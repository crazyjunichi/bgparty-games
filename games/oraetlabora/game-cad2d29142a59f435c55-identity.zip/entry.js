import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { DeltaNumber as u } from "@bgparty/sdk/fx/delta-number";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Floater as m, FlySprite as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as _, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/oraetlabora/meta.ts
var y = {
	id: "oraetlabora",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"engine-building",
		"tile-placement"
	],
	interactionTags: [],
	nameKey: "games.oraetlabora.name",
	descKey: "games.oraetlabora.desc",
	rulesKey: "games.oraetlabora.rules",
	icon: "⛪",
	iconImg: "games/oraetlabora.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1826794690258740734/C49AD7AA21F50BC0B93DA2419EE03AB554D44EE2/" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#54632f",
	releasedAt: "2026-11-02T00:40:00+08:00",
	search: {
		py: "qi dao yu gong zuo ora et labora",
		init: "qdygz"
	},
	hotseat: "open"
}, b = {
	G01: {
		id: "G01",
		cost: {
			wood: 1,
			clay: 1
		},
		economic: 4,
		dwelling: 3,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G01"
	},
	G02: {
		id: "G02",
		cost: { wood: 2 },
		economic: 4,
		dwelling: 4,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G02"
	},
	F03: {
		id: "F03",
		cost: {
			wood: 1,
			straw: 1
		},
		economic: 3,
		dwelling: 4,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.F03"
	},
	I03: {
		id: "I03",
		cost: { wood: 1 },
		economic: 2,
		dwelling: 3,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.I03"
	},
	F04: {
		id: "F04",
		cost: {
			wood: 3,
			clay: 2
		},
		economic: 10,
		dwelling: 6,
		cloister: !1,
		terrain: ["coast", "hillside"],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F04"
	},
	I04: {
		id: "I04",
		cost: { clay: 2 },
		economic: 5,
		dwelling: 4,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I04"
	},
	F05: {
		id: "F05",
		cost: {
			clay: 2,
			straw: 1
		},
		economic: 4,
		dwelling: 5,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F05"
	},
	I05: {
		id: "I05",
		cost: {
			stone: 2,
			straw: 1
		},
		economic: 9,
		dwelling: 7,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I05"
	},
	G06: {
		id: "G06",
		cost: {
			clay: 1,
			straw: 1
		},
		economic: 5,
		dwelling: 2,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G06"
	},
	G07: {
		id: "G07",
		cost: { clay: 1 },
		economic: 4,
		dwelling: -2,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G07"
	},
	F08: {
		id: "F08",
		cost: { stone: 2 },
		economic: 5,
		dwelling: 8,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F08"
	},
	I08: {
		id: "I08",
		cost: {
			wood: 2,
			clay: 1
		},
		economic: 5,
		dwelling: 5,
		cloister: !1,
		terrain: ["coast"],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I08"
	},
	F09: {
		id: "F09",
		cost: { coin: 3 },
		economic: 5,
		dwelling: 0,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F09"
	},
	I09: {
		id: "I09",
		cost: {
			wood: 1,
			straw: 1
		},
		economic: 3,
		dwelling: 3,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I09"
	},
	F10: {
		id: "F10",
		cost: {
			wood: 2,
			clay: 1
		},
		economic: 7,
		dwelling: 0,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [4],
		nameKey: "games.oraetlabora.buildings.F10"
	},
	I10: {
		id: "I10",
		cost: {
			stone: 1,
			straw: 1
		},
		economic: 5,
		dwelling: 0,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.I10"
	},
	F11: {
		id: "F11",
		cost: {
			wood: 1,
			stone: 1
		},
		economic: 1,
		dwelling: 7,
		cloister: !1,
		terrain: ["coast"],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F11"
	},
	I11: {
		id: "I11",
		cost: { wood: 1 },
		economic: 4,
		dwelling: 6,
		cloister: !1,
		terrain: ["water"],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I11"
	},
	G12: {
		id: "G12",
		cost: { wood: 1 },
		economic: 6,
		dwelling: 1,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G12"
	},
	G13: {
		id: "G13",
		cost: { clay: 2 },
		economic: 6,
		dwelling: 1,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 0,
		players: [4],
		nameKey: "games.oraetlabora.buildings.G13"
	},
	F14: {
		id: "F14",
		cost: { wood: 1 },
		economic: 3,
		dwelling: 6,
		cloister: !1,
		terrain: ["hillside"],
		stage: 1,
		players: [
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F14"
	},
	I14: {
		id: "I14",
		cost: { stone: 1 },
		economic: 3,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 1,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I14"
	},
	F15: {
		id: "F15",
		cost: {
			clay: 1,
			stone: 1
		},
		economic: 4,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 1,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.F15"
	},
	I15: {
		id: "I15",
		cost: {
			clay: 1,
			stone: 1
		},
		economic: 6,
		dwelling: 6,
		cloister: !1,
		terrain: ["hillside"],
		stage: 1,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.I15"
	},
	G16: {
		id: "G16",
		cost: {
			clay: 3,
			straw: 1
		},
		economic: 2,
		dwelling: 5,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 1,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G16"
	},
	F17: {
		id: "F17",
		cost: {
			stone: 2,
			straw: 1
		},
		economic: 7,
		dwelling: 7,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 1,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F17"
	},
	I17: {
		id: "I17",
		cost: {
			wood: 1,
			straw: 1
		},
		economic: 3,
		dwelling: 5,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 1,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I17"
	},
	G18: {
		id: "G18",
		cost: { wood: 3 },
		economic: 7,
		dwelling: 2,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 1,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G18"
	},
	G19: {
		id: "G19",
		cost: {
			wood: 2,
			clay: 2
		},
		economic: 8,
		dwelling: -3,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 1,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G19"
	},
	F20: {
		id: "F20",
		cost: {
			wood: 2,
			straw: 2
		},
		economic: 4,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F20"
	},
	I20: {
		id: "I20",
		cost: {
			wood: 1,
			stone: 1
		},
		economic: 3,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I20"
	},
	F21: {
		id: "F21",
		cost: {
			clay: 2,
			straw: 2
		},
		economic: 4,
		dwelling: 5,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F21"
	},
	I21: {
		id: "I21",
		cost: {
			clay: 2,
			straw: 2
		},
		economic: 6,
		dwelling: 5,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I21"
	},
	G22: {
		id: "G22",
		cost: { coin: 5 },
		economic: 7,
		dwelling: -4,
		cloister: !1,
		terrain: ["mountain"],
		stage: 2,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G22"
	},
	F23: {
		id: "F23",
		cost: {
			stone: 1,
			straw: 1
		},
		economic: 2,
		dwelling: 6,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.F23"
	},
	I23: {
		id: "I23",
		cost: {
			wood: 3,
			clay: 2
		},
		economic: 5,
		dwelling: 1,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.I23"
	},
	F24: {
		id: "F24",
		cost: {
			clay: 5,
			stone: 3
		},
		economic: 12,
		dwelling: 9,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F24"
	},
	I24: {
		id: "I24",
		cost: {
			clay: 3,
			stone: 3
		},
		economic: 10,
		dwelling: 8,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I24"
	},
	F25: {
		id: "F25",
		cost: {
			wood: 1,
			clay: 1
		},
		economic: 0,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.F25"
	},
	I25: {
		id: "I25",
		cost: { clay: 2 },
		economic: 2,
		dwelling: 6,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 2,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.I25"
	},
	G26: {
		id: "G26",
		cost: {
			clay: 4,
			stone: 1
		},
		economic: 15,
		dwelling: -2,
		cloister: !1,
		terrain: ["coast"],
		stage: 2,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G26"
	},
	F27: {
		id: "F27",
		cost: { coin: 25 },
		economic: 25,
		dwelling: 8,
		cloister: !1,
		terrain: ["hillside"],
		stage: 3,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F27"
	},
	I27: {
		id: "I27",
		cost: { coin: 20 },
		economic: 18,
		dwelling: 7,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 3,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I27"
	},
	G28: {
		id: "G28",
		cost: {
			wood: 6,
			stone: 5
		},
		economic: 15,
		dwelling: 7,
		cloister: !1,
		terrain: ["hillside", "mountain"],
		stage: 3,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G28"
	},
	F29: {
		id: "F29",
		cost: { coin: 5 },
		economic: 7,
		dwelling: -4,
		cloister: !1,
		terrain: ["mountain"],
		stage: 3,
		players: [3, 4],
		nameKey: "games.oraetlabora.buildings.F29"
	},
	I29: {
		id: "I29",
		cost: {
			clay: 1,
			straw: 1
		},
		economic: 1,
		dwelling: 5,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 3,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I29"
	},
	F30: {
		id: "F30",
		cost: {
			stone: 2,
			straw: 2
		},
		economic: 6,
		dwelling: 5,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 3,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F30"
	},
	I30: {
		id: "I30",
		cost: {
			wood: 1,
			clay: 2
		},
		economic: 4,
		dwelling: 5,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 3,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I30"
	},
	F31: {
		id: "F31",
		cost: { wood: 1 },
		economic: 3,
		dwelling: 6,
		cloister: !1,
		terrain: ["hillside"],
		stage: 3,
		players: [4],
		nameKey: "games.oraetlabora.buildings.F31"
	},
	I31: {
		id: "I31",
		cost: {
			clay: 1,
			stone: 2
		},
		economic: 12,
		dwelling: 0,
		cloister: !1,
		terrain: ["coast"],
		stage: 3,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.I31"
	},
	F32: {
		id: "F32",
		cost: { stone: 1 },
		economic: 2,
		dwelling: 5,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 3,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F32"
	},
	I32: {
		id: "I32",
		cost: {
			wood: 3,
			clay: 4
		},
		economic: 6,
		dwelling: 7,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 3,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I32"
	},
	F33: {
		id: "F33",
		cost: {
			wood: 3,
			clay: 3
		},
		economic: 8,
		dwelling: 4,
		cloister: !1,
		terrain: ["coast"],
		stage: 3,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F33"
	},
	I33: {
		id: "I33",
		cost: {
			clay: 3,
			straw: 1
		},
		economic: 5,
		dwelling: 3,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 3,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I33"
	},
	G34: {
		id: "G34",
		cost: {
			stone: 3,
			straw: 2
		},
		economic: 10,
		dwelling: 7,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G34"
	},
	F35: {
		id: "F35",
		cost: {
			clay: 2,
			straw: 1
		},
		economic: 4,
		dwelling: 2,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F35"
	},
	I35: {
		id: "I35",
		cost: { stone: 4 },
		economic: 6,
		dwelling: 2,
		cloister: !1,
		terrain: ["hillside"],
		stage: 4,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I35"
	},
	F36: {
		id: "F36",
		cost: { coin: 6 },
		economic: 2,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F36"
	},
	I36: {
		id: "I36",
		cost: { clay: 2 },
		economic: 5,
		dwelling: 3,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I36"
	},
	F37: {
		id: "F37",
		cost: { clay: 3 },
		economic: 3,
		dwelling: 4,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F37"
	},
	I37: {
		id: "I37",
		cost: {
			wood: 2,
			clay: 4
		},
		economic: 8,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I37"
	},
	F38: {
		id: "F38",
		cost: {
			wood: 1,
			stone: 2
		},
		economic: 5,
		dwelling: 5,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F38"
	},
	I38: {
		id: "I38",
		cost: { coin: 10 },
		economic: 3,
		dwelling: 7,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I38"
	},
	G39: {
		id: "G39",
		cost: {
			wood: 2,
			stone: 2
		},
		economic: 5,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [1, 4],
		nameKey: "games.oraetlabora.buildings.G39"
	},
	F40: {
		id: "F40",
		cost: {
			wood: 3,
			straw: 1
		},
		economic: 7,
		dwelling: 5,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.F40"
	},
	I40: {
		id: "I40",
		cost: {
			wood: 3,
			straw: 1
		},
		economic: 7,
		dwelling: 5,
		cloister: !1,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.I40"
	},
	G41: {
		id: "G41",
		cost: {
			clay: 1,
			stone: 1
		},
		economic: 3,
		dwelling: 3,
		cloister: !0,
		terrain: [
			"coast",
			"plains",
			"hillside"
		],
		stage: 4,
		players: [
			1,
			2,
			3,
			4
		],
		nameKey: "games.oraetlabora.buildings.G41"
	},
	farm: {
		id: "farm",
		cost: {},
		economic: 0,
		dwelling: 2,
		cloister: !1,
		terrain: ["plains"],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 0,
		nameKey: "games.oraetlabora.buildings.farm"
	},
	claymound: {
		id: "claymound",
		cost: {},
		economic: 0,
		dwelling: 3,
		cloister: !1,
		terrain: ["hillside"],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 0,
		nameKey: "games.oraetlabora.buildings.claymound"
	},
	office: {
		id: "office",
		cost: {},
		economic: 0,
		dwelling: 2,
		cloister: !0,
		terrain: ["plains"],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 0,
		nameKey: "games.oraetlabora.buildings.office"
	},
	S01: {
		id: "S01",
		cost: {},
		economic: 0,
		dwelling: -3,
		cloister: !1,
		terrain: [
			"plains",
			"coast",
			"hillside"
		],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 0,
		food: 1,
		energy: 1,
		nameKey: "games.oraetlabora.buildings.S01"
	},
	S02: {
		id: "S02",
		cost: {},
		economic: 1,
		dwelling: 1,
		cloister: !1,
		terrain: [
			"plains",
			"coast",
			"hillside"
		],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 0,
		food: 3,
		energy: 3,
		nameKey: "games.oraetlabora.buildings.S02"
	},
	S03: {
		id: "S03",
		cost: {},
		economic: 2,
		dwelling: 2,
		cloister: !1,
		terrain: [
			"plains",
			"coast",
			"hillside"
		],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 0,
		food: 7,
		energy: 0,
		nameKey: "games.oraetlabora.buildings.S03"
	},
	S04: {
		id: "S04",
		cost: {},
		economic: 4,
		dwelling: 6,
		cloister: !1,
		terrain: ["coast"],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 0,
		food: 8,
		energy: 3,
		nameKey: "games.oraetlabora.buildings.S04"
	},
	S05: {
		id: "S05",
		cost: {},
		economic: -1,
		dwelling: 5,
		cloister: !1,
		terrain: [
			"plains",
			"coast",
			"hillside"
		],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 1,
		food: 5,
		energy: 1,
		nameKey: "games.oraetlabora.buildings.S05"
	},
	S06: {
		id: "S06",
		cost: {},
		economic: 3,
		dwelling: 4,
		cloister: !1,
		terrain: [
			"plains",
			"coast",
			"hillside"
		],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 2,
		food: 5,
		energy: 6,
		nameKey: "games.oraetlabora.buildings.S06"
	},
	S07: {
		id: "S07",
		cost: {},
		economic: 8,
		dwelling: 6,
		cloister: !1,
		terrain: [
			"plains",
			"coast",
			"hillside"
		],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 3,
		food: 15,
		energy: 9,
		nameKey: "games.oraetlabora.buildings.S07"
	},
	S08: {
		id: "S08",
		cost: {},
		economic: 10,
		dwelling: 8,
		cloister: !1,
		terrain: ["hillside"],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 4,
		food: 30,
		energy: 3,
		nameKey: "games.oraetlabora.buildings.S08"
	},
	FL1: {
		id: "FL1",
		cost: { coin: 3 },
		economic: 2,
		dwelling: 0,
		cloister: !1,
		terrain: ["hillside"],
		players: [
			1,
			2,
			3,
			4
		],
		stage: 1,
		nameKey: "games.oraetlabora.buildings.FL1"
	}
}, x = {
	grain: 1,
	flour: 1,
	malt: 1,
	grapes: 1,
	coin: 1,
	coin5: 5,
	wine: 1,
	livestock: 2,
	whiskey: 2,
	bread: 3,
	meat: 5,
	beer: 5
}, S = {
	straw: .5,
	wood: 1,
	peat: 2,
	peatcoal: 3
}, C = {
	coin5: 2,
	book: 2,
	ceramic: 3,
	ornament: 4,
	reliquary: 8,
	wine: 1,
	whiskey: 1
}, ee = [
	0,
	2,
	3,
	4,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	10
], w = [
	0,
	1,
	2,
	2,
	3,
	4,
	4,
	5,
	6,
	6,
	7,
	8,
	10
], T = [
	2,
	3,
	4,
	4,
	5,
	5,
	6,
	7,
	8
], te = [
	3,
	4,
	4,
	5,
	5,
	5,
	6,
	6,
	7
], ne = [
	["livestock", "grain"],
	["clay", "grain"],
	["wood", "grain"],
	["stone", "grain"],
	["stone", "peat"],
	["stone", "clay"],
	["stone", "wood"],
	["stone", "coin5"],
	["stone", "meat"],
	["grain", "book"],
	["clay", "ceramic"],
	["wood", "ornament"]
], E = [
	"wood",
	"clay",
	"peat",
	"grain",
	"livestock",
	"coin",
	"coin5",
	"straw",
	"stone",
	"peatcoal",
	"meat",
	"flour",
	"bread",
	"grapes",
	"wine",
	"malt",
	"beer",
	"whiskey",
	"book",
	"ceramic",
	"ornament",
	"reliquary"
], D = [
	"wood",
	"clay",
	"peat",
	"grain",
	"livestock",
	"coin"
], re = t.enum(E), O = t.partialRecord(re, t.int().min(0).max(1e5)), ie = t.enum([
	"plains",
	"hillside",
	"coast",
	"water",
	"mountain"
]), ae = t.object({
	country: t.enum(["france", "ireland"]).default("france"),
	length: t.enum([
		"normal",
		"short",
		"long"
	]).default("normal"),
	loamy: t.boolean().default(!1),
	wonders: t.boolean().default(!1)
}).default({
	country: "france",
	length: "normal",
	loamy: !1,
	wonders: !1
}), k = t.object({
	key: t.string(),
	x: t.int(),
	y: t.number(),
	terrain: ie,
	cover: t.enum(["forest", "moor"]).nullable(),
	building: t.string().nullable(),
	clergy: t.object({
		owner: t.string(),
		index: t.int().min(0).max(2)
	}).nullable(),
	bonusClergy: t.array(t.object({
		owner: t.string(),
		index: t.literal(0)
	})).default([])
}), oe = t.object({
	rid: t.string(),
	stock: O,
	cells: t.array(k),
	settlements: t.array(t.string()),
	wonders: t.array(t.int().min(0).max(26)),
	districts: t.int(),
	plots: t.int()
}), se = t.object({
	cost: O,
	gain: O,
	food: t.number(),
	energy: t.number(),
	points: t.number()
}), ce = t.object({
	kind: t.enum([
		"trade",
		"production",
		"copy",
		"clear",
		"build",
		"settlement",
		"points",
		"land",
		"wonder",
		"prior",
		"swap",
		"neutral",
		"neutralUse"
	]),
	source: t.string(),
	owner: t.string(),
	cell: t.string(),
	recipes: t.array(se),
	limit: t.int(),
	goods: t.array(re),
	mode: t.string(),
	amount: t.number(),
	different: t.int(),
	path: t.array(t.string())
}), A = t.object({
	rid: t.string(),
	kind: t.string(),
	source: t.string(),
	value: t.number(),
	goods: O
}), j = t.object({
	config: ae,
	players: t.array(oe),
	neutral: oe.nullable(),
	round: t.int(),
	start: t.int(),
	turn: t.string(),
	actionQueue: t.array(t.string()),
	phase: t.enum([
		"action",
		"effect",
		"contract",
		"settlement",
		"done"
	]),
	consumed: t.boolean(),
	tasks: t.array(ce),
	afterTasks: t.enum([
		"action",
		"settlement",
		"neutralDone",
		"settlementStart"
	]),
	settlementStage: t.int(),
	settlementQueue: t.array(t.string()),
	finalSettlement: t.boolean(),
	bonus: t.boolean(),
	finalTurn: t.boolean(),
	endTriggered: t.boolean(),
	market: t.array(t.string()),
	remaining: t.array(t.string()),
	wheel: t.record(t.string(), t.int().min(-1).max(12)),
	landBought: t.int(),
	chainActions: t.int(),
	chainLand: t.int(),
	chainFirstLand: t.boolean(),
	neutralNew: t.array(t.string()),
	lastActor: t.string(),
	pendingFinal: t.boolean(),
	districtPrices: t.array(t.int()),
	plotPrices: t.array(t.int()),
	wonderSupply: t.array(t.int()),
	wonderCount: t.int(),
	used: t.array(t.string()),
	contract: t.object({
		owner: t.string(),
		cell: t.string(),
		actor: t.string()
	}).nullable(),
	log: t.array(A),
	serial: t.int()
}), le = t.object({}), M = t.string().max(40), ue = t.int().min(1).max(1e5), de = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("harvest"),
		cell: M,
		marker: t.enum([
			"wood",
			"peat",
			"joker"
		])
	}),
	t.object({
		type: t.literal("use"),
		owner: t.string(),
		cell: M,
		clergy: t.int().min(0).max(2),
		gift: t.enum([
			"coin",
			"wine",
			"whiskey"
		]).default("coin")
	}),
	t.object({
		type: t.literal("contract"),
		clergy: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("build"),
		building: t.string(),
		cell: M
	}),
	t.object({
		type: t.literal("land"),
		tile: t.enum(["district", "plot"]),
		side: t.int().min(0).max(1),
		x: t.int().min(-30).max(30),
		y: t.int().min(-30).max(30)
	}),
	t.object({
		type: t.literal("exchange"),
		from: t.enum([
			"grain",
			"coin",
			"coin5",
			"wine",
			"whiskey"
		]),
		count: ue
	}),
	t.object({
		type: t.literal("settle"),
		building: t.string(),
		cell: M,
		food: O,
		energy: O
	}),
	t.object({
		type: t.literal("resolve"),
		option: t.int().min(0).default(0),
		count: t.int().min(0).max(1e5).default(1),
		inputs: O.default({}),
		food: O.default({}),
		energy: O.default({}),
		points: O.default({}),
		output: re.optional(),
		secondary: re.optional(),
		target: M.default(""),
		owner: t.string().default(""),
		cells: t.array(M).max(4).default([]),
		marker: t.string().default(""),
		swap: t.array(t.string()).max(2).default([])
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("end") })
]);
//#endregion
//#region src/games/oraetlabora/effects.ts
function N(e, t, n, r, i = {}) {
	return {
		kind: e,
		source: t,
		owner: n,
		cell: r,
		recipes: [],
		limit: 1,
		goods: [],
		mode: "",
		amount: 0,
		different: 0,
		path: [],
		...i
	};
}
var P = (e, t, n = 0, r = 0, i = 0) => ({
	cost: e,
	gain: t,
	energy: n,
	food: r,
	points: i
});
function fe(e, t, n, r = []) {
	let i = (i, a = {}) => N(i, e, t, n, {
		path: r,
		...a
	}), a = (e, t, n = 1, r = 0, a = 0, o = {}) => i("trade", {
		recipes: [P(e, t, r, a)],
		limit: n,
		...o
	}), o = (e) => a({}, e), s = (...e) => i("production", { goods: e }), c = (e) => i("copy", { mode: e });
	switch (e) {
		case "farm": return [s("grain", "livestock")];
		case "claymound": return [s("clay")];
		case "office": return [s("coin")];
		case "FL1": return [i("swap"), s("clay", "livestock", "grain")];
		case "G01": return [c("prior")];
		case "G02": return [a({}, {}, 1, 0, 0, {
			different: 3,
			goods: D,
			amount: 6,
			mode: "basic"
		})];
		case "F03": return [a({ coin: 1 }, { grain: 6 })];
		case "I03": return [a({ coin: 1 }, {
			book: 1,
			grain: 4
		})];
		case "F04": return [a({ grain: 1 }, {
			straw: 1,
			flour: 1
		}, 7)];
		case "I04": return [a({ grain: 1 }, {
			straw: 1,
			malt: 1
		}, 1e5)];
		case "F05": return [a({ flour: 1 }, { bread: 1 }, 1e5, .5), a({ bread: 1 }, { coin: 4 }, 2)];
		case "I05": return [a({
			malt: 1,
			grain: 1
		}, { beer: 1 }, 1e5), a({ beer: 1 }, { coin: 7 })];
		case "G06": return [i("trade", { recipes: [
			P({}, { coin: 5 }, 3),
			P({}, { coin: 8 }, 6),
			P({}, { coin: 10 }, 9)
		] })];
		case "G07": return [o({
			peatcoal: 1,
			coin: 1
		}), a({ peat: 1 }, { peatcoal: 1 }, 1e5)];
		case "F08": return [a({}, {
			coin: 7,
			bread: 1
		}, 1, 0, 0, { different: 4 })];
		case "I08": return [o({ coin: 3 }), i("trade", { recipes: [P({}, { beer: 1 }), P({}, { whiskey: 1 })] })];
		case "F09": return [o({ grapes: 1 }), c("adjacent")];
		case "I09": return [a({}, {}, 1, 0, 0, { mode: "livestock" })];
		case "F10": return [i("clear", {
			mode: "carpentry",
			goods: ["wood"]
		})];
		case "I10": return [o({ malt: 1 }), c("adjacent")];
		case "F11": return [o({
			ceramic: 1,
			wine: 1,
			wood: 1,
			coin: 1
		})];
		case "I11": return [o({
			malt: 1,
			wood: 1,
			peat: 1,
			coin: 1
		})];
		case "G12": return [a({}, { stone: 1 }, 5, 1, 2)];
		case "G13": return [a({ coin: 2 }, {
			wood: 2,
			clay: 2,
			stone: 1,
			straw: 1
		})];
		case "F14":
		case "F31": return [s("grapes")];
		case "I14": return [
			o({ book: 1 }),
			i("trade", { recipes: [P({}, { grain: 2 }), P({}, { malt: 2 })] }),
			i("trade", { recipes: [P({}, { beer: 1 }), P({}, { whiskey: 1 })] })
		];
		case "F15": return [a({ coin: 1 }, {
			book: 1,
			bread: 1,
			grapes: 2,
			flour: 2
		})];
		case "I15": return [a({ book: 1 }, {}, 1, 0, 0, {
			mode: "twoBasic",
			goods: D
		})];
		case "G16": return [o({
			wood: 1,
			clay: 1,
			peat: 1,
			grain: 1,
			livestock: 1,
			coin: 1
		})];
		case "F17": return [a({ coin: 1 }, { book: 1 }, 3), a({ book: 1 }, {
			meat: 1,
			wine: 1
		})];
		case "I17": return [a({ coin: 1 }, {
			book: 1,
			meat: 1,
			whiskey: 1
		})];
		case "G18": return [a({ clay: 1 }, { ceramic: 1 }, 3, 1), a({ stone: 1 }, { ornament: 1 }, 1, 1)];
		case "G19": return [a({
			livestock: 1,
			straw: 1
		}, { meat: 1 }, 1e5)];
		case "F20": return [a({}, { coin: 1 }, 7, 0, 1), a({ wine: 1 }, { coin: 6 })];
		case "I20": return [a({ beer: 1 }, { coin: 8 }), a({ whiskey: 1 }, { coin: 7 })];
		case "F21": return [a({ grapes: 1 }, { wine: 1 }, 1e5), a({ wine: 1 }, { coin: 7 })];
		case "I21": return [a({
			malt: 1,
			wood: 1,
			peat: 1
		}, { whiskey: 2 }, 1e5)];
		case "G22":
		case "F29": return [s("stone")];
		case "F23": return [a({ coin: 1 }, {
			book: 1,
			ceramic: 1
		}, 1, 0, 0, { mode: "bathhouse" })];
		case "I23": return [a({ coin: 2 }, {}, 1, 0, 0, { mode: "locutory" })];
		case "F24": return [a({
			bread: 1,
			wine: 1
		}, { reliquary: 1 }, 2)];
		case "I24": return [a({ coin: 1 }, { book: 1 }), a({
			beer: 1,
			whiskey: 1
		}, { reliquary: 1 }, 3)];
		case "F25": return [a({}, {}, 1, 0, 0, {
			different: 13,
			mode: "wonder"
		})];
		case "I25": return [a({ reliquary: 1 }, {
			stone: 2,
			wood: 2,
			clay: 2,
			peat: 2,
			grain: 2,
			livestock: 2,
			coin: 2
		})];
		case "G26": return [a({ wood: 2 }, {
			coin: 5,
			ornament: 1
		})];
		case "F27": return [a({ wine: 1 }, {}, 1, 0, 0, { mode: "occupied" })];
		case "I27": return [a({ whiskey: 1 }, {}, 1, 0, 0, { mode: "occupied" })];
		case "G28": return [i("settlement")];
		case "I29": return [i("clear", {
			mode: "forestHut",
			goods: ["wood"]
		})];
		case "F30": return [a({ ceramic: 1 }, { coin: 12 })];
		case "I30": return [o({
			beer: 1,
			meat: 1
		}), a({ meat: 1 }, { ceramic: 1 }, 4)];
		case "I31": return [a({ peatcoal: 1 }, {
			coin: 3,
			whiskey: 1
		}, 3)];
		case "F32": return [a({ coin: 1 }, {}, 1, 0, 0, { mode: "calefactory" })];
		case "I32": return [a({}, { reliquary: 1 }, 1, 0, 0, { different: 5 })];
		case "F33": return [a({}, {}, 1, 3, 0, { mode: "shipping" })];
		case "I33": return [a({ wood: 3 }, {}, 1, 0, 0, { mode: "cooperage" })];
		case "G34": return [a({
			book: 1,
			ceramic: 1,
			ornament: 1,
			reliquary: 1
		}, {}, 1, 0, 0, { mode: "wonder" })];
		case "F35": return [a({}, {}, 1e5, 0, 0, { mode: "forge" })];
		case "I35": return [i("trade", {
			recipes: [P({
				whiskey: 1,
				coin: 5
			}, {}, 0, 0, 14)],
			mode: "wonder"
		})];
		case "F36": return [i("trade", {
			recipes: [
				P({ book: 1 }, { ceramic: 1 }),
				P({ ceramic: 1 }, { ornament: 1 }),
				P({ ornament: 1 }, { reliquary: 1 })
			],
			limit: 2,
			mode: "repeat"
		})];
		case "I36": return [a({
			book: 1,
			ceramic: 1
		}, {
			coin: 1,
			clay: 1,
			reliquary: 1
		}, 2)];
		case "F37": return [o({ ceramic: 1 }), a({
			wood: 1,
			straw: 1
		}, { book: 1 }, 1e5)];
		case "I37": return [a({ book: 1 }, {}, 1, 0, 0, { mode: "bulwark" })];
		case "F38": return [i("clear", {
			mode: "printing",
			limit: 4,
			goods: ["wood"]
		})];
		case "I38": return [a({ beer: 1 }, {}, 1, 0, 0, { mode: "festival" })];
		case "G39": return [i("trade", {
			recipes: [P({}, {
				book: 1,
				ornament: 1
			}, 0, 10), P({}, {
				book: 1,
				ornament: 1
			}, 6)],
			limit: 2,
			mode: "repeat"
		})];
		case "F40":
		case "I40": return [c("market")];
		case "G41": return [a({ coin: 5 }, {}, 1, 0, 0, { mode: "brotherhood" })];
		default: return [];
	}
}
//#endregion
//#region src/games/oraetlabora/rules.ts
var pe = "$neutral", me = (e, t) => `${e},${t}`, F = (e) => [...e.players, ...e.neutral ? [e.neutral] : []], I = (e, t) => F(e).find((e) => e.rid === t), L = (e) => (e.coin ?? 0) + 5 * (e.coin5 ?? 0), R = (e, t) => E.reduce((n, r) => n + (e[r] ?? 0) * (t[r] ?? 0), 0), z = (e, t) => e.x === t.x ? Math.abs(e.y - t.y) === (e.terrain === "mountain" || t.terrain === "mountain" ? 1.5 : 1) : Math.abs(e.x - t.x) === 1 && Math.abs(e.y - t.y) < (e.terrain === "mountain" || t.terrain === "mountain" ? 1 : .1), B = (e) => [...e.clergy ? [e.clergy] : [], ...e.bonusClergy], V = (e, t) => Array.from({ length: e.config.length === "short" ? 2 : 3 }, (e, t) => t).filter((n) => !F(e).some((e) => e.cells.some((e) => B(e).some((e) => e.owner === t && e.index === n)))), he = (e, t) => (e.config.length === "normal" && e.players.length === 2 ? w : ee)[e.wheel[t]] ?? 0, ge = (e) => {
	let t = e.config.country === "france" ? "F21" : "I21";
	return e.market.includes(t) || e.remaining.includes(t) ? 1 : 2;
}, H = (e) => e.phase === "contract" ? e.contract?.owner ?? e.turn : e.turn, U = () => ({ code: "games.oraetlabora.invalid" }), W = (e, t, n = 1) => {
	for (let r of E) e.stock[r] = (e.stock[r] ?? 0) + (t[r] ?? 0) * n;
}, _e = (e, t) => E.every((n) => (t[n] ?? 0) <= (e.stock[n] ?? 0)), ve = (...e) => {
	let t = {};
	for (let n of e) for (let e of E) t[e] = (t[e] ?? 0) + (n[e] ?? 0);
	return t;
}, ye = (e, t) => Object.fromEntries(Object.entries(e).map(([e, n]) => [e, n * t])), be = (e, t) => _e(e, t) ? (W(e, t, -1), !0) : !1;
function xe(e, t) {
	let n = { ...t };
	if (delete n.coin, !_e(e, n) || L(e.stock) < (t.coin ?? 0)) return !1;
	W(e, n, -1);
	let r = t.coin ?? 0, i = Math.min(e.stock.coin ?? 0, r);
	if (e.stock.coin = (e.stock.coin ?? 0) - i, r -= i, r > 0) {
		let t = Math.ceil(r / 5);
		e.stock.coin5 = (e.stock.coin5 ?? 0) - t, e.stock.coin += t * 5 - r;
	}
	return !0;
}
var Se = (e, t, n) => E.every((t) => !(e[t] ?? 0) || !!n[t]) && R(e, n) >= t;
function Ce(e, t, n, r, i, a, o, s) {
	return !Se(n, a, x) || !Se(r, o, S) || !Se(i, s, C) || !be(e, ve(n, r, i)) ? !1 : xe(e, t);
}
function G(e, t, n = "", r = 0, i = {}) {
	e.serial++, e.log.push({
		rid: e.turn,
		kind: t,
		source: n,
		value: r,
		goods: i
	}), e.log.length > 60 && e.log.shift();
}
function K(e, t, n = !1, r = !1) {
	for (let i of F(e)) for (let e of i.cells) r && i.rid !== t || (e.clergy?.owner === t && (!n || e.clergy.index === 0) && (e.clergy = null), e.bonusClergy = e.bonusClergy.filter((e) => e.owner !== t));
}
function we(e, t) {
	V(e, t.rid).length || K(e, t.rid);
}
function Te(e, t = !1, n = !1) {
	let r = [];
	for (let e = 0; e < 2; e++) for (let i = 0; i < 5; i++) r.push({
		key: me(i, e),
		x: i,
		y: e,
		terrain: i === 4 && e === 0 ? "hillside" : "plains",
		cover: n ? null : i === 0 ? t && e === 0 ? null : "moor" : i === 1 || i === 2 && e === 0 ? t && i === 1 && e === 0 ? null : "forest" : null,
		building: i === 4 ? e === 0 ? "claymound" : "office" : i === 2 && e === 1 ? "farm" : null,
		clergy: null,
		bonusClergy: []
	});
	return n && (r[0].building = "G13"), {
		rid: e,
		cells: r,
		stock: {},
		settlements: [
			"S01",
			"S02",
			"S03",
			"S04"
		],
		wonders: [],
		districts: 0,
		plots: 0
	};
}
function Ee(t, n, r) {
	let i = ae.parse(t);
	(n.length < 3 && i.length === "short" || n.length !== 2 && i.length === "long") && (i.length = "normal"), i.country !== "france" && (i.loamy = !1);
	let a = n.length, o = Object.values(b).filter((e) => !e.id.startsWith("S") && ![
		"farm",
		"office",
		"claymound",
		"FL1"
	].includes(e.id) && (e.id[0] === "G" || e.id[0] === (i.country === "france" ? "F" : "I"))).filter((e) => a === 1 ? ![
		"F10",
		"F14",
		"F29",
		"F31",
		"G13"
	].includes(e.id) : i.length === "long" ? ![
		"F10",
		"F29",
		"F31"
	].includes(e.id) : e.players.includes(i.length === "short" ? a - 1 : a)).map((e) => e.id);
	i.loamy && o.push("FL1");
	let s = Array.from({ length: 26 }, (e, t) => t + 1);
	for (let t = s.length - 1; t > 0; t--) {
		let n = e(r, 26 - t, t + 1);
		[s[t], s[n]] = [s[n], s[t]];
	}
	let c = {
		config: i,
		players: n.map((e) => Te(e, i.length === "short")),
		neutral: a === 1 ? Te(pe, !1, !0) : null,
		round: 0,
		start: 0,
		turn: n[0],
		actionQueue: [],
		phase: "action",
		consumed: !1,
		tasks: [],
		afterTasks: "action",
		settlementStage: 0,
		settlementQueue: [],
		finalSettlement: !1,
		bonus: !1,
		finalTurn: !1,
		endTriggered: !1,
		market: o.filter((e) => b[e].stage === 0),
		remaining: o.filter((e) => b[e].stage > 0),
		wheel: Object.fromEntries([...D, "joker"].map((e) => [e, +(a === 1)])),
		landBought: 0,
		chainActions: 0,
		chainLand: 0,
		chainFirstLand: !1,
		neutralNew: [],
		lastActor: "",
		pendingFinal: !1,
		districtPrices: a === 1 ? [...T].reverse() : [...T],
		plotPrices: a === 1 ? [...te].reverse() : [...te],
		wonderSupply: i.wonders ? s.slice(0, 2 * a + 1) : [],
		wonderCount: 0,
		used: [],
		contract: null,
		log: [],
		serial: 0
	};
	for (let e of c.players) a > 1 && W(e, Object.fromEntries(D.map((e) => [e, i.length === "short" ? 2 : 1])));
	return ke(c), { state: c };
}
function De(e) {
	for (let t of Object.keys(e.wheel)) e.wheel[t] >= 0 && (e.wheel[t] = e.wheel[t] === 12 ? e.players.length === 1 ? -1 : 12 : e.wheel[t] + 1);
	let t = e.players.length, n = e.config.length === "short";
	if (t > 1 && (e.config.country === "france" && e.round === (n ? 4 : t === 2 ? 11 : 8) && (e.wheel.grapes = 0), e.round === (n ? 6 : t === 2 ? 18 : 13) && (e.wheel.stone = 0)), n && e.round <= 12) for (let t of e.players) for (let n of ne[e.round - 1]) W(t, { [n]: 1 });
	G(e, "round", "", e.round);
}
function Oe(e, t) {
	e.lastActor !== t && (e.landBought = 0, e.used = [], e.chainActions = 0, e.chainLand = 0, e.chainFirstLand = !1), e.chainActions++, e.lastActor = t, e.turn = t, e.phase = "action", e.consumed = !1;
}
function ke(e) {
	e.round++;
	let t = e.players.length;
	for (let t of F(e)) we(e, t);
	De(e), e.start = t === 1 ? 0 : (e.round - 1) % t;
	let n = e.players.map((n, r) => e.players[(e.start + r) % t].rid);
	e.actionQueue = t >= 3 ? [...n, n[0]] : e.config.length === "long" ? [
		n[0],
		n[0],
		n[1]
	] : [n[0], n[0]];
	let r = (t === 1 ? [
		12,
		16,
		22,
		26,
		32
	] : e.config.length === "short" ? [
		3,
		5,
		7,
		9,
		13
	] : t === 4 ? [
		7,
		10,
		16,
		19,
		25
	] : t === 3 ? [
		6,
		11,
		15,
		20,
		25
	] : [
		7,
		14,
		21,
		28
	]).indexOf(e.round);
	if (r === 4 && t >= 3) {
		e.bonus = !0;
		for (let t of e.players) K(e, t.rid, !0);
		e.actionQueue = n, Oe(e, e.actionQueue.shift());
		return;
	}
	if (r === 4 && t === 1 && (e.pendingFinal = !0), r >= 0 && r < 4) {
		Ae(e, !1);
		return;
	}
	Oe(e, e.actionQueue.shift());
}
function Ae(e, t) {
	if (e.finalSettlement = t, e.tasks = [], e.afterTasks = "settlementStart", e.turn = e.players[e.start].rid, e.landBought = 0, e.neutral && e.market.length) {
		e.phase = "effect", e.neutralNew = [], e.tasks = [N("neutral", "", pe, "")];
		return;
	}
	je(e);
}
function je(e) {
	e.phase = "settlement", e.tasks = [], e.settlementQueue = e.players.map((t, n) => e.players[(e.start + n) % e.players.length].rid), e.turn = e.settlementQueue.shift(), e.landBought = 0, e.consumed = !1;
}
function Me(e) {
	if (e.settlementQueue.length) {
		e.turn = e.settlementQueue.shift(), e.landBought = 0, e.consumed = !1;
		return;
	}
	if (e.finalSettlement) {
		e.phase = "done";
		return;
	}
	e.settlementStage++;
	let t = e.remaining.filter((t) => b[t].stage === e.settlementStage);
	e.market.push(...t), e.remaining = e.remaining.filter((e) => !t.includes(e));
	for (let t of e.players) t.settlements.push(`S0${e.settlementStage + 4}`);
	e.lastActor = "", Oe(e, e.actionQueue.shift());
}
function Ne(e) {
	if (e.settlementStage === 4 && e.players.length === 2 && e.market.length <= (e.config.length === "long" ? 3 : 1) && (e.endTriggered = !0), e.actionQueue.length) {
		Oe(e, e.actionQueue.shift());
		return;
	}
	if (e.bonus || e.pendingFinal) {
		Ae(e, !0);
		return;
	}
	if (e.finalTurn || e.endTriggered && e.config.length === "long") {
		e.phase = "done";
		return;
	}
	if (e.endTriggered && e.players.length === 2) {
		e.finalTurn = !0, De(e);
		let t = e.players.find((t) => t.rid !== e.turn).rid;
		for (let t of e.players) we(e, t);
		Oe(e, t);
		return;
	}
	ke(e);
}
function q(e, t, n, r = !1) {
	let i = b[t];
	return !i || n.clergy || n.cover || !r && n.building && (t !== "FL1" || n.building !== "claymound") || r && n.building && b[n.building].cloister !== i.cloister || !r && !i.terrain.includes(n.terrain) ? !1 : !i.cloister || e.cells.some((e) => e.building && b[e.building].cloister && z(e, n));
}
function Pe(e) {
	if (e.tasks.length) {
		e.phase = "effect";
		return;
	}
	e.afterTasks === "settlementStart" || e.afterTasks === "neutralDone" ? (e.neutral && we(e, e.neutral), je(e)) : e.phase = e.afterTasks;
}
function Fe(e, t, n, r, i = []) {
	if ([
		"F09",
		"I10",
		"G26",
		"F30",
		"G34"
	].includes(t)) {
		if (e.used.includes(t)) return !1;
		e.used.push(t);
	}
	return e.tasks.unshift(...fe(t, n, r, [...i, `${n}:${r}:${t}`])), G(e, "use", t), Pe(e), !0;
}
function Ie(e, t, n, r) {
	if (r !== n && r !== "joker" || !(r in e.wheel) || e.wheel[r] < 0) return !1;
	let i = he(e, r);
	if (W(t, { [n]: i }), e.wheel[r] = 0, e.config.length === "short") for (let t of e.players) W(t, { [n]: 1 });
	return G(e, "produce", n, i, { [n]: i }), !0;
}
function Le(e, t, n, r, i = !1) {
	let a = t.cells.find((e) => e.key === r);
	return !e.market.includes(n) || !a || !q(t, n, a) || !i && !xe(t, b[n].cost) ? !1 : (a.building = n, e.market.splice(e.market.indexOf(n), 1), G(e, "build", n), V(e, t.rid).includes(0) && e.tasks.unshift(N("prior", n, t.rid, r)), !0);
}
function Re(e, t, n, r) {
	let i = (e, t, i, a = null) => ({
		key: me(n + e, r + t),
		x: n + e,
		y: r + t,
		terrain: i,
		cover: a,
		building: null,
		clergy: null,
		bonusClergy: []
	});
	return e === "district" ? t === 0 ? [
		i(0, 0, "plains", "moor"),
		i(1, 0, "plains", "forest"),
		i(2, 0, "plains", "forest"),
		i(3, 0, "hillside"),
		i(4, 0, "hillside")
	] : [
		i(0, 0, "plains", "forest"),
		i(1, 0, "plains"),
		i(2, 0, "plains"),
		i(3, 0, "plains"),
		i(4, 0, "hillside")
	] : t === 0 ? [
		i(0, 0, "water"),
		i(0, 1, "water"),
		i(1, 0, "coast"),
		i(1, 1, "coast")
	] : [
		i(0, 0, "hillside"),
		i(0, 1, "hillside"),
		i(1, .5, "mountain")
	];
}
var ze = (e, t) => e.x === t.x && Math.abs(e.y - t.y) < (e.terrain === "mountain" || t.terrain === "mountain" ? 1 : .1);
function Be(e, t, n) {
	return t.some((t) => e.cells.some((e) => ze(t, e))) ? !1 : n === "district" ? t[0].x === 0 && e.cells.some((e) => e.x === 0 && e.terrain === "plains" && Math.abs(e.y - t[0].y) === 1) : !(t.some((e) => e.terrain === "coast") ? t.find((e) => e.terrain === "coast").x >= 0 : t[0].x < 5) && t.some((t) => t.terrain !== "water" && t.terrain !== "mountain" && e.cells.some((e) => z(t, e) && (e.x >= 0 && e.x <= 4 && Number.isInteger(e.y) || e.terrain === t.terrain)));
}
function Ve(e, t, n, r = !1) {
	let i = Re(n.tile, n.side, n.x, n.y), a = n.tile === "district" ? e.districtPrices : e.plotPrices;
	return !a.length || !Be(t, i, n.tile) || !r && !xe(t, { coin: a[0] }) ? !1 : (a.shift(), t.cells.push(...i), n.tile === "district" ? t.districts++ : t.plots++, G(e, "land", n.tile), !0);
}
function He(e, t, n) {
	let r = b[n.building], i = t.cells.find((e) => e.key === n.cell);
	return !t.settlements.includes(n.building) || !i || !q(t, n.building, i) || !Ce(t, {}, n.food, n.energy, {}, r.food ?? 0, r.energy ?? 0, 0) ? !1 : (i.building = n.building, t.settlements.splice(t.settlements.indexOf(n.building), 1), G(e, "settle", n.building), !0);
}
function Ue(e, t) {
	if (t.mode === "market") return e.market.map((e) => ({
		owner: "",
		cell: e,
		source: e
	}));
	let n = F(e).find((e) => e.rid === t.owner)?.cells.find((e) => e.key === t.cell);
	return F(e).flatMap((e) => e.cells.filter((r) => r.building && !r.building.startsWith("S") && (t.mode === "prior" ? B(r).some((e) => e.index === 0) : t.mode === "occupied" ? B(r).length > 0 : e.rid === t.owner && !B(r).length && n && z(n, r))).map((t) => ({
		owner: e.rid,
		cell: t.key,
		source: t.building
	}))).filter((t) => !e.used.includes(t.source) || ![
		"F09",
		"I10",
		"G26",
		"F30",
		"G34"
	].includes(t.source));
}
function We(e, t, n, r) {
	let i = (...t) => (e.tasks.shift(), e.tasks.unshift(...t), Pe(e), !0), a = (e, t = {}) => N(e, n.source, n.owner, n.cell, {
		path: n.path,
		...t
	});
	if (n.kind === "production") return !r.output || !n.goods.includes(r.output) || !Ie(e, t, r.output, r.marker) ? !1 : i();
	if (n.kind === "swap") {
		let [t, n] = r.swap;
		return !t || !n || t === n || !(t in e.wheel) || !(n in e.wheel) || e.wheel[t] < 0 || e.wheel[n] < 0 ? !1 : ([e.wheel[t], e.wheel[n]] = [e.wheel[n], e.wheel[t]], i());
	}
	if (n.kind === "prior") {
		let r = t.cells.find((e) => e.key === n.cell);
		return !r?.building || r.clergy || !V(e, t.rid).includes(0) ? !1 : (r.clergy = {
			owner: t.rid,
			index: 0
		}, e.tasks.shift(), Fe(e, r.building, t.rid, r.key, n.path));
	}
	if (n.kind === "copy") {
		let t = Ue(e, n).find((e) => e.owner === r.owner && e.cell === r.target);
		return t ? (e.tasks.shift(), Fe(e, t.source, t.owner, t.cell, n.path)) : !1;
	}
	if (n.kind === "build") return e.tasks.shift(), Le(e, t, r.target, r.cells[0] ?? "") ? (Pe(e), !0) : !1;
	if (n.kind === "points") return E.some((e) => (r.inputs[e] ?? 0) > 0 && ![
		"book",
		"ceramic",
		"ornament",
		"reliquary"
	].includes(e)) || R(r.inputs, C) > n.amount ? !1 : (W(t, r.inputs), i());
	if (n.kind === "wonder") return e.wonderCount >= 8 || r.option !== 0 && (!e.config.wonders || !e.wonderSupply.includes(r.option)) ? !1 : (t.wonders.push(r.option), e.wonderSupply = e.wonderSupply.filter((e) => e !== r.option), e.wonderCount++, G(e, "wonder", "", r.option), i());
	if (n.kind === "clear") {
		let o = r.cells.map((e) => t.cells.find((t) => t.key === e));
		if (new Set(r.cells).size !== r.cells.length || o.length > n.limit || o.some((e) => !e || e.cover !== (n.mode === "peat" ? "moor" : "forest"))) return !1;
		for (let e of o) e && (e.cover = null);
		if (n.mode === "printing") W(t, { book: o.length });
		else if (n.mode === "carpentry" && o.length) return i(a("build"));
		else if (n.mode === "forestHut" && o.length) W(t, {
			livestock: 2,
			wood: 2,
			stone: 1
		});
		else if (o.length && !Ie(e, t, n.mode === "peat" ? "peat" : "wood", r.marker)) return !1;
		return i();
	}
	if (n.kind === "neutral") {
		let t = e.neutral, n = t.cells.find((e) => e.key === r.cells[0]);
		return !e.market.includes(r.target) || !n || !q(t, r.target, n, !0) ? !1 : (n.building = r.target, e.market.splice(e.market.indexOf(r.target), 1), e.neutralNew.push(n.key), G(e, "neutral", r.target), e.market.length ? !0 : i(a("neutralUse")));
	}
	if (n.kind === "neutralUse") {
		let n = e.neutral.cells.find((e) => e.key === r.target);
		return !n?.building || !e.neutralNew.includes(n.key) || n.clergy || !V(e, "$neutral").includes(0) || !xe(t, { coin: ge(e) }) ? !1 : (n.clergy = {
			owner: pe,
			index: 0
		}, e.tasks.shift(), Fe(e, n.building, pe, n.key));
	}
	if (n.kind !== "trade") return !1;
	let o = n.recipes[r.option];
	if (!o || r.count < 1 || r.count > n.limit) return !1;
	let s = r.count;
	if (!Ce(t, n.mode === "forge" ? { coin: 5 + (s - 1) * 10 } : ye(o.cost, s), r.food, r.energy, r.points, o.food * s, o.energy * s, o.points * s)) return !1;
	if (n.different) {
		let e = E.filter((e) => (r.inputs[e] ?? 0) > 0);
		if (e.length !== n.different || e.some((e) => r.inputs[e] !== 1) || !be(t, r.inputs)) return !1;
	}
	switch (W(t, o.gain, s), n.mode) {
		case "basic":
			if (!r.output || !D.includes(r.output)) return !1;
			W(t, { [r.output]: n.amount });
			break;
		case "twoBasic":
			if (!r.output || !r.secondary || r.output === r.secondary || !D.includes(r.output) || !D.includes(r.secondary)) return !1;
			W(t, {
				[r.output]: 5,
				[r.secondary]: 3
			});
			break;
		case "livestock": {
			let e = t.stock.livestock ?? 0;
			W(t, { coin: e >= 9 ? 8 : e >= 5 ? 5 : e >= 1 ? 3 : 0 });
			break;
		}
		case "bathhouse": {
			K(e, t.rid, !1, !0);
			let r = F(e).find((e) => e.rid === n.owner)?.cells.find((e) => e.key === n.cell);
			r && (r.clergy = null, r.bonusClergy = []);
			break;
		}
		case "locutory": return K(e, t.rid, !0), i(a("build"));
		case "occupied": return i(a("copy", { mode: "occupied" }));
		case "wonder": return i(a("wonder"));
		case "calefactory": return i(a("clear", { mode: "wood" }), a("clear", { mode: "peat" }));
		case "shipping": return i(a("production", {
			goods: [
				"meat",
				"bread",
				"wine"
			],
			mode: "jokerOnly"
		}));
		case "cooperage": return i(a("production", {
			goods: ["beer", "whiskey"],
			mode: "jokerOnly"
		}));
		case "forge":
			W(t, { reliquary: s });
			break;
		case "bulwark": return i(a("land", { mode: "district" }), a("land", { mode: "plot" }));
		case "festival": return i(a("points", { amount: t.cells.filter((e) => e.cover).length }));
		case "brotherhood": return i(a("points", { amount: t.cells.filter((e) => e.building && b[e.building].cloister).length * (e.players.length === 1 ? 1 : e.config.length === "long" ? 1.5 : 2) }));
		case "repeat": if (n.limit > s) return i({
			...n,
			limit: n.limit - s
		});
	}
	return G(e, "trade", n.source, s, ye(o.gain, s)), i();
}
function Ge(e, t, n) {
	if (e.phase === "done" || n.by !== H(e)) return U();
	let r = structuredClone(e), i = I(r, r.turn), a = t, o = !1;
	if (a.type === "exchange" && r.phase !== "contract") {
		let e = {
			grain: "straw",
			coin: "coin5",
			coin5: "coin",
			wine: "coin",
			whiskey: "coin"
		};
		o = be(i, { [a.from]: a.from === "coin" ? a.count * 5 : a.count }), o && (W(i, { [e[a.from]]: a.count * (a.from === "coin5" ? 5 : a.from === "whiskey" ? 2 : 1) }), G(r, "exchange", a.from, a.count));
	} else if (a.type === "contract" && r.phase === "contract" && r.contract) {
		let e = r.contract, t = I(r, e.owner), n = t.cells.find((t) => t.key === e.cell);
		V(r, t.rid).includes(a.clergy) && !n.clergy && (n.clergy = {
			owner: t.rid,
			index: a.clergy
		}, r.contract = null, r.turn = e.actor, r.phase = "effect", o = Fe(r, n.building, t.rid, n.key));
	} else if (a.type === "resolve" && r.phase === "effect" && r.tasks[0]) {
		let e = r.tasks[0];
		if (e.kind === "production" && e.mode === "jokerOnly" && a.marker !== "joker") return U();
		o = We(r, i, e, a);
	} else if (a.type === "skip" && r.phase === "effect" && r.tasks[0]?.kind !== "neutral") r.tasks.shift(), Pe(r), o = !0;
	else if (a.type === "land") {
		let e = r.phase === "effect" ? r.tasks[0] : null, t = e?.kind === "land", n = r.config.length === "long" && r.phase === "action";
		(t && (!e.mode || e.mode === a.tile) || (r.phase === "settlement" || r.phase === "action") && (n ? r.chainLand === 0 || r.chainActions > 1 && r.chainFirstLand && r.chainLand < 2 : r.landBought < 1)) && Ve(r, i, a, t) && (o = !0, t ? (e.limit > 1 ? e.limit-- : r.tasks.shift(), Pe(r)) : (r.landBought++, r.chainLand++, r.chainActions === 1 && (r.chainFirstLand = !0)));
	} else if (a.type === "settle" && (r.phase === "settlement" && !r.consumed || r.phase === "effect" && r.tasks[0]?.kind === "settlement")) o = He(r, i, a), o && (r.phase === "settlement" ? r.consumed = !0 : (r.tasks.shift(), Pe(r)));
	else if (a.type === "end") r.phase === "settlement" ? (Me(r), o = !0) : r.phase === "action" && r.consumed && (Ne(r), o = !0);
	else if (r.phase === "action" && !r.consumed) {
		if (r.afterTasks = "action", a.type === "harvest" && !r.bonus) {
			let e = i.cells.find((e) => e.key === a.cell), t = a.marker === "peat" ? "peat" : a.marker === "wood" ? "wood" : e?.cover === "moor" ? "peat" : "wood";
			e?.cover && (e.cover === "forest" ? t === "wood" : t === "peat") ? (e.cover = null, o = Ie(r, i, t, a.marker)) : !a.cell && !i.cells.some((e) => e.cover === (t === "wood" ? "forest" : "moor")) && (o = !0);
		} else if (a.type === "build") o = Le(r, i, a.building, a.cell);
		else if (a.type === "use") {
			let e = F(r).find((e) => e.rid === a.owner), t = e?.cells.find((e) => e.key === a.cell);
			if (t?.building && !t.building.startsWith("S") && (!t.clergy || r.bonus)) {
				if (r.bonus && V(r, i.rid).includes(0)) t.bonusClergy.push({
					owner: i.rid,
					index: 0
				}), o = Fe(r, t.building, e.rid, t.key);
				else if (e.rid === i.rid && V(r, i.rid).includes(a.clergy)) t.clergy = {
					owner: i.rid,
					index: a.clergy
				}, o = Fe(r, t.building, i.rid, t.key);
				else if (e.rid !== i.rid && V(r, e.rid).length) {
					let n = ge(r);
					if (o = a.gift === "coin" ? xe(i, { coin: n }) : be(i, { [a.gift]: 1 }), o) {
						if (a.gift === "coin" && e.rid !== "$neutral" && W(e, { coin: n }), e.rid === "$neutral") {
							if (!V(r, "$neutral").includes(a.clergy)) return U();
							t.clergy = {
								owner: pe,
								index: a.clergy
							}, o = Fe(r, t.building, pe, t.key);
						} else r.contract = {
							owner: e.rid,
							cell: t.key,
							actor: i.rid
						}, r.phase = "contract";
					}
				}
			}
		}
		o && (r.consumed = !0, r.tasks.length && (r.phase = "effect"));
	}
	return o ? {
		state: r,
		fx: Ke(e, r, a, n.by)
	} : U();
}
function Ke(e, t, n, r) {
	let i = [], a = [], o = [], s = [];
	for (let n of F(t)) {
		let t = I(e, n.rid);
		for (let e of n.cells) {
			let r = t.cells.find((t) => t.key === e.key);
			(!r || e.building !== r.building && e.building) && i.push({
				rid: n.rid,
				cell: e
			}), r?.cover && !e.cover && a.push({
				rid: n.rid,
				cell: r
			});
			for (let t of B(e)) (!r || !B(r).some((e) => e.owner === t.owner && e.index === t.index)) && o.push({
				rid: n.rid,
				cell: e.key,
				...t,
				returning: !1
			});
			for (let t of r ? B(r) : []) B(e).some((e) => e.owner === t.owner && e.index === t.index) || o.push({
				rid: n.rid,
				cell: e.key,
				...t,
				returning: !0
			});
		}
		for (let e of E) {
			let r = (n.stock[e] ?? 0) - (t.stock[e] ?? 0);
			r && s.push({
				rid: n.rid,
				good: e,
				delta: r
			});
		}
	}
	if (!i.length && !a.length && !o.length && !s.length) return [];
	let c = e.tasks[0];
	return [{
		kind: "ora-change",
		rid: r,
		data: {
			placed: i,
			removed: a,
			clergy: o,
			goods: s,
			source: n.type === "harvest" ? `cell:${r}:${n.cell}` : n.type === "exchange" ? `good:${r}:${n.from}` : c?.kind === "production" ? "wheel" : c?.cell ? `cell:${c.owner}:${c.cell}` : `seat:${r}`
		}
	}];
}
var qe = (e, t) => (b[t.building]?.dwelling ?? 0) + e.cells.filter((e) => z(t, e)).reduce((e, t) => e + (t.building ? b[t.building].dwelling : t.terrain === "water" ? 3 : 0), 0);
function Je(e, t, n) {
	if (!n) return e.config.wonders ? 20 : 30;
	let r = t.cells.filter((e) => e.building), i = r.filter((e) => e.building.startsWith("S")), a = r.filter((e) => b[e.building].cloister), o = (e) => r.reduce((t, n) => t + (b[n.building].cost[e] ?? 0), 0), s = (e) => t.stock[e] ?? 0, c = t.cells.filter((e) => !e.building && !e.cover).length;
	switch (n) {
		case 1: return 20 + r.length - i.length - a.length;
		case 2: return 12 + 3 * a.length;
		case 3: return 20 + 2 * o("straw");
		case 4: return 20 + 2 * Math.floor(L(t.stock) / 5);
		case 5: return 20 + 4 * s("meat");
		case 6: return 20 + s("beer") + s("whiskey");
		case 7: return 3 * r.filter((e) => b[e.building].dwelling >= 5).length;
		case 8: return 42 - 3 * t.cells.filter((e) => !e.building && !e.cover && i.some((t) => z(e, t))).length;
		case 9: return 15 + [
			"wood",
			"clay",
			"stone",
			"straw"
		].reduce((e, t) => e + s(t), 0);
		case 10: return 15 + R(t.stock, x) / 2;
		case 11: return 5 + Math.max(0, ...i.map((e) => qe(t, e)));
		case 12: return 20 + s("peat") + s("peatcoal");
		case 13: return 10 + Math.max(0, ...a.map((e) => qe(t, e)));
		case 14: return 36 - 2 * c;
		case 15: return 18 + o("clay");
		case 16: return [
			"wood",
			"clay",
			"stone",
			"straw"
		].reduce((e, t) => e + o(t), 0) * (e.config.length === "long" ? .5 : 1);
		case 17: return 6 + 4 * i.length;
		case 18: return 18 + o("wood");
		case 19: return 25 + Math.min(s("book"), s("ceramic"));
		case 20: return 20 + 2 * Math.min(s("livestock"), s("grain"));
		case 21: return 28 + s("ornament");
		case 22: return 12 + 2 * o("stone");
		case 23: return 25 + 2 * s("reliquary");
		case 24: return 6 + 4 * (t.districts + 1);
		case 25: return 45 - (e.config.length === "long" ? 1.5 : 3) * (t.districts + 1);
		case 26: return 60 - (e.config.length === "long" ? 1 : 2) * (r.length - i.length);
		default: return 0;
	}
}
function Ye(e, t) {
	let n = (e) => t.wonders.includes(e), r = t.stock.wine ?? 0, i = t.stock.whiskey ?? 0, a = t.stock.grain ?? 0, o = (e) => [...new Set(Array.from({ length: 5 }, (t, n) => [Math.min(e, n), Math.max(0, e - n)]).flat())], s = 0, c = 0, l = 0, u = -Infinity, d = -Infinity;
	for (let e of o(r)) for (let r of o(i)) {
		let i = -e - r - (n(6) ? r : 0) + Math.floor((L(t.stock) + e + 2 * r) / 5) * (n(4) ? 4 : 2);
		i > u && (u = i, s = e, c = r);
	}
	for (let e of /* @__PURE__ */ new Set([
		0,
		a,
		Math.max(0, a - (t.stock.livestock ?? 0))
	])) {
		let r = (n(9) ? e : 0) - (n(10) ? e / 2 : 0) + (n(20) ? 2 * Math.min(t.stock.livestock ?? 0, a - e) : 0);
		r > d && (d = r, l = e);
	}
	let f = {
		...t,
		stock: {
			...t.stock,
			wine: r - s,
			whiskey: i - c,
			grain: a - l,
			straw: (t.stock.straw ?? 0) + l,
			coin: (t.stock.coin ?? 0) + s + 2 * c
		}
	}, p = R(f.stock, C) - (f.stock.coin5 ?? 0) * 2 + Math.floor(L(f.stock) / 5) * 2, m = t.wonders.reduce((t, n) => t + Je(e, f, n), 0), h = t.cells.reduce((e, t) => e + (t.building ? b[t.building].economic : 0), 0), g = t.cells.filter((e) => e.building?.startsWith("S")), _ = 3 * g.reduce((e, n) => e + t.cells.filter((e) => e.terrain === "water" && !e.building && z(n, e)).length, 0), v = g.reduce((e, n) => e + qe(t, n), 0) - _;
	return {
		goods: p,
		economic: h,
		dwelling: v,
		water: _,
		wonders: m,
		total: p + h + v + _ + m
	};
}
var Xe = {
	saveCompatibility: { version: "1" },
	meta: y,
	schemas: {
		action: de,
		config: ae,
		publicView: j,
		privateView: le
	},
	setup: Ee,
	reduce: Ge,
	viewFor: (e) => ({
		public: e,
		private: {}
	}),
	status(e) {
		let t = Object.fromEntries(e.players.map((t) => [t.rid, Ye(e, t).total]));
		if (e.phase !== "done") return {
			phase: e.phase,
			scores: t
		};
		let n = e.players.map((e) => e.rid).sort((e, n) => t[n] - t[e]);
		return {
			phase: "done",
			scores: t,
			ranking: n,
			winner: e.players.length === 1 ? t[n[0]] >= 500 ? n : [] : n.filter((e) => t[e] === t[n[0]])
		};
	}
}, J = {
	name: "games.oraetlabora.name",
	desc: "games.oraetlabora.desc",
	invalid: "games.oraetlabora.invalid",
	round: "games.oraetlabora.round",
	stage: "games.oraetlabora.stage",
	turn: "games.oraetlabora.turn",
	action: "games.oraetlabora.action",
	effect: "games.oraetlabora.effect",
	settlement: "games.oraetlabora.settlement",
	contract: "games.oraetlabora.contract",
	done: "games.oraetlabora.done",
	market: "games.oraetlabora.market",
	estate: "games.oraetlabora.estate",
	settlements: "games.oraetlabora.settlements",
	resources: "games.oraetlabora.resources",
	production: "games.oraetlabora.production",
	land: "games.oraetlabora.land",
	district: "games.oraetlabora.district",
	plot: "games.oraetlabora.plot",
	side: "games.oraetlabora.side",
	prior: "games.oraetlabora.prior",
	lay: "games.oraetlabora.lay",
	clergy: "games.oraetlabora.clergy",
	available: "games.oraetlabora.available",
	occupied: "games.oraetlabora.occupied",
	use: "games.oraetlabora.use",
	build: "games.oraetlabora.build",
	harvest: "games.oraetlabora.harvest",
	fell: "games.oraetlabora.fell",
	cut: "games.oraetlabora.cut",
	joker: "games.oraetlabora.joker",
	exchange: "games.oraetlabora.exchange",
	end: "games.oraetlabora.end",
	endSettlement: "games.oraetlabora.endSettlement",
	skip: "games.oraetlabora.skip",
	confirm: "games.oraetlabora.confirm",
	cancel: "games.oraetlabora.cancel",
	back: "games.oraetlabora.back",
	close: "games.oraetlabora.close",
	details: "games.oraetlabora.details",
	cost: "games.oraetlabora.cost",
	economic: "games.oraetlabora.economic",
	dwelling: "games.oraetlabora.dwelling",
	food: "games.oraetlabora.food",
	energy: "games.oraetlabora.energy",
	points: "games.oraetlabora.points",
	payment: "games.oraetlabora.payment",
	inputs: "games.oraetlabora.inputs",
	gain: "games.oraetlabora.gain",
	count: "games.oraetlabora.count",
	output: "games.oraetlabora.output",
	secondary: "games.oraetlabora.secondary",
	marker: "games.oraetlabora.marker",
	swap: "games.oraetlabora.swap",
	neutral: "games.oraetlabora.neutral",
	neutralBuild: "games.oraetlabora.neutralBuild",
	neutralUse: "games.oraetlabora.neutralUse",
	chooseSite: "games.oraetlabora.chooseSite",
	chooseBuilding: "games.oraetlabora.chooseBuilding",
	chooseClergy: "games.oraetlabora.chooseClergy",
	chooseTarget: "games.oraetlabora.chooseTarget",
	contractGift: "games.oraetlabora.contractGift",
	coinGift: "games.oraetlabora.coinGift",
	wineGift: "games.oraetlabora.wineGift",
	whiskeyGift: "games.oraetlabora.whiskeyGift",
	repeat: "games.oraetlabora.repeat",
	different: "games.oraetlabora.different",
	autoPayment: "games.oraetlabora.autoPayment",
	waiting: "games.oraetlabora.waiting",
	total: "games.oraetlabora.total",
	goodsScore: "games.oraetlabora.goodsScore",
	economicScore: "games.oraetlabora.economicScore",
	dwellingScore: "games.oraetlabora.dwellingScore",
	waterScore: "games.oraetlabora.waterScore",
	wondersScore: "games.oraetlabora.wondersScore",
	wonder: "games.oraetlabora.wonder",
	wonderNumber: "games.oraetlabora.wonderNumber",
	baseWonder: "games.oraetlabora.baseWonder",
	result: "games.oraetlabora.result",
	review: "games.oraetlabora.review",
	winner: "games.oraetlabora.winner",
	soloWin: "games.oraetlabora.soloWin",
	soloLoss: "games.oraetlabora.soloLoss",
	soloGoal: "games.oraetlabora.soloGoal",
	again: "games.oraetlabora.again",
	lobby: "games.oraetlabora.lobby",
	log: "games.oraetlabora.log",
	country: "games.oraetlabora.country",
	france: "games.oraetlabora.france",
	ireland: "games.oraetlabora.ireland",
	length: "games.oraetlabora.length",
	normal: "games.oraetlabora.normal",
	short: "games.oraetlabora.short",
	long: "games.oraetlabora.long",
	expansions: "games.oraetlabora.expansions",
	loamy: "games.oraetlabora.loamy",
	wonders: "games.oraetlabora.wonders",
	on: "games.oraetlabora.on",
	off: "games.oraetlabora.off",
	rules: "games.oraetlabora.rules",
	once: "games.oraetlabora.once"
}, Y = {
	wood: "games.oraetlabora.goods.wood",
	clay: "games.oraetlabora.goods.clay",
	peat: "games.oraetlabora.goods.peat",
	grain: "games.oraetlabora.goods.grain",
	livestock: "games.oraetlabora.goods.livestock",
	coin: "games.oraetlabora.goods.coin",
	coin5: "games.oraetlabora.goods.coin5",
	straw: "games.oraetlabora.goods.straw",
	stone: "games.oraetlabora.goods.stone",
	peatcoal: "games.oraetlabora.goods.peatcoal",
	meat: "games.oraetlabora.goods.meat",
	flour: "games.oraetlabora.goods.flour",
	bread: "games.oraetlabora.goods.bread",
	grapes: "games.oraetlabora.goods.grapes",
	wine: "games.oraetlabora.goods.wine",
	malt: "games.oraetlabora.goods.malt",
	beer: "games.oraetlabora.goods.beer",
	whiskey: "games.oraetlabora.goods.whiskey",
	book: "games.oraetlabora.goods.book",
	ceramic: "games.oraetlabora.goods.ceramic",
	ornament: "games.oraetlabora.goods.ornament",
	reliquary: "games.oraetlabora.goods.reliquary"
}, Ze = {
	plains: "games.oraetlabora.terrain.plains",
	hillside: "games.oraetlabora.terrain.hillside",
	coast: "games.oraetlabora.terrain.coast",
	water: "games.oraetlabora.terrain.water",
	mountain: "games.oraetlabora.terrain.mountain"
}, Qe = {
	forest: "games.oraetlabora.cover.forest",
	moor: "games.oraetlabora.cover.moor"
}, $e = {
	prior: "games.oraetlabora.special.prior",
	basic: "games.oraetlabora.special.basic",
	livestock: "games.oraetlabora.special.livestock",
	adjacent: "games.oraetlabora.special.adjacent",
	carpentry: "games.oraetlabora.special.carpentry",
	twoBasic: "games.oraetlabora.special.twoBasic",
	bathhouse: "games.oraetlabora.special.bathhouse",
	locutory: "games.oraetlabora.special.locutory",
	occupied: "games.oraetlabora.special.occupied",
	wonder: "games.oraetlabora.special.wonder",
	forestHut: "games.oraetlabora.special.forestHut",
	calefactory: "games.oraetlabora.special.calefactory",
	shipping: "games.oraetlabora.special.shipping",
	cooperage: "games.oraetlabora.special.cooperage",
	forge: "games.oraetlabora.special.forge",
	bulwark: "games.oraetlabora.special.bulwark",
	printing: "games.oraetlabora.special.printing",
	festival: "games.oraetlabora.special.festival",
	brotherhood: "games.oraetlabora.special.brotherhood",
	market: "games.oraetlabora.special.market",
	settlement: "games.oraetlabora.special.settlement",
	swap: "games.oraetlabora.special.swap",
	production: "games.oraetlabora.special.production"
}, et = {
	wood: "#895331",
	clay: "#e3543c",
	peat: "#99855b",
	grain: "#f4db46",
	livestock: "#48a750",
	coin: "#dadcc8",
	coin5: "#9bbaa8",
	straw: "#f4d333",
	stone: "#383e38",
	peatcoal: "#353c38",
	meat: "#4fa643",
	flour: "#eee0a6",
	bread: "#d1ab73",
	grapes: "#b75b9d",
	wine: "#b75b9d",
	malt: "#f1d442",
	beer: "#dfad32",
	whiskey: "#a79461",
	book: "#e99b32",
	ceramic: "#e16d3c",
	ornament: "#be443d",
	reliquary: "#bf4c3a"
}, X = "#52422c", tt = (e, t, n, r) => /* @__PURE__ */ p("g", { children: [
	/* @__PURE__ */ f("ellipse", {
		cx: e + 1,
		cy: t + 2,
		rx: n,
		ry: n,
		fill: "#a76a25"
	}),
	/* @__PURE__ */ f("circle", {
		cx: e,
		cy: t,
		r: n,
		fill: "#efc95d",
		stroke: "#a97b2a",
		strokeWidth: "1.3"
	}),
	/* @__PURE__ */ f("circle", {
		cx: e,
		cy: t,
		r: n - 3,
		fill: "none",
		stroke: "#fff0a0",
		strokeDasharray: "1 2"
	}),
	/* @__PURE__ */ f("circle", {
		cx: e,
		cy: t,
		r: n - 5,
		fill: "none",
		stroke: "#b98a30"
	}),
	r && /* @__PURE__ */ f("text", {
		x: e,
		y: t + n * .4,
		textAnchor: "middle",
		fontFamily: "Georgia,serif",
		fontWeight: "bold",
		fontSize: n * 1.15,
		fill: "#9c732e",
		children: r
	})
] });
function nt({ malt: e = !1 }) {
	return /* @__PURE__ */ p("g", {
		transform: e ? "translate(8 6) scale(.8)" : void 0,
		fill: "#cba52f",
		stroke: "#78602a",
		strokeWidth: "1.2",
		children: [/* @__PURE__ */ f("path", {
			d: "M12 58Q24 31 52 9M20 42 19 24M29 33 33 13M40 23 52 4",
			fill: "none"
		}), Array.from({ length: 7 }, (e, t) => /* @__PURE__ */ p("g", {
			transform: `translate(${19 + t * 4.5} ${44 - t * 4.7}) rotate(42)`,
			children: [/* @__PURE__ */ f("path", {
				d: "M0 0Q-12-6-7-15Q2-11 0 0Z",
				fill: "#eed45c"
			}), /* @__PURE__ */ f("path", {
				d: "M1 0Q13-5 10-14Q1-12 1 0Z",
				fill: "#b69328"
			})]
		}, t))]
	});
}
var rt = {
	wood: /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "1.5",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m15 27 31-19q10-2 11 8L29 45Z",
				fill: "#af7d42"
			}),
			/* @__PURE__ */ f("path", {
				d: "m13 35 34-19q13 3 8 12L25 51Z",
				fill: "#89562e"
			}),
			/* @__PURE__ */ f("path", {
				d: "m11 38 30-18 9 16-28 18Z",
				fill: "#a6743c"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "16",
				cy: "46",
				rx: "9",
				ry: "12",
				transform: "rotate(-28 16 46)",
				fill: "#e3c994"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 38q-6 8 2 17m1-17q-3 6 4 12M31 32l12-7M30 37l15-9",
				fill: "none",
				stroke: "#62462c"
			})
		]
	}),
	clay: /* @__PURE__ */ p("g", {
		stroke: "#81512b",
		strokeWidth: "1.3",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m8 29 18-7 18 9-1 18-19 7L8 46Z",
				fill: "#be8433"
			}),
			/* @__PURE__ */ f("path", {
				d: "m18 12 20-4 18 10-21 5Z",
				fill: "#e7b74c"
			}),
			/* @__PURE__ */ f("path", {
				d: "m18 12 17 11v20L18 33Z",
				fill: "#d6a03b"
			}),
			/* @__PURE__ */ f("path", {
				d: "m35 23 21-5v21l-21 4Z",
				fill: "#8f602a"
			}),
			/* @__PURE__ */ f("path", {
				d: "m25 38 19-6 14 9-19 7Z",
				fill: "#d7a13e"
			}),
			/* @__PURE__ */ f("path", {
				d: "m25 38 14 10v13l-14-9Z",
				fill: "#b8792b"
			}),
			/* @__PURE__ */ f("path", {
				d: "m39 48 19-7v13l-19 7Z",
				fill: "#8c5929"
			})
		]
	}),
	peat: /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "1.3",
		children: [
			[
				[6, 30],
				[7, 39],
				[13, 48],
				[29, 21]
			].map(([e, t], n) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("path", {
				d: `m${e} ${t} 22-4 10 5-25 4Z`,
				fill: "#b69c70"
			}), /* @__PURE__ */ f("path", {
				d: `m${e} ${t} 7 5 25-4v9l-25 4-7-5Z`,
				fill: "#93774e"
			})] }, n)),
			/* @__PURE__ */ f("path", {
				d: "m31 9 11-2 7 5-10 40-14 3Z",
				fill: "#b59a6d"
			}),
			/* @__PURE__ */ f("path", {
				d: "m42 7 7 5-10 40-7 2Z",
				fill: "#857052"
			}),
			/* @__PURE__ */ f("path", {
				d: "m33 18 11 1m-15 10 12 1m-15 10 12 1",
				stroke: "#7a6548"
			})
		]
	}),
	grain: /* @__PURE__ */ f(nt, {}),
	livestock: /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "1.2",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m15 39-3 16 5 1 4-15m17-3 1 16 5 1-1-17",
				fill: "#c6b796"
			}),
			/* @__PURE__ */ f("path", {
				d: "M11 19q-7 6-4 16-6 8 1 9 3 0 5-5 5 8 13 5 9 3 14-5 10-2 12-14l-8-7q-5-4-10-1-4-5-10-2-7-3-13 4Z",
				fill: "#f0e5c4"
			}),
			/* @__PURE__ */ f("path", {
				d: "M43 17q3-8 11-4l5 8-7 7-8-4-3-5Z",
				fill: "#d8c5a0"
			}),
			/* @__PURE__ */ f("path", {
				d: "m49 17 7 3-3 7-7-3Z",
				fill: "#746449"
			}),
			/* @__PURE__ */ f("path", {
				d: "m44 17-7-2 3 6m15-4 6-1-3 6",
				fill: "#e7dab8"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "51",
				cy: "18",
				r: "1",
				fill: "#352e25"
			}),
			/* @__PURE__ */ f("path", {
				d: "m13 55 6 1m20-1 6 1M18 24q-5 7 0 10m13-12q-4 9 1 12",
				fill: "none"
			})
		]
	}),
	coin: tt(31, 33, 23, 1),
	coin5: /* @__PURE__ */ p("g", { children: [
		tt(25, 14, 12),
		tt(23, 22, 13),
		tt(27, 31, 14),
		tt(33, 41, 16),
		tt(37, 47, 15, 5)
	] }),
	straw: /* @__PURE__ */ p("g", {
		stroke: "#8a6d29",
		strokeWidth: "1.1",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M17 9Q32 3 47 9L39 30 48 56Q32 64 16 56l9-26Z",
				fill: "#edcd57"
			}),
			[
				20,
				25,
				30,
				35,
				40,
				45
			].map((e, t) => /* @__PURE__ */ f("path", {
				d: `M${e} 10Q${26 + t * 2} 28 ${e - 2} 56`,
				fill: "none",
				stroke: t % 2 ? "#fff1a0" : "#b59a39"
			}, e)),
			/* @__PURE__ */ f("path", {
				d: "M23 29q10 4 19 0v6q-10 4-19 0Z",
				fill: "#766c35"
			}),
			/* @__PURE__ */ f("path", {
				d: "m25 30 15 4m-15 0 14-3",
				stroke: "#cdb65a"
			})
		]
	}),
	stone: /* @__PURE__ */ p("g", {
		stroke: "#6c7367",
		strokeWidth: "1",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m18 22 20-17 13 21-5 29-17 5-14-24Z",
				fill: "#b5bbae"
			}),
			/* @__PURE__ */ f("path", {
				d: "m38 5-5 28 13 22 5-29Z",
				fill: "#88918a"
			}),
			/* @__PURE__ */ f("path", {
				d: "m18 22 15 11 5-28Z",
				fill: "#e1e2ce"
			}),
			/* @__PURE__ */ f("path", {
				d: "m15 36 14 24 4-27-15-11Z",
				fill: "#cbd0ba"
			})
		]
	}),
	peatcoal: /* @__PURE__ */ f("g", {
		stroke: "#55574b",
		strokeWidth: "1.2",
		children: [
			[
				16,
				34,
				14
			],
			[
				34,
				16,
				12
			],
			[
				46,
				39,
				11
			],
			[
				27,
				48,
				13
			],
			[
				33,
				32,
				12
			]
		].map(([e, t, n], r) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("path", {
			d: `M${e - n} ${t + 3} ${e - n / 2} ${t - n} ${e + n / 3} ${t - n - 3} ${e + n} ${t} ${e + 4} ${t + n} ${e - n / 2} ${t + n - 2}Z`,
			fill: [
				"#8a8c78",
				"#a0a18b",
				"#646a5d",
				"#7a806d",
				"#8a907e"
			][r]
		}), /* @__PURE__ */ f("path", {
			d: `M${e - n / 2} ${t - n} ${e} ${t - 2} ${e - n / 2} ${t + n - 2}`,
			fill: "#bdbaa0",
			stroke: "none"
		})] }, r))
	}),
	meat: /* @__PURE__ */ p("g", {
		stroke: "#a04c36",
		strokeWidth: "1.3",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M13 28Q17 13 43 10q13 2 9 18L39 47 16 49Z",
				fill: "#c98068"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 29q6-14 24-10l11 12-12 18-20-2Z",
				fill: "#9f3d42"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 31q15-14 28 3M28 20q-5 15 7 26",
				fill: "none",
				stroke: "#f0baa0",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M11 45q19-8 32 6 5 9-7 10l-22-1q-9-4-3-15Z",
				fill: "#d8937b"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 48q14-7 24 7-12 7-24 0Z",
				fill: "#a5444a"
			})
		]
	}),
	flour: /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "1.4",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M12 27q20-8 38 0l-4 27q-16 9-30 0Z",
				fill: "#b58d30"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "31",
				cy: "27",
				rx: "19",
				ry: "9",
				fill: "#f3d87e"
			}),
			/* @__PURE__ */ f("path", {
				d: "M20 28q11-9 24 1-12 7-24-1Z",
				fill: "#f7e7b3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M15 32q10 10 11 23m17-23-3 19M14 53l-4 6 8-1",
				fill: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "m14 10 14 19q4 6 9 0L19 6q-6-2-5 4Z",
				fill: "#957133"
			}),
			/* @__PURE__ */ f("path", {
				d: "m18 10 13 18",
				stroke: "#dcc068"
			})
		]
	}),
	bread: /* @__PURE__ */ p("g", {
		stroke: "#927039",
		strokeWidth: "1.2",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M8 44q5-23 28-30 15 0 12 15-6 19-30 25-14 1-10-10Z",
				fill: "#c28b42"
			}),
			/* @__PURE__ */ f("path", {
				d: "M12 41q11-21 29-24 3 11-14 26-14 10-15-2Z",
				fill: "#edc57b"
			}),
			/* @__PURE__ */ f("path", {
				d: "m22 28 9 8m-15 1 9 7m6-24 10 7",
				stroke: "#896333",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "M39 13q15-10 21 1 2 11-12 24-9-6-12-14Z",
				fill: "#dfb36b"
			}),
			/* @__PURE__ */ f("path", {
				d: "m41 17 16 5m-10-12 12 5",
				strokeWidth: "2"
			})
		]
	}),
	grapes: /* @__PURE__ */ p("g", {
		stroke: "#454635",
		strokeWidth: "1.2",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m30 18 7-13 3 1-5 15",
				fill: "#8c8651"
			}),
			/* @__PURE__ */ f("path", {
				d: "m29 17-13-8-3 8-9 4 9 7 15-4m6-8 15-8 3 9 9 3-11 9-15-7",
				fill: "#609a3a"
			}),
			/* @__PURE__ */ f("path", {
				d: "m11 20 16 1m11-2 14 0",
				fill: "none"
			}),
			[
				[26, 26],
				[36, 27],
				[21, 34],
				[31, 35],
				[41, 34],
				[25, 43],
				[35, 43],
				[29, 51],
				[30, 58]
			].map(([e, t], n) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("circle", {
				cx: e,
				cy: t,
				r: "6",
				fill: n % 2 ? "#796e9b" : "#5b577c"
			}), /* @__PURE__ */ f("circle", {
				cx: e - 1.5,
				cy: t - 2,
				r: "1.6",
				fill: "#bbb4cf",
				stroke: "none"
			})] }, n))
		]
	}),
	wine: /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "1.3",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m26 19-7 7-1 26q13 13 26 0L42 26l-7-7-1-11h-7Z",
				fill: "#ded09a"
			}),
			/* @__PURE__ */ f("path", {
				d: "M23 31q-13-15-16-2-1 8 11 10m24-8q12-14 15-4 3 9-13 14",
				fill: "none",
				stroke: "#9f8f56",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M22 33v18q5 8 15 3l2-22",
				fill: "#f1e0aa",
				stroke: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "m26 18 1-10 7 0 1 11",
				fill: "#73a44e"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "30.5",
				cy: "8",
				rx: "5",
				ry: "2.5",
				fill: "#d1c692"
			}),
			/* @__PURE__ */ f("path", {
				d: "m20 39 21 0m-21 6 21 0",
				stroke: "#b5a572"
			})
		]
	}),
	malt: /* @__PURE__ */ p("g", {
		stroke: "#8f722d",
		strokeWidth: "1.1",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M8 46q13-15 28-14l18 15-9 12H15Z",
				fill: "#cfad44"
			}),
			[
				0,
				1,
				2,
				3,
				4
			].map((e) => /* @__PURE__ */ f("path", {
				d: `m${17 + e * 7} 52q-8-8-4-15q8 2 8 12Z`,
				fill: "#efd475"
			}, e)),
			/* @__PURE__ */ f("path", {
				d: "m13 9 21 22-6 6L7 15q-1-7 6-6Z",
				fill: "#a87e31"
			}),
			/* @__PURE__ */ f("path", {
				d: "M24 27q16-7 21 3l-10 13Z",
				fill: "#e4c467"
			}),
			/* @__PURE__ */ f("path", {
				d: "m28 29 10 11",
				stroke: "#fff0a1"
			})
		]
	}),
	beer: /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "1.4",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M42 23q22-8 15 15-3 9-14 8",
				fill: "none",
				stroke: "#7c4b21",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 16q15-9 30 0l-1 38q-15 9-28 0Z",
				fill: "#bb7a24"
			}),
			/* @__PURE__ */ f("path", {
				d: "M18 20h7v34l-6-2Zm12 0h9v35l-9 2Z",
				fill: "#df9c2e",
				stroke: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 28q15 6 30 0m-30 9q15 6 30 0m-29 10q15 7 29 0",
				stroke: "#8e591f",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 17q-5-7 2-9 2-7 9-3 8-5 11 0 10-3 10 5 7 9-7 11-16 4-25-4Z",
				fill: "#f5e7b6",
				stroke: "#bba664"
			})
		]
	}),
	whiskey: /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "1.4",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M17 11q15-7 30 0 13 24 0 45-15 8-30 0-11-22 0-45Z",
				fill: "#94824b"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "32",
				cy: "12",
				rx: "16",
				ry: "6",
				fill: "#b3a165"
			}),
			/* @__PURE__ */ f("path", {
				d: "m22 10 22 5m-29 14q17 6 34 0m-35 17q18 6 36 0",
				fill: "none",
				stroke: "#564e32",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M24 20q-5 17 0 35m8-35v39m8-39q5 19 0 36",
				stroke: "#d1bd7e",
				fill: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "m20 12 24-2",
				stroke: "#5f5434"
			})
		]
	}),
	book: /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "1.4",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m10 14 25-7 22 21-4 22-28 9L9 40Z",
				fill: "#a9662c"
			}),
			/* @__PURE__ */ f("path", {
				d: "m24 39 29-9-2 17-28 9Z",
				fill: "#f3ddb0"
			}),
			/* @__PURE__ */ f("path", {
				d: "m11 14 14 21 32-8-22-20Z",
				fill: "#b98339"
			}),
			/* @__PURE__ */ f("path", {
				d: "m18 15 17-5 17 16-24 6Z",
				fill: "none",
				stroke: "#e1b65f"
			}),
			/* @__PURE__ */ f("path", {
				d: "M11 15q-7 14 12 38m-9-28q-1 8 10 17",
				fill: "none",
				stroke: "#e0b568",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "m29 35 10-3 1 15-8 3Z",
				fill: "#bd9247"
			}),
			/* @__PURE__ */ f("path", {
				d: "m28 54-1 7 8-3",
				fill: "none",
				stroke: "#aa442f",
				strokeWidth: "2"
			})
		]
	}),
	ceramic: /* @__PURE__ */ p("g", {
		stroke: "#8f502f",
		strokeWidth: "1.3",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M10 13q14-7 26 0l-3 12q5 25-5 30H15Q5 38 12 25Z",
				fill: "#dfab72"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "23",
				cy: "13",
				rx: "13",
				ry: "5",
				fill: "#f2ce97"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "23",
				cy: "13",
				rx: "10",
				ry: "2",
				fill: "#a9643d"
			}),
			/* @__PURE__ */ f("path", {
				d: "M39 26q-2-8 6-8 7 0 5 8 13 6 10 22-11 11-25 0-3-13 4-22Z",
				fill: "#ce955f"
			}),
			/* @__PURE__ */ f("path", {
				d: "M50 27q15-3 10 12",
				fill: "none",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M23 49q11-4 14 2l-2 10H24Z",
				fill: "#edbd86"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "30",
				cy: "50",
				rx: "7",
				ry: "3",
				fill: "#97603b"
			}),
			/* @__PURE__ */ f("path", {
				d: "m15 23-1 18m27-11-2 12",
				stroke: "#f2d6a3",
				strokeWidth: "3"
			})
		]
	}),
	ornament: /* @__PURE__ */ p("g", {
		transform: "rotate(35 32 32) translate(4 5) scale(.87)",
		stroke: "#4d4c42",
		strokeWidth: "1.1",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M3 28 8 18l4-2 5 9 7 3 7-5 8 3 5 5 11-4 10 7-9 5-12-2-8 4-12-4-8 1-8-5Z",
				fill: "#96998a"
			}),
			/* @__PURE__ */ f("path", {
				d: "m5 19 3-8 5 1 2 10m43 11 9 1-8 5",
				fill: "#c7cbb8"
			}),
			/* @__PURE__ */ f("path", {
				d: "M9 21Q0 24 4 35q6 12 18 3 10-9 0-17-9-7-15 1Z",
				fill: "#cbd0bd"
			}),
			/* @__PURE__ */ f("path", {
				d: "M28 24q-13 5-7 18 7 12 20 3 10-8 1-19-7-8-14-2Z",
				fill: "#cbd0bd"
			}),
			/* @__PURE__ */ f("path", {
				d: "M49 30q-12 4-7 16 7 11 19 3 8-9 0-16-6-7-12-3Z",
				fill: "#cbd0bd"
			}),
			/* @__PURE__ */ p("g", {
				fill: "none",
				strokeLinecap: "round",
				children: [
					/* @__PURE__ */ f("path", {
						d: "M8 22q-9 9 1 16 10 6 14-4 3-9-7-10-8-1-8 6 0 7 7 6 7-1 4-6-2-3-5 0m13-4q-11 9-2 17 10 9 17-2 5-10-6-14-10-3-11 5-1 9 8 8 7-1 5-6-1-4-5-1m15-1q-10 6-3 15 8 8 16-1 6-8-3-12-8-3-10 4-1 7 6 7 6 0 5-5-1-3-4-1",
						stroke: "#51574c",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ f("path", {
						d: "M7 23q-7 9 2 14m18-10q-8 8-1 15m22-8q-7 6-2 12M11 20q8-3 12 3m7 1q10-4 14 6m6-1q7-2 12 5",
						stroke: "#f0efda",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ f("path", {
						d: "m20 39 2 5m1-7 3 4m16 4 2 5m0-8 3 4M7 13l4 1m-5 2 6 1",
						stroke: "#747c6d",
						strokeWidth: "1.4"
					})
				]
			})
		]
	}),
	reliquary: /* @__PURE__ */ p("g", {
		stroke: "#78502b",
		strokeWidth: "1.3",
		children: [
			/* @__PURE__ */ f("path", {
				d: "m30 5 2-4 2 4h5v3h-5v4h-4V8h-5V5Z",
				fill: "#efd05c"
			}),
			/* @__PURE__ */ f("path", {
				d: "M31 10 52 21 46 43H18L12 21Z",
				fill: "#d39734"
			}),
			/* @__PURE__ */ f("path", {
				d: "m16 24 12-6v22H21Zm16-6 16 6-5 16H32Z",
				fill: "#9e4130"
			}),
			/* @__PURE__ */ f("path", {
				d: "m17 23 11-3m5 0 13 4M20 42h25M14 20h36",
				stroke: "#f8d881",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "m23 29 3 3-2 5-3-2m15-6 6 2-1 4-6-1",
				fill: "#e9e0bf"
			}),
			/* @__PURE__ */ f("path", {
				d: "m28 44 8 0-1 10 13 6H16l13-6Z",
				fill: "#e4b849"
			}),
			/* @__PURE__ */ f("path", {
				d: "m19 58 25 0",
				stroke: "#fae6a0"
			})
		]
	})
};
function it({ good: e }) {
	return /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("rect", {
		x: "1",
		y: "1",
		width: "62",
		height: "62",
		rx: "2",
		fill: et[e],
		stroke: "#77653e",
		strokeWidth: "1"
	}), rt[e]] });
}
function Z({ good: e }) {
	let t = o();
	return /* @__PURE__ */ f("svg", {
		className: "ora-good-icon",
		viewBox: "0 0 64 64",
		role: "img",
		"aria-label": t(Y[e]),
		children: /* @__PURE__ */ f(it, { good: e })
	});
}
function at({ kind: e }) {
	return e === "settlement" ? /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M3 27 17 12l14 15v29H3Z",
				fill: "#d4bc83"
			}),
			/* @__PURE__ */ f("path", {
				d: "m29 31 17-19 15 19v25H29Z",
				fill: "#b2ad75"
			}),
			/* @__PURE__ */ f("path", {
				d: "M1 27 17 8l17 19M27 32 46 8l17 24",
				fill: "none",
				stroke: "#a25331",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ f("path", {
				d: "M12 40h8v16h-8m30-16h8v16h-8",
				fill: "#79664a"
			})
		]
	}) : e === "swap" ? /* @__PURE__ */ p("g", {
		fill: "#8d713a",
		stroke: X,
		strokeWidth: "1",
		children: [/* @__PURE__ */ f("path", { d: "M6 17h37V7l16 17-16 16V30H6Z" }), /* @__PURE__ */ f("path", {
			d: "M58 47H21v10L5 40l16-16v10h37Z",
			fill: "#c4a451"
		})]
	}) : e === "food" ? /* @__PURE__ */ p("g", {
		fill: "#f1cf70",
		stroke: X,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ f("path", { d: "M6 27Q8 18 31 18t26 9v29H6Z" }),
			/* @__PURE__ */ f("path", {
				d: "M28 18V9q0-7 6-6",
				fill: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "M8 29q24 10 47 0",
				fill: "none"
			})
		]
	}) : e === "energy" ? /* @__PURE__ */ f("path", {
		d: "M30 3Q32 20 46 27q18 22-2 33Q13 70 9 46q-3-16 12-26-1 16 6 13 8-13 3-30Z",
		fill: "#efd14f",
		stroke: "#8b6c25",
		strokeWidth: "2"
	}) : e === "points" ? /* @__PURE__ */ f("path", {
		d: "M5 5h54v22Q56 50 32 60 8 50 5 27Z",
		fill: "#e8c557",
		stroke: X,
		strokeWidth: "2"
	}) : e === "wheel" ? /* @__PURE__ */ p("g", {
		fill: "#ead995",
		stroke: X,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ f("circle", {
				cx: "32",
				cy: "32",
				r: "28"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "32",
				cy: "32",
				r: "16"
			}),
			/* @__PURE__ */ f("path", { d: "M32 6v10m26 16H48M32 58V48M6 32h10M13 13l8 8m30-8-8 8M13 51l8-8m30 8-8-8" }),
			/* @__PURE__ */ f("path", {
				d: "M29 32 32 8l4 24Z",
				fill: "#755439"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "32",
				cy: "32",
				r: "4"
			})
		]
	}) : e === "different" ? /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ f("rect", {
				x: "4",
				y: "17",
				width: "29",
				height: "38",
				fill: "#de6b49",
				transform: "rotate(-12 18 35)"
			}),
			/* @__PURE__ */ f("rect", {
				x: "29",
				y: "9",
				width: "29",
				height: "38",
				fill: "#75a754",
				transform: "rotate(10 43 28)"
			}),
			/* @__PURE__ */ f("rect", {
				x: "18",
				y: "20",
				width: "29",
				height: "38",
				fill: "#e3c34a"
			})
		]
	}) : e === "basic" ? /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M10 12h41v46H10Z",
				fill: "#d5bd6b"
			}),
			/* @__PURE__ */ f("path", {
				d: "M14 8h41v46H14Z",
				fill: "#f0d879"
			}),
			/* @__PURE__ */ f("text", {
				x: "35",
				y: "40",
				textAnchor: "middle",
				fontFamily: "Georgia,serif",
				fontWeight: "bold",
				fontSize: "34",
				fill: X,
				stroke: "none",
				children: "?"
			})
		]
	}) : e === "prior" ? /* @__PURE__ */ p("g", { children: [
		/* @__PURE__ */ f("path", {
			d: "M17 24Q5 10 22 4q24-6 25 11l-6 12 13 32H9Z",
			fill: "#ac583b",
			stroke: X,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ f("ellipse", {
			cx: "31",
			cy: "15",
			rx: "7",
			ry: "8",
			fill: "#ebc89b"
		}),
		/* @__PURE__ */ f("path", {
			d: "m19 27 12 13 12-13m2 13v19m-4-15h8",
			fill: "none",
			stroke: "#efd367",
			strokeWidth: "3"
		})
	] }) : e === "building" ? /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M9 28 31 9l24 19v31H9Z",
				fill: "#d6bd7e"
			}),
			/* @__PURE__ */ f("path", {
				d: "M4 29 31 5l29 24-7 3-22-18-21 19Z",
				fill: "#ac653b"
			}),
			/* @__PURE__ */ f("path", {
				d: "M26 40h12v19H26Z",
				fill: "#776648"
			}),
			/* @__PURE__ */ f("path", {
				d: "M13 35h7v9h-7m32-9h7v9h-7",
				fill: "#83989a"
			})
		]
	}) : e === "wonder" ? /* @__PURE__ */ p("g", {
		stroke: X,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M7 22 32 4l25 18v8H7Z",
				fill: "#e7c462"
			}),
			/* @__PURE__ */ f("path", {
				d: "M12 30h8v25h-8m16-25h8v25h-8m16-25h8v25h-8",
				fill: "#f2df9c"
			}),
			/* @__PURE__ */ f("path", {
				d: "M5 55h54v7H5Z",
				fill: "#ac8a48"
			})
		]
	}) : /* @__PURE__ */ f("g", {
		stroke: "#425e33",
		strokeWidth: "2",
		children: /* @__PURE__ */ f("path", {
			d: e === "forest" ? "M31 3 13 25h9L8 43h18v18h11V43h20L43 25h10Z" : "M5 42 17 28l17 4 9-13 16 18-5 20H10Z",
			fill: e === "forest" ? "#547f3b" : "#827752"
		})
	});
}
function ot({ kind: e, value: t }) {
	let n = o();
	return /* @__PURE__ */ p("svg", {
		className: "ora-rule-icon",
		viewBox: "0 0 64 64",
		role: "img",
		"aria-label": `${e in J ? n(J[e]) : e}${t === void 0 ? "" : ` ${t}`}`,
		children: [/* @__PURE__ */ f(at, { kind: e }), t !== void 0 && /* @__PURE__ */ f("text", {
			x: "32",
			y: "49",
			textAnchor: "middle",
			fontSize: "28",
			fontWeight: "bold",
			fill: X,
			stroke: "#f8ebbd",
			strokeWidth: "1",
			paintOrder: "stroke",
			children: t
		})]
	});
}
function st() {
	return /* @__PURE__ */ f("svg", {
		className: "ora-conversion-arrow",
		viewBox: "0 0 30 22",
		"aria-hidden": "true",
		children: /* @__PURE__ */ f("path", {
			d: "M1 7H18V2L29 11 18 20V15H1Z",
			fill: "#51452c",
			stroke: "#f5e8bb",
			strokeWidth: "1"
		})
	});
}
function ct({ cover: e }) {
	return /* @__PURE__ */ p("g", {
		stroke: "#5c6342",
		strokeWidth: "1.2",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M13 6 30 2l20 7 10 15-1 19-10 15-22 4-17-9L3 35 6 17Z",
				fill: "#dce7a9"
			}),
			/* @__PURE__ */ f("path", {
				d: "M9 11 27 5l21 6 9 14-2 18-9 13-19 3-16-10-5-16Z",
				fill: "none",
				stroke: "#b6c783",
				strokeWidth: ".8"
			}),
			e === "forest" ? /* @__PURE__ */ p("g", {
				stroke: "#5e482c",
				strokeWidth: "1.4",
				children: [
					/* @__PURE__ */ f("path", {
						d: "m22 10 13 8 8-4 9 15-9 8-2 15-15 7-9-9 2-16-5-9Z",
						fill: "#8b5d31"
					}),
					/* @__PURE__ */ f("path", {
						d: "m22 10 13 8-4 10-11-2-6-1Z",
						fill: "#b19a60"
					}),
					/* @__PURE__ */ f("path", {
						d: "m43 14 9 15-9 8-5-13Z",
						fill: "#b29e6d"
					}),
					/* @__PURE__ */ f("path", {
						d: "m26 43 15-6v15l-15 7Z",
						fill: "#d7c18b"
					}),
					/* @__PURE__ */ f("path", {
						d: "m19 34 12-6 7-4-3 16-9 3-9 7Z",
						fill: "#704825"
					}),
					/* @__PURE__ */ f("path", {
						d: "m26 44 10-3m-11 8 11-3m-11 7 11-3",
						stroke: "#bca371",
						strokeWidth: ".8"
					})
				]
			}) : /* @__PURE__ */ p("g", {
				stroke: "#686850",
				strokeWidth: "1.3",
				children: [
					/* @__PURE__ */ f("path", {
						d: "m15 11 17-3 21 37-3 12-13 5L14 27Z",
						fill: "#9c9b80"
					}),
					/* @__PURE__ */ f("path", {
						d: "m15 11 22 39 16-5-21-37Z",
						fill: "#adae93"
					}),
					/* @__PURE__ */ f("path", {
						d: "m15 11-1 16 23 35V50Z",
						fill: "#d0d0b1"
					}),
					/* @__PURE__ */ f("path", {
						d: "m37 50 16-5-3 12-13 5Z",
						fill: "#777963"
					}),
					/* @__PURE__ */ f("path", {
						d: "m20 17 18 29m-22-17 17 25",
						stroke: "#dcdcc1",
						strokeWidth: "1"
					})
				]
			})
		]
	});
}
function lt({ cover: e }) {
	let t = o(), n = e === "forest" ? "wood" : "peat";
	return /* @__PURE__ */ p("svg", {
		className: "ora-harvest-diagram",
		viewBox: "0 0 184 78",
		role: "img",
		"aria-label": `${t(Qe[e])} → 1× ${t(Y[n])}`,
		children: [
			/* @__PURE__ */ f("svg", {
				x: "0",
				y: "3",
				width: "75",
				height: "72",
				viewBox: "0 0 64 64",
				children: /* @__PURE__ */ f(ct, { cover: e })
			}),
			/* @__PURE__ */ f("path", {
				d: "M76 29h13v-9l28 19-28 19v-9H76Z",
				fill: "#313e2b",
				stroke: "#f1efd0",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("text", {
				x: "94",
				y: "43",
				fill: "#fff8d6",
				textAnchor: "middle",
				fontFamily: "Georgia,serif",
				fontSize: "16",
				fontWeight: "bold",
				children: "1×"
			}),
			/* @__PURE__ */ f("path", {
				d: "m123 19 48-4 6 52-48 7Z",
				fill: "#74744d",
				stroke: "#565a3c"
			}),
			/* @__PURE__ */ f("path", {
				d: "m120 15 48-4 6 52-48 7Z",
				fill: "#8b8554",
				stroke: "#565a3c"
			}),
			/* @__PURE__ */ f("svg", {
				x: "119",
				y: "7",
				width: "55",
				height: "55",
				viewBox: "0 0 64 64",
				children: /* @__PURE__ */ f(it, { good: n })
			})
		]
	});
}
//#endregion
//#region src/games/oraetlabora/art.tsx
var ut = (e) => `games/oraetlabora/${e}.svg`;
function dt({ good: e, n: t }) {
	return /* @__PURE__ */ p("span", {
		className: "ora-good-amount",
		children: [/* @__PURE__ */ f(Z, { good: e }), /* @__PURE__ */ f("b", { children: t })]
	});
}
function ft({ stock: e }) {
	return /* @__PURE__ */ f("span", {
		className: "ora-stock-row",
		children: Object.entries(e).filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ f(dt, {
			good: e,
			n: t
		}, e))
	});
}
function pt({ value: e, dwelling: t = !1 }) {
	let n = o();
	return /* @__PURE__ */ p("span", {
		className: "ora-score",
		title: n(t ? J.dwelling : J.economic),
		children: [/* @__PURE__ */ f("svg", {
			viewBox: "0 0 28 32",
			"aria-hidden": "true",
			children: /* @__PURE__ */ f("path", {
				d: t ? "M2 14 14 2 26 14V30H2Z" : "M2 2H26V14Q25 25 14 30Q3 25 2 14Z",
				fill: t ? "#9c4d27" : "#e8c557",
				stroke: "#594226",
				strokeWidth: "1.5"
			})
		}), /* @__PURE__ */ f("b", { children: e })]
	});
}
function mt({ prior: e = !1, color: t = "#9b4932" }) {
	return /* @__PURE__ */ p("svg", {
		className: "ora-clergyman",
		viewBox: "0 0 30 52",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M7 19Q2 13 7 6Q15-2 23 6Q28 13 23 19L29 48Q15 54 1 48Z",
				fill: t,
				stroke: "#3e3324",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "15",
				cy: "12",
				rx: "5",
				ry: "6",
				fill: "#eac393"
			}),
			e && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
				d: "M8 20 15 30 22 20",
				fill: "none",
				stroke: "#ebd363",
				strokeWidth: "3"
			}), /* @__PURE__ */ f("path", {
				d: "M24 25V48M21 28H27",
				stroke: "#e8d078",
				strokeWidth: "3"
			})] })
		]
	});
}
function ht() {
	return /* @__PURE__ */ f("svg", {
		className: "ora-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "3",
			fill: "none",
			stroke: "#fff4ab",
			strokeWidth: "3",
			strokeDasharray: "7 5",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ f("animate", {
				attributeName: "stroke-dashoffset",
				from: "24",
				to: "0",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
function gt({ item: e }) {
	let t = o(), n = e.mode && e.mode !== "repeat" && e.mode !== "jokerOnly" ? $e[e.mode] : $e[e.kind], r = {
		wonder: "wonder",
		carpentry: "building",
		locutory: "building",
		occupied: "building",
		shipping: "wheel",
		cooperage: "wheel",
		festival: "points",
		brotherhood: "points"
	};
	return /* @__PURE__ */ p("span", {
		className: "ora-effect-lines",
		children: [
			e.recipes.map((t, n) => {
				let i = Object.entries(t.cost).filter(([, e]) => e > 0).map(([e, t]) => ({
					good: e,
					n: t
				}));
				t.food && i.push({
					kind: "food",
					n: t.food
				}), t.energy && i.push({
					kind: "energy",
					n: t.energy
				}), t.points && i.push({
					kind: "points",
					n: t.points
				}), e.different && i.push({
					kind: "different",
					n: e.different
				});
				let a = Object.entries(t.gain).filter(([, e]) => e > 0).map(([e, t]) => ({
					good: e,
					n: t
				}));
				return e.mode === "basic" ? a.push({
					kind: "basic",
					n: e.amount
				}) : e.mode === "twoBasic" ? a.push({
					kind: "basic",
					n: 5
				}, {
					kind: "basic",
					n: 3
				}) : r[e.mode] && a.push({
					kind: r[e.mode],
					n: 1
				}), e.mode === "forge" && (i.push({
					good: "coin",
					n: 5
				}), a.push({
					good: "reliquary",
					n: 1
				})), e.mode === "livestock" ? /* @__PURE__ */ p("span", {
					className: "ora-income-condition",
					children: [
						/* @__PURE__ */ f(Z, { good: "livestock" }),
						/* @__PURE__ */ f("span", { children: "≥ 1 / 5 / 9" }),
						/* @__PURE__ */ f("span", { children: "→" }),
						/* @__PURE__ */ f(Z, { good: "coin" }),
						/* @__PURE__ */ f("span", { children: "3 / 5 / 8" })
					]
				}, n) : !i.length && !a.length ? null : /* @__PURE__ */ p("span", {
					className: "ora-recipe-option",
					children: [n > 0 && e.recipes.length > 1 && /* @__PURE__ */ f("span", {
						className: "ora-recipe-or",
						children: "/"
					}), /* @__PURE__ */ f(_t, {
						input: i,
						output: a,
						limit: e.recipes.length > 1 ? 1e5 : e.limit
					})]
				}, n);
			}),
			e.recipes.length > 1 && /* @__PURE__ */ f("span", {
				className: "ora-recipe-total",
				children: t("games.oraetlabora.repeatCombined", { n: e.limit })
			}),
			e.kind === "production" && /* @__PURE__ */ f(_t, {
				input: [{ kind: "wheel" }],
				output: e.goods.map((e) => ({ good: e })),
				choice: !0
			}),
			e.kind === "copy" && /* @__PURE__ */ f(_t, {
				input: [{ kind: e.mode === "prior" ? "prior" : "building" }],
				output: [{ kind: "building" }]
			}),
			e.kind === "prior" && /* @__PURE__ */ f(_t, {
				input: [{ kind: "prior" }],
				output: [{ kind: "building" }]
			}),
			e.kind === "clear" && /* @__PURE__ */ f(_t, {
				input: [{ kind: e.mode === "peat" ? "moor" : "forest" }],
				output: e.mode === "printing" ? [{
					good: "book",
					n: 1
				}] : e.mode === "carpentry" ? [{ kind: "building" }] : e.mode === "forestHut" ? [
					{
						good: "livestock",
						n: 2
					},
					{
						good: "wood",
						n: 2
					},
					{
						good: "stone",
						n: 1
					}
				] : [{ kind: "wheel" }, { good: e.mode === "peat" ? "peat" : "wood" }],
				limit: e.limit
			}),
			e.kind === "settlement" && /* @__PURE__ */ f(ot, { kind: "settlement" }),
			e.kind === "swap" && /* @__PURE__ */ f(ot, { kind: "swap" }),
			n && /* @__PURE__ */ f("span", {
				className: "ora-effect-text",
				children: t(n)
			})
		]
	});
}
function _t({ input: e, output: t, limit: n = 1, choice: r = !1 }) {
	let i = o(), a = e.length + t.length > 5 ? 3 : 5, s = Math.ceil(e.length / a), c = Math.ceil(t.length / a), l = Math.max(1, s, c), u = Math.min(e.length, a) * 36, d = Math.min(t.length, a) * 36, m = e.length && t.length ? 38 : 0, h = Math.max(100, u + d + m), g = l * 38, _ = (e) => e.map((e) => `${e.n ?? ""} ${e.good ? i(Y[e.good]) : e.kind === "different" ? i(J.different, { n: e.n ?? 1 }) : e.kind === "basic" ? i(J.output) : e.kind && e.kind in J ? i(J[e.kind]) : i(J.effect)}`).join(", "), v = (e, t) => e.map((n, i) => /* @__PURE__ */ p("g", {
		transform: `translate(${t + i % a * 36} ${Math.floor(i / a) * 38 + (l * 38 - Math.ceil(e.length / a) * 38) / 2})`,
		children: [
			/* @__PURE__ */ f("svg", {
				x: "1",
				y: "1",
				width: "27",
				height: "27",
				viewBox: "0 0 64 64",
				children: n.good ? /* @__PURE__ */ f(it, { good: n.good }) : n.kind && /* @__PURE__ */ f(at, { kind: n.kind })
			}),
			n.n !== void 0 && /* @__PURE__ */ f("text", {
				x: "30",
				y: "31",
				textAnchor: "end",
				fontFamily: "Georgia,serif",
				fontWeight: "bold",
				fontSize: "17",
				fill: "#46371e",
				stroke: "#f5e9c5",
				strokeWidth: "2.5",
				paintOrder: "stroke",
				children: n.n
			}),
			r && i < e.length - 1 && /* @__PURE__ */ f("text", {
				x: "32",
				y: "19",
				fontSize: "13",
				fill: "#725f38",
				children: "/"
			})
		]
	}, i));
	return /* @__PURE__ */ p("svg", {
		className: "ora-recipe-diagram",
		viewBox: `0 0 ${h} ${g}`,
		role: "img",
		"aria-label": `${_(e)}${m ? " → " : ""}${_(t)}${n > 1 ? ` (${i(J.repeat, { n: n < 1e4 ? n : "∞" })})` : ""}`,
		style: { maxHeight: `${g * 1.5}px` },
		children: [
			v(e, (h - u - d - m) / 2),
			m > 0 && /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("path", {
				d: `M${(h - u - d - m) / 2 + u + 1} ${l * 19 - 8}h21v-6l15 14-15 14v-6h-21Z`,
				fill: "#53462d"
			}), n < 1e4 && /* @__PURE__ */ p("text", {
				x: (h - u - d - m) / 2 + u + 16,
				y: l * 19 + 4,
				textAnchor: "middle",
				fontFamily: "Georgia,serif",
				fontWeight: "bold",
				fontSize: "11",
				fill: "#fff1c6",
				children: [n, "×"]
			})] }),
			v(t, (h - u - d - m) / 2 + u + m)
		]
	});
}
function vt({ id: e, onClick: t, selected: n, compact: r = !1 }) {
	let i = o(), a = b[e], { ref: s } = c(`market:${e}`);
	return /* @__PURE__ */ p("button", {
		ref: s,
		type: "button",
		className: `ora-building-card${a.cloister ? " ora-cloister-card" : ""}${r ? " ora-compact-card" : ""}${n ? " ora-selected" : ""}`,
		onClick: t,
		"aria-label": i(a.nameKey),
		"aria-pressed": n,
		children: [/* @__PURE__ */ p("span", {
			className: "ora-card-face",
			children: [
				/* @__PURE__ */ p("span", {
					className: "ora-card-ribbon",
					children: [
						/* @__PURE__ */ f("span", {
							className: "ora-card-terrain",
							children: a.terrain.map((e) => /* @__PURE__ */ f("span", { children: i(Ze[e]) }, e))
						}),
						/* @__PURE__ */ p("span", {
							className: "ora-card-cost",
							children: [/* @__PURE__ */ f(ft, { stock: a.cost }), a.food !== void 0 && /* @__PURE__ */ p("span", {
								className: "ora-settle-cost",
								children: [/* @__PURE__ */ f(ot, {
									kind: "food",
									value: a.food
								}), /* @__PURE__ */ f(ot, {
									kind: "energy",
									value: a.energy
								})]
							})]
						}),
						/* @__PURE__ */ p("span", {
							className: "ora-card-values",
							children: [/* @__PURE__ */ f(pt, { value: a.economic }), /* @__PURE__ */ f(pt, {
								value: a.dwelling,
								dwelling: !0
							})]
						}),
						a.stage > 0 && /* @__PURE__ */ f("span", {
							className: "ora-letter",
							children: String.fromCharCode(64 + a.stage)
						})
					]
				}),
				/* @__PURE__ */ f("span", {
					className: "ora-card-title",
					children: i(a.nameKey)
				}),
				/* @__PURE__ */ f("span", {
					className: "ora-card-picture",
					children: /* @__PURE__ */ f("img", {
						src: ut(e),
						alt: "",
						draggable: !1
					})
				})
			]
		}), !r && /* @__PURE__ */ f("span", {
			className: "ora-card-effects",
			children: fe(e, "", "").map((e, t) => /* @__PURE__ */ f(gt, { item: e }, t))
		})]
	});
}
function yt({ rid: e, good: t, value: n, onClick: r }) {
	let i = o(), { ref: a } = c(`good:${e}:${t}`);
	return /* @__PURE__ */ p("button", {
		ref: a,
		className: "ora-resource",
		onClick: r,
		title: i(Y[t]),
		"aria-label": `${i(Y[t])}: ${n}`,
		children: [/* @__PURE__ */ f(Z, { good: t }), /* @__PURE__ */ f(u, { value: n })]
	});
}
//#endregion
//#region src/games/oraetlabora/wonders.tsx
var bt = {
	3: ["straw"],
	4: ["coin"],
	5: ["meat"],
	6: ["whiskey", "beer"],
	9: [
		"wood",
		"clay",
		"stone",
		"straw"
	],
	10: [
		"grain",
		"livestock",
		"meat",
		"bread"
	],
	12: ["peat", "peatcoal"],
	15: ["clay"],
	16: [
		"wood",
		"clay",
		"stone",
		"straw"
	],
	18: ["wood"],
	19: ["book", "ceramic"],
	20: ["livestock", "grain"],
	21: ["ornament"],
	22: ["stone"],
	23: ["reliquary"]
};
function xt({ id: e, state: t, estate: n, onClick: r }) {
	let i = o();
	return /* @__PURE__ */ p("button", {
		type: "button",
		className: "ora-wonder-card",
		onClick: r,
		children: [
			/* @__PURE__ */ p("span", {
				className: "ora-wonder-heading",
				children: [i(e ? J.wonderNumber : J.baseWonder, { n: e }), /* @__PURE__ */ f(pt, { value: Je(t, n, e) })]
			}),
			/* @__PURE__ */ f("img", {
				src: ut("wonder"),
				alt: ""
			}),
			/* @__PURE__ */ p("span", {
				className: "ora-wonder-symbols",
				children: [(bt[e] ?? []).map((e) => /* @__PURE__ */ f(Z, { good: e }, e)), !bt[e] && /* @__PURE__ */ f(ot, { kind: e === 11 || e === 17 ? "settlement" : "building" })]
			}),
			/* @__PURE__ */ f("span", { children: e ? i(`games.oraetlabora.wonderRules.w${e}`) : `${t.config.wonders ? 20 : 30} ${i(J.points)}` })
		]
	});
}
//#endregion
//#region src/games/oraetlabora/choices.ts
var Q = (e = {}) => ({
	type: "resolve",
	option: 0,
	count: 1,
	inputs: {},
	food: {},
	energy: {},
	points: {},
	target: "",
	owner: "",
	cells: [],
	marker: "",
	swap: [],
	...e
}), $ = (e, t) => !("code" in Xe.reduce(e, t, { by: H(e) }));
function St(e, t, n) {
	if (t <= 0) return {};
	if (R(e, n) < t) return null;
	let r = Math.ceil(t * 2) + Math.max(...Object.values(n)) * 2, i = /* @__PURE__ */ new Map([[0, {
		cost: 0,
		stock: {}
	}]]);
	for (let t of E) {
		let a = (n[t] ?? 0) * 2;
		if (!a) continue;
		let o = new Map(i);
		for (let [n, s] of i) for (let i = 1; i <= Math.min(e[t] ?? 0, Math.ceil(r / a)); i++) {
			let e = n + a * i;
			if (e > r) break;
			let c = s.cost + i * ((C[t] ?? (t === "coin" ? .4 : .15)) + .03);
			(!o.has(e) || o.get(e).cost > c) && o.set(e, {
				cost: c,
				stock: {
					...s.stock,
					[t]: i
				}
			});
		}
		i = o;
	}
	return [...i].filter(([e]) => e >= t * 2).sort((e, t) => e[1].cost - t[1].cost || e[0] - t[0])[0]?.[1].stock ?? null;
}
function Ct(e, t) {
	for (let n of E) e[n] = (e[n] ?? 0) - (t[n] ?? 0);
}
function wt(e, t, n, r, i, a = 0) {
	let o = { ...e.stock };
	for (let e of E) if (e !== "coin" && (n[e] ?? 0) > (o[e] ?? 0)) return null;
	if (L(o) < (n.coin ?? 0)) return null;
	Ct(o, {
		...n,
		coin: 0
	});
	let s = n.coin ?? 0, c = Math.min(o.coin ?? 0, s);
	if (o.coin = (o.coin ?? 0) - c, s -= c, s) {
		let e = Math.ceil(s / 5);
		o.coin5 = (o.coin5 ?? 0) - e, o.coin += e * 5 - s;
	}
	let l = St(o, r, x);
	if (!l) return null;
	Ct(o, l);
	let u = St(o, i, S);
	if (!u) return null;
	Ct(o, u);
	let d = St(o, a, C);
	return d ? {
		...t,
		food: l,
		energy: u,
		points: d
	} : null;
}
function Tt(e, t) {
	let n = E.filter((t) => (e.stock[t] ?? 0) > 0).sort((e, t) => (C[e] ?? 0) - (C[t] ?? 0));
	return n.length >= t ? Object.fromEntries(n.slice(0, t).map((e) => [e, 1])) : null;
}
function Et(e, t) {
	let n = [], r = t.cells.map((e) => e.x), i = t.cells.map((e) => Math.floor(e.y));
	for (let e of ["district", "plot"]) for (let a of [0, 1]) for (let o = Math.min(...i) - 2; o <= Math.max(...i) + 1; o++) for (let i = Math.min(...r) - 2; i <= Math.max(...r) + 1; i++) Be(t, Re(e, a, i, o), e) && n.push({
		type: "land",
		tile: e,
		side: a,
		x: i,
		y: o
	});
	return n;
}
function Dt(e) {
	let t = I(e, e.turn), n = [];
	if (e.phase === "done") return n;
	if (e.phase === "contract") return V(e, e.contract.owner).map((e) => ({
		type: "contract",
		clergy: e
	}));
	if (e.phase === "effect") {
		let r = e.tasks[0];
		if (!r) return n;
		if (r.kind !== "neutral" && n.push({ type: "skip" }), r.kind === "production") for (let e of r.goods) for (let t of r.mode === "jokerOnly" ? ["joker"] : [e, "joker"]) n.push(Q({
			output: e,
			marker: t
		}));
		if (r.kind === "swap") for (let t of Object.keys(e.wheel)) for (let r of Object.keys(e.wheel)) t < r && n.push(Q({ swap: [t, r] }));
		if (r.kind === "prior" && n.push(Q()), r.kind === "copy") for (let t of Ue(e, r)) n.push(Q({
			owner: t.owner,
			target: t.cell
		}));
		if (r.kind === "build") for (let r of e.market) for (let e of t.cells) q(t, r, e) && n.push(Q({
			target: r,
			cells: [e.key]
		}));
		if (r.kind === "neutral") for (let t of e.market) for (let r of e.neutral.cells) q(e.neutral, t, r, !0) && n.push(Q({
			target: t,
			cells: [r.key]
		}));
		if (r.kind === "neutralUse") for (let t of e.neutral.cells) e.neutralNew.includes(t.key) && n.push(Q({ target: t.key }));
		if (r.kind === "land" && n.push(...Et(e, t)), r.kind === "settlement" && n.push(...Ot(e, t)), r.kind === "wonder") for (let t of [0, ...e.wonderSupply]) n.push(Q({ option: t }));
		if (r.kind === "points") {
			for (let e of [
				"book",
				"ceramic",
				"ornament",
				"reliquary"
			]) n.push(Q({ inputs: { [e]: Math.floor(r.amount / C[e]) } }));
			let e = Math.floor(r.amount), t = {};
			for (let n of [
				"reliquary",
				"ornament",
				"ceramic",
				"book"
			]) t[n] = Math.floor(e / C[n]), e -= t[n] * C[n];
			n.push(Q({ inputs: t }));
		}
		if (r.kind === "clear") {
			let e = t.cells.filter((e) => e.cover === (r.mode === "peat" ? "moor" : "forest"));
			for (let t of e) for (let e of [r.mode === "peat" ? "peat" : "wood", "joker"]) n.push(Q({
				cells: [t.key],
				marker: e
			}));
			r.limit > 1 && n.push(Q({ cells: e.slice(0, r.limit).map((e) => e.key) }));
		}
		if (r.kind === "trade") for (let e = 0; e < r.recipes.length; e++) {
			let i = r.recipes[e], a = Math.min(r.limit, r.mode === "forge" ? Math.floor((L(t.stock) + 5) / 10) : 1e5, ...Object.entries(i.cost).filter(([, e]) => e > 0).map(([e, n]) => Math.floor((e === "coin" ? L(t.stock) : t.stock[e] ?? 0) / n)), i.food ? Math.floor(R(t.stock, x) / i.food) : 1e5, i.energy ? Math.floor(R(t.stock, S) / i.energy) : 1e5);
			for (let o of [.../* @__PURE__ */ new Set([1, a])].filter((e) => e > 0 && e <= r.limit)) {
				let a = wt(t, Q({
					option: e,
					count: o
				}), Object.fromEntries(Object.entries(i.cost).map(([e, t]) => [e, t * o])), i.food * o, i.energy * o, i.points * o);
				if (a) {
					if (r.different) {
						let e = Tt(t, r.different);
						if (!e) continue;
						a.inputs = e;
					}
					if (r.mode === "basic") for (let e of D) n.push({
						...a,
						output: e
					});
					else if (r.mode === "twoBasic") for (let e of D) for (let t of D) t !== e && n.push({
						...a,
						output: e,
						secondary: t
					});
					else n.push(a);
				}
			}
		}
	}
	if (e.phase === "settlement" && (e.consumed || n.push(...Ot(e, t)), n.push({ type: "end" }), n.push(...Et(e, t))), e.phase === "action") {
		if (e.consumed) n.push({ type: "end" });
		else {
			if (!e.bonus) {
				for (let e of t.cells.filter((e) => e.cover)) for (let t of [e.cover === "forest" ? "wood" : "peat", "joker"]) n.push({
					type: "harvest",
					cell: e.key,
					marker: t
				});
				t.cells.some((e) => e.cover === "forest") || n.push({
					type: "harvest",
					cell: "",
					marker: "wood"
				});
			}
			for (let r of e.market) for (let e of t.cells) q(t, r, e) && n.push({
				type: "build",
				building: r,
				cell: e.key
			});
			for (let r of F(e)) for (let i of r.cells.filter((e) => e.building && !e.building.startsWith("S"))) for (let a of e.bonus ? [0] : V(e, r.rid)) for (let e of r.rid === t.rid ? ["coin"] : [
				"coin",
				"wine",
				"whiskey"
			]) n.push({
				type: "use",
				owner: r.rid,
				cell: i.key,
				clergy: a,
				gift: e
			});
		}
		n.push(...Et(e, t));
	}
	for (let r of [
		"grain",
		"coin",
		"coin5",
		"wine",
		"whiskey"
	]) {
		let i = Math.floor((t.stock[r] ?? 0) / (r === "coin" ? 5 : 1)), a = [1, i];
		if (r === "grain") for (let n of e.market) a.push((b[n].cost.straw ?? 0) - (t.stock.straw ?? 0));
		for (let e of new Set(a)) e > 0 && e <= i && n.push({
			type: "exchange",
			from: r,
			count: e
		});
	}
	return n.filter((t) => $(e, t));
}
function Ot(e, t) {
	return t.settlements.flatMap((e) => t.cells.filter((n) => q(t, e, n)).flatMap((n) => {
		let r = b[e], i = wt(t, Q(), {}, r.food ?? 0, r.energy ?? 0);
		return i ? [{
			type: "settle",
			building: e,
			cell: n.key,
			food: i.food,
			energy: i.energy
		}] : [];
	}));
}
//#endregion
//#region src/games/oraetlabora/view-player.tsx
function kt(e) {
	return /* @__PURE__ */ f(At, {
		...e,
		state: e.public
	});
}
function At({ state: e, members: t, myRid: n, send: i }) {
	let u = o(), [m, h] = a(n), [g, _] = a(""), [v, y] = a(null), [C, ee] = a(null), [w, T] = a(null), [te, ne] = a(!1), [re, O] = a(!1), [ie, ae] = a([]), [k, oe] = a({
		tile: "district",
		side: 0
	}), [se, ce] = a("joker"), A = H(e) === n, j = r(() => Dt(e), [e]), le = I(e, e.turn), M = e.tasks[0], { ref: ue } = c("catalog"), [de, N] = a(!1), [P, fe] = a(null), [me, L] = a(null), R = e.phase === "effect" && M?.kind === "neutral", z = I(e, R ? pe : F(e).some((e) => e.rid === m) ? m : n), B = (e) => e === "$neutral" ? u(J.neutral) : t.find((t) => t.rid === e)?.name ?? e, U = (e) => s[t.find((t) => t.rid === e)?.colorIndex ?? 0]?.hex ?? "#647447", W = (t) => {
		A && $(e, t) && (i(t), _(""), ee(null), T(null), ae([]), fe(null), N(!1), y(null));
	}, _e = e.phase === "action" && !e.consumed || e.phase === "effect" && ["build", "neutral"].includes(M?.kind), ve = e.phase === "settlement" && !e.consumed || e.phase === "effect" && M?.kind === "settlement", ye = j.filter((e) => e.type === "land" && e.tile === k.tile && e.side === k.side), be = (e) => j.find((t) => t.type === "build" && t.building === g && t.cell === e.key || t.type === "settle" && t.building === g && t.cell === e.key || t.type === "resolve" && t.target === g && t.cells[0] === e.key && ["build", "neutral"].includes(M?.kind)), xe = (e) => j.find((t) => t.type === "resolve" && t.target === e.key && (M?.kind === "neutralUse" || t.owner === z.rid && M?.kind === "copy")), Se = (t) => e.phase === "effect" && M?.kind === "clear" && t.cover === (M.mode === "peat" ? "moor" : "forest") && z.rid === e.turn, Ce = (e) => {
		if (A && g && be(e)) {
			let t = be(e);
			t.type === "settle" ? fe(t) : W(t);
			return;
		}
		if (A && xe(e)) {
			W(xe(e));
			return;
		}
		if (A && Se(e)) {
			ae((t) => t.includes(e.key) ? t.filter((t) => t !== e.key) : [...t, e.key].slice(-M.limit));
			return;
		}
		(e.building || e.cover) && ee({
			owner: z.rid,
			cell: e.key
		});
	}, G = (e) => A && (!!g && !!be(e) || !!xe(e) || Se(e)), K = (C ? I(e, C.owner) : null)?.cells.find((e) => e.key === C?.cell), we = j.find((e) => e.type === "end"), Te = j.find((e) => e.type === "skip"), Ee = de || v === "land" || e.phase === "effect" && M?.kind === "land", De = e.market, Oe = /* @__PURE__ */ p("header", {
		className: "ora-header",
		children: [/* @__PURE__ */ p("div", {
			className: "ora-title",
			children: [/* @__PURE__ */ f("strong", { children: "Ora et Labora" }), /* @__PURE__ */ p("span", { children: [
				u(e.config.country === "france" ? J.france : J.ireland),
				" · ",
				u(J.round, { n: e.round }),
				" · ",
				String.fromCharCode(65 + e.settlementStage)
			] })]
		}), /* @__PURE__ */ f("div", {
			className: "ora-player-tabs",
			children: F(e).map((t) => /* @__PURE__ */ p(jt, {
				rid: t.rid,
				className: z.rid === t.rid ? "ora-tab ora-selected" : "ora-tab",
				style: { "--ora-player": U(t.rid) },
				onClick: () => {
					h(t.rid), _(""), N(!1);
				},
				children: [
					/* @__PURE__ */ f("span", { className: "ora-player-dot" }),
					B(t.rid),
					/* @__PURE__ */ f("b", { children: Ye(e, t).total }),
					/* @__PURE__ */ f("span", {
						className: "ora-tab-clergy",
						children: V(e, t.rid).map((e) => /* @__PURE__ */ f(Mt, {
							rid: t.rid,
							index: e,
							color: U(t.rid)
						}, e))
					})
				]
			}, t.rid))
		})]
	}), ke = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("nav", {
		className: "ora-book-tabs",
		children: [
			"market",
			"settlements",
			"land"
		].map((t) => /* @__PURE__ */ p("button", {
			className: (v ?? "market") === t ? "ora-selected" : "",
			onClick: () => {
				y(t), N(t === "land");
			},
			children: [u(J[t]), t === "market" && /* @__PURE__ */ f("b", { children: e.market.length })]
		}, t))
	}), Ee ? /* @__PURE__ */ p("div", {
		className: "ora-land-book",
		children: [
			/* @__PURE__ */ p("div", {
				className: "ora-land-tools",
				children: [["district", "plot"].map((t) => /* @__PURE__ */ p("button", {
					className: k.tile === t ? "ora-selected" : "",
					onClick: () => oe({
						tile: t,
						side: 0
					}),
					children: [u(J[t]), /* @__PURE__ */ f(ft, { stock: { coin: (t === "district" ? e.districtPrices : e.plotPrices)[0] ?? 0 } })]
				}, t)), /* @__PURE__ */ f("button", {
					onClick: () => oe({
						...k,
						side: 1 - k.side
					}),
					children: u(J.side)
				})]
			}),
			/* @__PURE__ */ f("div", {
				className: "ora-land-preview",
				children: Re(k.tile, k.side, 0, 0).map((e) => /* @__PURE__ */ f("div", {
					className: `ora-preview-cell ora-terrain-${e.terrain}`,
					style: {
						gridColumn: e.x + 1,
						gridRow: `${Math.floor(e.y) + 1} / span ${e.terrain === "mountain" ? 2 : 1}`
					},
					children: e.cover ? u(Qe[e.cover]) : u(Ze[e.terrain])
				}, e.key))
			}),
			/* @__PURE__ */ f("button", {
				className: "ora-primary",
				onClick: () => {
					N(!0), y(null), h(e.turn);
				},
				children: u(J.chooseSite)
			})
		]
	}) : /* @__PURE__ */ f("div", {
		className: "ora-catalog-grid",
		children: (v === "settlements" ? le.settlements : De).map((t) => /* @__PURE__ */ f(vt, {
			id: t,
			selected: g === t,
			onClick: () => {
				if (A && e.phase === "effect" && M?.kind === "copy" && M.mode === "market") {
					let e = j.find((e) => e.type === "resolve" && e.target === t);
					e && W(e);
					return;
				}
				if (!A || !(v === "settlements" ? ve : _e)) {
					L(t);
					return;
				}
				N(!1), _((e) => e === t ? "" : t), y(null), R || h(e.turn);
			}
		}, t))
	})] });
	return /* @__PURE__ */ p(l, {
		adaptive: !0,
		scroll: !1,
		className: "ora-root",
		banner: Oe,
		actionsHeight: "ora-actions-height",
		actions: /* @__PURE__ */ p("footer", {
			className: "ora-actions",
			children: [/* @__PURE__ */ f("span", { children: e.phase === "done" ? u(J.done) : A ? u(R ? J.neutralBuild : e.phase === "settlement" ? J.settlement : e.phase === "contract" ? J.contract : g ? J.chooseSite : e.phase === "effect" ? J.effect : J.action) : u(J.waiting, { name: B(H(e)) }) }), /* @__PURE__ */ p("div", { children: [
				(e.config.wonders || z.wonders.length > 0) && /* @__PURE__ */ p("button", {
					onClick: () => O(!0),
					children: [
						u(J.wonders),
						" ",
						z.wonders.length
					]
				}),
				/* @__PURE__ */ f("button", {
					onClick: () => ne(!0),
					children: u(J.log)
				}),
				Te && A && /* @__PURE__ */ f("button", {
					onClick: () => W(Te),
					children: u(J.skip)
				}),
				we && A && /* @__PURE__ */ f("button", {
					className: "ora-primary",
					onClick: () => W(we),
					children: u(e.phase === "settlement" ? J.endSettlement : J.end)
				})
			] })]
		}),
		children: [
			/* @__PURE__ */ p("main", {
				className: "ora-workspace",
				children: [/* @__PURE__ */ p("section", {
					className: "ora-estate-column",
					children: [
						/* @__PURE__ */ f(It, { state: e }),
						/* @__PURE__ */ f("div", {
							className: "ora-estate-scroll",
							children: /* @__PURE__ */ f(Pt, {
								estate: z,
								valid: G,
								selectedCells: ie,
								onCell: Ce,
								color: U,
								name: B,
								lands: A && Ee && z.rid === e.turn ? ye : [],
								onLand: W
							})
						}),
						/* @__PURE__ */ f("div", {
							className: "ora-resource-tray",
							children: E.filter((e) => D.includes(e) || (z.stock[e] ?? 0) > 0).map((e) => /* @__PURE__ */ f(yt, {
								rid: z.rid,
								good: e,
								value: z.stock[e] ?? 0,
								onClick: () => T(e)
							}, e))
						}),
						/* @__PURE__ */ p("div", {
							className: "ora-mobile-books",
							children: [
								/* @__PURE__ */ p("button", {
									onClick: () => {
										y("market"), N(!1);
									},
									children: [
										u(J.market),
										" ",
										/* @__PURE__ */ f("b", { children: e.market.length })
									]
								}),
								/* @__PURE__ */ f("button", {
									onClick: () => {
										y("settlements"), N(!1);
									},
									children: u(J.settlements)
								}),
								/* @__PURE__ */ f("button", {
									onClick: () => {
										y("land"), N(!0);
									},
									children: u(J.land)
								})
							]
						}),
						A && e.phase === "contract" && /* @__PURE__ */ p("div", {
							className: "ora-decision",
							children: [/* @__PURE__ */ f("h2", { children: u(J.chooseClergy) }), /* @__PURE__ */ f("div", {
								className: "ora-clergy-choices",
								children: V(e, H(e)).map((t) => /* @__PURE__ */ p("button", {
									onClick: () => W({
										type: "contract",
										clergy: t
									}),
									children: [/* @__PURE__ */ f(mt, {
										prior: t === 0,
										color: U(H(e))
									}), u(t === 0 ? J.prior : J.lay)]
								}, t))
							})]
						}),
						A && e.phase === "effect" && M && ![
							"copy",
							"build",
							"neutral",
							"settlement",
							"land"
						].includes(M.kind) && /* @__PURE__ */ p("div", {
							className: "ora-decision",
							children: [/* @__PURE__ */ f("h2", { children: M.source && b[M.source] ? u(b[M.source].nameKey) : u(J.effect) }), M.kind === "clear" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("p", { children: [
								u(J.chooseTarget),
								" · ",
								ie.length,
								"/",
								M.limit
							] }), /* @__PURE__ */ p("div", {
								className: "ora-inline-choices",
								children: [[M.mode === "peat" ? "peat" : "wood", "joker"].map((t) => /* @__PURE__ */ p("button", {
									onClick: () => ce(t),
									className: se === t ? "ora-selected" : "",
									children: [
										u(t === "joker" ? J.joker : Y[t]),
										" ",
										he(e, t)
									]
								}, t)), /* @__PURE__ */ f("button", {
									disabled: !$(e, Q({
										cells: ie,
										marker: se
									})),
									onClick: () => W(Q({
										cells: ie,
										marker: se
									})),
									children: u(J.confirm)
								})]
							})] }) : /* @__PURE__ */ f(zt, {
								state: e,
								task: M,
								actions: j,
								onAction: W
							})]
						}, `${e.serial}:${M.kind}:${M.source}:${M.limit}`)
					]
				}), /* @__PURE__ */ p("aside", {
					ref: ue,
					className: `ora-catalog${v ? " ora-book-open" : ""}`,
					children: [/* @__PURE__ */ f("div", {
						className: "ora-mobile-close",
						children: /* @__PURE__ */ f("button", {
							onClick: () => y(null),
							children: u(J.close)
						})
					}), ke]
				})]
			}),
			C && K && /* @__PURE__ */ p(Lt, {
				title: K.building ? u(b[K.building].nameKey) : K.cover ? u(Qe[K.cover]) : u(J.details),
				close: () => ee(null),
				children: [
					K.building && /* @__PURE__ */ f(vt, { id: K.building }),
					" ",
					K.cover && /* @__PURE__ */ f(lt, { cover: K.cover }),
					/* @__PURE__ */ p("div", {
						className: "ora-inline-choices",
						children: [A && j.filter((t) => t.type === "harvest" && t.cell === K.key && C.owner === e.turn).map((t, n) => /* @__PURE__ */ p("button", {
							onClick: () => W(t),
							children: [
								u(K.cover === "moor" ? J.cut : J.fell),
								" · ",
								t.type === "harvest" && (t.marker === "joker" ? u(J.joker) : u(Y[t.marker])),
								" · ",
								t.type === "harvest" && he(e, t.marker)
							]
						}, n)), A && j.filter((e) => e.type === "use" && e.owner === C.owner && e.cell === C.cell).map((t, n) => t.type === "use" && /* @__PURE__ */ p("button", {
							onClick: () => W(t),
							children: [/* @__PURE__ */ f(mt, {
								prior: t.clergy === 0,
								color: U(t.owner)
							}), /* @__PURE__ */ p("span", { children: [u(t.clergy === 0 ? J.prior : J.lay), C.owner !== e.turn && /* @__PURE__ */ f("small", { children: t.gift === "coin" ? u(J.coinGift, { n: ge(e) }) : u(t.gift === "wine" ? J.wineGift : J.whiskeyGift) })] })]
						}, n))]
					})
				]
			}),
			me && /* @__PURE__ */ f(Lt, {
				title: u(b[me].nameKey),
				close: () => L(null),
				children: /* @__PURE__ */ f(vt, { id: me })
			}),
			re && /* @__PURE__ */ f(Lt, {
				title: u(J.wonders),
				close: () => O(!1),
				children: /* @__PURE__ */ p("div", {
					className: "ora-wonder-grid",
					children: [z.wonders.map((t, n) => /* @__PURE__ */ f(xt, {
						id: t,
						state: e,
						estate: z
					}, `owned${n}`)), e.wonderSupply.map((t) => /* @__PURE__ */ f(xt, {
						id: t,
						state: e,
						estate: z
					}, t))]
				})
			}),
			w && /* @__PURE__ */ p(Lt, {
				title: u(Y[w]),
				close: () => T(null),
				children: [/* @__PURE__ */ f(Z, { good: w }), /* @__PURE__ */ f("div", {
					className: "ora-inline-choices",
					children: A && [
						"grain",
						"coin",
						"coin5",
						"wine",
						"whiskey"
					].includes(w) && [1, Math.floor((le.stock[w] ?? 0) / (w === "coin" ? 5 : 1))].filter((e, t, n) => e > 0 && n.indexOf(e) === t).map((t) => /* @__PURE__ */ p("button", {
						disabled: !$(e, {
							type: "exchange",
							from: w,
							count: t
						}),
						onClick: () => W({
							type: "exchange",
							from: w,
							count: t
						}),
						children: [
							u(J.exchange),
							" · ",
							t
						]
					}, t))
				})]
			}),
			P && /* @__PURE__ */ p(Lt, {
				title: u(J.payment),
				close: () => fe(null),
				children: [
					/* @__PURE__ */ f(vt, { id: P.building }),
					/* @__PURE__ */ f(Rt, {
						label: `${b[P.building].food} ${u(J.food)}`,
						value: P.food,
						max: le.stock,
						goods: E.filter((e) => !!x[e]),
						onChange: (e) => fe({
							...P,
							food: e
						})
					}),
					/* @__PURE__ */ f(Rt, {
						label: `${b[P.building].energy} ${u(J.energy)}`,
						value: P.energy,
						max: le.stock,
						goods: E.filter((e) => !!S[e]),
						onChange: (e) => fe({
							...P,
							energy: e
						})
					}),
					/* @__PURE__ */ f("button", {
						className: "ora-primary",
						disabled: !$(e, P),
						onClick: () => W(P),
						children: u(J.confirm)
					})
				]
			}),
			te && /* @__PURE__ */ f(Lt, {
				title: u(J.log),
				close: () => ne(!1),
				children: /* @__PURE__ */ f("ol", {
					className: "ora-log",
					children: e.log.map((e, t) => /* @__PURE__ */ p("li", { children: [
						B(e.rid),
						" · ",
						e.source && b[e.source] ? u(b[e.source].nameKey) : e.kind === "round" ? u(J.round, { n: e.value }) : e.source && e.source in Y ? u(Y[e.source]) : u(J.effect),
						/* @__PURE__ */ f(ft, { stock: e.goods })
					] }, t))
				})
			}),
			de && /* @__PURE__ */ p("div", {
				className: "ora-selected-card",
				children: [/* @__PURE__ */ f("span", { children: u(J[k.tile]) }), /* @__PURE__ */ f("button", {
					onClick: () => {
						N(!1), y(null);
					},
					children: u(J.cancel)
				})]
			}),
			(_e || ve) && g && /* @__PURE__ */ p("div", {
				className: "ora-selected-card",
				children: [/* @__PURE__ */ f("span", { children: u(b[g].nameKey) }), /* @__PURE__ */ f("button", {
					onClick: () => _(""),
					children: u(J.cancel)
				})]
			})
		]
	});
}
function jt({ rid: e, ...t }) {
	let { ref: n } = c(`seat:${e}`);
	return /* @__PURE__ */ f("button", {
		ref: n,
		...t
	});
}
function Mt({ rid: e, index: t, color: n }) {
	let { ref: r } = c(`available:${e}:${t}`);
	return /* @__PURE__ */ f("span", {
		ref: r,
		children: /* @__PURE__ */ f(mt, {
			prior: t === 0,
			color: n
		})
	});
}
function Nt({ owner: e, index: t, color: n, name: r, position: i }) {
	let { ref: a } = c(`clergy:${e}:${t}`);
	return /* @__PURE__ */ p("span", {
		ref: a,
		className: "ora-cell-clergy",
		title: r,
		style: { right: 3 + i * 24 },
		children: [/* @__PURE__ */ f(mt, {
			prior: t === 0,
			color: n
		}), /* @__PURE__ */ f("small", { children: r })]
	});
}
function Pt({ estate: e, onCell: t, valid: n = () => !1, selectedCells: r = [], color: i = () => "#7a4930", name: a = (e) => e, lands: o = [], onLand: s }) {
	let c = [...e.cells, ...o.flatMap((e) => Re(e.tile, e.side, e.x, e.y))], l = Math.min(...c.map((e) => e.x)), u = Math.max(...c.map((e) => e.x)), d = Math.floor(Math.min(...c.map((e) => e.y))), m = Math.ceil(Math.max(...c.map((e) => e.y)));
	return /* @__PURE__ */ p("div", {
		className: "ora-estate",
		style: {
			"--ora-columns": u - l + 1,
			"--ora-rows": m - d + 1,
			gridTemplateColumns: `repeat(${u - l + 1}, minmax(0, 1fr))`,
			gridTemplateRows: `repeat(${m - d + 1}, minmax(0, 1fr))`
		},
		children: [e.cells.map((o) => /* @__PURE__ */ f(Ft, {
			cell: o,
			rid: e.rid,
			row: Math.floor(o.y) - d + 1,
			col: o.x - l + 1,
			available: n(o),
			selected: r.includes(o.key),
			onClick: () => t?.(o),
			color: i,
			name: a
		}, o.key)), o.map((e) => /* @__PURE__ */ p("button", {
			className: "ora-land-target",
			style: {
				gridColumn: e.x - l + 1,
				gridRow: e.y - d + 1
			},
			onClick: () => s?.(e),
			"aria-label": `${e.x}, ${e.y}`,
			children: [/* @__PURE__ */ f(ht, {}), /* @__PURE__ */ f("span", { children: "＋" })]
		}, `${e.tile}:${e.side}:${e.x}:${e.y}`))]
	});
}
function Ft({ cell: e, rid: t, col: n, row: r, available: i, selected: a, onClick: s, color: l, name: u }) {
	let d = o(), { ref: m } = c(`cell:${t}:${e.key}`), h = e.building ? b[e.building] : null;
	return /* @__PURE__ */ p("button", {
		ref: m,
		type: "button",
		className: `ora-cell ora-terrain-${e.terrain}${e.cover ? " ora-covered" : ""}${a ? " ora-selected" : ""}`,
		style: {
			gridColumn: n,
			gridRow: `${r} / span ${e.terrain === "mountain" ? 2 : 1}`
		},
		onClick: s,
		"aria-label": `${h ? d(h.nameKey) : e.cover ? d(Qe[e.cover]) : d(Ze[e.terrain])} (${e.x}, ${e.y})`,
		children: [
			(e.cover || e.building) && /* @__PURE__ */ f("img", {
				className: "ora-cell-art",
				src: ut(e.cover ?? e.building),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ f("span", {
				className: `ora-cell-title${h?.cloister ? " ora-cloister-title" : ""}`,
				children: h ? d(h.nameKey) : e.cover ? d(Qe[e.cover]) : d(Ze[e.terrain])
			}),
			e.cover && /* @__PURE__ */ f("span", {
				className: "ora-cover-conversion",
				children: /* @__PURE__ */ f(lt, { cover: e.cover })
			}),
			h && /* @__PURE__ */ p("span", {
				className: "ora-cell-values",
				children: [/* @__PURE__ */ f(pt, { value: h.economic }), /* @__PURE__ */ f(pt, {
					value: h.dwelling,
					dwelling: !0
				})]
			}),
			[...e.clergy ? [e.clergy] : [], ...e.bonusClergy].map((e, t) => /* @__PURE__ */ f(Nt, {
				owner: e.owner,
				index: e.index,
				position: t,
				color: l(e.owner),
				name: u(e.owner)
			}, `${e.owner}:${e.index}`)),
			i && /* @__PURE__ */ f(ht, {})
		]
	});
}
function It({ state: e }) {
	let t = o(), { ref: n } = c("wheel"), r = Object.keys(e.wheel).filter((t) => e.wheel[t] >= 0);
	return /* @__PURE__ */ p("div", {
		ref: n,
		className: "ora-production",
		children: [/* @__PURE__ */ p("svg", {
			viewBox: "0 0 110 110",
			className: "ora-wheel",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ f("circle", {
					cx: "55",
					cy: "55",
					r: "49",
					fill: "#e4cf91",
					stroke: "#6a5833",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "55",
					cy: "55",
					r: "31",
					fill: "#f3e7bd",
					stroke: "#b7a36e"
				}),
				Array.from({ length: 13 }, (t, n) => {
					let r = (n / 13 - .25) * Math.PI * 2;
					return /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("path", {
						d: `M${55 + Math.cos(r) * 32} ${55 + Math.sin(r) * 32}L${55 + Math.cos(r) * 48} ${55 + Math.sin(r) * 48}`,
						stroke: "#998557"
					}), /* @__PURE__ */ f("text", {
						x: 55 + Math.cos(r + Math.PI / 13) * 40,
						y: 58 + Math.sin(r + Math.PI / 13) * 40,
						fontSize: "9",
						textAnchor: "middle",
						fill: "#493b24",
						children: (e.config.length === "normal" && e.players.length === 2 ? w : ee)[n]
					})] }, n);
				}),
				/* @__PURE__ */ f("g", {
					transform: `rotate(${e.round % 13 * 360 / 13} 55 55)`,
					className: "ora-wheel-hand",
					children: /* @__PURE__ */ f("path", {
						d: "M52 55 55 5 58 55Z",
						fill: "#765439"
					})
				}),
				/* @__PURE__ */ f("circle", {
					cx: "55",
					cy: "55",
					r: "5",
					fill: "#c89a3e"
				})
			]
		}), /* @__PURE__ */ f("div", {
			className: "ora-wheel-readings",
			children: r.map((n) => /* @__PURE__ */ p("span", { children: [n === "joker" ? /* @__PURE__ */ f("span", {
				className: "ora-joker",
				title: t(J.joker),
				children: "✦"
			}) : /* @__PURE__ */ f(Z, { good: n }), /* @__PURE__ */ f("b", { children: he(e, n) })] }, n))
		})]
	});
}
function Lt({ title: e, close: t, children: r }) {
	let a = o(), s = i(null), c = i(t);
	return n(() => {
		c.current = t;
	}, [t]), n(() => {
		let e = document.activeElement, t = s.current;
		t?.querySelector("button")?.focus();
		let n = (e) => {
			if (e.key === "Escape") {
				e.preventDefault(), c.current();
				return;
			}
			if (e.key !== "Tab" || !t) return;
			let n = [...t.querySelectorAll("button:not(:disabled),input:not(:disabled),[tabindex=\"0\"]")], r = n[0], i = n[n.length - 1];
			e.shiftKey && document.activeElement === r ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), r?.focus());
		};
		return document.addEventListener("keydown", n), () => {
			document.removeEventListener("keydown", n), e?.focus();
		};
	}, []), /* @__PURE__ */ f("div", {
		className: "ora-modal-backdrop",
		onClick: t,
		children: /* @__PURE__ */ p("section", {
			ref: s,
			className: "ora-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("h2", { children: e }), /* @__PURE__ */ f("button", {
				onClick: t,
				children: a(J.close)
			})] }), /* @__PURE__ */ f("div", {
				className: "ora-modal-body",
				children: r
			})]
		})
	});
}
function Rt({ label: e, value: t, max: n, onChange: r, goods: i = E }) {
	let a = o();
	return /* @__PURE__ */ p("fieldset", {
		className: "ora-payment",
		children: [/* @__PURE__ */ f("legend", { children: e }), /* @__PURE__ */ f("div", { children: i.filter((e) => (n[e] ?? 0) > 0).map((i) => /* @__PURE__ */ p("label", { children: [/* @__PURE__ */ f(Z, { good: i }), /* @__PURE__ */ f("input", {
			"aria-label": `${e}: ${a(Y[i])}`,
			type: "number",
			inputMode: "numeric",
			min: "0",
			max: n[i] ?? 0,
			value: t[i] ?? 0,
			onChange: (e) => r({
				...t,
				[i]: Math.max(0, Math.min(n[i] ?? 0, Math.floor(Number(e.target.value) || 0)))
			})
		})] }, i)) })]
	});
}
function zt({ state: e, task: t, actions: n, onAction: r }) {
	let i = o(), s = I(e, e.turn), c = n.filter((e) => e.type === "resolve"), [l, u] = a(() => c[0] ?? Q());
	if (t.kind === "production") return /* @__PURE__ */ f("div", {
		className: "ora-production-choices",
		children: t.goods.map((n) => /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f(Z, { good: n }), [n, "joker"].filter((e) => t.mode !== "jokerOnly" || e === "joker").map((t) => /* @__PURE__ */ p("button", {
			disabled: !$(e, Q({
				output: n,
				marker: t
			})),
			onClick: () => r(Q({
				output: n,
				marker: t
			})),
			children: [
				i(t === "joker" ? J.joker : Y[n]),
				" ",
				/* @__PURE__ */ f("b", { children: he(e, t) })
			]
		}, t))] }, n))
	});
	if (t.kind === "prior" || t.kind === "neutralUse") return /* @__PURE__ */ f("div", {
		className: "ora-inline-choices",
		children: c.map((n, a) => /* @__PURE__ */ p("button", {
			onClick: () => r(n),
			children: [/* @__PURE__ */ f(mt, { prior: !0 }), t.kind === "prior" ? i(J.use) : i(b[e.neutral.cells.find((e) => e.key === n.target).building].nameKey)]
		}, a))
	});
	if (t.kind === "swap") return /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("p", { children: i(J.swap) }),
		/* @__PURE__ */ f("div", {
			className: "ora-inline-choices",
			children: Object.keys(e.wheel).filter((t) => e.wheel[t] >= 0).map((t) => /* @__PURE__ */ p("button", {
				className: l.swap.includes(t) ? "ora-selected" : "",
				onClick: () => u({
					...l,
					swap: l.swap.includes(t) ? l.swap.filter((e) => e !== t) : [...l.swap, t].slice(-2)
				}),
				children: [
					t === "joker" ? i(J.joker) : /* @__PURE__ */ f(Z, { good: t }),
					" ",
					he(e, t)
				]
			}, t))
		}),
		/* @__PURE__ */ f("button", {
			className: "ora-primary",
			disabled: !$(e, l),
			onClick: () => r(l),
			children: i(J.confirm)
		})
	] });
	if (t.kind === "wonder") return /* @__PURE__ */ f("div", {
		className: "ora-wonder-grid",
		children: c.map((t) => /* @__PURE__ */ f(xt, {
			id: t.option,
			state: e,
			estate: s,
			onClick: () => r(t)
		}, t.option))
	});
	if (t.kind === "points") return /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ p("p", { children: [
			t.amount,
			" ",
			i(J.points)
		] }),
		/* @__PURE__ */ f(Rt, {
			label: i(J.gain),
			value: l.inputs,
			max: {
				book: Math.floor(t.amount / 2),
				ceramic: Math.floor(t.amount / 3),
				ornament: Math.floor(t.amount / 4),
				reliquary: Math.floor(t.amount / 8)
			},
			onChange: (e) => u({
				...l,
				inputs: e
			})
		}),
		/* @__PURE__ */ f("button", {
			className: "ora-primary",
			disabled: !$(e, l),
			onClick: () => r(l),
			children: i(J.confirm)
		})
	] });
	if (t.kind !== "trade") return null;
	let m = t.recipes[l.option] ?? t.recipes[0], h = (e, n) => {
		let r = t.recipes[e], i = Object.fromEntries(Object.entries(r.cost).map(([e, t]) => [e, t * n]));
		u(wt(s, {
			...l,
			option: e,
			count: n
		}, t.mode === "forge" ? { coin: 5 + (n - 1) * 10 } : i, r.food * n, r.energy * n, r.points * n) ?? {
			...l,
			option: e,
			count: n
		});
	};
	return /* @__PURE__ */ p("div", {
		className: "ora-trade-form",
		children: [
			/* @__PURE__ */ f(gt, { item: t }),
			t.recipes.length > 1 && /* @__PURE__ */ f("div", {
				className: "ora-inline-choices",
				children: t.recipes.map((e, t) => /* @__PURE__ */ p("button", {
					className: l.option === t ? "ora-selected" : "",
					onClick: () => h(t, l.count),
					children: [
						/* @__PURE__ */ f(ft, { stock: e.cost }),
						e.food || e.energy ? `${e.food || e.energy} ${i(e.food ? J.food : J.energy)}` : null,
						/* @__PURE__ */ f("span", { children: "→" }),
						/* @__PURE__ */ f(ft, { stock: e.gain })
					]
				}, t))
			}),
			t.limit > 1 && /* @__PURE__ */ p("label", {
				className: "ora-count",
				children: [i(J.count), /* @__PURE__ */ f("input", {
					type: "number",
					min: "1",
					max: t.limit,
					value: l.count,
					onChange: (e) => h(l.option, Math.max(1, Math.min(t.limit, Math.floor(Number(e.target.value) || 1))))
				})]
			}),
			t.different > 0 && /* @__PURE__ */ f(Rt, {
				label: i(J.different, { n: t.different }),
				value: l.inputs,
				max: Object.fromEntries(E.filter((e) => (s.stock[e] ?? 0) > 0).map((e) => [e, 1])),
				onChange: (e) => u({
					...l,
					inputs: e
				})
			}),
			m.food > 0 && /* @__PURE__ */ f(Rt, {
				label: `${m.food * l.count} ${i(J.food)}`,
				value: l.food,
				max: s.stock,
				goods: E.filter((e) => !!x[e]),
				onChange: (e) => u({
					...l,
					food: e
				})
			}),
			m.energy > 0 && /* @__PURE__ */ f(Rt, {
				label: `${m.energy * l.count} ${i(J.energy)}`,
				value: l.energy,
				max: s.stock,
				goods: E.filter((e) => !!S[e]),
				onChange: (e) => u({
					...l,
					energy: e
				})
			}),
			m.points > 0 && /* @__PURE__ */ f(Rt, {
				label: `${m.points * l.count} ${i(J.points)}`,
				value: l.points,
				max: s.stock,
				goods: E.filter((e) => !!C[e]),
				onChange: (e) => u({
					...l,
					points: e
				})
			}),
			["basic", "twoBasic"].includes(t.mode) && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("p", { children: i(J.output) }),
				/* @__PURE__ */ f("div", {
					className: "ora-inline-choices",
					children: D.map((e) => /* @__PURE__ */ f("button", {
						className: l.output === e ? "ora-selected" : "",
						onClick: () => u({
							...l,
							output: e
						}),
						children: /* @__PURE__ */ f(Z, { good: e })
					}, e))
				}),
				t.mode === "twoBasic" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("p", { children: i(J.secondary) }), /* @__PURE__ */ f("div", {
					className: "ora-inline-choices",
					children: D.map((e) => /* @__PURE__ */ f("button", {
						className: l.secondary === e ? "ora-selected" : "",
						onClick: () => u({
							...l,
							secondary: e
						}),
						children: /* @__PURE__ */ f(Z, { good: e })
					}, e))
				})] })
			] }),
			/* @__PURE__ */ f("button", {
				className: "ora-primary",
				disabled: !$(e, l),
				onClick: () => r(l),
				children: i(J.confirm)
			})
		]
	});
}
//#endregion
//#region src/games/oraetlabora/bot.ts
var Bt = {
	resource: 1,
	building: 3,
	space: .7,
	future: .8,
	clergy: 1.3,
	settlement: 1
}, Vt = {
	wood: 1.7,
	clay: 1.6,
	peat: .8,
	grain: 1.1,
	livestock: 1.4,
	coin: 1.1,
	coin5: 5.3,
	straw: 1,
	stone: 3,
	peatcoal: 1.4,
	meat: 2.4,
	flour: 1.1,
	bread: 2,
	grapes: 1.2,
	wine: 2.2,
	malt: 1.2,
	beer: 3,
	whiskey: 3,
	book: 2.5,
	ceramic: 3.5,
	ornament: 4.5,
	reliquary: 8.5
};
function Ht(e, t, n) {
	let r = I(e, t), i = e.settlementStage / 4, a = Ye(e, r).total;
	for (let e of E) {
		let t = r.stock[e] ?? 0;
		a += n.resource * Vt[e] * (Math.min(t, 8) + Math.min(12, Math.max(0, t - 8)) * .03) * (1 - i * .65);
	}
	let o = r.cells.filter((e) => e.building && !e.building.startsWith("S"));
	a += n.building * o.length + n.clergy * V(e, t).length;
	let s = [...e.market, ...e.remaining], c = r.cells.filter((e) => !e.building && [
		"coast",
		"plains",
		"hillside"
	].includes(e.terrain) && o.some((t) => b[t.building].cloister && z(t, e))).length;
	a -= Math.max(0, Math.min(2, s.filter((e) => b[e].cloister).length) - c) * 28, s.some((e) => b[e].terrain.length === 1 && b[e].terrain[0] === "mountain") && !r.cells.some((e) => e.terrain === "mountain") && (a -= 25), a += n.space * r.cells.filter((e) => !e.building && !e.cover).length;
	let l = e.market.filter((e) => r.cells.some((t) => q(r, e, t))).map((e) => {
		let t = b[e], i = Object.entries(t.cost).reduce((e, [t, n]) => e + Math.max(0, n - (t === "coin" ? L(r.stock) : r.stock[t] ?? 0)) * Vt[t], 0);
		return (n.building + t.economic * .5) * Math.exp(-i / 4);
	}).sort((e, t) => t - e);
	if (a += (l[0] ?? 0) * .7, e.players.length === 2 && e.settlementStage === 4) {
		a -= e.market.length * 80;
		let t = e.market.filter((e) => r.cells.some((t) => q(r, e, t))).map((e) => {
			let t = b[e].cost;
			return Object.entries(t).reduce((e, [t, n]) => e + Math.max(0, n - (t === "coin" ? L(r.stock) : r.stock[t] ?? 0)) * Vt[t], 0);
		});
		t.length && (a -= Math.min(...t) * 12);
	}
	let u = Math.max(0, ...e.market.map((e) => b[e].cost.wood ?? 0));
	(r.stock.wood ?? 0) < u && (a += Math.min(2, r.cells.filter((e) => e.cover === "forest").length) * 2);
	for (let t of [
		"coast",
		"mountain",
		"hillside"
	]) r.cells.some((e) => e.terrain === t) || (a -= n.space * e.market.filter((e) => b[e].terrain.includes(t)).length * 1.5);
	for (let e of r.cells.filter((e) => e.building?.startsWith("S"))) a += n.settlement * r.cells.filter((t) => t.building && z(e, t)).length;
	return a;
}
function Ut(e, t) {
	let n = Xe.reduce(e, t, { by: H(e) });
	return "state" in n ? n.state : null;
}
function Wt(e) {
	return Dt(e).filter((t) => {
		if (t.type === "exchange" && (t.from === "coin" || t.from === "coin5")) {
			let n = I(e, e.turn);
			if (!e.tasks[0]?.different || (n.stock[t.from === "coin" ? "coin5" : "coin"] ?? 0) > 0 || t.count !== 1) return !1;
		}
		let n = e.tasks[0];
		if (t.type !== "resolve" || n?.kind !== "copy") return !0;
		let r = t.owner ? `${t.owner}:${t.target}:` : "";
		return !r || !n.path.some((e) => e.startsWith(r));
	});
}
function Gt(e, t, n, r) {
	let i = Ht(e, t, n);
	if (e.turn !== t || e.phase !== "effect" || r <= 0 || !n.future) return i;
	let a = Wt(e).map((t) => Ut(e, t)).filter((e) => !!e).map((e) => ({
		state: e,
		value: Ht(e, t, n)
	})).sort((e, t) => t.value - e.value).slice(0, 3);
	return Math.max(i, ...a.map((e) => i + (Gt(e.state, t, n, r - 1) - i) * n.future));
}
function Kt(e = Bt) {
	return ({ public: t }, n) => {
		if (H(t) !== n.rid || t.phase === "done") return null;
		let r = Wt(t);
		if (!r.length) return null;
		let i = n.difficulty === "weak", a = r[0], o = -Infinity;
		for (let n of r) {
			let r = Ut(t, n);
			if (!r) continue;
			let s = Gt(r, t.turn, e, i ? 1 : 3);
			if (n.type === "exchange") {
				let n = Wt(r).filter((e) => e.type !== "exchange").map((e) => Ut(r, e)).filter((e) => !!e);
				s = Math.max(s, ...n.map((n) => Gt(n, t.turn, e, i ? 1 : 3))) - .05;
			}
			n.type === "land" && I(t, t.turn).cells.filter((e) => !e.cover && !e.building).length > 5 && (s -= 8), n.type === "skip" && (s -= .01), n.type === "end" && (s -= t.phase === "settlement" ? .02 : 0), s > o && (o = s, a = n);
		}
		return { action: a };
	};
}
var qt = Kt(), Jt = (e, t, n) => e.type === "build" || e.type === "settle" ? `${n("games.oraetlabora.build")} ${n(b[e.building].nameKey)}` : e.type === "harvest" ? n(e.marker === "peat" ? "games.oraetlabora.cut" : "games.oraetlabora.fell") : e.type === "end" ? n("games.oraetlabora.end") : e.type === "skip" ? n("games.oraetlabora.skip") : e.type === "land" ? n("games.oraetlabora.land") : n("games.oraetlabora.effect");
//#endregion
//#region src/games/oraetlabora/fx.tsx
function Yt({ cell: e, at: t }) {
	let n = o(), r = e.building ? b[e.building] : null;
	return /* @__PURE__ */ p("div", {
		className: `ora-cell ora-terrain-${e.terrain}${e.cover ? " ora-covered" : ""}`,
		style: {
			width: t.w,
			height: t.h
		},
		children: [
			(e.cover || e.building) && /* @__PURE__ */ f("img", {
				className: "ora-cell-art",
				src: ut(e.cover ?? e.building),
				alt: ""
			}),
			/* @__PURE__ */ f("span", {
				className: `ora-cell-title${r?.cloister ? " ora-cloister-title" : ""}`,
				children: r ? n(r.nameKey) : e.cover ? n(Qe[e.cover]) : n(Ze[e.terrain])
			}),
			r && /* @__PURE__ */ p("span", {
				className: "ora-cell-values",
				children: [/* @__PURE__ */ f(pt, { value: r.economic }), /* @__PURE__ */ f(pt, {
					value: r.dwelling,
					dwelling: !0
				})]
			}),
			e.cover && /* @__PURE__ */ f("span", {
				className: "ora-cover-conversion",
				children: /* @__PURE__ */ f(lt, { cover: e.cover })
			})
		]
	});
}
function Xt({ at: e, cell: t }) {
	let r = i(null);
	return n(() => {
		let e = r.current?.animate([{
			transform: "translateY(0) rotate(0)",
			opacity: 1
		}, {
			transform: "translateY(-28px) rotate(-4deg)",
			opacity: 0
		}], {
			duration: 340,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ f("div", {
		ref: r,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y
		},
		children: /* @__PURE__ */ f(Yt, {
			cell: t,
			at: e
		})
	});
}
var Zt = (e, t, n) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), Qt = { "ora-change"(e, t) {
	let n = e.data;
	if (!n) return null;
	let r = [], i = [], a = (e) => {
		let n = t.anchor(e);
		return n && n.w > 0 && n.h > 0 ? n : null;
	};
	for (let [e, t] of n.placed.entries()) {
		let n = `cell:${t.rid}:${t.cell.key}`, o = a(n), s = a(`market:${t.cell.building}`) ?? a("catalog") ?? a(`seat:${t.rid}`);
		if (!o || !s) continue;
		i.push(n);
		let c = Math.min(1, 100 / o.w, 156 / o.h), l = Zt(s, o.w * c, o.h * c);
		r.push(/* @__PURE__ */ f(h, {
			from: l,
			to: o,
			ms: 430,
			children: /* @__PURE__ */ f(Yt, {
				cell: t.cell,
				at: l
			})
		}, `place${e}`));
	}
	for (let [e, i] of n.removed.entries()) {
		let n = t.anchor(`cell:${i.rid}:${i.cell.key}`);
		n && r.push(/* @__PURE__ */ f(Xt, {
			at: n,
			cell: i.cell
		}, `clear${e}`));
	}
	for (let [e, a] of n.clergy.entries()) {
		let n = t.anchor(`cell:${a.rid}:${a.cell}`), o = t.anchor(`seat:${a.owner}`);
		if (!n || !o) continue;
		let c = a.returning ? `available:${a.owner}:${a.index}` : `clergy:${a.owner}:${a.index}`, l = t.anchor(c) ?? (a.returning ? Zt(o, 20, 36) : {
			x: n.x + n.w - 30,
			y: n.y + n.h - 52,
			w: 26,
			h: 45
		});
		t.anchor(c) && i.push(c);
		let u = a.returning ? Zt(n, 26, 45) : Zt(o, 20, 36);
		r.push(/* @__PURE__ */ f(h, {
			from: u,
			to: l,
			ms: 360,
			children: /* @__PURE__ */ f("span", {
				style: {
					display: "block",
					width: 26,
					height: 45
				},
				children: /* @__PURE__ */ f(mt, {
					prior: a.index === 0,
					color: s[t.member(a.owner)?.colorIndex ?? 0].hex
				})
			})
		}, `clergy${e}`));
	}
	for (let [e, t] of n.goods.entries()) {
		let i = a(`good:${t.rid}:${t.good}`) ?? a(`seat:${t.rid}`), o = a(n.source) ?? a(`seat:${t.rid}`);
		i && (t.delta > 0 && o && r.push(/* @__PURE__ */ f(h, {
			from: Zt(o, 30, 30),
			to: Zt(i, 30, 30),
			ms: 380,
			children: /* @__PURE__ */ f("span", {
				style: {
					display: "block",
					width: 30,
					height: 30
				},
				children: /* @__PURE__ */ f(Z, { good: t.good })
			})
		}, `good${e}`)), r.push(/* @__PURE__ */ f(m, {
			at: i,
			ms: 650,
			children: /* @__PURE__ */ p("span", {
				className: "ora-fx-delta",
				children: [
					t.delta > 0 ? "+" : "−",
					Math.abs(t.delta),
					" ",
					/* @__PURE__ */ f(Z, { good: t.good })
				]
			})
		}, `delta${e}`)));
	}
	if (!r.length) {
		let n = t.anchor(`seat:${e.rid}`);
		n && r.push(/* @__PURE__ */ f(g, {
			at: n,
			ms: 400
		}, "seat"));
	}
	return r.length ? {
		ms: 660,
		node: r,
		hide: i
	} : null;
} };
//#endregion
//#region src/games/oraetlabora/game-over.tsx
function $t({ public: e, result: t, members: r, myRid: c, hintCount: l, onPlayAgain: u, onBackToLobby: d }) {
	let m = e, h = o(), [g, _] = a(!0), [v, y] = a(null), b = i(null), x = i(null), S = i(null), C = (e) => r.find((t) => t.rid === e)?.name ?? e, ee = Object.fromEntries(m.players.map((e) => [e.rid, Ye(m, e)])), w = [
		["goodsScore", "goods"],
		["economicScore", "economic"],
		["dwellingScore", "dwelling"],
		["waterScore", "water"],
		["wondersScore", "wonders"]
	];
	n(() => {
		x.current?.focus({ preventScroll: !0 });
	}, []);
	let T = (e) => {
		_(e), requestAnimationFrame(() => (e ? x : S).current?.focus({ preventScroll: !0 }));
	}, te = m.players.length === 1 ? h(t.winner.length ? J.soloWin : J.soloLoss) : t.winner.map((e) => h(J.winner, { name: C(e) })).join(" · ");
	return /* @__PURE__ */ p("div", {
		className: "ora-endgame",
		children: [
			/* @__PURE__ */ f("div", {
				className: "ora-endgame-board",
				inert: g,
				children: /* @__PURE__ */ f(kt, {
					public: m,
					members: r,
					myRid: c,
					send: () => {}
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "ora-result-overlay",
				hidden: !g,
				children: /* @__PURE__ */ p("section", {
					ref: b,
					inert: v !== null,
					className: "ora-result-ledger",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": h(J.result),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), T(!1)), e.key === "Tab") {
							let t = [...b.current?.querySelectorAll("button:not(:disabled)") ?? []], n = t[0], r = t.at(-1);
							e.shiftKey && document.activeElement === n && (e.preventDefault(), r?.focus()), !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
						}
					},
					children: [
						/* @__PURE__ */ p("header", {
							className: "ora-result-heading",
							children: [/* @__PURE__ */ p("div", { children: [
								/* @__PURE__ */ f("span", { children: "Ora et Labora" }),
								/* @__PURE__ */ f("h1", { children: h(J.result) }),
								/* @__PURE__ */ f("p", { children: te })
							] }), /* @__PURE__ */ f("button", {
								ref: x,
								onClick: () => T(!1),
								children: h(J.review)
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "ora-result-body",
							children: [
								m.players.length === 1 && /* @__PURE__ */ f("p", { children: h(J.soloGoal) }),
								l !== void 0 && /* @__PURE__ */ f("p", { children: h("session.hint.usedCount", { n: l }) }),
								/* @__PURE__ */ f("div", {
									className: "ora-result-scroll",
									children: /* @__PURE__ */ p("table", {
										className: "ora-result-table",
										children: [
											/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
												scope: "col",
												children: h(J.points)
											}), t.ranking.map((e) => /* @__PURE__ */ p("th", {
												scope: "col",
												style: { "--ora-player": s[r.find((t) => t.rid === e)?.colorIndex ?? 0].hex },
												children: [/* @__PURE__ */ p("span", { children: [C(e), e === c && /* @__PURE__ */ f("small", { children: h("lobby.you") })] }), !!t.autopilot?.[e] && /* @__PURE__ */ f("small", { children: h("games.oraetlabora.autopilot", { n: Math.round(t.autopilot[e] * 100) }) })]
											}, e))] }) }),
											/* @__PURE__ */ f("tbody", { children: w.map(([e, n]) => /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
												scope: "row",
												children: h(J[e])
											}), t.ranking.map((e) => /* @__PURE__ */ f("td", { children: ee[e]?.[n] ?? "—" }, e))] }, e)) }),
											/* @__PURE__ */ f("tfoot", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
												scope: "row",
												children: h(J.total)
											}), t.ranking.map((e) => /* @__PURE__ */ f("td", {
												"data-winner": t.winner.includes(e) || void 0,
												children: t.scores?.[e] ?? ee[e]?.total ?? "—"
											}, e))] }) })
										]
									})
								})
							]
						}),
						/* @__PURE__ */ p("footer", {
							className: "ora-result-actions",
							children: [
								d && /* @__PURE__ */ f("button", {
									onClick: () => y("lobby"),
									children: h(J.lobby)
								}),
								u && /* @__PURE__ */ f("button", {
									className: "ora-primary",
									onClick: () => y("again"),
									children: h(J.again)
								}),
								!u && !d && /* @__PURE__ */ f("p", { children: h("session.result.waitHost") })
							]
						})
					]
				})
			}),
			!g && /* @__PURE__ */ f("div", {
				className: "ora-result-restore",
				children: /* @__PURE__ */ f("button", {
					ref: S,
					onClick: () => T(!0),
					children: h(J.result)
				})
			}),
			v && /* @__PURE__ */ f(Lt, {
				title: h(v === "again" ? "games.oraetlabora.confirmAgain" : "games.oraetlabora.confirmLobby"),
				close: () => y(null),
				children: /* @__PURE__ */ p("div", {
					className: "ora-inline-choices",
					children: [/* @__PURE__ */ f("button", {
						onClick: () => {
							let e = v === "again" ? u : d;
							y(null), e?.();
						},
						children: h(J.confirm)
					}), /* @__PURE__ */ f("button", {
						onClick: () => y(null),
						children: h(J.cancel)
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/games/oraetlabora/options.tsx
function en({ value: e, onChange: t }) {
	let n = o(), r = ae.safeParse(e), i = r.success ? r.data : ae.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ f(v, {
				title: n(J.country),
				columns: 2,
				children: ["france", "ireland"].map((e) => /* @__PURE__ */ f(_, {
					name: "ora-country",
					value: e,
					checked: i.country === e,
					label: n(J[e]),
					accent: y.accent,
					onChange: () => t({
						...i,
						country: e,
						loamy: e === "france" && i.loamy
					})
				}, e))
			}),
			/* @__PURE__ */ f(v, {
				title: n(J.length),
				children: [
					"normal",
					"short",
					"long"
				].map((e) => /* @__PURE__ */ f(_, {
					name: "ora-length",
					value: e,
					checked: i.length === e,
					label: n(J[e]),
					accent: y.accent,
					onChange: () => t({
						...i,
						length: e
					})
				}, e))
			}),
			["loamy", "wonders"].filter((e) => e !== "loamy" || i.country === "france").map((e) => /* @__PURE__ */ f(v, {
				title: n(J[e]),
				columns: 2,
				children: [!0, !1].map((r) => /* @__PURE__ */ f(_, {
					name: `ora-${e}`,
					value: String(r),
					checked: i[e] === r,
					label: n(r ? J.on : J.off),
					accent: y.accent,
					onChange: () => t({
						...i,
						[e]: r
					})
				}, String(r)))
			}, e))
		]
	});
}
//#endregion
//#region src/games/oraetlabora/guide.tsx
function tn() {
	let e = o();
	return /* @__PURE__ */ p("div", {
		className: "ora-guide",
		children: [
			/* @__PURE__ */ p("div", {
				className: "ora-guide-harvest",
				children: [/* @__PURE__ */ f(lt, { cover: "forest" }), /* @__PURE__ */ f(lt, { cover: "moor" })]
			}),
			/* @__PURE__ */ f("p", { children: e("games.oraetlabora.diagramLegend") }),
			/* @__PURE__ */ f("h3", { children: e(J.resources) }),
			/* @__PURE__ */ f("div", {
				className: "ora-guide-goods",
				children: E.map((t) => /* @__PURE__ */ p("div", { children: [
					/* @__PURE__ */ f(Z, { good: t }),
					/* @__PURE__ */ f("span", { children: e(Y[t]) }),
					/* @__PURE__ */ p("span", { children: [
						x[t] && /* @__PURE__ */ f(ot, {
							kind: "food",
							value: x[t]
						}),
						" ",
						S[t] && /* @__PURE__ */ f(ot, {
							kind: "energy",
							value: S[t]
						}),
						" ",
						C[t] && /* @__PURE__ */ f(ot, {
							kind: "points",
							value: C[t]
						})
					] })
				] }, t))
			}),
			/* @__PURE__ */ f("h3", { children: e(J.exchange) }),
			/* @__PURE__ */ p("div", {
				className: "ora-guide-exchanges",
				children: [
					/* @__PURE__ */ p("span", { children: [
						/* @__PURE__ */ f(Z, { good: "grain" }),
						/* @__PURE__ */ f(st, {}),
						/* @__PURE__ */ f(Z, { good: "straw" })
					] }),
					/* @__PURE__ */ p("span", { children: [
						/* @__PURE__ */ f(Z, { good: "coin5" }),
						/* @__PURE__ */ f("span", { children: "⇄" }),
						/* @__PURE__ */ f("span", { children: "5 ×" }),
						/* @__PURE__ */ f(Z, { good: "coin" })
					] }),
					/* @__PURE__ */ p("span", { children: [
						/* @__PURE__ */ f(Z, { good: "wine" }),
						/* @__PURE__ */ f(st, {}),
						/* @__PURE__ */ f(Z, { good: "coin" })
					] }),
					/* @__PURE__ */ p("span", { children: [
						/* @__PURE__ */ f(Z, { good: "whiskey" }),
						/* @__PURE__ */ f(st, {}),
						/* @__PURE__ */ f("span", { children: "2 ×" }),
						/* @__PURE__ */ f(Z, { good: "coin" })
					] })
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/oraetlabora/entry.tsx
var nn = {
	definition: Xe,
	View: kt,
	bot: qt,
	describe: Jt,
	fx: Qt,
	OverView: $t,
	Options: en,
	Guide: tn,
	locales: {
		zh: {
			name: "祈禱與工作",
			desc: "扩展修院领地，经营生产链，并围绕聚落建造繁荣的城镇。",
			invalid: "当前无法执行这项行动，请重新选择。",
			round: "第 {{n}} 轮",
			stage: "阶段 {{stage}}",
			turn: "{{name}} 的回合",
			action: "选择一项行动",
			effect: "完成建筑效果",
			settlement: "建造一座聚落，或结束聚落阶段",
			contract: "选择派出的神职人员",
			done: "终局",
			market: "建筑市场",
			estate: "领地",
			settlements: "聚落",
			resources: "物资",
			production: "生产轮",
			land: "购买土地",
			district: "地区",
			plot: "地块",
			side: "翻面",
			prior: "院长",
			lay: "修士",
			clergy: "神职人员",
			available: "可用",
			occupied: "已占用",
			use: "使用建筑",
			build: "建造",
			harvest: "采集",
			fell: "砍伐森林",
			cut: "挖掘泥炭",
			joker: "万能标记",
			exchange: "额外兑换",
			end: "结束行动",
			endSettlement: "结束聚落阶段",
			skip: "放弃此项效果",
			confirm: "确认",
			cancel: "取消",
			back: "返回",
			close: "关闭",
			details: "建筑详情",
			cost: "建造费用",
			economic: "经济分",
			dwelling: "居住值",
			food: "食物",
			energy: "能量",
			points: "分数",
			payment: "选择支付物资",
			inputs: "投入物资",
			gain: "获得物资",
			count: "次数",
			output: "选择获得的物资",
			secondary: "选择另一种物资",
			marker: "选择生产标记",
			swap: "选择两个生产标记",
			neutral: "中立修院",
			neutralBuild: "将剩余建筑放入中立修院",
			neutralUse: "可付费派出中立院长，使用一座刚建好的建筑",
			chooseSite: "选择领地上的合法位置",
			chooseBuilding: "选择建筑",
			chooseClergy: "选择神职人员",
			chooseTarget: "选择建筑目标",
			contractGift: "支付合约费用",
			coinGift: "支付 {{n}} 枚钱币",
			wineGift: "赠送一份葡萄酒",
			whiskeyGift: "赠送一份威士忌",
			repeat: "最多 {{n}} 次",
			repeatCombined: "以上转换合计最多 {{n}} 次",
			different: "支付 {{n}} 种不同物资，每种一份",
			autoPayment: "建议支付",
			waiting: "等待 {{name}} 行动",
			total: "总分",
			goodsScore: "物资得分",
			economicScore: "建筑与聚落",
			dwellingScore: "聚落居住分",
			waterScore: "水域居住分",
			wondersScore: "奇观",
			wonder: "奇观",
			wonderNumber: "奇观 {{n}}",
			baseWonder: "普通奇观",
			result: "修院编年史",
			review: "查看最终领地",
			winner: "{{name}} 获胜",
			soloWin: "目标达成",
			soloLoss: "继续经营你的修院",
			soloGoal: "单人目标：500 分",
			again: "再来一局",
			lobby: "返回大堂",
			log: "行动记录",
			country: "地区版本",
			france: "法国",
			ireland: "爱尔兰",
			length: "游戏时长",
			normal: "标准",
			short: "短局（3–4 人）",
			long: "长局（2 人）",
			expansions: "官方扩展",
			loamy: "黏土地（法国）",
			wonders: "利斯博恩修院的小奇观",
			on: "启用",
			off: "关闭",
			terrain: {
				plains: "平原",
				hillside: "山坡",
				coast: "海岸",
				water: "水域",
				mountain: "山地"
			},
			cover: {
				forest: "森林",
				moor: "泥炭地"
			},
			goods: {
				wood: "木材",
				clay: "黏土",
				peat: "泥炭",
				grain: "谷物",
				livestock: "牲畜",
				coin: "钱币",
				coin5: "五钱币",
				straw: "稻草",
				stone: "石料",
				peatcoal: "泥炭煤",
				meat: "肉",
				flour: "面粉",
				bread: "面包",
				grapes: "葡萄",
				wine: "葡萄酒",
				malt: "麦芽",
				beer: "啤酒",
				whiskey: "威士忌",
				book: "书籍",
				ceramic: "陶器",
				ornament: "饰物",
				reliquary: "圣物匣"
			},
			buildings: {
				G01: "修道院",
				G02: "修院庭院",
				F03: "谷仓",
				I03: "修院粮仓",
				F04: "风车磨坊",
				I04: "麦芽作坊",
				F05: "面包房",
				I05: "啤酒厂",
				G06: "燃料商人",
				G07: "泥炭煤窑",
				F08: "市场",
				I08: "伪灯塔",
				F09: "修院花园",
				I09: "纺织厂",
				F10: "木工作坊",
				I10: "农舍",
				F11: "港口步道",
				I11: "船屋",
				G12: "石料商人",
				G13: "建材市场",
				F14: "葡萄园",
				I14: "圣地",
				F15: "资助庄园",
				I15: "德鲁伊之家",
				G16: "修院议事厅",
				F17: "修院图书馆",
				I17: "缮写室",
				G18: "修院工坊",
				G19: "屠宰场",
				F20: "旅馆",
				I20: "酒馆",
				F21: "葡萄酒厂",
				I21: "威士忌酒厂",
				G22: "采石场",
				F23: "浴室",
				I23: "会客室",
				F24: "修院教堂",
				I24: "礼拜堂",
				F25: "奇观陈列室",
				I25: "门廊",
				G26: "造船厂",
				F27: "宫殿",
				I27: "大庄园",
				G28: "城堡",
				F29: "采石场",
				I29: "林中小屋",
				F30: "城镇庄园",
				I30: "修院食堂",
				F31: "葡萄园",
				I31: "煤港",
				F32: "暖房",
				I32: "分堂",
				F33: "航运公司",
				I33: "制桶坊",
				G34: "圣器室",
				F35: "伪造者工坊",
				I35: "圆塔",
				F36: "朝圣地",
				I36: "宝库",
				F37: "宿舍",
				I37: "堡垒",
				F38: "印刷所",
				I38: "庆典广场",
				G39: "庄园",
				F40: "修院客舍",
				I40: "宾馆",
				G41: "兄弟会会堂",
				farm: "农场",
				claymound: "黏土丘",
				office: "修院事务所",
				S01: "棚屋区",
				S02: "农业村",
				S03: "集镇",
				S04: "渔村",
				S05: "艺术家聚落",
				S06: "小村落",
				S07: "村庄",
				S08: "山顶村",
				FL1: "黏土地"
			},
			rules: "目标:\n经营修院领地，以物资、建筑、聚落及相邻水域的居住值与奇观获得最高总分；平分者共同获胜。单人目标为 500 分。法国与爱尔兰拥有不同的生产链和建筑。\n准备:\n每人拥有一块两行五列的心脏领地、农场、黏土丘、修院办公室、四张起始聚落及三名神职人员（院长与两名修士）。森林和泥炭地覆盖部分位置；短局移除左上方各一张覆盖牌，并只使用院长与一名修士。多人标准局每种基础物资各一份；短局各两份，单人没有起始物资。\n流程:\n每轮先收回已经全部派出的神职人员，再转动生产轮。\n· 三至四人游戏按顺序各行动一次，起始玩家再行动一次，起始身份逐轮轮换。\n· 标准双人游戏每次转轮后由一人连续行动两次，再交给另一人。\n· 长双人游戏每轮起始玩家行动两次，另一人行动一次；相邻轮次可能连续行动三次。\n· 单人游戏每轮行动两次。\n可选行动：\n· 使用建筑：把一名可用神职人员放到自己未被占用的建筑，按牌面依次选择效果；可放弃部分或全部效果。使用他人的空建筑须支付合约费用，由拥有者选择派出其院长或修士，不得拒绝。费用通常为一枚钱币；任何人建成葡萄酒厂或威士忌酒厂后变为两枚钱币，也可销毁一份葡萄酒或威士忌作为礼物。\n· 采集：移除自家一张森林获得木材，或一张泥炭地获得泥炭。选择对应标记或万能标记，按其生产轮数值获得物资，并把该标记归零；没有相应覆盖牌时可空过此行动。短局每次经生产轮获得物资时，所有玩家额外各获得一份相同物资。\n· 建造：支付建筑牌费用，放在符合地形的自家空位。修院建筑必须与另一修院建筑正交相邻。建造后若院长可用，可以立即派出并使用新建筑。山地跨两行，边缘与相接的两格均相邻。\n· 额外行动：随时将谷物翻为稻草、将一钱币与五钱币互换，或出售葡萄酒换一钱币、威士忌换两钱币。正反面物资与一钱币、五钱币均属于不同物资。支付食物或能量可组合任意适用物资，允许超付，没有找零。\n· 土地：每回合和每次聚落阶段最多购买一块。地区须沿心脏领地或地区上下延伸；海岸与山地地块须按对应边缘连接，不能重叠。长双人连续三行动期间最多购买两块，第一块须在第一行动购买，第二块须在第二或第三行动购买。\n聚落阶段:\n轮针到达 A、B、C、D 时，暂停常规行动。每人可购买一块土地，并支付食物、能量建造至多一张自有聚落。之后发放相应字母的新聚落和建筑，旧建筑继续保留。聚落阶段不使用神职人员。城堡允许在行动中另建一张聚落。\n三至四人标准局第 25 轮、短局第 13 轮为奖励轮：收回所有院长，每人建造一次或用院长免费使用任意已建建筑（包括被占用的建筑），随后进行最终聚落阶段。短局另有每轮印刷物资奖励。\n标准双人 D 阶段后市场只剩至多一张时，完成当前两行动回合，转轮，另一人再行动一次后结束；长双人只剩至多三张时，完成当前轮后结束。两种双人均无奖励轮或最终聚落阶段。\n单人:\n生产轮使用正面，基础与万能标记起始放 A 区；没有葡萄或石料标记，经过最高产量后移除标记。土地从最贵开始购买。中立修院起始拥有三座基础建筑和建材市场，付费使用时由你选择中立神职人员。每次聚落阶段先把市场剩余建筑放到中立领地，可覆盖未占用的同类建筑；修院建筑仍须邻接修院建筑，地形不受限制。然后可付合约费，用中立院长使用一座刚建成且未被覆盖的建筑。最终 E 阶段先执行自己的两次行动，再处理中立建筑与最终聚落。\n结算:\n· 书籍各 2 分、陶器各 3 分、饰物各 4 分、圣物匣各 8 分；葡萄酒和威士忌各 1 分，每完整五钱币 2 分。系统在终局自动比较出售酒类的最优得分。\n· 加上每座建筑与聚落的经济分。每座聚落再计自身和所有正交相邻建筑的居住值，负值同样计算，同一建筑可为多座聚落计分。每格空水域向每座正交相邻的聚落提供 3 点居住值。\n· 普通奇观各 30 分，最多八座。启用利斯博恩小奇观时，公开随机抽出的玩家数两倍加一张特殊奇观；获得奇观时可选一张特殊奇观或一座 20 分普通奇观。特殊奇观按各自图示计分。\n法国的黏土地：A 阶段入场，支付三钱币覆盖黏土丘；使用时交换两个生产标记位置，再生产黏土、牲畜或谷物。",
			wonderRules: {
				w1: "20 分，另按每座世俗建筑获得 1 分，包括起始建筑，不包括聚落。",
				w2: "12 分，另按每座修院建筑获得 3 分，包括修院事务所。",
				w3: "20 分，另按已建建筑的稻草费用总数，每份获得 2 分。",
				w4: "20 分，另按库存每完整 5 钱币获得 2 分。",
				w5: "20 分，另按库存每份肉获得 4 分。",
				w6: "20 分，另按库存每份啤酒及威士忌获得 1 分。",
				w7: "每座居住值至少为 5 的建筑或聚落获得 3 分。",
				w8: "42 分，每格与聚落相邻的空位扣 3 分；同一空位只扣一次。",
				w9: "15 分，另按库存每份木材、黏土、石料及稻草获得 1 分。",
				w10: "15 分，另按库存每点食物价值获得半分。",
				w11: "5 分，另加得分最高的那座聚落的完整居住分。",
				w12: "20 分，另按库存每份泥炭及泥炭煤获得 1 分。",
				w13: "10 分，另选一座修院建筑，按聚落方式计算它与相邻建筑的居住值，取最高值。",
				w14: "36 分，每格空位扣 2 分。森林及泥炭地不算空位。",
				w15: "18 分，另按已建建筑的黏土费用总数，每份获得 1 分。",
				w16: "按已建建筑的木材、黏土、石料及稻草费用总数，每份获得 1 分；长双人每份半分。",
				w17: "6 分，另按每座聚落获得 4 分。",
				w18: "18 分，另按已建建筑的木材费用总数，每份获得 1 分。",
				w19: "25 分，另按库存每组一本书籍和一件陶器获得 1 分。",
				w20: "20 分，另按库存每组一份牲畜和一份谷物获得 2 分。",
				w21: "28 分，另按库存每件饰物获得 1 分。",
				w22: "12 分，另按已建建筑的石料费用总数，每份获得 2 分。",
				w23: "25 分，另按库存每件圣物匣获得 2 分。",
				w24: "6 分，另按每块地区获得 4 分，心脏领地算一块地区。",
				w25: "45 分，每块地区扣 3 分，心脏领地算一块；长双人每块扣 1.5 分。",
				w26: "60 分，每座建筑扣 2 分，包括起始建筑，不包括聚落；长双人每座扣 1 分。"
			},
			special: {
				prior: "使用一座已被院长占用的建筑。",
				basic: "支付三种不同物资，获得六份相同基础物资。",
				livestock: "拥有至少 1／5／9 份牲畜时获得 3／5／8 枚钱币，不消耗牲畜。",
				adjacent: "获得牌面物资，然后可使用一座正交相邻的空建筑。本建筑每回合只能使用一次。",
				carpentry: "移除一张森林，再支付正常费用建造一座建筑；不获得木材。",
				twoBasic: "支付一本书籍，获得五份同种基础物资及三份另一种基础物资。",
				bathhouse: "支付一钱币，获得一本书籍和一件陶器。立即收回自己建筑上的全部己方神职人员，浴室拥有者也收回浴室上的神职人员。",
				locutory: "支付两钱币，收回自己的院长，再支付正常费用建造一座建筑。院长可以立即使用新建筑。",
				occupied: "支付牌面酒类，使用任意一座已被占用的建筑。",
				wonder: "支付牌面物资，获得一座奇观。",
				forestHut: "移除一张森林，获得两份牲畜、两份木材及一份石料。",
				calefactory: "支付一钱币，分别执行至多一次砍伐森林和挖掘泥炭。",
				shipping: "支付三能量，根据万能标记获得肉、面包或葡萄酒。",
				cooperage: "支付三份木材，根据万能标记获得啤酒或威士忌。",
				forge: "首件圣物匣支付五钱币，每增加一件再支付十钱币。",
				bulwark: "支付一本书籍，免费获得一块地区和一块地块。",
				printing: "移除至多四张森林，每张获得一本书籍，不获得木材。",
				festival: "支付一份啤酒，自家每张剩余森林和泥炭地获得一分。用书籍、陶器、饰物和圣物匣领取，可以少取。",
				brotherhood: "支付五钱币，自家每座修院建筑获得两分；单人每座一分，长双人每座一分半。用书籍、陶器、饰物和圣物匣领取，可以少取。",
				market: "使用一张市场中尚未建造的建筑牌。",
				settlement: "支付食物与能量，建造一张自有聚落。",
				swap: "交换两个生产标记的位置，然后生产黏土、牲畜或谷物。",
				production: "选择对应标记或万能标记，获得其当前产量，然后将标记归零。"
			},
			once: "每回合一次",
			confirmAgain: "确认结束回看并开始新一局？",
			confirmLobby: "确认结束回看并返回大堂？",
			autopilot: "托管 {{n}}%",
			diagramLegend: "箭头内的数字表示最多执行次数；箭头没有数字表示不限次数。并排物资需要同时支付，斜杠表示二选一。采集图示右侧的叠层物资表示根据生产轮获得相应产量。"
		},
		en: {
			name: "Ora et Labora",
			desc: "Expand a monastery estate, develop production chains and surround settlements with thriving buildings.",
			invalid: "That action is unavailable. Please choose again.",
			round: "Round {{n}}",
			stage: "Phase {{stage}}",
			turn: "{{name}}’s turn",
			action: "Choose an action",
			effect: "Resolve the building",
			settlement: "Build one settlement, or finish this settlement phase",
			contract: "Choose a clergyman to send",
			done: "Finished",
			market: "Building display",
			estate: "Estate",
			settlements: "Settlements",
			resources: "Goods",
			production: "Production wheel",
			land: "Buy landscape",
			district: "District",
			plot: "Plot",
			side: "Flip",
			prior: "Prior",
			lay: "Lay brother",
			clergy: "Clergy",
			available: "Available",
			occupied: "Occupied",
			use: "Use building",
			build: "Build",
			harvest: "Harvest",
			fell: "Fell trees",
			cut: "Cut peat",
			joker: "Joker",
			exchange: "Additional exchange",
			end: "Finish action",
			endSettlement: "Finish settlement phase",
			skip: "Skip this effect",
			confirm: "Confirm",
			cancel: "Cancel",
			back: "Back",
			close: "Close",
			details: "Building details",
			cost: "Building cost",
			economic: "Economic",
			dwelling: "Dwelling",
			food: "Food",
			energy: "Energy",
			points: "Points",
			payment: "Choose goods to pay",
			inputs: "Goods paid",
			gain: "Goods received",
			count: "Times",
			output: "Choose goods to receive",
			secondary: "Choose another good",
			marker: "Choose production marker",
			swap: "Choose two goods indicators",
			neutral: "Neutral monastery",
			neutralBuild: "Place the remaining buildings in the neutral monastery",
			neutralUse: "You may pay to use a newly built building with the neutral prior",
			chooseSite: "Choose a legal space on the estate",
			chooseBuilding: "Choose a building",
			chooseClergy: "Choose clergy",
			chooseTarget: "Choose a building target",
			contractGift: "Pay work contract",
			coinGift: "Pay {{n}} coins",
			wineGift: "Give one wine",
			whiskeyGift: "Give one whiskey",
			repeat: "Up to {{n}} times",
			repeatCombined: "Up to {{n}} conversions in total",
			different: "Pay {{n}} different goods, one of each",
			autoPayment: "Suggested payment",
			waiting: "Waiting for {{name}}",
			total: "Total",
			goodsScore: "Goods",
			economicScore: "Buildings & settlements",
			dwellingScore: "Settlement dwelling",
			waterScore: "Water dwelling score",
			wondersScore: "Wonders",
			wonder: "Wonder",
			wonderNumber: "Wonder {{n}}",
			baseWonder: "Ordinary Wonder",
			result: "Monastery chronicle",
			review: "Inspect final estate",
			winner: "{{name}} wins",
			soloWin: "Goal reached",
			soloLoss: "Keep growing your monastery",
			soloGoal: "Solo goal: 500 points",
			again: "Play again",
			lobby: "Back to lobby",
			log: "Action record",
			country: "Country",
			france: "France",
			ireland: "Ireland",
			length: "Game length",
			normal: "Normal",
			short: "Short (3–4 players)",
			long: "Long (2 players)",
			expansions: "Official expansions",
			loamy: "Loamy Landscape (France)",
			wonders: "The Little Wonders of Liesborn Abbey",
			on: "On",
			off: "Off",
			terrain: {
				plains: "Plains",
				hillside: "Hillside",
				coast: "Coast",
				water: "Water",
				mountain: "Mountain"
			},
			cover: {
				forest: "Forest",
				moor: "Moor"
			},
			goods: {
				wood: "Wood",
				clay: "Clay",
				peat: "Peat",
				grain: "Grain",
				livestock: "Livestock",
				coin: "Coin",
				coin5: "5 coins",
				straw: "Straw",
				stone: "Stone",
				peatcoal: "Peat coal",
				meat: "Meat",
				flour: "Flour",
				bread: "Bread",
				grapes: "Grapes",
				wine: "Wine",
				malt: "Malt",
				beer: "Beer",
				whiskey: "Whiskey",
				book: "Book",
				ceramic: "Ceramic",
				ornament: "Ornament",
				reliquary: "Reliquary"
			},
			buildings: {
				G01: "Priory",
				G02: "Cloister Courtyard",
				F03: "Grain Storage",
				I03: "Granary",
				F04: "Windmill",
				I04: "Malthouse",
				F05: "Bakery",
				I05: "Brewery",
				G06: "Fuel Merchant",
				G07: "Peat Coal Kiln",
				F08: "Market",
				I08: "False Lighthouse",
				F09: "Cloister Garden",
				I09: "Spinning Mill",
				F10: "Carpentry",
				I10: "Cottage",
				F11: "Harbor Promenade",
				I11: "Houseboat",
				G12: "Stone Merchant",
				G13: "Builders’ Market",
				F14: "Grapevine",
				I14: "Sacred Site",
				F15: "Financed Estate",
				I15: "Druid’s House",
				G16: "Cloister Chapter House",
				F17: "Cloister Library",
				I17: "Scriptorium",
				G18: "Cloister Workshop",
				G19: "Slaughterhouse",
				F20: "Inn",
				I20: "Alehouse",
				F21: "Winery",
				I21: "Whiskey Distillery",
				G22: "Quarry",
				F23: "Bathhouse",
				I23: "Locutory",
				F24: "Cloister Church",
				I24: "Chapel",
				F25: "Chamber of Wonders",
				I25: "Portico",
				G26: "Shipyard",
				F27: "Palace",
				I27: "Grand Manor",
				G28: "Castle",
				F29: "Quarry",
				I29: "Forest Hut",
				F30: "Town Estate",
				I30: "Refectory",
				F31: "Grapevine",
				I31: "Coal Harbor",
				F32: "Calefactory",
				I32: "Filial Church",
				F33: "Shipping Company",
				I33: "Cooperage",
				G34: "Sacristy",
				F35: "Forger’s Workshop",
				I35: "Round Tower",
				F36: "Pilgrimage Site",
				I36: "Camera",
				F37: "Dormitory",
				I37: "Bulwark",
				F38: "Printing Office",
				I38: "Festival Ground",
				G39: "Estate",
				F40: "Hospice",
				I40: "Guesthouse",
				G41: "House of the Brotherhood",
				farm: "Farmyard",
				claymound: "Clay Mound",
				office: "Cloister Office",
				S01: "Shanty Town",
				S02: "Farming Village",
				S03: "Market Town",
				S04: "Fishing Village",
				S05: "Artist’s Colony",
				S06: "Hamlet",
				S07: "Village",
				S08: "Hilltop Village",
				FL1: "Loamy Landscape"
			},
			rules: "Goal:\nDevelop a monastery estate. Score goods, economic values, settlement dwellings, adjacent water dwellings and Wonders. Highest total wins; ties share victory. The solo target is 500 points. France and Ireland have different buildings and production chains.\nSetup:\nEach player starts with a two-by-five heartland, Farmyard, Clay Mound, Cloister Office, four settlements and three clergymen (one prior and two lay brothers). Forests and moors cover some spaces. The short game removes one upper-left forest and moor and uses only a prior and one lay brother. Normal multiplayer starts with one of each basic good; short starts with two; solo starts with none.\nPlay:\n· At the start of a round, players who have used all their clergy retrieve them, then rotate the production wheel.\n· With three or four players, each takes one action and the starting player takes a second; the start rotates.\n· In normal two-player, each turn consists of two actions after a wheel rotation.\n· In long two-player, the starting player takes two actions and the other one, then the start changes; this can create three consecutive actions across rounds.\n· In solo, take two actions per rotation.\nAvailable actions:\n· Use a building: place available clergy on an unoccupied building of your own and resolve its effects in order. Effects may be skipped. To use an opponent’s empty building, pay a work contract; the owner must choose an available clergyman. The price is one coin, increasing to two once any Winery or Whiskey Distillery is built. Instead of paying coins you may discard one wine or whiskey as a gift.\n· Harvest: remove one forest for wood or one moor for peat. Choose its goods indicator or the joker, receive the indicated production and reset that marker to zero. Without a matching cover card you may spend the action without producing. In the short game, every production-wheel action also gives every player one extra matching good.\n· Build: pay a displayed building’s cost and place it on a legal empty space. Cloister buildings must be orthogonally adjacent to another cloister building. If your prior is available, you may immediately use a newly built building. A mountain spans two rows and is adjacent along both rows.\n· Additional actions: at any time, turn grain into straw, exchange one-coin and five-coin tiles, sell wine for one coin or whiskey for two coins. Front and back goods, including one-coin and five-coin tiles, are different goods. Food and energy may be paid using any combination of matching goods; overpayment gives no change.\n· Landscapes: buy at most one per turn and per settlement phase. Districts extend above or below heartland or districts. Coastal and mountain plots connect along appropriate edges without overlap. During three consecutive actions in long two-player, at most two landscapes may be bought: one during the first action and another during the second or third.\nSettlement phases:\nAt A, B, C and D, interrupt regular actions. Each player may buy a landscape and build at most one owned settlement, paying food and energy. Release the new letter’s settlements and buildings afterwards; old buildings remain. Settlements use no clergy. The Castle permits an additional settlement during an action.\nIn three- or four-player normal games, round 25 is a bonus round (round 13 in short): retrieve all priors; each player builds once or uses any built building for free with their prior, including occupied buildings. Then hold a final settlement phase. The short game also grants the goods printed for each round.\nAfter D in normal two-player, at most one building left triggers the end: finish the current two-action turn, rotate and give the other player one final action. Long two-player ends after completing the round when at most three buildings remain. Neither two-player game has a bonus round or final settlement phase.\nSolo:\nUse the front wheel. Basic indicators and joker start in the A sector; grapes and stone indicators never enter. Indicators passing maximum production are removed. Buy expensive landscapes first. The neutral monastery starts with three basic buildings and Builders’ Market. You choose its clergy when paying to use its buildings. Before each settlement phase, place all remaining displayed buildings in the neutral estate, overwriting unoccupied buildings of the same cloister category if needed. Cloister adjacency still applies; terrain restrictions do not. You may then pay a work contract to use one surviving newly built building with its available prior. In final phase E, take your own two actions before neutral building and final settlement.\nScoring:\n· Books score 2, ceramics 3, ornaments 4 and reliquaries 8. Wine and whiskey score 1 each, and every full five coins scores 2. The final score compares profitable wine or whiskey sales automatically.\n· Add economic values of all buildings and settlements. Each settlement also scores its own and all orthogonally adjacent dwelling values, including negatives. A building can count for several settlements. Each empty water space contributes 3 dwelling points to each orthogonally adjacent settlement.\n· Ordinary Wonders score 30; there are at most eight. With the Little Wonders of Liesborn Abbey, reveal twice the player count plus one special Wonder at random. Whenever gaining a Wonder choose one revealed special Wonder or an ordinary 20-point Wonder. Special Wonders score their printed conditions.\nLoamy Landscape is available only in France, released in A. Pay three coins to overbuild your Clay Mound. When used, swap two indicators, then produce clay, livestock or grain.",
			wonderRules: {
				w1: "20 points plus 1 per secular building, including starting buildings, excluding settlements.",
				w2: "12 points plus 3 per cloister building, including the Cloister Office.",
				w3: "20 points plus 2 per straw in the printed costs of your buildings.",
				w4: "20 points plus 2 per complete 5 coins in your supply.",
				w5: "20 points plus 4 per meat in your supply.",
				w6: "20 points plus 1 per beer and whiskey in your supply.",
				w7: "3 points per building or settlement with a dwelling value of at least 5.",
				w8: "42 points minus 3 per empty space adjacent to a settlement. Count each space once.",
				w9: "15 points plus 1 per wood, clay, stone and straw in your supply.",
				w10: "15 points plus half the food value of your supply.",
				w11: "5 points plus the full dwelling score of your best settlement.",
				w12: "20 points plus 1 per peat and peat coal in your supply.",
				w13: "10 points plus the highest dwelling score of a cloister building treated as a settlement, including its neighbours.",
				w14: "36 points minus 2 per empty space. Forests and moors are not empty.",
				w15: "18 points plus 1 per clay in the printed costs of your buildings.",
				w16: "1 point per wood, clay, stone and straw in the printed costs of your buildings; half a point in the long two-player game.",
				w17: "6 points plus 4 per settlement.",
				w18: "18 points plus 1 per wood in the printed costs of your buildings.",
				w19: "25 points plus 1 per book-and-ceramic pair in your supply.",
				w20: "20 points plus 2 per livestock-and-grain pair in your supply.",
				w21: "28 points plus 1 per ornament in your supply.",
				w22: "12 points plus 2 per stone in the printed costs of your buildings.",
				w23: "25 points plus 2 per reliquary in your supply.",
				w24: "6 points plus 4 per district, including your heartland as one district.",
				w25: "45 points minus 3 per district, including the heartland; minus 1.5 in the long two-player game.",
				w26: "60 points minus 2 per building, including starting buildings, excluding settlements; minus 1 in the long two-player game."
			},
			special: {
				prior: "Use a building occupied by a prior.",
				basic: "Pay three different goods for six identical basic goods.",
				livestock: "With at least 1 / 5 / 9 livestock receive 3 / 5 / 8 coins. Keep the livestock.",
				adjacent: "Take the printed goods, then optionally use an orthogonally adjacent empty building. This building may be used only once per turn.",
				carpentry: "Remove one forest, then build a building at its normal cost. Receive no wood.",
				twoBasic: "Pay one book for five identical basic goods and three of another basic good.",
				bathhouse: "Pay one coin for one book and one ceramic. Retrieve all your clergy on your buildings; the owner also retrieves the clergyman on the Bathhouse.",
				locutory: "Pay two coins, retrieve your prior, then build a building at its normal cost. Your prior may immediately use it.",
				occupied: "Pay the printed drink and use any occupied building.",
				wonder: "Pay the printed goods to gain a Wonder.",
				forestHut: "Remove one forest for two livestock, two wood and one stone.",
				calefactory: "Pay one coin to fell trees and/or cut peat, at most once each.",
				shipping: "Pay three energy to produce meat, bread or wine with the joker.",
				cooperage: "Pay three wood to produce beer or whiskey with the joker.",
				forge: "The first reliquary costs five coins; each additional one costs ten.",
				bulwark: "Pay one book for one free district and one free plot.",
				printing: "Remove up to four forests, gaining one book each and no wood.",
				festival: "Pay one beer for one point per forest and moor left on your estate. Take books, ceramics, ornaments or reliquaries; taking fewer points is allowed.",
				brotherhood: "Pay five coins for two points per own cloister building; one point in solo, one and a half in long two-player. Take books, ceramics, ornaments or reliquaries; fewer points are allowed.",
				market: "Use an unbuilt building in the display.",
				settlement: "Pay food and energy to build one of your settlements.",
				swap: "Swap two goods indicators, then produce clay, livestock or grain.",
				production: "Choose the matching indicator or joker, take its production and reset the marker to zero."
			},
			once: "Once per turn",
			confirmAgain: "End the review and start a new game?",
			confirmLobby: "End the review and return to the lobby?",
			autopilot: "Autopilot {{n}}%",
			diagramLegend: "A number inside an arrow is the maximum number of repetitions. An unnumbered arrow has no limit. Goods shown together are paid together; a slash indicates a choice. Stacked goods in harvest diagrams mean that the production wheel determines the quantity."
		}
	}
};
//#endregion
export { nn as default };
