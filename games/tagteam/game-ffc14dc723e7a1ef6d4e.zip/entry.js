import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useT as i } from "@bgparty/sdk/i18n";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { Floater as u, PulseBox as d } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as f } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as p, OptionSection as m } from "@bgparty/sdk/ui/game-options";
//#region src/games/tagteam/data.ts
var h = (e) => e, g = [
	h({
		id: "bodvar.enrage",
		fighter: "bodvar",
		copies: 1,
		star: !0,
		nameKey: "games.tagteam.cards.bodvar_enrage",
		textKey: "games.tagteam.cards.bodvar_enrage_text",
		effects: [{
			k: "rage",
			n: 1,
			if: { k: "human" }
		}, {
			k: "attack",
			if: { k: "bear" }
		}]
	}),
	h({
		id: "bodvar.spirit_trance",
		fighter: "bodvar",
		copies: 1,
		nameKey: "games.tagteam.cards.bodvar_spirit_trance",
		textKey: "games.tagteam.cards.bodvar_spirit_trance_text",
		effects: [{
			k: "power",
			target: "self",
			n: 2
		}, {
			k: "dd",
			target: "self",
			n: 2,
			if: { k: "selfAttacked" }
		}]
	}),
	h({
		id: "bodvar.rune_transformation",
		fighter: "bodvar",
		copies: 2,
		nameKey: "games.tagteam.cards.bodvar_rune_transformation",
		textKey: "games.tagteam.cards.bodvar_rune_transformation_text",
		effects: [{
			k: "block",
			success: [{
				k: "rage",
				n: 1
			}]
		}]
	}),
	h({
		id: "bodvar.rune_strength",
		fighter: "bodvar",
		copies: 2,
		nameKey: "games.tagteam.cards.bodvar_rune_strength",
		textKey: "games.tagteam.cards.bodvar_rune_strength_text",
		effects: [{
			k: "block",
			success: [{
				k: "power",
				target: "self",
				n: 1
			}]
		}]
	}),
	h({
		id: "bodvar.blood_ties",
		fighter: "bodvar",
		copies: 2,
		nameKey: "games.tagteam.cards.bodvar_blood_ties",
		textKey: "games.tagteam.cards.bodvar_blood_ties_text",
		effects: [{
			k: "heal",
			target: "partner",
			n: 2,
			if: { k: "human" }
		}, {
			k: "attack",
			if: { k: "bear" }
		}]
	}),
	h({
		id: "bodvar.berserk",
		fighter: "bodvar",
		copies: 2,
		nameKey: "games.tagteam.cards.bodvar_berserk",
		textKey: "games.tagteam.cards.bodvar_berserk_text",
		effects: [{
			k: "attack",
			if: { k: "human" }
		}, {
			k: "attack",
			target: "bothOpponents",
			if: { k: "bear" }
		}]
	}),
	h({
		id: "ching.terror",
		fighter: "ching",
		copies: 1,
		star: !0,
		nameKey: "games.tagteam.cards.ching_terror",
		textKey: "games.tagteam.cards.ching_terror_text",
		effects: [
			{
				k: "attack",
				if: {
					k: "ship",
					min: 0,
					max: 7
				}
			},
			{
				k: "heal",
				target: "self",
				n: 2,
				if: {
					k: "ship",
					min: 8,
					max: 15
				}
			},
			{
				k: "ship20",
				if: {
					k: "ship",
					min: 20,
					max: 20
				}
			},
			{
				k: "ship",
				n: 1
			}
		]
	}),
	h({
		id: "ching.secret_harbour",
		fighter: "ching",
		copies: 2,
		nameKey: "games.tagteam.cards.ching_secret_harbour",
		textKey: "games.tagteam.cards.ching_secret_harbour_text",
		effects: [{
			k: "block",
			success: [{
				k: "ship",
				n: 3
			}]
		}]
	}),
	h({
		id: "ching.spirited_defense",
		fighter: "ching",
		copies: 1,
		nameKey: "games.tagteam.cards.ching_spirited_defense",
		textKey: "games.tagteam.cards.ching_spirited_defense_text",
		effects: [{
			k: "block",
			success: [{
				k: "power",
				target: "self",
				n: 1
			}]
		}]
	}),
	h({
		id: "ching.revenge",
		fighter: "ching",
		copies: 1,
		nameKey: "games.tagteam.cards.ching_revenge",
		textKey: "games.tagteam.cards.ching_revenge_text",
		effects: [{ k: "attack" }, {
			k: "attack",
			by: "partner",
			if: {
				k: "ship",
				min: 8,
				max: 15
			}
		}]
	}),
	h({
		id: "ching.raiding_party",
		fighter: "ching",
		copies: 1,
		nameKey: "games.tagteam.cards.ching_raiding_party",
		textKey: "games.tagteam.cards.ching_raiding_party_text",
		effects: [{
			k: "power",
			target: "partner",
			n: 1,
			if: {
				k: "ship",
				min: 0,
				max: 7
			}
		}]
	}),
	h({
		id: "ching.outmaneuvered",
		fighter: "ching",
		copies: 2,
		nameKey: "games.tagteam.cards.ching_outmaneuvered",
		textKey: "games.tagteam.cards.ching_outmaneuvered_text",
		effects: [{ k: "attack" }, {
			k: "ship",
			n: 1
		}]
	}),
	h({
		id: "ching.join_fleet",
		fighter: "ching",
		copies: 1,
		nameKey: "games.tagteam.cards.ching_join_fleet",
		textKey: "games.tagteam.cards.ching_join_fleet_text",
		effects: [{
			k: "ship",
			n: 2
		}]
	}),
	h({
		id: "ching.gunpowder_wine",
		fighter: "ching",
		copies: 1,
		nameKey: "games.tagteam.cards.ching_gunpowder_wine",
		textKey: "games.tagteam.cards.ching_gunpowder_wine_text",
		effects: [{
			k: "heal",
			target: "self",
			n: 3
		}, {
			k: "heal",
			target: "partner",
			n: 3,
			if: {
				k: "ship",
				min: 8,
				max: 15
			}
		}]
	}),
	h({
		id: "fey.almp",
		fighter: "fey",
		copies: 1,
		star: !0,
		nameKey: "games.tagteam.cards.fey_almp",
		textKey: "games.tagteam.cards.fey_almp_text",
		effects: [{ k: "koIfAllSpirits" }]
	}),
	h({
		id: "fey.summon_greenman",
		fighter: "fey",
		copies: 1,
		nameKey: "games.tagteam.cards.fey_summon_greenman",
		textKey: "games.tagteam.cards.fey_summon_greenman_text",
		effects: [{
			k: "block",
			success: [{
				k: "summonFlip",
				to: "greenman"
			}]
		}]
	}),
	h({
		id: "fey.spirit_storm",
		fighter: "fey",
		copies: 2,
		nameKey: "games.tagteam.cards.fey_spirit_storm",
		textKey: "games.tagteam.cards.fey_spirit_storm_text",
		effects: [{
			k: "attack",
			plusSpirits: !0
		}]
	}),
	h({
		id: "fey.summon_redcap",
		fighter: "fey",
		copies: 1,
		nameKey: "games.tagteam.cards.fey_summon_redcap",
		textKey: "games.tagteam.cards.fey_summon_redcap_text",
		effects: [{
			k: "block",
			success: [{
				k: "summonFlip",
				to: "redcap"
			}]
		}]
	}),
	h({
		id: "fey.summon_leshi",
		fighter: "fey",
		copies: 1,
		nameKey: "games.tagteam.cards.fey_summon_leshi",
		textKey: "games.tagteam.cards.fey_summon_leshi_text",
		effects: [{
			k: "block",
			success: [{
				k: "summonFlip",
				to: "leshi"
			}]
		}]
	}),
	h({
		id: "fey.fairy_ring",
		fighter: "fey",
		copies: 2,
		nameKey: "games.tagteam.cards.fey_fairy_ring",
		textKey: "games.tagteam.cards.fey_fairy_ring_text",
		effects: [{
			k: "heal",
			target: "partner",
			n: "spirits",
			mult: 2
		}]
	}),
	h({
		id: "fey.entanglement",
		fighter: "fey",
		copies: 2,
		nameKey: "games.tagteam.cards.fey_entanglement",
		textKey: "games.tagteam.cards.fey_entanglement_text",
		effects: [{ k: "cancel" }]
	}),
	h({
		id: "fey.greenman",
		fighter: "fey",
		copies: 0,
		nameKey: "games.tagteam.cards.fey_greenman",
		textKey: "games.tagteam.cards.fey_greenman_text",
		effects: [{
			k: "heal",
			target: "selfAndPartner",
			n: 3
		}]
	}),
	h({
		id: "fey.redcap",
		fighter: "fey",
		copies: 0,
		nameKey: "games.tagteam.cards.fey_redcap",
		textKey: "games.tagteam.cards.fey_redcap_text",
		effects: [{ k: "attack" }, {
			k: "attack",
			by: "partner"
		}]
	}),
	h({
		id: "fey.leshi",
		fighter: "fey",
		copies: 0,
		nameKey: "games.tagteam.cards.fey_leshi",
		textKey: "games.tagteam.cards.fey_leshi_text",
		effects: [{
			k: "power",
			target: "both",
			n: 1
		}]
	}),
	h({
		id: "golem.pti",
		fighter: "golem",
		copies: 2,
		star: !0,
		nameKey: "games.tagteam.cards.golem_pti",
		textKey: "games.tagteam.cards.golem_pti_text",
		effects: [
			{
				k: "attack",
				if: { k: "partnerHasToken" }
			},
			{
				k: "golemToken",
				if: { k: "noPartnerToken" }
			},
			{
				k: "dd",
				target: "self",
				n: 3,
				if: { k: "noPartnerToken" }
			}
		]
	}),
	h({
		id: "golem.self_sacrifice",
		fighter: "golem",
		copies: 2,
		nameKey: "games.tagteam.cards.golem_self_sacrifice",
		textKey: "games.tagteam.cards.golem_self_sacrifice_text",
		effects: [{
			k: "transferPower",
			from: "self",
			n: 1
		}]
	}),
	h({
		id: "golem.fist_of_clay",
		fighter: "golem",
		copies: 3,
		nameKey: "games.tagteam.cards.golem_fist_of_clay",
		textKey: "games.tagteam.cards.golem_fist_of_clay_text",
		effects: [{ k: "attack" }]
	}),
	h({
		id: "golem.reanimation",
		fighter: "golem",
		copies: 1,
		nameKey: "games.tagteam.cards.golem_reanimation",
		textKey: "games.tagteam.cards.golem_reanimation_text",
		effects: [{ k: "reanimate" }]
	}),
	h({
		id: "golem.heal_wounded",
		fighter: "golem",
		copies: 2,
		nameKey: "games.tagteam.cards.golem_heal_wounded",
		textKey: "games.tagteam.cards.golem_heal_wounded_text",
		effects: [{
			k: "heal",
			target: "partner",
			n: 1
		}],
		instantBonus: [{
			k: "heal",
			target: "self",
			n: 3
		}]
	}),
	h({
		id: "milady.dressed_to_kill",
		fighter: "milady",
		copies: 1,
		star: !0,
		nameKey: "games.tagteam.cards.milady_dressed_to_kill",
		textKey: "games.tagteam.cards.milady_dressed_to_kill_text",
		effects: [{ k: "plantScheme" }]
	}),
	h({
		id: "milady.stab_smile",
		fighter: "milady",
		copies: 1,
		nameKey: "games.tagteam.cards.milady_stab_smile",
		textKey: "games.tagteam.cards.milady_stab_smile_text",
		effects: [{ k: "attack" }, {
			k: "unleashScheme",
			if: { k: "selfAttacked" }
		}]
	}),
	h({
		id: "milady.so_predictable",
		fighter: "milady",
		copies: 2,
		nameKey: "games.tagteam.cards.milady_so_predictable",
		textKey: "games.tagteam.cards.milady_so_predictable_text",
		effects: [{
			k: "block",
			success: [{ k: "unleashScheme" }]
		}]
	}),
	h({
		id: "milady.wdky",
		fighter: "milady",
		copies: 1,
		nameKey: "games.tagteam.cards.milady_wdky",
		textKey: "games.tagteam.cards.milady_wdky_text",
		effects: [{ k: "attack" }, {
			k: "power",
			target: "self",
			n: 1,
			if: { k: "attackBlocked" }
		}]
	}),
	h({
		id: "milady.licking_wounds",
		fighter: "milady",
		copies: 2,
		nameKey: "games.tagteam.cards.milady_licking_wounds",
		textKey: "games.tagteam.cards.milady_licking_wounds_text",
		effects: [{
			k: "heal",
			target: "self",
			n: 2
		}, {
			k: "plantScheme",
			if: { k: "healedFull" }
		}]
	}),
	h({
		id: "milady.friends_close",
		fighter: "milady",
		copies: 1,
		nameKey: "games.tagteam.cards.milady_friends_close",
		textKey: "games.tagteam.cards.milady_friends_close_text",
		effects: [{
			k: "heal",
			target: "partner",
			n: "power"
		}]
	}),
	h({
		id: "milady.checkmate",
		fighter: "milady",
		copies: 2,
		nameKey: "games.tagteam.cards.milady_checkmate",
		textKey: "games.tagteam.cards.milady_checkmate_text",
		effects: [{ k: "unleashScheme" }]
	}),
	h({
		id: "maman.cpr",
		fighter: "maman",
		copies: 2,
		star: !0,
		nameKey: "games.tagteam.cards.maman_cpr",
		textKey: "games.tagteam.cards.maman_cpr_text",
		effects: [{
			k: "dd",
			target: "self",
			n: 1
		}, { k: "attack" }]
	}),
	h({
		id: "maman.you_are_mine",
		fighter: "maman",
		copies: 2,
		nameKey: "games.tagteam.cards.maman_you_are_mine",
		textKey: "games.tagteam.cards.maman_you_are_mine_text",
		effects: [{
			k: "block",
			success: [{ k: "youAreMine" }]
		}]
	}),
	h({
		id: "maman.sacrifice_love",
		fighter: "maman",
		copies: 1,
		nameKey: "games.tagteam.cards.maman_sacrifice_love",
		textKey: "games.tagteam.cards.maman_sacrifice_love_text",
		effects: [{
			k: "dd",
			target: "partner",
			n: 1
		}, {
			k: "heal",
			target: "self",
			n: 4
		}]
	}),
	h({
		id: "maman.soul_embrace",
		fighter: "maman",
		copies: 2,
		nameKey: "games.tagteam.cards.maman_soul_embrace",
		textKey: "games.tagteam.cards.maman_soul_embrace_text",
		effects: [{
			k: "dd",
			target: "partner",
			n: 1
		}, {
			k: "power",
			target: "self",
			n: 1
		}]
	}),
	h({
		id: "maman.black_rooster",
		fighter: "maman",
		copies: 2,
		nameKey: "games.tagteam.cards.maman_black_rooster",
		textKey: "games.tagteam.cards.maman_black_rooster_text",
		effects: [{ k: "cancel" }]
	}),
	h({
		id: "maman.eternal_youth",
		fighter: "maman",
		copies: 1,
		nameKey: "games.tagteam.cards.maman_eternal_youth",
		textKey: "games.tagteam.cards.maman_eternal_youth_text",
		effects: [{ k: "eternalYouth" }]
	}),
	h({
		id: "jeanne.dieu_premier",
		fighter: "jeanne",
		copies: 1,
		star: !0,
		nameKey: "games.tagteam.cards.jeanne_dieu_premier",
		textKey: "games.tagteam.cards.jeanne_dieu_premier_text",
		effects: [{
			k: "voice",
			n: 1
		}]
	}),
	h({
		id: "jeanne.hand_righteous",
		fighter: "jeanne",
		copies: 2,
		nameKey: "games.tagteam.cards.jeanne_hand_righteous",
		textKey: "games.tagteam.cards.jeanne_hand_righteous_text",
		effects: [{ k: "attack" }, {
			k: "voice",
			n: 1
		}]
	}),
	h({
		id: "jeanne.holy_shield",
		fighter: "jeanne",
		copies: 3,
		nameKey: "games.tagteam.cards.jeanne_holy_shield",
		textKey: "games.tagteam.cards.jeanne_holy_shield_text",
		effects: [{
			k: "block",
			success: [{
				k: "voice",
				n: 1
			}]
		}]
	}),
	h({
		id: "jeanne.divine_vision",
		fighter: "jeanne",
		copies: 2,
		nameKey: "games.tagteam.cards.jeanne_divine_vision",
		textKey: "games.tagteam.cards.jeanne_divine_vision_text",
		effects: [{
			k: "heal",
			target: "selfAndPartner",
			n: 2
		}]
	}),
	h({
		id: "jeanne.sword_michael",
		fighter: "jeanne",
		copies: 2,
		nameKey: "games.tagteam.cards.jeanne_sword_michael",
		textKey: "games.tagteam.cards.jeanne_sword_michael_text",
		effects: [{
			k: "attack",
			success: [{
				k: "heal",
				target: "self",
				n: "power"
			}]
		}]
	}),
	h({
		id: "mephisto.twin_serpents",
		fighter: "mephisto",
		copies: 3,
		star: !0,
		nameKey: "games.tagteam.cards.mephisto_twin_serpents",
		textKey: "games.tagteam.cards.mephisto_twin_serpents_text",
		effects: [
			{
				k: "attack",
				if: {
					k: "serpent",
					face: "black"
				}
			},
			{
				k: "power",
				target: "self",
				n: 1,
				if: {
					k: "serpent",
					face: "white"
				}
			},
			{ k: "serpentFlip" }
		]
	}),
	h({
		id: "mephisto.fury_damned",
		fighter: "mephisto",
		copies: 1,
		nameKey: "games.tagteam.cards.mephisto_fury_damned",
		textKey: "games.tagteam.cards.mephisto_fury_damned_text",
		effects: [{
			k: "dd",
			target: "opponent",
			n: 4,
			if: { k: "oppStarter" }
		}]
	}),
	h({
		id: "mephisto.drag_hell",
		fighter: "mephisto",
		copies: 1,
		nameKey: "games.tagteam.cards.mephisto_drag_hell",
		textKey: "games.tagteam.cards.mephisto_drag_hell_text",
		effects: [{ k: "dragToHell" }]
	}),
	h({
		id: "mephisto.soul_siphon",
		fighter: "mephisto",
		copies: 1,
		nameKey: "games.tagteam.cards.mephisto_soul_siphon",
		textKey: "games.tagteam.cards.mephisto_soul_siphon_text",
		effects: [{
			k: "block",
			success: [{
				k: "heal",
				target: "self",
				n: "attackerPower"
			}]
		}]
	}),
	h({
		id: "mephisto.serpent_pit",
		fighter: "mephisto",
		copies: 2,
		nameKey: "games.tagteam.cards.mephisto_serpent_pit",
		textKey: "games.tagteam.cards.mephisto_serpent_pit_text",
		effects: [{
			k: "attack",
			if: {
				k: "serpent",
				face: "black"
			}
		}, {
			k: "dd",
			target: "self",
			n: 1,
			if: {
				k: "serpent",
				face: "white"
			}
		}]
	}),
	h({
		id: "mephisto.serpent_void",
		fighter: "mephisto",
		copies: 2,
		nameKey: "games.tagteam.cards.mephisto_serpent_void",
		textKey: "games.tagteam.cards.mephisto_serpent_void_text",
		effects: [{
			k: "heal",
			target: "self",
			n: 3,
			if: {
				k: "serpent",
				face: "white"
			}
		}, {
			k: "heal",
			target: "self",
			n: 1,
			if: {
				k: "serpent",
				face: "black"
			}
		}]
	}),
	h({
		id: "mordred.dark_power",
		fighter: "mordred",
		copies: 1,
		star: !0,
		nameKey: "games.tagteam.cards.mordred_dark_power",
		textKey: "games.tagteam.cards.mordred_dark_power_text",
		effects: [{
			k: "attack",
			if: {
				k: "powerGte",
				n: 8
			}
		}, {
			k: "power",
			target: "self",
			n: 1
		}]
	}),
	h({
		id: "mordred.vicious_riposte",
		fighter: "mordred",
		copies: 2,
		nameKey: "games.tagteam.cards.mordred_vicious_riposte",
		textKey: "games.tagteam.cards.mordred_vicious_riposte_text",
		effects: [{
			k: "block",
			success: [{ k: "attack" }]
		}]
	}),
	h({
		id: "mordred.hidden_dagger",
		fighter: "mordred",
		copies: 3,
		nameKey: "games.tagteam.cards.mordred_hidden_dagger",
		textKey: "games.tagteam.cards.mordred_hidden_dagger_text",
		effects: [{
			k: "attack",
			if: { k: "noOppAttacks" }
		}]
	}),
	h({
		id: "mordred.execution",
		fighter: "mordred",
		copies: 1,
		nameKey: "games.tagteam.cards.mordred_execution",
		textKey: "games.tagteam.cards.mordred_execution_text",
		effects: [{ k: "execution" }]
	}),
	h({
		id: "mordred.cloak_shadow",
		fighter: "mordred",
		copies: 3,
		nameKey: "games.tagteam.cards.mordred_cloak_shadow",
		textKey: "games.tagteam.cards.mordred_cloak_shadow_text",
		effects: [{
			k: "block",
			success: [{
				k: "heal",
				target: "self",
				n: 3
			}]
		}]
	}),
	h({
		id: "shango.aflame",
		fighter: "shango",
		copies: 1,
		star: !0,
		nameKey: "games.tagteam.cards.shango_aflame",
		textKey: "games.tagteam.cards.shango_aflame_text",
		effects: [{ k: "aflame" }]
	}),
	h({
		id: "shango.wall_flame",
		fighter: "shango",
		copies: 2,
		nameKey: "games.tagteam.cards.shango_wall_flame",
		textKey: "games.tagteam.cards.shango_wall_flame_text",
		effects: [{
			k: "block",
			success: [{
				k: "power",
				target: "both",
				n: 1
			}]
		}]
	}),
	h({
		id: "shango.cauterize",
		fighter: "shango",
		copies: 1,
		nameKey: "games.tagteam.cards.shango_cauterize",
		textKey: "games.tagteam.cards.shango_cauterize_text",
		effects: [{
			k: "heal",
			target: "partner",
			n: 3
		}]
	}),
	h({
		id: "shango.lightning_strike",
		fighter: "shango",
		copies: 2,
		nameKey: "games.tagteam.cards.shango_lightning_strike",
		textKey: "games.tagteam.cards.shango_lightning_strike_text",
		effects: [{
			k: "attack",
			target: "allOthers",
			power: "flamepower"
		}]
	}),
	h({
		id: "shango.thunder_stone",
		fighter: "shango",
		copies: 1,
		nameKey: "games.tagteam.cards.shango_thunder_stone",
		textKey: "games.tagteam.cards.shango_thunder_stone_text",
		effects: [{
			k: "transferPower",
			from: "partner",
			n: 1
		}]
	}),
	h({
		id: "shango.breath_fire",
		fighter: "shango",
		copies: 3,
		nameKey: "games.tagteam.cards.shango_breath_fire",
		textKey: "games.tagteam.cards.shango_breath_fire_text",
		effects: [{
			k: "attack",
			power: "flamepower",
			success: [{ k: "aflame" }]
		}]
	}),
	h({
		id: "wildbunch.corrupted_lawman",
		fighter: "wildbunch",
		copies: 1,
		star: !0,
		nameKey: "games.tagteam.cards.wildbunch_corrupted_lawman",
		textKey: "games.tagteam.cards.wildbunch_corrupted_lawman_text",
		effects: [
			{
				k: "sheriffGive",
				to: "opponent",
				if: {
					k: "sheriff",
					who: "self"
				}
			},
			{
				k: "attack",
				if: {
					k: "sheriff",
					who: "self"
				}
			},
			{
				k: "power",
				target: "opponent",
				n: 1,
				if: {
					k: "sheriff",
					who: "opp"
				}
			},
			{
				k: "sheriffGive",
				to: "self",
				if: {
					k: "sheriff",
					who: "opp"
				}
			},
			{
				k: "power",
				target: "self",
				n: 1,
				if: {
					k: "sheriff",
					who: "opp"
				}
			}
		]
	}),
	h({
		id: "wildbunch.keys_armory",
		fighter: "wildbunch",
		copies: 1,
		nameKey: "games.tagteam.cards.wildbunch_keys_armory",
		textKey: "games.tagteam.cards.wildbunch_keys_armory_text",
		effects: [{
			k: "sheriffHolderPower",
			n: 2
		}, {
			k: "sheriffGive",
			to: "opponent"
		}]
	}),
	h({
		id: "wildbunch.aint_here_talk",
		fighter: "wildbunch",
		copies: 2,
		nameKey: "games.tagteam.cards.wildbunch_aint_here_talk",
		textKey: "games.tagteam.cards.wildbunch_aint_here_talk_text",
		effects: [{
			k: "attack",
			target: "oppPartner"
		}]
	}),
	h({
		id: "wildbunch.gatling",
		fighter: "wildbunch",
		copies: 1,
		nameKey: "games.tagteam.cards.wildbunch_gatling",
		textKey: "games.tagteam.cards.wildbunch_gatling_text",
		effects: [{
			k: "attack",
			target: "bothOpponents",
			if: {
				k: "sheriff",
				who: "self"
			},
			success: [{
				k: "dd",
				target: "self",
				n: 1
			}]
		}]
	}),
	h({
		id: "wildbunch.outlaw_doc",
		fighter: "wildbunch",
		copies: 2,
		nameKey: "games.tagteam.cards.wildbunch_outlaw_doc",
		textKey: "games.tagteam.cards.wildbunch_outlaw_doc_text",
		effects: [{
			k: "heal",
			target: "partner",
			n: 3
		}],
		instantBonus: [{
			k: "heal",
			target: "self",
			n: 1
		}]
	}),
	h({
		id: "wildbunch.bribe",
		fighter: "wildbunch",
		copies: 2,
		nameKey: "games.tagteam.cards.wildbunch_bribe",
		textKey: "games.tagteam.cards.wildbunch_bribe_text",
		effects: [{
			k: "block",
			success: [{
				k: "sheriffGive",
				to: "self"
			}]
		}]
	}),
	h({
		id: "wildbunch.back_hideout",
		fighter: "wildbunch",
		copies: 1,
		nameKey: "games.tagteam.cards.wildbunch_back_hideout",
		textKey: "games.tagteam.cards.wildbunch_back_hideout_text",
		effects: [{
			k: "heal",
			target: "selfAndPartner",
			n: 1
		}],
		instantBonus: [{
			k: "heal",
			target: "self",
			n: 1
		}]
	}),
	h({
		id: "wong.thf",
		fighter: "wong",
		copies: 2,
		star: !0,
		nameKey: "games.tagteam.cards.wong_thf",
		textKey: "games.tagteam.cards.wong_thf_text",
		effects: [{ k: "concentration" }]
	}),
	h({
		id: "wong.tiger_fist",
		fighter: "wong",
		copies: 2,
		nameKey: "games.tagteam.cards.wong_tiger_fist",
		textKey: "games.tagteam.cards.wong_tiger_fist_text",
		effects: [{
			k: "attack",
			success: [{
				k: "transferPower",
				from: "self",
				n: 1
			}]
		}]
	}),
	h({
		id: "wong.ging_bridge",
		fighter: "wong",
		copies: 1,
		nameKey: "games.tagteam.cards.wong_ging_bridge",
		textKey: "games.tagteam.cards.wong_ging_bridge_text",
		effects: [{
			k: "transferPower",
			from: "self",
			n: 2
		}]
	}),
	h({
		id: "wong.ging_balance",
		fighter: "wong",
		copies: 2,
		nameKey: "games.tagteam.cards.wong_ging_balance",
		textKey: "games.tagteam.cards.wong_ging_balance_text",
		effects: [{
			k: "block",
			success: [{ k: "setPowerToPartner" }]
		}]
	}),
	h({
		id: "wong.crippling_touch",
		fighter: "wong",
		copies: 2,
		nameKey: "games.tagteam.cards.wong_crippling_touch",
		textKey: "games.tagteam.cards.wong_crippling_touch_text",
		effects: [{ k: "removeOppCardThenSelf" }]
	}),
	h({
		id: "wong.chi_focus",
		fighter: "wong",
		copies: 1,
		nameKey: "games.tagteam.cards.wong_chi_focus",
		textKey: "games.tagteam.cards.wong_chi_focus_text",
		effects: [{
			k: "power",
			target: "self",
			n: 1
		}, {
			k: "heal",
			target: "partner",
			n: 2
		}]
	})
], _ = new Map(g.map((e) => [e.id, e])), v = (e) => e, y = [
	v({
		id: "bodvar",
		nameKey: "games.tagteam.fighters.bodvar",
		titleKey: "games.tagteam.fighters.bodvar_title",
		emoji: "🐻",
		color: "#92400e",
		basePower: 3,
		maxHp: 11,
		stops: [],
		powerIcons: [6]
	}),
	v({
		id: "ching",
		nameKey: "games.tagteam.fighters.ching",
		titleKey: "games.tagteam.fighters.ching_title",
		emoji: "🏴‍☠️",
		color: "#0f766e",
		basePower: 2,
		maxHp: 14,
		stops: [],
		powerIcons: []
	}),
	v({
		id: "fey",
		nameKey: "games.tagteam.fighters.fey",
		titleKey: "games.tagteam.fighters.fey_title",
		emoji: "🧚",
		color: "#65a30d",
		basePower: 0,
		maxHp: 5,
		stops: [],
		powerIcons: []
	}),
	v({
		id: "golem",
		nameKey: "games.tagteam.fighters.golem",
		titleKey: "games.tagteam.fighters.golem_title",
		emoji: "🗿",
		color: "#57534e",
		basePower: 1,
		maxHp: 25,
		stops: [],
		powerIcons: [
			10,
			15,
			20
		]
	}),
	v({
		id: "jeanne",
		nameKey: "games.tagteam.fighters.jeanne",
		titleKey: "games.tagteam.fighters.jeanne_title",
		emoji: "🛡️",
		color: "#b45309",
		basePower: 1,
		maxHp: 18,
		stops: [],
		powerIcons: []
	}),
	v({
		id: "maman",
		nameKey: "games.tagteam.fighters.maman",
		titleKey: "games.tagteam.fighters.maman_title",
		emoji: "🕯️",
		color: "#701a75",
		basePower: 2,
		maxHp: 16,
		stops: [],
		powerIcons: []
	}),
	v({
		id: "mephisto",
		nameKey: "games.tagteam.fighters.mephisto",
		titleKey: "games.tagteam.fighters.mephisto_title",
		emoji: "😈",
		color: "#991b1b",
		basePower: 1,
		maxHp: 13,
		stops: [],
		powerIcons: []
	}),
	v({
		id: "milady",
		nameKey: "games.tagteam.fighters.milady",
		titleKey: "games.tagteam.fighters.milady_title",
		emoji: "🗡️",
		color: "#be185d",
		basePower: 1,
		maxHp: 16,
		stops: [1],
		powerIcons: []
	}),
	v({
		id: "mordred",
		nameKey: "games.tagteam.fighters.mordred",
		titleKey: "games.tagteam.fighters.mordred_title",
		emoji: "🖤",
		color: "#1e293b",
		basePower: 0,
		maxHp: 19,
		stops: [],
		powerIcons: []
	}),
	v({
		id: "shango",
		nameKey: "games.tagteam.fighters.shango",
		titleKey: "games.tagteam.fighters.shango_title",
		emoji: "⚡",
		color: "#b91c1c",
		basePower: 0,
		maxHp: 15,
		stops: [],
		powerIcons: []
	}),
	v({
		id: "wildbunch",
		nameKey: "games.tagteam.fighters.wildbunch",
		titleKey: "games.tagteam.fighters.wildbunch_title",
		emoji: "🤠",
		color: "#a16207",
		basePower: 1,
		maxHp: 5,
		stops: [
			1,
			2,
			3,
			4
		],
		powerIcons: []
	}),
	v({
		id: "wong",
		nameKey: "games.tagteam.fighters.wong",
		titleKey: "games.tagteam.fighters.wong_title",
		emoji: "🥋",
		color: "#1d4ed8",
		basePower: 2,
		maxHp: 17,
		stops: [],
		powerIcons: []
	})
], b = new Map(y.map((e) => [e.id, e])), x = [
	{
		hp: 3,
		nameKey: "games.tagteam.feyChars.c0",
		startPower: "partner"
	},
	{
		hp: 4,
		nameKey: "games.tagteam.feyChars.c1",
		startPower: "partner"
	},
	{
		hp: 5,
		nameKey: "games.tagteam.feyChars.c2",
		startPower: "self"
	}
], ee = [
	"unleashPower",
	"poison",
	"poison",
	"poison",
	"bothPower1",
	"unleashAttack",
	"ddAll",
	"selfPower2",
	"healPartner6",
	"partnerPower2",
	"attackBoth"
], S = {
	id: "tagteam",
	tier: "alpha",
	mechanics: ["deck-bag-building"],
	interactionTags: [],
	nameKey: "games.tagteam.name",
	descKey: "games.tagteam.desc",
	rulesKey: "games.tagteam.rules",
	icon: "🥊",
	iconImg: "games/tagteam.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/tagteam/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#c2410c",
	releasedAt: "2026-09-16",
	search: {
		py: "shuang xia xiao dui",
		init: "sxxd"
	},
	hotseat: "cover"
}, C = t.enum([
	"bodvar",
	"ching",
	"fey",
	"golem",
	"jeanne",
	"maman",
	"mephisto",
	"milady",
	"mordred",
	"shango",
	"wildbunch",
	"wong"
]), w = t.union([
	t.literal(0),
	t.literal(1),
	t.literal(2)
]), te = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draftPick"),
		fighter: C,
		ban: C.optional()
	}),
	t.object({
		type: t.literal("freePick"),
		fighters: t.tuple([C, C])
	}),
	t.object({
		type: t.literal("order"),
		first: t.union([t.literal(0), t.literal(1)]),
		feyChar: w.optional()
	}),
	t.object({
		type: t.literal("feyNext"),
		char: w
	}),
	t.object({
		type: t.literal("buildPick"),
		card: t.string(),
		pos: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), T = t.object({ draftMode: t.enum([
	"free",
	"standard",
	"competitive"
]).default("free") }).default({ draftMode: "free" }), E = t.object({
	card: t.string(),
	flip: t.enum([
		"greenman",
		"leshi",
		"redcap"
	]).optional(),
	removed: t.boolean().optional()
}), D = t.object({
	id: C,
	hp: t.int(),
	power: t.int().nonnegative(),
	bear: t.boolean(),
	rage: t.int().nonnegative().nullable(),
	ship: t.int().nonnegative().nullable(),
	voice: t.int().nonnegative().nullable(),
	serpent: t.enum(["black", "white"]).nullable(),
	feyHp: t.array(t.int().nonnegative()).nullable(),
	feyActive: t.int().min(0).max(2).nullable(),
	spirits: t.int().min(1).max(4).nullable(),
	aflame: t.int().nonnegative(),
	concentration: t.boolean(),
	golemToken: t.boolean(),
	sheriff: t.boolean()
}), ne = t.object({
	fighters: t.tuple([D, D]),
	deckCount: t.int().nonnegative(),
	revealed: t.array(E),
	buildCount: t.int().nonnegative(),
	schemePile: t.int().nonnegative().nullable(),
	schemesPlanted: t.int().nonnegative().nullable()
}), re = t.object({
	phase: t.enum([
		"draft",
		"order",
		"fight",
		"build",
		"done"
	]),
	round: t.int().min(1),
	players: t.tuple([t.string(), t.string()]),
	teams: t.tuple([ne, ne]).nullable(),
	draft: t.object({
		mode: t.enum([
			"free",
			"standard",
			"competitive"
		]),
		step: t.int().min(0).max(1),
		picks: t.tuple([t.array(C), t.array(C)]),
		submitted: t.tuple([t.boolean(), t.boolean()]),
		handSize: t.tuple([t.int().nonnegative(), t.int().nonnegative()])
	}).nullable(),
	orderReady: t.tuple([t.boolean(), t.boolean()]).nullable(),
	turn: t.int().nonnegative(),
	buildReady: t.tuple([t.boolean(), t.boolean()]).nullable(),
	pendingFey: t.union([t.literal(0), t.literal(1)]).nullable(),
	result: t.object({
		winner: t.union([t.literal(0), t.literal(1)]).nullable(),
		reason: t.enum([
			"ko",
			"doubleKo",
			"deckOut",
			"incinerated",
			"dragHell",
			"legendsPass"
		])
	}).nullable()
}), ie = t.object({
	hand: t.array(C).nullable(),
	myDraftPick: C.nullable(),
	myDraftBan: C.nullable(),
	myOrderReady: t.boolean(),
	myDeck: t.array(E),
	drawn: t.array(t.string()).nullable(),
	myBuildPick: t.object({
		card: t.string(),
		pos: t.int().nonnegative()
	}).nullable(),
	feyOptions: t.array(w).nullable()
}), ae = 1600, oe = 9e4, O = y.map((e) => e.id);
function k(t, n) {
	let r = e(t.seed, t.rngCursor, n);
	return t.rngCursor += 1, r;
}
function A(e, t) {
	for (let n = t.length - 1; n > 0; --n) {
		let r = k(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
}
var j = (e) => _.get(e.flip ? `fey.${e.flip}` : e.card), se = (e) => ({
	id: e,
	hp: b.get(e).maxHp,
	power: b.get(e).basePower,
	bear: !1,
	rage: e === "bodvar" ? 0 : null,
	ship: e === "ching" ? 0 : null,
	voice: e === "jeanne" ? 0 : null,
	serpent: null,
	feyHp: e === "fey" ? x.map((e) => e.hp) : null,
	feyActive: null,
	spirits: e === "fey" ? 1 : null,
	aflame: 0,
	concentration: !1,
	golemToken: !1,
	golemFresh: !1,
	sheriff: e === "wildbunch",
	feyKo: !1,
	transformedThisTurn: !1,
	fellThisTurn: !1
});
function ce(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		players: [t[0], t[1]],
		mode: e.draftMode,
		phase: "draft",
		round: 1,
		turn: 0,
		teams: null,
		draft: null,
		orderReady: null,
		build: null,
		pendingFey: null,
		result: null
	};
	if (r.mode === "free") r.draft = {
		step: 0,
		hands: [[], []],
		picks: [[], []],
		pending: [{}, {}],
		submitted: [!1, !1]
	};
	else {
		let e = [...O];
		A(r, e), r.draft = {
			step: 0,
			hands: [e.slice(0, 6), e.slice(6, 12)],
			picks: [[], []],
			pending: [{}, {}],
			submitted: [!1, !1]
		};
	}
	return {
		state: r,
		fx: [{
			kind: "draftStart",
			data: { mode: r.mode }
		}]
	};
}
function M(e) {
	let t = (t) => {
		let n = t.map(se);
		for (let t of n) t.id === "mephisto" && (t.serpent = k(e, 2) === 0 ? "black" : "white");
		let r = [];
		for (let e of t) for (let t of _.values()) {
			if (t.fighter !== e || t.copies === 0) continue;
			let n = t.copies - +!!t.star;
			for (let e = 0; e < n; e += 1) r.push(t.id);
		}
		A(e, r);
		let i = t.includes("milady"), a = i ? [...ee] : null;
		return a && A(e, a), {
			fighters: n,
			fightDeck: [],
			revealed: [],
			buildDeck: r,
			reanimateNext: !1,
			schemePile: a,
			schemesPlanted: i ? [] : null
		};
	};
	return e.teams = [t(e.draft.picks[0]), t(e.draft.picks[1])], e.draft = null, e.orderReady = [!1, !1], e.phase = "order", [{ kind: "orderStart" }];
}
var le = (e) => {
	for (let t of _.values()) if (t.fighter === e && t.star) return t.id;
	throw Error(`no starter for ${e}`);
}, N = (e, t) => e.teams[t >> 1].fighters[t & 1];
function P(e, t) {
	let n = N(e, t);
	return n.feyHp ? n.feyHp[n.feyActive ?? 0] : n.hp;
}
function F(e) {
	return e.feyHp ? x[e.feyActive ?? 0].hp : e.bear ? 15 : b.get(e.id).maxHp;
}
function I(e, t, n, r, i, a) {
	return (typeof e == "number" ? e : e === "power" ? n.snap[i] : e === "oppPower" ? n.snap[a ?? n.active[1 - r]] : e === "attackerPower" ? n.snap[n.active[1 - r]] : e === "spirits" ? n.spiritsSnap[r] : e === "halfTargetHp" ? Math.floor(P(n.s, a ?? n.active[1 - r]) / 2) : P(n.s, a ?? n.active[1 - r])) * (t ?? 1);
}
function ue(e, t, n, r, i) {
	let a = N(t.s, r), o = N(t.s, r ^ 1);
	switch (e.k) {
		case "powerGte": return t.snap[r] >= e.n;
		case "oppStarter": {
			let e = t.s.teams[1 - n].revealed, r = e[e.length - 1];
			return !!r && !!_.get(r.card)?.star;
		}
		case "ship": return (a.ship ?? 0) >= e.min && (a.ship ?? 0) <= e.max;
		case "sheriff": {
			let r = N(t.s, n << 1 | 0).sheriff || N(t.s, n << 1 | 1).sheriff;
			return e.who === "self" ? r : !r;
		}
		case "partnerHasToken": return o.golemToken;
		case "noPartnerToken": return !o.golemToken;
		case "serpent": return a.serpent === e.face;
		case "human": return !a.bear;
		case "bear": return a.bear;
		case "healedFull": return P(t.s, r) >= F(a);
		case "selfAttacked": return i === "late" ? t.selfAttacked[n] : "defer";
		case "attackBlocked": return i === "late" ? t.attackBlocked[n] : "defer";
		case "noOppAttacks": return i === "late" ? t.noOppAttacks[n] : "defer";
	}
}
function de(e, t, n, r) {
	let i = n.active[1 - t], a = e.target ?? "opponent";
	return a === "opponent" ? [i] : a === "oppPartner" ? [i ^ 1] : a === "bothOpponents" ? [i, i ^ 1] : [
		0,
		1,
		2,
		3
	].filter((e) => e !== r);
}
function fe(e, t, n, r, i) {
	let a = e.by === "partner" ? r ^ 1 : r, o;
	return o = e.power === "oppPower" ? t.snap[i] : e.power === "flamepower" ? t.snap[r] + N(t.s, i).aflame : t.snap[a], e.plusSpirits && (o += t.spiritsSnap[n]), o;
}
function pe(e, t, n, r) {
	for (let i of de(e, n, t, r)) t.attacks.push({
		src: e.by === "partner" ? r ^ 1 : r,
		targets: [i],
		power: fe(e, t, n, r, i),
		success: e.success
	});
}
function me(e, t, n, r) {
	if (t.voice !== null) for (let i = 0; i < r; i += 1) t.voice = (t.voice + 1) % 5, t.voice === 2 ? (t.power += 1, e.fx.push({
		kind: "power",
		data: {
			ref: n,
			n: 1,
			via: "voice"
		}
	})) : t.voice === 4 && (N(e.s, n ^ 1).power += 1, e.fx.push({
		kind: "power",
		data: {
			ref: n ^ 1,
			n: 1,
			via: "voice"
		}
	}));
}
function he(e, t, n, r) {
	t.rage === null || t.bear || (t.rage = Math.min(6, t.rage + r), t.rage >= 6 && (t.power += 3, t.bear = !0, t.transformedThisTurn = !0, t.hp = Math.min(15, t.power), t.rage = null, e.fx.push({
		kind: "transform",
		data: {
			ref: n,
			hp: t.hp
		}
	})));
}
function ge(e, t) {
	let n = N(e.s, t), r = n.aflame > 0;
	n.aflame = Math.min(5, n.aflame + 1), !r && N(e.s, t ^ 1).aflame > 0 && (N(e.s, t ^ 1).aflame = 0, e.fx.push({
		kind: "aflameClear",
		data: { ref: t ^ 1 }
	})), e.fx.push({
		kind: "aflame",
		data: {
			ref: t,
			n: n.aflame
		}
	});
}
function _e(e, t) {
	let n = e.s.teams[t];
	n.schemePile && n.schemesPlanted && n.schemePile.length !== 0 && (n.schemesPlanted.push(n.schemePile.shift()), e.fx.push({
		kind: "plant",
		data: {
			side: t,
			n: n.schemesPlanted.length
		}
	}));
}
function L(e, t, n) {
	let r = e.s, i = r.teams[t];
	if (!i.schemesPlanted || i.schemesPlanted.length === 0) return;
	let a = t << 1 | (i.fighters[0].id === "milady" ? 0 : 1), o = k(r, i.schemesPlanted.length), s = i.schemesPlanted.splice(o, 1)[0];
	e.fx.push({
		kind: "scheme",
		data: {
			side: t,
			scheme: s,
			via: n
		}
	});
	let c = a ^ 1, l = e.active[1 - t];
	switch (s) {
		case "unleashPower":
			N(r, c).power += 1, L(e, t, n);
			return;
		case "unleashAttack":
			e.attacks.push({
				src: a,
				targets: [l],
				power: N(r, a).power
			}), L(e, t, n);
			return;
		case "attackBoth":
			e.attacks.push({
				src: a,
				targets: [l],
				power: N(r, a).power
			}), e.attacks.push({
				src: a,
				targets: [l ^ 1],
				power: N(r, a).power
			});
			return;
		case "ddAll":
			for (let t = 0; t < 4; t += 1) e.dmg[t] += 1;
			return;
		case "bothPower1":
			N(r, a).power += 1, N(r, c).power += 1;
			return;
		case "selfPower2":
			N(r, a).power += 2;
			return;
		case "partnerPower2":
			N(r, c).power += 2;
			return;
		case "healPartner6":
			e.heal[c] += 6;
			return;
		case "poison":
			e.poisons.push(l);
			return;
	}
}
function R(e, t, n) {
	let r = e.s, i = N(r, t);
	if (n === 0) return;
	let a = !!i.feyHp;
	if (a && i.spirits === 4) return;
	let o = i.bear ? [] : b.get(i.id).stops, s = i.id === "maman", c = s ? -2 : 0, l = P(r, t), u = l, d = n > 0 ? -1 : 1, f = Math.abs(n);
	for (; f > 0;) {
		let n = l + d;
		if (d < 0 && n < c || d > 0 && (l <= (s ? -1 : 0) || n > F(i)) || (l = n, --f, !a && !i.bear && (b.get(i.id).powerIcons.includes(l) && e.icons.push({
			ref: t,
			icon: "power"
		}), i.id === "mephisto" && l === 8 && e.icons.push({
			ref: t,
			icon: "serpent"
		}), i.id === "milady" && (l === 2 || l === 8 || l === 12) && e.icons.push({
			ref: t,
			icon: "scheme"
		})), o.includes(l))) break;
	}
	l !== u && (a ? (i.feyHp[i.feyActive ?? 0] = l, l <= 0 && (i.fellThisTurn = !0, e.fx.push({
		kind: "feySpirit",
		data: { ref: t }
	}))) : i.hp = l, e.fx.push({
		kind: "hp",
		data: {
			ref: t,
			from: u,
			to: l
		}
	}));
}
function z(e, t) {
	let n = e.s, r = e.icons;
	e.icons = [];
	let i = [];
	for (let { ref: t, icon: a } of r) {
		let r = N(n, t);
		a === "power" ? (r.power += 1, e.fx.push({
			kind: "power",
			data: {
				ref: t,
				n: 1,
				via: "track"
			}
		})) : a === "serpent" ? (r.serpent = r.serpent === "black" ? "white" : "black", e.fx.push({
			kind: "serpentFlip",
			data: {
				ref: t,
				face: r.serpent
			}
		})) : i.push(t >> 1);
	}
	if (t < 3) {
		for (let t of i) L(e, t, "icon");
		i.length > 0 && (V(e), z(e, t + 1));
	}
}
function B(e) {
	let t = e.s, n = e.attacks;
	e.attacks = [];
	for (let r of n) {
		let n = r.src >> 1;
		if (e.block[1 - n]) {
			e.fx.push({
				kind: "blocked",
				data: {
					src: r.src,
					target: r.targets[0]
				}
			});
			continue;
		}
		for (let n of r.targets) {
			let i = N(t, n);
			if (i.golemToken && !i.golemFresh && i.id !== "golem") {
				i.golemToken = !1, e.fx.push({
					kind: "golemSave",
					data: { ref: n }
				});
				continue;
			}
			e.dmg[n] += r.power, e.fx.push({
				kind: "attack",
				data: {
					src: r.src,
					target: n,
					power: r.power
				}
			});
		}
	}
}
function V(e) {
	let t = e.s;
	for (let n = 0; n < 4; n += 1) {
		if (e.dmg[n] === 0 && e.heal[n] === 0) continue;
		let r = N(t, n), i = e.immune[n] || r.transformedThisTurn ? 0 : e.dmg[n] - e.heal[n];
		e.dmg[n] = 0, e.heal[n] = 0, R(e, n, i);
	}
	for (; e.poisons.length > 0;) {
		let n = e.poisons.shift(), r = Math.floor(P(t, n) / 2);
		r > 0 && !e.immune[n] && R(e, n, r), e.fx.push({
			kind: "poison",
			data: {
				ref: n,
				n: r
			}
		});
	}
}
var ve = /* @__PURE__ */ new Set([
	"selfAttacked",
	"attackBlocked",
	"noOppAttacks"
]);
function H(e, t, n, r) {
	let i = e.active[t];
	for (let a of n.effects) {
		let n = !!a.if && ve.has(a.if.k);
		r === "late" === n && (a.if && ue(a.if, e, t, i, r) !== !0 || U(e, t, i, a));
	}
}
function U(e, t, n, r) {
	let i = e.s, a = N(i, n), o = n ^ 1, s = e.active[1 - t];
	switch (r.k) {
		case "attack":
			pe(r, e, t, n);
			return;
		case "block":
			e.block[t] = !0, r.success && e.pendingSuccess.push({
				side: t,
				effects: r.success
			});
			return;
		case "heal": {
			let i = I(r.n, r.mult, e, t, n, null);
			r.target === "self" ? e.heal[n] += i : (r.target === "partner" || (e.heal[n] += i), e.heal[o] += i);
			return;
		}
		case "power": {
			let t = r.target === "self" ? [n] : r.target === "partner" ? [o] : r.target === "both" ? [n, o] : [s];
			for (let n of t) N(i, n).power = Math.max(0, N(i, n).power + r.n), e.fx.push({
				kind: "power",
				data: {
					ref: n,
					n: r.n,
					via: "card"
				}
			});
			return;
		}
		case "dd": {
			let i = r.target === "self" ? [n] : r.target === "partner" ? [o] : r.target === "opponent" ? [s] : r.target === "bothOpponents" ? [s, s ^ 1] : [
				0,
				1,
				2,
				3
			];
			for (let a of i) {
				let i = I(r.n, void 0, e, t, n, a);
				i <= 0 || (e.dmg[a] += i, e.fx.push({
					kind: "dd",
					data: {
						ref: a,
						n: i
					}
				}));
			}
			return;
		}
		case "cancel": return;
		case "transferPower": {
			let t = r.from === "self" ? n : o, a = t ^ 1, s = Math.min(r.n, N(i, t).power);
			N(i, t).power -= s, N(i, a).power += s, e.fx.push({
				kind: "transfer",
				data: {
					from: t,
					to: a,
					n: s
				}
			});
			return;
		}
		case "setPowerToPartner":
			a.power = N(i, o).power, e.fx.push({
				kind: "power",
				data: {
					ref: n,
					n: a.power,
					via: "balance"
				}
			});
			return;
		case "ship": {
			if (a.ship === null) return;
			let t = a.ship;
			a.ship = Math.min(20, a.ship + r.n), e.fx.push({
				kind: "ship",
				data: {
					ref: n,
					from: t,
					to: a.ship
				}
			});
			return;
		}
		case "ship20":
			if (a.ship === null) return;
			for (let t of [s, s ^ 1]) {
				let n = P(i, t) - 1;
				n > 0 && (e.fx.push({
					kind: "dd",
					data: {
						ref: t,
						n
					}
				}), R(e, t, n)), e.immune[t] = !0;
			}
			a.ship = 0, e.fx.push({
				kind: "ship20",
				data: { ref: n }
			});
			return;
		case "rage":
			he(e, a, n, r.n);
			return;
		case "voice":
			me(e, a, n, r.n);
			return;
		case "aflame":
			ge(e, s);
			return;
		case "plantScheme":
			_e(e, t);
			return;
		case "unleashScheme":
			L(e, t, "card");
			return;
		case "serpentFlip":
			a.serpent && (a.serpent = a.serpent === "black" ? "white" : "black", e.fx.push({
				kind: "serpentFlip",
				data: {
					ref: n,
					face: a.serpent
				}
			}));
			return;
		case "golemToken": {
			let t = N(i, o);
			t.golemToken = !0, t.golemFresh = !0, e.fx.push({
				kind: "golemToken",
				data: { ref: o }
			});
			return;
		}
		case "reanimate":
			i.teams[t].reanimateNext = !0, e.fx.push({
				kind: "reanimate",
				data: { side: t }
			});
			return;
		case "removeOppCardThenSelf":
			e.cripple[t] = !0;
			return;
		case "summonFlip": {
			let n = i.teams[t].revealed, a = n[n.length - 1];
			a && a.card.startsWith("fey.summon_") && (a.flip = r.to, e.fx.push({
				kind: "summonFlip",
				data: {
					side: t,
					to: r.to
				}
			}));
			return;
		}
		case "koIfAllSpirits":
			a.spirits === 4 && (a.feyKo = !0, e.fx.push({
				kind: "legendsPass",
				data: { ref: n }
			}));
			return;
		case "dragToHell":
			e.dragHell[t] = !0, e.fx.push({
				kind: "dragHell",
				data: { side: t }
			});
			return;
		case "eternalYouth":
			e.eternalYouth[t] = !0;
			return;
		case "youAreMine":
			e.youAreMine[t] = !0, e.fx.push({
				kind: "youAreMine",
				data: { side: t }
			});
			return;
		case "execution":
			e.execution[t] = !0;
			return;
		case "sheriffGive": {
			let t = [
				0,
				1,
				2,
				3
			].find((e) => N(i, e).sheriff);
			t !== void 0 && (N(i, t).sheriff = !1);
			let a = r.to === "self" ? n : s;
			N(i, a).sheriff = !0, e.fx.push({
				kind: "sheriff",
				data: { ref: a }
			});
			return;
		}
		case "sheriffHolderPower": {
			let t = [
				0,
				1,
				2,
				3
			].find((e) => N(i, e).sheriff);
			t !== void 0 && (N(i, t).power += r.n, e.fx.push({
				kind: "power",
				data: {
					ref: t,
					n: r.n,
					via: "sheriff"
				}
			}));
			return;
		}
		case "concentration": {
			let t = N(i, s);
			t.concentration ? (e.attacks.push({
				src: n,
				targets: [s],
				power: e.snap[s]
			}), t.concentration = !1, e.fx.push({
				kind: "concentrationBack",
				data: { ref: s }
			})) : (t.concentration = !0, e.fx.push({
				kind: "concentration",
				data: { ref: s }
			}));
			return;
		}
	}
}
function ye(e) {
	let t = e.teams, n = [];
	e.turn += 1;
	for (let t = 0; t < 4; t += 1) {
		let n = N(e, t);
		n.golemFresh = !1, n.transformedThisTurn = !1, n.fellThisTurn = !1;
	}
	let r = [t[0].fightDeck.shift(), t[1].fightDeck.shift()];
	t[0].revealed.push(r[0]), t[1].revealed.push(r[1]);
	let i = [j(r[0]), j(r[1])], a = [t[0].fighters[0].id === i[0].fighter ? 0 : 1, t[1].fighters[0].id === i[1].fighter ? 2 : 3];
	for (let t of [0, 1]) n.push({
		kind: "reveal",
		data: {
			side: t,
			card: r[t].card,
			flip: r[t].flip ?? null,
			turn: e.turn
		}
	});
	let o = [t[0].reanimateNext && i[0].id !== "wong.crippling_touch", t[1].reanimateNext && i[1].id !== "wong.crippling_touch"];
	t[0].reanimateNext = !1, t[1].reanimateNext = !1;
	let s = [i[1].effects.some((e) => e.k === "cancel"), i[0].effects.some((e) => e.k === "cancel")];
	for (let e of [0, 1]) s[e] && n.push({
		kind: "cancel",
		data: { side: e }
	});
	let c = {
		s: e,
		fx: n,
		snap: [
			0,
			1,
			2,
			3
		].map((t) => N(e, t).power),
		spiritsSnap: [t[0].fighters.find((e) => e.id === "fey")?.spirits ?? 0, t[1].fighters.find((e) => e.id === "fey")?.spirits ?? 0],
		active: a,
		attacks: [],
		block: [!1, !1],
		pendingSuccess: [],
		dmg: [
			0,
			0,
			0,
			0
		],
		heal: [
			0,
			0,
			0,
			0
		],
		poisons: [],
		youAreMine: [!1, !1],
		eternalYouth: [!1, !1],
		dragHell: [!1, !1],
		cripple: [!1, !1],
		execution: [!1, !1],
		immune: [
			!1,
			!1,
			!1,
			!1
		],
		selfAttacked: [!1, !1],
		attackBlocked: [!1, !1],
		noOppAttacks: [!1, !1],
		icons: []
	};
	for (let e of [0, 1]) s[e] || H(c, e, i[e], "early");
	for (let e of [0, 1]) c.selfAttacked[e] = c.attacks.some((t) => t.src >> 1 == 1 - e && t.targets.some((t) => t >> 1 === e)), c.noOppAttacks[e] = !c.attacks.some((t) => t.src >> 1 == 1 - e);
	for (let e of [0, 1]) c.attackBlocked[e] = c.block[1 - e] && c.attacks.some((t) => t.src >> 1 === e);
	for (let e of [0, 1]) s[e] || H(c, e, i[e], "late");
	let l = [c.block[0] && c.attacks.some((e) => e.src >> 1 == 1), c.block[1] && c.attacks.some((e) => !(e.src >> 1))];
	for (let e of [0, 1]) {
		if (!c.youAreMine[e]) continue;
		let t = c.active[1 - e] ^ 1;
		for (let n of c.attacks) n.src >> 1 == 1 - e && (n.targets = n.targets.map((n) => n >> 1 === e ? t : n));
	}
	let u = [], d = c.attacks;
	c.attacks = [];
	for (let t of d) {
		let r = t.src >> 1;
		if (c.block[1 - r]) {
			n.push({
				kind: "blocked",
				data: {
					src: t.src,
					target: t.targets[0]
				}
			});
			continue;
		}
		let i = !1;
		for (let r of t.targets) {
			let a = N(e, r);
			if (a.golemToken && !a.golemFresh && a.id !== "golem") {
				a.golemToken = !1, n.push({
					kind: "golemSave",
					data: { ref: r }
				}), i = !0;
				continue;
			}
			c.dmg[r] += t.power, i = !0, n.push({
				kind: "attack",
				data: {
					src: t.src,
					target: r,
					power: t.power
				}
			});
		}
		i && t.success && u.push({
			side: r,
			effects: t.success
		});
	}
	for (let e of [0, 1]) if (l[e]) for (let t of c.pendingSuccess) t.side === e && u.push(t);
	for (let e of u) for (let t of e.effects) U(c, e.side, c.active[e.side], t);
	B(c);
	for (let t of [0, 1]) {
		if (!c.eternalYouth[t]) continue;
		let r = c.active[t], i = 0;
		for (let n of [1 - t << 1, 1 - t << 1 | 1]) c.heal[n] > 0 && (i += Math.min(c.heal[n], Math.max(0, F(N(e, n)) - P(e, n))), c.heal[n] = 0);
		i > 0 && (Math.max(0, F(N(e, r)) - P(e, r)) > 0 && (c.heal[r] += i, N(e, r).power += 2), n.push({
			kind: "eternalYouth",
			data: {
				side: t,
				n: i
			}
		}));
	}
	V(c), z(c, 0);
	for (let n of [0, 1]) o[n] && !s[n] && (c.snap = [
		0,
		1,
		2,
		3
	].map((t) => N(e, t).power), c.spiritsSnap = [t[0].fighters.find((e) => e.id === "fey")?.spirits ?? 0, t[1].fighters.find((e) => e.id === "fey")?.spirits ?? 0], c.selfAttacked = [!1, !1], c.attackBlocked = [!1, !1], c.noOppAttacks = [!0, !0], c.pendingSuccess = [], H(c, n, i[n], "early"), H(c, n, i[n], "late"), B(c), V(c), z(c, 0));
	for (let t of [0, 1]) {
		if (!c.execution[t]) continue;
		let r = c.active[1 - t], i = P(e, r);
		i > 0 && i <= 4 && (n.push({
			kind: "execution",
			data: {
				ref: r,
				n: i
			}
		}), R(c, r, i), z(c, 0));
	}
	for (let e of [0, 1]) c.cripple[e] && (r[1 - e].removed = !0, r[e].removed = !0, n.push({
		kind: "cripple",
		data: { side: e }
	}));
	for (let t = 0; t < 4; t += 1) {
		let r = N(e, t);
		r.id === "maman" && r.hp === -2 && (r.power += 1, r.hp = 4, n.push({
			kind: "revive",
			data: { ref: t }
		}));
	}
	let f = be(e, c);
	if (f) return [...n, ...f];
	for (let r of [0, 1]) {
		let i = t[r].fighters.find((e) => e.id === "fey");
		i?.fellThisTurn && (i.spirits = Math.min(4, (i.spirits ?? 1) + 1), i.feyHp.some((e) => e > 0) && (e.pendingFey = r, n.push({
			kind: "feyChoose",
			data: { side: r }
		})));
	}
	return t[0].fightDeck.length === 0 && t[1].fightDeck.length === 0 ? [...n, ...xe(e)] : n;
}
function be(e, t) {
	let n = e.teams, r = [!1, !1], i = [!1, !1];
	for (let e of [0, 1]) for (let t of n[e].fighters) t.feyHp ? t.feyKo && (r[e] = !0) : t.id === "maman" ? (t.hp === 0 || t.hp === -1) && (r[e] = !0) : t.hp <= 0 && (r[e] = !0), t.aflame >= 5 && (i[e] = !0);
	let a = [r[0] || i[0], r[1] || i[1]];
	if (!a[0] && !a[1]) return null;
	for (let n of [0, 1]) if (t.dragHell[n] && a[n]) return e.result = {
		winner: n,
		reason: "dragHell"
	}, e.phase = "done", [{
		kind: "gameOver",
		data: {
			winner: n,
			reason: "dragHell"
		}
	}];
	if (i[0] !== i[1]) {
		let t = +!i[0];
		return e.result = {
			winner: 1 - t,
			reason: "incinerated"
		}, e.phase = "done", [{
			kind: "gameOver",
			data: {
				winner: 1 - t,
				reason: "incinerated"
			}
		}];
	}
	if (a[0] && a[1]) return e.result = {
		winner: null,
		reason: "doubleKo"
	}, e.phase = "done", [{
		kind: "gameOver",
		data: {
			winner: null,
			reason: "doubleKo"
		}
	}];
	let o = +!a[0], s = n[o].fighters.some((e) => e.feyKo);
	return e.result = {
		winner: 1 - o,
		reason: s ? "legendsPass" : "ko"
	}, e.phase = "done", [{
		kind: "gameOver",
		data: {
			winner: 1 - o,
			reason: e.result.reason
		}
	}];
}
function xe(e) {
	let t = e.teams;
	for (let e of t) e.fightDeck = e.revealed.filter((e) => !e.removed), e.revealed = [];
	return t.some((e) => e.buildDeck.length < 3) ? (e.result = {
		winner: null,
		reason: "deckOut"
	}, e.phase = "done", [{
		kind: "gameOver",
		data: {
			winner: null,
			reason: "deckOut"
		}
	}]) : (e.build = {
		drawn: [t[0].buildDeck.splice(0, 3), t[1].buildDeck.splice(0, 3)],
		picks: [null, null]
	}, e.phase = "build", [
		{
			kind: "buildStart",
			data: { round: e.round }
		},
		{
			kind: "buildDraw",
			data: { n: 3 },
			for: [e.players[0]]
		},
		{
			kind: "buildDraw",
			data: { n: 3 },
			for: [e.players[1]]
		}
	]);
}
function W(e) {
	let t = e.teams, n = [];
	for (let r of [0, 1]) {
		let i = t[r], a = e.build.picks[r], o = e.build.drawn[r], s = o.indexOf(a.card);
		i.fightDeck.splice(Math.min(a.pos, i.fightDeck.length), 0, { card: a.card }), i.buildDeck.push(...o.filter((e, t) => t !== s));
		let c = _.get(a.card);
		if (c?.instantBonus) {
			n.push({
				kind: "instantBonus",
				data: {
					side: r,
					fighter: c.fighter
				}
			});
			let t = r << 1 | (i.fighters[0].id === c.fighter ? 0 : 1), a = Se(e, n, r, t);
			for (let e of c.instantBonus) U(a, r, t, e);
			V(a), z(a, 0);
		}
	}
	return e.build = null, e.round += 1, e.turn = 0, e.phase = "fight", n.push({
		kind: "roundStart",
		data: { round: e.round }
	}), n;
}
function Se(e, t, n, r) {
	return {
		s: e,
		fx: t,
		snap: [
			0,
			1,
			2,
			3
		].map((t) => N(e, t).power),
		spiritsSnap: [0, 0],
		active: [r, 1 - n << 1 | 0],
		attacks: [],
		block: [!1, !1],
		pendingSuccess: [],
		dmg: [
			0,
			0,
			0,
			0
		],
		heal: [
			0,
			0,
			0,
			0
		],
		poisons: [],
		youAreMine: [!1, !1],
		eternalYouth: [!1, !1],
		dragHell: [!1, !1],
		cripple: [!1, !1],
		execution: [!1, !1],
		immune: [
			!1,
			!1,
			!1,
			!1
		],
		selfAttacked: [!1, !1],
		attackBlocked: [!1, !1],
		noOppAttacks: [!0, !0],
		icons: []
	};
}
function Ce(e, t, n) {
	if (e.phase === "done") return { code: "games.tagteam.errDone" };
	let r = structuredClone(e);
	if (t.type === "tick") return {
		state: r,
		fx: we(r)
	};
	let i = r.players.indexOf(n.by);
	if (i < 0) return { code: "games.tagteam.errNotPlayer" };
	if (r.phase === "draft") {
		let e = r.draft;
		if (r.mode === "free") {
			if (t.type !== "freePick") return { code: "games.tagteam.errBadAction" };
			if (e.submitted[i]) return { code: "games.tagteam.errSubmitted" };
			if (t.fighters[0] === t.fighters[1] || t.fighters.some((t) => e.picks[1 - i].includes(t))) return { code: "games.tagteam.errBadPick" };
			e.picks[i] = [...t.fighters], e.submitted[i] = !0;
		} else {
			if (t.type !== "draftPick") return { code: "games.tagteam.errBadAction" };
			if (e.submitted[i]) return { code: "games.tagteam.errSubmitted" };
			let n = e.hands[i];
			if (!n.includes(t.fighter)) return { code: "games.tagteam.errBadPick" };
			if (r.mode === "competitive" && e.step === 0) {
				if (!t.ban || !n.includes(t.ban) || t.ban === t.fighter) return { code: "games.tagteam.errBadPick" };
				e.pending[i].ban = t.ban;
			} else if (t.ban) return { code: "games.tagteam.errBadPick" };
			e.pending[i].fighter = t.fighter, e.submitted[i] = !0;
		}
		return e.submitted[0] && e.submitted[1] ? {
			state: r,
			fx: K(r)
		} : {
			state: r,
			fx: []
		};
	}
	if (r.phase === "order") return t.type === "order" ? r.orderReady[i] ? { code: "games.tagteam.errSubmitted" } : G(r, i, t.first, t.feyChar) || (r.orderReady[0] && r.orderReady[1] ? (r.phase = "fight", r.turn = 0, {
		state: r,
		fx: [{
			kind: "roundStart",
			data: { round: 1 }
		}]
	}) : {
		state: r,
		fx: []
	}) : { code: "games.tagteam.errBadAction" };
	if (r.phase === "fight") {
		if (t.type !== "feyNext" || r.pendingFey !== i) return { code: "games.tagteam.errBadAction" };
		let e = r.teams[i], n = e.fighters.findIndex((e) => e.id === "fey"), a = e.fighters[n];
		if (a.feyHp[t.char] <= 0) return { code: "games.tagteam.errBadPick" };
		a.feyActive = t.char;
		let o = x[t.char].startPower === "self" ? a : e.fighters[n ^ 1];
		return o.power += 1, r.pendingFey = null, {
			state: r,
			fx: [{
				kind: "feyEnter",
				data: {
					side: i,
					char: t.char
				}
			}]
		};
	}
	if (r.phase === "build") {
		if (t.type !== "buildPick") return { code: "games.tagteam.errBadAction" };
		let e = r.build;
		if (e.picks[i]) return { code: "games.tagteam.errSubmitted" };
		if (!e.drawn[i].includes(t.card)) return { code: "games.tagteam.errBadPick" };
		let n = r.teams[i].fightDeck.length;
		return t.pos > n ? { code: "games.tagteam.errBadPick" } : (e.picks[i] = {
			card: t.card,
			pos: t.pos
		}, e.picks[0] && e.picks[1] ? {
			state: r,
			fx: W(r)
		} : {
			state: r,
			fx: []
		});
	}
	return { code: "games.tagteam.errBadAction" };
}
function G(e, t, n, r) {
	let i = e.teams[t], a = i.fighters.map((e) => le(e.id)), o = i.fighters.findIndex((e) => e.id === "fey");
	if (o >= 0) {
		if (r === void 0) return { code: "games.tagteam.errBadPick" };
		let e = i.fighters[o];
		e.feyActive = r;
		let t = x[r].startPower === "self" ? e : i.fighters[o ^ 1];
		t.power += 1;
	}
	return i.fightDeck = n === 0 ? [{ card: a[0] }, { card: a[1] }] : [{ card: a[1] }, { card: a[0] }], e.orderReady[t] = !0, null;
}
function K(e) {
	let t = e.draft, n = [];
	if (e.mode === "free") return M(e);
	for (let e of [0, 1]) {
		let r = t.pending[e].fighter;
		t.picks[e].push(r);
		let i = t.hands[e];
		i.splice(i.indexOf(r), 1), t.pending[e].ban && (i.splice(i.indexOf(t.pending[e].ban), 1), n.push({
			kind: "draftBan",
			data: { side: e }
		})), t.pending[e] = {};
	}
	return n.push({
		kind: "draftReveal",
		data: { picks: [t.picks[0][t.step], t.picks[1][t.step]] }
	}), t.step === 0 ? ([t.hands[0], t.hands[1]] = [t.hands[1], t.hands[0]], t.step = 1, t.submitted = [!1, !1], n) : [...n, ...M(e)];
}
function we(e) {
	if (e.phase === "fight") return e.pendingFey === null ? ye(e) : [];
	if (e.phase === "build") {
		let t = e.build;
		for (let n of [0, 1]) {
			if (t.picks[n]) continue;
			let r = e.teams[n].fightDeck.length;
			t.picks[n] = {
				card: t.drawn[n][0],
				pos: k(e, r + 1)
			};
		}
		return W(e);
	}
	if (e.phase === "order") {
		for (let t of [0, 1]) e.orderReady[t] || G(e, t, 0, e.teams[t].fighters.findIndex((e) => e.id === "fey") >= 0 ? 0 : void 0);
		return e.orderReady[0] && e.orderReady[1] ? (e.phase = "fight", e.turn = 0, [{
			kind: "roundStart",
			data: { round: 1 }
		}]) : [];
	}
	if (e.phase === "draft") {
		let t = e.draft;
		for (let n of [0, 1]) if (!t.submitted[n]) {
			if (e.mode === "free") {
				let r = O.filter((e) => !t.picks[1 - n].includes(e)), i = r[k(e, r.length)], a = r.filter((e) => e !== i);
				t.picks[n] = [i, a[k(e, a.length)]], t.submitted[n] = !0;
			} else {
				let r = t.hands[n];
				if (t.pending[n].fighter = r[k(e, r.length)], e.mode === "competitive" && t.step === 0) {
					let i = r.filter((e) => e !== t.pending[n].fighter);
					t.pending[n].ban = i[k(e, i.length)];
				}
				t.submitted[n] = !0;
			}
		}
		return t.submitted[0] && t.submitted[1] ? K(e) : [];
	}
	return [];
}
function q(e, t) {
	let n = e.teams[t];
	return {
		fighters: n.fighters.map((e) => ({
			id: e.id,
			hp: e.feyHp ? e.feyHp[e.feyActive ?? 0] : e.hp,
			power: e.power,
			bear: e.bear,
			rage: e.rage,
			ship: e.ship,
			voice: e.voice,
			serpent: e.serpent,
			feyHp: e.feyHp,
			feyActive: e.feyActive,
			spirits: e.spirits,
			aflame: e.aflame,
			concentration: e.concentration,
			golemToken: e.golemToken,
			sheriff: e.sheriff
		})),
		deckCount: n.fightDeck.length,
		revealed: n.revealed.map((e) => ({
			card: e.card,
			flip: e.flip,
			removed: e.removed
		})),
		buildCount: n.buildDeck.length,
		schemePile: n.schemePile ? n.schemePile.length : null,
		schemesPlanted: n.schemesPlanted ? n.schemesPlanted.length : null
	};
}
function Te(e, t) {
	let n = e.players.indexOf(t), r = e.draft, i = e.teams?.[n];
	return {
		public: {
			phase: e.phase,
			round: e.round,
			players: e.players,
			teams: e.teams ? [q(e, 0), q(e, 1)] : null,
			draft: r ? {
				mode: e.mode,
				step: r.step,
				picks: [r.picks[0], r.picks[1]],
				submitted: r.submitted,
				handSize: [r.hands[0].length, r.hands[1].length]
			} : null,
			orderReady: e.orderReady,
			turn: e.turn,
			buildReady: e.build ? [e.build.picks[0] !== null, e.build.picks[1] !== null] : null,
			pendingFey: e.pendingFey,
			result: e.result
		},
		private: {
			hand: e.phase === "draft" ? e.mode === "free" ? O.filter((e) => !r.picks[n].includes(e) && !r.picks[1 - n].includes(e)) : r?.hands[n] ?? null : null,
			myDraftPick: r?.pending[n]?.fighter ?? null,
			myDraftBan: r?.pending[n]?.ban ?? null,
			myOrderReady: e.orderReady?.[n] ?? !1,
			myDeck: i && e.phase !== "draft" && e.phase !== "order" ? i.fightDeck.map((e) => ({
				card: e.card,
				flip: e.flip
			})) : [],
			drawn: e.phase === "build" ? e.build?.drawn[n] ?? null : null,
			myBuildPick: e.build?.picks[n] ?? null,
			feyOptions: e.pendingFey === n ? i?.fighters.find((e) => e.id === "fey")?.feyHp?.map((e, t) => e > 0 ? t : -1).filter((e) => e >= 0) ?? [] : null
		}
	};
}
function Ee(e) {
	if (e.phase !== "done" || !e.result) return { phase: e.phase };
	let [t, n] = e.players;
	if (e.result.winner === null) return {
		phase: "done",
		winner: [],
		ranking: [t, n]
	};
	let r = e.players[e.result.winner], i = e.players[1 - e.result.winner];
	return {
		phase: "done",
		winner: [r],
		ranking: [r, i]
	};
}
function De(e) {
	return e.phase === "done" ? null : e.phase === "fight" ? e.pendingFey === null ? ae : null : oe;
}
var Oe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: S,
	schemas: {
		action: te,
		publicView: re,
		privateView: ie,
		config: T
	},
	setup: ce,
	reduce: Ce,
	viewFor: Te,
	status: Ee,
	nextTickIn: De
};
//#endregion
//#region src/games/tagteam/view-player.tsx
function ke(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ c(Ae, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ae({ pub: e, priv: t, members: n, myRid: r, send: s }) {
	let u = i(), d = e.players.indexOf(r), f = (e) => n.find((t) => t.rid === e)?.name ?? e, p = "info", m = "", h;
	return e.phase === "draft" && e.draft ? (h = e.draft.mode === "free" ? void 0 : u("games.tagteam.draftStep", { n: e.draft.step + 1 }), e.draft.submitted[d] ? m = u("games.tagteam.waitOpp", { name: f(e.players[1 - d]) }) : (p = "accent", m = e.draft.mode === "free" ? u("games.tagteam.pickTwo") : e.draft.mode === "competitive" && e.draft.step === 0 ? u("games.tagteam.pickAndBan") : u("games.tagteam.pickOne"))) : e.phase === "order" ? t.myOrderReady ? m = u("games.tagteam.waitOpp", { name: f(e.players[1 - d]) }) : (p = "accent", m = u("games.tagteam.orderPrompt")) : e.phase === "fight" ? (h = u("games.tagteam.roundChip", { n: e.round }), e.pendingFey === d ? (p = "accent", m = u("games.tagteam.feyChoose")) : m = e.pendingFey === null ? u("games.tagteam.fighting", { n: e.turn }) : u("games.tagteam.waitOpp", { name: f(e.players[1 - d]) })) : e.phase === "build" ? (h = u("games.tagteam.roundChip", { n: e.round }), t.myBuildPick ? m = u("games.tagteam.waitOpp", { name: f(e.players[1 - d]) }) : (p = "accent", m = u("games.tagteam.buildPrompt"))) : e.phase === "done" && e.result && (m = e.result.winner === null ? u("games.tagteam.draw") : e.result.winner === d ? u("games.tagteam.youWin") : u("games.tagteam.youLose")), /* @__PURE__ */ c(a, {
		adaptive: !0,
		className: "tagteam-screen",
		banner: /* @__PURE__ */ c("div", {
			className: "tagteam-banner",
			children: /* @__PURE__ */ c(o, {
				tone: p,
				text: m,
				chip: h,
				accent: S.accent
			})
		}),
		children: e.phase === "draft" && e.draft ? /* @__PURE__ */ c(Ne, {
			pub: e,
			priv: t,
			side: d,
			send: s
		}) : e.phase === "order" && e.teams ? /* @__PURE__ */ c(Pe, {
			pub: e,
			priv: t,
			side: d,
			send: s
		}) : e.teams ? /* @__PURE__ */ l("div", {
			className: "tagteam-battle",
			children: [
				/* @__PURE__ */ c(J, {
					team: e.teams[1 - d],
					side: 1 - d,
					name: f(e.players[1 - d])
				}),
				/* @__PURE__ */ c(Me, {
					pub: e,
					mySide: d
				}),
				/* @__PURE__ */ c(J, {
					team: e.teams[d],
					side: d,
					name: f(e.players[d]),
					mine: !0
				}),
				/* @__PURE__ */ l("div", {
					className: "tagteam-controls",
					children: [e.phase === "build" && !t.myBuildPick && t.drawn && /* @__PURE__ */ c(Fe, {
						pub: e,
						priv: t,
						side: d,
						send: s
					}), e.pendingFey === d && t.feyOptions && /* @__PURE__ */ c(Ie, {
						pub: e,
						side: d,
						options: t.feyOptions,
						send: s
					})]
				})
			]
		}) : null
	});
}
function je({ f: e, side: t, idx: n, active: a }) {
	let o = i(), s = b.get(e.id), { ref: u } = r(`fighter:${t}:${n}`), d = e.feyHp ? e.spirits === 4 : e.id === "maman" ? e.hp === 0 || e.hp === -1 : e.hp <= 0;
	return /* @__PURE__ */ l("div", {
		ref: u,
		className: `tagteam-fighter ${a ? "ring-2" : ""} ${d ? "opacity-50" : ""}`,
		style: {
			borderColor: s.color,
			"--tw-ring-color": a ? s.color : void 0
		},
		children: [
			/* @__PURE__ */ l("div", {
				className: "tagteam-fighter-identity",
				children: [
					/* @__PURE__ */ c("span", {
						"aria-hidden": !0,
						className: "tagteam-fighter-symbol",
						children: e.bear ? "🐻" : s.emoji
					}),
					/* @__PURE__ */ c("span", {
						className: "tagteam-fighter-name",
						children: o(s.nameKey)
					}),
					/* @__PURE__ */ l("span", {
						className: "tagteam-fighter-markers",
						children: [
							e.sheriff && /* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								children: "⭐"
							}),
							e.golemToken && /* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								children: "🗿"
							}),
							e.concentration && /* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								children: "🎯"
							}),
							d && /* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								children: "💀"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ l("div", {
				className: "tagteam-fighter-stats font-mono tabular-nums",
				children: [/* @__PURE__ */ l("span", {
					className: "font-black text-violet-600",
					children: ["⬢", e.power]
				}), /* @__PURE__ */ l("span", {
					className: `font-black ${d ? "text-rose-600" : "text-rose-500"}`,
					children: ["❤", Math.max(0, e.hp)]
				})]
			}),
			/* @__PURE__ */ l("div", {
				className: "tagteam-fighter-tokens",
				children: [
					e.rage !== null && /* @__PURE__ */ l("span", {
						className: "rounded bg-amber-100 px-1 py-0.5 font-bold text-amber-800",
						children: [
							"🐾",
							e.rage,
							"/6"
						]
					}),
					e.ship !== null && /* @__PURE__ */ l("span", {
						className: "rounded bg-teal-100 px-1 py-0.5 font-bold text-teal-800",
						children: [
							"🚢",
							e.ship,
							"/20"
						]
					}),
					e.voice !== null && /* @__PURE__ */ l("span", {
						className: "rounded bg-amber-100 px-1 py-0.5 font-bold text-amber-800",
						children: ["😇", e.voice]
					}),
					e.serpent !== null && /* @__PURE__ */ c("span", {
						className: "rounded bg-red-100 px-1 py-0.5 font-bold text-red-800",
						children: e.serpent === "black" ? "🐍" : "🤍"
					}),
					e.spirits !== null && /* @__PURE__ */ l("span", {
						className: "rounded bg-lime-100 px-1 py-0.5 font-bold text-lime-800",
						children: [
							"🧚",
							e.spirits,
							"/4",
							e.feyHp?.map((t, n) => /* @__PURE__ */ l("span", {
								className: n === e.feyActive ? "underline" : t <= 0 ? "line-through opacity-50" : "",
								children: [" ", t]
							}, n))
						]
					}),
					e.aflame > 0 && /* @__PURE__ */ l("span", {
						className: "rounded bg-red-100 px-1 py-0.5 font-bold text-red-700",
						children: ["🔥", e.aflame]
					})
				]
			})
		]
	});
}
function J({ team: e, side: t, name: n, mine: a }) {
	let o = i(), { ref: s } = r(`deck:${t}`), u = e.revealed[e.revealed.length - 1], d = u ? _.get(u.card)?.fighter : null;
	return /* @__PURE__ */ l("div", {
		className: `frame tagteam-team ${a ? "tagteam-team--mine" : "tagteam-team--opponent"}`,
		children: [/* @__PURE__ */ l("div", {
			className: "tagteam-team-heading",
			children: [/* @__PURE__ */ l("span", {
				className: "tagteam-team-name",
				title: n,
				children: [n, a ? ` ${o("lobby.you")}` : ""]
			}), /* @__PURE__ */ l("div", {
				ref: s,
				className: "tagteam-team-deck font-mono tabular-nums",
				children: [
					/* @__PURE__ */ l("span", { children: ["🂠", e.deckCount] }),
					/* @__PURE__ */ l("span", { children: ["📦", e.buildCount] }),
					e.schemesPlanted !== null && /* @__PURE__ */ l("span", { children: ["🎭", e.schemesPlanted] })
				]
			})]
		}), /* @__PURE__ */ c("div", {
			className: "tagteam-team-fighters",
			children: e.fighters.map((e, n) => /* @__PURE__ */ c(je, {
				f: e,
				side: t,
				idx: n,
				active: d === e.id
			}, e.id))
		})]
	});
}
function Me({ pub: e, mySide: t }) {
	let n = i(), { ref: a } = r("stage");
	return e.teams ? /* @__PURE__ */ c("div", {
		ref: a,
		className: "tagteam-stage",
		children: [0, 1].map((r) => {
			let i = e.teams[r].revealed, a = i[i.length - 1];
			return /* @__PURE__ */ l("div", {
				className: "tagteam-revealed-column",
				"data-mine": r === t,
				children: [
					a ? /* @__PURE__ */ c(Y, {
						card: a.card,
						flip: a.flip,
						big: !0
					}) : /* @__PURE__ */ c("div", {
						className: "tagteam-card tagteam-empty-card",
						"aria-hidden": !0,
						children: "🂠"
					}),
					/* @__PURE__ */ c("div", {
						className: "tagteam-history",
						children: i.slice(0, -1).map((e, t) => /* @__PURE__ */ c(Y, {
							card: e.card,
							flip: e.flip,
							removed: e.removed
						}, t))
					}),
					/* @__PURE__ */ c("span", {
						className: "tagteam-removed text-rose-600",
						children: a?.removed ? n("games.tagteam.cardRemoved") : "\xA0"
					})
				]
			}, r);
		})
	}) : null;
}
function Y({ card: e, flip: t, big: n, removed: r }) {
	let a = i(), o = _.get(t ? `fey.${t}` : e);
	if (!o) return null;
	let s = b.get(o.fighter);
	return /* @__PURE__ */ l("div", {
		className: `tagteam-card ${n ? "tagteam-card--big" : "tagteam-card--history"} ${r ? "opacity-40" : ""}`,
		style: { borderColor: s.color },
		children: [
			/* @__PURE__ */ l("div", {
				className: "tagteam-card-heading",
				children: [/* @__PURE__ */ c("span", {
					"aria-hidden": !0,
					children: s.emoji
				}), /* @__PURE__ */ c("span", { children: a(o.nameKey) })]
			}),
			n && /* @__PURE__ */ c("span", {
				className: "tagteam-card-symbol",
				"aria-hidden": !0,
				children: s.emoji
			}),
			n && o.textKey && /* @__PURE__ */ c("p", {
				className: "tagteam-card-effect text-ink/80",
				children: a(o.textKey)
			})
		]
	});
}
function Ne({ pub: e, priv: t, side: r, send: a }) {
	let o = i(), s = e.draft, [u, d] = n([]), [f, p] = n(null), m = s.submitted[r], h = s.mode === "competitive" && s.step === 0, g = s.mode === "free" ? 2 : 1, _ = u.length === g && (!h || f !== null), v = t.hand ?? [], y = (e) => {
		if (!m) {
			if (h && u.length >= g && !u.includes(e)) {
				p(f === e ? null : e);
				return;
			}
			d((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length >= g ? t : [...t, e]);
		}
	};
	return /* @__PURE__ */ l("div", {
		className: "tagteam-prepare tagteam-draft",
		children: [
			/* @__PURE__ */ c("div", {
				className: "tagteam-draft-grid",
				children: v.map((e) => {
					let t = b.get(e), n = u.includes(e), r = f === e;
					return /* @__PURE__ */ l("button", {
						type: "button",
						disabled: m,
						"aria-pressed": n || r,
						onClick: () => y(e),
						className: `tagteam-choice tagteam-draft-choice ${r ? "opacity-60" : ""}`,
						style: n ? {
							borderColor: S.accent,
							boxShadow: `3px 3px 0 ${S.accent}`
						} : r ? { borderColor: "#e11d48" } : void 0,
						children: [
							/* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								className: "tagteam-choice-symbol",
								children: t.emoji
							}),
							/* @__PURE__ */ c("span", {
								className: "tagteam-choice-name",
								children: o(t.nameKey)
							}),
							n && /* @__PURE__ */ c("span", {
								className: "tagteam-choice-check",
								"aria-hidden": !0,
								children: "✓"
							}),
							r && /* @__PURE__ */ c("span", {
								className: "tagteam-ban text-rose-600",
								children: o("games.tagteam.banTag")
							})
						]
					}, e);
				})
			}),
			h && !m && /* @__PURE__ */ c("p", {
				className: "tagteam-prepare-note text-ink/70",
				children: o("games.tagteam.banHint")
			}),
			s.picks[0].length + s.picks[1].length > 0 && /* @__PURE__ */ c("div", {
				className: "tagteam-draft-picks",
				children: [0, 1].map((e) => s.picks[e].map((t) => /* @__PURE__ */ c("span", {
					className: "rounded bg-sky-100 px-1.5 py-0.5 font-bold text-sky-800",
					children: o(b.get(t).nameKey)
				}, `${e}:${t}`)))
			}),
			!m && /* @__PURE__ */ c("button", {
				type: "button",
				disabled: !_,
				onClick: () => {
					s.mode === "free" ? a({
						type: "freePick",
						fighters: [u[0], u[1]]
					}) : a({
						type: "draftPick",
						fighter: u[0],
						ban: h ? f ?? void 0 : void 0
					});
				},
				className: "btn-base tagteam-confirm",
				style: { background: S.accent },
				children: o("games.tagteam.confirm")
			}),
			m && t.myDraftPick && /* @__PURE__ */ c("p", {
				className: "tagteam-prepare-note text-center font-bold",
				children: o("games.tagteam.youPicked", { name: o(b.get(t.myDraftPick).nameKey) })
			})
		]
	});
}
function Pe({ pub: e, priv: t, side: r, send: a }) {
	let o = i(), u = e.teams[r], d = u.fighters.findIndex((e) => e.id === "fey"), [f, p] = n(0), [m, h] = n(2);
	return t.myOrderReady ? null : /* @__PURE__ */ l("div", {
		className: "tagteam-prepare tagteam-order",
		children: [
			/* @__PURE__ */ c("p", {
				className: "section-label",
				children: o("games.tagteam.orderFirst")
			}),
			/* @__PURE__ */ c("div", {
				className: "tagteam-order-grid",
				children: u.fighters.map((e, t) => {
					let n = b.get(e.id), r = f === t;
					return /* @__PURE__ */ l("button", {
						type: "button",
						onClick: () => p(t),
						"aria-pressed": r,
						className: "tagteam-choice tagteam-order-choice",
						style: r ? {
							borderColor: S.accent,
							boxShadow: `3px 3px 0 ${S.accent}`
						} : void 0,
						children: [
							/* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								className: "tagteam-choice-symbol",
								children: n.emoji
							}),
							/* @__PURE__ */ c("span", {
								className: "tagteam-choice-name",
								children: o(n.nameKey)
							}),
							r && /* @__PURE__ */ c("span", {
								className: "tagteam-choice-check",
								"aria-hidden": !0,
								children: "✓"
							})
						]
					}, e.id);
				})
			}),
			d >= 0 && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("p", {
				className: "section-label",
				children: o("games.tagteam.feyStart")
			}), /* @__PURE__ */ c("div", {
				className: "tagteam-fey-grid",
				children: x.map((e, t) => /* @__PURE__ */ l("button", {
					type: "button",
					onClick: () => h(t),
					"aria-pressed": m === t,
					className: "tagteam-choice tagteam-fey-choice",
					style: m === t ? {
						borderColor: S.accent,
						boxShadow: `3px 3px 0 ${S.accent}`
					} : void 0,
					children: [
						o(e.nameKey),
						/* @__PURE__ */ l("span", {
							className: "tagteam-fey-hp font-mono",
							children: ["❤", e.hp]
						}),
						m === t && /* @__PURE__ */ c("span", {
							className: "tagteam-choice-check",
							"aria-hidden": !0,
							children: "✓"
						})
					]
				}, t))
			})] }),
			/* @__PURE__ */ c("button", {
				type: "button",
				onClick: () => a({
					type: "order",
					first: f,
					feyChar: d >= 0 ? m : void 0
				}),
				className: "btn-base tagteam-confirm",
				style: { background: S.accent },
				children: o("games.tagteam.confirm")
			})
		]
	});
}
function Fe({ pub: e, priv: t, side: r, send: a }) {
	let o = i(), [s, u] = n(null), [d, f] = n(0), p = t.drawn ?? [], m = e.teams[r].deckCount;
	return /* @__PURE__ */ l("div", {
		className: "frame tagteam-build",
		children: [
			/* @__PURE__ */ c("p", {
				className: "section-label",
				children: o("games.tagteam.buildPick")
			}),
			/* @__PURE__ */ c("div", {
				className: "tagteam-build-grid",
				children: p.map((e) => {
					let t = _.get(e), n = s === e;
					return /* @__PURE__ */ l("button", {
						type: "button",
						onClick: () => u(e),
						"aria-pressed": n,
						className: "tagteam-choice tagteam-build-choice",
						style: n ? {
							borderColor: S.accent,
							boxShadow: `3px 3px 0 ${S.accent}`
						} : void 0,
						children: [
							/* @__PURE__ */ c("span", {
								className: "tagteam-choice-name",
								children: o(t.nameKey)
							}),
							t.instantBonus && /* @__PURE__ */ c("span", {
								"aria-hidden": !0,
								className: "block",
								children: "⚠️"
							}),
							n && /* @__PURE__ */ c("span", {
								className: "tagteam-choice-check",
								"aria-hidden": !0,
								children: "✓"
							})
						]
					}, e);
				})
			}),
			s && /* @__PURE__ */ l("div", {
				className: "tagteam-build-footer",
				children: [/* @__PURE__ */ l("div", {
					className: "tagteam-build-placement",
					children: [/* @__PURE__ */ c("p", {
						className: "section-label",
						children: o("games.tagteam.buildPos")
					}), /* @__PURE__ */ l("div", {
						className: "tagteam-build-position",
						children: [/* @__PURE__ */ c("input", {
							type: "range",
							min: 0,
							max: m,
							value: d,
							onChange: (e) => f(Number(e.target.value)),
							className: "tagteam-position-range",
							"aria-label": o("games.tagteam.buildPos")
						}), /* @__PURE__ */ c("span", {
							className: "tagteam-position-number font-mono font-bold tabular-nums",
							children: o("games.tagteam.buildPosN", { n: d + 1 })
						})]
					})]
				}), /* @__PURE__ */ c("button", {
					type: "button",
					onClick: () => a({
						type: "buildPick",
						card: s,
						pos: d
					}),
					className: "btn-base tagteam-confirm",
					style: { background: S.accent },
					children: o("games.tagteam.confirm")
				})]
			})
		]
	});
}
function Ie({ pub: e, side: t, options: n, send: r }) {
	let a = i(), o = e.teams[t].fighters.find((e) => e.id === "fey");
	return /* @__PURE__ */ l("div", {
		className: "frame tagteam-fey-picker",
		children: [/* @__PURE__ */ c("p", {
			className: "section-label",
			children: a("games.tagteam.feyChoose")
		}), /* @__PURE__ */ c("div", {
			className: "tagteam-fey-grid",
			children: n.map((e) => /* @__PURE__ */ l("button", {
				type: "button",
				onClick: () => r({
					type: "feyNext",
					char: e
				}),
				className: "tagteam-choice tagteam-fey-choice",
				children: [a(x[e].nameKey), /* @__PURE__ */ l("span", {
					className: "tagteam-fey-hp font-mono",
					children: ["❤", o.feyHp[e]]
				})]
			}, e))
		})]
	});
}
//#endregion
//#region src/games/tagteam/bot.ts
function X() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
var Z = {
	golem: 9,
	maman: 8,
	bodvar: 8,
	fey: 7,
	milady: 7,
	ching: 7,
	wong: 6,
	jeanne: 6,
	mephisto: 6,
	mordred: 5,
	wildbunch: 5,
	shango: 5
};
function Q(e) {
	let t = _.get(e);
	if (!t) return 0;
	let n = 0, r = (e) => {
		for (let t of e) t.k === "attack" || t.k === "block" ? n += 3 : t.k === "cancel" ? n += 4 : t.k === "heal" ? n += 2 : t.k === "power" ? n += 1.5 : t.k === "reanimate" || t.k === "removeOppCardThenSelf" || t.k === "dragToHell" || t.k === "execution" ? n += 4 : t.k === "unleashScheme" || t.k === "plantScheme" ? n += 1.5 : t.k === "summonFlip" ? n += 2 : n += 1, "success" in t && t.success && r(t.success);
	};
	return r(t.effects), t.instantBonus && (n += 1), n;
}
var Le = (e) => !!_.get(e)?.effects.some((e) => e.k === "block"), Re = (e) => !!_.get(e)?.effects.some((e) => e.k === "attack"), ze = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = t.difficulty === "weak", a = n.players.indexOf(t.rid);
	if (a < 0) return null;
	if (n.phase === "draft" && n.draft) {
		let e = n.draft;
		if (e.submitted[a]) return null;
		let t = r.hand ?? [];
		if (t.length === 0) return null;
		if (e.mode === "free") {
			let e = i ? [...t].sort(() => X() - .5) : [...t].sort((e, t) => Z[t] - Z[e]);
			return { action: {
				type: "freePick",
				fighters: [e[0], e[1]]
			} };
		}
		let o = i ? t[Math.floor(X() * t.length)] : t.reduce((e, t) => Z[t] > Z[e] ? t : e), s;
		if (e.mode === "competitive" && e.step === 0) {
			let e = t.filter((e) => e !== o);
			s = i ? e[Math.floor(X() * e.length)] : e.reduce((e, t) => Z[t] > Z[e] ? t : e);
		}
		return { action: {
			type: "draftPick",
			fighter: o,
			ban: s
		} };
	}
	if (n.phase === "order") {
		if (r.myOrderReady || !n.teams) return null;
		let e = n.teams[a], t = e.fighters.findIndex((e) => e.id === "fey"), o = 0;
		i ? o = X() < .5 ? 0 : 1 : b.get(e.fighters[1].id).basePower > b.get(e.fighters[0].id).basePower && (o = 1);
		let s;
		return t >= 0 && (s = i ? Math.floor(X() * 3) : 2), { action: {
			type: "order",
			first: o,
			feyChar: s
		} };
	}
	if (n.phase === "fight") {
		if (n.pendingFey !== a || !r.feyOptions) return null;
		let e = n.teams[a].fighters.find((e) => e.id === "fey");
		return { action: {
			type: "feyNext",
			char: i ? r.feyOptions[Math.floor(X() * r.feyOptions.length)] : r.feyOptions.reduce((t, n) => e.feyHp[n] > e.feyHp[t] ? n : t)
		} };
	}
	if (n.phase === "build") {
		if (r.myBuildPick || !r.drawn) return null;
		let e = r.drawn, t = i ? e[Math.floor(X() * e.length)] : e.reduce((e, t) => Q(t) > Q(e) ? t : e), o = 0;
		if (!i && Le(t) && n.teams) {
			let e = n.teams[1 - a].revealed.findIndex((e) => Re(e.card));
			o = e >= 0 ? Math.min(e, r.myDeck.length) : 0;
		} else !i && Q(t) < 4 && (o = r.myDeck.length);
		return { action: {
			type: "buildPick",
			card: t,
			pos: o
		} };
	}
	return null;
}, Be = (e, t, n) => {
	switch (e.type) {
		case "draftPick": {
			let t = n(b.get(e.fighter).nameKey);
			return e.ban ? n("games.tagteam.hintDraftBan", {
				name: t,
				ban: n(b.get(e.ban).nameKey)
			}) : n("games.tagteam.hintDraftPick", { name: t });
		}
		case "freePick": return n("games.tagteam.hintFreePick", {
			a: n(b.get(e.fighters[0]).nameKey),
			b: n(b.get(e.fighters[1]).nameKey)
		});
		case "order": return e.feyChar === void 0 ? n("games.tagteam.hintOrder", { n: e.first + 1 }) : n("games.tagteam.hintOrderFey", {
			n: e.first + 1,
			fey: n(x[e.feyChar].nameKey)
		});
		case "feyNext": return n("games.tagteam.hintFeyNext", { name: n(x[e.char].nameKey) });
		case "buildPick": {
			let t = _.get(e.card);
			return t ? n("games.tagteam.hintBuildPick", {
				card: n(t.nameKey),
				n: e.pos + 1
			}) : "";
		}
		default: return "";
	}
}, Ve = (e, t) => typeof t == "number" ? e.anchor(`fighter:${t >> 1}:${t & 1}`) : null;
function $(e, t, n, r = 900) {
	let i = Ve(e, t);
	if (!i) return null;
	let a = Math.max(1, Math.min(i.w / 160, i.h / 90));
	return {
		ms: r,
		node: /* @__PURE__ */ c(u, {
			at: i,
			ms: r - 100,
			children: /* @__PURE__ */ c("span", {
				className: "inline-block",
				style: {
					transform: `scale(${a})`,
					transformOrigin: "50% 100%"
				},
				children: n
			})
		})
	};
}
var He = {
	reveal(e, t) {
		let n = e.data, r = typeof n?.side == "number" ? n.side : 0, i = t.anchor(`deck:${r}`);
		return i ? {
			ms: 500,
			node: /* @__PURE__ */ c(d, {
				at: i,
				ms: 500
			})
		} : null;
	},
	attack(e, t) {
		let n = e.data;
		return $(t, n?.target, /* @__PURE__ */ l("span", {
			className: "text-lg font-black text-rose-600",
			children: [
				"-",
				typeof n?.power == "number" ? n.power : "",
				"⚔️"
			]
		}));
	},
	blocked(e, t) {
		let n = e.data;
		return $(t, n?.target, /* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			className: "text-lg",
			children: "🛡️"
		}));
	},
	dd(e, t) {
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ l("span", {
			className: "font-black text-rose-600",
			children: [
				"-",
				typeof n?.n == "number" ? n.n : "",
				"◆"
			]
		}));
	},
	hp(e, t) {
		let n = e.data;
		return typeof n?.to != "number" || typeof n?.from != "number" || n.to <= n.from ? null : $(t, n?.ref, /* @__PURE__ */ l("span", {
			className: "font-black text-emerald-600",
			children: [
				"+",
				n.to - n.from,
				"❤️"
			]
		}));
	},
	power(e, t) {
		let n = e.data, r = typeof n?.n == "number" ? n.n : 1;
		return $(t, n?.ref, /* @__PURE__ */ l("span", {
			className: "font-black text-violet-600",
			children: [r > 0 ? `+${r}` : r, "⬢"]
		}));
	},
	transfer(e, t) {
		let n = e.data;
		return $(t, n?.to, /* @__PURE__ */ l("span", {
			className: "font-black text-violet-600",
			children: [
				"+",
				typeof n?.n == "number" ? n.n : "",
				"⬢"
			]
		}));
	},
	transform(e, t) {
		navigator.vibrate?.(120);
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			className: "text-2xl",
			children: "🐻"
		}), 1200);
	},
	poison(e, t) {
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ l("span", {
			className: "font-black text-emerald-700",
			children: [
				"-",
				typeof n?.n == "number" ? n.n : "",
				"☠️"
			]
		}));
	},
	scheme(e, t) {
		let n = e.data, r = typeof n?.side == "number" ? n.side : 0, i = t.anchor("stage") ?? t.anchor(`deck:${r}`);
		return i ? {
			ms: 900,
			node: /* @__PURE__ */ c(u, {
				at: i,
				ms: 800,
				children: /* @__PURE__ */ c("span", {
					"aria-hidden": !0,
					className: "text-xl",
					children: "🎭"
				})
			})
		} : null;
	},
	serpentFlip(e, t) {
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			children: n?.face === "black" ? "🐍" : "🤍"
		}));
	},
	golemSave(e, t) {
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			className: "text-lg",
			children: "🗿"
		}));
	},
	aflame(e, t) {
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			className: "text-lg",
			children: "🔥"
		}));
	},
	revive(e, t) {
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			className: "text-2xl",
			children: "🕯️"
		}), 1100);
	},
	feySpirit(e, t) {
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			className: "text-lg",
			children: "✨"
		}));
	},
	execution(e, t) {
		let n = e.data;
		return $(t, n?.ref, /* @__PURE__ */ c("span", {
			"aria-hidden": !0,
			className: "text-xl",
			children: "⚰️"
		}), 1e3);
	},
	cancel(e, t) {
		let n = e.data, r = typeof n?.side == "number" ? n.side : 0, i = t.anchor(`deck:${r}`);
		return i ? {
			ms: 700,
			node: /* @__PURE__ */ c(u, {
				at: i,
				ms: 650,
				children: /* @__PURE__ */ c("span", {
					"aria-hidden": !0,
					children: "🚫"
				})
			})
		} : null;
	},
	instantBonus(e, t) {
		let n = e.data, r = typeof n?.side == "number" ? n.side : 0, i = t.anchor(`deck:${r}`);
		return i ? {
			ms: 800,
			node: /* @__PURE__ */ c(u, {
				at: i,
				ms: 750,
				children: /* @__PURE__ */ c("span", {
					"aria-hidden": !0,
					children: "⚠️"
				})
			})
		} : null;
	},
	gameOver(e, t) {
		navigator.vibrate?.(150);
		let n = e.data, r = typeof n?.winner == "number" ? n.winner : null, i = r === null ? t.anchor("stage") : t.anchor(`deck:${r}`);
		return i ? {
			ms: 1500,
			node: /* @__PURE__ */ c(u, {
				at: i,
				ms: 1400,
				children: /* @__PURE__ */ c("span", {
					"aria-hidden": !0,
					className: "text-3xl",
					children: r === null ? "🤝" : "🏆"
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/tagteam/game-over.tsx
function Ue(e) {
	return /* @__PURE__ */ c("div", {
		className: "tagteam-over",
		children: /* @__PURE__ */ c(f, {
			...e,
			accent: S.accent
		})
	});
}
//#endregion
//#region src/games/tagteam/options.tsx
var We = [
	{
		id: "free",
		labelKey: "games.tagteam.optFree"
	},
	{
		id: "standard",
		labelKey: "games.tagteam.optStandard"
	},
	{
		id: "competitive",
		labelKey: "games.tagteam.optCompetitive"
	}
];
function Ge({ value: e, onChange: t }) {
	let n = i(), r = T.safeParse(e), a = r.success ? r.data : T.parse(void 0);
	return /* @__PURE__ */ l("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ c(m, {
			title: n("games.tagteam.optDraftMode"),
			columns: 3,
			children: We.map((e) => /* @__PURE__ */ c(p, {
				name: "tagteam-draft-mode",
				value: e.id,
				checked: a.draftMode === e.id,
				label: n(e.labelKey),
				accent: S.accent,
				onChange: () => t({ draftMode: e.id })
			}, e.id))
		}), /* @__PURE__ */ c("p", {
			className: "text-xs text-ink/70",
			children: n("games.tagteam.optDraftModeHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tagteam/entry.tsx
var Ke = {
	definition: Oe,
	View: ke,
	bot: ze,
	describe: Be,
	fx: He,
	OverView: Ue,
	Options: Ge,
	locales: {
		zh: {
			name: "双侠小队",
			desc: "双人自动战斗:挑两名斗士组队,编排出牌顺序,看他们逐回合交手",
			rules: "目标:把对方任一斗士的血量打到 0(KO);焚化(凑齐 5 个火焰标记)等特殊败因见各斗士机制。\n准备:\n· 组队:自由选 2 名斗士,或轮抽;两名斗士的起始卡(★)组成初始战斗牌库。\n· 决定谁先出战;其余卡进入构筑牌库。\n流程(每轮两阶段):\n· 战斗!:双方战斗牌库同时逐张翻开并同时结算,直到翻完。\n· 攻击让对手失血,数值为回合开始时的战力;治疗与失血净额结算。\n· 格挡抵销对方全部攻击,挡下至少一次还有奖励。\n· 血标经过图标格触发奖励,紫色手掌格(Stop)会拦住血标。\n· 构筑!:从构筑牌库抽 3 张,秘密选 1 张插入战斗牌库任意位置,其余放回库底。\n· 插入不改变已有顺序;带 ⚠ 的卡加入时立即生效并公告,不透露是哪张。\n细节:\n· 当回合的战力变化不影响当回合攻击;多源攻击合并为一次总伤害。\n· 双 KO 平局;构筑牌库抽干也平局。\n12 名斗士各有独门机制:怒气变身、船轨、精灵、圣音、阴谋、火焰标记……慢慢挖掘组合!",
			optDraftMode: "组队方式",
			optFree: "自由选",
			optStandard: "标准轮抽",
			optCompetitive: "竞技轮抽",
			optDraftModeHint: "自由选:直接挑 2 名斗士;标准轮抽:各发 6 名,交替挑选;竞技轮抽:第一轮先暗扣 1 名再传给对手。",
			draftStep: "轮抽 · 第 {{n}} 步",
			waitOpp: "等 {{name}} 决定…",
			pickTwo: "选 2 名斗士组队",
			pickOne: "选 1 名斗士",
			pickAndBan: "选 1 名斗士,并暗扣 1 名弃掉",
			banTag: "暗扣",
			banHint: "选好斗士后,再点一名将其暗扣(对方拿不到)",
			youPicked: "你选了 {{name}}",
			orderPrompt: "决定谁先出战",
			orderFirst: "哪名斗士先出战?",
			feyStart: "选妖精的首发角色",
			roundChip: "第 {{n}} 轮",
			fighting: "战斗中 · 第 {{n}} 回合",
			feyChoose: "选下一个登场的妖精角色",
			buildPrompt: "构筑:选 1 张插入战斗牌库",
			buildPick: "抽到的 3 张:选 1 张",
			buildPos: "插入位置(1 = 最先打出)",
			buildPosN: "第 {{n}} 位",
			cardRemoved: "已移出游戏",
			confirm: "确定",
			youWin: "你赢了!",
			youLose: "你输了",
			draw: "平局",
			errDone: "本局已结束",
			errNotPlayer: "你不在本局中",
			errBadAction: "现在不能这么做",
			errSubmitted: "已经提交过了",
			errBadPick: "无效的选择",
			fighters: {
				bodvar: "博德瓦尔",
				bodvar_title: "怒熊战士",
				ching: "郑一嫂",
				ching_title: "红旗帮主",
				fey: "妖精一族",
				fey_title: "三相之灵",
				golem: "魔像",
				golem_title: "黏土守卫",
				jeanne: "圣女贞德",
				jeanne_title: "圣音聆听者",
				maman: "布里吉特妈妈",
				maman_title: "巫毒女王",
				mephisto: "墨菲斯托",
				mephisto_title: "地狱公爵",
				milady: "米莱狄",
				milady_title: "阴谋家",
				mordred: "莫德雷德",
				mordred_title: "叛逆骑士",
				shango: "尚戈",
				shango_title: "雷霆之神",
				wildbunch: "荒野帮",
				wildbunch_title: "法外狂徒",
				wong: "黄飞鸿",
				wong_title: "功夫宗师"
			},
			feyChars: {
				c0: "小仙灵",
				c1: "林中仙",
				c2: "白发仙"
			},
			schemes: {
				unleashPower: "连环计",
				poison: "毒药",
				bothPower1: "共进",
				unleashAttack: "暗杀令",
				ddAll: "无差别打击",
				selfPower2: "蓄势",
				healPartner6: "秘药",
				partnerPower2: "授艺",
				attackBoth: "双面伏击"
			},
			cards: {
				bodvar_enrage: "激怒",
				bodvar_enrage_text: "人类形态:+1 怒气;熊形态:攻击对手。",
				bodvar_spirit_trance: "灵魂恍惚",
				bodvar_spirit_trance_text: "+2 战力;若本回合被攻击,额外受 2 直伤。",
				bodvar_rune_transformation: "变身符文",
				bodvar_rune_transformation_text: "格挡;成功:+1 怒气。",
				bodvar_rune_strength: "力量符文",
				bodvar_rune_strength_text: "格挡;成功:+1 战力。",
				bodvar_blood_ties: "血脉相连",
				bodvar_blood_ties_text: "人类形态:搭档回 2 血;熊形态:攻击对手。",
				bodvar_berserk: "狂怒!",
				bodvar_berserk_text: "人类形态:攻击对手;熊形态:攻击双方对手。",
				ching_terror: "海域女霸",
				ching_terror_text: "船 0-7:攻击;船 8-15:回 2 血;船 20:双方对手血量打到 1 并免疫本回合其他血量变化,船归 0。然后 +1 船。",
				ching_secret_harbour: "秘密港湾",
				ching_secret_harbour_text: "格挡;成功:+3 船。",
				ching_spirited_defense: "激昂防御",
				ching_spirited_defense_text: "格挡;成功:+1 战力。",
				ching_revenge: "红旗帮的复仇",
				ching_revenge_text: "攻击对手;船 8-15 时搭档也攻击。",
				ching_raiding_party: "劫掠小队",
				ching_raiding_party_text: "船 0-7:搭档 +1 战力。",
				ching_outmaneuvered: "棋差一着",
				ching_outmaneuvered_text: "攻击对手;+1 船。",
				ching_join_fleet: "加入舰队!",
				ching_join_fleet_text: "+2 船。",
				ching_gunpowder_wine: "火药酒",
				ching_gunpowder_wine_text: "自己回 3 血;船 8-15 时搭档也回 3 血。",
				fey_almp: "众灵终将逝去",
				fey_almp_text: "若四格精灵已满,打出此卡时立即败北。",
				fey_summon_greenman: "召唤:绿人",
				fey_summon_greenman_text: "格挡;成功:本卡永久变为「绿人」。",
				fey_spirit_storm: "精灵风暴",
				fey_spirit_storm_text: "攻击对手,每有 1 个精灵,本次攻击伤害 +1。",
				fey_summon_redcap: "召唤:红帽子",
				fey_summon_redcap_text: "格挡;成功:本卡永久变为「红帽子」。",
				fey_summon_leshi: "召唤:莱西",
				fey_summon_leshi_text: "格挡;成功:本卡永久变为「莱西」。",
				fey_fairy_ring: "仙环",
				fey_fairy_ring_text: "搭档回血,每个精灵 2 点。",
				fey_entanglement: "缠绕",
				fey_entanglement_text: "取消对手本回合的卡。",
				fey_greenman: "绿人",
				fey_greenman_text: "你和搭档各回 3 血。",
				fey_redcap: "红帽子",
				fey_redcap_text: "你和搭档各攻击一次。",
				fey_leshi: "莱西",
				fey_leshi_text: "你和搭档各 +1 战力。",
				golem_pti: "保护无辜者",
				golem_pti_text: "若搭档已有傀儡标记:攻击对手;否则:把傀儡标记交给搭档,自己受 3 直伤。",
				golem_self_sacrifice: "自我牺牲",
				golem_self_sacrifice_text: "转移 1 战力给搭档。",
				golem_fist_of_clay: "黏土之拳",
				golem_fist_of_clay_text: "攻击对手。",
				golem_reanimation: "复生",
				golem_reanimation_text: "你的下一张卡发动两次。",
				golem_heal_wounded: "治愈伤者",
				golem_heal_wounded_text: "搭档回 1 血。⚠加入牌库时:魔像回 3 血。",
				milady_dressed_to_kill: "盛装赴死",
				milady_dressed_to_kill_text: "布置 1 个阴谋。",
				milady_stab_smile: "笑里藏刀",
				milady_stab_smile_text: "攻击对手;若本回合被攻击,触发 1 个阴谋。",
				milady_so_predictable: "早料到了",
				milady_so_predictable_text: "格挡;成功:触发 1 个阴谋。",
				milady_wdky: "杀不死我的让我更强",
				milady_wdky_text: "攻击对手;若被格挡,+1 战力。",
				milady_licking_wounds: "舔舐伤口",
				milady_licking_wounds_text: "回 2 血;然后若你满血,布置 1 个阴谋。",
				milady_friends_close: "亲近朋友……",
				milady_friends_close_text: "搭档回血,数值=你的战力。",
				milady_checkmate: "将军",
				milady_checkmate_text: "触发 1 个阴谋。",
				maman_cpr: "辣椒朗姆酒",
				maman_cpr_text: "自己受 1 直伤;攻击对手。",
				maman_you_are_mine: "你是我的",
				maman_you_are_mine_text: "格挡;成功:本回合所有打向你队的攻击改打对手的搭档。",
				maman_sacrifice_love: "爱之牺牲",
				maman_sacrifice_love_text: "搭档受 1 直伤,你回 4 血。",
				maman_soul_embrace: "灵魂相拥",
				maman_soul_embrace_text: "搭档受 1 直伤,你 +1 战力。",
				maman_black_rooster: "黑公鸡",
				maman_black_rooster_text: "取消对手本回合的卡。",
				maman_eternal_youth: "永葆青春",
				maman_eternal_youth_text: "取消对方本回合全部治疗,你改为回复等量血量;若确实回复了血量,则 +2 战力。",
				jeanne_dieu_premier: "上帝优先",
				jeanne_dieu_premier_text: "+1 圣音。",
				jeanne_hand_righteous: "义者之手",
				jeanne_hand_righteous_text: "攻击对手;+1 圣音。",
				jeanne_holy_shield: "圣盾",
				jeanne_holy_shield_text: "格挡;成功:+1 圣音。",
				jeanne_divine_vision: "神圣幻象",
				jeanne_divine_vision_text: "你和搭档各回 2 血。",
				jeanne_sword_michael: "圣米迦勒之剑",
				jeanne_sword_michael_text: "攻击对手;成功:回血,数值=你的战力。",
				mephisto_twin_serpents: "双蛇",
				mephisto_twin_serpents_text: "黑蛇:攻击对手;白蛇:+1 战力;然后翻转蛇标记。",
				mephisto_fury_damned: "诅咒之怒",
				mephisto_fury_damned_text: "若对手本回合打出其起始卡:对其 4 直伤。",
				mephisto_drag_hell: "拖你下地狱",
				mephisto_drag_hell_text: "若本回合你队将以任何原因落败,改为你立刻获胜。",
				mephisto_soul_siphon: "灵魂虹吸",
				mephisto_soul_siphon_text: "格挡;成功:回血,数值=攻击你的对手的战力。",
				mephisto_serpent_pit: "深渊之蛇",
				mephisto_serpent_pit_text: "黑蛇:攻击对手;白蛇:自己受 1 直伤。",
				mephisto_serpent_void: "虚空之蛇",
				mephisto_serpent_void_text: "白蛇:回 3 血;黑蛇:回 1 血。",
				mordred_dark_power: "黑暗之力",
				mordred_dark_power_text: "若战力 ≥8:攻击对手;+1 战力。",
				mordred_vicious_riposte: "恶毒反击",
				mordred_vicious_riposte_text: "格挡;成功:攻击对手。",
				mordred_hidden_dagger: "暗匕",
				mordred_hidden_dagger_text: "若对方两人都未攻击:攻击对手。",
				mordred_execution: "处决",
				mordred_execution_text: "对手卡结算后,若其血量 ≤4:对其造成等于其剩余血量的直伤。",
				mordred_cloak_shadow: "暗影斗篷",
				mordred_cloak_shadow_text: "格挡;成功:回 3 血。",
				shango_aflame: "点燃!",
				shango_aflame_text: "点燃对方出战斗士;若其本无火焰,收回其搭档板上全部火焰。",
				shango_wall_flame: "烈焰之墙",
				shango_wall_flame_text: "格挡;成功:你和搭档各 +1 战力。",
				shango_cauterize: "灼烧止血",
				shango_cauterize_text: "搭档回 3 血。",
				shango_lightning_strike: "雷击",
				shango_lightning_strike_text: "以火焰之力攻击所有其他斗士。",
				shango_thunder_stone: "雷霆石",
				shango_thunder_stone_text: "搭档转移 1 战力给你。",
				shango_breath_fire: "火焰吐息",
				shango_breath_fire_text: "以火焰之力攻击对手;成功:点燃目标。",
				wildbunch_corrupted_lawman: "堕落警长",
				wildbunch_corrupted_lawman_text: "若警徽在你队:把警徽交给对方并攻击对手;若在对手队:对手 +1 战力,你收回警徽并 +1 战力。",
				wildbunch_keys_armory: "军火库钥匙",
				wildbunch_keys_armory_text: "持警徽者 +2 战力;然后把警徽交给对手。",
				wildbunch_aint_here_talk: "不是来聊天的",
				wildbunch_aint_here_talk_text: "攻击对方的搭档。",
				wildbunch_gatling: "警长的私藏加特林",
				wildbunch_gatling_text: "若警徽在你队:攻击双方对手;成功:自己受 1 直伤。",
				wildbunch_outlaw_doc: "法外医生",
				wildbunch_outlaw_doc_text: "搭档回 3 血。⚠加入牌库时:荒野帮回 1 血。",
				wildbunch_bribe: "贿赂",
				wildbunch_bribe_text: "格挡;成功:拿走警徽。",
				wildbunch_back_hideout: "回藏身处",
				wildbunch_back_hideout_text: "你和搭档各回 1 血。⚠加入牌库时:荒野帮回 1 血。",
				wong_thf: "……摔得越重",
				wong_thf_text: "在对手身上放专注标记;若其已有:以它的战力攻击它,然后收回标记。",
				wong_tiger_fist: "虎拳",
				wong_tiger_fist_text: "攻击对手;成功:转移 1 战力给搭档。",
				wong_ging_bridge: "劲桥",
				wong_ging_bridge_text: "转移 2 战力给搭档。",
				wong_ging_balance: "劲衡",
				wong_ging_balance_text: "格挡;成功:己方战力变为与搭档相同。",
				wong_crippling_touch: "致残点穴",
				wong_crippling_touch_text: "对手卡结算后将其移出游戏;然后本卡也移出游戏。",
				wong_chi_focus: "聚气",
				wong_chi_focus_text: "+1 战力;搭档回 2 血。"
			},
			hintDraftPick: "挑{{name}}",
			hintDraftBan: "挑{{name}},暗扣{{ban}}",
			hintFreePick: "选{{a}}和{{b}}组队",
			hintOrder: "第 {{n}} 名斗士先出战",
			hintOrderFey: "第 {{n}} 名斗士先出战,妖精首发{{fey}}",
			hintFeyNext: "派{{name}}登场",
			hintBuildPick: "把{{card}}插到第 {{n}} 位"
		},
		en: {
			name: "Tag Team",
			desc: "Two-player auto-battler: draft a duo, stack your deck, and watch them trade blows",
			rules: "Goal: drop either enemy fighter to 0 HP (KO); special losses like Incineration (5 Flame tokens) are per-fighter mechanics.\nSetup:\n· Team building: free pick of 2 fighters, or a draft; the two starter cards (★) form your Fight Deck.\n· Decide who leads; all other cards form your Build Deck.\nEach round has two phases:\n· FIGHT!: both Fight Decks reveal one card at a time, resolved simultaneously, until empty.\n· Attacks make the opponent lose HP equal to your power at the start of the turn; healing and damage are netted.\n· Block negates all enemy attacks and grants a bonus if it stops at least one.\n· Markers landing on or passing icon spaces trigger them, and Stop spaces halt the marker.\n· BUILD!: draw 3 cards from your Build Deck, secretly pick 1 and insert it anywhere in your Fight Deck; the others go to the bottom.\n· Insertion does not reorder the rest; cards marked ⚠ announce and resolve immediately when added, without revealing which card.\nDetails:\n· Power changes mid-turn do not affect that turn; multiple attacks merge into one total.\n· Double KO is a draw; running out of Build Deck is also a draw.\nAll 12 fighters pack unique tricks: rage bear form, the ship track, spirits, divine voice, schemes, flames… find your combo!",
			optDraftMode: "Team building",
			optFree: "Free pick",
			optStandard: "Draft",
			optCompetitive: "Rival draft",
			optDraftModeHint: "Free: pick any 2 fighters. Draft: 6 each, alternate picks. Rival: also secretly ban 1 on the first step.",
			draftStep: "Draft · step {{n}}",
			waitOpp: "Waiting for {{name}}…",
			pickTwo: "Pick 2 fighters",
			pickOne: "Pick 1 fighter",
			pickAndBan: "Pick 1 fighter and secretly ban 1",
			banTag: "Banned",
			banHint: "After picking, tap one more to ban it (opponent cannot get it)",
			youPicked: "You picked {{name}}",
			orderPrompt: "Choose your opening fighter",
			orderFirst: "Which fighter leads?",
			feyStart: "Choose the Fey starting character",
			roundChip: "Round {{n}}",
			fighting: "Fighting · turn {{n}}",
			feyChoose: "Choose the next Fey character",
			buildPrompt: "BUILD!: insert 1 card into your Fight Deck",
			buildPick: "Drawn 3: pick 1",
			buildPos: "Insert position (1 = played first)",
			buildPosN: "Slot {{n}}",
			cardRemoved: "Removed from the game",
			confirm: "OK",
			youWin: "You win!",
			youLose: "You lose",
			draw: "Draw",
			errDone: "This game is over",
			errNotPlayer: "You are not in this game",
			errBadAction: "Not allowed right now",
			errSubmitted: "Already submitted",
			errBadPick: "Invalid pick",
			fighters: {
				bodvar: "Bödvar",
				bodvar_title: "Raging Bear",
				ching: "Ching Shih",
				ching_title: "Pirate Queen",
				fey: "The Fey Folk",
				fey_title: "Three-in-One",
				golem: "The Golem",
				golem_title: "Clay Guardian",
				jeanne: "Jeanne d'Arc",
				jeanne_title: "Voice of the Divine",
				maman: "Maman Brijit",
				maman_title: "Voodoo Queen",
				mephisto: "Mephisto",
				mephisto_title: "Lord of Hell",
				milady: "Milady",
				milady_title: "Schemer",
				mordred: "Mordred",
				mordred_title: "Traitor Knight",
				shango: "Shango",
				shango_title: "God of Thunder",
				wildbunch: "The Wild Bunch",
				wildbunch_title: "Outlaws",
				wong: "Wong Fei-Hung",
				wong_title: "Kung Fu Master"
			},
			feyChars: {
				c0: "Sprite",
				c1: "Sylvan",
				c2: "White-haired"
			},
			schemes: {
				unleashPower: "Chain Scheme",
				poison: "Poison",
				bothPower1: "Rising Together",
				unleashAttack: "Kill Order",
				ddAll: "Indiscriminate",
				selfPower2: "Buildup",
				healPartner6: "Secret Remedy",
				partnerPower2: "Mentorship",
				attackBoth: "Ambush"
			},
			cards: {
				bodvar_enrage: "Enrage",
				bodvar_enrage_text: "Human: +1 Rage. Bear: attack.",
				bodvar_spirit_trance: "Spirit Trance",
				bodvar_spirit_trance_text: "+2 Power; if attacked this turn, take 2 direct damage.",
				bodvar_rune_transformation: "Rune of Transformation",
				bodvar_rune_transformation_text: "Block; on success: +1 Rage.",
				bodvar_rune_strength: "Rune of Strength",
				bodvar_rune_strength_text: "Block; on success: +1 Power.",
				bodvar_blood_ties: "Blood Ties",
				bodvar_blood_ties_text: "Human: partner heals 2. Bear: attack.",
				bodvar_berserk: "Berserk!",
				bodvar_berserk_text: "Human: attack. Bear: attack both opponents.",
				ching_terror: "Terror of the Seas",
				ching_terror_text: "Ship 0-7: attack. 8-15: heal 2. 20: both opponents drop to 1 HP and ignore other HP changes this turn, ship resets to 0. Then +1 Ship.",
				ching_secret_harbour: "Secret Harbour",
				ching_secret_harbour_text: "Block; on success: +3 Ship.",
				ching_spirited_defense: "Spirited Defense",
				ching_spirited_defense_text: "Block; on success: +1 Power.",
				ching_revenge: "Revenge of the Red Flag Fleet",
				ching_revenge_text: "Attack; at Ship 8-15 your partner attacks too.",
				ching_raiding_party: "Raiding Party",
				ching_raiding_party_text: "Ship 0-7: partner +1 Power.",
				ching_outmaneuvered: "Outmaneuvered",
				ching_outmaneuvered_text: "Attack; +1 Ship.",
				ching_join_fleet: "Join the Fleet!",
				ching_join_fleet_text: "+2 Ship.",
				ching_gunpowder_wine: "Gunpowder Wine",
				ching_gunpowder_wine_text: "Heal 3; at Ship 8-15 your partner heals 3 too.",
				fey_almp: "All Legends Must Pass",
				fey_almp_text: "If all four spirit slots are filled, playing this card loses you the game.",
				fey_summon_greenman: "Summoning: The Green Man",
				fey_summon_greenman_text: "Block; on success: this card permanently becomes The Green Man.",
				fey_spirit_storm: "Spirit Storm",
				fey_spirit_storm_text: "Attack. This attack deals +1 damage per spirit.",
				fey_summon_redcap: "Summoning: Redcap",
				fey_summon_redcap_text: "Block; on success: this card permanently becomes Redcap.",
				fey_summon_leshi: "Summoning: Leshi",
				fey_summon_leshi_text: "Block; on success: this card permanently becomes Leshi.",
				fey_fairy_ring: "Fairy Ring",
				fey_fairy_ring_text: "Partner heals 2 per spirit.",
				fey_entanglement: "Entanglement",
				fey_entanglement_text: "Cancel the opponent's card this turn.",
				fey_greenman: "The Green Man",
				fey_greenman_text: "You and your partner each heal 3.",
				fey_redcap: "Redcap",
				fey_redcap_text: "You and your partner each attack.",
				fey_leshi: "Leshi",
				fey_leshi_text: "You and your partner each +1 Power.",
				golem_pti: "Protect the Innocent",
				golem_pti_text: "If your partner holds the Golem token: attack. Otherwise: give the token to your partner and take 3 direct damage.",
				golem_self_sacrifice: "Self Sacrifice",
				golem_self_sacrifice_text: "Transfer 1 Power to your partner.",
				golem_fist_of_clay: "Fist of Clay",
				golem_fist_of_clay_text: "Attack.",
				golem_reanimation: "Reanimation",
				golem_reanimation_text: "Your next card resolves twice.",
				golem_heal_wounded: "Heal the Wounded",
				golem_heal_wounded_text: "Partner heals 1. ⚠ When added: the Golem heals 3.",
				milady_dressed_to_kill: "Dressed to Kill",
				milady_dressed_to_kill_text: "Plant 1 Scheme.",
				milady_stab_smile: "With a Stab and a Smile",
				milady_stab_smile_text: "Attack; if attacked this turn, unleash 1 Scheme.",
				milady_so_predictable: "So Predictable",
				milady_so_predictable_text: "Block; on success: unleash 1 Scheme.",
				milady_wdky: "What Doesn't Kill You Makes Me Stronger",
				milady_wdky_text: "Attack; if blocked, +1 Power.",
				milady_licking_wounds: "Licking My Wounds",
				milady_licking_wounds_text: "Heal 2; then, if you are at full HP, plant 1 Scheme.",
				milady_friends_close: "I Keep My Friends Close…",
				milady_friends_close_text: "Partner heals HP equal to your Power.",
				milady_checkmate: "Checkmate",
				milady_checkmate_text: "Unleash 1 Scheme.",
				maman_cpr: "Chili Pepper Rum",
				maman_cpr_text: "Take 1 direct damage; attack.",
				maman_you_are_mine: "You Are Mine",
				maman_you_are_mine_text: "Block; on success: this turn, all attacks on your team hit the attackers' partner instead.",
				maman_sacrifice_love: "Sacrifice of Love",
				maman_sacrifice_love_text: "Partner takes 1 direct damage; you heal 4.",
				maman_soul_embrace: "Soul Embrace",
				maman_soul_embrace_text: "Partner takes 1 direct damage; you +1 Power.",
				maman_black_rooster: "The Black Rooster",
				maman_black_rooster_text: "Cancel the opponent's card this turn.",
				maman_eternal_youth: "Eternal Youth",
				maman_eternal_youth_text: "Cancel all enemy healing this turn and heal that much yourself; if you actually heal, +2 Power.",
				jeanne_dieu_premier: "Dieu Premier Servi",
				jeanne_dieu_premier_text: "+1 Divine Voice.",
				jeanne_hand_righteous: "Hand of the Righteous",
				jeanne_hand_righteous_text: "Attack; +1 Divine Voice.",
				jeanne_holy_shield: "Holy Shield",
				jeanne_holy_shield_text: "Block; on success: +1 Divine Voice.",
				jeanne_divine_vision: "Divine Vision",
				jeanne_divine_vision_text: "You and your partner each heal 2.",
				jeanne_sword_michael: "Sword of St. Michael",
				jeanne_sword_michael_text: "Attack; on success: heal HP equal to your Power.",
				mephisto_twin_serpents: "Twin Serpents",
				mephisto_twin_serpents_text: "Black serpent: attack. White serpent: +1 Power. Then flip the serpent token.",
				mephisto_fury_damned: "Fury of the Damned",
				mephisto_fury_damned_text: "If the opponent plays their starter card: 4 direct damage to them.",
				mephisto_drag_hell: "Drag You to Hell",
				mephisto_drag_hell_text: "If your team would lose this turn for any reason, you win instead.",
				mephisto_soul_siphon: "Soul Siphon",
				mephisto_soul_siphon_text: "Block; on success: heal HP equal to the Power of the fighter that attacked you.",
				mephisto_serpent_pit: "Serpent of the Pit",
				mephisto_serpent_pit_text: "Black serpent: attack. White serpent: take 1 direct damage.",
				mephisto_serpent_void: "Serpent of the Void",
				mephisto_serpent_void_text: "White serpent: heal 3. Black serpent: heal 1.",
				mordred_dark_power: "Dark Power",
				mordred_dark_power_text: "If your Power is 8 or more: attack. +1 Power.",
				mordred_vicious_riposte: "Vicious Riposte",
				mordred_vicious_riposte_text: "Block; on success: attack.",
				mordred_hidden_dagger: "Hidden Dagger",
				mordred_hidden_dagger_text: "If neither enemy attacked: attack.",
				mordred_execution: "Execution",
				mordred_execution_text: "After the opponent card resolves, if they have 4 HP or less: deal direct damage equal to their remaining HP.",
				mordred_cloak_shadow: "Cloak of Shadow",
				mordred_cloak_shadow_text: "Block; on success: heal 3.",
				shango_aflame: "Aflame!",
				shango_aflame_text: "Set the enemy's active fighter Aflame; if they had none, pull all Flame tokens from their partner's board.",
				shango_wall_flame: "Wall of Flame",
				shango_wall_flame_text: "Block; on success: you and your partner each +1 Power.",
				shango_cauterize: "Cauterize",
				shango_cauterize_text: "Partner heals 3.",
				shango_lightning_strike: "Lightning Strike",
				shango_lightning_strike_text: "Attack all other fighters using Flamepower.",
				shango_thunder_stone: "Thunder Stone",
				shango_thunder_stone_text: "Partner transfers 1 Power to you.",
				shango_breath_fire: "Breath of Fire",
				shango_breath_fire_text: "Attack using Flamepower; on success: set the target Aflame.",
				wildbunch_corrupted_lawman: "Corrupted Lawman",
				wildbunch_corrupted_lawman_text: "If your team holds the badge: give it to the opponents and attack. If they hold it: the opponent gets +1 Power; you take the badge back and get +1 Power.",
				wildbunch_keys_armory: "Keys to the Armory",
				wildbunch_keys_armory_text: "The badge holder +2 Power; then give the badge to the opponent.",
				wildbunch_aint_here_talk: "We Ain't Here to Talk",
				wildbunch_aint_here_talk_text: "Attack the opponent's partner.",
				wildbunch_gatling: "Sheriff's Personal Gatling Gun",
				wildbunch_gatling_text: "If your team holds the badge: attack both opponents; on success: take 1 direct damage.",
				wildbunch_outlaw_doc: "Outlaw Doc",
				wildbunch_outlaw_doc_text: "Partner heals 3. ⚠ When added: The Wild Bunch heals 1.",
				wildbunch_bribe: "Bribe",
				wildbunch_bribe_text: "Block; on success: take the badge.",
				wildbunch_back_hideout: "Back to the Hideout",
				wildbunch_back_hideout_text: "You and your partner each heal 1. ⚠ When added: The Wild Bunch heals 1.",
				wong_thf: "…The Harder They Fall",
				wong_thf_text: "Place a Focus token on the opponent; if they already have one: attack them with their own Power, then take the token back.",
				wong_tiger_fist: "Tiger Fist",
				wong_tiger_fist_text: "Attack; on success: transfer 1 Power to your partner.",
				wong_ging_bridge: "Ging Bridge",
				wong_ging_bridge_text: "Transfer 2 Power to your partner.",
				wong_ging_balance: "Ging Balance",
				wong_ging_balance_text: "Block; on success: your Power becomes equal to your partner's.",
				wong_crippling_touch: "Crippling Touch",
				wong_crippling_touch_text: "After the opponent's card resolves, remove it from the game; then remove this card too.",
				wong_chi_focus: "Chi Focus",
				wong_chi_focus_text: "+1 Power; partner heals 2."
			},
			hintDraftPick: "Pick {{name}}",
			hintDraftBan: "Pick {{name}}, secretly ban {{ban}}",
			hintFreePick: "Team {{a}} with {{b}}",
			hintOrder: "Fighter {{n}} leads",
			hintOrderFey: "Fighter {{n}} leads; Fey starts as {{fey}}",
			hintFeyNext: "Send in {{name}}",
			hintBuildPick: "Insert {{card}} at slot {{n}}"
		}
	}
};
//#endregion
export { Ke as default };
