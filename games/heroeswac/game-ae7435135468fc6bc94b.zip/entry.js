import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useCallback as r, useEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { IconBack as h, IconBot as g, IconExpand as _, IconLog as v } from "@bgparty/sdk/icons";
import { seatName as y } from "@bgparty/sdk/ui/player-strip";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region src/games/heroeswac/data.ts
var x = [
	"gnomes",
	"humans",
	"elves",
	"undead",
	"nagas",
	"orcs"
], S = [
	"wood",
	"iron",
	"gold",
	"move",
	"build"
], C = [
	14,
	22,
	30
], w = [
	2,
	2,
	3
], T = [
	12,
	18,
	24
], E = [
	2,
	2,
	3
], D = [
	"totem",
	"bowl",
	"mask",
	"crystal",
	"book",
	"grail"
], ee = {
	totem: {
		id: "totem",
		vp: 4,
		region: "paskaar",
		cond: {
			kind: "pay",
			res: "wood",
			amount: 12
		},
		elfWood: 5
	},
	bowl: {
		id: "bowl",
		vp: 4,
		region: "vurt",
		cond: {
			kind: "pay",
			res: "iron",
			amount: 12
		},
		elfWood: 4
	},
	mask: {
		id: "mask",
		vp: 4,
		region: "dortal",
		cond: {
			kind: "pay",
			res: "gold",
			amount: 12
		},
		elfWood: 6
	},
	crystal: {
		id: "crystal",
		vp: 5,
		region: "folen",
		cond: {
			kind: "foundations",
			amount: 4
		},
		elfWood: 2
	},
	book: {
		id: "book",
		vp: 5,
		region: "odmoor",
		cond: {
			kind: "victories",
			amount: 5
		},
		elfWood: 3
	},
	grail: {
		id: "grail",
		vp: 3,
		region: "togeed",
		cond: {
			kind: "mountains",
			amount: 4
		},
		elfWood: 2
	}
}, O = [
	{
		id: "asander",
		terrain: "forest",
		res: {
			wood: 1,
			iron: 1
		},
		any: 0,
		foundations: 3,
		removedAt: []
	},
	{
		id: "brynnlore",
		terrain: "mountain",
		res: {},
		any: 0,
		fortress: {
			pow: 14,
			vp: 4,
			res: {},
			any: 4
		},
		removedAt: []
	},
	{
		id: "cerness",
		terrain: "lake",
		res: {
			wood: 1,
			iron: 1
		},
		any: 0,
		portal: !0,
		removedAt: [2, 3]
	},
	{
		id: "dortal",
		terrain: "forest",
		res: { iron: 2 },
		any: 0,
		artifact: "mask",
		removedAt: []
	},
	{
		id: "esmore",
		terrain: "plain",
		res: { wood: 2 },
		any: 0,
		foundations: 3,
		removedAt: []
	},
	{
		id: "folen",
		terrain: "forest",
		res: {
			wood: 1,
			gold: 1
		},
		any: 0,
		artifact: "crystal",
		removedAt: []
	},
	{
		id: "glennfore",
		terrain: "mountain",
		res: {},
		any: 0,
		fortress: {
			pow: 10,
			vp: 3,
			res: {},
			any: 3
		},
		removedAt: [2, 3]
	},
	{
		id: "harrax",
		terrain: "mountain",
		res: {
			wood: 1,
			gold: 1
		},
		any: 0,
		portal: !0,
		removedAt: []
	},
	{
		id: "ikara",
		terrain: "mountain",
		res: {},
		any: 0,
		fortress: {
			pow: 7,
			vp: 2,
			res: { gold: 4 },
			any: 0
		},
		removedAt: [2]
	},
	{
		id: "jorveld",
		terrain: "mountain",
		res: { gold: 2 },
		any: 0,
		foundations: 3,
		removedAt: []
	},
	{
		id: "kosleen",
		terrain: "forest",
		res: {},
		any: 0,
		fortress: {
			pow: 21,
			vp: 5,
			res: {
				wood: 4,
				iron: 4
			},
			any: 0
		},
		removedAt: []
	},
	{
		id: "lox",
		terrain: "mountain",
		res: { iron: 2 },
		any: 0,
		foundations: 3,
		removedAt: []
	},
	{
		id: "morreed",
		terrain: "forest",
		res: {},
		any: 2,
		portal: !0,
		removedAt: [2]
	},
	{
		id: "nikleen",
		terrain: "plain",
		res: { wood: 2 },
		any: 0,
		foundations: 3,
		removedAt: []
	},
	{
		id: "odmoor",
		terrain: "forest",
		res: {
			iron: 1,
			gold: 1
		},
		any: 0,
		artifact: "book",
		removedAt: []
	},
	{
		id: "paskaar",
		terrain: "plain",
		res: { gold: 2 },
		any: 0,
		artifact: "totem",
		removedAt: []
	},
	{
		id: "qliss",
		terrain: "lake",
		res: {},
		any: 0,
		fortress: {
			pow: 6,
			vp: 2,
			res: {},
			any: 3
		},
		removedAt: []
	},
	{
		id: "rolgoy",
		terrain: "mountain",
		res: {},
		any: 0,
		fortress: {
			pow: 11,
			vp: 3,
			res: {
				wood: 3,
				iron: 3
			},
			any: 0
		},
		removedAt: []
	},
	{
		id: "suleen",
		terrain: "forest",
		res: {
			wood: 1,
			gold: 1
		},
		any: 0,
		foundations: 3,
		removedAt: []
	},
	{
		id: "togeed",
		terrain: "mountain",
		res: {
			wood: 1,
			iron: 1
		},
		any: 0,
		artifact: "grail",
		removedAt: []
	},
	{
		id: "ugmat",
		terrain: "lake",
		res: { iron: 2 },
		any: 0,
		foundations: 3,
		removedAt: []
	},
	{
		id: "vurt",
		terrain: "mountain",
		res: { wood: 2 },
		any: 0,
		artifact: "bowl",
		removedAt: []
	},
	{
		id: "wirs",
		terrain: "forest",
		res: {},
		any: 0,
		fortress: {
			pow: 19,
			vp: 5,
			res: { gold: 4 },
			any: 0
		},
		removedAt: []
	},
	{
		id: "xee",
		terrain: "forest",
		res: { gold: 2 },
		any: 0,
		foundations: 3,
		removedAt: []
	},
	{
		id: "yreel",
		terrain: "plain",
		res: {
			iron: 1,
			gold: 1
		},
		any: 0,
		portal: !0,
		removedAt: []
	},
	{
		id: "zasker",
		terrain: "plain",
		res: {
			iron: 1,
			gold: 1
		},
		any: 0,
		foundations: 3,
		removedAt: [2]
	},
	{
		id: "zoro",
		terrain: "plain",
		res: {},
		any: 0,
		fortress: {
			pow: 17,
			vp: 4,
			res: {},
			any: 7
		},
		removedAt: [2, 3]
	}
], k = Object.fromEntries(O.map((e) => [e.id, e])), A = {
	asander: [
		"brynnlore",
		"cerness",
		"dortal"
	],
	brynnlore: [
		"asander",
		"cerness",
		"dortal",
		"esmore"
	],
	cerness: [
		"asander",
		"brynnlore",
		"esmore",
		"folen",
		"glennfore"
	],
	dortal: [
		"asander",
		"brynnlore",
		"esmore",
		"harrax",
		"ikara"
	],
	esmore: [
		"brynnlore",
		"cerness",
		"dortal",
		"folen",
		"harrax",
		"jorveld",
		"kosleen"
	],
	folen: [
		"cerness",
		"esmore",
		"glennfore",
		"kosleen",
		"lox"
	],
	glennfore: [
		"cerness",
		"folen",
		"lox"
	],
	harrax: [
		"dortal",
		"esmore",
		"ikara",
		"jorveld"
	],
	ikara: [
		"dortal",
		"harrax",
		"morreed",
		"nikleen",
		"odmoor"
	],
	jorveld: [
		"esmore",
		"harrax",
		"kosleen",
		"odmoor",
		"paskaar"
	],
	kosleen: [
		"esmore",
		"folen",
		"jorveld",
		"lox",
		"paskaar"
	],
	lox: [
		"folen",
		"glennfore",
		"kosleen",
		"paskaar",
		"qliss"
	],
	morreed: [
		"ikara",
		"nikleen",
		"rolgoy",
		"ugmat",
		"vurt"
	],
	nikleen: [
		"ikara",
		"morreed",
		"odmoor",
		"rolgoy",
		"vurt"
	],
	odmoor: [
		"ikara",
		"jorveld",
		"nikleen",
		"paskaar",
		"rolgoy"
	],
	paskaar: [
		"jorveld",
		"kosleen",
		"lox",
		"odmoor",
		"qliss",
		"rolgoy",
		"suleen"
	],
	qliss: [
		"lox",
		"paskaar",
		"suleen",
		"togeed"
	],
	rolgoy: [
		"morreed",
		"nikleen",
		"odmoor",
		"paskaar",
		"suleen",
		"vurt",
		"yreel"
	],
	suleen: [
		"paskaar",
		"qliss",
		"rolgoy",
		"togeed",
		"yreel"
	],
	togeed: [
		"qliss",
		"suleen",
		"yreel",
		"zasker"
	],
	ugmat: [
		"morreed",
		"vurt",
		"wirs"
	],
	vurt: [
		"morreed",
		"nikleen",
		"rolgoy",
		"ugmat",
		"wirs",
		"xee",
		"yreel"
	],
	wirs: [
		"ugmat",
		"vurt",
		"xee"
	],
	xee: [
		"vurt",
		"wirs",
		"yreel",
		"zoro"
	],
	yreel: [
		"rolgoy",
		"suleen",
		"togeed",
		"vurt",
		"xee",
		"zasker",
		"zoro"
	],
	zasker: [
		"togeed",
		"yreel",
		"zoro"
	],
	zoro: [
		"xee",
		"yreel",
		"zasker"
	]
};
function j(e) {
	let t = {};
	for (let n of O) e.has(n.id) || (t[n.id] = A[n.id].filter((t) => !e.has(t)));
	let n = O.filter((t) => t.portal && !e.has(t.id)).map((e) => e.id);
	for (let e of n) {
		let r = new Set(t[e]);
		for (let t of n) t !== e && r.add(t);
		t[e] = [...r];
	}
	return t;
}
var M = [
	{
		pow: 2,
		vp: 1,
		res: {},
		any: 0
	},
	{
		pow: 3,
		vp: 1,
		res: {},
		any: 2
	},
	{
		pow: 5,
		vp: 1,
		res: {
			wood: 1,
			iron: 1,
			gold: 1
		},
		any: 0
	},
	{
		pow: 8,
		vp: 2,
		res: {
			wood: 2,
			iron: 2,
			gold: 2
		},
		any: 0
	},
	{
		pow: 13,
		vp: 3,
		res: {},
		any: 5
	},
	{
		pow: 19,
		vp: 4,
		res: {
			wood: 2,
			iron: 2,
			gold: 2
		},
		any: 0
	},
	{
		pow: 25,
		vp: 5,
		res: {
			wood: 3,
			iron: 3,
			gold: 3
		},
		any: 0
	},
	{
		pow: 32,
		vp: 7,
		res: {
			wood: 4,
			iron: 4,
			gold: 4
		},
		any: 0
	}
], N = [
	{
		pow: 3,
		vp: 1,
		res: {},
		any: 2
	},
	{
		pow: 3,
		vp: 1,
		res: {
			wood: 1,
			iron: 1,
			gold: 1
		},
		any: 0
	},
	{
		pow: 3,
		vp: 1,
		res: {
			wood: 1,
			iron: 1,
			gold: 1
		},
		any: 0
	},
	{
		pow: 8,
		vp: 2,
		res: {
			wood: 2,
			iron: 2,
			gold: 2
		},
		any: 0
	},
	{
		pow: 14,
		vp: 3,
		res: {
			wood: 2,
			iron: 2,
			gold: 2
		},
		any: 0
	},
	{
		pow: 20,
		vp: 4,
		res: {
			wood: 3,
			iron: 3,
			gold: 3
		},
		any: 0
	},
	{
		pow: 24,
		vp: 5,
		res: {
			wood: 3,
			iron: 3,
			gold: 3
		},
		any: 0
	},
	{
		pow: 33,
		vp: 7,
		res: {
			wood: 4,
			iron: 4,
			gold: 4
		},
		any: 0
	}
], P = [
	"games.heroeswac.monster.m0",
	"games.heroeswac.monster.m1",
	"games.heroeswac.monster.m2",
	"games.heroeswac.monster.m3",
	"games.heroeswac.monster.m4",
	"games.heroeswac.monster.m5",
	"games.heroeswac.monster.m6",
	"games.heroeswac.monster.m7"
], F = (e, t, n, r, i = {}) => ({
	id: e,
	nameKey: `games.heroeswac.unit.${e}`,
	pow: t,
	cost: n,
	start: r,
	...i
}), I = (e, t, n, r, i = []) => ({
	id: e,
	nameKey: `games.heroeswac.building.${e}`,
	descKey: `games.heroeswac.bld.${e}`,
	level: t,
	vp: n,
	cost: r,
	req: i
}), L = {
	gnomes: {
		id: "gnomes",
		nameKey: "games.heroeswac.faction.gnomes",
		descKey: "games.heroeswac.factionDesc.gnomes",
		color: "#78716c",
		terrainCost: {
			plain: 1,
			forest: 2,
			mountain: 2,
			lake: 3
		},
		monsterLine: M,
		units: [
			F("mechanic", 0, 2, 0, { recruitedBy: "academy" }),
			F("anisopter", 2, 3, 2, {
				recruitedBy: "workhouse",
				altPow: 3
			}),
			F("automaton", 4, 4, 0, {
				recruitedBy: "plant",
				altPow: 6
			}),
			F("mechasaur", 5, 6, 0, { recruitedBy: "factory" })
		],
		buildings: [
			I("generator", 1, 0, {
				iron: 3,
				gold: 2
			}),
			I("academy", 1, 0, {
				wood: 2,
				iron: 2
			}),
			I("assemblers", 2, 1, { iron: 5 }),
			I("library", 2, 0, {
				wood: 3,
				iron: 2
			}),
			I("workhouse", 2, 1, {
				iron: 3,
				gold: 2
			}),
			I("lab", 3, 3, {
				iron: 4,
				gold: 2
			}, ["assemblers"]),
			I("pipeline", 3, 1, {
				wood: 2,
				iron: 5
			}, ["library"]),
			I("plant", 3, 2, { iron: 5 }, ["workhouse"]),
			I("bank", 4, 3, {
				wood: 2,
				iron: 5,
				gold: 2
			}, ["pipeline"]),
			I("factory", 4, 5, {
				wood: 2,
				iron: 5,
				gold: 2
			}, ["pipeline", "plant"])
		]
	},
	humans: {
		id: "humans",
		nameKey: "games.heroeswac.faction.humans",
		descKey: "games.heroeswac.factionDesc.humans",
		color: "#db2777",
		terrainCost: {
			plain: 1,
			forest: 2,
			mountain: 3,
			lake: 2
		},
		monsterLine: M,
		units: [
			F("soldier", 2, 2, 2, {
				recruitedBy: "warguild",
				altPow: 3
			}),
			F("cuirassier", 3, 3, 0, {
				recruitedBy: "barracks",
				altPow: 4
			}),
			F("archmage", 5, 5, 0, {
				recruitedBy: "mageguild",
				altPow: 7
			})
		],
		buildings: [
			I("townhall", 1, 0, {
				wood: 2,
				iron: 2,
				gold: 2
			}),
			I("warguild", 1, 0, { iron: 4 }),
			I("market", 2, 0, { iron: 4 }),
			I("illtower", 2, 1, { iron: 3 }),
			I("trackers", 3, 1, {
				wood: 3,
				iron: 2
			}, ["market"]),
			I("tavern", 3, 2, {
				wood: 3,
				iron: 4
			}, ["illtower"]),
			I("barracks", 3, 3, { iron: 4 }, ["illtower", "warguild"]),
			I("armoury", 4, 2, {
				wood: 3,
				iron: 3,
				gold: 5
			}, ["trackers"]),
			I("cathedral", 4, 3, { iron: 5 }, ["tavern"]),
			I("mageguild", 4, 4, {
				wood: 3,
				iron: 5,
				gold: 3
			}, ["barracks"])
		]
	},
	elves: {
		id: "elves",
		nameKey: "games.heroeswac.faction.elves",
		descKey: "games.heroeswac.factionDesc.elves",
		color: "#9333ea",
		terrainCost: {
			plain: 1,
			forest: 2,
			mountain: 3,
			lake: 2
		},
		monsterLine: M,
		units: [
			F("pixie", 1, 1, 3, {
				recruitedBy: "brushwood",
				altPow: 2
			}),
			F("griffin", 3, 3, 0, {
				recruitedBy: "nests",
				altPow: 5
			}),
			F("ent", 6, 5, 0, {
				recruitedBy: "greattree",
				altPow: 10
			})
		],
		buildings: [
			I("horn", 1, 0, {
				iron: 3,
				gold: 1
			}),
			I("brushwood", 1, 0, {
				wood: 2,
				iron: 2
			}),
			I("armorshop", 2, 1, { iron: 4 }, ["horn"]),
			I("nests", 2, 1, {
				wood: 3,
				iron: 3
			}, ["brushwood"]),
			I("woodedcliff", 3, 2, { iron: 6 }, ["horn"]),
			I("observatory", 3, 2, {
				wood: 3,
				iron: 2
			}, ["armorshop"]),
			I("watch", 3, 2, {
				wood: 2,
				iron: 2,
				gold: 2
			}, ["nests"]),
			I("guidforest", 4, 1, {
				iron: 4,
				gold: 2
			}, ["woodedcliff"]),
			I("druidhouse", 4, 3, {
				wood: 2,
				iron: 5,
				gold: 2
			}, ["observatory"]),
			I("greattree", 4, 4, {
				wood: 3,
				iron: 5,
				gold: 3
			}, ["watch", "druidhouse"])
		]
	},
	undead: {
		id: "undead",
		nameKey: "games.heroeswac.faction.undead",
		descKey: "games.heroeswac.factionDesc.undead",
		color: "#2563eb",
		terrainCost: {
			plain: 2,
			forest: 2,
			mountain: 2,
			lake: 2
		},
		monsterLine: M,
		units: [
			F("skeleton", 1, 1, 4, {
				recruitedBy: "graveyard",
				altPow: 2
			}),
			F("executioner", 0, 2, 0, { recruitedBy: "ruins" }),
			F("lich", 5, 5, 0, { recruitedBy: "ossuary" })
		],
		buildings: [
			I("barrow", 1, 0, { iron: 4 }),
			I("hearse", 1, 1, {
				wood: 2,
				iron: 2,
				gold: 2
			}),
			I("graveyard", 1, 0, {
				wood: 3,
				gold: 1
			}),
			I("tomb", 2, 2, { iron: 5 }, ["barrow"]),
			I("shrine", 2, 1, { iron: 4 }, [
				"barrow",
				"hearse",
				"graveyard"
			]),
			I("ruins", 2, 1, {
				wood: 4,
				iron: 4
			}, ["graveyard"]),
			I("chapel", 3, 2, {
				iron: 5,
				gold: 4
			}, ["shrine"]),
			I("plague", 3, 2, { iron: 5 }, ["ruins"]),
			I("temple", 4, 4, { wood: 5 }, ["chapel"]),
			I("ossuary", 4, 3, {
				wood: 4,
				iron: 6
			}, ["plague"])
		]
	},
	nagas: {
		id: "nagas",
		nameKey: "games.heroeswac.faction.nagas",
		descKey: "games.heroeswac.factionDesc.nagas",
		color: "#0d9488",
		terrainCost: {
			plain: 1,
			forest: 2,
			mountain: 3,
			lake: 1
		},
		monsterLine: N,
		units: [F("serpent", 1, 0, 2)],
		buildings: [
			I("lighthouse", 1, 3, { serpents: 3 }),
			I("heart", 1, 2, { serpents: 3 }),
			I("church", 1, 0, { serpents: 4 }),
			I("dam", 1, 0, { serpents: 3 }),
			I("mine", 1, 2, { serpents: 2 }),
			I("geyser", 1, 2, { serpents: 2 }),
			I("ship", 1, 3, { serpents: 2 }),
			I("feeder", 1, 2, { serpents: 3 }),
			I("palace", 1, 2, { serpents: 4 }),
			I("reef", 1, 1, { serpents: 3 })
		]
	},
	orcs: {
		id: "orcs",
		nameKey: "games.heroeswac.faction.orcs",
		descKey: "games.heroeswac.factionDesc.orcs",
		color: "#ca8a04",
		terrainCost: {
			plain: 1,
			forest: 2,
			mountain: 3,
			lake: 2
		},
		monsterLine: M,
		units: [
			F("scout", 2, 2, 2, {
				recruitedBy: "camp",
				altPow: 4
			}),
			F("charger", 5, 3, 0, { recruitedBy: "gym" }),
			F("bomber", 9, 5, 0, {
				recruitedBy: "workshop",
				altPow: 12
			})
		],
		buildings: [
			I("idol", 1, 0, {
				iron: 2,
				gold: 2
			}),
			I("dump", 2, 1, {
				wood: 2,
				iron: 4,
				gold: 2
			}, ["idol"]),
			I("arena", 2, 0, {
				wood: 3,
				iron: 3,
				gold: 3
			}),
			I("camp", 2, 0, {
				wood: 2,
				iron: 2
			}),
			I("chiefhouse", 3, 2, {
				iron: 4,
				rage: 3
			}, ["dump"]),
			I("stable", 3, 2, {
				wood: 4,
				iron: 4,
				rage: 2
			}, ["dump"]),
			I("gym", 3, 2, {
				iron: 5,
				gold: 3
			}, ["camp"]),
			I("trophyhall", 4, 2, {
				iron: 6,
				rage: 2
			}, ["chiefhouse"]),
			I("catapult", 4, 2, {
				wood: 3,
				iron: 3,
				gold: 3,
				rage: 3
			}, ["arena"]),
			I("workshop", 4, 3, {
				wood: 4,
				iron: 4,
				rage: 4
			}, ["catapult", "gym"])
		]
	}
}, R = Object.fromEntries(x.flatMap((e) => L[e].buildings.map((t) => [t.id, {
	...t,
	faction: e
}]))), z = Object.fromEntries(x.flatMap((e) => L[e].units.map((t) => [t.id, {
	...t,
	faction: e
}]))), te = Object.fromEntries(x.map((e) => [e, L[e].nameKey])), B = Object.fromEntries(O.map((e) => [e.id, `games.heroeswac.region.${e.id}`])), ne = {
	totem: "games.heroeswac.artifact.totem",
	bowl: "games.heroeswac.artifact.bowl",
	mask: "games.heroeswac.artifact.mask",
	crystal: "games.heroeswac.artifact.crystal",
	book: "games.heroeswac.artifact.book",
	grail: "games.heroeswac.artifact.grail"
}, V = {
	wood: "games.heroeswac.act.wood",
	iron: "games.heroeswac.act.iron",
	gold: "games.heroeswac.act.gold",
	move: "games.heroeswac.act.move",
	build: "games.heroeswac.act.build"
}, re = {
	wood: 5,
	iron: 5,
	gold: 4
}, ie = {
	wood: 4,
	iron: 4,
	gold: 4
}, H = {
	id: "heroeswac",
	tier: "beta",
	mechanics: ["action-programming"],
	interactionTags: [],
	nameKey: "games.heroeswac.name",
	descKey: "games.heroeswac.desc",
	rulesKey: "games.heroeswac.rules",
	icon: "🗺️",
	iconImg: "games/heroeswac.webp",
	rulesUrl: { ru: "https://rules.bgparty.uuppi.com/heroeswac/ru.pdf" },
	precacheAssets: ["map.webp", "gnome-buildings.webp"],
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#9333ea",
	releasedAt: "2026-10-13",
	search: {
		py: "ying xiong zhi bi fa zheng tu",
		init: "yxzbfzt"
	},
	hotseat: "cover"
}, U = t.object({
	wood: t.int().nonnegative().optional(),
	iron: t.int().nonnegative().optional(),
	gold: t.int().nonnegative().optional()
}), W = t.string(), ae = t.enum(x), oe = t.enum(D), se = t.enum(S), G = t.string(), ce = t.record(t.string(), t.int().nonnegative()), le = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pick"),
		faction: ae
	}),
	t.object({
		type: t.literal("startPick"),
		region: W,
		anyGain: U.optional()
	}),
	t.object({
		type: t.literal("plan"),
		assign: t.partialRecord(se, t.int().min(1).max(4))
	}),
	t.object({
		type: t.literal("boost"),
		action: se.optional(),
		amount: t.int().min(1).optional()
	}),
	t.object({
		type: t.literal("build"),
		building: t.string().optional(),
		useFree: t.boolean().optional(),
		foundationSlot: t.int().min(0).max(2).nullable().optional(),
		recruits: ce.optional(),
		anyGain: U.optional(),
		library: t.boolean().optional(),
		illusion: t.object({
			kind: t.enum([
				"fortress",
				"artifact",
				"portal",
				"foundation"
			]),
			region: W,
			slot: t.int().min(0).max(2).optional()
		}).optional(),
		curseRegion: W.optional(),
		convert: t.object({
			toIron: t.int().nonnegative().optional(),
			toGold: t.int().nonnegative().optional()
		}).optional(),
		modify: t.object({
			s2c: t.int().nonnegative().optional(),
			c2b: t.int().nonnegative().optional(),
			s2b: t.int().nonnegative().optional()
		}).optional(),
		hydraDest: W.optional()
	}),
	t.object({
		type: t.literal("move"),
		dest: W,
		anyGain: U.optional(),
		hearse: t.int().nonnegative().optional(),
		hydraDest: W.optional(),
		geyser: t.boolean().optional()
	}),
	t.object({
		type: t.literal("declare"),
		fight: t.boolean(),
		wantFortress: t.boolean().optional(),
		wantArtifact: t.boolean().optional(),
		bribe: G.optional(),
		bribeGive: U.optional()
	}),
	t.object({
		type: t.literal("yieldDecide"),
		stick: t.boolean()
	}),
	t.object({
		type: t.literal("deploy"),
		units: ce,
		armorWood: t.int().nonnegative().optional()
	}),
	t.object({
		type: t.literal("reward"),
		choice: t.enum([
			"res",
			"loot",
			"artifact"
		]),
		victim: G.optional(),
		give: U.optional(),
		artifact: oe.optional(),
		anyGain: U.optional(),
		curseRegions: t.array(W).optional()
	}),
	t.object({
		type: t.literal("post"),
		fortress: t.object({
			units: ce,
			armorWood: t.int().nonnegative().optional(),
			useHydra: t.boolean().optional(),
			anyGain: U.optional()
		}).optional(),
		monster: t.object({
			skip: t.int().nonnegative().optional(),
			target: t.int().nonnegative().optional(),
			units: ce,
			armorWood: t.int().nonnegative().optional(),
			useHydra: t.boolean().optional(),
			anyGain: U.optional()
		}).optional(),
		artifact: t.object({
			payNests: t.boolean().optional(),
			anyGain: U.optional(),
			curseRegions: t.array(W).optional(),
			hydraDest: W.optional()
		}).optional()
	}),
	t.object({
		type: t.literal("toggleChapel"),
		on: t.boolean()
	})
]), ue = t.object({
	faction: ae.nullable(),
	region: W.nullable(),
	visited: t.array(W),
	mountainVisits: t.int().nonnegative(),
	wood: t.int().nonnegative(),
	iron: t.int().nonnegative(),
	gold: t.int().nonnegative(),
	rage: t.int().nonnegative(),
	science: t.int().nonnegative(),
	units: t.record(t.string(), t.int().nonnegative()),
	buildings: t.array(t.string()),
	artifacts: t.array(oe),
	fortresses: t.array(W),
	monsters: t.array(t.boolean()),
	foundations: t.record(t.string(), t.array(t.int().nonnegative())),
	thresh: t.object({
		wood: t.int().nonnegative(),
		iron: t.int().nonnegative(),
		gold: t.int().nonnegative(),
		rage: t.int().nonnegative()
	}),
	freeBuild: t.array(t.int()),
	chapelOn: t.boolean(),
	hydra: W.nullable(),
	hydraSummons: t.int().nonnegative(),
	notes: t.int().nonnegative()
}), de = t.object({
	kind: t.enum([
		"fortress",
		"artifact",
		"portal",
		"foundation"
	]),
	region: W,
	slot: t.int().optional(),
	by: G
}), fe = t.object({
	region: W,
	powers: t.record(t.string(), t.int()),
	winner: G.nullable(),
	hydraWin: G.nullable()
}), pe = t.union([le, t.object({
	type: t.literal("collect"),
	resource: t.enum([
		"wood",
		"iron",
		"gold"
	]),
	amount: t.int().positive()
})]), me = t.object({
	id: t.int().positive(),
	round: t.int().positive(),
	level: t.int().nullable(),
	actor: G,
	action: pe,
	contextRegion: W.optional(),
	contextKind: t.enum(["fortress", "artifact"]).optional(),
	result: t.object({
		regionBefore: W.nullable(),
		regionAfter: W.nullable(),
		resources: t.object({
			wood: t.int(),
			iron: t.int(),
			gold: t.int(),
			rage: t.int(),
			science: t.int(),
			notes: t.int()
		}),
		units: t.record(t.string(), t.int()),
		buildings: t.array(t.string()),
		artifactsGained: t.array(oe),
		artifactsLost: t.array(oe),
		fortresses: t.array(W),
		monsters: t.array(t.int().nonnegative()),
		battle: fe.optional()
	})
}), he = t.object({
	phase: t.enum([
		"pick",
		"start",
		"plan",
		"boost",
		"exec",
		"done"
	]),
	round: t.int().min(1),
	first: G,
	players: t.array(G),
	boards: t.record(t.string(), ue),
	map: t.object({
		removed: t.array(W),
		cursed: t.array(W),
		lakes: t.array(W),
		fortressOwner: t.record(t.string(), G),
		artifactOwner: t.record(t.string(), G),
		blocked: t.array(de)
	}),
	plan: t.partialRecord(se, t.int()).nullable(),
	boostInfo: t.record(t.string(), t.object({
		action: se,
		amount: t.int()
	})).nullable(),
	startOrder: t.array(G).nullable(),
	startIdx: t.int().nonnegative(),
	exec: t.object({
		level: t.int(),
		action: se,
		stage: t.enum([
			"build",
			"movePlan",
			"declare",
			"yield",
			"deploy",
			"reward",
			"post"
		]),
		waiting: t.array(G),
		declareRegions: t.array(t.object({
			region: W,
			members: t.array(G)
		})).optional(),
		yieldItem: t.object({
			region: W,
			kind: t.enum(["fortress", "artifact"]),
			claimants: t.array(G)
		}).nullable().optional(),
		battles: t.array(t.object({
			region: W,
			participants: t.array(G),
			hydraOwners: t.array(G)
		})).optional(),
		rewardQueue: t.array(G).optional(),
		leftover: t.record(t.string(), t.int()).optional(),
		budget: t.record(t.string(), t.int()).optional(),
		dests: t.record(t.string(), W).optional(),
		stayed: t.record(t.string(), t.boolean()).optional(),
		grants: t.record(t.string(), G).optional()
	}).nullable(),
	battleLog: t.array(fe),
	history: t.array(me),
	pending: t.object({
		actors: t.array(G),
		waiting: t.array(G)
	}).nullable()
}), ge = t.object({ echo: t.unknown().optional() }), K = (e) => ({ code: e }), q = () => K("games.heroeswac.err.phase"), J = (e, t) => e.buildings.includes(t), Y = (e, t) => e.artifacts.includes(t), X = (e) => (e?.wood ?? 0) + (e?.iron ?? 0) + (e?.gold ?? 0);
function Z(e, t, n, r, i = {}) {
	let a = e.player[t], o = {};
	for (let e of /* @__PURE__ */ new Set([...Object.keys(r.units), ...Object.keys(a.units)])) {
		let t = (a.units[e] ?? 0) - (r.units[e] ?? 0);
		t !== 0 && (o[e] = t);
	}
	let s = i.level === void 0 ? e.phase === "exec" ? e.execQueue[e.execIdx]?.level ?? null : null : i.level;
	e.history.push({
		id: e.history.length + 1,
		round: e.round,
		level: s,
		actor: t,
		action: n,
		contextRegion: i.contextRegion,
		contextKind: i.contextKind,
		result: {
			regionBefore: r.region,
			regionAfter: a.region,
			resources: {
				wood: a.wood - r.wood,
				iron: a.iron - r.iron,
				gold: a.gold - r.gold,
				rage: a.rage - r.rage,
				science: a.science - r.science,
				notes: a.notes - r.notes
			},
			units: o,
			buildings: a.buildings.filter((e) => !r.buildings.includes(e)),
			artifactsGained: a.artifacts.filter((e) => !r.artifacts.includes(e)),
			artifactsLost: r.artifacts.filter((e) => !a.artifacts.includes(e)),
			fortresses: a.fortresses.filter((e) => !r.fortresses.includes(e)),
			monsters: a.monsters.flatMap((e, t) => e && !r.monsters[t] ? [t] : []),
			battle: i.battle
		}
	});
}
function _e(e, t) {
	return e.lakes.includes(t) ? "lake" : k[t].terrain;
}
function ve(e, t) {
	let n = j(new Set(e.removed)), r = new Set(e.blocked.filter((e) => e.kind === "portal" && e.by !== t).map((e) => e.region));
	if (r.size === 0) return n;
	let i = {};
	for (let [e, t] of Object.entries(n)) i[e] = t.filter((t) => !k[e].portal || !k[t].portal || !r.has(e) && !r.has(t));
	return i;
}
function ye(e, t, n, r, i) {
	return e.blocked.some((e) => e.kind === n && e.region === r && e.by !== t && (n !== "foundation" || e.slot === i));
}
function be(e, t, n) {
	let r = _e(e, n), i = L[t.faction].terrainCost[r];
	return r === "forest" && (J(t, "trackers") || J(t, "guidforest")) && (i = 1), r === "mountain" && (J(t, "stable") ? i = 1 : (t.faction === "humans" && Y(t, "crystal") || t.faction === "elves" && Y(t, "book")) && (i = Math.min(i, 2))), t.faction === "undead" && Y(t, "totem") && k[n].foundations && (i = 1), i;
}
function xe(e, t, n, r) {
	if (n === r) return 0;
	let i = e.player[t], a = ve(e, t), o = { [n]: 0 }, s = [n];
	for (; s.length > 0;) {
		let t = 0;
		for (let e = 1; e < s.length; e++) o[s[e]] < o[s[t]] && (t = e);
		let n = s.splice(t, 1)[0];
		if (n === r) return o[n];
		for (let t of a[n] ?? []) {
			let r = o[n] + be(e, i, t);
			(o[t] === void 0 || r < o[t]) && (o[t] = r, s.includes(t) || s.push(t));
		}
	}
	return Infinity;
}
function Se(e, t, n, r) {
	if (n === r) return 0;
	let i = ve(e, t), a = /* @__PURE__ */ new Set([n]), o = [n], s = 0;
	for (; o.length > 0 && s < 3;) {
		s++;
		let e = [];
		for (let t of o) for (let n of i[t] ?? []) {
			if (n === r) return s;
			a.has(n) || (a.add(n), e.push(n));
		}
		o = e;
	}
	return Infinity;
}
var Ce = [
	4,
	9,
	14
], we = [
	2,
	3,
	4
];
function Q(e, t) {
	let n = t.gold ?? 0;
	n > 0 && e.faction === "elves" && Y(e, "bowl") && (n += 2), e.wood += t.wood ?? 0, e.iron += t.iron ?? 0, e.gold += n;
	for (let t of [
		"wood",
		"iron",
		"gold"
	]) for (; e.thresh[t] < 3 && e[t] >= C[e.thresh[t]];) e.thresh[t]++;
	(t.iron ?? 0) >= 3 && e.faction === "undead" && J(e, "chapel") && e.chapelOn && e.iron >= 3 && (e.iron -= 3, e.units.executioner = (e.units.executioner ?? 0) + 1);
}
function Te(e, t) {
	for (e.rage += t; e.thresh.rage < 3 && e.rage >= T[e.thresh.rage];) e.thresh.rage++;
}
function Ee(e, t) {
	e.science += t, Ce.forEach((t, n) => {
		e.science >= t && !e.freeGranted.includes(t) && (e.freeGranted.push(t), e.freeBuild.push(we[n]));
	});
}
function De(e, t, n, r) {
	let i = z[n];
	if (t.faction === "humans" && J(t, "armoury")) {
		if (n === "soldier") return 3;
		if (n === "cuirassier") return 4;
		if (n === "archmage") return 7;
	}
	if (t.faction === "gnomes") {
		if (n === "automaton" && Y(t, "bowl")) return 6;
		if (n === "anisopter" && Y(t, "mask")) return 3;
		if (n === "mechasaur") return 5 + Math.floor(t.science / 3);
	}
	if (t.faction === "undead") {
		if (n === "skeleton" && Y(t, "bowl")) return 2;
		if (n === "executioner") return r.budget;
	}
	if (t.faction === "orcs") {
		if (n === "scout" && r.region && _e(e, r.region) === "mountain" && J(t, "camp")) return 4;
		if (n === "bomber" && r.fortress && J(t, "workshop")) return 12;
	}
	return t.faction === "nagas" && n === "serpent" ? r.serpents : i.pow;
}
function Oe(e, t, n, r, i) {
	let a = e.player[t], o = [];
	for (let [t, r] of Object.entries(n)) for (let n = 0; n < r; n++) o.push({
		uid: t,
		pow: De(e, a, t, i)
	});
	if (o.length === 0) return 0;
	if (r > 0 && J(a, "armorshop")) {
		let e = o.filter((e) => z[e.uid].altPow !== void 0).sort((e, t) => t.pow - e.pow);
		for (let t = 0; t < Math.min(r, e.length); t++) e[t].pow = z[e[t].uid].altPow;
	}
	let s = o.filter((e) => e.uid === "mechanic").length;
	if (s > 0 && J(a, "academy")) {
		let e = o.filter((e) => e.uid !== "mechanic").sort((e, t) => t.pow - e.pow);
		for (let t = 0; t < Math.min(s, e.length); t++) e[t].pow *= 2;
	}
	let c = o.reduce((e, t) => e + t.pow, 0);
	return J(a, "horn") && (c += 1), J(a, "catapult") && (c += 4), i.monster && a.faction === "elves" && Y(a, "crystal") && (c += 3), c;
}
function ke(e, t) {
	let n = J(e, "heart") ? 25 : 18;
	return t && !J(e, "reef") && (n -= 2 * (e.units.serpent ?? 0)), Math.max(0, n);
}
function Ae(e, t) {
	let n = e.player[t], r = L[n.faction], i = {
		budget: e.moveBudget[t] ?? 0,
		serpents: 1
	}, a = null, o = (e) => e === "serpent" ? 4 : z[e].cost;
	for (let [t, s] of Object.entries(n.units)) {
		if (s <= 0) continue;
		if (a === null) {
			a = t;
			continue;
		}
		let c = De(e, n, t, i), l = De(e, n, a, i);
		(c < l || c === l && (o(t) < o(a) || o(t) === o(a) && r.units.findIndex((e) => e.id === t) < r.units.findIndex((e) => e.id === a))) && (a = t);
	}
	a !== null && (n.units[a] = (n.units[a] ?? 1) - 1);
}
function je(e, t, n) {
	if (!(e.cursed.includes(n) || e.removed.includes(n) || !k[n])) {
		e.cursed.push(n), e.cursedBy[n] = t;
		for (let r of e.players) r !== t && e.player[r].region === n && Ae(e, r);
	}
}
function Me(e) {
	let t = e.monsters.indexOf(!1);
	return t >= 0 && (e.monsters[t] = !0), t;
}
function Ne(e, t, n, r, i) {
	let a = e.player[t].faction, o = a === "gnomes" && n === "book" ? 9 : a === "humans" && n === "grail" || a === "undead" && n === "grail" ? 8 : 0;
	if (X(r) !== o) return K("games.heroeswac.err.badAny");
	let s = a === "undead" && (n === "mask" || n === "book") ? 3 : 0, c = i ?? [];
	if (s > 0) {
		if (c.length !== 3 || new Set(c).size !== 3) return K("games.heroeswac.err.badCurse");
		for (let t of c) if (!k[t] || e.removed.includes(t) || e.cursed.includes(t)) return K("games.heroeswac.err.badCurse");
	} else if (c.length > 0) return K("games.heroeswac.err.badCurse");
	return null;
}
function Pe(e, t, n, r, i) {
	let a = e.player[t], o = a.faction;
	X(r) > 0 && Q(a, r ?? {});
	for (let n of i ?? []) je(e, t, n);
	o === "gnomes" ? (n === "crystal" && Ee(a, 3), n === "grail" && (a.units.anisopter = (a.units.anisopter ?? 0) + 4)) : o === "humans" ? n === "bowl" && (a.units.archmage = (a.units.archmage ?? 0) + 3) : o === "elves" ? n === "totem" && (a.units.ent = (a.units.ent ?? 0) + 3) : o === "undead" ? n === "crystal" && (a.units.lich = (a.units.lich ?? 0) + 2) : o === "orcs" && (n === "totem" && Te(a, 6), n === "mask" && (a.units.bomber = (a.units.bomber ?? 0) + 3), n === "grail" && Te(a, 2 * a.artifacts.length)), o === "nagas" && J(a, "ship") && (a.notes = Math.min(12, a.notes + 1));
}
function Fe() {
	return {
		faction: null,
		region: null,
		visited: [],
		mountainVisits: 0,
		wood: 0,
		iron: 0,
		gold: 0,
		rage: 0,
		science: 0,
		units: {},
		buildings: [],
		artifacts: [],
		fortresses: [],
		monsters: [
			!1,
			!1,
			!1,
			!1,
			!1,
			!1,
			!1,
			!1
		],
		foundations: {},
		thresh: {
			wood: 0,
			iron: 0,
			gold: 0,
			rage: 0
		},
		freeBuild: [],
		freeGranted: [],
		chapelOn: !0,
		hydra: null,
		hydraSummons: 0,
		notes: 0,
		stoleArtifact: !1,
		monsterFought: !1
	};
}
function Ie(t, n, r) {
	let i = O.filter((e) => e.removedAt.includes(n.length)).map((e) => e.id), a = {};
	for (let e of n) a[e] = Fe();
	return { state: {
		seed: r,
		rngCursor: 1,
		players: n,
		player: a,
		phase: "pick",
		round: 1,
		firstIdx: e(r, 0, n.length),
		removed: i,
		cursed: [],
		cursedBy: {},
		lakes: [],
		fortressOwner: {},
		artifactOwner: {},
		blocked: [],
		plan: null,
		boostSubs: {},
		startOrder: [],
		startIdx: 0,
		execQueue: [],
		execIdx: 0,
		exec: null,
		moveBudget: {},
		battleLog: [],
		history: []
	} };
}
function Le(e) {
	let t = e.players.length;
	return Array.from({ length: t }, (n, r) => e.players[(e.firstIdx + r) % t]);
}
function Re(e) {
	e.phase = "exec";
	let t = [];
	for (let n of S) {
		let r = e.plan?.[n];
		r !== void 0 && t.push({
			level: r,
			action: n
		});
	}
	t.sort((e, t) => e.level - t.level || S.indexOf(e.action) - S.indexOf(t.action)), e.execQueue = t, e.execIdx = 0, ze(e);
}
function ze(e) {
	for (; e.execIdx < e.execQueue.length;) {
		let { level: t, action: n } = e.execQueue[e.execIdx];
		if (n === "wood" || n === "iron" || n === "gold") {
			for (let r of Le(e)) {
				let i = structuredClone(e.player[r]);
				Q(e.player[r], { [n]: t }), Z(e, r, {
					type: "collect",
					resource: n,
					amount: t
				}, i, { level: t });
			}
			e.execIdx++;
			continue;
		}
		if (n === "build") {
			for (let t of e.players) {
				let n = e.player[t];
				if (n.faction !== "nagas") continue;
				let r = J(n, "feeder") ? ie : re, i = Math.floor(n.wood / r.wood), a = Math.floor(n.iron / r.iron), o = Math.floor(n.gold / r.gold);
				n.units.serpent = (n.units.serpent ?? 0) + i + a + o, n.wood -= i * r.wood, n.iron -= a * r.iron, n.gold -= o * r.gold;
			}
			e.exec = {
				action: "build",
				subs: {}
			};
			return;
		}
		e.exec = {
			action: "move",
			stage: "movePlan",
			moveSubs: {},
			dests: {},
			budget: {},
			leftover: {},
			stayed: {},
			declareRegions: [],
			declareSubs: {},
			yieldQueue: [],
			yieldIdx: 0,
			yieldSubs: {},
			grants: {},
			battleWinners: {},
			battles: [],
			deploySubs: {},
			rewardQueue: [],
			rewardInfo: {},
			postSubs: {}
		};
		return;
	}
	Be(e);
}
function Be(e) {
	if (e.exec = null, e.execQueue = [], e.execIdx = 0, e.moveBudget = {}, e.round >= 16) {
		e.phase = "done";
		return;
	}
	e.round++, e.firstIdx = (e.firstIdx + 1) % e.players.length;
	for (let t of e.players) e.player[t].stoleArtifact = !1, e.player[t].monsterFought = !1;
	e.plan = null, e.boostSubs = {}, e.phase = "plan";
}
function Ve(e, t, n) {
	let r = e.player[t], i = e.execQueue[e.execIdx].level, a = r.wood, o = r.iron, s = r.gold, c = r.rage, l = r.units.serpent ?? 0, u = null;
	if (n.building) {
		let e = R[n.building];
		if (!e || e.faction !== r.faction || r.buildings.includes(n.building) || e.level > i || e.req.length > 0 && !e.req.some((e) => r.buildings.includes(e))) return K("games.heroeswac.err.noBuilding");
		if (u = e, n.useFree) {
			let t = r.freeBuild.filter((t) => t >= e.level).sort((e, t) => e - t)[0];
			if (e.level <= 1 || t === void 0) return K("games.heroeswac.err.noFree");
		} else {
			let t = e.cost.wood ?? 0, n = e.cost.gold ?? 0;
			r.faction === "elves" && J(r, "woodedcliff") && (t = 0), r.faction === "elves" && Y(r, "grail") && (n = 0);
			let i = e.cost.iron ?? 0, u = e.cost.rage ?? 0, d = e.cost.serpents ?? 0;
			if (a < t || o < i || s < n || c < u || l < d) return K("games.heroeswac.err.noRes");
			a -= t, s -= n;
		}
	} else if (n.useFree) return K("games.heroeswac.err.noFree");
	if (n.foundationSlot !== void 0 && n.foundationSlot !== null) {
		if (!u) return K("games.heroeswac.err.badFoundation");
		let i = r.region, a = k[i], o = n.foundationSlot;
		if (!a.foundations || o < 0 || o >= a.foundations || ye(e, t, "foundation", i, o) || (r.foundations[i]?.[o] ?? 0) >= u.level) return K("games.heroeswac.err.badFoundation");
	}
	let d = n.recruits ?? {}, f = 0;
	for (let [e, t] of Object.entries(d)) {
		if (t <= 0) continue;
		let n = z[e];
		if (!n || n.faction !== r.faction || !n.recruitedBy || !J(r, n.recruitedBy)) return K("games.heroeswac.err.noRecruit");
		let i = n.cost;
		r.faction === "gnomes" && J(r, "pipeline") && e !== "mechanic" && (i = Math.max(0, i - Math.floor(r.science / 9))), r.faction === "humans" && J(r, "cathedral") && (e === "cuirassier" && (i = 2), e === "archmage" && (i = 3)), f += i * t;
	}
	if (s < f) return K("games.heroeswac.err.noRes");
	let p = n.modify;
	if (p && ((p.s2c ?? 0) > 0 || (p.c2b ?? 0) > 0 || (p.s2b ?? 0) > 0)) {
		if (r.faction !== "orcs") return K("games.heroeswac.err.noRecruit");
		let e = p.s2c ?? 0, t = p.c2b ?? 0, n = p.s2b ?? 0;
		if (c < e + 3 * t + 4 * n) return K("games.heroeswac.err.noRage");
		if ((r.units.scout ?? 0) < e + n || (r.units.charger ?? 0) < t) return K("games.heroeswac.err.noRecruit");
	}
	if (n.library) {
		if (!J(r, "library") || a < 4) return K("games.heroeswac.err.noRes");
		a -= 4;
	}
	if (n.illusion) {
		if (!J(r, "illtower") || a < 4) return K("games.heroeswac.err.noRes");
		a -= 4;
		let t = n.illusion, i = k[t.region];
		if (!i || e.removed.includes(t.region) || e.blocked.some((e) => e.kind === t.kind && e.region === t.region && (t.kind !== "foundation" || e.slot === t.slot)) || t.kind === "fortress" && (!i.fortress || e.fortressOwner[t.region]) || t.kind === "artifact" && (!i.artifact || e.artifactOwner[i.artifact]) || t.kind === "portal" && !i.portal || t.kind === "foundation" && (!i.foundations || t.slot === void 0 || t.slot < 0 || t.slot >= i.foundations)) return K("games.heroeswac.err.badIllusion");
	}
	if (n.curseRegion) {
		if (!J(r, "plague") || a < 3) return K("games.heroeswac.err.noRes");
		if (a -= 3, !k[n.curseRegion] || e.removed.includes(n.curseRegion) || e.cursed.includes(n.curseRegion) || n.curseRegion !== r.region && !(ve(e, t)[r.region] ?? []).includes(n.curseRegion)) return K("games.heroeswac.err.badCurse");
	}
	if (n.convert && ((n.convert.toIron ?? 0) > 0 || (n.convert.toGold ?? 0) > 0)) {
		if (!(r.faction === "humans" && Y(r, "totem"))) return K("games.heroeswac.err.badConvert");
		let e = (n.convert.toIron ?? 0) + (n.convert.toGold ?? 0);
		if (a < e) return K("games.heroeswac.err.noRes");
	}
	let m = n.building === "assemblers" ? 9 : 0;
	return X(n.anyGain) === m ? n.hydraDest && (r.faction !== "nagas" || !u || (r.notes + 1) % 2 != 0 || !k[n.hydraDest] || e.removed.includes(n.hydraDest) || _e(e, n.hydraDest) !== "lake") ? K("games.heroeswac.err.noHydra") : null : K("games.heroeswac.err.badAny");
}
function He(e, t, n) {
	let r = e.player[t];
	if (n.building) {
		let e = R[n.building];
		if (n.useFree) {
			let t = r.freeBuild.filter((t) => t >= e.level).sort((e, t) => e - t)[0];
			r.freeBuild.splice(r.freeBuild.indexOf(t), 1);
		} else {
			let t = e.cost.wood ?? 0, n = e.cost.gold ?? 0;
			r.faction === "elves" && J(r, "woodedcliff") && (t = 0), r.faction === "elves" && Y(r, "grail") && (n = 0), r.wood -= t, r.gold -= n, r.iron -= e.cost.iron ?? 0, r.rage -= e.cost.rage ?? 0, e.cost.serpents && (r.units.serpent = (r.units.serpent ?? 0) - e.cost.serpents);
		}
		if (r.buildings.push(n.building), r.faction === "nagas" && (r.notes = Math.min(12, r.notes + 1)), n.building === "generator" && Ee(r, r.units.mechanic ?? 0), n.building === "assemblers" && (Ee(r, 1), Q(r, n.anyGain ?? {})), n.foundationSlot !== void 0 && n.foundationSlot !== null) {
			let t = r.region, i = r.foundations[t] ??= [
				0,
				0,
				0
			];
			i[n.foundationSlot] = e.level, J(r, "dump") && Te(r, 2);
		}
	}
	let i = n.recruits ?? {};
	for (let [e, t] of Object.entries(i)) {
		if (t <= 0) continue;
		let n = z[e].cost;
		r.faction === "gnomes" && J(r, "pipeline") && e !== "mechanic" && (n = Math.max(0, n - Math.floor(r.science / 9))), r.faction === "humans" && J(r, "cathedral") && (e === "cuirassier" && (n = 2), e === "archmage" && (n = 3)), r.gold -= n * t, r.units[e] = (r.units[e] ?? 0) + t, e === "automaton" && J(r, "plant") && Ee(r, t), e === "charger" && J(r, "arena") && Te(r, t);
	}
	let a = n.modify;
	if (a) {
		let e = a.s2c ?? 0, t = a.c2b ?? 0, n = a.s2b ?? 0;
		e + t + n > 0 && (r.rage -= e + 3 * t + 4 * n, r.units.scout = (r.units.scout ?? 0) - e - n, r.units.charger = (r.units.charger ?? 0) + e - t, r.units.bomber = (r.units.bomber ?? 0) + t + n);
	}
	if (n.library && (r.wood -= 4, Ee(r, 1)), n.illusion) {
		r.wood -= 4;
		let i = n.illusion;
		e.blocked.some((e) => e.kind === i.kind && e.region === i.region && (i.kind !== "foundation" || e.slot === i.slot)) || e.blocked.push({
			kind: i.kind,
			region: i.region,
			slot: i.slot,
			by: t
		});
	}
	if (n.curseRegion && (r.wood -= 3, je(e, t, n.curseRegion)), n.convert) {
		let e = n.convert.toIron ?? 0, t = n.convert.toGold ?? 0;
		r.wood -= e + t, Q(r, {
			iron: e,
			gold: t
		});
	}
	n.hydraDest && (r.hydra = n.hydraDest, r.hydraSummons++);
}
function Ue(e, t, n) {
	return e.execQueue[e.execIdx].level + +!!J(t, "observatory") + n;
}
function We(e, t, n) {
	let r = e.player[t], i = k[n.dest];
	if (!i || e.removed.includes(n.dest)) return K("games.heroeswac.err.badDest");
	let a = n.hearse ?? 0;
	if (a > 0) {
		if (!J(r, "hearse")) return K("games.heroeswac.err.noBudget");
		if (r.wood < 2 * a) return K("games.heroeswac.err.noRes");
	}
	let o = Ue(e, r, a), s = xe(e, t, r.region, n.dest);
	if (s > o || n.geyser && (!J(r, "geyser") || _e(e, n.dest) === "lake" || s + 1 > o)) return K("games.heroeswac.err.noBudget");
	if (n.hydraDest && (!r.hydra || !k[n.hydraDest] || e.removed.includes(n.hydraDest) || Se(e, t, r.hydra, n.hydraDest) > (J(r, "lighthouse") ? 2 : 1))) return K("games.heroeswac.err.noHydra");
	let c = r.visited.includes(n.dest) ? 0 : i.any + (J(r, "townhall") || J(r, "lab") ? 1 : 0);
	return X(n.anyGain) === c ? null : K("games.heroeswac.err.badAny");
}
function Ge(e, t) {
	for (let n of Le(e)) {
		let r = t.moveSubs[n], i = e.player[n], a = structuredClone(i), o = r.hearse ?? 0, s = Ue(e, i, o), c = xe(e, n, i.region, r.dest);
		t.budget[n] = s, t.leftover[n] = s - c, t.dests[n] = r.dest, t.stayed[n] = r.dest === i.region, e.moveBudget[n] = s, i.wood -= 2 * o, i.region = r.dest, i.visited.includes(r.dest) || (i.visited.push(r.dest), Q(i, k[r.dest].res), Q(i, r.anyGain ?? {}), _e(e, r.dest) === "mountain" && i.mountainVisits++), e.cursedBy[r.dest] && e.cursedBy[r.dest] !== n && Ae(e, n), r.geyser && (t.leftover[n]--, e.lakes.includes(r.dest) || e.lakes.push(r.dest)), i.faction === "orcs" && Y(i, "book") && Te(i, 1), r.hydraDest && i.hydra && (i.hydra = r.hydraDest), Z(e, n, r, a);
	}
	let n = {};
	for (let r of e.players) {
		let e = t.dests[r];
		(n[e] ??= []).push(r);
	}
	let r = {};
	for (let t of e.players) {
		let n = e.player[t].hydra;
		n && (r[n] ??= []).push(t);
	}
	for (let [e, i] of Object.entries(n)) {
		let n = r[e] ?? [];
		(/* @__PURE__ */ new Set([...i, ...n])).size < 2 || (n.length > 0 ? t.battles.push({
			region: e,
			heroes: i,
			hydraOwners: n
		}) : t.declareRegions.push({
			region: e,
			members: i
		}));
	}
	t.declareRegions.length > 0 ? t.stage = "declare" : t.battles.length > 0 ? (Ke(e, t), t.stage = "deploy") : t.stage = "post";
}
function Ke(e, t) {
	let n = Le(e), r = (e) => n.indexOf(e);
	t.battles.sort((e, t) => Math.min(...[...e.heroes, ...e.hydraOwners].map(r)) - Math.min(...[...t.heroes, ...t.hydraOwners].map(r)));
}
function qe(e, t) {
	let n = Object.fromEntries(t.declareRegions.flatMap((e) => e.members).map((t) => [t, structuredClone(e.player[t])]));
	for (let n of t.declareRegions) {
		let r = /* @__PURE__ */ new Set();
		for (let i of n.members) {
			let a = t.declareSubs[i];
			if (!a.bribe || a.bribe === i || !n.members.includes(a.bribe)) continue;
			let o = e.player[i];
			if (o.faction !== "nagas" || !J(o, "mine")) continue;
			let s = a.bribeGive ?? {};
			X(s) === 3 && ((s.wood ?? 0) > o.wood || (s.iron ?? 0) > o.iron || (s.gold ?? 0) > o.gold || (o.wood -= s.wood ?? 0, o.iron -= s.iron ?? 0, o.gold -= s.gold ?? 0, Q(e.player[a.bribe], s), r.add(a.bribe)));
		}
		let i = n.members.filter((e) => !r.has(e));
		if (i.some((e) => t.declareSubs[e].fight)) {
			i.length >= 2 && t.battles.push({
				region: n.region,
				heroes: i,
				hydraOwners: []
			});
			continue;
		}
		let a = k[n.region];
		if (a.fortress && !e.fortressOwner[n.region]) {
			let r = i.filter((r) => t.declareSubs[r].wantFortress && !ye(e, r, "fortress", n.region));
			r.length === 1 ? t.grants[`${n.region}:fortress`] = r[0] : r.length > 1 && t.yieldQueue.push({
				region: n.region,
				kind: "fortress",
				claimants: r
			});
		}
		if (a.artifact && !e.artifactOwner[a.artifact]) {
			let r = i.filter((r) => t.declareSubs[r].wantArtifact && !ye(e, r, "artifact", n.region));
			r.length === 1 ? t.grants[`${n.region}:artifact`] = r[0] : r.length > 1 && t.yieldQueue.push({
				region: n.region,
				kind: "artifact",
				claimants: r
			});
		}
	}
	for (let r of Le(e)) {
		let i = t.declareSubs[r];
		i && Z(e, r, i, n[r], { contextRegion: t.declareRegions.find((e) => e.members.includes(r))?.region });
	}
	t.yieldQueue.length > 0 ? (t.stage = "yield", t.yieldIdx = 0, t.yieldSubs = {}) : Je(e, t);
}
function Je(e, t) {
	t.battles.length > 0 ? (Ke(e, t), t.stage = "deploy") : t.stage = "post";
}
function Ye(e, t) {
	for (let n of t.battles) {
		let r = {}, i = {};
		for (let a of n.heroes) {
			let o = t.deploySubs[a] ?? {
				type: "deploy",
				units: {}
			}, s = e.player[a];
			s.wood -= o.armorWood ?? 0, i[a] = o.units;
			let c = o.units.serpent ?? 0, l = Oe(e, a, o.units, o.armorWood ?? 0, {
				region: n.region,
				budget: e.moveBudget[a] ?? 0,
				serpents: c
			});
			n.hydraOwners.includes(a) && (l += ke(s, !0)), r[a] = l;
		}
		for (let t of n.hydraOwners) n.heroes.includes(t) || (r[t] = ke(e.player[t], !1));
		let a = null, o = -1, s = !1;
		for (let [e, t] of Object.entries(r)) t > o ? (o = t, a = e, s = !1) : t === o && (s = !0);
		s && (a = null);
		for (let [t, n] of Object.entries(i)) {
			let r = e.player[t];
			for (let [e, t] of Object.entries(n)) r.units[e] = (r.units[e] ?? 0) - t;
			r.faction === "undead" && (J(r, "barrow") && (r.units.skeleton = (r.units.skeleton ?? 0) + Math.min(2, n.skeleton ?? 0)), J(r, "tomb") && (n.executioner ?? 0) > 0 && (r.units.executioner = (r.units.executioner ?? 0) + 1), J(r, "ossuary") && (n.lich ?? 0) > 0 && (r.units.skeleton = (r.units.skeleton ?? 0) + (n.skeleton ?? 0)));
		}
		for (let t of n.hydraOwners) e.player[t].hydra = null;
		let c = a !== null && !n.heroes.includes(a) ? a : null;
		if (a !== null) {
			let i = e.player[a];
			J(i, "idol") && Te(i, 2);
			let s = Me(i);
			if (c === null && s >= 0) {
				let e = Object.entries(r).filter(([e]) => e !== a).map(([, e]) => e);
				t.rewardInfo[a] = {
					region: n.region,
					monster: s,
					losers: Object.keys(r).filter((e) => e !== a),
					diff: o - Math.min(...e)
				}, t.rewardQueue.push(a);
			}
		}
		t.battleWinners[n.region] = a, e.battleLog.push({
			region: n.region,
			powers: r,
			winner: a,
			hydraWin: c
		}), e.battleLog.length > 40 && e.battleLog.shift();
	}
	t.stage = t.rewardQueue.length > 0 ? "reward" : "post";
}
function Xe(e, t, n, r) {
	let i = e.player[n].region;
	if (t.grants[`${i}:${r}`] === n) return !0;
	let a = t.battleWinners[i];
	if (a !== void 0) return a === n;
	let o = e.players.filter((e) => t.dests[e] === i);
	return o.length === 1 && o[0] === n;
}
function Ze(e, t) {
	for (let [n, r] of Object.entries(t)) {
		if (r <= 0) continue;
		let t = z[n];
		if (!t || t.faction !== e.faction || (e.units[n] ?? 0) < r) return !1;
	}
	return !0;
}
function Qe(e, t, n) {
	let r = e.exec, i = e.player[t], a = i.region, o = k[a];
	if (n.fortress && n.artifact) return K("games.heroeswac.err.fortressXorArtifact");
	if (n.fortress) {
		let s = n.fortress;
		if (!o.fortress || e.fortressOwner[a] || ye(e, t, "fortress", a) || !Xe(e, r, t, "fortress")) return K("games.heroeswac.err.noFortress");
		let c = $e(s.units);
		if (s.useHydra && i.hydra !== a || !s.useHydra && !c || !Ze(i, s.units)) return K("games.heroeswac.err.noFortress");
		let l = s.armorWood ?? 0;
		if (l > 0 && (!J(i, "armorshop") || i.wood < l)) return K("games.heroeswac.err.noFortress");
		if (X(s.anyGain) !== o.fortress.any) return K("games.heroeswac.err.badAny");
		let u = s.units.serpent ?? 0, d = Oe(e, t, s.units, l, {
			region: a,
			fortress: !0,
			budget: r.budget[t] ?? 0,
			serpents: u
		});
		if (s.useHydra && (d += ke(i, c)), d <= o.fortress.pow) return K("games.heroeswac.err.noFortress");
	}
	if (n.monster) {
		let o = n.monster;
		if (i.monsterFought) return K("games.heroeswac.err.noMonster");
		let s = L[i.faction].monsterLine, c;
		if (o.target !== void 0) {
			if (!J(i, "shrine") || !r.stayed[t] || o.target < 0 || o.target >= s.length || i.monsters[o.target]) return K("games.heroeswac.err.noMonster");
			c = o.target;
		} else {
			let e = o.skip ?? 0;
			if (e > (r.leftover[t] ?? 0)) return K("games.heroeswac.err.noMonster");
			let n = [];
			if (i.monsters.forEach((e, t) => {
				e || n.push(t);
			}), e >= n.length) return K("games.heroeswac.err.noMonster");
			c = n[e];
		}
		let l = $e(o.units);
		if (o.useHydra) {
			if (i.hydra !== a || l) return K("games.heroeswac.err.noMonster");
		} else if (!l) return K("games.heroeswac.err.noMonster");
		if (!Ze(i, o.units)) return K("games.heroeswac.err.noMonster");
		let u = o.armorWood ?? 0;
		if (u > 0 && (!J(i, "armorshop") || i.wood < u)) return K("games.heroeswac.err.noMonster");
		let d = o.useHydra ? 0 : s[c].any + (J(i, "market") ? 2 : 0);
		if (X(o.anyGain) !== d) return K("games.heroeswac.err.badAny");
		if (!o.useHydra) {
			let n = o.units.serpent ?? 0;
			if (Oe(e, t, o.units, u, {
				monster: !0,
				budget: r.budget[t] ?? 0,
				serpents: n
			}) <= s[c].pow) return K("games.heroeswac.err.noMonster");
		} else if (ke(i, !1) <= s[c].pow) return K("games.heroeswac.err.noMonster");
	}
	if (n.artifact) {
		let s = n.artifact, c = o.artifact;
		if (!c || e.artifactOwner[c] || ye(e, t, "artifact", a)) return K("games.heroeswac.err.noArtifact");
		if (i.stoleArtifact) return K("games.heroeswac.err.stoleArtifact");
		if (!Xe(e, r, t, "artifact")) return K("games.heroeswac.err.noArtifact");
		let l = ee[c];
		if (i.faction === "nagas") {
			if ((i.units.serpent ?? 0) < 3) return K("games.heroeswac.err.noArtifact");
		} else if (s.payNests) {
			if (!(i.faction === "elves" && J(i, "nests")) || (i.units.griffin ?? 0) < l.elfWood || i.wood < l.elfWood) return K("games.heroeswac.err.noArtifact");
		} else if (l.cond.kind === "pay") {
			if (i[l.cond.res] < l.cond.amount) return K("games.heroeswac.err.noArtifact");
		} else if (l.cond.kind === "foundations") {
			if (Object.values(i.foundations).reduce((e, t) => e + t.filter((e) => e > 0).length, 0) < l.cond.amount) return K("games.heroeswac.err.noArtifact");
		} else if (l.cond.kind === "victories") {
			if (i.fortresses.length + i.monsters.filter(Boolean).length < l.cond.amount) return K("games.heroeswac.err.noArtifact");
		} else if (i.mountainVisits < l.cond.amount) return K("games.heroeswac.err.noArtifact");
		let u = Ne(e, t, c, s.anyGain, s.curseRegions);
		if (u) return u;
		if (s.hydraDest && (i.faction !== "nagas" || !J(i, "ship") || (i.notes + 1) % 2 != 0 || !k[s.hydraDest] || e.removed.includes(s.hydraDest) || _e(e, s.hydraDest) !== "lake")) return K("games.heroeswac.err.noHydra");
	}
	if (n.fortress && n.monster) {
		if (n.fortress.useHydra && n.monster.useHydra) return K("games.heroeswac.err.noMonster");
		let e = {};
		for (let t of [n.fortress, n.monster]) for (let [n, r] of Object.entries(t.units)) e[n] = (e[n] ?? 0) + r;
		if (!Ze(i, e)) return K("games.heroeswac.err.noMonster");
	}
	return null;
}
function $e(e) {
	return Object.values(e).some((e) => e > 0);
}
function et(e, t, n, r) {
	let i = e.player[n], a = i.region, o = k[a];
	if (r.fortress && o.fortress && !e.fortressOwner[a]) {
		let s = r.fortress, c = s.armorWood ?? 0;
		i.wood -= c;
		for (let [e, t] of Object.entries(s.units)) i.units[e] = (i.units[e] ?? 0) - t;
		let l = $e(s.units), u = s.units.serpent ?? 0, d = Oe(e, n, s.units, c, {
			region: a,
			fortress: !0,
			budget: t.budget[n] ?? 0,
			serpents: u
		});
		s.useHydra && (d += ke(i, l), i.hydra = null), d > o.fortress.pow && (i.fortresses.push(a), e.fortressOwner[a] = n, l && (Q(i, o.fortress.res), Q(i, s.anyGain ?? {})));
	}
	if (r.monster) {
		let a = r.monster, o = L[i.faction].monsterLine, s;
		if (a.target !== void 0) s = a.target;
		else {
			let e = [];
			i.monsters.forEach((t, n) => {
				t || e.push(n);
			}), s = e[a.skip ?? 0];
		}
		if (i.monsterFought = !0, a.useHydra) i.hydra = null, ke(i, !1) > o[s].pow && (i.monsters[s] = !0);
		else {
			let r = a.armorWood ?? 0;
			i.wood -= r;
			for (let [e, t] of Object.entries(a.units)) i.units[e] = (i.units[e] ?? 0) - t;
			let c = a.units.serpent ?? 0;
			Oe(e, n, a.units, r, {
				monster: !0,
				budget: t.budget[n] ?? 0,
				serpents: c
			}) > o[s].pow && (i.monsters[s] = !0, Q(i, o[s].res), Q(i, a.anyGain ?? {}));
		}
	}
	if (r.artifact) {
		let t = r.artifact, a = o.artifact;
		if (!e.artifactOwner[a]) {
			let r = ee[a];
			i.faction === "nagas" ? i.units.serpent = (i.units.serpent ?? 0) - 3 : t.payNests ? i.wood -= r.elfWood : r.cond.kind === "pay" && (r.cond.res === "wood" ? i.wood -= r.cond.amount : r.cond.res === "iron" ? i.iron -= r.cond.amount : i.gold -= r.cond.amount), i.artifacts.push(a), e.artifactOwner[a] = n, Pe(e, n, a, t.anyGain, t.curseRegions), t.hydraDest && (i.hydra = t.hydraDest, i.hydraSummons++);
		}
	}
}
function tt(e, t, n) {
	let r = structuredClone(e), i = r.player[n.by];
	if (!i) return q();
	if (t.type === "toggleChapel") {
		if (i.faction !== "undead" || !J(i, "chapel")) return q();
		let e = structuredClone(i);
		return i.chapelOn = t.on, Z(r, n.by, t, e), { state: r };
	}
	if (t.type === "pick") {
		if (r.phase !== "pick") return q();
		if (i.faction) return K("games.heroeswac.err.picked");
		if (Object.values(r.player).some((e) => e.faction === t.faction)) return K("games.heroeswac.err.factionTaken");
		let e = structuredClone(i);
		i.faction = t.faction;
		for (let e of L[i.faction].units) e.start > 0 && (i.units[e.id] = e.start);
		if (Object.values(r.player).every((e) => e.faction)) {
			let e = r.players.length;
			r.startOrder = Array.from({ length: e }, (t, n) => r.players[(r.firstIdx - 1 - n + e * 2) % e]), r.startIdx = 0, r.phase = "start";
		}
		return Z(r, n.by, t, e, { level: null }), { state: r };
	}
	if (t.type === "startPick") {
		if (r.phase !== "start" || n.by !== r.startOrder[r.startIdx]) return q();
		let e = k[t.region];
		if (!e || !e.portal || r.removed.includes(t.region)) return K("games.heroeswac.err.notPortal");
		if (Object.values(r.player).some((e) => e.region === t.region)) return K("games.heroeswac.err.regionTaken");
		if (X(t.anyGain) !== e.any) return K("games.heroeswac.err.badAny");
		let a = structuredClone(i);
		return i.region = t.region, i.visited = [t.region], Q(i, e.res), Q(i, t.anyGain ?? {}), _e(r, t.region) === "mountain" && i.mountainVisits++, r.startIdx++, r.startIdx >= r.players.length && (r.phase = "plan"), Z(r, n.by, t, a, { level: null }), { state: r };
	}
	if (t.type === "plan") {
		if (r.phase !== "plan" || n.by !== r.players[r.firstIdx]) return q();
		let e = Object.keys(t.assign), a = Object.values(t.assign);
		if (e.length !== 4 || new Set(a).size !== 4 || !a.every((e) => e >= 1 && e <= 4)) return K("games.heroeswac.err.badPlan");
		let o = structuredClone(i);
		return r.plan = { ...t.assign }, r.boostSubs = {}, Z(r, n.by, t, o, { level: null }), r.players.filter((e) => {
			let t = r.player[e];
			return t.faction === "orcs" && J(t, "chiefhouse") && t.rage >= 1;
		}).length === 0 ? Re(r) : r.phase = "boost", { state: r };
	}
	if (t.type === "boost") {
		if (r.phase !== "boost") return q();
		if (r.boostSubs[n.by]) return K("games.heroeswac.err.already");
		if (!(i.faction === "orcs" && J(i, "chiefhouse") && i.rage >= 1)) return q();
		let e = structuredClone(i);
		if (t.action !== void 0) {
			let e = t.amount ?? 0;
			if (e < 1 || e > i.rage) return K("games.heroeswac.err.noRage");
			if (r.plan?.[t.action] === void 0) return K("games.heroeswac.err.noBoost");
			i.rage -= e, r.plan[t.action] = r.plan[t.action] + e, r.boostSubs[n.by] = {
				action: t.action,
				amount: e
			};
		} else r.boostSubs[n.by] = {};
		return Z(r, n.by, t, e, { level: null }), r.players.filter((e) => {
			let t = r.player[e];
			return t.faction === "orcs" && J(t, "chiefhouse") && t.rage >= 1;
		}).every((e) => r.boostSubs[e]) && Re(r), { state: r };
	}
	if (t.type === "build") {
		if (r.phase !== "exec" || r.exec?.action !== "build") return q();
		let e = r.exec;
		if (e.subs[n.by]) return K("games.heroeswac.err.already");
		let i = Ve(r, n.by, t);
		if (i) return i;
		if (e.subs[n.by] = t, r.players.every((t) => e.subs[t])) {
			for (let t of Le(r)) {
				let n = structuredClone(r.player[t]);
				He(r, t, e.subs[t]), Z(r, t, e.subs[t], n);
			}
			r.exec = null, r.execIdx++, ze(r);
		}
		return { state: r };
	}
	if (t.type === "move") {
		if (r.phase !== "exec" || r.exec?.action !== "move" || r.exec.stage !== "movePlan") return q();
		let e = r.exec;
		return e.moveSubs[n.by] ? K("games.heroeswac.err.already") : We(r, n.by, t) || (e.moveSubs[n.by] = t, r.players.every((t) => e.moveSubs[t]) && Ge(r, e), { state: r });
	}
	if (t.type === "declare") {
		if (r.phase !== "exec" || r.exec?.action !== "move" || r.exec.stage !== "declare") return q();
		let e = r.exec, a = e.declareRegions.find((e) => e.members.includes(n.by));
		if (!a) return K("games.heroeswac.err.notMember");
		if (e.declareSubs[n.by]) return K("games.heroeswac.err.already");
		if (t.bribe) {
			if (i.faction !== "nagas" || !J(i, "mine") || t.bribe === n.by || !a.members.includes(t.bribe)) return K("games.heroeswac.err.badDeclare");
			let e = t.bribeGive ?? {};
			if (X(e) !== 3) return K("games.heroeswac.err.badDeclare");
			if ((e.wood ?? 0) > i.wood || (e.iron ?? 0) > i.iron || (e.gold ?? 0) > i.gold) return K("games.heroeswac.err.noRes");
		}
		return e.declareSubs[n.by] = t, e.declareRegions.every((t) => t.members.every((t) => e.declareSubs[t])) && qe(r, e), { state: r };
	}
	if (t.type === "yieldDecide") {
		if (r.phase !== "exec" || r.exec?.action !== "move" || r.exec.stage !== "yield") return q();
		let e = r.exec, i = e.yieldQueue[e.yieldIdx];
		if (!i || !i.claimants.includes(n.by)) return K("games.heroeswac.err.notMember");
		if (e.yieldSubs[n.by] !== void 0) return K("games.heroeswac.err.already");
		if (e.yieldSubs[n.by] = t.stick, i.claimants.every((t) => e.yieldSubs[t] !== void 0)) {
			let t = Object.fromEntries(i.claimants.map((e) => [e, structuredClone(r.player[e])]));
			for (let n of Le(r)) i.claimants.includes(n) && Z(r, n, {
				type: "yieldDecide",
				stick: e.yieldSubs[n]
			}, t[n], {
				contextRegion: i.region,
				contextKind: i.kind
			});
			let n = i.claimants.filter((t) => e.yieldSubs[t]);
			n.length === 1 ? e.grants[`${i.region}:${i.kind}`] = n[0] : n.length >= 2 && e.battles.push({
				region: i.region,
				heroes: n,
				hydraOwners: []
			}), e.yieldIdx++, e.yieldSubs = {}, e.yieldIdx >= e.yieldQueue.length && Je(r, e);
		}
		return { state: r };
	}
	if (t.type === "deploy") {
		if (r.phase !== "exec" || r.exec?.action !== "move" || r.exec.stage !== "deploy") return q();
		let e = r.exec;
		if (!e.battles.find((e) => e.heroes.includes(n.by))) return K("games.heroeswac.err.notMember");
		if (e.deploySubs[n.by]) return K("games.heroeswac.err.already");
		if (!Ze(i, t.units)) return K("games.heroeswac.err.badDeploy");
		let a = t.armorWood ?? 0;
		if (a > 0) {
			let e = Object.values(t.units).reduce((e, t) => e + t, 0);
			if (!J(i, "armorshop") || i.wood < a || a > e) return K("games.heroeswac.err.badDeploy");
		}
		e.deploySubs[n.by] = t;
		let o = new Set(e.battles.flatMap((e) => e.heroes));
		if ([...o].every((t) => e.deploySubs[t])) {
			let t = Object.fromEntries([...o].map((e) => [e, structuredClone(r.player[e])]));
			Ye(r, e);
			for (let n of Le(r)) {
				if (!o.has(n)) continue;
				let i = e.battles.find((e) => e.heroes.includes(n))?.region, a = [...r.battleLog].reverse().find((e) => e.region === i);
				Z(r, n, e.deploySubs[n], t[n], {
					contextRegion: i,
					battle: a
				});
			}
		}
		return { state: r };
	}
	if (t.type === "reward") {
		if (r.phase !== "exec" || r.exec?.action !== "move" || r.exec.stage !== "reward") return q();
		let e = r.exec;
		if (e.rewardQueue[0] !== n.by) return q();
		let a = structuredClone(i), o = e.rewardInfo[n.by], s = L[i.faction].monsterLine;
		if (t.choice === "res") {
			let e = s[o.monster];
			if (X(t.anyGain) !== e.any) return K("games.heroeswac.err.badAny");
			Q(i, e.res), Q(i, t.anyGain ?? {});
		} else if (t.choice === "loot") {
			let e = t.victim, n = t.give ?? {};
			if (!e || !o.losers.includes(e) || o.diff <= 0 || X(n) !== o.diff) return K("games.heroeswac.err.badReward");
			let a = r.player[e];
			if ((n.wood ?? 0) > a.wood || (n.iron ?? 0) > a.iron || (n.gold ?? 0) > a.gold) return K("games.heroeswac.err.noRes");
			a.wood -= n.wood ?? 0, a.iron -= n.iron ?? 0, a.gold -= n.gold ?? 0, Q(i, n);
		} else {
			let e = t.victim, a = t.artifact;
			if (!e || !o.losers.includes(e) || !a) return K("games.heroeswac.err.badReward");
			let s = r.player[e];
			if (!s.artifacts.includes(a)) return K("games.heroeswac.err.badReward");
			let c = Ne(r, n.by, a, t.anyGain, t.curseRegions);
			if (c) return c;
			s.artifacts.splice(s.artifacts.indexOf(a), 1), i.artifacts.push(a), r.artifactOwner[a] = n.by, i.stoleArtifact = !0, Pe(r, n.by, a, t.anyGain, t.curseRegions);
		}
		return delete e.rewardInfo[n.by], e.rewardQueue.shift(), e.rewardQueue.length === 0 && (e.stage = "post"), Z(r, n.by, t, a), { state: r };
	}
	if (t.type === "post") {
		if (r.phase !== "exec" || r.exec?.action !== "move" || r.exec.stage !== "post") return q();
		let e = r.exec;
		if (e.postSubs[n.by]) return K("games.heroeswac.err.already");
		let i = Qe(r, n.by, t);
		if (i) return i;
		if (e.postSubs[n.by] = t, r.players.every((t) => e.postSubs[t])) {
			for (let t of Le(r)) {
				let n = structuredClone(r.player[t]);
				et(r, e, t, e.postSubs[t]), Z(r, t, e.postSubs[t], n, { contextRegion: r.player[t].region ?? void 0 });
			}
			r.exec = null, r.execIdx++, ze(r);
		}
		return { state: r };
	}
	return q();
}
function nt(e) {
	return {
		faction: e.faction,
		region: e.region,
		visited: e.visited,
		mountainVisits: e.mountainVisits,
		wood: e.wood,
		iron: e.iron,
		gold: e.gold,
		rage: e.rage,
		science: e.science,
		units: e.units,
		buildings: e.buildings,
		artifacts: e.artifacts,
		fortresses: e.fortresses,
		monsters: e.monsters,
		foundations: e.foundations,
		thresh: e.thresh,
		freeBuild: e.freeBuild,
		chapelOn: e.chapelOn,
		hydra: e.hydra,
		hydraSummons: e.hydraSummons,
		notes: e.notes
	};
}
function rt(e, t) {
	let n = {};
	for (let t of e.players) n[t] = nt(e.player[t]);
	let r = null, i, a = e.exec;
	if (e.phase === "exec" && a) {
		let { level: n, action: o } = e.execQueue[e.execIdx];
		if (a.action === "build") r = {
			level: n,
			action: o,
			stage: "build",
			waiting: e.players.filter((e) => !a.subs[e])
		}, i = a.subs[t];
		else {
			let s = {
				level: n,
				action: o
			};
			if (a.stage === "movePlan") r = {
				...s,
				stage: "movePlan",
				waiting: e.players.filter((e) => !a.moveSubs[e])
			}, i = a.moveSubs[t];
			else if (a.stage === "declare") r = {
				...s,
				stage: "declare",
				waiting: a.declareRegions.flatMap((e) => e.members).filter((e) => !a.declareSubs[e]),
				declareRegions: a.declareRegions,
				dests: a.dests
			}, i = {
				region: a.declareRegions.find((e) => e.members.includes(t))?.region,
				sub: a.declareSubs[t]
			};
			else if (a.stage === "yield") {
				let e = a.yieldQueue[a.yieldIdx] ?? null;
				r = {
					...s,
					stage: "yield",
					waiting: e ? e.claimants.filter((e) => a.yieldSubs[e] === void 0) : [],
					declareRegions: a.declareRegions,
					yieldItem: e,
					dests: a.dests,
					grants: a.grants
				}, i = {
					item: e,
					stick: a.yieldSubs[t]
				};
			} else a.stage === "deploy" ? (r = {
				...s,
				stage: "deploy",
				waiting: [...new Set(a.battles.flatMap((e) => e.heroes))].filter((e) => !a.deploySubs[e]),
				battles: a.battles.map((e) => ({
					region: e.region,
					participants: [...e.heroes, ...e.hydraOwners.filter((t) => !e.heroes.includes(t))],
					hydraOwners: e.hydraOwners
				})),
				dests: a.dests,
				leftover: a.leftover,
				budget: a.budget,
				stayed: a.stayed,
				grants: a.grants
			}, i = {
				region: a.battles.find((e) => e.heroes.includes(t))?.region,
				sub: a.deploySubs[t]
			}) : a.stage === "reward" ? (r = {
				...s,
				stage: "reward",
				waiting: a.rewardQueue.slice(0, 1),
				rewardQueue: a.rewardQueue,
				dests: a.dests,
				leftover: a.leftover,
				budget: a.budget,
				stayed: a.stayed,
				grants: a.grants
			}, i = { info: a.rewardInfo[t] }) : (r = {
				...s,
				stage: "post",
				waiting: e.players.filter((e) => !a.postSubs[e]),
				dests: a.dests,
				leftover: a.leftover,
				budget: a.budget,
				stayed: a.stayed,
				grants: a.grants
			}, i = a.postSubs[t]);
		}
	}
	let o = {};
	for (let [t, n] of Object.entries(e.boostSubs)) n.action !== void 0 && n.amount !== void 0 && (o[t] = {
		action: n.action,
		amount: n.amount
	});
	let s = null;
	if (e.phase === "pick") s = {
		actors: e.players,
		waiting: e.players.filter((t) => !e.player[t].faction)
	};
	else if (e.phase === "start") {
		let t = e.startOrder[e.startIdx];
		s = t ? {
			actors: [t],
			waiting: [t]
		} : null;
	} else if (e.phase === "plan") {
		let t = e.players[e.firstIdx];
		s = {
			actors: [t],
			waiting: [t]
		};
	} else if (e.phase === "boost") {
		let t = e.players.filter((t) => {
			let n = e.player[t];
			return n.faction === "orcs" && J(n, "chiefhouse") && (n.rage >= 1 || e.boostSubs[t] !== void 0);
		});
		s = {
			actors: t,
			waiting: t.filter((t) => !e.boostSubs[t])
		};
	} else if (e.phase === "exec" && a && r) {
		let t;
		t = a.action === "build" || a.stage === "movePlan" || a.stage === "post" ? e.players : a.stage === "declare" ? [...new Set(a.declareRegions.flatMap((e) => e.members))] : a.stage === "yield" ? a.yieldQueue[a.yieldIdx]?.claimants ?? [] : a.stage === "deploy" ? [...new Set(a.battles.flatMap((e) => e.heroes))] : a.rewardQueue.slice(0, 1), s = {
			actors: t,
			waiting: r.waiting
		};
	}
	return {
		public: {
			phase: e.phase,
			round: e.round,
			first: e.players[e.firstIdx],
			players: e.players,
			boards: n,
			map: {
				removed: e.removed,
				cursed: e.cursed,
				lakes: e.lakes,
				fortressOwner: e.fortressOwner,
				artifactOwner: e.artifactOwner,
				blocked: e.blocked
			},
			plan: e.plan ?? null,
			boostInfo: Object.keys(o).length > 0 ? o : null,
			startOrder: e.phase === "start" ? e.startOrder : null,
			startIdx: e.startIdx,
			exec: r,
			battleLog: e.battleLog,
			history: e.history,
			pending: s
		},
		private: { echo: i }
	};
}
function it(e, t) {
	let n = e.player[t], r = L[n.faction], i = 0;
	for (let e of n.buildings) i += R[e].vp;
	for (let e of Object.values(n.foundations)) for (let t of e) i += t;
	i += w.slice(0, n.thresh.wood).reduce((e, t) => e + t, 0), i += w.slice(0, n.thresh.iron).reduce((e, t) => e + t, 0), i += w.slice(0, n.thresh.gold).reduce((e, t) => e + t, 0), i += E.slice(0, n.thresh.rage).reduce((e, t) => e + t, 0), n.monsters.forEach((e, t) => {
		e && (i += r.monsterLine[t].vp);
	});
	for (let e of n.fortresses) i += k[e].fortress.vp;
	let a = Object.values(n.foundations).reduce((e, t) => e + t.filter((e) => e > 0).length, 0), o = n.monsters.filter(Boolean).length;
	if (n.faction === "nagas") for (let e of n.artifacts) i += ee[e].vp;
	else n.faction === "orcs" && Y(n, "bowl") && (i += 4);
	return J(n, "bank") && (i += n.freeGranted.length), n.faction === "gnomes" && Y(n, "totem") && (i += 2 * a), J(n, "tavern") && (i += o), n.faction === "humans" && Y(n, "mask") && (i += a), n.faction === "humans" && Y(n, "book") && (i += n.fortresses.length), J(n, "watch") && (i += 2 * n.fortresses.length), J(n, "druidhouse") && (i += n.artifacts.length), n.faction === "elves" && Y(n, "mask") && (i += Math.floor(n.visited.length / 2)), J(n, "temple") && (i += n.units.lich ?? 0), n.faction === "undead" && (i += e.cursed.length), J(n, "church") && (i += 2 * n.hydraSummons), J(n, "dam") && (i += O.filter((t) => !e.removed.includes(t.id) && _e(e, t.id) === "lake").length), J(n, "palace") && (i += a), J(n, "trophyhall") && (i += Math.floor(n.visited.length / 2)), n.faction === "orcs" && Y(n, "crystal") && (i += 2 * n.fortresses.length), i;
}
function at(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = it(e, n);
	let n = (t) => {
		let n = e.player[t];
		return n.wood + n.iron + n.gold + n.rage;
	}, r = [...e.players].sort((e, r) => t[r] - t[e] || n(r) - n(e)), i = r[0];
	return {
		phase: "done",
		winner: r.filter((e) => t[e] === t[i] && n(e) === n(i)),
		ranking: r,
		scores: t
	};
}
var ot = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: H,
	schemas: {
		action: le,
		publicView: he,
		privateView: ge
	},
	setup: Ie,
	reduce: tt,
	viewFor: rt,
	status: at
};
//#endregion
//#region src/games/heroeswac/icons.tsx
function $({ kind: e, size: t = 24, className: n }) {
	return /* @__PURE__ */ p("svg", {
		className: n,
		width: t,
		height: t,
		viewBox: "0 0 48 48",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.6",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		focusable: "false",
		children: {
			wood: /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("path", { d: "M8 14h22l8 7v8H16l-8-7zM12 27h20l7 6v7H19l-7-6z" }),
				/* @__PURE__ */ p("ellipse", {
					cx: "32",
					cy: "25",
					rx: "6",
					ry: "4"
				}),
				/* @__PURE__ */ p("ellipse", {
					cx: "34",
					cy: "36",
					rx: "5",
					ry: "3"
				}),
				/* @__PURE__ */ p("path", { d: "M13 18h13M17 31h12" })
			] }),
			iron: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "m8 31 5-17h22l5 17-5 6H13z" }), /* @__PURE__ */ p("path", { d: "m13 14 5 12h20M8 31h32M22 14l-4 12M15 34h19" })] }),
			gold: /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("circle", {
					cx: "24",
					cy: "24",
					r: "15"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "24",
					cy: "24",
					r: "10"
				}),
				/* @__PURE__ */ p("path", { d: "M24 5v4m0 30v4M5 24h4m30 0h4M11 11l3 3m20 20 3 3M37 11l-3 3M14 34l-3 3M28 18h-6a4 4 0 0 0 0 8h4a4 4 0 0 1 0 8h-6m4-19v22" })
			] }),
			move: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: "8",
				cy: "37",
				r: "3"
			}), /* @__PURE__ */ p("path", { d: "M13 37h6v-8h8v-8h8M29 12l10 9-10 9M7 10l6-4 6 4M13 6v13" })] }),
			build: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M8 38V16h6v-6h6v6h8v-6h6v6h6v22M5 40h38M19 38v-9a5 5 0 0 1 10 0v9M11 22h7m12 0h7" }) }),
			battle: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M9 8 38 37M39 8 10 37M7 6l10 2-8 8zM41 6 31 8l8 8zM7 34l8 8m26-8-8 8" }) }),
			journal: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M11 7h22a7 7 0 0 1 7 7v27H14a6 6 0 0 1-6-6V13a6 6 0 0 1 6-6ZM8 34h32M17 16h15M17 23h15M17 30h10" }) }),
			map: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "m5 11 12-4 14 4 12-4v29l-12 4-14-4-12 4zM17 7v29m14-25v29M23 18l7 7 6-8" }) }),
			seal: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: "24",
				cy: "24",
				r: "17"
			}), /* @__PURE__ */ p("path", { d: "m15 24 6 6 12-13" })] }),
			science: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M19 5h10m-7 0v15L12 35a5 5 0 0 0 4 8h16a5 5 0 0 0 4-8L26 20V5M17 32h14" }), /* @__PURE__ */ p("circle", {
				cx: "23",
				cy: "36",
				r: "2"
			})] }),
			rage: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M24 4c4 9-2 11 4 17 2-5 7-7 6-12 11 15 9 27-1 33H15C7 35 10 24 19 17c-1 7 3 9 5 10 3-9-3-14 0-23Z" }) }),
			notes: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M18 9v24a6 6 0 1 1-3-5V14l20-5v20a6 6 0 1 1-3-5V9z" }) }),
			hydra: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M12 38c4-8 8-9 12-7 4-2 8-1 12 7M18 31V16l-5-7-5 7m16 15V13l-5-8-5 8m16 18V16l5-7 5 7M8 17l5 3 5-3m-4-3 5 3 5-3m6 3 5 3 5-3" }) }),
			fortress: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M7 40V13h7V7h6v6h8V7h6v6h7v27M4 40h40M19 40V29a5 5 0 0 1 10 0v11M9 20h8m14 0h8" }) }),
			artifact: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M24 4 38 18 24 43 10 18zM10 18h28M17 18l7 25 7-25M16 10l8 8 8-8" }) }),
			monster: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M7 39c3-13 8-20 17-20s14 7 17 20M13 20 8 7l13 8m14 5 5-13-13 8M16 29h4m8 0h4M20 36c3 2 5 2 8 0" }) }),
			curse: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: "24",
				cy: "19",
				r: "12"
			}), /* @__PURE__ */ p("path", { d: "M17 30v8h14v-8M20 38v4m8-4v4M17 19h3m8 0h3m-8 6h2M7 7l4 4m30-4-4 4" })] }),
			plain: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: "24",
				cy: "24",
				r: "10"
			}), /* @__PURE__ */ p("path", { d: "M24 4v7m0 26v7M4 24h7m26 0h7M10 10l5 5m18 18 5 5m0-28-5 5M15 33l-5 5" })] }),
			forest: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M24 4 9 27h8l-9 12h32l-9-12h8zM24 39v6" }) }),
			mountain: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M4 40 19 9l8 16 5-9 12 24zM13 23l6 6 5-5m4 7 4-4 4 5" }) }),
			lake: /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M5 16c5 3 9 3 14 0s9-3 14 0 8 3 10 0M5 25c5 3 9 3 14 0s9-3 14 0 8 3 10 0M5 34c5 3 9 3 14 0s9-3 14 0 8 3 10 0" }) })
		}[e]
	});
}
//#endregion
//#region src/games/heroeswac/action-journal.tsx
function st(e, t) {
	return e.find((e) => e.rid === t)?.name ?? t;
}
function ct(e, t) {
	return Object.entries(e).filter(([, e]) => e > 0).map(([e, n]) => `${z[e] ? t(z[e].nameKey) : e}×${n}`).join("、");
}
function lt(e, t, n) {
	let r = e.action;
	switch (r.type) {
		case "pick": return t("games.heroeswac.ui.journal.pick", { faction: t(te[r.faction]) });
		case "startPick": return t("games.heroeswac.ui.journal.start", { region: t(B[r.region]) });
		case "plan": return t("games.heroeswac.ui.journal.plan", { sequence: Object.entries(r.assign).sort((e, t) => e[1] - t[1]).map(([e, n]) => `${n} ${t(V[e])}`).join(" → ") });
		case "boost": return r.action ? t("games.heroeswac.ui.journal.boost", {
			action: t(V[r.action]),
			amount: r.amount ?? 0
		}) : t("games.heroeswac.ui.journal.boostPass");
		case "collect": return t("games.heroeswac.ui.journal.collect", {
			action: t(V[r.resource]),
			amount: r.amount
		});
		case "build": {
			let e = [];
			return r.building && e.push(t("games.heroeswac.ui.journal.build", { building: t(R[r.building].nameKey) })), r.recruits && ct(r.recruits, t) && e.push(t("games.heroeswac.ui.journal.recruit", { units: ct(r.recruits, t) })), r.library && e.push(t("games.heroeswac.ui.journal.library")), r.illusion && e.push(t("games.heroeswac.ui.journal.illusion", { region: t(B[r.illusion.region]) })), r.curseRegion && e.push(t("games.heroeswac.ui.journal.curse", { region: t(B[r.curseRegion]) })), e.length ? e.join(" · ") : t("games.heroeswac.ui.journal.buildPass");
		}
		case "move": return r.dest === e.result.regionBefore ? t("games.heroeswac.ui.journal.stay", { region: t(B[r.dest]) }) : t("games.heroeswac.ui.journal.move", {
			from: t(B[e.result.regionBefore ?? r.dest]),
			to: t(B[r.dest])
		});
		case "declare": return [
			r.fight ? t("games.heroeswac.ui.journal.declareFight") : t("games.heroeswac.ui.journal.declarePeace"),
			[r.wantFortress && t("games.heroeswac.ui.journal.claimFortress"), r.wantArtifact && t("games.heroeswac.ui.journal.claimArtifact")].filter(Boolean).join("、"),
			r.bribe ? t("games.heroeswac.ui.journal.bribe", { name: st(n, r.bribe) }) : ""
		].filter(Boolean).join(" · ");
		case "yieldDecide": return t(r.stick ? "games.heroeswac.ui.journal.insist" : "games.heroeswac.ui.journal.yield", { region: e.contextRegion ? t(B[e.contextRegion]) : "" });
		case "deploy": return t("games.heroeswac.ui.journal.deploy", {
			region: e.contextRegion ? t(B[e.contextRegion]) : "",
			units: ct(r.units, t) || t("games.heroeswac.ui.journal.noUnits")
		});
		case "reward": return r.choice === "res" ? t("games.heroeswac.ui.journal.rewardRes") : r.choice === "loot" ? t("games.heroeswac.ui.journal.rewardLoot", { name: r.victim ? st(n, r.victim) : "" }) : t("games.heroeswac.ui.journal.rewardArtifact", { artifact: r.artifact ? t(ne[r.artifact]) : "" });
		case "post": {
			let e = [];
			return r.fortress && e.push(t("games.heroeswac.ui.journal.postFortress")), r.monster && e.push(t("games.heroeswac.ui.journal.postMonster")), r.artifact && e.push(t("games.heroeswac.ui.journal.postArtifact")), e.length ? e.join(" · ") : t("games.heroeswac.ui.journal.postPass");
		}
		case "toggleChapel": return t(r.on ? "games.heroeswac.ui.journal.chapelOn" : "games.heroeswac.ui.journal.chapelOff");
	}
}
function ut(e, t, n) {
	let r = e.result, i = [];
	for (let e of [
		"wood",
		"iron",
		"gold",
		"science",
		"rage",
		"notes"
	]) {
		let n = r.resources[e];
		if (!n) continue;
		let a = t(e === "science" ? "games.heroeswac.ui.scienceShort" : e === "rage" ? "games.heroeswac.ui.rageShort" : e === "notes" ? "games.heroeswac.ui.notesShort" : `games.heroeswac.ui.visual.${e}`);
		i.push(`${a} ${n > 0 ? "+" : "−"}${Math.abs(n)}`);
	}
	for (let [e, n] of Object.entries(r.units)) i.push(`${z[e] ? t(z[e].nameKey) : e} ${n > 0 ? "+" : "−"}${Math.abs(n)}`);
	for (let e of r.buildings) i.push(t("games.heroeswac.ui.journal.builtResult", { building: t(R[e].nameKey) }));
	for (let e of r.artifactsGained) i.push(t("games.heroeswac.ui.journal.artifactGain", { artifact: t(ne[e]) }));
	for (let e of r.artifactsLost) i.push(t("games.heroeswac.ui.journal.artifactLoss", { artifact: t(ne[e]) }));
	for (let e of r.fortresses) i.push(t("games.heroeswac.ui.journal.fortressGain", { region: t(B[e]) }));
	for (let e of r.monsters) i.push(t("games.heroeswac.ui.journal.monsterWin", { monster: t(P[e]) }));
	if (r.battle) {
		let a = r.battle.powers[e.actor] ?? 0;
		i.push(r.battle.winner === e.actor ? t("games.heroeswac.ui.journal.battleWin", { power: a }) : r.battle.winner ? t("games.heroeswac.ui.journal.battleLoss", {
			power: a,
			name: st(n, r.battle.winner)
		}) : t("games.heroeswac.ui.journal.battleTie", { power: a }));
	}
	return i;
}
function dt({ pub: e, members: t, onOpen: n, onOpenMap: r, mapActive: i = !1, journalActive: a = !1 }) {
	let o = l(), s = e.history.at(-1), c = e.pending, u = c && c.actors.length > 1 && c.waiting.length > 0 ? o("games.heroeswac.ui.journal.pendingCount", {
		done: c.actors.length - c.waiting.length,
		total: c.actors.length
	}) : s ? `${st(t, s.actor)} · ${lt(s, o, t)}` : o("games.heroeswac.ui.journal.empty");
	return /* @__PURE__ */ m("div", {
		className: "hwc-journal-ticker",
		children: [/* @__PURE__ */ m("span", {
			className: "hwc-journal-ticker__latest",
			title: u,
			children: [/* @__PURE__ */ p($, {
				kind: "seal",
				size: 18
			}), u]
		}), /* @__PURE__ */ m("div", {
			className: "hwc-journal-ticker__tools",
			children: [r && /* @__PURE__ */ m("button", {
				type: "button",
				className: i ? "is-active" : "",
				onClick: r,
				"aria-label": o("games.heroeswac.ui.journal.viewMap"),
				"aria-pressed": i,
				children: [/* @__PURE__ */ p($, {
					kind: "map",
					size: 16
				}), /* @__PURE__ */ p("span", { children: o("games.heroeswac.ui.mapLabel") })]
			}), /* @__PURE__ */ m("button", {
				type: "button",
				className: a ? "is-active" : "",
				onClick: n,
				"aria-label": o("games.heroeswac.ui.journal.allLogs"),
				"aria-pressed": a,
				children: [
					/* @__PURE__ */ p($, {
						kind: "journal",
						size: 16
					}),
					/* @__PURE__ */ p("span", { children: o("games.heroeswac.ui.journal.shortLogs") }),
					/* @__PURE__ */ p("b", { children: e.history.length })
				]
			})]
		})]
	});
}
function ft({ pub: e, members: t, open: n, onClose: r, returnTo: i = "game" }) {
	let a = l(), [o, c] = s("all"), [u, f] = s("all"), h = [...new Set(e.history.map((e) => e.round))].sort((e, t) => t - e), g = e.history.filter((e) => (o === "all" || e.round === o) && (u === "all" || e.actor === u)), _ = /* @__PURE__ */ new Map();
	for (let e of [...g].reverse()) {
		let t = `${e.round}:${e.level ?? "setup"}`;
		_.has(t) || _.set(t, []), _.get(t).push(e);
	}
	return /* @__PURE__ */ m("div", {
		className: `hwc-journal-layer${n ? " is-open" : ""}`,
		"aria-hidden": !n,
		inert: !n,
		children: [/* @__PURE__ */ p("button", {
			type: "button",
			className: "hwc-journal-layer__shade",
			onClick: r,
			tabIndex: n ? 0 : -1,
			"aria-label": a("games.heroeswac.ui.journal.close")
		}), /* @__PURE__ */ m("section", {
			className: "hwc-journal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": a("games.heroeswac.ui.journal.allLogs"),
			children: [/* @__PURE__ */ m("header", {
				className: "hwc-journal__head",
				children: [/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: a("games.heroeswac.ui.journal.title") }), /* @__PURE__ */ p("small", { children: a("games.heroeswac.ui.journal.count", { n: e.history.length }) })] }), /* @__PURE__ */ p("button", {
					type: "button",
					onClick: r,
					"aria-label": a("games.heroeswac.ui.journal.close"),
					children: "×"
				})]
			}), /* @__PURE__ */ m("div", {
				className: "hwc-journal__flow",
				children: [
					/* @__PURE__ */ m("div", {
						className: "hwc-journal__filters",
						children: [/* @__PURE__ */ m("label", { children: [/* @__PURE__ */ p("span", {
							className: "sr-only",
							children: a("games.heroeswac.ui.journal.roundFilter")
						}), /* @__PURE__ */ m("select", {
							value: o,
							onChange: (e) => c(e.target.value === "all" ? "all" : Number(e.target.value)),
							children: [/* @__PURE__ */ p("option", {
								value: "all",
								children: a("games.heroeswac.ui.journal.allRounds")
							}), h.map((e) => /* @__PURE__ */ p("option", {
								value: e,
								children: a("games.heroeswac.ui.journal.round", { n: e })
							}, e))]
						})] }), /* @__PURE__ */ m("label", { children: [/* @__PURE__ */ p("span", {
							className: "sr-only",
							children: a("games.heroeswac.ui.journal.playerFilter")
						}), /* @__PURE__ */ m("select", {
							value: u,
							onChange: (e) => f(e.target.value),
							children: [/* @__PURE__ */ p("option", {
								value: "all",
								children: a("games.heroeswac.ui.journal.allPlayers")
							}), t.map((e) => /* @__PURE__ */ p("option", {
								value: e.rid,
								children: e.name
							}, e.rid))]
						})] })]
					}),
					e.pending && e.pending.actors.length > 0 && /* @__PURE__ */ m("div", {
						className: "hwc-journal__pending",
						children: [/* @__PURE__ */ p("strong", { children: a("games.heroeswac.ui.journal.currentSubmissions") }), /* @__PURE__ */ p("div", { children: e.pending.actors.map((n) => /* @__PURE__ */ m("span", {
							className: e.pending.waiting.includes(n) ? "is-waiting" : "is-submitted",
							children: [
								st(t, n),
								" · ",
								a(e.pending.waiting.includes(n) ? "games.heroeswac.ui.journal.waiting" : "games.heroeswac.ui.journal.submitted")
							]
						}, n)) })]
					}),
					/* @__PURE__ */ m("div", {
						className: "hwc-journal__scroll",
						children: [_.size === 0 && /* @__PURE__ */ p("p", {
							className: "hwc-journal__empty",
							children: a("games.heroeswac.ui.journal.noEntries")
						}), [..._.entries()].map(([e, n]) => {
							let [r, i] = e.split(":");
							return /* @__PURE__ */ m("div", {
								className: "hwc-journal__group",
								children: [/* @__PURE__ */ p("h3", { children: i === "setup" ? a("games.heroeswac.ui.journal.groupSetup", { round: r }) : a("games.heroeswac.ui.journal.groupLevel", {
									round: r,
									level: i
								}) }), n.reverse().map((e) => {
									let n = t.find((t) => t.rid === e.actor), r = ut(e, a, t);
									return /* @__PURE__ */ m("article", {
										className: "hwc-journal__entry",
										children: [/* @__PURE__ */ p("span", {
											className: "hwc-journal__avatar",
											style: { backgroundColor: d[(n?.colorIndex ?? 0) % d.length].hex },
											children: st(t, e.actor).slice(0, 1)
										}), /* @__PURE__ */ m("div", { children: [
											/* @__PURE__ */ p("small", { children: st(t, e.actor) }),
											/* @__PURE__ */ p("strong", { children: lt(e, a, t) }),
											r.length > 0 && /* @__PURE__ */ p("p", { children: r.join(" · ") })
										] })]
									}, e.id);
								})]
							}, e);
						})]
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "hwc-journal__return",
						onClick: r,
						children: a(i === "result" ? "games.heroeswac.ui.journal.returnResult" : "games.heroeswac.ui.journal.return")
					})
				]
			})]
		})]
	});
}
//#endregion
//#region src/games/heroeswac/map-layout.ts
var pt = {
	asander: [14, 11],
	brynnlore: [24, 20],
	cerness: [43, 10],
	dortal: [10, 28],
	esmore: [30, 29],
	folen: [49, 19],
	glennfore: [85, 12],
	harrax: [16, 39],
	ikara: [23, 49],
	jorveld: [36, 47],
	kosleen: [52, 32],
	lox: [71, 31],
	morreed: [10, 52],
	nikleen: [23, 59],
	odmoor: [41, 57],
	paskaar: [59, 50],
	qliss: [84, 45],
	rolgoy: [35, 67],
	suleen: [53, 64],
	togeed: [70, 62],
	ugmat: [12, 79],
	vurt: [27, 79],
	wirs: [34, 87],
	xee: [49, 82],
	yreel: [66, 77],
	zasker: [82, 76],
	zoro: [88, 88]
}, mt = "./games/heroeswac/map.webp", ht = "./games/heroeswac/gnome-buildings.webp", gt = [
	"wood",
	"iron",
	"gold"
], _t = [
	1,
	2,
	3,
	4
], vt = {
	generator: 1,
	academy: 0,
	assemblers: 5,
	library: 3,
	workhouse: 2,
	lab: 4,
	pipeline: 1,
	plant: 2,
	bank: 0,
	factory: 5
};
function yt(e) {
	if (e <= 0) return;
	let t = {
		wood: 0,
		iron: 0,
		gold: 0
	};
	for (let n = 0; n < e; n++) t[Object.keys(t)[n % 3]]++;
	return t;
}
function bt(e, t, n) {
	let r = t.region;
	if (!r || !t.faction) return {
		cost: {},
		prev: {}
	};
	let i = j(new Set(e.map.removed)), a = new Set(e.map.blocked.filter((e) => e.kind === "portal" && e.by !== n).map((e) => e.region)), o = { [r]: 0 }, s = {}, c = [r];
	for (; c.length > 0;) {
		let n = 0;
		for (let e = 1; e < c.length; e++) o[c[e]] < o[c[n]] && (n = e);
		let r = c.splice(n, 1)[0];
		for (let n of i[r] ?? []) {
			if (k[r].portal && k[n].portal && (a.has(r) || a.has(n))) continue;
			let i = e.map.lakes.includes(n) ? "lake" : k[n].terrain, l = L[t.faction].terrainCost[i];
			i === "forest" && (t.buildings.includes("trackers") || t.buildings.includes("guidforest")) && (l = 1), i === "mountain" && (t.buildings.includes("stable") ? l = 1 : (t.faction === "humans" && t.artifacts.includes("crystal") || t.faction === "elves" && t.artifacts.includes("book")) && (l = Math.min(l, 2))), t.faction === "undead" && t.artifacts.includes("totem") && k[n].foundations && (l = 1);
			let u = o[r] + l;
			(o[n] === void 0 || u < o[n]) && (o[n] = u, s[n] = r, c.includes(n) || c.push(n));
		}
	}
	return {
		cost: o,
		prev: s
	};
}
function xt(e, t, n) {
	if (e === t) return [e];
	let r = [t];
	for (; r[0] !== e && n[r[0]];) r.unshift(n[r[0]]);
	return r[0] === e ? r : [];
}
function St({ me: e, preview: t }) {
	let n = l();
	return /* @__PURE__ */ m("div", {
		className: "hwc-resources",
		"aria-label": n("games.heroeswac.ui.myBoard"),
		children: [gt.map((r) => /* @__PURE__ */ m("span", {
			className: `hwc-resources__${r}`,
			children: [
				/* @__PURE__ */ p("b", {
					"aria-hidden": !0,
					children: /* @__PURE__ */ p($, {
						kind: r,
						size: 18
					})
				}),
				/* @__PURE__ */ p("small", { children: n(`games.heroeswac.ui.visual.${r}`) }),
				/* @__PURE__ */ p("strong", { children: e[r] }),
				t?.[r] ? /* @__PURE__ */ m("em", {
					className: e[r] < t[r] ? "is-short" : "",
					children: ["→", e[r] - t[r]]
				}) : null
			]
		}, r)), e.faction === "gnomes" && /* @__PURE__ */ m("span", {
			className: "hwc-resources__science",
			children: [
				/* @__PURE__ */ p("b", {
					"aria-hidden": !0,
					children: /* @__PURE__ */ p($, {
						kind: "science",
						size: 18
					})
				}),
				/* @__PURE__ */ p("small", { children: n("games.heroeswac.ui.scienceShort") }),
				/* @__PURE__ */ p("strong", { children: e.science })
			]
		})]
	});
}
function Ct({ pub: e, me: t, title: n, sub: r, members: i, onOpenJournal: a, onOpenMap: o, mapActive: s, journalActive: c, preview: u }) {
	let d = l();
	return /* @__PURE__ */ m("div", {
		className: "hwc-banner",
		children: [
			/* @__PURE__ */ m("div", {
				className: "hwc-banner__paper",
				children: [
					/* @__PURE__ */ m("span", {
						className: "hwc-round",
						children: [/* @__PURE__ */ p("b", { children: String(e.round).padStart(2, "0") }), /* @__PURE__ */ p("small", { children: d("games.heroeswac.ui.visual.roundShort") })]
					}),
					/* @__PURE__ */ m("div", {
						className: "hwc-banner__copy",
						children: [/* @__PURE__ */ p("strong", { children: n }), /* @__PURE__ */ p("small", { children: r })]
					}),
					/* @__PURE__ */ p("span", {
						className: "hwc-banner__emblem",
						"aria-hidden": !0,
						children: "✦"
					})
				]
			}),
			/* @__PURE__ */ p(St, {
				me: t,
				preview: u
			}),
			/* @__PURE__ */ p(dt, {
				pub: e,
				members: i,
				onOpen: a,
				onOpenMap: o,
				mapActive: s,
				journalActive: c
			})
		]
	});
}
function wt({ assign: e, setAssign: t, chosen: n, setChosen: r, canEdit: i, actions: a }) {
	let c = l(), [u, d] = s(null), h = o(null), g = o(!1), _ = (t) => S.find((n) => e[n] === t), v = (e, n) => {
		t((t) => {
			let r = { ...t }, i = S.find((e) => r[e] === n);
			return i && delete r[i], r[e] = n, r;
		}), r(null);
	};
	return /* @__PURE__ */ m("div", {
		className: "hwc-planner",
		children: [
			/* @__PURE__ */ m("div", {
				className: "hwc-planner__head",
				children: [/* @__PURE__ */ p("span", {
					className: "hwc-seal",
					children: "✦"
				}), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: c("games.heroeswac.ui.visual.planBoard") }), /* @__PURE__ */ p("small", { children: c("games.heroeswac.ui.visual.chooseAction") })] })]
			}),
			/* @__PURE__ */ p("div", {
				className: "hwc-levels",
				children: _t.map((e) => {
					let r = _(e);
					return /* @__PURE__ */ m("button", {
						type: "button",
						"data-hwc-level": e,
						disabled: !i,
						className: `hwc-level${r ? " is-filled" : ""}${(n || u) && !r ? " is-target" : ""}`,
						onClick: () => {
							if (i) {
								if (n) {
									v(n, e);
									return;
								}
								t((e) => {
									let t = { ...e };
									return r && delete t[r], t;
								});
							}
						},
						"aria-label": `${c("games.heroeswac.ui.visual.levelSlot", { n: e })} ${r ? c(V[r]) : ""}`,
						children: [
							/* @__PURE__ */ p("span", {
								className: "hwc-level__number",
								children: String(e).padStart(2, "0")
							}),
							/* @__PURE__ */ p("span", {
								className: "hwc-level__slot",
								children: r ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("b", {
									className: `hwc-level__token hwc-token--${r}`,
									"aria-hidden": !0,
									children: /* @__PURE__ */ p($, {
										kind: r,
										size: 31
									})
								}), /* @__PURE__ */ p("strong", { children: c(V[r]) })] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("i", {
									"aria-hidden": !0,
									children: "＋"
								}), /* @__PURE__ */ p("strong", { children: c(n ? V[n] : "games.heroeswac.ui.visual.emptySlot") })] })
							}),
							/* @__PURE__ */ p("span", {
								className: "hwc-level__rune",
								"aria-hidden": !0,
								children: r ? "◆" : "·"
							})
						]
					}, e);
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "hwc-stage-controls hwc-stage-controls--plan",
				children: [
					/* @__PURE__ */ p("div", {
						className: "hwc-planner__tray-title",
						children: c("games.heroeswac.ui.visual.actionTray")
					}),
					/* @__PURE__ */ p("div", {
						className: "hwc-actions-tray",
						children: S.map((t) => {
							let a = e[t] !== void 0, o = Object.keys(e).length === 4 && !a;
							return /* @__PURE__ */ m("button", {
								type: "button",
								disabled: !i || a,
								className: `hwc-action-token hwc-token--${t}${n === t ? " is-chosen" : ""}${a ? " is-placed" : ""}`,
								onPointerDown: (e) => {
									h.current = {
										action: t,
										x: e.clientX,
										y: e.clientY,
										moved: !1
									}, e.currentTarget.setPointerCapture(e.pointerId);
								},
								onPointerMove: (e) => {
									let n = h.current;
									n && n.action === t && (Math.hypot(e.clientX - n.x, e.clientY - n.y) > 8 && (n.moved = !0), n.moved && d({
										action: t,
										x: e.clientX,
										y: e.clientY
									}));
								},
								onPointerUp: (e) => {
									let n = h.current;
									if (h.current = null, d(null), !n?.moved) return;
									let r = document.elementFromPoint(e.clientX, e.clientY)?.closest("[data-hwc-level]");
									r && v(t, Number(r.dataset.hwcLevel)), g.current = !0, window.setTimeout(() => {
										g.current = !1;
									}, 0);
								},
								onPointerCancel: () => {
									h.current = null, d(null);
								},
								onClick: () => {
									g.current || r(n === t ? null : t);
								},
								children: [
									/* @__PURE__ */ p("span", {
										className: "hwc-action-token__disc",
										"aria-hidden": !0,
										children: /* @__PURE__ */ p($, {
											kind: t,
											size: 29
										})
									}),
									/* @__PURE__ */ p("b", { children: c(V[t]) }),
									o && /* @__PURE__ */ p("em", { children: c("games.heroeswac.ui.visual.unused") })
								]
							}, t);
						})
					}),
					a
				]
			}),
			u && /* @__PURE__ */ p("div", {
				className: `hwc-token-ghost hwc-token--${u.action}`,
				style: {
					left: u.x,
					top: u.y
				},
				children: /* @__PURE__ */ p($, {
					kind: u.action,
					size: 32
				})
			})
		]
	});
}
function Tt({ me: e, myRid: t, level: n, selected: r, onSelect: i, useFree: a, onFree: o, recruits: s, onRecruit: c, foundation: u, onFoundation: d, blocked: f, actions: h }) {
	let g = l(), _ = L.gnomes, v = _.buildings.find((e) => e.id === r), y = !!v && v.level > 1 && e.freeBuild.some((e) => e >= v.level), b = e.region ? k[e.region].foundations ?? 0 : 0;
	return /* @__PURE__ */ m("div", {
		className: "hwc-build-stage",
		children: [
			/* @__PURE__ */ m("div", {
				className: "hwc-build-stage__head",
				children: [/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: g("games.heroeswac.ui.visual.treeTitle") }), /* @__PURE__ */ p("small", { children: g("games.heroeswac.ui.visual.scienceTrack") })] }), /* @__PURE__ */ m("span", {
					className: "hwc-science-medal",
					children: [/* @__PURE__ */ p("b", { children: e.science }), /* @__PURE__ */ p("small", { children: g("games.heroeswac.ui.scienceShort") })]
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "hwc-build-scroll",
				children: /* @__PURE__ */ p("div", {
					className: "hwc-build-art",
					children: [
						4,
						3,
						2,
						1
					].map((t) => /* @__PURE__ */ m("div", {
						className: "hwc-build-tier",
						children: [/* @__PURE__ */ p("span", {
							className: "hwc-build-tier__level",
							children: String(t).padStart(2, "0")
						}), /* @__PURE__ */ p("div", {
							className: "hwc-build-tier__nodes",
							children: _.buildings.filter((e) => e.level === t).map((t) => {
								let a = e.buildings.includes(t.id), s = t.req.length === 0 || t.req.some((t) => e.buildings.includes(t)), c = t.level <= n, l = e.wood >= (t.cost.wood ?? 0) && e.iron >= (t.cost.iron ?? 0) && e.gold >= (t.cost.gold ?? 0), u = t.level > 1 && e.freeBuild.some((e) => e >= t.level), f = !a && s && c && (l || u), h = a ? g("games.heroeswac.ui.visual.built") : c ? s ? !l && !u ? g("games.heroeswac.ui.visual.needResources") : "" : g("games.heroeswac.ui.visual.needPrereq") : g("games.heroeswac.ui.visual.needLevel"), _ = vt[t.id] ?? 0;
								return /* @__PURE__ */ m("button", {
									type: "button",
									"aria-pressed": r === t.id,
									className: `hwc-build-node${a ? " is-built" : ""}${f ? " is-ready" : ""}${r === t.id ? " is-selected" : ""}`,
									onClick: () => {
										i(r === t.id ? null : t.id), o(!1), d(null);
									},
									children: [
										/* @__PURE__ */ p("span", {
											className: "hwc-build-node__art",
											"aria-hidden": !0,
											style: {
												backgroundImage: `url(${ht})`,
												backgroundPosition: `${_ % 3 * 50}% ${_ < 3 ? 0 : 100}%`
											}
										}),
										/* @__PURE__ */ m("span", {
											className: "hwc-build-node__top",
											children: [/* @__PURE__ */ p("b", { children: g(t.nameKey) }), /* @__PURE__ */ m("i", { children: [t.vp, "◆"] })]
										}),
										/* @__PURE__ */ p("span", {
											className: "hwc-build-node__cost",
											children: gt.filter((e) => (t.cost[e] ?? 0) > 0).map((e) => /* @__PURE__ */ m("span", {
												className: `hwc-cost--${e}`,
												children: [/* @__PURE__ */ p($, {
													kind: e,
													size: 14
												}), t.cost[e]]
											}, e))
										}),
										h && /* @__PURE__ */ p("small", { children: h })
									]
								}, t.id);
							})
						})]
					}, t))
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "hwc-stage-controls hwc-stage-controls--build",
				"data-detail": !!v,
				"data-recruits": _.units.some((t) => t.recruitedBy && e.buildings.includes(t.recruitedBy)),
				children: [
					v && /* @__PURE__ */ m("div", {
						className: "hwc-build-detail",
						children: [
							/* @__PURE__ */ p("span", {
								className: "hwc-build-detail__art",
								"aria-hidden": !0,
								style: {
									backgroundImage: `url(${ht})`,
									backgroundPosition: `${(vt[v.id] ?? 0) % 3 * 50}% ${(vt[v.id] ?? 0) < 3 ? 0 : 100}%`
								}
							}),
							/* @__PURE__ */ m("div", {
								className: "hwc-build-detail__body",
								children: [
									/* @__PURE__ */ m("strong", { children: [
										g(v.nameKey),
										" ",
										/* @__PURE__ */ m("em", { children: [v.vp, "◆"] })
									] }),
									/* @__PURE__ */ p("span", { children: g(v.descKey) }),
									/* @__PURE__ */ p("div", {
										className: "hwc-build-detail__cost",
										children: gt.filter((e) => (v.cost[e] ?? 0) > 0).map((e) => /* @__PURE__ */ m("span", { children: [
											/* @__PURE__ */ p($, {
												kind: e,
												size: 15
											}),
											g(`games.heroeswac.ui.visual.${e}`),
											" ",
											v.cost[e]
										] }, e))
									})
								]
							}),
							y && /* @__PURE__ */ m("button", {
								type: "button",
								"aria-pressed": a,
								onClick: () => o(!a),
								children: [a ? "✓ " : "◯ ", g("games.heroeswac.ui.buildFree")]
							}),
							b > 0 && /* @__PURE__ */ p("div", {
								className: "hwc-foundations",
								children: Array.from({ length: b }, (n, r) => {
									let i = e.foundations[e.region]?.[r] ?? 0, a = i >= v.level || f.some((n) => n.kind === "foundation" && n.region === e.region && n.slot === r && n.by !== t);
									return /* @__PURE__ */ m("button", {
										type: "button",
										disabled: a,
										"aria-pressed": u === r,
										onClick: () => d(u === r ? null : r),
										children: [
											g("games.heroeswac.ui.visual.foundation", { n: r + 1 }),
											" · ",
											i || "—"
										]
									}, r);
								})
							})
						]
					}),
					_.units.filter((t) => t.recruitedBy && e.buildings.includes(t.recruitedBy)).length > 0 && /* @__PURE__ */ m("div", {
						className: "hwc-recruit-rail",
						children: [/* @__PURE__ */ p("b", { children: g("games.heroeswac.ui.recruitLabel") }), _.units.filter((t) => t.recruitedBy && e.buildings.includes(t.recruitedBy)).map((t) => {
							let n = t.id === "mechanic" ? t.cost : Math.max(0, t.cost - (e.buildings.includes("pipeline") ? Math.floor(e.science / 9) : 0)), r = (s[t.id] ?? 0) > 0;
							return /* @__PURE__ */ m("span", {
								className: `hwc-recruit-rail__item${r ? " is-selected" : ""}`,
								children: [
									/* @__PURE__ */ p("button", {
										type: "button",
										onClick: () => c(t.id, -1),
										disabled: !r,
										children: "−"
									}),
									/* @__PURE__ */ m("strong", { children: [
										g(t.nameKey),
										" ×",
										s[t.id] ?? 0
									] }),
									/* @__PURE__ */ m("small", { children: [/* @__PURE__ */ p($, {
										kind: "gold",
										size: 14
									}), n] }),
									/* @__PURE__ */ p("button", {
										type: "button",
										onClick: () => c(t.id, 1),
										children: "＋"
									})
								]
							}, t.id);
						})]
					}),
					h
				]
			})
		]
	});
}
function Et({ pub: e, me: t, props: n, selected: a, onSelect: c, costs: u, prev: f, budget: h, readOnly: g = !1 }) {
	let _ = l(), [v, y] = s(1), [b, x] = s(1), S = o(null);
	i(() => {
		let e = S.current;
		if (!e) return;
		let t = () => {
			let t = window.matchMedia("(orientation: landscape)").matches;
			x(t ? Math.max(1, Math.min(e.clientWidth / 1020, e.clientHeight / 680)) : 1);
		}, n = new ResizeObserver(t);
		return n.observe(e), t(), () => n.disconnect();
	}, []);
	let C = r(() => {
		let e = S.current, n = t.region ? pt[t.region] : null;
		e && n && (e.scrollLeft = n[0] / 100 * (1020 * v * b) - e.clientWidth / 2, e.scrollTop = n[1] / 100 * (680 * v * b) - e.clientHeight / 2);
	}, [
		t.region,
		v,
		b
	]);
	i(() => {
		C();
	}, [C]);
	let w = (!g && t.region && a ? xt(t.region, a, f) : []).map((e) => pt[e].join(",")).join(" ");
	return /* @__PURE__ */ m("div", {
		className: "hwc-world",
		children: [/* @__PURE__ */ m("div", {
			className: "hwc-map-tools",
			children: [
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: C,
					"aria-label": _("games.heroeswac.ui.visual.returnToMe"),
					children: "⌖"
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => y((e) => Math.max(.8, +(e - .2).toFixed(1))),
					"aria-label": _("games.heroeswac.ui.visual.zoomOut"),
					children: "−"
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => y((e) => Math.min(1.6, +(e + .2).toFixed(1))),
					"aria-label": _("games.heroeswac.ui.visual.zoomIn"),
					children: "＋"
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "hwc-map-viewport",
			ref: S,
			children: /* @__PURE__ */ m("div", {
				className: "hwc-map-canvas",
				style: {
					width: 1020 * v * b,
					height: 680 * v * b,
					backgroundImage: `url(${mt})`
				},
				children: [w && /* @__PURE__ */ p("svg", {
					className: "hwc-map-route",
					viewBox: "0 0 100 100",
					preserveAspectRatio: "none",
					"aria-hidden": !0,
					children: /* @__PURE__ */ p("polyline", { points: w })
				}), O.filter((t) => !e.map.removed.includes(t.id)).map((r) => {
					let i = pt[r.id], o = u[r.id], s = o !== void 0 && o <= h, l = r.id === t.region, f = n.members.filter((t) => e.boards[t.rid]?.region === r.id), v = e.map.fortressOwner[r.id], y = r.artifact && e.map.artifactOwner[r.artifact];
					return /* @__PURE__ */ m("div", {
						className: "hwc-map-site",
						style: {
							left: `${i[0]}%`,
							top: `${i[1]}%`
						},
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							disabled: g,
							onClick: () => c(r.id),
							"aria-pressed": a === r.id,
							className: `hwc-map-node${g ? " is-readonly" : s ? " is-reachable" : " is-unreachable"}${l ? " is-here" : ""}${a === r.id ? " is-selected" : ""}${t.visited.includes(r.id) ? " is-visited" : ""}`,
							children: [/* @__PURE__ */ m("span", { children: [
								/* @__PURE__ */ p($, {
									kind: e.map.lakes.includes(r.id) ? "lake" : r.terrain,
									size: 14
								}),
								" ",
								_(B[r.id])
							] }), /* @__PURE__ */ m("small", { children: [
								l ? _("games.heroeswac.ui.visual.currentRegion") : g ? "" : s ? `${o}⚡` : "×",
								r.fortress && /* @__PURE__ */ m("i", { children: [/* @__PURE__ */ p($, {
									kind: "fortress",
									size: 13
								}), v ? "✓" : ""] }),
								r.artifact && /* @__PURE__ */ m("i", { children: [/* @__PURE__ */ p($, {
									kind: "artifact",
									size: 13
								}), y ? "✓" : ""] }),
								e.map.cursed.includes(r.id) && /* @__PURE__ */ p("i", { children: /* @__PURE__ */ p($, {
									kind: "curse",
									size: 13
								}) })
							] })]
						}), f.length > 0 && /* @__PURE__ */ p("div", {
							className: "hwc-map-pieces",
							children: f.map((e) => /* @__PURE__ */ p("span", {
								title: e.name,
								style: { backgroundColor: d[e.colorIndex % d.length].hex },
								children: e.name.slice(0, 1)
							}, e.rid))
						})]
					}, r.id);
				})]
			})
		})]
	});
}
function Dt({ props: e, pub: t, me: n, onOpenJournal: r, onOpenMap: i, mapActive: a, journalActive: o }) {
	let c = l(), d = t.phase === "plan" ? "plan" : t.exec?.stage === "build" ? "build" : "move", f = t.exec, h = f?.waiting.includes(e.myRid) ?? !1, g = t.phase === "plan" && t.first === e.myRid, [_, v] = s({}), [y, b] = s(null), [x, S] = s(null), [C, w] = s(!1), [T, E] = s(null), [D, ee] = s({}), [O, A] = s(null), j = d === "move" ? bt(t, n, e.myRid) : {
		cost: {},
		prev: {}
	}, M = (f?.level ?? 0) + +!!n.buildings.includes("observatory"), N = L.gnomes.buildings.find((e) => e.id === x), P = N && !C ? N.cost : {}, F = Object.entries(D).reduce((e, [t, r]) => {
		let i = L.gnomes.units.find((e) => e.id === t);
		return i ? e + r * (t === "mechanic" ? i.cost : Math.max(0, i.cost - (n.buildings.includes("pipeline") ? Math.floor(n.science / 9) : 0))) : e;
	}, 0), I = !N || !n.buildings.includes(N.id) && N.level <= (f?.level ?? 0) && (N.req.length === 0 || N.req.some((e) => n.buildings.includes(e))) && (C ? N.level > 1 && n.freeBuild.some((e) => e >= N.level) : n.wood >= (P.wood ?? 0) && n.iron >= (P.iron ?? 0) && n.gold >= (P.gold ?? 0)), R = d === "build" && h && I && n.gold >= (P.gold ?? 0) + F, z = O ? k[O] : null, te = O ? j.cost[O] : void 0, ne = d === "move" && h && te !== void 0 && te <= M, re = z && O !== n.region && !n.visited.includes(O) ? z.any + (n.buildings.includes("lab") || n.buildings.includes("townhall") ? 1 : 0) : 0, ie = c(N ? N.nameKey : "games.heroeswac.ui.buildNone"), H = e.members.find((e) => e.rid === t.first), U = c(d === "plan" ? "games.heroeswac.ui.phasePlan" : d === "build" ? "games.heroeswac.ui.stageBuild" : "games.heroeswac.ui.stageMove"), W = d === "plan" ? g : h, ae = e.members.map((e) => e.name).join(" · "), oe = () => {
		d === "plan" && g && Object.values(_).filter((e) => e !== void 0).length === 4 ? (e.send({
			type: "plan",
			assign: _
		}), v({})) : d === "build" && R ? (e.send({
			type: "build",
			building: x ?? void 0,
			useFree: N ? C : void 0,
			foundationSlot: N ? T ?? void 0 : void 0,
			recruits: Object.fromEntries(Object.entries(D).filter(([, e]) => e > 0)),
			anyGain: x === "assemblers" ? yt(9) : void 0
		}), S(null), w(!1), E(null), ee({})) : d === "move" && ne && O && (e.send({
			type: "move",
			dest: O,
			anyGain: yt(re)
		}), A(null));
	}, se = d === "plan" ? g && Object.values(_).filter((e) => e !== void 0).length === 4 : d === "build" ? R : ne, G = W ? d === "plan" ? c("games.heroeswac.ui.visual.publishPlan") : d === "build" ? ie : c("games.heroeswac.ui.visual.confirmMove") : c("games.heroeswac.ui.waiting"), ce = d === "plan" ? c("games.heroeswac.ui.visual.chooseAction") : d === "build" ? N ? `${c(N.nameKey)} · ${c("games.heroeswac.ui.visual.wood")} ${P.wood ?? 0} · ${c("games.heroeswac.ui.visual.iron")} ${P.iron ?? 0} · ${c("games.heroeswac.ui.visual.gold")} ${(P.gold ?? 0) + F}` : c("games.heroeswac.ui.buildNone") : z ? `${c(B[z.id])} · ${c("games.heroeswac.ui.visual.routeCost", {
		n: te ?? "—",
		budget: M
	})}${re ? ` · ${c("games.heroeswac.ui.visual.firstVisit")} +${re}` : ""}` : c("games.heroeswac.ui.visual.chooseDestination"), le = /* @__PURE__ */ m("div", {
		className: "hwc-action-dock",
		children: [/* @__PURE__ */ p("p", { children: ce }), /* @__PURE__ */ p("button", {
			type: "button",
			className: "btn-base hwc-primary",
			disabled: !se,
			onClick: oe,
			children: G
		})]
	});
	return /* @__PURE__ */ p(u, {
		adaptive: !0,
		className: "hwc-adaptive",
		scroll: !1,
		banner: /* @__PURE__ */ p(Ct, {
			pub: t,
			me: n,
			title: U,
			sub: W ? f ? c("games.heroeswac.ui.execLine", {
				n: f.level,
				action: c(V[f.action])
			}) : ae : c("games.heroeswac.ui.visual.waitingFor", { name: H?.name ?? "" }),
			members: e.members,
			onOpenJournal: r,
			onOpenMap: i,
			mapActive: a,
			journalActive: o,
			preview: d === "build" && N ? {
				wood: P.wood ?? 0,
				iron: P.iron ?? 0,
				gold: (P.gold ?? 0) + F
			} : void 0
		}),
		children: /* @__PURE__ */ m("div", {
			className: `hwc-scene hwc-scene--${d} hwc-stage-enter`,
			children: [
				d === "plan" && /* @__PURE__ */ p(wt, {
					assign: _,
					setAssign: v,
					chosen: y,
					setChosen: b,
					canEdit: g,
					actions: le
				}),
				d === "build" && /* @__PURE__ */ p(Tt, {
					me: n,
					myRid: e.myRid,
					level: f?.level ?? 0,
					selected: x,
					onSelect: S,
					useFree: C,
					onFree: w,
					recruits: D,
					onRecruit: (e, t) => ee((n) => ({
						...n,
						[e]: Math.max(0, (n[e] ?? 0) + t)
					})),
					foundation: T,
					onFoundation: E,
					blocked: t.map.blocked,
					actions: le
				}),
				d === "move" && /* @__PURE__ */ m("div", {
					className: "hwc-map-stage",
					children: [/* @__PURE__ */ p(Et, {
						pub: t,
						me: n,
						props: e,
						selected: O,
						onSelect: A,
						costs: j.cost,
						prev: j.prev,
						budget: M
					}), /* @__PURE__ */ p("div", {
						className: "hwc-stage-controls hwc-stage-controls--move",
						children: le
					})]
				})
			]
		}, d)
	});
}
//#endregion
//#region src/games/heroeswac/view-player.tsx
var Ot = {
	plain: "plain",
	forest: "forest",
	mountain: "mountain",
	lake: "lake"
}, kt = (e) => (e?.wood ?? 0) + (e?.iron ?? 0) + (e?.gold ?? 0);
function At(e) {
	if (e <= 0) return;
	let t = {
		wood: 0,
		iron: 0,
		gold: 0
	}, n = [
		"wood",
		"iron",
		"gold"
	];
	for (let r = 0; r < e; r++) t[n[r % 3]]++;
	return t;
}
function jt(e, t) {
	let n = 0, r = t.serpent ?? 0;
	for (let [i, a] of Object.entries(t)) {
		if (a <= 0) continue;
		if (i === "serpent") {
			n += r * a;
			continue;
		}
		let t = z[i]?.pow ?? 0;
		i === "mechasaur" && (t += Math.floor(e.science / 3)), n += t * a;
	}
	return e.buildings.includes("horn") && (n += 1), e.buildings.includes("catapult") && (n += 4), n;
}
function Mt(e, t) {
	let n = {}, r = Object.entries(e.units).filter(([, e]) => e > 0).map(([t, n]) => ({
		uid: t,
		n,
		pow: t === "serpent" ? 0 : (z[t]?.pow ?? 0) + (t === "mechasaur" ? Math.floor(e.science / 3) : 0)
	})).sort((e, t) => e.pow - t.pow);
	for (let i of r) for (let r = 0; r < i.n; r++) if (n[i.uid] = (n[i.uid] ?? 0) + 1, jt(e, n) > t) return n;
	return null;
}
function Nt({ props: e, pub: t, me: n, journalOpen: r, setJournalOpen: i, mapOpen: a, setMapOpen: o }) {
	let s = l();
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
		className: `hwc-map-preview${a ? " is-open" : ""}`,
		"aria-hidden": !a,
		inert: !a,
		children: [/* @__PURE__ */ p(Et, {
			pub: t,
			me: n,
			props: e,
			selected: null,
			onSelect: () => {},
			costs: {},
			prev: {},
			budget: 0,
			readOnly: !0
		}), /* @__PURE__ */ m("div", {
			className: "hwc-map-preview__head",
			children: [
				/* @__PURE__ */ p($, {
					kind: "map",
					size: 18
				}),
				/* @__PURE__ */ p("span", { children: s("games.heroeswac.ui.mapLabel") }),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => o(!1),
					children: s("games.heroeswac.ui.journal.backFromMap")
				})
			]
		})]
	}), /* @__PURE__ */ p(ft, {
		pub: t,
		members: e.members,
		open: r,
		onClose: () => i(!1)
	})] });
}
function Pt(e) {
	let t = e.public, n = e.private, { members: r, myRid: i, send: a } = e, o = l(), c = t.boards[i], d = (e) => r.find((t) => t.rid === e)?.name ?? e, [f, h] = s({ recruits: {} }), [g, _] = s({
		fight: !1,
		wantFortress: !1,
		wantArtifact: !1
	}), [v, y] = s(0), [b, x] = s({}), [S, C] = s(!1), [w, T] = s(null), E = t.exec, D = E?.waiting.includes(i) ?? !1, A = E?.action === "move" && E.stage === "movePlan", M = `${t.phase}:${E?.action ?? ""}:${E?.stage ?? ""}:${E?.level ?? ""}`, N = !A && w === M, F = (e) => T(e ? M : null), I = () => {
		F(!1), C(!0);
	}, re = () => {
		C(!1), F(!N && !A);
	};
	if (!c) return null;
	if (t.phase === "plan" || t.phase === "exec" && (c.faction === "gnomes" && E?.action === "build" && E.stage === "build" || c.faction && [
		"gnomes",
		"humans",
		"elves",
		"orcs"
	].includes(c.faction) && E?.action === "move" && E.stage === "movePlan")) return /* @__PURE__ */ m("div", {
		className: "hwc-root",
		children: [/* @__PURE__ */ p(Dt, {
			props: e,
			pub: t,
			me: c,
			onOpenJournal: I,
			onOpenMap: re,
			mapActive: !S && (A || N),
			journalActive: S
		}), /* @__PURE__ */ p(Nt, {
			props: e,
			pub: t,
			me: c,
			journalOpen: S,
			setJournalOpen: C,
			mapOpen: N,
			setMapOpen: F
		})]
	});
	let ie = t.phase === "pick" ? o("games.heroeswac.ui.phasePick") : t.phase === "start" ? o("games.heroeswac.ui.phaseStart") : t.phase === "boost" ? o("games.heroeswac.ui.phaseBoost") : o("games.heroeswac.ui.phaseExec"), H = c.faction ? L[c.faction] : null, U = (() => {
		if (t.phase !== "exec" || !E || E.action !== "build" || E.stage !== "build" || !D || !H) return null;
		let e = c.faction === "elves" && c.buildings.includes("woodedcliff"), n = c.faction === "elves" && c.artifacts.includes("grail"), r = (t) => {
			let r = R[t];
			return {
				w: e ? 0 : r.cost.wood ?? 0,
				i: r.cost.iron ?? 0,
				g: n ? 0 : r.cost.gold ?? 0,
				r: r.cost.rage ?? 0,
				s: r.cost.serpents ?? 0
			};
		}, i = (e) => {
			let t = r(e);
			return c.wood >= t.w && c.iron >= t.i && c.gold >= t.g && c.rage >= t.r && (c.units.serpent ?? 0) >= t.s;
		}, s = (e) => {
			let t = z[e].cost;
			return c.faction === "gnomes" && c.buildings.includes("pipeline") && e !== "mechanic" && (t = Math.max(0, t - Math.floor(c.science / 9))), c.faction === "humans" && c.buildings.includes("cathedral") && (e === "cuirassier" && (t = 2), e === "archmage" && (t = 3)), t;
		}, l = Object.entries(f.recruits).reduce((e, [t, n]) => e + s(t) * n, 0), u = f.building && !f.useFree ? r(f.building) : {
			w: 0,
			i: 0,
			g: 0,
			r: 0,
			s: 0
		}, d = c.gold - u.g - l, g = !f.building || f.useFree || c.wood >= u.w && c.iron >= u.i && c.rage >= u.r && (c.units.serpent ?? 0) >= u.s, _ = (e) => e > 1 && c.freeBuild.some((t) => t >= e);
		return /* @__PURE__ */ m("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ p("p", {
					className: "text-sm font-semibold",
					children: o("games.heroeswac.ui.stageBuild")
				}),
				/* @__PURE__ */ p("div", {
					className: "grid grid-cols-2 gap-1",
					children: H.buildings.map((e) => {
						let t = c.buildings.includes(e.id), n = e.req.length === 0 || e.req.some((e) => c.buildings.includes(e)), r = e.level <= E.level, a = !t && n && r && i(e.id), s = !t && n && r && _(e.level), l = f.building === e.id;
						return /* @__PURE__ */ m("button", {
							type: "button",
							disabled: !a && !s,
							"aria-pressed": l,
							onClick: () => h((t) => ({
								...t,
								building: l ? void 0 : e.id,
								useFree: !a && s
							})),
							title: o(e.descKey),
							className: `hwc-build-choice rounded-lg border p-2 text-left text-xs ${l ? "is-selected" : ""} ${!a && !s ? "opacity-40" : ""}`,
							children: [/* @__PURE__ */ m("div", {
								className: "font-semibold",
								children: [
									o(e.nameKey),
									" · L",
									e.level
								]
							}), /* @__PURE__ */ p("div", {
								className: "text-slate-500",
								children: o(e.descKey)
							})]
						}, e.id);
					})
				}),
				H.units.some((e) => e.recruitedBy && c.buildings.includes(e.recruitedBy)) && /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("p", {
					className: "text-xs font-semibold text-slate-600",
					children: o("games.heroeswac.ui.recruitLabel")
				}), /* @__PURE__ */ p("div", {
					className: "flex flex-wrap gap-1",
					children: H.units.filter((e) => e.recruitedBy && c.buildings.includes(e.recruitedBy)).map((e) => {
						let t = s(e.id), n = f.recruits[e.id] ?? 0;
						return /* @__PURE__ */ m("span", {
							className: `hwc-recruit-choice inline-flex items-center gap-1 rounded-lg border px-1 text-xs${n > 0 ? " is-selected" : ""}`,
							children: [
								/* @__PURE__ */ p("button", {
									type: "button",
									className: "min-h-11 min-w-11",
									disabled: n <= 0,
									onClick: () => h((t) => ({
										...t,
										recruits: {
											...t.recruits,
											[e.id]: Math.max(0, (t.recruits[e.id] ?? 0) - 1)
										}
									})),
									children: "−"
								}),
								/* @__PURE__ */ m("span", { children: [
									o(e.nameKey),
									" ×",
									n,
									"(",
									/* @__PURE__ */ p($, {
										kind: "gold",
										size: 14
									}),
									t,
									")"
								] }),
								/* @__PURE__ */ p("button", {
									type: "button",
									className: "min-h-11 min-w-11",
									disabled: t <= 0 || t > d,
									onClick: () => h((t) => ({
										...t,
										recruits: {
											...t.recruits,
											[e.id]: (t.recruits[e.id] ?? 0) + 1
										}
									})),
									children: "+"
								})
							]
						}, e.id);
					})
				})] }),
				/* @__PURE__ */ p("button", {
					type: "button",
					disabled: !g || d < 0,
					onClick: () => {
						let e = {
							type: "build",
							building: f.building,
							useFree: f.useFree,
							recruits: Object.fromEntries(Object.entries(f.recruits).filter(([, e]) => e > 0)),
							anyGain: f.building === "assemblers" ? At(9) : void 0
						};
						a(e), h({ recruits: {} });
					},
					className: "min-h-12 w-full rounded-xl bg-violet-600 text-white font-semibold disabled:opacity-40",
					children: f.building ? o(R[f.building].nameKey) : o("games.heroeswac.ui.buildNone")
				})
			]
		});
	})(), W = (() => {
		if (t.phase !== "exec" || !E || E.action !== "move" || E.stage !== "movePlan" || !D || !H || !c.region) return null;
		let e = E.level + +!!c.buildings.includes("observatory"), n = j(new Set(t.map.removed)), r = [c.region, ...n[c.region] ?? []];
		return /* @__PURE__ */ m("div", {
			className: "space-y-2",
			children: [/* @__PURE__ */ m("p", {
				className: "text-sm font-semibold",
				children: [
					o("games.heroeswac.ui.stageMove"),
					" · ",
					o("games.heroeswac.ui.moveBudget", { n: e })
				]
			}), /* @__PURE__ */ p("div", {
				className: "grid grid-cols-2 gap-1",
				children: r.map((e) => {
					let t = k[e], n = !c.visited.includes(e), r = e !== c.region && n ? t.any + (c.buildings.includes("townhall") || c.buildings.includes("lab") ? 1 : 0) : 0;
					return /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => a({
							type: "move",
							dest: e,
							anyGain: At(r)
						}),
						className: "min-h-12 rounded-lg border border-slate-300 bg-white p-2 text-left text-xs",
						children: [
							e === c.region ? o("games.heroeswac.ui.stay") : o(B[e]),
							" ",
							/* @__PURE__ */ p($, {
								kind: Ot[t.terrain],
								size: 16
							}),
							n && e !== c.region && /* @__PURE__ */ m("span", {
								className: "text-emerald-600",
								children: [" +", kt(t.res) + t.any]
							})
						]
					}, e);
				})
			})]
		});
	})(), ae = (() => {
		if (t.phase !== "exec" || !E || E.stage !== "declare" || !D) return null;
		let e = E.declareRegions?.find((e) => e.members.includes(i));
		if (!e) return null;
		let n = k[e.region];
		return /* @__PURE__ */ m("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ m("p", {
					className: "text-sm font-semibold",
					children: [
						o("games.heroeswac.ui.stageDeclare"),
						" · ",
						o(B[e.region])
					]
				}),
				/* @__PURE__ */ p("p", {
					className: "text-xs text-slate-600",
					children: o("games.heroeswac.ui.declarePrompt")
				}),
				/* @__PURE__ */ m("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => _((e) => ({
								...e,
								fight: !e.fight
							})),
							className: `min-h-11 flex-1 rounded-lg border text-sm ${g.fight ? "border-rose-600 bg-rose-50 text-rose-700" : "border-slate-300 bg-white"}`,
							children: o("games.heroeswac.ui.declareFight")
						}),
						n.fortress && !t.map.fortressOwner[e.region] && /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => _((e) => ({
								...e,
								wantFortress: !e.wantFortress
							})),
							className: `min-h-11 flex-1 rounded-lg border text-sm ${g.wantFortress ? "border-amber-600 bg-amber-50 text-amber-700" : "border-slate-300 bg-white"}`,
							children: o("games.heroeswac.ui.wantFortress")
						}),
						n.artifact && !t.map.artifactOwner[n.artifact] && /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => _((e) => ({
								...e,
								wantArtifact: !e.wantArtifact
							})),
							className: `min-h-11 flex-1 rounded-lg border text-sm ${g.wantArtifact ? "border-amber-600 bg-amber-50 text-amber-700" : "border-slate-300 bg-white"}`,
							children: o("games.heroeswac.ui.wantArtifact")
						})
					]
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => a({
						type: "declare",
						fight: g.fight,
						wantFortress: g.wantFortress,
						wantArtifact: g.wantArtifact
					}),
					className: "min-h-12 w-full rounded-xl bg-violet-600 text-white font-semibold",
					children: g.fight ? o("games.heroeswac.ui.declareFight") : o("games.heroeswac.ui.declarePeace")
				})
			]
		});
	})(), oe = t.phase !== "exec" || !E || E.stage !== "yield" || !D || !E.yieldItem?.claimants.includes(i) ? null : /* @__PURE__ */ m("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ p("p", {
				className: "text-sm font-semibold",
				children: o("games.heroeswac.ui.stageYield")
			}),
			/* @__PURE__ */ p("p", {
				className: "text-xs text-slate-600",
				children: o("games.heroeswac.ui.yieldPrompt")
			}),
			/* @__PURE__ */ m("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => a({
						type: "yieldDecide",
						stick: !1
					}),
					className: "min-h-12 flex-1 rounded-xl border border-slate-300 bg-white font-semibold",
					children: o("games.heroeswac.ui.yieldGive")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => a({
						type: "yieldDecide",
						stick: !0
					}),
					className: "min-h-12 flex-1 rounded-xl bg-rose-600 text-white font-semibold",
					children: o("games.heroeswac.ui.yieldStick")
				})]
			})
		]
	}), se = (() => {
		if (t.phase !== "exec" || !E || E.stage !== "deploy" || !D) return null;
		let e = E.battles?.find((e) => e.participants.includes(i));
		if (!e) return null;
		let n = {};
		for (let [e, t] of Object.entries(c.units)) t > 0 && (n[e] = t);
		return /* @__PURE__ */ m("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ m("p", {
					className: "text-sm font-semibold",
					children: [
						o("games.heroeswac.ui.stageDeploy"),
						" · ",
						o(B[e.region])
					]
				}),
				/* @__PURE__ */ p("p", {
					className: "text-xs text-slate-600",
					children: o("games.heroeswac.ui.deployPrompt")
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => a({
						type: "deploy",
						units: n
					}),
					className: "min-h-12 w-full rounded-xl bg-rose-600 text-white font-semibold",
					children: [
						o("games.heroeswac.ui.deployAll"),
						"(",
						jt(c, n),
						")"
					]
				})
			]
		});
	})(), G = (() => {
		if (t.phase !== "exec" || !E || E.stage !== "reward" || E.rewardQueue?.[0] !== i) return null;
		let e = n?.echo?.info;
		if (!e || !H) return null;
		let r = H.monsterLine[e.monster], s = e.losers.find((n) => {
			let r = t.boards[n];
			return r && r.wood + r.iron + r.gold >= e.diff;
		}), l = e.losers.flatMap((e) => (t.boards[e]?.artifacts ?? []).map((t) => ({
			victim: e,
			art: t
		})));
		return /* @__PURE__ */ m("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ p("p", {
					className: "text-sm font-semibold",
					children: o("games.heroeswac.ui.stageReward")
				}),
				/* @__PURE__ */ p("p", {
					className: "text-xs text-slate-600",
					children: o("games.heroeswac.ui.rewardPrompt")
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => a({
						type: "reward",
						choice: "res",
						anyGain: At(r.any)
					}),
					className: "min-h-12 w-full rounded-xl bg-violet-600 text-white font-semibold",
					children: [
						o("games.heroeswac.ui.rewardRes"),
						"(",
						kt(r.res) + r.any,
						")"
					]
				}),
				s && e.diff > 0 && /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => {
						let n = t.boards[s], r = {
							wood: 0,
							iron: 0,
							gold: 0
						}, i = e.diff;
						for (let e of [
							"wood",
							"iron",
							"gold"
						]) {
							let t = Math.min(i, n[e]);
							r[e] = t, i -= t;
						}
						a({
							type: "reward",
							choice: "loot",
							victim: s,
							give: r
						});
					},
					className: "min-h-12 w-full rounded-xl border border-slate-300 bg-white font-semibold",
					children: o("games.heroeswac.ui.rewardLoot", {
						name: d(s),
						n: e.diff
					})
				}),
				l.map(({ victim: e, art: n }) => {
					let r = c.faction === "gnomes" && n === "book" ? 9 : (c.faction === "humans" || c.faction === "undead") && n === "grail" ? 8 : 0, i = c.faction === "undead" && (n === "mask" || n === "book"), s = i ? O.filter((e) => !t.map.removed.includes(e.id) && !t.map.cursed.includes(e.id)).slice(0, 3).map((e) => e.id) : void 0;
					return i && (s?.length ?? 0) < 3 ? null : /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => a({
							type: "reward",
							choice: "artifact",
							victim: e,
							artifact: n,
							anyGain: At(r),
							curseRegions: s
						}),
						className: "min-h-12 w-full rounded-xl border border-slate-300 bg-white font-semibold",
						children: [
							o("games.heroeswac.ui.rewardArtifact"),
							" · ",
							o(ne[n]),
							"(",
							d(e),
							")"
						]
					}, `${e}:${n}`);
				})
			]
		});
	})(), ce = (() => {
		if (t.phase !== "exec" || !E || E.action !== "move" || E.stage !== "post" || !D || !c.region || !H) return null;
		let e = c.region, n = k[e], r = E.grants ?? {}, s = Object.values(t.boards).filter((t) => t.region === e).length === 1, l = t.battleLog.some((t) => t.region === e && t.winner === i), u = (t) => s || l || r[`${e}:${t}`] === i, d = E.leftover?.[i] ?? 0, f = !!n.fortress && !t.map.fortressOwner[e] && u("fortress") && Mt(c, n.fortress.pow) !== null, h = H.monsterLine, g = [];
		c.monsters.forEach((e, t) => {
			e || g.push(t);
		});
		let _ = c.buildings.includes("shrine") && (E.stayed?.[i] ?? !1), v = g.map((e, t) => ({
			target: e,
			skip: t
		})).filter((e) => (_ || e.skip <= d) && Mt(c, h[e.target].pow) !== null), y = n.artifact, S = (() => {
			if (!y || t.map.artifactOwner[y] || !u("artifact")) return !1;
			let e = ee[y];
			return c.faction === "nagas" ? (c.units.serpent ?? 0) >= 3 : e.cond.kind === "pay" ? c[e.cond.res] >= e.cond.amount : e.cond.kind === "foundations" ? Object.values(c.foundations).reduce((e, t) => e + t.filter((e) => e > 0).length, 0) >= e.cond.amount : e.cond.kind === "victories" ? c.fortresses.length + c.monsters.filter(Boolean).length >= e.cond.amount : c.mountainVisits >= e.cond.amount;
		})();
		return /* @__PURE__ */ m("div", {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ m("p", {
					className: "text-sm font-semibold",
					children: [
						o("games.heroeswac.ui.stagePost"),
						" · ",
						o(B[e])
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "flex flex-wrap gap-1",
					children: [
						f && n.fortress && /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => x((e) => ({
								...e,
								fortress: !e.fortress,
								artifact: e.fortress ? e.artifact : !1
							})),
							className: `min-h-11 rounded-lg border px-3 text-xs ${b.fortress ? "border-violet-600 bg-violet-50" : "border-slate-300 bg-white"}`,
							children: o("games.heroeswac.ui.postFortress", { n: n.fortress.pow })
						}),
						v.map((e) => /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => x((t) => ({
								...t,
								monster: t.monster === e.target ? void 0 : e.target
							})),
							className: `min-h-11 rounded-lg border px-3 text-xs ${b.monster === e.target ? "border-violet-600 bg-violet-50" : "border-slate-300 bg-white"}`,
							children: o("games.heroeswac.ui.postMonster", {
								name: o(P[e.target]),
								n: h[e.target].pow
							})
						}, e.target)),
						S && y && !b.fortress && /* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => x((e) => ({
								...e,
								artifact: !e.artifact
							})),
							className: `min-h-11 rounded-lg border px-3 text-xs ${b.artifact ? "border-violet-600 bg-violet-50" : "border-slate-300 bg-white"}`,
							children: [
								o("games.heroeswac.ui.postArtifact"),
								" · ",
								o(ne[y])
							]
						})
					]
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => {
						let e = { type: "post" };
						if (b.fortress && n.fortress && (e.fortress = {
							units: Mt(c, n.fortress.pow),
							anyGain: At(n.fortress.any)
						}), b.monster !== void 0) {
							let t = v.find((e) => e.target === b.monster);
							t && (e.monster = {
								skip: _ ? void 0 : t.skip,
								target: _ ? t.target : void 0,
								units: Mt(c, h[t.target].pow),
								anyGain: At(h[t.target].any + (c.buildings.includes("market") ? 2 : 0))
							});
						}
						if (b.artifact && y) {
							let n = c.faction === "gnomes" && y === "book" ? 9 : (c.faction === "humans" || c.faction === "undead") && y === "grail" ? 8 : 0, r = c.faction === "undead" && (y === "mask" || y === "book"), i = r ? O.filter((e) => !t.map.removed.includes(e.id) && !t.map.cursed.includes(e.id)).slice(0, 3).map((e) => e.id) : void 0;
							(!r || (i?.length ?? 0) >= 3) && (e.artifact = {
								anyGain: At(n),
								curseRegions: i
							});
						}
						a(e), x({});
					},
					className: "min-h-12 w-full rounded-xl bg-violet-600 text-white font-semibold",
					children: b.fortress || b.monster !== void 0 || b.artifact ? o("games.heroeswac.ui.submit") : o("games.heroeswac.ui.postSkip")
				})
			]
		});
	})(), le = t.phase !== "boost" || !c.buildings.includes("chiefhouse") || c.rage < 1 || v === t.round || !t.plan ? null : /* @__PURE__ */ m("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ p("p", {
			className: "text-xs text-slate-600",
			children: o("games.heroeswac.ui.boostPrompt")
		}), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap gap-1",
			children: [Object.keys(t.plan).map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => {
					a({
						type: "boost",
						action: e,
						amount: 1
					}), y(t.round);
				},
				className: "min-h-11 rounded-lg border border-amber-500 bg-amber-50 px-3 text-xs font-semibold text-amber-700",
				children: o("games.heroeswac.ui.boostPlus", { action: o(V[e]) })
			}, e)), /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => {
					a({ type: "boost" }), y(t.round);
				},
				className: "min-h-11 rounded-lg border border-slate-300 bg-white px-3 text-xs",
				children: o("games.heroeswac.ui.boostPass")
			})]
		})]
	}), ue = t.phase === "pick" && !c.faction && /* @__PURE__ */ p("div", {
		className: "grid grid-cols-2 gap-2",
		children: Object.values(L).map((e) => {
			let n = Object.values(t.boards).some((t) => t.faction === e.id);
			return /* @__PURE__ */ m("button", {
				type: "button",
				disabled: n,
				onClick: () => a({
					type: "pick",
					faction: e.id
				}),
				className: "min-h-12 rounded-xl border border-slate-300 bg-white p-2 text-left disabled:opacity-40",
				style: {
					borderLeftColor: e.color,
					borderLeftWidth: 4
				},
				children: [/* @__PURE__ */ p("div", {
					className: "font-semibold text-sm",
					children: o(te[e.id])
				}), /* @__PURE__ */ p("div", {
					className: "text-xs text-slate-500",
					children: o(e.descKey)
				})]
			}, e.id);
		})
	}), de = t.phase === "start" && !c.region && (t.startOrder?.[t.startIdx] === i ? /* @__PURE__ */ m("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ p("p", {
			className: "text-sm text-slate-600",
			children: o("games.heroeswac.ui.startPrompt")
		}), /* @__PURE__ */ p("div", {
			className: "grid grid-cols-2 gap-1",
			children: O.filter((e) => e.portal && !t.map.removed.includes(e.id) && !Object.values(t.boards).some((t) => t.region === e.id)).map((e) => /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => a({
					type: "startPick",
					region: e.id,
					anyGain: At(e.any)
				}),
				className: "min-h-12 rounded-lg border border-slate-300 bg-white p-2 text-left text-xs",
				children: [
					o(B[e.id]),
					" ",
					/* @__PURE__ */ p($, {
						kind: Ot[e.terrain],
						size: 16
					})
				]
			}, e.id))
		})]
	}) : /* @__PURE__ */ p("p", {
		className: "text-sm text-slate-600",
		children: o("games.heroeswac.ui.startWait", { name: d(t.startOrder?.[t.startIdx] ?? t.first) })
	}));
	return /* @__PURE__ */ m("div", {
		className: "hwc-root",
		children: [/* @__PURE__ */ p("div", {
			className: "hwc-legacy",
			children: /* @__PURE__ */ p(u, {
				adaptive: !0,
				scroll: !1,
				className: "hwc-adaptive",
				banner: /* @__PURE__ */ p(Ct, {
					pub: t,
					me: c,
					title: ie,
					sub: E ? o("games.heroeswac.ui.execLine", {
						n: E.level,
						action: o(V[E.action])
					}) : r.map((e) => e.name).join(" · "),
					members: r,
					onOpenJournal: I,
					onOpenMap: re,
					mapActive: !S && (A || N),
					journalActive: S
				}),
				children: /* @__PURE__ */ m("div", {
					className: "hwc-legacy-layout",
					children: [/* @__PURE__ */ p("div", {
						className: "hwc-legacy-map",
						children: /* @__PURE__ */ p(Et, {
							pub: t,
							me: c,
							props: e,
							selected: null,
							onSelect: () => {},
							costs: {},
							prev: {},
							budget: 0,
							readOnly: !0
						})
					}), /* @__PURE__ */ m("div", {
						className: "hwc-legacy-controls",
						children: [/* @__PURE__ */ m("div", {
							className: "hwc-legacy__body hwc-stage-enter space-y-3 p-2",
							children: [
								c.faction && /* @__PURE__ */ m("div", {
									className: "rounded-xl border border-slate-200 bg-white p-2 text-xs",
									children: [
										/* @__PURE__ */ m("div", {
											className: "flex flex-wrap items-center gap-x-3 gap-y-1 font-mono",
											children: [
												/* @__PURE__ */ p("span", {
													className: "font-semibold",
													style: { color: L[c.faction].color },
													children: o(te[c.faction])
												}),
												/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
													kind: "wood",
													size: 15
												}), c.wood] }),
												/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
													kind: "iron",
													size: 15
												}), c.iron] }),
												/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
													kind: "gold",
													size: 15
												}), c.gold] }),
												c.faction === "gnomes" && /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
													kind: "science",
													size: 15
												}), c.science] }),
												c.faction === "orcs" && /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
													kind: "rage",
													size: 15
												}), c.rage] }),
												c.faction === "nagas" && /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
													kind: "notes",
													size: 15
												}), c.notes] }),
												c.hydra && /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
													kind: "hydra",
													size: 15
												}), o(B[c.hydra])] })
											]
										}),
										/* @__PURE__ */ m("div", {
											className: "mt-1 flex flex-wrap gap-1",
											children: [
												Object.entries(c.units).filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ m("span", {
													className: "rounded bg-slate-100 px-1.5 py-0.5",
													children: [
														o(z[e].nameKey),
														"×",
														t
													]
												}, e)),
												c.buildings.map((e) => /* @__PURE__ */ p("span", {
													className: "rounded bg-violet-50 px-1.5 py-0.5 text-violet-700",
													title: o(R[e].descKey),
													children: o(R[e].nameKey)
												}, e)),
												c.artifacts.map((e) => /* @__PURE__ */ p("span", {
													className: "rounded bg-amber-50 px-1.5 py-0.5 text-amber-700",
													children: o(ne[e])
												}, e))
											]
										}),
										c.faction === "undead" && c.buildings.includes("chapel") && /* @__PURE__ */ m("button", {
											type: "button",
											onClick: () => a({
												type: "toggleChapel",
												on: !c.chapelOn
											}),
											className: "mt-1 min-h-8 rounded-lg border border-slate-300 px-2",
											children: [
												o("games.heroeswac.ui.chapelToggle"),
												":",
												/* @__PURE__ */ p($, {
													kind: c.chapelOn ? "seal" : "curse",
													size: 16
												})
											]
										})
									]
								}),
								ue,
								de,
								le,
								U,
								W,
								ae,
								oe,
								se,
								G,
								ce
							]
						}, `${t.phase}:${E?.stage ?? "none"}:${E?.level ?? 0}`), /* @__PURE__ */ m("div", {
							className: "hwc-action-dock",
							children: [/* @__PURE__ */ p("p", { children: ie }), /* @__PURE__ */ p("span", {
								className: "hwc-legacy__hint",
								children: o(D ? "games.heroeswac.ui.visual.selectAbove" : "games.heroeswac.ui.waiting")
							})]
						})]
					})]
				})
			})
		}), /* @__PURE__ */ p(Nt, {
			props: e,
			pub: t,
			me: c,
			journalOpen: S,
			setJournalOpen: C,
			mapOpen: N,
			setMapOpen: F
		})]
	});
}
//#endregion
//#region src/games/heroeswac/bot.ts
var Ft = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, It = (e) => e[Math.floor(Ft() * e.length)], Lt = (e) => (e?.wood ?? 0) + (e?.iron ?? 0) + (e?.gold ?? 0);
function Rt(e, t) {
	if (t <= 0) return;
	let n = {
		wood: 0,
		iron: 0,
		gold: 0
	};
	for (let r = 0; r < t; r++) {
		let t = [
			"wood",
			"iron",
			"gold"
		].reduce((t, r) => e[t] + n[t] <= e[r] + n[r] ? t : r);
		n[t]++;
	}
	return n;
}
function zt(e, t) {
	let n = 0, r = t.serpent ?? 0;
	for (let [i, a] of Object.entries(t)) {
		if (a <= 0) continue;
		if (i === "serpent") {
			n += r * a;
			continue;
		}
		let t = z[i];
		if (!t) continue;
		let o = t.pow;
		i === "mechasaur" && (o += Math.floor(e.science / 3)), n += o * a;
	}
	return e.buildings.includes("horn") && (n += 1), e.buildings.includes("catapult") && (n += 4), n;
}
function Bt(e, t) {
	let n = {}, r = Object.entries(e.units).filter(([, e]) => e > 0).map(([t, n]) => ({
		uid: t,
		n,
		pow: t === "serpent" ? 0 : (z[t]?.pow ?? 0) + (t === "mechasaur" ? Math.floor(e.science / 3) : 0)
	})).sort((e, t) => e.pow - t.pow);
	for (let i of r) for (let r = 0; r < i.n; r++) if (n[i.uid] = (n[i.uid] ?? 0) + 1, zt(e, n) > t) return n;
	return null;
}
function Vt(e, t) {
	let n = new Set(Object.values(e.boards).map((e) => e.faction)), r = x.filter((e) => !n.has(e));
	return t ? It(r) : r[0];
}
function Ht(e, t) {
	let n = new Set(Object.values(e.boards).map((e) => e.region)), r = O.filter((t) => t.portal && !e.map.removed.includes(t.id) && !n.has(t.id));
	if (r.length === 0) return null;
	let i = t ? It(r) : r.reduce((e, t) => Lt(e.res) + e.any >= Lt(t.res) + t.any ? e : t), a = e.boards[e.startOrder[e.startIdx]];
	return {
		type: "startPick",
		region: i.id,
		anyGain: Rt(a, i.any)
	};
}
function Ut(e, t) {
	let n = [...S];
	if (t) {
		let e = n.sort(() => Ft() - .5).slice(0, 4), t = [
			1,
			2,
			3,
			4
		].sort(() => Ft() - .5);
		return Object.fromEntries(e.map((e, n) => [e, t[n]]));
	}
	let r = [
		"wood",
		"iron",
		"gold"
	].slice().sort((t, n) => e[t] - e[n]);
	return {
		build: 4,
		move: 2,
		[r[0]]: 3,
		[r[1]]: 1
	};
}
function Wt(e, t, n) {
	let r = e.exec.level, i = L[t.faction], a = t.faction === "elves" && t.buildings.includes("woodedcliff"), o = t.faction === "elves" && t.artifacts.includes("grail"), s = (e) => {
		let n = R[e], r = a ? 0 : n.cost.wood ?? 0, i = o ? 0 : n.cost.gold ?? 0;
		return t.wood >= r && t.iron >= (n.cost.iron ?? 0) && t.gold >= i && t.rage >= (n.cost.rage ?? 0) && (t.units.serpent ?? 0) >= (n.cost.serpents ?? 0);
	}, c = i.buildings.filter((e) => !t.buildings.includes(e.id) && e.level <= r && (e.req.length === 0 || e.req.some((e) => t.buildings.includes(e))) && s(e.id)), l = n ? c.length > 0 ? It(c) : null : c.sort((e, t) => t.vp - e.vp || t.level - e.level)[0], u = t.gold;
	l && (u -= o ? 0 : l.cost.gold ?? 0);
	let d;
	if (l && t.region) {
		let e = k[t.region], n = t.foundations[t.region] ?? [];
		if (e?.foundations) {
			for (let t = 0; t < e.foundations; t++) if ((n[t] ?? 0) < l.level) {
				d = t;
				break;
			}
		}
	}
	let f = {};
	if (t.faction !== "nagas") {
		let e = t.faction === "gnomes" && t.buildings.includes("pipeline") ? Math.floor(t.science / 9) : 0;
		for (let n = 0; n < 12; n++) {
			let n = i.units.filter((e) => e.recruitedBy && t.buildings.includes(e.recruitedBy)).map((n) => {
				let r = n.id === "mechanic" ? n.cost : Math.max(0, n.cost - e);
				return t.faction === "humans" && t.buildings.includes("cathedral") && (n.id === "cuirassier" && (r = 2), n.id === "archmage" && (r = 3)), {
					u: n,
					cost: r
				};
			}).filter((e) => e.cost <= u && e.cost > 0).sort((e, t) => t.u.pow - e.u.pow)[0];
			if (!n) break;
			f[n.u.id] = (f[n.u.id] ?? 0) + 1, u -= n.cost;
		}
	}
	let p;
	return l && t.faction === "nagas" && (t.notes + 1) % 2 == 0 && (p = O.find((t) => (t.terrain === "lake" || e.map.lakes.includes(t.id)) && !e.map.removed.includes(t.id))?.id), {
		type: "build",
		building: l?.id,
		foundationSlot: d,
		recruits: Object.keys(f).length > 0 ? f : void 0,
		anyGain: l?.id === "assemblers" ? Rt(t, 9) : void 0,
		hydraDest: p
	};
}
function Gt(e, t, n) {
	let r = e.exec.level + +!!t.buildings.includes("observatory"), i = L[t.faction];
	if (n || !t.region) return {
		type: "move",
		dest: t.region ?? ""
	};
	let a = j(new Set(e.map.removed)), o = (n) => Object.values(e.boards).filter((e) => e.region === n && e !== t).length, s = (a[t.region] ?? []).filter((e) => !t.visited.includes(e) && i.terrainCost[k[e].terrain] <= r).map((e) => ({
		r: e,
		rd: k[e],
		score: Lt(k[e].res) + k[e].any + (o(e) > 0 ? -3 : 0)
	})).sort((e, t) => t.score - e.score)[0]?.r ?? t.region, c = !t.visited.includes(s), l = k[s], u = c ? l.any + (t.buildings.includes("townhall") || t.buildings.includes("lab") ? 1 : 0) : 0, d;
	return t.hydra && (a[t.hydra] ?? []).includes(s) && (d = s), {
		type: "move",
		dest: s,
		anyGain: Rt(t, u),
		hydraDest: d
	};
}
function Kt(e, t) {
	let n = e.exec.declareRegions?.find((e) => e.members.includes(t)), r = n ? k[n.region] : null;
	return {
		type: "declare",
		fight: !1,
		wantFortress: !!r?.fortress && !e.map.fortressOwner[n.region],
		wantArtifact: !!r?.artifact && !e.map.artifactOwner[r.artifact]
	};
}
function qt(e, t) {
	let n = {};
	for (let [r, i] of Object.entries(e.units)) i > 0 && (n[r] = t ? Math.max(1, Math.floor(i / 2)) : i);
	return {
		type: "deploy",
		units: n
	};
}
function Jt(e, t) {
	let n = t?.info, r = e.faction === "nagas" ? N : M;
	return {
		type: "reward",
		choice: "res",
		anyGain: Rt(e, (n ? r[n.monster] : void 0)?.any ?? 0)
	};
}
function Yt(e, t, n) {
	let r = e.exec, i = t.region, a = k[i], o = r.grants ?? {}, s = Object.entries(e.boards).filter(([, e]) => e.region === i), c = s.length === 1 && s[0][0] === n, l = e.battleLog.some((e) => e.region === i && e.winner === n), u = (e) => c || l || o[`${i}:${e}`] === n, d = { type: "post" };
	if (a.fortress && !e.map.fortressOwner[i] && u("fortress")) {
		let e = Bt(t, a.fortress.pow);
		e && (d.fortress = {
			units: e,
			anyGain: Rt(t, a.fortress.any)
		});
	}
	if (!d.fortress && a.artifact && !e.map.artifactOwner[a.artifact] && u("artifact")) {
		let e = ee[a.artifact], n = t.faction === "nagas" ? (t.units.serpent ?? 0) >= 3 : e.cond.kind === "pay" ? t[e.cond.res] >= e.cond.amount : e.cond.kind === "foundations" ? Object.values(t.foundations).reduce((e, t) => e + t.filter((e) => e > 0).length, 0) >= e.cond.amount : e.cond.kind === "victories" ? t.fortresses.length + t.monsters.filter(Boolean).length >= e.cond.amount : t.mountainVisits >= e.cond.amount, r = t.faction === "gnomes" && a.artifact === "book" ? 9 : (t.faction === "humans" || t.faction === "undead") && a.artifact === "grail" ? 8 : 0, i = t.faction === "undead" && (a.artifact === "mask" || a.artifact === "book");
		n && !i && (d.artifact = { anyGain: Rt(t, r) });
	}
	let f = d.fortress ? {
		...t,
		units: Object.fromEntries(Object.entries(t.units).map(([e, t]) => [e, t - (d.fortress.units[e] ?? 0)]))
	} : t, p = r.leftover?.[n] ?? 0, m = t.faction === "nagas" ? N : M, h = [];
	t.monsters.forEach((e, t) => {
		e || h.push(t);
	});
	let g = t.buildings.includes("shrine") && (r.stayed?.[n] ?? !1);
	for (let e = 0; e < h.length && e <= p; e++) {
		let n = h[e], r = Bt(f, m[n].pow);
		if (r) {
			d.monster = {
				skip: e,
				target: g ? n : void 0,
				units: r,
				anyGain: Rt(t, m[n].any + (t.buildings.includes("market") ? 2 : 0))
			};
			break;
		}
	}
	return d;
}
var Xt = (e, t) => {
	let n = e.public, r = n.boards?.[t.rid];
	if (!r || n.phase === "done") return null;
	let i = t.difficulty === "weak", a = (e) => ({ action: e });
	switch (n.phase) {
		case "pick": return r.faction ? null : a({
			type: "pick",
			faction: Vt(n, i)
		});
		case "start": {
			if (r.region || n.startOrder?.[n.startIdx] !== t.rid) return null;
			let e = Ht(n, i);
			return e ? a(e) : null;
		}
		case "plan": return n.first === t.rid && !n.plan ? a({
			type: "plan",
			assign: Ut(r, i)
		}) : null;
		case "boost": {
			let e = t.memory ?? {};
			return !(r.faction === "orcs" && r.buildings.includes("chiefhouse") && r.rage >= 1) || e.boostRound === n.round ? null : {
				action: { type: "boost" },
				memory: { boostRound: n.round }
			};
		}
		case "exec": {
			let o = n.exec;
			if (!o || !o.waiting.includes(t.rid)) return null;
			switch (o.stage) {
				case "build": return a(Wt(n, r, i));
				case "movePlan": return a(Gt(n, r, i));
				case "declare": return a(Kt(n, t.rid));
				case "yield": return a({
					type: "yieldDecide",
					stick: !1
				});
				case "deploy": return a(qt(r, i));
				case "reward": return a(Jt(r, e.private?.echo));
				case "post": return a(Yt(n, r, t.rid));
				default: return null;
			}
		}
		default: return null;
	}
};
//#endregion
//#region src/games/heroeswac/endgame-review.tsx
function Zt({ board: e, renderResult: t, ...n }) {
	let r = l(), [c, u] = s(!0), [d, f] = s(null), g = o(null), y = o(null), b = o(null);
	i(() => {
		if (!d) return;
		b.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let x = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? g : y).current?.focus({ preventScroll: !0 }));
	}, S = a(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...S
	};
	return /* @__PURE__ */ m("div", {
		className: "heroeswac-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ p("div", {
				className: "heroeswac-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ p("div", {
				className: "heroeswac-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ m("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "heroeswac-endgame-panel",
					"aria-label": r("session.result.title"),
					children: [
						/* @__PURE__ */ m("header", {
							className: "heroeswac-endgame-heading",
							children: [/* @__PURE__ */ m("div", {
								className: "heroeswac-endgame-brand",
								children: [/* @__PURE__ */ p("span", {
									"aria-hidden": "true",
									children: H.icon
								}), r(H.nameKey)]
							}), /* @__PURE__ */ p("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": r("games.heroeswac.reviewHide"),
								title: r("games.heroeswac.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ p(_, { size: 19 })
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "heroeswac-endgame-result",
							inert: d !== null,
							children: t(C)
						}),
						d && /* @__PURE__ */ m("div", {
							className: "heroeswac-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ p("button", {
								type: "button",
								ref: b,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: r(d.label === "again" ? "games.heroeswac.reviewConfirmAgain" : "games.heroeswac.reviewConfirmLobby")
							}), /* @__PURE__ */ p("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), g.current?.focus({ preventScroll: !0 });
								},
								children: r("games.heroeswac.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "heroeswac-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base",
					ref: y,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ p(v, { size: 18 }),
						r("games.heroeswac.reviewShow"),
						/* @__PURE__ */ p(h, { size: 18 })
					]
				})
			})
		]
	});
}
function Qt({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: u, renderRowExtra: d, summary: h, navigation: v, content: x, afterRanking: S, scoreUnit: C, rankOf: w }) {
	let T = l(), E = c((e) => e.locale), [D, ee] = s({}), O = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? y(n, E) : e;
	}, k = (t, n) => w?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), A = e.ranking.some((t) => e.scores?.[t] !== void 0), j = (t, n) => /* @__PURE__ */ m("div", {
		className: "heroeswac-score-identity",
		children: [
			/* @__PURE__ */ m("span", {
				className: "heroeswac-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ p("span", {
					"aria-label": T("games.heroeswac.reviewWinner"),
					children: "♛ "
				}), A && k(t, n)]
			}),
			/* @__PURE__ */ m("span", {
				className: "heroeswac-score-name",
				children: [O(t), t === r && /* @__PURE__ */ p("small", { children: T("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ m("small", {
				className: "heroeswac-score-autopilot",
				children: [
					/* @__PURE__ */ p(g, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), M = (t) => e.ranking.map((n) => /* @__PURE__ */ p("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ m("div", {
		className: "heroeswac-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ p(b, {}),
			v,
			/* @__PURE__ */ m("div", {
				className: "heroeswac-score-body",
				children: [
					h && /* @__PURE__ */ p("div", {
						className: "heroeswac-score-summary",
						children: h
					}),
					i !== void 0 && /* @__PURE__ */ p("p", {
						className: "heroeswac-score-hints",
						children: T("session.hint.usedCount", { n: i })
					}),
					x ?? (u?.length ? /* @__PURE__ */ p("div", {
						className: "heroeswac-score-table-scroll",
						children: /* @__PURE__ */ m("table", {
							className: "heroeswac-score-table",
							"aria-label": T(H.nameKey),
							children: [
								/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { scope: "col" }), /* @__PURE__ */ p(f, { children: e.ranking.map((t, n) => /* @__PURE__ */ p("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: j(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ p("tbody", { children: u.map((e, t) => /* @__PURE__ */ m(n, { children: [/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ m("button", {
										type: "button",
										"aria-expanded": !!D[t],
										onClick: () => ee((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ p(_, { size: 15 }), e.label]
									}) : e.label
								}), M(e)] }), D[t] && e.details?.map((e, t) => /* @__PURE__ */ m("tr", {
									className: "heroeswac-score-sub",
									children: [/* @__PURE__ */ p("th", {
										scope: "row",
										children: e.label
									}), M(e)]
								}, t))] }, t)) }),
								A && /* @__PURE__ */ p("tfoot", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
									scope: "row",
									children: T("games.heroeswac.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ p("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ p("ol", {
						className: "heroeswac-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ m("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ m("div", {
								className: "heroeswac-score-rankline",
								children: [j(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ m("strong", {
									className: "heroeswac-score-points",
									children: [e.scores[t], C && /* @__PURE__ */ p("small", { children: C })]
								})]
							}), d?.(t)]
						}, t))
					})),
					S,
					!!u?.length && d && /* @__PURE__ */ p("div", {
						className: "heroeswac-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ p("summary", { children: O(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ m("footer", {
				className: "heroeswac-score-actions",
				children: [
					o && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: T("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: T("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ p("p", { children: T("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/heroeswac/game-over.tsx
function $t(e) {
	let [t, n] = s(!1), r = e.public;
	return /* @__PURE__ */ m("div", {
		className: "hwc-over hwc-root",
		children: [
			/* @__PURE__ */ p("div", {
				className: "hwc-over__screen",
				children: /* @__PURE__ */ p(Qt, {
					result: e.result,
					hintCount: e.hintCount,
					members: e.members,
					myRid: e.myRid,
					accent: H.accent,
					onPlayAgain: e.onPlayAgain,
					onBackToLobby: e.onBackToLobby
				})
			}),
			/* @__PURE__ */ p(dt, {
				pub: r,
				members: e.members,
				onOpen: () => n(!0),
				journalActive: t
			}),
			/* @__PURE__ */ p(ft, {
				pub: r,
				members: e.members,
				open: t,
				onClose: () => n(!1),
				returnTo: "result"
			})
		]
	});
}
function en(e) {
	return /* @__PURE__ */ p(Zt, {
		...e,
		board: /* @__PURE__ */ p(Pt, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ p($t, { ...e })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/heroeswac/entry.tsx
var tn = {
	definition: ot,
	View: Pt,
	bot: Xt,
	OverView: en,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "英雄之笔伐征途",
			desc: "十六回合编程行动,占要塞、打怪、收神器,六个阵营各走各的发展路线",
			rules: "目标:十六回合后总得分最高者获胜。\n流程:\n· 每回合先手从伐木、采铁、采金、移动、建造中选四个行动,各分配等级一至四。\n· 其余玩家照抄同一编程,全体按等级升序同时执行。\n· 采集按等级获得资源,移动按等级获得移动力,建造按等级上限建一座建筑并可招募。\n· 每回合结束,先手移交给左邻玩家。\n移动与战斗:\n· 沿相邻区域逐格移动,每进入一个区域按其地形支付移动力。\n· 只有目的地结算:首次造访获得该区域印有的资源。\n· 同区有多名玩家时同时秘密选择宣战或和平,有人宣战则全员混战。\n· 战斗秘密部署部队,力量严格更高者胜,平局全败,参战单位全灭。\n· 未用完的移动力可挑战怪物线上的怪物,每一点跳过一只。\n发展:\n· 要塞全局唯一,力量超过守备值才能占领;地基登记建筑等级换终局分。\n· 六件神器各有收取条件;被诅咒的区域会让造访的对手失去最弱部队。\n· 六个阵营的建筑树、部队与地形费用各不相同。\n计分:\n· 建筑分、地基等级、资源阈值、怪物分、要塞分与神器分相加。\n· 平分比较库存资源总量,再平则共享胜利。",
			faction: {
				gnomes: "侏儒",
				humans: "人类",
				elves: "精灵",
				undead: "亡灵",
				nagas: "娜迦",
				orcs: "兽人"
			},
			factionDesc: {
				gnomes: "科学轨道解锁免费建造,机械部队越到后期越强",
				humans: "多面发展,幻象塔可以封锁地图上的目标",
				elves: "盔甲铺战前强化,巢穴狮鹫可用木材换神器",
				undead: "瘟疫诅咒削弱对手,巫妖参战可复活骷髅",
				nagas: "蛇群即货币,建造圈音符召唤九头蛇",
				orcs: "怒气提级与改装部队,投石车令全军战力暴涨"
			},
			region: {
				asander: "阿桑德",
				brynnlore: "布林洛尔",
				cerness: "瑟内斯",
				dortal: "多塔尔",
				esmore: "埃斯莫尔",
				folen: "佛伦",
				glennfore: "格伦佛",
				harrax: "哈拉克丝",
				ikara: "伊卡拉",
				jorveld: "约维尔德",
				kosleen: "科斯林",
				lox: "洛克斯",
				morreed: "莫里德",
				nikleen: "尼克林",
				odmoor: "奥德摩尔",
				paskaar: "帕斯卡",
				qliss: "克丽丝",
				rolgoy: "罗尔戈伊",
				suleen: "苏林",
				togeed: "托格伊德",
				ugmat: "乌格玛特",
				vurt: "乌尔特",
				wirs: "威尔斯",
				xee: "希伊",
				yreel: "伊里尔",
				zasker: "扎斯克",
				zoro: "佐罗"
			},
			artifact: {
				totem: "图腾",
				bowl: "蓝碗",
				mask: "金面具",
				crystal: "水晶",
				book: "红书",
				grail: "圣杯"
			},
			act: {
				wood: "伐木",
				iron: "采铁",
				gold: "采金",
				move: "移动",
				build: "建造"
			},
			monster: {
				m0: "鱼人",
				m1: "豺狼人",
				m2: "鹰身女妖",
				m3: "半人马",
				m4: "娜迦",
				m5: "蝎狮",
				m6: "巨人",
				m7: "龙"
			},
			unit: {
				mechanic: "机械师",
				anisopter: "蜓翼机",
				automaton: "自动机",
				mechasaur: "机甲龙",
				soldier: "士兵",
				cuirassier: "胸甲骑兵",
				archmage: "大法师",
				pixie: "小精灵",
				griffin: "狮鹫",
				ent: "树人",
				skeleton: "骷髅",
				executioner: "刽子手",
				lich: "巫妖",
				serpent: "蛇群",
				scout: "侦察兵",
				charger: "冲锋手",
				bomber: "投弹手"
			},
			building: {
				generator: "发电机",
				academy: "学院",
				assemblers: "装配间",
				library: "图书馆",
				workhouse: "工房",
				lab: "实验室",
				pipeline: "流水线",
				plant: "装配厂",
				bank: "银行",
				factory: "工厂",
				townhall: "市政厅",
				warguild: "战士行会",
				market: "市场",
				illtower: "幻象塔",
				trackers: "追踪者之家",
				tavern: "酒馆",
				barracks: "兵营",
				armoury: "军械库",
				cathedral: "大教堂",
				mageguild: "法师行会",
				horn: "号角",
				brushwood: "灌木丛",
				armorshop: "盔甲铺",
				nests: "巢穴",
				woodedcliff: "林崖",
				observatory: "瞭望塔",
				watch: "哨塔",
				guidforest: "引路林",
				druidhouse: "德鲁伊之家",
				greattree: "巨树",
				barrow: "古坟",
				hearse: "灵车",
				graveyard: "墓园",
				tomb: "石墓",
				shrine: "神龛",
				ruins: "城堡废墟",
				chapel: "礼拜堂",
				plague: "瘟疫柱",
				temple: "神殿",
				ossuary: "藏骨堂",
				lighthouse: "灯塔",
				heart: "海洋之心",
				church: "教堂",
				dam: "水坝",
				mine: "矿场",
				geyser: "间歇泉",
				ship: "帆船",
				feeder: "饲育场",
				palace: "宫殿",
				reef: "珊瑚礁",
				idol: "战争神像",
				dump: "废料场",
				arena: "竞技场",
				camp: "营地",
				chiefhouse: "酋长屋",
				stable: "马厩",
				gym: "训练场",
				trophyhall: "战利品厅",
				catapult: "投石车",
				workshop: "工坊"
			},
			bld: {
				generator: "建造时,场上每个机械师使你获得 1 点科学",
				academy: "招募机械师;每个机械师令一支部队力量翻倍",
				assemblers: "建造时获得 1 点科学与 9 个任意资源",
				library: "建造行动中可付 4 木获得 1 点科学",
				workhouse: "招募蜓翼机",
				lab: "首次造访区域时额外获得 1 个任意资源",
				pipeline: "每 9 点科学使招募费减少 1 金,机械师除外",
				plant: "招募自动机;每招募 1 个获得 1 点科学",
				bank: "终局时科学达到 4、9、14 各 +1 分",
				factory: "招募机甲龙;每 3 点科学使其力量 +1",
				townhall: "首次造访区域时额外获得 1 个任意资源",
				warguild: "招募士兵",
				market: "击败怪物时额外获得 2 个任意资源",
				illtower: "建造行动结束可付 4 木,封锁一个要塞、神器、传送门或地基",
				trackers: "进入森林只需 1 点移动力",
				tavern: "终局时每个已击败的怪物 +1 分",
				barracks: "招募胸甲骑兵",
				armoury: "士兵力量 3、胸甲骑兵力量 4、大法师力量 7",
				cathedral: "胸甲骑兵招募费 2 金、大法师招募费 3 金",
				mageguild: "招募大法师",
				horn: "战斗中全军总力量 +1",
				brushwood: "招募小精灵",
				armorshop: "战斗前可付木材临时强化部队,仅当场有效",
				nests: "招募狮鹫;狮鹫数达到神器木价时可用木材收神器",
				woodedcliff: "建造不再花费木材",
				observatory: "移动行动 +1 移动力",
				watch: "终局时每个已占领的要塞 +2 分",
				guidforest: "进入森林只需 1 点移动力",
				druidhouse: "终局时每个神器 +1 分",
				greattree: "招募树人",
				barrow: "战斗后复活至多 2 个阵亡骷髅",
				hearse: "移动时每 2 木换 1 点额外移动力",
				graveyard: "招募骷髅",
				tomb: "战斗后复活 1 个阵亡刽子手",
				shrine: "原地不动的移动行动可任选怪物线上的目标",
				ruins: "招募刽子手;其力量等于本回合你的移动力",
				chapel: "获得至少 3 铁时可用 3 铁换 1 个刽子手",
				plague: "建造行动结束可付 3 木诅咒当前或相邻区域",
				temple: "终局时每个存活巫妖 +1 分",
				ossuary: "招募巫妖;巫妖参战则复活全部阵亡骷髅",
				lighthouse: "九头蛇一次可移动 2 个区域",
				heart: "海洋之心,九头蛇力量升至 25",
				church: "终局时每次召唤九头蛇 +2 分",
				dam: "终局时地图上每个湖泊区域 +1 分",
				mine: "遭遇时付 3 个任意资源给同区玩家可避免与其战斗",
				geyser: "移动行动结束可付 1 移动力把当前区域变湖泊",
				ship: "获得神器时圈 1 个音符",
				feeder: "木铁换蛇的比率各减 1",
				palace: "终局时每个地基上的建筑 +1 分",
				reef: "蛇群不再降低九头蛇力量",
				idol: "任何战斗获胜获得 2 点怒气",
				dump: "在地基上建造时获得 2 点怒气",
				arena: "招募冲锋手时获得 1 点怒气",
				camp: "招募侦察兵;山地区域战斗时其力量视为 4",
				chiefhouse: "计划公布后可付怒气提升自己的行动等级",
				stable: "进入山地只需 1 点移动力",
				gym: "招募冲锋手",
				trophyhall: "终局时每访问 2 个区域 +1 分",
				catapult: "战斗中全军总力量 +4",
				workshop: "招募投弹手;夺要塞时其力量视为 12"
			},
			err: {
				phase: "当前阶段不能这么做",
				picked: "已经选过了",
				factionTaken: "这个阵营已被选走",
				notPortal: "起始区域必须是传送门区域",
				regionTaken: "这个区域已被占据",
				badPlan: "编程必须是四个行动各配一个等级,一至四不重复",
				noBoost: "这个行动本轮没有安排",
				noRage: "怒气不足",
				already: "已经提交过了",
				noBuilding: "这座建筑现在不能建",
				noFree: "没有可用的免费建造资格",
				badFoundation: "这个地基槽位不可用",
				noRecruit: "这个兵种现在不能招募",
				noRes: "资源不足",
				badIllusion: "这个目标无法封锁",
				badCurse: "这个区域无法诅咒",
				badConvert: "转换数量不对",
				badAny: "任意资源的数量不对",
				noHydra: "现在不能召唤或移动九头蛇",
				badDest: "去不了这个区域",
				noBudget: "移动力不足",
				notMember: "你不在这场遭遇里",
				badDeclare: "声明无效",
				badDeploy: "部署无效",
				badReward: "奖励选择无效",
				noFortress: "这座要塞现在不能攻打",
				noMonster: "这只怪物现在不能打",
				noArtifact: "这件神器现在不能收",
				stoleArtifact: "本回合已经抢过神器,不能再收区域神器",
				fortressXorArtifact: "要塞与神器只能选一个"
			},
			ui: {
				round: "第 {{n}} / 16 回合",
				phasePick: "选择阵营",
				phaseStart: "选择起始区域",
				phasePlan: "行动编程",
				phaseBoost: "酋长屋提级",
				phaseExec: "执行行动",
				pickPrompt: "选择你的阵营,先到先选",
				startPrompt: "选择一个传送门区域作为起始位置",
				startWait: "等待 {{name}} 选择起始区域…",
				planPrompt: "给四个行动各分配一个等级,一至四各用一次",
				planWait: "等待 {{name}} 完成行动编程…",
				planNone: "不安排",
				submit: "提交",
				waiting: "等待其他玩家…",
				boostPrompt: "付 1 点怒气把一个行动的等级 +1,或放弃",
				boostPass: "放弃提级",
				boostPlus: "{{action}} +1",
				execLine: "等级 {{n}} · {{action}}",
				stageBuild: "建造与招募",
				buildNone: "本回合不建造",
				buildFree: "使用免费建造资格",
				recruitLabel: "招募",
				stageMove: "选择目的地",
				stay: "原地不动",
				moveBudget: "移动力 {{n}}",
				stageDeclare: "同区遭遇",
				declarePrompt: "所在区域发生遭遇,选择宣战或和平",
				declareFight: "宣战",
				declarePeace: "和平共处",
				wantFortress: "想要要塞",
				wantArtifact: "想要神器",
				stageYield: "目标争议",
				yieldPrompt: "多名玩家想要同一目标,让步还是坚持?",
				yieldGive: "让步",
				yieldStick: "坚持",
				stageDeploy: "战斗部署",
				deployPrompt: "选择投入战斗的部队,参战单位全灭",
				deployAll: "全部投入",
				stageReward: "战斗奖励",
				rewardPrompt: "选择你的胜利奖励",
				rewardRes: "拿怪物印有的资源",
				rewardLoot: "从 {{name}} 处掠夺 {{n}} 个资源",
				rewardArtifact: "抢一件神器",
				stagePost: "移动结算",
				postFortress: "攻打要塞,守备 {{n}}",
				postMonster: "挑战 {{name}},力量 {{n}}",
				postArtifact: "收取神器",
				postSkip: "跳过",
				chapelToggle: "礼拜堂:获得 3 铁时自动换刽子手",
				myBoard: "我的面板",
				unitsLabel: "部队",
				buildingsLabel: "建筑",
				mapLabel: "地图",
				cursed: "诅咒",
				fortressShort: "要塞 {{n}}",
				scienceShort: "科学",
				rageShort: "怒气",
				notesShort: "音符",
				logTitle: "战斗记录",
				logLine: "{{region}}:{{name}} 获胜",
				logDraw: "{{region}}:平局,全员败退",
				hydra: "九头蛇",
				planOf: "本轮编程",
				journal: {
					allLogs: "全部日志",
					shortLogs: "日志",
					title: "全部行动日志",
					close: "关闭日志",
					return: "收起日志 · 返回对局",
					returnResult: "收起日志 · 返回结算",
					count: "公开记录 {{n}} 条",
					empty: "本局尚无公开行动",
					noEntries: "当前筛选下没有行动记录",
					allRounds: "全部回合",
					allPlayers: "所有玩家",
					round: "第 {{n}} 回合",
					roundFilter: "按回合筛选日志",
					playerFilter: "按玩家筛选日志",
					groupSetup: "第 {{round}} 回合 · 开局与编排",
					groupLevel: "第 {{round}} 回合 · {{level}} 级行动",
					currentSubmissions: "当前提交进度",
					submitted: "已提交",
					waiting: "待提交",
					pendingCount: "本阶段 {{done}} / {{total}} 人已提交",
					pick: "选择 {{faction}} 阵营",
					start: "从 {{region}} 出发",
					plan: "公布行动顺序：{{sequence}}",
					boost: "消耗怒气，把 {{action}} 提升 {{amount}} 级",
					boostPass: "放弃行动提级",
					collect: "执行 {{action}}，基础获得 {{amount}}",
					build: "建成 {{building}}",
					recruit: "招募 {{units}}",
					library: "使用图书馆能力",
					illusion: "在 {{region}} 设置幻象",
					curse: "诅咒 {{region}}",
					buildPass: "本级未建造或招募",
					move: "从 {{from}} 移动至 {{to}}",
					stay: "留在 {{region}}，未移动",
					declareFight: "在同区遭遇中宣战",
					declarePeace: "在同区遭遇中选择和平",
					claimFortress: "争取要塞",
					claimArtifact: "争取神器",
					bribe: "向 {{name}} 支付贿礼",
					insist: "在 {{region}} 坚持争夺",
					yield: "在 {{region}} 让步",
					deploy: "在 {{region}} 部署 {{units}}",
					noUnits: "不投入部队",
					rewardRes: "选择战斗资源奖励",
					rewardLoot: "从 {{name}} 处掠夺资源",
					rewardArtifact: "夺取神器 {{artifact}}",
					postFortress: "攻打要塞",
					postMonster: "挑战怪物",
					postArtifact: "收取神器",
					postPass: "跳过移动后行动",
					chapelOn: "开启礼拜堂自动兑换",
					chapelOff: "关闭礼拜堂自动兑换",
					builtResult: "建筑落成：{{building}}",
					artifactGain: "获得 {{artifact}}",
					artifactLoss: "失去 {{artifact}}",
					fortressGain: "占领 {{region}} 要塞",
					monsterWin: "击败 {{monster}}",
					battleWin: "战力 {{power}} · 获胜",
					battleLoss: "战力 {{power}} · 败于 {{name}}",
					battleTie: "战力 {{power}} · 平局",
					viewMap: "查看地图",
					backFromMap: "返回当前工作台"
				},
				visual: {
					actionTray: "行动棋子",
					planBoard: "本轮行动顺序",
					emptySlot: "空槽",
					roundShort: "回合",
					selectAbove: "请在上方游戏面板中操作",
					scienceTrack: "沿建筑分支向上发展",
					wood: "木",
					iron: "铁",
					gold: "金",
					chooseAction: "先选行动，再放进 1–4 级槽位",
					levelSlot: "{{n}} 级",
					unused: "本轮不执行",
					publishPlan: "公布行动顺序",
					treeTitle: "侏儒发展树",
					built: "已建成",
					selected: "已选中",
					needLevel: "行动等级不足",
					needPrereq: "需先建前置建筑",
					needResources: "资源不足",
					foundation: "地基 {{n}}",
					routeCost: "路径消耗 {{n}} / {{budget}}",
					firstVisit: "首访资源",
					unreachable: "本轮到不了",
					chooseDestination: "在地图上选择目的地",
					confirmMove: "秘密提交目的地",
					currentRegion: "你在这里",
					returnToMe: "回到我的位置",
					zoomIn: "放大地图",
					zoomOut: "缩小地图",
					autoResources: "任意资源按木、铁、金均分",
					waitingFor: "等待 {{name}}"
				}
			}
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Heroes: Write & Conquer",
			desc: "Sixteen rounds of programmed actions: fortresses, monsters, artifacts, six asymmetric factions",
			rules: "Goal: after sixteen rounds, the highest total score wins.\nRounds:\n· The first player picks four of five actions and assigns levels one to four.\n· Everyone copies the same program; actions run in ascending level order.\n· Gathering grants resources, moving grants move points, building builds and recruits.\n· At the end of each round, the first-player role passes left.\nMovement and combat:\n· Move region by region, paying the terrain cost of each region entered.\n· Only the destination resolves: first visits grant the printed resources.\n· Sharing a region means secret declarations; any war starts a melee.\n· Commit units secretly; the strictly stronger side wins and all committed die.\n· Leftover move points challenge monsters on your track, one skip per point.\nDevelopment:\n· Fortresses are unique; exceed their defense to capture them.\n· Six artifacts have their own conditions; curses weaken visiting rivals.\n· Each faction has its own buildings, troops, and terrain costs.\nScoring:\n· Buildings, foundations, thresholds, monsters, fortresses, artifacts.\n· Ties break on stockpiled resources; further ties share the victory.",
			faction: {
				gnomes: "Gnomes",
				humans: "Humans",
				elves: "Elves",
				undead: "Undead",
				nagas: "Nagas",
				orcs: "Orcs"
			},
			factionDesc: {
				gnomes: "Science unlocks free builds; machines grow stronger late",
				humans: "Flexible all-rounders; the Illusion Tower blocks map targets",
				elves: "Pre-battle armor boosts; griffins buy artifacts with wood",
				undead: "Plague curses weaken rivals; liches raise fallen skeletons",
				nagas: "Serpents are currency; buildings tune notes to summon the Hydra",
				orcs: "Rage boosts action levels and upgrades troops on the fly"
			},
			region: {
				asander: "Asander",
				brynnlore: "Brynnlore",
				cerness: "Cerness",
				dortal: "Dortal",
				esmore: "Esmore",
				folen: "Folen",
				glennfore: "Glennfore",
				harrax: "Harrax",
				ikara: "Ikara",
				jorveld: "Jorveld",
				kosleen: "Kosleen",
				lox: "Lox",
				morreed: "Morreed",
				nikleen: "Nikleen",
				odmoor: "Odmoor",
				paskaar: "Paskaar",
				qliss: "Qliss",
				rolgoy: "Rolgoy",
				suleen: "Suleen",
				togeed: "Tog'Eed",
				ugmat: "Ugmat",
				vurt: "Vurt",
				wirs: "Wirs",
				xee: "Xee",
				yreel: "Yreel",
				zasker: "Zasker",
				zoro: "Zoro"
			},
			artifact: {
				totem: "Totem",
				bowl: "Blue Bowl",
				mask: "Golden Mask",
				crystal: "Crystal",
				book: "Red Book",
				grail: "Grail"
			},
			act: {
				wood: "Wood",
				iron: "Iron",
				gold: "Gold",
				move: "Move",
				build: "Build"
			},
			monster: {
				m0: "Fishfolk",
				m1: "Gnoll",
				m2: "Harpy",
				m3: "Centaur",
				m4: "Naga",
				m5: "Manticore",
				m6: "Giant",
				m7: "Dragon"
			},
			unit: {
				mechanic: "Mechanic",
				anisopter: "Anisopter",
				automaton: "Automaton",
				mechasaur: "Mechasaur",
				soldier: "Soldier",
				cuirassier: "Cuirassier",
				archmage: "Archmage",
				pixie: "Pixie",
				griffin: "Griffin",
				ent: "Ent",
				skeleton: "Skeleton",
				executioner: "Executioner",
				lich: "Lich",
				serpent: "Serpent",
				scout: "Scout",
				charger: "Charger",
				bomber: "Bomber"
			},
			building: {
				generator: "Generator",
				academy: "Academy",
				assemblers: "Assemblers",
				library: "Library",
				workhouse: "Workhouse",
				lab: "Laboratory",
				pipeline: "Pipeline",
				plant: "Plant",
				bank: "Bank",
				factory: "Factory",
				townhall: "Town Hall",
				warguild: "Warrior Guild",
				market: "Market",
				illtower: "Tower of Illusions",
				trackers: "House of Trackers",
				tavern: "Tavern",
				barracks: "Barracks",
				armoury: "Armoury",
				cathedral: "Cathedral",
				mageguild: "Mage Guild",
				horn: "Horn",
				brushwood: "Pixie Brushwood",
				armorshop: "Armor Shop",
				nests: "Nests",
				woodedcliff: "Wooded Cliff",
				observatory: "Observatory",
				watch: "Watch",
				guidforest: "Guiding Forest",
				druidhouse: "House of the Druid",
				greattree: "The Great Tree",
				barrow: "Barrow",
				hearse: "Hearse",
				graveyard: "Graveyard",
				tomb: "Tomb",
				shrine: "Shrine",
				ruins: "Castle Ruins",
				chapel: "Chapel",
				plague: "Plague Column",
				temple: "Temple",
				ossuary: "Ossuary",
				lighthouse: "Lighthouse",
				heart: "Heart of the Ocean",
				church: "Church",
				dam: "Dam",
				mine: "Mine",
				geyser: "Geyser",
				ship: "Ship",
				feeder: "Feeder",
				palace: "Palace",
				reef: "Reef",
				idol: "Idol of War",
				dump: "Dump",
				arena: "Arena",
				camp: "Camp",
				chiefhouse: "House of Chief",
				stable: "Stable",
				gym: "Gym",
				trophyhall: "Trophy Hall",
				catapult: "Catapult",
				workshop: "Workshop"
			},
			bld: {
				generator: "On build, gain 1 science per Mechanic in play",
				academy: "Recruits Mechanics; each Mechanic doubles one unit",
				assemblers: "On build, gain 1 science and 9 any resources",
				library: "During build actions, pay 4 wood for 1 science",
				workhouse: "Recruits Anisopters",
				lab: "First visits to regions grant 1 extra any resource",
				pipeline: "Every 9 science discounts recruit cost by 1 gold",
				plant: "Recruits Automatons; each recruit grants 1 science",
				bank: "Endgame: +1 VP each for science at 4, 9, and 14",
				factory: "Recruits Mechasaurs; +1 power per 3 science",
				townhall: "First visits to regions grant 1 extra any resource",
				warguild: "Recruits Soldiers",
				market: "Defeating a monster grants 2 extra any resources",
				illtower: "After building, pay 4 wood to block one map target",
				trackers: "Entering forests costs 1 move point",
				tavern: "Endgame: +1 VP per defeated monster",
				barracks: "Recruits Cuirassiers",
				armoury: "Soldier 3, Cuirassier 4, Archmage 7 power",
				cathedral: "Cuirassiers cost 2 gold, Archmages cost 3 gold",
				mageguild: "Recruits Archmages",
				horn: "Army total power +1 in battle",
				brushwood: "Recruits Pixies",
				armorshop: "Pay wood before battle to boost units for that fight",
				nests: "Recruits Griffins; griffins let you buy artifacts with wood",
				woodedcliff: "Buildings no longer cost wood",
				observatory: "Move actions grant +1 move point",
				watch: "Endgame: +2 VP per captured fortress",
				guidforest: "Entering forests costs 1 move point",
				druidhouse: "Endgame: +1 VP per artifact",
				greattree: "Recruits Ents",
				barrow: "After battle, revive up to 2 fallen Skeletons",
				hearse: "While moving, every 2 wood buys 1 extra move point",
				graveyard: "Recruits Skeletons",
				tomb: "After battle, revive 1 fallen Executioner",
				shrine: "A stationary move may target any monster on the track",
				ruins: "Recruits Executioners; power equals your move points",
				chapel: "When gaining 3+ iron, trade 3 iron for an Executioner",
				plague: "After building, pay 3 wood to curse this or an adjacent region",
				temple: "Endgame: +1 VP per surviving Lich",
				ossuary: "Recruits Liches; a fighting Lich revives all Skeletons",
				lighthouse: "The Hydra moves up to 2 regions",
				heart: "Heart of the Ocean: Hydra power rises to 25",
				church: "Endgame: +2 VP per Hydra summon",
				dam: "Endgame: +1 VP per lake region on the map",
				mine: "Pay 3 any resources to a co-located player to avoid battle",
				geyser: "After moving, pay 1 move point to turn this region into a lake",
				ship: "Gaining an artifact circles 1 note",
				feeder: "Wood and iron serpent rates drop by 1",
				palace: "Endgame: +1 VP per building on foundations",
				reef: "Serpents no longer weaken the Hydra",
				idol: "Winning any battle grants 2 rage",
				dump: "Building on a foundation grants 2 rage",
				arena: "Recruiting a Charger grants 1 rage",
				camp: "Recruits Scouts; Scouts count as power 4 in mountains",
				chiefhouse: "After the plan is revealed, pay rage to raise a level",
				stable: "Entering mountains costs 1 move point",
				gym: "Recruits Chargers",
				trophyhall: "Endgame: +1 VP per 2 visited regions",
				catapult: "Army total power +4 in battle",
				workshop: "Recruits Bombers; they count as 12 against fortresses"
			},
			err: {
				phase: "Not allowed in the current phase",
				picked: "Already chosen",
				factionTaken: "That faction is taken",
				notPortal: "The starting region must be a portal",
				regionTaken: "That region is occupied",
				badPlan: "Assign levels one to four to four different actions",
				noBoost: "That action is not planned this round",
				noRage: "Not enough rage",
				already: "Already submitted",
				noBuilding: "Cannot build that building now",
				noFree: "No free-build token available",
				badFoundation: "That foundation slot is unavailable",
				noRecruit: "Cannot recruit that unit now",
				noRes: "Not enough resources",
				badIllusion: "That target cannot be blocked",
				badCurse: "That region cannot be cursed",
				badConvert: "Invalid conversion amount",
				badAny: "Wrong number of any-resources",
				noHydra: "Cannot summon or move the Hydra now",
				badDest: "Cannot go there",
				noBudget: "Not enough move points",
				notMember: "You are not part of this encounter",
				badDeclare: "Invalid declaration",
				badDeploy: "Invalid deployment",
				badReward: "Invalid reward choice",
				noFortress: "Cannot attack that fortress now",
				noMonster: "Cannot fight that monster now",
				noArtifact: "Cannot claim that artifact now",
				stoleArtifact: "You already stole an artifact this round",
				fortressXorArtifact: "Choose either the fortress or the artifact"
			},
			ui: {
				round: "Round {{n}} / 16",
				phasePick: "Pick a faction",
				phaseStart: "Pick a starting region",
				phasePlan: "Programming",
				phaseBoost: "Chief House boost",
				phaseExec: "Executing",
				pickPrompt: "Pick your faction, first come first served",
				startPrompt: "Pick a portal region as your start",
				startWait: "Waiting for {{name}} to pick a start…",
				planPrompt: "Assign levels one to four to four actions, each once",
				planWait: "Waiting for {{name}} to program…",
				planNone: "Skip",
				submit: "Submit",
				waiting: "Waiting for other players…",
				boostPrompt: "Pay 1 rage to raise an action level by 1, or pass",
				boostPass: "Pass",
				boostPlus: "{{action}} +1",
				execLine: "Level {{n}} · {{action}}",
				stageBuild: "Build and recruit",
				buildNone: "No building this round",
				buildFree: "Use a free-build token",
				recruitLabel: "Recruit",
				stageMove: "Pick a destination",
				stay: "Stay put",
				moveBudget: "{{n}} move points",
				stageDeclare: "Encounter",
				declarePrompt: "An encounter here: declare war or peace",
				declareFight: "War",
				declarePeace: "Peace",
				wantFortress: "Want the fortress",
				wantArtifact: "Want the artifact",
				stageYield: "Contested claim",
				yieldPrompt: "Several players want the same target: yield or insist?",
				yieldGive: "Yield",
				yieldStick: "Insist",
				stageDeploy: "Deploy for battle",
				deployPrompt: "Commit units to battle; all committed units die",
				deployAll: "Commit everything",
				stageReward: "Battle reward",
				rewardPrompt: "Choose your victory reward",
				rewardRes: "Take the monster-printed resources",
				rewardLoot: "Loot {{n}} resources from {{name}}",
				rewardArtifact: "Steal an artifact",
				stagePost: "After-move actions",
				postFortress: "Storm the fortress, defense {{n}}",
				postMonster: "Fight {{name}}, power {{n}}",
				postArtifact: "Claim the artifact",
				postSkip: "Skip",
				chapelToggle: "Chapel: auto-trade 3 iron for an Executioner",
				myBoard: "My board",
				unitsLabel: "Units",
				buildingsLabel: "Buildings",
				mapLabel: "Map",
				cursed: "Cursed",
				fortressShort: "Fortress {{n}}",
				scienceShort: "Science",
				rageShort: "Rage",
				notesShort: "Notes",
				logTitle: "Battle log",
				logLine: "{{region}}: {{name}} wins",
				logDraw: "{{region}}: tie, everyone falls",
				hydra: "Hydra",
				planOf: "Program this round",
				journal: {
					allLogs: "Full log",
					shortLogs: "Log",
					title: "Full action log",
					close: "Close log",
					return: "Close log · Return to game",
					returnResult: "Close log · Return to results",
					count: "{{n}} public entries",
					empty: "No public actions yet",
					noEntries: "No actions match these filters",
					allRounds: "All rounds",
					allPlayers: "All players",
					round: "Round {{n}}",
					roundFilter: "Filter log by round",
					playerFilter: "Filter log by player",
					groupSetup: "Round {{round}} · Setup and plan",
					groupLevel: "Round {{round}} · Level {{level}}",
					currentSubmissions: "Current submissions",
					submitted: "Submitted",
					waiting: "Waiting",
					pendingCount: "{{done}} / {{total}} players submitted",
					pick: "Chose the {{faction}} faction",
					start: "Started in {{region}}",
					plan: "Published action order: {{sequence}}",
					boost: "Spent rage to raise {{action}} by {{amount}} levels",
					boostPass: "Passed on action boost",
					collect: "Used {{action}} for {{amount}} base resources",
					build: "Built {{building}}",
					recruit: "Recruited {{units}}",
					library: "Used the Library ability",
					illusion: "Placed an illusion in {{region}}",
					curse: "Cursed {{region}}",
					buildPass: "Did not build or recruit at this level",
					move: "Moved from {{from}} to {{to}}",
					stay: "Stayed in {{region}}",
					declareFight: "Declared war in the encounter",
					declarePeace: "Chose peace in the encounter",
					claimFortress: "Claimed the fortress",
					claimArtifact: "Claimed the artifact",
					bribe: "Offered a bribe to {{name}}",
					insist: "Insisted on the claim in {{region}}",
					yield: "Yielded the claim in {{region}}",
					deploy: "Deployed {{units}} in {{region}}",
					noUnits: "no units",
					rewardRes: "Chose battle resource reward",
					rewardLoot: "Looted resources from {{name}}",
					rewardArtifact: "Took the {{artifact}} artifact",
					postFortress: "Stormed the fortress",
					postMonster: "Fought a monster",
					postArtifact: "Claimed an artifact",
					postPass: "Skipped after-move actions",
					chapelOn: "Enabled automatic Chapel exchange",
					chapelOff: "Disabled automatic Chapel exchange",
					builtResult: "Built: {{building}}",
					artifactGain: "Gained {{artifact}}",
					artifactLoss: "Lost {{artifact}}",
					fortressGain: "Captured the fortress in {{region}}",
					monsterWin: "Defeated {{monster}}",
					battleWin: "Power {{power}} · Victory",
					battleLoss: "Power {{power}} · Lost to {{name}}",
					battleTie: "Power {{power}} · Tie",
					viewMap: "View map",
					backFromMap: "Return to current board"
				},
				visual: {
					actionTray: "Action tokens",
					planBoard: "This round's action order",
					emptySlot: "Empty",
					roundShort: "Round",
					selectAbove: "Choose an action on the board above",
					scienceTrack: "Build upward through four tiers",
					wood: "Wood",
					iron: "Iron",
					gold: "Gold",
					chooseAction: "Pick an action, then place it in a level 1–4 slot",
					levelSlot: "Level {{n}}",
					unused: "Not played this round",
					publishPlan: "Publish action order",
					treeTitle: "Gnome development tree",
					built: "Built",
					selected: "Selected",
					needLevel: "Action level too low",
					needPrereq: "Build a prerequisite first",
					needResources: "Not enough resources",
					foundation: "Foundation {{n}}",
					routeCost: "Path cost {{n}} / {{budget}}",
					firstVisit: "First visit reward",
					unreachable: "Out of reach this round",
					chooseDestination: "Choose a destination on the map",
					confirmMove: "Submit destination secretly",
					currentRegion: "You are here",
					returnToMe: "Center on my location",
					zoomIn: "Zoom in",
					zoomOut: "Zoom out",
					autoResources: "Flexible resources split across wood, iron, gold",
					waitingFor: "Waiting for {{name}}"
				}
			}
		}
	}
};
//#endregion
export { tn as default };
