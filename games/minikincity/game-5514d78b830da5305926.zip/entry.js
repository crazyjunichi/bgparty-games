import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { IconClose as l, IconInfo as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { Texture as f } from "@bgparty/sdk/texture";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { seatName as te } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchor as m } from "@bgparty/sdk/fx/anchors";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Floater as v, FlySprite as y, PulseBox as ne } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as b } from "@bgparty/sdk/confirm-button";
import { Confetti as re } from "@bgparty/sdk/ui/confetti";
import { OptionSwitch as ie } from "@bgparty/sdk/ui/game-options";
//#region src/games/minikincity/data.ts
var x = (e, t, n, r) => ({
	reward: e,
	per: t,
	require: n,
	divisor: r
}), S = (e, t, n, r) => x({ vp: e }, t, n, r), C = (e, t, n) => x({ pawns: e }, t, n), w = (e, t, n, r, i, a) => ({
	id: `${e}${t}`,
	color: e,
	value: t,
	symbols: n,
	slots: r,
	score: i,
	instant: a,
	atlas: e === "r" ? t - 1 : e === "g" ? t <= 10 ? 30 - t : t + 19 : e === "b" ? t + 39 : 60
}), T = [
	w("r", 1, "LD", 2, S(9, void 0, { book: 5 })),
	w("r", 2, "HH", 0, void 0, C(1, "heart")),
	w("r", 3, "SD", 2, S(9, void 0, { smile: 6 })),
	w("r", 4, "D", 5, x({ cockade: 2 })),
	w("r", 5, "DD", 2, S(1, "r")),
	w("r", 6, "SS", 3, S(1, "smile")),
	w("r", 7, "L", 2, S(5, void 0, { sets: 2 })),
	w("r", 8, "SH", 2, S(1, "b")),
	w("r", 9, "D", 3, S(5, void 0, { bag: 5 })),
	w("r", 10, "S", 2, S(7, void 0, {
		bag: 5,
		heart: 2
	})),
	w("r", 11, "HSL", 5, S(1, "pawns", void 0, 3)),
	w("r", 12, "LD", 0, void 0, C(2, void 0, { smile: 3 })),
	w("r", 13, "", 0, void 0, x({ bonus: 2 }, void 0, { symbols: 1 })),
	w("r", 14, "SH", 3, S(1, "heart")),
	w("r", 15, "", 2, S(1, "smile")),
	w("r", 16, "S", 3, S(1, "cockade")),
	w("r", 17, "D", 3, x({ cockade: 1 })),
	w("r", 18, "", 1, x({ cockade: 1 }, void 0, { book: 3 })),
	w("r", 19, "H", 0, void 0, x({ bonus: 1 }, void 0, { symbols: 1 })),
	w("r", 20, "L", 2, S(2, void 0, { symbols: 1 })),
	w("g", 1, "LL", 4, S(2, "book")),
	w("g", 2, "L", 2, S(6, void 0, { symbols: 1 })),
	w("g", 3, "SD", 0, void 0, x({
		pawns: 2,
		bonus: 1
	})),
	w("g", 4, "SL", 2, S(1, "bag")),
	w("g", 5, "D", 0, void 0, C(1, "types")),
	w("g", 6, "SD", 5, S(3, "instant")),
	w("g", 7, "D", 2, S(1, "g")),
	w("g", 8, "D", 3, S(1, "bag")),
	w("g", 9, "SSL", 4, S(7, void 0, {
		book: 4,
		smile: 3
	})),
	w("g", 10, "SD", 0, void 0, C(2, void 0, { bag: 3 })),
	w("g", 11, "", 2, S(7, void 0, { heart: 3 })),
	w("g", 12, "SD", 0, void 0, C(1)),
	w("g", 13, "D", 1, S(4, void 0, {
		bag: 5,
		book: 3
	})),
	w("g", 14, "", 1, S(6, void 0, {
		smile: 4,
		heart: 2
	})),
	w("g", 15, "H", 0, void 0, C(2, void 0, { heart: 2 })),
	w("g", 16, "LD", 3, S(3, void 0, { smile: 4 })),
	w("g", 17, "", 1, S(1, "bonuses")),
	w("g", 18, "S", 0, void 0, C(1, "b")),
	w("g", 19, "D", 1, S(2, void 0, { instant: 3 })),
	w("g", 20, "DD", 0),
	w("b", 1, "", 3, S(3, "low")),
	w("b", 2, "S", 0, void 0, C(4)),
	w("b", 3, "D", 2, S(3, "sets")),
	w("b", 4, "H", 3, S(2, "heart")),
	w("b", 5, "LHSD", 0),
	w("b", 6, "", 0, void 0, x({
		pawns: 2,
		bonus: 1
	})),
	w("b", 7, "DD", 2, S(5, void 0, { g: 4 })),
	w("b", 8, "L", 0, void 0, C(3, void 0, { book: 2 })),
	w("b", 9, "H", 2, S(1, "mid")),
	w("b", 10, "", 4, S(4, "symbols")),
	w("b", 11, "", 1, S(4, void 0, { b: 4 })),
	w("b", 12, "D", 5, S(2, "high")),
	w("b", 13, "", 2, S(7, void 0, { bag: 6 })),
	w("b", 14, "", 0, void 0, C(1, "instant")),
	w("b", 15, "", 1, x({ cockade: 1 })),
	w("b", 16, "L", 0, void 0, x({ bonus: 1 }, void 0, { cockade: 1 })),
	w("b", 17, "S", 3, S(1, "book")),
	w("b", 18, "L", 2, S(3, void 0, { r: 4 })),
	w("b", 19, "S", 3, S(1, "top")),
	w("b", 20, "", 0, void 0, C(1)),
	w("n", 21, "", 0),
	{
		...w("r", 0, "", 0, void 0, C(6)),
		atlas: 62
	},
	{
		...w("g", 0, "", 2, S(1, "book")),
		extraScore: S(1, "smile"),
		atlas: 63
	},
	{
		...w("b", 0, "", 2, S(1, "bag")),
		extraScore: S(1, "heart"),
		atlas: 64
	}
], E = Object.fromEntries(T.map((e) => [e.id, e])), D = [
	"bluePawns",
	"greenPawns",
	"redPawns",
	"wild",
	"heart",
	"points",
	"cockade",
	"smile",
	"bag",
	"book"
], O = {
	points: { vp: 2 },
	cockade: { cockade: 1 }
}, k = {
	bluePawns: C(1, "b"),
	greenPawns: C(1, "g"),
	redPawns: C(1, "r")
}, A = (e = 0, t = 0, n = 0, r = 0) => ({
	pawns: e,
	vp: t,
	cockade: n,
	bonus: r
}), ae = {
	2: [
		[A(0, 4, 0, 1), A()],
		[A(4, 0, 1), A()],
		[A(2, 4), A()],
		[A(4, 0, 0, 1), A()],
		[A(2, 0, 1, 1), A()],
		[A(0, 6), A()],
		[A(2, 2, 1), A()],
		[A(3, 3), A()],
		[A(1, 0, 2), A()]
	],
	3: [
		[
			A(0, 4, 0, 1),
			A(0, 3),
			A()
		],
		[
			A(4, 0, 1),
			A(2, 1),
			A()
		],
		[
			A(2, 4),
			A(1, 2),
			A()
		],
		[
			A(4, 0, 0, 1),
			A(2, 1),
			A()
		],
		[
			A(2, 0, 1, 1),
			A(0, 1, 1),
			A()
		],
		[
			A(0, 6),
			A(0, 3),
			A()
		],
		[
			A(2, 2, 1),
			A(1, 2),
			A()
		],
		[
			A(3, 3),
			A(0, 3),
			A()
		],
		[
			A(1, 0, 2),
			A(0, 1, 1),
			A()
		]
	],
	4: [
		[
			A(0, 4, 0, 1),
			A(0, 4),
			A(0, 2),
			A()
		],
		[
			A(4, 0, 1),
			A(2, 2),
			A(2),
			A()
		],
		[
			A(2, 4),
			A(1, 3),
			A(0, 2),
			A()
		],
		[
			A(4, 0, 0, 1),
			A(3, 1),
			A(1, 1),
			A()
		],
		[
			A(2, 0, 1, 1),
			A(1, 1, 1),
			A(0, 0, 1),
			A()
		],
		[
			A(0, 6),
			A(0, 4),
			A(0, 2),
			A()
		],
		[
			A(2, 2, 1),
			A(2, 0, 1),
			A(0, 2),
			A()
		],
		[
			A(3, 3),
			A(1, 3),
			A(0, 2),
			A()
		],
		[
			A(1, 0, 2),
			A(0, 2, 1),
			A(1, 1),
			A()
		]
	],
	5: [
		[
			A(0, 4, 0, 1),
			A(0, 0, 1),
			A(0, 2),
			A(0, 1),
			A()
		],
		[
			A(4, 0, 1),
			A(3, 1),
			A(2),
			A(1),
			A()
		],
		[
			A(2, 4),
			A(1, 3),
			A(0, 2),
			A(1),
			A()
		],
		[
			A(4, 0, 0, 1),
			A(3, 1),
			A(2),
			A(1),
			A()
		],
		[
			A(2, 0, 1, 1),
			A(1, 1, 1),
			A(0, 0, 1),
			A(1),
			A()
		],
		[
			A(0, 6),
			A(0, 4),
			A(0, 2),
			A(0, 1),
			A()
		],
		[
			A(2, 2, 1),
			A(2, 0, 1),
			A(0, 2),
			A(0, 1),
			A()
		],
		[
			A(3, 3),
			A(1, 3),
			A(1, 1),
			A(1),
			A()
		],
		[
			A(1, 0, 2),
			A(0, 2, 1),
			A(0, 0, 1),
			A(1),
			A()
		]
	]
}, j = (e) => [
	"r",
	"b",
	"g"
][Math.floor(e / 3)], oe = (e, t) => (e >= 4 ? 18 : 0) + (e % 2 == 1 ? 3 : 0) + Math.floor(t / 3) * 6 + t % 3, se = {
	2: [A(3), A(2)],
	3: [
		A(3),
		A(2, 2),
		A(2)
	],
	4: [
		A(3),
		A(2, 0, 1),
		A(2, 1),
		A(1)
	],
	5: [
		A(3),
		A(2, 0, 1),
		A(2, 1),
		A(1),
		A()
	]
}, ce = {
	id: "minikincity",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"drafting",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.minikincity.name",
	descKey: "games.minikincity.desc",
	rulesKey: "games.minikincity.rules",
	icon: "🏡",
	iconImg: "games/minikincity.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/1010/2246/6379/files/Minikin_City_Rules_ENG_compressed_68709b69-fce1-4342-9553-3ebb57167c2b.pdf?v=1784709890" },
	minPlayers: 2,
	maxPlayers: 5,
	accent: "#326c61",
	releasedAt: "2026-10-31T00:42:34+08:00",
	search: {
		py: "xiao cheng da zuo",
		init: "xcdz"
	},
	hotseat: "cover",
	botDelayMs: 550
}, M = t.string().regex(/^(?:[rgb](?:[0-9]|1[0-9]|20)|n21)$/), N = t.object({ musicFestival: t.boolean().default(!1) }).prefault({}), P = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("keep"),
		cards: t.array(M).length(4)
	}),
	t.object({
		type: t.literal("play"),
		card: M
	}),
	t.object({
		type: t.literal("draft"),
		card: M
	}),
	t.object({
		type: t.literal("allocate"),
		card: M
	}),
	t.object({
		type: t.literal("bonus"),
		bonus: t.enum(D)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), le = t.object({
	id: M,
	pawns: t.int().nonnegative()
}), F = t.object({
	rewards: t.int(),
	city: t.int(),
	cockades: t.int(),
	total: t.int(),
	cards: t.record(t.string(), t.int()),
	cockadeCount: t.int()
}), ue = t.object({
	phase: t.enum([
		"keep",
		"play",
		"allocate",
		"bonus",
		"draft",
		"extra",
		"settle",
		"done"
	]),
	turn: t.string(),
	round: t.int(),
	lead: t.string(),
	rewards: t.array(t.int().min(0).max(8)).length(9),
	market: t.array(M),
	availableBonus: t.array(t.enum(D)),
	supply: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	ranking: t.array(t.string()),
	history: t.array(t.array(t.string())),
	finalRanking: t.array(t.string()),
	finalValues: t.record(t.string(), t.int()),
	pendingBonus: t.int().nonnegative(),
	finalRevealed: t.boolean(),
	players: t.array(t.object({
		rid: t.string(),
		city: t.array(le),
		reserve: t.int().nonnegative(),
		bonuses: t.array(t.enum(D)),
		rewardVP: t.int().nonnegative(),
		rewardCockades: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		kept: t.boolean(),
		hand: t.array(M).nullable(),
		score: F
	})),
	last: t.object({
		kind: t.enum([
			"play",
			"draft",
			"bonus",
			"allocate",
			"reward",
			"reveal",
			"final",
			"keep",
			"fill",
			"gain",
			"return",
			"showHand"
		]),
		rid: t.string(),
		card: M.optional(),
		bonus: t.enum(D).optional(),
		n: t.int().optional(),
		vp: t.int().optional(),
		cockade: t.int().optional()
	}).nullable()
}), de = t.object({ hand: t.array(M) }), fe = () => ({
	rewards: 0,
	city: 0,
	cockades: 0,
	total: 0,
	cards: {},
	cockadeCount: 0
});
function I(e) {
	let t = {
		book: 0,
		heart: 0,
		smile: 0,
		bag: 0,
		r: 0,
		g: 0,
		b: 0,
		sets: 0,
		symbols: 0,
		types: 0,
		instant: 0,
		pawns: e.reserve,
		bonuses: e.bonuses.length,
		cockade: e.rewardCockades,
		low: 0,
		mid: 0,
		high: 0,
		top: 0
	};
	for (let n of e.city) {
		let e = E[n.id];
		for (let n of e.symbols) t[{
			L: "book",
			H: "heart",
			S: "smile",
			D: "bag"
		}[n]] += 1;
		e.color !== "n" && (t[e.color] += 1), e.instant && (t.instant += 1), e.value >= 1 && e.value <= 20 && (t[e.value <= 5 ? "low" : e.value <= 10 ? "mid" : e.value <= 15 ? "high" : "top"] += 1), t.pawns += n.pawns;
	}
	for (let n of e.bonuses) (n === "book" || n === "heart" || n === "smile" || n === "bag") && (t[n] += 1);
	let n = +!!e.bonuses.includes("wild");
	for (; [
		"r",
		"g",
		"b"
	].reduce((e, n) => e + Math.max(0, t.sets + 1 - t[n]), 0) <= n;) t.sets += 1;
	t.r += n, t.g += n, t.b += n, t.symbols = Math.min(t.book, t.heart, t.smile, t.bag), t.types = [
		t.book,
		t.heart,
		t.smile,
		t.bag
	].filter((e) => e > 0).length, t.cockade += +!!e.bonuses.includes("cockade");
	for (let n of e.city) {
		let e = E[n.id];
		e.score?.reward.cockade && n.pawns === e.slots && (t.cockade += L(e.score, t).cockade ?? 0);
	}
	return t;
}
function L(e, t) {
	if (!e || Object.entries(e.require ?? {}).some(([e, n]) => t[e] < n)) return {};
	let n = e.per ? Math.floor(t[e.per] / (e.divisor ?? 1)) : 1;
	return Object.fromEntries(Object.entries(e.reward).map(([e, t]) => [e, t * n]));
}
function R(e) {
	let t = I(e), n = fe();
	n.rewards = e.rewardVP + (e.bonuses.includes("points") ? 2 : 0), n.cockadeCount = t.cockade, n.cockades = [
		0,
		1,
		3,
		6,
		10,
		15,
		21
	][Math.min(6, t.cockade)];
	for (let r of e.city) {
		let e = E[r.id], i = e.slots > 0 && r.pawns === e.slots ? (L(e.score, t).vp ?? 0) + (L(e.extraScore, t).vp ?? 0) : 0;
		n.cards[r.id] = i, n.city += i;
	}
	return n.total = n.rewards + n.city + n.cockades, n;
}
var z = (e, t = e.turn) => e.players.find((e) => e.rid === t), B = (e) => e.city.some((e) => e.pawns < E[e.id].slots);
function V(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function H(e, t, n) {
	return e.last = t, e.resume = n, e.phase = "settle", [{
		kind: t.kind,
		rid: t.rid,
		data: {
			...t,
			round: e.round,
			final: e.finalRevealed,
			position: e.rewardIndex + 1,
			cards: t.kind === "reveal" ? e.market : t.kind === "showHand" ? z(e, t.rid).hand : []
		}
	}];
}
function U(e, t, n) {
	let r = Math.min(e.supply, n.pawns ?? 0);
	return t.reserve += r, e.supply -= r, t.rewardVP += n.vp ?? 0, t.rewardCockades += n.cockade ?? 0, e.pendingBonus += n.bonus ?? 0, r;
}
function W(e) {
	return e.market = e.deck.splice(0, e.players.length + 1), e.played = [], e.turn = e.lead, e.ranking = [], H(e, {
		kind: "reveal",
		rid: e.turn
	}, "beginPlay");
}
function G(e, t = !1) {
	let n = j(e.rewards[t ? 8 : e.round - 1]), r = Array.from({ length: e.players.length }, (t, n) => e.players[(e.players.findIndex((t) => t.rid === e.lead) + n) % e.players.length].rid);
	if (t) {
		for (let t of e.players) e.finalValues[t.rid] = t.hand.reduce((e, t) => e + (E[t].color === n ? E[t].value : 0), 0);
		return r.sort((t, n) => e.finalValues[n] - e.finalValues[t]);
	}
	let i = (t) => {
		let r = E[z(e, t).city.at(-1).id];
		return r.value === 21 ? 100 : r.value + (r.color === n ? 30 : 0);
	};
	return r.sort((e, t) => i(t) - i(e));
}
function K(e, t = !1) {
	e.turn = (t ? e.finalRanking : e.ranking)[e.rewardIndex];
	let n = z(e), r = t ? se[e.players.length][e.rewardIndex] : ae[e.players.length][e.rewards[e.round - 1]][e.rewardIndex], i = U(e, n, r);
	return H(e, {
		kind: "reward",
		rid: n.rid,
		n: i,
		vp: r.vp,
		cockade: r.cockade
	}, t ? "afterFinalReward" : "afterReward");
}
function pe(e) {
	let t = z(e), n = t.city.at(-1), r = L(E[n.id].instant, I(t)), i = U(e, t, r);
	return i || r.vp || r.cockade || r.bonus ? H(e, {
		kind: "gain",
		rid: t.rid,
		card: n.id,
		n: i,
		vp: r.vp,
		cockade: r.cockade
	}, "afterGain") : (e.resume = e.playExtra ? "afterExtra" : "afterPlay", me(e));
}
function me(e) {
	let t = z(e);
	if (e.resume === "afterCard") {
		let n = t.city.at(-1), r = Math.min(t.reserve, E[n.id].slots);
		return n.pawns = r, t.reserve -= r, r ? H(e, {
			kind: "fill",
			rid: t.rid,
			card: n.id,
			n: r
		}, "afterFill") : pe(e);
	}
	if (e.resume === "afterFill") return pe(e);
	if (e.resume === "afterGain" && (e.resume = e.playExtra ? "afterExtra" : "afterPlay"), t.reserve > 0 && B(t)) return e.phase = "allocate", [];
	if (e.pendingBonus > 0 && e.availableBonus.length) return e.phase = "bonus", [];
	switch (e.pendingBonus = 0, e.resume) {
		case "afterKeep": {
			let t = e.players.find((e) => !e.kept);
			return t ? (e.turn = t.rid, e.phase = "keep", []) : W(e);
		}
		case "beginPlay": return e.phase = "play", [];
		case "afterPlay": return e.played.length < e.players.length ? (e.turn = e.players[(e.players.findIndex((t) => t.rid === e.turn) + 1) % e.players.length].rid, e.phase = "play", []) : (e.ranking = G(e), e.history.push([...e.ranking]), e.rewardIndex = 0, H(e, {
			kind: "final",
			rid: e.ranking[0]
		}, "beginRewards"));
		case "beginRewards": return K(e);
		case "afterReward": return e.rewardIndex += 1, e.rewardIndex < e.players.length ? K(e) : (e.turn = e.ranking.at(-1), e.phase = "draft", []);
		case "afterDraft": {
			let t = e.ranking.indexOf(e.turn);
			if (t > 0) return e.turn = e.ranking[t - 1], e.phase = "draft", [];
			let n = e.market[0];
			return e.deck.push(...e.market), e.market = [], H(e, {
				kind: "return",
				rid: e.turn,
				card: n
			}, "nextRound");
		}
		case "nextRound": return e.lead = e.ranking[0], e.round < 8 ? (e.round++, W(e)) : H(e, {
			kind: "final",
			rid: e.lead
		}, "beginFinal");
		case "beginFinal": return e.finalRevealed = !0, e.revealed = [], e.resume = "revealNext", me(e);
		case "revealNext":
			if (e.revealed.length < e.players.length) {
				let t = (e.players.findIndex((t) => t.rid === e.lead) + e.revealed.length) % e.players.length, n = e.players[t].rid;
				return e.revealed.push(n), e.finalValues[n] = e.players[t].hand.reduce((t, n) => t + (E[n].color === j(e.rewards[8]) ? E[n].value : 0), 0), H(e, {
					kind: "showHand",
					rid: n
				}, "revealNext");
			}
			return e.finalRanking = G(e, !0), e.rewardIndex = 0, H(e, {
				kind: "final",
				rid: e.finalRanking[0]
			}, "beginFinalRewards");
		case "beginFinalRewards": return K(e, !0);
		case "afterFinalReward": return e.rewardIndex += 1, e.rewardIndex < e.players.length ? K(e, !0) : (e.turn = e.finalRanking[0], e.phase = "extra", []);
		case "afterExtra": return e.phase = "done", [];
	}
}
var he = {
	meta: ce,
	saveCompatibility: { version: "2" },
	schemas: {
		action: P,
		publicView: ue,
		privateView: de,
		config: N
	},
	setup(t, n, r) {
		let i = {
			seed: r,
			cursor: 0,
			players: n.map((e) => ({
				rid: e,
				hand: [],
				city: [],
				reserve: 0,
				bonuses: [],
				rewardVP: 0,
				rewardCockades: 0,
				kept: !1
			})),
			deck: [],
			rewards: [],
			market: [],
			availableBonus: [...D],
			supply: 75,
			phase: "keep",
			turn: n[0],
			round: 1,
			lead: n[0],
			ranking: [],
			history: [],
			finalRanking: [],
			finalValues: {},
			finalRevealed: !1,
			pendingBonus: 0,
			resume: "afterKeep",
			last: null,
			rewardIndex: 0,
			played: [],
			playExtra: !1,
			revealed: []
		};
		i.deck = V(i, T.filter((e) => e.value !== 0 || t.musicFestival).map((e) => e.id)), i.rewards = V(i, Array.from({ length: 9 }, (e, t) => t));
		for (let e of i.players) e.hand = i.deck.splice(0, 6);
		return i.lead = n[e(r, i.cursor++, n.length)], i.turn = i.lead, {
			state: i,
			fx: []
		};
	},
	reduce(e, t, n) {
		let r = { code: "games.minikincity.errAction" };
		if (t.type === "tick") {
			if (e.phase !== "settle") return {
				state: e,
				fx: []
			};
			let t = structuredClone(e);
			return {
				state: t,
				fx: me(t)
			};
		}
		if (e.phase === "done" || e.phase === "settle" || n.by !== e.turn) return r;
		let i = structuredClone(e), a = z(i), o;
		if (t.type === "keep" && i.phase === "keep") {
			if (new Set(t.cards).size !== 4 || t.cards.some((e) => !a.hand.includes(e))) return r;
			i.deck.push(...a.hand.filter((e) => !t.cards.includes(e))), a.hand = [...t.cards], a.kept = !0, o = H(i, {
				kind: "keep",
				rid: a.rid,
				n: 2
			}, "afterKeep");
		} else if (t.type === "play" && (i.phase === "play" || i.phase === "extra")) {
			if (!a.hand.includes(t.card)) return r;
			let e = a.hand.indexOf(t.card);
			i.playExtra = i.phase === "extra", a.hand.splice(e, 1), a.city.push({
				id: t.card,
				pawns: 0
			}), i.playExtra || i.played.push(a.rid), o = H(i, {
				kind: "play",
				rid: a.rid,
				card: t.card,
				n: e
			}, "afterCard");
		} else if (t.type === "allocate" && i.phase === "allocate") {
			let e = a.city.find((e) => e.id === t.card);
			if (!e || e.pawns >= E[e.id].slots || a.reserve < 1) return r;
			a.reserve--, e.pawns++, o = H(i, {
				kind: "allocate",
				rid: a.rid,
				card: t.card,
				n: e.pawns
			}, i.resume);
		} else if (t.type === "bonus" && i.phase === "bonus") {
			if (!i.availableBonus.includes(t.bonus)) return r;
			i.availableBonus.splice(i.availableBonus.indexOf(t.bonus), 1), i.pendingBonus--, a.bonuses.push(t.bonus);
			let e = U(i, a, L(k[t.bonus], I(a)));
			o = H(i, {
				kind: "bonus",
				rid: a.rid,
				bonus: t.bonus,
				n: e
			}, i.resume);
		} else if (t.type === "draft" && i.phase === "draft") {
			if (!i.market.includes(t.card)) return r;
			i.market.splice(i.market.indexOf(t.card), 1), a.hand.push(t.card), o = H(i, {
				kind: "draft",
				rid: a.rid,
				card: t.card
			}, "afterDraft");
		} else return r;
		return {
			state: i,
			fx: o
		};
	},
	viewFor(e, t) {
		return {
			public: {
				phase: e.phase,
				turn: e.turn,
				round: e.round,
				lead: e.lead,
				rewards: e.rewards,
				market: e.market,
				availableBonus: e.availableBonus,
				supply: e.supply,
				deckCount: e.deck.length,
				ranking: e.ranking,
				history: e.history,
				finalRanking: e.finalRanking,
				finalValues: e.finalValues,
				pendingBonus: e.pendingBonus,
				finalRevealed: e.finalRevealed,
				last: e.last,
				players: e.players.map((t) => ({
					rid: t.rid,
					city: t.city,
					reserve: t.reserve,
					bonuses: t.bonuses,
					rewardVP: t.rewardVP,
					rewardCockades: t.rewardCockades,
					handCount: t.hand.length,
					kept: t.kept,
					hand: e.revealed.includes(t.rid) ? t.hand : null,
					score: R(t)
				}))
			},
			private: { hand: e.players.find((e) => e.rid === t)?.hand ?? [] }
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((e) => [e.rid, R(e).total])), n = e.players.map((e) => e.rid).sort((n, r) => t[r] - t[n] || z(e, r).reserve - z(e, n).reserve), r = n[0];
		return {
			phase: "done",
			ranking: n,
			scores: t,
			winner: n.filter((n) => t[n] === t[r] && z(e, n).reserve === z(e, r).reserve)
		};
	},
	nextTickIn: (e) => e.phase === "settle" ? 480 : null
}, ge = {
	book: "games.minikincity.book",
	heart: "games.minikincity.heart",
	smile: "games.minikincity.smile",
	bag: "games.minikincity.bag",
	r: "games.minikincity.r",
	g: "games.minikincity.g",
	b: "games.minikincity.b",
	sets: "games.minikincity.sets",
	symbols: "games.minikincity.symbols",
	types: "games.minikincity.types",
	instant: "games.minikincity.instant",
	pawns: "games.minikincity.pawns",
	bonuses: "games.minikincity.bonuses",
	cockade: "games.minikincity.cockade",
	low: "games.minikincity.low",
	mid: "games.minikincity.mid",
	high: "games.minikincity.high",
	top: "games.minikincity.top"
}, q = {
	r: "games.minikincity.r",
	g: "games.minikincity.g",
	b: "games.minikincity.b",
	n: "games.minikincity.n"
}, _e = {
	bluePawns: "games.minikincity.bluePawns",
	greenPawns: "games.minikincity.greenPawns",
	redPawns: "games.minikincity.redPawns",
	wild: "games.minikincity.wild",
	heart: "games.minikincity.bonusHeart",
	points: "games.minikincity.points",
	cockade: "games.minikincity.bonusCockade",
	smile: "games.minikincity.bonusSmile",
	bag: "games.minikincity.bonusBag",
	book: "games.minikincity.bonusBook"
}, ve = {
	book: "games.minikincity.countBook",
	heart: "games.minikincity.countHeart",
	smile: "games.minikincity.countSmile",
	bag: "games.minikincity.countBag",
	r: "games.minikincity.countRed",
	g: "games.minikincity.countGreen",
	b: "games.minikincity.countBlue",
	sets: "games.minikincity.countSets",
	symbols: "games.minikincity.countSymbols",
	types: "games.minikincity.countTypes",
	instant: "games.minikincity.countInstant",
	pawns: "games.minikincity.countPawns",
	bonuses: "games.minikincity.countBonuses",
	cockade: "games.minikincity.countCockades",
	low: "games.minikincity.countLow",
	mid: "games.minikincity.countMid",
	high: "games.minikincity.countHigh",
	top: "games.minikincity.countTop",
	vp: "games.minikincity.countVp"
};
function ye() {
	let e = s(), t = (t, n) => e(ve[t], {
		n,
		plural: n === 1 ? "" : "s"
	}), n = (e) => Object.entries(e).filter(([, e]) => e).map(([e, n]) => t(e === "bonus" ? "bonuses" : e, n)).join(" · ");
	return {
		t: e,
		reward: n,
		effect: (r) => {
			if (!r) return e("games.minikincity.noEffect");
			let i = e("games.minikincity.gain", { reward: n(r.reward) });
			return r.per && (i = e("games.minikincity.per", {
				quantity: t(r.per, r.divisor ?? 1),
				reward: i
			})), r.require && (i = e("games.minikincity.condition", {
				condition: Object.entries(r.require).map(([e, n]) => t(e, n)).join(" · "),
				reward: i
			})), i;
		}
	};
}
//#endregion
//#region src/games/minikincity/art.tsx
var J = (e) => `games/minikincity/${e}.svg`;
function Y({ kind: e }) {
	return /* @__PURE__ */ g("img", {
		className: "mc-icon",
		src: J(`icon-${e}`),
		alt: ""
	});
}
function X({ id: e }) {
	return /* @__PURE__ */ g("img", {
		className: "mc-card-image",
		src: J(e),
		alt: "",
		draggable: !1
	});
}
var be = {
	1: [[49.5, 65.8]],
	2: [[39.5, 65], [59, 65.2]],
	3: [
		[32.3, 63.5],
		[66.3, 63.7],
		[49.3, 67.7]
	],
	4: [
		[20.5, 62.8],
		[77.7, 62.8],
		[39.5, 66.9],
		[59, 66.9]
	],
	5: [
		[15.8, 63],
		[49.5, 63],
		[82.5, 63],
		[32.5, 67],
		[66.1, 67]
	]
};
function xe({ id: e, rid: t, n, filled: r, x: i, y: a }) {
	let { ref: o, hidden: s } = m(`mc-slot:${t}:${e}:${n}`);
	return /* @__PURE__ */ g("span", {
		ref: o,
		className: "mc-pawn-space",
		style: {
			left: `${i}%`,
			top: `${a}%`,
			visibility: s ? "hidden" : void 0
		},
		children: r && /* @__PURE__ */ g(Y, { kind: "pawn" })
	});
}
function Se({ id: e, pawns: t, rid: n, anchor: r, active: i, selected: a, onChoose: o, onDetails: s }) {
	let { t: c } = ye(), l = E[e], { ref: d, hidden: f } = m(r ?? null), ee = c("games.minikincity.cardName", {
		color: c(q[l.color]),
		n: l.value
	});
	return /* @__PURE__ */ _("div", {
		ref: d,
		className: `mc-card${i ? " mc-legal" : ""}${a ? " mc-selected" : ""}`,
		style: { visibility: f ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ g("button", {
				className: "mc-card-face",
				disabled: !o,
				onClick: o,
				"aria-label": t !== void 0 && i ? c("games.minikincity.place", {
					color: c(q[l.color]),
					value: l.value,
					n: t,
					total: l.slots
				}) : ee,
				"aria-pressed": o ? a : void 0,
				children: /* @__PURE__ */ g(X, { id: e })
			}),
			t !== void 0 && n && (be[l.slots] ?? []).map(([r, i], a) => /* @__PURE__ */ g(xe, {
				id: e,
				rid: n,
				n: a + 1,
				filled: a < t,
				x: r,
				y: i
			}, a)),
			s && /* @__PURE__ */ g("button", {
				className: "mc-detail-button",
				"aria-label": `${c("games.minikincity.details")} · ${ee}`,
				onClick: () => s(e),
				children: /* @__PURE__ */ g(u, { size: 15 })
			})
		]
	});
}
function Ce({ id: e, active: t, onChoose: n, anchor: r }) {
	let { t: i } = ye(), { ref: a, hidden: o } = m(r ?? null);
	return /* @__PURE__ */ g("button", {
		ref: a,
		className: `mc-bonus${t ? " mc-legal" : ""}`,
		style: { visibility: o ? "hidden" : void 0 },
		disabled: !n,
		onClick: n,
		"aria-label": i(_e[e]),
		title: i(_e[e]),
		children: /* @__PURE__ */ g("img", {
			src: J(`bonus-${D.indexOf(e)}`),
			alt: ""
		})
	});
}
function Z({ name: e, className: t, children: n, inert: r }) {
	let { ref: i, hidden: a } = m(e);
	return /* @__PURE__ */ g("div", {
		ref: i,
		inert: r,
		className: t,
		style: { visibility: a ? "hidden" : void 0 },
		children: n
	});
}
//#endregion
//#region src/games/minikincity/view-player.tsx
var we = {
	2: [22.1, 36.1],
	3: [
		22,
		36.1,
		50.1
	],
	4: [
		19.3,
		33.3,
		47.4,
		61.3
	],
	5: [
		17.8,
		31.9,
		45.9,
		59.9,
		73.9
	]
}, Te = {
	keep: "games.minikincity.keep",
	play: "games.minikincity.play",
	allocate: "games.minikincity.allocate",
	bonus: "games.minikincity.bonus",
	draft: "games.minikincity.draft",
	extra: "games.minikincity.extra",
	settle: "games.minikincity.settle",
	done: "games.minikincity.done"
};
function Ee(e) {
	return /* @__PURE__ */ g(De, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function De({ pub: e, priv: t, members: r, myRid: s, send: u, readOnly: m = !1 }) {
	c();
	let { t: h, effect: v, reward: y } = ye(), ne = o((e) => e.locale), b = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? te(t, ne) : e;
	}, [re, ie] = a({
		rid: s,
		key: ""
	}), [x, S] = a(null), [C, w] = a([]), [T, O] = a(null), k = x !== null || T !== null, A = i(null);
	n(() => {
		if (!k) return;
		let e = document.activeElement;
		return A.current?.querySelector("button")?.focus(), () => e?.focus();
	}, [k]);
	let M = m ? "done" : `${e.phase}:${e.round}:${e.last?.kind}:${e.last?.rid}:${e.last?.card}`, N = e.phase === "settle" && e.last && [
		"play",
		"fill",
		"bonus",
		"showHand"
	].includes(e.last.kind) ? e.last.rid : s, P = e.players.find((e) => e.rid === (re.key === M ? re.rid : N)) ?? e.players[0], le = e.players.find((e) => e.rid === s), F = !m && e.turn === s, ue = t?.hand ?? le?.hand ?? [], de = F && e.phase === "allocate", fe = F && e.phase === "bonus", L = F && e.phase === "draft", R = F && (e.phase === "play" || e.phase === "extra"), z = F && e.phase === "keep", B = C.filter((e) => ue.includes(e)), V = I(P), H = x ? E[x] : null, U = [...ue];
	e.phase === "settle" && e.last?.kind === "play" && e.last.rid === s && e.last.card && !U.includes(e.last.card) && U.splice(e.last.n ?? 0, 0, e.last.card);
	let W = [...e.market];
	e.phase === "settle" && (e.last?.kind === "draft" || e.last?.kind === "return") && e.last.card && !W.includes(e.last.card) && W.push(e.last.card);
	let G = [...e.availableBonus];
	e.phase === "settle" && e.last?.kind === "bonus" && e.last.bonus && !G.includes(e.last.bonus) && G.push(e.last.bonus);
	let K = m ? h("games.minikincity.done") : F || e.phase === "settle" ? h(Te[e.phase]) : h("games.minikincity.waiting", { name: b(e.turn) }), pe = (e) => {
		z ? w(B.includes(e) ? B.filter((t) => t !== e) : B.length < 4 ? [...B, e] : B) : R && (u({
			type: "play",
			card: e
		}), w([]));
	};
	return /* @__PURE__ */ g(ee, {
		adaptive: !0,
		className: "mc-screen",
		scroll: !1,
		banner: /* @__PURE__ */ _("div", {
			className: "mc-banner",
			inert: k,
			children: [/* @__PURE__ */ g(p, {
				tone: F ? "accent" : "info",
				accent: ce.accent,
				text: K,
				chip: h("games.minikincity.round", { n: e.round })
			}), /* @__PURE__ */ g("div", {
				className: "mc-seats",
				children: e.players.map((t) => {
					let n = r.find((e) => e.rid === t.rid), i = e.ranking.indexOf(t.rid);
					return /* @__PURE__ */ g(Z, {
						name: `mc-seat:${t.rid}`,
						className: "mc-seat-anchor",
						children: /* @__PURE__ */ _("button", {
							className: `mc-seat${P.rid === t.rid ? " mc-seat-selected" : ""}${e.turn === t.rid && !m ? " mc-seat-turn" : ""}`,
							onClick: () => ie({
								rid: t.rid,
								key: M
							}),
							style: { borderColor: d[n?.colorIndex ?? 0]?.hex },
							children: [
								/* @__PURE__ */ g("b", { children: b(t.rid) }),
								/* @__PURE__ */ g("span", { children: i >= 0 ? h("games.minikincity.rank", { n: i + 1 }) : h("games.minikincity.handCount", { n: t.handCount }) }),
								/* @__PURE__ */ _("small", { children: [
									/* @__PURE__ */ g(Y, { kind: "pawn" }),
									t.reserve,
									" · ",
									/* @__PURE__ */ g(Y, { kind: "vp" }),
									t.rewardVP,
									" · ",
									/* @__PURE__ */ g(Y, { kind: "cockade" }),
									t.rewardCockades
								] })
							]
						})
					}, t.rid);
				})
			})]
		}),
		actionsHeight: "mc-hand-height",
		actions: /* @__PURE__ */ _(Z, {
			name: "mc-hand",
			className: "mc-hand-tray",
			inert: k,
			children: [/* @__PURE__ */ _("div", {
				className: "mc-hand-heading",
				children: [/* @__PURE__ */ g("b", { children: h("games.minikincity.hand") }), z ? /* @__PURE__ */ _("button", {
					className: "mc-primary",
					disabled: B.length !== 4,
					onClick: () => {
						u({
							type: "keep",
							cards: B
						}), w([]);
					},
					children: [
						h("games.minikincity.confirmKeep"),
						" ",
						B.length,
						"/4"
					]
				}) : /* @__PURE__ */ g("span", { children: e.finalRevealed ? h("games.minikincity.finalValue", { n: e.finalValues[s] ?? 0 }) : h("games.minikincity.handCount", { n: ue.length }) })]
			}), /* @__PURE__ */ g("div", {
				className: "mc-hand-row",
				children: U.map((e) => /* @__PURE__ */ g(Se, {
					id: e,
					anchor: `mc-hand:${e}`,
					active: R || z,
					selected: B.includes(e),
					onChoose: R || z ? () => pe(e) : void 0,
					onDetails: S
				}, e))
			})]
		}),
		overlay: x && H ? /* @__PURE__ */ g("div", {
			ref: A,
			className: "mc-modal",
			role: "dialog",
			"aria-modal": "true",
			onKeyDown: (e) => {
				e.key === "Tab" && (e.preventDefault(), A.current?.querySelector("button")?.focus()), e.key === "Escape" && (S(null), O(null));
			},
			"aria-label": h("games.minikincity.details"),
			children: /* @__PURE__ */ _("div", {
				className: "mc-detail-panel",
				children: [
					/* @__PURE__ */ g("button", {
						className: "mc-close",
						"aria-label": h("games.minikincity.close"),
						onClick: () => S(null),
						children: /* @__PURE__ */ g(l, { size: 22 })
					}),
					/* @__PURE__ */ g("img", {
						src: J(H.id),
						alt: ""
					}),
					/* @__PURE__ */ _("div", { children: [
						/* @__PURE__ */ g("h2", { children: h("games.minikincity.cardName", {
							color: h(q[H.color]),
							n: H.value
						}) }),
						/* @__PURE__ */ g("h3", { children: h(H.instant ? "games.minikincity.instantEffect" : "games.minikincity.scoreEffect") }),
						/* @__PURE__ */ g("p", { children: v(H.instant ?? H.score) }),
						H.extraScore && /* @__PURE__ */ g("p", { children: v(H.extraScore) }),
						H.value === 21 && /* @__PURE__ */ g("p", { children: h("games.minikincity.alwaysFirst") }),
						/* @__PURE__ */ g("p", { children: h("games.minikincity.slots", { n: H.slots }) }),
						/* @__PURE__ */ g("div", {
							className: "mc-symbols",
							children: [
								"L",
								"H",
								"S",
								"D"
							].flatMap((e, t) => Array.from({ length: H.symbols.split(e).length - 1 }, (n, r) => /* @__PURE__ */ g(Y, { kind: [
								"book",
								"heart",
								"smile",
								"bag"
							][t] }, `${e}${r}`)))
						})
					] })
				]
			})
		}) : T === null ? null : /* @__PURE__ */ g("div", {
			ref: A,
			className: "mc-modal",
			role: "dialog",
			"aria-modal": "true",
			onKeyDown: (e) => {
				e.key === "Tab" && (e.preventDefault(), A.current?.querySelector("button")?.focus()), e.key === "Escape" && (S(null), O(null));
			},
			"aria-label": h("games.minikincity.rewardTitle"),
			children: /* @__PURE__ */ _("div", {
				className: "mc-reward-panel",
				children: [
					/* @__PURE__ */ g("button", {
						className: "mc-close",
						"aria-label": h("games.minikincity.close"),
						onClick: () => O(null),
						children: /* @__PURE__ */ g(l, { size: 22 })
					}),
					/* @__PURE__ */ g("h2", { children: h(T === 8 ? "games.minikincity.finalColor" : "games.minikincity.rewardTitle") }),
					/* @__PURE__ */ g("img", {
						src: J(T === 8 ? `final-${e.players.length - 2}` : `reward-${oe(e.players.length, e.rewards[T])}`),
						alt: ""
					}),
					(T === 8 ? se[e.players.length] : ae[e.players.length][e.rewards[T]]).map((e, t) => /* @__PURE__ */ _("p", { children: [
						/* @__PURE__ */ g("b", { children: h("games.minikincity.rank", { n: t + 1 }) }),
						" · ",
						y(e) || "—"
					] }, t))
				]
			})
		}),
		children: /* @__PURE__ */ _("div", {
			className: "mc-table",
			inert: k,
			children: [
				/* @__PURE__ */ g(f, {
					kind: "sheen",
					base: "#e4e6c9",
					className: "mc-texture"
				}),
				/* @__PURE__ */ g("div", {
					className: "mc-rounds",
					children: e.rewards.map((t, n) => /* @__PURE__ */ g(Z, {
						name: `mc-round:${n}`,
						className: "mc-round-anchor",
						children: /* @__PURE__ */ _("button", {
							className: `mc-round${n === e.round - 1 && !e.finalRevealed ? " mc-round-current" : ""}`,
							onClick: () => O(n),
							"aria-label": `${h(n === 8 ? "games.minikincity.finalColor" : "games.minikincity.round", { n: n + 1 })} · ${h(q[j(t)])}`,
							children: [/* @__PURE__ */ g("span", { children: n === 8 ? "★" : n + 1 }), /* @__PURE__ */ _("div", {
								className: "mc-round-art",
								children: [
									/* @__PURE__ */ g("img", {
										src: J(n === 8 ? `final-${e.players.length - 2}` : `reward-${oe(e.players.length, t)}`),
										alt: ""
									}),
									n === 8 && /* @__PURE__ */ g("i", { className: `mc-color mc-color-${j(t)}` }),
									/* @__PURE__ */ g("div", {
										className: "mc-round-markers",
										children: (n === 8 ? e.finalRanking : e.history[n] ?? []).map((t, i) => /* @__PURE__ */ g("div", {
											className: "mc-marker-position",
											style: { top: `${we[e.players.length][i] + (n === 8 ? .4 : 0)}%` },
											children: /* @__PURE__ */ g(Z, {
												name: `mc-marker:${n}:${t}`,
												className: "mc-marker-anchor",
												children: /* @__PURE__ */ g("span", {
													title: `${i + 1} ${b(t)}`,
													style: { background: d[r.find((e) => e.rid === t)?.colorIndex ?? 0]?.hex },
													children: i + 1
												})
											})
										}, t))
									})
								]
							})]
						})
					}, n))
				}),
				/* @__PURE__ */ _("div", {
					className: "mc-playfield",
					children: [/* @__PURE__ */ _("section", {
						className: "mc-public-area",
						children: [
							/* @__PURE__ */ _("div", {
								className: "mc-area-heading",
								children: [/* @__PURE__ */ g("h2", { children: h("games.minikincity.market") }), /* @__PURE__ */ g(Z, {
									name: "mc-deck",
									className: "mc-deck",
									children: /* @__PURE__ */ g("span", { children: e.deckCount })
								})]
							}),
							/* @__PURE__ */ g("div", {
								className: "mc-market",
								children: W.map((t) => /* @__PURE__ */ g(Se, {
									id: t,
									anchor: `mc-market:${t}`,
									active: L && e.market.includes(t),
									onChoose: L && e.market.includes(t) ? () => u({
										type: "draft",
										card: t
									}) : void 0,
									onDetails: S
								}, t))
							}),
							/* @__PURE__ */ _("div", {
								className: "mc-pool",
								children: [/* @__PURE__ */ _(Z, {
									name: "mc-supply",
									className: "mc-supply",
									children: [/* @__PURE__ */ g(Y, { kind: "pawn" }), h("games.minikincity.supply", { n: e.supply })]
								}), /* @__PURE__ */ g("div", {
									className: "mc-bonus-pool",
									children: D.filter((e) => G.includes(e)).map((t) => /* @__PURE__ */ g(Ce, {
										id: t,
										anchor: `mc-bonus:${t}`,
										active: fe && e.availableBonus.includes(t),
										onChoose: fe && e.availableBonus.includes(t) ? () => u({
											type: "bonus",
											bonus: t
										}) : void 0
									}, t))
								})]
							})
						]
					}), /* @__PURE__ */ _("section", {
						className: "mc-city-area",
						children: [
							/* @__PURE__ */ _("div", {
								className: "mc-area-heading",
								children: [/* @__PURE__ */ g("h2", { children: h("games.minikincity.city", { name: b(P.rid) }) }), /* @__PURE__ */ _(Z, {
									name: `mc-reserve:${P.rid}`,
									className: "mc-reserve",
									children: [/* @__PURE__ */ g(Y, { kind: "pawn" }), P.reserve]
								})]
							}),
							/* @__PURE__ */ _("div", {
								className: "mc-city-stats",
								children: [
									[
										"book",
										"heart",
										"smile",
										"bag"
									].map((e) => /* @__PURE__ */ _("span", {
										title: h(ge[e]),
										children: [/* @__PURE__ */ g(Y, { kind: e }), V[e]]
									}, e)),
									/* @__PURE__ */ _("span", {
										title: h("games.minikincity.cockade"),
										children: [/* @__PURE__ */ g(Y, { kind: "cockade" }), V.cockade]
									}),
									/* @__PURE__ */ g("span", { children: h("games.minikincity.score", { n: P.score.total }) })
								]
							}),
							/* @__PURE__ */ g(Z, {
								name: `mc-city:${P.rid}`,
								className: "mc-city-cards",
								children: P.city.map((e) => /* @__PURE__ */ g(Se, {
									id: e.id,
									pawns: e.pawns,
									rid: P.rid,
									anchor: `mc-card:${P.rid}:${e.id}`,
									active: de && P.rid === s && e.pawns < E[e.id].slots,
									onChoose: de && P.rid === s && e.pawns < E[e.id].slots ? () => u({
										type: "allocate",
										card: e.id
									}) : void 0,
									onDetails: S
								}, e.id))
							}),
							/* @__PURE__ */ g(Z, {
								name: `mc-bonuses:${P.rid}`,
								className: "mc-owned-bonuses",
								children: P.bonuses.map((e) => /* @__PURE__ */ g(Ce, {
									id: e,
									anchor: `mc-owned-bonus:${P.rid}:${e}`
								}, e))
							}),
							P.hand && /* @__PURE__ */ g("div", {
								className: "mc-final-hand",
								children: /* @__PURE__ */ _(Z, {
									name: `mc-final-hand:${P.rid}`,
									className: "mc-final-reveal",
									children: [/* @__PURE__ */ g("b", { children: h("games.minikincity.finalValue", { n: e.finalValues[P.rid] ?? 0 }) }), /* @__PURE__ */ g("div", { children: P.hand.map((e) => /* @__PURE__ */ g(Se, {
										id: e,
										onDetails: S
									}, e)) })]
								})
							}, P.rid)
						]
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/games/minikincity/bot.ts
var Oe = {
	pawnValue: 1.1,
	bonusValue: 4,
	symbolGrowth: .55,
	colorGrowth: .3,
	rankWeight: 1,
	reserveWeight: .05,
	completionBias: .5,
	futureWeight: .55
}, ke = {
	...Oe,
	pawnValue: 1.6,
	symbolGrowth: .2,
	colorGrowth: .1,
	reserveWeight: .15
};
function Ae(e) {
	let t = Math.floor(4294967296 / e.length) * e.length, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return e[n % e.length];
}
var je = (e, t) => (e.vp ?? 0) + (e.pawns ?? 0) * t.pawnValue + (e.cockade ?? 0) * 3 + (e.bonus ?? 0) * t.bonusValue;
function Me(e, t, n) {
	let r = I(e), i = Math.max(0, 8 - t);
	for (let e of [
		"book",
		"heart",
		"smile",
		"bag"
	]) r[e] += i * n.symbolGrowth;
	for (let e of [
		"r",
		"g",
		"b"
	]) r[e] += i * n.colorGrowth;
	return r.symbols = Math.min(r.book, r.heart, r.smile, r.bag), r.sets = Math.min(r.r, r.g, r.b), r.instant += i * .3, r.pawns += i * 2, r.cockade += i * .2, r;
}
function Ne(e, t, n) {
	if (!e) return 0;
	let r = Object.entries(e.require ?? {}).reduce((e, [n, r]) => e + Math.max(0, r - t[n]), 0);
	return je(L({
		...e,
		require: void 0
	}, t), n) * .45 ** r;
}
function Q(e, t, n) {
	let r = Me(e, t, n), i = 0;
	for (let a of e.city) {
		let e = E[a.id];
		if (!e.slots) continue;
		let o = e.slots - a.pawns, s = o === 0 ? 1 : Math.min(.95, Math.max(0, (8 - t) * .6 + 1) / (o + 1));
		i += (Ne(e.score, r, n) + Ne(e.extraScore, r, n)) * s;
	}
	return i + R(e).cockades;
}
function Pe(e = {}) {
	return (t, n) => {
		let r = {
			...t.public.players.length > 2 ? ke : Oe,
			...e
		}, i = t.public, a = i.players.find((e) => e.rid === n.rid);
		if (!a || i.turn !== n.rid || i.phase === "settle" || i.phase === "done") return null;
		let o = t.private?.hand ?? [], s = {
			...a,
			hand: o
		}, c = n.difficulty === "weak", l = (e, t) => c ? Ae(e) : e.reduce((e, n) => t(n) > t(e) ? n : e), u = (e) => {
			let t = E[e], n = {
				...s,
				city: [...s.city, {
					id: e,
					pawns: Math.min(s.reserve, t.slots)
				}],
				reserve: Math.max(0, s.reserve - t.slots)
			}, a = I(n);
			return je(L(t.instant, a), r) + (Q(n, i.round, r) - Q(s, i.round, r)) + r.futureWeight * t.symbols.length + (t.slots === 0 ? 0 : .15);
		};
		if (i.phase === "keep") {
			let e = [];
			for (let t = 0; t < o.length; t++) for (let n = t + 1; n < o.length; n++) e.push(o.filter((e, r) => r !== t && r !== n));
			return { action: {
				type: "keep",
				cards: l(e, (e) => e.reduce((e, t) => e + u(t), 0) + new Set(e.map((e) => E[e].color)).size)
			} };
		}
		if (i.phase === "play" || i.phase === "extra") {
			let e = j(i.rewards[i.round - 1]), t = (t) => {
				let n = E[t];
				if (i.phase === "extra") return 0;
				let a = (t) => E[t].value + (E[t].value === 21 ? 100 : E[t].color === e ? 30 : 0), o = i.players.filter((e) => e.rid !== s.rid && e.city.length === i.round).map((e) => e.city.at(-1).id), c = o.filter((e) => a(e) > a(t)).length, l = i.players.length - 1 - o.length, u = n.value === 21 ? 0 : n.color === e ? (20 - n.value) / 61 : (20 - n.value) * 2 / 61 + 20 / 61, d = Math.min(i.players.length - 1, Math.round(c + l * u));
				return je(ae[i.players.length][i.rewards[i.round - 1]][d], r);
			};
			return { action: {
				type: "play",
				card: l(o, (e) => u(e) + r.rankWeight * t(e) - r.reserveWeight * E[e].value * (E[e].color === j(i.rewards[8]) ? i.round / 8 : 0))
			} };
		}
		return i.phase === "draft" ? { action: {
			type: "draft",
			card: l(i.market, (e) => u(e) + (E[e].color === j(i.rewards[8]) ? E[e].value * r.reserveWeight * i.round / 8 : 0))
		} } : i.phase === "allocate" ? { action: {
			type: "allocate",
			card: l(s.city.filter((e) => e.pawns < E[e.id].slots), (e) => {
				let t = E[e.id], n = Me(s, i.round, r);
				return (Ne(t.score, n, r) + Ne(t.extraScore, n, r)) / (t.slots - e.pawns) + r.completionBias / (t.slots - e.pawns);
			}).id
		} } : i.phase === "bonus" ? { action: {
			type: "bonus",
			bonus: l(i.availableBonus, (e) => {
				let t = {
					...s,
					bonuses: [...s.bonuses, e]
				};
				return je(O[e] ?? L(k[e], I(t)), r) + Q(t, i.round, r) - Q(s, i.round, r) + +(e === "wild");
			})
		} } : null;
	};
}
var Fe = Pe(), Ie = (e, t, n) => e.type === "tick" ? "" : n({
	keep: "games.minikincity.keep",
	play: "games.minikincity.play",
	draft: "games.minikincity.draft",
	allocate: "games.minikincity.allocate",
	bonus: "games.minikincity.bonus"
}[e.type]), $ = (e, t = 32) => ({
	x: e.x + e.w / 2 - t / 2,
	y: e.y + e.h / 2 - t / 2,
	w: t,
	h: t
});
function Le({ from: e, to: t, count: n, ms: r }) {
	return /* @__PURE__ */ g(h, { children: Array.from({ length: n }, (n, i) => /* @__PURE__ */ g(y, {
		from: {
			...$(e),
			x: $(e).x + i * 5
		},
		to: {
			...$(t),
			x: $(t).x + (i % 3 - 1) * 7
		},
		ms: r,
		children: /* @__PURE__ */ g("span", {
			className: "mc-flying-pawn",
			children: /* @__PURE__ */ g(Y, { kind: "pawn" })
		})
	}, i)) });
}
function Re({ at: e, cards: t, ms: n }) {
	let a = i(null);
	return r(() => {
		let e = a.current?.animate([{
			transform: "perspective(700px) rotateY(-90deg)",
			opacity: .2
		}, {
			transform: "perspective(700px) rotateY(0)",
			opacity: 1
		}], {
			duration: n,
			easing: "cubic-bezier(.2,.7,.2,1)",
			fill: "both"
		});
		return () => e?.cancel();
	}, [n]), /* @__PURE__ */ g("div", {
		ref: a,
		className: "mc-flip-hand",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: t.map((e) => /* @__PURE__ */ g("div", {
			className: "mc-flip-card",
			children: /* @__PURE__ */ g(X, { id: e })
		}, e))
	});
}
var ze = {
	play(e, t) {
		let n = e.data, r = `mc-hand:${n.card}`, i = `mc-card:${e.rid}:${n.card}`, a = t.anchor(e.rid === t.myRid ? r : `mc-seat:${e.rid}`) ?? t.anchor("mc-hand"), o = t.anchor(i) ?? t.anchor(`mc-seat:${e.rid}`);
		return !a || !o || !n.card ? null : {
			ms: 480,
			hide: t.queued ? [] : [i, ...e.rid === t.myRid ? [r] : []],
			node: /* @__PURE__ */ g(y, {
				from: a,
				to: o,
				ms: 480,
				children: /* @__PURE__ */ g("div", {
					className: "mc-flying-card",
					children: /* @__PURE__ */ g(X, { id: n.card })
				})
			})
		};
	},
	fill(e, t) {
		let n = e.data, r = t.anchor(`mc-reserve:${e.rid}`) ?? t.anchor(`mc-seat:${e.rid}`);
		if (!r || !n.card) return null;
		let i = Array.from({ length: n.n ?? 0 }, (t, r) => `mc-slot:${e.rid}:${n.card}:${r + 1}`);
		return {
			ms: 480,
			hide: t.queued ? [] : i,
			node: /* @__PURE__ */ g(h, { children: i.map((e) => {
				let n = t.anchor(e);
				return n ? /* @__PURE__ */ g(y, {
					from: $(r),
					to: $(n, n.w),
					ms: 480,
					children: /* @__PURE__ */ g("span", {
						className: "mc-flying-pawn",
						children: /* @__PURE__ */ g(Y, { kind: "pawn" })
					})
				}, e) : null;
			}) })
		};
	},
	gain(e, t) {
		let n = e.data, r = t.anchor("mc-supply"), i = t.anchor(`mc-card:${e.rid}:${n.card}`) ?? t.anchor(`mc-seat:${e.rid}`), a = t.anchor(`mc-reserve:${e.rid}`) ?? t.anchor(`mc-seat:${e.rid}`);
		return i ? {
			ms: 480,
			node: /* @__PURE__ */ _(h, { children: [
				!!n.n && r && a && /* @__PURE__ */ g(Le, {
					from: r,
					to: a,
					count: n.n,
					ms: 480
				}),
				!!n.vp && /* @__PURE__ */ _(v, {
					at: i,
					ms: 480,
					children: [
						"+",
						n.vp,
						" ",
						/* @__PURE__ */ g(Y, { kind: "vp" })
					]
				}),
				!!n.cockade && /* @__PURE__ */ _(v, {
					at: i,
					ms: 480,
					children: [
						"+",
						n.cockade,
						" ",
						/* @__PURE__ */ g(Y, { kind: "cockade" })
					]
				}),
				!n.n && !n.vp && !n.cockade && /* @__PURE__ */ g(ne, {
					at: i,
					ms: 480
				})
			] })
		} : null;
	},
	draft(e, t) {
		let n = e.data, r = `mc-market:${n.card}`, i = e.rid === t.myRid ? `mc-hand:${n.card}` : `mc-seat:${e.rid}`, a = t.anchor(r), o = t.anchor(i);
		return !a || !o || !n.card ? null : {
			ms: 480,
			hide: t.queued ? [] : [r, ...e.rid === t.myRid ? [i] : []],
			node: /* @__PURE__ */ g(y, {
				from: a,
				to: o,
				ms: 480,
				children: /* @__PURE__ */ g("div", {
					className: "mc-flying-card",
					children: /* @__PURE__ */ g(X, { id: n.card })
				})
			})
		};
	},
	return(e, t) {
		let n = e.data, r = `mc-market:${n.card}`, i = t.anchor(r), a = t.anchor("mc-deck");
		return !i || !a || !n.card ? null : {
			ms: 480,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ g(y, {
				from: i,
				to: a,
				ms: 480,
				children: /* @__PURE__ */ g("div", {
					className: "mc-flying-card",
					children: /* @__PURE__ */ g(X, { id: n.card })
				})
			})
		};
	},
	reveal(e, t) {
		let n = e.data, r = t.anchor("mc-deck");
		return r ? {
			ms: 480,
			hide: t.queued ? [] : n.cards.map((e) => `mc-market:${e}`),
			node: /* @__PURE__ */ g(h, { children: n.cards.map((e) => {
				let n = t.anchor(`mc-market:${e}`);
				return n ? /* @__PURE__ */ g(y, {
					from: r,
					to: n,
					ms: 480,
					children: /* @__PURE__ */ g("div", {
						className: "mc-flying-card",
						children: /* @__PURE__ */ g(X, { id: e })
					})
				}, e) : null;
			}) })
		} : null;
	},
	allocate(e, t) {
		let n = e.data, r = t.anchor(`mc-reserve:${e.rid}`) ?? t.anchor(`mc-seat:${e.rid}`), i = `mc-slot:${e.rid}:${n.card}:${n.n}`, a = t.anchor(i) ?? t.anchor(`mc-seat:${e.rid}`);
		return !r || !a ? null : {
			ms: 480,
			hide: t.queued ? [] : [i],
			node: /* @__PURE__ */ g(y, {
				from: $(r),
				to: $(a, Math.max(16, a.w)),
				ms: 480,
				children: /* @__PURE__ */ g("span", {
					className: "mc-flying-pawn",
					children: /* @__PURE__ */ g(Y, { kind: "pawn" })
				})
			})
		};
	},
	bonus(e, t) {
		let n = e.data;
		if (!n.bonus) return null;
		let r = `mc-bonus:${n.bonus}`, i = `mc-owned-bonus:${e.rid}:${n.bonus}`, a = t.anchor(r), o = t.anchor(i) ?? t.anchor(`mc-seat:${e.rid}`), s = t.anchor("mc-supply"), c = t.anchor(`mc-reserve:${e.rid}`) ?? t.anchor(`mc-seat:${e.rid}`);
		return !a || !o ? null : {
			ms: 480,
			hide: t.queued ? [] : [r, i],
			node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(y, {
				from: a,
				to: o,
				ms: 480,
				children: /* @__PURE__ */ g("img", {
					className: "mc-flying-bonus",
					src: J(`bonus-${D.indexOf(n.bonus)}`),
					alt: ""
				})
			}), !!n.n && s && c && /* @__PURE__ */ g(Le, {
				from: s,
				to: c,
				count: n.n,
				ms: 480
			})] })
		};
	},
	reward(e, t) {
		let n = e.data, r = t.anchor(`mc-seat:${e.rid}`), i = t.anchor(`mc-marker:${n.final ? 8 : n.round - 1}:${e.rid}`) ?? t.anchor(`mc-round:${n.final ? 8 : n.round - 1}`), a = t.anchor("mc-supply"), o = t.anchor(`mc-reserve:${e.rid}`) ?? r;
		if (!r || !i) return null;
		let s = d[t.member(e.rid ?? "")?.colorIndex ?? 0]?.hex;
		return {
			ms: 480,
			hide: t.queued ? [] : [`mc-marker:${n.final ? 8 : n.round - 1}:${e.rid}`],
			node: /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g(y, {
					from: $(r, 22),
					to: i,
					ms: 480,
					children: /* @__PURE__ */ g("span", {
						className: "mc-reward-chip",
						style: { background: s },
						children: n.position
					})
				}),
				!!n.n && a && o && /* @__PURE__ */ g(Le, {
					from: a,
					to: o,
					count: n.n,
					ms: 480
				}),
				!!n.vp && /* @__PURE__ */ _(v, {
					at: r,
					ms: 480,
					children: [
						"+",
						n.vp,
						" ",
						/* @__PURE__ */ g(Y, { kind: "vp" })
					]
				}),
				!!n.cockade && /* @__PURE__ */ _(v, {
					at: r,
					ms: 480,
					children: [
						"+",
						n.cockade,
						" ",
						/* @__PURE__ */ g(Y, { kind: "cockade" })
					]
				})
			] })
		};
	},
	showHand(e, t) {
		let n = e.data, r = `mc-final-hand:${e.rid}`, i = t.anchor(r);
		return i ? {
			ms: 480,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ g(Re, {
				at: i,
				cards: n.cards,
				ms: 480
			})
		} : null;
	},
	final(e, t) {
		let n = t.anchor(`mc-seat:${e.rid}`);
		return n ? {
			ms: 480,
			node: /* @__PURE__ */ g(ne, {
				at: n,
				ms: 480
			})
		} : null;
	},
	keep(e, t) {
		let n = t.anchor(e.rid === t.myRid ? "mc-hand" : `mc-seat:${e.rid}`), r = t.anchor("mc-deck");
		return !n || !r ? null : {
			ms: 480,
			node: /* @__PURE__ */ g(h, { children: [0, 1].map((e) => /* @__PURE__ */ g(y, {
				from: {
					...$(n, 55),
					x: $(n, 55).x + e * 17
				},
				to: r,
				ms: 480,
				children: /* @__PURE__ */ g("div", { className: "mc-card-back" })
			}, e)) })
		};
	}
};
//#endregion
//#region src/games/minikincity/game-over.tsx
function Be({ result: e, public: t, private: n, members: r, myRid: i, hintCount: s, onPlayAgain: c, onBackToLobby: u }) {
	let d = t, { t: f } = ye(), ee = o((e) => e.locale), [p, m] = a(!0), h = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? te(t, ee) : e;
	};
	return /* @__PURE__ */ _("div", {
		className: "mc-over mc-screen",
		children: [
			/* @__PURE__ */ g("div", {
				className: "mc-over-board",
				inert: p,
				children: /* @__PURE__ */ g(De, {
					pub: d,
					priv: n,
					members: r,
					myRid: i,
					send: () => void 0,
					readOnly: !0
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "mc-result-layer",
				hidden: !p,
				inert: !p,
				children: [
					/* @__PURE__ */ g(re, {}),
					/* @__PURE__ */ _("header", {
						className: "mc-result-heading",
						children: [
							/* @__PURE__ */ g(Y, { kind: "pawn" }),
							/* @__PURE__ */ g("h1", { children: f("games.minikincity.resultTitle") }),
							/* @__PURE__ */ g("button", {
								className: "mc-close",
								"aria-label": f("games.minikincity.review"),
								onClick: () => m(!1),
								children: /* @__PURE__ */ g(l, { size: 24 })
							})
						]
					}),
					/* @__PURE__ */ _("div", {
						className: "mc-result-scroll",
						children: [
							/* @__PURE__ */ g("div", {
								className: "mc-winners",
								children: e.winner.map((e) => /* @__PURE__ */ _("strong", { children: [
									h(e),
									" · ",
									f("games.minikincity.winner")
								] }, e))
							}),
							/* @__PURE__ */ g("div", {
								className: "mc-score-scroll",
								children: /* @__PURE__ */ _("table", {
									className: "mc-score-table",
									"data-players": d.players.length,
									children: [/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", { children: f("games.minikincity.done") }), e.ranking.map((t) => /* @__PURE__ */ _("th", { children: [h(t), e.winner.includes(t) && /* @__PURE__ */ g(Y, { kind: "cockade" })] }, t))] }) }), /* @__PURE__ */ _("tbody", { children: [[
										["games.minikincity.rewardsScore", "rewards"],
										["games.minikincity.cityScore", "city"],
										["games.minikincity.cockadeScore", "cockades"],
										["games.minikincity.total", "total"]
									].map(([t, n]) => /* @__PURE__ */ _("tr", {
										className: n === "total" ? "mc-total-row" : "",
										children: [/* @__PURE__ */ g("th", { children: f(t) }), e.ranking.map((e) => /* @__PURE__ */ g("td", { children: d.players.find((t) => t.rid === e).score[n] }, e))]
									}, t)), /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", { children: f("games.minikincity.unused") }), e.ranking.map((e) => /* @__PURE__ */ g("td", { children: d.players.find((t) => t.rid === e).reserve }, e))] })] })]
								})
							}),
							/* @__PURE__ */ _("details", {
								className: "mc-score-details",
								children: [/* @__PURE__ */ g("summary", { children: f("games.minikincity.cityScore") }), d.players.map((e) => /* @__PURE__ */ _("section", { children: [/* @__PURE__ */ g("h2", { children: h(e.rid) }), /* @__PURE__ */ g("div", { children: Object.entries(e.score.cards).map(([e, t]) => /* @__PURE__ */ _("span", { children: [
									f("games.minikincity.cardName", {
										color: f(q[E[e].color]),
										n: E[e].value
									}),
									" · ",
									t
								] }, e)) })] }, e.rid))]
							}),
							s !== void 0 && /* @__PURE__ */ g("p", { children: f("session.hint.usedCount", { n: s }) }),
							e.autopilot && Object.entries(e.autopilot).map(([e, t]) => /* @__PURE__ */ _("p", { children: [
								h(e),
								" · ",
								f("session.autopilot.share", { n: Math.round(t * 100) })
							] }, e))
						]
					})
				]
			}),
			/* @__PURE__ */ _("footer", {
				className: "mc-result-actions",
				children: [
					/* @__PURE__ */ g("button", {
						className: "mc-primary",
						onClick: () => m(!p),
						children: f(p ? "games.minikincity.review" : "games.minikincity.showResult")
					}),
					c && /* @__PURE__ */ g(b, {
						compact: !0,
						label: f("session.result.playAgain"),
						confirmLabel: f("games.minikincity.confirmAgain"),
						onConfirm: c
					}),
					" ",
					u && /* @__PURE__ */ g(b, {
						compact: !0,
						label: f("session.result.backToLobby"),
						confirmLabel: f("games.minikincity.confirmBack"),
						onConfirm: u
					}),
					" ",
					!c && !u && /* @__PURE__ */ g("span", { children: f("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/minikincity/options.tsx
function Ve({ value: e, onChange: t }) {
	let n = s(), r = N.safeParse(e), i = r.success ? r.data : N.parse(void 0);
	return /* @__PURE__ */ g(ie, {
		checked: i.musicFestival,
		label: n("games.minikincity.musicFestival"),
		accent: ce.accent,
		onChange: () => t({
			...i,
			musicFestival: !i.musicFestival
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/minikincity/entry.tsx
var He = {
	definition: he,
	View: Ee,
	bot: Fe,
	describe: Ie,
	fx: ze,
	OverView: Be,
	Options: Ve,
	locales: {
		zh: {
			name: "小城大作",
			countBook: "{{n}} 本书",
			countHeart: "{{n}} 个爱心",
			countSmile: "{{n}} 个笑脸",
			countBag: "{{n}} 个钱袋",
			countRed: "{{n}} 张红色城市牌",
			countGreen: "{{n}} 张绿色城市牌",
			countBlue: "{{n}} 张蓝色城市牌",
			countSets: "{{n}} 套三色牌",
			countSymbols: "{{n}} 套四符号",
			countTypes: "{{n}} 种符号",
			countInstant: "{{n}} 张带即时效果的城市牌",
			countPawns: "{{n}} 个小人",
			countBonuses: "{{n}} 枚奖励标记",
			countCockades: "{{n}} 枚勋章",
			countLow: "{{n}} 张1–5号城市牌",
			countMid: "{{n}} 张6–10号城市牌",
			countHigh: "{{n}} 张11–15号城市牌",
			countTop: "{{n}} 张16–20号城市牌",
			countVp: "{{n}} 胜利点",
			desc: "将遗落的小物件建成奇妙城市，争取奖励，让小人搬进最有价值的建筑。",
			errAction: "当前无法执行此操作，请重新选择。",
			musicFestival: "音乐节宣传牌",
			round: "第 {{n}} / 8 轮",
			finalColor: "终局主色",
			keep: "选择保留 4 张城市牌",
			confirmKeep: "保留这 4 张牌",
			play: "选择一张手牌加入城市",
			draft: "选择一张市场牌加入手牌",
			allocate: "点击城市牌的空位，分配小人",
			bonus: "选择一个奖励标记",
			extra: "选择额外加入城市的手牌",
			settle: "正在结算",
			done: "城市落成",
			waiting: "等待 {{name}}",
			hand: "手牌",
			market: "公开市场",
			city: "{{name}}的城市",
			bonuses: "奖励标记",
			supply: "公共小人 {{n}}",
			reserve: "未使用小人 {{n}}",
			deck: "城市牌堆 {{n}}",
			close: "关闭",
			details: "查看牌面详情",
			cardName: "{{color}} {{n}} 号",
			r: "红色",
			g: "绿色",
			b: "蓝色",
			n: "无色",
			book: "书本",
			heart: "爱心",
			smile: "笑脸",
			bag: "钱袋",
			sets: "三色牌套",
			symbols: "四符号套",
			types: "符号种类",
			instant: "即时效果",
			pawns: "小人",
			cockade: "勋章",
			low: "1–5 号城市牌",
			mid: "6–10 号城市牌",
			high: "11–15 号城市牌",
			top: "16–20 号城市牌",
			vp: "胜利点",
			gain: "获得 {{reward}}",
			per: "每{{quantity}}，{{reward}}",
			condition: "拥有{{condition}}时，{{reward}}",
			count: "{{n}} 个{{metric}}",
			scoreEffect: "填满小人后计分",
			instantEffect: "出牌时立即生效",
			noEffect: "这张牌没有额外效果。",
			symbolsLabel: "提供的符号",
			slots: "小人空位 {{n}}",
			place: "向 {{color}} {{value}} 号放置一个小人（{{n}} / {{total}}）",
			score: "{{n}} 分",
			handCount: "{{n}} 张手牌",
			rank: "第 {{n}} 名",
			lastRank: "本轮名次",
			bluePawns: "立即按城市中蓝色牌数获得小人",
			greenPawns: "立即按城市中绿色牌数获得小人",
			redPawns: "立即按城市中红色牌数获得小人",
			wild: "每项效果中视为一张任选颜色城市牌",
			points: "终局获得 2 胜利点",
			bonusHeart: "增加一个爱心",
			bonusSmile: "增加一个笑脸",
			bonusBag: "增加一个钱袋",
			bonusBook: "增加一本书",
			bonusCockade: "终局增加一枚勋章",
			alwaysFirst: "本轮排名始终第一",
			rewardTitle: "本轮奖励",
			rewardsScore: "奖励与标记",
			cityScore: "城市牌计分",
			cockadeScore: "勋章计分",
			total: "总分",
			unused: "未使用小人",
			winner: "获胜",
			resultTitle: "小小城市，大大成就",
			review: "回看城市",
			showResult: "展开计分表",
			confirmAgain: "确定开始新的一局吗？",
			confirmBack: "确定返回大厅吗？",
			finalHand: "终局揭示的手牌",
			finalValue: "主色总和 {{n}}",
			claim: "领取此标记",
			chooseCard: "选择此牌",
			removeCard: "取消选择此牌",
			scoreNow: "当前城市得分",
			rules: "目标：\n用城市牌和小人建造城市。经过 8 轮及一次终局竞赛后，胜利点最多者获胜。同分时未使用小人较多者获胜，仍相同则共享胜利。\n\n准备：\n按人数选择 9 张奖励牌，随机排列。第 9 张的颜色是终局主色。每人从 6 张城市牌中保留 4 张，其余放回牌堆底。首家随机决定。音乐节宣传牌可在开局选项中加入，默认关闭。\n\n每轮流程：\n· 展示人数加 1 张城市牌作为公开市场。\n· 从首家起顺时针，每人打一张手牌，加入自己的城市。有闪电的牌立即执行效果。右上方符号从出牌起持续有效。\n· 本轮奖励牌颜色的城市牌优先，按数值从高到低排名；其他颜色随后按数值从高到低排名。同为非主色且数值相同，先出牌者优先。无色 21 号始终第一。\n· 按名次领取奖励牌对应的胜利点、勋章、小人或奖励标记。奖励标记从公共池选择，每枚只能被一人领取。\n· 从最后一名起反向选择市场中的一张牌加入手牌。剩余一张放回牌堆底。本轮第一名成为下轮首家，出牌仍顺时针。\n\n小人分配：\n获得小人时必须立即放入自己城市牌的空位，可自由分配，放下后不得挪动。没有足够空位时保留多余小人；以后打出有空位的牌，必须先用这些小人尽量填满。只有填满空位的城市牌，底部计分或勋章效果才生效。公共小人供应为 75 个，耗尽时本版本只领取剩余数量。\n\n图例与条件：\n书本、爱心、笑脸、钱袋来自城市牌右上方和奖励标记；不要求牌已填满。箭头左侧的条件全部达到时，获得右侧奖励一次；乘号效果按对应数量计算。三色牌套由红、绿、蓝各一张组成，四符号套由四种普通符号各一个组成。三色奖励标记对每项效果可以独立选择颜色，但一套中只补一张牌。数值范围只计城市中对应号码的牌，0 号和 21 号不计入 1–20 的任何区间。\n\n终局：\n第 8 轮补牌后，从当轮第一名起顺时针揭示手牌。将手牌中终局主色的数值相加，按总和排名，相同则先揭示者优先。领取终局奖励并分配小人后，第一名额外打一张手牌，照常执行即时效果和放置小人。\n分别计算奖励牌和标记的胜利点、填满的城市牌效果，以及勋章得分。勋章 1、2、3、4、5、6 枚或更多，依次获得 1、3、6、10、15、21 胜利点。未填满的牌不提供底部胜利点或勋章。音乐节红 0 立即获得 6 个小人；绿 0 填满后按书本与笑脸各获得 1 分；蓝 0 填满后按钱袋与爱心各获得 1 分。"
		},
		en: {
			name: "Minikin City",
			countBook: "{{n}} book{{plural}}",
			countHeart: "{{n}} heart{{plural}}",
			countSmile: "{{n}} smile{{plural}}",
			countBag: "{{n}} money bag{{plural}}",
			countRed: "{{n}} red City card{{plural}}",
			countGreen: "{{n}} green City card{{plural}}",
			countBlue: "{{n}} blue City card{{plural}}",
			countSets: "{{n}} color set{{plural}}",
			countSymbols: "{{n}} symbol set{{plural}}",
			countTypes: "{{n}} symbol type{{plural}}",
			countInstant: "{{n}} City card{{plural}} with an Instant effect",
			countPawns: "{{n}} Minikin{{plural}}",
			countBonuses: "{{n}} Bonus token{{plural}}",
			countCockades: "{{n}} Cockade{{plural}}",
			countLow: "{{n}} City card{{plural}} numbered 1–5",
			countMid: "{{n}} City card{{plural}} numbered 6–10",
			countHigh: "{{n}} City card{{plural}} numbered 11–15",
			countTop: "{{n}} City card{{plural}} numbered 16–20",
			countVp: "{{n}} VP",
			desc: "Turn forgotten objects into a tiny city, win rewards, and give your Minikins valuable homes.",
			errAction: "That action is unavailable. Please choose again.",
			musicFestival: "Music Festival promo",
			round: "Round {{n}} / 8",
			finalColor: "Final color",
			keep: "Keep 4 City cards",
			confirmKeep: "Keep these 4 cards",
			play: "Play a hand card into your city",
			draft: "Take a market card into your hand",
			allocate: "Place Minikins on empty city spaces",
			bonus: "Choose a Bonus token",
			extra: "Play your extra City card",
			settle: "Resolving rewards",
			done: "City complete",
			waiting: "Waiting for {{name}}",
			hand: "Hand",
			market: "Open display",
			city: "{{name}}’s city",
			bonuses: "Bonus tokens",
			supply: "Supply: {{n}} Minikins",
			reserve: "Unused Minikins: {{n}}",
			deck: "City deck: {{n}}",
			close: "Close",
			details: "Inspect card",
			cardName: "{{color}} {{n}}",
			r: "Red",
			g: "Green",
			b: "Blue",
			n: "Colorless",
			book: "books",
			heart: "hearts",
			smile: "smiles",
			bag: "money bags",
			sets: "color sets",
			symbols: "symbol sets",
			types: "symbol types",
			instant: "Instant effects",
			pawns: "Minikins",
			cockade: "Cockades",
			low: "City cards 1–5",
			mid: "City cards 6–10",
			high: "City cards 11–15",
			top: "City cards 16–20",
			vp: "VP",
			gain: "Gain {{reward}}",
			per: "{{reward}} for every {{quantity}}.",
			condition: "{{reward}} if you have {{condition}}.",
			count: "{{n}} {{metric}}",
			scoreEffect: "Score when all spaces are filled",
			instantEffect: "Resolve immediately when played",
			noEffect: "This card has no additional effect.",
			symbolsLabel: "Symbols provided",
			slots: "Minikin spaces: {{n}}",
			place: "Place a Minikin on {{color}} {{value}} ({{n}} / {{total}})",
			score: "{{n}} VP",
			handCount: "{{n}} hand cards",
			rank: "Rank {{n}}",
			lastRank: "Round ranking",
			bluePawns: "Immediately gain a Minikin for each blue City card",
			greenPawns: "Immediately gain a Minikin for each green City card",
			redPawns: "Immediately gain a Minikin for each red City card",
			wild: "Counts as one City card of your chosen color for each effect",
			points: "Gain 2 VP at final scoring",
			bonusHeart: "Provides one additional heart",
			bonusSmile: "Provides one additional smile",
			bonusBag: "Provides one additional money bag",
			bonusBook: "Provides one additional book",
			bonusCockade: "Provides one additional Cockade at final scoring",
			alwaysFirst: "Always ranks first this round",
			rewardTitle: "Round rewards",
			rewardsScore: "Rewards & tokens",
			cityScore: "City cards",
			cockadeScore: "Cockades",
			total: "Total",
			unused: "Unused Minikins",
			winner: "Winner",
			resultTitle: "A tiny city. A grand achievement.",
			review: "View cities",
			showResult: "Show score sheet",
			confirmAgain: "Start a new game?",
			confirmBack: "Return to the lobby?",
			finalHand: "Revealed final hand",
			finalValue: "Final-color total: {{n}}",
			claim: "Take this token",
			chooseCard: "Choose this card",
			removeCard: "Deselect this card",
			scoreNow: "Current city score",
			rules: "Goal:\nBuild a city with City cards and Minikin pawns. After 8 rounds and a final contest, the most VP wins. Ties favor the player with more unused Minikins; a further tie is a shared victory.\n\nSetup:\nSelect the 9 Reward cards for your player count and shuffle their order. The ninth card determines the final color. Each player keeps 4 of 6 City cards; the others go to the bottom of the deck. Choose the first player randomly. The optional Music Festival cards are off by default.\n\nEach round:\n· Reveal one more City card than the number of players to form the open display.\n· Starting with the first player and continuing clockwise, each player adds a hand card to their city. Resolve its Instant effect, marked by lightning, immediately. Its top-right symbols become available at once.\n· Cards matching the round’s Reward color rank first, highest value first. Other colors follow in descending value. Equal values in other colors favor the earlier play. Colorless 21 always ranks first.\n· Receive the VP, Cockades, Minikins or Bonus tokens for your rank. Choose tokens from the common supply; each token can be taken only once.\n· In reverse ranking order, each player takes a card from the open display. Put the last card under the deck. The top-ranked player leads the next round, but plays still proceed clockwise.\n\nMinikin management:\nImmediately place gained Minikins on any empty spaces in your city, freely dividing them among cards. Placed Minikins cannot move. Keep excess pawns only when all available spaces are filled. When you later play a card with spaces, fill it as far as possible with these unused pawns. A card’s bottom scoring or Cockade effect works only when all its spaces are filled. The supply contains 75 Minikins; this implementation grants only the remaining pawns if it runs out.\n\nSymbols and conditions:\nBooks, hearts, smiles and money bags come from the top right of City cards and Bonus tokens, even on unfilled cards. Meet every condition left of an arrow to gain its reward once. Multiplication effects count the indicated items. A color set contains one red, one green and one blue card. A symbol set contains one of each ordinary symbol. The wild-color token can choose a color independently for each effect, but supplies only one card within a set. Value ranges count matching cards in your city; 0 and 21 belong to none of the 1–20 ranges.\n\nEndgame:\nAfter drafting in round 8, reveal hands clockwise from that round’s winner. Add the values of hand cards matching the final color and rank the totals; earlier reveal wins ties. Resolve all final rewards and Minikin placement, then the winner plays one extra hand card, resolving its Instant effect and Minikin placement normally.\nAdd VP from Reward cards and Bonus tokens, effects on filled City cards, and Cockades. Having 1, 2, 3, 4, 5 or at least 6 Cockades scores 1, 3, 6, 10, 15 or 21 VP. Unfilled cards provide no bottom VP or Cockades. Music Festival Red 0 immediately gains 6 Minikins. Filled Green 0 scores 1 VP per book and per smile; filled Blue 0 scores 1 VP per money bag and per heart."
		}
	}
};
//#endregion
export { He as default };
