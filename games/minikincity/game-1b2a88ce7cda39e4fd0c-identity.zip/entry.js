import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { IconClose as l, IconInfo as u } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { Texture as f } from "@bgparty/sdk/texture";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchor as h } from "@bgparty/sdk/fx/anchors";
import { usePrefersReducedMotion as g } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { Floater as b, FlySprite as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as te } from "@bgparty/sdk/confirm-button";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
import { OptionSwitch as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/minikincity/data.ts
var w = (e, t, n, r) => ({
	reward: e,
	per: t,
	require: n,
	divisor: r
}), T = (e, t, n, r) => w({ vp: e }, t, n, r), E = (e, t, n) => w({ pawns: e }, t, n), D = (e, t, n, r, i, a) => ({
	id: `${e}${t}`,
	color: e,
	value: t,
	symbols: n,
	slots: r,
	score: i,
	instant: a,
	atlas: e === "r" ? t - 1 : e === "g" ? t <= 10 ? 30 - t : t + 19 : e === "b" ? t + 39 : 60
}), O = [
	D("r", 1, "LD", 2, T(9, void 0, { book: 5 })),
	D("r", 2, "HH", 0, void 0, E(1, "heart")),
	D("r", 3, "SD", 2, T(9, void 0, { smile: 6 })),
	D("r", 4, "D", 5, w({ cockade: 2 })),
	D("r", 5, "DD", 2, T(1, "r")),
	D("r", 6, "SS", 3, T(1, "smile")),
	D("r", 7, "L", 2, T(5, void 0, { sets: 2 })),
	D("r", 8, "SH", 2, T(1, "b")),
	D("r", 9, "D", 3, T(5, void 0, { bag: 5 })),
	D("r", 10, "S", 2, T(7, void 0, {
		bag: 5,
		heart: 2
	})),
	D("r", 11, "HSL", 5, T(1, "pawns", void 0, 3)),
	D("r", 12, "LD", 0, void 0, E(2, void 0, { smile: 3 })),
	D("r", 13, "", 0, void 0, w({ bonus: 2 }, void 0, { symbols: 1 })),
	D("r", 14, "SH", 3, T(1, "heart")),
	D("r", 15, "", 2, T(1, "smile")),
	D("r", 16, "S", 3, T(1, "cockade")),
	D("r", 17, "D", 3, w({ cockade: 1 })),
	D("r", 18, "", 1, w({ cockade: 1 }, void 0, { book: 3 })),
	D("r", 19, "H", 0, void 0, w({ bonus: 1 }, void 0, { symbols: 1 })),
	D("r", 20, "L", 2, T(2, void 0, { symbols: 1 })),
	D("g", 1, "LL", 4, T(2, "book")),
	D("g", 2, "L", 2, T(6, void 0, { symbols: 1 })),
	D("g", 3, "SD", 0, void 0, w({
		pawns: 2,
		bonus: 1
	})),
	D("g", 4, "SL", 2, T(1, "bag")),
	D("g", 5, "D", 0, void 0, E(1, "types")),
	D("g", 6, "SD", 5, T(3, "instant")),
	D("g", 7, "D", 2, T(1, "g")),
	D("g", 8, "D", 3, T(1, "bag")),
	D("g", 9, "SSL", 4, T(7, void 0, {
		book: 4,
		smile: 3
	})),
	D("g", 10, "SD", 0, void 0, E(2, void 0, { bag: 3 })),
	D("g", 11, "", 2, T(7, void 0, { heart: 3 })),
	D("g", 12, "SD", 0, void 0, E(1)),
	D("g", 13, "D", 1, T(4, void 0, {
		bag: 5,
		book: 3
	})),
	D("g", 14, "", 1, T(6, void 0, {
		smile: 4,
		heart: 2
	})),
	D("g", 15, "H", 0, void 0, E(2, void 0, { heart: 2 })),
	D("g", 16, "LD", 3, T(3, void 0, { smile: 4 })),
	D("g", 17, "", 1, T(1, "bonuses")),
	D("g", 18, "S", 0, void 0, E(1, "b")),
	D("g", 19, "D", 1, T(2, void 0, { instant: 3 })),
	D("g", 20, "DD", 0),
	D("b", 1, "", 3, T(3, "low")),
	D("b", 2, "S", 0, void 0, E(4)),
	D("b", 3, "D", 2, T(3, "sets")),
	D("b", 4, "H", 3, T(2, "heart")),
	D("b", 5, "LHSD", 0),
	D("b", 6, "", 0, void 0, w({
		pawns: 2,
		bonus: 1
	})),
	D("b", 7, "DD", 2, T(5, void 0, { g: 4 })),
	D("b", 8, "L", 0, void 0, E(3, void 0, { book: 2 })),
	D("b", 9, "H", 2, T(1, "mid")),
	D("b", 10, "", 4, T(4, "symbols")),
	D("b", 11, "", 1, T(4, void 0, { b: 4 })),
	D("b", 12, "D", 5, T(2, "high")),
	D("b", 13, "", 2, T(7, void 0, { bag: 6 })),
	D("b", 14, "", 0, void 0, E(1, "instant")),
	D("b", 15, "", 1, w({ cockade: 1 })),
	D("b", 16, "L", 0, void 0, w({ bonus: 1 }, void 0, { cockade: 1 })),
	D("b", 17, "S", 3, T(1, "book")),
	D("b", 18, "L", 2, T(3, void 0, { r: 4 })),
	D("b", 19, "S", 3, T(1, "top")),
	D("b", 20, "", 0, void 0, E(1)),
	D("n", 21, "", 0),
	{
		...D("r", 0, "", 0, void 0, E(6)),
		atlas: 62
	},
	{
		...D("g", 0, "", 2, T(1, "book")),
		extraScore: T(1, "smile"),
		atlas: 63
	},
	{
		...D("b", 0, "", 2, T(1, "bag")),
		extraScore: T(1, "heart"),
		atlas: 64
	}
], k = Object.fromEntries(O.map((e) => [e.id, e])), A = [
	"bluePawns",
	"greenPawns",
	"redPawns",
	"wild",
	"heart",
	"points",
	"cockade",
	"smile",
	"bag",
	"book"
], j = {
	points: { vp: 2 },
	cockade: { cockade: 1 }
}, M = {
	bluePawns: E(1, "b"),
	greenPawns: E(1, "g"),
	redPawns: E(1, "r")
}, N = (e = 0, t = 0, n = 0, r = 0) => ({
	pawns: e,
	vp: t,
	cockade: n,
	bonus: r
}), re = {
	2: [
		[N(0, 4, 0, 1), N()],
		[N(4, 0, 1), N()],
		[N(2, 4), N()],
		[N(4, 0, 0, 1), N()],
		[N(2, 0, 1, 1), N()],
		[N(0, 6), N()],
		[N(2, 2, 1), N()],
		[N(3, 3), N()],
		[N(1, 0, 2), N()]
	],
	3: [
		[
			N(0, 4, 0, 1),
			N(0, 3),
			N()
		],
		[
			N(4, 0, 1),
			N(2, 1),
			N()
		],
		[
			N(2, 4),
			N(1, 2),
			N()
		],
		[
			N(4, 0, 0, 1),
			N(2, 1),
			N()
		],
		[
			N(2, 0, 1, 1),
			N(0, 1, 1),
			N()
		],
		[
			N(0, 6),
			N(0, 3),
			N()
		],
		[
			N(2, 2, 1),
			N(1, 2),
			N()
		],
		[
			N(3, 3),
			N(0, 3),
			N()
		],
		[
			N(1, 0, 2),
			N(0, 1, 1),
			N()
		]
	],
	4: [
		[
			N(0, 4, 0, 1),
			N(0, 4),
			N(0, 2),
			N()
		],
		[
			N(4, 0, 1),
			N(2, 2),
			N(2),
			N()
		],
		[
			N(2, 4),
			N(1, 3),
			N(0, 2),
			N()
		],
		[
			N(4, 0, 0, 1),
			N(3, 1),
			N(1, 1),
			N()
		],
		[
			N(2, 0, 1, 1),
			N(1, 1, 1),
			N(0, 0, 1),
			N()
		],
		[
			N(0, 6),
			N(0, 4),
			N(0, 2),
			N()
		],
		[
			N(2, 2, 1),
			N(2, 0, 1),
			N(0, 2),
			N()
		],
		[
			N(3, 3),
			N(1, 3),
			N(0, 2),
			N()
		],
		[
			N(1, 0, 2),
			N(0, 2, 1),
			N(1, 1),
			N()
		]
	],
	5: [
		[
			N(0, 4, 0, 1),
			N(0, 0, 1),
			N(0, 2),
			N(0, 1),
			N()
		],
		[
			N(4, 0, 1),
			N(3, 1),
			N(2),
			N(1),
			N()
		],
		[
			N(2, 4),
			N(1, 3),
			N(0, 2),
			N(1),
			N()
		],
		[
			N(4, 0, 0, 1),
			N(3, 1),
			N(2),
			N(1),
			N()
		],
		[
			N(2, 0, 1, 1),
			N(1, 1, 1),
			N(0, 0, 1),
			N(1),
			N()
		],
		[
			N(0, 6),
			N(0, 4),
			N(0, 2),
			N(0, 1),
			N()
		],
		[
			N(2, 2, 1),
			N(2, 0, 1),
			N(0, 2),
			N(0, 1),
			N()
		],
		[
			N(3, 3),
			N(1, 3),
			N(1, 1),
			N(1),
			N()
		],
		[
			N(1, 0, 2),
			N(0, 2, 1),
			N(0, 0, 1),
			N(1),
			N()
		]
	]
}, P = (e) => [
	"r",
	"b",
	"g"
][Math.floor(e / 3)], ie = (e, t) => (e >= 4 ? 18 : 0) + (e % 2 == 1 ? 3 : 0) + Math.floor(t / 3) * 6 + t % 3, ae = {
	2: [N(3), N(2)],
	3: [
		N(3),
		N(2, 2),
		N(2)
	],
	4: [
		N(3),
		N(2, 0, 1),
		N(2, 1),
		N(1)
	],
	5: [
		N(3),
		N(2, 0, 1),
		N(2, 1),
		N(1),
		N()
	]
}, oe = {
	id: "minikincity",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"drafting",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.minikincity.name",
	descKey: "games.minikincity.desc",
	rulesKey: "games.minikincity.rules",
	icon: "🏡",
	iconImg: "games/minikincity.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/1010/2246/6379/files/Minikin_City_Rules_ENG_compressed_68709b69-fce1-4342-9553-3ebb57167c2b.pdf?v=1784709890" },
	minPlayers: 2,
	maxPlayers: 5,
	accent: "#326c61",
	releasedAt: "2026-10-31T00:42:34+08:00",
	search: {
		py: "xiao cheng da zuo",
		init: "xcdz"
	},
	hotseat: "cover",
	botDelayMs: 550
}, F = t.string().regex(/^(?:[rgb](?:[0-9]|1[0-9]|20)|n21)$/), I = t.object({ musicFestival: t.boolean().default(!1) }).prefault({}), se = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("keep"),
		cards: t.array(F).length(4)
	}),
	t.object({
		type: t.literal("play"),
		card: F
	}),
	t.object({
		type: t.literal("draft"),
		card: F
	}),
	t.object({
		type: t.literal("allocate"),
		card: F
	}),
	t.object({
		type: t.literal("bonus"),
		bonus: t.enum(A)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), L = t.object({
	id: F,
	pawns: t.int().nonnegative()
}), R = t.object({
	rewards: t.int(),
	city: t.int(),
	cockades: t.int(),
	total: t.int(),
	cards: t.record(t.string(), t.int()),
	cockadeCount: t.int()
}), ce = t.object({
	phase: t.enum([
		"keep",
		"play",
		"allocate",
		"bonus",
		"draft",
		"extra",
		"settle",
		"done"
	]),
	turn: t.string(),
	round: t.int(),
	lead: t.string(),
	rewards: t.array(t.int().min(0).max(8)).length(9),
	market: t.array(F),
	availableBonus: t.array(t.enum(A)),
	supply: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	ranking: t.array(t.string()),
	history: t.array(t.array(t.string())),
	finalRanking: t.array(t.string()),
	finalValues: t.record(t.string(), t.int()),
	pendingBonus: t.int().nonnegative(),
	finalRevealed: t.boolean(),
	players: t.array(t.object({
		rid: t.string(),
		city: t.array(L),
		reserve: t.int().nonnegative(),
		bonuses: t.array(t.enum(A)),
		rewardVP: t.int().nonnegative(),
		rewardCockades: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		kept: t.boolean(),
		hand: t.array(F).nullable(),
		score: R
	})),
	last: t.object({
		kind: t.enum([
			"play",
			"draft",
			"bonus",
			"allocate",
			"reward",
			"reveal",
			"final",
			"keep",
			"fill",
			"gain",
			"return",
			"showHand"
		]),
		rid: t.string(),
		card: F.optional(),
		bonus: t.enum(A).optional(),
		n: t.int().optional(),
		vp: t.int().optional(),
		cockade: t.int().optional()
	}).nullable()
}), le = t.object({ hand: t.array(F) }), ue = () => ({
	rewards: 0,
	city: 0,
	cockades: 0,
	total: 0,
	cards: {},
	cockadeCount: 0
});
function z(e) {
	let t = {
		book: 0,
		heart: 0,
		smile: 0,
		bag: 0,
		r: 0,
		g: 0,
		b: 0,
		sets: 0,
		symbols: 0,
		types: 0,
		instant: 0,
		pawns: e.reserve,
		bonuses: e.bonuses.length,
		cockade: e.rewardCockades,
		low: 0,
		mid: 0,
		high: 0,
		top: 0
	};
	for (let n of e.city) {
		let e = k[n.id];
		for (let n of e.symbols) t[{
			L: "book",
			H: "heart",
			S: "smile",
			D: "bag"
		}[n]] += 1;
		e.color !== "n" && (t[e.color] += 1), e.instant && (t.instant += 1), e.value >= 1 && e.value <= 20 && (t[e.value <= 5 ? "low" : e.value <= 10 ? "mid" : e.value <= 15 ? "high" : "top"] += 1), t.pawns += n.pawns;
	}
	for (let n of e.bonuses) (n === "book" || n === "heart" || n === "smile" || n === "bag") && (t[n] += 1);
	let n = +!!e.bonuses.includes("wild");
	for (; [
		"r",
		"g",
		"b"
	].reduce((e, n) => e + Math.max(0, t.sets + 1 - t[n]), 0) <= n;) t.sets += 1;
	t.r += n, t.g += n, t.b += n, t.symbols = Math.min(t.book, t.heart, t.smile, t.bag), t.types = [
		t.book,
		t.heart,
		t.smile,
		t.bag
	].filter((e) => e > 0).length, t.cockade += +!!e.bonuses.includes("cockade");
	for (let n of e.city) {
		let e = k[n.id];
		e.score?.reward.cockade && n.pawns === e.slots && (t.cockade += B(e.score, t).cockade ?? 0);
	}
	return t;
}
function B(e, t) {
	if (!e || Object.entries(e.require ?? {}).some(([e, n]) => t[e] < n)) return {};
	let n = e.per ? Math.floor(t[e.per] / (e.divisor ?? 1)) : 1;
	return Object.fromEntries(Object.entries(e.reward).map(([e, t]) => [e, t * n]));
}
function V(e) {
	let t = z(e), n = ue();
	n.rewards = e.rewardVP + (e.bonuses.includes("points") ? 2 : 0), n.cockadeCount = t.cockade, n.cockades = [
		0,
		1,
		3,
		6,
		10,
		15,
		21
	][Math.min(6, t.cockade)];
	for (let r of e.city) {
		let e = k[r.id], i = e.slots > 0 && r.pawns === e.slots ? (B(e.score, t).vp ?? 0) + (B(e.extraScore, t).vp ?? 0) : 0;
		n.cards[r.id] = i, n.city += i;
	}
	return n.total = n.rewards + n.city + n.cockades, n;
}
var H = (e, t = e.turn) => e.players.find((e) => e.rid === t), de = (e) => e.city.some((e) => e.pawns < k[e.id].slots);
function U(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function W(e, t, n) {
	return e.last = t, e.resume = n, e.phase = "settle", [{
		kind: t.kind,
		rid: t.rid,
		data: {
			...t,
			round: e.round,
			final: e.finalRevealed,
			position: e.rewardIndex + 1,
			cards: t.kind === "reveal" ? e.market : t.kind === "showHand" ? H(e, t.rid).hand : []
		}
	}];
}
function G(e, t, n) {
	let r = Math.min(e.supply, n.pawns ?? 0);
	return t.reserve += r, e.supply -= r, t.rewardVP += n.vp ?? 0, t.rewardCockades += n.cockade ?? 0, e.pendingBonus += n.bonus ?? 0, r;
}
function K(e) {
	return e.market = e.deck.splice(0, e.players.length + 1), e.played = [], e.turn = e.lead, e.ranking = [], W(e, {
		kind: "reveal",
		rid: e.turn
	}, "beginPlay");
}
function fe(e, t = !1) {
	let n = P(e.rewards[t ? 8 : e.round - 1]), r = Array.from({ length: e.players.length }, (t, n) => e.players[(e.players.findIndex((t) => t.rid === e.lead) + n) % e.players.length].rid);
	if (t) {
		for (let t of e.players) e.finalValues[t.rid] = t.hand.reduce((e, t) => e + (k[t].color === n ? k[t].value : 0), 0);
		return r.sort((t, n) => e.finalValues[n] - e.finalValues[t]);
	}
	let i = (t) => {
		let r = k[H(e, t).city.at(-1).id];
		return r.value === 21 ? 100 : r.value + (r.color === n ? 30 : 0);
	};
	return r.sort((e, t) => i(t) - i(e));
}
function q(e, t = !1) {
	e.turn = (t ? e.finalRanking : e.ranking)[e.rewardIndex];
	let n = H(e), r = t ? ae[e.players.length][e.rewardIndex] : re[e.players.length][e.rewards[e.round - 1]][e.rewardIndex], i = G(e, n, r);
	return W(e, {
		kind: "reward",
		rid: n.rid,
		n: i,
		vp: r.vp,
		cockade: r.cockade
	}, t ? "afterFinalReward" : "afterReward");
}
function pe(e) {
	let t = H(e), n = t.city.at(-1), r = B(k[n.id].instant, z(t)), i = G(e, t, r);
	return i || r.vp || r.cockade || r.bonus ? W(e, {
		kind: "gain",
		rid: t.rid,
		card: n.id,
		n: i,
		vp: r.vp,
		cockade: r.cockade
	}, "afterGain") : (e.resume = e.playExtra ? "afterExtra" : "afterPlay", me(e));
}
function me(e) {
	let t = H(e);
	if (e.resume === "afterCard") {
		let n = t.city.at(-1), r = Math.min(t.reserve, k[n.id].slots);
		return n.pawns = r, t.reserve -= r, r ? W(e, {
			kind: "fill",
			rid: t.rid,
			card: n.id,
			n: r
		}, "afterFill") : pe(e);
	}
	if (e.resume === "afterFill") return pe(e);
	if (e.resume === "afterGain" && (e.resume = e.playExtra ? "afterExtra" : "afterPlay"), t.reserve > 0 && de(t)) return e.phase = "allocate", [];
	if (e.pendingBonus > 0 && e.availableBonus.length) return e.phase = "bonus", [];
	switch (e.pendingBonus = 0, e.resume) {
		case "afterKeep": {
			let t = e.players.find((e) => !e.kept);
			return t ? (e.turn = t.rid, e.phase = "keep", []) : K(e);
		}
		case "beginPlay": return e.phase = "play", [];
		case "afterPlay": return e.played.length < e.players.length ? (e.turn = e.players[(e.players.findIndex((t) => t.rid === e.turn) + 1) % e.players.length].rid, e.phase = "play", []) : (e.ranking = fe(e), e.history.push([...e.ranking]), e.rewardIndex = 0, W(e, {
			kind: "final",
			rid: e.ranking[0]
		}, "beginRewards"));
		case "beginRewards": return q(e);
		case "afterReward": return e.rewardIndex += 1, e.rewardIndex < e.players.length ? q(e) : (e.turn = e.ranking.at(-1), e.phase = "draft", []);
		case "afterDraft": {
			let t = e.ranking.indexOf(e.turn);
			if (t > 0) return e.turn = e.ranking[t - 1], e.phase = "draft", [];
			let n = e.market[0];
			return e.deck.push(...e.market), e.market = [], W(e, {
				kind: "return",
				rid: e.turn,
				card: n
			}, "nextRound");
		}
		case "nextRound": return e.lead = e.ranking[0], e.round < 8 ? (e.round++, K(e)) : W(e, {
			kind: "final",
			rid: e.lead
		}, "beginFinal");
		case "beginFinal": return e.finalRevealed = !0, e.revealed = [], e.resume = "revealNext", me(e);
		case "revealNext":
			if (e.revealed.length < e.players.length) {
				let t = (e.players.findIndex((t) => t.rid === e.lead) + e.revealed.length) % e.players.length, n = e.players[t].rid;
				return e.revealed.push(n), e.finalValues[n] = e.players[t].hand.reduce((t, n) => t + (k[n].color === P(e.rewards[8]) ? k[n].value : 0), 0), W(e, {
					kind: "showHand",
					rid: n
				}, "revealNext");
			}
			return e.finalRanking = fe(e, !0), e.rewardIndex = 0, W(e, {
				kind: "final",
				rid: e.finalRanking[0]
			}, "beginFinalRewards");
		case "beginFinalRewards": return q(e, !0);
		case "afterFinalReward": return e.rewardIndex += 1, e.rewardIndex < e.players.length ? q(e, !0) : (e.turn = e.finalRanking[0], e.phase = "extra", []);
		case "afterExtra": return e.phase = "done", [];
	}
}
var he = {
	meta: oe,
	saveCompatibility: { version: "2" },
	schemas: {
		action: se,
		publicView: ce,
		privateView: le,
		config: I
	},
	setup(t, n, r) {
		let i = {
			seed: r,
			cursor: 0,
			players: n.map((e) => ({
				rid: e,
				hand: [],
				city: [],
				reserve: 0,
				bonuses: [],
				rewardVP: 0,
				rewardCockades: 0,
				kept: !1
			})),
			deck: [],
			rewards: [],
			market: [],
			availableBonus: [...A],
			supply: 75,
			phase: "keep",
			turn: n[0],
			round: 1,
			lead: n[0],
			ranking: [],
			history: [],
			finalRanking: [],
			finalValues: {},
			finalRevealed: !1,
			pendingBonus: 0,
			resume: "afterKeep",
			last: null,
			rewardIndex: 0,
			played: [],
			playExtra: !1,
			revealed: []
		};
		i.deck = U(i, O.filter((e) => e.value !== 0 || t.musicFestival).map((e) => e.id)), i.rewards = U(i, Array.from({ length: 9 }, (e, t) => t));
		for (let e of i.players) e.hand = i.deck.splice(0, 6);
		return i.lead = n[e(r, i.cursor++, n.length)], i.turn = i.lead, {
			state: i,
			fx: []
		};
	},
	reduce(e, t, n) {
		let r = { code: "games.minikincity.errAction" };
		if (t.type === "tick") {
			if (e.phase !== "settle") return {
				state: e,
				fx: []
			};
			let t = structuredClone(e);
			return {
				state: t,
				fx: me(t)
			};
		}
		if (e.phase === "done" || e.phase === "settle" || n.by !== e.turn) return r;
		let i = structuredClone(e), a = H(i), o;
		if (t.type === "keep" && i.phase === "keep") {
			if (new Set(t.cards).size !== 4 || t.cards.some((e) => !a.hand.includes(e))) return r;
			i.deck.push(...a.hand.filter((e) => !t.cards.includes(e))), a.hand = [...t.cards], a.kept = !0, o = W(i, {
				kind: "keep",
				rid: a.rid,
				n: 2
			}, "afterKeep");
		} else if (t.type === "play" && (i.phase === "play" || i.phase === "extra")) {
			if (!a.hand.includes(t.card)) return r;
			let e = a.hand.indexOf(t.card);
			i.playExtra = i.phase === "extra", a.hand.splice(e, 1), a.city.push({
				id: t.card,
				pawns: 0
			}), i.playExtra || i.played.push(a.rid), o = W(i, {
				kind: "play",
				rid: a.rid,
				card: t.card,
				n: e
			}, "afterCard");
		} else if (t.type === "allocate" && i.phase === "allocate") {
			let e = a.city.find((e) => e.id === t.card);
			if (!e || e.pawns >= k[e.id].slots || a.reserve < 1) return r;
			a.reserve--, e.pawns++, o = W(i, {
				kind: "allocate",
				rid: a.rid,
				card: t.card,
				n: e.pawns
			}, i.resume);
		} else if (t.type === "bonus" && i.phase === "bonus") {
			if (!i.availableBonus.includes(t.bonus)) return r;
			i.availableBonus.splice(i.availableBonus.indexOf(t.bonus), 1), i.pendingBonus--, a.bonuses.push(t.bonus);
			let e = G(i, a, B(M[t.bonus], z(a)));
			o = W(i, {
				kind: "bonus",
				rid: a.rid,
				bonus: t.bonus,
				n: e
			}, i.resume);
		} else if (t.type === "draft" && i.phase === "draft") {
			if (!i.market.includes(t.card)) return r;
			i.market.splice(i.market.indexOf(t.card), 1), a.hand.push(t.card), o = W(i, {
				kind: "draft",
				rid: a.rid,
				card: t.card
			}, "afterDraft");
		} else return r;
		return {
			state: i,
			fx: o
		};
	},
	viewFor(e, t) {
		return {
			public: {
				phase: e.phase,
				turn: e.turn,
				round: e.round,
				lead: e.lead,
				rewards: e.rewards,
				market: e.market,
				availableBonus: e.availableBonus,
				supply: e.supply,
				deckCount: e.deck.length,
				ranking: e.ranking,
				history: e.history,
				finalRanking: e.finalRanking,
				finalValues: e.finalValues,
				pendingBonus: e.pendingBonus,
				finalRevealed: e.finalRevealed,
				last: e.last,
				players: e.players.map((t) => ({
					rid: t.rid,
					city: t.city,
					reserve: t.reserve,
					bonuses: t.bonuses,
					rewardVP: t.rewardVP,
					rewardCockades: t.rewardCockades,
					handCount: t.hand.length,
					kept: t.kept,
					hand: e.revealed.includes(t.rid) ? t.hand : null,
					score: V(t)
				}))
			},
			private: { hand: e.players.find((e) => e.rid === t)?.hand ?? [] }
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((e) => [e.rid, V(e).total])), n = e.players.map((e) => e.rid).sort((n, r) => t[r] - t[n] || H(e, r).reserve - H(e, n).reserve), r = n[0];
		return {
			phase: "done",
			ranking: n,
			scores: t,
			winner: n.filter((n) => t[n] === t[r] && H(e, n).reserve === H(e, r).reserve)
		};
	},
	nextTickIn: (e) => e.phase === "settle" ? 480 : null
}, ge = {
	book: "games.minikincity.book",
	heart: "games.minikincity.heart",
	smile: "games.minikincity.smile",
	bag: "games.minikincity.bag",
	r: "games.minikincity.r",
	g: "games.minikincity.g",
	b: "games.minikincity.b",
	sets: "games.minikincity.sets",
	symbols: "games.minikincity.symbols",
	types: "games.minikincity.types",
	instant: "games.minikincity.instant",
	pawns: "games.minikincity.pawns",
	bonuses: "games.minikincity.bonuses",
	cockade: "games.minikincity.cockade",
	low: "games.minikincity.low",
	mid: "games.minikincity.mid",
	high: "games.minikincity.high",
	top: "games.minikincity.top"
}, J = {
	r: "games.minikincity.r",
	g: "games.minikincity.g",
	b: "games.minikincity.b",
	n: "games.minikincity.n"
}, _e = {
	bluePawns: "games.minikincity.bluePawns",
	greenPawns: "games.minikincity.greenPawns",
	redPawns: "games.minikincity.redPawns",
	wild: "games.minikincity.wild",
	heart: "games.minikincity.bonusHeart",
	points: "games.minikincity.points",
	cockade: "games.minikincity.bonusCockade",
	smile: "games.minikincity.bonusSmile",
	bag: "games.minikincity.bonusBag",
	book: "games.minikincity.bonusBook"
}, ve = {
	book: "games.minikincity.countBook",
	heart: "games.minikincity.countHeart",
	smile: "games.minikincity.countSmile",
	bag: "games.minikincity.countBag",
	r: "games.minikincity.countRed",
	g: "games.minikincity.countGreen",
	b: "games.minikincity.countBlue",
	sets: "games.minikincity.countSets",
	symbols: "games.minikincity.countSymbols",
	types: "games.minikincity.countTypes",
	instant: "games.minikincity.countInstant",
	pawns: "games.minikincity.countPawns",
	bonuses: "games.minikincity.countBonuses",
	cockade: "games.minikincity.countCockades",
	low: "games.minikincity.countLow",
	mid: "games.minikincity.countMid",
	high: "games.minikincity.countHigh",
	top: "games.minikincity.countTop",
	vp: "games.minikincity.countVp"
};
function ye() {
	let e = s(), t = (t, n) => e(ve[t], {
		n,
		plural: n === 1 ? "" : "s"
	}), n = (e) => Object.entries(e).filter(([, e]) => e).map(([e, n]) => t(e === "bonus" ? "bonuses" : e, n)).join(" · ");
	return {
		t: e,
		reward: n,
		effect: (r) => {
			if (!r) return e("games.minikincity.noEffect");
			let i = e("games.minikincity.gain", { reward: n(r.reward) });
			return r.per && (i = e("games.minikincity.per", {
				quantity: t(r.per, r.divisor ?? 1),
				reward: i
			})), r.require && (i = e("games.minikincity.condition", {
				condition: Object.entries(r.require).map(([e, n]) => t(e, n)).join(" · "),
				reward: i
			})), i;
		}
	};
}
//#endregion
//#region src/games/minikincity/art.tsx
var Y = (e) => `games/minikincity/${e}.svg`;
function X({ kind: e }) {
	return /* @__PURE__ */ v("img", {
		className: "mc-icon",
		src: Y(`icon-${e}`),
		alt: ""
	});
}
function Z({ id: e }) {
	return /* @__PURE__ */ v("img", {
		className: "mc-card-image",
		src: Y(e),
		alt: "",
		draggable: !1
	});
}
var be = {
	1: [[49.5, 65.8]],
	2: [[39.5, 65], [59, 65.2]],
	3: [
		[32.3, 63.5],
		[66.3, 63.7],
		[49.3, 67.7]
	],
	4: [
		[20.5, 62.8],
		[77.7, 62.8],
		[39.5, 66.9],
		[59, 66.9]
	],
	5: [
		[15.8, 63],
		[49.5, 63],
		[82.5, 63],
		[32.5, 67],
		[66.1, 67]
	]
};
function xe({ id: e, rid: t, n, filled: r, x: i, y: a }) {
	let { ref: o, hidden: s } = h(`mc-slot:${t}:${e}:${n}`);
	return /* @__PURE__ */ v("span", {
		ref: o,
		className: "mc-pawn-space",
		style: {
			left: `${i}%`,
			top: `${a}%`,
			visibility: s ? "hidden" : void 0
		},
		children: r && /* @__PURE__ */ v(X, { kind: "pawn" })
	});
}
function Se() {
	let e = g();
	return /* @__PURE__ */ v("svg", {
		className: "mc-legal-outline",
		"aria-hidden": "true",
		children: /* @__PURE__ */ v("rect", {
			x: "1",
			y: "1",
			rx: "8",
			style: {
				width: "calc(100% - 2px)",
				height: "calc(100% - 2px)"
			},
			strokeDasharray: "5 5",
			children: !e && /* @__PURE__ */ v("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-10",
				dur: "0.8s",
				repeatCount: "indefinite"
			})
		})
	});
}
function Ce({ id: e, pawns: t, rid: n, anchor: r, active: i, selected: a, onChoose: o, onDetails: s }) {
	let { t: c } = ye(), l = k[e], { ref: d, hidden: f } = h(r ?? null), p = c("games.minikincity.cardName", {
		color: c(J[l.color]),
		n: l.value
	});
	return /* @__PURE__ */ y("div", {
		ref: d,
		className: `mc-card${i ? " mc-legal" : ""}${a ? " mc-selected" : ""}`,
		style: { visibility: f ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ v("button", {
				className: "mc-card-face",
				disabled: !o,
				onClick: o,
				"aria-label": t !== void 0 && i ? c("games.minikincity.place", {
					color: c(J[l.color]),
					value: l.value,
					n: t,
					total: l.slots
				}) : p,
				"aria-pressed": o ? a : void 0,
				children: /* @__PURE__ */ v(Z, { id: e })
			}),
			t !== void 0 && n && (be[l.slots] ?? []).map(([r, i], a) => /* @__PURE__ */ v(xe, {
				id: e,
				rid: n,
				n: a + 1,
				filled: a < t,
				x: r,
				y: i
			}, a)),
			s && /* @__PURE__ */ v("button", {
				className: "mc-detail-button",
				"aria-label": `${c("games.minikincity.details")} · ${p}`,
				onClick: () => s(e),
				children: /* @__PURE__ */ v(u, { size: 15 })
			}),
			i && /* @__PURE__ */ v(Se, {})
		]
	});
}
function we({ id: e, active: t, onChoose: n, anchor: r }) {
	let { t: i } = ye(), { ref: a, hidden: o } = h(r ?? null);
	return /* @__PURE__ */ y("button", {
		ref: a,
		className: `mc-bonus${t ? " mc-legal" : ""}`,
		style: { visibility: o ? "hidden" : void 0 },
		disabled: !n,
		onClick: n,
		"aria-label": i(_e[e]),
		title: i(_e[e]),
		children: [/* @__PURE__ */ v("img", {
			src: Y(`bonus-${A.indexOf(e)}`),
			alt: ""
		}), t && /* @__PURE__ */ v(Se, {})]
	});
}
function Q({ name: e, className: t, children: n, inert: r }) {
	let { ref: i, hidden: a } = h(e);
	return /* @__PURE__ */ v("div", {
		ref: i,
		inert: r,
		className: t,
		style: { visibility: a ? "hidden" : void 0 },
		children: n
	});
}
//#endregion
//#region src/games/minikincity/view-player.tsx
var Te = {
	2: [22.1, 36.1],
	3: [
		22,
		36.1,
		50.1
	],
	4: [
		19.3,
		33.3,
		47.4,
		61.3
	],
	5: [
		17.8,
		31.9,
		45.9,
		59.9,
		73.9
	]
}, Ee = {
	keep: "games.minikincity.keep",
	play: "games.minikincity.play",
	allocate: "games.minikincity.allocate",
	bonus: "games.minikincity.bonus",
	draft: "games.minikincity.draft",
	extra: "games.minikincity.extra",
	settle: "games.minikincity.settle",
	done: "games.minikincity.done"
};
function De(e) {
	return /* @__PURE__ */ v(Oe, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function Oe({ pub: e, priv: t, members: r, myRid: s, send: u, readOnly: h = !1 }) {
	c();
	let { t: g, effect: _, reward: b } = ye(), x = o((e) => e.locale), S = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? ee(t, x) : e;
	}, [te, ne] = a({
		rid: s,
		key: ""
	}), [C, w] = a(null), [T, E] = a([]), [D, O] = a(null), j = C !== null || D !== null, M = i(null);
	n(() => {
		if (!j) return;
		let e = document.activeElement;
		return M.current?.querySelector("button")?.focus(), () => e?.focus();
	}, [j]);
	let N = h ? "done" : `${e.phase}:${e.round}:${e.last?.kind}:${e.last?.rid}:${e.last?.card}`, F = e.phase === "settle" && e.last && [
		"play",
		"fill",
		"bonus",
		"showHand"
	].includes(e.last.kind) ? e.last.rid : s, I = e.players.find((e) => e.rid === (te.key === N ? te.rid : F)) ?? e.players[0], se = e.players.find((e) => e.rid === s), L = !h && e.turn === s, R = t?.hand ?? se?.hand ?? [], ce = L && e.phase === "allocate", le = L && e.phase === "bonus", ue = L && e.phase === "draft", B = L && (e.phase === "play" || e.phase === "extra"), V = L && e.phase === "keep", H = T.filter((e) => R.includes(e)), de = z(I), U = C ? k[C] : null, W = [...R];
	e.phase === "settle" && e.last?.kind === "play" && e.last.rid === s && e.last.card && !W.includes(e.last.card) && W.splice(e.last.n ?? 0, 0, e.last.card);
	let G = [...e.market];
	e.phase === "settle" && (e.last?.kind === "draft" || e.last?.kind === "return") && e.last.card && !G.includes(e.last.card) && G.push(e.last.card);
	let K = [...e.availableBonus];
	e.phase === "settle" && e.last?.kind === "bonus" && e.last.bonus && !K.includes(e.last.bonus) && K.push(e.last.bonus);
	let fe = h ? g("games.minikincity.done") : L || e.phase === "settle" ? g(Ee[e.phase]) : g("games.minikincity.waiting", { name: S(e.turn) }), q = (e) => {
		V ? E(H.includes(e) ? H.filter((t) => t !== e) : H.length < 4 ? [...H, e] : H) : B && (u({
			type: "play",
			card: e
		}), E([]));
	};
	return /* @__PURE__ */ v(p, {
		adaptive: !0,
		className: "mc-screen",
		scroll: !1,
		banner: /* @__PURE__ */ y("div", {
			className: "mc-banner",
			inert: j,
			children: [/* @__PURE__ */ v(m, {
				tone: L ? "accent" : "info",
				accent: oe.accent,
				text: fe,
				chip: g("games.minikincity.round", { n: e.round })
			}), /* @__PURE__ */ v("div", {
				className: "mc-seats",
				children: e.players.map((t) => {
					let n = r.find((e) => e.rid === t.rid), i = e.ranking.indexOf(t.rid);
					return /* @__PURE__ */ v(Q, {
						name: `mc-seat:${t.rid}`,
						className: "mc-seat-anchor",
						children: /* @__PURE__ */ y("button", {
							className: `mc-seat${I.rid === t.rid ? " mc-seat-selected" : ""}${e.turn === t.rid && !h ? " mc-seat-turn" : ""}`,
							onClick: () => ne({
								rid: t.rid,
								key: N
							}),
							style: { borderColor: d[n?.colorIndex ?? 0]?.hex },
							children: [
								/* @__PURE__ */ v("b", { children: S(t.rid) }),
								/* @__PURE__ */ v("span", { children: i >= 0 ? g("games.minikincity.rank", { n: i + 1 }) : g("games.minikincity.handCount", { n: t.handCount }) }),
								/* @__PURE__ */ y("small", { children: [
									/* @__PURE__ */ v(X, { kind: "pawn" }),
									t.reserve,
									" · ",
									/* @__PURE__ */ v(X, { kind: "vp" }),
									t.rewardVP,
									" · ",
									/* @__PURE__ */ v(X, { kind: "cockade" }),
									t.rewardCockades
								] })
							]
						})
					}, t.rid);
				})
			})]
		}),
		actionsHeight: "mc-hand-height",
		actions: /* @__PURE__ */ y(Q, {
			name: "mc-hand",
			className: "mc-hand-tray",
			inert: j,
			children: [/* @__PURE__ */ y("div", {
				className: "mc-hand-heading",
				children: [/* @__PURE__ */ v("b", { children: g("games.minikincity.hand") }), V ? /* @__PURE__ */ y("button", {
					className: "mc-primary",
					disabled: H.length !== 4,
					onClick: () => {
						u({
							type: "keep",
							cards: H
						}), E([]);
					},
					children: [
						g("games.minikincity.confirmKeep"),
						" ",
						H.length,
						"/4"
					]
				}) : /* @__PURE__ */ v("span", { children: e.finalRevealed ? g("games.minikincity.finalValue", { n: e.finalValues[s] ?? 0 }) : g("games.minikincity.handCount", { n: R.length }) })]
			}), /* @__PURE__ */ v("div", {
				className: "mc-hand-row",
				children: W.map((e) => /* @__PURE__ */ v(Ce, {
					id: e,
					anchor: `mc-hand:${e}`,
					active: B || V,
					selected: H.includes(e),
					onChoose: B || V ? () => q(e) : void 0,
					onDetails: w
				}, e))
			})]
		}),
		overlay: C && U ? /* @__PURE__ */ v("div", {
			ref: M,
			className: "mc-modal",
			role: "dialog",
			"aria-modal": "true",
			onKeyDown: (e) => {
				e.key === "Tab" && (e.preventDefault(), M.current?.querySelector("button")?.focus()), e.key === "Escape" && (w(null), O(null));
			},
			"aria-label": g("games.minikincity.details"),
			children: /* @__PURE__ */ y("div", {
				className: "mc-detail-panel",
				children: [
					/* @__PURE__ */ v("button", {
						className: "mc-close",
						"aria-label": g("games.minikincity.close"),
						onClick: () => w(null),
						children: /* @__PURE__ */ v(l, { size: 22 })
					}),
					/* @__PURE__ */ v("img", {
						src: Y(U.id),
						alt: ""
					}),
					/* @__PURE__ */ y("div", { children: [
						/* @__PURE__ */ v("h2", { children: g("games.minikincity.cardName", {
							color: g(J[U.color]),
							n: U.value
						}) }),
						/* @__PURE__ */ v("h3", { children: g(U.instant ? "games.minikincity.instantEffect" : "games.minikincity.scoreEffect") }),
						/* @__PURE__ */ v("p", { children: _(U.instant ?? U.score) }),
						U.extraScore && /* @__PURE__ */ v("p", { children: _(U.extraScore) }),
						U.value === 21 && /* @__PURE__ */ v("p", { children: g("games.minikincity.alwaysFirst") }),
						/* @__PURE__ */ v("p", { children: g("games.minikincity.slots", { n: U.slots }) }),
						/* @__PURE__ */ v("div", {
							className: "mc-symbols",
							children: [
								"L",
								"H",
								"S",
								"D"
							].flatMap((e, t) => Array.from({ length: U.symbols.split(e).length - 1 }, (n, r) => /* @__PURE__ */ v(X, { kind: [
								"book",
								"heart",
								"smile",
								"bag"
							][t] }, `${e}${r}`)))
						})
					] })
				]
			})
		}) : D === null ? null : /* @__PURE__ */ v("div", {
			ref: M,
			className: "mc-modal",
			role: "dialog",
			"aria-modal": "true",
			onKeyDown: (e) => {
				e.key === "Tab" && (e.preventDefault(), M.current?.querySelector("button")?.focus()), e.key === "Escape" && (w(null), O(null));
			},
			"aria-label": g("games.minikincity.rewardTitle"),
			children: /* @__PURE__ */ y("div", {
				className: "mc-reward-panel",
				children: [
					/* @__PURE__ */ v("button", {
						className: "mc-close",
						"aria-label": g("games.minikincity.close"),
						onClick: () => O(null),
						children: /* @__PURE__ */ v(l, { size: 22 })
					}),
					/* @__PURE__ */ v("h2", { children: g(D === 8 ? "games.minikincity.finalColor" : "games.minikincity.rewardTitle") }),
					/* @__PURE__ */ v("img", {
						src: Y(D === 8 ? `final-${e.players.length - 2}` : `reward-${ie(e.players.length, e.rewards[D])}`),
						alt: ""
					}),
					(D === 8 ? ae[e.players.length] : re[e.players.length][e.rewards[D]]).map((e, t) => /* @__PURE__ */ y("p", { children: [
						/* @__PURE__ */ v("b", { children: g("games.minikincity.rank", { n: t + 1 }) }),
						" · ",
						b(e) || "—"
					] }, t))
				]
			})
		}),
		children: /* @__PURE__ */ y("div", {
			className: "mc-table",
			inert: j,
			children: [
				/* @__PURE__ */ v(f, {
					kind: "sheen",
					base: "#e4e6c9",
					className: "mc-texture"
				}),
				/* @__PURE__ */ v("div", {
					className: "mc-rounds",
					children: e.rewards.map((t, n) => /* @__PURE__ */ v(Q, {
						name: `mc-round:${n}`,
						className: "mc-round-anchor",
						children: /* @__PURE__ */ y("button", {
							className: `mc-round${n === e.round - 1 && !e.finalRevealed ? " mc-round-current" : ""}`,
							onClick: () => O(n),
							"aria-label": `${g(n === 8 ? "games.minikincity.finalColor" : "games.minikincity.round", { n: n + 1 })} · ${g(J[P(t)])}`,
							children: [/* @__PURE__ */ v("span", { children: n === 8 ? "★" : n + 1 }), /* @__PURE__ */ y("div", {
								className: "mc-round-art",
								children: [
									/* @__PURE__ */ v("img", {
										src: Y(n === 8 ? `final-${e.players.length - 2}` : `reward-${ie(e.players.length, t)}`),
										alt: ""
									}),
									n === 8 && /* @__PURE__ */ v("i", { className: `mc-color mc-color-${P(t)}` }),
									/* @__PURE__ */ v("div", {
										className: "mc-round-markers",
										children: (n === 8 ? e.finalRanking : e.history[n] ?? []).map((t, i) => /* @__PURE__ */ v("div", {
											className: "mc-marker-position",
											style: { top: `${Te[e.players.length][i] + (n === 8 ? .4 : 0)}%` },
											children: /* @__PURE__ */ v(Q, {
												name: `mc-marker:${n}:${t}`,
												className: "mc-marker-anchor",
												children: /* @__PURE__ */ v("span", {
													title: `${i + 1} ${S(t)}`,
													style: { background: d[r.find((e) => e.rid === t)?.colorIndex ?? 0]?.hex },
													children: i + 1
												})
											})
										}, t))
									})
								]
							})]
						})
					}, n))
				}),
				/* @__PURE__ */ y("div", {
					className: "mc-playfield",
					children: [/* @__PURE__ */ y("section", {
						className: "mc-public-area",
						children: [
							/* @__PURE__ */ y("div", {
								className: "mc-area-heading",
								children: [/* @__PURE__ */ v("h2", { children: g("games.minikincity.market") }), /* @__PURE__ */ v(Q, {
									name: "mc-deck",
									className: "mc-deck",
									children: /* @__PURE__ */ v("span", { children: e.deckCount })
								})]
							}),
							/* @__PURE__ */ v("div", {
								className: "mc-market",
								children: G.map((t) => /* @__PURE__ */ v(Ce, {
									id: t,
									anchor: `mc-market:${t}`,
									active: ue && e.market.includes(t),
									onChoose: ue && e.market.includes(t) ? () => u({
										type: "draft",
										card: t
									}) : void 0,
									onDetails: w
								}, t))
							}),
							/* @__PURE__ */ y("div", {
								className: "mc-pool",
								children: [/* @__PURE__ */ y(Q, {
									name: "mc-supply",
									className: "mc-supply",
									children: [/* @__PURE__ */ v(X, { kind: "pawn" }), g("games.minikincity.supply", { n: e.supply })]
								}), /* @__PURE__ */ v("div", {
									className: "mc-bonus-pool",
									children: A.filter((e) => K.includes(e)).map((t) => /* @__PURE__ */ v(we, {
										id: t,
										anchor: `mc-bonus:${t}`,
										active: le && e.availableBonus.includes(t),
										onChoose: le && e.availableBonus.includes(t) ? () => u({
											type: "bonus",
											bonus: t
										}) : void 0
									}, t))
								})]
							})
						]
					}), /* @__PURE__ */ y("section", {
						className: "mc-city-area",
						children: [
							/* @__PURE__ */ y("div", {
								className: "mc-area-heading",
								children: [/* @__PURE__ */ v("h2", { children: g("games.minikincity.city", { name: S(I.rid) }) }), /* @__PURE__ */ y(Q, {
									name: `mc-reserve:${I.rid}`,
									className: "mc-reserve",
									children: [/* @__PURE__ */ v(X, { kind: "pawn" }), I.reserve]
								})]
							}),
							/* @__PURE__ */ y("div", {
								className: "mc-city-stats",
								children: [
									[
										"book",
										"heart",
										"smile",
										"bag"
									].map((e) => /* @__PURE__ */ y("span", {
										title: g(ge[e]),
										children: [/* @__PURE__ */ v(X, { kind: e }), de[e]]
									}, e)),
									/* @__PURE__ */ y("span", {
										title: g("games.minikincity.cockade"),
										children: [/* @__PURE__ */ v(X, { kind: "cockade" }), de.cockade]
									}),
									/* @__PURE__ */ v("span", { children: g("games.minikincity.score", { n: I.score.total }) })
								]
							}),
							/* @__PURE__ */ v(Q, {
								name: `mc-city:${I.rid}`,
								className: "mc-city-cards",
								children: I.city.map((e) => /* @__PURE__ */ v(Ce, {
									id: e.id,
									pawns: e.pawns,
									rid: I.rid,
									anchor: `mc-card:${I.rid}:${e.id}`,
									active: ce && I.rid === s && e.pawns < k[e.id].slots,
									onChoose: ce && I.rid === s && e.pawns < k[e.id].slots ? () => u({
										type: "allocate",
										card: e.id
									}) : void 0,
									onDetails: w
								}, e.id))
							}),
							/* @__PURE__ */ v(Q, {
								name: `mc-bonuses:${I.rid}`,
								className: "mc-owned-bonuses",
								children: I.bonuses.map((e) => /* @__PURE__ */ v(we, {
									id: e,
									anchor: `mc-owned-bonus:${I.rid}:${e}`
								}, e))
							}),
							I.hand && /* @__PURE__ */ v("div", {
								className: "mc-final-hand",
								children: /* @__PURE__ */ y(Q, {
									name: `mc-final-hand:${I.rid}`,
									className: "mc-final-reveal",
									children: [/* @__PURE__ */ v("b", { children: g("games.minikincity.finalValue", { n: e.finalValues[I.rid] ?? 0 }) }), /* @__PURE__ */ v("div", { children: I.hand.map((e) => /* @__PURE__ */ v(Ce, {
										id: e,
										onDetails: w
									}, e)) })]
								})
							}, I.rid)
						]
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/games/minikincity/bot.ts
var ke = {
	pawnValue: 1.1,
	bonusValue: 4,
	symbolGrowth: .55,
	colorGrowth: .3,
	rankWeight: 1,
	reserveWeight: .05,
	completionBias: .5,
	futureWeight: .55
}, Ae = {
	...ke,
	pawnValue: 1.6,
	symbolGrowth: .2,
	colorGrowth: .1,
	reserveWeight: .15
};
function je(e) {
	let t = Math.floor(4294967296 / e.length) * e.length, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return e[n % e.length];
}
var Me = (e, t) => (e.vp ?? 0) + (e.pawns ?? 0) * t.pawnValue + (e.cockade ?? 0) * 3 + (e.bonus ?? 0) * t.bonusValue;
function Ne(e, t, n) {
	let r = z(e), i = Math.max(0, 8 - t);
	for (let e of [
		"book",
		"heart",
		"smile",
		"bag"
	]) r[e] += i * n.symbolGrowth;
	for (let e of [
		"r",
		"g",
		"b"
	]) r[e] += i * n.colorGrowth;
	return r.symbols = Math.min(r.book, r.heart, r.smile, r.bag), r.sets = Math.min(r.r, r.g, r.b), r.instant += i * .3, r.pawns += i * 2, r.cockade += i * .2, r;
}
function Pe(e, t, n) {
	if (!e) return 0;
	let r = Object.entries(e.require ?? {}).reduce((e, [n, r]) => e + Math.max(0, r - t[n]), 0);
	return Me(B({
		...e,
		require: void 0
	}, t), n) * .45 ** r;
}
function Fe(e, t, n) {
	let r = Ne(e, t, n), i = 0;
	for (let a of e.city) {
		let e = k[a.id];
		if (!e.slots) continue;
		let o = e.slots - a.pawns, s = o === 0 ? 1 : Math.min(.95, Math.max(0, (8 - t) * .6 + 1) / (o + 1));
		i += (Pe(e.score, r, n) + Pe(e.extraScore, r, n)) * s;
	}
	return i + V(e).cockades;
}
function Ie(e = {}) {
	return (t, n) => {
		let r = {
			...t.public.players.length > 2 ? Ae : ke,
			...e
		}, i = t.public, a = i.players.find((e) => e.rid === n.rid);
		if (!a || i.turn !== n.rid || i.phase === "settle" || i.phase === "done") return null;
		let o = t.private?.hand ?? [], s = {
			...a,
			hand: o
		}, c = n.difficulty === "weak", l = (e, t) => c ? je(e) : e.reduce((e, n) => t(n) > t(e) ? n : e), u = (e) => {
			let t = k[e], n = {
				...s,
				city: [...s.city, {
					id: e,
					pawns: Math.min(s.reserve, t.slots)
				}],
				reserve: Math.max(0, s.reserve - t.slots)
			}, a = z(n);
			return Me(B(t.instant, a), r) + (Fe(n, i.round, r) - Fe(s, i.round, r)) + r.futureWeight * t.symbols.length + (t.slots === 0 ? 0 : .15);
		};
		if (i.phase === "keep") {
			let e = [];
			for (let t = 0; t < o.length; t++) for (let n = t + 1; n < o.length; n++) e.push(o.filter((e, r) => r !== t && r !== n));
			return { action: {
				type: "keep",
				cards: l(e, (e) => e.reduce((e, t) => e + u(t), 0) + new Set(e.map((e) => k[e].color)).size)
			} };
		}
		if (i.phase === "play" || i.phase === "extra") {
			let e = P(i.rewards[i.round - 1]), t = (t) => {
				let n = k[t];
				if (i.phase === "extra") return 0;
				let a = (t) => k[t].value + (k[t].value === 21 ? 100 : k[t].color === e ? 30 : 0), o = i.players.filter((e) => e.rid !== s.rid && e.city.length === i.round).map((e) => e.city.at(-1).id), c = o.filter((e) => a(e) > a(t)).length, l = i.players.length - 1 - o.length, u = n.value === 21 ? 0 : n.color === e ? (20 - n.value) / 61 : (20 - n.value) * 2 / 61 + 20 / 61, d = Math.min(i.players.length - 1, Math.round(c + l * u));
				return Me(re[i.players.length][i.rewards[i.round - 1]][d], r);
			};
			return { action: {
				type: "play",
				card: l(o, (e) => u(e) + r.rankWeight * t(e) - r.reserveWeight * k[e].value * (k[e].color === P(i.rewards[8]) ? i.round / 8 : 0))
			} };
		}
		return i.phase === "draft" ? { action: {
			type: "draft",
			card: l(i.market, (e) => u(e) + (k[e].color === P(i.rewards[8]) ? k[e].value * r.reserveWeight * i.round / 8 : 0))
		} } : i.phase === "allocate" ? { action: {
			type: "allocate",
			card: l(s.city.filter((e) => e.pawns < k[e.id].slots), (e) => {
				let t = k[e.id], n = Ne(s, i.round, r);
				return (Pe(t.score, n, r) + Pe(t.extraScore, n, r)) / (t.slots - e.pawns) + r.completionBias / (t.slots - e.pawns);
			}).id
		} } : i.phase === "bonus" ? { action: {
			type: "bonus",
			bonus: l(i.availableBonus, (e) => {
				let t = {
					...s,
					bonuses: [...s.bonuses, e]
				};
				return Me(j[e] ?? B(M[e], z(t)), r) + Fe(t, i.round, r) - Fe(s, i.round, r) + +(e === "wild");
			})
		} } : null;
	};
}
var Le = Ie(), Re = (e, t, n) => e.type === "tick" ? "" : n({
	keep: "games.minikincity.keep",
	play: "games.minikincity.play",
	draft: "games.minikincity.draft",
	allocate: "games.minikincity.allocate",
	bonus: "games.minikincity.bonus"
}[e.type]), $ = (e, t = 32) => ({
	x: e.x + e.w / 2 - t / 2,
	y: e.y + e.h / 2 - t / 2,
	w: t,
	h: t
});
function ze({ from: e, to: t, count: n, ms: r }) {
	return /* @__PURE__ */ v(_, { children: Array.from({ length: n }, (n, i) => /* @__PURE__ */ v(x, {
		from: {
			...$(e),
			x: $(e).x + i * 5
		},
		to: {
			...$(t),
			x: $(t).x + (i % 3 - 1) * 7
		},
		ms: r,
		children: /* @__PURE__ */ v("span", {
			className: "mc-flying-pawn",
			children: /* @__PURE__ */ v(X, { kind: "pawn" })
		})
	}, i)) });
}
function Be({ at: e, cards: t, ms: n }) {
	let a = i(null);
	return r(() => {
		let e = a.current?.animate([{
			transform: "perspective(700px) rotateY(-90deg)",
			opacity: .2
		}, {
			transform: "perspective(700px) rotateY(0)",
			opacity: 1
		}], {
			duration: n,
			easing: "cubic-bezier(.2,.7,.2,1)",
			fill: "both"
		});
		return () => e?.cancel();
	}, [n]), /* @__PURE__ */ v("div", {
		ref: a,
		className: "mc-flip-hand",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: t.map((e) => /* @__PURE__ */ v("div", {
			className: "mc-flip-card",
			children: /* @__PURE__ */ v(Z, { id: e })
		}, e))
	});
}
var Ve = {
	play(e, t) {
		let n = e.data, r = `mc-hand:${n.card}`, i = `mc-card:${e.rid}:${n.card}`, a = t.anchor(e.rid === t.myRid ? r : `mc-seat:${e.rid}`) ?? t.anchor("mc-hand"), o = t.anchor(i) ?? t.anchor(`mc-seat:${e.rid}`);
		return !a || !o || !n.card ? null : {
			ms: 480,
			hide: t.queued ? [] : [i, ...e.rid === t.myRid ? [r] : []],
			node: /* @__PURE__ */ v(x, {
				from: a,
				to: o,
				ms: 480,
				children: /* @__PURE__ */ v("div", {
					className: "mc-flying-card",
					children: /* @__PURE__ */ v(Z, { id: n.card })
				})
			})
		};
	},
	fill(e, t) {
		let n = e.data, r = t.anchor(`mc-reserve:${e.rid}`) ?? t.anchor(`mc-seat:${e.rid}`);
		if (!r || !n.card) return null;
		let i = Array.from({ length: n.n ?? 0 }, (t, r) => `mc-slot:${e.rid}:${n.card}:${r + 1}`);
		return {
			ms: 480,
			hide: t.queued ? [] : i,
			node: /* @__PURE__ */ v(_, { children: i.map((e) => {
				let n = t.anchor(e);
				return n ? /* @__PURE__ */ v(x, {
					from: $(r),
					to: $(n, n.w),
					ms: 480,
					children: /* @__PURE__ */ v("span", {
						className: "mc-flying-pawn",
						children: /* @__PURE__ */ v(X, { kind: "pawn" })
					})
				}, e) : null;
			}) })
		};
	},
	gain(e, t) {
		let n = e.data, r = t.anchor("mc-supply"), i = t.anchor(`mc-card:${e.rid}:${n.card}`) ?? t.anchor(`mc-seat:${e.rid}`), a = t.anchor(`mc-reserve:${e.rid}`) ?? t.anchor(`mc-seat:${e.rid}`);
		return i ? {
			ms: 480,
			node: /* @__PURE__ */ y(_, { children: [
				!!n.n && r && a && /* @__PURE__ */ v(ze, {
					from: r,
					to: a,
					count: n.n,
					ms: 480
				}),
				!!n.vp && /* @__PURE__ */ y(b, {
					at: i,
					ms: 480,
					children: [
						"+",
						n.vp,
						" ",
						/* @__PURE__ */ v(X, { kind: "vp" })
					]
				}),
				!!n.cockade && /* @__PURE__ */ y(b, {
					at: i,
					ms: 480,
					children: [
						"+",
						n.cockade,
						" ",
						/* @__PURE__ */ v(X, { kind: "cockade" })
					]
				}),
				!n.n && !n.vp && !n.cockade && /* @__PURE__ */ v(S, {
					at: i,
					ms: 480
				})
			] })
		} : null;
	},
	draft(e, t) {
		let n = e.data, r = `mc-market:${n.card}`, i = e.rid === t.myRid ? `mc-hand:${n.card}` : `mc-seat:${e.rid}`, a = t.anchor(r), o = t.anchor(i);
		return !a || !o || !n.card ? null : {
			ms: 480,
			hide: t.queued ? [] : [r, ...e.rid === t.myRid ? [i] : []],
			node: /* @__PURE__ */ v(x, {
				from: a,
				to: o,
				ms: 480,
				children: /* @__PURE__ */ v("div", {
					className: "mc-flying-card",
					children: /* @__PURE__ */ v(Z, { id: n.card })
				})
			})
		};
	},
	return(e, t) {
		let n = e.data, r = `mc-market:${n.card}`, i = t.anchor(r), a = t.anchor("mc-deck");
		return !i || !a || !n.card ? null : {
			ms: 480,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ v(x, {
				from: i,
				to: a,
				ms: 480,
				children: /* @__PURE__ */ v("div", {
					className: "mc-flying-card",
					children: /* @__PURE__ */ v(Z, { id: n.card })
				})
			})
		};
	},
	reveal(e, t) {
		let n = e.data, r = t.anchor("mc-deck");
		return r ? {
			ms: 480,
			hide: t.queued ? [] : n.cards.map((e) => `mc-market:${e}`),
			node: /* @__PURE__ */ v(_, { children: n.cards.map((e) => {
				let n = t.anchor(`mc-market:${e}`);
				return n ? /* @__PURE__ */ v(x, {
					from: r,
					to: n,
					ms: 480,
					children: /* @__PURE__ */ v("div", {
						className: "mc-flying-card",
						children: /* @__PURE__ */ v(Z, { id: e })
					})
				}, e) : null;
			}) })
		} : null;
	},
	allocate(e, t) {
		let n = e.data, r = t.anchor(`mc-reserve:${e.rid}`) ?? t.anchor(`mc-seat:${e.rid}`), i = `mc-slot:${e.rid}:${n.card}:${n.n}`, a = t.anchor(i) ?? t.anchor(`mc-seat:${e.rid}`);
		return !r || !a ? null : {
			ms: 480,
			hide: t.queued ? [] : [i],
			node: /* @__PURE__ */ v(x, {
				from: $(r),
				to: $(a, Math.max(16, a.w)),
				ms: 480,
				children: /* @__PURE__ */ v("span", {
					className: "mc-flying-pawn",
					children: /* @__PURE__ */ v(X, { kind: "pawn" })
				})
			})
		};
	},
	bonus(e, t) {
		let n = e.data;
		if (!n.bonus) return null;
		let r = `mc-bonus:${n.bonus}`, i = `mc-owned-bonus:${e.rid}:${n.bonus}`, a = t.anchor(r), o = t.anchor(i) ?? t.anchor(`mc-seat:${e.rid}`), s = t.anchor("mc-supply"), c = t.anchor(`mc-reserve:${e.rid}`) ?? t.anchor(`mc-seat:${e.rid}`);
		return !a || !o ? null : {
			ms: 480,
			hide: t.queued ? [] : [r, i],
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(x, {
				from: a,
				to: o,
				ms: 480,
				children: /* @__PURE__ */ v("img", {
					className: "mc-flying-bonus",
					src: Y(`bonus-${A.indexOf(n.bonus)}`),
					alt: ""
				})
			}), !!n.n && s && c && /* @__PURE__ */ v(ze, {
				from: s,
				to: c,
				count: n.n,
				ms: 480
			})] })
		};
	},
	reward(e, t) {
		let n = e.data, r = t.anchor(`mc-seat:${e.rid}`), i = t.anchor(`mc-marker:${n.final ? 8 : n.round - 1}:${e.rid}`) ?? t.anchor(`mc-round:${n.final ? 8 : n.round - 1}`), a = t.anchor("mc-supply"), o = t.anchor(`mc-reserve:${e.rid}`) ?? r;
		if (!r || !i) return null;
		let s = d[t.member(e.rid ?? "")?.colorIndex ?? 0]?.hex;
		return {
			ms: 480,
			hide: t.queued ? [] : [`mc-marker:${n.final ? 8 : n.round - 1}:${e.rid}`],
			node: /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v(x, {
					from: $(r, 22),
					to: i,
					ms: 480,
					children: /* @__PURE__ */ v("span", {
						className: "mc-reward-chip",
						style: { background: s },
						children: n.position
					})
				}),
				!!n.n && a && o && /* @__PURE__ */ v(ze, {
					from: a,
					to: o,
					count: n.n,
					ms: 480
				}),
				!!n.vp && /* @__PURE__ */ y(b, {
					at: r,
					ms: 480,
					children: [
						"+",
						n.vp,
						" ",
						/* @__PURE__ */ v(X, { kind: "vp" })
					]
				}),
				!!n.cockade && /* @__PURE__ */ y(b, {
					at: r,
					ms: 480,
					children: [
						"+",
						n.cockade,
						" ",
						/* @__PURE__ */ v(X, { kind: "cockade" })
					]
				})
			] })
		};
	},
	showHand(e, t) {
		let n = e.data, r = `mc-final-hand:${e.rid}`, i = t.anchor(r);
		return i ? {
			ms: 480,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ v(Be, {
				at: i,
				cards: n.cards,
				ms: 480
			})
		} : null;
	},
	final(e, t) {
		let n = t.anchor(`mc-seat:${e.rid}`);
		return n ? {
			ms: 480,
			node: /* @__PURE__ */ v(S, {
				at: n,
				ms: 480
			})
		} : null;
	},
	keep(e, t) {
		let n = t.anchor(e.rid === t.myRid ? "mc-hand" : `mc-seat:${e.rid}`), r = t.anchor("mc-deck");
		return !n || !r ? null : {
			ms: 480,
			node: /* @__PURE__ */ v(_, { children: [0, 1].map((e) => /* @__PURE__ */ v(x, {
				from: {
					...$(n, 55),
					x: $(n, 55).x + e * 17
				},
				to: r,
				ms: 480,
				children: /* @__PURE__ */ v("div", { className: "mc-card-back" })
			}, e)) })
		};
	}
};
//#endregion
//#region src/games/minikincity/game-over.tsx
function He({ result: e, public: t, private: n, members: r, myRid: i, hintCount: s, onPlayAgain: c, onBackToLobby: u }) {
	let d = t, { t: f } = ye(), p = o((e) => e.locale), [m, h] = a(!0), g = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? ee(t, p) : e;
	};
	return /* @__PURE__ */ y("div", {
		className: "mc-over mc-screen",
		children: [
			/* @__PURE__ */ v("div", {
				className: "mc-over-board",
				inert: m,
				children: /* @__PURE__ */ v(Oe, {
					pub: d,
					priv: n,
					members: r,
					myRid: i,
					send: () => void 0,
					readOnly: !0
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "mc-result-layer",
				hidden: !m,
				inert: !m,
				children: [
					/* @__PURE__ */ v(ne, {}),
					/* @__PURE__ */ y("header", {
						className: "mc-result-heading",
						children: [
							/* @__PURE__ */ v(X, { kind: "pawn" }),
							/* @__PURE__ */ v("h1", { children: f("games.minikincity.resultTitle") }),
							/* @__PURE__ */ v("button", {
								className: "mc-close",
								"aria-label": f("games.minikincity.review"),
								onClick: () => h(!1),
								children: /* @__PURE__ */ v(l, { size: 24 })
							})
						]
					}),
					/* @__PURE__ */ y("div", {
						className: "mc-result-scroll",
						children: [
							/* @__PURE__ */ v("div", {
								className: "mc-winners",
								children: e.winner.map((e) => /* @__PURE__ */ y("strong", { children: [
									g(e),
									" · ",
									f("games.minikincity.winner")
								] }, e))
							}),
							/* @__PURE__ */ v("div", {
								className: "mc-score-scroll",
								children: /* @__PURE__ */ y("table", {
									className: "mc-score-table",
									"data-players": d.players.length,
									children: [/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { children: f("games.minikincity.done") }), e.ranking.map((t) => /* @__PURE__ */ y("th", { children: [g(t), e.winner.includes(t) && /* @__PURE__ */ v(X, { kind: "cockade" })] }, t))] }) }), /* @__PURE__ */ y("tbody", { children: [[
										["games.minikincity.rewardsScore", "rewards"],
										["games.minikincity.cityScore", "city"],
										["games.minikincity.cockadeScore", "cockades"],
										["games.minikincity.total", "total"]
									].map(([t, n]) => /* @__PURE__ */ y("tr", {
										className: n === "total" ? "mc-total-row" : "",
										children: [/* @__PURE__ */ v("th", { children: f(t) }), e.ranking.map((e) => /* @__PURE__ */ v("td", { children: d.players.find((t) => t.rid === e).score[n] }, e))]
									}, t)), /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { children: f("games.minikincity.unused") }), e.ranking.map((e) => /* @__PURE__ */ v("td", { children: d.players.find((t) => t.rid === e).reserve }, e))] })] })]
								})
							}),
							/* @__PURE__ */ y("details", {
								className: "mc-score-details",
								children: [/* @__PURE__ */ v("summary", { children: f("games.minikincity.cityScore") }), d.players.map((e) => /* @__PURE__ */ y("section", { children: [/* @__PURE__ */ v("h2", { children: g(e.rid) }), /* @__PURE__ */ v("div", { children: Object.entries(e.score.cards).map(([e, t]) => /* @__PURE__ */ y("span", { children: [
									f("games.minikincity.cardName", {
										color: f(J[k[e].color]),
										n: k[e].value
									}),
									" · ",
									t
								] }, e)) })] }, e.rid))]
							}),
							s !== void 0 && /* @__PURE__ */ v("p", { children: f("session.hint.usedCount", { n: s }) }),
							e.autopilot && Object.entries(e.autopilot).map(([e, t]) => /* @__PURE__ */ y("p", { children: [
								g(e),
								" · ",
								f("session.autopilot.share", { n: Math.round(t * 100) })
							] }, e))
						]
					})
				]
			}),
			/* @__PURE__ */ y("footer", {
				className: "mc-result-actions",
				children: [
					/* @__PURE__ */ v("button", {
						className: "mc-primary",
						onClick: () => h(!m),
						children: f(m ? "games.minikincity.review" : "games.minikincity.showResult")
					}),
					c && /* @__PURE__ */ v(te, {
						compact: !0,
						label: f("session.result.playAgain"),
						confirmLabel: f("games.minikincity.confirmAgain"),
						onConfirm: c
					}),
					" ",
					u && /* @__PURE__ */ v(te, {
						compact: !0,
						label: f("session.result.backToLobby"),
						confirmLabel: f("games.minikincity.confirmBack"),
						onConfirm: u
					}),
					" ",
					!c && !u && /* @__PURE__ */ v("span", { children: f("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/minikincity/options.tsx
function Ue({ value: e, onChange: t }) {
	let n = s(), r = I.safeParse(e), i = r.success ? r.data : I.parse(void 0);
	return /* @__PURE__ */ v(C, {
		checked: i.musicFestival,
		label: n("games.minikincity.musicFestival"),
		accent: oe.accent,
		onChange: () => t({
			...i,
			musicFestival: !i.musicFestival
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/minikincity/entry.tsx
var We = {
	definition: he,
	View: De,
	bot: Le,
	describe: Re,
	fx: Ve,
	OverView: He,
	Options: Ue,
	locales: {
		zh: {
			name: "小城大作",
			countBook: "{{n}} 本书",
			countHeart: "{{n}} 个爱心",
			countSmile: "{{n}} 个笑脸",
			countBag: "{{n}} 个钱袋",
			countRed: "{{n}} 张红色城市牌",
			countGreen: "{{n}} 张绿色城市牌",
			countBlue: "{{n}} 张蓝色城市牌",
			countSets: "{{n}} 套三色牌",
			countSymbols: "{{n}} 套四符号",
			countTypes: "{{n}} 种符号",
			countInstant: "{{n}} 张带即时效果的城市牌",
			countPawns: "{{n}} 个小人",
			countBonuses: "{{n}} 枚奖励标记",
			countCockades: "{{n}} 枚勋章",
			countLow: "{{n}} 张1–5号城市牌",
			countMid: "{{n}} 张6–10号城市牌",
			countHigh: "{{n}} 张11–15号城市牌",
			countTop: "{{n}} 张16–20号城市牌",
			countVp: "{{n}} 胜利点",
			desc: "将遗落的小物件建成奇妙城市，争取奖励，让小人搬进最有价值的建筑。",
			errAction: "当前无法执行此操作，请重新选择。",
			musicFestival: "音乐节宣传牌",
			round: "第 {{n}} / 8 轮",
			finalColor: "终局主色",
			keep: "选择保留 4 张城市牌",
			confirmKeep: "保留这 4 张牌",
			play: "选择一张手牌加入城市",
			draft: "选择一张市场牌加入手牌",
			allocate: "点击城市牌的空位，分配小人",
			bonus: "选择一个奖励标记",
			extra: "选择额外加入城市的手牌",
			settle: "正在结算",
			done: "城市落成",
			waiting: "等待 {{name}}",
			hand: "手牌",
			market: "公开市场",
			city: "{{name}}的城市",
			bonuses: "奖励标记",
			supply: "公共小人 {{n}}",
			reserve: "未使用小人 {{n}}",
			deck: "城市牌堆 {{n}}",
			close: "关闭",
			details: "查看牌面详情",
			cardName: "{{color}} {{n}} 号",
			r: "红色",
			g: "绿色",
			b: "蓝色",
			n: "无色",
			book: "书本",
			heart: "爱心",
			smile: "笑脸",
			bag: "钱袋",
			sets: "三色牌套",
			symbols: "四符号套",
			types: "符号种类",
			instant: "即时效果",
			pawns: "小人",
			cockade: "勋章",
			low: "1–5 号城市牌",
			mid: "6–10 号城市牌",
			high: "11–15 号城市牌",
			top: "16–20 号城市牌",
			vp: "胜利点",
			gain: "获得 {{reward}}",
			per: "每{{quantity}}，{{reward}}",
			condition: "拥有{{condition}}时，{{reward}}",
			count: "{{n}} 个{{metric}}",
			scoreEffect: "填满小人后计分",
			instantEffect: "出牌时立即生效",
			noEffect: "这张牌没有额外效果。",
			symbolsLabel: "提供的符号",
			slots: "小人空位 {{n}}",
			place: "向 {{color}} {{value}} 号放置一个小人（{{n}} / {{total}}）",
			score: "{{n}} 分",
			handCount: "{{n}} 张手牌",
			rank: "第 {{n}} 名",
			lastRank: "本轮名次",
			bluePawns: "立即按城市中蓝色牌数获得小人",
			greenPawns: "立即按城市中绿色牌数获得小人",
			redPawns: "立即按城市中红色牌数获得小人",
			wild: "每项效果中视为一张任选颜色城市牌",
			points: "终局获得 2 胜利点",
			bonusHeart: "增加一个爱心",
			bonusSmile: "增加一个笑脸",
			bonusBag: "增加一个钱袋",
			bonusBook: "增加一本书",
			bonusCockade: "终局增加一枚勋章",
			alwaysFirst: "本轮排名始终第一",
			rewardTitle: "本轮奖励",
			rewardsScore: "奖励与标记",
			cityScore: "城市牌计分",
			cockadeScore: "勋章计分",
			total: "总分",
			unused: "未使用小人",
			winner: "获胜",
			resultTitle: "小小城市，大大成就",
			review: "回看城市",
			showResult: "展开计分表",
			confirmAgain: "确定开始新的一局吗？",
			confirmBack: "确定返回大厅吗？",
			finalHand: "终局揭示的手牌",
			finalValue: "主色总和 {{n}}",
			claim: "领取此标记",
			chooseCard: "选择此牌",
			removeCard: "取消选择此牌",
			scoreNow: "当前城市得分",
			rules: "目标：\n用城市牌和小人建造城市。经过 8 轮及一次终局竞赛后，胜利点最多者获胜。同分时未使用小人较多者获胜，仍相同则共享胜利。\n\n准备：\n按人数选择 9 张奖励牌，随机排列。第 9 张的颜色是终局主色。每人从 6 张城市牌中保留 4 张，其余放回牌堆底。首家随机决定。音乐节宣传牌可在开局选项中加入，默认关闭。\n\n每轮流程：\n· 展示人数加 1 张城市牌作为公开市场。\n· 从首家起顺时针，每人打一张手牌，加入自己的城市。有闪电的牌立即执行效果。右上方符号从出牌起持续有效。\n· 本轮奖励牌颜色的城市牌优先，按数值从高到低排名；其他颜色随后按数值从高到低排名。同为非主色且数值相同，先出牌者优先。无色 21 号始终第一。\n· 按名次领取奖励牌对应的胜利点、勋章、小人或奖励标记。奖励标记从公共池选择，每枚只能被一人领取。\n· 从最后一名起反向选择市场中的一张牌加入手牌。剩余一张放回牌堆底。本轮第一名成为下轮首家，出牌仍顺时针。\n\n小人分配：\n获得小人时必须立即放入自己城市牌的空位，可自由分配，放下后不得挪动。没有足够空位时保留多余小人；以后打出有空位的牌，必须先用这些小人尽量填满。只有填满空位的城市牌，底部计分或勋章效果才生效。公共小人供应为 75 个，耗尽时本版本只领取剩余数量。\n\n图例与条件：\n· 书本、爱心、笑脸、钱袋来自城市牌右上方和奖励标记；不要求牌已填满。\n· 箭头左侧的条件全部达到时，获得右侧奖励一次。\n·  乘号效果按对应数量计算。\n· 三色牌套由红、绿、蓝各一张组成，四符号套由四种普通符号各一个组成。\n· 三色奖励标记对每项效果可以独立选择颜色，但一套中只补一张牌。\n· 数值范围只计城市中对应号码的牌，0 号和 21 号不计入 1–20 的任何区间。\n\n终局：\n第 8 轮补牌后，从当轮第一名起顺时针揭示手牌。将手牌中终局主色的数值相加，按总和排名，相同则先揭示者优先。领取终局奖励并分配小人后，第一名额外打一张手牌，照常执行即时效果和放置小人。\n分别计算奖励牌和标记的胜利点、填满的城市牌效果，以及勋章得分。勋章 1、2、3、4、5、6 枚或更多，依次获得 1、3、6、10、15、21 胜利点。未填满的牌不提供底部胜利点或勋章。\n音乐节宣传牌：\n· 红色 0 号牌：立即获得 6 个小人。\n· 绿色 0 号牌：填满后，每个书本和每个笑脸各获得 1 分。\n· 蓝色 0 号牌：填满后，每个钱袋和每个爱心各获得 1 分。"
		},
		en: {
			name: "Minikin City",
			countBook: "{{n}} book{{plural}}",
			countHeart: "{{n}} heart{{plural}}",
			countSmile: "{{n}} smile{{plural}}",
			countBag: "{{n}} money bag{{plural}}",
			countRed: "{{n}} red City card{{plural}}",
			countGreen: "{{n}} green City card{{plural}}",
			countBlue: "{{n}} blue City card{{plural}}",
			countSets: "{{n}} color set{{plural}}",
			countSymbols: "{{n}} symbol set{{plural}}",
			countTypes: "{{n}} symbol type{{plural}}",
			countInstant: "{{n}} City card{{plural}} with an Instant effect",
			countPawns: "{{n}} Minikin{{plural}}",
			countBonuses: "{{n}} Bonus token{{plural}}",
			countCockades: "{{n}} Cockade{{plural}}",
			countLow: "{{n}} City card{{plural}} numbered 1–5",
			countMid: "{{n}} City card{{plural}} numbered 6–10",
			countHigh: "{{n}} City card{{plural}} numbered 11–15",
			countTop: "{{n}} City card{{plural}} numbered 16–20",
			countVp: "{{n}} VP",
			desc: "Turn forgotten objects into a tiny city, win rewards, and give your Minikins valuable homes.",
			errAction: "That action is unavailable. Please choose again.",
			musicFestival: "Music Festival promo",
			round: "Round {{n}} / 8",
			finalColor: "Final color",
			keep: "Keep 4 City cards",
			confirmKeep: "Keep these 4 cards",
			play: "Play a hand card into your city",
			draft: "Take a market card into your hand",
			allocate: "Place Minikins on empty city spaces",
			bonus: "Choose a Bonus token",
			extra: "Play your extra City card",
			settle: "Resolving rewards",
			done: "City complete",
			waiting: "Waiting for {{name}}",
			hand: "Hand",
			market: "Open display",
			city: "{{name}}’s city",
			bonuses: "Bonus tokens",
			supply: "Supply: {{n}} Minikins",
			reserve: "Unused Minikins: {{n}}",
			deck: "City deck: {{n}}",
			close: "Close",
			details: "Inspect card",
			cardName: "{{color}} {{n}}",
			r: "Red",
			g: "Green",
			b: "Blue",
			n: "Colorless",
			book: "books",
			heart: "hearts",
			smile: "smiles",
			bag: "money bags",
			sets: "color sets",
			symbols: "symbol sets",
			types: "symbol types",
			instant: "Instant effects",
			pawns: "Minikins",
			cockade: "Cockades",
			low: "City cards 1–5",
			mid: "City cards 6–10",
			high: "City cards 11–15",
			top: "City cards 16–20",
			vp: "VP",
			gain: "Gain {{reward}}",
			per: "{{reward}} for every {{quantity}}.",
			condition: "{{reward}} if you have {{condition}}.",
			count: "{{n}} {{metric}}",
			scoreEffect: "Score when all spaces are filled",
			instantEffect: "Resolve immediately when played",
			noEffect: "This card has no additional effect.",
			symbolsLabel: "Symbols provided",
			slots: "Minikin spaces: {{n}}",
			place: "Place a Minikin on {{color}} {{value}} ({{n}} / {{total}})",
			score: "{{n}} VP",
			handCount: "{{n}} hand cards",
			rank: "Rank {{n}}",
			lastRank: "Round ranking",
			bluePawns: "Immediately gain a Minikin for each blue City card",
			greenPawns: "Immediately gain a Minikin for each green City card",
			redPawns: "Immediately gain a Minikin for each red City card",
			wild: "Counts as one City card of your chosen color for each effect",
			points: "Gain 2 VP at final scoring",
			bonusHeart: "Provides one additional heart",
			bonusSmile: "Provides one additional smile",
			bonusBag: "Provides one additional money bag",
			bonusBook: "Provides one additional book",
			bonusCockade: "Provides one additional Cockade at final scoring",
			alwaysFirst: "Always ranks first this round",
			rewardTitle: "Round rewards",
			rewardsScore: "Rewards & tokens",
			cityScore: "City cards",
			cockadeScore: "Cockades",
			total: "Total",
			unused: "Unused Minikins",
			winner: "Winner",
			resultTitle: "A tiny city. A grand achievement.",
			review: "View cities",
			showResult: "Show score sheet",
			confirmAgain: "Start a new game?",
			confirmBack: "Return to the lobby?",
			finalHand: "Revealed final hand",
			finalValue: "Final-color total: {{n}}",
			claim: "Take this token",
			chooseCard: "Choose this card",
			removeCard: "Deselect this card",
			scoreNow: "Current city score",
			rules: "Goal:\nBuild a city with City cards and Minikin pawns. After 8 rounds and a final contest, the most VP wins. Ties favor the player with more unused Minikins; a further tie is a shared victory.\n\nSetup:\nSelect the 9 Reward cards for your player count and shuffle their order. The ninth card determines the final color. Each player keeps 4 of 6 City cards; the others go to the bottom of the deck. Choose the first player randomly. The optional Music Festival cards are off by default.\n\nEach round:\n· Reveal one more City card than the number of players to form the open display.\n· Starting with the first player and continuing clockwise, each player adds a hand card to their city. Resolve its Instant effect, marked by lightning, immediately. Its top-right symbols become available at once.\n· Cards matching the round’s Reward color rank first, highest value first. Other colors follow in descending value. Equal values in other colors favor the earlier play. Colorless 21 always ranks first.\n· Receive the VP, Cockades, Minikins or Bonus tokens for your rank. Choose tokens from the common supply; each token can be taken only once.\n· In reverse ranking order, each player takes a card from the open display. Put the last card under the deck. The top-ranked player leads the next round, but plays still proceed clockwise.\n\nMinikin management:\nImmediately place gained Minikins on any empty spaces in your city, freely dividing them among cards. Placed Minikins cannot move. Keep excess pawns only when all available spaces are filled. When you later play a card with spaces, fill it as far as possible with these unused pawns. A card’s bottom scoring or Cockade effect works only when all its spaces are filled. The supply contains 75 Minikins; this implementation grants only the remaining pawns if it runs out.\n\nSymbols and conditions:\n· Books, hearts, smiles and money bags come from the top right of City cards and Bonus tokens, even on unfilled cards.\n· Meet every condition left of an arrow to gain its reward once.\n· Multiplication effects count the indicated items.\n· A color set contains one red, one green and one blue card. A symbol set contains one of each ordinary symbol.\n· The wild-color token can choose a color independently for each effect, but supplies only one card within a set.\n· Value ranges count matching cards in your city; 0 and 21 belong to none of the 1–20 ranges.\n\nEndgame:\nAfter drafting in round 8, reveal hands clockwise from that round’s winner. Add the values of hand cards matching the final color and rank the totals; earlier reveal wins ties. Resolve all final rewards and Minikin placement, then the winner plays one extra hand card, resolving its Instant effect and Minikin placement normally.\nAdd VP from Reward cards and Bonus tokens, effects on filled City cards, and Cockades. Having 1, 2, 3, 4, 5 or at least 6 Cockades scores 1, 3, 6, 10, 15 or 21 VP. Unfilled cards provide no bottom VP or Cockades.\nMusic Festival cards:\n· Red 0 immediately gains 6 Minikins.\n· Filled Green 0 scores 1 VP per book and per smile.\n· Filled Blue 0 scores 1 VP per money bag and per heart."
		}
	}
};
//#endregion
export { We as default };
