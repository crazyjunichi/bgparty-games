import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { IconExpand as s, IconInfo as c, IconMenu as l } from "@bgparty/sdk/icons";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { OptionRadio as p, OptionSection as m } from "@bgparty/sdk/ui/game-options";
//#region src/games/mooncolonybloodbath/data.ts
var h = [
	{
		id: 0,
		cost: 4,
		population: 8,
		trigger: "farm",
		symbol: "star",
		nameKey: "games.mooncolonybloodbath.b0",
		textKey: "games.mooncolonybloodbath.b0Text"
	},
	{
		id: 1,
		cost: 6,
		population: 10,
		trigger: null,
		symbol: "star",
		nameKey: "games.mooncolonybloodbath.b1",
		textKey: "games.mooncolonybloodbath.b1Text"
	},
	{
		id: 2,
		cost: 6,
		population: 5,
		trigger: "farm",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b2",
		textKey: "games.mooncolonybloodbath.b2Text"
	},
	{
		id: 3,
		cost: 1,
		population: 5,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b3",
		textKey: "games.mooncolonybloodbath.b3Text"
	},
	{
		id: 4,
		cost: 5,
		population: 6,
		trigger: "farm",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b4",
		textKey: "games.mooncolonybloodbath.b4Text"
	},
	{
		id: 5,
		cost: 5,
		population: 10,
		trigger: null,
		symbol: "rings",
		nameKey: "games.mooncolonybloodbath.b5",
		textKey: "games.mooncolonybloodbath.b5Text"
	},
	{
		id: 6,
		cost: 7,
		population: 10,
		trigger: null,
		symbol: "star",
		nameKey: "games.mooncolonybloodbath.b6",
		textKey: "games.mooncolonybloodbath.b6Text"
	},
	{
		id: 7,
		cost: 3,
		population: 8,
		trigger: "research",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b7",
		textKey: "games.mooncolonybloodbath.b7Text"
	},
	{
		id: 8,
		cost: 8,
		population: 3,
		trigger: "farm",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b8",
		textKey: "games.mooncolonybloodbath.b8Text"
	},
	{
		id: 9,
		cost: 3,
		population: 5,
		trigger: "mine",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b9",
		textKey: "games.mooncolonybloodbath.b9Text"
	},
	{
		id: 10,
		cost: 6,
		population: 9,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b10",
		textKey: "games.mooncolonybloodbath.b10Text"
	},
	{
		id: 11,
		cost: 3,
		population: 7,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b11",
		textKey: "games.mooncolonybloodbath.b11Text"
	},
	{
		id: 12,
		cost: 3,
		population: 5,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b12",
		textKey: "games.mooncolonybloodbath.b12Text"
	},
	{
		id: 13,
		cost: 7,
		population: 4,
		trigger: "research",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b13",
		textKey: "games.mooncolonybloodbath.b13Text"
	},
	{
		id: 14,
		cost: 7,
		population: 2,
		trigger: "mine",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b14",
		textKey: "games.mooncolonybloodbath.b14Text"
	},
	{
		id: 15,
		cost: 4,
		population: 8,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b15",
		textKey: "games.mooncolonybloodbath.b15Text"
	},
	{
		id: 16,
		cost: 1,
		population: 4,
		trigger: "restock",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b16",
		textKey: "games.mooncolonybloodbath.b16Text"
	},
	{
		id: 17,
		cost: 6,
		population: 6,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b17",
		textKey: "games.mooncolonybloodbath.b17Text"
	},
	{
		id: 18,
		cost: 4,
		population: 8,
		trigger: "restock",
		symbol: "star",
		nameKey: "games.mooncolonybloodbath.b18",
		textKey: "games.mooncolonybloodbath.b18Text"
	},
	{
		id: 19,
		cost: 7,
		population: 7,
		trigger: "mine",
		symbol: "rings",
		nameKey: "games.mooncolonybloodbath.b19",
		textKey: "games.mooncolonybloodbath.b19Text"
	},
	{
		id: 20,
		cost: 2,
		population: 6,
		trigger: "research",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b20",
		textKey: "games.mooncolonybloodbath.b20Text"
	},
	{
		id: 21,
		cost: 9,
		population: 14,
		trigger: null,
		symbol: "rings",
		nameKey: "games.mooncolonybloodbath.b21",
		textKey: "games.mooncolonybloodbath.b21Text"
	},
	{
		id: 22,
		cost: 4,
		population: 5,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b22",
		textKey: "games.mooncolonybloodbath.b22Text"
	},
	{
		id: 23,
		cost: 10,
		population: 9,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b23",
		textKey: "games.mooncolonybloodbath.b23Text"
	},
	{
		id: 24,
		cost: 6,
		population: 4,
		trigger: "research",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b24",
		textKey: "games.mooncolonybloodbath.b24Text"
	},
	{
		id: 25,
		cost: 5,
		population: 4,
		trigger: "research",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b25",
		textKey: "games.mooncolonybloodbath.b25Text"
	},
	{
		id: 26,
		cost: 12,
		population: 16,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b26",
		textKey: "games.mooncolonybloodbath.b26Text"
	},
	{
		id: 27,
		cost: 10,
		population: 12,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b27",
		textKey: "games.mooncolonybloodbath.b27Text"
	},
	{
		id: 28,
		cost: 15,
		population: 20,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b28",
		textKey: "games.mooncolonybloodbath.b28Text"
	},
	{
		id: 29,
		cost: 2,
		population: 6,
		trigger: "mine",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b29",
		textKey: "games.mooncolonybloodbath.b29Text"
	},
	{
		id: 30,
		cost: 0,
		population: 0,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b30",
		textKey: "games.mooncolonybloodbath.b30Text"
	},
	{
		id: 31,
		cost: 4,
		population: 3,
		trigger: "mine",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b31",
		textKey: "games.mooncolonybloodbath.b31Text"
	},
	{
		id: 32,
		cost: 3,
		population: 6,
		trigger: "restock",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b32",
		textKey: "games.mooncolonybloodbath.b32Text"
	},
	{
		id: 33,
		cost: 5,
		population: 5,
		trigger: "restock",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b33",
		textKey: "games.mooncolonybloodbath.b33Text"
	},
	{
		id: 34,
		cost: 4,
		population: 7,
		trigger: "research",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b34",
		textKey: "games.mooncolonybloodbath.b34Text"
	},
	{
		id: 35,
		cost: 4,
		population: 8,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b35",
		textKey: "games.mooncolonybloodbath.b35Text"
	},
	{
		id: 36,
		cost: 6,
		population: 5,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b36",
		textKey: "games.mooncolonybloodbath.b36Text"
	},
	{
		id: 37,
		cost: 5,
		population: 8,
		trigger: "mine",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b37",
		textKey: "games.mooncolonybloodbath.b37Text"
	},
	{
		id: 38,
		cost: 0,
		population: 4,
		trigger: "farm",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b38",
		textKey: "games.mooncolonybloodbath.b38Text"
	},
	{
		id: 39,
		cost: 2,
		population: 5,
		trigger: "farm",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b39",
		textKey: "games.mooncolonybloodbath.b39Text"
	},
	{
		id: 40,
		cost: 1,
		population: 5,
		trigger: "restock",
		symbol: "star",
		nameKey: "games.mooncolonybloodbath.b40",
		textKey: "games.mooncolonybloodbath.b40Text"
	},
	{
		id: 41,
		cost: 4,
		population: 3,
		trigger: "restock",
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b41",
		textKey: "games.mooncolonybloodbath.b41Text"
	},
	{
		id: 42,
		cost: 10,
		population: 7,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b42",
		textKey: "games.mooncolonybloodbath.b42Text"
	},
	{
		id: 43,
		cost: 1,
		population: 3,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b43",
		textKey: "games.mooncolonybloodbath.b43Text"
	},
	{
		id: 44,
		cost: 2,
		population: 4,
		trigger: null,
		symbol: null,
		nameKey: "games.mooncolonybloodbath.b44",
		textKey: "games.mooncolonybloodbath.b44Text"
	}
], g = (e) => Math.floor(e / 2), _ = (e) => h[g(e)], v = {
	development: [
		{
			nameKey: "games.mooncolonybloodbath.development0",
			textKey: "games.mooncolonybloodbath.development0Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development1",
			textKey: "games.mooncolonybloodbath.development1Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development2",
			textKey: "games.mooncolonybloodbath.development2Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development3",
			textKey: "games.mooncolonybloodbath.development3Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development4",
			textKey: "games.mooncolonybloodbath.development4Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development5",
			textKey: "games.mooncolonybloodbath.development5Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development6",
			textKey: "games.mooncolonybloodbath.development6Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development7",
			textKey: "games.mooncolonybloodbath.development7Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development8",
			textKey: "games.mooncolonybloodbath.development8Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.development9",
			textKey: "games.mooncolonybloodbath.development9Text"
		}
	],
	event: [
		{
			nameKey: "games.mooncolonybloodbath.event0",
			textKey: "games.mooncolonybloodbath.event0Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event1",
			textKey: "games.mooncolonybloodbath.event1Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event2",
			textKey: "games.mooncolonybloodbath.event2Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event3",
			textKey: "games.mooncolonybloodbath.event3Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event4",
			textKey: "games.mooncolonybloodbath.event4Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event5",
			textKey: "games.mooncolonybloodbath.event5Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event6",
			textKey: "games.mooncolonybloodbath.event6Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event7",
			textKey: "games.mooncolonybloodbath.event7Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event8",
			textKey: "games.mooncolonybloodbath.event8Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event9",
			textKey: "games.mooncolonybloodbath.event9Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event10",
			textKey: "games.mooncolonybloodbath.event10Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event11",
			textKey: "games.mooncolonybloodbath.event11Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.event12",
			textKey: "games.mooncolonybloodbath.event12Text"
		}
	],
	robot: [
		{
			nameKey: "games.mooncolonybloodbath.robot0",
			textKey: "games.mooncolonybloodbath.robot0Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot1",
			textKey: "games.mooncolonybloodbath.robot1Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot2",
			textKey: "games.mooncolonybloodbath.robot2Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot3",
			textKey: "games.mooncolonybloodbath.robot3Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot4",
			textKey: "games.mooncolonybloodbath.robot4Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot5",
			textKey: "games.mooncolonybloodbath.robot5Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot6",
			textKey: "games.mooncolonybloodbath.robot6Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot7",
			textKey: "games.mooncolonybloodbath.robot7Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot8",
			textKey: "games.mooncolonybloodbath.robot8Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot9",
			textKey: "games.mooncolonybloodbath.robot9Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot10",
			textKey: "games.mooncolonybloodbath.robot10Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot11",
			textKey: "games.mooncolonybloodbath.robot11Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot12",
			textKey: "games.mooncolonybloodbath.robot12Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot13",
			textKey: "games.mooncolonybloodbath.robot13Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot14",
			textKey: "games.mooncolonybloodbath.robot14Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot15",
			textKey: "games.mooncolonybloodbath.robot15Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot16",
			textKey: "games.mooncolonybloodbath.robot16Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot17",
			textKey: "games.mooncolonybloodbath.robot17Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot18",
			textKey: "games.mooncolonybloodbath.robot18Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.robot19",
			textKey: "games.mooncolonybloodbath.robot19Text"
		}
	],
	twist: [
		{
			nameKey: "games.mooncolonybloodbath.twist0",
			textKey: "games.mooncolonybloodbath.twist0Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist1",
			textKey: "games.mooncolonybloodbath.twist1Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist2",
			textKey: "games.mooncolonybloodbath.twist2Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist3",
			textKey: "games.mooncolonybloodbath.twist3Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist4",
			textKey: "games.mooncolonybloodbath.twist4Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist5",
			textKey: "games.mooncolonybloodbath.twist5Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist6",
			textKey: "games.mooncolonybloodbath.twist6Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist7",
			textKey: "games.mooncolonybloodbath.twist7Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist8",
			textKey: "games.mooncolonybloodbath.twist8Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist9",
			textKey: "games.mooncolonybloodbath.twist9Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist10",
			textKey: "games.mooncolonybloodbath.twist10Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist11",
			textKey: "games.mooncolonybloodbath.twist11Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist12",
			textKey: "games.mooncolonybloodbath.twist12Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist13",
			textKey: "games.mooncolonybloodbath.twist13Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist14",
			textKey: "games.mooncolonybloodbath.twist14Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist15",
			textKey: "games.mooncolonybloodbath.twist15Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist16",
			textKey: "games.mooncolonybloodbath.twist16Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist17",
			textKey: "games.mooncolonybloodbath.twist17Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist18",
			textKey: "games.mooncolonybloodbath.twist18Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist19",
			textKey: "games.mooncolonybloodbath.twist19Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist20",
			textKey: "games.mooncolonybloodbath.twist20Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist21",
			textKey: "games.mooncolonybloodbath.twist21Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist22",
			textKey: "games.mooncolonybloodbath.twist22Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist23",
			textKey: "games.mooncolonybloodbath.twist23Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.twist24",
			textKey: "games.mooncolonybloodbath.twist24Text"
		}
	],
	perk: [
		{
			nameKey: "games.mooncolonybloodbath.perk0",
			textKey: "games.mooncolonybloodbath.perk0Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.perk1",
			textKey: "games.mooncolonybloodbath.perk1Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.perk2",
			textKey: "games.mooncolonybloodbath.perk2Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.perk3",
			textKey: "games.mooncolonybloodbath.perk3Text"
		},
		{
			nameKey: "games.mooncolonybloodbath.perk4",
			textKey: "games.mooncolonybloodbath.perk4Text"
		}
	],
	work: [{
		nameKey: "games.mooncolonybloodbath.work0",
		textKey: "games.mooncolonybloodbath.work0Text"
	}],
	trouble: [{
		nameKey: "games.mooncolonybloodbath.trouble0",
		textKey: "games.mooncolonybloodbath.trouble0Text"
	}],
	loneliness: [{
		nameKey: "games.mooncolonybloodbath.loneliness0",
		textKey: "games.mooncolonybloodbath.loneliness0Text"
	}]
}, y = [
	0,
	1,
	5,
	7,
	8,
	12,
	14,
	15,
	18,
	19,
	20,
	21
], b = (e, t, n) => ({
	op: e,
	...t === void 0 ? {} : { n: t },
	...n ? { items: n } : {}
}), x = (e) => b("money", e), S = (e) => b("food", e), C = (e) => b("population", e), w = (e) => b("draw", e), T = (e) => b("box", e), E = (e, t) => b("discard", e, t), D = (e) => ({
	op: "action",
	action: e
}), O = (e, t = -1) => ({
	op: "add",
	mode: e,
	id: t
}), k = (e, t) => b("foodOffer", e, t), A = (e, t) => b("moneyOffer", e, t), j = (e, t) => ({
	op: "boxOffer",
	items: e,
	card: t
}), M = () => ({ op: "removeOffer" }), N = (e) => e.base + e.buildings.reduce((e, t) => e + _(t.card).population, 0), P = (e, t) => e.muted ? 0 : e.buildings.filter((e) => g(e.card) === t).length, F = (e, t) => P(e, t) > 0, I = (e) => e.buildings.reduce((e, t) => e + t.boxes, 0), L = [
	0,
	1,
	2,
	3,
	5,
	6,
	8,
	12,
	14,
	15,
	17,
	18,
	19,
	21,
	23,
	24,
	26,
	27,
	28,
	30,
	31,
	33,
	35,
	36,
	37,
	39,
	40,
	42,
	43
];
function R(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function z(e, t) {
	e.tasks.unshift(...t);
}
function B(e, t, n) {
	t.hand.splice(t.hand.indexOf(n), 1), e.buildingDiscard.push(n), t.money += P(t, 6);
}
function V(e, t) {
	let n = _(t).cost;
	return Math.max(0, n - P(e, 44) - 2 * P(e, 42) - (n >= 6 ? 3 * P(e, 17) : 0));
}
function H(e, t) {
	let n = [], r = F(e, 4) ? Math.min(t, e.food) : 0;
	for (let i = 0; i <= r; i++) e.money >= t - i && n.push({
		money: t - i,
		food: i
	});
	return n;
}
function U(e, t) {
	return (e.reserved.length ? e.reserved : e.hand).filter((e) => (t.mode !== "small" || _(e).cost <= 4) && (t.mode !== "large" || _(e).cost >= 5));
}
function W(e, t, n = !1) {
	return e.closed ? [] : U(e, t).flatMap((r) => H(e, V(e, r) + (t.n ?? 0)).map((e) => ({
		view: {
			id: `build:${r}:${e.food}`,
			text: "build",
			card: r,
			action: "build",
			...e,
			score: _(r).population + (_(r).trigger ? 6 : 2) - e.food * .6
		},
		tasks: [{
			op: n ? "seal" : "construct",
			card: r,
			food: e.food,
			n: e.money,
			action: "build"
		}]
	})));
}
function G(e, t, n, r = 1, i = {}) {
	return {
		view: {
			id: e,
			text: t,
			score: r,
			...i
		},
		tasks: n
	};
}
var K = () => G("skip", "skip", [], 0), q = (e) => ({
	op: "build",
	mode: e
}), te = (e, t) => e.buildings.filter((e) => e.boxes > 0 && (t === void 0 || e.card === t));
function ne(e, t) {
	let n = e.colonies[t], r = n.tasks[0];
	if (!r) return [];
	let i = r.n ?? 1, a = r.items ?? [];
	switch (r.op) {
		case "begin": return [G("continue", "continue", a)];
		case "window": return a.map((e, t) => G(`window:${t}`, e.op === "base" ? "baseEffect" : e.op === "play" ? "play" : "ability", [{
			...e,
			source: e.card ?? e.source
		}, {
			...r,
			items: a.filter((e, n) => n !== t)
		}], e.op === "base" ? 4 : 5, {
			card: e.card,
			action: e.action
		}));
		case "choosework": return [...[
			"mine",
			"farm",
			"research",
			"restock"
		].map((e) => G(e, e, [{
			op: "seal",
			action: e
		}], e === "farm" ? Math.max(2, n.buildings.length * 2 - n.food) : e === "mine" ? Math.max(2, 10 - n.money) : e === "research" ? Math.max(1, 5 - n.hand.length) : I(n) < n.buildings.length ? 4 : 0, { action: e })), ...n.closed ? [] : W(n, r, !0)];
		case "build": return [...W(n, r), K()];
		case "loss": return n.base < i ? n.buildings.map((e) => G(`lose:${e.card}`, "loseBuilding", [{
			op: "remove",
			card: e.card
		}, b("loss", i)], -_(e.card).population - e.boxes * 3 - (_(e.card).trigger ? 4 : 0), { card: e.card })) : [];
		case "removeOffer": return [...n.buildings.map((e) => G(`remove:${e.card}`, "loseBuilding", [{
			op: "remove",
			card: e.card,
			mode: r.mode
		}], -_(e.card).population + (r.mode === "return" ? 8 : 2), { card: e.card })), G("decline", "skip", r.mode === "return" ? [] : [b("loss", 3)], -4)];
		case "discard": return n.hand.filter((e) => !r.cards?.includes(e)).map((e) => {
			let t = [...r.cards ?? [], e], o = t.length >= Math.min(i, n.hand.length);
			return G(`discard:${e}`, "discard", o ? [{
				op: "discardBatch",
				cards: t
			}, ...a] : [{
				...r,
				cards: t
			}], -_(e).population - (_(e).trigger ? 6 : 0), { card: e });
		});
		case "handOffer": return [...n.hand.length >= i ? [G("use", "discardFor", [E(i, a)], 3, { n: i })] : [], K()];
		case "foodOffer": return [...n.food >= i ? [G("use", "payFood", [S(-i), ...a], 3, { n: i })] : [], K()];
		case "moneyOffer": return [...H(n, i).map((e) => G(`pay:${e.food}`, "payment", [
			x(-e.money),
			S(-e.food),
			...a
		], 3, e)), K()];
		case "boxOffer": return [...te(n, r.card).map((e) => G(`spend:${e.card}`, "spendBox", [{
			op: "takeBox",
			card: e.card
		}, ...a], 4, { card: e.card })), G("decline", "skip", r.mode === "efficiency" ? [x(-2)] : [], r.mode === "efficiency" ? -2 : 0)];
		case "spendBox": return te(n).map((e) => G(`spend:${e.card}`, "spendBox", [{
			op: "takeBox",
			card: e.card
		}, ...i > 1 ? [b("spendBox", i - 1, a)] : a], -e.boxes, { card: e.card }));
		case "box": return n.buildings.filter((e) => r.mode !== "empty" || e.boxes === 0).map((e) => G(`box:${e.card}`, "box", [{
			op: "putBox",
			card: e.card
		}, ...i > 1 ? [b("box", i - 1)] : []], [
			2,
			3,
			12,
			29,
			32,
			37,
			40
		].includes(g(e.card)) ? 5 : 1, { card: e.card }));
		case "perk": return n.perks.map((e) => G(`perk:${e}`, `perk${e}`, [{
			op: "perkAdd",
			id: e
		}], [
			3,
			2,
			2,
			3,
			4
		][e]));
		case "move": {
			let e = [];
			for (let t of n.buildings) for (let i of n.buildings) t.boxes && t.card !== i.card && (r.mode !== "more" || i.boxes > t.boxes) && e.push(G(`move:${t.card}:${i.card}`, "moveBox", [{
				op: "takeBox",
				card: t.card
			}, {
				op: "putBox",
				card: i.card
			}], i.boxes - t.boxes, {
				card: t.card,
				target: i.card
			}));
			return r.mode === "more" && e.length ? e : [...e, K()];
		}
		case "pass": return n.hand.length ? n.hand.map((e) => G(`pass:${e}`, "pass", [{
			op: "passCard",
			card: e
		}], -_(e).population, { card: e })) : [];
		case "reserve": return n.hand.map((e) => G(`reserve:${e}`, "reserve", [{
			op: "reserveCard",
			card: e
		}], _(e).population - _(e).cost, { card: e }));
		case "survey": return [
			...n.hand.map((e) => G(`bury:${e}`, "survey", [{
				op: "buryCard",
				card: e
			}], 4 - _(e).population / 3, { card: e })),
			...n.surveyed.length ? [G("sell", "sell", [b("sell")], n.surveyed.length * 8, { n: n.surveyed.length })] : [],
			K()
		];
		case "focus": return [...n.muted ? [] : n.buildings.filter((e) => _(e.card).trigger).map((e) => G(`focus:${e.card}`, "ability", [{
			op: "ability",
			card: e.card
		}], 4, { card: e.card })), K()];
		case "repeat": return [...n.muted ? [] : n.buildings.filter((e) => L.includes(g(e.card))).map((e) => G(`play:${e.card}`, "play", [{
			op: "play",
			card: e.card,
			id: g(e.card)
		}], 4, { card: e.card })), K()];
		case "accident": return [...n.buildings.filter((e) => g(e.card) === 3 && e.boxes).map((e) => G(`ignore:${e.card}`, "spendBox", [{
			op: "takeBox",
			card: e.card
		}], 5, { card: e.card })), G("continue", "continue", [b("loss", 3)], -3)];
		case "stack": return [...I(n) && i > 0 ? [G("spend", "spend", [b("spendBox", 1, [b("stack", i - 2)])], 3, { n: 1 })] : [], G("finish", "finish", i > 0 ? [b("loss", i)] : [], -i)];
		case "crater": return [...I(n) ? [G("spend", "spend", [b("spendBox", 1, [x(2), b("crater")])], n.money < 10 ? 3 : -1, { n: 1 })] : [], G("finish", "finish", [], 0)];
		case "synthetic": return [G("finish", "finish", [], 0), ...Array.from({ length: n.money + (F(n, 4) ? n.food : 0) }, (e, t) => t + 1).flatMap((e) => H(n, e).map((t) => G(`meat:${e}:${t.food}`, "payment", [
			x(-t.money),
			S(-t.food),
			S(e)
		], Math.min(e, Math.max(0, n.buildings.length * 2 - n.food)) - e * .2, {
			...t,
			n: e
		})))];
		case "defund": return ["money", "food"].filter((e) => n.money === n.food || (n.money > n.food ? e === "money" : e === "food")).map((e) => G(e, e, [b(e, -Math.floor((e === "money" ? n.money : n.food) / 2))], e === "food" ? -2 : -1));
		case "anyAction": return (r.mode === "generator" ? [
			"mine",
			"farm",
			"research"
		] : [
			"mine",
			"farm",
			"research",
			"restock",
			"build"
		]).map((e) => G(e, e, [D(e)], e === "farm" && n.food < n.buildings.length ? 8 : e === "build" ? 5 : 3, { action: e }));
		case "market": return [
			...n.food >= 2 ? [G("food", "food", [S(-2), x(4)], 3)] : [],
			...n.hand.length ? [G("discard", "discard", [E(1, [x(4)])], 2)] : [],
			K()
		];
		case "tunnels": return [
			G("food", "food", [S(2)], n.food < n.buildings.length * 2 ? 5 : 2),
			G("money", "money", [x(2)], n.money < 6 ? 4 : 2),
			G("boxes", "boxes", [T(1)], 2)
		];
		case "spaceport": return [...H(n, 3).flatMap((e) => [...n.perks.length ? [G(`perk:${e.food}`, "perk", [
			x(-e.money),
			S(-e.food),
			b("perk")
		], 3, e)] : [], G(`pop:${e.food}`, "population", [
			x(-e.money),
			S(-e.food),
			C(3)
		], N(n) < 12 ? 5 : 2, e)]), K()];
		case "flexible": return [
			G("draw", "research", [w(1)], n.hand.length < 3 ? 5 : 1),
			G("money", "money", [x(2)], n.money < 5 ? 4 : 2),
			G("box", "boxes", [T(1)], I(n) < n.buildings.length ? 3 : 0),
			G("food", "food", [S(2)], n.food < n.buildings.length * 2 ? 5 : 1)
		];
		default: return [];
	}
}
function re(e, t) {
	if (e.muted || !e.buildings.some((e) => e.card === t)) return [];
	let n = e.buildings.find((e) => e.card === t);
	switch (g(t)) {
		case 0: return [b("market")];
		case 2: return [j([C(4)], t)];
		case 4: return [S(2)];
		case 7: return [k(3, [b("perk")])];
		case 8: return [k(1, [x(4)])];
		case 9: return [x(2)];
		case 13: return [w(2)];
		case 14: return [
			x(4),
			w(1),
			E(1)
		];
		case 16: return [b("tunnels")];
		case 18: return [x(2), b("move")];
		case 19: return [x(e.money === 0 ? 5 : 2)];
		case 20: return e.money >= 10 ? [C(2)] : [];
		case 24:
		case 34: return [w(1)];
		case 25: return [C(2)];
		case 29: return [{
			op: "putBox",
			card: t
		}];
		case 31:
		case 33:
		case 41: return [T(1)];
		case 32: return [j([
			x(4),
			w(1),
			E(1)
		], t)];
		case 37: return [x(n.boxes)];
		case 38: return [C(1)];
		case 39: return [S(1)];
		case 40: return [j([S(4)], t)];
		default: return [];
	}
}
function ie(e, t, n) {
	if (e.muted) return [];
	switch (t) {
		case 0: return [O("development", 8)];
		case 1: return [O("development", 7)];
		case 2:
		case 3:
		case 8:
		case 31:
		case 36: return [b("perk")];
		case 5: return [O("development", 6)];
		case 6: return [O("development", 1)];
		case 12: return [{
			op: "putBox",
			n: 3,
			card: n
		}];
		case 14: return [O("development", 2)];
		case 15: return [w(2), E(2)];
		case 18: return [O("development", 3)];
		case 19: return [O("development", 0)];
		case 21: return [O("robot")];
		case 23: return [q()];
		case 24: return [
			S(2),
			T(1),
			w(1)
		];
		case 26: return [C(Math.floor(e.buildings.length / 2))];
		case 27: return [b("crater")];
		case 28: return [O("event")];
		case 30: return [x(6)];
		case 33: return [{
			op: "anyAction",
			mode: "generator"
		}];
		case 35: return [T(1)];
		case 37: return [O("development", 4)];
		case 39: return [D("farm")];
		case 40: return [O("development", 9)];
		case 41: return [b("repeat")];
		case 42: return [w(2)];
		case 43: return [T(2)];
		default: return [];
	}
}
function ae(e, t, n) {
	if (e.muted) return [];
	switch (t) {
		case 9: return [x(4)];
		case 17: return [O("development", 5)];
		case 20: return [b("perk")];
		case 22: return [T(2)];
		case 23: return [D("mine")];
		case 27: return [S(4)];
		case 29: return [x(n * 3)];
		case 43: return [w(2)];
		case 44: return [q()];
		default: return [];
	}
}
function oe(e, t, n) {
	let r = e.colonies[t];
	if (n.kind === "work") return [b("choosework")];
	if (n.kind === "loneliness") return [C(r.buildings.filter((e) => _(e.card).symbol === "rings").length * 3), b("loss", r.buildings.filter((e) => _(e.card).symbol === "star").length * 3)];
	if (n.kind === "perk") return n.owner === t ? [
		[S(2)],
		[T(1)],
		[w(1)],
		[x(2)],
		[C(2)]
	][n.id] : [];
	if (n.kind === "event") return n.id === 0 ? [b("hunger")] : n.id === 1 ? F(r, 36) ? [] : [w(1), E(2)] : n.id >= 3 && n.id <= 11 ? n.id >= 5 && n.id <= 7 && F(r, 3) ? [b("accident")] : [b("loss", [
		0,
		0,
		0,
		4,
		2,
		3,
		3,
		3,
		4,
		5,
		6,
		7
	][n.id])] : [];
	if (n.kind === "development") switch (n.id) {
		case 0: return [x(-2)];
		case 1: return [b("handOffer", 1, [S(4)])];
		case 2: return [b("handOffer", 2, [q()])];
		case 3: return [A(2, [T(2)])];
		case 4: return [w(1), E(1)];
		case 5: return [M()];
		case 6: return [b("spendBox", 1)];
		case 7: return [k(2, [C(3)])];
		case 8: return [j([w(2)])];
		case 9: return [k(2, [x(4)])];
	}
	if (n.kind === "twist") switch (n.id) {
		case 0: return [A(2, [D("restock")])];
		case 1: return [b("populationOffer", 2, [D("research")])];
		case 2: return [b("survey")];
		case 3: return [x(2), b("synthetic")];
		case 4: return [x(r.buildings.filter((e) => e.boxes > 0).length)];
		case 5: return [b("university")];
		case 6: return [b("animalResearch")];
		case 7: return [j([x(5)])];
		case 8: return [A(5, [w(4)])];
		case 9: return [j([q("small")])];
		case 10: return [b("defund")];
		case 11: return [b("diversify")];
		case 12: return r.money < 5 ? [x(3)] : [];
		case 13: return [{
			op: "removeOffer",
			mode: "return"
		}];
		case 14: return [A(3, [b("perk")])];
		case 15: return [b("flexible")];
		case 16: return [b("focus")];
		case 17: return [b("handOffer", 1, [q("large")])];
		case 18: return [j([D("farm")])];
		case 19: return [x(Math.floor(r.money / 4))];
		case 20: return r.buildings.length <= 4 ? [w(1), S(2)] : [];
		case 21: return [k(2, [D("mine")])];
		case 22: return [b("recruits")];
		case 23: return [{
			op: "build",
			n: r.buildings.length
		}];
		case 24: return [b("realityShow")];
	}
	if (n.kind === "robot") {
		let t = [
			5,
			4,
			6,
			7,
			5,
			5,
			5,
			5,
			7,
			4,
			7,
			6,
			4,
			5,
			5,
			4,
			Math.max(...e.players.map((t) => e.colonies[t].buildings.length)),
			8,
			6,
			7
		][n.id], r = [
			[],
			[b("spendBox", 1)],
			[{
				op: "move",
				mode: "more"
			}],
			[j([b("anyAction")])],
			[b("reserve")],
			[b("pass")],
			[M()],
			[{
				...j([]),
				mode: "efficiency"
			}],
			[w(1)],
			[b("kitchenRobot")],
			[x(2)],
			[b("miningRobot")],
			[],
			[b("researchRobot")],
			[j([S(2)])],
			[S(-2)],
			[],
			[],
			[],
			[{
				op: "box",
				n: 1,
				mode: "empty"
			}]
		];
		return n.id === 18 ? [b("stack", 6)] : [b("loss", t), ...r[n.id]];
	}
	return [];
}
function se(e, t) {
	let n = e.colonies[t], r = n.tasks.shift(), i = n.tasks.length;
	n.revision++;
	let a = r.n ?? 1, o = r.items ?? [];
	switch (r.op) {
		case "money":
			n.money = Math.max(0, n.money + a);
			break;
		case "food":
			n.food = Math.max(0, n.food + a), a > 0 && (n.base += P(n, 1));
			break;
		case "population":
			n.base += a;
			break;
		case "draw":
			for (let t = 0; t < a; t++) {
				e.buildings.length || (e.buildings = R(e, e.buildingDiscard), e.buildingDiscard = []);
				let t = e.buildings.pop();
				if (t === void 0) break;
				n.hand.push(t);
			}
			break;
		case "putBox": {
			let e = n.buildings.find((e) => e.card === r.card);
			e && (e.boxes += a);
			break;
		}
		case "takeBox": {
			let e = n.buildings.find((e) => e.card === r.card);
			e?.boxes && e.boxes--;
			break;
		}
		case "discardOne":
			r.card !== void 0 && n.hand.includes(r.card) && B(e, n, r.card);
			break;
		case "discardBatch":
			for (let t of r.cards ?? []) B(e, n, t);
			break;
		case "discard":
			z(n, o);
			break;
		case "seal":
			n.sealed = r, z(n, [b("workWait")]);
			break;
		case "reserveCard":
			r.card !== void 0 && (n.hand.splice(n.hand.indexOf(r.card), 1), n.reserved.push(r.card));
			break;
		case "buryCard":
			r.card !== void 0 && (n.hand.splice(n.hand.indexOf(r.card), 1), n.surveyed.push(r.card));
			break;
		case "sell":
			n.money += n.surveyed.length * 8, e.buildingDiscard.push(...n.surveyed), n.surveyed = [];
			break;
		case "passCard":
			n.passed = r.card ?? -1, z(n, [b("deliveryWait")]);
			break;
		case "pass":
			n.passed = -1, z(n, [b("deliveryWait")]);
			break;
		case "action": {
			if (r.action === "build") {
				z(n, [r.card === void 0 ? q() : {
					...r,
					op: "construct"
				}]);
				break;
			}
			let e = [{
				op: "base",
				action: r.action
			}];
			if (!n.muted) for (let t of n.buildings) _(t.card).trigger === r.action && e.push({
				op: "ability",
				card: t.card,
				action: r.action
			});
			z(n, [{
				op: "window",
				items: e
			}]);
			break;
		}
		case "base":
			z(n, r.action === "mine" ? [x(4)] : r.action === "farm" ? [S(4)] : r.action === "research" ? [w(2)] : [T(2)]);
			break;
		case "ability":
			r.card !== void 0 && z(n, re(n, r.card).map((e) => ({
				...e,
				source: r.card
			})));
			break;
		case "play":
			z(n, ie(n, r.id, r.card).map((e) => ({
				...e,
				source: r.card
			})));
			break;
		case "solar": {
			let e = n.buildings.find((e) => e.card === r.card);
			e && !n.muted && (n.base += Math.floor(e.boxes / 2));
			break;
		}
		case "cargo":
			!n.muted && n.buildings.some((e) => e.card === r.card) && z(n, [{
				op: "putBox",
				card: r.target
			}]);
			break;
		case "construct": {
			let e = r.card, t = n.reserved.includes(e) ? n.reserved : n.hand;
			t.splice(t.indexOf(e), 1), n.money -= a, n.food -= r.food ?? 0;
			let i = [...n.buildings];
			if (n.buildings.push({
				card: e,
				boxes: 0
			}), !n.muted) {
				let t = [{
					op: "play",
					id: g(e),
					card: e
				}];
				for (let n of i) g(n.card) === 10 && t.push({
					op: "solar",
					card: n.card
				}), g(n.card) === 11 && t.push({
					op: "spaceport",
					card: n.card
				}), g(n.card) === 22 && t.push({
					op: "cargo",
					card: n.card,
					target: e
				});
				z(n, [{
					op: "window",
					items: t
				}]);
			}
			break;
		}
		case "remove": {
			let t = n.buildings.findIndex((e) => e.card === r.card);
			if (t < 0) break;
			let [i] = n.buildings.splice(t, 1), a = g(i.card);
			n.base += _(i.card).population, r.mode === "return" || a === 34 && !n.muted ? n.hand.push(i.card) : e.buildingDiscard.push(i.card), n.money += P(n, 38), z(n, ae(n, a, i.boxes).map((e) => ({
				...e,
				source: i.card
			})));
			break;
		}
		case "loss": {
			let t = Math.min(n.base, a);
			n.base -= t, N(n) === 0 && a > 0 && (n.dead = !0), t < a && n.buildings.length && z(n, [b("loss", a - t)]), n.dead && (n.tasks = [], e.deliveryBarrier && (n.passed = -1, n.tasks = [b("deliveryWait")]));
			break;
		}
		case "perkAdd":
			n.perks.splice(n.perks.indexOf(r.id), 1), J(e, t, {
				kind: "perk",
				id: r.id,
				owner: t
			});
			break;
		case "add":
			J(e, t, {
				kind: r.mode,
				id: r.id ?? -1
			});
			break;
		case "hunger": {
			let e = n.buildings.filter((e) => g(e.card) !== 30 && !(F(n, 35) && e.boxes > 0)).length, t = Math.max(0, e - n.food);
			n.food = Math.max(0, n.food - e), z(n, t ? [b("loss", t)] : [C(2 + 3 * P(n, 25))]);
			break;
		}
		case "diversify": {
			let e = n.muted ? [] : n.buildings.map((e) => _(e.card).trigger);
			z(n, [
				...e.includes("research") ? [w(1)] : [],
				...e.includes("restock") ? [T(1)] : [],
				...e.includes("farm") ? [S(2)] : [],
				...e.includes("mine") ? [] : [x(-2)]
			]);
			break;
		}
		case "kitchenRobot":
			n.food < 8 && z(n, [b("loss", 3)]);
			break;
		case "miningRobot":
			z(n, [x(n.buildings.filter((e) => _(e.card).trigger === "mine").length)]);
			break;
		case "researchRobot":
			n.hand.length >= 5 && z(n, [E(1)]);
			break;
		case "university":
			z(n, [x(Math.floor(n.hand.length / 3))]);
			break;
		case "animalResearch":
			z(n, [x(-n.hand.length), w(2)]);
			break;
		case "recruits":
			n.hand.length > n.buildings.length && z(n, [C(3)]);
			break;
		case "realityShow": (I(n) >= 6 || n.hand.length >= 6 || n.buildings.length >= 6) && z(n, [x(3)]);
	}
	if (r.source !== void 0) for (let e = 0; e < n.tasks.length - i; e++) n.tasks[e].source ??= r.source;
}
function J(e, t, n) {
	let r = n;
	if (n.kind === "event") {
		if (e.events >= 12 && e.players.length === 1 && e.config.extendedSolo) {
			let t = e.robots.pop();
			if (t === void 0) return;
			r = {
				kind: "robot",
				id: t
			}, e.extraRobots++;
		} else {
			if (e.events >= 13) return;
			r = {
				kind: "event",
				id: e.events++
			};
		}
	} else if (n.kind === "robot" || n.kind === "twist") {
		let t = (n.kind === "robot" ? e.robots : e.twists).pop();
		if (t === void 0) return;
		r = {
			kind: n.kind,
			id: t
		};
	} else if (n.kind === "development") {
		if (!e.developments[n.id]) return;
		e.developments[n.id]--;
	}
	e.additions.push({
		card: r,
		source: t,
		order: e.additions.filter((e) => e.source === t).length
	}), e.colonies[t] && (e.colonies[t].money += 2 * P(e.colonies[t], 15));
}
function ce(e) {
	return e.muted || e.sealed || e.passed !== null || !e.tasks.length ? [] : e.buildings.filter((e) => g(e.card) === 12 && e.boxes > 0).map((e) => e.card);
}
function le(e, t) {
	let n = e.colonies[t].tasks[0];
	if (!n || n.op === "workWait" || n.op === "deliveryWait") return !1;
	let r = e.colonies[t];
	return n.op === "loss" && r.base >= (n.n ?? 1) || ue(e, t).length === 0;
}
function ue(e, t) {
	let n = e.colonies[t], r = n.tasks[0];
	return r?.op === "populationOffer" ? [...N(n) >= (r.n ?? 1) ? [G("use", "payPopulation", [b("loss", r.n), ...r.items ?? []], 2, { n: r.n })] : [], K()] : ne(e, t);
}
var de = (e) => e ? {
	begin: "continue",
	build: "buildChoice",
	moneyOffer: "optional",
	foodOffer: "optional",
	handOffer: "optional",
	boxOffer: "spendBox",
	removeOffer: "remove",
	populationOffer: "optional",
	spaceport: "optional",
	market: "optional",
	tunnels: "choose",
	flexible: "choose"
}[e.op] ?? e.op : null, fe = {
	id: "mooncolonybloodbath",
	tier: "alpha",
	mechanics: ["engine-building", "deck-bag-building"],
	interactionTags: [],
	nameKey: "games.mooncolonybloodbath.name",
	descKey: "games.mooncolonybloodbath.desc",
	rulesKey: "games.mooncolonybloodbath.rules",
	icon: "🌘",
	iconImg: "games/mooncolonybloodbath.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [4],
	rulesUrl: { en: "https://officialgamerules.org/wp-content/uploads/2026/02/Moon_Colony_Bloodbath_Rulebook.pdf" },
	accent: "#6268a8",
	releasedAt: "2026-10-26T23:07:22+08:00",
	search: {
		py: "yueqiuzhiminyuxueqiusheng",
		init: "yqzmyxqs"
	},
	hotseat: "cover",
	botDelayMs: 650
}, Y = t.object({
	beginner: t.boolean().default(!0),
	extendedSolo: t.boolean().default(!1)
}).default({
	beginner: !0,
	extendedSolo: !1
}), pe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		revision: t.int().nonnegative(),
		choice: t.string().max(80)
	}),
	t.object({
		type: t.literal("storage"),
		revision: t.int().nonnegative(),
		card: t.int().min(0).max(89)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), me = t.object({
	kind: t.enum([
		"work",
		"trouble",
		"loneliness",
		"event",
		"robot",
		"twist",
		"development",
		"perk"
	]),
	id: t.int(),
	owner: t.string().optional()
}), he = t.object({
	card: t.int(),
	boxes: t.int().nonnegative()
}), ge = t.object({
	id: t.string(),
	text: t.string(),
	n: t.number().optional(),
	card: t.number().optional(),
	target: t.number().optional(),
	action: t.enum([
		"mine",
		"farm",
		"research",
		"restock",
		"build"
	]).optional(),
	food: t.number().optional(),
	money: t.number().optional(),
	score: t.number()
}), _e = t.object({
	players: t.array(t.object({
		rid: t.string(),
		base: t.int(),
		population: t.int(),
		money: t.int(),
		food: t.int(),
		buildings: t.array(he),
		handCount: t.int(),
		reservedCount: t.int(),
		surveyedCount: t.int(),
		perks: t.array(t.int()),
		ready: t.boolean(),
		work: t.array(t.string()),
		muted: t.boolean(),
		dead: t.boolean()
	})),
	phase: t.enum([
		"progress",
		"resolve",
		"done"
	]),
	current: me.nullable(),
	initialTwists: t.array(t.int()),
	revealed: t.array(t.object({
		rid: t.string(),
		card: t.int()
	})),
	deckCount: t.int(),
	discardCount: t.int(),
	buildingDeckCount: t.int(),
	buildingDiscardCount: t.int(),
	buildingDiscardTop: t.int().nullable(),
	events: t.int(),
	extraRobots: t.int(),
	cycle: t.int(),
	turn: t.int(),
	doors: t.boolean(),
	repairs: t.boolean(),
	robotCount: t.int(),
	twistCount: t.int(),
	developments: t.array(t.int()),
	extendedSolo: t.boolean(),
	ended: t.enum(["population", "manual"]).nullable()
}), ve = t.object({
	hand: t.array(t.int()),
	reserved: t.array(t.int()),
	surveyed: t.array(t.int()),
	revision: t.int(),
	prompt: t.string().nullable(),
	sourceCard: t.int().nullable(),
	choices: t.array(ge),
	storage: t.array(t.int()),
	selected: t.int().nullable(),
	marked: t.array(t.int()),
	amount: t.number().nullable()
});
function ye(e, t, n) {
	let r = {}, i = {
		players: [...t],
		colonies: r,
		seed: n,
		cursor: 0,
		config: Y.parse(e),
		deck: [],
		discard: [],
		buildings: [],
		buildingDiscard: [],
		robots: [],
		twists: [],
		developments: Array(10).fill(2),
		additions: [],
		initialTwists: [],
		current: null,
		revealed: [],
		events: 0,
		extraRobots: 0,
		cycle: 1,
		turn: 0,
		phase: "progress",
		ended: null,
		doors: !1,
		repairs: !1,
		workBarrier: !1,
		deliveryBarrier: !1,
		log: []
	};
	i.buildings = R(i, Array.from({ length: 90 }, (e, t) => t)), i.robots = R(i, Array.from({ length: 20 }, (e, t) => t)), i.twists = R(i, Array.from({ length: 25 }, (e, t) => t)), i.initialTwists = (e.beginner ? R(i, [...y]) : [...i.twists]).slice(-2), i.twists = i.twists.filter((e) => !i.initialTwists.includes(e));
	let a = [
		...Array.from({ length: 4 }, (e, t) => ({
			kind: "work",
			id: t
		})),
		{
			kind: "trouble",
			id: 0
		},
		{
			kind: "trouble",
			id: 1
		},
		...i.initialTwists.map((e) => ({
			kind: "twist",
			id: e
		}))
	];
	t.length === 1 && a.push({
		kind: "loneliness",
		id: 0
	}), i.deck = R(i, a);
	for (let e of t) r[e] = {
		base: 30,
		money: 4,
		food: 4,
		buildings: [],
		hand: i.buildings.splice(-4),
		reserved: [],
		surveyed: [],
		perks: [
			0,
			1,
			2,
			3,
			4
		],
		tasks: [],
		revision: 0,
		sealed: null,
		passed: null,
		work: [],
		muted: !1,
		closed: !1,
		dead: !1
	};
	return { state: i };
}
function be(e) {
	if (!e.deck.length) {
		e.deck = R(e, e.discard), e.discard = [], e.cycle++, e.doors = !1, e.repairs = !1;
		for (let t of Object.values(e.colonies)) t.work = [];
	}
	let t = e.deck.pop();
	if (t) {
		if (e.current = t, e.revealed = [], e.discard.push(t), e.turn++, e.phase = "resolve", e.log.push({
			turn: e.turn,
			card: t
		}), t.kind === "event" && t.id === 12) {
			e.phase = "done", e.ended = "manual";
			return;
		}
		t.kind === "trouble" && J(e, "$table", {
			kind: "event",
			id: -1
		}), t.kind === "event" && t.id === 2 && J(e, "$table", {
			kind: "robot",
			id: -1
		}), t.kind === "robot" && t.id === 0 && (e.doors = !0), t.kind === "robot" && t.id === 12 && (e.repairs = !0), e.workBarrier = t.kind === "work", e.deliveryBarrier = t.kind === "robot" && t.id === 5;
		for (let n of e.players) {
			let r = e.colonies[n];
			r.sealed = null, r.passed = null, r.revision++, r.muted = t.kind === "work" && e.doors, r.closed = t.kind === "work" && e.repairs;
			let i = oe(e, n, t);
			if (r.tasks = i.length ? [{
				op: "begin",
				items: i
			}] : [], t.kind === "work" && !r.muted && r.hand.length === 0) {
				let e = r.buildings.filter((e) => Math.floor(e.card / 2) === 5).length;
				e && r.tasks.unshift(b("draw", e));
			}
		}
		t.kind === "work" && (e.doors = !1, e.repairs = !1);
	}
}
function xe(e) {
	e.current?.kind === "robot" && e.current.id === 17 && J(e, "$table", {
		kind: "twist",
		id: -1
	});
	let t = [...e.additions].sort((t, n) => e.players.indexOf(t.source) - e.players.indexOf(n.source) || t.order - n.order);
	e.deck.push(...R(e, t.map((e) => e.card))), e.additions = [];
	for (let t of Object.values(e.colonies)) t.muted = !1, t.closed = !1;
	e.players.some((t) => e.colonies[t].dead) ? (e.phase = "done", e.ended = "population") : e.phase = "progress";
}
function Se(e) {
	return e.workBarrier && e.players.every((t) => e.colonies[t].sealed !== null && e.colonies[t].tasks[0]?.op === "workWait") ? !0 : e.deliveryBarrier && e.players.every((t) => e.colonies[t].tasks[0]?.op === "deliveryWait");
}
function Ce(e) {
	if (e.workBarrier) {
		e.revealed = e.players.flatMap((t) => {
			let n = e.colonies[t].sealed?.card;
			return n === void 0 ? [] : [{
				rid: t,
				card: n
			}];
		});
		for (let t of e.players) {
			let n = e.colonies[t], r = n.sealed;
			n.work.push(r.action), n.tasks = [{
				...r,
				op: "action"
			}], n.sealed = null, n.revision++;
		}
		e.workBarrier = !1;
	} else {
		let t = e.players.map((t) => e.colonies[t].passed);
		e.players.forEach((n, r) => {
			let i = e.colonies[n], a = t[r];
			a !== null && a >= 0 && i.hand.splice(i.hand.indexOf(a), 1);
		}), e.players.forEach((n, r) => {
			let i = e.colonies[n], a = t[(r + e.players.length - 1) % e.players.length];
			a !== null && a >= 0 && i.hand.push(a), i.tasks = i.tasks.slice(1), i.passed = null, i.revision++;
		}), e.deliveryBarrier = !1;
	}
}
function we(e) {
	for (let t of e.players) {
		let n = e.colonies[t].tasks[0];
		if (n && n.op !== "workWait" && n.op !== "deliveryWait") return le(e, t) ? t : null;
	}
	return null;
}
function Te(e, t, { by: n }) {
	if (t.type === "tick") {
		if (n !== "$engine") return { code: "games.mooncolonybloodbath.errTick" };
		if (e.phase === "done") return { state: e };
		let t = structuredClone(e);
		if (t.phase === "progress") be(t);
		else if (Se(t)) Ce(t);
		else if (t.players.every((e) => !t.colonies[e].tasks.length)) xe(t);
		else {
			let n = we(t);
			if (n) se(t, n);
			else return { state: e };
		}
		return { state: t };
	}
	let r = e.colonies[n];
	if (e.phase !== "resolve" || !r || t.revision !== r.revision) return { code: "games.mooncolonybloodbath.errAction" };
	if (t.type === "storage") {
		if (!ce(r).includes(t.card)) return { code: "games.mooncolonybloodbath.errAction" };
		let i = structuredClone(e), a = i.colonies[n];
		return a.buildings.find((e) => e.card === t.card).boxes--, a.tasks.unshift({
			op: "draw",
			n: 1,
			source: t.card
		}), a.revision++, { state: i };
	}
	if (le(e, n)) return { code: "games.mooncolonybloodbath.errAction" };
	let i = ue(e, n).find((e) => e.view.id === t.choice);
	if (!i) return { code: "games.mooncolonybloodbath.errAction" };
	let a = structuredClone(e), o = a.colonies[n], s = o.tasks[0]?.source;
	return o.tasks.splice(0, 1, ...i.tasks.map((e) => ({
		...e,
		source: e.source ?? s
	}))), o.revision++, { state: a };
}
function Ee(e, t) {
	let n = e.colonies[t], r = {
		players: e.players.map((t) => {
			let n = e.colonies[t];
			return {
				rid: t,
				base: n.base,
				population: N(n),
				money: n.money,
				food: n.food,
				buildings: n.buildings,
				handCount: n.hand.length,
				reservedCount: n.reserved.length,
				surveyedCount: n.surveyed.length,
				perks: n.perks,
				ready: n.tasks.length === 0 || n.sealed !== null || n.passed !== null,
				work: n.work,
				muted: n.muted,
				dead: n.dead
			};
		}),
		phase: e.phase,
		current: e.current,
		revealed: e.revealed,
		initialTwists: e.initialTwists,
		deckCount: e.deck.length,
		discardCount: e.discard.length,
		buildingDeckCount: e.buildings.length,
		buildingDiscardCount: e.buildingDiscard.length,
		buildingDiscardTop: e.buildingDiscard.at(-1) ?? null,
		events: e.events,
		extraRobots: e.extraRobots,
		cycle: e.cycle,
		turn: e.turn,
		doors: e.doors,
		repairs: e.repairs,
		robotCount: e.robots.length,
		twistCount: e.twists.length,
		developments: e.developments,
		extendedSolo: e.config.extendedSolo,
		ended: e.ended
	};
	if (!n) return { public: r };
	let i = le(e, t);
	return {
		public: r,
		private: {
			hand: n.hand,
			reserved: n.reserved,
			surveyed: n.surveyed,
			revision: n.revision,
			prompt: i ? null : de(n.tasks[0]),
			sourceCard: n.tasks[0]?.source ?? n.tasks[0]?.card ?? null,
			choices: i ? [] : ue(e, t).map((e) => e.view),
			storage: ce(n),
			selected: n.sealed?.card ?? n.passed,
			marked: n.tasks[0]?.cards ?? [],
			amount: n.tasks[0]?.op === "discard" ? Math.min(n.tasks[0].n ?? 1, n.hand.length) - (n.tasks[0].cards?.length ?? 0) : n.tasks[0]?.n ?? null
		}
	};
}
function De(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => N(e.colonies[n]) - N(e.colonies[t])), n = Object.fromEntries(e.players.map((t) => [t, e.players.length === 1 ? e.config.extendedSolo ? e.extraRobots : e.events : N(e.colonies[t])]));
	return {
		phase: "done",
		winner: e.players.length === 1 ? e.ended === "manual" ? [...e.players] : [] : t.filter((n) => N(e.colonies[n]) === N(e.colonies[t[0]])),
		ranking: t,
		scores: n
	};
}
function Oe(e) {
	return e.phase === "done" ? null : e.phase === "progress" ? 950 : Se(e) || e.players.every((t) => !e.colonies[t].tasks.length) || we(e) ? 240 : null;
}
var ke = {
	meta: fe,
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	schemas: {
		action: pe,
		publicView: _e,
		privateView: ve,
		config: Y
	},
	setup: ye,
	reduce: Te,
	viewFor: Ee,
	status: De,
	nextTickIn: Oe
}, Ae = /* #__PURE__ */ Object.assign({
	"./art/b0.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"32\" y=\"86\" width=\"249\" height=\"69\" rx=\"4\" fill=\"#d3baa0\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"m25 87 35-39H253L291 87Z\" fill=\"#d7b956\" stroke=\"#345b55\" stroke-width=\"3\"/><polygon points=\"34,84 50,51 66,84\" fill=\"#f4ddb2\"/><polygon points=\"69,84 85,51 101,84\" fill=\"#d08b79\"/><polygon points=\"104,84 120,51 136,84\" fill=\"#f4ddb2\"/><polygon points=\"139,84 155,51 171,84\" fill=\"#d08b79\"/><polygon points=\"174,84 190,51 206,84\" fill=\"#f4ddb2\"/><polygon points=\"209,84 225,51 241,84\" fill=\"#d08b79\"/><polygon points=\"244,84 260,51 276,84\" fill=\"#f4ddb2\"/><rect x=\"55\" y=\"104\" width=\"98\" height=\"43\" rx=\"3\" fill=\"#496b61\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"m69 135v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m95 135v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m121 135v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><g transform=\"translate(183 102) scale(1.6)\" ><polygon points=\"12,0 24,12 12,24 0,12\" fill=\"#e9d76a\" stroke=\"#b3a34c\" stroke-width=\"1\"/><path d=\"M12 8C1 1 4 19 12 21C21 19 24 1 12 8\" fill=\"#85ad44\" stroke=\"#456b36\"/><path d=\"M12 9V3Q17 0 18 4Q16 7 12 6\" fill=\"#a8c258\" stroke=\"#456b36\"/></g><g transform=\"translate(231 106) scale(1.5)\" ><polygon points=\"2,3 20,3 24,22 0,22\" fill=\"#253735\"/><path d=\"M4 18 7 7H11L13 14 15 7H18L21 18H17L16 12 14 18H10L9 12 7 18Z\" fill=\"#f5db59\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b1.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M36 156V107a39 39 0 0 1 78 0V156Z\" fill=\"#608690\" stroke=\"#b8cec0\" stroke-width=\"2\"/><rect x=\"48\" y=\"114\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"63\" y=\"114\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"78\" y=\"114\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"93\" y=\"114\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"48\" y=\"136\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"63\" y=\"136\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"78\" y=\"136\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"93\" y=\"136\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><path d=\"M99 156V86a57 57 0 0 1 114 0V156Z\" fill=\"#608690\" stroke=\"#b8cec0\" stroke-width=\"2\"/><rect x=\"111\" y=\"93\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"126\" y=\"93\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"141\" y=\"93\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"156\" y=\"93\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"111\" y=\"115\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"126\" y=\"115\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"141\" y=\"115\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"156\" y=\"115\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><path d=\"M195 156V118a44 44 0 0 1 88 0V156Z\" fill=\"#608690\" stroke=\"#b8cec0\" stroke-width=\"2\"/><rect x=\"207\" y=\"125\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"222\" y=\"125\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"237\" y=\"125\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"252\" y=\"125\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"207\" y=\"147\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"222\" y=\"147\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"237\" y=\"147\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"252\" y=\"147\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><path d=\"M46 132V61\" stroke=\"#ddc99b\" stroke-width=\"5\"/><rect x=\"10\" y=\"45\" width=\"96\" height=\"27\" rx=\"3\" fill=\"#174f61\" stroke=\"#dcc373\" stroke-width=\"2\"/><text x=\"58\" y=\"64\" font-size=\"12\" fill=\"#efd58d\" text-anchor=\"middle\" font-family=\"Bahnschrift,Arial,sans-serif\" font-weight=\"700\">MOON HOTEL</text><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/b10.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M75 156 119 109M211 156 187 106\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"8\"/><polygon points=\"33,62 208,34 280,107 92,137\" fill=\"#416b78\" stroke=\"#a7c3bd\" stroke-width=\"4\"/><path d=\"M56 58l65 73\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"1.3\"/><path d=\"M86 54l65 73\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"1.3\"/><path d=\"M116 50l65 73\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"1.3\"/><path d=\"M146 46l65 73\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"1.3\"/><path d=\"M176 42l65 73\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"1.3\"/><path d=\"M206 38l65 73\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"1.3\"/><path d=\"M53 84 229 58M72 109 255 84\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b11.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"30,149 132,88 290,143 190,173\" fill=\"#8d9e92\" stroke=\"#385c54\" stroke-width=\"3\"/><rect x=\"44\" y=\"89\" width=\"63\" height=\"49\" rx=\"12\" fill=\"#b5c5b2\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M190 134V69q17-45 34 0v65Z\" fill=\"#d8d2b2\" stroke=\"#345b55\" stroke-width=\"3\"/><polygon points=\"188,115 175,145 204,135\" fill=\"#b06c79\"/><polygon points=\"224,115 242,145 213,135\" fill=\"#b06c79\"/><rect x=\"196\" y=\"77\" width=\"20\" height=\"19\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><path d=\"M206 136v22\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"5\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b12.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"32\" y=\"72\" width=\"241\" height=\"81\" rx=\"12\" fill=\"#b4b89a\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"46\" y=\"85\" width=\"210\" height=\"64\" rx=\"1\" fill=\"#294e4b\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(61 103) scale(1.8)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(125 103) scale(1.8)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(189 103) scale(1.8)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><rect x=\"175\" y=\"48\" width=\"84\" height=\"29\" rx=\"12\" fill=\"#97b8ac\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(205 48) scale(1.1)\" ><path d=\"M7 1V8L1 20Q1 23 12 23Q23 23 23 20L17 8V1Z\" fill=\"#bcdedb\" stroke=\"#3e6a6b\" stroke-width=\"1.4\"/><path d=\"M5 14H19L22 21Q13 26 2 21Z\" fill=\"#5ca3aa\"/><circle cx=\"10\" cy=\"16\" r=\"1.4\" fill=\"#e1f2c1\" /><circle cx=\"16\" cy=\"20\" r=\"1\" fill=\"#e1f2c1\" /></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b13.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M123 154 141 88 160 88 182 154Z\" fill=\"url(#__mcb__metal)\" stroke=\"#345b5b\" stroke-width=\"3\"/><path d=\"m144 100-46-25 24-28 53 29Z\" fill=\"#9ab9b3\" stroke=\"#345b5b\" stroke-width=\"3\"/><path d=\"M53 32Q65 106 137 92L153 50Z\" fill=\"url(#__mcb__metal)\" stroke=\"#d3e3d0\" stroke-width=\"3\"/><path d=\"m54 33 77 16-45-43\" fill=\"none\" stroke=\"#b1cfca\" stroke-width=\"2\"/><path d=\"m86 6 3 49 44-6\" stroke=\"#c5d7c4\" stroke-width=\"2\" fill=\"none\"/><rect x=\"183\" y=\"119\" width=\"67\" height=\"37\" rx=\"12\" fill=\"#e0d6b5\" stroke=\"#49706a\" stroke-width=\"2\"/><rect x=\"199\" y=\"126\" width=\"28\" height=\"16\" rx=\"5\" fill=\"#397a7e\" /><g transform=\"translate(266 125) scale(0.55)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/b14.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"20,153 85,84 123,126 188,66 273,156\" fill=\"#9493a1\" stroke=\"#455e58\" stroke-width=\"3\"/><path d=\"M118 143V52H191V85\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"13\"/><rect x=\"107\" y=\"39\" width=\"110\" height=\"31\" rx=\"3\" fill=\"#a8a5bb\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"48\" y=\"133\" width=\"196\" height=\"22\" rx=\"10\" fill=\"#516f64\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"65\" cy=\"144\" r=\"7\" fill=\"#c8c6a5\" /><circle cx=\"91\" cy=\"144\" r=\"7\" fill=\"#c8c6a5\" /><circle cx=\"117\" cy=\"144\" r=\"7\" fill=\"#c8c6a5\" /><circle cx=\"143\" cy=\"144\" r=\"7\" fill=\"#c8c6a5\" /><circle cx=\"169\" cy=\"144\" r=\"7\" fill=\"#c8c6a5\" /><circle cx=\"195\" cy=\"144\" r=\"7\" fill=\"#c8c6a5\" /><circle cx=\"221\" cy=\"144\" r=\"7\" fill=\"#c8c6a5\" /><polygon points=\"198,77 219,88 207,106 186,92\" fill=\"#e2dbc3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b15.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"40\" y=\"79\" width=\"237\" height=\"76\" rx=\"12\" fill=\"#d0b697\" stroke=\"#345b55\" stroke-width=\"3\"/><polygon points=\"25,83 100,48 213,48 291,83\" fill=\"#8cafaa\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"68\" y=\"97\" width=\"68\" height=\"58\" rx=\"2\" fill=\"#365e59\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"167\" y=\"103\" width=\"55\" height=\"28\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><g transform=\"translate(184 40) scale(1.5)\" ><polygon points=\"2,3 20,3 24,22 0,22\" fill=\"#253735\"/><path d=\"M4 18 7 7H11L13 14 15 7H18L21 18H17L16 12 14 18H10L9 12 7 18Z\" fill=\"#f5db59\"/></g><g transform=\"translate(235 131) scale(1.1)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b16.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M32 157V95a59 67 0 0 1 118 0V157M166 157V110a53 52 0 0 1 106 0V157\" fill=\"#bcc3ac\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M47 157V98a44 51 0 0 1 88 0V157M180 157V112a38 35 0 0 1 76 0V157\" fill=\"#294d47\"/><path d=\"M88 65V156M218 87V156\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><g transform=\"translate(88 129) scale(1.1)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b17.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"81\" y=\"40\" width=\"135\" height=\"112\" rx=\"67.5\" fill=\"#b7c4b6\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M85 58H212M85 135H212\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><rect x=\"47\" y=\"89\" width=\"35\" height=\"65\" rx=\"17.5\" fill=\"#c6b9a3\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M51 107H78M51 137H78\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><rect x=\"217\" y=\"89\" width=\"35\" height=\"65\" rx=\"17.5\" fill=\"#c6b9a3\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M221 107H248M221 137H248\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M92 58H205M88 119H211\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"5\"/><circle cx=\"148\" cy=\"94\" r=\"25\" fill=\"#dbc265\" stroke=\"#385f54\" stroke-width=\"3\"/><polygon points=\"148,72 141,90 119,92 137,102 131,122 149,108 166,122 160,102 177,92 155,90\" fill=\"#506c57\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b18.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M45 154V73Q100 16 198 57L236 85V154Z\" fill=\"url(#__mcb__metal)\" stroke=\"#365656\" stroke-width=\"3\"/><path d=\"M53 77H227V152H53Z\" fill=\"#1c3b3d\"/><path d=\"M59 79V149M75 70V149M212 76V149M227 82V149\" stroke=\"#7c9a8c\" stroke-width=\"3\"/><path d=\"M57 92H229M57 120H229\" stroke=\"#56766d\" stroke-width=\"2\"/><g transform=\"translate(65 126) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(102 126) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(139 126) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(176 126) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(78 96) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(115 96) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(152 96) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(65 66) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(102 66) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(139 66) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(176 66) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><path d=\"M221 155V121H245L260 148H280V158H218\" fill=\"#d5ae52\" stroke=\"#264b49\" stroke-width=\"2\"/><path d=\"M268 155V106H278V154H299\" fill=\"none\" stroke=\"#d6bd77\" stroke-width=\"5\"/><circle cx=\"232\" cy=\"160\" r=\"9\" fill=\"#2e4e49\" /><circle cx=\"270\" cy=\"160\" r=\"9\" fill=\"#2e4e49\" /><g transform=\"translate(236 107) scale(0.43)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/b19.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"22,155 77,88 140,132 212,74 288,156\" fill=\"#c0c3ad\" stroke=\"#607464\" stroke-width=\"3\"/><rect x=\"94\" y=\"88\" width=\"109\" height=\"64\" rx=\"8\" fill=\"#aabdb4\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M135 88V43l80 37\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"11\"/><rect x=\"202\" y=\"70\" width=\"47\" height=\"28\" rx=\"2\" fill=\"#d2c9a2\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M111 112H191M111 131H191\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b2.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M31 155V71Q62 24 149 28Q244 32 279 74V155Z\" fill=\"url(#__mcb__metal)\" stroke=\"#34605e\" stroke-width=\"3\"/><path d=\"M48 149V77Q156 4 264 77V149\" fill=\"#2a5350\"/><path d=\"M63 148V88Q86 51 108 88V148Z\" fill=\"#b0a6bf\" stroke=\"#dce2c4\" stroke-width=\"3\"/><circle cx=\"86\" cy=\"102\" r=\"17\" fill=\"#a8cfbb\" stroke=\"#668a7d\" stroke-width=\"2\"/><circle cx=\"85\" cy=\"104\" r=\"8\" fill=\"#dcad83\" /><path d=\"m72 125q13-15 26 0v17h-26Z\" fill=\"#deb4bd\"/><rect x=\"70\" y=\"140\" width=\"30\" height=\"7\" rx=\"2\" fill=\"#3b6960\" /><path d=\"M129 148V88Q152 51 174 88V148Z\" fill=\"#bfbd95\" stroke=\"#dce2c4\" stroke-width=\"3\"/><circle cx=\"152\" cy=\"102\" r=\"17\" fill=\"#a8cfbb\" stroke=\"#668a7d\" stroke-width=\"2\"/><circle cx=\"151\" cy=\"104\" r=\"8\" fill=\"#dcad83\" /><path d=\"m138 125q13-15 26 0v17h-26Z\" fill=\"#a9bf89\"/><rect x=\"136\" y=\"140\" width=\"30\" height=\"7\" rx=\"2\" fill=\"#3b6960\" /><path d=\"M195 148V88Q218 51 240 88V148Z\" fill=\"#9dbbba\" stroke=\"#dce2c4\" stroke-width=\"3\"/><circle cx=\"218\" cy=\"102\" r=\"17\" fill=\"#a8cfbb\" stroke=\"#668a7d\" stroke-width=\"2\"/><circle cx=\"217\" cy=\"104\" r=\"8\" fill=\"#dcad83\" /><path d=\"m204 125q13-15 26 0v17h-26Z\" fill=\"#d1bd82\"/><rect x=\"202\" y=\"140\" width=\"30\" height=\"7\" rx=\"2\" fill=\"#3b6960\" /><g transform=\"translate(276 115) scale(0.65)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/b20.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"40\" y=\"70\" width=\"240\" height=\"84\" rx=\"12\" fill=\"#9fb9aa\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"54\" y=\"84\" width=\"211\" height=\"62\" rx=\"3\" fill=\"#335e5c\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"64\" y=\"92\" width=\"53\" height=\"46\" rx=\"20\" fill=\"#aac6b5\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"85\" cy=\"117\" r=\"10\" fill=\"#c0b28e\" /><circle cx=\"80\" cy=\"107\" r=\"5\" fill=\"#c0b28e\" /><circle cx=\"91\" cy=\"107\" r=\"5\" fill=\"#c0b28e\" /><rect x=\"130\" y=\"92\" width=\"53\" height=\"46\" rx=\"20\" fill=\"#aac6b5\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"151\" cy=\"117\" r=\"10\" fill=\"#c0b28e\" /><circle cx=\"146\" cy=\"107\" r=\"5\" fill=\"#c0b28e\" /><circle cx=\"157\" cy=\"107\" r=\"5\" fill=\"#c0b28e\" /><rect x=\"196\" y=\"92\" width=\"53\" height=\"46\" rx=\"20\" fill=\"#aac6b5\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"217\" cy=\"117\" r=\"10\" fill=\"#c0b28e\" /><circle cx=\"212\" cy=\"107\" r=\"5\" fill=\"#c0b28e\" /><circle cx=\"223\" cy=\"107\" r=\"5\" fill=\"#c0b28e\" /><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b21.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"24,150 59,77 249,77 289,150\" fill=\"#8eaaa1\" stroke=\"#345b55\" stroke-width=\"4\"/><rect x=\"88\" y=\"91\" width=\"134\" height=\"64\" rx=\"3\" fill=\"#6d877e\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"123\" y=\"107\" width=\"61\" height=\"48\" rx=\"6\" fill=\"#b8baa1\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"153\" cy=\"129\" r=\"14\" fill=\"#4a685a\" /><path d=\"M137 128H169M153 113v30\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b22.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"37\" y=\"79\" width=\"243\" height=\"76\" rx=\"31\" fill=\"#a0bbad\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M70 85V148M112 82V150M207 82V150M248 86V148\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><rect x=\"122\" y=\"96\" width=\"73\" height=\"59\" rx=\"2\" fill=\"#355f58\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(128 120) scale(1.1)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(155 113) scale(1.2)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b23.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"11,158 56,68 111,103 173,47 255,93 302,158\" fill=\"#939b8b\" stroke=\"#4d6b5b\" stroke-width=\"4\"/><path d=\"M79 157q2-66 64-58q67-8 74 58Z\" fill=\"#234b45\"/><path d=\"M119 139v-25H172v25\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"4\"/><g transform=\"translate(137 134) scale(1)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b24.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"41\" y=\"78\" width=\"237\" height=\"77\" rx=\"12\" fill=\"#a7bfb4\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"63\" y=\"35\" width=\"42\" height=\"77\" rx=\"21\" fill=\"#d5d7b5\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M67 53H101M67 95H101\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><rect x=\"124\" y=\"23\" width=\"50\" height=\"91\" rx=\"25\" fill=\"#c2c7b3\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M128 41H170M128 97H170\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><rect x=\"195\" y=\"49\" width=\"45\" height=\"67\" rx=\"22.5\" fill=\"#d8c79b\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M199 67H236M199 99H236\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M84 37V19H149M151 23V7M219 49V28H266V117\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"4\"/><rect x=\"112\" y=\"119\" width=\"53\" height=\"27\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><g transform=\"translate(215 114) scale(1.4)\" ><path d=\"M7 1V8L1 20Q1 23 12 23Q23 23 23 20L17 8V1Z\" fill=\"#bcdedb\" stroke=\"#3e6a6b\" stroke-width=\"1.4\"/><path d=\"M5 14H19L22 21Q13 26 2 21Z\" fill=\"#5ca3aa\"/><circle cx=\"10\" cy=\"16\" r=\"1.4\" fill=\"#e1f2c1\" /><circle cx=\"16\" cy=\"20\" r=\"1\" fill=\"#e1f2c1\" /></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b25.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"29\" y=\"54\" width=\"260\" height=\"101\" rx=\"28\" fill=\"#9db6a8\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"42\" y=\"73\" width=\"38\" height=\"73\" rx=\"19\" fill=\"#b7ccae\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M46 91H76M46 129H76\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><circle cx=\"61\" cy=\"96\" r=\"10\" fill=\"#d6ac88\" /><rect x=\"50\" y=\"111\" width=\"22\" height=\"25\" rx=\"9\" fill=\"#b38f9d\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"92\" y=\"73\" width=\"38\" height=\"73\" rx=\"19\" fill=\"#b7ccae\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M96 91H126M96 129H126\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><circle cx=\"111\" cy=\"96\" r=\"10\" fill=\"#d6ac88\" /><rect x=\"100\" y=\"111\" width=\"22\" height=\"25\" rx=\"9\" fill=\"#b38f9d\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"142\" y=\"73\" width=\"38\" height=\"73\" rx=\"19\" fill=\"#b7ccae\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M146 91H176M146 129H176\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><circle cx=\"161\" cy=\"96\" r=\"10\" fill=\"#d6ac88\" /><rect x=\"150\" y=\"111\" width=\"22\" height=\"25\" rx=\"9\" fill=\"#b38f9d\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"192\" y=\"73\" width=\"38\" height=\"73\" rx=\"19\" fill=\"#b7ccae\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M196 91H226M196 129H226\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><circle cx=\"211\" cy=\"96\" r=\"10\" fill=\"#d6ac88\" /><rect x=\"200\" y=\"111\" width=\"22\" height=\"25\" rx=\"9\" fill=\"#b38f9d\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"242\" y=\"73\" width=\"38\" height=\"73\" rx=\"19\" fill=\"#b7ccae\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M246 91H276M246 129H276\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><circle cx=\"261\" cy=\"96\" r=\"10\" fill=\"#d6ac88\" /><rect x=\"250\" y=\"111\" width=\"22\" height=\"25\" rx=\"9\" fill=\"#b38f9d\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b26.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"25\" y=\"104\" width=\"86\" height=\"51\" rx=\"12\" fill=\"#b3bd9c\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"84\" y=\"59\" width=\"102\" height=\"96\" rx=\"12\" fill=\"#8bb1a9\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"174\" y=\"86\" width=\"109\" height=\"69\" rx=\"12\" fill=\"#a6bbc0\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"114\" y=\"28\" width=\"47\" height=\"36\" rx=\"12\" fill=\"#d5c590\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"96\" y=\"80\" width=\"11\" height=\"16\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"115\" y=\"80\" width=\"11\" height=\"16\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"134\" y=\"80\" width=\"11\" height=\"16\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"153\" y=\"80\" width=\"11\" height=\"16\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"96\" y=\"109\" width=\"11\" height=\"16\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"115\" y=\"109\" width=\"11\" height=\"16\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"134\" y=\"109\" width=\"11\" height=\"16\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"153\" y=\"109\" width=\"11\" height=\"16\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"36\" y=\"120\" width=\"54\" height=\"17\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"196\" y=\"108\" width=\"52\" height=\"27\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b27.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"12,155 43,104 85,132 152,111 218,127 282,99 307,157\" fill=\"#a99b83\"/><rect x=\"62\" y=\"94\" width=\"194\" height=\"57\" rx=\"23\" fill=\"#99b6ad\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"76\" y=\"109\" width=\"21\" height=\"19\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"111\" y=\"109\" width=\"21\" height=\"19\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"146\" y=\"109\" width=\"21\" height=\"19\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"181\" y=\"109\" width=\"21\" height=\"19\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"216\" y=\"109\" width=\"21\" height=\"19\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><path d=\"M105 151v-24H135v24\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b28.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M29 155V78a130.5 114 0 0 1 261 0V155Z\" fill=\"url(#__mcb__glass)\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M29 78H290M159.5 -36V155\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M31 107H287M54 41 79 155M111-20 126 155M215 12 190 155M269 45 243 155\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><rect x=\"138\" y=\"104\" width=\"43\" height=\"52\" rx=\"14\" fill=\"#d4d2b1\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"144\" y=\"115\" width=\"31\" height=\"41\" rx=\"12\" fill=\"#335d54\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b29.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"17,155 66,100 136,141 211,113 290,155\" fill=\"#b6a07e\"/><rect x=\"65\" y=\"96\" width=\"125\" height=\"59\" rx=\"10\" fill=\"#c3ac72\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M80 96V76H221V151\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"10\"/><rect x=\"199\" y=\"95\" width=\"49\" height=\"58\" rx=\"24.5\" fill=\"#bdad8e\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M203 113H244M203 136H244\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M47 108q16-52 42-27m156 57q39-33 32-59\" fill=\"none\" stroke=\"#d9c89c\" stroke-width=\"5\" stroke-dasharray=\"4 6\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b3.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"39\" y=\"70\" width=\"238\" height=\"87\" rx=\"12\" fill=\"#9faab6\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"51\" y=\"82\" width=\"42\" height=\"60\" rx=\"17\" fill=\"#ccd9c0\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"72\" cy=\"108\" r=\"14\" fill=\"#8fbba9\" /><path d=\"m68 98q-13 9 0 20q15-5 4-17Z\" fill=\"#c38d9c\"/><rect x=\"105\" y=\"82\" width=\"42\" height=\"60\" rx=\"17\" fill=\"#ccd9c0\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"126\" cy=\"108\" r=\"14\" fill=\"#8fbba9\" /><path d=\"m122 98q-13 9 0 20q15-5 4-17Z\" fill=\"#c38d9c\"/><rect x=\"159\" y=\"82\" width=\"42\" height=\"60\" rx=\"17\" fill=\"#ccd9c0\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"180\" cy=\"108\" r=\"14\" fill=\"#8fbba9\" /><path d=\"m176 98q-13 9 0 20q15-5 4-17Z\" fill=\"#c38d9c\"/><rect x=\"213\" y=\"82\" width=\"42\" height=\"60\" rx=\"17\" fill=\"#ccd9c0\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"234\" cy=\"108\" r=\"14\" fill=\"#8fbba9\" /><path d=\"m230 98q-13 9 0 20q15-5 4-17Z\" fill=\"#c38d9c\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b30.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M99 155V18\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"6\"/><path d=\"M102 23Q148 5 203 27V82Q148 62 102 79Z\" fill=\"#dbc365\" stroke=\"#355f53\" stroke-width=\"3\"/><circle cx=\"148\" cy=\"45\" r=\"16\" fill=\"#b8d0b8\" /><path d=\"M151 30q-15 16 1 30a16 16 0 0 1-1-30\" fill=\"#5d8c80\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b31.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"15,155 79,75 152,123 206,82 301,155\" fill=\"#9b8c7e\" stroke=\"#506459\" stroke-width=\"3\"/><rect x=\"110\" y=\"82\" width=\"93\" height=\"72\" rx=\"5\" fill=\"#b47759\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M139 83V40H225V115\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"12\"/><polygon points=\"213,103 239,103 245,134 207,134\" fill=\"#d0a477\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(55 133) scale(1.3)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b32.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M66 154V72H259V151\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"7\"/><rect x=\"78\" y=\"48\" width=\"56\" height=\"105\" rx=\"28\" fill=\"#b5b4a1\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M82 66H130M82 136H130\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><rect x=\"151\" y=\"48\" width=\"56\" height=\"105\" rx=\"28\" fill=\"#bdc9ac\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M155 66H203M155 136H203\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M106 50V29H181V50\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"4\"/><polygon points=\"107,84 98,110 108,110 101,133 123,102 112,102 123,84\" fill=\"#d4ba61\"/><rect x=\"220\" y=\"113\" width=\"51\" height=\"41\" rx=\"12\" fill=\"#9bb29d\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b33.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"49\" y=\"83\" width=\"219\" height=\"71\" rx=\"12\" fill=\"#a9b393\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"112\" cy=\"118\" r=\"35\" fill=\"#c5ccaf\" stroke=\"#42685a\" stroke-width=\"4\"/><circle cx=\"112\" cy=\"118\" r=\"22\" fill=\"#698e7a\" /><path d=\"M103 96 126 130M127 98 98 131\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"7\"/><rect x=\"195\" y=\"58\" width=\"49\" height=\"91\" rx=\"24.5\" fill=\"#d2c69d\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M199 76H240M199 132H240\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M221 58V31H266V85\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"6\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b34.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"44\" y=\"82\" width=\"234\" height=\"74\" rx=\"12\" fill=\"#abc2b8\" stroke=\"#345b55\" stroke-width=\"3\"/><polygon points=\"57,149 80,102 105,145\" fill=\"#c3ac77\"/><polygon points=\"114,148 137,80 163,145\" fill=\"#c39987\"/><polygon points=\"172,149 208,96 239,146\" fill=\"#a7b399\"/><path d=\"M66 72V38H106V63M222 81V29\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"5\"/><rect x=\"74\" y=\"31\" width=\"39\" height=\"19\" rx=\"12\" fill=\"#a8bfb0\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b35.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M30 149V83A130 108 0 0 1 260 83V149Z\" fill=\"url(#__mcb__glass)\" stroke=\"#add4c5\" stroke-width=\"3\"/><path d=\"M30 83H260M37 112H257M145 16V149M72 33Q35 82 69 148M111 18Q88 80 102 149M180 18Q203 80 187 149M217 33Q255 82 222 149\" stroke=\"#c3d7c0\" stroke-width=\"2\" fill=\"none\" opacity=\".7\"/><path d=\"m45 151 55-35H210L249 151Z\" fill=\"#a58e54\"/><path d=\"M55 145H240\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m62 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m84 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m106 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m128 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m150 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m172 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m194 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m216 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M63 140H232\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m65 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m87 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m109 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m131 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m153 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m175 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m197 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m219 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"M71 135H224\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m68 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m90 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m112 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m134 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m156 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m178 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m200 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m222 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M79 130H216\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m71 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m93 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m115 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m137 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m159 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m181 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m203 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m225 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"M87 125H208\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m74 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m96 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m118 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m140 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m162 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m184 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m206 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m228 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M31 150H268\" stroke=\"#253f3d\" stroke-width=\"5\"/><rect x=\"119\" y=\"108\" width=\"46\" height=\"43\" rx=\"4\" fill=\"#d1d5b9\" stroke=\"#3f655a\" stroke-width=\"2\"/><rect x=\"127\" y=\"114\" width=\"28\" height=\"34\" rx=\"12\" fill=\"#23494a\" /><path d=\"M30 69Q110 11 200 38\" stroke=\"#ecf1cb\" stroke-width=\"8\" opacity=\".15\" fill=\"none\"/><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/b36.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"41\" y=\"70\" width=\"235\" height=\"85\" rx=\"12\" fill=\"#6c8c85\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"52\" y=\"81\" width=\"43\" height=\"62\" rx=\"4\" fill=\"#234d4b\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"61\" y=\"89\" width=\"25\" height=\"18\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><circle cx=\"63\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><circle cx=\"73\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><circle cx=\"83\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><rect x=\"106\" y=\"81\" width=\"43\" height=\"62\" rx=\"4\" fill=\"#234d4b\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"115\" y=\"89\" width=\"25\" height=\"18\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><circle cx=\"117\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><circle cx=\"127\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><circle cx=\"137\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><rect x=\"160\" y=\"81\" width=\"43\" height=\"62\" rx=\"4\" fill=\"#234d4b\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"169\" y=\"89\" width=\"25\" height=\"18\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><circle cx=\"171\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><circle cx=\"181\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><circle cx=\"191\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><rect x=\"214\" y=\"81\" width=\"43\" height=\"62\" rx=\"4\" fill=\"#234d4b\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"223\" y=\"89\" width=\"25\" height=\"18\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><circle cx=\"225\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><circle cx=\"235\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><circle cx=\"245\" cy=\"126\" r=\"2\" fill=\"#d6bf6d\" /><path d=\"M70 70V39H253M253 39V18\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"4\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b37.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M69 155V52H231V151\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"7\"/><rect x=\"80\" y=\"59\" width=\"42\" height=\"94\" rx=\"21\" fill=\"#b0c3b4\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M84 77H118M84 136H118\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M102 61V37\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"6\"/><rect x=\"135\" y=\"59\" width=\"42\" height=\"94\" rx=\"21\" fill=\"#b0c3b4\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M139 77H173M139 136H173\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M157 61V37\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"6\"/><rect x=\"190\" y=\"59\" width=\"42\" height=\"94\" rx=\"21\" fill=\"#b0c3b4\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M194 77H228M194 136H228\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"M212 61V37\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"6\"/><circle cx=\"271\" cy=\"123\" r=\"24\" fill=\"#d6bc6d\" stroke=\"#345b55\" stroke-width=\"3\"/><text x=\"271\" y=\"130\" text-anchor=\"middle\" fill=\"#355f53\" font-family=\"Georgia\" font-weight=\"bold\" font-size=\"19\">He</text><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b38.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"35\" y=\"95\" width=\"248\" height=\"61\" rx=\"8\" fill=\"#adc8b2\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"48\" y=\"75\" width=\"62\" height=\"58\" rx=\"5\" fill=\"#4e7c6f\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"m60 100v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m86 100v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"M54 118H102\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><rect x=\"125\" y=\"75\" width=\"62\" height=\"58\" rx=\"5\" fill=\"#4e7c6f\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"m137 100v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m163 100v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"M131 118H179\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><rect x=\"202\" y=\"75\" width=\"62\" height=\"58\" rx=\"5\" fill=\"#4e7c6f\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"m214 100v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m240 100v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"M208 118H256\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><path d=\"M30 145H289M59 154V174M258 154v20\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"5\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b39.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M29 155V98a129.5 69 0 0 1 259 0V155Z\" fill=\"url(#__mcb__glass)\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M29 98H288M158.5 29V155\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><path d=\"m56 143v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m82 143v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m108 143v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m134 143v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m160 143v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m186 143v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m212 143v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m238 143v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m66 112v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m92 112v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m118 112v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m144 112v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m170 112v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m196 112v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"m222 112v-24q-20-14-17 0l17 13q22-16 19-28l-19 18\" fill=\"#9fb966\" stroke=\"#487154\" stroke-width=\"2\"/><path d=\"M35 154H281\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"5\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b4.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M30 149V83A130 108 0 0 1 260 83V149Z\" fill=\"url(#__mcb__glass)\" stroke=\"#add4c5\" stroke-width=\"3\"/><path d=\"M30 83H260M37 112H257M145 16V149M72 33Q35 82 69 148M111 18Q88 80 102 149M180 18Q203 80 187 149M217 33Q255 82 222 149\" stroke=\"#c3d7c0\" stroke-width=\"2\" fill=\"none\" opacity=\".7\"/><path d=\"m45 151 55-35H210L249 151Z\" fill=\"#a58e54\"/><path d=\"M55 145H240\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m62 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m84 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m106 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m128 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m150 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m172 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m194 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m216 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M63 140H232\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m65 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m87 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m109 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m131 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m153 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m175 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m197 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m219 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"M71 135H224\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m68 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m90 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m112 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m134 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m156 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m178 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m200 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m222 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M79 130H216\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m71 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m93 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m115 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m137 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m159 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m181 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m203 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m225 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"M87 125H208\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m74 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m96 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m118 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m140 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m162 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m184 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m206 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m228 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M31 150H268\" stroke=\"#253f3d\" stroke-width=\"5\"/><rect x=\"119\" y=\"108\" width=\"46\" height=\"43\" rx=\"4\" fill=\"#d1d5b9\" stroke=\"#3f655a\" stroke-width=\"2\"/><rect x=\"127\" y=\"114\" width=\"28\" height=\"34\" rx=\"12\" fill=\"#23494a\" /><g transform=\"translate(270 118) scale(0.65)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#c9d5be\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#c9d5be\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#c9d5be\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><g transform=\"translate(273 154) scale(0.7)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/b40.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"37\" y=\"70\" width=\"241\" height=\"84\" rx=\"12\" fill=\"#c2bca4\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"51\" y=\"99\" width=\"69\" height=\"51\" rx=\"6\" fill=\"#699987\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"132\" y=\"102\" width=\"62\" height=\"48\" rx=\"3\" fill=\"#e0c28c\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"144\" cy=\"111\" r=\"6\" fill=\"#3f6252\" /><circle cx=\"163\" cy=\"111\" r=\"6\" fill=\"#3f6252\" /><circle cx=\"182\" cy=\"111\" r=\"6\" fill=\"#3f6252\" /><rect x=\"208\" y=\"84\" width=\"53\" height=\"66\" rx=\"7\" fill=\"#a9bbac\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M78 95V54H176V35\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"5\"/><g transform=\"translate(217 104) scale(1.4)\" ><polygon points=\"12,0 24,12 12,24 0,12\" fill=\"#e9d76a\" stroke=\"#b3a34c\" stroke-width=\"1\"/><path d=\"M12 8C1 1 4 19 12 21C21 19 24 1 12 8\" fill=\"#85ad44\" stroke=\"#456b36\"/><path d=\"M12 9V3Q17 0 18 4Q16 7 12 6\" fill=\"#a8c258\" stroke=\"#456b36\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b41.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><polygon points=\"23,156 112,110 284,140 181,176\" fill=\"#92a89b\" stroke=\"#385e52\" stroke-width=\"3\"/><path d=\"M86 137V25H147M98 40H156M98 65H160M98 91H153\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"5\"/><path d=\"M165 139V62q16-40 32 0v77Z\" fill=\"#dbd4b9\" stroke=\"#345b55\" stroke-width=\"3\"/><polygon points=\"164,117 149,147 178,137\" fill=\"#bd7f7c\"/><polygon points=\"197,117 212,147 185,137\" fill=\"#bd7f7c\"/><circle cx=\"181\" cy=\"85\" r=\"10\" fill=\"#67958c\" /><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b42.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"49\" y=\"53\" width=\"73\" height=\"86\" rx=\"36.5\" fill=\"#b4b7a5\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M53 71H118M53 122H118\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><rect x=\"144\" y=\"69\" width=\"75\" height=\"70\" rx=\"37.5\" fill=\"#a9b4a1\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M148 87H215M148 122H215\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><polygon points=\"65,139 85,158 103,139\" fill=\"#b9bda5\" stroke=\"#345b55\" stroke-width=\"2\"/><polygon points=\"162,139 182,158 200,139\" fill=\"#b9bda5\" stroke=\"#345b55\" stroke-width=\"2\"/><path d=\"M82 55V32H268V143\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"7\"/><rect x=\"222\" y=\"117\" width=\"64\" height=\"38\" rx=\"12\" fill=\"#8eab9e\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b43.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"m32 151 29-89 116-19 108 102Z\" fill=\"#c4c4a3\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M177 43V153M62 62 177 43 284 62M177 43 236 153\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><rect x=\"81\" y=\"106\" width=\"62\" height=\"45\" rx=\"1\" fill=\"#385f55\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(196 105) scale(1.7)\" ><path d=\"M7 1V8L1 20Q1 23 12 23Q23 23 23 20L17 8V1Z\" fill=\"#bcdedb\" stroke=\"#3e6a6b\" stroke-width=\"1.4\"/><path d=\"M5 14H19L22 21Q13 26 2 21Z\" fill=\"#5ca3aa\"/><circle cx=\"10\" cy=\"16\" r=\"1.4\" fill=\"#e1f2c1\" /><circle cx=\"16\" cy=\"20\" r=\"1\" fill=\"#e1f2c1\" /></g><g transform=\"translate(45 130) scale(1)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b44.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"30\" y=\"119\" width=\"260\" height=\"35\" rx=\"16\" fill=\"#9ab0a0\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"44\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"67\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"90\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"113\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"136\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"159\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"182\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"205\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"228\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"251\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><circle cx=\"274\" cy=\"137\" r=\"9\" fill=\"#496b5d\" stroke=\"#c6c9aa\" stroke-width=\"1.5\"/><path d=\"M84 120V40H231V109\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"8\"/><path d=\"M155 42V74l-23 18m23-18 24 18\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"7\"/><g transform=\"translate(73 95) scale(1.3)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(208 94) scale(1.3)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b5.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M79 157 125 62 151 66 189 157Z\" fill=\"#8eaaa6\" stroke=\"#2d5555\" stroke-width=\"3\"/><path d=\"m43 38 171 38Q139 126 43 38Z\" fill=\"url(#__mcb__metal)\" stroke=\"#c8d8c3\" stroke-width=\"3\"/><path d=\"m43 38 94 11 77 27M137 49 160 7\" fill=\"none\" stroke=\"#a1c3b7\" stroke-width=\"3\"/><circle cx=\"160\" cy=\"7\" r=\"4\" fill=\"#f2d369\" /><path d=\"M195 151V117L249 97 283 117V151Z\" fill=\"#afc3b0\" stroke=\"#365f58\" stroke-width=\"3\"/><rect x=\"216\" y=\"119\" width=\"32\" height=\"18\" rx=\"3\" fill=\"#547f76\" /><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/b6.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"43\" y=\"103\" width=\"61\" height=\"51\" rx=\"12\" fill=\"#d8b76e\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"201\" y=\"97\" width=\"64\" height=\"57\" rx=\"12\" fill=\"#b5c4a5\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M82 100 126 61 185 77 221 101\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"12\"/><polygon points=\"109,69 129,44 153,60 141,79\" fill=\"#b1c3a6\" stroke=\"#365c53\" stroke-width=\"2\"/><g transform=\"translate(128 119) scale(1.4)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><polygon points=\"133,134 177,106 199,139\" fill=\"#94a99c\"/><circle cx=\"81\" cy=\"133\" r=\"13\" fill=\"#46695a\" /><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b7.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M30 155V78a83 75 0 0 1 166 0V155Z\" fill=\"url(#__mcb__glass)\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M30 78H196M113 3V155\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"2\"/><rect x=\"206\" y=\"103\" width=\"76\" height=\"51\" rx=\"12\" fill=\"#a4b5a1\" stroke=\"#345b55\" stroke-width=\"3\"/><path d=\"M212 104V49M199 61H228M254 102V77\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"5\"/><rect x=\"66\" y=\"103\" width=\"29\" height=\"29\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><rect x=\"113\" y=\"103\" width=\"29\" height=\"29\" rx=\"3\" fill=\"#e6cc7a\" stroke=\"#3d6d64\" stroke-width=\"2\"/><g transform=\"translate(219 112) scale(1.6)\" ><path d=\"M7 1V8L1 20Q1 23 12 23Q23 23 23 20L17 8V1Z\" fill=\"#bcdedb\" stroke=\"#3e6a6b\" stroke-width=\"1.4\"/><path d=\"M5 14H19L22 21Q13 26 2 21Z\" fill=\"#5ca3aa\"/><circle cx=\"10\" cy=\"16\" r=\"1.4\" fill=\"#e1f2c1\" /><circle cx=\"16\" cy=\"20\" r=\"1\" fill=\"#e1f2c1\" /></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b8.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><rect x=\"43\" y=\"63\" width=\"234\" height=\"91\" rx=\"30\" fill=\"#b5bd9f\" stroke=\"#345b55\" stroke-width=\"3\"/><rect x=\"67\" y=\"83\" width=\"186\" height=\"57\" rx=\"5\" fill=\"#3b625d\" stroke=\"#345b55\" stroke-width=\"3\"/><circle cx=\"95\" cy=\"121\" r=\"19\" fill=\"#e5cf94\" /><path d=\"M95 121v-20\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><circle cx=\"158\" cy=\"121\" r=\"19\" fill=\"#e5cf94\" /><path d=\"M158 121v-20\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><circle cx=\"221\" cy=\"121\" r=\"19\" fill=\"#e5cf94\" /><path d=\"M221 121v-20\" fill=\"none\" stroke=\"#a8c2af\" stroke-width=\"3\"/><rect x=\"90\" y=\"42\" width=\"132\" height=\"30\" rx=\"5\" fill=\"#d4b66e\" stroke=\"#345b55\" stroke-width=\"3\"/><g transform=\"translate(142 43) scale(1.1)\" ><polygon points=\"12,0 24,12 12,24 0,12\" fill=\"#e9d76a\" stroke=\"#b3a34c\" stroke-width=\"1\"/><path d=\"M12 8C1 1 4 19 12 21C21 19 24 1 12 8\" fill=\"#85ad44\" stroke=\"#456b36\"/><path d=\"M12 9V3Q17 0 18 4Q16 7 12 6\" fill=\"#a8c258\" stroke=\"#456b36\"/></g><g transform=\"translate(282 126) scale(0.45)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g></svg>",
	"./art/b9.svg": "<svg preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M30 157Q76 106 117 148L183 144 230 177H30Z\" fill=\"#8b725d\"/><path d=\"m75 143 37-34 39 34 30-25 44 48\" fill=\"#bbb19a\" stroke=\"#5b625b\" stroke-width=\"2\"/><path d=\"M58 147H175V124H148L127 95 104 103V139H58Z\" fill=\"#c7a448\" stroke=\"#344a43\" stroke-width=\"3\"/><path d=\"m128 102 43-61 61 4-3 10-52-2-31 55Z\" fill=\"#dfbf5b\" stroke=\"#344a43\" stroke-width=\"3\"/><path d=\"m225 43 31 67-16 22-9-9 12-14-27-58\" fill=\"#caa746\" stroke=\"#344a43\" stroke-width=\"3\"/><rect x=\"104\" y=\"105\" width=\"23\" height=\"25\" rx=\"2\" fill=\"#71918b\" stroke=\"#344a43\" stroke-width=\"2\"/><rect x=\"54\" y=\"144\" width=\"128\" height=\"20\" rx=\"9\" fill=\"#354f4b\" /><circle cx=\"65\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"80\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"95\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"110\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"125\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"140\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"155\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"170\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><g transform=\"translate(264 116) scale(0.62)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><g transform=\"translate(38 153) scale(0.8)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/base-dome.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"300\" height=\"230\" viewBox=\"0 0 300 230\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><defs><linearGradient id=\"__mcb__deepSpace\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#07191c\"/><stop offset=\".65\" stop-color=\"#18322f\"/><stop offset=\"1\" stop-color=\"#33483a\"/></linearGradient><linearGradient id=\"__mcb__regolith\" x1=\"0\" y1=\"0\" x2=\".35\" y2=\"1\"><stop stop-color=\"#958b78\"/><stop offset=\".18\" stop-color=\"#d3c8b0\"/><stop offset=\".7\" stop-color=\"#b3a68f\"/><stop offset=\"1\" stop-color=\"#8a8a77\"/></linearGradient><linearGradient id=\"__mcb__deckMetal\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#758174\"/><stop offset=\".02\" stop-color=\"#d2ceb6\"/><stop offset=\".07\" stop-color=\"#647266\"/><stop offset=\".1\" stop-color=\"#344b43\"/><stop offset=\"1\" stop-color=\"#20372f\"/></linearGradient><linearGradient id=\"__mcb__silver\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".2\"><stop stop-color=\"#697e76\"/><stop offset=\".22\" stop-color=\"#e0e1cc\"/><stop offset=\".44\" stop-color=\"#a5b4a1\"/><stop offset=\".65\" stop-color=\"#e7e5ce\"/><stop offset=\"1\" stop-color=\"#8a9c88\"/></linearGradient><linearGradient id=\"__mcb__key\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f7d77e\"/><stop offset=\".8\" stop-color=\"#d9aa4e\"/><stop offset=\"1\" stop-color=\"#b8873a\"/></linearGradient><linearGradient id=\"__mcb__earth\" x1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#8caeb0\"/><stop offset=\".5\" stop-color=\"#3a7285\"/><stop offset=\"1\" stop-color=\"#163d4b\"/></linearGradient><radialGradient id=\"__mcb__halo\"><stop stop-color=\"#dce1ba\" stop-opacity=\".45\"/><stop offset=\"1\" stop-color=\"#dce1ba\" stop-opacity=\"0\"/></radialGradient><pattern id=\"__mcb__finePrint\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0 1 1\" stroke=\"#402d1e\" opacity=\".11\" stroke-width=\".8\"/></pattern><filter id=\"__mcb__objectShadow\" x=\"-25%\" y=\"-30%\" width=\"160%\" height=\"180%\"><feDropShadow dx=\"4\" dy=\"7\" stdDeviation=\"5\" flood-color=\"#101f19\" flood-opacity=\".5\"/></filter><filter id=\"__mcb__paperShadow\" x=\"-15%\" y=\"-15%\" width=\"140%\" height=\"150%\"><feDropShadow dx=\"2\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#1d2f24\" flood-opacity=\".45\"/></filter><clipPath id=\"__mcb__sphereClip\"><circle cx=\"0\" cy=\"0\" r=\"50\"/></clipPath></defs><g font-family=\"Microsoft YaHei,Arial,sans-serif\"><g transform=\"translate(150 78) scale(1)\" ><g transform=\"translate(0 0) scale(1)\" ><ellipse cx=\"0\" cy=\"99\" rx=\"139\" ry=\"25\" fill=\"#5e705c\" opacity=\".4\"/><path d=\"M-119 70V31a119 101 0 0 1 238 0V70Z\" fill=\"url(#__mcb__glass)\" stroke=\"#d2d6b7\" stroke-width=\"4\"/><path d=\"M-119 31H119M0-70V69M-75-46Q-108 12-72 70M75-46Q108 12 72 70\" stroke=\"#a9c6aa\" stroke-width=\"2\" fill=\"none\"/><path d=\"M-127 70H127V94H-127Z\" fill=\"url(#__mcb__silver)\" stroke=\"#3b5f4c\" stroke-width=\"2\"/><path d=\"M-80 96V123M81 96V123\" stroke=\"#566e59\" stroke-width=\"8\"/><rect x=\"-42\" y=\"16\" width=\"84\" height=\"84\" rx=\"42\" fill=\"#d6d8b9\" stroke=\"#426558\" stroke-width=\"4\"/><circle cx=\"0\" cy=\"58\" r=\"34\" fill=\"#203f38\" stroke=\"#91ad91\" stroke-width=\"2\"/><circle cx=\"-111\" cy=\"81\" r=\"5\" fill=\"#647d70\" stroke=\"#d9dcc4\" stroke-width=\".8\"/><path d=\"M-113.5 82.5L-108.5 79.5\" stroke=\"#243e34\" stroke-width=\"1.6\" /><circle cx=\"111\" cy=\"81\" r=\"5\" fill=\"#647d70\" stroke=\"#d9dcc4\" stroke-width=\".8\"/><path d=\"M108.5 82.5L113.5 79.5\" stroke=\"#243e34\" stroke-width=\"1.6\" /></g></g></g></svg>",
	"./art/base.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M30 149V83A130 108 0 0 1 260 83V149Z\" fill=\"url(#__mcb__glass)\" stroke=\"#add4c5\" stroke-width=\"3\"/><path d=\"M30 83H260M37 112H257M145 16V149M72 33Q35 82 69 148M111 18Q88 80 102 149M180 18Q203 80 187 149M217 33Q255 82 222 149\" stroke=\"#c3d7c0\" stroke-width=\"2\" fill=\"none\" opacity=\".7\"/><path d=\"m45 151 55-35H210L249 151Z\" fill=\"#a58e54\"/><path d=\"M55 145H240\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m62 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m84 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m106 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m128 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m150 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m172 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m194 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m216 141q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M63 140H232\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m65 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m87 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m109 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m131 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m153 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m175 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m197 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m219 136q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"M71 135H224\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m68 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m90 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m112 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m134 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m156 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m178 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m200 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m222 131q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M79 130H216\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m71 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m93 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m115 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m137 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m159 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m181 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m203 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"m225 126q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#a3b765\"/><path d=\"M87 125H208\" stroke=\"#315a3b\" stroke-width=\"5\"/><path d=\"m74 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m96 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m118 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m140 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m162 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m184 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m206 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"m228 121q-6-12-11-7q6 5 11 7q-1-10 7-11q-2 10-7 11\" fill=\"#739854\"/><path d=\"M31 150H268\" stroke=\"#253f3d\" stroke-width=\"5\"/><rect x=\"119\" y=\"108\" width=\"46\" height=\"43\" rx=\"4\" fill=\"#d1d5b9\" stroke=\"#3f655a\" stroke-width=\"2\"/><rect x=\"127\" y=\"114\" width=\"28\" height=\"34\" rx=\"12\" fill=\"#23494a\" /><path d=\"M30 69Q110 11 200 38\" stroke=\"#ecf1cb\" stroke-width=\"8\" opacity=\".15\" fill=\"none\"/><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/crew0.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100\" height=\"100\" viewBox=\"0 0 100 100\"><defs><linearGradient id=\"space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><defs><linearGradient id=\"deepSpace\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#07191c\"/><stop offset=\".65\" stop-color=\"#18322f\"/><stop offset=\"1\" stop-color=\"#33483a\"/></linearGradient><linearGradient id=\"regolith\" x1=\"0\" y1=\"0\" x2=\".35\" y2=\"1\"><stop stop-color=\"#958b78\"/><stop offset=\".18\" stop-color=\"#d3c8b0\"/><stop offset=\".7\" stop-color=\"#b3a68f\"/><stop offset=\"1\" stop-color=\"#8a8a77\"/></linearGradient><linearGradient id=\"deckMetal\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#758174\"/><stop offset=\".02\" stop-color=\"#d2ceb6\"/><stop offset=\".07\" stop-color=\"#647266\"/><stop offset=\".1\" stop-color=\"#344b43\"/><stop offset=\"1\" stop-color=\"#20372f\"/></linearGradient><linearGradient id=\"silver\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".2\"><stop stop-color=\"#697e76\"/><stop offset=\".22\" stop-color=\"#e0e1cc\"/><stop offset=\".44\" stop-color=\"#a5b4a1\"/><stop offset=\".65\" stop-color=\"#e7e5ce\"/><stop offset=\"1\" stop-color=\"#8a9c88\"/></linearGradient><linearGradient id=\"key\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f7d77e\"/><stop offset=\".8\" stop-color=\"#d9aa4e\"/><stop offset=\"1\" stop-color=\"#b8873a\"/></linearGradient><linearGradient id=\"earth\" x1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#8caeb0\"/><stop offset=\".5\" stop-color=\"#3a7285\"/><stop offset=\"1\" stop-color=\"#163d4b\"/></linearGradient><radialGradient id=\"halo\"><stop stop-color=\"#dce1ba\" stop-opacity=\".45\"/><stop offset=\"1\" stop-color=\"#dce1ba\" stop-opacity=\"0\"/></radialGradient><pattern id=\"finePrint\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0 1 1\" stroke=\"#402d1e\" opacity=\".11\" stroke-width=\".8\"/></pattern><filter id=\"objectShadow\" x=\"-25%\" y=\"-30%\" width=\"160%\" height=\"180%\"><feDropShadow dx=\"4\" dy=\"7\" stdDeviation=\"5\" flood-color=\"#101f19\" flood-opacity=\".5\"/></filter><filter id=\"paperShadow\" x=\"-15%\" y=\"-15%\" width=\"140%\" height=\"150%\"><feDropShadow dx=\"2\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#1d2f24\" flood-opacity=\".45\"/></filter><clipPath id=\"sphereClip\"><circle cx=\"0\" cy=\"0\" r=\"50\"/></clipPath></defs><g font-family=\"Microsoft YaHei,Arial,sans-serif\"><g transform=\"translate(50 50) scale(0.96)\" ><circle cx=\"0\" cy=\"0\" r=\"49\" fill=\"#dadcc8\" stroke=\"#405f55\" stroke-width=\"2\"/><circle cx=\"0\" cy=\"0\" r=\"44\" fill=\"#557b76\" /><circle cx=\"0\" cy=\"0\" r=\"41\" fill=\"#b0c4ad\" /><path d=\"M-31 36Q-25 15 0 19Q25 15 31 36Q0 52-31 36\" fill=\"#7bafa1\" stroke=\"#355e56\" stroke-width=\"2\"/><path d=\"m-13 20 13 12 13-12-4-8H-9Z\" fill=\"#cbd3bd\"/><path d=\"M-21-15Q-23-39 2-37Q27-35 22-10L19 7Q11 24 0 24Q-16 22-20 6Z\" fill=\"#d4a27a\" stroke=\"#745d47\" stroke-width=\"1.3\"/><path d=\"M-22-9Q-33-27-11-39Q16-48 26-25L23-7 15-22 2-27-7-12-20-16Z\" fill=\"#554c3e\"/><path d=\"M-15-3q6-4 11-1M6-4q6-4 11 0\" stroke=\"#554d3c\" stroke-width=\"2\" fill=\"none\"/><circle cx=\"-10\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><circle cx=\"11\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><path d=\"M1 0-2 9H4M-6 15Q0 18 7 14\" stroke=\"#8c594b\" stroke-width=\"1.6\" fill=\"none\"/><g stroke=\"#496f67\" stroke-width=\"2\" fill=\"#b5cfbd\" fill-opacity=\".25\"><ellipse cx=\"-10\" cy=\"1\" rx=\"10\" ry=\"7\"/><ellipse cx=\"11\" cy=\"1\" rx=\"10\" ry=\"7\"/><path d=\"M0 0H1M-20-1-4-4M21-1 27-3\"/></g><path d=\"M-31-29Q-49-10-36 23M19-35Q46-26 41 9\" stroke=\"#edf0d5\" stroke-width=\"3\" opacity=\".6\" fill=\"none\"/><circle cx=\"0\" cy=\"0\" r=\"47\" fill=\"none\" stroke=\"#a7bba6\" stroke-width=\"3\"/></g></g></svg>",
	"./art/crew1.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100\" height=\"100\" viewBox=\"0 0 100 100\"><defs><linearGradient id=\"space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><defs><linearGradient id=\"deepSpace\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#07191c\"/><stop offset=\".65\" stop-color=\"#18322f\"/><stop offset=\"1\" stop-color=\"#33483a\"/></linearGradient><linearGradient id=\"regolith\" x1=\"0\" y1=\"0\" x2=\".35\" y2=\"1\"><stop stop-color=\"#958b78\"/><stop offset=\".18\" stop-color=\"#d3c8b0\"/><stop offset=\".7\" stop-color=\"#b3a68f\"/><stop offset=\"1\" stop-color=\"#8a8a77\"/></linearGradient><linearGradient id=\"deckMetal\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#758174\"/><stop offset=\".02\" stop-color=\"#d2ceb6\"/><stop offset=\".07\" stop-color=\"#647266\"/><stop offset=\".1\" stop-color=\"#344b43\"/><stop offset=\"1\" stop-color=\"#20372f\"/></linearGradient><linearGradient id=\"silver\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".2\"><stop stop-color=\"#697e76\"/><stop offset=\".22\" stop-color=\"#e0e1cc\"/><stop offset=\".44\" stop-color=\"#a5b4a1\"/><stop offset=\".65\" stop-color=\"#e7e5ce\"/><stop offset=\"1\" stop-color=\"#8a9c88\"/></linearGradient><linearGradient id=\"key\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f7d77e\"/><stop offset=\".8\" stop-color=\"#d9aa4e\"/><stop offset=\"1\" stop-color=\"#b8873a\"/></linearGradient><linearGradient id=\"earth\" x1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#8caeb0\"/><stop offset=\".5\" stop-color=\"#3a7285\"/><stop offset=\"1\" stop-color=\"#163d4b\"/></linearGradient><radialGradient id=\"halo\"><stop stop-color=\"#dce1ba\" stop-opacity=\".45\"/><stop offset=\"1\" stop-color=\"#dce1ba\" stop-opacity=\"0\"/></radialGradient><pattern id=\"finePrint\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0 1 1\" stroke=\"#402d1e\" opacity=\".11\" stroke-width=\".8\"/></pattern><filter id=\"objectShadow\" x=\"-25%\" y=\"-30%\" width=\"160%\" height=\"180%\"><feDropShadow dx=\"4\" dy=\"7\" stdDeviation=\"5\" flood-color=\"#101f19\" flood-opacity=\".5\"/></filter><filter id=\"paperShadow\" x=\"-15%\" y=\"-15%\" width=\"140%\" height=\"150%\"><feDropShadow dx=\"2\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#1d2f24\" flood-opacity=\".45\"/></filter><clipPath id=\"sphereClip\"><circle cx=\"0\" cy=\"0\" r=\"50\"/></clipPath></defs><g font-family=\"Microsoft YaHei,Arial,sans-serif\"><g transform=\"translate(50 50) scale(0.96)\" ><circle cx=\"0\" cy=\"0\" r=\"49\" fill=\"#dadcc8\" stroke=\"#405f55\" stroke-width=\"2\"/><circle cx=\"0\" cy=\"0\" r=\"44\" fill=\"#557b76\" /><circle cx=\"0\" cy=\"0\" r=\"41\" fill=\"#b0c4ad\" /><path d=\"M-31 36Q-25 15 0 19Q25 15 31 36Q0 52-31 36\" fill=\"#a88b9e\" stroke=\"#355e56\" stroke-width=\"2\"/><path d=\"m-13 20 13 12 13-12-4-8H-9Z\" fill=\"#cbd3bd\"/><path d=\"M-21-15Q-23-39 2-37Q27-35 22-10L19 7Q11 24 0 24Q-16 22-20 6Z\" fill=\"#a8785b\" stroke=\"#745d47\" stroke-width=\"1.3\"/><path d=\"M-22-9Q-33-27-11-39Q16-48 26-25L23-7 15-22 2-27-7-12-20-16Z\" fill=\"#3c4441\"/><path d=\"M-15-3q6-4 11-1M6-4q6-4 11 0\" stroke=\"#554d3c\" stroke-width=\"2\" fill=\"none\"/><circle cx=\"-10\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><circle cx=\"11\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><path d=\"M1 0-2 9H4M-6 15Q0 18 7 14\" stroke=\"#8c594b\" stroke-width=\"1.6\" fill=\"none\"/><path d=\"M-31-29Q-49-10-36 23M19-35Q46-26 41 9\" stroke=\"#edf0d5\" stroke-width=\"3\" opacity=\".6\" fill=\"none\"/><circle cx=\"0\" cy=\"0\" r=\"47\" fill=\"none\" stroke=\"#a7bba6\" stroke-width=\"3\"/></g></g></svg>",
	"./art/crew2.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100\" height=\"100\" viewBox=\"0 0 100 100\"><defs><linearGradient id=\"space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><defs><linearGradient id=\"deepSpace\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#07191c\"/><stop offset=\".65\" stop-color=\"#18322f\"/><stop offset=\"1\" stop-color=\"#33483a\"/></linearGradient><linearGradient id=\"regolith\" x1=\"0\" y1=\"0\" x2=\".35\" y2=\"1\"><stop stop-color=\"#958b78\"/><stop offset=\".18\" stop-color=\"#d3c8b0\"/><stop offset=\".7\" stop-color=\"#b3a68f\"/><stop offset=\"1\" stop-color=\"#8a8a77\"/></linearGradient><linearGradient id=\"deckMetal\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#758174\"/><stop offset=\".02\" stop-color=\"#d2ceb6\"/><stop offset=\".07\" stop-color=\"#647266\"/><stop offset=\".1\" stop-color=\"#344b43\"/><stop offset=\"1\" stop-color=\"#20372f\"/></linearGradient><linearGradient id=\"silver\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".2\"><stop stop-color=\"#697e76\"/><stop offset=\".22\" stop-color=\"#e0e1cc\"/><stop offset=\".44\" stop-color=\"#a5b4a1\"/><stop offset=\".65\" stop-color=\"#e7e5ce\"/><stop offset=\"1\" stop-color=\"#8a9c88\"/></linearGradient><linearGradient id=\"key\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f7d77e\"/><stop offset=\".8\" stop-color=\"#d9aa4e\"/><stop offset=\"1\" stop-color=\"#b8873a\"/></linearGradient><linearGradient id=\"earth\" x1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#8caeb0\"/><stop offset=\".5\" stop-color=\"#3a7285\"/><stop offset=\"1\" stop-color=\"#163d4b\"/></linearGradient><radialGradient id=\"halo\"><stop stop-color=\"#dce1ba\" stop-opacity=\".45\"/><stop offset=\"1\" stop-color=\"#dce1ba\" stop-opacity=\"0\"/></radialGradient><pattern id=\"finePrint\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0 1 1\" stroke=\"#402d1e\" opacity=\".11\" stroke-width=\".8\"/></pattern><filter id=\"objectShadow\" x=\"-25%\" y=\"-30%\" width=\"160%\" height=\"180%\"><feDropShadow dx=\"4\" dy=\"7\" stdDeviation=\"5\" flood-color=\"#101f19\" flood-opacity=\".5\"/></filter><filter id=\"paperShadow\" x=\"-15%\" y=\"-15%\" width=\"140%\" height=\"150%\"><feDropShadow dx=\"2\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#1d2f24\" flood-opacity=\".45\"/></filter><clipPath id=\"sphereClip\"><circle cx=\"0\" cy=\"0\" r=\"50\"/></clipPath></defs><g font-family=\"Microsoft YaHei,Arial,sans-serif\"><g transform=\"translate(50 50) scale(0.96)\" ><circle cx=\"0\" cy=\"0\" r=\"49\" fill=\"#dadcc8\" stroke=\"#405f55\" stroke-width=\"2\"/><circle cx=\"0\" cy=\"0\" r=\"44\" fill=\"#557b76\" /><circle cx=\"0\" cy=\"0\" r=\"41\" fill=\"#b0c4ad\" /><path d=\"M-31 36Q-25 15 0 19Q25 15 31 36Q0 52-31 36\" fill=\"#b2b983\" stroke=\"#355e56\" stroke-width=\"2\"/><path d=\"m-13 20 13 12 13-12-4-8H-9Z\" fill=\"#cbd3bd\"/><path d=\"M-21-15Q-23-39 2-37Q27-35 22-10L19 7Q11 24 0 24Q-16 22-20 6Z\" fill=\"#e1b38c\" stroke=\"#745d47\" stroke-width=\"1.3\"/><path d=\"M-22-9Q-33-27-11-39Q16-48 26-25L23-7 15-22 2-27-7-12-20-16Z\" fill=\"#a26645\"/><path d=\"M-15-3q6-4 11-1M6-4q6-4 11 0\" stroke=\"#554d3c\" stroke-width=\"2\" fill=\"none\"/><circle cx=\"-10\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><circle cx=\"11\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><path d=\"M1 0-2 9H4M-6 15Q0 18 7 14\" stroke=\"#8c594b\" stroke-width=\"1.6\" fill=\"none\"/><path d=\"M-31-29Q-49-10-36 23M19-35Q46-26 41 9\" stroke=\"#edf0d5\" stroke-width=\"3\" opacity=\".6\" fill=\"none\"/><circle cx=\"0\" cy=\"0\" r=\"47\" fill=\"none\" stroke=\"#a7bba6\" stroke-width=\"3\"/></g></g></svg>",
	"./art/crew3.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100\" height=\"100\" viewBox=\"0 0 100 100\"><defs><linearGradient id=\"space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><defs><linearGradient id=\"deepSpace\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#07191c\"/><stop offset=\".65\" stop-color=\"#18322f\"/><stop offset=\"1\" stop-color=\"#33483a\"/></linearGradient><linearGradient id=\"regolith\" x1=\"0\" y1=\"0\" x2=\".35\" y2=\"1\"><stop stop-color=\"#958b78\"/><stop offset=\".18\" stop-color=\"#d3c8b0\"/><stop offset=\".7\" stop-color=\"#b3a68f\"/><stop offset=\"1\" stop-color=\"#8a8a77\"/></linearGradient><linearGradient id=\"deckMetal\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#758174\"/><stop offset=\".02\" stop-color=\"#d2ceb6\"/><stop offset=\".07\" stop-color=\"#647266\"/><stop offset=\".1\" stop-color=\"#344b43\"/><stop offset=\"1\" stop-color=\"#20372f\"/></linearGradient><linearGradient id=\"silver\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".2\"><stop stop-color=\"#697e76\"/><stop offset=\".22\" stop-color=\"#e0e1cc\"/><stop offset=\".44\" stop-color=\"#a5b4a1\"/><stop offset=\".65\" stop-color=\"#e7e5ce\"/><stop offset=\"1\" stop-color=\"#8a9c88\"/></linearGradient><linearGradient id=\"key\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f7d77e\"/><stop offset=\".8\" stop-color=\"#d9aa4e\"/><stop offset=\"1\" stop-color=\"#b8873a\"/></linearGradient><linearGradient id=\"earth\" x1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#8caeb0\"/><stop offset=\".5\" stop-color=\"#3a7285\"/><stop offset=\"1\" stop-color=\"#163d4b\"/></linearGradient><radialGradient id=\"halo\"><stop stop-color=\"#dce1ba\" stop-opacity=\".45\"/><stop offset=\"1\" stop-color=\"#dce1ba\" stop-opacity=\"0\"/></radialGradient><pattern id=\"finePrint\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0 1 1\" stroke=\"#402d1e\" opacity=\".11\" stroke-width=\".8\"/></pattern><filter id=\"objectShadow\" x=\"-25%\" y=\"-30%\" width=\"160%\" height=\"180%\"><feDropShadow dx=\"4\" dy=\"7\" stdDeviation=\"5\" flood-color=\"#101f19\" flood-opacity=\".5\"/></filter><filter id=\"paperShadow\" x=\"-15%\" y=\"-15%\" width=\"140%\" height=\"150%\"><feDropShadow dx=\"2\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#1d2f24\" flood-opacity=\".45\"/></filter><clipPath id=\"sphereClip\"><circle cx=\"0\" cy=\"0\" r=\"50\"/></clipPath></defs><g font-family=\"Microsoft YaHei,Arial,sans-serif\"><g transform=\"translate(50 50) scale(0.96)\" ><circle cx=\"0\" cy=\"0\" r=\"49\" fill=\"#dadcc8\" stroke=\"#405f55\" stroke-width=\"2\"/><circle cx=\"0\" cy=\"0\" r=\"44\" fill=\"#557b76\" /><circle cx=\"0\" cy=\"0\" r=\"41\" fill=\"#b0c4ad\" /><path d=\"M-31 36Q-25 15 0 19Q25 15 31 36Q0 52-31 36\" fill=\"#8aaabb\" stroke=\"#355e56\" stroke-width=\"2\"/><path d=\"m-13 20 13 12 13-12-4-8H-9Z\" fill=\"#cbd3bd\"/><path d=\"M-21-15Q-23-39 2-37Q27-35 22-10L19 7Q11 24 0 24Q-16 22-20 6Z\" fill=\"#b38765\" stroke=\"#745d47\" stroke-width=\"1.3\"/><path d=\"M-22-9Q-33-27-11-39Q16-48 26-25L23-7 15-22 2-27-7-12-20-16Z\" fill=\"#d1c9a5\"/><path d=\"M-15-3q6-4 11-1M6-4q6-4 11 0\" stroke=\"#554d3c\" stroke-width=\"2\" fill=\"none\"/><circle cx=\"-10\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><circle cx=\"11\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><path d=\"M1 0-2 9H4M-6 15Q0 18 7 14\" stroke=\"#8c594b\" stroke-width=\"1.6\" fill=\"none\"/><g stroke=\"#496f67\" stroke-width=\"2\" fill=\"#b5cfbd\" fill-opacity=\".25\"><ellipse cx=\"-10\" cy=\"1\" rx=\"10\" ry=\"7\"/><ellipse cx=\"11\" cy=\"1\" rx=\"10\" ry=\"7\"/><path d=\"M0 0H1M-20-1-4-4M21-1 27-3\"/></g><path d=\"M-31-29Q-49-10-36 23M19-35Q46-26 41 9\" stroke=\"#edf0d5\" stroke-width=\"3\" opacity=\".6\" fill=\"none\"/><circle cx=\"0\" cy=\"0\" r=\"47\" fill=\"none\" stroke=\"#a7bba6\" stroke-width=\"3\"/></g></g></svg>",
	"./art/crew4.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100\" height=\"100\" viewBox=\"0 0 100 100\"><defs><linearGradient id=\"space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><defs><linearGradient id=\"deepSpace\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#07191c\"/><stop offset=\".65\" stop-color=\"#18322f\"/><stop offset=\"1\" stop-color=\"#33483a\"/></linearGradient><linearGradient id=\"regolith\" x1=\"0\" y1=\"0\" x2=\".35\" y2=\"1\"><stop stop-color=\"#958b78\"/><stop offset=\".18\" stop-color=\"#d3c8b0\"/><stop offset=\".7\" stop-color=\"#b3a68f\"/><stop offset=\"1\" stop-color=\"#8a8a77\"/></linearGradient><linearGradient id=\"deckMetal\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#758174\"/><stop offset=\".02\" stop-color=\"#d2ceb6\"/><stop offset=\".07\" stop-color=\"#647266\"/><stop offset=\".1\" stop-color=\"#344b43\"/><stop offset=\"1\" stop-color=\"#20372f\"/></linearGradient><linearGradient id=\"silver\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".2\"><stop stop-color=\"#697e76\"/><stop offset=\".22\" stop-color=\"#e0e1cc\"/><stop offset=\".44\" stop-color=\"#a5b4a1\"/><stop offset=\".65\" stop-color=\"#e7e5ce\"/><stop offset=\"1\" stop-color=\"#8a9c88\"/></linearGradient><linearGradient id=\"key\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f7d77e\"/><stop offset=\".8\" stop-color=\"#d9aa4e\"/><stop offset=\"1\" stop-color=\"#b8873a\"/></linearGradient><linearGradient id=\"earth\" x1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#8caeb0\"/><stop offset=\".5\" stop-color=\"#3a7285\"/><stop offset=\"1\" stop-color=\"#163d4b\"/></linearGradient><radialGradient id=\"halo\"><stop stop-color=\"#dce1ba\" stop-opacity=\".45\"/><stop offset=\"1\" stop-color=\"#dce1ba\" stop-opacity=\"0\"/></radialGradient><pattern id=\"finePrint\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0 1 1\" stroke=\"#402d1e\" opacity=\".11\" stroke-width=\".8\"/></pattern><filter id=\"objectShadow\" x=\"-25%\" y=\"-30%\" width=\"160%\" height=\"180%\"><feDropShadow dx=\"4\" dy=\"7\" stdDeviation=\"5\" flood-color=\"#101f19\" flood-opacity=\".5\"/></filter><filter id=\"paperShadow\" x=\"-15%\" y=\"-15%\" width=\"140%\" height=\"150%\"><feDropShadow dx=\"2\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#1d2f24\" flood-opacity=\".45\"/></filter><clipPath id=\"sphereClip\"><circle cx=\"0\" cy=\"0\" r=\"50\"/></clipPath></defs><g font-family=\"Microsoft YaHei,Arial,sans-serif\"><g transform=\"translate(50 50) scale(0.96)\" ><circle cx=\"0\" cy=\"0\" r=\"49\" fill=\"#dadcc8\" stroke=\"#405f55\" stroke-width=\"2\"/><circle cx=\"0\" cy=\"0\" r=\"44\" fill=\"#557b76\" /><circle cx=\"0\" cy=\"0\" r=\"41\" fill=\"#b0c4ad\" /><path d=\"M-31 36Q-25 15 0 19Q25 15 31 36Q0 52-31 36\" fill=\"#7bafa1\" stroke=\"#355e56\" stroke-width=\"2\"/><path d=\"m-13 20 13 12 13-12-4-8H-9Z\" fill=\"#cbd3bd\"/><path d=\"M-21-15Q-23-39 2-37Q27-35 22-10L19 7Q11 24 0 24Q-16 22-20 6Z\" fill=\"#d4a27a\" stroke=\"#745d47\" stroke-width=\"1.3\"/><path d=\"M-22-9Q-33-27-11-39Q16-48 26-25L23-7 15-22 2-27-7-12-20-16Z\" fill=\"#554c3e\"/><path d=\"M-15-3q6-4 11-1M6-4q6-4 11 0\" stroke=\"#554d3c\" stroke-width=\"2\" fill=\"none\"/><circle cx=\"-10\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><circle cx=\"11\" cy=\"1\" r=\"1.8\" fill=\"#243d3b\" /><path d=\"M1 0-2 9H4M-6 15Q0 18 7 14\" stroke=\"#8c594b\" stroke-width=\"1.6\" fill=\"none\"/><path d=\"M-31-29Q-49-10-36 23M19-35Q46-26 41 9\" stroke=\"#edf0d5\" stroke-width=\"3\" opacity=\".6\" fill=\"none\"/><circle cx=\"0\" cy=\"0\" r=\"47\" fill=\"none\" stroke=\"#a7bba6\" stroke-width=\"3\"/></g></g></svg>",
	"./art/development.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M45 154V73Q100 16 198 57L236 85V154Z\" fill=\"url(#__mcb__metal)\" stroke=\"#365656\" stroke-width=\"3\"/><path d=\"M53 77H227V152H53Z\" fill=\"#1c3b3d\"/><path d=\"M59 79V149M75 70V149M212 76V149M227 82V149\" stroke=\"#7c9a8c\" stroke-width=\"3\"/><path d=\"M57 92H229M57 120H229\" stroke=\"#56766d\" stroke-width=\"2\"/><g transform=\"translate(65 126) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(102 126) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(139 126) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(176 126) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(78 96) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(115 96) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(152 96) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(65 66) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(102 66) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(139 66) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(176 66) scale(1.25)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><path d=\"M221 155V121H245L260 148H280V158H218\" fill=\"#d5ae52\" stroke=\"#264b49\" stroke-width=\"2\"/><path d=\"M268 155V106H278V154H299\" fill=\"none\" stroke=\"#d6bd77\" stroke-width=\"5\"/><circle cx=\"232\" cy=\"160\" r=\"9\" fill=\"#2e4e49\" /><circle cx=\"270\" cy=\"160\" r=\"9\" fill=\"#2e4e49\" /><g transform=\"translate(236 107) scale(0.43)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/event.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M79 157 125 62 151 66 189 157Z\" fill=\"#8eaaa6\" stroke=\"#2d5555\" stroke-width=\"3\"/><path d=\"m43 38 171 38Q139 126 43 38Z\" fill=\"url(#__mcb__metal)\" stroke=\"#c8d8c3\" stroke-width=\"3\"/><path d=\"m43 38 94 11 77 27M137 49 160 7\" fill=\"none\" stroke=\"#a1c3b7\" stroke-width=\"3\"/><circle cx=\"160\" cy=\"7\" r=\"4\" fill=\"#f2d369\" /><path d=\"M195 151V117L249 97 283 117V151Z\" fill=\"#afc3b0\" stroke=\"#365f58\" stroke-width=\"3\"/><rect x=\"216\" y=\"119\" width=\"32\" height=\"18\" rx=\"3\" fill=\"#547f76\" /><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/loneliness.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M36 156V107a39 39 0 0 1 78 0V156Z\" fill=\"#608690\" stroke=\"#b8cec0\" stroke-width=\"2\"/><rect x=\"48\" y=\"114\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"63\" y=\"114\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"78\" y=\"114\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"93\" y=\"114\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"48\" y=\"136\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"63\" y=\"136\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"78\" y=\"136\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"93\" y=\"136\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><path d=\"M99 156V86a57 57 0 0 1 114 0V156Z\" fill=\"#608690\" stroke=\"#b8cec0\" stroke-width=\"2\"/><rect x=\"111\" y=\"93\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"126\" y=\"93\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"141\" y=\"93\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"156\" y=\"93\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"111\" y=\"115\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"126\" y=\"115\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"141\" y=\"115\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"156\" y=\"115\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><path d=\"M195 156V118a44 44 0 0 1 88 0V156Z\" fill=\"#608690\" stroke=\"#b8cec0\" stroke-width=\"2\"/><rect x=\"207\" y=\"125\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"222\" y=\"125\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"237\" y=\"125\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"252\" y=\"125\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#f1d280\" /><rect x=\"207\" y=\"147\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"222\" y=\"147\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"237\" y=\"147\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><rect x=\"252\" y=\"147\" width=\"6\" height=\"9\" rx=\"3\" fill=\"#e9c56a\" /><path d=\"M46 132V61\" stroke=\"#ddc99b\" stroke-width=\"5\"/><rect x=\"10\" y=\"45\" width=\"96\" height=\"27\" rx=\"3\" fill=\"#174f61\" stroke=\"#dcc373\" stroke-width=\"2\"/><text x=\"58\" y=\"64\" font-size=\"12\" fill=\"#efd58d\" text-anchor=\"middle\" font-family=\"Bahnschrift,Arial,sans-serif\" font-weight=\"700\">MOON HOTEL</text><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/perk.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M31 155V71Q62 24 149 28Q244 32 279 74V155Z\" fill=\"url(#__mcb__metal)\" stroke=\"#34605e\" stroke-width=\"3\"/><path d=\"M48 149V77Q156 4 264 77V149\" fill=\"#2a5350\"/><path d=\"M63 148V88Q86 51 108 88V148Z\" fill=\"#b0a6bf\" stroke=\"#dce2c4\" stroke-width=\"3\"/><circle cx=\"86\" cy=\"102\" r=\"17\" fill=\"#a8cfbb\" stroke=\"#668a7d\" stroke-width=\"2\"/><circle cx=\"85\" cy=\"104\" r=\"8\" fill=\"#dcad83\" /><path d=\"m72 125q13-15 26 0v17h-26Z\" fill=\"#deb4bd\"/><rect x=\"70\" y=\"140\" width=\"30\" height=\"7\" rx=\"2\" fill=\"#3b6960\" /><path d=\"M129 148V88Q152 51 174 88V148Z\" fill=\"#bfbd95\" stroke=\"#dce2c4\" stroke-width=\"3\"/><circle cx=\"152\" cy=\"102\" r=\"17\" fill=\"#a8cfbb\" stroke=\"#668a7d\" stroke-width=\"2\"/><circle cx=\"151\" cy=\"104\" r=\"8\" fill=\"#dcad83\" /><path d=\"m138 125q13-15 26 0v17h-26Z\" fill=\"#a9bf89\"/><rect x=\"136\" y=\"140\" width=\"30\" height=\"7\" rx=\"2\" fill=\"#3b6960\" /><path d=\"M195 148V88Q218 51 240 88V148Z\" fill=\"#9dbbba\" stroke=\"#dce2c4\" stroke-width=\"3\"/><circle cx=\"218\" cy=\"102\" r=\"17\" fill=\"#a8cfbb\" stroke=\"#668a7d\" stroke-width=\"2\"/><circle cx=\"217\" cy=\"104\" r=\"8\" fill=\"#dcad83\" /><path d=\"m204 125q13-15 26 0v17h-26Z\" fill=\"#d1bd82\"/><rect x=\"202\" y=\"140\" width=\"30\" height=\"7\" rx=\"2\" fill=\"#3b6960\" /><g transform=\"translate(276 115) scale(0.65)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/robot.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M0 128Q121 89 320 135V180H0\" fill=\"#b58c89\"/><path d=\"M246 25V146M274 30V145\" stroke=\"#819b95\" stroke-width=\"4\"/><path d=\"m129 122-15 50h20l22-42m18-8 23 50h20l-18-53\" fill=\"url(#__mcb__metal)\" stroke=\"#284b4d\" stroke-width=\"3\"/><path d=\"m118 69-24 51 10 9 32-44m60-17 19 37 48-4\" fill=\"none\" stroke=\"#b5c5b4\" stroke-width=\"12\"/><path d=\"M119 69Q159 49 199 69L190 126Q159 144 126 125Z\" fill=\"#244c4f\" stroke=\"#b8c8ba\" stroke-width=\"3\"/><path d=\"m130 68 27 28 28-28-7 62h-39Z\" fill=\"url(#__mcb__pinkMetal)\"/><circle cx=\"157\" cy=\"42\" r=\"27\" fill=\"url(#__mcb__metal)\" stroke=\"#264e4d\" stroke-width=\"3\"/><path d=\"M134 37Q157 11 182 38L181 52Q159 67 134 51Z\" fill=\"#d6b663\" stroke=\"#3e6055\" stroke-width=\"2\"/><circle cx=\"146\" cy=\"40\" r=\"5\" fill=\"#d86a60\" /><circle cx=\"169\" cy=\"40\" r=\"5\" fill=\"#d86a60\" /><path d=\"M145 55H171M150 50H165M157 14V2\" stroke=\"#6b6c51\" stroke-width=\"2\"/><circle cx=\"157\" cy=\"3\" r=\"4\" fill=\"#cb6879\" /><path d=\"m110 105-35-10-20 8 25 8 29-2m109-10 49-1\" fill=\"#c1d2bf\" stroke=\"#345f59\" stroke-width=\"3\"/><rect x=\"64\" y=\"78\" width=\"19\" height=\"20\" rx=\"3\" fill=\"#ecdfc1\" /><rect x=\"248\" y=\"78\" width=\"19\" height=\"20\" rx=\"3\" fill=\"#ecdfc1\" /><path d=\"M70 73q-6-7 1-12m183 12q8-7 0-12\" stroke=\"#d1cdb3\" stroke-width=\"2\" fill=\"none\"/><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/table.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1920\" height=\"1080\" viewBox=\"0 0 1920 1080\" preserveAspectRatio=\"xMidYMid slice\"><defs><linearGradient id=\"space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><defs><linearGradient id=\"deepSpace\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#07191c\"/><stop offset=\".65\" stop-color=\"#18322f\"/><stop offset=\"1\" stop-color=\"#33483a\"/></linearGradient><linearGradient id=\"regolith\" x1=\"0\" y1=\"0\" x2=\".35\" y2=\"1\"><stop stop-color=\"#958b78\"/><stop offset=\".18\" stop-color=\"#d3c8b0\"/><stop offset=\".7\" stop-color=\"#b3a68f\"/><stop offset=\"1\" stop-color=\"#8a8a77\"/></linearGradient><linearGradient id=\"deckMetal\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#758174\"/><stop offset=\".02\" stop-color=\"#d2ceb6\"/><stop offset=\".07\" stop-color=\"#647266\"/><stop offset=\".1\" stop-color=\"#344b43\"/><stop offset=\"1\" stop-color=\"#20372f\"/></linearGradient><linearGradient id=\"silver\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".2\"><stop stop-color=\"#697e76\"/><stop offset=\".22\" stop-color=\"#e0e1cc\"/><stop offset=\".44\" stop-color=\"#a5b4a1\"/><stop offset=\".65\" stop-color=\"#e7e5ce\"/><stop offset=\"1\" stop-color=\"#8a9c88\"/></linearGradient><linearGradient id=\"key\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f7d77e\"/><stop offset=\".8\" stop-color=\"#d9aa4e\"/><stop offset=\"1\" stop-color=\"#b8873a\"/></linearGradient><linearGradient id=\"earth\" x1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#8caeb0\"/><stop offset=\".5\" stop-color=\"#3a7285\"/><stop offset=\"1\" stop-color=\"#163d4b\"/></linearGradient><radialGradient id=\"halo\"><stop stop-color=\"#dce1ba\" stop-opacity=\".45\"/><stop offset=\"1\" stop-color=\"#dce1ba\" stop-opacity=\"0\"/></radialGradient><pattern id=\"finePrint\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0 1 1\" stroke=\"#402d1e\" opacity=\".11\" stroke-width=\".8\"/></pattern><filter id=\"objectShadow\" x=\"-25%\" y=\"-30%\" width=\"160%\" height=\"180%\"><feDropShadow dx=\"4\" dy=\"7\" stdDeviation=\"5\" flood-color=\"#101f19\" flood-opacity=\".5\"/></filter><filter id=\"paperShadow\" x=\"-15%\" y=\"-15%\" width=\"140%\" height=\"150%\"><feDropShadow dx=\"2\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#1d2f24\" flood-opacity=\".45\"/></filter><clipPath id=\"sphereClip\"><circle cx=\"0\" cy=\"0\" r=\"50\"/></clipPath></defs><g font-family=\"Microsoft YaHei,Arial,sans-serif\"><rect x=\"0\" y=\"0\" width=\"1920\" height=\"1080\" rx=\"0\" fill=\"url(#deepSpace)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"157\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"378\" cy=\"194\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"449\" cy=\"231\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"520\" cy=\"268\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"591\" cy=\"305\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"662\" cy=\"342\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"733\" cy=\"29\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"804\" cy=\"66\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"875\" cy=\"103\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"946\" cy=\"140\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"1017\" cy=\"177\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"1088\" cy=\"214\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"1159\" cy=\"251\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"1230\" cy=\"288\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"1301\" cy=\"325\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"1372\" cy=\"12\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"1443\" cy=\"49\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"1514\" cy=\"86\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"1585\" cy=\"123\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"1656\" cy=\"160\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"1727\" cy=\"197\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"1798\" cy=\"234\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"1869\" cy=\"271\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"308\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"345\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"69\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"106\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"375\" cy=\"143\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"446\" cy=\"180\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"1267.2\" cy=\"294\" r=\"560\" fill=\"url(#halo)\" /><g transform=\"translate(520 184) scale(1.2)\" ><circle cx=\"0\" cy=\"0\" r=\"53\" fill=\"#8db4b5\" opacity=\".13\"/><circle cx=\"0\" cy=\"0\" r=\"50\" fill=\"url(#earth)\" /><g clip-path=\"url(#sphereClip)\"><path d=\"m-43-32 22 1 9 15 22 1 7 13-18 4-8 21-16 5-16-17-3-25-9-4m89 2-22 3-3 14 12 12-1 26 18 17 16-25-2-32Z\" fill=\"#a2b79a\"/><path d=\"M-61-24Q-8-45 49-13M-52-7Q-9-28 53-1M-51 15Q8-2 58 29M-27 40Q4 28 38 40\" stroke=\"#f0ead1\" stroke-width=\"5\" opacity=\".67\" fill=\"none\"/><path d=\"M5-51Q70 2 13 54H63V-54Z\" fill=\"#071f2c\" opacity=\".72\"/></g></g><path d=\"M-40 424Q403.2 224 979.2 349Q1420.8 289 1960 379V1080H-40Z\" fill=\"url(#regolith)\"/><path d=\"M0 436Q384 294 960 392Q1478.4 312 1920 430\" stroke=\"#e9d8b4\" stroke-width=\"4\" fill=\"none\" opacity=\".55\"/><path d=\"M0 515Q384 403 1017.6 549T1920 534V1080H0Z\" fill=\"#b4aa91\" opacity=\".62\"/><ellipse cx=\"93\" cy=\"761.6\" rx=\"103\" ry=\"20\" fill=\"#9b947d\" opacity=\".7\"/><path d=\"M-10 758Q93 718 196 758\" stroke=\"#e8d8b8\" stroke-width=\"4.8\" fill=\"none\" opacity=\".7\"/><ellipse cx=\"93\" cy=\"762\" rx=\"78.28\" ry=\"12.4\" fill=\"#b0a48b\"/><ellipse cx=\"1766\" cy=\"697.86\" rx=\"146\" ry=\"27\" fill=\"#9b947d\" opacity=\".7\"/><path d=\"M1620 693Q1766 639 1912 693\" stroke=\"#e8d8b8\" stroke-width=\"6.4799999999999995\" fill=\"none\" opacity=\".7\"/><ellipse cx=\"1766\" cy=\"698.4\" rx=\"110.96000000000001\" ry=\"16.74\" fill=\"#b0a48b\"/><ellipse cx=\"987\" cy=\"769.4\" rx=\"172\" ry=\"30\" fill=\"#9b947d\" opacity=\".7\"/><path d=\"M815 764Q987 704 1159 764\" stroke=\"#e8d8b8\" stroke-width=\"7.199999999999999\" fill=\"none\" opacity=\".7\"/><ellipse cx=\"987\" cy=\"770\" rx=\"130.72\" ry=\"18.6\" fill=\"#b0a48b\"/><ellipse cx=\"1514\" cy=\"441.52\" rx=\"74\" ry=\"14\" fill=\"#9b947d\" opacity=\".7\"/><path d=\"M1440 439Q1514 411 1588 439\" stroke=\"#e8d8b8\" stroke-width=\"3.36\" fill=\"none\" opacity=\".7\"/><ellipse cx=\"1514\" cy=\"441.8\" rx=\"56.24\" ry=\"8.68\" fill=\"#b0a48b\"/><ellipse cx=\"489\" cy=\"547.6\" rx=\"102\" ry=\"20\" fill=\"#9b947d\" opacity=\".7\"/><path d=\"M387 544Q489 504 591 544\" stroke=\"#e8d8b8\" stroke-width=\"4.8\" fill=\"none\" opacity=\".7\"/><ellipse cx=\"489\" cy=\"548\" rx=\"77.52\" ry=\"12.4\" fill=\"#b0a48b\"/><ellipse cx=\"1460\" cy=\"853.88\" rx=\"91\" ry=\"16\" fill=\"#9b947d\" opacity=\".7\"/><path d=\"M1369 851Q1460 819 1551 851\" stroke=\"#e8d8b8\" stroke-width=\"3.84\" fill=\"none\" opacity=\".7\"/><ellipse cx=\"1460\" cy=\"854.2\" rx=\"69.16\" ry=\"9.92\" fill=\"#b0a48b\"/><path d=\"m71 414 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m208 487 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m345 560 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m482 633 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m619 706 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m756 779 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m893 852 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1030 925 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1167 998 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1304 1071 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1441 483 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1578 556 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1715 629 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1852 702 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m69 775 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m206 848 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m343 921 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m480 994 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m617 1067 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m754 479 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m891 552 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1028 625 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1165 698 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1302 771 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1439 844 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1576 917 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1713 990 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1850 1063 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m67 475 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m204 548 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m341 621 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m478 694 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m615 767 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m752 840 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m889 913 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1026 986 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1163 1059 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1300 471 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1437 544 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1574 617 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1711 690 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1848 763 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m65 836 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m202 909 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m339 982 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m476 1055 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m613 467 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m750 540 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m887 613 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1024 686 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1161 759 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1298 832 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1435 905 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1572 978 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1709 1051 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1846 463 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m63 536 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m200 609 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m337 682 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m474 755 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m611 828 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m748 901 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m885 974 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1022 1047 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1159 459 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1296 532 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1433 605 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1570 678 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1707 751 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1844 824 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m61 897 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m198 970 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m335 1043 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m472 455 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m609 528 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m746 601 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m883 674 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1020 747 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1157 820 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1294 893 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1431 966 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1568 1039 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1705 451 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1842 524 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m59 597 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m196 670 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m333 743 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m470 816 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m607 889 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m744 962 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m881 1035 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1018 447 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1155 520 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1292 593 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1429 666 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1566 739 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1703 812 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1840 885 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m57 958 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m194 1031 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m331 443 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m468 516 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m605 589 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m742 662 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m879 735 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1016 808 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1153 881 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1290 954 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1427 1027 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1564 439 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1701 512 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1838 585 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m55 658 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m192 731 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m329 804 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m466 877 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m603 950 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m740 1023 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m877 435 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1014 508 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1151 581 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1288 654 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1425 727 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1562 800 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1699 873 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1836 946 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m53 1019 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m190 431 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m327 504 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m464 577 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m601 650 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m738 723 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m875 796 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1012 869 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1149 942 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1286 1015 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1423 427 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1560 500 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1697 573 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1834 646 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m51 719 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m188 792 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m325 865 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m462 938 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m599 1011 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m736 423 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m873 496 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1010 569 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1147 642 3 -1 2 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1284 715 4 -2 3 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1421 788 2 -3 4 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1558 861 3 -4 5 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1695 934 4 -1 2 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m1832 1007 2 -2 3 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m49 419 3 -3 4 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m186 492 4 -4 5 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m323 565 2 -1 2 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m460 638 3 -2 3 2\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m597 711 4 -3 4 3\" stroke=\"#857d69\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><path d=\"m734 784 2 -4 5 1\" stroke=\"#e0ceb0\" opacity=\".4\" stroke-width=\"1\" fill=\"none\"/><g opacity=\".45\"><path d=\"M918 304V270a81 66 0 0 1 162 0V305Z\" fill=\"url(#glass)\" stroke=\"#a5bca8\" stroke-width=\"2\"/><path d=\"M918 270H1080M999 204V304M946 219Q930 260 948 304M1052 219Q1070 260 1051 304\" stroke=\"#bac9ac\" fill=\"none\"/><path d=\"M1080 296H1148V273H1222V301H1290V255H1340V300H1440\" fill=\"#a3ab97\" stroke=\"#4e695e\" stroke-width=\"2\"/><path d=\"M1202 273V206M1192 224H1215M1320 255V176\" stroke=\"#a8bba2\" stroke-width=\"5\"/><path d=\"m1302 199 33-29 33 27Q1334 218 1302 199Z\" fill=\"#c5d2bc\"/></g><rect x=\"0\" y=\"329\" width=\"1920\" height=\"751\" rx=\"0\" fill=\"url(#finePrint)\" /></g></svg>",
	"./art/trouble.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M30 157Q76 106 117 148L183 144 230 177H30Z\" fill=\"#8b725d\"/><path d=\"m75 143 37-34 39 34 30-25 44 48\" fill=\"#bbb19a\" stroke=\"#5b625b\" stroke-width=\"2\"/><path d=\"M58 147H175V124H148L127 95 104 103V139H58Z\" fill=\"#c7a448\" stroke=\"#344a43\" stroke-width=\"3\"/><path d=\"m128 102 43-61 61 4-3 10-52-2-31 55Z\" fill=\"#dfbf5b\" stroke=\"#344a43\" stroke-width=\"3\"/><path d=\"m225 43 31 67-16 22-9-9 12-14-27-58\" fill=\"#caa746\" stroke=\"#344a43\" stroke-width=\"3\"/><rect x=\"104\" y=\"105\" width=\"23\" height=\"25\" rx=\"2\" fill=\"#71918b\" stroke=\"#344a43\" stroke-width=\"2\"/><rect x=\"54\" y=\"144\" width=\"128\" height=\"20\" rx=\"9\" fill=\"#354f4b\" /><circle cx=\"65\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"80\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"95\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"110\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"125\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"140\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"155\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><circle cx=\"170\" cy=\"154\" r=\"5\" fill=\"#8d9c86\" stroke=\"#1c3939\" stroke-width=\"2\"/><g transform=\"translate(264 116) scale(0.62)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><g transform=\"translate(38 153) scale(0.8)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/twist.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M123 154 141 88 160 88 182 154Z\" fill=\"url(#__mcb__metal)\" stroke=\"#345b5b\" stroke-width=\"3\"/><path d=\"m144 100-46-25 24-28 53 29Z\" fill=\"#9ab9b3\" stroke=\"#345b5b\" stroke-width=\"3\"/><path d=\"M53 32Q65 106 137 92L153 50Z\" fill=\"url(#__mcb__metal)\" stroke=\"#d3e3d0\" stroke-width=\"3\"/><path d=\"m54 33 77 16-45-43\" fill=\"none\" stroke=\"#b1cfca\" stroke-width=\"2\"/><path d=\"m86 6 3 49 44-6\" stroke=\"#c5d7c4\" stroke-width=\"2\" fill=\"none\"/><rect x=\"183\" y=\"119\" width=\"67\" height=\"37\" rx=\"12\" fill=\"#e0d6b5\" stroke=\"#49706a\" stroke-width=\"2\"/><rect x=\"199\" y=\"126\" width=\"28\" height=\"16\" rx=\"5\" fill=\"#397a7e\" /><g transform=\"translate(266 125) scale(0.55)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#d6dfcf\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#d6dfcf\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>",
	"./art/work.svg": "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 320 180\"><defs><linearGradient id=\"__mcb__space\" x2=\".4\" y2=\"1\"><stop stop-color=\"#10282c\"/><stop offset=\"1\" stop-color=\"#354954\"/></linearGradient><linearGradient id=\"__mcb__paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffdf4\"/><stop offset=\"1\" stop-color=\"#e8e3d1\"/></linearGradient><linearGradient id=\"__mcb__moon\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b9bbc0\"/><stop offset=\"1\" stop-color=\"#ddd1b9\"/></linearGradient><linearGradient id=\"__mcb__metal\" x1=\"0\" x2=\"1\"><stop stop-color=\"#425d5c\"/><stop offset=\".3\" stop-color=\"#d9e5d7\"/><stop offset=\".53\" stop-color=\"#8ba6a1\"/><stop offset=\".8\" stop-color=\"#d4e1d4\"/><stop offset=\"1\" stop-color=\"#608480\"/></linearGradient><linearGradient id=\"__mcb__glass\" x1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#d0e4bc\"/><stop offset=\".44\" stop-color=\"#719b8b\"/><stop offset=\"1\" stop-color=\"#234a4c\"/></linearGradient><linearGradient id=\"__mcb__pinkMetal\" x2=\"1\" y2=\".4\"><stop stop-color=\"#e9aaaf\"/><stop offset=\".35\" stop-color=\"#cf677d\"/><stop offset=\".65\" stop-color=\"#e6b5bc\"/><stop offset=\"1\" stop-color=\"#733b59\"/></linearGradient><linearGradient id=\"__mcb__ribbon\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f3b05a\"/><stop offset=\"1\" stop-color=\"#f4cf76\"/></linearGradient><pattern id=\"__mcb__dots\" width=\"9\" height=\"9\" patternUnits=\"userSpaceOnUse\"><circle cx=\"2\" cy=\"2\" r=\".6\" fill=\"#25443e\" opacity=\".16\"/></pattern><pattern id=\"__mcb__stripes\" width=\"12\" height=\"12\" patternTransform=\"rotate(45)\" patternUnits=\"userSpaceOnUse\"><rect width=\"6\" height=\"12\" fill=\"#8c3c56\"/><rect x=\"6\" width=\"6\" height=\"12\" fill=\"#f2c0c7\"/></pattern><filter id=\"__mcb__shadow\" x=\"-15%\" y=\"-10%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"1\" dy=\"3\" stdDeviation=\"2\" flood-color=\"#193d37\" flood-opacity=\".22\"/></filter><filter id=\"__mcb__lift\" x=\"-20%\" y=\"-20%\" width=\"150%\" height=\"160%\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"5\" flood-color=\"#164c53\" flood-opacity=\".25\"/></filter><filter id=\"__mcb__grain\" x=\"0\" y=\"0\" width=\"100%\" height=\"100%\"><feTurbulence baseFrequency=\".6\" numOctaves=\"3\" stitchTiles=\"stitch\"/><feColorMatrix type=\"saturate\" values=\"0\"/><feComponentTransfer><feFuncA type=\"linear\" slope=\".09\"/></feComponentTransfer><feBlend in=\"SourceGraphic\" mode=\"multiply\"/></filter><clipPath id=\"__mcb__sceneClip\"><rect width=\"320\" height=\"180\" rx=\"12\"/></clipPath></defs><g clip-path=\"url(#__mcb__sceneClip)\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__space)\" /><circle cx=\"23\" cy=\"9\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"94\" cy=\"46\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"165\" cy=\"83\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"236\" cy=\"120\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"307\" cy=\"32\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"58\" cy=\"69\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"129\" cy=\"106\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"200\" cy=\"18\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"271\" cy=\"55\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"22\" cy=\"92\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"93\" cy=\"4\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"164\" cy=\"41\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"235\" cy=\"78\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"306\" cy=\"115\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"57\" cy=\"27\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"128\" cy=\"64\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"199\" cy=\"101\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"270\" cy=\"13\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"21\" cy=\"50\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"92\" cy=\"87\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"163\" cy=\"124\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"234\" cy=\"36\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"305\" cy=\"73\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"56\" cy=\"110\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"127\" cy=\"22\" r=\"1.2\" fill=\"#a7c6c7\" opacity=\"0.4\"/><circle cx=\"198\" cy=\"59\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"269\" cy=\"96\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.72\"/><circle cx=\"20\" cy=\"8\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.88\"/><circle cx=\"91\" cy=\"45\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"162\" cy=\"82\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.56\"/><circle cx=\"233\" cy=\"119\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.72\"/><circle cx=\"304\" cy=\"31\" r=\"0.6\" fill=\"#e1dcc2\" opacity=\"0.88\"/><circle cx=\"55\" cy=\"68\" r=\"1.2\" fill=\"#e1dcc2\" opacity=\"0.4\"/><circle cx=\"126\" cy=\"105\" r=\"0.6\" fill=\"#a7c6c7\" opacity=\"0.56\"/><circle cx=\"277\" cy=\"27\" r=\"15\" fill=\"#b3cabd\" /><path d=\"M273 13Q281 29 270 41A15 15 0 0 0 277 12Z\" fill=\"#577d7c\"/><path d=\"M0 133Q45 108 90 133Q157 90 220 121Q276 132 320 108V180H0Z\" fill=\"#787d7e\"/><path d=\"M0 159Q74 122 133 153Q220 127 320 153V180H0Z\" fill=\"url(#__mcb__moon)\"/><path d=\"M8 164Q83 140 120 164M220 159Q250 143 306 159\" stroke=\"#7d8581\" opacity=\".5\" fill=\"none\"/><ellipse cx=\"277\" cy=\"166\" rx=\"19\" ry=\"4\" fill=\"#919792\"/><ellipse cx=\"277\" cy=\"164\" rx=\"15\" ry=\"3\" fill=\"#babbb1\"/><path d=\"M0 150V45L141 4 320 38V161\" fill=\"#415854\" stroke=\"#88a299\" stroke-width=\"2\"/><path d=\"M15 150V53L139 18 303 48V152\" fill=\"#182f32\"/><path d=\"M26 151V52L139 18\" stroke=\"#7a9891\" stroke-width=\"3\"/><path d=\"M79 151V52L144 18\" stroke=\"#7a9891\" stroke-width=\"3\"/><path d=\"M132 151V52L149 18\" stroke=\"#7a9891\" stroke-width=\"3\"/><path d=\"M185 151V52L154 18\" stroke=\"#7a9891\" stroke-width=\"3\"/><path d=\"M238 151V52L159 18\" stroke=\"#7a9891\" stroke-width=\"3\"/><rect x=\"52\" y=\"93\" width=\"71\" height=\"37\" rx=\"4\" fill=\"#82998c\" /><g transform=\"translate(70 74) scale(1.2)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(91 88) scale(1.3)\" ><polygon points=\"2,6 12,1 23,6 23,20 12,24 2,20\" fill=\"#e5af64\" stroke=\"#9b733d\" stroke-width=\"1.1\"/><polygon points=\"2,6 12,11 23,6 12,1\" fill=\"#f6d28b\"/><polygon points=\"12,11 23,6 23,20 12,24\" fill=\"#b67b37\"/><path d=\"M12 11V24M7 3 18 8V13\" fill=\"none\" stroke=\"#e9bb71\" stroke-width=\"2\"/></g><g transform=\"translate(65 96) scale(0.85)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#adc6ae\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#adc6ae\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#adc6ae\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><path d=\"M158 153V105Q183 77 211 105V153Z\" fill=\"#e8b54b\" stroke=\"#344f45\" stroke-width=\"3\"/><circle cx=\"183\" cy=\"105\" r=\"18\" fill=\"#e9c776\" stroke=\"#2f4c47\" stroke-width=\"2\"/><rect x=\"169\" y=\"101\" width=\"29\" height=\"8\" rx=\"4\" fill=\"#274e4e\" /><circle cx=\"170\" cy=\"157\" r=\"12\" fill=\"#2f4743\" /><circle cx=\"204\" cy=\"157\" r=\"12\" fill=\"#2f4743\" /><path d=\"m158 116-23 8-2-13m78 7 28 8 10-17\" fill=\"none\" stroke=\"#94aea0\" stroke-width=\"7\"/><g transform=\"translate(249 111) scale(0.8)\" ><path d=\"M6 27 2 50 9 52 16 34M23 27 28 49 36 48 30 24\" stroke=\"#183e42\" stroke-width=\"3\" fill=\"#c6d4bc\"/><path d=\"M4 13Q16 7 30 14L28 33Q16 39 5 32Z\" fill=\"#c6d4bc\" stroke=\"#3a5b58\" stroke-width=\"2\"/><path d=\"m6 16-8 9-3-4 8-12M28 16 37 23 40 18 31 10\" fill=\"#c6d4bc\" stroke=\"#3a5b58\" stroke-width=\"3\"/><circle cx=\"17\" cy=\"4\" r=\"13\" fill=\"#d2dbca\" stroke=\"#38635e\" stroke-width=\"2\"/><path d=\"M6 2Q18-10 28 2V10Q15 16 6 7Z\" fill=\"#bc8b43\"/><path d=\"M9 0Q17-5 24-1\" stroke=\"#e9e2b5\" stroke-width=\"2\" fill=\"none\"/><rect x=\"9\" y=\"18\" width=\"12\" height=\"7\" rx=\"2\" fill=\"#719b8e\" /><circle cx=\"24\" cy=\"20\" r=\"2\" fill=\"#e4bb5e\" /></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"180\" rx=\"0\" fill=\"url(#__mcb__dots)\" /></g></svg>"
});
function X({ name: e, className: t = "" }) {
	let r = n().replaceAll(":", ""), i = Ae[`./art/${e}.svg`];
	return /* @__PURE__ */ d("span", {
		"aria-hidden": "true",
		className: `mcb-illustration ${t}`,
		dangerouslySetInnerHTML: { __html: i.replaceAll("__mcb__", `mcb${r}`) }
	});
}
function Z({ kind: e, size: t = 18 }) {
	return /* @__PURE__ */ d("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		fill: "none",
		"aria-hidden": "true",
		className: "mcb-resource-icon",
		children: e === "population" ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("circle", {
				cx: "12",
				cy: "12",
				r: "11",
				fill: "#dfe5c8",
				stroke: "#72918a",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "12",
				cy: "12",
				r: "8.5",
				fill: "#579185"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "12",
				cy: "10",
				r: "5",
				fill: "#e0af81"
			}),
			/* @__PURE__ */ d("path", {
				d: "M7 9Q7 2 15 6L18 10 14 9 12 7 8 10Z",
				fill: "#6b5944"
			}),
			/* @__PURE__ */ d("path", {
				d: "M5 20q1-8 7-6 6-2 7 6",
				fill: "#b3c4a2"
			})
		] }) : e === "money" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", {
			d: "m1 22 4-20h14l4 20Z",
			fill: "#243d34",
			stroke: "#c7bb8b"
		}), /* @__PURE__ */ d("path", {
			d: "m4 18 3-12h4l2 7 2-7h3l3 12h-4l-1-6-2 6h-4l-1-6-1 6Z",
			fill: "#eed568"
		})] }) : e === "food" ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", {
				d: "m12 0 12 12-12 12L0 12Z",
				fill: "#e3ce68",
				stroke: "#afad63"
			}),
			/* @__PURE__ */ d("path", {
				d: "M12 8C3 3 3 17 12 21 21 17 21 3 12 8Z",
				fill: "#9cb958",
				stroke: "#55723e"
			}),
			/* @__PURE__ */ d("path", {
				d: "M12 9V3q4-5 6 0-2 4-6 2",
				stroke: "#55723e"
			})
		] }) : /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", {
				d: "m2 6 10-5 10 5v13l-10 4-10-4Z",
				fill: "#d3a15c",
				stroke: "#96713f"
			}),
			/* @__PURE__ */ d("path", {
				d: "m2 6 10 5 10-5-10-5Z",
				fill: "#f2cf89"
			}),
			/* @__PURE__ */ d("path", {
				d: "m12 11 10-5v13l-10 4Z",
				fill: "#b9803e"
			}),
			/* @__PURE__ */ d("path", {
				d: "M12 11v12M7 3l10 5v5",
				stroke: "#edc47c",
				strokeWidth: "1.5"
			})
		] })
	});
}
function je({ id: e, robot: t = !1 }) {
	return /* @__PURE__ */ d(X, {
		name: t ? "robot" : `b${e}`,
		className: "mcb-art"
	});
}
function Me({ rings: e }) {
	return /* @__PURE__ */ d("svg", {
		width: "17",
		height: "17",
		viewBox: "0 0 24 24",
		fill: "none",
		"aria-hidden": "true",
		children: e ? /* @__PURE__ */ f("g", {
			stroke: "currentColor",
			strokeWidth: "1.8",
			children: [
				/* @__PURE__ */ d("circle", {
					cx: "12",
					cy: "7",
					r: "4.5"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "7",
					cy: "16",
					r: "4.5"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "17",
					cy: "16",
					r: "4.5"
				})
			]
		}) : /* @__PURE__ */ d("path", {
			d: "m12 1 2 7 6-5-3 8 6 1-7 3 4 6-7-4-2 6-2-7-7 4 4-7-6-2 7-2-4-6 7 4Z",
			fill: "currentColor"
		})
	});
}
function Ne({ card: e, boxes: t, compact: n = !1, selected: r = !1, available: i = !1, danger: o = !1, previewBoxes: s }) {
	let c = a(), l = _(e), ee = c("games.mooncolonybloodbath.playPrefix"), p = c("games.mooncolonybloodbath.lostPrefix"), m = c(l.textKey).split("\n");
	return /* @__PURE__ */ f("article", {
		className: `mcb-card${n ? " mcb-card--built" : ""}${r ? " mcb-card--selected" : ""}${i ? " mcb-card--available" : ""}${o && r ? " mcb-card--danger" : ""}`,
		"data-action": l.trigger ?? "passive",
		children: [
			/* @__PURE__ */ d("div", { className: "mcb-card-paper" }),
			/* @__PURE__ */ f("div", {
				className: "mcb-card-stats",
				children: [/* @__PURE__ */ f("span", {
					"aria-label": c("games.mooncolonybloodbath.cardCost", { n: l.cost }),
					children: [l.cost, /* @__PURE__ */ d(Z, {
						kind: "money",
						size: 16
					})]
				}), /* @__PURE__ */ f("span", {
					"aria-label": c("games.mooncolonybloodbath.cardPopulation", { n: l.population }),
					children: [l.population, /* @__PURE__ */ d(Z, {
						kind: "population",
						size: 17
					})]
				})]
			}),
			/* @__PURE__ */ d("h3", { children: c(l.nameKey) }),
			/* @__PURE__ */ d(je, { id: l.id }),
			(t !== void 0 || s !== void 0) && /* @__PURE__ */ f("div", {
				className: "mcb-boxes",
				children: [t !== void 0 && t > 0 && /* @__PURE__ */ f("span", {
					"aria-label": `${c("games.mooncolonybloodbath.boxes")} ${t}`,
					children: [/* @__PURE__ */ d(Z, {
						kind: "boxes",
						size: 20
					}), /* @__PURE__ */ d("b", { children: t })]
				}), s !== void 0 && /* @__PURE__ */ f("span", {
					className: "mcb-box-preview",
					children: [
						/* @__PURE__ */ d(Z, {
							kind: "boxes",
							size: 18
						}),
						t,
						" → ",
						s
					]
				})]
			}),
			/* @__PURE__ */ d("div", {
				className: "mcb-card-abilities",
				children: m.map((e, t) => {
					let n = e.match(/^([^:：]{1,24}[:：])/u);
					return /* @__PURE__ */ d("p", {
						className: e.startsWith(p) ? "mcb-lost" : e.startsWith(ee) ? "mcb-play" : "",
						children: n ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("strong", { children: n[1] }), e.slice(n[0].length)] }) : e
					}, t);
				})
			}),
			/* @__PURE__ */ d("footer", { children: l.symbol && /* @__PURE__ */ d("span", {
				role: "img",
				"aria-label": c(l.symbol === "rings" ? "games.mooncolonybloodbath.rings" : "games.mooncolonybloodbath.star"),
				title: c(l.symbol === "rings" ? "games.mooncolonybloodbath.rings" : "games.mooncolonybloodbath.star"),
				children: /* @__PURE__ */ d(Me, { rings: l.symbol === "rings" })
			}) }),
			(r || i) && /* @__PURE__ */ d("span", {
				className: "mcb-card-mark",
				"aria-hidden": "true",
				children: r ? "✓" : "+"
			})
		]
	});
}
function Pe(e) {
	let t = v[e.kind];
	return t[e.kind === "work" || e.kind === "trouble" ? 0 : e.id] ?? t[0];
}
function Fe({ card: e, owner: t }) {
	let n = a(), r = Pe(e);
	return /* @__PURE__ */ f("article", {
		className: "mcb-progress",
		"data-kind": e.kind,
		children: [
			t && /* @__PURE__ */ d("span", {
				className: "mcb-progress-owner",
				children: t
			}),
			/* @__PURE__ */ d("h2", { children: n(r.nameKey) }),
			/* @__PURE__ */ d(X, {
				name: e.kind,
				className: "mcb-progress-art"
			}),
			/* @__PURE__ */ d("div", {
				className: "mcb-progress-text",
				children: n(r.textKey).split("\n").map((e, t) => /* @__PURE__ */ d("p", { children: e }, t))
			})
		]
	});
}
//#endregion
//#region src/games/mooncolonybloodbath/i18n-keys.ts
var Q = {
	b0: "games.mooncolonybloodbath.b0",
	b0Text: "games.mooncolonybloodbath.b0Text",
	b1: "games.mooncolonybloodbath.b1",
	b1Text: "games.mooncolonybloodbath.b1Text",
	b2: "games.mooncolonybloodbath.b2",
	b2Text: "games.mooncolonybloodbath.b2Text",
	b3: "games.mooncolonybloodbath.b3",
	b3Text: "games.mooncolonybloodbath.b3Text",
	b4: "games.mooncolonybloodbath.b4",
	b4Text: "games.mooncolonybloodbath.b4Text",
	b5: "games.mooncolonybloodbath.b5",
	b5Text: "games.mooncolonybloodbath.b5Text",
	b6: "games.mooncolonybloodbath.b6",
	b6Text: "games.mooncolonybloodbath.b6Text",
	b7: "games.mooncolonybloodbath.b7",
	b7Text: "games.mooncolonybloodbath.b7Text",
	b8: "games.mooncolonybloodbath.b8",
	b8Text: "games.mooncolonybloodbath.b8Text",
	b9: "games.mooncolonybloodbath.b9",
	b9Text: "games.mooncolonybloodbath.b9Text",
	b10: "games.mooncolonybloodbath.b10",
	b10Text: "games.mooncolonybloodbath.b10Text",
	b11: "games.mooncolonybloodbath.b11",
	b11Text: "games.mooncolonybloodbath.b11Text",
	b12: "games.mooncolonybloodbath.b12",
	b12Text: "games.mooncolonybloodbath.b12Text",
	b13: "games.mooncolonybloodbath.b13",
	b13Text: "games.mooncolonybloodbath.b13Text",
	b14: "games.mooncolonybloodbath.b14",
	b14Text: "games.mooncolonybloodbath.b14Text",
	b15: "games.mooncolonybloodbath.b15",
	b15Text: "games.mooncolonybloodbath.b15Text",
	b16: "games.mooncolonybloodbath.b16",
	b16Text: "games.mooncolonybloodbath.b16Text",
	b17: "games.mooncolonybloodbath.b17",
	b17Text: "games.mooncolonybloodbath.b17Text",
	b18: "games.mooncolonybloodbath.b18",
	b18Text: "games.mooncolonybloodbath.b18Text",
	b19: "games.mooncolonybloodbath.b19",
	b19Text: "games.mooncolonybloodbath.b19Text",
	b20: "games.mooncolonybloodbath.b20",
	b20Text: "games.mooncolonybloodbath.b20Text",
	b21: "games.mooncolonybloodbath.b21",
	b21Text: "games.mooncolonybloodbath.b21Text",
	b22: "games.mooncolonybloodbath.b22",
	b22Text: "games.mooncolonybloodbath.b22Text",
	b23: "games.mooncolonybloodbath.b23",
	b23Text: "games.mooncolonybloodbath.b23Text",
	b24: "games.mooncolonybloodbath.b24",
	b24Text: "games.mooncolonybloodbath.b24Text",
	b25: "games.mooncolonybloodbath.b25",
	b25Text: "games.mooncolonybloodbath.b25Text",
	b26: "games.mooncolonybloodbath.b26",
	b26Text: "games.mooncolonybloodbath.b26Text",
	b27: "games.mooncolonybloodbath.b27",
	b27Text: "games.mooncolonybloodbath.b27Text",
	b28: "games.mooncolonybloodbath.b28",
	b28Text: "games.mooncolonybloodbath.b28Text",
	b29: "games.mooncolonybloodbath.b29",
	b29Text: "games.mooncolonybloodbath.b29Text",
	b30: "games.mooncolonybloodbath.b30",
	b30Text: "games.mooncolonybloodbath.b30Text",
	b31: "games.mooncolonybloodbath.b31",
	b31Text: "games.mooncolonybloodbath.b31Text",
	b32: "games.mooncolonybloodbath.b32",
	b32Text: "games.mooncolonybloodbath.b32Text",
	b33: "games.mooncolonybloodbath.b33",
	b33Text: "games.mooncolonybloodbath.b33Text",
	b34: "games.mooncolonybloodbath.b34",
	b34Text: "games.mooncolonybloodbath.b34Text",
	b35: "games.mooncolonybloodbath.b35",
	b35Text: "games.mooncolonybloodbath.b35Text",
	b36: "games.mooncolonybloodbath.b36",
	b36Text: "games.mooncolonybloodbath.b36Text",
	b37: "games.mooncolonybloodbath.b37",
	b37Text: "games.mooncolonybloodbath.b37Text",
	b38: "games.mooncolonybloodbath.b38",
	b38Text: "games.mooncolonybloodbath.b38Text",
	b39: "games.mooncolonybloodbath.b39",
	b39Text: "games.mooncolonybloodbath.b39Text",
	b40: "games.mooncolonybloodbath.b40",
	b40Text: "games.mooncolonybloodbath.b40Text",
	b41: "games.mooncolonybloodbath.b41",
	b41Text: "games.mooncolonybloodbath.b41Text",
	b42: "games.mooncolonybloodbath.b42",
	b42Text: "games.mooncolonybloodbath.b42Text",
	b43: "games.mooncolonybloodbath.b43",
	b43Text: "games.mooncolonybloodbath.b43Text",
	b44: "games.mooncolonybloodbath.b44",
	b44Text: "games.mooncolonybloodbath.b44Text",
	development0: "games.mooncolonybloodbath.development0",
	development0Text: "games.mooncolonybloodbath.development0Text",
	development1: "games.mooncolonybloodbath.development1",
	development1Text: "games.mooncolonybloodbath.development1Text",
	development2: "games.mooncolonybloodbath.development2",
	development2Text: "games.mooncolonybloodbath.development2Text",
	development3: "games.mooncolonybloodbath.development3",
	development3Text: "games.mooncolonybloodbath.development3Text",
	development4: "games.mooncolonybloodbath.development4",
	development4Text: "games.mooncolonybloodbath.development4Text",
	development5: "games.mooncolonybloodbath.development5",
	development5Text: "games.mooncolonybloodbath.development5Text",
	development6: "games.mooncolonybloodbath.development6",
	development6Text: "games.mooncolonybloodbath.development6Text",
	development7: "games.mooncolonybloodbath.development7",
	development7Text: "games.mooncolonybloodbath.development7Text",
	development8: "games.mooncolonybloodbath.development8",
	development8Text: "games.mooncolonybloodbath.development8Text",
	development9: "games.mooncolonybloodbath.development9",
	development9Text: "games.mooncolonybloodbath.development9Text",
	event0: "games.mooncolonybloodbath.event0",
	event0Text: "games.mooncolonybloodbath.event0Text",
	event1: "games.mooncolonybloodbath.event1",
	event1Text: "games.mooncolonybloodbath.event1Text",
	event2: "games.mooncolonybloodbath.event2",
	event2Text: "games.mooncolonybloodbath.event2Text",
	event3: "games.mooncolonybloodbath.event3",
	event3Text: "games.mooncolonybloodbath.event3Text",
	event4: "games.mooncolonybloodbath.event4",
	event4Text: "games.mooncolonybloodbath.event4Text",
	event5: "games.mooncolonybloodbath.event5",
	event5Text: "games.mooncolonybloodbath.event5Text",
	event6: "games.mooncolonybloodbath.event6",
	event6Text: "games.mooncolonybloodbath.event6Text",
	event7: "games.mooncolonybloodbath.event7",
	event7Text: "games.mooncolonybloodbath.event7Text",
	event8: "games.mooncolonybloodbath.event8",
	event8Text: "games.mooncolonybloodbath.event8Text",
	event9: "games.mooncolonybloodbath.event9",
	event9Text: "games.mooncolonybloodbath.event9Text",
	event10: "games.mooncolonybloodbath.event10",
	event10Text: "games.mooncolonybloodbath.event10Text",
	event11: "games.mooncolonybloodbath.event11",
	event11Text: "games.mooncolonybloodbath.event11Text",
	event12: "games.mooncolonybloodbath.event12",
	event12Text: "games.mooncolonybloodbath.event12Text",
	robot0: "games.mooncolonybloodbath.robot0",
	robot0Text: "games.mooncolonybloodbath.robot0Text",
	robot1: "games.mooncolonybloodbath.robot1",
	robot1Text: "games.mooncolonybloodbath.robot1Text",
	robot2: "games.mooncolonybloodbath.robot2",
	robot2Text: "games.mooncolonybloodbath.robot2Text",
	robot3: "games.mooncolonybloodbath.robot3",
	robot3Text: "games.mooncolonybloodbath.robot3Text",
	robot4: "games.mooncolonybloodbath.robot4",
	robot4Text: "games.mooncolonybloodbath.robot4Text",
	robot5: "games.mooncolonybloodbath.robot5",
	robot5Text: "games.mooncolonybloodbath.robot5Text",
	robot6: "games.mooncolonybloodbath.robot6",
	robot6Text: "games.mooncolonybloodbath.robot6Text",
	robot7: "games.mooncolonybloodbath.robot7",
	robot7Text: "games.mooncolonybloodbath.robot7Text",
	robot8: "games.mooncolonybloodbath.robot8",
	robot8Text: "games.mooncolonybloodbath.robot8Text",
	robot9: "games.mooncolonybloodbath.robot9",
	robot9Text: "games.mooncolonybloodbath.robot9Text",
	robot10: "games.mooncolonybloodbath.robot10",
	robot10Text: "games.mooncolonybloodbath.robot10Text",
	robot11: "games.mooncolonybloodbath.robot11",
	robot11Text: "games.mooncolonybloodbath.robot11Text",
	robot12: "games.mooncolonybloodbath.robot12",
	robot12Text: "games.mooncolonybloodbath.robot12Text",
	robot13: "games.mooncolonybloodbath.robot13",
	robot13Text: "games.mooncolonybloodbath.robot13Text",
	robot14: "games.mooncolonybloodbath.robot14",
	robot14Text: "games.mooncolonybloodbath.robot14Text",
	robot15: "games.mooncolonybloodbath.robot15",
	robot15Text: "games.mooncolonybloodbath.robot15Text",
	robot16: "games.mooncolonybloodbath.robot16",
	robot16Text: "games.mooncolonybloodbath.robot16Text",
	robot17: "games.mooncolonybloodbath.robot17",
	robot17Text: "games.mooncolonybloodbath.robot17Text",
	robot18: "games.mooncolonybloodbath.robot18",
	robot18Text: "games.mooncolonybloodbath.robot18Text",
	robot19: "games.mooncolonybloodbath.robot19",
	robot19Text: "games.mooncolonybloodbath.robot19Text",
	twist0: "games.mooncolonybloodbath.twist0",
	twist0Text: "games.mooncolonybloodbath.twist0Text",
	twist1: "games.mooncolonybloodbath.twist1",
	twist1Text: "games.mooncolonybloodbath.twist1Text",
	twist2: "games.mooncolonybloodbath.twist2",
	twist2Text: "games.mooncolonybloodbath.twist2Text",
	twist3: "games.mooncolonybloodbath.twist3",
	twist3Text: "games.mooncolonybloodbath.twist3Text",
	twist4: "games.mooncolonybloodbath.twist4",
	twist4Text: "games.mooncolonybloodbath.twist4Text",
	twist5: "games.mooncolonybloodbath.twist5",
	twist5Text: "games.mooncolonybloodbath.twist5Text",
	twist6: "games.mooncolonybloodbath.twist6",
	twist6Text: "games.mooncolonybloodbath.twist6Text",
	twist7: "games.mooncolonybloodbath.twist7",
	twist7Text: "games.mooncolonybloodbath.twist7Text",
	twist8: "games.mooncolonybloodbath.twist8",
	twist8Text: "games.mooncolonybloodbath.twist8Text",
	twist9: "games.mooncolonybloodbath.twist9",
	twist9Text: "games.mooncolonybloodbath.twist9Text",
	twist10: "games.mooncolonybloodbath.twist10",
	twist10Text: "games.mooncolonybloodbath.twist10Text",
	twist11: "games.mooncolonybloodbath.twist11",
	twist11Text: "games.mooncolonybloodbath.twist11Text",
	twist12: "games.mooncolonybloodbath.twist12",
	twist12Text: "games.mooncolonybloodbath.twist12Text",
	twist13: "games.mooncolonybloodbath.twist13",
	twist13Text: "games.mooncolonybloodbath.twist13Text",
	twist14: "games.mooncolonybloodbath.twist14",
	twist14Text: "games.mooncolonybloodbath.twist14Text",
	twist15: "games.mooncolonybloodbath.twist15",
	twist15Text: "games.mooncolonybloodbath.twist15Text",
	twist16: "games.mooncolonybloodbath.twist16",
	twist16Text: "games.mooncolonybloodbath.twist16Text",
	twist17: "games.mooncolonybloodbath.twist17",
	twist17Text: "games.mooncolonybloodbath.twist17Text",
	twist18: "games.mooncolonybloodbath.twist18",
	twist18Text: "games.mooncolonybloodbath.twist18Text",
	twist19: "games.mooncolonybloodbath.twist19",
	twist19Text: "games.mooncolonybloodbath.twist19Text",
	twist20: "games.mooncolonybloodbath.twist20",
	twist20Text: "games.mooncolonybloodbath.twist20Text",
	twist21: "games.mooncolonybloodbath.twist21",
	twist21Text: "games.mooncolonybloodbath.twist21Text",
	twist22: "games.mooncolonybloodbath.twist22",
	twist22Text: "games.mooncolonybloodbath.twist22Text",
	twist23: "games.mooncolonybloodbath.twist23",
	twist23Text: "games.mooncolonybloodbath.twist23Text",
	twist24: "games.mooncolonybloodbath.twist24",
	twist24Text: "games.mooncolonybloodbath.twist24Text",
	perk0: "games.mooncolonybloodbath.perk0",
	perk0Text: "games.mooncolonybloodbath.perk0Text",
	perk1: "games.mooncolonybloodbath.perk1",
	perk1Text: "games.mooncolonybloodbath.perk1Text",
	perk2: "games.mooncolonybloodbath.perk2",
	perk2Text: "games.mooncolonybloodbath.perk2Text",
	perk3: "games.mooncolonybloodbath.perk3",
	perk3Text: "games.mooncolonybloodbath.perk3Text",
	perk4: "games.mooncolonybloodbath.perk4",
	perk4Text: "games.mooncolonybloodbath.perk4Text",
	work0: "games.mooncolonybloodbath.work0",
	work0Text: "games.mooncolonybloodbath.work0Text",
	trouble0: "games.mooncolonybloodbath.trouble0",
	trouble0Text: "games.mooncolonybloodbath.trouble0Text",
	loneliness0: "games.mooncolonybloodbath.loneliness0",
	loneliness0Text: "games.mooncolonybloodbath.loneliness0Text",
	name: "games.mooncolonybloodbath.name",
	desc: "games.mooncolonybloodbath.desc",
	population: "games.mooncolonybloodbath.population",
	base: "games.mooncolonybloodbath.base",
	money: "games.mooncolonybloodbath.money",
	food: "games.mooncolonybloodbath.food",
	boxes: "games.mooncolonybloodbath.boxes",
	hand: "games.mooncolonybloodbath.hand",
	buildings: "games.mooncolonybloodbath.buildings",
	reserved: "games.mooncolonybloodbath.reserved",
	surveyed: "games.mooncolonybloodbath.surveyed",
	perks: "games.mooncolonybloodbath.perks",
	work: "games.mooncolonybloodbath.work",
	mine: "games.mooncolonybloodbath.mine",
	farm: "games.mooncolonybloodbath.farm",
	research: "games.mooncolonybloodbath.research",
	restock: "games.mooncolonybloodbath.restock",
	build: "games.mooncolonybloodbath.build",
	cycle: "games.mooncolonybloodbath.cycle",
	turn: "games.mooncolonybloodbath.turn",
	waiting: "games.mooncolonybloodbath.waiting",
	resolving: "games.mooncolonybloodbath.resolving",
	next: "games.mooncolonybloodbath.next",
	choose: "games.mooncolonybloodbath.choose",
	window: "games.mooncolonybloodbath.window",
	choosework: "games.mooncolonybloodbath.choosework",
	buildChoice: "games.mooncolonybloodbath.buildChoice",
	loss: "games.mooncolonybloodbath.loss",
	remove: "games.mooncolonybloodbath.remove",
	discard: "games.mooncolonybloodbath.discard",
	box: "games.mooncolonybloodbath.box",
	spendBox: "games.mooncolonybloodbath.spendBox",
	perk: "games.mooncolonybloodbath.perk",
	move: "games.mooncolonybloodbath.move",
	pass: "games.mooncolonybloodbath.pass",
	reserve: "games.mooncolonybloodbath.reserve",
	survey: "games.mooncolonybloodbath.survey",
	focus: "games.mooncolonybloodbath.focus",
	repeat: "games.mooncolonybloodbath.repeat",
	accident: "games.mooncolonybloodbath.accident",
	stack: "games.mooncolonybloodbath.stack",
	crater: "games.mooncolonybloodbath.crater",
	synthetic: "games.mooncolonybloodbath.synthetic",
	defund: "games.mooncolonybloodbath.defund",
	optional: "games.mooncolonybloodbath.optional",
	anyAction: "games.mooncolonybloodbath.anyAction",
	skip: "games.mooncolonybloodbath.skip",
	continue: "games.mooncolonybloodbath.continue",
	finish: "games.mooncolonybloodbath.finish",
	use: "games.mooncolonybloodbath.use",
	baseEffect: "games.mooncolonybloodbath.baseEffect",
	ability: "games.mooncolonybloodbath.ability",
	play: "games.mooncolonybloodbath.play",
	lost: "games.mooncolonybloodbath.lost",
	payment: "games.mooncolonybloodbath.payment",
	spend: "games.mooncolonybloodbath.spend",
	amount: "games.mooncolonybloodbath.amount",
	sell: "games.mooncolonybloodbath.sell",
	moveBox: "games.mooncolonybloodbath.moveBox",
	storage: "games.mooncolonybloodbath.storage",
	progressDeck: "games.mooncolonybloodbath.progressDeck",
	buildingDeck: "games.mooncolonybloodbath.buildingDeck",
	remaining: "games.mooncolonybloodbath.remaining",
	initial: "games.mooncolonybloodbath.initial",
	events: "games.mooncolonybloodbath.events",
	extra: "games.mooncolonybloodbath.extra",
	inspect: "games.mooncolonybloodbath.inspect",
	close: "games.mooncolonybloodbath.close",
	none: "games.mooncolonybloodbath.none",
	beginner: "games.mooncolonybloodbath.beginner",
	simple: "games.mooncolonybloodbath.simple",
	all: "games.mooncolonybloodbath.all",
	soloMode: "games.mooncolonybloodbath.soloMode",
	normal: "games.mooncolonybloodbath.normal",
	extended: "games.mooncolonybloodbath.extended",
	soloHint: "games.mooncolonybloodbath.soloHint",
	errAction: "games.mooncolonybloodbath.errAction",
	errTick: "games.mooncolonybloodbath.errTick",
	resultPopulation: "games.mooncolonybloodbath.resultPopulation",
	resultSolo: "games.mooncolonybloodbath.resultSolo",
	resultManual: "games.mooncolonybloodbath.resultManual",
	resultDeath: "games.mooncolonybloodbath.resultDeath",
	muted: "games.mooncolonybloodbath.muted",
	closed: "games.mooncolonybloodbath.closed",
	rings: "games.mooncolonybloodbath.rings",
	star: "games.mooncolonybloodbath.star",
	selected: "games.mooncolonybloodbath.selected",
	log: "games.mooncolonybloodbath.log",
	cost: "games.mooncolonybloodbath.cost",
	viewColony: "games.mooncolonybloodbath.viewColony",
	rules: "games.mooncolonybloodbath.rules",
	payFood: "games.mooncolonybloodbath.payFood",
	discardFor: "games.mooncolonybloodbath.discardFor",
	payPopulation: "games.mooncolonybloodbath.payPopulation",
	discardTop: "games.mooncolonybloodbath.discardTop",
	loseBuilding: "games.mooncolonybloodbath.loseBuilding",
	lossAmount: "games.mooncolonybloodbath.lossAmount",
	discardAmount: "games.mooncolonybloodbath.discardAmount",
	stackAmount: "games.mooncolonybloodbath.stackAmount"
};
//#endregion
//#region src/games/mooncolonybloodbath/choice-label.ts
function $(e, t) {
	return e.food ? e.money ? t("games.mooncolonybloodbath.payment", {
		money: e.money,
		food: e.food
	}) : t("games.mooncolonybloodbath.payFood", { n: e.food }) : t("games.mooncolonybloodbath.amount", { n: e.money ?? 0 });
}
function Ie(e, t, n, r = !0) {
	let i = n.private, a = n.public.current, o = i?.sourceCard == null ? void 0 : _(i.sourceCard).id, s = t(Q[e.text] ?? Q.choose, {
		n: e.n ?? 0,
		money: e.money ?? 0,
		food: e.food ?? 0
	});
	e.text === "payment" && (s = $(e, t)), e.action && e.card === void 0 && (s = t(e.text === "baseEffect" ? "games.mooncolonybloodbath.resolveAction" : "games.mooncolonybloodbath.chooseAction", { action: t(Q[e.action]) })), e.card === void 0 ? (i?.prompt === "defund" ? s = t(e.text === "money" ? "games.mooncolonybloodbath.loseHalfMoney" : "games.mooncolonybloodbath.loseHalfFood") : o === 0 && i?.prompt === "optional" ? (e.text === "food" && (s = t("games.mooncolonybloodbath.marketFood")), e.text === "discard" && (s = t("games.mooncolonybloodbath.marketDiscard"))) : i?.prompt === "choose" && (o === 16 || a?.kind === "twist" && a.id === 15) ? (e.text === "money" && (s = t("games.mooncolonybloodbath.gainMoney", { n: 2 })), e.text === "food" && (s = t("games.mooncolonybloodbath.gainFood", { n: 2 })), e.text === "boxes" && (s = t("games.mooncolonybloodbath.gainBox", { n: 1 })), e.text === "research" && (s = t("games.mooncolonybloodbath.drawBuilding", { n: 1 }))) : o === 11 && e.text === "population" && (s = t("games.mooncolonybloodbath.gainPopulation", { n: 3 })), e.text === "skip" && i?.prompt === "remove" && (a?.kind === "development" && a.id === 5 || a?.kind === "robot" && a.id === 6) && (s = t("games.mooncolonybloodbath.declineBuilding")), e.text === "finish" && i?.prompt === "stack" && (i.amount ?? 0) > 0 && (s = t("games.mooncolonybloodbath.finishLoss")), e.text === "finish" && i?.prompt === "crater" && (s = t("games.mooncolonybloodbath.finishExchange"))) : (e.text === "box" && (s = t("games.mooncolonybloodbath.placeBox")), e.text === "spendBox" && (s = t("games.mooncolonybloodbath.consumeBox")), e.text === "survey" && (s = t("games.mooncolonybloodbath.buryCard")), e.text === "reserve" && (s = t("games.mooncolonybloodbath.reserveCard")), e.text === "pass" && (s = t("games.mooncolonybloodbath.passCard")));
	let c = e.card === void 0 || !r ? "" : t(_(e.card).nameKey), l = e.target === void 0 ? "" : ` → ${t(_(e.target).nameKey)}`;
	return `${s}${c ? ` · ${c}` : ""}${l}`;
}
//#endregion
//#region src/games/mooncolonybloodbath/view-player.tsx
var Le = [
	"mine",
	"farm",
	"research",
	"restock",
	"build"
];
function Re(e) {
	let t = a(), n = e.public, p = e.private, [m, h] = i(e.myRid), [g, v] = i(null), [y, b] = i(null), [x, S] = i(null), [C, w] = i(!1), [T, E] = i(!1), D = r(null), O = (t) => e.members.find((e) => e.rid === t)?.name ?? t, k = n.players.find((e) => e.rid === m) ?? n.players.find((t) => t.rid === e.myRid) ?? n.players[0], A = n.players.find((t) => t.rid === e.myRid), j = p?.choices ?? [], M = (e, r = !0) => Ie(e, t, {
		public: n,
		private: p
	}, r), N = j.length > 0, P = x && p && x.revision === p.revision ? j.find((e) => e.id === x.id) : j.length === 1 ? j[0] : void 0, F = y && p && y.revision === p.revision ? y.kind : p?.prompt === "buildChoice" && p.reserved.length ? "reserved" : "hand", I = p?.[F] ?? [], L = p?.prompt === "loss" ? "lossAmount" : p?.prompt === "discard" ? "discardAmount" : p?.prompt === "stack" ? "stackAmount" : null, R = N ? L ? t(`games.mooncolonybloodbath.${L}`, { n: p?.amount ?? 0 }) : t(Q[p?.prompt] ?? Q.choose) : p?.selected !== null && p?.selected !== void 0 ? t("games.mooncolonybloodbath.selected") : n.phase === "progress" ? t("games.mooncolonybloodbath.next") : t("games.mooncolonybloodbath.waiting"), z = P?.text === "loseBuilding", B = P ? j.filter((e) => e.card === P.card && e.text === P.text && e.target === P.target) : [];
	function V(e) {
		p && (S({
			revision: p.revision,
			id: e.id
		}), w(!1));
	}
	function H() {
		p && P && e.send({
			type: "choose",
			revision: p.revision,
			choice: P.id
		});
	}
	function U(e, t) {
		let n = t ? j.filter((t) => t.card === e) : [];
		n.length ? V(n[0]) : v({ card: e });
	}
	function W(e) {
		let t = j.filter((t) => t.action === e);
		t.length === 1 ? V(t[0]) : e === "build" && p ? (b({
			revision: p.revision,
			kind: p.reserved.length ? "reserved" : "hand"
		}), D.current?.scrollIntoView({ block: "nearest" })) : w(!0);
	}
	let G = /* @__PURE__ */ f("div", {
		className: "mcb-action-tray",
		children: [
			/* @__PURE__ */ f("div", {
				className: "mcb-ticket",
				"aria-live": "polite",
				children: [/* @__PURE__ */ d("strong", { children: P ? P.card === void 0 ? M(P) : t(_(P.card).nameKey) : R }), P?.money === void 0 ? P?.card !== void 0 && /* @__PURE__ */ d("span", { children: M(P, !1) }) : /* @__PURE__ */ f("span", {
					className: "mcb-payment",
					"aria-label": $(P, t),
					children: [
						/* @__PURE__ */ d(Z, { kind: "money" }),
						P.money,
						!!P.food && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(Z, { kind: "food" }), P.food] }),
						B.length > 1 && /* @__PURE__ */ d("select", {
							"aria-label": t("games.mooncolonybloodbath.paymentMethod"),
							value: P.id,
							onChange: (e) => {
								let t = j.find((t) => t.id === e.target.value);
								t && V(t);
							},
							children: B.map((e) => /* @__PURE__ */ d("option", {
								value: e.id,
								children: $(e, t)
							}, e.id))
						})
					]
				})]
			}),
			/* @__PURE__ */ d("button", {
				type: "button",
				className: "mcb-alternatives",
				disabled: !N && !p?.storage.length,
				onClick: () => w(!0),
				"aria-label": t("games.mooncolonybloodbath.allChoices"),
				children: /* @__PURE__ */ d(l, { size: 22 })
			}),
			/* @__PURE__ */ d("button", {
				type: "button",
				className: `mcb-confirm${z ? " mcb-confirm--danger" : ""}`,
				disabled: !P,
				onClick: H,
				children: t(z ? "games.mooncolonybloodbath.loseBuilding" : "games.mooncolonybloodbath.confirm")
			})
		]
	});
	return /* @__PURE__ */ f("div", {
		className: "mcb-screen",
		children: [
			/* @__PURE__ */ d(X, {
				name: "table",
				className: "mcb-table-art"
			}),
			/* @__PURE__ */ d(ee, {
				adaptive: !0,
				className: "mcb-layout",
				scroll: !0,
				actionsHeight: "mcb-actions-height",
				actions: G,
				children: /* @__PURE__ */ f("div", {
					className: "mcb-page",
					children: [
						/* @__PURE__ */ f("header", {
							className: "mcb-masthead",
							children: [/* @__PURE__ */ f("h1", {
								"aria-label": t("games.mooncolonybloodbath.name"),
								children: [
									t("games.mooncolonybloodbath.titleMain"),
									" ",
									/* @__PURE__ */ d("em", { children: t("games.mooncolonybloodbath.titleSubtitle") })
								]
							}), /* @__PURE__ */ d("span", { children: t("games.mooncolonybloodbath.turn", { n: n.turn }) })]
						}),
						/* @__PURE__ */ d("nav", {
							className: "mcb-crew",
							"aria-label": t("games.mooncolonybloodbath.viewColony"),
							children: n.players.map((n, r) => /* @__PURE__ */ f("button", {
								type: "button",
								className: "mcb-crew-member",
								"data-me": n.rid === e.myRid,
								"data-observed": n.rid === k?.rid,
								"aria-pressed": n.rid === k?.rid,
								onClick: () => h(n.rid),
								"aria-label": `${O(n.rid)} · ${t("games.mooncolonybloodbath.population")} ${n.population} · ${t(n.ready ? "games.mooncolonybloodbath.ready" : "games.mooncolonybloodbath.pending")}`,
								children: [
									/* @__PURE__ */ d(X, { name: `crew${r}` }),
									/* @__PURE__ */ d("span", {
										className: "mcb-crew-name",
										children: O(n.rid)
									}),
									/* @__PURE__ */ d("b", { children: n.population }),
									/* @__PURE__ */ d("span", {
										className: "mcb-ready",
										"aria-hidden": "true",
										children: n.ready ? "✓" : "·"
									})
								]
							}, n.rid))
						}),
						/* @__PURE__ */ d("div", {
							className: "mcb-resources",
							children: [
								"population",
								"money",
								"food"
							].map((e) => /* @__PURE__ */ f("span", { children: [
								/* @__PURE__ */ d(Z, {
									kind: e,
									size: 32
								}),
								/* @__PURE__ */ d("b", { children: A?.[e] ?? 0 }),
								/* @__PURE__ */ d("small", { children: t(`games.mooncolonybloodbath.${e}`) })
							] }, e))
						}),
						/* @__PURE__ */ f("section", {
							className: "mcb-common",
							children: [
								/* @__PURE__ */ f("div", {
									className: "mcb-current",
									"data-kind": n.current?.kind ?? "work",
									children: [/* @__PURE__ */ d("button", {
										type: "button",
										className: "mcb-current-card",
										"aria-label": n.current ? t(Pe(n.current).nameKey) : t("games.mooncolonybloodbath.progressDeck"),
										onClick: () => n.current && v({ progress: n.current }),
										disabled: !n.current,
										children: n.current ? /* @__PURE__ */ d(Fe, {
											card: n.current,
											owner: n.current.owner ? O(n.current.owner) : void 0
										}) : /* @__PURE__ */ d("span", {
											className: "mcb-progress-placeholder",
											children: t("games.mooncolonybloodbath.name")
										})
									}), /* @__PURE__ */ f("button", {
										type: "button",
										className: "mcb-current-prompt",
										disabled: !N,
										onClick: () => w(!0),
										children: [R, /* @__PURE__ */ d(s, { size: 18 })]
									})]
								}),
								/* @__PURE__ */ f("div", {
									className: "mcb-piles",
									children: [/* @__PURE__ */ f("div", {
										className: "mcb-deck",
										children: [
											/* @__PURE__ */ d("span", { children: "☾" }),
											/* @__PURE__ */ d("b", { children: n.deckCount }),
											/* @__PURE__ */ d("small", { children: t("games.mooncolonybloodbath.progressDeck") })
										]
									}), /* @__PURE__ */ f("div", {
										className: "mcb-deck mcb-deck--building",
										children: [
											/* @__PURE__ */ d("span", { children: "⌂" }),
											/* @__PURE__ */ d("b", { children: n.buildingDeckCount }),
											/* @__PURE__ */ d("small", { children: t("games.mooncolonybloodbath.buildingDeck") })
										]
									})]
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									className: "mcb-initial-trigger",
									onClick: () => E(!0),
									children: [
										t("games.mooncolonybloodbath.cycle", { n: n.cycle }),
										" · ",
										t("games.mooncolonybloodbath.events", { n: n.events }),
										/* @__PURE__ */ d(c, { size: 16 })
									]
								})
							]
						}),
						/* @__PURE__ */ f("aside", {
							className: "mcb-colony-tools",
							children: [/* @__PURE__ */ f("div", {
								className: "mcb-wheel",
								role: "group",
								"aria-label": t("games.mooncolonybloodbath.choosework"),
								children: [Le.map((e, n) => /* @__PURE__ */ f("button", {
									type: "button",
									"data-action": e,
									"aria-pressed": P?.action === e,
									disabled: !j.some((t) => t.action === e),
									style: {
										left: `${50 + Math.cos((n * 72 - 90) * Math.PI / 180) * 34}%`,
										top: `${50 + Math.sin((n * 72 - 90) * Math.PI / 180) * 34}%`
									},
									onClick: () => W(e),
									children: [/* @__PURE__ */ d("span", {
										"aria-hidden": "true",
										children: [
											"⚒",
											"♧",
											"⚗",
											"◇",
											"⌂"
										][n]
									}), t(Q[e])]
								}, e)), /* @__PURE__ */ d("span", {
									className: "mcb-wheel-hub",
									children: P?.action ? t(Q[P.action]) : t("games.mooncolonybloodbath.work")
								})]
							}), /* @__PURE__ */ f("div", {
								className: "mcb-base",
								children: [
									/* @__PURE__ */ d(X, { name: "base-dome" }),
									/* @__PURE__ */ d("b", { children: k?.base ?? 0 }),
									/* @__PURE__ */ d("small", { children: t("games.mooncolonybloodbath.base") })
								]
							})]
						}),
						/* @__PURE__ */ f("section", {
							className: "mcb-colony",
							"aria-label": t("games.mooncolonybloodbath.buildings"),
							children: [
								/* @__PURE__ */ f("div", {
									className: "mcb-section-heading",
									children: [
										/* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("span", {
											className: "sr-only",
											children: t("games.mooncolonybloodbath.viewColony")
										}), /* @__PURE__ */ d("select", {
											"aria-label": t("games.mooncolonybloodbath.viewColony"),
											value: k?.rid ?? "",
											onChange: (e) => h(e.target.value),
											children: n.players.map((e) => /* @__PURE__ */ d("option", {
												value: e.rid,
												children: O(e.rid)
											}, e.rid))
										})] }),
										/* @__PURE__ */ f("strong", { children: [
											t("games.mooncolonybloodbath.buildings"),
											" ",
											k?.buildings.length ?? 0
										] }),
										/* @__PURE__ */ f("span", { children: [
											t("games.mooncolonybloodbath.base"),
											" ",
											k?.base ?? 0
										] })
									]
								}),
								/* @__PURE__ */ f("div", {
									className: "mcb-buildings",
									children: [k?.buildings.map((n) => {
										let r = k.rid === e.myRid, i = r && j.some((e) => e.card === n.card), a = r && (P?.card === n.card || P?.target === n.card);
										return /* @__PURE__ */ f("div", {
											className: "mcb-card-object",
											children: [/* @__PURE__ */ d("button", {
												type: "button",
												className: "mcb-card-pick",
												"aria-pressed": a,
												"aria-label": `${t(_(n.card).nameKey)} · ${t(i ? "games.mooncolonybloodbath.choose" : "games.mooncolonybloodbath.inspect")}`,
												onClick: () => U(n.card, r),
												children: /* @__PURE__ */ d(Ne, {
													card: n.card,
													boxes: n.boxes,
													compact: !0,
													available: i,
													selected: a,
													danger: z,
													previewBoxes: a && P?.text === "box" ? n.boxes + 1 : void 0
												})
											}), /* @__PURE__ */ d("button", {
												type: "button",
												className: "mcb-inspect-button",
												"aria-label": `${t("games.mooncolonybloodbath.inspect")} · ${t(_(n.card).nameKey)}`,
												onClick: () => v({ card: n.card }),
												children: /* @__PURE__ */ d(c, { size: 18 })
											})]
										}, n.card);
									}), !k?.buildings.length && /* @__PURE__ */ f("div", {
										className: "mcb-empty-colony",
										children: [/* @__PURE__ */ d(X, { name: "base-dome" }), /* @__PURE__ */ d("span", { children: t("games.mooncolonybloodbath.none") })]
									})]
								}),
								k?.muted && /* @__PURE__ */ d("p", {
									className: "mcb-colony-status",
									children: t("games.mooncolonybloodbath.muted")
								})
							]
						}),
						/* @__PURE__ */ f("section", {
							ref: D,
							className: "mcb-hand",
							"aria-label": t("games.mooncolonybloodbath.hand"),
							children: [/* @__PURE__ */ d("div", {
								className: "mcb-section-heading mcb-hand-tabs",
								children: [
									"hand",
									"reserved",
									"surveyed"
								].map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									"aria-pressed": F === e,
									onClick: () => b({
										revision: p?.revision ?? 0,
										kind: e
									}),
									children: [
										t(e === "hand" ? "games.mooncolonybloodbath.hand" : e === "reserved" ? "games.mooncolonybloodbath.reserved" : "games.mooncolonybloodbath.surveyed"),
										" ",
										/* @__PURE__ */ d("b", { children: p?.[e].length ?? 0 })
									]
								}, e))
							}), /* @__PURE__ */ f("div", {
								className: "mcb-hand-cards",
								children: [I.map((e) => {
									let n = j.some((t) => t.card === e), r = P?.card === e || p?.selected === e || !!p?.marked.includes(e);
									return /* @__PURE__ */ f("div", {
										className: "mcb-card-object",
										children: [/* @__PURE__ */ d("button", {
											type: "button",
											className: "mcb-card-pick",
											"aria-pressed": r,
											"aria-label": `${t(_(e).nameKey)} · ${t(n ? "games.mooncolonybloodbath.choose" : "games.mooncolonybloodbath.inspect")}`,
											onClick: () => U(e, !0),
											children: /* @__PURE__ */ d(Ne, {
												card: e,
												selected: r,
												available: n
											})
										}), /* @__PURE__ */ d("button", {
											type: "button",
											className: "mcb-inspect-button",
											"aria-label": `${t("games.mooncolonybloodbath.inspect")} · ${t(_(e).nameKey)}`,
											onClick: () => v({ card: e }),
											children: /* @__PURE__ */ d(c, { size: 18 })
										})]
									}, e);
								}), !I.length && /* @__PURE__ */ d("p", {
									className: "mcb-empty-hand",
									children: t("games.mooncolonybloodbath.none")
								})]
							})]
						}),
						/* @__PURE__ */ f("section", {
							className: "mcb-records",
							children: [
								/* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => E(!0),
									children: t("games.mooncolonybloodbath.initial")
								}),
								n.buildingDiscardTop !== null && /* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => v({ card: n.buildingDiscardTop }),
									children: t("games.mooncolonybloodbath.discardTop")
								}),
								n.revealed.map((e) => /* @__PURE__ */ f("span", { children: [
									O(e.rid),
									" · ",
									t("games.mooncolonybloodbath.build"),
									" · ",
									t(_(e.card).nameKey)
								] }, e.rid))
							]
						})
					]
				})
			}),
			/* @__PURE__ */ d(o, {
				open: C,
				onClose: () => w(!1),
				label: t("games.mooncolonybloodbath.allChoices"),
				title: R,
				children: /* @__PURE__ */ f("div", {
					className: "mcb-choice-sheet",
					children: [
						p?.sourceCard !== null && p?.sourceCard !== void 0 && /* @__PURE__ */ f("button", {
							type: "button",
							className: "mcb-sheet-source",
							onClick: () => {
								w(!1), v({ card: p.sourceCard });
							},
							children: [
								/* @__PURE__ */ d(c, { size: 18 }),
								" ",
								t(_(p.sourceCard).nameKey)
							]
						}),
						j.map((e) => /* @__PURE__ */ f("button", {
							type: "button",
							className: "mcb-choice",
							"aria-pressed": P?.id === e.id,
							"data-action": e.action,
							onClick: () => V(e),
							children: [/* @__PURE__ */ d("span", { children: M(e) }), e.money !== void 0 && e.text !== "payment" && /* @__PURE__ */ d("small", { children: $(e, t) })]
						}, `${p?.revision}:${e.id}`)),
						p?.storage.map((n) => /* @__PURE__ */ f("button", {
							type: "button",
							className: "mcb-choice",
							onClick: () => e.send({
								type: "storage",
								revision: p.revision,
								card: n
							}),
							children: [
								t("games.mooncolonybloodbath.storage"),
								" · ",
								t(_(n).nameKey)
							]
						}, `storage:${n}`))
					]
				})
			}),
			/* @__PURE__ */ d(o, {
				open: g !== null,
				onClose: () => v(null),
				label: t("games.mooncolonybloodbath.inspect"),
				title: t("games.mooncolonybloodbath.inspect"),
				children: /* @__PURE__ */ d("div", {
					className: "mcb-inspect",
					children: g && ("card" in g ? /* @__PURE__ */ d(Ne, { card: g.card }) : /* @__PURE__ */ d(Fe, {
						card: g.progress,
						owner: g.progress.owner ? O(g.progress.owner) : void 0
					}))
				})
			}),
			/* @__PURE__ */ d(o, {
				open: T,
				onClose: () => E(!1),
				label: t("games.mooncolonybloodbath.initial"),
				title: t("games.mooncolonybloodbath.initial"),
				children: /* @__PURE__ */ f("div", {
					className: "mcb-initial-sheet",
					children: [
						/* @__PURE__ */ f("p", { children: [
							t("games.mooncolonybloodbath.events", { n: n.events }),
							" · ",
							t("games.mooncolonybloodbath.cycle", { n: n.cycle })
						] }),
						n.extendedSolo && n.players.length === 1 && /* @__PURE__ */ d("p", { children: t("games.mooncolonybloodbath.extra", { n: n.extraRobots }) }),
						n.initialTwists.map((e) => /* @__PURE__ */ d(Fe, { card: {
							kind: "twist",
							id: e
						} }, e))
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/mooncolonybloodbath/bot.ts
var ze = ({ public: e, private: t }, n) => {
	if (!t || e.phase !== "resolve") return null;
	let r = e.players.find((e) => e.rid === n.rid);
	if (!r) return null;
	if (t.storage.length && t.hand.length < 2 && t.prompt !== null && t.selected === null) return { action: {
		type: "storage",
		revision: t.revision,
		card: t.storage[0]
	} };
	if (!t.choices.length) return null;
	let i = t.choices.map((e) => {
		let i = e.score;
		if (e.action && e.card === void 0 && t.prompt === "choosework") {
			let t = r.buildings.filter((t) => _(t.card).trigger === e.action);
			i += r.muted ? 0 : t.length * 3;
		}
		if (e.action === "build" && e.card !== void 0) {
			let t = _(e.card);
			i += r.buildings.length < 5 ? 4 : -3, r.food < r.buildings.length && t.trigger !== "farm" && (i -= 8), t.trigger === "farm" && (i += 3), t.cost === 0 && (i += 3);
		}
		return {
			c: e,
			score: n.difficulty === "weak" ? Math.round(i / 5) : i
		};
	}).sort((e, t) => t.score - e.score);
	return { action: {
		type: "choose",
		revision: t.revision,
		choice: i[0].c.id
	} };
}, Be = (e, t, n) => {
	if (e.type === "storage") return n("games.mooncolonybloodbath.storage");
	if (e.type !== "choose") return n("games.mooncolonybloodbath.continue");
	let r = t.private?.choices.find((t) => t.id === e.choice);
	return r ? Ie(r, n, t) : n("games.mooncolonybloodbath.continue");
};
//#endregion
//#region src/games/mooncolonybloodbath/game-over-row.tsx
function Ve({ public: e, rid: t }) {
	let n = a(), r = e, i = r.players.find((e) => e.rid === t);
	return i ? /* @__PURE__ */ f("div", {
		className: "text-xs leading-relaxed opacity-75",
		children: [
			/* @__PURE__ */ d("p", { children: n("games.mooncolonybloodbath.resultPopulation", {
				base: i.base,
				buildings: i.population - i.base,
				total: i.population
			}) }),
			r.players.length === 1 && /* @__PURE__ */ d("p", { children: n("games.mooncolonybloodbath.resultSolo", {
				n: r.events,
				extra: r.extraRobots
			}) }),
			/* @__PURE__ */ d("p", { children: n(r.ended === "manual" ? "games.mooncolonybloodbath.resultManual" : "games.mooncolonybloodbath.resultDeath") })
		]
	}) : null;
}
//#endregion
//#region src/games/mooncolonybloodbath/options.tsx
function He({ value: e, onChange: t }) {
	let n = a(), r = Y.safeParse(e), i = r.success ? r.data : Y.parse(void 0);
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ d(m, {
				title: n("games.mooncolonybloodbath.beginner"),
				children: [!0, !1].map((e) => /* @__PURE__ */ d(p, {
					name: "mcb-twists",
					value: String(e),
					checked: i.beginner === e,
					accent: fe.accent,
					label: n(e ? "games.mooncolonybloodbath.simple" : "games.mooncolonybloodbath.all"),
					onChange: () => t({
						...i,
						beginner: e
					})
				}, String(e)))
			}),
			/* @__PURE__ */ d(m, {
				title: n("games.mooncolonybloodbath.soloMode"),
				children: [!1, !0].map((e) => /* @__PURE__ */ d(p, {
					name: "mcb-solo",
					value: String(e),
					checked: i.extendedSolo === e,
					accent: fe.accent,
					label: n(e ? "games.mooncolonybloodbath.extended" : "games.mooncolonybloodbath.normal"),
					onChange: () => t({
						...i,
						extendedSolo: e
					})
				}, String(e)))
			}),
			/* @__PURE__ */ d("p", {
				className: "text-sm opacity-70",
				children: n("games.mooncolonybloodbath.soloHint")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/mooncolonybloodbath/entry.tsx
var Ue = {
	definition: ke,
	View: Re,
	bot: ze,
	describe: Be,
	RowView: Ve,
	Options: He,
	locales: {
		zh: {
			b0: "市场",
			b0Text: "耕作时：你可以支付2份食物或弃置1张手牌，获得4点资金。\n建成时：将1张「贸易」发展牌加入进程牌库。",
			b1: "月球旅馆",
			b1Text: "每次获得食物时，基地人口增加1人。\n建成时：将1张「游客」发展牌加入进程牌库。",
			b2: "育婴室",
			b2Text: "耕作时：你可以消耗这座建筑上的1个物资箱，使基地人口增加4人。\n建成时：选择1张个人奖励牌，加入进程牌库。",
			b3: "器官库",
			b3Text: "遇到「事故」事件时，你可以消耗这座建筑上的1个物资箱，忽略该事件。\n建成时：选择1张个人奖励牌，加入进程牌库。",
			b4: "马铃薯农场",
			b4Text: "耕作时：获得2份食物。\n支付资金时，你可以用等量食物代替，也可以混合支付。",
			b5: "无线电天线",
			b5Text: "工作开始时，如果你没有手牌，抽取1张建筑牌。\n建成时：将1张「维修」发展牌加入进程牌库。",
			b6: "回收站",
			b6Text: "每弃置1张建筑手牌，获得1点资金。\n建成时：将1张「花园」发展牌加入进程牌库。",
			b7: "研究站",
			b7Text: "研究时：你可以支付3份食物，选择1张个人奖励牌加入进程牌库。",
			b8: "餐厅",
			b8Text: "耕作时：你可以支付1份食物，获得4点资金。\n建成时：选择1张个人奖励牌，加入进程牌库。",
			b9: "硅矿场",
			b9Text: "采矿时：获得2点资金。\n失去时：获得4点资金。",
			b10: "太阳能板",
			b10Text: "每建成另一座建筑时，这座建筑上每有2个物资箱，基地人口增加1人；不足2个的部分不计。",
			b11: "太空港",
			b11Text: "每建成另一座建筑时，你可以支付3点资金，选择1张个人奖励牌加入进程牌库，或使基地人口增加3人。",
			b12: "研发仓库",
			b12Text: "建成时：在这座建筑上放置3个物资箱。\n你可以随时消耗这座建筑上的1个物资箱，抽取1张建筑牌。",
			b13: "望远镜",
			b13Text: "研究时：抽取2张建筑牌。",
			b14: "钛矿场",
			b14Text: "采矿时：获得4点资金，抽取1张建筑牌，然后弃置1张手牌。\n建成时：将1张「创新」发展牌加入进程牌库。",
			b15: "贸易站",
			b15Text: "每次你向进程牌库加入卡牌时，获得2点资金。\n建成时：抽取2张建筑牌，然后弃置2张手牌。",
			b16: "隧道",
			b16Text: "补给时：选择获得2份食物、1个物资箱或2点资金。",
			b17: "反应堆",
			b17Text: "建造印刷费用至少为6点资金的建筑时，费用减少3点资金。\n失去时：将1张「辐射」发展牌加入进程牌库。",
			b18: "仓储中心",
			b18Text: "补给时：获得2点资金。你可以将自己一座建筑上的1个物资箱移到另一座建筑上。\n建成时：将1张「保养」发展牌加入进程牌库。",
			b19: "铝矿场",
			b19Text: "采矿时：如果你没有资金，获得5点资金；否则获得2点资金。\n建成时：将1张「预算削减」发展牌加入进程牌库。",
			b20: "动物实验室",
			b20Text: "研究时：如果你拥有至少10点资金，基地人口增加2人。\n失去时：选择1张个人奖励牌，加入进程牌库。",
			b21: "地堡",
			b21Text: "建成时：将1张机器人牌加入进程牌库。",
			b22: "货运舱",
			b22Text: "每建成另一座建筑时，在新建筑上放置1个物资箱。\n失去时：获得2个物资箱。",
			b23: "洞穴",
			b23Text: "建成时：你可以执行一次建造行动。\n失去时：执行一次采矿行动。",
			b24: "化学实验室",
			b24Text: "研究时：抽取1张建筑牌。\n建成时：获得2份食物和1个物资箱，并抽取1张建筑牌。",
			b25: "克隆库",
			b25Text: "研究时：基地人口增加2人。\n每次未因饥荒损失人口时，基地人口额外增加3人。",
			b26: "综合建筑",
			b26Text: "建成时：你每拥有2座建筑，基地人口增加1人；不足2座的部分不计。",
			b27: "环形山住宅",
			b27Text: "建成时：你可以消耗任意数量的物资箱，每消耗1个，获得2点资金。\n失去时：获得4份食物。",
			b28: "穹顶",
			b28Text: "建成时：将下一张事件牌加入进程牌库。",
			b29: "尘埃矿场",
			b29Text: "采矿时：在这座建筑上放置1个物资箱。\n失去时：这座建筑原有的每个物资箱使你获得3点资金。",
			b30: "旗帜",
			b30Text: "饥荒时，这座建筑不需要支付食物。\n建成时：获得6点资金。",
			b31: "铁矿场",
			b31Text: "采矿时：获得1个物资箱。\n建成时：选择1张个人奖励牌，加入进程牌库。",
			b32: "燃料电池",
			b32Text: "补给时：你可以消耗这座建筑上的1个物资箱，获得4点资金，抽取1张建筑牌，然后弃置1张手牌。",
			b33: "发电机",
			b33Text: "补给时：获得1个物资箱。\n建成时：选择执行一次采矿、耕作或研究行动。",
			b34: "地质实验室",
			b34Text: "研究时：抽取1张建筑牌。\n失去时：将这张建筑牌收回手牌。",
			b35: "温室",
			b35Text: "饥荒时，你所有放有物资箱的建筑都不需要支付食物。\n建成时：获得1个物资箱。",
			b36: "黑客基地",
			b36Text: "忽略「文书工作」事件。\n建成时：选择1张个人奖励牌，加入进程牌库。",
			b37: "氦-3矿场",
			b37Text: "采矿时：这座建筑上每有1个物资箱，获得1点资金。\n建成时：将1张「月球车」发展牌加入进程牌库。",
			b38: "水培设施",
			b38Text: "耕作时：基地人口增加1人。\n每失去另一座建筑时，获得1点资金。",
			b39: "羽衣甘蓝农场",
			b39Text: "耕作时：获得1份食物。\n建成时：执行一次耕作行动。",
			b40: "厨房",
			b40Text: "补给时：你可以消耗这座建筑上的1个物资箱，获得4份食物。\n建成时：将1张「自动售货机」发展牌加入进程牌库。",
			b41: "发射台",
			b41Text: "补给时：获得1个物资箱。\n建成时：重复执行自己另一座建筑的建成能力。不能选择发射台。",
			b42: "月壤混凝土厂",
			b42Text: "建造建筑时，费用减少2点资金。\n建成时：抽取2张建筑牌。",
			b43: "临时实验室",
			b43Text: "建成时：获得2个物资箱。\n失去时：抽取2张建筑牌。",
			b44: "装配线",
			b44Text: "建造建筑时，费用减少1点资金。\n失去时：你可以执行一次建造行动。",
			development0: "预算削减",
			development0Text: "失去2点资金。",
			development1: "花园",
			development1Text: "你可以弃置1张手牌，获得4份食物。",
			development2: "创新",
			development2Text: "你可以弃置2张手牌，然后执行一次建造行动。仍须支付建造费用。",
			development3: "保养",
			development3Text: "你可以支付2点资金，获得2个物资箱。",
			development4: "月球车",
			development4Text: "抽取1张建筑牌，然后弃置1张手牌。",
			development5: "辐射",
			development5Text: "你可以失去一座建筑。如果不这样做，人口减少3人。",
			development6: "维修",
			development6Text: "消耗1个物资箱。如果没有物资箱，无须执行此效果。",
			development7: "游客",
			development7Text: "你可以支付2份食物，使基地人口增加3人。",
			development8: "贸易",
			development8Text: "你可以消耗1个物资箱，抽取2张建筑牌。",
			development9: "自动售货机",
			development9Text: "你可以支付2份食物，获得4点资金。",
			event0: "饥荒",
			event0Text: "为每座建筑支付1份食物。每缺少1份食物，人口减少1人。\n如果没有因此损失人口，基地人口增加2人。",
			event1: "文书工作",
			event1Text: "抽取1张建筑牌，然后弃置2张手牌。",
			event2: "故障",
			event2Text: "将1张机器人牌加入公共进程牌库。",
			event3: "泄漏",
			event3Text: "人口减少4人。",
			event4: "怒火爆发",
			event4Text: "人口减少2人。",
			event5: "事故",
			event5Text: "人口减少3人。",
			event6: "事故",
			event6Text: "人口减少3人。",
			event7: "事故",
			event7Text: "人口减少3人。",
			event8: "泄漏",
			event8Text: "人口减少4人。",
			event9: "气闸测试",
			event9Text: "人口减少5人。",
			event10: "月震",
			event10Text: "人口减少6人。",
			event11: "停电",
			event11Text: "人口减少7人。",
			event12: "使用说明书",
			event12Text: "游戏结束。幸存总人口最多的玩家获胜；人口相同则并列获胜。",
			robot0: "自动门",
			robot0Text: "人口减少5人。\n重新洗牌前，下一次工作中的所有建筑能力失效。",
			robot1: "机器人管家",
			robot1Text: "人口减少4人，然后消耗1个物资箱。",
			robot2: "清洁机器人",
			robot2Text: "人口减少6人。\n如果能够移动，将自己一座建筑上的1个物资箱移到物资箱更多的另一座建筑上。",
			robot3: "机器人伙伴",
			robot3Text: "人口减少7人。\n你可以消耗1个物资箱，执行一次任意行动。",
			robot4: "建筑机器人",
			robot4Text: "人口减少5人。\n将1张手牌列为待建建筑。下次建造时，必须先从待建建筑中选择。",
			robot5: "送货无人机",
			robot5Text: "人口减少5人。\n所有玩家同时向左侧玩家传递1张手牌。没有手牌的玩家仍可接收卡牌。",
			robot6: "钻探机器人",
			robot6Text: "人口减少5人。\n你可以额外失去一座建筑。如果不这样做，人口再减少3人。",
			robot7: "效率机器人",
			robot7Text: "人口减少5人。\n消耗1个物资箱，或失去2点资金。",
			robot8: "热心机器人",
			robot8Text: "人口减少7人，然后抽取1张建筑牌。",
			robot9: "厨房机器人",
			robot9Text: "人口减少4人。\n如果你的食物少于8份，人口再减少3人。",
			robot10: "军用机器人",
			robot10Text: "人口减少7人，然后获得2点资金。",
			robot11: "采矿机器人",
			robot11Text: "人口减少6人。\n你每拥有一座采矿建筑，获得1点资金。",
			robot12: "维修机器人",
			robot12Text: "人口减少4人。\n重新洗牌前，下一次工作不能执行建造行动。",
			robot13: "研究机器人",
			robot13Text: "人口减少5人。\n如果你的手牌至少有5张，弃置1张手牌。",
			robot14: "机器人医生",
			robot14Text: "人口减少5人。\n你可以消耗1个物资箱，获得2份食物。",
			robot15: "机器人侍者",
			robot15Text: "人口减少4人，然后失去2份食物。",
			robot16: "安保机器人",
			robot16Text: "找出所有玩家中最多的建筑数量。你的人口减少相同的人数。",
			robot17: "觉醒人工智能",
			robot17Text: "人口减少8人。\n将1张变局牌加入公共进程牌库。",
			robot18: "堆垛机器人",
			robot18Text: "人口减少6人。\n你可以消耗任意数量的物资箱，每个物资箱使本次人口损失减少2人。",
			robot19: "仓库机器人",
			robot19Text: "人口减少7人。\n如果你有未放置物资箱的建筑，在其中一座上放置1个物资箱。",
			twist0: "定期货运",
			twist0Text: "你可以支付2点资金，执行一次补给行动。",
			twist1: "冒险研究",
			twist1Text: "你可以使人口减少2人，执行一次研究行动。",
			twist2: "勘测",
			twist2Text: "你可以埋置1张手牌，或弃置所有已埋牌，每弃置1张获得8点资金。",
			twist3: "合成肉",
			twist3Text: "获得2点资金。\n你可以支付任意数量的资金，每支付1点资金，获得1份食物。",
			twist4: "地下城",
			twist4Text: "你每有一座放置了物资箱的建筑，获得1点资金。",
			twist5: "大学",
			twist5Text: "你每有3张手牌，获得1点资金；不足3张的部分不计。",
			twist6: "动物研究",
			twist6Text: "你每有1张手牌，失去1点资金。然后抽取2张建筑牌。",
			twist7: "副产品",
			twist7Text: "你可以消耗1个物资箱，获得5点资金。",
			twist8: "蓝图",
			twist8Text: "你可以支付5点资金，抽取4张建筑牌。",
			twist9: "建筑套件",
			twist9Text: "你可以消耗1个物资箱，建造一座印刷费用不超过4点资金的建筑。仍须支付建造费用。",
			twist10: "撤资",
			twist10Text: "比较你的资金与食物数量，失去较多一项的一半，损失数量向下取整。数量相同时，自行选择失去哪一项。",
			twist11: "多元化",
			twist11Text: "如果你有研究建筑，抽取1张建筑牌。\n如果你有补给建筑，获得1个物资箱。\n如果你有耕作建筑，获得2份食物。\n如果你没有采矿建筑，失去2点资金。",
			twist12: "应急基金",
			twist12Text: "如果你的资金少于5点，获得3点资金。",
			twist13: "工程师",
			twist13Text: "你可以失去一座建筑，并将这张牌收回手牌。该建筑的人口转入基地，失去能力照常执行。",
			twist14: "优待",
			twist14Text: "你可以支付3点资金，选择1张个人奖励牌加入进程牌库。",
			twist15: "灵活计划",
			twist15Text: "选择一项：抽取1张建筑牌、获得2点资金、获得1个物资箱或获得2份食物。",
			twist16: "专注",
			twist16Text: "选择自己一座采矿、耕作、研究或补给建筑，执行它的行动能力。",
			twist17: "宏伟计划",
			twist17Text: "你可以弃置1张手牌，建造一座印刷费用至少为5点资金的建筑。仍须支付建造费用。",
			twist18: "集约耕作",
			twist18Text: "你可以消耗1个物资箱，执行一次耕作行动。",
			twist19: "投资",
			twist19Text: "你每有4点资金，获得1点资金；不足4点的部分不计。",
			twist20: "孤立",
			twist20Text: "如果你的建筑不超过4座，抽取1张建筑牌，并获得2份食物。",
			twist21: "采矿热",
			twist21Text: "你可以支付2份食物，执行一次采矿行动。",
			twist22: "新兵",
			twist22Text: "如果你的手牌数量多于建筑数量，基地人口增加3人。",
			twist23: "加班",
			twist23Text: "你可以额外支付等同于自己建筑数量的资金，执行一次建造行动。仍须支付所选建筑的建造费用。",
			twist24: "真人秀",
			twist24Text: "如果你的物资箱、手牌或建筑中，有任意一项的数量达到6，获得3点资金。",
			perk0: "食物奖励",
			perk0Text: "获得2份食物。",
			perk1: "物资奖励",
			perk1Text: "获得1个物资箱。",
			perk2: "研究奖励",
			perk2Text: "抽取1张建筑牌。",
			perk3: "资金奖励",
			perk3Text: "获得2点资金。",
			perk4: "人口奖励",
			perk4Text: "基地人口增加2人。",
			work0: "工作",
			work0Text: "选择执行一次采矿、耕作、研究、补给或建造行动。\n基本行动与相关建筑能力的执行顺序由你决定。",
			trouble0: "麻烦",
			trouble0Text: "将下一张事件牌加入进程牌库。",
			loneliness0: "孤独",
			loneliness0Text: "每个三环标记使基地人口增加3人。\n每个爆星标记使人口减少3人。",
			name: "月球殖民：浴血求生",
			titleMain: "月球殖民：",
			titleSubtitle: "浴血求生",
			desc: "经营月球殖民地，在失控机器人与灾难中生存",
			population: "人口",
			base: "基地",
			money: "资金",
			food: "食物",
			boxes: "物资箱",
			hand: "手牌",
			buildings: "建筑",
			reserved: "待建建筑",
			surveyed: "已埋牌",
			perks: "可用个人奖励",
			work: "工作",
			mine: "采矿",
			farm: "耕作",
			research: "研究",
			restock: "补给",
			build: "建造",
			cycle: "牌库循环第 {{n}} 轮",
			turn: "第 {{n}} 张进程牌",
			waiting: "等待其他玩家完成",
			resolving: "正在结算",
			next: "翻开下一张进程牌",
			choose: "请选择",
			window: "选择下一项能力或基本行动",
			choosework: "选择本次工作行动",
			buildChoice: "选择要建造的建筑",
			loss: "基地人口不足，请选择要失去的建筑",
			remove: "选择要失去的建筑",
			discard: "选择弃置的手牌",
			box: "选择放置物资箱的建筑",
			spendBox: "选择要消耗物资箱的建筑",
			perk: "选择要加入进程牌库的个人奖励牌",
			move: "选择物资箱的起点建筑与目标建筑",
			pass: "选择向左传递的手牌",
			reserve: "选择下次优先建造的建筑牌",
			survey: "选择要埋置的手牌，或出售全部已埋牌",
			focus: "选择一座建筑的行动能力",
			repeat: "选择要重复的建成能力",
			accident: "你可以消耗器官库上的1个物资箱，忽略本次事故",
			stack: "你可以消耗物资箱，减少本次人口损失",
			crater: "你可以消耗物资箱，每个兑换2点资金",
			synthetic: "选择兑换食物所需的付款方式",
			defund: "选择要失去的资源",
			optional: "是否使用此能力？",
			anyAction: "选择额外行动",
			skip: "不使用此能力",
			continue: "继续执行",
			finish: "完成",
			use: "使用能力",
			baseEffect: "基本行动",
			ability: "建筑能力",
			play: "建成能力",
			lost: "失去能力",
			payment: "支付{{money}}点资金和{{food}}份食物",
			spend: "消耗{{n}}个物资箱",
			amount: "支付{{n}}点资金",
			sell: "出售全部已埋牌（{{n}} 张）",
			moveBox: "移动1个物资箱",
			storage: "消耗研发仓库上的1个物资箱，抽取1张建筑牌",
			progressDeck: "进程牌库",
			buildingDeck: "建筑牌库",
			remaining: "剩余 {{n}}",
			initial: "初始变局",
			events: "已加入{{n}}张事件牌，共13张",
			extra: "额外加入{{n}}张机器人牌",
			inspect: "查看卡牌",
			close: "关闭",
			none: "暂无",
			beginner: "初始变局",
			simple: "简单变局",
			all: "全部变局",
			soloMode: "单人挑战",
			normal: "标准挑战",
			extended: "延长挑战",
			soloHint: "单人游戏加入孤独牌。延长挑战从第13张事件开始改为加入机器人牌，并按额外加入的数量计分。",
			errAction: "此操作当前不可用",
			errTick: "只有主机可以推进进程",
			resultPopulation: "基地人口{{base}}人，建筑人口{{buildings}}人，总人口{{total}}人",
			resultSolo: "已加入{{n}}张事件牌，额外加入{{extra}}张机器人牌",
			resultManual: "已翻开「使用说明书」，游戏结束",
			resultDeath: "已有殖民地的人口耗尽",
			muted: "本次工作期间，所有建筑能力失效",
			closed: "下次工作不能建造",
			rings: "单人游戏：孤独时，基地人口增加3人",
			star: "单人游戏：孤独时，人口减少3人",
			selected: "已选择，等待同时公开",
			log: "进程记录",
			cost: "费用",
			viewColony: "查看殖民地",
			rules: "游戏目标：\n任一殖民地的人口耗尽，或翻开「使用说明书」事件牌时，游戏结束。多人游戏中，幸存总人口最多的玩家获胜；人口相同则并列获胜。\n游戏准备：\n每位玩家的基地人口为30人，起始拥有4点资金和4份食物。每位玩家抽取4张建筑牌，并获得5种个人奖励牌，各1张。\n进程牌库由4张工作牌、2张麻烦牌和随机抽取的2张变局牌组成。初始变局可从简单变局或全部变局中抽取，由游戏设置决定。\n回合流程：\n翻开1张进程牌，所有玩家同时执行牌面效果。所有玩家完成后，再翻开下一张进程牌。麻烦牌将下一张事件牌加入进程牌库；「故障」事件加入1张机器人牌。\n新加入的进程牌放在牌库顶部。同批加入多张时，先混洗这些牌再放到顶部。只有需要翻牌而进程牌库为空时，才将进程弃牌洗成新的牌库；牌库为空时仍可加入新牌，不会因此提前混入弃牌。\n五种基本行动：\n工作时，每位玩家选择一种行动。建造所用的卡牌先秘密选定，再同时公开。\n· 采矿：获得4点资金。\n· 耕作：获得4份食物。\n· 研究：抽取2张建筑牌。\n· 补给：获得2个物资箱，分别选择放置的建筑。\n· 建造：选择1张建筑牌，支付建造费用后，将它放入自己的殖民地。\n你可以自行安排基本行动与相关建筑能力的执行顺序。额外行动也会触发相应建筑能力；同一种行动可以重复执行。\n建筑与物资箱：\n总人口等于基地人口与所有建筑牌上印刷人口的总和。建造时直接增加建筑上的印刷人口，不从基地扣除。增加人口的效果通常增加基地人口，特殊情况以牌面为准。\n物资箱必须放在自己的建筑上，可以在同一座建筑上放置多个。同名建筑的能力通常可以叠加；可选效果必须付清所需费用才能执行。\n牌面上的「建成时」与「失去时」分别在建成或失去该建筑时执行。个人奖励牌加入进程牌库后可以反复出现，但只对所属玩家生效。\n人口损失与饥荒：\n人口损失先从基地人口中扣除。基地人口不足时，选择一座建筑失去，将其印刷人口转入基地。弃置失去的建筑及其全部物资箱，并完整执行这座建筑的失去能力，然后继续扣除尚未承担的人口损失。必要时，重复失去建筑的过程。只有规则或牌面要求时才能失去建筑，不能自行弃置已建建筑。\n饥荒时，每座建筑需要支付1份食物；「旗帜」和「温室」的能力可以豁免。每缺少1份食物，人口减少1人，食物缺额合计为一次人口损失。如果没有因饥荒损失人口，基地人口增加2人。\n单人玩法：\n单人游戏在初始牌库中加入1张孤独牌。孤独时，每个三环标记使基地人口增加3人，每个爆星标记使人口减少3人。\n· 标准挑战：翻开「使用说明书」时获胜；如果人口先耗尽，则挑战失败。挑战失败时，记录已经加入进程牌库的最高事件序号。\n· 延长挑战：从第13张事件开始，改为加入机器人牌，直至殖民地人口耗尽，按额外加入的机器人牌数量计分。\n界面操作：\n手牌、待建建筑和已埋牌仅本人可见。建筑弃牌堆只公开顶部一张。已建建筑与手牌位于同一页面，向下滚动可以查看后续卡牌。\n· 点击可选卡牌，再点击底部确认按钮。点击信息按钮可查看完整牌面。\n· 「全部选择」列出当前可执行的操作；有多种付款方式时，可在底部选择。\n· 每次选择操作前，可以使用研发仓库；已经提交选择后不能使用。\n· 需要同时弃置多张手牌时，先选齐所需数量，再一起弃置。",
			payFood: "支付{{n}}份食物",
			discardFor: "弃置{{n}}张手牌",
			payPopulation: "使人口减少{{n}}人",
			discardTop: "查看建筑弃牌堆的顶牌",
			loseBuilding: "失去建筑",
			lossAmount: "还需承担{{n}}人的人口损失，请选择要失去的建筑",
			discardAmount: "再选择{{n}}张要弃置的手牌",
			stackAmount: "还需承担{{n}}人的人口损失，可以消耗物资箱减免",
			paymentMethod: "支付方式",
			allChoices: "全部选择",
			confirm: "确认选择",
			ready: "已完成",
			pending: "选择中",
			playPrefix: "建成时：",
			lostPrefix: "失去时：",
			chooseAction: "执行{{action}}行动",
			resolveAction: "执行{{action}}的基本行动",
			placeBox: "放置1个物资箱",
			consumeBox: "消耗1个物资箱",
			buryCard: "埋置1张手牌",
			reserveCard: "将此牌列为待建建筑",
			passCard: "向左侧玩家传递1张手牌",
			gainMoney: "获得{{n}}点资金",
			gainFood: "获得{{n}}份食物",
			gainBox: "获得{{n}}个物资箱",
			gainPopulation: "使基地人口增加{{n}}人",
			drawBuilding: "抽取{{n}}张建筑牌",
			marketFood: "支付2份食物，获得4点资金",
			marketDiscard: "弃置1张手牌，获得4点资金",
			loseHalfMoney: "失去一半资金，损失数量向下取整",
			loseHalfFood: "失去一半食物，损失数量向下取整",
			declineBuilding: "不失去建筑，使人口减少3人",
			finishLoss: "承担剩余人口损失",
			finishExchange: "结束兑换",
			cardCost: "建造费用：{{n}}点资金",
			cardPopulation: "建筑人口：{{n}}人"
		},
		en: {
			b0: "Market",
			b0Text: "Farming: You may pay 2 food or discard 1 hand card to gain 4 money.\nWhen built: Add a Trade Development card to the Progress deck.",
			b1: "Moon Hotel",
			b1Text: "Whenever you gain food, gain 1 base population.\nWhen built: Add a Tourists Development card to the Progress deck.",
			b2: "Nursery",
			b2Text: "Farming: You may spend 1 box from this building to gain 4 base population.\nWhen built: Choose a personal Perk card to add to the Progress deck.",
			b3: "Organ Banks",
			b3Text: "When an Accident is revealed, you may spend 1 box from this building to ignore that Event.\nWhen built: Choose a personal Perk card to add to the Progress deck.",
			b4: "Potato Farm",
			b4Text: "Farming: Gain 2 food.\nYou may pay with food instead of money at the same rate, or combine both resources.",
			b5: "Radio Antennae",
			b5Text: "At the start of Work, draw 1 building card if your hand is empty.\nWhen built: Add a Repairs Development card to the Progress deck.",
			b6: "Recycling",
			b6Text: "Gain 1 money for each building card you discard from your hand.\nWhen built: Add a Gardens Development card to the Progress deck.",
			b7: "Research Station",
			b7Text: "Researching: You may pay 3 food to choose a personal Perk card and add it to the Progress deck.",
			b8: "Restaurant",
			b8Text: "Farming: You may pay 1 food to gain 4 money.\nWhen built: Choose a personal Perk card to add to the Progress deck.",
			b9: "Silica Mine",
			b9Text: "Mining: Gain 2 money.\nWhen lost: Gain 4 money.",
			b10: "Solar Panels",
			b10Text: "Whenever you build another building, gain 1 base population for every 2 boxes on this building, rounded down.",
			b11: "Spaceport",
			b11Text: "Whenever you build another building, you may pay 3 money to add a personal Perk card to the Progress deck or gain 3 base population.",
			b12: "Research and Development Storage",
			b12Text: "When built: Put 3 boxes on this building.\nAt any time, you may spend 1 box from this building to draw 1 building card.",
			b13: "Telescope",
			b13Text: "Researching: Draw 2 building cards.",
			b14: "Titanium Mine",
			b14Text: "Mining: Gain 4 money, draw 1 building card, then discard 1 hand card.\nWhen built: Add an Innovation Development card to the Progress deck.",
			b15: "Trading Post",
			b15Text: "Whenever you add a card to the Progress deck, gain 2 money.\nWhen built: Draw 2 building cards, then discard 2 hand cards.",
			b16: "Tunnels",
			b16Text: "Restocking: Choose to gain 2 food, 1 box, or 2 money.",
			b17: "Reactor",
			b17Text: "Buildings with a printed cost of at least 6 money cost you 3 money less to build.\nWhen lost: Add a Radiation Development card to the Progress deck.",
			b18: "Warehouse",
			b18Text: "Restocking: Gain 2 money. You may move 1 box from one of your buildings to another.\nWhen built: Add a Maintain Development card to the Progress deck.",
			b19: "Aluminum Mine",
			b19Text: "Mining: Gain 5 money if you have no money; otherwise gain 2 money.\nWhen built: Add a Budget Cuts Development card to the Progress deck.",
			b20: "Animal Laboratory",
			b20Text: "Researching: Gain 2 base population if you have at least 10 money.\nWhen lost: Choose a personal Perk card to add to the Progress deck.",
			b21: "Bunker",
			b21Text: "When built: Add a Robot card to the Progress deck.",
			b22: "Cargo Bay",
			b22Text: "Whenever you build another building, put 1 box on the new building.\nWhen lost: Gain 2 boxes.",
			b23: "Cave",
			b23Text: "When built: You may perform a Build action.\nWhen lost: Perform a Mine action.",
			b24: "Chemistry Laboratory",
			b24Text: "Researching: Draw 1 building card.\nWhen built: Gain 2 food and 1 box, and draw 1 building card.",
			b25: "Clone Banks",
			b25Text: "Researching: Gain 2 base population.\nWhenever Hunger causes you no population loss, gain 3 additional base population.",
			b26: "Complex",
			b26Text: "When built: Gain 1 base population for every 2 buildings you own, rounded down.",
			b27: "Crater Homes",
			b27Text: "When built: You may spend any number of boxes to gain 2 money for each box spent.\nWhen lost: Gain 4 food.",
			b28: "Dome",
			b28Text: "When built: Add the next Event card to the Progress deck.",
			b29: "Dust Mine",
			b29Text: "Mining: Put 1 box on this building.\nWhen lost: Gain 3 money for each box that was on this building.",
			b30: "Flag",
			b30Text: "This building needs no food during Hunger.\nWhen built: Gain 6 money.",
			b31: "Iron Mine",
			b31Text: "Mining: Gain 1 box.\nWhen built: Choose a personal Perk card to add to the Progress deck.",
			b32: "Fuel Cells",
			b32Text: "Restocking: You may spend 1 box from this building to gain 4 money, draw 1 building card, then discard 1 hand card.",
			b33: "Generator",
			b33Text: "Restocking: Gain 1 box.\nWhen built: Choose to perform a Mine, Farm, or Research action.",
			b34: "Geology Laboratory",
			b34Text: "Researching: Draw 1 building card.\nWhen lost: Return this building card to your hand.",
			b35: "Greenhouse",
			b35Text: "Your buildings with boxes need no food during Hunger.\nWhen built: Gain 1 box.",
			b36: "Hacker Lair",
			b36Text: "Ignore the Paperwork Event.\nWhen built: Choose a personal Perk card to add to the Progress deck.",
			b37: "Helium-3 Mine",
			b37Text: "Mining: Gain 1 money for each box on this building.\nWhen built: Add a Moon Buggy Development card to the Progress deck.",
			b38: "Hydroponics",
			b38Text: "Farming: Gain 1 base population.\nWhenever you lose another building, gain 1 money.",
			b39: "Kale Farm",
			b39Text: "Farming: Gain 1 food.\nWhen built: Perform a Farm action.",
			b40: "Kitchen",
			b40Text: "Restocking: You may spend 1 box from this building to gain 4 food.\nWhen built: Add a Vending Machines Development card to the Progress deck.",
			b41: "Launch Pad",
			b41Text: "Restocking: Gain 1 box.\nWhen built: Repeat the ability of another building that triggers when built. You cannot choose a Launch Pad.",
			b42: "Lunarcrete Factory",
			b42Text: "Your buildings cost 2 money less to build.\nWhen built: Draw 2 building cards.",
			b43: "Makeshift Laboratory",
			b43Text: "When built: Gain 2 boxes.\nWhen lost: Draw 2 building cards.",
			b44: "Assembly Line",
			b44Text: "Your buildings cost 1 money less to build.\nWhen lost: You may perform a Build action.",
			development0: "Budget Cuts",
			development0Text: "Lose 2 money.",
			development1: "Gardens",
			development1Text: "You may discard 1 hand card to gain 4 food.",
			development2: "Innovation",
			development2Text: "You may discard 2 hand cards, then perform a Build action. You must still pay the building cost.",
			development3: "Maintain",
			development3Text: "You may pay 2 money to gain 2 boxes.",
			development4: "Moon Buggy",
			development4Text: "Draw 1 building card, then discard 1 hand card.",
			development5: "Radiation",
			development5Text: "You may lose one of your buildings. If you do not, lose 3 population.",
			development6: "Repairs",
			development6Text: "Spend 1 box. If you have no boxes, this has no effect.",
			development7: "Tourists",
			development7Text: "You may pay 2 food to gain 3 base population.",
			development8: "Trade",
			development8Text: "You may spend 1 box to draw 2 building cards.",
			development9: "Vending Machines",
			development9Text: "You may pay 2 food to gain 4 money.",
			event0: "Hunger",
			event0Text: "Pay 1 food for each building. Lose 1 population for each food you cannot pay.\nIf you lose no population to Hunger, gain 2 base population.",
			event1: "Paperwork",
			event1Text: "Draw 1 building card, then discard 2 hand cards.",
			event2: "Glitch",
			event2Text: "Add one Robot card to the shared Progress deck.",
			event3: "Leak",
			event3Text: "Lose 4 population.",
			event4: "Tempers Flare",
			event4Text: "Lose 2 population.",
			event5: "Accident",
			event5Text: "Lose 3 population.",
			event6: "Accident",
			event6Text: "Lose 3 population.",
			event7: "Accident",
			event7Text: "Lose 3 population.",
			event8: "Leak",
			event8Text: "Lose 4 population.",
			event9: "Airlock Test",
			event9Text: "Lose 5 population.",
			event10: "Moonquake",
			event10Text: "Lose 6 population.",
			event11: "Power Failure",
			event11Text: "Lose 7 population.",
			event12: "Instruction Manual",
			event12Text: "The game ends. The player with the most surviving population wins. Tied players share the win.",
			robot0: "Automatic Doors",
			robot0Text: "Lose 5 population.\nAll building abilities are disabled during the next Work before the deck is reshuffled.",
			robot1: "Robot Butler",
			robot1Text: "Lose 4 population, then spend 1 box.",
			robot2: "Cleaning Robot",
			robot2Text: "Lose 6 population.\nIf possible, move 1 box from one of your buildings to another that has more boxes.",
			robot3: "Robot Companion",
			robot3Text: "Lose 7 population.\nYou may spend 1 box to perform any one action.",
			robot4: "Construction Robot",
			robot4Text: "Lose 5 population.\nSet aside 1 hand card as a reserved building. You must build reserved cards before other cards.",
			robot5: "Delivery Drone",
			robot5Text: "Lose 5 population.\nAll players pass 1 hand card to the player on their left at the same time. An empty-handed player can still receive a card.",
			robot6: "Drilling Robot",
			robot6Text: "Lose 5 population.\nYou may also lose one of your buildings. If you do not, lose 3 more population.",
			robot7: "Efficiency Robot",
			robot7Text: "Lose 5 population.\nSpend 1 box or lose 2 money.",
			robot8: "Helpful Robot",
			robot8Text: "Lose 7 population, then draw 1 building card.",
			robot9: "Kitchen Robot",
			robot9Text: "Lose 4 population.\nIf you have less than 8 food, lose 3 more population.",
			robot10: "Military Robot",
			robot10Text: "Lose 7 population, then gain 2 money.",
			robot11: "Mining Robot",
			robot11Text: "Lose 6 population.\nGain 1 money for each of your mining buildings.",
			robot12: "Repairs Robot",
			robot12Text: "Lose 4 population.\nYou cannot perform a Build action during the next Work before the deck is reshuffled.",
			robot13: "Research Robot",
			robot13Text: "Lose 5 population.\nIf you have at least 5 hand cards, discard 1 hand card.",
			robot14: "Robot Doctor",
			robot14Text: "Lose 5 population.\nYou may spend 1 box to gain 2 food.",
			robot15: "Robot Waiter",
			robot15Text: "Lose 4 population, then lose 2 food.",
			robot16: "Security Robot",
			robot16Text: "Find the largest number of buildings owned by any player. Lose that much population.",
			robot17: "Sentient AI",
			robot17Text: "Lose 8 population.\nAdd one Twist card to the shared Progress deck.",
			robot18: "Stacking Robot",
			robot18Text: "Lose 6 population.\nYou may spend any number of boxes to reduce this population loss by 2 for each box spent.",
			robot19: "Warehouse Robot",
			robot19Text: "Lose 7 population.\nIf you have a building without boxes, put 1 box on one such building.",
			twist0: "Regular Shipments",
			twist0Text: "You may pay 2 money to perform a Restock action.",
			twist1: "Risky Research",
			twist1Text: "You may lose 2 population to perform a Research action.",
			twist2: "Surveying",
			twist2Text: "You may bury 1 hand card, or discard all your buried cards to gain 8 money for each card discarded.",
			twist3: "Synthetic Meat",
			twist3Text: "Gain 2 money.\nYou may pay any amount of money to gain 1 food for each money paid.",
			twist4: "Underground City",
			twist4Text: "Gain 1 money for each of your buildings that has boxes.",
			twist5: "University",
			twist5Text: "Gain 1 money for every 3 hand cards, rounded down.",
			twist6: "Animal Research",
			twist6Text: "Lose 1 money for each hand card, then draw 2 building cards.",
			twist7: "Ancillary Products",
			twist7Text: "You may spend 1 box to gain 5 money.",
			twist8: "Blueprints",
			twist8Text: "You may pay 5 money to draw 4 building cards.",
			twist9: "Construction Kits",
			twist9Text: "You may spend 1 box to build a building with a printed cost of at most 4 money. You must still pay the building cost.",
			twist10: "Defunding",
			twist10Text: "Compare your money and food. Lose half of the resource you have more of, rounding the loss down. If the amounts are equal, choose which resource to lose.",
			twist11: "Diversify",
			twist11Text: "If you have a research building, draw 1 building card.\nIf you have a restocking building, gain 1 box.\nIf you have a farming building, gain 2 food.\nIf you have no mining buildings, lose 2 money.",
			twist12: "Emergency Fund",
			twist12Text: "If you have less than 5 money, gain 3 money.",
			twist13: "Engineers",
			twist13Text: "You may lose one of your buildings and return its card to your hand. Transfer its population to your base and resolve its ability when lost as normal.",
			twist14: "Favored Status",
			twist14Text: "You may pay 3 money to choose a personal Perk card and add it to the Progress deck.",
			twist15: "Flexible Plan",
			twist15Text: "Choose one: draw 1 building card, gain 2 money, gain 1 box, or gain 2 food.",
			twist16: "Focus",
			twist16Text: "Choose one of your mining, farming, research, or restocking buildings and resolve its action ability.",
			twist17: "Grand Plan",
			twist17Text: "You may discard 1 hand card to build a building with a printed cost of at least 5 money. You must still pay the building cost.",
			twist18: "Intensive Farming",
			twist18Text: "You may spend 1 box to perform a Farm action.",
			twist19: "Investments",
			twist19Text: "Gain 1 money for every 4 money you already have, rounded down.",
			twist20: "Isolation",
			twist20Text: "If you have no more than 4 buildings, draw 1 building card and gain 2 food.",
			twist21: "Mining Fever",
			twist21Text: "You may pay 2 food to perform a Mine action.",
			twist22: "New Recruits",
			twist22Text: "If you have more hand cards than buildings, gain 3 base population.",
			twist23: "Overtime",
			twist23Text: "You may pay extra money equal to the number of buildings you own to perform a Build action. You must also pay the chosen building cost.",
			twist24: "Reality Show",
			twist24Text: "If you have at least 6 boxes, 6 hand cards, or 6 buildings, gain 3 money.",
			perk0: "Food",
			perk0Text: "Gain 2 food.",
			perk1: "Boxes",
			perk1Text: "Gain 1 box.",
			perk2: "Research",
			perk2Text: "Draw 1 building card.",
			perk3: "Money",
			perk3Text: "Gain 2 money.",
			perk4: "Population",
			perk4Text: "Gain 2 base population.",
			work0: "Work",
			work0Text: "Choose to perform a Mine, Farm, Research, Restock, or Build action.\nResolve its basic action and relevant building abilities in any order.",
			trouble0: "Trouble",
			trouble0Text: "Add the next Event card to the Progress deck.",
			loneliness0: "Loneliness",
			loneliness0Text: "Gain 3 base population for each rings symbol.\nLose 3 population for each star symbol.",
			name: "Moon Colony Bloodbath",
			titleMain: "MOON COLONY",
			titleSubtitle: "BLOODBATH",
			desc: "Build a lunar colony and survive disasters and malfunctioning robots",
			population: "Population",
			base: "Base",
			money: "Money",
			food: "Food",
			boxes: "Boxes",
			hand: "Hand",
			buildings: "Buildings",
			reserved: "Reserved buildings",
			surveyed: "Buried cards",
			perks: "Available personal Perks",
			work: "Work",
			mine: "Mine",
			farm: "Farm",
			research: "Research",
			restock: "Restock",
			build: "Build",
			cycle: "Progress deck cycle {{n}}",
			turn: "Progress card {{n}}",
			waiting: "Waiting for other players",
			resolving: "Resolving",
			next: "Revealing next Progress card",
			choose: "Make a choice",
			window: "Choose the next ability or basic action",
			choosework: "Choose your Work action",
			buildChoice: "Choose a building to build",
			loss: "Your base has too little population. Choose a building to lose",
			remove: "Choose a building to lose",
			discard: "Choose a hand card to discard",
			box: "Choose a building for the box",
			spendBox: "Choose a building to spend a box from",
			perk: "Choose a personal Perk card to add to the Progress deck",
			move: "Choose the buildings to move a box from and to",
			pass: "Choose a card to pass left",
			reserve: "Choose a building card to build before other cards",
			survey: "Choose a hand card to bury, or sell all buried cards",
			focus: "Choose a building action ability",
			repeat: "Choose an ability marked When built to repeat",
			accident: "You may spend 1 box from Organ Banks to ignore this Accident",
			stack: "You may spend boxes to reduce this population loss",
			crater: "You may exchange boxes for 2 money each",
			synthetic: "Choose a payment to exchange for food",
			defund: "Choose which resource to lose",
			optional: "Use this ability?",
			anyAction: "Choose an extra action",
			skip: "Do not use this ability",
			continue: "Continue",
			finish: "Finish",
			use: "Use ability",
			baseEffect: "Basic action",
			ability: "Building ability",
			play: "Ability when built",
			lost: "Ability when lost",
			payment: "Pay {{money}} money and {{food}} food",
			spend: "Spend {{n}} boxes",
			amount: "Pay {{n}} money",
			sell: "Sell all buried cards ({{n}})",
			moveBox: "Move 1 box",
			storage: "Spend 1 box from Research and Development Storage to draw 1 building card",
			progressDeck: "Progress deck",
			buildingDeck: "Building deck",
			remaining: "{{n}} remaining",
			initial: "Initial Twists",
			events: "{{n}} of 13 Event cards added",
			extra: "{{n}} extra Robot cards added",
			inspect: "Inspect cards",
			close: "Close",
			none: "None",
			beginner: "Starting Twists",
			simple: "Simple Twists",
			all: "All Twists",
			soloMode: "Solo challenge",
			normal: "Standard challenge",
			extended: "Extended challenge",
			soloHint: "Solo play adds Loneliness. The extended challenge replaces the thirteenth Event and later Events with Robots, scoring the extra Robot cards added.",
			errAction: "That action is not available now",
			errTick: "Only the host can advance progress",
			resultPopulation: "Base population: {{base}}. Building population: {{buildings}}. Total population: {{total}}.",
			resultSolo: "Event cards added: {{n}}. Extra Robot cards added: {{extra}}.",
			resultManual: "Instruction Manual was revealed. The game has ended",
			resultDeath: "A colony has run out of population",
			muted: "All building abilities are disabled during this Work",
			closed: "No building during the next Work",
			rings: "Solo play: gain 3 base population during Loneliness",
			star: "Solo play: lose 3 population during Loneliness",
			selected: "Selected; waiting to reveal together",
			log: "Progress history",
			cost: "Cost",
			viewColony: "View colony",
			rules: "Game objective:\nThe game ends when any colony runs out of population or Instruction Manual is revealed. In multiplayer, the player with the most surviving population wins. Tied players share the win.\nSetup:\nEach player starts with 30 base population, 4 money, and 4 food, draws 4 building cards, and receives one of each of the 5 personal Perk cards.\nThe Progress deck starts with 4 Work cards, 2 Trouble cards, and 2 random Twist cards. The game setting determines whether starting Twists are drawn from simple Twists or all Twists.\nTurn sequence:\nReveal 1 Progress card. All players resolve its effects at the same time. Reveal the next card after every player has finished. Trouble adds the next Event card to the Progress deck; Glitch adds one Robot card.\nPut newly added Progress cards on top of the deck. Shuffle cards added together before placing them there. Reshuffle the Progress discards only when a card must be revealed and the deck is empty. You may add new cards to an empty deck without reshuffling the discards yet.\nBasic actions:\nDuring Work, each player chooses one action. Building cards are chosen secretly, then revealed together.\n· Mine: Gain 4 money.\n· Farm: Gain 4 food.\n· Research: Draw 2 building cards.\n· Restock: Gain 2 boxes, choosing a building for each box.\n· Build: Choose 1 building card, pay its building cost, and place it in your colony.\nYou may resolve the basic action and the relevant building abilities in any order. Extra actions also trigger the relevant building abilities. You may repeat an action.\nBuildings and boxes:\nYour total population is your base population plus the printed population of all your buildings. A new building brings its printed population; you do not move that population out of your base. Effects that grant population normally add it to your base, unless the card says otherwise.\nBoxes must be placed on your buildings. A building may hold more than one box. Duplicate building abilities usually stack. Optional effects require their full payment.\nAbilities marked When built or When lost trigger when that building is built or lost. Personal Perk cards can recur after joining the Progress deck, but only their owner benefits.\nPopulation loss:\nPay population losses from your base first. If your base has too little population, lose one building and move its printed population to your base. Discard the lost building and all its boxes, and fully resolve its ability when lost. Then resume the remaining population loss. You may need to lose more buildings. You may lose buildings only when instructed by the rules or a card.\nDuring Hunger, pay 1 food per building. Apply the exemptions from Flag and Greenhouse. Lose 1 population for each food you cannot pay, treating the total shortage as one population loss. If Hunger causes you no population loss, gain 2 base population.\nSolo play:\nAdd one Loneliness card to the starting Progress deck. During Loneliness, gain 3 base population per rings symbol and lose 3 population per star symbol.\n· Standard challenge: Win by reaching Instruction Manual. If your population runs out first, the challenge is lost. If you lose, score the highest Event number added to the Progress deck.\n· Extended challenge: Add Robot cards instead of the thirteenth Event and all later Events. Continue until your colony runs out of population, and score the number of extra Robot cards added.\nUsing the interface:\nYour hand, reserved buildings, and buried cards are private. Only the top building discard is public. Buildings and hand cards share one page; scroll down to view the remaining cards.\n· Select an available card, then use the confirmation button below. Use the information button to inspect a card.\n· All choices lists the available actions. When several payments are possible, choose one in the lower bar.\n· You may use Research and Development Storage before submitting a choice, but not after submitting it.\n· When discarding several hand cards, select the required number before discarding them together.",
			payFood: "Pay {{n}} food",
			discardFor: "Discard {{n}} hand cards",
			payPopulation: "Lose {{n}} population",
			discardTop: "Inspect the top building discard",
			loseBuilding: "Lose building",
			lossAmount: "{{n}} population loss remains. Choose a building to lose",
			discardAmount: "Select {{n}} more cards to discard",
			stackAmount: "{{n}} population loss remains. You may spend boxes to reduce it",
			paymentMethod: "Payment method",
			allChoices: "All choices",
			confirm: "Confirm selection",
			ready: "Done",
			pending: "Choosing",
			playPrefix: "When built:",
			lostPrefix: "When lost:",
			chooseAction: "Perform a {{action}} action",
			resolveAction: "Resolve the basic {{action}} action",
			placeBox: "Place 1 box",
			consumeBox: "Spend 1 box",
			buryCard: "Bury 1 hand card",
			reserveCard: "Reserve this card to build before other cards",
			passCard: "Pass 1 hand card to the player on your left",
			gainMoney: "Gain {{n}} money",
			gainFood: "Gain {{n}} food",
			gainBox: "Gain {{n}} box",
			gainPopulation: "Gain {{n}} base population",
			drawBuilding: "Draw {{n}} building card",
			marketFood: "Pay 2 food to gain 4 money",
			marketDiscard: "Discard 1 hand card to gain 4 money",
			loseHalfMoney: "Lose half your money, rounding the loss down",
			loseHalfFood: "Lose half your food, rounding the loss down",
			declineBuilding: "Keep your buildings and lose 3 population",
			finishLoss: "Take the remaining population loss",
			finishExchange: "Finish exchanging boxes",
			cardCost: "Building cost: {{n}} money",
			cardPopulation: "Building population: {{n}}"
		}
	}
};
//#endregion
export { Ue as default };
