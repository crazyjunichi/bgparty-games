import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as s } from "@bgparty/sdk/ui/phase-banner";
import { AVATARS as c } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { BottomSheet as u } from "@bgparty/sdk/bottom-sheet";
import { IconClose as d, IconHistory as f, IconRotate as p } from "@bgparty/sdk/icons";
import { DeltaNumber as m } from "@bgparty/sdk/fx/delta-number";
import { useT as h } from "@bgparty/sdk/i18n";
import { SheetView as g } from "@bgparty/sdk/sheet-view";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { OptionRadio as b, OptionSection as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/1817/meta.ts
var S = {
	id: "1817",
	tier: "alpha",
	mechanics: [
		"stock-holding",
		"route-building",
		"tile-placement",
		"auction"
	],
	interactionTags: [],
	nameKey: "games.1817.name",
	descKey: "games.1817.desc",
	rulesKey: "games.1817.rules",
	icon: "🚂",
	iconImg: "games/1817.webp",
	minPlayers: 3,
	maxPlayers: 7,
	bestPlayers: [4, 5],
	accent: "#213c37",
	releasedAt: "2026-11-10T03:31:09+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "open",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/0252/9371/7588/files/1817_Rules_v1.0_-_5_March_2015.pdf" }
}, C = t.int().min(0).max(1e6), w = t.int().min(0).max(19), T = t.string().regex(/^[A-J][1-9][0-9]?$/), E = t.union([
	t.literal(2),
	t.literal(5),
	t.literal(10)
]), D = t.object({
	increasedShorts: t.boolean().default(!1),
	shortSqueeze: t.boolean().default(!1),
	modernTrains: t.boolean().default(!1)
}).prefault({}), O = t.discriminatedUnion("type", [
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("bid"),
		amount: C
	}),
	t.object({
		type: t.literal("private"),
		id: t.int().min(0).max(10),
		amount: C
	}),
	t.object({
		type: t.literal("ipo"),
		company: w,
		hex: T,
		city: t.int().min(0).max(1),
		amount: C
	}),
	t.object({
		type: t.literal("fund"),
		size: E,
		privates: t.array(t.int().min(0).max(10)).max(11)
	}),
	t.object({
		type: t.literal("buy"),
		company: w,
		source: t.enum(["treasury", "market"])
	}),
	t.object({
		type: t.literal("sell"),
		company: w,
		count: t.int().min(1).max(10)
	}),
	t.object({
		type: t.literal("short"),
		company: w
	}),
	t.object({
		type: t.literal("company"),
		company: w,
		loans: t.int().min(0).max(10),
		shares: t.int().min(0).max(30)
	}),
	t.object({
		type: t.literal("loan"),
		count: t.int().min(1).max(10)
	}),
	t.object({
		type: t.literal("repay"),
		count: t.int().min(0).max(10)
	}),
	t.object({
		type: t.literal("lay"),
		hex: T,
		tile: t.string().max(4),
		rotation: t.int().min(0).max(5),
		mine: t.int().min(0).max(10).nullable()
	}),
	t.object({
		type: t.literal("bridge"),
		hex: T,
		private: t.int().min(0).max(10)
	}),
	t.object({
		type: t.literal("token"),
		hex: T,
		city: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("routes"),
		routes: t.array(t.object({
			train: t.int().min(0),
			paths: t.array(t.string().max(20)).max(200)
		})).max(8)
	}),
	t.object({
		type: t.literal("dividend"),
		mode: t.enum([
			"full",
			"half",
			"withhold"
		])
	}),
	t.object({
		type: t.literal("train"),
		train: t.string().max(8),
		seller: w.nullable(),
		price: C
	}),
	t.object({
		type: t.literal("answer"),
		accept: t.boolean()
	}),
	t.object({
		type: t.literal("discard"),
		train: t.int().min(0)
	}),
	t.object({ type: t.literal("convert") }),
	t.object({
		type: t.literal("merge"),
		company: w,
		survivor: w
	}),
	t.object({ type: t.literal("offer") }),
	t.object({
		type: t.literal("purchase"),
		company: w,
		loans: t.int().min(0).max(10),
		repay: t.int().min(0).max(10)
	}),
	t.object({
		type: t.literal("keepTokens"),
		tokens: t.array(t.string().max(15)).max(8)
	}),
	t.object({ type: t.literal("bankrupt") })
]), k = t.object({
	rid: t.string(),
	cash: t.int(),
	shares: t.array(t.int().min(0)),
	shorts: t.array(t.int().min(0)),
	privates: t.array(t.int().min(0)),
	bankrupt: t.boolean(),
	sold: t.array(w)
}), A = t.object({
	id: t.int(),
	kind: t.string(),
	obsolete: t.boolean()
}), j = t.object({
	id: w,
	size: E,
	president: t.string().nullable(),
	active: t.boolean(),
	cash: t.int(),
	loans: t.int().min(0),
	price: t.int().min(0).max(31),
	order: t.int(),
	treasury: t.int().min(0),
	market: t.int().min(0),
	bankShorts: t.int().min(0),
	tokens: t.int().min(0).max(16),
	tokenDebt: t.int().min(0),
	privates: t.array(t.int().min(0)),
	trains: t.array(A),
	started: t.int(),
	changed: t.int(),
	liquidationOrder: t.int()
}), ee = t.object({
	tile: t.string(),
	rotation: t.int(),
	mine: t.boolean(),
	bridge: t.boolean(),
	tokens: t.array(t.object({
		company: w,
		city: t.int()
	}))
}), te = t.object({
	kind: t.enum([
		"private",
		"ipo",
		"liquidation",
		"acquisition",
		"friendly"
	]),
	target: t.int(),
	hex: t.string(),
	city: t.int(),
	bid: t.int(),
	leader: t.string().nullable(),
	passed: t.array(t.string()),
	initiator: t.string(),
	next: t.string()
}), ne = t.object({
	kind: t.enum(["merge", "train"]),
	proposer: t.string(),
	recipient: t.string(),
	company: w,
	target: w,
	survivor: w,
	train: t.int(),
	price: t.int()
}), re = t.object({
	config: D,
	seed: t.int(),
	players: t.array(k),
	companies: t.array(j),
	board: t.record(t.string(), ee),
	phase: t.enum([
		"initial",
		"auction",
		"funding",
		"stock",
		"operating",
		"merger",
		"post",
		"sale",
		"purchase",
		"done"
	]),
	actor: t.string(),
	priority: t.string(),
	round: t.int(),
	operatingRound: t.int(),
	phaseNumber: t.int(),
	current: t.int(),
	step: t.int(),
	passes: t.int(),
	lastActor: t.string(),
	stockStep: t.int(),
	stockActed: t.boolean(),
	seedMoney: t.int(),
	availablePrivates: t.array(t.int()),
	privateUses: t.array(t.int()),
	auction: te.nullable(),
	trade: ne.nullable(),
	queue: t.array(w),
	saleQueue: t.array(w),
	pendingSale: t.boolean().default(!1),
	maRound: t.int(),
	postCompany: t.int(),
	postPlayers: t.array(t.string()),
	postIndex: t.int(),
	postPresident: t.string(),
	postForced: t.boolean(),
	postTokenCost: t.int(),
	maPrices: t.array(t.int()),
	orSetEnd: t.int(),
	crisisCompany: t.int(),
	crisisAmount: t.int(),
	interest: t.int(),
	depotIndex: t.int(),
	depotRemaining: t.array(t.int()),
	openTrains: t.array(A),
	trainSerial: t.int(),
	orderSerial: t.int(),
	lays: t.array(t.string()),
	upgraded: t.boolean(),
	tokenPlaced: t.boolean(),
	revenue: t.int(),
	routes: t.array(t.object({
		train: t.int(),
		paths: t.array(t.string()),
		revenue: t.int()
	})),
	endAt: t.int().nullable(),
	crisis: t.string().nullable(),
	discardCompany: t.int().nullable(),
	excessTokens: t.int().nullable(),
	log: t.array(t.object({
		key: t.string(),
		rid: t.string(),
		company: t.int(),
		amount: t.number(),
		detail: t.string()
	}))
}), ie = t.object({}), ae = [
	0,
	0,
	0,
	0,
	40,
	45,
	50,
	55,
	60,
	65,
	70,
	80,
	90,
	100,
	110,
	120,
	135,
	150,
	165,
	180,
	200,
	220,
	245,
	270,
	300,
	330,
	360,
	400,
	440,
	490,
	540,
	600
], M = [
	40,
	40,
	40,
	80,
	80,
	30,
	60,
	90,
	60,
	90,
	120
], N = [
	"2",
	"2+",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8"
], P = [
	100,
	100,
	250,
	400,
	600,
	750,
	900,
	1100
], F = [
	999999,
	4,
	12,
	8,
	5,
	4,
	3,
	999999
];
function oe(e, t) {
	let n = t.startsWith("bank:"), r = t.startsWith("open:"), i = r ? t.slice(5) : t, a = n ? void 0 : e.openTrains.find((e) => String(e.id) === i);
	if (r) return a ? {
		open: a,
		kind: a.kind
	} : null;
	let o = N[e.depotIndex];
	return a ? {
		open: a,
		kind: a.kind
	} : (n ? t.slice(5) : t) === o ? {
		open: void 0,
		kind: o
	} : null;
}
var se = (e) => e >= 6 ? 2 : e >= 4 ? 3 : 4, ce = (e) => e >= 6 ? [10] : e === 5 ? [5, 10] : e === 4 ? [5] : e === 3 ? [2, 5] : [2], le = (e) => e.companies.reduce((e, t) => e + t.loans, 0), I = (e) => ae[e.price], ue = (e) => ae.reduce((t, n, r) => n > 0 && n <= e ? r : t, 4), de = (e, t) => t.shares.reduce((n, r, i) => n + r - +(e.companies[i].president === t.rid && r >= 2), 0), fe = (e) => ({
	3: 21,
	4: 16,
	5: 13,
	6: 11,
	7: 9
})[Math.max(3, e.players.filter((e) => !e.bankrupt).length)], pe = (e) => e.size === 2 ? 2 : e.size === 5 ? 3 : 6, L = (e, t) => e.players.find((e) => e.rid === t);
function me(e, t) {
	let n = [];
	for (let r = 0; r < 2 ** e.privates.length; r++) {
		let i = e.privates.filter((e, t) => r & 2 ** t), a = i.reduce((e, t) => e + M[t], 0);
		a <= t && t - a <= e.cash && n.push(i);
	}
	return n;
}
function R(e, t) {
	let n = e.players.findIndex((e) => e.rid === t);
	for (let t = 1; t <= e.players.length; t++) {
		let r = e.players[(n + t) % e.players.length];
		if (!r.bankrupt) return r.rid;
	}
	return t;
}
var he = (e, t) => t.cash + t.shares.reduce((n, r, i) => n + (r - t.shorts[i]) * I(e.companies[i]), 0);
function z(e, t, n) {
	let r = Math.max(1, Math.min(31, t.price + n));
	r !== t.price && (t.price = r, t.order = ++e.orderSerial);
}
function B(e, t, n) {
	if (n < 0 || t.loans + n > t.size || le(e) + n > 70 || !t.active || t.price === 0) return !1;
	t.loans += n, t.cash += 100 * n;
	for (let r = 0; r < n; r++) z(e, t, -1);
	return !0;
}
function ge(e, t) {
	for (let n of e.players) {
		let e = Math.min(n.shares[t.id], n.shorts[t.id]);
		n.shares[t.id] -= e, n.shorts[t.id] -= e;
	}
	let n = Math.min(t.market, t.bankShorts);
	t.market -= n, t.bankShorts -= n;
}
function _e(e, t) {
	if (t.size === 2) return;
	let n = t.president ? L(e, t.president) : null, r = n && !n.bankrupt ? n : null, i = n ? e.players.indexOf(n) : 0;
	for (let n = 1; n <= e.players.length; n++) {
		let a = e.players[(i + n) % e.players.length];
		!a.bankrupt && a.shares[t.id] >= 2 && (!r || a.shares[t.id] > r.shares[t.id]) && (r = a);
	}
	r && (t.president = r.rid);
}
function V(e, t, n, r, i = !1) {
	return !t.bankrupt && n.active && n.price >= 4 && n.size !== 2 && !!n.president && (r === "treasury" ? n.treasury > 0 : n.market > 0) && t.cash >= I(n) && (i || !t.sold.includes(n.id)) && (t.shorts[n.id] > 0 || t.shares[n.id] < pe(n) && de(e, t) < fe(e));
}
function H(e, t, n, r, i = !1, a = !1) {
	if (!n.active || n.size === 2 || n.price < 4 || r > t.shares[n.id] || r < 1 || !a && n.started === e.round && e.phase === "stock") return !1;
	if (n.president !== t.rid) return !0;
	let o = t.shares[n.id] - r;
	return i ? o >= 2 && e.players.every((e) => e.bankrupt || e.rid === t.rid || e.shares[n.id] <= o) : o >= 2 || e.players.some((e) => !e.bankrupt && e.rid !== t.rid && e.shares[n.id] >= 2);
}
function ve(e, t, n) {
	let r = e.config.increasedShorts && n.size === 10 ? 10 : 5;
	return e.phaseNumber < 8 && n.active && n.size !== 2 && n.price >= 4 && n.started !== e.round && t.shares[n.id] === 0 && e.players.reduce((e, t) => e + t.shorts[n.id], n.bankShorts) < r;
}
function ye(e) {
	return e.companies.filter((e) => e.active).sort((e, t) => t.price - e.price || e.order - t.order).map((e) => e.id);
}
function be(e, t, n) {
	let r = e.auction;
	if (!r) return [];
	let i = e.companies[r.target], a = r.kind === "liquidation" ? 0 : i.loans, o = r.kind === "liquidation" ? 0 : i.cash + (r.kind === "friendly" ? i.treasury * I(i) : 0);
	return e.companies.filter((r) => {
		if (!r.active || r.id === i.id || r.president !== t || r.price < 4) return !1;
		let s = Math.max(0, r.loans + a - r.size), c = Math.min(70 - le(e) + s, r.size - r.loans - a + s);
		return r.cash + o + c * 100 - s * 100 >= n;
	});
}
//#endregion
//#region src/games/1817/components.ts
var xe = {
	5: {
		color: "yellow",
		code: "city=revenue:20;path=a:0,b:_0;path=a:1,b:_0"
	},
	6: {
		color: "yellow",
		code: "city=revenue:20;path=a:0,b:_0;path=a:2,b:_0"
	},
	7: {
		color: "yellow",
		code: "path=a:0,b:1"
	},
	8: {
		color: "yellow",
		code: "path=a:0,b:2"
	},
	9: {
		color: "yellow",
		code: "path=a:0,b:3"
	},
	57: {
		color: "yellow",
		code: "city=revenue:20;path=a:0,b:_0;path=a:_0,b:3"
	},
	14: {
		color: "green",
		code: "city=revenue:30,slots:2;path=a:0,b:_0;path=a:1,b:_0;path=a:3,b:_0;path=a:4,b:_0"
	},
	15: {
		color: "green",
		code: "city=revenue:30,slots:2;path=a:0,b:_0;path=a:1,b:_0;path=a:2,b:_0;path=a:3,b:_0"
	},
	54: {
		color: "green",
		code: "city=revenue:60,loc:0.5;city=revenue:60,loc:2.5;path=a:0,b:_0;path=a:_0,b:1;path=a:2,b:_1;path=a:_1,b:3;label=NY"
	},
	80: {
		color: "green",
		code: "junction;path=a:0,b:_0;path=a:1,b:_0;path=a:2,b:_0"
	},
	81: {
		color: "green",
		code: "junction;path=a:0,b:_0;path=a:2,b:_0;path=a:4,b:_0"
	},
	82: {
		color: "green",
		code: "junction;path=a:0,b:_0;path=a:1,b:_0;path=a:3,b:_0"
	},
	83: {
		color: "green",
		code: "junction;path=a:0,b:_0;path=a:5,b:_0;path=a:3,b:_0"
	},
	592: {
		color: "green",
		code: "city=revenue:50,slots:2;path=a:0,b:_0;path=a:2,b:_0;path=a:4,b:_0;label=B"
	},
	619: {
		color: "green",
		code: "city=revenue:30,slots:2;path=a:0,b:_0;path=a:2,b:_0;path=a:3,b:_0;path=a:4,b:_0"
	},
	62: {
		color: "brown",
		code: "city=revenue:80,slots:2;city=revenue:80,slots:2;path=a:0,b:_0;path=a:_0,b:1;path=a:2,b:_1;path=a:_1,b:3;label=NY"
	},
	63: {
		color: "brown",
		code: "city=revenue:40,slots:2;path=a:0,b:_0;path=a:1,b:_0;path=a:2,b:_0;path=a:3,b:_0;path=a:4,b:_0;path=a:5,b:_0"
	},
	448: {
		color: "brown",
		code: "city=revenue:40,slots:2;path=a:0,b:_0;path=a:1,b:_0;path=a:2,b:_0;path=a:3,b:_0"
	},
	544: {
		color: "brown",
		code: "junction;path=a:0,b:_0;path=a:1,b:_0;path=a:3,b:_0;path=a:4,b:_0"
	},
	545: {
		color: "brown",
		code: "junction;path=a:0,b:_0;path=a:1,b:_0;path=a:2,b:_0;path=a:3,b:_0"
	},
	546: {
		color: "brown",
		code: "junction;path=a:0,b:_0;path=a:2,b:_0;path=a:3,b:_0;path=a:4,b:_0"
	},
	593: {
		color: "brown",
		code: "city=revenue:60,slots:3;path=a:0,b:_0;path=a:2,b:_0;path=a:3,b:_0;path=a:4,b:_0;label=B"
	},
	611: {
		color: "brown",
		code: "city=revenue:40,slots:2;path=a:0,b:_0;path=a:1,b:_0;path=a:2,b:_0;path=a:3,b:_0;path=a:4,b:_0"
	},
	597: {
		color: "gray",
		code: "city=revenue:80,slots:3;path=a:0,b:_0;path=a:1,b:_0;path=a:2,b:_0;path=a:3,b:_0;path=a:4,b:_0;label=B"
	},
	X00: {
		color: "yellow",
		code: "city=revenue:30;path=a:1,b:_0;path=a:3,b:_0;path=a:5,b:_0;label=B"
	},
	X30: {
		color: "gray",
		code: "city=revenue:100,slots:4;path=a:2,b:_0;path=a:3,b:_0;path=a:4,b:_0;path=a:5,b:_0;label=NY"
	}
}, Se = {
	A20: {
		color: "red",
		code: "offboard=revenue:yellow_20|green_30|brown_50|gray_60;path=a:5,b:_0;path=a:0,b:_0",
		name: "Montréal"
	},
	A28: {
		color: "red",
		code: "offboard=revenue:yellow_20|green_30|brown_50|gray_60;path=a:0,b:_0",
		name: "Maritime Prov."
	},
	D1: {
		color: "red",
		code: "offboard=revenue:yellow_30|green_50|brown_60|gray_80;path=a:4,b:_0;path=a:5,b:_0",
		name: "Chicago"
	},
	H1: {
		color: "red",
		code: "offboard=revenue:yellow_20|green_30|brown_50|gray_60;path=a:3,b:_0;path=a:4,b:_0;path=a:5,b:_0",
		name: "St. Louis"
	},
	J7: {
		color: "red",
		code: "offboard=revenue:yellow_30|green_50|brown_60|gray_80;path=a:2,b:_0;path=a:3,b:_0",
		name: "Atlanta"
	},
	J15: {
		color: "red",
		code: "offboard=revenue:yellow_20|green_30|brown_50|gray_60;path=a:2,b:_0;path=a:3,b:_0",
		name: "Raleigh-Durham"
	},
	B5: {
		color: "white",
		code: "city=revenue:0",
		name: "Lansing"
	},
	B17: {
		color: "white",
		code: "city=revenue:0",
		name: "Rochester"
	},
	C14: {
		color: "white",
		code: "city=revenue:0",
		name: "Buffalo"
	},
	C22: {
		color: "white",
		code: "city=revenue:0",
		name: "Albany"
	},
	F3: {
		color: "white",
		code: "city=revenue:0",
		name: "Indianapolis"
	},
	F13: {
		color: "white",
		code: "city=revenue:0",
		name: "Pittsburgh"
	},
	F19: {
		color: "white",
		code: "city=revenue:0",
		name: "Philadelphia"
	},
	I16: {
		color: "white",
		code: "city=revenue:0",
		name: "Richmond"
	},
	D7: {
		color: "white",
		code: "city=revenue:0;upgrade=cost:20,terrain:lake",
		name: "Toledo"
	},
	D19: {
		color: "white",
		code: "city=revenue:0;upgrade=cost:15,terrain:mountain",
		name: "Scranton"
	},
	I12: {
		color: "white",
		code: "city=revenue:0;upgrade=cost:15,terrain:mountain",
		name: "Blacksburg"
	},
	G6: {
		color: "white",
		code: "city=revenue:0;upgrade=cost:10,terrain:water",
		name: "Cincinnati"
	},
	H3: {
		color: "white",
		code: "city=revenue:0;upgrade=cost:10,terrain:water",
		name: "Louisville"
	},
	H9: {
		color: "white",
		code: "city=revenue:0;upgrade=cost:10,terrain:water",
		name: "Charleston"
	},
	B25: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	C20: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	C24: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	E16: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	E18: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	F15: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	G12: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	G14: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	H11: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	H13: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	H15: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	I8: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	I10: {
		color: "white",
		code: "upgrade=cost:15,terrain:mountain",
		name: ""
	},
	D13: {
		color: "white",
		code: "upgrade=cost:10,terrain:water",
		name: ""
	},
	E12: {
		color: "white",
		code: "upgrade=cost:10,terrain:water",
		name: ""
	},
	F11: {
		color: "white",
		code: "upgrade=cost:10,terrain:water",
		name: ""
	},
	G4: {
		color: "white",
		code: "upgrade=cost:10,terrain:water",
		name: ""
	},
	G10: {
		color: "white",
		code: "upgrade=cost:10,terrain:water",
		name: ""
	},
	H7: {
		color: "white",
		code: "upgrade=cost:10,terrain:water",
		name: ""
	},
	B9: {
		color: "white",
		code: "upgrade=cost:20,terrain:lake",
		name: ""
	},
	B27: {
		color: "white",
		code: "upgrade=cost:20,terrain:lake",
		name: ""
	},
	D25: {
		color: "white",
		code: "upgrade=cost:20,terrain:lake",
		name: ""
	},
	D27: {
		color: "white",
		code: "upgrade=cost:20,terrain:lake",
		name: ""
	},
	G20: {
		color: "white",
		code: "upgrade=cost:20,terrain:lake",
		name: ""
	},
	H17: {
		color: "white",
		code: "upgrade=cost:20,terrain:lake",
		name: ""
	},
	B3: {
		color: "white",
		code: "",
		name: ""
	},
	B7: {
		color: "white",
		code: "",
		name: ""
	},
	B11: {
		color: "white",
		code: "",
		name: ""
	},
	B15: {
		color: "white",
		code: "",
		name: ""
	},
	B19: {
		color: "white",
		code: "",
		name: ""
	},
	B21: {
		color: "white",
		code: "",
		name: ""
	},
	B23: {
		color: "white",
		code: "",
		name: ""
	},
	C4: {
		color: "white",
		code: "",
		name: ""
	},
	C6: {
		color: "white",
		code: "",
		name: ""
	},
	C16: {
		color: "white",
		code: "",
		name: ""
	},
	C18: {
		color: "white",
		code: "",
		name: ""
	},
	D3: {
		color: "white",
		code: "",
		name: ""
	},
	D5: {
		color: "white",
		code: "",
		name: ""
	},
	D15: {
		color: "white",
		code: "",
		name: ""
	},
	D17: {
		color: "white",
		code: "",
		name: ""
	},
	D21: {
		color: "white",
		code: "",
		name: ""
	},
	D23: {
		color: "white",
		code: "",
		name: ""
	},
	E2: {
		color: "white",
		code: "",
		name: ""
	},
	E4: {
		color: "white",
		code: "",
		name: ""
	},
	E6: {
		color: "white",
		code: "",
		name: ""
	},
	E8: {
		color: "white",
		code: "",
		name: ""
	},
	E10: {
		color: "white",
		code: "",
		name: ""
	},
	E14: {
		color: "white",
		code: "",
		name: ""
	},
	E20: {
		color: "white",
		code: "",
		name: ""
	},
	F5: {
		color: "white",
		code: "",
		name: ""
	},
	F7: {
		color: "white",
		code: "",
		name: ""
	},
	F9: {
		color: "white",
		code: "",
		name: ""
	},
	F17: {
		color: "white",
		code: "",
		name: ""
	},
	F21: {
		color: "white",
		code: "",
		name: ""
	},
	G2: {
		color: "white",
		code: "",
		name: ""
	},
	G8: {
		color: "white",
		code: "",
		name: ""
	},
	G16: {
		color: "white",
		code: "",
		name: ""
	},
	H5: {
		color: "white",
		code: "",
		name: ""
	},
	I2: {
		color: "white",
		code: "",
		name: ""
	},
	I4: {
		color: "white",
		code: "",
		name: ""
	},
	I6: {
		color: "white",
		code: "",
		name: ""
	},
	I14: {
		color: "white",
		code: "",
		name: ""
	},
	C10: {
		color: "white",
		code: "border=edge:5,type:impassable",
		name: ""
	},
	D11: {
		color: "white",
		code: "border=edge:2,type:impassable",
		name: ""
	},
	B13: {
		color: "gray",
		code: "town=revenue:yellow_20|green_30|brown_40;path=a:1,b:_0;path=a:4,b:_0;path=a:5,b:_0",
		name: "Toronto"
	},
	D9: {
		color: "gray",
		code: "city=revenue:yellow_30|green_40|brown_50|gray_60,slots:2;path=a:5,b:_0;path=a:0,b:_0",
		name: "Cleveland"
	},
	F1: {
		color: "gray",
		code: "junction;path=a:4,b:_0;path=a:3,b:_0;path=a:5,b:_0",
		name: ""
	},
	C8: {
		color: "yellow",
		code: "city=revenue:30;path=a:4,b:_0;path=a:0,b:_0;label=B;upgrade=cost:20,terrain:lake",
		name: "Detroit"
	},
	C26: {
		color: "yellow",
		code: "city=revenue:30;path=a:3,b:_0;path=a:5,b:_0;label=B",
		name: "Boston"
	},
	E22: {
		color: "yellow",
		code: "city=revenue:40;city=revenue:40;path=a:0,b:_0;path=a:3,b:_1;label=NY;upgrade=cost:20,terrain:lake",
		name: "New York"
	},
	G18: {
		color: "yellow",
		code: "city=revenue:30;path=a:4,b:_0;path=a:0,b:_0;label=B",
		name: "Baltimore"
	}
}, U = [
	{
		symbol: "A&S",
		name: "Alton & Southern Railway",
		color: "#ee3e80"
	},
	{
		symbol: "A&A",
		name: "Arcade and Attica",
		color: "#904098"
	},
	{
		symbol: "Belt",
		name: "Belt Railway of Chicago",
		color: "#f2a847"
	},
	{
		symbol: "Bess",
		name: "Bessemer and Lake Erie Railroad",
		color: "#16190e"
	},
	{
		symbol: "B&A",
		name: "Boston and Albany Railroad",
		color: "#ef4223"
	},
	{
		symbol: "DL&W",
		name: "Delaware, Lackawanna and Western Railroad",
		color: "#984573"
	},
	{
		symbol: "J",
		name: "Elgin, Joliet and Eastern Railway",
		color: "#bedb86"
	},
	{
		symbol: "GT",
		name: "Grand Trunk Western Railroad",
		color: "#e48329"
	},
	{
		symbol: "H",
		name: "Housatonic Railroad",
		color: "#bedef3"
	},
	{
		symbol: "ME",
		name: "Morristown and Erie Railway",
		color: "#ffdea8"
	},
	{
		symbol: "NYOW",
		name: "New York, Ontario and Western Railway",
		color: "#0095da"
	},
	{
		symbol: "NYSW",
		name: "New York, Susquehanna and Western Railway",
		color: "#fff36b"
	},
	{
		symbol: "PSNR",
		name: "Pittsburgh, Shawmut and Northern Railroad",
		color: "#0a884b"
	},
	{
		symbol: "PLE",
		name: "Pittsburgh and Lake Erie Railroad",
		color: "#00afad"
	},
	{
		symbol: "PW",
		name: "Providence and Worcester Railroad",
		color: "#bec8cc"
	},
	{
		symbol: "R",
		name: "Rutland Railroad",
		color: "#165633"
	},
	{
		symbol: "SR",
		name: "Strasburg Railroad",
		color: "#e31f21"
	},
	{
		symbol: "UR",
		name: "Union Railroad",
		color: "#003d84"
	},
	{
		symbol: "WT",
		name: "Warren & Trumbull Railroad",
		color: "#e96f2c"
	},
	{
		symbol: "WC",
		name: "West Chester Railroad",
		color: "#984d2d"
	}
];
//#endregion
//#region src/games/1817/rail-trail.ts
function Ce(e) {
	let t = e.length, n = Array(t).fill(-1), r = Array(t), i = Array(t), a = Array(t), o = Array(t);
	if (t % 2) return null;
	let s = (e, a) => {
		let o = Array(t).fill(!1);
		for (; e = i[e], o[e] = !0, !(n[e] < 0);) e = r[n[e]];
		for (;;) {
			if (a = i[a], o[a]) return a;
			a = r[n[a]];
		}
	}, c = (e, t, a) => {
		for (; i[e] !== t;) o[i[e]] = o[i[n[e]]] = !0, r[e] = a, a = n[e], e = r[n[e]];
	}, l = (l) => {
		a.fill(!1), r.fill(-1);
		for (let e = 0; e < t; e++) i[e] = e;
		let u = [l];
		a[l] = !0;
		for (let d = 0; d < u.length; d++) {
			let f = u[d];
			for (let d of e[f]) if (i[f] !== i[d] && n[f] !== d) {
				if (d === l || n[d] >= 0 && r[n[d]] >= 0) {
					let e = s(f, d);
					o.fill(!1), c(f, e, d), c(d, e, f);
					for (let n = 0; n < t; n++) o[i[n]] && (i[n] = e, a[n] || (a[n] = !0, u.push(n)));
				} else if (r[d] < 0) {
					if (r[d] = f, n[d] < 0) {
						for (; d >= 0;) {
							let e = r[d], t = e < 0 ? -1 : n[e];
							n[d] = e, e >= 0 && (n[e] = d), d = t;
						}
						return !0;
					}
					d = n[d], a[d] = !0, u.push(d);
				}
			}
		}
		return !1;
	};
	for (let r = 0; r < t; r++) if (n[r] < 0) {
		let t = e[r].find((e) => n[e] < 0);
		t !== void 0 && (n[r] = t, n[t] = r);
	}
	for (let e = 0; e < t; e++) if (n[e] < 0 && !l(e)) return null;
	return n;
}
function we(e, t, n, r, i, a, o, s, c) {
	let l = /* @__PURE__ */ new Set([
		n,
		r,
		...i
	]), u = [], d = /* @__PURE__ */ new Set(), f = (e) => l.has(e) || !t.has(e);
	for (let [t, n] of e) if (f(t)) for (let e of n) f(e.to) && !(e.mask & a) && !d.has(e.mask) && (d.add(e.mask), u.push({
		...e,
		from: t
	}));
	let p = /* @__PURE__ */ new Map(), m = (e, t, n) => {
		let r = p.get(e) ?? [];
		r.push({
			to: t,
			edge: n
		}), p.set(e, r);
	};
	u.forEach((e, t) => {
		m(e.from, e.to, t), m(e.to, e.from, t);
	});
	let h = /* @__PURE__ */ new Set([n]), g = [n];
	for (let e = 0; e < g.length; e++) if (g[e] !== r) for (let t of p.get(g[e]) ?? []) h.has(t.to) || (h.add(t.to), g.push(t.to));
	if ([...l].some((e) => !h.has(e))) return null;
	let _ = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new Map(), y = /* @__PURE__ */ new Set(), b = 0, x = (e, t) => {
		_.set(e, ++b), v.set(e, b);
		let n = e === r;
		for (let r of p.get(e) ?? []) if (r.edge !== t && h.has(r.to)) {
			if (_.has(r.to)) v.set(e, Math.min(v.get(e), _.get(r.to)));
			else {
				let t = x(r.to, r.edge);
				v.set(e, Math.min(v.get(e), v.get(r.to))), v.get(r.to) > _.get(e) && !t && y.add(r.edge), n ||= t;
			}
		}
		return n;
	};
	x(n, -1);
	let S = /* @__PURE__ */ new Set([n]), C = [n];
	for (let e = 0; e < C.length; e++) for (let t of p.get(C[e]) ?? []) !y.has(t.edge) && h.has(t.to) && !S.has(t.to) && (S.add(t.to), C.push(t.to));
	if ([...l].some((e) => !S.has(e)) || (u.splice(0, u.length, ...u.filter((e, t) => !y.has(t) && S.has(e.from) && S.has(e.to))), (u.reduce((e, t) => e | t.mask, 0n) & o) !== o)) return null;
	let w = u.reduce((e, t, n) => t.mask & o ? e | 1n << BigInt(n) : e, 0n), T = /* @__PURE__ */ new Set(), E = (e, i) => {
		if (e & i) return null;
		let a = `${e}:${i}`;
		if (T.has(a)) return null;
		if (T.add(a), --c.remaining < 0) return;
		c.queries++;
		let o = [], d = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Map(), p = () => (o.push([]), o.length - 1), m = (e, t) => {
			o[e].includes(t) || (o[e].push(t), o[t].push(e));
		}, h = (e, t) => {
			let n = d.get(e) ?? [];
			n.push(t), d.set(e, n);
		};
		u.forEach((t, n) => {
			if (e & 1n << BigInt(n)) return;
			let r = p(), a = p();
			f.set(n, [r, a]), h(t.from, r), h(t.to, a), i & 1n << BigInt(n) || m(r, a);
		});
		for (let e of l) if (!d.has(e)) return null;
		for (let [e, i] of d) {
			if (!t.has(e)) for (let e = 0; e < i.length; e++) for (let t = e + 1; t < i.length; t++) m(i[e], i[t]);
			let a = e === n || e === r ? 1 : l.has(e) ? 2 : 0;
			for (let e = 0; e < a; e++) {
				let e = p();
				for (let t of i) m(e, t);
			}
		}
		let g = Ce(o);
		if (!g) return null;
		let _ = /* @__PURE__ */ new Set();
		for (let [e, [t, n]] of f) (i & 1n << BigInt(e) || g[t] !== n) && _.add(e);
		let v = s & ~u.reduce((e, t, n) => i & 1n << BigInt(n) ? e | t.mines : e, 0n), y = (t) => {
			let n = e, r = !1;
			for (let e of t) {
				let t = E(n, i | 1n << BigInt(e));
				if (t) return t;
				r ||= t === void 0, n |= 1n << BigInt(e);
			}
			return r ? void 0 : null;
		};
		if (v) {
			let t = v & -v;
			return y(u.map((e, t) => t).filter((n) => !(e & 1n << BigInt(n)) && !!(u[n].mines & t)).sort((e, t) => Number(_.has(t)) - Number(_.has(e))));
		}
		let b = /* @__PURE__ */ new Map(), x = (e, t, n) => {
			let r = b.get(e) ?? [];
			r.push({
				to: t,
				edge: n
			}), b.set(e, r);
		};
		for (let e of _) {
			let t = u[e];
			x(t.from, t.to, e), x(t.to, t.from, e);
		}
		let S = /* @__PURE__ */ new Set([n]), C = [n];
		for (let e = 0; e < C.length; e++) for (let t of b.get(C[e]) ?? []) S.has(t.to) || (S.add(t.to), C.push(t.to));
		let w = [...l].find((e) => !S.has(e)) ?? [..._].filter((e) => i & 1n << BigInt(e)).map((e) => u[e].from).find((e) => !S.has(e));
		if (w) {
			let t = /* @__PURE__ */ new Set([w]), n = [w];
			for (let e = 0; e < n.length; e++) for (let r of b.get(n[e]) ?? []) t.has(r.to) || (t.add(r.to), n.push(r.to));
			let i = u.map((e, t) => t).filter((n) => !(e & 1n << BigInt(n)) && t.has(u[n].from) !== t.has(u[n].to));
			return i.length < (t.has(r) ? 1 : 2) ? null : y(i);
		}
		let D = /* @__PURE__ */ new Set(), O = [{
			key: n,
			paths: []
		}], k = [];
		for (; O.length;) {
			let e = O[O.length - 1], t = b.get(e.key)?.find((e) => !D.has(e.edge));
			if (t) {
				let n = u[t.edge];
				D.add(t.edge), O.push({
					key: t.to,
					paths: e.key === n.from ? n.paths : [...n.paths].reverse()
				});
			} else k.push(O.pop().paths);
		}
		return k.reverse().flat();
	};
	return E(0n, w);
}
//#endregion
//#region src/games/1817/matching-routes.ts
function Te(e, t, n, r, i, a, o, s, c, l = 5e4) {
	let u = o, d = -Infinity, f = new Map(n.map((e) => [e.key, e])), p = n.filter((e) => e.own).map((e) => e.key), m = new Set(p);
	for (let t = 0; t < p.length; t++) {
		let n = f.get(p[t]);
		if (!n?.blocked || n.own) for (let n of e.get(p[t]) ?? []) !(n.mask & i) && !m.has(n.to) && (m.add(n.to), p.push(n.to));
	}
	let h = n.filter((e) => m.has(e.key)).sort((e, t) => t.value - e.value);
	if (h.length > 30) return {
		route: u,
		exact: !1
	};
	let g = 0n;
	for (let [t, n] of e) if (m.has(t)) for (let e of n) !(e.mask & i) && m.has(e.to) && (g |= e.mines);
	let _ = (e) => {
		let t = 0;
		for (; e;) e &= e - 1n, t++;
		return t;
	}, v = new Map(h.map((e, t) => [e.key, t])), y = h.map((n) => {
		let r = /* @__PURE__ */ new Set([n.key]), a = [n.key], o = 0;
		for (let n = 0; n < a.length; n++) for (let s of e.get(a[n]) ?? []) {
			if (s.mask & i || r.has(s.to)) continue;
			r.add(s.to);
			let e = v.get(s.to);
			e === void 0 ? t.has(s.to) || a.push(s.to) : o |= 1 << e;
		}
		return o;
	}), b = (e) => {
		let t = e & -e, n = t;
		for (; n;) {
			let r = n & -n;
			n ^= r;
			let i = 31 - Math.clz32(r), a = y[i] & e & ~t;
			t |= a, n |= a;
		}
		return t === e;
	}, x = h.reduce((e, t, n) => t.blocked ? e | 1 << n : e, 0), S = /* @__PURE__ */ new Map(), C = (e) => {
		if (!(e & e - 1)) return e;
		let t = S.get(e);
		if (t !== void 0) return t;
		let n = 0;
		for (let t = e; t; t &= t - 1) {
			let r = t & -t, i = e ^ r, a = C(i), o = i & i - 1 ? a & ~x : a;
			y[31 - Math.clz32(r)] & o && (n |= r);
		}
		return S.set(e, n), n;
	}, w = /* @__PURE__ */ new Map(), T = (e, t) => {
		if (!(e & t)) return 0;
		if (e === t) return t;
		let n = w.get(t) ?? /* @__PURE__ */ new Map();
		w.set(t, n);
		let r = n.get(e);
		if (r !== void 0) return r;
		let i = 0;
		for (let n = e & ~t; n; n &= n - 1) {
			let r = n & -n, a = e ^ r, o = T(a, t), s = a & a - 1 ? o & ~x : o;
			y[31 - Math.clz32(r)] & s && (i |= r);
		}
		return n.size < 2e5 && n.set(e, i), i;
	}, E = (e) => b(e) && !!C(e), D = _(g) * 10, O = [], k = (e, t, n, i, a, o, s) => {
		if (i >= 2 && a && n + D > u.revenue && O.push({
			mask: t,
			value: n,
			n: i
		}), i === r) return;
		let c = n + D;
		for (let t = e; t < Math.min(h.length, e + r - i); t++) c += h[t].value;
		if (!(c <= u.revenue)) for (let r = e; r < h.length; r++) !s.has(h[r].hex) && o + Number(h[r].blocked) <= 2 && (s.add(h[r].hex), k(r + 1, t | 1 << r, n + h[r].value, i + 1, a || h[r].own, o + Number(h[r].blocked), s), s.delete(h[r].hex));
	};
	k(0, 0, 0, 0, !1, 0, /* @__PURE__ */ new Set()), O.sort((e, t) => t.value - e.value || t.n - e.n);
	let A = [];
	for (let e = g; A.push(e), e; e = e - 1n & g);
	A.sort((e, t) => _(t) - _(e));
	let j = {
		remaining: l,
		queries: 0
	};
	for (let n of O) {
		if (n.value + D <= u.revenue || u.revenue >= s) break;
		if (!E(n.mask)) continue;
		let r = h.filter((e, t) => n.mask & 1 << t), o = r.filter((e) => e.blocked);
		for (let s of A) {
			let l = n.value + _(s) * 10;
			if (l <= u.revenue) continue;
			let f = !1, p = !1;
			for (let l = 0; l < r.length && !p; l++) for (let d = l + 1; d < r.length && !p; d++) {
				if (!(T(n.mask, 1 << v.get(r[l].key)) & 1 << v.get(r[d].key)) || o.some((e) => e !== r[l] && e !== r[d])) continue;
				let m = we(e, t, r[l].key, r[d].key, r.filter((e, t) => t !== l && t !== d).map((e) => e.key), i, a, s, j);
				if (m === void 0) {
					f = !0;
					continue;
				}
				if (m === null) continue;
				let h = c(m);
				if (h === null) throw Error("Invalid route from the track matching solver");
				h > u.revenue && (u = {
					train: -1,
					paths: m,
					revenue: h
				}), p = !0;
			}
			if (f && !p && (d = Math.max(d, l)), j.remaining < 0) {
				d = Math.max(d, n.value + D);
				break;
			}
		}
		if (j.remaining < 0) break;
	}
	return {
		route: u,
		exact: u.revenue >= s || d <= u.revenue,
		queries: j.queries
	};
}
//#endregion
//#region src/games/1817/network.ts
var W = Object.keys(Se), G = [
	[1, -1],
	[0, -2],
	[-1, -1],
	[-1, 1],
	[0, 2],
	[1, 1]
];
function K(e, t) {
	let [n, r] = G[t];
	return `${String.fromCharCode(e.charCodeAt(0) + n)}${Number(e.slice(1)) + r}`;
}
function Ee(e) {
	return {
		x: 25 + Number(e.slice(1)) * Math.sqrt(3) * 10,
		y: 30 + (e.charCodeAt(0) - 65) * 30
	};
}
var q = (e, t = 20) => {
	let n = (120 + e * 60) * Math.PI / 180;
	return {
		x: Math.cos(n) * t * Math.sqrt(3) / 2,
		y: Math.sin(n) * t * Math.sqrt(3) / 2
	};
};
function De(e, t, n = 2, r = 0) {
	let i = {
		color: e,
		nodes: [],
		paths: [],
		label: "",
		cost: 0,
		terrain: "",
		border: []
	}, a = n >= 7 ? 3 : n >= 5 ? 2 : +(n >= 3);
	for (let e of t.split(";")) {
		let t = e.indexOf("="), n = t < 0 ? e : e.slice(0, t), o = e.slice(t + 1), s = Object.fromEntries(o.split(",").map((e) => e.split(":")));
		if ([
			"city",
			"town",
			"offboard",
			"junction"
		].includes(n)) {
			let e = (s.revenue ?? "0").split("|").map((e) => Number(e.split("_").at(-1)));
			i.nodes.push({
				type: n,
				revenue: e[Math.min(a, e.length - 1)],
				slots: n === "city" ? Number(s.slots ?? 1) : 0
			});
		}
		if (n === "path") {
			let e = (e) => e.startsWith("_") ? -1 - Number(e.slice(1)) : (Number(e) + r) % 6;
			i.paths.push([e(s.a), e(s.b)]);
		}
		n === "label" && (i.label = o), n === "upgrade" && (i.cost = Number(s.cost), i.terrain = s.terrain), n === "border" && s.type === "impassable" && i.border.push(Number(s.edge));
	}
	return i;
}
function J(e, t) {
	let n = e.board[t], r = n.tile ? xe[n.tile] : Se[t];
	return De(r.color, r.code, e.phaseNumber, n.rotation);
}
function Oe(e, t, n, r) {
	let i = e.board[t];
	if (!i) return !1;
	let a = J(e, t).nodes[n];
	return !!a && a.type === "city" && t !== "B13" && (!r && r !== 0 || !i.tokens.some((e) => e.company === r)) && i.tokens.filter((e) => e.city === n).length < a.slots;
}
var Y = (e, t) => `${e}:${t}`, ke = /* @__PURE__ */ new WeakMap(), Ae = /* @__PURE__ */ new WeakMap(), je = /* @__PURE__ */ new WeakMap(), Me = /* @__PURE__ */ new Map();
function Ne(e) {
	ke.delete(e), Ae.delete(e), je.delete(e);
}
function X(e) {
	let t = ke.get(e);
	if (t) return t;
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = (e, t, r) => {
		n.set(e, [...n.get(e) ?? [], {
			to: t,
			segment: r
		}]);
	};
	for (let t of W) {
		let n = J(e, t);
		n.nodes.forEach((e, n) => r.set(Y(t, -1 - n), {
			hex: t,
			node: n,
			data: e
		})), n.paths.forEach(([e, n], r) => {
			let a = Y(t, e), o = Y(t, n), s = `${t}/${r}`;
			i(a, o, s), i(o, a, s);
		});
	}
	for (let e of W) for (let t = 0; t < 6; t++) {
		let r = K(e, t), a = Y(e, t), o = Y(r, (t + 3) % 6);
		n.has(a) && n.has(o) && i(a, o, null);
	}
	let a = {
		links: n,
		stops: r
	};
	return ke.set(e, a), a;
}
function Z(e, t, n) {
	if (n.data.type === "offboard") return !0;
	if (n.data.type !== "city") return !1;
	let r = e.board[n.hex].tokens.filter((e) => e.city === n.node);
	return r.length >= n.data.slots && !r.some((e) => e.company === t.id);
}
function Pe(e, t) {
	let n = Ae.get(e) ?? /* @__PURE__ */ new Map();
	if (Ae.set(e, n), n.has(t.id)) return n.get(t.id);
	let r = X(e), i = /* @__PURE__ */ new Set(), a = [];
	for (let n of W) for (let r of e.board[n].tokens) r.company === t.id && a.push(Y(n, -1 - r.city));
	let o = new Set(a);
	for (; a.length;) {
		let n = a.pop();
		if (i.has(n)) continue;
		i.add(n);
		let s = r.stops.get(n);
		if (!(s && Z(e, t, s) && !o.has(n))) for (let e of r.links.get(n) ?? []) i.has(e.to) || a.push(e.to);
	}
	return n.set(t.id, i), i;
}
function Fe(e, t, n) {
	let r = De(Se[t].color, Se[t].code);
	return n.paths.flat().filter((e) => e >= 0).every((n) => {
		let i = K(t, n);
		if (!e.board[i] || r.border.includes(n)) return !1;
		let a = J(e, i);
		return a.border.includes((n + 3) % 6) || a.color === "blue" ? !1 : !["red", "gray"].includes(a.color) || a.paths.some((e) => e.includes((n + 3) % 6));
	});
}
function Ie(e, t, n) {
	let r = [t], i = /* @__PURE__ */ new Set();
	for (; r.length;) {
		let t = r.pop();
		if (t === n) return !0;
		if (!i.has(t)) {
			i.add(t);
			for (let n of e) n.includes(t) && r.push(n[0] === t ? n[1] : n[0]);
		}
	}
	return !1;
}
function Le(e, t, n, r, i, a) {
	let o = xe[r], s = e.board[n];
	if (!o || !s || e.lays.length >= 2 || e.lays.includes(n) || s.mine) return null;
	let c = J(e, n), l = De(o.color, o.code, e.phaseNumber, i), u = [
		"white",
		"yellow",
		"green",
		"brown",
		"gray"
	], d = u.indexOf(l.color);
	if (u.indexOf(c.color) + 1 !== d || d > (e.phaseNumber >= 7 ? 4 : e.phaseNumber >= 5 ? 3 : e.phaseNumber >= 3 ? 2 : 1) || c.color !== "white" && e.upgraded || !Fe(e, n, l)) return null;
	let f = c.nodes.some((e) => e.type === "city"), p = l.nodes.some((e) => e.type === "city");
	if (f !== p || (c.label || l.label) && c.label !== l.label && r !== "X00") return null;
	let m = r === "X00" && n === "F13" && t.privates.includes(0) && c.color === "white";
	if (r === "X00" && !m || c.paths.some(([e, t]) => !Ie(l.paths, l.nodes.length === 1 && e < 0 ? -1 : e, l.nodes.length === 1 && t < 0 ? -1 : t))) return null;
	let h = Pe(e, t);
	if (!(c.color === "white" && s.tokens.some((e) => e.company === t.id)) && !m && !l.paths.flat().some((e) => e >= 0 && h.has(Y(K(n, e), (e + 3) % 6)) || e < 0 && h.has(Y(n, e)))) return null;
	if (c.color === "green" && c.label === "" && p) {
		let t = new Set(l.paths.flat().filter((e) => e >= 0)).size;
		for (let r of [
			"63",
			"611",
			"448"
		]) for (let i = 0; i < 6; i++) {
			let a = xe[r], o = De(a.color, a.code, e.phaseNumber, i);
			if (!(new Set(o.paths.flat().filter((e) => e >= 0)).size <= t) && Fe(e, n, o) && c.paths.every(([e, t]) => Ie(o.paths, e, t))) return null;
		}
	}
	let g = De(Se[n].color, Se[n].code), _ = e.lays.length ? 20 : 0, v = 0;
	if (c.color === "white" && (_ += g.cost), (n === "C8" || n === "E22") && l.color === "green" && (_ += 20), c.color === "white" && g.terrain === "water" && t.privates.some((e) => e === 2 || e === 3) && (_ -= g.cost), a !== null) {
		if (c.color !== "white" || g.terrain !== "mountain" || ![
			5,
			6,
			7
		].includes(a) || !t.privates.includes(a) || e.privateUses[a] <= 0 || !l.paths.flat().filter((e) => e >= 0).some((t) => {
			let r = K(n, t), i = Se[r];
			if (!i || !/city=|offboard=/.test(i.code)) return !1;
			let a = J(e, r), o = (t + 3) % 6;
			return a.paths.some(([e, t]) => e === o && t < 0 || t === o && e < 0) ? !0 : !["red", "gray"].includes(a.color) && !a.border.includes(o);
		})) return null;
		_ -= g.cost;
	}
	return c.color === "white" && g.terrain === "mountain" && t.privates.includes(1) && (v = 20), t.cash >= _ ? {
		cost: _,
		grant: v
	} : null;
}
function Re(e, t, n, r, i = X(e)) {
	if (!n.length || new Set(n).size !== n.length) return null;
	let a = /* @__PURE__ */ new Map();
	for (let [e, t] of i.links) for (let n of t) n.segment && a.set(n.segment, [e, n.to]);
	let o = a.get(n[0]);
	if (!o) return null;
	for (let s of o) {
		let o = i.stops.get(s);
		if (!o || o.data.type === "junction") continue;
		let c = s, l = !0, u = 0, d = !1, f = 0, p = /* @__PURE__ */ new Set(), m = /* @__PURE__ */ new Set(), h = (n, a) => {
			let o = i.stops.get(n);
			if (!o || o.data.type === "junction") return !0;
			if (p.has(o.hex)) return !1;
			p.add(o.hex), u++, f += o.data.revenue + (e.board[o.hex].bridge ? 10 : 0);
			let c = e.board[o.hex].tokens.some((e) => e.city === o.node && e.company === t.id);
			return d ||= c, c && e.config.modernTrains && r >= 7 && (f += r === 7 ? 10 : 20), u <= r && (a || !Z(e, t, o) || n === s);
		};
		if (!h(s, !1)) continue;
		for (let t = 0; t < n.length; t++) {
			let r = a.get(n[t]);
			if (!r) {
				l = !1;
				break;
			}
			if (!r.includes(c)) {
				let e = i.links.get(c)?.find((e) => !e.segment && r.includes(e.to));
				if (!e) {
					l = !1;
					break;
				}
				c = e.to;
			}
			c = r[0] === c ? r[1] : r[0];
			let o = n[t].split("/")[0];
			if (e.board[o].mine && !m.has(o) && (f += 10, m.add(o)), !h(c, t === n.length - 1)) {
				l = !1;
				break;
			}
		}
		let g = i.stops.get(c);
		if (l && g && g.data.type !== "junction" && d && u >= 2) return f;
	}
	return null;
}
function ze(e, t) {
	let n = je.get(e) ?? /* @__PURE__ */ new Map(), r = `${t.id}:${t.trains.map((e) => `${e.id}/${e.kind}`).join(",")}`;
	if (je.set(e, n), n.has(r)) return n.get(r);
	let i = `${e.phaseNumber}:${Number(e.config.modernTrains)}:${r}:${JSON.stringify(e.board)}`, a = Me.get(i);
	if (a) return n.set(r, a), a;
	let o = Be(e, t);
	return n.set(r, o), Me.set(i, o), Me.size > 128 && Me.delete(Me.keys().next().value), o;
}
function Be(e, t) {
	if (!t.trains.length) return [];
	let n = X(e), r = Ve(e, t), { bits: i, connections: a } = r, o = (r) => {
		let i = n.stops.get(r);
		return e.board[i.hex].tokens.some((e) => e.company === t.id && e.city === i.node);
	}, s = (e) => {
		let t = 0;
		for (; e;) e &= e - 1n, t++;
		return t;
	}, c = (e, t, n = 0n, a = 0) => {
		let o = r.single(e, t, n, a);
		return {
			route: o,
			mask: o.paths.reduce((e, t) => e | i.get(t), 0n)
		};
	}, l = t.trains.map((e) => ({
		id: e.id,
		distance: parseInt(e.kind)
	})), u = (e, t, n) => {
		let r = l.map((r, i) => c(r.distance, e[i], t[i], n ? Math.max(0, d - n.routes.reduce((e, t, n) => e + (i === n ? 0 : t.revenue), 0)) : 0));
		return {
			forbidden: e,
			required: t,
			routes: r.map((e, t) => ({
				...e.route,
				train: l[t].id
			})),
			masks: r.map((e) => e.mask),
			upper: r.reduce((e, t) => e + t.route.revenue, 0)
		};
	}, d = 0, f = [];
	for (let e of [l.map((e, t) => t), l.map((e, t) => t).reverse()]) {
		let t = 0n, n = [];
		for (let r of e) {
			let e = c(l[r].distance, t, 0n, l.length === 2 && n.length ? Math.max(0, d - n[0].revenue) : 0);
			t |= e.mask, n.push({
				...e.route,
				train: l[r].id
			});
		}
		let r = n.reduce((e, t) => e + t.revenue, 0);
		r > d && (d = r, f = n.filter((e) => e.paths.length));
		let a = l.map((e) => n.find((t) => t.train === e.id)), o = /* @__PURE__ */ new Set();
		for (let t = 0; t < 8; t++) {
			let t = a.map((e) => e.paths.join(",")).join("|");
			if (o.has(t)) break;
			o.add(t);
			for (let t of e) {
				let e = a.reduce((e, n, r) => r === t ? e : n.paths.reduce((e, t) => e | i.get(t), e), 0n), n = c(l[t].distance, e, 0n, Math.max(0, a[t].revenue - 1));
				Number.isFinite(n.route.revenue) && (a[t] = {
					...n.route,
					train: l[t].id
				});
			}
			let n = a.reduce((e, t) => e + t.revenue, 0);
			n > d && (d = n, f = a.filter((e) => e.paths.length));
		}
	}
	let p = [...n.stops].filter(([e]) => o(e)).reduce((e, [t]) => (n.links.get(t) ?? []).reduce((e, t) => e | (t.segment ? i.get(t.segment) : 0n), e), 0n), m = [...n.stops].filter(([e, t]) => t.data.type === "junction" && (n.links.get(e)?.length ?? 0) < 4).map(([e]) => (n.links.get(e) ?? []).reduce((e, t) => e | (t.segment ? i.get(t.segment) : 0n), 0n)), h = [u(l.map(() => 0n), l.map(() => 0n))], g = /* @__PURE__ */ new Set(), _ = (e) => e.reduce((t, n, r) => t + e.slice(r + 1).reduce((e, t) => e + s(n & t), 0), 0);
	for (; h.length;) {
		h.sort((e, t) => e.upper - t.upper);
		let e = h.pop();
		if (e.upper <= d) return f;
		for (let t = 0; t < l.length; t++) {
			let n = 0n, r = [];
			for (let i of [t, ...l.map((e, t) => t).filter((e) => e !== t)]) {
				let t = r.length ? c(l[i].distance, n, 0n, l.length === 2 ? Math.max(0, d - r[0].revenue) : 0) : {
					route: e.routes[i],
					mask: e.masks[i]
				};
				n |= t.mask, r.push({
					...t.route,
					train: l[i].id
				});
			}
			let i = r.reduce((e, t) => e + t.revenue, 0);
			i > d && (d = i, f = r.filter((e) => e.paths.length));
		}
		if (e.upper <= d) return f;
		let t = null;
		for (let n = 0; n < l.length && !t; n++) for (let r = n + 1; r < l.length; r++) {
			let i = e.masks[n] & e.masks[r];
			if (i) {
				let e = i & p;
				t = [
					n,
					r,
					e ? e & -e : i & -i
				];
				break;
			}
		}
		if (!t) return e.routes.filter((e) => e.paths.length);
		let [n, r] = t, i = e.masks[n] & e.masks[r], o = l[n].distance <= l[r].distance ? n : r, s = -1, v = null, y = _(e.masks), b = /* @__PURE__ */ new Set(), x = [...m.filter((t) => e.masks[n] & t && e.masks[r] & t), ...[...a.values()].flat().filter((e) => e.mask & i).map((e) => {
			let t = e.mask & i;
			return t & -t;
		})];
		for (let i of x) {
			if (b.has(i) || e.required[o] & i) continue;
			b.add(i);
			let a = c(l[o].distance, e.forbidden[o] | i, e.required[o], Math.max(0, d - e.routes.reduce((e, t, n) => e + (n === o ? 0 : t.revenue), 0))), u = e.routes[o].revenue - a.route.revenue;
			if (u === 0) {
				let t = [...e.masks];
				t[o] = a.mask;
				let n = _(t);
				if (n < y) {
					v = {
						...a,
						conflicts: n
					};
					break;
				}
			}
			if (u > s && (s = u, t = [
				o,
				o === n ? r : n,
				i
			]), u > 0) break;
		}
		if (v) {
			e.routes[o] = {
				...v.route,
				train: l[o].id
			}, e.masks[o] = v.mask, h.push(e);
			continue;
		}
		for (let n of [t[0], t[1]]) {
			let r = [...e.forbidden];
			r[n] |= t[2];
			let i = [...e.required];
			if (n === t[1] && !(t[2] & t[2] - 1n) && (i[t[0]] |= t[2]), r.some((e, t) => e & i[t])) continue;
			let a = l.map((e, t) => `${e.distance}:${r[t]}:${i[t]}`).sort().join("|");
			if (g.has(a)) continue;
			g.add(a);
			let o = u(r, i, e);
			o.masks.some((e, t) => (e & i[t]) !== i[t]) || o.upper > d && h.push(o);
		}
	}
	return f;
}
function Ve(e, t) {
	let n = X(e), r = Pe(e, t), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map();
	for (let e of n.links.values()) for (let t of e) t.segment && !i.has(t.segment) && i.set(t.segment, 1n << BigInt(i.size));
	for (let t of W) a.set(t, 1n << BigInt(a.size)), e.board[t].mine && o.set(t, 1n << BigInt(o.size));
	let s = new Set([...n.links].filter(([e, t]) => n.stops.has(e) || t.length !== 2).map(([e]) => e)), c = /* @__PURE__ */ new Map();
	for (let e of s) {
		let t = [];
		for (let r of n.links.get(e) ?? []) {
			let a = e, c = r.to, l = r, u = 0n, d = 0n, f = [];
			for (;;) {
				if (l.segment) {
					let e = i.get(l.segment);
					if (u & e) break;
					u |= e, f.push(l.segment), d |= o.get(l.segment.split("/")[0]) ?? 0n;
				}
				if (s.has(c)) {
					f.length && (c !== e || d) && t.push({
						to: c,
						mask: u,
						paths: f,
						mines: d
					});
					break;
				}
				let r = n.links.get(c)?.find((e) => e.to !== a);
				if (!r) break;
				a = c, c = r.to, l = r;
			}
		}
		c.set(e, t);
	}
	let l = [...n.stops].filter(([e, t]) => t.data.type !== "junction" && r.has(e)).map(([e]) => e), u = new Set([...n.stops].filter(([, e]) => e.data.type !== "junction").map(([e]) => e)), d = (e) => {
		let t = 0;
		for (; e;) e &= e - 1n, t++;
		return t;
	}, f = (1n << BigInt(o.size)) - 1n, p = /* @__PURE__ */ new Map(), m = /* @__PURE__ */ new Map(), h = /* @__PURE__ */ new Map();
	return {
		single: (o, g, _ = 0n, v = 0) => {
			let y = `${o}:${g}:${_}`, b = p.get(y);
			if (b) return b;
			if (v > 0 && v >= (m.get(y) ?? Infinity)) return {
				train: -1,
				paths: [],
				revenue: -Infinity
			};
			let x = h.get(o) ?? [], S = {
				train: -1,
				paths: [],
				revenue: 0
			}, C = Infinity;
			for (let e of x) !(e.mask & g) && (e.mask & _) === _ && e.route.revenue > S.revenue && (S = e.route), (e.forbidden & g) === e.forbidden && (e.required & _) === e.required && (C = Math.min(C, e.route.revenue));
			for (let [r, i] of h) if (r !== o) for (let r of i) {
				if (r.mask & g || (r.mask & _) !== _) continue;
				let i = Re(e, t, r.route.paths, o, n);
				i !== null && i > S.revenue && (S = {
					...r.route,
					revenue: i
				});
			}
			S.revenue < v && (S = {
				train: -1,
				paths: [],
				revenue: v
			});
			let w = () => !S.paths.length && v > 0 ? (m.set(y, Math.min(v, m.get(y) ?? Infinity)), {
				train: -1,
				paths: [],
				revenue: -Infinity
			}) : (p.set(y, S), x.push({
				forbidden: g,
				required: _,
				mask: S.paths.reduce((e, t) => e | i.get(t), 0n),
				route: S
			}), h.set(o, x), S);
			if (S.revenue >= C) return w();
			let T = /* @__PURE__ */ new Set(), E = /* @__PURE__ */ new Map(), D = /* @__PURE__ */ new Map();
			for (let [i, a] of n.stops) {
				let n = e.board[a.hex].tokens.some((e) => e.company === t.id && e.city === a.node);
				n && T.add(i);
				let s = a.data.revenue + (e.board[a.hex].bridge ? 10 : 0) + (n && e.config.modernTrains && o >= 7 ? o === 7 ? 10 : 20 : 0);
				E.set(i, s), a.data.type !== "junction" && r.has(i) && D.set(a.hex, Math.max(D.get(a.hex) ?? 0, s));
			}
			let O = Te(c, u, l.map((r) => {
				let i = n.stops.get(r);
				return {
					key: r,
					hex: i.hex,
					own: T.has(r),
					value: E.get(r),
					blocked: Z(e, t, i)
				};
			}), o, g, _, S, C, (r) => Re(e, t, r, o, n));
			if (S = O.route, O.exact) return w();
			let k = [...D].sort((e, t) => t[1] - e[1]), A = [], j = /* @__PURE__ */ new Map(), ee = /* @__PURE__ */ new Map(), te = /* @__PURE__ */ new Map(), ne = /* @__PURE__ */ new Map();
			for (let e of s) {
				let t = /* @__PURE__ */ new Set([e]), r = [e], i = /* @__PURE__ */ new Set();
				for (; r.length;) for (let e of c.get(r.pop()) ?? []) {
					if (e.mask & g || t.has(e.to)) continue;
					t.add(e.to);
					let a = n.stops.get(e.to);
					a && a.data.type !== "junction" ? i.add(e.to) : r.push(e.to);
				}
				te.set(e, [...i]);
			}
			let re = (r, i, o, s) => {
				let c = `${r}:${i}:${o}:${Number(s)}`, l = ne.get(c);
				if (l !== void 0) return l;
				let u = s ? 0 : -Infinity;
				if (o > 0) for (let c of te.get(r) ?? []) {
					let r = n.stops.get(c), l = a.get(r.hex);
					if (i & l) continue;
					let d = s || T.has(c), f = Z(e, t, r) ? d ? 0 : -Infinity : re(c, i | l, o - 1, d);
					u = Math.max(u, E.get(c) + f);
				}
				return ne.size < 2e5 && ne.set(c, u), u;
			}, ie = (r, i, o, s, l, u) => {
				let f = /* @__PURE__ */ new Map([[r, 0]]), p = [[r, 0]], m = /* @__PURE__ */ new Map(), h = 0n, g = 0n, v = u;
				for (; p.length;) {
					let [s, u] = p.pop();
					if (f.get(s) !== u) continue;
					let d = n.stops.get(s);
					if (!(s !== r && d && d.data.type !== "junction" && (m.set(d.hex, Math.max(m.get(d.hex) ?? 0, E.get(s))), v ||= T.has(s), Z(e, t, d)))) for (let e of c.get(s) ?? []) {
						if (e.mask & i) continue;
						let t = n.stops.get(e.to), r = t && t.data.type !== "junction";
						if (r && o & a.get(t.hex)) continue;
						let s = u + Number(!!r);
						s > l || (h |= e.mines, g |= e.mask, s < (f.get(e.to) ?? Infinity) && (f.set(e.to, s), p.push([e.to, s])));
					}
				}
				return !v || (_ & ~i & g) !== (_ & ~i) ? -Infinity : [...m.values()].sort((e, t) => t - e).slice(0, l).reduce((e, t) => e + t, 0) + d(h & ~s) * 10;
			}, ae = (r, i, s, l, u, p, m) => {
				if (S.revenue >= C) return;
				let h = n.stops.get(r);
				if (A.length && h && h.data.type !== "junction") {
					let n = a.get(h.hex);
					if (s & n || ++u > o || (s |= n, p += E.get(r), m ||= T.has(r), m && (i & _) === _ && p > S.revenue && (S = {
						train: -1,
						paths: [...A],
						revenue: p
					}), Z(e, t, h) || u === o)) return;
				}
				let v = p + d(f & ~l) * 10, y = o - u;
				for (let [e, t] of k) !(s & a.get(e)) && y-- > 0 && (v += t);
				if (v <= S.revenue || p + re(r, s, o - u, m) + d(f & ~l) * 10 <= S.revenue) return;
				let b = `${r}:${s}:${l}:${Number(m)}:${i & _}`, x = ee.get(b) ?? [];
				if (x.some((e) => e.revenue >= p && (e.used & i) === e.used) || ((ee.size < 1e5 || ee.has(b)) && ee.set(b, [...x.filter((e) => !(p >= e.revenue && (e.used & i) === i)).slice(-31), {
					used: i,
					revenue: p
				}]), p + ie(r, i | g, s, l, o - u, m) <= S.revenue)) return;
				let w = j.get(r) ?? [];
				if (w.some((e) => e.city === s && e.mine === l && e.required === (i & _))) return;
				j.set(r, [...w, {
					city: s,
					mine: l,
					required: i & _
				}]);
				let D = (c.get(r) ?? []).filter((e) => !(e.mask & (i | g))).sort((e, t) => (E.get(t.to) ?? 0) - (E.get(e.to) ?? 0));
				for (let e of D) A.push(...e.paths), ae(e.to, i | e.mask, s, l | e.mines, u, p + d(e.mines & ~l) * 10, m), A.splice(A.length - e.paths.length);
				w.length ? j.set(r, w) : j.delete(r);
			};
			for (let e of l.sort((e, t) => (E.get(t) ?? 0) - (E.get(e) ?? 0))) {
				let t = n.stops.get(e);
				ae(e, 0n, a.get(t.hex), 0n, 1, E.get(e), T.has(e));
			}
			return w();
		},
		bits: i,
		connections: c
	};
}
function He(e, t) {
	let n = [];
	for (let r of W) for (let i of Object.keys(xe)) for (let a = 0; a < 6; a++) {
		let o = {
			hex: r,
			tile: i,
			rotation: a,
			mine: null
		};
		Le(e, t, r, i, a, null) && n.push(o);
	}
	return n;
}
function Ue() {
	return Object.fromEntries(W.map((e) => [e, {
		tile: "",
		rotation: 0,
		tokens: [],
		mine: !1,
		bridge: !1
	}]));
}
//#endregion
//#region src/games/1817/rules.ts
function We(e) {
	if (e.crisis) return e.crisis;
	if (e.discardCompany !== null) {
		let t = e.companies[e.discardCompany].president;
		return t && !L(e, t).bankrupt ? t : e.actor;
	}
	if (e.excessTokens !== null) {
		let t = e.companies[e.excessTokens].president;
		return t && !L(e, t).bankrupt ? t : e.actor;
	}
	return e.trade ? e.trade.recipient : e.phase === "done" ? "" : e.actor;
}
function Q(e, t, n = e.actor, r = -1, i = 0, a = "") {
	e.log.push({
		key: t,
		rid: n,
		company: r,
		amount: i,
		detail: a
	});
}
function Ge(e) {
	return {
		id: e,
		size: 2,
		president: null,
		active: !1,
		cash: 0,
		loans: 0,
		price: 0,
		order: 0,
		treasury: 0,
		market: 0,
		bankShorts: 0,
		tokens: 0,
		tokenDebt: 0,
		privates: [],
		trains: [],
		started: -1,
		changed: -1,
		liquidationOrder: 0
	};
}
function Ke(t, n, r) {
	let i = n[e(r, 0, n.length)];
	return { state: {
		config: D.parse(t),
		seed: r,
		players: n.map((e) => ({
			rid: e,
			cash: Math.floor(1260 / n.length),
			shares: Array(20).fill(0),
			shorts: Array(20).fill(0),
			privates: [],
			bankrupt: !1,
			sold: []
		})),
		companies: Array.from({ length: 20 }, (e, t) => Ge(t)),
		board: Ue(),
		phase: "initial",
		actor: i,
		priority: i,
		round: 0,
		operatingRound: 0,
		phaseNumber: 2,
		current: -1,
		step: 0,
		passes: 0,
		lastActor: n[(n.indexOf(i) + n.length - 1) % n.length],
		stockStep: 0,
		stockActed: !1,
		seedMoney: 200,
		availablePrivates: Array.from({ length: 11 }, (e, t) => t),
		privateUses: [
			1,
			0,
			1,
			2,
			1,
			1,
			2,
			3,
			0,
			0,
			0
		],
		auction: null,
		trade: null,
		queue: [],
		saleQueue: [],
		pendingSale: !1,
		maRound: 0,
		maPrices: [],
		orSetEnd: 2,
		postCompany: -1,
		postPlayers: [],
		postIndex: 0,
		postPresident: "",
		postForced: !1,
		postTokenCost: 0,
		interest: 5,
		depotIndex: 0,
		depotRemaining: [...F],
		openTrains: [],
		trainSerial: 0,
		orderSerial: 0,
		lays: [],
		upgraded: !1,
		tokenPlaced: !1,
		revenue: 0,
		routes: [],
		endAt: null,
		crisis: null,
		crisisCompany: -1,
		crisisAmount: 0,
		discardCompany: null,
		excessTokens: null,
		log: []
	} };
}
function qe(e, t) {
	t.price !== 0 && (t.price = 0, t.liquidationOrder = ++e.orderSerial, Q(e, "liquidate", t.president ?? "", t.id));
}
function Je(e) {
	e.tokenDebt > 0 && e.cash >= e.tokenDebt && (e.cash -= e.tokenDebt, e.tokens += e.tokenDebt / 50, e.tokenDebt = 0);
}
function Ye(e) {
	for (let t of e.companies) t.active && (ge(e, t), Je(t));
	e.crisis = e.players.find((e) => !e.bankrupt && e.cash < 0)?.rid ?? null, e.crisis || (e.crisisCompany = -1, e.crisisAmount = 0), e.discardCompany = e.companies.find((t) => t.active && t.trains.length > se(e.phaseNumber))?.id ?? null, e.excessTokens = null;
	for (let t of e.companies) if (t.active && t.tokens > 8) {
		if (W.reduce((n, r) => n + e.board[r].tokens.filter((e) => e.company === t.id).length, 0) > 8) {
			e.excessTokens = t.id;
			break;
		}
		t.tokens = 8;
	}
	e.players.filter((e) => !e.bankrupt).length <= 1 && (e.phase = "done");
}
function Xe(e, t, n, r) {
	let i = L(e, t);
	i.cash -= I(n), i.shares[n.id]++, r === "treasury" ? (n.treasury--, n.cash += I(n)) : n.market--, ge(e, n), _e(e, n), Q(e, "buy", t, n.id, I(n));
}
function Ze(e, t, n, r) {
	let i = L(e, t);
	i.shares[n.id] -= r, n.market += r, i.cash += r * I(n), i.sold.includes(n.id) || i.sold.push(n.id), ge(e, n), _e(e, n), Q(e, "sell", t, n.id, r);
}
function Qe(e) {
	e.phase = "stock", e.round++, e.actor = e.priority, e.passes = 0, e.stockStep = 0, e.stockActed = !1, e.lastActor = "", e.orSetEnd = e.endAt ?? e.operatingRound + 2;
	for (let t of e.players) t.sold = [];
	for (let t of e.companies) if (t.active) {
		ge(e, t);
		let n = Math.min(t.treasury, t.bankShorts);
		t.treasury -= n, t.bankShorts -= n, t.cash += n * I(t);
	}
	Q(e, "stock", "", -1, e.round);
}
function $e(e) {
	if (e.stockActed ? (e.passes = 0, e.lastActor = e.actor) : e.passes++, e.actor = R(e, e.actor), e.stockStep = 0, e.stockActed = !1, !(e.passes < e.players.filter((e) => !e.bankrupt).length)) {
		e.priority = e.lastActor ? R(e, e.lastActor) : e.priority;
		for (let t of ye(e)) {
			let n = e.companies[t];
			if (n.tokenDebt && qe(e, n), n.price === 0 || n.size === 2) continue;
			let r = e.players.reduce((e, n) => e + n.shares[t], 0);
			r >= n.size && z(e, n, e.config.shortSqueeze && r > n.size ? 2 : 1), n.market && z(e, n, -n.market);
		}
		et(e);
	}
}
function et(e) {
	e.phase = "operating", e.operatingRound++, e.interest = Math.max(5, Math.ceil(le(e) / 5) * 5), e.queue = ye(e).filter((t) => e.companies[t].price > 0);
	for (let t of e.companies) if (t.active && t.trains.length) {
		let n = t.privates.reduce((e, t) => e + (t === 8 ? 10 : t === 9 ? 15 : t === 10 ? 20 : 0), 0);
		t.cash += n, n && Q(e, "mail", t.president ?? "", t.id, n);
	}
	Q(e, "operating", "", -1, e.operatingRound), tt(e);
}
function tt(e) {
	for (; e.queue.length;) {
		let t = e.queue.shift(), n = e.companies[t];
		if (n.active && n.price !== 0 && n.president && !L(e, n.president).bankrupt) {
			e.current = t, e.actor = n.president, e.step = 0, e.lays = [], e.upgraded = !1, e.tokenPlaced = !1, e.routes = [], e.revenue = 0;
			return;
		}
	}
	if (it(e), e.endAt !== null && e.operatingRound >= e.endAt) {
		e.phase = "done";
		return;
	}
	at(e);
}
function nt(e, t) {
	let n = Number.parseInt(t);
	if (!(n <= e.phaseNumber)) {
		e.phaseNumber = n;
		for (let t of e.companies) if (t.trains = t.trains.filter((e) => !(n >= 4 && e.kind === "2" || n >= 6 && e.kind === "3" || n >= 8 && e.kind === "4")), n >= 4) for (let e of t.trains) e.kind === "2+" && (e.obsolete = !0);
		e.openTrains = e.openTrains.filter((e) => !(n >= 4 && (e.kind === "2" || e.kind === "2+") || n >= 6 && e.kind === "3" || n >= 8 && e.kind === "4")), n === 8 && e.endAt === null && (e.endAt = e.operatingRound + 3, Q(e, "ending", "", -1, e.endAt)), Q(e, "era", "", -1, n);
	}
}
function rt(e) {
	let t = N[e.depotIndex];
	return e.depotRemaining[e.depotIndex]--, e.depotRemaining[e.depotIndex] === 0 && e.depotIndex++, nt(e, t), t;
}
function it(e) {
	Q(e, "export", "", -1, 0, rt(e)), e.depotIndex === 0 && (e.depotRemaining[0] = 0, e.depotIndex = 1);
}
function at(e) {
	e.phase = "merger", e.maRound++, e.maPrices = e.companies.map((e) => e.active ? e.price : -1);
	let t = ye(e);
	e.queue = t.filter((t) => e.companies[t].price >= 4), e.saleQueue = [
		...e.companies.filter((e) => e.active && e.price === 0).sort((e, t) => t.liquidationOrder - e.liquidationOrder).map((e) => e.id),
		...t.filter((t) => e.companies[t].price > 0 && e.companies[t].price < 4).reverse(),
		...t.filter((t) => e.companies[t].price >= 4).reverse()
	], ot(e);
}
function ot(e) {
	for (e.phase = "merger"; e.queue.length;) {
		let t = e.companies[e.queue.shift()];
		if (!(!t.active || t.price < 4 || t.size === 10 || t.changed === e.maRound || !t.president)) {
			e.current = t.id, e.actor = t.president;
			return;
		}
	}
	st(e);
}
function st(e) {
	if (e.phase = "sale", e.pendingSale = !0, Ye(e), !(e.players.filter((e) => !e.bankrupt).length <= 1 || e.crisis || e.discardCompany !== null || e.excessTokens !== null)) {
		for (e.pendingSale = !1; e.saleQueue.length;) {
			let t = e.saleQueue.filter((t) => e.companies[t].active && e.companies[t].price === 0).sort((t, n) => e.companies[n].liquidationOrder - e.companies[t].liquidationOrder)[0];
			t !== void 0 && (e.saleQueue = [t, ...e.saleQueue.filter((e) => e !== t)]);
			let n = e.saleQueue.shift(), r = e.companies[n], i = e.maPrices[n];
			if (!(!r.active || i < 0 || i >= 4 && r.price > 0 && r.price < 4)) {
				if (e.current = n, r.price === 0 || i < 4) {
					ct(e, r, r.price === 0 ? "liquidation" : "acquisition");
					return;
				}
				if (r.president) {
					e.actor = r.president;
					return;
				}
			}
		}
		e.current = -1, e.operatingRound >= e.orSetEnd ? Qe(e) : et(e);
	}
}
function ct(e, t, n) {
	let r = t.president ?? e.priority;
	e.auction = {
		kind: n,
		target: t.id,
		hex: "",
		city: 0,
		bid: n === "friendly" ? t.size * I(t) - 10 : 0,
		leader: null,
		passed: [],
		initiator: r,
		next: ""
	}, e.phase = "auction", e.actor = R(e, r);
}
function lt(e) {
	let t = e.auction, n = e.players.filter((e) => !e.bankrupt && !t.passed.includes(e.rid));
	if (t.leader && n.length === 1 || !t.leader && n.length === 0) {
		ut(e);
		return;
	}
	let r = R(e, e.actor);
	for (; t.passed.includes(r);) r = R(e, r);
	e.actor = r;
}
function ut(e) {
	let t = e.auction;
	if (t.kind === "private") {
		let n = L(e, t.leader);
		n.cash -= t.bid, n.privates.push(t.target), e.seedMoney -= M[t.target] - t.bid, e.availablePrivates = e.availablePrivates.filter((e) => e !== t.target), Q(e, "private", n.rid, -1, t.bid, String(t.target)), e.actor = t.next, e.phase = "initial", e.auction = null;
	} else t.kind === "ipo" ? (e.phase = "funding", e.actor = t.leader) : t.leader ? (e.phase = "purchase", e.actor = t.leader) : t.kind === "liquidation" ? (ht(e, null, 0, 0), st(e)) : (e.auction = null, st(e));
}
function dt(e, t, n, r, i) {
	e.phase = "post", e.postCompany = t.id, e.postPresident = n, e.postForced = r, e.postTokenCost = i, e.postIndex = 0, e.postPlayers = [n];
	let a = R(e, n);
	for (; a !== n;) e.postPlayers.push(a), a = R(e, a);
	e.actor = n, e.step = 0;
}
function ft(e) {
	e.postIndex++, e.postIndex < e.postPlayers.length ? e.actor = e.postPlayers[e.postIndex] : (e.step = 1, e.actor = e.companies[e.postCompany].president);
}
function pt(e, t, n) {
	t.tokens += n.tokens;
	for (let r of Object.values(e.board)) {
		for (let e of r.tokens) e.company === n.id && (e.company = t.id);
		let e = /* @__PURE__ */ new Set();
		r.tokens = r.tokens.filter((n) => n.company !== t.id || !e.has(n.company) && (e.add(n.company), !0));
	}
}
function mt(e, t, n, r) {
	let i = e.companies[t], a = e.companies[n], o = i.president, s = o !== a.president, c = i.size === 2, l = e.companies[r], u = e.companies[r === t ? n : t], d = ue(c ? I(i) + I(a) : (I(i) + I(a)) / 2);
	for (let t of e.players) {
		let e = t.shares[i.id] + t.shares[a.id], n = t.shorts[i.id] + t.shorts[a.id];
		t.shares[i.id] = t.shares[a.id] = t.shorts[i.id] = t.shorts[a.id] = 0, t.shares[r] = c ? e / 2 : e, t.shorts[r] = n;
	}
	l.cash += u.cash, l.loans += u.loans, l.privates.push(...u.privates), l.trains.push(...u.trains), l.treasury = c ? 3 : i.treasury + a.treasury, l.market = i.market + a.market, l.bankShorts = i.bankShorts + a.bankShorts, pt(e, l, u), l.size = c ? 5 : 10, l.president = o, l.price = d, l.order = ++e.orderSerial, l.changed = e.maRound, e.companies[u.id] = Ge(u.id), ge(e, l), c || _e(e, l), c && s && Xe(e, o, l, "treasury"), Q(e, "merge", o, l.id, 0, `${t},${n}`), dt(e, l, l.president, !1, 0);
}
function ht(e, t, n, r) {
	let i = e.auction, a = e.companies[i.target], o = i.kind === "liquidation", s = i.leader ? i.bid : 0, c = s;
	if (t) pt(e, t, a), t.trains.push(...a.trains), t.privates.push(...a.privates), o || (t.cash += a.cash + (i.kind === "friendly" ? a.treasury * I(a) : 0), t.loans += a.loans, t.loans -= r, t.cash -= r * 100), a.loans = o ? a.loans : 0, B(e, t, n), t.cash -= s;
	else for (let t of Object.values(e.board)) t.tokens = t.tokens.filter((e) => e.company !== a.id);
	if (o) {
		let t = a.cash + s - a.loans * 100;
		t < 0 && a.president && !L(e, a.president).bankrupt && (L(e, a.president).cash += t), c = Math.max(0, t);
	}
	let l = Math.floor(c / a.size);
	for (let t of e.players) t.bankrupt || (t.cash += (t.shares[a.id] - t.shorts[a.id]) * l), t.shares[a.id] = t.shorts[a.id] = 0;
	Q(e, "sale", i.leader ?? "", a.id, s, t === null ? "" : String(t.id)), e.companies[a.id] = Ge(a.id), e.auction = null;
}
function gt(e, t) {
	let n = L(e, t);
	e.crisisCompany >= 0 && (e.companies[e.crisisCompany].cash += Math.max(0, e.crisisAmount + n.cash));
	for (let r of e.companies) r.active && (r.market += n.shares[r.id], r.bankShorts += n.shorts[r.id], n.shares[r.id] = n.shorts[r.id] = 0, r.president === t && qe(e, r), ge(e, r));
	n.cash = 0, n.bankrupt = !0, n.privates = [], e.crisis = null, e.crisisCompany = -1, e.crisisAmount = 0, Q(e, "bankrupt", t), e.actor === t && (e.actor = R(e, t)), e.phase === "operating" && e.current >= 0 && e.companies[e.current].president === t ? tt(e) : e.phase === "merger" && e.current >= 0 && e.companies[e.current].president === t && ot(e);
}
var $ = () => ({ code: "games.1817.invalid" }), _t = () => ({ code: "games.1817.notYourTurn" });
function vt(e, t, n) {
	if (We(e) !== n.by) return _t();
	let r = e.phase === "operating" && e.step === 2 && (t.type === "routes" || t.type === "pass") && !e.crisis && e.discardCompany === null && e.excessTokens === null ? ze(e, e.companies[e.current]) : [], i = structuredClone(e), a = L(i, n.by), o = t;
	if (i.phase === "stock" && [
		"buy",
		"ipo",
		"company",
		"pass"
	].includes(o.type) && de(i, a) > fe(i) && i.companies.some((e) => H(i, a, e, 1))) return $();
	if (i.crisis) {
		if (o.type === "sell" && o.count === 1 && H(i, a, i.companies[o.company], 1, !0)) Ze(i, a.rid, i.companies[o.company], 1);
		else if (o.type === "bankrupt" && !i.companies.some((e) => H(i, a, e, 1, !0))) gt(i, a.rid);
		else return $();
	} else if (i.discardCompany !== null) {
		let e = i.companies[i.discardCompany], t = o.type === "discard" ? e.trains.find((e) => e.id === o.train) : null;
		if (!t) return $();
		e.trains = e.trains.filter((e) => e.id !== t.id), t.obsolete || i.openTrains.push(t), Q(i, "discard", a.rid, e.id, 0, t.kind);
	} else if (i.excessTokens !== null) {
		let e = i.companies[i.excessTokens];
		if (o.type !== "keepTokens" || o.tokens.length !== 8 || new Set(o.tokens.map((e) => e.split(":")[0])).size !== 8 || o.tokens.some((t) => {
			let [n, r] = t.split(":");
			return !i.board[n]?.tokens.some((t) => t.company === e.id && t.city === Number(r));
		})) return $();
		for (let [t, n] of Object.entries(i.board)) n.tokens = n.tokens.filter((n) => n.company !== e.id || o.tokens.includes(`${t}:${n.city}`));
		e.tokens = 8;
	} else if (i.trade) {
		if (o.type !== "answer") return $();
		let e = i.trade;
		if (i.trade = null, o.accept) {
			if (e.kind === "merge") mt(i, e.company, e.target, e.survivor);
			else {
				let t = i.companies[e.company], n = i.companies[e.target], r = n.trains.find((t) => t.id === e.train);
				t.cash -= e.price, n.cash += e.price, t.trains.push(r), n.trains = n.trains.filter((t) => t.id !== e.train), Q(i, "train", e.proposer, t.id, e.price, r.kind);
			}
		}
	} else if (i.phase === "initial") {
		if (o.type === "private") {
			if (!i.availablePrivates.includes(o.id) || o.amount % 5 || o.amount < Math.max(0, M[o.id] - i.seedMoney) || o.amount > Math.min(a.cash, M[o.id])) return $();
			i.auction = {
				kind: "private",
				target: o.id,
				hex: "",
				city: 0,
				bid: o.amount,
				leader: a.rid,
				passed: [],
				initiator: a.rid,
				next: R(i, a.rid)
			}, i.phase = "auction", i.passes = 0, i.lastActor = a.rid, i.actor = R(i, a.rid);
		} else if (o.type === "pass") i.passes++, i.actor = R(i, a.rid), i.passes >= i.players.filter((e) => !e.bankrupt).length && (i.priority = R(i, i.lastActor), i.availablePrivates = [], Qe(i));
		else return $();
	} else if (i.phase === "auction") {
		let e = i.auction;
		if (o.type === "pass") e.passed.push(a.rid);
		else if (o.type === "bid") {
			if (o.amount <= e.bid) return $();
			if (e.kind === "private") {
				if (o.amount % 5 || o.amount > Math.min(M[e.target], a.cash)) return $();
			} else if (e.kind === "ipo") {
				if (o.amount % 5 || o.amount > 400 || !me(a, o.amount).length || de(i, a) >= fe(i)) return $();
			} else if (o.amount % 10 || e.initiator === a.rid && o.amount > e.bid + 10 || !be(i, a.rid, o.amount).length) return $();
			e.bid = o.amount, e.leader = a.rid;
		} else return $();
		lt(i);
	} else if (i.phase === "funding") {
		let e = i.auction;
		if (o.type !== "fund" || !ce(i.phaseNumber).includes(o.size) || new Set(o.privates).size !== o.privates.length || o.privates.some((e) => !a.privates.includes(e))) return $();
		let t = e.bid - o.privates.reduce((e, t) => e + M[t], 0);
		if (t < 0 || t > a.cash) return $();
		let n = i.companies[e.target];
		Object.assign(n, Ge(n.id), {
			active: !0,
			size: o.size,
			president: a.rid,
			cash: t,
			price: ue(e.bid / 2),
			order: ++i.orderSerial,
			treasury: o.size - 2,
			tokens: 1 + +!!o.privates.includes(4),
			tokenDebt: o.size === 10 ? 150 : o.size === 5 ? 50 : 0,
			privates: [...o.privates],
			started: i.round
		}), a.cash -= t, a.privates = a.privates.filter((e) => !o.privates.includes(e)), a.shares[n.id] = 2, Q(i, "ipo", a.rid, n.id, e.bid, String(o.size)), i.auction = null, i.phase = "stock", i.actor = e.initiator, i.stockActed = !0, $e(i);
	} else if (i.phase === "stock") {
		if (o.type === "sell" && i.stockStep === 0 && H(i, a, i.companies[o.company], o.count)) Ze(i, a.rid, i.companies[o.company], o.count), i.stockActed = !0;
		else if (o.type === "short" && i.stockStep <= 1 && ve(i, a, i.companies[o.company])) {
			let e = i.companies[o.company];
			a.shorts[e.id]++, e.market++, a.cash += I(e), a.sold.includes(e.id) || a.sold.push(e.id), i.stockStep = 2, i.stockActed = !0, Q(i, "short", a.rid, e.id, I(e));
		} else if (o.type === "buy" && V(i, a, i.companies[o.company], o.source)) Xe(i, a.rid, i.companies[o.company], o.source), i.stockActed = !0, $e(i);
		else if (o.type === "ipo" && de(i, a) < fe(i)) {
			if (i.companies[o.company].active || !Oe(i, o.hex, o.city) || o.amount < 100 || o.amount > 400 || o.amount % 5 || !me(a, o.amount).length) return $();
			i.board[o.hex].tokens.push({
				company: o.company,
				city: o.city
			}), i.auction = {
				kind: "ipo",
				target: o.company,
				hex: o.hex,
				city: o.city,
				bid: o.amount,
				leader: a.rid,
				passed: [],
				initiator: a.rid,
				next: R(i, a.rid)
			}, i.phase = "auction", i.actor = R(i, a.rid);
		} else if (o.type === "company" && !i.stockActed) {
			let e = i.companies[o.company];
			if (!e.active || e.price < 4 || e.president !== a.rid || o.loans + o.shares === 0 || o.shares > e.market || !B(i, e, o.loans) || e.cash < o.shares * I(e)) return $();
			e.cash -= o.shares * I(e), e.market -= o.shares, e.treasury += o.shares, Q(i, "finance", a.rid, e.id, o.loans, String(o.shares)), i.stockActed = !0, $e(i);
		} else if (o.type === "pass") {
			if (de(i, a) > fe(i) && i.companies.some((e) => H(i, a, e, 1))) return $();
			$e(i);
		} else return $();
	} else if (i.phase === "operating") {
		let e = i.companies[i.current];
		if (o.type === "loan" && i.step !== 5 && B(i, e, o.count)) Q(i, "loan", a.rid, e.id, o.count);
		else if (o.type === "bridge" && [2, 3].includes(o.private) && e.privates.includes(o.private) && i.privateUses[o.private] > 0 && [
			"H3",
			"G6",
			"H9"
		].includes(o.hex) && !i.board[o.hex].bridge) i.board[o.hex].bridge = !0, i.privateUses[o.private]--, Q(i, "bridge", a.rid, e.id, 0, o.hex);
		else if (o.type === "lay" && i.step === 0) {
			let t = Le(i, e, o.hex, o.tile, o.rotation, o.mine);
			if (!t) return $();
			let n = J(i, o.hex);
			if (e.cash += t.grant - t.cost, i.board[o.hex].tile = o.tile, i.board[o.hex].rotation = o.rotation, J(i, o.hex).nodes.length === 1) for (let e of i.board[o.hex].tokens) e.city = 0;
			i.lays.push(o.hex), i.upgraded ||= n.color !== "white", o.mine !== null && (i.board[o.hex].mine = !0, i.privateUses[o.mine]--), Q(i, "lay", a.rid, e.id, t.cost, `${o.hex} ${o.tile}`);
		} else if (o.type === "token" && i.step === 1 && !i.tokenPlaced && Oe(i, o.hex, o.city, e.id) && Pe(i, e).has(`${o.hex}:${-1 - o.city}`) && W.reduce((t, n) => t + i.board[n].tokens.filter((t) => t.company === e.id).length, 0) < e.tokens) i.board[o.hex].tokens.push({
			company: e.id,
			city: o.city
		}), i.tokenPlaced = !0, Q(i, "token", a.rid, e.id, 0, o.hex);
		else if (o.type === "routes" && i.step === 2) {
			let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), s = 0, c = [];
			for (let r of o.routes) {
				let a = e.trains.find((e) => e.id === r.train);
				if (!a || n.has(a.id) || r.paths.some((e) => t.has(e))) return $();
				let o = Re(i, e, r.paths, Number.parseInt(a.kind));
				if (o === null) return $();
				r.paths.forEach((e) => t.add(e)), n.add(a.id), s += o, c.push({
					...r,
					revenue: o
				});
			}
			if (s !== r.reduce((e, t) => e + t.revenue, 0)) return $();
			i.routes = c, i.revenue = s, e.trains = e.trains.filter((e) => !e.obsolete), i.step = 3, Q(i, "routes", a.rid, e.id, s);
		} else if (o.type === "dividend" && i.step === 3) {
			let t = o.mode === "withhold" ? 0 : o.mode === "full" ? i.revenue : e.size === 10 ? Math.ceil(i.revenue / 20) * 10 : i.revenue / 2, n = t / e.size;
			e.cash += i.revenue - t + n * e.treasury;
			for (let t of i.players) t.bankrupt || (t.cash += (t.shares[e.id] - t.shorts[e.id]) * n);
			let r = e.price < 4 ? 40 : I(e);
			z(i, e, t === 0 ? -1 : t >= r * 2 ? 2 : +(t >= r)), i.step = 4, Q(i, "dividend", a.rid, e.id, t, o.mode);
		} else if (o.type === "train" && i.step === 4 && e.trains.length < se(i.phaseNumber)) {
			if (o.seller === null) {
				let t = oe(i, o.train);
				if (!t) return $();
				let { open: n, kind: r } = t, s = N.indexOf(r);
				if (o.price !== P[s] || e.cash < o.price) return $();
				e.cash -= o.price, n ? (e.trains.push(n), i.openTrains = i.openTrains.filter((e) => e.id !== n.id)) : (e.trains.push({
					id: ++i.trainSerial,
					kind: r,
					obsolete: !1
				}), rt(i)), Q(i, "train", a.rid, e.id, o.price, r);
			} else {
				let t = i.companies[o.seller], n = t.trains.find((e) => String(e.id) === o.train);
				if (t.id === e.id || !t.active || t.price === 0 || !t.president || !n || n.obsolete || o.price < 1 || e.cash < o.price) return $();
				t.president === a.rid ? (e.cash -= o.price, t.cash += o.price, t.trains = t.trains.filter((e) => e.id !== n.id), e.trains.push(n), Q(i, "train", a.rid, e.id, o.price, n.kind)) : i.trade = {
					kind: "train",
					proposer: a.rid,
					recipient: t.president,
					company: e.id,
					target: t.id,
					survivor: e.id,
					train: n.id,
					price: o.price
				};
			}
		} else if (o.type === "repay" && i.step === 5 && o.count <= e.loans && e.cash >= 100 * o.count) e.loans -= o.count, e.cash -= o.count * 100, o.count && z(i, e, o.count), i.step = 6, Q(i, "repay", a.rid, e.id, o.count);
		else if (o.type === "pass") {
			if (i.step <= 1) i.step++;
			else if (i.step === 2) {
				if (r.length) return $();
				i.routes = [], i.revenue = 0, e.trains = e.trains.filter((e) => !e.obsolete), i.step = 3;
			} else if (i.step === 4) {
				for (; e.cash < e.loans * i.interest && B(i, e, 1););
				let t = e.loans * i.interest;
				e.cash >= t ? (e.cash -= t, i.step = 5, Q(i, "interest", a.rid, e.id, t)) : (qe(i, e), a.cash += e.cash - t, e.cash = 0, a.cash < 0 && (i.crisisCompany = e.id, i.crisisAmount = t), tt(i));
			} else if (i.step === 5) i.step = 6;
			else if (i.step === 6) e.trains.length || qe(i, e), tt(i);
			else return $();
		} else return $();
	} else if (i.phase === "merger") {
		let e = i.companies[i.current];
		if (o.type === "pass") ot(i);
		else if (o.type === "convert") {
			let t = e.size === 2, n = Math.min(8 - e.tokens, t ? 1 : 2);
			e.size = t ? 5 : 10, e.treasury += t ? 3 : 5, e.changed = i.maRound, Q(i, "convert", a.rid, e.id, e.size), dt(i, e, a.rid, !1, n * 50);
		} else if (o.type === "merge") {
			let t = i.companies[o.company];
			if (t.id === e.id || !t.active || t.size !== e.size || t.price < 4 || t.changed === i.maRound || !t.president || ![e.id, t.id].includes(o.survivor) || e.size === 2 && t.president !== a.rid && (a.cash < ae[ue(I(e) + I(t))] || de(i, a) >= fe(i))) return $();
			t.president === a.rid ? mt(i, e.id, t.id, o.survivor) : i.trade = {
				kind: "merge",
				proposer: a.rid,
				recipient: t.president,
				company: e.id,
				target: t.id,
				survivor: o.survivor,
				train: -1,
				price: 0
			};
		} else return $();
	} else if (i.phase === "post") {
		let e = i.companies[i.postCompany];
		if (i.step === 0) {
			if (o.type === "buy" && o.company === e.id && o.source === "treasury" && V(i, a, e, "treasury", !0)) Xe(i, a.rid, e, "treasury"), i.postIndex !== 0 && ft(i);
			else if (o.type === "sell" && i.postIndex > 0 && o.company === e.id && H(i, a, e, o.count, !1, !0)) Ze(i, a.rid, e, o.count), ft(i);
			else if (o.type === "pass") ft(i);
			else return $();
		} else if (o.type === "loan" && B(i, e, o.count)) Q(i, "loan", a.rid, e.id, o.count);
		else if (o.type === "pass") e.cash < i.postTokenCost ? qe(i, e) : (e.cash -= i.postTokenCost, e.tokens += i.postTokenCost / 50), ot(i);
		else return $();
	} else if (i.phase === "sale") {
		if (o.type === "offer") ct(i, i.companies[i.current], "friendly");
		else if (o.type === "pass") st(i);
		else return $();
	} else if (i.phase === "purchase") {
		if (o.type !== "purchase" || !be(i, a.rid, i.auction.bid).some((e) => e.id === o.company)) return $();
		let e = i.companies[o.company], t = i.companies[i.auction.target], n = i.auction.kind === "liquidation", r = n ? 0 : t.loans, s = e.cash + (n ? 0 : t.cash + (i.auction.kind === "friendly" ? t.treasury * I(t) : 0));
		if (o.repay > r || e.loans + r - o.repay + o.loans > e.size || le(i) - o.repay + o.loans > 70 || s + 100 * o.loans - 100 * o.repay < i.auction.bid) return $();
		let c = r - o.repay;
		ht(i, e, o.loans, o.repay), c && z(i, e, -c), st(i);
	} else return $();
	return Ye(i), i.pendingSale && i.phase !== "done" && !i.crisis && i.discardCompany === null && i.excessTokens === null && (st(i), Ye(i)), Ne(i), { state: i };
}
var yt = {
	meta: S,
	saveCompatibility: { version: "1" },
	schemas: {
		config: D,
		action: O,
		publicView: re,
		privateView: ie
	},
	setup: Ke,
	reduce: vt,
	viewFor: (e) => ({
		public: e,
		private: {}
	}),
	status: (e) => {
		if (e.phase !== "done" || e.crisis || e.discardCompany !== null || e.excessTokens !== null) return { phase: e.crisis ? "crisis" : e.phase === "done" ? "settling" : e.phase };
		let t = [...e.players].sort((t, n) => Number(t.bankrupt) - Number(n.bankrupt) || he(e, n) - he(e, t)).map((e) => e.rid), n = Object.fromEntries(e.players.map((t) => [t.rid, he(e, t)])), r = L(e, t[0]);
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((t) => !L(e, t).bankrupt && n[t] === n[r.rid]),
			scores: n
		};
	}
};
//#endregion
//#region src/games/1817/moves.ts
function bt(e) {
	let t = We(e), n = e.players.find((e) => e.rid === t);
	if (!n) return [];
	let r = [];
	if (e.crisis) {
		for (let t of e.companies) H(e, n, t, 1, !0) && r.push({
			type: "sell",
			company: t.id,
			count: 1
		});
		return r.length ? r : [{ type: "bankrupt" }];
	}
	if (e.discardCompany !== null) return e.companies[e.discardCompany].trains.map((e) => ({
		type: "discard",
		train: e.id
	}));
	if (e.excessTokens !== null) return [{
		type: "keepTokens",
		tokens: W.flatMap((t) => e.board[t].tokens.filter((t) => t.company === e.excessTokens).map((e) => `${t}:${e.city}`)).slice(0, 8)
	}];
	if (e.trade) return [{
		type: "answer",
		accept: !0
	}, {
		type: "answer",
		accept: !1
	}];
	if (e.phase === "initial") for (let t of e.availablePrivates) {
		let i = Math.max(0, M[t] - e.seedMoney);
		i <= n.cash && r.push({
			type: "private",
			id: t,
			amount: i
		});
	}
	else if (e.phase === "auction") {
		let t = e.auction, n = t.kind === "private" || t.kind === "ipo" ? 5 : 10, i = t.bid + n;
		r.push({
			type: "bid",
			amount: i
		});
	} else if (e.phase === "funding") for (let t of ce(e.phaseNumber)) for (let i of me(n, e.auction.bid)) r.push({
		type: "fund",
		size: t,
		privates: i
	});
	else if (e.phase === "stock") {
		for (let i of e.companies) if (i.active) {
			if (e.stockStep === 0) for (let t = 1; t <= n.shares[i.id]; t++) H(e, n, i, t) && r.push({
				type: "sell",
				company: i.id,
				count: t
			});
			e.stockStep <= 1 && ve(e, n, i) && r.push({
				type: "short",
				company: i.id
			});
			for (let t of ["treasury", "market"]) V(e, n, i, t) && r.push({
				type: "buy",
				company: i.id,
				source: t
			});
			if (!e.stockActed && i.president === t && i.price >= 4) for (let t = 0; t <= Math.min(i.size - i.loans, 70 - le(e)); t++) for (let e = 0; e <= i.market; e++) t + e && r.push({
				type: "company",
				company: i.id,
				loans: t,
				shares: e
			});
		}
		if (de(e, n) < fe(e)) {
			let t = e.companies.find((e) => !e.active);
			if (t) {
				for (let i of W) for (let a = 0; a < 2; a++) if (Oe(e, i, a)) {
					let e = Array.from({ length: 61 }, (e, t) => 100 + t * 5).find((e) => me(n, e).length);
					e !== void 0 && r.push({
						type: "ipo",
						company: t.id,
						hex: i,
						city: a,
						amount: e
					});
				}
			}
		}
	} else if (e.phase === "operating") {
		let t = e.companies[e.current];
		if (e.step !== 5) for (let n = 1; n <= Math.min(t.size - t.loans, 70 - le(e)); n++) r.push({
			type: "loan",
			count: n
		});
		for (let n of t.privates.filter((t) => (t === 2 || t === 3) && e.privateUses[t] > 0)) for (let t of [
			"H3",
			"G6",
			"H9"
		]) e.board[t].bridge || r.push({
			type: "bridge",
			private: n,
			hex: t
		});
		if (e.step === 0) {
			let n = He(e, t);
			r.push(...n.map((e) => ({
				type: "lay",
				...e
			})));
			for (let n of t.privates.filter((t) => [
				5,
				6,
				7
			].includes(t) && e.privateUses[t] > 0)) for (let e of W) for (let t of [
				"7",
				"8",
				"9"
			]) for (let i = 0; i < 6; i++) r.push({
				type: "lay",
				hex: e,
				tile: t,
				rotation: i,
				mine: n
			});
		} else if (e.step === 1) {
			let n = Pe(e, t);
			for (let e of W) for (let t = 0; t < 4; t++) n.has(`${e}:${-1 - t}`) && r.push({
				type: "token",
				hex: e,
				city: t
			});
		} else if (e.step === 2) r.push({
			type: "routes",
			routes: ze(e, t).map(({ train: e, paths: t }) => ({
				train: e,
				paths: t
			}))
		});
		else if (e.step === 3) for (let e of [
			"full",
			"half",
			"withhold"
		]) r.push({
			type: "dividend",
			mode: e
		});
		else if (e.step === 4 && t.trains.length < se(e.phaseNumber)) {
			r.push({
				type: "train",
				train: `bank:${N[e.depotIndex]}`,
				seller: null,
				price: P[e.depotIndex]
			});
			for (let t of e.openTrains) r.push({
				type: "train",
				train: `open:${t.id}`,
				seller: null,
				price: P[N.indexOf(t.kind)]
			});
			for (let n of e.companies) if (n.active && n.id !== t.id && n.price > 0 && n.president) for (let e of n.trains) e.obsolete || r.push({
				type: "train",
				train: String(e.id),
				seller: n.id,
				price: Math.min(t.cash, P[N.indexOf(e.kind)])
			});
		} else if (e.step === 5) for (let e = 0; e <= Math.min(t.loans, Math.floor(t.cash / 100)); e++) r.push({
			type: "repay",
			count: e
		});
	} else if (e.phase === "merger") {
		let t = e.companies[e.current];
		r.push({ type: "convert" });
		for (let n of e.companies) if (n.active && n.id !== t.id && n.size === t.size && n.price >= 4 && n.changed !== e.maRound) for (let e of [t.id, n.id]) r.push({
			type: "merge",
			company: n.id,
			survivor: e
		});
	} else if (e.phase === "post") {
		let t = e.companies[e.postCompany];
		if (e.step === 0) {
			if (V(e, n, t, "treasury", !0) && r.push({
				type: "buy",
				company: t.id,
				source: "treasury"
			}), e.postIndex > 0) for (let i = 1; i <= n.shares[t.id]; i++) H(e, n, t, i, !1, !0) && r.push({
				type: "sell",
				company: t.id,
				count: i
			});
		} else for (let n = 1; n <= Math.min(t.size - t.loans, 70 - le(e)); n++) r.push({
			type: "loan",
			count: n
		});
	} else if (e.phase === "sale") r.push({ type: "offer" });
	else if (e.phase === "purchase") {
		let n = e.companies[e.auction.target], i = e.auction.kind === "liquidation" ? 0 : n.loans;
		for (let n of be(e, t, e.auction.bid)) for (let e = 0; e <= i; e++) for (let t = 0; t <= n.size; t++) r.push({
			type: "purchase",
			company: n.id,
			loans: t,
			repay: e
		});
	}
	return r.push({ type: "pass" }), r.filter((n) => n.type === "lay" ? !!Le(e, e.companies[e.current], n.hex, n.tile, n.rotation, n.mine) : !("code" in vt(e, n, { by: t })));
}
function xt(e, t) {
	return ze(e, e.companies[t]).reduce((e, t) => e + t.revenue, 0);
}
//#endregion
//#region src/games/1817/keys.ts
var St = [
	"games.1817.p0",
	"games.1817.p1",
	"games.1817.p2",
	"games.1817.p3",
	"games.1817.p4",
	"games.1817.p5",
	"games.1817.p6",
	"games.1817.p7",
	"games.1817.p8",
	"games.1817.p9",
	"games.1817.p10"
], Ct = [
	"games.1817.effect0",
	"games.1817.effect1",
	"games.1817.effect2",
	"games.1817.effect3",
	"games.1817.effect4",
	"games.1817.effect5",
	"games.1817.effect6",
	"games.1817.effect7",
	"games.1817.effect8",
	"games.1817.effect9",
	"games.1817.effect10"
], wt = {
	initial: "games.1817.initial",
	auction: "games.1817.auction",
	funding: "games.1817.funding",
	stock: "games.1817.stock",
	operating: "games.1817.operating",
	merger: "games.1817.merger",
	post: "games.1817.post",
	sale: "games.1817.sale",
	purchase: "games.1817.purchase",
	done: "games.1817.done"
}, Tt = [
	"games.1817.layStep",
	"games.1817.tokenStep",
	"games.1817.routesStep",
	"games.1817.dividendStep",
	"games.1817.trainStep",
	"games.1817.repayStep",
	"games.1817.finishStep"
], Et = {
	private: "games.1817.logPrivate",
	ipo: "games.1817.logIPO",
	buy: "games.1817.logBuy",
	sell: "games.1817.logSell",
	short: "games.1817.logShort",
	finance: "games.1817.logFinance",
	loan: "games.1817.logLoan",
	repay: "games.1817.logRepay",
	lay: "games.1817.logLay",
	token: "games.1817.logToken",
	bridge: "games.1817.logBridge",
	routes: "games.1817.logRoutes",
	dividend: "games.1817.logDividend",
	train: "games.1817.logTrain",
	interest: "games.1817.logInterest",
	liquidate: "games.1817.logLiquidate",
	mail: "games.1817.logMail",
	stock: "games.1817.logStock",
	operating: "games.1817.logOperating",
	era: "games.1817.logEra",
	export: "games.1817.logExport",
	ending: "games.1817.logEnding",
	merge: "games.1817.logMerge",
	convert: "games.1817.logConvert",
	sale: "games.1817.logSale",
	bankrupt: "games.1817.logBankrupt",
	discard: "games.1817.logDiscard"
}, Dt = {
	reserve: 1,
	privateValue: .7,
	debtAversion: 1,
	growth: 1
};
function Ot(e, t) {
	let n = e.companies[t], r = 0;
	if (n.trains.length) {
		for (let n = e.log.length - 1; n >= 0; n--) if (e.log[n].key === "routes" && e.log[n].company === t) {
			r = e.log[n].amount;
			break;
		}
	}
	return (r - n.loans * e.interest) / n.size * 3 + n.cash / n.size * .5 - I(n);
}
function kt(e, t, n = !1) {
	let r = vt(e, t, { by: We(e) });
	if ("code" in r) return -Infinity;
	let i = r.state, a = i.companies[i.current];
	a.trains.length || (a.trains = [{
		id: -1,
		kind: "2",
		obsolete: !1
	}]);
	let o = Pe(i, a), s = new Set([...o].map((e) => e.split(":")[0])), c = 0;
	for (let e of W) {
		let t = J(i, e);
		if (!t.nodes.some((e) => e.type !== "junction") || s.has(e)) continue;
		let n = Ee(e), r = Math.min(...[...s].map((e) => {
			let t = Ee(e);
			return Math.hypot(n.x - t.x, n.y - t.y) / 34.64;
		}));
		c += Math.max(10, ...t.nodes.map((e) => e.revenue)) / Math.max(1, r) ** 2;
	}
	return (n ? xt(i, a.id) * 8 : 0) + s.size * 2 + c - (e.companies[e.current].cash - a.cash) * .15 + (t.mine === null ? 0 : 4);
}
function At(e, t = Dt) {
	let n = We(e), r = e.players.find((e) => e.rid === n);
	if (!r) return null;
	let i = /* @__PURE__ */ new Map(), a = (t) => (i.has(t) || i.set(t, Ot(e, t)), i.get(t)), o = bt(e), s = o.find((e) => e.type === "pass");
	if (!o.length) return null;
	if (e.crisis) return o.filter((e) => e.type === "sell").sort((e, t) => a(e.company) - a(t.company))[0] ?? o[0];
	if (e.discardCompany !== null) return o.sort((t, n) => Number.parseInt(e.companies[e.discardCompany].trains.find((e) => e.id === t.train).kind) - Number.parseInt(e.companies[e.discardCompany].trains.find((e) => e.id === n.train).kind))[0];
	if (e.excessTokens !== null) return o[0];
	if (e.trade) return {
		type: "answer",
		accept: e.trade.kind === "train" ? e.companies[e.trade.target].trains.length > 1 || e.trade.price >= P[N.indexOf(e.companies[e.trade.target].trains.find((t) => t.id === e.trade.train).kind)] : e.companies[e.trade.target].cash < 100 || e.companies[e.trade.target].loans > 0
	};
	if (e.phase === "initial") return o.filter((e) => e.type === "private").filter((e) => e.amount < M[e.id] * t.privateValue).sort((e, t) => M[t.id] - t.amount - (M[e.id] - e.amount))[0] ?? s;
	if (e.phase === "auction") {
		let i = e.auction, a = o.find((e) => e.type === "bid");
		if (!a || a.type !== "bid") return s;
		if (i.kind === "private") return a.amount <= M[i.target] * t.privateValue && r.cash - a.amount >= 90 ? a : s;
		if (i.kind === "ipo") return e.companies.filter((e) => e.active && e.president === n).length < 2 && a.amount <= Math.min(200, r.cash + r.privates.reduce((e, t) => e + M[t], 0)) ? a : s;
		let c = e.companies[i.target], l = c.trains.reduce((e, t) => e + P[N.indexOf(t.kind)] * (t.obsolete ? 0 : .65), 0) + (i.kind === "liquidation" ? 0 : c.cash - c.loans * 100) + c.tokens * 15;
		return a.amount <= l ? a : s;
	}
	if (e.phase === "funding") return o.filter((e) => e.type === "fund").sort((t, n) => {
		let r = (t) => {
			let n = e.auction.bid - t.privates.reduce((e, t) => e + M[t], 0);
			return t.privates.reduce((e, t) => e + M[t] * .5, 0) + Math.min(150, n) - (t.size - 2) * 12;
		};
		return r(n) - r(t);
	})[0];
	if (e.phase === "stock") {
		let t = e.companies.filter((e) => e.active && e.president === n), i = o.filter((e) => e.type === "company").find((t) => {
			let n = e.companies[t.company];
			return t.shares === 0 && t.loans === Math.ceil(Math.max(0, Math.max(n.tokenDebt, n.trains.length ? 0 : P[e.depotIndex]) - n.cash) / 100);
		});
		if (i) return i;
		let c = o.filter((e) => e.type === "buy").sort((e, t) => a(t.company) - a(e.company));
		if (c[0] && a(c[0].company) > 0) return c[0];
		let l = o.filter((e) => e.type === "ipo");
		if (l.length && t.length < (e.phaseNumber < 5 ? 2 : 1) && he(e, r) >= 100) {
			let t = [
				"D9",
				"C8",
				"G18",
				"G6",
				"F3",
				"F13",
				"H3",
				"F19",
				"C26",
				"C14"
			];
			l.sort((e, n) => (t.indexOf(e.hex) < 0 ? 99 : t.indexOf(e.hex)) - (t.indexOf(n.hex) < 0 ? 99 : t.indexOf(n.hex)));
			let n = l[0], i = e.phaseNumber >= 6 ? 250 : e.phaseNumber >= 3 ? 150 : 100, a = Array.from({ length: 61 }, (e, t) => 100 + t * 5).filter((e) => e >= i && e <= Math.min(400, r.cash + r.privates.reduce((e, t) => e + M[t], 0)) && me(r, e).length)[0];
			return a === void 0 ? n : {
				...n,
				amount: a
			};
		}
		return de(e, r) > de(e, {
			...r,
			shares: r.shares.map((e) => Math.min(e, 1))
		}) + 12 ? o.find((e) => e.type === "sell") ?? s : s ?? o[0];
	}
	if (e.phase === "operating") {
		let n = e.companies[e.current], r = o.find((e) => e.type === "loan" && e.count === 1);
		if (e.step === 0) {
			let t = o.find((e) => e.type === "bridge");
			if (t) return t;
			let i = o.filter((e) => e.type === "lay");
			if (i.length) {
				let t = i.map((t) => ({
					a: t,
					score: kt(e, t)
				})).sort((e, t) => t.score - e.score);
				return n.trains.some((e) => Number.parseInt(e.kind) >= 5) ? t[0].a : t.slice(0, 4).map(({ a: t }) => ({
					a: t,
					score: kt(e, t, !0)
				})).sort((e, t) => t.score - e.score)[0].a;
			}
			if (r && !e.lays.length && n.cash < 20 && n.loans < 2 && e.interest < 20) return r;
		} else if (e.step === 1) return o.find((e) => e.type === "token") ?? s;
		else if (e.step === 2) return o.find((e) => e.type === "routes");
		else if (e.step === 3) {
			let r = n.trains.length ? n.loans * e.interest * t.reserve : P[e.depotIndex] + n.loans * e.interest;
			return {
				type: "dividend",
				mode: n.cash + e.revenue / 2 < r ? "withhold" : n.cash > r + 200 ? "full" : "half"
			};
		} else if (e.step === 4) {
			let t = o.find((e) => e.type === "train" && e.seller === null), i = !n.trains.length || n.trains.every((e) => e.obsolete) || n.trains.length < 2 && n.cash >= P[e.depotIndex] + n.loans * e.interest + 30;
			if (t && i) return t;
			if (r && i && n.cash < P[e.depotIndex] && n.cash + (n.size - n.loans) * 100 >= P[e.depotIndex]) return r;
		} else if (e.step === 5) {
			let r = Math.max(40, P[e.depotIndex] * .35) * t.reserve;
			return o.filter((e) => e.type === "repay").filter((e) => n.cash - e.count * 100 >= r).at(-1) ?? {
				type: "repay",
				count: 0
			};
		}
		return s ?? o[0];
	}
	if (e.phase === "merger") {
		let n = e.companies[e.current], i = o.find((e) => e.type === "convert");
		return i && e.phaseNumber >= (n.size === 2 ? 3 : 5) && n.cash >= (n.size === 2 ? 50 : 100) && r.cash >= I(n) * t.growth ? i : s;
	}
	if (e.phase === "post") {
		let t = e.companies[e.postCompany], n = o.find((e) => e.type === "buy");
		return e.step === 0 ? n && (a(t.id) > 0 || t.cash < e.postTokenCost) && V(e, r, t, "treasury", !0) ? n : s : t.cash < e.postTokenCost ? o.find((e) => e.type === "loan" && e.count === 1) ?? s : s;
	}
	return e.phase === "sale" ? s : e.phase === "purchase" ? o.filter((e) => e.type === "purchase").sort((e, n) => e.loans * t.debtAversion - n.loans * t.debtAversion || n.repay - e.repay)[0] : o[0];
}
function jt(e = {}) {
	let t = {
		...Dt,
		...e
	};
	return (e, n) => {
		if (We(e.public) !== n.rid) return null;
		let r = At(e.public, n.difficulty === "weak" ? {
			...t,
			privateValue: .4,
			reserve: 1.6
		} : t);
		return r ? { action: r } : null;
	};
}
var Mt = jt(), Nt = (e, { public: t }, n) => {
	switch (e.type) {
		case "pass": return n("games.1817.pass");
		case "private": return `${n(St[e.id])}: $${e.amount}`;
		case "bid": return n("games.1817.bid", { n: e.amount });
		case "ipo": return `${U[e.company].symbol} · ${e.hex} · $${e.amount}`;
		case "fund": return n("games.1817.fund", { n: e.size });
		case "buy": return `${U[e.company].symbol} · ${n(e.source === "treasury" ? "games.1817.buyTreasury" : "games.1817.buyMarket")}`;
		case "sell": return `${U[e.company].symbol} · ${n("games.1817.sell", { n: e.count })}`;
		case "short": return `${U[e.company].symbol} · ${n("games.1817.short")}`;
		case "company": return n("games.1817.finance", {
			loans: e.loans,
			shares: e.shares
		});
		case "loan": return n("games.1817.loan", { n: e.count });
		case "repay": return n("games.1817.repay", { n: e.count });
		case "lay": return `${e.hex} · ${n("games.1817.tile", { n: e.tile })} · ${n("games.1817.rotation", { n: e.rotation + 1 })}${e.mine === null ? "" : ` · ${n("games.1817.mine")}`}`;
		case "token": return `${e.hex} · ${n("games.1817.placeToken")}`;
		case "bridge": return `${e.hex} · ${n("games.1817.bridge")}`;
		case "routes": return n("games.1817.run");
		case "dividend": return n(e.mode === "full" ? "games.1817.full" : e.mode === "half" ? "games.1817.half" : "games.1817.withhold");
		case "train": {
			let r = e.seller === null ? oe(t, e.train) : null;
			return n("games.1817.buyTrain", {
				train: (e.seller === null ? r?.open : t.companies[e.seller].trains.find((t) => String(t.id) === e.train))?.kind ?? r?.kind ?? e.train,
				seller: e.seller === null ? n(r?.open ? "games.1817.openMarket" : "games.1817.bank") : U[e.seller].name,
				n: e.price
			});
		}
		case "answer": return n(e.accept ? "games.1817.accept" : "games.1817.decline");
		case "discard": return n("games.1817.discard", { train: t.companies[t.discardCompany].trains.find((t) => t.id === e.train)?.kind ?? "" });
		case "convert": return n("games.1817.convert");
		case "merge": return `${n("games.1817.merge", { name: U[e.company].symbol })} · ${n("games.1817.survivor", { name: U[e.survivor].symbol })}`;
		case "offer": return n("games.1817.offer");
		case "purchase": return `${n("games.1817.acquire", { name: U[e.company].symbol })} · ${n("games.1817.loan", { n: e.loans })} · ${n("games.1817.repay", { n: e.repay })}`;
		case "keepTokens": return n("games.1817.keepTokens");
		case "bankrupt": return n("games.1817.bankrupt");
	}
}, Pt = Array.from({ length: 6 }, (e, t) => {
	let n = (-90 + t * 60) * Math.PI / 180;
	return `${Math.cos(n) * 20},${Math.sin(n) * 20}`;
}).join(" "), Ft = {
	white: "#dce8cf",
	yellow: "#f8d34d",
	green: "#72ae81",
	brown: "#b88657",
	gray: "#b7b9b2",
	red: "#a74c46",
	blue: "#a7d1d5"
};
function It(e, t) {
	return e.nodes.length === 2 ? {
		x: 0,
		y: t === 0 ? 6 : -6
	} : {
		x: 0,
		y: 0
	};
}
function Lt(e, t, n) {
	let r = t < 0 ? It(e, -1 - t) : q(t), i = n < 0 ? It(e, -1 - n) : q(n);
	return t < 0 || n < 0 || (t - n + 6) % 6 == 3 ? `M${r.x},${r.y}L${i.x},${i.y}` : `M${r.x},${r.y}Q0,0 ${i.x},${i.y}`;
}
function Rt(e, t) {
	let n = null, r = "";
	for (let i of t) {
		let [t, a] = i.split("/"), o = J(e, t), s = o.paths[Number(a)];
		if (!s) continue;
		let c = Ee(t), l = n ? s.find((e) => n.hex === t ? e === n.endpoint : e >= 0 && (e + 3) % 6 === n.endpoint) ?? s[0] : s.find((e) => e < 0) ?? s[0], u = s[0] === l ? s[1] : s[0], d = l < 0 ? It(o, -1 - l) : q(l), f = u < 0 ? It(o, -1 - u) : q(u);
		r += `${r ? "L" : "M"}${c.x + d.x},${c.y + d.y}`, r += l < 0 || u < 0 || (l - u + 6) % 6 == 3 ? `L${c.x + f.x},${c.y + f.y}` : `Q${c.x},${c.y} ${c.x + f.x},${c.y + f.y}`, n = {
			hex: t,
			endpoint: u
		};
	}
	return r;
}
function zt({ tile: e, children: t, selected: n = !1 }) {
	return /* @__PURE__ */ y("g", { children: [
		/* @__PURE__ */ v("polygon", {
			points: Pt,
			fill: Ft[e.color],
			stroke: n ? "#164e63" : "#6b755e",
			strokeWidth: n ? 1.4 : .5
		}),
		e.terrain === "mountain" && /* @__PURE__ */ v("g", {
			fill: "#b0b49d",
			stroke: "#8d9579",
			strokeWidth: "0.3",
			children: /* @__PURE__ */ v("path", { d: "M-13,-6l5,-8 6,8ZM2,-6l4,-6 6,6Z" })
		}),
		e.terrain === "water" && /* @__PURE__ */ v("path", {
			d: "M-15,-10Q-5,-4 0,-10T15,-9",
			fill: "none",
			stroke: "#6aa4b8",
			strokeWidth: "2"
		}),
		e.paths.map(([t, n], r) => /* @__PURE__ */ v("path", {
			d: Lt(e, t, n),
			stroke: "#28332e",
			fill: "none",
			strokeWidth: "2.8",
			strokeLinecap: "round"
		}, r)),
		e.nodes.map((t, n) => {
			let r = It(e, n);
			return /* @__PURE__ */ y("g", {
				transform: `translate(${r.x} ${r.y})`,
				children: [t.type === "city" ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("circle", {
					r: t.slots > 2 ? 8 : t.slots === 2 ? 7 : 5,
					fill: "#fffdf4",
					stroke: "#34463c",
					strokeWidth: "0.65"
				}), t.slots > 1 && Array.from({ length: t.slots }, (e, n) => /* @__PURE__ */ v("circle", {
					cx: (n - (t.slots - 1) / 2) * 4,
					cy: "0",
					r: "1.4",
					fill: "none",
					stroke: "#7a8174",
					strokeWidth: "0.4"
				}, n))] }) : t.type === "junction" ? null : /* @__PURE__ */ v("circle", {
					r: "2",
					fill: e.color === "red" ? "#fff4d6" : "#263c35"
				}), t.type !== "junction" && /* @__PURE__ */ v("text", {
					y: e.nodes.length > 1 ? 0 : -8,
					x: e.nodes.length > 1 ? 10 : 0,
					textAnchor: "middle",
					fontSize: "5.5",
					fontWeight: "700",
					fill: e.color === "red" ? "#fff" : "#28362c",
					children: t.revenue || ""
				})]
			}, n);
		}),
		e.label && /* @__PURE__ */ v("text", {
			x: "11",
			y: "-10",
			fontSize: "4.5",
			fontWeight: "700",
			textAnchor: "middle",
			children: e.label
		}),
		e.border.map((e) => {
			let t = (90 + e * 60) * Math.PI / 180, n = t + Math.PI / 3;
			return /* @__PURE__ */ v("line", {
				x1: 20 * Math.cos(t),
				y1: 20 * Math.sin(t),
				x2: 20 * Math.cos(n),
				y2: 20 * Math.sin(n),
				stroke: "#277fa7",
				strokeWidth: "2"
			}, e);
		}),
		t
	] });
}
function Bt({ state: e, selected: t, legal: n = [], preview: r }) {
	return /* @__PURE__ */ y("g", { children: [
		/* @__PURE__ */ v("rect", {
			width: 560,
			height: 330,
			fill: "#d2e3d6"
		}),
		/* @__PURE__ */ v("path", {
			d: "M0,0H560V330H410Q430,280 460,200T540,80H0Z",
			fill: "#b2d2d1",
			opacity: "0.45"
		}),
		W.map((r) => {
			let i = Ee(r), a = J(e, r), o = e.board[r], s = Se[r].name, c = s === "Maritime Prov." ? ["Maritime", "Prov."] : [s];
			return /* @__PURE__ */ y("g", {
				transform: `translate(${i.x} ${i.y})`,
				children: [
					/* @__PURE__ */ v("title", { children: `${r}${s ? ` · ${s}` : ""}` }),
					/* @__PURE__ */ y("g", {
						className: o.tile ? "r1817-tile-enter" : void 0,
						children: [
							/* @__PURE__ */ v(zt, {
								tile: a,
								selected: r === t
							}),
							s && /* @__PURE__ */ v("text", {
								textAnchor: "middle",
								y: a.nodes.length > 1 ? 14 : 11,
								fontSize: "4.2",
								fontFamily: "Georgia,serif",
								fill: a.color === "red" ? "#fff9e9" : "#253f32",
								children: c.map((e, t) => /* @__PURE__ */ v("tspan", {
									x: "0",
									dy: t ? 4.5 : 0,
									children: e
								}, t))
							}),
							/* @__PURE__ */ v("text", {
								x: "-11",
								y: "-11",
								fontSize: "3.4",
								fill: a.color === "red" ? "#fff" : "#56684f",
								children: r
							}),
							a.cost > 0 && !o.tile && /* @__PURE__ */ y("text", {
								x: "0",
								y: "17",
								textAnchor: "middle",
								fontSize: "4",
								fill: "#6b5034",
								children: ["$", a.cost]
							})
						]
					}, `${o.tile}:${o.rotation}`),
					e.routes.flatMap((t, n) => t.paths.filter((e) => e.startsWith(`${r}/`)).map((t) => {
						let r = Number(t.split("/")[1]), i = a.paths[r];
						return i ? /* @__PURE__ */ v("path", {
							d: Lt(a, ...i),
							fill: "none",
							stroke: [
								"#b83222",
								"#006e9a",
								"#7c2fa4",
								"#095f37"
							][n % 4],
							strokeWidth: "1.4",
							strokeDasharray: "3 1",
							children: /* @__PURE__ */ v("animate", {
								ref: Vt,
								begin: "indefinite",
								attributeName: "stroke-dashoffset",
								from: "12",
								to: "0",
								dur: "1s",
								repeatCount: "1"
							})
						}, `${n}:${t}:${e.operatingRound}:${e.current}`) : null;
					})),
					o.tokens.map((e) => {
						let t = a.nodes[e.city], n = It(a, e.city), r = o.tokens.filter((t) => t.city === e.city), i = (r.indexOf(e) - (r.length - 1) / 2) * 6, s = U[e.company];
						return /* @__PURE__ */ y("g", {
							transform: `translate(${n.x + i} ${n.y})`,
							className: "r1817-token-enter",
							children: [/* @__PURE__ */ v("circle", {
								r: "3.6",
								fill: s.color,
								stroke: "#fff",
								strokeWidth: "0.7"
							}), /* @__PURE__ */ v("text", {
								textAnchor: "middle",
								dominantBaseline: "central",
								fontSize: t?.slots > 2 ? 2 : 2.3,
								fill: "#101e17",
								fontWeight: "900",
								stroke: "#fff",
								strokeWidth: "0.4",
								paintOrder: "stroke",
								children: s.symbol
							})]
						}, `${e.company}:${e.city}`);
					}),
					o.mine && /* @__PURE__ */ y("g", {
						transform: "translate(10 10)",
						children: [/* @__PURE__ */ v("path", {
							d: "M-4,2l2,-5 5,1 1,4Z",
							fill: "#242924"
						}), /* @__PURE__ */ v("text", {
							y: "6",
							fontSize: "3",
							textAnchor: "middle",
							children: "+10"
						})]
					}),
					o.bridge && /* @__PURE__ */ v("g", {
						transform: "translate(-10 10)",
						stroke: "#314640",
						strokeWidth: "0.9",
						fill: "none",
						children: /* @__PURE__ */ v("path", { d: "M-4,2V-2H4V2M-4,0H4M-2,-2V2M2,-2V2" })
					}),
					n.includes(r) && /* @__PURE__ */ v("polygon", {
						points: Pt,
						fill: "#fff",
						fillOpacity: "0.15",
						stroke: "#064863",
						strokeWidth: "0.9",
						strokeDasharray: "3 2",
						pointerEvents: "none",
						children: /* @__PURE__ */ v("animate", {
							ref: Vt,
							begin: "indefinite",
							attributeName: "stroke-dashoffset",
							from: "10",
							to: "0",
							dur: "0.8s",
							repeatCount: "indefinite"
						})
					})
				]
			}, r);
		}),
		e.routes.map((t, n) => /* @__PURE__ */ v("g", {
			pointerEvents: "none",
			children: /* @__PURE__ */ y("rect", {
				x: "-3",
				y: "-1.6",
				width: "6",
				height: "3.2",
				rx: "0.6",
				fill: [
					"#b83222",
					"#006e9a",
					"#7c2fa4",
					"#095f37"
				][n % 4],
				stroke: "#fff",
				strokeWidth: "0.5",
				children: [/* @__PURE__ */ v("animateMotion", {
					ref: Vt,
					begin: "indefinite",
					path: Rt(e, t.paths),
					dur: "2.4s",
					rotate: "auto",
					fill: "freeze"
				}), /* @__PURE__ */ v("animate", {
					ref: Vt,
					begin: "indefinite",
					attributeName: "opacity",
					values: "0;1;1;0",
					keyTimes: "0;0.05;0.92;1",
					dur: "2.4s",
					fill: "freeze"
				})]
			})
		}, `${e.operatingRound}:${e.current}:${t.train}`)),
		r && (() => {
			let t = xe[r.tile], n = Ee(r.hex);
			return t ? /* @__PURE__ */ v("g", {
				transform: `translate(${n.x} ${n.y})`,
				opacity: "0.85",
				pointerEvents: "none",
				children: /* @__PURE__ */ v(zt, {
					tile: De(t.color, t.code, e.phaseNumber, r.rotation),
					selected: !0
				})
			}) : null;
		})()
	] });
}
var Vt = (e) => {
	e?.beginElement();
};
//#endregion
//#region src/games/1817/view-player.tsx
function Ht(e) {
	return /* @__PURE__ */ v(Ut, {
		...e,
		state: e.public
	});
}
function Ut({ state: e, members: t, myRid: b, send: x, readOnly: S = !1 }) {
	let C = h(), w = We(e), T = !S && w === b, E = (n) => {
		let r = t.find((e) => e.rid === n), i = r?.colorIndex ?? Math.max(0, e.players.findIndex((e) => e.rid === n));
		return r?.name || C(l[i % l.length].nameKey);
	}, [D, O] = a(0), [k, A] = a(null), [j, ee] = a(0), [te, ne] = a(!1), [re, ie] = a(null), [N, P] = a(!1), F = `${b}:${w}:${e.phase}:${e.current}:${e.step}:${e.postIndex}`, [oe, ce] = a(null), pe = (e) => {
		O(e), ce({
			viewer: b,
			id: e
		});
	}, [me, R] = a({
		scope: F,
		action: null
	}), z = r(() => S ? [] : bt(e), [e, S]), B = me.scope === F && me.action && !("code" in vt(e, me.action, { by: w })) ? me.action : null, ge = e.companies[D], _e = e.current >= 0 ? e.companies[e.current] : null, V = oe?.viewer === b ? e.companies[oe.id] : e.phase === "operating" || e.phase === "merger" || e.phase === "sale" ? _e : e.phase === "post" ? e.companies[e.postCompany] : ge, H = e.phase === "initial" || e.auction?.kind === "private", ve = e.auction?.kind === "private" ? e.auction.target : e.availablePrivates.includes(j) ? j : e.availablePrivates[0], ye = T ? [...new Set(z.flatMap((e) => "hex" in e ? [e.hex] : []))] : [], [be, Ce] = a({
		scope: "",
		tokens: []
	}), we = be.scope === F ? be.tokens : [], Te = C(wt[e.phase]);
	e.crisis ? Te = C("games.1817.crisis") : e.discardCompany === null ? e.excessTokens === null ? e.trade ? Te = C("games.1817.consent") : e.phase === "operating" && (Te = C(Tt[e.step])) : Te = C("games.1817.tokensStep") : Te = C("games.1817.discardStep");
	let W = e.trade?.company ?? e.discardCompany ?? e.excessTokens ?? ([
		"operating",
		"merger",
		"sale"
	].includes(e.phase) ? e.current : e.phase === "post" ? e.postCompany : e.phase === "purchase" ? e.auction?.target : void 0);
	!e.crisis && W !== void 0 && W >= 0 && (Te = `${U[W].symbol} · ${Te}`);
	let G = e.trade, K = G?.kind === "merge" ? e.companies[G.company] : null, q = G?.kind === "merge" ? e.companies[G.target] : null, J = K && q ? ae[ue(K.size === 2 ? I(K) + I(q) : (I(K) + I(q)) / 2)] : 0, Oe = (t) => Nt(t, {
		public: e,
		private: {}
	}, C), Y = (e) => {
		T && (x(e), R({
			scope: F,
			action: null
		}));
	}, ke = (e) => R({
		scope: F,
		action: e
	}), Ae = (t) => !("code" in vt(e, t, { by: w })), je = z.filter((t) => [
		"pass",
		"ipo",
		"private",
		"lay",
		"token",
		"bridge",
		"keepTokens"
	].includes(t.type) ? !1 : e.phase === "stock" && "company" in t ? t.company === D : !0), Me = B && (B.type === "bid" || B.type === "private" || B.type === "ipo" || B.type === "train") ? B : null, [Ne, X] = a({
		scope: "",
		amount: 0
	}), Z = Ne.scope === F ? Ne.amount : Me && "amount" in Me ? Me.amount : e.auction ? e.auction.bid + (e.auction.kind === "private" || e.auction.kind === "ipo" ? 5 : 10) : 100, Pe = (e) => {
		ke(e), "amount" in e ? X({
			scope: F,
			amount: e.amount
		}) : e.type === "train" && X({
			scope: F,
			amount: e.price
		});
	}, Fe = k ? Se[k] : null, Ie = z.filter((e) => e.type === "lay" && e.hex === k), Re = Ie.filter((e, t) => Ie.findIndex((t) => t.tile === e.tile && t.mine === e.mine) === t), ze = z.filter((e) => (e.type === "token" || e.type === "bridge") && e.hex === k), Be = z.find((e) => e.type === "ipo" && e.hex === k), Ve = Be ? {
		...Be,
		company: ge.active ? Be.company : D,
		amount: Ne.scope === F ? Z : Be.amount
	} : null, He = z.find((e) => e.type === "pass"), Ue = je.filter((e) => e.type === "loan"), Q = je.filter((e) => e.type !== "loan"), Ge = i(null), [Ke, qe] = a({
		x: 0,
		y: 0
	}), Je = B?.type === "lay" ? B.hex : null;
	return n(() => {
		let e = Ge.current, t = e?.querySelector("svg > g");
		if (!e || !t || !Je) return;
		let n = () => {
			let n = t.getScreenCTM(), r = e.getBoundingClientRect(), i = Ee(Je);
			if (!n) return;
			let a = n.a * i.x + n.c * i.y + n.e - r.left, o = n.b * i.x + n.d * i.y + n.f - r.top;
			qe({
				x: Math.max(Math.min(130, r.width / 2), Math.min(r.width - Math.min(130, r.width / 2), a)),
				y: Math.max(4, Math.min(r.height - 52, o + (o > r.height - 100 ? -70 : 28)))
			});
		};
		n();
		let r = new ResizeObserver(n), i = new MutationObserver(n);
		return r.observe(e), i.observe(t, {
			attributes: !0,
			attributeFilter: ["transform"]
		}), () => {
			r.disconnect(), i.disconnect();
		};
	}, [Je]), /* @__PURE__ */ y(o, {
		adaptive: !0,
		scroll: !1,
		className: "r1817-root",
		banner: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ y("header", {
			className: "r1817-header",
			children: [
				/* @__PURE__ */ v("strong", { children: "1817" }),
				/* @__PURE__ */ y("span", { children: [
					C(wt[e.phase]),
					" · ",
					C("games.1817.phase"),
					" ",
					e.phaseNumber
				] }),
				/* @__PURE__ */ y("span", {
					className: "r1817-interest",
					children: [
						C("games.1817.interest"),
						" $",
						e.interest,
						" · ",
						C("games.1817.loanSummary", { n: le(e) })
					]
				}),
				/* @__PURE__ */ v("button", {
					onClick: () => ne(!0),
					"aria-label": C("games.1817.history"),
					children: /* @__PURE__ */ v(f, { size: 20 })
				})
			]
		}), /* @__PURE__ */ v("div", {
			className: "r1817-investors",
			children: e.players.map((e, n) => {
				let r = t.find((t) => t.rid === e.rid), i = l[(r?.colorIndex ?? n) % l.length];
				return /* @__PURE__ */ y("button", {
					className: `r1817-investor${w === e.rid ? " r1817-active" : ""}`,
					style: { "--investor-color": i.hex },
					onClick: () => ie(e.rid),
					children: [/* @__PURE__ */ v("img", {
						src: c[r?.avatar ?? n % c.length],
						alt: ""
					}), /* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v("b", { children: E(e.rid) }), /* @__PURE__ */ v("small", { children: e.bankrupt ? C("games.1817.bankruptPlayer") : /* @__PURE__ */ y(_, { children: [
						/* @__PURE__ */ v("span", { children: C("games.1817.cash") }),
						" $",
						/* @__PURE__ */ v(m, { value: e.cash })
					] }) })] })]
				}, e.rid);
			})
		})] }),
		children: [
			/* @__PURE__ */ y("div", {
				className: "r1817-table",
				children: [
					/* @__PURE__ */ y("div", {
						className: "r1817-scene",
						children: [
							/* @__PURE__ */ y("div", {
								className: "r1817-map",
								ref: Ge,
								children: [/* @__PURE__ */ v(g, {
									sheetW: 560,
									sheetH: 330,
									fitKey: "1817-base-map",
									clampToSheet: !0,
									highlight: "off",
									eligible: Object.keys(e.board).map((e) => {
										let t = Ee(e);
										return {
											key: e,
											rect: {
												x: t.x,
												y: t.y,
												w: 0,
												h: 0
											}
										};
									}),
									onTapEligible: (t) => {
										if (A(t), P(!0), R({
											scope: F,
											action: null
										}), e.excessTokens !== null) {
											let n = e.board[t].tokens.find((t) => t.company === e.excessTokens);
											if (n) {
												let e = `${t}:${n.city}`;
												Ce({
													scope: F,
													tokens: we.includes(e) ? we.filter((t) => t !== e) : [...we, e].slice(-8)
												});
											}
										}
									},
									children: /* @__PURE__ */ v(Bt, {
										state: e,
										selected: k,
										legal: e.excessTokens === null ? ye : Object.keys(e.board).filter((t) => e.board[t].tokens.some((t) => t.company === e.excessTokens)),
										preview: B?.type === "lay" ? B : null
									})
								}), B?.type === "lay" && /* @__PURE__ */ y("div", {
									className: "r1817-map-tools",
									style: {
										left: Ke.x,
										top: Ke.y,
										bottom: "auto"
									},
									children: [
										/* @__PURE__ */ y("b", { children: [
											B.hex,
											" · ",
											B.tile
										] }),
										/* @__PURE__ */ v("button", {
											"aria-label": C("games.1817.rotation", { n: B.rotation + 1 }),
											onClick: () => {
												let e = Ie.filter((e) => e.tile === B.tile && e.mine === B.mine), t = e.findIndex((e) => e.rotation === B.rotation);
												ke(e[(t + 1) % e.length]);
											},
											children: /* @__PURE__ */ v(p, { size: 18 })
										}),
										/* @__PURE__ */ v("button", {
											onClick: () => Y(B),
											children: C("games.1817.confirm")
										}),
										/* @__PURE__ */ v("button", {
											onClick: () => R({
												scope: F,
												action: null
											}),
											"aria-label": C("games.1817.cancel"),
											children: /* @__PURE__ */ v(d, { size: 18 })
										})
									]
								})]
							}),
							H && !N && /* @__PURE__ */ y("div", {
								className: "r1817-privates",
								children: [/* @__PURE__ */ y("h2", { children: [C("games.1817.initial"), /* @__PURE__ */ y("small", { children: [
									C("games.1817.subsidy"),
									" $",
									e.seedMoney
								] })] }), /* @__PURE__ */ v("div", {
									className: "r1817-private-grid",
									children: (e.auction?.kind === "private" ? [e.auction.target] : e.availablePrivates).map((e) => /* @__PURE__ */ y("button", {
										className: `r1817-private${e === ve ? " r1817-selected" : ""}`,
										onClick: () => {
											ee(e);
											let t = z.find((t) => t.type === "private" && t.id === e);
											t && Pe(t);
										},
										children: [
											/* @__PURE__ */ v("span", {
												className: "r1817-private-symbol",
												"aria-hidden": "true",
												children: /* @__PURE__ */ v("svg", {
													viewBox: "0 0 48 30",
													children: /* @__PURE__ */ v("path", {
														d: e < 2 ? "M4,25V13H12V5H18V13H26V20H42V25ZM9,25V20M20,25V20M32,25V20" : e < 4 ? "M4,25V10H44V25M4,13Q24,-2 44,13M14,10V25M24,5V25M34,10V25" : e < 5 ? "M6,26V11L24,2L42,11V26ZM20,26V16H28V26" : e < 8 ? "M8,25L14,8L28,3L40,16L36,25Z" : "M4,7H44V27H4ZM4,7L24,20L44,7",
														fill: "none",
														stroke: "currentColor",
														strokeWidth: "2"
													})
												})
											}),
											/* @__PURE__ */ v("b", { children: C(St[e]) }),
											/* @__PURE__ */ y("span", {
												className: "r1817-face",
												children: ["$", M[e]]
											}),
											/* @__PURE__ */ v("p", { children: C(Ct[e]) })
										]
									}, e))
								})]
							}),
							H && /* @__PURE__ */ v("button", {
								className: "r1817-map-toggle",
								onClick: () => P((e) => !e),
								children: C(N ? "games.1817.privates" : "games.1817.map")
							})
						]
					}),
					/* @__PURE__ */ y("aside", {
						className: "r1817-ledger",
						children: [
							/* @__PURE__ */ v("div", {
								className: "r1817-phase",
								children: /* @__PURE__ */ v(s, {
									text: Te,
									tone: T ? "accent" : "info",
									accent: "#213c37",
									sub: T ? C("games.1817.yours") : w ? C("games.1817.waiting", { name: E(w) }) : void 0
								})
							}),
							/* @__PURE__ */ y("div", {
								className: "r1817-ledger-scroll",
								children: [
									G && /* @__PURE__ */ v("section", {
										className: "r1817-auction",
										children: K && q ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("p", { children: C("games.1817.mergeOffer", {
											first: U[K.id].name,
											second: U[q.id].name,
											survivor: U[G.survivor].name,
											shares: K.size === 2 ? 5 : 10,
											price: J
										}) }), K.size === 2 && K.president !== q.president && /* @__PURE__ */ v("p", { children: C("games.1817.mergeFunding", {
											name: E(G.proposer),
											n: J
										}) })] }) : /* @__PURE__ */ v("p", { children: C("games.1817.trainOffer", {
											buyer: U[G.company].name,
											seller: U[G.target].name,
											train: e.companies[G.target].trains.find((e) => e.id === G.train).kind,
											n: G.price
										}) })
									}),
									e.auction && /* @__PURE__ */ y("div", {
										className: "r1817-auction",
										children: [
											/* @__PURE__ */ v("b", { children: e.auction.kind === "private" ? C(St[e.auction.target]) : U[e.auction.target].name }),
											/* @__PURE__ */ v("strong", { children: C("games.1817.bidNow", { n: e.auction.bid }) }),
											e.auction.leader && /* @__PURE__ */ v("span", { children: E(e.auction.leader) })
										]
									}),
									!H && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("div", {
										className: "r1817-company-list",
										children: e.companies.map((e) => /* @__PURE__ */ y("button", {
											"aria-pressed": V?.id === e.id,
											onClick: () => pe(e.id),
											style: { "--rail-color": U[e.id].color },
											children: [/* @__PURE__ */ v("span", { children: U[e.id].symbol }), e.active && /* @__PURE__ */ v("small", { children: e.price < 4 ? C(e.price === 0 ? "games.1817.liquidationZone" : "games.1817.acquisitionZone") : `$${I(e)}` })]
										}, e.id))
									}), V?.active && /* @__PURE__ */ y("section", {
										className: "r1817-charter",
										style: { "--rail-color": U[V.id].color },
										children: [
											/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("span", {
												className: "r1817-seal",
												children: U[V.id].symbol
											}), /* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("h2", { children: U[V.id].name }), /* @__PURE__ */ v("small", { children: C("games.1817.sharesCount", { n: V.size }) })] })] }),
											/* @__PURE__ */ y("dl", { children: [
												/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("dt", { children: C("games.1817.treasury") }), /* @__PURE__ */ y("dd", { children: ["$", /* @__PURE__ */ v(m, { value: V.cash })] })] }),
												/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("dt", { children: C("games.1817.price") }), /* @__PURE__ */ y("dd", { children: ["$", I(V)] })] }),
												/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("dt", { children: C("games.1817.loans") }), /* @__PURE__ */ y("dd", { children: [
													V.loans,
													" / ",
													V.size
												] })] }),
												/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("dt", { children: C("games.1817.tokens") }), /* @__PURE__ */ v("dd", { children: V.tokens })] })
											] }),
											/* @__PURE__ */ y("p", { children: [
												C("games.1817.president"),
												" · ",
												V.president ? E(V.president) : "—"
											] }),
											/* @__PURE__ */ v("div", {
												className: "r1817-trains",
												children: V.trains.map((e) => /* @__PURE__ */ y("span", {
													className: "r1817-train",
													children: [/* @__PURE__ */ v("svg", {
														viewBox: "0 0 40 22",
														"aria-hidden": "true",
														children: /* @__PURE__ */ v("path", {
															d: "M3,17V6H17V2H24V6H32L37,17ZM9,17A3,3 0 1 0 9,22A3,3 0 1 0 9,17M29,17A3,3 0 1 0 29,22A3,3 0 1 0 29,17",
															fill: "currentColor"
														})
													}), /* @__PURE__ */ v("b", { children: e.kind })]
												}, e.id))
											}),
											/* @__PURE__ */ y("small", { children: [
												C("games.1817.trainLimit", {
													n: V.trains.length,
													max: se(e.phaseNumber)
												}),
												" · ",
												C("games.1817.treasuryCount", { n: V.treasury }),
												" · ",
												C("games.1817.marketCount", { n: V.market })
											] }),
											V.tokenDebt > 0 && /* @__PURE__ */ v("p", {
												className: "r1817-warning",
												children: C("games.1817.debt", { n: V.tokenDebt })
											}),
											V.privates.map((e) => /* @__PURE__ */ y("details", { children: [/* @__PURE__ */ v("summary", { children: C(St[e]) }), /* @__PURE__ */ v("p", { children: C(Ct[e]) })] }, e))
										]
									})] }),
									k && /* @__PURE__ */ y("section", {
										className: "r1817-hex-context",
										children: [/* @__PURE__ */ y("h3", { children: [k, Fe?.name ? ` · ${Fe.name}` : ""] }), T && /* @__PURE__ */ y(_, { children: [
											Re.length > 0 && /* @__PURE__ */ v("div", {
												className: "r1817-tile-tray",
												children: Re.map((t) => {
													let n = xe[t.tile], r = Le(e, e.companies[e.current], t.hex, t.tile, t.rotation, t.mine)?.cost ?? 0;
													return /* @__PURE__ */ y("button", {
														onClick: () => ke(t),
														className: B?.type === "lay" && B.tile === t.tile && B.mine === t.mine ? "r1817-selected" : "",
														"aria-label": Oe(t),
														children: [
															/* @__PURE__ */ v("svg", {
																viewBox: "-23 -23 46 46",
																children: /* @__PURE__ */ v(zt, { tile: De(n.color, n.code, e.phaseNumber, t.rotation) })
															}),
															/* @__PURE__ */ y("span", { children: [
																t.tile,
																" · $",
																r
															] }),
															t.mine !== null && /* @__PURE__ */ v("small", { children: C("games.1817.mine") })
														]
													}, `${t.tile}:${t.mine}`);
												})
											}),
											ze.map((e, t) => /* @__PURE__ */ y("button", {
												className: "r1817-action",
												onClick: () => Y(e),
												children: [Oe(e), "city" in e ? ` · ${C("games.1817.city", { n: e.city + 1 })}` : ""]
											}, t)),
											Ve && /* @__PURE__ */ y("div", {
												className: "r1817-ipo",
												children: [
													/* @__PURE__ */ y("label", { children: [C("games.1817.railways"), /* @__PURE__ */ v("select", {
														value: Ve.company,
														onChange: (e) => O(Number(e.target.value)),
														children: e.companies.filter((e) => !e.active).map((e) => /* @__PURE__ */ v("option", {
															value: e.id,
															children: U[e.id].name
														}, e.id))
													})] }),
													/* @__PURE__ */ y("label", { children: [C("games.1817.amount"), /* @__PURE__ */ v("input", {
														type: "number",
														min: "100",
														max: "400",
														step: "5",
														value: Ve.amount,
														onChange: (e) => X({
															scope: F,
															amount: Number(e.target.value)
														})
													})] }),
													z.filter((e) => e.type === "ipo" && e.hex === k).map((e) => {
														let t = {
															...Ve,
															city: e.city
														};
														return /* @__PURE__ */ y("button", {
															className: "r1817-action",
															disabled: !Ae(t),
															onClick: () => Y(t),
															children: [
																C("games.1817.ipo", { n: t.amount }),
																" · ",
																C("games.1817.city", { n: e.city + 1 })
															]
														}, e.city);
													})
												]
											})
										] })]
									}),
									T && /* @__PURE__ */ y("div", {
										className: "r1817-decisions",
										children: [
											e.phase === "initial" && ve !== void 0 && (() => {
												let t = Ne.scope === F ? Z : Math.max(0, M[ve] - e.seedMoney), n = {
													type: "private",
													id: ve,
													amount: t
												};
												return /* @__PURE__ */ y(_, { children: [
													/* @__PURE__ */ v("h3", { children: C(St[ve]) }),
													/* @__PURE__ */ y("label", { children: [C("games.1817.amount"), /* @__PURE__ */ v("input", {
														type: "number",
														value: t,
														step: "5",
														min: "0",
														max: M[ve],
														onChange: (e) => X({
															scope: F,
															amount: Number(e.target.value)
														})
													})] }),
													/* @__PURE__ */ v("button", {
														className: "r1817-action",
														disabled: !Ae(n),
														onClick: () => Y(n),
														children: C("games.1817.privateBuy", { n: t })
													})
												] });
											})(),
											e.phase === "auction" && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ y("label", { children: [C("games.1817.amount"), /* @__PURE__ */ v("input", {
												type: "number",
												step: e.auction.kind === "private" || e.auction.kind === "ipo" ? 5 : 10,
												value: Z,
												onChange: (e) => X({
													scope: F,
													amount: Number(e.target.value)
												})
											})] }), /* @__PURE__ */ v("button", {
												className: "r1817-action",
												disabled: !Ae({
													type: "bid",
													amount: Z
												}),
												onClick: () => Y({
													type: "bid",
													amount: Z
												}),
												children: C("games.1817.bid", { n: Z })
											})] }),
											e.excessTokens !== null && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("p", { children: we.join(" · ") || C("games.1817.selectHex") }), /* @__PURE__ */ v("button", {
												className: "r1817-action",
												disabled: !Ae({
													type: "keepTokens",
													tokens: we
												}),
												onClick: () => Y({
													type: "keepTokens",
													tokens: we
												}),
												children: C("games.1817.keepTokens")
											})] }),
											Q.filter((e) => e.type !== "bid").map((t, n) => /* @__PURE__ */ y("button", {
												className: `r1817-action${t.type === "bankrupt" ? " r1817-danger" : ""}`,
												onClick: () => t.type === "train" && t.seller !== null ? Pe(t) : Y(t),
												children: [Oe(t), t.type === "fund" && /* @__PURE__ */ v("small", { children: t.privates.map((e) => C(St[e])).join(" · ") || C("games.1817.cashPayment", { n: e.auction.bid }) })]
											}, n)),
											B?.type === "train" && B.seller !== null && /* @__PURE__ */ y("div", { children: [
												/* @__PURE__ */ v("p", { children: Oe({
													...B,
													price: Z
												}) }),
												/* @__PURE__ */ y("label", { children: [C("games.1817.adjustTrain"), /* @__PURE__ */ v("input", {
													type: "number",
													min: "1",
													value: Z,
													onChange: (e) => X({
														scope: F,
														amount: Number(e.target.value)
													})
												})] }),
												/* @__PURE__ */ v("button", {
													className: "r1817-action",
													disabled: !Ae({
														...B,
														price: Z
													}),
													onClick: () => Y({
														...B,
														price: Z
													}),
													children: C("games.1817.confirm")
												})
											] }),
											!!Ue.length && /* @__PURE__ */ y("details", { children: [/* @__PURE__ */ v("summary", { children: C("games.1817.loans") }), Ue.map((e, t) => /* @__PURE__ */ v("button", {
												className: "r1817-action",
												onClick: () => Y(e),
												children: Oe(e)
											}, t))] }),
											!k && (e.phase === "stock" || e.phase === "operating" && e.step <= 1) && /* @__PURE__ */ v("p", { children: C("games.1817.selectHex") })
										]
									})
								]
							}),
							/* @__PURE__ */ v("footer", {
								className: "r1817-ledger-footer",
								children: T && He ? /* @__PURE__ */ v("button", {
									className: "r1817-action r1817-secondary",
									onClick: () => Y(He),
									children: C(e.phase === "stock" && e.stockActed ? "games.1817.endTurn" : e.phase === "operating" ? "games.1817.nextStep" : "games.1817.pass")
								}) : /* @__PURE__ */ v("span", { children: S ? C("games.1817.done") : w ? C("games.1817.waiting", { name: E(w) }) : C("games.1817.done") })
							})
						]
					}),
					/* @__PURE__ */ v("div", {
						className: "r1817-exchange",
						"aria-label": C("games.1817.exchange"),
						children: /* @__PURE__ */ y("div", {
							className: "r1817-exchange-track",
							style: { minHeight: 28 + Math.max(1, ...e.companies.map((t) => e.companies.filter((e) => e.active && e.price === t.price).length)) * 24 },
							children: [Array.from({ length: 32 }, (e, t) => /* @__PURE__ */ v("div", {
								className: `r1817-market-cell${t < 4 ? " r1817-market-risk" : ""}`,
								children: /* @__PURE__ */ v("b", { children: t < 4 ? t === 0 ? "×" : "—" : I({ price: t }) })
							}, t)), e.companies.filter((e) => e.active).map((t) => /* @__PURE__ */ v("button", {
								className: "r1817-stock-marker",
								onClick: () => pe(t.id),
								style: {
									background: U[t.id].color,
									"--market-price": t.price,
									"--market-stack": e.companies.filter((e) => e.active && e.price === t.price && (e.order < t.order || e.order === t.order && e.id < t.id)).length
								},
								"aria-label": `${U[t.id].name} · ${C("games.1817.price")} $${I(t)}`,
								children: U[t.id].symbol
							}, t.id))]
						})
					})
				]
			}),
			/* @__PURE__ */ v(u, {
				open: te,
				onClose: () => ne(!1),
				label: C("games.1817.history"),
				title: C("games.1817.history"),
				children: /* @__PURE__ */ v("ol", {
					className: "r1817-log",
					children: e.log.map((e, t) => /* @__PURE__ */ v("li", { children: Et[e.key] ? C(Et[e.key], {
						name: E(e.rid),
						company: U[e.company]?.symbol ?? "",
						n: e.amount,
						detail: e.key === "private" ? C(St[Number(e.detail)]) : e.detail
					}) : "" }, t))
				})
			}),
			/* @__PURE__ */ v(u, {
				open: re !== null,
				onClose: () => ie(null),
				label: C("games.1817.portfolio"),
				title: re ? E(re) : "",
				children: re && (() => {
					let t = L(e, re);
					return /* @__PURE__ */ y("div", {
						className: "r1817-portfolio",
						children: [
							/* @__PURE__ */ y("h3", { children: [
								C("games.1817.wealth"),
								" $",
								he(e, t)
							] }),
							/* @__PURE__ */ y("p", { children: [
								C("games.1817.cash"),
								" $",
								t.cash,
								" · ",
								C("games.1817.certificates", {
									n: de(e, t),
									max: fe(e)
								})
							] }),
							e.companies.filter((e) => t.shares[e.id] || t.shorts[e.id]).map((e) => /* @__PURE__ */ y("div", {
								className: "r1817-position",
								children: [/* @__PURE__ */ v("b", { children: U[e.id].name }), /* @__PURE__ */ y("span", { children: [
									C("games.1817.shares"),
									" ",
									t.shares[e.id],
									" · ",
									C("games.1817.shorts"),
									" ",
									t.shorts[e.id]
								] })]
							}, e.id)),
							t.privates.map((e) => /* @__PURE__ */ y("details", { children: [/* @__PURE__ */ y("summary", { children: [
								C(St[e]),
								" · $",
								M[e]
							] }), /* @__PURE__ */ v("p", { children: C(Ct[e]) })] }, e))
						]
					});
				})()
			})
		]
	});
}
//#endregion
//#region src/games/1817/game-over.tsx
function Wt({ result: e, public: t, members: n, myRid: r, hintCount: i, onPlayAgain: o, onBackToLobby: s }) {
	let u = t, f = h(), [p, m] = a(!0), [g, _] = a(null), b = (e) => {
		let t = n.find((t) => t.rid === e), r = Math.max(0, u.players.findIndex((t) => t.rid === e));
		return t?.name || f(l[(t?.colorIndex ?? r) % l.length].nameKey);
	}, x = e.ranking.map((t) => {
		let n = u.players.find((e) => e.rid === t), r = n.shares.reduce((e, t, n) => e + t * I(u.companies[n]), 0), i = n.shorts.reduce((e, t, n) => e + t * I(u.companies[n]), 0);
		return {
			rid: t,
			cash: n.cash,
			long: r,
			short: i,
			total: e.scores?.[t] ?? n.cash + r - i,
			bankrupt: n.bankrupt
		};
	});
	return /* @__PURE__ */ y("div", {
		className: "r1817-ending",
		children: [
			/* @__PURE__ */ v("div", {
				className: "r1817-ending-board",
				inert: p,
				children: /* @__PURE__ */ v(Ut, {
					public: u,
					state: u,
					members: n,
					myRid: r,
					send: () => {},
					readOnly: !0
				})
			}),
			/* @__PURE__ */ v("button", {
				className: "r1817-result-toggle",
				onClick: () => m(!0),
				children: f("games.1817.showResult")
			}),
			/* @__PURE__ */ v("div", {
				className: "r1817-result-mask",
				hidden: !p,
				children: /* @__PURE__ */ y("section", {
					className: "r1817-final",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": f("games.1817.finalTitle"),
					children: [
						/* @__PURE__ */ y("header", { children: [
							/* @__PURE__ */ v("span", {
								className: "r1817-final-year",
								children: "1817"
							}),
							/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("h1", { children: f("games.1817.finalTitle") }), /* @__PURE__ */ v("p", { children: f(e.winner.length > 1 ? "games.1817.tie" : "games.1817.winner", { name: e.winner.map(b).join(" · ") }) })] }),
							/* @__PURE__ */ v("button", {
								onClick: () => m(!1),
								"aria-label": f("games.1817.reviewMap"),
								children: /* @__PURE__ */ v(d, { size: 24 })
							})
						] }),
						/* @__PURE__ */ y("div", {
							className: "r1817-final-scroll",
							children: [
								/* @__PURE__ */ v("div", {
									className: "r1817-accounts-scroll",
									children: /* @__PURE__ */ y("table", {
										className: "r1817-accounts",
										style: { minWidth: 100 + x.length * 100 },
										children: [/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { children: "—" }), x.map((t) => {
											let r = n.find((e) => e.rid === t.rid), i = u.players.findIndex((e) => e.rid === t.rid);
											return /* @__PURE__ */ y("th", {
												"data-winner": e.winner.includes(t.rid),
												children: [
													/* @__PURE__ */ v("img", {
														src: c[r?.avatar ?? i % c.length],
														alt: ""
													}),
													/* @__PURE__ */ v("b", { children: b(t.rid) }),
													t.bankrupt && /* @__PURE__ */ v("small", { children: f("games.1817.bankruptPlayer") })
												]
											}, t.rid);
										})] }) }), /* @__PURE__ */ v("tbody", { children: [
											{
												key: "cash",
												label: "games.1817.finalCash"
											},
											{
												key: "long",
												label: "games.1817.finalLong"
											},
											{
												key: "short",
												label: "games.1817.finalShort"
											},
											{
												key: "total",
												label: "games.1817.finalTotal"
											}
										].map((e) => /* @__PURE__ */ y("tr", {
											className: e.key === "total" ? "r1817-final-total" : void 0,
											children: [/* @__PURE__ */ v("th", { children: f(e.label) }), x.map((t) => /* @__PURE__ */ y("td", { children: [
												e.key === "short" ? "−" : "",
												"$",
												t[e.key]
											] }, t.rid))]
										}, e.key)) })]
									})
								}),
								i !== void 0 && i > 0 && /* @__PURE__ */ v("p", { children: f("games.1817.hints", { n: i }) }),
								x.map((t) => e.autopilot?.[t.rid] ? /* @__PURE__ */ y("p", { children: [
									b(t.rid),
									" · ",
									f("games.1817.autopilot", { n: Math.round(e.autopilot[t.rid] * 100) })
								] }, t.rid) : null)
							]
						}),
						/* @__PURE__ */ y("footer", { children: [
							/* @__PURE__ */ v("button", {
								onClick: () => m(!1),
								children: f("games.1817.reviewMap")
							}),
							o && /* @__PURE__ */ v("button", {
								onClick: () => g === "again" ? o() : _("again"),
								children: f(g === "again" ? "games.1817.confirm" : "games.1817.playAgain")
							}),
							s && /* @__PURE__ */ v("button", {
								onClick: () => g === "leave" ? s() : _("leave"),
								children: f(g === "leave" ? "games.1817.leaveConfirm" : "games.1817.lobby")
							}),
							!o && !s && /* @__PURE__ */ v("span", { children: f("games.1817.waitHost") })
						] })
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/1817/options.tsx
function Gt({ value: e, onChange: t }) {
	let n = h(), r = D.parse(e);
	return /* @__PURE__ */ v("div", {
		className: "flex flex-col gap-4",
		children: [
			{
				key: "increasedShorts",
				title: "games.1817.optionShorts"
			},
			{
				key: "shortSqueeze",
				title: "games.1817.optionSqueeze"
			},
			{
				key: "modernTrains",
				title: "games.1817.optionModern"
			}
		].map((e) => /* @__PURE__ */ v(x, {
			title: n(e.title),
			columns: 2,
			children: [!1, !0].map((i) => /* @__PURE__ */ v(b, {
				name: `1817-${e.key}`,
				value: String(i),
				checked: r[e.key] === i,
				label: n(i ? "games.1817.on" : "games.1817.off"),
				accent: S.accent,
				onChange: () => t({
					...r,
					[e.key]: i
				})
			}, String(i)))
		}, e.key))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/1817/entry.tsx
var Kt = {
	definition: yt,
	View: Ht,
	bot: Mt,
	describe: Nt,
	OverView: Wt,
	Options: Gt,
	locales: {
		zh: {
			name: "1817",
			desc: "铺设铁路，操控股权、卖空和贷款，在收购与清算中积累财富。",
			rules: "目标:\n你以投资人的身份持有铁路公司股份，同时担任所控制公司的总裁。个人现金与公司资金分别记账。游戏结束时，个人财富等于现金加持股市值，再减去空头市值；公司资产与私人公司不计分。财富最高者获胜。若只剩一位未破产的投资人，该投资人立即获胜。\n准备:\n· 基础版支持 3 至 7 人。3、4、5、6、7 人分别获得 420、315、252、210、180 美元，证书上限分别为 21、16、13、11、9 张。总统证代表两股，但只算一张证书；私人公司与空头不计入证书上限。\n· 随机决定首位投资人。11 家私人公司公开拍卖，公共补贴池共有 200 美元。私人公司随后只能作为新公司首次发行的出资，不能转售。\n初始拍卖:\n当前投资人选择一家私人公司发起拍卖，也可以跳过。起拍价加剩余补贴不得低于面值，所有出价均为 5 美元的整数倍，且不得超过面值或自己持有的现金。参与者依次加价或退出，同一场拍卖中退出后不能重新加入。\n只剩一位竞买者时，该竞买者支付出价，补贴池支付面值与出价的差额。由发起拍卖者左侧的投资人继续选择下一场拍卖。所有人连续跳过后，移除剩余私人公司，开始股票轮。\n股票轮:\n每轮从优先交易权持有者开始，依次行动，直到所有未破产的投资人连续跳过。行动过的投资人仍会获得后续回合；优先交易权交给最后行动者左侧的投资人。\n· 个人行动依次为：卖出任意数量的持股；最多卖空一股；购买一张证书，或发起一家新公司的首次发行。可以省略其中任意步骤，但必须遵守先后次序。购买或首次发行结束本次行动。\n· 公司行动替代整次个人行动：为一家由自己担任总裁、且不在收购区或清算区的公司取得贷款，然后可以从市场回购本公司任意数量的股份。至少执行其中一项。\n· 买入的价格为当前每股股价，钱支付给股份来源方。卖股与卖空均从银行领取当前股价，卖出不会直接降低股价。本股票轮卖过或卖空过的公司，本轮不得买入。\n· 2 股公司不能买卖普通股份或卖空。新公司首次发行所在的股票轮不能卖出或卖空其股票。收购区公司的股票不能交易。总统证不得进入市场；卖股导致另一位至少持有两股的投资人持股更多时，总统身份转移。同量时原总裁优先，否则从原总裁左侧依次比较。\n· 5 股公司的个人持股上限为 3 股，10 股公司为 6 股。超过证书上限时，须尽可能卖股后才可结束股票行动。购买股票平掉空头不受证书和持股上限限制。\n· 卖空会产生一股市场流通股和一股个人空头，同时收到股价。每家公司最多存在 5 股空头。个人不能同时持有同一家公司的多头与空头，取得匹配股份时立即抵消。第 8 阶段禁止新增卖空，既有空头仍须结算。\n首次发行:\n选择尚未使用的公司及一处空闲城市站位；不能选择多伦多。总统证以 100 至 400 美元、按 5 美元递增拍卖。中标者选择当前阶段允许的股本，并以现金和私人公司的面值恰好支付出价。私人公司归新公司所有，只有现金部分进入公司金库。初始股价为出价的一半，向下取股价表上的价格。\n2 股、5 股、10 股公司分别拥有 1、2、4 枚基础站标。首次发行的首枚免费；5 股与 10 股公司须在股票轮结束前分别支付 50 或 150 美元购买其余站标，可以在后续公司行动中贷款筹款。未能支付的公司进入清算。\n股票轮结束时，投资人合计持有至少全部股本的 5 股或 10 股公司，股价先右移一格；随后每一股市场股票使股价左移一格。股价最高 600 美元，向左最低停在最左收购格。\n贷款与轮次:\n股票轮后依次进行运营轮、合并收购轮、第二运营轮和第二合并收购轮，然后返回股票轮。每笔贷款获得 100 美元，并使股价左移一格；每还一笔贷款支付 100 美元，并使股价右移一格。公司最多持有等于股本股数的贷款，全局共 70 笔。\n每个运营轮开始时，按已借贷款每五笔一档设定每笔利息，每档为 5 美元，最低为 5 美元。本运营轮内利率固定。拥有火车的公司先领取其邮政合同收入。公司按股价从高到低运营，同价时先进入该价位的公司优先。\n公司运营:\n· 铺轨：可以铺设或升级最多两块不同格的板块，其中最多一次升级。第二次操作另行支付 20 美元。黄色、绿色、棕色、灰色板块分别在第 2、3、5、7 阶段开放；必须逐色升级并保留既有轨道和站标。普通城市升棕时须尽量使用出口更多的板块。\n· 新轨道须与公司的合法网络相连，未铺轨的起始城市可以先铺城市板块。轨道不能出界、跨越不可通行边界或进入红灰格没有接口的一侧。首次铺轨支付地形费用，底特律和纽约升绿另行支付 20 美元；矿场格不能升级。\n· 放置站标：每次运营最多从公司库存放置一枚站标，目的城市必须有空位且与公司网络相连。本公司在同格不能重复放置，不能在多伦多放置。放置时不再付费。\n· 运行火车：每条路线至少含一枚本公司站标，两端为城市或红色外部地点。不能重复城市或轨段，纽约两个城区视作同一个城市。其他公司填满的城市可作终点但不能穿过，红区只可作端点。火车数字限制经过的城市和外部地点数量；矿场不占停靠次数且不能作端点。各列火车不能共用轨段，须采用合计收入最高的合法路线。界面会提供最高收入路线。\n· 分红：可以全额分红、半额分红或保留全部收入。分红按股本股数分配，金库股份的分红给公司，市场股份的分红由银行保留。空头持有人向银行支付相同的每股分红。10 股公司半额分红时，分给股东的部分向上取至 10 美元，留存部分向下取至 10 美元。\n· 总分红为零时股价左移一格；达到当前股价时右移一格，达到两倍时右移两格。收购区股价在此计算中按 40 美元处理。\n· 买车：未达火车上限时，可以从银行按标价买车，也可以经卖方总裁同意、以至少 1 美元从其他未清算公司买车。总裁不能以个人现金补贴买车。银行新车依次出售；公开市场上的弃车按原价出售。\n· 利息：买车结束后，公司必须支付全部利息，并在需要时尽量贷款，新增贷款本轮也计息。仍付不起时，公司进入清算，公司现金交给总裁，由总裁支付利息；不足时进入现金危机。\n· 还贷与结束：利息付清后可偿还任意数量的贷款。完成还贷步骤后可再次贷款；利息结算后至还贷步骤完成前不得贷款。公司结束运营时没有火车就进入清算。每个运营轮末出口下一列新车，可能触发阶段变化。\n火车与阶段:\n· 银行依次提供：2 型 100 美元，2+ 型 100 美元，3 型 250 美元，4 型 400 美元，5 型 600 美元，6 型 750 美元，7 型 900 美元，8 型 1100 美元。2+、3、4、5、6、7 型数量分别为 4、12、8、5、4、3 列。2 型仅首个运营轮无限供应，首轮出口后撤下全部余车；8 型无限供应。\n· 第 2、3 阶段公司最多持有 4 列车，第 4、5 阶段最多 3 列，第 6 阶段起最多 2 列。超限时立即由总裁选择弃车至公开市场。\n· 首列 4 型使所有 2 型淘汰；2+ 型可以再运行一次，随后移除，期间不能转卖。首列 6 型淘汰所有 3 型，首列 8 型淘汰所有 4 型。\n· 新公司允许的股本依次为：第 2 阶段只能 2 股；第 3 阶段可选 2 或 5 股；第 4 阶段只能 5 股；第 5 阶段可选 5 或 10 股；第 6 阶段起只能 10 股。已有公司不必强制扩股。\n私人公司:\n· 匹兹堡钢厂，面值 40 美元：可在匹兹堡铺专用黄色城市板块，不要求连通，仍占一次铺轨。\n· 山地工程师，面值 40 美元：每次在山地首次铺黄轨，先支付费用，再让公司获得 20 美元。\n· 俄亥俄桥梁与联合桥梁，面值分别为 40、80 美元：首次铺河流格免地形费，并分别提供一枚、两枚桥梁。可在公司运营期间把桥放在路易维尔、辛辛那提或查尔斯顿，不要求连通；每城最多一枚，所有路线经过时均加 10 美元。\n· 车站，面值 80 美元：向公司额外提供一枚站标。\n· 小型、普通与大型煤矿，面值分别为 30、60、90 美元：分别提供一枚、两枚、三枚矿场。首次在紧邻城市或红色地点的山地铺黄轨时，可放矿场并免山地费；轨道必须能直接连接该地点，允许相邻城市未来升级后接通。矿场使路线增加 10 美元，此格不能升级。\n· 小型、普通与大型邮政合同，面值分别为 60、90、120 美元：公司在每个运营轮开始时有火车，分别获得 10、15、20 美元。\n合并与扩股:\n合并收购轮先按开始时的运营顺序，处理不在收购区或清算区的公司。每家公司每轮最多扩股或合并一次；本次跳过仍可接受后续公司的合并提议。合并须经双方总裁同意，不要求铁路相连。\n· 2 股公司可扩至 5 股，金库新增三股；之后须购买一枚站标，费用 50 美元。5 股公司可扩至 10 股，新增五股，并购买两枚站标，费用 100 美元。站标最多八枚，只购买未超过上限的数量；付不起则清算。\n· 两家 2 股公司可合为一家 5 股公司，各原始两股折为一股，新股价为两公司原股价之和，向下取股价表价格。金库新增三股。不同总裁时，发起方总裁必须再买一股成为新总裁，另一方得到一股。\n· 两家 5 股公司可合为一家 10 股公司，按一比一合并多头、空头及金库股份，新股价为原股价平均值向下取值。持股最多者成为总裁；并列时发起方总裁优先。匹配的多头与空头立即抵消。\n· 扩股或合并后，原总裁先可从金库购买任意数量的股份，再由其左侧起其余投资人各获得一次买一股金库股份、卖任意持股或跳过的机会。不可卖空。随后公司可以贷款，并支付扩股所需站标费用。\n收购与清算:\n完成扩股合并后，依次处理最近进入清算区的公司、按倒运营顺序的收购区公司，再按倒运营顺序让正常公司选择是否自愿出售。在本轮转换或收购中刚进入收购区的公司，不加入本轮收购拍卖，也不能继续收购。\n· 清算拍卖由银行以零美元起标，只出售火车、站标与私人公司。收购拍卖最低 10 美元。自愿出售最低为股价乘股本股数，成交后目标公司的金库股份先按股价卖给银行，增加目标现金。\n· 从目标总裁左侧起，以 10 美元的整数倍竞价。目标总裁为自己的其他公司竞买时，每次只能比前价多出 10 美元。退出后不得重入。中标者才指定自己的哪家正常公司购买；须能承担出价及继承的全部贷款，可以利用目标现金、取得新贷款，并偿还继承贷款。\n· 正常收购继承目标的现金与贷款；每笔未偿还的继承贷款使买方股价左移一格。成交价除股本股数向下取整，逐股支付给多头，并向空头收取。目标公司随后可重新发行。\n· 清算时，公司原现金加拍卖款先偿还全部贷款。不足由总裁承担；有盈余才按股数向多头分配并向空头收取。无人竞买时移除资产。没有未破产总裁的公司，其不足由银行承担。\n· 合并与收购继承全部站标。同格重复站标退回金库；总数超过八枚时，总裁须优先选择保留至多八个不同格的已放置站标，其余可用站标补足至八枚。超限火车立即弃置。\n现金危机与结束:\n个人现金不足以支付空头分红、清算债务或公司利息时，必须逐股出售可以合法出售的持股，且不能导致总统身份转移。没有可售股份且仍不足时破产退出；持股、空头及私人公司进入市场，所担任总裁的公司进入清算。银行立即抵消匹配多空，并在每个股票轮开始时从金库购买股份，继续平掉银行空头。\n首列 8 型火车购入或出口后，再完成三个运营轮及中间的合并收购轮。如果触发时是本组第一个运营轮，先完成本组，再进行股票轮和最后两个运营轮；若触发时是第二个运营轮，下一股票轮后最后一组包含三个运营轮，期间不插入额外股票轮。\n可选规则:\n· 增加卖空：10 股公司的空头上限改为十股。\n· 轧空：股票轮结束时，投资人合计持股超过 100% 的公司股价右移两格。\n· 现代火车：7 型、8 型火车的路线每经过一枚本公司站标，分别增加 10 或 20 美元。\n本实现采用基础版 v1.0 规则，不包含 Volatility 或其他地图变体。",
			invalid: "此行动不符合当前规则或资金条件。",
			notYourTurn: "请等待轮到你行动。",
			liquidationZone: "清算",
			acquisitionZone: "收购区",
			bank: "银行",
			openMarket: "公开市场",
			mergeOffer: "{{first}} 与 {{second}} 合并，保留 {{survivor}}。合并后为 {{shares}} 股公司，股价为 ${{price}}。",
			mergeFunding: "{{name}} 须以 ${{n}} 购买一股新公司股票。",
			trainOffer: "{{buyer}} 向 {{seller}} 购买一辆 {{train}} 型火车，支付 ${{n}}。",
			initial: "私人公司拍卖",
			auction: "竞价",
			funding: "首次发行出资",
			stock: "股票轮",
			operating: "运营轮",
			merger: "扩股与合并",
			post: "扩股后交易",
			sale: "公司出售",
			purchase: "指定收购公司",
			done: "交易结束",
			layStep: "铺设或升级轨道",
			tokenStep: "放置站标",
			routesStep: "运行火车",
			dividendStep: "决定分红",
			trainStep: "购买火车",
			repayStep: "偿还贷款",
			finishStep: "结束运营",
			crisis: "筹集现金偿债",
			discardStep: "选择超限火车",
			tokensStep: "保留八处站标",
			consent: "等待交易同意",
			cash: "现金",
			wealth: "净资产",
			treasury: "金库",
			market: "市场",
			shares: "持股",
			shorts: "空头",
			loans: "贷款",
			trains: "火车",
			tokens: "站标",
			privates: "私人公司",
			price: "股价",
			revenue: "收入",
			interest: "每笔利息",
			subsidy: "补贴余额",
			phase: "阶段",
			round: "运营轮 {{n}}",
			waiting: "等待 {{name}}",
			yours: "轮到你行动",
			portfolio: "投资组合",
			railways: "铁路公司",
			map: "铁路地图",
			exchange: "证券交易所",
			history: "交易记录",
			close: "关闭",
			back: "返回",
			details: "查看详情",
			noAssets: "尚未持有资产",
			available: "可用",
			selectHex: "选择地图上的目标格。",
			selectCompany: "选择公司以查看交易与资产。",
			amount: "出价（美元）",
			confirm: "确认",
			cancel: "取消",
			face: "面值 ${{n}}",
			certificates: "证书 {{n}} / {{max}}",
			total: "合计",
			source: "来源",
			bidNow: "当前出价 ${{n}}",
			treasuryCount: "金库 {{n}} 股",
			marketCount: "市场 {{n}} 股",
			sharesCount: "{{n}} 股公司",
			tokensCount: "{{n}} 枚站标",
			trainLimit: "火车 {{n}} / {{max}}",
			debt: "待购站标 ${{n}}",
			loanSummary: "{{n}} 笔 / 70",
			noRoute: "暂无合法收益路线",
			sold: "本轮已卖出",
			bankruptPlayer: "已破产",
			president: "总裁",
			city: "城区 {{n}}",
			tile: "板块 {{n}}",
			rotation: "朝向 {{n}}",
			mine: "放置煤矿",
			bridge: "放置桥梁",
			companyFunds: "公司资金 ${{n}}",
			routeTotal: "最高路线收入 ${{n}}",
			finishChoice: "完成选择",
			pass: "跳过",
			endTurn: "结束本次行动",
			nextStep: "完成此步骤",
			bid: "加价至 ${{n}}",
			privateBuy: "以 ${{n}} 发起拍卖",
			ipo: "以 ${{n}} 发起首次发行",
			fund: "出资设立 {{n}} 股公司",
			cashPayment: "支付现金 ${{n}}",
			buyTreasury: "从金库买入一股",
			buyMarket: "从市场买入一股",
			sell: "卖出 {{n}} 股",
			short: "卖空一股",
			finance: "贷款 {{loans}} 笔，回购 {{shares}} 股",
			loan: "取得 {{n}} 笔贷款",
			repay: "偿还 {{n}} 笔贷款",
			lay: "铺设 {{tile}}，支付 ${{n}}",
			placeToken: "放置站标",
			run: "运行最高收入路线",
			full: "全额分红",
			half: "半额分红",
			withhold: "保留全部收入",
			buyTrain: "从 {{seller}} 购买 {{train}} 型，支付 ${{n}}",
			accept: "同意交易",
			decline: "拒绝交易",
			discard: "弃置 {{train}} 型火车",
			convert: "扩充公司股本",
			merge: "与 {{name}} 合并",
			survivor: "保留 {{name}} 公司",
			offer: "自愿出售公司",
			acquire: "由 {{name}} 收购",
			keepTokens: "保留所选八处站标",
			bankrupt: "宣布破产",
			adjustBid: "调整出价",
			adjustIPO: "选择公司与起拍价",
			adjustTrain: "商议购车价格",
			p0: "匹兹堡钢厂",
			p1: "山地工程师",
			p2: "俄亥俄桥梁",
			p3: "联合桥梁",
			p4: "车站",
			p5: "小型煤矿",
			p6: "煤矿",
			p7: "大型煤矿",
			p8: "小型邮政合同",
			p9: "邮政合同",
			p10: "大型邮政合同",
			effect0: "允许在匹兹堡铺设专用黄色城市板块，不要求连通。",
			effect1: "在山地首次铺黄轨后，公司获得 20 美元。",
			effect2: "免河流格铺轨费，并提供一枚桥梁。",
			effect3: "免河流格铺轨费，并提供两枚桥梁。",
			effect4: "公司获得一枚额外站标。",
			effect5: "提供一枚煤矿，放置时免山地铺轨费。",
			effect6: "提供两枚煤矿，放置时免山地铺轨费。",
			effect7: "提供三枚煤矿，放置时免山地铺轨费。",
			effect8: "运营轮开始时有火车，公司获得 10 美元。",
			effect9: "运营轮开始时有火车，公司获得 15 美元。",
			effect10: "运营轮开始时有火车，公司获得 20 美元。",
			optionShorts: "增加卖空",
			optionSqueeze: "轧空",
			optionModern: "现代火车",
			on: "启用",
			off: "关闭",
			logPrivate: "{{name}} 以 ${{n}} 购得 {{detail}}。",
			logIPO: "{{name}} 以 ${{n}} 发行 {{company}}。",
			logBuy: "{{name}} 以 ${{n}} 买入 {{company}} 一股。",
			logSell: "{{name}} 卖出 {{company}} {{n}} 股。",
			logShort: "{{name}} 卖空 {{company}} 一股，收到 ${{n}}。",
			logFinance: "{{company}} 取得 {{n}} 笔贷款，回购 {{detail}} 股。",
			logLoan: "{{company}} 取得 {{n}} 笔贷款。",
			logRepay: "{{company}} 偿还 {{n}} 笔贷款。",
			logLay: "{{company}} 在 {{detail}} 铺轨，支付 ${{n}}。",
			logToken: "{{company}} 在 {{detail}} 放置站标。",
			logBridge: "{{company}} 在 {{detail}} 建造桥梁。",
			logRoutes: "{{company}} 的火车收入为 ${{n}}。",
			logDividend: "{{company}} 分红 ${{n}}。",
			logTrain: "{{company}} 以 ${{n}} 购入 {{detail}} 型火车。",
			logInterest: "{{company}} 支付 ${{n}} 利息。",
			logLiquidate: "{{company}} 进入清算。",
			logMail: "{{company}} 领取 ${{n}} 邮政收入。",
			logStock: "第 {{n}} 个股票轮开始。",
			logOperating: "第 {{n}} 个运营轮开始。",
			logEra: "进入第 {{n}} 阶段。",
			logExport: "银行出口一列 {{detail}} 型火车。",
			logEnding: "将在第 {{n}} 个运营轮后结束游戏。",
			logMerge: "{{company}} 完成合并。",
			logConvert: "{{company}} 扩充为 {{n}} 股公司。",
			logSale: "{{company}} 以 ${{n}} 成交。",
			logBankrupt: "{{name}} 破产退出。",
			logDiscard: "{{company}} 弃置一列 {{detail}} 型火车。",
			finalTitle: "纽约证券交易所 · 最终资产",
			finalCash: "个人现金",
			finalLong: "持股市值",
			finalShort: "空头负债",
			finalTotal: "净资产",
			winner: "{{name}} 获胜",
			tie: "并列获胜：{{name}}",
			reviewMap: "回看铁路网络",
			showResult: "展开资产结算",
			playAgain: "再来一局",
			lobby: "返回大厅",
			waitHost: "等待主机开始新一局。",
			leaveConfirm: "确定离开本局结算吗？",
			hints: "本局使用求助 {{n}} 次",
			autopilot: "托管占比 {{n}}%"
		},
		en: {
			name: "1817",
			desc: "Build railroads and manage shares, shorts, and debt through mergers and liquidations.",
			rules: "Goal:\nYou invest in railroad companies and act as president of companies you control. Personal cash and company treasuries are separate. Final wealth is personal cash plus the market value of shares, minus the market value of shorts. Private companies and company assets do not count. The wealthiest investor wins. If only one investor remains solvent, that investor wins immediately.\nSetup:\n· The base game supports 3–7 investors. Starting cash for 3, 4, 5, 6, and 7 investors is $420, $315, $252, $210, and $180; certificate limits are 21, 16, 13, 11, and 9. A president's certificate represents two shares but counts as one certificate. Privates and shorts do not count toward the certificate limit.\n· The first investor is chosen randomly. Eleven private companies are auctioned with a shared $200 subsidy pool. Privates may subsequently be contributed to an IPO at face value but cannot be resold.\nInitial auction:\nThe active investor nominates a private or passes. The opening bid plus the remaining subsidy must cover its face value. All bids must be multiples of $5, no greater than face value or the bidder's cash. Investors raise or pass in order. Passing withdraws permanently from that auction.\nThe last bidder pays the bid; the subsidy pool pays the difference from face value. Play resumes to the left of the auction initiator. When everyone passes consecutively, unsold privates are removed and a stock round begins.\nStock rounds:\nInvestors act clockwise from the priority deal holder until all solvent investors pass consecutively. Anyone who acts is guaranteed another turn. Priority passes to the left of the last investor who acted.\n· A personal turn permits, in order: selling any number of shares; shorting at most one share; then buying one certificate or initiating an IPO. Any steps may be omitted, but their order is fixed. Buying or completing an IPO ends the turn.\n· Alternatively, act for one company you preside over outside acquisition or liquidation: take loans, then optionally buy back any number of its own market shares. At least one of these actions is required.\n· Purchases cost the current share price and pay the source of the share. Sales and shorts receive the current share price from the bank. Selling does not directly move the price. After selling or shorting a company's stock, you cannot buy it again in that stock round.\n· A 2-share company cannot trade ordinary shares or be shorted. Shares cannot be sold or shorted in the stock round of the company's IPO. Shares in acquisition cannot trade. A president's certificate cannot enter the market. If a sale leaves another investor with at least two shares and a larger holding, the presidency changes. Ties favor the incumbent, otherwise the nearest eligible investor to the outgoing president's left.\n· Personal holding limits are three shares in a 5-share company and six in a 10-share company. Excess certificates must be sold before ending a stock turn whenever legally possible. Buying to close a short is exempt from certificate and share limits.\n· Shorting creates a market share and a personal short, and pays the seller the share price. At most five shorts may exist per company. Matching long and short shares held by one investor cancel immediately. No new shorts may be opened in phase 8; existing shorts remain liable.\nIPOs:\nChoose an unused company and an open city station location other than Toronto. Auction its president's certificate for $100–$400 in multiples of $5. The winner chooses a company size permitted in the current phase and pays the bid exactly using cash and privates at face value. Contributed privates belong to the company; only cash enters its treasury. Initial share price is half the bid rounded down to a market price.\nThe basic station allotment is one, two, or four tokens for 2-, 5-, or 10-share companies. The home token is free. A 5-share company must pay $50, or a 10-share company $150, for the remaining tokens before the stock round ends. A later company turn may take loans to pay this cost. Failure to pay causes liquidation.\nAt the end of a stock round, a 5- or 10-share company with at least 100% held by investors moves right once. Its price then moves left once for every share in the market. Prices stop at $600 to the right and at the leftmost acquisition space to the left.\nLoans and round sequence:\nAfter a stock round, play an operating round, a merger/acquisition round, a second operating round, and a second merger/acquisition round, then another stock round. Each $100 loan moves the share price left once. Repaying $100 moves it right once. A company may hold no more loans than its share size; only 70 loans exist.\nAt the start of each operating round, interest per loan is set to $5 for each group of five outstanding loans, rounded up, with a minimum of $5. It remains fixed throughout that operating round. Companies with trains first receive mail income. Companies operate in descending share price order; ties favor the first company to enter that price space.\nCompany operation:\n· Track: lay or upgrade up to two different hexes, with at most one upgrade. A second tile operation costs an extra $20. Yellow, green, brown, and gray become available in phases 2, 3, 5, and 7. Upgrade one color at a time, preserving track and tokens. Normal cities upgraded to brown must use as many exits as fit.\n· New track must connect to the company's legal network; an untracked home city may receive its first city tile. Track cannot leave the map, cross impassable boundaries, or enter a red or gray hex without a matching connection. Pay terrain costs for the initial lay. Detroit and New York cost an additional $20 to upgrade to green. Mine hexes cannot be upgraded.\n· Station: place at most one available company token in a connected open city location. A company cannot place two tokens in one hex or place a token in Toronto. Placement itself is free.\n· Routes: each route must include a company token and have cities or red offboard locations at both ends. A route cannot repeat a city or track segment; New York's two city groups count as one city. A city filled by other companies may be an endpoint but cannot be traversed. Red locations must be endpoints. The train number limits cities and offboard locations visited. Mines do not count as stops and cannot be endpoints. Different trains cannot share track. The company must use the highest combined legal revenue; the interface supplies optimal routes.\n· Dividends: pay full, pay half, or withhold. Divide the paid portion by the company's share size. Treasury shares pay the company, market shares pay the bank, and shorts pay the same per-share dividend to the bank. A 10-share half dividend rounds the distributed half up to $10 and the retained half down to $10.\n· A zero payout moves left once. A payout at least the share price moves right once; at least twice the price moves right twice. Treat an acquisition share price as $40 for this comparison.\n· Trains: below its train limit, a company may buy from the bank at face value or, with the seller's president's consent, from a company outside liquidation at any agreed price of at least $1. Presidents cannot contribute personal cash. New bank trains sell in order; discarded market trains sell at face value.\n· Interest: after train purchases, pay interest on every loan. Take additional loans if necessary and possible; these loans also accrue interest immediately. If payment remains impossible, liquidate the company, transfer its cash to the president, and require the president to pay the interest. Insufficient personal cash causes a cash crisis.\n· Repayment and completion: after interest, repay any number of loans. Loans cannot be taken between paying interest and completing repayment. After repayment, loans may be taken again. A company with no train at the end of its operation liquidates. Export the next new train at each operating round's end, potentially changing phase.\nTrains and phases:\n· Bank trains are 2/$100, 2+/$100, 3/$250, 4/$400, 5/$600, 6/$750, 7/$900, and 8/$1100. Quantities for 2+, 3, 4, 5, 6, and 7 are 4, 12, 8, 5, 4, and 3. Unlimited 2-trains are available only in the first operating round; all remaining 2-trains are withdrawn after its export. 8-trains are unlimited.\n· Train limits are four in phases 2–3, three in phases 4–5, and two from phase 6 onward. Presidents immediately discard excess trains to the open market.\n· The first 4-train rusts all 2-trains. 2+ trains run once more and are then removed; they cannot be traded while obsolete. The first 6-train rusts all 3-trains; the first 8-train rusts all 4-trains.\n· IPO sizes are: only 2 in phase 2; 2 or 5 in phase 3; only 5 in phase 4; 5 or 10 in phase 5; only 10 from phase 6 onward. Existing companies need not grow.\nPrivate companies:\n· Pittsburgh Steel Mill, $40: permits the special yellow Pittsburgh tile without a connectivity requirement, using one track lay.\n· Mountain Engineers, $40: earn $20 for the company after paying any required cost for an initial yellow lay in mountains.\n· Ohio Bridge and Union Bridge, $40 and $80: waive initial river terrain fees and provide one and two bridge tokens. During company operation, bridges may be placed in Louisville, Cincinnati, or Charleston without connectivity. At most one bridge per city; all routes visiting it earn an extra $10.\n· Train Station, $80: gives the company one extra station token.\n· Minor, regular, and Major Coal Mines, $30, $60, and $90: supply one, two, and three mines. When laying yellow in mountains next to a city or red location, place a mine to waive the mountain cost. Track must connect directly to that location, allowing a future upgrade of the adjacent city. A mine adds $10 to a route and prevents upgrades of its hex.\n· Minor, regular, and Major Mail Contracts, $60, $90, and $120: pay $10, $15, and $20 at the start of each operating round if the company owns a train.\nConversions and mergers:\nIn the operating order fixed at the start of M&A, companies outside acquisition and liquidation may convert or merge at most once. Passing does not prevent accepting a later merger. Both presidents must consent; no rail connection is required.\n· A 2-share company converts to 5 with three new treasury shares and must buy one token for $50. A 5-share company converts to 10 with five new treasury shares and must buy two tokens for $100. Buy only the tokens that fit within eight. Inability to pay causes liquidation.\n· Two 2-share companies merge into a 5-share company, exchanging each pair of old shares for one new share. The new price is the sum of old prices rounded down to a market value. Three shares enter treasury. With different presidents, the initiating president must buy another share to become president; the other president receives one share.\n· Two 5-share companies merge into a 10-share company. Combine long, short, market, and treasury shares one for one. The new price is the old prices' average rounded down. The largest holding determines presidency, with ties favoring the initiating president. Matching long and short shares cancel immediately.\n· After conversion or merger, the original president may buy any number of treasury shares. Each other investor, clockwise from that president's left, then has one opportunity to buy one treasury share, sell any number of shares, or pass. No shorting is allowed. The company may then take loans and must pay conversion token costs.\nAcquisitions and liquidations:\nAfter conversions and mergers, sell liquidations most recently entered first, acquisition companies in reverse operating order, and then allow normal companies to offer friendly sales in reverse operating order. A company newly entering acquisition during conversion or purchase is excluded from acquisition sale and further purchases in this M&A round.\n· Liquidation starts with a $0 bank bid and sells only trains, station tokens, and privates. Acquisition bids start at $10. Friendly sale minimum is share price times company size. A friendly seller's treasury shares are sold to the bank at market value, adding cash to the acquired treasury.\n· Bid clockwise from the target president's left in multiples of $10. The target president, bidding for another company, may increase the previous bid by only $10. Passing is final. The winning investor then names an eligible company that can pay the bid and handle all inherited debt. Target cash and additional loans may finance the purchase; inherited loans may be repaid.\n· A normal acquisition inherits target cash and loans. Each retained inherited loan moves the buyer's price left once. Divide the bid by company size and round down: pay that amount per long share and charge it per short share. Return the target charter for future IPOs.\n· In liquidation, combine target cash and the bid to repay all loans. The president pays any deficit. Only a surplus is distributed per share to longs and charged to shorts. Without a bidder, remove the assets. The bank covers deficits for companies without a solvent president.\n· All tokens transfer in mergers and acquisitions. Return duplicate tokens in one hex to treasury. If the total exceeds eight, the president chooses up to eight distinct occupied hexes first; remaining unused tokens fill the allotment to eight. Discard excess trains immediately.\nCash crises and ending:\nWhen personal cash cannot cover short dividends, liquidation debt, or company interest, sell legally available shares one at a time without changing any presidency. If no legal sale remains and the debt is unpaid, the investor goes bankrupt. Transfer shares, shorts, and privates to the market and liquidate companies they preside over. The bank cancels matching longs and shorts immediately, and buys treasury shares at the start of each stock round to close remaining bank shorts.\nAfter the first 8-train is bought or exported, complete three more operating rounds and intervening M&A rounds. If triggered in the first operating round of a set, finish that set, play a stock round, then a final two operating rounds. If triggered in the second, play a stock round and then a final set of three operating rounds without an extra stock round inside it.\nVariants:\n· Increased shorts: allow ten shorts in a 10-share company.\n· Short squeeze: at stock round end, more than 100% held by investors moves the price right twice.\n· Modern trains: a 7- or 8-train earns an additional $10 or $20 per company station token on its route.\nThis implementation uses base v1.0 rules and excludes Volatility and other map variants.",
			invalid: "This action does not meet the current rules or funding requirements.",
			notYourTurn: "Please wait for your turn.",
			liquidationZone: "Liquidation",
			acquisitionZone: "Acquisition",
			bank: "the bank",
			openMarket: "the open market",
			mergeOffer: "{{first}} and {{second}} will merge, retaining {{survivor}}. The result is a {{shares}}-share company with a share price of ${{price}}.",
			mergeFunding: "{{name}} must buy one new company share for ${{n}}.",
			trainOffer: "{{buyer}} will buy one {{train}}-train from {{seller}} for ${{n}}.",
			initial: "Private auction",
			auction: "Bidding",
			funding: "Fund the IPO",
			stock: "Stock round",
			operating: "Operating round",
			merger: "Conversions & mergers",
			post: "Post-conversion trading",
			sale: "Company sales",
			purchase: "Choose buyer",
			done: "Trading closed",
			layStep: "Lay or upgrade track",
			tokenStep: "Place a station",
			routesStep: "Run trains",
			dividendStep: "Choose dividend",
			trainStep: "Buy trains",
			repayStep: "Repay loans",
			finishStep: "Complete operation",
			crisis: "Raise cash for debt",
			discardStep: "Discard excess trains",
			tokensStep: "Keep eight stations",
			consent: "Transaction consent",
			cash: "Cash",
			wealth: "Net worth",
			treasury: "Treasury",
			market: "Market",
			shares: "Shares",
			shorts: "Shorts",
			loans: "Loans",
			trains: "Trains",
			tokens: "Stations",
			privates: "Private companies",
			price: "Share price",
			revenue: "Revenue",
			interest: "Interest per loan",
			subsidy: "Subsidy left",
			phase: "Phase",
			round: "OR {{n}}",
			waiting: "Waiting for {{name}}",
			yours: "Your turn",
			portfolio: "Portfolio",
			railways: "Railroads",
			map: "Rail network",
			exchange: "Stock exchange",
			history: "Transactions",
			close: "Close",
			back: "Back",
			details: "View details",
			noAssets: "No assets yet",
			available: "Available",
			selectHex: "Select a destination hex on the map.",
			selectCompany: "Select a company to inspect its assets and trades.",
			amount: "Bid (dollars)",
			confirm: "Confirm",
			cancel: "Cancel",
			face: "Face value ${{n}}",
			certificates: "Certificates {{n}} / {{max}}",
			total: "Total",
			source: "Source",
			bidNow: "Current bid ${{n}}",
			treasuryCount: "{{n}} treasury shares",
			marketCount: "{{n}} market shares",
			sharesCount: "{{n}}-share company",
			tokensCount: "{{n}} station tokens",
			trainLimit: "Trains {{n}} / {{max}}",
			debt: "Stations owed ${{n}}",
			loanSummary: "{{n}} of 70 loans",
			noRoute: "No revenue route yet",
			sold: "Sold this round",
			bankruptPlayer: "Bankrupt",
			president: "President",
			city: "City group {{n}}",
			tile: "Tile {{n}}",
			rotation: "Orientation {{n}}",
			mine: "Place a coal mine",
			bridge: "Place a bridge",
			companyFunds: "Company cash ${{n}}",
			routeTotal: "Maximum route revenue ${{n}}",
			finishChoice: "Complete selection",
			pass: "Pass",
			endTurn: "End turn",
			nextStep: "Complete step",
			bid: "Bid ${{n}}",
			privateBuy: "Open bidding at ${{n}}",
			ipo: "Open IPO at ${{n}}",
			fund: "Fund a {{n}}-share company",
			cashPayment: "Pay ${{n}} cash",
			buyTreasury: "Buy one treasury share",
			buyMarket: "Buy one market share",
			sell: "Sell {{n}} shares",
			short: "Short one share",
			finance: "Take {{loans}} loans, buy back {{shares}} shares",
			loan: "Take {{n}} loans",
			repay: "Repay {{n}} loans",
			lay: "Lay {{tile}} for ${{n}}",
			placeToken: "Place station",
			run: "Run maximum revenue routes",
			full: "Pay full",
			half: "Pay half",
			withhold: "Withhold",
			buyTrain: "Buy {{train}}-train from {{seller}} for ${{n}}",
			accept: "Accept transaction",
			decline: "Decline transaction",
			discard: "Discard {{train}}-train",
			convert: "Convert company",
			merge: "Merge with {{name}}",
			survivor: "Keep {{name}} charter",
			offer: "Offer friendly sale",
			acquire: "Acquire with {{name}}",
			keepTokens: "Keep eight selected stations",
			bankrupt: "Declare bankruptcy",
			adjustBid: "Adjust bid",
			adjustIPO: "Choose charter and opening bid",
			adjustTrain: "Negotiate train price",
			p0: "Pittsburgh Steel Mill",
			p1: "Mountain Engineers",
			p2: "Ohio Bridge Co.",
			p3: "Union Bridge Co.",
			p4: "Train Station",
			p5: "Minor Coal Mine",
			p6: "Coal Mine",
			p7: "Major Coal Mine",
			p8: "Minor Mail Contract",
			p9: "Mail Contract",
			p10: "Major Mail Contract",
			effect0: "Lay the special yellow Pittsburgh tile without connectivity.",
			effect1: "Earn $20 after an initial yellow mountain lay.",
			effect2: "Waive river terrain costs and provide one bridge.",
			effect3: "Waive river terrain costs and provide two bridges.",
			effect4: "Provide one additional station token.",
			effect5: "Provide one mine, waiving its mountain terrain cost.",
			effect6: "Provide two mines, waiving their mountain terrain costs.",
			effect7: "Provide three mines, waiving their mountain terrain costs.",
			effect8: "Earn $10 at OR start if the company has a train.",
			effect9: "Earn $15 at OR start if the company has a train.",
			effect10: "Earn $20 at OR start if the company has a train.",
			optionShorts: "Increased shorts",
			optionSqueeze: "Short squeeze",
			optionModern: "Modern trains",
			on: "On",
			off: "Off",
			logPrivate: "{{name}} bought {{detail}} for ${{n}}.",
			logIPO: "{{name}} floated {{company}} for ${{n}}.",
			logBuy: "{{name}} bought a {{company}} share for ${{n}}.",
			logSell: "{{name}} sold {{n}} {{company}} shares.",
			logShort: "{{name}} shorted {{company}} and received ${{n}}.",
			logFinance: "{{company}} took {{n}} loans and bought back {{detail}} shares.",
			logLoan: "{{company}} took {{n}} loans.",
			logRepay: "{{company}} repaid {{n}} loans.",
			logLay: "{{company}} laid {{detail}} for ${{n}}.",
			logToken: "{{company}} placed a station at {{detail}}.",
			logBridge: "{{company}} placed a bridge at {{detail}}.",
			logRoutes: "{{company}} earned ${{n}} from trains.",
			logDividend: "{{company}} distributed ${{n}} in dividends.",
			logTrain: "{{company}} bought a {{detail}}-train for ${{n}}.",
			logInterest: "{{company}} paid ${{n}} interest.",
			logLiquidate: "{{company}} entered liquidation.",
			logMail: "{{company}} received ${{n}} mail income.",
			logStock: "Stock round {{n}} began.",
			logOperating: "Operating round {{n}} began.",
			logEra: "Phase {{n}} began.",
			logExport: "The bank exported a {{detail}}-train.",
			logEnding: "The game will end after operating round {{n}}.",
			logMerge: "{{company}} completed a merger.",
			logConvert: "{{company}} converted to {{n}} shares.",
			logSale: "{{company}} sold for ${{n}}.",
			logBankrupt: "{{name}} went bankrupt.",
			logDiscard: "{{company}} discarded a {{detail}}-train.",
			finalTitle: "New York Stock Exchange · Final accounts",
			finalCash: "Personal cash",
			finalLong: "Long positions",
			finalShort: "Short liabilities",
			finalTotal: "Net worth",
			winner: "{{name}} wins",
			tie: "Joint winners: {{name}}",
			reviewMap: "Review rail network",
			showResult: "Show final accounts",
			playAgain: "Play again",
			lobby: "Back to lobby",
			waitHost: "Waiting for the host to start another game.",
			leaveConfirm: "Leave these final accounts?",
			hints: "{{n}} hints used",
			autopilot: "{{n}}% on autopilot"
		}
	}
};
//#endregion
export { Kt as default };
