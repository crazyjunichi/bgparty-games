import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as f } from "@bgparty/sdk/avatars";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { IconClose as g, IconExpand as _, IconRecenter as v, IconZoomIn as y, IconZoomOut as b } from "@bgparty/sdk/icons";
import { Floater as x, FlySprite as S, PulseBox as C } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as w } from "@bgparty/sdk/confirm-button";
import { OptionRadio as T, OptionSection as E, OptionSwitch as D } from "@bgparty/sdk/ui/game-options";
//#region src/games/seagrass/meta.ts
var O = {
	id: "seagrass",
	tier: "alpha",
	nameKey: "games.seagrass.name",
	descKey: "games.seagrass.desc",
	rulesKey: "games.seagrass.rules",
	icon: "🪸",
	iconImg: "games/seagrass.webp",
	minPlayers: 2,
	maxPlayers: 4,
	accent: "#00a8a7",
	releasedAt: "2026-11-06T18:33:17+08:00",
	mechanics: [
		"tile-placement",
		"area-control",
		"hand-management",
		"set-collection"
	],
	interactionTags: [],
	search: {
		py: "hai cao",
		init: "hc"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/17109138799597378568/C5A1E548E23143885C4BF9BDEA0185232C6C0D2E/" }
}, k = t.enum([
	"jellyfish",
	"starfish",
	"crab",
	"turtle"
]), A = t.object({
	board: t.enum(["front", "back"]).default("front"),
	regionStart: t.int().min(0).max(3).default(0),
	special: t.boolean().default(!0),
	discovery: t.boolean().default(!1)
}).prefault({}), j = t.object({
	tile: t.int().min(0).max(127),
	cell: t.int().min(0).max(200)
}), M = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("colony"),
		placements: t.array(j).min(1).max(8)
	}),
	t.object({
		type: t.literal("reef"),
		tile: t.int().min(0).max(127),
		cell: t.int().min(0).max(200)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), N = t.object({
	cell: t.int(),
	owner: t.int(),
	tile: t.int(),
	faceUp: t.boolean(),
	reef: t.int().nullable()
}), P = t.object({
	root: t.int(),
	cells: t.array(t.int()),
	explored: t.boolean(),
	scored: t.boolean(),
	tokens: t.array(k)
}), F = t.object({
	colony: t.int(),
	reef: t.int(),
	discovery: t.int(),
	leftover: t.int()
}), I = t.object({
	config: A,
	regions: t.array(t.int()),
	pieces: t.array(N),
	reefs: t.array(P),
	turn: t.int(),
	move: t.int(),
	phase: t.enum([
		"play",
		"bonus",
		"resolve",
		"done"
	]),
	antlers: t.int(),
	players: t.array(t.object({
		rid: t.string(),
		handCount: t.int(),
		deckCount: t.int(),
		specials: t.array(k),
		tokens: t.array(t.int()).length(4),
		score: t.int().nullable(),
		breakdown: F.nullable(),
		unplayed: t.int()
	})),
	queue: t.array(t.int()),
	last: t.object({
		cells: t.array(t.int()),
		kind: t.enum([
			"colony",
			"reef",
			"score"
		]),
		points: t.int(),
		player: t.int()
	}).nullable()
}), L = t.object({
	hand: t.array(t.int()),
	specials: t.array(t.int()),
	score: t.int(),
	breakdown: F
}), R = {
	front: [
		{
			id: 0,
			x: 94.5,
			y: 475.5,
			region: 2,
			type: "empty"
		},
		{
			id: 1,
			x: 94.5,
			y: 540.05,
			region: 2,
			type: "empty"
		},
		{
			id: 2,
			x: 94.5,
			y: 604.6,
			region: 2,
			type: "empty"
		},
		{
			id: 3,
			x: 94.5,
			y: 669.15,
			region: 2,
			type: "empty"
		},
		{
			id: 4,
			x: 150.47,
			y: 378.67499999999995,
			region: -1,
			type: "rock"
		},
		{
			id: 5,
			x: 150.47,
			y: 443.22499999999997,
			region: 2,
			type: "empty"
		},
		{
			id: 6,
			x: 150.47,
			y: 507.775,
			region: 2,
			type: "empty"
		},
		{
			id: 7,
			x: 150.47,
			y: 572.3249999999999,
			region: 2,
			type: "reef"
		},
		{
			id: 8,
			x: 150.47,
			y: 636.875,
			region: 2,
			type: "empty"
		},
		{
			id: 9,
			x: 150.47,
			y: 701.425,
			region: 2,
			type: "empty"
		},
		{
			id: 10,
			x: 150.47,
			y: 765.975,
			region: -1,
			type: "rock"
		},
		{
			id: 11,
			x: 150.47,
			y: 830.525,
			region: 2,
			type: "empty"
		},
		{
			id: 12,
			x: 206.44,
			y: 217.3,
			region: 0,
			type: "empty"
		},
		{
			id: 13,
			x: 206.44,
			y: 281.85,
			region: 0,
			type: "empty"
		},
		{
			id: 14,
			x: 206.44,
			y: 346.4,
			region: 0,
			type: "empty"
		},
		{
			id: 15,
			x: 206.44,
			y: 410.95,
			region: -1,
			type: "rock"
		},
		{
			id: 16,
			x: 206.44,
			y: 475.5,
			region: 2,
			type: "empty"
		},
		{
			id: 17,
			x: 206.44,
			y: 540.05,
			region: 2,
			type: "empty"
		},
		{
			id: 18,
			x: 206.44,
			y: 604.6,
			region: 2,
			type: "empty"
		},
		{
			id: 19,
			x: 206.44,
			y: 669.15,
			region: 2,
			type: "empty"
		},
		{
			id: 20,
			x: 206.44,
			y: 733.7,
			region: -1,
			type: "rock"
		},
		{
			id: 21,
			x: 206.44,
			y: 798.25,
			region: 2,
			type: "empty"
		},
		{
			id: 22,
			x: 206.44,
			y: 862.8,
			region: 2,
			type: "empty"
		},
		{
			id: 23,
			x: 262.40999999999997,
			y: 185.025,
			region: 0,
			type: "empty"
		},
		{
			id: 24,
			x: 262.40999999999997,
			y: 249.57500000000002,
			region: 0,
			type: "reef"
		},
		{
			id: 25,
			x: 262.40999999999997,
			y: 314.125,
			region: 0,
			type: "empty"
		},
		{
			id: 26,
			x: 262.40999999999997,
			y: 378.67499999999995,
			region: 0,
			type: "empty"
		},
		{
			id: 27,
			x: 262.40999999999997,
			y: 443.22499999999997,
			region: 0,
			type: "empty"
		},
		{
			id: 28,
			x: 262.40999999999997,
			y: 507.775,
			region: 2,
			type: "empty"
		},
		{
			id: 29,
			x: 262.40999999999997,
			y: 572.3249999999999,
			region: 2,
			type: "empty"
		},
		{
			id: 30,
			x: 262.40999999999997,
			y: 636.875,
			region: 2,
			type: "empty"
		},
		{
			id: 31,
			x: 262.40999999999997,
			y: 701.425,
			region: 2,
			type: "reef"
		},
		{
			id: 32,
			x: 262.40999999999997,
			y: 765.975,
			region: 2,
			type: "empty"
		},
		{
			id: 33,
			x: 262.40999999999997,
			y: 830.525,
			region: 2,
			type: "empty"
		},
		{
			id: 34,
			x: 262.40999999999997,
			y: 895.0749999999999,
			region: 2,
			type: "empty"
		},
		{
			id: 35,
			x: 318.38,
			y: 217.3,
			region: 0,
			type: "empty"
		},
		{
			id: 36,
			x: 318.38,
			y: 281.85,
			region: 0,
			type: "empty"
		},
		{
			id: 37,
			x: 318.38,
			y: 346.4,
			region: 0,
			type: "empty"
		},
		{
			id: 38,
			x: 318.38,
			y: 410.95,
			region: 0,
			type: "empty"
		},
		{
			id: 39,
			x: 318.38,
			y: 475.5,
			region: 0,
			type: "empty"
		},
		{
			id: 40,
			x: 318.38,
			y: 540.05,
			region: 2,
			type: "empty"
		},
		{
			id: 41,
			x: 318.38,
			y: 604.6,
			region: 2,
			type: "empty"
		},
		{
			id: 42,
			x: 318.38,
			y: 669.15,
			region: -1,
			type: "rock"
		},
		{
			id: 43,
			x: 318.38,
			y: 733.7,
			region: 2,
			type: "empty"
		},
		{
			id: 44,
			x: 318.38,
			y: 798.25,
			region: 2,
			type: "empty"
		},
		{
			id: 45,
			x: 318.38,
			y: 862.8,
			region: 2,
			type: "reef"
		},
		{
			id: 46,
			x: 318.38,
			y: 927.3499999999999,
			region: 2,
			type: "empty"
		},
		{
			id: 47,
			x: 374.35,
			y: 185.025,
			region: 0,
			type: "empty"
		},
		{
			id: 48,
			x: 374.35,
			y: 249.57500000000002,
			region: 0,
			type: "empty"
		},
		{
			id: 49,
			x: 374.35,
			y: 314.125,
			region: -1,
			type: "rock"
		},
		{
			id: 50,
			x: 374.35,
			y: 378.67499999999995,
			region: 0,
			type: "empty"
		},
		{
			id: 51,
			x: 374.35,
			y: 443.22499999999997,
			region: 0,
			type: "reef"
		},
		{
			id: 52,
			x: 374.35,
			y: 507.775,
			region: 0,
			type: "empty"
		},
		{
			id: 53,
			x: 374.35,
			y: 572.3249999999999,
			region: 2,
			type: "empty"
		},
		{
			id: 54,
			x: 374.35,
			y: 636.875,
			region: -1,
			type: "rock"
		},
		{
			id: 55,
			x: 374.35,
			y: 701.425,
			region: 2,
			type: "empty"
		},
		{
			id: 56,
			x: 374.35,
			y: 765.975,
			region: 2,
			type: "empty"
		},
		{
			id: 57,
			x: 374.35,
			y: 830.525,
			region: 2,
			type: "empty"
		},
		{
			id: 58,
			x: 374.35,
			y: 895.0749999999999,
			region: 2,
			type: "empty"
		},
		{
			id: 59,
			x: 430.32,
			y: 152.75,
			region: 0,
			type: "empty"
		},
		{
			id: 60,
			x: 430.32,
			y: 217.3,
			region: 0,
			type: "empty"
		},
		{
			id: 61,
			x: 430.32,
			y: 281.85,
			region: 0,
			type: "empty"
		},
		{
			id: 62,
			x: 430.32,
			y: 346.4,
			region: -1,
			type: "rock"
		},
		{
			id: 63,
			x: 430.32,
			y: 410.95,
			region: 0,
			type: "empty"
		},
		{
			id: 64,
			x: 430.32,
			y: 475.5,
			region: 0,
			type: "empty"
		},
		{
			id: 65,
			x: 430.32,
			y: 540.05,
			region: 0,
			type: "empty"
		},
		{
			id: 66,
			x: 430.32,
			y: 604.6,
			region: 3,
			type: "empty"
		},
		{
			id: 67,
			x: 430.32,
			y: 669.15,
			region: 3,
			type: "empty"
		},
		{
			id: 68,
			x: 430.32,
			y: 733.7,
			region: -1,
			type: "rock"
		},
		{
			id: 69,
			x: 430.32,
			y: 798.25,
			region: -1,
			type: "rock"
		},
		{
			id: 70,
			x: 430.32,
			y: 862.8,
			region: 2,
			type: "empty"
		},
		{
			id: 71,
			x: 486.28999999999996,
			y: 185.025,
			region: 0,
			type: "empty"
		},
		{
			id: 72,
			x: 486.28999999999996,
			y: 249.57500000000002,
			region: 0,
			type: "reef"
		},
		{
			id: 73,
			x: 486.28999999999996,
			y: 314.125,
			region: 0,
			type: "empty"
		},
		{
			id: 74,
			x: 486.28999999999996,
			y: 378.67499999999995,
			region: 0,
			type: "empty"
		},
		{
			id: 75,
			x: 486.28999999999996,
			y: 443.22499999999997,
			region: 0,
			type: "empty"
		},
		{
			id: 76,
			x: 486.28999999999996,
			y: 507.775,
			region: 0,
			type: "empty"
		},
		{
			id: 77,
			x: 486.28999999999996,
			y: 572.3249999999999,
			region: 3,
			type: "empty"
		},
		{
			id: 78,
			x: 486.28999999999996,
			y: 636.875,
			region: 3,
			type: "empty"
		},
		{
			id: 79,
			x: 486.28999999999996,
			y: 701.425,
			region: 3,
			type: "empty"
		},
		{
			id: 80,
			x: 486.28999999999996,
			y: 765.975,
			region: 3,
			type: "empty"
		},
		{
			id: 81,
			x: 486.28999999999996,
			y: 830.525,
			region: 3,
			type: "empty"
		},
		{
			id: 82,
			x: 542.26,
			y: 217.3,
			region: 0,
			type: "empty"
		},
		{
			id: 83,
			x: 542.26,
			y: 281.85,
			region: 0,
			type: "empty"
		},
		{
			id: 84,
			x: 542.26,
			y: 346.4,
			region: 0,
			type: "empty"
		},
		{
			id: 85,
			x: 542.26,
			y: 410.95,
			region: 0,
			type: "empty"
		},
		{
			id: 86,
			x: 542.26,
			y: 475.5,
			region: -1,
			type: "rock"
		},
		{
			id: 87,
			x: 542.26,
			y: 540.05,
			region: 3,
			type: "empty"
		},
		{
			id: 88,
			x: 542.26,
			y: 604.6,
			region: 3,
			type: "empty"
		},
		{
			id: 89,
			x: 542.26,
			y: 669.15,
			region: 3,
			type: "empty"
		},
		{
			id: 90,
			x: 542.26,
			y: 733.7,
			region: 3,
			type: "empty"
		},
		{
			id: 91,
			x: 542.26,
			y: 798.25,
			region: 3,
			type: "reef"
		},
		{
			id: 92,
			x: 542.26,
			y: 862.8,
			region: 3,
			type: "empty"
		},
		{
			id: 93,
			x: 598.23,
			y: 185.025,
			region: -1,
			type: "rock"
		},
		{
			id: 94,
			x: 598.23,
			y: 249.57500000000002,
			region: -1,
			type: "rock"
		},
		{
			id: 95,
			x: 598.23,
			y: 314.125,
			region: 1,
			type: "empty"
		},
		{
			id: 96,
			x: 598.23,
			y: 378.67499999999995,
			region: 1,
			type: "empty"
		},
		{
			id: 97,
			x: 598.23,
			y: 443.22499999999997,
			region: -1,
			type: "rock"
		},
		{
			id: 98,
			x: 598.23,
			y: 507.775,
			region: 3,
			type: "empty"
		},
		{
			id: 99,
			x: 598.23,
			y: 572.3249999999999,
			region: 3,
			type: "reef"
		},
		{
			id: 100,
			x: 598.23,
			y: 636.875,
			region: -1,
			type: "rock"
		},
		{
			id: 101,
			x: 598.23,
			y: 701.425,
			region: 3,
			type: "empty"
		},
		{
			id: 102,
			x: 598.23,
			y: 765.975,
			region: 3,
			type: "empty"
		},
		{
			id: 103,
			x: 654.2,
			y: 152.75,
			region: 1,
			type: "empty"
		},
		{
			id: 104,
			x: 654.2,
			y: 217.3,
			region: 1,
			type: "empty"
		},
		{
			id: 105,
			x: 654.2,
			y: 281.85,
			region: 1,
			type: "empty"
		},
		{
			id: 106,
			x: 654.2,
			y: 346.4,
			region: 1,
			type: "empty"
		},
		{
			id: 107,
			x: 654.2,
			y: 410.95,
			region: 1,
			type: "empty"
		},
		{
			id: 108,
			x: 654.2,
			y: 475.5,
			region: 3,
			type: "empty"
		},
		{
			id: 109,
			x: 654.2,
			y: 540.05,
			region: 3,
			type: "empty"
		},
		{
			id: 110,
			x: 654.2,
			y: 604.6,
			region: 3,
			type: "empty"
		},
		{
			id: 111,
			x: 654.2,
			y: 669.15,
			region: -1,
			type: "rock"
		},
		{
			id: 112,
			x: 710.17,
			y: 120.47500000000005,
			region: 1,
			type: "empty"
		},
		{
			id: 113,
			x: 710.17,
			y: 185.025,
			region: 1,
			type: "empty"
		},
		{
			id: 114,
			x: 710.17,
			y: 249.57500000000002,
			region: 1,
			type: "empty"
		},
		{
			id: 115,
			x: 710.17,
			y: 314.125,
			region: 1,
			type: "empty"
		},
		{
			id: 116,
			x: 710.17,
			y: 378.67499999999995,
			region: 1,
			type: "reef"
		},
		{
			id: 117,
			x: 710.17,
			y: 443.22499999999997,
			region: 1,
			type: "empty"
		},
		{
			id: 118,
			x: 710.17,
			y: 507.775,
			region: 3,
			type: "empty"
		},
		{
			id: 119,
			x: 710.17,
			y: 572.3249999999999,
			region: 3,
			type: "empty"
		},
		{
			id: 120,
			x: 710.17,
			y: 636.875,
			region: 3,
			type: "empty"
		},
		{
			id: 121,
			x: 710.17,
			y: 701.425,
			region: 3,
			type: "empty"
		},
		{
			id: 122,
			x: 766.14,
			y: 152.75,
			region: 1,
			type: "empty"
		},
		{
			id: 123,
			x: 766.14,
			y: 217.3,
			region: 1,
			type: "empty"
		},
		{
			id: 124,
			x: 766.14,
			y: 281.85,
			region: -1,
			type: "rock"
		},
		{
			id: 125,
			x: 766.14,
			y: 346.4,
			region: 1,
			type: "empty"
		},
		{
			id: 126,
			x: 766.14,
			y: 410.95,
			region: 1,
			type: "empty"
		},
		{
			id: 127,
			x: 766.14,
			y: 475.5,
			region: 1,
			type: "empty"
		},
		{
			id: 128,
			x: 766.14,
			y: 540.05,
			region: 3,
			type: "empty"
		},
		{
			id: 129,
			x: 766.14,
			y: 604.6,
			region: 3,
			type: "empty"
		},
		{
			id: 130,
			x: 766.14,
			y: 669.15,
			region: 3,
			type: "empty"
		},
		{
			id: 131,
			x: 766.14,
			y: 733.7,
			region: 3,
			type: "empty"
		},
		{
			id: 132,
			x: 822.11,
			y: 120.47500000000005,
			region: 1,
			type: "empty"
		},
		{
			id: 133,
			x: 822.11,
			y: 185.025,
			region: 1,
			type: "reef"
		},
		{
			id: 134,
			x: 822.11,
			y: 249.57500000000002,
			region: -1,
			type: "rock"
		},
		{
			id: 135,
			x: 822.11,
			y: 314.125,
			region: 1,
			type: "empty"
		},
		{
			id: 136,
			x: 822.11,
			y: 378.67499999999995,
			region: 1,
			type: "empty"
		},
		{
			id: 137,
			x: 822.11,
			y: 443.22499999999997,
			region: 1,
			type: "empty"
		},
		{
			id: 138,
			x: 822.11,
			y: 507.775,
			region: -1,
			type: "rock"
		},
		{
			id: 139,
			x: 822.11,
			y: 572.3249999999999,
			region: 3,
			type: "empty"
		},
		{
			id: 140,
			x: 822.11,
			y: 636.875,
			region: 3,
			type: "reef"
		},
		{
			id: 141,
			x: 822.11,
			y: 701.425,
			region: 3,
			type: "empty"
		},
		{
			id: 142,
			x: 878.0799999999999,
			y: 152.75,
			region: 1,
			type: "empty"
		},
		{
			id: 143,
			x: 878.0799999999999,
			y: 217.3,
			region: 1,
			type: "empty"
		},
		{
			id: 144,
			x: 878.0799999999999,
			y: 281.85,
			region: 1,
			type: "empty"
		},
		{
			id: 145,
			x: 878.0799999999999,
			y: 346.4,
			region: 1,
			type: "empty"
		},
		{
			id: 146,
			x: 878.0799999999999,
			y: 410.95,
			region: 1,
			type: "reef"
		},
		{
			id: 147,
			x: 878.0799999999999,
			y: 475.5,
			region: 1,
			type: "empty"
		},
		{
			id: 148,
			x: 878.0799999999999,
			y: 540.05,
			region: -1,
			type: "rock"
		},
		{
			id: 149,
			x: 878.0799999999999,
			y: 604.6,
			region: 3,
			type: "empty"
		},
		{
			id: 150,
			x: 878.0799999999999,
			y: 669.15,
			region: 3,
			type: "empty"
		},
		{
			id: 151,
			x: 934.05,
			y: 185.025,
			region: 1,
			type: "empty"
		},
		{
			id: 152,
			x: 934.05,
			y: 249.57500000000002,
			region: 1,
			type: "empty"
		},
		{
			id: 153,
			x: 934.05,
			y: 314.125,
			region: 1,
			type: "empty"
		},
		{
			id: 154,
			x: 934.05,
			y: 378.67499999999995,
			region: 1,
			type: "empty"
		},
		{
			id: 155,
			x: 934.05,
			y: 443.22499999999997,
			region: 1,
			type: "empty"
		}
	],
	back: [
		{
			id: 0,
			x: 115,
			y: 248.2,
			region: 0,
			type: "empty"
		},
		{
			id: 1,
			x: 115.6,
			y: 310.5,
			region: 0,
			type: "empty"
		},
		{
			id: 2,
			x: 115,
			y: 373.5,
			region: 0,
			type: "empty"
		},
		{
			id: 3,
			x: 168.9,
			y: 215.7,
			region: 0,
			type: "empty"
		},
		{
			id: 4,
			x: 169.5,
			y: 278,
			region: 0,
			type: "reef"
		},
		{
			id: 5,
			x: 169.5,
			y: 341.3,
			region: 0,
			type: "empty"
		},
		{
			id: 6,
			x: 169.4,
			y: 404.2,
			region: 0,
			type: "empty"
		},
		{
			id: 7,
			x: 168.8,
			y: 466.9,
			region: 0,
			type: "empty"
		},
		{
			id: 8,
			x: 223.4,
			y: 183.8,
			region: 0,
			type: "empty"
		},
		{
			id: 9,
			x: 223.4,
			y: 246.9,
			region: 0,
			type: "empty"
		},
		{
			id: 10,
			x: 223.4,
			y: 309.2,
			region: 0,
			type: "empty"
		},
		{
			id: 11,
			x: 223.4,
			y: 373,
			region: 0,
			type: "empty"
		},
		{
			id: 12,
			x: 223.4,
			y: 435.3,
			region: 0,
			type: "empty"
		},
		{
			id: 13,
			x: 223.4,
			y: 497.2,
			region: 0,
			type: "empty"
		},
		{
			id: 14,
			x: 223.4,
			y: 559.5,
			region: 2,
			type: "empty"
		},
		{
			id: 15,
			x: 223.4,
			y: 622.7,
			region: 2,
			type: "empty"
		},
		{
			id: 16,
			x: 223.4,
			y: 685.4,
			region: 2,
			type: "empty"
		},
		{
			id: 17,
			x: 223.4,
			y: 748.3,
			region: 2,
			type: "empty"
		},
		{
			id: 18,
			x: 278.1,
			y: 779.1,
			region: 2,
			type: "empty"
		},
		{
			id: 19,
			x: 278.1,
			y: 716.2,
			region: 2,
			type: "empty"
		},
		{
			id: 20,
			x: 278.1,
			y: 653.5,
			region: 2,
			type: "empty"
		},
		{
			id: 21,
			x: 278.1,
			y: 590.3,
			region: 2,
			type: "empty"
		},
		{
			id: 22,
			x: 278.1,
			y: 528,
			region: 2,
			type: "empty"
		},
		{
			id: 23,
			x: 278.1,
			y: 466.1,
			region: 0,
			type: "empty"
		},
		{
			id: 24,
			x: 278.1,
			y: 403.8,
			region: 0,
			type: "reef"
		},
		{
			id: 25,
			x: 278.1,
			y: 340,
			region: 0,
			type: "empty"
		},
		{
			id: 26,
			x: 278.1,
			y: 277.7,
			region: 0,
			type: "empty"
		},
		{
			id: 27,
			x: 278.1,
			y: 214.7,
			region: 0,
			type: "empty"
		},
		{
			id: 28,
			x: 278.1,
			y: 152.3,
			region: 0,
			type: "empty"
		},
		{
			id: 29,
			x: 332.7,
			y: 121.8,
			region: 0,
			type: "empty"
		},
		{
			id: 30,
			x: 332.7,
			y: 183.7,
			region: 0,
			type: "empty"
		},
		{
			id: 31,
			x: 332.7,
			y: 309.1,
			region: 0,
			type: "empty"
		},
		{
			id: 32,
			x: 332.7,
			y: 246.1,
			region: 0,
			type: "empty"
		},
		{
			id: 33,
			x: 332.7,
			y: 371.4,
			region: 0,
			type: "empty"
		},
		{
			id: 34,
			x: 332.7,
			y: 435.2,
			region: 0,
			type: "empty"
		},
		{
			id: 35,
			x: 332.7,
			y: 497.5,
			region: 2,
			type: "empty"
		},
		{
			id: 36,
			x: 332.7,
			y: 559.4,
			region: 2,
			type: "reef"
		},
		{
			id: 37,
			x: 332.7,
			y: 621.7,
			region: 2,
			type: "empty"
		},
		{
			id: 38,
			x: 332.7,
			y: 684.9,
			region: 2,
			type: "empty"
		},
		{
			id: 39,
			x: 332.7,
			y: 747.6,
			region: 2,
			type: "reef"
		},
		{
			id: 40,
			x: 332.7,
			y: 810.5,
			region: 2,
			type: "empty"
		},
		{
			id: 41,
			x: 387.6,
			y: 842.7,
			region: 2,
			type: "empty"
		},
		{
			id: 42,
			x: 387.6,
			y: 779.8,
			region: 2,
			type: "empty"
		},
		{
			id: 43,
			x: 387.6,
			y: 717.1,
			region: 2,
			type: "empty"
		},
		{
			id: 44,
			x: 387.6,
			y: 653.9,
			region: 2,
			type: "empty"
		},
		{
			id: 45,
			x: 387.6,
			y: 591.6,
			region: 2,
			type: "empty"
		},
		{
			id: 46,
			x: 387.6,
			y: 529.7,
			region: 2,
			type: "empty"
		},
		{
			id: 47,
			x: 387.6,
			y: 467.4,
			region: 2,
			type: "empty"
		},
		{
			id: 48,
			x: 387.6,
			y: 403.6,
			region: 1,
			type: "empty"
		},
		{
			id: 49,
			x: 387.6,
			y: 341.3,
			region: 1,
			type: "empty"
		},
		{
			id: 50,
			x: 387.6,
			y: 278.3,
			region: 0,
			type: "empty"
		},
		{
			id: 51,
			x: 387.6,
			y: 215.9,
			region: 0,
			type: "reef"
		},
		{
			id: 52,
			x: 387.6,
			y: 154,
			region: 0,
			type: "empty"
		},
		{
			id: 53,
			x: 442.2,
			y: 122.2,
			region: 0,
			type: "empty"
		},
		{
			id: 54,
			x: 442.2,
			y: 184.1,
			region: 0,
			type: "empty"
		},
		{
			id: 55,
			x: 496.3,
			y: 152.4,
			region: 0,
			type: "empty"
		},
		{
			id: 56,
			x: 496.3,
			y: 214.7,
			region: 0,
			type: "empty"
		},
		{
			id: 57,
			x: 442.2,
			y: 246.5,
			region: 0,
			type: "empty"
		},
		{
			id: 58,
			x: 496.3,
			y: 277.8,
			region: 1,
			type: "empty"
		},
		{
			id: 59,
			x: 442.2,
			y: 309.5,
			region: 1,
			type: "empty"
		},
		{
			id: 60,
			x: 496.3,
			y: 340.1,
			region: 1,
			type: "reef"
		},
		{
			id: 61,
			x: 442.2,
			y: 371.8,
			region: 1,
			type: "empty"
		},
		{
			id: 62,
			x: 550.7,
			y: 308.9,
			region: 1,
			type: "empty"
		},
		{
			id: 63,
			x: 442.2,
			y: 435.6,
			region: 1,
			type: "empty"
		},
		{
			id: 64,
			x: 496.3,
			y: 403.9,
			region: 1,
			type: "empty"
		},
		{
			id: 65,
			x: 496.3,
			y: 466.2,
			region: -1,
			type: "rock"
		},
		{
			id: 66,
			x: 442.2,
			y: 497.9,
			region: 2,
			type: "empty"
		},
		{
			id: 67,
			x: 442.2,
			y: 559.8,
			region: 2,
			type: "empty"
		},
		{
			id: 68,
			x: 496.3,
			y: 528.1,
			region: -1,
			type: "rock"
		},
		{
			id: 69,
			x: 496.3,
			y: 590.4,
			region: 2,
			type: "empty"
		},
		{
			id: 70,
			x: 442.2,
			y: 622.1,
			region: 2,
			type: "empty"
		},
		{
			id: 71,
			x: 442.2,
			y: 685.3,
			region: 2,
			type: "empty"
		},
		{
			id: 72,
			x: 496.3,
			y: 653.6,
			region: 2,
			type: "reef"
		},
		{
			id: 73,
			x: 496.3,
			y: 716.3,
			region: 2,
			type: "empty"
		},
		{
			id: 74,
			x: 442.2,
			y: 748,
			region: 2,
			type: "empty"
		},
		{
			id: 75,
			x: 442.2,
			y: 810.9,
			region: 2,
			type: "empty"
		},
		{
			id: 76,
			x: 496.3,
			y: 779.2,
			region: 2,
			type: "empty"
		},
		{
			id: 77,
			x: 604.5,
			y: 717,
			region: 3,
			type: "empty"
		},
		{
			id: 78,
			x: 550.7,
			y: 748,
			region: 2,
			type: "empty"
		},
		{
			id: 79,
			x: 550.7,
			y: 685,
			region: 2,
			type: "empty"
		},
		{
			id: 80,
			x: 550.7,
			y: 622.4,
			region: 2,
			type: "empty"
		},
		{
			id: 81,
			x: 550.7,
			y: 559.2,
			region: 1,
			type: "empty"
		},
		{
			id: 82,
			x: 550.7,
			y: 496.8,
			region: 1,
			type: "empty"
		},
		{
			id: 83,
			x: 550.7,
			y: 435,
			region: 1,
			type: "empty"
		},
		{
			id: 84,
			x: 550.7,
			y: 372.7,
			region: 1,
			type: "empty"
		},
		{
			id: 85,
			x: 604.5,
			y: 340.8,
			region: 1,
			type: "empty"
		},
		{
			id: 86,
			x: 604.5,
			y: 404.6,
			region: 1,
			type: "empty"
		},
		{
			id: 87,
			x: 604.5,
			y: 466.9,
			region: 1,
			type: "empty"
		},
		{
			id: 88,
			x: 604.5,
			y: 528.8,
			region: 1,
			type: "empty"
		},
		{
			id: 89,
			x: 604.5,
			y: 591.1,
			region: 1,
			type: "empty"
		},
		{
			id: 90,
			x: 604.5,
			y: 654.3,
			region: -1,
			type: "rock"
		},
		{
			id: 91,
			x: 604.5,
			y: 779.9,
			region: 3,
			type: "empty"
		},
		{
			id: 92,
			x: 659.3,
			y: 811,
			region: 3,
			type: "empty"
		},
		{
			id: 93,
			x: 659.3,
			y: 748.1,
			region: 3,
			type: "empty"
		},
		{
			id: 94,
			x: 659.3,
			y: 685.4,
			region: 3,
			type: "empty"
		},
		{
			id: 95,
			x: 659.3,
			y: 622.2,
			region: -1,
			type: "rock"
		},
		{
			id: 96,
			x: 659.3,
			y: 559.8,
			region: 1,
			type: "empty"
		},
		{
			id: 97,
			x: 659.3,
			y: 498,
			region: 1,
			type: "reef"
		},
		{
			id: 98,
			x: 659.3,
			y: 435.7,
			region: 1,
			type: "empty"
		},
		{
			id: 99,
			x: 659.3,
			y: 371.9,
			region: 1,
			type: "empty"
		},
		{
			id: 100,
			x: 659.3,
			y: 309.5,
			region: 1,
			type: "empty"
		},
		{
			id: 101,
			x: 713.6,
			y: 278.3,
			region: 1,
			type: "empty"
		},
		{
			id: 102,
			x: 713.6,
			y: 341.4,
			region: 1,
			type: "empty"
		},
		{
			id: 103,
			x: 713.6,
			y: 403.7,
			region: 1,
			type: "empty"
		},
		{
			id: 104,
			x: 713.6,
			y: 467.5,
			region: 1,
			type: "empty"
		},
		{
			id: 105,
			x: 713.6,
			y: 529.8,
			region: 1,
			type: "empty"
		},
		{
			id: 106,
			x: 713.6,
			y: 591.7,
			region: 3,
			type: "empty"
		},
		{
			id: 107,
			x: 713.6,
			y: 654,
			region: 3,
			type: "empty"
		},
		{
			id: 108,
			x: 713.6,
			y: 717.2,
			region: 3,
			type: "reef"
		},
		{
			id: 109,
			x: 713.6,
			y: 779.9,
			region: 3,
			type: "empty"
		},
		{
			id: 110,
			x: 713.6,
			y: 842.8,
			region: 3,
			type: "empty"
		},
		{
			id: 111,
			x: 768.1,
			y: 873.4,
			region: 3,
			type: "empty"
		},
		{
			id: 112,
			x: 768.1,
			y: 810.5,
			region: 3,
			type: "empty"
		},
		{
			id: 113,
			x: 768.1,
			y: 747.8,
			region: 3,
			type: "empty"
		},
		{
			id: 114,
			x: 768.1,
			y: 684.6,
			region: 3,
			type: "empty"
		},
		{
			id: 115,
			x: 768.1,
			y: 622.3,
			region: 3,
			type: "empty"
		},
		{
			id: 116,
			x: 768.1,
			y: 560.4,
			region: 3,
			type: "empty"
		},
		{
			id: 117,
			x: 768.1,
			y: 498.1,
			region: 1,
			type: "empty"
		},
		{
			id: 118,
			x: 768.1,
			y: 434.3,
			region: 1,
			type: "empty"
		},
		{
			id: 119,
			x: 768.1,
			y: 372,
			region: 1,
			type: "reef"
		},
		{
			id: 120,
			x: 768.1,
			y: 308.9,
			region: 1,
			type: "empty"
		},
		{
			id: 121,
			x: 822.1,
			y: 340.6,
			region: 1,
			type: "empty"
		},
		{
			id: 122,
			x: 822.1,
			y: 403.6,
			region: 1,
			type: "empty"
		},
		{
			id: 123,
			x: 822.1,
			y: 465.9,
			region: -1,
			type: "rock"
		},
		{
			id: 124,
			x: 876.8,
			y: 498.2,
			region: 3,
			type: "empty"
		},
		{
			id: 125,
			x: 876.8,
			y: 560.5,
			region: 3,
			type: "empty"
		},
		{
			id: 126,
			x: 931.1,
			y: 529.3,
			region: 3,
			type: "empty"
		},
		{
			id: 127,
			x: 931.1,
			y: 591.6,
			region: 3,
			type: "empty"
		},
		{
			id: 128,
			x: 931.1,
			y: 653.5,
			region: 3,
			type: "empty"
		},
		{
			id: 129,
			x: 931.1,
			y: 715.8,
			region: 3,
			type: "empty"
		},
		{
			id: 130,
			x: 876.8,
			y: 622.4,
			region: 3,
			type: "empty"
		},
		{
			id: 131,
			x: 876.8,
			y: 684.7,
			region: 3,
			type: "empty"
		},
		{
			id: 132,
			x: 876.8,
			y: 748,
			region: 3,
			type: "empty"
		},
		{
			id: 133,
			x: 876.8,
			y: 873.5,
			region: 3,
			type: "empty"
		},
		{
			id: 134,
			x: 876.8,
			y: 810.6,
			region: 3,
			type: "empty"
		},
		{
			id: 135,
			x: 822.1,
			y: 905,
			region: 3,
			type: "empty"
		},
		{
			id: 136,
			x: 822.1,
			y: 842.1,
			region: 3,
			type: "reef"
		},
		{
			id: 137,
			x: 822.1,
			y: 779.4,
			region: 3,
			type: "empty"
		},
		{
			id: 138,
			x: 822.1,
			y: 716.2,
			region: 3,
			type: "empty"
		},
		{
			id: 139,
			x: 822.1,
			y: 653.9,
			region: 3,
			type: "empty"
		},
		{
			id: 140,
			x: 822.1,
			y: 592,
			region: 3,
			type: "reef"
		},
		{
			id: 141,
			x: 822.1,
			y: 529.7,
			region: 3,
			type: "empty"
		}
	]
}, z = [
	"jellyfish",
	"starfish",
	"crab",
	"turtle"
];
function B(e) {
	let t = e % 32, n = z[Math.floor(t / 8)], r = t % 8;
	return {
		kind: n,
		count: r < 5 ? 1 : r < 7 ? 2 : n === "jellyfish" ? 4 : n === "crab" ? 1 : 2,
		special: r === 7,
		owner: Math.floor(e / 32)
	};
}
function V(e, t) {
	return R[e.board].filter((e) => e.type !== "rock" && t.includes(e.region));
}
var H = /* @__PURE__ */ new Map();
function U(e, t) {
	let n = `${e.board}:${[...t].sort().join(",")}`, r = H.get(n);
	if (r) return r;
	let i = V(e, t), a = new Map(i.map((e) => [e.id, i.filter((t) => e.id !== t.id && Math.hypot(e.x - t.x, e.y - t.y) < 70).map((e) => e.id)]));
	return H.set(n, a), a;
}
function W(e, t) {
	let n = e.pieces.filter((e) => !t.some((t) => t.cell === e.cell)).concat(t.map((e) => ({
		...e,
		owner: B(e.tile).owner,
		faceUp: !0,
		reef: null
	}))), r = U(e.config, e.regions), i = e.reefs.map((e) => ({
		...e,
		explored: e.explored || e.cells.some((e) => r.get(e)?.some((e) => n.some((t) => t.faceUp && t.cell === e)))
	})), a = t[0] ? B(t[0].tile) : null, o = a ? K(n, r, a.owner, a.kind).filter((e) => e.some((e) => t.some((t) => t.cell === e.cell))) : [], s = t.some((e) => B(e.tile).special && B(e.tile).kind === "starfish"), c = t.some((e) => !B(e.tile).special);
	return {
		pieces: n,
		reefs: i,
		points: o.reduce((e, t) => e + q(t), 0),
		valid: c && o.length === (s ? 2 : 1),
		groups: o.length
	};
}
function ee(e, t, n, r) {
	return (r.get(e) ?? []).some((e) => t.some((t) => t.cell === e && t.faceUp) || n.some((t) => t.explored && t.cells.includes(e)));
}
function G(e) {
	let t = U(e.config, e.regions);
	return V(e.config, e.regions).filter((t) => !e.pieces.some((e) => e.cell === t.id) && !e.reefs.some((e) => e.cells.includes(t.id))).filter((n) => {
		let r = e.reefs.filter((e) => (t.get(n.id) ?? []).some((t) => e.cells.includes(t)));
		return r.length === 1 && r[0].explored && !r[0].scored;
	}).map((e) => e.id);
}
function te(e, t) {
	let n = U(e.config, e.regions), r = B(t);
	return V(e.config, e.regions).filter((t) => {
		if (e.reefs.some((e) => e.cells.includes(t.id))) return !1;
		let i = e.pieces.find((e) => e.cell === t.id);
		return r.special && r.kind === "crab" ? i?.faceUp && i.owner !== r.owner : !i && ee(t.id, e.pieces, e.reefs, n);
	}).map((e) => e.id);
}
function K(e, t, n, r) {
	let i = e.filter((e) => e.owner === n && e.faceUp && B(e.tile).kind === r), a = /* @__PURE__ */ new Set(), o = [];
	for (let e of i) {
		if (a.has(e.cell)) continue;
		let n = [], r = [e];
		for (a.add(e.cell); r.length;) {
			let e = r.pop();
			n.push(e);
			for (let n of i) !a.has(n.cell) && t.get(e.cell)?.includes(n.cell) && (a.add(n.cell), r.push(n));
		}
		o.push(n);
	}
	return o;
}
var q = (e) => e.reduce((e, t) => e + B(t.tile).count, 0);
function J(e, t, n, r) {
	let i = new Set(e.cells.flatMap((e) => n.get(e) ?? []));
	return Array.from({ length: r }, (e, n) => q(t.filter((e) => e.faceUp && e.owner === n && i.has(e.cell))));
}
function ne(e, t) {
	let n = [
		0,
		0,
		4,
		8,
		16,
		24
	][Math.min(e, 5)], r = n / 2, i = t.map(() => 0), a = Math.max(...t);
	if (!a) return i;
	let o = t.flatMap((e, t) => e === a ? [t] : []);
	if (o.length > 1) {
		for (let e of o) i[e] = Math.ceil((n + r) / o.length);
		return i;
	}
	i[o[0]] = n;
	let s = Math.max(0, ...t.filter((e) => e !== a));
	if (!s || t.length === 2 && s * 2 < a) return i;
	let c = t.flatMap((e, t) => e === s ? [t] : []);
	for (let e of c) i[e] = Math.ceil(r / c.length);
	return i;
}
var Y = (e) => e.colony + e.reef + e.discovery + e.leftover;
function re(t, n, r) {
	let i = A.parse(t), a = [
		0,
		1,
		3,
		2
	], o = Array.from({ length: n.length }, (e, t) => a[(t + i.regionStart) % 4]), s = {
		config: i,
		players: n,
		regions: o,
		pieces: [],
		reefs: [],
		hands: [],
		decks: [],
		specials: [],
		tokens: [],
		scores: [],
		turn: 0,
		move: 1,
		phase: "play",
		antlers: n.length * 3 - 1,
		queue: [],
		last: null,
		seed: r,
		cursor: 0
	}, c = V(i, o).filter((e) => e.type === "reef"), l = e(r, s.cursor++, c.length);
	return s.reefs = c.map((e, t) => ({
		root: e.id,
		cells: [e.id],
		explored: t === l,
		scored: !1,
		tokens: i.discovery ? [...z] : []
	})), n.forEach((t, n) => {
		let a = Array.from({ length: 32 }, (e, t) => n * 32 + t).filter((e) => !B(e).special);
		for (let t = a.length - 1; t > 0; t--) {
			let n = e(r, s.cursor++, t + 1);
			[a[t], a[n]] = [a[n], a[t]];
		}
		s.hands.push(a.splice(0, 5)), s.decks.push(a), s.specials.push(i.special ? [
			7,
			15,
			23,
			31
		].map((e) => n * 32 + e) : []), s.tokens.push([
			0,
			0,
			0,
			0
		]), s.scores.push({
			colony: 0,
			reef: 0,
			discovery: 0,
			leftover: 0
		});
	}), {
		state: s,
		fx: s.players.map((e, t) => ({
			kind: "research",
			rid: e,
			data: {
				placements: [],
				drawn: 5,
				removed: []
			},
			for: [e],
			secret: { cards: s.hands[t] }
		}))
	};
}
function ie(e, t, n) {
	let r = e.players[e.turn], i = t.hands[e.turn].filter((t) => !e.hands[e.turn].includes(t)), a = e.pieces.filter((e) => e.faceUp && n.some((t) => t.cell === e.cell));
	return [{
		kind: "research",
		rid: r,
		data: {
			placements: n.map((t) => ({
				...t,
				tile: t.faceUp ? t.tile : e.turn * 32
			})),
			drawn: i.length,
			removed: a.map((t) => ({
				tile: t.tile,
				cell: t.cell,
				ownerRid: e.players[t.owner]
			}))
		},
		for: [r],
		secret: { cards: i }
	}];
}
function ae(e, t) {
	let n = e.hands[e.turn], r = e.decks[e.turn];
	n.push(...r.splice(0, Math.min(t, 7 - n.length)));
}
function oe(e) {
	let t = U(e.config, e.regions);
	for (let n of e.reefs) {
		if (n.scored) continue;
		let r = new Set(n.cells.flatMap((e) => t.get(e) ?? [])), i = e.pieces.filter((e) => e.faceUp && r.has(e.cell));
		i.length && (n.explored = !0);
		for (let t of [...n.tokens]) {
			let r = i.filter((e) => B(e.tile).kind === t);
			if (!r.length) continue;
			let a = r.map((e) => e.owner).sort((t, n) => (t - e.turn + e.players.length) % e.players.length - (n - e.turn + e.players.length) % e.players.length)[0];
			for (e.tokens[a][z.indexOf(t)]++, n.tokens = n.tokens.filter((e) => e !== t); e.tokens[a].every((e) => e > 0);) e.tokens[a] = e.tokens[a].map((e) => e - 1), e.scores[a].discovery += 10;
		}
	}
}
function se(e) {
	let t = U(e.config, e.regions), n = /* @__PURE__ */ new Set([...e.pieces.map((e) => e.cell), ...e.reefs.flatMap((e) => e.cells)]);
	return e.reefs.filter((e) => !e.scored && e.cells.every((e) => (t.get(e) ?? []).every((e) => n.has(e)))).map((e) => e.root);
}
function ce(e) {
	e.antlers <= 0 || !e.hands[e.turn].length ? (e.phase = "done", e.scores.forEach((t, n) => {
		t.leftover = e.tokens[n].reduce((e, t) => e + t, 0);
	})) : (e.turn = (e.turn + 1) % e.players.length, e.move++, e.phase = "play");
}
function le(e, t) {
	if (t && e.hands[e.turn].length) {
		e.phase = "bonus";
		return;
	}
	e.queue = se(e), e.queue.length ? e.phase = "resolve" : ce(e);
}
function ue(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "resolve") return { state: e };
		let t = structuredClone(e), n = t.queue.shift(), r = t.reefs.find((e) => e.root === n), i = U(t.config, t.regions), a = ne(r.cells.length, J(r, t.pieces, i, t.players.length));
		return a.forEach((e, n) => {
			t.scores[n].reef += e;
		}), r.scored = !0, r.tokens = [], t.antlers = Math.max(0, t.antlers - 1), t.last = {
			kind: "score",
			cells: [...r.cells],
			points: a[t.turn],
			player: t.turn
		}, t.queue.length || ce(t), {
			state: t,
			fx: [{
				kind: "reefScore",
				data: {
					root: n,
					awards: a,
					players: t.players
				}
			}]
		};
	}
	if (!["play", "bonus"].includes(e.phase) || e.players[e.turn] !== n.by) return { code: "games.seagrass.errTurn" };
	let r = structuredClone(e), i = r.turn, a = U(r.config, r.regions), o = G(r);
	if (t.type === "reef") {
		if (!r.hands[i].includes(t.tile) || !o.includes(t.cell)) return { code: "games.seagrass.errPlacement" };
		let n = r.reefs.find((e) => (a.get(t.cell) ?? []).some((t) => e.cells.includes(t)));
		return r.hands[i] = r.hands[i].filter((e) => e !== t.tile), r.pieces.push({
			cell: t.cell,
			tile: t.tile,
			owner: i,
			faceUp: !1,
			reef: n.root
		}), n.cells.push(t.cell), oe(r), ae(r, 3), r.last = {
			kind: "reef",
			cells: [t.cell],
			points: 0,
			player: i
		}, le(r, !1), {
			state: r,
			fx: ie(e, r, [{
				tile: t.tile,
				cell: t.cell,
				faceUp: !1
			}])
		};
	}
	if (e.phase === "bonus" && o.length) return { code: "games.seagrass.errBonus" };
	let s = t.placements.map((e) => e.tile), c = t.placements.map((e) => e.cell);
	if (new Set(s).size !== s.length || new Set(c).size !== c.length) return { code: "games.seagrass.errPlacement" };
	let l = s.map(B), u = l[0].kind;
	if (l.some((e) => e.kind !== u || e.owner !== i) || !s.some((e) => r.hands[i].includes(e))) return { code: "games.seagrass.errMatch" };
	let d = s.filter((e) => B(e).special);
	if (d.length > 1 || s.some((e) => !(B(e).special ? r.specials[i] : r.hands[i]).includes(e))) return { code: "games.seagrass.errMatch" };
	for (let e of t.placements) {
		if (!te(r, e.tile).includes(e.cell)) return { code: "games.seagrass.errPlacement" };
		r.pieces = r.pieces.filter((t) => t.cell !== e.cell), r.pieces.push({
			cell: e.cell,
			tile: e.tile,
			owner: i,
			faceUp: !0,
			reef: null
		}), oe(r);
	}
	let f = K(r.pieces, a, i, u).filter((e) => e.some((e) => c.includes(e.cell)));
	if (f.length !== (d.length && u === "starfish" ? 2 : 1)) return { code: "games.seagrass.errColony" };
	let p = f.reduce((e, t) => e + q(t), 0);
	return r.scores[i].colony += p, r.hands[i] = r.hands[i].filter((e) => !s.includes(e)), r.specials[i] = r.specials[i].filter((e) => !s.includes(e)), r.hands[i].length || ae(r, 1), r.last = {
		kind: "colony",
		cells: c,
		points: p,
		player: i
	}, le(r, !!d.length && u === "turtle"), {
		state: r,
		fx: ie(e, r, t.placements.map((e) => ({
			...e,
			faceUp: !0
		})))
	};
}
function de(e, t) {
	let n = e.players.indexOf(t);
	return {
		public: {
			config: e.config,
			regions: e.regions,
			pieces: e.pieces.map((e) => e.faceUp ? e : {
				...e,
				tile: e.owner * 32
			}),
			reefs: e.reefs,
			turn: e.turn,
			move: e.move,
			phase: e.phase,
			antlers: e.antlers,
			queue: e.queue,
			last: e.last,
			players: e.players.map((t, n) => ({
				rid: t,
				handCount: e.hands[n].length,
				deckCount: e.decks[n].length,
				specials: e.specials[n].map((e) => B(e).kind),
				tokens: e.tokens[n],
				score: e.phase === "done" ? Y(e.scores[n]) : null,
				breakdown: e.phase === "done" ? e.scores[n] : null,
				unplayed: e.hands[n].length + e.decks[n].length + e.specials[n].length
			}))
		},
		...n >= 0 ? { private: {
			hand: e.hands[n],
			specials: e.specials[n],
			score: Y(e.scores[n]),
			breakdown: e.scores[n]
		} } : {}
	};
}
function fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => e.hands[t].length + e.decks[t].length + e.specials[t].length, n = e.players.map((e, t) => t).sort((n, r) => Y(e.scores[r]) - Y(e.scores[n]) || t(r) - t(n)), r = n[0];
	return {
		phase: "done",
		ranking: n.map((t) => e.players[t]),
		winner: n.filter((n) => Y(e.scores[n]) === Y(e.scores[r]) && t(n) === t(r)).map((t) => e.players[t]),
		scores: Object.fromEntries(e.players.map((t, n) => [t, Y(e.scores[n])]))
	};
}
var pe = {
	meta: O,
	saveCompatibility: { version: "1" },
	schemas: {
		action: M,
		publicView: I,
		privateView: L,
		config: A
	},
	setup: re,
	reduce: ue,
	viewFor: de,
	status: fe,
	nextTickIn: (e) => e.phase === "resolve" ? 650 : null
}, me = {
	turtle: {
		box: "0 0 140 132",
		base: "M66,6L64,8L62,8L62,9L59,12L59,17L58,18L58,21L57,22L57,26L56,27L56,35L55,36L54,36L52,38L51,38L50,37L49,34L48,34L47,33L47,32L45,30L44,30L43,29L43,28L40,28L39,27L30,27L29,28L27,28L25,30L24,30L22,32L22,33L19,36L17,41L13,46L13,47L12,48L12,49L11,50L11,51L10,52L8,57L7,58L6,58L6,59L5,60L5,63L6,63L7,64L11,64L12,63L17,63L19,61L21,61L21,60L22,59L23,59L23,58L24,57L25,57L29,53L29,52L30,51L34,51L35,52L35,55L33,58L33,61L32,62L32,67L31,68L31,75L32,76L32,83L34,86L34,89L35,90L35,91L36,92L38,97L40,99L40,104L39,105L39,107L38,108L38,111L39,112L39,114L40,115L40,119L41,120L41,121L42,121L43,122L45,122L46,121L48,121L49,120L49,116L51,113L55,113L56,114L56,115L58,115L59,116L59,117L61,117L63,119L65,119L66,120L66,121L70,121L72,119L73,119L78,115L80,115L80,114L81,113L84,113L87,116L87,121L89,121L90,122L93,122L95,119L95,117L96,116L96,114L97,113L97,104L96,103L95,100L96,99L98,94L101,91L101,88L103,85L103,80L104,79L104,73L105,72L104,71L104,64L103,63L103,60L101,57L101,54L100,53L100,52L101,51L105,51L106,52L106,53L107,53L108,54L108,55L109,55L110,56L110,57L112,57L113,58L113,59L114,59L119,63L123,63L126,65L128,65L130,63L131,63L131,62L130,61L130,60L129,59L127,54L123,49L123,48L122,47L122,46L121,45L121,44L120,43L120,42L119,41L117,36L111,30L110,30L108,28L106,28L105,27L103,27L102,26L98,26L97,27L96,27L95,28L93,28L91,30L90,30L90,31L89,32L88,32L88,33L86,36L82,36L80,33L80,30L79,29L79,23L78,22L78,20L77,19L77,13L75,11L75,10L74,10L73,9L73,8L71,8L70,7L70,6Z",
		shade: "M60,105L60,108L66,112L71,110L74,107L74,106L70,101L63,101L62,102L62,103ZM89,93L88,93L87,92L80,92L77,95L77,96L76,97L76,100L77,101L77,102L79,104L80,104L87,97L87,96L89,94ZM45,92L44,93L45,94L45,95L54,104L56,104L56,103L58,100L58,97L56,95L56,94L54,92ZM63,83L59,88L59,90L61,92L61,93L63,96L70,96L72,94L72,93L74,90L74,88L73,87L73,86L70,83ZM83,70L80,73L80,74L78,76L78,77L76,80L78,85L80,87L92,87L94,85L94,84L95,83L95,80L96,79L96,75L97,74L97,71L96,70ZM38,70L37,71L37,75L38,76L38,80L39,81L39,84L41,86L45,86L46,87L54,87L55,86L56,83L58,81L58,79L55,76L54,73L51,70ZM63,57L59,61L59,62L57,64L57,65L56,66L56,68L58,70L59,73L63,77L71,77L73,75L73,74L75,72L75,71L78,68L78,67L76,65L75,62L71,57ZM81,46L80,47L80,48L78,50L78,51L76,53L76,55L77,56L77,57L80,60L81,63L82,64L94,64L95,63L95,61L94,60L94,59L93,58L93,56L91,54L91,53L86,48L85,48L83,46ZM52,46L49,47L42,54L42,55L39,60L39,62L38,63L39,64L51,64L53,62L53,61L57,56L57,53L56,52L56,51L54,49L54,48ZM58,42L58,44L59,45L61,50L63,52L69,52L70,51L71,51L73,49L73,48L75,46L75,45L76,44L74,42L70,42L69,41L64,41L63,42ZM25,31L23,31L22,32L22,33L19,36L17,41L15,43L15,45L12,48L12,49L8,56L9,57L12,57L15,54L15,50L14,49L14,46L15,45L18,45L19,44L20,44L25,40L25,39L26,38L26,35L25,34ZM27,29L31,33L34,33L35,34L37,34L38,33L39,33L42,30L42,29L39,27L30,27ZM92,29L92,30L95,33L102,33L103,32L104,32L107,29L108,29L109,30L109,32L108,33L108,36L107,37L108,40L110,42L111,42L113,44L114,44L115,45L119,45L119,41L118,40L117,37L115,35L115,34L111,30L109,30L107,28L106,28L105,27L103,27L102,26L98,26L97,27L96,27L95,28L93,28ZM61,11L60,11L59,12L59,14L60,14L61,13ZM73,10L73,13L75,15L76,15L76,12L74,10Z"
	},
	crab: {
		box: "0 0 140 132",
		base: "M40,9L40,10L38,12L38,14L36,16L36,18L35,19L34,19L34,20L32,23L32,26L31,27L30,27L30,35L31,36L31,38L28,43L28,50L33,55L33,56L35,58L35,62L36,63L36,66L35,67L34,67L34,68L33,69L31,69L31,70L30,71L28,71L28,72L27,73L23,73L22,72L21,69L18,66L17,63L16,63L15,62L15,61L18,58L19,58L19,57L22,52L22,49L23,48L23,41L21,41L20,44L18,46L18,47L16,49L14,54L12,56L12,57L11,58L11,60L10,61L10,62L11,63L11,64L12,65L12,66L13,67L13,68L14,69L16,74L18,76L18,77L20,79L20,80L25,80L27,78L29,78L31,76L33,76L33,75L34,74L37,74L37,73L38,72L41,72L42,73L43,76L41,79L39,79L39,80L38,81L36,81L34,83L32,83L32,84L31,85L29,85L27,87L26,87L25,88L25,90L26,91L26,92L27,93L27,94L28,95L30,100L32,102L32,104L33,104L34,105L34,107L36,109L36,110L37,111L39,116L41,118L42,118L43,119L67,119L67,117L66,117L64,115L61,115L60,114L58,114L57,113L50,113L47,115L44,115L43,114L43,112L42,111L42,109L39,104L39,101L38,100L37,97L36,97L35,96L35,95L34,95L32,92L32,91L35,88L37,88L39,86L41,86L42,87L42,88L41,89L41,92L42,93L42,94L43,95L43,96L44,97L44,98L45,99L47,104L49,106L65,106L65,105L64,105L62,103L60,103L59,102L52,102L51,101L51,99L49,96L49,92L51,90L53,90L53,89L54,88L56,88L58,86L61,86L62,87L62,88L64,88L66,90L81,90L83,88L84,88L84,87L85,86L88,86L89,87L89,88L91,88L93,90L95,90L96,91L97,94L96,95L96,96L94,99L94,101L93,102L87,102L86,103L84,103L82,105L81,105L81,106L97,106L97,105L98,104L99,104L99,103L101,100L101,98L103,96L103,94L104,93L104,89L103,89L102,88L102,87L99,87L97,85L95,85L94,84L94,81L95,80L98,80L99,81L99,82L100,82L105,86L107,86L108,87L108,88L111,88L114,91L114,92L113,93L112,93L112,94L109,97L109,98L108,99L108,100L104,107L104,110L103,111L103,114L102,115L100,115L97,113L89,113L86,115L82,115L80,117L79,117L79,119L102,119L103,118L105,118L105,117L106,116L107,116L107,115L108,114L108,113L109,112L109,111L110,110L110,109L111,108L111,107L112,106L112,105L113,104L115,99L116,98L117,98L117,96L119,94L119,93L120,92L120,88L119,87L118,87L116,85L115,85L113,83L111,83L110,82L110,81L108,81L106,79L104,79L102,76L103,73L104,72L107,72L109,74L111,74L112,75L112,76L115,76L116,77L116,78L118,78L120,80L125,80L127,78L127,77L128,76L128,75L129,74L131,69L133,67L133,65L135,62L135,60L134,59L133,56L131,54L131,53L130,52L130,51L129,50L129,49L128,48L126,43L123,40L123,41L122,42L122,47L123,48L123,52L124,53L125,56L130,61L130,62L127,65L126,68L125,69L124,69L124,70L122,73L119,73L118,72L118,71L115,71L114,70L114,69L112,69L111,68L111,67L110,67L109,66L109,65L110,64L110,61L111,60L111,57L112,56L112,55L113,54L114,54L114,53L117,50L117,43L115,40L115,35L116,34L116,29L115,28L115,27L114,26L114,25L113,24L113,23L112,22L112,21L111,20L111,19L110,18L110,17L109,16L107,11L106,11L105,10L105,9L102,9L101,8L83,8L82,9L80,9L80,10L78,12L87,15L92,20L92,22L91,23L82,23L83,26L85,26L86,27L86,28L88,28L90,30L92,30L93,31L93,32L96,32L97,33L97,34L100,34L101,35L101,36L106,36L108,38L108,40L112,47L112,48L110,51L104,51L100,47L99,47L98,46L98,45L96,45L95,44L95,43L93,43L92,42L92,41L89,41L88,40L88,39L87,39L86,38L86,37L85,36L85,33L84,32L82,32L81,33L81,34L79,36L71,36L70,37L66,37L65,36L64,33L63,32L61,32L60,33L60,38L59,39L58,39L58,40L57,41L54,41L54,42L53,43L51,43L51,44L50,45L48,45L48,46L47,47L46,47L42,51L42,52L41,53L39,53L37,51L36,51L35,50L35,49L34,49L33,48L33,47L36,42L36,38L39,36L44,36L46,34L48,34L50,32L52,32L52,31L53,30L55,30L57,28L59,28L63,24L63,23L54,23L53,22L53,21L56,18L56,17L57,16L58,16L60,14L62,14L63,13L65,13L66,12L67,12L67,11L65,9L63,9L62,8L43,8L42,9Z",
		shade: "M80,118L102,118L103,117L103,116L102,115L100,115L97,113L89,113L86,115L82,115L80,117ZM41,116L41,118L65,118L66,117L64,115L61,115L60,114L58,114L57,113L50,113L47,115L42,115ZM83,104L83,105L95,105L95,104L93,102L87,102L86,103L84,103ZM49,103L49,105L63,105L63,104L62,103L60,103L59,102L50,102ZM22,42L21,42L20,43L20,44L16,49L14,54L12,56L12,57L11,58L11,61L14,60L20,54L20,52L21,51L21,48L22,47ZM123,41L122,42L122,47L123,48L123,52L124,53L125,56L128,59L129,59L131,61L134,61L134,59L133,58L131,53L129,51L129,50L128,49L126,44L124,42L124,41ZM82,32L81,33L81,35L82,36L84,36L84,33L83,32ZM62,32L61,32L60,33L60,36L61,37L63,35L63,33ZM79,12L82,12L83,13L86,14L93,21L96,18L96,17L100,12L101,9L100,8L83,8L82,9L81,9L79,11ZM42,9L42,10L44,12L44,13L46,15L46,16L50,21L51,21L59,13L60,13L61,12L65,12L66,11L66,10L65,9L63,9L62,8L43,8Z"
	},
	starfish: {
		box: "0 0 150 140",
		base: "M87,12L86,13L83,14L83,15L81,17L81,19L79,22L79,25L77,28L77,31L76,32L76,33L75,34L73,39L70,42L70,43L69,44L68,44L63,48L60,48L58,50L51,50L50,51L34,51L33,52L30,52L30,53L29,54L29,59L35,65L36,65L38,67L39,67L41,69L42,69L49,76L49,77L50,77L51,78L51,79L53,82L53,85L55,88L55,98L54,99L54,102L53,103L53,105L52,106L52,108L51,109L51,112L50,113L50,115L49,116L49,121L51,123L52,123L53,124L54,124L55,123L58,123L60,121L61,121L63,119L64,119L66,117L67,117L71,113L73,113L75,111L77,111L79,109L95,109L96,110L96,111L99,111L101,113L102,113L104,115L105,115L107,117L108,117L110,119L111,119L116,123L123,123L123,122L124,121L124,112L122,109L122,106L121,105L121,103L120,102L120,98L119,97L119,89L120,88L120,84L121,83L123,78L126,75L126,74L127,73L128,73L128,72L129,71L130,71L132,69L133,69L137,65L138,65L140,63L141,63L145,58L145,54L143,52L140,52L139,51L123,51L122,50L115,50L113,48L111,48L109,46L107,46L106,45L106,44L105,44L104,43L104,42L103,42L102,41L102,40L101,39L101,38L100,37L100,36L96,29L96,27L95,26L95,24L94,23L94,21L93,20L93,18L92,17L92,16L89,13L88,13Z",
		shade: "M56,100L54,100L54,102L53,103L53,105L52,106L52,108L51,109L51,112L50,113L50,115L49,116L49,121L52,123L54,123L55,122L60,120L62,118L63,118L66,115L67,115L69,113L70,113L71,112L71,111L70,110L67,109L65,107L64,107L62,105L61,105ZM117,99L111,105L110,105L105,109L102,110L101,111L101,112L102,113L103,113L106,116L107,116L109,118L110,118L112,120L113,120L115,122L117,122L118,123L119,123L120,122L121,122L123,120L123,111L122,110L122,108L121,107L121,105L120,104L120,102L119,101L119,99ZM82,51L81,52L79,52L78,53L77,53L75,55L74,55L70,59L70,60L68,62L68,64L67,65L67,76L68,77L70,82L75,87L76,87L79,89L82,89L83,90L89,90L90,89L93,89L94,88L97,87L101,83L101,82L103,80L103,79L104,78L104,76L105,75L105,66L104,65L104,63L103,62L103,61L101,59L101,58L98,55L97,55L95,53L94,53L93,52L91,52L90,51ZM31,52L29,54L29,59L33,63L34,63L37,66L38,66L43,70L45,67L45,63L46,62L46,60L50,53L50,51L34,51L33,52ZM121,50L121,51L123,54L123,56L125,59L125,61L126,62L126,64L127,65L127,68L129,70L131,68L132,68L135,65L136,65L139,62L140,62L143,59L143,58L144,57L144,53L143,52L140,52L139,51L123,51L122,50ZM85,13L81,17L81,19L79,22L79,25L77,28L77,32L96,32L96,29L95,28L95,26L94,25L94,23L93,22L93,20L92,19L92,17L91,16L91,15L89,13Z"
	},
	jellyfish: {
		box: "0 0 140 140",
		base: "M76,11L73,13L66,13L64,15L61,15L59,17L57,17L55,19L54,19L52,21L51,21L49,23L48,23L48,24L47,25L46,25L46,26L40,33L40,34L36,41L36,43L35,44L35,46L34,47L34,52L33,53L33,74L39,74L41,72L43,72L44,71L45,71L46,72L48,72L49,73L49,76L50,77L50,88L49,89L49,92L48,93L48,95L47,96L47,97L45,99L45,100L44,101L43,101L43,102L42,103L41,103L38,106L38,110L40,112L45,112L47,110L48,110L52,106L52,105L55,102L55,101L57,98L57,95L58,94L58,88L59,87L59,75L60,74L63,74L63,73L64,72L65,72L66,73L66,125L69,127L72,127L73,126L74,126L74,125L75,124L75,77L77,74L81,74L83,77L83,124L84,125L84,126L85,126L86,127L90,127L92,125L92,75L94,73L95,73L96,74L98,74L100,77L100,94L101,95L101,96L102,97L102,99L103,100L104,103L106,105L106,106L110,110L111,110L113,112L119,112L119,111L120,110L120,105L119,105L112,98L112,97L110,94L110,92L109,91L109,73L112,71L115,71L116,72L117,72L119,74L125,74L125,51L124,50L124,47L123,46L123,43L122,42L122,41L121,40L121,39L120,38L120,37L119,36L117,31L116,31L115,30L114,27L113,27L112,26L112,25L111,25L110,24L110,23L109,23L107,21L106,21L105,20L105,19L103,19L101,17L99,17L97,15L94,15L92,13L85,13L84,12L82,12L81,11Z",
		shade: "M100,74L99,75L99,76L100,77L100,94L102,97L102,99L103,100L104,103L106,105L106,106L109,109L110,109L112,111L117,111L119,109L119,105L111,97L111,96L109,93L109,91L108,90L108,73L106,73L105,74ZM57,74L51,74L50,73L49,74L49,76L50,77L50,88L49,89L49,92L48,93L48,95L47,96L47,97L44,100L44,101L43,102L42,102L38,106L38,110L39,111L44,111L46,109L47,109L52,104L52,103L54,101L54,100L55,99L55,97L56,96L56,94L57,93L57,83L58,82L58,75ZM89,70L88,70L84,74L83,74L82,75L82,76L83,77L83,124L85,126L89,126L91,124L91,72ZM67,70L66,71L66,125L67,126L72,126L74,124L74,75L69,70ZM51,47L51,54L54,57L102,57L105,54L105,47L104,46L104,43L103,42L101,37L99,35L99,34L92,28L91,28L88,26L86,26L85,25L82,25L81,24L75,24L74,25L70,25L69,26L68,26L67,27L62,29L56,35L56,36L54,38L54,39L53,40L53,42L52,43L52,46Z"
	}
};
//#endregion
//#region src/games/seagrass/art.tsx
function he({ kind: e, className: t }) {
	let n = me[e];
	return /* @__PURE__ */ h("svg", {
		viewBox: n.box,
		className: t,
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("path", {
			d: n.base,
			fill: "currentColor",
			fillRule: "evenodd"
		}), /* @__PURE__ */ m("path", {
			d: n.shade,
			fill: "var(--sg-mark, #547c5a)",
			fillRule: "evenodd"
		})]
	});
}
function X({ className: e }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 100 100",
		className: e,
		"aria-hidden": !0,
		children: /* @__PURE__ */ m("path", {
			d: "M43 91V68L18 53Q11 47 17 42Q21 38 27 42L43 51V38L24 26Q18 22 22 16Q25 12 31 15L43 23V12Q43 5 50 5Q57 5 57 12V23L69 15Q75 12 78 18Q81 23 76 26L57 38V51L73 42Q80 37 84 43Q88 49 81 53L57 68V91Z",
			fill: "#ee8e94",
			stroke: "#bd5d77",
			strokeWidth: 2
		})
	});
}
function ge({ explored: e = !0 }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 100 100",
		"aria-hidden": !0,
		fill: "none",
		stroke: e ? "#42af97" : "#92a79e",
		strokeWidth: 4,
		strokeLinecap: "round",
		children: /* @__PURE__ */ m("path", { d: "M48 84V51L34 35V18M48 61L63 43V15M48 74L73 60L80 38M34 35L20 27V17M34 45L22 49L12 38M63 43L78 27V15M48 51L47 26L53 15M73 60L86 59L91 49M38 84L25 73L18 60M58 84L73 76L84 76" })
	});
}
function Z({ avatar: e }) {
	return /* @__PURE__ */ m("span", {
		className: "sg-portrait",
		children: /* @__PURE__ */ m("img", {
			src: f[e % f.length],
			alt: "",
			draggable: !1
		})
	});
}
function _e({ kind: e }) {
	let t = me[e];
	return /* @__PURE__ */ m("span", {
		className: `sg-discovery sg-discovery-${e}`,
		children: /* @__PURE__ */ m("svg", {
			viewBox: t.box,
			"aria-hidden": !0,
			children: /* @__PURE__ */ m("path", {
				d: t.base,
				fill: "currentColor"
			})
		})
	});
}
function ve({ kind: e }) {
	return e === "jellyfish" ? null : /* @__PURE__ */ m("span", {
		className: `sg-ability sg-ability-${e}`,
		"aria-hidden": !0,
		children: /* @__PURE__ */ h("svg", {
			viewBox: "0 0 32 32",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 2.2,
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ m("circle", {
				cx: 16,
				cy: 16,
				r: 14
			}), e === "turtle" ? /* @__PURE__ */ m("path", { d: "M16 25V9M16 18L10 14V9M16 15L22 11V7M16 23L24 19V15M10 14L7 11M16 10L12 6" }) : e === "starfish" ? /* @__PURE__ */ m("path", { d: "M16 7V25M5 16H13M5 16L9 12M5 16L9 20M27 16H19M27 16L23 12M27 16L23 20" }) : /* @__PURE__ */ m("path", { d: "M16 6V21M10 15L16 21L22 15M8 26H24" })]
		})
	});
}
function Q({ tile: e, color: t, back: n = !1, style: r }) {
	let i = B(e);
	return /* @__PURE__ */ m("div", {
		className: `sg-tile${n ? " sg-tile-back" : ""}`,
		style: {
			...r,
			"--sg-player": t,
			"--sg-mark": `color-mix(in srgb, ${t}, #293f35 40%)`
		},
		children: /* @__PURE__ */ m("div", {
			className: "sg-tile-core",
			children: n ? /* @__PURE__ */ m(ge, {}) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
				className: `sg-creatures sg-count-${i.count}${i.special ? ` sg-special-${i.kind}` : ""}`,
				children: Array.from({ length: i.count }, (e, t) => /* @__PURE__ */ m(he, { kind: i.kind }, t))
			}), i.special && /* @__PURE__ */ m(ve, { kind: i.kind })] })
		})
	});
}
//#endregion
//#region src/games/seagrass/labels.ts
function $(e, t) {
	return e(t === "jellyfish" ? "games.seagrass.jellyfish" : t === "starfish" ? "games.seagrass.starfish" : t === "crab" ? "games.seagrass.crab" : "games.seagrass.turtle");
}
function ye(e, t) {
	return e(t === "jellyfish" ? "games.seagrass.specialJellyfish" : t === "starfish" ? "games.seagrass.specialStarfish" : t === "crab" ? "games.seagrass.specialCrab" : "games.seagrass.specialTurtle");
}
//#endregion
//#region src/games/seagrass/board.tsx
function be({ id: e, x: t, y: n, piece: r, reef: i, root: o, preview: s, target: l, onPlace: u, onInspect: d, color: f, identity: g }) {
	let _ = c(), { ref: v, hidden: y } = a(`cell:${e}`), { ref: b, hidden: x } = a(`antler:${e}`), S = r?.faceUp ? B(r.tile) : null, C = l ? _("games.seagrass.placeAt", { n: e + 1 }) : S && r ? _("games.seagrass.ownedTile", {
		name: g(r.owner).name,
		tile: _(S.special ? "games.seagrass.specialTile" : "games.seagrass.tile", {
			kind: $(_, S.kind),
			n: S.count
		})
	}) : i ? _("games.seagrass.reefInfo", {
		size: i.cells.length,
		state: _(i.scored ? "games.seagrass.completed" : i.explored ? "games.seagrass.explored" : "games.seagrass.unexplored")
	}) : _("games.seagrass.cell", { n: e + 1 });
	return /* @__PURE__ */ m("div", {
		className: `sg-cell${l ? " sg-target" : ""}${s ? " sg-preview" : ""}`,
		style: {
			left: t - 37,
			top: n - 32,
			visibility: y ? "hidden" : void 0
		},
		ref: v,
		children: /* @__PURE__ */ h("button", {
			type: "button",
			disabled: !l && !r && !i,
			onClick: () => l ? u?.(e) : d(e),
			"aria-label": C,
			"data-cell": e,
			className: "sg-cell-hit",
			children: [
				/* @__PURE__ */ m("svg", {
					className: "sg-hex",
					viewBox: "0 0 74 64",
					"aria-hidden": !0,
					children: /* @__PURE__ */ m("polygon", { points: "18.5,1 55.5,1 73,32 55.5,63 18.5,63 1,32" })
				}),
				r ? /* @__PURE__ */ m(Q, {
					tile: r.tile,
					color: f(r.owner),
					back: !r.faceUp
				}) : i && /* @__PURE__ */ m("div", {
					className: `sg-reef${i.explored ? " sg-explored" : ""}`,
					children: /* @__PURE__ */ m(ge, { explored: i.explored })
				}),
				i && o && /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("span", {
						className: "sg-reef-size",
						children: _("games.seagrass.reefSize", { n: i.cells.length })
					}),
					i.scored && /* @__PURE__ */ m("span", {
						className: "sg-antler-slot",
						ref: b,
						style: { visibility: x ? "hidden" : void 0 },
						children: /* @__PURE__ */ m(X, { className: "sg-antler" })
					}),
					i.tokens.length > 0 && /* @__PURE__ */ m("span", {
						className: "sg-reef-tokens",
						children: i.tokens.map((e) => /* @__PURE__ */ m(_e, { kind: e }, e))
					})
				] }),
				l && /* @__PURE__ */ m("svg", {
					className: "sg-legal-outline",
					viewBox: "0 0 74 64",
					"aria-hidden": !0,
					children: /* @__PURE__ */ m("polygon", { points: "18.5,2 55.5,2 72,32 55.5,62 18.5,62 2,32" })
				})
			]
		})
	});
}
function xe({ pub: e, targets: t = [], preview: a = [], onPlace: o, color: s, identity: l }) {
	let u = c(), d = r(null), [f, _] = i({
		w: 600,
		h: 500
	}), [x, S] = i({
		zoom: 1,
		x: 0,
		y: 0
	}), [C, w] = i(null), T = a.find((e) => e.cell === C) ?? e.pieces.find((e) => e.cell === C), E = e.reefs.find((e) => e.cells.includes(C ?? -1)), D = T?.faceUp ? B(T.tile) : null, O = D && T ? l(T.owner) : null, k = r(/* @__PURE__ */ new Map()), A = r(!1), j = V(e.config, e.regions), M = Math.min(...j.map((e) => e.x)) - 46, N = Math.min(...j.map((e) => e.y)) - 42, P = Math.max(...j.map((e) => e.x)) - M + 46, F = Math.max(...j.map((e) => e.y)) - N + 42, I = Math.min(f.w / P, f.h / F) * x.zoom, L = (f.w - P * I) / 2 + x.x, R = (f.h - F * I) / 2 + x.y;
	n(() => {
		let e = d.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => _({
			w: e.contentRect.width,
			h: e.contentRect.height
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let z = (e, t = f.w / 2, n = f.h / 2) => S((r) => {
		let i = Math.max(1, Math.min(4, r.zoom * e)), a = i / r.zoom;
		return {
			zoom: i,
			x: i === 1 ? 0 : (r.x + f.w / 2 - t) * a - f.w / 2 + t,
			y: i === 1 ? 0 : (r.y + f.h / 2 - n) * a - f.h / 2 + n
		};
	}), H = (e) => {
		e.button === 0 && (k.current.size || (A.current = !1), k.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY,
			startX: e.clientX,
			startY: e.clientY
		}));
	}, U = (e) => {
		let t = k.current.get(e.pointerId);
		if (!t) return;
		let n = [...k.current.values()];
		k.current.set(e.pointerId, {
			...t,
			x: e.clientX,
			y: e.clientY
		});
		let r = e.clientX - t.x, i = e.clientY - t.y;
		if ((Math.hypot(e.clientX - t.startX, e.clientY - t.startY) > 3 || k.current.size > 1) && (A.current = !0), A.current) {
			if (e.currentTarget.setPointerCapture(e.pointerId), k.current.size === 1) S((e) => ({
				...e,
				x: e.x + r,
				y: e.y + i
			}));
			else {
				let t = [...k.current.values()], a = (e) => Math.hypot(e[0].x - e[1].x, e[0].y - e[1].y), o = a(n), s = e.currentTarget.getBoundingClientRect();
				o && z(a(t) / o, (t[0].x + t[1].x) / 2 - s.left, (t[0].y + t[1].y) / 2 - s.top), S((e) => ({
					...e,
					x: e.x + r / 2,
					y: e.y + i / 2
				}));
			}
		}
	}, W = (e) => {
		k.current.delete(e.pointerId), e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
	};
	return /* @__PURE__ */ h("div", {
		className: "sg-board",
		ref: d,
		"data-board": e.config.board,
		children: [
			/* @__PURE__ */ m("img", {
				className: "sg-sea-garden",
				src: "games/seagrass/sea-garden.svg",
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ m("div", {
				className: "sg-sea-input",
				onPointerDown: H,
				onPointerMove: U,
				onPointerUp: W,
				onPointerCancel: W,
				onClickCapture: (e) => {
					A.current &&= (e.preventDefault(), e.stopPropagation(), !1);
				},
				onWheel: (e) => {
					let t = e.currentTarget.getBoundingClientRect();
					z(e.deltaY < 0 ? 1.15 : 1 / 1.15, e.clientX - t.left, e.clientY - t.top);
				},
				children: /* @__PURE__ */ h("div", {
					className: "sg-world",
					style: {
						width: P,
						height: F,
						transform: `translate(${L}px,${R}px) scale(${I})`
					},
					children: [/* @__PURE__ */ m("svg", {
						className: "sg-region-lines",
						viewBox: `0 0 ${P} ${F}`,
						"aria-hidden": !0,
						children: j.map((e) => /* @__PURE__ */ m("polygon", {
							points: [
								[18.5, 0],
								[55.5, 0],
								[74, 32],
								[55.5, 64],
								[18.5, 64],
								[0, 32]
							].map(([t, n]) => `${e.x - M - 37 + t},${e.y - N - 32 + n}`).join(" "),
							fill: "none",
							stroke: [
								"#25afa7",
								"#58c2a5",
								"#348d9d",
								"#6ac8bb"
							][e.region],
							strokeWidth: 8
						}, e.id))
					}), j.map((n) => {
						let r = a.find((e) => e.cell === n.id) ?? e.pieces.find((e) => e.cell === n.id), i = e.reefs.find((e) => e.cells.includes(n.id));
						return /* @__PURE__ */ m(be, {
							id: n.id,
							x: n.x - M,
							y: n.y - N,
							piece: r,
							reef: i,
							root: i?.root === n.id,
							preview: a.some((e) => e.cell === n.id),
							target: t.includes(n.id),
							onPlace: o,
							onInspect: w,
							color: s,
							identity: l
						}, n.id);
					})]
				})
			}),
			(D && T && O || E) && /* @__PURE__ */ h("section", {
				className: "sg-inspection",
				"aria-label": u("games.seagrass.details"),
				children: [D && T && O ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("div", {
					className: "sg-inspection-tile",
					children: /* @__PURE__ */ m(Q, {
						tile: T.tile,
						color: s(T.owner)
					})
				}), /* @__PURE__ */ h("div", {
					className: "sg-inspection-copy",
					children: [
						/* @__PURE__ */ h("div", {
							className: "sg-inspection-owner",
							style: { "--sg-player": s(T.owner) },
							children: [/* @__PURE__ */ m(Z, { avatar: O.avatar }), /* @__PURE__ */ m("strong", { children: O.name })]
						}),
						/* @__PURE__ */ m("span", { children: u(D.special ? "games.seagrass.specialTile" : "games.seagrass.tile", {
							kind: $(u, D.kind),
							n: D.count
						}) }),
						D.special && /* @__PURE__ */ m("p", { children: ye(u, D.kind) })
					]
				})] }) : E && /* @__PURE__ */ h("div", {
					className: "sg-inspection-copy",
					children: [/* @__PURE__ */ m("strong", { children: u("games.seagrass.reefInfo", {
						size: E.cells.length,
						state: u(E.scored ? "games.seagrass.completed" : E.explored ? "games.seagrass.explored" : "games.seagrass.unexplored")
					}) }), E.tokens.length > 0 && /* @__PURE__ */ m("p", { children: u("games.seagrass.undiscovered", { kinds: E.tokens.map((e) => $(u, e)).join(" / ") }) })]
				}), /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => w(null),
					"aria-label": u("games.seagrass.closeDetails"),
					children: /* @__PURE__ */ m(g, { size: 19 })
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "sg-camera",
				children: [
					/* @__PURE__ */ m("button", {
						"aria-label": u("games.seagrass.zoomOut"),
						onClick: () => z(1 / 1.4),
						children: /* @__PURE__ */ m(b, { size: 19 })
					}),
					/* @__PURE__ */ m("button", {
						"aria-label": u("games.seagrass.resetView"),
						onClick: () => S({
							zoom: 1,
							x: 0,
							y: 0
						}),
						children: /* @__PURE__ */ m(v, { size: 19 })
					}),
					/* @__PURE__ */ m("button", {
						"aria-label": u("games.seagrass.zoomIn"),
						onClick: () => z(1.4),
						children: /* @__PURE__ */ m(y, { size: 19 })
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/seagrass/view-player.tsx
function Se({ tile: e, selected: t, disabled: n, color: r, onClick: i }) {
	let o = c(), s = B(e), { ref: l, hidden: u } = a(`tile:${e}`), d = o(s.special ? "games.seagrass.specialTile" : "games.seagrass.tile", {
		kind: $(o, s.kind),
		n: s.count
	});
	return /* @__PURE__ */ m("button", {
		ref: l,
		className: `sg-hand-tile${t ? " sg-selected" : ""}`,
		disabled: n,
		"aria-pressed": t,
		"aria-label": d,
		title: s.special ? `${d}：${ye(o, s.kind)}` : d,
		style: { visibility: u ? "hidden" : void 0 },
		onClick: i,
		children: /* @__PURE__ */ m(Q, {
			tile: e,
			color: r
		})
	});
}
function Ce({ player: e, avatar: t, name: n, active: r, color: i, discovery: o }) {
	let s = c(), { ref: l } = a(`seat:${e.rid}`);
	return /* @__PURE__ */ h("div", {
		className: `sg-seat${r ? " sg-seat-active" : ""}`,
		style: { "--sg-player": i },
		ref: l,
		children: [
			/* @__PURE__ */ h("div", {
				className: "sg-seat-name",
				children: [
					/* @__PURE__ */ m(Z, { avatar: t }),
					/* @__PURE__ */ m("span", {
						className: "sg-player-name",
						children: n
					}),
					/* @__PURE__ */ m("span", {
						className: "sg-turn-dot",
						"aria-hidden": !0,
						children: r ? "◆" : ""
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "sg-seat-detail",
				children: [s("games.seagrass.handDeck", {
					hand: e.handCount,
					deck: e.deckCount
				}), /* @__PURE__ */ m("span", {
					className: "sg-seat-specials",
					"aria-label": s("games.seagrass.reserve"),
					children: e.specials.map((e) => /* @__PURE__ */ m(he, { kind: e }, e))
				})]
			}),
			o && /* @__PURE__ */ m("div", {
				className: "sg-token-row",
				children: z.map((t, n) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(_e, { kind: t }), /* @__PURE__ */ m("b", { children: e.tokens[n] })] }, t))
			})
		]
	});
}
function we(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ m(Te, {
		...e,
		pub: t,
		priv: n
	});
}
function Te({ pub: e, priv: t, members: n, myRid: r, send: f }) {
	let p = c(), g = s((e) => e.locale), [_, v] = i(e.phase === "bonus" && G(e).length ? "reef" : "colony"), [y, b] = i(null), [x, S] = i([]), C = e.players.findIndex((e) => e.rid === r), w = C === e.turn && ["play", "bonus"].includes(e.phase), T = G(e).length > 0, E = e.phase === "bonus" && T ? "reef" : "colony", D = t?.hand.join(","), O = `${r}:${e.move}:${e.phase}:${e.turn}:${D}`, [k, A] = i(O);
	k !== O && (A(O), v(E), b(null), S([]));
	let { ref: j } = a(`hand:${r}`), { ref: M } = a(`deck:${r}`), N = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? d(t, g) : e;
	}, P = (t) => l[(n.find((n) => n.rid === e.players[t]?.rid)?.colorIndex ?? t) % l.length].hex, F = (t) => ({
		name: N(e.players[t].rid),
		avatar: n.find((n) => n.rid === e.players[t].rid)?.avatar ?? 0
	}), I = W(e, _ === "colony" ? x : []), L = {
		...e,
		pieces: I.pieces,
		reefs: I.reefs
	}, R = w && y !== null ? _ === "reef" ? G(e) : te(L, y) : [], z = _ === "reef" ? x.map((e) => ({
		...e,
		owner: C,
		faceUp: !1,
		reef: null
	})) : x.map((e) => ({
		...e,
		owner: C,
		faceUp: !0,
		reef: null
	})), V = x.length ? B(x[0].tile).kind : null, H = (e) => w && !x.some((t) => t.tile === e) && (_ === "reef" ? !B(e).special : !V || B(e).kind === V), U = (e) => {
		_ === "reef" && S([]), b(y === e ? null : e);
	}, ee = (e) => {
		y !== null && R.includes(e) && (S(_ === "reef" ? [{
			tile: y,
			cell: e
		}] : [...x, {
			tile: y,
			cell: e
		}]), b(null));
	}, K = () => {
		w && x.length && (_ !== "colony" || I.valid) && f(_ === "reef" ? {
			type: "reef",
			...x[0]
		} : {
			type: "colony",
			placements: x
		});
	}, q = w ? e.phase === "bonus" ? p("games.seagrass.bonus") : p("games.seagrass.yourTurn") : e.phase === "done" ? p("games.seagrass.finished") : e.phase === "resolve" ? p("games.seagrass.resolving") : p("games.seagrass.waiting", { name: N(e.players[e.turn].rid) }), J = y === null ? x.length ? _ === "colony" && !I.valid ? x.every((e) => B(e.tile).special) ? p("games.seagrass.specialWithRegular") : p("games.seagrass.invalidGroup") : p("games.seagrass.addOrConfirm") : p("games.seagrass.chooseTile") : B(y).special ? ye(p, B(y).kind) : p("games.seagrass.chooseCell");
	return /* @__PURE__ */ m("div", {
		className: "sg-screen",
		children: /* @__PURE__ */ m(u, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ h("header", {
				className: "sg-header",
				children: [/* @__PURE__ */ h("div", {
					className: "sg-progress",
					children: [
						/* @__PURE__ */ m("strong", { children: q }),
						/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(X, {}), p("games.seagrass.antlers", { n: e.antlers })] }),
						/* @__PURE__ */ m("small", { children: p("games.seagrass.move", { n: e.move }) })
					]
				}), /* @__PURE__ */ m("div", {
					className: "sg-seats",
					style: { "--sg-seats": e.players.length },
					children: e.players.map((t, n) => /* @__PURE__ */ m(Ce, {
						player: t,
						avatar: F(n).avatar,
						name: N(t.rid),
						active: n === e.turn,
						color: P(n),
						discovery: e.config.discovery
					}, t.rid))
				})]
			}),
			children: /* @__PURE__ */ h("div", {
				className: "sg-research-layout",
				children: [/* @__PURE__ */ m(xe, {
					pub: e,
					preview: z,
					targets: R,
					onPlace: ee,
					color: P,
					identity: F
				}), /* @__PURE__ */ h("aside", {
					className: "sg-rack",
					ref: j,
					children: [
						/* @__PURE__ */ h("div", {
							className: "sg-rack-top",
							children: [/* @__PURE__ */ h("span", { children: [
								p("games.seagrass.ownScore"),
								" ",
								/* @__PURE__ */ m("strong", { children: /* @__PURE__ */ m(o, { value: t?.score ?? 0 }) })
							] }), /* @__PURE__ */ h("div", {
								className: "sg-deck",
								ref: M,
								"aria-label": p("games.seagrass.deck"),
								children: [/* @__PURE__ */ m("i", {}), /* @__PURE__ */ m("b", { children: e.players[C]?.deckCount ?? "—" })]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "sg-modes",
							children: [/* @__PURE__ */ m("button", {
								disabled: !w || e.phase === "bonus" && T,
								"aria-pressed": _ === "colony",
								onClick: () => {
									v("colony"), S([]), b(null);
								},
								children: p("games.seagrass.colony")
							}), /* @__PURE__ */ m("button", {
								disabled: !w || !T,
								"aria-pressed": _ === "reef",
								onClick: () => {
									v("reef"), S([]), b(null);
								},
								children: p("games.seagrass.reef")
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "sg-hand-scroll",
							children: /* @__PURE__ */ m("div", {
								className: "sg-hand",
								children: t?.hand.map((e) => /* @__PURE__ */ m(Se, {
									tile: e,
									color: P(C),
									selected: y === e,
									disabled: !H(e),
									onClick: () => U(e)
								}, e))
							})
						}),
						e.config.special && /* @__PURE__ */ h("div", {
							className: "sg-specials",
							children: [/* @__PURE__ */ m("span", { children: p("games.seagrass.reserve") }), /* @__PURE__ */ m("div", { children: t?.specials.map((e) => /* @__PURE__ */ m(Se, {
								tile: e,
								color: P(C),
								selected: y === e,
								disabled: !H(e),
								onClick: () => U(e)
							}, e)) })]
						}),
						/* @__PURE__ */ m("p", {
							className: "sg-help",
							"aria-live": "polite",
							children: w ? J : q
						}),
						/* @__PURE__ */ h("div", {
							className: "sg-submit",
							children: [
								/* @__PURE__ */ m("button", {
									disabled: !x.length,
									"aria-label": p("games.seagrass.cancel"),
									onClick: () => {
										S([]), b(null);
									},
									children: "↺"
								}),
								/* @__PURE__ */ m("button", {
									disabled: !x.length,
									onClick: () => {
										S(x.slice(0, -1)), b(null);
									},
									children: p("games.seagrass.undo")
								}),
								/* @__PURE__ */ m("button", {
									className: "sg-primary",
									disabled: !w || !x.length || _ === "colony" && !I.valid,
									onClick: K,
									children: p(_ === "reef" ? "games.seagrass.confirmReef" : "games.seagrass.confirmColony", { n: I.points })
								})
							]
						})
					]
				}, r)]
			})
		})
	});
}
//#endregion
//#region src/games/seagrass/bot.ts
var Ee = {
	colonyW: 1,
	reefW: .25,
	drawW: 2.4,
	frontierW: .12,
	specialCost: .5,
	discoveryW: 1.4
};
function De(e) {
	let t = /* @__PURE__ */ new Uint32Array(1);
	return crypto.getRandomValues(t), e[Math.floor(t[0] / 4294967296 * e.length)];
}
function Oe(e, t, n = 8) {
	let r = U(e.config, e.regions), i = [], a = new Set(G(e));
	for (let o of z) {
		let s = t.hand.filter((e) => B(e).kind === o), c = t.specials.filter((e) => B(e).kind === o);
		if (!s.length) continue;
		let l = [{
			placements: [],
			pieces: e.pieces,
			reefs: e.reefs,
			rank: 0
		}];
		for (let t = 0; t < s.length + c.length; t++) {
			let t = [], u = /* @__PURE__ */ new Set();
			for (let n of l) {
				let l = new Set(n.placements.map((e) => e.tile)), d = [...s, ...c].filter((e) => !l.has(e)), f = /* @__PURE__ */ new Set();
				for (let s of d) {
					let l = B(s), d = `${l.count}:${l.special}`;
					if (!f.has(d)) {
						f.add(d);
						for (let d of te({
							...e,
							pieces: n.pieces,
							reefs: n.reefs
						}, s)) {
							let f = [...n.placements, {
								tile: s,
								cell: d
							}], p = f.map((e) => `${e.cell}:${B(e.tile).count}:${B(e.tile).special}`).sort().join("|");
							if (u.has(p)) continue;
							u.add(p);
							let m = W(e, f);
							if (m.groups > (o === "starfish" && c.length ? 2 : 1)) continue;
							let h = new Set(m.pieces.filter((e) => e.owner === l.owner && e.faceUp && B(e.tile).kind === o).flatMap((e) => r.get(e.cell) ?? []).filter((t) => !m.pieces.some((e) => e.cell === t) && !e.reefs.some((e) => e.cells.includes(t)))), g = m.points + h.size * .12 + f.filter((e) => a.has(e.cell)).length * .05;
							m.valid && i.push(f), t.push({
								placements: f,
								pieces: m.pieces,
								reefs: m.reefs,
								rank: g
							});
						}
					}
				}
			}
			if (t.sort((e, t) => t.rank - e.rank), l = t.slice(0, n), !l.length) break;
		}
	}
	return i;
}
function ke(e, t, n, r) {
	let i = U(e.config, e.regions), a = /* @__PURE__ */ new Set([...t.map((e) => e.cell), ...n.flatMap((e) => e.cells)]);
	return n.reduce((n, o) => {
		if (o.scored) return n;
		let s = [...new Set(o.cells.flatMap((e) => i.get(e) ?? []).filter((e) => !o.cells.includes(e)))].filter((e) => !a.has(e)).length, c = J(o, t, i, e.players.length), l = ne(o.cells.length, c), u = Math.max(0, ...l.filter((e, t) => t !== r));
		return n + (l[r] - u / Math.max(1, e.players.length - 1)) * (s === 0 ? 1 : 1 / (1 + s * .35));
	}, 0);
}
function Ae(e, t, n, r) {
	let i = e.turn, a = U(e.config, e.regions), o = ke(e, e.pieces, e.reefs, i), s, c, l, u;
	if (n.type === "colony") {
		let o = W(e, n.placements);
		s = o.pieces, c = o.reefs, u = n.placements.map((e) => e.tile);
		let d = B(u[0]).kind, f = K(s, a, i, d).filter((e) => e.some((e) => n.placements.some((t) => t.cell === e.cell))), p = new Set(f.flatMap((e) => e.flatMap((e) => a.get(e.cell) ?? [])).filter((e) => !s.some((t) => t.cell === e) && !c.some((t) => t.cells.includes(e)))), m = u.filter((e) => !B(e).special).length;
		l = o.points * r.colonyW + p.size * r.frontierW + (t.hand.length === m && e.players[i].deckCount ? r.drawW : 0) - u.filter((e) => B(e).special).length * r.specialCost, u.some((e) => B(e).special && d === "turtle") && t.hand.length > m && (l += r.drawW * Math.min(2, e.players[i].deckCount)), l += Math.min(3, t.hand.filter((e) => !u.includes(e) && B(e).kind === d).length) * Math.sqrt(q(f.flat())) * r.frontierW;
	} else {
		u = [n.tile];
		let o = e.reefs.find((e) => (a.get(n.cell) ?? []).some((t) => e.cells.includes(t)));
		c = e.reefs.map((e) => e === o ? {
			...e,
			cells: [...e.cells, n.cell]
		} : e), s = [...e.pieces, {
			tile: n.tile,
			cell: n.cell,
			owner: i,
			faceUp: !1,
			reef: o.root
		}], l = Math.min(3, 8 - t.hand.length, e.players[i].deckCount) * r.drawW - B(n.tile).count * .15;
	}
	if (l += (ke(e, s, c, i) - o) * r.reefW, e.config.discovery) for (let t of c) {
		if (t.scored) continue;
		let n = new Set(t.cells.flatMap((e) => a.get(e) ?? []));
		for (let a of t.tokens) s.filter((e) => e.faceUp && n.has(e.cell) && B(e.tile).kind === a).map((e) => e.owner).sort((t, n) => (t - i + e.players.length) % e.players.length - (n - i + e.players.length) % e.players.length)[0] === i && (l += r.discoveryW * (e.players[i].tokens[z.indexOf(a)] ? 1 : 2));
	}
	return l;
}
function je(e = Ee) {
	return (t, n) => {
		let r = t.public, i = t.private;
		if (!i || r.players[r.turn].rid !== n.rid || !["play", "bonus"].includes(r.phase)) return null;
		let a = G(r), o = [];
		for (let e of a) for (let t of i.hand) o.push({
			type: "reef",
			tile: t,
			cell: e
		});
		if (r.phase !== "bonus" || !a.length) for (let e of Oe(r, i)) o.push({
			type: "colony",
			placements: e
		});
		if (!o.length) return null;
		if (n.difficulty === "weak") return { action: De(o) };
		let s = o[0], c = -Infinity;
		for (let t of o) {
			let n = Ae(r, i, t, e);
			n > c && (s = t, c = n);
		}
		return { action: s };
	};
}
var Me = je(), Ne = (e, t, n) => e.type === "reef" ? n("games.seagrass.hintReef", { cell: e.cell + 1 }) : e.type === "colony" ? n("games.seagrass.hintColony", {
	kind: $(n, B(e.placements[0].tile).kind),
	n: e.placements.length,
	cell: e.placements[0].cell + 1
}) : "", Pe = {
	research(e, t) {
		let n = e.data, r = e.secret, i = e.rid, a = i === t.myRid, o = t.anchor(a ? `hand:${i}` : `seat:${i}`), s = t.anchor(`deck:${i}`) ?? t.anchor(`seat:${i}`), c = l[(t.member(i)?.colorIndex ?? 0) % l.length].hex, u = [], d = [], f = t.queued ? 170 : 370;
		for (let [e, r] of n.placements.entries()) {
			let n = t.anchor(`cell:${r.cell}`);
			if (!o || !n) continue;
			let i = {
				x: n.x + n.w * .02,
				y: n.y + n.h * .01,
				w: n.w * .96,
				h: n.h * .94
			};
			t.queued || u.push(`cell:${r.cell}`);
			let a = {
				x: o.x + o.w / 2 - i.w / 2,
				y: o.y + o.h / 2 - i.h / 2,
				w: i.w * 1.12,
				h: i.h * 1.12
			};
			d.push(/* @__PURE__ */ m(S, {
				from: a,
				to: i,
				ms: f,
				delay: t.queued ? 0 : e * 22,
				children: /* @__PURE__ */ m(Q, {
					tile: r.tile,
					color: c,
					back: !r.faceUp
				})
			}, `p${r.cell}`));
		}
		for (let [e, r] of n.removed.entries()) {
			let n = t.anchor(`cell:${r.cell}`);
			if (!n) continue;
			let i = l[(t.member(r.ownerRid)?.colorIndex ?? 0) % l.length].hex;
			d.push(/* @__PURE__ */ m("div", {
				className: "sg-fx-remove",
				style: {
					position: "absolute",
					left: n.x,
					top: n.y,
					width: n.w,
					height: n.h
				},
				children: /* @__PURE__ */ m(Q, {
					tile: r.tile,
					color: i
				})
			}, `r${e}`));
		}
		for (let e = 0; e < n.drawn; e++) {
			let n = r?.cards?.[e], o = a && n !== void 0 ? `tile:${n}` : `seat:${i}`, l = t.anchor(o);
			if (!s || !l) continue;
			a && !t.queued && u.push(o);
			let p = a ? l.w : Math.min(35, l.h), h = a ? l.h : Math.min(30, l.h);
			d.push(/* @__PURE__ */ m(S, {
				from: {
					x: s.x,
					y: s.y,
					w: p,
					h
				},
				to: {
					x: l.x + (l.w - p) / 2,
					y: l.y + (l.h - h) / 2,
					w: p,
					h
				},
				ms: f,
				delay: t.queued ? 0 : 80 + e * 25,
				children: /* @__PURE__ */ m(Q, {
					tile: n ?? 0,
					color: c,
					back: !a || n === void 0
				})
			}, `d${e}`));
		}
		return d.length ? {
			ms: t.queued ? 200 : 620,
			hide: u,
			node: /* @__PURE__ */ m(p, { children: d })
		} : null;
	},
	reefScore(e, t) {
		let n = e.data, r = t.anchor(`cell:${n.root}`), i = t.anchor(`antler:${n.root}`), a = [];
		r && a.push(/* @__PURE__ */ m(C, {
			at: r,
			ms: 650
		}, "pulse")), i && a.push(/* @__PURE__ */ m("div", {
			className: "sg-fx-antler",
			style: {
				position: "absolute",
				left: i.x,
				top: i.y,
				width: i.w,
				height: i.h
			},
			children: /* @__PURE__ */ m(X, {})
		}, "antler"));
		for (let [e, r] of n.awards.entries()) {
			let i = t.anchor(`seat:${n.players[e]}`);
			r && i && a.push(/* @__PURE__ */ m(x, {
				at: i,
				ms: 600,
				children: /* @__PURE__ */ h("span", {
					style: { color: "#fff2b4" },
					children: ["+", r]
				})
			}, e));
		}
		return a.length ? {
			ms: 650,
			hide: i && !t.queued ? [`antler:${n.root}`] : [],
			node: /* @__PURE__ */ m(p, { children: a })
		} : null;
	}
};
//#endregion
//#region src/games/seagrass/game-over.tsx
function Fe({ result: e, public: t, members: n, hintCount: r, onPlayAgain: a, onBackToLobby: o }) {
	let u = t, f = c(), p = s((e) => e.locale), [g, v] = i(!0), y = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? d(t, p) : e;
	}, b = (e) => l[(n.find((t) => t.rid === u.players[e].rid)?.colorIndex ?? e) % l.length].hex, x = (e) => ({
		name: y(u.players[e].rid),
		avatar: n.find((t) => t.rid === u.players[e].rid)?.avatar ?? 0
	}), S = e.ranking.map((e) => u.players.find((t) => t.rid === e)), C = [
		["colony", "games.seagrass.colonyScore"],
		["reef", "games.seagrass.reefScore"],
		...u.config.discovery ? [["discovery", "games.seagrass.discoveryScore"], ["leftover", "games.seagrass.leftoverScore"]] : []
	];
	return /* @__PURE__ */ h("div", {
		className: "sg-screen sg-over",
		children: [
			/* @__PURE__ */ h("header", {
				className: "sg-over-title",
				children: [/* @__PURE__ */ m(X, {}), /* @__PURE__ */ m("h1", { children: f("games.seagrass.results") })]
			}),
			/* @__PURE__ */ h("div", {
				className: "sg-over-stage",
				children: [/* @__PURE__ */ m("div", {
					className: "sg-final-board",
					inert: g,
					"aria-hidden": g,
					children: /* @__PURE__ */ m(xe, {
						pub: u,
						color: b,
						identity: x
					})
				}), /* @__PURE__ */ h("section", {
					className: "sg-results",
					inert: !g,
					"aria-hidden": !g,
					style: { display: g ? void 0 : "none" },
					children: [
						/* @__PURE__ */ h("div", {
							className: "sg-results-title",
							children: [/* @__PURE__ */ m("h2", { children: f(e.winner.length === 1 ? "games.seagrass.winner" : "games.seagrass.tied", { name: e.winner.map(y).join("、") }) }), /* @__PURE__ */ m("button", {
								onClick: () => v(!1),
								"aria-label": f("games.seagrass.hideResults"),
								children: /* @__PURE__ */ m(_, { size: 23 })
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "sg-results-scroll",
							children: /* @__PURE__ */ h("table", { children: [/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
								scope: "col",
								children: f("games.seagrass.total")
							}), S.map((t) => /* @__PURE__ */ h("th", {
								scope: "col",
								className: e.winner.includes(t.rid) ? "sg-winner" : "",
								children: [
									/* @__PURE__ */ h("span", {
										className: "sg-result-player",
										style: { "--sg-player": b(u.players.indexOf(t)) },
										children: [/* @__PURE__ */ m(Z, { avatar: x(u.players.indexOf(t)).avatar }), y(t.rid)]
									}),
									/* @__PURE__ */ m("strong", { children: t.score }),
									e.autopilot?.[t.rid] !== void 0 && /* @__PURE__ */ m("small", { children: f("games.seagrass.autopilot", { n: Math.round(e.autopilot[t.rid] * 100) }) })
								]
							}, t.rid))] }) }), /* @__PURE__ */ h("tbody", { children: [C.map(([e, t]) => /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
								scope: "row",
								children: f(t)
							}), S.map((t) => /* @__PURE__ */ m("td", { children: t.breakdown?.[e] ?? 0 }, t.rid))] }, e)), /* @__PURE__ */ h("tr", {
								className: "sg-unplayed",
								children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: f("games.seagrass.unplayed")
								}), S.map((e) => /* @__PURE__ */ m("td", { children: e.unplayed }, e.rid))]
							})] })] })
						}),
						/* @__PURE__ */ m("button", {
							className: "sg-review-button",
							onClick: () => v(!1),
							children: f("games.seagrass.viewBoard")
						})
					]
				})]
			}),
			/* @__PURE__ */ h("footer", {
				className: "sg-over-controls",
				children: [
					!g && /* @__PURE__ */ m("button", {
						onClick: () => v(!0),
						children: f("games.seagrass.showResults")
					}),
					a && /* @__PURE__ */ m(w, {
						className: "sg-primary",
						label: f("games.seagrass.again"),
						confirmLabel: f("games.seagrass.confirmAgain"),
						onConfirm: a
					}),
					o && /* @__PURE__ */ m(w, {
						label: f("games.seagrass.lobby"),
						confirmLabel: f("games.seagrass.confirmLobby"),
						onConfirm: o
					}),
					!a && !o && /* @__PURE__ */ m("span", { children: f("games.seagrass.waitHost") }),
					r !== void 0 && r > 0 && /* @__PURE__ */ m("small", { children: f("games.seagrass.hints", { n: r }) })
				]
			})
		]
	});
}
//#endregion
//#region src/games/seagrass/options.tsx
function Ie({ value: e, onChange: t }) {
	let n = c(), r = A.safeParse(e), i = r.success ? r.data : A.parse({});
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ m(E, {
				title: n("games.seagrass.board"),
				children: ["front", "back"].map((e) => /* @__PURE__ */ m(T, {
					name: "seagrass-board",
					value: e,
					checked: i.board === e,
					label: n(e === "front" ? "games.seagrass.front" : "games.seagrass.back"),
					accent: "#00a8a7",
					onChange: () => t({
						...i,
						board: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(E, {
				title: n("games.seagrass.regions"),
				children: [
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ m(T, {
					name: "seagrass-region",
					value: String(e),
					checked: i.regionStart === e,
					label: n("games.seagrass.region", { n: e + 1 }),
					accent: "#00a8a7",
					onChange: () => t({
						...i,
						regionStart: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(D, {
				checked: i.special,
				label: n("games.seagrass.special"),
				hint: n("games.seagrass.specialHint"),
				accent: "#00a8a7",
				onChange: () => t({
					...i,
					special: !i.special
				})
			}),
			/* @__PURE__ */ m(D, {
				checked: i.discovery,
				label: n("games.seagrass.discovery"),
				hint: n("games.seagrass.discoveryHint"),
				accent: "#00a8a7",
				onChange: () => t({
					...i,
					discovery: !i.discovery
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/seagrass/entry.tsx
var Le = {
	definition: pe,
	View: we,
	bot: Me,
	describe: Ne,
	fx: Pe,
	OverView: Fe,
	Options: Ie,
	locales: {
		zh: {
			name: "海草",
			desc: "在海底扩展生物群落，探索并争夺珊瑚礁",
			rules: "目标：研究生物群落和珊瑚礁获得分数，终局总分最高者获胜。\n准备：\n每人有四种生物各7块普通板块（5块单生物、2块双生物）及1块特殊板块。普通板块组成自己的暗牌库，起手抽5块。特殊板块公开放在手牌旁。每局使用与人数相同的相连区域，每区域有3座礁；其中随机一座为已探索礁。鹿角数量比礁的数量少1。\n流程：\n轮到你时，选择研究群落或研究礁，然后结算本回合完成的所有礁。\n· 研究群落：从手牌连续放置1块或更多同种生物，可搭配该种特殊板块。每块必须邻接已探索礁或任意玩家任意种类的正面生物，所有新板块最后必须属于自己的同一个同种群落。不能放在岩石或未启用区域。每当生物接触未探索礁，该礁永久成为已探索礁。完成放置后，获得整个受影响群落的生物总数对应的分数，按生物只数而非板块数计算。手牌用完才从暗牌库抽1块，否则不抽。\n· 研究礁：从手牌放1块普通板块作为牌背，邻接一座已探索礁并扩大它；落点不能同时邻接另一座礁。然后从自己的暗牌库补最多3块，手牌上限7块。牌库空后仍能研究礁；没有合法扩礁格时必须研究群落。\n特殊生物：\n特殊板块不能单独使用，必须搭配至少1块手牌中的同种普通板块。\n· 特殊水母板块计为4只水母。\n· 特殊海龟板块计为2只海龟，群落行动完整结束后立即额外研究一次礁（无扩礁格时按通用规则改为研究群落，无手牌时结束回合）。\n· 特殊海星板块计为2只海星，本次放置必须恰好分属两个互不相邻的群落，两个群落都计分。\n· 特殊螃蟹板块计为1只螃蟹，必须替换另一名玩家的一块正面生物，原块永久移除，本回合所放螃蟹仍须属于同一群落。\n礁的结算：\n回合结束时，若礁已完全被正面生物、岩石或区域边界包围，则该礁完成。统计每名玩家直接邻接该礁的生物只数，同一板块只计算一次。按礁的板块总数，第一名和第二名分别获得以下分数：\n· 礁共有 1 块板块时，第一名和第二名均不得分。\n· 礁共有 2 块板块时，第一名获得 4 分，第二名获得 2 分。\n· 礁共有 3 块板块时，第一名获得 8 分，第二名获得 4 分。\n· 礁共有 4 块板块时，第一名获得 16 分，第二名获得 8 分。\n· 礁共有 5 块及以上板块时，第一名获得 24 分，第二名获得 12 分。\n· 两人局中，第二名的生物数须达到第一名的一半才得分。只有一人邻接时不发第二名分数。\n· 并列第一时，将第一名和第二名分数相加后均分给并列者，向上取整，其他人不得分。第一名独占、第二名并列时，第二名分数均分并向上取整。\n· 每座完成的礁计分后放置1个鹿角，该礁以后不能扩展或再计分。\n发现扩展：\n可在开局设置中启用，默认关闭。每座礁起始有四种生物标记各1枚，某种生物首次接触时由该生物的主人领取对应标记；扩礁也能触发。扩礁同时首次触及多名玩家的同种生物时，本作按当前行动者起顺时针优先领取。集齐四种立即消耗一套获得10分，可重复；终局剩余标记每枚1分。礁完成时移除未领取标记。\n结束：\n放完最后一个鹿角，或任一玩家回合结束时手牌为空，游戏结束。若同回合完成所有剩余礁，即使最后一座没有鹿角也全部计分；未完成礁不计分。游戏中分数保密，自己可查看，终局公开。总分相同者比较手牌、牌库和未用特殊板块的总数，较多者获胜；仍相同则共同获胜。",
			jellyfish: "水母",
			starfish: "海星",
			crab: "螃蟹",
			turtle: "海龟",
			board: "海域",
			front: "正面海域",
			back: "背面海域",
			regions: "起始区域",
			region: "区域 {{n}}",
			special: "特殊生物",
			specialHint: "关闭后使用入门模式",
			discovery: "发现扩展",
			discoveryHint: "收集四种生物的发现标记",
			colony: "研究群落",
			reef: "研究礁",
			yourTurn: "轮到你研究",
			waiting: "等待{{name}}研究",
			bonus: "海龟：额外研究礁",
			resolving: "珊瑚礁计分中",
			finished: "研究结束",
			antlers: "剩余鹿角 {{n}}",
			move: "第{{n}}回合",
			handDeck: "手牌 {{hand}} · 牌库 {{deck}}",
			ownScore: "我的分数",
			hand: "手牌",
			reserve: "特殊生物",
			deck: "暗牌库",
			tile: "{{kind}} · {{n}}只",
			specialTile: "特殊{{kind}} · {{n}}只",
			cell: "第{{n}}格",
			placeAt: "在第{{n}}格放置",
			reefInfo: "{{size}}块礁 · {{state}}",
			explored: "已探索",
			unexplored: "未探索",
			completed: "已完成",
			reefSize: "x{{n}}",
			details: "板块详情",
			closeDetails: "关闭详情",
			ownedTile: "{{name}} · {{tile}}",
			undiscovered: "尚未发现：{{kinds}}",
			specialJellyfish: "四只水母，与同种普通板块一起放置。",
			specialTurtle: "与普通海龟一起放置，随后额外研究一次礁。",
			specialStarfish: "与普通海星分成两个不相邻的群落，分别计分。",
			specialCrab: "替换对手的一块正面生物，并搭配普通螃蟹使用。",
			confirmColony: "提交 · {{n}}分",
			confirmReef: "确认扩礁",
			undo: "撤销",
			cancel: "清空预览",
			chooseTile: "选择手牌，再选择海域中的落点",
			chooseCell: "选择高亮格放置",
			addOrConfirm: "继续放置同种生物，或提交研究",
			invalidGroup: "普通生物须连成一群；特殊海星须分成两群",
			specialWithRegular: "特殊生物须搭配同种普通生物",
			reefUnavailable: "没有可以扩展的礁，请研究群落",
			zoomIn: "放大海域",
			zoomOut: "缩小海域",
			resetView: "查看整片海域",
			results: "研究成果",
			winner: "{{name}}获胜",
			tied: "{{name}}共同获胜",
			total: "总分",
			colonyScore: "群落",
			reefScore: "珊瑚礁",
			discoveryScore: "发现套组",
			leftoverScore: "剩余标记",
			unplayed: "未用板块",
			viewBoard: "回看海域",
			showResults: "查看研究成果",
			hideResults: "收起研究成果",
			again: "再来一局",
			confirmAgain: "确认重新开始？",
			lobby: "返回大厅",
			confirmLobby: "确认返回大厅？",
			waitHost: "等待主机安排下一局",
			hints: "使用建议 {{n}}次",
			autopilot: "托管 {{n}}%",
			hintColony: "放置{{kind}}，共{{n}}块，先放在第{{cell}}格",
			hintReef: "在第{{cell}}格扩展珊瑚礁",
			errTurn: "现在不能行动",
			errPlacement: "这个位置不能放置该板块",
			errMatch: "请选择手牌中同种的普通生物，特殊生物须搭配使用",
			errBonus: "请先完成海龟的额外研究礁",
			errColony: "新放的生物必须形成规定数量的群落"
		},
		en: {
			name: "Seagrass",
			desc: "Grow creature colonies and compete to research the reefs",
			rules: "Goal: score the most points by researching colonies and reefs.\nSetup:\nEach player has seven regular tiles of each creature (five singles and two doubles) and one special of each type. Shuffle your regular tiles into your own hidden supply and draw five. Keep your specials face up beside your hand. Use connected regions equal to the number of players, with three reefs per region. One random reef starts explored. There is one fewer antler than reefs.\nPlay:\nOn your turn, Research Colony or Research Reef, then score all reefs completed this turn.\n· Research Colony: play one or more matching regular tiles from your hand, optionally with the matching special. Each tile must touch an explored reef or any face-up creature tile. All newly played tiles must end in one of your colonies of that creature. Dark rocks and unused regions cannot be occupied. A reef touched by any face-up creature becomes permanently explored. Score the number of creatures in the entire affected colony, counting creatures rather than tiles. If your hand is empty, draw one tile; otherwise draw none.\n· Research Reef: place one regular tile from your hand face down beside an explored reef, expanding it. The space cannot touch another reef. Draw up to three tiles, to a hand limit of seven. You may Research Reef with an empty supply. If no reef can expand, you must Research Colony instead.\nSpecial creatures:\nA special cannot be played alone: include at least one matching regular tile from your hand.\n· The special jellyfish counts as four creatures.\n· The special turtle counts as two and gives an immediate extra Research Reef action after fully resolving the colony (use the general Research Colony fallback if no reef can expand; end the turn if you have no tiles).\n· The special starfish counts as two and requires this turn’s tiles to be split between exactly two nonadjacent colonies; score both.\n· The special crab counts as one and must replace any opponent’s face-up creature tile, permanently removing it. All your newly played crabs must still belong to one colony.\nScoring reefs:\nAt the end of a turn, a reef surrounded completely by face-up creatures, rocks or the play-area edge is completed. Count each player’s creatures directly adjacent to it, counting each tile once. First and second place score according to the reef’s total tile count:\n· With 1 tile, neither place scores points.\n· With 2 tiles, first place scores 4 points and second place scores 2 points.\n· With 3 tiles, first place scores 8 points and second place scores 4 points.\n· With 4 tiles, first place scores 16 points and second place scores 8 points.\n· With 5 or more tiles, first place scores 24 points and second place scores 12 points.\n· In two-player games, second place needs at least half as many creatures as first to score. No second-place points are awarded if only one player touches the reef.\n· Tied first: add first- and second-place points and divide among tied players, rounding up; nobody else scores. A sole first with tied second: divide second-place points among those tied, rounding up.\n· Place an antler on each completed reef after scoring it. It cannot expand or score again.\nDiscovery expansion:\nOptional, off by default. Each reef starts with one token of each creature type. The owner of the first creature of a type touching a reef claims its matching token. Reef expansion may also trigger this. If expansion first touches matching creatures belonging to multiple players simultaneously, this adaptation gives priority clockwise from the active player. Immediately spend each complete set of four different tokens to score ten points. Each leftover token scores one at the end. Unclaimed tokens are removed when a reef is completed.\nEnd:\nThe game ends when the last antler is placed or a player ends their turn with an empty hand. If all remaining reefs complete in one turn, score all of them even without an antler for the final reef. Incomplete reefs do not score. Scores are hidden during play, except your own, and revealed at the end. Most points wins; tied players compare all unplayed tiles (hand, supply and unused specials), with more winning. A further tie is a shared victory.",
			jellyfish: "Jellyfish",
			starfish: "Starfish",
			crab: "Crab",
			turtle: "Turtle",
			board: "Sea",
			front: "Front sea",
			back: "Back sea",
			regions: "Starting region",
			region: "Region {{n}}",
			special: "Special creatures",
			specialHint: "Turn off for introductory mode",
			discovery: "Discovery expansion",
			discoveryHint: "Collect four different discovery tokens",
			colony: "Research Colony",
			reef: "Research Reef",
			yourTurn: "Your research turn",
			waiting: "Waiting for {{name}}",
			bonus: "Turtle: extra reef research",
			resolving: "Scoring a reef",
			finished: "Research complete",
			antlers: "{{n}} antlers left",
			move: "Turn {{n}}",
			handDeck: "Hand {{hand}} · Supply {{deck}}",
			ownScore: "My score",
			hand: "Hand",
			reserve: "Specials",
			deck: "Hidden supply",
			tile: "{{kind}} · {{n}} creatures",
			specialTile: "Special {{kind}} · {{n}} creatures",
			cell: "Space {{n}}",
			placeAt: "Place on space {{n}}",
			reefInfo: "{{size}}-tile reef · {{state}}",
			explored: "Explored",
			unexplored: "Unexplored",
			completed: "Completed",
			reefSize: "x{{n}}",
			details: "Tile details",
			closeDetails: "Close details",
			ownedTile: "{{name}} · {{tile}}",
			undiscovered: "Undiscovered: {{kinds}}",
			specialJellyfish: "Four jellyfish. Play with matching regular tiles.",
			specialTurtle: "Play with regular turtles, then take an extra Research Reef action.",
			specialStarfish: "Split this turn’s starfish between two nonadjacent colonies; score both.",
			specialCrab: "Replace an opponent’s face-up creature tile; play with regular crabs.",
			confirmColony: "Research · {{n}} pts",
			confirmReef: "Expand reef",
			undo: "Undo",
			cancel: "Clear preview",
			chooseTile: "Choose a tile, then a space in the sea",
			chooseCell: "Choose a highlighted space",
			addOrConfirm: "Add matching creatures or submit your research",
			invalidGroup: "One colony required; special starfish requires two",
			specialWithRegular: "Include a matching regular creature",
			reefUnavailable: "No reef can expand. Research a colony.",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			resetView: "View the whole sea",
			results: "Research results",
			winner: "{{name}} wins",
			tied: "{{name}} share the victory",
			total: "Total",
			colonyScore: "Colonies",
			reefScore: "Reefs",
			discoveryScore: "Discovery sets",
			leftoverScore: "Tokens left",
			unplayed: "Unplayed tiles",
			viewBoard: "Review the sea",
			showResults: "Show results",
			hideResults: "Hide results",
			again: "Play again",
			confirmAgain: "Start a new game?",
			lobby: "Back to lobby",
			confirmLobby: "Return to lobby?",
			waitHost: "Waiting for the host",
			hints: "{{n}} hints used",
			autopilot: "Autopilot {{n}}%",
			hintColony: "Play {{n}} {{kind}} tiles, starting at space {{cell}}",
			hintReef: "Expand the reef at space {{cell}}",
			errTurn: "You cannot act now",
			errPlacement: "This tile cannot be placed there",
			errMatch: "Choose matching regular tiles from your hand; include a regular tile with a special",
			errBonus: "Complete the turtle’s extra reef research first",
			errColony: "Your new tiles must form the required number of colonies"
		}
	}
};
//#endregion
export { Le as default };
