import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { useT as s } from "@bgparty/sdk/i18n";
import { Texture as c } from "@bgparty/sdk/texture";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { IconCheck as h } from "@bgparty/sdk/icons";
import { Flash as g, Floater as _ } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as v } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as y, OptionSection as b, OptionSwitch as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/quacks/data.ts
var S = {
	w1: "w",
	w2: "w",
	w3: "w",
	o1: "o",
	o6: "o",
	g1: "g",
	g2: "g",
	g4: "g",
	b1: "b",
	b2: "b",
	b4: "b",
	r1: "r",
	r2: "r",
	r4: "r",
	y1: "y",
	y2: "y",
	y4: "y",
	p1: "p",
	k1: "k",
	t1: "t"
}, C = {
	w1: 1,
	w2: 2,
	w3: 3,
	o1: 1,
	o6: 6,
	g1: 1,
	g2: 2,
	g4: 4,
	b1: 1,
	b2: 2,
	b4: 4,
	r1: 1,
	r2: 2,
	r4: 4,
	y1: 1,
	y2: 2,
	y4: 4,
	p1: 1,
	k1: 1,
	t1: 0
};
Object.keys(S);
var w = {
	w1: "w2",
	w2: "w3",
	g1: "g2",
	g2: "g4",
	b1: "b2",
	b2: "b4",
	r1: "r2",
	r2: "r4",
	y1: "y2",
	y2: "y4"
}, ee = [
	"w1",
	"w1",
	"w1",
	"w1",
	"w2",
	"w2",
	"w3",
	"o1",
	"g1"
], T = [
	[
		0,
		0,
		!1
	],
	[
		1,
		0,
		!1
	],
	[
		2,
		0,
		!1
	],
	[
		3,
		0,
		!1
	],
	[
		4,
		0,
		!1
	],
	[
		5,
		0,
		!0
	],
	[
		6,
		1,
		!1
	],
	[
		7,
		1,
		!1
	],
	[
		8,
		1,
		!1
	],
	[
		9,
		1,
		!0
	],
	[
		10,
		2,
		!1
	],
	[
		11,
		2,
		!1
	],
	[
		12,
		2,
		!1
	],
	[
		13,
		2,
		!0
	],
	[
		14,
		3,
		!1
	],
	[
		15,
		3,
		!1
	],
	[
		15,
		3,
		!0
	],
	[
		16,
		3,
		!1
	],
	[
		16,
		4,
		!1
	],
	[
		17,
		4,
		!1
	],
	[
		17,
		4,
		!0
	],
	[
		18,
		4,
		!1
	],
	[
		18,
		5,
		!1
	],
	[
		19,
		5,
		!1
	],
	[
		19,
		5,
		!0
	],
	[
		20,
		5,
		!1
	],
	[
		20,
		6,
		!1
	],
	[
		21,
		6,
		!1
	],
	[
		21,
		6,
		!0
	],
	[
		22,
		7,
		!1
	],
	[
		22,
		7,
		!0
	],
	[
		23,
		7,
		!1
	],
	[
		23,
		8,
		!1
	],
	[
		24,
		8,
		!1
	],
	[
		24,
		8,
		!0
	],
	[
		25,
		9,
		!1
	],
	[
		25,
		9,
		!0
	],
	[
		26,
		9,
		!1
	],
	[
		26,
		10,
		!1
	],
	[
		27,
		10,
		!1
	],
	[
		27,
		10,
		!0
	],
	[
		28,
		11,
		!1
	],
	[
		28,
		11,
		!0
	],
	[
		29,
		11,
		!1
	],
	[
		29,
		12,
		!1
	],
	[
		30,
		12,
		!1
	],
	[
		30,
		12,
		!0
	],
	[
		31,
		12,
		!1
	],
	[
		31,
		13,
		!1
	],
	[
		32,
		13,
		!1
	],
	[
		32,
		13,
		!0
	],
	[
		33,
		14,
		!1
	],
	[
		33,
		14,
		!0
	],
	[
		35,
		15,
		!1
	]
], E = T.length - 2, D = [
	1,
	4,
	7,
	10,
	12,
	14,
	16,
	18,
	20,
	22,
	24,
	26,
	28,
	30,
	32,
	34,
	36,
	38,
	40,
	42,
	44,
	46,
	48
], O = {
	1: {
		o1: 3,
		g1: 4,
		g2: 8,
		g4: 14,
		b1: 5,
		b2: 10,
		b4: 19,
		r1: 6,
		r2: 10,
		r4: 16,
		y1: 8,
		y2: 12,
		y4: 18,
		p1: 9,
		k1: 10
	},
	2: {
		o1: 3,
		g1: 6,
		g2: 11,
		g4: 18,
		b1: 5,
		b2: 10,
		b4: 19,
		r1: 4,
		r2: 8,
		r4: 14,
		y1: 9,
		y2: 13,
		y4: 19,
		p1: 12,
		k1: 10
	},
	3: {
		o1: 3,
		g1: 6,
		g2: 11,
		g4: 21,
		b1: 4,
		b2: 8,
		b4: 14,
		r1: 5,
		r2: 9,
		r4: 15,
		y1: 8,
		y2: 12,
		y4: 18,
		p1: 10,
		k1: 10
	},
	4: {
		o1: 3,
		g1: 4,
		g2: 8,
		g4: 14,
		b1: 5,
		b2: 10,
		b4: 19,
		r1: 7,
		r2: 11,
		r4: 17,
		y1: 8,
		y2: 12,
		y4: 18,
		p1: 11,
		k1: 10
	},
	5: {
		o1: 3,
		o6: 22,
		g1: 4,
		g2: 8,
		g4: 14,
		b1: 5,
		b2: 10,
		b4: 18,
		r1: 7,
		r2: 11,
		r4: 17,
		y1: 8,
		y2: 12,
		y4: 18,
		p1: 16,
		k1: 9,
		t1: 10
	},
	6: {
		o1: 3,
		o6: 22,
		g1: 5,
		g2: 9,
		g4: 16,
		b1: 8,
		b2: 15,
		b4: 19,
		r1: 6,
		r2: 11,
		r4: 18,
		y1: 10,
		y2: 14,
		y4: 20,
		p1: 9,
		k1: 10,
		t1: 8
	}
}, k = {
	silverFlask: "silver",
	silverSix: "silver",
	silverReturn: "silver",
	silverBonus: "silver",
	copperUpgrade: "copper",
	copperDouble: "copper",
	copperCopy: "copper",
	copperRuby: "copper",
	goldRubyVp: "gold",
	goldCheap: "gold",
	goldColors: "gold",
	goldBag: "gold"
}, te = {
	silver: [
		"silverFlask",
		"silverSix",
		"silverReturn",
		"silverBonus"
	],
	copper: [
		"copperUpgrade",
		"copperDouble",
		"copperCopy",
		"copperRuby"
	],
	gold: [
		"goldRubyVp",
		"goldCheap",
		"goldColors",
		"goldBag"
	]
}, A = [
	0,
	3,
	3,
	3,
	3,
	4,
	7,
	10,
	14
], j = [
	{
		kind: "ruby",
		n: 1
	},
	{
		kind: "vp",
		n: 1
	},
	{
		kind: "chip",
		chip: "b2"
	},
	{
		kind: "vp",
		n: 2
	},
	{
		kind: "chip",
		chip: "k1"
	},
	{
		kind: "vp",
		n: 2
	},
	{
		kind: "ruby",
		n: 2
	},
	{
		kind: "vp",
		n: 3
	},
	{
		kind: "chip",
		chip: "p1"
	},
	{
		kind: "vp",
		n: 3
	},
	{
		kind: "chip",
		chip: "y1"
	},
	{
		kind: "vp",
		n: 4
	}
], M = j.length, N = [
	"vp1",
	"vp1",
	"vp2",
	"ruby",
	"droplet",
	"o1"
], ne = [
	{
		id: "seasoned",
		kind: "blue"
	},
	{
		id: "luckyDevil",
		kind: "blue"
	},
	{
		id: "shining",
		kind: "blue"
	},
	{
		id: "malicious",
		kind: "blue"
	},
	{
		id: "wellStirred",
		kind: "blue"
	},
	{
		id: "potFull",
		kind: "blue"
	},
	{
		id: "secondChance",
		kind: "blue"
	},
	{
		id: "strong",
		kind: "blue"
	},
	{
		id: "pumpkin",
		kind: "blue"
	},
	{
		id: "magicPotion",
		kind: "blue"
	},
	{
		id: "ratsFriends",
		kind: "purple"
	},
	{
		id: "ratInfestation",
		kind: "purple"
	},
	{
		id: "goodStart",
		kind: "purple"
	},
	{
		id: "luxury",
		kind: "purple"
	},
	{
		id: "donations",
		kind: "purple"
	},
	{
		id: "beginner",
		kind: "purple"
	},
	{
		id: "moment",
		kind: "purple"
	},
	{
		id: "justInTime",
		kind: "purple"
	},
	{
		id: "keepOne",
		kind: "purple"
	},
	{
		id: "wheel",
		kind: "purple"
	},
	{
		id: "lessIsMore",
		kind: "purple"
	},
	{
		id: "alms",
		kind: "purple"
	},
	{
		id: "potFilling",
		kind: "purple"
	},
	{
		id: "chooseWisely",
		kind: "purple"
	}
], re = {
	g1: ["o1"],
	g2: ["b1", "r1"],
	g4: ["y1", "p1"]
}, P = {
	id: "quacks",
	tier: "released",
	mechanics: ["deck-bag-building", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.quacks.name",
	descKey: "games.quacks.desc",
	rulesKey: "games.quacks.rules",
	icon: "🧪",
	iconImg: "games/quacks.webp",
	rulesUrl: { de: "https://rules.bgparty.uuppi.com/quacks/de.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4],
	playerRange: (e) => e && typeof e == "object" && e.herbWitches === !0 ? {
		min: 2,
		max: 5
	} : {
		min: 2,
		max: 4
	},
	accent: "#0d9488",
	releasedAt: "2026-09-25",
	search: {
		py: "lang zhong chuang jiang hu",
		init: "lzcjh"
	},
	hotseat: "cover"
}, F = t.enum([
	"w1",
	"w2",
	"w3",
	"o1",
	"o6",
	"g1",
	"g2",
	"g4",
	"b1",
	"b2",
	"b4",
	"r1",
	"r2",
	"r4",
	"y1",
	"y2",
	"y4",
	"p1",
	"k1",
	"t1"
]), ie = t.object({
	bookSet: t.union([
		t.literal(1),
		t.literal(2),
		t.literal(3),
		t.literal(4),
		t.literal(5),
		t.literal(6)
	]),
	fortune: t.boolean(),
	trialPot: t.boolean(),
	herbWitches: t.boolean()
}).prefault({
	bookSet: 1,
	fortune: !0,
	trialPot: !1,
	herbWitches: !1
}), ae = t.discriminatedUnion("type", [
	t.object({ type: t.literal("draw") }),
	t.object({ type: t.literal("stop") }),
	t.object({ type: t.literal("confirmDone") }),
	t.object({
		type: t.literal("placeAside"),
		index: t.int().nonnegative()
	}),
	t.object({ type: t.literal("flask") }),
	t.object({ type: t.literal("wellStirred") }),
	t.object({ type: t.literal("secondChance") }),
	t.object({ type: t.literal("strongStart") }),
	t.object({
		type: t.literal("strongPick"),
		index: t.int().nonnegative().nullable()
	}),
	t.object({
		type: t.literal("bluePick"),
		index: t.int().nonnegative().nullable()
	}),
	t.object({
		type: t.literal("dropletAssign"),
		tube: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("fRatsFriends"),
		chip: t.enum([
			"g4",
			"b4",
			"r4",
			"y4"
		]).nullable()
	}),
	t.object({
		type: t.literal("fGoodStart"),
		giveUp: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("fMoment"),
		index: t.int().nonnegative().nullable()
	}),
	t.object({
		type: t.literal("fJustInTime"),
		remove: t.boolean()
	}),
	t.object({
		type: t.literal("fKeepOne"),
		kind: t.enum([
			"k",
			"c2",
			"r"
		]),
		chip: t.enum([
			"g2",
			"b2",
			"r2",
			"y2"
		]).optional()
	}),
	t.object({
		type: t.literal("fWheel"),
		chip: t.enum([
			"w1",
			"o1",
			"g1",
			"b1",
			"r1",
			"y1"
		]).nullable()
	}),
	t.object({
		type: t.literal("fChooseWisely"),
		purple: t.boolean()
	}),
	t.object({
		type: t.literal("maliciousPick"),
		chip: t.enum([
			"g2",
			"b2",
			"r2",
			"y2"
		])
	}),
	t.object({
		type: t.literal("greenSwap"),
		choices: t.array(F.nullable())
	}),
	t.object({
		type: t.literal("greenRuby"),
		count: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("purpleTier"),
		tier: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("purpleUpgrade"),
		index: t.int().nonnegative().nullable(),
		tier: t.int().min(1).max(3)
	}),
	t.object({
		type: t.literal("bustChoice"),
		points: t.boolean()
	}),
	t.object({
		type: t.literal("buy"),
		chips: t.array(F).max(2),
		witchDouble: t.boolean().optional(),
		witchCopy: t.boolean().optional(),
		witchRuby: t.boolean().optional()
	}),
	t.object({
		type: t.literal("roundEnd"),
		pot: t.int().nonnegative(),
		tube: t.int().nonnegative(),
		refill: t.boolean(),
		witchHalf: t.boolean().optional()
	}),
	t.object({
		type: t.literal("placeAsideAny"),
		index: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("yellowRuby"),
		use: t.boolean()
	}),
	t.object({
		type: t.literal("greenStart"),
		index: t.int().nonnegative().nullable()
	}),
	t.object({
		type: t.literal("purpleBuy"),
		chips: t.array(F).max(2)
	}),
	t.object({ type: t.literal("witchFlask") }),
	t.object({ type: t.literal("witchSix") }),
	t.object({
		type: t.literal("witchSixPlace"),
		index: t.int().nonnegative()
	}),
	t.object({ type: t.literal("witchSixDone") }),
	t.object({
		type: t.literal("witchReturn"),
		idxs: t.array(t.int().nonnegative()).max(2)
	}),
	t.object({
		type: t.literal("witchUpgrade"),
		idxs: t.array(t.int().nonnegative()).max(2)
	}),
	t.object({
		type: t.literal("witchYesNo"),
		yes: t.boolean()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), oe = t.string(), se = t.object({
	chip: F,
	pos: t.int().nonnegative()
}), ce = t.enum([
	"bluePick",
	"strongPick",
	"dropletAssign",
	"fRatsFriends",
	"fGoodStart",
	"fMoment",
	"fJustInTime",
	"fKeepOne",
	"fWheel",
	"fChooseWisely",
	"malicious",
	"greenSwap",
	"greenRuby",
	"purpleTier",
	"purpleUpgrade",
	"bustChoice",
	"yellowRuby",
	"greenStart",
	"purpleBuy",
	"witchSix",
	"witchAllBonus",
	"witchGoldRuby",
	"witchColors",
	"witchBag"
]), le = t.object({
	rid: oe,
	score: t.int().nonnegative(),
	rubies: t.int().nonnegative(),
	droplet: t.int().nonnegative(),
	tube: t.int().nonnegative(),
	flaskFull: t.boolean(),
	pot: t.array(se),
	aside: t.array(F),
	asideAny: t.array(F),
	bowl: t.array(F),
	pennies: t.object({
		silver: t.boolean(),
		copper: t.boolean(),
		gold: t.boolean()
	}),
	startChip: F.nullable(),
	whiteSum: t.int().nonnegative(),
	threshold: t.int(),
	exploded: t.boolean(),
	shielded: t.boolean(),
	finishing: t.boolean(),
	done: t.boolean(),
	wellStirred: t.boolean(),
	secondChance: t.boolean(),
	strong: t.boolean(),
	drawn: t.int().nonnegative(),
	bagCount: t.int().nonnegative(),
	rats: t.int().nonnegative(),
	settle: t.object({
		scoreSpace: t.int().nonnegative(),
		money: t.int().nonnegative(),
		vp: t.int().nonnegative(),
		rubySpace: t.boolean(),
		step: t.enum([
			"b",
			"bust",
			"buy",
			"f",
			"done"
		])
	}).nullable(),
	pending: t.array(ce),
	dropletQueue: t.int().nonnegative()
}), ue = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"fortune",
		"draw",
		"settle",
		"done"
	]),
	bookSet: t.union([
		t.literal(1),
		t.literal(2),
		t.literal(3),
		t.literal(4),
		t.literal(5),
		t.literal(6)
	]),
	trialPot: t.boolean(),
	expansion: t.boolean(),
	witches: t.array(t.string()),
	fortuneOn: t.boolean(),
	fortune: t.string().nullable(),
	dieRolls: t.array(t.object({
		rid: oe,
		faces: t.array(t.string())
	})).nullable(),
	players: t.array(le)
}), de = t.object({
	bag: t.array(F),
	pending: t.array(t.object({
		kind: ce,
		options: t.array(F).optional(),
		n: t.int().optional(),
		idxs: t.array(t.int()).optional()
	}))
}), fe = 1600, pe = 2600, me = (e, t) => ({
	score: 0,
	rubies: 1,
	droplet: 0,
	tube: 0,
	flaskFull: !0,
	bag: e,
	pot: [],
	aside: [],
	whiteSum: 0,
	exploded: !1,
	shielded: !1,
	blueShield: 0,
	doubleNext: !1,
	drawn: 0,
	finishing: !1,
	done: !1,
	wellStirred: !1,
	secondChance: !1,
	strong: !1,
	dropletQueue: 0,
	rats: 0,
	pending: [],
	settleStep: null,
	scoreSpace: 0,
	money: 0,
	vp: 0,
	rubySpace: !1,
	spent: 0,
	lastFull: 0,
	pennies: {
		silver: t,
		copper: t,
		gold: t
	},
	asideAny: [],
	bowl: [],
	startChip: null,
	witchBonus: !1
});
function he(t, n, r) {
	let i = t.herbWitches, a = {
		players: n,
		seed: r,
		rngCursor: 0,
		bookSet: i ? t.bookSet : Math.min(t.bookSet, 4),
		fortuneOn: t.fortune,
		trialPot: t.trialPot,
		expansion: i,
		witches: [],
		dieDeferred: !1,
		round: 1,
		phase: "fortune",
		fortuneDeck: [],
		fortune: null,
		ps: Object.fromEntries(n.map((e) => [e, me([...ee], i)])),
		dieRolls: null
	};
	if (i) for (let t of [
		"silver",
		"copper",
		"gold"
	]) {
		let n = te[t];
		a.witches.push(n[e(r, a.rngCursor, n.length)]), a.rngCursor += 1;
	}
	if (a.fortuneOn) {
		let t = ne.map((e) => e.id);
		for (let n = t.length - 1; n > 0; --n) {
			let i = e(r, a.rngCursor, n + 1);
			a.rngCursor += 1, [t[n], t[i]] = [t[i], t[n]];
		}
		a.fortuneDeck = t;
	}
	return {
		state: a,
		fx: [{
			kind: "roundStart",
			data: { round: 1 }
		}]
	};
}
var ge = (e, t) => e.filter((e) => S[e] === t).length, I = (e, t) => ge(e.pot.map((e) => e.chip), t), L = (e, t) => ge(e.bag, t) + I(e, t), _e = (e) => e.droplet + e.rats, R = (e) => e.pot.length > 0 ? e.pot[e.pot.length - 1].pos : _e(e), z = (e) => e.pot.length > 0 ? e.pot[e.pot.length - 1] : null;
function ve(e, t) {
	let n = 7;
	if (e.bookSet === 3) {
		let e = I(t, "y");
		e >= 1 && (n += 1), e >= 3 && (n += 1);
	}
	return e.fortune === "luxury" && (n += 2), n;
}
function B(t, n, r) {
	let i = [];
	for (let a = 0; a < r && n.bag.length > 0; a += 1) {
		let r = e(t.seed, t.rngCursor, n.bag.length);
		t.rngCursor += 1, i.push(n.bag.splice(r, 1)[0]);
	}
	return i;
}
function V(e, t, n) {
	n <= 0 || (e.trialPot ? (t.dropletQueue += n, t.pending.some((e) => e.kind === "dropletAssign") || t.pending.push({ kind: "dropletAssign" })) : t.droplet += n);
}
function ye(e, t, n) {
	n === "vp1" ? t.score += 1 : n === "vp2" ? t.score += 2 : n === "ruby" ? t.rubies += 1 : n === "droplet" ? V(e, t, 1) : t.bag.push("o1");
}
function be(t, n) {
	let r = N[e(t.seed, t.rngCursor, N.length)];
	return t.rngCursor += 1, ye(t, n, r), r;
}
function xe(e) {
	let t = j[e.tube - 1];
	t.kind === "ruby" ? e.rubies += t.n : t.kind === "vp" ? e.score += t.n : e.bag.push(t.chip);
}
function Se(e, t) {
	t.exploded = !0, t.blueShield > 0 && (t.shielded = !0), t.finishing = !0;
	let n = e.witches.includes("silverFlask") && t.pennies.silver && t.flaskFull;
	t.aside.length === 0 && t.asideAny.length === 0 && !n && (t.done = !0);
}
function Ce(e, t, n, r, i, a, o = !1) {
	i && t.blueShield > 0 && --t.blueShield;
	let s = S[n];
	if (!o && s === "r" && e.bookSet === 2) {
		t.aside.push(n), t.drawn += 1, r.push({
			kind: "aside",
			rid: a,
			data: { chip: n }
		});
		return;
	}
	if (e.expansion && R(t) >= E) {
		t.bowl.push(n), t.drawn += 1;
		let i = !1;
		s === "w" && (t.whiteSum += C[n], !o && t.whiteSum > ve(e, t) && (Se(e, t), i = !0)), r.push({
			kind: "bowl",
			rid: a,
			data: {
				chip: n,
				exploded: i
			}
		});
		return;
	}
	let c = n;
	if (n === "t1" && e.bookSet === 5) {
		let e = [...t.pot].reverse().find((e) => S[e.chip] !== "w" && S[e.chip] !== "t");
		e && (c = e.chip);
	}
	s = S[c];
	let l;
	if (l = n === "t1" ? e.bookSet === 5 ? c === "t1" ? 1 : C[c] : Math.min(t.rats + 1, 4) : C[n], t.doubleNext &&= (l *= 2, !1), s === "r") {
		if (e.bookSet === 1) {
			let e = I(t, "o");
			e >= 3 ? l += 2 : e >= 1 && (l += 1);
		} else if (e.bookSet === 3) {
			let e = z(t);
			e && S[e.chip] === "w" && (l += C[e.chip]);
		} else e.bookSet === 6 && (l = Math.max(C[c], ...t.pot.filter((e) => S[e.chip] === "r").map((e) => C[e.chip])));
	}
	if (c === "w1" && e.bookSet === 4 && I(t, "r") >= 1 && (l = 2), s === "y" && e.bookSet === 4) {
		let e = I(t, "y") + 1;
		e <= 3 && (l += e);
	}
	s === "o" && e.fortune === "pumpkin" && (l += 1);
	let u = Math.min(R(t) + l, E), d = e.expansion && u >= E;
	if (!o && s === "y" && e.bookSet === 2 && !d && (t.doubleNext = !0), t.pot.push({
		chip: n,
		pos: u
	}), t.drawn += 1, S[n] === "w" && (t.whiteSum += C[n], !o && t.whiteSum > ve(e, t))) {
		Se(e, t), r.push({
			kind: "draw",
			rid: a,
			data: {
				chip: n,
				pos: u,
				exploded: !0
			}
		});
		return;
	}
	if (T[u][2] && (e.fortune === "luckyDevil" && (t.score += 2), e.fortune === "shining" && (t.rubies += 1), s === "b" && e.bookSet === 3 && (t.rubies += 1), s === "b" && e.bookSet === 4 && (t.score += C[c])), o || d) {
		if (s === "b" && e.bookSet === 5 && !o) {
			let e = t.pot.slice(0, -1).slice(-C[c]);
			t.rubies += e.filter((e) => e.chip === "w1").length;
		}
		s === "b" && e.bookSet === 6 && !o && I(t, "o") >= C[c] && (t.score += C[c]), r.push({
			kind: "draw",
			rid: a,
			data: {
				chip: n,
				pos: u,
				exploded: !1
			}
		});
		return;
	}
	if (s === "b" && e.bookSet === 1) {
		let n = B(e, t, C[c]);
		n.length > 0 && t.pending.push({
			kind: "bluePick",
			options: n
		});
	}
	if (s === "b" && e.bookSet === 2 && (t.blueShield = C[c]), s === "b" && e.bookSet === 5) {
		let e = t.pot.slice(0, -1).slice(-C[c]);
		t.rubies += e.filter((e) => e.chip === "w1").length;
	}
	if (s === "b" && e.bookSet === 6 && I(t, "o") >= C[c] && (t.score += C[c]), s === "r" && e.bookSet === 5) {
		let n = B(e, t, 1);
		n.length > 0 && (t.asideAny.push(n[0]), S[n[0]] === "w" && (t.whiteSum += C[n[0]], t.whiteSum > ve(e, t) && Se(e, t)), r.push({
			kind: "asideAny",
			rid: a,
			data: { chip: n[0] }
		}));
	}
	if (s === "y" && e.bookSet === 5 && t.rubies >= 1 && t.pending.push({ kind: "yellowRuby" }), s === "y" && e.bookSet === 6) {
		let n = B(e, t, 1);
		if (n.length > 0) {
			let e = n[0] === "t1" ? 1 : C[n[0]];
			t.pot[t.pot.length - 1].pos = Math.min(u + e, E), t.bag.push(n[0]), r.push({
				kind: "yellowDraw",
				rid: a,
				data: {
					chip: n[0],
					extra: e
				}
			});
		}
	}
	r.push({
		kind: "draw",
		rid: a,
		data: {
			chip: n,
			pos: u,
			exploded: !1
		}
	});
}
function we(e, t) {
	let n = 0;
	for (let r = 0; r * 50 < t; r += 1) for (let i of D) {
		let a = i + r * 50;
		a >= e && a < t && (n += 1);
	}
	return n;
}
function Te(e) {
	if (e.round < 2) return;
	let t = Math.max(...e.players.map((t) => e.ps[t].score));
	for (let n of e.players) {
		let r = e.ps[n];
		if (r.score >= t) continue;
		let i = we(r.score, t);
		e.fortune === "ratInfestation" && (i *= 2), r.rats = i;
	}
}
function Ee(e, t) {
	if (e.fortuneOn && (e.fortune = e.fortuneDeck.pop() ?? null, e.fortune && t.push({
		kind: "fortune",
		data: { card: e.fortune }
	}), e.fortune === "wellStirred" || e.fortune === "secondChance" || e.fortune === "strong")) for (let t of e.players) e.fortune === "wellStirred" ? e.ps[t].wellStirred = !0 : e.fortune === "secondChance" ? e.ps[t].secondChance = !0 : e.ps[t].strong = !0;
	Te(e);
	let n = e.fortune;
	if (n && ne.find((e) => e.id === n)?.kind === "purple") {
		if (n === "ratsFriends") for (let t of e.players) e.ps[t].pending.push({ kind: "fRatsFriends" });
		else if (n === "goodStart") for (let t of e.players) e.ps[t].rats > 0 && e.ps[t].pending.push({
			kind: "fGoodStart",
			rats: e.ps[t].rats
		});
		else if (n === "donations") for (let n of e.players) {
			let r = be(e, e.ps[n]);
			t.push({
				kind: "die",
				rid: n,
				data: { faces: [r] }
			});
		}
		else if (n === "beginner") {
			let t = Math.min(...e.players.map((t) => e.ps[t].score));
			for (let n of e.players) e.ps[n].score === t && e.ps[n].bag.push("g1");
		} else if (n === "moment") for (let t of e.players) {
			let n = B(e, e.ps[t], 4);
			n.length > 0 && e.ps[t].pending.push({
				kind: "fMoment",
				options: n
			});
		}
		else if (n === "justInTime") for (let t of e.players) e.ps[t].pending.push({ kind: "fJustInTime" });
		else if (n === "keepOne") for (let t of e.players) e.ps[t].pending.push({ kind: "fKeepOne" });
		else if (n === "wheel") for (let t of e.players) e.ps[t].rubies >= 1 && e.ps[t].pending.push({ kind: "fWheel" });
		else if (n === "lessIsMore") {
			let t = /* @__PURE__ */ new Map();
			for (let n of e.players) {
				let r = e.ps[n], i = B(e, r, 5);
				t.set(n, {
					chips: i,
					sum: i.reduce((e, t) => e + C[t], 0)
				});
			}
			let n = Math.min(...[...t.values()].map((e) => e.sum));
			for (let r of e.players) {
				let i = e.ps[r], a = t.get(r);
				i.bag.push(...a.chips), a.sum === n ? i.bag.push("b2") : i.rubies += 1;
			}
		} else if (n === "alms") {
			let t = Math.min(...e.players.map((t) => e.ps[t].rubies));
			for (let n of e.players) e.ps[n].rubies === t && (e.ps[n].rubies += 1);
		} else if (n === "potFilling") for (let t of e.players) V(e, e.ps[t], 1);
		else if (n === "chooseWisely") for (let t of e.players) e.ps[t].pending.push({ kind: "fChooseWisely" });
	}
}
function De(e, t) {
	let n = e.players.filter((t) => !e.ps[t].exploded || e.ps[t].witchBonus);
	if (n.length === 0) return;
	let r = Math.max(...n.map((t) => e.ps[t].money)), i = n.filter((t) => e.ps[t].money === r), a = Math.max(...i.map((t) => e.ps[t].scoreSpace)), o = i.filter((t) => e.ps[t].scoreSpace === a);
	for (let n of o) {
		let r = e.fortune === "potFull" ? 2 : 1, i = [];
		for (let t = 0; t < r; t += 1) i.push(be(e, e.ps[n]));
		e.dieRolls?.push({
			rid: n,
			faces: i
		}), t.push({
			kind: "die",
			rid: n,
			data: { faces: i }
		});
	}
}
function Oe(e, t) {
	e.dieDeferred && e.phase === "settle" && (e.players.some((t) => e.ps[t].settleStep === "b") || (e.dieDeferred = !1, De(e, t)));
}
function ke(e, t) {
	e.phase = "settle", e.dieRolls = [];
	for (let t of e.players) {
		let n = e.ps[t];
		if (n.settleStep = "b", n.spent = 0, e.bookSet === 3 && n.whiteSum === 7 && n.pot.length > 0) {
			let e = n.pot.reduce((e, t) => e + (S[t.chip] === "g" ? C[t.chip] : 0), 0);
			e > 0 && (n.pot[n.pot.length - 1].pos = Math.min(n.pot[n.pot.length - 1].pos + e, E));
		}
		n.lastFull = R(n);
		let r = Math.min(R(n) + 1, T.length - 1);
		n.scoreSpace = r, n.money = T[r][0], n.vp = T[r][1], n.bowl.length > 0 && (n.vp += Math.floor(n.bowl.reduce((e, t) => e + C[t], 0) / 2)), n.rubySpace = T[r][2];
	}
	if (e.dieDeferred = e.witches.includes("silverBonus"), e.dieDeferred || De(e, t), e.bookSet === 5) {
		let t = [];
		for (let n of e.players) for (let r of e.ps[n].pot) S[r.chip] === "k" && t.push({
			pos: r.pos,
			rid: n
		});
		if (t.length > 0) {
			let n = Math.max(...t.map((e) => e.pos));
			for (let r of t.filter((e) => e.pos === n)) V(e, e.ps[r.rid], 1);
			let r = t.filter((e) => e.pos < n);
			if (r.length > 0) {
				let t = Math.max(...r.map((e) => e.pos));
				for (let n of r.filter((e) => e.pos === t)) e.ps[n.rid].rubies += 1;
			}
		}
	}
	for (let n of e.players) {
		let r = e.ps[n], i = e.players.indexOf(n), a = e.players.length;
		e.witches.includes("silverBonus") && r.exploded && !r.shielded && r.pennies.silver && r.pending.push({ kind: "witchAllBonus" }), e.witches.includes("goldColors") && r.pennies.gold && r.pot.some((e) => S[e.chip] !== "w") && r.pending.push({ kind: "witchColors" }), e.witches.includes("goldBag") && r.pennies.gold && r.bag.some((e) => S[e] !== "w" && (e === "p1" || e === "t1" || C[e] >= 2)) && r.pending.push({ kind: "witchBag" }), r.rubySpace && (e.witches.includes("goldRubyVp") && r.pennies.gold ? r.pending.push({ kind: "witchGoldRuby" }) : r.rubies += 1), e.fortune === "seasoned" && r.whiteSum === 7 && V(e, r, 1);
		let o = L(r, "k");
		if (e.bookSet <= 4 && o > 0) {
			if (a === 2) {
				let t = L(e.ps[e.players[1 - i]], "k");
				o >= t && V(e, r, 1), o > t && (r.rubies += 1);
			} else {
				let t = L(e.ps[e.players[(i + 1) % a]], "k"), n = L(e.ps[e.players[(i - 1 + a) % a]], "k");
				(o > t || o > n) && V(e, r, 1), o > t && o > n && (r.rubies += 1);
			}
		}
		if (e.bookSet === 6) {
			let t = e.ps[e.players[(i + 1) % a]];
			r.rubies += t.pot.filter((e) => S[e.chip] === "k").length;
			let n = [];
			for (let e = t.pot.length - 1; e >= 0 && n.length < 2; --e) n.push(e);
			n.some((e) => S[t.pot[e].chip] === "k") && (t.rubies += 1);
		}
		let s = [];
		for (let e = r.pot.length - 1; e >= 0 && s.length < 2; --e) s.push(e);
		let c = s.filter((e) => S[r.pot[e].chip] === "g");
		if (e.bookSet === 1) r.rubies += c.length;
		else if (e.bookSet === 2 && c.length > 0) r.pending.push({
			kind: "greenSwap",
			idxs: c
		});
		else if (e.bookSet === 4 && c.length > 0) r.pending.push({
			kind: "greenRuby",
			max: Math.min(c.length, r.rubies)
		});
		else if (e.bookSet === 5 && c.length > 0) {
			let i = e.fortune === "potFull" ? 2 : 1, a = [];
			for (let t = 0; t < c.length * i; t += 1) a.push(be(e, r));
			e.dieRolls.push({
				rid: n,
				faces: a
			}), t.push({
				kind: "die",
				rid: n,
				data: { faces: a }
			});
		} else if (e.bookSet === 6 && c.length > 0) {
			let e = Math.max(...c.map((e) => C[r.pot[e].chip]));
			r.pending.push({
				kind: "greenStart",
				max: e
			});
		}
		let l = L(r, "p");
		if (e.bookSet === 1) l === 1 ? r.score += 1 : l === 2 ? (r.score += 1, r.rubies += 1) : l >= 3 && (r.score += 2, V(e, r, 1));
		else if (e.bookSet === 2) l >= 1 && r.pending.push({
			kind: "purpleTier",
			count: Math.min(3, l)
		});
		else if (e.bookSet === 3) for (let e of r.pot) S[e.chip] === "p" && (r.score += e.pos >= 30 ? 3 : e.pos >= 20 ? 2 : +(e.pos >= 10));
		else if (e.bookSet === 4) l >= 1 && r.pending.push({
			kind: "purpleUpgrade",
			tier: Math.min(3, l)
		});
		else if (e.bookSet === 5) for (let e = 0; e < r.pot.length - 1; e += 1) S[r.pot[e].chip] === "p" && (r.score += C[r.pot[e + 1].chip]);
		else if (e.bookSet === 6) {
			let e = r.pot.filter((e) => S[e.chip] === "p").reduce((e, t) => e + T[t.pos][1], 0);
			e > 0 && r.pending.push({
				kind: "purpleBuy",
				budget: e
			});
		}
		if ((!r.exploded || r.shielded) && (r.score += r.vp), e.fortune === "malicious" && r.exploded) {
			let t = e.players[(e.players.indexOf(n) + 1) % e.players.length];
			e.ps[t].pending.push({ kind: "malicious" });
		}
	}
	je(e), Oe(e, t), e.players.every((t) => e.ps[t].settleStep === "done") && t.push({ kind: "settleDone" });
}
function Ae(e) {
	let t = 0;
	for (; e.pending.length === 0 && e.settleStep === "b" && t < 4;) t += 1, e.exploded && !e.shielded ? (e.settleStep = "bust", e.pending.push({ kind: "bustChoice" })) : e.settleStep = "buy";
}
function je(e) {
	for (let t of e.players) Ae(e.ps[t]);
}
function Me(e, t) {
	e.round === 9 && (t.score += Math.floor(Math.max(0, t.money - t.spent) / 5), t.score += Math.floor(t.rubies / 2), t.rubies %= 2, e.expansion && (t.score += 2 * (Number(t.pennies.silver) + Number(t.pennies.copper) + Number(t.pennies.gold))));
}
function Ne(e, t) {
	if (e.round >= 9) {
		e.phase = "done";
		return;
	}
	e.round += 1;
	for (let t of e.players) {
		let n = e.ps[t], r = n.pot.map((e) => e.chip);
		if (n.startChip) {
			let e = r.indexOf(n.startChip);
			e >= 0 && r.splice(e, 1);
		}
		n.bag.push(...r, ...n.aside, ...n.asideAny, ...n.bowl), n.pot = [], n.aside = [], n.asideAny = [], n.bowl = [], n.whiteSum = 0, n.exploded = !1, n.shielded = !1, n.blueShield = 0, n.doubleNext = !1, n.drawn = 0, n.finishing = !1, n.done = !1, n.wellStirred = !1, n.secondChance = !1, n.strong = !1, n.rats = 0, n.pending = [], n.settleStep = null, n.spent = 0, n.witchBonus = !1, e.round === 6 && n.bag.push("w1");
	}
	e.fortune = null, e.dieRolls = null, e.dieDeferred = !1, e.phase = "fortune", t.push({
		kind: "roundStart",
		data: { round: e.round }
	});
}
function Pe(e, t) {
	e.phase === "draw" && e.players.every((t) => e.ps[t].done) && ke(e, t);
}
var H = (e, t) => {
	let n = e.pending.findIndex((e) => e.kind === t);
	return n < 0 ? null : e.pending.splice(n, 1)[0];
};
function Fe(e, t, n, r, i, a, o = !1) {
	if (r !== null) {
		let s = n[r];
		t.bag.push(...n.filter((e, t) => t !== r)), Ce(e, t, s, i, !0, a, o);
	} else t.bag.push(...n);
}
function Ie(e, t) {
	for (let n of e.players) {
		let r = e.ps[n];
		if (!r.startChip) continue;
		let i = r.startChip;
		r.startChip = null, Ce(e, r, i, t, !0, n);
	}
}
function Le(e, t) {
	let n = O[e.bookSet][t];
	return n === void 0 ? e.expansion && t === "o6" ? 22 : void 0 : n;
}
function Re(e, t, n, r) {
	for (let i of r) if (e.bookSet === 6 && i === "k1") {
		let r = e.players[(e.players.indexOf(n) + 1) % e.players.length];
		e.ps[r].bag.push(i), V(e, t, 1);
	} else t.bag.push(i);
}
function ze(e, t, n) {
	if (new Set(t.map((e) => S[e])).size !== t.length) return { code: "games.quacks.errSameColor" };
	let r = 0;
	for (let n of t) {
		let t = Le(e, n);
		if (t === void 0 || S[n] === "y" && e.round < 2 || S[n] === "p" && e.round < 3) return { code: "games.quacks.errBadChip" };
		r += t;
	}
	return r > n ? { code: "games.quacks.errTooExpensive" } : r;
}
function Be(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "fortune") {
			let t = structuredClone(e), n = [];
			return t.fortuneOn ? t.fortune === null ? (Ee(t, n), {
				state: t,
				fx: n
			}) : (t.players.every((e) => t.ps[e].pending.length === 0) && (t.phase = "draw", Ie(t, n), n.push({ kind: "drawStart" })), {
				state: t,
				fx: n
			}) : (Te(t), t.phase = "draw", Ie(t, n), n.push({ kind: "drawStart" }), {
				state: t,
				fx: n
			});
		}
		if (e.phase === "settle" && e.players.every((t) => e.ps[t].settleStep === "done")) {
			let t = structuredClone(e), n = [];
			return Ne(t, n), {
				state: t,
				fx: n
			};
		}
		return {
			state: e,
			fx: []
		};
	}
	let r = e.ps[n.by];
	if (!r) return { code: "games.quacks.errNotYourTurn" };
	let i = r.pending[0];
	if (t.type === "bluePick" || t.type === "strongPick") {
		if (e.phase !== "draw") return { code: "games.quacks.errBadAction" };
		let r = t.type === "bluePick" ? "bluePick" : "strongPick";
		if (!i || i.kind !== r) return { code: "games.quacks.errBadAction" };
		let a = i.options;
		if (t.index !== null && (t.index < 0 || t.index >= a.length)) return { code: "games.quacks.errBadChoice" };
		let o = structuredClone(e), s = [];
		return H(o.ps[n.by], r), Fe(o, o.ps[n.by], a, t.index, s, n.by, r === "strongPick"), Pe(o, s), {
			state: o,
			fx: s
		};
	}
	if (t.type === "witchSixPlace" || t.type === "witchSixDone") {
		if (e.phase !== "draw" || !i || i.kind !== "witchSix") return { code: "games.quacks.errBadAction" };
		if (t.type === "witchSixPlace" && t.index >= i.options.length) return { code: "games.quacks.errBadChoice" };
		let r = structuredClone(e), a = r.ps[n.by], o = [], s = a.pending[0];
		if (t.type === "witchSixPlace") {
			let e = s.options[t.index];
			s.options.splice(t.index, 1), s.options.length === 0 && H(a, "witchSix"), Ce(r, a, e, o, !0, n.by);
		} else H(a, "witchSix"), a.bag.push(...s.options), o.push({
			kind: "witchSixDone",
			rid: n.by
		});
		return Pe(r, o), {
			state: r,
			fx: o
		};
	}
	if (t.type === "yellowRuby") {
		if (e.phase !== "draw" || !i || i.kind !== "yellowRuby") return { code: "games.quacks.errBadAction" };
		if (t.use && r.rubies < 1) return { code: "games.quacks.errNoRubies" };
		let a = structuredClone(e), o = a.ps[n.by], s = [];
		if (H(o, "yellowRuby"), t.use) {
			--o.rubies;
			let e = z(o);
			e && (e.pos = Math.min(e.pos + 3, E), s.push({
				kind: "yellowBoost",
				rid: n.by,
				data: { pos: e.pos }
			}));
		}
		return Pe(a, s), {
			state: a,
			fx: s
		};
	}
	if (t.type === "dropletAssign") {
		if (!i || i.kind !== "dropletAssign") return { code: "games.quacks.errBadAction" };
		if (t.tube > r.dropletQueue) return { code: "games.quacks.errBadChoice" };
		let a = structuredClone(e), o = a.ps[n.by];
		H(o, "dropletAssign");
		let s = t.tube, c = o.dropletQueue - t.tube;
		o.dropletQueue = 0;
		let l = M - o.tube;
		s > l && (c += s - l, s = l), o.droplet += c;
		for (let e = 0; e < s; e += 1) o.tube += 1, xe(o);
		let u = [{
			kind: "droplet",
			rid: n.by,
			data: {
				pot: c,
				tube: s
			}
		}];
		return a.phase === "settle" && (Ae(o), Oe(a, u), a.players.every((e) => a.ps[e].settleStep === "done") && u.push({ kind: "settleDone" })), {
			state: a,
			fx: u
		};
	}
	if (t.type.startsWith("f") && t.type !== "flask") {
		if (!i) return { code: "games.quacks.errBadAction" };
		let r = structuredClone(e), a = r.ps[n.by], o = [];
		if (t.type === "fRatsFriends") {
			if (i.kind !== "fRatsFriends") return { code: "games.quacks.errBadAction" };
			H(a, "fRatsFriends"), t.chip === null ? a.score += a.rats : a.bag.push(t.chip);
		} else if (t.type === "fGoodStart") {
			if (i.kind !== "fGoodStart") return { code: "games.quacks.errBadAction" };
			if (t.giveUp > Math.min(3, a.rats)) return { code: "games.quacks.errBadChoice" };
			H(a, "fGoodStart"), a.rats -= t.giveUp, a.rubies += t.giveUp;
		} else if (t.type === "fMoment") {
			if (i.kind !== "fMoment") return { code: "games.quacks.errBadAction" };
			let e = i.options;
			if (t.index !== null && (t.index < 0 || t.index >= e.length)) return { code: "games.quacks.errBadChoice" };
			if (H(a, "fMoment"), t.index !== null) {
				let n = w[e[t.index]];
				if (!n) return { code: "games.quacks.errBadChip" };
				a.bag.push(...e.filter((e, n) => n !== t.index), n);
			} else a.bag.push(...e), e.every((e) => !w[e]) && a.bag.push("g1");
		} else if (t.type === "fJustInTime") {
			if (i.kind !== "fJustInTime") return { code: "games.quacks.errBadAction" };
			if (H(a, "fJustInTime"), t.remove) {
				let e = a.bag.indexOf("w1");
				if (e < 0) return { code: "games.quacks.errBadChip" };
				a.bag.splice(e, 1);
			} else a.score += 4;
		} else if (t.type === "fKeepOne") {
			if (i.kind !== "fKeepOne") return { code: "games.quacks.errBadAction" };
			if (H(a, "fKeepOne"), t.kind === "k") {
				if (r.bookSet === 6) {
					let e = r.players[(r.players.indexOf(n.by) + 1) % r.players.length];
					r.ps[e].bag.push("k1"), V(r, a, 1);
				} else a.bag.push("k1");
			} else if (t.kind === "r") a.rubies += 3;
			else {
				if (!t.chip) return { code: "games.quacks.errBadChip" };
				a.bag.push(t.chip);
			}
		} else if (t.type === "fWheel") {
			if (i.kind !== "fWheel") return { code: "games.quacks.errBadAction" };
			if (H(a, "fWheel"), t.chip !== null) {
				if (a.rubies < 1) return { code: "games.quacks.errNoRubies" };
				--a.rubies, a.bag.push(t.chip);
			}
		} else if (t.type === "fChooseWisely") {
			if (i.kind !== "fChooseWisely") return { code: "games.quacks.errBadAction" };
			H(a, "fChooseWisely"), t.purple ? a.bag.push("p1") : V(r, a, 2);
		} else return { code: "games.quacks.errBadAction" };
		return {
			state: r,
			fx: o
		};
	}
	if (t.type === "draw" || t.type === "stop" || t.type === "confirmDone" || t.type === "placeAside" || t.type === "placeAsideAny" || t.type === "flask" || t.type === "witchFlask" || t.type === "witchSix" || t.type === "witchReturn" || t.type === "wellStirred" || t.type === "secondChance" || t.type === "strongStart") {
		if (e.phase !== "draw" || r.done || r.pending.length > 0) return { code: "games.quacks.errBadAction" };
		let i = structuredClone(e), a = i.ps[n.by], o = [];
		if (t.type === "draw") {
			if (a.finishing) return { code: "games.quacks.errBadAction" };
			if (a.bag.length === 0) a.finishing = !0, a.aside.length === 0 && a.asideAny.length === 0 && (a.done = !0);
			else {
				let e = B(i, a, 1)[0];
				Ce(i, a, e, o, !0, n.by);
			}
		} else if (t.type === "stop") a.finishing = !0, a.aside.length === 0 && a.asideAny.length === 0 && (a.done = !0), o.push({
			kind: "stop",
			rid: n.by
		});
		else if (t.type === "confirmDone") a.done = !0;
		else if (t.type === "placeAside") {
			if (t.index >= a.aside.length) return { code: "games.quacks.errBadChoice" };
			let e = a.aside.splice(t.index, 1)[0], r = Math.min(R(a) + C[e], E);
			a.pot.push({
				chip: e,
				pos: r
			}), a.finishing && a.aside.length === 0 && a.asideAny.length === 0 && (a.done = !0), o.push({
				kind: "draw",
				rid: n.by,
				data: {
					chip: e,
					pos: r,
					exploded: !1
				}
			});
		} else if (t.type === "placeAsideAny") {
			if (t.index >= a.asideAny.length) return { code: "games.quacks.errBadChoice" };
			let e = a.asideAny.splice(t.index, 1)[0];
			if (i.expansion && R(a) >= E) a.bowl.push(e), o.push({
				kind: "bowl",
				rid: n.by,
				data: {
					chip: e,
					exploded: !1
				}
			});
			else {
				let t = Math.min(R(a) + C[e], E);
				a.pot.push({
					chip: e,
					pos: t
				}), o.push({
					kind: "draw",
					rid: n.by,
					data: {
						chip: e,
						pos: t,
						exploded: !1
					}
				});
			}
			a.finishing && a.aside.length === 0 && a.asideAny.length === 0 && (a.done = !0);
		} else if (t.type === "flask") {
			if (!a.flaskFull || a.finishing) return { code: "games.quacks.errBadAction" };
			let e = z(a);
			if (!e || S[e.chip] !== "w") return { code: "games.quacks.errBadAction" };
			a.pot.pop(), a.whiteSum -= C[e.chip], a.bag.push(e.chip), a.flaskFull = !1, o.push({
				kind: "flask",
				rid: n.by,
				data: { chip: e.chip }
			});
		} else if (t.type === "witchFlask") {
			if (!i.witches.includes("silverFlask") || !a.pennies.silver || !a.exploded || !a.flaskFull) return { code: "games.quacks.errBadAction" };
			let e = z(a);
			if (e && S[e.chip] === "w") a.pot.pop(), a.whiteSum -= C[e.chip], a.bag.push(e.chip), o.push({
				kind: "flask",
				rid: n.by,
				data: { chip: e.chip }
			});
			else if (a.asideAny.length > 0 && S[a.asideAny[a.asideAny.length - 1]] === "w") {
				let e = a.asideAny.pop();
				a.whiteSum -= C[e], a.bag.push(e), o.push({
					kind: "flask",
					rid: n.by,
					data: { chip: e }
				});
			} else if (a.bowl.length > 0 && S[a.bowl[a.bowl.length - 1]] === "w") {
				let e = a.bowl.pop();
				a.whiteSum -= C[e], a.bag.push(e), o.push({
					kind: "flask",
					rid: n.by,
					data: { chip: e }
				});
			} else return { code: "games.quacks.errBadAction" };
			a.flaskFull = !1, a.pennies.silver = !1, a.exploded = !1, a.finishing = !1, a.done = !1;
		} else if (t.type === "witchSix") {
			if (!i.witches.includes("silverSix") || !a.pennies.silver || a.finishing || a.exploded || a.bag.length === 0) return { code: "games.quacks.errBadAction" };
			let e = B(i, a, 6);
			if (e.length === 0) return { code: "games.quacks.errBadAction" };
			a.pennies.silver = !1, a.pending.push({
				kind: "witchSix",
				options: e
			});
		} else if (t.type === "witchReturn") {
			if (!i.witches.includes("silverReturn") || !a.pennies.silver || a.exploded || a.finishing) return { code: "games.quacks.errBadAction" };
			if (t.idxs.length === 0) return { code: "games.quacks.errBadChoice" };
			let e = [...new Set(t.idxs)].sort((e, t) => t - e);
			for (let t of e) if (t >= a.pot.length || S[a.pot[t].chip] !== "w") return { code: "games.quacks.errBadChoice" };
			let r = [];
			for (let t of e) {
				let [e] = a.pot.splice(t, 1);
				a.whiteSum -= C[e.chip], r.push(e.chip);
			}
			a.bag.push(...r), a.pennies.silver = !1, o.push({
				kind: "witchReturn",
				rid: n.by,
				data: { chips: r }
			});
		} else if (t.type === "wellStirred") {
			if (i.fortune !== "wellStirred" || !a.wellStirred || a.finishing) return { code: "games.quacks.errBadAction" };
			let e = a.pot.findIndex((e) => S[e.chip] === "w");
			if (e < 0) return { code: "games.quacks.errBadChip" };
			let [t] = a.pot.splice(e, 1);
			a.whiteSum -= C[t.chip], a.bag.push(t.chip), a.wellStirred = !1, o.push({
				kind: "flask",
				rid: n.by,
				data: { chip: t.chip }
			});
		} else if (t.type === "secondChance") {
			if (i.fortune !== "secondChance" || !a.secondChance || a.exploded || a.drawn < 5) return { code: "games.quacks.errBadAction" };
			a.bag.push(...a.pot.map((e) => e.chip), ...a.aside, ...a.asideAny, ...a.bowl), a.pot = [], a.aside = [], a.asideAny = [], a.bowl = [], a.whiteSum = 0, a.drawn = 0, a.blueShield = 0, a.doubleNext = !1, a.finishing = !1, a.secondChance = !1, o.push({
				kind: "secondChance",
				rid: n.by
			});
		} else if (t.type === "strongStart") {
			if (i.fortune !== "strong" || !a.strong || a.finishing || a.bag.length === 0) return { code: "games.quacks.errBadAction" };
			a.strong = !1;
			let e = B(i, a, 5);
			if (e.length === 0) return { code: "games.quacks.errBadAction" };
			a.pending.push({
				kind: "strongPick",
				options: e
			});
		}
		return Pe(i, o), {
			state: i,
			fx: o
		};
	}
	if (e.phase !== "settle") return { code: "games.quacks.errBadAction" };
	let a = structuredClone(e), o = a.ps[n.by], s = [], c = o.pending[0];
	if (t.type === "maliciousPick") {
		if (!c || c.kind !== "malicious") return { code: "games.quacks.errBadAction" };
		H(o, "malicious"), o.bag.push(t.chip);
	} else if (t.type === "greenSwap") {
		if (!c || c.kind !== "greenSwap") return { code: "games.quacks.errBadAction" };
		let e = c.idxs;
		if (t.choices.length !== e.length) return { code: "games.quacks.errBadChoice" };
		for (let n = 0; n < e.length; n += 1) {
			let r = t.choices[n];
			if (r === null) continue;
			let i = re[o.pot[e[n]].chip];
			if (!i || !i.includes(r)) return { code: "games.quacks.errBadChip" };
			o.pot[e[n]].chip = r;
		}
		H(o, "greenSwap");
	} else if (t.type === "greenRuby") {
		if (!c || c.kind !== "greenRuby") return { code: "games.quacks.errBadAction" };
		if (t.count > c.max || t.count > o.rubies) return { code: "games.quacks.errBadChoice" };
		H(o, "greenRuby"), o.rubies -= t.count, V(a, o, t.count);
	} else if (t.type === "purpleTier") {
		if (!c || c.kind !== "purpleTier") return { code: "games.quacks.errBadAction" };
		if (t.tier > c.count) return { code: "games.quacks.errBadChoice" };
		H(o, "purpleTier");
		for (let e = 0; e < t.tier; e += 1) {
			let e = o.bag.indexOf("p1");
			if (e >= 0) o.bag.splice(e, 1);
			else {
				let e = o.pot.findIndex((e) => e.chip === "p1");
				e >= 0 && o.pot.splice(e, 1);
			}
		}
		t.tier === 1 ? (o.bag.push("k1"), o.score += 1, o.rubies += 1) : t.tier === 2 ? (o.bag.push("g1", "b2"), o.score += 3, V(a, o, 1)) : t.tier === 3 && (o.bag.push("y4"), o.score += 6, o.rubies += 1, V(a, o, 2));
	} else if (t.type === "purpleUpgrade") {
		if (!c || c.kind !== "purpleUpgrade") return { code: "games.quacks.errBadAction" };
		if (H(o, "purpleUpgrade"), t.index !== null) {
			let e = t.tier <= c.tier ? t.tier : 0, n = o.pot[t.index];
			if (!n || e === 0) return { code: "games.quacks.errBadChoice" };
			let r = e === 2 ? 2 : 1;
			if (C[n.chip] !== r) return { code: "games.quacks.errBadChip" };
			let i = n.chip;
			for (let t = 0; t < (e === 3 ? 2 : 1); t += 1) i = i ? w[i] : void 0;
			if (!i) return { code: "games.quacks.errBadChip" };
			n.chip = i;
		}
	} else if (t.type === "bustChoice") return !c || c.kind !== "bustChoice" ? { code: "games.quacks.errBadAction" } : (H(o, "bustChoice"), t.points ? (o.score += o.vp, o.money = 0, o.settleStep = "f", a.fortune === "magicPotion" && (o.flaskFull = !0)) : o.settleStep = "buy", {
		state: a,
		fx: s
	});
	else if (t.type === "buy") {
		if (o.settleStep !== "buy" || o.pending.length > 0) return { code: "games.quacks.errBadAction" };
		if (o.money === 0 && t.chips.length > 0) return { code: "games.quacks.errTooExpensive" };
		let e = !!t.witchDouble, r = !!t.witchCopy, i = !!t.witchRuby;
		if (e || r || i) {
			if (!o.pennies.copper || e && !a.witches.includes("copperDouble") || r && !a.witches.includes("copperCopy") || i && !a.witches.includes("copperRuby")) return { code: "games.quacks.errBadAction" };
			if (r && t.chips.length === 0) return { code: "games.quacks.errBadChoice" };
		}
		e && (o.money *= 2);
		let c = o.money + (i ? 2 * o.rubies : 0), l = ze(a, t.chips, c);
		if (typeof l != "number") return l;
		Re(a, o, n.by, t.chips), r && o.bag.push(t.chips[0]), (e || r || i) && (o.pennies.copper = !1), o.spent += l, s.push({
			kind: "buy",
			rid: n.by,
			data: {
				chips: t.chips,
				...r ? { copy: !0 } : {}
			}
		}), o.settleStep = "f", a.fortune === "magicPotion" && (o.flaskFull = !0);
	} else if (t.type === "purpleBuy") {
		if (!c || c.kind !== "purpleBuy") return { code: "games.quacks.errBadAction" };
		let e = c.budget, r = ze(a, t.chips, e);
		if (typeof r != "number") return r;
		H(o, "purpleBuy"), Re(a, o, n.by, t.chips), a.round === 9 && (o.score += Math.floor((e - r) / 5)), s.push({
			kind: "buy",
			rid: n.by,
			data: { chips: t.chips }
		});
	} else if (t.type === "greenStart") {
		if (!c || c.kind !== "greenStart") return { code: "games.quacks.errBadAction" };
		if (t.index !== null) {
			let e = o.pot[t.index];
			if (!e || C[e.chip] > c.max) return { code: "games.quacks.errBadChoice" };
			H(o, "greenStart"), o.startChip = e.chip;
		} else H(o, "greenStart");
	} else if (t.type === "witchYesNo") {
		if (!c) return { code: "games.quacks.errBadAction" };
		let e = c.kind;
		if (e === "witchAllBonus") H(o, "witchAllBonus"), t.yes && (o.pennies.silver = !1, o.shielded = !0, o.witchBonus = !0, o.score += o.vp);
		else if (e === "witchGoldRuby") H(o, "witchGoldRuby"), t.yes ? (o.pennies.gold = !1, o.rubies += o.vp) : o.rubies += 1;
		else if (e === "witchColors") {
			if (H(o, "witchColors"), t.yes) {
				let e = new Set(o.pot.map((e) => S[e.chip]).filter((e) => e !== "w"));
				o.score += A[Math.min(e.size, A.length - 1)], o.pennies.gold = !1;
			}
		} else if (e === "witchBag") {
			if (H(o, "witchBag"), t.yes) {
				let e = 0;
				for (let t of o.bag) S[t] !== "w" && (t === "p1" || t === "t1" || C[t] >= 2) && (e += 1);
				o.score += 2 * e, o.pennies.gold = !1;
			}
		} else return { code: "games.quacks.errBadAction" };
	} else if (t.type === "witchUpgrade") {
		if (o.settleStep !== "buy" && o.settleStep !== "f" || o.pending.length > 0 || !a.witches.includes("copperUpgrade") || !o.pennies.copper) return { code: "games.quacks.errBadAction" };
		let e = [...new Set(t.idxs)];
		if (e.length === 0 || e.length === 2 && !(e.includes(o.pot.length - 1) && e.includes(o.pot.length - 2))) return { code: "games.quacks.errBadChoice" };
		for (let t of e) {
			let e = o.pot[t];
			if (!e) return { code: "games.quacks.errBadChoice" };
			let n = w[e.chip];
			if (!n) return { code: "games.quacks.errBadChip" };
			e.chip = n;
		}
		o.pennies.copper = !1, s.push({
			kind: "witchUpgrade",
			rid: n.by,
			data: { idxs: e }
		});
	} else if (t.type === "roundEnd") {
		if (o.settleStep !== "f" || o.pending.length > 0) return { code: "games.quacks.errBadAction" };
		if (t.tube > 0 && !a.trialPot) return { code: "games.quacks.errBadChoice" };
		let e = !!t.witchHalf;
		if (e && (!a.witches.includes("goldCheap") || !o.pennies.gold)) return { code: "games.quacks.errBadAction" };
		let r = e ? 1 : 2, i = t.refill && !o.flaskFull ? r : 0, c = r * (t.pot + t.tube) + i;
		if (c > o.rubies) return { code: "games.quacks.errNoRubies" };
		o.rubies -= c, e && (o.pennies.gold = !1), o.droplet += t.pot;
		let l = M - o.tube, u = Math.min(t.tube, l);
		u < t.tube && (o.droplet += t.tube - u);
		for (let e = 0; e < u; e += 1) o.tube += 1, xe(o);
		t.refill && (o.flaskFull = !0), s.push({
			kind: "droplet",
			rid: n.by,
			data: {
				pot: t.pot,
				tube: u
			}
		}), o.settleStep = "done", Me(a, o);
	} else return { code: "games.quacks.errBadAction" };
	return je(a), Oe(a, s), a.players.every((e) => a.ps[e].settleStep === "done") && s.push({ kind: "settleDone" }), {
		state: a,
		fx: s
	};
}
function Ve(e, t) {
	let n = e.ps[t];
	return {
		public: {
			round: e.round,
			phase: e.phase,
			bookSet: e.bookSet,
			trialPot: e.trialPot,
			expansion: e.expansion,
			witches: e.witches,
			fortuneOn: e.fortuneOn,
			fortune: e.fortune,
			dieRolls: e.dieRolls,
			players: e.players.map((t) => {
				let n = e.ps[t];
				return {
					rid: t,
					score: n.score,
					rubies: n.rubies,
					droplet: n.droplet,
					tube: n.tube,
					flaskFull: n.flaskFull,
					pot: n.pot,
					aside: n.aside,
					asideAny: n.asideAny,
					bowl: n.bowl,
					pennies: n.pennies,
					startChip: n.startChip,
					whiteSum: n.whiteSum,
					threshold: ve(e, n),
					exploded: n.exploded,
					shielded: n.shielded,
					finishing: n.finishing,
					done: n.done,
					wellStirred: n.wellStirred,
					secondChance: n.secondChance,
					strong: n.strong,
					drawn: n.drawn,
					bagCount: n.bag.length,
					rats: n.rats,
					settle: n.settleStep ? {
						scoreSpace: n.scoreSpace,
						money: n.money,
						vp: n.vp,
						rubySpace: n.rubySpace,
						step: n.settleStep
					} : null,
					pending: n.pending.map((e) => e.kind),
					dropletQueue: n.dropletQueue
				};
			})
		},
		private: {
			bag: n ? [...n.bag] : [],
			pending: n ? n.pending.map((e) => ({
				kind: e.kind,
				..."options" in e ? { options: e.options } : {},
				...e.kind === "purpleUpgrade" ? { n: e.tier } : {},
				...e.kind === "greenRuby" ? { n: e.max } : {},
				...e.kind === "fGoodStart" ? { n: e.rats } : {},
				...e.kind === "greenSwap" ? { idxs: e.idxs } : {},
				...e.kind === "greenStart" ? { n: e.max } : {},
				...e.kind === "purpleBuy" ? { n: e.budget } : {}
			})) : []
		}
	};
}
function He(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => {
		let r = e.ps[n].score - e.ps[t].score;
		return r === 0 ? e.ps[n].lastFull - e.ps[t].lastFull : r;
	}), n = t[0];
	return {
		phase: "done",
		winner: t.filter((t) => e.ps[t].score === e.ps[n].score && e.ps[t].lastFull === e.ps[n].lastFull),
		ranking: t,
		scores: Object.fromEntries(e.players.map((t) => [t, e.ps[t].score]))
	};
}
function Ue(e) {
	return e.phase === "fortune" ? e.players.every((t) => e.ps[t].pending.length === 0) ? fe : null : e.phase === "settle" && e.players.every((t) => e.ps[t].settleStep === "done") ? pe : null;
}
var We = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: P,
	schemas: {
		action: ae,
		publicView: ue,
		privateView: de,
		config: ie
	},
	setup: he,
	reduce: Be,
	viewFor: Ve,
	status: He,
	nextTickIn: Ue
}, Ge = {
	w: "#fff9e9",
	o: "#f5a035",
	g: "#74bd67",
	b: "#74b9dc",
	r: "#e46f62",
	y: "#f5cf57",
	p: "#ae86c8",
	k: "#4d5961",
	t: "#5bc8be"
}, Ke = {
	w: "#273b3a",
	o: "#492d20",
	g: "#1f462e",
	b: "#183f58",
	r: "#5a2727",
	y: "#5e4321",
	p: "#3f2b59",
	k: "#ffffff",
	t: "#13403c"
}, U = (() => {
	let e = T.length, t = 3.75, n = Math.PI * .55, r = (e) => t / 2 * (e * Math.sqrt(e * e + 1) + Math.asinh(e)), i = r(13 / t), a = r(24.266666666666666) - i;
	return Array.from({ length: e }, (o, s) => {
		let c = s * a / (e - 1), l = 0, u = 20.8;
		for (let e = 0; e < 40; e += 1) {
			let e = (l + u) / 2;
			r(e + 13 / t) - i < c ? l = e : u = e;
		}
		let d = (l + u) / 2, f = 13 + t * d, p = n + d;
		return {
			x: 187.5 + f * Math.cos(p) * 1.29,
			y: 404 - f * Math.sin(p) * 1.29
		};
	});
})(), qe = U.map((e, t) => `${t ? "L" : "M"}${e.x.toFixed(1)} ${e.y.toFixed(1)}`).join(" ");
function Je(e) {
	let t = Math.min(e.droplet + e.rats, T.length - 1);
	return e.settle?.scoreSpace ?? Math.min((e.pot.at(-1)?.pos ?? t) + 1, T.length - 1);
}
function Ye({ p: e, phase: t, eligibleIndices: n, selectedIndices: r }) {
	let i = s(), a = Math.min(e.droplet + e.rats, T.length - 1), o = Je(e), c = U[o], l = /* @__PURE__ */ new Map();
	return /* @__PURE__ */ m("svg", {
		className: "quacks-pot",
		viewBox: "0 239 375 330",
		role: "img",
		"aria-label": i("games.quacks.potAria"),
		children: [
			/* @__PURE__ */ p("ellipse", {
				cx: "187.5",
				cy: "548",
				rx: "142",
				ry: "17",
				fill: "#4c453d",
				opacity: ".18"
			}),
			/* @__PURE__ */ p("path", {
				d: "M47 365 C7 356 10 401 27 423 L49 417 M328 365 C367 353 372 399 350 424 L327 418",
				fill: "none",
				stroke: "#294b55",
				strokeWidth: "19",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M47 365 C7 356 10 401 27 423 L49 417 M328 365 C367 353 372 399 350 424 L327 418",
				fill: "none",
				stroke: "#6494a0",
				strokeWidth: "11",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "187.5",
				cy: "404",
				r: "152",
				fill: "#294d61",
				stroke: "#173b4c",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "187.5",
				cy: "404",
				r: "145",
				fill: "#51869b",
				stroke: "#c1e5df",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "187.5",
				cy: "404",
				r: "135",
				fill: "#b67a4b",
				stroke: "#304b4b",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "187.5",
				cy: "404",
				r: "127",
				fill: "#e9b271",
				stroke: "#825331",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "187.5",
				cy: "404",
				r: "120",
				fill: "#2b7b70",
				stroke: "#1c4b49",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "187.5",
				cy: "404",
				r: "116",
				fill: "#58aa92"
			}),
			/* @__PURE__ */ p("path", {
				d: "M71 399 C95 378 107 386 123 401 C141 418 159 408 174 390 C194 366 216 363 239 384 C265 407 287 405 303 386",
				fill: "none",
				stroke: "#a3d9af",
				strokeWidth: "7",
				opacity: ".33"
			}),
			/* @__PURE__ */ p("path", {
				d: "M84 446 C111 428 132 450 151 458 C174 467 196 447 217 439 C248 428 278 451 294 443",
				fill: "none",
				stroke: "#b4e1b7",
				strokeWidth: "9",
				opacity: ".26"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "106",
				cy: "353",
				r: "7",
				fill: "#9bd0b0",
				opacity: ".35"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "260",
				cy: "468",
				r: "5",
				fill: "#c7e8bd",
				opacity: ".38"
			}),
			Array.from({ length: 28 }, (e, t) => {
				let n = t * Math.PI * 2 / 28;
				return /* @__PURE__ */ p("circle", {
					cx: 187.5 + 140 * Math.cos(n),
					cy: 404 + 140 * Math.sin(n),
					r: "2.3",
					fill: "#f6d692",
					stroke: "#86552f",
					strokeWidth: ".7"
				}, t);
			}),
			/* @__PURE__ */ p("path", {
				d: qe,
				fill: "none",
				stroke: "#e7d5a6",
				strokeWidth: "16",
				strokeLinejoin: "round",
				opacity: ".35"
			}),
			/* @__PURE__ */ p("path", {
				d: qe,
				fill: "none",
				stroke: "#174d49",
				strokeWidth: "2",
				strokeLinejoin: "round",
				opacity: ".4"
			}),
			U.map((e, t) => /* @__PURE__ */ m("g", { children: [
				/* @__PURE__ */ p("circle", {
					cx: e.x,
					cy: e.y + 1.5,
					r: "8.6",
					fill: "#1a635e",
					opacity: ".42"
				}),
				/* @__PURE__ */ p("circle", {
					cx: e.x,
					cy: e.y,
					r: "8.6",
					fill: t <= a ? "#b3d5bd" : t <= o ? "#caead1" : "#e3d6aa",
					stroke: "#2c7166",
					strokeWidth: "1.3"
				}),
				T[t][2] ? /* @__PURE__ */ p("path", {
					d: `M${e.x} ${e.y - 4} l3.7 4 -3.7 4 -3.7 -4z`,
					fill: "#cc5d57",
					stroke: "#743732",
					strokeWidth: ".6"
				}) : t % 5 == 0 ? /* @__PURE__ */ p("text", {
					x: e.x,
					y: e.y + 2.5,
					textAnchor: "middle",
					fontSize: "6.2",
					fontWeight: "800",
					fill: "#39736a",
					children: T[t][0]
				}) : null
			] }, t)),
			/* @__PURE__ */ p("path", {
				d: `M${U[a].x} ${U[a].y - 9} q-7 9 0 13 q7 -4 0 -13z`,
				fill: "#4da7cd",
				stroke: "#22516a",
				strokeWidth: "1.4"
			}),
			e.pot.map((i, a) => {
				let o = l.get(i.pos) ?? 0;
				l.set(i.pos, o + 1);
				let s = U[Math.min(i.pos, U.length - 1)], c = s.x + o * 4.4, u = s.y - o * 2.1, d = S[i.chip], f = a === e.pot.length - 1 && t === "draw", h = n?.includes(a) ?? !1, g = r?.includes(a) ?? !1;
				return /* @__PURE__ */ m("g", {
					className: f ? "quacks-pot-latest" : void 0,
					children: [
						h && /* @__PURE__ */ p("circle", {
							cx: c,
							cy: u,
							r: "14",
							fill: "none",
							stroke: g ? "#fff9e9" : "#f5cf57",
							strokeWidth: "2.6",
							strokeDasharray: g ? void 0 : "3 2"
						}),
						f && /* @__PURE__ */ p("circle", {
							cx: c,
							cy: u,
							r: "14.5",
							fill: "none",
							stroke: "#edb54a",
							strokeWidth: "2.5",
							strokeDasharray: "3 3"
						}),
						/* @__PURE__ */ p("circle", {
							cx: c,
							cy: u + 2,
							r: "9.5",
							fill: "#1c3e3f",
							opacity: ".62"
						}),
						/* @__PURE__ */ p("circle", {
							cx: c,
							cy: u,
							r: "9.5",
							fill: Ge[d],
							stroke: "#27423f",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ p("path", {
							d: `M${c - 5.7} ${u - 4} Q${c} ${u - 7.7} ${c + 5.2} ${u - 3.8}`,
							fill: "none",
							stroke: "#fff",
							strokeWidth: "1.4",
							opacity: ".72"
						}),
						i.chip === "o6" && /* @__PURE__ */ p("path", {
							d: `M${c - 5} ${u - 5} q-2 5 0 10 M${c + 5} ${u - 5} q2 5 0 10`,
							fill: "none",
							stroke: "#9a5f22",
							strokeWidth: ".7",
							opacity: ".65"
						}),
						i.chip === "t1" && /* @__PURE__ */ p("circle", {
							cx: c,
							cy: u,
							r: "7",
							fill: "none",
							stroke: "#13403c",
							strokeWidth: ".8",
							strokeDasharray: "1.5 2",
							opacity: ".75"
						}),
						/* @__PURE__ */ p("text", {
							x: c,
							y: u + 3.1,
							textAnchor: "middle",
							fontSize: "9",
							fontWeight: "900",
							fill: Ke[d],
							children: i.chip === "t1" ? "?" : C[i.chip]
						}),
						g && /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("circle", {
							cx: c + 10,
							cy: u - 11,
							r: "6",
							fill: "#0d766f",
							stroke: "#fff9e9",
							strokeWidth: "1"
						}), /* @__PURE__ */ p("path", {
							d: `M${c + 7.5} ${u - 11} l2 2 3.5 -4`,
							fill: "none",
							stroke: "#fff9e9",
							strokeWidth: "1.4",
							strokeLinecap: "round"
						})] })
					]
				}, a);
			}),
			/* @__PURE__ */ p("circle", {
				cx: c.x,
				cy: c.y,
				r: "14",
				fill: "none",
				stroke: e.settle ? "#e6a439" : "#fff9e9",
				strokeWidth: "3.5",
				strokeDasharray: e.settle ? void 0 : "4 3"
			}),
			e.settle && /* @__PURE__ */ p("path", {
				d: `M${c.x - 5} ${c.y} l4 4 7 -9`,
				fill: "none",
				stroke: "#a75f26",
				strokeWidth: "2.6",
				strokeLinecap: "round"
			}),
			e.exploded && /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("path", {
				d: "M153 392 l22 -14 -5 18 21 -7 -5 17 29 -8",
				fill: "none",
				stroke: "#b44b42",
				strokeWidth: "5",
				strokeLinecap: "round"
			}), /* @__PURE__ */ p("text", {
				x: "187.5",
				y: "431",
				textAnchor: "middle",
				fontSize: "26",
				children: "💥"
			})] })
		]
	});
}
//#endregion
//#region src/games/quacks/chip-token.tsx
function W({ chip: e, size: t = 30 }) {
	let n = S[e];
	return /* @__PURE__ */ p("span", {
		"aria-hidden": !0,
		className: `quacks-chip-token ${e === "o6" ? "quacks-chip-token--pumpkin6" : e === "t1" ? "quacks-chip-token--locoweed" : ""}`,
		style: {
			width: t,
			height: t,
			fontSize: Math.round(t * .43),
			backgroundColor: Ge[n],
			color: Ke[n]
		},
		children: /* @__PURE__ */ p("span", {
			className: "quacks-chip-token-value",
			children: e === "t1" ? "?" : C[e]
		})
	});
}
//#endregion
//#region src/games/quacks/ingredient-art.tsx
var Xe = {
	o: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M0-9q-4-5-10-1q-8-1-8 10q0 14 11 13q7 3 14 0q11 1 11-12q0-11-9-11q-6-4-9 1" }), /* @__PURE__ */ p("path", {
		d: "M0-8q-6 8 0 21m0-21q6 8 0 21M0-10q-2-8 5-9",
		fill: "none"
	})] }),
	g: /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("path", {
			d: "M-4-4l-11-8-5 4m16 8l-13-3-5 5m18 2l-12 6v7M4-4l11-8 5 4M4 0l13-3 5 5M4 4l12 6v7",
			fill: "none"
		}),
		/* @__PURE__ */ p("ellipse", {
			cy: "3",
			rx: "8",
			ry: "11"
		}),
		/* @__PURE__ */ p("circle", {
			cy: "-8",
			r: "5"
		}),
		/* @__PURE__ */ p("path", {
			d: "M-3 0l6 5m-6 0 6-5",
			stroke: "#ecf6db",
			fill: "none"
		})
	] }),
	b: /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("path", { d: "M-15 4q-3-20 12-21q15-1 17 12l-6 9v9H-9V4Z" }),
		/* @__PURE__ */ p("path", { d: "m9-4 14 6-14 3Z" }),
		/* @__PURE__ */ p("ellipse", {
			cx: "-6",
			cy: "-4",
			rx: "4",
			ry: "5",
			fill: "#35566b",
			stroke: "none"
		}),
		/* @__PURE__ */ p("path", {
			d: "M-5 7v7m7-7v7",
			fill: "none"
		})
	] }),
	r: /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("path", {
			d: "m-5-1-2 17q7 4 14 0L5-1",
			fill: "#f5e5bd"
		}),
		/* @__PURE__ */ p("path", { d: "M-20 0q2-19 20-20q17 1 20 20q-20 6-40 0Z" }),
		/* @__PURE__ */ m("g", {
			fill: "#fff2cf",
			stroke: "none",
			children: [
				/* @__PURE__ */ p("circle", {
					cx: "-9",
					cy: "-7",
					r: "3"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "5",
					cy: "-12",
					r: "3.2"
				}),
				/* @__PURE__ */ p("circle", {
					cx: "13",
					cy: "-4",
					r: "2.5"
				})
			]
		})
	] }),
	y: /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("path", { d: "M0-8q-9 2-8 11l-5 12 10-5 3 10 4-10 10 5L8 3q0-8-8-11Z" }),
		/* @__PURE__ */ p("path", {
			d: "M0-8q-18-6-10-16Q0-21 0-8q1-16 12-17Q17-13 0-8",
			fill: "#7caa64"
		}),
		/* @__PURE__ */ p("path", {
			d: "M-4 1h1m6 0h1M-3 5q3 3 6 0",
			fill: "none"
		})
	] }),
	p: /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("path", { d: "M-15 17V-1q0-18 15-18T15-1v18l-8-5-7 5-7-5Z" }),
		/* @__PURE__ */ p("ellipse", {
			cx: "-5",
			cy: "-2",
			rx: "2",
			ry: "3",
			fill: "#fff4de",
			stroke: "none"
		}),
		/* @__PURE__ */ p("ellipse", {
			cx: "5",
			cy: "-2",
			rx: "2",
			ry: "3",
			fill: "#fff4de",
			stroke: "none"
		}),
		/* @__PURE__ */ p("path", {
			d: "M-3 7q3 3 6 0",
			fill: "none"
		})
	] }),
	k: /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("path", { d: "M-2 0q-9-21-20-15q-8 13 8 22q-14 1-10 12Q-8 24-1 6M2 0q9-21 20-15q8 13-8 22q14 1 10 12Q8 24 1 6" }),
		/* @__PURE__ */ p("path", {
			d: "M0-7v26m0-25-5-8m5 8 5-8",
			fill: "none"
		}),
		/* @__PURE__ */ p("path", {
			d: "m-13-5 5 6m21-6-5 6",
			stroke: "#f7e9bf",
			fill: "none"
		})
	] }),
	t: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M0 20V-6m0 9q-21 4-19-13Q-4-15 0 3m0 7q22 1 20-16Q5-10 0 10m0-14q-8-13 4-20Q16-12 0-4" }), /* @__PURE__ */ p("path", {
		d: "m-16-8 13 9M17-4 3 8M4-20 0-6",
		fill: "none",
		stroke: "#d5ead4"
	})] })
};
function Ze({ color: e }) {
	return /* @__PURE__ */ p("svg", {
		className: "quacks-ingredient-art",
		viewBox: "-28 -28 56 56",
		"aria-hidden": "true",
		fill: Ge[e],
		stroke: "#64543e",
		strokeWidth: "1.8",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: Xe[e]
	});
}
function Qe() {
	return /* @__PURE__ */ m("svg", {
		className: "quacks-book-art",
		viewBox: "-31 -4 62 48",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("path", {
				d: "M0 6Q-14-4-28 1v34q15-5 28 5 14-10 28-5V1Q14-4 0 6",
				fill: "#e5c58b",
				stroke: "#7c5e3f",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ p("path", {
				d: "M0 6v34m-22-30q10-2 17 3m-17 5q10-2 17 3m10-8q8-5 17-3m-17 11q8-5 17-3",
				stroke: "#a48357",
				strokeWidth: "1.5",
				fill: "none"
			}),
			/* @__PURE__ */ p("path", {
				d: "M13 2v15l5-4 5 1V1",
				fill: "#087f77"
			})
		]
	});
}
function $e() {
	return /* @__PURE__ */ m("svg", {
		className: "quacks-coin-art",
		viewBox: "0 0 20 20",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("circle", {
				cx: "10",
				cy: "10",
				r: "8",
				fill: "#e9bd65",
				stroke: "#99733e",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "10",
				cy: "10",
				r: "5.3",
				fill: "none",
				stroke: "#b88843",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ p("path", {
				d: "M8 6v8m4-8v8",
				stroke: "#8b6336",
				strokeWidth: "1.2"
			})
		]
	});
}
//#endregion
//#region src/games/quacks/keymaps.ts
var et = {
	w: "games.quacks.colorW",
	o: "games.quacks.colorO",
	g: "games.quacks.colorG",
	b: "games.quacks.colorB",
	r: "games.quacks.colorR",
	y: "games.quacks.colorY",
	p: "games.quacks.colorP",
	k: "games.quacks.colorK",
	t: "games.quacks.colorT"
}, tt = {
	seasoned: "games.quacks.cardSeasoned",
	luckyDevil: "games.quacks.cardLuckyDevil",
	shining: "games.quacks.cardShining",
	malicious: "games.quacks.cardMalicious",
	wellStirred: "games.quacks.cardWellStirred",
	potFull: "games.quacks.cardPotFull",
	secondChance: "games.quacks.cardSecondChance",
	strong: "games.quacks.cardStrong",
	pumpkin: "games.quacks.cardPumpkin",
	magicPotion: "games.quacks.cardMagicPotion",
	ratsFriends: "games.quacks.cardRatsFriends",
	ratInfestation: "games.quacks.cardRatInfestation",
	goodStart: "games.quacks.cardGoodStart",
	luxury: "games.quacks.cardLuxury",
	donations: "games.quacks.cardDonations",
	beginner: "games.quacks.cardBeginner",
	moment: "games.quacks.cardMoment",
	justInTime: "games.quacks.cardJustInTime",
	keepOne: "games.quacks.cardKeepOne",
	wheel: "games.quacks.cardWheel",
	lessIsMore: "games.quacks.cardLessIsMore",
	alms: "games.quacks.cardAlms",
	potFilling: "games.quacks.cardPotFilling",
	chooseWisely: "games.quacks.cardChooseWisely"
}, nt = {
	seasoned: "games.quacks.cardSeasonedDesc",
	luckyDevil: "games.quacks.cardLuckyDevilDesc",
	shining: "games.quacks.cardShiningDesc",
	malicious: "games.quacks.cardMaliciousDesc",
	wellStirred: "games.quacks.cardWellStirredDesc",
	potFull: "games.quacks.cardPotFullDesc",
	secondChance: "games.quacks.cardSecondChanceDesc",
	strong: "games.quacks.cardStrongDesc",
	pumpkin: "games.quacks.cardPumpkinDesc",
	magicPotion: "games.quacks.cardMagicPotionDesc",
	ratsFriends: "games.quacks.cardRatsFriendsDesc",
	ratInfestation: "games.quacks.cardRatInfestationDesc",
	goodStart: "games.quacks.cardGoodStartDesc",
	luxury: "games.quacks.cardLuxuryDesc",
	donations: "games.quacks.cardDonationsDesc",
	beginner: "games.quacks.cardBeginnerDesc",
	moment: "games.quacks.cardMomentDesc",
	justInTime: "games.quacks.cardJustInTimeDesc",
	keepOne: "games.quacks.cardKeepOneDesc",
	wheel: "games.quacks.cardWheelDesc",
	lessIsMore: "games.quacks.cardLessIsMoreDesc",
	alms: "games.quacks.cardAlmsDesc",
	potFilling: "games.quacks.cardPotFillingDesc",
	chooseWisely: "games.quacks.cardChooseWiselyDesc"
}, rt = {
	silverFlask: "games.quacks.witchSilverFlask",
	silverSix: "games.quacks.witchSilverSix",
	silverReturn: "games.quacks.witchSilverReturn",
	silverBonus: "games.quacks.witchSilverBonus",
	copperUpgrade: "games.quacks.witchCopperUpgrade",
	copperDouble: "games.quacks.witchCopperDouble",
	copperCopy: "games.quacks.witchCopperCopy",
	copperRuby: "games.quacks.witchCopperRuby",
	goldRubyVp: "games.quacks.witchGoldRubyVp",
	goldCheap: "games.quacks.witchGoldCheap",
	goldColors: "games.quacks.witchGoldColors",
	goldBag: "games.quacks.witchGoldBag"
}, it = {
	silverFlask: "games.quacks.witchSilverFlaskDesc",
	silverSix: "games.quacks.witchSilverSixDesc",
	silverReturn: "games.quacks.witchSilverReturnDesc",
	silverBonus: "games.quacks.witchSilverBonusDesc",
	copperUpgrade: "games.quacks.witchCopperUpgradeDesc",
	copperDouble: "games.quacks.witchCopperDoubleDesc",
	copperCopy: "games.quacks.witchCopperCopyDesc",
	copperRuby: "games.quacks.witchCopperRubyDesc",
	goldRubyVp: "games.quacks.witchGoldRubyVpDesc",
	goldCheap: "games.quacks.witchGoldCheapDesc",
	goldColors: "games.quacks.witchGoldColorsDesc",
	goldBag: "games.quacks.witchGoldBagDesc"
}, at = {
	silver: "games.quacks.pennySilver",
	copper: "games.quacks.pennyCopper",
	gold: "games.quacks.pennyGold"
}, ot = [
	{
		color: "o",
		name: "games.quacks.ingredientO"
	},
	{
		color: "g",
		name: "games.quacks.ingredientG"
	},
	{
		color: "b",
		name: "games.quacks.ingredientB"
	},
	{
		color: "r",
		name: "games.quacks.ingredientR"
	},
	{
		color: "y",
		name: "games.quacks.ingredientY"
	},
	{
		color: "p",
		name: "games.quacks.ingredientP"
	},
	{
		color: "k",
		name: "games.quacks.ingredientK"
	},
	{
		color: "t",
		name: "games.quacks.ingredientT"
	}
], st = {
	1: {
		g: "games.quacks.bookG1",
		b: "games.quacks.bookB1",
		r: "games.quacks.bookR1",
		y: "games.quacks.bookY1",
		p: "games.quacks.bookP1"
	},
	2: {
		g: "games.quacks.bookG2",
		b: "games.quacks.bookB2",
		r: "games.quacks.bookR2",
		y: "games.quacks.bookY2",
		p: "games.quacks.bookP2"
	},
	3: {
		g: "games.quacks.bookG3",
		b: "games.quacks.bookB3",
		r: "games.quacks.bookR3",
		y: "games.quacks.bookY3",
		p: "games.quacks.bookP3"
	},
	4: {
		g: "games.quacks.bookG4",
		b: "games.quacks.bookB4",
		r: "games.quacks.bookR4",
		y: "games.quacks.bookY4",
		p: "games.quacks.bookP4"
	},
	5: {
		g: "games.quacks.bookG5",
		b: "games.quacks.bookB5",
		r: "games.quacks.bookR5",
		y: "games.quacks.bookY5",
		p: "games.quacks.bookP5"
	},
	6: {
		g: "games.quacks.bookG6",
		b: "games.quacks.bookB6",
		r: "games.quacks.bookR6",
		y: "games.quacks.bookY6",
		p: "games.quacks.bookP6"
	}
};
function ct(e, t) {
	return t === "o" ? e.expansion ? "games.quacks.bookOExpansion" : "games.quacks.bookO" : t === "t" ? e.bookSet === 5 ? "games.quacks.bookT5" : "games.quacks.bookT6" : t === "k" ? e.bookSet === 5 ? "games.quacks.bookK5" : e.bookSet === 6 ? "games.quacks.bookK6" : e.players.length === 2 ? "games.quacks.bookKTwo" : "games.quacks.bookKMany" : st[e.bookSet][t];
}
function lt(e) {
	return [
		"o1",
		...e.expansion ? ["o6"] : [],
		"g1",
		"g2",
		"g4",
		"b1",
		"b2",
		"b4",
		"r1",
		"r2",
		"r4",
		"y1",
		"y2",
		"y4",
		"p1",
		"k1",
		...e.bookSet >= 5 ? ["t1"] : []
	];
}
function G(e, t) {
	return O[e.bookSet][t] ?? (e.expansion && t === "o6" ? 22 : 0);
}
function ut({ pub: e, budget: t, cost: n, subtitle: r }) {
	let i = s();
	return /* @__PURE__ */ m("div", {
		className: "quacks-market-head",
		children: [/* @__PURE__ */ m("div", {
			className: "quacks-market-heading",
			children: [
				/* @__PURE__ */ p(Qe, {}),
				/* @__PURE__ */ p("strong", { children: i("games.quacks.marketTitle") }),
				/* @__PURE__ */ p("small", { children: r ?? i("games.quacks.marketBookSet", { n: e.bookSet }) })
			]
		}), /* @__PURE__ */ m("span", {
			className: "quacks-market-money",
			"aria-label": i("games.quacks.buyTitle", { n: t - n }),
			children: [
				/* @__PURE__ */ p($e, {}),
				/* @__PURE__ */ p("strong", { children: t - n }),
				/* @__PURE__ */ m("span", { children: ["/ ", t] })
			]
		})]
	});
}
function dt({ pub: e, picked: t, budget: r, onPick: i }) {
	let a = s(), o = n(), c = t.reduce((t, n) => t + G(e, n), 0), l = lt(e);
	return /* @__PURE__ */ p("div", {
		className: "quacks-market-list",
		children: ot.map(({ color: n, name: s }) => {
			let u = l.filter((e) => S[e] === n);
			if (!u.length) return null;
			let d = n === "y" && e.round < 2 ? 2 : n === "p" && e.round < 3 ? 3 : null, f = t.find((e) => S[e] === n), g = `${o}-${n}`;
			return /* @__PURE__ */ m("section", {
				className: `quacks-market-row ${f ? "is-selected" : ""}`,
				"aria-label": `${a(et[n])} · ${a(s)}`,
				children: [/* @__PURE__ */ m("div", {
					className: "quacks-market-description",
					children: [/* @__PURE__ */ m("div", {
						className: "quacks-market-ingredient",
						children: [
							/* @__PURE__ */ p(Ze, { color: n }),
							/* @__PURE__ */ p("strong", { children: a(s) }),
							/* @__PURE__ */ p("small", { children: a(et[n]) }),
							d !== null && /* @__PURE__ */ p("span", {
								className: "quacks-market-unlock",
								children: a("games.quacks.marketUnlock", { n: d })
							})
						]
					}), /* @__PURE__ */ p("p", {
						id: g,
						children: a(ct(e, n))
					})]
				}), /* @__PURE__ */ p("div", {
					className: "quacks-market-options",
					children: u.map((o) => {
						let s = t.includes(o), l = c - (f ? G(e, f) : 0) + G(e, o) > r, u = t.length >= 2 && !f, _ = d !== null || !s && (l || u), v = d === null ? a(s ? "games.quacks.marketSelected" : l ? "games.quacks.marketInsufficient" : u ? "games.quacks.marketLimit" : "games.quacks.marketAvailable") : a("games.quacks.marketUnlock", { n: d });
						return /* @__PURE__ */ m("button", {
							type: "button",
							className: `quacks-market-item ${s ? "is-selected" : ""}`,
							disabled: _,
							"aria-pressed": s,
							"aria-describedby": g,
							"aria-label": `${a(et[n])} ${o === "t1" ? "?" : C[o]} · ${a("games.quacks.marketPrice", { n: G(e, o) })} · ${v}`,
							onClick: () => i(o),
							children: [
								/* @__PURE__ */ p(W, {
									chip: o,
									size: 30
								}),
								/* @__PURE__ */ m("span", {
									className: "quacks-market-price",
									children: [/* @__PURE__ */ p($e, {}), /* @__PURE__ */ p("strong", { children: G(e, o) })]
								}),
								s && /* @__PURE__ */ p("span", {
									className: "quacks-market-check",
									"aria-hidden": "true",
									children: /* @__PURE__ */ p(h, { size: 13 })
								})
							]
						}, o);
					})
				})]
			}, n);
		})
	});
}
//#endregion
//#region src/games/quacks/expansion-art.tsx
function K({ witch: e, size: t = 23 }) {
	let n = (() => {
		switch (e) {
			case "silverFlask": return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M9 3h6M10 3v6l-4.5 8a3 3 0 0 0 2.6 4.5h7.8a3 3 0 0 0 2.6-4.5L14 9V3" }), /* @__PURE__ */ p("path", { d: "M8 16h8" })] });
			case "silverSix": return /* @__PURE__ */ p(f, { children: [
				0,
				1,
				2,
				3,
				4,
				5
			].map((e) => /* @__PURE__ */ p("circle", {
				cx: 7 + e % 3 * 5,
				cy: 8 + Math.floor(e / 3) * 7,
				r: "1.5",
				fill: "currentColor",
				stroke: "none"
			}, e)) });
			case "silverReturn": return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M6 7V3L2.5 6.5 6 10V7a8 8 0 1 1-1 9" }), /* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "12",
				r: "2.5"
			})] });
			case "silverBonus": return /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "M12 2.5 14.8 8l6 .9-4.4 4.3 1 6-5.4-2.9-5.4 2.9 1-6-4.4-4.3 6-.9z" }) });
			case "copperUpgrade": return /* @__PURE__ */ p(f, { children: /* @__PURE__ */ p("path", { d: "m5 14 7-8 7 8M5 20l7-8 7 8" }) });
			case "copperDouble": return /* @__PURE__ */ p("text", {
				x: "12",
				y: "16.8",
				textAnchor: "middle",
				fontSize: "13",
				fontWeight: "900",
				fill: "currentColor",
				stroke: "none",
				children: "×2"
			});
			case "copperCopy": return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: "9",
				cy: "10",
				r: "5.2"
			}), /* @__PURE__ */ p("circle", {
				cx: "15",
				cy: "14",
				r: "5.2"
			})] });
			case "copperRuby": return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "m10 4 6 7-6 8-6-8z" }), /* @__PURE__ */ p("path", { d: "M18 5v8M14 9h8" })] });
			case "goldRubyVp": return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "m12 3 6 7-6 7-6-7z" }), /* @__PURE__ */ p("path", { d: "M4 18v3M9 19v3M18 19v3" })] });
			case "goldCheap": return /* @__PURE__ */ p("text", {
				x: "12",
				y: "17",
				textAnchor: "middle",
				fontSize: "17",
				fontWeight: "900",
				fill: "currentColor",
				stroke: "none",
				children: "½"
			});
			case "goldColors": return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M12 12 3 18M12 12l-5 9M12 12v10M12 12l5 9M12 12l9 6" }), /* @__PURE__ */ p("circle", {
				cx: "12",
				cy: "10",
				r: "2.5"
			})] });
			case "goldBag": return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M8 5h8l-2 4c4 2 5 5 5 8a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4c0-3 1-6 5-8z" }), /* @__PURE__ */ p("path", { d: "M9 9h6M12 12v6M9 15h6" })] });
		}
	})();
	return /* @__PURE__ */ p("svg", {
		"aria-hidden": !0,
		viewBox: "0 0 24 24",
		width: t,
		height: t,
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: n
	});
}
function ft({ penny: e, used: t = !1 }) {
	let n = s();
	return /* @__PURE__ */ p("span", {
		"aria-hidden": !0,
		className: `quacks-penny quacks-penny--${e} ${t ? "is-used" : ""}`,
		children: t ? "×" : n(at[e]).slice(0, 1)
	});
}
function q({ witch: e, used: t = !1 }) {
	return /* @__PURE__ */ m("span", {
		"aria-hidden": !0,
		className: `quacks-witch-action-mark quacks-witch-action-mark--${k[e]}`,
		children: [/* @__PURE__ */ p(K, {
			witch: e,
			size: 20
		}), /* @__PURE__ */ p(ft, {
			penny: k[e],
			used: t
		})]
	});
}
function pt({ p: e }) {
	let t = s(), n = Math.floor(e.bowl.reduce((e, t) => e + C[t], 0) / 2);
	return /* @__PURE__ */ m("div", {
		className: "quacks-bowl",
		role: "status",
		"aria-label": `${t("games.quacks.bowlLabel")} · ${e.bowl.length ? t("games.quacks.bowlBonus", { n }) : t("games.quacks.bowlEmpty")}`,
		children: [
			/* @__PURE__ */ p("span", {
				className: "quacks-bowl-title",
				children: t("games.quacks.bowlLabel")
			}),
			/* @__PURE__ */ m("svg", {
				className: "quacks-bowl-vessel",
				viewBox: "0 0 84 58",
				"aria-hidden": !0,
				children: [
					/* @__PURE__ */ p("ellipse", {
						cx: "42",
						cy: "51",
						rx: "38",
						ry: "5",
						fill: "#4c453d",
						opacity: ".18"
					}),
					/* @__PURE__ */ p("path", {
						d: "M3 15Q42 33 81 15L72 42Q42 61 12 42Z",
						fill: "#ae754a",
						stroke: "#5f412d",
						strokeWidth: "2.5"
					}),
					/* @__PURE__ */ p("path", {
						d: "M12 19Q42 31 72 19L68 38Q42 51 16 38Z",
						fill: "#6d5039",
						stroke: "#4c3526"
					}),
					/* @__PURE__ */ p("path", {
						d: "M3 15Q42 31 81 15",
						fill: "none",
						stroke: "#e2ae69",
						strokeWidth: "5",
						strokeLinecap: "round"
					})
				]
			}),
			/* @__PURE__ */ m("span", {
				className: "quacks-bowl-chips",
				children: [e.bowl.slice(0, 3).map((e, t) => /* @__PURE__ */ p(W, {
					chip: e,
					size: 17
				}, t)), e.bowl.length > 3 && /* @__PURE__ */ m("span", {
					className: "quacks-bowl-more",
					children: ["+", e.bowl.length - 3]
				})]
			}),
			/* @__PURE__ */ p("span", {
				className: "quacks-bowl-score",
				children: e.bowl.length ? t("games.quacks.bowlScore", { n }) : t("games.quacks.bowlEmpty")
			})
		]
	});
}
//#endregion
//#region src/games/quacks/hud.tsx
function mt({ fortune: e, expanded: t, onToggle: n }) {
	let r = s();
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: "quacks-fortune cursor-pointer text-left disabled:cursor-default",
		disabled: !e,
		"aria-expanded": t,
		onClick: n,
		children: [
			/* @__PURE__ */ p("span", {
				className: "quacks-fortune-seal",
				"aria-hidden": !0,
				children: "✧"
			}),
			/* @__PURE__ */ m("span", {
				className: "quacks-fortune-copy",
				children: [/* @__PURE__ */ p("span", {
					className: "quacks-eyebrow",
					children: r("games.quacks.phaseFortune")
				}), /* @__PURE__ */ p("strong", { children: r(e ? tt[e] : "games.quacks.phaseFortune") })]
			}),
			/* @__PURE__ */ p("span", {
				className: "quacks-fortune-spark",
				"aria-hidden": !0,
				children: "◆"
			})
		]
	});
}
function ht({ p: e, owner: t }) {
	let n = s(), r = e.whiteSum >= e.threshold - 2, i = e.exploded ? `💥 ${n("games.quacks.explodedTag")}` : r ? `⚠ ${n("games.quacks.riskTitle")}` : n("games.quacks.riskTitle");
	return /* @__PURE__ */ m("div", {
		className: `quacks-risk ${r ? "quacks-risk--warning" : ""} ${e.exploded ? "quacks-risk--burst" : ""}`,
		role: "meter",
		"aria-label": t ? `${t} · ${n("games.quacks.riskTitle")}` : n("games.quacks.riskTitle"),
		"aria-valuemin": 0,
		"aria-valuemax": Math.max(e.threshold + 1, e.whiteSum),
		"aria-valuenow": e.whiteSum,
		"aria-valuetext": n("games.quacks.whiteSum", {
			n: e.whiteSum,
			m: e.threshold
		}),
		children: [
			/* @__PURE__ */ m("span", {
				className: "quacks-risk-label",
				children: [t ? `${t} · ` : "", i]
			}),
			/* @__PURE__ */ p("span", {
				className: "quacks-risk-segments",
				"aria-hidden": !0,
				children: Array.from({ length: e.threshold }, (t, n) => /* @__PURE__ */ p("span", { className: n < e.whiteSum ? "is-filled" : "" }, n))
			}),
			/* @__PURE__ */ m("strong", {
				className: "quacks-risk-value",
				children: [
					e.whiteSum,
					"/",
					e.threshold
				]
			})
		]
	});
}
function gt({ witches: e, p: t }) {
	let n = s(), [r, a] = i(null), o = r && e.includes(r) ? r : null;
	return /* @__PURE__ */ m("div", {
		className: "quacks-witches",
		"aria-label": n("games.quacks.witchBarTitle"),
		children: [e.map((e) => {
			let r = k[e], i = t.pennies[r];
			return /* @__PURE__ */ m("button", {
				type: "button",
				className: `quacks-witch quacks-witch--${r} ${o === e ? "is-open" : ""} ${i ? "" : "is-used"}`,
				"aria-label": `${n(rt[e])} · ${n(i ? "games.quacks.pennyReady" : "games.quacks.pennyUsed")} · ${n(it[e])}`,
				"aria-expanded": o === e,
				onClick: () => a(o === e ? null : e),
				children: [
					/* @__PURE__ */ p("span", {
						className: "quacks-witch-sigil",
						children: /* @__PURE__ */ p(K, {
							witch: e,
							size: 23
						})
					}),
					/* @__PURE__ */ p("span", {
						className: "quacks-witch-name",
						children: n(rt[e])
					}),
					/* @__PURE__ */ p("span", {
						className: "quacks-witch-state",
						children: n(i ? "games.quacks.pennyReady" : "games.quacks.pennyUsed")
					}),
					/* @__PURE__ */ p(ft, {
						penny: r,
						used: !i
					})
				]
			}, e);
		}), o && /* @__PURE__ */ m("button", {
			type: "button",
			className: `quacks-witch-desc quacks-witch-desc--${k[o]}`,
			onClick: () => a(null),
			children: [/* @__PURE__ */ m("span", {
				className: "quacks-witch-desc-head",
				children: [
					/* @__PURE__ */ p(K, {
						witch: o,
						size: 26
					}),
					/* @__PURE__ */ p("strong", { children: n(rt[o]) }),
					/* @__PURE__ */ p(ft, {
						penny: k[o],
						used: !t.pennies[k[o]]
					})
				]
			}), /* @__PURE__ */ p("span", { children: n(it[o]) })]
		})]
	});
}
function _t({ p: e, trialPot: t }) {
	let n = s(), r = e.tube < M ? j[e.tube] : null;
	return /* @__PURE__ */ m("div", {
		className: "quacks-props",
		children: [
			/* @__PURE__ */ m("span", {
				className: "quacks-prop quacks-prop--bag",
				children: [/* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "quacks-bag-icon"
				}), n("games.quacks.bagLeft", { n: e.bagCount })]
			}),
			/* @__PURE__ */ m("span", {
				className: "quacks-prop quacks-prop--drop",
				children: [
					"💧 ",
					e.droplet,
					e.rats > 0 ? ` +${e.rats}` : ""
				]
			}),
			/* @__PURE__ */ m("span", {
				className: `quacks-prop quacks-prop--flask ${e.flaskFull ? "" : "is-used"}`,
				children: ["⚗ ", n(e.flaskFull ? "games.quacks.flaskReady" : "games.quacks.flaskUsed")]
			}),
			t && /* @__PURE__ */ m("span", {
				className: "quacks-prop quacks-prop--tube",
				children: [
					"🧪 ",
					e.tube,
					"/",
					M,
					r?.kind === "ruby" && ` · ◆${r.n}`,
					r?.kind === "vp" && ` · ★${r.n}`,
					r?.kind === "chip" && /* @__PURE__ */ p(W, {
						chip: r.chip,
						size: 17
					})
				]
			}),
			e.aside.length > 0 && /* @__PURE__ */ m("span", {
				className: "quacks-prop quacks-prop--aside",
				children: [
					n("games.quacks.asideLabel"),
					" ",
					e.aside.map((e, t) => /* @__PURE__ */ p(W, {
						chip: e,
						size: 18
					}, t))
				]
			}),
			e.asideAny.length > 0 && /* @__PURE__ */ m("span", {
				className: "quacks-prop quacks-prop--aside",
				children: [
					n("games.quacks.asideAnyLabel"),
					" ",
					e.asideAny.map((e, t) => /* @__PURE__ */ p(W, {
						chip: e,
						size: 18
					}, t))
				]
			}),
			e.startChip && /* @__PURE__ */ m("span", {
				className: "quacks-prop quacks-prop--drop",
				children: [
					n("games.quacks.startChipLabel"),
					" ",
					/* @__PURE__ */ p(W, {
						chip: e.startChip,
						size: 18
					})
				]
			})
		]
	});
}
function vt({ p: e, owner: t }) {
	let n = s(), r = Je(e), [i, a, o] = T[r];
	return /* @__PURE__ */ m("div", {
		className: "quacks-reward",
		role: "status",
		children: [/* @__PURE__ */ m("span", {
			className: "quacks-eyebrow",
			children: [t ? `${t} · ` : "", n(e.settle ? "games.quacks.rewardSettlement" : "games.quacks.rewardPreview", { n: r })]
		}), /* @__PURE__ */ m("span", {
			className: "quacks-reward-values",
			children: [
				/* @__PURE__ */ m("strong", { children: [
					/* @__PURE__ */ p("span", {
						"aria-hidden": !0,
						children: "🪙"
					}),
					" ",
					e.settle?.money ?? i
				] }),
				/* @__PURE__ */ m("strong", { children: [
					/* @__PURE__ */ p("span", {
						"aria-hidden": !0,
						children: "★"
					}),
					" ",
					e.settle?.vp ?? a
				] }),
				(e.settle?.rubySpace ?? o) && /* @__PURE__ */ m("strong", {
					className: "quacks-reward-ruby",
					children: ["◆ ", n("games.quacks.spaceRuby")]
				})
			]
		})]
	});
}
//#endregion
//#region src/games/quacks/view-player.tsx
var J = "quacks-btn", Y = "quacks-btn quacks-btn--primary";
function X() {
	let e = s();
	return (t) => `${e(et[S[t]])} ${C[t]}`;
}
function yt({ defaultClass: e, children: t }) {
	let [n, a] = i(null), o = r(null);
	return /* @__PURE__ */ p("div", {
		className: `absolute z-10 touch-none select-none ${n ? "cursor-grabbing" : `cursor-grab ${e}`}`,
		style: n ? {
			left: n.x,
			top: n.y
		} : void 0,
		onPointerDown: (e) => {
			let t = e.currentTarget, n = t.getBoundingClientRect();
			o.current = {
				dx: e.clientX - n.left,
				dy: e.clientY - n.top
			}, t.setPointerCapture(e.pointerId);
		},
		onPointerMove: (e) => {
			if (!o.current) return;
			let t = e.currentTarget.parentElement.getBoundingClientRect(), n = e.currentTarget.getBoundingClientRect();
			a({
				x: Math.min(Math.max(e.clientX - t.left - o.current.dx, 0), t.width - n.width),
				y: Math.min(Math.max(e.clientY - t.top - o.current.dy, 0), t.height - n.height)
			});
		},
		onPointerUp: () => o.current = null,
		onPointerCancel: () => o.current = null,
		children: t
	});
}
function bt(e, t) {
	return e === "vp1" ? t("games.quacks.dieVp", { n: 1 }) : e === "vp2" ? t("games.quacks.dieVp", { n: 2 }) : t(e === "ruby" ? "games.quacks.dieRuby" : e === "droplet" ? "games.quacks.dieDroplet" : "games.quacks.dieO1");
}
function Z({ text: e }) {
	return /* @__PURE__ */ p("p", {
		className: "mb-1.5 text-xs font-extrabold",
		children: e
	});
}
function xt({ chips: e, onPick: t }) {
	let n = X();
	return /* @__PURE__ */ p("div", {
		className: "flex flex-wrap items-center gap-2",
		children: e.map((e) => /* @__PURE__ */ m("button", {
			type: "button",
			"aria-label": n(e),
			onClick: () => t(e),
			className: `${J} flex items-center gap-1.5`,
			children: [/* @__PURE__ */ p(W, {
				chip: e,
				size: 24
			}), n(e)]
		}, e))
	});
}
function St({ pd: e, send: t }) {
	let n = s(), r = e.kind;
	return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: n(r === "bluePick" ? "games.quacks.promptBluePick" : "games.quacks.promptStrongPick") }), /* @__PURE__ */ m("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [(e.options ?? []).map((e, n) => /* @__PURE__ */ p(Ct, {
			c: e,
			onClick: () => t({
				type: r,
				index: n
			})
		}, n)), /* @__PURE__ */ p("button", {
			type: "button",
			className: J,
			onClick: () => t({
				type: r,
				index: null
			}),
			children: n("games.quacks.pickNone")
		})]
	})] });
}
function Ct({ c: e, disabled: t, onClick: n }) {
	let r = X();
	return /* @__PURE__ */ p("button", {
		type: "button",
		"aria-label": r(e),
		disabled: t,
		onClick: n,
		className: `${J} !px-2`,
		children: /* @__PURE__ */ p(W, {
			chip: e,
			size: 26
		})
	});
}
function wt({ me: e, send: t }) {
	let n = s(), r = e.dropletQueue, a = M - e.tube, [o, c] = i(() => Math.min(r, a));
	return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: n("games.quacks.promptDropletAssign", { n: r }) }), /* @__PURE__ */ m("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [
			/* @__PURE__ */ p("button", {
				type: "button",
				className: `${J} min-w-11`,
				disabled: o <= 0,
				onClick: () => c(o - 1),
				children: "−"
			}),
			/* @__PURE__ */ p("span", {
				className: "text-sm font-bold",
				children: n("games.quacks.dropletTube", { n: o })
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: `${J} min-w-11`,
				disabled: o >= Math.min(r, a),
				onClick: () => c(o + 1),
				children: "+"
			}),
			/* @__PURE__ */ p("span", {
				className: "text-sm font-bold",
				children: n("games.quacks.dropletPot", { n: r - o })
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: Y,
				style: { background: P.accent },
				onClick: () => t({
					type: "dropletAssign",
					tube: o
				}),
				children: n("games.quacks.confirmDone")
			})
		]
	})] });
}
function Tt({ pd: e, me: t, send: n }) {
	let r = s(), a = X(), o = e.idxs ?? [], [c, l] = i(() => o.map(() => null));
	return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: r("games.quacks.promptGreenSwap") }), /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-1.5",
		children: [o.map((e, n) => {
			let i = t.pot[e]?.chip, o = i === "g1" || i === "g2" || i === "g4" ? re[i] : [];
			return /* @__PURE__ */ m("div", {
				className: "flex flex-wrap items-center gap-1.5",
				children: [
					i && /* @__PURE__ */ p(W, {
						chip: i,
						size: 24
					}),
					/* @__PURE__ */ p("span", {
						className: "text-xs font-bold",
						children: "→"
					}),
					o.map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						"aria-label": a(e),
						onClick: () => l(c.map((t, r) => r === n ? e : t)),
						className: `${J} !px-2 ${c[n] === e ? "ring-2 ring-ink" : ""}`,
						children: /* @__PURE__ */ p(W, {
							chip: e,
							size: 20
						})
					}, e)),
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => l(c.map((e, t) => t === n ? null : e)),
						className: `${J} ${c[n] === null ? "ring-2 ring-ink" : ""}`,
						children: r("games.quacks.greenKeep")
					})
				]
			}, e);
		}), /* @__PURE__ */ p("button", {
			type: "button",
			className: `${Y} self-start`,
			style: { background: P.accent },
			onClick: () => n({
				type: "greenSwap",
				choices: c
			}),
			children: r("games.quacks.confirmDone")
		})]
	})] });
}
function Et({ pd: e, me: t, send: n }) {
	let r = s(), a = X(), o = e.n ?? 1, [c, l] = i(o), u = c === 2 ? 2 : 1, d = (e) => {
		if (C[e] !== u) return !1;
		let t = w[e];
		return !(!t || c === 3 && !w[t]);
	};
	return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: r("games.quacks.promptPurpleUpgrade", { n: c }) }), /* @__PURE__ */ m("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [
			Array.from({ length: o }, (e, t) => t + 1).map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => l(e),
				className: `${J} !px-2 ${c === e ? "ring-2 ring-ink" : ""}`,
				children: e
			}, e)),
			t.pot.map((e, t) => /* @__PURE__ */ p("button", {
				type: "button",
				"aria-label": a(e.chip),
				disabled: !d(e.chip),
				onClick: () => n({
					type: "purpleUpgrade",
					index: t,
					tier: c
				}),
				className: `${J} !px-2`,
				children: /* @__PURE__ */ p(W, {
					chip: e.chip,
					size: 20
				})
			}, t)),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => n({
					type: "purpleUpgrade",
					index: null,
					tier: c
				}),
				children: r("games.quacks.upgradeSkip")
			})
		]
	})] });
}
function Dt({ budget: e, pub: t, send: n }) {
	let r = s(), [a, o] = i([]), c = a.reduce((e, n) => e + G(t, n), 0);
	return /* @__PURE__ */ m("div", {
		className: "quacks-market",
		children: [
			/* @__PURE__ */ p(ut, {
				pub: t,
				budget: e,
				cost: c,
				subtitle: r("games.quacks.promptPurpleBuy", { n: e })
			}),
			/* @__PURE__ */ p("div", {
				className: "quacks-market-scroll",
				children: /* @__PURE__ */ p(dt, {
					pub: t,
					picked: a,
					budget: e,
					onPick: (e) => o((t) => {
						if (t.includes(e)) return t.filter((t) => t !== e);
						let n = t.find((t) => S[t] === S[e]);
						return n ? t.map((t) => t === n ? e : t) : t.length >= 2 ? t : [...t, e];
					})
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "quacks-market-footer",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => n({
						type: "purpleBuy",
						chips: []
					}),
					children: r("games.quacks.buyNone")
				}), /* @__PURE__ */ m("button", {
					type: "button",
					className: Y,
					style: { background: P.accent },
					disabled: a.length === 0 || c > e,
					onClick: () => n({
						type: "purpleBuy",
						chips: a
					}),
					children: [r("games.quacks.buyConfirm"), c > 0 ? ` · ${r("games.quacks.marketCost", { n: c })}` : ""]
				})]
			})
		]
	});
}
function Ot({ pd: e, me: t, priv: n, pub: r, send: i }) {
	let a = s();
	switch (e.kind) {
		case "bluePick":
		case "strongPick": return /* @__PURE__ */ p(St, {
			pd: e,
			send: i
		});
		case "dropletAssign": return /* @__PURE__ */ p(wt, {
			me: t,
			send: i
		});
		case "fRatsFriends": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptRatsFriends") }), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ p(xt, {
				chips: [
					"g4",
					"b4",
					"r4",
					"y4"
				],
				onPick: (e) => i({
					type: "fRatsFriends",
					chip: e
				})
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "fRatsFriends",
					chip: null
				}),
				children: a("games.quacks.takeRatsVp", { n: t.rats })
			})]
		})] });
		case "fGoodStart": {
			let t = Math.min(3, e.n ?? 0);
			return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptGoodStart") }), /* @__PURE__ */ m("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => i({
						type: "fGoodStart",
						giveUp: 0
					}),
					children: a("games.quacks.goodStartKeep")
				}), Array.from({ length: t }, (e, t) => t + 1).map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => i({
						type: "fGoodStart",
						giveUp: e
					}),
					children: a("games.quacks.goodStartTrade", { n: e })
				}, e))]
			})] });
		}
		case "fMoment": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptMoment") }), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [(e.options ?? []).map((e, t) => /* @__PURE__ */ p(Ct, {
				c: e,
				disabled: !w[e],
				onClick: () => i({
					type: "fMoment",
					index: t
				})
			}, t)), /* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "fMoment",
					index: null
				}),
				children: a("games.quacks.momentSkip")
			})]
		})] });
		case "fJustInTime": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptJustInTime") }), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "fJustInTime",
					remove: !1
				}),
				children: a("games.quacks.takeVp", { n: 4 })
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				disabled: !n.bag.includes("w1"),
				onClick: () => i({
					type: "fJustInTime",
					remove: !0
				}),
				children: a("games.quacks.removeW1")
			})]
		})] });
		case "fKeepOne": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptKeepOne") }), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => i({
						type: "fKeepOne",
						kind: "k"
					}),
					children: a("games.quacks.keepBlack")
				}),
				/* @__PURE__ */ p(xt, {
					chips: [
						"g2",
						"b2",
						"r2",
						"y2"
					],
					onPick: (e) => i({
						type: "fKeepOne",
						kind: "c2",
						chip: e
					})
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => i({
						type: "fKeepOne",
						kind: "r"
					}),
					children: a("games.quacks.keepRubies")
				})
			]
		})] });
		case "fWheel": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptWheel") }), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ p(xt, {
				chips: [
					"w1",
					"o1",
					"g1",
					"b1",
					"r1",
					"y1"
				],
				onPick: (e) => i({
					type: "fWheel",
					chip: e
				})
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "fWheel",
					chip: null
				}),
				children: a("games.quacks.wheelSkip")
			})]
		})] });
		case "fChooseWisely": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptChooseWisely") }), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "fChooseWisely",
					purple: !1
				}),
				children: a("games.quacks.takeDroplets", { n: 2 })
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "fChooseWisely",
					purple: !0
				}),
				children: a("games.quacks.takePurple")
			})]
		})] });
		case "malicious": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptMalicious") }), /* @__PURE__ */ p(xt, {
			chips: [
				"g2",
				"b2",
				"r2",
				"y2"
			],
			onPick: (e) => i({
				type: "maliciousPick",
				chip: e
			})
		})] });
		case "greenSwap": return /* @__PURE__ */ p(Tt, {
			pd: e,
			me: t,
			send: i
		});
		case "greenRuby": {
			let t = e.n ?? 0;
			return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptGreenRuby") }), /* @__PURE__ */ p("div", {
				className: "flex flex-wrap items-center gap-2",
				children: Array.from({ length: t + 1 }, (e, t) => /* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => i({
						type: "greenRuby",
						count: t
					}),
					children: a("games.quacks.greenRubyN", { n: t })
				}, t))
			})] });
		}
		case "purpleTier": {
			let t = e.n ?? 0, n = {
				1: "games.quacks.purpleTier1",
				2: "games.quacks.purpleTier2",
				3: "games.quacks.purpleTier3"
			};
			return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptPurpleTier") }), /* @__PURE__ */ m("div", {
				className: "flex flex-col gap-1.5",
				children: [Array.from({ length: t }, (e, t) => t + 1).map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: `${J} text-left`,
					onClick: () => i({
						type: "purpleTier",
						tier: e
					}),
					children: a(n[e])
				}, e)), /* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => i({
						type: "purpleTier",
						tier: 0
					}),
					children: a("games.quacks.greenKeep")
				})]
			})] });
		}
		case "purpleUpgrade": return /* @__PURE__ */ p(Et, {
			pd: e,
			me: t,
			send: i
		});
		case "bustChoice": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptBust") }), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "bustChoice",
					points: !0
				}),
				children: a("games.quacks.bustPoints", { n: t.settle?.vp ?? 0 })
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "bustChoice",
					points: !1
				}),
				children: a("games.quacks.bustBuy", { n: t.settle?.money ?? 0 })
			})]
		})] });
		case "yellowRuby": return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptYellowRuby") }), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "yellowRuby",
					use: !0
				}),
				children: a("games.quacks.witchUse")
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: J,
				onClick: () => i({
					type: "yellowRuby",
					use: !1
				}),
				children: a("games.quacks.witchSkip")
			})]
		})] });
		case "greenStart": {
			let n = e.n ?? 0;
			return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.promptGreenStart") }), /* @__PURE__ */ m("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [t.pot.map((e, t) => /* @__PURE__ */ p(Ct, {
					c: e.chip,
					disabled: C[e.chip] > n,
					onClick: () => i({
						type: "greenStart",
						index: t
					})
				}, t)), /* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => i({
						type: "greenStart",
						index: null
					}),
					children: a("games.quacks.greenStartSkip")
				})]
			})] });
		}
		case "purpleBuy": return /* @__PURE__ */ p(Dt, {
			budget: e.n ?? 0,
			pub: r,
			send: i
		});
		case "witchSix": return /* @__PURE__ */ m("div", {
			className: "quacks-witch-choice",
			children: [/* @__PURE__ */ m("div", {
				className: "quacks-witch-choice-head",
				children: [/* @__PURE__ */ p(q, { witch: "silverSix" }), /* @__PURE__ */ p(Z, { text: a("games.quacks.promptWitchSix") })]
			}), /* @__PURE__ */ m("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [(e.options ?? []).map((e, t) => /* @__PURE__ */ p(Ct, {
					c: e,
					onClick: () => i({
						type: "witchSixPlace",
						index: t
					})
				}, t)), /* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => i({ type: "witchSixDone" }),
					children: a("games.quacks.witchSixDone")
				})]
			})]
		});
		case "witchAllBonus":
		case "witchGoldRuby":
		case "witchColors":
		case "witchBag": {
			let n = Nt(e, t), r = e.kind === "witchAllBonus" ? "silverBonus" : e.kind === "witchGoldRuby" ? "goldRubyVp" : e.kind === "witchColors" ? "goldColors" : "goldBag";
			return /* @__PURE__ */ m("div", {
				className: "quacks-witch-choice",
				children: [/* @__PURE__ */ m("div", {
					className: "quacks-witch-choice-head",
					children: [/* @__PURE__ */ p(q, { witch: r }), /* @__PURE__ */ p(Z, { text: a(n.k, n.vars) })]
				}), /* @__PURE__ */ m("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: `${Y} quacks-witch-action`,
						style: { background: P.accent },
						onClick: () => i({
							type: "witchYesNo",
							yes: !0
						}),
						children: a("games.quacks.witchUse")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: J,
						onClick: () => i({
							type: "witchYesNo",
							yes: !1
						}),
						children: a("games.quacks.witchSkip")
					})]
				})]
			});
		}
	}
}
function kt({ me: e, pub: t, send: n, onPotPreview: r }) {
	let a = s(), o = X(), [c, l] = i(null), u = e.pot.length > 0 ? e.pot[e.pot.length - 1] : null, d = e.flaskFull && !e.finishing && !!u && S[u.chip] === "w", f = e.pot.some((e) => S[e.chip] === "w"), h = e.pot.flatMap((e, t) => S[e.chip] === "w" ? [t] : []), g = t.witches, _ = t.expansion && e.pennies.silver, v = _ && g.includes("silverFlask") && e.exploded && e.flaskFull, y = e.asideAny.map((e, t) => /* @__PURE__ */ m("button", {
		type: "button",
		className: `${J} flex items-center gap-1`,
		onClick: () => n({
			type: "placeAsideAny",
			index: t
		}),
		children: [/* @__PURE__ */ p(W, {
			chip: e,
			size: 20
		}), a("games.quacks.asideAnyLabel")]
	}, `aa${t}`));
	return e.finishing ? /* @__PURE__ */ m("div", {
		className: "quacks-finishing flex flex-wrap items-center gap-2",
		children: [
			e.aside.map((e, t) => /* @__PURE__ */ m("button", {
				type: "button",
				className: `${J} flex items-center gap-1.5`,
				onClick: () => n({
					type: "placeAside",
					index: t
				}),
				children: [/* @__PURE__ */ p(W, {
					chip: e,
					size: 22
				}), a("games.quacks.placeAsideN", { n: C[e] })]
			}, t)),
			y,
			t.expansion && g.includes("silverFlask") && /* @__PURE__ */ m("button", {
				type: "button",
				className: `${J} quacks-witch-action`,
				disabled: !v,
				onClick: () => n({ type: "witchFlask" }),
				children: [/* @__PURE__ */ p(q, {
					witch: "silverFlask",
					used: !_
				}), a("games.quacks.witchFlaskBtn")]
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: `${Y} flex-1`,
				style: { background: P.accent },
				onClick: () => n({ type: "confirmDone" }),
				children: a("games.quacks.confirmDone")
			})
		]
	}) : /* @__PURE__ */ m("div", {
		className: "quacks-draw-actions flex flex-col gap-2",
		children: [
			/* @__PURE__ */ m("div", {
				className: "quacks-draw-main flex gap-2",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: `${Y} quacks-draw-button flex-1`,
					style: { background: P.accent },
					disabled: e.bagCount === 0,
					onClick: () => n({ type: "draw" }),
					children: a("games.quacks.draw")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: `${J} quacks-stop-button min-h-12 flex-1`,
					onClick: () => n({ type: "stop" }),
					children: a("games.quacks.stop")
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "quacks-draw-tools flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ m("button", {
						type: "button",
						className: J,
						disabled: !d,
						onClick: () => n({ type: "flask" }),
						children: ["⚗️ ", a("games.quacks.flask")]
					}),
					e.wellStirred && /* @__PURE__ */ p("button", {
						type: "button",
						className: J,
						disabled: !f,
						onClick: () => n({ type: "wellStirred" }),
						children: a("games.quacks.wellStirredBtn")
					}),
					e.secondChance && /* @__PURE__ */ p("button", {
						type: "button",
						className: J,
						disabled: e.drawn < 5 || e.exploded,
						onClick: () => n({ type: "secondChance" }),
						children: a("games.quacks.secondChanceBtn")
					}),
					e.strong && /* @__PURE__ */ p("button", {
						type: "button",
						className: J,
						disabled: e.bagCount === 0,
						onClick: () => n({ type: "strongStart" }),
						children: a("games.quacks.strongBtn")
					}),
					e.aside.map((e, t) => /* @__PURE__ */ m("button", {
						type: "button",
						className: `${J} flex items-center gap-1`,
						onClick: () => n({
							type: "placeAside",
							index: t
						}),
						children: [/* @__PURE__ */ p(W, {
							chip: e,
							size: 20
						}), a("games.quacks.placeAsideN", { n: C[e] })]
					}, t)),
					y,
					t.expansion && g.includes("silverSix") && /* @__PURE__ */ m("button", {
						type: "button",
						className: `${J} quacks-witch-action`,
						disabled: !(_ && !e.exploded && e.bagCount > 0),
						onClick: () => n({ type: "witchSix" }),
						children: [/* @__PURE__ */ p(q, {
							witch: "silverSix",
							used: !_
						}), a("games.quacks.witchSixBtn")]
					}),
					t.expansion && g.includes("silverReturn") && c === null && /* @__PURE__ */ m("button", {
						type: "button",
						className: `${J} quacks-witch-action`,
						disabled: !(_ && !e.exploded && f),
						onClick: () => {
							l([]), r(h, []);
						},
						children: [/* @__PURE__ */ p(q, {
							witch: "silverReturn",
							used: !_
						}), a("games.quacks.witchReturnBtn")]
					})
				]
			}),
			c !== null && /* @__PURE__ */ m("div", {
				className: "quacks-return-picker",
				children: [
					/* @__PURE__ */ m("div", {
						className: "quacks-witch-choice-head",
						children: [/* @__PURE__ */ p(q, { witch: "silverReturn" }), /* @__PURE__ */ p("span", { children: a("games.quacks.witchReturnHint") })]
					}),
					/* @__PURE__ */ p("div", {
						className: "quacks-return-chips",
						children: e.pot.map((e, t) => S[e.chip] === "w" ? /* @__PURE__ */ m("button", {
							type: "button",
							"aria-label": `${t + 1} · ${o(e.chip)}`,
							"aria-pressed": c.includes(t),
							className: `quacks-upgrade-chip ${c.includes(t) ? "is-selected" : ""}`,
							onClick: () => {
								let e = c.includes(t) ? c.filter((e) => e !== t) : c.length >= 2 ? c : [...c, t];
								l(e), r(h, e);
							},
							children: [/* @__PURE__ */ p(W, {
								chip: e.chip,
								size: 26
							}), /* @__PURE__ */ p("span", { children: t + 1 })]
						}, t) : null)
					}),
					/* @__PURE__ */ m("div", {
						className: "quacks-upgrade-actions",
						children: [/* @__PURE__ */ p("button", {
							type: "button",
							className: J,
							onClick: () => {
								l(null), r(null);
							},
							children: a("games.quacks.witchSkip")
						}), /* @__PURE__ */ p("button", {
							type: "button",
							className: Y,
							style: { background: P.accent },
							disabled: c.length === 0,
							onClick: () => {
								n({
									type: "witchReturn",
									idxs: c
								}), l(null), r(null);
							},
							children: a("games.quacks.confirmDone")
						})]
					})
				]
			})
		]
	});
}
function At({ me: e, pub: t, send: n, onPotPreview: r }) {
	let a = s(), o = X(), [c, l] = i(null), u = e.pot.flatMap((e, t) => w[e.chip] ? [t] : []);
	if (!t.expansion || !t.witches.includes("copperUpgrade") || !e.pennies.copper) return null;
	if (c === null) return /* @__PURE__ */ m("button", {
		type: "button",
		className: `${J} quacks-witch-action`,
		disabled: u.length === 0,
		onClick: () => {
			l([]), r(u, []);
		},
		children: [/* @__PURE__ */ p(q, { witch: "copperUpgrade" }), a("games.quacks.witchUpgradeBtn")]
	});
	let d = c.length < 2 || c.includes(e.pot.length - 1) && c.includes(e.pot.length - 2);
	return /* @__PURE__ */ m("div", {
		className: "quacks-upgrade-picker",
		children: [
			/* @__PURE__ */ m("div", {
				className: "quacks-upgrade-head",
				children: [/* @__PURE__ */ p(q, { witch: "copperUpgrade" }), /* @__PURE__ */ p("span", { children: a("games.quacks.witchUpgradeHint") })]
			}),
			/* @__PURE__ */ p("div", {
				className: "quacks-upgrade-chips",
				children: e.pot.map((e, t) => /* @__PURE__ */ m("button", {
					type: "button",
					"aria-label": `${t + 1} · ${o(e.chip)}`,
					"aria-pressed": c.includes(t),
					disabled: !w[e.chip],
					className: `quacks-upgrade-chip ${c.includes(t) ? "is-selected" : ""}`,
					onClick: () => {
						let e = c.includes(t) ? c.filter((e) => e !== t) : c.length >= 2 ? c : [...c, t];
						l(e), r(u, e);
					},
					children: [/* @__PURE__ */ p(W, {
						chip: e.chip,
						size: 26
					}), /* @__PURE__ */ p("span", { children: t + 1 })]
				}, t))
			}),
			/* @__PURE__ */ m("div", {
				className: "quacks-upgrade-actions",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => {
						l(null), r(null);
					},
					children: a("games.quacks.witchSkip")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: Y,
					style: { background: P.accent },
					disabled: c.length === 0 || !d,
					onClick: () => {
						n({
							type: "witchUpgrade",
							idxs: c
						}), l(null), r(null);
					},
					children: a("games.quacks.confirmDone")
				})]
			})
		]
	});
}
function jt({ me: e, pub: t, send: n, onPotPreview: r }) {
	let a = s(), [o, c] = i([]), [l, u] = i(null), d = (e.settle?.money ?? 0) * (l === "double" ? 2 : 1) + (l === "ruby" ? e.rubies * 2 : 0), f = (e) => G(t, e), h = o.reduce((e, t) => e + f(t), 0), g = t.expansion && e.pennies.copper, _ = (e, n, r) => t.witches.includes(n) ? /* @__PURE__ */ m("button", {
		type: "button",
		className: `${J} quacks-witch-action`,
		"aria-pressed": l === e,
		disabled: !g,
		onClick: () => u(l === e ? null : e),
		children: [/* @__PURE__ */ p(q, {
			witch: n,
			used: !g
		}), a(r)]
	}) : null;
	return /* @__PURE__ */ m("div", {
		className: "quacks-market",
		children: [
			/* @__PURE__ */ p(ut, {
				pub: t,
				budget: d,
				cost: h
			}),
			/* @__PURE__ */ m("div", {
				className: "quacks-market-scroll",
				children: [/* @__PURE__ */ p(dt, {
					pub: t,
					picked: o,
					budget: d,
					onPick: (e) => c((t) => {
						if (t.includes(e)) return t.filter((t) => t !== e);
						let n = t.find((t) => S[t] === S[e]);
						return n ? t.map((t) => t === n ? e : t) : t.length >= 2 ? t : [...t, e];
					})
				}), g && /* @__PURE__ */ m("div", {
					className: "quacks-market-witches",
					children: [
						_("double", "copperDouble", "games.quacks.witchDoubleBtn"),
						_("copy", "copperCopy", "games.quacks.witchCopyBtn"),
						_("ruby", "copperRuby", "games.quacks.witchRubyBtn"),
						/* @__PURE__ */ p(At, {
							me: e,
							pub: t,
							send: n,
							onPotPreview: r
						})
					]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "quacks-market-footer",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: J,
					onClick: () => n({
						type: "buy",
						chips: []
					}),
					children: a("games.quacks.buyNone")
				}), /* @__PURE__ */ m("button", {
					type: "button",
					className: Y,
					style: { background: P.accent },
					disabled: o.length === 0 || h > d,
					onClick: () => n({
						type: "buy",
						chips: o,
						...l === "double" ? { witchDouble: !0 } : {},
						...l === "copy" ? { witchCopy: !0 } : {},
						...l === "ruby" ? { witchRuby: !0 } : {}
					}),
					children: [a("games.quacks.buyConfirm"), h > 0 ? ` · ${a("games.quacks.marketCost", { n: h })}` : ""]
				})]
			})
		]
	});
}
function Mt({ me: e, pub: t, send: n, onPotPreview: r }) {
	let a = s(), [o, c] = i(0), [l, u] = i(0), [d, f] = i(!1), [h, g] = i(!1), _ = t.expansion && t.witches.includes("goldCheap") && e.pennies.gold, v = h && _ ? 1 : 2, y = d && !e.flaskFull ? v : 0, b = e.rubies - v * (o + l) - y, x = (e, t, n, r) => /* @__PURE__ */ m("span", {
		className: "flex items-center gap-1",
		children: [
			/* @__PURE__ */ p("button", {
				type: "button",
				"aria-label": r,
				className: `${J} min-w-11 !px-1`,
				disabled: e <= 0,
				onClick: () => t(e - 1),
				children: "−"
			}),
			/* @__PURE__ */ m("span", {
				className: "min-w-8 text-center text-xs font-bold",
				children: [r, e > 0 ? ` ×${e}` : ""]
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				"aria-label": r,
				className: `${J} min-w-11 !px-1`,
				disabled: b < v || e >= n,
				onClick: () => t(e + 1),
				children: "+"
			})
		]
	});
	return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p(Z, { text: a("games.quacks.roundEndTitle", { n: b }) }), /* @__PURE__ */ m("div", {
		className: "flex flex-wrap items-center gap-x-3 gap-y-1.5",
		children: [
			x(o, c, 99, a(v === 1 ? "games.quacks.pushPotHalf" : "games.quacks.pushPot")),
			t.trialPot && x(l, u, M - e.tube, a(v === 1 ? "games.quacks.pushTubeHalf" : "games.quacks.pushTube")),
			!e.flaskFull && /* @__PURE__ */ m("button", {
				type: "button",
				className: `${J} ${d ? "ring-2 ring-ink" : ""}`,
				disabled: !d && b < v,
				onClick: () => f(!d),
				children: ["⚗️ ", a(v === 1 ? "games.quacks.refillFlaskHalf" : "games.quacks.refillFlask")]
			}),
			_ && /* @__PURE__ */ m("button", {
				type: "button",
				className: `${J} quacks-witch-action`,
				"aria-pressed": h,
				onClick: () => g(!h),
				children: [/* @__PURE__ */ p(q, { witch: "goldCheap" }), a("games.quacks.witchHalfBtn")]
			}),
			/* @__PURE__ */ p(At, {
				me: e,
				pub: t,
				send: n,
				onPotPreview: r
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: Y,
				style: { background: P.accent },
				onClick: () => n({
					type: "roundEnd",
					pot: o,
					tube: l,
					refill: d && !e.flaskFull,
					...h && _ ? { witchHalf: !0 } : {}
				}),
				children: a("games.quacks.roundEndDone")
			})
		]
	})] });
}
function Nt(e, t) {
	switch (e.kind) {
		case "bluePick": return { k: "games.quacks.promptBluePick" };
		case "strongPick": return { k: "games.quacks.promptStrongPick" };
		case "dropletAssign": return {
			k: "games.quacks.promptDropletAssign",
			vars: { n: t?.dropletQueue ?? 0 }
		};
		case "fRatsFriends": return { k: "games.quacks.promptRatsFriends" };
		case "fGoodStart": return { k: "games.quacks.promptGoodStart" };
		case "fMoment": return { k: "games.quacks.promptMoment" };
		case "fJustInTime": return { k: "games.quacks.promptJustInTime" };
		case "fKeepOne": return { k: "games.quacks.promptKeepOne" };
		case "fWheel": return { k: "games.quacks.promptWheel" };
		case "fChooseWisely": return { k: "games.quacks.promptChooseWisely" };
		case "malicious": return { k: "games.quacks.promptMalicious" };
		case "greenSwap": return { k: "games.quacks.promptGreenSwap" };
		case "greenRuby": return { k: "games.quacks.promptGreenRuby" };
		case "purpleTier": return { k: "games.quacks.promptPurpleTier" };
		case "purpleUpgrade": return {
			k: "games.quacks.promptPurpleUpgrade",
			vars: { n: e.n ?? 1 }
		};
		case "bustChoice": return { k: "games.quacks.promptBust" };
		case "yellowRuby": return { k: "games.quacks.promptYellowRuby" };
		case "greenStart": return { k: "games.quacks.promptGreenStart" };
		case "purpleBuy": return {
			k: "games.quacks.promptPurpleBuy",
			vars: { n: e.n ?? 0 }
		};
		case "witchSix": return { k: "games.quacks.promptWitchSix" };
		case "witchAllBonus": return { k: "games.quacks.promptWitchAllBonus" };
		case "witchGoldRuby": return {
			k: "games.quacks.promptWitchGoldRuby",
			vars: { n: t?.settle?.vp ?? 0 }
		};
		case "witchColors": return { k: "games.quacks.promptWitchColors" };
		case "witchBag": return { k: "games.quacks.promptWitchBag" };
	}
}
function Pt(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Ft, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ft({ pub: e, priv: t, members: n, myRid: r, send: h }) {
	let g = s(), [_, v] = i(r), [y, b] = i(null), x = `${e.round}:${e.fortune ?? ""}`, S = y?.key === x ? y.open : e.phase === "fortune", [C, w] = i(null), { ref: ee } = a("pot"), T = e.players.find((e) => e.rid === r), E = e.players.find((e) => e.rid === _) ?? T, D = t?.pending[0] ?? null, O = `${e.round}:${e.phase}:${D?.kind ?? T?.settle?.step ?? "idle"}`, k = (e, t = []) => {
		e && v(r), w(e ? {
			key: O,
			eligible: e,
			selected: t
		} : null);
	}, te = C?.key === O && E?.rid === r ? C : null, A = (e) => n.find((t) => t.rid === e)?.name ?? e, j = "info", M, N;
	if (e.phase === "fortune") {
		if (D) {
			j = "accent";
			let e = Nt(D, T);
			M = g(e.k, e.vars);
		} else M = e.fortune ? g(tt[e.fortune]) : g("games.quacks.phaseFortune"), e.players.some((e) => e.pending.length > 0) && (N = g("games.quacks.waitOthers"));
	} else if (e.phase === "draw") {
		if (D) {
			j = "accent";
			let e = Nt(D, T);
			M = g(e.k, e.vars);
		} else T?.done ? (j = T.exploded ? "warn" : "info", M = g(T.exploded ? "games.quacks.explodedTag" : "games.quacks.doneTag"), N = g("games.quacks.waitOthers")) : (j = "accent", M = g("games.quacks.phaseDraw"), N = g("games.quacks.whiteSum", {
			n: T?.whiteSum ?? 0,
			m: T?.threshold ?? 0
		}));
	} else if (e.phase === "settle") {
		let e = T?.settle?.step, t = D !== null || e === "buy" || e === "f";
		if (t && (j = "accent"), D) {
			let e = Nt(D, T);
			M = g(e.k, e.vars);
		} else M = g("games.quacks.phaseSettle"), t || (N = g("games.quacks.waitOthers"));
	} else j = "done", M = g("session.result.title");
	let ne;
	ne = D && T && t ? /* @__PURE__ */ p(Ot, {
		pd: D,
		me: T,
		priv: t,
		pub: e,
		send: h
	}) : e.phase === "draw" && T && !T.done ? /* @__PURE__ */ p(kt, {
		me: T,
		pub: e,
		send: h,
		onPotPreview: k
	}) : e.phase === "settle" && T?.settle?.step === "buy" ? /* @__PURE__ */ p(jt, {
		me: T,
		pub: e,
		send: h,
		onPotPreview: k
	}) : e.phase === "settle" && T?.settle?.step === "f" ? /* @__PURE__ */ p(Mt, {
		me: T,
		pub: e,
		send: h,
		onPotPreview: k
	}) : /* @__PURE__ */ p("p", {
		className: "py-2 text-center text-xs font-bold text-ink/60",
		children: g("games.quacks.waitOthers")
	});
	let re = e.phase === "settle" && (T?.settle?.step === "buy" && !D || D?.kind === "purpleBuy");
	return /* @__PURE__ */ p(d, {
		adaptive: !0,
		scroll: !1,
		className: "quacks-adaptive",
		children: /* @__PURE__ */ m("div", {
			className: "quacks-screen",
			children: [
				/* @__PURE__ */ p("div", {
					className: "quacks-banner",
					children: /* @__PURE__ */ p(l, {
						tone: j,
						text: M,
						sub: N,
						chip: g("games.quacks.roundShort", { n: e.round }),
						accent: P.accent
					})
				}),
				/* @__PURE__ */ p("div", {
					className: "quacks-players",
					children: /* @__PURE__ */ p(u, {
						variant: "plate",
						members: n,
						myRid: r,
						anchorOf: (e) => `seat:${e}`,
						onPick: (e) => v(e),
						picked: (e) => e === E?.rid,
						action: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? e.phase === "draw" ? n.done ? "done" : "pending" : e.phase === "settle" ? n.settle?.step === "done" ? "done" : "pending" : null : null;
						},
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ m(f, { children: [
								/* @__PURE__ */ m("span", {
									className: "font-mono tabular-nums",
									children: [/* @__PURE__ */ p("span", {
										className: "text-amber-500",
										children: "★"
									}), /* @__PURE__ */ p(o, { value: n.score })]
								}),
								/* @__PURE__ */ m("span", {
									className: "font-mono tabular-nums",
									children: [/* @__PURE__ */ p("span", {
										className: "text-rose-500",
										children: "◆"
									}), n.rubies]
								}),
								/* @__PURE__ */ p("span", {
									className: n.flaskFull ? "" : "opacity-30",
									children: "⚗️"
								}),
								(n.exploded || n.shielded) && /* @__PURE__ */ m("span", {
									className: "absolute -top-1.5 right-1 z-10 flex gap-1",
									children: [n.exploded && /* @__PURE__ */ m("span", {
										className: "rounded border border-ink bg-danger-soft px-1 text-[10px] leading-3.5 font-bold text-danger-ink",
										children: ["💥", g("games.quacks.explodedTag")]
									}), n.shielded && /* @__PURE__ */ m("span", {
										className: "rounded border border-ink bg-info-soft px-1 text-[10px] leading-3.5 font-bold text-info-ink",
										children: ["🛡", g("games.quacks.shieldTag")]
									})]
								})
							] }) : null;
						}
					})
				}),
				/* @__PURE__ */ m("div", {
					ref: ee,
					className: "frame quacks-table",
					children: [
						/* @__PURE__ */ p(c, {
							kind: "sheen",
							base: "#e5d5b2",
							className: "quacks-table-texture absolute inset-0 size-full"
						}),
						/* @__PURE__ */ m("div", {
							className: "quacks-table-body",
							children: [/* @__PURE__ */ m("div", {
								className: "quacks-table-notes",
								children: [
									e.fortuneOn && /* @__PURE__ */ p(mt, {
										fortune: e.fortune,
										expanded: !!e.fortune && S,
										onToggle: () => b({
											key: x,
											open: !S
										})
									}),
									e.expansion && E && /* @__PURE__ */ p(gt, {
										witches: e.witches,
										p: E
									}),
									E && /* @__PURE__ */ p(ht, {
										p: E,
										owner: E.rid === r ? void 0 : A(E.rid)
									}),
									E && /* @__PURE__ */ p(_t, {
										p: E,
										trialPot: e.trialPot
									})
								]
							}), /* @__PURE__ */ m("div", {
								className: `quacks-board-stage ${e.expansion ? "quacks-board-stage--expansion" : ""}`,
								children: [
									E && /* @__PURE__ */ p(Ye, {
										p: E,
										phase: e.phase,
										eligibleIndices: te?.eligible,
										selectedIndices: te?.selected
									}),
									E && /* @__PURE__ */ p(vt, {
										p: E,
										owner: E.rid === r ? void 0 : A(E.rid)
									}),
									e.expansion && E && /* @__PURE__ */ p(pt, { p: E })
								]
							})]
						}),
						S && e.fortune && /* @__PURE__ */ p(yt, {
							defaultClass: "quacks-float--fortune",
							children: /* @__PURE__ */ m("div", {
								className: "quacks-fortune-note",
								children: [/* @__PURE__ */ m("div", {
									className: "mb-1 flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ p("strong", { children: g(tt[e.fortune]) }), /* @__PURE__ */ p("button", {
										type: "button",
										className: J,
										onPointerDown: (e) => e.stopPropagation(),
										onClick: () => b({
											key: x,
											open: !1
										}),
										children: g("common.close")
									})]
								}), g(nt[e.fortune])]
							})
						}),
						e.dieRolls && e.dieRolls.length > 0 && /* @__PURE__ */ p(yt, {
							defaultClass: "quacks-float--die",
							children: /* @__PURE__ */ m("div", {
								className: "quacks-die-note",
								children: [/* @__PURE__ */ m("span", { children: ["🎲 ", g("games.quacks.dieFaces")] }), e.dieRolls.map((e) => /* @__PURE__ */ m("span", { children: [
									A(e.rid),
									": ",
									e.faces.map((e) => bt(e, g)).join(" · ")
								] }, e.rid))]
							})
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: "quacks-bottom safe-b",
					children: /* @__PURE__ */ p("div", {
						className: `quacks-actions ${re ? "quacks-actions--buy" : ""}`,
						children: /* @__PURE__ */ p("div", {
							className: "quacks-actions-content",
							children: ne
						}, O)
					})
				})
			]
		})
	});
}
//#endregion
//#region src/games/quacks/bot.ts
var It = {
	moneyW: 1.2,
	rubyW: 2.5,
	riskW: 1.8,
	pushBonus: 1.5,
	flaskRoom: 1,
	rollTheta: .25,
	rolloutK: 64,
	catchUpW: .05,
	wo: 1,
	wg: 1,
	wb: 2,
	wr: .6,
	wy: 1.5,
	wp: 1,
	wk: .6,
	wt: 1,
	buyEffic: 0,
	bustMoneyMax: 8,
	refillMin: 4,
	potPairMax: 3,
	tubePairMax: 2
}, Lt = {
	1: {
		b: 1.4,
		r: 1.2
	},
	2: {
		r: 1.5,
		b: 1.2,
		y: 1.2
	},
	3: {
		b: 1.3,
		y: 1.3,
		r: 1.2
	},
	4: {
		y: 1.5,
		r: 1.3,
		g: 1.2
	},
	5: {
		b: 1.3,
		r: 1.2,
		g: 1.3,
		t: 1.2
	},
	6: {
		p: 1.4,
		b: 1.2,
		y: 1.1,
		t: 1.1
	}
};
function Rt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function zt(e) {
	let t = e.pot[e.pot.length - 1], n = t ? t.pos : e.droplet + e.rats;
	return Math.min(n + 1, T.length - 1);
}
function Bt(e, t) {
	let [n, r, i] = T[Math.min(e, T.length - 1)];
	return n * t.moneyW + r + (i ? t.rubyW : 0);
}
function Vt(e, t) {
	let n = 2166136261, r = `${e.pot.map((e) => e.chip).join(".")}|${[...t].sort().join(".")}|${e.whiteSum}|${e.flaskFull}|${e.droplet}|${e.rats}`;
	for (let e = 0; e < r.length; e += 1) n ^= r.charCodeAt(e), n = Math.imul(n, 16777619);
	return n >>> 0;
}
function Ht(e) {
	let t = e || 1;
	return () => (t ^= t << 13, t ^= t >>> 17, t ^= t << 5, (t >>> 0) / 4294967296);
}
function Ut(e, t, n) {
	let r = e.pot.map((e) => e.chip), i = r[r.length - 1];
	return {
		bag: [...t],
		chips: r,
		positions: e.pot.map((e) => e.pos),
		whiteSum: e.whiteSum,
		flask: e.flaskFull,
		aside: [...e.aside],
		dbl: n.bookSet === 2 && i !== void 0 && S[i] === "y",
		busted: !1,
		base: e.droplet + e.rats,
		o: r.filter((e) => S[e] === "o").length,
		r: r.filter((e) => S[e] === "r").length,
		y: r.filter((e) => S[e] === "y").length
	};
}
function Wt(e, t, n, r) {
	let i = Math.floor(n() * e.bag.length), a = e.bag[i];
	e.bag[i] = e.bag[e.bag.length - 1], e.bag.pop();
	let o = S[a];
	if (o === "r" && t.bookSet === 2) {
		e.aside.push(a);
		return;
	}
	let s = C[a];
	if (a === "t1" && (s = 2), e.dbl &&= (s *= 2, !1), o === "r") {
		if (t.bookSet === 1) e.o >= 3 ? s += 2 : e.o >= 1 && (s += 1);
		else if (t.bookSet === 3) {
			let t = e.chips[e.chips.length - 1];
			t && S[t] === "w" && (s += C[t]);
		}
	}
	if (a === "w1" && t.bookSet === 4 && e.r >= 1 && (s = 2), o === "y" && t.bookSet === 4) {
		let t = e.y + 1;
		t <= 3 && (s += t);
	}
	o === "y" && t.bookSet === 2 && (e.dbl = !0);
	let c = e.positions.length > 0 ? e.positions[e.positions.length - 1] : e.base;
	e.positions.push(Math.min(c + s, E)), e.chips.push(a), o === "o" ? e.o += 1 : o === "r" ? e.r += 1 : o === "y" && (e.y += 1), o === "w" && (e.whiteSum += C[a], e.whiteSum > r && (e.busted = !0));
}
function Gt(e, t) {
	let n = e.positions.length > 0 ? e.positions[e.positions.length - 1] : e.base;
	for (let t of e.aside) n = Math.min(n + C[t], E);
	let [r, i, a] = T[Math.min(n + 1, T.length - 1)], o = r * t.moneyW + i + (a ? t.rubyW : 0);
	return e.busted ? o - Math.min(r * t.moneyW, i) * t.riskW : o;
}
function Kt(e, t, n, r) {
	let i = e.threshold, a = Ht(Vt(e, t)), o = 0;
	for (let s = 0; s < r.rolloutK; s += 1) {
		let s = Ut(e, t, n);
		for (Wt(s, n, a, i); !s.busted && s.bag.length > 0;) {
			let e = s.chips[s.chips.length - 1];
			if (s.flask && e && S[e] === "w" && s.whiteSum >= i - r.flaskRoom) {
				s.chips.pop(), s.positions.pop(), s.whiteSum -= C[e], s.bag.push(e), s.flask = !1;
				continue;
			}
			if (s.positions[s.positions.length - 1] >= E) break;
			let t = i - s.whiteSum, o = 0;
			for (let e of s.bag) S[e] === "w" && C[e] > t && (o += 1);
			if (o / s.bag.length > r.rollTheta) break;
			Wt(s, n, a, i);
		}
		o += Gt(s, r);
	}
	return o / r.rolloutK;
}
function qt(e, t, n, r) {
	if (t.length === 0) return !1;
	if (e.pot.length === 0) return !0;
	let i = Bt(zt(e), r), a = Kt(e, t, n, r), o = r.pushBonus;
	if (n.round >= 7) {
		let t = Math.max(...n.players.filter((t) => t.rid !== e.rid).map((e) => e.score));
		o += r.catchUpW * Math.max(0, t - e.score);
	}
	return a + o > i;
}
function Jt(e, t, n, r) {
	let i = r ?? e.settle?.money ?? 0;
	if (i <= 0 || t.round >= 9) return [];
	let a = {
		w: 0,
		o: n.wo,
		g: n.wg,
		b: n.wb,
		r: n.wr,
		y: n.wy,
		p: n.wp,
		k: n.wk,
		t: n.wt
	}, o = {
		...t.expansion ? { o6: 22 } : {},
		...O[t.bookSet]
	}, s = Object.keys(o).filter((e) => !(o[e] > i || S[e] === "y" && t.round < 2 || S[e] === "p" && t.round < 3)), c = (e) => a[S[e]] * C[e] * (Lt[t.bookSet][S[e]] ?? 1), l = [], u = 0;
	for (let e = 0; e < s.length; e += 1) {
		let t = s[e], r = o[t], a = c(t) / r ** +n.buyEffic;
		a > u && (u = a, l = [t]);
		for (let a = e + 1; a < s.length; a += 1) {
			let e = s[a];
			if (S[t] === S[e]) continue;
			let d = o[e];
			if (r + d > i) continue;
			let f = (c(t) + c(e)) / (r + d) ** +n.buyEffic;
			f > u && (u = f, l = [t, e]);
		}
	}
	return l;
}
function Yt(e = It) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.players.find((e) => e.rid === n.rid);
		if (!a || !i) return null;
		let o = i.pending[0];
		if (o) {
			if (o.kind === "bluePick" || o.kind === "strongPick") {
				let e = (e) => o.kind === "bluePick" ? { action: {
					type: "bluePick",
					index: e
				} } : { action: {
					type: "strongPick",
					index: e
				} }, t = o.options ?? [];
				if (t.length === 0) return e(null);
				if (n.difficulty === "weak") return e(Rt(t.map((e, t) => t)));
				let r = t.map((e, t) => ({
					c: e,
					i: t
				})).filter((e) => S[e.c] !== "w");
				if (r.length > 0) {
					let t = r.sort((e, t) => C[t.c] - C[e.c])[0];
					return e(t.i);
				}
				let i = a.threshold - a.whiteSum, s = t.map((e, t) => ({
					c: e,
					i: t
				})).filter((e) => C[e.c] <= i);
				return s.length > 0 ? e(s.sort((e, t) => C[e.c] - C[t.c])[0].i) : e(null);
			}
			if (o.kind === "dropletAssign") return { action: {
				type: "dropletAssign",
				tube: Math.min(a.dropletQueue, M - a.tube)
			} };
			if (o.kind === "fRatsFriends") return { action: {
				type: "fRatsFriends",
				chip: a.rats >= 4 ? null : "g4"
			} };
			if (o.kind === "fGoodStart") return { action: {
				type: "fGoodStart",
				giveUp: 0
			} };
			if (o.kind === "fMoment") {
				let e = (o.options ?? []).findIndex((e) => w[e]);
				return { action: {
					type: "fMoment",
					index: e >= 0 ? e : null
				} };
			}
			if (o.kind === "fJustInTime") return { action: {
				type: "fJustInTime",
				remove: i.bag.includes("w1") && i.bag.length > 4
			} };
			if (o.kind === "fKeepOne") return { action: {
				type: "fKeepOne",
				kind: "c2",
				chip: "b2"
			} };
			if (o.kind === "fWheel") return { action: {
				type: "fWheel",
				chip: a.rubies > 1 ? "g1" : null
			} };
			if (o.kind === "fChooseWisely") return { action: {
				type: "fChooseWisely",
				purple: !i.bag.includes("p1")
			} };
			if (o.kind === "malicious") return { action: {
				type: "maliciousPick",
				chip: "b2"
			} };
			if (o.kind === "greenSwap") return { action: {
				type: "greenSwap",
				choices: (o.idxs ?? []).map((e) => {
					let t = a.pot[e]?.chip;
					return t === "g1" ? "o1" : t === "g2" ? "b1" : null;
				})
			} };
			if (o.kind === "greenRuby") return { action: {
				type: "greenRuby",
				count: a.rubies > 2 ? o.n ?? 0 : 0
			} };
			if (o.kind === "purpleTier") return { action: {
				type: "purpleTier",
				tier: o.n ?? 0
			} };
			if (o.kind === "purpleUpgrade") {
				let e = o.n ?? 1, t = e === 2 ? 2 : 1, n = a.pot.findIndex((e) => C[e.chip] === t && w[e.chip]);
				return { action: {
					type: "purpleUpgrade",
					index: n >= 0 ? n : null,
					tier: e
				} };
			}
			if (o.kind === "yellowRuby") return { action: {
				type: "yellowRuby",
				use: a.rubies > 2
			} };
			if (o.kind === "greenStart") {
				let e = o.n ?? 0, t = null, n = 0;
				return a.pot.forEach((r, i) => {
					let a = C[r.chip];
					a <= e && a > n && (n = a, t = i);
				}), { action: {
					type: "greenStart",
					index: t
				} };
			}
			if (o.kind === "purpleBuy") return { action: {
				type: "purpleBuy",
				chips: Jt(a, r, e, o.n ?? 0)
			} };
			if (o.kind === "witchAllBonus") return { action: {
				type: "witchYesNo",
				yes: !1
			} };
			if (o.kind === "witchGoldRuby") return { action: {
				type: "witchYesNo",
				yes: (a.settle?.vp ?? 0) >= 3
			} };
			if (o.kind === "witchColors") return { action: {
				type: "witchYesNo",
				yes: new Set(a.pot.map((e) => S[e.chip]).filter((e) => e !== "w")).size >= 6
			} };
			if (o.kind === "witchBag") return { action: {
				type: "witchYesNo",
				yes: i.bag.filter((e) => S[e] !== "w" && (e === "p1" || e === "t1" || C[e] >= 2)).length >= 4
			} };
			if (o.kind === "bustChoice") {
				let t = a.settle?.money ?? 0, n = a.settle?.vp ?? 0;
				return { action: {
					type: "bustChoice",
					points: r.round >= 9 ? n >= t / 5 : t < e.bustMoneyMax
				} };
			}
		}
		if (r.phase === "draw" && !a.done) {
			if (a.finishing) return a.aside.length > 0 ? { action: {
				type: "placeAside",
				index: 0
			} } : a.asideAny.length > 0 ? { action: {
				type: "placeAsideAny",
				index: 0
			} } : { action: { type: "confirmDone" } };
			if (n.difficulty === "weak") return a.pot.length > 0 && Rt([!0, !1]) ? { action: { type: "stop" } } : { action: { type: "draw" } };
			let t = a.pot[a.pot.length - 1];
			return a.wellStirred && a.whiteSum >= a.threshold - 2 && a.pot.some((e) => S[e.chip] === "w") ? { action: { type: "wellStirred" } } : a.flaskFull && t && S[t.chip] === "w" && a.whiteSum >= a.threshold - e.flaskRoom ? { action: { type: "flask" } } : a.secondChance && a.drawn >= 5 && a.whiteSum >= a.threshold - 1 && zt(a) < 25 ? { action: { type: "secondChance" } } : a.strong && a.pot.length === 0 && i.bag.length > 0 ? { action: { type: "strongStart" } } : qt(a, i.bag, r, e) ? { action: { type: "draw" } } : { action: { type: "stop" } };
		}
		if (r.phase === "settle" && a.settle) {
			if (a.settle.step === "buy") return { action: {
				type: "buy",
				chips: Jt(a, r, e)
			} };
			if (a.settle.step === "f") {
				let t = !a.flaskFull && a.rubies >= e.refillMin, n = Math.floor((a.rubies - (t ? 2 : 0)) / 2), i = 0;
				return r.trialPot && (i = Math.min(n, M - a.tube, e.tubePairMax), n -= i), { action: {
					type: "roundEnd",
					pot: Math.min(n, e.potPairMax),
					tube: i,
					refill: t
				} };
			}
		}
		return null;
	};
}
var Xt = Yt(), Zt = (e, t, n) => e.type === "draw" ? n("games.quacks.hintDraw") : e.type === "stop" ? n("games.quacks.hintStop") : e.type === "flask" ? n("games.quacks.hintFlask") : e.type === "wellStirred" ? n("games.quacks.hintWellStirred") : e.type === "secondChance" ? n("games.quacks.hintSecondChance") : e.type === "strongStart" ? n("games.quacks.hintStrong") : e.type === "buy" ? n("games.quacks.hintBuy") : e.type === "bustChoice" ? n(e.points ? "games.quacks.hintBustPoints" : "games.quacks.hintBustBuy") : "";
//#endregion
//#region src/games/quacks/fx.tsx
function Q({ k: e, vars: t, className: n }) {
	let r = s();
	return /* @__PURE__ */ p("span", {
		className: n,
		children: r(e, t)
	});
}
function $(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Qt(e, t) {
	return e === "vp1" ? /* @__PURE__ */ p(Q, {
		k: "games.quacks.dieVp",
		vars: { n: 1 }
	}, t) : e === "vp2" ? /* @__PURE__ */ p(Q, {
		k: "games.quacks.dieVp",
		vars: { n: 2 }
	}, t) : e === "ruby" ? /* @__PURE__ */ p(Q, { k: "games.quacks.dieRuby" }, t) : e === "droplet" ? /* @__PURE__ */ p(Q, { k: "games.quacks.dieDroplet" }, t) : /* @__PURE__ */ p(Q, { k: "games.quacks.dieO1" }, t);
}
var $t = {
	roundStart(e, t) {
		let n = t.anchor("pot"), r = e.data?.round;
		return !n || !r ? null : {
			ms: 1e3,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 1e3,
				children: /* @__PURE__ */ p(Q, {
					k: "games.quacks.roundShort",
					vars: { n: r },
					className: "rounded-xl border-2 border-ink bg-surface px-3 py-1 font-display text-lg font-extrabold"
				})
			})
		};
	},
	fortune(e, t) {
		let n = t.anchor("pot"), r = e.data?.card;
		return !n || !r ? null : {
			ms: 1400,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 1400,
				children: /* @__PURE__ */ m("span", {
					className: "rounded-xl border-2 border-ink bg-surface px-3 py-1.5 text-sm font-extrabold shadow-[3px_3px_0_var(--color-ink)]",
					children: ["🔮 ", /* @__PURE__ */ p(Q, { k: tt[r] })]
				})
			})
		};
	},
	draw(e, t) {
		let n = e.data, r = $(t, e.rid);
		return !n?.chip || !r && !n.exploded ? null : {
			ms: 900,
			node: /* @__PURE__ */ m(f, { children: [
				n.exploded && /* @__PURE__ */ p(g, { ms: 700 }),
				r && /* @__PURE__ */ p(_, {
					at: r,
					ms: 800,
					children: /* @__PURE__ */ p(W, {
						chip: n.chip,
						size: 32
					})
				}),
				n.exploded && r && /* @__PURE__ */ p(_, {
					at: r,
					ms: 900,
					delay: 150,
					children: /* @__PURE__ */ p("span", {
						className: "text-xl",
						children: "💥"
					})
				})
			] })
		};
	},
	aside(e, t) {
		let n = e.data, r = $(t, e.rid);
		return !n?.chip || !r ? null : {
			ms: 700,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 700,
				children: /* @__PURE__ */ p(W, {
					chip: n.chip,
					size: 28
				})
			})
		};
	},
	stop(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ p("span", {
					className: "text-lg",
					children: "✋"
				})
			})
		} : null;
	},
	flask(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ p("span", {
					className: "text-lg",
					children: "⚗️"
				})
			})
		} : null;
	},
	secondChance(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ p("span", {
					className: "text-lg",
					children: "↩️"
				})
			})
		} : null;
	},
	die(e, t) {
		let n = e.data, r = $(t, e.rid);
		return !n?.faces || !r ? null : {
			ms: 1100,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 1100,
				children: /* @__PURE__ */ m("span", {
					className: "rounded-lg border-2 border-ink bg-surface px-2 py-0.5 text-xs font-extrabold",
					children: ["🎲 ", n.faces.map((e, t) => Qt(e, t))]
				})
			})
		};
	},
	buy(e, t) {
		let n = e.data, r = $(t, e.rid);
		return !n?.chips || n.chips.length === 0 || !r ? null : {
			ms: 900,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 900,
				children: /* @__PURE__ */ p("span", {
					className: "flex gap-1",
					children: n.chips.map((e, t) => /* @__PURE__ */ p(W, {
						chip: e,
						size: 26
					}, t))
				})
			})
		};
	},
	droplet(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ p("span", {
					className: "text-lg",
					children: "💧"
				})
			})
		} : null;
	},
	settleDone(e, t) {
		let n = t.anchor("pot");
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ p("span", {
					className: "text-xl",
					children: "✅"
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/quacks/game-over.tsx
function en({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ p(d, {
		adaptive: !0,
		scroll: !1,
		className: "quacks-result-screen",
		children: /* @__PURE__ */ p("div", {
			className: "quacks-result",
			children: /* @__PURE__ */ p(v, {
				hintCount: e,
				result: t,
				members: n,
				myRid: r,
				accent: P.accent,
				onPlayAgain: i,
				onBackToLobby: a
			})
		})
	});
}
//#endregion
//#region src/games/quacks/options.tsx
function tn({ value: e, onChange: t }) {
	let n = s(), r = ie.safeParse(e), i = r.success ? r.data : ie.parse(void 0), a = (e, t, n, r, i) => /* @__PURE__ */ p(x, {
		checked: e,
		label: n,
		hint: r,
		accent: P.accent,
		onChange: t
	}, i);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ p(b, {
				title: n("games.quacks.optBookSet"),
				columns: 3,
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((e) => {
					let r = e >= 5 && !i.herbWitches;
					return /* @__PURE__ */ p(y, {
						name: "quacks-book-set",
						value: String(e),
						checked: i.bookSet === e,
						disabled: r,
						label: n("games.quacks.optBookSetN", { n: e }),
						hint: r ? n("games.quacks.optBookExpansionLock") : void 0,
						accent: P.accent,
						onChange: () => t({
							...i,
							bookSet: e
						})
					}, e);
				})
			}),
			a(i.fortune, () => t({
				...i,
				fortune: !i.fortune
			}), n("games.quacks.optFortune"), n("games.quacks.optFortuneDesc"), "fortune"),
			a(i.trialPot, () => t({
				...i,
				trialPot: !i.trialPot
			}), n("games.quacks.optTrialPot"), n("games.quacks.optTrialPotDesc"), "trialPot"),
			/* @__PURE__ */ m("button", {
				type: "button",
				"aria-pressed": i.herbWitches,
				className: `quacks-option-expansion card min-h-11 cursor-pointer p-2 text-left ${i.herbWitches ? "is-active" : ""}`,
				onClick: () => t({
					...i,
					herbWitches: !i.herbWitches,
					bookSet: i.herbWitches ? Math.min(i.bookSet, 4) : i.bookSet
				}),
				children: [
					/* @__PURE__ */ m("span", {
						className: "quacks-option-sigils",
						"aria-hidden": !0,
						children: [
							/* @__PURE__ */ p(K, {
								witch: "silverSix",
								size: 21
							}),
							/* @__PURE__ */ p(K, {
								witch: "copperDouble",
								size: 21
							}),
							/* @__PURE__ */ p(K, {
								witch: "goldCheap",
								size: 21
							})
						]
					}),
					/* @__PURE__ */ m("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ p("strong", {
							className: "block text-sm",
							children: n("games.quacks.optHerbWitches")
						}), /* @__PURE__ */ p("small", {
							className: "block text-xs text-ink/70",
							children: n("games.quacks.optHerbWitchesDesc")
						})]
					}),
					/* @__PURE__ */ p("span", {
						className: "quacks-option-state",
						children: n(i.herbWitches ? "games.quacks.optExpansionOn" : "games.quacks.optExpansionOff")
					})
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/quacks/entry.tsx
var nn = {
	definition: We,
	View: Pt,
	bot: Xt,
	describe: Zt,
	fx: $t,
	OverView: en,
	Options: tn,
	locales: {
		zh: {
			name: "郎中闯江湖",
			desc: "往锅里一味味加料熬药,白片超量就爆锅",
			rules: "目标:游戏共进行 9 轮,计分轨得分最高者获胜;若平分,最后一轮锅中进度更远者获胜。\n准备:\n· 芯片以「颜色+面值」表示,如白 2 即白色 2 值芯片。\n· 每位玩家的起始袋中有 4 枚白色 1 值芯片、2 枚白色 2 值芯片、1 枚白色 3 值芯片，以及橙色 1 值芯片和绿色 1 值芯片各 1 枚。另获得 1 枚红宝石和 1 个装满的烧瓶。\n· 配料书按开局所选套数生效;黄色芯片第 2 轮起开放购买,紫色芯片第 3 轮起开放。\n流程:\n· 每轮开始翻开 1 张预言卡:紫色卡立即结算,蓝色卡持续生效至本轮结束。\n· 第 2 轮起,落后者按与领先者相差的鼠尾数,获得锅内起手位置加成。\n· 熬药:从自己袋中盲抽芯片,自水滴位置起沿锅轨前进该片面值格数,可随时停手。\n· 白色芯片是会引发爆炸的药材。当锅内白色芯片的面值之和超过 7 时，立即爆锅，必须结束本轮熬药。\n· 烧瓶可将最后抽到的白片放回袋中,每次装满只能使用一次。\n· 放置红色、蓝色或黄色芯片时，立即触发对应配料书的能力。绿色、紫色和黑色配料书的能力在结算阶段触发。\n结算(按序):\n· 奖励骰：在没有爆锅的玩家中，结算格购买额度最高的玩家掷 1 次奖励骰。购买额度相同时，比较锅内进度；仍然相同的玩家均可掷骰。\n· 芯片动作:结算黑、绿、紫书能力。\n· 红宝石:结算格带有红宝石标记则获得 1 枚红宝石,爆锅者同样获得。\n· 得分:按结算格分数前进计分轨;爆锅者只能在得分与购买之间二选一。\n· 购买：使用结算格提供的购买额度，购买 1 枚或 2 枚颜色不同的芯片，并将它们放入自己的袋中。未使用的额度不能保留。\n· 轮末:每支付 2 枚红宝石可将水滴推前 1 格,次数不限;可支付 2 枚红宝石补满烧瓶,每轮限一次。\n结束:\n· 第 6 轮开始时,每名玩家将一枚白色 1 值芯片加入自己的袋中。\n· 第 9 轮结束后，每剩余 5 钱币可换取 1 分，每剩余 2 枚红宝石可换取 1 分。\n试炼大锅(可选变体):\n· 水滴前进时,可将进度自由分配给锅轨与试管奖励轨。\n· 试管轨共 12 格,每前进 1 格立即领取该格奖励(红宝石、分数或指定芯片);轮末也可用红宝石推进试管轨。\n草药女巫(可选扩展):\n· 支持第 5 人;开局从银、铜、金三色女巫中各随机翻 1 张生效。\n· 每人持银、铜、金便士各 1 枚,整局各用 1 次,未使用的便士终局每个计 2 分。\n· 溢流碗:芯片到达锅底最后一格后,继续抽的片放入溢流碗。\n· 溢流碗中的彩色芯片不触发能力，白色芯片的面值仍计入爆炸值。结算时，将碗内全部芯片的面值相加，除以 2 后向下取整，获得等量分数。\n· 新配料痴愚草为青色芯片，没有固定面值。放置时，根据所选配料书确定其面值。新的南瓜配料书加入面值为 6 的南瓜芯片；所有升级效果均不能用于南瓜芯片。\n· 第 5 套和第 6 套配料书提供新的能力，启用扩展后可以使用。",
			roundShort: "第 {{n}} 轮",
			phaseFortune: "预言卡",
			phaseDraw: "熬药",
			phaseSettle: "结算",
			waitOthers: "等待其他玩家",
			optBookSet: "配料书套数",
			optBookSetN: "第 {{n}} 套",
			optFortune: "预言卡",
			optFortuneDesc: "每轮翻 1 张:紫卡立即结算,蓝卡整轮生效",
			optTrialPot: "试炼大锅(试管奖励轨)",
			optTrialPotDesc: "水滴前进时可改推试管轨,逐格领奖",
			draw: "从布袋抽一片",
			stop: "就此停手",
			riskTitle: "白片风险",
			flaskReady: "烧瓶可用",
			flaskUsed: "烧瓶已用",
			asideLabel: "锅旁",
			potAria: "药锅与螺旋配料轨道",
			rewardPreview: "下格收益 · 第 {{n}} 格",
			rewardSettlement: "结算格 · 第 {{n}} 格",
			marketTitle: "我的配料书",
			marketRule: "买至多两种",
			marketRemaining: "{{n}} / {{m}} 钱",
			marketBookSet: "第 {{n}} 套 · 至多购买两种颜色",
			marketUnlock: "第 {{n}} 轮开放",
			ingredientO: "南瓜",
			ingredientG: "花园蜘蛛",
			ingredientB: "乌鸦头骨",
			ingredientR: "毒蝇伞",
			ingredientY: "曼德拉草",
			ingredientP: "幽灵呼吸",
			ingredientK: "鬼脸天蛾",
			ingredientT: "痴愚草",
			bookO: "按面值前进，没有额外能力。",
			bookOExpansion: "按面值前进，没有额外能力；南瓜不可升级。",
			bookG1: "结算时，最后或倒数第二片为绿片，每片获得 1 枚红宝石。",
			bookB1: "放入后，再抽取与蓝片面值等量的芯片，可选 1 片放入，其余放回袋中。",
			bookR1: "锅内已有 1–2 片橙片时多走 1 格；3 片及以上时多走 2 格。",
			bookY1: "放入时，若上一片为白片，将该白片放回袋中。",
			bookP1: "结算时，1 片：1 分；2 片：1 分及 1 红宝石；3 片及以上：2 分，水滴前进 1 格。",
			bookG2: "结算时，末两片中的绿片可换片入袋：绿 1 换橙 1；绿 2 换蓝 1 或红 1；绿 4 换黄 1 或紫 1。",
			bookB2: "放入后，接下来与蓝片面值等量的抽片次数内若爆锅，仍可得分和购买，但不能掷奖励骰。",
			bookR2: "抽到后先放在锅旁，之后任一轮停手时可选择放入。",
			bookY2: "放入后，下一片按面值的两倍前进。",
			bookP2: "结算时，可交回 1–3 片紫片，换取对应档位的芯片、分数、红宝石与水滴奖励。",
			bookG3: "结算时，若白片总和恰为 7，最后一片额外前进锅内绿片面值之和。",
			bookB3: "放在红宝石格上时，立即获得 1 枚红宝石。",
			bookR3: "放入时，若上一片为白片，额外前进该白片的面值。",
			bookY3: "锅内第 1 片黄片将爆锅阈值提高至 8，第 3 片提高至 9。",
			bookP3: "结算时，每片紫片按所在格得分：第 10–19 格得 1 分，第 20–29 格得 2 分，第 30 格及以后得 3 分。",
			bookG4: "结算时，末两片中的每片绿片可支付 1 枚红宝石，使水滴前进 1 格。",
			bookB4: "放在红宝石格上时，立即获得等于蓝片面值的分数。",
			bookR4: "锅内有红片后，白 1 前进 2 格，爆锅计数仍按 1 计算。",
			bookY4: "本轮第 1、2、3 片黄片分别多走 1、2、3 格，之后无额外效果。",
			bookP4: "结算时，按紫片数量升级锅内 1 片：1 片可从 1 升 2；2 片可从 2 升 4；3 片及以上可从 1 升 4。",
			bookG5: "结算时，最后或倒数第二片为绿片，每片可掷 1 次奖励骰。",
			bookB5: "放入时，查看之前与蓝片面值等量的芯片，每片白 1 使你获得 1 枚红宝石。",
			bookR5: "放入后，再抽 1 片置于锅旁，本轮可择时放入；置旁白片仍计入爆锅值。",
			bookY5: "放入时，可支付 1 枚红宝石，额外前进 3 格。",
			bookP5: "结算时，每片紫片获得等于其后一片面值的分数。",
			bookG6: "结算时，若末两片中有绿片，可选锅内 1 片作为下轮起手片，面值不超过该绿片。",
			bookB6: "放入时，若锅内橙片数量不少于蓝片面值，立即获得等于蓝片面值的分数。",
			bookR6: "按锅内最高的红片面值前进，包含正在放入的这片。",
			bookY6: "放入后，再抽 1 片；黄片额外前进该片面值，该片放回袋中。抽到痴愚草按 1 计算。",
			bookP6: "结算时，紫片所在格的分数之和可用于额外购买至多两种颜色的芯片。",
			bookKTwo: "结算时，黑片数不少于对手：水滴前进 1 格；多于对手时，另得 1 枚红宝石。",
			bookKMany: "结算时，黑片数多于至少一名邻座：水滴前进 1 格；多于左右两名邻座时，另得 1 枚红宝石。",
			bookK5: "结算时，位置最靠前的黑片使水滴前进 1 格，次靠前的获得 1 枚红宝石；并列均领奖。",
			bookK6: "买入的黑片放入左邻袋中，自己的水滴前进 1 格。结算时，左邻锅内每片黑片使你获得 1 枚红宝石；黑片在末两位时，左邻也获得 1 枚。",
			bookT5: "复制锅内最近一片其他彩色芯片的面值与能力；若没有，则前进 1 格。",
			bookT6: "按本轮鼠尾数加 1 前进，最多前进 4 格。",
			marketPrice: "价格 {{n}} 钱",
			marketCost: "{{n}} 钱",
			marketSelected: "已选",
			marketAvailable: "可买",
			marketInsufficient: "钱不足",
			marketLimit: "限两种",
			flask: "烧瓶:放回最后白片",
			confirmDone: "完成",
			placeAsideN: "放上红 {{n}}",
			whiteSum: "白片 {{n}}/{{m}}",
			bagLeft: "袋余 {{n}}",
			explodedTag: "爆锅",
			doneTag: "已停手",
			shieldTag: "护盾",
			wellStirredBtn: "搅匀:放回首个白片",
			secondChanceBtn: "重开本轮",
			strongBtn: "猛料:抽 5 选 1",
			promptBluePick: "蓝片生效:选 1 片放上,其余回袋",
			promptStrongPick: "猛料:选 1 片放上,其余回袋",
			pickNone: "全部放回",
			promptDropletAssign: "水滴前进 {{n}} 格:推锅还是推试管",
			dropletPot: "锅前进 {{n}} 格",
			dropletTube: "试管前进 {{n}} 格",
			promptRatsFriends: "选 1 个 4 级芯片,或按鼠尾数得分",
			takeRatsVp: "拿 {{n}} 分",
			promptGoodStart: "可放弃最多 3 条鼠尾,每条换 1 红宝石",
			goodStartKeep: "保留鼠尾",
			goodStartTrade: "放弃 {{n}} 条",
			promptMoment: "机遇:选 1 片换同色高一级",
			momentSkip: "不换",
			promptJustInTime: "及时:拿 4 分,或移除袋中 1 个白 1",
			takeVp: "拿 {{n}} 分",
			removeW1: "移除 1 个白 1",
			promptKeepOne: "三选一,只能留一个",
			keepBlack: "拿 1 个黑片",
			keepChip2: "拿 1 个 2 级芯片",
			keepRubies: "拿 3 个红宝石",
			promptWheel: "可付 1 红宝石换 1 个 1 级芯片",
			wheelSkip: "不换",
			promptChooseWisely: "水滴前进 2 格,或拿 1 个紫片",
			takeDroplets: "水滴前进 {{n}} 格",
			takePurple: "拿 1 个紫片",
			promptMalicious: "右邻爆锅,任选 1 个 2 级芯片",
			promptGreenSwap: "末尾绿片可换片(不换则保持)",
			greenKeep: "不换",
			promptGreenRuby: "每片末尾绿片可付 1 红宝石换水滴前进 1 格",
			greenRubyN: "换 {{n}} 次",
			promptPurpleTier: "交回紫片换奖励(0 = 不换)",
			purpleTier1: "1 片:黑 1 + 1 分 + 1 红宝石",
			purpleTier2: "2 片:绿 1 + 蓝 2 + 3 分 + 水滴 1",
			purpleTier3: "3 片:黄 4 + 6 分 + 1 红宝石 + 水滴 2",
			promptPurpleUpgrade: "选锅内 1 片升级(第 {{n}} 档)",
			upgradeSkip: "放弃",
			promptBust: "爆锅:得分与购买二选一",
			bustPoints: "拿 {{n}} 分",
			bustBuy: "用 {{n}} 钱购买",
			spaceInfo: "结算格:钱 {{m}} · 分 {{v}}",
			spaceRuby: "红宝石格",
			buyTitle: "购买(余 {{n}} 钱)",
			buyTotal: "合计 {{n}} 钱",
			buyNone: "不买",
			buyConfirm: "确认购买",
			dieFaces: "奖励骰",
			dieVp: "+{{n}} 分",
			dieRuby: "+1 红宝石",
			dieDroplet: "水滴 +1",
			dieO1: "橙 1 入袋",
			roundEndTitle: "轮末:红宝石花销(余 {{n}})",
			refillFlask: "补满烧瓶(2)",
			pushPot: "水滴前进 1 格(2)",
			pushTube: "试管前进 1 格(2)",
			refillFlaskHalf: "补满烧瓶(1)",
			pushPotHalf: "水滴前进 1 格(1)",
			pushTubeHalf: "试管前进 1 格(1)",
			roundEndDone: "结束本轮",
			colorW: "白",
			colorO: "橙",
			colorG: "绿",
			colorB: "蓝",
			colorR: "红",
			colorY: "黄",
			colorP: "紫",
			colorK: "黑",
			cardSeasoned: "恰到火候",
			cardSeasonedDesc: "本轮白片总和恰好 7 的玩家水滴前进 1 格",
			cardLuckyDevil: "走运的家伙",
			cardLuckyDevilDesc: "本轮到达红宝石格额外多得 2 分(爆锅也算)",
			cardShining: "格外闪耀",
			cardShiningDesc: "本轮到达红宝石格额外多获得 1 枚红宝石",
			cardMalicious: "幸灾乐祸",
			cardMaliciousDesc: "本轮你爆锅时,左邻任选 1 个 2 级芯片",
			cardWellStirred: "搅拌均匀",
			cardWellStirredDesc: "本轮第一个白片可放回袋一次",
			cardPotFull: "满锅",
			cardPotFullDesc: "本轮掷奖励骰者掷两次",
			cardSecondChance: "再来一次",
			cardSecondChanceDesc: "抽满 5 片后可重开本轮一次",
			cardStrong: "猛料",
			cardStrongDesc: "熬药中可发动一次:抽 5 片选 1 放入",
			cardPumpkin: "南瓜派对",
			cardPumpkinDesc: "本轮橙片多走 1 格",
			cardMagicPotion: "魔法药剂",
			cardMagicPotionDesc: "本轮轮末烧瓶免费补满",
			cardRatsFriends: "老鼠之友",
			cardRatsFriendsDesc: "每人:任一 4 级芯片,或每鼠尾 1 分",
			cardRatInfestation: "鼠患",
			cardRatInfestationDesc: "本轮鼠尾翻倍",
			cardGoodStart: "良好开端",
			cardGoodStartDesc: "每人可放弃 1-3 条鼠尾,每条换 1 红宝石",
			cardLuxury: "生活奢靡",
			cardLuxuryDesc: "本轮爆锅阈值 7 提高到 9",
			cardDonations: "捐赠",
			cardDonationsDesc: "全员各掷 1 次奖励骰",
			cardBeginner: "新手优待",
			cardBeginnerDesc: "分数最低者得绿 1",
			cardMoment: "机遇时刻",
			cardMomentDesc: "抽 4 片,可换 1 片为同色高一级;不能换则拿绿 1",
			cardJustInTime: "及时雨",
			cardJustInTimeDesc: "拿 4 分,或移除袋中 1 个白 1",
			cardKeepOne: "只能留一个",
			cardKeepOneDesc: "三选一:黑 1 / 任一 2 级芯片 / 3 红宝石",
			cardWheel: "讨价还价",
			cardWheelDesc: "可付 1 红宝石换任一 1 级芯片(除紫黑)",
			cardLessIsMore: "少即是多",
			cardLessIsMoreDesc: "全员抽 5 片,总和最小者得蓝 2,其余得 1 红宝石",
			cardAlms: "施舍",
			cardAlmsDesc: "红宝石最少者得 1 红宝石",
			cardPotFilling: "锅快满了",
			cardPotFillingDesc: "全员水滴前进 1 格",
			cardChooseWisely: "谨慎选择",
			cardChooseWiselyDesc: "水滴前进 2 格,或拿 1 个紫片",
			errNotYourTurn: "现在轮不到你",
			errBadAction: "现在不能这么做",
			errBadChip: "不能选这个芯片",
			errBadChoice: "这个选择不合法",
			errTooExpensive: "钱不够",
			errSameColor: "一次只能买不同颜色的芯片",
			errNoRubies: "红宝石不够",
			hintDraw: "继续抽片",
			hintStop: "停手,保住当前成果",
			hintFlask: "用烧瓶放回最后的白片",
			hintWellStirred: "搅匀大锅:放回第一个白片",
			hintSecondChance: "用第二次机会重开本轮",
			hintStrong: "用强力开局抽五选一",
			hintBuy: "按预算买入芯片",
			hintBustPoints: "爆锅后选择拿分",
			hintBustBuy: "爆锅后选择购买",
			optHerbWitches: "草药女巫扩展",
			optHerbWitchesDesc: "第 5 人 + 女巫便士 + 溢流碗,解锁第 5/6 套配料书",
			optBookExpansionLock: "需开启草药女巫",
			optExpansionOn: "已开启",
			optExpansionOff: "点击开启",
			colorT: "青",
			pennySilver: "银便士",
			pennyCopper: "铜便士",
			pennyGold: "金便士",
			witchBarTitle: "草药女巫",
			pennyReady: "便士可用",
			pennyUsed: "便士已用",
			bowlLabel: "溢流碗",
			bowlBonus: "碗加分 +{{n}}",
			bowlEmpty: "待溢流",
			bowlScore: "+{{n}} 分",
			asideAnyLabel: "置旁",
			startChipLabel: "起手片",
			promptYellowRuby: "黄片生效:可付 1 红宝石,这片黄再多走 3 格",
			promptGreenStart: "绿片生效:选锅内 1 片作下轮起手片",
			promptPurpleBuy: "紫片生效:可用 {{n}} 钱额外购买",
			promptWitchSix: "银女巫:逐片点放,剩余回袋",
			promptWitchAllBonus: "银女巫:爆锅仍拿全部奖励(分+购买+掷骰资格)?",
			promptWitchGoldRuby: "金女巫:红宝石格改拿 {{n}} 枚红宝石?",
			promptWitchColors: "金女巫:按锅内颜色数拿分?",
			promptWitchBag: "金女巫:清空袋子按片拿分?",
			witchUse: "使用",
			witchSkip: "不用",
			witchFlaskBtn: "银女巫:烧瓶救回爆锅",
			witchSixBtn: "银女巫:抽 6 片",
			witchReturnBtn: "银女巫:丢回白片",
			witchUpgradeBtn: "铜女巫:锅内升档",
			witchUpgradeHint: "任选 1 片，或选锅内最后 2 片",
			witchReturnHint: "选最多 2 片白片放回袋中",
			witchDoubleBtn: "翻倍",
			witchCopyBtn: "复制",
			witchRubyBtn: "宝石加持",
			witchHalfBtn: "金女巫半价(1 红宝石/次)",
			witchSixDone: "收工,余片回袋",
			greenStartSkip: "不选",
			witchSilverFlask: "救锅妙手",
			witchSilverFlaskDesc: "整局一次:爆锅后若烧瓶仍满,可用烧瓶收回引爆的白片,继续熬药",
			witchSilverSix: "六片连抽",
			witchSilverSixDesc: "整局一次:从袋中抽 6 片,逐片自选放上,剩余回袋",
			witchSilverReturn: "白片回收",
			witchSilverReturnDesc: "整局一次:未爆锅时把锅内最多 2 张白片丢回袋中",
			witchSilverBonus: "爆锅无妨",
			witchSilverBonusDesc: "整局一次:爆锅仍拿全部奖励——得分、购买,若最前还可掷奖励骰",
			witchCopperUpgrade: "锅内升档",
			witchCopperUpgradeDesc: "整局一次:购买时把锅内最后两片各升一档,或任意一片升一档(南瓜除外)",
			witchCopperDouble: "双倍预算",
			witchCopperDoubleDesc: "整局一次:本轮购买值翻倍,仍限 2 片不同色",
			witchCopperCopy: "买一再一",
			witchCopperCopyDesc: "整局一次:购买后免费复制所买第 1 片",
			witchCopperRuby: "宝石加持",
			witchCopperRubyDesc: "整局一次:本轮每持有 1 枚红宝石,购买值 +2(不消耗红宝石)",
			witchGoldRubyVp: "红宝石雨",
			witchGoldRubyVpDesc: "整局一次:结算格有红宝石标记时,改拿等值于该格分数的红宝石",
			witchGoldCheap: "轮末半价",
			witchGoldCheapDesc: "整局一次:轮末推水滴、补烧瓶只需 1 红宝石/次",
			witchGoldColors: "缤纷一锅",
			witchGoldColorsDesc: "整局一次:按锅内不同颜色数(不含白)拿分:1-4 色 3 分,5 色 4 分,6 色 7 分,7 色 10 分,8 色 14 分",
			witchGoldBag: "袋中寻宝",
			witchGoldBagDesc: "整局一次:袋内每片彩色 2/4/6 值片、紫片与痴愚草片计 2 分"
		},
		en: {
			name: "Quacks of Quedlinburg",
			desc: "Push your luck brewing potions — too many white chips and the pot explodes",
			rules: "Goal: the game lasts 9 rounds; the player furthest along the score track wins. Ties go to the player whose pot advanced further in the final round.\nSetup:\n· Chips are written as color plus value, e.g. white 2 is a white chip of value 2.\n· Each player's starting bag contains four white chips of value 1, two of value 2, one of value 3, and one each of the orange and green chips of value 1. Each player also receives 1 ruby and 1 filled flask.\n· Ingredient books follow the set chosen at game start; yellow chips can be bought from round 2, purple chips from round 3.\nPlay:\n· Each round opens by revealing 1 fortune card: purple cards resolve at once, blue cards stay in effect until the round ends.\n· From round 2, anyone behind the leader gains a head start in the pot equal to the rat tails between them and the leader.\n· Brewing: draw chips blind from your bag; starting from the droplet, each chip advances along the pot track by its face value. You may stop at any time.\n· White chips are explosive: if their combined value in your pot exceeds 7, the pot explodes and your brewing ends at once.\n· The flask returns the last drawn white chip to your bag; each filling allows one use.\n· Red, blue and yellow book abilities trigger when a chip of that color is placed; green, purple and black book abilities trigger during scoring.\nScoring (in order):\n· Bonus die: Among players whose pots did not explode, the player with the highest buying value on their scoring space rolls the bonus die once. Break ties by progress along the pot track. If players are still tied, all tied players roll.\n· Chip actions: resolve black, green and purple book abilities.\n· Rubies: if the scoring space shows a ruby, gain 1 ruby; exploded players gain it as well.\n· Points: advance on the score track by the scoring space's points; exploded players choose either points or buying.\n· Buying: spend the scoring space's money on 1 or 2 chips of different colors for your bag; unspent money is lost.\n· End of round: every 2 rubies may advance your droplet by 1 space, without limit; 2 rubies refill the flask, once per round.\nEnd:\n· At the start of round 6, each player adds one white 1 to their bag.\n· After round 9, every 5 unspent money converts to 1 point, and every 2 leftover rubies convert to 1 point.\nThe Trial Pot (optional variant):\n· When the droplet advances, its progress may be split freely between the pot track and the test tube reward track.\n· The test tube track has 12 spaces; each space grants its reward (rubies, points or a named chip) as soon as it is reached. Rubies may also advance the test tube at the end of a round.\nThe Herb Witches (optional expansion):\n· Supports a 5th player; at setup, one witch of each penny color (silver, copper, gold) is revealed at random.\n· Each player holds one penny of each color, usable once per game; unspent pennies score 2 points each at the end.\n· Overflow bowl: once a chip reaches the final space, further drawn chips go to the overflow bowl.\n· Colored chips there trigger nothing, white chips still count toward exploding, and half the bowl's total face value (rounded down) scores.\n· The new locoweed (turquoise) chip has no fixed value. Determine its value when placing it, using the selected book set; the new pumpkin book adds pumpkin 6, and pumpkins can never be upgraded.\n· Book sets 5 and 6 bring all-new abilities and unlock with the expansion.",
			roundShort: "Round {{n}}",
			phaseFortune: "Fortune",
			phaseDraw: "Brewing",
			phaseSettle: "Scoring",
			waitOthers: "Waiting for the others",
			optBookSet: "Ingredient book set",
			optBookSetN: "Set {{n}}",
			optFortune: "Fortune cards",
			optFortuneDesc: "Reveal 1 each round: purple resolves at once, blue lasts all round",
			optTrialPot: "Trial pot (test tube track)",
			optTrialPotDesc: "Droplets may advance the test-tube reward track instead",
			draw: "Draw a chip",
			stop: "Stop brewing",
			riskTitle: "White risk",
			flaskReady: "Flask ready",
			flaskUsed: "Flask used",
			asideLabel: "Aside",
			potAria: "Potion cauldron and spiral ingredient track",
			rewardPreview: "Next space · {{n}}",
			rewardSettlement: "Scoring space · {{n}}",
			marketTitle: "My ingredient book",
			marketRule: "Up to two colors",
			marketRemaining: "{{n}} / {{m}} coins",
			marketBookSet: "Set {{n}} · Up to two colors",
			marketUnlock: "Opens in round {{n}}",
			ingredientO: "Pumpkin",
			ingredientG: "Garden spider",
			ingredientB: "Crow skull",
			ingredientR: "Toadstool",
			ingredientY: "Mandrake",
			ingredientP: "Ghost’s breath",
			ingredientK: "Hawk moth",
			ingredientT: "Locoweed",
			bookO: "Move by its value, with no extra ability.",
			bookOExpansion: "Move by its value. Pumpkins cannot be upgraded.",
			bookG1: "At scoring, each green chip in the last two positions earns 1 ruby.",
			bookB1: "After placing, draw as many chips as its value. You may place 1; return the rest to the bag.",
			bookR1: "Move 1 extra space with 1–2 orange chips already in the pot, or 2 extra with 3 or more.",
			bookY1: "When placed after a white chip, return that white chip to the bag.",
			bookP1: "At scoring, 1 purple: 1 point; 2: 1 point and 1 ruby; 3 or more: 2 points and advance the droplet 1 space.",
			bookG2: "At scoring, swap greens in the last two positions: green 1 for orange 1; green 2 for blue 1 or red 1; green 4 for yellow 1 or purple 1.",
			bookB2: "For the next draws equal to its value, an explosion still allows points and buying, but no bonus die.",
			bookR2: "Set aside when drawn. You may place it after stopping in this or a later round.",
			bookY2: "The next chip moves twice its value.",
			bookP2: "At scoring, return 1–3 purple chips for the matching tier of chips, points, rubies and droplet rewards.",
			bookG3: "At scoring, if white chips total exactly 7, advance the last chip by the total value of all green chips in the pot.",
			bookB3: "Gain 1 ruby immediately when placed on a ruby space.",
			bookR3: "When placed after a white chip, move extra spaces equal to that white chip’s value.",
			bookY3: "The first yellow raises the explosion threshold to 8; the third raises it to 9.",
			bookP3: "At scoring, each purple earns 1 point on spaces 10–19, 2 on spaces 20–29, or 3 on space 30 and beyond.",
			bookG4: "At scoring, pay 1 ruby for each green in the last two positions to advance the droplet 1 space.",
			bookB4: "When placed on a ruby space, immediately score points equal to its value.",
			bookR4: "With a red chip in the pot, white 1 chips move 2 spaces but still count as 1 toward exploding.",
			bookY4: "The first, second and third yellow chips this round move 1, 2 and 3 extra spaces. Later yellows get no bonus.",
			bookP4: "At scoring, upgrade 1 chip in the pot: with 1 purple, 1 to 2; with 2, 2 to 4; with 3 or more, 1 to 4.",
			bookG5: "At scoring, each green in the last two positions lets you roll the bonus die once.",
			bookB5: "Look back over as many chips as its value. Gain 1 ruby for each white 1 among them.",
			bookR5: "After placing, draw 1 chip and set it aside to place later this round. White chips set aside still count toward exploding.",
			bookY5: "When placed, you may pay 1 ruby to move 3 extra spaces.",
			bookP5: "At scoring, each purple earns points equal to the face value of the chip immediately after it.",
			bookG6: "At scoring, a green in the last two positions lets you choose a chip in your pot to start next round; its value cannot exceed that green’s.",
			bookB6: "If the pot has at least as many orange chips as this blue’s value, immediately score points equal to its value.",
			bookR6: "Move by the highest red value in the pot, including this chip.",
			bookY6: "After placing, draw 1 chip. Move this yellow extra spaces equal to its value, then return it to the bag. Locoweed counts as 1.",
			bookP6: "At scoring, the total points printed on the purple chips’ spaces buy up to two extra chip colors.",
			bookKTwo: "At scoring, match or exceed your opponent’s black chip count to advance the droplet 1 space; exceeding it also earns 1 ruby.",
			bookKMany: "At scoring, exceed either neighbor’s black chip count to advance the droplet 1 space; exceed both to also gain 1 ruby.",
			bookK5: "At scoring, the furthest black advances its owner’s droplet 1 space; the next furthest earns 1 ruby. All ties receive rewards.",
			bookK6: "Bought blacks go into your left neighbor’s bag; advance your droplet 1 space. At scoring, each black in their pot earns you 1 ruby; a black in their last two positions also earns them 1 ruby.",
			bookT5: "Copy the value and ability of the latest other colored chip in the pot. With none, move 1 space.",
			bookT6: "Move by this round’s rat tails plus 1, up to 4 spaces.",
			marketPrice: "Price {{n}} coins",
			marketCost: "{{n}} coins",
			marketSelected: "Chosen",
			marketAvailable: "Buy",
			marketInsufficient: "Too dear",
			marketLimit: "Limit 2",
			flask: "Flask: return last white",
			confirmDone: "Done",
			placeAsideN: "Place red {{n}}",
			whiteSum: "White {{n}}/{{m}}",
			bagLeft: "Bag {{n}}",
			explodedTag: "Busted",
			doneTag: "Stopped",
			shieldTag: "Shield",
			wellStirredBtn: "Stir: return first white",
			secondChanceBtn: "Restart round",
			strongBtn: "Strong: draw 5 keep 1",
			promptBluePick: "Blue: place 1 chip, return the rest",
			promptStrongPick: "Strong: place 1 chip, return the rest",
			pickNone: "Return all",
			promptDropletAssign: "Droplet advances {{n}}: pot or test tube?",
			dropletPot: "Pot +{{n}} spaces",
			dropletTube: "Tube +{{n}} spaces",
			promptRatsFriends: "Take a 4-value chip, or score per rat tail",
			takeRatsVp: "Take {{n}} pts",
			promptGoodStart: "Give up up to 3 rat tails, 1 ruby each",
			goodStartKeep: "Keep rats",
			goodStartTrade: "Give up {{n}}",
			promptMoment: "Opportunity: swap 1 chip for the next level of its color",
			momentSkip: "Skip",
			promptJustInTime: "Just in time: take 4 pts or remove a white 1 from your bag",
			takeVp: "Take {{n}} pts",
			removeW1: "Remove a white 1",
			promptKeepOne: "Pick one — you only keep one",
			keepBlack: "Take a black 1",
			keepChip2: "Take any 2-value chip",
			keepRubies: "Take 3 rubies",
			promptWheel: "Pay 1 ruby for any 1-value chip",
			wheelSkip: "Skip",
			promptChooseWisely: "Advance the droplet 2 spaces, or take a purple chip",
			takeDroplets: "Advance droplet {{n}}",
			takePurple: "Take a purple 1",
			promptMalicious: "Your neighbor exploded: take any 2-value chip",
			promptGreenSwap: "Trailing green chips may be swapped (keep otherwise)",
			greenKeep: "Keep",
			promptGreenRuby: "Pay 1 ruby per trailing green chip to advance the droplet 1 space",
			greenRubyN: "Pay for {{n}}",
			promptPurpleTier: "Return purple chips for rewards (0 = skip)",
			purpleTier1: "1: black 1 + 1 pt + 1 ruby",
			purpleTier2: "2: green 1 + blue 2 + 3 pts + droplet 1",
			purpleTier3: "3: yellow 4 + 6 pts + 1 ruby + droplet 2",
			promptPurpleUpgrade: "Upgrade 1 chip in your pot (tier {{n}})",
			upgradeSkip: "Skip",
			promptBust: "Busted: choose points or buying",
			bustPoints: "Take {{n}} pts",
			bustBuy: "Buy with {{n}}",
			buyTitle: "Buy ({{n}} left)",
			buyTotal: "Total: {{n}}",
			spaceInfo: "Space: {{m}} coins · {{v}} pts",
			spaceRuby: "Ruby space",
			buyNone: "Buy nothing",
			buyConfirm: "Confirm purchase",
			dieFaces: "Bonus die",
			dieVp: "+{{n}} pts",
			dieRuby: "+1 ruby",
			dieDroplet: "Droplet +1",
			dieO1: "Orange 1 to bag",
			roundEndTitle: "Round end: ruby spending ({{n}} left)",
			refillFlask: "Refill flask (2)",
			pushPot: "Advance droplet 1 space (2)",
			pushTube: "Advance test tube 1 space (2)",
			refillFlaskHalf: "Refill flask (1)",
			pushPotHalf: "Advance droplet 1 space (1)",
			pushTubeHalf: "Advance test tube 1 space (1)",
			roundEndDone: "End round",
			colorW: "White",
			colorO: "Orange",
			colorG: "Green",
			colorB: "Blue",
			colorR: "Red",
			colorY: "Yellow",
			colorP: "Purple",
			colorK: "Black",
			cardSeasoned: "Seasoned Perfectly",
			cardSeasonedDesc: "Players whose white chips total exactly 7 advance their droplet 1 space",
			cardLuckyDevil: "Lucky Devil",
			cardLuckyDevilDesc: "Reaching a ruby space scores 2 extra pts (even exploded)",
			cardShining: "Shining Extra Bright",
			cardShiningDesc: "Reaching a ruby space grants 1 extra ruby",
			cardMalicious: "Malicious Joy",
			cardMaliciousDesc: "When you explode, your left neighbor takes any 2-value chip",
			cardWellStirred: "Well Stirred",
			cardWellStirredDesc: "Your first white chip this round may be returned to the bag once",
			cardPotFull: "The Pot is Full",
			cardPotFullDesc: "Bonus die rollers roll twice this round",
			cardSecondChance: "A Second Chance",
			cardSecondChanceDesc: "After drawing 5 chips you may restart the round once",
			cardStrong: "Strong Ingredient",
			cardStrongDesc: "Once while brewing: draw 5 chips and place 1",
			cardPumpkin: "Pumpkin Patch Party",
			cardPumpkinDesc: "Orange chips move 1 extra space this round",
			cardMagicPotion: "Magic Potion",
			cardMagicPotionDesc: "Flasks refill for free at round end",
			cardRatsFriends: "Rats Are Your Friends",
			cardRatsFriendsDesc: "Each player: any 4-value chip, or 1 pt per rat tail",
			cardRatInfestation: "Rat Infestation",
			cardRatInfestationDesc: "Rat tails count double this round",
			cardGoodStart: "A Good Start",
			cardGoodStartDesc: "Each player may give up 1-3 rat tails for 1 ruby each",
			cardLuxury: "Living in Luxury",
			cardLuxuryDesc: "The explosion threshold rises from 7 to 9 this round",
			cardDonations: "Donations",
			cardDonationsDesc: "Everyone rolls the bonus die",
			cardBeginner: "Beginner's Bonus",
			cardBeginnerDesc: "The player(s) with the fewest points gain a green 1",
			cardMoment: "Moment of Opportunity",
			cardMomentDesc: "Draw 4 chips; swap 1 for the next level of its color, or take a green 1 if none qualify",
			cardJustInTime: "Just in Time",
			cardJustInTimeDesc: "Take 4 pts or remove a white 1 from your bag",
			cardKeepOne: "But You Only Get to Keep One!",
			cardKeepOneDesc: "Pick one: black 1 / any 2-value chip / 3 rubies",
			cardWheel: "Wheel and Deal",
			cardWheelDesc: "Pay 1 ruby for any 1-value chip (except purple/black)",
			cardLessIsMore: "Less is More",
			cardLessIsMoreDesc: "Everyone draws 5 chips; the lowest total gains a blue 2, the rest 1 ruby",
			cardAlms: "Alms",
			cardAlmsDesc: "The player(s) with the fewest rubies gain 1 ruby",
			cardPotFilling: "The Pot is Filling Up",
			cardPotFillingDesc: "Everyone advances their droplet 1 space",
			cardChooseWisely: "Choose Wisely",
			cardChooseWiselyDesc: "Advance the droplet 2 spaces, or take a purple chip",
			errNotYourTurn: "Not your turn",
			errBadAction: "Not allowed right now",
			errBadChip: "Cannot pick that chip",
			errBadChoice: "Invalid choice",
			errTooExpensive: "Not enough money",
			errSameColor: "Bought chips must be different colors",
			errNoRubies: "Not enough rubies",
			hintDraw: "Draw another chip",
			hintStop: "Stop and keep what you have",
			hintFlask: "Use the flask to return the last white chip",
			hintWellStirred: "Well stirred: return the first white chip",
			hintSecondChance: "Use second chance to restart the round",
			hintStrong: "Use strong start: draw five, pick one",
			hintBuy: "Buy chips within budget",
			hintBustPoints: "Busted: take the points",
			hintBustBuy: "Busted: buy instead",
			optHerbWitches: "Herb Witches expansion",
			optHerbWitchesDesc: "5th player + witch pennies + overflow bowl; unlocks book sets 5/6",
			optBookExpansionLock: "Requires Herb Witches",
			optExpansionOn: "Enabled",
			optExpansionOff: "Tap to enable",
			colorT: "Turq",
			pennySilver: "Silver penny",
			pennyCopper: "Copper penny",
			pennyGold: "Gold penny",
			witchBarTitle: "Herb Witches",
			pennyReady: "Penny ready",
			pennyUsed: "Penny spent",
			bowlLabel: "Overflow bowl",
			bowlBonus: "Bowl +{{n}}",
			bowlEmpty: "Empty",
			bowlScore: "+{{n}} pts",
			asideAnyLabel: "Set aside",
			startChipLabel: "Start chip",
			promptYellowRuby: "Yellow: pay 1 ruby to move this chip 3 more spaces",
			promptGreenStart: "Green: pick 1 chip in your pot as next round's start chip",
			promptPurpleBuy: "Purple: buy with up to {{n}} extra money",
			promptWitchSix: "Silver witch: place the 6 chips one by one; the rest return",
			promptWitchAllBonus: "Silver witch: keep ALL rewards despite exploding (points + buying + die)?",
			promptWitchGoldRuby: "Gold witch: take {{n}} rubies instead of 1 for the ruby space?",
			promptWitchColors: "Gold witch: score by distinct colors in your pot?",
			promptWitchBag: "Gold witch: score for qualifying chips in your bag?",
			witchUse: "Use",
			witchSkip: "Skip",
			witchFlaskBtn: "Silver witch: flask saves the bust",
			witchSixBtn: "Silver witch: draw 6",
			witchReturnBtn: "Silver witch: return whites",
			witchUpgradeBtn: "Copper witch: upgrade in pot",
			witchUpgradeHint: "Pick 1 chip, or the last 2 chips in your pot",
			witchReturnHint: "Return up to 2 white chips to your bag",
			witchDoubleBtn: "Double",
			witchCopyBtn: "Copy",
			witchRubyBtn: "Ruby boost",
			witchHalfBtn: "Gold witch: half price (1 ruby each)",
			witchSixDone: "Done; return the rest",
			greenStartSkip: "None",
			witchSilverFlask: "Pot Saver",
			witchSilverFlaskDesc: "Once per game: after exploding, if your flask is still full, use it to take back the busting white chip and keep brewing",
			witchSilverSix: "Sixfold Draw",
			witchSilverSixDesc: "Once per game: draw 6 chips, place them one by one in any order, return the rest",
			witchSilverReturn: "White Return",
			witchSilverReturnDesc: "Once per game: while not exploded, toss up to 2 white chips from your pot back into the bag",
			witchSilverBonus: "No Harm Done",
			witchSilverBonusDesc: "Once per game: an exploded pot still scores, buys, and rolls the bonus die if furthest ahead",
			witchCopperUpgrade: "Pot Upgrade",
			witchCopperUpgradeDesc: "Once per game: while buying, upgrade the last two chips in your pot by one step each, or any one chip (pumpkins excluded)",
			witchCopperDouble: "Double Budget",
			witchCopperDoubleDesc: "Once per game: double this round's buying power; still at most 2 chips of different colors",
			witchCopperCopy: "Buy One Get One",
			witchCopperCopyDesc: "Once per game: after buying, copy the first bought chip for free",
			witchCopperRuby: "Ruby Boost",
			witchCopperRubyDesc: "Once per game: +2 buying power per ruby you hold this round (rubies are not spent)",
			witchGoldRubyVp: "Ruby Rain",
			witchGoldRubyVpDesc: "Once per game: on a ruby scoring space, take rubies equal to that space's points instead of 1",
			witchGoldCheap: "Half Price",
			witchGoldCheapDesc: "Once per game: end-of-round droplet pushes and flask refills cost 1 ruby each",
			witchGoldColors: "Colorful Pot",
			witchGoldColorsDesc: "Once per game: score by distinct colors in your pot (white excluded): 1-4 colors 3 pts, 5 colors 4, 6 colors 7, 7 colors 10, 8 colors 14",
			witchGoldBag: "Bag Treasure",
			witchGoldBagDesc: "Once per game: each colored 2/4/6-value chip, purple chip and locoweed chip in your bag scores 2 pts"
		}
	}
};
//#endregion
export { nn as default };
