import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { IconCheck as d, IconClose as f, IconLog as p, IconPlay as m, IconSearch as h } from "@bgparty/sdk/icons";
import { GameScreen as g } from "@bgparty/sdk/ui/game-screen";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { CubeTexture as b, LinearFilter as ee, PerspectiveCamera as te, SRGBColorSpace as x, Scene as S, WebGLRenderer as ne } from "three";
import { Floater as re } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as C, OptionSection as ie } from "@bgparty/sdk/ui/game-options";
//#region \0bgparty-json:D:/Other/BG/BGParty/src/games/chroniclesofcrime/data/cases.json.mjs
var ae = await fetch("games/chroniclesofcrime/data/data/cases.json").then((e) => e.json()), w = /*#__PURE__*/ JSON.parse("[{\"id\":\"89e3683c-3f4a-4161-942f-35b50bb0ddfb\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i01\",\"name\":{\"zh\":\"食物\",\"en\":\"Food\"}},{\"id\":\"ae326a94-ac19-4f19-8194-c5e65e59588d\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i02\",\"name\":{\"zh\":\"纸张\",\"en\":\"Papers\"}},{\"id\":\"22a3d6bd-1702-4283-974e-8c3cdae7656d\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i03\",\"name\":{\"zh\":\"脚印和踪迹\",\"en\":\"Footprints & Traces\"}},{\"id\":\"f7abb6f5-084c-416e-9416-c491aed9598a\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i04\",\"name\":{\"zh\":\"车辆\",\"en\":\"Vehicles\"}},{\"id\":\"44e3a17b-63b0-49af-92ae-ccce82127b66\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i05\",\"name\":{\"zh\":\"血和人体组织\",\"en\":\"Blood & Organs\"}},{\"id\":\"a8c3370c-5141-47e7-849f-77512d134f16\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i06\",\"name\":{\"zh\":\"液体\",\"en\":\"Liquids\"}},{\"id\":\"d893b10b-8ad1-40a5-9d57-852eeba76997\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i07\",\"name\":{\"zh\":\"瓶子\",\"en\":\"Bottles\"}},{\"id\":\"e4beac69-6885-4782-ad09-52da2191801a\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i08\",\"name\":{\"zh\":\"药物\",\"en\":\"Medicine & Drugs\"}},{\"id\":\"96fc6d96-0703-43ef-8cf0-887309ca7296\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i09\",\"name\":{\"zh\":\"园艺工具\",\"en\":\"Gardening tools\"}},{\"id\":\"a65399a6-53ea-4b11-acf4-2818ee6bd422\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i10\",\"name\":{\"zh\":\"装饰\",\"en\":\"Decoration items\"}},{\"id\":\"3b523972-d82e-4011-b2c7-3476c2a70dce\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i30\",\"name\":{\"zh\":\"袋子和时尚饰品\",\"en\":\"Bags & Fashion\"}},{\"id\":\"5e4aa8dc-c2d8-4c59-aa3f-eeba10e1e799\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i29\",\"name\":{\"zh\":\"手作工具\",\"en\":\"DIY tools\"}},{\"id\":\"b7b25e51-4d9a-4641-83b3-c429648e6038\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i28\",\"name\":{\"zh\":\"动物\",\"en\":\"Animals\"}},{\"id\":\"9882ecf0-340c-45cb-b557-68dada4fa63a\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i27\",\"name\":{\"zh\":\"衣服\",\"en\":\"Clothes\"}},{\"id\":\"1e9d682f-3937-491f-b2b2-2842acb6e632\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i26\",\"name\":{\"zh\":\"寝具\",\"en\":\"Bedding\"}},{\"id\":\"4af7d291-b90a-4678-910e-1afa2819ad95\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i25\",\"name\":{\"zh\":\"办公室用品\",\"en\":\"Office materials\"}},{\"id\":\"987eaaa0-b758-4f6e-afe6-feff9615d683\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i24\",\"name\":{\"zh\":\"书本和杂志\",\"en\":\"Books & Magazines\"}},{\"id\":\"9ce88179-ba21-4dbc-a0a4-1b836e1f1781\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i23\",\"name\":{\"zh\":\"运动用品\",\"en\":\"Sport items\"}},{\"id\":\"d6d952e1-4ce5-42f9-9682-107977005477\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i22\",\"name\":{\"zh\":\"厨具\",\"en\":\"Kitchen utensils\"}},{\"id\":\"3d94ae14-94f0-44d7-89cc-973a9673a298\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i21\",\"name\":{\"zh\":\"照片和相机\",\"en\":\"Photos & Cameras\"}},{\"id\":\"61b5f3b9-b506-4e39-a6a2-be0a9fc0496a\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i20\",\"name\":{\"zh\":\"餐具\",\"en\":\"Tableware\"}},{\"id\":\"e85934eb-36f4-4fbc-9c3c-4654e5b08df3\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i19\",\"name\":{\"zh\":\"高科技设备\",\"en\":\"High Tech devices\"}},{\"id\":\"3c4c595e-8ce7-4b4d-9245-71698c58318c\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i18\",\"name\":{\"zh\":\"计算机设备\",\"en\":\"Computer devices\"}},{\"id\":\"9894615f-158a-4dc1-843b-713983424b5c\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i17\",\"name\":{\"zh\":\"钥匙和锁\",\"en\":\"Keys & Locks\"}},{\"id\":\"755d233b-57b3-4c92-8ea6-9e603610831b\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i16\",\"name\":{\"zh\":\"束带和拘束器\",\"en\":\"Cords & restraining devices\"}},{\"id\":\"4fd7432b-11cb-4973-a2bb-97359ed443ae\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i15\",\"name\":{\"zh\":\"通讯设备\",\"en\":\"Communiation devices\"}},{\"id\":\"1df593cb-39cc-497e-ad01-caac0d86f1d9\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i14\",\"name\":{\"zh\":\"枪支\",\"en\":\"Firearms\"}},{\"id\":\"c27c1228-3699-427b-8025-86ea4518b9a3\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i13\",\"name\":{\"zh\":\"家具\",\"en\":\"Furniture\"}},{\"id\":\"1fac024b-e7ae-467a-8586-a89f07092096\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i12\",\"name\":{\"zh\":\"近身武器\",\"en\":\"Melee weapons\"}},{\"id\":\"e9c5023e-8aba-45a1-b7c5-438c95cd64dd\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i11\",\"name\":{\"zh\":\"珠宝\",\"en\":\"Jewelry\"}},{\"id\":\"97bf8dfe-5b40-48bf-a662-c23de2c57c7a\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i31\",\"name\":{\"zh\":\"游戏和玩具\",\"en\":\"Games & Toys\"}},{\"id\":\"5df758f0-94ec-4461-9965-4c75142cf8dc\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i32\",\"name\":{\"zh\":\"植物\",\"en\":\"Plants\"}},{\"id\":\"61053212-3ef6-41ca-9d52-0d2e50b5a8b9\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i33\",\"name\":{\"zh\":\"盥洗用品\",\"en\":\"Toiletries & hygiene\"}},{\"id\":\"c5759738-480f-4c23-b529-92d792a4338b\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i34\",\"name\":{\"zh\":\"易燃物\",\"en\":\"Flammable objects\"}},{\"id\":\"e8e1d4ba-dcb7-4e2e-b150-25071dc93503\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i35\",\"name\":{\"zh\":\"垃圾\",\"en\":\"Trash\"}},{\"id\":\"a06f67d0-d224-420c-8cf1-2a617f164f52\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i36\",\"name\":{\"zh\":\"包装盒和箱子\",\"en\":\"Boxes & Packages\"}},{\"id\":\"423a8ad9-b3ce-4bec-af7f-791591159204\",\"label\":\"\",\"image\":-1,\"kind\":\"category\",\"code\":\"i37\",\"name\":{\"zh\":\"图案和符号\",\"en\":\"Sign & Symbols\"}},{\"id\":\"cc9a1df8-af6b-419b-b2bf-c042299db571\",\"label\":\"01\",\"image\":37,\"kind\":\"character\",\"code\":\"c01\",\"name\":{\"zh\":\"Character 01\",\"en\":\"Character 01\"}},{\"id\":\"51d4eb40-d621-48b2-81bb-bb5573b20d37\",\"label\":\"02\",\"image\":38,\"kind\":\"character\",\"code\":\"c02\",\"name\":{\"zh\":\"Character 02\",\"en\":\"Character 02\"}},{\"id\":\"0c6a66bd-65c6-4538-aa87-90ccce2b52d5\",\"label\":\"03\",\"image\":39,\"kind\":\"character\",\"code\":\"c03\",\"name\":{\"zh\":\"Character 03\",\"en\":\"Character 03\"}},{\"id\":\"b3a49360-9e64-4842-ac00-cccbb36249e9\",\"label\":\"04\",\"image\":40,\"kind\":\"character\",\"code\":\"c04\",\"name\":{\"zh\":\"Character 04\",\"en\":\"Character 04\"}},{\"id\":\"3171341c-9939-44eb-b941-150900a04cd4\",\"label\":\"05\",\"image\":41,\"kind\":\"character\",\"code\":\"c05\",\"name\":{\"zh\":\"Character 05\",\"en\":\"Character 05\"}},{\"id\":\"1236018d-47c0-42f5-a7c9-c604fd7edc5e\",\"label\":\"06\",\"image\":42,\"kind\":\"character\",\"code\":\"c06\",\"name\":{\"zh\":\"Character 06\",\"en\":\"Character 06\"}},{\"id\":\"b7754392-a603-4979-9c36-cdaa005f5b58\",\"label\":\"07\",\"image\":43,\"kind\":\"character\",\"code\":\"c07\",\"name\":{\"zh\":\"Character 07\",\"en\":\"Character 07\"}},{\"id\":\"9cf0374a-98a8-4bfc-be0c-e1906e6280f4\",\"label\":\"08\",\"image\":44,\"kind\":\"character\",\"code\":\"c08\",\"name\":{\"zh\":\"Character 08\",\"en\":\"Character 08\"}},{\"id\":\"3486346e-224a-4edd-8f0a-0275e3a771cb\",\"label\":\"09\",\"image\":45,\"kind\":\"character\",\"code\":\"c09\",\"name\":{\"zh\":\"Character 09\",\"en\":\"Character 09\"}},{\"id\":\"7ce8258e-aeea-4ced-81b8-3918af5242ea\",\"label\":\"10\",\"image\":46,\"kind\":\"character\",\"code\":\"c10\",\"name\":{\"zh\":\"Character 10\",\"en\":\"Character 10\"}},{\"id\":\"ad226dbe-289b-462a-829a-fba4522bf8ce\",\"label\":\"11\",\"image\":47,\"kind\":\"character\",\"code\":\"c11\",\"name\":{\"zh\":\"Character 11\",\"en\":\"Character 11\"}},{\"id\":\"52022e62-4287-461f-8085-f4e3ea7b619f\",\"label\":\"12\",\"image\":48,\"kind\":\"character\",\"code\":\"c12\",\"name\":{\"zh\":\"Character 12\",\"en\":\"Character 12\"}},{\"id\":\"5649216b-8e7a-4616-9112-853dfe862b93\",\"label\":\"13\",\"image\":49,\"kind\":\"character\",\"code\":\"c13\",\"name\":{\"zh\":\"Character 13\",\"en\":\"Character 13\"}},{\"id\":\"a29765ab-a685-4c0a-ad4b-264acca36e48\",\"label\":\"14\",\"image\":50,\"kind\":\"character\",\"code\":\"c14\",\"name\":{\"zh\":\"Character 14\",\"en\":\"Character 14\"}},{\"id\":\"bf5d3ad5-bc59-44bd-aa86-cb713c096d26\",\"label\":\"15\",\"image\":51,\"kind\":\"character\",\"code\":\"c15\",\"name\":{\"zh\":\"Character 15\",\"en\":\"Character 15\"}},{\"id\":\"aa9cd824-3872-4a32-ae59-e1e1f6e90104\",\"label\":\"16\",\"image\":52,\"kind\":\"character\",\"code\":\"c16\",\"name\":{\"zh\":\"Character 16\",\"en\":\"Character 16\"}},{\"id\":\"884c5fdd-3ef8-4ed8-a47f-bfe47c7c9e1f\",\"label\":\"17\",\"image\":53,\"kind\":\"character\",\"code\":\"c17\",\"name\":{\"zh\":\"Character 17\",\"en\":\"Character 17\"}},{\"id\":\"f3b02d56-9ce2-4047-b3d2-310f886f642f\",\"label\":\"18\",\"image\":54,\"kind\":\"character\",\"code\":\"c18\",\"name\":{\"zh\":\"Character 18\",\"en\":\"Character 18\"}},{\"id\":\"cad02f2d-4bd4-4da8-8701-ca802165bbe5\",\"label\":\"19\",\"image\":55,\"kind\":\"character\",\"code\":\"c19\",\"name\":{\"zh\":\"Character 19\",\"en\":\"Character 19\"}},{\"id\":\"cc56f4b6-963d-45d3-939e-0b8b6f550332\",\"label\":\"20\",\"image\":56,\"kind\":\"character\",\"code\":\"c20\",\"name\":{\"zh\":\"Character 20\",\"en\":\"Character 20\"}},{\"id\":\"069e7a2c-1122-46a1-9fc8-830ccb7375a8\",\"label\":\"21\",\"image\":57,\"kind\":\"character\",\"code\":\"c21\",\"name\":{\"zh\":\"Character 21\",\"en\":\"Character 21\"}},{\"id\":\"9600da3d-e2be-4c42-ad82-d62cd5581a4e\",\"label\":\"22\",\"image\":58,\"kind\":\"character\",\"code\":\"c22\",\"name\":{\"zh\":\"Character 22\",\"en\":\"Character 22\"}},{\"id\":\"0c3a2ecf-9aaa-465c-af3c-e68f5c58499f\",\"label\":\"23\",\"image\":59,\"kind\":\"character\",\"code\":\"c23\",\"name\":{\"zh\":\"Character 23\",\"en\":\"Character 23\"}},{\"id\":\"b5412662-4b37-4f01-bf76-de8488881773\",\"label\":\"24\",\"image\":60,\"kind\":\"character\",\"code\":\"c24\",\"name\":{\"zh\":\"Character 24\",\"en\":\"Character 24\"}},{\"id\":\"27606a5d-bdc3-4413-b32b-fba3fbf00ca1\",\"label\":\"25\",\"image\":61,\"kind\":\"character\",\"code\":\"c25\",\"name\":{\"zh\":\"Character 25\",\"en\":\"Character 25\"}},{\"id\":\"fd9e8ee3-98a9-4d97-9126-a82a6425b237\",\"label\":\"30\",\"image\":62,\"kind\":\"character\",\"code\":\"c30\",\"name\":{\"zh\":\"Character 30\",\"en\":\"Character 30\"}},{\"id\":\"0116dd06-50bd-436a-ad51-e3683a82cd32\",\"label\":\"31\",\"image\":63,\"kind\":\"character\",\"code\":\"c31\",\"name\":{\"zh\":\"Character 31\",\"en\":\"Character 31\"}},{\"id\":\"adca5933-f397-47f5-854a-59ef76bd04ca\",\"label\":\"32\",\"image\":64,\"kind\":\"character\",\"code\":\"c32\",\"name\":{\"zh\":\"Character 32\",\"en\":\"Character 32\"}},{\"id\":\"a271255a-d9e3-4a7c-8998-9169d7c98050\",\"label\":\"33\",\"image\":65,\"kind\":\"character\",\"code\":\"c33\",\"name\":{\"zh\":\"Character 33\",\"en\":\"Character 33\"}},{\"id\":\"657f6e7f-516f-48ed-a310-99d750f6cf4f\",\"label\":\"34\",\"image\":66,\"kind\":\"character\",\"code\":\"c34\",\"name\":{\"zh\":\"Character 34\",\"en\":\"Character 34\"}},{\"id\":\"eb3c712a-0cb3-43c8-938a-765672e77dbc\",\"label\":\"35\",\"image\":67,\"kind\":\"character\",\"code\":\"c35\",\"name\":{\"zh\":\"Character 35\",\"en\":\"Character 35\"}},{\"id\":\"d92155da-7a75-45a3-a7dd-84b1877e3f74\",\"label\":\"36\",\"image\":68,\"kind\":\"character\",\"code\":\"c36\",\"name\":{\"zh\":\"Character 36\",\"en\":\"Character 36\"}},{\"id\":\"ae5f8949-13b6-4040-b5ff-0a5c4cbbf70a\",\"label\":\"37\",\"image\":69,\"kind\":\"character\",\"code\":\"c37\",\"name\":{\"zh\":\"Character 37\",\"en\":\"Character 37\"}},{\"id\":\"151989bf-c8c4-4cac-93f5-edc808820783\",\"label\":\"38\",\"image\":70,\"kind\":\"character\",\"code\":\"c38\",\"name\":{\"zh\":\"Character 38\",\"en\":\"Character 38\"}},{\"id\":\"16e2fe95-a80c-4e5c-a306-275d0c373181\",\"label\":\"39\",\"image\":71,\"kind\":\"character\",\"code\":\"c39\",\"name\":{\"zh\":\"Character 39\",\"en\":\"Character 39\"}},{\"id\":\"12b69db3-79db-4114-b39f-be7003b743f3\",\"label\":\"40\",\"image\":72,\"kind\":\"character\",\"code\":\"c40\",\"name\":{\"zh\":\"Character 40\",\"en\":\"Character 40\"}},{\"id\":\"d9c8e2d0-5b44-400a-b363-76ac40d9c1dd\",\"label\":\"41\",\"image\":73,\"kind\":\"character\",\"code\":\"c41\",\"name\":{\"zh\":\"Character 41\",\"en\":\"Character 41\"}},{\"id\":\"7d098e16-c9ee-496b-83f1-77ff4dcabfb7\",\"label\":\"42\",\"image\":74,\"kind\":\"character\",\"code\":\"c42\",\"name\":{\"zh\":\"Character 42\",\"en\":\"Character 42\"}},{\"id\":\"383f6c0b-dfb9-4017-a178-f5fcd07d25f7\",\"label\":\"43\",\"image\":75,\"kind\":\"character\",\"code\":\"c43\",\"name\":{\"zh\":\"Character 43\",\"en\":\"Character 43\"}},{\"id\":\"0b21e508-18c8-484a-99d4-4d718cad035e\",\"label\":\"44\",\"image\":76,\"kind\":\"character\",\"code\":\"c44\",\"name\":{\"zh\":\"Character 44\",\"en\":\"Character 44\"}},{\"id\":\"09d194d4-b524-4e1a-a8eb-08620d6fc6b1\",\"label\":\"45\",\"image\":77,\"kind\":\"character\",\"code\":\"c45\",\"name\":{\"zh\":\"Character 45\",\"en\":\"Character 45\"}},{\"id\":\"e23e6a25-07e6-47af-bd17-be765ec88888\",\"label\":\"46\",\"image\":78,\"kind\":\"character\",\"code\":\"c46\",\"name\":{\"zh\":\"Character 46\",\"en\":\"Character 46\"}},{\"id\":\"9fe6daec-b460-46fa-8a31-4c6c962b56c0\",\"label\":\"47\",\"image\":79,\"kind\":\"character\",\"code\":\"c47\",\"name\":{\"zh\":\"Character 47\",\"en\":\"Character 47\"}},{\"id\":\"ca782e41-7146-468f-944c-e15bb5c8b703\",\"label\":\"48\",\"image\":80,\"kind\":\"character\",\"code\":\"c48\",\"name\":{\"zh\":\"Character 48\",\"en\":\"Character 48\"}},{\"id\":\"4598f66e-c92e-4190-9955-815c356851ed\",\"label\":\"49\",\"image\":81,\"kind\":\"character\",\"code\":\"c49\",\"name\":{\"zh\":\"Character 49\",\"en\":\"Character 49\"}},{\"id\":\"455aa9d7-5f72-4570-bf05-1db6385d77a2\",\"label\":\"50\",\"image\":82,\"kind\":\"character\",\"code\":\"c50\",\"name\":{\"zh\":\"Character 50\",\"en\":\"Character 50\"}},{\"id\":\"86e5c635-c11f-44bc-8724-5fe8979e095c\",\"label\":\"26\",\"image\":83,\"kind\":\"character\",\"code\":\"c26\",\"name\":{\"zh\":\"Character 26\",\"en\":\"Character 26\"}},{\"id\":\"76a2b758-1348-4186-8879-e35a61e4bc2c\",\"label\":\"27\",\"image\":84,\"kind\":\"character\",\"code\":\"c27\",\"name\":{\"zh\":\"Character 27\",\"en\":\"Character 27\"}},{\"id\":\"21090396-106e-4cc9-9639-57b4f94617f8\",\"label\":\"28\",\"image\":85,\"kind\":\"character\",\"code\":\"c28\",\"name\":{\"zh\":\"Character 28\",\"en\":\"Character 28\"}},{\"id\":\"73789e24-fe99-494f-96e0-eed2614cc44a\",\"label\":\"29\",\"image\":86,\"kind\":\"character\",\"code\":\"c29\",\"name\":{\"zh\":\"Character 29\",\"en\":\"Character 29\"}},{\"id\":\"75843bf1-2c3f-4785-9758-d19bc514e461\",\"label\":\"55\",\"image\":87,\"kind\":\"character\",\"code\":\"c55\",\"name\":{\"zh\":\"Character 55\",\"en\":\"Character 55\"}},{\"id\":\"15f148a4-6fb7-422b-80bd-6931ee60d1e0\",\"label\":\"54\",\"image\":88,\"kind\":\"character\",\"code\":\"c54\",\"name\":{\"zh\":\"Character 54\",\"en\":\"Character 54\"}},{\"id\":\"54a917b5-9a31-4a31-b42b-ea582b47e0ad\",\"label\":\"53\",\"image\":89,\"kind\":\"character\",\"code\":\"c53\",\"name\":{\"zh\":\"Character 53\",\"en\":\"Character 53\"}},{\"id\":\"554f682d-0537-4a12-a064-c06bdb054cef\",\"label\":\"52\",\"image\":90,\"kind\":\"character\",\"code\":\"c52\",\"name\":{\"zh\":\"Character 52\",\"en\":\"Character 52\"}},{\"id\":\"1723e4ae-4d36-48a8-8dde-e6730e7a64eb\",\"label\":\"51\",\"image\":91,\"kind\":\"character\",\"code\":\"c51\",\"name\":{\"zh\":\"Character 51\",\"en\":\"Character 51\"}},{\"id\":\"8d87a822-cf9a-45f5-a88b-6361b0ff3399\",\"label\":\"\",\"image\":92,\"kind\":\"expert\",\"code\":\"p04\",\"name\":{\"zh\":\"科学家\",\"en\":\"Scientist\"}},{\"id\":\"a4fa4174-173c-4d20-9151-d1d136052ab9\",\"label\":\"\",\"image\":93,\"kind\":\"expert\",\"code\":\"p03\",\"name\":{\"zh\":\"犯罪学家\",\"en\":\"Criminologist\"}},{\"id\":\"c75c7340-482e-40b8-adc7-a33891236dd7\",\"label\":\"\",\"image\":94,\"kind\":\"expert\",\"code\":\"p02\",\"name\":{\"zh\":\"医生\",\"en\":\"Doctor\"}},{\"id\":\"7db81fb8-f910-491a-852f-b29347b6e8af\",\"label\":\"\",\"image\":95,\"kind\":\"expert\",\"code\":\"p01\",\"name\":{\"zh\":\"黑客\",\"en\":\"Hacker\"}},{\"id\":\"7a75258d-5f98-44de-af6c-b6616ffb6e7f\",\"label\":\"A\",\"image\":96,\"kind\":\"location\",\"code\":\"lA\",\"name\":{\"zh\":\"西敏\",\"en\":\"Westminster\"}},{\"id\":\"5ba8e579-f54d-40e3-b229-5a9145cad28c\",\"label\":\"B\",\"image\":97,\"kind\":\"location\",\"code\":\"lB\",\"name\":{\"zh\":\"市中心\",\"en\":\"The City\"}},{\"id\":\"cb4deda5-5ebd-4637-83a2-1015f19296da\",\"label\":\"C\",\"image\":98,\"kind\":\"location\",\"code\":\"lC\",\"name\":{\"zh\":\"苏豪区和柯芬园\",\"en\":\"Soho & Covent Garden\"}},{\"id\":\"61d90c2f-da92-441a-9836-579a940249ec\",\"label\":\"D\",\"image\":99,\"kind\":\"location\",\"code\":\"lD\",\"name\":{\"zh\":\"莱斯特广场和海德公园\",\"en\":\"Leicester Square & Hyde Park\"}},{\"id\":\"2b5c7fde-a4f6-45d9-9792-d9f354f6b350\",\"label\":\"E\",\"image\":100,\"kind\":\"location\",\"code\":\"lE\",\"name\":{\"zh\":\"康登\",\"en\":\"Camden\"}},{\"id\":\"efb0d04e-bba8-4165-bc1e-f4ac9cbc9df3\",\"label\":\"F\",\"image\":101,\"kind\":\"location\",\"code\":\"lF\",\"name\":{\"zh\":\"肯辛顿和车路士\",\"en\":\"Kensington & Chelsea\"}},{\"id\":\"23178775-8687-423c-95d6-b4abdd7cf4a8\",\"label\":\"G\",\"image\":102,\"kind\":\"location\",\"code\":\"lG\",\"name\":{\"zh\":\"诺丁山\",\"en\":\"Notting Hill\"}},{\"id\":\"eb863b1d-ab56-488b-b94c-54d689222b7f\",\"label\":\"H\",\"image\":103,\"kind\":\"location\",\"code\":\"lH\",\"name\":{\"zh\":\"兰柏和布里克斯顿\",\"en\":\"Lambeth & Brixton\"}},{\"id\":\"627d67d4-0c86-40e3-a8ea-e9d4f37dab52\",\"label\":\"I\",\"image\":104,\"kind\":\"location\",\"code\":\"lI\",\"name\":{\"zh\":\"东区和白教堂\",\"en\":\"East End & White Chapel\"}},{\"id\":\"4920e397-95c1-45c1-9957-89a577f7a75b\",\"label\":\"J\",\"image\":105,\"kind\":\"location\",\"code\":\"lJ\",\"name\":{\"zh\":\"南华克和路易咸\",\"en\":\"Southwark & Lewisham\"}},{\"id\":\"8fe7490e-a16d-406b-a9d8-c18534bdb27b\",\"label\":\"K\",\"image\":106,\"kind\":\"location\",\"code\":\"lK\",\"name\":{\"zh\":\"梅费尔和马里波恩\",\"en\":\"Mayfair Marylebone\"}},{\"id\":\"b0dbf284-c3cb-4626-9b2c-88b231bbe4f2\",\"label\":\"L\",\"image\":107,\"kind\":\"location\",\"code\":\"lL\",\"name\":{\"zh\":\"布鲁姆斯伯里\",\"en\":\"Bloomsbury\"}},{\"id\":\"afba10cb-0cbf-4f86-a866-204c3072d28f\",\"label\":\"M\",\"image\":108,\"kind\":\"location\",\"code\":\"lM\",\"name\":{\"zh\":\"格林威治\",\"en\":\"Greenwich\"}},{\"id\":\"a0efb59b-18ea-4d07-a371-eb27296201f8\",\"label\":\"N\",\"image\":109,\"kind\":\"location\",\"code\":\"lN\",\"name\":{\"zh\":\"帕丁顿\",\"en\":\"Paddington\"}},{\"id\":\"2d89f3f1-2041-4841-a35f-9f44f6885df8\",\"label\":\"O\",\"image\":110,\"kind\":\"location\",\"code\":\"lO\",\"name\":{\"zh\":\"南区\",\"en\":\"South Bank\"}},{\"id\":\"9bf95230-2cb1-47db-8d70-b465bab06926\",\"label\":\"P\",\"image\":111,\"kind\":\"location\",\"code\":\"lP\",\"name\":{\"zh\":\"码头区\",\"en\":\"Docklands\"}},{\"id\":\"14cf49f0-4df6-496b-ae75-51b8414c6a98\",\"label\":\"\",\"image\":112,\"kind\":\"location\",\"code\":\"l01\",\"name\":{\"zh\":\"苏格兰场\",\"en\":\"Scotland Yard\"}},{\"id\":\"bb4bbe1c-fef0-498f-a75b-3e278244f0f3\",\"label\":\"01\",\"image\":-1,\"kind\":\"special\",\"code\":\"s01\",\"name\":{\"zh\":\"特殊物品01\",\"en\":\"Special item 01\"}},{\"id\":\"066aeed2-b8ba-4086-af83-094b4992756d\",\"label\":\"02\",\"image\":-1,\"kind\":\"special\",\"code\":\"s02\",\"name\":{\"zh\":\"特殊物品02\",\"en\":\"Special item 02\"}},{\"id\":\"a32ca9d1-f068-4f30-8e74-f9962085387e\",\"label\":\"03\",\"image\":-1,\"kind\":\"special\",\"code\":\"s03\",\"name\":{\"zh\":\"特殊物品03\",\"en\":\"Special item 03\"}},{\"id\":\"1ea6d4db-a19b-450d-b738-d9fc1a1d9d62\",\"label\":\"04\",\"image\":-1,\"kind\":\"special\",\"code\":\"s04\",\"name\":{\"zh\":\"特殊物品04\",\"en\":\"Special item 04\"}},{\"id\":\"b4327e16-40ba-4b2c-a50c-a16520d49aa0\",\"label\":\"05\",\"image\":-1,\"kind\":\"special\",\"code\":\"s05\",\"name\":{\"zh\":\"特殊物品05\",\"en\":\"Special item 05\"}},{\"id\":\"84ee3ac7-eb2c-45f0-a9e4-bb22c7ed7210\",\"label\":\"06\",\"image\":-1,\"kind\":\"special\",\"code\":\"s06\",\"name\":{\"zh\":\"特殊物品06\",\"en\":\"Special item 06\"}},{\"id\":\"d409a9d5-62c3-40f7-ad82-16fef698e037\",\"label\":\"07\",\"image\":-1,\"kind\":\"special\",\"code\":\"s07\",\"name\":{\"zh\":\"特殊物品07\",\"en\":\"Special item 07\"}},{\"id\":\"1c841e12-0cf5-43d9-8696-d85c83a146c6\",\"label\":\"08\",\"image\":-1,\"kind\":\"special\",\"code\":\"s08\",\"name\":{\"zh\":\"特殊物品08\",\"en\":\"Special item 08\"}},{\"id\":\"0b4445b1-d4b3-4a0e-b1bf-8671824b8ab1\",\"label\":\"09\",\"image\":-1,\"kind\":\"special\",\"code\":\"s09\",\"name\":{\"zh\":\"特殊物品09\",\"en\":\"Special item 09\"}},{\"id\":\"5f77acd3-b469-4071-b397-b264a40f9481\",\"label\":\"10\",\"image\":-1,\"kind\":\"special\",\"code\":\"s10\",\"name\":{\"zh\":\"特殊物品10\",\"en\":\"Special item 10\"}},{\"id\":\"18653ae6-ea3b-4d63-b02b-8bec9b85935e\",\"label\":\"15\",\"image\":-1,\"kind\":\"special\",\"code\":\"s15\",\"name\":{\"zh\":\"特殊物品15\",\"en\":\"Special item 15\"}},{\"id\":\"cbb0e153-6529-4b2c-83f2-fd1dc97cfc58\",\"label\":\"14\",\"image\":-1,\"kind\":\"special\",\"code\":\"s14\",\"name\":{\"zh\":\"特殊物品14\",\"en\":\"Special item 14\"}},{\"id\":\"1bde90d3-eb67-41aa-9137-ee3810125b6a\",\"label\":\"13\",\"image\":-1,\"kind\":\"special\",\"code\":\"s13\",\"name\":{\"zh\":\"特殊物品13\",\"en\":\"Special item 13\"}},{\"id\":\"f2731dc1-7ecb-4d6e-9947-1f8a464287a5\",\"label\":\"12\",\"image\":-1,\"kind\":\"special\",\"code\":\"s12\",\"name\":{\"zh\":\"特殊物品12\",\"en\":\"Special item 12\"}},{\"id\":\"fbbb6ad4-6d1d-41b3-8129-6f6bf84ed131\",\"label\":\"11\",\"image\":-1,\"kind\":\"special\",\"code\":\"s11\",\"name\":{\"zh\":\"特殊物品11\",\"en\":\"Special item 11\"}}]"), oe = {
	Id_Editor_Unnamed: {
		en: "Unnamed",
		zh: "Unnamed"
	},
	Id_Editor_Default: {
		en: "Default",
		zh: "Default"
	},
	Id_Editor_AnyLocation: {
		en: "(Any Location)",
		zh: "(Any Location)"
	},
	Id_Editor_AnyCharacter: {
		en: "(Any Character)",
		zh: "(Any Character)"
	},
	Id_Editor_AnyItem: {
		en: "(Any Item)",
		zh: "(Any Item)"
	},
	Id_Editor_AnyEvent: {
		en: "(Any Event)",
		zh: "(Any Event)"
	},
	Id_Editor_AnyObject: {
		en: "(Any Object)",
		zh: "(Any Object)"
	},
	Id_Editor_None: {
		en: "(None)",
		zh: "(None)"
	},
	Id_Scenario_Introduction: {
		en: "<ui=Tutorial>Welcome to the Chronicles of Crime tutorial.\n\nThis short case explains how to play.\n\nTap the story or the card area to read on. The triangle at the bottom right of the story marks the next passage.",
		zh: "<ui=教学模式>欢迎游玩推理事件簿教学模式。\n\n这个简短案件会讲解基本玩法。\n\n轻点正文或下方卡片区继续阅读。正文右下角的三角表示还有下一段。"
	},
	Id_Scenario_Name: {
		en: "Your first case",
		zh: "首件案件"
	},
	Id_Location_Name_0: {
		en: "Scotland Yard",
		zh: "苏格兰场"
	},
	Id_Character_Name_0: {
		en: "Chief Officer Doyle",
		zh: "戴尔局长"
	},
	Id_DisplayTextPerState_0: {
		en: "Ah, at last you're here. I have a case for you!\nAn old woman <char=07> has been found dead. I need you to find out if it's a natural death or an homicide.",
		zh: "你终于来了，我有件案件要给你。\n\n一位老妇<char=07>被发现死亡。我要你调查这是自然死亡抑或谋杀。"
	},
	Id_DisplayText_Action_0: {
		en: "You are interviewing the person named at the top.@Select another person or an evidence category, then press the action button below to ask about that subject.@Select the victim <char=07> and ask the Chief Officer about her.",
		zh: "上方显示当前交谈的人物。@选择其他人物或证据类别，再点击底部的行动按钮，向他询问相关情况。@现在选择死者<char=07>，再点击行动按钮，向局长询问她的情况。"
	},
	Id_Character_Name_1: {
		en: "Anna Taylor",
		zh: "安娜泰勒"
	},
	Id_Location_Name_1: {
		en: "Victim's Apartment",
		zh: "死者的住所"
	},
	Id_DisplayTextPerState_2: {
		en: "This woman's name is Anna Taylor. She's been found dead in her home in the Notting Hill district <loc=G>. Here's the address. Maybe you should go there and investigate...",
		zh: "那女人叫安娜泰勒，遗体在诺丁山的家中被发现<loc=G>。这是那里的地址，也许你该到那里调查一下……"
	},
	Id_DisplayText_Action_1: {
		en: "You have discovered Notting Hill <loc=G>.@End the interview, select the location, then press \"Go to\" below.",
		zh: "你已获知诺丁山<loc=G>的地址。@结束询问，再从地点中选择那里，点击底部的“前往”按钮。"
	},
	Id_LocationState_Introduction_0: {
		en: "<ui=Tutorial>You are now in Notting Hill, inside the victim's apartment, as indicated at the top of the screen.",
		zh: "<ui=Tutorial>你来到诺丁山上死者的住所。萤幕上方也有显示。"
	},
	Id_DisplayText_Action_2: {
		en: "Select an evidence category matching what you saw, then press Examine below. You can search the scene again to look for more clues.",
		zh: "选择与你看到的线索相符的证据类别，再点击底部的“检查”按钮。也可以再次搜证，寻找更多线索。"
	},
	Id_Item_Name_0: {
		en: "Dead Cat",
		zh: "死猫"
	},
	Id_Item_Name_1: {
		en: "Cake",
		zh: "蛋糕"
	},
	Id_Item_Name_2: {
		en: "Card Game",
		zh: "扑克牌"
	},
	Id_Item_Name_3: {
		en: "Old Phone",
		zh: "旧电话"
	},
	Id_DisplayTextPerState_1: {
		en: "The victim's cats are dead.",
		zh: "死者的猫都死了。"
	},
	Id_DisplayTextPerState_3: {
		en: "You pick up a cream cake that's been partially eaten.",
		zh: "你捡起吃了一半的奶油蛋糕。"
	},
	Id_DisplayText_Default_0: {
		en: "Unfortunately there is nothing of real interest for the investigation in this category.",
		zh: "很可惜，这类别对本案并无关系。"
	},
	Id_DisplayTextPerState_4: {
		en: "You find a classic deck of 52 playing cards, apparently a usual pastime for the victim.",
		zh: "你找到一副典型的52张游戏卡牌，看来死者用来打发时间。"
	},
	Id_DisplayTextPerState_5: {
		en: "An old corded telephone that still works.",
		zh: "一台还能运作的家用电话。"
	},
	Id_Character_Name_2: {
		en: "Eric Gloomerry",
		zh: "艾力·古鲁梅利"
	},
	Id_Character_Name_3: {
		en: "Jeremy King",
		zh: "哲礼美·甘"
	},
	Id_Character_Name_4: {
		en: "Harvey Marshall",
		zh: "哈维·马绍"
	},
	Id_Character_Name_5: {
		en: "Lou Chin",
		zh: "刘紫嫣"
	},
	Id_DisplayText_Action_3: {
		en: "The Doctor performs autopsies and medical examinations.@Select the Doctor from Experts and press Contact. Then select a person or evidence and press the analysis button below.",
		zh: "医生可以验尸并提供医学意见。@在专家中选择医生，点击“联系”；再选择希望他检查的人物或证据，点击底部的分析按钮。"
	},
	Id_DisplayText_Action_4: {
		en: "The Doctor performs autopsies and medical examinations.@Select the Doctor from Experts and press Contact. Then select a person or evidence and press the analysis button below.",
		zh: "医生可以验尸并提供医学意见。@在专家中选择医生，点击“联系”；再选择希望他检查的人物或证据，点击底部的分析按钮。"
	},
	Id_DisplayText_Action_6: {
		en: "The Hacker can research information and examine technology.@Select the Hacker from Experts and press Contact. Then select a subject and press the analysis button below.",
		zh: "黑客可以查找资料并分析电子设备。@在专家中选择黑客，点击“联系”；再选择希望询问的人物或证据，点击底部的分析按钮。"
	},
	Id_DisplayText_Action_7: {
		en: "The Scientist can analyze evidence in the laboratory.@Select the Scientist from Experts and press Contact. Then select the evidence and press the analysis button below.",
		zh: "科学家可以在实验室分析证据。@在专家中选择科学家，点击“联系”；再选择希望分析的证据，点击底部的分析按钮。"
	},
	Id_DisplayText_Action_8: {
		en: "The Criminologist studies suspects and the social significance of objects.@Select the Criminologist from Experts and press Contact. Then select a subject and press the analysis button below.",
		zh: "犯罪学家可以分析嫌疑人的心理，也能解释物品所处的社会背景。@在专家中选择犯罪学家，点击“联系”；再选择希望询问的人物或证据，点击底部的分析按钮。"
	},
	Id_DisplayTextPerState_6: {
		en: "The elderly woman died on her rocking chair with no obvious signs of struggle.",
		zh: "老妇人坐在轮椅上死去，死前没有任何明显挣扎的痕迹。"
	},
	Id_DisplayText_Default_1: {
		en: "This person isn't present here.",
		zh: "这人物不在这地方。"
	},
	Id_DisplayTextPerState_7: {
		en: "If you want some help from the Chief Officer, you will have to go back to the Scotland Yard.",
		zh: "若想得到局长帮助，必须先回去苏格兰场。"
	},
	Id_DisplayTextPerState_8: {
		en: "The woman died around 10:30pm yesterday. Her heart just stopped. @ We have found an unusually large amount of digitalis, a poisonous plant residue which can provoke a cardiac arrest. <itm=04>",
		zh: "这妇人在昨晚十点半左右死于心脏停顿。@我们发现她体内残留异常大量的毛地黄，可导致心跳停止。<itm=04>"
	},
	Id_DisplayText_Default_2: {
		en: "A corpse is a mystery that an autopsy attempts to solve, but honestly I'm not sure this person would have wanted to be opened with my scalpel.",
		zh: "验尸的目的是查明尸体的谜团，但我可不清楚这人是否愿意被我用手术刀开膛。"
	},
	Id_DisplayTextPerState_9: {
		en: "Doctor Schrödinger's theories are useless.  \nThe cats died of digitalis poisoning. <itm=04>",
		zh: "薛丁格博士的理论在此用不着。\n\n这些猫死于毛地黄中毒。<itm=04>"
	},
	Id_Item_Name_4: {
		en: "Digitalis",
		zh: "毛地黄"
	},
	Id_DisplayTextPerState_10: {
		en: "I can't believe these old things still exist!\nLuckily it's linked to the network with the same usual wires. I was able to find the last call, yesterday at 6:15pm. It came from the phone of a lady named Rose Butterfly <char=09>",
		zh: "这些老东西竟然还在人世间！\n\n幸好它还是连接到常用的网路线路，由此让我找到最后一则通话时在昨晚六点十五分，由露丝·伯特菲女士拨出<char=09>。"
	},
	Id_DisplayText_Default_3: {
		en: "I'm not the one who can help you with this.",
		zh: "我在这件事上帮不上忙。"
	},
	Id_DisplayText_Action_5: {
		en: "The symbol <itm=04> reveals a special subject. Its card is now available under Special items.",
		zh: "图示<itm=04>表示你发现了一个特殊物品。对应的卡片已加入“特殊物品”卡区。"
	},
	Id_DisplayTextPerState_11: {
		en: "This particular deck is used to play bridge. It's a game played by teams of 2, where one partner can become what is called \"the dummy\". In some countries the dummy is called \"the dead\".@ Anna Taylor was part of a bridge club in Leicester Square <loc=D>.",
		zh: "这是用来玩桥牌的卡牌。桥牌是两人队伍游玩的游戏，当中一人称为「梦家」。有些地方把梦家称为「死者」。@安娜·泰勒是莱斯特广场桥牌会的成员<loc=D>。"
	},
	Id_Location_Name_3: {
		en: "Bridge Club",
		zh: "桥牌会"
	},
	Id_Item_Name_5: {
		en: "Letter",
		zh: "信件"
	},
	Id_DisplayTextPerState_14: {
		en: "A letter with the following text: \n<b><i>\"Give up on the tournament! You are not as strong as you were before. For the good of the club, leave your spot to someone younger.\" </i></b>",
		zh: "以下是信件内容：\n\n<b><i>「放弃参赛吧！你已经不像以前那样强了。为了整个会著想，让位给年轻人吧。」</i></b>"
	},
	Id_DisplayText_Action_9: {
		en: "This letter makes you wonder if the suspect hasn't had a change of heart. Don't hesitate to re-interrogate him on certain subjects, he might be able to tell you more about them.",
		zh: "读完这封信，你疑惑嫌疑犯是否曾经改变主意。有时候就相同事物再次盘问角色，会获得更多资讯。"
	},
	Id_Character_Name_7: {
		en: "Rose Butterfly",
		zh: "露丝·伯特菲"
	},
	Id_DisplayTextPerState_29: {
		en: "My name is Rose Butterfly. I'm a florist. Bridge is more than just a passion to me, and Anna was my partner.",
		zh: "我叫露丝·伯特菲，是花店店主。对我来说，桥牌不单是趣味，而安娜是我的搭档。"
	},
	Id_DisplayTextPerState_30: {
		en: "You need to be careful with the Floxglove flower. It's dangerous because of the digitalis it contains. But it's beautiful nonetheless.",
		zh: "接触洋地黄时必须小心，因为它含有毛地黄，可能带来危险，不过这种花实在漂亮。"
	},
	Id_DisplayTextPerState_31: {
		en: "Bridge is a game with such intensity... I love the adrenaline rush of the tournaments. @ There's an important one tomorrow with a big cash prize. With the right partner, I have a good chance to win it.",
		zh: "桥牌是非常刺激的游戏，我很享受比赛时肾上腺素急升的感觉。@明天有一场奖金丰富的重要赛事。只要有好的伙伴，我大有把握胜出。"
	},
	Id_DisplayTextPerState_32: {
		en: "Anna was the President of the club, and we have this place thanks to her. She was my partner and we owe her so much.",
		zh: "安娜是桥牌会的主席，我们都很感激她创立这个会，而且她是我的搭档，我们都欠下她很多。"
	},
	Id_DisplayTextPerState_33: {
		en: "Yes, I admit that Anna was a difficult person, and to be honest she was a bad Bridge player. It's her money that made her President of the club.",
		zh: "对，我的确认为安娜不易相处，而且坦白说，她的桥牌打得很烂。她之所以能当上主席，全因她出的钱。"
	},
	Id_DisplayTextPerState_34: {
		en: "I love to make cream cakes. Sugar is still legal, isn't it?",
		zh: "我喜欢做奶油蛋糕。糖是合法用品对吧。"
	},
	Id_DisplayText_Default_6: {
		en: "I really don't know what to say about this.",
		zh: "我不知道该说什么。"
	},
	Id_DisplayTextPerState_36: {
		en: "We're practicing for a big Bridge tournament right now. How can I help you?",
		zh: "我们正在为参赛而练习。请问有什么事？"
	},
	Id_LocationState_Introduction_2: {
		en: "A woman <char=04> welcomes you at the Bridge club.",
		zh: "一位女性<char=04>在桥牌会欢迎你。"
	},
	Id_DisplayText_Default_7: {
		en: "The person you are looking for isn't here. Try to move to a location where that person is located.",
		zh: "你要找的人物不在这里，移动到他所在地点吧。"
	},
	Id_DisplayText_Default_8: {
		en: "This object can't be picked up or used in this location.",
		zh: "这物品不能在这地点拾取或使用。"
	},
	Id_DisplayText_Default_10: {
		en: "This object can't be picked up or used in this location.",
		zh: "这物品不能在这地点拾取或使用。"
	},
	Id_DisplayText_Default_11: {
		en: "The person you are looking for isn't here. Try to move to a location where that person is located.",
		zh: "你要找的人物不在这里，移动到他所在地点吧。"
	},
	Id_DisplayTextPerState_38: {
		en: "An old lady who grew up during the war, and who was extremely stingy with her money.",
		zh: "这位老妇人在战时长大，极端吝啬。"
	},
	Id_DisplayTextPerState_40: {
		en: "A compulsive fighter who will do whatever it takes to get what she wants. She makes her presence loud and clear with her extreme quirkiness. You will most likely find her at the Leicester Square Bridge Club <loc=D>.",
		zh: "这位坚定的斗士会用尽办法获得想要的事物，以非常古怪的个性向全世界清晰宣告自己是个怎样的人物。你应该会在莱斯特广场的桥牌会找到她。"
	},
	Id_DisplayTextPerState_41: {
		en: "Ah! The Chief Officer… There's so much to say about this man, but I'm pretty sure now's not the time.",
		zh: "啊！局长……我有很多关于他的资讯，但现在绝不是适当的时候去谈论。"
	},
	Id_DisplayText_Default_13: {
		en: "Criminals are complex beings. I need a little more information to figure this out.",
		zh: "罪犯的内心很复杂，我需要更多资料才可以弄清楚。"
	},
	Id_DisplayText_Default_14: {
		en: "Each object has a criminal history related to it, but this one isn't necessarily linked with your current investigation.",
		zh: "每件证物都有一段犯罪史，但这件与目前的案件无关。"
	},
	Id_DisplayTextPerState_42: {
		en: "Poison is often used by killers who don't like physical violence. The serial killer Marie Becker, also called the Black Widow, was famous for using digitalis. @ Remember that getting the right dosage of poison is difficult, and it can sometimes kill by accident.",
		zh: "不喜欢肢体暴力的凶手通常都会下毒。连环杀手玛丽·贝卡，又称黑寡妇，以使用毛地黄而臭名昭彰。@控制剂量并不容易，一个不慎便会意外杀人。"
	},
	Id_DisplayText_Default_15: {
		en: "My microscope doesn't really work so well on people.",
		zh: "显微镜在人身上派不上用场。"
	},
	Id_DisplayTextPerState_43: {
		en: "Who could be so cruel as to kill a sweet little kitty....\nUnfortunately, animal corpses are not my area of expertise.",
		zh: "有谁这么残忍杀死可爱的猫咪呢……\n\n很可惜，动物尸体不是我的专长。"
	},
	Id_DisplayTextPerState_44: {
		en: "My analysis confirms traces of digitalis <itm=04> inside the cake. The quantity might not have been harmful to you or I, but would have been fatal to an elderly woman like the victim.",
		zh: "经过分析，我在蛋糕里发现毛地黄<itm=04>，剂量对你和我未必有害，但对死者这样的老妇人已足以致命。"
	},
	Id_DisplayTextPerState_45: {
		en: "Scientifically, there's nothing to say about the cards. The criminologist might be able to help you more.",
		zh: "从科学角度来说，这些卡牌没有特点。找犯罪学家帮助应该更好。"
	},
	Id_DisplayTextPerState_46: {
		en: "Scientifically, there's nothing to say about the phone. The Hacker might help you on this.",
		zh: "从科学角度来说，这电话没有特点。找黑客帮助应该更好。"
	},
	Id_DisplayTextPerState_47: {
		en: "Digitoxin or digitalis is a cardiac glycoside extract from a flower commonly called the Foxglove or in latin <i>Digitalis purpurea</i>.",
		zh: "毛地黄毒是从俗称洋地黄（学名叫<i>Digitalis purpurea</i>）的花朵中提取出来的强心苷。"
	},
	Id_DisplayTextPerState_48: {
		en: "Unfortunately, it's a letter without any identifiable fingerprints.",
		zh: "很可惜，信上找不到可以辨认的指纹。"
	},
	Id_DisplayText_Default_16: {
		en: "I need evidence before I can analyze it. Have you collected the object?@End the interview, select the matching evidence category at the scene, then press Examine to collect it.",
		zh: "我需要拿到证据才能分析。你已经收集到那件物品了吗？@结束询问，在现场选择相应的证据类别，再点击“检查”，收集物品。"
	},
	Id_DisplayTextPerState_49: {
		en: "He's a good fellow who saved my life on more than one occasion when I was...let's just say...on the borders of legality",
		zh: "他是一名非常优秀的同僚，在我……游走法律边缘时多次拯救我的生命。"
	},
	Id_DisplayTextPerState_50: {
		en: "A quick Internet search found that she was president of a Bridge club in Leicester Square <loc=D>.",
		zh: "简单上网搜寻一下，可以得知她是莱斯特广场桥牌会的主席。"
	},
	Id_DisplayTextPerState_52: {
		en: "She's registered for a Bridge tournament tomorrow with a big cash prize for the winner. Guess who was supposed to be her partner?\nBINGO! Our victim, Anna.",
		zh: "她报名参加了明天的桥牌比赛。那比赛设有巨额的冠军奖金。猜猜看谁是她的搭档吧。\n\n对！死者安娜。"
	},
	Id_DisplayText_Default_17: {
		en: "To each his own. My speciality is medicine, especially that of those who no longer move.",
		zh: "人各有长。我专精的是医学，尤其是已经不会再动的生物。"
	},
	Id_DisplayText_Action_10: {
		en: "Good start. When you're sure of your suspicions, go back to the Scotland Yard to give your report, and answer the questions to close the case.",
		zh: "这是个好开始！当你们认为已经弄清谜团，便可回去苏格兰场提交报告，回答问题以结案。"
	},
	Id_LocationState_Introduction_3: {
		en: "If you need any help, the Chief Officer's office <char=33> is open.",
		zh: "若你需要帮助，可以到局长办公室<char=33>。"
	},
	Id_LocationState_Introduction_4: {
		en: "If you are ready to give your report, press \"Close the case\" below.",
		zh: "准备好提交报告后，点击底部的“提交结案报告”。"
	},
	Id_Ending_Question_0: {
		en: "Select a card, then press Submit answer for each question.\n\nWho killed Anna Taylor <char=07>?",
		zh: "每题选择相应卡片，再点击底部的提交按钮。\n\n谁杀死了安娜·泰勒<char=07>？"
	},
	Id_Ending_Question_1: {
		en: "Why was she killed?",
		zh: "她为何被杀？"
	},
	Id_Ending_Question_4: {
		en: "What was the murder weapon?",
		zh: "凶器是什么？"
	},
	Id_Ending_Question_WrongMandatory_0: {
		en: "The Chief Officer doesn't believe your theory. He would like you to continue your investigation. Find the crime weapon and who could have used it.",
		zh: "局长不相信你的推论，命令你继续调查。找出凶器和凶手吧。"
	},
	Id_Ending_FinalSummary_0: {
		en: "<ui=Tutorial>Well done, You just completed this Tutorial successfully!@\nThe answers you give at the end can send you back to the investigation or provoke a different ending.@ Press the \"Solution\" button to learn everything about this case.",
		zh: "<ui=Tutorial>做得好！你完成了这个教学模式了！@\n\n根据你在最后给出的答案，系统会指示你回去继续搜查，或者带领你到不同的结局。@按下「答案」以了解整个案件吧。"
	},
	Id_Scenario_ClosedLocationDefaultMessage: {
		en: "Location cards represent London's districts. Without an address or a precise goal you cannot go there.",
		zh: "地点板块表示伦敦的不同区域，但你必须要有地址或目标才可以前往。"
	},
	Id_Scenario_SameLocationDefaultMessage: {
		en: "You are already in this location. The location is indicated in the top left corner.",
		zh: "你已在这地点，看左上角可知目前所在地点。"
	},
	Id_Scenario_UnusedScanCodeMessage: {
		en: "There is no information about this subject.",
		zh: "没有与此对象相关的信息。"
	},
	Id_DisplayTextPerState_54: {
		en: "<i> You are calling the IT department:</i>\nInternet and Technology, that's my thing! What can I do to help you?",
		zh: "<i>你联络了情报局。</i>\n\n我的专长是网路和科技。有什么事呢？"
	},
	Id_DisplayTextPerState_55: {
		en: "<i> You are calling the Morgue </i>\n\nWho should I autopsy?",
		zh: "<i>你联络了解剖室。</i>\n\n有什么需要验尸？"
	},
	Id_DisplayTextPerState_56: {
		en: "<i> You are calling the Criminology Center: </i>\nI study the psychological profiles of killers and the history of crime. Can I help you with anything?",
		zh: "<i>你联络了犯罪学中心。</i>\n\n我研究凶手的心理状态和犯罪历史，有什么需要协助的？"
	},
	Id_DisplayTextPerState_57: {
		en: "<i>You are calling the Laboratory: </i> \n\nScientific analysis is the basis of modern investigation.\nDo you have any evidence for me?",
		zh: "<i>你联络了实验室。</i>\n\n科学方法是现代调查的基本。\n你为我带来了什么证据？"
	},
	Id_DisplayTextPerState_58: {
		en: "<i> You are calling the IT department:</i>\nInternet and Technology, that's my thing! What can I do to help you?",
		zh: "<i>你联络了情报局。</i>\n\n我的专长是网路和科技。有什么事呢？"
	},
	Id_DisplayTextPerState_60: {
		en: "<i> You are calling the IT department:</i>\nInternet and Technology, that's my thing! What can I do to help you?",
		zh: "<i>你联络了情报局。</i>\n\n我的专长是网络和科技。有什么事呢？"
	},
	Id_DisplayTextPerState_61: {
		en: "<i> You are calling the Morgue </i>\n\nWho should I autopsy?",
		zh: "<i>你联络了解剖室。</i>\n\n有什么需要验尸？"
	},
	Id_DisplayTextPerState_63: {
		en: "<i> You are calling the Morgue </i>\n\nWho should I autopsy?",
		zh: "<i>你联络了解剖室。</i>\n\n有什么需要验尸？"
	},
	Id_DisplayTextPerState_64: {
		en: "<i> You are calling the Criminology Center: </i>\nI study the psychological profiles of killers and the history of crime. Can I help you with anything?",
		zh: "<i>你联络了犯罪学中心。</i>\n\n我研究凶手的心理状态和犯罪历史，有什么需要协助的？"
	},
	Id_DisplayTextPerState_66: {
		en: "<i> You are calling the Criminology Center: </i>\n\nI study the psychological profiles of killers and the history of crime. Can I help you with anything?",
		zh: "<i>你联络了犯罪学中心。</i>\n\n我研究凶手的心理状态和犯罪历史，有什么需要协助的？"
	},
	Id_DisplayTextPerState_67: {
		en: "<i>You are calling the Laboratory: </i> \n\nScientific analysis is the basis of modern investigation.\nDo you have any evidence for me?",
		zh: "<i>你联络了实验室。</i>\n\n科学方法是现代调查的基本。\n你为我带来了什么证据？"
	},
	Id_DisplayTextPerState_69: {
		en: "<i>You are calling the Laboratory: </i> \n\nScientific analysis is the basis of modern investigation.\nDo you have any evidence for me?",
		zh: "<i>你联络了实验室。</i>\n\n科学方法是现代调查的基本。\n你为我带来了什么证据？"
	},
	Id_DisplayText_Action_11: {
		en: "There are still clues to find at the scene. Look behind you and at the floor. Afterwards, select a matching evidence category and press Examine to collect the clue.",
		zh: "现场还有线索等待发现。搜证时也要留意身后和脚下。观察结束后，选择相符的证据类别，再点击“检查”，收集线索。"
	},
	Id_DisplayText_Default_18: {
		en: "I can help you with many things, dear, but this is not one of them.",
		zh: "好家伙，我可以给你很多帮助，但不包括这件。"
	},
	Id_DisplayText_Default_19: {
		en: "What about asking one of the forensic experts?",
		zh: "要不去问一问其中一位鉴识专家？"
	},
	Id_DisplayTextPerState_71: {
		en: "We can talk once the case is closed. Stay focused on your task.",
		zh: "先专心侦破这案件，之后我再跟你聊。"
	},
	Id_DisplayText_Default_20: {
		en: "I don't know what to say about this subject.",
		zh: "我不知道该说什么。"
	},
	Id_DisplayTextPerState_73: {
		en: "Anna was supposed to be my partner, but she sucked at Bridge. Her death is a tragedy I would have never wished upon her, though it's true that it will allow me to have a better partner for tomorrow and, hopefully, win the big prize.",
		zh: "安娜本是我的搭档，但她牌技非常烂。她去世固然是个惨案，我绝不想她突然遭厄，不过无可否认的是这样我便能找一位更优秀的搭档，增加明天赢得大奖的机会。"
	},
	Id_DisplayTextPerState_74: {
		en: "It was always difficult to get Anna on the phone, since she refused to have a cell phone.",
		zh: "打电话不容易找上安娜，因为她不肯买一支手机。"
	},
	Id_DisplayTextPerState_75: {
		en: "It's true. I wrote this letter. I will speak frankly since you know the tensions between myself and Anna.",
		zh: "对，这些信是我写的。你知道我跟安娜之间有时会剑拔弩张，"
	},
	Id_DisplayTextPerState_76: {
		en: "To learn more about the personality of a suspect, it's good to ask other people what they think about them.",
		zh: "如想了解嫌疑犯的性格，最好的方法是向其他人询问对那人的看法。"
	},
	Id_DisplayText_Default_21: {
		en: "I need more info before I can do that research.",
		zh: "我需要更多资讯才可开始研究。"
	},
	Id_DisplayTextPerState_77: {
		en: "Our victim, Anna Taylor, was part of a Bridge Club in Leicester Square <loc=D>. Apparently, her partner did not want her to participate in the tournamant.",
		zh: "死者安娜·泰勒是莱斯特广场<loc=D>桥牌会的一员。很明显的是她的搭档不希望她出赛。"
	},
	Id_DisplayTextPerState_78: {
		en: "Criminals are becoming more wary of phone tapping.",
		zh: "罪犯拨打那通电话，显得非常小心翼翼。"
	},
	Id_DisplayTextPerState_79: {
		en: "In California, an American was sentenced to 16 years in prison for killing 18 cats and injuring 3 others.\n\n...I don't know if this information will be really useful to your investigation.",
		zh: "在加利福尼亚，有一位美国人因杀害十八只猫、伤害另外三只，而被判囚十六年。\n\n……我不晓得这资讯对你有没用。"
	},
	Id_DisplayTextPerState_80: {
		en: "Wasting such a delicious looking cake, that is criminal indeed.\nTry to find out who sent it.",
		zh: "浪费这些看来如此美味的蛋糕，本身便是一桩罪案。\n\n找出谁送出这蛋糕吧。"
	},
	Id_LocationState_Introduction_5: {
		en: "You are back in Notting Hill, inside the victim's apartment.",
		zh: "你回到诺丁山上死者的住所。"
	},
	Id_DisplayTextPerState_81: {
		en: "If you are lost, my office is always open. I will guide you as much as I can. What do you want to talk about?",
		zh: "若你迷失方向，随时来我的办公室求助吧，我会尽我所能引导你。你想知道什么？"
	},
	Id_Character_Name_8: {
		en: "Jenny May",
		zh: "珍妮·梅"
	},
	Id_DisplayTextPerState_82: {
		en: "My name is Jenny May, and I'm a veterinarian. It's my day off today, but I'm totally exhausted after working more than 12 hours yesterday.",
		zh: "我叫珍妮·梅，是一名兽医。今天我休假，但昨天工作了超过十二小时，现在仍然筋疲力竭。"
	},
	Id_DisplayTextPerState_84: {
		en: "Anna was the president of the Bridge club, and we owe a lot to her. She was the teammate of one of our best players, Rose <char=09>. Rose is here today.",
		zh: "安娜是桥牌会主席，而我们欠下她太多了。她的队员是露丝<char=09>，而露丝是会内非常优秀的桥牌玩家。"
	},
	Id_DisplayTextPerState_85: {
		en: "Anna asked me a few times to pass by her place and check on her cats. Poor little ones, they had a cholesterol problem.@ I kept telling Anna not to feed them human food, but I think she was doing it anyway.",
		zh: "安娜有几次请我去她家里检查她的猫。牠们真可怜，受胆固醇折磨。@我多番提醒安娜不要喂猫吃人类的食物，但不认为她听得进。"
	},
	Id_DisplayTextPerState_86: {
		en: "I heard Rose <char=09> on the phone with a delivery man. She was trying to get a cake delivered to Anna <char=07>.",
		zh: "我听到露丝<char=09>跟送货员通电话，要把一个蛋糕送给安娜<char=07>。"
	},
	Id_DisplayTextPerState_87: {
		en: "I discovered Bridge only recently and love it!\nI lose often, not like Rose <char=09>, who wins almost every single tournament! There is one tomorrow, actually, with a big cash prize for the winning team.",
		zh: "我最近才开始打桥牌，而我很喜爱。\n\n我经常输掉，跟在比赛里连战连胜的露丝<char=09>差得远。其实明天还有一场赛事，胜出的队伍会赢得巨额奖金。"
	},
	Id_DisplayTextPerState_88: {
		en: "I do use many dangerous substances when I have to put down animals, but definitely not digitalis.",
		zh: "我使用过许多危险的药物来把动物安乐死，但不包括毛地黄。"
	},
	Id_DisplayTextPerState_89: {
		en: "I've never seen this letter before.",
		zh: "我未见过这封信。"
	},
	Id_DisplayText_Default_22: {
		en: "I would like to help you, but I don't know anything about this subject.",
		zh: "我很乐意帮助你，但我不懂这件事。"
	},
	Id_DisplayText_Default_23: {
		en: "What a funny question. No, I don't know.",
		zh: "这是个有趣的问题，但我没有答案。"
	},
	Id_DisplayTextPerState_90: {
		en: "I don't know Anna's phone number. I had no reason to call her.",
		zh: "我不晓得安娜的电话号码，我没有理由拨给她。"
	},
	Id_DisplayTextPerState_91: {
		en: "So you've been told I couldn't stand Anna anymore. Well... if the masks are off, then I will speak straight.",
		zh: "有人跟你说过我受不了安娜吗？那么我也不用伪装了，打开天窗说亮话吧。"
	},
	Id_DisplayText_Default_24: {
		en: "I don't recognize this, should I?",
		zh: "我应该认得这个人吗 ?"
	},
	Id_DisplayTextPerState_92: {
		en: "Rose is competitive, and she often argued with Anna because they were losing more and more often. But they most likely reconciled because Rose sent a cake to Anna <char=07> yesterday.",
		zh: "露丝竞争心很重，而且由于队伍越来越常输掉比赛，她跟安娜的争执也变多了。不过昨天露丝送蛋糕去给安娜<char=07>作赔礼，所以应该和好了吧。"
	},
	Id_DisplayTextPerState_93: {
		en: "I'm new to the club, but if I can help you, please let me know.",
		zh: "我加入这桥牌会没多久，但需要我帮忙的请尽管说。"
	},
	Id_DisplayTextPerState_94: {
		en: "You want to analyze the victim's corpse? Well thought! But you should go to the crime scene or ask the doctor what he thinks of the body.",
		zh: "你想分析死者的尸体？杰出的一手，但你该到案发现场或征询医生的意见。"
	},
	Id_DisplayTextPerState_95: {
		en: "Did you think of asking her what she thinks about the victim?",
		zh: "有没有打算询问她怎样看待死者？"
	},
	Id_DisplayTextPerState_96: {
		en: "I'm happy to see new players coming.",
		zh: "有新会员加入，我很开心。"
	},
	Id_DisplayText_Action_13: {
		en: "Plan your actions carefully: questions and item checks cost time, and travelling costs more.@Some locations offer a Search scene action. Drag the scene to look around during the observation time. Try it in the victim's apartment.",
		zh: "谨慎安排行动：询问和检查物品会消耗时间，移动所需的时间更多。@有些地点可以进行“现场搜证”。观察期间拖动画面，查看周围。现在可以在死者住所尝试。"
	},
	Id_DisplayTextPerState_98: {
		en: "A young lady, very serious, who works as a vet. You could say that she has succeeded in life. She is now looking to give a meaning to it.",
		zh: "一名任职兽医、非常认真的年轻女性。你可以说她是人生赢家，目前正努力实践人生的意义。"
	},
	Id_DisplayText_Action_14: {
		en: "Investigate the case, gather clues and decide what happened.@The Chief Officer is character <char=33>.@Select his card, then press Talk to below. Selecting a card alone does not act or cost time.",
		zh: "调查案件、收集线索，并推断事件的真相。@局长是人物<char=33>。@选择他的人物牌，再点击底部的交谈按钮。仅选择卡片不会执行行动，也不消耗时间。"
	},
	Id_DisplayTextPerState_99: {
		en: "Collect the phone first so I can analyze it.@End the interview, select Communication Devices from Evidence, then press Examine to collect the phone.",
		zh: "先收集那部电话，我才能分析。@结束询问，在证据类别中选择“通讯设备”，再点击“检查”，收集电话。"
	},
	Id_DisplayText_Action_15: {
		en: "Select a person at your location, then press Talk to below.@During the interview, select that same person again and press Ask about to hear about them.",
		zh: "选择当前地点的人物，再点击底部的交谈按钮。@交谈时，再次选择他的人物牌，点击询问按钮，可以听他介绍自己。"
	},
	Id_Item_Name_6: {
		en: "Furniture",
		zh: "家具"
	},
	Id_Item_Name_7: {
		en: "Books",
		zh: "书本"
	},
	Id_Item_Name_8: {
		en: "Flowers",
		zh: "花朵"
	},
	Id_DisplayTextPerState_100: {
		en: "Well tried, but the furniture here is old and uninteresting.",
		zh: "著眼点不错，但这里的家具只是老旧而已，没有值得注意的地方。"
	},
	Id_DisplayTextPerState_101: {
		en: "Books about card games and Bridge. No real evidence for the investigation.",
		zh: "有关扑克牌游戏和桥牌的书，找不到有助调查的证据。"
	},
	Id_DisplayTextPerState_102: {
		en: "These flowers are dried out and are not of any interest for the investigation.",
		zh: "这些花已经干枯，找不到有助调查的证据。"
	},
	Id_Ending_Final_Solution_Text_0: {
		en: "Anna Taylor <char=07> was president of the Bridge Club, but also a terrible player. Her partner Rose Butterfly <char=09> is a true competitor. To stop Anna from participating in the tournament (and therefore to get a new partner) Rose offered Anna a cake with a trace of digitalis, hoping to make her temporarily sick.@ But Anna wasn't young anymore, and her body couldn't support the quantity of the digitalis found in the cake. Nor could her cats, by the way. @Rose, on the other hand, will be able to start her own Bridge club... in prison.",
		zh: "安娜·泰勒<char=07>是桥牌会主席，牌却打得很烂。她的搭档露丝·伯特菲却很有实力，力争上游。为了阻止安娜参赛（顺便找一位新搭档），露丝给安娜送去一个加了一点毛地黄的蛋糕，希望使她病一阵子。@可是安娜不再年轻了，身体承受不了那个剂量的毛地黄。顺带一提，猫儿也受不了。@露丝现在可以建立她自己的桥牌会……在狱中。"
	},
	Id_Item_Name_9: {
		en: "Flowers",
		zh: "花朵"
	},
	Id_DisplayTextPerState_103: {
		en: "These Flowers dried out and are not of any interest for the investigation.",
		zh: "这些花已经干枯，找不到有助调查的证据。"
	},
	Id_DisplayTextPerState_104: {
		en: "I'm a florist, so I know a lot about flowers.",
		zh: "我是花店店主，所以熟知花卉。"
	},
	Id_DisplayTextPerState_105: {
		en: "I'm a florist, so I know a lot about flowers.",
		zh: "我是花店店主，所以熟知花卉。"
	},
	Id_DisplayTextPerState_106: {
		en: "Digitoxin or digitalis <itm=04> is a cardiac glycoside extract from a flower commonly called the Foxglove, or in Latin, <i>Digitalis purpurea</i>.",
		zh: "毛地黄毒是从俗称洋地黄（学名叫<i>Digitalis purpurea</i>）的花朵中提取出来的强心苷。"
	},
	Id_DisplayTextPerState_107: {
		en: "Digitoxin or digitalis <itm=04> is a cardiac glycoside extract from a flower commonly called the Foxglove, or in Latin, <i>Digitalis purpurea</i>.",
		zh: "毛地黄毒是从俗称洋地黄（学名叫<i>Digitalis purpurea</i>）的花朵中提取出来的强心苷。"
	},
	Id_DisplayText_Action_16: {
		en: "The neighborhood investigation just finished. We learned that Anna Taylor <char=07> was a Bridge player, often practicing in a club on Leicester Square <loc=D>",
		zh: "我们向邻舍打听完消息了，得知安娜·泰勒<char=07>是一位桥牌玩家，经常在莱斯特广场<loc=D>的桥牌会练习。"
	},
	Id_DisplayTextPerState_108: {
		en: "I've discovered that the cake was delivered around 8pm to Anna Taylor.\nThe credit card with the name \"Rose Butterfly\" paid for the order.",
		zh: "我发现这蛋糕是晚上八时左右送给安娜·泰勒的。\n\n支付的信用卡持有人名叫「露丝·伯特菲」。"
	},
	Id_DisplayTextPerState_109: {
		en: "It's true. I confess. I sent a cake to Anna in order to get her sick and forfeit tomorrow's tournament. I never wanted her to die! ",
		zh: "我承认这是真的。我送出这蛋糕给安娜，希望她因此生病，缺席明天的大赛。但我没想过要她死！"
	},
	Id_DisplayText_Action_17: {
		en: "You have enough elements to solve this case.\nGo back to the Scotland Yard to give your report.",
		zh: "你已经有足够材料破案了。\n\n回去苏格兰场呈交报告吧。"
	},
	Id_DisplayText_Action_18: {
		en: "Some texts will give you information that will alter the attitude of some suspects. Come back to interrogate them when you think you have made an important finding.",
		zh: "有些文字会提供资讯，改变某些嫌疑犯的态度。若你自认为找到重大证据，再回头盘问他们吧。"
	},
	Id_DisplayText_Action_12: {
		en: "Select the Chief Officer <char=33> and press Talk to. Then select the victim <char=07> and press Ask about.",
		zh: "选择局长<char=33>，点击交谈按钮；再选择死者<char=07>，点击询问按钮，向他了解死者的情况。"
	},
	Id_DisplayText_Action_19: {
		en: "Select the victim <char=07>, then press Ask about to ask the Chief Officer <char=33> what he knows about her.",
		zh: "选择死者<char=07>，再点击底部的询问按钮，向局长<char=33>了解她的情况。"
	}
}, se = await fetch("games/chroniclesofcrime/data/data/chapter1-texts.json").then((e) => e.json()), ce = await fetch("games/chroniclesofcrime/data/data/additional-cases.json").then((e) => e.json()), le = await fetch("games/chroniclesofcrime/data/data/chapter2-texts.json").then((e) => e.json()), T = await fetch("games/chroniclesofcrime/data/data/chapter3-texts.json").then((e) => e.json()), ue = await fetch("games/chroniclesofcrime/data/data/pharaohs-texts.json").then((e) => e.json()), E = await fetch("games/chroniclesofcrime/data/data/roses-texts.json").then((e) => e.json()), de = [
	"410c03a6-9c5e-41d1-89bc-fbf88fb2017a",
	"e41d1577-af77-4179-bf0f-8adb28320ed0",
	"f764f62f-9997-4106-8999-b224503e7656",
	"2c3ef9cf-30c5-412a-87af-3a8f652b0ed1",
	"34e67ffb-a815-4466-a19b-d35bcb13a288",
	"42c77cba-a7de-4841-b74b-0ff48e7140d9",
	"4f2d7689-ef63-465e-b908-a096da22dc97",
	"c63d75a9-32b5-4097-a0a8-f42e204e3c64",
	"939df6cf-2b5d-4a99-8d3e-decf6d09636b",
	"d674f64e-ed0a-4f88-ac61-39cf91b1df9f"
], fe = await fetch("games/chroniclesofcrime/data/data/expansion-cases.json").then((e) => e.json()), D = await fetch("games/chroniclesofcrime/data/data/expansion-texts.json").then((e) => e.json()), pe = /*#__PURE__*/ JSON.parse("[{\"id\":\"79742cb9-c864-4ff9-92e4-138ff1743a39\",\"code\":\"a2\",\"label\":\"\",\"kind\":\"action\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Intimidation\",\"zh\":\"恫吓\"}},{\"id\":\"a4d99f12-4622-4e31-b0b1-705d2ef8aeb9\",\"code\":\"a3\",\"label\":\"\",\"kind\":\"action\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Break in\",\"zh\":\"擅闯\"}},{\"id\":\"6577f25b-1def-47c2-b575-0e4dd27be892\",\"code\":\"a4\",\"label\":\"\",\"kind\":\"action\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Corruption\",\"zh\":\"贿赂\"}},{\"id\":\"637ec9e7-8e3e-4334-9f17-73c50fa112f8\",\"code\":\"a1\",\"label\":\"\",\"kind\":\"action\",\"image\":3,\"atlas\":\"noir\",\"name\":{\"en\":\"Shadowing\",\"zh\":\"跟踪\"}},{\"id\":\"5c17725f-deac-40af-9d51-7e29f47ca745\",\"code\":\"c20\",\"label\":\"20\",\"kind\":\"character\",\"image\":4,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 20\",\"zh\":\"Character 20\"}},{\"id\":\"1d9033b7-d232-4f23-9e45-871dd2073511\",\"code\":\"c21\",\"label\":\"21\",\"kind\":\"character\",\"image\":5,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 21\",\"zh\":\"Character 21\"}},{\"id\":\"20c3604d-99e3-4371-b685-35ac6afbb7fd\",\"code\":\"c22\",\"label\":\"22\",\"kind\":\"character\",\"image\":6,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 22\",\"zh\":\"Character 22\"}},{\"id\":\"fcbe42d8-2ae1-418b-8ca9-c21718164ad3\",\"code\":\"c23\",\"label\":\"23\",\"kind\":\"character\",\"image\":7,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 23\",\"zh\":\"Character 23\"}},{\"id\":\"d36f637d-63ca-4d7f-a254-e3570e3c6a8c\",\"code\":\"c24\",\"label\":\"24\",\"kind\":\"character\",\"image\":8,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 24\",\"zh\":\"Character 24\"}},{\"id\":\"51c7aeb4-cd52-4fe1-8bb2-f4cf01008d41\",\"code\":\"c25\",\"label\":\"25\",\"kind\":\"character\",\"image\":9,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 25\",\"zh\":\"Character 25\"}},{\"id\":\"cf9c5341-3f71-4a67-9d24-3a82c312da2f\",\"code\":\"c26\",\"label\":\"26\",\"kind\":\"character\",\"image\":10,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 26\",\"zh\":\"Character 26\"}},{\"id\":\"85fd95b9-2f6f-4100-ae23-c330ab23e8be\",\"code\":\"c27\",\"label\":\"27\",\"kind\":\"character\",\"image\":11,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 27\",\"zh\":\"Character 27\"}},{\"id\":\"01da3cf6-c85d-45be-ab9e-3baf445f0dd9\",\"code\":\"c28\",\"label\":\"28\",\"kind\":\"character\",\"image\":12,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 28\",\"zh\":\"Character 28\"}},{\"id\":\"c2023847-fbe8-4353-96cd-d912d1261f95\",\"code\":\"c29\",\"label\":\"29\",\"kind\":\"character\",\"image\":13,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 29\",\"zh\":\"Character 29\"}},{\"id\":\"01a87255-0f3f-449f-b6d7-0a1785ff0df4\",\"code\":\"c01\",\"label\":\"01\",\"kind\":\"character\",\"image\":14,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 01\",\"zh\":\"Character 01\"}},{\"id\":\"102742e1-08dc-4bcf-8684-1755548a21af\",\"code\":\"c02\",\"label\":\"02\",\"kind\":\"character\",\"image\":15,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 02\",\"zh\":\"Character 02\"}},{\"id\":\"e863aa50-d4df-443d-9a99-71703893fa74\",\"code\":\"c03\",\"label\":\"03\",\"kind\":\"character\",\"image\":16,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 03\",\"zh\":\"Character 03\"}},{\"id\":\"f1cc8a15-78f0-46ff-8387-3cc9134bb370\",\"code\":\"c04\",\"label\":\"04\",\"kind\":\"character\",\"image\":17,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 04\",\"zh\":\"Character 04\"}},{\"id\":\"d73d8738-126f-4a8e-961d-e4989480407a\",\"code\":\"c05\",\"label\":\"05\",\"kind\":\"character\",\"image\":18,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 05\",\"zh\":\"Character 05\"}},{\"id\":\"adec5292-ba9c-4d38-a4cc-deba4558f696\",\"code\":\"c06\",\"label\":\"06\",\"kind\":\"character\",\"image\":19,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 06\",\"zh\":\"Character 06\"}},{\"id\":\"78939cd2-decb-407d-afe7-fda00d71b1e3\",\"code\":\"c07\",\"label\":\"07\",\"kind\":\"character\",\"image\":20,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 07\",\"zh\":\"Character 07\"}},{\"id\":\"c9b8819c-488c-41ff-be3f-ca790c3420ff\",\"code\":\"c08\",\"label\":\"08\",\"kind\":\"character\",\"image\":21,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 08\",\"zh\":\"Character 08\"}},{\"id\":\"2c1b57a5-07b3-42b1-aaac-1d35486af1de\",\"code\":\"c09\",\"label\":\"09\",\"kind\":\"character\",\"image\":22,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 09\",\"zh\":\"Character 09\"}},{\"id\":\"e5d3484d-2de3-48f3-b478-c38f71b5b98b\",\"code\":\"c10\",\"label\":\"10\",\"kind\":\"character\",\"image\":23,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 10\",\"zh\":\"Character 10\"}},{\"id\":\"7071ff0a-17e5-4165-85c6-b4e41964dc44\",\"code\":\"c11\",\"label\":\"11\",\"kind\":\"character\",\"image\":24,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 11\",\"zh\":\"Character 11\"}},{\"id\":\"fd8e3a3e-4b90-425d-a96a-e3fe3d0db458\",\"code\":\"c12\",\"label\":\"12\",\"kind\":\"character\",\"image\":25,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 12\",\"zh\":\"Character 12\"}},{\"id\":\"3b3668dc-6ce4-4674-a5b7-bc246b5fe2f0\",\"code\":\"c13\",\"label\":\"13\",\"kind\":\"character\",\"image\":26,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 13\",\"zh\":\"Character 13\"}},{\"id\":\"b3a4ccfd-6507-4604-900f-03be45c492d6\",\"code\":\"c14\",\"label\":\"14\",\"kind\":\"character\",\"image\":27,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 14\",\"zh\":\"Character 14\"}},{\"id\":\"bcd14fe5-53d6-47cb-b785-6d914aa755e8\",\"code\":\"c15\",\"label\":\"15\",\"kind\":\"character\",\"image\":28,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 15\",\"zh\":\"Character 15\"}},{\"id\":\"7f8ba43c-417a-4d08-91cc-cd00e5143cfa\",\"code\":\"c16\",\"label\":\"16\",\"kind\":\"character\",\"image\":29,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 16\",\"zh\":\"Character 16\"}},{\"id\":\"f6b49cfb-a3b9-4838-afc3-a8b61ae22bca\",\"code\":\"c17\",\"label\":\"17\",\"kind\":\"character\",\"image\":30,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 17\",\"zh\":\"Character 17\"}},{\"id\":\"7f6d29a5-010c-4b0a-8550-8332179424d8\",\"code\":\"c18\",\"label\":\"18\",\"kind\":\"character\",\"image\":31,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 18\",\"zh\":\"Character 18\"}},{\"id\":\"3ebba1f1-8de7-47f4-934e-e57750d6405e\",\"code\":\"c19\",\"label\":\"19\",\"kind\":\"character\",\"image\":32,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 19\",\"zh\":\"Character 19\"}},{\"id\":\"b27e6bc3-b642-42b8-a981-d4e7bc7183b3\",\"code\":\"c30\",\"label\":\"30\",\"kind\":\"character\",\"image\":33,\"atlas\":\"noir\",\"name\":{\"en\":\"Character 30\",\"zh\":\"Character 30\"}},{\"id\":\"f280fa58-e68a-49c7-96c9-35878072d481\",\"code\":\"l01\",\"label\":\"\",\"kind\":\"location\",\"image\":34,\"atlas\":\"noir\",\"name\":{\"en\":\"Detective office \",\"zh\":\"侦探社 \"}},{\"id\":\"84517c73-163d-46cb-9773-4fbe0a24d1cd\",\"code\":\"lA\",\"label\":\"A\",\"kind\":\"location\",\"image\":35,\"atlas\":\"noir\",\"name\":{\"en\":\"Appartements\",\"zh\":\"住宅\"}},{\"id\":\"11dab9d3-0226-4065-91bf-f5176dfbe961\",\"code\":\"lB\",\"label\":\"B\",\"kind\":\"location\",\"image\":36,\"atlas\":\"noir\",\"name\":{\"en\":\"Club\",\"zh\":\"俱乐部\"}},{\"id\":\"2e57ace0-9d69-4b04-adaa-dfa73eecfdc7\",\"code\":\"lC\",\"label\":\"C\",\"kind\":\"location\",\"image\":37,\"atlas\":\"noir\",\"name\":{\"en\":\"Studios\",\"zh\":\"工作室\"}},{\"id\":\"d472dce2-6a1a-4a04-a5ae-1c26ac55f8d4\",\"code\":\"lD\",\"label\":\"D\",\"kind\":\"location\",\"image\":38,\"atlas\":\"noir\",\"name\":{\"en\":\"Luxurious House\",\"zh\":\"豪宅\"}},{\"id\":\"7d31e3b3-4172-4f6a-808e-b3278a1d74e1\",\"code\":\"lE\",\"label\":\"E\",\"kind\":\"location\",\"image\":39,\"atlas\":\"noir\",\"name\":{\"en\":\"Street\",\"zh\":\"街道\"}},{\"id\":\"2ce94a54-1b3e-4dfa-8ad2-d3b38fb83fc3\",\"code\":\"lF\",\"label\":\"F\",\"kind\":\"location\",\"image\":40,\"atlas\":\"noir\",\"name\":{\"en\":\"Docks\",\"zh\":\"码头\"}},{\"id\":\"d2165ccf-9378-42c8-bf69-2cbb8b98c94b\",\"code\":\"lG\",\"label\":\"G\",\"kind\":\"location\",\"image\":41,\"atlas\":\"noir\",\"name\":{\"en\":\"Hotel-Restaurant\",\"zh\":\"饭店餐厅\"}},{\"id\":\"e4e514d9-184e-4885-b792-99c8aa0b4b15\",\"code\":\"lH\",\"label\":\"H\",\"kind\":\"location\",\"image\":42,\"atlas\":\"noir\",\"name\":{\"en\":\"Station\",\"zh\":\"车站\"}},{\"id\":\"b653f786-af26-4516-9520-17f33fb57a3a\",\"code\":\"lI\",\"label\":\"I\",\"kind\":\"location\",\"image\":43,\"atlas\":\"noir\",\"name\":{\"en\":\"Dark Alley\",\"zh\":\"暗巷\"}},{\"id\":\"761f0d28-6734-4c18-9b50-b9cb4caea61b\",\"code\":\"lL\",\"label\":\"L\",\"kind\":\"location\",\"image\":44,\"atlas\":\"noir\",\"name\":{\"en\":\"Park Center\",\"zh\":\"公园中心\"}},{\"id\":\"134026f2-989e-480d-a42f-b5c3ddd288b8\",\"code\":\"lK\",\"label\":\"K\",\"kind\":\"location\",\"image\":45,\"atlas\":\"noir\",\"name\":{\"en\":\"Downtown\",\"zh\":\"市中心\"}},{\"id\":\"ce98e0fb-bc20-4321-bb99-2cac66962598\",\"code\":\"lJ\",\"label\":\"J\",\"kind\":\"location\",\"image\":46,\"atlas\":\"noir\",\"name\":{\"en\":\"Glass Villa\",\"zh\":\"玻璃别墅\"}},{\"id\":\"c0f586cc-a7e2-4d70-bfd3-fdafd39892f0\",\"code\":\"lN\",\"label\":\"N\",\"kind\":\"location\",\"image\":47,\"atlas\":\"noir\",\"name\":{\"en\":\"Library\",\"zh\":\"图书馆\"}},{\"id\":\"03d6cf50-a673-4be9-a96a-d219777fcaf4\",\"code\":\"lM\",\"label\":\"M\",\"kind\":\"location\",\"image\":48,\"atlas\":\"noir\",\"name\":{\"en\":\"Bar\",\"zh\":\"酒吧\"}},{\"id\":\"974efe04-8187-44f8-ac1c-0c1c886a6f02\",\"code\":\"s01\",\"label\":\"16\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 16\",\"zh\":\"特殊物品16\"}},{\"id\":\"d7ccbde2-b55c-44f9-b6da-1675e2a46694\",\"code\":\"s02\",\"label\":\"17\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 17\",\"zh\":\"特殊物品17\"}},{\"id\":\"784d6add-1ec1-4922-884f-1f296eb0c74e\",\"code\":\"s03\",\"label\":\"18\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 18\",\"zh\":\"特殊物品18\"}},{\"id\":\"cbbbeb41-1a45-4d83-ba2f-c21e9b6d9e58\",\"code\":\"s04\",\"label\":\"19\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 19\",\"zh\":\"特殊物品19\"}},{\"id\":\"d60a3e97-81e8-4db3-a19e-fc38ad6d6288\",\"code\":\"s05\",\"label\":\"20\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 20\",\"zh\":\"特殊物品20\"}},{\"id\":\"90b627c3-9510-4b66-82fa-49d10a906387\",\"code\":\"s06\",\"label\":\"21\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 21\",\"zh\":\"特殊物品21\"}},{\"id\":\"c8376005-6886-4681-b61a-9c58ecac4947\",\"code\":\"s07\",\"label\":\"22\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 22\",\"zh\":\"特殊物品22\"}},{\"id\":\"baee27c4-6929-4308-8b25-bc967c3e7f84\",\"code\":\"s08\",\"label\":\"23\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 23\",\"zh\":\"特殊物品23\"}},{\"id\":\"71be37e2-acfa-41de-9899-4f382a7f8e19\",\"code\":\"s09\",\"label\":\"24\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 24\",\"zh\":\"特殊物品24\"}},{\"id\":\"a3e21f08-7142-47a6-ac68-8dc5651258c8\",\"code\":\"s10\",\"label\":\"25\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"noir\",\"name\":{\"en\":\"Special item 25\",\"zh\":\"特殊物品25\"}},{\"id\":\"56ebe6de-f383-4ab8-af4a-39d87232893b\",\"code\":\"a1\",\"label\":\"\",\"kind\":\"action\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Fitness\",\"zh\":\"体能\"}},{\"id\":\"49e40569-f11e-4e16-82c6-e54cc3d5e910\",\"code\":\"a2\",\"label\":\"\",\"kind\":\"action\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Speach\",\"zh\":\"沟通\"}},{\"id\":\"fd301af6-46d9-46b2-aa87-b17b7838be7a\",\"code\":\"a3\",\"label\":\"\",\"kind\":\"action\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Mind\",\"zh\":\"头脑\"}},{\"id\":\"5360a0cf-ff6e-47ef-8f19-f02e96932a9f\",\"code\":\"a4\",\"label\":\"\",\"kind\":\"action\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Hint\",\"zh\":\"提示\"}},{\"id\":\"c2325eeb-2468-4a07-91b8-f90a223a5862\",\"code\":\"c20\",\"label\":\"20\",\"kind\":\"character\",\"image\":4,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 20\",\"zh\":\"Character 20\"}},{\"id\":\"34f6fd6c-2df1-48c4-9ac7-3ef105920fa4\",\"code\":\"c21\",\"label\":\"21\",\"kind\":\"character\",\"image\":5,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 21\",\"zh\":\"Character 21\"}},{\"id\":\"fa34f0b5-c4fb-474f-acb8-04f5c1e31cf4\",\"code\":\"c22\",\"label\":\"22\",\"kind\":\"character\",\"image\":6,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 22\",\"zh\":\"Character 22\"}},{\"id\":\"340749b8-97ac-4384-a884-28a5ae1ff1a3\",\"code\":\"c23\",\"label\":\"23\",\"kind\":\"character\",\"image\":7,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 23\",\"zh\":\"Character 23\"}},{\"id\":\"028a7256-1bd6-4d3f-8d4b-1ed17c30861b\",\"code\":\"c24\",\"label\":\"24\",\"kind\":\"character\",\"image\":8,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 24\",\"zh\":\"Character 24\"}},{\"id\":\"a776b31b-a57f-4dc8-b697-efbe12c3dec5\",\"code\":\"c25\",\"label\":\"25\",\"kind\":\"character\",\"image\":9,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 25\",\"zh\":\"Character 25\"}},{\"id\":\"651f4423-f2e9-472b-9d4f-e49b91d78256\",\"code\":\"c26\",\"label\":\"26\",\"kind\":\"character\",\"image\":10,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 26\",\"zh\":\"Character 26\"}},{\"id\":\"894928e1-ca92-4c4f-9e6b-9ef6f0a96945\",\"code\":\"c27\",\"label\":\"27\",\"kind\":\"character\",\"image\":11,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 27\",\"zh\":\"Character 27\"}},{\"id\":\"0dabe867-3d6c-4407-b8b4-22faa9a022fa\",\"code\":\"c28\",\"label\":\"28\",\"kind\":\"character\",\"image\":12,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 28\",\"zh\":\"Character 28\"}},{\"id\":\"e3744d44-897a-4ca5-94f9-566ef4b179b6\",\"code\":\"c29\",\"label\":\"29\",\"kind\":\"character\",\"image\":13,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 29\",\"zh\":\"Character 29\"}},{\"id\":\"d7138fc6-bff1-425d-b536-b989202e7dcc\",\"code\":\"c01\",\"label\":\"01\",\"kind\":\"character\",\"image\":14,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 1\",\"zh\":\"Character 1\"}},{\"id\":\"5c8c73c2-d56c-4930-8f7f-beffc2674643\",\"code\":\"c02\",\"label\":\"02\",\"kind\":\"character\",\"image\":15,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 2\",\"zh\":\"Character 2\"}},{\"id\":\"ef2b5617-d809-45fe-85fe-ad7747339ad2\",\"code\":\"c03\",\"label\":\"03\",\"kind\":\"character\",\"image\":16,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 3\",\"zh\":\"Character 3\"}},{\"id\":\"dc2a3892-2fcd-424b-b5fb-bd19090efc4b\",\"code\":\"c04\",\"label\":\"04\",\"kind\":\"character\",\"image\":17,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 4\",\"zh\":\"Character 4\"}},{\"id\":\"2884e88c-2cd6-492f-860c-cf153f416211\",\"code\":\"c05\",\"label\":\"05\",\"kind\":\"character\",\"image\":18,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 5\",\"zh\":\"Character 5\"}},{\"id\":\"1e24c43f-365c-4ca6-93a2-3764814721e4\",\"code\":\"c06\",\"label\":\"06\",\"kind\":\"character\",\"image\":19,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 6\",\"zh\":\"Character 6\"}},{\"id\":\"24bd8091-235c-477b-b520-4049cd84e47f\",\"code\":\"c07\",\"label\":\"07\",\"kind\":\"character\",\"image\":20,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 7\",\"zh\":\"Character 7\"}},{\"id\":\"78b75627-2fd9-49e1-867e-e3a5a228f1cf\",\"code\":\"c08\",\"label\":\"08\",\"kind\":\"character\",\"image\":21,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 8\",\"zh\":\"Character 8\"}},{\"id\":\"39cc0c95-1177-4127-a362-4dad4a2994c7\",\"code\":\"c09\",\"label\":\"09\",\"kind\":\"character\",\"image\":22,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 9\",\"zh\":\"Character 9\"}},{\"id\":\"1d2e02aa-b6cd-476e-be81-36a3e0f03259\",\"code\":\"c10\",\"label\":\"10\",\"kind\":\"character\",\"image\":23,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 10\",\"zh\":\"Character 10\"}},{\"id\":\"ad94811a-4b14-40ab-93a9-b827955ab0c2\",\"code\":\"c11\",\"label\":\"11\",\"kind\":\"character\",\"image\":24,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 11\",\"zh\":\"Character 11\"}},{\"id\":\"899bf412-3fa4-4b8b-a61d-60dab9088313\",\"code\":\"c12\",\"label\":\"12\",\"kind\":\"character\",\"image\":25,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 12\",\"zh\":\"Character 12\"}},{\"id\":\"c0063a18-01e9-4cc4-8f44-00a6b0e64f94\",\"code\":\"c13\",\"label\":\"13\",\"kind\":\"character\",\"image\":26,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 13\",\"zh\":\"Character 13\"}},{\"id\":\"88a2e4a3-f6f0-455f-89b7-705efc478450\",\"code\":\"c14\",\"label\":\"14\",\"kind\":\"character\",\"image\":27,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 14\",\"zh\":\"Character 14\"}},{\"id\":\"e323eaa1-25d6-4fa3-8ae3-7a5730fbce4c\",\"code\":\"c15\",\"label\":\"15\",\"kind\":\"character\",\"image\":28,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 15\",\"zh\":\"Character 15\"}},{\"id\":\"3082a4e2-4d13-4b58-ac84-40c7ac75a1a7\",\"code\":\"c16\",\"label\":\"16\",\"kind\":\"character\",\"image\":29,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 16\",\"zh\":\"Character 16\"}},{\"id\":\"0f265ff1-005f-4ee3-968d-81fb0b73b8a3\",\"code\":\"c17\",\"label\":\"17\",\"kind\":\"character\",\"image\":30,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 17\",\"zh\":\"Character 17\"}},{\"id\":\"8495985d-68ee-480a-bf55-cbf8cc63105e\",\"code\":\"c18\",\"label\":\"18\",\"kind\":\"character\",\"image\":31,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 18\",\"zh\":\"Character 18\"}},{\"id\":\"ca2e4e9b-ebf7-4b78-be52-8cf1c6f7a137\",\"code\":\"c19\",\"label\":\"19\",\"kind\":\"character\",\"image\":32,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 19\",\"zh\":\"Character 19\"}},{\"id\":\"fbf6bd1d-f796-45ad-8d53-bcddd3124382\",\"code\":\"c30\",\"label\":\"30\",\"kind\":\"character\",\"image\":33,\"atlas\":\"redview\",\"name\":{\"en\":\"Character 30\",\"zh\":\"Character 30\"}},{\"id\":\"77e787e1-a317-4754-9b49-c5e4f34919a0\",\"code\":\"lA\",\"label\":\"A\",\"kind\":\"location\",\"image\":34,\"atlas\":\"redview\",\"name\":{\"en\":\"Location A\",\"zh\":\"地点A\"}},{\"id\":\"14e30885-df74-447e-a974-619617e13744\",\"code\":\"lB\",\"label\":\"B\",\"kind\":\"location\",\"image\":35,\"atlas\":\"redview\",\"name\":{\"en\":\"Location B\",\"zh\":\"地点B\"}},{\"id\":\"1c67e154-e44c-4edd-83d8-6e6f9e03cf1a\",\"code\":\"lC\",\"label\":\"C\",\"kind\":\"location\",\"image\":36,\"atlas\":\"redview\",\"name\":{\"en\":\"Location C\",\"zh\":\"地点C\"}},{\"id\":\"c64decab-322a-4455-91be-75ac33d1ebed\",\"code\":\"lD\",\"label\":\"D\",\"kind\":\"location\",\"image\":37,\"atlas\":\"redview\",\"name\":{\"en\":\"Location D\",\"zh\":\"地点D\"}},{\"id\":\"8fc00db7-a943-43ff-8ea2-a4e7d3411b7e\",\"code\":\"lE\",\"label\":\"E\",\"kind\":\"location\",\"image\":38,\"atlas\":\"redview\",\"name\":{\"en\":\"Location E\",\"zh\":\"地点E\"}},{\"id\":\"3cae25ae-d1e9-48bb-b9d3-982cc38fa050\",\"code\":\"lF\",\"label\":\"F\",\"kind\":\"location\",\"image\":39,\"atlas\":\"redview\",\"name\":{\"en\":\"Location F\",\"zh\":\"地点F\"}},{\"id\":\"148d8038-8256-4d83-8999-62ae30a4bae0\",\"code\":\"lG\",\"label\":\"G\",\"kind\":\"location\",\"image\":40,\"atlas\":\"redview\",\"name\":{\"en\":\"Location G\",\"zh\":\"地点G\"}},{\"id\":\"5fa63ff3-045f-4439-ad88-b9b302a9bb93\",\"code\":\"lH\",\"label\":\"H\",\"kind\":\"location\",\"image\":41,\"atlas\":\"redview\",\"name\":{\"en\":\"Location H\",\"zh\":\"地点H\"}},{\"id\":\"3935c70a-5018-4a6c-83ef-b8b320979608\",\"code\":\"lI\",\"label\":\"I\",\"kind\":\"location\",\"image\":42,\"atlas\":\"redview\",\"name\":{\"en\":\"Location I\",\"zh\":\"地点I\"}},{\"id\":\"808fafaf-47cd-4f4b-83ce-877f5a37b908\",\"code\":\"lJ\",\"label\":\"J\",\"kind\":\"location\",\"image\":43,\"atlas\":\"redview\",\"name\":{\"en\":\"Location J\",\"zh\":\"地点J\"}},{\"id\":\"7f05f004-2740-40db-b6b2-1b60f67e0519\",\"code\":\"lN\",\"label\":\"N\",\"kind\":\"location\",\"image\":44,\"atlas\":\"redview\",\"name\":{\"en\":\"Location N\",\"zh\":\"地点N\"}},{\"id\":\"40bc19e1-e5b7-4cc2-8a78-52178367a0d1\",\"code\":\"lM\",\"label\":\"M\",\"kind\":\"location\",\"image\":45,\"atlas\":\"redview\",\"name\":{\"en\":\"Location M\",\"zh\":\"地点M\"}},{\"id\":\"301b3554-39ac-4df0-a19f-ab81a0c13c58\",\"code\":\"lL\",\"label\":\"L\",\"kind\":\"location\",\"image\":46,\"atlas\":\"redview\",\"name\":{\"en\":\"Location L\",\"zh\":\"地点L\"}},{\"id\":\"15b1cc21-5f56-452b-bc52-a78d0934f5eb\",\"code\":\"lK\",\"label\":\"K\",\"kind\":\"location\",\"image\":47,\"atlas\":\"redview\",\"name\":{\"en\":\"Location K\",\"zh\":\"地点K\"}},{\"id\":\"adee3c50-9802-4580-bb6f-dcf0409240df\",\"code\":\"l01\",\"label\":\"\",\"kind\":\"location\",\"image\":48,\"atlas\":\"redview\",\"name\":{\"en\":\"HQ\",\"zh\":\"总部\"}},{\"id\":\"02fc2dfc-9bf4-4c25-bc86-fad161dea7d8\",\"code\":\"s01\",\"label\":\"26\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 26\",\"zh\":\"特殊物品26\"}},{\"id\":\"5507ea61-d8e0-4398-89e0-4696d5e9dc7d\",\"code\":\"s02\",\"label\":\"27\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 27\",\"zh\":\"特殊物品27\"}},{\"id\":\"fc2d29d5-07c9-419c-b4af-0c1d15ed78f7\",\"code\":\"s03\",\"label\":\"28\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 28\",\"zh\":\"特殊物品28\"}},{\"id\":\"f4102edf-79d3-4e7d-b769-4ac32c7dbfc7\",\"code\":\"s04\",\"label\":\"29\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 29\",\"zh\":\"特殊物品29\"}},{\"id\":\"990e04dc-152e-4c23-820f-710c34641c81\",\"code\":\"s05\",\"label\":\"30\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 30\",\"zh\":\"特殊物品30\"}},{\"id\":\"ca4866d4-93ba-434d-b1f8-2517e1163a46\",\"code\":\"s06\",\"label\":\"31\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 31\",\"zh\":\"特殊物品31\"}},{\"id\":\"3e11699c-8ed7-40f3-80ae-4188895447f9\",\"code\":\"s07\",\"label\":\"32\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 32\",\"zh\":\"特殊物品32\"}},{\"id\":\"236a8251-8bca-4a2f-899b-ca4a13b7de92\",\"code\":\"s08\",\"label\":\"33\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 33\",\"zh\":\"特殊物品33\"}},{\"id\":\"19e656cc-4f3b-46b3-9d06-c0b3d9b749e9\",\"code\":\"s09\",\"label\":\"34\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 34\",\"zh\":\"特殊物品34\"}},{\"id\":\"3ea449f4-9842-4118-917c-dc882c2ca38d\",\"code\":\"s10\",\"label\":\"35\",\"kind\":\"special\",\"image\":-1,\"atlas\":\"redview\",\"name\":{\"en\":\"Special item 35\",\"zh\":\"特殊物品35\"}}]"), O = [
	"1e724a44-73a0-4d57-a5aa-05249a3c9e82",
	"30c195b4-fb92-490b-a467-cfa16fbe1fb6",
	"04d69a9d-89af-4e1a-ab61-531a672a94e3",
	"297e7a0a-b263-45b8-bad1-f549e13af5be",
	"63e394e4-f00d-40c7-8ea5-a374106ee99b",
	"ed710f97-3a27-45ff-9270-c564a94706f2",
	"f91bb4f1-7762-4d52-ba62-cd0e96e5ea06",
	"8a926c92-857f-44f6-9a27-78a7105853cd",
	"a5e2e320-6bc4-4db3-9867-1cd8af14dc22",
	"0112034f-4d17-41b3-873a-7641619172d8",
	"37aa4d15-c653-475e-a285-aa5cfea93d86",
	"52af6c37-ab67-4f40-9b3f-f952970b1a13",
	"7c5510a8-7876-4a7a-bb81-fc244cc43bf7",
	"84e639f1-2fe6-4fb4-8afc-c3df7c4cd132",
	"10ed00ba-596e-4f51-be0e-ae485d5d5314",
	"9f4d1301-37c8-48bf-9d34-faf52a1ca8e8",
	"242b66f0-ac78-4f72-8f7b-802706da2739",
	"ec605e54-273d-4585-a0c7-b99636df351e"
], k = [
	"tutorial",
	"chapter1",
	"chapter2",
	"chapter3",
	"pharaohs",
	"roses",
	"noir1",
	"noir2",
	"noir3",
	"noir4",
	"redview1",
	"redview2",
	"redview3",
	"redview4"
], A = {
	tutorial: "games.chroniclesofcrime.tutorial",
	chapter1: "games.chroniclesofcrime.chapter1",
	chapter2: "games.chroniclesofcrime.chapter2",
	chapter3: "games.chroniclesofcrime.chapter3",
	pharaohs: "games.chroniclesofcrime.pharaohs",
	roses: "games.chroniclesofcrime.roses",
	noir1: "games.chroniclesofcrime.noir1",
	noir2: "games.chroniclesofcrime.noir2",
	noir3: "games.chroniclesofcrime.noir3",
	noir4: "games.chroniclesofcrime.noir4",
	redview1: "games.chroniclesofcrime.redview1",
	redview2: "games.chroniclesofcrime.redview2",
	redview3: "games.chroniclesofcrime.redview3",
	redview4: "games.chroniclesofcrime.redview4"
}, me = {
	tutorial: "chapter1",
	chapter1: "chapter2",
	chapter2: "chapter3",
	redview1: "redview2",
	redview2: "redview3",
	redview3: "redview4"
}, he = [
	"base",
	"noir",
	"redview"
], ge = {
	base: "games.chroniclesofcrime.base",
	noir: "games.chroniclesofcrime.noir",
	redview: "games.chroniclesofcrime.redview"
}, j = (e) => e.startsWith("noir") ? "noir" : e.startsWith("redview") ? "redview" : "base", M = [
	{
		id: "alex",
		name: "Alex",
		skills: [
			2,
			2,
			2
		],
		energy: 1
	},
	{
		id: "jeff",
		name: "Jeff",
		skills: [
			1,
			1,
			1
		],
		energy: 4
	},
	{
		id: "richy",
		name: "Richy",
		skills: [
			0,
			3,
			1
		],
		energy: 2
	},
	{
		id: "sarah",
		name: "Sarah",
		skills: [
			2,
			2,
			1
		],
		energy: 2
	},
	{
		id: "tom",
		name: "Tom",
		skills: [
			3,
			0,
			1
		],
		energy: 2
	},
	{
		id: "victoria",
		name: "Victoria",
		skills: [
			1,
			1,
			3
		],
		energy: 1
	}
], N = [
	"alex",
	"jeff",
	"richy",
	"sarah",
	"tom",
	"victoria"
], P = [
	"games.chroniclesofcrime.fitness",
	"games.chroniclesofcrime.mind",
	"games.chroniclesofcrime.speech"
], _e = [
	"games.chroniclesofcrime.easy",
	"games.chroniclesofcrime.normal",
	"games.chroniclesofcrime.hard"
], F = {
	...ae,
	...ce,
	...fe
}, I = [...w, ...pe], ve = {
	tutorial: oe,
	chapter1: se,
	chapter2: le,
	chapter3: T,
	pharaohs: ue,
	roses: E,
	...D
}, ye = [
	"c864db5f-47d2-4d7d-bbb3-faa6090204b9",
	"ad923c06-6345-4817-9be5-e50b0fe4a936",
	"b617f5a0-7029-43b6-b137-5e1b86e972e5",
	...de,
	...O
], L = (e) => [
	...F[e].Locations,
	...F[e].Characters,
	...F[e].Items
];
function R(e) {
	let t = j(e);
	return I.filter((e) => t === "base" ? !e.atlas : e.atlas === t || !e.atlas && (e.kind === "category" || e.kind === "special"));
}
function be(e) {
	return R(e).find((e) => e.kind === "location" && e.code === "l01");
}
function xe(e, t, n = "tutorial") {
	let r = e === "char" ? "character" : e === "loc" ? "location" : e === "itm" ? "special" : "category", i = t.trim().toLowerCase(), a = R(n).filter((e) => e.kind === r);
	return a.find((e) => e.label && e.label.toLowerCase() === i.padStart(r === "character" || r === "special" ? 2 : 1, "0")) ?? a.find((e) => e.code.slice(1).toLowerCase() === i.padStart(2, "0"));
}
//#endregion
//#region src/games/chroniclesofcrime/meta.ts
var Se = {
	id: "chroniclesofcrime",
	tier: "beta",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.chroniclesofcrime.name",
	descKey: "games.chroniclesofcrime.desc",
	rulesKey: "games.chroniclesofcrime.rules",
	icon: "🕵️",
	iconImg: "games/chroniclesofcrime.webp",
	rulesUrl: { en: "https://luckyduckgames.com/usa/index.php?controller=attachment&id_attachment=1004" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#77603e",
	releasedAt: "2026-10-17T23:40:13+08:00",
	search: {
		py: "tui li shi jian bu",
		init: "tlsjb"
	},
	hotseat: "open",
	precacheAssets: /* @__PURE__ */ "noir-cards.webp,redview-cards.webp,1e724a44-73a0-4d57-a5aa-05249a3c9e82.webp,30c195b4-fb92-490b-a467-cfa16fbe1fb6.webp,04d69a9d-89af-4e1a-ab61-531a672a94e3.webp,297e7a0a-b263-45b8-bad1-f549e13af5be.webp,63e394e4-f00d-40c7-8ea5-a374106ee99b.webp,ed710f97-3a27-45ff-9270-c564a94706f2.webp,f91bb4f1-7762-4d52-ba62-cd0e96e5ea06.webp,8a926c92-857f-44f6-9a27-78a7105853cd.webp,a5e2e320-6bc4-4db3-9867-1cd8af14dc22.webp,0112034f-4d17-41b3-873a-7641619172d8.webp,37aa4d15-c653-475e-a285-aa5cfea93d86.webp,52af6c37-ab67-4f40-9b3f-f952970b1a13.webp,7c5510a8-7876-4a7a-bb81-fc244cc43bf7.webp,84e639f1-2fe6-4fb4-8afc-c3df7c4cd132.webp,10ed00ba-596e-4f51-be0e-ae485d5d5314.webp,9f4d1301-37c8-48bf-9d34-faf52a1ca8e8.webp,242b66f0-ac78-4f72-8f7b-802706da2739.webp,ec605e54-273d-4585-a0c7-b99636df351e.webp,cards.webp,c864db5f-47d2-4d7d-bbb3-faa6090204b9.webp,ad923c06-6345-4817-9be5-e50b0fe4a936.webp,b617f5a0-7029-43b6-b137-5e1b86e972e5.webp,410c03a6-9c5e-41d1-89bc-fbf88fb2017a.webp,e41d1577-af77-4179-bf0f-8adb28320ed0.webp,f764f62f-9997-4106-8999-b224503e7656.webp,2c3ef9cf-30c5-412a-87af-3a8f652b0ed1.webp,34e67ffb-a815-4466-a19b-d35bcb13a288.webp,42c77cba-a7de-4841-b74b-0ff48e7140d9.webp,4f2d7689-ef63-465e-b908-a096da22dc97.webp,c63d75a9-32b5-4097-a0a8-f42e204e3c64.webp,939df6cf-2b5d-4a99-8d3e-decf6d09636b.webp,d674f64e-ed0a-4f88-ac61-39cf91b1df9f.webp".split(",")
}, z = (e, t, n, r, i = 0) => ({
	card: e,
	textId: t === "intro" ? "Id_Scenario_Introduction" : t.replace(/^l/, "Id_LocationState_Introduction_").replace(/^d/, "Id_DisplayTextPerState_").replace(/^a/, "Id_DisplayText_Action_"),
	part: i,
	summary: {
		zh: n,
		en: r
	}
}), Ce = {
	tutorial: [
		z("c33", "l3", "警察局长", "Police chief"),
		z("c07", "d77", "桥牌会成员", "Bridge club member"),
		z("c07", "a16", "桥牌会成员", "Bridge club member"),
		z("c07", "d50", "桥牌会主席", "Bridge club president"),
		z("c09", "d29", "自称花店店主、安娜的桥牌搭档", "Says she owns a flower shop and is Anna’s bridge partner"),
		z("c04", "d82", "自称兽医", "Says she is a veterinarian")
	],
	chapter1: [
		z("c33", "intro", "警察局长", "Police chief"),
		z("c14", "d5", "大使的女儿", "The ambassador’s daughter"),
		z("c15", "l4", "大使", "Ambassador"),
		z("c48", "l3", "领事馆保安", "Consulate security guard"),
		z("c46", "d1", "被指为公园里的毒贩", "Described as a drug dealer in the park"),
		z("c41", "d24", "被称作流浪汉", "Described as homeless"),
		z("c40", "intro", "园丁、遗体发现者", "Gardener who found the body", 1),
		z("c10", "d5", "被称作卡拉的保姆", "Described as Clara’s nanny"),
		z("c16", "d50", "自称为布兰奇太太工作", "Says she works for Mrs Blanche"),
		z("c49", "d222", "自称酒保", "Says he is a bartender")
	],
	chapter2: [
		z("c33", "intro", "警察局长", "Police chief"),
		z("c37", "intro", "圣玛丽医院院长", "Director of St Mary’s Hospital", 1),
		z("c02", "l3", "私家侦探事务所老板", "Private detective agency owner"),
		z("c49", "d306", "酒保", "Bartender"),
		z("c35", "d348", "自称曾任军医、现正写书", "Says he was an army doctor and is writing a book"),
		z("c40", "l11", "园丁", "Gardener"),
		z("c39", "d298", "银行家", "Banker"),
		z("c01", "l7", "艾利的妻子", "Eli’s wife"),
		z("c43", "d82", "警员", "Police officer"),
		z("c08", "l9", "孤儿院院长", "Orphanage director"),
		z("c45", "l9", "教师", "Teacher"),
		z("c26", "l9", "孤儿院的孩子", "Child at the orphanage"),
		z("c09", "l0", "医生", "Doctor"),
		z("c28", "d60", "自称为生病的工友代班", "Says he is covering for a sick janitor"),
		z("c12", "d490", "自称在海德公园工作", "Says she works at Hyde Park"),
		z("c31", "d179", "自称住在医院楼下病房", "Says he is a patient on the floor below")
	],
	chapter3: [
		z("c33", "l0", "警察局长", "Police chief"),
		z("c15", "a4", "法国大使", "French ambassador"),
		z("c47", "a0", "戴尔局长的儿子", "Chief Dale’s son", 1),
		z("c21", "l3", "首相", "Prime minister"),
		z("c36", "intro", "国安局局长", "Director of national security", 1),
		z("c18", "intro", "国安局局长的私人秘书", "Private secretary to the security director", 1),
		z("c22", "d91", "一等兵", "Private first class"),
		z("c43", "d490", "警察同僚", "Fellow police officer"),
		z("c24", "d80", "自称有三十余年军旅经历的上校", "Says he is a colonel with over thirty years of service"),
		z("c19", "d177", "自称爱尔兰共和军成员", "Says she is an IRA member"),
		z("c23", "d403", "自称一等兵", "Says he is a private")
	],
	pharaohs: [
		z("c17", "intro", "大英博物馆策展人", "British Museum curator", 2),
		z("c11", "d122", "自称查理斯的女儿", "Says she is Charles’s daughter"),
		z("c52", "d195", "自称已退休的古代历史教授", "Says he is a retired ancient history professor"),
		z("c48", "d11", "自称大英博物馆保安", "Says he is a British Museum security guard"),
		z("c53", "d46", "诺丁山古董店老板", "Notting Hill antiques shop owner", 2),
		z("c49", "d32", "被称作古董交易中介", "Described as an antiques broker", 1),
		z("c46", "d73", "自称豪斯特庄园管理员", "Says he manages the Howster estate"),
		z("c22", "d87", "自称艾德蒙爵士的女儿", "Says she is Sir Edmund’s daughter"),
		z("c39", "intro", "总警官", "Police superintendent"),
		z("c38", "d281", "自称无处可去、住在码头", "Says he has nowhere to live except the docks"),
		z("c14", "d331", "自称八岁、住在废墟附近", "Says she is eight and lives near the ruins"),
		z("c27", "d119", "贵族、古艺术爱好者", "Nobleman and ancient art enthusiast")
	],
	roses: [
		z("c15", "intro", "总警官", "Police superintendent", 1),
		z("c03", "intro", "失踪女子", "Missing woman", 1),
		z("c03", "d22", "被称作模特儿同事", "Described as a fellow model"),
		z("c02", "d22", "被称作模特儿同事", "Described as a fellow model"),
		z("c20", "d22", "被称作模特儿同事", "Described as a fellow model"),
		z("c50", "d19", "被称作奈莉的男朋友", "Described as Nelly’s boyfriend"),
		z("c31", "d23", "被称作剧场演员", "Described as a stage actor"),
		z("c45", "l1", "在餐饮街工作", "Works in the restaurant district"),
		z("c37", "l9", "负责现场的警探", "Detective at the crime scene"),
		z("c05", "d22", "自称模特儿、酒吧兼职人员", "Says she models and works part-time at a bar"),
		z("c42", "d15", "被称作剧场导演", "Described as a theatre director"),
		z("c55", "d100", "自称模特儿经纪人", "Says he is a modelling agent")
	],
	noir1: [
		z("c14", "d1", "死者邵玛的父亲", "Thelma’s father"),
		z("c12", "d2", "女演员、本案死者", "Actress and victim"),
		z("c20", "l1", "验尸官", "Medical examiner"),
		z("c02", "l1", "记者朋友", "Journalist friend"),
		z("c16", "l7", "看守现场的警员", "Officer guarding the scene", 1),
		z("c09", "l6", "餐厅负责人、厨师", "Restaurant manager and chef"),
		z("c22", "l4", "电影导演", "Film director", 1),
		z("c11", "d64", "被称作罗布的妻子、前影星", "Described as Rob’s wife and a former film star", 1),
		z("c17", "d122", "被称作邵玛的前夫、经纪人", "Described as Thelma’s ex-husband and agent"),
		z("c08", "d179", "被称作幸运鸭酒吧老板", "Described as the Lucky Duck’s owner"),
		z("c06", "d395", "凡斯的保镖", "Vance’s bodyguard"),
		z("c28", "l3", "电影工作室警卫", "Film studio guard"),
		z("c15", "d153", "自称邵玛的女佣、司机", "Says she is Thelma’s maid and chauffeur")
	],
	noir2: [
		z("c06", "l0", "事故汽车的驾驶员", "Driver in the car crash"),
		z("c27", "l2", "侦探的秘书", "The detective’s secretary"),
		z("c13", "d57", "女演员", "Actress", 1),
		z("c07", "d58", "咖啡集团继承人、珍娜的丈夫", "Coffee company heir and Jenna’s husband"),
		z("c22", "d105", "被称作电影制片人", "Described as a film producer"),
		z("c11", "d109", "被称作珍娜的朋友、演出同事", "Described as Jenna’s friend and fellow performer", 1),
		z("c03", "d170", "被称作摄影师", "Described as a photographer", 1),
		z("c23", "l14", "拳击选手", "Boxer"),
		z("c19", "l14", "拳击选手", "Boxer"),
		z("c21", "d70", "撞球酒吧经营者", "Pool bar operator"),
		z("c02", "d51", "先驱报犯罪记者", "Herald crime reporter"),
		z("c15", "l5", "图书馆馆员", "Librarian"),
		z("c01", "d332", "自称电影工作室编剧", "Says he is a studio scriptwriter"),
		z("c12", "d214", "自称二十岁、希望成为演员", "Says she is twenty and an aspiring actress"),
		z("c05", "d278", "黑帮老大", "Mob boss")
	],
	noir3: [
		z("c15", "d2", "自称彼得的姐姐、本案委托人", "Client who says she is Peter’s sister"),
		z("c19", "d2", "据姐姐所述为退伍军人、医护兵", "Sister describes him as a veteran and medic", 1),
		z("c11", "intro", "侦探的秘书", "The detective’s secretary"),
		z("c20", "d149", "撒寇诊所医生", "Doctor at Sako’s clinic", 1),
		z("c10", "l14", "值班护理师", "Nurse on duty"),
		z("c24", "l1", "邻居、算命师", "Neighbour and fortune teller"),
		z("c14", "d139", "被称作彼得的朋友", "Described as Peter’s friend"),
		z("c29", "d58", "自称继承了母亲的餐厅", "Says she inherited her mother’s restaurant"),
		z("c16", "d34", "负责本案的警探", "Detective assigned to the case"),
		z("c09", "l22", "卡利家的管家", "The Carlit family’s butler"),
		z("c25", "l11", "卡利饭店持有人", "Carlit Hotel owner"),
		z("c12", "d64", "女演员", "Actress"),
		z("c23", "d147", "被称作酒保", "Described as a bartender"),
		z("c28", "l8", "在码头工作的老朋友", "Old friend working at the docks"),
		z("c22", "d405", "专门饰演警员的演员", "Actor specialising in police roles"),
		z("c13", "d238", "自称在诊所接受治疗", "Says she is being treated at the clinic"),
		z("c26", "d363", "自称曾任卡利家的园丁", "Says he was the Carlit family’s groundskeeper"),
		z("c17", "d144", "被称作电影制片人", "Described as a film producer")
	],
	noir4: [
		z("c20", "l2", "医院医生", "Hospital doctor"),
		z("c22", "l15", "负责现场的警探", "Detective at the scene"),
		z("c27", "d4", "自称旺德利教授的侄女", "Says she is Professor Wonderley’s niece"),
		z("c09", "d4", "被称作大学考古学家", "Described as a university archaeologist"),
		z("c05", "l9", "保镖、守卫", "Bodyguard and guard", 1),
		z("c08", "l9", "知名黑帮人物", "Known gangster"),
		z("c12", "l9", "奈西的妻子", "Nacy’s wife"),
		z("c23", "a4", "货轮二副", "Ship’s second mate"),
		z("c28", "a10", "货轮船长", "Ship’s captain"),
		z("c30", "d48", "古董店帮手、王李梅的弟弟", "Antiques shop assistant and Mei’s brother"),
		z("c29", "d48", "艺术品商人", "Art dealer"),
		z("c01", "intro", "记者朋友", "Journalist friend"),
		z("c11", "l13", "鞋店销售员", "Shoe shop assistant"),
		z("c19", "d222", "货轮电报员", "Ship’s radio operator"),
		z("c17", "l18", "饭店接待员", "Hotel receptionist")
	],
	redview1: [
		z("c03", "d12", "高三科学老师", "Senior-year science teacher"),
		z("c14", "l7", "与母亲同住", "Lives with his mother"),
		z("c06", "d81", "加油站老板", "Gas station owner", 2),
		z("c22", "l4", "学校校长", "School principal"),
		z("c13", "d64", "被称作高中体育老师", "Described as the high-school PE teacher", 1),
		z("c29", "l10", "小镇警长", "Town sheriff"),
		z("c26", "d48", "自称在红景镇行医三十五年", "Says he has practised medicine in Redview for thirty-five years", 1),
		z("c04", "d95", "自称帮助法兰克打理加油站", "Says she helps Frank run the gas station"),
		z("c08", "d226", "自称经营酒吧八年", "Says he has run the bar for eight years")
	],
	redview2: [
		z("c01", "intro", "小镇警长", "Town sheriff", 1),
		z("c22", "l9", "学校校长", "School principal"),
		z("c03", "l9", "学校老师", "School teacher"),
		z("c25", "l2", "动物收容所工作人员", "Animal shelter worker"),
		z("c20", "d26", "苏丹王宫宠物店店主", "Sultan’s Palace pet shop owner"),
		z("c30", "d261", "警长的狗", "The sheriff’s dog"),
		z("c02", "l6", "漫画与游戏店老板", "Comics and games shop owner"),
		z("c21", "d320", "被称作记者", "Described as a journalist"),
		z("c04", "d97", "自称在餐厅工作", "Says she works at the restaurant"),
		z("c11", "d283", "自称本季啦啦队队长", "Says she is this season’s cheerleading captain"),
		z("c05", "d366", "被称作作家", "Described as a writer", 1)
	],
	redview3: [
		z("c03", "intro", "科学老师", "Science teacher", 2),
		z("c26", "l2", "医院医生", "Hospital doctor"),
		z("c27", "l0", "博物馆策展人", "Museum curator", 1),
		z("c07", "l5", "小镇镇长", "Town mayor"),
		z("c08", "l13", "酒吧老板", "Bar owner"),
		z("c15", "l20", "工地工人", "Construction worker"),
		z("c10", "l20", "工地工人", "Construction worker"),
		z("c01", "l0", "小镇警长", "Town sheriff", 1),
		z("c09", "d148", "自称负责管理工地工人", "Says he supervises construction workers")
	],
	redview4: [
		z("c01", "l3", "小镇警长", "Town sheriff"),
		z("c02", "d53", "电子游戏店老板", "Video game shop owner"),
		z("c07", "l4", "小镇镇长", "Town mayor"),
		z("c12", "Id_DisplayTextPerState_Yes_3", "地产建商", "Property developer", 1),
		z("c13", "Id_DisplayTextPerState_Yes_18", "体育老师", "PE teacher"),
		z("c21", "l3", "记者", "Journalist"),
		z("c24", "l18", "旅馆接待人员", "Hotel receptionist"),
		z("c29", "d35", "曾任小镇警长", "Former town sheriff", 1),
		z("c26", "l7", "医院医生", "Hospital doctor"),
		z("c14", "d198", "自称游戏程序员、伊利亚德游戏公司创办人", "Says he develops games and founded Iliad Games", 1),
		z("c05", "l25", "作家", "Writer")
	]
};
function we(e, t) {
	let n = ve[e][t.textId];
	return {
		zh: n.zh.split("@")[t.part] ?? "",
		en: n.en.split("@")[t.part] ?? ""
	};
}
function Te(e, t) {
	return R(e).find((e) => e.code === t.card)?.id;
}
var Ee = (e) => `${e.card}:${e.textId}:${e.part}`, De = t.record(t.string().max(80), t.number().finite().int()), Oe = t.object({
	caseId: t.enum(k).default("tutorial"),
	campaign: De.optional(),
	roleId: t.enum(N).default("alex")
}).prefault({}), ke = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("scan"),
		code: t.string().min(1).max(64)
	}),
	t.object({ type: t.literal("next") }),
	t.object({ type: t.literal("leave") }),
	t.object({ type: t.literal("investigate") }),
	t.object({ type: t.literal("scene_ready") }),
	t.object({ type: t.literal("exit_scene") }),
	t.object({ type: t.literal("solve") }),
	t.object({
		type: t.literal("answer"),
		cardId: t.string().max(64)
	}),
	t.object({ type: t.literal("abort_ending") }),
	t.object({
		type: t.literal("notes"),
		text: t.string().max(4e3)
	}),
	t.object({ type: t.literal("special") }),
	t.object({
		type: t.literal("choice"),
		answer: t.enum([
			"yes",
			"no",
			"cancel"
		])
	}),
	t.object({ type: t.literal("roll") }),
	t.object({ type: t.literal("resolve_test") }),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite().nonnegative()
	})
]), B = t.object({
	zh: t.string(),
	en: t.string()
}), V = t.object({
	id: t.string(),
	code: t.string(),
	label: t.string(),
	kind: t.enum([
		"location",
		"character",
		"category",
		"expert",
		"special",
		"action"
	]),
	atlas: t.enum(["noir", "redview"]).optional(),
	image: t.number().int(),
	name: B,
	categoryName: B.optional()
}), Ae = t.object({
	id: t.string(),
	card: V
}), je = t.object({
	group: t.number().int(),
	time: t.number().int(),
	kind: t.enum(["action", "event"]),
	location: B.nullable(),
	person: B.nullable(),
	subject: B.nullable(),
	locationId: t.string().nullable().optional(),
	personId: t.string().nullable().optional(),
	subjectId: t.string().nullable().optional()
}), Me = t.object({
	serial: t.number().int(),
	text: B,
	kind: t.enum(["dialogue", "tutorial"]).optional(),
	clues: t.array(Ae).optional(),
	source: t.object({
		textId: t.string(),
		part: t.number().int()
	}).optional(),
	record: je.optional()
}), Ne = t.object({
	caseId: t.enum(k),
	phase: t.enum([
		"investigation",
		"scene",
		"ending",
		"done"
	]),
	gameTime: t.number().int(),
	elapsed: t.number().int(),
	location: V.nullable(),
	context: V.nullable(),
	cards: t.array(V),
	current: Me.nullable(),
	history: t.array(Me),
	cardActions: t.record(t.string(), t.enum([
		"talk",
		"ask",
		"examine",
		"contact",
		"analyze",
		"travel",
		"use"
	])),
	money: t.number().nullable().optional(),
	role: t.object({
		id: t.enum(N),
		name: t.string(),
		skills: t.array(t.number()),
		energy: t.number().int(),
		maximumEnergy: t.number().int(),
		fatigued: t.boolean()
	}).nullable().optional(),
	specialAction: B.nullable().optional(),
	interaction: t.object({
		kind: t.enum(["choice", "test"]),
		title: B,
		prompt: B,
		cancelable: t.boolean(),
		skill: t.number().int(),
		difficulty: t.number().int(),
		modifier: t.number().int(),
		rolls: t.array(t.number().int()),
		successes: t.number().int(),
		canRoll: t.boolean(),
		successLabels: t.boolean()
	}).nullable().optional(),
	readingAction: t.enum([
		"next",
		"investigation",
		"interview",
		"scene",
		"ending",
		"interaction"
	]).nullable(),
	profiles: t.record(t.string(), t.array(t.object({
		summary: B,
		excerpt: B
	}))).optional(),
	forcedEnding: t.boolean().optional(),
	canInvestigate: t.boolean(),
	canSolve: t.boolean(),
	canLeave: t.boolean(),
	scene: t.object({
		id: t.string(),
		remaining: t.number(),
		ready: t.boolean()
	}).nullable(),
	question: t.object({
		index: t.number().int(),
		total: t.number().int(),
		mandatory: t.boolean(),
		text: B
	}).nullable(),
	notes: t.string(),
	result: t.object({
		total: t.number().int(),
		maximum: t.number().int(),
		stars: t.number().int(),
		answers: t.array(t.object({
			question: B,
			answer: V.nullable(),
			score: t.number().int()
		})),
		stateScore: t.number().int(),
		timeScore: t.number().int(),
		penalty: t.number().int(),
		outro: B,
		solution: B,
		campaign: De.optional()
	}).nullable()
}), Pe = t.object({}), Fe = {
	zh: "",
	en: ""
}, Ie = 4e4, H = (e) => F[e.caseId], U = (e, t) => L(e.caseId).find((e) => e.UniqueId === t), W = (e, t) => t.States.find((n) => n.UniqueId === e.states[t.UniqueId]), G = (e) => e.context.at(-1) ?? "", K = (e) => e.context.find((t) => H(e).Locations.some((e) => e.UniqueId === t)) ?? "", q = (e) => H(e).EndingScript.Variants.find((t) => t.UniqueId === (e.endingVariantId ?? H(e).EndingScript.DefaultVariantId)) ?? H(e).EndingScript.Variants[0], J = (e, t) => ve[e.caseId][t] ?? Fe, Y = (e, t) => !e || e.split(/[,;\s]+/).includes(t), X = (e, t) => {
	let n = L(e.caseId).find((e) => e.UniqueId === t || e.ScanCode === t), r = R(e.caseId).find((e) => e.id === (n?.ScanCode ?? t));
	if (!r) return null;
	if (r.kind === "category") return n && (W(e, n)?.ShowUI === 1 || e.reportedEvidence?.includes(n.UniqueId) || e.foundItems?.includes(n.UniqueId)) ? {
		...r,
		name: J(e, n.Name),
		categoryName: r.name
	} : r;
	let i = n && J(e, n.Name);
	return i?.en || i?.zh ? {
		...r,
		name: i
	} : r;
};
function Le(e) {
	let t = X(e, G(e)), n = e.scanContext && X(e, e.scanContext.objectId), r = t?.kind === "character" || t?.kind === "expert", i = X(e, K(e)), a = n && n.id !== t?.id && n.kind !== "location" ? n : null;
	return {
		group: e.serial + 1,
		time: e.gameTime,
		kind: "action",
		location: i?.name ?? null,
		locationId: i?.id ?? null,
		person: r ? t.name : null,
		personId: r ? t.id : null,
		subject: a?.name ?? null,
		subjectId: a?.id ?? null
	};
}
function Re(e) {
	return e.phase === "investigation" && e.pages.length === 1 && !e.interaction && !e.pendingInteractions?.length && !e.queuedEnergyTest;
}
function ze(e) {
	return Ce[e.caseId].flatMap((t) => {
		let n = we(e.caseId, t), r = e.knownProfiles?.includes(Ee(t)) || e.history.some((e) => e.source ? e.source.textId === t.textId && e.source.part === t.part : e.text.en === n.en && e.text.zh === n.zh), i = Te(e.caseId, t);
		return r && i ? [{
			id: i,
			summary: t.summary,
			excerpt: n
		}] : [];
	});
}
var Be = {
	Id_DisplayText_Default_16: [1],
	Id_DisplayTextPerState_99: [1]
}, Ve = {
	tutorial: [
		"Id_DisplayTextPerState_100",
		"Id_DisplayTextPerState_101",
		"Id_DisplayTextPerState_102",
		"Id_DisplayTextPerState_103"
	],
	chapter1: [
		"Id_DisplayTextPerState_130",
		"Id_DisplayTextPerState_163",
		"Id_DisplayTextPerState_196",
		"Id_DisplayTextPerState_197",
		"Id_DisplayTextPerState_227",
		"Id_DisplayTextPerState_262",
		"Id_DisplayTextPerState_226",
		"Id_DisplayTextPerState_293"
	],
	chapter2: [
		"Id_DisplayTextPerState_50",
		"Id_DisplayTextPerState_191",
		"Id_DisplayTextPerState_51",
		"Id_DisplayTextPerState_518"
	],
	chapter3: [
		"Id_DisplayTextPerState_289",
		"Id_DisplayTextPerState_290",
		"Id_DisplayTextPerState_291",
		"Id_DisplayTextPerState_139",
		"Id_DisplayTextPerState_141",
		"Id_DisplayTextPerState_469"
	],
	pharaohs: [
		"Id_DisplayTextPerState_191",
		"Id_DisplayTextPerState_159",
		"Id_DisplayTextPerState_163"
	],
	roses: [
		"Id_DisplayTextPerState_118",
		"Id_DisplayTextPerState_126",
		"Id_DisplayTextPerState_110",
		"Id_DisplayTextPerState_111",
		"Id_DisplayTextPerState_112",
		"Id_DisplayTextPerState_114",
		"Id_DisplayTextPerState_115"
	]
};
function He(e, t, n, r) {
	return /^\s*<ui=Tutorial>/.test(J(e, t).en.split("@")[n] ?? "") ? !0 : e.caseId === "tutorial" ? Be[t]?.includes(n) || t === "Id_Scenario_Introduction" || t === "Id_LocationState_Introduction_4" ? !0 : r === 6 : !1;
}
function Ue(e, t) {
	t.phase === "ending" && !t.pages.length && !q(t).Questions.length && (t.result = ct(t), t.phase = "done"), !t.interaction && t.pendingInteractions?.length && (t.interaction = t.pendingInteractions.shift()), t.queuedEnergyTest && !t.interaction && t.phase === "investigation" && (delete t.queuedEnergyTest, t.energyRisk = !0, t.interaction = {
		entry: {
			Mode: 6,
			Text: "Id_DisplayText_Action_34",
			ActionSettings: {
				ActionCardType: 0,
				ActionCardDifficulty: 1,
				Text: ""
			}
		},
		rolls: [],
		successes: 0
	});
	let n = [], r = t.pages[0];
	return r && r.serial !== e.pages[0]?.serial && r.clues?.length && n.push({
		kind: "discoverClues",
		data: {
			serial: r.serial,
			clues: r.clues
		}
	}), t.gameTime > e.gameTime && n.push({
		kind: "timeSpent",
		data: { minutes: t.gameTime - e.gameTime },
		with: n.length > 0
	}), !n.length && e.pages[0]?.serial !== r?.serial && n.push({ kind: "readingAdvance" }), {
		state: t,
		...n.length ? { fx: n } : {}
	};
}
function We(e) {
	let t = e.pages[0];
	if (t && e.history.at(-1)?.serial !== t.serial) {
		Ce[e.caseId].forEach((n) => {
			let r = Ee(n);
			t.source?.textId === n.textId && t.source.part === n.part && !e.knownProfiles?.includes(r) && (e.knownProfiles ??= []).push(r);
		}), e.history.push(t), e.history.length > 500 && e.history.shift();
		for (let n of t.text.en.matchAll(/<(char|loc|itm|cat)\s*=\s*([^>]+)>/g)) {
			let r = xe(n[1], n[2], e.caseId);
			r && !e.discovered.includes(r.id) && (e.discovered.push(r.id), r.kind !== "category" && r.kind !== "expert" && (t.clues ??= []).push({
				id: r.id,
				card: X(e, r.id)
			}));
		}
		if (t.text.en.includes("<home>")) {
			let n = be(e.caseId);
			n && !e.discovered.includes(n.id) && (e.discovered.push(n.id), t.clues ??= [], t.clues.push({
				id: n.id,
				card: X(e, n.id)
			}));
		}
	}
}
function Z(e, t, n) {
	(e.caseId === "redview1" && t === "Id_DisplayText_Action_9" || e.caseId === "redview2" && t === "Id_DisplayText_Action_11" || e.caseId === "redview3" && ["Id_DisplayText_Action_2", "Id_DisplayText_Action_12"].includes(t) || e.caseId === "redview4" && [
		"Id_DisplayText_Action_15",
		"Id_DisplayText_Action_16",
		"Id_DisplayText_Action_35"
	].includes(t)) && (e.energy = at(e).energy, e.fatigued = !1), e.caseId === "redview2" && t === "Id_DisplayTextPerState_80" && (e.energy = Math.max(0, (e.energy ?? 0) - 1)), e.caseId === "redview3" && ["Id_DisplayText_Action_5", "Id_DisplayText_Action_6"].includes(t) && (e.fatigued = !0), e.caseId === "redview4" && t === "Id_DisplayText_Action_34" && (e.queuedEnergyTest = !0);
	let r = J(e, t), i = r.en.split("@"), a = r.zh.split("@");
	if (!r.en.trim() && !r.zh.trim()) return;
	let o = Le(e);
	for (let r = 0; r < Math.max(i.length, a.length); r++) e.pages.push({
		serial: ++e.serial,
		kind: He(e, t, r, n) ? "tutorial" : "dialogue",
		text: {
			en: i[r] ?? "",
			zh: a[r] ?? i[r] ?? ""
		},
		source: {
			textId: t,
			part: r
		},
		record: { ...o }
	});
	We(e);
}
function Ge(e, t) {
	let n = U(e, t.UniqueIdForChangeState);
	if (!n || !n.States.some((e) => e.UniqueId === t.NewStateUniqueId) || !Y(t.FromStatesUniqueIds, e.states[n.UniqueId])) return;
	let r = W(e, n);
	e.states[n.UniqueId] = t.NewStateUniqueId;
	let i = W(e, n);
	if (r?.ShowUI !== 1 && i?.ShowUI === 1 && H(e).Items.includes(n) && !(e.reportedEvidence ?? []).includes(n.UniqueId)) {
		(e.reportedEvidence ??= []).push(n.UniqueId);
		let t = X(e, n.ScanCode);
		if (t) return {
			id: n.UniqueId,
			card: {
				...t,
				name: J(e, n.Name)
			}
		};
	}
}
function Ke(e, t, n) {
	let r = e.pages.filter((e) => e.serial > t), i = r.find((e) => e.kind !== "tutorial") ?? r[0];
	i && n.length && (i.clues ??= []).push(...n);
}
function qe(e, t) {
	let n = e.serial, r = t.map((t) => et(e, t)).filter((e) => !!e);
	for (let t of [...e.pages, ...e.history]) t.serial > n && t.record?.kind !== "event" && (t.record = {
		...t.record,
		group: n + 1,
		kind: "event",
		person: null,
		personId: null,
		subject: null,
		subjectId: null
	});
	Ke(e, n, r);
}
function Je(e, t) {
	e.interaction ? (e.pendingInteractions ??= []).push(t) : e.interaction = t;
}
function Ye(e, t, n = !1) {
	let r = H(e).Events.find((e) => e.UniqueId === t);
	if (!r) return;
	let i = r.Triggers.filter((r) => !n || r.Conditions.every((n) => $e(e, n, t))), a = n && r.Type === 0 ? i.slice(0, 1) : i;
	a.length && r.Type === 0 && (e.events[t].enabled = !1);
	for (let t of a) qe(e, t.Actions);
}
function Xe(e, t) {
	for (let n of t) {
		let t = n.VariableUniqueId ?? n.VariableId ?? "";
		if (!(t in e.variables)) continue;
		let r = Number(n.NewValue ?? n.Value);
		Number.isFinite(r) && (e.variables[t] = n.Mode === 1 ? e.variables[t] + r : n.Mode === 2 ? e.variables[t] - r : r);
	}
}
function Ze(e, t, n) {
	n === 0 ? e.gameTime = t : n === 1 ? e.gameTime += t : e.gameTime = (Math.floor(e.gameTime / 1440) + 1) * 1440 + t;
}
function Qe(e, t, n = 0) {
	return [
		e === t,
		e !== t,
		e < t,
		e <= t,
		e > t,
		e >= t
	][n] ?? !1;
}
function $e(e, t, n) {
	let r = t.$type.split(",")[0].split(".").at(-1);
	if (r === "ObjectStateCheck") {
		let n = Y(t.ObjectStateUniqueId ?? "", e.states[t.ObjectUniqueId ?? ""]);
		return t.ObjectStateCheckType === 1 ? !n : n;
	}
	if (r === "InsideOrOutsideLocation") {
		let n = K(e) === t.LocationUniqueId;
		return t.InsideOrOutsideLocationCheckType === 1 ? !n : n;
	}
	if (r === "TimePassed") return e.gameTime >= (t.TimePassedSince === 1 ? e.events[n].since : 0) + (t.TimePassedInMinutes ?? 0);
	if (r === "CheckContextObject") return t.CheckType === 1 ? G(e) !== t.ObjectUniqueId : G(e) === t.ObjectUniqueId;
	if (r === "VariableValue") return Qe(e.variables[t.VariableUniqueId ?? ""] ?? 0, Number(t.Value), t.VariableCheckType);
	if (r === "CheckIfInterrogating") {
		let n = H(e).Characters.some((t) => t.UniqueId === G(e));
		return t.IsOrNotInterrogatingCheckTypeCheckType === 1 ? !n : n;
	}
	if (r === "ObjectScanned") {
		let n = e.scanContext;
		return !!n && n.objectId === t.ScannedObjectUniqueId && Y(t.ScannedObjectStateUniqueId ?? "", n.objectState) && (!t.ContextUniqueId || n.contextId === t.ContextUniqueId) && Y(t.ContextStateUniqueId ?? "", n.contextState);
	}
	return !1;
}
function et(e, t) {
	let n = t.$type.split(",")[0].split(".").at(-1);
	if (n === "DisplayText" && !t.UseAppLocalization) Z(e, t.Text ?? "", t.UiType), t.DisplayMode && t.DisplayMode !== 100 && Je(e, {
		entry: {
			Mode: t.DisplayMode === 6 ? 5 : t.DisplayMode,
			Text: t.Text ?? ""
		},
		yesEventId: t.YesEventId,
		noEventId: t.NoEventId,
		rolls: [],
		successes: 0
	});
	else if (n === "SetObjectState") return Ge(e, {
		UniqueIdForChangeState: t.UniqueIdForChangeState ?? "",
		FromStatesUniqueIds: t.FromStatesUniqueIds ?? "",
		NewStateUniqueId: t.NewStateUniqueId ?? ""
	});
	else if (n === "EnableDisableEvent") {
		let n = e.events[t.EventUniqueId ?? ""];
		if (!n) return;
		let r = t.OperationType === 1 ? !1 : t.OperationType !== 3 || n.enabled;
		n.enabled = r, n.version++, r && (n.since = e.gameTime), (t.OperationType === 2 || t.OperationType === 3) && Ye(e, t.EventUniqueId ?? "");
	} else if (n === "ChangeGameTime") Ze(e, t.TimeInMinutes ?? 0, t.ChangeType ?? 0);
	else if (n === "SetVariable") Xe(e, [{
		VariableUniqueId: t.VariableUniqueId,
		Value: t.Value,
		Mode: t.Mode ?? 0
	}]);
	else if (n === "SetIntroText") e.introductionId = t.Text;
	else if (n === "SetContext") {
		let n = U(e, t.ObjectUniqueId ?? "");
		if (!n) return;
		e.context = H(e).Locations.includes(n) ? [n.UniqueId] : [K(e), n.UniqueId].filter(Boolean);
		let r = X(e, n.UniqueId);
		r && !e.discovered.includes(r.id) && e.discovered.push(r.id);
	} else if (n === "TriggerEnding") {
		if (!H(e).EndingScript.Variants.some((e) => e.UniqueId === t.EndingVariantId)) return;
		e.endingVariantId = t.EndingVariantId, e.forcedEnding = !0, e.answers = [], e.scene = null, e.phase = "ending", delete e.interaction, delete e.pendingInteractions, delete e.queuedEnergyTest, delete e.energyRisk;
	}
}
function tt(e, t, n) {
	let r = t.$type.split(",")[0].split(".").at(-1);
	return r === "ObjectStateCheck" ? e.states[t.ObjectUniqueId ?? ""] : r === "InsideOrOutsideLocation" ? K(e) : r === "CheckContextObject" ? G(e) : r === "TimePassed" ? `${e.gameTime}:${e.events[n].since}` : r === "VariableValue" ? e.variables[t.VariableUniqueId ?? ""] : r === "CheckIfInterrogating" ? G(e) : r === "ObjectScanned" ? e.scanContext ?? null : "";
}
function Q(e) {
	for (let t = 0; t < 128; t++) {
		let t = [];
		for (let n of H(e).Events) {
			let r = e.events[n.UniqueId];
			if (r.enabled) for (let i of n.Triggers) {
				if (!i.Conditions.length) continue;
				let a = JSON.stringify([r.version, ...i.Conditions.map((t) => tt(e, t, n.UniqueId))]);
				if (e.checked[i.UniqueId] !== a && (e.checked[i.UniqueId] = a, i.Conditions.every((t) => $e(e, t, n.UniqueId)) && (n.Type === 0 && (r.enabled = !1), t.push({
					priority: i.Priority,
					actions: i.Actions
				}), n.Type === 0))) break;
			}
		}
		if (!t.length) break;
		t.sort((e, t) => t.priority - e.priority);
		for (let n of t) qe(e, n.actions);
	}
	We(e);
}
function nt(e, t, n, r) {
	return (!r.Location || K(e) === r.Location) && Y(r.ContextObjectState, e.states[t.UniqueId]) && Y(r.ScannedObjectState, e.states[n.UniqueId]) && (!r.OtherObject || Y(r.OtherObjectState, e.states[r.OtherObject])) && (!r.CheckVariable || Qe(e.variables[r.VariableId] ?? 0, Number(r.VariableValue), r.VariableCheckType));
}
function rt(e) {
	return e.OverrideInternalPriority ? e.CustomPriority : 1e4 + (e.Location ? 1e3 : 0) + (e.ContextObjectState ? 100 : 0) + (e.ScannedObjectState ? 10 : 0);
}
function it(e, t) {
	let n = W(e, t), r = U(e, G(e)), i = H(e).Characters.includes(t), a = n.IsContextMode === 3 ? e.context.map((t) => U(e, t)).reverse() : [r], o = null;
	for (let n of a) {
		let r = i ? n.MiniGames.QrCodeScanner.CharactersGrid : n.MiniGames.QrCodeScanner.ItemsGrid;
		for (let i of r.TextsPerState[t.UniqueId] ?? []) nt(e, n, t, i) && (!o || rt(i) >= rt(o.entry)) && (o = {
			context: n,
			entry: i
		});
	}
	return o;
}
var at = (e) => M.find((t) => t.id === e.roleId) ?? M[0];
function ot(e, t) {
	if (!t) return;
	let n = e.serial, r = t.StateChanges.map((t) => Ge(e, t)).filter((e) => !!e);
	Xe(e, t.VariablesChanges), t.EnableChangeGameTime && Ze(e, t.GameTimeInMinutes, t.GameTimeChangeType), t.EnableSetEventActivation && et(e, {
		$type: "EnableDisableEvent",
		EventUniqueId: t.SetEventActivationEventId,
		OperationType: t.SetEventActivationOperationType
	}), Z(e, t.Text), Ke(e, n, r);
}
function st(t, n) {
	let r = t.serial, i = R(t.caseId).find((e) => e.id === n || e.code.toLowerCase() === n.toLowerCase().replace(/^(lnd1|noir1|wtr1)_/, ""));
	i && !t.discovered.includes(i.id) && t.discovered.push(i.id);
	let a = i && L(t.caseId).find((e) => e.ScanCode === i.id);
	if (!a) {
		t.gameTime += H(t).Config.TimeCostInMinutes_UnusedScanCode, Z(t, H(t).Config.UnusedScanCodeMessage), Q(t);
		return;
	}
	let o = W(t, a);
	t.scanContext = {
		objectId: a.UniqueId,
		objectState: o.UniqueId,
		contextId: G(t),
		contextState: t.states[G(t)]
	};
	let s = H(t).Characters.some((e) => e.UniqueId === a.UniqueId);
	if (i.kind === "location") {
		o.IsContextMode === 0 ? Z(t, H(t).Config.ClosedLocationDefaultMessage) : K(t) === a.UniqueId ? Z(t, H(t).Config.SameLocationDefaultMessage) : (t.context = [a.UniqueId], t.gameTime += H(t).Config.TimeCostInMinutes_Move, Z(t, o.IntruductionMessage ?? "")), Q(t), delete t.scanContext;
		return;
	}
	let c = U(t, G(t)), l = it(t, a);
	if (l) {
		let e = l.entry.StateChanges.map((e) => Ge(t, e)).filter((e) => !!e);
		i.kind === "category" && H(t).Locations.includes(l.context) && Ve[t.caseId]?.includes(l.entry.Text) && !t.foundItems?.includes(a.UniqueId) && (t.foundItems ??= []).push(a.UniqueId), Xe(t, l.entry.VariablesChanges), !l.entry.DisableIsContext && o.IsContextMode && (H(t).Locations.some((e) => e.UniqueId === c.UniqueId) || o.IsContextMode === 3) && (t.context = [K(t), a.UniqueId].filter(Boolean));
		let n = t.serial;
		Z(t, l.entry.Text), Ke(t, n, e), [
			1,
			2,
			3,
			4,
			5,
			6
		].includes(l.entry.Mode) && Je(t, {
			entry: l.entry,
			rolls: [],
			successes: 0
		});
	} else {
		let n = (s ? c.MiniGames.QrCodeScanner.CharactersGrid : c.MiniGames.QrCodeScanner.ItemsGrid).RandomTextsPerState.filter((e) => !e.ContextObjectState || e.ContextObjectState === t.states[c.UniqueId]), r = n.find((e) => e.ContextObjectState) ?? n[0], i = r ? [
			r.DefaultText1,
			r.DefaultText2,
			r.DefaultText3
		].filter((e) => !!e && !!(J(t, e).en.trim() || J(t, e).zh.trim())) : [];
		i.length ? Z(t, i[e(t.seed, t.cursor++, i.length)]) : Z(t, H(t).Config.UnusedScanCodeMessage);
	}
	o.AddGameTimeWhenScanned && (t.gameTime += s ? H(t).Config.TimeCostInMinutes_Interrogate : H(t).Config.TimeCostInMinutes_ScanItem);
	for (let e of [...t.pages, ...t.history]) e.serial > r && e.record?.kind === "action" && (e.record = {
		...e.record,
		time: t.gameTime,
		group: r + 1
	});
	Q(t), delete t.scanContext;
}
function ct(e) {
	let t = q(e), n = H(e).Config, r = t.Questions.map((t, n) => ({
		question: J(e, t.Text),
		answer: X(e, e.answers[n]),
		score: t.Answers.find((t) => t.ObjectUniqueId === e.answers[n])?.Score ?? (t.ScorePenalty ? -t.ScorePenalty : 0)
	})), i = t.ObjectStateChecks.reduce((t, n) => t + (e.states[n.ObjectUniqueId] === n.ObjectStateUniqueId ? n.Score : 0), 0), a = e.gameTime - n.GameStartTime, o = 0;
	n.EnableTimeBonus && a < n.IdealPlayedTime ? o = Math.min(n.MaxTimeBonus, Math.ceil(Math.abs(n.MaxTimeBonus / (n.IdealPlayedTime - n.MaxBonusPlayedTime)) * (n.IdealPlayedTime - a))) : n.EnableTimeBonus && n.MaxTimePenalty > 0 && a > n.IdealPlayedTime && (o = -Math.min(n.MaxTimePenalty, Math.ceil(Math.abs(n.MaxTimePenalty / (n.MaxPenaltyPlayedTime - n.IdealPlayedTime)) * (a - n.IdealPlayedTime))));
	let s = Math.max(0, r.reduce((e, t) => e + t.score, 0) + i + o - e.penalty), c = t.Questions.reduce((e, t) => e + Math.max(0, ...t.Answers.map((e) => e.Score)), 0) + t.ObjectStateChecks.reduce((e, t) => e + Math.max(0, t.Score), 0), l = t.Finals.find((n) => n.Conditions.every((n) => Y(n.AnswersObjectUniqueId, e.answers[t.Questions.findIndex((e) => e.UniqueId === n.QuestionId)] ?? "")) && n.ObjectStateChecks.every((t) => Y(t.ObjectStateUniqueId, e.states[t.ObjectUniqueId])));
	l && Xe(e, l.VariablesChanges);
	let u = Object.fromEntries(H(e).VariablesManager.Variables.filter((e) => e.IsPublic).map((t) => [t.Name, e.variables[t.UniqueId]]));
	return {
		total: s,
		maximum: c,
		stars: n.StarsScores.filter((e) => s >= e).length,
		answers: r,
		stateScore: i,
		timeScore: o,
		penalty: e.penalty,
		outro: J(e, l?.Text ?? ""),
		solution: J(e, t.TextFinalSolution),
		campaign: u
	};
}
function lt(e, t) {
	let n = U(e, G(e)), r = n && W(e, n);
	return !!r && [r.SpecialAction, r.SecondSpecialAction].includes(t);
}
function ut(e) {
	let t = K(e), n = e.states[t];
	return ye.includes(n) ? n : ye.includes(t) ? t : null;
}
function dt(e) {
	return e.phase === "investigation" && (!e.pages.length || Re(e)) && lt(e, 1) && !!ut(e);
}
function ft(e, t) {
	return t.kind === "action" ? "use" : t.kind === "location" ? "travel" : t.kind === "expert" ? "contact" : X(e, G(e))?.kind === "expert" ? "analyze" : e.context.length > 1 ? "ask" : e.caseId === "tutorial" && t.code === "c07" ? "examine" : t.kind === "character" && H(e).Characters.some((e) => e.ScanCode === t.id) ? "talk" : "examine";
}
function pt(e, t) {
	if (t.kind !== "action") return !0;
	if (j(e.caseId) === "noir") return t.code !== "a4" || (e.variables[H(e).Config.CurrencyVariableId ?? ""] ?? 0) >= 20;
	let n = L(e.caseId).find((e) => e.ScanCode === t.id), r = n && it(e, n);
	return !!r && r.entry.Mode !== 0;
}
var mt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: Se,
	schemas: {
		action: ke,
		publicView: Ne,
		privateView: Pe,
		config: Oe
	},
	setup(e, t, n) {
		let { caseId: r, campaign: i, roleId: a } = Oe.parse(e), o = F[r], s = {
			players: t,
			seed: n,
			cursor: 0,
			caseId: r,
			phase: "investigation",
			gameTime: o.Config.GameStartTime,
			states: Object.fromEntries(L(r).map((e) => [e.UniqueId, e.InitialState])),
			variables: Object.fromEntries(o.VariablesManager.Variables.map((e) => [e.UniqueId, e.IsPublic && (r === "chapter2" || r === "chapter3") ? i?.[e.Name] ?? e.Value : e.Value])),
			context: [o.Config.StartLocationId],
			discovered: [],
			events: Object.fromEntries(o.Events.map((e) => [e.UniqueId, {
				enabled: e.Enabled,
				since: o.Config.GameStartTime,
				version: 0
			}])),
			checked: {},
			pages: [],
			history: [],
			serial: 0,
			notes: "",
			scene: null,
			answers: [],
			penalty: 0,
			result: null,
			...j(r) === "redview" ? {
				roleId: a,
				energy: M.find((e) => e.id === a).energy
			} : {}
		}, c = X(s, o.Config.StartLocationId);
		if (c && s.discovered.push(c.id), o.Config.StartEventId) {
			let e = o.Events.find((e) => e.UniqueId === o.Config.StartEventId);
			if (e) {
				for (let t of e.Triggers) if (t.Conditions.every((t) => $e(s, t, e.UniqueId)) && (e.Type === 0 && (s.events[e.UniqueId].enabled = !1), qe(s, t.Actions), e.Type === 0)) break;
			}
		}
		Z(s, s.introductionId ?? o.Config.IntruductionMessage);
		let l = U(s, K(s));
		return l && Z(s, W(s, l)?.IntruductionMessage ?? ""), Q(s), { state: s };
	},
	reduce(t, n, r) {
		if (n.type === "tick" ? r.by !== "$engine" : !t.players.includes(r.by)) return { code: "games.chroniclesofcrime.invalidAction" };
		let i = structuredClone(t);
		if (n.type === "tick") return !i.scene?.ready || i.phase !== "scene" ? { state: t } : (i.scene.deadline === null && (i.scene.deadline = n.now + i.scene.remaining), i.scene.remaining = Math.max(0, i.scene.deadline - n.now), i.scene.remaining || (i.scene = null, i.phase = "investigation", Q(i)), { state: i });
		if (n.type === "notes") return i.notes = n.text, { state: i };
		if (i.phase === "done") return { code: "games.chroniclesofcrime.invalidAction" };
		if (n.type === "next" && i.pages.length) return i.pages.shift(), We(i), Ue(t, i);
		if (n.type === "scene_ready" && i.scene) return i.scene.ready = !0, { state: i };
		if (n.type === "exit_scene" && i.scene) return i.scene = null, i.phase = "investigation", Q(i), { state: i };
		if (Re(i) && (i.pages = []), i.pages.length || i.phase === "scene") return { code: "games.chroniclesofcrime.readFirst" };
		if (i.interaction) {
			let r = i.interaction, a = r.entry.Mode;
			if (n.type === "choice" && a !== 6) {
				if (n.answer === "cancel" && ![3, 4].includes(a)) return { code: "games.chroniclesofcrime.invalidAction" };
				delete i.interaction, n.answer !== "cancel" && (ot(i, n.answer === "yes" ? r.entry.YesSettings : r.entry.NoSettings), Ye(i, (n.answer === "yes" ? r.yesEventId : r.noEventId) ?? ""));
			} else if (n.type === "roll" && a === 6 && (!r.rolls.length || !i.fatigued && (i.energy ?? 0) > 0) && r.successes < 1) {
				r.rolls.length && (i.energy = Math.max(0, (i.energy ?? 0) - 1));
				let t = e(i.seed, i.cursor++, 6) + 1, n = r.entry.ActionSettings, a = H(i).Config, o = [
					a.WtrActionEasyModifier ?? 1,
					a.WtrActionNormalModifier ?? 0,
					a.WtrActionHardModifier ?? -1
				][n.ActionCardDifficulty] ?? 0, s = t + (i.fatigued ? 0 : at(i).skills[n.ActionCardType]) + o;
				r.rolls.push(t), r.successes += s >= 7 ? 2 : +(s >= 5);
			} else if (n.type === "resolve_test" && a === 6 && r.rolls.length) delete i.interaction, i.energyRisk && (r.successes || (i.energy = 0), delete i.energyRisk), ot(i, r.successes >= 1 ? r.entry.YesSettings : r.entry.NoSettings);
			else return { code: "games.chroniclesofcrime.invalidAction" };
			return Q(i), Ue(t, i);
		}
		if (n.type === "abort_ending" && i.phase === "ending" && !i.forcedEnding) return i.phase = "investigation", i.answers = [], { state: i };
		if (n.type === "answer" && i.phase === "ending") {
			let e = q(i).Questions[i.answers.length];
			if (!e || n.cardId && !R(i.caseId).some((e) => e.id === n.cardId)) return { code: "games.chroniclesofcrime.invalidAction" };
			let t = L(i.caseId).find((e) => e.ScanCode === n.cardId)?.UniqueId ?? n.cardId;
			return e.QuestionType === 0 && !e.Answers.some((e) => e.ObjectUniqueId === t) ? (i.penalty += e.ScorePenalty, i.answers = [], i.phase = "investigation", Z(i, q(i).TextForWrongMandatoryAnswer)) : (i.answers.push(t), i.answers.length === q(i).Questions.length && (i.result = ct(i), i.phase = "done")), { state: i };
		}
		if (i.phase !== "investigation") return { code: "games.chroniclesofcrime.invalidAction" };
		if (n.type === "scan") {
			let e = n.code.trim(), t = R(i.caseId).find((t) => t.id === e || t.code.toLowerCase() === e.toLowerCase().replace(/^(lnd1|noir1|wtr1)_/, ""));
			if (t && !pt(i, t)) return { code: "games.chroniclesofcrime.invalidAction" };
			st(i, e);
		} else if (n.type === "special" && lt(i, 4)) {
			let e = W(i, U(i, G(i))), t = H(i).Events.find((t) => t.UniqueId === e.SpecialEventActionId);
			if (!t) return { code: "games.chroniclesofcrime.invalidAction" };
			Ye(i, t.UniqueId, !0), Q(i);
		} else if (n.type === "leave" && i.context.length > 1) i.context.pop(), Q(i);
		else if (n.type === "solve" && lt(i, 3)) i.phase = "ending", i.answers = [], delete i.endingVariantId, i.forcedEnding = !1;
		else if (n.type === "investigate" && dt(i)) i.gameTime += H(i).Config.TimeCostInMinutes_Investigate, i.scene = {
			id: ut(i),
			remaining: Ie,
			deadline: null,
			ready: !1
		}, i.phase = "scene", Q(i);
		else return { code: "games.chroniclesofcrime.invalidAction" };
		return Ue(t, i);
	},
	viewFor(e) {
		let t = e.phase === "ending" && !e.pages.length ? q(e).Questions[e.answers.length] : null, n = R(e.caseId).filter((t) => e.discovered.includes(t.id) || t.kind === "category" || t.kind === "expert" || t.kind === "action").map((t) => X(e, t.id)), r = H(e).Config, i = e.interaction, a = e.roleId ? at(e) : null, o = U(e, G(e)) && W(e, U(e, G(e))), s = n.filter((t) => pt(e, t)), c = i?.entry.ActionSettings, l = c?.ActionCardDifficulty ?? 1, u = {};
		for (let t of ze(e)) {
			let e = u[t.id] ??= [];
			e.some((e) => e.summary.en === t.summary.en) || e.push({
				summary: t.summary,
				excerpt: t.excerpt
			});
		}
		return {
			public: {
				caseId: e.caseId,
				phase: e.phase,
				gameTime: e.gameTime,
				elapsed: e.gameTime - H(e).Config.GameStartTime,
				location: X(e, K(e)),
				context: X(e, G(e)),
				cards: n,
				cardActions: Object.fromEntries(s.map((t) => [t.id, ft(e, t)])),
				money: r.EnableCurrency ? e.variables[r.CurrencyVariableId ?? ""] ?? 0 : null,
				role: a ? {
					id: a.id,
					name: a.name,
					skills: e.fatigued ? [
						0,
						0,
						0
					] : [...a.skills],
					energy: e.energy ?? 0,
					maximumEnergy: a.energy,
					fatigued: e.fatigued ?? !1
				} : null,
				specialAction: lt(e, 4) && o?.SpecialEventActionName ? J(e, o.SpecialEventActionName) : null,
				interaction: i ? {
					kind: i.entry.Mode === 6 ? "test" : "choice",
					title: J(e, c?.Text ?? ""),
					cancelable: [3, 4].includes(i.entry.Mode),
					prompt: J(e, i.entry.Text),
					skill: c?.ActionCardType ?? 0,
					difficulty: l,
					modifier: [
						r.WtrActionEasyModifier ?? 1,
						r.WtrActionNormalModifier ?? 0,
						r.WtrActionHardModifier ?? -1
					][l] ?? 0,
					rolls: i.rolls,
					successes: i.successes,
					canRoll: i.entry.Mode === 6 && i.successes < 1 && (!i.rolls.length || !e.fatigued && (e.energy ?? 0) > 0),
					successLabels: i.entry.Mode === 5
				} : null,
				current: e.pages[0] ?? null,
				history: e.history,
				readingAction: !e.pages.length || Re(e) ? null : e.pages.length > 1 ? "next" : e.phase === "scene" ? "scene" : e.phase === "ending" ? "ending" : i ? "interaction" : e.context.length > 1 ? "interview" : "investigation",
				profiles: u,
				forcedEnding: e.forcedEnding ?? !1,
				canInvestigate: !i && dt(e),
				canSolve: !i && e.phase === "investigation" && (!e.pages.length || Re(e)) && lt(e, 3),
				canLeave: !i && e.context.length > 1,
				scene: e.scene ? {
					id: e.scene.id,
					remaining: e.scene.remaining,
					ready: e.scene.ready
				} : null,
				question: t ? {
					index: e.answers.length + 1,
					total: q(e).Questions.length,
					mandatory: t.QuestionType === 0,
					text: J(e, t.Text)
				} : null,
				notes: e.notes,
				result: e.result
			},
			private: {}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.players,
			ranking: e.players,
			scores: Object.fromEntries(e.players.map((t) => [t, e.result?.total ?? 0]))
		} : { phase: e.phase };
	},
	nextTickIn(e, t) {
		return e.phase === "scene" && e.scene?.ready ? e.scene.deadline === null ? 0 : Math.max(0, Math.min(1e3, e.scene.deadline - t)) : null;
	}
}, ht = {
	p01: {
		role: "games.chroniclesofcrime.hacker",
		description: "games.chroniclesofcrime.hackerDescription"
	},
	p02: {
		role: "games.chroniclesofcrime.doctor",
		description: "games.chroniclesofcrime.doctorDescription"
	},
	p03: {
		role: "games.chroniclesofcrime.criminologist",
		description: "games.chroniclesofcrime.criminologistDescription"
	},
	p04: {
		role: "games.chroniclesofcrime.scientist",
		description: "games.chroniclesofcrime.scientistDescription"
	}
}, gt = {
	location: "games.chroniclesofcrime.location",
	character: "games.chroniclesofcrime.character",
	category: "games.chroniclesofcrime.category",
	expert: "games.chroniclesofcrime.expert",
	special: "games.chroniclesofcrime.special",
	action: "games.chroniclesofcrime.action"
}, _t = {
	i01: "🍽️",
	i02: "📄",
	i03: "👣",
	i04: "🚗",
	i05: "🫀",
	i06: "💧",
	i07: "🍾",
	i08: "💊",
	i09: "🧤",
	i10: "🖼️",
	i11: "💍",
	i12: "🔪",
	i13: "🪑",
	i14: "🔫",
	i15: "☎️",
	i16: "🪢",
	i17: "🔑",
	i18: "💻",
	i19: "📡",
	i20: "🍴",
	i21: "📷",
	i22: "🍳",
	i23: "⚽",
	i24: "📚",
	i25: "📎",
	i26: "🛏️",
	i27: "👕",
	i28: "🐈",
	i29: "🛠️",
	i30: "👜",
	i31: "🃏",
	i32: "🌿",
	i33: "🧴",
	i34: "🔥",
	i35: "🗑️",
	i36: "📦",
	i37: "🔣"
};
function vt({ card: e }) {
	let t = {
		location: "📍",
		character: "👤",
		category: "🔎",
		expert: "🧑‍🔬",
		special: "📦",
		action: "✋"
	}, n = e.atlas ? `${e.atlas}-cards` : "cards", r = e.atlas ? 8 : 16;
	return e.image >= 0 ? /* @__PURE__ */ v("span", {
		"aria-hidden": !0,
		className: "coc-portrait",
		style: {
			backgroundImage: `url(./games/chroniclesofcrime/${n}.webp)`,
			backgroundSize: `800% ${r * 100}%`,
			backgroundPosition: `${e.image % 8 / 7 * 100}% ${Math.floor(e.image / 8) / (r - 1) * 100}%`
		}
	}) : /* @__PURE__ */ v("span", {
		"aria-hidden": !0,
		className: "coc-portrait coc-symbol",
		children: _t[e.code] ?? t[e.kind]
	});
}
function yt({ children: e, clue: t, serial: n }) {
	let { ref: r } = u(t && n !== void 0 ? `coc-text:${n}:${t.id}` : null);
	return /* @__PURE__ */ v("span", {
		ref: r,
		className: "coc-inline-card",
		children: e
	});
}
function bt({ serial: e }) {
	let { ref: t, hidden: n } = u(`coc-page:${e}`);
	return /* @__PURE__ */ v("span", {
		ref: t,
		className: "coc-fx-guard",
		"aria-hidden": !0,
		style: { visibility: n ? "hidden" : void 0 }
	});
}
function xt({ card: e }) {
	let t = s((e) => e.locale);
	return /* @__PURE__ */ y("div", {
		className: "coc-card coc-flying-note",
		children: [
			/* @__PURE__ */ v(vt, { card: e }),
			e.label && /* @__PURE__ */ v("span", {
				className: "coc-card-label",
				children: e.label
			}),
			/* @__PURE__ */ v("span", {
				className: "coc-card-name",
				children: e.name[t]
			})
		]
	});
}
function $({ content: e, kind: t = "dialogue", clues: r = [], serial: i, caseId: a = "tutorial" }) {
	let o = s((e) => e.locale), l = c(), u = (e[o] || e.en).replaceAll("@", "\n\n").split(/(<[^>]+>)/g), d = /* @__PURE__ */ new Set(), f = u.map((e, t) => {
		let s = e.match(/^<(char|loc|itm|cat)\s*=\s*([^>]+)>$/);
		if (e === "<home>") {
			let e = be(a), n = r.find((t) => t.card.id === e?.id && !d.has(t.id));
			return n && d.add(n.id), /* @__PURE__ */ v(yt, {
				clue: n,
				serial: i,
				children: e?.name[o]
			}, t);
		}
		if (s) {
			let e = xe(s[1], s[2], a), n = r.find((t) => t.card.id === e?.id && !d.has(t.id));
			return n && d.add(n.id), /* @__PURE__ */ y(yt, {
				clue: n,
				serial: i,
				children: [
					e ? l(gt[e.kind]) : s[1],
					" ",
					s[2]
				]
			}, t);
		}
		return e.startsWith("<") ? null : /* @__PURE__ */ v(n, { children: e }, t);
	});
	return /* @__PURE__ */ y("div", {
		className: t === "tutorial" ? "coc-narrative coc-tutorial" : "coc-narrative",
		children: [
			i !== void 0 && /* @__PURE__ */ v(bt, { serial: i }),
			t === "tutorial" && /* @__PURE__ */ v("strong", {
				className: "coc-tutorial-label",
				children: l("games.chroniclesofcrime.tutorialHint")
			}),
			f,
			r.filter((e) => !d.has(e.id)).map((e) => /* @__PURE__ */ v("span", {
				className: "coc-acquired-reference",
				children: /* @__PURE__ */ v(yt, {
					clue: e,
					serial: i,
					children: e.card.name[o]
				})
			}, e.id))
		]
	});
}
//#endregion
//#region src/games/chroniclesofcrime/panorama.tsx
function St({ sceneId: e, onReady: t }) {
	let n = c(), i = a(null), s = a(t), [l, u] = o(0), [d, f] = o("loading");
	return r(() => {
		s.current = t;
	}, [t]), r(() => {
		let t = i.current;
		if (!t) return;
		let n = !1, r, a, o = () => {}, c = new Image(), l = () => {
			n || f("failed");
		};
		return c.onerror = l, c.onload = () => {
			if (!n) try {
				r = new ne({
					antialias: !0,
					alpha: !1
				}), r.setPixelRatio(Math.min(devicePixelRatio, 2));
				let e = Array.from({ length: 6 }, (e, t) => {
					let n = document.createElement("canvas");
					return n.width = n.height = c.height, n.getContext("2d").drawImage(c, t * c.height, 0, c.height, c.height, 0, 0, c.height, c.height), n;
				});
				a = new b([
					e[1],
					e[0],
					...e.slice(2)
				]), a.colorSpace = x, a.minFilter = ee, a.needsUpdate = !0;
				let n = new S();
				n.background = a;
				let i = new te(80, 1, .1, 10), u = 0, d = 0, p = null, m = () => {
					i.lookAt(Math.sin(u) * Math.cos(d), Math.sin(d), Math.cos(u) * Math.cos(d)), r.render(n, i);
				}, h = () => {
					r.setSize(t.clientWidth, t.clientHeight), i.aspect = t.clientWidth / Math.max(1, t.clientHeight), i.updateProjectionMatrix(), m();
				}, g = (e) => {
					p = {
						id: e.pointerId,
						x: e.clientX,
						y: e.clientY
					}, t.setPointerCapture(e.pointerId);
				}, _ = (e) => {
					p && p.id === e.pointerId && (u += (e.clientX - p.x) * .005, d = Math.max(-1.45, Math.min(1.45, d + (e.clientY - p.y) * .005)), p.x = e.clientX, p.y = e.clientY, m());
				}, v = () => {
					p = null;
				}, y = (e) => {
					[
						"ArrowLeft",
						"ArrowRight",
						"ArrowUp",
						"ArrowDown"
					].includes(e.key) && (e.preventDefault(), e.key === "ArrowLeft" && (u += .15), e.key === "ArrowRight" && (u -= .15), e.key === "ArrowUp" && (d = Math.min(1.45, d + .15)), e.key === "ArrowDown" && (d = Math.max(-1.45, d - .15)), m());
				};
				t.appendChild(r.domElement), t.addEventListener("pointerdown", g), t.addEventListener("pointermove", _), t.addEventListener("pointerup", v), t.addEventListener("pointercancel", v), t.addEventListener("keydown", y), r.domElement.addEventListener("webglcontextlost", l);
				let re = new ResizeObserver(h);
				re.observe(t), h(), o = () => {
					re.disconnect(), t.removeEventListener("pointerdown", g), t.removeEventListener("pointermove", _), t.removeEventListener("pointerup", v), t.removeEventListener("pointercancel", v), t.removeEventListener("keydown", y), r?.domElement.removeEventListener("webglcontextlost", l);
				}, f("ready"), s.current();
			} catch {
				l();
			}
		}, c.src = `./games/chroniclesofcrime/${e}.webp`, () => {
			n = !0, c.onload = null, c.onerror = null, o(), r?.domElement.remove(), r?.dispose(), a?.dispose();
		};
	}, [e, l]), /* @__PURE__ */ y("div", {
		className: "coc-panorama-wrap",
		children: [/* @__PURE__ */ v("div", {
			ref: i,
			tabIndex: 0,
			role: "region",
			"aria-label": n("games.chroniclesofcrime.sceneHint"),
			className: "coc-panorama"
		}), d !== "ready" && /* @__PURE__ */ y("div", {
			className: "coc-scene-status",
			role: "status",
			children: [/* @__PURE__ */ v("p", { children: n(d === "failed" ? "games.chroniclesofcrime.sceneFailed" : "games.chroniclesofcrime.sceneLoading") }), d === "failed" && /* @__PURE__ */ v("button", {
				className: "btn-base mt-3 min-h-11",
				onClick: () => {
					f("loading"), u((e) => e + 1);
				},
				children: n("games.chroniclesofcrime.retry")
			})]
		})]
	});
}
//#endregion
//#region src/games/chroniclesofcrime/case-history.ts
function Ct(e) {
	let t = [];
	for (let n of e) {
		if (n.kind === "tutorial") continue;
		let e = t.at(-1);
		n.record && e && JSON.stringify(e[0].record) === JSON.stringify(n.record) ? e.push(n) : t.push([n]);
	}
	return t;
}
function wt(e, t, n) {
	if (e.record?.personId === t || e.record?.subjectId === t || e.clues?.some((e) => e.card.id === t)) return !0;
	for (let r of [e.text.en, e.text.zh]) {
		for (let e of r.matchAll(/<(char|loc|itm|cat)\s*=\s*([^>]+)>/g)) if (xe(e[1], e[2], n)?.id === t) return !0;
		if (r.includes("<home>") && be(n)?.id === t) return !0;
	}
	return !1;
}
function Tt(e, t) {
	return Ct(e.history).filter((n) => n.some((n) => wt(n, t, e.caseId))).flat();
}
//#endregion
//#region src/games/chroniclesofcrime/view-player.tsx
var Et = [
	{
		kind: "character",
		label: "games.chroniclesofcrime.characters"
	},
	{
		kind: "location",
		label: "games.chroniclesofcrime.locations"
	},
	{
		kind: "category",
		label: "games.chroniclesofcrime.categories"
	},
	{
		kind: "expert",
		label: "games.chroniclesofcrime.experts"
	},
	{
		kind: "special",
		label: "games.chroniclesofcrime.specials"
	},
	{
		kind: "action",
		label: "games.chroniclesofcrime.actions"
	}
], Dt = {
	talk: "games.chroniclesofcrime.talkTo",
	ask: "games.chroniclesofcrime.askAbout",
	examine: "games.chroniclesofcrime.examine",
	contact: "games.chroniclesofcrime.contact",
	analyze: "games.chroniclesofcrime.analyze",
	travel: "games.chroniclesofcrime.travelTo",
	use: "games.chroniclesofcrime.useAction"
}, Ot = {
	next: "games.chroniclesofcrime.next",
	investigation: "games.chroniclesofcrime.resumeInvestigation",
	interview: "games.chroniclesofcrime.resumeInterview",
	scene: "games.chroniclesofcrime.startObservation",
	ending: "games.chroniclesofcrime.resumeEnding",
	interaction: "games.chroniclesofcrime.makeChoice"
};
function kt({ kind: e, label: t, active: n, unread: r, onClick: i }) {
	let a = c(), { ref: o } = u(`coc-tab:${e}`);
	return /* @__PURE__ */ y("button", {
		ref: o,
		id: `coc-tab-${e}`,
		role: "tab",
		"aria-controls": "coc-card-panel",
		"aria-selected": n,
		className: n ? "coc-tab coc-active" : "coc-tab",
		onClick: i,
		children: [a(t), r && /* @__PURE__ */ v("span", {
			className: "coc-tab-new",
			"aria-label": a("games.chroniclesofcrime.newClue")
		})]
	});
}
function At({ card: e, identity: t, selected: n, disabled: r, onClick: i }) {
	let a = c(), o = s((e) => e.locale), { ref: l, hidden: f } = u(`coc-card:${e.id}`), p = e.kind === "expert" ? ht[e.code] : void 0, m = e.categoryName?.[o];
	return /* @__PURE__ */ y("button", {
		ref: l,
		className: `coc-card${n ? " coc-selected" : ""}${p ? " coc-expert-card" : ""}${m ? " coc-found-item" : ""}`,
		style: { visibility: f ? "hidden" : void 0 },
		disabled: r,
		"aria-label": `${a(gt[e.kind])} ${e.label} ${e.name[o]}${p ? ` · ${a(p.role)}` : ""}${m ? `${m === e.name[o] ? "" : ` · ${m}`} · ${a("games.chroniclesofcrime.leadToInvestigate")}` : ""}`,
		"aria-pressed": n,
		onClick: i,
		children: [
			/* @__PURE__ */ v(vt, { card: e }),
			e.label && /* @__PURE__ */ v("span", {
				className: "coc-card-label",
				children: e.label
			}),
			p && /* @__PURE__ */ v("strong", {
				className: "coc-expert-role",
				children: a(p.role)
			}),
			/* @__PURE__ */ v("span", {
				className: "coc-card-name",
				children: e.kind === "category" ? /* @__PURE__ */ y("span", {
					className: "coc-item-copy",
					children: [/* @__PURE__ */ v("span", {
						className: "coc-card-category",
						children: m ?? e.name[o]
					}), m && m !== e.name[o] && /* @__PURE__ */ v("strong", {
						className: "coc-item-name",
						children: e.name[o]
					})]
				}) : /* @__PURE__ */ y("span", { children: [e.name[o], t && /* @__PURE__ */ v("span", {
					className: "coc-card-identity",
					title: t,
					children: t
				})] })
			}),
			m && /* @__PURE__ */ v("span", {
				className: "coc-item-lead",
				"aria-hidden": !0,
				children: "?"
			}),
			n && /* @__PURE__ */ v("span", {
				className: "coc-card-check",
				"aria-hidden": !0,
				children: /* @__PURE__ */ v(d, { size: 13 })
			})
		]
	});
}
function jt({ view: e, pages: t = e.history }) {
	let n = c(), r = s((e) => e.locale), i = [], a;
	for (let e of Ct(t)) {
		let t = e[0].record ? Math.floor(e[0].record.time / 1440) + 1 : void 0;
		i.push({
			pages: e,
			day: t === a ? void 0 : t
		}), t !== void 0 && (a = t);
	}
	return i.map(({ pages: t, day: i }) => {
		let a = t[0].record, o = a ? `${String(Math.floor(a.time / 60) % 24).padStart(2, "0")}:${String(a.time % 60).padStart(2, "0")}` : "", s = a?.subject?.[r], c = a?.kind === "event" ? n("games.chroniclesofcrime.caseEvent") : a?.person?.[r] ?? (s ? n("games.chroniclesofcrime.examination") : "");
		return /* @__PURE__ */ y("div", { children: [i !== void 0 && /* @__PURE__ */ v("h3", {
			className: "coc-history-day",
			children: n("games.chroniclesofcrime.day", { n: i })
		}), /* @__PURE__ */ y("article", {
			className: "coc-history-entry",
			children: [a && /* @__PURE__ */ y("div", {
				className: "coc-history-context",
				children: [
					/* @__PURE__ */ v("time", { children: o }),
					a.location && /* @__PURE__ */ y(_, { children: [" · ", a.location[r]] }),
					c && /* @__PURE__ */ y(_, { children: [" · ", c] }),
					s && /* @__PURE__ */ y(_, { children: [" → ", s] })
				]
			}), t.map((t) => /* @__PURE__ */ v($, {
				content: t.text,
				kind: t.kind,
				clues: t.clues,
				caseId: e.caseId
			}, t.serial))]
		})] }, t[0].serial);
	});
}
function Mt({ card: e, view: t, close: n, opener: i }) {
	let l = c(), u = s((e) => e.locale), d = a(null), [m, h] = o("history"), g = a(null), _ = Tt(t, e.id), b = t.profiles?.[e.id] ?? [];
	return r(() => {
		let e = d.current, t = i.current;
		return e?.showModal(), () => {
			e?.close(), t?.focus();
		};
	}, [i]), r(() => {
		g.current && (g.current.scrollTop = g.current.scrollHeight);
	}, [m]), /* @__PURE__ */ v("dialog", {
		ref: d,
		className: "coc-modal",
		"aria-label": l("games.chroniclesofcrime.relatedDossier"),
		onCancel: (e) => {
			e.preventDefault(), n();
		},
		onClick: (e) => {
			e.target === e.currentTarget && n();
		},
		children: /* @__PURE__ */ y("div", {
			className: "coc-file-body",
			children: [
				/* @__PURE__ */ y("div", {
					className: "coc-modal-heading",
					children: [/* @__PURE__ */ y("strong", { children: [/* @__PURE__ */ v(p, {
						size: 19,
						"aria-hidden": !0
					}), l("games.chroniclesofcrime.relatedDossier")] }), /* @__PURE__ */ v("button", {
						className: "coc-icon-button",
						"aria-label": l("games.chroniclesofcrime.close"),
						onClick: n,
						autoFocus: !0,
						children: /* @__PURE__ */ v(f, { size: 20 })
					})]
				}),
				/* @__PURE__ */ y("div", {
					className: "coc-profile-person",
					children: [/* @__PURE__ */ v(vt, { card: e }), /* @__PURE__ */ y("div", { children: [e.categoryName && e.categoryName[u] !== e.name[u] && /* @__PURE__ */ v("p", { children: e.categoryName[u] }), /* @__PURE__ */ v("h2", { children: e.name[u] })] })]
				}),
				e.kind === "character" && /* @__PURE__ */ y("div", {
					className: "coc-file-tabs",
					role: "tablist",
					"aria-label": l("games.chroniclesofcrime.relatedDossier"),
					children: [/* @__PURE__ */ v("button", {
						role: "tab",
						id: "coc-related-history-tab",
						"aria-controls": "coc-related-history-panel",
						"aria-selected": m === "history",
						onClick: () => h("history"),
						children: l("games.chroniclesofcrime.history")
					}), /* @__PURE__ */ v("button", {
						role: "tab",
						id: "coc-profile-tab",
						"aria-controls": "coc-profile-panel",
						"aria-selected": m === "profile",
						onClick: () => h("profile"),
						children: l("games.chroniclesofcrime.characterProfile")
					})]
				}),
				m === "history" ? /* @__PURE__ */ v("div", {
					ref: g,
					className: "coc-history",
					id: "coc-related-history-panel",
					role: e.kind === "character" ? "tabpanel" : void 0,
					"aria-labelledby": e.kind === "character" ? "coc-related-history-tab" : void 0,
					children: _.length ? /* @__PURE__ */ v(jt, {
						view: t,
						pages: _
					}) : /* @__PURE__ */ v("p", {
						className: "coc-empty-history",
						children: l("games.chroniclesofcrime.noRelatedHistory")
					})
				}) : /* @__PURE__ */ v("div", {
					className: "coc-profile-notes",
					id: "coc-profile-panel",
					role: "tabpanel",
					"aria-labelledby": "coc-profile-tab",
					children: b.length ? b.map((e, n) => /* @__PURE__ */ y("article", { children: [/* @__PURE__ */ v("h3", { children: e.summary[u] }), /* @__PURE__ */ y("details", { children: [/* @__PURE__ */ v("summary", { children: l("games.chroniclesofcrime.sourcePassage") }), /* @__PURE__ */ v($, {
						content: e.excerpt,
						caseId: t.caseId
					})] })] }, n)) : /* @__PURE__ */ v("p", { children: l("games.chroniclesofcrime.identityUnknown") })
				})
			]
		})
	});
}
function Nt({ finish: e }) {
	let t = c(), [n, i] = o(!1);
	return r(() => {
		let e = window.setTimeout(() => i(!0), 800);
		return () => window.clearTimeout(e);
	}, []), n ? /* @__PURE__ */ v("button", {
		className: "coc-primary",
		onClick: e,
		children: t("games.chroniclesofcrime.exitScene")
	}) : null;
}
function Pt({ view: e, save: t, close: n, opener: i }) {
	let s = c(), [l, u] = o(e.notes), [d, m] = o("history"), h = a(null), g = a(null);
	return r(() => {
		let e = h.current;
		e?.showModal();
		let t = i.current;
		return () => {
			e?.close(), t?.focus();
		};
	}, [i]), r(() => {
		let e = g.current;
		e && (e.scrollTop = e.scrollHeight);
	}, [d]), /* @__PURE__ */ v("dialog", {
		ref: h,
		className: "coc-modal",
		"aria-label": s("games.chroniclesofcrime.dossier"),
		onCancel: (e) => {
			e.preventDefault(), n();
		},
		onClick: (e) => {
			e.target === e.currentTarget && n();
		},
		children: /* @__PURE__ */ y("div", {
			className: "coc-file-body",
			children: [
				/* @__PURE__ */ y("div", {
					className: "coc-modal-heading",
					children: [/* @__PURE__ */ y("strong", { children: [/* @__PURE__ */ v(p, {
						size: 19,
						"aria-hidden": !0
					}), s("games.chroniclesofcrime.dossier")] }), /* @__PURE__ */ v("button", {
						className: "coc-icon-button",
						"aria-label": s("games.chroniclesofcrime.close"),
						onClick: n,
						autoFocus: !0,
						children: /* @__PURE__ */ v(f, { size: 20 })
					})]
				}),
				e.role && /* @__PURE__ */ y("div", {
					className: "coc-role-summary",
					children: [
						/* @__PURE__ */ v("strong", { children: e.role.name }),
						/* @__PURE__ */ v("span", { children: s("games.chroniclesofcrime.energy", {
							n: e.role.energy,
							max: e.role.maximumEnergy
						}) }),
						P.map((t, n) => /* @__PURE__ */ y("span", { children: [
							s(t),
							" +",
							e.role.skills[n]
						] }, t))
					]
				}),
				/* @__PURE__ */ y("div", {
					className: "coc-file-tabs",
					role: "tablist",
					"aria-label": s("games.chroniclesofcrime.dossier"),
					children: [/* @__PURE__ */ v("button", {
						role: "tab",
						id: "coc-history-tab",
						"aria-controls": "coc-history-panel",
						"aria-selected": d === "history",
						onClick: () => m("history"),
						children: s("games.chroniclesofcrime.history")
					}), /* @__PURE__ */ v("button", {
						role: "tab",
						id: "coc-notes-tab",
						"aria-controls": "coc-notes-panel",
						"aria-selected": d === "notes",
						onClick: () => m("notes"),
						children: s("games.chroniclesofcrime.notes")
					})]
				}),
				d === "history" ? /* @__PURE__ */ v("div", {
					ref: g,
					className: "coc-history",
					id: "coc-history-panel",
					role: "tabpanel",
					"aria-labelledby": "coc-history-tab",
					children: /* @__PURE__ */ v(jt, { view: e })
				}) : /* @__PURE__ */ y("div", {
					className: "coc-notes-panel",
					id: "coc-notes-panel",
					role: "tabpanel",
					"aria-labelledby": "coc-notes-tab",
					children: [/* @__PURE__ */ v("textarea", {
						className: "coc-notes",
						maxLength: 4e3,
						"aria-label": s("games.chroniclesofcrime.notes"),
						placeholder: s("games.chroniclesofcrime.notesPlaceholder"),
						value: l,
						onChange: (e) => u(e.target.value)
					}), /* @__PURE__ */ v("button", {
						className: "coc-primary",
						onClick: () => t(l),
						children: s("games.chroniclesofcrime.saveNotes")
					})]
				})
			]
		})
	});
}
function Ft({ view: e, send: t }) {
	let n = c(), i = s((e) => e.locale), o = a(null);
	r(() => {
		let e = o.current;
		return e?.showModal(), () => e?.close();
	}, []);
	let l = e.interaction, u = l.kind === "test";
	return /* @__PURE__ */ v("dialog", {
		ref: o,
		className: "coc-modal coc-interaction",
		"aria-labelledby": "coc-interaction-title",
		onCancel: (e) => {
			e.preventDefault(), l.cancelable && t({
				type: "choice",
				answer: "cancel"
			});
		},
		children: /* @__PURE__ */ y("div", {
			className: "coc-interaction-body",
			children: [
				/* @__PURE__ */ v("h2", {
					id: "coc-interaction-title",
					children: l.title[i] || n(u ? "games.chroniclesofcrime.skillTest" : "games.chroniclesofcrime.makeChoice")
				}),
				/* @__PURE__ */ v($, {
					content: l.prompt,
					caseId: e.caseId
				}),
				u && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ y("p", { children: [
						n(P[l.skill]),
						" · ",
						n(_e[l.difficulty])
					] }),
					/* @__PURE__ */ y("p", { children: [
						e.role?.name,
						" · ",
						n("games.chroniclesofcrime.energy", {
							n: e.role?.energy ?? 0,
							max: e.role?.maximumEnergy ?? 0
						})
					] }),
					e.role?.fatigued && /* @__PURE__ */ v("p", { children: n("games.chroniclesofcrime.fatigued") }),
					/* @__PURE__ */ v("div", {
						className: "coc-dice",
						role: "status",
						"aria-live": "polite",
						children: l.rolls.map((e, t) => /* @__PURE__ */ v("span", {
							"aria-label": n("games.chroniclesofcrime.dieResult", { n: e }),
							children: [
								"⚀",
								"⚁",
								"⚂",
								"⚃",
								"⚄",
								"⚅"
							][e - 1]
						}, t))
					}),
					/* @__PURE__ */ v("p", { children: n("games.chroniclesofcrime.testFormula", {
						ability: e.role?.skills[l.skill] ?? 0,
						modifier: l.modifier
					}) }),
					/* @__PURE__ */ v("strong", { children: n("games.chroniclesofcrime.successes", { n: l.successes }) }),
					/* @__PURE__ */ y("div", {
						className: "coc-interaction-actions",
						children: [l.canRoll && /* @__PURE__ */ v("button", {
							className: "coc-primary",
							onClick: () => t({ type: "roll" }),
							children: n(l.rolls.length ? "games.chroniclesofcrime.spendEnergy" : "games.chroniclesofcrime.roll")
						}), l.rolls.length > 0 && /* @__PURE__ */ v("button", {
							className: l.successes ? "coc-primary" : "coc-quiet",
							onClick: () => t({ type: "resolve_test" }),
							children: n(l.successes ? "games.chroniclesofcrime.continueTest" : "games.chroniclesofcrime.acceptFailure")
						})]
					})
				] }),
				!u && /* @__PURE__ */ y("div", {
					className: "coc-interaction-actions",
					children: [
						/* @__PURE__ */ v("button", {
							className: "coc-primary",
							onClick: () => t({
								type: "choice",
								answer: "yes"
							}),
							children: n(l.successLabels ? "games.chroniclesofcrime.success" : "games.chroniclesofcrime.yes")
						}),
						/* @__PURE__ */ v("button", {
							className: "coc-quiet",
							onClick: () => t({
								type: "choice",
								answer: "no"
							}),
							children: n(l.successLabels ? "games.chroniclesofcrime.failure" : "games.chroniclesofcrime.no")
						}),
						l.cancelable && /* @__PURE__ */ v("button", {
							className: "coc-quiet",
							onClick: () => t({
								type: "choice",
								answer: "cancel"
							}),
							children: n("games.chroniclesofcrime.cancel")
						})
					]
				})
			]
		})
	});
}
function It({ public: e, send: t }) {
	let n = e, r = c(), i = s((e) => e.locale), [f, b] = o("character"), ee = j(n.caseId), te = Et.filter((e) => e.kind === "expert" ? ee === "base" : e.kind !== "action" || ee !== "base");
	te.some((e) => e.kind === f) || b("character");
	let x = n.history.at(-1)?.serial ?? 0, [S, ne] = o(() => Object.fromEntries(Et.map((e) => [e.kind, x])));
	S[f] < x && ne({
		...S,
		[f]: x
	});
	let [re, C] = o(!1), [ie, ae] = o(null), w = a(null), oe = a(null), se = a(null), { ref: ce } = u("coc-clock"), { ref: le } = u("coc-paper"), [T, ue] = o(null);
	l();
	let E = !!n.current && !!n.readingAction, de = n.readingAction === "next", fe = n.cards.find((e) => e.id === ie), D = n.question, pe = [
		n.caseId,
		n.phase,
		n.location?.id,
		n.context?.id,
		n.gameTime,
		n.current?.serial,
		n.history.at(-1)?.serial,
		D?.index
	].join(":");
	T && T.scope !== pe && ue(null);
	let O = T?.scope === pe ? n.cards.find((e) => e.id === T.cardId) : null, k = O && n.cardActions[O.id], A = n.current?.text ?? D?.text ?? n.history.at(-1)?.text, me = n.current ?? (D ? void 0 : n.history.at(-1)), he = Math.floor(n.gameTime / 60) % 24, ge = n.gameTime % 60, M = (e) => {
		ue(O?.id === e.id ? null : {
			scope: pe,
			cardId: e.id
		});
	}, N = (e) => {
		ue(null), t(e);
	}, P = n.context?.kind === "expert", _e = P && n.context ? ht[n.context.code] : void 0, F = O?.kind === "expert" ? ht[O.code] : void 0, I = n.phase === "scene" ? n.location : n.context ?? n.location, ve = I?.kind === "location" ? I.label ? `${r("games.chroniclesofcrime.location")} ${I.label}` : "" : n.location?.name[i], ye = n.phase === "scene" ? "games.chroniclesofcrime.scene" : n.phase === "ending" ? "games.chroniclesofcrime.ending" : P ? "games.chroniclesofcrime.consultation" : n.context?.id === n.location?.id ? "games.chroniclesofcrime.investigation" : "games.chroniclesofcrime.interview", L = /* @__PURE__ */ y("header", {
		className: "coc-subject",
		children: [
			I && /* @__PURE__ */ v("span", {
				className: "coc-subject-portrait",
				children: /* @__PURE__ */ v(vt, { card: I })
			}),
			/* @__PURE__ */ y("div", {
				className: "coc-subject-name",
				children: [/* @__PURE__ */ v("h1", {
					title: I?.name[i],
					children: I?.name[i]
				}), (ve || P) && /* @__PURE__ */ y("p", { children: [/* @__PURE__ */ v("span", {
					className: "coc-subject-place",
					children: _e ? r(_e.role) : ve
				}), P && /* @__PURE__ */ y("span", {
					className: "coc-remote",
					children: [" · ", r("games.chroniclesofcrime.remoteContact")]
				})] })]
			}),
			D ? !n.forcedEnding && /* @__PURE__ */ v("button", {
				className: "coc-context-action",
				disabled: E,
				onClick: () => N({ type: "abort_ending" }),
				children: r("games.chroniclesofcrime.abortEnding")
			}) : n.phase !== "scene" && n.canLeave ? /* @__PURE__ */ v("button", {
				className: "coc-context-action",
				disabled: E,
				onClick: () => N({ type: "leave" }),
				children: r(P ? "games.chroniclesofcrime.endContact" : "games.chroniclesofcrime.leave")
			}) : n.canSolve && /* @__PURE__ */ v("button", {
				className: "coc-context-action",
				disabled: E,
				onClick: () => N({ type: "solve" }),
				children: r("games.chroniclesofcrime.solve")
			})
		]
	}), R = n.cards.filter((e) => e.kind === f), be = n.canInvestigate ? "games.chroniclesofcrime.investigate" : P ? "games.chroniclesofcrime.chooseAnalysisSubject" : n.canLeave ? "games.chroniclesofcrime.chooseTopic" : "games.chroniclesofcrime.chooseTarget";
	return /* @__PURE__ */ y("div", {
		className: "coc-root coc-main",
		lang: i === "zh" ? "zh-CN" : "en",
		children: [
			/* @__PURE__ */ v(g, {
				adaptive: !0,
				className: "coc-screen",
				scroll: !1,
				actionsHeight: "coc-action-slot",
				overlay: /* @__PURE__ */ y(_, { children: [F && /* @__PURE__ */ v("div", {
					className: "coc-expert-preview",
					role: "status",
					children: r(F.description)
				}), O && [
					"character",
					"category",
					"special"
				].includes(O.kind) && /* @__PURE__ */ v("div", {
					className: "coc-profile-preview",
					children: /* @__PURE__ */ v("button", {
						ref: se,
						className: "coc-quiet",
						"aria-haspopup": "dialog",
						onClick: () => ae(O.id),
						children: r("games.chroniclesofcrime.relatedDossier")
					})
				})] }),
				banner: /* @__PURE__ */ y("div", {
					className: "coc-banner",
					children: [
						/* @__PURE__ */ y("span", {
							className: "coc-phase",
							children: [
								r(ye),
								n.money != null && /* @__PURE__ */ v("small", {
									className: "coc-resource",
									children: r("games.chroniclesofcrime.money", { n: n.money })
								}),
								n.role && /* @__PURE__ */ y("small", {
									className: "coc-resource",
									children: [
										n.role.name,
										" · ⚡",
										n.role.energy,
										"/",
										n.role.maximumEnergy
									]
								})
							]
						}),
						/* @__PURE__ */ y("div", {
							ref: ce,
							className: "coc-clock",
							children: [/* @__PURE__ */ v("small", { children: r("games.chroniclesofcrime.day", { n: Math.floor(n.gameTime / 1440) + 1 }) }), /* @__PURE__ */ y("time", { children: [
								String(he).padStart(2, "0"),
								":",
								String(ge).padStart(2, "0")
							] })]
						}),
						/* @__PURE__ */ y("button", {
							ref: oe,
							className: "coc-file-button",
							"aria-haspopup": "dialog",
							onClick: () => C(!0),
							children: [/* @__PURE__ */ v(p, {
								size: 18,
								"aria-hidden": !0
							}), r("games.chroniclesofcrime.dossier")]
						})
					]
				}),
				actions: /* @__PURE__ */ y("div", {
					className: "coc-actions",
					children: [!E && n.specialAction && !n.interaction && n.phase === "investigation" && /* @__PURE__ */ v("button", {
						className: "coc-quiet coc-special-button",
						onClick: () => N({ type: "special" }),
						children: n.specialAction[i]
					}), E ? n.readingAction !== "next" && /* @__PURE__ */ v("button", {
						className: "coc-primary coc-enter-action",
						onClick: () => N({ type: "next" }),
						children: r(n.readingAction === "interaction" && n.interaction?.kind === "test" ? "games.chroniclesofcrime.skillTest" : Ot[n.readingAction])
					}) : n.phase === "scene" ? /* @__PURE__ */ v(Nt, { finish: () => N({ type: "exit_scene" }) }) : D ? /* @__PURE__ */ y("button", {
						className: "coc-primary",
						disabled: E || !O,
						onClick: () => O && N({
							type: "answer",
							cardId: O.id
						}),
						children: [/* @__PURE__ */ v(d, {
							size: 19,
							"aria-hidden": !0
						}), /* @__PURE__ */ v("span", { children: O ? r("games.chroniclesofcrime.submitSelectedAnswer", { name: O.name[i] }) : r("games.chroniclesofcrime.submitAnswer") })]
					}) : O && k ? /* @__PURE__ */ y("button", {
						className: "coc-primary",
						disabled: E,
						onClick: () => N({
							type: "scan",
							code: O.id
						}),
						children: [/* @__PURE__ */ v(m, {
							size: 19,
							"aria-hidden": !0
						}), /* @__PURE__ */ v("span", { children: r(Dt[k], {
							name: O.name[i],
							expert: n.context?.name[i] ?? ""
						}) })]
					}) : /* @__PURE__ */ y("button", {
						className: "coc-primary",
						disabled: E || !n.canInvestigate,
						onClick: () => N({ type: "investigate" }),
						children: [/* @__PURE__ */ v(h, {
							size: 19,
							"aria-hidden": !0
						}), /* @__PURE__ */ v("span", { children: r(be) })]
					})]
				}),
				children: /* @__PURE__ */ v("div", {
					className: `coc-workspace${de ? " coc-page-turning" : ""}`,
					onPointerDownCapture: (e) => {
						w.current = {
							x: e.clientX,
							y: e.clientY,
							time: performance.now(),
							moved: !1
						};
					},
					onPointerMoveCapture: (e) => {
						let t = w.current;
						t && Math.hypot(e.clientX - t.x, e.clientY - t.y) > 9 && (t.moved = !0);
					},
					onPointerCancelCapture: () => {
						w.current = null;
					},
					onScrollCapture: () => {
						w.current && (w.current.moved = !0);
					},
					onClick: (e) => {
						let t = e.target, n = w.current;
						!de || !n || n.moved || performance.now() - n.time > 450 || window.getSelection()?.toString() || !t.closest("button, a, header, .coc-tabs") && t.closest(".coc-story-content, .coc-cards") && N({ type: "next" });
					},
					children: n.phase === "scene" && n.scene && !E ? /* @__PURE__ */ y("div", {
						className: "coc-scene",
						children: [
							/* @__PURE__ */ v(St, {
								sceneId: n.scene.id,
								onReady: () => {
									n.scene?.ready || t({ type: "scene_ready" });
								}
							}),
							/* @__PURE__ */ v("div", {
								className: "coc-scene-subject",
								children: L
							}),
							/* @__PURE__ */ v("div", {
								className: "coc-countdown",
								role: "timer",
								children: r("games.chroniclesofcrime.seconds", { n: Math.ceil(n.scene.remaining / 1e3) })
							}),
							/* @__PURE__ */ v("p", {
								className: "coc-scene-hint",
								children: r("games.chroniclesofcrime.sceneHint")
							})
						]
					}) : /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ y("section", {
						className: "coc-story",
						children: [
							L,
							/* @__PURE__ */ y("div", {
								ref: le,
								className: "coc-story-content",
								"aria-live": "polite",
								children: [D && /* @__PURE__ */ y("div", {
									className: "coc-question-heading",
									children: [/* @__PURE__ */ y("span", { children: [
										r("games.chroniclesofcrime.question", {
											n: D.index,
											total: D.total
										}),
										" · ",
										r(D.mandatory ? "games.chroniclesofcrime.mandatory" : "games.chroniclesofcrime.optional")
									] }), !D.mandatory && /* @__PURE__ */ v("button", {
										className: "coc-quiet",
										disabled: E,
										onClick: () => N({
											type: "answer",
											cardId: ""
										}),
										children: r("games.chroniclesofcrime.skipAnswer")
									})]
								}), A && (D && n.caseId === "tutorial" && D.index === 1 ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v($, {
									kind: "tutorial",
									content: {
										en: A.en.split("\n\n")[0],
										zh: A.zh.split("\n\n")[0]
									}
								}), /* @__PURE__ */ v($, { content: {
									en: A.en.split("\n\n").slice(1).join("\n\n"),
									zh: A.zh.split("\n\n").slice(1).join("\n\n")
								} })] }) : /* @__PURE__ */ v($, {
									content: A,
									kind: me?.kind,
									clues: me?.clues,
									serial: n.current?.serial,
									caseId: n.caseId
								}))]
							}, n.current?.serial ?? `question-${D?.index ?? "history"}`),
							/* @__PURE__ */ v("div", {
								className: "coc-page-cue",
								children: de && /* @__PURE__ */ v("button", {
									className: "coc-next-page",
									"aria-label": r("games.chroniclesofcrime.next"),
									onClick: (e) => {
										let t = w.current;
										(e.detail === 0 || !t || !t.moved && performance.now() - t.time < 450) && N({ type: "next" });
									},
									children: /* @__PURE__ */ v("span", {
										"aria-hidden": !0,
										children: "▼"
									})
								})
							})
						]
					}), /* @__PURE__ */ y("section", {
						className: "coc-bank",
						children: [/* @__PURE__ */ v("div", {
							className: "coc-tabs",
							role: "tablist",
							"aria-label": r("games.chroniclesofcrime.chooseCard"),
							children: te.map((e) => /* @__PURE__ */ v(kt, {
								...e,
								active: f === e.kind,
								unread: f !== e.kind && n.history.some((t) => t.serial > S[e.kind] && t.clues?.some((t) => t.card.kind === e.kind)),
								onClick: () => {
									b(e.kind), ne({
										...S,
										[e.kind]: x
									});
								}
							}, e.kind))
						}), /* @__PURE__ */ y("div", {
							className: f === "category" ? "coc-cards coc-categories" : "coc-cards",
							id: "coc-card-panel",
							role: "tabpanel",
							"aria-labelledby": `coc-tab-${f}`,
							children: [R.map((e) => /* @__PURE__ */ v(At, {
								card: e,
								identity: n.profiles?.[e.id]?.at(-1)?.summary[i],
								selected: O?.id === e.id,
								disabled: E || e.kind === "action" && !n.cardActions[e.id],
								onClick: () => M(e)
							}, e.id)), !R.length && /* @__PURE__ */ v("p", {
								className: "coc-empty",
								children: r("games.chroniclesofcrime.emptyCards")
							})]
						}, f)]
					})] })
				})
			}),
			re && /* @__PURE__ */ v(Pt, {
				view: n,
				opener: oe,
				close: () => C(!1),
				save: (e) => {
					t({
						type: "notes",
						text: e
					}), C(!1);
				}
			}),
			fe && /* @__PURE__ */ v(Mt, {
				card: fe,
				view: n,
				opener: se,
				close: () => ae(null)
			}),
			!E && n.interaction && /* @__PURE__ */ v(Ft, {
				view: n,
				send: N
			})
		]
	});
}
//#endregion
//#region src/games/chroniclesofcrime/bot.ts
var Lt = () => null, Rt = 1150;
function zt({ clue: e, from: t, to: n, paper: r, delay: o }) {
	let s = a(null), c = Math.max(1, Math.min(r.w / 440, r.h / 540, 1.7)), l = 112 * c, u = 128 * c, d = Math.max(r.x + 6, Math.min(t.x + t.w / 2 - l / 2, r.x + r.w - l - 6)), f = Math.max(r.y + 6, Math.min(t.y - 34, r.y + r.h - u - 6));
	return i(() => {
		let e = s.current;
		if (!e) return;
		let t = n.x + n.w / 2 - (d + l / 2), r = n.y + n.h / 2 - (f + u / 2), i = e.animate([
			{
				opacity: 0,
				transform: "translateY(14px) scale(.35) rotate(-5deg)"
			},
			{
				opacity: 1,
				transform: "translateY(0) scale(1) rotate(-2deg)",
				offset: .18
			},
			{
				opacity: 1,
				transform: "translateY(0) scale(1) rotate(-2deg)",
				offset: .62
			},
			{
				opacity: .9,
				transform: `translate(${t * .55}px, ${r * .55 - 14}px) scale(.65) rotate(3deg)`,
				offset: .83
			},
			{
				opacity: 0,
				transform: `translate(${t}px, ${r}px) scale(.15) rotate(0deg)`
			}
		], {
			duration: Rt,
			delay: o,
			fill: "both",
			easing: "ease-in-out"
		});
		return () => i.cancel();
	}, [
		t,
		n,
		d,
		f,
		l,
		u,
		o
	]), /* @__PURE__ */ v("div", {
		ref: s,
		className: "coc-root coc-fx-root",
		style: {
			left: d,
			top: f,
			width: l,
			height: u
		},
		children: /* @__PURE__ */ v("div", {
			style: {
				transform: `scale(${c})`,
				transformOrigin: "top left"
			},
			children: /* @__PURE__ */ v(xt, { card: e.card })
		})
	});
}
function Bt({ at: e, delay: t }) {
	let n = a(null);
	return i(() => {
		let e = n.current?.animate([
			{ opacity: 0 },
			{
				opacity: 1,
				offset: .3
			},
			{ opacity: 0 }
		], {
			duration: 350,
			delay: t,
			fill: "both"
		});
		return () => e?.cancel();
	}, [t]), /* @__PURE__ */ v("div", {
		ref: n,
		className: "coc-root coc-fx-arrival",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		}
	});
}
function Vt({ minutes: e }) {
	let t = c();
	return /* @__PURE__ */ v("span", {
		className: "coc-root coc-fx-time",
		children: t("games.chroniclesofcrime.timeSpent", { n: e })
	});
}
var Ht = {
	readingAdvance() {
		return {
			ms: 1,
			node: null
		};
	},
	discoverClues(e, t) {
		let n = e.data;
		if (!n?.clues?.length || t.queued) return null;
		let r = t.anchor("coc-paper"), i = `coc-page:${n.serial}`;
		if (!r || !t.anchor(i)) return null;
		let a = n.clues.flatMap((e, i) => {
			let a = t.anchor(`coc-text:${n.serial}:${e.id}`), o = t.anchor(`coc-tab:${e.card.kind}`);
			if (!a || !o || a.y > r.y + r.h || a.y + a.h < r.y) return [];
			let s = Math.min(i * 70, 280);
			return [/* @__PURE__ */ v(zt, {
				clue: e,
				from: a,
				to: o,
				paper: r,
				delay: s
			}, e.id), /* @__PURE__ */ v(Bt, {
				at: o,
				delay: s + Rt - 100
			}, `arrival:${e.id}`)];
		});
		return a.length ? {
			ms: 1700,
			node: a,
			hide: [i, ...n.clues.filter((e) => e.id === e.card.id && t.anchor(`coc-card:${e.card.id}`)).map((e) => `coc-card:${e.card.id}`)]
		} : null;
	},
	timeSpent(e, t) {
		let n = e.data?.minutes, r = t.anchor("coc-clock");
		return !r || !n ? null : {
			ms: 1150,
			node: /* @__PURE__ */ v(re, {
				at: {
					...r,
					y: r.y + r.h + 25
				},
				ms: 1150,
				children: /* @__PURE__ */ v(Vt, { minutes: n })
			})
		};
	}
};
//#endregion
//#region src/games/chroniclesofcrime/game-over.tsx
function Ut({ public: e, onPlayAgain: t, onPlayAgainWithConfig: n, onBackToLobby: r }) {
	let i = e, a = i.result, l = c(), u = s((e) => e.locale), [d, f] = o(!1), p = me[i.caseId];
	return a ? /* @__PURE__ */ v("div", {
		className: "coc-root coc-end",
		lang: u === "zh" ? "zh-CN" : "en",
		children: /* @__PURE__ */ v(g, {
			adaptive: !0,
			className: "coc-screen",
			scroll: !1,
			banner: /* @__PURE__ */ y("div", {
				className: "coc-banner coc-report-banner",
				children: [/* @__PURE__ */ v("strong", { children: l("games.chroniclesofcrime.done") }), /* @__PURE__ */ v("span", { children: l(A[i.caseId]) })]
			}),
			actionsHeight: "coc-report-action-slot",
			actions: /* @__PURE__ */ y("div", {
				className: "coc-actions coc-report-actions",
				children: [p && n && /* @__PURE__ */ v("button", {
					className: "coc-primary",
					onClick: () => n({
						caseId: p,
						campaign: a.campaign ?? {},
						...i.role ? { roleId: i.role.id } : {}
					}),
					children: l("games.chroniclesofcrime.nextCase", { name: l(A[p]) })
				}), /* @__PURE__ */ y("div", {
					className: "coc-secondary-actions",
					children: [t && /* @__PURE__ */ v("button", {
						className: "coc-quiet",
						onClick: t,
						children: l("games.chroniclesofcrime.playAgain")
					}), r && /* @__PURE__ */ v("button", {
						className: "coc-quiet",
						onClick: r,
						children: l("games.chroniclesofcrime.backToLobby")
					})]
				})]
			}),
			children: /* @__PURE__ */ y("section", {
				className: "coc-report",
				children: [/* @__PURE__ */ y("div", {
					className: "coc-report-summary",
					children: [
						/* @__PURE__ */ y("div", {
							className: "coc-total",
							children: [
								/* @__PURE__ */ v("span", { children: l("games.chroniclesofcrime.score") }),
								/* @__PURE__ */ v("strong", {
									className: "font-mono tabular-nums",
									children: a.total
								}),
								/* @__PURE__ */ y("span", { children: ["★".repeat(a.stars), "☆".repeat(5 - a.stars)] }),
								/* @__PURE__ */ v("small", { children: l("games.chroniclesofcrime.maximum", { n: a.maximum }) })
							]
						}),
						/* @__PURE__ */ v("p", {
							className: "coc-report-elapsed",
							children: l("games.chroniclesofcrime.elapsed", {
								hours: Math.floor(i.elapsed / 60),
								minutes: i.elapsed % 60
							})
						}),
						/* @__PURE__ */ y("div", {
							className: "coc-breakdown",
							children: [
								/* @__PURE__ */ v("span", { children: l("games.chroniclesofcrime.answerScore") }),
								/* @__PURE__ */ v("b", { children: a.answers.reduce((e, t) => e + t.score, 0) }),
								/* @__PURE__ */ v("span", { children: l("games.chroniclesofcrime.stateScore") }),
								/* @__PURE__ */ v("b", { children: a.stateScore }),
								/* @__PURE__ */ v("span", { children: l("games.chroniclesofcrime.timeScore") }),
								/* @__PURE__ */ v("b", { children: a.timeScore }),
								/* @__PURE__ */ v("span", { children: l("games.chroniclesofcrime.penalty") }),
								/* @__PURE__ */ v("b", { children: -a.penalty })
							]
						})
					]
				}), /* @__PURE__ */ y("div", {
					className: "coc-report-detail",
					children: [
						a.answers.map((e, t) => /* @__PURE__ */ y("article", {
							className: "coc-answer",
							children: [/* @__PURE__ */ v($, {
								content: e.question,
								caseId: i.caseId
							}), /* @__PURE__ */ y("div", {
								className: "flex justify-between gap-3 pt-2",
								children: [/* @__PURE__ */ v("strong", { children: e.answer?.name[u] ?? l("games.chroniclesofcrime.noAnswer") }), /* @__PURE__ */ v("b", { children: e.score })]
							})]
						}, t)),
						/* @__PURE__ */ v("h3", {
							className: "font-bold",
							children: l("games.chroniclesofcrime.outro")
						}),
						/* @__PURE__ */ v($, {
							content: a.outro,
							caseId: i.caseId
						}),
						/* @__PURE__ */ v("button", {
							className: "coc-quiet my-3",
							onClick: () => f((e) => !e),
							children: l(d ? "games.chroniclesofcrime.hideSolution" : "games.chroniclesofcrime.showSolution")
						}),
						d && /* @__PURE__ */ v($, {
							content: a.solution,
							caseId: i.caseId
						})
					]
				})]
			})
		})
	}) : null;
}
//#endregion
//#region src/games/chroniclesofcrime/options.tsx
function Wt({ value: e, onChange: t }) {
	let n = c(), r = Oe.safeParse(e), i = r.success ? r.data : Oe.parse(void 0), a = j(i.caseId);
	return /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ v(ie, {
			title: n("games.chroniclesofcrime.seriesOption"),
			children: he.map((e) => /* @__PURE__ */ v(C, {
				name: "chronicles-series",
				value: e,
				checked: a === e,
				label: n(ge[e]),
				accent: Se.accent,
				onChange: () => t({
					caseId: k.find((t) => j(t) === e),
					roleId: i.roleId
				})
			}, e))
		}),
		/* @__PURE__ */ v(ie, {
			title: n("games.chroniclesofcrime.caseOption"),
			children: k.filter((e) => j(e) === a).map((e) => /* @__PURE__ */ v(C, {
				name: "chronicles-case",
				value: e,
				checked: i.caseId === e,
				label: n(A[e]),
				accent: Se.accent,
				onChange: () => t({
					caseId: e,
					roleId: i.roleId
				})
			}, e))
		}),
		a === "redview" && /* @__PURE__ */ v(ie, {
			title: n("games.chroniclesofcrime.roleOption"),
			children: M.map((e) => /* @__PURE__ */ v(C, {
				name: "chronicles-role",
				value: e.id,
				checked: i.roleId === e.id,
				label: n("games.chroniclesofcrime.roleDescription", {
					name: e.name,
					fitness: e.skills[0],
					mind: e.skills[1],
					speech: e.skills[2],
					energy: e.energy
				}),
				accent: Se.accent,
				onChange: () => t({
					...i,
					roleId: e.id
				})
			}, e.id))
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/chroniclesofcrime/entry.tsx
var Gt = {
	definition: mt,
	View: It,
	bot: Lt,
	fx: Ht,
	OverView: Ut,
	Options: Wt,
	locales: {
		zh: {
			name: "推理事件簿",
			desc: "独自调查伦敦、黑幕与红景镇案件，询问人物、观察现场并揭开真相。",
			rules: "目标：\n· 调查案件，收集线索并回答结案问题。\n准备：\n· 选择伦敦基础版、黑幕或红景镇系列，再选择案件。\n· 每局由一人操作；红景镇开局另选一名少年角色。\n· 从结案页继续下一章，会保留相应结果和角色。\n· 直接选章使用默认开局；案件中的编号对应下方卡片。\n调查：\n· 点选卡片，再点击底部行动按钮执行；选择不消耗时间。\n· 地点用于前往，人物用于交谈，物品和证据类别用于检查。\n· 询问时选择其他人物或物品，向当前人物提问。\n· 基础版可联系专家，再选择分析对象并执行行动。\n· 再点选中卡可取消选择；结束询问后可与其他人物交谈。\n· 通常移动消耗20分钟，询问和检查消耗5分钟。\n· 个别案件或行动的耗时不同，以案件内时间变化为准。\n· 允许搜证的地点才可现场搜证，每次消耗5分钟。\n· 观察持续40秒；结束后选择看到的证据类别并检查。\n· 人物、地点和特殊物品随正文揭示加入卡区。\n· 线索和人物会随调查进展与游戏内时间改变。\n· 轻点正文或卡区翻页；右下角三角表示还有下一段。\n· 普通末页可直接选卡行动；观察、选择和结案另行确认。\n· 选中人物或物品，可查看关联案卷与已知人物资料。\n· 案卷可查看带时间与对象的记录、编辑笔记。\n· 对局进度由本机自动保存。\n黑幕：\n· 使用跟踪、恫吓、擅闯和贿赂行动卡调查。\n· 行动针对当前地点或正在询问的人物。\n· 贿赂需要至少20美元；实际收支随剧情自动结算。\n红景镇：\n· 使用体能、头脑、沟通行动卡；提示卡用于索取线索。\n· 可进行的检定和提示随当前地点、人物及剧情改变。\n· 检定掷一枚六面骰，加上角色对应能力与难度修正。\n· 简单增加1点，普通不变，困难减少1点。\n· 合计5至6获得1个成功，7或以上获得2个成功。\n· 当前单角色模式累计至少1个成功便通过检定。\n· 未通过时可消耗1点体力追加掷骰，成功数累加。\n· 也可接受失败并继续剧情；通过后无需追加掷骰。\n· 少数剧情直接询问行动结果，按提示选择成功或失败。\n· 回总部睡觉可恢复体力；特殊剧情可能限制恢复或能力。\n结算：\n· 按剧情指引提交结案报告；部分剧情自动进入结案。\n· 逐题选择卡片并提交；选答题可以跳过。\n· 必答题答错会扣分并返回调查。\n· 得分包含答案、调查结果、耗时和累计奖惩。",
			caseOption: "案件",
			tutorial: "教程",
			chapter1: "第一章：直面谜团",
			chapter2: "第二章：邪恶根源",
			chapter3: "第三章：权力核心",
			pharaohs: "法老的诅咒",
			roses: "玫瑰皆有刺",
			investigation: "地点调查",
			interview: "人物询问",
			consultation: "专家咨询",
			ending: "结案报告",
			scene: "现场搜证",
			done: "调查结束",
			characters: "人物",
			locations: "地点",
			categories: "证据类别",
			experts: "专家",
			specials: "特殊物品",
			character: "人物",
			location: "地点",
			category: "证据",
			expert: "专家",
			special: "物品",
			next: "阅读下一段",
			resumeInvestigation: "返回调查",
			resumeInterview: "返回询问",
			startObservation: "开始观察（40秒）",
			leave: "结束询问",
			investigate: "现场搜证",
			solve: "提交结案报告",
			talkTo: "找「{{name}}」交谈",
			askAbout: "询问关于「{{name}}」的事情",
			examine: "检查「{{name}}」",
			contact: "联系「{{name}}」",
			analyze: "请「{{expert}}」分析「{{name}}」",
			travelTo: "前往「{{name}}」",
			chooseTarget: "选择调查目标",
			chooseTopic: "选择询问对象",
			chooseAnalysisSubject: "选择分析对象",
			remoteContact: "远程联系",
			endContact: "结束联系",
			tutorialHint: "教学提示",
			newClue: "有新线索",
			timeSpent: "＋{{n}}分钟",
			leadToInvestigate: "待查线索",
			characterProfile: "人物资料",
			sourcePassage: "查看原文",
			identityUnknown: "尚未获知此人的身份背景。",
			relatedDossier: "关联案卷",
			noRelatedHistory: "暂无相关调查记录。",
			caseEvent: "案件进展",
			examination: "检查",
			doctor: "医生",
			hacker: "黑客",
			scientist: "科学家",
			criminologist: "犯罪学家",
			doctorDescription: "验尸，提供医学意见。",
			hackerDescription: "分析技术问题，调查信息。",
			scientistDescription: "在实验室分析物证，提供科学意见。",
			criminologistDescription: "分析嫌疑人的心理特征与物品的社会背景。",
			dossier: "案卷",
			history: "调查记录",
			notes: "调查笔记",
			close: "关闭",
			emptyCards: "暂无已发现的卡片。",
			chooseCard: "选择卡片",
			notesPlaceholder: "记录人物关系、时间和待查线索……",
			saveNotes: "保存笔记",
			notesSaved: "笔记已保存",
			question: "问题 {{n}} / {{total}}",
			mandatory: "必答",
			optional: "选答",
			submitAnswer: "提交答案",
			submitSelectedAnswer: "提交「{{name}}」作为答案",
			skipAnswer: "跳过本题",
			abortEnding: "返回调查",
			selectAnswer: "选择一张卡片作为答案。",
			selected: "已选：{{name}}",
			sceneLoading: "正在载入现场……",
			sceneFailed: "现场暂时无法显示，请重试。",
			retry: "重新载入",
			sceneHint: "拖动观察四周，使用方向键也可转动视角。",
			exitScene: "结束观察",
			seconds: "剩余 {{n}} 秒",
			score: "得分",
			maximum: "基础满分 {{n}}",
			answerScore: "答案得分",
			stateScore: "调查结果",
			timeScore: "耗时奖惩",
			penalty: "累计扣分",
			solution: "案件真相",
			outro: "调查结论",
			showSolution: "查看案件真相",
			hideSolution: "收起案件真相",
			noAnswer: "未作答",
			playAgain: "重新调查",
			nextCase: "继续调查：{{name}}",
			backToLobby: "返回大厅",
			resumeEnding: "填写结案报告",
			elapsed: "已调查 {{hours}} 小时 {{minutes}} 分钟",
			day: "第 {{n}} 天",
			invalidAction: "当前无法执行此操作。",
			readFirst: "请先阅读完当前内容。",
			seriesOption: "系列",
			base: "基础版：伦敦",
			noir: "黑幕",
			redview: "红景镇迷踪",
			noir1: "邵玛绯闻",
			noir2: "回忆录",
			noir3: "无药可救",
			noir4: "地狱之隼",
			redview1: "第一章：序幕",
			redview2: "第二章：野兽",
			redview3: "第三章：巫婆",
			redview4: "第四章：幽灵",
			roleOption: "调查角色",
			roleDescription: "{{name}}：体能＋{{fitness}}，头脑＋{{mind}}，沟通＋{{speech}}；体力{{energy}}",
			fitness: "体能",
			mind: "头脑",
			speech: "沟通",
			easy: "容易",
			normal: "普通",
			hard: "困难",
			actions: "行动",
			action: "行动",
			useAction: "使用「{{name}}」",
			money: "${{n}}",
			energy: "体力 {{n}} / {{max}}",
			skillTest: "能力检定",
			makeChoice: "作出选择",
			yes: "是",
			no: "否",
			cancel: "取消",
			success: "成功",
			failure: "失败",
			roll: "掷骰",
			spendEnergy: "消耗1点体力，追加掷骰",
			continueTest: "继续调查",
			acceptFailure: "结束检定，接受失败",
			dieResult: "骰子点数：{{n}}",
			successes: "成功数 {{n}} / 1",
			testFormula: "骰子点数＋能力{{ability}}＋（{{modifier}}）：5至6为1次成功，7及以上为2次成功。",
			fatigued: "疲劳：能力视为0，无法消耗体力追加掷骰。"
		},
		en: {
			name: "Chronicles of Crime",
			desc: "Investigate London, Noir and Redview cases. Interview witnesses, search scenes and uncover the truth.",
			rules: "Goal:\n· Investigate the case, gather clues and answer the closing questions.\nSetup:\n· Choose London, Noir or Redview, then select a case.\n· One player investigates; Redview also requires a teenager role.\n· Continue from the closing report to retain relevant results and your role.\n· Direct chapter selection uses the default start. References match the cards below.\nInvestigation:\n· Select a card, then press its action button. Selection costs no time.\n· Travel to locations, talk to people, and examine items or evidence categories.\n· During an interview, select another person or item to ask about them.\n· In the base game, contact an expert, then select a subject to analyze.\n· Tap a selected card again to deselect it. End an interview before starting another.\n· Travel usually costs 20 minutes; questions and item checks cost 5 minutes.\n· Some cases and actions use different costs, reflected in the game clock.\n· Eligible locations allow scene searches, each costing 5 game minutes.\n· Observe for 40 seconds, then select the evidence categories you noticed and examine them.\n· People, locations and special items appear as the story reveals them.\n· Clues and characters can change with progress and game time.\n· Tap the story or card area to read on; a triangle marks the next passage.\n· Act directly on the last passage; observation, choices and closing use explicit buttons.\n· Select a person or item to read related records and known profiles.\n· Case file contains timed investigation records and notes.\n· Progress is saved automatically on this device.\nNoir:\n· Use Follow, Intimidate, Break In and Bribe action cards.\n· Actions target your current location or the person you are interviewing.\n· Bribery requires at least $20. The story applies all income and spending.\nRedview:\n· Use Fitness, Mind and Speech action cards, or the Hint card for leads.\n· Available tests and hints depend on your location, interview and progress.\n· Roll one six-sided die and add the matching ability and difficulty modifier.\n· Easy adds +1, Normal adds 0 and Hard adds −1.\n· A total of 5–6 gives 1 success; a total of 7 or more gives 2.\n· This single-character mode requires at least 1 accumulated success to pass.\n· If you fail, you may spend 1 energy to roll an extra die. Successes accumulate.\n· You may accept failure and continue. Once you pass, no extra roll is needed.\n· A few story prompts ask for an action result directly; select success or failure as prompted.\n· Sleep at HQ to recover energy. Special events can restrict recovery or abilities.\nScoring:\n· Follow the story to submit the closing report. Some events start it automatically.\n· Select and submit a card for each question; optional questions may be skipped.\n· A wrong mandatory answer costs points and returns you to the investigation.\n· Scoring includes answers, investigation results, time and accumulated penalties.",
			caseOption: "Case",
			tutorial: "Tutorial",
			chapter1: "Chapter One: Facing Mystery",
			chapter2: "Chapter Two: The Source of Evil",
			chapter3: "Chapter Three: At the Heart of Power",
			pharaohs: "Curse of the Pharaohs",
			roses: "Every Rose Has Its Thorns",
			investigation: "Investigation",
			interview: "Interview",
			consultation: "Expert advice",
			ending: "Closing report",
			scene: "Scene search",
			done: "Case closed",
			characters: "People",
			locations: "Locations",
			categories: "Evidence",
			experts: "Experts",
			specials: "Special items",
			character: "Person",
			location: "Location",
			category: "Evidence",
			expert: "Expert",
			special: "Item",
			next: "Read next passage",
			resumeInvestigation: "Return to investigation",
			resumeInterview: "Return to interview",
			startObservation: "Start observation (40s)",
			leave: "End interview",
			investigate: "Search scene",
			solve: "Close the case",
			talkTo: "Talk to {{name}}",
			askAbout: "Ask about {{name}}",
			examine: "Examine {{name}}",
			contact: "Contact {{name}}",
			analyze: "Ask {{expert}} to analyze {{name}}",
			travelTo: "Go to {{name}}",
			chooseTarget: "Select an investigation target",
			chooseTopic: "Select a topic",
			chooseAnalysisSubject: "Select a subject to analyze",
			remoteContact: "Remote contact",
			endContact: "End contact",
			tutorialHint: "Tutorial guidance",
			newClue: "New clue",
			timeSpent: "+{{n}} min",
			leadToInvestigate: "Lead to investigate",
			characterProfile: "Profile",
			sourcePassage: "Read source passage",
			identityUnknown: "This person’s background has not been revealed yet.",
			relatedDossier: "Related records",
			noRelatedHistory: "No related investigation records yet.",
			caseEvent: "Case development",
			examination: "Examine",
			doctor: "Doctor",
			hacker: "Hacker",
			scientist: "Scientist",
			criminologist: "Criminologist",
			doctorDescription: "Autopsies and medical observations.",
			hackerDescription: "Technical analysis and information research.",
			scientistDescription: "Laboratory analysis and scientific research.",
			criminologistDescription: "Psychological profiles and the social context of objects.",
			dossier: "Case file",
			history: "Case history",
			notes: "Notes",
			close: "Close",
			emptyCards: "No cards discovered yet.",
			chooseCard: "Select a card",
			notesPlaceholder: "Record connections, times and leads…",
			saveNotes: "Save notes",
			notesSaved: "Notes saved",
			question: "Question {{n}} / {{total}}",
			mandatory: "Mandatory",
			optional: "Optional",
			submitAnswer: "Submit answer",
			submitSelectedAnswer: "Answer: {{name}}",
			skipAnswer: "Skip question",
			abortEnding: "Resume investigation",
			selectAnswer: "Choose a card as your answer.",
			selected: "Selected: {{name}}",
			sceneLoading: "Loading the scene…",
			sceneFailed: "The scene could not be displayed. Please retry.",
			retry: "Retry",
			sceneHint: "Drag to look around. Arrow keys also turn the view.",
			exitScene: "Finish searching",
			seconds: "{{n}} seconds left",
			score: "Score",
			maximum: "Base maximum {{n}}",
			answerScore: "Answers",
			stateScore: "Investigation results",
			timeScore: "Time adjustment",
			penalty: "Accumulated penalties",
			solution: "The truth",
			outro: "Conclusion",
			showSolution: "Reveal the truth",
			hideSolution: "Hide the truth",
			noAnswer: "No answer",
			playAgain: "Investigate again",
			nextCase: "Continue: {{name}}",
			backToLobby: "Back to lobby",
			resumeEnding: "Write the closing report",
			elapsed: "Investigated for {{hours}}h {{minutes}}m",
			day: "Day {{n}}",
			invalidAction: "This action is not available now.",
			readFirst: "Please finish reading the current message.",
			seriesOption: "Series",
			base: "Base game: London",
			noir: "Noir",
			redview: "Welcome to Redview",
			noir1: "The Thelma Dott Affair",
			noir2: "A Life Lost",
			noir3: "A Cure to Die For",
			noir4: "Hell’s Hawk",
			redview1: "Chapter 1: The Beginning",
			redview2: "Chapter 2: The Beast",
			redview3: "Chapter 3: The Witch",
			redview4: "Chapter 4: The Ghost",
			roleOption: "Investigator",
			roleDescription: "{{name}}: Fitness +{{fitness}}, Mind +{{mind}}, Speech +{{speech}}; Energy {{energy}}",
			fitness: "Fitness",
			mind: "Mind",
			speech: "Speech",
			easy: "Easy",
			normal: "Normal",
			hard: "Hard",
			actions: "Actions",
			action: "Action",
			useAction: "Use {{name}}",
			money: "${{n}}",
			energy: "Energy {{n}} / {{max}}",
			skillTest: "Skill test",
			makeChoice: "Make a choice",
			yes: "Yes",
			no: "No",
			cancel: "Cancel",
			success: "Success",
			failure: "Failure",
			roll: "Roll the die",
			spendEnergy: "Spend 1 energy to roll again",
			continueTest: "Continue",
			acceptFailure: "Finish with failure",
			dieResult: "Die result: {{n}}",
			successes: "Successes {{n}} / 1",
			testFormula: "Die + ability {{ability}} + ({{modifier}}): 5–6 gives 1 success; 7 or more gives 2.",
			fatigued: "Exhausted: abilities count as 0 and energy cannot buy extra rolls."
		}
	}
};
//#endregion
export { Gt as default };
