import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as i } from "@bgparty/sdk/player-colors";
import { useWakeLock as a } from "@bgparty/sdk/use-wake-lock";
import { SheetFxProbe as o, SheetView as s } from "@bgparty/sdk/sheet-view";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { FlySprite as ee, PulseBox as m } from "@bgparty/sdk/fx/primitives";
//#region src/games/godfather/data.ts
var h = (e, t = 0, n) => ({
	kind: e,
	value: t,
	...n ? { extra: n } : {}
}), g = [
	1,
	2,
	3,
	5
], _ = [
	5,
	5,
	6,
	2
], v = [
	{
		atlas: 0,
		count: 3,
		color: 3,
		cost: [1],
		reward: [3],
		effect: h("shootThug")
	},
	{
		atlas: 23,
		count: 5,
		color: 0,
		cost: [0, 0],
		reward: [2, 2],
		effect: h("bank", 3)
	},
	{
		atlas: 26,
		count: 3,
		color: 0,
		cost: [0],
		reward: [3],
		effect: h("refuse")
	},
	{
		atlas: 27,
		count: 3,
		color: 3,
		cost: [
			1,
			1,
			1
		],
		reward: [3, 3],
		effect: h("bomb")
	},
	{
		atlas: 28,
		count: 11,
		color: 1,
		cost: [
			0,
			1,
			2
		],
		reward: [5],
		effect: h("shakedown")
	},
	{
		atlas: 29,
		count: 5,
		color: 3,
		cost: [1, 1],
		reward: [2, 2],
		effect: h("drive", 2)
	},
	{
		atlas: 30,
		count: 3,
		color: 0,
		cost: [
			0,
			0,
			0
		],
		reward: [3, 3],
		effect: h("extort")
	},
	{
		atlas: 33,
		count: 3,
		color: 2,
		cost: [
			2,
			2,
			2
		],
		reward: [3, 3],
		effect: h("control")
	},
	{
		atlas: 34,
		count: 5,
		color: 2,
		cost: [2, 2],
		reward: [2, 2],
		effect: h("reuse")
	},
	{
		atlas: 35,
		count: 3,
		color: 2,
		cost: [2],
		reward: [3],
		effect: h("move")
	}
], y = [
	{
		front: [h("draw")],
		back: [h("draw")],
		grade: 0
	},
	{
		front: [h("goods", 2)],
		back: [h("goods", 2)],
		grade: 0
	},
	{
		front: [h("first"), h("money", 1)],
		back: [h("money", 1)],
		grade: 0
	},
	{
		front: [h("exchange", 2, [5])],
		back: [h("bank", 1)],
		grade: 0
	},
	{
		front: [h("goods", 0)],
		back: [h("goods", 0)],
		grade: 0
	},
	{
		front: [h("goods", 1)],
		back: [h("goods", 1)],
		grade: 0
	},
	{
		front: [h("bank", 1)],
		back: [h("bank", 1)],
		grade: 0
	},
	{
		front: [h("exchange", 1, [5])],
		back: [h("money", 1)],
		grade: 1
	},
	{
		front: [h("exchangeGood", 1)],
		back: [h("bank", 1)],
		grade: 1
	},
	{
		front: [h("goods", 0), h("money", 1)],
		back: [h("goods", 0)],
		grade: 1
	},
	{
		front: [h("goods", 2), h("money", 1)],
		back: [h("goods", 2)],
		grade: 1
	},
	{
		front: [h("goods", 1), h("money", 1)],
		back: [h("goods", 1)],
		grade: 1
	},
	{
		front: [h("draw"), h("money", 2)],
		back: [h("draw")],
		grade: 1
	},
	{
		front: [h("money", 3)],
		back: [h("money", 1)],
		grade: 1
	},
	{
		front: [h("bank", 1), h("money", 2)],
		back: [h("bank", 1)],
		grade: 1
	},
	{
		front: [h("exchange", 3, [3, 5])],
		back: [h("money", 3)],
		grade: 2
	},
	{
		front: [h("goods", 3), h("money", 2)],
		back: [h("goods", 3)],
		grade: 2
	},
	{
		front: [h("bank", 3)],
		back: [h("bank", 1)],
		grade: 2
	},
	{
		front: [h("goods", 3), h("bank", 1)],
		back: [h("goods", 3)],
		grade: 2
	}
], b = [
	{
		x: 44,
		y: 13,
		turfs: [
			5,
			3,
			0
		],
		min: 2
	},
	{
		x: 17,
		y: 33,
		turfs: [5, 7],
		min: 3
	},
	{
		x: 35,
		y: 33,
		turfs: [
			5,
			7,
			0
		],
		min: 2
	},
	{
		x: 52,
		y: 33,
		turfs: [
			3,
			6,
			0
		],
		min: 2
	},
	{
		x: 67,
		y: 33,
		turfs: [3, 6],
		min: 3
	},
	{
		x: 44,
		y: 40,
		turfs: [
			0,
			7,
			6
		],
		min: 2
	},
	{
		x: 44,
		y: 54,
		turfs: [7, 6],
		min: 3
	},
	{
		x: 73,
		y: 46,
		turfs: [6, 4],
		min: 2
	},
	{
		x: 44,
		y: 68,
		turfs: [
			7,
			6,
			1
		],
		min: 2
	},
	{
		x: 68,
		y: 68,
		turfs: [6, 1],
		min: 3
	},
	{
		x: 25,
		y: 78,
		turfs: [7, 1],
		min: 3
	},
	{
		x: 73,
		y: 86,
		turfs: [1, 2],
		min: 2
	},
	{
		x: 84,
		y: 60,
		turfs: [4, 2],
		min: 2
	},
	{
		x: 96,
		y: 60,
		turfs: [4, 2],
		min: 3
	}
], x = [
	{
		x: 47,
		y: 86,
		color: "#8798ac"
	},
	{
		x: 87,
		y: 79,
		color: "#a48594"
	},
	{
		x: 59,
		y: 20,
		color: "#8d7eab"
	},
	{
		x: 87,
		y: 37,
		color: "#ad7964"
	},
	{
		x: 25,
		y: 20,
		color: "#8e9b9f"
	},
	{
		x: 57,
		y: 51,
		color: "#748d70"
	},
	{
		x: 28,
		y: 51,
		color: "#a16a69"
	}
], S = Array.from({ length: 18 }, (e, t) => ({
	atlas: t + 5,
	act: Math.floor(t / 6) + 1
})), C = [
	...g.flatMap((e) => Array.from({ length: 30 }, () => ({
		kind: "money",
		value: e
	}))),
	...Array.from({ length: 4 }, (e, t) => Array.from({ length: 8 }, () => ({
		kind: "goods",
		value: t
	}))).flat(),
	...v.flatMap((e, t) => Array.from({ length: e.count }, () => ({
		kind: "job",
		value: t
	}))),
	...S.map((e, t) => ({
		kind: "ally",
		value: t
	}))
].map((e, t) => ({
	...e,
	id: t
})), w = (e) => e.reduce((e, t) => e + (C[t].kind === "money" ? C[t].value : 0), 0), te = {
	id: "godfather",
	tier: "alpha",
	nameKey: "games.godfather.name",
	descKey: "games.godfather.desc",
	rulesKey: "games.godfather.rules",
	icon: "🕴️",
	iconImg: "games/godfather.webp",
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#927243",
	mechanics: [
		"worker-placement",
		"area-control",
		"hand-management",
		"auction"
	],
	interactionTags: [],
	releasedAt: "2026-11-05T00:15:00+08:00",
	search: {
		py: "jiao fu ke li ang de di guo",
		init: "jfkladdg"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://cmon-files.s3.amazonaws.com/pdf/assets_item/resource/65/GDF001-Rulebook.pdf" }
}, T = t.int().nonnegative(), ne = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		piece: T,
		slot: T
	}),
	t.object({
		type: t.literal("job"),
		card: T,
		rewardFirst: t.boolean()
	}),
	t.object({
		type: t.literal("ally"),
		card: T
	}),
	t.object({
		type: t.literal("choose"),
		value: t.int()
	}),
	t.object({
		type: t.literal("effect"),
		index: T
	}),
	t.object({
		type: t.literal("bid"),
		cards: t.array(T).max(120)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), re = t.object({
	kind: t.string(),
	value: t.int().optional(),
	extra: t.array(t.int()).optional()
}), E = t.object({
	id: T,
	owner: t.int(),
	kind: t.enum([
		"thug",
		"family",
		"mayor",
		"union",
		"police"
	]),
	slot: t.int(),
	available: t.boolean()
}), D = t.object({
	rid: t.string(),
	handCount: T,
	caseCount: T,
	used: t.array(T),
	jobs: t.array(T),
	bid: t.int(),
	committed: t.boolean(),
	final: t.array(t.int())
}), O = t.object({
	players: t.array(D),
	pieces: t.array(E),
	phase: t.enum([
		"business",
		"effects",
		"prompt",
		"between",
		"war",
		"bidding",
		"auction",
		"tribute",
		"reset",
		"final",
		"done"
	]),
	active: t.string(),
	turn: t.string(),
	first: t.string(),
	act: t.int(),
	turfs: t.array(t.array(t.int())),
	businesses: t.array(t.object({
		id: T,
		turf: T
	})),
	publicJobs: t.array(T),
	allies: t.array(T),
	supply: t.array(t.object({
		kind: t.string(),
		value: t.int(),
		count: T
	})),
	effects: t.array(re),
	prompt: t.string(),
	target: t.int(),
	count: t.int(),
	revealed: t.array(T),
	warTurf: t.int(),
	log: t.array(t.object({
		event: t.string(),
		rid: t.string(),
		value: t.int(),
		target: t.int()
	}))
}), k = t.object({
	hand: t.array(T),
	suitcase: t.array(T),
	legal: t.array(ne),
	bid: t.array(T),
	offered: t.array(T)
}), A = (e, t, n = 0, r = []) => ({
	kind: e,
	seat: t,
	value: n,
	extra: [...r],
	cards: [],
	piece: -1,
	remaining: 0,
	selected: []
}), j = (e, t) => JSON.stringify(e) === JSON.stringify(t), ie = (e) => e.prompt?.seat ?? e.blocks[0]?.seat ?? e.active;
function M(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function N(e, t, n = 0, r = -1, i = e.turn) {
	e.log.push({
		event: t,
		rid: e.players[i].rid,
		value: n,
		target: r
	});
}
function P(e, t, n, r, i = -1, a = -1, o = !1) {
	let s = a >= 0 ? e.pieces[a] : void 0;
	e.fx.push({
		kind: "transfer",
		rid: e.players[r]?.rid ?? "",
		data: {
			from: t,
			to: n,
			piece: a,
			...s ? {
				pieceKind: s.kind,
				owner: e.players[s.owner]?.rid ?? ""
			} : {},
			...o && i >= 0 ? { card: i } : {}
		},
		...i >= 0 && !o ? {
			for: [e.players[r].rid],
			secret: { card: i }
		} : {}
	});
}
function F(e, t, n, r, i = !1) {
	let a = e.supply.find((e) => C[e].kind === n && C[e].value === r);
	if (a === void 0 && n === "money") {
		for (let t of [...g].reverse().filter((e) => e < r)) if (a = e.supply.find((e) => C[e].kind === n && C[e].value === t), a !== void 0) break;
	}
	a !== void 0 && (e.supply.splice(e.supply.indexOf(a), 1), e.players[t][i ? "suitcase" : "hand"].push(a), P(e, "supply", `${i ? "case" : "hand"}:${e.players[t].rid}`, t, a, -1, !0));
}
function I(e, t) {
	let n = C[t];
	n.kind === "money" || n.kind === "goods" ? e.supply.push(t) : n.kind === "job" ? e.discard.push(t) : e.removed.push(t);
}
function L(e) {
	return e.deck.length || (e.deck = M(e, e.discard), e.discard = []), e.deck.pop();
}
function ae(e) {
	let t = e.players.length === 2 ? 2 : e.players.length === 5 ? 4 : 3;
	for (; e.publicJobs.length < t;) {
		let t = L(e);
		if (t === void 0) break;
		e.publicJobs.push(t);
	}
	e.act < 4 && (e.allies = M(e, e.removed.filter((t) => C[t].kind === "ally" && S[C[t].value].act === e.act)).slice(0, e.players.length - 1), e.removed = e.removed.filter((t) => !e.allies.includes(t)));
}
function R(e) {
	let t = Array.from({ length: 7 }, (e, t) => t + 1).find((t) => e.businesses.filter((e) => e.turf === t).length < 2), n = (e.act < 3 ? e.blue : e.red).pop();
	t && n !== void 0 && e.businesses.push({
		id: n,
		turf: t
	});
}
function oe(t, n, r) {
	let i = {
		players: n.map((e) => ({
			rid: e,
			hand: [],
			suitcase: [],
			used: [],
			completed: [],
			bid: [],
			committed: !1,
			final: []
		})),
		pieces: [],
		phase: "business",
		active: 0,
		turn: 0,
		first: 0,
		act: 1,
		seed: r,
		cursor: 0,
		supply: C.filter((e) => e.kind === "money" || e.kind === "goods").map((e) => e.id),
		deck: [],
		discard: [],
		removed: C.filter((e) => e.kind === "ally").map((e) => e.id),
		blue: [],
		red: [],
		turfs: Array.from({ length: 7 }, () => []),
		businesses: Array.from({ length: 7 }, (e, t) => ({
			id: t,
			turf: t + 1
		})),
		publicJobs: [],
		allies: [],
		blocks: [],
		prompt: null,
		pendingJob: -1,
		rewardFirst: !1,
		offered: [],
		auction: [],
		warTurf: 1,
		returnPhase: "effects",
		tributeSeat: 0,
		finalSeat: 0,
		log: [],
		fx: []
	};
	i.deck = M(i, C.filter((e) => e.kind === "job").map((e) => e.id)), i.blue = M(i, [
		7,
		8,
		9,
		10,
		11,
		12,
		13,
		14
	]), i.red = M(i, [
		15,
		16,
		17,
		18
	]), i.first = e(r, i.cursor++, n.length), i.turn = i.active = i.first, n.forEach((e, t) => {
		for (let e of [
			1,
			2,
			3
		]) F(i, t, "money", e);
		for (let e = 0; e < 2; e++) {
			let e = L(i);
			e !== void 0 && i.players[t].hand.push(e);
		}
		for (let e = 0; e < (n.length === 2 ? 3 : 2); e++) i.pieces.push({
			id: i.pieces.length,
			owner: t,
			kind: "thug",
			slot: -1,
			available: !0
		});
		for (let e = 0; e < 3; e++) i.pieces.push({
			id: i.pieces.length,
			owner: t,
			kind: "family",
			slot: e === 0 ? -1 : -3,
			available: e === 0
		});
	});
	for (let e of [
		"mayor",
		"union",
		"police"
	]) i.pieces.push({
		id: i.pieces.length,
		owner: -1,
		kind: e,
		slot: -1,
		available: !0
	});
	if (n.length >= 4 && i.businesses.push({
		id: i.blue.pop(),
		turf: 1
	}), n.length === 5) for (let e of [2, 3]) i.businesses.push({
		id: i.blue.pop(),
		turf: e
	});
	return ae(i), R(i), i.fx = [], {
		state: i,
		fx: []
	};
}
function z(e, t) {
	return t.slot < 0 ? [] : t.slot >= 200 ? [t.slot - 200] : t.slot >= 100 ? b[t.slot - 100]?.turfs.filter((e) => e > 0) ?? [] : [e.businesses.find((e) => e.id === t.slot)?.turf ?? 0];
}
function se(e, t) {
	let n = Array(e.players.length + 1).fill(0);
	for (let r of e.pieces) z(e, r).includes(t) && n[r.owner < 0 ? e.players.length : r.owner]++;
	return n;
}
function B(e, t) {
	return t.kind === "police" ? [
		201,
		202,
		203,
		204,
		205,
		206,
		207
	].filter((e) => e !== t.slot) : t.kind === "family" || t.kind === "mayor" ? b.flatMap((t, n) => t.min <= e.players.length && !e.pieces.some((e) => e.slot === 100 + n) ? [100 + n] : []) : e.businesses.filter((t) => !e.pieces.some((e) => e.slot === t.id)).map((e) => e.id);
}
function V(e, t, n, r = !0, i = !0) {
	n.length && e.blocks[r ? "unshift" : "push"]({
		seat: t,
		effects: structuredClone(n),
		optional: i
	});
}
function H(e) {
	if (e.prompt = null, e.blocks = e.blocks.filter((e) => e.effects.length), e.returnPhase === "war") {
		e.phase = "war", e.returnPhase = "effects";
		return;
	}
	e.phase = e.blocks.length ? "effects" : "between", e.active = e.blocks[0]?.seat ?? e.turn;
}
function U(e, t) {
	e.prompt = t, e.active = t.seat, e.phase = "prompt";
}
function ce(e, t, n, r = []) {
	V(e, t, [...b[n - 100].turfs.flatMap((t) => t === 0 ? [{
		kind: "bank",
		value: 1
	}] : e.businesses.filter((e) => e.turf === t).flatMap((e) => y[e.id].back)), ...r]);
}
function le(e, t, n, r = 1) {
	let i = e.businesses.find((e) => e.id === n), a = e.turfs[i.turf - 1].at(-1);
	a !== void 0 && a !== t ? U(e, A("frontOrder", e.turn, n, [
		t,
		a,
		r
	])) : (V(e, t, Array.from({ length: r }, () => y[n].front).flat()), H(e));
}
function ue(e, t, n, r) {
	let i = t.slot < 0 ? `reserve:${e.players[r].rid}` : `slot:${t.slot}`;
	t.slot = n, P(e, i, `piece:${t.id}`, r, -1, t.id, !0), N(e, "place", t.id, n, r);
}
function de(e, t, n, r, i = !0) {
	if (ue(e, t, n, r), !i) {
		H(e);
		return;
	}
	t.kind === "thug" || t.kind === "union" ? le(e, r, n) : (ce(e, r, n), H(e));
}
function fe(e, t, n) {
	e.turfs.flat().filter((e) => e === t).length < 9 ? (e.turfs[n - 1].push(t), N(e, "control", n, -1, t), e.fx.push({
		kind: "control",
		rid: e.players[t].rid,
		data: { turf: n }
	}), H(e)) : U(e, A("recycle", t, n));
}
function pe(e, t, n) {
	let r = `slot:${t.slot}`;
	t.slot = -2, P(e, r, `piece:${t.id}`, n, -1, t.id, !0), N(e, "kill", t.id, -1, n);
}
function me(e) {
	if (e.pendingJob < 0) return;
	let t = e.players[e.turn];
	t.suitcase.push(e.pendingJob), t.completed.push(e.pendingJob), P(e, "job-play", `case:${t.rid}`, e.turn, e.pendingJob, -1, !0), N(e, "job", C[e.pendingJob].value), e.pendingJob = -1;
}
function he(e) {
	me(e);
	for (let t = 1; t <= e.players.length; t++) {
		let n = (e.turn + t) % e.players.length;
		if (we(e, n).length) {
			e.turn = e.active = n, e.phase = "business";
			return;
		}
	}
	e.phase = "war", e.warTurf = 1;
}
function ge(e) {
	for (let t of e.players) t.hand.push(...t.used), t.used = [];
	e.active = e.first, e.tributeSeat = 0, e.phase = "tribute";
}
function _e(e, t, n) {
	return ve(e.players[t].hand, v[C[n].value].cost);
}
function ve(e, t) {
	let n = [...t], r = 0, i = e.filter((e) => C[e].kind === "goods").map((e) => C[e].value);
	for (let e of i) if (e === 3) r++;
	else {
		let t = n.indexOf(e);
		t >= 0 && n.splice(t, 1);
	}
	return n.length <= r;
}
function ye(e) {
	let t = v[C[e.pendingJob].value], n = {
		kind: "reward",
		extra: t.reward
	}, r = e.rewardFirst ? [n, t.effect] : [t.effect, n];
	for (let t of [...r].reverse()) V(e, e.turn, [t], !0, !1);
	H(e);
}
function be(e, t) {
	let n = C[t].value, r = Math.floor(n / 6) + 1, i = n % 6;
	if (i === 0) V(e, e.turn, r === 1 ? [{
		kind: "money",
		value: 2
	}] : r === 2 ? [{
		kind: "bank",
		value: 2
	}] : [{
		kind: "money",
		value: 5
	}]);
	else if (r === 1 && i === 3) V(e, e.turn, e.turfs.filter((t) => t.at(-1) === e.turn).map(() => ({
		kind: "caseMoney",
		value: 1
	})));
	else if (r === 1 && i === 4) V(e, e.turn, [{
		kind: "bank",
		value: 1
	}]);
	else if (r === 2 && i === 1) V(e, e.turn, [{
		kind: "money",
		value: 3
	}]);
	else if (r === 2 && i === 4) V(e, e.turn, e.turfs.filter((t) => t.at(-1) === e.turn).map(() => ({ kind: "chooseGood" })));
	else if (r === 3 && i === 1) V(e, e.turn, e.turfs.filter((t) => t.at(-1) === e.turn).map(() => ({
		kind: "money",
		value: 5
	})));
	else if (r === 3 && i === 2) V(e, e.turn, [{
		kind: "bank",
		value: 3
	}]);
	else {
		let t = i === 5 ? "union" : (r === 1 ? i === 1 : r === 2 ? i === 2 : i === 3) ? "mayor" : "police", n = e.pieces.find((e) => e.kind === t);
		if (n.slot !== -2) {
			let t = A("neutral", e.turn, r);
			t.piece = n.id, U(e, t);
			return;
		}
	}
	H(e);
}
function xe(e, t, n) {
	let r = e.players[n], i = t.value ?? 0;
	if (t.kind === "money" || t.kind === "goods" || t.kind === "caseMoney") F(e, n, t.kind === "goods" ? "goods" : "money", i, t.kind === "caseMoney");
	else if (t.kind === "reward") for (let r of t.extra ?? []) F(e, n, "money", r);
	else if (t.kind === "first") e.first = n, N(e, "first", 0, -1, n);
	else if (t.kind === "draw") {
		let t = [];
		for (let n = 0; n < 2; n++) {
			let n = L(e);
			n !== void 0 && t.push(n);
		}
		if (t.length) {
			let r = A("draw", n);
			r.cards = t, U(e, r);
			return;
		}
	} else if (t.kind === "bank") {
		if (r.hand.some((e) => C[e].kind === "money")) {
			let t = A("bank", n);
			t.remaining = i, U(e, t);
			return;
		}
	} else if (t.kind === "exchange" || t.kind === "exchangeGood") {
		if (r.hand.length >= i) {
			let r = A("exchange", n, t.kind === "exchangeGood" ? -1 : 0, t.extra);
			r.remaining = i, U(e, r);
			return;
		}
	} else if (t.kind === "refuse") {
		e.offered = [];
		let t = e.players.flatMap((e, t) => t !== n && e.hand.length ? [t] : []);
		if (t.length) {
			U(e, A("refuseDiscard", t[0], n, t.slice(1)));
			return;
		}
	} else if (t.kind === "chooseGood") {
		U(e, A("good", n));
		return;
	} else {
		U(e, A(t.kind, n, i, t.extra));
		return;
	}
	H(e);
}
function Se(e, t) {
	let n = e.players[t.seat], r = (e) => e.owner >= 0 && e.owner !== t.seat && e.slot >= 0;
	switch (t.kind) {
		case "pay": return n.hand.filter((e) => C[e].kind === "goods" && (C[e].value === t.extra[0] || C[e].value === 3) && ve(n.hand.filter((t) => t !== e), t.extra.slice(1)));
		case "draw": return t.cards;
		case "bank": return [-1, ...n.hand.filter((e) => C[e].kind === "money")];
		case "exchange":
		case "refuseDiscard": return n.hand;
		case "loot": return [-1, ...e.offered];
		case "good": return [
			0,
			1,
			2
		].filter((t) => e.supply.some((e) => C[e].kind === "goods" && C[e].value === t));
		case "frontOrder": return [0, 1];
		case "neutral": return B(e, e.pieces[t.piece]);
		case "shakedown": return e.businesses.map((e) => e.id);
		case "shootThug": return e.pieces.filter((e) => r(e) && e.kind === "thug").map((e) => e.id);
		case "drive": return [-1, ...e.pieces.filter((e) => r(e) && !t.selected.includes(e.owner)).map((e) => e.id)];
		case "bomb": return Array.from({ length: 7 }, (e, t) => t + 1).filter((t) => e.pieces.some((n) => r(n) && z(e, n).includes(t)));
		case "policeMove": return [-1, ...e.pieces.filter((n) => n.id !== t.piece && z(e, n).includes(t.value) && B(e, n).length).map((e) => e.id)];
		case "policeKill": return [-1, ...e.pieces.filter((n) => n.owner >= 0 && z(e, n).includes(t.value)).map((e) => e.id)];
		case "control": return t.extra.length ? t.extra.filter((e) => e > 0) : [
			1,
			2,
			3,
			4,
			5,
			6,
			7
		];
		case "recycle": return [-1, ...e.turfs.flatMap((e, n) => e.includes(t.seat) ? [n + 1] : [])];
		case "reuse": return e.pieces.filter((e) => e.owner === t.seat && e.slot >= 0).map((e) => e.id);
		case "move": return e.pieces.filter((t) => t.slot >= 0 && B(e, t).length).map((e) => e.id);
		case "destination":
		case "redeploy": return B(e, e.pieces[t.piece]).filter((n) => !t.value || !z(e, {
			...e.pieces[t.piece],
			slot: n
		}).includes(t.value));
		case "extort": return e.players.flatMap((e, n) => n !== t.seat && e.suitcase.some((e) => C[e].kind === "money") ? [n] : []);
		case "extortMoney": return n.suitcase.filter((e) => C[e].kind === "money");
		default: return [];
	}
}
function Ce(e, t) {
	let n = e.players.findIndex((e) => e.rid === t);
	if (n < 0 || e.phase === "done") return [];
	let r = e.players[n];
	if (e.phase === "bidding") return r.committed ? [] : [{
		type: "bid",
		cards: []
	}];
	if (ie(e) !== n) return [];
	if (e.phase === "prompt" && e.prompt) {
		let t = Se(e, e.prompt);
		return (t.length ? t : [-1]).map((e) => ({
			type: "choose",
			value: e
		}));
	}
	return e.phase === "effects" ? [...(e.blocks[0]?.effects ?? []).map((e, t) => ({
		type: "effect",
		index: t
	})), ...e.blocks[0]?.optional ? [{
		type: "choose",
		value: -1
	}] : []] : e.phase === "auction" ? e.allies.map((e) => ({
		type: "choose",
		value: e
	})) : e.phase === "tribute" ? r.hand.length > _[e.act - 1] ? r.hand.map((e) => ({
		type: "choose",
		value: e
	})) : [] : e.phase === "business" ? we(e, n) : [];
}
function we(e, t) {
	let n = e.players[t], r = e.pieces.filter((e) => e.owner === t && e.slot === -1);
	if (!r.length) return [];
	let i = r.flatMap((t) => B(e, t).map((e) => ({
		type: "place",
		piece: t.id,
		slot: e
	})));
	for (let r of [...n.hand, ...e.publicJobs]) if (C[r].kind === "job" && _e(e, t, r)) for (let e of [!1, !0]) i.push({
		type: "job",
		card: r,
		rewardFirst: e
	});
	for (let e of n.hand) C[e].kind === "ally" && i.push({
		type: "ally",
		card: e
	});
	return i;
}
function Te(e, t) {
	let n = e.prompt, r = n.seat, i = e.players[r];
	if (t === -1) {
		n.kind === "loot" && (e.offered.forEach((t) => I(e, t)), e.offered = []), H(e);
		return;
	}
	if (n.kind === "pay") {
		i.hand.splice(i.hand.indexOf(t), 1), I(e, t), P(e, `hand:${i.rid}`, "supply", r, t, -1, !0), n.extra.shift(), n.extra.length || ye(e);
		return;
	}
	if (n.kind === "draw") i.hand.push(t), n.cards.filter((e) => e !== t).forEach((t) => I(e, t)), P(e, "deck", `hand:${i.rid}`, r, t);
	else if (n.kind === "bank") {
		if (i.hand.splice(i.hand.indexOf(t), 1), i.suitcase.push(t), P(e, `hand:${i.rid}`, `case:${i.rid}`, r, t, -1, !0), N(e, "bank", C[t].value, -1, r), --n.remaining && i.hand.some((e) => C[e].kind === "money")) return;
	} else if (n.kind === "exchange") {
		if (i.hand.splice(i.hand.indexOf(t), 1), I(e, t), P(e, `hand:${i.rid}`, "supply", r, t, -1, !0), --n.remaining) return;
		if (n.value === -1) {
			U(e, A("good", r));
			return;
		}
		V(e, r, n.extra.map((e) => ({
			kind: "money",
			value: e
		})));
	} else if (n.kind === "refuseDiscard") {
		if (i.hand.splice(i.hand.indexOf(t), 1), e.offered.push(t), P(e, `hand:${i.rid}`, "offered", r, t, -1, !0), n.extra.length) {
			let t = n.extra.shift();
			n.seat = t, e.active = t;
			return;
		}
		U(e, A("loot", n.value));
		return;
	} else if (n.kind === "loot") i.suitcase.push(t), e.offered.filter((e) => e !== t).forEach((t) => I(e, t)), e.offered = [], P(e, "offered", `case:${i.rid}`, r, t, -1, !0);
	else if (n.kind === "good") F(e, r, "goods", t);
	else if (n.kind === "frontOrder") {
		let [r, i, a] = n.extra, o = t === 0 ? [r, i] : [i, r];
		for (let t of [...o].reverse()) V(e, t, Array.from({ length: a }, () => y[n.value].front).flat());
	} else if (n.kind === "neutral") {
		let i = e.pieces[n.piece];
		if (ue(e, i, t, r), i.kind === "union") {
			le(e, r, t, n.value);
			return;
		}
		if (i.kind === "mayor") {
			let i = {
				kind: "control",
				extra: b[t - 100].turfs.filter((e) => e > 0)
			};
			n.value === 2 ? V(e, r, [i]) : ce(e, r, t, n.value === 3 ? [i] : []);
		} else if (n.value === 3) e.pieces.filter((n) => n.owner >= 0 && n.owner !== r && z(e, n).includes(t - 200)).forEach((t) => pe(e, t, r));
		else {
			let a = A(n.value === 1 ? "policeMove" : "policeKill", r, t - 200);
			a.piece = i.id, U(e, a);
			return;
		}
	} else if (n.kind === "shakedown") {
		le(e, r, t);
		return;
	} else if (n.kind === "shootThug" || n.kind === "policeKill" || n.kind === "drive") {
		let i = e.pieces[t];
		if (pe(e, i, r), n.kind === "drive" && --n.value > 0) {
			n.selected.push(i.owner);
			return;
		}
	} else if (n.kind === "bomb") e.pieces.filter((n) => n.owner >= 0 && n.owner !== r && z(e, n).includes(t)).forEach((t) => pe(e, t, r));
	else if (n.kind === "control") {
		fe(e, r, t);
		return;
	} else if (n.kind === "recycle") {
		let i = e.turfs[t - 1], a = i.lastIndexOf(r);
		i.splice(a, 1), e.turfs[n.value - 1].push(r), N(e, "control", n.value, t, r);
	} else if (n.kind === "reuse" || n.kind === "move" || n.kind === "policeMove") {
		let a = e.pieces[t], o = A(n.kind === "reuse" ? "redeploy" : "destination", r, n.kind === "policeMove" ? n.value : 0);
		if (o.piece = t, n.kind === "reuse") {
			let n = `slot:${a.slot}`;
			a.slot = -1, P(e, n, `reserve:${i.rid}`, r, -1, t, !0);
		}
		U(e, o);
		return;
	} else if (n.kind === "destination" || n.kind === "redeploy") {
		de(e, e.pieces[n.piece], t, r, n.kind === "redeploy");
		return;
	} else if (n.kind === "extort") {
		let n = A("extortMoney", t, r);
		n.remaining = Math.min(3, e.players[t].suitcase.filter((e) => C[e].kind === "money").length), U(e, n);
		return;
	} else if (n.kind === "extortMoney") {
		i.suitcase.splice(i.suitcase.indexOf(t), 1), e.players[n.value].hand.push(t), P(e, `case:${i.rid}`, `hand:${e.players[n.value].rid}`, n.value, t);
		let r = e.fx.at(-1);
		if (r.for = [i.rid, e.players[n.value].rid], --n.remaining) return;
	}
	H(e);
}
function Ee(e, t) {
	let n = e.players[t], r = e.turfs.filter((n) => {
		if (!n.includes(t)) return !1;
		let r = e.players.map((e, t) => n.filter((e) => e === t).length), i = Math.max(...r), a = r.flatMap((e, t) => e === i ? [t] : []);
		return [...n].reverse().find((e) => a.includes(e)) === t;
	}).length, i = [
		0,
		1,
		2,
		3
	].map((n) => {
		let r = e.players.map((e) => e.suitcase.filter((e) => C[e].kind === "job" && v[C[e].value].color === n).length);
		return r[t] > 0 && r[t] === Math.max(...r) ? 5 : 0;
	});
	return [
		w(n.suitcase),
		r * 5,
		...i
	];
}
function De(e) {
	if (e.phase === "between") he(e);
	else if (e.phase === "war") {
		if (e.warTurf > 7) {
			e.act === 4 ? ge(e) : (e.phase = "bidding", e.players.forEach((e) => {
				e.committed = !1, e.bid = [];
			}));
			return;
		}
		let t = e.warTurf++, n = se(e, t), r = Math.max(...n), i = n.indexOf(r);
		N(e, "war", t, n.filter((e) => e === r).length === 1 && i < e.players.length ? i : -1), r > 0 && n.filter((e) => e === r).length === 1 && i < e.players.length && (e.returnPhase = "war", fe(e, i, t));
	} else if (e.phase === "auction") {
		if (e.auction.length && e.allies.length) {
			e.active = e.auction[0];
			return;
		}
		ge(e);
	} else if (e.phase === "tribute") {
		if (e.players[e.active].hand.length > _[e.act - 1]) return;
		++e.tributeSeat < e.players.length ? e.active = (e.first + e.tributeSeat) % e.players.length : e.phase = e.act === 4 ? "final" : "reset";
	} else if (e.phase === "reset") {
		e.act++, e.allies.forEach((t) => e.removed.push(t)), e.allies = [];
		for (let t of e.pieces) {
			if (t.kind === "family" && t.slot === -3) {
				let n = e.pieces.filter((e) => e.owner === t.owner && e.kind === "family").indexOf(t);
				(n === 1 && e.act >= 2 || n === 2 && e.act >= 4) && (t.available = !0);
			}
			t.available && (t.slot = -1);
		}
		ae(e), R(e), e.turn = e.active = e.first, e.phase = "business", N(e, "act", e.act);
	} else if (e.phase === "final") {
		let t = e.finalSeat++, n = e.players[t];
		n.hand.forEach((t) => C[t].kind === "money" ? n.suitcase.push(t) : I(e, t)), n.hand = [], n.final = Ee(e, t), N(e, "final", n.final.reduce((e, t) => e + t, 0), -1, t), e.finalSeat === e.players.length && (e.phase = "done");
	}
}
function Oe(e, t, n) {
	let r = { code: "games.godfather.invalid" };
	if (t.type === "tick") {
		if (n.by !== "$engine" || ![
			"between",
			"war",
			"auction",
			"tribute",
			"reset",
			"final"
		].includes(e.phase) || e.phase === "auction" && e.auction.length && e.allies.length) return r;
		let t = structuredClone(e);
		return t.fx = [], De(t), {
			state: t,
			fx: t.fx
		};
	}
	let i = e.players.findIndex((e) => e.rid === n.by);
	if (i < 0) return r;
	if (t.type === "bid") {
		let n = e.players[i];
		if (e.phase !== "bidding" || n.committed || new Set(t.cards).size !== t.cards.length || t.cards.some((e) => !n.suitcase.includes(e) || C[e].kind !== "money")) return r;
	} else if (!Ce(e, n.by).some((e) => j(e, t))) return r;
	let a = structuredClone(e);
	a.fx = [];
	let o = a.players[i];
	if (t.type === "bid") o.bid = [...t.cards], o.committed = !0, a.players.every((e) => e.committed) && (a.auction = a.players.flatMap((e, t) => w(e.bid) > 0 ? [t] : []).sort((e, t) => w(a.players[t].bid) - w(a.players[e].bid) || (e - a.first + a.players.length) % a.players.length - (t - a.first + a.players.length) % a.players.length), a.phase = "auction", a.active = a.auction[0] ?? a.first, N(a, "reveal"));
	else if (t.type === "place") de(a, a.pieces[t.piece], t.slot, i);
	else if (t.type === "ally") o.hand.splice(o.hand.indexOf(t.card), 1), o.used.push(t.card), P(a, `hand:${o.rid}`, `ally:${t.card}`, i, t.card, -1, !0), N(a, "ally", C[t.card].value), be(a, t.card);
	else if (t.type === "job") {
		let e = o.hand.indexOf(t.card);
		e >= 0 ? o.hand.splice(e, 1) : a.publicJobs.splice(a.publicJobs.indexOf(t.card), 1), a.pendingJob = t.card, a.rewardFirst = t.rewardFirst, U(a, A("pay", i, 0, v[C[t.card].value].cost)), P(a, e >= 0 ? `hand:${o.rid}` : `card:${t.card}`, "job-play", i, t.card, -1, !0);
	} else if (t.type === "effect") {
		let e = a.blocks[0], n = e.effects.splice(t.index, 1)[0];
		xe(a, n, e.seat);
	} else t.type === "choose" && (a.phase === "prompt" ? Te(a, t.value) : a.phase === "effects" ? (a.blocks.shift(), H(a)) : a.phase === "tribute" ? (o.hand.splice(o.hand.indexOf(t.value), 1), I(a, t.value), P(a, `hand:${o.rid}`, "supply", i, t.value, -1, !0)) : a.phase === "auction" && (o.bid.forEach((e) => {
		o.suitcase.splice(o.suitcase.indexOf(e), 1), I(a, e);
	}), o.hand.push(t.value), a.allies.splice(a.allies.indexOf(t.value), 1), P(a, `card:${t.value}`, `hand:${o.rid}`, i, t.value, -1, !0), N(a, "bribe", w(o.bid), C[t.value].value, i), a.auction.shift(), a.active = a.auction[0] ?? a.first));
	return {
		state: a,
		fx: a.fx
	};
}
function ke(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.prompt, i = r?.kind === "loot" || r?.kind === "refuseDiscard" ? e.offered : e.pendingJob >= 0 ? [e.pendingJob] : [];
	return {
		public: {
			players: e.players.map((t) => ({
				rid: t.rid,
				handCount: t.hand.length,
				caseCount: t.suitcase.length,
				used: t.used,
				jobs: t.completed.map((e) => v[C[e].value].color),
				bid: [
					"bidding",
					"business",
					"effects",
					"prompt",
					"between",
					"war"
				].includes(e.phase) ? -1 : w(t.bid),
				committed: t.committed,
				final: t.final
			})),
			pieces: e.pieces,
			phase: e.phase,
			active: e.players[ie(e)]?.rid ?? e.players[e.active].rid,
			turn: e.players[e.turn].rid,
			first: e.players[e.first].rid,
			act: e.act,
			turfs: e.turfs,
			businesses: e.businesses,
			publicJobs: e.publicJobs,
			allies: e.allies,
			supply: [...g.map((e) => ({
				kind: "money",
				value: e
			})), ...[
				0,
				1,
				2,
				3
			].map((e) => ({
				kind: "goods",
				value: e
			}))].map((t) => ({
				...t,
				count: e.supply.filter((e) => C[e].kind === t.kind && C[e].value === t.value).length
			})),
			effects: e.blocks[0]?.effects ?? [],
			prompt: r?.kind ?? "",
			target: r?.kind === "neutral" || r?.kind === "destination" || r?.kind === "redeploy" ? r.piece : r?.value ?? -1,
			count: r?.remaining ?? 0,
			revealed: i,
			warTurf: e.warTurf - 1,
			log: e.log
		},
		private: {
			hand: n?.hand ?? [],
			suitcase: n?.suitcase ?? [],
			legal: Ce(e, t),
			bid: n?.bid ?? [],
			offered: r?.seat === e.players.findIndex((e) => e.rid === t) && r.kind === "draw" ? r.cards : []
		}
	};
}
function Ae(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (e) => e.final.reduce((e, t) => e + t, 0), n = [...e.players].sort((e, n) => t(n) - t(e) || n.final[1] - e.final[1]), r = n[0];
	return {
		phase: "done",
		winner: n.filter((e) => t(e) === t(r) && e.final[1] === r.final[1]).map((e) => e.rid),
		ranking: n.map((e) => e.rid),
		scores: Object.fromEntries(n.map((e) => [e.rid, t(e)]))
	};
}
var je = {
	meta: te,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ne,
		publicView: O,
		privateView: k
	},
	setup: oe,
	reduce: Oe,
	viewFor: ke,
	status: Ae,
	nextTickIn: (e) => [
		"between",
		"war",
		"reset",
		"final"
	].includes(e.phase) || e.phase === "tribute" && e.players[e.active].hand.length <= _[e.act - 1] || e.phase === "auction" && (!e.auction.length || !e.allies.length) ? 650 : null
}, Me = {
	name: "教父：柯里昂的帝国",
	desc: "调遣家族、争夺纽约地盘，将财富藏进行李箱。",
	rules: "目标：\n在四幕中通过商铺和任务获利，将钱存进行李箱。终局比较箱内的钱与奖励总额；平局时比较获得地盘奖励的数量，再平局则共同获胜。\n准备：\n2–5 人。每家获得两名打手（两人局三名）、一名教父、九枚控制标记，以及 $1、$2、$3 各一张和两张随机任务。第二幕增加顾问，第四幕增加继承人；三种家族成员能力相同。四人开局在 1 号地盘增加蓝色商铺，五人在 1、2、3 号增加。\n每幕流程：\n每幕依次进行以下步骤：\n· 开设商铺。\n· 进行家族经营。\n· 结算地盘战。\n· 进行贿赂。\n· 向教父进贡。\n· 进行幕间准备。第四幕没有贿赂与幕间准备。\n· 第一、二幕开始在编号最小的空位开设蓝色商铺，第三、四幕开设红色商铺。\n家族经营：\n从马头标记持有者开始，顺时针每人执行一个行动，不能主动跳过。备用区没有自己的棋子时退出本幕，不能再完成任务或使用盟友。所有派遣位置均满且也没有可执行的任务或盟友时，本幕跳过该家族。\n· 打手：放到商铺空前门，使用全部前门能力。该地盘若由另一家控制，对方也使用同样能力，由当前行动玩家决定谁先执行。\n· 家族成员：放到空圆点，使用所有相邻地盘的全部背门能力，自由安排能力顺序。两人局不能使用标有 3+ 的六个圆点。中央公园只提供存钱能力，不能控制。\n· 完成任务：从手中支付指定非法货物，毒品可代替酒、枪或血钱；执行手中或公共任务，领取牌面指定面额的奖金，可以先领奖金或先执行效果。完成的任务放入箱内。公共任务本幕不补充。\n· 盟友：从手中打出一张盟友并执行其能力，每幕一次。用过的盟友在进贡前收回手中，也占手牌上限。中立棋子在执行玩家的当前回合后归为同一中立阵营；被枪杀的棋子本幕不能取回。\n商铺与钱币：\n· 每次存钱能力只能公开存入一张手中的钱；重复图标可分别使用。\n· 抽任务能力为抽两张、选一张、弃掉另一张。\n· 钱币不得换零钱，供应不足时领取下一档较低面额；货物用尽则不领取。\n· 任务堆空时洗入任务弃牌。\n地盘战与贿赂：\n按 1–7 号地盘逐区比较影响力：区内和相邻圆点的每枚棋子各提供一点。唯一最高的家族叠放一枚控制标记；平局或中立最高均不放置，旧控制标记保留。每家只有九枚，用尽时可以从已有叠层中取回一枚再放置，也可以放弃。\n前三幕开始时，各随机展示比玩家人数少一张的本幕盟友牌。各家秘密选择箱内的钱暗拍，可不出钱。按金额从高到低选盟友，平局按当前首家起顺时针。取得盟友者将所出钱币归还供应；未取得者保留出价。不出钱不能取得盟友。\n进贡与幕间：\n收回用过的盟友后，各家弃置超出本幕上限的手牌：第一幕和第二幕的上限为 5 张，第三幕为 6 张，第四幕为 2 张。钱和货物回供应，任务入弃牌，盟友移除。前三幕结束收回城中及河中的棋子，加入本幕解锁成员，补公共任务空位并更换公共盟友。\n终局：\n第四幕进贡后将剩余手钱放入箱内，弃掉其他手牌。每个地盘的标记数量最多者获得 $5，同数时比较叠层中各家最高标记的位置。每种任务颜色数量最多且至少有一张者获得 $5，平局均获得。箱内的其他货物或盟友没有价值。",
	invalid: "这个操作当前不能执行。",
	money: "钱币",
	act: "幕",
	first: "首家",
	hand: "手牌",
	suitcase: "行李箱",
	reserve: "备用区",
	river: "哈德逊河",
	publicJobs: "公共任务",
	allies: "盟友",
	supply: "供应",
	goods: [
		"酒",
		"枪",
		"血钱",
		"毒品"
	],
	kinds: {
		thug: "打手",
		family: "家族成员",
		mayor: "市长",
		union: "工会主席",
		police: "警察局长"
	},
	turfs: [
		"中央公园",
		"华尔街",
		"布鲁克林",
		"上东区",
		"皇后区",
		"上西区",
		"中城区",
		"切尔西"
	],
	businesses: [
		"理发店",
		"韩式洗衣店",
		"赌坊",
		"皇后区商店",
		"上西区酒馆",
		"枪械经销店",
		"会计事务所",
		"贝斯特百货",
		"坚科公司",
		"爱迪生酒店",
		"米茨与韦斯石油",
		"军火库",
		"宾州中央铁路",
		"星尘厅",
		"米茨大楼",
		"联邦储备银行",
		"圣乔治酒店",
		"杰克·登普西餐厅",
		"波尔克爱好商店"
	],
	jobs: [
		"别忘了甜饼",
		"密室交易",
		"无法拒绝",
		"汽车炸弹",
		"敲诈",
		"驾车枪击",
		"勒索",
		"恐吓",
		"强势回归",
		"驱逐"
	],
	jobDetails: [
		"枪杀一名敌方打手。",
		"公开并存入最多三张手钱。",
		"其他各家弃一张手牌；你可选其中一张放入行李箱。",
		"枪杀一个地盘内所有敌方玩家棋子。",
		"执行任意商铺前门能力，即使已有打手。",
		"对最多两个不同玩家各枪杀一枚棋子。",
		"从一家的箱中拿三张钱进手牌，由对方选择。",
		"在一个地盘放置一枚自己的控制标记。",
		"取回城中的一枚自己棋子，立即重新使用。",
		"移动任意一枚棋子至另一合法空位，不执行能力。"
	],
	allyNames: [
		"受雇打手",
		"市长",
		"警察局长",
		"小庄家",
		"税务顾问",
		"工会主席",
		"家族会计",
		"家族士兵",
		"市长",
		"警察局长",
		"警局证物管理员",
		"工会主席",
		"头目",
		"好莱坞制片人",
		"酒店老板",
		"市长",
		"警察局长",
		"工会主席"
	],
	allyDetails: [
		"获得一张 $2。",
		"将市长移到空圆点，执行所有相邻商铺背门。",
		"将警察局长移到一个地盘，把区内任意一枚棋子移出该地盘，放到另一合法空位，不执行能力。",
		"每控制一个地盘，将一张 $1 直接放入箱内。",
		"存入一张手钱。",
		"将工会主席移到空前门，执行该前门一次。",
		"存入最多两张手钱。",
		"获得一张 $3。",
		"将市长移到空圆点，取得一个相邻地盘的控制。",
		"将警察局长移到一个地盘，枪杀区内一枚玩家棋子。",
		"每控制一个地盘，任选酒、枪或血钱一张。",
		"将工会主席移到空前门，执行该前门两次。",
		"获得一张 $5。",
		"每控制一个地盘，获得一张 $5。",
		"存入最多三张手钱。",
		"将市长移到空圆点，执行背门并取得一个相邻地盘的控制。",
		"将警察局长移到一个地盘，枪杀区内所有敌方玩家棋子。",
		"将工会主席移到空前门，执行该前门三次。"
	],
	colors: [
		"黄色任务",
		"蓝色任务",
		"绿色任务",
		"灰色任务"
	],
	phases: {
		business: "家族经营",
		effects: "执行能力",
		prompt: "选择目标",
		between: "行动结算",
		war: "地盘战",
		bidding: "秘密出价",
		auction: "选择盟友",
		tribute: "向教父进贡",
		reset: "幕间准备",
		final: "清点财富",
		done: "纽约的新主人"
	},
	prompts: {
		pay: "支付任务所需的货物",
		draw: "选择一张任务",
		bank: "选择一张手钱存入箱内",
		exchange: "选择要弃掉的手牌",
		refuseDiscard: "弃一张手牌",
		loot: "选择一张弃牌放入箱内",
		good: "选择一种货物",
		frontOrder: "决定谁先执行前门能力",
		neutral: "选择中立棋子的落点",
		shakedown: "选择一间商铺",
		shootThug: "选择要枪杀的敌方打手",
		drive: "选择另一个玩家的棋子",
		bomb: "选择汽车炸弹的目标地盘",
		policeMove: "选择区内要移动的棋子",
		policeKill: "选择区内要枪杀的玩家棋子",
		control: "选择要控制的地盘",
		recycle: "选择取回标记的地盘",
		reuse: "选择自己要重新使用的棋子",
		move: "选择要移动的棋子",
		destination: "选择新的落点",
		redeploy: "立即重新放置棋子",
		extort: "选择要勒索的家族",
		extortMoney: "选择交给对方的钱"
	},
	effects: {
		money: "领取钱币",
		caseMoney: "将钱直接放入箱内",
		goods: "领取货物",
		reward: "领取任务奖金",
		draw: "抽两张任务并保留一张",
		bank: "存入手钱",
		exchange: "弃牌换钱",
		exchangeGood: "弃牌换货物",
		chooseGood: "选择货物",
		refuse: "执行无法拒绝",
		shootThug: "枪杀敌方打手",
		drive: "执行驾车枪击",
		bomb: "执行汽车炸弹",
		control: "放置控制标记",
		reuse: "重新使用棋子",
		move: "移动棋子",
		extort: "勒索钱币",
		shakedown: "敲诈商铺",
		first: "取得马头标记"
	},
	front: "前门",
	back: "背门",
	empty: "空位",
	selected: "已选",
	choose: "选择",
	confirm: "确认",
	close: "关闭",
	detail: "详情",
	skip: "放弃剩余能力",
	decline: "不使用",
	rewardFirst: "先领取奖金",
	effectFirst: "先执行效果",
	playJob: "完成任务",
	playAlly: "使用盟友",
	waiting: "等待",
	caseHidden: "箱内卡牌",
	bid: "出价",
	sealBid: "封存出价",
	committed: "已封存",
	noBid: "不出钱",
	actionFirst: "行动者先",
	controllerFirst: "控制者先",
	noCards: "没有卡牌",
	fit: "全景",
	log: "事件记录",
	control: "控制",
	influence: "影响力",
	total: "总额",
	cash: "箱内钱币",
	dominance: "地盘奖励",
	scoreItem: "计分项目",
	finalTitle: "纽约的家族账簿",
	review: "回看最终城市",
	backToResult: "返回账簿",
	confirmReplay: "确认再来一局",
	confirmLobby: "确认返回大厅",
	logEvents: {
		place: "派出棋子",
		control: "取得地盘控制",
		kill: "枪杀棋子",
		bank: "存入钱币",
		job: "完成任务",
		ally: "使用盟友",
		reveal: "揭晓贿赂出价",
		bribe: "贿赂盟友",
		act: "开始新的一幕",
		final: "清点最终财富",
		war: "结算地盘",
		first: "取得马头标记"
	}
}, Ne = {
	name: "The Godfather: Corleone’s Empire",
	desc: "Deploy your family, control New York, and hide your fortune in a suitcase.",
	rules: "Goal:\nAfter four Acts, win with the most money in your Suitcase plus bonuses. Break a tie by the number of Turf Dominance Bonuses; a further tie is a shared victory.\nSetup:\nFor 2–5 players. Each Family starts with two Thugs (three with two players), one Don, nine Control markers, one $1, $2 and $3 card, and two random Jobs. Add the Consigliere in Act II and the Heir in Act IV. All Family Members have the same abilities. Start an extra Blue Business in Turf 1 with four players, or Turfs 1, 2 and 3 with five.\nEach Act:\nComplete these steps in order:\n· Open a Business.\n· Conduct Family Business.\n· Resolve Turf Wars.\n· Bribe Allies.\n· Pay Tribute.\n· Prepare the next Act. Act IV has no Bribery or Entr’acte. Open a Blue Business in Acts I–II or a Red one in Acts III–IV, in the lowest-numbered empty Business space.\nFamily Business:\nStarting with the Horse Head holder, take one action clockwise. You cannot pass voluntarily. Once no Family figures remain in your reserve, you leave the Act and cannot complete Jobs or play Allies. A Family with no legal placement, Job or Ally action is skipped for this Act.\n· Thug: occupy an empty Business Front and use all its abilities. If another Family controls its Turf, that Family uses the same abilities; the active player chooses who goes first.\n· Family Member: occupy an empty round space and use all the Backs of every Business in all adjacent Turfs, in any order. Six spaces marked 3+ are unavailable with two players. Central Park only offers a Suitcase ability and cannot be controlled.\n· Job: discard its required Illegal Goods from your hand. Narcotics can replace Booze, Guns or Blood Money. Complete a Job from your hand or the public display, taking its exact Money cards and executing its effect, in either order. Place the completed Job in your Suitcase. Public Jobs are not replenished during an Act.\n· Ally: play an Ally from your hand and use its ability once per Act. Played Allies return to your hand before Tribute and count toward the hand limit. Neutral figures form a single neutral faction after the acting player’s turn. Gunned-down figures cannot return before the next Act.\nBusinesses and Money:\nEach Suitcase icon lets you reveal and bank one Money card from your hand. Repeated icons can be used separately. A Job draw means draw two, keep one, discard the other. Never make change. If a Money pile is empty, take the next lower available denomination. Empty Goods piles give nothing; recycle discarded Jobs when their deck is empty.\nTurf Wars and Bribery:\nResolve Turfs 1–7. Each figure in a Turf or on an adjacent round space has one Influence. The unique leading Family places a Control marker on the stack. Ties and a neutral lead place none; older markers remain. A Family has only nine markers; when depleted, it may reuse one from an existing stack or decline.\nIn each of the first three Acts, display player count minus one random Allies for that Act. Secretly select Money cards from your Suitcase, including none. Choose Allies in descending bid order, breaking ties clockwise from the first player. Only winners pay their exact cards to the supply. Losing bids remain in the Suitcase; zero bids cannot take Allies.\nTribute and Entr’acte:\nReturn played Allies, then discard to at most 5, 5, 6 or 2 hand cards in Acts I–IV. Money and Goods return to supply, Jobs are discarded, Allies leave the game. Between Acts, recover all figures from the city and river, unlock the new Family Member, replenish missing Public Jobs and change the Ally display.\nFinal accounting:\nAfter Act IV Tribute, bank remaining hand Money and discard other hand cards. Each Turf awards $5 to the Family with the most markers, breaking ties by whose highest marker is higher in the stack. Each Job colour awards $5 to every tied leader with at least one card. Other Goods and Allies in a Suitcase have no value.",
	invalid: "That action is not available now.",
	money: "Money",
	act: "Act",
	first: "First",
	hand: "Hand",
	suitcase: "Suitcase",
	reserve: "Reserve",
	river: "Hudson River",
	publicJobs: "Public Jobs",
	allies: "Allies",
	supply: "Supply",
	goods: [
		"Booze",
		"Guns",
		"Blood Money",
		"Narcotics"
	],
	kinds: {
		thug: "Thug",
		family: "Family Member",
		mayor: "Mayor",
		union: "Union Boss",
		police: "Police Chief"
	},
	turfs: [
		"Central Park",
		"Wall Street",
		"Brooklyn",
		"Upper East Side",
		"Queens",
		"Upper West Side",
		"Midtown",
		"Chelsea"
	],
	businesses: [
		"Barbershop",
		"Korean Laundry",
		"Gambling Den",
		"Queens Store",
		"West Side Tavern",
		"Gun Dealership",
		"Accounting Office",
		"Best & Co. Dept Store",
		"Genco",
		"Hotel Edison",
		"Mietz & Weiss Oil",
		"Munitions",
		"Penn Central Railroad",
		"The Stardust Room",
		"The Mietz Building",
		"Federal Reserve",
		"Hotel St. George",
		"Jack Dempsey’s",
		"Polk’s Hobby Shop"
	],
	jobs: [
		"…Take the Cannoli",
		"Backroom Deal",
		"Can’t Refuse",
		"Car Bomb",
		"Shakedown",
		"Drive-by Shooting",
		"Extortion",
		"Intimidation",
		"Muscle In",
		"Muscled Out"
	],
	jobDetails: [
		"Gun down one enemy Thug.",
		"Reveal and bank up to three Money cards from your hand.",
		"Other players discard one card each; choose up to one to Suitcase.",
		"Gun down all enemy player figures in one Turf.",
		"Use any Business Front, even if occupied.",
		"Gun down one figure from each of up to two different players.",
		"Take three Money cards from one Suitcase into your hand; their owner chooses.",
		"Place one of your Control markers on one Turf.",
		"Retrieve one of your city figures and immediately use it again.",
		"Move any figure to another legal empty space without its abilities."
	],
	allyNames: [
		"Hired Muscle",
		"Mayor",
		"Police Chief",
		"Small-Time Bookie",
		"Tax Advisor",
		"Union Boss",
		"Family Accountant",
		"Family Soldier",
		"Mayor",
		"Police Chief",
		"Police Evidence Manager",
		"Union Boss",
		"Capo",
		"Hollywood Producer",
		"Hotel Owner",
		"Mayor",
		"Police Chief",
		"Union Boss"
	],
	allyDetails: [
		"Gain one $2 card.",
		"Move the Mayor to an empty round space and use all adjacent Backs.",
		"Move the Police Chief to a Turf, then move any figure there out of that Turf to another legal empty space without abilities.",
		"For each controlled Turf, add one $1 directly to your Suitcase.",
		"Bank one hand Money card.",
		"Move the Union Boss to an empty Front and use it once.",
		"Bank up to two hand Money cards.",
		"Gain one $3 card.",
		"Move the Mayor to an empty round space and control one adjacent Turf.",
		"Move the Police Chief to a Turf and gun down one player figure there.",
		"For each controlled Turf, choose one Booze, Guns or Blood Money.",
		"Move the Union Boss to an empty Front and use it twice.",
		"Gain one $5 card.",
		"Gain one $5 for each controlled Turf.",
		"Bank up to three hand Money cards.",
		"Move the Mayor to an empty round space, use the Backs and control one adjacent Turf.",
		"Move the Police Chief to a Turf and gun down all enemy player figures there.",
		"Move the Union Boss to an empty Front and use it three times."
	],
	colors: [
		"Yellow Jobs",
		"Blue Jobs",
		"Green Jobs",
		"Gray Jobs"
	],
	phases: {
		business: "Family Business",
		effects: "Use abilities",
		prompt: "Choose a target",
		between: "Resolve action",
		war: "Turf Wars",
		bidding: "Secret Bribes",
		auction: "Choose an Ally",
		tribute: "Tribute to the Don",
		reset: "Entr’acte",
		final: "Count the fortune",
		done: "New York’s new ruler"
	},
	prompts: {
		pay: "Pay the required Illegal Goods",
		draw: "Keep one Job",
		bank: "Choose a hand Money card to bank",
		exchange: "Choose a hand card to discard",
		refuseDiscard: "Discard one hand card",
		loot: "Choose a discarded card to Suitcase",
		good: "Choose an Illegal Good",
		frontOrder: "Choose who uses the Front first",
		neutral: "Choose the neutral figure’s space",
		shakedown: "Choose a Business",
		shootThug: "Choose an enemy Thug to gun down",
		drive: "Choose a figure from another player",
		bomb: "Choose the Car Bomb’s Turf",
		policeMove: "Choose a figure in the Turf to move",
		policeKill: "Choose a player figure in the Turf to gun down",
		control: "Choose a Turf to control",
		recycle: "Choose a Turf to retrieve your marker from",
		reuse: "Choose your figure to use again",
		move: "Choose a figure to move",
		destination: "Choose its new space",
		redeploy: "Immediately place the figure again",
		extort: "Choose a Family to extort",
		extortMoney: "Choose Money to give the other Family"
	},
	effects: {
		money: "Take Money",
		caseMoney: "Add Money to Suitcase",
		goods: "Take Illegal Goods",
		reward: "Take Job rewards",
		draw: "Draw two Jobs and keep one",
		bank: "Bank hand Money",
		exchange: "Discard for Money",
		exchangeGood: "Discard for Illegal Goods",
		chooseGood: "Choose Illegal Goods",
		refuse: "Execute Can’t Refuse",
		shootThug: "Gun down an enemy Thug",
		drive: "Execute Drive-by Shooting",
		bomb: "Execute Car Bomb",
		control: "Place a Control marker",
		reuse: "Use a figure again",
		move: "Move a figure",
		extort: "Extort Money",
		shakedown: "Shake down a Business",
		first: "Take the Horse Head"
	},
	front: "Front",
	back: "Back",
	empty: "Empty",
	selected: "Selected",
	choose: "Choose",
	confirm: "Confirm",
	close: "Close",
	detail: "Details",
	skip: "Decline remaining abilities",
	decline: "Decline",
	rewardFirst: "Money first",
	effectFirst: "Effect first",
	playJob: "Complete Job",
	playAlly: "Play Ally",
	waiting: "Waiting",
	caseHidden: "Suitcase cards",
	bid: "Bribe",
	sealBid: "Seal bribe",
	committed: "Sealed",
	noBid: "No bribe",
	actionFirst: "Acting player first",
	controllerFirst: "Controller first",
	noCards: "No cards",
	fit: "Overview",
	log: "Event log",
	control: "Control",
	influence: "Influence",
	total: "Total",
	cash: "Suitcase Money",
	dominance: "Turf bonuses",
	scoreItem: "Item",
	finalTitle: "The Family Ledger",
	review: "Review the final city",
	backToResult: "Back to ledger",
	confirmReplay: "Confirm another game",
	confirmLobby: "Confirm return to lobby",
	logEvents: {
		place: "Deployed a figure",
		control: "Gained control",
		kill: "Gunned down a figure",
		bank: "Banked Money",
		job: "Completed a Job",
		ally: "Played an Ally",
		reveal: "Revealed bribes",
		bribe: "Bribed an Ally",
		act: "Started a new Act",
		final: "Counted final fortune",
		war: "Resolved Turf",
		first: "Took the Horse Head"
	}
}, W = () => l((e) => e.locale) === "zh" ? Me : Ne, Pe = (e) => `games/godfather/portrait-${e}.svg`, Fe = [
	"#d1ae53",
	"#6b93a0",
	"#73977a",
	"#a4a09a"
];
function G({ value: e }) {
	return /* @__PURE__ */ p("svg", {
		className: "gf-good-icon",
		viewBox: "0 0 56 66",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("rect", {
				x: "2",
				y: "2",
				width: "52",
				height: "62",
				rx: "2",
				fill: "#21231f",
				stroke: [
					"#d3b35d",
					"#b5b5aa",
					"#5c896b",
					"#c8b967"
				][e],
				strokeWidth: "3"
			}),
			e === 0 && /* @__PURE__ */ p("g", {
				transform: "rotate(25 28 33)",
				fill: "none",
				stroke: "#e8e1ce",
				strokeWidth: "1.8",
				children: [/* @__PURE__ */ f("path", { d: "M23 10h10v16l5 8v23H18V34l5-8z" }), /* @__PURE__ */ f("path", { d: "M23 15h10M18 41h20M22 47h12" })]
			}),
			e === 1 && /* @__PURE__ */ p("g", {
				transform: "rotate(-38 28 33)",
				fill: "#dfdbc9",
				children: [/* @__PURE__ */ f("path", { d: "M25 5h5v29h8v5h-8v6l6 13h-11l-1-20h-5v-6h6z" }), /* @__PURE__ */ f("path", { d: "M21 22h10v3H21zM30 34h13v3H30z" })]
			}),
			e === 2 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("g", {
				transform: "rotate(-22 28 30)",
				fill: "none",
				stroke: "#e2ddc9",
				strokeWidth: "1.6",
				children: [
					/* @__PURE__ */ f("rect", {
						x: "11",
						y: "16",
						width: "30",
						height: "17"
					}),
					/* @__PURE__ */ f("rect", {
						x: "15",
						y: "29",
						width: "30",
						height: "17"
					}),
					/* @__PURE__ */ f("path", { d: "M18 21h16M23 38h14" }),
					/* @__PURE__ */ f("ellipse", {
						cx: "27",
						cy: "25",
						rx: "3",
						ry: "5"
					}),
					/* @__PURE__ */ f("ellipse", {
						cx: "32",
						cy: "38",
						rx: "3",
						ry: "5"
					})
				]
			}), /* @__PURE__ */ f("path", {
				d: "M11 42l6-1 3 7 6 3-2 8-8-3-7-8z",
				fill: "#963e37"
			})] }),
			e === 3 && /* @__PURE__ */ p("g", {
				fill: "none",
				stroke: "#e2d7a7",
				strokeWidth: "1.7",
				transform: "rotate(27 28 33)",
				children: [
					/* @__PURE__ */ f("path", { d: "M25 5v8m-5 0h16M24 15h9v25h-9zM20 41h17M28 42v17M22 28h11" }),
					/* @__PURE__ */ f("ellipse", {
						cx: "28",
						cy: "11",
						rx: "7",
						ry: "3"
					}),
					/* @__PURE__ */ f("path", { d: "M17 47q-13 12-2 14t22-17" })
				]
			})
		]
	});
}
function K({ value: e }) {
	return /* @__PURE__ */ p("span", {
		className: "gf-coin",
		"data-value": e,
		children: ["$", e]
	});
}
function q({ kind: e, color: t = "#b4a382" }) {
	return /* @__PURE__ */ p("svg", {
		className: "gf-pawn",
		viewBox: "0 0 60 84",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("path", {
				d: e === "thug" || e === "union" ? "M8 70h44v11H8z" : "M5 77a25 7 0 1 0 50 0 25 7 0 1 0-50 0",
				fill: t,
				stroke: "#23221e",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ p("g", {
				fill: t,
				stroke: "#292620",
				strokeWidth: "1.7",
				strokeLinejoin: "round",
				children: [
					/* @__PURE__ */ f("path", { d: "M20 14l2-8h17l3 8 6 3H14z" }),
					/* @__PURE__ */ f("path", { d: "M22 18h17l-1 12-8 5-8-7z" }),
					/* @__PURE__ */ f("path", { d: "M20 32l9 6 10-6 8 9-4 24-6 4-1 8h-9l-2-16-2 16h-9l3-16-5-6 1-17z" }),
					/* @__PURE__ */ f("path", { d: "M24 35l5 16 7-16M29 39v20" })
				]
			}),
			(e === "thug" || e === "union") && /* @__PURE__ */ f("path", {
				d: "M14 46l37-5 2 5-14 3-4 9-5-2 2-6-17 2z",
				fill: "#242725",
				stroke: "#b2ab91"
			}),
			e === "police" && /* @__PURE__ */ f("path", {
				d: "M32 40l5 3-1 7-4 2-4-3v-6z",
				fill: "#dfc078"
			}),
			e === "mayor" && /* @__PURE__ */ f("path", {
				d: "M13 57h20v14H13z",
				fill: "#6b4430",
				stroke: "#dbc9a5"
			})
		]
	});
}
function J({ id: e, detailed: t = !1 }) {
	let n = W(), r = C[e];
	if (r.kind === "money") return /* @__PURE__ */ p("span", {
		className: "gf-money-face",
		"data-value": r.value,
		children: [
			/* @__PURE__ */ f("small", { children: n.money }),
			/* @__PURE__ */ p("b", { children: ["$", r.value] }),
			/* @__PURE__ */ f("span", { children: "✧ ─ ✧" })
		]
	});
	if (r.kind === "goods") return /* @__PURE__ */ p("span", {
		className: "gf-goods-face",
		children: [/* @__PURE__ */ f(G, { value: r.value }), /* @__PURE__ */ f("strong", { children: n.goods[r.value] })]
	});
	let i = r.kind === "job" ? v[r.value] : null;
	return /* @__PURE__ */ p("span", {
		className: "gf-card-face",
		style: { "--gf-category": i ? Fe[i.color] : "#b79a66" },
		children: [
			/* @__PURE__ */ f("strong", {
				className: "gf-card-title",
				children: i ? n.jobs[r.value] : n.allyNames[r.value]
			}),
			/* @__PURE__ */ f("span", {
				className: "gf-portrait",
				children: /* @__PURE__ */ f("img", {
					src: Pe(i ? 0 : r.value + 1),
					alt: "",
					draggable: !1
				})
			}),
			i ? /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("span", {
					className: "gf-card-cost",
					children: i.cost.map((e, t) => /* @__PURE__ */ f(G, { value: e }, t))
				}),
				/* @__PURE__ */ f("span", {
					className: "gf-card-description",
					children: n.jobDetails[r.value]
				}),
				/* @__PURE__ */ f("span", {
					className: "gf-card-reward",
					children: i.reward.map((e, t) => /* @__PURE__ */ f(K, { value: e }, t))
				})
			] }) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("small", { children: [
				n.act,
				" ",
				Math.floor(r.value / 6) + 1
			] }), /* @__PURE__ */ f("span", {
				className: "gf-card-description",
				children: n.allyDetails[r.value]
			})] }),
			t && i && /* @__PURE__ */ f("small", { children: n.colors[i.color] })
		]
	});
}
function Y({ effect: e, w: t }) {
	return /* @__PURE__ */ p("span", {
		className: "gf-effect-face",
		children: [
			/* @__PURE__ */ f("span", { children: t.effects[e.kind] ?? e.kind }),
			e.kind === "goods" && /* @__PURE__ */ f(G, { value: e.value ?? 0 }),
			(e.kind === "money" || e.kind === "caseMoney") && /* @__PURE__ */ f(K, { value: e.value ?? 0 }),
			e.kind === "bank" && /* @__PURE__ */ p("b", { children: ["▣ ", e.value] }),
			e.extra && ["reward", "exchange"].includes(e.kind) && e.extra.map((e, t) => /* @__PURE__ */ f(K, { value: e }, t)),
			(e.kind === "exchange" || e.kind === "exchangeGood") && /* @__PURE__ */ p("small", { children: [e.value, " ▱"] })
		]
	});
}
//#endregion
//#region src/games/godfather/view-player.tsx
function X({ name: e, children: t, className: n }) {
	let { ref: i, hidden: a } = r(e);
	return /* @__PURE__ */ f("div", {
		ref: i,
		className: n,
		style: { visibility: a ? "hidden" : void 0 },
		children: t
	});
}
function Ie() {
	return /* @__PURE__ */ f("svg", {
		className: "gf-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "5",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "6 4",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ f("animate", {
				attributeName: "stroke-dashoffset",
				from: "20",
				to: "0",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
var Z = (e, t) => {
	if (e >= 200) {
		let t = x[e - 201];
		return {
			x: t.x * 10 + 45,
			y: t.y * 10 - 100,
			w: 48,
			h: 60
		};
	}
	if (e >= 100) {
		let t = b[e - 100];
		return {
			x: t.x * 10 - 24,
			y: t.y * 10 - 24,
			w: 48,
			h: 48
		};
	}
	let n = t.businesses.find((t) => t.id === e), r = x[n.turf - 1], i = t.businesses.filter((e) => e.turf === n.turf), a = i.length === 1 ? 0 : i.indexOf(n) === 0 ? -65 : 65;
	return {
		x: r.x * 10 - 57 + a,
		y: r.y * 10 - 48,
		w: 114,
		h: 115
	};
};
function Le({ pub: e, members: t, actions: r = [], selectedPiece: a = -1, onAction: c, onInspect: l }) {
	let u = W(), [d, ee] = n(0), m = (n) => n < 0 ? "" : t.find((t) => t.rid === e.players[n]?.rid)?.name ?? e.players[n]?.rid ?? "", h = (n) => n < 0 ? "#b2a791" : i[(t.find((t) => t.rid === e.players[n].rid)?.colorIndex ?? 0) % i.length].hex, g = [], _ = [
		"shootThug",
		"drive",
		"policeMove",
		"policeKill",
		"reuse",
		"move"
	].includes(e.prompt), v = [
		"bomb",
		"control",
		"recycle"
	].includes(e.prompt);
	r.forEach((t, n) => {
		if (t.type === "place" && t.piece === a && g.push({
			key: `a${n}`,
			rect: Z(t.slot, e),
			action: t
		}), !(t.type !== "choose" || t.value < 0) && ([
			"neutral",
			"destination",
			"redeploy"
		].includes(e.prompt) && g.push({
			key: `a${n}`,
			rect: Z(t.value, e),
			action: t
		}), e.prompt === "shakedown" && g.push({
			key: `a${n}`,
			rect: Z(t.value, e),
			action: t
		}), _ && g.push({
			key: `a${n}`,
			rect: Z(e.pieces[t.value].slot, e),
			action: t
		}), v)) {
			let e = x[t.value - 1];
			g.push({
				key: `a${n}`,
				rect: {
					x: e.x * 10 - 35,
					y: e.y * 10 - 105,
					w: 70,
					h: 42
				},
				action: t
			});
		}
	});
	let S = g.length ? g : e.businesses.map((t) => ({
		key: `b${t.id}`,
		rect: Z(t.id, e)
	}));
	return /* @__PURE__ */ p("section", {
		className: "gf-city",
		children: [
			/* @__PURE__ */ p(s, {
				sheetW: 1e3,
				sheetH: 1e3,
				image: "games/godfather/board.svg",
				fitKey: `${d}`,
				clampToSheet: !0,
				eligible: S,
				highlight: g.length ? "inset" : "off",
				onTapEligible: (e) => {
					let t = g.find((t) => t.key === e);
					t ? c?.(t.action) : e.startsWith("b") && l?.(Number(e.slice(1)));
				},
				children: [
					x.map((t, n) => /* @__PURE__ */ p("g", { children: [
						/* @__PURE__ */ p("text", {
							x: t.x * 10,
							y: t.y * 10 - 115,
							textAnchor: "middle",
							className: "gf-map-label",
							children: [
								n + 1,
								" · ",
								u.turfs[n + 1]
							]
						}),
						/* @__PURE__ */ p("g", {
							transform: `translate(${t.x * 10 - 35} ${t.y * 10 - 104})`,
							children: [
								/* @__PURE__ */ f("rect", {
									width: "70",
									height: "40",
									rx: "4",
									fill: "#191d1c",
									stroke: "#b69b6b"
								}),
								e.turfs[n].map((e, t) => /* @__PURE__ */ f("rect", {
									x: 4 + t * 6,
									y: 9 - t * .3,
									width: "14",
									height: "25",
									rx: "2",
									fill: h(e),
									stroke: "#191d1c"
								}, t)),
								/* @__PURE__ */ f("text", {
									x: "35",
									y: "29",
									textAnchor: "middle",
									className: "gf-map-owner",
									children: m(e.turfs[n].at(-1) ?? -1)
								})
							]
						}),
						/* @__PURE__ */ f(o, {
							name: `turf:${n + 1}`,
							r: {
								x: t.x * 10 - 35,
								y: t.y * 10 - 105,
								w: 70,
								h: 42
							}
						}),
						/* @__PURE__ */ f(o, {
							name: `slot:${n + 201}`,
							r: Z(n + 201, e)
						})
					] }, n)),
					/* @__PURE__ */ f("text", {
						x: "440",
						y: "244",
						textAnchor: "middle",
						className: "gf-park-label",
						children: u.turfs[0]
					}),
					b.map((t, n) => {
						let r = t.min <= e.players.length;
						return /* @__PURE__ */ p("g", {
							opacity: r ? 1 : .25,
							children: [
								/* @__PURE__ */ f("circle", {
									cx: t.x * 10,
									cy: t.y * 10,
									r: "25",
									fill: "#b4a68a",
									stroke: "#eee5cb",
									strokeWidth: "3"
								}),
								/* @__PURE__ */ f("text", {
									x: t.x * 10,
									y: t.y * 10 + 7,
									textAnchor: "middle",
									fontSize: "18",
									fill: "#272a26",
									children: t.min === 3 ? "3+" : "●"
								}),
								/* @__PURE__ */ f(o, {
									name: `slot:${100 + n}`,
									r: Z(100 + n, e)
								})
							]
						}, n);
					}),
					e.businesses.map((t) => {
						let n = Z(t.id, e), r = y[t.id];
						return /* @__PURE__ */ p("g", { children: [
							/* @__PURE__ */ f("rect", {
								x: n.x,
								y: n.y,
								width: n.w,
								height: n.h,
								fill: "#ddd1b7",
								stroke: r.grade === 2 ? "#9c4439" : r.grade === 1 ? "#527f96" : "#9d8860",
								strokeWidth: "5"
							}),
							/* @__PURE__ */ f("text", {
								x: n.x + n.w / 2,
								y: n.y + 15,
								textAnchor: "middle",
								fontSize: "12",
								fill: "#29241b",
								children: u.businesses[t.id]
							}),
							/* @__PURE__ */ f("g", {
								transform: `translate(${n.x + 8} ${n.y + 22})`,
								children: r.back.map((e, t) => /* @__PURE__ */ f(Re, {
									e,
									x: t * 31
								}, t))
							}),
							/* @__PURE__ */ f("path", {
								d: `M${n.x + 5} ${n.y + 54}h${n.w - 10}`,
								stroke: "#80745c"
							}),
							/* @__PURE__ */ f("g", {
								transform: `translate(${n.x + 8} ${n.y + 65})`,
								children: r.front.map((e, t) => /* @__PURE__ */ f(Re, {
									e,
									x: t * 31
								}, t))
							}),
							/* @__PURE__ */ f("rect", {
								x: n.x + n.w - 30,
								y: n.y + n.h - 29,
								width: "24",
								height: "24",
								fill: "#8c8068",
								stroke: "#f0e6cf"
							}),
							/* @__PURE__ */ f(o, {
								name: `slot:${t.id}`,
								r: n
							})
						] }, t.id);
					}),
					e.pieces.filter((e) => e.slot >= 0).map((t) => {
						let n = Z(t.slot, e), r = t.slot < 100 ? n.x + n.w - 36 : n.x - 1, i = t.slot < 100 ? n.y + n.h - 57 : n.y - 26;
						return /* @__PURE__ */ f("g", { children: /* @__PURE__ */ f("foreignObject", {
							x: r,
							y: i,
							width: "50",
							height: "74",
							children: /* @__PURE__ */ f(X, {
								name: `piece:${t.id}`,
								className: "gf-map-pawn",
								children: /* @__PURE__ */ f("span", {
									title: `${m(t.owner)} ${u.kinds[t.kind]}`,
									children: /* @__PURE__ */ f(q, {
										kind: t.kind,
										color: h(t.owner)
									})
								})
							})
						}) }, t.id);
					})
				]
			}),
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "gf-fit",
				onClick: () => ee(d + 1),
				children: u.fit
			}),
			/* @__PURE__ */ p(X, {
				name: "river",
				className: "gf-river",
				children: [/* @__PURE__ */ f("span", { children: u.river }), e.pieces.filter((e) => e.slot === -2).map((e) => /* @__PURE__ */ f(X, {
					name: `piece:${e.id}`,
					children: /* @__PURE__ */ f("span", {
						title: `${m(e.owner)} ${u.kinds[e.kind]}`,
						children: /* @__PURE__ */ f(q, {
							kind: e.kind,
							color: h(e.owner)
						})
					})
				}, e.id))]
			})
		]
	});
}
function Re({ e, x: t }) {
	return /* @__PURE__ */ f("g", {
		transform: `translate(${t} 0)`,
		children: e.kind === "goods" ? /* @__PURE__ */ f("foreignObject", {
			width: "26",
			height: "30",
			children: /* @__PURE__ */ f(G, { value: e.value ?? 0 })
		}) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("rect", {
			width: "26",
			height: "27",
			rx: "2",
			fill: e.kind === "bank" ? "#9d753d" : "#f3ead7",
			stroke: "#766345"
		}), /* @__PURE__ */ f("text", {
			x: "13",
			y: "19",
			fontSize: "16",
			fontWeight: "bold",
			textAnchor: "middle",
			fill: "#282a23",
			children: e.kind === "money" ? `$${e.value}` : e.kind === "bank" ? "▣" : e.kind === "draw" ? "▱" : e.kind === "first" ? "♞" : "⇄"
		})] })
	});
}
function Q({ id: e, onClick: t, legal: n = !1, selected: i = !1 }) {
	let { ref: a, hidden: o } = r(`card:${e}`);
	return /* @__PURE__ */ p("button", {
		ref: a,
		type: "button",
		className: "gf-card",
		"data-selected": i || void 0,
		style: { visibility: o ? "hidden" : void 0 },
		onClick: t,
		children: [/* @__PURE__ */ f(J, { id: e }), n && /* @__PURE__ */ f(Ie, {})]
	});
}
function ze(e) {
	a();
	let t = e.public, r = e.private, o = W(), s = r?.legal ?? [], l = t.players.find((t) => t.rid === e.myRid), [u, ee] = n(-1), [m, h] = n(null), [g, v] = n(null), [x, S] = n("hand"), [te, T] = n([]), [ne, re] = n(!1), [E, D] = n(null), O = (t) => e.members.find((e) => e.rid === t)?.name ?? t, k = (t) => i[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % i.length].hex, A = (t) => {
		e.send(t), D(null), h(null), ee(-1);
	}, j = (e) => s.find((t) => t.type === "choose" && t.value === e), ie = (e) => s.find((t) => (t.type === "job" || t.type === "ally") && t.card === e), M = [
		"pay",
		"bank",
		"exchange",
		"refuseDiscard"
	].includes(t.prompt) || t.phase === "tribute", N = t.prompt === "extortMoney", P = t.pieces.find((n) => n.id === u && n.slot === -1 && t.players[n.owner]?.rid === e.myRid), F = x === "case" || N || t.phase === "bidding" ? r?.suitcase ?? [] : r?.hand ?? [], I = te.filter((e) => r?.suitcase.includes(e) && C[e].kind === "money"), L = t.phase === "prompt" ? o.prompts[t.prompt] : o.phases[t.phase], ae = (e) => e >= 200 ? o.turfs[e - 200] : e >= 100 ? b[e - 100].turfs.map((e) => o.turfs[e]).join(" · ") : o.businesses[e], R = E?.type === "choose" && [
		"shootThug",
		"drive",
		"policeMove",
		"policeKill",
		"reuse",
		"move"
	].includes(t.prompt) ? t.pieces[E.value] : void 0, oe = (e) => {
		let n = j(e);
		if ((M || N) && n) {
			A(n);
			return;
		}
		if (t.phase === "bidding" && C[e].kind === "money" && s.length) {
			T((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
			return;
		}
		h(e);
	}, z = /* @__PURE__ */ p("div", {
		className: "gf-personal",
		children: [/* @__PURE__ */ p("div", {
			className: "gf-tray-head",
			children: [
				/* @__PURE__ */ p("button", {
					type: "button",
					"aria-pressed": x === "hand",
					onClick: () => S("hand"),
					children: [
						o.hand,
						" ",
						r?.hand.length ?? 0
					]
				}),
				/* @__PURE__ */ f(X, {
					name: `case:${e.myRid}`,
					children: /* @__PURE__ */ p("button", {
						type: "button",
						"aria-pressed": x === "case",
						onClick: () => S("case"),
						children: [
							o.suitcase,
							" $",
							w(r?.suitcase ?? [])
						]
					})
				}),
				t.phase === "bidding" && s.length > 0 && /* @__PURE__ */ p("button", {
					type: "button",
					className: "gf-primary",
					onClick: () => {
						A({
							type: "bid",
							cards: I
						}), T([]);
					},
					children: [
						o.sealBid,
						" $",
						w(I)
					]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => re(!0),
					children: o.log
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "gf-tray-body",
			children: [
				/* @__PURE__ */ f(X, {
					name: `reserve:${e.myRid}`,
					className: "gf-reserve",
					children: t.pieces.filter((n) => n.owner >= 0 && t.players[n.owner]?.rid === e.myRid && n.slot === -1).map((t) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "gf-piece",
						"aria-label": o.kinds[t.kind],
						"aria-pressed": P?.id === t.id,
						onClick: () => ee(u === t.id ? -1 : t.id),
						children: [
							/* @__PURE__ */ f(q, {
								kind: t.kind,
								color: k(e.myRid)
							}),
							/* @__PURE__ */ f("small", { children: o.kinds[t.kind] }),
							s.some((e) => e.type === "place" && e.piece === t.id) && /* @__PURE__ */ f(Ie, {})
						]
					}, t.id))
				}),
				/* @__PURE__ */ f(X, {
					name: `hand:${e.myRid}`,
					className: "gf-hand-anchor",
					children: /* @__PURE__ */ p("div", {
						className: "gf-hand",
						children: [F.map((e) => /* @__PURE__ */ f(Q, {
							id: e,
							selected: t.phase === "bidding" && I.includes(e),
							legal: !!((M || N) && j(e)) || !!ie(e),
							onClick: () => oe(e)
						}, e)), !F.length && /* @__PURE__ */ f("span", {
							className: "gf-empty-hand",
							children: o.noCards
						})]
					})
				}),
				/* @__PURE__ */ p("div", {
					className: "gf-case-box",
					children: [
						/* @__PURE__ */ f("span", { children: "▣" }),
						/* @__PURE__ */ p("b", { children: ["$", w(r?.suitcase ?? [])] }),
						/* @__PURE__ */ f("small", { children: o.suitcase })
					]
				})
			]
		})]
	});
	return /* @__PURE__ */ p(c, {
		adaptive: !0,
		scroll: !1,
		className: "gf-screen",
		actionsHeight: "gf-tray-height",
		actions: z,
		banner: /* @__PURE__ */ p("header", {
			className: "gf-header",
			children: [/* @__PURE__ */ p("div", {
				className: "gf-title",
				children: [/* @__PURE__ */ f("b", { children: o.name }), /* @__PURE__ */ p("span", { children: [
					o.act,
					" ",
					t.act,
					" / IV · ",
					L,
					t.phase === "tribute" ? ` · ${_[t.act - 1]}` : "",
					" · ",
					s.length ? O(e.myRid) : `${o.waiting} ${O(t.active)}`
				] })]
			}), /* @__PURE__ */ f("div", {
				className: "gf-families",
				children: t.players.map((e) => /* @__PURE__ */ f(X, {
					name: `seat:${e.rid}`,
					children: /* @__PURE__ */ p("button", {
						type: "button",
						style: { "--gf-owner": k(e.rid) },
						"data-active": t.active === e.rid || void 0,
						onClick: () => {
							let n = s.find((n) => n.type === "choose" && n.value === t.players.indexOf(e) && t.prompt === "extort");
							n && D(n);
						},
						children: [/* @__PURE__ */ p("strong", { children: [t.first === e.rid ? "♞ " : "", O(e.rid)] }), /* @__PURE__ */ p("span", { children: [
							"▱ ",
							e.handCount,
							" · ▣ ",
							e.caseCount,
							e.bid >= 0 ? ` · $${e.bid}` : e.committed && t.phase === "bidding" ? ` · ${o.committed}` : ""
						] })]
					})
				}, e.rid))
			})]
		}),
		overlay: /* @__PURE__ */ p(d, { children: [t.phase === "effects" && s.length > 0 && /* @__PURE__ */ p("div", {
			className: "gf-effect-prompt",
			children: [/* @__PURE__ */ f("div", { children: t.effects.map((e, t) => /* @__PURE__ */ f("button", {
				type: "button",
				onClick: () => A({
					type: "effect",
					index: t
				}),
				children: /* @__PURE__ */ f(Y, {
					effect: e,
					w: o
				})
			}, t)) }), j(-1) && /* @__PURE__ */ f("button", {
				type: "button",
				onClick: () => A(j(-1)),
				children: o.skip
			})]
		}), t.phase === "prompt" && s.length > 0 && /* @__PURE__ */ p("div", {
			className: "gf-choice-prompt",
			children: [/* @__PURE__ */ f("strong", { children: L }), /* @__PURE__ */ p("div", { children: [
				["draw", "loot"].includes(t.prompt) && (t.prompt === "draw" ? r?.offered ?? [] : t.revealed).map((e) => /* @__PURE__ */ f(Q, {
					id: e,
					legal: !!j(e),
					onClick: () => j(e) && A(j(e))
				}, e)),
				t.prompt === "good" && s.map((e) => e.type === "choose" && e.value >= 0 ? /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => A(e),
					children: [/* @__PURE__ */ f(G, { value: e.value }), o.goods[e.value]]
				}, e.value) : null),
				t.prompt === "frontOrder" && s.map((e) => e.type === "choose" ? /* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => A(e),
					children: e.value === 0 ? o.actionFirst : o.controllerFirst
				}, e.value) : null),
				j(-1) && /* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => A(j(-1)),
					children: o.decline
				})
			] })]
		})] }),
		children: [
			/* @__PURE__ */ p("div", {
				className: "gf-table",
				children: [/* @__PURE__ */ f(Le, {
					pub: t,
					members: e.members,
					actions: s,
					selectedPiece: P?.id ?? -1,
					onAction: (e) => D(e),
					onInspect: v
				}), /* @__PURE__ */ p("aside", {
					className: "gf-public",
					children: [
						/* @__PURE__ */ f(X, {
							name: "deck",
							className: "gf-public-heading",
							children: /* @__PURE__ */ f("h2", { children: o.publicJobs })
						}),
						/* @__PURE__ */ f("div", {
							className: "gf-public-cards",
							children: t.publicJobs.map((e) => /* @__PURE__ */ f(Q, {
								id: e,
								legal: !!ie(e),
								onClick: () => h(e)
							}, e))
						}),
						/* @__PURE__ */ f("h2", { children: o.allies }),
						/* @__PURE__ */ p("div", {
							className: "gf-public-cards",
							children: [t.allies.map((e) => /* @__PURE__ */ f(Q, {
								id: e,
								legal: t.phase === "auction" && !!j(e),
								onClick: () => h(e)
							}, e)), t.players.flatMap((e) => e.used.map((e) => /* @__PURE__ */ f(X, {
								name: `ally:${e}`,
								children: /* @__PURE__ */ f(Q, {
									id: e,
									onClick: () => h(e)
								})
							}, e)))]
						}),
						/* @__PURE__ */ f(X, {
							name: "supply",
							className: "gf-supply",
							children: t.supply.map((e) => /* @__PURE__ */ p("span", { children: [e.kind === "money" ? /* @__PURE__ */ f(K, { value: e.value }) : /* @__PURE__ */ f(G, { value: e.value }), /* @__PURE__ */ f("small", { children: e.count })] }, `${e.kind}${e.value}`))
						})
					]
				})]
			}),
			/* @__PURE__ */ f(X, {
				name: "job-play",
				className: "gf-job-play",
				children: t.revealed.filter((e) => C[e].kind === "job").map((e) => /* @__PURE__ */ f(J, { id: e }, e))
			}),
			/* @__PURE__ */ f(X, { name: "offered" }),
			(m !== null || g !== null || E || ne) && /* @__PURE__ */ f("div", {
				className: "gf-modal",
				role: "dialog",
				"aria-modal": "true",
				children: /* @__PURE__ */ p("section", {
					className: "gf-detail",
					children: [
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "gf-close",
							onClick: () => {
								h(null), v(null), D(null), re(!1);
							},
							children: o.close
						}),
						ne && /* @__PURE__ */ f("div", {
							className: "gf-log",
							children: t.log.map((e, t) => /* @__PURE__ */ p("p", { children: [
								O(e.rid),
								" · ",
								o.logEvents[e.event] ?? e.event,
								e.event === "bank" || e.event === "bribe" || e.event === "final" ? ` $${e.value}` : e.event === "war" || e.event === "control" ? ` ${o.turfs[e.value]}` : ""
							] }, t))
						}),
						m !== null && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
							className: "gf-detail-card",
							children: /* @__PURE__ */ f(J, {
								id: m,
								detailed: !0
							})
						}), /* @__PURE__ */ p("div", {
							className: "gf-detail-actions",
							children: [s.filter((e) => e.type === "job" && e.card === m).map((e, t) => /* @__PURE__ */ f("button", {
								type: "button",
								className: "gf-primary",
								onClick: () => A(e),
								children: e.type === "job" && e.rewardFirst ? o.rewardFirst : o.effectFirst
							}, t)), s.filter((e) => e.type === "ally" && e.card === m || t.phase === "auction" && e.type === "choose" && e.value === m).map((e, t) => /* @__PURE__ */ f("button", {
								type: "button",
								className: "gf-primary",
								onClick: () => A(e),
								children: e.type === "ally" ? o.playAlly : o.choose
							}, t))]
						})] }),
						g !== null && /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ f("h2", { children: o.businesses[g] }),
							/* @__PURE__ */ f("h3", { children: o.back }),
							y[g].back.map((e, t) => /* @__PURE__ */ f(Y, {
								effect: e,
								w: o
							}, t)),
							/* @__PURE__ */ f("h3", { children: o.front }),
							y[g].front.map((e, t) => /* @__PURE__ */ f(Y, {
								effect: e,
								w: o
							}, t))
						] }),
						E && /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ f("h2", { children: L }),
							E.type === "place" && /* @__PURE__ */ p("div", {
								className: "gf-placement-preview",
								children: [/* @__PURE__ */ f(q, {
									kind: t.pieces[E.piece].kind,
									color: k(e.myRid)
								}), /* @__PURE__ */ f("strong", { children: E.slot >= 100 ? b[E.slot - 100].turfs.map((e) => o.turfs[e]).join(" · ") : o.businesses[E.slot] })]
							}),
							R && /* @__PURE__ */ p("div", {
								className: "gf-placement-preview",
								children: [/* @__PURE__ */ f(q, {
									kind: R.kind,
									color: R.owner < 0 ? void 0 : k(t.players[R.owner].rid)
								}), /* @__PURE__ */ p("strong", { children: [
									R.owner < 0 ? "" : `${O(t.players[R.owner].rid)} · `,
									o.kinds[R.kind],
									" · ",
									ae(R.slot)
								] })]
							}),
							E.type === "choose" && !R && /* @__PURE__ */ f("p", { children: t.prompt === "extort" ? O(t.players[E.value].rid) : [
								"bomb",
								"control",
								"recycle"
							].includes(t.prompt) ? o.turfs[E.value] : ae(E.value) }),
							E.type === "place" && (E.slot >= 100 ? b[E.slot - 100].turfs.flatMap((e) => e === 0 ? [{
								kind: "bank",
								value: 1
							}] : t.businesses.filter((t) => t.turf === e).flatMap((e) => y[e.id].back)) : y[E.slot].front).map((e, t) => /* @__PURE__ */ f(Y, {
								effect: e,
								w: o
							}, t)),
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "gf-primary",
								onClick: () => A(E),
								children: o.confirm
							})
						] })
					]
				})
			}),
			!l && /* @__PURE__ */ f("span", {
				className: "gf-spectator",
				children: o.waiting
			})
		]
	});
}
//#endregion
//#region src/games/godfather/bot.ts
var Be = {
	territory: 1,
	bank: 1,
	job: 4
};
function Ve(e, t, n) {
	let r = C[e];
	if (r.kind === "money") return r.value * (t.act === 4 ? 1.6 : .75);
	if (r.kind === "ally") return 5;
	if (r.kind === "goods") return r.value === 3 ? 4 : 2.6;
	let i = n.filter((e) => C[e].kind === "goods").map((e) => C[e].value);
	return 1 + v[r.value].cost.filter((e) => i.includes(e) || i.includes(3)).length * 1.2;
}
function $(e, t, n, r) {
	let i = n.hand.filter((e) => C[e].kind === "money").map((e) => C[e].value).sort((e, t) => t - e), a = e.value ?? 0;
	if (e.kind === "money" || e.kind === "caseMoney") return a;
	if (e.kind === "goods") {
		if (!t.supply.some((e) => e.kind === "goods" && e.value === a && e.count)) return 0;
		let e = [...n.hand, ...t.publicJobs].some((e) => C[e].kind === "job" && v[C[e].value].cost.includes(a));
		return (a === 3 ? 4 : e ? 3.1 : 2) / (1 + n.hand.filter((e) => C[e].kind === "goods" && C[e].value === a).length * .3);
	}
	if (e.kind === "bank") return r.bank * i.slice(0, a).reduce((e, t) => e + t, 0) * .95;
	if (e.kind === "draw") return n.hand.filter((e) => C[e].kind === "job").length < 3 ? 2.3 : .8;
	if (e.kind === "exchange" || e.kind === "exchangeGood") {
		let r = a || 1;
		if (n.hand.length < r) return 0;
		let i = n.hand.map((e) => Ve(e, t, n.hand)).sort((e, t) => e - t).slice(0, r).reduce((e, t) => e + t, 0);
		return Math.max(0, (e.extra?.reduce((e, t) => e + t, 0) ?? 3.5) - i);
	}
	return e.kind === "reward" ? e.extra?.reduce((e, t) => e + t, 0) ?? 0 : 3;
}
function He(e, t, n, r) {
	let i = se({
		players: e.players,
		pieces: e.pieces,
		businesses: e.businesses
	}, n), a = Math.max(...i.filter((e, n) => n !== t)), o = i[t];
	return r.territory * (o === a ? 2.4 : o + 1 === a ? 1.4 : o > a ? .25 : .6);
}
function Ue(e, t, n, r, i = Be) {
	let a = t.players.findIndex((e) => e.rid === r);
	if (e.type === "place") {
		let r = e.slot >= 100 ? b[e.slot - 100].turfs.flatMap((e) => e === 0 ? [{
			kind: "bank",
			value: 1
		}] : t.businesses.filter((t) => t.turf === e).flatMap((e) => y[e.id].back)) : y[e.slot].front, o = e.slot >= 100 ? b[e.slot - 100].turfs.filter((e) => e > 0) : [t.businesses.find((t) => t.id === e.slot).turf], s = e.slot < 100 && t.turfs[o[0] - 1].at(-1) !== void 0 && t.turfs[o[0] - 1].at(-1) !== a;
		return r.reduce((e, r) => e + $(r, t, n, i), 0) + o.reduce((e, n) => e + He(t, a, n, i), 0) - +!!s;
	}
	if (e.type === "job") {
		let r = v[C[e.card].value];
		return i.job * (r.reward.reduce((e, t) => e + t, 0) + $(r.effect, t, n, i) + 1.5) - r.cost.length * 1.5 + (e.rewardFirst && r.effect.kind === "bank" ? 3 : 0);
	}
	if (e.type === "ally") return 5.8;
	if (e.type === "effect") return $(t.effects[e.index], t, n, i) + .1;
	if (e.type !== "choose") return 0;
	let o = e.value;
	if (o === -1 || t.phase === "effects") return -100;
	if (t.phase === "tribute" || ["exchange", "refuseDiscard"].includes(t.prompt)) return -Ve(o, t, n.hand);
	if (t.phase === "auction") {
		let e = C[o].value % 6;
		return e === 5 || [
			1,
			2,
			3
		].includes(e) ? 7 : 5;
	}
	if (t.prompt === "pay") return C[o].value === 3 ? -2 : 0;
	if (t.prompt === "bank" || t.prompt === "loot") return Ve(o, t, n.hand);
	if (t.prompt === "extortMoney") return -C[o].value;
	if (t.prompt === "draw") return Ve(o, t, n.hand);
	if (t.prompt === "good") return $({
		kind: "goods",
		value: o
	}, t, n, i);
	if (t.prompt === "control") {
		let e = t.turfs[o - 1], n = e.filter((e) => e === a).length, r = Math.max(...t.players.map((t, n) => n === a ? 0 : e.filter((e) => e === n).length));
		return n === r ? 6 : n + 1 === r ? 4 : n > r ? 1 : 2;
	}
	return t.prompt === "recycle" ? -t.turfs[o - 1].filter((e) => e === a).length + (t.turfs[o - 1].at(-1) === a ? -5 : 0) : t.prompt === "shakedown" ? y[o].front.reduce((e, r) => e + $(r, t, n, i), 0) : t.prompt === "neutral" || t.prompt === "redeploy" || t.prompt === "destination" ? o >= 200 ? t.pieces.filter((e) => e.owner !== a && e.slot >= 0).length + He(t, a, o - 200, i) : o >= 100 ? b[o - 100].turfs.reduce((e, n) => e + (n ? He(t, a, n, i) : 2), 0) : y[o].front.reduce((e, r) => e + $(r, t, n, i), 0) : t.prompt === "reuse" ? t.pieces[o].kind === "family" ? 5 : 3 : t.prompt === "extort" ? t.players[o].caseCount : 1;
}
function We(e = Be) {
	return (t, n) => {
		let r = t.private;
		if (!r?.legal.length) return null;
		if (t.public.phase === "bidding") {
			let e = r.suitcase.filter((e) => C[e].kind === "money").sort((e, t) => C[e].value - C[t].value), n = t.public.act === 1 ? 2 : 3, i = [];
			for (let t of e) w([...i, t]) <= n && i.push(t);
			return { action: {
				type: "bid",
				cards: i
			} };
		}
		if (n.difficulty === "weak") {
			let e = /* @__PURE__ */ new Uint32Array(1), t = Math.floor(4294967296 / r.legal.length) * r.legal.length;
			do
				crypto.getRandomValues(e);
			while (e[0] >= t);
			return { action: r.legal[e[0] % r.legal.length] };
		}
		let i = r.legal[0], a = -Infinity;
		for (let o of r.legal) {
			let s = Ue(o, t.public, r, n.rid, e);
			s > a && (i = o, a = s);
		}
		return { action: i };
	};
}
var Ge = We(), Ke = (e, t, n) => ({
	x: e.x + e.w / 2 - t / 2,
	y: e.y + e.h / 2 - n / 2,
	w: t,
	h: n
}), qe = {
	transfer: (e, t) => {
		let n = e.data, r = n.card ?? e.secret?.card, a = t.member(n.piece >= 0 ? n.owner ?? "" : e.rid ?? ""), o = `seat:${e.rid}`, s = (e) => e && e.w > 0 && e.h > 0 ? e : null, c = s(t.anchor(`hand:${e.rid}`)), l = r === void 0 ? null : s(t.anchor(`card:${r}`)), u = c && l && l.x >= c.x && l.x + l.w <= c.x + c.w, d = n.piece >= 0 && n.to.startsWith("piece:") ? n.to : n.to.startsWith("hand:") && e.rid === t.myRid && u ? `card:${r}` : n.to, p = s(t.anchor(d)) ?? s(t.anchor(o)), m = s(t.anchor(n.from)) ?? s(t.anchor(n.from.startsWith("card:") ? "deck" : o)) ?? s(t.anchor("supply"));
		if (!p || !m) return null;
		let h = t.queued ? 180 : 560, g = n.piece >= 0 ? 44 : 72, _ = n.piece >= 0 ? 62 : 105, v = Ke(m, g, _), y = d.startsWith("piece:") || d.startsWith("card:") ? p : Ke(p, g * .7, _ * .7), b = a ? i[a.colorIndex % i.length].hex : "#b4a382";
		return {
			ms: h,
			node: /* @__PURE__ */ f(ee, {
				from: v,
				to: y,
				ms: h,
				children: /* @__PURE__ */ f("div", {
					className: "gf-fx-piece",
					style: {
						width: g,
						height: _
					},
					children: n.piece >= 0 ? /* @__PURE__ */ f(q, {
						kind: n.pieceKind ?? "family",
						color: b
					}) : r === void 0 ? /* @__PURE__ */ f("span", {
						className: "gf-card-back",
						children: "♞"
					}) : /* @__PURE__ */ f(J, { id: r })
				})
			}),
			hide: !t.queued && (d.startsWith("piece:") || d.startsWith("card:")) ? [d] : []
		};
	},
	control: (e, t) => {
		let n = e.data.turf, r = t.anchor(`turf:${n}`);
		return r ? {
			ms: 570,
			node: /* @__PURE__ */ f(m, {
				at: r,
				ms: 570
			})
		} : null;
	}
};
//#endregion
//#region src/games/godfather/game-over.tsx
function Je({ label: e, confirm: t, run: r }) {
	let [i, a] = n(!1);
	return /* @__PURE__ */ f("button", {
		type: "button",
		className: i ? "gf-confirm danger-stripes" : "gf-confirm",
		onBlur: () => a(!1),
		onClick: () => {
			i ? (a(!1), r()) : a(!0);
		},
		children: i ? t : e
	});
}
function Ye(e) {
	let t = e.public, r = W(), i = u(), [a, o] = n(!1), s = (t) => e.members.find((e) => e.rid === t)?.name ?? t, c = [
		r.cash,
		r.dominance,
		...r.colors
	];
	return /* @__PURE__ */ p("div", {
		className: "gf-screen gf-ending",
		children: [
			/* @__PURE__ */ f("div", {
				className: "gf-ending-city",
				inert: !a,
				"aria-hidden": !a,
				children: /* @__PURE__ */ f(Le, {
					pub: t,
					members: e.members
				})
			}),
			/* @__PURE__ */ p("section", {
				className: "gf-ledger",
				hidden: a,
				children: [/* @__PURE__ */ p("header", { children: [
					/* @__PURE__ */ f("span", { children: "NEW YORK · 1950" }),
					/* @__PURE__ */ f("h1", { children: r.finalTitle }),
					/* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => o(!0),
						children: r.review
					})
				] }), /* @__PURE__ */ p("div", {
					className: "gf-ledger-scroll",
					children: [
						/* @__PURE__ */ p("table", { children: [/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: r.scoreItem }), e.result.ranking.map((t) => /* @__PURE__ */ p("th", {
							"data-winner": e.result.winner.includes(t) || void 0,
							children: [s(t), e.result.winner.includes(t) ? " ♞" : ""]
						}, t))] }) }), /* @__PURE__ */ p("tbody", { children: [/* @__PURE__ */ p("tr", {
							className: "gf-ledger-total",
							children: [/* @__PURE__ */ f("th", { children: r.total }), e.result.ranking.map((e) => /* @__PURE__ */ p("td", { children: ["$", t.players.find((t) => t.rid === e).final.reduce((e, t) => e + t, 0)] }, e))]
						}), c.map((n, r) => /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: n }), e.result.ranking.map((e) => /* @__PURE__ */ p("td", { children: ["$", t.players.find((t) => t.rid === e).final[r]] }, e))] }, n))] })] }),
						e.hintCount !== void 0 && /* @__PURE__ */ f("p", { children: i("session.hint.usedCount", { n: e.hintCount }) }),
						e.result.ranking.filter((t) => (e.result.autopilot?.[t] ?? 0) > 0).map((t) => /* @__PURE__ */ p("p", { children: [
							s(t),
							" · ",
							i("session.autopilot.share", { n: Math.round((e.result.autopilot?.[t] ?? 0) * 100) })
						] }, t))
					]
				})]
			}),
			/* @__PURE__ */ p("footer", {
				className: "gf-ending-controls",
				children: [
					a && /* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => o(!1),
						children: r.backToResult
					}),
					e.onPlayAgain && /* @__PURE__ */ f(Je, {
						label: i("session.result.playAgain"),
						confirm: r.confirmReplay,
						run: e.onPlayAgain
					}),
					e.onBackToLobby && /* @__PURE__ */ f(Je, {
						label: i("session.result.backToLobby"),
						confirm: r.confirmLobby,
						run: e.onBackToLobby
					}),
					!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ f("span", { children: i("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/godfather/entry.tsx
var Xe = {
	definition: je,
	View: ze,
	bot: Ge,
	fx: qe,
	OverView: Ye,
	locales: {
		zh: Me,
		en: Ne
	}
};
//#endregion
export { Xe as default };
