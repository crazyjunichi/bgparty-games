import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { PLAYER_COLORS as n } from "@bgparty/sdk/player-colors";
import { AVATARS as r } from "@bgparty/sdk/avatars";
import { useEffect as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { IconClose as m } from "@bgparty/sdk/icons";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
//#region src/games/greylune/data.ts
var v = (e, t = 1, n) => ({
	kind: e,
	n: t,
	...n ? { ref: n } : {}
}), y = (e, ...t) => ({
	pay: e,
	gain: t
}), b = [];
function x(e, t, n, r, i, a = [], o = {}) {
	b.push({
		id: e,
		name: t,
		zh: n,
		period: r,
		cost: i,
		abilities: a,
		immediate: [],
		score: 0,
		...o
	});
}
x(101, "Travelers Guild I", "旅人公会 I", 1, 0, [y([], v("travel", 2))]), x(102, "Scouts Guild I", "斥候公会 I", 1, 0, [y([["seal", 1]], v("travel", -1))], { seals: -1 }), x(103, "Riven Oak", "裂橡酒馆", 1, 0, [y([], v("story", 103))]), x(104, "Golden Lion", "金狮酒馆", 1, 0, [y([], v("story", 104))], { seals: -1 }), x(105, "Magical School", "魔法学校", 1, 0, [y([["sealCoins", 1]], v("magic"))], { seals: -1 }), x(106, "Smithy", "铁匠铺", 1, 0, [y([], v("force"))]), x(107, "Travelers Guild II", "旅人公会 II", 2, 0, [y([["coins", 2]], v("travel", 4))]), x(108, "Scouts Guild II", "斥候公会 II", 2, 0, [y([["seal", 1]], v("travel", -1))], { seals: -1 }), x(109, "Hall of the Heroes", "英雄殿堂", 2, 0, [
	y([["force", 1]], v("vp", 3)),
	y([["magic", 1]], v("vp", 4)),
	y([["force", 1], ["magic", 1]], v("vp", 7))
]), x(110, "Town Hall", "市政厅", 2, 0, [y([["sealCoins", 1]], v("force"), v("magic"))], { seals: -1 }), x(111, "Silver Wolf", "银狼酒馆", 2, 0, [y([], v("story", 111))], { seals: -1 }), x(112, "Jolly Boar", "欢野猪酒馆", 2, 0, [y([], v("story", 112))]), x(113, "Fortress", "要塞", 3, 0, [y([["sealCoins", 1]], v("count", 2, "companions"))], { seals: -1 }), x(114, "Travelers Guild III", "旅人公会 III", 3, 0, [y([["coins", 2]], v("travel", 5))]), x(115, "Library", "图书馆", 3, 0, [y([["sealCoins", 1]], v("count", 1, "told"))], { seals: -1 }), x(116, "Scarlet Dragon", "绯龙酒馆", 3, 0, [y([], v("story", 116))]), x(201, "Jade Statue", "翡翠雕像", 1, 3, [], {
	immediate: [v("skill")],
	score: 5
}), x(202, "Tommy", "汤米", 1, 4, [y([], v("travel")), y([["workers", 1]], v("travel", 2))], { score: 1 }), x(203, "Hundred League Boots", "百里靴", 1, 2, [y([], v("travel", 5))], { seals: 1 }), x(204, "Wizard’s Staff", "巫师法杖", 1, 3, [y([["workers", 1]], v("magic"))], {
	immediate: [v("magic")],
	score: 1
}), x(205, "Mysterious Map", "神秘地图", 1, 3, [y([], v("travel")), y([["workers", 1]], v("travel", 3))], { score: 1 }), x(206, "Mana Potion", "魔力药水", 1, 3, [], {
	seals: 1,
	potion: !0
}), x(207, "Strength Potion", "力量药水", 1, 2, [], {
	seals: 1,
	potion: !0
}), x(208, "Short Sword", "短剑", 1, 2, [y([["workers", 1]], v("force"))], {
	immediate: [v("force")],
	score: 1
}), x(209, "Gold Statue", "黄金雕像", 2, 4, [], {
	immediate: [v("skill")],
	score: 5
}), x(210, "Snowmane", "雪鬃", 2, 4, [y([["workers", 1]], v("travel", 3)), y([["workers", 2]], v("travel", 5))], { score: 2 }), x(211, "Horn", "号角", 2, 2, [y([["workers", 1]], v("vp", 3)), y([["workers", 2]], v("vp", 5))], { score: 1 }), x(212, "Treasure Map", "藏宝图", 2, 3, [y([], v("travel", 2)), y([["workers", 1]], v("travel", 4))], { score: 1 }), x(213, "Charisma Potion", "魅力药水", 2, 3, [], {
	seals: 1,
	potion: !0
}), x(214, "Endurance Potion", "耐力药水", 2, 3, [], {
	seals: 1,
	potion: !0
}), x(215, "Flying Potion", "飞行药水", 2, 2, [], {
	seals: 1,
	potion: !0
}), x(216, "Bladechant", "刃歌", 2, 5, [y([], v("skill")), y([["workers", 1]], v("force"), v("magic"))], { score: 1 }), x(217, "Invisibility Potion", "隐形药水", 2, 3, [], {
	seals: 1,
	potion: !0
}), x(218, "Rubis Statue", "红宝石雕像", 3, 6, [], {
	immediate: [v("skill")],
	score: 6
}), x(219, "Mandolin", "曼陀林琴", 3, 5, [y([["workers", 1]], v("count", 1, "untold"))], { score: 5 }), x(220, "Bag of Holding", "次元袋", 3, 4, [y([["workers", 1]], v("count", 1, "items"))], { score: 4 }), x(221, "Philosopher’s Stone", "贤者之石", 3, 3, [y([["workers", 1]], v("vp", 5))], { seals: 1 }), x(222, "Magic Ring", "魔法戒指", 3, 7, [], { score: 9 });
var S = [
	"Kael",
	"Elwen",
	"Dorian",
	"Ariok",
	"Selia",
	"Neris",
	"Bran",
	"Lucan",
	"Isandre",
	"Seren",
	"Mira"
], C = [
	"凯尔",
	"埃尔温",
	"多里安",
	"阿里奥克",
	"塞莉娅",
	"奈丽丝",
	"布兰",
	"卢坎",
	"伊桑德尔",
	"瑟伦",
	"米拉"
], w = [
	"force",
	"far",
	"items",
	"magic",
	"potions",
	"coins2",
	"workersMinus2",
	"lowest",
	"companions",
	"told",
	"banners"
];
S.forEach((e, t) => x(301 + t, e, C[t], t < 6 ? 1 : 2, 7, [], {
	immediate: t === 3 ? [v("worker"), v("magic")] : [v("worker")],
	score: [4, 8].includes(t) ? 2 : 1,
	per: w[t]
}));
var T = Object.fromEntries(b.map((e) => [e.id, e])), E = b, D = {
	0: [
		[v("coins", 2)],
		[v("force")],
		[v("vp", 2)]
	],
	103: [
		[v("vp", 2)],
		[v("force")],
		[v("worker")]
	],
	104: [
		[v("coins", 4)],
		[v("vp")],
		[v("coins", -1)]
	],
	111: [
		[v("coins", 4)],
		[v("vp", -1)],
		[v("ready")]
	],
	112: [
		[v("vp", 3)],
		[v("coins", 2)],
		[v("skill")]
	],
	116: [
		[v("vp", 3)],
		[v("vp", 2)],
		[v("vp")]
	]
}, ee = [];
function O(e, t, n, r, i, ...a) {
	ee.push({
		id: e,
		name: t,
		zh: n,
		period: e <= 16 ? 1 : e <= 32 ? 2 : 3,
		area: r,
		story: i,
		outcomes: a
	});
}
function k(e, t) {
	return [[e, t]];
}
O(1, "Valley", "山谷", 1, 0, y(k("haveForce", 1), v("travel", 2)), y([["workers", 1]], v("vp", 3))), O(2, "Tiger", "猛虎", 1, 3, y([["workers", 1]])), O(3, "Rocky Pass", "岩石隘口", 3, 2, y([], v("force"))), O(4, "Sheep", "羊群", 2, 0, y([], v("income", 7))), O(5, "Mine", "矿井", 3, 1, y([["workers", 1]], v("income", 5))), O(6, "Pack of Wolves", "狼群", 1, 2, y(k("haveForce", 2), v("vp", 3))), O(7, "Marauders", "掠夺者", 2, 2, y(k("haveSkills", 2), v("coins", 4))), O(8, "Initiation", "入门试炼", 1, 1, y([["coins", 4]], v("force"), v("magic"))), O(9, "Hermit", "隐士", 2, 2, y(k("haveForce", 2), v("magic"))), O(10, "Ambush", "伏击", 1, 1, y(k("haveMagic", 1), v("income", 4))), O(11, "Cursed Skull", "诅咒头骨", 2, 3, y(k("haveMagic", 2), v("ready"))), O(12, "Circle of Stones", "环形石阵", 3, 1, y([], v("magic"))), O(13, "Camp", "营地", 4, 1, y(k("haveSkills", 1), v("worker"))), O(14, "Inn", "旅店", 3, 1, y([["coins", 2]], v("worker"))), O(15, "Bear", "巨熊", 4, 3, y(k("haveForce", 1), v("vp", 2)), y(k("haveMagic", 1), v("vp", 2))), O(16, "World Tree", "世界树", 2, 0, y([], v("income", 1))), O(17, "Treasure", "宝藏", 1, 2, y(k("haveMagic", 3), v("coins", 3)), y([["magic", 1]], v("coins", 4))), O(18, "Lone Tower", "孤塔", 2, 3, y([["magic", 1]], v("vp", 3), v("travel", 3))), O(19, "Witchcraft", "巫术", 3, 1, y([["coins", 4]], v("magic", 2))), O(20, "Incantation", "咒语", 4, 3, y([["workers", 1]], v("magic"))), O(21, "Unicorn", "独角兽", 3, 3, y(k("haveMagic", 3), v("ready"), v("income", 8))), O(22, "Joust", "马上比武", 4, 1, y([["workers", 1]], v("vp", 3)), y(k("haveForce", 4), v("vp", 4))), O(23, "Diamond", "钻石", 3, 2, y([["force", 1]], v("coins", 5))), O(24, "Farm", "农场", 2, 0, y([], v("worker"))), O(25, "Demon", "恶魔", 5, 3, y(k("haveForce", 3), v("vp", 3)), y(k("haveMagic", 3), v("vp", 3))), O(26, "Legendary Sword", "传说之剑", 1, 1, y([["workers", 1]], v("vp", 3))), O(27, "Coopery", "制桶工坊", 4, 0, y([["coins", 4]], v("income", 2))), O(28, "Training", "训练", 2, 0, y([["coins", 4]], v("income", 3))), O(29, "Vagabond", "流浪者", 3, 2, y(k("haveSkills", 4), v("worker"))), O(30, "Errant Knight", "游侠骑士", 3, 1, y([["coins", 2]], v("force"), v("vp", 2))), O(31, "Caravan", "商队", 1, 0, y([["workers", 2]], v("income", 6))), O(32, "Brigands", "强盗", 5, 1, y(k("haveForce", 3), v("coins", 4), v("vp", 2))), O(33, "Archery", "射箭", 1, 1, y([["coins", 3]], v("force"), v("vp", 3))), O(34, "Snowy Pass", "雪山隘口", 3, 2, y(k("haveForce", 5), v("coins", 5), v("vp", 3))), O(35, "Necromancer", "死灵法师", 5, 1, y(k("haveSkills", 8), v("vp", 9))), O(36, "Gold Mine", "金矿", 2, 0, y([["workers", 1]], v("coins", 7))), O(37, "Dragon", "巨龙", 5, 3, y(k("haveForce", 5), v("vp", 4)), y(k("haveMagic", 5), v("vp", 4))), O(38, "Labyrinth", "迷宫", 4, 0, y([["workers", 1]], v("vp", 4)), y([["workers", 1]], v("vp", 4))), O(39, "Relay", "驿站", 2, 1, y([["coins", 4]], v("vp", 2), v("travel", 3))), O(40, "Fairy Ring", "仙灵之环", 3, 2, y([["workers", 1]], v("magic"), v("vp", 3))), O(41, "Holy Chalice", "圣杯", 4, 2, y(k("haveMagic", 5), v("ready"), v("vp", 4)));
var A = Object.fromEntries(ee.map((e) => [e.id, e])), te = ee, j = [
	{
		name: "Banquet",
		zh: "宴会",
		abilities: [y([], v("coins", 3)), y([], v("ready"))]
	},
	{
		name: "Festival",
		zh: "节庆",
		abilities: [
			y([], v("magic"), v("vp", 2)),
			y([], v("magic"), v("coins", 2)),
			y([], v("vp", 2), v("travel")),
			y([], v("coins", 2), v("force")),
			y([], v("force"), v("travel"))
		]
	},
	{
		name: "Great Fair",
		zh: "大集市",
		abilities: [y([["coins", 3]], v("force"), v("magic"))]
	},
	{
		name: "Magic Show",
		zh: "魔术表演",
		abilities: [y([["magic", 1]], v("travel", 5))]
	},
	{
		name: "Gathering",
		zh: "集会",
		abilities: [y([["force", 1]], v("worker")), y([["coins", 3]], v("worker"))]
	},
	{
		name: "Tournament",
		zh: "比武大会",
		abilities: [y([["force", 1]], v("coins", 6)), y([["force", 1]], v("vp", 4))]
	}
], M = [
	{
		name: "Giant",
		zh: "巨人",
		pay: k("haveForce", 4)
	},
	{
		name: "Dragon",
		zh: "屠龙",
		pay: k("haveSkills", 6)
	},
	{
		name: "Wraiths",
		zh: "幽魂",
		pay: k("haveMagic", 4)
	},
	{
		name: "Bard Tournament",
		zh: "吟游诗人竞赛",
		pay: [["stories", 2]]
	},
	{
		name: "Donation",
		zh: "捐赠",
		pay: [["item", 1]]
	},
	{
		name: "Undeads",
		zh: "亡灵",
		pay: [["force", 1], ["magic", 1]]
	},
	{
		name: "Deadly Trap",
		zh: "致命陷阱",
		pay: [["return", 1]]
	},
	{
		name: "Ransom",
		zh: "赎金",
		pay: [["coins", 6]]
	},
	{
		name: "Wedding",
		zh: "婚礼",
		pay: [["workers", 2]]
	}
], N = {
	1: v("vp"),
	2: v("vp", 2),
	3: v("force"),
	4: v("coins"),
	5: v("coins", 2),
	6: v("coins", 4),
	7: v("coins"),
	8: v("vp")
}, P = Array.from({ length: 12 }, (e, t) => t < 6 ? [Math.floor(t / 3) * 3 + t % 3, (Math.floor(t / 3) + 1) * 3 + t % 3] : [Math.floor((t - 6) / 2) * 3 + (t - 6) % 2, Math.floor((t - 6) / 2) * 3 + (t - 6) % 2 + 1]), ne = {
	id: "greylune",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.greylune.name",
	descKey: "games.greylune.desc",
	rulesKey: "games.greylune.rules",
	icon: "🏰",
	iconImg: "games/greylune.webp",
	rulesUrl: { en: "https://medias.sorryweare.fr/wp-content/uploads/2026/10/RULES-GREYLUNE-236X236_EN_LIGHT.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	accent: "#8f432a",
	releasedAt: "2026-11-02T01:25:00+08:00",
	search: {
		py: "huiyue",
		init: "hy"
	},
	hotseat: "open",
	botDelayMs: 650
}, re = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	key: t.string().max(80)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), ie = t.object({
	kind: t.enum([
		"coins",
		"force",
		"magic",
		"skill",
		"vp",
		"worker",
		"travel",
		"ready",
		"income",
		"story",
		"count"
	]),
	n: t.number(),
	ref: t.string().optional()
}), ae = t.array(t.tuple([t.string(), t.number()])), oe = t.object({
	key: t.string(),
	kind: t.string(),
	card: t.number().optional(),
	slot: t.number().optional(),
	gap: t.number().optional(),
	option: t.number().optional(),
	n: t.number().optional(),
	cards: t.array(t.number()).optional(),
	gain: t.array(ie).optional(),
	pay: ae.optional(),
	source: t.string().optional()
}), se = t.object({
	rid: t.string(),
	season: t.enum([
		"spring",
		"summer",
		"autumn"
	]),
	coins: t.number(),
	force: t.number(),
	magic: t.number(),
	active: t.number(),
	reserve: t.number(),
	camp: t.number(),
	removed: t.number(),
	score: t.number(),
	items: t.array(t.number()),
	companions: t.array(t.number()),
	exhausted: t.array(t.number()),
	untold: t.array(t.number()),
	told: t.array(t.number()),
	income: t.array(t.number()),
	position: t.number(),
	event: t.number().nullable(),
	special: t.boolean(),
	bonuses: t.array(t.number()),
	bonusLevel: t.number(),
	quests: t.array(t.number()),
	questPoints: t.number()
}), ce = t.object({
	revision: t.number(),
	year: t.number(),
	phase: t.enum([
		"play",
		"settle",
		"done"
	]),
	turn: t.string(),
	first: t.string(),
	board: t.array(t.number().nullable()),
	seals: t.array(t.array(t.number())),
	streets: t.array(t.array(t.string())),
	encounters: t.array(t.number()),
	event: t.number(),
	quests: t.array(t.number()),
	questFirst: t.array(t.string().nullable()),
	players: t.array(se),
	prompt: t.string(),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		card: t.number().optional(),
		n: t.number().optional()
	})),
	final: t.array(t.object({
		rid: t.string(),
		track: t.number(),
		quests: t.number(),
		items: t.number(),
		companions: t.number(),
		skills: t.number(),
		total: t.number()
	}))
}), le = t.object({ choices: t.array(oe) }), F = (e) => e.players[e.turn], ue = (e) => [...e.items, ...e.companions], I = (e, t) => ue(e).includes(t) && !e.exhausted.includes(t), L = (e, t = 1) => ({
	kind: e,
	n: t
});
function R(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function z(e, t, n, r) {
	e.log.push({
		rid: F(e).rid,
		kind: t,
		...n === void 0 ? {} : { card: n },
		...r === void 0 ? {} : { n: r }
	}), e.log = e.log.slice(-100);
}
function de(e) {
	return e.sealDeck.length || (e.sealDeck = R(e, e.sealDiscard), e.sealDiscard = []), e.sealDeck.pop();
}
function fe(e) {
	e.sealDiscard.push(...e.seals.flat()), e.board = e.villageDeck.splice(0, 9), e.seals = e.board.map((t) => Array.from({ length: T[t].seals === -1 ? e.players.length - 1 : T[t].seals ?? 0 }, () => de(e))), e.encounters = e.encounterDeck.splice(0, e.players.length + 3), e.event = e.eventDeck.shift(), e.streets = Array.from({ length: 12 }, () => []), e.players.forEach((e) => {
		e.season = "spring", e.event = null, e.special = !1;
	}), e.turn = e.first, e.phase = "settle", e.queue = [{ kind: "yearReveal" }, { kind: "endSetup" }];
}
function pe(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		revision: 0,
		year: 1,
		first: 0,
		turn: 0,
		phase: "play",
		players: t.map((e) => ({
			rid: e,
			season: "spring",
			coins: 8,
			force: 0,
			magic: 0,
			active: 3,
			reserve: 4,
			camp: 0,
			removed: 0,
			score: 0,
			items: [],
			companions: [],
			exhausted: [],
			untold: [],
			told: [],
			income: [],
			position: 0,
			event: null,
			special: !1,
			bonuses: [
				0,
				1,
				2
			],
			bonusLevel: 0,
			quests: [],
			questPoints: 0
		})),
		board: [],
		seals: [],
		streets: [],
		encounters: [],
		villageDeck: [],
		encounterDeck: [],
		eventDeck: [],
		sealDeck: [],
		sealDiscard: [],
		event: 0,
		quests: [],
		questFirst: [
			null,
			null,
			null
		],
		queue: [],
		log: [],
		final: []
	};
	for (let e = 1; e <= 3; e++) r.villageDeck.push(...R(r, E.filter((t) => t.period === e).map((e) => e.id)).slice(e === 3 ? 0 : 2)), r.encounterDeck.push(...R(r, te.filter((t) => t.period === e).map((e) => e.id)).slice(0, (t.length + 3) * (e === 3 ? 1 : 2)));
	return r.eventDeck = R(r, [
		0,
		1,
		2,
		3,
		4,
		5
	]).slice(0, 5), r.quests = R(r, [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	]).slice(0, 3), r.sealDeck = R(r, Array.from({ length: 24 }, (e, t) => 1 + Math.floor(t / 8))), fe(r), { state: r };
}
var me = (e, t) => t === "items" ? e.items.length : t === "companions" ? e.companions.length : t === "untold" ? e.untold.length : t === "told" ? e.told.length : t === "force" ? e.force : t === "magic" ? e.magic : t === "lowest" ? Math.min(e.force, e.magic) : t === "coins2" ? Math.floor(e.coins / 2) : t === "workersMinus2" ? Math.max(0, 5 - e.reserve - e.removed) : t === "potions" ? e.items.filter((e) => T[e].potion).length : t === "far" ? [...e.untold, ...e.told].filter((e) => A[e].area >= 3).length : t === "banners" ? new Set([...e.untold, ...e.told].map((e) => A[e].area)).size : 0;
function he(e) {
	let t = e.items.reduce((e, t) => e + T[t].score, 0), n = e.companions.reduce((t, n) => t + T[n].score * me(e, T[n].per), 0), r = e.force === 5 && e.magic === 5 ? 5 : e.force >= 3 && e.magic >= 3 ? 2 : 0;
	return {
		rid: e.rid,
		track: e.score,
		quests: e.questPoints,
		items: t,
		companions: n,
		skills: r,
		total: e.score + e.questPoints + t + n + r
	};
}
function ge(e, t) {
	let n = F(e);
	n.score += t, n.bonusLevel === 0 && n.score >= 8 ? (n.bonusLevel = 1, e.queue.unshift({
		kind: "bonus",
		n: 8
	})) : n.bonusLevel === 1 && n.score >= 20 && (n.bonusLevel = 2, e.queue.unshift({
		kind: "bonus",
		n: 20
	}));
}
function B(e, t, n = 0, r) {
	let i = t.map((e) => ({
		...e,
		n: e.n === -1 ? n : e.n
	}));
	i.length > 1 ? e.queue.unshift({
		kind: "rewardOrder",
		gains: i,
		slot: r
	}) : e.queue.unshift(...i.map((e) => ({
		kind: "gain",
		gain: e,
		slot: r
	})));
}
var V = (e, t) => ({
	kind: "window",
	triggers: e,
	next: {
		...t,
		mod: { ...t.mod ?? {} }
	}
});
function _e(e, t) {
	F(e).exhausted.push(t), t !== 309 && I(F(e), 309) && e.queue.unshift({
		kind: "isandre",
		card: t
	});
}
function ve(e, t) {
	e.items = e.items.filter((e) => e !== t), e.exhausted = e.exhausted.filter((e) => e !== t);
}
function H(e, t) {
	return e.streets.reduce((e, n, r) => e + (P[r].includes(t) ? n.length : 0), 0) - 1;
}
function ye(e) {
	return 3 + +!!e.companions.includes(301) + (e.companions.includes(303) ? 2 : 0) + +!!e.items.includes(220);
}
function U(e, t, n = !1) {
	let r = F(e), i = { ...t.mod };
	n && (I(r, 301) && (i.force = (i.force ?? 0) + 1), t.source === "item" && I(r, 307) && (i.workers = (i.workers ?? 0) + 1), t.source === "grid" && t.card >= 200 && t.card < 300 && I(r, 303) && (i.discount = (i.discount ?? 0) + 1), t.source === "grid" && I(r, 306) && (i.freeCrowd = !0), I(r, 305) && !i.seal && (i.seal = 1));
	let a = t.source === "grid" ? T[t.card].cost : 0;
	t.source === "grid" && (a += i.freeCrowd ? 0 : Math.max(0, H(e, t.slot)), a -= i.discount ?? 0);
	let o = t.pay.map(([e, t]) => [e, e === "force" ? Math.max(0, t - (i.force ?? 0)) : e === "workers" ? Math.max(0, t - (i.workers ?? 0)) : t]);
	return o.some(([e]) => e === "sealCoins") && (a += i.seal ?? t.seal), a > 0 && o.push(["coins", a]), o;
}
function be(e, t, n = {}) {
	let r = F(e), i = {};
	for (let [e, n] of t) i[e] = (i[e] ?? 0) + n;
	return Object.entries(i).every(([e, t]) => {
		switch (e) {
			case "coins": return r.coins >= t;
			case "force": return r.force >= t;
			case "magic": return r.magic >= t;
			case "workers":
			case "return": return r.active >= t + (e === "workers" ? i.return ?? 0 : i.workers ?? 0);
			case "haveForce": return r.force + (n.tf ?? 0) >= t;
			case "haveMagic": return r.magic + (n.tm ?? 0) >= t;
			case "haveSkills": return r.force + r.magic + (n.tf ?? 0) + (n.tm ?? 0) >= t;
			case "stories": return r.untold.length >= t;
			case "item": return r.items.length >= t;
			default: return !0;
		}
	});
}
function xe(e, t) {
	let n = F(e);
	for (let [r, i] of t) r === "coins" && (n.coins -= i), r === "force" && (n.force -= i), r === "magic" && (n.magic -= i), r === "workers" && (n.active -= i, n.camp += i), r === "return" && (n.active -= i, n.removed += i), r === "item" && e.queue.unshift({
		kind: "discard",
		n: i,
		slot: 1
	}), r === "stories" && e.queue.unshift({
		kind: "questStories",
		n: i
	});
}
function Se(e) {
	return e.untold.some((e) => A[e].story > 0) || e.untold.length > 0 && (I(e, 310) || I(e, 213));
}
function Ce(e, t) {
	let n = F(e);
	return t.pay.some(([e]) => e === "seal" || e === "sealCoins") && t.seal < 1 || t.gain.some((e) => e.kind === "story") && !Se(n) || t.source === "grid" && t.card >= 300 && n.companions.length >= 3 || t.gain.some((e) => e.kind === "ready") && !n.exhausted.length && t.gain.length === 1 ? !1 : be(e, U(e, t, !0), t.mod);
}
function we(e, t) {
	let n = [];
	t.source === "coins" && n.push("coins"), t.source === "grid" && (H(e, t.slot) > 0 && n.push("crowd"), t.card >= 200 && t.card < 300 && n.push("buy")), t.pay.some(([e]) => e === "force") && n.push("force"), t.source === "item" && t.pay.some(([e]) => e === "workers") && n.push("workers"), t.seal > 0 && n.push("seal"), e.queue.unshift(V(n, {
		kind: "execute",
		plan: t
	}));
}
function W(e, t = 0, n = 0, r = -1, i = -1, a = 0, o = [], s = [], c = {}) {
	return {
		source: e,
		card: t,
		option: n,
		gap: r,
		slot: i,
		seal: a,
		pay: o,
		gain: s,
		mod: c
	};
}
function Te(e) {
	let t = F(e), n = [];
	if (t.season === "spring" ? (t.active > 0 && P.forEach((t, r) => {
		t.some((t) => e.board[t] !== null) && n.push({
			kind: "place",
			gap: r
		});
	}), n.push({ kind: "summer" })) : (e.streets.forEach((r, i) => {
		if (!r.includes(t.rid)) return;
		let a = P[i].filter((t) => e.board[t] !== null);
		a.length || n.push({
			kind: "retrieve",
			gap: i,
			plan: W("coins", 0, 0, i)
		}), a.forEach((t) => {
			let r = e.board[t], a = T[r];
			n.push({
				kind: "coins",
				card: r,
				gap: i,
				slot: t,
				n: Math.max(0, H(e, t)),
				plan: W("coins", r, 0, i, t)
			}), (r < 200 ? a.abilities : [{
				pay: [],
				gain: a.immediate
			}]).forEach((a, o) => {
				(a.pay.some(([e]) => e === "seal" || e === "sealCoins") || r >= 200 && e.seals[t].length > 0 ? [...new Set(e.seals[t])] : [0]).forEach((s) => {
					let c = W("grid", r, o, i, t, s, a.pay, a.gain);
					Ce(e, c) && n.push({
						kind: "activate",
						card: r,
						option: o,
						gap: i,
						slot: t,
						n: s,
						gain: a.gain,
						pay: U(e, c),
						plan: c
					});
				});
			});
		});
	}), t.items.filter((e) => I(t, e)).forEach((t) => T[t].abilities.forEach((r, i) => {
		let a = W("item", t, i, -1, -1, 0, r.pay, r.gain);
		Ce(e, a) && n.push({
			kind: "use",
			card: t,
			option: i,
			gain: r.gain,
			pay: r.pay,
			plan: a
		});
	})), t.active && !t.special && (n.push({
		kind: "special",
		option: 0,
		gain: [L("travel")],
		plan: W("special", 0, 0, -1, -1, 0, [["workers", 1]], [L("travel")])
	}), n.push({
		kind: "special",
		option: 1,
		gain: [L("magic")],
		plan: W("special", 0, 1, -1, -1, 0, [["workers", 1]], [L("magic")])
	}), Se(t) && n.push({
		kind: "special",
		option: 2,
		plan: W("special", 0, 2, -1, -1, 0, [["workers", 1]], [L("story", 0)])
	})), e.streets.some((e) => e.includes(t.rid)) || n.push({ kind: "autumn" })), t.event === null) {
		let r = t.active ? [-1] : [];
		t.season === "summer" && e.streets.forEach((e, n) => {
			e.includes(t.rid) && r.push(n);
		}), r.forEach((t) => j[e.event].abilities.forEach((r, i) => {
			if (e.event === 1 && e.players.some((e) => e.event === i)) return;
			let a = W("event", 0, i, t, -1, 0, r.pay, r.gain);
			Ce(e, a) && n.push({
				kind: "event",
				gap: t,
				option: i,
				gain: r.gain,
				pay: r.pay,
				plan: a
			});
		}));
	}
	return n;
}
function Ee(e, t) {
	let n = F(e), r = t.triggers ?? [], i = t.next, a = i.plan, o = a?.mod ?? i.mod ?? {}, s = [], c = (e, t, i) => {
		I(n, e) && r.includes(t) && s.push({
			kind: "react",
			card: e,
			...i === void 0 ? {} : { n: i }
		});
	}, l = (e) => Math.max(0, ...a?.pay.filter(([t]) => t === e).map(([, e]) => e) ?? [+(e === "force")]);
	if ((o.force ?? 0) < l("force") && c(301, "force"), c(302, "travel"), o.discount || c(303, "buy"), n.magic > 0 && c(304, "encounter"), !o.seal) for (let t = 1; t <= 3; t++) (!a || be(e, U(e, {
		...a,
		mod: {
			...o,
			seal: t
		}
	}, !0), o)) && c(305, "seal", t);
	return o.freeCrowd || c(306, "crowd"), o.extraCoins || c(306, "coins"), (o.workers ?? 0) < l("workers") && c(307, "workers"), o.other || (i.gain?.kind === "magic" && c(308, "skill", 0), i.gain?.kind === "force" && c(308, "skill", 1)), o.story || (c(310, "story"), c(213, "story")), n.active > 0 && P.some((t) => t.some((t) => e.board[t] !== null)) && (c(311, "encounter"), c(311, "travelDone"), c(214, "encounter"), c(214, "travelDone")), c(206, "encounter"), c(207, "encounter"), c(215, "encounter"), c(217, "encounter"), s;
}
function De(e, t = !1) {
	if (t) return e.untold.map((e) => [e]);
	let n = e.untold.filter((e) => A[e].story > 0), r = [];
	function i(e, t) {
		for (let a = e; a < n.length; a++) {
			let e = [...t, n[a]], o = e.map((e) => A[e].story), s = o.reduce((e, t) => e + t, 0);
			(s <= 3 || e.length === 2 && o.every((e) => e === 2)) && r.push(e), s < 3 && e.length < 3 && i(a + 1, e);
		}
	}
	return i(0, []), r;
}
function Oe(e) {
	if (e.phase === "done") return [];
	let t = F(e), n = e.queue[0];
	if (!n) return Te(e);
	let r = n.mod ?? {};
	if (n.kind === "window") {
		let r = Ee(e, n), i = n.next, a = i.plan?.mod ?? i.mod ?? {}, o = !i.plan || be(e, U(e, i.plan), a);
		return i.kind === "story" && !De(t, a.story).length ? r.filter((e) => e.card === 310 || e.card === 213) : [...r, ...o ? [{ kind: "continue" }] : []];
	}
	if (n.kind === "move") return Array.from({ length: 6 }, (e, t) => t).filter((e) => Math.abs(e - t.position) <= n.n + (r.extraTravel ?? 0)).map((e) => ({
		kind: "move",
		n: e
	}));
	if (n.kind === "encounter") {
		let n = [];
		if (e.encounters.filter((e) => A[e].area === t.position).forEach((t) => {
			let i = A[t];
			for (let a = 1; a < 1 << i.outcomes.length; a++) for (let o = 0; o < 1 << i.outcomes.length; o++) {
				if ((o & a) !== o || o.toString(2).replaceAll("0", "").length > (r.ignore ?? 0)) continue;
				let s = i.outcomes.flatMap((e, t) => a & 1 << t && !(o & 1 << t) ? e.pay : []).map(([e, t]) => [e, e === "force" ? Math.max(0, t - (r.force ?? 0)) : t]);
				be(e, s, r) && n.push({
					kind: "encounter",
					card: t,
					option: a,
					n: o,
					pay: s,
					gain: i.outcomes.flatMap((e, t) => a & 1 << t ? e.gain : [])
				});
			}
		}), t.position >= 3 && !t.quests.includes(t.position - 3)) {
			let i = t.position - 3, a = M[e.quests[i]], o = W("quest", 0, 0, -1, i, 0, a.pay, [], {
				tf: r.tf,
				tm: r.tm
			});
			Ce(e, o) && n.push({
				kind: "quest",
				slot: i,
				plan: o,
				pay: a.pay
			});
		}
		return n.push({
			kind: "skipEncounter",
			n: t.position
		}), n;
	}
	if (n.kind === "story") return De(t, r.story).map((e) => ({
		kind: "story",
		cards: e,
		n: r.story ? 3 : Math.min(3, e.reduce((e, t) => e + A[t].story, 0))
	}));
	if (n.kind === "storySeal") return [...new Set(e.seals[n.slot])].map((e) => ({
		kind: "seal",
		n: e
	}));
	if (n.kind === "ready") return [{ kind: "skip" }, ...t.exhausted.map((e) => ({
		kind: "ready",
		card: e
	}))];
	if (n.kind === "skill") return [{
		kind: "skill",
		n: 0
	}, {
		kind: "skill",
		n: 1
	}];
	if (n.kind === "bonus") return t.bonuses.map((e) => ({
		kind: "bonus",
		n: e
	}));
	if (n.kind === "isandre") return [{ kind: "skip" }, ...I(t, 309) && ue(t).includes(n.card) && t.exhausted.includes(n.card) ? [{
		kind: "isandre",
		card: n.card
	}] : []];
	if (n.kind === "placeExtra") return P.flatMap((n, r) => t.active > 0 && n.some((t) => e.board[t] !== null) ? [{
		kind: "placeExtra",
		gap: r
	}] : []);
	if (n.kind === "discard") return t.items.map((e) => ({
		kind: "discard",
		card: e
	}));
	if (n.kind === "questStories") return t.untold.flatMap((e, n) => t.untold.slice(n + 1).map((t) => ({
		kind: "questStories",
		cards: [e, t]
	})));
	if (n.kind === "rewardOrder") {
		let e = n.gains.some((e) => e.kind !== "travel");
		return n.gains.flatMap((t, n) => e && t.kind === "travel" ? [] : [{
			kind: "rewardOrder",
			option: n,
			gain: [t]
		}]);
	}
	return [];
}
function ke(e) {
	return Oe(e).map((t, n) => {
		let r = { ...t };
		return delete r.plan, delete r.task, {
			...r,
			key: `${e.revision}:${n}`
		};
	});
}
function Ae(e) {
	if (e.players.every((e) => e.season === "autumn")) {
		if (e.year === 5) {
			e.players.forEach((e) => {
				e.bonuses = [];
			}), e.final = e.players.map(he), e.phase = "done";
			return;
		}
		e.year++, e.first = (e.first + 1) % e.players.length, fe(e);
		return;
	}
	do
		e.turn = (e.turn + 1) % e.players.length;
	while (F(e).season === "autumn");
	e.phase = "play";
}
function je(e, t) {
	let n = F(e), { source: r, card: i, slot: a, gap: o, option: s, mod: c } = t, l = c.seal ?? t.seal;
	if (xe(e, U(e, t)), r === "grid" || r === "coins") {
		if (e.streets[o].splice(e.streets[o].indexOf(n.rid), 1), n.camp++, r === "coins") {
			n.coins += Math.max(0, a < 0 ? 0 : H(e, a) + 1) + (c.extraCoins ?? 0), z(e, "coins", i, Math.max(0, a < 0 ? 0 : H(e, a) + 1) + (c.extraCoins ?? 0));
			return;
		}
		if (i >= 200 && (e.board[a] = null, i >= 300 ? n.companions.push(i) : n.items.push(i)), t.seal > 0) {
			let n = e.seals[a].indexOf(t.seal);
			e.sealDiscard.push(e.seals[a].splice(n, 1)[0]);
		}
		i >= 200 && i < 300 && (e.queue.unshift({ kind: "checkLimit" }), t.seal > 0 && e.queue.unshift({
			kind: "gain",
			gain: L("vp", l)
		}), c.discount && e.queue.unshift({
			kind: "gain",
			gain: L("vp", 1)
		}));
	} else if (r === "item") i === 203 || (i === 205 || i === 212) && s === 1 ? ve(n, i) : _e(e, i);
	else if (r === "event") o === -1 ? n.active-- : e.streets[o].splice(e.streets[o].indexOf(n.rid), 1), n.event = s;
	else if (r === "special") n.special = !0;
	else if (r === "quest") {
		let t = e.questFirst[a] === null;
		t && (e.questFirst[a] = n.rid), n.quests.push(a), n.questPoints += (t ? 7 : 5) + a;
	}
	z(e, r === "grid" ? "activate" : r, i, s);
	let u = e.queue.splice(0), d = u.filter((e) => [
		"discard",
		"questStories",
		"isandre"
	].includes(e.kind)), f = u.filter((e) => !d.includes(e));
	e.queue.push(...f), B(e, t.gain, l, a), e.queue.unshift(...d);
}
function Me(e, t) {
	let n = e.queue[0], r = n.next, i = F(e), a = t.card, o = r.plan ? r.plan.mod : r.mod ??= {};
	a === 301 && (o.force = (o.force ?? 0) + 1), a === 302 && (o.extraTravel = (o.extraTravel ?? 0) + 2), a === 303 && (o.discount = (o.discount ?? 0) + 1), a === 304 && (i.magic--, o.ignore = (o.ignore ?? 0) + 1), a === 305 && (o.seal = t.n), a === 306 && (n.triggers?.includes("coins") ? o.extraCoins = 2 : o.freeCrowd = !0), a === 307 && (o.workers = (o.workers ?? 0) + 1), a === 308 && (o.other = t.n + 1), (a === 310 || a === 213) && (o.story = !0), a === 206 && (o.tm = (o.tm ?? 0) + 2), a === 207 && (o.tf = (o.tf ?? 0) + 2), a === 215 && (o.tf = (o.tf ?? 0) + 1, o.tm = (o.tm ?? 0) + 1), a === 217 && (o.ignore = (o.ignore ?? 0) + 1), (a === 311 || a === 214) && e.queue.unshift({ kind: "placeExtra" }), T[a].potion && !i.companions.includes(305) ? ve(i, a) : _e(e, a), z(e, "react", a);
}
function Ne(e, t) {
	let n = F(e), r = e.queue[0];
	if (t.kind === "react") {
		Me(e, t);
		return;
	}
	if (t.kind === "continue") {
		e.queue.shift(), e.queue.unshift(r.next);
		return;
	}
	if (!r) {
		if (t.kind === "place") n.active--, e.streets[t.gap].push(n.rid), z(e, "place", void 0, t.gap);
		else if (t.kind === "summer") {
			n.season = "summer", z(e, "summer");
			return;
		} else t.kind === "autumn" ? (n.season = "autumn", e.queue.push({ kind: "home" }, { kind: "recover" }, { kind: "income" }), z(e, "autumn")) : t.plan && we(e, t.plan);
		e.phase = "settle";
		return;
	}
	if (e.queue.shift(), t.kind === "move" && (n.position = t.n, z(e, "move", void 0, t.n), e.queue.unshift(V(["encounter", ...e.encounters.some((e) => A[e].area === n.position && e === 23) ? ["force"] : []], {
		kind: "encounter",
		mod: {}
	}), V(["travelDone"], { kind: "journeyEnd" }))), t.kind === "encounter" && (xe(e, t.pay), e.encounters = e.encounters.filter((e) => e !== t.card), n.untold.push(t.card), z(e, "encounter", t.card), B(e, t.gain ?? [])), t.kind === "quest" && we(e, t.plan), t.kind === "skipEncounter" && (n.position === 1 && n.coins++, n.position === 2 && ge(e, 1)), t.kind === "story") {
		n.untold = n.untold.filter((e) => !t.cards.includes(e)), n.told.push(...t.cards), z(e, "story", void 0, t.n);
		let i = D[r.card ?? 0].slice(0, t.n).flat();
		i.some((e) => e.n === -1) && r.slot !== void 0 && e.seals[r.slot].length ? e.queue.unshift({
			kind: "storySeal",
			slot: r.slot,
			gains: i
		}) : B(e, i.filter((e) => e.n !== -1));
	}
	if (t.kind === "seal" && (e.sealDiscard.push(e.seals[r.slot].splice(e.seals[r.slot].indexOf(t.n), 1)[0]), e.queue.unshift(V(["seal"], {
		kind: "sealReward",
		n: t.n,
		gains: r.gains
	}))), t.kind === "ready" && (n.exhausted = n.exhausted.filter((e) => e !== t.card)), t.kind === "skill" && e.queue.unshift(V(["skill"], {
		kind: "applyGain",
		gain: L(t.n === 0 ? "force" : "magic")
	})), t.kind === "bonus" && (n.bonuses = r.n === 20 ? [] : n.bonuses.filter((e) => e !== t.n), B(e, t.n === 0 ? [L("coins", 5)] : t.n === 1 ? [L("force"), L("magic")] : [L("worker")]), r.n === 8 && n.score >= 20 && n.bonusLevel === 1 && (n.bonusLevel = 2, e.queue.unshift({
		kind: "bonus",
		n: 20
	})), z(e, "bonus", void 0, t.n)), t.kind === "isandre" && (n.exhausted.push(309), n.exhausted = n.exhausted.filter((e) => e !== t.card), z(e, "react", 309)), t.kind === "placeExtra" && (n.active--, e.streets[t.gap].push(n.rid), z(e, "place", void 0, t.gap)), t.kind === "discard" && (ve(n, t.card), z(e, "discard", t.card), r.slot !== 1 && n.items.length > ye(n) && e.queue.unshift({ kind: "discard" })), t.kind === "questStories" && (n.untold = n.untold.filter((e) => !t.cards.includes(e)), n.told.push(...t.cards)), t.kind === "rewardOrder") {
		let n = r.gains.filter((e, n) => n !== t.option);
		n.length && e.queue.unshift({
			...r,
			gains: n
		}), e.queue.unshift({
			kind: "gain",
			gain: r.gains[t.option],
			slot: r.slot
		});
	}
	e.phase = "settle";
}
function Pe(e) {
	let t = F(e), n = e.queue.shift(), r = [], i = e.turn, a = t.position;
	if (n.kind === "gain" && n.gain?.kind === "worker" && t.reserve && r.push({
		asset: "villager",
		from: `reserve:${t.rid}`,
		to: `resource:${t.rid}:active`,
		fallback: `seat:${t.rid}`,
		color: i
	}), n.kind === "execute") {
		let e = n.plan;
		e.source === "grid" || e.source === "coins" ? (r.push({
			asset: "villager",
			from: `gap:${e.gap}`,
			to: `camp:${t.rid}`,
			fallback: `seat:${t.rid}`,
			color: i
		}), e.source === "grid" && e.card >= 200 && r.push({
			asset: "card",
			id: e.card,
			from: `village:${e.slot}`,
			to: `owned:${e.card}`,
			fallback: `seat:${t.rid}`,
			hide: `owned:${e.card}`
		})) : e.source === "event" ? r.push({
			asset: "villager",
			from: e.gap < 0 ? `resource:${t.rid}:active` : `gap:${e.gap}`,
			to: "event",
			fallback: `seat:${t.rid}`,
			color: i
		}) : e.source === "quest" ? r.push({
			asset: "quest",
			from: `quest-stock:${t.rid}`,
			to: `quest-marker:${e.slot}:${t.rid}`,
			hide: `quest-marker:${e.slot}:${t.rid}`,
			fallback: `seat:${t.rid}`,
			color: i
		}) : e.source === "item" && (e.card === 203 || (e.card === 205 || e.card === 212) && e.option === 1) && r.push({
			asset: "card",
			id: e.card,
			from: `owned-slot:${e.card}`,
			to: "discard"
		});
	}
	n.kind === "home" && a !== 0 && r.push({
		asset: "pawn",
		from: `pawn-slot:${a}:${t.rid}`,
		to: `pawn-slot:0:${t.rid}`,
		hide: `pawn:${t.rid}`,
		color: i
	}), n.kind === "recover" && (t.camp && r.push({
		asset: "villager",
		from: `camp:${t.rid}`,
		to: `resource:${t.rid}:active`,
		fallback: `seat:${t.rid}`,
		color: i
	}), t.event !== null && r.push({
		asset: "villager",
		from: "event",
		to: `resource:${t.rid}:active`,
		fallback: `seat:${t.rid}`,
		color: i
	}));
	let o = {
		kind: "resolve",
		rid: t.rid,
		data: {
			kind: n.kind,
			...n.card === void 0 ? {} : { card: n.card }
		}
	};
	if (n.kind === "execute") je(e, n.plan);
	else if (n.kind === "gain") {
		let r = n.gain;
		if (r.kind === "force" || r.kind === "magic") e.queue.unshift(V(["skill"], {
			kind: "applyGain",
			gain: r
		}));
		else if (r.kind === "coins") t.coins += r.n;
		else if (r.kind === "vp") ge(e, r.n);
		else if (r.kind === "worker") {
			let e = Math.min(t.reserve, r.n);
			t.reserve -= e, t.active += e;
		} else r.kind === "skill" || r.kind === "ready" ? e.queue.unshift({ kind: r.kind }) : r.kind === "income" ? (t.income.push(r.n), B(e, [N[r.n]])) : r.kind === "count" ? ge(e, r.n * me(t, r.ref)) : r.kind === "travel" ? e.queue.unshift(V(["travel"], {
			kind: "move",
			n: r.n
		})) : r.kind === "story" && e.queue.unshift(V(["story"], {
			kind: "story",
			card: r.n,
			slot: n.slot
		}));
		o.data = {
			kind: r.kind,
			n: r.n
		};
	} else if (n.kind === "applyGain") {
		let r = n.gain, i = r.kind, a = Math.max(0, t[i] + r.n - 5);
		t[i] = Math.min(5, t[i] + r.n), n.mod?.other && e.queue.unshift({
			kind: "applyGain",
			gain: L(n.mod.other === 1 ? "force" : "magic")
		}), a && ge(e, a), o.data = {
			kind: i,
			n: r.n
		};
	} else n.kind === "sealReward" ? B(e, n.gains, n.mod?.seal ?? n.n) : n.kind === "checkLimit" && t.items.length > ye(t) ? e.queue.unshift({ kind: "discard" }) : n.kind === "home" ? t.position = 0 : n.kind === "recover" ? (t.active += t.camp + (t.event === null ? 0 : 1), t.camp = 0, t.event = null, t.exhausted = []) : n.kind === "income" ? B(e, [L("coins", 3 - t.companions.length), ...t.income.map((e) => N[e])]) : n.kind === "endSetup" && (e.phase = "play");
	return r.length && (o.data = {
		...o.data,
		moves: r
	}), [o];
}
function Fe(e) {
	let t = e.queue[0];
	return t ? t.kind === "window" ? Ee(e, t).length === 0 : t.kind === "placeExtra" ? !Oe(e).length : t.kind === "ready" ? F(e).exhausted.length === 0 : ![
		"move",
		"encounter",
		"story",
		"storySeal",
		"ready",
		"skill",
		"bonus",
		"isandre",
		"placeExtra",
		"discard",
		"questStories",
		"rewardOrder"
	].includes(t.kind) : e.phase === "settle";
}
function Ie(e, t, n) {
	if (e.phase === "done") return { code: "games.greylune.invalid" };
	if (t.type === "tick") {
		if (!Fe(e)) return { code: "games.greylune.invalid" };
		let t = structuredClone(e);
		t.revision++;
		let n = [];
		if (!t.queue.length) Ae(t), t.year !== e.year && (n = [{
			kind: "reveal",
			data: { cards: t.board }
		}]);
		else if (t.queue[0].kind === "window") {
			let e = t.queue.shift();
			t.queue.unshift(e.next);
		} else n = Pe(t);
		return {
			state: t,
			fx: n
		};
	}
	if (n.by !== F(e).rid || Fe(e)) return { code: "games.greylune.invalid" };
	let r = ke(e).findIndex((e) => e.key === t.key);
	if (r < 0) return { code: "games.greylune.invalid" };
	let i = Oe(e)[r], a = structuredClone(e);
	a.revision++;
	let o = F(e), s = e.turn, c = [];
	return (i.kind === "place" || i.kind === "placeExtra") && c.push({
		asset: "villager",
		from: `resource:${o.rid}:active`,
		to: `worker:${i.gap}:${e.streets[i.gap].length}`,
		hide: `worker:${i.gap}:${e.streets[i.gap].length}`,
		fallback: `seat:${o.rid}`,
		color: s
	}), i.kind === "move" && c.push({
		asset: "pawn",
		from: `pawn-slot:${o.position}:${o.rid}`,
		to: `pawn-slot:${i.n}:${o.rid}`,
		hide: `pawn:${o.rid}`,
		color: s
	}), i.kind === "encounter" && c.push({
		asset: "encounter",
		id: i.card,
		from: `encounter:${i.card}`,
		to: `story:${i.card}`,
		fallback: `seat:${o.rid}`,
		hide: `story:${i.card}`
	}), (i.kind === "story" || i.kind === "questStories") && i.cards?.forEach((e) => c.push({
		asset: "encounter",
		id: e,
		from: `story:${e}`,
		to: `told:${o.rid}`,
		fallback: `seat:${o.rid}`
	})), (i.kind === "discard" || i.kind === "react" && T[i.card].potion && !o.companions.includes(305)) && c.push({
		asset: "card",
		id: i.card,
		from: `owned-slot:${i.card}`,
		to: "discard",
		fallback: `seat:${o.rid}`
	}), Ne(a, i), {
		state: a,
		fx: [{
			kind: "act",
			rid: n.by,
			data: {
				kind: i.kind,
				moves: c,
				...i.card === void 0 ? {} : { card: i.card },
				...i.gap === void 0 ? {} : { gap: i.gap },
				...i.n === void 0 ? {} : { n: i.n }
			}
		}]
	};
}
function Le(e, t) {
	return {
		public: {
			revision: e.revision,
			year: e.year,
			phase: e.phase,
			turn: F(e).rid,
			first: e.players[e.first].rid,
			board: e.board,
			seals: e.seals,
			streets: e.streets,
			encounters: e.encounters,
			event: e.event,
			quests: e.quests,
			questFirst: e.questFirst,
			players: e.players,
			prompt: e.queue[0]?.kind ?? F(e).season,
			log: e.log,
			final: e.final
		},
		private: { choices: t === F(e).rid && !Fe(e) ? ke(e) : [] }
	};
}
var Re = {
	meta: ne,
	saveCompatibility: { version: "1" },
	schemas: {
		action: re,
		publicView: ce,
		privateView: le
	},
	setup: pe,
	reduce: Ie,
	viewFor: Le,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.final.map((e) => [e.rid, e.total])), n = [...e.players.map((e) => e.rid)].sort((e, n) => t[n] - t[e]);
		return {
			phase: "done",
			scores: t,
			ranking: n,
			winner: n.filter((e) => t[e] === t[n[0]])
		};
	},
	nextTickIn: (e) => e.phase !== "done" && Fe(e) ? 520 : null
}, ze = {
	name: "Greylune",
	desc: "Gather villagers, recruit companions and tell the stories of five years of adventure.",
	invalid: "That action is no longer available. Choose a current action.",
	rules: "Goal:\nAfter five years, the highest total of immediate points, quests, items, companions and skills wins. Ties are shared.\nSetup:\nEach player starts with 3 active villagers, 4 in reserve, 8 coins, and no Strength or Magic. Each year has a 3×3 village, five encounters with two players, six with three, or seven with four and one event. Three random quests occupy areas 3, 4 and 5. Remove two village cards from each of periods I and II.\nSeasons and turns:\nPlayers take turns clockwise but advance through seasons independently. In Spring, choose one of these actions:\n· Place one active villager in an internal gap between two adjacent village slots, at least one containing a card. Gaps have no occupancy limit.\n· Attend this year’s event.\n· Enter Summer and immediately take a Summer action.\nIn Summer, retrieve one of your villagers from a gap and name an adjacent card. Gain coins equal to all other villagers around it, or pay its printed cost plus one coin per other adjacent villager to activate a building, buy an item or recruit a companion. The villager goes to camp. If both slots are empty, you may still retrieve it for no coins. Buildings stay; purchased cards leave. A companion costs 7 coins, brings one villager and is limited to three. Items normally have a limit of three; choose discards after immediate gains. Some companions and the Bag of Holding raise this limit.\nYou may also exhaust an item and pay its cost, or use your annual special action: spend one active villager to travel up to one space, gain one Magic or tell a story. Attend the event once per year using an active villager, or in Summer one from the village. Festival spaces are exclusive but become available when their occupant enters Autumn.\nEnter Autumn only when none of your villagers remain in the village. Return your adventurer home, recover villagers from camp, the event and the special action, ready every card and gain three coins, reduced by one coin per companion, and collect all income-token rewards. When everyone reaches Autumn, start a new year and pass the first-player token left. Income is also collected in year five.\nAdventures, reactions and stories:\nTravel up to the given distance in either direction, including staying put. Resolve one encounter in your destination, take the alternative reward (one coin in area 1 or one point in area 2), or complete the quest in areas 3–5. Choose either encounter side or both. All selected requirements must be met and paid together before any reward. Extra travel is resolved last. Keep resolved encounters as untold stories. Each player may complete each quest once. For quests in areas 3, 4 and 5, the first player to finish scores 7, 8 and 9 final points respectively; later finishers score 5, 6 and 7 respectively.\nUse companions and potions at their matching reaction windows. Potions are discarded, or exhausted instead with Selia. Permanent companion powers still work while exhausted. Temporary skills may exceed 5 but cannot be spent as real skills and give no overflow points. Ignoring a requirement works on encounters, never on quests.\nTell stories by moving untold encounters to the told area, with a total story value capped at 3; receive all reached tavern tiers. Each encounter card used must contribute story value, subject to these restrictions:\n· A card with story value 0 cannot be used.\n· A card with story value 3 must be used alone.\n· Two cards with story value 2 may count as a combined story value of 3. Seren or the Charisma Potion may turn one encounter into a 3. A tavern without seals still hears stories, skipping only the tier requiring a seal.\nScoring and end:\nStrength and Magic are capped at 5; each excess permanent point immediately scores 1 VP. On first reaching 8 and 20 immediate VP, choose an unused bonus: 5 coins, one Strength and one Magic, or one villager. At 20 discard all remaining bonuses. Final scoring never triggers bonuses.\nAfter Autumn of year five, add quest, retained item and companion scores. Having both skills at least 3 gives 2 points; having both at 5 gives 5 instead.",
	ui: {
		finalPoints: "Final VP",
		immediate: "Immediate gain",
		companionScoring: "Scored by companion ability",
		potion: "Potion",
		confirm: "Confirm",
		cancel: "Cancel",
		viewFinal: "View final village",
		restoreResult: "Open scorebook",
		confirmAgain: "Start a new game?",
		confirmLobby: "Return to the lobby?",
		winner: "Winner",
		active: "Active",
		abilities: "Actions",
		quests: "Quests",
		points: "Points",
		emptyInventory: "No items or companions yet",
		emptyStories: "No stories yet",
		year: "Year",
		coins: "Coins",
		force: "Strength",
		magic: "Magic",
		skills: "Skills",
		workers: "Active villagers",
		worker: "Villager",
		vp: "VP",
		reserve: "Reserve",
		camp: "Camp",
		haveForce: "Strength at least",
		haveMagic: "Magic at least",
		haveSkills: "Combined skills at least",
		return: "Permanently remove an active villager",
		item: "Discard an item",
		stories: "Tell encounters",
		seal: "Discard a seal",
		sealCoins: "Discard a seal and pay its value in coins",
		travel: "Travel",
		ready: "Ready a card",
		skill: "Strength or Magic",
		income: "Income",
		story: "Tell a story",
		count: "VP per matching card",
		sealValue: "Set seal value to {{n}}",
		spring: "Spring",
		summer: "Summer",
		autumn: "Autumn",
		done: "Journey’s end",
		village: "Village",
		adventure: "Adventure road",
		event: "Annual event",
		inventory: "My belongings",
		companions: "Companions",
		items: "Items",
		untold: "Untold stories",
		told: "Told stories",
		quest: "Heroic quest",
		place: "Place a villager",
		placeExtra: "Place an active villager in a gap",
		retrieve: "Retrieve a villager",
		coinsAction: "Gain coins",
		activate: "Activate / buy",
		use: "Use item",
		special: "Special action",
		autumnAction: "Enter Autumn",
		summerAction: "Enter Summer",
		react: "Use reaction",
		continue: "Continue",
		skip: "Pass",
		move: "Travel to",
		encounter: "Resolve encounter",
		skipEncounter: "Take area reward / end adventure",
		discard: "Discard",
		bonus: "Choose bonus",
		isandre: "Exhaust Isandre and ready this card",
		questStories: "Tell two encounters",
		rewardOrder: "Collect reward",
		choose: "Choose action",
		waiting: "Waiting for",
		resolving: "Resolving",
		cost: "Pay",
		reward: "Gain",
		none: "None",
		close: "Close",
		inspect: "Inspect",
		all: "All",
		street: "Gap",
		empty: "Empty ground",
		exhausted: "Exhausted",
		first: "First player",
		track: "Immediate VP",
		total: "Total",
		finalSkills: "Skill bonus",
		again: "Play again",
		lobby: "Back to lobby",
		journal: "Travel journal",
		select: "Select a card or gap to see its actions",
		of: "No.",
		side: "Side",
		both: "Both sides"
	},
	prompts: {
		rewardOrder: "Choose the next reward",
		spring: "Place a villager or enter Summer",
		summer: "Retrieve villagers or use items",
		window: "Choose whether to react",
		move: "Choose a destination",
		encounter: "Choose an encounter, quest or area reward",
		story: "Choose stories to tell",
		storySeal: "Choose a tavern seal",
		ready: "Choose a card to ready",
		skill: "Choose a skill",
		bonus: "Choose a bonus",
		isandre: "Choose whether to ready the card just exhausted",
		placeExtra: "Choose a gap for your active villager",
		discard: "Choose an item to discard",
		questStories: "Choose two encounters to tell",
		settle: "Resolving"
	},
	potions: {
		206: "Gain two temporary Magic during the adventure.",
		207: "Gain two temporary Strength during the adventure.",
		213: "Tell one encounter as a value-3 story.",
		214: "Place one active villager in the village.",
		215: "Gain one temporary Strength and one temporary Magic during the adventure.",
		217: "Ignore one encounter requirement on an adventure."
	},
	reactions: [
		"Pay one less Strength. Item limit +1. Score one VP per Strength.",
		"Travel up to two extra spaces. Score one VP per encounter from areas 3, 4 or 5.",
		"An item costs one coin less and scores one VP. Item limit +2. Score one VP per item.",
		"Spend one Magic on an adventure to ignore one encounter requirement. Score one VP per Magic.",
		"Choose a discarded seal’s value from 1–3. Potions exhaust instead of discarding. Score two VP per potion.",
		"Gain two extra coins on retrieval, or ignore the village crowd surcharge. Score one VP per two coins.",
		"Spend one less villager to use an item. Score one VP per recruited villager, minus two.",
		"When gaining a skill, gain one of the other. Score the lower skill level.",
		"Ready another card just exhausted. Score two VP per companion.",
		"Tell one encounter as a value-3 story. Score one VP per told encounter.",
		"Place an active villager in the village on an adventure. Score one VP per distinct encounter area."
	]
}, Be = {
	name: "灰月",
	desc: "在四季流转中召集村民、招募同伴，踏上旅途并传颂冒险故事。",
	invalid: "此操作已不可用，请选择当前可用的操作。",
	rules: "目标:\n五年结束后，总分最高的玩家获胜，平分共享胜利。总分包括即时分、任务、物品、同伴及技能奖励。\n准备:\n每人有3名活跃村民、4名储备村民、8枚钱币、0 点力量及 0 点魔法。城镇每年翻开9张牌组成3行3列的牌阵，并在两人、三人或四人游戏中，分别翻开 5 张、6 张或 7 张遭遇牌及1个事件；3项随机任务放在距离3、4、5的区域。第一、二时期各移除2张城镇牌。\n季节与回合:\n玩家按顺时针方向行动，但各自独立推进季节。春季可以选择以下行动之一：\n· 将 1 名活跃村民放在两张相邻城镇牌之间的内街，其中一格为空也可以。内街不限制村民人数。\n· 参加本年的事件。\n· 转入夏季，并立即进行一次夏季行动。\n夏季可从街道取回自己的1名村民并选择相邻牌：领取等于其余相邻村民数的钱币，或支付牌费及其余相邻村民数的钱币来使用建筑、购买物品或招募同伴。取回的村民进入营地；两侧均为空时仍可取回，但不获钱币。建筑保留，物品和同伴取走。同伴固定花费 7 枚钱币并立即获得1名村民，最多3张；物品默认最多3张，超出时自行弃置，立即奖励先结算。同伴和次元袋可提高物品上限。\n夏季还可横置物品并支付其费用，或使用每年一次的特殊行动：支付1名活跃村民，移动至多1格、获得 1 点魔法，或讲故事。事件每人每年仅参加一次；春季参加事件时使用活跃村民；夏季也可以取回街道上自己的村民来参加事件。节庆的位置互斥，玩家秋季离开后可复用。\n仅当街道上没有自己的村民时才能转入秋季：冒险者回村，营地、事件及特殊行动的村民回到活跃区，竖置全部牌，领取3枚钱币，但每拥有一名同伴就少领取1枚钱币；此外，领取所有收入标记的奖励。各玩家均到秋季后开始新年，起始玩家左移；第五年也领取收入。\n冒险、反应与故事:\n移动不超过所示距离，可向任一方向或停留。到达后可解决1张该区域的遭遇牌，或领取区域替代奖励（距离为 1 的区域获得 1 枚钱币，距离为 2 的区域获得 1 分），或完成距离3至5的任务。遭遇可选左侧、右侧或两侧，所有所选条件必须在领取任何奖励之前同时满足并支付；额外移动最后结算。将完成的遭遇收入未讲故事区。\n每人每项任务仅完成一次，在距离 3、4、5 的任务中，首位完成者依次获得 7 分、8 分、9 分终局分数；后来完成者依次获得 5 分、6 分、7 分。\n同伴及药水在对应动作的反应窗口使用；药水弃置，拥有塞莉娅时改为横置。同伴的永久效果横置后仍生效。临时技能值可以超过5点，但不能作为真实技能支付，不产生溢出分；忽略条件只适用于遭遇，不能用于任务。\n讲故事将未讲遭遇移入已讲区，总故事值最多3，逐层累计领取酒馆奖励。使用的每张遭遇牌都必须贡献故事值，并遵守以下限制：\n· 不能使用故事值为0的牌。\n· 故事值为3的牌不能与其他牌搭配。\n· 可以将两张故事值为2的牌合计按3点故事值计算。\n瑟伦或魅力药水可以将一张遭遇牌的故事值变为3。酒馆无封印时仍可讲故事，只跳过依赖封印的一层。\n计分与结束:\n力量与魔法的上限各为5点，每溢出1点立即获得 1 分。即时分首次达到8和20时，各选一个未用奖励：5 枚钱币、1 点力量及 1 点魔法，或 1 名村民；达到20后弃掉其余奖励。终局计分不触发奖励。\n第五年秋季结束后，将任务、保留物品及同伴的终局分数加入总分。力量和魔法均达到 3 点时，额外获得 2 分；两者均达到 5 点时，这项奖励改为 5 分。",
	ui: {
		finalPoints: "终局分",
		immediate: "立即获得",
		companionScoring: "按同伴能力计分",
		potion: "药水",
		confirm: "确认",
		cancel: "取消",
		viewFinal: "回看最终局面",
		restoreResult: "查看计分册",
		confirmAgain: "确定开始新的一局？",
		confirmLobby: "确定返回大堂？",
		winner: "获胜者",
		active: "活跃",
		abilities: "行动",
		quests: "任务",
		points: "分数",
		emptyInventory: "暂无物品或同伴",
		emptyStories: "暂无故事",
		year: "年",
		coins: "钱币",
		force: "力量",
		magic: "魔法",
		skills: "技能",
		workers: "活跃村民",
		worker: "村民",
		vp: "分",
		reserve: "储备",
		camp: "营地",
		haveForce: "力量至少",
		haveMagic: "魔法至少",
		haveSkills: "力量与魔法合计至少",
		return: "永久移除活跃村民",
		item: "弃置物品",
		stories: "讲述遭遇",
		seal: "弃置封印",
		sealCoins: "弃置封印并支付等值钱币",
		travel: "移动",
		ready: "竖置一张牌",
		skill: "力量或魔法",
		income: "收入",
		story: "讲故事",
		count: "每项得分",
		sealValue: "封印值设为{{n}}",
		spring: "春季",
		summer: "夏季",
		autumn: "秋季",
		done: "旅途落幕",
		village: "城镇",
		adventure: "冒险道路",
		event: "年度事件",
		inventory: "我的行囊",
		companions: "同伴",
		items: "物品",
		untold: "未讲故事",
		told: "已讲故事",
		quest: "英雄任务",
		place: "放置村民",
		placeExtra: "将活跃村民放入街道",
		retrieve: "取回村民",
		coinsAction: "领取钱币",
		activate: "使用／购买",
		use: "使用物品",
		special: "特殊行动",
		autumnAction: "进入秋季",
		summerAction: "进入夏季",
		react: "发动反应",
		continue: "继续",
		skip: "跳过",
		move: "前往",
		encounter: "解决遭遇",
		skipEncounter: "领取区域奖励／结束冒险",
		discard: "弃置",
		bonus: "选择奖励",
		isandre: "横置伊桑德尔并竖置此牌",
		questStories: "讲述两张遭遇",
		rewardOrder: "领取奖励",
		choose: "选择操作",
		waiting: "等待",
		resolving: "结算中",
		cost: "支付",
		reward: "获得",
		none: "无",
		close: "关闭",
		inspect: "查看",
		all: "全部",
		street: "街道",
		empty: "空地",
		exhausted: "已横置",
		first: "起始玩家",
		track: "即时分",
		total: "总分",
		finalSkills: "技能奖励",
		again: "再来一局",
		lobby: "返回大堂",
		journal: "旅途记录",
		select: "请选择牌或街道，查看可用操作",
		of: "第",
		side: "条件",
		both: "同时满足两侧"
	},
	prompts: {
		rewardOrder: "选择先领取的奖励",
		spring: "放置村民或进入夏季",
		summer: "取回村民或使用物品",
		window: "选择是否发动反应",
		move: "选择目的地",
		encounter: "选择遭遇、任务或区域奖励",
		story: "选择要讲述的故事",
		storySeal: "选择酒馆封印",
		ready: "选择要竖置的牌",
		skill: "选择一项技能",
		bonus: "选择一个奖励",
		isandre: "选择是否竖置刚横置的牌",
		placeExtra: "选择一条街道放置村民",
		discard: "选择要弃置的物品",
		questStories: "选择两张遭遇讲述",
		settle: "正在结算"
	},
	potions: {
		206: "冒险期间临时获得2魔法。",
		207: "冒险期间临时获得2力量。",
		213: "讲故事时将单张遭遇的故事值变为3。",
		214: "将1名活跃村民放入城镇。",
		215: "冒险期间临时获得1力量和1魔法。",
		217: "冒险时忽略遭遇的一项条件。"
	},
	reactions: [
		"支付力量时少支付1点；物品上限增加1。终局每点力量1分。",
		"冒险移动距离增加2。终局每张距离3、4或5的遭遇1分。",
		"购买物品少支付1钱币并获得1分；物品上限增加2。终局每件物品1分。",
		"冒险时支付1魔法，忽略遭遇的一项条件。终局每点魔法1分。",
		"弃置封印时将其值设为1至3；使用药水改为横置。终局每瓶药水2分。",
		"取回村民领钱币时额外获得2钱币，或使用城镇牌时免除其他村民附加费。终局每2钱币1分。",
		"使用自己物品时少支付1名村民。终局每名已获得村民（减2）1分。",
		"获得力量或魔法时获得另一项技能1点。终局较低的技能每点1分。",
		"另一张自己的牌横置后，将其竖置。终局每张同伴2分。",
		"讲故事时将单张遭遇的故事值变为3。终局每张已讲遭遇1分。",
		"冒险时将1名活跃村民放入城镇。终局遭遇每种不同区域标记1分。"
	]
}, G = (e) => e ? ze : Be;
function K(e, t, n = !1) {
	let r = n ? A[e] : T[e];
	return r ? t ? r.name : r.zh : "";
}
function q(e, t) {
	let n = G(t).ui[e.kind] ?? e.kind;
	if (e.kind === "income") return t ? `Gain income: ${q(N[e.n], !0)}` : `获得收入标记：${q(N[e.n], !1)}`;
	if (e.kind === "story" || e.kind === "ready") return n;
	if (e.kind === "count") {
		let n = {
			items: ["件物品", "item"],
			companions: ["张同伴", "companion"],
			told: ["张已讲遭遇", "told encounter"],
			untold: ["张未讲遭遇", "untold encounter"]
		}[e.ref ?? ""];
		return t ? `Gain ${e.n} point(s) for each ${n?.[1] ?? "matching card"}` : `每${n?.[0] ?? "项"}获得${e.n}分`;
	}
	let r = e.n === -1 ? t ? "the seal value" : "封印值" : `${e.n}`;
	return e.kind === "travel" ? t ? `Move up to ${r} space(s)` : `移动至多${r}格` : e.n === -1 && !t ? `获得与封印值等量的${n}` : t ? `Gain ${r} ${n.toLowerCase()}` : `获得${r}${e.kind === "worker" ? "名" : e.kind === "coins" ? "枚" : e.kind === "vp" ? "" : "点"}${n}`;
}
function Ve(e, t) {
	let n = G(t).ui, r = n[{
		coins: "coinsAction",
		autumn: "autumnAction",
		summer: "summerAction"
	}[e.kind] ?? e.kind] ?? n.choose, i = e.card ? K(e.card, t, e.kind === "encounter") : "", a = e.kind === "encounter" ? ` · ${e.option === 3 ? n.both : `${n.side} ${e.option}`}` : "", o = e.cards?.map((e) => K(e, t, !0)).join(" + ") ?? "", s = e.gap !== void 0 && e.gap >= 0 ? ` · ${n.street} ${e.gap + 1}` : "", c = e.kind === "react" && e.card === 305 ? n.sealValue.replace("{{n}}", `${e.n}`) : e.kind === "bonus" ? [
		t ? "5 coins" : "5枚钱币",
		t ? "1 Strength and 1 Magic" : "1点力量与1点魔法",
		t ? "1 villager" : "1名村民"
	][e.n] : e.kind === "skill" ? e.n === 0 ? n.force : n.magic : e.kind === "coins" ? `${e.n} ${n.coins}` : ["move", "seal"].includes(e.kind) ? `${e.n}` : "", l = e.gain?.map((e) => q(e, t)).join(" · ");
	return `${r}${i ? ` · ${i}` : ""}${o ? ` · ${o}` : ""}${s}${a}${c ? ` · ${c}` : ""}${l ? ` → ${l}` : ""}`;
}
//#endregion
//#region src/games/greylune/art.tsx
var He = [
	"firstplayer",
	"wand",
	"bow",
	"hammer",
	"swords",
	"edge"
], Ue = {
	coins: "gold",
	force: "strength",
	magic: "magic",
	worker: "villager",
	workers: "spendvillager",
	return: "withdraw",
	travel: "move",
	vp: "victorypoint",
	story: "story",
	stories: "story",
	income: "income",
	ready: "tilt",
	item: "object",
	count: "victorypoint",
	haveForce: "strength",
	haveMagic: "magic"
};
function J({ kind: e, label: t = "" }) {
	return [
		"skill",
		"skills",
		"haveSkills"
	].includes(e) ? /* @__PURE__ */ p("span", {
		className: "gl-icon gl-icon-pair",
		role: t ? "img" : void 0,
		"aria-label": t || void 0,
		children: [
			/* @__PURE__ */ f(J, { kind: "force" }),
			/* @__PURE__ */ f("small", { children: e === "skill" ? "/" : "+" }),
			/* @__PURE__ */ f(J, { kind: "magic" })
		]
	}) : e === "seal" || e === "sealCoins" ? /* @__PURE__ */ p("span", {
		className: `gl-icon gl-seal-cost${e === "sealCoins" ? " gl-seal-coins" : ""}`,
		role: t ? "img" : void 0,
		"aria-label": t || void 0,
		children: [
			/* @__PURE__ */ f("img", {
				src: "games/greylune/seal-back.svg",
				alt: ""
			}),
			/* @__PURE__ */ f("i", { children: "×" }),
			e === "sealCoins" && /* @__PURE__ */ f(J, { kind: "coins" })
		]
	}) : /^income[1-8]$/.test(e) ? /* @__PURE__ */ f("img", {
		className: "gl-icon",
		src: `games/greylune/income-${e.slice(6)}.svg`,
		alt: t,
		draggable: !1
	}) : /* @__PURE__ */ f("img", {
		className: "gl-icon",
		src: `games/greylune/icon-${Ue[e] ?? e}.svg`,
		alt: t,
		draggable: !1
	});
}
function Y() {
	return /* @__PURE__ */ f("svg", {
		className: "gl-target",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "5",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "7 5",
			vectorEffect: "non-scaling-stroke"
		})
	});
}
function We(e, t) {
	return {
		items: ["物品", "items"],
		companions: ["同伴", "companions"],
		told: ["已讲遭遇", "told encounters"],
		untold: ["未讲遭遇", "untold encounters"],
		force: ["力量", "Strength"],
		magic: ["魔法", "Magic"],
		far: ["距离3–5遭遇", "area 3–5 encounters"],
		potions: ["药水", "potions"],
		coins2: ["每2钱币", "2 coins"],
		workersMinus2: ["村民−2", "villagers−2"],
		lowest: ["较低技能", "lower skill"],
		banners: ["不同区域", "distinct areas"]
	}[e]?.[+!!t] ?? "";
}
function X({ gains: e }) {
	let t = s((e) => e.locale) === "en";
	return /* @__PURE__ */ f("span", {
		className: "gl-symbols",
		children: e.map((e, n) => /* @__PURE__ */ p("span", {
			title: q(e, t),
			"aria-label": q(e, t),
			children: [
				/* @__PURE__ */ f(J, { kind: e.kind === "income" ? `income${e.n}` : e.kind }),
				/* @__PURE__ */ f("b", { children: [
					"story",
					"ready",
					"income"
				].includes(e.kind) ? "" : e.n < 0 ? "?" : e.n }),
				e.kind === "count" && /* @__PURE__ */ p("small", { children: ["× ", We(e.ref ?? "", t)] })
			]
		}, n))
	});
}
function Ge({ price: e, verbose: t = !1 }) {
	let n = G(s((e) => e.locale) === "en").ui;
	return /* @__PURE__ */ f("span", {
		className: "gl-symbols",
		children: e.map(([e, r], i) => /* @__PURE__ */ p("span", {
			title: `${n[e] ?? e} ${r}`,
			children: [
				/* @__PURE__ */ f(J, {
					kind: e,
					label: n[e] ?? e
				}),
				/* @__PURE__ */ p("b", { children: [e.startsWith("have") ? "≥" : "", r] }),
				t && /* @__PURE__ */ f("small", { children: n[e] })
			]
		}, i))
	});
}
function Z({ id: e, encounter: t = !1, compact: n = !1 }) {
	let r = s((e) => e.locale) === "en", i = G(r).ui, a = T[e], o = A[e], c = t || a.cost > 0 || a.immediate.length > 0 || a.score > 0 || a.potion;
	return /* @__PURE__ */ p("span", {
		className: `gl-face ${t ? "gl-face-encounter" : e < 200 ? "gl-face-building" : e < 300 ? "gl-face-item" : "gl-face-companion"}${n ? " gl-face-compact" : ""}`,
		children: [
			/* @__PURE__ */ f("strong", {
				className: "gl-card-title",
				children: K(e, r, t)
			}),
			/* @__PURE__ */ f("img", {
				className: "gl-illustration",
				src: `games/greylune/${t ? "encounter" : "card"}-${e}.svg`,
				alt: "",
				draggable: !1
			}),
			c && /* @__PURE__ */ f("span", {
				className: "gl-card-rules",
				children: t ? /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f(J, { kind: He[o.area] }),
					/* @__PURE__ */ f(J, { kind: `story${o.story || ""}` }),
					/* @__PURE__ */ f("b", { children: o.story })
				] }) : /* @__PURE__ */ p(d, { children: [
					a.cost > 0 && /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(J, { kind: "coins" }), /* @__PURE__ */ f("b", { children: a.cost })] }),
					a.immediate.length > 0 && /* @__PURE__ */ f(X, { gains: a.immediate }),
					e >= 200 && a.score > 0 && /* @__PURE__ */ p("span", {
						title: i.finalPoints,
						children: [
							/* @__PURE__ */ f(J, { kind: "vp" }),
							/* @__PURE__ */ f("b", { children: a.score }),
							a.per && /* @__PURE__ */ f("small", { children: "×" })
						]
					}),
					a.per && /* @__PURE__ */ f("small", {
						className: "gl-score-object",
						children: We(a.per, r)
					}),
					a.potion && /* @__PURE__ */ f(J, {
						kind: "potiondiscarded",
						label: i.potion
					})
				] })
			}),
			!t && D[e] ? /* @__PURE__ */ f("span", {
				className: "gl-card-abilities",
				children: D[e].map((e, t) => /* @__PURE__ */ p("span", {
					className: "gl-printed-effect",
					children: [
						/* @__PURE__ */ f(J, { kind: `story${t + 1}` }),
						/* @__PURE__ */ f("i", { children: "→" }),
						/* @__PURE__ */ f(X, { gains: e })
					]
				}, t))
			}) : (t || a.abilities.length > 0) && /* @__PURE__ */ f("span", {
				className: "gl-card-abilities",
				children: (t ? o.outcomes : a.abilities).map((e, t) => /* @__PURE__ */ p("span", {
					className: "gl-printed-effect",
					children: [
						/* @__PURE__ */ f(Ge, { price: e.pay }),
						/* @__PURE__ */ f("i", { children: "→" }),
						/* @__PURE__ */ f(X, { gains: e.gain })
					]
				}, t))
			})
		]
	});
}
function Ke({ id: e, encounter: t = !1 }) {
	let n = s((e) => e.locale) === "en", r = G(n), i = r.ui, a = T[e], o = A[e], c = t ? o.outcomes : a.abilities;
	return /* @__PURE__ */ p("div", {
		className: "gl-card-details",
		children: [/* @__PURE__ */ f(Z, {
			id: e,
			encounter: t
		}), /* @__PURE__ */ p("div", {
			className: "gl-effect-details",
			children: [
				!t && a.immediate.length > 0 && /* @__PURE__ */ p("p", { children: [
					/* @__PURE__ */ f("b", { children: i.immediate }),
					/* @__PURE__ */ f(X, { gains: a.immediate }),
					/* @__PURE__ */ f("span", { children: a.immediate.map((e) => q(e, n)).join(" · ") })
				] }),
				c.map((e, r) => /* @__PURE__ */ p("div", {
					className: "gl-effect-row",
					children: [
						t && /* @__PURE__ */ p("b", { children: [
							i.side,
							" ",
							r + 1
						] }),
						/* @__PURE__ */ f(Ge, {
							price: e.pay,
							verbose: !0
						}),
						/* @__PURE__ */ f("span", {
							"aria-hidden": !0,
							children: "→"
						}),
						/* @__PURE__ */ f(X, { gains: e.gain }),
						/* @__PURE__ */ f("span", { children: e.gain.map((e) => q(e, n)).join(" · ") || i.none })
					]
				}, r)),
				!t && e >= 300 && /* @__PURE__ */ f("p", { children: r.reactions[e - 301] }),
				!t && a.potion && /* @__PURE__ */ f("p", { children: r.potions[e] }),
				!t && D[e] && /* @__PURE__ */ f("div", {
					className: "gl-tavern-tiers",
					children: D[e].map((e, t) => /* @__PURE__ */ p("p", { children: [
						/* @__PURE__ */ f(J, { kind: `story${t + 1}` }),
						/* @__PURE__ */ f(X, { gains: e }),
						/* @__PURE__ */ f("span", { children: e.map((e) => q(e, n)).join(" · ") })
					] }, t))
				}),
				t && /* @__PURE__ */ p("p", { children: [
					/* @__PURE__ */ f(J, { kind: "story" }),
					" ",
					i.untold,
					": ",
					o.story
				] }),
				!t && a.score > 0 && /* @__PURE__ */ p("p", { children: [
					/* @__PURE__ */ f(J, { kind: "vp" }),
					i.finalPoints,
					": ",
					a.score,
					a.per ? ` · ${i.companionScoring}` : ""
				] })
			]
		})]
	});
}
//#endregion
//#region src/games/greylune/dialog.tsx
function qe({ open: e, title: t, onClose: n, children: r, className: o = "" }) {
	let c = a(null), l = s((e) => e.locale) === "en";
	return i(() => {
		let t = c.current;
		e && !t?.open ? t?.showModal() : !e && t?.open && t.close();
	}, [e]), /* @__PURE__ */ p("dialog", {
		ref: c,
		className: `gl-dialog ${o}`,
		onCancel: (e) => {
			e.preventDefault(), n();
		},
		"aria-label": t,
		children: [/* @__PURE__ */ p("header", {
			className: "gl-dialog-header",
			children: [/* @__PURE__ */ f("h2", { children: t }), /* @__PURE__ */ f("button", {
				type: "button",
				className: "gl-icon-button",
				onClick: n,
				"aria-label": G(l).ui.close,
				children: /* @__PURE__ */ f(m, { size: 22 })
			})]
		}), r]
	});
}
//#endregion
//#region src/games/greylune/view-player.tsx
var Je = [
	"blue",
	"orange",
	"purple",
	"red"
];
function Q({ name: e, children: t, className: n = "", style: r }) {
	let { ref: i, hidden: a } = l(e);
	return /* @__PURE__ */ f("div", {
		ref: i,
		className: n,
		style: r,
		children: /* @__PURE__ */ f("div", {
			className: "gl-slot-content",
			style: { visibility: a ? "hidden" : void 0 },
			children: t
		})
	});
}
function Ye({ choice: e, send: t, english: n }) {
	return /* @__PURE__ */ p("button", {
		type: "button",
		className: "gl-choice",
		onClick: () => t(e),
		children: [/* @__PURE__ */ f("strong", { children: Ve(e, n) }), e.pay?.length ? /* @__PURE__ */ f(Ge, {
			price: e.pay,
			verbose: !0
		}) : null]
	});
}
function Xe({ anchor: e, color: t, label: n, avatar: i, theme: a }) {
	let { ref: o, hidden: s } = l(e);
	return /* @__PURE__ */ f("span", {
		ref: o,
		className: "gl-worker-piece",
		style: { visibility: s ? "hidden" : void 0 },
		children: /* @__PURE__ */ f("span", {
			className: `gl-villager gl-villager-${t}`,
			title: n,
			style: { backgroundColor: a },
			children: /* @__PURE__ */ f("img", {
				src: r[i % r.length],
				alt: "",
				draggable: !1,
				style: {
					width: "1.75em",
					height: "1.75em",
					maxWidth: "100%",
					maxHeight: "100%",
					display: "block",
					objectFit: "contain",
					pointerEvents: "none",
					borderRadius: "inherit"
				}
			})
		})
	});
}
function Ze({ anchor: e, color: t, label: n, avatar: i }) {
	let { ref: a, hidden: o } = l(e);
	return /* @__PURE__ */ p("span", {
		ref: a,
		className: "gl-quest-marker",
		style: { visibility: o ? "hidden" : void 0 },
		children: [/* @__PURE__ */ f("img", {
			src: r[i % r.length],
			alt: "",
			style: {
				backgroundColor: t,
				borderRadius: "50%"
			}
		}), /* @__PURE__ */ f("span", { children: n })]
	});
}
function Qe(e) {
	let t = e.public, i = e.private, a = s((e) => e.locale) === "en", c = G(a), l = c.ui, [m, h] = o("village"), [g, _] = o(e.myRid), [v, y] = o(null), [b, x] = o(null), S = t.phase === "done" ? [] : i?.choices ?? [], C = t.players.find((e) => e.rid === g) ?? t.players[0], w = (t) => e.members.find((e) => e.rid === t)?.name ?? t, T = (e) => Je[Math.max(0, t.players.findIndex((t) => t.rid === e)) % 4], E = (t) => {
		e.send({
			type: "choose",
			key: t.key
		}), y(null), x(null);
	}, D = (e, t = 0) => y({
		kind: e,
		id: t
	}), ee = b === null ? [] : P[b], O = t.phase === "done" ? l.done : c.prompts[t.prompt] ?? l.resolving, k = S.find((e) => e.kind === "continue") ?? S.find((e) => e.kind === "summer"), te = v ? S.filter((e) => v.kind === "actions" ? !["place", "placeExtra"].includes(e.kind) : v.kind === "event" ? e.kind === "event" : v.kind === "quest" ? e.kind === "quest" && e.slot === v.id : v.kind === "card" ? e.card === v.id && e.kind !== "encounter" && (b === null || e.gap === void 0 || e.gap === b) : v.kind === "encounter" ? e.kind === "encounter" && e.card === v.id || e.cards?.includes(v.id) : !1) : [], ne = v ? v.kind === "card" || v.kind === "encounter" ? K(v.id, a, v.kind === "encounter") : v.kind === "event" ? a ? j[t.event].name : j[t.event].zh : v.kind === "quest" ? a ? M[t.quests[v.id]].name : M[t.quests[v.id]].zh : v.kind === "journal" ? l.journal : O : "";
	return /* @__PURE__ */ p(u, {
		adaptive: !0,
		scroll: !1,
		className: "greylune",
		banner: /* @__PURE__ */ p("div", {
			className: "gl-banner",
			style: { backgroundImage: "linear-gradient(90deg, #264851 25%, #264851ee 43%, #26485100 77%), url(\"games/greylune/valley-scene.svg\")" },
			children: [/* @__PURE__ */ p("header", {
				className: "gl-heading",
				children: [
					/* @__PURE__ */ f(Q, {
						name: "deck",
						children: /* @__PURE__ */ p("div", {
							className: "gl-crest",
							children: [
								/* @__PURE__ */ f(J, { kind: "firstplayer" }),
								/* @__PURE__ */ f("b", {
									className: "gl-brand",
									children: "GREYLUNE"
								}),
								/* @__PURE__ */ f("svg", {
									viewBox: "0 0 280 22",
									"aria-hidden": !0,
									children: /* @__PURE__ */ f("path", {
										d: "M10 2Q38 22 82 9L125 15 140 20 155 15 198 9Q242 22 270 2M19 3Q36 14 48 10M261 3Q244 14 232 10",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "1.2"
									})
								})
							]
						})
					}),
					/* @__PURE__ */ p("span", {
						className: "gl-year",
						children: [
							l.year,
							" ",
							/* @__PURE__ */ f("b", { children: t.year }),
							" / 5"
						]
					}),
					/* @__PURE__ */ f(Q, {
						name: "discard",
						children: /* @__PURE__ */ p("button", {
							className: "gl-text-button",
							type: "button",
							onClick: () => D("journal"),
							children: [/* @__PURE__ */ f(J, { kind: "story" }), l.journal]
						})
					})
				]
			}), /* @__PURE__ */ f("div", {
				className: "gl-players",
				children: t.players.map((i) => /* @__PURE__ */ f(Q, {
					name: `seat:${i.rid}`,
					className: `gl-player gl-player-${T(i.rid)}${t.turn === i.rid && t.phase !== "done" ? " gl-player-turn" : ""}`,
					style: { "--gl-player-color": n[(e.members.find((e) => e.rid === i.rid)?.colorIndex ?? 0) % n.length].hex },
					children: /* @__PURE__ */ p("button", {
						type: "button",
						className: "gl-player-button",
						"aria-pressed": C.rid === i.rid,
						onClick: () => {
							_(i.rid), h("inventory");
						},
						children: [
							/* @__PURE__ */ f("img", {
								className: "gl-player-pawn",
								src: r[(e.members.find((e) => e.rid === i.rid)?.avatar ?? 0) % r.length],
								style: {
									backgroundColor: n[(e.members.find((e) => e.rid === i.rid)?.colorIndex ?? 0) % n.length].hex,
									borderRadius: "50%",
									objectFit: "contain"
								},
								alt: ""
							}),
							/* @__PURE__ */ p("span", {
								className: "gl-player-name",
								children: [t.first === i.rid && /* @__PURE__ */ f(J, { kind: "firstplayer" }), w(i.rid)]
							}),
							/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(J, { kind: i.season }), l[i.season]] }),
							/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(J, { kind: "vp" }), t.phase === "done" ? t.final.find((e) => e.rid === i.rid)?.total : i.score] }),
							/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(J, { kind: "coins" }), i.coins] }),
							/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(J, { kind: "villager" }), i.active] })
						]
					})
				}, i.rid))
			})]
		}),
		actionsHeight: "gl-actions-height",
		actions: /* @__PURE__ */ p("footer", {
			className: "gl-action-bar",
			children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("b", { children: t.phase === "done" ? l.done : w(t.turn) }), /* @__PURE__ */ f("span", { children: O })] }), S.length > 0 ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
				type: "button",
				className: "gl-button",
				onClick: () => D("actions"),
				children: l.choose
			}), k && /* @__PURE__ */ f("button", {
				type: "button",
				className: "gl-button gl-primary",
				onClick: () => E(k),
				children: Ve(k, a)
			})] }) : t.phase !== "done" && /* @__PURE__ */ f("span", {
				className: "gl-waiting",
				children: t.phase === "settle" ? l.resolving : l.waiting
			})]
		}),
		children: [
			/* @__PURE__ */ f("nav", {
				className: "gl-tabs",
				"aria-label": l.inspect,
				children: [
					"village",
					"adventure",
					"inventory"
				].map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					"aria-pressed": m === e,
					onClick: () => h(e),
					children: l[e]
				}, e))
			}),
			/* @__PURE__ */ p("div", {
				className: `gl-layout gl-tab-${m}`,
				children: [
					/* @__PURE__ */ p("section", {
						className: "gl-village gl-panel",
						children: [/* @__PURE__ */ p("div", {
							className: "gl-section-heading",
							children: [
								/* @__PURE__ */ f("h2", { children: l.village }),
								/* @__PURE__ */ p("span", { children: [
									l.street,
									" ",
									b === null ? "—" : b + 1
								] }),
								/* @__PURE__ */ f("button", {
									type: "button",
									className: "gl-text-button",
									onClick: () => D("event"),
									children: l.event
								})
							]
						}), /* @__PURE__ */ p("div", {
							className: "gl-grid",
							children: [t.board.map((e, n) => {
								let r = S.some((e) => e.slot === n && (b === null || e.gap === void 0 || e.gap === b)), i = ee.includes(n);
								return /* @__PURE__ */ p(Q, {
									name: `village:${n}`,
									className: "gl-board-slot",
									style: {
										gridRow: Math.floor(n / 3) * 2 + 1,
										gridColumn: n % 3 * 2 + 1
									},
									children: [/* @__PURE__ */ f("button", {
										type: "button",
										className: `gl-card${r ? " gl-legal" : ""}${i ? " gl-selected" : ""}`,
										"aria-label": e === null ? l.empty : K(e, a),
										disabled: e === null,
										onClick: () => e !== null && D("card", e),
										children: e === null ? /* @__PURE__ */ f("span", {
											className: "gl-empty",
											children: l.empty
										}) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Z, { id: e }), r && /* @__PURE__ */ f(Y, {})] })
									}), t.seals[n].length > 0 && /* @__PURE__ */ f("div", {
										className: "gl-seals",
										children: t.seals[n].map((e, t) => /* @__PURE__ */ f("img", {
											src: `games/greylune/seal-${e}.svg`,
											alt: `${l.seal} ${e}`
										}, t))
									})]
								}, n);
							}), P.map((r, i) => {
								let a = r[0], o = r[1], s = (a % 3 + o % 3) / 2, c = (Math.floor(a / 3) + Math.floor(o / 3)) / 2, u = S.find((e) => (e.kind === "place" || e.kind === "placeExtra") && e.gap === i), d = S.some((e) => e.gap === i);
								return /* @__PURE__ */ f(Q, {
									name: `gap:${i}`,
									className: "gl-street-slot",
									style: {
										gridRow: c * 2 + 1,
										gridColumn: s * 2 + 1
									},
									children: /* @__PURE__ */ p("button", {
										type: "button",
										"aria-label": `${l.street} ${i + 1}${t.streets[i].length ? ` · ${t.streets[i].map(w).join(", ")}` : ""}`,
										"aria-pressed": b === i,
										className: `gl-gap${u || d ? " gl-legal" : ""}${b === i ? " gl-selected" : ""}`,
										onClick: () => {
											if (u) E(u);
											else {
												x(b === i ? null : i);
												let e = S.find((e) => e.kind === "retrieve" && e.gap === i);
												e && E(e);
											}
										},
										children: [
											/* @__PURE__ */ f("span", {
												className: "gl-gap-number",
												children: i + 1
											}),
											/* @__PURE__ */ f("span", {
												className: "gl-villagers",
												children: t.streets[i].map((t, r) => /* @__PURE__ */ f(Xe, {
													anchor: `worker:${i}:${r}`,
													color: T(t),
													label: w(t),
													avatar: e.members.find((e) => e.rid === t)?.avatar ?? 0,
													theme: n[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % n.length].hex
												}, r))
											}),
											(u || d) && /* @__PURE__ */ f(Y, {})
										]
									})
								}, `gap${i}`);
							})]
						}, t.year)]
					}),
					/* @__PURE__ */ p("section", {
						className: "gl-road gl-panel",
						children: [/* @__PURE__ */ f("div", {
							className: "gl-section-heading",
							children: /* @__PURE__ */ f("h2", { children: l.adventure })
						}), /* @__PURE__ */ f("div", {
							className: "gl-road-scroll",
							style: { backgroundImage: "url(\"games/greylune/map-land.svg\")" },
							children: Array.from({ length: 6 }, (n, r) => /* @__PURE__ */ f($e, {
								area: r,
								pub: t,
								choices: S,
								name: w,
								members: e.members,
								open: D,
								send: E,
								english: a
							}, `${t.year}:${r}`))
						})]
					}),
					/* @__PURE__ */ p("section", {
						className: "gl-personal gl-panel",
						children: [/* @__PURE__ */ p("div", {
							className: "gl-section-heading",
							children: [/* @__PURE__ */ f("h2", { children: w(C.rid) }), /* @__PURE__ */ f("select", {
								className: "gl-player-select",
								value: C.rid,
								"aria-label": l.inspect,
								onChange: (e) => _(e.target.value),
								children: t.players.map((e) => /* @__PURE__ */ f("option", {
									value: e.rid,
									children: w(e.rid)
								}, e.rid))
							})]
						}), /* @__PURE__ */ p("div", {
							className: "gl-personal-scroll",
							children: [
								/* @__PURE__ */ f("div", {
									className: "gl-resource-grid",
									children: [
										"coins",
										"force",
										"magic",
										"active"
									].map((e) => /* @__PURE__ */ f(Q, {
										name: `resource:${C.rid}:${e}`,
										children: /* @__PURE__ */ p("div", {
											className: `gl-resource gl-resource-${e}`,
											children: [
												/* @__PURE__ */ f(J, { kind: e === "active" ? "villager" : e }),
												/* @__PURE__ */ f("span", { children: e === "active" ? l.workers : l[e] }),
												/* @__PURE__ */ f("b", {
													className: "gl-number",
													children: C[e]
												}, C[e]),
												(e === "force" || e === "magic") && /* @__PURE__ */ f("span", {
													className: "gl-track",
													children: [
														1,
														2,
														3,
														4,
														5
													].map((t) => /* @__PURE__ */ f("i", { className: t <= C[e] ? "gl-track-full" : "" }, t))
												})
											]
										})
									}, e))
								}),
								/* @__PURE__ */ p("div", {
									className: "gl-worker-zones",
									children: [
										/* @__PURE__ */ f(Q, {
											name: `camp:${C.rid}`,
											children: /* @__PURE__ */ p("span", { children: [l.camp, /* @__PURE__ */ f("b", { children: C.camp })] })
										}),
										/* @__PURE__ */ f(Q, {
											name: `reserve:${C.rid}`,
											children: /* @__PURE__ */ p("span", { children: [l.reserve, /* @__PURE__ */ f("b", { children: C.reserve })] })
										}),
										/* @__PURE__ */ f(Q, {
											name: `quest-stock:${C.rid}`,
											children: /* @__PURE__ */ p("span", { children: [l.quests, /* @__PURE__ */ f("b", { children: C.quests.length })] })
										})
									]
								}),
								/* @__PURE__ */ p(Q, {
									name: `inventory:${C.rid}`,
									children: [
										/* @__PURE__ */ f("h3", { children: l.inventory }),
										/* @__PURE__ */ f(et, {
											ids: [...C.items, ...C.companions],
											className: "gl-inventory",
											children: (e) => /* @__PURE__ */ f(Q, {
												name: `owned-slot:${e}`,
												className: "gl-owned-slot",
												children: /* @__PURE__ */ f(Q, {
													name: `owned:${e}`,
													children: [...C.items, ...C.companions].includes(e) ? /* @__PURE__ */ p("button", {
														type: "button",
														className: `gl-card gl-owned${C.exhausted.includes(e) ? " gl-exhausted" : ""}`,
														onClick: () => D("card", e),
														children: [
															/* @__PURE__ */ f(Z, {
																id: e,
																compact: !0
															}),
															C.exhausted.includes(e) && /* @__PURE__ */ f("span", {
																className: "gl-exhausted-label",
																children: l.exhausted
															}),
															S.some((t) => t.card === e) && /* @__PURE__ */ f(Y, {})
														]
													}) : /* @__PURE__ */ f("span", { className: "gl-taken" })
												})
											})
										}),
										C.items.length + C.companions.length === 0 && /* @__PURE__ */ f("p", {
											className: "gl-muted",
											children: l.emptyInventory
										})
									]
								}),
								/* @__PURE__ */ p(Q, {
									name: `untold:${C.rid}`,
									children: [
										/* @__PURE__ */ p("h3", { children: [
											l.untold,
											" ",
											/* @__PURE__ */ f("b", { children: C.untold.length })
										] }),
										/* @__PURE__ */ f(et, {
											ids: C.untold,
											className: "gl-story-list",
											children: (e) => /* @__PURE__ */ f(Q, {
												name: `story:${e}`,
												children: C.untold.includes(e) ? /* @__PURE__ */ p("button", {
													type: "button",
													className: "gl-story",
													onClick: () => D("encounter", e),
													children: [
														/* @__PURE__ */ f(J, { kind: `story${A[e].story || ""}` }),
														/* @__PURE__ */ f("span", { children: K(e, a, !0) }),
														/* @__PURE__ */ f("b", { children: A[e].story })
													]
												}) : /* @__PURE__ */ f("span", { className: "gl-story gl-taken" })
											})
										}),
										!C.untold.length && /* @__PURE__ */ f("p", {
											className: "gl-muted",
											children: l.emptyStories
										})
									]
								}),
								/* @__PURE__ */ f(Q, {
									name: `told:${C.rid}`,
									children: /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ p("summary", { children: [
										l.told,
										" · ",
										C.told.length
									] }), C.told.map((e) => /* @__PURE__ */ f("button", {
										type: "button",
										className: "gl-story",
										onClick: () => D("encounter", e),
										children: K(e, a, !0)
									}, e))] })
								}),
								/* @__PURE__ */ p("details", {
									className: "gl-income",
									children: [/* @__PURE__ */ p("summary", { children: [
										l.income,
										" · ",
										C.income.length
									] }), C.income.map((e, t) => /* @__PURE__ */ f("p", { children: q(N[e], a) }, t))]
								}),
								/* @__PURE__ */ f(Q, {
									name: "event",
									children: /* @__PURE__ */ p("button", {
										type: "button",
										className: "gl-event",
										onClick: () => D("event"),
										children: [
											/* @__PURE__ */ f(J, { kind: "summer" }),
											/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("small", { children: l.event }), /* @__PURE__ */ f("b", { children: a ? j[t.event].name : j[t.event].zh })] }),
											/* @__PURE__ */ f("span", {
												className: "gl-event-workers",
												children: t.players.filter((e) => e.event !== null).map((t) => /* @__PURE__ */ f("span", {
													className: `gl-villager gl-villager-${T(t.rid)}`,
													title: w(t.rid),
													style: { backgroundColor: n[(e.members.find((e) => e.rid === t.rid)?.colorIndex ?? 0) % n.length].hex },
													children: /* @__PURE__ */ f("img", {
														src: r[(e.members.find((e) => e.rid === t.rid)?.avatar ?? 0) % r.length],
														alt: "",
														draggable: !1,
														style: {
															width: "1.75em",
															height: "1.75em",
															maxWidth: "100%",
															maxHeight: "100%",
															display: "block",
															objectFit: "contain",
															pointerEvents: "none",
															borderRadius: "inherit"
														}
													})
												}, t.rid))
											}),
											S.some((e) => e.kind === "event") && /* @__PURE__ */ f(Y, {})
										]
									})
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ f(qe, {
				open: v !== null,
				title: ne,
				onClose: () => y(null),
				children: /* @__PURE__ */ f("div", {
					className: "gl-dialog-body",
					children: v && /* @__PURE__ */ p(d, { children: [
						(v.kind === "card" || v.kind === "encounter") && /* @__PURE__ */ f(Ke, {
							id: v.id,
							encounter: v.kind === "encounter"
						}),
						v.kind === "quest" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Ge, {
							price: M[t.quests[v.id]].pay,
							verbose: !0
						}), /* @__PURE__ */ p("p", { children: [
							l.first,
							": ",
							t.questFirst[v.id] ? w(t.questFirst[v.id]) : "—",
							" · ",
							7 + v.id,
							" / ",
							5 + v.id,
							" ",
							l.finalPoints
						] })] }),
						v.kind === "event" && j[t.event].abilities.map((e, t) => /* @__PURE__ */ p("div", {
							className: "gl-effect-row",
							children: [
								/* @__PURE__ */ f(Ge, {
									price: e.pay,
									verbose: !0
								}),
								/* @__PURE__ */ f("span", { children: "→" }),
								/* @__PURE__ */ f(X, { gains: e.gain }),
								/* @__PURE__ */ f("span", { children: e.gain.map((e) => q(e, a)).join(" · ") })
							]
						}, t)),
						v.kind === "journal" && /* @__PURE__ */ f("ol", {
							className: "gl-journal",
							children: t.log.map((e, t) => /* @__PURE__ */ p("li", { children: [/* @__PURE__ */ f("b", { children: w(e.rid) }), /* @__PURE__ */ p("span", { children: [
								l[e.kind] ?? l.reward,
								e.card && e.card > 0 ? ` · ${K(e.card, a, e.kind === "encounter")}` : "",
								e.n === void 0 ? "" : ` · ${e.n}`
							] })] }, t))
						}),
						te.length > 0 && /* @__PURE__ */ f("div", {
							className: "gl-choices",
							children: te.map((e) => /* @__PURE__ */ f(Ye, {
								choice: e,
								send: E,
								english: a
							}, e.key))
						})
					] })
				})
			})
		]
	});
}
function $e({ area: e, pub: t, choices: i, name: a, members: s, open: c, send: u, english: d }) {
	let [m] = o(() => t.encounters.filter((t) => A[t].area === e)), h = G(d).ui, g = i.find((t) => t.kind === "move" && t.n === e), { ref: _, hidden: v } = l(`area:${e}`);
	return /* @__PURE__ */ p("div", {
		className: `gl-area gl-area-${e}`,
		ref: _,
		style: { visibility: v ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ p("svg", {
				className: "gl-road-trail",
				viewBox: "0 0 100 280",
				preserveAspectRatio: "none",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ f("path", {
					d: e === 0 ? "M50 65V280" : "M50 0C100 75 0 185 50 280",
					className: "gl-trail-edge"
				}), /* @__PURE__ */ f("path", {
					d: e === 0 ? "M50 65V280" : "M50 0C100 75 0 185 50 280",
					className: "gl-trail-paper"
				})]
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: `gl-destination${g ? " gl-legal" : ""}`,
				onClick: () => g && u(g),
				"aria-label": `${h.move} ${e}`,
				disabled: !g,
				children: [
					/* @__PURE__ */ f(J, { kind: He[e] }),
					/* @__PURE__ */ f("b", { children: e === 0 ? h.village : e }),
					g && /* @__PURE__ */ f(Y, {})
				]
			}),
			/* @__PURE__ */ f("div", {
				className: "gl-adventurers",
				children: t.players.map((t) => /* @__PURE__ */ f(Q, {
					name: `pawn-slot:${e}:${t.rid}`,
					className: "gl-pawn-slot",
					children: t.position === e && /* @__PURE__ */ f(Q, {
						name: `pawn:${t.rid}`,
						children: /* @__PURE__ */ f("img", {
							className: "gl-pawn",
							src: r[(s.find((e) => e.rid === t.rid)?.avatar ?? 0) % r.length],
							style: {
								backgroundColor: n[(s.find((e) => e.rid === t.rid)?.colorIndex ?? 0) % n.length].hex,
								borderRadius: "50%",
								objectFit: "contain"
							},
							alt: a(t.rid),
							title: a(t.rid)
						})
					})
				}, t.rid))
			}),
			/* @__PURE__ */ f("div", {
				className: "gl-area-cards",
				children: m.map((e) => /* @__PURE__ */ f(Q, {
					name: `encounter:${e}`,
					className: "gl-encounter-slot",
					children: t.encounters.includes(e) ? /* @__PURE__ */ p("button", {
						type: "button",
						className: "gl-card",
						onClick: () => c("encounter", e),
						children: [/* @__PURE__ */ f(Z, {
							id: e,
							encounter: !0,
							compact: !0
						}), i.some((t) => t.kind === "encounter" && t.card === e) && /* @__PURE__ */ f(Y, {})]
					}) : /* @__PURE__ */ f("span", {
						className: "gl-taken",
						"aria-hidden": !0
					})
				}, e))
			}),
			e >= 3 && /* @__PURE__ */ f(Q, {
				name: `quest:${e - 3}`,
				children: /* @__PURE__ */ p("button", {
					type: "button",
					className: "gl-quest",
					onClick: () => c("quest", e - 3),
					children: [
						/* @__PURE__ */ f("span", { children: d ? M[t.quests[e - 3]].name : M[t.quests[e - 3]].zh }),
						/* @__PURE__ */ p("b", { children: [
							e + 4,
							" / ",
							e + 2,
							/* @__PURE__ */ f(J, { kind: "vp" })
						] }),
						t.players.filter((t) => t.quests.includes(e - 3)).map((t) => /* @__PURE__ */ f(Ze, {
							anchor: `quest-marker:${e - 3}:${t.rid}`,
							color: n[(s.find((e) => e.rid === t.rid)?.colorIndex ?? 0) % n.length].hex,
							label: a(t.rid),
							avatar: s.find((e) => e.rid === t.rid)?.avatar ?? 0
						}, t.rid)),
						i.some((t) => t.kind === "quest" && t.slot === e - 3) && /* @__PURE__ */ f(Y, {})
					]
				})
			}),
			e === 1 && /* @__PURE__ */ p("small", {
				className: "gl-area-reward",
				children: [/* @__PURE__ */ f(J, { kind: "coins" }), "1"]
			}),
			e === 2 && /* @__PURE__ */ p("small", {
				className: "gl-area-reward",
				children: [/* @__PURE__ */ f(J, { kind: "vp" }), "1"]
			})
		]
	});
}
function et({ ids: e, className: t, children: n }) {
	let [r, a] = o(e), s = e.join(",");
	return i(() => {
		let e = setTimeout(() => a(s ? s.split(",").map(Number) : []), 550);
		return () => clearTimeout(e);
	}, [s]), /* @__PURE__ */ f("div", {
		className: t,
		children: [.../* @__PURE__ */ new Set([...r, ...e])].map((e) => /* @__PURE__ */ f("div", { children: n(e) }, e))
	});
}
//#endregion
//#region src/games/greylune/bot.ts
var tt = {
	worker: 2.2,
	skill: 1.35,
	coin: .34,
	story: .65,
	placement: .6,
	companion: 1.15
};
function $(e, t, n, r) {
	let i = 6 - n.year;
	if (e.kind === "vp") return Math.max(0, e.n);
	if (e.kind === "coins") return e.n * r.coin * (t.coins < 4 ? 1.5 : 1);
	if (e.kind === "worker") return t.reserve ? r.worker * (.4 + i / 2) : 0;
	if (e.kind === "force" || e.kind === "magic") return e.n * (t[e.kind] === 5 ? 1 : r.skill * (.7 + i / 5));
	if (e.kind === "skill") return Math.max($({
		kind: "force",
		n: 1
	}, t, n, r), $({
		kind: "magic",
		n: 1
	}, t, n, r));
	if (e.kind === "income") return (i + 1) * $(N[e.n], t, {
		...n,
		year: 5
	}, r);
	if (e.kind === "ready") return t.exhausted.length ? 1.7 : 0;
	if (e.kind === "travel") return Math.max(1, e.n) * .8 + .8;
	if (e.kind === "story") {
		let i = Math.max(0, ...t.untold.map((e) => A[e].story));
		return D[e.n].slice(0, i).flat().reduce((e, i) => e + $(i, t, n, r), 0);
	}
	return e.kind === "count" ? e.n * (e.ref === "items" ? t.items.length : e.ref === "companions" ? t.companions.length : e.ref === "told" ? t.told.length : t.untold.length) : 0;
}
function nt(e, t, n, r = tt) {
	let i = (e) => e.reduce((e, i) => e + $(i, n, t, r), 0), a = (e.pay ?? []).reduce((e, [t, n]) => e + (t === "coins" ? n * r.coin : t === "workers" ? n * .8 : t === "force" || t === "magic" ? n * r.skill : 0), 0);
	if (e.kind === "activate") {
		let n = T[e.card];
		return i(e.gain ?? []) - a + (e.card >= 300 ? r.companion * (5 - t.year + 2) : e.card >= 200 ? n.score + Math.max(0, 5 - t.year) * (n.potion ? .2 : .7) + (e.n ?? 0) : 0);
	}
	if (e.kind === "use" || e.kind === "special" || e.kind === "event") return i(e.gain ?? []) - a + (e.kind === "event" ? .4 : 0);
	if (e.kind === "coins") return (e.n ?? 0) * r.coin + (n.coins < 3 ? .5 : 0);
	if (e.kind === "place") {
		let a = P[e.gap].map((e) => {
			let a = t.board[e];
			if (a === null) return -1;
			let o = T[a];
			return o.id >= 300 ? n.companions.length < 3 && n.coins >= 5 ? 5 : 0 : o.id >= 200 ? o.score + i(o.immediate) - o.cost * r.coin : Math.max(...o.abilities.map((e) => i(e.gain)));
		}).sort((e, t) => t - e);
		return 2 + a[0] * r.placement + a[1] * .2 - t.streets[e.gap].filter((e) => e === n.rid).length * .6;
	}
	if (e.kind === "placeExtra") return 3;
	if (e.kind === "summer") return n.active > 0 ? -10 : 0;
	if (e.kind === "autumn") return -8;
	if (e.kind === "retrieve") return -1;
	if (e.kind === "encounter") return i(e.gain ?? []) - a + .8 + A[e.card].story * r.story;
	if (e.kind === "quest") return 6 + e.slot - a;
	if (e.kind === "skipEncounter") return e.n === 2 ? 1 : e.n === 1 ? r.coin : 0;
	if (e.kind === "move") {
		let a = t.encounters.filter((t) => A[t].area === e.n), o = Math.max(0, ...a.map((e) => Math.max(...A[e].outcomes.filter((e) => e.pay.every(([e, t]) => e === "haveForce" ? n.force >= t : e === "haveMagic" ? n.magic >= t : e === "haveSkills" ? n.force + n.magic >= t : e === "coins" ? n.coins >= t : e === "force" ? n.force >= t : e === "magic" ? n.magic >= t : e !== "workers" || n.active >= t)).map((t) => i(t.gain) + A[e].story * r.story), 0))), s = e.n >= 3 && !n.quests.includes(e.n - 3) && M[t.quests[e.n - 3]].pay.every(([e, t]) => e === "haveForce" ? n.force >= t : e === "haveMagic" ? n.magic >= t : e === "haveSkills" ? n.force + n.magic >= t : e === "coins" ? n.coins >= t : e === "workers" ? n.active >= t : e === "item" ? n.items.length > 0 : e === "stories" ? n.untold.length >= t : e === "return" ? n.active > 0 : n[e] >= t) ? 6 + e.n : 0;
		return Math.max(o, s, e.n === 2 ? 1 : e.n === 1 ? r.coin : 0) + e.n * .015;
	}
	return e.kind === "story" ? e.n * 2 - (e.cards?.length ?? 0) * .15 : e.kind === "seal" ? e.n : e.kind === "skill" ? $({
		kind: e.n === 0 ? "force" : "magic",
		n: 1
	}, n, t, r) + (n.force === n.magic ? 0 : (e.n === 0 ? n.force < n.magic : n.magic < n.force) ? .15 : 0) : e.kind === "bonus" ? e.n === 0 ? i([{
		kind: "coins",
		n: 5
	}]) : e.n === 1 ? i([{
		kind: "force",
		n: 1
	}, {
		kind: "magic",
		n: 1
	}]) : i([{
		kind: "worker",
		n: 1
	}]) : e.kind === "ready" || e.kind === "isandre" ? e.card >= 300 ? 2 : Math.max(.1, ...T[e.card].abilities.map((e) => i(e.gain))) : e.kind === "discard" ? -T[e.card].score - Math.max(0, 5 - t.year) * (T[e.card].potion ? .3 : .8) : e.kind === "questStories" ? -(e.cards ?? []).reduce((e, t) => e + A[t].story, 0) : e.kind === "react" ? [
		301,
		303,
		306,
		307,
		308
	].includes(e.card) ? 1.5 : e.card === 305 ? e.n === 1 ? 1.5 : .6 : e.card === 302 || e.card === 311 ? 1 : e.card === 310 || e.card === 213 ? n.untold.some((e) => A[e].story === 3) ? -.2 : .6 : [
		206,
		207,
		215,
		217,
		304
	].includes(e.card) ? -.1 : .2 : 0;
}
function rt(e = tt) {
	return ({ public: t, private: n }, r) => {
		if (t.turn !== r.rid || !n?.choices.length) return null;
		let i = t.players.find((e) => e.rid === r.rid), a = n.choices.map((n) => ({
			c: n,
			score: nt(n, t, i, e)
		}));
		return a.sort((e, t) => t.score - e.score || e.c.key.localeCompare(t.c.key)), { action: {
			type: "choose",
			key: (r.difficulty === "weak" ? a[Math.min(a.length - 1, 1)] : a[0]).c.key
		} };
	};
}
var it = rt(), at = (e, t) => {
	let i = t.member(e.rid ?? ""), a = n[(i?.colorIndex ?? 0) % n.length].hex, o = e.data, s = [], c = Math.min(460, t.queued ? 180 : 420), l = (o?.moves ?? []).flatMap((n, o) => {
		let l = t.anchor(n.from), u = t.anchor(n.to), d = t.anchor(n.fallback ?? `seat:${e.rid}`), p = l && l.w > 0 && l.h > 0 ? l : d, m = u && u.w > 0 && u.h > 0 ? u : d;
		if (!p || !m || !p.w || !m.w) return [];
		let h = n.asset === "card" || n.asset === "encounter", _ = h ? Math.min(140, p.w) : n.asset === "pawn" ? 40 : n.asset === "quest" ? 28 : 20, v = h ? _ * 1.2 : n.asset === "pawn" ? 44 : 28, y = {
			x: p.x + (p.w - _) / 2,
			y: p.y + (p.h - v) / 2,
			w: _,
			h: v
		}, b = h && u && u.w > 0 ? Math.min(140, u.w) : _, x = {
			x: m.x + (m.w - b) / 2,
			y: m.y + (m.h - v * b / _) / 2,
			w: b,
			h: v * b / _
		};
		return n.hide && u && u.w > 0 && !t.queued && s.push(n.hide), [/* @__PURE__ */ f(g, {
			from: y,
			to: x,
			ms: c,
			children: h ? /* @__PURE__ */ f("div", {
				className: "gl-fx-card",
				style: {
					width: _,
					height: v
				},
				children: /* @__PURE__ */ f(Z, {
					id: n.id,
					encounter: n.asset === "encounter"
				})
			}) : /* @__PURE__ */ f("img", {
				className: n.asset === "pawn" || n.asset === "quest" ? "gl-fx-pawn" : "gl-fx-villager",
				src: r[(i?.avatar ?? 0) % r.length],
				style: {
					width: _,
					height: v,
					objectFit: "contain",
					backgroundColor: a,
					borderRadius: "50%",
					pointerEvents: "none"
				},
				alt: ""
			})
		}, o)];
	});
	if (l.length) return {
		ms: c,
		node: l,
		hide: s
	};
	let u = o?.kind === "worker" ? "active" : o?.kind, d = u ? t.anchor(`resource:${e.rid}:${u}`) ?? t.anchor(`seat:${e.rid}`) : null;
	if (d && [
		"coins",
		"force",
		"magic",
		"worker",
		"vp"
	].includes(o?.kind ?? "") && o?.n) return {
		ms: c,
		node: /* @__PURE__ */ f(h, {
			at: d,
			ms: c,
			children: /* @__PURE__ */ p("span", {
				className: "gl-fx-label",
				children: [
					/* @__PURE__ */ f(J, { kind: o.kind }),
					" ",
					o.n > 0 ? "+" : "",
					o.n
				]
			})
		})
	};
	if (o?.card && [
		"react",
		"ready",
		"isandre",
		"quest"
	].includes(o.kind ?? "")) {
		let n = t.anchor(`owned:${o.card}`) ?? t.anchor(`seat:${e.rid}`);
		if (n) return {
			ms: c,
			node: /* @__PURE__ */ f(_, {
				at: n,
				ms: c
			})
		};
	}
	return {
		ms: 0,
		node: null
	};
}, ot = {
	act: at,
	resolve: at,
	reveal(e, t) {
		let n = e.data?.cards ?? [], r = [];
		return {
			ms: 480,
			node: n.flatMap((e, n) => {
				let i = t.anchor(`village:${n}`), a = t.anchor("deck");
				return !e || !i || !a ? [] : (r.push(`village:${n}`), [/* @__PURE__ */ f(g, {
					from: a,
					to: i,
					ms: 320,
					delay: n * 15,
					children: /* @__PURE__ */ f("div", {
						className: "gl-fx-card",
						style: {
							width: i.w,
							height: i.h
						},
						children: /* @__PURE__ */ f(Z, { id: e })
					})
				}, n)]);
			}),
			hide: r
		};
	}
};
//#endregion
//#region src/games/greylune/game-over.tsx
function st(e) {
	let t = e.public, n = c(), r = G(s((e) => e.locale) === "en").ui, [i, a] = o(!0), [l, u] = o(null), m = (t) => e.members.find((e) => e.rid === t)?.name ?? t, h = e.result.ranking.map((e) => t.final.find((t) => t.rid === e)), g = [
		"track",
		"quests",
		"items",
		"companions",
		"skills",
		"total"
	], _ = {
		track: r.track,
		quests: r.quests,
		items: r.items,
		companions: r.companions,
		skills: r.finalSkills,
		total: r.total
	};
	return /* @__PURE__ */ p("div", {
		className: "gl-result-root",
		children: [
			/* @__PURE__ */ f("div", {
				className: "gl-result-board",
				inert: i,
				children: /* @__PURE__ */ f(Qe, {
					...e,
					send: () => void 0
				})
			}),
			!i && /* @__PURE__ */ f("button", {
				type: "button",
				className: "gl-button gl-primary gl-result-restore",
				onClick: () => a(!0),
				children: r.restoreResult
			}),
			/* @__PURE__ */ p(qe, {
				open: i,
				title: r.done,
				className: "gl-result-dialog",
				onClose: () => a(!1),
				children: [/* @__PURE__ */ p("div", {
					className: "gl-dialog-body",
					children: [
						/* @__PURE__ */ p("div", {
							className: "gl-result-emblem",
							"aria-hidden": !0,
							children: [/* @__PURE__ */ f(J, { kind: "firstplayer" }), /* @__PURE__ */ f(J, { kind: "vp" })]
						}),
						/* @__PURE__ */ p("h1", {
							className: "gl-result-title",
							children: [
								/* @__PURE__ */ p("small", { children: [
									"GREYLUNE · ",
									r.year,
									" 5"
								] }),
								r.winner,
								" · ",
								e.result.winner.map(m).join(" / ")
							]
						}),
						/* @__PURE__ */ f("div", {
							className: "gl-score-scroll",
							children: /* @__PURE__ */ p("table", {
								className: "gl-score-table",
								children: [/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: r.points }), h.map((t) => /* @__PURE__ */ p("th", {
									scope: "col",
									children: [m(t.rid), e.result.winner.includes(t.rid) && /* @__PURE__ */ f("span", {
										"aria-hidden": !0,
										children: " ★"
									})]
								}, t.rid))] }) }), /* @__PURE__ */ f("tbody", { children: g.map((e) => /* @__PURE__ */ p("tr", {
									className: e === "total" ? "gl-score-total" : void 0,
									children: [/* @__PURE__ */ f("th", {
										scope: "row",
										children: _[e]
									}), h.map((t) => /* @__PURE__ */ f("td", { children: t[e] }, t.rid))]
								}, e)) })]
							})
						}),
						/* @__PURE__ */ p("div", {
							className: "gl-result-notes",
							children: [e.hintCount !== void 0 && /* @__PURE__ */ f("p", { children: n("session.hint.usedCount", { n: e.hintCount }) }), h.filter((t) => (e.result.autopilot?.[t.rid] ?? 0) > 0).map((t) => /* @__PURE__ */ p("p", {
								className: "gl-ap-share",
								children: [
									m(t.rid),
									" · ",
									n("session.autopilot.share", { n: Math.round(e.result.autopilot[t.rid] * 100) })
								]
							}, t.rid))]
						})
					]
				}), /* @__PURE__ */ f("footer", {
					className: "gl-result-controls",
					children: l ? /* @__PURE__ */ p(d, { children: [
						/* @__PURE__ */ f("p", { children: l === "again" ? r.confirmAgain : r.confirmLobby }),
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "gl-button",
							onClick: () => u(null),
							children: r.cancel
						}),
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "gl-button gl-primary",
							onClick: () => l === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(),
							children: r.confirm
						})
					] }) : /* @__PURE__ */ p(d, { children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "gl-button",
							onClick: () => a(!1),
							children: [
								/* @__PURE__ */ f(J, { kind: "story" }),
								" ",
								r.viewFinal
							]
						}),
						e.onPlayAgain && /* @__PURE__ */ f("button", {
							type: "button",
							className: "gl-button gl-primary",
							onClick: () => u("again"),
							children: r.again
						}),
						e.onBackToLobby && /* @__PURE__ */ f("button", {
							type: "button",
							className: "gl-button",
							onClick: () => u("lobby"),
							children: r.lobby
						}),
						!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ f("p", { children: n("session.result.waitHost") })
					] })
				})]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/greylune/entry.tsx
var ct = {
	definition: Re,
	View: Qe,
	bot: it,
	fx: ot,
	OverView: st,
	locales: {
		zh: Be,
		en: ze
	}
};
//#endregion
export { ct as default };
