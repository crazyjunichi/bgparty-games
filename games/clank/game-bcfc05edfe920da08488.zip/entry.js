import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useCallback as r, useEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { IconBack as g, IconBot as _, IconExpand as v, IconLog as y, IconRecenter as b, IconSettings as x, IconZoomIn as S, IconZoomOut as C } from "@bgparty/sdk/icons";
import { BottomSheet as w } from "@bgparty/sdk/bottom-sheet";
import { seatName as T } from "@bgparty/sdk/ui/player-strip";
import { Confetti as E } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as D, OptionSection as O, OptionSwitch as k } from "@bgparty/sdk/ui/game-options";
//#region src/games/clank/cards.ts
var A = [
	{
		id: "burgle",
		pack: "starter",
		copies: 6,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "scramble",
		pack: "starter",
		copies: 1,
		type: "basic",
		cost: 0,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "sidestep",
		pack: "starter",
		copies: 1,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "stumble",
		pack: "starter",
		copies: 2,
		type: "basic",
		cost: 0,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "explore",
		pack: "reserve",
		copies: 15,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "mercenary",
		pack: "reserve",
		copies: 15,
		type: "companion",
		cost: 2,
		skill: 1,
		swords: 2,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "tome",
		pack: "reserve",
		copies: 12,
		type: "basic",
		cost: 7,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 7,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "amulet-of-vigor",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 7,
		skill: 4,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [{
			op: "gain",
			resource: "heal",
			n: 1
		}],
		arrive: [],
		discard: []
	},
	{
		id: "animated-door",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "boots",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "apothecary",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "discard",
			n: 1,
			then: [{
				op: "choose",
				options: [
					{
						id: "swords:3",
						effects: [{
							op: "gain",
							resource: "swords",
							n: 3
						}]
					},
					{
						id: "gold:2",
						effects: [{
							op: "gain",
							resource: "gold",
							n: 2
						}]
					},
					{
						id: "heal:1",
						effects: [{
							op: "gain",
							resource: "heal",
							n: 1
						}]
					}
				]
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "archaeologist",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "idol",
			effects: [{
				op: "gain",
				resource: "skill",
				n: 2
			}]
		}
	},
	{
		id: "blecher",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 4
		}, {
			op: "gain",
			resource: "clank",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "boots-of-swiftness",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 3,
		points: 3,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [{
			op: "gain",
			resource: "boots",
			n: 1
		}],
		arrive: [],
		discard: []
	},
	{
		id: "bracers-of-agility",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "brilliance",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 3
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "cave-troll",
		pack: "base",
		copies: 1,
		type: "monster",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 3
		}, {
			op: "draw",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: [],
		deep: !0
	},
	{
		id: "cleric-of-the-sun",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 1,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [{
			op: "gain",
			resource: "heal",
			n: 1
		}],
		arrive: [],
		discard: []
	},
	{
		id: "crystal-golem",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "skill",
			n: 3
		}],
		acquire: [],
		arrive: [],
		discard: [],
		cave: !0
	},
	{
		id: "dead-run",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 2,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 2
		}, {
			op: "flag",
			flag: "ignoreCave"
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "diamond",
		pack: "base",
		copies: 1,
		type: "gem",
		cost: 8,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 8,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}],
		arrive: [],
		discard: []
	},
	{
		id: "dragon-shrine",
		pack: "base",
		copies: 2,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !0,
		play: [{
			op: "choose",
			options: [{
				id: "gold:2",
				effects: [{
					op: "gain",
					resource: "gold",
					n: 2
				}]
			}, {
				id: "trash",
				effects: [{ op: "trash" }]
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "dragons-eye",
		pack: "base",
		copies: 1,
		type: "gem",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}],
		arrive: [],
		discard: [],
		deep: !0
	},
	{
		id: "dwarven-peddler",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "elven-boots",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "elven-cloak",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: -2
		}, {
			op: "draw",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "elven-dagger",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 1,
		swords: 1,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "emerald",
		pack: "base",
		copies: 2,
		type: "gem",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 5,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}],
		arrive: [],
		discard: []
	},
	{
		id: "flying-carpet",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 2,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "flag",
			flag: "ignoreCave"
		}, {
			op: "flag",
			flag: "ignoreMonsters"
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "gem-collector",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: -2
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "invoker-of-the-ancients",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 1
		}, { op: "teleport" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "kobold",
		pack: "base",
		copies: 3,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !0,
		play: [{
			op: "gain",
			resource: "skill",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "kobold-merchant",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "artifact",
			effects: [{
				op: "gain",
				resource: "skill",
				n: 2
			}]
		}
	},
	{
		id: "ladder",
		pack: "base",
		copies: 2,
		type: "device",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "boots",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "lucky-coin",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 1,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 1
		}, {
			op: "draw",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "master-burglar",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "trash",
			burgle: !0
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "mister-whiskers",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !0,
		danger: !1,
		play: [{
			op: "choose",
			options: [{
				id: "attack",
				effects: [{ op: "attack" }]
			}, {
				id: "clank:-2",
				effects: [{
					op: "gain",
					resource: "clank",
					n: -2
				}]
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "monkeybot-3000",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 3
		}, {
			op: "draw",
			n: 3
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "move-silently",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 2,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: -2
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "ogre",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 5
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "ogre-grunt",
		pack: "base",
		copies: 3,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 3
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "overlord",
		pack: "base",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 2
		}],
		acquire: [],
		arrive: [{
			op: "gain",
			resource: "clank",
			n: 1,
			others: !0,
			all: !0
		}],
		discard: []
	},
	{
		id: "pickaxe",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 4,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "rebel-captain",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "companion",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "rebel-miner",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "companion",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "rebel-scout",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 2,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "companion",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "rebel-soldier",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "companion",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "ruby",
		pack: "base",
		copies: 2,
		type: "gem",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 6,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}],
		arrive: [],
		discard: []
	},
	{
		id: "sapphire",
		pack: "base",
		copies: 3,
		type: "gem",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 4,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}],
		arrive: [],
		discard: []
	},
	{
		id: "search",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "scepter-of-the-ape-lord",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 3
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "silver-spear",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 3,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [{
			op: "gain",
			resource: "swords",
			n: 1
		}],
		arrive: [],
		discard: []
	},
	{
		id: "singing-sword",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 3,
		swords: 2,
		boots: 0,
		points: 2,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "sleight-of-hand",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "discard",
			n: 1,
			then: [{
				op: "draw",
				n: 2
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "sneak",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: -2
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "shrine",
		pack: "base",
		copies: 3,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			options: [{
				id: "gold:1",
				effects: [{
					op: "gain",
					resource: "gold",
					n: 1
				}]
			}, {
				id: "heal:1",
				effects: [{
					op: "gain",
					resource: "heal",
					n: 1
				}]
			}]
		}],
		acquire: [],
		arrive: [{
			op: "black",
			n: 3
		}],
		discard: []
	},
	{
		id: "swagger",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "tattle",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 1,
			others: !0
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "teleporter",
		pack: "base",
		copies: 2,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{ op: "teleport" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "the-duke",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 2,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "the-mountain-king",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 6,
		skill: 2,
		swords: 1,
		boots: 1,
		points: 3,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "crown",
			effects: [{
				op: "gain",
				resource: "swords",
				n: 1
			}, {
				op: "gain",
				resource: "boots",
				n: 1
			}]
		}
	},
	{
		id: "the-queen-of-hearts",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 6,
		skill: 3,
		swords: 1,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "crown",
			effects: [{
				op: "gain",
				resource: "heal",
				n: 1
			}]
		}
	},
	{
		id: "the-vault",
		pack: "base",
		copies: 1,
		type: "device",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 5
		}, {
			op: "gain",
			resource: "clank",
			n: 3
		}],
		acquire: [],
		arrive: [],
		discard: [],
		deep: !0
	},
	{
		id: "treasure-hunter",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{ op: "replace" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "treasure-map",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 5
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "tunnel-guide",
		pack: "base",
		copies: 2,
		type: "companion",
		cost: 1,
		skill: 0,
		swords: 1,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "underworld-dealing",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			options: [{
				id: "gold:1",
				effects: [{
					op: "gain",
					resource: "gold",
					n: 1
				}]
			}, {
				id: "tomePaid",
				effects: [{
					op: "tome",
					n: 2,
					pay: 7
				}]
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "wand-of-recall",
		pack: "base",
		copies: 2,
		type: "basic",
		cost: 5,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "artifact",
			effects: [{ op: "teleport" }]
		}
	},
	{
		id: "wand-of-wind",
		pack: "base",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			options: [{
				id: "teleport",
				effects: [{ op: "teleport" }]
			}, {
				id: "adjacent",
				effects: [{ op: "adjacent" }]
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "watcher",
		pack: "base",
		copies: 3,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 3
		}, {
			op: "gain",
			resource: "clank",
			n: 1,
			others: !0
		}],
		acquire: [],
		arrive: [{
			op: "gain",
			resource: "clank",
			n: 1,
			others: !0,
			all: !0
		}],
		discard: []
	},
	{
		id: "wizard",
		pack: "base",
		copies: 1,
		type: "companion",
		cost: 6,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "alchemist",
		pack: "sunken",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "tome",
			effects: [{
				op: "gain",
				resource: "gold",
				n: 2
			}]
		}
	},
	{
		id: "ancient-invocation",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 2
		}, { op: "teleport" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "aspiration",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "gold",
			n: 1
		}],
		arrive: [],
		discard: [],
		conditional: {
			when: "crown",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "black-pearl",
		pack: "sunken",
		copies: 1,
		type: "gem",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 5,
		dragon: !0,
		danger: !1,
		play: [{
			op: "discard",
			n: 1,
			then: [{
				op: "draw",
				n: 2
			}]
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}],
		arrive: [],
		discard: []
	},
	{
		id: "boomerang",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 1,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [{ op: "boomerang" }]
	},
	{
		id: "burglars-boots",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			options: [
				{
					id: "clank:-2",
					effects: [{
						op: "gain",
						resource: "clank",
						n: -2
					}]
				},
				{
					id: "boots:1",
					effects: [{
						op: "gain",
						resource: "boots",
						n: 1
					}]
				},
				{
					id: "gold:1",
					effects: [{
						op: "gain",
						resource: "gold",
						n: 1
					}]
				}
			]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "climbing-gear",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "discard",
			n: 1,
			then: [{
				op: "gain",
				resource: "boots",
				n: 1
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "coin-purse",
		pack: "sunken",
		copies: 2,
		type: "basic",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		acquire: [{
			op: "gain",
			resource: "gold",
			n: 3
		}],
		arrive: [],
		discard: [{
			op: "gain",
			resource: "gold",
			n: 5
		}]
	},
	{
		id: "crystal-fish",
		pack: "sunken",
		copies: 2,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: [],
		cave: !0,
		water: !0
	},
	{
		id: "deep-dive",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "discard",
			n: 3,
			then: [{
				op: "draw",
				n: 5
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "elven-ranger",
		pack: "sunken",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 1,
		swords: 1,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "eye-in-the-water",
		pack: "sunken",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			options: [{
				id: "gold:2",
				effects: [{
					op: "gain",
					resource: "gold",
					n: 2
				}]
			}, {
				id: "clank:-2",
				effects: [{
					op: "gain",
					resource: "clank",
					n: -2
				}]
			}]
		}],
		acquire: [],
		arrive: [{
			op: "gain",
			resource: "clank",
			n: 2,
			others: !0,
			all: !0
		}],
		discard: []
	},
	{
		id: "fishing-pole",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}, {
			op: "discard",
			n: 1,
			then: []
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "grand-plan",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		acquire: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		arrive: [],
		discard: []
	},
	{
		id: "pickpocket",
		pack: "sunken",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "acquire",
			max: 2
		}],
		acquire: [],
		arrive: [],
		discard: [{
			op: "acquire",
			max: 2
		}]
	},
	{
		id: "pipe-organ",
		pack: "sunken",
		copies: 1,
		type: "device",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{ op: "organ" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "medic",
		pack: "sunken",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "discard",
			n: 1,
			then: [{
				op: "gain",
				resource: "heal",
				n: 1
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "merling",
		pack: "sunken",
		copies: 2,
		type: "companion",
		cost: 2,
		skill: 1,
		swords: 1,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "mermaid",
		pack: "sunken",
		copies: 2,
		type: "companion",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "flag",
			flag: "scuba"
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "rebel-brawler",
		pack: "sunken",
		copies: 1,
		type: "companion",
		cost: 1,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "companion",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "rebel-scholar",
		pack: "sunken",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "companion",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "saurian",
		pack: "sunken",
		copies: 2,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !0,
		play: [{
			op: "gain",
			resource: "gold",
			n: 4
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "short-cut",
		pack: "sunken",
		copies: 1,
		type: "basic",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "boots",
			n: 1
		}],
		arrive: [],
		discard: [{
			op: "gain",
			resource: "boots",
			n: 2
		}]
	},
	{
		id: "shrine-of-the-mermaid",
		pack: "sunken",
		copies: 2,
		type: "device",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !0,
		play: [{
			op: "choose",
			options: [{
				id: "gold:2",
				effects: [{
					op: "gain",
					resource: "gold",
					n: 2
				}]
			}, {
				id: "waterTeleport",
				effects: [{
					op: "teleport",
					water: !0
				}]
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "silver-pearl",
		pack: "sunken",
		copies: 1,
		type: "gem",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !0,
		danger: !1,
		play: [{
			op: "discard",
			n: 1,
			then: [{
				op: "draw",
				n: 2
			}]
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}],
		arrive: [],
		discard: []
	},
	{
		id: "sorcerer",
		pack: "sunken",
		copies: 1,
		type: "monster",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "tome",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: [],
		deep: !0
	},
	{
		id: "white-pearl",
		pack: "sunken",
		copies: 2,
		type: "gem",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !0,
		danger: !1,
		play: [{
			op: "discard",
			n: 1,
			then: [{
				op: "draw",
				n: 2
			}]
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}],
		arrive: [],
		discard: []
	},
	{
		id: "blessed-fountain",
		pack: "mummy",
		copies: 2,
		type: "device",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "heal",
			n: 1
		}, {
			op: "gain",
			resource: "curse",
			n: -1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "book-of-the-dead",
		pack: "mummy",
		copies: 1,
		type: "basic",
		cost: 7,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 3
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "bullwhip",
		pack: "mummy",
		copies: 2,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 1,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "camel",
		pack: "mummy",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 1,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "secret",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "canopic-jars",
		pack: "mummy",
		copies: 1,
		type: "device",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 4
		}, {
			op: "gain",
			resource: "curse",
			n: 1
		}],
		acquire: [],
		arrive: [{ op: "roll" }],
		discard: []
	},
	{
		id: "crocodilian",
		pack: "mummy",
		copies: 2,
		type: "monster",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: -1
		}, {
			op: "gain",
			resource: "curse",
			n: -1
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "crystal-skull",
		pack: "mummy",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "twoGems",
			effects: [{
				op: "tome",
				n: 1
			}]
		}
	},
	{
		id: "death-mask",
		pack: "mummy",
		copies: 2,
		type: "basic",
		cost: 4,
		skill: 2,
		swords: 2,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "curse",
			n: -1
		}],
		acquire: [],
		arrive: [{ op: "roll" }],
		discard: []
	},
	{
		id: "doomsayer",
		pack: "mummy",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 2,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "noise",
			effects: [{
				op: "gain",
				resource: "curse",
				n: 1,
				others: !0
			}]
		}
	},
	{
		id: "daring-explorer",
		pack: "mummy",
		copies: 1,
		type: "companion",
		cost: 6,
		skill: 2,
		swords: 0,
		boots: 1,
		points: 3,
		dragon: !1,
		danger: !0,
		play: [{
			op: "adjacent",
			idol: !0,
			noise: 2,
			optional: !0
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "excavate",
		pack: "mummy",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: 2
		}, {
			op: "draw",
			n: 2
		}],
		acquire: [],
		arrive: [{ op: "roll" }],
		discard: []
	},
	{
		id: "historian",
		pack: "mummy",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "noise",
			effects: [{ op: "trash" }]
		}
	},
	{
		id: "jasper",
		pack: "mummy",
		copies: 2,
		type: "gem",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 7,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}, {
			op: "gain",
			resource: "curse",
			n: 1
		}],
		arrive: [],
		discard: []
	},
	{
		id: "kittypatra",
		pack: "mummy",
		copies: 1,
		type: "companion",
		cost: 1,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			options: [{
				id: "clank:-2",
				effects: [{
					op: "gain",
					resource: "clank",
					n: -2
				}]
			}, {
				id: "curse:-1",
				effects: [{
					op: "gain",
					resource: "curse",
					n: -1
				}]
			}]
		}],
		acquire: [],
		arrive: [{ op: "roll" }],
		discard: []
	},
	{
		id: "lapis-lazuli",
		pack: "mummy",
		copies: 1,
		type: "gem",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 8,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}, {
			op: "gain",
			resource: "curse",
			n: 1
		}],
		arrive: [],
		discard: []
	},
	{
		id: "need-for-greed",
		pack: "mummy",
		copies: 2,
		type: "basic",
		cost: 2,
		skill: 1,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "discard",
			n: 1,
			then: [{
				op: "gain",
				resource: "gold",
				n: 2
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "ornate-khopesh",
		pack: "mummy",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 0,
		swords: 3,
		boots: 0,
		points: 3,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "swords",
			n: 3
		}],
		arrive: [],
		discard: []
	},
	{
		id: "purify",
		pack: "mummy",
		copies: 1,
		type: "basic",
		cost: 5,
		skill: 3,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [{
			op: "gain",
			resource: "curse",
			n: -1
		}],
		arrive: [],
		discard: []
	},
	{
		id: "rebel-burglar",
		pack: "mummy",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "trash",
			burgle: !0
		}],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "companion",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "rebel-mystic",
		pack: "mummy",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{ op: "teleport" }],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "companion",
			effects: [{
				op: "draw",
				n: 1
			}]
		}
	},
	{
		id: "ring-of-wishes",
		pack: "mummy",
		copies: 1,
		type: "device",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			times: 3,
			options: [
				{
					id: "gold:1",
					effects: [{
						op: "gain",
						resource: "gold",
						n: 1
					}]
				},
				{
					id: "boots:1",
					effects: [{
						op: "gain",
						resource: "boots",
						n: 1
					}]
				},
				{
					id: "curse:-1",
					effects: [{
						op: "gain",
						resource: "curse",
						n: -1
					}]
				}
			]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "royal-bodyguard",
		pack: "mummy",
		copies: 2,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "crown",
			effects: [{
				op: "flag",
				flag: "ignoreIcons"
			}]
		}
	},
	{
		id: "scorpion-queen",
		pack: "mummy",
		copies: 1,
		type: "monster",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{ op: "scorpion" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "serpentine",
		pack: "mummy",
		copies: 2,
		type: "gem",
		cost: 4,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 6,
		dragon: !0,
		danger: !1,
		play: [{
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 2
		}, {
			op: "gain",
			resource: "curse",
			n: 1
		}],
		arrive: [],
		discard: []
	},
	{
		id: "staff-of-the-ancients",
		pack: "mummy",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 2
		}],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "gem",
			effects: [{ op: "teleport" }]
		}
	},
	{
		id: "stone-simian",
		pack: "mummy",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 3
		}],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "idol",
			effects: [{
				op: "gain",
				resource: "heal",
				n: 1
			}]
		}
	},
	{
		id: "thrill-seeker",
		pack: "mummy",
		copies: 2,
		type: "companion",
		cost: 4,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "noise",
			effects: [{
				op: "gain",
				resource: "boots",
				n: 2
			}]
		}
	},
	{
		id: "tomb-robber",
		pack: "mummy",
		copies: 1,
		type: "companion",
		cost: 4,
		skill: 0,
		swords: 1,
		boots: 2,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [{ op: "roll" }],
		discard: [],
		conditional: {
			when: "artifact",
			effects: [{
				op: "gain",
				resource: "gold",
				n: 2
			}]
		}
	},
	{
		id: "tomb-snake",
		pack: "mummy",
		copies: 2,
		type: "monster",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "skill",
			n: 2
		}],
		acquire: [],
		arrive: [{
			op: "gain",
			resource: "clank",
			n: 1,
			others: !0,
			all: !0
		}],
		discard: [],
		deep: !0
	},
	{
		id: "whiskersphinx",
		pack: "mummy",
		copies: 1,
		type: "monster",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "draw",
			n: 2
		}, {
			op: "gain",
			resource: "curse",
			n: -1
		}],
		acquire: [],
		arrive: [{ op: "roll" }],
		discard: []
	},
	{
		id: "brawn-vs-boots",
		pack: "promo",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			options: [{
				id: "swords:2",
				effects: [{
					op: "gain",
					resource: "swords",
					n: 2
				}]
			}, {
				id: "boots:2",
				effects: [{
					op: "gain",
					resource: "boots",
					n: 2
				}]
			}]
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "enchanted-dice",
		pack: "promo",
		copies: 1,
		type: "basic",
		cost: 3,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{ op: "dice" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "dire-wolf",
		pack: "promo",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 1,
		swords: 0,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{ op: "direWolf" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "expedition-leader",
		pack: "promo",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 2,
		swords: 1,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "friendly-watcher",
		pack: "promo",
		copies: 1,
		type: "companion",
		cost: 5,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "gain",
			resource: "gold",
			n: 3
		}, {
			op: "gain",
			resource: "clank",
			n: 1,
			others: !0
		}],
		acquire: [],
		arrive: [{
			op: "gain",
			resource: "clank",
			n: 1,
			others: !0,
			all: !0
		}],
		discard: []
	},
	{
		id: "magic-spectacles",
		pack: "promo",
		copies: 1,
		type: "basic",
		cost: 4,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{ op: "peek" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "mummy-hunters",
		pack: "promo",
		copies: 1,
		type: "companion",
		cost: 2,
		skill: 0,
		swords: 2,
		boots: 1,
		points: 1,
		dragon: !1,
		danger: !1,
		play: [{
			op: "flag",
			flag: "immuneMummy"
		}],
		acquire: [],
		arrive: [{ op: "roll" }],
		discard: []
	},
	{
		id: "opal-apestone",
		pack: "promo",
		copies: 1,
		type: "gem",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 3,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "clank",
			n: -1
		}, {
			op: "draw",
			n: 1
		}],
		acquire: [{
			op: "gain",
			resource: "clank",
			n: 3
		}],
		arrive: [],
		discard: []
	},
	{
		id: "siren",
		pack: "promo",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{
			op: "acquire",
			companion: !0
		}],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "snack-table",
		pack: "promo",
		copies: 1,
		type: "device",
		cost: 2,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !0,
		danger: !1,
		play: [{
			op: "gain",
			resource: "heal",
			n: 1
		}, { op: "snack" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "trailblazer",
		pack: "promo",
		copies: 1,
		type: "companion",
		cost: 3,
		skill: 1,
		swords: 1,
		boots: 1,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [],
		acquire: [],
		arrive: [],
		discard: [],
		conditional: {
			when: "feature",
			effects: [{
				op: "gain",
				resource: "gold",
				n: 2
			}]
		}
	},
	{
		id: "wand-of-time",
		pack: "promo",
		copies: 1,
		type: "basic",
		cost: 6,
		skill: 2,
		swords: 0,
		boots: 0,
		points: 2,
		dragon: !1,
		danger: !1,
		play: [{ op: "recall" }],
		acquire: [],
		arrive: [],
		discard: []
	},
	{
		id: "wishing-wall",
		pack: "promo",
		copies: 1,
		type: "device",
		cost: 6,
		skill: 0,
		swords: 0,
		boots: 0,
		points: 0,
		dragon: !1,
		danger: !1,
		play: [{
			op: "choose",
			times: 2,
			distinct: !0,
			options: [
				{
					id: "trash",
					effects: [{ op: "trash" }]
				},
				{
					id: "swords:2",
					effects: [{
						op: "gain",
						resource: "swords",
						n: 2
					}]
				},
				{
					id: "boots:2",
					effects: [{
						op: "gain",
						resource: "boots",
						n: 2
					}]
				},
				{
					id: "heal:1",
					effects: [{
						op: "gain",
						resource: "heal",
						n: 1
					}]
				}
			]
		}],
		acquire: [],
		arrive: [],
		discard: []
	}
], j = Object.fromEntries(A.map((e) => [e.id, e])), M = (e) => e.players[e.active], N = (e, t) => e.players.find((e) => e.rid === t);
function ee() {
	return {
		skill: 0,
		swords: 0,
		boots: 0,
		stopped: !1,
		mined: !1,
		negativeClank: 0,
		noiseMade: 0,
		goldEvents: 0,
		secretFound: !1,
		featureUsed: !1,
		needsAir: !1,
		flags: [],
		triggered: [],
		grants: {},
		trashed: []
	};
}
//#endregion
//#region src/games/clank/core.ts
var P = [
	2,
	2,
	3,
	3,
	4,
	4,
	5
], te = {
	refill: 420,
	dragon: 600,
	advance: 420,
	effect: 240
};
function F(t, n) {
	return e(t.seed, t.cursor++, n);
}
function I(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = F(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function L(e, t) {
	return {
		uid: e.uid++,
		kind: t
	};
}
function R(e, t, n, r, i = !1) {
	let a = r.map((e) => ({
		rid: t,
		source: n,
		effect: e
	}));
	i ? e.queue.unshift(...a) : e.queue.push(...a);
}
function z(e, t, n) {
	for (let r = 0; r < n; r++) {
		t.deck.length || (t.deck = I(e, t.discard), t.discard = []);
		let n = t.deck.shift();
		if (!n) break;
		t.hand.push(n);
	}
}
function B(e, t) {
	let n = Math.min(e.damage, t);
	e.damage -= n, e.supply += n;
}
function V(e, t, n) {
	t.gold += n, n > 0 && t.rid === M(e).rid && e.turn.goldEvents++;
}
function ne(e, t, n) {
	if (t.state !== "active" && t.rid !== M(e).rid) return;
	let r = t.rid === M(e).rid;
	if (n < 0) {
		let i = Math.min(t.clank, -n);
		t.clank -= i, t.supply += i, r && (e.turn.negativeClank += -n - i);
		return;
	}
	let i = r ? Math.min(n, e.turn.negativeClank) : 0;
	r && (e.turn.negativeClank -= i);
	let a = Math.min(n - i, t.supply);
	t.supply -= a, t.clank += a, r && (e.turn.noiseMade += a);
}
function re(e, t, n, r = !1) {
	r && t.rid === M(e).rid && e.turn.flags.includes("immuneMummy") || (t.curses = Math.max(0, t.curses + n), n > 0 && t.rid === M(e).rid && (e.turn.featureUsed = !0));
}
function ie(e, t, n = !1) {
	t.state === "active" && (t.state = n ? "escaped" : "knocked", e.log.push({
		event: n ? "escape" : "knockout",
		rid: t.rid
	}), e.countdown ??= {
		rid: t.rid,
		step: 0
	});
}
function ae(e, t, n, r = !1) {
	if (t.state !== "active") {
		r && (t.removed += n);
		return;
	}
	if (r) {
		let e = Math.min(10 - t.damage, n);
		t.damage += e, t.removed += n - e;
	} else {
		let r = Math.min(n, t.supply);
		if (t.supply -= r, t.damage += r, r < n) {
			ie(e, t);
			return;
		}
	}
	e.log.push({
		event: "damage",
		rid: t.rid,
		n
	}), t.damage >= 10 && ie(e, t);
}
function oe(e, t) {
	return e.splice(t, 1)[0];
}
//#endregion
//#region src/games/clank/gears.ts
var se = [
	{
		id: "tri-wrench-lock",
		sides: 3,
		symbol: "wrench",
		routes: [{
			a: 0,
			b: 1,
			locked: !0
		}, {
			a: 0,
			b: 2
		}]
	},
	{
		id: "tri-cog",
		sides: 3,
		symbol: "cog",
		routes: [{
			a: 0,
			b: 2,
			monsters: 2
		}]
	},
	{
		id: "tri-banana",
		sides: 3,
		symbol: "banana",
		routes: [{
			a: 1,
			b: 2,
			locked: !0,
			monsters: 2
		}]
	},
	{
		id: "tri-wrench",
		sides: 3,
		symbol: "wrench",
		routes: [{
			a: 0,
			b: 1,
			monsters: 1
		}, {
			a: 0,
			b: 2,
			boots: 2
		}]
	},
	{
		id: "square-cog",
		sides: 4,
		symbol: "cog",
		routes: [{
			a: 1,
			b: 0,
			boots: 2
		}, {
			a: 1,
			b: 2,
			monsters: 1
		}]
	},
	{
		id: "square-banana-cross",
		sides: 4,
		symbol: "banana",
		routes: [{
			a: 0,
			b: 1,
			boots: 2
		}, {
			a: 2,
			b: 3
		}]
	},
	{
		id: "square-banana",
		sides: 4,
		symbol: "banana",
		routes: [{
			a: 2,
			b: 0,
			monsters: 1
		}, {
			a: 2,
			b: 3
		}]
	},
	{
		id: "square-wrench",
		sides: 4,
		symbol: "wrench",
		routes: [{
			a: 2,
			b: 0,
			boots: 2
		}, {
			a: 2,
			b: 1
		}]
	},
	{
		id: "pent-cog",
		sides: 5,
		symbol: "cog",
		routes: [{
			a: 0,
			b: 2,
			boots: 2,
			monsters: 1
		}, {
			a: 3,
			b: 4,
			locked: !0
		}]
	}
], ce = Object.fromEntries(se.map((e) => [e.id, e]));
//#endregion
//#region src/games/clank/maps/build.ts
function H(e, t) {
	return e.map(([e, n, r = ""], i) => {
		let a = {
			id: i,
			x: e,
			y: n,
			deep: n > t
		};
		for (let e of r.split(" ")) {
			let t = Number(e.slice(1)) || 1;
			e === "c" && (a.cave = !0), e === "w" && (a.water = !0), e === "s" && (a.market = !0), e === "W" && (a.webbed = !0), e === "d" && (a.deep = !0), e === "t" && (a.deep = !1), e.startsWith("m") && (a.minor = t), e.startsWith("M") && (a.major = t), e.startsWith("a") && (a.artifact = t), e.startsWith("i") && (a.idols = t), e.startsWith("h") && (a.heal = t), e.startsWith("g") && (a.gold = t), e.startsWith("z") && (a.zone = Number(e.slice(1)));
		}
		return a;
	});
}
function U(e) {
	return e.trim().split(/\s+/).filter(Boolean).map((e, t) => {
		let [n, ...r] = e.split(":"), [i, a] = n.split(/[-~>]/).map(Number), o = {
			id: t,
			a: i,
			b: a
		};
		n.includes(">") && (o.oneWay = !0);
		for (let e of r) {
			let t = Number(e.slice(1)) || 1;
			e === "k" && (o.locked = !0), e === "e" && (o.elevator = !0), e === "w" && (o.web = !0), e === "a" && (o.apparatus = !0), e === "r" && (o.wrap = !0), e.startsWith("b") && (o.boots = t), e.startsWith("s") && (o.monsters = t), e.startsWith("n") && (o.clank = t), e.startsWith("u") && (o.curse = t);
		}
		return o;
	});
}
function le(e) {
	let t = new Set(e.rooms.map((e) => e.id));
	for (let n of e.tunnels) if (!t.has(n.a) || !t.has(n.b)) throw Error(`Invalid Clank map ${e.id}: ${n.id}`);
	return e;
}
//#endregion
//#region src/games/clank/maps/base.ts
var ue = le({
	id: "base-front",
	family: "base",
	rooms: H([
		[100, 105],
		[105, 220],
		[345, 220],
		[
			575,
			225,
			"m2"
		],
		[
			790,
			230,
			"M"
		],
		[
			1030,
			185,
			"M"
		],
		[
			150,
			380,
			"c M"
		],
		[
			400,
			415,
			"c"
		],
		[
			580,
			415,
			"M"
		],
		[
			790,
			450,
			"c"
		],
		[1e3, 375],
		[110, 580],
		[
			310,
			600,
			"m2"
		],
		[
			560,
			620,
			"c"
		],
		[790, 630],
		[
			1010,
			570,
			"m2"
		],
		[150, 760],
		[
			385,
			785,
			"c a5"
		],
		[
			610,
			830,
			"s m2"
		],
		[
			840,
			830,
			"s m2"
		],
		[
			1020,
			740,
			"a7"
		],
		[
			1210,
			785,
			"c"
		],
		[
			260,
			910,
			"c a15"
		],
		[
			365,
			1035,
			"M"
		],
		[
			610,
			1e3,
			"s"
		],
		[
			840,
			1e3,
			"s a10"
		],
		[
			1020,
			930,
			"c M"
		],
		[
			1300,
			980,
			"M"
		],
		[
			110,
			1090,
			"i3"
		],
		[
			350,
			1160,
			"m2"
		],
		[
			570,
			1185,
			"a20"
		],
		[
			770,
			1195,
			"c"
		],
		[
			980,
			1235,
			"a25"
		],
		[
			1160,
			1095,
			"h"
		],
		[
			1300,
			1145,
			"a30"
		],
		[160, 1325],
		[
			435,
			1335,
			"M"
		],
		[
			700,
			1335,
			"h"
		],
		[
			1200,
			1295,
			"c M"
		]
	], 700),
	tunnels: U("\n    0-1 1-2 2-3:b2 3-4:b2 5>4 5-10:k\n    6>2:b2 6-11:s1 2-7 3-8:k 3-9 4-9:s1 9-10:b2 10-15\n    7-12:b2 7-13:s1 8-13:k 9-14:s1 11-16:b2 12-16:s1 13-14 13-17:b2 13-18:s2 14-20:k 15-20\n    16-17 16-21:r 16-22 16>28:s1 17-23:b2:s1 17-24 18-24 19-20 19-26:s1 21-27:k\n    23-24:k 24-25 24-29:b2 24-30:s2 25-31:k 27-34:s1 28>22 29>28:b2 29-30:s2 29-35\n    30-31:k 30-36:s1 30-37:b2 31-32:s2 32-33:b2:s1 32-37:s2 32-38 33>26 35-36:k 36-37 37-38:b2:s1\n  ")
}), de = le({
	id: "base-back",
	family: "base",
	rooms: H([
		[100, 150],
		[450, 210],
		[620, 280],
		[
			880,
			260,
			"m2"
		],
		[
			100,
			300,
			"M"
		],
		[
			275,
			330,
			"c"
		],
		[455, 370],
		[
			620,
			450,
			"c"
		],
		[790, 430],
		[985, 420],
		[
			1130,
			360,
			"c m2"
		],
		[
			110,
			430,
			"m2"
		],
		[
			100,
			610,
			"M"
		],
		[
			285,
			580,
			"m2"
		],
		[
			475,
			560,
			"c"
		],
		[615, 590],
		[
			775,
			580,
			"M"
		],
		[
			960,
			620,
			"c"
		],
		[
			1150,
			585,
			"s"
		],
		[
			140,
			765,
			"M"
		],
		[
			440,
			750,
			"s"
		],
		[
			600,
			740,
			"M"
		],
		[
			865,
			755,
			"a7"
		],
		[
			1300,
			850,
			"i3"
		],
		[
			1070,
			860,
			"m2"
		],
		[
			360,
			900,
			"a10"
		],
		[
			655,
			905,
			"s"
		],
		[
			860,
			920,
			"s"
		],
		[
			1100,
			1025,
			"a5"
		],
		[
			275,
			1035,
			"m2"
		],
		[
			500,
			1025,
			"a20"
		],
		[
			700,
			1080,
			"c M"
		],
		[
			900,
			1070,
			"M"
		],
		[
			105,
			1135,
			"s"
		],
		[
			1275,
			1140,
			"m2"
		],
		[
			260,
			1205,
			"a25"
		],
		[
			420,
			1195,
			"c"
		],
		[
			645,
			1210,
			"m2"
		],
		[
			945,
			1195,
			"a15"
		],
		[
			130,
			1320,
			"M"
		],
		[
			330,
			1330,
			"a30"
		],
		[
			625,
			1325,
			"m2"
		],
		[
			815,
			1305,
			"c h"
		],
		[
			1130,
			1300,
			"M"
		]
	], 700),
	tunnels: U("\n    0-1 1>2 6>1 5-6 4-5:s2 4-10:r 11-5 5-13 11-12:k 13-12:k 13-14\n    6-7:s3 7-2 7-8 8-9 2>3:b2 3-10:b2 3-9 9-17 9-18:s1 10-18 8-16 8-17\n    7-14 7-15 15-21:s1 14-20:s1 13-19:b2 20-25:s1 20-26 21-26:s1\n    22-16:k 22-26 22-27:s1 22-24 17-24 17-23:s1 18-23:s2 23>28 34>23\n    19-29 25-29:s1 26-31 27-28 27-32 24-28 29-33:k 29-35:k 29-36\n    30>31 30-37:s1 28-38:s1 28-34:b2 38-37:s1 38-43:s2 34-43:k\n    33-39 39-40 40-41:s1 36-41:b2:s1 36-37 37-42 41-42:s1\n  ")
}), fe = le({
	id: "sunken-boat",
	family: "sunken",
	rooms: H([
		[100, 140],
		[100, 215],
		[280, 220],
		[
			475,
			220,
			"m2"
		],
		[
			730,
			240,
			"c M"
		],
		[
			980,
			195,
			"M"
		],
		[
			135,
			420,
			"w m2"
		],
		[
			345,
			380,
			"c m2"
		],
		[
			585,
			400,
			"c M"
		],
		[
			930,
			360,
			"g1"
		],
		[
			780,
			535,
			"c m2"
		],
		[
			1020,
			535,
			"c M"
		],
		[
			85,
			570,
			"w M"
		],
		[
			320,
			540,
			"c g1"
		],
		[
			140,
			735,
			"w"
		],
		[
			330,
			740,
			"s"
		],
		[
			520,
			780,
			"s m2"
		],
		[
			685,
			780,
			"s a5"
		],
		[
			850,
			780,
			"s"
		],
		[
			1050,
			780,
			"w a20"
		],
		[
			1230,
			780,
			"c m2"
		],
		[
			130,
			970,
			"c m2"
		],
		[
			380,
			1e3,
			"w m2"
		],
		[
			630,
			1010,
			"w a7"
		],
		[
			845,
			1005,
			"w m2"
		],
		[
			1040,
			915,
			"c h"
		],
		[
			1250,
			920,
			"m2"
		],
		[
			100,
			1150,
			"a15"
		],
		[
			290,
			1230,
			"i3"
		],
		[
			505,
			1135,
			"c M"
		],
		[
			755,
			1150,
			"c M"
		],
		[
			920,
			1160,
			"w g1"
		],
		[
			1110,
			1075,
			"c a10"
		],
		[
			1290,
			1100,
			"h"
		],
		[
			135,
			1330,
			"w M"
		],
		[
			540,
			1340,
			"w a25"
		],
		[
			755,
			1340,
			"w M"
		],
		[
			940,
			1320,
			"w M"
		],
		[
			1150,
			1280,
			"w a30"
		]
	], 650),
	tunnels: U("\n    0-1 1-2 2-3:b2 3-4:s2 4-5:s1 5-9:k 2-6:s1 2-7 2-8:k 3>9 4-9\n    6-12 6-13 7-13 8-13 8-9:k 8-10:s2 9-10 9-11:s2 10-18:s1 11-18\n    12>13 12-14 12-15:s1 13-15 13-16:s1 14-15 15-16 16-17 17-18 11-19:k\n    19-20:s3 14-20:r 14-21 14-22 15>22:n2 22>16 16>23:n1 23>17 17-24:k\n    24>18:n1 18-25:b2 19-26:k 20-26 21-26:r 21-22:s2 22-23 23-24\n    24-26 25-26 21-27:b2 22-28:s1 22-29 23-29:s2 23-30:k 24-31 24-32\n    26>33 27-28 27-34 28-29:s1 28-34 28-35 29-30:s2 29-35:k 30-36:k\n    31-33:s1 32-33 32-38 33>38:b2 34-35 35-36 36-37 37-38:s1 31-37\n  ")
}), pe = le({
	id: "sunken-sewer",
	family: "sunken",
	rooms: H([
		[100, 140],
		[140, 250],
		[425, 210],
		[
			625,
			200,
			"m2"
		],
		[
			835,
			235,
			"h"
		],
		[
			1100,
			190,
			"w M"
		],
		[125, 400],
		[
			425,
			390,
			"m2"
		],
		[
			625,
			350,
			"c M"
		],
		[
			765,
			400,
			"c m2"
		],
		[
			950,
			375,
			"w M"
		],
		[
			1130,
			375,
			"w m2"
		],
		[
			1125,
			525,
			"w m2"
		],
		[
			285,
			515,
			"M"
		],
		[
			460,
			540,
			"c g1"
		],
		[660, 570],
		[895, 585],
		[
			265,
			715,
			"c a5"
		],
		[
			425,
			740,
			"s m2"
		],
		[
			740,
			705,
			"c h"
		],
		[
			1075,
			715,
			"s m2"
		],
		[
			1220,
			725,
			"M"
		],
		[
			235,
			915,
			"M"
		],
		[425, 955],
		[
			625,
			905,
			"s a7"
		],
		[
			895,
			825,
			"s a10"
		],
		[
			1100,
			940,
			"M"
		],
		[
			1300,
			890,
			"c"
		],
		[
			80,
			1150,
			"w m2"
		],
		[
			310,
			1120,
			"c a15"
		],
		[
			570,
			1120,
			"c g1"
		],
		[
			775,
			1080,
			"i3"
		],
		[
			960,
			1165,
			"w g1"
		],
		[
			1110,
			1075,
			"c w a30"
		],
		[
			1310,
			1070,
			"w a20"
		],
		[
			150,
			1320,
			"w M"
		],
		[
			360,
			1305,
			"w m2"
		],
		[
			580,
			1345,
			"w a25"
		],
		[
			815,
			1345,
			"w M"
		],
		[
			1030,
			1335,
			"w m2"
		],
		[
			1220,
			1270,
			"w M"
		]
	], 650),
	tunnels: U("\n    0-1 1-2 2-3:b2 4>3 2>7 7>2:k 2>6 6-7 6-13 7-13 7-14 7-8:k\n    8-14 8-15 3-9 9-15:b2 9-16 9-10 10-4 10-5 5-11 10-11 10-12\n    11-12 10-16:s2 12-16 12-20 13-17 14-15 14-18:s1 15-19 16-19:s1\n    15-24:s2 17-18 6-11:r 17-20:k:r 20-21 17-22:b2 18-22:k 18-24:s1\n    19-24 19-25 20-25 20-26:k 21-27:b2 22-28 23-24 23-29:s1 23>36:n1 23-37\n    24-30:s1 24-31:s1 25>32:n1 25-26 26-32:b2 26-34:s1 27-34\n    28-29:s1 28-35 29-35 29-36 30>31 30-37:s2 31>39 31-38:k\n    32-33 32-39 33-40 34-40:s1 35-36 36-37 37-38 38-39 39-40\n    6>28:n3\n  ")
}), me = le({
	id: "mummy-pyramid",
	family: "mummy",
	rooms: H([
		[
			90,
			140,
			"z0"
		],
		[
			110,
			220,
			"z0"
		],
		[
			350,
			210,
			"z0"
		],
		[
			600,
			205,
			"m2 z0"
		],
		[
			800,
			215,
			"M z0"
		],
		[
			975,
			145,
			"c M z0"
		],
		[
			105,
			410,
			"c M z0"
		],
		[
			490,
			340,
			"c m2 z0"
		],
		[
			710,
			400,
			"m2 z0"
		],
		[
			1040,
			365,
			"a5 z1 d"
		],
		[
			1190,
			245,
			"c a25 z1 d"
		],
		[
			1305,
			400,
			"m2 z1 d"
		],
		[
			280,
			540,
			"z0"
		],
		[
			590,
			525,
			"z0"
		],
		[
			140,
			685,
			"z0"
		],
		[
			455,
			635,
			"c m2 z0"
		],
		[
			735,
			695,
			"c h z1 d"
		],
		[
			910,
			575,
			"i3 z1 d"
		],
		[
			1200,
			540,
			"s z1 d"
		],
		[
			1405,
			595,
			"c M z1 d"
		],
		[
			900,
			850,
			"m2 z3 d"
		],
		[
			1180,
			770,
			"c m2 z1 d"
		],
		[
			260,
			855,
			"c M z0"
		],
		[
			600,
			830,
			"s m2 z2 d"
		],
		[
			125,
			985,
			"m2 z0"
		],
		[
			450,
			975,
			"s z2 d"
		],
		[
			720,
			970,
			"s a7 z2 d"
		],
		[
			1050,
			950,
			"a15 z3 d"
		],
		[
			1300,
			1010,
			"M z3 d"
		],
		[
			565,
			1095,
			"M z2 d"
		],
		[
			270,
			1165,
			"c m2 z2 d"
		],
		[
			940,
			1120,
			"c i10 z3 d"
		],
		[
			1135,
			1095,
			"z3 d"
		],
		[
			130,
			1310,
			"M z2 d"
		],
		[
			420,
			1305,
			"a10 z2 d"
		],
		[
			605,
			1300,
			"c M z2 d"
		],
		[
			835,
			1305,
			"a20 z3 d"
		],
		[
			1035,
			1300,
			"c M z3 d"
		],
		[
			1230,
			1225,
			"a30 z3 d"
		]
	], Infinity),
	tunnels: U("\n    0-1 1-2 6>1 6-2:s2 2-3:b2 2-7:s1 2-12 3>8 3-4:k 4-8:k 4-9:u2\n    5-9 8-9 7-13 8-13 20>8 12-14 6-14:u1:s1 12-15 13-15 13-23:s1\n    16-23:b2 16-20:u1 16-17:k 9>17:s1 9-18 10-11:k 10-18:u3 11-18\n    11-19:s1 18-21 17-21:u1 21-20 21-27:s1 19-28:u1:b2 14-22:b2\n    14-24 15-22:s3 15-23:u1 22-25 24>30 24-33:u1 25-30 25-23\n    23-26 26-20:s1 20>17:s1 26-29:k 26-31:k 27-31:u1 27-32 28-32:s1\n    29-30:s2 29-34:u1 30-34 34>33 34-35 35-26 35-36:s2 31-36:b2\n    32-36:s1 32-37:s1 32-38:k 36-37 37-38:s2\n  ")
}), he = le({
	id: "mummy-sphinx",
	family: "mummy",
	rooms: H([
		[
			100,
			140,
			"z0"
		],
		[
			255,
			240,
			"z0"
		],
		[
			465,
			240,
			"z0"
		],
		[
			670,
			240,
			"m2 z0"
		],
		[
			920,
			250,
			"i10 z0"
		],
		[
			80,
			380,
			"c z0"
		],
		[
			285,
			420,
			"m2 z0"
		],
		[
			515,
			430,
			"c M z0"
		],
		[
			795,
			420,
			"s M z0"
		],
		[
			975,
			395,
			"m2 z0"
		],
		[
			80,
			565,
			"c M z0"
		],
		[
			245,
			580,
			"z0"
		],
		[
			405,
			580,
			"M z0"
		],
		[
			700,
			580,
			"c m2 z0"
		],
		[
			980,
			585,
			"c M z0"
		],
		[
			130,
			760,
			"m2 z2"
		],
		[
			345,
			770,
			"c a5 z2"
		],
		[
			560,
			780,
			"s z1"
		],
		[
			750,
			770,
			"z1"
		],
		[
			965,
			770,
			"c a7 z3"
		],
		[
			1175,
			770,
			"z3"
		],
		[
			80,
			1040,
			"i3 z2"
		],
		[
			245,
			920,
			"s z2"
		],
		[
			435,
			920,
			"m2 z2"
		],
		[
			705,
			915,
			"a10 z1"
		],
		[
			855,
			950,
			"s m2 z3"
		],
		[
			1075,
			940,
			"m2 z3"
		],
		[
			1300,
			915,
			"c a20 z3"
		],
		[
			590,
			1045,
			"M z1"
		],
		[
			935,
			1130,
			"M z3"
		],
		[
			1070,
			1120,
			"c z3"
		],
		[
			1305,
			1100,
			"h z3"
		],
		[
			490,
			1165,
			"c a15 z1"
		],
		[
			755,
			1185,
			"c h z1"
		],
		[
			100,
			1310,
			"m2 z2"
		],
		[
			305,
			1255,
			"c M z2"
		],
		[
			455,
			1320,
			"a25 z2"
		],
		[
			680,
			1335,
			"M z1"
		],
		[
			855,
			1305,
			"c m2 z3"
		],
		[
			1045,
			1325,
			"M z3"
		],
		[
			1235,
			1240,
			"c a30 z3"
		]
	], 700),
	tunnels: U("\n    0-1 1-2:k 2-3 3-4:b2 1-5 5-2 2-6:k 2-7:s1 5-6:s1 6-7:s2\n    6-10:b2 6-11 7-12:k 7-13:u1 3-13 8>3 8>9 4-9 4>20:u1\n    8-14:s2 9-14:b2 8-18:b2 8-19 10-15:u1 11-15 11-16 12-17:k\n    17>7 13-17 13-18:s1 14-19 14-20:s1 15-20:r 15-22:s1 15>21:b2\n    16-17 16-23:s1 16-22 17-24:k 18-17:s1 18-25 19-20 19-25 19-26:s1\n    20-26 20-27:u2 22>21 22-23:s1 22-32:s1 23-24 23-28:k 24-25\n    24-28:u1 25-26:b2 25-29:b2 25-30:s1 26-27:s2 27-31:b2\n    28-32:b2 28-33 29-33 29-38:u1 30-39:s2 30-40:k 31-40:u1\n    21-32:u1 21>34:b2 34-32 34-35:s2 35-36:s1 35-32:u1 36-33:k\n    36-37:b2 37-38:s1 38-39:k 39-40:u2\n  ")
}), ge = le({
	id: "spider-lair",
	family: "goldSilk",
	rooms: H([
		[95, 120],
		[110, 210],
		[370, 205],
		[
			630,
			205,
			"m2 W"
		],
		[
			850,
			205,
			"c m2"
		],
		[
			88,
			390,
			"c M W"
		],
		[
			295,
			350,
			"c m2"
		],
		[
			485,
			410,
			"m2"
		],
		[670, 385],
		[
			885,
			370,
			"h"
		],
		[
			1140,
			400,
			"c M"
		],
		[
			955,
			540,
			"c M W"
		],
		[1200, 580],
		[
			765,
			565,
			"c m2"
		],
		[
			555,
			595,
			"c M W"
		],
		[
			280,
			550,
			"g1"
		],
		[95, 605],
		[
			95,
			805,
			"M"
		],
		[
			285,
			855,
			"a5"
		],
		[
			440,
			780,
			"m2"
		],
		[600, 780],
		[
			810,
			800,
			"a8"
		],
		[
			1005,
			805,
			"s"
		],
		[
			1150,
			800,
			"M W"
		],
		[
			1330,
			800,
			"m2"
		],
		[
			1280,
			1005,
			"c a10"
		],
		[
			1100,
			995,
			"m2 W"
		],
		[
			860,
			1035,
			"s"
		],
		[
			690,
			1040,
			"i3 W"
		],
		[
			510,
			950,
			"c g3 W"
		],
		[
			330,
			1020,
			"c M W"
		],
		[
			125,
			1015,
			"s"
		],
		[
			130,
			1245,
			"s m2"
		],
		[
			300,
			1195,
			"a20"
		],
		[
			535,
			1125,
			"h"
		],
		[
			855,
			1220,
			"c a15"
		],
		[
			1100,
			1180,
			"c M"
		],
		[
			1285,
			1180,
			"a25"
		],
		[
			420,
			1320,
			"a30"
		],
		[
			660,
			1290,
			"c M"
		],
		[
			1045,
			1320,
			"h"
		]
	], 700),
	tunnels: U("\n    0-1 1-2 2-3:w 3-4 4-10:w 4-9 1-5:k 2-6 2-7:b2 2-8:k 5-6:s2 5-15:s1\n    5-16:b2 6-7:s1 6-15 7-8 7>15 7-14:k 8-3 8-9:s2 8>13 8-14:s1\n    13>9 9-11:k 9>12:w 10-12 11-12:w 11-22:s1 12-22 12-24 13-20 13-21:w\n    14-19:k 14-20:s1 15-18:b2 15-19:s1 16>15 16-17:s1 17-18:s2 17-31:b2\n    18-19 18-29:s1 18-31 19-20 20-21:w 20>28 20>27 21-22:w 21-27\n    22-26 23-24:s1 23-25:s1 23-26:b2 24-25 25-31:r 25-26 26-27\n    26-28 26-36:s1 26-35:w 27-35 28>35 28-29:s1 29-30:k 29-34\n    30-31:w 30-33:s1 31-32:w 31-33:k 32-38:b2:s2 33-34:s2 34>39\n    35-39:w 35-40:s2 36-37:k 36-25:s1 37>25 37-40:b2 38-39:w\n  ")
}), _e = le({
	id: "dwarven-mine",
	family: "goldSilk",
	rooms: H([
		[1110, 110],
		[1110, 175],
		[1110, 320],
		[790, 255],
		[
			595,
			255,
			"m2"
		],
		[
			410,
			285,
			"m2"
		],
		[
			255,
			195,
			"M"
		],
		[
			70,
			110,
			"M"
		],
		[155, 315],
		[
			205,
			455,
			"m2"
		],
		[420, 450],
		[
			585,
			425,
			"c m2"
		],
		[
			755,
			410,
			"M"
		],
		[
			950,
			410,
			"m2"
		],
		[
			250,
			615,
			"c M"
		],
		[575, 615],
		[
			790,
			585,
			"c"
		],
		[
			970,
			615,
			"c h"
		],
		[
			1150,
			580,
			"m2"
		],
		[
			210,
			825,
			"s"
		],
		[
			400,
			835,
			"c a5"
		],
		[
			575,
			860,
			"i3"
		],
		[
			760,
			800,
			"s m2"
		],
		[
			975,
			780,
			"m2"
		],
		[
			1150,
			800,
			"c M"
		],
		[
			1325,
			835,
			"a20"
		],
		[120, 1020],
		[
			315,
			1010,
			"M"
		],
		[
			735,
			1015,
			"a7"
		],
		[
			895,
			960,
			"c a10"
		],
		[
			1075,
			960,
			"s"
		],
		[1265, 1020],
		[
			450,
			1140,
			"s m2"
		],
		[
			265,
			1180,
			"c a15"
		],
		[
			100,
			1270,
			"c M"
		],
		[
			650,
			1180,
			"c h"
		],
		[
			820,
			1150,
			"M"
		],
		[1025, 1125],
		[
			1235,
			1150,
			"M"
		],
		[
			310,
			1340,
			"a25"
		],
		[
			530,
			1340,
			"M"
		],
		[765, 1330],
		[
			985,
			1320,
			"c M"
		],
		[
			1190,
			1285,
			"a30"
		]
	], 730),
	tunnels: U("\n    0-1 1-2 2-3 3-4 4-5:s1 4-6:k 7>6 7-8:s2 8-5:s1 8-9\n    9-4:b2 9-14:s1 10-11 10-14:s2 10-15 11-4:s1 11-3 12-15:s2\n    12-13:k 13-3:s1 13-2:s2 13-16 17>13:k 14-15:k 15-16 15>21\n    16-22 17-18 17-22 18-23 18-24:s1 14-19:s1 19-20 20-27:s1\n    19-26 26-27:s1 22-23:s1 23-24 24-25:s2 23-29:s1 23-30\n    22-28:b2 28>21:s1 21-32:s1 28-32 28-35 28-36:s1 29-36:s1\n    29-30 30-25:b2 30-31 30-38:b2 25-31:s2 31-26:r 31-38\n    27-33:s2 32-33:s1 26-34:s2 34-33:k 34-39:b2 39-40:s1 40-41:b2\n    35-40:s1 35-41 36-37:s1 37-38:s1 38-43:k 41-42:s2 42-43:s1\n    7-34:e 8-26:e\n  "),
	mines: [
		{
			id: 0,
			rooms: [3],
			gold: 1,
			depth: 165,
			x: 830,
			y: 165
		},
		{
			id: 1,
			rooms: [9, 10],
			gold: 1,
			depth: 450,
			x: 320,
			y: 450
		},
		{
			id: 2,
			rooms: [18],
			gold: 2,
			depth: 500,
			x: 1150,
			y: 500
		},
		{
			id: 3,
			rooms: [15, 16],
			gold: 1,
			depth: 650,
			x: 685,
			y: 650
		},
		{
			id: 4,
			rooms: [19, 20],
			gold: 1,
			depth: 760,
			x: 310,
			y: 760
		},
		{
			id: 5,
			rooms: [27],
			gold: 1,
			depth: 940,
			x: 410,
			y: 940
		},
		{
			id: 6,
			rooms: [32],
			gold: 1,
			depth: 1035,
			x: 450,
			y: 1035
		},
		{
			id: 7,
			rooms: [23, 29],
			gold: 1,
			depth: 875,
			x: 965,
			y: 875
		},
		{
			id: 8,
			rooms: [31],
			gold: 1,
			depth: 1075,
			x: 1360,
			y: 1075
		},
		{
			id: 9,
			rooms: [36],
			gold: 2,
			depth: 1180,
			x: 895,
			y: 1180
		},
		{
			id: 10,
			rooms: [37, 42],
			gold: 2,
			depth: 1215,
			x: 1020,
			y: 1215
		},
		{
			id: 11,
			rooms: [40, 41],
			gold: 3,
			depth: 1315,
			x: 650,
			y: 1315
		}
	]
}), ve = le({
	id: "jungle",
	family: "apeLords",
	rooms: H([
		[75, 130],
		[340, 205],
		[550, 205],
		[
			780,
			240,
			"m2"
		],
		[
			1030,
			280,
			"i3"
		],
		[
			75,
			275,
			"M"
		],
		[
			335,
			345,
			"m2"
		],
		[
			535,
			395,
			"c g1"
		],
		[790, 410],
		[
			85,
			510,
			"c h"
		],
		[
			255,
			555,
			"c m2"
		],
		[460, 600],
		[
			650,
			595,
			"c M"
		],
		[
			805,
			590,
			"c m2"
		],
		[
			985,
			515,
			"M"
		],
		[1175, 535],
		[
			95,
			735,
			"m2"
		],
		[365, 790],
		[
			610,
			785,
			"m2"
		],
		[
			865,
			800,
			"c a10"
		],
		[
			1040,
			770,
			"s"
		],
		[
			1265,
			780,
			"c M"
		],
		[
			215,
			885,
			"c a7"
		],
		[
			420,
			985,
			"s a5"
		],
		[
			695,
			965,
			"M"
		],
		[
			890,
			970,
			"s m2"
		],
		[
			1075,
			1020,
			"c h"
		],
		[
			1255,
			1020,
			"a15"
		],
		[125, 1070],
		[
			630,
			1095,
			"m2"
		],
		[
			815,
			1140,
			"c a20"
		],
		[
			300,
			1175,
			"s m2"
		],
		[
			1070,
			1210,
			"g1"
		],
		[
			1255,
			1240,
			"M"
		],
		[
			115,
			1265,
			"c M"
		],
		[
			520,
			1300,
			"M"
		],
		[
			685,
			1270,
			"c M"
		],
		[
			325,
			1340,
			"a25"
		],
		[
			905,
			1300,
			"a33"
		]
	], 680),
	tunnels: U("\n    0-1 1-2 2>3:n1 3>4:n1 5>1:n1:a 5-9:k 6-2:b2:a 6-10:s2 6>11:n1\n    2-7 2-8:k 3-8:s1 4>8:n1:a 7-8:s1:a 7-11:a 7-12:s2 7-13 8-13:s1\n    8-14 9-10 9-16 10>16:n1 10-17:a 11-17 12-18:k 12-19:s1 13-19:s1\n    13-20 14-15:s1 15-20:a 15-21:b2:a 16-22:a 16-28:b2 17-18 17-22\n    17-23 18-19:a 18-23 18-24:s2 19-20 19-24:b2 20-25 20>27:n1:a\n    21-27:s1 22-28:s1 23-24:b2 23-29:s1 23>28:n1:a 23-31:b2:a 24-25:s2\n    25-26 26-27:s1 26>30:n2:a 27-28:r 27-33:s2 28-31 28-34:s1\n    29-30:s1 29-35:b2:a 29-36:k 31-35:s2 32-26:k 32>33:n1\n    34-37:s2 35-37:k 36-38:s2 38-32:b2\n  ")
}), ye = [
	{
		id: 0,
		x: 650,
		y: 390,
		ports: [
			4,
			9,
			8
		]
	},
	{
		id: 1,
		x: 970,
		y: 300,
		ports: [
			5,
			10,
			4
		]
	},
	{
		id: 2,
		x: 685,
		y: 745,
		ports: [
			16,
			17,
			22
		],
		exitOnly: [16]
	},
	{
		id: 3,
		x: 415,
		y: 1320,
		ports: [
			34,
			39,
			38
		]
	},
	{
		id: 4,
		x: 415,
		y: 495,
		ports: [
			8,
			15,
			14,
			7
		]
	},
	{
		id: 5,
		x: 1070,
		y: 650,
		ports: [
			12,
			18,
			23,
			11
		]
	},
	{
		id: 6,
		x: 400,
		y: 850,
		ports: [
			22,
			28,
			33,
			21
		],
		exitOnly: [33]
	},
	{
		id: 7,
		x: 975,
		y: 980,
		ports: [
			27,
			36,
			30,
			26
		]
	},
	{
		id: 8,
		x: 845,
		y: 1260,
		ports: [
			30,
			36,
			40,
			39,
			35
		]
	}
], be = U("\n  0-1 1-2 2-3 3-5:b2 3-4:s2 1-7:k 2-7 6-7 6-13 3-8 8-16:k\n  9-11 10-12 5-10:s2 13-20:s2 14-21 15-22 9-17:s2 12-19:b2\n  18-25 19-25:s1 20-21:s2 20-24:s1 21-24:s1 22-26:b2 17-23:s1\n  23-27 25-27 25-31:k 27-31:s2 24-32 28-29:s1 28-34 29-26:b2\n  35-34:s1 33>32 33>28 34>33:s1 32-38:s1:b2 35-39:s1 37-36:s1 37-40:s2\n  24-25:r\n"), xe = ye.flatMap((e) => e.ports.flatMap((t, n) => e.ports.slice(n + 1).map((r, i) => ({
	id: 0,
	a: t,
	b: r,
	gear: {
		id: e.id,
		from: n,
		to: n + i + 1
	}
})))).map((e, t) => ({
	...e,
	id: be.length + t
})), Se = [
	ue,
	de,
	fe,
	pe,
	me,
	he,
	ge,
	_e,
	ve,
	le({
		id: "temple",
		family: "apeLords",
		rooms: H([
			[75, 125],
			[80, 225],
			[
				295,
				225,
				"c"
			],
			[515, 215],
			[
				775,
				275,
				"c M"
			],
			[
				1065,
				185,
				"m2"
			],
			[100, 400],
			[
				300,
				380,
				"c m2"
			],
			[
				500,
				370,
				"m2"
			],
			[
				800,
				485,
				"c m2"
			],
			[
				1135,
				400,
				"c M"
			],
			[975, 510],
			[1190, 545],
			[
				105,
				535,
				"m2"
			],
			[280, 575],
			[520, 590],
			[
				670,
				585,
				"M"
			],
			[
				850,
				760,
				"M"
			],
			[
				1140,
				765,
				"m2"
			],
			[
				1315,
				740,
				"M"
			],
			[
				80,
				760,
				"M"
			],
			[
				310,
				745,
				"a5"
			],
			[
				520,
				765,
				"m2"
			],
			[
				1015,
				800,
				"s"
			],
			[
				100,
				920,
				"s m2"
			],
			[
				1290,
				910,
				"s"
			],
			[
				830,
				890,
				"a10"
			],
			[1110, 960],
			[
				495,
				975,
				"s"
			],
			[
				690,
				1020,
				"M"
			],
			[
				850,
				1070,
				"c M"
			],
			[
				1300,
				1090,
				"c a20"
			],
			[
				80,
				1120,
				"c a7"
			],
			[
				275,
				1110,
				"i3"
			],
			[475, 1140],
			[
				655,
				1160,
				"c a15"
			],
			[
				1030,
				1160,
				"s"
			],
			[
				1240,
				1240,
				"c m2"
			],
			[
				230,
				1330,
				"a25"
			],
			[
				600,
				1335,
				"M"
			],
			[
				1015,
				1310,
				"a33"
			]
		], 700),
		tunnels: [...be, ...xe],
		gears: ye
	})
], W = Object.fromEntries(Se.map((e) => [e.id, e])), Ce = {
	"base-front": "games.clank.maps.baseFront",
	"base-back": "games.clank.maps.baseBack",
	"sunken-boat": "games.clank.maps.sunkenBoat",
	"sunken-sewer": "games.clank.maps.sunkenSewer",
	"mummy-pyramid": "games.clank.maps.mummyPyramid",
	"mummy-sphinx": "games.clank.maps.mummySphinx",
	"spider-lair": "games.clank.maps.spiderLair",
	"dwarven-mine": "games.clank.maps.dwarvenMine",
	jungle: "games.clank.maps.jungle",
	temple: "games.clank.maps.temple"
};
//#endregion
//#region src/games/clank/movement.ts
function we(e) {
	return W[e.map].rooms[M(e).room];
}
function Te(e, t) {
	if (!t.gear) return t;
	let n = e.gears.find((e) => e.id === t.gear.id), r = ce[n.piece], i = (t.gear.from - n.orientation + r.sides) % r.sides, a = (t.gear.to - n.orientation + r.sides) % r.sides, o = r.routes.find((e) => e.a === i && e.b === a || e.a === a && e.b === i);
	return o ? {
		...t,
		boots: o.boots,
		monsters: o.monsters,
		locked: o.locked
	} : null;
}
function Ee(e, t, n = !0) {
	return W[e.map].tunnels.flatMap((r) => {
		if (r.a !== t && r.b !== t) return [];
		let i = Te(e, r);
		return !i || !n && r.oneWay && r.a !== t || !n && r.gear && W[e.map].gears.find((e) => e.id === r.gear.id).exitOnly?.includes(t) ? [] : [{
			room: r.a === t ? r.b : r.a,
			tunnel: i
		}];
	});
}
function De(e) {
	let t = M(e), n = e.turn;
	if (t.state !== "active" || n.mined || n.stopped && !n.flags.includes("ignoreCave")) return [];
	let r = t.items.some((e) => e.kind === "key"), i = t.items.some((e) => e.kind === "scuba") || n.flags.includes("scuba"), a = n.flags.includes("ignoreIcons");
	return Ee(e, t.room, !1).flatMap(({ room: o, tunnel: s }) => {
		if (o === 0 && !t.artifacts.length || !a && s.locked && !r || s.elevator && !t.gold) return [];
		let c = W[e.map].rooms[t.room].water && W[e.map].rooms[o].water, l = a ? 1 : Math.max(s.boots ?? 1, c && !i ? 2 : 1), u = a || n.flags.includes("ignoreMonsters") ? 0 : s.monsters ?? 0;
		return (s.id in e.webs ? ["sword", "boot"] : ["none"]).flatMap((e) => {
			let r = +(e === "boot"), i = +(e === "sword");
			if (n.boots < l + r) return [];
			let a = [];
			for (let r = 0; r <= Math.min(u, n.swords - i); r++) {
				let n = u - r;
				n >= 10 - t.damage || n > t.supply || a.push({
					type: "move",
					tunnel: s.id,
					to: o,
					swords: r,
					web: e
				});
			}
			return a;
		});
	});
}
function Oe(e, t) {
	let n = M(e), r = Te(e, W[e.map].tunnels[t.tunnel]), i = e.turn.flags.includes("ignoreIcons"), a = n.items.some((e) => e.kind === "scuba") || e.turn.flags.includes("scuba"), o = we(e).water && W[e.map].rooms[t.to].water;
	return {
		boots: (i ? 1 : Math.max(r.boots ?? 1, o && !a ? 2 : 1)) + Number(t.web === "boot"),
		damage: (i || e.turn.flags.includes("ignoreMonsters") ? 0 : r.monsters ?? 0) - t.swords,
		swords: t.swords + Number(t.web === "sword"),
		clank: i ? 0 : r.clank ?? 0,
		curse: i ? 0 : r.curse ?? 0,
		gold: +!!r.elevator
	};
}
//#endregion
//#region src/games/clank/effects.ts
function G(e, t, n, r, i, a = {}) {
	i.length && (e.choice = {
		rid: t,
		source: n,
		kind: r,
		options: i,
		...a
	});
}
var K = (e, t) => ({
	type: "resolve",
	option: e,
	...t === void 0 ? {} : { target: t }
});
function ke(e, t = 1) {
	for (let n = 0; n < t; n++) {
		let t = e.rage === P.length - 1;
		if (e.rage = Math.min(P.length - 1, e.rage + 1), e.map !== "temple" || !t && ![
			3,
			4,
			5,
			6
		].includes(e.rage)) continue;
		let n = e.rotations.shift();
		if (n) {
			for (let t of e.gears) {
				let e = ce[t.piece];
				(n === "all" || n === e.symbol) && (t.orientation = (t.orientation + 1) % e.sides);
			}
			e.log.push({
				event: "rotate",
				token: n
			});
		}
	}
}
function Ae(e) {
	if (e.mummy < 0) return;
	let t = F(e, 4);
	if (t !== e.mummy) {
		e.mummy = t, e.log.push({
			event: "mummy",
			n: t
		});
		for (let n of e.players) n.state === "active" && W[e.map].rooms[n.room].zone === t && re(e, n, 1, !0);
	}
}
function je(e, t = 0, n = "play") {
	for (let t of e.players) t.bag += t.clank, t.clank = 0;
	let r = e.row.filter((e) => e && j[e.kind].danger).length;
	e.attack = {
		remaining: P[e.rage] + r + t,
		after: n
	}, e.phase = "dragon", e.lastDraw = [], e.log.push({
		event: "dragon",
		n: e.attack.remaining
	});
}
function Me(e, t, n) {
	let r = e.row[n], i = j[r.kind];
	if (e.row[n] = null, i.type === "monster" || i.type === "device") {
		e.dungeonDiscard.push(r);
		let n = i.conditional && Re(e, t, i.conditional.when) ? i.conditional.effects : [];
		R(e, t.rid, r.kind, [...i.play, ...n], !0);
	} else t.discard.push(r), R(e, t.rid, r.kind, i.acquire, !0);
	e.log.push({
		event: i.type === "monster" ? "defeat" : "acquire",
		rid: t.rid,
		card: r.kind
	});
}
function Ne(e, t, n) {
	let r = Math.min(n, e.reserve.tome);
	for (let n = 0; n < r; n++) t.discard.push(L(e, "tome"));
	e.reserve.tome -= r;
}
function Pe(e, t, n = !1) {
	return [...t.played, ...t.discard].filter((t) => !e.turn.trashed.includes(t.uid) && (!n || t.kind === "burgle"));
}
function Fe(e, t, n) {
	e.turn.secretFound = !0, e.log.push({
		event: "secret",
		rid: t.rid,
		token: n
	}), [
		"heal1",
		"heal2",
		"boots",
		"swords",
		"heroism"
	].includes(n) ? t.potions.push(n) : n === "gold2" || n === "gold5" ? V(e, t, n === "gold2" ? 2 : 5) : n === "skill2" || n === "skill5" ? e.turn.skill += n === "skill2" ? 2 : 5 : n === "draw3" ? z(e, t, 3) : n === "chalice" || n === "mummyChalice" ? t.chalices++ : n === "mummyGold" ? V(e, t, 5) : n === "spring" ? t.spring++ : n === "egg" ? (t.eggs++, ke(e)) : n === "scarab" && t.scarabs++, (n === "mummyGold" || n === "mummyChalice" || n === "scarab") && Ae(e);
}
function Ie(e, t, n) {
	let r = W[e.map].rooms[n], i = e.rooms[n];
	r.webbed && r.gold && V(e, t, r.gold), r.webbed && r.heal && B(t, r.heal), i.secrets.length ? Fe(e, t, i.secrets.shift()) : i.idols.length && t.idols.push(i.idols.shift());
}
function Le(e, t, n) {
	t.room = n;
	let r = W[e.map].rooms[n];
	if (r.water ? e.turn.featureUsed = !0 : e.turn.needsAir = !1, r.cave && (e.turn.stopped = !0), e.log.push({
		event: "move",
		rid: t.rid,
		room: n
	}), n === 0) return;
	let i = e.rooms[n];
	if (!r.webbed && r.gold && V(e, t, r.gold), !r.webbed && r.heal && B(t, r.heal), (!r.webbed || !r.gold && !r.heal) && !i.secrets.length && !i.idols.length) return;
	let a = [];
	(!r.webbed || e.turn.swords > 0) && a.push({
		action: K("take"),
		effects: []
	}), a.push({
		action: K("skip"),
		effects: []
	}), G(e, t.rid, "room", "entry", a, { subject: n });
}
function Re(e, t, n) {
	let r = [...t.played, ...t.discard];
	switch (n) {
		case "companion": return t.played.filter((e) => j[e.kind].type === "companion").length >= 2;
		case "artifact": return t.artifacts.length > 0;
		case "crown": return t.items.some((e) => e.kind === "crown");
		case "idol": return t.idols.length > 0;
		case "tome": return r.some((e) => e.kind === "tome");
		case "gem": return r.some((e) => j[e.kind].type === "gem");
		case "twoGems": return r.filter((e) => j[e.kind].type === "gem").length >= 2;
		case "noise": return t.clank > 0;
		case "secret": return e.turn.secretFound;
		case "feature": return e.turn.featureUsed;
	}
}
function ze(e) {
	let t = M(e);
	if (t.state !== "knocked") for (let n of t.played) {
		let r = j[n.kind];
		r.conditional && !e.turn.triggered.includes(n.uid) && Re(e, t, r.conditional.when) && (e.turn.triggered.push(n.uid), R(e, t.rid, n.kind, r.conditional.effects));
		let i = String(n.uid), a = e.turn.grants[i] ?? 0;
		n.kind === "swagger" && (e.turn.skill += e.turn.noiseMade - a, e.turn.grants[i] = e.turn.noiseMade), (n.kind === "search" || n.kind === "expedition-leader") && (t.gold += e.turn.goldEvents - a, e.turn.grants[i] = e.turn.goldEvents);
	}
}
function Be(e) {
	let t = e.queue.shift();
	if (!t) return;
	let { rid: n, source: r, effect: i } = t, a = N(e, n);
	if (a.state !== "knocked") switch (i.op) {
		case "gain": {
			let t = i.others ? e.players.filter((e) => (i.all || e.rid !== n) && e.state === "active") : [a];
			for (let n of t) i.resource === "clank" ? ne(e, n, i.n) : i.resource === "curse" ? re(e, n, i.n) : i.resource === "gold" ? V(e, n, i.n) : i.resource === "heal" ? B(n, i.n) : e.turn[i.resource] += i.n;
			break;
		}
		case "draw":
			z(e, a, i.n);
			break;
		case "flag":
			e.turn.flags.includes(i.flag) || e.turn.flags.push(i.flag);
			break;
		case "black": {
			let t = Math.min(i.n, e.blackRemoved);
			e.blackRemoved -= t, e.blackBag += t;
			break;
		}
		case "roll":
			Ae(e);
			break;
		case "attack":
			je(e);
			break;
		case "tome":
			(!i.pay || a.gold >= i.pay) && (i.pay && (a.gold -= i.pay), Ne(e, a, i.n));
			break;
		case "discard":
			a.hand.length && G(e, n, r, "discard", a.hand.map((e) => ({
				action: K("discard", e.uid),
				effects: []
			})), {
				remaining: Math.min(i.n, a.hand.length),
				then: a.hand.length >= i.n ? i.then : []
			});
			break;
		case "trash":
			G(e, n, r, "trash", Pe(e, a, i.burgle).map((e) => ({
				action: K("trash", e.uid),
				effects: []
			})));
			break;
		case "choose":
			G(e, n, r, "choose", i.options.filter((t) => !t.effects.some((t) => t.op === "tome" && t.pay && a.gold < t.pay || t.op === "teleport" && t.water && !W[e.map].rooms[a.room].water)).map((e) => ({
				action: K(e.id),
				effects: e.effects
			})), {
				remaining: i.times ?? 1,
				distinct: i.distinct,
				used: []
			});
			break;
		case "teleport":
			(!i.water || W[e.map].rooms[a.room].water) && G(e, n, r, "teleport", [...new Set(Ee(e, a.room).map((e) => e.room))].filter((e) => e !== 0 || a.artifacts.length).map((e) => ({
				action: K("teleport", e),
				effects: []
			})));
			break;
		case "adjacent": {
			let t = [...new Set(Ee(e, a.room).map((e) => e.room))].filter((t) => e.rooms[t].secrets.length || i.idol && e.rooms[t].idols.length).map((e) => ({
				action: K("adjacent", e),
				effects: []
			}));
			i.optional && t.push({
				action: K("skip"),
				effects: []
			}), G(e, n, r, "adjacent", t, { subject: i.noise ?? 0 });
			break;
		}
		case "acquire":
			G(e, n, r, "acquire", e.row.flatMap((t, n) => {
				if (!t) return [];
				let r = j[t.kind];
				return r.type === "monster" || i.companion && r.type !== "companion" || i.max !== void 0 && r.cost > i.max || r.deep && !W[e.map].rooms[a.room].deep ? [] : [{
					action: K("acquire", n),
					effects: []
				}];
			}));
			break;
		case "replace":
			G(e, n, r, "replace", e.row.flatMap((e, t) => e ? [{
				action: K("replace", t),
				effects: []
			}] : []));
			break;
		case "recall":
			a.discard.length ? G(e, n, r, "recall", a.discard.map((e) => ({
				action: K("recall", e.uid),
				effects: []
			}))) : z(e, a, 2);
			break;
		case "peek":
			!a.deck.length && a.discard.length && (z(e, a, 1), a.deck.unshift(a.hand.pop())), e.peek = a.deck[0] ?? null, e.peek && G(e, n, r, "peek", [{
				action: K("top"),
				effects: []
			}, {
				action: K("bottom"),
				effects: []
			}]);
			break;
		case "organ":
			G(e, n, r, "organ", [-1, 1].map((e) => ({
				action: K("organ", e),
				effects: []
			})));
			break;
		case "boomerang": {
			let e = a.discard.length - 1;
			for (; e >= 0 && a.discard[e].kind !== "boomerang";) e--;
			e >= 0 && a.hand.push(a.discard.splice(e, 1)[0]);
			break;
		}
		case "scorpion":
			V(e, a, Math.max(0, 7 - a.curses));
			break;
		case "direWolf": {
			let t = e.row.filter((e) => e && j[e.kind].type === "monster").length + 1 + Number(W[e.map].family === "sunken") + Number(e.mummy >= 0) + Number(e.guardian.length > 0);
			ne(e, a, t), e.turn.swords += t;
			break;
		}
		case "dice": {
			let t = ["black", ...e.players.map((e) => e.rid)], n = [e.blackBag, ...e.players.map((e) => e.bag)], r = [];
			for (let i = 0; i < 2; i++) {
				let i = n.reduce((e, t) => e + t, 0);
				if (!i) break;
				let a = F(e, i), o = 0;
				for (; a >= n[o];) a -= n[o++];
				n[o]--, r.push(t[o]);
			}
			e.lastDraw = r, V(e, a, r.filter((e) => e === "black").length);
			break;
		}
		case "snack":
			R(e, n, r, e.players.filter((e) => e.rid !== n && e.state === "active" && e.gold > 0 && e.damage > 0).map((e) => ({
				op: "snackOffer",
				rid: e.rid,
				recipient: n
			})), !0);
			break;
		case "snackOffer": {
			let t = N(e, i.rid);
			t.state === "active" && t.gold > 0 && t.damage > 0 && G(e, t.rid, i.recipient, "snack", [{
				action: K("pay"),
				effects: []
			}, {
				action: K("skip"),
				effects: []
			}]);
			break;
		}
	}
}
//#endregion
//#region src/games/clank/legal.ts
function Ve(e, t) {
	let n = j[t];
	return Math.max(0, n.cost - (n.type === "gem" ? 2 * M(e).played.filter((e) => e.kind === "gem-collector").length : 0));
}
function He(e, t) {
	if (e.choice) return e.choice.rid === t ? e.choice.options.map((e) => e.action) : [];
	if (e.queue.length || e.attack) return [];
	let n = M(e);
	if (t !== n.rid) return [];
	if (e.phase === "intermission") return [{ type: "continue" }];
	if (e.phase !== "play" || n.state === "knocked") return [];
	let r = n.hand.map((e) => ({
		type: "play",
		card: e.uid
	})), i = we(e);
	for (let [t, n] of e.row.entries()) {
		if (!n) continue;
		let a = j[n.kind];
		a.deep && !i.deep || a.cave && !(i.cave || a.water && i.water) || (a.type === "monster" ? e.turn.swords >= a.cost : e.turn.skill >= Ve(e, n.kind)) && r.push({
			type: "row",
			slot: t
		});
	}
	for (let t of [
		"explore",
		"mercenary",
		"tome"
	]) e.reserve[t] > 0 && e.turn.skill >= j[t].cost && r.push({
		type: "reserve",
		card: t
	});
	if (n.state === "active" && r.push(...De(e)), e.rooms[n.room].artifacts.length && n.artifacts.length < 1 + n.items.filter((e) => e.kind === "backpack").length && r.push({ type: "artifact" }), i.market && n.gold >= 7) for (let t of [
		"key",
		"backpack",
		"crown",
		"scuba",
		"ankh",
		"timeWinder"
	]) e.market[t].length && r.push({
		type: "market",
		item: t
	});
	if (e.turn.swords >= 2 && r.push({
		type: "fight",
		monster: "goblin"
	}), i.water && W[e.map].family === "sunken" && e.turn.swords >= 3 && r.push({
		type: "fight",
		monster: "goldfish"
	}), e.mummy >= 0 && i.zone === e.mummy && (e.turn.swords >= 2 && r.push({
		type: "fight",
		monster: "mummyGold"
	}), e.turn.swords >= 3 && r.push({
		type: "fight",
		monster: "mummyCleanse"
	})), e.turn.swords >= 3) for (let t of e.guardian) r.push({
		type: "fight",
		monster: "guardian",
		apparatus: t
	});
	if (n.supply > 0 && e.turn.skill >= 2) for (let t of W[e.map].mines ?? []) !(t.id in e.mines) && t.rooms.includes(n.room) && r.push({
		type: "mine",
		mine: t.id
	});
	e.map === "spider-lair" && n.supply > 0 && e.turn.skill >= 8 && e.cache.forEach((e, t) => {
		e || r.push({
			type: "cache",
			cache: t
		});
	});
	for (let t of e.gears) {
		let i = ce[t.piece];
		if (W[e.map].gears.find((e) => e.id === t.id).ports.includes(n.room) && n.apparatus.includes(i.symbol)) for (let e = 0; e < i.sides; e++) e !== t.orientation && r.push({
			type: "rotate",
			gear: t.id,
			orientation: e,
			apparatus: i.symbol
		});
	}
	for (let e of new Set(n.potions)) r.push({
		type: "potion",
		potion: e
	});
	if (n.spring) for (let t of Pe(e, n)) r.push({
		type: "spring",
		card: t.uid
	});
	return !n.hand.length && (!n.spring || !Pe(e, n).length) && r.push({ type: "end" }), r;
}
//#endregion
//#region src/games/clank/scoring.ts
function Ue(e, t) {
	return t.artifacts.length > 0 && (t.state === "escaped" || !W[e.map].rooms[t.room].deep);
}
function We(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t), a = e.players.find((e) => e.rid === n);
	return Number(r[n].eligible) - Number(r[t].eligible) || r[n].total - r[t].total || Math.max(0, ...a.artifacts) - Math.max(0, ...i.artifacts);
}
function Ge(e) {
	let t = W[e.map].mines ?? [], n = e.players.filter((n) => Ue(e, n) && t.some((t) => e.mines[t.id] === n.rid)).sort((n, r) => {
		let i = t.filter((t) => e.mines[t.id] === n.rid), a = t.filter((t) => e.mines[t.id] === r.rid);
		return a.length - i.length || Math.max(...a.map((e) => e.depth)) - Math.max(...i.map((e) => e.depth));
	});
	return Object.fromEntries(e.players.map((t) => {
		let r = [
			...t.hand,
			...t.deck,
			...t.discard,
			...t.played
		].filter((t) => !e.turn.trashed.includes(t.uid)), i = r.filter((e) => e.kind === "tome").length, a = 0;
		for (let n of r) n.kind === "dragons-eye" ? a += t.state === "escaped" ? 10 : 0 : n.kind === "dwarven-peddler" ? a += [
			t.chalices > 0,
			t.eggs > 0,
			t.idols.length > 0
		].filter(Boolean).length >= 2 ? 4 : 0 : n.kind === "the-duke" ? a += Math.floor(t.gold / 5) : n.kind === "wizard" ? a += 2 * i : n.kind === "grand-plan" ? a += t.items.length >= 3 ? 7 : 0 : n.kind === "book-of-the-dead" ? a += t.curses : n.kind === "purify" ? a += e.players.every((e) => e.rid === t.rid || t.curses < e.curses) ? 5 : 0 : a += j[n.kind].points;
		let o = {
			eligible: Ue(e, t),
			artifacts: t.artifacts.reduce((e, t) => e + t, 0),
			gold: t.gold,
			cards: a,
			tokens: t.idols.reduce((e, t) => e + t, 0) + 7 * t.chalices + 3 * (t.eggs + t.scarabs) + t.webs.reduce((e, t) => e + t, 0),
			market: t.items.reduce((e, t) => e + t.points, 0),
			mastery: t.state === "escaped" ? 20 : 0,
			curses: -2 * t.curses,
			mining: [
				20,
				10,
				5
			][n.findIndex((e) => e.rid === t.rid)] ?? 0,
			apparatus: e.map === "jungle" ? [
				"cog",
				"wrench",
				"banana"
			].reduce((e, n) => e + t.apparatus.filter((e) => e === n).length ** 2, 0) : 0,
			campaign: t.campaign,
			total: 0
		};
		return o.total = o.eligible ? o.artifacts + o.gold + o.cards + o.tokens + o.market + o.mastery + o.curses + o.mining + o.apparatus + o.campaign : 0, [t.rid, o];
	}));
}
function Ke(e) {
	if (e.queue = [], e.choice = null, e.attack = null, e.ending = !1, e.scores = Ge(e), e.config.campaign && e.gameNumber === 1) {
		e.firstGameScores = structuredClone(e.scores);
		let t = e.players.map((e) => e.rid).filter((t) => e.scores[t].eligible).sort((t, n) => We(e, t, n, e.scores));
		for (let n of e.players) n.campaign = [
			20,
			10,
			5
		][t.indexOf(n.rid)] ?? 0;
		e.phase = "intermission";
	} else e.phase = "done";
}
//#endregion
//#region src/games/clank/resolve.ts
function qe(e, t, n) {
	let r = N(e, t), i = r.discard.findIndex((e) => e.uid === n);
	i >= 0 ? r.discard.splice(i, 1) : e.turn.trashed.push(n);
}
function Je(e, t) {
	let n = e.choice, r = N(e, n.rid), i = n.options.find((e) => e.action.type === "resolve" && e.action.option === t.option && e.action.target === t.target);
	switch (e.choice = null, n.kind) {
		case "choose": {
			let a = (n.remaining ?? 1) - 1;
			if (a > 0) {
				let i = n.distinct ? n.options.filter((e) => e.action.type !== "resolve" || e.action.option !== t.option) : n.options;
				R(e, r.rid, n.source, [{
					op: "choose",
					times: a,
					distinct: n.distinct,
					options: i.map((e) => ({
						id: e.action.type === "resolve" ? e.action.option : "",
						effects: e.effects
					}))
				}], !0);
			}
			R(e, r.rid, n.source, i.effects, !0);
			break;
		}
		case "discard": {
			let i = oe(r.hand, r.hand.findIndex((e) => e.uid === t.target));
			r.discard.push(i);
			let a = (n.remaining ?? 1) - 1, o = a ? [{
				op: "discard",
				n: a,
				then: n.then ?? []
			}] : n.then ?? [];
			R(e, r.rid, n.source, [...j[i.kind].discard, ...o], !0);
			break;
		}
		case "trash":
			qe(e, r.rid, t.target);
			break;
		case "teleport":
			Le(e, r, t.target), t.target === 0 && ie(e, r, !0);
			break;
		case "adjacent":
			if (t.option !== "skip") {
				ne(e, r, n.subject ?? 0);
				let i = e.rooms[t.target];
				i.secrets.length ? Fe(e, r, i.secrets.shift()) : i.idols.length && r.idols.push(i.idols.shift());
			}
			break;
		case "acquire":
			Me(e, r, t.target);
			break;
		case "recall":
			r.hand.push(oe(r.discard, r.discard.findIndex((e) => e.uid === t.target)));
			break;
		case "replace": {
			let n = t.target, i = e.row[n];
			if (e.dungeonDiscard.push(i), e.row[n] = e.dungeon.shift() ?? null, e.row[n] && R(e, r.rid, e.row[n].kind, j[e.row[n].kind].arrive, !0), !e.dungeon.length) {
				for (let t of e.players) t.state === "active" && ie(e, t);
				Ke(e);
			}
			break;
		}
		case "peek":
			t.option === "bottom" && r.deck.push(r.deck.shift()), z(e, r, 1), e.peek = null;
			break;
		case "organ":
			t.target > 0 ? ke(e) : e.rage = Math.max(0, e.rage - 1);
			break;
		case "entry":
			t.option === "take" && (W[e.map].rooms[n.subject].webbed && e.turn.swords--, Ie(e, r, n.subject));
			break;
		case "snack": t.option === "pay" && (r.gold--, V(e, N(e, n.source), 1), B(r, 1));
	}
	M(e).state === "knocked" && (e.choice = null);
}
//#endregion
//#region src/games/clank/schema.ts
var Ye = t.enum([
	"base-front",
	"base-back",
	"sunken-boat",
	"sunken-sewer",
	"mummy-pyramid",
	"mummy-sphinx",
	"spider-lair",
	"dwarven-mine",
	"jungle",
	"temple"
]), Xe = t.object({
	sunken: t.boolean().default(!1),
	mummy: t.boolean().default(!1),
	goldSilk: t.boolean().default(!1),
	apeLords: t.boolean().default(!1),
	promo: t.boolean().default(!1),
	campaign: t.boolean().default(!1),
	map: Ye.default("base-front")
}).superRefine((e, t) => {
	let n = e.map.startsWith("sunken-") ? "sunken" : e.map.startsWith("mummy-") ? "mummy" : ["spider-lair", "dwarven-mine"].includes(e.map) ? "goldSilk" : ["jungle", "temple"].includes(e.map) ? "apeLords" : null;
	n && !e[n] && t.addIssue({
		code: "custom",
		message: "Enable the expansion for this map",
		path: ["map"]
	}), e.campaign && (!e.apeLords || e.map !== "jungle") && t.addIssue({
		code: "custom",
		message: "The campaign begins in the Jungle",
		path: ["campaign"]
	});
}).default({
	sunken: !1,
	mummy: !1,
	goldSilk: !1,
	apeLords: !1,
	promo: !1,
	campaign: !1,
	map: "base-front"
}), q = t.int().nonnegative(), Ze = t.object({
	uid: q,
	kind: t.string()
}), Qe = t.enum([
	"key",
	"backpack",
	"crown",
	"scuba",
	"ankh",
	"timeWinder"
]), $e = t.enum([
	"heal1",
	"heal2",
	"boots",
	"swords",
	"heroism"
]), et = t.enum([
	"cog",
	"wrench",
	"banana"
]), tt = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: q
	}),
	t.object({
		type: t.literal("row"),
		slot: q.max(5)
	}),
	t.object({
		type: t.literal("reserve"),
		card: t.enum([
			"explore",
			"mercenary",
			"tome"
		])
	}),
	t.object({
		type: t.literal("move"),
		tunnel: q,
		to: q,
		swords: q,
		web: t.enum([
			"none",
			"sword",
			"boot"
		])
	}),
	t.object({ type: t.literal("artifact") }),
	t.object({
		type: t.literal("market"),
		item: Qe
	}),
	t.object({
		type: t.literal("fight"),
		monster: t.enum([
			"goblin",
			"goldfish",
			"mummyGold",
			"mummyCleanse",
			"guardian"
		]),
		apparatus: et.optional()
	}),
	t.object({
		type: t.literal("mine"),
		mine: q
	}),
	t.object({
		type: t.literal("cache"),
		cache: q.max(7)
	}),
	t.object({
		type: t.literal("rotate"),
		gear: q.max(8),
		orientation: q.max(4),
		apparatus: et
	}),
	t.object({
		type: t.literal("potion"),
		potion: $e
	}),
	t.object({
		type: t.literal("spring"),
		card: q
	}),
	t.object({
		type: t.literal("resolve"),
		option: t.string(),
		target: t.int().optional()
	}),
	t.object({ type: t.literal("end") }),
	t.object({ type: t.literal("continue") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), nt = t.object({
	eligible: t.boolean(),
	artifacts: t.number(),
	gold: t.number(),
	cards: t.number(),
	tokens: t.number(),
	market: t.number(),
	mastery: t.number(),
	curses: t.number(),
	mining: t.number(),
	apparatus: t.number(),
	campaign: t.number(),
	total: t.number()
}), rt = t.object({
	skill: q,
	swords: q,
	boots: q,
	stopped: t.boolean(),
	mined: t.boolean(),
	negativeClank: q,
	noiseMade: q,
	goldEvents: q,
	secretFound: t.boolean(),
	featureUsed: t.boolean(),
	needsAir: t.boolean(),
	flags: t.array(t.enum([
		"ignoreCave",
		"ignoreMonsters",
		"ignoreIcons",
		"scuba",
		"immuneMummy"
	]))
}), it = t.object({
	event: t.enum([
		"play",
		"move",
		"acquire",
		"defeat",
		"artifact",
		"secret",
		"market",
		"mine",
		"web",
		"rotate",
		"dragon",
		"damage",
		"escape",
		"knockout",
		"mummy",
		"round",
		"campaign"
	]),
	rid: t.string().optional(),
	card: t.string().optional(),
	n: t.number().optional(),
	room: t.number().optional(),
	token: t.string().optional()
}), at = t.object({
	config: Xe,
	map: Ye,
	phase: t.enum([
		"play",
		"refill",
		"dragon",
		"advance",
		"intermission",
		"done"
	]),
	active: t.string(),
	turnNumber: q,
	gameNumber: q,
	players: t.array(t.object({
		rid: t.string(),
		room: q,
		damage: q,
		supply: q,
		clank: q,
		bag: q,
		gold: q,
		curses: q,
		artifacts: t.array(q),
		idols: t.array(q),
		chalices: q,
		eggs: q,
		scarabs: q,
		items: t.array(t.object({
			kind: Qe,
			points: q
		})),
		potions: t.array($e),
		handCount: q,
		deckCount: q,
		discard: t.array(Ze),
		played: t.array(Ze),
		webCount: q,
		apparatusCount: q,
		apparatus: t.array(et).nullable(),
		state: t.enum([
			"active",
			"escaped",
			"knocked"
		]),
		campaign: q
	})),
	row: t.array(Ze.nullable()).length(6),
	dungeonCount: q,
	reserve: t.record(t.string(), q),
	market: t.record(t.string(), t.array(q)),
	rooms: t.array(t.object({
		id: q,
		secrets: q,
		artifacts: t.array(q),
		idols: t.array(q)
	})),
	webs: t.array(q),
	apparatus: t.array(t.object({
		tunnel: q,
		kind: et
	})),
	mines: t.array(t.object({
		mine: q,
		owner: t.string()
	})),
	cache: t.array(t.string().nullable()),
	gears: t.array(t.object({
		id: q,
		piece: t.string(),
		orientation: q
	})),
	rage: q,
	blackBag: q,
	blackRemoved: q,
	mummy: t.int().min(-1).max(3),
	countdown: t.object({
		rid: t.string(),
		step: q
	}).nullable(),
	turn: rt,
	choice: t.object({
		rid: t.string(),
		source: t.string(),
		kind: t.string()
	}).nullable(),
	scores: t.record(t.string(), nt).nullable(),
	firstGameScores: t.record(t.string(), nt).nullable(),
	log: t.array(it),
	lastDraw: t.array(t.string())
}), ot = t.object({
	hand: t.array(Ze),
	apparatus: t.array(et),
	webs: t.array(q),
	peek: Ze.nullable(),
	actions: t.array(tt),
	spring: q
});
//#endregion
//#region src/games/clank/setup.ts
function st(e) {
	let t = Xe.parse(e);
	t.campaign && t.apeLords ? t.map = "jungle" : t.campaign = !1;
	let n = W[t.map].family;
	return n !== "base" && !t[n === "sunken" ? "sunken" : n === "mummy" ? "mummy" : n] && (t.map = "base-front"), t;
}
function ct(e, t, n) {
	let r = st(e), i = {
		config: r,
		map: r.map,
		seed: n,
		cursor: 0,
		uid: 1,
		phase: "play",
		players: [],
		active: 0,
		turnNumber: 1,
		gameNumber: 1,
		turn: ee(),
		dungeon: [],
		row: [],
		dungeonDiscard: [],
		reserve: {
			explore: 15,
			mercenary: 15,
			tome: 12
		},
		market: {
			key: [5, 5],
			backpack: [5, 5],
			crown: [
				10,
				9,
				8
			],
			scuba: [],
			ankh: [],
			timeWinder: []
		},
		rooms: {},
		webs: {},
		apparatus: {},
		guardian: [],
		mines: {},
		cache: Array(8).fill(null),
		gears: [],
		rotations: [],
		rage: 4 - t.length,
		blackBag: 24,
		blackRemoved: 0,
		mummy: -1,
		countdown: null,
		queue: [],
		choice: null,
		peek: null,
		dragonPending: !1,
		attack: null,
		refillSlot: 0,
		ending: !1,
		scores: null,
		firstGameScores: null,
		log: [],
		lastDraw: []
	}, a = W[i.map];
	a.family === "sunken" && (i.market.scuba = [5, 5]), r.mummy && (i.market.ankh = [7, 7]), a.family === "apeLords" && (i.market.timeWinder = [5, 5]), a.family === "mummy" && (i.mummy = 3);
	let o = [
		"heal1",
		"heal1",
		"heal1",
		"boots",
		"boots",
		"swords",
		"swords",
		"skill2",
		"skill2",
		"skill2",
		"gold2",
		"gold2",
		"gold2",
		"spring",
		"spring",
		"egg",
		"egg",
		"egg"
	], s = [
		"heal2",
		"heal2",
		"skill5",
		"skill5",
		"gold5",
		"gold5",
		"draw3",
		"draw3",
		"chalice",
		"chalice",
		"chalice"
	];
	r.sunken && (o.push("swords", "gold2"), s.push("heroism")), a.family === "mummy" && (o.push("scarab", "scarab"), s.push("mummyGold", "mummyChalice")), o = I(i, o), s = I(i, s);
	let c = new Set(I(i, a.rooms.filter((e) => e.artifact).map((e) => e.artifact)).slice(0, 4 - t.length));
	for (let e of a.rooms) i.rooms[e.id] = {
		secrets: e.minor ? o.splice(0, e.minor) : e.major ? s.splice(0, e.major) : [],
		artifacts: e.artifact && !c.has(e.artifact) ? [e.artifact] : [],
		idols: e.idols === 10 ? [10] : Array(e.idols ?? 0).fill(5)
	};
	let l = I(i, [
		1,
		1,
		1,
		1,
		1,
		1,
		2,
		2,
		2,
		2,
		3,
		3
	]), u = I(i, Array.from({ length: 5 }, () => [
		"cog",
		"wrench",
		"banana"
	]).flat());
	for (let e of a.tunnels) e.web && (i.webs[e.id] = l.shift()), e.apparatus && (i.apparatus[e.id] = u.shift());
	if (i.map === "jungle" && (i.guardian = [
		"cog",
		"wrench",
		"banana"
	]), i.map === "temple") {
		let e = I(i, se.filter((e) => e.sides === 3)), t = I(i, se.filter((e) => e.sides === 4));
		i.gears = a.gears.map((n) => {
			let r = n.ports.length === 3 ? e.shift() : n.ports.length === 4 ? t.shift() : se[8];
			return {
				id: n.id,
				piece: r.id,
				orientation: F(i, r.sides)
			};
		}), i.rotations = I(i, [
			"cog",
			"cog",
			"wrench",
			"wrench",
			"banana",
			"banana",
			"all",
			"none"
		]);
	}
	let d = I(i, Array.from({ length: 6 }, () => [
		"cog",
		"wrench",
		"banana"
	]).flat());
	for (let [e, n] of t.entries()) {
		let t = {
			rid: n,
			room: 0,
			damage: 0,
			supply: 30 - Math.max(0, 3 - e),
			clank: Math.max(0, 3 - e),
			bag: 0,
			removed: 0,
			gold: 0,
			curses: 0,
			artifacts: [],
			idols: [],
			chalices: 0,
			eggs: 0,
			scarabs: 0,
			potions: [],
			items: [],
			deck: [],
			hand: [],
			discard: [],
			played: [],
			webs: [],
			apparatus: i.map === "temple" ? d.splice(0, 3) : [],
			state: "active",
			campaign: 0,
			spring: 0
		};
		t.deck = I(i, [
			"burgle",
			"burgle",
			"burgle",
			"burgle",
			"burgle",
			"burgle",
			"stumble",
			"stumble",
			"scramble",
			"sidestep"
		].map((e) => L(i, e))), z(i, t, 5), i.players.push(t);
	}
	let f = A.filter((e) => e.pack === "base" || e.pack === "sunken" && r.sunken || e.pack === "mummy" && r.mummy || e.pack === "promo" && r.promo);
	i.dungeon = I(i, f.flatMap((e) => Array.from({ length: e.copies }, () => L(i, e.id))));
	let p = [];
	for (; i.row.length < 6;) {
		let e = i.dungeon.shift(), n = f.find((t) => t.id === e.kind);
		n.dragon ? p.push(e) : (i.row.push(e), R(i, t[0], e.kind, n.arrive));
	}
	return i.dungeon = I(i, [...i.dungeon, ...p]), i;
}
//#endregion
//#region src/games/clank/meta.ts
var lt = {
	id: "clank",
	tier: "alpha",
	nameKey: "games.clank.name",
	descKey: "games.clank.desc",
	rulesKey: "games.clank.rules",
	icon: "🐉",
	iconImg: "games/clank.webp",
	minPlayers: 2,
	maxPlayers: 4,
	mechanics: [
		"deck-bag-building",
		"push-your-luck",
		"race",
		"set-collection"
	],
	interactionTags: [],
	accent: "#795331",
	releasedAt: "2026-10-26T23:23:13+08:00",
	search: {
		py: "jin sheng xun bao ji clank",
		init: "jsxbj"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://d19y2ttatozxjp.cloudfront.net/pdfs/EN_Clank_Rulebook.pdf" }
};
//#endregion
//#region src/games/clank/rules.ts
function ut(e) {
	let t = M(e);
	t.discard.push(...t.played.filter((t) => !e.turn.trashed.includes(t.uid))), t.played = [], t.spring = 0, e.turn.trashed = [], t.state === "active" && z(e, t, 5), e.phase = "refill", e.dragonPending = !1;
}
function dt(e) {
	if (e.choice || e.phase === "done" || e.phase === "intermission") return;
	if (e.queue.length && e.phase !== "dragon") {
		Be(e), ze(e);
		return;
	}
	let t = M(e);
	if (e.phase === "dragon") {
		let t = e.attack, n = e.blackBag + e.players.reduce((e, t) => e + t.bag, 0);
		if (t.remaining > 0 && n > 0) {
			let r = F(e, n);
			if (r < e.blackBag) e.blackBag--, e.blackRemoved++, e.lastDraw.push("black");
			else {
				r -= e.blackBag;
				for (let t of e.players) {
					if (r >= t.bag) {
						r -= t.bag;
						continue;
					}
					t.bag--, e.lastDraw.push(t.rid), ae(e, t, 1, !0);
					break;
				}
			}
			t.remaining--;
			return;
		}
		e.phase = t.after, e.attack = null, t.after === "advance" && e.players.every((e) => e.state !== "active") && Ke(e);
		return;
	}
	if (e.phase === "play" && t.state === "knocked") {
		e.queue = [], ut(e);
		return;
	}
	if (e.phase === "refill") {
		let n = e.row.findIndex((e) => e === null);
		if (n >= 0) {
			let r = e.dungeon.shift();
			if (r) {
				e.row[n] = r;
				let i = j[r.kind];
				e.queue.push(...i.arrive.map((e) => ({
					rid: t.rid,
					source: r.kind,
					effect: e
				}))), e.dragonPending ||= i.dragon;
			}
			if (!e.dungeon.length) {
				for (let t of e.players) ie(e, t);
				Ke(e);
			}
			return;
		}
		e.dragonPending ? je(e, 0, "advance") : e.phase = "advance";
		return;
	}
	if (e.phase === "advance") {
		if (e.players.every((e) => e.state !== "active")) {
			Ke(e);
			return;
		}
		e.active = (e.active + 1) % e.players.length;
		let t = M(e);
		if (e.countdown?.rid === t.rid) {
			if (e.countdown.step++, e.countdown.step >= 4) {
				for (let t of e.players) ie(e, t);
				Ke(e);
			} else je(e, e.countdown.step, "advance");
			return;
		}
		if (t.state !== "active") return;
		e.turn = ee(), e.turnNumber++, e.turn.needsAir = !!W[e.map].rooms[t.room].water, e.phase = "play", e.lastDraw = [];
	}
}
function ft(e, t) {
	let n = Object.entries(e);
	return n.length === Object.keys(t).length && n.every(([e, n]) => t[e] === n);
}
function pt(e, t, n) {
	if (t.type === "tick" && n !== "$engine" || t.type !== "tick" && !He(e, n).some((e) => ft(e, t))) return { code: "games.clank.errorAction" };
	let r = structuredClone(e);
	if (t.type === "tick") return dt(r), { state: r };
	let i = M(r);
	switch (t.type) {
		case "play": {
			let e = i.hand.splice(i.hand.findIndex((e) => e.uid === t.card), 1)[0], n = j[e.kind];
			i.played.push(e), r.turn.skill += n.skill, r.turn.swords += n.swords, r.turn.boots += n.boots, r.queue.push(...n.play.map((t) => ({
				rid: i.rid,
				source: e.kind,
				effect: t
			}))), r.log.push({
				event: "play",
				rid: i.rid,
				card: e.kind
			});
			break;
		}
		case "row": {
			let e = j[r.row[t.slot].kind];
			e.type === "monster" ? r.turn.swords -= e.cost : r.turn.skill -= Ve(r, e.id), Me(r, i, t.slot);
			break;
		}
		case "reserve":
			r.turn.skill -= j[t.card].cost, r.reserve[t.card]--, i.discard.push(L(r, t.card)), r.log.push({
				event: "acquire",
				rid: i.rid,
				card: t.card
			});
			break;
		case "move": {
			let e = Oe(r, t);
			r.turn.boots -= e.boots, r.turn.swords -= e.swords, i.gold -= e.gold, ae(r, i, e.damage), ne(r, i, e.clank), re(r, i, e.curse), t.tunnel in r.webs && (i.webs.push(r.webs[t.tunnel]), delete r.webs[t.tunnel], r.turn.featureUsed = !0, r.log.push({
				event: "web",
				rid: i.rid
			})), t.tunnel in r.apparatus && (i.apparatus.push(r.apparatus[t.tunnel]), delete r.apparatus[t.tunnel]), Le(r, i, t.to), t.to === 0 && ie(r, i, !0);
			break;
		}
		case "artifact":
			i.artifacts.push(r.rooms[i.room].artifacts.shift()), ke(r), r.log.push({
				event: "artifact",
				rid: i.rid,
				n: i.artifacts.at(-1)
			});
			break;
		case "market": {
			i.gold -= 7;
			let e = r.market[t.item].shift();
			if (i.items.push({
				kind: t.item,
				points: e
			}), t.item === "ankh" && B(i, 1), t.item === "timeWinder") {
				let e = Math.min(3, i.bag);
				i.bag -= e, i.supply += e;
			}
			r.log.push({
				event: "market",
				rid: i.rid,
				token: t.item
			});
			break;
		}
		case "fight":
			t.monster === "goblin" && (r.turn.swords -= 2, V(r, i, 1)), t.monster === "goldfish" && (r.turn.swords -= 3, V(r, i, 3)), t.monster === "mummyGold" && (r.turn.swords -= 2, V(r, i, 4), re(r, i, 1, !0), Ae(r)), t.monster === "mummyCleanse" && (r.turn.swords -= 3, re(r, i, -Math.ceil(i.curses / 2)), Ae(r)), t.monster === "guardian" && (r.turn.swords -= 3, r.guardian.splice(r.guardian.indexOf(t.apparatus), 1), i.apparatus.push(t.apparatus)), r.log.push({
				event: "defeat",
				rid: i.rid,
				token: t.monster
			});
			break;
		case "mine": {
			let e = W[r.map].mines.find((e) => e.id === t.mine);
			r.turn.skill -= 2, i.supply--, r.mines[e.id] = i.rid, V(r, i, e.gold), r.turn.mined = !0, r.turn.featureUsed = !0, r.log.push({
				event: "mine",
				rid: i.rid,
				n: e.gold
			});
			break;
		}
		case "cache":
			r.turn.skill -= 8, i.supply--, r.cache[t.cache] = i.rid, t.cache < 4 && V(r, i, t.cache === 0 ? 5 : 3), t.cache === 1 && r.turn.swords++, t.cache === 2 && r.turn.boots++, (t.cache === 3 || t.cache === 4) && B(i, 1), t.cache >= 4 && Ne(r, i, 1), t.cache >= 5 && V(r, i, t.cache === 7 ? 2 : 1);
			break;
		case "rotate":
			r.gears.find((e) => e.id === t.gear).orientation = t.orientation, i.apparatus.splice(i.apparatus.indexOf(t.apparatus), 1), r.log.push({
				event: "rotate",
				rid: i.rid,
				n: t.gear
			});
			break;
		case "potion":
			i.potions.splice(i.potions.indexOf(t.potion), 1), (t.potion === "heal1" || t.potion === "heroism") && B(i, 1), t.potion === "heal2" && B(i, 2), (t.potion === "boots" || t.potion === "heroism") && r.turn.boots++, t.potion === "swords" && (r.turn.swords += 2), t.potion === "heroism" && r.turn.swords++;
			break;
		case "spring":
			qe(r, i.rid, t.card), i.spring--;
			break;
		case "resolve":
			Je(r, t);
			break;
		case "end":
			i.state === "active" && r.turn.needsAir && !i.items.some((e) => e.kind === "scuba") && !r.turn.flags.includes("scuba") && ae(r, i, 1), ut(r);
			break;
		case "continue": {
			let e = ct({
				...r.config,
				campaign: !1,
				map: "temple"
			}, r.players.map((e) => e.rid), F(r, 2147483647));
			e.config = { ...r.config }, e.gameNumber = 2, e.firstGameScores = r.firstGameScores;
			for (let t of e.players) {
				let e = r.players.find((e) => e.rid === t.rid);
				t.apparatus = [...e.apparatus], t.campaign = e.campaign;
			}
			return e.log.push({ event: "campaign" }), { state: e };
		}
	}
	return ze(r), { state: r };
}
function mt(e, t) {
	let n = e.players.find((e) => e.rid === t), r = {
		skill: e.turn.skill,
		swords: e.turn.swords,
		boots: e.turn.boots,
		stopped: e.turn.stopped,
		mined: e.turn.mined,
		negativeClank: e.turn.negativeClank,
		noiseMade: e.turn.noiseMade,
		goldEvents: e.turn.goldEvents,
		secretFound: e.turn.secretFound,
		featureUsed: e.turn.featureUsed,
		needsAir: e.turn.needsAir,
		flags: e.turn.flags
	};
	return {
		public: {
			config: e.config,
			map: e.map,
			phase: e.phase,
			active: M(e).rid,
			turnNumber: e.turnNumber,
			gameNumber: e.gameNumber,
			players: e.players.map((t) => {
				let { deck: n, hand: r, webs: i, apparatus: a } = t;
				return {
					rid: t.rid,
					room: t.room,
					damage: t.damage,
					supply: t.supply,
					clank: t.clank,
					bag: t.bag,
					gold: t.gold,
					curses: t.curses,
					artifacts: t.artifacts,
					idols: t.idols,
					chalices: t.chalices,
					eggs: t.eggs,
					scarabs: t.scarabs,
					items: t.items,
					potions: t.potions,
					discard: t.discard,
					played: t.played,
					state: t.state,
					campaign: t.campaign,
					deckCount: n.length,
					handCount: r.length,
					webCount: i.length,
					apparatusCount: a.length,
					apparatus: e.map !== "temple" || e.config.campaign || e.phase === "done" ? a : null
				};
			}),
			row: e.row,
			dungeonCount: e.dungeon.length,
			reserve: e.reserve,
			market: e.market,
			rooms: Object.entries(e.rooms).map(([e, t]) => ({
				id: Number(e),
				secrets: t.secrets.length,
				artifacts: t.artifacts,
				idols: t.idols
			})),
			webs: Object.keys(e.webs).map(Number),
			apparatus: Object.entries(e.apparatus).map(([e, t]) => ({
				tunnel: Number(e),
				kind: t
			})),
			mines: Object.entries(e.mines).map(([e, t]) => ({
				mine: Number(e),
				owner: t
			})),
			cache: e.cache,
			gears: e.gears,
			rage: e.rage,
			blackBag: e.blackBag,
			blackRemoved: e.blackRemoved,
			mummy: e.mummy,
			countdown: e.countdown,
			turn: r,
			choice: e.choice ? {
				rid: e.choice.rid,
				source: e.choice.source,
				kind: e.choice.kind
			} : null,
			scores: e.scores,
			firstGameScores: e.firstGameScores,
			log: e.log.slice(-120),
			lastDraw: e.lastDraw
		},
		private: {
			hand: n?.hand ?? [],
			apparatus: n?.apparatus ?? [],
			webs: n?.webs ?? [],
			peek: e.choice?.rid === t ? e.peek : null,
			actions: He(e, t),
			spring: n?.spring ?? 0
		}
	};
}
var ht = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: lt,
	schemas: {
		action: tt,
		publicView: at,
		privateView: ot,
		config: Xe
	},
	setup: (e, t, n) => ({ state: ct(e, t, n) }),
	reduce: (e, t, n) => pt(e, t, n.by),
	viewFor: mt,
	status: (e) => {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.players.map((e) => e.rid).sort((t, n) => We(e, t, n, e.scores));
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((n) => e.scores[n].eligible && We(e, n, t[0], e.scores) === 0),
			scores: Object.fromEntries(t.map((t) => [t, e.scores[t].total]))
		};
	},
	nextTickIn: (e) => e.choice || e.phase === "done" || e.phase === "intermission" ? null : e.phase === "dragon" ? te.dragon : e.queue.length ? te.effect : e.phase === "refill" ? te.refill : e.phase === "advance" || M(e).state === "knocked" ? te.advance : null
}, gt = [
	"#2979d6",
	"#58a342",
	"#b74955",
	"#9663c6"
], _t = (e) => String(e).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;"), J = (e, t, n, r, i = "") => `${i ? `<g ${i}>` : ""}<g transform="translate(${e} ${t}) scale(${n})">${r}</g>${i ? "</g>" : ""}`, vt = (e, t, n, r = 20, i = "#f6eedb", a = "") => `<text x="${t}" y="${n}" font-size="${r}" fill="${i}" ${a}>${_t(e)}</text>`, Y = (e, t, n = "") => `<path d="${e}" fill="${t}" ${n}/>`, X = (e, t, n, r, i, a = "") => `<rect x="${e}" y="${t}" width="${n}" height="${r}" fill="${i}" ${a}/>`, Z = (e, t, n, r, i = "") => `<circle cx="${e}" cy="${t}" r="${n}" fill="${r}" ${i}/>`, yt = (e, t, n, r = 24, i = "#fff5db") => vt(e, t, n, r, i, "font-weight=\"800\" text-anchor=\"middle\" paint-order=\"stroke\" stroke=\"#161b22\" stroke-width=\"2.5\" stroke-linejoin=\"round\""), bt = "<defs>\n <linearGradient id=\"sky\" x2=\"0\" y2=\"1\"><stop stop-color=\"#71b9da\"/><stop offset=\".55\" stop-color=\"#bad8cb\"/><stop offset=\"1\" stop-color=\"#477b87\"/></linearGradient>\n <linearGradient id=\"stone\" x2=\".3\" y2=\"1\"><stop stop-color=\"#63717c\"/><stop offset=\".45\" stop-color=\"#3e4c59\"/><stop offset=\"1\" stop-color=\"#24313c\"/></linearGradient>\n <linearGradient id=\"rock\" x2=\".4\" y2=\"1\"><stop stop-color=\"#363a34\"/><stop offset=\".5\" stop-color=\"#292c29\"/><stop offset=\"1\" stop-color=\"#1c2221\"/></linearGradient>\n <linearGradient id=\"wall\" x2=\".5\" y2=\"1\"><stop stop-color=\"#414842\"/><stop offset=\"1\" stop-color=\"#303831\"/></linearGradient>\n <linearGradient id=\"arch-stone\" x2=\".3\" y2=\"1\"><stop stop-color=\"#8e8b75\"/><stop offset=\".5\" stop-color=\"#6e6c5b\"/><stop offset=\"1\" stop-color=\"#45483e\"/></linearGradient>\n <linearGradient id=\"floor\" x2=\".2\" y2=\"1\"><stop stop-color=\"#6a6552\"/><stop offset=\"1\" stop-color=\"#9c9271\"/></linearGradient>\n <linearGradient id=\"ui-leather\" x2=\"0\" y2=\"1\"><stop stop-color=\"#352820\"/><stop offset=\"1\" stop-color=\"#251d19\"/></linearGradient>\n <linearGradient id=\"ui-button\" x2=\"0\" y2=\"1\"><stop stop-color=\"#2d6070\"/><stop offset=\"1\" stop-color=\"#234654\"/></linearGradient>\n <radialGradient id=\"room-light\" cx=\".6\" cy=\".7\" r=\".8\"><stop stop-color=\"#ce9b47\" stop-opacity=\".44\"/><stop offset=\"1\" stop-color=\"#b37e39\" stop-opacity=\"0\"/></radialGradient>\n <radialGradient id=\"crystal-light\" cx=\".5\" cy=\".75\" r=\".7\"><stop stop-color=\"#369ec5\" stop-opacity=\".52\"/><stop offset=\"1\" stop-color=\"#123a4a\" stop-opacity=\"0\"/></radialGradient>\n <radialGradient id=\"ground-light\"><stop stop-color=\"#72725c\" stop-opacity=\".18\"/><stop offset=\"1\" stop-color=\"#40473b\" stop-opacity=\"0\"/></radialGradient>\n <radialGradient id=\"ground-shadow\"><stop stop-color=\"#050e08\" stop-opacity=\".7\"/><stop offset=\".55\" stop-color=\"#07120c\" stop-opacity=\".35\"/><stop offset=\"1\" stop-color=\"#0e1710\" stop-opacity=\"0\"/></radialGradient>\n <linearGradient id=\"mouth-shade\" x2=\"0\" y2=\"1\"><stop stop-color=\"#071008\" stop-opacity=\".6\"/><stop offset=\".55\" stop-color=\"#071008\" stop-opacity=\"0\"/></linearGradient>\n <linearGradient id=\"room\" x2=\".8\" y2=\"1\"><stop stop-color=\"#080e18\"/><stop offset=\".8\" stop-color=\"#202f3b\"/><stop offset=\"1\" stop-color=\"#5a6870\"/></linearGradient>\n <linearGradient id=\"metal\" x2=\".2\" y2=\"1\"><stop stop-color=\"#a9b5ba\"/><stop offset=\".18\" stop-color=\"#63727a\"/><stop offset=\".5\" stop-color=\"#29353c\"/><stop offset=\".85\" stop-color=\"#74818a\"/><stop offset=\"1\" stop-color=\"#b7c0b7\"/></linearGradient>\n <linearGradient id=\"gold\" x2=\".3\" y2=\"1\"><stop stop-color=\"#fff0a5\"/><stop offset=\".25\" stop-color=\"#e9b951\"/><stop offset=\".6\" stop-color=\"#a66824\"/><stop offset=\"1\" stop-color=\"#f1cd6d\"/></linearGradient>\n <linearGradient id=\"leather\" x2=\"0\" y2=\"1\"><stop stop-color=\"#7d5943\"/><stop offset=\".4\" stop-color=\"#49352e\"/><stop offset=\"1\" stop-color=\"#2e2525\"/></linearGradient>\n <linearGradient id=\"paper\" x2=\".2\" y2=\"1\"><stop stop-color=\"#ddcf9d\"/><stop offset=\".5\" stop-color=\"#c5b37f\"/><stop offset=\"1\" stop-color=\"#e1d0a0\"/></linearGradient>\n <linearGradient id=\"blue\" x2=\".5\" y2=\"1\"><stop stop-color=\"#a2ecff\"/><stop offset=\".4\" stop-color=\"#318ec3\"/><stop offset=\"1\" stop-color=\"#173e82\"/></linearGradient>\n <linearGradient id=\"fire\" x2=\"1\" y2=\".2\"><stop stop-color=\"#fffcc2\"/><stop offset=\".2\" stop-color=\"#fff181\"/><stop offset=\".6\" stop-color=\"#ff9a2a\"/><stop offset=\"1\" stop-color=\"#ed3a15\" stop-opacity=\"0\"/></linearGradient>\n <linearGradient id=\"flame\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fffbd2\"/><stop offset=\".5\" stop-color=\"#ffba3a\"/><stop offset=\"1\" stop-color=\"#e64d17\"/></linearGradient>\n <linearGradient id=\"purple\" x2=\".3\" y2=\"1\"><stop stop-color=\"#b3a2d1\"/><stop offset=\".45\" stop-color=\"#695081\"/><stop offset=\"1\" stop-color=\"#312a46\"/></linearGradient>\n <linearGradient id=\"redflag\" x2=\"0\" y2=\"1\"><stop stop-color=\"#aa453c\"/><stop offset=\"1\" stop-color=\"#542629\"/></linearGradient>\n <linearGradient id=\"cardblue\" x2=\"0\" y2=\"1\"><stop stop-color=\"#4389bc\"/><stop offset=\"1\" stop-color=\"#1a3f62\"/></linearGradient>\n <linearGradient id=\"cave\" x2=\".6\" y2=\"1\"><stop stop-color=\"#071b39\"/><stop offset=\".55\" stop-color=\"#15294b\"/><stop offset=\"1\" stop-color=\"#3c3886\"/></linearGradient>\n <filter id=\"shadow\" x=\"-.3\" y=\"-.3\" width=\"1.6\" height=\"1.8\"><feDropShadow dx=\"0\" dy=\"5\" stdDeviation=\"4\" flood-color=\"#071019\" flood-opacity=\".8\"/></filter>\n <filter id=\"blueglow\" x=\"-.5\" y=\"-.5\" width=\"2\" height=\"2\"><feDropShadow dx=\"0\" dy=\"0\" stdDeviation=\"6\" flood-color=\"#59d7ff\" flood-opacity=\".9\"/></filter>\n <filter id=\"goldglow\" x=\"-.6\" y=\"-.6\" width=\"2.2\" height=\"2.2\"><feDropShadow dx=\"0\" dy=\"0\" stdDeviation=\"8\" flood-color=\"#ffcc54\" flood-opacity=\".85\"/></filter>\n <filter id=\"fireglow\" x=\"-.4\" y=\"-1\" width=\"1.8\" height=\"3\"><feDropShadow dx=\"0\" dy=\"0\" stdDeviation=\"12\" flood-color=\"#ff6917\" flood-opacity=\".8\"/></filter>\n <symbol id=\"boot\" viewBox=\"-16 -17 32 34\"><path d=\"M-9-15 3-14 2-2 9 2 14 4 13 11 7 14-11 12-12 5-9 2Z\" fill=\"#111923\" stroke=\"#d9c88d\" stroke-width=\"1.2\"/><path d=\"M-8-10 2-9M-8-5 2-4M-10 8 10 9\" fill=\"none\" stroke=\"#9e8b65\" stroke-width=\"1.8\"/></symbol>\n <symbol id=\"sword\" viewBox=\"-18 -20 36 40\"><path d=\"m-3 7 2-22 5-4 4 5L2 8Z\" fill=\"#d9e9e9\" stroke=\"#182633\" stroke-width=\"1.2\"/><path d=\"M2-14 0 6\" fill=\"none\" stroke=\"#88a8b1\"/><path d=\"m-10 7 18 2-2 5-16-3Z\" fill=\"url(#gold)\"/><path d=\"m-2 12 4 1-2 10-5-1Z\" fill=\"#734b35\"/></symbol>\n <symbol id=\"skill\" viewBox=\"-18 -18 36 36\"><path d=\"M0-16 15 0 0 16-15 0Z\" fill=\"#30b3eb\" stroke=\"#092438\" stroke-width=\"2\"/><path d=\"m0-12 11 12H0Z\" fill=\"#a2efff\" opacity=\".75\"/></symbol>\n <symbol id=\"heart\" viewBox=\"-18 -18 36 36\"><path d=\"M0 16C-5 9-18 1-16-8-14-19-3-16 0-9 4-18 15-18 17-8 20 1 6 10 0 16Z\" fill=\"#b13d48\" stroke=\"#f2a298\" stroke-width=\"1.3\"/><path d=\"M-11-9Q-8-14-4-9\" fill=\"none\" stroke=\"#ffd0b1\" stroke-width=\"2\"/></symbol>\n <symbol id=\"coin\" viewBox=\"-18 -18 36 36\"><circle r=\"16\" fill=\"url(#gold)\" stroke=\"#52381f\" stroke-width=\"2\"/><circle r=\"11.8\" fill=\"none\" stroke=\"#fff0a0\" stroke-width=\"1.1\"/><path d=\"m0-9 3 6 6 1-4 4 1 6-6-3-6 3 1-6-4-4 6-1Z\" fill=\"#a46928\"/></symbol>\n <symbol id=\"lock\" viewBox=\"-16 -18 32 36\"><path d=\"M-8-3v-7C-8-21 8-21 8-10v7\" fill=\"none\" stroke=\"#f1edd7\" stroke-width=\"4\"/><path d=\"M-12-3h24v21h-24Z\" fill=\"#ece8d1\"/><circle cy=\"5\" r=\"3\" fill=\"#1a2830\"/><path d=\"M-1 7h2v6h-2Z\" fill=\"#1a2830\"/></symbol>\n <symbol id=\"monster\" viewBox=\"-20 -18 40 36\"><path d=\"m-15-4-3-10 10 6 8-3 8 3 10-6-3 10 1 9-7 10H-9L-16 5Z\" fill=\"#f0ead5\" stroke=\"#0f1e29\" stroke-width=\"2\"/><path d=\"m-10 0 8 2-5 4Zm20 0-8 2 5 4ZM-5 9l5-3 5 3-5 4Z\" fill=\"#17212a\"/></symbol>\n <symbol id=\"cube\" viewBox=\"-17 -19 34 38\"><path d=\"M0-17 15-9 0 0-15-9Z\" fill=\"currentColor\" stroke=\"#e5eddd\" stroke-opacity=\".45\"/><path d=\"M-15-9 0 0v18l-15-9Z\" fill=\"currentColor\"/><path d=\"M0 0 15-9V9L0 18Z\" fill=\"currentColor\"/><path d=\"M0 0 15-9V9L0 18Z\" fill=\"#000\" opacity=\".23\"/><path d=\"M-15-9 0 0v18\" fill=\"none\" stroke=\"#fff\" stroke-opacity=\".3\" stroke-width=\"1.2\"/></symbol>\n <symbol id=\"flameSmall\" viewBox=\"-15 -31 30 62\"><path d=\"M0-29C8-12 18-6 12 10S-14 31-13 9C-17-4-5-5-3-17L0-8Z\" fill=\"url(#flame)\"/><path d=\"M0-8C7 7 10 17 1 21S-6 7 0-8Z\" fill=\"#fff9b1\"/></symbol>\n <symbol id=\"goblet\" viewBox=\"-32 -42 64 84\"><path d=\"M-24-35H24L18-5 5 7v20l17 7v5h-44v-5l17-7V7L-18-5Z\" fill=\"url(#gold)\" stroke=\"#65421f\" stroke-width=\"2\"/><path d=\"M-22-27H-32Q-36-4-17-4M22-27H32Q36-4 17-4\" fill=\"none\" stroke=\"#d69c3e\" stroke-width=\"5\"/><path d=\"M-13-31H-5L-1-4-8-10Z\" fill=\"#fff4a4\" opacity=\".7\"/><path d=\"m0-27 7 8-7 9-7-9Z\" fill=\"#61bf87\" stroke=\"#226d5d\"/></symbol>\n <symbol id=\"crown\" viewBox=\"-38 -35 76 70\"><path d=\"m-31-21 16 12 15-23L15-9 31-21 25 20H-25Z\" fill=\"url(#gold)\" stroke=\"#6a4124\" stroke-width=\"2\"/><path d=\"M-24 14H24V28H-24Z\" fill=\"url(#gold)\"/><path d=\"m0-10 7 9-7 9-7-9Z\" fill=\"#41bb8c\"/><circle cx=\"-21\" cy=\"2\" r=\"4\" fill=\"#bd3f52\"/><circle cx=\"21\" cy=\"2\" r=\"4\" fill=\"#bd3f52\"/></symbol>\n <symbol id=\"idol\" viewBox=\"-30 -40 60 80\"><path d=\"M-17-32 0-40 17-32 24-15 14 7 21 29 29 39H-29L-21 29-14 7-24-15Z\" fill=\"url(#gold)\" stroke=\"#825020\" stroke-width=\"2\"/><path d=\"M-12-24 0-19 12-24 9-6 0 1-9-6Z\" fill=\"#b17526\"/><circle cx=\"-8\" cy=\"-17\" r=\"3\" fill=\"#b32337\"/><circle cx=\"8\" cy=\"-17\" r=\"3\" fill=\"#b32337\"/><path d=\"M-13 13Q0 22 13 13M-14 30H14\" fill=\"none\" stroke=\"#ffe49b\" stroke-width=\"3\"/></symbol>\n <symbol id=\"star\" viewBox=\"-10 -10 20 20\"><path d=\"M0-10 2-2 10 0 2 2 0 10-2 2-10 0-2-2Z\" fill=\"#e4eaff\"/></symbol>\n</defs>";
function Q(e, t, n, r) {
	return `<svg x="${t - r / 2}" y="${n - r / 2}" width="${r}" height="${r}" overflow="visible"><use href="#${e}" width="${r}" height="${r}"/></svg>`;
}
function xt(e, t, n, r, i = 0) {
	return `<g transform="rotate(${i} ${e} ${t})" color="${r}">${Q("cube", e, t, n)}</g>`;
}
function St(e, t = 0) {
	return `<g stroke-linejoin="round">${Y("M-18 27Q0 16 18 27L14 31H-14Z", "#091119", "opacity=\".65\"")}${Y("M-11 8-7 28-3 31 0 27 3 31 8 29 12 8Z", "#544b47", "stroke=\"#1d1c27\" stroke-width=\"2\"")}${Y("M-9 20-12 31-3 32-1 22M7 20 4 31 14 31 11 20", "#302c31")}${Y("M-13-9-18 13-4 20 0 14 5 21 18 13 12-11Z", e, "stroke=\"#c3c3ae\" stroke-width=\"1.8\"")}${Y("M-11-7-15 11-6 14 1-3 5 15 14 11 9-8Z", "#000", "opacity=\".23\"")}${Y("M-13-7Q-15-21 0-32 15-22 14-7L9 1H-8Z", e, "stroke=\"#d0ceba\" stroke-width=\"1.8\"")}${Y("M-8-13Q0-24 9-13L7-2Q0 6-7-2Z", "#191f2d")}${Y("M-6-8Q0-12 6-8L4 1H-4Z", "#c69265")}${Y("M-11 1-18 13-24 9-18-4Z", e)}${Y("m12 0 10 9-4 6-12-9Z", e)}${Z(-20, 11, 3.5, "#c4966f")}${Z(20, 12, 3.5, "#c4966f")}${Y(t ? "M18 14 31-3 34-5 32 0 22 17Z" : "M18 14 27 23 29 20 22 12Z", "#d5dfd7", "stroke=\"#2c4047\"")}${Y("M-13 9 13 9 12 13H-12Z", "#8d633b")}${X(-2, 9, 5, 5, "url(#gold)")}${Z(-3, -6, 1, "#f8dbac")}${Z(3, -6, 1, "#f8dbac")}</g>`;
}
function Ct(e, t, n, r, i = gt[e]) {
	let a = e === 2 ? "#c09675" : e === 3 ? "#cc9c58" : "#d3a77d", o = e === 2 ? Y("M-29-3-24-30 0-41 24-30 30-3 21 11 15-14H-15L-20 12Z", "url(#metal)", "stroke=\"#c4bca1\" stroke-width=\"2\"") + Y("M-25-15-42-27-42-40-30-31M25-15 42-27 42-40 30-31", "url(#gold)") : Y("M-31 5Q-38-28 0-45 37-25 30 6L20 21-20 21Z", i, "stroke=\"#a5bbac\" stroke-width=\"2\""), s = e === 3 ? Y("m-16-15-7-16 16 9M16-15l7-16-16 9", "#c6a36b") + Y("M-18 1-10 19 0 25 12 19 20 1Z", "#bd8e4b") + Y("M-19 1H-35M-20 7-35 11M19 1H35M20 7 35 11", "none", "stroke=\"#e9d7aa\" stroke-width=\"1.5\"") : e === 2 ? Y("M-20 4-22 21-8 34 0 29 8 34 22 21 20 4 10 12H-10Z", "#725042") : Y("M-26 5-25 26 0 17 26 27 26 4 13 9H-13Z", i);
	return J(t, n, r / 50, Z(0, 0, 49, "url(#metal)", "stroke=\"#0d1c2b\" stroke-width=\"4\"") + Z(0, 0, 43, "#142d43", "stroke=\"" + i + "\" stroke-width=\"3\"") + o + Y("M-21-17Q0-32 21-17L20 9 10 24H-10L-20 9Z", a, "stroke=\"#503e36\" stroke-width=\"1.5\"") + s + Y("M-14-7-5-9M5-9 14-7", "none", "stroke=\"#493c36\" stroke-width=\"3\"") + Z(-9, -4, 2, "#262b2c") + Z(9, -4, 2, "#262b2c") + Y("M-4 1-2 6H3M-5 12H6", "none", "stroke=\"#805f49\" stroke-width=\"1.5\""));
}
function wt(e, t, n, r = !1) {
	return J(e, t, n, `<g filter="url(#shadow)">${Z(105, 105, 92, "#18242a", "stroke=\"#83908e\" stroke-width=\"8\"")}${Z(105, 105, 82, "#342d40", "stroke=\"#a39878\" stroke-width=\"3\"")}${Y("M24 134 27 93 17 81 37 51 54 42 55 19 81 39 107 33 127 44 144 33 145 57 173 64 184 88 216 103 235 105 248 122 242 141 212 146 194 169 157 176 129 171 100 184 64 177Z", "url(#purple)", "stroke=\"#221f30\" stroke-width=\"4\"")}${Y("M42 50 20 18 34 12 63 43 80 45 62 57Z", "url(#metal)")}${Y("M69 36 64 1 77 6 88 40M111 39 120 12 129 10 126 48M145 59 164 38 175 40 164 72", "url(#metal)", "stroke=\"#252d32\" stroke-width=\"2\"")}${Y("M30 91 43 65 75 59 90 73 76 90 58 106Z", "#807292")}${Y("M88 59 113 49 138 63 157 75 142 95 111 99 88 82Z", "#716082")}${Y("M151 77 174 84 184 105 223 116 233 128 193 135 164 119Z", "#897594")}${Y("M76 100 112 88 149 103 167 123 146 143 114 132 85 137 63 125Z", "#53415f")}${Y("M110 149 140 143 176 145 204 137 236 135 221 155 193 161 168 174 135 167Z", r ? "#240c17" : "#352333", "stroke=\"#b08898\" stroke-width=\"2\"")}${Y("m143 147 7 16 7-17m17-1 6 13 7-14m16-4 4 11 7-13m-80 3-1 13 8-10", "#e6d4b3")}${Y("M117 89 129 77 157 88 142 101Z", "#231e28")}${Y("m127 88 15-3 8 4-14 6Z", r ? "#fff4ac" : "#f3a130", "filter=\"url(#goldglow)\"")}${Y("M138 85 136 96", "none", "stroke=\"#3a2121\" stroke-width=\"3\"")}${Y("m223 115 9 4-3 6-8-2Z", "#272332")}${Y("M46 123 65 116 78 130 61 140ZM64 148 85 137 105 154 85 162ZM100 112 114 103 125 116 115 128Z", "#aa93ac", "opacity=\".3\"")}${Y("M33 143 36 164 56 179 88 182 108 175 126 186 152 174 175 182 175 198 27 198Z", "#3c3548", "stroke=\"#90888e\" stroke-width=\"3\"")}${[
		35,
		65,
		95,
		125,
		155
	].map((e, t) => xt(e, 202, 23, t < 3 ? "#d95226" : "#49444a")).join("")}</g>`);
}
function Tt() {
	let e = [];
	for (let t = 0; t < 5; t++) {
		let n = t * 145;
		e.push(Y(`M35 ${n}H1125`, "none", "stroke=\"#87907a\" stroke-opacity=\".1\" stroke-width=\"2\""));
		for (let r = 0; r < 8; r++) {
			let i = 55 + r * 156 + (t % 2 ? 78 : 0);
			e.push(Y(`M${i} ${n}v145`, "none", "stroke=\"#87907a\" stroke-opacity=\".08\" stroke-width=\"2\""));
		}
	}
	return X(-150, -160, 1800, 1900, "url(#rock)") + X(35, 0, 1090, 700, "url(#wall)") + e.join("") + Y("M35 100Q300 160 540 80T1125 140V440Q800 380 570 460T35 400Z", "#a1a78a", "opacity=\".025\"") + Y("M-100 694Q130 670 300 691T650 698T1030 695T1510 732L1530 1580H-120Z", "url(#rock)") + Y("M-60 785Q230 706 430 814T840 830T1490 800V1040Q1200 972 980 1060T470 960T-60 1050Z", "#43473c", "opacity=\".15\"") + Y("M-90 1160Q210 1070 470 1170T1010 1150T1520 1200V1560H-90Z", "#151d1b", "opacity=\".22\"") + Y("M55 855Q210 794 340 840M710 1090Q855 1050 950 1100M1070 850Q1230 880 1380 821M130 1340Q270 1295 405 1350", "none", "stroke=\"#111b18\" stroke-width=\"4\" stroke-opacity=\".18\"") + Y("M20 681Q180 663 340 682T670 689T1000 685L1170 708 1155 721Q920 705 690 711T310 702T20 696Z", "#555f44") + Y("M20 680Q160 663 310 680T660 687T1000 684L1168 708", "none", "stroke=\"#81905a\" stroke-width=\"6\" stroke-opacity=\".42\"") + "<ellipse cx=\"650\" cy=\"1010\" rx=\"510\" ry=\"460\" fill=\"url(#ground-light)\"/>";
}
function Et(e, t, n, r = "goblet", i = .67) {
	return J(e, t, i, `<ellipse cy="36" rx="27" ry="7" fill="#080d0b" opacity=".75"/>${Q(r, 0, -4, 80)}${Z(0, 38, 18, "#356348", "stroke=\"#c3b987\" stroke-width=\"1.2\"")}${yt(n, 0, 46, 27)}${Q("star", -27, -27, 9)}`);
}
function Dt(e, t, n = !1) {
	return J(e, t, 1, Z(0, 1, 19, "#191a12", "opacity=\".5\"") + Z(0, -1, 18, n ? "#dfb75b" : "#b99b62", "stroke=\"#6d532c\" stroke-width=\"1.5\"") + Y("M-13-9Q-3-20 11-10", "none", "stroke=\"#f1dc96\" stroke-width=\"2\" stroke-opacity=\".6\"") + vt("?", 0, 6, 24, "#51391c", "text-anchor=\"middle\" font-family=\"Georgia\" font-weight=\"700\""));
}
function Ot(e, t, n, r = 15, i = 0) {
	return J(e, t, 1, Y(`M${-r / 2} 0L${-r * .72 + i} ${-n * .65} ${i} ${-n} ${r * .65 + i} ${-n * .64} ${r / 2} 0Z`, "#276b88") + Y(`M0 0L${i} ${-n} ${r * .65 + i} ${-n * .64} ${r / 2} 0Z`, "#4ba6c5") + Y(`M${-r * .72 + i} ${-n * .65} ${i} ${-n} ${i + 1} ${-n * .65} 0 0 ${-r / 2} 0Z`, "#23536c") + Y(`M${i} ${-n} ${r * .65 + i} ${-n * .64}`, "none", "stroke=\"#b0e3df\" stroke-width=\"1.5\" stroke-opacity=\".7\""));
}
function kt(e, t = !1, n = !1, r = -1, i = []) {
	let a = (e.market ? 148 : e.idols ? 108 : 142) / 2, o = (e.idols ? 165 : 104) / 2, s = `r${e.id}`, c = e.cave ? "M-61 40Q-77 14-57-20L-37-40Q-2-53 29-38L55-20Q75 9 58 40Q15 53-21 45Z" : `M${-a + 13} ${o - 6}V${-o + 38}Q${-a + 13} ${-o + 9} 0 ${-o + 9}Q${a - 13} ${-o + 9} ${a - 13} ${-o + 38}V${o - 6}Z`, l = e.cave ? "M-72 39Q-89 10-69-25L-43-49Q-2-66 36-47L68-24Q87 11 70 45L36 56-26 53Z" : `M${-a - 2} ${o - 2}L${-a - 3} ${-o + 40}Q${-a - 4} ${-o - 4} 0 ${-o - 5}Q${a + 5} ${-o - 4} ${a + 3} ${-o + 40}L${a + 1} ${o + 2}Z`, u = "<ellipse cy=\"" + (o + 8) + "\" rx=\"" + (a + 17) + "\" ry=\"18\" fill=\"url(#ground-shadow)\"/>";
	u += Y(l, e.cave ? "#424f48" : "url(#arch-stone)") + Y(c, "#101a16");
	let d = "";
	if (e.cave) d += X(-80, -65, 160, 130, "#102b31") + X(-80, -65, 160, 130, "url(#crystal-light)") + Y("M-72 35Q-35 20-6 30T70 31V65H-75Z", "#34616b") + "<ellipse cx=\"0\" cy=\"36\" rx=\"53\" ry=\"12\" fill=\"#62b2c4\" opacity=\".16\"/>", d += Ot(-49, 15, 43, 18, -5) + Ot(-35, 25, 26, 12, 2) + Ot(43, 22, 49, 18, 5) + Ot(56, 28, 29, 14, 4) + Ot(-17, -27, 22, 12, -4) + Ot(29, -28, 20, 12, 4), d += Y("M-70 37-51 30-36 41-23 37 1 43 22 37 45 45 62 35 75 54H-75Z", "#384d47");
	else if (d += X(-a, -o, a * 2, o * 2, "#202a21") + X(-a, -o, a * 2, o * 2, "url(#room-light)") + Y(`M${-a + 13} ${-o + 30}l19 10v${o * 2 - 62}l-19 16Z`, "#2b382a") + Y(`M${a - 13} ${-o + 30}l-18 10v${o * 2 - 62}l18 16Z`, "#5b5b40") + Y(`M${-a + 13} ${o - 6}l19-16H${a - 31}l18 16Z`, "url(#floor)") + Y(`M${-a + 33} ${-o + 33}H${a - 30}M${-a + 33} ${-o + 53}H${a - 30}`, "none", "stroke=\"#9b956a\" stroke-opacity=\".12\" stroke-width=\"1.2\"") + Y(`M-12 ${o - 21}l-12 17M16 ${o - 21}l12 17`, "none", "stroke=\"#4f503e\" stroke-width=\"1.2\"") + X(-a, -o, a * 2, o * 2, "url(#mouth-shade)"), e.market) {
		d += "<ellipse cx=\"0\" cy=\"7\" rx=\"65\" ry=\"48\" fill=\"url(#room-light)\"/>" + Y("M-58-25Q0-34 58-25L64-5Q49 1 42-6 28 2 21-5 7 2 0-5-14 2-21-5-35 2-42-5-55 0-64-5Z", "#c0b18a");
		for (let e = 0; e < 6; e++) e % 2 == 0 && (d += Y(`M${-57 + e * 19} -25q9-2 18-2l2 23q-9 6-20 0Z`, "#8c4d36"));
		d += Y("M-56-4V35M55-4V35", "none", "stroke=\"#8c7148\" stroke-width=\"5\"") + X(-57, 21, 114, 17, "#927344") + X(-53, 38, 106, 10, "#5b452d") + Y("M-53 23H53", "none", "stroke=\"#c0a26d\" stroke-width=\"2\"");
		for (let e = 0; e < 4; e++) d += Y(`M${-39 + e * 24} 21v-9q6-8 12 0v9Z`, [
			"#847b53",
			"#a2844b",
			"#68754b",
			"#926754"
		][e]);
	} else !e.artifact && !e.major && !e.minor && !e.heal && (d += Y(`M24 ${o - 23}q-6-18 3-21h10q9 5 1 21Z`, "#666344") + Y(`M22 ${o - 23}h17`, "none", "stroke=\"#8a8160\" stroke-width=\"1\""));
	let f = "";
	if (e.artifact) f += Et(0, 1, e.artifact, e.artifact === 15 ? "crown" : "goblet");
	else if (e.idols) for (let e = 0; e < 3; e++) f += Et(0, -44 + e * 48, i[e] ?? 5, "idol", .44);
	else e.heal ? f += Q("heart", 0, 0, 42) : e.major ? f += Dt(0, 4, !0) : e.minor && (f += e.minor > 1 ? Dt(-15, 4) + Dt(15, 4) : Dt(0, 4));
	return r >= 0 && (f += J(e.artifact ? -30 : 0, 14, .95, St(gt[r], Number(r === 0)))), u += `<defs><clipPath id="clip-${s}">${Y(c, "white")}</clipPath></defs><g clip-path="url(#clip-${s})">${d}${f}</g>`, e.cave ? u += Y("M-69 27Q-80 7-62-22L-41-43M22-45 53-28 65-7", "none", "stroke=\"#7a8870\" stroke-width=\"3\" stroke-opacity=\".5\"") : u += Y(`M${-a + 2} ${-o + 36}Q${-a + 1} ${-o - 1} 0 ${-o - 2}`, "none", "stroke=\"#b0a680\" stroke-opacity=\".5\" stroke-width=\"3\"") + Y(`M-34 ${-o + 2}l5 14M-1 ${-o - 3}v12M33 ${-o + 2}l-5 14M${-a + 1} ${-o + 38}h14M${a - 14} ${-o + 38}h16`, "none", "stroke=\"#454b3b\" stroke-width=\"3\" stroke-opacity=\".8\"") + Y(`M${-a + 11} ${o - 4}H${a - 10}`, "none", "stroke=\"#a59872\" stroke-width=\"3\" stroke-opacity=\".6\""), t ? u += Y(l, "none", "stroke=\"#f4ce70\" stroke-width=\"2.5\" stroke-linejoin=\"round\" filter=\"url(#goldglow)\"") : n && (u += `<path d="M${-a + 5} ${o + 7}h17m${a * 2 - 44} 0h17" fill="none" stroke="#87c2ba" stroke-width="3" stroke-linecap="round"/>`), r === 0 && (u += Ct(0, -44, -o - 22, 15) + Y(`M-37 ${-o - 10}l14 13 2-17Z`, "#f0e4ba")), J(e.x, e.y, 1, `<g id="${s}">${u}</g>`);
}
function At(e = "#3999de") {
	return X(0, 0, 200, 170, "#314b56") + Y("m53 42 31-24 58 8 25 46-31 67-63-5-34-53Z", e, "stroke=\"#c1f0f0\" stroke-width=\"1.2\"") + Y("m84 18 3 51 55-43-10 58 35-12-31 67-49-70-14 65-34-53 48-12Z", "#122f83", "opacity=\".8\"") + Y("m53 42 34 27-3-51 58 8-55 43-48 12Z", "#90e6ff", "opacity=\".75\"") + Y("m87 69 45 15 4 55Z", "#5cbef1") + Y("m53 42 20 92-34-53Z", "#aeddf2", "opacity=\".5\"") + Q("star", 146, 45, 16);
}
function jt(e = !1) {
	let t = X(0, 0, 200, 170, "#354444") + X(0, 146, 200, 24, "#525c4f");
	return e && (t += Y("M14 117 60 105 95 122 91 161H14Z", "#6d452b", "stroke=\"#ad955c\" stroke-width=\"4\"") + Y("M14 117 60 105 95 122 55 132Z", "#a77b40") + X(50, 127, 12, 22, "url(#gold)")), t += Y("M63 170 75 109 91 92 123 93 143 114 157 170Z", e ? "#5d4565" : "#53754c", "stroke=\"#1a2c2a\" stroke-width=\"2\"") + Y("M81 108 62 169H94L105 121 122 170H156L131 104Z", e ? "#34334e" : "#334b3b") + Y("M84 81 88 111 107 121 126 104 120 78Z", "#c2926d") + Y("M76 52Q96 23 124 49L134 89 116 98 83 88Z", e ? "#51405e" : "#5e4231") + Y("M88 53Q110 39 123 62L121 85 110 100 93 90 85 73Z", "#d1a27c") + Y("M87 52 80 88 74 113 83 122 94 91 92 62 123 59 130 102 141 104 132 58Q111 23 87 52Z", e ? "#524561" : "#6e4531") + Y("M98 72h6m8-1h6", "none", "stroke=\"#303932\" stroke-width=\"2\"") + Y("M108 76 105 82h5m-7 7h10", "none", "stroke=\"#976846\" stroke-width=\"1.3\"") + Y("M70 111 44 142 49 154 80 134 94 119M132 112l28-29 11 9-24 43Z", e ? "#514262" : "#667c50", "stroke=\"#263c34\" stroke-width=\"2\"") + Y("m49 145 7 8-12 7-8-8ZM157 84l3-10 13 4-1 13Z", "#c9976e") + Y("M84 147 137 137 141 147 82 159Z", "#9b7644") + X(110, 142, 12, 11, "url(#gold)", "transform=\"rotate(-12 110 142)\""), e && (t += Y("m43 145-15-12-2 4 14 14Z", "#c5d0cb") + Y("M83 69 122 66 119 80 88 83Z", "#2b2b3b") + Y("M94 74h8m8-1h8", "none", "stroke=\"#d4b48a\" stroke-width=\"2\"")), t;
}
function Mt() {
	return X(0, 0, 200, 170, "#263f4e") + Y("M0 123 68 66 128 84 200 21V170H0Z", "#405964") + Y("m10 146 65-31 75 18 50-15v52H0Z", "#5c6c6b") + J(101, 83, 2.3, Q("sword", 0, 0, 66), "transform-origin=\"101 83\"") + Y("M30 44Q80-5 140 39M54 38Q102 6 156 57", "none", "stroke=\"#7ed2e5\" stroke-width=\"3\" opacity=\".4\"") + Q("star", 118, 47, 18);
}
function Nt() {
	return X(0, 0, 200, 170, "#302b30") + Y("M0 144 65 116 139 116 200 145v25H0Z", "#67584a") + Y("M30 35 133 24 169 45 164 146 62 160 29 137Z", "#422b26", "stroke=\"#b49b64\" stroke-width=\"3\"") + Y("M44 39 133 30 161 47 153 139 65 151 43 133Z", "#5f3f31") + Y("M35 38 57 50 62 151 35 135Z", "#2d2525") + Y("m63 53 85-12 8 6-5 85-85 10Z", "#ad8f58", "opacity=\".23\"") + J(108, 93, .64, Y("M-23-25-3-35 23-28 28-10 7 1 17 27-12 36-30 14-16 0Z", "url(#gold)") + Y("M-13-8 2-17 14-10 6-1-7 5Z", "#634931")) + Y("M58 145 153 134 159 140 66 153Z", "#e4d5ad") + Y("M45 39 52 47M135 30l15 9M67 140l-2-9m83-5-9 3", "none", "stroke=\"#ddc379\" stroke-width=\"4\"");
}
function Pt() {
	return X(0, 0, 200, 170, "#3e3436") + Y("M0 170 39 88 76 116 119 70 160 101 200 82V170Z", "#645042") + Y("M50 170 62 103 81 88 129 87 151 116 169 170Z", "#6d3f32") + Y("M58 56 27 41 41 71 66 82M137 55l35-17-14 31-22 14", "#70934f", "stroke=\"#283c30\" stroke-width=\"2\"") + Y("M68 40 88 25 121 30 141 48 133 88 111 111 78 97 61 69Z", "#779b54", "stroke=\"#314431\" stroke-width=\"3\"") + Y("M70 47 87 42 101 61 80 62M116 45l17 6-8 17-19-8", "#4c683c") + Y("m75 51 18 3-11 9Zm37 6 14-4-3 10Z", "#eacb6c") + Y("M93 63 82 81 108 86 115 77Z", "#93ae67") + Y("M77 89 90 84 120 86 123 96 101 101 84 98Z", "#392c28") + Y("m88 87 3 9 6-8m13-1 4 7 5-8", "#dfd0ab") + Y("M69 111 38 143 45 158 83 136M135 111l26 15-2 15-31-10Z", "#819352") + Y("M52 165 60 141 141 135 153 170Z", "#353b35") + J(156, 89, 1.3, Q("sword", 0, 0, 72)) + Y("M73 122 137 145M80 107l-8 50", "none", "stroke=\"#a37c4b\" stroke-width=\"8\"");
}
function Ft() {
	return X(0, 0, 200, 170, "#33494a") + Y("M0 150 48 119 102 128 158 106 200 139v31H0Z", "#6b7262") + J(95, 88, 2.4, Q("boot", 0, 0, 54), "transform-origin=\"95 88\"") + Y("M23 38 55 21 84 32M125 31l39-10 18 17", "none", "stroke=\"#91b2a0\" stroke-width=\"3\" opacity=\".45\"");
}
function It(e) {
	let t = X(0, 0, 200, 170, "#344550") + Y("M0 150 83 126 151 138 200 141V170H0Z", "#596663");
	return t += e === "scramble" ? Y("M0 147H40V119H85V85H130V48H200V170H0Z", "#53646b", "stroke=\"#93a4a4\" stroke-width=\"2\"") + Y("M153 0Q140 25 147 53T143 97", "none", "stroke=\"#bca371\" stroke-width=\"5\"") + J(104, 80, 1.9, St("#4d7c85", 1), "transform=\"rotate(-17 104 80)\"") + Y("M129 65 147 52", "none", "stroke=\"#c3976d\" stroke-width=\"7\"") : e === "stumble" ? J(99, 91, 2.1, St("#89794c", 1), "transform=\"rotate(23 99 91)\"") + J(151, 143, .85, Y("M-20-19 12-32 26-19 16-4 10 15-17 16-25 1Z", "url(#gold)", "stroke=\"#62462d\" stroke-width=\"2\"") + Y("m-15-16 9 29M3-26 7 8", "none", "stroke=\"#f1d18e\" stroke-width=\"3\"")) + Q("star", 167, 100, 19) + Q("star", 142, 81, 12) : e === "sneak" ? Y("M134 16Q160-7 185 16V91H134Z", "#819eae", "opacity=\".6\"") + Y("M145 8V91M165 4V91M182 13V91M134 50H185", "none", "stroke=\"#24323c\" stroke-width=\"4\"") + J(91, 102, 2.1, St("#696080", 1)) + Y("M21 132 40 130M17 143l21-1", "none", "stroke=\"#8fabb0\" stroke-width=\"2\"") : J(109, 103, 2.2, St("#447d8b", 1), "transform=\"rotate(-13 109 103)\"") + Y("M23 81 53 75M18 96l26-2", "none", "stroke=\"#a4c1be\" stroke-width=\"2\""), t;
}
function Lt() {
	return X(0, 0, 200, 170, "#354439") + Y("M0 142 30 89 54 118 157 76 200 116v54H0Z", "#55614d") + Y("M48 170 56 106 81 93 126 97 153 124 162 170Z", "#5d6578", "stroke=\"#232e33\" stroke-width=\"2\"") + Y("M83 88 87 112 115 122 126 102 121 80Z", "#d0a581") + Y("M73 45Q93 17 125 36L139 65 133 94 120 107 82 94 70 74Z", "#d0ac88") + Y("M73 61Q62 40 88 23L121 28 139 52 123 56 109 41 88 48 80 74Z", "#a7aaa1") + Y("M75 78 84 115 108 128 128 112 136 79 122 93 113 82 104 94 86 84Z", "#b4b3a3") + Y("M77 64h21v18H78Zm26 0h22v18h-21Zm-5 8h6", "none", "stroke=\"#5c502c\" stroke-width=\"3\"") + Y("M63 121 86 143 128 133 143 143 121 159 77 161 46 137Z", "#738299") + Y("M113 128 124 119 139 125 139 142 122 144Z", "#c5a27d") + J(125, 116, .25, At()) + Q("skill", 129, 124, 29) + Q("star", 148, 108, 16);
}
function Rt() {
	return X(0, 0, 200, 170, "#344651") + Y("M0 149 56 88 133 107 200 65V170H0Z", "#596a70") + Y("M36 170 53 111 88 94 127 97 160 121 170 170Z", "url(#metal)", "stroke=\"#26363e\" stroke-width=\"3\"") + Y("M77 87 78 106 106 122 133 100 125 76Z", "#b08b6b") + Y("M65 48 80 23 117 21 139 43 141 72 131 88 119 52 83 55 77 90 62 77Z", "url(#metal)", "stroke=\"#c6c5ad\" stroke-width=\"2\"") + Y("M85 53 119 50 125 77 110 100 89 87 78 69Z", "#c59c78") + Y("M82 74 93 92 111 104 126 91 129 72 116 80 97 76Z", "#6d5142") + Y("M89 64h9m12-2h10", "none", "stroke=\"#293b3e\" stroke-width=\"3\"") + Y("M41 116 70 108 91 136 70 161 36 145M144 116 173 121 178 149 149 155 126 137Z", "url(#metal)", "stroke=\"#9aa7a8\" stroke-width=\"2\"") + J(151, 81, 1.35, Q("sword", 0, 0, 100)) + Y("M80 119 118 164M117 117 76 169", "none", "stroke=\"#805a35\" stroke-width=\"7\"");
}
function zt() {
	return X(0, 0, 200, 170, "#3d4740") + Y("M0 147 49 134 135 135 200 149V170H0Z", "#5b6150") + J(100, 85, 2.5, Q("coin", 0, 0, 47)) + Q("star", 54, 42, 14) + Q("star", 149, 111, 11) + Y("M83 34Q114 22 134 47", "none", "stroke=\"#d7c995\" stroke-width=\"2\" opacity=\".5\"");
}
function Bt() {
	return X(0, 0, 200, 170, "#343e36") + Y("M33 170V56L52 41V28H149V42L167 57V170Z", "#69715a", "stroke=\"#a1a181\" stroke-width=\"2\"") + Y("M55 164V69Q100 8 145 69V164Z", "#1c2a25") + Y("M64 170 67 132H134L139 170Z", "#89846a") + Y("M63 130H138L130 142H70Z", "#b1a276") + J(101, 93, .7, Y("M-35-11-37-38-17-25 0-36 20-24 39-35 33-6 23 6 35 12 29 26 7 30-9 22-32 29-32 11-17 1Z", "#a28c56", "stroke=\"#d0bb7c\" stroke-width=\"2\"") + Y("M-13-10 1-17 19-8 6 1Z", "#1b2923") + Y("m-6-9 12 1-8 5Z", "#e8ac4b")) + Y("M35 56H53M148 56H166M35 89H53M148 89H166M35 120H53M148 120H166", "none", "stroke=\"#444e40\" stroke-width=\"3\"");
}
function Vt() {
	return X(0, 0, 200, 170, "#34434a") + Y("M20 122 64 77 107 102 58 157Z", "#bcae86", "stroke=\"#e2d3a4\" stroke-width=\"2\"") + Y("M59 145 88 77 127 95 102 159Z", "#516e78", "stroke=\"#e2d3a4\" stroke-width=\"2\"") + Y("M73 149 136 92 162 124 109 169Z", "#b9a685", "stroke=\"#e2d3a4\" stroke-width=\"2\"") + Y("M12 77 43 62 66 60 89 76 84 88 58 78 42 87 23 98Z", "#c89670", "stroke=\"#e0b48b\" stroke-width=\"2\"") + Y("M118 32 134 21 151 26 187 57 181 80 165 69 146 51 135 57 143 74 132 79 116 59Z", "#c89670", "stroke=\"#e0b48b\" stroke-width=\"2\"") + Q("skill", 104, 51, 30);
}
function Ht(e) {
	let t = e === "key" ? Y("M-25-32a18 18 0 1 0 0 36 18 18 0 0 0 0-36Zm0 10a8 8 0 1 1 0 16 8 8 0 0 1 0-16ZM-13-3 31 40 42 29 34 21 26 29 20 23 28 15 19 7 12 14-18-13Z", "url(#gold)") : e === "potion" ? Y("M-10-47H10V-21Q43-8 35 22 26 48-4 43-41 40-36 11-33-9-10-21Z", "#5b9c91", "stroke=\"#a1c7aa\" stroke-width=\"3\"") + X(-13, -53, 26, 13, "#9e7853") + Y("M-28 8Q-3 19 28 5V25Q5 46-22 28Z", "#c57c7e") : e === "map" ? Y("M-62-40-27-50 8-37 51-48 61 35 23 45-14 32-51 43Z", "#bfae7b", "stroke=\"#e1d3a4\" stroke-width=\"2\"") + Y("M-27-47-14 32M8-35 23 42M-32-18Q-2 30 33-10", "none", "stroke=\"#765e3e\" stroke-width=\"3\"") + Y("M22-17 42-4M39-20 26 1", "none", "stroke=\"#954a38\" stroke-width=\"4\"") : Y("M-33 52 14-40 26-35-20 60Z", "#9c8355", "stroke=\"#c3b783\" stroke-width=\"2\"") + J(21, -39, 1, Q("skill", 0, 0, 40)) + Q("star", -30, -21, 14) + Q("star", 42, 4, 10);
	return X(0, 0, 200, 170, "#36464a") + Y("M0 150 55 131 145 136 200 147V170H0Z", "#576256") + J(100, 87, 1.05, t);
}
function Ut() {
	return X(0, 0, 200, 170, "#34434a") + Y("M55 170 82 15M112 170 137 15M78 36 133 36M74 63H129M69 91H125M64 119H120M60 147H115", "none", "stroke=\"#ac9164\" stroke-width=\"7\" stroke-linecap=\"round\"") + Y("M80 18 57 165M135 18 113 165", "none", "stroke=\"#dbc59a\" stroke-width=\"2\"");
}
function Wt() {
	return X(0, 0, 200, 170, "#354b56") + Y("M0 128 38 106 80 120 143 96 200 116V170H0Z", "#62767a") + Y("M25 103 118 54 176 78 86 139Z", "#94636d", "stroke=\"#d7b46b\" stroke-width=\"4\"") + Y("M46 103 116 68 154 80 85 123Z", "#5a6582", "stroke=\"#b69964\" stroke-width=\"2\"") + Y("M72 101 110 82 132 85 98 108Z", "#c5b17b") + Y("M26 102 16 110M34 108 24 117M42 113 32 122M51 119 41 128M60 124 50 133M69 130 59 139M78 135 68 144", "none", "stroke=\"#cfb578\" stroke-width=\"2\"");
}
function Gt() {
	return X(0, 0, 200, 170, "#263e47") + Y("M58 170 55 102 74 81 128 81 149 103 147 170Z", "#487b91", "stroke=\"#a0d0d1\" stroke-width=\"2\"") + Y("M77 38 99 20 125 39 131 74 111 94 78 77 69 59Z", "#5e9bb0", "stroke=\"#a0d0d1\" stroke-width=\"2\"") + Y("M77 38 99 20 102 53 125 39 112 75 78 77 102 53Z", "#8dc8d1") + Y("M80 55 94 58 89 65ZM109 57 123 54 114 65Z", "#102f42") + Y("M64 101 28 112 20 152 43 165 77 128M139 101 170 108 186 143 166 160 127 125Z", "#66a3b2", "stroke=\"#a0d0d1\" stroke-width=\"2\"") + Y("M80 97 108 110 135 96 122 141 94 155 78 133Z", "#397189") + Q("skill", 108, 120, 32);
}
function Kt(e) {
	return e === "ladder" ? Ut() : e === "flying-carpet" ? Wt() : e === "crystal-golem" ? Gt() : [
		"sapphire",
		"emerald",
		"ruby",
		"diamond",
		"black-pearl",
		"dragons-eye"
	].includes(e) ? At(e === "emerald" ? "#35b27e" : e === "ruby" ? "#d44352" : e === "black-pearl" ? "#797599" : "#3999de") : [
		"boots-of-swiftness",
		"elven-boots",
		"burglars-boots",
		"climbing-gear"
	].includes(e) ? Ft() : e === "tome" ? Nt() : [
		"goblin",
		"kobold",
		"ogre",
		"ogre-grunt",
		"cave-troll",
		"watcher",
		"overlord"
	].includes(e) ? Pt() : [
		"singing-sword",
		"silver-spear",
		"elven-dagger",
		"pickaxe"
	].includes(e) ? Mt() : [
		"mercenary",
		"rebel-soldier",
		"rebel-captain",
		"the-duke",
		"the-mountain-king",
		"rebel-brawler"
	].includes(e) ? Rt() : [
		"sidestep",
		"scramble",
		"stumble",
		"sneak",
		"dead-run",
		"move-silently",
		"swagger"
	].includes(e) ? It(e) : [
		"gem-collector",
		"wizard",
		"invoker-of-the-ancients",
		"alchemist",
		"archaeologist"
	].includes(e) ? Lt() : [
		"dragon-shrine",
		"shrine",
		"the-vault",
		"animated-door"
	].includes(e) ? Bt() : [
		"sleight-of-hand",
		"brilliance",
		"bracers-of-agility",
		"search"
	].includes(e) ? Vt() : [
		"lucky-coin",
		"treasure-hunter",
		"underworld-dealing",
		"coin-purse"
	].includes(e) ? zt() : ["treasure-map", "grand-plan"].includes(e) ? Ht("map") : [
		"apothecary",
		"medic",
		"amulet-of-vigor",
		"crystal-fish"
	].includes(e) ? Ht("potion") : e.includes("wand") || e.includes("scepter") || e === "teleporter" ? Ht("wand") : e.includes("key") ? Ht("key") : jt(e === "burgle");
}
function qt(e) {
	return { __html: e.replaceAll("id=\"", "id=\"clank-art-").replaceAll("url(#", "url(#clank-art-").replaceAll("href=\"#", "href=\"#clank-art-") };
}
function Jt() {
	return /* @__PURE__ */ m("svg", {
		className: "clank-art-defs",
		width: "0",
		height: "0",
		"aria-hidden": !0,
		children: /* @__PURE__ */ m("g", { dangerouslySetInnerHTML: qt(bt) })
	});
}
function Yt({ kind: e, size: t = 20 }) {
	return /* @__PURE__ */ m("svg", {
		className: "clank-symbol",
		width: t,
		height: t,
		viewBox: "0 0 36 36",
		"aria-hidden": !0,
		children: /* @__PURE__ */ m("use", {
			href: `#clank-art-${e}`,
			x: "2",
			y: "2",
			width: "32",
			height: "32"
		})
	});
}
function Xt({ index: e, color: t, size: n = 32 }) {
	return /* @__PURE__ */ m("svg", {
		width: n,
		height: n,
		viewBox: "-52 -52 104 104",
		"aria-hidden": !0,
		dangerouslySetInnerHTML: qt(Ct(e % 4, 0, 0, 50, t))
	});
}
function Zt({ color: e }) {
	return /* @__PURE__ */ m("g", {
		className: "clank-figure",
		dangerouslySetInnerHTML: qt(St(e))
	});
}
function Qt({ angry: e = !1 }) {
	return /* @__PURE__ */ m("svg", {
		className: "clank-dragon-art",
		viewBox: "0 0 260 225",
		"aria-hidden": !0,
		dangerouslySetInnerHTML: qt(wt(0, 0, 1, e))
	});
}
function $t({ depth: e = 700 }) {
	return /* @__PURE__ */ m("g", {
		className: "clank-terrain",
		transform: `translate(0 ${e - 700})`,
		dangerouslySetInnerHTML: qt(Tt())
	});
}
function en({ room: e, contents: t, selected: n, reachable: r }) {
	let i = {
		...e,
		artifact: t.artifacts[0],
		idols: t.idols.length,
		major: e.major ? t.secrets : 0,
		minor: e.major ? 0 : t.secrets
	};
	return /* @__PURE__ */ m("g", { dangerouslySetInnerHTML: qt(kt(i, n, r, -1, t.idols)) });
}
function tn({ kind: e }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 200 170",
		"aria-hidden": !0,
		dangerouslySetInnerHTML: qt(Kt(e))
	});
}
//#endregion
//#region src/games/clank/i18n-keys.ts
var $ = {
	guide_symbols: "games.clank.guide.symbols",
	name: "games.clank.name",
	desc: "games.clank.desc",
	errorAction: "games.clank.errorAction",
	ui_moveDamage: "games.clank.ui.moveDamage",
	ui_overview: "games.clank.ui.overview",
	ui_locate: "games.clank.ui.locate",
	ui_mapTools: "games.clank.ui.mapTools",
	ui_dragonAttack: "games.clank.ui.dragonAttack",
	ui_blackCube: "games.clank.ui.blackCube",
	ui_danger: "games.clank.ui.danger",
	ui_cancel: "games.clank.ui.cancel",
	ui_close: "games.clank.ui.close",
	ui_chooseMove: "games.clank.ui.chooseMove",
	ui_playHand: "games.clank.ui.playHand",
	ui_selectMove: "games.clank.ui.selectMove",
	ui_noisePool: "games.clank.ui.noisePool",
	ui_turn: "games.clank.ui.turn",
	ui_yourTurn: "games.clank.ui.yourTurn",
	ui_waiting: "games.clank.ui.waiting",
	ui_resolving: "games.clank.ui.resolving",
	ui_intermission: "games.clank.ui.intermission",
	ui_continue: "games.clank.ui.continue",
	ui_hand: "games.clank.ui.hand",
	ui_played: "games.clank.ui.played",
	ui_dungeon: "games.clank.ui.dungeon",
	ui_supplies: "games.clank.ui.supplies",
	ui_actions: "games.clank.ui.actions",
	ui_inspect: "games.clank.ui.inspect",
	ui_confirm: "games.clank.ui.confirm",
	ui_end: "games.clank.ui.end",
	ui_play: "games.clank.ui.play",
	ui_acquire: "games.clank.ui.acquire",
	ui_defeat: "games.clank.ui.defeat",
	ui_artifact: "games.clank.ui.artifact",
	ui_market: "games.clank.ui.market",
	ui_mine: "games.clank.ui.mine",
	ui_cache: "games.clank.ui.cache",
	ui_rotate: "games.clank.ui.rotate",
	ui_potion: "games.clank.ui.potion",
	ui_spring: "games.clank.ui.spring",
	ui_move: "games.clank.ui.move",
	ui_room: "games.clank.ui.room",
	ui_moveCost: "games.clank.ui.moveCost",
	ui_skill: "games.clank.ui.skill",
	ui_swords: "games.clank.ui.swords",
	ui_boots: "games.clank.ui.boots",
	ui_health: "games.clank.ui.health",
	ui_gold: "games.clank.ui.gold",
	ui_clank: "games.clank.ui.clank",
	ui_bag: "games.clank.ui.bag",
	ui_rage: "games.clank.ui.rage",
	ui_deck: "games.clank.ui.deck",
	ui_discard: "games.clank.ui.discard",
	ui_log: "games.clank.ui.log",
	ui_player: "games.clank.ui.player",
	ui_secrets: "games.clank.ui.secrets",
	ui_idols: "games.clank.ui.idols",
	ui_water: "games.clank.ui.water",
	ui_cave: "games.clank.ui.cave",
	ui_deep: "games.clank.ui.deep",
	ui_surface: "games.clank.ui.surface",
	ui_entrance: "games.clank.ui.entrance",
	ui_web: "games.clank.ui.web",
	ui_curse: "games.clank.ui.curse",
	ui_apparatus: "games.clank.ui.apparatus",
	ui_remaining: "games.clank.ui.remaining",
	ui_cost: "games.clank.ui.cost",
	ui_points: "games.clank.ui.points",
	ui_onePoint: "games.clank.ui.onePoint",
	ui_inspectCard: "games.clank.ui.inspectCard",
	ui_noAction: "games.clank.ui.noAction",
	ui_choose: "games.clank.ui.choose",
	ui_take: "games.clank.ui.take",
	ui_skip: "games.clank.ui.skip",
	ui_zoomIn: "games.clank.ui.zoomIn",
	ui_zoomOut: "games.clank.ui.zoomOut",
	ui_resetMap: "games.clank.ui.resetMap",
	ui_map: "games.clank.ui.map",
	ui_countdown: "games.clank.ui.countdown",
	ui_mummy: "games.clank.ui.mummy",
	ui_escaped: "games.clank.ui.escaped",
	ui_knocked: "games.clank.ui.knocked",
	ui_active: "games.clank.ui.active",
	ui_firstGame: "games.clank.ui.firstGame",
	ui_campaignBonus: "games.clank.ui.campaignBonus",
	ui_noScore: "games.clank.ui.noScore",
	ui_details: "games.clank.ui.details",
	ui_reveal: "games.clank.ui.reveal",
	ui_spendBoots: "games.clank.ui.spendBoots",
	ui_spendSwords: "games.clank.ui.spendSwords",
	ui_spendGold: "games.clank.ui.spendGold",
	ui_makeClank: "games.clank.ui.makeClank",
	ui_gainCurse: "games.clank.ui.gainCurse",
	ui_handCount: "games.clank.ui.handCount",
	ui_deckCount: "games.clank.ui.deckCount",
	ui_bagCount: "games.clank.ui.bagCount",
	ui_noiseCount: "games.clank.ui.noiseCount",
	ui_curseCount: "games.clank.ui.curseCount",
	ui_healthCount: "games.clank.ui.healthCount",
	ui_goldCount: "games.clank.ui.goldCount",
	ui_artifactValues: "games.clank.ui.artifactValues",
	ui_idolValues: "games.clank.ui.idolValues",
	ui_secretCount: "games.clank.ui.secretCount",
	ui_none: "games.clank.ui.none",
	ui_websCollected: "games.clank.ui.websCollected",
	ui_openDungeon: "games.clank.ui.openDungeon",
	ui_openActions: "games.clank.ui.openActions",
	ui_moveSeparator: "games.clank.ui.moveSeparator",
	ui_inventory: "games.clank.ui.inventory",
	ui_suppliesCount: "games.clank.ui.suppliesCount",
	options_expansions: "games.clank.options.expansions",
	options_sunken: "games.clank.options.sunken",
	options_mummy: "games.clank.options.mummy",
	options_goldSilk: "games.clank.options.goldSilk",
	options_apeLords: "games.clank.options.apeLords",
	options_promo: "games.clank.options.promo",
	options_campaign: "games.clank.options.campaign",
	options_map: "games.clank.options.map",
	maps_baseFront: "games.clank.maps.baseFront",
	maps_baseBack: "games.clank.maps.baseBack",
	maps_sunkenBoat: "games.clank.maps.sunkenBoat",
	maps_sunkenSewer: "games.clank.maps.sunkenSewer",
	maps_mummyPyramid: "games.clank.maps.mummyPyramid",
	maps_mummySphinx: "games.clank.maps.mummySphinx",
	maps_spiderLair: "games.clank.maps.spiderLair",
	maps_dwarvenMine: "games.clank.maps.dwarvenMine",
	maps_jungle: "games.clank.maps.jungle",
	maps_temple: "games.clank.maps.temple",
	items_key: "games.clank.items.key",
	items_backpack: "games.clank.items.backpack",
	items_crown: "games.clank.items.crown",
	items_scuba: "games.clank.items.scuba",
	items_ankh: "games.clank.items.ankh",
	items_timeWinder: "games.clank.items.timeWinder",
	items_heal1: "games.clank.items.heal1",
	items_heal2: "games.clank.items.heal2",
	items_boots: "games.clank.items.boots",
	items_swords: "games.clank.items.swords",
	items_heroism: "games.clank.items.heroism",
	items_goblin: "games.clank.items.goblin",
	items_goldfish: "games.clank.items.goldfish",
	items_mummyGold: "games.clank.items.mummyGold",
	items_mummyCleanse: "games.clank.items.mummyCleanse",
	items_guardian: "games.clank.items.guardian",
	items_cog: "games.clank.items.cog",
	items_wrench: "games.clank.items.wrench",
	items_banana: "games.clank.items.banana",
	items_gold2: "games.clank.items.gold2",
	items_gold5: "games.clank.items.gold5",
	items_skill2: "games.clank.items.skill2",
	items_skill5: "games.clank.items.skill5",
	items_draw3: "games.clank.items.draw3",
	items_chalice: "games.clank.items.chalice",
	items_spring: "games.clank.items.spring",
	items_egg: "games.clank.items.egg",
	items_scarab: "games.clank.items.scarab",
	items_mummyChalice: "games.clank.items.mummyChalice",
	choice_discard: "games.clank.choice.discard",
	choice_trash: "games.clank.choice.trash",
	choice_teleport: "games.clank.choice.teleport",
	choice_adjacent: "games.clank.choice.adjacent",
	choice_acquire: "games.clank.choice.acquire",
	choice_replace: "games.clank.choice.replace",
	choice_recall: "games.clank.choice.recall",
	choice_peek: "games.clank.choice.peek",
	choice_entry: "games.clank.choice.entry",
	choice_snack: "games.clank.choice.snack",
	choice_organ: "games.clank.choice.organ",
	choice_choose: "games.clank.choice.choose",
	choice_top: "games.clank.choice.top",
	choice_bottom: "games.clank.choice.bottom",
	choice_pay: "games.clank.choice.pay",
	choice_skip: "games.clank.choice.skip",
	choice_take: "games.clank.choice.take",
	choice_attack: "games.clank.choice.attack",
	choice_waterTeleport: "games.clank.choice.waterTeleport",
	choice_tomePaid: "games.clank.choice.tomePaid",
	choice_up: "games.clank.choice.up",
	choice_down: "games.clank.choice.down",
	choice_gain: "games.clank.choice.gain",
	choice_remove: "games.clank.choice.remove",
	choice_gear: "games.clank.choice.gear",
	choice_cache: "games.clank.choice.cache",
	score_artifacts: "games.clank.score.artifacts",
	score_gold: "games.clank.score.gold",
	score_cards: "games.clank.score.cards",
	score_tokens: "games.clank.score.tokens",
	score_market: "games.clank.score.market",
	score_mastery: "games.clank.score.mastery",
	score_curses: "games.clank.score.curses",
	score_mining: "games.clank.score.mining",
	score_apparatus: "games.clank.score.apparatus",
	score_campaign: "games.clank.score.campaign",
	score_total: "games.clank.score.total",
	events_play: "games.clank.events.play",
	events_move: "games.clank.events.move",
	events_acquire: "games.clank.events.acquire",
	events_defeat: "games.clank.events.defeat",
	events_artifact: "games.clank.events.artifact",
	events_secret: "games.clank.events.secret",
	events_market: "games.clank.events.market",
	events_mine: "games.clank.events.mine",
	events_web: "games.clank.events.web",
	events_rotate: "games.clank.events.rotate",
	events_dragon: "games.clank.events.dragon",
	events_damage: "games.clank.events.damage",
	events_escape: "games.clank.events.escape",
	events_knockout: "games.clank.events.knockout",
	events_mummy: "games.clank.events.mummy",
	events_round: "games.clank.events.round",
	events_campaign: "games.clank.events.campaign",
	events_rotatePlayer: "games.clank.events.rotatePlayer",
	guide_cache: "games.clank.guide.cache",
	guide_cacheText: "games.clank.guide.cacheText",
	guide_cache1: "games.clank.guide.cache1",
	guide_cache2: "games.clank.guide.cache2",
	guide_cache3: "games.clank.guide.cache3",
	guide_cache4: "games.clank.guide.cache4",
	guide_cache5: "games.clank.guide.cache5",
	guide_cache6: "games.clank.guide.cache6",
	guide_cache7: "games.clank.guide.cache7",
	guide_cache8: "games.clank.guide.cache8",
	rules: "games.clank.rules",
	action_play: "games.clank.action.play",
	action_acquire: "games.clank.action.acquire",
	action_defeat: "games.clank.action.defeat",
	action_market: "games.clank.action.market",
	action_guardian: "games.clank.action.guardian",
	action_mummyGold: "games.clank.action.mummyGold",
	action_mummyCleanse: "games.clank.action.mummyCleanse",
	action_mine: "games.clank.action.mine",
	action_rotate: "games.clank.action.rotate",
	action_potion: "games.clank.action.potion",
	action_spring: "games.clank.action.spring",
	action_discard: "games.clank.action.discard",
	action_trash: "games.clank.action.trash",
	action_recall: "games.clank.action.recall",
	action_teleport: "games.clank.action.teleport",
	action_adjacent: "games.clank.action.adjacent",
	action_replace: "games.clank.action.replace",
	action_freeAcquire: "games.clank.action.freeAcquire",
	resource_skill: "games.clank.resource.skill",
	resource_swords: "games.clank.resource.swords",
	resource_boots: "games.clank.resource.boots",
	resource_gold: "games.clank.resource.gold",
	resource_clank: "games.clank.resource.clank",
	resource_curse: "games.clank.resource.curse",
	resource_oneCurse: "games.clank.resource.oneCurse",
	resource_heal: "games.clank.resource.heal",
	resource_makeClank: "games.clank.resource.makeClank"
};
//#endregion
//#region src/games/clank/scene.tsx
function nn({ pub: e, actions: t, members: n, myRid: r, selectedRoom: a, onRoom: c }) {
	let u = d(), f = W[e.map], p = o(null), g = o(null), [_, v] = s({
		width: 375,
		height: 594
	}), [y, w] = s(null), [T, E] = s(!1), D = o(null), O = o(/* @__PURE__ */ new Map()), k = o(0), A = o(null);
	i(() => {
		let e = new ResizeObserver(([e]) => v({
			width: e.contentRect.width,
			height: e.contentRect.height
		}));
		return e.observe(p.current), () => e.disconnect();
	}, []);
	let j = f.rooms[e.players.find((e) => e.rid === r)?.room ?? 0], M = _.height / Math.max(1, _.width), N = Math.max(.82, Math.min(1.15, Math.min(_.width, _.height) / 600)), ee = _.width / N, P = Math.min(...f.rooms.map((e) => e.x)) - 100, te = Math.max(...f.rooms.map((e) => e.x)) + 100, F = Math.min(...f.rooms.map((e) => e.y)) - 90, I = Math.max(...f.rooms.map((e) => e.y)) + 100, L = (e, t, n, r) => r >= n - t ? (t + n - r) / 2 : Math.max(t, Math.min(n - r, e)), R = y === "overview" ? Math.max(te - P, (I - F) / M) : ee / (y?.zoom ?? 1), z = y === "overview" ? {
		x: (P + te - R) / 2,
		y: (F + I - R * M) / 2,
		width: R
	} : y ? {
		x: y.x - R / 2,
		y: y.y - R * M / 2,
		width: R
	} : {
		x: L(j.x - R * .42, P, te, R),
		y: L(j.y - R * M * .34, F, I, R * M),
		width: R
	}, B = (e) => w(() => {
		let t = Math.max(340, Math.min(2e3, z.width * e));
		return {
			x: z.x + z.width / 2,
			y: z.y + z.width * M / 2,
			zoom: ee / t
		};
	}), V = () => w("overview"), ne = new Set(t.flatMap((e) => e.type === "move" ? [e.to] : e.type === "resolve" && ["teleport", "adjacent"].includes(e.option) && e.target !== void 0 ? [e.target] : [])), re = new Set(t.flatMap((e) => e.type === "move" && e.to === a ? [e.tunnel] : [])), ie = f.family === "sunken" ? 650 : f.id === "jungle" ? 680 : f.id === "dwarven-mine" ? 730 : 700, ae = (e) => {
		A.current?.moved || c(e);
	};
	return /* @__PURE__ */ h("div", {
		ref: p,
		className: "clank-map-viewport",
		"data-family": f.family,
		children: [
			/* @__PURE__ */ h("svg", {
				ref: g,
				viewBox: `${z.x} ${z.y} ${z.width} ${z.width * M}`,
				role: "group",
				"aria-label": u(Ce[e.map]),
				className: "clank-map-svg",
				onWheel: (e) => B(e.deltaY > 0 ? 1.12 : .89),
				onPointerDown: (e) => {
					if (O.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					}), O.current.size === 1) A.current = {
						x: e.clientX,
						y: e.clientY,
						box: z,
						moved: !1
					};
					else {
						let [e, t] = [...O.current.values()];
						k.current = Math.hypot(e.x - t.x, e.y - t.y);
					}
				},
				onPointerMove: (e) => {
					if (!O.current.has(e.pointerId)) return;
					if (O.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					}), O.current.size >= 2) {
						let [e, t] = [...O.current.values()], n = Math.hypot(e.x - t.x, e.y - t.y);
						k.current && B(k.current / Math.max(1, n)), k.current = n, A.current && (A.current.moved = !0);
						return;
					}
					if (!A.current) return;
					let t = e.clientX - A.current.x, n = e.clientY - A.current.y;
					if (Math.hypot(t, n) < 5 && !A.current.moved) return;
					A.current.moved || e.currentTarget.setPointerCapture(e.pointerId), A.current.moved = !0;
					let r = A.current.box.width / Math.max(1, g.current.getBoundingClientRect().width), i = A.current.box;
					w({
						x: i.x - t * r + i.width / 2,
						y: i.y - n * r + i.width * M / 2,
						zoom: ee / i.width
					});
				},
				onPointerUp: (e) => {
					O.current.delete(e.pointerId), k.current = 0, A.current?.moved && (e.preventDefault(), setTimeout(() => {
						A.current = null;
					}, 0));
				},
				onPointerCancel: (e) => {
					O.current.delete(e.pointerId), A.current = null, k.current = 0;
				},
				children: [
					/* @__PURE__ */ m("rect", {
						x: "-4000",
						y: "-4000",
						width: "10000",
						height: "10000",
						fill: "#293129"
					}),
					/* @__PURE__ */ m($t, { depth: ie }),
					f.gears?.map((e) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
						cx: e.x,
						cy: e.y,
						r: "69",
						fill: "#685a36",
						stroke: "#b59b63",
						strokeWidth: "4",
						strokeDasharray: "9 5"
					}), /* @__PURE__ */ h("text", {
						x: e.x,
						y: e.y + 7,
						textAnchor: "middle",
						fill: "#d6c695",
						fontSize: "24",
						children: ["⚙", e.id + 1]
					})] }, e.id)),
					f.tunnels.map((t) => {
						let n = Te(e, t);
						if (!n) return null;
						let r = f.rooms[n.a], i = f.rooms[n.b], a = n.gear && f.gears.find((e) => e.id === n.gear.id), o = a ? a.x : (r.x + i.x) / 2, s = a ? a.y : (r.y + i.y) / 2, c = a ? `M${r.x} ${r.y}Q${o} ${s} ${i.x} ${i.y}` : `M${r.x} ${r.y}C${r.x} ${s + 8} ${i.x} ${s - 8} ${i.x} ${i.y}`, l = re.has(n.id), u = [
							n.locked && ["lock", 0],
							(n.boots ?? 1) > 1 && ["boot", n.boots],
							n.monsters && ["monster", n.monsters],
							n.curse && ["curse", n.curse],
							n.clank && ["noise", n.clank],
							n.elevator && ["coin", 1],
							e.webs.includes(n.id) && ["web", 0]
						].filter(Boolean), d = e.apparatus.find((e) => e.tunnel === n.id)?.kind, p = (e, t) => /* @__PURE__ */ h("g", { children: [u.map(([n, r], i) => /* @__PURE__ */ h("g", {
							transform: `translate(${e + (i - (u.length - 1) / 2) * 34} ${t})`,
							children: [
								/* @__PURE__ */ m("circle", {
									r: "17",
									fill: "#d5c7a4",
									stroke: "#413e2d",
									strokeWidth: "1.2"
								}),
								[
									"boot",
									"monster",
									"lock",
									"coin"
								].includes(n) ? /* @__PURE__ */ m("g", {
									className: "clank-route-icon",
									children: /* @__PURE__ */ m("use", {
										href: `#clank-art-${n}`,
										x: "-13",
										y: "-13",
										width: "26",
										height: "26"
									})
								}) : /* @__PURE__ */ m("text", {
									y: "7",
									textAnchor: "middle",
									fontSize: "22",
									fill: "#302d23",
									children: n === "curse" ? "☠" : n === "noise" ? "!" : "🕸"
								}),
								r > 1 && /* @__PURE__ */ m("text", {
									x: "14",
									y: "16",
									className: "clank-route-count",
									children: r
								})
							]
						}, `${n}:${i}`)), d && /* @__PURE__ */ m("text", {
							x: e,
							y: t + 42,
							fontSize: "23",
							textAnchor: "middle",
							children: d === "banana" ? "🍌" : d === "wrench" ? "🔧" : "⚙"
						})] });
						return n.wrap ? /* @__PURE__ */ m("g", { children: [[r, i], [i, r]].map(([e, t]) => {
							let n = e.x < t.x ? P : te, r = (e.x + n) / 2;
							return /* @__PURE__ */ h("g", { children: [
								/* @__PURE__ */ m("path", {
									d: `M${e.x} ${e.y}H${n}`,
									fill: "none",
									stroke: l ? "#edd079" : "#a7a081",
									strokeWidth: l ? 6 : 3.2
								}),
								/* @__PURE__ */ h("text", {
									x: n,
									y: e.y - 25,
									textAnchor: e.x < t.x ? "start" : "end",
									fill: "#e5d4a6",
									fontSize: "20",
									children: ["↔ ", t.id]
								}),
								p(r, e.y)
							] }, e.id);
						}) }, n.id) : /* @__PURE__ */ h("g", {
							className: "clank-tunnel",
							"data-selected": l,
							children: [
								/* @__PURE__ */ m("path", {
									d: c,
									fill: "none",
									stroke: "#121b16",
									strokeWidth: l ? 12 : 7,
									opacity: ".6"
								}),
								/* @__PURE__ */ m("path", {
									d: c,
									fill: "none",
									stroke: l ? "#edd079" : "#a7a081",
									strokeWidth: l ? 6 : 3.2,
									strokeOpacity: l ? 1 : .66
								}),
								n.oneWay && /* @__PURE__ */ m("path", {
									d: "M-12-6 0-3V-10L13 0 0 10V3L-12 6Z",
									fill: "#c5bc97",
									transform: `translate(${o} ${s - (u.length ? 27 : 0)}) rotate(${Math.atan2(i.y - r.y, i.x - r.x) * 180 / Math.PI})`
								}),
								p(o, s)
							]
						}, n.id);
					}),
					f.rooms.map((t) => /* @__PURE__ */ h("g", {
						className: "clank-room",
						"data-selected": a === t.id,
						role: "button",
						tabIndex: 0,
						"aria-label": `${u($.ui_room, { n: t.id })}${ne.has(t.id) ? ` · ${u($.ui_move, { n: t.id })}` : ""}`,
						onClick: () => ae(t.id),
						onKeyDown: (e) => {
							(e.key === "Enter" || e.key === " ") && (e.preventDefault(), c(t.id));
						},
						children: [
							/* @__PURE__ */ m("title", { children: `${u($.ui_room, { n: t.id })} · ${u(t.deep ? $.ui_deep : $.ui_surface)}${t.water ? ` · ${u($.ui_water)}` : ""}${t.cave ? ` · ${u($.ui_cave)}` : ""}` }),
							/* @__PURE__ */ m(en, {
								room: t,
								contents: e.rooms[t.id],
								selected: a === t.id,
								reachable: ne.has(t.id)
							}),
							t.water && /* @__PURE__ */ m("path", {
								d: `M${t.x - 53} ${t.y + 30}q13-6 26 0t26 0t26 0t26 0`,
								stroke: "#68c2ca",
								strokeWidth: "5",
								fill: "none"
							}),
							t.id === 0 && /* @__PURE__ */ m("g", {
								transform: `translate(${t.x} ${t.y - 5})`,
								children: /* @__PURE__ */ m("path", {
									d: "M-13 20V-25H13L6-14H-13",
									fill: "#cfbc7c",
									stroke: "#e4d5a5",
									strokeWidth: "2"
								})
							}),
							t.gold && /* @__PURE__ */ h("g", {
								transform: `translate(${t.x + 39} ${t.y + 25})`,
								children: [/* @__PURE__ */ m("use", {
									href: "#clank-art-coin",
									x: "-14",
									y: "-14",
									width: "28",
									height: "28"
								}), /* @__PURE__ */ m("text", {
									x: "17",
									y: "6",
									className: "clank-route-count",
									children: t.gold
								})]
							}),
							t.webbed && /* @__PURE__ */ m("text", {
								x: t.x - 64,
								y: t.y - 25,
								fontSize: "24",
								children: "🕸"
							}),
							t.zone !== void 0 && /* @__PURE__ */ h("text", {
								x: t.x + 49,
								y: t.y - 40,
								fill: "#d8b77b",
								fontSize: "18",
								children: [e.mummy === t.zone ? "☠ " : "", t.zone]
							})
						]
					}, t.id)),
					f.mines?.map((t) => /* @__PURE__ */ h("g", {
						onClick: () => ae(t.rooms[0]),
						children: [/* @__PURE__ */ m("rect", {
							x: t.x - 25,
							y: t.y - 15,
							width: "50",
							height: "30",
							rx: "4",
							fill: e.mines.some((e) => e.mine === t.id) ? "#6d6c53" : "#c9ad69",
							stroke: "#84713f"
						}), /* @__PURE__ */ h("text", {
							x: t.x,
							y: t.y + 6,
							textAnchor: "middle",
							fontSize: "19",
							children: ["⛏", t.gold]
						})]
					}, t.id)),
					e.players.map((t, i) => {
						let a = f.rooms[t.room], o = n.find((e) => e.rid === t.rid), s = l[o?.colorIndex ?? i].hex, c = e.players.filter((e) => e.room === t.room), u = (c.findIndex((e) => e.rid === t.rid) - (c.length - 1) / 2) * 28;
						return /* @__PURE__ */ h("g", {
							className: "clank-pawn",
							"data-out": t.state !== "active",
							style: { transform: `translate(${a.x + u}px, ${a.y + 13}px)` },
							children: [
								/* @__PURE__ */ m("title", { children: o?.name ?? t.rid }),
								/* @__PURE__ */ m(Zt, { color: s }),
								t.rid === r && /* @__PURE__ */ m("path", {
									d: "M-7-42 0-33 7-42Z",
									fill: "#f1df9c"
								})
							]
						}, t.rid);
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "clank-map-tools",
				onKeyDown: (e) => {
					e.key === "Escape" && (E(!1), D.current?.focus());
				},
				children: [
					T && /* @__PURE__ */ h("div", {
						id: "clank-map-controls",
						className: "clank-map-tools-panel",
						role: "group",
						"aria-label": u($.ui_mapTools),
						children: [
							/* @__PURE__ */ m("button", {
								type: "button",
								"aria-label": u($.ui_zoomIn),
								title: u($.ui_zoomIn),
								onClick: () => B(.8),
								children: /* @__PURE__ */ m(S, { size: 20 })
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								"aria-label": u($.ui_zoomOut),
								title: u($.ui_zoomOut),
								onClick: () => B(1.25),
								children: /* @__PURE__ */ m(C, { size: 20 })
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => {
									V(), E(!1);
								},
								children: u($.ui_overview)
							})
						]
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						ref: D,
						"aria-label": u($.ui_mapTools),
						title: u($.ui_mapTools),
						"aria-expanded": T,
						"aria-controls": T ? "clank-map-controls" : void 0,
						onClick: () => E(!T),
						children: /* @__PURE__ */ m(x, { size: 21 })
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						"aria-label": u($.ui_locate),
						title: u($.ui_locate),
						onClick: () => {
							w(null), E(!1);
						},
						children: /* @__PURE__ */ m(b, { size: 21 })
					})
				]
			}),
			e.phase === "dragon" && /* @__PURE__ */ h("div", {
				className: "clank-dragon-event",
				role: "status",
				children: [/* @__PURE__ */ m("strong", { children: u($.ui_dragonAttack) }), /* @__PURE__ */ m("div", { children: e.lastDraw.map((t, r) => {
					let i = n.find((e) => e.rid === t);
					return /* @__PURE__ */ m("span", {
						className: "clank-drawn-cube",
						style: { color: t === "black" ? "#343c36" : l[i?.colorIndex ?? 0].hex },
						title: t === "black" ? u($.ui_blackCube) : i?.name,
						children: /* @__PURE__ */ m(Yt, {
							kind: "cube",
							size: 28
						})
					}, `${e.turnNumber}:${r}`);
				}) })]
			})
		]
	});
}
//#endregion
//#region src/games/clank/board.tsx
function rn({ pub: e, gearId: t, orientation: n }) {
	let r = W[e.map].gears.find((e) => e.id === t), i = ce[e.gears.find((e) => e.id === t).piece], a = (e, t) => {
		let r = (e + n) / i.sides * 2 * Math.PI - Math.PI / 2;
		return [100 + Math.cos(r) * t, 100 + Math.sin(r) * t];
	};
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 200 200",
		className: "clank-gear-preview",
		children: [
			/* @__PURE__ */ m("polygon", {
				points: r.ports.map((e, t) => a(t - n, 90).join(",")).join(" "),
				fill: "#dabd7b",
				stroke: "#795331",
				strokeWidth: "4"
			}),
			i.routes.map((e, t) => {
				let n = a(e.a, 85), r = a(e.b, 85);
				return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("path", {
					d: `M${n} Q100 100 ${r}`,
					stroke: "#785735",
					strokeWidth: "10",
					fill: "none"
				}), /* @__PURE__ */ m("text", {
					x: (n[0] + r[0]) / 2,
					y: (n[1] + r[1]) / 2,
					fontSize: "16",
					children: e.locked ? "🔒" : e.monsters ? `⚔${e.monsters}` : e.boots ? `🥾${e.boots}` : ""
				})] }, t);
			}),
			r.ports.map((e, t) => {
				let r = a(t - n, 72);
				return /* @__PURE__ */ m("text", {
					x: r[0],
					y: r[1],
					textAnchor: "middle",
					fontSize: "18",
					fontWeight: "bold",
					children: e
				}, e);
			}),
			/* @__PURE__ */ m("text", {
				x: "100",
				y: "110",
				textAnchor: "middle",
				fontSize: "22",
				children: i.symbol === "cog" ? "⚙" : i.symbol === "banana" ? "🍌" : "🔧"
			})
		]
	});
}
//#endregion
//#region src/games/clank/sheet.tsx
function an(e) {
	let t = o(null), { open: n, onClose: r, title: a } = e;
	return i(() => {
		if (!n) return;
		let e = document.activeElement, i = () => [...t.current?.querySelectorAll(".bottom-sheet__panel button:not(:disabled), .bottom-sheet__panel summary, .bottom-sheet__panel [href], .bottom-sheet__panel [tabindex=\"0\"]") ?? []].filter((e) => e.getClientRects().length), a = requestAnimationFrame(() => i()[0]?.focus({ preventScroll: !0 })), o = (e) => {
			if (e.key === "Escape" && r && (e.preventDefault(), r()), e.key !== "Tab") return;
			let t = i(), n = t.indexOf(document.activeElement);
			if (!t.length) {
				e.preventDefault();
				return;
			}
			e.shiftKey && n <= 0 ? (e.preventDefault(), t.at(-1)?.focus()) : !e.shiftKey && (n === -1 || n === t.length - 1) && (e.preventDefault(), t[0].focus());
		};
		return document.addEventListener("keydown", o), () => {
			cancelAnimationFrame(a), document.removeEventListener("keydown", o), e?.focus({ preventScroll: !0 });
		};
	}, [
		n,
		r,
		a
	]), /* @__PURE__ */ m("div", {
		ref: t,
		className: "clank-sheet",
		children: /* @__PURE__ */ m(w, { ...e })
	});
}
//#endregion
//#region src/games/clank/card-keys.ts
var on = {
	burgle: {
		name: "games.clank.cards.burgle.name",
		text: "games.clank.cards.burgle.text"
	},
	scramble: {
		name: "games.clank.cards.scramble.name",
		text: "games.clank.cards.scramble.text"
	},
	sidestep: {
		name: "games.clank.cards.sidestep.name",
		text: "games.clank.cards.sidestep.text"
	},
	stumble: {
		name: "games.clank.cards.stumble.name",
		text: "games.clank.cards.stumble.text"
	},
	explore: {
		name: "games.clank.cards.explore.name",
		text: "games.clank.cards.explore.text"
	},
	mercenary: {
		name: "games.clank.cards.mercenary.name",
		text: "games.clank.cards.mercenary.text"
	},
	tome: {
		name: "games.clank.cards.tome.name",
		text: "games.clank.cards.tome.text"
	},
	"amulet-of-vigor": {
		name: "games.clank.cards.amulet-of-vigor.name",
		text: "games.clank.cards.amulet-of-vigor.text"
	},
	"animated-door": {
		name: "games.clank.cards.animated-door.name",
		text: "games.clank.cards.animated-door.text"
	},
	apothecary: {
		name: "games.clank.cards.apothecary.name",
		text: "games.clank.cards.apothecary.text"
	},
	archaeologist: {
		name: "games.clank.cards.archaeologist.name",
		text: "games.clank.cards.archaeologist.text"
	},
	blecher: {
		name: "games.clank.cards.blecher.name",
		text: "games.clank.cards.blecher.text"
	},
	"boots-of-swiftness": {
		name: "games.clank.cards.boots-of-swiftness.name",
		text: "games.clank.cards.boots-of-swiftness.text"
	},
	"bracers-of-agility": {
		name: "games.clank.cards.bracers-of-agility.name",
		text: "games.clank.cards.bracers-of-agility.text"
	},
	brilliance: {
		name: "games.clank.cards.brilliance.name",
		text: "games.clank.cards.brilliance.text"
	},
	"cave-troll": {
		name: "games.clank.cards.cave-troll.name",
		text: "games.clank.cards.cave-troll.text"
	},
	"cleric-of-the-sun": {
		name: "games.clank.cards.cleric-of-the-sun.name",
		text: "games.clank.cards.cleric-of-the-sun.text"
	},
	"crystal-golem": {
		name: "games.clank.cards.crystal-golem.name",
		text: "games.clank.cards.crystal-golem.text"
	},
	"dead-run": {
		name: "games.clank.cards.dead-run.name",
		text: "games.clank.cards.dead-run.text"
	},
	diamond: {
		name: "games.clank.cards.diamond.name",
		text: "games.clank.cards.diamond.text"
	},
	"dragon-shrine": {
		name: "games.clank.cards.dragon-shrine.name",
		text: "games.clank.cards.dragon-shrine.text"
	},
	"dragons-eye": {
		name: "games.clank.cards.dragons-eye.name",
		text: "games.clank.cards.dragons-eye.text"
	},
	"dwarven-peddler": {
		name: "games.clank.cards.dwarven-peddler.name",
		text: "games.clank.cards.dwarven-peddler.text"
	},
	"elven-boots": {
		name: "games.clank.cards.elven-boots.name",
		text: "games.clank.cards.elven-boots.text"
	},
	"elven-cloak": {
		name: "games.clank.cards.elven-cloak.name",
		text: "games.clank.cards.elven-cloak.text"
	},
	"elven-dagger": {
		name: "games.clank.cards.elven-dagger.name",
		text: "games.clank.cards.elven-dagger.text"
	},
	emerald: {
		name: "games.clank.cards.emerald.name",
		text: "games.clank.cards.emerald.text"
	},
	"flying-carpet": {
		name: "games.clank.cards.flying-carpet.name",
		text: "games.clank.cards.flying-carpet.text"
	},
	"gem-collector": {
		name: "games.clank.cards.gem-collector.name",
		text: "games.clank.cards.gem-collector.text"
	},
	"invoker-of-the-ancients": {
		name: "games.clank.cards.invoker-of-the-ancients.name",
		text: "games.clank.cards.invoker-of-the-ancients.text"
	},
	kobold: {
		name: "games.clank.cards.kobold.name",
		text: "games.clank.cards.kobold.text"
	},
	"kobold-merchant": {
		name: "games.clank.cards.kobold-merchant.name",
		text: "games.clank.cards.kobold-merchant.text"
	},
	ladder: {
		name: "games.clank.cards.ladder.name",
		text: "games.clank.cards.ladder.text"
	},
	"lucky-coin": {
		name: "games.clank.cards.lucky-coin.name",
		text: "games.clank.cards.lucky-coin.text"
	},
	"master-burglar": {
		name: "games.clank.cards.master-burglar.name",
		text: "games.clank.cards.master-burglar.text"
	},
	"mister-whiskers": {
		name: "games.clank.cards.mister-whiskers.name",
		text: "games.clank.cards.mister-whiskers.text"
	},
	"monkeybot-3000": {
		name: "games.clank.cards.monkeybot-3000.name",
		text: "games.clank.cards.monkeybot-3000.text"
	},
	"move-silently": {
		name: "games.clank.cards.move-silently.name",
		text: "games.clank.cards.move-silently.text"
	},
	ogre: {
		name: "games.clank.cards.ogre.name",
		text: "games.clank.cards.ogre.text"
	},
	"ogre-grunt": {
		name: "games.clank.cards.ogre-grunt.name",
		text: "games.clank.cards.ogre-grunt.text"
	},
	overlord: {
		name: "games.clank.cards.overlord.name",
		text: "games.clank.cards.overlord.text"
	},
	pickaxe: {
		name: "games.clank.cards.pickaxe.name",
		text: "games.clank.cards.pickaxe.text"
	},
	"rebel-captain": {
		name: "games.clank.cards.rebel-captain.name",
		text: "games.clank.cards.rebel-captain.text"
	},
	"rebel-miner": {
		name: "games.clank.cards.rebel-miner.name",
		text: "games.clank.cards.rebel-miner.text"
	},
	"rebel-scout": {
		name: "games.clank.cards.rebel-scout.name",
		text: "games.clank.cards.rebel-scout.text"
	},
	"rebel-soldier": {
		name: "games.clank.cards.rebel-soldier.name",
		text: "games.clank.cards.rebel-soldier.text"
	},
	ruby: {
		name: "games.clank.cards.ruby.name",
		text: "games.clank.cards.ruby.text"
	},
	sapphire: {
		name: "games.clank.cards.sapphire.name",
		text: "games.clank.cards.sapphire.text"
	},
	search: {
		name: "games.clank.cards.search.name",
		text: "games.clank.cards.search.text"
	},
	"scepter-of-the-ape-lord": {
		name: "games.clank.cards.scepter-of-the-ape-lord.name",
		text: "games.clank.cards.scepter-of-the-ape-lord.text"
	},
	"silver-spear": {
		name: "games.clank.cards.silver-spear.name",
		text: "games.clank.cards.silver-spear.text"
	},
	"singing-sword": {
		name: "games.clank.cards.singing-sword.name",
		text: "games.clank.cards.singing-sword.text"
	},
	"sleight-of-hand": {
		name: "games.clank.cards.sleight-of-hand.name",
		text: "games.clank.cards.sleight-of-hand.text"
	},
	sneak: {
		name: "games.clank.cards.sneak.name",
		text: "games.clank.cards.sneak.text"
	},
	shrine: {
		name: "games.clank.cards.shrine.name",
		text: "games.clank.cards.shrine.text"
	},
	swagger: {
		name: "games.clank.cards.swagger.name",
		text: "games.clank.cards.swagger.text"
	},
	tattle: {
		name: "games.clank.cards.tattle.name",
		text: "games.clank.cards.tattle.text"
	},
	teleporter: {
		name: "games.clank.cards.teleporter.name",
		text: "games.clank.cards.teleporter.text"
	},
	"the-duke": {
		name: "games.clank.cards.the-duke.name",
		text: "games.clank.cards.the-duke.text"
	},
	"the-mountain-king": {
		name: "games.clank.cards.the-mountain-king.name",
		text: "games.clank.cards.the-mountain-king.text"
	},
	"the-queen-of-hearts": {
		name: "games.clank.cards.the-queen-of-hearts.name",
		text: "games.clank.cards.the-queen-of-hearts.text"
	},
	"the-vault": {
		name: "games.clank.cards.the-vault.name",
		text: "games.clank.cards.the-vault.text"
	},
	"treasure-hunter": {
		name: "games.clank.cards.treasure-hunter.name",
		text: "games.clank.cards.treasure-hunter.text"
	},
	"treasure-map": {
		name: "games.clank.cards.treasure-map.name",
		text: "games.clank.cards.treasure-map.text"
	},
	"tunnel-guide": {
		name: "games.clank.cards.tunnel-guide.name",
		text: "games.clank.cards.tunnel-guide.text"
	},
	"underworld-dealing": {
		name: "games.clank.cards.underworld-dealing.name",
		text: "games.clank.cards.underworld-dealing.text"
	},
	"wand-of-recall": {
		name: "games.clank.cards.wand-of-recall.name",
		text: "games.clank.cards.wand-of-recall.text"
	},
	"wand-of-wind": {
		name: "games.clank.cards.wand-of-wind.name",
		text: "games.clank.cards.wand-of-wind.text"
	},
	watcher: {
		name: "games.clank.cards.watcher.name",
		text: "games.clank.cards.watcher.text"
	},
	wizard: {
		name: "games.clank.cards.wizard.name",
		text: "games.clank.cards.wizard.text"
	},
	alchemist: {
		name: "games.clank.cards.alchemist.name",
		text: "games.clank.cards.alchemist.text"
	},
	"ancient-invocation": {
		name: "games.clank.cards.ancient-invocation.name",
		text: "games.clank.cards.ancient-invocation.text"
	},
	aspiration: {
		name: "games.clank.cards.aspiration.name",
		text: "games.clank.cards.aspiration.text"
	},
	"black-pearl": {
		name: "games.clank.cards.black-pearl.name",
		text: "games.clank.cards.black-pearl.text"
	},
	boomerang: {
		name: "games.clank.cards.boomerang.name",
		text: "games.clank.cards.boomerang.text"
	},
	"burglars-boots": {
		name: "games.clank.cards.burglars-boots.name",
		text: "games.clank.cards.burglars-boots.text"
	},
	"climbing-gear": {
		name: "games.clank.cards.climbing-gear.name",
		text: "games.clank.cards.climbing-gear.text"
	},
	"coin-purse": {
		name: "games.clank.cards.coin-purse.name",
		text: "games.clank.cards.coin-purse.text"
	},
	"crystal-fish": {
		name: "games.clank.cards.crystal-fish.name",
		text: "games.clank.cards.crystal-fish.text"
	},
	"deep-dive": {
		name: "games.clank.cards.deep-dive.name",
		text: "games.clank.cards.deep-dive.text"
	},
	"elven-ranger": {
		name: "games.clank.cards.elven-ranger.name",
		text: "games.clank.cards.elven-ranger.text"
	},
	"eye-in-the-water": {
		name: "games.clank.cards.eye-in-the-water.name",
		text: "games.clank.cards.eye-in-the-water.text"
	},
	"fishing-pole": {
		name: "games.clank.cards.fishing-pole.name",
		text: "games.clank.cards.fishing-pole.text"
	},
	"grand-plan": {
		name: "games.clank.cards.grand-plan.name",
		text: "games.clank.cards.grand-plan.text"
	},
	pickpocket: {
		name: "games.clank.cards.pickpocket.name",
		text: "games.clank.cards.pickpocket.text"
	},
	"pipe-organ": {
		name: "games.clank.cards.pipe-organ.name",
		text: "games.clank.cards.pipe-organ.text"
	},
	medic: {
		name: "games.clank.cards.medic.name",
		text: "games.clank.cards.medic.text"
	},
	merling: {
		name: "games.clank.cards.merling.name",
		text: "games.clank.cards.merling.text"
	},
	mermaid: {
		name: "games.clank.cards.mermaid.name",
		text: "games.clank.cards.mermaid.text"
	},
	"rebel-brawler": {
		name: "games.clank.cards.rebel-brawler.name",
		text: "games.clank.cards.rebel-brawler.text"
	},
	"rebel-scholar": {
		name: "games.clank.cards.rebel-scholar.name",
		text: "games.clank.cards.rebel-scholar.text"
	},
	saurian: {
		name: "games.clank.cards.saurian.name",
		text: "games.clank.cards.saurian.text"
	},
	"short-cut": {
		name: "games.clank.cards.short-cut.name",
		text: "games.clank.cards.short-cut.text"
	},
	"shrine-of-the-mermaid": {
		name: "games.clank.cards.shrine-of-the-mermaid.name",
		text: "games.clank.cards.shrine-of-the-mermaid.text"
	},
	"silver-pearl": {
		name: "games.clank.cards.silver-pearl.name",
		text: "games.clank.cards.silver-pearl.text"
	},
	sorcerer: {
		name: "games.clank.cards.sorcerer.name",
		text: "games.clank.cards.sorcerer.text"
	},
	"white-pearl": {
		name: "games.clank.cards.white-pearl.name",
		text: "games.clank.cards.white-pearl.text"
	},
	"blessed-fountain": {
		name: "games.clank.cards.blessed-fountain.name",
		text: "games.clank.cards.blessed-fountain.text"
	},
	"book-of-the-dead": {
		name: "games.clank.cards.book-of-the-dead.name",
		text: "games.clank.cards.book-of-the-dead.text"
	},
	bullwhip: {
		name: "games.clank.cards.bullwhip.name",
		text: "games.clank.cards.bullwhip.text"
	},
	camel: {
		name: "games.clank.cards.camel.name",
		text: "games.clank.cards.camel.text"
	},
	"canopic-jars": {
		name: "games.clank.cards.canopic-jars.name",
		text: "games.clank.cards.canopic-jars.text"
	},
	crocodilian: {
		name: "games.clank.cards.crocodilian.name",
		text: "games.clank.cards.crocodilian.text"
	},
	"crystal-skull": {
		name: "games.clank.cards.crystal-skull.name",
		text: "games.clank.cards.crystal-skull.text"
	},
	"death-mask": {
		name: "games.clank.cards.death-mask.name",
		text: "games.clank.cards.death-mask.text"
	},
	doomsayer: {
		name: "games.clank.cards.doomsayer.name",
		text: "games.clank.cards.doomsayer.text"
	},
	"daring-explorer": {
		name: "games.clank.cards.daring-explorer.name",
		text: "games.clank.cards.daring-explorer.text"
	},
	excavate: {
		name: "games.clank.cards.excavate.name",
		text: "games.clank.cards.excavate.text"
	},
	historian: {
		name: "games.clank.cards.historian.name",
		text: "games.clank.cards.historian.text"
	},
	jasper: {
		name: "games.clank.cards.jasper.name",
		text: "games.clank.cards.jasper.text"
	},
	kittypatra: {
		name: "games.clank.cards.kittypatra.name",
		text: "games.clank.cards.kittypatra.text"
	},
	"lapis-lazuli": {
		name: "games.clank.cards.lapis-lazuli.name",
		text: "games.clank.cards.lapis-lazuli.text"
	},
	"need-for-greed": {
		name: "games.clank.cards.need-for-greed.name",
		text: "games.clank.cards.need-for-greed.text"
	},
	"ornate-khopesh": {
		name: "games.clank.cards.ornate-khopesh.name",
		text: "games.clank.cards.ornate-khopesh.text"
	},
	purify: {
		name: "games.clank.cards.purify.name",
		text: "games.clank.cards.purify.text"
	},
	"rebel-burglar": {
		name: "games.clank.cards.rebel-burglar.name",
		text: "games.clank.cards.rebel-burglar.text"
	},
	"rebel-mystic": {
		name: "games.clank.cards.rebel-mystic.name",
		text: "games.clank.cards.rebel-mystic.text"
	},
	"ring-of-wishes": {
		name: "games.clank.cards.ring-of-wishes.name",
		text: "games.clank.cards.ring-of-wishes.text"
	},
	"royal-bodyguard": {
		name: "games.clank.cards.royal-bodyguard.name",
		text: "games.clank.cards.royal-bodyguard.text"
	},
	"scorpion-queen": {
		name: "games.clank.cards.scorpion-queen.name",
		text: "games.clank.cards.scorpion-queen.text"
	},
	serpentine: {
		name: "games.clank.cards.serpentine.name",
		text: "games.clank.cards.serpentine.text"
	},
	"staff-of-the-ancients": {
		name: "games.clank.cards.staff-of-the-ancients.name",
		text: "games.clank.cards.staff-of-the-ancients.text"
	},
	"stone-simian": {
		name: "games.clank.cards.stone-simian.name",
		text: "games.clank.cards.stone-simian.text"
	},
	"thrill-seeker": {
		name: "games.clank.cards.thrill-seeker.name",
		text: "games.clank.cards.thrill-seeker.text"
	},
	"tomb-robber": {
		name: "games.clank.cards.tomb-robber.name",
		text: "games.clank.cards.tomb-robber.text"
	},
	"tomb-snake": {
		name: "games.clank.cards.tomb-snake.name",
		text: "games.clank.cards.tomb-snake.text"
	},
	whiskersphinx: {
		name: "games.clank.cards.whiskersphinx.name",
		text: "games.clank.cards.whiskersphinx.text"
	},
	"brawn-vs-boots": {
		name: "games.clank.cards.brawn-vs-boots.name",
		text: "games.clank.cards.brawn-vs-boots.text"
	},
	"enchanted-dice": {
		name: "games.clank.cards.enchanted-dice.name",
		text: "games.clank.cards.enchanted-dice.text"
	},
	"dire-wolf": {
		name: "games.clank.cards.dire-wolf.name",
		text: "games.clank.cards.dire-wolf.text"
	},
	"expedition-leader": {
		name: "games.clank.cards.expedition-leader.name",
		text: "games.clank.cards.expedition-leader.text"
	},
	"friendly-watcher": {
		name: "games.clank.cards.friendly-watcher.name",
		text: "games.clank.cards.friendly-watcher.text"
	},
	"magic-spectacles": {
		name: "games.clank.cards.magic-spectacles.name",
		text: "games.clank.cards.magic-spectacles.text"
	},
	"mummy-hunters": {
		name: "games.clank.cards.mummy-hunters.name",
		text: "games.clank.cards.mummy-hunters.text"
	},
	"opal-apestone": {
		name: "games.clank.cards.opal-apestone.name",
		text: "games.clank.cards.opal-apestone.text"
	},
	siren: {
		name: "games.clank.cards.siren.name",
		text: "games.clank.cards.siren.text"
	},
	"snack-table": {
		name: "games.clank.cards.snack-table.name",
		text: "games.clank.cards.snack-table.text"
	},
	trailblazer: {
		name: "games.clank.cards.trailblazer.name",
		text: "games.clank.cards.trailblazer.text"
	},
	"wand-of-time": {
		name: "games.clank.cards.wand-of-time.name",
		text: "games.clank.cards.wand-of-time.text"
	},
	"wishing-wall": {
		name: "games.clank.cards.wishing-wall.name",
		text: "games.clank.cards.wishing-wall.text"
	}
};
//#endregion
//#region src/games/clank/card.tsx
function sn({ kind: e, compact: t = !1 }) {
	let n = d(), r = j[e], i = on[e];
	return /* @__PURE__ */ h("div", {
		className: `clank-card${t ? " clank-card--compact" : ""}`,
		"data-type": r.type,
		"data-pack": r.pack,
		children: [
			/* @__PURE__ */ h("div", {
				className: "clank-card-heading",
				children: [/* @__PURE__ */ m("strong", { children: n(i.name) }), r.points > 0 && /* @__PURE__ */ m("b", {
					className: "clank-card-points",
					title: n(r.points === 1 ? $.ui_onePoint : $.ui_points, { n: r.points }),
					children: r.points
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "clank-card-art",
				children: [/* @__PURE__ */ m(tn, { kind: e }), (r.skill > 0 || r.swords > 0 || r.boots > 0) && /* @__PURE__ */ m("div", {
					className: "clank-card-resources",
					children: [
						[
							"skill",
							r.skill,
							$.ui_skill
						],
						[
							"sword",
							r.swords,
							$.ui_swords
						],
						[
							"boot",
							r.boots,
							$.ui_boots
						]
					].filter(([, e]) => e > 0).map(([e, t, r]) => /* @__PURE__ */ h("span", {
						title: n(r),
						children: [/* @__PURE__ */ m(Yt, {
							kind: e,
							size: 20
						}), /* @__PURE__ */ m("b", { children: t })]
					}, e))
				})]
			}),
			!t && /* @__PURE__ */ m(cn, { text: n(i.text) }),
			/* @__PURE__ */ h("div", {
				className: "clank-card-foot",
				children: [/* @__PURE__ */ h("span", { children: [
					r.dragon && /* @__PURE__ */ m("span", {
						title: n($.ui_dragonAttack),
						className: "clank-card-dragon",
						children: "🐉"
					}),
					r.danger && /* @__PURE__ */ m("span", {
						title: n($.ui_danger),
						children: "⚠"
					}),
					r.deep && /* @__PURE__ */ m("span", {
						title: n($.ui_deep),
						children: "⬇"
					}),
					r.cave && /* @__PURE__ */ m("span", {
						title: n($.ui_cave),
						children: "◆"
					}),
					r.water && /* @__PURE__ */ m("span", {
						title: n($.ui_water),
						children: "≈"
					})
				] }), /* @__PURE__ */ h("span", {
					title: n($.ui_cost, { n: r.cost }),
					children: [/* @__PURE__ */ m(Yt, {
						kind: r.type === "monster" ? "sword" : "skill",
						size: 21
					}), /* @__PURE__ */ m("b", { children: r.cost })]
				})]
			})
		]
	});
}
function cn({ text: e }) {
	let t = [];
	for (let n of e.split("\n")) {
		let e = n.startsWith("· "), r = t.at(-1);
		e && r?.list ? r.lines.push(n.slice(2)) : t.push({
			list: e,
			lines: [e ? n.slice(2) : n]
		});
	}
	return /* @__PURE__ */ m("div", {
		className: "clank-card-text",
		children: t.map((e, t) => e.list ? /* @__PURE__ */ m("ul", { children: e.lines.map((e, t) => /* @__PURE__ */ m("li", { children: e }, t)) }, t) : /* @__PURE__ */ m("p", { children: e.lines.map((e) => {
			let t = /^([^：:]{1,45}[：:])(.*)$/.exec(e);
			return t ? /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("strong", { children: t[1] }), t[2]] }, e) : e;
		}) }, t))
	});
}
//#endregion
//#region src/games/clank/labels.ts
function ln(e, t) {
	return t((on[e] ?? on.burgle).name);
}
function un(e, t) {
	let n = $[`items_${e}`];
	return n ? t(n) : ln(e, t);
}
function dn(e, t, n, r) {
	let i = t.players.find((e) => e.rid === t.active), a = [
		...n?.hand ?? [],
		...i?.played ?? [],
		...i?.discard ?? []
	], o = (e) => ln(a.find((t) => t.uid === e)?.kind ?? "burgle", r);
	switch (e.type) {
		case "play": return r($.action_play, { card: o(e.card) });
		case "row": return r(j[t.row[e.slot]?.kind ?? "burgle"].type === "monster" ? $.action_defeat : $.action_acquire, { card: ln(t.row[e.slot]?.kind ?? "burgle", r) });
		case "reserve": return r($.action_acquire, { card: ln(e.card, r) });
		case "move": return r($.ui_move, { n: e.to });
		case "artifact": return r($.ui_artifact);
		case "market": return r($.action_market, { item: un(e.item, r) });
		case "fight": return e.monster === "mummyGold" ? r($.action_mummyGold) : e.monster === "mummyCleanse" ? r($.action_mummyCleanse) : e.apparatus ? r($.action_guardian, { item: un(e.apparatus, r) }) : r($.action_defeat, { card: un(e.monster, r) });
		case "mine": return r($.action_mine, { n: e.mine + 1 });
		case "cache": return r($.choice_cache, {
			n: e.cache + 1,
			reward: r(pn[e.cache])
		});
		case "rotate": return r($.action_rotate, {
			n: e.gear + 1,
			orientation: e.orientation + 1,
			item: un(e.apparatus, r)
		});
		case "potion": return r($.action_potion, { item: un(e.potion, r) });
		case "spring": return r($.action_spring, { card: o(e.card) });
		case "continue": return r($.ui_continue);
		case "end": return r($.ui_end);
		case "tick": return r($.ui_resolving);
		case "resolve": {
			if ([
				"discard",
				"trash",
				"recall"
			].includes(e.option)) return r($[`action_${e.option}`], { card: o(e.target) });
			if (["teleport", "adjacent"].includes(e.option)) return r($[`action_${e.option}`], { n: e.target });
			if (e.option === "replace" || e.option === "acquire") return r(e.option === "replace" ? $.action_replace : $.action_freeAcquire, { card: ln(t.row[e.target]?.kind ?? "burgle", r) });
			if (e.option === "organ") return r(e.target > 0 ? $.choice_up : $.choice_down);
			let [n, i] = e.option.split(":");
			if (i !== void 0) {
				let e = Math.abs(Number(i));
				if (n === "heal") return r($.resource_heal, { n: e });
				if (n === "clank" && Number(i) > 0) return r($.resource_makeClank, { n: e });
				let t = n === "curse" && e === 1 ? $.resource_oneCurse : $[`resource_${n}`] ?? $.resource_curse;
				return r(Number(i) < 0 ? $.choice_remove : $.choice_gain, { resource: r(t, { n: e }) });
			}
			return r($[`choice_${e.option}`] ?? $.ui_choose);
		}
	}
}
function fn(e, t, n) {
	let r = e.event === "rotate" && e.rid ? $.events_rotatePlayer : $[`events_${e.event}`], i = e.event === "secret" && e.token === "mummyGold" ? n($.items_gold5) : e.token ? un(e.token, n) : "";
	return n(r, {
		name: e.rid ? t(e.rid) : "",
		card: e.card ? ln(e.card, n) : i,
		n: e.event === "rotate" ? (e.n ?? 0) + 1 : e.room ?? e.n ?? 0
	});
}
var pn = [
	$.guide_cache1,
	$.guide_cache2,
	$.guide_cache3,
	$.guide_cache4,
	$.guide_cache5,
	$.guide_cache6,
	$.guide_cache7,
	$.guide_cache8
], mn = {
	key: [$.items_key, "games.clank.possessions.key"],
	backpack: [$.items_backpack, "games.clank.possessions.backpack"],
	crown: [$.items_crown, "games.clank.possessions.crown"],
	scuba: [$.items_scuba, "games.clank.possessions.scuba"],
	ankh: [$.items_ankh, "games.clank.possessions.ankh"],
	timeWinder: [$.items_timeWinder, "games.clank.possessions.timeWinder"],
	heal1: [$.items_heal1, "games.clank.possessions.heal1"],
	heal2: [$.items_heal2, "games.clank.possessions.heal2"],
	boots: [$.items_boots, "games.clank.possessions.boots"],
	swords: [$.items_swords, "games.clank.possessions.swords"],
	heroism: [$.items_heroism, "games.clank.possessions.heroism"],
	gold2: [$.items_gold2, "games.clank.possessions.gold2"],
	gold5: [$.items_gold5, "games.clank.possessions.gold5"],
	skill2: [$.items_skill2, "games.clank.possessions.skill2"],
	skill5: [$.items_skill5, "games.clank.possessions.skill5"],
	draw3: [$.items_draw3, "games.clank.possessions.draw3"],
	chalice: [$.items_chalice, "games.clank.possessions.chalice"],
	spring: [$.items_spring, "games.clank.possessions.spring"],
	egg: [$.items_egg, "games.clank.possessions.egg"],
	scarab: [$.items_scarab, "games.clank.possessions.scarab"],
	mummyGold: [$.items_gold5, "games.clank.possessions.mummyGold"],
	mummyChalice: [$.items_mummyChalice, "games.clank.possessions.mummyChalice"],
	artifact: ["games.clank.possessions.artifactName", "games.clank.possessions.artifact"],
	idol: ["games.clank.possessions.idolName", "games.clank.possessions.idol"],
	web: [$.ui_web, "games.clank.possessions.web"],
	cog: [$.items_cog, "games.clank.possessions.apparatusTemple"],
	wrench: [$.items_wrench, "games.clank.possessions.apparatusTemple"],
	banana: [$.items_banana, "games.clank.possessions.apparatusTemple"]
}, hn = (e) => Object.hasOwn(mn, e);
function gn({ kind: e }) {
	let t = {
		chalice: "goblet",
		mummyChalice: "goblet",
		artifact: "goblet",
		idol: "idol",
		crown: "crown",
		gold2: "coin",
		gold5: "coin",
		mummyGold: "coin",
		skill2: "skill",
		skill5: "skill"
	}[e];
	if (t) return /* @__PURE__ */ m(Yt, {
		kind: t,
		size: 36
	});
	let n = [
		"heal1",
		"heal2",
		"boots",
		"swords",
		"heroism"
	].includes(e);
	return /* @__PURE__ */ m("svg", {
		className: "clank-token-art",
		width: "36",
		height: "36",
		viewBox: "-3 -2 38 38",
		"aria-hidden": "true",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: n ? /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("path", {
				d: "M11 2h10v5h-2v5c14 7 11 19-3 19S-1 19 13 12V7h-2Z",
				fill: e.startsWith("heal") ? "#a34b55" : e === "heroism" ? "#b38b40" : "#427e96"
			}),
			/* @__PURE__ */ m("path", { d: "M11 7h10M7 22h18" }),
			e === "heal1" || e === "heal2" ? /* @__PURE__ */ m("path", { d: "M16 17v9M12 21h8" }) : e === "swords" ? /* @__PURE__ */ m("path", { d: "m12 26 8-10M12 21l6 5" }) : /* @__PURE__ */ m("path", { d: "m16 16-4 7h7l-3 5" })
		] }) : /* @__PURE__ */ m("path", { d: {
			key: "M24 12a7 7 0 1 1-3-6l-9 9v5H7v5H2v-7L18 2",
			backpack: "M7 10h18v20H7ZM12 10V5h8v5M10 19h12v8H10M7 13H3v13h4M25 13h4v13h-4",
			scuba: "M5 11h22v12H5ZM16 11v12M27 16h4V3h-6M8 27h16",
			ankh: "M16 15C3 9 11 0 16 2c5-2 13 7 0 13Zm0 0v16M6 20h20",
			timeWinder: "M6 2h20M6 30h20M9 3v6l14 14v6M23 3v6L9 23v6M12 7h8M12 26h8",
			egg: "M16 2C6 2 0 24 8 29c5 4 13 3 17-1C32 20 24 2 16 2ZM9 14l5 4-5 4M21 9l-3 5 5 4",
			scarab: "M8 17a8 12 0 1 0 16 0 8 12 0 1 0-16 0ZM16 5v24M7 10 2 7M6 18H1M8 25l-6 5M25 10l5-3M26 18h5M24 25l6 5",
			spring: "M16 3v14M10 7l6-5 6 5M4 21l12 9 12-9-12-8ZM4 21v6l12 5 12-5v-6",
			web: "M16 0v32M0 16h32M5 5l22 22M5 27 27 5M16 5l8 3 3 8-3 8-8 3-8-3-3-8 3-8ZM16 11l4 1 1 4-1 4-4 1-4-1-1-4 1-4Z",
			cog: "M11 2h10v5l5 3 4-2 3 8-5 3v5l-5 4-2 4H11l-2-4-5-4v-5l-5-3 3-8 4 2 5-3ZM21 17a5 5 0 1 0-10 0 5 5 0 1 0 10 0",
			wrench: "M22 2a9 9 0 0 0-9 12L2 25l5 5 11-11A9 9 0 0 0 30 7l-8 6-4-4Z",
			banana: "M26 2C28 18 17 28 3 24l-1 4C20 38 35 19 29 2ZM4 24l-2-3M25 4l4-3",
			draw3: "M2 8h18v23H2ZM8 4h18v23M14 1h17v23"
		}[e] })
	});
}
function _n({ kind: e, map: t }) {
	let n = d(), r = [
		"cog",
		"wrench",
		"banana"
	].includes(e) && t === "jungle" ? "games.clank.possessions.apparatusJungle" : mn[e][1];
	return /* @__PURE__ */ m("p", {
		className: "clank-token-effect",
		children: n(r)
	});
}
function vn({ kind: e, points: t, price: n }) {
	let r = d();
	return /* @__PURE__ */ h("div", {
		className: "clank-token-description",
		children: [
			/* @__PURE__ */ h("div", {
				className: "clank-token-heading",
				children: [/* @__PURE__ */ m(gn, { kind: e }), /* @__PURE__ */ m("strong", { children: r(mn[e][0]) })]
			}),
			/* @__PURE__ */ m(_n, { kind: e }),
			(n !== void 0 || t !== void 0) && /* @__PURE__ */ h("div", {
				className: "clank-token-values",
				children: [n !== void 0 && /* @__PURE__ */ m("span", { children: r("games.clank.possessions.purchaseCost", { n }) }), t !== void 0 && /* @__PURE__ */ m("span", { children: r("games.clank.possessions.endPoints", { n: t }) })]
			})
		]
	});
}
function yn({ player: e, priv: t, myRid: n, map: r, actions: i, onUse: a }) {
	let o = d(), s = e.rid === n, c = [], l = (e, t = 1, n) => {
		if (!t) return;
		let r = c.find((t) => t.kind === e && t.points === n);
		r ? r.count += t : c.push({
			kind: e,
			count: t,
			points: n
		});
	};
	return e.potions.forEach((e) => l(e)), e.artifacts.forEach((e) => l("artifact", 1, e)), e.idols.forEach((e) => l("idol", 1, e)), l("chalice", e.chalices, 7), l("egg", e.eggs, 3), l("scarab", e.scarabs, 3), e.items.forEach((e) => l(e.kind, 1, e.points)), (e.apparatus ?? (s ? t?.apparatus : []) ?? []).forEach((e) => l(e)), s ? (t?.webs.forEach((e) => l("web", 1, e)), l("spring", t?.spring ?? 0)) : l("web", e.webCount), /* @__PURE__ */ h("section", {
		className: "clank-inventory",
		children: [
			/* @__PURE__ */ m("h3", { children: o($.ui_inventory) }),
			c.length ? /* @__PURE__ */ m("div", {
				className: "clank-possession-grid",
				children: c.map((e) => {
					let t = s ? i.find((t) => t.type === "potion" && t.potion === e.kind) : void 0, n = e.points === void 0 ? r === "jungle" && [
						"cog",
						"wrench",
						"banana"
					].includes(e.kind) ? e.count ** 2 : void 0 : e.points * e.count;
					return /* @__PURE__ */ h("details", {
						className: "clank-possession",
						children: [/* @__PURE__ */ h("summary", { children: [
							/* @__PURE__ */ m(gn, { kind: e.kind }),
							/* @__PURE__ */ h("span", {
								className: "clank-possession-name",
								children: [o(mn[e.kind][0]), /* @__PURE__ */ m("small", { children: o("games.clank.possessions.quantity", { n: e.count }) })]
							}),
							n !== void 0 && /* @__PURE__ */ m("span", {
								className: "clank-possession-points",
								children: o($.ui_points, { n })
							})
						] }), /* @__PURE__ */ h("div", {
							className: "clank-possession-content",
							children: [/* @__PURE__ */ m(_n, {
								kind: e.kind,
								map: r
							}), t && /* @__PURE__ */ m("button", {
								type: "button",
								className: "clank-primary",
								onClick: () => a(t),
								children: o($.ui_potion)
							})]
						})]
					}, `${e.kind}:${e.points ?? ""}`);
				})
			}) : /* @__PURE__ */ m("p", { children: o($.ui_none) }),
			e.apparatus === null && !s && e.apparatusCount > 0 && /* @__PURE__ */ m("p", { children: o("games.clank.possessions.hiddenApparatus", { n: e.apparatusCount }) })
		]
	});
}
//#endregion
//#region src/games/clank/view-player.tsx
function bn(e) {
	let t = d(), n = e.public, i = e.private, [a, o] = s(null), [u, g] = s(!1), [_, v] = s(null), [y, b] = s(null), x = (e) => {
		o(e), g(e !== null), v(null);
	}, S = r(() => {
		g(!1), v(null);
	}, []), C = n.players.find((t) => t.rid === e.myRid), w = n.phase === "done" ? [] : i?.actions ?? [], T = n.phase !== "done" && n.choice?.rid === e.myRid, E = (t) => e.members.find((e) => e.rid === t)?.name ?? t, D = (t) => {
		w.some((e) => JSON.stringify(e) === JSON.stringify(t)) && (e.send(t), g(!1), v(null), b(null));
	}, O = (e) => w.find((t) => t.type === "row" && t.slot === e), k = (e, t) => x({
		type: "card",
		kind: e,
		action: t
	}), A = T ? t($[`choice_${n.choice.kind}`] ?? $.ui_choose) : n.phase === "intermission" ? t($.ui_intermission) : w.length ? t($.ui_yourTurn) : n.phase === "play" && !n.choice && n.active !== e.myRid ? t($.ui_waiting, { name: E(n.active) }) : t($.ui_resolving), M = w.find((e) => e.type === "end" || e.type === "continue"), N = a?.type === "room" ? w.filter((e) => e.type === "move" && e.to === a.room) : [], ee = (e) => {
		let r = Te(n, W[n.map].tunnels[e.tunnel]), i = n.players.find((e) => e.rid === n.active), a = n.turn.flags.includes("ignoreIcons"), o = W[n.map].rooms[i.room].water && W[n.map].rooms[e.to].water, s = i.items.some((e) => e.kind === "scuba") || n.turn.flags.includes("scuba"), c = (a ? 1 : Math.max(r.boots ?? 1, o && !s ? 2 : 1)) + Number(e.web === "boot"), l = e.swords + Number(e.web === "sword"), u = (a || n.turn.flags.includes("ignoreMonsters") ? 0 : r.monsters ?? 0) - e.swords;
		return [
			t($.ui_spendBoots, { n: c }),
			l ? t($.ui_spendSwords, { n: l }) : "",
			u ? t($.ui_moveDamage, { n: u }) : "",
			r.elevator ? t($.ui_spendGold, { n: 1 }) : "",
			!a && r.clank ? t($.ui_makeClank, { n: r.clank }) : "",
			!a && r.curse ? t($.ui_gainCurse, { n: r.curse }) : ""
		].filter(Boolean).join(t($.ui_moveSeparator));
	}, P = _ && w.some((e) => JSON.stringify(e) === JSON.stringify(_)) ? _ : null, te = (e) => {
		let t = w.filter((t) => t.type === "move" && t.to === e);
		b(e), t.length === 1 ? (v(t[0]), g(!1)) : x({
			type: "room",
			room: e
		});
	}, F = /* @__PURE__ */ m("div", {
		className: "clank-dungeon-grid",
		children: n.row.map((e, n) => e ? /* @__PURE__ */ m("button", {
			type: "button",
			className: "clank-card-button",
			"data-available": !!O(n),
			onClick: () => k(e.kind, O(n)),
			"aria-label": t($.ui_inspectCard, { card: ln(e.kind, t) }),
			children: /* @__PURE__ */ m(sn, {
				kind: e.kind,
				compact: !0
			})
		}, e.uid) : /* @__PURE__ */ m("div", {
			className: "clank-empty-card",
			children: /* @__PURE__ */ m(Yt, {
				kind: "cube",
				size: 30
			})
		}, n))
	}), I = /* @__PURE__ */ m("div", {
		className: "clank-seats",
		children: n.players.map((r, i) => {
			let a = e.members.find((e) => e.rid === r.rid), o = l[a?.colorIndex ?? i].hex;
			return /* @__PURE__ */ h("button", {
				type: "button",
				className: "clank-seat",
				"data-active": n.active === r.rid,
				"data-out": r.state !== "active",
				style: { "--clank-player": o },
				onClick: () => x({
					type: "player",
					rid: r.rid
				}),
				"aria-label": `${E(r.rid)} · ${t($.ui_healthCount, { n: 10 - r.damage })} · ${t($.ui_goldCount, { n: r.gold })}`,
				children: [/* @__PURE__ */ m(Xt, {
					index: i,
					color: o
				}), /* @__PURE__ */ h("span", {
					className: "clank-seat-info",
					children: [
						/* @__PURE__ */ h("strong", { children: [E(r.rid), r.rid === e.myRid && /* @__PURE__ */ m("span", {
							className: "clank-self-dot",
							children: "●"
						})] }),
						/* @__PURE__ */ h("span", {
							className: "clank-seat-stats",
							children: [
								/* @__PURE__ */ m(Yt, {
									kind: "heart",
									size: 13
								}),
								/* @__PURE__ */ m(c, { value: 10 - r.damage }),
								/* @__PURE__ */ m(Yt, {
									kind: "coin",
									size: 13
								}),
								/* @__PURE__ */ m(c, { value: r.gold })
							]
						}),
						/* @__PURE__ */ h("span", {
							className: "clank-seat-extra",
							children: [
								t($[`ui_${r.state}`]),
								" · ",
								t($.ui_room, { n: r.room })
							]
						})
					]
				})]
			}, r.rid);
		})
	}), L = P?.type === "move" ? P : M, R = a?.type === "card" && a.action && w.some((e) => JSON.stringify(e) === JSON.stringify(a.action)) ? a.action : null;
	return /* @__PURE__ */ h("div", {
		className: "clank-screen",
		children: [
			/* @__PURE__ */ m(Jt, {}),
			/* @__PURE__ */ m(f, {
				adaptive: !0,
				scroll: !1,
				banner: /* @__PURE__ */ h("div", {
					className: "clank-banner",
					children: [/* @__PURE__ */ m("div", {
						className: "clank-mobile-seats",
						children: I
					}), /* @__PURE__ */ h("div", {
						className: "clank-status",
						children: [
							/* @__PURE__ */ h("span", {
								className: "clank-rage",
								children: ["🐉 ", t($.ui_rage, { n: n.rage + 1 })]
							}),
							/* @__PURE__ */ m("span", {
								className: "clank-status-prompt",
								"data-quiet": n.phase === "play" && !n.choice && w.length > 0,
								role: "status",
								children: A
							}),
							/* @__PURE__ */ m("span", { children: n.countdown ? t($.ui_countdown, { n: n.countdown.step }) : t($.ui_turn, { n: n.turnNumber }) })
						]
					})]
				}),
				actionsHeight: "clank-actions-height",
				actions: /* @__PURE__ */ h("div", {
					className: "clank-hand-area",
					children: [
						/* @__PURE__ */ h("div", {
							className: "clank-resources",
							children: [
								[
									[
										"skill",
										n.turn.skill,
										$.ui_skill
									],
									[
										"sword",
										n.turn.swords,
										$.ui_swords
									],
									[
										"boot",
										n.turn.boots,
										$.ui_boots
									]
								].map(([e, n, r]) => /* @__PURE__ */ h("span", {
									title: t(r),
									children: [
										/* @__PURE__ */ m(Yt, {
											kind: e,
											size: 22
										}),
										/* @__PURE__ */ m(c, { value: n }),
										/* @__PURE__ */ m("small", { children: t(r) })
									]
								}, e)),
								/* @__PURE__ */ h("span", {
									className: "clank-personal-noise",
									title: t($.ui_clank),
									children: [/* @__PURE__ */ m(Yt, {
										kind: "cube",
										size: 19
									}), /* @__PURE__ */ m(c, { value: C?.clank ?? 0 })]
								}),
								/* @__PURE__ */ m("span", {
									className: "clank-hand-count",
									children: t($.ui_handCount, { n: i?.hand.length ?? 0 })
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "clank-hand",
							children: i?.hand.map((e) => /* @__PURE__ */ m("button", {
								type: "button",
								className: "clank-card-button",
								"data-available": w.some((t) => t.type === "play" && t.card === e.uid),
								onClick: () => k(e.kind, w.find((t) => t.type === "play" && t.card === e.uid)),
								"aria-label": t($.ui_inspectCard, { card: ln(e.kind, t) }),
								children: /* @__PURE__ */ m(sn, {
									kind: e.kind,
									compact: !0
								})
							}, e.uid))
						}),
						/* @__PURE__ */ m("div", {
							className: "clank-command",
							children: /* @__PURE__ */ h("div", {
								className: "clank-command-buttons",
								children: [
									P?.type === "move" ? /* @__PURE__ */ m("button", {
										type: "button",
										className: "clank-secondary",
										onClick: () => {
											v(null), b(null);
										},
										children: t($.ui_cancel)
									}) : /* @__PURE__ */ m("button", {
										type: "button",
										className: "clank-secondary clank-open-dungeon",
										onClick: () => x({ type: "dungeon" }),
										children: t($.ui_openDungeon)
									}),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "clank-secondary",
										onClick: () => x({ type: "actions" }),
										children: t($.ui_openActions)
									}),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "clank-primary",
										disabled: !L || T,
										onClick: () => {
											L && D(L);
										},
										children: L ? dn(L, n, i, t) : t($.ui_end)
									})
								]
							})
						})
					]
				}),
				children: /* @__PURE__ */ h("div", {
					className: "clank-table",
					children: [
						/* @__PURE__ */ h("aside", {
							className: "clank-player-side",
							children: [
								/* @__PURE__ */ m(Qt, { angry: n.phase === "dragon" }),
								/* @__PURE__ */ m("div", {
									className: "clank-rage-track",
									"aria-label": t($.ui_rage, { n: n.rage + 1 }),
									children: Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ m("span", { "data-lit": t <= n.rage }, t))
								}),
								I,
								/* @__PURE__ */ h("div", {
									className: "clank-noise-pool",
									children: [/* @__PURE__ */ m("strong", { children: t($.ui_noisePool) }), n.players.map((t, n) => /* @__PURE__ */ h("div", {
										style: { color: l[e.members.find((e) => e.rid === t.rid)?.colorIndex ?? n].hex },
										children: [
											/* @__PURE__ */ m(Yt, {
												kind: "cube",
												size: 22
											}),
											/* @__PURE__ */ m("span", { children: E(t.rid) }),
											/* @__PURE__ */ m(c, { value: t.clank })
										]
									}, t.rid))]
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									className: "clank-secondary",
									onClick: () => x({ type: "log" }),
									children: t($.ui_log)
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							className: "clank-map-area",
							children: [/* @__PURE__ */ m(nn, {
								pub: n,
								actions: w,
								members: e.members,
								myRid: e.myRid,
								selectedRoom: y,
								onRoom: te
							}, `${n.map}:${n.gameNumber}`), P?.type === "move" && /* @__PURE__ */ m("div", {
								className: "clank-command-hint",
								role: "status",
								children: ee(P)
							})]
						}),
						/* @__PURE__ */ h("aside", {
							className: "clank-dungeon-side",
							children: [
								/* @__PURE__ */ h("div", {
									className: "clank-section-heading",
									children: [/* @__PURE__ */ m("strong", { children: t($.ui_dungeon) }), /* @__PURE__ */ m("span", { children: t($.ui_remaining, { n: n.dungeonCount }) })]
								}),
								F,
								/* @__PURE__ */ m("button", {
									type: "button",
									className: "clank-secondary",
									onClick: () => x({ type: "supplies" }),
									children: t($.ui_supplies)
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									className: "clank-history-button",
									onClick: () => x({ type: "log" }),
									children: n.log.length ? fn(n.log[n.log.length - 1], E, t) : t($.ui_log)
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ m(an, {
				open: u && !T && n.phase !== "intermission",
				onClose: S,
				label: t($.ui_details),
				title: a?.type === "room" ? t($.ui_room, { n: a.room }) : a?.type === "player" ? E(a.rid) : a?.type === "card" ? ln(a.kind, t) : t($[`ui_${a?.type ?? "details"}`] ?? $.ui_details),
				footer: R ? /* @__PURE__ */ m("div", {
					className: "clank-sheet-footer",
					children: /* @__PURE__ */ m("button", {
						type: "button",
						className: "clank-primary",
						onClick: () => D(R),
						children: dn(R, n, i, t)
					})
				}) : void 0,
				children: /* @__PURE__ */ h("div", {
					className: "clank-panel",
					children: [
						a?.type === "actions" && /* @__PURE__ */ m("p", { children: t(Ce[n.map]) }),
						a?.type === "card" && /* @__PURE__ */ m(sn, { kind: a.kind }),
						a?.type === "dungeon" && /* @__PURE__ */ h(p, { children: [F, /* @__PURE__ */ m("p", { children: t($.ui_remaining, { n: n.dungeonCount }) })] }),
						a?.type === "room" && /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("p", { children: [
								t(W[n.map].rooms[a.room].deep ? $.ui_deep : $.ui_surface),
								W[n.map].rooms[a.room].water ? ` · ${t($.ui_water)}` : "",
								W[n.map].rooms[a.room].cave ? ` · ${t($.ui_cave)}` : ""
							] }),
							/* @__PURE__ */ h("div", {
								className: "clank-detail-lines",
								children: [
									/* @__PURE__ */ m("p", { children: t($.ui_secretCount, { n: n.rooms[a.room].secrets }) }),
									/* @__PURE__ */ m("p", { children: t($.ui_artifactValues, { values: n.rooms[a.room].artifacts.join(", ") || t($.ui_none) }) }),
									/* @__PURE__ */ m("p", { children: t($.ui_idolValues, { values: n.rooms[a.room].idols.join(", ") || t($.ui_none) }) })
								]
							}),
							N.length > 1 && /* @__PURE__ */ m("h3", { children: t($.ui_chooseMove) }),
							/* @__PURE__ */ h("div", {
								className: "clank-choice-list",
								children: [N.map((e, r) => /* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => {
										v(e), g(!1);
									},
									children: [/* @__PURE__ */ m("strong", { children: dn(e, n, i, t) }), e.type === "move" && /* @__PURE__ */ m("small", { children: ee(e) })]
								}, r)), C?.room === a.room && w.filter((e) => [
									"artifact",
									"market",
									"mine",
									"rotate"
								].includes(e.type)).map((e, r) => /* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => v(e),
									children: dn(e, n, i, t)
								}, `local${r}`))]
							})
						] }),
						(a?.type === "actions" || a?.type === "supplies") && /* @__PURE__ */ h("div", {
							className: "clank-choice-list",
							children: [
								w.filter((e) => a.type === "supplies" ? [
									"reserve",
									"market",
									"fight",
									"cache"
								].includes(e.type) : ![
									"play",
									"move",
									"reserve",
									"row",
									"resolve"
								].includes(e.type)).map((e, r) => /* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => e.type === "reserve" ? k(e.card, e) : v(e),
									children: dn(e, n, i, t)
								}, r)),
								a.type === "actions" && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => x({ type: "supplies" }),
									children: t($.ui_supplies)
								}), /* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => x({ type: "log" }),
									children: t($.ui_log)
								})] }),
								!w.length && /* @__PURE__ */ m("p", { children: t($.ui_noAction) })
							]
						}),
						a?.type === "log" && /* @__PURE__ */ m("ol", {
							className: "clank-history",
							children: n.log.map((e, n) => /* @__PURE__ */ m("li", { children: e.event === "secret" && e.token && hn(e.token) ? /* @__PURE__ */ h("details", { children: [/* @__PURE__ */ m("summary", { children: fn(e, E, t) }), /* @__PURE__ */ m(vn, { kind: e.token })] }) : fn(e, E, t) }, n))
						}),
						a?.type === "player" && (() => {
							let r = n.players.find((e) => e.rid === a.rid);
							return /* @__PURE__ */ h(p, { children: [
								/* @__PURE__ */ m("div", {
									className: "clank-player-facts",
									children: [
										[$.ui_healthCount, 10 - r.damage],
										[$.ui_goldCount, r.gold],
										[$.ui_noiseCount, r.clank],
										[$.ui_bagCount, r.bag],
										[$.ui_curseCount, r.curses],
										[$.ui_suppliesCount, r.supply],
										[$.ui_deckCount, r.deckCount],
										[$.ui_handCount, r.handCount]
									].map(([e, n]) => /* @__PURE__ */ m("p", { children: t(e, { n }) }, e))
								}),
								/* @__PURE__ */ m(yn, {
									player: r,
									priv: i,
									myRid: e.myRid,
									map: n.map,
									actions: w,
									onUse: D
								}, `${r.rid}:${n.gameNumber}`),
								/* @__PURE__ */ m("h3", { children: t($.ui_played) }),
								/* @__PURE__ */ m("div", {
									className: "clank-card-collection",
									children: r.played.map((e) => /* @__PURE__ */ m("button", {
										type: "button",
										onClick: () => k(e.kind),
										children: /* @__PURE__ */ m(sn, {
											kind: e.kind,
											compact: !0
										})
									}, e.uid))
								}),
								/* @__PURE__ */ m("h3", { children: t($.ui_discard) }),
								/* @__PURE__ */ m("div", {
									className: "clank-card-collection",
									children: r.discard.map((e) => /* @__PURE__ */ m("button", {
										type: "button",
										onClick: () => k(e.kind),
										children: /* @__PURE__ */ m(sn, {
											kind: e.kind,
											compact: !0
										})
									}, e.uid))
								})
							] });
						})(),
						P && P.type !== "move" && /* @__PURE__ */ h("div", {
							className: "clank-confirm",
							children: [
								P.type === "market" ? /* @__PURE__ */ m(vn, {
									kind: P.item,
									price: 7,
									points: n.market[P.item][0]
								}) : P.type === "potion" ? /* @__PURE__ */ m(vn, { kind: P.potion }) : /* @__PURE__ */ m("strong", { children: dn(P, n, i, t) }),
								P.type === "rotate" && /* @__PURE__ */ m(rn, {
									pub: n,
									gearId: P.gear,
									orientation: P.orientation
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									className: "clank-primary",
									onClick: () => D(P),
									children: t($.ui_confirm)
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ m(an, {
				open: T,
				label: A,
				title: `${n.choice?.source && n.choice.source in j ? ln(n.choice.source, t) + " · " : ""}${A}`,
				children: /* @__PURE__ */ h("div", {
					className: "clank-panel",
					children: [i?.peek && /* @__PURE__ */ m(sn, { kind: i.peek.kind }), /* @__PURE__ */ m("div", {
						className: "clank-choice-list",
						children: w.filter((e) => e.type === "resolve").map((e, r) => /* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => D(e),
							children: dn(e, n, i, t)
						}, r))
					})]
				})
			}),
			n.phase === "intermission" && /* @__PURE__ */ m(an, {
				open: !0,
				label: t($.ui_intermission),
				title: t($.ui_intermission),
				children: /* @__PURE__ */ h("div", {
					className: "clank-panel",
					children: [n.players.map((e) => /* @__PURE__ */ h("p", { children: [
						E(e.rid),
						" · ",
						t($.ui_firstGame),
						" ",
						t(n.firstGameScores?.[e.rid].total === 1 ? $.ui_onePoint : $.ui_points, { n: n.firstGameScores?.[e.rid].total ?? 0 }),
						" · ",
						t($.ui_campaignBonus),
						" ",
						t($.ui_points, { n: e.campaign })
					] }, e.rid)), M && /* @__PURE__ */ m("button", {
						type: "button",
						className: "clank-primary",
						onClick: () => D(M),
						children: t($.ui_continue)
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/games/clank/bot-context.ts
var xn = 1e4;
function Sn(e, t, n, r) {
	let i = r, a = i?.game === e.gameNumber && i.map === e.map && (i.turn ?? 0) <= e.turnNumber, o = e.players.find((e) => e.rid === n), s = a ? i.retired ?? [] : [], c = new Map((a ? i.cards ?? [] : []).filter((e) => !s.includes(e.uid)).map((e) => [e.uid, e]));
	for (let e of [
		...t.hand,
		...o.played,
		...o.discard
	]) s.includes(e.uid) || c.set(e.uid, e);
	return {
		game: e.gameNumber,
		map: e.map,
		turn: e.turnNumber,
		cards: [...c.values()],
		visits: a ? [...i.visits ?? []] : [],
		walked: a && i.turn === e.turnNumber ? [...i.walked ?? []] : [],
		retired: s
	};
}
function Cn(e, t, n = !0) {
	let r = n ? e.map(() => []) : e;
	n && e.forEach((e, t) => e.forEach((e) => r[e.to].push({
		to: t,
		cost: e.cost
	})));
	let i = e.map(() => xn), a = e.map(() => !1);
	t.forEach((e) => {
		i[e] = 0;
	});
	for (let t = 0; t < e.length; t++) {
		let t = -1;
		for (let n = 0; n < e.length; n++) !a[n] && (t < 0 || i[n] < i[t]) && (t = n);
		if (t < 0 || i[t] >= 1e4) break;
		a[t] = !0;
		for (let e of r[t]) i[e.to] = Math.min(i[e.to], i[t] + e.cost);
	}
	return i;
}
function wn(e, t, n, r, i) {
	let a = e.players.find((e) => e.rid === n), o = W[e.map], s = (e) => a.items.some((t) => t.kind === e), c = (t) => e.turn.flags.includes(t), l = e.blackBag + e.players.reduce((e, t) => e + t.bag + t.clank, 0), u = [
		2,
		2,
		3,
		3,
		4,
		4,
		5
	][e.rage] + e.row.filter((e) => e && j[e.kind].danger).length, d = u * (a.bag + a.clank) / Math.max(1, l), f = 10 - a.damage, p = i.caution * (.25 + d / Math.max(1, f) + Math.max(0, a.damage - 4) * .2), m = i.caution * (1.7 + a.damage * .55 + d * 1.2), h = i.noise * (.25 + u / Math.max(8, l) * m * 2), g = r.cards, _ = a.deckCount + a.handCount + a.played.length + a.discard.length, v = Math.max(1, g.reduce((e, t) => e + j[t.kind].boots + j[t.kind].play.reduce((e, t) => e + (t.op === "gain" && t.resource === "boots" ? t.n : +(t.op === "teleport")), 0), 0) / Math.max(10, g.length) * 5), y = e.countdown ? Math.max(.5, 3.5 - e.countdown.step) : Math.max(2, Math.min(12, (f - 1) / Math.max(.35, d * .7))), b = o.rooms.map((t) => Ee(e, t.id, !1).flatMap(({ room: n, tunnel: r }) => {
		let l = t.id === a.room && c("ignoreIcons");
		if (r.locked && !s("key") && !l || r.elevator && a.gold === 0 || n === 0 && !a.artifacts.length) return [];
		let u = t.water && o.rooms[n].water && !s("scuba");
		return [{
			to: n,
			cost: Math.max(r.boots ?? 1, u ? 2 : 1) + (r.monsters ?? 0) * (.22 + p * .6) + Number(e.webs.includes(r.id)) * .5 + Number(!!o.rooms[n].cave) * v * .55 + (r.clank ?? 0) * h / i.tempo + (r.curse ?? 0) * 2 / i.tempo + Number(!!r.elevator) / i.tempo,
			tunnel: r
		}];
	})), x = Cn(b.map((t, n) => n === 0 || t.some((e) => e.to === 0) ? t : [...t, ...Ee(e, n, !1).filter((e) => e.room === 0 && (!e.tunnel.locked || s("key")) && (!e.tunnel.elevator || a.gold > 0)).map((e) => ({
		to: 0,
		cost: e.tunnel.boots ?? 1,
		tunnel: e.tunnel
	}))]), [0]), S = Cn(b, [a.room], !1), C = (t) => {
		let n = o.rooms[t], i = e.rooms.find((e) => e.id === t), s = r.visits.filter((e) => e === t).length;
		return (n.webbed ? .75 : 1) * ((i.secrets ? n.major ? 4.8 : 3 : i.idols[0] ?? 0) + (n.heal ? Math.min(a.damage, n.heal) * m : 0) / (1 + s) + (n.gold ?? 0) / (1 + s * 3));
	}, w = 1 + a.items.filter((e) => e.kind === "backpack").length, T = a.artifacts.length ? 0 : -1, E = -Infinity;
	if (a.artifacts.length < w) for (let t of e.rooms) {
		if (!t.artifacts.length || S[t.id] >= 1e4 || x[t.id] >= 1e4) continue;
		let n = S[t.id] + x[t.id], r = Math.max(0, n / v - y) * (e.countdown ? 20 : 4), o = 24 + t.artifacts[0] * i.artifact + C(t.id) - S[t.id] * i.tempo - x[t.id] * (i.tempo * .22 + p) - r;
		o > E && (E = o, (!a.artifacts.length || o > 16 + x[a.room] * .7) && (T = t.id));
	}
	T < 0 && (T = e.rooms.filter((e) => e.artifacts.length).sort((e, t) => S[e.id] - S[t.id])[0]?.id ?? 0);
	let D = Cn(b, [T]), O = T, k = !!e.countdown || f <= 2 + d || a.artifacts.length > 0 && x[a.room] / v >= y - 1;
	if (!k && D[a.room] < 1e4) {
		let e = 1.3;
		for (let t of o.rooms) {
			if (t.id === a.room || S[t.id] >= 1e4 || D[t.id] >= 1e4 || r.walked.includes(t.id)) continue;
			let n = S[t.id] + D[t.id] - D[a.room];
			if (n > v * (a.artifacts.length ? 1.8 : 1.2) || x[t.id] / v > y - 1) continue;
			let o = C(t.id) * i.detour - Math.max(0, n) * (i.tempo + p) - S[t.id] * .2;
			o > e && (e = o, T = t.id);
		}
		D = Cn(b, [T]);
	}
	let A = Math.min(y, Math.max(1, (a.artifacts.length ? x[a.room] : S[T] + x[T]) / v + (k ? 0 : 1.5))), M = Math.max(0, (A * 5 - a.deckCount) / Math.max(10, _ + 2)), N = a.artifacts.reduce((e, t) => e + t, 0) + a.gold + a.items.reduce((e, t) => e + t.points, 0) + 20, ee = o.rooms[a.room];
	return {
		pub: e,
		priv: t,
		p: a,
		map: o,
		memory: r,
		w: i,
		has: s,
		flag: c,
		cubes: l,
		exposure: d,
		health: f,
		risk: p,
		damageValue: m,
		noiseValue: h,
		mobility: v,
		rounds: y,
		graph: b,
		home: x,
		outward: S,
		target: T,
		primaryTarget: O,
		goalDistance: D,
		urgent: k,
		remaining: A,
		cycles: M,
		known: g,
		treasure: N,
		roomReward: C,
		room: ee
	};
}
function Tn(e, t, n) {
	return Cn(wn({
		...e.pub,
		gears: e.pub.gears.map((e) => e.id === t ? {
			...e,
			orientation: n
		} : e)
	}, e.priv, e.p.rid, e.memory, e.w).graph, [e.target])[e.p.room];
}
function En(e, t, n, r, i) {
	let a = e.flag("ignoreIcons");
	return {
		boots: (a ? 1 : Math.max(t.boots ?? 1, e.room.water && n.water && !e.has("scuba") && !e.flag("scuba") ? 2 : 1)) + Number(i === "boot"),
		damage: (a || e.flag("ignoreMonsters") ? 0 : t.monsters ?? 0) - r,
		swords: r + Number(i === "sword"),
		noise: a ? 0 : t.clank ?? 0,
		curses: a ? 0 : t.curse ?? 0
	};
}
//#endregion
//#region src/games/clank/bot-values.ts
function Dn(e, t, n) {
	let { p: r, priv: i, pub: a } = e, o = [...r.played, ...r.discard];
	return (t === "companion" ? r.played.filter((e) => j[e.kind].type === "companion").length >= 2 : t === "artifact" ? r.artifacts.length > 0 : t === "crown" ? e.has("crown") : t === "idol" ? r.idols.length > 0 : t === "tome" ? o.some((e) => e.kind === "tome") : t === "gem" ? o.some((e) => j[e.kind].type === "gem") : t === "twoGems" ? o.filter((e) => j[e.kind].type === "gem").length >= 2 : t === "noise" ? r.clank > 0 : t === "secret" ? a.turn.secretFound : a.turn.featureUsed) ? 1 : n ? t === "artifact" ? .7 : t === "noise" || t === "feature" || t === "secret" ? .45 : t === "companion" ? Math.min(.85, [...e.known, ...i.hand].filter((e) => j[e.kind].type === "companion").length * .12) : .1 : 0;
}
function On(e, t, n, r = !1) {
	let { p: i, pub: a, w: o } = e;
	switch (t) {
		case "gold": return n;
		case "skill": return n * (r ? 1.15 : .95);
		case "swords": return n * o.swords * (r ? .7 : .5 + Number(a.turn.swords < 2) * .3);
		case "boots": return n * o.boots * (i.state === "active" ? !r && (a.turn.mined || a.turn.stopped && !e.flag("ignoreCave")) ? .15 : (e.urgent ? 4 : 2.6) / (r ? 1 : 1 + Math.max(0, a.turn.boots - e.goalDistance[i.room]) * .4) : 0);
		case "heal": return Math.min(i.damage, n) * (r ? e.damageValue * .55 : e.damageValue);
		case "clank": return n < 0 ? Math.min(-n, r ? 2 : i.clank + 1) * e.noiseValue : -n * e.noiseValue;
		case "curse": return n < 0 ? Math.min(i.curses, -n) * 2 : -n * 2;
		default: return 0;
	}
}
function kn(e, t) {
	let { p: n } = e;
	switch (t) {
		case "dragons-eye": return 10 * (e.urgent ? .65 : .9);
		case "dwarven-peddler": return [
			n.chalices > 0,
			n.eggs > 0,
			n.idols.length > 0
		].filter(Boolean).length >= 2 ? 4 : 1;
		case "the-duke": return Math.floor(n.gold / 5) + 1;
		case "wizard": return 2 * e.known.filter((e) => e.kind === "tome").length + e.cycles * .5;
		case "grand-plan": return n.items.length >= 3 ? 7 : n.items.length * 1.2;
		case "book-of-the-dead": return n.curses;
		case "purify": return e.pub.players.every((e) => e.rid === n.rid || n.curses < e.curses) ? 5 : 1;
		default: return j[t].points;
	}
}
function An(e) {
	let t = e.exposure * e.damageValue + (e.health <= e.exposure + 1 ? e.treasure * .3 : 0);
	return e.pub.players.filter((t) => t.rid !== e.p.rid && t.state === "active").reduce((t, n) => t + (n.bag + n.clank) / Math.max(1, e.cubes) * (1 + n.damage * .3), 0) - t;
}
function jn(e, t, n = !1, r = 0) {
	if (r > 5) return 0;
	let i = (t) => jn(e, t, n, r + 1);
	return t.reduce((t, r) => {
		switch (r.op) {
			case "gain": return t + (r.others ? (r.all ? On(e, r.resource, r.n, n) : 0) + (r.resource === "clank" ? r.n * .25 : -r.n * .15) : On(e, r.resource, r.n, n));
			case "draw": return t + r.n * 2.8 * e.w.draw;
			case "choose": return t + [...r.options].map((e) => i(e.effects)).sort((e, t) => t - e).slice(0, r.distinct ? r.times ?? 1 : 1).reduce((e, t) => e + t, 0) * (r.distinct ? 1 : r.times ?? 1);
			case "discard": {
				if (n) return t + Math.max(0, i(r.then) - r.n * 1.3);
				let a = e.priv.hand.map((t) => Mn(e, t.kind, !0)).sort((e, t) => e - t);
				return t + (a.length >= r.n ? i(r.then) - a.slice(0, r.n).reduce((e, t) => e + t, 0) : 0);
			}
			case "trash": return t + (e.cycles > .4 ? 3.5 : .5) * e.w.engine;
			case "teleport": return t + (r.water && !e.room.water ? +!!n : e.urgent ? 8 : 5);
			case "flag": return t + (r.flag === "ignoreCave" ? n || e.pub.turn.stopped ? 2.5 : 1 : r.flag === "ignoreIcons" ? 4 : r.flag === "scuba" ? e.room.water ? 4 : .5 : r.flag === "ignoreMonsters" ? 2 : e.p.curses ? 1 : .5);
			case "recall": return t + 4.5;
			case "acquire": return t + (n ? 5 : 6);
			case "adjacent": return t + 3 - (r.noise ?? 0) * e.noiseValue;
			case "peek": return t + 3.2 * e.w.draw;
			case "attack": return t + An(e);
			case "black": return t + Math.min(r.n, e.pub.blackRemoved) * .3;
			case "tome": return t + (e.p.gold >= (r.pay ?? 0) ? Math.min(r.n, e.pub.reserve.tome) * 7 - (r.pay ?? 0) : 0);
			case "organ": return t + e.exposure * .5;
			case "scorpion": return t + Math.max(0, 7 - e.p.curses);
			case "direWolf": return t + 1.5 - e.noiseValue * 3;
			case "dice": return t + 2 * e.pub.blackBag / Math.max(1, e.cubes);
			case "boomerang": return t + 2;
			case "replace": return t + 1;
			case "snack": return t + .5;
			case "roll": return t - .3;
			case "snackOffer": return t;
		}
	}, 0);
}
function Mn(e, t, n = !1) {
	let r = j[t];
	return On(e, "skill", r.skill, n) + On(e, "swords", r.swords, n) + On(e, "boots", r.boots, n) + jn(e, r.play, n) + (r.conditional ? Dn(e, r.conditional.when, n) * jn(e, r.conditional.effects, n) : 0);
}
function Nn(e, t) {
	let n = j[t];
	if (n.type === "monster" || n.type === "device") return Mn(e, t);
	let r = e.known.reduce((t, n) => t + Mn(e, n.kind, !0), 0) / Math.max(1, e.known.length), i = Math.min(3.5, e.cycles) * e.w.engine;
	return kn(e, t) + jn(e, n.acquire) + i * (Mn(e, t, !0) - r * .8) - +(n.points === 0 && !n.play.length && e.cycles < .25);
}
function Pn(e, t) {
	for (let n of e) {
		if (n.op === "choose") {
			let e = n.options.find((e) => e.id === t);
			if (e) return e.effects;
			for (let e of n.options) {
				let n = Pn(e.effects, t);
				if (n) return n;
			}
		}
		if (n.op === "discard") {
			let e = Pn(n.then, t);
			if (e) return e;
		}
	}
}
//#endregion
//#region src/games/clank/bot-weights.ts
var Fn = {
	tempo: 1.8,
	artifact: .7,
	detour: 1.5,
	caution: 1,
	engine: 1,
	draw: 1,
	noise: 1,
	boots: 1,
	swords: 1,
	shopping: 1,
	reserve: .7
};
//#endregion
//#region src/games/clank/bot.ts
function In(e = {}) {
	let t = {
		...Fn,
		...e
	};
	return ({ public: e, private: n }, r) => {
		if (!n?.actions.length) return null;
		let i = Sn(e, n, r.rid, r.memory), a = wn(e, n, r.rid, i, t), { p: o } = a, s = [
			...n.hand,
			...o.played,
			...o.discard
		], c = (e) => s.find((t) => t.uid === e)?.kind ?? "burgle", l = (e) => {
			let t = c(e);
			return Math.max(.15, a.cycles) * (2.5 - Mn(a, t, !0)) - kn(a, t);
		}, u = n.actions.flatMap((n) => {
			let r = n.type === "row" ? e.row[n.slot].kind : n.type === "reserve" ? n.card : null;
			return !r || j[r].type === "monster" ? [] : [{
				a: n,
				kind: r,
				cost: Math.max(0, j[r].cost - (j[r].type === "gem" ? o.played.filter((e) => e.kind === "gem-collector").length * 2 : 0)),
				value: Nn(a, r) * (n.type === "reserve" ? t.reserve : 1)
			}];
		}), d = (t, n) => {
			let r = Math.min(40, Math.max(0, t)), i = Array(r + 1).fill(0);
			return u.forEach((t, a) => {
				if (a === n && t.a.type !== "reserve" || t.value <= 0) return;
				let o = t.a.type === "reserve" ? Math.min(5, e.reserve[t.kind] - Number(u[n]?.kind === t.kind)) : 1;
				for (let e = 0; e < o; e++) for (let e = r; e >= t.cost; e--) i[e] = Math.max(i[e], i[e - t.cost] + t.value);
			}), i[r];
		}, f = new Map(u.map((t, n) => [t.a, t.value + d(e.turn.skill - t.cost, n)])), p = n.actions.some((e) => e.type === "move" && a.goalDistance[e.to] < a.goalDistance[o.room]), m = (r) => {
			switch (r.type) {
				case "continue": return 1e3;
				case "artifact": return a.primaryTarget === o.room || a.urgent ? 400 : -1;
				case "play": {
					let e = c(r.card), t = j[e], i = 100 + Mn(a, e) * 3;
					if (e === "stumble" && (i = 68), t.play.some((e) => e.op === "discard")) {
						let e = n.hand.filter((e) => e.uid !== r.card).map((e) => Mn(a, e.kind, !0));
						i = 96 + (e.length ? 8 - Math.min(...e) * 4 : 0);
					}
					return t.play.some((e) => e.op === "teleport" || e.op === "recall" || e.op === "boomerang" || e.op === "trash" || e.op === "acquire") && (i -= 30), t.play.some((e) => e.op === "attack") && An(a) < -5 && (i = 40), (e === "swagger" || e === "search" || e === "expedition-leader") && (i += 35), i;
				}
				case "potion": {
					if (r.potion === "heal1" || r.potion === "heal2") {
						let e = r.potion === "heal1" ? 1 : 2;
						return o.damage >= e && (o.damage >= 4 || a.urgent) ? 180 + a.damageValue : -10;
					}
					if (r.potion === "heroism" && o.damage >= 3) return 175;
					let t = !e.turn.mined && (!e.turn.stopped || a.flag("ignoreCave")) && o.state === "active";
					if (r.potion === "boots" || r.potion === "heroism") {
						if (!t) return -10;
						let n = a.graph[o.room].some((t) => a.goalDistance[t.to] < a.goalDistance[o.room] && (t.tunnel.boots ?? 1) <= e.turn.boots + 1);
						return !p && n ? 85 : a.urgent && e.turn.boots < a.goalDistance[o.room] ? 75 : -10;
					}
					return n.actions.some((t) => t.type === "move" && a.goalDistance[t.to] < a.goalDistance[o.room] && En(a, Te(e, a.map.tunnels[t.tunnel]), a.map.rooms[t.to], t.swords, t.web).damage > 0) || a.health <= 3 && t ? 90 : a.remaining <= 1.5 || o.state === "escaped" ? 32 : -10;
				}
				case "move": {
					let t = Te(e, a.map.tunnels[r.tunnel]), n = En(a, t, a.map.rooms[r.to], r.swords, r.web), s = a.goalDistance[o.room] - a.goalDistance[r.to];
					if (s <= 0 || a.goalDistance[r.to] >= 1e4) return -30 - n.damage * a.damageValue;
					let c = i.walked.filter((e) => e === r.to).length, l = a.map.rooms[r.to].heal ?? 0, u = n.damage >= a.health - a.exposure - .6 && !l && r.to !== 0, d = a.graph[r.to].filter((e) => a.goalDistance[e.to] < a.goalDistance[r.to]).reduce((e, t) => Math.max(e, t.tunnel.monsters ?? 0), 0), f = Math.max(0, n.swords + d - e.turn.swords) * .35;
					return 55 + Math.min(8, s) * 4 + a.roomReward(r.to) * .6 - n.damage * a.damageValue - n.noise * a.noiseValue - n.curses * 2 - f - c * 50 - Number(u) * (a.map.rooms[r.to].deep ? a.treasure * .4 : 8) + (r.to === 0 ? a.urgent ? 36 : 6 : 0);
				}
				case "rotate": {
					let e = Tn(a, r.gear, r.orientation);
					return e + 1 < a.goalDistance[o.room] ? 82 + Math.min(8, a.goalDistance[o.room] - e) : -20;
				}
				case "market": {
					let t = (e.market[r.item][0] ?? 0) - 7;
					return r.item === "key" && !a.has("key") && (t += a.urgent ? 2 : 9), r.item === "scuba" && !a.has("scuba") && (t += a.map.family === "sunken" ? 8 : 0), r.item === "ankh" && (t += Math.min(o.damage, 1) * a.damageValue), r.item === "timeWinder" && (t += Math.min(3, o.bag) * a.damageValue * .6), r.item === "backpack" && (t += !a.has("backpack") && !a.urgent && a.pub.rooms.some((e) => e.artifacts.length && a.outward[e.id] < 4) ? 8 : 0), t > .2 ? 75 + t : -5;
				}
				case "row": {
					let n = e.row[r.slot].kind, i = j[n];
					if (i.type === "monster") {
						let e = Nn(a, n) - i.cost * .45;
						return e > 0 ? 38 + e * 3 - Number(p) * 5 : -5;
					}
					let o = f.get(r) ?? 0;
					return Nn(a, n) > 0 ? 35 + o * 2 * t.shopping : -5;
				}
				case "reserve": return Nn(a, r.card) > 0 ? 35 + (f.get(r) ?? 0) * 2 * t.shopping : -5;
				case "fight": return 25 + (r.monster === "mummyCleanse" ? Math.ceil(o.curses / 2) * 2 : r.monster === "mummyGold" ? 2 : r.monster === "goldfish" ? 3 : r.monster === "guardian" ? a.map.id === "jungle" ? 1 + 2 * n.apparatus.filter((e) => e === r.apparatus).length : 2 : 1) * 3;
				case "mine": {
					let t = a.map.mines.find((e) => e.id === r.mine), n = e.players.map((t) => e.mines.filter((e) => e.owner === t.rid).length), i = e.mines.filter((e) => e.owner === o.rid).length, s = i === 0 ? 7 : i < Math.max(...n) ? 3 : 1;
					return p && (a.urgent || e.turn.boots >= 2) ? -2 : 35 + t.gold + s;
				}
				case "cache": return 36 + (r.cache >= 4 ? 7 : 0) + (r.cache === 0 ? 5 : r.cache < 4 ? 3 : 1) + (r.cache === 3 || r.cache === 4 ? On(a, "heal", 1) : 0);
				case "spring": return n.hand.length ? 45 + l(r.card) : 120 + l(r.card);
				case "resolve": {
					if (e.choice?.kind === "choose") {
						let t = j[e.choice.source], n = t ? Pn([
							...t.play,
							...t.acquire,
							...t.conditional?.effects ?? []
						], r.option) : void 0;
						if (n) return jn(a, n);
					}
					if (r.option === "discard") return -Mn(a, c(r.target)) + jn(a, j[c(r.target)].discard);
					if (r.option === "trash") return l(r.target);
					if (r.option === "recall") return Mn(a, c(r.target));
					if (r.option === "teleport") return Math.min(100, a.goalDistance[o.room]) - Math.min(100, a.goalDistance[r.target]) + a.roomReward(r.target) * .25 + (r.target === 0 ? 10 : 0);
					if (r.option === "take") return a.roomReward(o.room) - Number(!!a.room.webbed) * .6;
					if (r.option === "adjacent") return a.roomReward(r.target);
					if (r.option === "acquire") return Nn(a, e.row[r.target].kind);
					if (r.option === "replace") return -Nn(a, e.row[r.target].kind);
					if (r.option === "attack") return An(a);
					if (r.option === "skip") return 0;
					if (r.option === "pay") return On(a, "heal", 1) - 1.2;
					if (r.option === "organ") return r.target < 0 ? a.exposure + .1 : An(a) * .2;
					if (r.option === "top" || r.option === "bottom") return r.option === "bottom" && n.peek ? 2 - Mn(a, n.peek.kind) : 0;
					let [t, i] = r.option.split(":");
					return i === void 0 ? 0 : On(a, t, Number(i));
				}
				case "end": return 0;
				case "tick": return -100;
			}
		}, h = n.actions[0], g = -Infinity;
		for (let e of n.actions) {
			let t = m(e);
			t > g && (g = t, h = e);
		}
		if ((h.type === "move" || h.type === "resolve" && h.option === "teleport") && (i.walked.push(o.room), i.visits.push(h.type === "move" ? h.to : h.target), i.visits = i.visits.slice(-120)), h.type === "spring" || h.type === "resolve" && h.option === "trash") {
			let e = h.type === "spring" ? h.card : h.target;
			i.cards = i.cards.filter((t) => t.uid !== e), i.retired = [...i.retired, e];
		}
		return {
			action: h,
			memory: i
		};
	};
}
var Ln = In(), Rn = (e, t, n) => dn(e, t.public, t.private, n);
//#endregion
//#region src/games/clank/endgame-review.tsx
function zn({ board: e, renderResult: t, ...n }) {
	let r = d(), [c, l] = s(!0), [u, f] = s(null), p = o(null), _ = o(null), b = o(null);
	i(() => {
		if (!u) return;
		b.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let x = (e) => {
		f(null), l(e), requestAnimationFrame(() => (e ? p : _).current?.focus({ preventScroll: !0 }));
	}, S = a(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...S
	};
	return /* @__PURE__ */ h("div", {
		className: "clank-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ m("div", {
				className: "clank-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ m("div", {
				className: "clank-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ h("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "clank-endgame-panel",
					"aria-label": r("session.result.title"),
					children: [
						/* @__PURE__ */ h("header", {
							className: "clank-endgame-heading",
							children: [/* @__PURE__ */ h("div", {
								className: "clank-endgame-brand",
								children: [/* @__PURE__ */ m("span", {
									"aria-hidden": "true",
									children: lt.icon
								}), r(lt.nameKey)]
							}), /* @__PURE__ */ m("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": r("games.clank.reviewHide"),
								title: r("games.clank.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ m(v, { size: 19 })
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "clank-endgame-result",
							inert: u !== null,
							children: t(C)
						}),
						u && /* @__PURE__ */ h("div", {
							className: "clank-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ m("button", {
								type: "button",
								ref: b,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									f(null), e();
								},
								children: r(u.label === "again" ? "games.clank.reviewConfirmAgain" : "games.clank.reviewConfirmLobby")
							}), /* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: r("games.clank.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "clank-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ m(y, { size: 18 }),
						r("games.clank.reviewShow"),
						/* @__PURE__ */ m(g, { size: 18 })
					]
				})
			})
		]
	});
}
function Bn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: c, renderRowExtra: l, summary: f, navigation: g, content: y, afterRanking: b, scoreUnit: x, rankOf: S }) {
	let C = d(), w = u((e) => e.locale), [D, O] = s({}), k = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? T(n, w) : e;
	}, A = (t, n) => S?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), j = e.ranking.some((t) => e.scores?.[t] !== void 0), M = (t, n) => /* @__PURE__ */ h("div", {
		className: "clank-score-identity",
		children: [
			/* @__PURE__ */ h("span", {
				className: "clank-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ m("span", {
					"aria-label": C("games.clank.reviewWinner"),
					children: "♛ "
				}), j && A(t, n)]
			}),
			/* @__PURE__ */ h("span", {
				className: "clank-score-name",
				children: [k(t), t === r && /* @__PURE__ */ m("small", { children: C("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ h("small", {
				className: "clank-score-autopilot",
				children: [
					/* @__PURE__ */ m(_, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), N = (t) => e.ranking.map((n) => /* @__PURE__ */ m("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ h("div", {
		className: "clank-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ m(E, {}),
			g,
			/* @__PURE__ */ h("div", {
				className: "clank-score-body",
				children: [
					f && /* @__PURE__ */ m("div", {
						className: "clank-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ m("p", {
						className: "clank-score-hints",
						children: C("session.hint.usedCount", { n: i })
					}),
					y ?? (c?.length ? /* @__PURE__ */ m("div", {
						className: "clank-score-table-scroll",
						children: /* @__PURE__ */ h("table", {
							className: "clank-score-table",
							"aria-label": C(lt.nameKey),
							children: [
								/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { scope: "col" }), /* @__PURE__ */ m(p, { children: e.ranking.map((t, n) => /* @__PURE__ */ m("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: M(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ m("tbody", { children: c.map((e, t) => /* @__PURE__ */ h(n, { children: [/* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ h("button", {
										type: "button",
										"aria-expanded": !!D[t],
										onClick: () => O((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ m(v, { size: 15 }), e.label]
									}) : e.label
								}), N(e)] }), D[t] && e.details?.map((e, t) => /* @__PURE__ */ h("tr", {
									className: "clank-score-sub",
									children: [/* @__PURE__ */ m("th", {
										scope: "row",
										children: e.label
									}), N(e)]
								}, t))] }, t)) }),
								j && /* @__PURE__ */ m("tfoot", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: C("games.clank.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ m("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ m("ol", {
						className: "clank-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ h("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ h("div", {
								className: "clank-score-rankline",
								children: [M(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ h("strong", {
									className: "clank-score-points",
									children: [e.scores[t], x && /* @__PURE__ */ m("small", { children: x })]
								})]
							}), l?.(t)]
						}, t))
					})),
					b,
					!!c?.length && l && /* @__PURE__ */ m("div", {
						className: "clank-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ h("details", { children: [/* @__PURE__ */ m("summary", { children: k(e) }), l(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ h("footer", {
				className: "clank-score-actions",
				children: [
					o && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: C("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: C("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ m("p", { children: C("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/clank/endgame-scores.tsx
function Vn(e) {
	let t = d(), n = e.public, r = [
		"artifacts",
		"gold",
		"cards",
		"tokens",
		"market",
		"mastery",
		"curses",
		"mining",
		"apparatus",
		"campaign"
	].map((e) => ({
		label: t($[`score_${e}`]),
		value: (t) => n.scores?.[t]?.eligible ? n.scores[t][e] : "—"
	}));
	return /* @__PURE__ */ m(Bn, {
		...e,
		rows: r,
		renderRowExtra: (e) => n.scores?.[e] && !n.scores[e].eligible ? /* @__PURE__ */ m("p", { children: t($.ui_noScore) }) : null
	});
}
//#endregion
//#region src/games/clank/game-over.tsx
function Hn(e) {
	return /* @__PURE__ */ m(Vn, { ...e });
}
function Un(e) {
	return /* @__PURE__ */ m(zn, {
		...e,
		board: /* @__PURE__ */ m(bn, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ m(Hn, { ...e })
	});
}
//#endregion
//#region src/games/clank/game-over-row.tsx
function Wn({ public: e, rid: t }) {
	let n = d(), r = e.scores?.[t];
	return r ? /* @__PURE__ */ m("div", {
		className: "flex flex-wrap gap-x-3 gap-y-1 text-xs",
		children: r.eligible ? Object.keys(r).filter((e) => e !== "eligible" && e !== "total" && r[e] !== 0).map((e) => /* @__PURE__ */ h("span", { children: [
			n($[`score_${e}`]),
			" ",
			r[e]
		] }, e)) : n($.ui_noScore)
	}) : null;
}
//#endregion
//#region src/games/clank/options.tsx
function Gn({ value: e, onChange: t }) {
	let n = d(), r = Xe.safeParse(e), i = r.success ? r.data : Xe.parse(void 0), a = (e) => {
		let n = {
			...i,
			[e]: !i[e]
		};
		n.apeLords || (n.campaign = !1);
		let r = W[n.map].family;
		r !== "base" && !n[r] && (n.map = "base-front"), n.campaign && (n.map = "jungle"), t(n);
	};
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ m(O, {
				title: n($.options_expansions),
				children: [
					"sunken",
					"mummy",
					"goldSilk",
					"apeLords",
					"promo"
				].map((e) => /* @__PURE__ */ m(k, {
					checked: i[e],
					label: n($[`options_${e}`]),
					accent: lt.accent,
					onChange: () => a(e)
				}, e))
			}),
			i.apeLords && /* @__PURE__ */ m(O, {
				title: n($.options_apeLords),
				children: /* @__PURE__ */ m(k, {
					checked: i.campaign,
					label: n($.options_campaign),
					accent: lt.accent,
					onChange: () => a("campaign")
				})
			}),
			!i.campaign && /* @__PURE__ */ m(O, {
				title: n($.options_map),
				children: Se.filter((e) => e.family === "base" || i[e.family]).map((e) => /* @__PURE__ */ m(D, {
					name: "clank-map",
					value: e.id,
					checked: i.map === e.id,
					label: n(Ce[e.id]),
					accent: lt.accent,
					onChange: () => t({
						...i,
						map: e.id
					})
				}, e.id))
			})
		]
	});
}
//#endregion
//#region src/games/clank/guide.tsx
function Kn() {
	let e = d();
	return /* @__PURE__ */ h("section", {
		className: "flex flex-col gap-2 text-sm leading-relaxed",
		"aria-labelledby": "clank-symbol-guide",
		children: [/* @__PURE__ */ m("h3", {
			id: "clank-symbol-guide",
			className: "font-extrabold",
			children: e($.guide_symbols)
		}), /* @__PURE__ */ m("ul", {
			className: "grid grid-cols-2 gap-x-4 gap-y-1",
			children: [
				["🐉", $.ui_dragonAttack],
				["⚠", $.ui_danger],
				["⬇", $.ui_deep],
				["◆", $.ui_cave],
				["≈", $.ui_water]
			].map(([t, n]) => /* @__PURE__ */ h("li", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ m("span", {
					"aria-hidden": !0,
					children: t
				}), /* @__PURE__ */ m("span", { children: e(n) })]
			}, n))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/clank/entry.tsx
var qn = {
	definition: ht,
	View: bn,
	bot: Ln,
	describe: Rn,
	OverView: Un,
	RowView: Wn,
	Options: Gn,
	Guide: Kn,
	locales: {
		zh: {
			possessions: {
				artifactName: "神器",
				idolName: "神像",
				quantity: "数量：{{n}}",
				purchaseCost: "购买费用：{{n}} 枚金币",
				endPoints: "终局分值：{{n}} 分",
				hiddenApparatus: "持有 {{n}} 件器具，种类未公开。",
				key: "持有时，可以通过带锁的通道。",
				backpack: "持有时，神器携带上限增加一件。",
				crown: "按王冠上标示的分值计分。购买时取得市场中分值最高的剩余王冠。",
				scuba: "持有时，在两个水域房间之间移动所需的最低移动力由 2 点降为 1 点，仍须支付通道上的其他费用；在水下结束回合时不会受到缺氧伤害。",
				ankh: "购买时，恢复 1 点生命。",
				timeWinder: "购买时，从龙袋中取回最多 3 个自己的方块，放回个人供给区。",
				heal1: "在自己的回合使用，恢复 1 点生命。使用后消耗。",
				heal2: "在自己的回合使用，恢复 2 点生命。使用后消耗。",
				boots: "在自己的回合使用，获得 1 点移动力。使用后消耗。",
				swords: "在自己的回合使用，获得 2 点战斗力。使用后消耗。",
				heroism: "在自己的回合使用，获得 1 点移动力和 1 点战斗力，并恢复 1 点生命。使用后消耗。",
				gold2: "获得时，2 枚金币计入金币余额，可以用于购买物品；游戏结束时，剩余金币每枚计 1 分。",
				gold5: "获得时，5 枚金币计入金币余额，可以用于购买物品；游戏结束时，剩余金币每枚计 1 分。",
				skill2: "获得时，立即获得 2 点技能，仅限本回合使用。",
				skill5: "获得时，立即获得 5 点技能，仅限本回合使用。",
				draw3: "获得时，立即抽取 3 张牌。",
				chalice: "保留至游戏结束，每个圣杯计 7 分。圣杯不是神器。",
				spring: "本回合结束前，从打出区或弃牌堆中选择一张卡牌销毁。使用后消耗。",
				egg: "获得时，巨龙怒气提高一级。保留至游戏结束，每枚龙蛋计 3 分。",
				scarab: "获得时，掷金字塔骰并按结果移动木乃伊。保留至游戏结束，每只圣甲虫计 3 分。",
				mummyGold: "获得时，5 枚金币计入金币余额，并掷金字塔骰，按结果移动木乃伊。剩余金币每枚计 1 分。",
				mummyChalice: "获得时，掷金字塔骰并按结果移动木乃伊。保留至游戏结束，每个圣杯计 7 分。圣杯不是神器。",
				artifact: "获得时，巨龙怒气提高一级。持有神器才能返回入口撤离，并取得终局计分资格；在地下城深处倒下仍不能计分。神器按标示分值计分。",
				idol: "保留至游戏结束，按标示分值计分。神像不是神器。",
				web: "穿越蛛网时，额外支付 1 点移动力或 1 点战斗力并收集它。游戏结束时，按蛛网上的分值计分。",
				apparatusJungle: "保留至游戏结束。同类器具的总分为数量的平方，例如 2 件计 4 分、3 件计 9 分。",
				apparatusTemple: "在相连房间中，可以消耗与齿轮符号相同的一件器具来旋转齿轮。神庙中的器具不直接计分。"
			},
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "噤声寻宝记",
			desc: "深入龙穴构筑牌库，夺取神器并在巨龙追击前撤离。",
			errorAction: "该操作当前不可用。",
			ui: {
				moveDamage: "受到 {{n}} 点伤害",
				overview: "查看全图",
				locate: "定位自己",
				mapTools: "地图工具",
				dragonAttack: "巨龙袭击",
				blackCube: "黑色方块",
				danger: "危险",
				cancel: "取消",
				close: "关闭",
				chooseMove: "选择移动方式",
				playHand: "选择一张手牌打出",
				selectMove: "选择要前往的高亮房间",
				noisePool: "噪音区",
				turn: "第 {{n}} 回合",
				yourTurn: "轮到你行动",
				waiting: "等待 {{name}} 行动",
				resolving: "正在结算",
				intermission: "第一局结束",
				continue: "开始神庙对局",
				hand: "手牌",
				played: "打出区",
				dungeon: "地下城公共牌列",
				supplies: "常备牌与市场",
				actions: "可用操作",
				inspect: "卡牌详情",
				confirm: "确认操作",
				end: "结束回合",
				play: "打出",
				acquire: "获取",
				defeat: "击败",
				artifact: "拾取神器",
				market: "购买市场物品",
				mine: "采矿",
				cache: "蛛后宝库",
				rotate: "旋转齿轮",
				potion: "使用药水",
				spring: "在魔法泉销毁卡牌",
				move: "移动至房间 {{n}}",
				room: "房间 {{n}}",
				moveCost: "消耗 {{boots}} 点移动力、{{swords}} 点战斗力和 {{gold}} 枚金币，受到 {{damage}} 点伤害",
				skill: "技能",
				swords: "战斗力",
				boots: "移动力",
				health: "生命",
				gold: "金币",
				clank: "噪音",
				bag: "龙袋中的方块",
				rage: "怒气等级 {{n}}",
				deck: "牌库",
				discard: "弃牌堆",
				log: "对局记录",
				player: "玩家详情",
				secrets: "秘密",
				idols: "神像",
				water: "水域",
				cave: "水晶洞穴",
				deep: "深处",
				surface: "地表",
				entrance: "入口",
				web: "蛛网",
				curse: "诅咒",
				apparatus: "器具",
				remaining: "地下城牌库剩余 {{n}} 张",
				cost: "费用：{{n}}",
				points: "{{n}} 分",
				onePoint: "1 分",
				inspectCard: "查看“{{card}}”的详情",
				noAction: "当前没有可用操作",
				choose: "选择效果或目标",
				take: "拾取奖励",
				skip: "放弃奖励",
				zoomIn: "放大地图",
				zoomOut: "缩小地图",
				resetMap: "重置地图",
				map: "地图",
				countdown: "撤离倒计时 {{n}} / 4",
				mummy: "木乃伊区域 {{n}}",
				escaped: "已撤离",
				knocked: "已倒下",
				active: "探索中",
				firstGame: "丛林对局得分",
				campaignBonus: "战役奖励分",
				noScore: "没有神器，或在地下城深处倒下，不能计分。",
				details: "详情",
				reveal: "获得的奖励",
				spendBoots: "消耗 {{n}} 点移动力",
				spendSwords: "消耗 {{n}} 点战斗力",
				spendGold: "支付 {{n}} 枚金币",
				makeClank: "制造 {{n}} 点噪音",
				gainCurse: "获得 {{n}} 个诅咒",
				handCount: "手牌 {{n}} 张",
				deckCount: "牌库 {{n}} 张",
				bagCount: "龙袋中的方块 {{n}} 个",
				noiseCount: "噪音区的方块 {{n}} 个",
				curseCount: "诅咒 {{n}} 个",
				healthCount: "生命 {{n}} / 10",
				goldCount: "金币 {{n}} 枚",
				artifactValues: "神器分值：{{values}}",
				idolValues: "神像分值：{{values}}",
				secretCount: "剩余秘密：{{n}} 个",
				none: "无",
				websCollected: "收集的蛛网分值：{{values}}",
				openDungeon: "查看公共牌",
				openActions: "其他行动",
				moveSeparator: "；",
				inventory: "持有物品",
				suppliesCount: "供给区方块 {{n}} 个"
			},
			options: {
				expansions: "扩展内容",
				sunken: "沉没宝藏",
				mummy: "木乃伊的诅咒",
				goldSilk: "黄金与蛛丝",
				apeLords: "猿王神庙",
				promo: "工坊促销卡（13 张）",
				campaign: "双局战役：先丛林，后神庙",
				map: "地图"
			},
			maps: {
				baseFront: "基础版正面",
				baseBack: "基础版背面",
				sunkenBoat: "沉船",
				sunkenSewer: "下水道",
				mummyPyramid: "金字塔",
				mummySphinx: "狮身人面像",
				spiderLair: "蛛后巢穴",
				dwarvenMine: "矮人矿坑",
				jungle: "丛林",
				temple: "神庙"
			},
			items: {
				key: "万能钥匙",
				backpack: "背包",
				crown: "王冠",
				scuba: "潜水装备",
				ankh: "生命之符",
				timeWinder: "时光装置",
				heal1: "小型治疗药水",
				heal2: "大型治疗药水",
				boots: "迅捷药水",
				swords: "力量药水",
				heroism: "英雄药水",
				goblin: "哥布林",
				goldfish: "金鱼",
				mummyGold: "木乃伊",
				mummyCleanse: "木乃伊",
				guardian: "青铜守卫",
				cog: "齿轮",
				wrench: "猴子扳手",
				banana: "香蕉",
				gold2: "2 枚金币",
				gold5: "5 枚金币",
				skill2: "2 点技能",
				skill5: "5 点技能",
				draw3: "抽取 3 张牌",
				chalice: "圣杯",
				spring: "魔法泉",
				egg: "龙蛋",
				scarab: "圣甲虫",
				mummyChalice: "木乃伊圣杯"
			},
			choice: {
				discard: "从手牌中弃置一张牌",
				trash: "从打出区或弃牌堆中销毁一张牌",
				teleport: "选择传送目的地",
				adjacent: "选择相邻房间的奖励",
				acquire: "选择免费获取的卡牌",
				replace: "选择要替换的地下城公共牌",
				recall: "选择加入手牌的弃牌",
				peek: "决定牌库顶牌的位置",
				entry: "拾取房间奖励",
				snack: "向“点心桌”的使用者支付 1 枚金币，恢复 1 点生命",
				organ: "调整怒气",
				choose: "选择奖励",
				top: "留在牌库顶部并抽取",
				bottom: "移至牌库底部并抽取一张牌",
				pay: "支付 1 枚金币并恢复 1 点生命",
				skip: "放弃",
				take: "领取奖励",
				attack: "触发一次巨龙袭击",
				waterTeleport: "从水域传送至相邻房间",
				tomePaid: "支付 7 枚金币，获得 2 张“秘密典籍”",
				up: "将怒气提高一级",
				down: "将怒气降低一级",
				gain: "获得 {{resource}}",
				remove: "移除 {{resource}}",
				gear: "将齿轮 {{n}} 转至方向 {{orientation}}",
				cache: "领取宝库奖励 {{n}}：{{reward}}"
			},
			score: {
				artifacts: "神器",
				gold: "金币",
				cards: "卡牌",
				tokens: "秘密与收藏",
				market: "市场物品",
				mastery: "撤离奖励",
				curses: "诅咒",
				mining: "采矿奖励",
				apparatus: "器具",
				campaign: "战役奖励",
				total: "总分"
			},
			events: {
				play: "{{name}} 打出“{{card}}”",
				move: "{{name}} 进入房间 {{n}}",
				acquire: "{{name}} 获取“{{card}}”",
				defeat: "{{name}} 击败“{{card}}”",
				artifact: "{{name}} 拾取了价值 {{n}} 分的神器",
				secret: "{{name}} 找到了{{card}}",
				market: "{{name}} 购买了“{{card}}”",
				mine: "{{name}} 采矿，获得 {{n}} 枚金币",
				web: "{{name}} 清除了蛛网",
				rotate: "齿轮发生旋转",
				dragon: "巨龙袭击，抽取 {{n}} 个方块",
				damage: "{{name}} 受到 {{n}} 点伤害",
				escape: "{{name}} 成功撤离",
				knockout: "{{name}} 倒下了",
				mummy: "木乃伊进入区域 {{n}}",
				round: "新的回合开始",
				campaign: "神庙战役开始",
				rotatePlayer: "{{name}} 旋转了齿轮 {{n}}"
			},
			guide: {
				symbols: "牌面标记",
				cache: "蛛后宝库奖励",
				cacheText: "每次支付 8 点技能，并放置 1 个个人供给区的方块。每项奖励整局只能领取一次。",
				cache1: "获得 5 枚金币。",
				cache2: "获得 3 枚金币和 1 点战斗力。",
				cache3: "获得 3 枚金币和 1 点移动力。",
				cache4: "获得 3 枚金币，恢复 1 点生命。",
				cache5: "获得 1 张“秘密典籍”，恢复 1 点生命。",
				cache6: "获得 1 张“秘密典籍”和 1 枚金币。",
				cache7: "获得 1 张“秘密典籍”和 1 枚金币。",
				cache8: "获得 1 张“秘密典籍”和 2 枚金币。"
			},
			rules: "游戏目标：\n深入地下城取得神器，返回入口撤离。游戏结束时，在有计分资格的玩家中，总分最高者获胜。\n开局准备：\n每人有 10 点生命和 10 张初始牌，洗牌后抽取 5 张。启用的扩展卡牌加入地下城牌库，专属组件按所选地图布置。\n回合行动：\n出牌、移动、获取卡牌、战斗和购买物品可以交错进行。打出手牌后，获得牌面所示的技能、战斗力、移动力及其他效果。\n· 支付技能获取地下城公共牌或常备牌，新获得的卡牌放入弃牌堆。\n· 支付战斗力击败怪物，立即获得奖励；怪物牌不加入个人牌库。\n· 支付技能使用装置牌，立即结算效果；装置牌不加入个人牌库。\n· 在市场房间中，每件市场物品的价格为 7 枚金币。\n结束回合前必须打出全部手牌，并用完已获得的魔法泉销毁机会。回合结束时弃置打出区的牌，再抽取 5 张牌。未使用的技能、战斗力和移动力不会保留到下回合，金币保留。\n需要抽牌但牌库为空时，将弃牌堆洗混，组成新的牌库。\n移动与房间：\n沿通道进入相邻房间，通常消耗 1 点移动力，脚印表示所需数量。通道每有一个怪物图标，需要支付 1 点战斗力，否则受到 1 点伤害。通过带锁的通道需要万能钥匙，通过升降梯需要支付 1 枚金币。\n进入水晶洞穴后，本回合不能继续使用移动力，除非卡牌效果允许。传送不消耗移动力，可以越过通道限制，但目的地仍须是相邻房间。\n进入房间时可以领取秘密或神像，神器需要在所在房间主动拾取。通常只能携带一件神器，每个背包将携带上限增加一件。携带神器返回入口即成功撤离，没有神器不能返回入口。\n巨龙袭击：\n每制造 1 点噪音，将个人供给区的 1 个方块放入噪音区。移除噪音时收回噪音区的方块；不足的部分抵消本回合之后的噪音。袭击开始时，将所有玩家噪音区的方块放入龙袋。\n回合末补齐地下城公共牌列，并结算新牌的到来效果。本次补牌中只要出现巨龙袭击标记，补牌结束后触发一次袭击，不因同时出现多个标记重复触发。\n按怒气等级抽取方块，公共牌列中每张危险牌使抽取数量增加一个。每抽到自己的一个方块，受到 1 点伤害；黑色方块不会造成伤害。抽出的方块离开龙袋。拾取神器或龙蛋会提高怒气。\n撤离与计分：\n生命降至零，或承受通道等伤害时供给方块不足，玩家倒下。首位撤离或倒下的玩家触发撤离倒计时。此后每轮轮到该玩家时触发袭击，前三次依次多抽 1、2、3 个方块；第四次轮到该玩家，所有仍在探索的玩家倒下。地下城牌库耗尽也会使所有仍在探索的玩家倒下。\n全部玩家撤离或倒下后，游戏结束。没有神器，或在地下城深处倒下，均不能计分；携带神器在地表倒下，仍可计分。\n· 神器、卡牌、市场物品和收藏按各自分值计分，每枚金币计 1 分。\n· 成功撤离额外获得 20 分，每个诅咒扣除 2 分。\n总分相同，最高分神器较高者获胜；仍相同则并列。\n沉没宝藏：\n在两个水域房间之间移动，通常至少消耗 2 点移动力。如果在水域开始回合，且整回合未进入有空气的房间，回合末受到 1 点伤害。潜水装备免除缺氧伤害及水域移动的额外费用。\n木乃伊的诅咒：\n与木乃伊处于同一区域时，可以选择以下一种方式与它战斗。\n· 支付 2 点战斗力，获得 4 枚金币和 1 个诅咒。\n· 支付 3 点战斗力，移除一半诅咒，移除数量向上取整。\n每次战斗后投掷金字塔骰。木乃伊移入新区域时，该区域玩家获得 1 个诅咒。\n黄金与蛛丝：\n清除通道蛛网需要额外支付 1 点移动力或战斗力，并收集该蛛网。领取被蛛网覆盖的房间奖励，需要支付 1 点战斗力。蛛网按标示分值计分。\n在矿脉相邻房间中，支付 2 点技能和 1 个个人供给区的方块采矿，获得所示金币。每条矿脉整局只能开采一次，采矿后本回合不能再使用移动力。\n有计分资格的采矿者按矿脉数量排名，前三名额外获得 20、10、5 分。矿脉数量相同，开采过的最深矿脉较深者优先。\n猿王神庙：\n经过器具所在通道时收集器具，器具分为齿轮、猴子扳手和香蕉。在丛林地图中，每类器具分别按数量的平方计分，三类分数相加；例如，两个齿轮和一个香蕉共计 5 分。支付 3 点战斗力击败青铜守卫，可以取得其剩余器具中的一件。\n在神庙地图中，在齿轮连接的房间消耗同符号器具，可以改变齿轮方向。器具不直接计分；怒气提高至特定等级时，也可能引发齿轮旋转。\n双局战役：\n先进行丛林对局，再进行神庙对局，第二局保留第一局收集的器具。第一局有计分资格的前三名，分别获得 20、10、5 分战役奖励。最终胜负按第二局得分及战役奖励决定，不累加第一局总分。\n蛛后宝库奖励：\n每次支付 8 点技能，并放置 1 个个人供给区的方块。每项奖励整局只能领取一次。\n· 奖励 1：获得 5 枚金币。\n· 奖励 2：获得 3 枚金币和 1 点战斗力。\n· 奖励 3：获得 3 枚金币和 1 点移动力。\n· 奖励 4：获得 3 枚金币，恢复 1 点生命。\n· 奖励 5：获得 1 张“秘密典籍”，恢复 1 点生命。\n· 奖励 6：获得 1 张“秘密典籍”和 1 枚金币。\n· 奖励 7：获得 1 张“秘密典籍”和 1 枚金币。\n· 奖励 8：获得 1 张“秘密典籍”和 2 枚金币。",
			cards: {
				burgle: {
					name: "潜窃",
					text: "获得 1 点技能。"
				},
				scramble: {
					name: "攀行",
					text: "获得 1 点技能和 1 点移动力。"
				},
				sidestep: {
					name: "侧步",
					text: "获得 1 点移动力。"
				},
				stumble: {
					name: "失足",
					text: "制造 1 点噪音。"
				},
				explore: {
					name: "探索",
					text: "获得 2 点技能和 1 点移动力。"
				},
				mercenary: {
					name: "佣兵",
					text: "获得 1 点技能和 2 点战斗力。"
				},
				tome: {
					name: "秘密典籍",
					text: "价值 7 分。"
				},
				"amulet-of-vigor": {
					name: "活力护符",
					text: "获得 4 点技能。\n获取时：恢复 1 点生命。\n价值 3 分。"
				},
				"animated-door": {
					name: "活化之门",
					text: "获得 1 点移动力。\n带有巨龙袭击标记。"
				},
				apothecary: {
					name: "药剂师",
					text: "从手牌中弃置 1 张牌，然后选择一项：\n· 获得 3 点战斗力。\n· 获得 2 枚金币。\n· 恢复 1 点生命。\n价值 2 分。"
				},
				archaeologist: {
					name: "考古学家",
					text: "抽取 1 张牌。\n若持有神像：获得 2 点技能。\n价值 1 分。"
				},
				blecher: {
					name: "打嗝怪",
					text: "获得 4 枚金币；制造 2 点噪音。\n带有巨龙袭击标记。"
				},
				"boots-of-swiftness": {
					name: "迅捷之靴",
					text: "获得 3 点移动力。\n获取时：获得 1 点移动力。\n价值 3 分。"
				},
				"bracers-of-agility": {
					name: "敏捷护腕",
					text: "抽取 2 张牌。\n价值 2 分。"
				},
				brilliance: {
					name: "灵光乍现",
					text: "抽取 3 张牌。"
				},
				"cave-troll": {
					name: "洞穴巨魔",
					text: "获得 3 枚金币；抽取 2 张牌。\n仅当你位于地下城深处时，才能击败此怪物。\n带有巨龙袭击标记。"
				},
				"cleric-of-the-sun": {
					name: "太阳祭司",
					text: "获得 2 点技能和 1 点战斗力。\n获取时：恢复 1 点生命。\n价值 1 分。"
				},
				"crystal-golem": {
					name: "水晶魔像",
					text: "获得 3 点技能。\n仅当你位于水晶洞穴中时，才能击败此怪物。"
				},
				"dead-run": {
					name: "狂奔",
					text: "获得 2 点移动力。\n制造 2 点噪音；本回合进入水晶洞穴后，仍可使用移动力继续移动。"
				},
				diamond: {
					name: "钻石",
					text: "抽取 1 张牌。\n获取时：制造 2 点噪音。\n带有巨龙袭击标记。\n价值 8 分。"
				},
				"dragon-shrine": {
					name: "巨龙圣坛",
					text: "选择一项：\n· 获得 2 枚金币。\n· 从打出区或弃牌堆中销毁一张牌。\n危险：此牌位于地下城公共牌列时，每次巨龙袭击多抽一个方块。"
				},
				"dragons-eye": {
					name: "龙之眼",
					text: "抽取 1 张牌。\n获取时：制造 2 点噪音。\n成功撤离时计 10 分。\n仅当你位于地下城深处时，才能获取此牌。\n带有巨龙袭击标记。"
				},
				"dwarven-peddler": {
					name: "矮人小贩",
					text: "获得 1 点移动力。\n获得 2 枚金币。\n圣杯、龙蛋与神像中持有至少两类时计 4 分。"
				},
				"elven-boots": {
					name: "精灵长靴",
					text: "获得 1 点技能和 1 点移动力。\n抽取 1 张牌。\n价值 2 分。"
				},
				"elven-cloak": {
					name: "精灵斗篷",
					text: "获得 1 点技能。\n移除 2 点噪音；抽取 1 张牌。\n价值 2 分。"
				},
				"elven-dagger": {
					name: "精灵匕首",
					text: "获得 1 点技能和 1 点战斗力。\n抽取 1 张牌。\n价值 2 分。"
				},
				emerald: {
					name: "翡翠",
					text: "抽取 1 张牌。\n获取时：制造 2 点噪音。\n带有巨龙袭击标记。\n价值 5 分。"
				},
				"flying-carpet": {
					name: "飞毯",
					text: "获得 2 点移动力。\n本回合进入水晶洞穴后，仍可使用移动力继续移动；本回合忽略通道上的怪物。\n价值 2 分。"
				},
				"gem-collector": {
					name: "宝石收藏家",
					text: "获得 2 点技能。\n移除 2 点噪音。\n本回合获取宝石牌时，技能费用减少 2 点。\n价值 2 分。"
				},
				"invoker-of-the-ancients": {
					name: "远古召唤师",
					text: "制造 1 点噪音；传送到相邻房间。\n价值 1 分。"
				},
				kobold: {
					name: "狗头人",
					text: "获得 1 点技能。\n带有巨龙袭击标记。\n危险：此牌位于地下城公共牌列时，每次巨龙袭击多抽一个方块。"
				},
				"kobold-merchant": {
					name: "狗头人商贩",
					text: "获得 2 枚金币。\n若持有神器：获得 2 点技能。\n价值 1 分。"
				},
				ladder: {
					name: "梯子",
					text: "获得 2 点移动力。"
				},
				"lucky-coin": {
					name: "幸运硬币",
					text: "获得 1 点技能。\n制造 1 点噪音；抽取 1 张牌。\n价值 1 分。"
				},
				"master-burglar": {
					name: "盗贼大师",
					text: "获得 2 点技能。\n从打出区或弃牌堆中销毁一张“潜窃”。\n价值 2 分。"
				},
				"mister-whiskers": {
					name: "胡须先生",
					text: "选择一项：\n· 触发一次巨龙袭击。\n· 移除 2 点噪音。\n带有巨龙袭击标记。\n价值 1 分。"
				},
				"monkeybot-3000": {
					name: "机械猴3000",
					text: "制造 3 点噪音；抽取 3 张牌。\n带有巨龙袭击标记。\n价值 1 分。"
				},
				"move-silently": {
					name: "悄然移动",
					text: "获得 2 点移动力。\n移除 2 点噪音。"
				},
				ogre: {
					name: "食人魔",
					text: "获得 5 枚金币。\n带有巨龙袭击标记。"
				},
				"ogre-grunt": {
					name: "兽人步兵",
					text: "获得 3 枚金币。\n带有巨龙袭击标记。"
				},
				overlord: {
					name: "霸主",
					text: "抽取 2 张牌。\n到来效果：所有玩家制造 1 点噪音。"
				},
				pickaxe: {
					name: "矿镐",
					text: "获得 2 点战斗力。\n获得 2 枚金币。\n价值 2 分。"
				},
				"rebel-captain": {
					name: "反抗军队长",
					text: "获得 2 点技能。\n若本回合打出另一张伙伴牌：抽取 1 张牌。\n价值 1 分。"
				},
				"rebel-miner": {
					name: "反抗军矿工",
					text: "获得 2 枚金币。\n若本回合打出另一张伙伴牌：抽取 1 张牌。\n价值 1 分。"
				},
				"rebel-scout": {
					name: "反抗军斥候",
					text: "获得 2 点移动力。\n若本回合打出另一张伙伴牌：抽取 1 张牌。\n价值 1 分。"
				},
				"rebel-soldier": {
					name: "反抗军士兵",
					text: "获得 2 点战斗力。\n若本回合打出另一张伙伴牌：抽取 1 张牌。\n价值 1 分。"
				},
				ruby: {
					name: "红宝石",
					text: "抽取 1 张牌。\n获取时：制造 2 点噪音。\n带有巨龙袭击标记。\n价值 6 分。"
				},
				sapphire: {
					name: "蓝宝石",
					text: "抽取 1 张牌。\n获取时：制造 2 点噪音。\n带有巨龙袭击标记。\n价值 4 分。"
				},
				search: {
					name: "搜寻",
					text: "获得 2 点技能和 1 点移动力。\n本回合每次获得金币时，额外获得 1 枚金币。"
				},
				"scepter-of-the-ape-lord": {
					name: "猿王权杖",
					text: "获得 3 点技能。\n制造 3 点噪音。\n价值 3 分。"
				},
				"silver-spear": {
					name: "银矛",
					text: "获得 3 点战斗力。\n获取时：获得 1 点战斗力。\n价值 2 分。"
				},
				"singing-sword": {
					name: "歌唱之剑",
					text: "获得 3 点技能和 2 点战斗力。\n制造 1 点噪音。\n带有巨龙袭击标记。\n价值 2 分。"
				},
				"sleight-of-hand": {
					name: "巧手",
					text: "从手牌中弃置 1 张牌，然后抽取 2 张牌。"
				},
				sneak: {
					name: "潜行",
					text: "获得 1 点技能和 1 点移动力。\n移除 2 点噪音。"
				},
				shrine: {
					name: "圣坛",
					text: "选择一项：\n· 获得 1 枚金币。\n· 恢复 1 点生命。\n到来效果：将 3 个已移除的黑色方块放回龙袋。"
				},
				swagger: {
					name: "大摇大摆",
					text: "获得 1 点移动力。\n本回合每实际向噪音区放置 1 个方块，获得 1 点技能。"
				},
				tattle: {
					name: "告密",
					text: "获得 2 点技能。\n每名对手制造 1 点噪音。"
				},
				teleporter: {
					name: "传送装置",
					text: "传送到相邻房间。"
				},
				"the-duke": {
					name: "公爵",
					text: "获得 2 点技能和 2 点战斗力。\n每 5 枚金币额外计 1 分。"
				},
				"the-mountain-king": {
					name: "山丘之王",
					text: "获得 2 点技能、 1 点战斗力和 1 点移动力。\n若持有王冠：获得 1 点战斗力；获得 1 点移动力。\n价值 3 分。"
				},
				"the-queen-of-hearts": {
					name: "红心女王",
					text: "获得 3 点技能和 1 点战斗力。\n若持有王冠：恢复 1 点生命。\n价值 3 分。"
				},
				"the-vault": {
					name: "宝库",
					text: "获得 5 枚金币；制造 3 点噪音。\n仅当你位于地下城深处时，才能获取此牌。\n带有巨龙袭击标记。"
				},
				"treasure-hunter": {
					name: "寻宝者",
					text: "获得 2 点技能和 2 点战斗力。\n替换地下城公共牌列中的一张牌，并结算新牌的到来效果。替换本身不会因新牌的袭击标记触发巨龙袭击。\n价值 1 分。"
				},
				"treasure-map": {
					name: "藏宝图",
					text: "获得 5 枚金币。"
				},
				"tunnel-guide": {
					name: "隧道向导",
					text: "获得 1 点战斗力和 1 点移动力。\n价值 1 分。"
				},
				"underworld-dealing": {
					name: "地下交易",
					text: "选择一项：\n· 获得 1 枚金币。\n· 支付 7 枚金币，获得 2 张秘密典籍。"
				},
				"wand-of-recall": {
					name: "召回魔杖",
					text: "获得 2 点技能。\n若持有神器：传送到相邻房间。\n价值 1 分。"
				},
				"wand-of-wind": {
					name: "风之魔杖",
					text: "选择一项：\n· 传送到相邻房间。\n· 从相邻房间取得一个秘密。\n价值 3 分。"
				},
				watcher: {
					name: "监视者",
					text: "获得 3 枚金币；每名对手制造 1 点噪音。\n到来效果：所有玩家制造 1 点噪音。"
				},
				wizard: {
					name: "巫师",
					text: "获得 3 点技能。\n每张秘密典籍额外计 2 分。"
				},
				alchemist: {
					name: "炼金术士",
					text: "获得 2 点技能。\n若打出区或弃牌堆有秘密典籍：获得 2 枚金币。\n价值 1 分。"
				},
				"ancient-invocation": {
					name: "远古祈唤",
					text: "制造 2 点噪音；传送到相邻房间。"
				},
				aspiration: {
					name: "雄心",
					text: "抽取 1 张牌。\n若持有王冠：抽取 1 张牌。\n获取时：获得 1 枚金币。"
				},
				"black-pearl": {
					name: "黑珍珠",
					text: "从手牌中弃置 1 张牌，然后抽取 2 张牌。\n获取时：制造 2 点噪音。\n带有巨龙袭击标记。\n价值 5 分。"
				},
				boomerang: {
					name: "回旋镖",
					text: "获得 1 点技能和 2 点战斗力。\n在回合中从手牌弃置此牌时：将这张牌返回手牌。\n价值 1 分。"
				},
				"burglars-boots": {
					name: "盗贼之靴",
					text: "选择一项：\n· 移除 2 点噪音。\n· 获得 1 点移动力。\n· 获得 1 枚金币。\n价值 1 分。"
				},
				"climbing-gear": {
					name: "攀登装备",
					text: "获得 1 点移动力。\n从手牌中弃置 1 张牌，然后获得 1 点移动力。\n价值 1 分。"
				},
				"coin-purse": {
					name: "钱袋",
					text: "获得 2 枚金币。\n获取时：获得 3 枚金币。\n在回合中从手牌弃置此牌时：获得 5 枚金币。"
				},
				"crystal-fish": {
					name: "水晶鱼",
					text: "获得 2 枚金币。\n仅当你位于水晶洞穴或水域中时，才能击败此怪物。\n带有巨龙袭击标记。"
				},
				"deep-dive": {
					name: "深潜",
					text: "从手牌中弃置 3 张牌，然后抽取 5 张牌。"
				},
				"elven-ranger": {
					name: "精灵游侠",
					text: "获得 1 点技能、 1 点战斗力和 1 点移动力。\n抽取 1 张牌。\n价值 2 分。"
				},
				"eye-in-the-water": {
					name: "水中之眼",
					text: "选择一项：\n· 获得 2 枚金币。\n· 移除 2 点噪音。\n到来效果：所有玩家制造 2 点噪音。"
				},
				"fishing-pole": {
					name: "鱼竿",
					text: "抽取 1 张牌；从手牌中弃置 1 张牌。\n价值 1 分。"
				},
				"grand-plan": {
					name: "宏伟计划",
					text: "获得 2 点技能。\n获得 2 枚金币。\n获取时：获得 2 枚金币。\n持有至少三件市场物品时计 7 分。"
				},
				pickpocket: {
					name: "扒手",
					text: "获得 1 点移动力。\n免费获取地下城公共牌列中的一张牌（技能费用不超过 2 点）。\n在回合中从手牌弃置此牌时：免费获取地下城公共牌列中的一张牌（技能费用不超过 2 点）。\n价值 1 分。"
				},
				"pipe-organ": {
					name: "管风琴",
					text: "将怒气提高或降低一级。"
				},
				medic: {
					name: "医师",
					text: "获得 1 点技能。\n从手牌中弃置 1 张牌，然后恢复 1 点生命。\n价值 1 分。"
				},
				merling: {
					name: "鱼人",
					text: "获得 1 点技能、 1 点战斗力和 1 点移动力。\n价值 1 分。"
				},
				mermaid: {
					name: "美人鱼",
					text: "获得 2 点技能和 1 点移动力。\n本回合免除缺氧伤害及水域移动的额外费用。\n价值 1 分。"
				},
				"rebel-brawler": {
					name: "反抗军斗士",
					text: "获得 2 点战斗力。\n制造 1 点噪音。\n若本回合打出另一张伙伴牌：抽取 1 张牌。\n价值 1 分。"
				},
				"rebel-scholar": {
					name: "反抗军学者",
					text: "抽取 1 张牌。\n若本回合打出另一张伙伴牌：抽取 1 张牌。\n价值 1 分。"
				},
				saurian: {
					name: "蜥蜴兽",
					text: "获得 4 枚金币。\n带有巨龙袭击标记。\n危险：此牌位于地下城公共牌列时，每次巨龙袭击多抽一个方块。"
				},
				"short-cut": {
					name: "捷径",
					text: "获得 1 点移动力。\n制造 1 点噪音。\n获取时：获得 1 点移动力。\n在回合中从手牌弃置此牌时：获得 2 点移动力。"
				},
				"shrine-of-the-mermaid": {
					name: "美人鱼圣坛",
					text: "选择一项：\n· 获得 2 枚金币。\n· 在水域中时，传送到相邻房间。\n危险：此牌位于地下城公共牌列时，每次巨龙袭击多抽一个方块。"
				},
				"silver-pearl": {
					name: "银珍珠",
					text: "从手牌中弃置 1 张牌，然后抽取 2 张牌。\n获取时：制造 2 点噪音。\n带有巨龙袭击标记。\n价值 2 分。"
				},
				sorcerer: {
					name: "术士",
					text: "获得 1 张秘密典籍。\n仅当你位于地下城深处时，才能击败此怪物。\n带有巨龙袭击标记。"
				},
				"white-pearl": {
					name: "白珍珠",
					text: "从手牌中弃置 1 张牌，然后抽取 2 张牌。\n获取时：制造 2 点噪音。\n带有巨龙袭击标记。\n价值 3 分。"
				},
				"blessed-fountain": {
					name: "祝福之泉",
					text: "恢复 1 点生命；移除 1 个诅咒。\n带有巨龙袭击标记。"
				},
				"book-of-the-dead": {
					name: "亡者之书",
					text: "抽取 3 张牌。\n每个诅咒额外计 1 分。\n带有巨龙袭击标记。"
				},
				bullwhip: {
					name: "长鞭",
					text: "获得 2 点技能、 1 点战斗力和 1 点移动力。\n制造 1 点噪音。\n价值 2 分。"
				},
				camel: {
					name: "骆驼",
					text: "获得 1 点战斗力和 1 点移动力。\n若本回合找到秘密：抽取 1 张牌。\n价值 1 分。"
				},
				"canopic-jars": {
					name: "卡诺卜罐",
					text: "抽取 4 张牌；获得 1 个诅咒。\n到来效果：投掷金字塔骰并移动木乃伊。"
				},
				crocodilian: {
					name: "鳄鱼兽",
					text: "移除 1 点噪音；移除 1 个诅咒。\n带有巨龙袭击标记。"
				},
				"crystal-skull": {
					name: "水晶头骨",
					text: "获得 3 点技能。\n若打出区或弃牌堆有至少两张宝石牌：获得 1 张秘密典籍。\n价值 2 分。"
				},
				"death-mask": {
					name: "死亡面具",
					text: "获得 2 点技能和 2 点战斗力。\n移除 1 个诅咒。\n到来效果：投掷金字塔骰并移动木乃伊。\n价值 1 分。"
				},
				doomsayer: {
					name: "末日预言者",
					text: "获得 2 点战斗力。\n若噪音区有自己的方块：每名对手获得 1 个诅咒。\n价值 2 分。"
				},
				"daring-explorer": {
					name: "大胆的探险家",
					text: "获得 2 点技能和 1 点移动力。\n可制造 2 点噪音，从相邻房间取得一个秘密或神像。\n危险：此牌位于地下城公共牌列时，每次巨龙袭击多抽一个方块。\n价值 3 分。"
				},
				excavate: {
					name: "挖掘",
					text: "制造 2 点噪音；抽取 2 张牌。\n到来效果：投掷金字塔骰并移动木乃伊。"
				},
				historian: {
					name: "历史学家",
					text: "获得 2 点技能。\n若噪音区有自己的方块：从打出区或弃牌堆中销毁一张牌。\n价值 2 分。"
				},
				jasper: {
					name: "碧玉",
					text: "抽取 1 张牌。\n获取时：制造 2 点噪音；获得 1 个诅咒。\n带有巨龙袭击标记。\n价值 7 分。"
				},
				kittypatra: {
					name: "猫艳后",
					text: "选择一项：\n· 移除 2 点噪音。\n· 移除 1 个诅咒。\n到来效果：投掷金字塔骰并移动木乃伊。\n价值 1 分。"
				},
				"lapis-lazuli": {
					name: "青金石",
					text: "抽取 1 张牌。\n获取时：制造 2 点噪音；获得 1 个诅咒。\n带有巨龙袭击标记。\n价值 8 分。"
				},
				"need-for-greed": {
					name: "贪欲",
					text: "获得 1 点技能。\n从手牌中弃置 1 张牌，然后获得 2 枚金币。"
				},
				"ornate-khopesh": {
					name: "华丽镰形剑",
					text: "获得 3 点战斗力。\n抽取 1 张牌。\n获取时：获得 3 点战斗力。\n价值 3 分。"
				},
				purify: {
					name: "净化",
					text: "获得 3 点技能。\n获取时：移除 1 个诅咒。\n你的诅咒数量少于所有对手时计 5 分。"
				},
				"rebel-burglar": {
					name: "反抗军窃贼",
					text: "从打出区或弃牌堆中销毁一张“潜窃”。\n若本回合打出另一张伙伴牌：抽取 1 张牌。\n价值 1 分。"
				},
				"rebel-mystic": {
					name: "反抗军秘术师",
					text: "传送到相邻房间。\n若本回合打出另一张伙伴牌：抽取 1 张牌。\n价值 1 分。"
				},
				"ring-of-wishes": {
					name: "许愿之戒",
					text: "选择三次，可以重复选择：\n· 获得 1 枚金币。\n· 获得 1 点移动力。\n· 移除 1 个诅咒。"
				},
				"royal-bodyguard": {
					name: "皇家护卫",
					text: "获得 1 点移动力。\n若持有王冠：本回合忽略通道图标。\n价值 1 分。"
				},
				"scorpion-queen": {
					name: "蝎后",
					text: "获得等于 7 减去自身诅咒数量的金币，最低为 0 枚。\n带有巨龙袭击标记。"
				},
				serpentine: {
					name: "蛇纹石",
					text: "抽取 1 张牌。\n获取时：制造 2 点噪音；获得 1 个诅咒。\n带有巨龙袭击标记。\n价值 6 分。"
				},
				"staff-of-the-ancients": {
					name: "远古法杖",
					text: "获得 2 枚金币。\n若打出区或弃牌堆有宝石牌：传送到相邻房间。\n价值 1 分。"
				},
				"stone-simian": {
					name: "石猿",
					text: "获得 3 枚金币。\n若持有神像：恢复 1 点生命。\n带有巨龙袭击标记。"
				},
				"thrill-seeker": {
					name: "寻险者",
					text: "获得 1 点技能和 1 点移动力。\n若噪音区有自己的方块：获得 2 点移动力。\n价值 1 分。"
				},
				"tomb-robber": {
					name: "盗墓者",
					text: "获得 1 点战斗力和 2 点移动力。\n若持有神器：获得 2 枚金币。\n到来效果：投掷金字塔骰并移动木乃伊。\n价值 2 分。"
				},
				"tomb-snake": {
					name: "墓穴蛇",
					text: "获得 2 点技能。\n到来效果：所有玩家制造 1 点噪音。\n仅当你位于地下城深处时，才能击败此怪物。"
				},
				whiskersphinx: {
					name: "胡须狮身兽",
					text: "抽取 2 张牌；移除 1 个诅咒。\n到来效果：投掷金字塔骰并移动木乃伊。"
				},
				"brawn-vs-boots": {
					name: "力量与速度",
					text: "获得 2 点技能。\n选择一项：\n· 获得 2 点战斗力。\n· 获得 2 点移动力。"
				},
				"enchanted-dice": {
					name: "魔法骰子",
					text: "获得 2 点技能。\n从龙袋中抽取两个方块，然后放回。每抽到一个黑色方块，获得 1 枚金币。\n价值 1 分。"
				},
				"dire-wolf": {
					name: "恐狼",
					text: "获得 1 点技能和 1 点移动力。\n地下城公共牌列中的怪物和常驻怪物，每个使你制造 1 点噪音并获得 1 点战斗力。\n价值 1 分。"
				},
				"expedition-leader": {
					name: "探险队长",
					text: "获得 2 点技能、 1 点战斗力和 1 点移动力。\n本回合每次获得金币时，额外获得 1 枚金币。\n价值 2 分。"
				},
				"friendly-watcher": {
					name: "友善的监视者",
					text: "获得 3 枚金币；每名对手制造 1 点噪音。\n到来效果：所有玩家制造 1 点噪音。\n价值 1 分。"
				},
				"magic-spectacles": {
					name: "魔法眼镜",
					text: "获得 2 点技能。\n查看牌库顶牌；将其留在顶部或移至底部，然后抽取一张牌。\n价值 2 分。"
				},
				"mummy-hunters": {
					name: "木乃伊猎手",
					text: "获得 2 点战斗力和 1 点移动力。\n本回合免疫木乃伊给予的诅咒。\n到来效果：投掷金字塔骰并移动木乃伊。\n价值 1 分。"
				},
				"opal-apestone": {
					name: "蛋白石猿石",
					text: "移除 1 点噪音；抽取 1 张牌。\n获取时：制造 3 点噪音。\n带有巨龙袭击标记。\n价值 3 分。"
				},
				siren: {
					name: "海妖",
					text: "免费获取地下城公共牌列中的一张伙伴牌。\n价值 2 分。"
				},
				"snack-table": {
					name: "点心桌",
					text: "恢复 1 点生命。\n每名其他玩家可以向你支付 1 枚金币，恢复其自身 1 点生命。\n带有巨龙袭击标记。"
				},
				trailblazer: {
					name: "开路先锋",
					text: "获得 1 点技能、 1 点战斗力和 1 点移动力。\n若本回合经过水域、获得诅咒、清除蛛网或采矿：获得 2 枚金币。\n价值 2 分。"
				},
				"wand-of-time": {
					name: "时间魔杖",
					text: "获得 2 点技能。\n将弃牌堆中的一张牌加入手牌；若弃牌堆为空，抽取两张牌。\n价值 2 分。"
				},
				"wishing-wall": {
					name: "许愿墙",
					text: "选择两个不同的选项：\n· 从打出区或弃牌堆中销毁一张牌。\n· 获得 2 点战斗力。\n· 获得 2 点移动力。\n· 恢复 1 点生命。"
				}
			},
			action: {
				play: "打出“{{card}}”",
				acquire: "获取“{{card}}”",
				defeat: "击败“{{card}}”",
				market: "购买“{{item}}”",
				guardian: "击败青铜守卫，获得“{{item}}”",
				mummyGold: "击败木乃伊，获得 4 枚金币和 1 个诅咒",
				mummyCleanse: "击败木乃伊，移除一半诅咒（向上取整）",
				mine: "开采矿脉 {{n}}",
				rotate: "消耗“{{item}}”，将齿轮 {{n}} 转至方向 {{orientation}}",
				potion: "使用“{{item}}”",
				spring: "在魔法泉销毁“{{card}}”",
				discard: "从手牌中弃置“{{card}}”",
				trash: "销毁“{{card}}”",
				recall: "将“{{card}}”从弃牌堆加入手牌",
				teleport: "传送至房间 {{n}}",
				adjacent: "领取房间 {{n}} 的奖励",
				replace: "替换“{{card}}”",
				freeAcquire: "免费获取“{{card}}”"
			},
			resource: {
				skill: "{{n}} 点技能",
				swords: "{{n}} 点战斗力",
				boots: "{{n}} 点移动力",
				gold: "{{n}} 枚金币",
				clank: "{{n}} 点噪音",
				curse: "{{n}} 个诅咒",
				oneCurse: "1 个诅咒",
				heal: "恢复 {{n}} 点生命",
				makeClank: "制造 {{n}} 点噪音"
			}
		},
		en: {
			possessions: {
				artifactName: "Artifact",
				idolName: "Monkey Idol",
				quantity: "Quantity: {{n}}",
				purchaseCost: "Purchase cost: {{n}} gold",
				endPoints: "End-game value: {{n}} points",
				hiddenApparatus: "{{n}} ape-aratus tokens held; their types are hidden.",
				key: "While held, allows you to use tunnels with a lock icon.",
				backpack: "While held, increases your artifact carrying capacity by one.",
				crown: "Scores its printed value. When buying a crown, take the highest-valued crown remaining in the market.",
				scuba: "While held, reduces the minimum cost of moving between flooded rooms from 2 Boots to 1; other tunnel costs still apply. Prevents damage from ending your turn without coming up for air.",
				ankh: "When purchased, heal 1 damage.",
				timeWinder: "When purchased, return up to 3 cubes of your color from the Dragon Bag to your personal supply.",
				heal1: "Use during your turn to heal 1 damage. Consumed after use.",
				heal2: "Use during your turn to heal 2 damage. Consumed after use.",
				boots: "Use during your turn to gain 1 Boot. Consumed after use.",
				swords: "Use during your turn to gain 2 Swords. Consumed after use.",
				heroism: "Use during your turn to gain 1 Boot and 1 Sword, and heal 1 damage. Consumed after use.",
				gold2: "When found, adds 2 gold to your balance, available for purchases. Each unspent gold scores 1 point at the end of the game.",
				gold5: "When found, adds 5 gold to your balance, available for purchases. Each unspent gold scores 1 point at the end of the game.",
				skill2: "When found, immediately gain 2 Skill to use this turn.",
				skill5: "When found, immediately gain 5 Skill to use this turn.",
				draw3: "When found, immediately draw 3 cards.",
				chalice: "Keep until the end of the game; each chalice scores 7 points. It is not an artifact.",
				spring: "Before ending this turn, trash one card from your play area or discard pile. Consumed after use.",
				egg: "When found, increase Dragon Rage by one level. Keep until the end of the game; each egg scores 3 points.",
				scarab: "When found, roll the pyramid die and move the Mummy as indicated. Keep until the end of the game; each scarab scores 3 points.",
				mummyGold: "When found, add 5 gold to your balance, then roll the pyramid die and move the Mummy as indicated. Each unspent gold scores 1 point.",
				mummyChalice: "When found, roll the pyramid die and move the Mummy as indicated. Keep until the end of the game; each chalice scores 7 points. It is not an artifact.",
				artifact: "When taken, increase Dragon Rage by one level. An artifact is required to escape through the entrance and to qualify for scoring; being knocked out in the Depths still prevents scoring. Scores its printed value.",
				idol: "Keep until the end of the game and score its printed value. It is not an artifact.",
				web: "When crossing a web, spend 1 additional Boot or Sword and collect it. Scores its printed value at the end of the game.",
				apparatusJungle: "Keep until the end of the game. Each type scores the square of its quantity: 2 of a type score 4 points, 3 score 9 points.",
				apparatusTemple: "While in a connected room, spend one token matching the gear symbol to rotate that gear. Ape-aratus tokens do not directly score points in the Temple."
			},
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Clank!",
			desc: "Build your deck, steal an artifact, and escape the dragon.",
			errorAction: "That action is not available.",
			ui: {
				moveDamage: "Take {{n}} damage",
				overview: "Full map",
				locate: "Find my pawn",
				mapTools: "Map controls",
				dragonAttack: "Dragon attack",
				blackCube: "Black cube",
				danger: "Danger",
				cancel: "Cancel",
				close: "Close",
				chooseMove: "Choose how to move",
				playHand: "Choose a card to play",
				selectMove: "Choose a highlighted room to enter",
				noisePool: "Clank! area",
				turn: "Turn {{n}}",
				yourTurn: "Your turn",
				waiting: "Waiting for {{name}}",
				resolving: "Resolving",
				intermission: "First game complete",
				continue: "Begin the Temple game",
				hand: "Hand",
				played: "Play area",
				dungeon: "Dungeon Row",
				supplies: "Reserve & market",
				actions: "Available actions",
				inspect: "Card details",
				confirm: "Confirm",
				end: "End turn",
				play: "Play",
				acquire: "Acquire",
				defeat: "Defeat",
				artifact: "Take artifact",
				market: "Buy Market item",
				mine: "Mine",
				cache: "Spider Queen’s Cache",
				rotate: "Rotate gear",
				potion: "Use potion",
				spring: "Trash a card at the Magic Spring",
				move: "Move to room {{n}}",
				room: "Room {{n}}",
				moveCost: "Spend {{boots}} movement, {{swords}} combat and {{gold}} gold; take {{damage}} damage",
				skill: "Skill",
				swords: "Combat",
				boots: "Movement",
				health: "Health",
				gold: "Gold",
				clank: "Clank!",
				bag: "Cubes in the Dragon Bag",
				rage: "Rage level {{n}}",
				deck: "Deck",
				discard: "Discard pile",
				log: "History",
				player: "Player details",
				secrets: "Secrets",
				idols: "Monkey idols",
				water: "Water",
				cave: "Crystal Cave",
				deep: "Depths",
				surface: "Above the Depths",
				entrance: "Entrance",
				web: "Web",
				curse: "Curses",
				apparatus: "Ape-aratus",
				remaining: "Dungeon Deck: {{n}} cards left",
				cost: "Cost: {{n}}",
				points: "{{n}} points",
				onePoint: "1 point",
				inspectCard: "View details for {{card}}",
				noAction: "No actions available",
				choose: "Choose an effect or target",
				take: "Take reward",
				skip: "Decline reward",
				zoomIn: "Zoom in",
				zoomOut: "Zoom out",
				resetMap: "Reset map",
				map: "Map",
				countdown: "Countdown {{n}} / 4",
				mummy: "Mummy zone {{n}}",
				escaped: "Escaped",
				knocked: "Knocked out",
				active: "Exploring",
				firstGame: "Jungle game score",
				campaignBonus: "Campaign bonus points",
				noScore: "No artifact, or knocked out in the Depths: no score.",
				details: "Details",
				reveal: "Collected rewards",
				spendBoots: "Spend {{n}} movement",
				spendSwords: "Spend {{n}} combat",
				spendGold: "Pay {{n}} gold",
				makeClank: "Make {{n}} Clank!",
				gainCurse: "Gain {{n}} Curse tokens",
				handCount: "Hand cards: {{n}}",
				deckCount: "Deck cards: {{n}}",
				bagCount: "Cubes in the Dragon Bag: {{n}}",
				noiseCount: "Cubes in the Clank! area: {{n}}",
				curseCount: "Curse tokens: {{n}}",
				healthCount: "Health: {{n}} / 10",
				goldCount: "Gold: {{n}}",
				artifactValues: "Artifact values: {{values}}",
				idolValues: "Monkey idol values: {{values}}",
				secretCount: "Secrets left: {{n}}",
				none: "None",
				websCollected: "Collected web values: {{values}}",
				openDungeon: "View cards",
				openActions: "More actions",
				moveSeparator: "; ",
				inventory: "Items held",
				suppliesCount: "Supply cubes: {{n}}"
			},
			options: {
				expansions: "Expansions",
				sunken: "Sunken Treasures",
				mummy: "The Mummy’s Curse",
				goldSilk: "Gold and Silk",
				apeLords: "Temple of the Ape Lords",
				promo: "Workshop promotional cards (13 cards)",
				campaign: "Two-game campaign: Jungle, then Temple",
				map: "Map"
			},
			maps: {
				baseFront: "Base: front",
				baseBack: "Base: back",
				sunkenBoat: "Shipwreck",
				sunkenSewer: "Sewers",
				mummyPyramid: "Pyramid",
				mummySphinx: "Sphinx",
				spiderLair: "Spider Queen’s Lair",
				dwarvenMine: "Dwarven Mine",
				jungle: "Jungle",
				temple: "Temple"
			},
			items: {
				key: "Master Key",
				backpack: "Backpack",
				crown: "Crown",
				scuba: "Diving Gear",
				ankh: "Ankh",
				timeWinder: "Time Winder",
				heal1: "Healing Potion",
				heal2: "Greater Healing Potion",
				boots: "Potion of Swiftness",
				swords: "Potion of Strength",
				heroism: "Potion of Heroism",
				goblin: "Goblin",
				goldfish: "Goldfish",
				mummyGold: "Mummy",
				mummyCleanse: "Mummy",
				guardian: "Bronze Guardian",
				cog: "Cog",
				wrench: "Monkey Wrench",
				banana: "Banana",
				gold2: "2 gold",
				gold5: "5 gold",
				skill2: "2 Skill",
				skill5: "5 Skill",
				draw3: "Draw 3 cards",
				chalice: "Chalice",
				spring: "Magic Spring",
				egg: "Dragon Egg",
				scarab: "Scarab",
				mummyChalice: "Mummy’s Chalice"
			},
			choice: {
				discard: "Discard a card from your hand",
				trash: "Trash a card from your play area or discard pile",
				teleport: "Choose a room to teleport to",
				adjacent: "Choose a reward in an adjacent room",
				acquire: "Choose a card to acquire for free",
				replace: "Choose a Dungeon Row card to replace",
				recall: "Choose a discarded card to return to your hand",
				peek: "Choose where to put the top card",
				entry: "Collect room rewards",
				snack: "Pay the Snack Table user 1 gold to recover 1 health",
				organ: "Adjust rage",
				choose: "Choose a reward",
				top: "Leave on top and draw it",
				bottom: "Move to the bottom and draw a card",
				pay: "Pay 1 gold and recover 1 health",
				skip: "Decline",
				take: "Collect the reward",
				attack: "Trigger dragon attack",
				waterTeleport: "Teleport from water",
				tomePaid: "Pay 7 gold for two Secret Tomes",
				up: "Increase rage by one level",
				down: "Decrease rage by one level",
				gain: "Gain {{resource}}",
				remove: "Remove {{resource}}",
				gear: "Turn gear {{n}} to orientation {{orientation}}",
				cache: "Claim cache reward {{n}}: {{reward}}"
			},
			score: {
				artifacts: "Artifacts",
				gold: "Gold",
				cards: "Cards",
				tokens: "Secrets & collectibles",
				market: "Market items",
				mastery: "Escape bonus",
				curses: "Curses",
				mining: "Mining bonus",
				apparatus: "Ape-aratus",
				campaign: "Campaign bonus",
				total: "Total"
			},
			events: {
				play: "{{name}} played {{card}}",
				move: "{{name}} entered room {{n}}",
				acquire: "{{name}} acquired {{card}}",
				defeat: "{{name}} defeated {{card}}",
				artifact: "{{name}} took a {{n}}-point artifact",
				secret: "{{name}} found {{card}}",
				market: "{{name}} bought {{card}}",
				mine: "{{name}} mined for {{n}} gold",
				web: "{{name}} cleared a web",
				rotate: "Gears rotated",
				dragon: "Dragon attack: draw {{n}} cubes",
				damage: "{{name}} took {{n}} damage",
				escape: "{{name}} escaped",
				knockout: "{{name}} was knocked out",
				mummy: "Mummy moved to zone {{n}}",
				round: "A new turn began",
				campaign: "The Temple game began",
				rotatePlayer: "{{name}} rotated gear {{n}}"
			},
			guide: {
				symbols: "Card symbols",
				cache: "Spider Queen’s Cache rewards",
				cacheText: "Spend 8 skill and place 1 cube from your personal supply per claim. Each reward can be claimed once per game.",
				cache1: "Gain 5 gold.",
				cache2: "Gain 3 gold and 1 combat.",
				cache3: "Gain 3 gold and 1 movement.",
				cache4: "Gain 3 gold and recover 1 health.",
				cache5: "Gain 1 Secret Tome and recover 1 health.",
				cache6: "Gain 1 Secret Tome and 1 gold.",
				cache7: "Gain 1 Secret Tome and 1 gold.",
				cache8: "Gain 1 Secret Tome and 2 gold."
			},
			rules: "Goal:\nTake an artifact from the dungeon and escape through the entrance. At the end of the game, the eligible player with the highest score wins.\nSetup:\nEach player starts with 10 health and a shuffled deck of 10 cards. Draw 5 cards. Shuffle enabled expansion cards into the Dungeon Deck and use the components for the chosen map.\nTurn actions:\nPlay cards, move, acquire cards, fight and buy items in any order. Playing a card gives you its skill, combat, movement and other effects.\n· Spend skill to acquire Dungeon Row or reserve cards. Put acquired cards in your discard pile.\n· Spend combat to defeat monsters and receive their rewards. Monster cards do not enter your deck.\n· Spend skill to use a Device and resolve its effect immediately. Device cards do not enter your deck.\n· In a market room, each Market item costs 7 gold.\nBefore ending your turn, play every hand card and use any available Magic Spring trash effects. Then discard your played cards and draw 5 cards. Unused skill, combat and movement expire; keep your gold.\nWhen you need to draw from an empty deck, shuffle your discard pile to form a new deck.\nMovement and rooms:\nFollow a tunnel to an adjacent room, usually for 1 movement; footprints show the cost. For each monster symbol, spend 1 combat or take 1 damage. A locked tunnel requires a Master Key, and an elevator requires 1 gold.\nAfter entering a Crystal Cave, you cannot spend movement again this turn unless an effect allows it. Teleporting costs no movement and ignores tunnel restrictions, but the destination must be adjacent.\nOn entry, you may collect a secret or monkey idol; take an artifact as a separate action in its room. You may carry one artifact, plus one per Backpack. Return to the entrance with an artifact to escape. You cannot return without one.\nDragon attacks:\nFor each Clank! you make, move 1 cube from your personal supply to the Clank! area. Removing Clank! returns your cubes; any excess cancels later Clank! this turn. At the start of an attack, move every player’s Clank! cubes into the Dragon Bag.\nAt turn end, refill the Dungeon Row and resolve the new cards’ Arrive effects. If any refill card has a dragon attack symbol, trigger one attack after refilling. Multiple symbols in the same refill do not cause multiple attacks.\nRage determines how many cubes are drawn, plus one for each Danger card in the row. Each of your cubes drawn deals 1 damage to you; black cubes deal none. Drawn cubes leave the bag. Taking an artifact or Dragon Egg increases rage.\nEscape and scoring:\nYou are knocked out at zero health, or if you lack supply cubes to take damage outside the bag. The first player to escape or be knocked out starts the countdown. Each time their turn returns, attack with 1, then 2, then 3 extra cubes. On their fourth return, all remaining explorers are knocked out. An empty Dungeon Deck also knocks out all remaining explorers.\nThe game ends when everyone has escaped or been knocked out. A player without an artifact, or knocked out in the Depths, cannot score. A player knocked out above the Depths can still score with an artifact.\n· Score artifacts, cards, Market items and collectibles at their values. Each gold is worth 1 point.\n· Escaping awards 20 extra points. Each Curse token loses 2 points.\nBreak score ties using each player’s highest-value artifact. Remaining ties share victory.\nSunken Treasures:\nMoving between two water rooms normally costs at least 2 movement. If you start in water and never enter a room with air, take 1 damage at turn end. Diving Gear prevents air damage and removes the extra underwater movement cost.\nThe Mummy’s Curse:\nWhile in the Mummy’s zone, choose one of these ways to fight it.\n· Spend 2 combat to gain 4 gold and 1 Curse token.\n· Spend 3 combat to remove half your Curse tokens, rounded up.\nRoll the pyramid die after each fight. When the Mummy enters a new zone, players there gain 1 Curse token.\nGold and Silk:\nTo clear a tunnel web, spend 1 extra movement or combat and collect the web. Collecting rewards in a webbed room costs 1 combat. Collected webs score their printed values.\nIn a room beside a mine, spend 2 skill and 1 cube from your personal supply to claim its gold. Each mine can be claimed once per game. After mining, you cannot spend movement again this turn.\nEligible miners rank by mines claimed. The top three gain 20, 10 and 5 extra points. Break ties using each player’s deepest claimed mine.\nTemple of the Ape Lords:\nCollect ape-aratus when passing through its tunnel. Types are Cog, Monkey Wrench and Banana. In the Jungle, square the count of each type and add the three scores: two Cogs and one Banana score 5 points. Spend 3 combat to defeat the Bronze Guardian and take one remaining ape-aratus.\nIn the Temple, spend a matching ape-aratus in a room connected to a gear to change its orientation. Ape-aratus does not score directly. Rage increases at certain levels can also rotate gears.\nTwo-game campaign:\nPlay the Jungle game, then the Temple game, carrying your collected ape-aratus into the second game. The top three eligible players in the first game receive campaign bonuses of 20, 10 and 5 points. The final result uses the second-game score plus this bonus, without adding the first-game total.\nSpider Queen’s Cache:\nSpend 8 skill and place 1 cube from your personal supply per claim. Each reward can be claimed once per game.\n· Reward 1: Gain 5 gold.\n· Reward 2: Gain 3 gold and 1 combat.\n· Reward 3: Gain 3 gold and 1 movement.\n· Reward 4: Gain 3 gold and recover 1 health.\n· Reward 5: Gain 1 Secret Tome and recover 1 health.\n· Reward 6: Gain 1 Secret Tome and 1 gold.\n· Reward 7: Gain 1 Secret Tome and 1 gold.\n· Reward 8: Gain 1 Secret Tome and 2 gold.",
			cards: {
				burgle: {
					name: "Burgle",
					text: "Gain 1 skill."
				},
				scramble: {
					name: "Scramble",
					text: "Gain 1 skill and 1 movement."
				},
				sidestep: {
					name: "Sidestep",
					text: "Gain 1 movement."
				},
				stumble: {
					name: "Stumble",
					text: "Make 1 Clank!"
				},
				explore: {
					name: "Explore",
					text: "Gain 2 skill and 1 movement."
				},
				mercenary: {
					name: "Mercenary",
					text: "Gain 1 skill and 2 combat."
				},
				tome: {
					name: "Secret Tome",
					text: "Worth 7 points."
				},
				"amulet-of-vigor": {
					name: "Amulet of Vigor",
					text: "Gain 4 skill.\nWhen acquired: Recover 1 health.\nWorth 3 points."
				},
				"animated-door": {
					name: "Animated Door",
					text: "Gain 1 movement.\nDragon attack symbol."
				},
				apothecary: {
					name: "Apothecary",
					text: "Discard 1 card from your hand, then choose one:\n· Gain 3 combat.\n· Gain 2 gold.\n· Recover 1 health.\nWorth 2 points."
				},
				archaeologist: {
					name: "Archaeologist",
					text: "Draw 1 card.\nIf you have a monkey idol: Gain 2 skill.\nWorth 1 point."
				},
				blecher: {
					name: "Belcher",
					text: "Gain 4 gold; Make 2 Clank!\nDragon attack symbol."
				},
				"boots-of-swiftness": {
					name: "Boots of Swiftness",
					text: "Gain 3 movement.\nWhen acquired: Gain 1 movement.\nWorth 3 points."
				},
				"bracers-of-agility": {
					name: "Bracers of Agility",
					text: "Draw 2 cards.\nWorth 2 points."
				},
				brilliance: {
					name: "Brilliance",
					text: "Draw 3 cards."
				},
				"cave-troll": {
					name: "Cave Troll",
					text: "Gain 3 gold; Draw 2 cards.\nOnly available in the Depths.\nDragon attack symbol."
				},
				"cleric-of-the-sun": {
					name: "Cleric of the Sun",
					text: "Gain 2 skill and 1 combat.\nWhen acquired: Recover 1 health.\nWorth 1 point."
				},
				"crystal-golem": {
					name: "Crystal Golem",
					text: "Gain 3 skill.\nYou must be in a Crystal Cave to defeat this monster."
				},
				"dead-run": {
					name: "Dead Run",
					text: "Gain 2 movement.\nMake 2 Clank!; Ignore Crystal Caves this turn."
				},
				diamond: {
					name: "Diamond",
					text: "Draw 1 card.\nWhen acquired: Make 2 Clank!\nDragon attack symbol.\nWorth 8 points."
				},
				"dragon-shrine": {
					name: "Dragon Shrine",
					text: "Choose one:\n· Gain 2 gold.\n· Trash one card from your play area or discard pile.\nDanger: attacks draw one extra cube while this is in the row."
				},
				"dragons-eye": {
					name: "Dragon’s Eye",
					text: "Draw 1 card.\nWhen acquired: Make 2 Clank!\nWorth 10 points if you escape.\nOnly available in the Depths.\nDragon attack symbol."
				},
				"dwarven-peddler": {
					name: "Dwarven Peddler",
					text: "Gain 1 movement.\nGain 2 gold.\nWorth 4 points if you have at least two of: chalice, dragon egg, monkey idol."
				},
				"elven-boots": {
					name: "Elven Boots",
					text: "Gain 1 skill and 1 movement.\nDraw 1 card.\nWorth 2 points."
				},
				"elven-cloak": {
					name: "Elven Cloak",
					text: "Gain 1 skill.\nRemove 2 Clank!; Draw 1 card.\nWorth 2 points."
				},
				"elven-dagger": {
					name: "Elven Dagger",
					text: "Gain 1 skill and 1 combat.\nDraw 1 card.\nWorth 2 points."
				},
				emerald: {
					name: "Emerald",
					text: "Draw 1 card.\nWhen acquired: Make 2 Clank!\nDragon attack symbol.\nWorth 5 points."
				},
				"flying-carpet": {
					name: "Flying Carpet",
					text: "Gain 2 movement.\nIgnore Crystal Caves this turn; Ignore tunnel monsters this turn.\nWorth 2 points."
				},
				"gem-collector": {
					name: "Gem Collector",
					text: "Gain 2 skill.\nRemove 2 Clank!\nGem cards cost 2 less skill to acquire this turn.\nWorth 2 points."
				},
				"invoker-of-the-ancients": {
					name: "Invoker of the Ancients",
					text: "Make 1 Clank!; Teleport to an adjacent room.\nWorth 1 point."
				},
				kobold: {
					name: "Kobold",
					text: "Gain 1 skill.\nDragon attack symbol.\nDanger: attacks draw one extra cube while this is in the row."
				},
				"kobold-merchant": {
					name: "Kobold Merchant",
					text: "Gain 2 gold.\nIf you have an artifact: Gain 2 skill.\nWorth 1 point."
				},
				ladder: {
					name: "Ladder",
					text: "Gain 2 movement."
				},
				"lucky-coin": {
					name: "Lucky Coin",
					text: "Gain 1 skill.\nMake 1 Clank!; Draw 1 card.\nWorth 1 point."
				},
				"master-burglar": {
					name: "Master Burglar",
					text: "Gain 2 skill.\nTrash one Burgle from your play area or discard pile.\nWorth 2 points."
				},
				"mister-whiskers": {
					name: "Mister Whiskers",
					text: "Choose one:\n· Trigger a dragon attack.\n· Remove 2 Clank!\nDragon attack symbol.\nWorth 1 point."
				},
				"monkeybot-3000": {
					name: "MonkeyBot 3000",
					text: "Make 3 Clank!; Draw 3 cards.\nDragon attack symbol.\nWorth 1 point."
				},
				"move-silently": {
					name: "Move Silently",
					text: "Gain 2 movement.\nRemove 2 Clank!"
				},
				ogre: {
					name: "Ogre",
					text: "Gain 5 gold.\nDragon attack symbol."
				},
				"ogre-grunt": {
					name: "Orc Grunt",
					text: "Gain 3 gold.\nDragon attack symbol."
				},
				overlord: {
					name: "Overlord",
					text: "Draw 2 cards.\nArrive: All players make 1 Clank!"
				},
				pickaxe: {
					name: "Pickaxe",
					text: "Gain 2 combat.\nGain 2 gold.\nWorth 2 points."
				},
				"rebel-captain": {
					name: "Rebel Captain",
					text: "Gain 2 skill.\nIf you play another Companion this turn: Draw 1 card.\nWorth 1 point."
				},
				"rebel-miner": {
					name: "Rebel Miner",
					text: "Gain 2 gold.\nIf you play another Companion this turn: Draw 1 card.\nWorth 1 point."
				},
				"rebel-scout": {
					name: "Rebel Scout",
					text: "Gain 2 movement.\nIf you play another Companion this turn: Draw 1 card.\nWorth 1 point."
				},
				"rebel-soldier": {
					name: "Rebel Soldier",
					text: "Gain 2 combat.\nIf you play another Companion this turn: Draw 1 card.\nWorth 1 point."
				},
				ruby: {
					name: "Ruby",
					text: "Draw 1 card.\nWhen acquired: Make 2 Clank!\nDragon attack symbol.\nWorth 6 points."
				},
				sapphire: {
					name: "Sapphire",
					text: "Draw 1 card.\nWhen acquired: Make 2 Clank!\nDragon attack symbol.\nWorth 4 points."
				},
				search: {
					name: "Search",
					text: "Gain 2 skill and 1 movement.\nGain 1 extra gold each time you gain gold this turn."
				},
				"scepter-of-the-ape-lord": {
					name: "Scepter of the Ape Lord",
					text: "Gain 3 skill.\nMake 3 Clank!\nWorth 3 points."
				},
				"silver-spear": {
					name: "Silver Spear",
					text: "Gain 3 combat.\nWhen acquired: Gain 1 combat.\nWorth 2 points."
				},
				"singing-sword": {
					name: "Singing Sword",
					text: "Gain 3 skill and 2 combat.\nMake 1 Clank!\nDragon attack symbol.\nWorth 2 points."
				},
				"sleight-of-hand": {
					name: "Sleight of Hand",
					text: "Discard 1 card from your hand, then draw 2 cards."
				},
				sneak: {
					name: "Sneak",
					text: "Gain 1 skill and 1 movement.\nRemove 2 Clank!"
				},
				shrine: {
					name: "Shrine",
					text: "Choose one:\n· Gain 1 gold.\n· Recover 1 health.\nArrive: Return 3 removed black cubes to the bag."
				},
				swagger: {
					name: "Swagger",
					text: "Gain 1 movement.\nGain 1 skill for each cube you actually place in the Clank! area this turn."
				},
				tattle: {
					name: "Tattle",
					text: "Gain 2 skill.\nEach opponent makes 1 Clank!"
				},
				teleporter: {
					name: "Teleporter",
					text: "Teleport to an adjacent room."
				},
				"the-duke": {
					name: "The Duke",
					text: "Gain 2 skill and 2 combat.\nWorth 1 point per 5 gold."
				},
				"the-mountain-king": {
					name: "The Mountain King",
					text: "Gain 2 skill, 1 combat and 1 movement.\nIf you have a Crown: Gain 1 combat; Gain 1 movement.\nWorth 3 points."
				},
				"the-queen-of-hearts": {
					name: "The Queen of Hearts",
					text: "Gain 3 skill and 1 combat.\nIf you have a Crown: Recover 1 health.\nWorth 3 points."
				},
				"the-vault": {
					name: "The Vault",
					text: "Gain 5 gold; Make 3 Clank!\nOnly available in the Depths.\nDragon attack symbol."
				},
				"treasure-hunter": {
					name: "Treasure Hunter",
					text: "Gain 2 skill and 2 combat.\nReplace a Dungeon Row card and resolve the new card’s Arrive effect. Its dragon attack symbol does not trigger an attack from this replacement.\nWorth 1 point."
				},
				"treasure-map": {
					name: "Treasure Map",
					text: "Gain 5 gold."
				},
				"tunnel-guide": {
					name: "Tunnel Guide",
					text: "Gain 1 combat and 1 movement.\nWorth 1 point."
				},
				"underworld-dealing": {
					name: "Underworld Dealing",
					text: "Choose one:\n· Gain 1 gold.\n· Pay 7 gold to gain 2 Secret Tomes."
				},
				"wand-of-recall": {
					name: "Wand of Recall",
					text: "Gain 2 skill.\nIf you have an artifact: Teleport to an adjacent room.\nWorth 1 point."
				},
				"wand-of-wind": {
					name: "Wand of Wind",
					text: "Choose one:\n· Teleport to an adjacent room.\n· Take a secret from an adjacent room.\nWorth 3 points."
				},
				watcher: {
					name: "Watcher",
					text: "Gain 3 gold; Each opponent makes 1 Clank!\nArrive: All players make 1 Clank!"
				},
				wizard: {
					name: "Wizard",
					text: "Gain 3 skill.\nWorth 2 points per Secret Tome."
				},
				alchemist: {
					name: "Alchemist",
					text: "Gain 2 skill.\nIf a Secret Tome is in your play area or discard pile: Gain 2 gold.\nWorth 1 point."
				},
				"ancient-invocation": {
					name: "Ancient Invocation",
					text: "Make 2 Clank!; Teleport to an adjacent room."
				},
				aspiration: {
					name: "Aspiration",
					text: "Draw 1 card.\nIf you have a Crown: Draw 1 card.\nWhen acquired: Gain 1 gold."
				},
				"black-pearl": {
					name: "Black Pearl",
					text: "Discard 1 card from your hand, then draw 2 cards.\nWhen acquired: Make 2 Clank!\nDragon attack symbol.\nWorth 5 points."
				},
				boomerang: {
					name: "Boomerang",
					text: "Gain 1 skill and 2 combat.\nWhen discarded from your hand during your turn: Return this card to your hand.\nWorth 1 point."
				},
				"burglars-boots": {
					name: "Burglar’s Boots",
					text: "Choose one:\n· Remove 2 Clank!\n· Gain 1 movement.\n· Gain 1 gold.\nWorth 1 point."
				},
				"climbing-gear": {
					name: "Climbing Gear",
					text: "Gain 1 movement.\nDiscard 1 card from your hand, then gain 1 movement.\nWorth 1 point."
				},
				"coin-purse": {
					name: "Coin Purse",
					text: "Gain 2 gold.\nWhen acquired: Gain 3 gold.\nWhen discarded from your hand during your turn: Gain 5 gold."
				},
				"crystal-fish": {
					name: "Crystal Fish",
					text: "Gain 2 gold.\nYou must be in a Crystal Cave or water room to defeat this monster.\nDragon attack symbol."
				},
				"deep-dive": {
					name: "Deep Dive",
					text: "Discard 3 cards from your hand, then draw 5 cards."
				},
				"elven-ranger": {
					name: "Elven Ranger",
					text: "Gain 1 skill, 1 combat and 1 movement.\nDraw 1 card.\nWorth 2 points."
				},
				"eye-in-the-water": {
					name: "Eye-in-the-Water",
					text: "Choose one:\n· Gain 2 gold.\n· Remove 2 Clank!\nArrive: All players make 2 Clank!"
				},
				"fishing-pole": {
					name: "Fishing Pole",
					text: "Draw 1 card; Discard 1 card from your hand.\nWorth 1 point."
				},
				"grand-plan": {
					name: "Grand Plan",
					text: "Gain 2 skill.\nGain 2 gold.\nWhen acquired: Gain 2 gold.\nWorth 7 points if you have at least three Market items."
				},
				pickpocket: {
					name: "Pickpocket",
					text: "Gain 1 movement.\nAcquire a card from the Dungeon Row for free (cost 2 or less).\nWhen discarded from your hand during your turn: Acquire a card from the Dungeon Row for free (cost 2 or less).\nWorth 1 point."
				},
				"pipe-organ": {
					name: "Pipe Organ",
					text: "Increase or decrease rage by one."
				},
				medic: {
					name: "Medic",
					text: "Gain 1 skill.\nDiscard 1 card from your hand, then Recover 1 health.\nWorth 1 point."
				},
				merling: {
					name: "Merling",
					text: "Gain 1 skill, 1 combat and 1 movement.\nWorth 1 point."
				},
				mermaid: {
					name: "Mermaid",
					text: "Gain 2 skill and 1 movement.\nIgnore air damage and the extra underwater movement cost this turn.\nWorth 1 point."
				},
				"rebel-brawler": {
					name: "Rebel Brawler",
					text: "Gain 2 combat.\nMake 1 Clank!\nIf you play another Companion this turn: Draw 1 card.\nWorth 1 point."
				},
				"rebel-scholar": {
					name: "Rebel Scholar",
					text: "Draw 1 card.\nIf you play another Companion this turn: Draw 1 card.\nWorth 1 point."
				},
				saurian: {
					name: "Saurian",
					text: "Gain 4 gold.\nDragon attack symbol.\nDanger: attacks draw one extra cube while this is in the row."
				},
				"short-cut": {
					name: "Short Cut",
					text: "Gain 1 movement.\nMake 1 Clank!\nWhen acquired: Gain 1 movement.\nWhen discarded from your hand during your turn: Gain 2 movement."
				},
				"shrine-of-the-mermaid": {
					name: "Shrine of the Mermaid",
					text: "Choose one:\n· Gain 2 gold.\n· Teleport to an adjacent room if in water.\nDanger: attacks draw one extra cube while this is in the row."
				},
				"silver-pearl": {
					name: "Silver Pearl",
					text: "Discard 1 card from your hand, then draw 2 cards.\nWhen acquired: Make 2 Clank!\nDragon attack symbol.\nWorth 2 points."
				},
				sorcerer: {
					name: "Sorcerer",
					text: "Gain 1 Secret Tome.\nOnly available in the Depths.\nDragon attack symbol."
				},
				"white-pearl": {
					name: "White Pearl",
					text: "Discard 1 card from your hand, then draw 2 cards.\nWhen acquired: Make 2 Clank!\nDragon attack symbol.\nWorth 3 points."
				},
				"blessed-fountain": {
					name: "Blessed Fountain",
					text: "Recover 1 health; Remove 1 Curse token.\nDragon attack symbol."
				},
				"book-of-the-dead": {
					name: "Book of the Dead",
					text: "Draw 3 cards.\nWorth 1 point per Curse.\nDragon attack symbol."
				},
				bullwhip: {
					name: "Bullwhip",
					text: "Gain 2 skill, 1 combat and 1 movement.\nMake 1 Clank!\nWorth 2 points."
				},
				camel: {
					name: "Camel",
					text: "Gain 1 combat and 1 movement.\nIf you find a secret this turn: Draw 1 card.\nWorth 1 point."
				},
				"canopic-jars": {
					name: "Canopic Jars",
					text: "Draw 4 cards; Gain 1 Curse token.\nArrive: Roll the pyramid die and move the Mummy."
				},
				crocodilian: {
					name: "Crocodilian",
					text: "Remove 1 Clank!; Remove 1 Curse token.\nDragon attack symbol."
				},
				"crystal-skull": {
					name: "Crystal Skull",
					text: "Gain 3 skill.\nIf at least two Gems are in your play area or discard pile: Gain 1 Secret Tome.\nWorth 2 points."
				},
				"death-mask": {
					name: "Death Mask",
					text: "Gain 2 skill and 2 combat.\nRemove 1 Curse token.\nArrive: Roll the pyramid die and move the Mummy.\nWorth 1 point."
				},
				doomsayer: {
					name: "Doomsayer",
					text: "Gain 2 combat.\nIf your cubes are in the Clank! area: Each opponent gains 1 Curse token.\nWorth 2 points."
				},
				"daring-explorer": {
					name: "Daring Explorer",
					text: "Gain 2 skill and 1 movement.\nTake a secret or monkey idol from an adjacent room by making 2 Clank!\nDanger: attacks draw one extra cube while this is in the row.\nWorth 3 points."
				},
				excavate: {
					name: "Excavate",
					text: "Make 2 Clank!; Draw 2 cards.\nArrive: Roll the pyramid die and move the Mummy."
				},
				historian: {
					name: "Historian",
					text: "Gain 2 skill.\nIf your cubes are in the Clank! area: Trash one card from your play area or discard pile.\nWorth 2 points."
				},
				jasper: {
					name: "Jasper",
					text: "Draw 1 card.\nWhen acquired: Make 2 Clank!; Gain 1 Curse token.\nDragon attack symbol.\nWorth 7 points."
				},
				kittypatra: {
					name: "Kittypatra",
					text: "Choose one:\n· Remove 2 Clank!\n· Remove 1 Curse token.\nArrive: Roll the pyramid die and move the Mummy.\nWorth 1 point."
				},
				"lapis-lazuli": {
					name: "Lapis Lazuli",
					text: "Draw 1 card.\nWhen acquired: Make 2 Clank!; Gain 1 Curse token.\nDragon attack symbol.\nWorth 8 points."
				},
				"need-for-greed": {
					name: "Need for Greed",
					text: "Gain 1 skill.\nDiscard 1 card from your hand, then gain 2 gold."
				},
				"ornate-khopesh": {
					name: "Ornate Khopesh",
					text: "Gain 3 combat.\nDraw 1 card.\nWhen acquired: Gain 3 combat.\nWorth 3 points."
				},
				purify: {
					name: "Purify",
					text: "Gain 3 skill.\nWhen acquired: Remove 1 Curse token.\nWorth 5 points if you have fewer Curses than every opponent."
				},
				"rebel-burglar": {
					name: "Rebel Burglar",
					text: "Trash one Burgle from your play area or discard pile.\nIf you play another Companion this turn: Draw 1 card.\nWorth 1 point."
				},
				"rebel-mystic": {
					name: "Rebel Mystic",
					text: "Teleport to an adjacent room.\nIf you play another Companion this turn: Draw 1 card.\nWorth 1 point."
				},
				"ring-of-wishes": {
					name: "Ring of Wishes",
					text: "Choose three times; repeats allowed:\n· Gain 1 gold.\n· Gain 1 movement.\n· Remove 1 Curse token."
				},
				"royal-bodyguard": {
					name: "Royal Bodyguard",
					text: "Gain 1 movement.\nIf you have a Crown: Ignore tunnel icons this turn.\nWorth 1 point."
				},
				"scorpion-queen": {
					name: "Scorpion Queen",
					text: "Gain 7 gold minus your Curses, minimum 0.\nDragon attack symbol."
				},
				serpentine: {
					name: "Serpentine",
					text: "Draw 1 card.\nWhen acquired: Make 2 Clank!; Gain 1 Curse token.\nDragon attack symbol.\nWorth 6 points."
				},
				"staff-of-the-ancients": {
					name: "Staff of the Ancients",
					text: "Gain 2 gold.\nIf a Gem is in your play area or discard pile: Teleport to an adjacent room.\nWorth 1 point."
				},
				"stone-simian": {
					name: "Stone Simian",
					text: "Gain 3 gold.\nIf you have a monkey idol: Recover 1 health.\nDragon attack symbol."
				},
				"thrill-seeker": {
					name: "Thrill Seeker",
					text: "Gain 1 skill and 1 movement.\nIf your cubes are in the Clank! area: Gain 2 movement.\nWorth 1 point."
				},
				"tomb-robber": {
					name: "Tomb Robber",
					text: "Gain 1 combat and 2 movement.\nIf you have an artifact: Gain 2 gold.\nArrive: Roll the pyramid die and move the Mummy.\nWorth 2 points."
				},
				"tomb-snake": {
					name: "Tomb Snake",
					text: "Gain 2 skill.\nArrive: All players make 1 Clank!\nOnly available in the Depths."
				},
				whiskersphinx: {
					name: "Whiskersphinx",
					text: "Draw 2 cards; Remove 1 Curse token.\nArrive: Roll the pyramid die and move the Mummy."
				},
				"brawn-vs-boots": {
					name: "Brawn vs. Boots",
					text: "Gain 2 skill.\nChoose one:\n· Gain 2 combat.\n· Gain 2 movement."
				},
				"enchanted-dice": {
					name: "Enchanted Dice",
					text: "Gain 2 skill.\nDraw two cubes from the Dragon Bag, then return them. Gain 1 gold for each black cube drawn.\nWorth 1 point."
				},
				"dire-wolf": {
					name: "Dire Wolf",
					text: "Gain 1 skill and 1 movement.\nFor each monster in the Dungeon Row and each permanent monster, make 1 Clank! and gain 1 combat.\nWorth 1 point."
				},
				"expedition-leader": {
					name: "Expedition Leader",
					text: "Gain 2 skill, 1 combat and 1 movement.\nGain 1 extra gold each time you gain gold this turn.\nWorth 2 points."
				},
				"friendly-watcher": {
					name: "Friendly Watcher",
					text: "Gain 3 gold; Each opponent makes 1 Clank!\nArrive: All players make 1 Clank!\nWorth 1 point."
				},
				"magic-spectacles": {
					name: "Magic Spectacles",
					text: "Gain 2 skill.\nLook at your top card; leave it on top or move it to the bottom, then draw one.\nWorth 2 points."
				},
				"mummy-hunters": {
					name: "Mummy Hunters",
					text: "Gain 2 combat and 1 movement.\nIgnore Curses from the Mummy this turn.\nArrive: Roll the pyramid die and move the Mummy.\nWorth 1 point."
				},
				"opal-apestone": {
					name: "Opal Apestone",
					text: "Remove 1 Clank!; Draw 1 card.\nWhen acquired: Make 3 Clank!\nDragon attack symbol.\nWorth 3 points."
				},
				siren: {
					name: "Siren",
					text: "Acquire a Companion from the Dungeon Row for free.\nWorth 2 points."
				},
				"snack-table": {
					name: "Snack Table",
					text: "Recover 1 health.\nEach other player may pay you 1 gold to recover 1 health of their own.\nDragon attack symbol."
				},
				trailblazer: {
					name: "Trailblazer",
					text: "Gain 1 skill, 1 combat and 1 movement.\nIf you enter water, gain a Curse, clear a web, or mine this turn: Gain 2 gold.\nWorth 2 points."
				},
				"wand-of-time": {
					name: "Wand of Time",
					text: "Gain 2 skill.\nReturn one discarded card to your hand; if your discard pile is empty, draw two.\nWorth 2 points."
				},
				"wishing-wall": {
					name: "Wishing Wall",
					text: "Choose two different options:\n· Trash a card from your play area or discard pile.\n· Gain 2 combat.\n· Gain 2 movement.\n· Recover 1 health."
				}
			},
			action: {
				play: "Play {{card}}",
				acquire: "Acquire {{card}}",
				defeat: "Defeat {{card}}",
				market: "Buy {{item}}",
				guardian: "Defeat the Bronze Guardian to gain {{item}}",
				mummyGold: "Defeat the Mummy: gain 4 gold and 1 Curse token",
				mummyCleanse: "Defeat the Mummy: remove half your Curse tokens, rounded up",
				mine: "Excavate mine {{n}}",
				rotate: "Spend {{item}} to turn gear {{n}} to orientation {{orientation}}",
				potion: "Use {{item}}",
				spring: "Trash {{card}} at the Magic Spring",
				discard: "Discard {{card}} from your hand",
				trash: "Trash {{card}}",
				recall: "Return {{card}} from your discard pile to your hand",
				teleport: "Teleport to room {{n}}",
				adjacent: "Collect the reward in room {{n}}",
				replace: "Replace {{card}}",
				freeAcquire: "Acquire {{card}} for free"
			},
			resource: {
				skill: "{{n}} skill",
				swords: "{{n}} combat",
				boots: "{{n}} movement",
				gold: "{{n}} gold",
				clank: "{{n}} Clank!",
				curse: "{{n}} Curse tokens",
				oneCurse: "1 Curse token",
				heal: "Recover {{n}} health",
				makeClank: "Make {{n}} Clank!"
			}
		}
	}
};
//#endregion
export { qn as default };
