import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { BottomSheet as s } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { useWakeLock as u } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { useFxAnchor as f } from "@bgparty/sdk/fx/anchors";
import { LogTicker as p } from "@bgparty/sdk/ui/log-sheet";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { usePrefersReducedMotion as _ } from "@bgparty/sdk/fx/use-reduced-motion";
import { HintRing as v } from "@bgparty/sdk/ui/hint-ring";
import { IconBack as y, IconBot as b, IconExpand as ee, IconLog as te } from "@bgparty/sdk/icons";
import { seatName as ne } from "@bgparty/sdk/ui/player-strip";
import { Confetti as re } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as x, OptionSection as S, OptionSwitch as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/unstoppable/data.ts
var w = {
	12800: {
		id: 12800,
		name: "games.unstoppable.cards.c12800",
		kind: "tactic",
		cost: 0,
		level: 0,
		play: [{
			op: "credits",
			n: 1
		}]
	},
	12803: {
		id: 12803,
		name: "games.unstoppable.cards.c12803",
		kind: "tactic",
		cost: 1,
		level: 0,
		play: [{
			op: "damage",
			n: 1
		}]
	},
	13600: {
		id: 13600,
		name: "games.unstoppable.cards.c13600",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "damage",
			n: 2
		}],
		expansion: !1
	},
	13601: {
		id: 13601,
		name: "games.unstoppable.cards.c13601",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "choice",
			options: [
				[{
					op: "damage",
					n: 2
				}],
				[{
					op: "credits",
					n: 2
				}],
				[{
					op: "damage",
					n: 2
				}, {
					op: "credits",
					n: 2
				}]
			],
			flag: "upgradedThird"
		}],
		expansion: !0
	},
	13602: {
		id: 13602,
		name: "games.unstoppable.cards.c13602",
		faction: "silver",
		kind: "ally",
		cost: 1,
		level: 1,
		play: [],
		exhaust: [[{
			op: "armor",
			n: 1
		}, {
			op: "damage",
			n: 1,
			when: "conspire"
		}]],
		expansion: !1
	},
	13603: {
		id: 13603,
		name: "games.unstoppable.cards.c13603",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "credits",
			n: 2
		}, {
			op: "train",
			n: 1,
			when: "upgraded"
		}],
		expansion: !0
	},
	13604: {
		id: 13604,
		name: "games.unstoppable.cards.c13604",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "credits",
			n: 1
		}, {
			op: "damage",
			n: 2,
			when: "upgrades2"
		}],
		expansion: !1
	},
	13605: {
		id: 13605,
		name: "games.unstoppable.cards.c13605",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "train",
			n: 1
		}, {
			op: "damage",
			n: 2,
			when: "health5"
		}],
		expansion: !1
	},
	13606: {
		id: 13606,
		name: "games.unstoppable.cards.c13606",
		faction: "viren",
		kind: "tactic",
		cost: 2,
		level: 1,
		play: [{
			op: "damage",
			n: 2
		}, {
			op: "refresh",
			n: "focus"
		}],
		expansion: !1
	},
	13607: {
		id: 13607,
		name: "games.unstoppable.cards.c13607",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "credits",
			n: 3
		}],
		expansion: !1
	},
	13608: {
		id: 13608,
		name: "games.unstoppable.cards.c13608",
		faction: "council",
		kind: "ally",
		cost: 2,
		level: 1,
		play: [],
		exhaust: [[{
			op: "pay",
			n: 1,
			flag: "discardHand",
			effects: [{
				op: "damage",
				n: 3
			}]
		}, {
			op: "credits",
			n: 1,
			when: "unite4"
		}]],
		expansion: !1
	},
	13609: {
		id: 13609,
		name: "games.unstoppable.cards.c13609",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "bargain",
			n: 4,
			effects: [{
				op: "damage",
				n: 2
			}, {
				op: "damage",
				n: 2
			}]
		}],
		expansion: !1
	},
	13610: {
		id: 13610,
		name: "games.unstoppable.cards.c13610",
		faction: "silver",
		kind: "ally",
		cost: 1,
		level: 1,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 2,
			when: "upgradedConspire"
		}]],
		expansion: !0
	},
	13611: {
		id: 13611,
		name: "games.unstoppable.cards.c13611",
		faction: "junker",
		kind: "tactic",
		cost: 0,
		level: 1,
		play: [{
			op: "damage",
			n: 1
		}, {
			op: "bargain",
			n: 3,
			effects: [{
				op: "discount",
				n: 3,
				flag: "upgrade"
			}]
		}],
		expansion: !1
	},
	13612: {
		id: 13612,
		name: "games.unstoppable.cards.c13612",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "damage",
			n: 1
		}, {
			op: "credits",
			n: "focus"
		}],
		expansion: !1
	},
	13613: {
		id: 13613,
		name: "games.unstoppable.cards.c13613",
		faction: "council",
		kind: "tactic",
		cost: 2,
		level: 1,
		play: [
			{
				op: "damage",
				n: 1
			},
			{
				op: "train",
				n: 1
			},
			{
				op: "damage",
				n: 1,
				times: "unite"
			}
		],
		expansion: !1
	},
	13614: {
		id: 13614,
		name: "games.unstoppable.cards.c13614",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "choice",
			options: [[{
				op: "armor",
				n: 3
			}], [{
				op: "exchange",
				n: 3,
				resource: "armor",
				flag: "equalLevel"
			}]]
		}],
		expansion: !0
	},
	13615: {
		id: 13615,
		name: "games.unstoppable.cards.c13615",
		faction: "council",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [
			{
				op: "damage",
				n: 1
			},
			{
				op: "train",
				n: 1
			},
			{
				op: "damage",
				n: 1,
				when: "upgradedUnite3"
			}
		],
		expansion: !0
	},
	13616: {
		id: 13616,
		name: "games.unstoppable.cards.c13616",
		faction: "junker",
		kind: "ally",
		cost: 1,
		level: 1,
		play: [],
		exhaust: [[{
			op: "credits",
			n: 1
		}, {
			op: "credits",
			n: 1,
			when: "upgraded"
		}]],
		expansion: !0
	},
	13617: {
		id: 13617,
		name: "games.unstoppable.cards.c13617",
		faction: "viren",
		kind: "ally",
		cost: 1,
		level: 1,
		play: [],
		exhaust: [[{
			op: "actions",
			n: 1
		}, {
			op: "armor",
			n: 1
		}]],
		expansion: !0
	},
	13618: {
		id: 13618,
		name: "games.unstoppable.cards.c13618",
		faction: "council",
		kind: "tactic",
		cost: 0,
		level: 1,
		play: [{
			op: "train",
			n: 1
		}, {
			op: "train",
			n: 1,
			when: "unite3"
		}],
		expansion: !1
	},
	13619: {
		id: 13619,
		name: "games.unstoppable.cards.c13619",
		faction: "junker",
		kind: "ally",
		cost: 2,
		level: 1,
		play: [],
		exhaust: [[{
			op: "choice",
			options: [[{
				op: "credits",
				n: 1
			}], [{
				op: "damage",
				n: 1
			}]]
		}]],
		expansion: !1
	},
	13620: {
		id: 13620,
		name: "games.unstoppable.cards.c13620",
		faction: "viren",
		kind: "ally",
		cost: 3,
		level: 1,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 2
		}]],
		expansion: !1
	},
	13621: {
		id: 13621,
		name: "games.unstoppable.cards.c13621",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 1,
		play: [{
			op: "health",
			n: 1,
			when: "conspire"
		}, {
			op: "pay",
			n: 1,
			resource: "health",
			effects: [{
				op: "damage",
				n: 2
			}]
		}],
		expansion: !1
	},
	13622: {
		id: 13622,
		name: "games.unstoppable.cards.c13622",
		faction: "council",
		kind: "tactic",
		cost: 2,
		level: 1,
		play: [{
			op: "damage",
			n: 2
		}, {
			op: "eliminate",
			n: 1,
			when: "unite3"
		}],
		expansion: !1
	},
	13623: {
		id: 13623,
		name: "games.unstoppable.cards.c13623",
		faction: "viren",
		kind: "tactic",
		cost: 0,
		level: 1,
		play: [{
			op: "actions",
			n: 1
		}, {
			op: "refresh",
			n: 1,
			when: "conspire"
		}],
		expansion: !1
	},
	13400: {
		id: 13400,
		name: "games.unstoppable.cards.c13400",
		faction: "junker",
		kind: "ally",
		cost: 1,
		level: 2,
		play: [],
		exhaust: [[{
			op: "credits",
			n: 2
		}, {
			op: "credits",
			n: 1,
			when: "conspire"
		}]],
		expansion: !1
	},
	13401: {
		id: 13401,
		name: "games.unstoppable.cards.c13401",
		faction: "viren",
		kind: "ally",
		cost: 2,
		level: 2,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 2
		}, {
			op: "actions",
			n: 1,
			when: "upgraded"
		}]],
		expansion: !0
	},
	13402: {
		id: 13402,
		name: "games.unstoppable.cards.c13402",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [
			{
				op: "damage",
				n: 2
			},
			{
				op: "health",
				n: 1,
				when: "upgraded"
			},
			{
				op: "armor",
				n: 1,
				when: "upgraded"
			}
		],
		expansion: !0
	},
	13403: {
		id: 13403,
		name: "games.unstoppable.cards.c13403",
		faction: "junker",
		kind: "tactic",
		cost: 0,
		level: 2,
		play: [
			{
				op: "actions",
				n: 1
			},
			{
				op: "health",
				n: 1
			},
			{
				op: "bargain",
				n: 3,
				effects: [{
					op: "damage",
					n: 2
				}]
			}
		],
		expansion: !1
	},
	13404: {
		id: 13404,
		name: "games.unstoppable.cards.c13404",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [{
			op: "health",
			n: 2
		}, {
			op: "damage",
			n: "sourceUpgrades"
		}],
		expansion: !0
	},
	13405: {
		id: 13405,
		name: "games.unstoppable.cards.c13405",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [{
			op: "pay",
			n: 3,
			resource: "health",
			flag: "embrace",
			effects: [{
				op: "damage",
				n: 2
			}, {
				op: "damage",
				n: 1
			}]
		}, {
			op: "damage",
			n: 2,
			when: "upgraded"
		}],
		expansion: !0
	},
	13406: {
		id: 13406,
		name: "games.unstoppable.cards.c13406",
		faction: "silver",
		kind: "tactic",
		cost: 2,
		level: 2,
		play: [{
			op: "damage",
			n: 2
		}, {
			op: "damage",
			n: 1
		}],
		expansion: !1
	},
	13407: {
		id: 13407,
		name: "games.unstoppable.cards.c13407",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [{
			op: "exchange",
			n: 10,
			resource: "health",
			flag: "blood"
		}],
		expansion: !1
	},
	13408: {
		id: 13408,
		name: "games.unstoppable.cards.c13408",
		faction: "council",
		kind: "tactic",
		cost: 0,
		level: 2,
		play: [{
			op: "train",
			n: 1
		}, {
			op: "damage",
			n: 1
		}],
		passive: ["trainRequired"],
		expansion: !1
	},
	13409: {
		id: 13409,
		name: "games.unstoppable.cards.c13409",
		faction: "council",
		kind: "tactic",
		cost: 2,
		level: 2,
		play: [{
			op: "armor",
			n: 3
		}, {
			op: "refresh",
			n: 1,
			when: "unite3"
		}],
		expansion: !1
	},
	13410: {
		id: 13410,
		name: "games.unstoppable.cards.c13410",
		faction: "viren",
		kind: "tactic",
		cost: 0,
		level: 1,
		play: [{
			op: "actions",
			n: 2
		}, {
			op: "credits",
			n: 1
		}],
		expansion: !1
	},
	13411: {
		id: 13411,
		name: "games.unstoppable.cards.c13411",
		faction: "council",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [{
			op: "train",
			n: 1
		}, {
			op: "revealCores",
			n: 3,
			when: "unite3",
			flag: "small"
		}],
		expansion: !1
	},
	13412: {
		id: 13412,
		name: "games.unstoppable.cards.c13412",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [
			{
				op: "actions",
				n: 2
			},
			{
				op: "credits",
				n: 1
			},
			{
				op: "armor",
				n: 2
			}
		],
		expansion: !1
	},
	13413: {
		id: 13413,
		name: "games.unstoppable.cards.c13413",
		faction: "junker",
		kind: "tactic",
		cost: 2,
		level: 2,
		play: [{
			op: "bargain",
			n: 3,
			effects: [{
				op: "credits",
				n: 4
			}]
		}],
		passive: ["upgradeBuyDamage2Health1"],
		expansion: !1
	},
	13414: {
		id: 13414,
		name: "games.unstoppable.cards.c13414",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [
			{
				op: "health",
				n: 1
			},
			{
				op: "armor",
				n: 3
			},
			{
				op: "actions",
				n: 1,
				when: "kills2"
			}
		],
		expansion: !1
	},
	13415: {
		id: 13415,
		name: "games.unstoppable.cards.c13415",
		faction: "council",
		kind: "tactic",
		cost: 2,
		level: 2,
		play: [{
			op: "health",
			n: 2
		}, {
			op: "eliminate",
			n: 1
		}],
		expansion: !1
	},
	13416: {
		id: 13416,
		name: "games.unstoppable.cards.c13416",
		faction: "council",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [{
			op: "train",
			n: 1
		}, {
			op: "damage",
			n: 2,
			when: "upgraded"
		}],
		expansion: !0
	},
	13417: {
		id: 13417,
		name: "games.unstoppable.cards.c13417",
		faction: "silver",
		kind: "ally",
		cost: 1,
		level: 3,
		play: [],
		exhaust: [[{
			op: "health",
			n: 1
		}, {
			op: "damage",
			n: 2,
			when: "conspire"
		}]],
		expansion: !1
	},
	13418: {
		id: 13418,
		name: "games.unstoppable.cards.c13418",
		faction: "silver",
		kind: "tactic",
		cost: 3,
		level: 2,
		play: [
			{
				op: "damage",
				n: 6
			},
			{
				op: "armor",
				n: 2
			},
			{
				op: "train",
				n: 1,
				when: "conspire"
			}
		],
		expansion: !1
	},
	13419: {
		id: 13419,
		name: "games.unstoppable.cards.c13419",
		faction: "viren",
		kind: "tactic",
		cost: 3,
		level: 2,
		play: [{
			op: "armor",
			n: 6
		}, {
			op: "retrieve",
			n: 1,
			flag: "allyFromDeck"
		}],
		expansion: !1
	},
	13420: {
		id: 13420,
		name: "games.unstoppable.cards.c13420",
		faction: "viren",
		kind: "ally",
		cost: 2,
		level: 2,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 2,
			flag: "onDeckDraw"
		}]],
		expansion: !1
	},
	13421: {
		id: 13421,
		name: "games.unstoppable.cards.c13421",
		faction: "council",
		kind: "ally",
		cost: 1,
		level: 2,
		play: [],
		exhaust: [[{
			op: "train",
			n: 1
		}, {
			op: "damage",
			n: 2,
			when: "unite3"
		}]],
		expansion: !0
	},
	13422: {
		id: 13422,
		name: "games.unstoppable.cards.c13422",
		faction: "council",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [
			{
				op: "damage",
				n: 1
			},
			{
				op: "damage",
				n: 1
			},
			{
				op: "train",
				n: 1
			}
		],
		expansion: !1
	},
	13423: {
		id: 13423,
		name: "games.unstoppable.cards.c13423",
		faction: "viren",
		kind: "tactic",
		cost: 0,
		level: 2,
		play: [{
			op: "armor",
			n: 2
		}, {
			op: "damage",
			n: "focus"
		}],
		expansion: !1
	},
	13424: {
		id: 13424,
		name: "games.unstoppable.cards.c13424",
		faction: "silver",
		kind: "tactic",
		cost: 2,
		level: 2,
		play: [{
			op: "damage",
			n: 6
		}, {
			op: "retrieve",
			n: 1,
			zone: "discard",
			flag: "random"
		}],
		expansion: !1
	},
	13425: {
		id: 13425,
		name: "games.unstoppable.cards.c13425",
		faction: "silver",
		kind: "ally",
		cost: 2,
		level: 2,
		play: [],
		exhaust: [[{
			op: "pay",
			n: 2,
			resource: "health",
			effects: [{
				op: "draw",
				n: 1,
				flag: "bottom"
			}]
		}, {
			op: "armor",
			n: 2,
			when: "conspire"
		}]],
		expansion: !1
	},
	13426: {
		id: 13426,
		name: "games.unstoppable.cards.c13426",
		faction: "viren",
		kind: "ally",
		cost: 2,
		level: 2,
		play: [],
		exhaust: [[{
			op: "actions",
			n: "focus"
		}]],
		expansion: !1
	},
	13427: {
		id: 13427,
		name: "games.unstoppable.cards.c13427",
		faction: "junker",
		kind: "tactic",
		cost: 0,
		level: 2,
		play: [{
			op: "damage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			when: "firstPlay",
			flag: "improvise"
		}],
		expansion: !1
	},
	13428: {
		id: 13428,
		name: "games.unstoppable.cards.c13428",
		faction: "junker",
		kind: "ally",
		cost: 2,
		level: 2,
		play: [],
		exhaust: [[{
			op: "actions",
			n: 1
		}, {
			op: "credits",
			n: 1
		}]],
		expansion: !1
	},
	13429: {
		id: 13429,
		name: "games.unstoppable.cards.c13429",
		faction: "council",
		kind: "ally",
		cost: 3,
		level: 2,
		play: [],
		exhaust: [[
			{
				op: "damage",
				n: 2
			},
			{
				op: "train",
				n: 1
			},
			{
				op: "faction",
				n: 1
			}
		]],
		expansion: !1
	},
	13430: {
		id: 13430,
		name: "games.unstoppable.cards.c13430",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 2,
		play: [{
			op: "damage",
			n: 2
		}, {
			op: "credits",
			n: 2,
			when: "conspire"
		}],
		expansion: !1
	},
	13700: {
		id: 13700,
		name: "games.unstoppable.cards.c13700",
		faction: "junker",
		kind: "tactic",
		cost: 0,
		level: 3,
		play: [
			{
				op: "credits",
				n: 1
			},
			{
				op: "damage",
				n: 1
			},
			{
				op: "actions",
				n: 1,
				when: "upgrades4"
			},
			{
				op: "damage",
				n: 2,
				when: "upgrades4"
			}
		],
		expansion: !1
	},
	13701: {
		id: 13701,
		name: "games.unstoppable.cards.c13701",
		faction: "council",
		kind: "tactic",
		cost: 2,
		level: 3,
		play: [{
			op: "eliminate",
			n: 1
		}, {
			op: "damage",
			n: 1,
			times: "unite"
		}],
		expansion: !1
	},
	13702: {
		id: 13702,
		name: "games.unstoppable.cards.c13702",
		faction: "viren",
		kind: "ally",
		cost: 2,
		level: 3,
		play: [],
		exhaust: [[{
			op: "health",
			n: 1
		}, {
			op: "refresh",
			n: 1,
			when: "conspire"
		}]],
		expansion: !1
	},
	13703: {
		id: 13703,
		name: "games.unstoppable.cards.c13703",
		faction: "viren",
		kind: "tactic",
		cost: 2,
		level: 3,
		play: [
			{
				op: "damage",
				n: 3
			},
			{
				op: "armor",
				n: 2
			},
			{
				op: "actions",
				n: 2,
				when: "armor5"
			}
		],
		expansion: !0
	},
	13704: {
		id: 13704,
		name: "games.unstoppable.cards.c13704",
		faction: "viren",
		kind: "tactic",
		cost: 3,
		level: 3,
		play: [],
		passive: ["alliesActions1Damage3"],
		expansion: !1
	},
	13705: {
		id: 13705,
		name: "games.unstoppable.cards.c13705",
		faction: "junker",
		kind: "tactic",
		cost: 0,
		level: 3,
		play: [{
			op: "actions",
			n: 1
		}],
		passive: ["otherPlayDamage1"],
		expansion: !1
	},
	13706: {
		id: 13706,
		name: "games.unstoppable.cards.c13706",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 3,
		play: [{
			op: "retrieve",
			n: 1,
			zone: "discard",
			maxLevel: 3
		}, {
			op: "actions",
			n: 1,
			when: "conspire"
		}],
		expansion: !1
	},
	13707: {
		id: 13707,
		name: "games.unstoppable.cards.c13707",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 3,
		play: [{
			op: "damage",
			n: 2
		}, {
			op: "damage",
			n: "focus"
		}],
		expansion: !1
	},
	13708: {
		id: 13708,
		name: "games.unstoppable.cards.c13708",
		faction: "council",
		kind: "tactic",
		cost: 3,
		level: 3,
		play: [
			{
				op: "damage",
				n: 2
			},
			{
				op: "damage",
				n: 2
			},
			{
				op: "health",
				n: 2
			},
			{
				op: "eliminate",
				n: 1,
				when: "unite3"
			}
		],
		expansion: !1
	},
	13709: {
		id: 13709,
		name: "games.unstoppable.cards.c13709",
		faction: "junker",
		kind: "ally",
		cost: 1,
		level: 3,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 2,
			times: "sourceUpgrades",
			ignoreTaunt: !0
		}]],
		expansion: !1
	},
	13710: {
		id: 13710,
		name: "games.unstoppable.cards.c13710",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 3,
		play: [{
			op: "damage",
			n: "silverDiscard"
		}, {
			op: "damage",
			n: "focus"
		}],
		expansion: !1
	},
	13711: {
		id: 13711,
		name: "games.unstoppable.cards.c13711",
		faction: "council",
		kind: "ally",
		cost: 2,
		level: 3,
		play: [],
		exhaust: [[{
			op: "mark",
			n: 2,
			flag: "playedDamage"
		}]],
		acquire: [{
			op: "upgrade",
			n: 0,
			flag: "self"
		}],
		expansion: !1
	},
	13712: {
		id: 13712,
		name: "games.unstoppable.cards.c13712",
		faction: "junker",
		kind: "tactic",
		cost: 2,
		level: 3,
		play: [{
			op: "credits",
			n: 2
		}, {
			op: "bargain",
			n: 3,
			effects: [{
				op: "upgrade",
				n: 5,
				flag: "ifSelfTrigger"
			}]
		}],
		expansion: !0
	},
	13713: {
		id: 13713,
		name: "games.unstoppable.cards.c13713",
		faction: "council",
		kind: "tactic",
		cost: 2,
		level: 3,
		play: [
			{
				op: "damage",
				n: 2
			},
			{
				op: "actions",
				n: 1
			},
			{
				op: "train",
				n: 1,
				times: "unite"
			}
		],
		expansion: !1
	},
	13714: {
		id: 13714,
		name: "games.unstoppable.cards.c13714",
		faction: "junker",
		kind: "ally",
		cost: 0,
		level: 3,
		play: [],
		exhaust: [[{
			op: "credits",
			n: 2
		}, {
			op: "recycleMarket",
			n: 1,
			flag: "entire"
		}]],
		expansion: !1
	},
	13715: {
		id: 13715,
		name: "games.unstoppable.cards.c13715",
		faction: "silver",
		kind: "ally",
		cost: 4,
		level: 3,
		play: [],
		exhaust: [[{
			op: "armor",
			n: 6
		}, {
			op: "health",
			n: 2,
			when: "conspire"
		}]],
		expansion: !1
	},
	13716: {
		id: 13716,
		name: "games.unstoppable.cards.c13716",
		faction: "council",
		kind: "tactic",
		cost: 1,
		level: 3,
		play: [{
			op: "eliminate",
			n: 1
		}, {
			op: "choice",
			options: [
				[{
					op: "credits",
					n: 4
				}],
				[{
					op: "damage",
					n: 3
				}],
				[{
					op: "actions",
					n: 3
				}]
			],
			when: "unite3"
		}],
		expansion: !0
	},
	13717: {
		id: 13717,
		name: "games.unstoppable.cards.c13717",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 3,
		play: [{
			op: "damage",
			n: 3
		}, {
			op: "health",
			n: 2,
			when: "conspire"
		}],
		expansion: !1
	},
	13718: {
		id: 13718,
		name: "games.unstoppable.cards.c13718",
		faction: "council",
		kind: "tactic",
		cost: 1,
		level: 3,
		play: [{
			op: "train",
			n: 1
		}, {
			op: "destroy",
			n: 1,
			flag: "activeWounded"
		}],
		expansion: !1
	},
	13719: {
		id: 13719,
		name: "games.unstoppable.cards.c13719",
		faction: "silver",
		kind: "ally",
		cost: 1,
		level: 3,
		play: [],
		exhaust: [[{
			op: "discardThreat",
			n: 1,
			flag: "wounded",
			noBoss: !0
		}]],
		expansion: !1
	},
	13720: {
		id: 13720,
		name: "games.unstoppable.cards.c13720",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 3,
		play: [{
			op: "damage",
			n: "armor",
			flag: "reduceCostOnKill"
		}],
		expansion: !1
	},
	13721: {
		id: 13721,
		name: "games.unstoppable.cards.c13721",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 3,
		play: [{
			op: "pay",
			n: 1,
			resource: "health",
			effects: [{
				op: "damage",
				n: 2
			}, {
				op: "damage",
				n: 1
			}]
		}, {
			op: "eliminate",
			n: 1,
			when: "conspire"
		}],
		expansion: !0
	},
	13722: {
		id: 13722,
		name: "games.unstoppable.cards.c13722",
		faction: "council",
		kind: "ally",
		cost: 2,
		level: 3,
		play: [],
		exhaust: [[{
			op: "credits",
			n: "unite"
		}, {
			op: "damage",
			n: "unite",
			when: "upgraded"
		}]],
		expansion: !0
	},
	13723: {
		id: 13723,
		name: "games.unstoppable.cards.c13723",
		faction: "junker",
		kind: "ally",
		cost: 2,
		level: 3,
		play: [],
		exhaust: [[{
			op: "credits",
			n: 2
		}, {
			op: "damage",
			n: 1,
			times: "upgrades"
		}]],
		expansion: !0
	},
	13800: {
		id: 13800,
		name: "games.unstoppable.cards.c13800",
		faction: "junker",
		kind: "ally",
		cost: 1,
		level: 4,
		play: [],
		exhaust: [[{
			op: "train",
			n: 1
		}, {
			op: "activateUpgrades",
			n: 1,
			flag: "tacticOnly"
		}]],
		passive: ["allyTacticUpgrades"],
		expansion: !1
	},
	13801: {
		id: 13801,
		name: "games.unstoppable.cards.c13801",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 4,
		play: [{
			op: "actions",
			n: 3
		}, {
			op: "credits",
			n: 2
		}],
		expansion: !1
	},
	13802: {
		id: 13802,
		name: "games.unstoppable.cards.c13802",
		faction: "junker",
		kind: "tactic",
		cost: 2,
		level: 4,
		play: [
			{
				op: "damage",
				n: 2
			},
			{
				op: "damage",
				n: 2
			},
			{
				op: "bargain",
				n: 4,
				effects: [{
					op: "activateUpgrades",
					n: 1,
					flag: "freePayments"
				}]
			}
		],
		expansion: !0
	},
	13803: {
		id: 13803,
		name: "games.unstoppable.cards.c13803",
		faction: "silver",
		kind: "ally",
		cost: 1,
		level: 4,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 1
		}, {
			op: "shuffleThreat",
			n: 1,
			flag: "bottomThenReveal",
			optional: !0
		}]],
		expansion: !0
	},
	13804: {
		id: 13804,
		name: "games.unstoppable.cards.c13804",
		faction: "council",
		kind: "tactic",
		cost: 1,
		level: 4,
		play: [
			{
				op: "damage",
				n: 1
			},
			{
				op: "damage",
				n: 1
			},
			{
				op: "damage",
				n: 1
			},
			{
				op: "damage",
				n: 1
			},
			{
				op: "eliminate",
				n: 1,
				when: "unite3"
			}
		],
		expansion: !1
	},
	13805: {
		id: 13805,
		name: "games.unstoppable.cards.c13805",
		faction: "council",
		kind: "tactic",
		cost: 0,
		level: 4,
		play: [{
			op: "train",
			n: 1
		}],
		passive: ["anyFaction"],
		expansion: !1
	},
	13806: {
		id: 13806,
		name: "games.unstoppable.cards.c13806",
		faction: "viren",
		kind: "tactic",
		cost: 0,
		level: 4,
		play: [{
			op: "damage",
			n: 2
		}, {
			op: "refresh",
			n: 1,
			when: "conspire"
		}],
		expansion: !1
	},
	13807: {
		id: 13807,
		name: "games.unstoppable.cards.c13807",
		faction: "silver",
		kind: "tactic",
		cost: 0,
		level: 4,
		play: [{
			op: "playTop",
			n: 1
		}, {
			op: "damage",
			n: "level",
			when: "conspire"
		}],
		expansion: !1
	},
	13808: {
		id: 13808,
		name: "games.unstoppable.cards.c13808",
		faction: "junker",
		kind: "ally",
		cost: 1,
		level: 4,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 3
		}, {
			op: "eliminate",
			n: 1,
			flag: "selfDraft",
			when: "upgraded"
		}]],
		expansion: !0
	},
	13809: {
		id: 13809,
		name: "games.unstoppable.cards.c13809",
		faction: "silver",
		kind: "tactic",
		cost: 0,
		level: 4,
		play: [{
			op: "exchange",
			n: 10,
			resource: "health",
			flag: "sibling"
		}],
		expansion: !0
	},
	13810: {
		id: 13810,
		name: "games.unstoppable.cards.c13810",
		faction: "council",
		kind: "ally",
		cost: 1,
		level: 4,
		play: [],
		exhaust: [[{
			op: "pay",
			n: 1,
			resource: "health",
			effects: [{
				op: "activateUpgrades",
				n: 3,
				flag: "level3Core"
			}]
		}]],
		expansion: !0
	},
	13811: {
		id: 13811,
		name: "games.unstoppable.cards.c13811",
		faction: "viren",
		kind: "tactic",
		cost: 2,
		level: 4,
		play: [{
			op: "damage",
			n: 3
		}, {
			op: "actions",
			n: "focus"
		}],
		expansion: !0
	},
	13812: {
		id: 13812,
		name: "games.unstoppable.cards.c13812",
		faction: "viren",
		kind: "ally",
		cost: 4,
		level: 4,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 4
		}, {
			op: "damage",
			n: 1
		}]],
		expansion: !0
	},
	13813: {
		id: 13813,
		name: "games.unstoppable.cards.c13813",
		faction: "council",
		kind: "tactic",
		cost: 6,
		level: 4,
		play: [{
			op: "destroy",
			n: "unite"
		}],
		expansion: !1
	},
	13814: {
		id: 13814,
		name: "games.unstoppable.cards.c13814",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 4,
		play: [{
			op: "destroy",
			n: 1,
			zone: "deck",
			flag: "extraActiveCost2",
			when: "health5"
		}],
		expansion: !1
	},
	13815: {
		id: 13815,
		name: "games.unstoppable.cards.c13815",
		faction: "silver",
		kind: "tactic",
		cost: 2,
		level: 4,
		play: [{
			op: "damage",
			n: 3
		}, {
			op: "damage",
			n: 2
		}],
		expansion: !1
	},
	13816: {
		id: 13816,
		name: "games.unstoppable.cards.c13816",
		faction: "viren",
		kind: "ally",
		cost: 1,
		level: 4,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 1
		}, {
			op: "actions",
			n: 1,
			when: "conspire"
		}]],
		expansion: !1
	},
	13817: {
		id: 13817,
		name: "games.unstoppable.cards.c13817",
		faction: "junker",
		kind: "tactic",
		cost: 0,
		level: 4,
		play: [{
			op: "trade",
			n: 1
		}, {
			op: "bargain",
			n: 3,
			effects: [{
				op: "trade",
				n: 1
			}, {
				op: "activateUpgrades",
				n: 1
			}]
		}],
		expansion: !1
	},
	13818: {
		id: 13818,
		name: "games.unstoppable.cards.c13818",
		faction: "viren",
		kind: "tactic",
		cost: 3,
		level: 4,
		play: [
			{
				op: "damage",
				n: 3
			},
			{
				op: "damage",
				n: 3
			},
			{
				op: "credits",
				n: "focus"
			},
			{
				op: "damage",
				n: "focus"
			}
		],
		expansion: !1
	},
	13819: {
		id: 13819,
		name: "games.unstoppable.cards.c13819",
		faction: "junker",
		kind: "ally",
		cost: 2,
		level: 4,
		play: [],
		exhaust: [[{
			op: "damage",
			n: "upgrades"
		}]],
		expansion: !1
	},
	13820: {
		id: 13820,
		name: "games.unstoppable.cards.c13820",
		faction: "council",
		kind: "tactic",
		cost: 4,
		level: 4,
		play: [{
			op: "actions",
			n: 1,
			when: "unite3"
		}, {
			op: "credits",
			n: 4
		}],
		passive: ["anyFaction", "uniteCostReduction"],
		expansion: !0
	},
	13821: {
		id: 13821,
		name: "games.unstoppable.cards.c13821",
		faction: "silver",
		kind: "ally",
		cost: 1,
		level: 4,
		play: [],
		exhaust: [[{
			op: "disableKeywords",
			n: 1
		}], [{
			op: "choice",
			options: [[{
				op: "damage",
				n: 2
			}], [{
				op: "armor",
				n: 3
			}]]
		}]],
		expansion: !1
	},
	13822: {
		id: 13822,
		name: "games.unstoppable.cards.c13822",
		faction: "council",
		kind: "ally",
		cost: 2,
		level: 4,
		play: [],
		exhaust: [[{
			op: "mark",
			n: 1,
			flag: "playedCost"
		}]],
		expansion: !1
	},
	13823: {
		id: 13823,
		name: "games.unstoppable.cards.c13823",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 4,
		play: [{
			op: "damage",
			n: 3
		}],
		passive: ["killCredits1"],
		expansion: !1
	},
	13900: {
		id: 13900,
		name: "games.unstoppable.cards.c13900",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 5,
		play: [{
			op: "armor",
			n: 4
		}, {
			op: "mark",
			n: 1,
			flag: "swapResources"
		}],
		expansion: !0
	},
	13901: {
		id: 13901,
		name: "games.unstoppable.cards.c13901",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 5,
		play: [{
			op: "credits",
			n: "unite",
			times: 3
		}],
		expansion: !0
	},
	13902: {
		id: 13902,
		name: "games.unstoppable.cards.c13902",
		faction: "junker",
		kind: "ally",
		cost: 1,
		level: 5,
		play: [],
		exhaust: [[{
			op: "credits",
			n: 4
		}, {
			op: "mark",
			n: 3,
			flag: "bargainDamage"
		}]],
		expansion: !1
	},
	13903: {
		id: 13903,
		name: "games.unstoppable.cards.c13903",
		faction: "silver",
		kind: "ally",
		cost: 3,
		level: 5,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 1
		}, {
			op: "pay",
			n: 1,
			resource: "health",
			effects: [{
				op: "refresh",
				n: 1,
				flag: "self"
			}]
		}]],
		enter: [{
			op: "health",
			n: 3
		}],
		leave: [{
			op: "health",
			n: 3
		}],
		expansion: !1
	},
	13906: {
		id: 13906,
		name: "games.unstoppable.cards.c13906",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 5,
		play: [{
			op: "discardThreat",
			n: 1
		}, {
			op: "discardThreat",
			n: 1,
			when: "conspire"
		}],
		expansion: !1
	},
	13907: {
		id: 13907,
		name: "games.unstoppable.cards.c13907",
		faction: "council",
		kind: "tactic",
		cost: 0,
		level: 5,
		play: [
			{
				op: "armor",
				n: 4
			},
			{
				op: "train",
				n: 1
			},
			{
				op: "eliminate",
				n: 1,
				when: "conspire"
			}
		],
		expansion: !0
	},
	13908: {
		id: 13908,
		name: "games.unstoppable.cards.c13908",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 5,
		play: [{
			op: "credits",
			n: 7
		}, {
			op: "bargain",
			n: 7,
			effects: [{
				op: "damage",
				n: 3
			}, {
				op: "damage",
				n: 3
			}]
		}],
		expansion: !1
	},
	13909: {
		id: 13909,
		name: "games.unstoppable.cards.c13909",
		faction: "viren",
		kind: "tactic",
		cost: 2,
		level: 5,
		play: [
			{
				op: "armor",
				n: 5
			},
			{
				op: "health",
				n: 4
			},
			{
				op: "bottom",
				n: 2,
				flag: "drawSame"
			}
		],
		expansion: !1
	},
	13910: {
		id: 13910,
		name: "games.unstoppable.cards.c13910",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 5,
		play: [{
			op: "actions",
			n: 2
		}, {
			op: "draw",
			n: 2,
			flag: "bottom"
		}],
		expansion: !1
	},
	13911: {
		id: 13911,
		name: "games.unstoppable.cards.c13911",
		faction: "silver",
		kind: "tactic",
		cost: 0,
		level: 5,
		play: [
			{
				op: "armor",
				n: 4
			},
			{
				op: "eliminate",
				n: 1
			},
			{
				op: "draft",
				n: 1,
				maxLevel: 4,
				flag: "top",
				when: "conspire"
			}
		],
		expansion: !0
	},
	13912: {
		id: 13912,
		name: "games.unstoppable.cards.c13912",
		faction: "council",
		kind: "tactic",
		cost: 2,
		level: 5,
		play: [
			{
				op: "damage",
				n: 2
			},
			{
				op: "damage",
				n: 2
			},
			{
				op: "damage",
				n: 2
			},
			{
				op: "damage",
				n: 2
			}
		],
		expansion: !1
	},
	13913: {
		id: 13913,
		name: "games.unstoppable.cards.c13913",
		faction: "silver",
		kind: "tactic",
		cost: -1,
		level: 5,
		play: [{
			op: "splitDamage",
			n: 10
		}],
		expansion: !1
	},
	13914: {
		id: 13914,
		name: "games.unstoppable.cards.c13914",
		faction: "council",
		kind: "ally",
		cost: 1,
		level: 5,
		play: [],
		exhaust: [[{
			op: "eliminate",
			n: 1
		}]],
		passive: ["chooseFaction"],
		expansion: !1
	},
	13915: {
		id: 13915,
		name: "games.unstoppable.cards.c13915",
		faction: "council",
		kind: "tactic",
		cost: 0,
		level: 5,
		play: [{
			op: "bottom",
			n: "unite",
			flag: "drawThenBottom"
		}],
		expansion: !1
	},
	13916: {
		id: 13916,
		name: "games.unstoppable.cards.c13916",
		faction: "viren",
		kind: "ally",
		cost: 2,
		level: 5,
		play: [],
		exhaust: [[{
			op: "actions",
			n: 2
		}], [{
			op: "actions",
			n: 1
		}, {
			op: "credits",
			n: 2
		}]],
		expansion: !1
	},
	13917: {
		id: 13917,
		name: "games.unstoppable.cards.c13917",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 5,
		play: [
			{
				op: "actions",
				n: 1
			},
			{
				op: "damage",
				n: 4
			},
			{
				op: "bargain",
				n: 3,
				effects: [{
					op: "discount",
					n: 3,
					flag: "upgrade"
				}]
			}
		],
		expansion: !1
	},
	14100: {
		id: 14100,
		name: "games.unstoppable.cards.c14100",
		faction: "viren",
		kind: "tactic",
		cost: 4,
		level: 6,
		play: [{
			op: "allDamage",
			n: "focus",
			times: 2,
			flag: "includeDeck",
			ignoreTaunt: !0
		}],
		expansion: !0
	},
	14101: {
		id: 14101,
		name: "games.unstoppable.cards.c14101",
		faction: "silver",
		kind: "tactic",
		cost: -1,
		level: 6,
		play: [{
			op: "exchange",
			n: 10,
			resource: "health",
			flag: "progress"
		}],
		expansion: !0
	},
	14102: {
		id: 14102,
		name: "games.unstoppable.cards.c14102",
		faction: "silver",
		kind: "tactic",
		cost: 3,
		level: 6,
		play: [{
			op: "armor",
			n: 5
		}],
		passive: ["redirectKills"],
		expansion: !1
	},
	14103: {
		id: 14103,
		name: "games.unstoppable.cards.c14103",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 6,
		play: [{
			op: "damage",
			n: 3
		}, {
			op: "retrieve",
			n: 1,
			zone: "play",
			flag: "other",
			when: "conspire"
		}],
		expansion: !1
	},
	14104: {
		id: 14104,
		name: "games.unstoppable.cards.c14104",
		faction: "viren",
		kind: "ally",
		cost: 0,
		level: 6,
		play: [],
		exhaust: [[{
			op: "credits",
			n: "focus"
		}]],
		expansion: !1
	},
	14106: {
		id: 14106,
		name: "games.unstoppable.cards.c14106",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 6,
		play: [{
			op: "credits",
			n: "actions"
		}, {
			op: "damage",
			n: 2,
			times: "actions"
		}],
		passive: ["actionDamage2"],
		expansion: !1
	},
	14107: {
		id: 14107,
		name: "games.unstoppable.cards.c14107",
		faction: "junker",
		kind: "tactic",
		cost: 0,
		level: 6,
		play: [
			{
				op: "actions",
				n: 1
			},
			{
				op: "damage",
				n: 4
			},
			{
				op: "bargain",
				n: 4,
				effects: [{
					op: "damage",
					n: 4
				}]
			}
		],
		expansion: !1
	},
	14108: {
		id: 14108,
		name: "games.unstoppable.cards.c14108",
		faction: "council",
		kind: "ally",
		cost: 1,
		level: 6,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 2,
			times: "unite"
		}]],
		expansion: !1
	},
	14109: {
		id: 14109,
		name: "games.unstoppable.cards.c14109",
		faction: "council",
		kind: "tactic",
		cost: 0,
		level: 6,
		play: [{
			op: "health",
			n: 2
		}, {
			op: "destroy",
			n: 1
		}],
		expansion: !1
	},
	14110: {
		id: 14110,
		name: "games.unstoppable.cards.c14110",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 6,
		play: [],
		passive: ["doubleExhaust"],
		expansion: !1
	},
	14111: {
		id: 14111,
		name: "games.unstoppable.cards.c14111",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 6,
		play: [{
			op: "credits",
			n: 4
		}, {
			op: "destroy",
			n: "sourceUpgrades"
		}],
		expansion: !0
	},
	14112: {
		id: 14112,
		name: "games.unstoppable.cards.c14112",
		faction: "junker",
		kind: "ally",
		cost: 2,
		level: 6,
		play: [],
		exhaust: [[{
			op: "mark",
			n: 1,
			flag: "tacticUpgradeDamage"
		}]],
		enter: [{
			op: "credits",
			n: 4
		}],
		leave: [{
			op: "credits",
			n: 4
		}],
		expansion: !1
	},
	14113: {
		id: 14113,
		name: "games.unstoppable.cards.c14113",
		faction: "silver",
		kind: "ally",
		cost: 2,
		level: 6,
		play: [],
		exhaust: [[{
			op: "refresh",
			n: 1,
			all: !0,
			flag: "other"
		}]],
		passive: ["trainDamage2"],
		expansion: !0
	},
	14114: {
		id: 14114,
		name: "games.unstoppable.cards.c14114",
		faction: "council",
		kind: "tactic",
		cost: 3,
		level: 6,
		play: [
			{
				op: "damage",
				n: 3
			},
			{
				op: "damage",
				n: 3
			},
			{
				op: "damage",
				n: 3
			},
			{
				op: "damage",
				n: 3
			}
		],
		expansion: !1
	},
	14115: {
		id: 14115,
		name: "games.unstoppable.cards.c14115",
		faction: "silver",
		kind: "tactic",
		cost: -1,
		level: 6,
		play: [{
			op: "splitDamage",
			n: 13
		}],
		expansion: !1
	},
	14116: {
		id: 14116,
		name: "games.unstoppable.cards.c14116",
		faction: "council",
		kind: "tactic",
		cost: 3,
		level: 6,
		play: [
			{
				op: "credits",
				n: 6,
				flag: "hasJunker"
			},
			{
				op: "damage",
				n: 2,
				times: 3,
				flag: "hasSilver"
			},
			{
				op: "armor",
				n: 6,
				flag: "hasViren"
			}
		],
		expansion: !0
	},
	14117: {
		id: 14117,
		name: "games.unstoppable.cards.c14117",
		faction: "silver",
		kind: "ally",
		cost: 2,
		level: 6,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 5
		}]],
		expansion: !1
	},
	14200: {
		id: 14200,
		name: "games.unstoppable.cards.c14200",
		faction: "silver",
		kind: "ally",
		cost: 1,
		level: 0,
		play: [],
		exhaust: [[{
			op: "pay",
			n: 1,
			resource: "health",
			effects: [{
				op: "damage",
				n: "missingHealth"
			}]
		}, {
			op: "health",
			n: 2,
			level: 3
		}]],
		character: "kai"
	},
	14201: {
		id: 14201,
		name: "games.unstoppable.cards.c14201",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 0,
		play: [
			{
				op: "train",
				n: 1
			},
			{
				op: "train",
				n: 1,
				when: "conspire"
			},
			{
				op: "pay",
				n: 1,
				resource: "health",
				effects: [{
					op: "damage",
					n: 3
				}],
				level: 2
			},
			{
				op: "exchange",
				n: 10,
				resource: "health",
				flag: "armor",
				level: 4
			}
		],
		character: "kai"
	},
	14202: {
		id: 14202,
		name: "games.unstoppable.cards.c14202",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 0,
		play: [{
			op: "credits",
			n: 2
		}, {
			op: "credits",
			n: 1,
			when: "health7"
		}],
		character: "kai"
	},
	14203: {
		id: 14203,
		name: "games.unstoppable.cards.c14203",
		faction: "silver",
		kind: "ally",
		cost: 2,
		level: 0,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 2
		}, {
			op: "damage",
			n: 2,
			when: "conspire",
			level: 3
		}]],
		character: "roux",
		expansion: !0
	},
	14204: {
		id: 14204,
		name: "games.unstoppable.cards.c14204",
		faction: "silver",
		kind: "tactic",
		cost: 1,
		level: 0,
		play: [
			{
				op: "credits",
				n: 1
			},
			{
				op: "armor",
				n: 2,
				when: "conspire"
			},
			{
				op: "refresh",
				n: 1,
				when: "conspire",
				level: 2
			}
		],
		character: "roux",
		expansion: !0
	},
	14205: {
		id: 14205,
		name: "games.unstoppable.cards.c14205",
		faction: "council",
		kind: "ally",
		cost: 0,
		level: 0,
		play: [],
		exhaust: [[{
			op: "train",
			n: 1
		}, {
			op: "credits",
			n: 2,
			when: "unite3"
		}]],
		character: "roux",
		expansion: !0
	},
	14300: {
		id: 14300,
		name: "games.unstoppable.cards.c14300",
		faction: "viren",
		kind: "ally",
		cost: 1,
		level: 0,
		play: [],
		exhaust: [[{
			op: "actions",
			n: 1
		}, {
			op: "damage",
			n: 2,
			level: 3
		}]],
		character: "sima",
		expansion: !0
	},
	14301: {
		id: 14301,
		name: "games.unstoppable.cards.c14301",
		faction: "viren",
		kind: "tactic",
		cost: 0,
		level: 0,
		play: [{
			op: "armor",
			n: "focus",
			all: !0
		}],
		passive: ["blockedCredits"],
		character: "sima",
		expansion: !0
	},
	14302: {
		id: 14302,
		name: "games.unstoppable.cards.c14302",
		faction: "junker",
		kind: "tactic",
		cost: 1,
		level: 0,
		play: [{
			op: "damage",
			n: "focus"
		}, {
			op: "damage",
			n: "focus",
			level: 4
		}],
		character: "sima",
		expansion: !0
	},
	14303: {
		id: 14303,
		name: "games.unstoppable.cards.c14303",
		faction: "junker",
		kind: "ally",
		cost: 1,
		level: 0,
		play: [],
		exhaust: [[
			{
				op: "bargain",
				n: 3,
				effects: [{
					op: "damage",
					n: 1
				}]
			},
			{
				op: "credits",
				n: 1,
				level: 2
			},
			{
				op: "bargain",
				n: 4,
				effects: [{
					op: "damage",
					n: 1
				}, {
					op: "damage",
					n: 1
				}],
				level: 4
			}
		]],
		character: "zephyr"
	},
	14304: {
		id: 14304,
		name: "games.unstoppable.cards.c14304",
		faction: "junker",
		kind: "tactic",
		cost: 0,
		level: 0,
		play: [{
			op: "choice",
			options: [[{
				op: "discount",
				n: 2,
				flag: "bargain"
			}], [{
				op: "mark",
				n: 2,
				flag: "endCredits"
			}]]
		}],
		character: "zephyr"
	},
	14305: {
		id: 14305,
		name: "games.unstoppable.cards.c14305",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 0,
		play: [{
			op: "damage",
			n: "upgrades"
		}],
		character: "zephyr"
	},
	14400: {
		id: 14400,
		name: "games.unstoppable.cards.c14400",
		faction: "council",
		kind: "ally",
		cost: 1,
		level: 0,
		play: [],
		exhaust: [[{
			op: "damage",
			n: 1
		}, {
			op: "armor",
			n: "unite",
			level: 3
		}]],
		character: "tiberius"
	},
	14401: {
		id: 14401,
		name: "games.unstoppable.cards.c14401",
		faction: "council",
		kind: "tactic",
		cost: 2,
		level: 0,
		play: [{
			op: "allDamage",
			n: 1,
			ignoreTaunt: !0
		}, {
			op: "allDamage",
			n: 1,
			ignoreTaunt: !0,
			level: 4
		}],
		character: "tiberius"
	},
	14402: {
		id: 14402,
		name: "games.unstoppable.cards.c14402",
		faction: "silver",
		kind: "tactic",
		cost: 0,
		level: 0,
		play: [{
			op: "credits",
			n: 1,
			when: "active3"
		}, {
			op: "credits",
			n: "wounded",
			level: 2
		}],
		character: "tiberius"
	},
	14403: {
		id: 14403,
		name: "games.unstoppable.cards.c14403",
		faction: "viren",
		kind: "ally",
		cost: 1,
		level: 0,
		play: [],
		exhaust: [[{
			op: "damage",
			n: "focus"
		}]],
		character: "julida"
	},
	14404: {
		id: 14404,
		name: "games.unstoppable.cards.c14404",
		faction: "viren",
		kind: "tactic",
		cost: 1,
		level: 0,
		play: [
			{
				op: "train",
				n: 1
			},
			{
				op: "armor",
				n: "focus"
			},
			{
				op: "exchange",
				n: 10,
				resource: "armor",
				flag: "damage",
				level: 3
			}
		],
		character: "julida"
	},
	14405: {
		id: 14405,
		name: "games.unstoppable.cards.c14405",
		faction: "council",
		kind: "tactic",
		cost: 0,
		level: 0,
		play: [{
			op: "credits",
			n: "unite"
		}],
		character: "julida"
	},
	1700: {
		id: 1700,
		name: "games.unstoppable.cards.c1700",
		kind: "boss",
		cost: 0,
		level: 0,
		play: [],
		enter: [{
			op: "bossDamage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			flag: "bossDiscard"
		}],
		passive: ["bossProtected"]
	},
	1701: {
		id: 1701,
		name: "games.unstoppable.cards.c1701",
		kind: "boss",
		cost: 0,
		level: 0,
		play: [],
		enter: [{
			op: "bossDamage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			flag: "bossDiscard"
		}],
		passive: ["bossProtected"]
	},
	1702: {
		id: 1702,
		name: "games.unstoppable.cards.c1702",
		kind: "boss",
		cost: 0,
		level: 0,
		play: [],
		enter: [{
			op: "bossDamage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			flag: "bossDiscard"
		}],
		passive: ["bossProtected"]
	},
	1703: {
		id: 1703,
		name: "games.unstoppable.cards.c1703",
		kind: "boss",
		cost: 0,
		level: 0,
		play: [],
		enter: [{
			op: "bossDamage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			flag: "bossDiscard"
		}],
		passive: ["bossProtected"]
	},
	1100: {
		id: 1100,
		name: "games.unstoppable.cards.c1100",
		kind: "boss",
		cost: 0,
		level: 0,
		play: [],
		enter: [{
			op: "bossDamage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			flag: "bossDiscard"
		}],
		passive: ["bossProtected"]
	},
	1101: {
		id: 1101,
		name: "games.unstoppable.cards.c1101",
		kind: "boss",
		cost: 0,
		level: 0,
		play: [],
		enter: [{
			op: "bossDamage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			flag: "bossDiscard"
		}],
		passive: ["bossProtected"]
	},
	1102: {
		id: 1102,
		name: "games.unstoppable.cards.c1102",
		kind: "boss",
		cost: 0,
		level: 0,
		play: [],
		enter: [{
			op: "bossDamage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			flag: "bossDiscard"
		}],
		passive: ["bossProtected"]
	},
	1103: {
		id: 1103,
		name: "games.unstoppable.cards.c1103",
		kind: "boss",
		cost: 0,
		level: 0,
		play: [],
		enter: [{
			op: "bossDamage",
			n: 1
		}, {
			op: "mark",
			n: 1,
			flag: "bossDiscard"
		}],
		passive: ["bossProtected"]
	}
}, T = {
	12100: {
		id: 12100,
		name: "games.unstoppable.cards.u12100",
		cost: 4,
		slot: "bottom",
		kind: "either",
		play: [],
		exhaust: [],
		attack: 0,
		defense: 1,
		keywords: [],
		reward: [],
		costReduction: 2,
		faction: "viren"
	},
	12101: {
		id: 12101,
		name: "games.unstoppable.cards.u12101",
		cost: 4,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "damage",
			n: "unite"
		}],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: [],
		reward: [],
		faction: "council",
		expansion: !0
	},
	12102: {
		id: 12102,
		name: "games.unstoppable.cards.u12102",
		cost: 6,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "actions",
			n: 1
		}, {
			op: "damage",
			n: 4
		}],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: [],
		reward: [{
			op: "credits",
			n: 2
		}],
		faction: "junker"
	},
	12103: {
		id: 12103,
		name: "games.unstoppable.cards.u12103",
		cost: 5,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "damage",
			n: 4
		}, {
			op: "train",
			n: 1
		}],
		exhaust: [],
		attack: 2,
		defense: 0,
		keywords: [],
		reward: []
	},
	12104: {
		id: 12104,
		name: "games.unstoppable.cards.u12104",
		cost: 5,
		slot: "bottom",
		kind: "either",
		play: [],
		exhaust: [],
		attack: 0,
		defense: 2,
		keywords: ["rage"],
		reward: [],
		costReduction: 3
	},
	12105: {
		id: 12105,
		name: "games.unstoppable.cards.u12105",
		cost: 4,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "damage",
			n: "focus"
		}],
		exhaust: [],
		attack: 2,
		defense: 0,
		keywords: [],
		reward: [],
		faction: "viren",
		expansion: !0
	},
	12106: {
		id: 12106,
		name: "games.unstoppable.cards.u12106",
		cost: 6,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "repeat",
			n: 1,
			flag: "core"
		}],
		exhaust: [],
		attack: 0,
		defense: 2,
		keywords: [],
		reward: [{
			op: "actions",
			n: 1
		}]
	},
	12107: {
		id: 12107,
		name: "games.unstoppable.cards.u12107",
		cost: 2,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "draft",
			n: 1,
			maxLevel: 2,
			flag: "top"
		}],
		exhaust: [],
		attack: 0,
		defense: 0,
		keywords: ["taunt"],
		reward: [{
			op: "damage",
			n: 2
		}],
		faction: "council"
	},
	12108: {
		id: 12108,
		name: "games.unstoppable.cards.u12108",
		cost: 3,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "health",
			n: 2,
			when: "health5"
		}, {
			op: "train",
			n: 1,
			when: "health5"
		}],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: ["rage"],
		reward: [{
			op: "damage",
			n: 2
		}],
		faction: "silver"
	},
	12200: {
		id: 12200,
		name: "games.unstoppable.cards.u12200",
		cost: 3,
		slot: "bottom",
		kind: "ally",
		play: [],
		exhaust: [{
			op: "damage",
			n: 1
		}],
		attack: 1,
		defense: 0,
		keywords: [],
		reward: []
	},
	12201: {
		id: 12201,
		name: "games.unstoppable.cards.u12201",
		cost: 1,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "damage",
			n: 2
		}],
		exhaust: [],
		attack: 2,
		defense: 0,
		keywords: [],
		reward: []
	},
	12202: {
		id: 12202,
		name: "games.unstoppable.cards.u12202",
		cost: 2,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "damage",
			n: 2
		}],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: [],
		reward: [{
			op: "train",
			n: 1
		}]
	},
	12203: {
		id: 12203,
		name: "games.unstoppable.cards.u12203",
		cost: 4,
		slot: "bottom",
		kind: "either",
		play: [],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: [],
		reward: [],
		costReduction: 2
	},
	12204: {
		id: 12204,
		name: "games.unstoppable.cards.u12204",
		cost: 2,
		slot: "bottom",
		kind: "ally",
		play: [],
		exhaust: [{
			op: "damage",
			n: 1,
			when: "conspire"
		}],
		attack: 0,
		defense: 1,
		keywords: [],
		reward: [],
		expansion: !0
	},
	12205: {
		id: 12205,
		name: "games.unstoppable.cards.u12205",
		cost: 4,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "damage",
			n: 2
		}, {
			op: "train",
			n: 1
		}],
		exhaust: [],
		attack: 0,
		defense: 1,
		keywords: [],
		reward: [],
		faction: "silver"
	},
	12206: {
		id: 12206,
		name: "games.unstoppable.cards.u12206",
		cost: 2,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "refresh",
			n: "focus"
		}],
		exhaust: [],
		attack: 0,
		defense: 1,
		keywords: [],
		reward: [],
		faction: "viren"
	},
	12207: {
		id: 12207,
		name: "games.unstoppable.cards.u12207",
		cost: 3,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "actions",
			n: 2
		}],
		exhaust: [],
		attack: 0,
		defense: 2,
		keywords: [],
		reward: []
	},
	12208: {
		id: 12208,
		name: "games.unstoppable.cards.u12208",
		cost: 5,
		slot: "top",
		kind: "tactic",
		play: [
			{
				op: "damage",
				n: 1
			},
			{
				op: "damage",
				n: 1
			},
			{
				op: "damage",
				n: 1
			}
		],
		exhaust: [],
		attack: 0,
		defense: 1,
		keywords: [],
		reward: [{
			op: "train",
			n: 1
		}],
		faction: "council"
	},
	14900: {
		id: 14900,
		name: "games.unstoppable.cards.u14900",
		cost: 5,
		slot: "top",
		kind: "ally",
		play: [],
		exhaust: [{
			op: "actions",
			n: 1
		}, {
			op: "armor",
			n: 2
		}],
		attack: 0,
		defense: 0,
		keywords: ["taunt"],
		reward: [],
		faction: "viren"
	},
	14901: {
		id: 14901,
		name: "games.unstoppable.cards.u14901",
		cost: 3,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "credits",
			n: 2
		}, {
			op: "health",
			n: 1
		}],
		exhaust: [],
		attack: 0,
		defense: 1,
		keywords: [],
		reward: [],
		faction: "council"
	},
	14902: {
		id: 14902,
		name: "games.unstoppable.cards.u14902",
		cost: 5,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "credits",
			n: 2
		}, {
			op: "bargain",
			n: 5,
			effects: [{
				op: "damage",
				n: 5
			}]
		}],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: [],
		reward: [],
		faction: "junker",
		expansion: !0
	},
	14903: {
		id: 14903,
		name: "games.unstoppable.cards.u14903",
		cost: 3,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "actions",
			n: 1
		}, {
			op: "armor",
			n: "focus"
		}],
		exhaust: [],
		attack: 0,
		defense: 0,
		keywords: ["taunt"],
		reward: [{
			op: "actions",
			n: 1
		}],
		faction: "viren"
	},
	14904: {
		id: 14904,
		name: "games.unstoppable.cards.u14904",
		cost: 2,
		slot: "top",
		kind: "ally",
		play: [],
		exhaust: [{
			op: "health",
			n: 1
		}],
		attack: 0,
		defense: 1,
		keywords: [],
		reward: [],
		expansion: !0
	},
	14905: {
		id: 14905,
		name: "games.unstoppable.cards.u14905",
		cost: 2,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "armor",
			n: 5
		}],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: [],
		reward: []
	},
	14906: {
		id: 14906,
		name: "games.unstoppable.cards.u14906",
		cost: 3,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "credits",
			n: 2
		}],
		exhaust: [],
		attack: 0,
		defense: 1,
		keywords: [],
		reward: []
	},
	14907: {
		id: 14907,
		name: "games.unstoppable.cards.u14907",
		cost: 3,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "credits",
			n: 1
		}, {
			op: "bargain",
			n: 2,
			effects: [{
				op: "train",
				n: 1
			}]
		}],
		exhaust: [],
		attack: 0,
		defense: 0,
		keywords: ["rage"],
		reward: [],
		faction: "junker"
	},
	14908: {
		id: 14908,
		name: "games.unstoppable.cards.u14908",
		cost: 2,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "actions",
			n: 1
		}],
		exhaust: [],
		attack: 0,
		defense: 0,
		keywords: ["fast"],
		reward: []
	},
	15e3: {
		id: 15e3,
		name: "games.unstoppable.cards.u15000",
		cost: 1,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "armor",
			n: 1
		}, {
			op: "train",
			n: 1
		}],
		exhaust: [],
		attack: 0,
		defense: 0,
		keywords: ["taunt"],
		reward: []
	},
	15001: {
		id: 15001,
		name: "games.unstoppable.cards.u15001",
		cost: 6,
		slot: "top",
		kind: "tactic",
		play: [{
			op: "damage",
			n: 5,
			when: "conspire"
		}],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: ["rage"],
		reward: [],
		faction: "silver"
	},
	15002: {
		id: 15002,
		name: "games.unstoppable.cards.u15002",
		cost: 1,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "damage",
			n: 1
		}, {
			op: "train",
			n: 1
		}],
		exhaust: [],
		attack: 0,
		defense: 0,
		keywords: ["fast"],
		reward: []
	},
	15004: {
		id: 15004,
		name: "games.unstoppable.cards.u15004",
		cost: 7,
		slot: "top",
		kind: "tactic",
		play: [
			{
				op: "credits",
				n: 2
			},
			{
				op: "damage",
				n: 2
			},
			{
				op: "damage",
				n: 2
			}
		],
		exhaust: [],
		attack: 0,
		defense: 0,
		keywords: ["rage"],
		reward: [{
			op: "credits",
			n: 2
		}],
		faction: "junker"
	},
	15005: {
		id: 15005,
		name: "games.unstoppable.cards.u15005",
		cost: 4,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "damage",
			n: 3
		}],
		exhaust: [],
		attack: 1,
		defense: 0,
		keywords: [],
		reward: []
	},
	15006: {
		id: 15006,
		name: "games.unstoppable.cards.u15006",
		cost: 1,
		slot: "bottom",
		kind: "either",
		play: [],
		exhaust: [],
		attack: 0,
		defense: 0,
		keywords: [],
		reward: [{
			op: "credits",
			n: 1
		}, {
			op: "train",
			n: 1
		}],
		expansion: !0
	},
	15007: {
		id: 15007,
		name: "games.unstoppable.cards.u15007",
		cost: 4,
		slot: "bottom",
		kind: "tactic",
		play: [{
			op: "damage",
			n: "focus"
		}],
		exhaust: [],
		attack: 2,
		defense: 0,
		keywords: [],
		reward: [],
		faction: "silver",
		expansion: !0
	}
}, E = {
	1800: {
		id: 1800,
		name: "games.unstoppable.cards.t1800",
		attack: 2,
		defense: "danger",
		keywords: ["rage"],
		reward: [{
			op: "credits",
			n: 2
		}],
		boss: !1
	},
	1801: {
		id: 1801,
		name: "games.unstoppable.cards.t1801",
		attack: 2,
		defense: "danger",
		keywords: ["rage"],
		reward: [{
			op: "credits",
			n: 2
		}],
		boss: !1
	},
	1802: {
		id: 1802,
		name: "games.unstoppable.cards.t1802",
		attack: 2,
		defense: "danger",
		keywords: ["rage"],
		reward: [{
			op: "credits",
			n: 2
		}],
		boss: !1
	},
	1803: {
		id: 1803,
		name: "games.unstoppable.cards.t1803",
		attack: "danger",
		defense: 3,
		keywords: ["crazed5"],
		reward: [{
			op: "credits",
			n: 1
		}],
		boss: !1
	},
	1804: {
		id: 1804,
		name: "games.unstoppable.cards.t1804",
		attack: "danger",
		defense: 3,
		keywords: ["crazed5"],
		reward: [{
			op: "credits",
			n: 1
		}],
		boss: !1
	},
	1805: {
		id: 1805,
		name: "games.unstoppable.cards.t1805",
		attack: "danger",
		defense: 3,
		keywords: ["crazed5"],
		reward: [{
			op: "credits",
			n: 1
		}],
		boss: !1
	},
	1806: {
		id: 1806,
		name: "games.unstoppable.cards.t1806",
		attack: 2,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "eliminate",
			n: 1
		}],
		boss: !1
	},
	1807: {
		id: 1807,
		name: "games.unstoppable.cards.t1807",
		attack: 2,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "train",
			n: 1
		}],
		boss: !1
	},
	1808: {
		id: 1808,
		name: "games.unstoppable.cards.t1808",
		attack: 2,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "train",
			n: 1
		}],
		boss: !1
	},
	1809: {
		id: 1809,
		name: "games.unstoppable.cards.t1809",
		attack: 3,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "eliminate",
			n: 1
		}],
		boss: !1
	},
	1810: {
		id: 1810,
		name: "games.unstoppable.cards.t1810",
		attack: 3,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "eliminate",
			n: 1
		}],
		boss: !1
	},
	1811: {
		id: 1811,
		name: "games.unstoppable.cards.t1811",
		attack: 3,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "eliminate",
			n: 1
		}],
		boss: !1
	},
	1900: {
		id: 1900,
		name: "games.unstoppable.cards.t1900",
		attack: 1,
		defense: "danger",
		keywords: ["fast"],
		reward: [{
			op: "actions",
			n: 1
		}],
		boss: !1
	},
	1901: {
		id: 1901,
		name: "games.unstoppable.cards.t1901",
		attack: 2,
		defense: 1,
		keywords: ["terror"],
		reward: [],
		boss: !1
	},
	1902: {
		id: 1902,
		name: "games.unstoppable.cards.t1902",
		attack: 3,
		defense: "danger",
		keywords: ["crazed5"],
		reward: [{
			op: "credits",
			n: 3
		}],
		boss: !1,
		defenseBonus: 1
	},
	1903: {
		id: 1903,
		name: "games.unstoppable.cards.t1903",
		attack: 2,
		defense: "danger",
		keywords: ["terror"],
		reward: [{
			op: "actions",
			n: 1
		}],
		boss: !1
	},
	1905: {
		id: 1905,
		name: "games.unstoppable.cards.t1905",
		attack: 3,
		defense: 0,
		keywords: ["fast"],
		reward: [{
			op: "actions",
			n: 1
		}],
		boss: !1
	},
	2e3: {
		id: 2e3,
		name: "games.unstoppable.cards.t2000",
		attack: 1,
		defense: "danger",
		keywords: ["taunt"],
		reward: [],
		boss: !1
	},
	2001: {
		id: 2001,
		name: "games.unstoppable.cards.t2001",
		attack: 2,
		defense: 1,
		keywords: [],
		reward: [{
			op: "damage",
			n: 2
		}],
		boss: !1
	},
	2002: {
		id: 2002,
		name: "games.unstoppable.cards.t2002",
		attack: "danger",
		defense: "danger",
		keywords: ["fast"],
		reward: [],
		boss: !1
	},
	2003: {
		id: 2003,
		name: "games.unstoppable.cards.t2003",
		attack: 2,
		defense: "danger",
		keywords: ["crazed5"],
		reward: [{
			op: "credits",
			n: 2
		}],
		boss: !1,
		defenseBonus: 2
	},
	2005: {
		id: 2005,
		name: "games.unstoppable.cards.t2005",
		attack: "danger",
		defense: "danger",
		keywords: ["taunt"],
		reward: [],
		boss: !1
	},
	9e4: {
		id: 9e4,
		name: "games.unstoppable.cards.t90000",
		attack: 2,
		defense: "danger",
		keywords: ["taunt"],
		reward: [],
		boss: !1
	},
	90001: {
		id: 90001,
		name: "games.unstoppable.cards.t90001",
		attack: 1,
		defense: "danger",
		keywords: [],
		reward: [],
		boss: !1
	},
	90002: {
		id: 90002,
		name: "games.unstoppable.cards.t90002",
		attack: 2,
		defense: 0,
		keywords: ["rage"],
		reward: [{
			op: "credits",
			n: 1
		}],
		boss: !1
	},
	90003: {
		id: 90003,
		name: "games.unstoppable.cards.t90003",
		attack: 1,
		defense: "danger",
		keywords: ["fast"],
		reward: [{
			op: "credits",
			n: 1
		}],
		boss: !1
	},
	90004: {
		id: 90004,
		name: "games.unstoppable.cards.t90004",
		attack: 1,
		defense: "danger",
		keywords: ["taunt"],
		reward: [{
			op: "credits",
			n: 1
		}],
		boss: !1,
		defenseBonus: 1
	},
	1700: {
		id: 1700,
		name: "games.unstoppable.cards.t1700",
		attack: 2,
		defense: "danger",
		keywords: ["rage"],
		reward: [{
			op: "damage",
			n: 3
		}],
		boss: !0
	},
	1701: {
		id: 1701,
		name: "games.unstoppable.cards.t1701",
		attack: 2,
		defense: "danger",
		keywords: ["rage"],
		reward: [{
			op: "damage",
			n: 3
		}],
		boss: !0
	},
	1702: {
		id: 1702,
		name: "games.unstoppable.cards.t1702",
		attack: 3,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "damage",
			n: 4
		}],
		boss: !0
	},
	1703: {
		id: 1703,
		name: "games.unstoppable.cards.t1703",
		attack: 3,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "damage",
			n: 4
		}],
		boss: !0
	},
	1100: {
		id: 1100,
		name: "games.unstoppable.cards.t1100",
		attack: 1,
		defense: "danger",
		keywords: ["fast"],
		reward: [{
			op: "damage",
			n: 1
		}],
		boss: !0
	},
	1103: {
		id: 1103,
		name: "games.unstoppable.cards.t1103",
		attack: 1,
		defense: "danger",
		keywords: ["fast"],
		reward: [{
			op: "damage",
			n: 1
		}],
		boss: !0
	},
	1101: {
		id: 1101,
		name: "games.unstoppable.cards.t1101",
		attack: 2,
		defense: "danger",
		keywords: ["rage"],
		reward: [{
			op: "damage",
			n: 3
		}],
		boss: !0
	},
	1102: {
		id: 1102,
		name: "games.unstoppable.cards.t1102",
		attack: 1,
		defense: "danger",
		keywords: [],
		reward: [{
			op: "damage",
			n: 4
		}],
		boss: !0
	}
}, ie = [
	[
		13604,
		13602,
		13616,
		13619,
		13606,
		13612,
		13618,
		13410,
		13611,
		13608,
		13621,
		13607,
		13605,
		13600,
		13613,
		13614,
		13609,
		13622,
		13623,
		13601,
		13617,
		13620,
		13615,
		13610,
		13603
	],
	[
		13422,
		13429,
		13430,
		13420,
		13424,
		13413,
		13414,
		13401,
		13423,
		13405,
		13415,
		13421,
		13400,
		13403,
		13406,
		13402,
		13407,
		13404,
		13425,
		13419,
		13411,
		13416,
		13427,
		13428,
		13426,
		13408,
		13409,
		13412,
		13418
	],
	[
		13713,
		13703,
		13722,
		13704,
		13705,
		13717,
		13723,
		13721,
		13702,
		13417,
		13714,
		13710,
		13711,
		13709,
		13708,
		13707,
		13715,
		13701,
		13712,
		13719,
		13718,
		13706,
		13720,
		13700,
		13716
	],
	[
		13801,
		13812,
		13813,
		13811,
		13804,
		13810,
		13819,
		13808,
		13817,
		13822,
		13821,
		13815,
		13816,
		13823,
		13818,
		13807,
		13803,
		13809,
		13820,
		13805,
		13802,
		13800,
		13806,
		13814
	],
	[
		13916,
		13903,
		13913,
		13910,
		13909,
		13908,
		13914,
		13902,
		13911,
		13906,
		13917,
		13915,
		13912,
		13900,
		13907,
		13901
	],
	[
		14108,
		14107,
		14116,
		14106,
		14100,
		14115,
		14102,
		14111,
		14104,
		14114,
		14110,
		14103,
		14112,
		14117,
		14101,
		14109,
		14113
	]
], ae = [
	12106,
	14904,
	14907,
	12202,
	14900,
	12200,
	12100,
	15e3,
	15001,
	14905,
	12102,
	12207,
	12107,
	14901,
	12201,
	14904,
	15005,
	14905,
	12202,
	15002,
	12205,
	12103,
	15006,
	12200,
	12101,
	12108,
	12104,
	14906,
	15007,
	12203,
	12204,
	14902,
	12104,
	12204,
	15004,
	15005,
	12207,
	12206,
	12105,
	12203,
	12201,
	14906,
	14908,
	15006,
	12208,
	14903
], D = {
	ceres: [
		1802,
		1809,
		1808,
		1806,
		1805,
		1810,
		1807,
		1803,
		1811,
		1801,
		1800,
		1804,
		1804
	],
	mithras: [
		2003,
		2003,
		2003,
		2002,
		2005,
		2e3,
		2e3,
		2002,
		2002,
		2001,
		2002,
		2001,
		2001
	],
	virenos: [
		1905,
		1900,
		1900,
		1901,
		1900,
		1901,
		1901,
		1901,
		1902,
		1902,
		1903,
		1903,
		1903
	]
}, oe = [
	"silver",
	"junker",
	"viren",
	"council"
], se = [
	"kai",
	"zephyr",
	"tiberius",
	"julida",
	"roux",
	"sima"
], ce = {
	kai: [
		14200,
		14201,
		14202
	],
	zephyr: [
		14303,
		14304,
		14305
	],
	tiberius: [
		14400,
		14401,
		14402
	],
	julida: [
		14403,
		14404,
		14405
	],
	roux: [
		14203,
		14204,
		14205
	],
	sima: [
		14300,
		14301,
		14302
	]
}, le = {
	harbinger: [
		{ level: 0 },
		{
			level: 0,
			skip: "expert"
		},
		{
			level: 1,
			effect: "market"
		},
		{
			level: 1,
			skip: "hard",
			effect: "eliminate"
		},
		{
			level: 1,
			effect: "market"
		},
		{
			level: 2,
			skip: "expert"
		},
		{
			level: 2,
			effect: "eliminate"
		},
		{
			level: 2,
			effect: "market"
		},
		{
			level: 3,
			skip: "hard"
		},
		{
			level: 3,
			effect: "market"
		},
		{
			level: 3,
			effect: "eliminate"
		},
		{
			level: 4,
			skip: "expert"
		},
		{
			level: 4,
			effect: "market"
		},
		{
			level: 4,
			effect: "eliminate"
		},
		{
			level: 5,
			skip: "normal"
		},
		{
			level: 5,
			skip: "normal"
		},
		{ level: 6 }
	],
	triumvirate: [
		{ level: 0 },
		{
			level: 0,
			skip: "expert"
		},
		{
			level: 1,
			effect: "market"
		},
		{
			level: 1,
			skip: "hard",
			effect: "eliminate"
		},
		{
			level: 1,
			effect: "market"
		},
		{
			level: 1,
			skip: "hard"
		},
		{
			level: 2,
			effect: "eliminate"
		},
		{
			level: 2,
			effect: "market"
		},
		{
			level: 2,
			skip: "hard"
		},
		{
			level: 3,
			effect: "market"
		},
		{
			level: 3,
			effect: "eliminate"
		},
		{
			level: 3,
			skip: "expert"
		},
		{
			level: 4,
			effect: "market"
		},
		{
			level: 4,
			effect: "eliminate"
		},
		{
			level: 5,
			skip: "normal"
		},
		{
			level: 5,
			skip: "normal"
		},
		{ level: 6 }
	],
	duomo: [
		{ level: 0 },
		{
			level: 0,
			skip: "expert"
		},
		{
			level: 1,
			effect: "market"
		},
		{
			level: 1,
			skip: "hard",
			effect: "eliminate"
		},
		{
			level: 1,
			effect: "market"
		},
		{
			level: 1,
			skip: "expert"
		},
		{
			level: 2,
			effect: "eliminate"
		},
		{
			level: 2,
			skip: "expert"
		},
		{
			level: 2,
			effect: "market"
		},
		{
			level: 3,
			effect: "eliminate"
		},
		{
			level: 3,
			effect: "market"
		},
		{
			level: 4,
			effect: "eliminate"
		},
		{
			level: 5,
			skip: "normal"
		},
		{
			level: 5,
			skip: "normal"
		},
		{ level: 6 }
	]
}, O = {
	id: "unstoppable",
	tier: "beta",
	mechanics: ["deck-bag-building", "engine-building"],
	interactionTags: ["cooperative"],
	nameKey: "games.unstoppable.name",
	descKey: "games.unstoppable.desc",
	rulesKey: "games.unstoppable.rules",
	icon: "🦾",
	iconImg: "games/unstoppable.webp",
	minPlayers: 1,
	maxPlayers: 2,
	rulesUrl: { en: "https://renegadegamestudios.com/content/File%20Storage%20for%20site/Rulebooks/Unstoppable/Unstoppable_Rulebook_P4.pdf" },
	bestPlayers: [1],
	accent: "#606cb4",
	releasedAt: "2026-10-16T18:08:22+08:00",
	search: {
		py: "gu yong ying hao",
		init: "gyyh"
	},
	hotseat: "cover"
}, k = t.union([t.number(), t.enum([
	"focus",
	"unite",
	"upgrades",
	"sourceUpgrades",
	"missingHealth",
	"health",
	"armor",
	"actions",
	"credits",
	"silverDiscard",
	"tacticsDiscard",
	"active",
	"wounded",
	"level",
	"danger"
])]), A = t.lazy(() => t.object({
	op: t.enum(/* @__PURE__ */ "damage.bossDamage.credits.health.armor.actions.train.draw.refresh.eliminate.destroy.defeat.discardThreat.retrieve.draft.upgrade.discount.faction.choice.bargain.pay.exchange.repeat.allDamage.bottom.trade.recycleMarket.disableKeywords.swapResources.returnSelf.playTop.shuffleThreat.splitDamage.activateUpgrades.revealCores.mark".split(".")),
	n: k.optional(),
	times: k.optional(),
	when: t.enum([
		"conspire",
		"upgraded",
		"upgradedConspire",
		"upgradedUnite3",
		"health7",
		"health5",
		"armor5",
		"upgrades2",
		"upgrades4",
		"unite3",
		"unite4",
		"active3",
		"killed",
		"firstPlay",
		"kills2"
	]).optional(),
	level: t.number().optional(),
	effects: t.array(A).optional(),
	options: t.array(t.array(A)).optional(),
	resource: t.enum([
		"health",
		"armor",
		"credits",
		"actions"
	]).optional(),
	zone: t.enum([
		"hand",
		"discard",
		"play",
		"any",
		"deck"
	]).optional(),
	maxLevel: t.number().optional(),
	minLevel: t.number().optional(),
	faction: t.enum([
		"silver",
		"junker",
		"viren",
		"council"
	]).optional(),
	flag: t.string().optional(),
	all: t.boolean().optional(),
	ignoreTaunt: t.boolean().optional(),
	noBoss: t.boolean().optional(),
	optional: t.boolean().optional()
})), j = t.object({
	boss: t.enum([
		"harbinger",
		"triumvirate",
		"duomo"
	]).default("harbinger"),
	difficulty: t.enum([
		"normal",
		"hard",
		"expert"
	]).default("normal"),
	expansion: t.boolean().default(!0)
}).prefault({}), ue = t.discriminatedUnion("type", [t.object({
	type: t.literal("pick"),
	id: t.string().max(80)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), M = t.object({
	iid: t.string(),
	core: t.number().nullable(),
	upgrades: t.array(t.number()),
	exhausted: t.boolean(),
	cost: t.number(),
	factions: t.array(t.enum([
		"silver",
		"junker",
		"viren",
		"council"
	]))
}), de = t.object({
	iid: t.string(),
	owner: t.string(),
	threat: t.number(),
	attack: t.number(),
	health: t.number(),
	damage: t.number(),
	keywords: t.array(t.enum([
		"fast",
		"taunt",
		"rage",
		"terror",
		"crazed5"
	])),
	upgrades: t.array(t.number()),
	onDeck: t.boolean(),
	disabled: t.boolean()
}), fe = t.object({
	id: t.string(),
	key: t.string(),
	params: t.record(t.string(), t.union([t.string(), t.number()])),
	category: t.enum([
		"character",
		"play",
		"exhaust",
		"buy",
		"target",
		"effect",
		"draft",
		"card",
		"number",
		"end",
		"story",
		"other"
	]),
	target: t.string().optional(),
	card: t.number().optional(),
	upgrade: t.number().optional(),
	threat: t.number().optional(),
	effects: t.array(A).optional(),
	n: t.number().optional(),
	cost: t.number().optional()
}), pe = t.object({
	config: j,
	phase: t.enum([
		"character",
		"upkeep",
		"draft",
		"main",
		"threat",
		"cleanup",
		"done"
	]),
	turn: t.number(),
	danger: t.number(),
	dangerLevel: t.number(),
	roundsLeft: t.number(),
	bossDamage: t.number(),
	bossHealth: t.number(),
	locations: t.array(t.number()),
	story: t.array(t.number()),
	storyDamage: t.record(t.string(), t.number()),
	storyCredits: t.record(t.string(), t.number()),
	storyNext: t.number().nullable(),
	storyResolved: t.array(t.number()),
	ending: t.number().nullable(),
	market: t.array(t.number()),
	upgradeCount: t.number(),
	coreCounts: t.array(t.number()),
	threatCount: t.number(),
	draftSets: t.array(t.object({
		who: t.string(),
		level: t.number(),
		cards: t.array(t.number()),
		picked: t.boolean()
	})),
	players: t.array(t.object({
		rid: t.string(),
		character: t.string(),
		health: t.number(),
		armor: t.number(),
		credits: t.number(),
		actions: t.number(),
		level: t.number(),
		training: t.number(),
		handCount: t.number(),
		deckCount: t.number(),
		play: t.array(M),
		discard: t.array(M),
		threats: t.array(de),
		ready: t.boolean(),
		loops: t.number(),
		victoryLevels: t.number(),
		ownedUpgrades: t.number()
	})),
	waiting: t.string().nullable(),
	prompt: t.string(),
	source: t.number().nullable(),
	victory: t.boolean(),
	reason: t.string().nullable(),
	scores: t.record(t.string(), t.number()),
	scoreParts: t.record(t.string(), t.object({
		base: t.number(),
		rounds: t.number(),
		health: t.number(),
		loops: t.number(),
		transhumanist: t.number(),
		retire: t.number(),
		coalition: t.number(),
		unstoppable: t.number()
	})),
	log: t.array(t.object({
		key: t.string(),
		who: t.string(),
		n: t.number().optional(),
		card: t.number().optional()
	}))
}), me = t.object({
	hand: t.array(M),
	choices: t.array(fe),
	source: M.nullable(),
	effect: A.nullable()
}), N = (e, t = 1, n = {}) => ({
	op: e,
	n: t,
	...n
}), P = {
	0: {
		name: "games.unstoppable.story.s00",
		text: "games.unstoppable.story.t00",
		options: [{
			key: "games.unstoppable.story.goMithras",
			resource: "none",
			n: 0,
			next: 1
		}, {
			key: "games.unstoppable.story.goVirenos",
			resource: "none",
			n: 0,
			next: 11
		}]
	},
	1: {
		name: "games.unstoppable.story.s01",
		text: "games.unstoppable.story.t01",
		options: [{
			key: "games.unstoppable.story.intimidate",
			resource: "damage",
			n: 3,
			next: 2,
			effects: [N("damage", 3)]
		}, {
			key: "games.unstoppable.story.buyInfo",
			resource: "credits",
			n: 3,
			next: 3,
			each: [N("eliminate", 1, { optional: !0 })]
		}]
	},
	2: {
		name: "games.unstoppable.story.s02",
		text: "games.unstoppable.story.t02",
		options: [{
			key: "games.unstoppable.story.defeat",
			resource: "damage",
			n: 4,
			next: 4,
			effects: [N("damage"), N("damage")]
		}, {
			key: "games.unstoppable.story.bribe",
			resource: "credits",
			n: 4,
			next: 5,
			effects: [N("defeat", 1, { zone: "deck" })]
		}]
	},
	3: {
		name: "games.unstoppable.story.s03",
		text: "games.unstoppable.story.t03",
		options: [{
			key: "games.unstoppable.story.teachLesson",
			resource: "damage",
			n: 4,
			next: 5,
			effects: [N("damage", 4)]
		}, {
			key: "games.unstoppable.story.support",
			resource: "credits",
			n: 4,
			next: 6,
			flag: "oneFreeUpgrade"
		}]
	},
	4: {
		name: "games.unstoppable.story.s04",
		text: "games.unstoppable.story.t04",
		options: [{
			key: "games.unstoppable.story.defeat",
			resource: "damage",
			n: 5,
			next: 7,
			effects: [N("damage", 3), N("damage")]
		}, {
			key: "games.unstoppable.story.wait",
			resource: "armor",
			n: 5,
			next: 8,
			each: [N("draw", 1, { flag: "bottom" })]
		}]
	},
	5: {
		name: "games.unstoppable.story.s05",
		text: "games.unstoppable.story.t05",
		options: [{
			key: "games.unstoppable.story.offer",
			resource: "eliminate",
			n: 3,
			next: 9
		}, {
			key: "games.unstoppable.story.donate",
			resource: "credits",
			n: 8,
			next: 10,
			flag: "damageDiscount"
		}]
	},
	6: {
		name: "games.unstoppable.story.s06",
		text: "games.unstoppable.story.t06",
		options: [{
			key: "games.unstoppable.story.counterattack",
			resource: "damage",
			n: 7,
			next: 8,
			effects: [N("damage", 3), N("damage", 2)]
		}, {
			key: "games.unstoppable.story.bribe",
			resource: "credits",
			n: 6,
			next: 9,
			effects: [N("defeat", 1, { flag: "active" })]
		}]
	},
	7: {
		name: "games.unstoppable.story.s07",
		text: "games.unstoppable.story.t07",
		options: [{
			key: "games.unstoppable.story.killKrenko",
			resource: "damage",
			n: 10,
			next: 7,
			flag: "ending"
		}]
	},
	8: {
		name: "games.unstoppable.story.s08",
		text: "games.unstoppable.story.t08",
		options: [{
			key: "games.unstoppable.story.duel",
			resource: "damage",
			n: 10,
			next: 8,
			flag: "ending"
		}]
	},
	9: {
		name: "games.unstoppable.story.s09",
		text: "games.unstoppable.story.t09",
		options: [{
			key: "games.unstoppable.story.price",
			resource: "credits",
			n: 10,
			next: 9,
			flag: "ending"
		}]
	},
	10: {
		name: "games.unstoppable.story.s10",
		text: "games.unstoppable.story.t10",
		options: [{
			key: "games.unstoppable.story.accept",
			resource: "credits",
			n: 15,
			next: 10,
			flag: "donationDiscountEnding"
		}, {
			key: "games.unstoppable.story.contribute",
			resource: "eliminate",
			n: 1,
			next: 10,
			flag: "donate"
		}]
	},
	11: {
		name: "games.unstoppable.story.s11",
		text: "games.unstoppable.story.t11",
		options: [{
			key: "games.unstoppable.story.bounty",
			resource: "damage",
			n: 3,
			next: 12,
			effects: [N("damage", 3)]
		}, {
			key: "games.unstoppable.story.infiltrate",
			resource: "credits",
			n: 4,
			next: 13,
			each: [N("upgrade", 4)]
		}]
	},
	12: {
		name: "games.unstoppable.story.s12",
		text: "games.unstoppable.story.t12",
		options: [{
			key: "games.unstoppable.story.finishPrey",
			resource: "damage",
			n: 4,
			next: 14,
			each: [N("actions")]
		}, {
			key: "games.unstoppable.story.release",
			resource: "armor",
			n: 4,
			next: 15,
			effects: [N("defeat", 1, { zone: "deck" })]
		}]
	},
	13: {
		name: "games.unstoppable.story.s13",
		text: "games.unstoppable.story.t13",
		options: [{
			key: "games.unstoppable.story.bluff",
			resource: "damage",
			n: 4,
			next: 15,
			effects: [N("damage", 4)]
		}, {
			key: "games.unstoppable.story.deal",
			resource: "credits",
			n: 5,
			next: 16,
			each: [N("pay", 2, {
				resource: "credits",
				effects: [N("upgrade", 99)],
				optional: !0
			})]
		}]
	},
	14: {
		name: "games.unstoppable.story.s14",
		text: "games.unstoppable.story.t14",
		options: [{
			key: "games.unstoppable.story.cutLegs",
			resource: "damage",
			n: 5,
			next: 17,
			effects: [N("damage", 5)],
			flag: "remove21"
		}, {
			key: "games.unstoppable.story.outrun",
			resource: "actions",
			n: 3,
			next: 18,
			flag: "remove21"
		}]
	},
	15: {
		name: "games.unstoppable.story.s15",
		text: "games.unstoppable.story.t15",
		options: [{
			key: "games.unstoppable.story.resistArrest",
			resource: "damage",
			n: 7,
			next: 18,
			effects: [N("damage", 7, { flag: "overkillCredits" })]
		}, {
			key: "games.unstoppable.story.escape",
			resource: "credits",
			n: 4,
			next: 19,
			each: [N("health", -1), N("eliminate", 2, { optional: !0 })]
		}]
	},
	16: {
		name: "games.unstoppable.story.s16",
		text: "games.unstoppable.story.t16",
		options: [{
			key: "games.unstoppable.story.threaten",
			resource: "eliminate",
			n: 1,
			next: 19,
			flag: "damageLevel"
		}, {
			key: "games.unstoppable.story.bribe",
			resource: "credits",
			n: 3,
			next: 20,
			flag: "damageSurcharge"
		}]
	},
	17: {
		name: "games.unstoppable.story.s17",
		text: "games.unstoppable.story.t17",
		options: [{
			key: "games.unstoppable.story.fightSkargen",
			resource: "damage",
			n: 10,
			next: 17,
			flag: "ending"
		}]
	},
	18: {
		name: "games.unstoppable.story.s18",
		text: "games.unstoppable.story.t18",
		options: [{
			key: "games.unstoppable.story.counter",
			resource: "damage",
			n: 10,
			next: 18,
			flag: "ending"
		}]
	},
	19: {
		name: "games.unstoppable.story.s19",
		text: "games.unstoppable.story.t19",
		options: [{
			key: "games.unstoppable.story.exterminate",
			resource: "credits",
			n: 3,
			next: 19,
			flag: "swarmSurchargeEnding"
		}]
	},
	20: {
		name: "games.unstoppable.story.s20",
		text: "games.unstoppable.story.t20",
		options: [{
			key: "games.unstoppable.story.paySkargen",
			resource: "credits",
			n: 10,
			next: 20,
			flag: "upgradesDiscountEnding"
		}]
	},
	21: {
		name: "games.unstoppable.story.s21",
		text: "games.unstoppable.story.t21",
		options: []
	},
	22: {
		name: "games.unstoppable.story.s22",
		text: "games.unstoppable.story.t22",
		options: []
	}
};
function he(e, t) {
	if (e.story.includes(t) || e.story.push(t), e.storyDamage[t] = 0, e.storyCredits[t] = 0, t === 1 || t === 11) {
		let n = t === 1 ? "mithras" : "virenos", r = e.unusedThreats[n] ?? [];
		e.unusedThreats[n] = [], e.threatDeck = [...R(e, r), ...e.threatDeck];
	}
	(t === 14 || t === 19) && he(e, 21), t === 16 && (e.storyDamage[t] = 1), H(e, "games.unstoppable.logStory", "", t);
}
function ge(e, t, n) {
	let r = n.n * e.players.length;
	return n.resource === "armor" && (r = n.n), n.flag === "damageDiscount" && (r -= e.storyDamage[t] ?? 0), n.flag === "donationDiscountEnding" && (r -= e.storyCredits[t] ?? 0), n.flag === "damageSurcharge" && (r += e.storyDamage[t] ?? 0), n.flag === "swarmSurchargeEnding" && (r += e.storyCredits[21] ?? 0), n.flag === "upgradesDiscountEnding" && (r -= e.players.reduce((t, n) => t + [...n.hand, ...n.play].reduce((t, n) => t + e.cards[n].upgrades.length, 0), 0)), Math.max(0, r);
}
function _e(e, t, n) {
	return e.players.find((e) => e.rid === t).hand.filter((t) => e.cards[t].core !== null && w[e.cards[t].core].kind !== "boss" && w[e.cards[t].core].level >= n);
}
function ve(e, t, n, r) {
	let i = P[n].options[r];
	if (i.flag !== "donate") {
		if (e.storyResolved.push(n), i.flag?.includes("Ending") || i.flag === "ending") {
			e.ending = n, Se(e);
			return;
		}
		if (e.storyNext = i.next, i.flag === "remove21" && (e.story = e.story.filter((e) => e !== 21)), i.effects && V(e, t, void 0, i.effects, `story/${n}/${r}`), i.each) for (let t of e.players) V(e, t.rid, void 0, i.each, `story/${n}/${r}`);
		i.flag === "oneFreeUpgrade" && B(e, {
			type: "story",
			who: t,
			flag: "freeUpgrade"
		});
	}
}
function ye(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t);
	if (r?.type === "story" && r.flag === "freeUpgrade") {
		for (let t of e.players) n("games.unstoppable.story.giveUpgrade", () => {
			e.tasks.shift(), V(e, t.rid, void 0, [N("upgrade", 99)], "story/free");
		}, {
			category: "story",
			target: t.rid
		});
		return;
	}
	if (r?.type === "storyPay") {
		let a = r.n, o = r.group, s = P[a].options[o], c = r.ids, l = r.step ?? 0, u = r.cores[0], d = (t) => {
			e.tasks.shift(), l + 1 < c.length && u - t > 0 ? B(e, {
				...r,
				who: c[l + 1],
				step: l + 1,
				cores: [u - t]
			}) : ve(e, c[0], a, o);
		};
		if (s.resource === "eliminate") {
			let i = s.flag === "damageLevel" ? Math.min(5, (e.storyDamage[a] ?? 0) + 1) : s.n;
			for (let o of _e(e, t, i)) n("games.unstoppable.eliminateCard", () => {
				let t = w[e.cards[o].core].level;
				J(e, o, "removed"), s.flag === "donate" ? (e.storyCredits[a] = (e.storyCredits[a] ?? 0) + t, e.tasks.shift(), l + 1 < c.length && B(e, {
					...r,
					who: c[l + 1],
					step: l + 1
				})) : d(1);
			}, {
				category: "card",
				target: o,
				card: e.cards[o].core,
				n: i
			});
		} else {
			let r = s.resource, a = c.slice(l + 1).reduce((t, n) => t + e.players.find((e) => e.rid === n)[r], 0);
			for (let o = Math.max(0, u - a); o <= Math.min(u, i[r]); o++) n("games.unstoppable.story.contributeAmount", () => {
				q(e, t, r, -o), d(o);
			}, {
				category: "number",
				n: o,
				cost: o,
				params: { n: o },
				target: r
			});
		}
		return;
	}
	if (r?.type === "storyThreat") {
		let a = r.n, o = r.flag, s = () => {
			e.tasks.shift();
		};
		if (o === "discard" || o === "highDiscard") {
			for (let t of i.hand.filter((t) => o !== "highDiscard" || w[e.cards[t].core].level >= 3)) n("games.unstoppable.discardCard", () => {
				s(), J(e, t, "discard");
			}, {
				category: "card",
				target: t,
				card: e.cards[t].core
			});
			n(a === 9 ? "games.unstoppable.story.loseCredit" : "games.unstoppable.story.takeDamage", () => {
				s(), a === 9 ? q(e, t, "credits", -1) : De(e, t, a === 10 ? 10 : 1);
			}, {
				category: "other",
				n: a === 10 ? 10 : 1
			});
		} else if (o === "pay") {
			let r = a === 3 ? 1 : 2;
			i.credits >= r && n("games.unstoppable.pay", () => {
				s(), q(e, t, "credits", -r);
			}, {
				category: "number",
				cost: r,
				n: r,
				params: { n: r },
				target: "credits"
			}), n(a === 20 ? "games.unstoppable.story.extraThreat" : "games.unstoppable.story.takeDamage", () => {
				s(), a === 20 ? B(e, {
					type: "refill",
					who: t,
					n: 1,
					flag: "one"
				}) : De(e, t, a === 3 ? i.credits : 1);
			}, {
				category: "other",
				n: a === 3 ? i.credits : 1
			});
		} else if (o === "hurt" || o === "endKrenko" || o === "endSkargen") {
			let a = o === "endKrenko" ? 3 + +(i.armor === 0) : o === "endSkargen" ? 1 + (i.armor === 0 ? 3 : 0) : r.step ?? 1;
			n("games.unstoppable.story.takeDamage", () => {
				s(), De(e, t, a);
			}, {
				category: "other",
				n: a,
				params: { n: a }
			});
		}
		return;
	}
	if (!(e.storyNext !== null || e.victory)) for (let r of e.story.filter((t) => !e.storyResolved.includes(t))) r === 0 && e.players.some((e) => e.level < 2) || P[r].options.forEach((a, o) => {
		let s = ge(e, r, a);
		if (!(a.resource === "damage" && (e.storyDamage[r] ?? 0) < s) && !((a.resource === "credits" || a.resource === "actions") && e.players.reduce((e, t) => e + t[a.resource], 0) < s) && !(a.resource === "armor" && i.armor < s)) {
			if (a.resource === "eliminate") {
				let t = a.flag === "damageLevel" ? Math.min(5, (e.storyDamage[r] ?? 0) + 1) : a.n;
				if (e.players.some((n) => !_e(e, n.rid, t).length)) return;
			}
			n(a.key, () => {
				if (a.resource === "credits" || a.resource === "actions" || a.resource === "eliminate") {
					let n = [t, ...e.players.filter((e) => e.rid !== t).map((e) => e.rid)];
					B(e, {
						type: "storyPay",
						who: t,
						n: r,
						group: o,
						step: 0,
						ids: n,
						cores: [a.resource === "eliminate" ? n.length : s]
					});
				} else a.resource === "armor" && q(e, t, "armor", -s), a.resource === "damage" && (e.storyDamage[r] -= s), ve(e, t, r, o);
			}, {
				category: "story",
				target: `story:${r}`,
				n: o,
				cost: s,
				params: { n: s }
			});
		}
	});
}
function be(e, t) {
	if (e.config.boss !== "duomo") return;
	let n = e.story.filter((t) => !e.storyResolved.includes(t)), r = [];
	for (let i of n) {
		if (t === "upkeep" && (i === 21 && (e.storyCredits[21] = (e.storyCredits[21] ?? 0) + le.duomo[e.danger].level), i === 8)) {
			let t = le.duomo[e.danger];
			(!t.skip || t.effect !== "eliminate") && (e.story.includes(4) || he(e, 4));
		}
		if (t === "threat") {
			for (let t of e.players) {
				if ([
					2,
					4,
					8,
					12,
					17,
					21
				].includes(i)) {
					let n = i === 2 || i === 12 ? 1 : i === 8 ? 2 : i === 21 ? e.storyCredits[21] ?? 0 : 3;
					r.push({
						type: "storyThreat",
						who: t.rid,
						n: i,
						step: n,
						flag: "hurt"
					});
				}
				[3, 13].includes(i) && r.push({
					type: "storyThreat",
					who: t.rid,
					n: i,
					flag: "pay"
				}), [
					6,
					9,
					10,
					15
				].includes(i) && r.push({
					type: "storyThreat",
					who: t.rid,
					n: i,
					flag: i === 9 ? "highDiscard" : "discard"
				});
			}
			i === 16 && (e.storyDamage[16] = (e.storyDamage[16] ?? 0) + 1), i === 4 && e.story.some((e) => [
				7,
				8,
				9,
				10
			].includes(e)) && (e.story = e.story.filter((e) => e !== 4));
		}
		if (t === "threatEnd" && (i === 7 || i === 18)) for (let t of e.players) r.push({
			type: "storyThreat",
			who: t.rid,
			n: i,
			flag: i === 7 ? "endKrenko" : "endSkargen"
		});
		if (t === "cleanup" && i === 20) for (let t of e.players) r.push({
			type: "storyThreat",
			who: t.rid,
			n: i,
			flag: "pay"
		});
	}
	B(e, ...r);
}
var F = (e) => {
	let t = e.data?.kind;
	return e.kind === "unstCombat" && t === "echo" ? 700 : e.kind === "unstCombat" && [
		"attack",
		"capacitor",
		"hostile"
	].includes(t ?? "") ? 650 : 500;
}, I = (e, t) => e.players.find((e) => e.rid === t), L = (e, t = 1, n = {}) => ({
	op: e,
	n: t,
	...n
});
function R(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rng++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function z(e, t, n, r) {
	let i = `c${e.nextId++}`;
	return e.cards[i] = {
		iid: i,
		owner: t,
		core: n,
		threat: r,
		upgrades: [],
		damage: 0,
		exhausted: !1,
		extraFactions: [],
		flags: []
	}, i;
}
function xe(e) {
	if (!e.threatDeck.length) {
		let t = Object.keys(e.unusedThreats).find((t) => e.unusedThreats[t].length);
		t && (e.threatDeck = R(e, e.unusedThreats[t]), e.unusedThreats[t] = []);
	}
	return e.threatDeck.shift();
}
function B(e, ...t) {
	e.tasks.unshift(...t);
}
function V(e, t, n, r, i = "effect") {
	r.length && B(e, {
		type: "group",
		who: t,
		source: n,
		effects: structuredClone(r),
		keys: r.map((e, t) => `${i}/${t}`)
	});
}
function H(e, t, n = "", r, i) {
	e.log.push({
		key: t,
		who: n,
		...r === void 0 ? {} : { n: r },
		...i === void 0 ? {} : { card: i }
	}), e.log.length > 35 && e.log.shift();
}
function U(e, t) {
	e.victory || (e.phase = "done", e.reason = t, e.tasks = []);
}
function Se(e) {
	e.victory || (e.victory = !0, e.players.forEach((e) => {
		e.victoryLevels = 0, e.ready = !1;
	}), H(e, "games.unstoppable.logVictory"));
}
function Ce(e) {
	return le[e.config.boss][e.danger]?.level ?? 6;
}
function W(e, t) {
	return [.../* @__PURE__ */ new Set([...t.core !== null && w[t.core].faction ? [w[t.core].faction] : [], ...t.core === 13820 && !I(e, t.owner).play.includes(t.iid) ? [] : t.extraFactions])];
}
function we(e) {
	return [...e.hand, ...e.play];
}
function G(e, t, n) {
	return t.play.filter((t) => e.cards[t].core !== null && w[e.cards[t].core].passive?.includes(n));
}
function K(e, t, n, r) {
	if (r === void 0) return 1;
	if (typeof r == "number") return r;
	let i = n ? e.cards[n] : void 0, a = we(t).map((t) => e.cards[t]);
	switch (r) {
		case "focus": {
			let t = i ? W(e, i) : [];
			return a.filter((n) => W(e, n).some((e) => t.includes(e))).length;
		}
		case "unite": return new Set(a.flatMap((t) => W(e, t))).size;
		case "upgrades": return a.reduce((e, t) => e + t.upgrades.length, 0);
		case "sourceUpgrades": return i?.upgrades.length ?? 0;
		case "missingHealth": return 10 - t.health;
		case "health": return t.health;
		case "armor": return t.armor;
		case "actions": return t.actions;
		case "credits": return t.credits;
		case "silverDiscard": return t.discard.filter((t) => w[e.cards[t].core ?? 12800]?.faction === "silver").length;
		case "tacticsDiscard": return t.discard.filter((t) => w[e.cards[t].core ?? 12800]?.kind === "tactic").length;
		case "active": return t.threats.length;
		case "wounded": return t.threats.filter((t) => e.cards[t].damage > 0).length;
		case "level": return t.level;
		case "danger": return Ce(e);
	}
}
function Te(e, t, n) {
	let r = I(e, t.who), i = t.source ? e.cards[t.source] : void 0;
	if (n.level && r.level < n.level) return !1;
	if (n.flag?.startsWith("has")) {
		let t = {
			hasJunker: "junker",
			hasSilver: "silver",
			hasViren: "viren"
		}[n.flag];
		if (t && !we(r).some((n) => W(e, e.cards[n]).includes(t))) return !1;
	}
	switch (n.when) {
		case "conspire":
		case "upgradedConspire": return !!i && (n.when === "conspire" || i.upgrades.length > 0) && we(r).some((t) => t !== i.iid && W(e, e.cards[t]).some((t) => W(e, i).includes(t)));
		case "upgraded": return (i?.upgrades.length ?? 0) > 0;
		case "upgradedUnite3": return (i?.upgrades.length ?? 0) > 0 && K(e, r, t.source, "unite") >= 3;
		case "health7": return r.health <= 7;
		case "health5": return r.health <= 5;
		case "armor5": return r.armor >= 5;
		case "upgrades2": return K(e, r, t.source, "upgrades") >= 2;
		case "upgrades4": return [...we(r), ...r.discard].reduce((t, n) => t + e.cards[n].upgrades.length, 0) >= 4;
		case "unite3": return K(e, r, t.source, "unite") >= 3;
		case "unite4": return K(e, r, t.source, "unite") >= 4;
		case "active3": return r.threats.length >= 3;
		case "firstPlay": return e.uses[`play/${t.source}`] === 1;
		case "killed": return i?.flags.includes("killed") ?? !1;
		case "kills2": return Ee(r, "kills") >= 2;
		default: return !0;
	}
}
function Ee(e, t) {
	return e.flags.filter((e) => e.startsWith(`${t}:`)).reduce((e, t) => e + Number(t.split(":")[1]), 0);
}
function q(e, t, n, r) {
	let i = I(e, t), a = i[n];
	if (i[n] = Math.max(0, Math.min(n === "credits" ? 2 ** 53 - 1 : n === "actions" ? 6 : 10, i[n] + r)), n === "credits" && r < 0 && e.story.includes(5) && !e.storyResolved.includes(5) && (e.storyDamage[5] = (e.storyDamage[5] ?? 0) + a - i.credits), n === "actions" && i.actions > a) for (let n of G(e, i, "actionDamage2")) V(e, t, n, [L("damage", 2, { times: i.actions - a })], "actionGain");
	n === "health" && i.health === 0 && U(e, "games.unstoppable.lossHealth");
}
function De(e, t, n) {
	let r = I(e, t), i = Math.min(r.armor, n);
	r.armor -= i, r.health = Math.max(0, r.health - (n - i)), i && q(e, t, "credits", i * G(e, r, "blockedCredits").length), H(e, "games.unstoppable.logHurt", t, n), r.health || U(e, "games.unstoppable.lossHealth");
}
function Oe(e, t, n) {
	let r = t.training;
	if (t.training = Math.min(6, t.training + n), r < t.training) {
		t.flags.push("trained");
		for (let n of G(e, t, "trainDamage2")) V(e, t.rid, n, [L("damage", 2, { times: t.training - r })], "train");
	}
}
function ke(e, t) {
	let n = e.cards[t], r = I(e, n.owner);
	for (let i of [
		"hand",
		"play",
		"deck",
		"threats",
		"discard",
		"removed"
	]) {
		let a = r[i].indexOf(t);
		a >= 0 && (r[i].splice(a, 1), i === "play" && n.core !== null && V(e, r.rid, t, w[n.core].leave ?? [], "leave"));
	}
}
function J(e, t, n) {
	let r = e.cards[t], i = I(e, r.owner);
	ke(e, t), i[n].push(t), n !== "threats" && n !== "deck" && (r.damage = 0), n === "play" && r.core !== null && V(e, i.rid, t, w[r.core].enter ?? [], "enter");
}
function Ae(e, t) {
	return e.cards[t].core === null || w[e.cards[t].core].kind !== "boss";
}
function je(e, t) {
	if (!Ae(e, t)) return;
	let n = e.cards[t];
	H(e, "games.unstoppable.logEliminate", n.owner, void 0, n.core ?? void 0), J(e, t, "removed"), B(e, {
		type: "check",
		who: n.owner
	});
}
function Y(e, t, n = !1) {
	let r = e.cards[t];
	if (r.core === null) {
		J(e, t, "removed");
		return;
	}
	if (w[r.core].kind === "boss") {
		J(e, t, "discard"), B(e, {
			type: "effect",
			who: r.owner,
			source: t,
			effect: L("bossDamage", 1, { flag: "mandatory" })
		});
		return;
	}
	J(e, t, "hand"), n && V(e, r.owner, t, w[r.core].acquire ?? [], "acquire");
}
function X(e, t) {
	let n = E[t.threat], r = t.upgrades.map((e) => T[e]), i = (n.attack === "danger" ? Ce(e) : n.attack) + r.reduce((e, t) => e + t.attack, 0), a = (n.defense === "danger" ? Ce(e) : n.defense) + (n.defenseBonus ?? 0) + r.reduce((e, t) => e + t.defense, 0), o = t.flags.includes("disabled") ? [] : [
		...n.keywords,
		...r.flatMap((e) => e.keywords),
		...e.config.boss === "duomo" && e.story.includes(17) && !e.storyResolved.includes(17) && I(e, t.owner).threats.includes(t.iid) ? ["terror"] : []
	];
	return {
		attack: i,
		health: i + a,
		keywords: o
	};
}
function Me(e) {
	return e.players.flatMap((e) => [...e.threats, ...e.deck.slice(0, 1)]);
}
function Ne(e, t) {
	return Me(e).filter((n) => {
		let r = e.cards[n], i = I(e, r.owner), a = X(e, r);
		return t.noBoss && E[r.threat].boss || t.zone === "deck" && i.deck[0] !== n || t.flag === "wounded" && !r.damage ? !1 : t.ignoreTaunt || a.keywords.includes("taunt") || ![...i.threats, ...i.deck.slice(0, 1)].some((t) => X(e, e.cards[t]).keywords.includes("taunt"));
	});
}
function Pe(e, t, n, r = !1) {
	let i = e.cards[t], a = I(e, i.owner), o = a.deck[0] === t, s = i.flags.includes("disabled") ? [] : [...E[i.threat].reward, ...i.upgrades.flatMap((e) => T[e].reward)];
	H(e, r ? "games.unstoppable.logDestroy" : "games.unstoppable.logDefeat", n, void 0, i.threat), I(e, n).flags.push("kills:1");
	let c = o ? a.deck[1] : void 0;
	for (let t of G(e, I(e, n), "killActions1")) V(e, n, t, [L("actions")], "kill");
	for (let t of G(e, I(e, n), "killCredits1")) V(e, n, t, [L("credits")], "kill");
	r ? J(e, t, "removed") : G(e, a, "redirectKills").length && !E[i.threat].boss && i.core !== null ? B(e, {
		type: "reveal",
		who: a.rid,
		source: t,
		flag: `redirect/${n}`,
		effects: s
	}) : (V(e, n, t, s, "reward"), B(e, {
		type: "check",
		who: a.rid
	}), c && B(e, {
		type: "reveal",
		who: a.rid,
		source: c
	}), Y(e, t)), r && (B(e, {
		type: "check",
		who: a.rid
	}), c && B(e, {
		type: "reveal",
		who: a.rid,
		source: c
	}));
}
function Fe(e, t, n, r, i, a = !0) {
	let o = e.cards[n], s = I(e, t), c = X(e, o);
	a && q(e, t, "actions", -c.keywords.filter((e) => e === "terror").length), o.damage += r, H(e, "games.unstoppable.logDamage", t, r, o.threat), o.damage >= c.health && (i && e.cards[i].flags.push("killed"), Pe(e, n, t)), s.health <= 0 && U(e, "games.unstoppable.lossHealth");
}
function Ie(e, t) {
	if (t.core === null) return 0;
	let n = w[t.core], r = I(e, t.owner);
	return n.cost < 0 ? -1 : Math.max(0, n.cost - t.upgrades.reduce((e, t) => e + (T[t].costReduction ?? 0), 0) - (t.flags.includes("cost6") ? 6 : 0) - t.flags.filter((e) => e === "cost2").length * 2 - t.flags.filter((e) => e === "cost1").length - (n.passive?.includes("uniteCostReduction") ? K(e, r, t.iid, "unite") : 0) - (n.cost >= 2 ? Ee(r, "playedCost") : 0));
}
function Le(e, t, n, r, i) {
	if (i !== void 0) return T[r].cost <= i ? 0 : Infinity;
	let a = T[r];
	return Math.max(0, a.cost - (a.faction && W(e, n).includes(a.faction) ? 2 : 0) - t.upgradeDiscount - (e.story.includes(20) ? 2 - n.upgrades.length : 0));
}
function Re(e, t, n) {
	if (t.core === null || w[t.core].kind === "boss") return !1;
	let r = T[n], i = w[t.core];
	return t.upgrades.every((e) => T[e].slot !== r.slot) && (r.kind === "either" || i.kind === r.kind || !!i.passive?.includes("allyTacticUpgrades"));
}
function ze(e) {
	for (; e.market.length < 6 && e.upgradeDeck.length;) e.market.push(e.upgradeDeck.shift());
}
function Be(e, t, n, r) {
	let i = e.locations[n] < [
		4,
		3,
		5
	][n] * e.players.length;
	if (e.locations[n] += r, i && e.locations[n] >= [
		4,
		3,
		5
	][n] * e.players.length) for (let t of e.players) V(e, t.rid, void 0, n === 0 ? [L("train", 2)] : n === 1 ? [L("eliminate")] : [L("pay", 2, {
		resource: "credits",
		effects: [L("bossDamage")],
		optional: !0
	})], "locationReward");
	H(e, "games.unstoppable.logLocation", t, r);
}
function Ve(e, t, n, r, i) {
	q(e, t.rid, "credits", -i), t.upgradeDiscount = 0;
	let a = e.cards[n], o = e.market.indexOf(r);
	e.market.splice(o, 1), a.upgrades.push(r), ze(e), H(e, "games.unstoppable.logUpgrade", t.rid, i, r);
	for (let n of G(e, t, "upgradeBuyDamage2Health1")) V(e, t.rid, n, [L("damage", 2), L("health")], "buy");
}
function He(e) {
	let t = e.tasks.shift();
	e.tasks[0]?.type === "count" && e.tasks[0].source === t.source && e.tasks[0].effectId === t.effectId && e.tasks.shift();
}
function Ue(e, t, n, r, i = 0) {
	let a = e.cards[n], o = w[a.core], s = I(e, t), c = r === "exhaust" ? o.exhaust?.[i] ?? [] : o.play, l = c.map((e) => o.id === 14106 && r === "play" ? {
		...e,
		...e.n === "actions" ? { n: s.actions } : {},
		...e.times === "actions" ? { times: s.actions } : {}
	} : e), u = c.map((e, t) => `core/${r}/${i}/${t}`);
	for (let e = 0; e < a.upgrades.length; e++) {
		let t = a.upgrades[e], n = T[t], i = r === "exhaust" ? n.exhaust ?? [] : o.kind === "ally" ? [] : n.play;
		l.push(...i), u.push(...i.map((e, n) => `upgrade/${t}/${r}/${n}`));
	}
	if (r === "exhaust") {
		for (let t of G(e, s, "alliesActions1Damage3")) l.push(L("actions"), L("damage", 3)), u.push(`aid/${t}/a`, `aid/${t}/d`);
		if (G(e, s, "doubleExhaust").length) {
			let e = [...l], t = [...u];
			l.push(...e), u.push(...t);
		}
	} else {
		if (o.cost >= 2) for (let e = 0; e < Ee(s, "playedDamage"); e++) l.push(L("damage")), u.push(`playedDamage/${e}`);
		o.passive?.includes("anyFaction") && (l.push(L("faction")), u.push("faction"));
		for (let t of G(e, s, "otherPlayDamage1").filter((e) => e !== n)) l.push(L("damage")), u.push(`tavern/${t}`);
		if (o.kind === "tactic") for (let e = 0; e < a.upgrades.length * Ee(s, "tacticUpgradeDamage"); e++) l.push(L("damage")), u.push(`yuki/${e}`);
	}
	l.length && B(e, {
		type: "group",
		who: t,
		source: n,
		effects: structuredClone(l),
		keys: u
	});
}
function We(e, t, n, r, i = !1) {
	let a = I(e, t), o = e.cards[n];
	i || q(e, t, "actions", -r), o.flags = o.flags.filter((e) => !e.startsWith("x:")), o.flags.push(`x:${r}`), e.uses[`play/${n}`] = (e.uses[`play/${n}`] ?? 0) + 1, o.exhausted = !1, a.ready = !1, Ue(e, t, n, "play"), J(e, n, "play"), H(e, "games.unstoppable.logPlay", t, r, o.core);
}
function Ge(e, t, n) {
	let r = t.effects.splice(n, 1)[0], i = t.keys.splice(n, 1)[0], a = t.source && t.flag !== "uncounted" ? [{
		type: "count",
		who: t.who,
		source: t.source,
		effectId: i
	}] : [];
	B(e, {
		type: "effect",
		who: t.who,
		source: t.source,
		effect: r,
		effectId: i,
		...t.flag === "echo" ? { flag: "echo" } : {}
	}, ...a);
}
function Ke(e, t, n) {
	e.tasks.shift(), n?.length && V(e, t.who, t.source, n, `${t.effectId ?? "child"}/child`);
}
function qe(e, t, n) {
	return (n.zone === "hand" ? t.hand : n.zone === "play" ? t.play : n.zone === "discard" ? t.discard : n.zone === "deck" ? n.flag === "searchDeck" ? t.deck : t.deck.slice(0, 1) : [
		...t.hand,
		...t.discard,
		...t.play
	]).filter((t) => {
		let r = e.cards[t], i = r.core === null ? null : w[r.core];
		return Ae(e, t) && (n.minLevel === void 0 || (i?.level ?? 0) >= n.minLevel) && (n.maxLevel === void 0 || (i?.level ?? 0) <= n.maxLevel);
	});
}
function Je(e, t, n, r, i, a) {
	for (let o of [...new Set(e.market)]) for (let s of we(t)) {
		let c = e.cards[s], l = Le(e, t, c, o, i);
		(!a || s === a) && Re(e, c, o) && l <= t.credits && n("games.unstoppable.buy", () => {
			r?.(s, o), Ve(e, t, s, o, l);
		}, {
			category: "buy",
			target: s,
			card: c.core,
			upgrade: o,
			cost: l
		});
	}
}
function Ye(e, t, n) {
	let r = t.effect, i = I(e, t.who), a = t.source ? e.cards[t.source] : void 0, o = K(e, i, t.source, r.n), s = K(e, i, t.source, r.times), c = (n) => Ke(e, t, n), l = (t, i, a = "games.unstoppable.chooseCard") => t.forEach((t) => {
		let o = e.cards[t], s = I(e, o.owner);
		n(a, () => i(t), {
			category: "card",
			target: t,
			...(s.deck.includes(t) || s.threats.includes(t)) && !["searchDeck", "allyFromDeck"].includes(r.flag ?? "") ? { threat: o.threat } : { card: o.core ?? void 0 }
		});
	});
	switch (r.op) {
		case "damage":
		case "splitDamage": {
			if (o <= 0 || s <= 0) return !1;
			let i = Ne(e, r);
			r.flag?.startsWith("fixed:") && (i = i.filter((e) => e === r.flag.slice(6)));
			let l = r.op === "splitDamage", u = t.ids ?? [], d = Number(a?.flags.find((e) => e.startsWith("x:"))?.slice(2) ?? 1);
			if (l && d === 0) return !1;
			l && u.length >= d && (i = i.filter((e) => u.includes(e)));
			for (let d of i) for (let i of l ? Array.from({ length: o }, (e, t) => t + 1) : [o]) n("games.unstoppable.dealDamage", () => {
				c(), l && i < o ? B(e, {
					...t,
					effect: {
						...r,
						n: o - i
					},
					ids: [.../* @__PURE__ */ new Set([...u, d])]
				}) : !l && s > 1 && B(e, {
					...t,
					effect: {
						...r,
						n: o,
						times: s - 1
					}
				});
				let n = I(e, e.cards[d].owner).deck[0] === d, f = X(e, e.cards[d]).health, p = Math.max(0, e.cards[d].damage + i - f);
				Fe(e, t.who, d, i, t.source, !l || !u.includes(d)), r.flag === "onDeckDraw" && n && e.cards[d].damage === 0 && I(e, e.cards[d].owner).deck[0] !== d && V(e, t.who, t.source, [L("actions")]), r.flag === "overkillCredits" && p && q(e, t.who, "credits", p), r.flag === "reduceCostOnKill" && !Me(e).includes(d) && a && a.flags.push("cost2");
			}, {
				category: "target",
				target: d,
				n: i
			});
			if (!r.noBoss && !r.flag?.startsWith("fixed:") && e.config.boss === "triumvirate") {
				for (let i = 0; i < 3; i++) if (e.locations[i] < [
					4,
					3,
					5
				][i] * e.players.length && (!l || u.length < d || u.includes(`location:${i}`))) for (let a of l ? Array.from({ length: o }, (e, t) => t + 1) : [o]) n("games.unstoppable.hitLocation", () => {
					c(), l && a < o ? B(e, {
						...t,
						effect: {
							...r,
							n: o - a
						},
						ids: [.../* @__PURE__ */ new Set([...u, `location:${i}`])]
					}) : !l && s > 1 && B(e, {
						...t,
						effect: {
							...r,
							n: o,
							times: s - 1
						}
					}), Be(e, t.who, i, a);
				}, {
					category: "target",
					target: `location:${i}`,
					n: a
				});
			}
			if (!r.noBoss && !r.flag?.startsWith("fixed:") && e.config.boss === "duomo") {
				for (let i of e.story.filter((t) => !e.storyResolved.includes(t))) if ((i === 21 || P[i].options.some((e) => e.resource === "damage")) && !(l && u.length >= d && !u.includes(`story:${i}`))) for (let a of l ? Array.from({ length: o }, (e, t) => t + 1) : [o]) n("games.unstoppable.dealDamage", () => {
					c(), l && a < o ? B(e, {
						...t,
						effect: {
							...r,
							n: o - a
						},
						ids: [.../* @__PURE__ */ new Set([...u, `story:${i}`])]
					}) : !l && s > 1 && B(e, {
						...t,
						effect: {
							...r,
							n: o,
							times: s - 1
						}
					}), e.storyDamage[i] = (e.storyDamage[i] ?? 0) + a, i === 21 && (e.storyCredits[21] = Math.max(0, (e.storyCredits[21] ?? 0) - a), e.storyDamage[21] = 0);
				}, {
					category: "target",
					target: `story:${i}`,
					n: a
				});
			}
			break;
		}
		case "bossDamage":
			if (e.config.boss === "duomo") return !1;
			if ((e.config.boss !== "triumvirate" || e.locations.filter((t, n) => t < [
				4,
				3,
				5
			][n] * e.players.length).length < 2) && n("games.unstoppable.hitBoss", () => {
				c(), e.bossDamage += o, e.bossDamage >= (e.config.boss === "harbinger" ? 12 : 5) * e.players.length && Se(e);
			}, {
				category: "target",
				target: "boss",
				n: o
			}), e.config.boss === "triumvirate") for (let r = 0; r < 3; r++) e.locations[r] < [
				4,
				3,
				5
			][r] * e.players.length && n("games.unstoppable.hitLocation", () => {
				c(), Be(e, t.who, r, o);
			}, {
				category: "target",
				target: `location:${r}`,
				n: o
			});
			break;
		case "refresh":
			for (let n of r.all ? e.players : [i]) {
				let i = n.play.filter((t) => e.cards[t].exhausted && w[e.cards[t].core].kind === "ally");
				r.flag === "self" && (i = i.filter((e) => e === t.source)), r.flag === "other" && (i = i.filter((e) => e !== t.source)), l(i, (n) => {
					c(), e.cards[n].exhausted = !1, o > 1 && V(e, t.who, t.source, [{
						...r,
						n: o - 1
					}]);
				}, "games.unstoppable.refreshAlly");
			}
			break;
		case "eliminate":
			l(r.flag?.startsWith("self") ? a && Ae(e, a.iid) && !i.removed.includes(a.iid) ? [a.iid] : [] : qe(e, i, r), (n) => {
				c(), r.flag === "selfDraft" && B(e, {
					type: "effect",
					who: t.who,
					source: t.source,
					effect: L("revealCores", 3, { flag: "pickOne" })
				}), o > 1 && V(e, t.who, t.source, [{
					...r,
					n: o - 1
				}]), je(e, n);
			}, "games.unstoppable.eliminateCard");
			break;
		case "destroy":
		case "defeat":
		case "discardThreat":
		case "disableKeywords":
			l(Me(e).filter((t) => {
				let n = e.cards[t], i = I(e, n.owner);
				return (r.op !== "destroy" || Ae(e, t)) && (!r.noBoss || !E[n.threat].boss) && (r.zone !== "deck" || i.deck[0] === t) && (!["wounded", "activeWounded"].includes(r.flag ?? "") || n.damage > 0) && (r.op !== "discardThreat" && !["active", "activeWounded"].includes(r.flag ?? "") || i.threats.includes(t));
			}), (n) => {
				if (c(), r.op === "destroy" || r.op === "defeat") Pe(e, n, t.who, r.op === "destroy");
				else if (r.op === "disableKeywords") e.cards[n].flags.push("disabled");
				else {
					let t = I(e, e.cards[n].owner), r = t.deck[0] === n ? t.deck[1] : void 0;
					J(e, n, "discard"), B(e, {
						type: "check",
						who: t.rid
					}), r && B(e, {
						type: "reveal",
						who: t.rid,
						source: r
					});
				}
				o > 1 && V(e, t.who, t.source, [{
					...r,
					n: o - 1
				}]), r.flag === "extraActiveCost2" && V(e, t.who, t.source, [L("pay", 2, {
					resource: "actions",
					effects: [L("destroy", 1, { flag: "active" })],
					optional: !0
				})]);
			}, r.op === "destroy" ? "games.unstoppable.destroyThreat" : r.op === "discardThreat" ? "games.unstoppable.discardThreat" : "games.unstoppable.disableKeywords");
			break;
		case "retrieve": {
			let n = qe(e, i, r).filter((t) => e.cards[t].core !== null);
			if (r.flag === "random" && n.length) return !1;
			r.flag === "self" && (n = a ? [a.iid] : []), r.flag === "other" && (n = n.filter((e) => e !== t.source)), r.flag === "allyFromDeck" && (n = [...i.deck, ...i.discard].filter((t) => e.cards[t].core !== null && w[e.cards[t].core].kind === "ally")), l(n, (t) => {
				let n = i.deck.includes(t);
				c(), B(e, {
					type: "check",
					who: i.rid
				}), Y(e, t), n && r.flag === "allyFromDeck" && a && J(e, a.iid, "deck");
			}, "games.unstoppable.takeCard");
			break;
		}
		case "choice":
			r.options?.forEach((e, t) => {
				(r.flag !== "upgradedThird" || t !== 2 || a?.upgrades.length) && n("games.unstoppable.chooseEffect", () => c(e), {
					category: "effect",
					n: t + 1,
					params: { n: t + 1 },
					target: `option:${t}`,
					effects: e
				});
			});
			break;
		case "pay":
		case "bargain": {
			if (r.flag === "discardHand") {
				l(i.hand, (t) => {
					c(r.effects), J(e, t, "discard");
				}, "games.unstoppable.discardCard");
				break;
			}
			let a = r.op === "bargain" ? "credits" : r.resource ?? "credits", s = r.op === "bargain" ? Math.max(0, o - K(e, i, t.source, "focus") - i.bargainDiscount) : o;
			(i[a] >= s || r.flag === "embrace") && n("games.unstoppable.pay", () => {
				c(r.effects), r.flag === "embrace" && i.health <= s ? i.health = 5 : q(e, t.who, a, -s), r.op === "bargain" && (i.bargainDiscount = 0, Ee(i, "bargainDamage") && V(e, t.who, t.source, [L("damage", Ee(i, "bargainDamage"))]));
			}, {
				category: "number",
				cost: s,
				n: s,
				params: { n: s },
				target: a
			});
			break;
		}
		case "exchange": {
			if (r.flag === "sibling") {
				let r = K(e, i, t.source, "focus") >= 3;
				(r || i.health >= 1) && n("games.unstoppable.chooseEffect", () => {
					c(r ? [L("damage", 3), L("damage", 3)] : [L("damage", 3)]), r || q(e, t.who, "health", -1);
				}, {
					category: "effect",
					effects: r ? [L("damage", 3), L("damage", 3)] : [L("pay", 1, {
						resource: "health",
						effects: [L("damage", 3)]
					})]
				});
				break;
			}
			let s = r.resource ?? "health", l = Number(a?.flags.find((e) => e.startsWith("x:"))?.slice(2) ?? 0);
			for (let a = r.flag === "progress" ? l : 1; a <= Math.min(r.flag === "progress" ? l : o, i[s]); a++) r.flag === "progress" && a > i.credits || n("games.unstoppable.pay", () => {
				c(), q(e, t.who, s, -a), r.flag === "equalLevel" ? V(e, t.who, t.source, [L("damage", a)]) : r.flag === "armor" ? q(e, t.who, "armor", a) : r.flag === "progress" ? (q(e, t.who, "credits", -a), V(e, t.who, t.source, [
					L("damage", a),
					L("damage", a),
					...i.health <= 6 ? [L("retrieve", 1, {
						zone: "discard",
						maxLevel: 4
					})] : [],
					...i.health <= 2 ? [L("retrieve", 1, {
						zone: "deck",
						flag: "searchDeck"
					})] : []
				])) : r.flag === "blood" ? V(e, t.who, t.source, [L("damage", a), L("damage", a)]) : V(e, t.who, t.source, [L("damage", a)]);
			}, {
				category: "number",
				n: a,
				cost: a,
				params: { n: a },
				target: s
			});
			break;
		}
		case "faction":
			for (let t of oe) (!a || !W(e, a).includes(t)) && n(Xe[t], () => {
				c(), a && a.extraFactions.push(t);
			}, {
				category: "other",
				target: t
			});
			break;
		case "upgrade":
			Je(e, i, n, (n, i) => {
				c(), r.flag === "ifSelfTrigger" && n === t.source && V(e, t.who, n, [...T[i].play, ...T[i].exhaust ?? []], `upgrade/${i}/play`);
			}, r.flag === "self" ? 99 : o, r.flag === "self" ? t.source : void 0);
			break;
		case "draft":
		case "revealCores": {
			if (r.flag === "pickOne") return !1;
			let a = r.flag === "small" ? [Math.min(6, i.training)] : Array.from({ length: Math.min(r.maxLevel ?? (r.op === "revealCores" ? o : i.training), 6) }, (e, t) => t + 1);
			for (let i of a) e.coreDecks[i - 1].length && n("games.unstoppable.chooseLevel", () => {
				if (c(), r.op === "draft") {
					let n = e.coreDecks[i - 1].shift(), r = xe(e);
					r === void 0 ? U(e, "games.unstoppable.lossThreats") : Y(e, z(e, t.who, n, r), !0);
				} else B(e, {
					type: "draftPick",
					who: t.who,
					cores: e.coreDecks[i - 1].splice(0, 3),
					n: i,
					flag: "bonus"
				});
			}, {
				category: "draft",
				n: i,
				params: { n: i }
			});
			break;
		}
		case "bottom":
			if (r.flag === "drawThenBottom") {
				for (let r = 0; r <= o; r++) n("games.unstoppable.chooseAmount", () => {
					c(), B(e, {
						type: "effect",
						who: i.rid,
						source: t.source,
						effect: L("draw", r)
					}, {
						type: "effect",
						who: i.rid,
						source: t.source,
						effect: L("bottom", r, { flag: "mandatory" })
					});
				}, {
					category: "number",
					n: r,
					params: { n: r }
				});
				break;
			}
			if (r.flag === "drawSame") {
				let a = t.step ?? 0;
				return l(i.hand, (n) => {
					J(e, n, "deck"), t.step = a + 1, t.effect = {
						...r,
						n: o - 1
					}, o === 1 && (c(), B(e, {
						type: "effect",
						who: i.rid,
						source: t.source,
						effect: L("draw", a + 1)
					}));
				}, "games.unstoppable.putBottom"), n("games.unstoppable.continue", () => {
					c(), B(e, {
						type: "effect",
						who: i.rid,
						source: t.source,
						effect: L("draw", a)
					});
				}, { category: "end" }), !0;
			}
			if (o <= 0) return !1;
			l(i.hand, (n) => {
				c(), o > 1 && B(e, {
					...t,
					effect: {
						...r,
						n: o - 1
					}
				}), J(e, n, "deck");
			}, "games.unstoppable.putBottom");
			break;
		case "trade":
			if (r.flag === "swapPlay") l(i.play.filter((e) => e !== t.source), (n) => {
				c(), B(e, {
					type: "effect",
					who: t.who,
					source: t.source,
					effect: L("trade", 1, { flag: `swap:${n}` })
				});
			});
			else if (r.flag?.startsWith("swap:")) {
				let n = r.flag.slice(5);
				l(i.hand, (r) => {
					c(), J(e, n, "hand"), We(e, t.who, r, 0, !0);
				});
			} else if (r.flag?.startsWith("swapHand:")) {
				let n = r.flag.slice(9);
				l(i.play.filter((e) => e !== t.source), (t) => {
					c(), J(e, t, "hand"), J(e, n, "play");
				});
			} else l(i.hand, (n) => {
				c(), i.play.filter((e) => e !== t.source).length && B(e, {
					type: "effect",
					who: t.who,
					source: t.source,
					effect: L("trade", 1, { flag: `swapHand:${n}` })
				});
			});
			break;
		case "shuffleThreat":
			l(e.players.flatMap((e) => e.threats), (t) => {
				let n = I(e, e.cards[t].owner);
				c(), J(e, t, "deck"), r.flag === "swap" ? (n.deck = R(e, n.deck), B(e, {
					type: "refill",
					who: n.rid,
					n: 1,
					flag: "one"
				})) : (J(e, n.deck[0], "threats"), n.deck[0] && B(e, {
					type: "reveal",
					who: n.rid,
					source: n.deck[0]
				}));
			}, "games.unstoppable.putBottom");
			break;
		case "recycleMarket":
			if (r.flag === "entire") {
				n("games.unstoppable.cycleAllUpgrades", () => {
					c(), e.upgradeDeck.push(...e.market), e.market = [], ze(e);
				}, { category: "other" });
				break;
			}
			for (let t = 0; t < e.market.length; t++) n("games.unstoppable.cycleUpgrade", () => {
				let [n] = e.market.splice(t, 1);
				e.upgradeDeck.push(n), r.flag !== "all" && (c(), ze(e));
			}, {
				category: "other",
				upgrade: e.market[t]
			});
			if (r.flag === "all") return n("games.unstoppable.finishMarket", () => {
				c(), ze(e);
			}, { category: "end" }), !0;
			break;
		case "returnSelf":
			a && !i.removed.includes(a.iid) && n("games.unstoppable.takeCard", () => {
				c(), Y(e, a.iid);
			}, {
				category: "card",
				target: a.iid,
				card: a.core ?? void 0
			});
			break;
		case "swapResources":
			for (let r = -i.credits; r <= i.armor; r++) r !== 0 && i.armor - r <= 10 && n("games.unstoppable.exchangeResources", () => {
				c(), q(e, t.who, "armor", -r), q(e, t.who, "credits", r);
			}, {
				category: "number",
				n: r,
				params: { n: r }
			});
			break;
		default: return !1;
	}
	return r.flag !== "mandatory" && n("games.unstoppable.forfeit", () => He(e), { category: "end" }), !0;
}
var Xe = {
	silver: "games.unstoppable.silver",
	junker: "games.unstoppable.junker",
	viren: "games.unstoppable.viren",
	council: "games.unstoppable.council"
};
function Ze(t, n) {
	let r = n.effect, i = I(t, n.who), a = K(t, i, n.source, r.n), o = K(t, i, n.source, r.times), s = n.source ? t.cards[n.source] : void 0;
	switch (Ke(t, n), r.op) {
		case "credits":
		case "health":
		case "armor":
		case "actions":
			for (let e of r.all ? t.players : [i]) q(t, e.rid, r.op, a * o);
			break;
		case "train":
			Oe(t, i, a * o);
			break;
		case "draw":
			for (let e = 0; e < a; e++) B(t, {
				type: "reveal",
				who: i.rid,
				flag: r.flag === "bottom" ? "drawBottom" : "draw"
			});
			break;
		case "discount":
			r.flag === "bargain" ? i.bargainDiscount += a : i.upgradeDiscount += a;
			break;
		case "mark":
			r.flag === "bossDiscard" && s ? J(t, s.iid, "discard") : r.flag === "sourceCost0" && s ? s.flags.push("cost6") : r.flag === "improvise" ? R(t, i.hand).slice(0, 2).forEach((e) => t.cards[e].flags.push("cost1")) : i.flags.push(`${r.flag}:${a}`);
			break;
		case "repeat":
			s && s.core !== null && w[s.core].play.length && (V(t, i.rid, s.iid, w[s.core].play, "core/play/0"), t.tasks[0].flag = "echo");
			break;
		case "activateUpgrades":
			if (r.flag === "level3Core") {
				let e = t.coreDecks[2].shift();
				if (e !== void 0) {
					let n = z(t, i.rid, e, 90001), r = w[e];
					B(t, {
						type: "temporaryCoreEnd",
						who: i.rid,
						source: n,
						n: e
					}), V(t, i.rid, n, [...r.play, ...r.exhaust?.length === 1 ? r.exhaust[0] : r.exhaust?.length ? [{
						op: "choice",
						options: r.exhaust
					}] : []], "core/play/0");
				}
			} else s && s.upgrades.filter((e) => r.flag !== "tacticOnly" || T[e].kind === "tactic").forEach((e) => {
				let n = (e) => e.flatMap((e) => ["pay", "bargain"].includes(e.op) ? n(e.effects ?? []) : [{
					...e,
					...e.effects ? { effects: n(e.effects) } : {},
					...e.options ? { options: e.options.map(n) } : {}
				}]), a = [...T[e].play, ...T[e].exhaust ?? []];
				V(t, i.rid, s.iid, r.flag === "freePayments" ? n(a) : a, `upgrade/${e}/play`);
			});
			break;
		case "allDamage": {
			let e = r.flag === "includeDeck" ? Me(t) : t.players.flatMap((e) => e.threats), s = e.map((e) => L("damage", a, {
				times: o,
				ignoreTaunt: r.ignoreTaunt,
				flag: `fixed:${e}`
			}));
			s.length && B(t, {
				type: "group",
				who: i.rid,
				source: n.source,
				effects: s,
				keys: e,
				flag: "uncounted"
			});
			break;
		}
		case "retrieve": {
			let n = qe(t, i, r);
			n.length && Y(t, n[e(t.seed, t.rng++, n.length)]);
			break;
		}
		case "bottom":
			r.flag === "drawThenBottom" && B(t, {
				type: "effect",
				who: i.rid,
				source: n.source,
				effect: L("draw", a)
			}, {
				type: "effect",
				who: i.rid,
				source: n.source,
				effect: L("bottom", a, { flag: "mandatory" })
			});
			break;
		case "revealCores":
			if (r.flag === "pickOne") {
				let e = t.coreDecks.slice(0, 3).flatMap((e) => e.splice(0, 1));
				B(t, {
					type: "draftPick",
					who: i.rid,
					cores: e,
					flag: "bonusMixed"
				});
			}
			break;
		case "playTop": B(t, {
			type: "reveal",
			who: i.rid,
			flag: "playTop"
		});
	}
}
function Qe(e) {
	e.phase = "upkeep";
	for (let t of e.players) t.deck = R(e, [
		12800,
		...[
			,
			,
			,
			,
			,
			,
		].fill(12803),
		...ce[t.character]
	].map((n, r) => z(e, t.rid, n, r === 0 ? 9e4 : r < 7 ? 90001 : [
		90002,
		90003,
		90004
	][r - 7]))), t.hand = t.deck.splice(0, 3);
	e.tasks = [
		...e.players.flatMap((e) => [{
			type: "reveal",
			who: e.rid,
			source: e.deck[0]
		}, {
			type: "refill",
			who: e.rid
		}]),
		{
			type: "bossSetup",
			who: e.players[0].rid
		},
		{
			type: "phase",
			who: e.players[0].rid,
			flag: "upkeep"
		}
	];
}
function $e(e, t) {
	let n = I(e, t.who), r = t.step ?? 0;
	if (e.tasks.shift(), r === 0) {
		n.flags.push("leveling"), n.level += 1, n.training = Math.min(6, n.training + 1), e.victory && (n.victoryLevels += 1), H(e, "games.unstoppable.logLevel", n.rid, n.level), B(e, {
			...t,
			step: 1
		});
		for (let t of [...n.play]) J(e, t, "discard");
	} else if (r === 1) B(e, {
		...t,
		step: 2
	});
	else if (r === 2) B(e, {
		...t,
		step: 3
	});
	else if (r === 3) {
		if (e.config.boss !== "duomo" && e.bossDeck.length) {
			let t = e.bossDeck.shift();
			n.discard.push(z(e, n.rid, t, t));
		}
		B(e, {
			...t,
			step: 4
		});
	} else n.deck = R(e, n.discard), n.discard = [], n.deck.forEach((t) => {
		e.cards[t].damage = 0, e.cards[t].exhausted = !1;
	}), n.flags = n.flags.filter((e) => e !== "leveling" && e !== "emptyLeveled"), n.deck.length || n.flags.push("emptyLeveled"), n.deck[0] && B(e, {
		type: "reveal",
		who: n.rid,
		source: n.deck[0]
	});
}
function et(e, t) {
	let n = I(e, t.who);
	if (!(t.flag === "one" ? (t.n ?? 1) > 0 : n.threats.filter((t) => !X(e, e.cards[t]).keywords.includes("fast")).length < 3 || n.deck[0] && X(e, e.cards[n.deck[0]]).keywords.includes("fast"))) {
		e.tasks.shift();
		return;
	}
	if (!n.deck.length) {
		if (t.step !== 1 && (n.discard.length || n.play.length || n.hand.length > 3)) {
			t.step = 1, B(e, {
				type: "level",
				who: n.rid
			});
			return;
		}
		let r = xe(e);
		if (r === void 0) {
			U(e, "games.unstoppable.lossThreats");
			return;
		}
		n.deck.push(z(e, n.rid, null, r)), B(e, {
			type: "reveal",
			who: n.rid,
			source: n.deck[0]
		});
		return;
	}
	let r = n.deck[0];
	J(e, r, "threats"), t.step = 0, t.flag === "one" && (t.n = (t.n ?? 1) - 1), n.deck[0] && B(e, {
		type: "reveal",
		who: n.rid,
		source: n.deck[0]
	});
}
function tt(e, t) {
	let n = I(e, t.who);
	if (e.tasks.shift(), t.flag === "playTopCore") {
		let r = t.source, i = e.cards[r];
		if (!n.hand.includes(r) || i.core === null || w[i.core].kind === "boss") return;
		let a = Ie(e, i);
		B(e, {
			type: "effect",
			who: n.rid,
			source: r,
			effect: L("health", -Math.max(0, a), { flag: "mandatory" })
		}), i.flags.push("temporaryAlly"), We(e, n.rid, r, 0, !0);
		return;
	}
	if (t.flag === "draw" || t.flag === "drawBottom" || t.flag === "playTop") {
		if (!n.deck.length) {
			e.phase === "main" && !n.threats.length && !n.flags.includes("emptyLeveled") && B(e, {
				type: "level",
				who: n.rid
			}, t);
			return;
		}
		let r = t.flag === "drawBottom" ? n.deck[n.deck.length - 1] : n.deck[0], i = n.deck[0] === r ? n.deck[1] : void 0;
		t.flag === "playTop" && B(e, {
			type: "reveal",
			who: n.rid,
			source: r,
			flag: "playTopCore"
		}), B(e, {
			type: "check",
			who: n.rid
		}), i && B(e, {
			type: "reveal",
			who: n.rid,
			source: i
		}), Y(e, r);
		return;
	}
	if (!t.source || !Me(e).includes(t.source)) return;
	let r = e.cards[t.source], i = X(e, r);
	if (n.health <= 5) {
		let t = i.keywords.filter((e) => e === "crazed5").length * 2;
		t && (r.damage += t, H(e, "games.unstoppable.logCrazed", n.rid, t, r.threat), r.damage >= i.health && Pe(e, r.iid, n.rid));
	}
}
function nt(e, t) {
	if (e.tasks.shift(), t.flag === "upkeep") e.phase = "upkeep", e.players.forEach((t) => {
		t.ready = !1, t.play.forEach((t) => {
			e.cards[t].exhausted = !1;
		}), q(e, t.rid, "actions", 3);
	}), B(e, {
		type: "phase",
		who: e.players[0].rid,
		flag: "draft"
	}), be(e, "upkeep");
	else if (t.flag === "draft") e.phase = "draft", e.draftSets = [], B(e, ...e.players.map((e) => ({
		type: "draft",
		who: e.rid
	})), {
		type: "phase",
		who: e.players[0].rid,
		flag: "draftPick"
	});
	else if (t.flag === "draftPick") B(e, ...e.players.map((e) => ({
		type: "draftPick",
		who: e.rid
	})), {
		type: "phase",
		who: e.players[0].rid,
		flag: "draftBottom"
	});
	else if (t.flag === "draftBottom") B(e, ...e.draftSets.filter((e) => e.cards.length).map((e, t) => ({
		type: "draftBottom",
		who: e.who,
		group: t,
		cores: [...e.cards],
		n: e.level
	})), {
		type: "phase",
		who: e.players[0].rid,
		flag: "main"
	}), e.players.forEach((e) => {
		e.training = Math.min(6, e.level);
	});
	else if (t.flag === "main") e.phase = "main", e.draftSets = [];
	else if (t.flag === "threat") {
		e.phase = "threat";
		let t = [];
		for (let n of e.players) for (let r of n.threats) {
			let i = X(e, e.cards[r]).keywords.filter((e) => e === "rage").length;
			i && t.push({
				type: "rage",
				who: n.rid,
				n: i,
				source: r
			}), t.push({
				type: "attack",
				who: n.rid,
				source: r
			});
		}
		B(e, ...t, {
			type: "phase",
			who: e.players[0].rid,
			flag: "threatEnd"
		}), be(e, "threat");
	} else if (t.flag === "threatEnd") B(e, {
		type: "phase",
		who: e.players[0].rid,
		flag: "cleanup"
	}), be(e, "threatEnd");
	else if (t.flag === "cleanup") {
		e.phase = "cleanup";
		for (let t of [
			7,
			8,
			18
		]) e.storyDamage[t] = 0;
		B(e, {
			type: "phase",
			who: e.players[0].rid,
			flag: "refill"
		});
		for (let t of e.players) {
			q(e, t.rid, "credits", Ee(t, "endCredits"));
			for (let n of Object.values(e.cards)) n.owner === t.rid && n.flags.includes("temporaryAlly") && !t.removed.includes(n.iid) && !t.threats.includes(n.iid) && J(e, n.iid, "threats");
			for (let n of [...t.play]) w[e.cards[n].core].kind !== "ally" && J(e, n, "discard");
			t.actions = 0, t.armor = 0, t.ready = !1, t.flags = t.flags.filter((e) => e === "emptyLeveled"), t.bargainDiscount = 0, t.upgradeDiscount = 0;
		}
		for (let t of Object.values(e.cards)) t.extraFactions = [], t.flags = [];
		be(e, "cleanup");
	} else if (t.flag === "refill") B(e, ...e.players.map((e) => ({
		type: "refill",
		who: e.rid
	})), {
		type: "danger",
		who: e.players[0].rid
	});
	else if (t.flag === "next") {
		if (e.storyNext !== null) {
			let t = e.storyNext;
			e.story = e.story.filter((e) => e === 21 && [17, 19].includes(t)), e.storyResolved = [], e.storyNext = null, he(e, t);
		}
		e.turn++, e.uses = {}, e.locationUsed = [], B(e, {
			type: "phase",
			who: e.players[0].rid,
			flag: "upkeep"
		});
	}
}
function rt(e) {
	let t = e.tasks[0];
	if (!t || e.phase === "done") return;
	let n = I(e, t.who);
	switch (t.type) {
		case "effect":
			Te(e, t, t.effect) ? Ze(e, t) : He(e);
			break;
		case "group":
			e.tasks.shift();
			break;
		case "count": {
			e.tasks.shift();
			let r = `${t.source}/${t.effectId}`;
			e.uses[r] = (e.uses[r] ?? 0) + 1, e.uses[r] >= 4 && t.source && !I(e, e.cards[t.source].owner).removed.includes(t.source) && Ae(e, t.source) && (n.loops++, je(e, t.source));
			break;
		}
		case "check":
			e.tasks.shift(), e.phase === "main" && !n.deck.length && !n.threats.length && !n.flags.includes("leveling") && (!n.flags.includes("emptyLeveled") || n.play.length || n.discard.length || n.hand.length > 3) && B(e, {
				type: "level",
				who: n.rid
			});
			break;
		case "level":
			$e(e, t);
			break;
		case "refill":
			et(e, t);
			break;
		case "reveal":
			tt(e, t);
			break;
		case "phase":
			nt(e, t);
			break;
		case "bossSetup":
			if (e.tasks.shift(), e.config.boss !== "duomo") for (let t of e.players) {
				let n = e.config.boss === "harbinger" ? [e.bossDeck.splice(e.bossDeck.findIndex((e) => e < 1702), 1)[0], e.bossDeck.splice(e.bossDeck.findIndex((e) => e >= 1702), 1)[0]] : Array.from({ length: 2 }, () => e.bossDeck.splice(e.bossDeck.findIndex((e) => e === 1100 || e === 1103), 1)[0]);
				t.deck = R(e, [...t.deck, ...n.map((n) => z(e, t.rid, n, n))]), t.deck[0] && B(e, {
					type: "reveal",
					who: t.rid,
					source: t.deck[0]
				});
			}
			break;
		case "temporaryCoreEnd":
			e.tasks.shift(), e.coreDecks[2].push(t.n), t.source && (ke(e, t.source), delete e.cards[t.source]);
			break;
		case "rage":
			e.tasks.shift();
			break;
		case "attack":
			e.tasks.shift(), t.source && n.threats.includes(t.source) && De(e, n.rid, X(e, e.cards[t.source]).attack);
			break;
		case "danger": {
			e.tasks.shift();
			let t = le[e.config.boss];
			do
				e.danger++;
			while (t[e.danger]?.skip === e.config.difficulty);
			if (e.danger >= t.length - 1) {
				U(e, "games.unstoppable.lossDanger");
				break;
			}
			if (B(e, {
				type: "phase",
				who: n.rid,
				flag: "next"
			}), t[e.danger].effect === "market" && B(e, {
				type: "market",
				who: n.rid
			}), t[e.danger].effect === "eliminate") for (let t of [...e.players].reverse()) V(e, t.rid, void 0, [L("pay", 1, {
				resource: "credits",
				effects: [L("eliminate")],
				optional: !0
			})], "dangerEliminate");
			break;
		}
		case "story":
		case "storyPay":
		case "storyThreat":
			e.tasks.shift();
			break;
		case "draft":
		case "draftPick":
		case "draftBottom":
		case "market":
		case "end": e.tasks.shift();
	}
}
function it(e, t, n) {
	let r = I(e, t.who);
	if (t.type === "group") t.effects?.forEach((r, i) => {
		Te(e, t, r) && n("games.unstoppable.resolveEffect", () => Ge(e, t, i), {
			category: "effect",
			n: i,
			target: `effect:${i}`,
			params: {
				n: i + 1,
				effectKey: t.keys?.[i] ?? ""
			},
			effects: [r],
			...t.keys?.[i]?.startsWith("upgrade/") ? { upgrade: Number(t.keys[i].split("/")[1]) } : {}
		});
	}), t.effects?.some((n) => Te(e, t, n)) && n("games.unstoppable.forfeitRemaining", () => {
		e.tasks.shift();
	}, { category: "end" });
	else if (t.type === "effect") Te(e, t, t.effect) && Ye(e, t, n);
	else if (t.type === "level") {
		if (t.step === 1 && r.hand.length > 3) for (let t of r.hand) n("games.unstoppable.discardToThree", () => J(e, t, "discard"), {
			category: "card",
			target: t,
			card: e.cards[t].core ?? void 0,
			n: r.hand.length - 3
		});
		else if (t.step === 2) {
			for (let i of [...r.hand, ...r.discard].filter((t) => Ae(e, t))) n("games.unstoppable.eliminateCard", () => {
				e.tasks.shift(), B(e, {
					...t,
					step: 3
				}), je(e, i);
			}, {
				category: "card",
				target: i,
				card: e.cards[i].core ?? void 0
			});
			n("games.unstoppable.keepAll", () => {
				e.tasks.shift(), B(e, {
					...t,
					step: 3
				});
			}, { category: "end" });
		}
	} else if (t.type === "draft") {
		for (let t = 1; t <= Math.min(6, r.training); t++) e.coreDecks[t - 1].length && n("games.unstoppable.chooseLevel", () => {
			e.tasks.shift();
			let n = e.coreDecks[t - 1].splice(0, e.players.length === 1 ? 3 : 2);
			e.draftSets.push({
				who: r.rid,
				level: t,
				cards: n,
				picked: !1
			});
		}, {
			category: "draft",
			n: t,
			params: { n: t }
		});
		e.coreDecks.some((e, t) => t < r.training && e.length) || n("games.unstoppable.continue", () => {
			e.tasks.shift();
		}, { category: "end" });
	} else if (t.type === "draftPick") {
		if (t.flag === "bonus" || t.flag === "bonusMixed") for (let i of t.cores ?? []) n("games.unstoppable.keepCard", () => {
			e.tasks.shift();
			let n = xe(e);
			if (n === void 0 ? U(e, "games.unstoppable.lossThreats") : Y(e, z(e, r.rid, i, n), !0), t.flag === "bonusMixed") for (let n of t.cores.filter((e) => e !== i)) e.coreDecks[w[n].level - 1].push(n);
			else B(e, {
				type: "draftBottom",
				who: r.rid,
				cores: t.cores.filter((e) => e !== i),
				n: t.n
			});
		}, {
			category: "draft",
			card: i
		});
		else for (let t of e.draftSets.filter((e) => !e.picked)) for (let i of t.cards) n("games.unstoppable.keepCard", () => {
			e.tasks.shift(), t.picked = !0, t.cards.splice(t.cards.indexOf(i), 1);
			let n = xe(e);
			n === void 0 ? U(e, "games.unstoppable.lossThreats") : Y(e, z(e, r.rid, i, n), !0);
		}, {
			category: "draft",
			card: i,
			target: t.who
		});
	} else if (t.type === "draftBottom") for (let r = 0; r < (t.cores?.length ?? 0); r++) n("games.unstoppable.returnCoreBottom", () => {
		e.coreDecks[t.n - 1].push(t.cores.splice(r, 1)[0]), t.cores.length || e.tasks.shift();
	}, {
		category: "draft",
		card: t.cores[r]
	});
	else if (t.type === "rage") for (let i of r.play.filter((t) => w[e.cards[t].core].kind === "ally")) n("games.unstoppable.rageDiscard", () => {
		t.n = (t.n ?? 1) - 1, t.n <= 0 && e.tasks.shift(), J(e, i, "discard");
	}, {
		category: "card",
		target: i,
		card: e.cards[i].core
	});
	else if (t.type === "market") {
		for (let r = 0; r < e.market.length; r++) n("games.unstoppable.cycleUpgrade", () => {
			e.upgradeDeck.push(e.market.splice(r, 1)[0]), t.step = (t.step ?? 0) + 1;
		}, {
			category: "other",
			upgrade: e.market[r]
		});
		n("games.unstoppable.finishMarket", () => {
			e.tasks.shift(), ze(e);
		}, { category: "end" });
	} else if (t.type === "reveal" && t.flag?.startsWith("redirect/")) {
		let i = t.flag.slice(9), a = t.source;
		n("games.unstoppable.takeDefeated", () => {
			let n = r.deck[0] === a ? r.deck[1] : void 0;
			e.tasks.shift(), V(e, i, a, t.effects ?? [], "reward"), B(e, {
				type: "check",
				who: r.rid
			}), n && B(e, {
				type: "reveal",
				who: r.rid,
				source: n
			}), Y(e, a);
		}, {
			category: "card",
			target: a,
			card: e.cards[a].core
		}), n("games.unstoppable.redirectDefeated", () => {
			e.tasks.shift(), J(e, a, "deck"), V(e, i, a, t.effects ?? [], "reward"), V(e, r.rid, void 0, [L("draw", 2)], "redirect");
		}, { category: "other" });
	} else (t.type === "storyPay" || t.type === "storyThreat" || t.type === "story") && ye(e, t.who, n, t);
}
function at(e, t, n) {
	if (t.ready) {
		n("games.unstoppable.resumeMain", () => {
			t.ready = !1;
		}, { category: "end" });
		return;
	}
	for (let r of t.hand) {
		let i = e.cards[r], a = w[i.core];
		if (a.kind === "boss" || a.passive?.includes("trainRequired") && !t.flags.includes("trained")) continue;
		let o = Ie(e, i);
		for (let a of o < 0 ? Array.from({ length: t.actions + 1 }, (e, t) => t) : [o]) a <= t.actions && n("games.unstoppable.playCard", () => We(e, t.rid, r, a), {
			category: "play",
			target: r,
			card: i.core,
			cost: a
		});
	}
	for (let r of t.play) {
		let i = e.cards[r], a = w[i.core];
		i.exhausted || a.exhaust?.forEach((o, s) => n("games.unstoppable.exhaustAlly", () => {
			i.exhausted = !0, t.ready = !1, Ue(e, t.rid, r, "exhaust", s);
		}, {
			category: "exhaust",
			target: r,
			card: i.core,
			n: s,
			effects: a.exhaust?.[s]
		})), a.passive?.includes("chooseFaction") && !i.flags.includes("factionUsed") && n("games.unstoppable.chooseFaction", () => {
			i.flags.push("factionUsed"), V(e, t.rid, r, [L("faction")], "chiefFaction");
		}, {
			category: "other",
			target: r,
			card: i.core
		});
	}
	if (Je(e, t, n), Ee(t, "swapResources") && n("games.unstoppable.exchangeResources", () => B(e, {
		type: "effect",
		who: t.rid,
		effect: L("swapResources")
	}), {
		category: "other",
		target: "swapResources"
	}), e.config.boss === "triumvirate") for (let r = 0; r < 3; r++) {
		let i = `${t.rid}/${r}`;
		e.locations[r] >= [
			4,
			3,
			5
		][r] * e.players.length && !e.locationUsed.includes(i) && t.actions >= (r === 1 ? 2 : 1) && (r !== 2 || t.credits >= 2) && n("games.unstoppable.locationAction", () => {
			e.locationUsed.push(i), q(e, t.rid, "actions", -(r === 1 ? 2 : 1)), r === 2 && q(e, t.rid, "credits", -2), V(e, t.rid, void 0, r === 0 ? [L("train"), L("health")] : r === 1 ? [L("eliminate")] : [L("bossDamage")], `location/${r}`);
		}, {
			category: "story",
			target: `location:${r}`,
			n: r,
			cost: r === 1 ? 2 : 1
		});
	}
	e.config.boss === "duomo" && ye(e, t.rid, n), t.ready ? n("games.unstoppable.resumeMain", () => {
		t.ready = !1;
	}, { category: "end" }) : n(e.victory ? "games.unstoppable.finishVictory" : "games.unstoppable.finishMain", () => {
		t.ready = !0, e.players.every((e) => e.ready) && (e.victory ? (e.phase = "done", e.reason = "games.unstoppable.victory") : B(e, {
			type: "phase",
			who: e.players[0].rid,
			flag: "threat"
		}));
	}, { category: "end" });
}
function ot(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || e.phase === "done") return [];
	let r = [], i = e.tasks[0], a = i?.source ? e.cards[i.source] : void 0, o = a && !I(e, a.owner).deck.includes(a.iid) && !I(e, a.owner).threats.includes(a.iid), s = (t, n, s = {}) => r.push({
		view: {
			id: `${e.serial}:${r.length}`,
			key: t,
			category: "other",
			...s,
			params: {
				...o ? {
					source: a.iid,
					effectKey: i?.effectId ?? ""
				} : {},
				...s.params
			}
		},
		run: n
	});
	if (e.phase === "character") {
		if (!n.character) for (let t of se) (e.config.expansion || !["roux", "sima"].includes(t)) && !e.players.some((e) => e.character === t) && s(st[t], () => {
			n.character = t, e.players.every((e) => e.character) && Qe(e);
		}, {
			category: "character",
			target: t
		});
	} else e.tasks.length ? e.tasks[0].who === t && it(e, e.tasks[0], s) : e.phase === "main" && at(e, n, s);
	return r;
}
var st = {
	kai: "games.unstoppable.kai",
	zephyr: "games.unstoppable.zephyr",
	tiberius: "games.unstoppable.tiberius",
	julida: "games.unstoppable.julida",
	roux: "games.unstoppable.roux",
	sima: "games.unstoppable.sima"
};
function ct(e, t, n) {
	let r = j.parse(e), i = {
		config: r,
		players: t.slice(0, 2).map((e) => ({
			rid: e,
			character: "",
			health: 10,
			armor: 0,
			credits: 3,
			actions: 0,
			level: 1,
			training: 1,
			deck: [],
			hand: [],
			play: [],
			discard: [],
			threats: [],
			removed: [],
			ready: !1,
			bargainDiscount: 0,
			upgradeDiscount: 0,
			flags: [],
			loops: 0,
			victoryLevels: 0
		})),
		cards: {},
		coreDecks: [],
		threatDeck: [],
		unusedThreats: {},
		upgradeDeck: [],
		market: [],
		bossDeck: [],
		bossDamage: 0,
		locations: [
			0,
			0,
			0
		],
		locationUsed: [],
		story: r.boss === "duomo" ? [0] : [],
		storyDamage: {},
		storyCredits: {},
		storyNext: null,
		storyResolved: [],
		ending: null,
		phase: "character",
		turn: 1,
		danger: 0,
		seed: n,
		rng: 0,
		serial: 0,
		nextId: 1,
		tasks: [],
		draftSets: [],
		uses: {},
		victory: !1,
		reason: null,
		log: []
	};
	return i.coreDecks = ie.map((e) => R(i, e.filter((e) => r.expansion || !w[e].expansion))), i.upgradeDeck = R(i, ae.filter((e) => r.expansion || !T[e].expansion)), ze(i), i.threatDeck = R(i, [...D.ceres, ...r.boss === "duomo" ? [] : D[r.boss === "harbinger" ? "virenos" : "mithras"]]), i.unusedThreats = Object.fromEntries(Object.entries(D).filter(([e]) => e !== "ceres" && (r.boss === "duomo" || e === (r.boss === "harbinger" ? "mithras" : "virenos"))).map(([e, t]) => [e, [...t]])), i.bossDeck = r.boss === "harbinger" ? R(i, [
		1700,
		1700,
		1701,
		1701,
		1701,
		1702,
		1702,
		1702,
		1703,
		1703
	]) : r.boss === "triumvirate" ? R(i, [
		1100,
		1100,
		1103,
		1103,
		1101,
		1101,
		1101,
		1102,
		1102,
		1102
	]) : Array.from({ length: 22 }, (e, t) => t + 1), { state: i };
}
function lt(e, t, n, r, i) {
	let a = e.players.find((e) => e.threats.includes(n) || e.deck[0] === n), o = e.cards[n], s = a?.deck[0] === n ? "deck" : a ? String(a.threats.indexOf(n)) : "";
	return {
		kind: "unstCombat",
		rid: t.who,
		data: {
			source: t.source ?? "",
			effectKey: t.effectId ?? "",
			target: n,
			n: r,
			kind: i,
			owner: a?.rid ?? t.who,
			slot: s,
			...a && o ? { threat: yt(e, n, a.deck[0] === n) } : {}
		}
	};
}
function ut(e, t, n, r = 0, i = "") {
	return {
		kind: "unstCue",
		rid: e,
		data: {
			target: t,
			cue: n,
			n: r,
			source: i
		}
	};
}
function dt(e, t, n, r, i) {
	return {
		kind: "unstMove",
		rid: e,
		data: {
			from: t,
			to: n,
			cue: r,
			...i ? { threat: i } : {}
		}
	};
}
function ft(e, t, n, r, i) {
	let a = [], o = I(e, n?.who ?? i), s = I(t, o.rid), c = n?.source ?? (r?.target && e.cards[r.target] ? r.target : ""), l = c ? `card:${c}` : `seat:${o.rid}`, u = (e, t = l, n = 0) => a.push(ut(o.rid, t, e, n, c)), d = n?.type === "effect" ? n.effect?.op : void 0, f = r?.target ? e.cards[r.target] : void 0, p = !r && n?.type === "effect" && n.effect && Te(e, n, n.effect);
	for (let r of e.players) {
		let e = I(t, r.rid), i = [
			"health",
			"armor",
			"actions",
			"credits",
			"training",
			"level"
		].flatMap((t) => e[t] === r[t] ? [] : [{
			key: t,
			n: e[t] - r[t]
		}]);
		i.length && a.push({
			kind: "unstResource",
			rid: r.rid,
			data: {
				changes: i,
				source: c,
				effectKey: n?.effectId ?? ""
			}
		});
	}
	if (!r && n) {
		if (p && (d === "repeat" && t.tasks[0]?.flag === "echo" && a.push(lt(e, n, c, 0, "echo")), d === "activateUpgrades" && t.tasks[0]?.type === "group" && u("activate"), d === "allDamage" && t.tasks[0]?.type === "group" && u("attack"), d === "discount" && (s.bargainDiscount !== o.bargainDiscount || s.upgradeDiscount !== o.upgradeDiscount) && u("discount", l, K(e, o, c, n.effect.n)), d === "mark" && (s.flags.length !== o.flags.length || c && t.cards[c]?.flags.length !== e.cards[c]?.flags.length || n.effect?.flag === "improvise" && o.hand.length) && u("mark"), d === "mark" && n.effect?.flag === "bossDiscard" && c && s.discard.includes(c) && !o.discard.includes(c) && a.push(dt(o.rid, l, `supply:${o.rid}`, "discard")), d === "revealCores" && t.tasks[0]?.type === "draftPick" && u("reveal", `seat:${o.rid}`), d === "train" && s.training === o.training && K(e, o, c, n.effect.n) * K(e, o, c, n.effect.times) > 0 && u("limit", `resource:${o.rid}:training`), d && [
			"health",
			"armor",
			"actions"
		].includes(d))) for (let r of n.effect.all ? e.players : [o]) {
			let i = d;
			K(e, o, c, n.effect.n) * K(e, o, c, n.effect.times) > 0 && r[i] === I(t, r.rid)[i] && a.push(ut(r.rid, `resource:${r.rid}:${i}`, "limit"));
		}
		if (n.type === "attack" && c && o.threats.includes(c) && a.push({
			kind: "unstCombat",
			rid: o.rid,
			data: {
				source: c,
				sourceAnchor: `threat:${c}`,
				effectKey: "",
				target: `seat:${o.rid}`,
				n: X(e, e.cards[c]).attack,
				kind: "hostile",
				owner: o.rid,
				slot: ""
			}
		}), n.type === "refill" && o.deck[0] && s.threats.includes(o.deck[0])) {
			let e = o.deck[0];
			a.push(dt(o.rid, `threat-slot:${o.rid}:deck`, `threat:${e}`, "refill", yt(t, e, !1)));
		}
		if (n.type === "reveal" && n.source && Me(e).includes(n.source) && !n.flag) {
			let r = t.cards[n.source].damage - e.cards[n.source].damage;
			r > 0 ? a.push(lt(e, n, n.source, r, "attack")) : u("reveal", `threat:${n.source}`);
		}
		if (n.type === "reveal" && n.flag === "playTopCore" && c && s.play.includes(c) && a.push(lt(t, n, c, 0, "play")), n.type === "level" && ((n.step ?? 0) === 0 && o.play.length && u("discard", `supply:${o.rid}`, o.play.length), n.step === 3 && s.discard.length > o.discard.length && u("bossCard", `supply:${o.rid}`), (n.step ?? 0) >= 4 && u("shuffle", `supply:${o.rid}`)), n.type === "bossSetup") for (let t of e.players) a.push(ut(t.rid, `supply:${t.rid}`, "shuffle"));
		if (n.type === "count" && c && !o.removed.includes(c) && s.removed.includes(c) && u("remove"), n.type === "danger" && t.danger !== e.danger && u("danger", "danger"), n.type === "phase") {
			if (n.flag === "cleanup") for (let t of e.players) (t.play.length || t.flags.length) && a.push(ut(t.rid, `seat:${t.rid}`, "cleanup"));
			if (n.flag === "upkeep") for (let t of e.players) t.play.some((t) => e.cards[t].exhausted) && a.push(ut(t.rid, `seat:${t.rid}`, "ready"));
			n.flag === "next" && e.storyNext !== null && u("story", "boss");
		}
	}
	if (r) {
		if ((r.category === "play" || r.category === "exhaust" || r.category === "buy") && r.target && a.push(lt(t, {
			type: "effect",
			who: i,
			source: r.target,
			...r.upgrade ? { effectId: `upgrade/${r.upgrade}` } : {}
		}, r.target, 0, r.category === "buy" ? "upgrade" : "play")), f && r.category === "card") {
			let r = `card:${f.iid}`, i = I(e, f.owner), o = I(t, f.owner);
			d === "refresh" ? u("ready", r) : d === "disableKeywords" ? u("disable", `threat:${f.iid}`) : o.removed.includes(f.iid) && !i.removed.includes(f.iid) ? u("remove", r) : o.discard.includes(f.iid) && !i.discard.includes(f.iid) ? a.push(dt(i.rid, r, `supply:${i.rid}`, "discard")) : o.deck.includes(f.iid) && !i.deck.includes(f.iid) ? a.push(dt(i.rid, r, `supply:${i.rid}`, "bottom")) : (d === "destroy" || d === "defeat") && u("defeat", `seat:${f.owner}`), d === "trade" && o.play.includes(f.iid) && !i.play.includes(f.iid) && u("activate", `card:${f.iid}`), d === "shuffleThreat" && (n?.effect?.flag === "swap" ? u("shuffle", `supply:${f.owner}`) : i.deck[0] && o.threats.includes(i.deck[0]) && a.push(dt(i.rid, `threat-slot:${i.rid}:deck`, `threat:${i.deck[0]}`, "refill", yt(t, i.deck[0], !1))));
		}
		d === "faction" && u("faction"), (d === "recycleMarket" || n?.type === "market") && u("market", "market"), (r.category === "story" || n?.type === "story" || n?.type === "storyPay") && u("story", r.target?.startsWith("story:") ? r.target : "boss"), r.category === "draft" && n?.type === "draftBottom" ? u("bottom", `seat:${o.rid}`) : r.category === "draft" && n?.type !== "draftPick" && d !== "draft" && u("reveal", `seat:${o.rid}`);
	}
	if (n?.type === "reveal" && [
		"draw",
		"drawBottom",
		"playTop"
	].includes(n.flag ?? "") || d === "retrieve" || d === "returnSelf" || d === "draft" || d === "trade" || r?.category === "draft" && n?.type === "draftPick" || r?.key === "games.unstoppable.takeDefeated") for (let e of s.hand.filter((e) => !o.hand.includes(e))) {
		let t = o.discard.includes(e) || o.deck.includes(e) ? `supply:${o.rid}` : `seat:${o.rid}`;
		a.push(dt(o.rid, t, `hand:${o.rid}`, "draw"));
	}
	return n?.type === "reveal" && [
		"draw",
		"drawBottom",
		"playTop"
	].includes(n.flag ?? "") && s.discard.length > o.discard.length && u("bossCard", `supply:${o.rid}`), a;
}
function pt(e, t, n, r, i, a = []) {
	return a.push(...ft(e, t, n, r, i)), a.forEach((e, t) => {
		t && (e.with = !0);
	}), t.beatMs = a.length ? Math.max(...a.map(F)) : 0, {
		state: t,
		...a.length ? { fx: a } : {}
	};
}
function mt(e, t, n) {
	if (e.phase === "done") return { code: "games.unstoppable.errFinished" };
	if (t.type === "tick") {
		if (!e.tasks.length || e.players.some((t) => ot(e, t.rid).length)) return { state: e };
		let t = structuredClone(e), n = e.tasks[0];
		return rt(t), t.serial++, pt(e, t, n, void 0, n.who);
	}
	let r = structuredClone(e), i = ot(r, n.by).find((e) => e.view.id === t.id);
	if (!i) return { code: "games.unstoppable.errChoice" };
	let a = e.tasks[0], o = i.view, s = [];
	if (a?.type === "effect" && o.category === "target" && o.target && [
		"damage",
		"splitDamage",
		"bossDamage"
	].includes(a.effect.op)) {
		let t = a.flag === "echo" ? "echo" : /^upgrade\/(15005|12202)\//.test(a.effectId ?? "") ? "capacitor" : "attack";
		s.push(lt(e, a, o.target, o.n ?? K(e, I(e, a.who), a.source, a.effect.n), t));
	}
	return i.run(), r.serial++, s[0] && o.target && e.cards[o.target] && !Me(r).includes(o.target) && (s[0].data = {
		...s[0].data,
		defeated: !0
	}), pt(e, r, a, o, n.by, s);
}
function ht(e) {
	return le[e.config.boss].slice(e.danger + 1, -1).filter((t) => t.skip !== e.config.difficulty).length;
}
function gt(e, t) {
	return Object.values(_t(e, t)).reduce((e, t) => e + t, 0);
}
function _t(e, t) {
	if (!e.victory) return {
		base: 0,
		rounds: 0,
		health: 0,
		loops: 0,
		transhumanist: 0,
		retire: 0,
		coalition: 0,
		unstoppable: 0
	};
	let n = [
		...t.deck,
		...t.hand,
		...t.play,
		...t.discard,
		...t.threats
	], r = n.filter((t) => e.cards[t].core !== null && w[e.cards[t].core].level > 0).every((t) => e.cards[t].upgrades.length), i = oe.every((t) => n.filter((n) => e.cards[n].core !== null && w[e.cards[n].core].faction === t).length >= 2);
	return {
		base: {
			normal: 100,
			hard: 200,
			expert: 300
		}[e.config.difficulty],
		rounds: ht(e) * 10,
		health: t.health,
		loops: t.loops * 10,
		transhumanist: r ? 10 : 0,
		retire: t.credits >= 15 ? 10 : 0,
		coalition: i ? 10 : 0,
		unstoppable: t.victoryLevels >= 2 ? 50 : 0
	};
}
function vt(e, t) {
	let n = e.cards[t];
	return {
		iid: t,
		core: n.core,
		upgrades: n.upgrades,
		exhausted: n.exhausted,
		cost: Ie(e, n),
		factions: W(e, n)
	};
}
function yt(e, t, n) {
	let r = e.cards[t], i = X(e, r);
	return {
		iid: t,
		owner: r.owner,
		threat: r.threat,
		attack: i.attack,
		health: i.health,
		keywords: i.keywords,
		damage: r.damage,
		upgrades: r.upgrades,
		onDeck: n,
		disabled: r.flags.includes("disabled")
	};
}
function bt(e, t) {
	let n = e.tasks[0], r = n?.source ? e.cards[n.source] : void 0, i = r && !I(e, r.owner).deck.includes(r.iid) && !I(e, r.owner).threats.includes(r.iid) ? r : void 0;
	return {
		public: {
			config: e.config,
			phase: e.phase,
			turn: e.turn,
			danger: e.danger,
			dangerLevel: Ce(e),
			roundsLeft: ht(e),
			bossDamage: e.bossDamage,
			bossHealth: (e.config.boss === "harbinger" ? 12 : 5) * e.players.length,
			locations: e.locations,
			story: e.story,
			storyDamage: e.storyDamage,
			storyCredits: e.storyCredits,
			storyNext: e.storyNext,
			storyResolved: e.storyResolved,
			ending: e.ending,
			market: e.market,
			upgradeCount: e.upgradeDeck.length,
			coreCounts: e.coreDecks.map((e) => e.length),
			threatCount: e.threatDeck.length,
			draftSets: e.draftSets,
			players: e.players.map((t) => ({
				rid: t.rid,
				character: t.character,
				health: t.health,
				armor: t.armor,
				credits: t.credits,
				actions: t.actions,
				level: t.level,
				training: t.training,
				handCount: t.hand.length,
				deckCount: t.deck.length,
				play: t.play.map((t) => vt(e, t)),
				discard: t.discard.map((t) => vt(e, t)),
				threats: [...t.threats.map((t) => yt(e, t, !1)), ...t.deck.slice(0, 1).map((t) => yt(e, t, !0))],
				ready: t.ready,
				loops: t.loops,
				victoryLevels: t.victoryLevels,
				ownedUpgrades: we(t).reduce((t, n) => t + e.cards[n].upgrades.length, 0)
			})),
			waiting: n?.who ?? null,
			prompt: e.phase === "character" ? "games.unstoppable.characterPrompt" : n ? xt[n.type] : "games.unstoppable.mainPrompt",
			source: i?.core ?? null,
			victory: e.victory,
			reason: e.reason,
			scores: Object.fromEntries(e.players.map((t) => [t.rid, gt(e, t)])),
			scoreParts: Object.fromEntries(e.players.map((t) => [t.rid, _t(e, t)])),
			log: e.log
		},
		private: {
			hand: (e.players.find((e) => e.rid === t)?.hand ?? []).map((t) => vt(e, t)),
			choices: ot(e, t).map((e) => e.view),
			source: i && i.owner === t ? vt(e, i.iid) : null,
			effect: n?.who === t && n.type === "effect" ? n.effect ?? null : null
		}
	};
}
var xt = {
	group: "games.unstoppable.effectPrompt",
	effect: "games.unstoppable.targetPrompt",
	count: "games.unstoppable.resolving",
	check: "games.unstoppable.resolving",
	level: "games.unstoppable.levelPrompt",
	refill: "games.unstoppable.refilling",
	reveal: "games.unstoppable.resolving",
	phase: "games.unstoppable.resolving",
	draft: "games.unstoppable.draftLevelPrompt",
	draftPick: "games.unstoppable.draftPickPrompt",
	draftBottom: "games.unstoppable.draftBottomPrompt",
	rage: "games.unstoppable.ragePrompt",
	attack: "games.unstoppable.threatPrompt",
	danger: "games.unstoppable.resolving",
	market: "games.unstoppable.marketPrompt",
	story: "games.unstoppable.storyPrompt",
	storyPay: "games.unstoppable.storyPayPrompt",
	storyThreat: "games.unstoppable.storyPrompt",
	end: "games.unstoppable.resolving",
	bossSetup: "games.unstoppable.resolving",
	temporaryCoreEnd: "games.unstoppable.resolving"
}, St = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: O,
	schemas: {
		action: ue,
		config: j,
		publicView: pe,
		privateView: me
	},
	setup: ct,
	reduce: mt,
	viewFor: bt,
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.victory ? e.players.map((e) => e.rid) : [],
			ranking: e.players.map((e) => e.rid),
			scores: Object.fromEntries(e.players.map((t) => [t.rid, gt(e, t)]))
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return e.phase !== "done" && e.tasks.length && !e.players.some((t) => ot(e, t.rid).length) ? e.beatMs ?? 0 : null;
	}
}, Ct = {
	silver: "games.unstoppable.silver",
	junker: "games.unstoppable.junker",
	viren: "games.unstoppable.viren",
	council: "games.unstoppable.council"
}, wt = {
	kai: "games.unstoppable.kai",
	zephyr: "games.unstoppable.zephyr",
	tiberius: "games.unstoppable.tiberius",
	julida: "games.unstoppable.julida",
	roux: "games.unstoppable.roux",
	sima: "games.unstoppable.sima"
}, Tt = {
	harbinger: "games.unstoppable.harbinger",
	triumvirate: "games.unstoppable.triumvirate",
	duomo: "games.unstoppable.duomo"
}, Et = [
	"games.unstoppable.location0",
	"games.unstoppable.location1",
	"games.unstoppable.location2"
], Dt = {
	fast: "games.unstoppable.fast",
	taunt: "games.unstoppable.taunt",
	rage: "games.unstoppable.rage",
	terror: "games.unstoppable.terror",
	crazed5: "games.unstoppable.crazed5"
}, Ot = {
	health: "games.unstoppable.health",
	armor: "games.unstoppable.armor",
	credits: "games.unstoppable.credits",
	actions: "games.unstoppable.actions"
}, kt = {
	focus: "games.unstoppable.value.focus",
	unite: "games.unstoppable.value.unite",
	upgrades: "games.unstoppable.value.upgrades",
	sourceUpgrades: "games.unstoppable.value.sourceUpgrades",
	missingHealth: "games.unstoppable.value.missingHealth",
	health: "games.unstoppable.value.health",
	armor: "games.unstoppable.value.armor",
	actions: "games.unstoppable.value.actions",
	credits: "games.unstoppable.value.credits",
	silverDiscard: "games.unstoppable.value.silverDiscard",
	tacticsDiscard: "games.unstoppable.value.tacticsDiscard",
	active: "games.unstoppable.value.active",
	wounded: "games.unstoppable.value.wounded",
	level: "games.unstoppable.value.level",
	danger: "games.unstoppable.value.danger"
}, At = {
	upgradedConspire: "games.unstoppable.when.upgradedConspire",
	unite4: "games.unstoppable.when.unite4",
	upgradedUnite3: "games.unstoppable.when.upgradedUnite3",
	conspire: "games.unstoppable.when.conspire",
	upgraded: "games.unstoppable.when.upgraded",
	health7: "games.unstoppable.when.health7",
	health5: "games.unstoppable.when.health5",
	armor5: "games.unstoppable.when.armor5",
	upgrades2: "games.unstoppable.when.upgrades2",
	upgrades4: "games.unstoppable.when.upgrades4",
	unite3: "games.unstoppable.when.unite3",
	active3: "games.unstoppable.when.active3",
	killed: "games.unstoppable.when.killed",
	firstPlay: "games.unstoppable.when.firstPlay",
	kills2: "games.unstoppable.when.kills2"
}, jt = {
	trainRequired: "games.unstoppable.passives.trainRequired",
	upgradeBuyDamage2Health1: "games.unstoppable.passives.upgradeBuyDamage2Health1",
	killActions1: "games.unstoppable.passives.killActions1",
	alliesActions1Damage3: "games.unstoppable.passives.alliesActions1Damage3",
	otherPlayDamage1: "games.unstoppable.passives.otherPlayDamage1",
	allyTacticUpgrades: "games.unstoppable.passives.allyTacticUpgrades",
	anyFaction: "games.unstoppable.passives.anyFaction",
	uniteCostReduction: "games.unstoppable.passives.uniteCostReduction",
	killCredits1: "games.unstoppable.passives.killCredits1",
	chooseFaction: "games.unstoppable.passives.chooseFaction",
	redirectKills: "games.unstoppable.passives.redirectKills",
	actionDamage2: "games.unstoppable.passives.actionDamage2",
	doubleExhaust: "games.unstoppable.passives.doubleExhaust",
	trainDamage2: "games.unstoppable.passives.trainDamage2",
	blockedCredits: "games.unstoppable.passives.blockedCredits",
	bossProtected: "games.unstoppable.passives.bossProtected"
}, Mt = {
	equalLevel: "games.unstoppable.special.equalLevel",
	blood: "games.unstoppable.special.blood",
	progress: "games.unstoppable.special.progress",
	sibling: "games.unstoppable.special.sibling",
	armor: "games.unstoppable.special.armor",
	selfDraft: "games.unstoppable.special.selfDraft",
	small: "games.unstoppable.special.small",
	level3Core: "games.unstoppable.special.level3Core",
	bottomThenReveal: "games.unstoppable.special.bottomThenReveal",
	drawSame: "games.unstoppable.special.drawSame",
	drawThenBottom: "games.unstoppable.special.drawThenBottom",
	improvise: "games.unstoppable.special.improvise",
	playedDamage: "games.unstoppable.special.playedDamage",
	playedCost: "games.unstoppable.special.playedCost",
	bargainDamage: "games.unstoppable.special.bargainDamage",
	endCredits: "games.unstoppable.special.endCredits",
	tacticUpgradeDamage: "games.unstoppable.special.tacticUpgradeDamage",
	discardHand: "games.unstoppable.special.discardHand",
	embrace: "games.unstoppable.special.embrace",
	allyFromDeck: "games.unstoppable.special.allyFromDeck",
	tacticOnly: "games.unstoppable.special.tacticOnly",
	freePayments: "games.unstoppable.special.freePayments",
	swapResources: "games.unstoppable.special.swapResources"
}, Nt = {
	onDeckDraw: "games.unstoppable.special.onDeckDraw",
	overkillCredits: "games.unstoppable.special.overkillCredits",
	reduceCostOnKill: "games.unstoppable.special.reduceCostOnKill",
	extraActiveCost2: "games.unstoppable.special.extraActiveCost2",
	includeDeck: "games.unstoppable.special.includeDeck",
	random: "games.unstoppable.special.random",
	self: "games.unstoppable.special.self",
	other: "games.unstoppable.special.other",
	wounded: "games.unstoppable.special.wounded",
	hasJunker: "games.unstoppable.special.hasJunker",
	hasSilver: "games.unstoppable.special.hasSilver",
	hasViren: "games.unstoppable.special.hasViren",
	ifSelfTrigger: "games.unstoppable.special.ifSelfTrigger"
}, Pt = {
	damage: "games.unstoppable.effect.damage",
	bossDamage: "games.unstoppable.effect.bossDamage",
	credits: "games.unstoppable.effect.credits",
	health: "games.unstoppable.effect.health",
	armor: "games.unstoppable.effect.armor",
	actions: "games.unstoppable.effect.actions",
	train: "games.unstoppable.effect.train",
	draw: "games.unstoppable.effect.draw",
	refresh: "games.unstoppable.effect.refresh",
	eliminate: "games.unstoppable.effect.eliminate",
	destroy: "games.unstoppable.effect.destroy",
	defeat: "games.unstoppable.effect.defeat",
	discardThreat: "games.unstoppable.effect.discardThreat",
	draft: "games.unstoppable.effect.draft",
	upgrade: "games.unstoppable.effect.upgrade",
	discount: "games.unstoppable.effect.discount",
	faction: "games.unstoppable.effect.faction",
	exchange: "games.unstoppable.effect.exchange",
	repeat: "games.unstoppable.effect.repeat",
	allDamage: "games.unstoppable.effect.allDamage",
	bottom: "games.unstoppable.effect.bottom",
	trade: "games.unstoppable.effect.trade",
	recycleMarket: "games.unstoppable.effect.recycleMarket",
	disableKeywords: "games.unstoppable.effect.disableKeywords",
	swapResources: "games.unstoppable.effect.swapResources",
	returnSelf: "games.unstoppable.effect.returnSelf",
	playTop: "games.unstoppable.effect.playTop",
	shuffleThreat: "games.unstoppable.effect.shuffleThreat",
	splitDamage: "games.unstoppable.effect.splitDamage",
	activateUpgrades: "games.unstoppable.effect.activateUpgrades",
	revealCores: "games.unstoppable.effect.revealCores"
};
function Ft(e, t) {
	let n = (e) => typeof e == "string" ? t(kt[e]) : e ?? 1, r = n(e.n), i = t(Ot[e.resource ?? "credits"]), a;
	return a = e.flag && Mt[e.flag] && e.flag !== "ifSelfTrigger" ? t(Mt[e.flag]) : e.op === "choice" ? (e.options ?? []).map((e) => Z(e, t)).join(` ${t("games.unstoppable.or")} `) : e.op === "bargain" || e.op === "pay" ? t(e.op === "bargain" ? "games.unstoppable.effect.bargain" : "games.unstoppable.effect.pay", {
		n: r,
		resource: i,
		text: Z(e.effects ?? [], t)
	}) : e.op === "retrieve" ? t("games.unstoppable.effect.retrieve", {
		zone: t(e.zone === "deck" ? "games.unstoppable.deck" : e.zone === "hand" ? "games.unstoppable.hand" : "games.unstoppable.discard"),
		limit: e.maxLevel === void 0 ? "" : t("games.unstoppable.effect.maxLevel", { n: e.maxLevel })
	}) : e.op === "mark" ? "" : t(e.op === "health" && typeof e.n == "number" && e.n < 0 ? "games.unstoppable.effect.loseHealth" : e.op === "draw" && e.flag === "bottom" ? "games.unstoppable.effect.drawBottom" : e.op === "upgrade" && e.flag === "self" ? "games.unstoppable.effect.selfUpgrade" : e.op === "upgrade" && e.n === 99 ? "games.unstoppable.effect.anyUpgrade" : e.op === "recycleMarket" && e.flag === "entire" ? "games.unstoppable.effect.recycleEntireMarket" : e.op === "recycleMarket" && !e.flag ? "games.unstoppable.effect.recycleOneUpgrade" : e.op === "discount" && e.flag === "bargain" ? "games.unstoppable.effect.bargainDiscount" : Pt[e.op], {
		n: e.op === "draft" ? e.maxLevel ?? r : typeof r == "number" ? Math.abs(r) : r,
		resource: i
	}), e.flag === "ifSelfTrigger" && (a += ` · ${t(Mt.ifSelfTrigger)}`), (e.flag === "active" || e.flag === "activeWounded") && (a += ` · ${t("games.unstoppable.special.active")}`), e.flag === "activeWounded" && (a += ` · ${t("games.unstoppable.special.wounded")}`), e.zone === "deck" && [
		"damage",
		"destroy",
		"defeat"
	].includes(e.op) && (a += ` · ${t("games.unstoppable.special.onDeck")}`), e.times !== void 0 && e.times !== 1 && (a = t("games.unstoppable.repeatTimes", {
		text: a,
		n: n(e.times)
	})), e.flag && Nt[e.flag] && (a += ` · ${t(Nt[e.flag])}`), e.ignoreTaunt && (a = t("games.unstoppable.effect.ignoreTaunt", { text: a })), e.noBoss && (a = t("games.unstoppable.effect.noBoss", { text: a })), e.all && (a = t("games.unstoppable.allPlayers", { text: a })), e.when && (a = t("games.unstoppable.condition", {
		condition: t(At[e.when]),
		text: a
	})), e.level && (a = t("games.unstoppable.levelCondition", {
		n: e.level,
		text: a
	})), a;
}
var Z = (e, t) => e.map((e) => Ft(e, t)).filter(Boolean).join("；"), It = {
	attack: "#fa783b",
	shield: "#6be2df",
	echo: "#b49cf4",
	paper: "#ece8d7",
	ink: "#171a20"
};
function Lt(e) {
	let t = e.find((e) => [
		"damage",
		"splitDamage",
		"allDamage",
		"bossDamage",
		"repeat",
		"armor",
		"credits",
		"train",
		"health",
		"draw"
	].includes(e.op))?.op;
	return t === "repeat" ? "echo" : t === "armor" ? "shield" : t === "credits" ? "credits" : t === "train" ? "train" : t === "health" ? "health" : t === "draw" ? "draw" : "attack";
}
function Rt({ kind: e = "attack", echo: t = !1, capacitor: n = !1, seed: r = 0 }) {
	let i = It;
	if (e === "attack") return /* @__PURE__ */ g("svg", {
		className: "unst-art",
		viewBox: "0 0 220 140",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("path", {
				fill: "#d6c9ad",
				d: "M0 0H220V140H0z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#bd6a42",
				d: "M140 0H220V140H57z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#382c2b",
				d: "M174 0H220V140H102z"
			}),
			[
				0,
				1,
				2,
				3,
				4,
				5,
				6
			].map((e) => /* @__PURE__ */ h("path", {
				d: `M${13 + e * 12} 130L${94 + e * 12} 8`,
				stroke: "#b7a98e",
				opacity: ".5"
			}, e)),
			t && /* @__PURE__ */ g("g", { children: [
				/* @__PURE__ */ h("path", {
					fill: "#77638c",
					d: "M30 135L117 9L159 0L80 125z"
				}),
				/* @__PURE__ */ h("path", {
					fill: "#baa4e3",
					d: "M89 140L161 30L202 7L138 128z"
				}),
				/* @__PURE__ */ h("path", {
					d: "M18 119L106 1",
					stroke: "#d9c5ff",
					strokeWidth: "3"
				})
			] }),
			/* @__PURE__ */ h("path", {
				fill: "#20262b",
				d: "M27 140L134 7L190-8L104 127z"
			}),
			/* @__PURE__ */ h("path", {
				fill: i.attack,
				d: "M55 140L145 18L185 0L109 119z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#fff4ce",
				d: "M82 121L153 13L168 9L111 109z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#fb8a42",
				d: "M17 140L48 108L70 113L49 140z"
			}),
			/* @__PURE__ */ h("path", {
				d: "M122 114L166 60H208M11 48H48L66 27H102",
				fill: "none",
				stroke: "#56514a",
				strokeWidth: "2"
			}),
			n && /* @__PURE__ */ g("g", {
				className: "unst-art-circuit",
				fill: "none",
				stroke: "#659ca2",
				strokeWidth: "3",
				children: [/* @__PURE__ */ h("path", { d: "M4 100H31L64 63H89M132 111H160L187 82H217" }), [
					30,
					43,
					56
				].map((e) => /* @__PURE__ */ h("path", {
					d: `M${e} 114l7-10h6l-7 10z`,
					fill: "#e78946",
					stroke: "none"
				}, e))]
			}),
			/* @__PURE__ */ h("path", {
				fill: "#e4c9a1",
				d: "M184 119l4-5h4l-4 5zM193 119l4-5h4l-4 5zM202 119l4-5h4l-4 5z"
			})
		]
	});
	let a = e === "shield" ? i.shield : e === "credits" ? "#d5b763" : e === "health" ? "#b6cba3" : e === "train" || e === "echo" ? i.echo : "#b8c7d0";
	return /* @__PURE__ */ g("svg", {
		className: "unst-art",
		viewBox: "0 0 220 140",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("path", {
				fill: e === "credits" ? "#403a2a" : e === "shield" ? "#223b3c" : "#34303e",
				d: "M0 0H220V140H0z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#ffffff0b",
				d: "M0 0H80L180 140H100z"
			}),
			e === "credits" ? /* @__PURE__ */ g(m, { children: [[
				56,
				100,
				144
			].map((e, t) => /* @__PURE__ */ h("path", {
				d: `M${e} 19l24 14v71l-24 15-24-15V33z`,
				fill: t === 1 ? a : "#7c7045",
				stroke: a,
				strokeWidth: "2"
			}, e)), /* @__PURE__ */ h("path", {
				d: "M26 75H194",
				stroke: "#e3d7a7",
				strokeWidth: "3"
			})] }) : e === "shield" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M110 10L172 36V80L110 131L48 80V36z",
				fill: "#6be2df1c",
				stroke: a,
				strokeWidth: "4"
			}), /* @__PURE__ */ h("path", {
				d: "M110 29L151 46V76L110 110L69 76V46zM110 30V110M69 46L151 76M151 46L69 76",
				fill: "none",
				stroke: a,
				strokeWidth: "2"
			})] }) : e === "ally" ? /* @__PURE__ */ h(m, { children: [
				55,
				110,
				165
			].map((e, t) => /* @__PURE__ */ h("path", {
				d: `M${e - 18} 29h36v54l-18 28-18-28z`,
				fill: t === 1 ? "#b7cbbd" : "none",
				stroke: "#a9c8bd",
				strokeWidth: "3"
			}, e)) }) : /* @__PURE__ */ g(m, { children: [[
				18,
				35,
				52,
				69
			].map((e, t) => /* @__PURE__ */ h("path", {
				d: `M110 ${70 - e}l${e} ${e}-${e} ${e}-${e}-${e}z`,
				transform: `rotate(${r % 3 * 4} 110 70)`,
				fill: t === 0 ? a : "none",
				stroke: a,
				opacity: 1 - t * .17,
				strokeWidth: "3"
			}, e)), /* @__PURE__ */ h("path", {
				d: "M18 70H69M151 70H202",
				stroke: a,
				strokeWidth: "2"
			})] })
		]
	});
}
function zt({ id: e }) {
	let t = e === 90004, n = e === 90001, r = t ? "#bec698" : n ? "#c49a6a" : "#cf927a";
	return /* @__PURE__ */ g("svg", {
		className: "unst-art",
		viewBox: "0 0 220 140",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("path", {
				fill: t ? "#343b33" : n ? "#37312f" : "#392e30",
				d: "M0 0H220V140H0z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#ffffff09",
				d: "M0 0H96L181 140H84z"
			}),
			t ? /* @__PURE__ */ g(m, { children: [
				[
					0,
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ h("circle", {
					cx: 110 + Math.cos(e * Math.PI / 3) * 35,
					cy: 70 + Math.sin(e * Math.PI / 3) * 35,
					r: "20",
					stroke: r,
					strokeWidth: "3",
					fill: "none"
				}, e)),
				/* @__PURE__ */ h("path", {
					fill: r,
					d: "M110 42L135 82H85z"
				}),
				/* @__PURE__ */ h("path", {
					fill: "#414b3d",
					d: "M110 51L125 77H96z"
				})
			] }) : n ? /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M27 82L106 9L194 66L113 132z",
					fill: "none",
					stroke: r,
					strokeWidth: "4"
				}),
				/* @__PURE__ */ h("path", {
					fill: r,
					d: "M63 79L110 32L159 64L111 108z"
				}),
				/* @__PURE__ */ h("path", {
					fill: "#554333",
					d: "M110 32L159 64L111 108L109 70z"
				})
			] }) : /* @__PURE__ */ h("g", {
				transform: `rotate(${e % 3 * 6 - 6} 110 70)`,
				children: [
					66,
					110,
					154
				].map((e, t) => /* @__PURE__ */ h("path", {
					d: `M${e - 16} 29l25-10 7 69-16 26-17-26z`,
					fill: t === 1 ? r : "none",
					stroke: r,
					strokeWidth: "3"
				}, e))
			}),
			/* @__PURE__ */ h("path", {
				d: "M9 31V9H44M211 109V131H177",
				stroke: "#d4c5a5",
				fill: "none",
				opacity: ".6"
			})
		]
	});
}
//#endregion
//#region src/games/unstoppable/choice-hint.tsx
function Bt() {
	let e = _();
	return /* @__PURE__ */ h("span", {
		className: "unst-choice-hint",
		"aria-hidden": !0,
		children: e ? /* @__PURE__ */ g("svg", {
			className: "unst-choice-hint-static",
			children: [/* @__PURE__ */ h("rect", {
				x: 2,
				y: 2,
				rx: 4,
				fill: "none",
				stroke: "#fff",
				strokeWidth: 4,
				opacity: .9
			}), /* @__PURE__ */ h("rect", {
				x: 2,
				y: 2,
				rx: 4,
				fill: "none",
				className: "stroke-ink",
				strokeWidth: 2.5,
				strokeDasharray: "8 6",
				strokeLinecap: "round"
			})]
		}) : /* @__PURE__ */ h(v, {
			radius: 0,
			flash: !1
		})
	});
}
//#endregion
//#region src/games/unstoppable/battle-card.tsx
function Vt({ anchor: e, ...t }) {
	let { ref: n, hidden: r } = f(e);
	return /* @__PURE__ */ h("button", {
		ref: n,
		...t,
		style: { visibility: r ? "hidden" : void 0 }
	});
}
function Ht({ effects: e }) {
	let t = l(), n = e[0], r = e.length === 1 && n && !n.when && !n.level && (n.times === void 0 || n.times === 1) && typeof (n.n ?? 1) == "number", i = n?.op === "damage" ? "games.unstoppable.damageLabel" : n?.op === "armor" ? "games.unstoppable.armor" : n?.op === "credits" ? "games.unstoppable.credits" : n?.op === "health" ? "games.unstoppable.health" : n?.op === "actions" ? "games.unstoppable.actions" : n?.op === "repeat" ? "games.unstoppable.repeatCore" : null;
	return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", {
		className: "unst-effect-lines",
		children: r && i ? t(i) : e.map((e, n) => /* @__PURE__ */ h("span", { children: Ft(e, t) }, n))
	}), r && i && /* @__PURE__ */ h("b", { children: n.n ?? 1 })] });
}
function Ut({ card: e, choices: t, hint: n = !1, onPick: r, onInspect: i, onOptions: a }) {
	let o = l(), s = e.core === null ? void 0 : w[e.core], { ref: c, hidden: u } = f(`card:${e.iid}`), { ref: d } = f(`card-body:${e.iid}`);
	if (!s) return null;
	let p = t.filter((t) => t.category === "effect" && t.params.source === e.iid), _ = p.filter((e) => String(e.params.effectKey).startsWith("core/")), v = t.filter((t) => (t.category === "play" || t.category === "exhaust") && t.target === e.iid), y = _.length ? _ : v, b = t.filter((t) => t.target === e.iid && ["target", "card"].includes(t.category)), ee = b.length ? b : y, te = (e) => e.length === 1 ? r(e[0]) : a(e), ne = e.upgrades.map((e) => T[e]), re = ne.some((e) => e.play.some((e) => e.op === "repeat")), x = ne.some((e) => e.id === 15005 || e.id === 12202), S = s.play, C = (t) => {
		let r = ne.find((e) => e.slot === t), i = r ? p.filter((e) => e.upgrade === r.id) : [];
		return r ? /* @__PURE__ */ g(Vt, {
			anchor: `card-part:${e.iid}:upgrade/${r.id}`,
			type: "button",
			className: "unst-battle-part",
			"data-tone": Lt(r.play.length ? r.play : r.exhaust ?? []),
			"data-available": i.length > 0,
			"aria-disabled": !i.length,
			onClick: () => i.length && te(i),
			"aria-label": `${o(r.name)} · ${Z(r.play.length ? r.play : r.exhaust ?? [], o)}`,
			children: [
				/* @__PURE__ */ h("strong", { children: o(r.name) }),
				/* @__PURE__ */ h("span", {
					className: "unst-part-readout",
					children: /* @__PURE__ */ h(Ht, { effects: r.play })
				}),
				r.exhaust?.length ? /* @__PURE__ */ g("span", {
					className: "unst-card-rule",
					children: [/* @__PURE__ */ h("small", { children: o("games.unstoppable.onExhaust") }), /* @__PURE__ */ h(Ht, { effects: r.exhaust })]
				}) : null,
				r.costReduction ? /* @__PURE__ */ h("span", {
					className: "unst-card-rule",
					children: o("games.unstoppable.playCostReduction", { n: r.costReduction })
				}) : null,
				/* @__PURE__ */ g("span", {
					className: "unst-battle-cells",
					"aria-hidden": !0,
					children: [
						/* @__PURE__ */ h("i", {}),
						/* @__PURE__ */ h("i", {}),
						/* @__PURE__ */ h("i", {})
					]
				}),
				n && i.length > 0 && /* @__PURE__ */ h(Bt, {})
			]
		}) : /* @__PURE__ */ h("span", {
			className: "unst-battle-empty",
			children: o(t === "top" ? "games.unstoppable.top" : "games.unstoppable.bottom")
		});
	};
	return /* @__PURE__ */ g("div", {
		ref: c,
		style: { visibility: u ? "hidden" : void 0 },
		className: "unst-battle-card",
		"data-echo": re,
		"data-exhausted": e.exhausted,
		children: [re && /* @__PURE__ */ h("span", {
			className: "unst-battle-echo",
			"aria-hidden": !0
		}), /* @__PURE__ */ h("div", {
			className: "unst-battle-shell",
			children: /* @__PURE__ */ g("div", {
				className: "unst-battle-inner",
				children: [
					/* @__PURE__ */ g("button", {
						type: "button",
						className: "unst-battle-title",
						onClick: i,
						"aria-label": `${o("games.unstoppable.inspect")} · ${o(s.name)}`,
						children: [/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("strong", {
							"data-name-length": o(s.name).length > 20 ? "wrap" : o(s.name).length > 12 ? "long" : void 0,
							children: o(s.name)
						}), /* @__PURE__ */ g("small", { children: [
							o(s.kind === "ally" ? "games.unstoppable.ally" : "games.unstoppable.tactic"),
							" · ",
							o("games.unstoppable.level"),
							" ",
							s.level
						] })] }), /* @__PURE__ */ h("b", { children: e.cost < 0 ? "X" : e.cost })]
					}),
					/* @__PURE__ */ g("div", {
						ref: d,
						className: "unst-battle-scroll",
						tabIndex: 0,
						role: "region",
						"aria-label": o(s.name),
						children: [
							C("top"),
							/* @__PURE__ */ g(Vt, {
								anchor: `card-part:${e.iid}:core`,
								type: "button",
								className: "unst-battle-core",
								"data-available": ee.length > 0,
								"aria-disabled": !ee.length,
								onClick: () => ee.length && te(ee),
								"aria-label": !b.length && y.length ? `${o(s.name)} · ${_.length ? Z(S, o) : o(v[0].category === "play" ? "games.unstoppable.playCard" : "games.unstoppable.exhaustAlly")}` : o(s.name),
								children: [
									/* @__PURE__ */ h(Rt, {
										kind: s.kind === "ally" ? "ally" : Lt(s.play),
										echo: re,
										capacitor: x,
										seed: s.id
									}),
									/* @__PURE__ */ g("span", {
										className: "unst-battle-core-readout",
										children: [
											S.length > 0 && /* @__PURE__ */ h("span", {
												className: "unst-card-rule",
												children: /* @__PURE__ */ h(Ht, { effects: S })
											}),
											s.enter?.length ? /* @__PURE__ */ g("span", {
												className: "unst-card-rule",
												children: [/* @__PURE__ */ h("small", { children: o("games.unstoppable.onEnter") }), /* @__PURE__ */ h(Ht, { effects: s.enter })]
											}) : null,
											s.exhaust?.map((e, t) => /* @__PURE__ */ g("span", {
												className: "unst-card-rule",
												children: [/* @__PURE__ */ g("small", { children: [o("games.unstoppable.onExhaust"), s.exhaust.length > 1 ? ` ${t + 1}` : ""] }), /* @__PURE__ */ h(Ht, { effects: e })]
											}, t)),
											s.passive?.filter((e) => jt[e]).map((e) => /* @__PURE__ */ h("span", {
												className: "unst-card-rule",
												children: o(jt[e])
											}, e)),
											s.acquire?.length ? /* @__PURE__ */ g("span", {
												className: "unst-card-rule",
												children: [/* @__PURE__ */ h("small", { children: o("games.unstoppable.onAcquire") }), /* @__PURE__ */ h(Ht, { effects: s.acquire })]
											}) : null,
											s.leave?.length ? /* @__PURE__ */ g("span", {
												className: "unst-card-rule",
												children: [/* @__PURE__ */ h("small", { children: o("games.unstoppable.onLeave") }), /* @__PURE__ */ h(Ht, { effects: s.leave })]
											}) : null
										]
									}),
									n && (_.length > 0 || b.length > 0) && /* @__PURE__ */ h(Bt, {})
								]
							}),
							C("bottom")
						]
					}, e.iid),
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "unst-battle-activate",
						disabled: !y.length,
						onClick: () => te(y),
						children: v.length && !_.length ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: o(v[0].category === "play" ? "games.unstoppable.playCard" : "games.unstoppable.exhaustAlly") }), /* @__PURE__ */ h("b", { children: v[0].cost ?? "↗" })] }) : /* @__PURE__ */ h("span", { children: o("games.unstoppable.resolveEffect") })
					}),
					e.exhausted && /* @__PURE__ */ h("span", {
						className: "unst-battle-exhausted",
						children: o("games.unstoppable.exhausted")
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/games/unstoppable/threat-card.tsx
function Wt({ card: e, large: t = !1 }) {
	let n = l(), r = E[e.threat];
	return /* @__PURE__ */ g("span", {
		className: `unst-threat${t ? " unst-threat--large" : ""}${e.onDeck ? " unst-threat--deck" : ""}`,
		children: [
			/* @__PURE__ */ g("span", {
				className: "unst-card__head",
				children: [/* @__PURE__ */ g("span", { children: ["⚔ ", e.attack] }), /* @__PURE__ */ g("strong", { children: [
					"♥ ",
					Math.max(0, e.health - e.damage),
					" / ",
					e.health
				] })]
			}),
			/* @__PURE__ */ h("strong", {
				className: "unst-card__name",
				children: n(r.name)
			}),
			/* @__PURE__ */ h(zt, { id: e.threat }),
			/* @__PURE__ */ h("span", {
				className: "unst-keywords",
				children: e.keywords.map((e, t) => /* @__PURE__ */ h("span", { children: n(Dt[e]) }, t))
			}),
			t && /* @__PURE__ */ h("span", {
				className: "unst-card__body",
				children: e.disabled ? /* @__PURE__ */ h("p", { children: n("games.unstoppable.disabledThreat") }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("b", { children: n("games.unstoppable.reward") }), [...r.reward, ...e.upgrades.flatMap((e) => T[e].reward)].map((e, t) => /* @__PURE__ */ h("p", {
					className: "unst-effect",
					children: Ft(e, n)
				}, t))] })
			}),
			/* @__PURE__ */ h("span", {
				className: "unst-health-track",
				children: /* @__PURE__ */ h("span", { style: { width: `${Math.max(0, 100 * (e.health - e.damage) / e.health)}%` } })
			}),
			/* @__PURE__ */ h("span", {
				className: "unst-card__type",
				children: n(e.onDeck ? "games.unstoppable.onDeck" : "games.unstoppable.battlefield")
			})
		]
	});
}
//#endregion
//#region src/games/unstoppable/view-player.tsx
var Gt = {
	silver: "◆",
	junker: "⚙",
	viren: "❖",
	council: "◈"
};
function Q({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = f(e);
	return /* @__PURE__ */ h("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function Kt({ name: e, children: t }) {
	let { ref: n, hidden: r } = f(e);
	return /* @__PURE__ */ h("span", {
		ref: n,
		style: { visibility: r ? "hidden" : void 0 },
		children: t
	});
}
function $({ effects: e }) {
	let t = l();
	return /* @__PURE__ */ h(m, { children: e.map((e, n) => /* @__PURE__ */ h("p", {
		className: "unst-effect",
		children: Ft(e, t)
	}, n)) });
}
function qt({ card: e, large: t = !1 }) {
	let n = l(), r = e.core === null ? null : w[e.core];
	return r ? /* @__PURE__ */ g("span", {
		className: `unst-card${t ? " unst-card--large" : ""}${e.exhausted ? " unst-card--exhausted" : ""}`,
		"data-faction": r.faction ?? "none",
		children: [
			/* @__PURE__ */ g("span", {
				className: "unst-card__head",
				children: [/* @__PURE__ */ h("span", { children: e.factions.map((e) => /* @__PURE__ */ h("span", {
					title: n(Ct[e]),
					children: Gt[e]
				}, e)) }), /* @__PURE__ */ h("strong", { children: e.cost < 0 ? "X" : e.cost })]
			}),
			/* @__PURE__ */ h("strong", {
				className: "unst-card__name",
				children: n(r.name)
			}),
			/* @__PURE__ */ g("span", {
				className: "unst-card__type",
				children: [
					n(r.kind === "ally" ? "games.unstoppable.ally" : r.kind === "boss" ? "games.unstoppable.boss" : "games.unstoppable.tactic"),
					" · ",
					n("games.unstoppable.level"),
					" ",
					r.level
				]
			}),
			/* @__PURE__ */ h(Rt, {
				kind: r.kind === "ally" ? "ally" : Lt(r.play),
				echo: e.upgrades.includes(12106),
				capacitor: e.upgrades.some((e) => e === 15005 || e === 12202),
				seed: r.id
			}),
			t ? /* @__PURE__ */ g("span", {
				className: "unst-card__body",
				children: [
					r.play.length > 0 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("b", { children: n("games.unstoppable.onPlay") }), /* @__PURE__ */ h($, { effects: r.play })] }),
					r.enter?.length ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("b", { children: n("games.unstoppable.onEnter") }), /* @__PURE__ */ h($, { effects: r.enter })] }) : null,
					r.acquire?.length ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("b", { children: n("games.unstoppable.onAcquire") }), /* @__PURE__ */ h($, { effects: r.acquire })] }) : null,
					r.exhaust?.map((e, t) => /* @__PURE__ */ g("span", {
						className: "unst-branch",
						children: [/* @__PURE__ */ g("b", { children: [n("games.unstoppable.onExhaust"), r.exhaust.length > 1 ? ` ${t + 1}` : ""] }), /* @__PURE__ */ h($, { effects: e })]
					}, t)),
					r.leave?.length ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("b", { children: n("games.unstoppable.onLeave") }), /* @__PURE__ */ h($, { effects: r.leave })] }) : null,
					r.passive?.filter((e) => jt[e]).map((e) => /* @__PURE__ */ h("p", {
						className: "unst-effect",
						children: n(jt[e])
					}, e))
				]
			}) : /* @__PURE__ */ h("span", {
				className: "unst-card__brief",
				children: Z(r.play.length ? r.play : r.exhaust?.[0] ?? [], n)
			}),
			/* @__PURE__ */ h("span", {
				className: "unst-card__slots",
				children: ["top", "bottom"].map((t) => {
					let r = e.upgrades.find((e) => T[e].slot === t);
					return /* @__PURE__ */ h("span", { children: r ? n(T[r].name) : t === "top" ? "▱" : "▰" }, t);
				})
			}),
			e.exhausted && /* @__PURE__ */ h("span", {
				className: "unst-card__status",
				children: n("games.unstoppable.exhausted")
			})
		]
	}) : null;
}
function Jt({ id: e, large: t = !1 }) {
	let n = l(), r = T[e];
	return /* @__PURE__ */ g("span", {
		className: `unst-upgrade${t ? " unst-upgrade--large" : ""}`,
		"data-faction": r.faction ?? "none",
		children: [
			/* @__PURE__ */ g("span", {
				className: "unst-card__head",
				children: [/* @__PURE__ */ g("span", { children: [
					r.slot === "top" ? "▱" : "▰",
					" ",
					r.faction ? Gt[r.faction] : ""
				] }), /* @__PURE__ */ g("strong", { children: ["¤ ", r.cost] })]
			}),
			/* @__PURE__ */ h("strong", {
				className: "unst-card__name",
				children: n(r.name)
			}),
			/* @__PURE__ */ h(Rt, { kind: Lt(r.play.length ? r.play : r.exhaust ?? []) }),
			/* @__PURE__ */ g("span", {
				className: "unst-card__type",
				children: [
					n(r.slot === "top" ? "games.unstoppable.top" : "games.unstoppable.bottom"),
					" · ",
					n(r.kind === "ally" ? "games.unstoppable.ally" : r.kind === "tactic" ? "games.unstoppable.tactic" : "games.unstoppable.either")
				]
			}),
			t ? /* @__PURE__ */ g("span", {
				className: "unst-card__body",
				children: [
					r.play.length > 0 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("b", { children: n("games.unstoppable.onPlay") }), /* @__PURE__ */ h($, { effects: r.play })] }),
					r.exhaust?.length ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("b", { children: n("games.unstoppable.onExhaust") }), /* @__PURE__ */ h($, { effects: r.exhaust })] }) : null,
					r.costReduction ? /* @__PURE__ */ h("p", { children: n("games.unstoppable.playCostReduction", { n: r.costReduction }) }) : null,
					/* @__PURE__ */ g("p", { children: [
						n("games.unstoppable.attack", { n: r.attack }),
						" · ",
						n("games.unstoppable.defense", { n: r.defense })
					] }),
					/* @__PURE__ */ h("p", { children: r.keywords.map((e) => n(Dt[e])).join(" · ") }),
					r.reward.length > 0 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("b", { children: n("games.unstoppable.reward") }), /* @__PURE__ */ h($, { effects: r.reward })] })
				]
			}) : /* @__PURE__ */ h("span", {
				className: "unst-card__brief",
				children: Z(r.play.length ? r.play : r.exhaust ?? [], n)
			})
		]
	});
}
function Yt(e) {
	u();
	let t = l(), n = e.public, r = e.private, i = n.phase === "done" ? [] : r?.choices ?? [], a = n.players.find((t) => t.rid === e.myRid), c = (t) => e.members.find((e) => e.rid === t)?.name ?? t, f = i.length > 0 && (n.phase === "character" || n.waiting === e.myRid), [_, v] = o(null), [y, b] = o(f), [ee, te] = o(""), [ne, re] = o(e.myRid), [x, S] = o(null), C = n.players.find((e) => e.rid === ne) ?? a ?? n.players[0], ie = n.players.flatMap((e) => [...e.threats.map((e) => e.iid), ...e.play.map((e) => e.iid)]).concat(r?.hand.map((e) => e.iid) ?? []), ae = i.some((e) => e.category === "effect" && /^(core|upgrade)\//.test(String(e.params.effectKey)) || e.target && ie.includes(e.target) && ["target", "card"].includes(e.category)), D = (C.rid === e.myRid ? r?.source ?? [...r?.hand ?? [], ...C.play].find((e) => e.iid === ee) : void 0) ?? C.play.find((e) => e.core === n.source) ?? C.play[C.play.length - 1] ?? (C.rid === e.myRid ? r?.hand[0] : void 0), oe = f ? i[0].id : "", [se, O] = o(oe);
	se !== oe && (O(oe), oe && (b(!ae), v(null), S(null)));
	let k = (t) => {
		e.send({
			type: "pick",
			id: t.id
		}), v(null), b(!1), S(null);
	}, A = (e) => {
		S(e.map((e) => e.id)), b(!0);
	}, j = (e) => i.filter((t) => t.target === e && ["target", "card"].includes(t.category)), ue = f && !y && _ === null, M = (e) => ue && j(e).length > 0 ? /* @__PURE__ */ h(Bt, {}) : null, de = (e) => e.threats.some((e) => j(e.iid).length > 0) || e.play.some((e) => j(e.iid).length > 0 || i.some((t) => t.category === "effect" && t.params.source === e.iid)), fe = (e) => {
		let t = j(e.iid);
		t.length === 1 ? k(t[0]) : t.length ? A(t) : v({
			kind: "threat",
			card: e
		});
	}, pe = (e) => {
		let r = t(e.key, {
			...e.params,
			n: e.n ?? e.cost ?? e.params.n ?? 1
		});
		if (e.category === "character") return r;
		if (e.category === "buy") return t("games.unstoppable.upgradeTarget", {
			card: e.card === void 0 ? "" : t(w[e.card].name),
			upgrade: e.upgrade === void 0 ? "" : t(T[e.upgrade].name)
		});
		if (e.effects?.length) return `${e.upgrade === void 0 ? "" : t(T[e.upgrade].name) + " · "}${Z(e.effects, t)}`;
		let i = e.card === void 0 ? e.threat === void 0 ? e.upgrade === void 0 ? "" : t(T[e.upgrade].name) : t(E[e.threat].name) : t(w[e.card].name), a = n.players.flatMap((e) => e.threats).find((t) => t.iid === e.target);
		return a && (i = `${t(E[a.threat].name)} · ${c(a.owner)}`), e.target === "boss" && (i = t(Tt[n.config.boss])), e.target?.startsWith("location:") && (i = t(Et[Number(e.target.slice(9))])), e.target?.startsWith("story:") && (i = t(P[Number(e.target.slice(6))].name)), e.target && e.target in Ot && (i = t(Ot[e.target])), i ? `${r} · ${i}` : r;
	}, me = (e) => {
		let n = e.cost ?? 0;
		if (e.category === "play") return t("games.unstoppable.actionCost", { n });
		if (e.category === "story" && e.target?.startsWith("story:")) {
			let r = P[Number(e.target.slice(6))].options[e.n ?? 0]?.resource;
			return r === "none" ? "" : t(r === "damage" ? "games.unstoppable.damageRequired" : r === "eliminate" ? "games.unstoppable.cardsRequired" : r === "armor" ? "games.unstoppable.armorCost" : r === "actions" ? "games.unstoppable.actionCost" : "games.unstoppable.creditCost", { n });
		}
		return e.category === "story" ? t("games.unstoppable.actionCost", { n }) : t("games.unstoppable.creditCost", { n });
	}, N = (e) => /* @__PURE__ */ g("button", {
		className: `unst-choice${e.category === "end" ? " unst-choice--quiet" : ""}`,
		onClick: () => k(e),
		children: [
			/* @__PURE__ */ g("span", { children: [pe(e), e.category === "exhaust" && e.n !== void 0 && w[e.card].exhaust.length > 1 ? ` · ${e.n + 1}` : ""] }),
			e.category === "character" && e.target && /* @__PURE__ */ h("small", { children: ce[e.target].map((e) => t(w[e].name)).join(" · ") }),
			e.cost !== void 0 && e.category !== "number" && /* @__PURE__ */ h("small", { children: me(e) })
		]
	}, e.id), he = _ ? i.filter((e) => _.kind === "core" || _.kind === "threat" ? e.target === _.card.iid : _.kind === "upgrade" ? e.upgrade === _.id : _.kind === "story" ? e.target === `story:${_.id}` : _.kind === "location" && e.target === `location:${_.id}`) : [], ge = (e) => P[e].options.map((r, i) => {
		let a = r.n * (r.resource === "armor" ? 1 : n.players.length);
		return r.flag === "damageDiscount" && (a -= n.storyDamage[e] ?? 0), r.flag === "donationDiscountEnding" && (a -= n.storyCredits[e] ?? 0), r.flag === "damageSurcharge" && (a += n.storyDamage[e] ?? 0), r.flag === "swarmSurchargeEnding" && (a += n.storyCredits[21] ?? 0), r.flag === "upgradesDiscountEnding" && (a -= n.players.reduce((e, t) => e + t.ownedUpgrades, 0)), /* @__PURE__ */ g("div", {
			className: "unst-story-option",
			children: [
				/* @__PURE__ */ h("b", { children: t(r.key) }),
				r.resource !== "none" && /* @__PURE__ */ h("p", { children: r.resource === "eliminate" ? t("games.unstoppable.storyEliminate", { n: r.flag === "damageLevel" ? Math.min(5, (n.storyDamage[e] ?? 0) + 1) : r.n }) : t(r.resource === "damage" ? "games.unstoppable.damageRequired" : r.resource === "armor" ? "games.unstoppable.armorCost" : r.resource === "actions" ? "games.unstoppable.actionCost" : "games.unstoppable.creditCost", { n: Math.max(0, a) }) }),
				r.effects && /* @__PURE__ */ h($, { effects: r.effects }),
				r.each && /* @__PURE__ */ h("p", { children: t("games.unstoppable.allPlayers", { text: Z(r.each, t) }) }),
				r.flag === "oneFreeUpgrade" && /* @__PURE__ */ h("p", { children: t("games.unstoppable.storyFreeUpgrade") }),
				r.flag === "donate" ? /* @__PURE__ */ h("p", { children: t("games.unstoppable.storyDonation") }) : r.flag?.toLowerCase().includes("ending") ? /* @__PURE__ */ h("p", { children: t("games.unstoppable.storyVictory") }) : /* @__PURE__ */ h("p", { children: t("games.unstoppable.storyNext", { n: r.next }) })
			]
		}, i);
	}), _e = (e) => ({
		iid: `core:${e}`,
		core: e,
		upgrades: [],
		exhausted: !1,
		cost: w[e].cost,
		factions: w[e].faction ? [w[e].faction] : []
	}), ve = (e) => t(e.key, {
		name: c(e.who),
		n: e.n ?? 0,
		card: e.card === void 0 ? "" : t((e.key === "games.unstoppable.logUpgrade" ? T[e.card] : e.key === "games.unstoppable.logDamage" || e.key === "games.unstoppable.logDefeat" || e.key === "games.unstoppable.logDestroy" || e.key === "games.unstoppable.logCrazed" ? E[e.card] : w[e.card])?.name ?? "games.unstoppable.core")
	}), ye = [
		"games.unstoppable.resolving",
		"games.unstoppable.refilling",
		"games.unstoppable.threatPrompt"
	].includes(n.prompt), be = !i.length && n.waiting && n.waiting !== e.myRid && !ye ? t("games.unstoppable.waiting", { name: c(n.waiting) }) : t(n.prompt);
	return /* @__PURE__ */ g("div", {
		className: "unst-screen",
		"data-team": n.players.length > 1,
		"data-boss": n.config.boss,
		children: [
			/* @__PURE__ */ h(d, {
				adaptive: !0,
				className: "unst-adaptive",
				scroll: !1,
				banner: /* @__PURE__ */ g("div", {
					className: "unst-banner",
					children: [/* @__PURE__ */ g("div", {
						className: "unst-player-heading",
						children: [
							/* @__PURE__ */ h("strong", { children: a?.character ? t(wt[a.character]) : c(e.myRid) }),
							/* @__PURE__ */ g("span", { children: [
								/* @__PURE__ */ g(Kt, {
									name: `resource:${e.myRid}:level`,
									children: [
										t("games.unstoppable.level"),
										" ",
										a?.level ?? 1
									]
								}),
								" · ",
								/* @__PURE__ */ g(Kt, {
									name: `resource:${e.myRid}:training`,
									children: [
										t("games.unstoppable.training"),
										" ",
										a?.training ?? 1
									]
								})
							] }),
							/* @__PURE__ */ h("span", { children: t("games.unstoppable.turn", { n: n.turn }) })
						]
					}), /* @__PURE__ */ h(Q, {
						name: `seat:${e.myRid}`,
						className: "unst-resource-strip",
						children: a && /* @__PURE__ */ h(m, { children: [
							"health",
							"armor",
							"actions",
							"credits"
						].map((n, r) => /* @__PURE__ */ g(Kt, {
							name: `resource:${e.myRid}:${n}`,
							children: [/* @__PURE__ */ h("span", {
								"aria-hidden": !0,
								children: [
									"♥",
									"⬡",
									"ϟ",
									"¤"
								][r]
							}), /* @__PURE__ */ h("b", {
								"aria-label": `${t(Ot[n])} ${a[n]}`,
								children: a[n]
							})]
						}, n)) })
					})]
				}),
				children: /* @__PURE__ */ g("div", {
					className: "unst-workspace",
					children: [/* @__PURE__ */ g("div", {
						className: "unst-table",
						children: [
							/* @__PURE__ */ g("section", {
								className: "unst-boss-zone",
								children: [
									/* @__PURE__ */ h(Q, {
										name: "boss",
										children: /* @__PURE__ */ g("button", {
											className: "unst-boss-heading",
											"data-target": j("boss").length > 0,
											onClick: () => {
												let e = j("boss");
												e.length === 1 ? k(e[0]) : e.length && A(e);
											},
											disabled: !j("boss").length,
											children: [
												/* @__PURE__ */ h("strong", { children: t(Tt[n.config.boss]) }),
												/* @__PURE__ */ g("span", { children: [
													t("games.unstoppable.danger"),
													" ",
													/* @__PURE__ */ h("b", { children: n.dangerLevel })
												] }),
												n.config.boss !== "duomo" && /* @__PURE__ */ g("b", { children: [
													"♥ ",
													Math.max(0, n.bossHealth - n.bossDamage),
													" / ",
													n.bossHealth
												] }),
												M("boss")
											]
										})
									}),
									/* @__PURE__ */ h(Q, {
										name: "danger",
										className: "unst-danger-track",
										children: le[n.config.boss].map((e, r) => /* @__PURE__ */ h("span", {
											"data-current": r === n.danger,
											"data-skipped": e.skip === n.config.difficulty,
											"aria-label": r === n.danger ? t("games.unstoppable.remainingRounds", { n: n.roundsLeft }) : void 0,
											children: r === n.danger ? "◆" : r === le[n.config.boss].length - 1 ? "☠" : e.effect === "market" ? "▱" : e.effect === "eliminate" ? "◇" : e.level
										}, r))
									}),
									n.config.boss === "triumvirate" && /* @__PURE__ */ h("div", {
										className: "unst-locations",
										children: n.locations.map((e, r) => /* @__PURE__ */ h(Q, {
											name: `location:${r}`,
											children: /* @__PURE__ */ g("button", {
												"data-target": j(`location:${r}`).length > 0,
												onClick: () => {
													let e = j(`location:${r}`);
													e.length === 1 ? k(e[0]) : e.length ? A(e) : v({
														kind: "location",
														id: r
													});
												},
												children: [
													/* @__PURE__ */ h("strong", { children: t(Et[r]) }),
													/* @__PURE__ */ h("span", { children: e >= [
														4,
														3,
														5
													][r] * n.players.length ? t("games.unstoppable.locationDefeated") : `♥ ${[
														4,
														3,
														5
													][r] * n.players.length - e}` }),
													M(`location:${r}`)
												]
											})
										}, r))
									}),
									n.config.boss === "duomo" && /* @__PURE__ */ h("div", {
										className: "unst-story-row",
										children: n.story.map((e) => /* @__PURE__ */ h(Q, {
											name: `story:${e}`,
											children: /* @__PURE__ */ g("button", {
												"data-target": j(`story:${e}`).length > 0,
												onClick: () => {
													let t = j(`story:${e}`);
													t.length === 1 ? k(t[0]) : t.length ? A(t) : v({
														kind: "story",
														id: e
													});
												},
												children: [
													/* @__PURE__ */ h("strong", { children: t(P[e].name) }),
													/* @__PURE__ */ h("small", { children: e === 21 ? t("games.unstoppable.storyCredits", { n: n.storyCredits[e] ?? 0 }) : t("games.unstoppable.storyDamage", { n: n.storyDamage[e] ?? 0 }) }),
													M(`story:${e}`)
												]
											})
										}, e))
									}),
									n.storyNext !== null && /* @__PURE__ */ h("span", {
										className: "unst-story-next",
										children: t("games.unstoppable.storyNext", { n: n.storyNext })
									})
								]
							}),
							n.players.length > 1 && /* @__PURE__ */ h("div", {
								className: "unst-seat-tabs",
								role: "group",
								"aria-label": t("games.unstoppable.battlefield"),
								children: n.players.map((t) => /* @__PURE__ */ h(Q, {
									name: t.rid === e.myRid ? `field:${t.rid}` : `seat:${t.rid}`,
									children: /* @__PURE__ */ g("button", {
										"aria-pressed": t.rid === C.rid,
										"data-target": t.rid !== C.rid && de(t),
										onClick: () => re(t.rid),
										children: [
											c(t.rid),
											t.rid !== e.myRid && /* @__PURE__ */ g("small", { children: [
												" ♥ ",
												t.health,
												" · ⬡ ",
												t.armor,
												" · ϟ ",
												t.actions,
												" · ¤ ",
												t.credits
											] }),
											ue && t.rid !== C.rid && de(t) && /* @__PURE__ */ h(Bt, {})
										]
									})
								}, t.rid))
							}),
							/* @__PURE__ */ g("section", {
								className: "unst-field",
								children: [
									/* @__PURE__ */ h("div", {
										className: "unst-row unst-battlefield",
										children: Array.from({ length: Math.max(3, C.threats.filter((e) => !e.onDeck).length) }, (e, n) => {
											let r = C.threats.filter((e) => !e.onDeck)[n];
											return /* @__PURE__ */ h(Q, {
												name: `threat-slot:${C.rid}:${n}`,
												className: "unst-threat-slot",
												children: r && /* @__PURE__ */ h(Q, {
													name: `threat:${r.iid}`,
													children: /* @__PURE__ */ g("button", {
														className: "unst-piece",
														"data-target": j(r.iid).length > 0,
														onClick: () => fe(r),
														"aria-label": `${t(E[r.threat].name)} · ${t("games.unstoppable.remainingHealth", { n: r.health - r.damage })}`,
														children: [/* @__PURE__ */ h(Wt, { card: r }), M(r.iid)]
													})
												})
											}, n);
										})
									}),
									/* @__PURE__ */ h("div", {
										className: "unst-decision",
										role: "status",
										children: n.victory ? t("games.unstoppable.victoryContinue") : be
									}),
									/* @__PURE__ */ g("div", {
										className: "unst-play-stage",
										children: [/* @__PURE__ */ h("div", {
											className: "unst-focus",
											children: D ? /* @__PURE__ */ h(Ut, {
												card: D,
												choices: C.rid === e.myRid ? i : i.filter((e) => ["target", "card"].includes(e.category)),
												hint: ue,
												onPick: k,
												onInspect: () => v({
													kind: "core",
													card: D
												}),
												onOptions: A
											}) : /* @__PURE__ */ g("div", {
												className: "unst-idle-card",
												children: [/* @__PURE__ */ h(Rt, { kind: "shield" }), /* @__PURE__ */ h("span", { children: t("games.unstoppable.noCards") })]
											})
										}), /* @__PURE__ */ g("aside", {
											className: "unst-side",
											children: [
												/* @__PURE__ */ h("div", {
													className: "unst-allies unst-row",
													children: C.play.filter((e) => e.iid !== D?.iid).map((e) => /* @__PURE__ */ h(Q, {
														name: `card:${e.iid}`,
														children: /* @__PURE__ */ g("button", {
															className: "unst-piece",
															"data-target": j(e.iid).length > 0,
															onClick: () => {
																let t = j(e.iid);
																t.length === 1 ? k(t[0]) : t.length ? A(t) : (te(e.iid), v({
																	kind: "core",
																	card: e
																}));
															},
															children: [/* @__PURE__ */ h(qt, { card: e }), M(e.iid)]
														})
													}, e.iid))
												}),
												/* @__PURE__ */ h(Q, {
													name: `threat-slot:${C.rid}:deck`,
													className: "unst-ondeck",
													children: C.threats.filter((e) => e.onDeck).map((e) => /* @__PURE__ */ h(Q, {
														name: `threat:${e.iid}`,
														children: /* @__PURE__ */ g("button", {
															className: "unst-piece",
															"data-target": j(e.iid).length > 0,
															onClick: () => fe(e),
															children: [/* @__PURE__ */ h(Wt, { card: e }), M(e.iid)]
														})
													}, e.iid))
												}),
												/* @__PURE__ */ h(Q, {
													name: `supply:${C.rid}`,
													children: /* @__PURE__ */ g("button", {
														className: "unst-deck-count",
														onClick: () => v({
															kind: "discard",
															rid: C.rid
														}),
														children: [/* @__PURE__ */ g("span", { children: [
															t("games.unstoppable.deck"),
															" ",
															/* @__PURE__ */ h("b", { children: C.deckCount }),
															" · ",
															t("games.unstoppable.discard"),
															" ",
															C.discard.length
														] }), C.rid !== e.myRid && /* @__PURE__ */ g("small", { children: [
															t("games.unstoppable.level"),
															" ",
															C.level,
															" · ",
															t("games.unstoppable.training"),
															" ",
															C.training,
															/* @__PURE__ */ h("br", {}),
															t("games.unstoppable.hand"),
															" ",
															C.handCount
														] })]
													})
												})
											]
										})]
									})
								]
							}),
							/* @__PURE__ */ h("div", {
								className: "unst-log",
								children: /* @__PURE__ */ h(p, {
									log: n.log,
									line: ve
								})
							})
						]
					}), /* @__PURE__ */ g("div", {
						className: "unst-actions",
						children: [
							/* @__PURE__ */ h("div", {
								className: "unst-hand-label",
								children: /* @__PURE__ */ g("span", { children: [
									t("games.unstoppable.hand"),
									" ",
									r?.hand.length ?? 0
								] })
							}),
							/* @__PURE__ */ h(Q, {
								name: `hand:${e.myRid}`,
								className: "unst-hand unst-row",
								children: r?.hand.map((n) => /* @__PURE__ */ g("button", {
									className: "unst-piece",
									"data-selected": D?.iid === n.iid,
									"data-target": j(n.iid).length > 0,
									onClick: () => {
										let t = j(n.iid);
										t.length === 1 ? k(t[0]) : t.length ? A(t) : (te(n.iid), re(e.myRid));
									},
									"aria-label": t(w[n.core].name),
									children: [/* @__PURE__ */ h(qt, { card: n }), M(n.iid)]
								}, n.iid))
							}),
							/* @__PURE__ */ g("div", {
								className: "unst-controls",
								children: [
									/* @__PURE__ */ h(Kt, {
										name: "market",
										children: /* @__PURE__ */ h("button", {
											className: "unst-link",
											onClick: () => v({ kind: "market" }),
											children: t("games.unstoppable.market")
										})
									}),
									/* @__PURE__ */ g("button", {
										className: "unst-primary",
										onClick: () => {
											S(null), b(!0);
										},
										disabled: !i.length,
										children: [t(f ? "games.unstoppable.choose" : "games.unstoppable.moreActions"), i.length ? ` (${i.length})` : ""]
									}),
									i.filter((e) => e.key === "games.unstoppable.finishMain" || e.key === "games.unstoppable.resumeMain" || e.key === "games.unstoppable.finishVictory").map(N)
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ h(s, {
				open: y,
				onClose: () => b(!1),
				label: be,
				title: be,
				tall: !0,
				children: /* @__PURE__ */ g("div", {
					className: "unst-choice-panel",
					children: [
						r?.effect && /* @__PURE__ */ h("p", {
							className: "unst-current-effect",
							children: Ft(r.effect, t)
						}),
						n.source !== null && /* @__PURE__ */ h("div", {
							className: "unst-source",
							children: t(w[n.source].name)
						}),
						i.filter((e) => x === null || x.includes(e.id)).map((e) => /* @__PURE__ */ g("div", { children: [e.category === "draft" && e.card !== void 0 && /* @__PURE__ */ h("button", {
							className: "unst-preview-card",
							onClick: () => {
								b(!1), v({
									kind: "core",
									card: _e(e.card)
								});
							},
							children: /* @__PURE__ */ h(qt, { card: _e(e.card) })
						}), N(e)] }, e.id)),
						i.length === 0 && /* @__PURE__ */ h("p", { children: t("games.unstoppable.noChoice") })
					]
				})
			}),
			/* @__PURE__ */ h(s, {
				open: _ !== null,
				onClose: () => v(null),
				label: t("games.unstoppable.inspect"),
				title: t("games.unstoppable.inspect"),
				tall: !0,
				children: /* @__PURE__ */ g("div", {
					className: "unst-inspect",
					children: [
						_?.kind === "core" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(qt, {
							card: _.card,
							large: !0
						}), _.card.upgrades.map((e) => /* @__PURE__ */ h(Jt, {
							id: e,
							large: !0
						}, e))] }),
						_?.kind === "threat" && /* @__PURE__ */ h(Wt, {
							card: _.card,
							large: !0
						}),
						_?.kind === "upgrade" && /* @__PURE__ */ h(Jt, {
							id: _.id,
							large: !0
						}),
						_?.kind === "market" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("div", {
							className: "unst-inspect-grid",
							children: n.market.map((e, t) => /* @__PURE__ */ h("button", {
								className: "unst-piece",
								onClick: () => v({
									kind: "upgrade",
									id: e
								}),
								children: /* @__PURE__ */ h(Jt, { id: e })
							}, `${e}:${t}`))
						}), /* @__PURE__ */ g("div", {
							className: "unst-supplies",
							children: [
								t("games.unstoppable.cores"),
								" ",
								n.coreCounts.map((e, n) => /* @__PURE__ */ g("span", { children: [
									t("games.unstoppable.level"),
									" ",
									n + 1,
									" · ",
									e
								] }, n))
							]
						})] }),
						_?.kind === "discard" && /* @__PURE__ */ h("div", {
							className: "unst-inspect-grid",
							children: n.players.find((e) => e.rid === _.rid)?.discard.map((e) => /* @__PURE__ */ h("button", {
								className: "unst-piece",
								onClick: () => v({
									kind: "core",
									card: e
								}),
								children: /* @__PURE__ */ h(qt, { card: e })
							}, e.iid))
						}),
						_?.kind === "story" && /* @__PURE__ */ g(m, { children: [
							/* @__PURE__ */ g("h3", { children: [
								_.id,
								" · ",
								t(P[_.id].name)
							] }),
							/* @__PURE__ */ h("p", { children: t(P[_.id].text) }),
							/* @__PURE__ */ h("p", { children: t("games.unstoppable.storyDamage", { n: n.storyDamage[_.id] ?? 0 }) }),
							ge(_.id)
						] }),
						_?.kind === "location" && /* @__PURE__ */ g(m, { children: [
							/* @__PURE__ */ h("h3", { children: t(Et[_.id]) }),
							/* @__PURE__ */ h("p", { children: t("games.unstoppable.locationRules") }),
							/* @__PURE__ */ h("p", { children: t(_.id === 0 ? "games.unstoppable.locationRules0" : _.id === 1 ? "games.unstoppable.locationRules1" : "games.unstoppable.locationRules2") })
						] }),
						he.map(N)
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/unstoppable/bot.ts
function Xt(e) {
	let t = 4294967296 - 4294967296 % e, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return n[0] % e;
}
function Zt(e, t) {
	let n = typeof e.n == "number" ? e.n : 2, r = typeof e.times == "number" ? e.times : 1;
	return e.op === "choice" ? Math.max(0, ...(e.options ?? []).map((e) => e.reduce((e, n) => e + Zt(n, t), 0))) : e.op === "pay" || e.op === "bargain" ? (e.effects ?? []).reduce((e, n) => e + Zt(n, t), 0) - (e.resource === "health" ? n * (t < 5 ? 5 : 1) : n * .2) : ({
		damage: 2,
		bossDamage: 25,
		credits: 1,
		health: t < 7 ? 3 : .2,
		armor: 1.1,
		actions: 4,
		train: 2,
		draw: 4,
		refresh: 5,
		eliminate: .3,
		destroy: 7,
		defeat: 9,
		retrieve: 5,
		draft: 5,
		upgrade: 6,
		repeat: 5,
		playTop: 4,
		allDamage: 5,
		activateUpgrades: 5
	}[e.op] ?? .7) * n * r;
}
function Qt(e, t, n, r) {
	let i = t.players.find((e) => e.rid === r), a = i.health;
	if (e.category === "end") return e.key === "games.unstoppable.finishMarket" ? 4 : e.key === "games.unstoppable.keepAll" ? 1 : -100;
	if (e.category === "character") return e.target === "kai" ? 10 : 5;
	if (e.category === "effect") return (e.effects ?? []).reduce((e, t) => e + Zt(t, a), 0);
	if (e.category === "target") {
		if (e.target === "boss") return 100;
		if (e.target?.startsWith("location:")) return n.effect?.op === "bossDamage" ? 100 : 15 + (e.n ?? 1) * .2;
		if (e.target?.startsWith("story:")) return 8;
		let i = t.players.flatMap((e) => e.threats).find((t) => t.iid === e.target);
		if (i) {
			let t = i.health - i.damage, n = e.n ?? 1;
			return (n >= t ? 30 : 10) + i.attack * 2 - Math.max(0, n - t) * .5 + +(i.owner === r);
		}
	}
	if (e.category === "exhaust") return 35;
	if (e.category === "play") {
		let t = w[e.card];
		return 10 + t.play.reduce((e, t) => e + Zt(t, a), 0) + (t.kind === "ally" ? 15 : 0) - (e.cost ?? 0) * .8;
	}
	return e.category === "buy" ? 5 + (T[e.upgrade].cost - (e.cost ?? 0)) + (w[e.card].kind === "ally" ? 2 : 0) - (e.cost ?? 0) * .5 : e.category === "draft" ? e.card === void 0 ? (e.n ?? 1) * 3 : w[e.card].level + w[e.card].play.reduce((e, t) => e + Zt(t, a), 0) + (w[e.card].kind === "ally" ? 8 : 0) - w[e.card].cost : e.category === "story" ? 28 : e.category === "number" ? e.target === "health" && a - (e.cost ?? 0) < 3 ? -120 : 10 + (e.n ?? 0) : e.category === "card" ? e.key === "games.unstoppable.eliminateCard" || e.key === "games.unstoppable.discardToThree" || e.key === "games.unstoppable.rageDiscard" ? e.card === 12803 ? 8 : e.card === 12800 ? 6 : 5 - (w[e.card ?? 12800]?.level ?? 0) : e.card === void 0 ? 8 : 8 + (w[e.card]?.level ?? 0) : e.key === "games.unstoppable.cycleUpgrade" || e.target === "swapResources" ? -110 : e.key === "games.unstoppable.chooseFaction" ? 7 : e.target && [
		"silver",
		"junker",
		"viren",
		"council"
	].includes(e.target) ? 10 - [...n.hand, ...i.play].filter((t) => t.factions.includes(e.target)).length : 2;
}
var $t = (e, t) => {
	let n = e.private;
	if (!n?.choices.length || e.public.players.find((e) => e.rid === t.rid)?.ready && e.public.waiting !== t.rid) return null;
	let r = n.choices;
	return { action: {
		type: "pick",
		id: (t.difficulty === "weak" ? r[Xt(r.length)] : [...r].sort((r, i) => Qt(i, e.public, n, t.rid) - Qt(r, e.public, n, t.rid))[0]).id
	} };
}, en = (e, t, n) => {
	if (e.type !== "pick") return "";
	let r = t.private?.choices.find((t) => t.id === e.id);
	return r ? r.effects?.length ? Z(r.effects, n) : n(r.key, {
		...r.params,
		n: r.n ?? r.cost ?? 1
	}) + (r.card === void 0 ? "" : ` · ${n(w[r.card].name)}`) : "";
};
//#endregion
//#region src/games/unstoppable/fx.tsx
function tn(e, t, n) {
	let r = e.anchor(`card:${t}`), i = e.anchor(`card-body:${t}`), a = e.anchor(`card-part:${t}:${n.startsWith("upgrade/") ? n.split("/").slice(0, 2).join("/") : "core"}`);
	if (!a || !i) return r;
	let o = Math.max(a.x, i.x), s = Math.max(a.y, i.y), c = Math.min(a.x + a.w, i.x + i.w) - o, l = Math.min(a.y + a.h, i.y + i.h) - s;
	return c > 8 && l > 8 ? {
		x: o,
		y: s,
		w: c,
		h: l
	} : r;
}
var nn = {
	activate: "games.unstoppable.fx.activate",
	attack: "games.unstoppable.fx.attack",
	discount: "games.unstoppable.fx.discount",
	mark: "games.unstoppable.fx.mark",
	reveal: "games.unstoppable.fx.reveal",
	discard: "games.unstoppable.fx.discard",
	bottom: "games.unstoppable.fx.bottom",
	bossCard: "games.unstoppable.fx.bossCard",
	shuffle: "games.unstoppable.fx.shuffle",
	remove: "games.unstoppable.fx.remove",
	danger: "games.unstoppable.fx.danger",
	cleanup: "games.unstoppable.fx.cleanup",
	ready: "games.unstoppable.fx.ready",
	story: "games.unstoppable.fx.story",
	disable: "games.unstoppable.fx.disable",
	defeat: "games.unstoppable.fx.defeat",
	faction: "games.unstoppable.fx.faction",
	market: "games.unstoppable.fx.market",
	draw: "games.unstoppable.fx.draw",
	refill: "games.unstoppable.fx.refill",
	limit: "games.unstoppable.fx.limit"
};
function rn({ at: e, cue: t, n, ms: r }) {
	let i = l(), a = t === "danger" || t === "remove" ? "#ed9455" : t === "ready" ? It.shield : "#d7c796";
	return /* @__PURE__ */ g("div", {
		className: "unst-fx-scene",
		style: {
			"--unst-fx-ms": `${r}ms`,
			color: a
		},
		children: [/* @__PURE__ */ h("div", {
			className: "unst-fx-cue",
			style: {
				left: e.x,
				top: e.y,
				width: e.w,
				height: e.h
			}
		}), /* @__PURE__ */ g("span", {
			className: "unst-fx-caption",
			style: {
				left: e.x + e.w / 2,
				top: Math.max(30, e.y + e.h / 2)
			},
			children: [i(nn[t]), n > 0 ? ` · ${n}` : ""]
		})]
	});
}
function an({ changes: e, ms: t, from: n }) {
	let r = l();
	return /* @__PURE__ */ g("div", {
		className: "unst-fx-scene",
		style: { "--unst-fx-ms": `${t}ms` },
		children: [n && /* @__PURE__ */ h("svg", {
			className: "unst-fx-geometry",
			width: "100%",
			height: "100%",
			"aria-hidden": !0,
			children: /* @__PURE__ */ h("rect", {
				className: "unst-fx-charge",
				x: n.x,
				y: n.y,
				width: n.w,
				height: n.h,
				fill: "none",
				stroke: "#e8dbad",
				strokeWidth: "3"
			})
		}), e.map(({ key: t, n, at: i, fallback: a, index: o }) => {
			let s = t === "armor" ? It.shield : n < 0 ? "#f69a6b" : "#e8dbad", c = t === "training" ? "games.unstoppable.training" : t === "level" ? "games.unstoppable.level" : Ot[t], l = a ? i.x + (o + 1) * i.w / (e.length + 1) : i.x + i.w / 2, u = Math.max(30, i.y + i.h / 2);
			return /* @__PURE__ */ g("div", {
				style: { color: s },
				children: [/* @__PURE__ */ h("div", {
					className: `unst-fx-cue${t === "armor" ? " unst-fx-shield" : ""}`,
					style: {
						left: i.x,
						top: i.y,
						width: i.w,
						height: i.h
					}
				}), /* @__PURE__ */ g("span", {
					className: "unst-fx-resource",
					style: {
						left: l,
						top: u
					},
					children: [/* @__PURE__ */ h("small", { children: r(c) }), /* @__PURE__ */ g("b", { children: [n > 0 ? "+" : "−", Math.abs(n)] })]
				})]
			}, t);
		})]
	});
}
function on({ from: e, to: t, cue: n, threat: r, ms: i }) {
	let a = l(), o = r ? t.w : 46, s = r ? t.h : 62;
	return /* @__PURE__ */ g("div", {
		className: "unst-fx-scene",
		style: {
			"--unst-fx-ms": `${i}ms`,
			color: "#d7c796"
		},
		children: [/* @__PURE__ */ h("div", {
			className: "unst-fx-transfer",
			style: {
				left: e.x + e.w / 2 - o / 2,
				top: e.y + e.h / 2 - s / 2,
				width: o,
				height: s,
				"--unst-fx-dx": `${t.x + t.w / 2 - e.x - e.w / 2}px`,
				"--unst-fx-dy": `${t.y + t.h / 2 - e.y - e.h / 2}px`
			},
			children: r ? /* @__PURE__ */ h(Wt, { card: r }) : /* @__PURE__ */ h("div", {
				className: "unst-fx-cardback",
				"aria-hidden": !0,
				children: "◈"
			})
		}), /* @__PURE__ */ h("span", {
			className: "unst-fx-caption",
			style: {
				left: t.x + t.w / 2,
				top: Math.max(30, t.y + t.h / 2)
			},
			children: a(nn[n])
		})]
	});
}
function sn({ at: e, threat: t }) {
	return /* @__PURE__ */ h("div", {
		className: "unst-fx-victim",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ h(Wt, { card: t })
	});
}
function cn({ data: e, from: t, to: n, ms: r, victim: i, flight: a }) {
	let o = l(), s = [
		"armor",
		"health",
		"credits",
		"actions"
	].includes(e.kind), c = !s && e.n > 0 && e.source !== e.target, u = e.kind === "echo", d = e.kind === "capacitor", f = u ? It.echo : e.kind === "armor" ? It.shield : s ? "#d7c796" : It.attack, p = t.x + t.w * .52, _ = t.y + t.h * .55, v = n.x + n.w / 2, y = n.y + n.h / 2, b = _, ee = {
		"--unst-fx-ms": `${r}ms`,
		color: f
	};
	return /* @__PURE__ */ g("div", {
		className: "unst-fx-scene",
		style: ee,
		children: [
			i && e.threat && /* @__PURE__ */ h(sn, {
				at: n,
				threat: e.threat
			}),
			/* @__PURE__ */ g("svg", {
				className: "unst-fx-geometry",
				width: "100%",
				height: "100%",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ g("g", {
						className: "unst-fx-charge",
						fill: "none",
						stroke: f,
						strokeWidth: "3",
						children: [/* @__PURE__ */ h("path", { d: `M${t.x - 5} ${b - 19}h${t.w + 10}v38h-${t.w + 10}z` }), /* @__PURE__ */ h("path", {
							d: `M${t.x + 8} ${b}h${t.w * .3}l${t.w * .18} ${_ - b}h${t.w * .34}`,
							strokeWidth: "6"
						})]
					}),
					c && /* @__PURE__ */ g(m, { children: [a && /* @__PURE__ */ g("g", {
						className: "unst-fx-flight",
						fill: "none",
						stroke: f,
						strokeWidth: d ? 5 : 9,
						strokeLinecap: "square",
						children: [/* @__PURE__ */ h("path", {
							pathLength: "1",
							d: d ? `M${p} ${_}L${p - 20} ${_ - 30}L${v + 25} ${y + 24}L${v} ${y}` : `M${p - 16} ${_ + 26}Q${p - 35} ${y + 25} ${v + 15} ${y - 24}`
						}), u && /* @__PURE__ */ h("path", {
							pathLength: "1",
							d: `M${p + 10} ${_ + 32}Q${p - 9} ${y + 31} ${v + 39} ${y - 18}`,
							strokeWidth: "5"
						})]
					}), /* @__PURE__ */ g("g", {
						className: "unst-fx-impact",
						fill: "none",
						stroke: f,
						strokeWidth: "4",
						style: { transformOrigin: `${v}px ${y}px` },
						children: [/* @__PURE__ */ h("path", {
							d: `M${v - 31} ${y + 32}L${v + 28} ${y - 34}M${v - 16} ${y + 40}L${v + 40} ${y - 22}`,
							strokeWidth: "9"
						}), [
							0,
							1,
							2,
							3,
							4,
							5
						].map((e) => {
							let t = e * Math.PI / 3;
							return /* @__PURE__ */ h("path", { d: `M${v + Math.cos(t) * 20} ${y + Math.sin(t) * 20}l${Math.cos(t) * 29} ${Math.sin(t) * 29}` }, e);
						})]
					})] }),
					s && /* @__PURE__ */ h("g", {
						className: "unst-fx-field",
						fill: `${f}15`,
						stroke: f,
						strokeWidth: "3",
						style: { transformOrigin: `${v}px ${y}px` },
						children: e.kind === "armor" ? /* @__PURE__ */ h("path", { d: `M${v} ${y - 42}l42 18v31l-42 35-42-35v-31z` }) : /* @__PURE__ */ h("path", { d: `M${v} ${y - 25}l31 25-31 25-31-25z` })
					}),
					!c && !s && /* @__PURE__ */ g("g", {
						className: "unst-fx-field",
						fill: "none",
						stroke: f,
						strokeWidth: "3",
						style: { transformOrigin: `${p}px ${_}px` },
						children: [/* @__PURE__ */ h("path", { d: `M${t.x - 7} ${t.y + 14}l20-20h${t.w - 4}v${t.h + 12}h-${t.w + 16}z` }), u && /* @__PURE__ */ h("path", { d: `M${t.x + 7} ${t.y}l20-20h${t.w - 4}v${t.h + 12}h-${t.w + 16}z` })]
					})
				]
			}),
			e.n !== 0 && e.kind !== "hostile" && /* @__PURE__ */ g("span", {
				className: "unst-fx-number",
				style: {
					left: v,
					top: y - 24
				},
				children: [s && e.n > 0 ? "+" : c ? "−" : "", e.n]
			}),
			(e.defeated || u || e.kind === "upgrade") && /* @__PURE__ */ h("span", {
				className: "unst-fx-caption",
				style: {
					left: v,
					top: Math.max(30, y + 22)
				},
				children: o(e.defeated ? "games.unstoppable.fx.defeat" : u ? "games.unstoppable.repeatCore" : "games.unstoppable.buy")
			})
		]
	});
}
var ln = {
	unstCombat(e, t) {
		let n = e.data, r = n.sourceAnchor ? t.anchor(n.sourceAnchor) : tn(t, n.source, n.effectKey), i = n.threat ? t.anchor(`threat:${n.target}`) : t.anchor(n.target), a = `threat-slot:${n.owner}:${n.slot}`, o = n.threat && !t.queued ? t.anchor(a) : null, s = o ?? i ?? (n.source === n.target ? r : null) ?? t.anchor(`seat:${n.owner}`);
		if (!s) return null;
		let c = r ?? s, l = t.queued ? Math.round(F(e) / 2) : F(e);
		return {
			ms: l,
			node: /* @__PURE__ */ h(cn, {
				data: n,
				from: c,
				to: s,
				ms: l,
				victim: !!o,
				flight: !!r && !!(o ?? i) && r !== s
			}),
			...o ? { hide: [a] } : {}
		};
	},
	unstCue(e, t) {
		let n = e.data, r = t.anchor(n.target) ?? t.anchor(`seat:${e.rid}`);
		if (!r) return null;
		let i = t.queued ? Math.round(F(e) / 2) : F(e);
		return {
			ms: i,
			node: /* @__PURE__ */ h(rn, {
				at: r,
				cue: n.cue,
				n: n.n,
				ms: i
			})
		};
	},
	unstResource(e, t) {
		let n = e.data, r = t.anchor(`seat:${e.rid}`), i = n.changes.flatMap((n, i) => {
			let a = t.anchor(`resource:${e.rid}:${n.key}`), o = a ?? r;
			return o ? [{
				...n,
				at: o,
				fallback: !a,
				index: i
			}] : [];
		});
		if (!i.length) return null;
		let a = t.queued ? Math.round(F(e) / 2) : F(e);
		return {
			ms: a,
			node: /* @__PURE__ */ h(an, {
				changes: i,
				ms: a,
				from: tn(t, n.source, n.effectKey)
			})
		};
	},
	unstMove(e, t) {
		let n = e.data, r = t.anchor(n.from), i = t.anchor(n.to), a = i ?? t.anchor(`seat:${e.rid}`);
		if (!a) return null;
		let o = t.queued ? Math.round(F(e) / 2) : F(e);
		return !r || !i || t.queued ? {
			ms: o,
			node: /* @__PURE__ */ h(rn, {
				at: a,
				cue: n.cue,
				n: 0,
				ms: o
			})
		} : {
			ms: o,
			node: /* @__PURE__ */ h(on, {
				from: r,
				to: i,
				cue: n.cue,
				threat: n.threat,
				ms: o
			}),
			...n.threat ? { hide: [n.to] } : {}
		};
	}
};
//#endregion
//#region src/games/unstoppable/endgame-review.tsx
function un({ board: e, renderResult: t, ...n }) {
	let s = l(), [c, u] = o(!0), [d, f] = o(null), p = a(null), m = a(null), _ = a(null);
	r(() => {
		if (!d) return;
		_.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let v = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, b = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), ne = {
		...n,
		...b
	};
	return /* @__PURE__ */ g("div", {
		className: "unstoppable-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ h("div", {
				className: "unstoppable-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ h("div", {
				className: "unstoppable-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ g("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), v(!1));
					},
					className: "unstoppable-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ g("header", {
							className: "unstoppable-endgame-heading",
							children: [/* @__PURE__ */ g("div", {
								className: "unstoppable-endgame-brand",
								children: [/* @__PURE__ */ h("span", {
									"aria-hidden": "true",
									children: O.icon
								}), s(O.nameKey)]
							}), /* @__PURE__ */ h("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.unstoppable.reviewHide"),
								title: s("games.unstoppable.reviewHide"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ h(ee, { size: 19 })
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "unstoppable-endgame-result",
							inert: d !== null,
							children: t(ne)
						}),
						d && /* @__PURE__ */ g("div", {
							className: "unstoppable-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								ref: _,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.unstoppable.reviewConfirmAgain" : "games.unstoppable.reviewConfirmLobby")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.unstoppable.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "unstoppable-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ g("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => v(!0),
					children: [
						/* @__PURE__ */ h(te, { size: 18 }),
						s("games.unstoppable.reviewShow"),
						/* @__PURE__ */ h(y, { size: 18 })
					]
				})
			})
		]
	});
}
function dn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: u, renderRowExtra: d, summary: f, navigation: p, content: _, afterRanking: v, scoreUnit: y, rankOf: te }) {
	let x = l(), S = c((e) => e.locale), [C, w] = o({}), T = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? ne(n, S) : e;
	}, E = (t, n) => te?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), ie = e.ranking.some((t) => e.scores?.[t] !== void 0), ae = (t, n) => /* @__PURE__ */ g("div", {
		className: "unstoppable-score-identity",
		children: [
			/* @__PURE__ */ g("span", {
				className: "unstoppable-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ h("span", {
					"aria-label": x("games.unstoppable.reviewWinner"),
					children: "♛ "
				}), ie && E(t, n)]
			}),
			/* @__PURE__ */ g("span", {
				className: "unstoppable-score-name",
				children: [T(t), t === r && /* @__PURE__ */ h("small", { children: x("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ g("small", {
				className: "unstoppable-score-autopilot",
				children: [
					/* @__PURE__ */ h(b, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), D = (t) => e.ranking.map((n) => /* @__PURE__ */ h("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ g("div", {
		className: "unstoppable-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ h(re, {}),
			p,
			/* @__PURE__ */ g("div", {
				className: "unstoppable-score-body",
				children: [
					f && /* @__PURE__ */ h("div", {
						className: "unstoppable-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ h("p", {
						className: "unstoppable-score-hints",
						children: x("session.hint.usedCount", { n: i })
					}),
					_ ?? (u?.length ? /* @__PURE__ */ h("div", {
						className: "unstoppable-score-table-scroll",
						children: /* @__PURE__ */ g("table", {
							className: "unstoppable-score-table",
							"aria-label": x(O.nameKey),
							children: [
								/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { scope: "col" }), /* @__PURE__ */ h(m, { children: e.ranking.map((t, n) => /* @__PURE__ */ h("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: ae(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ h("tbody", { children: u.map((e, t) => /* @__PURE__ */ g(n, { children: [/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ g("button", {
										type: "button",
										"aria-expanded": !!C[t],
										onClick: () => w((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ h(ee, { size: 15 }), e.label]
									}) : e.label
								}), D(e)] }), C[t] && e.details?.map((e, t) => /* @__PURE__ */ g("tr", {
									className: "unstoppable-score-sub",
									children: [/* @__PURE__ */ h("th", {
										scope: "row",
										children: e.label
									}), D(e)]
								}, t))] }, t)) }),
								ie && /* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: x("games.unstoppable.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ h("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ h("ol", {
						className: "unstoppable-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ g("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ g("div", {
								className: "unstoppable-score-rankline",
								children: [ae(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ g("strong", {
									className: "unstoppable-score-points",
									children: [e.scores[t], y && /* @__PURE__ */ h("small", { children: y })]
								})]
							}), d?.(t)]
						}, t))
					})),
					v,
					!!u?.length && d && /* @__PURE__ */ h("div", {
						className: "unstoppable-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ g("details", { children: [/* @__PURE__ */ h("summary", { children: T(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ g("footer", {
				className: "unstoppable-score-actions",
				children: [
					s && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: x("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: x("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ h("p", { children: x("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/unstoppable/endgame-scores.tsx
function fn(e) {
	let t = l(), n = e.public, r = n.victory ? [
		["base", "games.unstoppable.reviewBase"],
		["rounds", "games.unstoppable.reviewRounds"],
		["health", "games.unstoppable.reviewHealth"],
		["loops", "games.unstoppable.reviewLoops"],
		["transhumanist", "games.unstoppable.scoreTranshumanist"],
		["retire", "games.unstoppable.scoreRetire"],
		["coalition", "games.unstoppable.scoreCoalition"],
		["unstoppable", "games.unstoppable.scoreUnstoppable"]
	].map(([e, r]) => ({
		label: t(r),
		value: (t) => n.scoreParts[t]?.[e] ?? "—"
	})) : [], i = {
		7: "games.unstoppable.endingA",
		8: "games.unstoppable.endingB",
		9: "games.unstoppable.endingC",
		10: "games.unstoppable.endingD",
		17: "games.unstoppable.endingE",
		18: "games.unstoppable.endingF",
		19: "games.unstoppable.endingG",
		20: "games.unstoppable.endingH"
	};
	return /* @__PURE__ */ h(dn, {
		...e,
		renderRowExtra: void 0,
		rows: r,
		summary: /* @__PURE__ */ g(m, { children: [n.reason && /* @__PURE__ */ h("p", { children: t(n.reason) }), n.ending !== null && i[n.ending] && /* @__PURE__ */ h("p", { children: t(i[n.ending]) })] })
	});
}
//#endregion
//#region src/games/unstoppable/game-over.tsx
function pn(e) {
	return /* @__PURE__ */ h(fn, { ...e });
}
function mn(e) {
	return /* @__PURE__ */ h(un, {
		...e,
		board: /* @__PURE__ */ h(Yt, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ h(pn, { ...e })
	});
}
//#endregion
//#region src/games/unstoppable/game-over-row.tsx
var hn = {
	7: "games.unstoppable.endingA",
	8: "games.unstoppable.endingB",
	9: "games.unstoppable.endingC",
	10: "games.unstoppable.endingD",
	17: "games.unstoppable.endingE",
	18: "games.unstoppable.endingF",
	19: "games.unstoppable.endingG",
	20: "games.unstoppable.endingH"
};
function gn({ public: e, rid: t }) {
	let n = l(), r = e, i = r.scoreParts[t];
	if (!i) return null;
	let a = [
		["games.unstoppable.scoreBase", i.base],
		["games.unstoppable.scoreRounds", i.rounds],
		["games.unstoppable.scoreHealth", i.health],
		["games.unstoppable.scoreLoops", i.loops]
	], o = [
		["games.unstoppable.scoreTranshumanist", i.transhumanist],
		["games.unstoppable.scoreRetire", i.retire],
		["games.unstoppable.scoreCoalition", i.coalition],
		["games.unstoppable.scoreUnstoppable", i.unstoppable]
	];
	return /* @__PURE__ */ g("div", {
		className: "unst-over-row mt-2 space-y-2 text-xs text-ink-soft",
		children: [
			r.reason && /* @__PURE__ */ h("p", { children: n(r.reason) }),
			r.ending !== null && hn[r.ending] && /* @__PURE__ */ h("p", { children: n(hn[r.ending]) }),
			r.victory && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("div", {
				className: "flex flex-wrap gap-x-3 gap-y-1",
				children: a.map(([e, t]) => /* @__PURE__ */ h("span", { children: n(e, { n: t }) }, e))
			}), o.filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ g("p", { children: [
				n(e),
				" · ",
				n("games.unstoppable.scoreAchievement", { n: t })
			] }, e))] })
		]
	});
}
//#endregion
//#region src/games/unstoppable/options.tsx
var _n = {
	normal: "games.unstoppable.normal",
	hard: "games.unstoppable.hard",
	expert: "games.unstoppable.expert"
};
function vn({ value: e, onChange: t }) {
	let n = l(), r = j.safeParse(e), i = r.success ? r.data : j.parse({});
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ h(S, {
				title: n("games.unstoppable.optBoss"),
				columns: 3,
				children: [
					"harbinger",
					"triumvirate",
					"duomo"
				].map((e) => /* @__PURE__ */ h(x, {
					name: "unst-boss",
					value: e,
					checked: i.boss === e,
					label: n(Tt[e]),
					accent: O.accent,
					onChange: () => t({
						...i,
						boss: e
					})
				}, e))
			}),
			/* @__PURE__ */ h(S, {
				title: n("games.unstoppable.optDifficulty"),
				columns: 3,
				children: [
					"normal",
					"hard",
					"expert"
				].map((e) => /* @__PURE__ */ h(x, {
					name: "unst-difficulty",
					value: e,
					checked: i.difficulty === e,
					label: n(_n[e]),
					accent: O.accent,
					onChange: () => t({
						...i,
						difficulty: e
					})
				}, e))
			}),
			/* @__PURE__ */ h(C, {
				checked: i.expansion,
				label: n("games.unstoppable.optExpansion"),
				hint: n("games.unstoppable.optExpansionHint"),
				accent: O.accent,
				onChange: () => t({
					...i,
					expansion: !i.expansion
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/unstoppable/entry.tsx
var yn = {
	definition: St,
	View: Yt,
	bot: $t,
	describe: en,
	fx: ln,
	OverView: mn,
	RowView: gn,
	Options: vn,
	locales: {
		zh: {
			reviewBase: "胜利基础分",
			reviewRounds: "剩余回合",
			reviewHealth: "剩余生命",
			reviewLoops: "力量觉醒",
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			fx: {
				activate: "再次激活升级",
				attack: "发动攻击",
				discount: "费用减免",
				mark: "效果生效",
				reveal: "揭示卡牌",
				discard: "弃置卡牌",
				bottom: "放回牌库底部",
				bossCard: "首领牌加入弃牌",
				shuffle: "重组牌库",
				remove: "移除卡牌",
				danger: "危险推进",
				cleanup: "回合清理",
				ready: "重置盟友",
				story: "剧情推进",
				disable: "威胁效果已停用",
				defeat: "击败威胁",
				faction: "派系已改变",
				market: "市场已更新",
				draw: "加入手牌",
				refill: "威胁入场",
				limit: "已达上限"
			},
			damageLabel: "伤害",
			repeatCore: "重复核心效果",
			name: "孤勇英豪",
			desc: "构筑双面复合牌，联手击败首领",
			silver: "希维尔",
			junker: "拾荒客",
			viren: "维纶",
			council: "议会",
			kai: "凯·希维尔",
			zephyr: "泽弗",
			tiberius: "提比略",
			julida: "朱莉达",
			roux: "露",
			sima: "西玛",
			harbinger: "毁灭预兆",
			triumvirate: "三巨头",
			duomo: "杜莫之威",
			normal: "普通",
			hard: "困难",
			expert: "专家",
			optBoss: "首领",
			optDifficulty: "难度",
			optExpansion: "暴君之殇扩展",
			optExpansionHint: "加入扩展核心牌、升级牌及两名角色",
			playCostReduction: "打出此牌的行动费用减少 {{n}}",
			defense: "防御 {{n}}",
			characterPrompt: "选择你的角色",
			mainPrompt: "打出卡牌、耗用盟友或购买升级",
			effectPrompt: "选择下一项要结算的效果",
			targetPrompt: "选择效果的目标",
			resolving: "正在结算",
			levelPrompt: "升级：弃至三张手牌，可移除一张牌",
			refilling: "正在补充威胁",
			draftLevelPrompt: "选择一个可用等级的核心牌堆",
			draftPickPrompt: "选择一张核心牌加入手牌",
			draftBottomPrompt: "依次选择归还牌堆底部的牌",
			ragePrompt: "狂怒：弃置一名盟友",
			threatPrompt: "威胁正在攻击",
			marketPrompt: "选择要替换的升级牌",
			storyPrompt: "选择剧情行动",
			storyPayPrompt: "分摊剧情所需的费用",
			buy: "购买升级",
			chooseCard: "选择卡牌",
			dealDamage: "造成 {{n}} 点伤害",
			hitBoss: "对首领造成 {{n}} 点伤害",
			hitLocation: "对地点造成 {{n}} 点伤害",
			refreshAlly: "重置盟友",
			eliminateCard: "移除卡牌",
			destroyThreat: "消灭威胁",
			discardThreat: "弃置威胁",
			disableKeywords: "停用威胁的关键词与奖励",
			takeCard: "加入手牌",
			chooseEffect: "选择效果",
			resolveEffect: "结算效果",
			discardCard: "弃置手牌",
			pay: "支付 {{n}}",
			chooseLevel: "等级 {{n}}",
			chooseAmount: "选择 {{n}} 张",
			putBottom: "放到牌库底部",
			cycleUpgrade: "将升级牌放到牌堆底部",
			exchangeResources: "交换护甲与信用",
			forfeit: "放弃此项效果",
			forfeitRemaining: "放弃剩余效果",
			discardToThree: "弃置一张手牌",
			keepAll: "保留所有卡牌",
			continue: "继续",
			keepCard: "选择此牌",
			returnCoreBottom: "放到核心牌堆底部",
			rageDiscard: "弃置此盟友",
			finishMarket: "完成替换",
			takeDefeated: "将击败的牌加入手牌",
			redirectDefeated: "放到牌库底部并抽两张牌",
			playCard: "打出卡牌",
			exhaustAlly: "耗用盟友",
			chooseFaction: "选择派系",
			locationAction: "使用地点",
			finishVictory: "完成本回合并计分",
			finishMain: "结束主阶段",
			resumeMain: "继续主阶段",
			victory: "首领已被击败",
			lossHealth: "一名角色的生命降至零",
			lossDanger: "危险标记到达终点",
			lossThreats: "威胁牌已耗尽",
			errFinished: "本局已经结束",
			errChoice: "该选择已不可用，请重新选择",
			logVictory: "首领已被击败，可继续完成当前回合",
			logHurt: "{{name}}受到 {{n}} 点伤害",
			logEliminate: "{{name}}移除了「{{card}}」",
			logDestroy: "{{name}}消灭了「{{card}}」",
			logDefeat: "{{name}}击败了「{{card}}」",
			logDamage: "{{name}}对「{{card}}」造成 {{n}} 点伤害",
			logPlay: "{{name}}打出了「{{card}}」",
			logUpgrade: "{{name}}购买了「{{card}}」，支付 {{n}} 信用",
			logLevel: "{{name}}升至等级 {{n}}",
			logCrazed: "「{{card}}」因癫狂受到 {{n}} 点伤害",
			logStory: "进入剧情 {{n}}",
			logLocation: "{{name}}对地点造成 {{n}} 点伤害",
			turn: "回合 {{n}}",
			waiting: "等待{{name}}",
			health: "生命",
			armor: "护甲",
			credits: "信用",
			actions: "行动",
			level: "等级",
			training: "训练",
			danger: "危险",
			hand: "手牌",
			playArea: "在场卡牌",
			discard: "弃牌",
			battlefield: "战场",
			onDeck: "牌库顶",
			deck: "牌库",
			market: "升级市场",
			cores: "核心牌堆",
			boss: "首领",
			storyLabel: "剧情",
			location0: "隐秘库房",
			location1: "醒神剂集散中心",
			location2: "大三元赌场",
			locationDefeated: "已攻占",
			core: "核心",
			ally: "盟友",
			tactic: "战术",
			either: "战术或盟友",
			top: "上部升级",
			bottom: "下部升级",
			exhausted: "已耗用",
			ready: "可用",
			cost: "费用 {{n}}",
			actionCost: "支付 {{n}} 行动",
			creditCost: "支付 {{n}} 信用",
			attack: "攻击 {{n}}",
			threatHealth: "生命 {{n}}",
			remainingHealth: "剩余生命 {{n}}",
			reward: "击败奖励",
			onPlay: "打出时",
			onExhaust: "耗用时",
			onEnter: "入场时",
			onAcquire: "获得此牌时",
			onLeave: "离场时",
			passive: "在场时",
			inspect: "查看卡牌",
			close: "关闭",
			choose: "选择",
			moreActions: "更多行动",
			openChoices: "选择行动",
			noCards: "没有卡牌",
			noChoice: "等待结算",
			ownBattlefield: "你的战场",
			ownerBattlefield: "{{name}}的战场",
			ownedCard: "{{name}}的卡牌",
			upgradeTarget: "为「{{card}}」安装「{{upgrade}}」",
			score: "{{n}} 分",
			remainingRounds: "剩余 {{n}} 回合",
			victoryContinue: "胜利！可继续完成当前回合",
			storyDamage: "累计伤害 {{n}}",
			storyCredits: "累计贡献 {{n}}",
			storyNext: "下回合进入剧情 {{n}}",
			ending: "结局 {{n}}",
			endingA: "结局 A：击败贾科的机械躯体，阻止了他的行动；他的意识是否还存在，仍是未知数。",
			endingB: "结局 B：贾科落败，他的机械残骸被带走研究，海盗团的威胁暂时消退。",
			endingC: "结局 C：你与贾科达成秘密合作，以新的目标换取了他的配合。",
			endingD: "结局 D：交易完成，你加入了海盗们的行列，开始筹划自己的航行。",
			endingE: "结局 E：斯卡根在战斗中倒下，藤蛛们将他的躯体带回森林。",
			endingF: "结局 F：你利用森林中的陷阱制服了追击者，等待议会前来处理。",
			endingG: "结局 G：虫群被清除，斯卡根也在反击中落败，你领取了约定的赏金。",
			endingH: "结局 H：你付出了价款，将斯卡根送离星球，暂时摆脱了他的纠缠。",
			scoreBase: "胜利基础分 {{n}}",
			scoreHealth: "剩余生命 {{n}}",
			scoreLoops: "力量觉醒 {{n}} 分",
			scoreRounds: "剩余回合 {{n}} 分",
			scoreAchievement: "成就得分 {{n}}",
			disabledThreat: "关键词与击败奖励已被取消。",
			when: {
				upgradedUnite3: "此牌已升级且联合不少于 3",
				upgradedConspire: "此牌已升级且满足密谋条件",
				unite4: "联合不少于 4",
				conspire: "密谋",
				upgraded: "已升级",
				health7: "生命不高于 7",
				health5: "生命不高于 5",
				armor5: "护甲不低于 5",
				upgrades2: "手牌与在场卡牌共至少两个升级",
				upgrades4: "手牌、在场卡牌及弃牌共至少四个升级",
				unite3: "联合，至少三个派系",
				active3: "至少三个在场威胁",
				killed: "此牌已击败威胁",
				firstPlay: "本回合首次打出",
				kills2: "本回合已消灭至少两个威胁"
			},
			cycleAllUpgrades: "将全部市场升级放回牌堆底，然后补满市场",
			damageRequired: "伤害要求：{{n}}",
			cardsRequired: "每位玩家移除一张符合条件的手牌",
			armorCost: "支付 {{n}} 护甲",
			storyEliminate: "每位玩家移除一张等级不低于 {{n}} 的手牌。",
			storyFreeUpgrade: "选择一位玩家，免费安装一个升级。",
			storyDonation: "每位玩家移除一张手牌，按移除牌的总等级降低最终价款。",
			storyVictory: "触发胜利结局。",
			locationRules: "地点可以受到普通伤害与首领伤害。至少两个地点尚存时，首领伤害只能以地点为目标。",
			locationRules0: "击破时，每位玩家训练两次。击破后，每位玩家每回合可以支付 1 行动，训练一次并恢复 1 生命。",
			locationRules1: "击破时，每位玩家可以移除一张牌。击破后，每位玩家每回合可以支付 2 行动，移除一张牌。",
			locationRules2: "击破时，每位玩家可以支付 2 信用，造成 1 首领伤害。击破后，每位玩家每回合可以支付 1 行动与 2 信用，造成 1 首领伤害。",
			scoreLevels: "胜利后升级 {{n}} 次",
			scoreTranshumanist: "超越人类：全部非起始非首领牌均有升级",
			scoreRetire: "退休时刻：至少 15 信用",
			scoreCoalition: "联盟领袖：四个派系各至少两张牌",
			scoreUnstoppable: "孤勇英豪：胜利后在本回合再升两级",
			fast: "迅速",
			taunt: "嘲讽",
			rage: "狂怒",
			terror: "恐怖",
			crazed5: "癫狂 5",
			allPlayers: "每位玩家：{{text}}",
			repeatTimes: "{{text}}；执行 {{n}} 次",
			condition: "{{condition}}：{{text}}",
			levelCondition: "等级不低于 {{n}}：{{text}}",
			or: "或",
			then: "然后",
			effect: {
				damage: "造成 {{n}} 点伤害",
				bossDamage: "造成 {{n}} 点首领伤害",
				credits: "获得 {{n}} 信用",
				health: "恢复 {{n}} 生命",
				armor: "获得 {{n}} 护甲",
				actions: "获得 {{n}} 行动",
				loseHealth: "失去 {{n}} 生命",
				train: "训练 {{n}} 次",
				draw: "抽 {{n}} 张牌",
				drawBottom: "从牌库底部抽 {{n}} 张牌",
				refresh: "重置 {{n}} 名盟友",
				eliminate: "移除 {{n}} 张卡牌",
				destroy: "消灭 {{n}} 个威胁，不获得卡牌及奖励",
				defeat: "击败 {{n}} 个威胁",
				discardThreat: "弃置 {{n}} 个在场威胁",
				retrieve: "将{{zone}}中的一张牌加入手牌{{limit}}",
				draft: "从等级不高于 {{n}} 的核心牌堆顶获得一张牌",
				upgrade: "免费购买费用不高于 {{n}} 的升级",
				selfUpgrade: "免费为此牌安装一个升级",
				anyUpgrade: "免费购买一个升级",
				recycleEntireMarket: "将市场中的全部升级放到牌堆底部，再补满市场",
				recycleOneUpgrade: "将市场中的一个升级放到牌堆底部，再补满市场",
				discount: "下次购买升级少支付 {{n}} 信用",
				bargainDiscount: "下次折价少支付 {{n}} 信用",
				faction: "本回合额外视为一个所选派系",
				bargain: "折价 {{n}}：{{text}}",
				pay: "支付 {{n}} {{resource}}，{{text}}",
				exchange: "失去至多 {{n}} {{resource}}，造成等量伤害",
				repeat: "再次结算此核心牌的打出效果",
				allDamage: "对每个在场威胁造成 {{n}} 点伤害",
				bottom: "将 {{n}} 张手牌放到牌库底部",
				trade: "交换一张手牌与另一张在场卡牌的位置",
				recycleMarket: "将任意升级牌放到牌堆底部，补满市场",
				disableKeywords: "本回合停用一个威胁的所有关键词与奖励",
				swapResources: "任意交换护甲与信用",
				returnSelf: "将此牌收回手牌",
				playTop: "打出牌库顶牌并失去等同其费用的生命；威胁阶段后将其放回战场",
				shuffleThreat: "将一个在场威胁洗入牌库，再补充一个威胁",
				splitDamage: "造成 {{n}} 点伤害，可分配给至多等同行动费用的目标数",
				activateUpgrades: "执行此牌上所有升级的效果",
				revealCores: "查看可用等级牌堆顶三张牌，选择一张加入手牌",
				mark: "本回合获得：{{text}}",
				ignoreTaunt: "{{text}}，无视嘲讽",
				noBoss: "{{text}}，首领牌除外",
				maxLevel: "，等级不高于 {{n}}"
			},
			value: {
				focus: "同派系卡牌数",
				unite: "不同派系数",
				upgrades: "手牌与在场卡牌的升级数",
				sourceUpgrades: "此牌的升级数",
				missingHealth: "已失去的生命数",
				health: "当前生命",
				armor: "当前护甲",
				actions: "剩余行动",
				credits: "当前信用",
				silverDiscard: "弃牌中的希维尔卡牌数",
				tacticsDiscard: "弃牌中的战术数",
				active: "在场威胁数",
				wounded: "受伤的在场威胁数",
				level: "当前等级",
				danger: "危险等级"
			},
			special: {
				equalLevel: "失去至多 3 护甲，对一个威胁造成等量伤害",
				blood: "失去任意生命，造成两次等量伤害",
				progress: "X 为打出此牌支付的行动数。失去 X 生命与 X 信用，造成两次 X 伤害；生命不高于 6 时检索弃牌中等级不高于 4 的牌，生命不高于 2 时额外检索牌库中一张牌",
				sibling: "失去 1 生命，造成 3 点伤害；同派系卡牌不少于三张时，无须失去生命，且可额外造成 3 点伤害",
				discardHand: "弃置一张手牌，造成 3 点伤害",
				embrace: "失去 3 生命，造成 2 点和 1 点伤害；若因此失去最后一点生命，将生命设为 5",
				allyFromDeck: "从牌库或弃牌中选择一张盟友牌加入手牌；若翻找了牌库，将此牌放到牌库底部",
				tacticOnly: "结算此牌上所有战术升级的效果",
				freePayments: "额外执行此牌上所有升级的效果，无须支付其费用",
				ifSelfTrigger: "若将此升级安装于来源牌，结算该升级的效果",
				swapResources: "本回合可随时交换任意护甲与信用",
				armor: "失去任意生命，获得等量护甲",
				selfDraft: "移除此牌；分别查看等级 1、2、3 牌堆顶牌，选择一张加入手牌",
				small: "查看训练标记所在等级牌堆的顶三张牌，选择一张",
				level3Core: "结算等级 3 牌堆顶牌的效果，然后将其放到该牌堆底部",
				bottomThenReveal: "将一个在场威胁放到牌库底部，再将牌库顶威胁放入战场",
				drawSame: "将至多两张手牌放到牌库底部，每放一张抽一张牌",
				drawThenBottom: "按手牌与在场卡牌的不同派系数抽牌，然后将等量手牌放到牌库底部",
				onDeckDraw: "若击败牌库顶威胁，获得 1 行动",
				overkillCredits: "获得等同溢出伤害的信用",
				reduceCostOnKill: "若击败威胁，本回合此牌费用减少 2",
				extraActiveCost2: "可额外支付 2 行动，消灭一个在场威胁",
				includeDeck: "包括牌库顶威胁",
				random: "随机选择",
				self: "此牌",
				other: "此牌以外的盟友",
				wounded: "仅限受伤的威胁",
				active: "仅限在场威胁",
				onDeck: "仅限牌库顶威胁",
				improvise: "本回合首次打出时，随机两张手牌在本回合费用减少 1",
				playedDamage: "本回合你打出的费用不低于 2 的牌额外造成 2 点伤害",
				playedCost: "本回合你打出的原本费用不低于 2 的牌可少支付 1 行动",
				bargainDamage: "本回合每次执行折价效果，造成 3 点伤害",
				endCredits: "本回合结束时获得 2 信用",
				tacticUpgradeDamage: "本回合你打出的战术牌，其每个升级额外造成 1 点伤害",
				hasJunker: "手牌或在场有拾荒客卡牌",
				hasSilver: "手牌或在场有希维尔卡牌",
				hasViren: "手牌或在场有维纶卡牌"
			},
			passives: {
				embrace: "手牌或在场生命恢复效果不受此牌影响",
				trainRequired: "本回合训练后才可打出",
				upgradeBuyDamage2Health1: "每次购买升级，造成 2 点伤害并恢复 1 生命",
				killActions1: "每次击败威胁，获得 1 行动",
				alliesActions1Damage3: "你的盟友耗用时额外获得 1 行动并造成 3 点伤害",
				otherPlayDamage1: "每次打出另一张牌，造成 1 点伤害",
				allyTacticUpgrades: "可安装战术升级；打出时不触发这些升级",
				anyFaction: "本回合额外视为一个所选派系",
				uniteCostReduction: "费用减少手牌与在场卡牌的不同派系数",
				killCredits1: "每次击败威胁，获得 1 信用",
				chooseFaction: "每回合可选择一个额外派系",
				redirectKills: "可将击败的非首领牌放到牌库底部，并抽两张牌",
				actionDamage2: "每次获得 1 行动，造成 2 点伤害",
				doubleExhaust: "所有盟友耗用时额外执行其效果一次",
				trainDamage2: "每次训练，造成 2 点伤害",
				blockedCredits: "每次护甲抵挡 1 点伤害，获得 1 信用",
				bossProtected: "进入手牌时造成 1 点首领伤害，然后弃置；不能移除或升级"
			},
			story: {
				goMithras: "前往密特拉斯",
				goVirenos: "前往维雷诺斯",
				intimidate: "威吓情报贩子",
				buyInfo: "购买情报",
				defeat: "击败对手",
				bribe: "贿赂",
				teachLesson: "教训奸商",
				support: "提供资金",
				wait: "架起护盾等待时机",
				offer: "献上卡牌",
				donate: "捐赠信用",
				counterattack: "发起反击",
				killKrenko: "击败贾科",
				duel: "赢得决斗",
				price: "支付价款",
				accept: "接受交易",
				contribute: "捐赠一张卡牌",
				bounty: "完成悬赏",
				infiltrate: "潜入据点",
				finishPrey: "击败猎物",
				release: "释放猎物",
				bluff: "虚张声势",
				deal: "达成交易",
				cutLegs: "斩断肢足",
				outrun: "摆脱追击",
				resistArrest: "反抗逮捕",
				escape: "逃脱",
				threaten: "发出威胁",
				fightSkargen: "对抗斯卡根",
				counter: "击退敌人",
				exterminate: "清除虫群",
				paySkargen: "支付斯卡根的价款",
				giveUpgrade: "选择获得免费升级的玩家",
				contributeAmount: "贡献 {{n}}",
				loseCredit: "失去 1 信用",
				takeDamage: "受到 {{n}} 点伤害",
				extraThreat: "额外补充一个威胁",
				s00: "面见发明家",
				t00: "所有角色达到等级 2 后，选择一个目的地。",
				s01: "调查可疑的小酒馆",
				t01: "造成每位玩家 3 点伤害，或共同支付每位玩家 3 信用。",
				s02: "太空海盗爪牙",
				t02: "威胁阶段：每位玩家受到 1 点伤害。",
				s03: "腐败的店长",
				t03: "威胁阶段：每位玩家支付 1 信用，否则受到等同当前信用数的伤害。",
				s04: "太空海盗援军",
				t04: "威胁阶段：每位玩家受到 3 点伤害。",
				s05: "引起贾科的注意",
				t05: "每当玩家支付信用，在此牌上放置等量伤害，降低捐赠费用。",
				s06: "当地警队到达",
				t06: "威胁阶段：每位玩家弃置一张手牌，否则受到 1 点伤害。",
				s07: "贾科亲自出马",
				t07: "必须在一个回合内完成伤害要求。威胁阶段：受到 3 点伤害；没有护甲时额外受到 1 点。",
				s08: "贾科要将你碎尸万段",
				t08: "回合开始时，若危险格无彩色边框或不含移除效果，将卡牌 #4 放回场中。必须在一个回合内完成伤害要求。威胁阶段：每位玩家受到 2 点伤害。",
				s09: "贾科愿意配合",
				t09: "威胁阶段：弃置一张等级不低于 3 的手牌，否则失去 1 信用。",
				s10: "贾科提出了一个建议",
				t10: "可捐赠手牌，按等级降低最终价款。威胁阶段：弃置一张手牌，否则受到 10 点伤害。",
				s11: "到达维雷诺斯",
				t11: "选择完成悬赏或支付费用潜入据点。",
				s12: "你困住了一头鹿",
				t12: "威胁阶段：每位玩家受到 1 点伤害。",
				s13: "收集信息",
				t13: "威胁阶段：每位玩家支付 2 信用，否则受到 1 点伤害。",
				s14: "你听到一阵响动",
				t14: "幼虫群随追逐入场；完成此剧情时移除幼虫群。",
				s15: "希维尔家族亲信",
				t15: "威胁阶段：弃置一张手牌，否则受到 1 点伤害。",
				s16: "后巷会面",
				t16: "每个威胁阶段提高 1 点威胁，最多为等级 5 的移除要求。",
				s17: "为伊利斯复仇的斯卡根",
				t17: "所有在场威胁额外获得恐怖。威胁阶段：每位玩家受到 3 点伤害。",
				s18: "斯卡根的追杀",
				t18: "必须在一个回合内完成伤害要求。威胁阶段：受到 1 点伤害；没有护甲时额外受到 3 点。",
				s19: "斯卡根召唤了伊利斯",
				t19: "价款增加幼虫群的当前数量。",
				s20: "滔滔不绝的斯卡根",
				t20: "手牌与在场卡牌的升级数降低价款。购买升级时，目标牌每有一个空槽，费用减少 1 信用。清理阶段：每位玩家支付 2 信用，否则额外补充一个威胁。",
				s21: "伊利斯的幼崽",
				t21: "每次维持阶段按危险等级增加虫群；伤害可减少虫群。威胁阶段：受到等同虫群数量的伤害。",
				s22: "剧情费用说明",
				t22: "支付选项费用后，执行效果并翻面查看结果。伤害、信用与行动费用乘以玩家人数；伤害可跨回合累积，注明限时的选项除外。两名玩家可共同分担信用或行动费用。移除要求由每位玩家各自从手牌移除一张达到指定等级的卡牌；护甲费用由一位玩家独自支付。"
			},
			rules: "目标：击败首领。单人操控一名角色；双人合作，各操控一名角色。\n· 任意角色生命降至零，或危险标记到达终点，立即失败。\n准备：每人选择角色，获得 10 生命、3 信用，抽三张起始手牌。\n· 起始牌库有六张劈砍、一张备用资金和三张角色牌。\n· 核心面与威胁面属于同一张牌；上下升级同时改变这两面。\n· 只有在场和牌库顶的威胁面可以查看。\n每回合五阶段：\n· 维持：获得 3 行动，重置盟友；生命与护甲上限 10，行动上限 6。\n· 选牌：从训练标记所在等级或更低的核心牌堆选牌。\n· 单人翻三张，保留一张；双人各翻两张，每组各取一张，可以互选。\n· 保留的核心与普通威胁堆顶盲配，加入手牌；剩余核心按自选顺序归底。\n· 选牌结束后，将训练标记移回等级标记处。\n· 主阶段：任意顺序打出手牌、耗用盟友、购买升级。\n· 每个行动须完整结算，之后任一玩家才可开始下一个行动。\n· 打出卡牌须支付行动费用；盟友每次耗用只能选择一个耗用分支。\n· 只能升级手牌与在场卡牌；每张牌最多安装一个上部和一个下部升级。\n· 匹配升级所示派系少付 2 信用；安装升级不会赋予派系。\n· 威胁：在场威胁逐个造成等同攻击值的伤害，先扣护甲再扣生命。\n· 牌库顶威胁不攻击；威胁受伤不会降低攻击值。\n· 清理：弃置战术，清空行动与护甲，补场后推进危险。\n· 补场至三个非迅速威胁在场，且牌库顶不是迅速威胁。\n· 普通跳过绿色格，困难跳过黄色格，专家跳过红色格；只跳所选颜色。\n战斗与升级：\n· 威胁生命等于攻击加防御，伤害跨回合保留；可以攻击任一玩家的威胁。\n· 击败后先将整张牌交给其战场所属者，再由完成击杀者获得奖励。\n· 消灭威胁会移除整张牌，不获得卡牌或击败奖励。\n· 主阶段牌库空且没有在场威胁，或清理补场时牌库空，立即升级。\n· 等级与训练标记各前进一格；弃置所有在场卡牌，并弃至三张手牌。\n· 可移除手牌或弃牌中的一张牌；处理首领效果，然后洗弃牌成为新牌库。\n· 升级等事件立即中断；处理完后继续原效果，即使来源已离场。\n· 效果可自由排序或放弃；同一实例的同一效果在本回合第四次结算后，移除此牌。\n关键词：\n· 密谋要求另一张同派系牌；专注计算手牌与在场同派系牌数。\n· 联合计算手牌与在场的不同派系数；折价按同派系牌数减费，最低为零。\n· 已升级要求此牌至少安装一个升级。\n· 迅速不占准备和清理补场时的三个威胁名额。\n· 同一战场有嘲讽时，伤害必须先以嘲讽威胁为目标。\n· 威胁阶段每个狂怒迫使玩家弃置一名盟友。\n· 每次以恐怖威胁为伤害目标，失去 1 行动；零行动时仍可攻击。\n· 癫狂 5 揭示时，若所属玩家生命不高于 5，该威胁对自己造成 2 点伤害。\n· 癫狂、狂怒、恐怖可以叠加；迅速和嘲讽不叠加。\n首领：\n· 毁灭预兆与三巨头的专属牌进入手牌时，造成首领伤害并弃置。\n· 三巨头的地点可受到普通伤害；至少两个地点尚存时，首领伤害只能打地点。\n· 杜莫需要完成剧情分支并触发结局；双人可以分摊剧情的信用与行动费用。\n计分：胜利后可以继续当前回合，结束后按每名玩家分别计分。\n· 普通 100、困难 200、专家 300；每个剩余回合 10 分，另加剩余生命。\n· 每次因第四次效果移除卡牌，获得 10 分。\n· 持有至少 15 信用、全部非起始非首领牌均有升级，分别获得 10 分。\n· 四个派系各至少两张牌，获得 10 分。\n· 胜利后在本回合再升两级，获得 50 分；不再开始新回合。",
			cards: {
				c12800: "备用资金",
				c12803: "劈砍",
				c13600: "2米之下",
				c13601: "献血",
				c13602: "希维尔家族亲信",
				c13603: "不义之财",
				c13604: "危险交易",
				c13605: "突破极限",
				c13606: "罢工运动",
				c13607: "嘉德维克的小店",
				c13608: "冲动的议员",
				c13609: "雇佣枪手",
				c13610: "忠犬",
				c13611: "闲逛",
				c13612: "荒地取材",
				c13613: "光学辅助",
				c13614: "电镀火花",
				c13615: "暗中密谋",
				c13616: "忠诚客户",
				c13617: "“铁锤”",
				c13618: "数据传输",
				c13619: "JMAJ-99 回收机器人",
				c13620: "亲维纶人士",
				c13621: "血之契约",
				c13622: "本地目标",
				c13623: "和平协议",
				c13400: "废品奇才",
				c13401: "蛮力",
				c13402: "幻境",
				c13403: "闪象",
				c13404: "升级接口",
				c13405: "爱的抱抱",
				c13406: "3米之下",
				c13407: "血之盟约",
				c13408: "流连生手",
				c13409: "呼叫守卫",
				c13410: "维纶协作",
				c13411: "新计划",
				c13412: "维纶阵型",
				c13413: "卡利加里废料场",
				c13414: "集中意志",
				c13415: "区域目标",
				c13416: "强忍伤痛",
				c13417: "无力争论",
				c13418: "剑术大师的教导",
				c13419: "虚弱傀儡",
				c13420: "亲维纶者",
				c13421: "私人教官",
				c13422: "高效光学辅助",
				c13423: "维纶战术",
				c13424: "训练场",
				c13425: "堂中之影",
				c13426: "反抗军抵抗社",
				c13427: "随机应变",
				c13428: "无赖黑客",
				c13429: "大使",
				c13430: "巷战悬赏",
				c13700: "超频",
				c13701: "国家目标",
				c13702: "雷普拉医生",
				c13703: "掌控局势",
				c13704: "反抗军的支援",
				c13705: "隐蔽酒馆",
				c13706: "发现秘密",
				c13707: "维纶战略",
				c13708: "将军的青睐",
				c13709: "废品猎人",
				c13710: "旧时荣光",
				c13711: "资深军官",
				c13712: "回报",
				c13713: "集成光学辅助",
				c13714: "金手嘉德维克",
				c13715: "皇家铁匠",
				c13716: "公敌",
				c13717: "暗中利刃",
				c13718: "力量释放",
				c13719: "附魔暗影猎手",
				c13720: "护盾爆破",
				c13721: "家族秘密",
				c13722: "地下联系",
				c13723: "嘉德维克保全公司",
				c13800: "受启智士",
				c13801: "维纶的反抗",
				c13802: "双持",
				c13803: "清理人索尔",
				c13804: "全球目标",
				c13805: "保存证明",
				c13806: "不安的协议",
				c13807: "呼叫援助",
				c13808: "爆破专家",
				c13809: "兄妹相争",
				c13810: "希维尔说客·安",
				c13811: "优化生产",
				c13812: "八爪鼠小小",
				c13813: "呼叫帮手",
				c13814: "家族盟约",
				c13815: "5米之下",
				c13816: "维纶招募官",
				c13817: "公平交易",
				c13818: "回收战舰",
				c13819: "小玩意儿",
				c13820: "清理街道",
				c13821: "卡恩伯爵",
				c13822: "维纶档案科斯",
				c13823: "废土黄金",
				c13900: "铸剑为犁",
				c13901: "团购优惠",
				c13902: "监视者卡利加里",
				c13903: "家族医师",
				c13906: "放逐",
				c13907: "致命“事故”",
				c13908: "嘉德维克的总店",
				c13909: "掌控意志",
				c13910: "埋伏",
				c13911: "“致命”事故",
				c13912: "议会维和队",
				c13913: "10米之下",
				c13914: "首席议员卡德兰·派尔",
				c13915: "联席会议",
				c13916: "唤星者法利纳",
				c13917: "拾荒",
				c14100: "公开起义",
				c14101: "进步的代价",
				c14102: "希维尔之力",
				c14103: "残暴突袭",
				c14104: "卡纳杜X",
				c14106: "起义",
				c14107: "拦路摩托",
				c14108: "沃利将军",
				c14109: "医用纳米材料",
				c14110: "反抗军之力",
				c14111: "血债",
				c14112: "店主由纪",
				c14113: "免许皆传·吴",
				c14114: "精英维和队",
				c14115: "13米之下",
				c14116: "和平共存",
				c14117: "天恩女爵",
				c14200: "护卫小队",
				c14201: "力量调谐",
				c14202: "生意手段",
				c14203: "宠物藤蛛点点",
				c14204: "王位继承人",
				c14205: "热心议员",
				c14300: "反抗军网络",
				c14301: "生产工具",
				c14302: "工人联合",
				c14303: "大猫维斯帕",
				c14304: "夜市",
				c14305: "创造性",
				c14400: "持权首领",
				c14401: "实施制裁",
				c14402: "渔翁得利",
				c14403: "奥尔达姑妈",
				c14404: "挺身而出",
				c14405: "救援",
				u12100: "维纶英勇勋章",
				u12101: "联网",
				u12102: "拾荒客捕兽夹",
				u12103: "自动追踪",
				u12104: "忠诚勋章",
				u12105: "晶化",
				u12106: "复制仪",
				u12107: "通讯上行",
				u12108: "固守",
				u12200: "激光手枪",
				u12201: "蛮力",
				u12202: "千瓦电容器",
				u12203: "英勇勋章",
				u12204: "伙伴",
				u12205: "升华仪式",
				u12206: "出租悬浮车",
				u12207: "医用肾上腺素",
				u12208: "连发枪",
				u14900: "液体铠甲",
				u14901: "速效恢复药",
				u14902: "重装",
				u14903: "维纶冥想术",
				u14904: "醒神剂",
				u14905: "投射护盾",
				u14906: "“合理”费用",
				u14907: "后巷交易",
				u14908: "黑市肾上腺素",
				u15000: "影像增强",
				u15001: "意识链接",
				u15002: "数据库",
				u15004: "悬赏",
				u15005: "两千瓦电容器",
				u15006: "标记目标",
				u15007: "绝密文件",
				t1800: "基因改造人",
				t1801: "基因改造人",
				t1802: "基因改造人",
				t1803: "秘社信徒",
				t1804: "秘社信徒",
				t1805: "秘社信徒",
				t1806: "三巨头队长",
				t1807: "情报骇客",
				t1808: "情报骇客",
				t1809: "三巨头爪牙",
				t1810: "三巨头爪牙",
				t1811: "三巨头爪牙",
				t1900: "金鸲",
				t1901: "维纶复国者",
				t1902: "维纶雄鹿",
				t1903: "藤蛛",
				t1905: "枯木追踪者",
				t2000: "沙母",
				t2001: "法外神枪手",
				t2002: "越野车",
				t2003: "妖兽",
				t2005: "豪吼者",
				t90000: "维纶鹿",
				t90001: "谷神星扒手",
				t90002: "暗巷刀客",
				t90003: "摩托拾荒客",
				t90004: "孢子怪",
				t1700: "秘社信徒",
				t1701: "秘社信徒",
				t1702: "秘社档案员",
				t1703: "秘社档案员",
				t1100: "三巨头线人",
				t1103: "三巨头线人",
				t1101: "三巨头打手",
				t1102: "三巨头枪手",
				c1700: "毁灭预兆秘社",
				c1701: "毁灭预兆秘社",
				c1702: "毁灭预兆秘社",
				c1703: "毁灭预兆秘社",
				c1100: "三巨头爪牙",
				c1101: "三巨头爪牙",
				c1102: "三巨头爪牙",
				c1103: "三巨头爪牙"
			}
		},
		en: {
			reviewBase: "Victory",
			reviewRounds: "Remaining rounds",
			reviewHealth: "Remaining health",
			reviewLoops: "Power awakening",
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			fx: {
				activate: "Upgrades reactivated",
				attack: "Attack",
				discount: "Cost reduction",
				mark: "Effect active",
				reveal: "Card revealed",
				discard: "Cards discarded",
				bottom: "Returned to deck bottom",
				bossCard: "Boss card added to discard",
				shuffle: "Deck reshuffled",
				remove: "Card removed",
				danger: "Danger advances",
				cleanup: "Turn cleanup",
				ready: "Allies refreshed",
				story: "Story advances",
				disable: "Threat effects disabled",
				defeat: "Threat defeated",
				faction: "Faction changed",
				market: "Market updated",
				draw: "Added to hand",
				refill: "Threat enters",
				limit: "Limit reached"
			},
			damageLabel: "Damage",
			repeatCore: "Repeat core effect",
			name: "Unstoppable",
			desc: "Build double-sided cards and defeat a formidable boss",
			silver: "Silver",
			junker: "Junker",
			viren: "Viren",
			council: "Council",
			kai: "Kai Silver",
			zephyr: "Zephyr",
			tiberius: "Tiberius",
			julida: "Julida",
			roux: "Roux",
			sima: "Sima",
			harbinger: "The Harbinger",
			triumvirate: "The Triumvirate",
			duomo: "Duomo’s Menace",
			normal: "Normal",
			hard: "Hard",
			expert: "Expert",
			optBoss: "Boss",
			optDifficulty: "Difficulty",
			optExpansion: "Tyrant’s End",
			optExpansionHint: "Include expansion cores, upgrades, and two characters",
			playCostReduction: "Reduce this card’s action cost by {{n}}",
			defense: "Defense {{n}}",
			characterPrompt: "Choose your character",
			mainPrompt: "Play cards, exhaust allies, or buy upgrades",
			effectPrompt: "Choose the next effect to resolve",
			targetPrompt: "Choose a target",
			resolving: "Resolving",
			levelPrompt: "Level up: discard to three; you may eliminate a card",
			refilling: "Refilling the battlefield",
			draftLevelPrompt: "Choose an available core deck",
			draftPickPrompt: "Choose a core to add to your hand",
			draftBottomPrompt: "Choose the order for the bottom of the deck",
			ragePrompt: "Rage: discard an ally",
			threatPrompt: "Threats are attacking",
			marketPrompt: "Choose upgrades to cycle",
			storyPrompt: "Choose a story action",
			storyPayPrompt: "Contribute to the story cost",
			buy: "Buy upgrade",
			chooseCard: "Choose card",
			dealDamage: "Deal {{n}} damage",
			hitBoss: "Deal {{n}} boss damage",
			hitLocation: "Deal {{n}} damage to a location",
			refreshAlly: "Refresh ally",
			eliminateCard: "Eliminate card",
			destroyThreat: "Destroy threat",
			discardThreat: "Discard threat",
			disableKeywords: "Disable keywords and rewards",
			takeCard: "Add to hand",
			chooseEffect: "Choose effect",
			resolveEffect: "Resolve effect",
			discardCard: "Discard a hand card",
			pay: "Pay {{n}}",
			chooseLevel: "Level {{n}}",
			chooseAmount: "Choose {{n}} cards",
			putBottom: "Put on bottom of deck",
			cycleUpgrade: "Cycle upgrade",
			exchangeResources: "Exchange armor and credits",
			forfeit: "Forfeit this effect",
			forfeitRemaining: "Forfeit remaining effects",
			discardToThree: "Discard a card",
			keepAll: "Keep all cards",
			continue: "Continue",
			keepCard: "Keep this card",
			returnCoreBottom: "Return to core deck bottom",
			rageDiscard: "Discard this ally",
			finishMarket: "Finish cycling",
			takeDefeated: "Take the defeated card",
			redirectDefeated: "Put on deck bottom and draw two",
			playCard: "Play card",
			exhaustAlly: "Exhaust ally",
			chooseFaction: "Choose a faction",
			locationAction: "Use location",
			finishVictory: "Finish turn and score",
			finishMain: "Finish main phase",
			resumeMain: "Resume main phase",
			victory: "Boss defeated",
			lossHealth: "A character reached zero health",
			lossDanger: "The danger marker reached the end",
			lossThreats: "No threat cards remain",
			errFinished: "This game has ended",
			errChoice: "That choice is no longer available",
			logVictory: "Boss defeated; finish the current turn",
			logHurt: "{{name}} takes {{n}} damage",
			logEliminate: "{{name}} eliminates {{card}}",
			logDestroy: "{{name}} destroys {{card}}",
			logDefeat: "{{name}} defeats {{card}}",
			logDamage: "{{name}} deals {{n}} damage to {{card}}",
			logPlay: "{{name}} plays {{card}}",
			logUpgrade: "{{name}} buys {{card}} for {{n}} credits",
			logLevel: "{{name}} reaches level {{n}}",
			logCrazed: "{{card}} takes {{n}} Crazed damage",
			logStory: "Story {{n}} begins",
			logLocation: "{{name}} deals {{n}} damage to a location",
			turn: "Turn {{n}}",
			waiting: "Waiting for {{name}}",
			health: "Health",
			armor: "Armor",
			credits: "Credits",
			actions: "Actions",
			level: "Level",
			training: "Training",
			danger: "Danger",
			hand: "Hand",
			playArea: "In play",
			discard: "Discard",
			battlefield: "Battlefield",
			onDeck: "On deck",
			deck: "Deck",
			market: "Upgrade market",
			cores: "Core decks",
			boss: "Boss",
			storyLabel: "Story",
			location0: "Hidden Warehouse",
			location1: "Stimulant Distribution Center",
			location2: "Grand Triad Megacasino",
			locationDefeated: "Captured",
			core: "Core",
			ally: "Ally",
			tactic: "Tactic",
			either: "Tactic or ally",
			top: "Top upgrade",
			bottom: "Bottom upgrade",
			exhausted: "Exhausted",
			ready: "Ready",
			cost: "Cost {{n}}",
			actionCost: "Pay {{n}} actions",
			creditCost: "Pay {{n}} credits",
			attack: "Attack {{n}}",
			threatHealth: "Health {{n}}",
			remainingHealth: "{{n}} health left",
			reward: "Defeat reward",
			onPlay: "When played",
			onExhaust: "When exhausted",
			onEnter: "On entering play",
			onAcquire: "When acquired",
			onLeave: "On leaving play",
			passive: "While in play",
			inspect: "Inspect card",
			close: "Close",
			choose: "Choose",
			moreActions: "More actions",
			openChoices: "Choose an action",
			noCards: "No cards",
			noChoice: "Waiting for resolution",
			ownBattlefield: "Your battlefield",
			ownerBattlefield: "{{name}}’s battlefield",
			ownedCard: "{{name}}’s card",
			upgradeTarget: "Attach {{upgrade}} to {{card}}",
			score: "{{n}} points",
			remainingRounds: "{{n}} turns remaining",
			victoryContinue: "Victory! You may finish the current turn",
			storyDamage: "Accumulated damage {{n}}",
			storyCredits: "Contributions {{n}}",
			storyNext: "Story {{n}} begins next turn",
			ending: "Ending {{n}}",
			endingA: "Ending A: Krenko’s body is defeated, though his consciousness may survive.",
			endingB: "Ending B: Krenko falls, and his remains are taken away for study.",
			endingC: "Ending C: You strike a secret agreement with Krenko and offer him new targets.",
			endingD: "Ending D: The bargain is made, and you join the pirates to plan your own voyage.",
			endingE: "Ending E: Skargen falls in battle, and the vinespiders carry him into the forest.",
			endingF: "Ending F: Your forest trap disables the pursuer, leaving the Council to collect him.",
			endingG: "Ending G: The Brood is cleared and Skargen is defeated; you collect the bounty.",
			endingH: "Ending H: You pay to send Skargen off-world and gain a respite from his pursuit.",
			scoreBase: "Victory {{n}}",
			scoreHealth: "Remaining health {{n}}",
			scoreLoops: "Power Within {{n}}",
			scoreRounds: "Rounds remaining {{n}}",
			scoreAchievement: "Achievement {{n}}",
			disabledThreat: "Keywords and defeat rewards are disabled.",
			when: {
				upgradedUnite3: "Upgraded and Unite at least 3",
				upgradedConspire: "Upgraded and Conspire",
				unite4: "Unite at least 4",
				conspire: "Conspire",
				upgraded: "Upgraded",
				health7: "Health at most 7",
				health5: "Health at most 5",
				armor5: "Armor at least 5",
				upgrades2: "At least two upgrades in hand and play",
				upgrades4: "At least four upgrades in hand, play, and discard",
				unite3: "Unite with at least three factions",
				active3: "At least three active threats",
				killed: "This card defeated a threat",
				firstPlay: "First play this turn",
				kills2: "At least two threats destroyed this turn"
			},
			cycleAllUpgrades: "Return all market upgrades to the bottom, then refill",
			damageRequired: "Damage required: {{n}}",
			cardsRequired: "Each player eliminates an eligible hand card",
			armorCost: "Spend {{n}} armor",
			storyEliminate: "Each player eliminates a hand card of level {{n}} or higher.",
			storyFreeUpgrade: "Choose one player to install an upgrade for free.",
			storyDonation: "Each player eliminates a hand card; reduce the final price by their total level.",
			storyVictory: "Trigger a winning ending.",
			locationRules: "Locations take normal and boss damage. With at least two remaining, boss damage must target locations.",
			locationRules0: "When defeated, each player trains twice. Then, once per turn each player may spend 1 action to train once and recover 1 health.",
			locationRules1: "When defeated, each player may eliminate a card. Then, once per turn each player may spend 2 actions to eliminate a card.",
			locationRules2: "When defeated, each player may spend 2 credits to deal 1 boss damage. Then, once per turn each player may spend 1 action and 2 credits to deal 1 boss damage.",
			scoreLevels: "{{n}} level-ups after victory",
			scoreTranshumanist: "Transhumanist: all non-starting non-boss cards upgraded",
			scoreRetire: "Time to Retire: at least 15 credits",
			scoreCoalition: "Coalition Leader: two cards of each faction",
			scoreUnstoppable: "Become Unstoppable: level up twice after victory",
			fast: "Fast",
			taunt: "Taunt",
			rage: "Rage",
			terror: "Terror",
			crazed5: "Crazed 5",
			allPlayers: "Each player: {{text}}",
			repeatTimes: "{{text}}; {{n}} times",
			condition: "{{condition}}: {{text}}",
			levelCondition: "Level {{n}} or higher: {{text}}",
			or: "or",
			then: "then",
			effect: {
				damage: "Deal {{n}} damage",
				bossDamage: "Deal {{n}} boss damage",
				credits: "Gain {{n}} credits",
				health: "Gain {{n}} health",
				armor: "Gain {{n}} armor",
				actions: "Gain {{n}} actions",
				loseHealth: "Lose {{n}} health",
				train: "Train {{n}} times",
				draw: "Draw {{n}} cards",
				drawBottom: "Draw {{n}} cards from deck bottom",
				refresh: "Refresh {{n}} allies",
				eliminate: "Eliminate {{n}} cards",
				destroy: "Destroy {{n}} threats without taking cards or rewards",
				defeat: "Defeat {{n}} threats",
				discardThreat: "Discard {{n}} active threats",
				retrieve: "Take a card from {{zone}}{{limit}}",
				draft: "Gain a top core card of level {{n}} or lower",
				upgrade: "Buy an upgrade costing up to {{n}} for free",
				selfUpgrade: "Attach an upgrade to this card for free",
				anyUpgrade: "Buy an upgrade for free",
				recycleEntireMarket: "Put every market upgrade on deck bottom, then refill the market",
				recycleOneUpgrade: "Put one market upgrade on deck bottom, then refill the market",
				discount: "Your next upgrade costs {{n}} fewer credits",
				bargainDiscount: "Your next Bargain costs {{n}} fewer credits",
				faction: "Treat this card as an additional chosen faction this turn",
				bargain: "Bargain {{n}}: {{text}}",
				pay: "Pay {{n}} {{resource}}: {{text}}",
				exchange: "Lose up to {{n}} {{resource}} to deal that much damage",
				repeat: "Resolve this core’s play effects again",
				allDamage: "Deal {{n}} damage to each active threat",
				bottom: "Put {{n}} cards from hand on deck bottom",
				trade: "Exchange a card in hand with another card in play",
				recycleMarket: "Cycle any upgrades and refill the market",
				disableKeywords: "Disable a threat’s keywords and rewards this turn",
				swapResources: "Exchange any amount of armor and credits",
				returnSelf: "Return this card to hand",
				playTop: "Play your top card and lose health equal to its cost; return it to the battlefield after the Threat Phase",
				shuffleThreat: "Shuffle an active threat into your deck, then add a threat",
				splitDamage: "Deal {{n}} damage, divided among up to the number of targets paid for",
				activateUpgrades: "Resolve all upgrades on this card",
				revealCores: "Look at three cores from an available deck and keep one",
				mark: "For this turn: {{text}}",
				ignoreTaunt: "{{text}}, ignoring Taunt",
				noBoss: "{{text}}, excluding boss cards",
				maxLevel: " of level {{n}} or lower"
			},
			value: {
				focus: "same-faction card count",
				unite: "distinct faction count",
				upgrades: "upgrade count in hand and play",
				sourceUpgrades: "this card’s upgrade count",
				missingHealth: "missing health",
				health: "current health",
				armor: "current armor",
				actions: "remaining actions",
				credits: "current credits",
				silverDiscard: "Silver cards in discard",
				tacticsDiscard: "tactics in discard",
				active: "active threat count",
				wounded: "wounded active threat count",
				level: "current level",
				danger: "danger level"
			},
			special: {
				equalLevel: "Lose up to 3 armor to deal that much damage to one threat",
				blood: "Lose any health to deal that much damage twice",
				progress: "X is the action cost paid to play this card. Lose X health and X credits to deal X damage twice; at 6 health or less take a discard of level 4 or lower; at 2 health or less also take any card from your deck",
				sibling: "Lose 1 health to deal 3 damage; with at least three same-faction cards, lose no health and you may deal 3 more damage",
				discardHand: "Discard a hand card to deal 3 damage",
				embrace: "Lose 3 health to deal 2 and 1 damage; if this would lose your last health, set your health to 5",
				allyFromDeck: "Take an ally from your deck or discard; if you searched your deck, put this card on deck bottom",
				tacticOnly: "Resolve every tactic upgrade on this card",
				freePayments: "Resolve every upgrade on this card once more without paying their costs",
				ifSelfTrigger: "If you attach the upgrade to the source card, resolve that upgrade",
				swapResources: "You may exchange armor and credits at any time this turn",
				armor: "Lose any health to gain that much armor",
				selfDraft: "Eliminate this card; look at the top core of levels 1, 2, and 3 and keep one",
				small: "Look at three cores at your training level and keep one",
				level3Core: "Resolve the effects of the top level-3 core, then return it to the bottom",
				bottomThenReveal: "Put an active threat on deck bottom, then add the top threat to the battlefield",
				drawSame: "Put up to two hand cards on deck bottom, drawing one for each",
				drawThenBottom: "Draw cards equal to your distinct factions in hand and play, then put that many cards from hand on deck bottom",
				onDeckDraw: "If this defeats an on-deck threat, gain 1 action",
				overkillCredits: "Gain credits equal to excess damage",
				reduceCostOnKill: "If a threat is defeated, this card costs 2 fewer actions this turn",
				extraActiveCost2: "You may pay 2 more actions to destroy an active threat",
				includeDeck: "Include on-deck threats",
				random: "Choose at random",
				self: "This card",
				other: "An ally other than this one",
				wounded: "Wounded threats only",
				active: "Active threats only",
				onDeck: "On-deck threats only",
				improvise: "On your first play this turn, reduce two random hand cards’ costs by 1 for this turn",
				playedDamage: "Cards you play with cost at least 2 deal 2 additional damage this turn",
				playedCost: "Cards you play with original cost at least 2 cost 1 fewer action this turn",
				bargainDamage: "Deal 3 damage whenever you use Bargain this turn",
				endCredits: "Gain 2 credits at the end of this turn",
				tacticUpgradeDamage: "Each upgrade on tactics you play deals 1 additional damage this turn",
				hasJunker: "With a Junker card in hand or play",
				hasSilver: "With a Silver card in hand or play",
				hasViren: "With a Viren card in hand or play"
			},
			passives: {
				embrace: "Resolve this card’s printed effects as usual",
				trainRequired: "You may play this only after training this turn",
				upgradeBuyDamage2Health1: "Whenever you buy an upgrade, deal 2 damage and gain 1 health",
				killActions1: "Gain 1 action whenever you defeat a threat",
				alliesActions1Damage3: "Your allies gain 1 action and deal 3 damage when exhausted",
				otherPlayDamage1: "Deal 1 damage whenever you play another card",
				allyTacticUpgrades: "May hold tactic upgrades; they do not trigger when played",
				anyFaction: "Counts as an additional chosen faction this turn",
				uniteCostReduction: "Costs fewer actions equal to distinct factions in hand and play",
				killCredits1: "Gain 1 credit whenever you defeat a threat",
				chooseFaction: "May choose an additional faction each turn",
				redirectKills: "May put defeated non-boss cards on deck bottom and draw two cards",
				actionDamage2: "Deal 2 damage for each action gained",
				doubleExhaust: "All allies resolve their effects once more when exhausted",
				trainDamage2: "Deal 2 damage whenever you train",
				blockedCredits: "Gain 1 credit for each damage blocked by armor",
				bossProtected: "On entering your hand, deal 1 boss damage and discard; cannot be eliminated or upgraded"
			},
			story: {
				goMithras: "Travel to Mithras",
				goVirenos: "Travel to Virenos",
				intimidate: "Intimidate the informant",
				buyInfo: "Buy information",
				defeat: "Defeat the adversary",
				bribe: "Bribe",
				teachLesson: "Teach the merchant a lesson",
				support: "Provide funds",
				wait: "Raise shields and wait",
				offer: "Offer cards",
				donate: "Donate credits",
				counterattack: "Counterattack",
				killKrenko: "Defeat Krenko",
				duel: "Win the duel",
				price: "Pay the price",
				accept: "Accept the deal",
				contribute: "Donate a card",
				bounty: "Claim the bounty",
				infiltrate: "Infiltrate the outpost",
				finishPrey: "Defeat the quarry",
				release: "Release the quarry",
				bluff: "Bluff",
				deal: "Make a deal",
				cutLegs: "Sever its legs",
				outrun: "Outrun the pursuit",
				resistArrest: "Resist arrest",
				escape: "Escape",
				threaten: "Threaten",
				fightSkargen: "Fight Skargen",
				counter: "Drive them back",
				exterminate: "Exterminate the swarm",
				paySkargen: "Pay Skargen",
				giveUpgrade: "Choose who receives the free upgrade",
				contributeAmount: "Contribute {{n}}",
				loseCredit: "Lose 1 credit",
				takeDamage: "Take {{n}} damage",
				extraThreat: "Add an extra threat",
				s00: "Meet the Inventor",
				t00: "Once every character reaches level 2, choose a destination.",
				s01: "The Suspicious Tavern",
				t01: "Accumulate 3 damage per player, or pay 3 credits per player.",
				s02: "Space Pirate Minions",
				t02: "Threat Phase: each player takes 1 damage.",
				s03: "The Corrupt Shopkeeper",
				t03: "Threat Phase: each player pays 1 credit or takes damage equal to their credits.",
				s04: "Space Pirate Reinforcements",
				t04: "Threat Phase: each player takes 3 damage.",
				s05: "Drawing Krenko’s Attention",
				t05: "Whenever a player spends credits, place that much damage here to reduce the donation cost.",
				s06: "The Local Police Arrive",
				t06: "Threat Phase: each player discards a hand card or takes 1 damage.",
				s07: "Krenko Takes Action",
				t07: "Meet the damage requirement in one turn. Threat Phase: take 3 damage, plus 1 with no armor.",
				s08: "Krenko’s Revenge",
				t08: "At the start of the turn, return card #4 to play if the danger space has no colored border or no elimination effect. Meet the damage requirement in one turn. Threat Phase: each player takes 2 damage.",
				s09: "Krenko Will Cooperate",
				t09: "Threat Phase: discard a hand card of level 3 or higher, or lose 1 credit.",
				s10: "Krenko’s Proposal",
				t10: "Donate hand cards to reduce the final price by their level. Threat Phase: discard a hand card or take 10 damage.",
				s11: "Arrival on Virenos",
				t11: "Claim the bounty or pay to infiltrate the outpost.",
				s12: "A Trapped Stag",
				t12: "Threat Phase: each player takes 1 damage.",
				s13: "Gathering Information",
				t13: "Threat Phase: each player pays 2 credits or takes 1 damage.",
				s14: "A Stir in the Forest",
				t14: "The Brood joins the chase; remove it when this story is completed.",
				s15: "Silver Family Confidants",
				t15: "Threat Phase: discard a hand card or take 1 damage.",
				s16: "Meeting in the Alley",
				t16: "The elimination level requirement rises each Threat Phase, up to level 5.",
				s17: "Skargen’s Vengeance",
				t17: "All active threats gain Terror. Threat Phase: each player takes 3 damage.",
				s18: "Skargen’s Pursuit",
				t18: "Meet the damage requirement in one turn. Threat Phase: take 1 damage, plus 3 with no armor.",
				s19: "Skargen Summons Ilis",
				t19: "The price increases by the current size of the Brood.",
				s20: "Skargen’s Terms",
				t20: "Upgrades in hand and play reduce the price. When buying an upgrade, reduce its cost by 1 for each empty slot on its card. Cleanup: each player pays 2 credits or adds an extra threat.",
				s21: "Ilis’s Brood",
				t21: "Each Upkeep adds the danger level to the Brood. Damage reduces its size. Threat Phase: take damage equal to its size.",
				s22: "Story Costs",
				t22: "Pay an option’s cost, resolve its effects, then turn the card over. Multiply damage, credit, and action costs by the player count. Damage persists between turns unless stated otherwise. Players may split credit and action costs. For elimination costs, each player removes one hand card meeting the level requirement. One player must pay the full armor cost."
			},
			rules: "Goal: defeat the boss, solo or cooperatively with one character per player.\n· Lose immediately if any character reaches zero health or danger reaches the end.\nSetup: choose a character; start with 10 health, 3 credits, and three cards.\n· Each starting deck has six Strikes, one Spare Credits, and three character cards.\n· A sleeve holds a core, a threat, and up to two upgrades affecting both sides.\n· You may only view a threat side while it is active or on deck.\nFive phases each turn:\n· Upkeep: gain 3 actions and refresh allies. Health and armor cap at 10, actions at 6.\n· Draft: choose a core deck at or below your training marker.\n· Solo reveals three and keeps one. Two players reveal two each and keep one from each set.\n· Pair each kept core with an unseen threat and add it to hand. Return the others to deck bottom.\n· After drafting, reset training to your level marker.\n· Main: play cards, exhaust allies, and buy upgrades in any order.\n· Fully resolve each action before either player starts another.\n· Pay actions to play cards. Choose one exhaust branch per ally exhaustion.\n· Upgrade only hand or in-play cards, with at most one upgrade per slot.\n· Matching the upgrade’s faction reduces its cost by 2 credits; upgrades grant no faction.\n· Threat: active threats deal their full attack, reducing armor before health.\n· On-deck threats do not attack. Damage does not reduce a threat’s attack.\n· Cleanup: discard tactics, lose actions and armor, refill threats, then advance danger.\n· Refill to three non-Fast active threats and a non-Fast on-deck threat.\n· Skip only your difficulty color: Normal green, Hard yellow, Expert red.\nCombat and leveling:\n· Threat health equals attack plus defense. Damage persists. Attack either battlefield.\n· First give the defeated card to its battlefield owner, then award the final attacker its rewards.\n· Destroying a threat eliminates its sleeve without granting its card or rewards.\n· Level up when deck and battlefield are empty in Main, or an empty deck prevents refilling.\n· Advance both markers; discard all cards in play and down to three cards in hand.\n· You may eliminate one hand or discard card; resolve the boss effect, then shuffle your discard.\n· Events interrupt immediately. Resume the original effect even if its source left play.\n· Order or forfeit effects freely. Eliminate a sleeve after its same effect resolves four times in a turn.\nKeywords:\n· Conspire requires another same-faction card. Focus counts your same-faction cards in hand and play.\n· Unite counts distinct factions in hand and play. Bargain reduces its price by same-faction cards, to zero.\n· Upgraded requires at least one attached upgrade.\n· Fast does not count toward the three threats when refilling during Setup or Cleanup.\n· With Taunt in a battlefield, damage there must target a Taunt threat.\n· Each Rage instance discards one ally in the Threat Phase.\n· Each time you target Terror with damage, lose 1 action; you may still attack at zero actions.\n· Crazed 5 deals itself 2 damage when revealed if its owner has at most 5 health.\n· Crazed, Rage, and Terror stack; Fast and Taunt do not.\nBosses:\n· Harbinger and Triumvirate cards entering hand deal boss damage and are discarded.\n· Triumvirate locations take normal damage. With at least two remaining, boss damage must target locations.\n· Duomo requires a story Ending. Players may split credit and action costs.\nScoring: after victory, finish the current turn if desired, then score each character.\n· Score 100/200/300 for Normal/Hard/Expert, 10 per remaining turn, plus remaining health.\n· Gain 10 for every four-use elimination.\n· Gain 10 each for at least 15 credits and upgrading every non-starting non-boss card.\n· Gain 10 for owning at least two cards of each faction.\n· Gain 50 for leveling up twice after victory during that turn. Never start an extra turn.",
			cards: {
				c12800: "Spare Credits",
				c12803: "Strike",
				c13600: "Two Meters Under",
				c13601: "Blood Donation",
				c13602: "Silver Family Confidant",
				c13603: "Ill-gotten Gains",
				c13604: "Risky Deal",
				c13605: "Exceed Your Limits",
				c13606: "Labor Strike",
				c13607: "Gadwick’s Emporium",
				c13608: "Impetuous Councilor",
				c13609: "Hired Guns",
				c13610: "Faithful Hound",
				c13611: "Loitering",
				c13612: "Wasteland Salvage",
				c13613: "Optical Assistance",
				c13614: "Galvanic Spark",
				c13615: "Secret Plans",
				c13616: "Loyal Customer",
				c13617: "Hammer",
				c13618: "Data Transfer",
				c13619: "JMAJ-99 Salvage Bot",
				c13620: "Viren Sympathizer",
				c13621: "Blood Pact",
				c13622: "Local Target",
				c13623: "Peace Treaty",
				c13400: "Scrap Prodigy",
				c13401: "Brute Force",
				c13402: "Mirage",
				c13403: "Flashphant",
				c13404: "Upgrade Interface",
				c13405: "Loving Embrace",
				c13406: "Three Meters Under",
				c13407: "Blood Covenant",
				c13408: "Novice Intriguer",
				c13409: "Call the Guard",
				c13410: "Viren Solidarity",
				c13411: "New Plan",
				c13412: "Viren Formation",
				c13413: "Caligari Scrapyard",
				c13414: "Concentrated Will",
				c13415: "Regional Target",
				c13416: "Endure the Pain",
				c13417: "Empty Arguments",
				c13418: "Swordmaster’s Lessons",
				c13419: "Frail Puppet",
				c13420: "Viren Ally",
				c13421: "Private Instructor",
				c13422: "Efficient Optical Assistance",
				c13423: "Viren Tactics",
				c13424: "Training Ground",
				c13425: "Shadowy Confidant",
				c13426: "Resistance Society",
				c13427: "Improvisation",
				c13428: "Rogue Hacker",
				c13429: "Ambassador",
				c13430: "Alley Bounty",
				c13700: "Overclock",
				c13701: "National Target",
				c13702: "Doctor Repla",
				c13703: "Take Control",
				c13704: "Aid from the Resistance",
				c13705: "Hidden Tavern",
				c13706: "Discover Secrets",
				c13707: "Viren Strategy",
				c13708: "General’s Favor",
				c13709: "Scrap Hunter",
				c13710: "Former Glory",
				c13711: "Veteran Officer",
				c13712: "Recompense",
				c13713: "Integrated Optical Assistance",
				c13714: "Gadwick Goldenhand",
				c13715: "Royal Armorer",
				c13716: "Public Enemy",
				c13717: "A Blade in the Dark",
				c13718: "Release Power",
				c13719: "Shadow Hunter",
				c13720: "Shield Burst",
				c13721: "Family Secrets",
				c13722: "Underground Contacts",
				c13723: "Gadwick Security",
				c13800: "Enlightened Sage",
				c13801: "Viren Resistance",
				c13802: "Dual Wield",
				c13803: "Sol the Cleaner",
				c13804: "Global Target",
				c13805: "Preserve Evidence",
				c13806: "Uneasy Accord",
				c13807: "Call for Aid",
				c13808: "Demolition Expert",
				c13809: "Sibling Rivalry",
				c13810: "Ann, Silver Advocate",
				c13811: "Optimized Production",
				c13812: "Tiny, the Octomouse",
				c13813: "Call in Favors",
				c13814: "Family Covenant",
				c13815: "Five Meters Under",
				c13816: "Viren Recruiter",
				c13817: "Fair Trade",
				c13818: "Salvaged Battleship",
				c13819: "Little Gizmo",
				c13820: "Clear the Streets",
				c13821: "Count Karn",
				c13822: "Viren Archivist",
				c13823: "Wasteland Gold",
				c13900: "Swords to Plowshares",
				c13901: "Group Discount",
				c13902: "Caligari, the Overseer",
				c13903: "Family Physician",
				c13906: "Banish",
				c13907: "Lethal “Accident”",
				c13908: "Gadwick’s Grand Emporium",
				c13909: "Dominate Will",
				c13910: "Ambush",
				c13911: "“Lethal” Accident",
				c13912: "Council Peacekeepers",
				c13913: "Ten Meters Under",
				c13914: "Chief Councilor Cadlan Pyle",
				c13915: "Joint Assembly",
				c13916: "Starcaller Falina",
				c13917: "Scavenge",
				c14100: "Open Revolt",
				c14101: "The Price of Progress",
				c14102: "Power of Silver",
				c14103: "Brutal Assault",
				c14104: "Kanadu X",
				c14106: "Uprising",
				c14107: "Roadblock Bike",
				c14108: "Admiral Worley",
				c14109: "Medical Nanites",
				c14110: "Power of the Resistance",
				c14111: "Blood Debt",
				c14112: "Yuki, Shopkeeper",
				c14113: "Master Wu",
				c14114: "Elite Peacekeepers",
				c14115: "Thirteen Meters Under",
				c14116: "Peaceful Coexistence",
				c14117: "Lady Grace",
				c14200: "Guard Squadron",
				c14201: "Power Attunement",
				c14202: "Business Savvy",
				c14203: "Dot, Pet Vinespider",
				c14204: "Heir to the Throne",
				c14205: "Eager Councilor",
				c14300: "Resistance Network",
				c14301: "Tools of Production",
				c14302: "Workers United",
				c14303: "Vesper, Junkyard Cat",
				c14304: "Night Market",
				c14305: "Ingenuity",
				c14400: "Ruling Councilor",
				c14401: "Impose Sanctions",
				c14402: "Profit from Conflict",
				c14403: "Aunt Orda",
				c14404: "Step Up",
				c14405: "Rescue",
				u12100: "Viren Medal of Valor",
				u12101: "Networking",
				u12102: "Junker Sandtrap",
				u12103: "Auto-tracker",
				u12104: "Medal of Loyalty",
				u12105: "Crystallize",
				u12106: "Replicator",
				u12107: "Comms Uplink",
				u12108: "Hold Fast",
				u12200: "Laser Pistol",
				u12201: "Empowered",
				u12202: "1000w Arc Capacitor",
				u12203: "Medal of Valor",
				u12204: "Companion",
				u12205: "Ascension Ritual",
				u12206: "Rental Hovercar",
				u12207: "Medical Adrenaline",
				u12208: "Repeater",
				u14900: "Liquid Armor",
				u14901: "Quick Recovery",
				u14902: "Reload",
				u14903: "Viren Meditation",
				u14904: "Stimulant",
				u14905: "Projected Shield",
				u14906: "“Reasonable” Fee",
				u14907: "Back-alley Deal",
				u14908: "Black-market Adrenaline",
				u15000: "Image Enhancement",
				u15001: "Mind Link",
				u15002: "Database",
				u15004: "Bounty",
				u15005: "2000w Arc Capacitor",
				u15006: "Marked Target",
				u15007: "Top-secret File",
				t1800: "Genmod Enforcer",
				t1801: "Genmod Enforcer",
				t1802: "Genmod Enforcer",
				t1803: "Order Acolyte",
				t1804: "Order Acolyte",
				t1805: "Order Acolyte",
				t1806: "Triumvirate Captain",
				t1807: "Commhacker",
				t1808: "Commhacker",
				t1809: "Triumvirate Minion",
				t1810: "Triumvirate Minion",
				t1811: "Triumvirate Minion",
				t1900: "Goldfinch",
				t1901: "Viren Loyalist",
				t1902: "Virenian Stag",
				t1903: "Vinespider",
				t1905: "Deadwood Stalker",
				t2000: "Sandmother",
				t2001: "Fugitive Gunslinger",
				t2002: "Blitzer",
				t2003: "Grimbeast",
				t2005: "Howler",
				t90000: "Virenian Doe",
				t90001: "Ceresan Thief",
				t90002: "Backalley Blademaster",
				t90003: "Junker Cyclist",
				t90004: "Sporeling",
				t1700: "Order Acolyte",
				t1701: "Order Acolyte",
				t1702: "Order Archivist",
				t1703: "Order Archivist",
				t1100: "Triumvirate Informant",
				t1103: "Triumvirate Informant",
				t1101: "Triumvirate Strongarm",
				t1102: "Triumvirate Enforcer",
				c1700: "The Harbinger’s Order",
				c1701: "The Harbinger’s Order",
				c1702: "The Harbinger’s Order",
				c1703: "The Harbinger’s Order",
				c1100: "Triumvirate Agent",
				c1101: "Triumvirate Agent",
				c1102: "Triumvirate Agent",
				c1103: "Triumvirate Agent"
			}
		}
	}
};
//#endregion
export { yn as default };
