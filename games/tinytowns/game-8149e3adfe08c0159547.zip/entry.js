import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { IconBack as s, IconDown as c, IconInfo as l } from "@bgparty/sdk/icons";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as p } from "@bgparty/sdk/assets";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as y, OptionSection as ee, OptionSwitch as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/tinytowns/data.ts
var x = [
	"wood",
	"wheat",
	"brick",
	"glass",
	"stone"
], te = [
	"cottage",
	"food",
	"civic",
	"faith",
	"tavern",
	"trade",
	"industry",
	"monument"
], ne = {
	w: "wood",
	h: "wheat",
	b: "brick",
	g: "glass",
	s: "stone"
};
function S(e) {
	return e.flatMap((e, t) => [...e].flatMap((e, n) => ne[e] ? [[
		n,
		t,
		ne[e]
	]] : []));
}
function C(e, t, n, ...r) {
	return {
		id: e,
		group: t,
		art: n,
		pattern: S(r)
	};
}
var w = [
	C("warehouse", "industry", 0, "hwh", "b.b"),
	C("tradingPost", "industry", 1, "sw.", "swb"),
	C("factory", "industry", 2, "w...", "bssb"),
	C("bank", "industry", 3, "hh.", "wgb"),
	C("well", "civic", 4, "ws"),
	C("shed", "civic", 5, "ws"),
	C("millstone", "civic", 6, "ws"),
	C("fountain", "civic", 7, "ws"),
	C("theater", "trade", 8, ".s.", "wgw"),
	C("tailor", "trade", 9, ".h.", "sgs"),
	C("market", "trade", 10, ".w.", "sgs"),
	C("bakery", "trade", 11, ".h.", "bgb"),
	C("tavern", "tavern", 12, "bbg"),
	C("inn", "tavern", 13, "hsg"),
	C("feastHall", "tavern", 14, "wwg"),
	C("almshouse", "tavern", 15, "ssg"),
	C("orchard", "food", 16, "sh", "hw"),
	C("greenhouse", "food", 17, "hg", "ww"),
	C("granary", "food", 18, "hh", "wb"),
	C("farm", "food", 19, "hh", "ww"),
	C("temple", "faith", 20, "..g", "bbs"),
	C("cloister", "faith", 21, "..g", "wbs"),
	C("chapel", "faith", 22, "..g", "sgs"),
	C("abbey", "faith", 23, "...g", "bsss"),
	C("cottage", "cottage", 24, ".h", "bg"),
	C("silvaForum", "monument", 25, "..h.", "bbsw"),
	C("elderTree", "monument", 26, "bhs", "wgw"),
	C("opaleye", "monument", 27, "w...", "bghh", "s..."),
	C("obelisk", "monument", 28, "h..", "bgb"),
	C("mandrasPalace", "monument", 29, "hg", "bw"),
	C("groveUniversity", "monument", 30, ".b.", "sgs"),
	C("mausoleum", "monument", 31, "ww", "bs"),
	C("fortIronweed", "monument", 32, "h.b", "sws"),
	C("cathedralCaterina", "monument", 33, ".h", "sg"),
	C("barrettCastle", "monument", 34, "h..s", "wggb"),
	C("archive", "monument", 35, "hh", "bg"),
	C("architectGuild", "monument", 36, "..g", ".hs", "wb."),
	C("starloom", "monument", 37, "gg", "wh"),
	C("skyBaths", "monument", 38, ".h.", "sgw", "b.b"),
	C("bondmaker", "monument", 39, "wssg", "h...")
], T = Object.fromEntries(w.map((e) => [e.id, e])), re = [
	"cottage",
	"farm",
	"well",
	"chapel",
	"tavern",
	"bakery",
	"warehouse"
], ie = w.filter((e) => e.group === "monument").map((e) => e.id), ae = {
	wood: "#634331",
	wheat: "#f3ab25",
	brick: "#e54636",
	glass: "#269ca6",
	stone: "#b3aa90"
}, E = t.enum(x), D = t.int().min(0).max(15), O = t.object({
	mode: t.enum(["master", "townHall"]).default("master"),
	buildings: t.enum(["first", "random"]).default("first"),
	monuments: t.boolean().default(!0),
	cavern: t.boolean().default(!1)
}).default({
	mode: "master",
	buildings: "first",
	monuments: !0,
	cavern: !1
}), oe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("monument"),
		id: t.string()
	}),
	t.object({
		type: t.literal("name"),
		resource: E
	}),
	t.object({
		type: t.literal("place"),
		at: D,
		resource: E,
		offer: t.int().min(0).max(2).optional(),
		warehouse: D.optional(),
		swap: t.int().min(0).max(2).optional(),
		bondmaker: t.boolean().optional()
	}),
	t.object({
		type: t.literal("cavern"),
		offer: t.int().min(0).max(2).optional()
	}),
	t.object({
		type: t.literal("build"),
		id: t.string(),
		cells: t.array(D).min(2).max(8),
		at: D,
		resource: E.optional()
	}),
	t.object({
		type: t.literal("effect"),
		id: t.string().optional(),
		at: D.optional(),
		source: D.optional(),
		resource: E.optional(),
		choices: t.array(t.string()).max(3).optional(),
		skip: t.boolean().optional()
	}),
	t.object({
		type: t.literal("feed"),
		cells: t.array(D).max(16)
	}),
	t.object({ type: t.literal("ready") }),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), k = t.object({
	resource: E.nullable(),
	building: t.string().nullable(),
	stored: t.array(E).max(3),
	marker: E.nullable()
}), se = t.object({
	kind: t.enum([
		"grove",
		"guild",
		"watch",
		"watchTrigger",
		"obelisk"
	]),
	remaining: t.int(),
	choices: t.array(t.string()),
	used: t.array(D),
	source: t.string().nullable()
}), ce = t.object({
	cottage: t.number(),
	food: t.number(),
	civic: t.number(),
	faith: t.number(),
	tavern: t.number(),
	trade: t.number(),
	industry: t.number(),
	monument: t.number(),
	empty: t.number(),
	total: t.number(),
	fed: t.array(D),
	emptyCount: t.int(),
	cottages: t.int()
}), A = t.object({
	rid: t.string(),
	cells: t.array(k).length(16),
	monument: t.string().nullable(),
	monumentBuilt: t.boolean(),
	placed: t.boolean(),
	ready: t.boolean(),
	completed: t.int().nullable(),
	masterTurns: t.int(),
	cavernUsed: t.int(),
	effect: se.nullable(),
	watched: t.array(t.string()),
	shrineValue: t.int(),
	starloomValue: t.int(),
	fed: t.array(D),
	score: ce
}), le = t.object({
	players: t.array(t.string()),
	towns: t.array(A),
	cards: t.array(t.string()),
	phase: t.enum([
		"monument",
		"name",
		"play",
		"done"
	]),
	round: t.int(),
	master: t.string(),
	resource: E.nullable(),
	mode: t.enum([
		"master",
		"townHall",
		"solo"
	]),
	offers: t.array(E),
	config: O,
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		id: t.string().optional(),
		at: D.optional(),
		resource: E.optional()
	}))
}), j = t.object({
	monument: t.string().nullable(),
	options: t.array(t.string()),
	effect: se.nullable()
}), M = () => ({
	resource: null,
	building: null,
	stored: [],
	marker: null
}), ue = (e) => [
	e % 4 ? e - 1 : -1,
	e % 4 < 3 ? e + 1 : -1,
	e >= 4 ? e - 4 : -1,
	e < 12 ? e + 4 : -1
].filter((e) => e >= 0), N = (e) => !e.building && !e.resource, P = (e) => e.building === "barrettCastle" ? "cottage" : e.building ? T[e.building].group : null, F = (e) => e.building === "barrettCastle" ? 2 : +(P(e) === "cottage"), de = /* @__PURE__ */ new Map();
function I(e) {
	let t = de.get(e);
	if (t) return t;
	let n = [], r = /* @__PURE__ */ new Set();
	for (let t = 0; t < 2; t++) for (let i = 0; i < 4; i++) {
		let a = e.map(([e, n, r]) => [
			t ? -e : e,
			n,
			r
		]);
		for (let e = 0; e < i; e++) a = a.map(([e, t, n]) => [
			-t,
			e,
			n
		]);
		let o = Math.min(...a.map((e) => e[0])), s = Math.min(...a.map((e) => e[1]));
		a = a.map(([e, t, n]) => [
			e - o,
			t - s,
			n
		]).sort((e, t) => e[1] - t[1] || e[0] - t[0]);
		let c = JSON.stringify(a);
		r.has(c) || (r.add(c), n.push(a));
	}
	return de.set(e, n), n;
}
function fe(e, t) {
	let n = T[t];
	if (!n) return [];
	let r = [], i = /* @__PURE__ */ new Set();
	for (let t of I(n.pattern)) {
		let n = Math.max(...t.map((e) => e[0])) + 1, a = Math.max(...t.map((e) => e[1])) + 1;
		for (let o = 0; o <= 4 - a; o++) for (let a = 0; a <= 4 - n; a++) {
			let n = t.map(([e, t]) => (o + t) * 4 + a + e);
			if (!n.every((n, r) => e[n].resource === t[r][2] || e[n].building === "tradingPost")) continue;
			let s = n.filter((t) => e[t].resource !== null && !e[t].building);
			if (!s.length) continue;
			let c = [...n].sort((e, t) => e - t).join(",");
			i.has(c) || (i.add(c), r.push({
				cells: n,
				removed: s,
				pattern: t
			}));
		}
	}
	return r;
}
var pe = (e, t) => e.length === t.length && new Set(e).size === e.length && e.every((e) => t.includes(e)), me = (e, t, n, r) => t === "shed" || r ? e.flatMap((e, t) => N(e) || n.removed.includes(t) ? [t] : []) : n.removed;
function he(e) {
	let t = e.flatMap((e, t) => F(e) ? [t] : []), n = e.filter((e) => e.building === "greenhouse").length, r = e.filter((e) => e.building === "farm").length * 4, i = /* @__PURE__ */ new Set();
	for (let n = 0; n < 16; n++) e[n].building === "granary" && t.filter((e) => Math.abs(n % 4 - e % 4) <= 1 && Math.abs((n >> 2) - (e >> 2)) <= 1).forEach((e) => i.add(e)), e[n].building === "orchard" && t.filter((e) => n % 4 == e % 4 || n >> 2 == e >> 2).forEach((e) => i.add(e));
	let a = [], o = new Set(t);
	for (; o.size;) {
		let e = o.values().next().value;
		o.delete(e);
		let t = [e];
		for (let e = 0; e < t.length; e++) for (let n of ue(t[e])) o.has(n) && (o.delete(n), t.push(n));
		a.push(t);
	}
	return {
		cottages: t,
		greens: n,
		farms: r,
		fixed: i,
		groups: a
	};
}
function ge(e, t) {
	if (new Set(t).size !== t.length || t.some((t) => !F(e[t]))) return !1;
	let n = he(e), r = new Set(t);
	return n.groups.map((t) => t.reduce((t, i) => t + (r.has(i) && !n.fixed.has(i) ? F(e[i]) : 0), 0)).sort((e, t) => t - e).slice(n.greens).reduce((e, t) => e + t, 0) <= n.farms;
}
function L(e, t) {
	let n = new Set(t), r = t.reduce((t, n) => t + F(e[n]), 0), i = e.some((e) => e.building === "mausoleum");
	return t.reduce((t, n) => t + (e[n].building === "barrettCastle" ? 5 : i ? 0 : 3), 0) + e.filter((e) => e.building === "chapel").length * r + e.reduce((t, r, i) => t + (r.building === "temple" && ue(i).reduce((t, r) => t + (n.has(r) ? F(e[r]) : 0), 0) >= 2 ? 4 : 0), 0);
}
function R(e) {
	let t = he(e);
	if (!t.farms && !t.greens) return t.cottages.filter((e) => t.fixed.has(e));
	if (ge(e, t.cottages)) return t.cottages;
	let n = [], r = -Infinity;
	for (let i = 0; i < 2 ** t.cottages.length; i++) {
		let a = t.cottages.filter((e, t) => i & 1 << t);
		if (!ge(e, a)) continue;
		let o = L(e, a);
		o > r && (r = o, n = a);
	}
	return n;
}
function z(e, t) {
	let n = e.cells, r = e.fed !== null && ge(n, e.fed) ? e.fed : R(n), i = new Set(r), a = (e) => n.filter((t) => t.building === e).length, o = r.reduce((e, t) => e + F(n[t]), 0), s = (e) => a(e) > 0, c = {
		cottage: 0,
		food: 0,
		civic: 0,
		faith: 0,
		tavern: 0,
		trade: 0,
		industry: 0,
		monument: 0,
		empty: 0,
		total: 0,
		fed: r,
		emptyCount: n.filter((e) => !e.building).length,
		cottages: ((e) => n.reduce((t, n) => t + (P(n) === e ? e === "cottage" ? F(n) : 1 : 0), 0))("cottage")
	};
	for (let r = 0; r < 16; r++) {
		let l = n[r], u = l.building;
		if (!u) continue;
		let d = ue(r), f = (e) => d.filter((t) => P(n[t]) === e), p = (e) => r !== e && (r % 4 == e % 4 || r >> 2 == e >> 2), m = 0;
		switch (u) {
			case "cottage":
				m = i.has(r) || s("mausoleum") ? 3 : 0;
				break;
			case "barrettCastle":
				m = i.has(r) ? 5 : 0;
				break;
			case "well":
				m = d.reduce((e, t) => e + F(n[t]), 0);
				break;
			case "shed":
				m = 1;
				break;
			case "millstone":
				m = f("food").length || f("trade").length ? 2 : 0;
				break;
			case "fountain":
				m = d.some((e) => n[e].building === "fountain") ? 2 : 0;
				break;
			case "abbey":
				m = d.some((e) => [
					"cottage",
					"industry",
					"trade"
				].includes(P(n[e]) ?? "")) ? 0 : 3;
				break;
			case "chapel":
				m = o;
				break;
			case "cloister":
				m = [
					0,
					3,
					12,
					15
				].filter((e) => n[e].building === "cloister").length;
				break;
			case "temple":
				m = d.reduce((e, t) => e + (i.has(t) ? F(n[t]) : 0), 0) >= 2 ? 4 : 0;
				break;
			case "feastHall":
				m = 2 + +(a("feastHall") > (t?.cells.filter((e) => e.building === "feastHall").length ?? a("feastHall")));
				break;
			case "inn":
				m = n.some((e, t) => e.building === "inn" && p(t)) ? 0 : 3;
				break;
			case "bakery":
				m = f("food").length || f("industry").length ? 3 : 0;
				break;
			case "market":
				m = Math.max(n.filter((e, t) => e.building === "market" && t % 4 == r % 4).length, n.filter((e, t) => e.building === "market" && t >> 2 == r >> 2).length);
				break;
			case "tailor":
				m = 1 + [
					5,
					6,
					9,
					10
				].filter((e) => n[e].building === "tailor").length;
				break;
			case "theater":
				m = new Set(n.flatMap((e, t) => p(t) && P(e) && P(e) !== "trade" ? [P(e)] : [])).size;
				break;
			case "bank":
				m = 4;
				break;
			case "tradingPost":
				m = 1;
				break;
			case "warehouse":
				m = -l.stored.length;
				break;
			case "silvaForum": {
				let e = 0, t = /* @__PURE__ */ new Set();
				for (let r = 0; r < 16; r++) {
					if (!n[r].building || t.has(r)) continue;
					let i = P(n[r]), a = [r];
					t.add(r);
					for (let e = 0; e < a.length; e++) for (let r of ue(a[e])) P(n[r]) === i && !t.has(r) && (t.add(r), a.push(r));
					e = Math.max(e, a.reduce((e, t) => e + (P(n[t]) === "cottage" ? F(n[t]) : 1), 0));
				}
				m = 1 + e;
				break;
			}
			case "elderTree":
				m = e.shrineValue;
				break;
			case "mandrasPalace":
				m = 2 * new Set(d.flatMap((e) => P(n[e]) ? [P(n[e])] : [])).size;
				break;
			case "groveUniversity":
				m = 3;
				break;
			case "fortIronweed":
				m = 7;
				break;
			case "cathedralCaterina":
				m = 2;
				break;
			case "archive":
				m = new Set(n.flatMap((e) => P(e) && P(e) !== "monument" ? [P(e)] : [])).size;
				break;
			case "architectGuild":
				m = 1;
				break;
			case "starloom":
				m = e.starloomValue;
				break;
			case "skyBaths": m = 2 * te.filter((e) => !n.some((t) => P(t) === e)).length;
		}
		c[P(l) ?? "monument"] += m;
	}
	return c.tavern += ([
		0,
		2,
		5,
		9,
		14,
		20
	][Math.min(5, a("tavern"))] ?? 0) + ([
		0,
		-1,
		5,
		-3,
		15,
		-5,
		26
	][Math.min(6, a("almshouse"))] ?? 0), c.empty = s("cathedralCaterina") ? 0 : -c.emptyCount, c.total = te.reduce((e, t) => e + c[t], c.empty), c;
}
var B = (e) => x.filter((t) => !e.some((e) => e.building === "bank" && e.marker === t)), V = {
	id: "tinytowns",
	tier: "alpha",
	mechanics: ["tile-placement", "set-collection"],
	interactionTags: [],
	nameKey: "games.tinytowns.name",
	descKey: "games.tinytowns.desc",
	rulesKey: "games.tinytowns.rules",
	icon: "🏘️",
	iconImg: "games/tinytowns.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1823399538538672090/A62373A1C42BB89D0CB8AD9CA4AA6167FCF8321E/" },
	minPlayers: 1,
	maxPlayers: 6,
	bestPlayers: [3, 4],
	accent: "#986035",
	releasedAt: "2026-10-31T14:13:00+08:00",
	search: {
		py: "xiao xiao cheng zhen tiny towns",
		init: "xxcz"
	},
	hotseat: "cover",
	botDelayMs: 320
}, H = {
	place: 280,
	build: 400,
	reveal: 360
}, U = () => ({ code: "games.tinytowns.error" });
function _e(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var W = () => x.flatMap((e) => [
	e,
	e,
	e
]), G = (e) => e.players.filter((t) => e.towns[t].completed === null), ve = (e) => !e.cells.some(N), K = (e, t) => e.cells.some((e) => e.building === t), q = (e, t) => e.mode === "solo" || e.mode === "townHall" ? e.mode === "solo" || e.round % 3 != 0 : e.master !== t;
function ye(e, t) {
	let n = e.towns[t];
	return !n || n.completed !== null || n.ready || e.phase === "done" || e.phase === "monument" ? !1 : ve(n) ? !0 : (e.phase === "name" && e.master === t || e.phase === "play" && e.mode === "townHall" && e.resource === null && !n.placed) && B(n.cells).length === 0;
}
function be(e, t = !1) {
	t || e.round++;
	for (let t of G(e)) e.towns[t].placed = !1, e.towns[t].ready = !1;
	if (e.resource = null, e.mode === "master") {
		let n = G(e), r = e.players.indexOf(e.master);
		t || (r = (r + 1) % e.players.length);
		for (let t = 0; t < e.players.length; t++) {
			let i = e.players[(r + t) % e.players.length];
			if (n.includes(i) && (n.length === 1 || !K(e.towns[i], "fortIronweed"))) {
				e.master = i;
				break;
			}
		}
		e.phase = "name";
	} else if (e.phase = "play", e.mode === "solo") {
		if (e.selectedOffer !== null) {
			let t = e.offers[e.selectedOffer];
			e.deck.push(t), e.offers[e.selectedOffer] = e.deck.shift(), e.selectedOffer = null;
		}
	} else if (e.round % 3 != 0) e.deck.length || (e.deck = _e(e, W()).slice(5)), e.resource = e.deck.shift();
	else {
		let t = G(e);
		for (let n of t) t.length > 1 && K(e.towns[n], "fortIronweed") && (e.towns[n].placed = !0);
	}
}
function xe(t, n, r) {
	let i = O.safeParse(t), a = i.success ? i.data : O.parse(void 0), o = {
		players: [...n],
		towns: {},
		cards: [],
		config: a,
		phase: a.monuments ? "monument" : "name",
		round: 1,
		master: n[0],
		resource: null,
		mode: n.length === 1 ? "solo" : a.mode,
		seed: r,
		cursor: 0,
		deck: [],
		offers: [],
		selectedOffer: null,
		log: []
	};
	o.cards = a.buildings === "first" ? [...re] : ["cottage", ...[
		"food",
		"civic",
		"faith",
		"tavern",
		"trade",
		"industry"
	].map((t) => {
		let i = w.filter((e) => e.group === t && (n.length > 1 || !["inn", "bank"].includes(e.id)));
		return i[e(r, o.cursor++, i.length)].id;
	})];
	let s = ie.filter((e) => n.length > 1 || !["opaleye", "fortIronweed"].includes(e));
	s = _e(o, s);
	for (let e of n) o.towns[e] = {
		rid: e,
		cells: Array.from({ length: 16 }, M),
		monument: null,
		options: a.monuments ? s.splice(0, 2) : [],
		monumentBuilt: !1,
		placed: !1,
		ready: !1,
		completed: null,
		masterTurns: 0,
		cavernUsed: 0,
		effects: [],
		watched: [],
		shrineValue: 0,
		starloomValue: 0,
		fed: null
	};
	return o.mode === "solo" && (o.deck = _e(o, W()), o.offers = o.deck.splice(0, 3)), o.mode === "townHall" && (o.deck = _e(o, W()).slice(5)), a.monuments || be(o, !0), {
		state: o,
		fx: []
	};
}
function J(e, t) {
	t.completed = e.round, t.ready = !0, t.starloomValue = [
		0,
		6,
		3,
		2
	][1 + e.players.filter((t) => e.towns[t].completed !== null && e.towns[t].completed < e.round).length] ?? 0, e.log.push({
		rid: t.rid,
		kind: "finish"
	});
}
function Y(e) {
	if (e.players.every((t) => e.towns[t].completed !== null)) {
		e.phase = "done";
		for (let t of e.players) for (let n of e.towns[t].cells) n.resource = null;
	} else G(e).every((t) => e.towns[t].ready && e.towns[t].effects.length === 0) && be(e);
}
function Se(e, t, n) {
	return t !== "bank" && t !== "factory" || !!n && (t !== "bank" || !e.cells.some((e) => e.building === "bank" && e.marker === n));
}
function Ce(e, t, n) {
	if (n === "elderTree") {
		let e = t.cells.filter((e) => e.building).length;
		t.shrineValue = [
			0,
			1,
			2,
			3,
			4,
			5,
			8
		][Math.min(6, e)];
	}
	n === "groveUniversity" && t.effects.push({
		kind: "grove",
		remaining: 1,
		choices: [],
		used: [],
		source: null
	}), n === "architectGuild" && t.effects.push({
		kind: "guild",
		remaining: 2,
		choices: [],
		used: [],
		source: null
	}), n === "opaleye" && t.effects.push({
		kind: "watch",
		remaining: 3,
		choices: [],
		used: [],
		source: null
	});
	let r = e.players.indexOf(t.rid), i = /* @__PURE__ */ new Set([e.players[(r + 1) % e.players.length], e.players[(r + e.players.length - 1) % e.players.length]]);
	for (let r of i) {
		let i = e.towns[r];
		r !== t.rid && i.completed === null && i.watched.includes(n) && (i.watched = i.watched.filter((e) => e !== n), i.effects.push({
			kind: "watchTrigger",
			remaining: 1,
			choices: [n],
			used: [],
			source: t.rid
		}), i.ready = !1);
	}
}
function we(e, t, n, r, i, a, o = []) {
	t.cells[r] = {
		...M(),
		building: n,
		marker: i ?? null
	}, t.fed = null, T[n].group === "monument" && (t.monumentBuilt = !0), e.log.push({
		rid: t.rid,
		kind: "build",
		id: n,
		at: r
	}), a.push({
		kind: "build",
		rid: t.rid,
		data: {
			id: n,
			at: r,
			consumed: o
		}
	}), Ce(e, t, n);
}
function Te(e, t, n) {
	let r = e.resource;
	if (e.mode === "solo") {
		if (n.offer === void 0 || !e.offers[n.offer]) return !1;
		r = e.offers[n.offer];
	}
	return r === null ? B(t.cells).includes(n.resource) : n.resource === r || q(e, t.rid) && t.cells.some((e) => e.building === "factory" && e.marker === r);
}
function Ee(e, t) {
	let n = e.towns[t];
	if (e.phase !== "play" || !n || n.placed || n.ready || n.completed !== null) return [];
	let r = [];
	for (let i of x) for (let a of e.mode === "solo" ? [
		0,
		1,
		2
	] : [void 0]) {
		let o = {
			type: "place",
			resource: i,
			at: 0,
			...a === void 0 ? {} : { offer: a }
		};
		if (Te(e, n, o)) {
			for (let i = 0; i < 16; i++) N(n.cells[i]) && r.push({
				...o,
				at: i
			}), q(e, t) && K(n, "bondmaker") && n.cells[i].building === "cottage" && !n.cells[i].stored.length && r.push({
				...o,
				at: i,
				bondmaker: !0
			});
			if (q(e, t)) for (let e = 0; e < 16; e++) {
				let t = n.cells[e];
				if (t.building === "warehouse") {
					t.stored.length < 3 && r.push({
						...o,
						at: e,
						warehouse: e
					});
					for (let i = 0; i < t.stored.length; i++) for (let t = 0; t < 16; t++) N(n.cells[t]) && r.push({
						...o,
						at: t,
						warehouse: e,
						swap: i
					});
				}
			}
		}
	}
	return r;
}
function De(e, t, n) {
	if (t.type === "tick") return {
		state: e,
		fx: []
	};
	if (!e.towns[n.by] || e.phase === "done") return U();
	let r = structuredClone(e), i = r.towns[n.by], a = [];
	if (t.type === "monument") return r.phase !== "monument" || i.monument || !i.options.includes(t.id) ? U() : (i.monument = t.id, i.options = [], r.players.every((e) => r.towns[e].monument) && be(r, !0), {
		state: r,
		fx: a
	});
	if (t.type === "name") return r.phase !== "name" || r.master !== n.by || !B(i.cells).includes(t.resource) ? U() : (r.resource = t.resource, r.phase = "play", i.masterTurns++, r.log.push({
		rid: n.by,
		kind: "name",
		resource: t.resource
	}), {
		state: r,
		fx: [{
			kind: "name",
			rid: n.by,
			data: { resource: t.resource }
		}]
	});
	if (t.type === "feed") return r.phase !== "play" || i.completed !== null || i.ready || !i.placed || i.effects.length || !ge(i.cells, t.cells) ? U() : (i.fed = t.cells, {
		state: r,
		fx: a
	});
	if (t.type === "finish") return ye(r, n.by) ? (i.effects = [], J(r, i), Y(r), r.phase === "name" && r.master === n.by && i.completed !== null && be(r, !0), {
		state: r,
		fx: [{
			kind: "finish",
			rid: n.by
		}]
	}) : U();
	if (r.phase !== "play" || i.completed !== null || i.ready) return U();
	if (t.type === "effect") {
		let e = i.effects[0];
		if (!e || !i.placed) return U();
		if (t.skip) return e.kind === "watch" ? U() : (i.effects.shift(), Y(r), {
			state: r,
			fx: a
		});
		if (e.kind === "watch") {
			let e = t.choices;
			return !e || e.length !== 3 || new Set(e).size !== 3 || e.some((e) => !r.cards.includes(e)) ? U() : (i.watched = [...e], i.effects.shift(), {
				state: r,
				fx: a
			});
		}
		let n = t.id, o = t.at;
		if (!n || o === void 0 || !r.cards.includes(n) || !Se(i, n, t.resource) || e.kind === "watchTrigger" && !e.choices.includes(n)) return U();
		if (e.kind === "guild") {
			let r = t.source;
			if (r === void 0 || e.used.includes(r) || !i.cells[r].building || T[i.cells[r].building].group === "monument" || i.cells[r].building === n) return U();
			if (n === "shed") {
				if (o !== r && !N(i.cells[o])) return U();
			} else if (o !== r) return U();
			i.cells[r] = M(), e.used.push(r);
		} else if (!N(i.cells[o])) return U();
		return e.remaining--, e.remaining <= 0 && i.effects.shift(), we(r, i, n, o, t.resource, a), {
			state: r,
			fx: a
		};
	}
	if (i.effects.length && t.type !== "place" && t.type !== "cavern") return U();
	if (t.type === "place") {
		if (i.placed || !Te(r, i, t)) return U();
		let e = i.cells[t.at];
		if (t.warehouse !== void 0) {
			let o = i.cells[t.warehouse];
			if (!q(r, n.by) || o.building !== "warehouse" || t.bondmaker) return U();
			if (t.swap !== void 0) {
				if (!N(e) || t.swap >= o.stored.length) return U();
				let r = o.stored[t.swap];
				o.stored[t.swap] = t.resource, e.resource = r, a.push({
					kind: "place",
					rid: n.by,
					data: {
						resource: r,
						at: t.at,
						from: t.warehouse,
						fromStored: t.swap
					}
				});
			} else {
				if (o.stored.length >= 3 || t.at !== t.warehouse) return U();
				o.stored.push(t.resource);
			}
		} else if (t.bondmaker) {
			if (!q(r, n.by) || !K(i, "bondmaker") || e.building !== "cottage" || e.stored.length) return U();
			e.stored.push(t.resource);
		} else {
			if (!N(e)) return U();
			e.resource = t.resource;
		}
		return i.placed = !0, r.mode === "solo" && (r.selectedOffer = t.offer), r.log.push({
			rid: n.by,
			kind: "place",
			at: t.at,
			resource: t.resource
		}), a.unshift({
			kind: "place",
			rid: n.by,
			data: {
				resource: t.resource,
				at: t.warehouse ?? t.at,
				...t.warehouse === void 0 ? t.bondmaker ? { stored: 0 } : {} : { stored: t.swap ?? i.cells[t.warehouse].stored.length - 1 },
				...t.offer === void 0 ? {} : { offer: t.offer }
			}
		}), a.length > 1 && (a[1].with = !0), {
			state: r,
			fx: a
		};
	}
	if (t.type === "cavern") return i.placed || !r.config.cavern || r.mode === "solo" || !q(r, n.by) || i.cavernUsed >= 2 ? U() : (i.cavernUsed++, i.placed = !0, r.log.push({
		rid: n.by,
		kind: "cavern"
	}), {
		state: r,
		fx: [{
			kind: "cavern",
			rid: n.by,
			data: { resource: r.resource }
		}]
	});
	if (t.type === "build") {
		if (!i.placed || !r.cards.includes(t.id) && (i.monument !== t.id || i.monumentBuilt) || !Se(i, t.id, t.resource)) return U();
		let e = fe(i.cells, t.id).find((e) => pe(e.cells, t.cells));
		if (!e || !me(i.cells, t.id, e, K(i, "obelisk")).includes(t.at)) return U();
		let n = e.removed.map((e) => ({
			at: e,
			resource: i.cells[e].resource
		}));
		for (let t of e.removed) i.cells[t] = M();
		return we(r, i, t.id, t.at, t.resource, a, n), {
			state: r,
			fx: a
		};
	}
	return t.type === "ready" && i.placed ? (ve(i) ? (J(r, i), a.push({
		kind: "finish",
		rid: n.by
	})) : i.ready = !0, Y(r), {
		state: r,
		fx: a
	}) : U();
}
function Oe(e, t) {
	let n = e.towns[t];
	return {
		public: {
			players: e.players,
			cards: e.cards,
			phase: e.phase,
			round: e.round,
			master: e.master,
			resource: e.resource,
			mode: e.mode,
			offers: e.offers,
			config: e.config,
			log: e.log,
			towns: e.players.map((t, n) => {
				let r = e.towns[t], i = z(r, e.towns[e.players[(n + e.players.length - 1) % e.players.length]]);
				return {
					rid: t,
					cells: r.cells,
					monument: r.monumentBuilt || e.phase === "done" ? r.monument : null,
					monumentBuilt: r.monumentBuilt,
					placed: r.placed,
					ready: r.ready,
					completed: r.completed,
					masterTurns: r.masterTurns,
					cavernUsed: r.cavernUsed,
					effect: r.effects[0] ?? null,
					watched: r.watched,
					shrineValue: r.shrineValue,
					starloomValue: r.starloomValue,
					fed: i.fed,
					score: i
				};
			})
		},
		private: {
			monument: n?.monument ?? null,
			options: n?.options ?? [],
			effect: n?.effects[0] ?? null
		}
	};
}
function X(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t, n) => [t, z(e.towns[t], e.towns[e.players[(n + e.players.length - 1) % e.players.length]])])), n = (n, r) => t[r].total - t[n].total || e.towns[n].masterTurns - e.towns[r].masterTurns || t[n].emptyCount - t[r].emptyCount || t[r].cottages - t[n].cottages, r = [...e.players].sort(n);
	return {
		phase: "done",
		ranking: r,
		winner: r.filter((e) => n(e, r[0]) === 0),
		scores: Object.fromEntries(e.players.map((e) => [e, t[e].total]))
	};
}
var ke = {
	meta: V,
	saveCompatibility: { version: "1" },
	schemas: {
		action: oe,
		publicView: le,
		privateView: j,
		config: O
	},
	setup: xe,
	reduce: De,
	viewFor: Oe,
	status: X
}, Ae = {
	warehouse: {
		name: "games.tinytowns.cards.warehouse.name",
		effect: "games.tinytowns.cards.warehouse.effect"
	},
	tradingPost: {
		name: "games.tinytowns.cards.tradingPost.name",
		effect: "games.tinytowns.cards.tradingPost.effect"
	},
	factory: {
		name: "games.tinytowns.cards.factory.name",
		effect: "games.tinytowns.cards.factory.effect"
	},
	bank: {
		name: "games.tinytowns.cards.bank.name",
		effect: "games.tinytowns.cards.bank.effect"
	},
	well: {
		name: "games.tinytowns.cards.well.name",
		effect: "games.tinytowns.cards.well.effect"
	},
	shed: {
		name: "games.tinytowns.cards.shed.name",
		effect: "games.tinytowns.cards.shed.effect"
	},
	millstone: {
		name: "games.tinytowns.cards.millstone.name",
		effect: "games.tinytowns.cards.millstone.effect"
	},
	fountain: {
		name: "games.tinytowns.cards.fountain.name",
		effect: "games.tinytowns.cards.fountain.effect"
	},
	theater: {
		name: "games.tinytowns.cards.theater.name",
		effect: "games.tinytowns.cards.theater.effect"
	},
	tailor: {
		name: "games.tinytowns.cards.tailor.name",
		effect: "games.tinytowns.cards.tailor.effect"
	},
	market: {
		name: "games.tinytowns.cards.market.name",
		effect: "games.tinytowns.cards.market.effect"
	},
	bakery: {
		name: "games.tinytowns.cards.bakery.name",
		effect: "games.tinytowns.cards.bakery.effect"
	},
	tavern: {
		name: "games.tinytowns.cards.tavern.name",
		effect: "games.tinytowns.cards.tavern.effect"
	},
	inn: {
		name: "games.tinytowns.cards.inn.name",
		effect: "games.tinytowns.cards.inn.effect"
	},
	feastHall: {
		name: "games.tinytowns.cards.feastHall.name",
		effect: "games.tinytowns.cards.feastHall.effect"
	},
	almshouse: {
		name: "games.tinytowns.cards.almshouse.name",
		effect: "games.tinytowns.cards.almshouse.effect"
	},
	orchard: {
		name: "games.tinytowns.cards.orchard.name",
		effect: "games.tinytowns.cards.orchard.effect"
	},
	greenhouse: {
		name: "games.tinytowns.cards.greenhouse.name",
		effect: "games.tinytowns.cards.greenhouse.effect"
	},
	granary: {
		name: "games.tinytowns.cards.granary.name",
		effect: "games.tinytowns.cards.granary.effect"
	},
	farm: {
		name: "games.tinytowns.cards.farm.name",
		effect: "games.tinytowns.cards.farm.effect"
	},
	temple: {
		name: "games.tinytowns.cards.temple.name",
		effect: "games.tinytowns.cards.temple.effect"
	},
	cloister: {
		name: "games.tinytowns.cards.cloister.name",
		effect: "games.tinytowns.cards.cloister.effect"
	},
	chapel: {
		name: "games.tinytowns.cards.chapel.name",
		effect: "games.tinytowns.cards.chapel.effect"
	},
	abbey: {
		name: "games.tinytowns.cards.abbey.name",
		effect: "games.tinytowns.cards.abbey.effect"
	},
	cottage: {
		name: "games.tinytowns.cards.cottage.name",
		effect: "games.tinytowns.cards.cottage.effect"
	},
	silvaForum: {
		name: "games.tinytowns.cards.silvaForum.name",
		effect: "games.tinytowns.cards.silvaForum.effect"
	},
	elderTree: {
		name: "games.tinytowns.cards.elderTree.name",
		effect: "games.tinytowns.cards.elderTree.effect"
	},
	opaleye: {
		name: "games.tinytowns.cards.opaleye.name",
		effect: "games.tinytowns.cards.opaleye.effect"
	},
	obelisk: {
		name: "games.tinytowns.cards.obelisk.name",
		effect: "games.tinytowns.cards.obelisk.effect"
	},
	mandrasPalace: {
		name: "games.tinytowns.cards.mandrasPalace.name",
		effect: "games.tinytowns.cards.mandrasPalace.effect"
	},
	groveUniversity: {
		name: "games.tinytowns.cards.groveUniversity.name",
		effect: "games.tinytowns.cards.groveUniversity.effect"
	},
	mausoleum: {
		name: "games.tinytowns.cards.mausoleum.name",
		effect: "games.tinytowns.cards.mausoleum.effect"
	},
	fortIronweed: {
		name: "games.tinytowns.cards.fortIronweed.name",
		effect: "games.tinytowns.cards.fortIronweed.effect"
	},
	cathedralCaterina: {
		name: "games.tinytowns.cards.cathedralCaterina.name",
		effect: "games.tinytowns.cards.cathedralCaterina.effect"
	},
	barrettCastle: {
		name: "games.tinytowns.cards.barrettCastle.name",
		effect: "games.tinytowns.cards.barrettCastle.effect"
	},
	archive: {
		name: "games.tinytowns.cards.archive.name",
		effect: "games.tinytowns.cards.archive.effect"
	},
	architectGuild: {
		name: "games.tinytowns.cards.architectGuild.name",
		effect: "games.tinytowns.cards.architectGuild.effect"
	},
	starloom: {
		name: "games.tinytowns.cards.starloom.name",
		effect: "games.tinytowns.cards.starloom.effect"
	},
	skyBaths: {
		name: "games.tinytowns.cards.skyBaths.name",
		effect: "games.tinytowns.cards.skyBaths.effect"
	},
	bondmaker: {
		name: "games.tinytowns.cards.bondmaker.name",
		effect: "games.tinytowns.cards.bondmaker.effect"
	}
}, je = {
	wood: "games.tinytowns.resources.wood",
	wheat: "games.tinytowns.resources.wheat",
	brick: "games.tinytowns.resources.brick",
	glass: "games.tinytowns.resources.glass",
	stone: "games.tinytowns.resources.stone"
}, Me = {
	cottage: "games.tinytowns.groups.cottage",
	food: "games.tinytowns.groups.food",
	civic: "games.tinytowns.groups.civic",
	faith: "games.tinytowns.groups.faith",
	tavern: "games.tinytowns.groups.tavern",
	trade: "games.tinytowns.groups.trade",
	industry: "games.tinytowns.groups.industry",
	monument: "games.tinytowns.groups.monument"
}, Z = (e) => Ae[e];
function Q({ resource: e, flat: t = !1 }) {
	let n = ae[e], [r, i] = {
		wood: ["#91664c", "#422d25"],
		wheat: ["#ffd15c", "#c77a19"],
		brick: ["#fb7961", "#b62d2d"],
		glass: ["#70d2cf", "#16727e"],
		stone: ["#d8d0b4", "#8b826e"]
	}[e];
	return /* @__PURE__ */ h("svg", {
		className: "tinytowns-cube",
		viewBox: "0 0 64 64",
		"aria-hidden": "true",
		children: t ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("rect", {
			x: "2",
			y: "2",
			width: "60",
			height: "60",
			rx: "1",
			fill: n,
			stroke: "#fff",
			strokeWidth: "2"
		}), /* @__PURE__ */ h("path", {
			d: "M5 5H59",
			stroke: r,
			strokeWidth: "2"
		})] }) : /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M5 19L38 7L60 21L28 34Z",
				fill: r
			}),
			/* @__PURE__ */ h("path", {
				d: "M5 19L28 34V61L5 46Z",
				fill: i
			}),
			/* @__PURE__ */ h("path", {
				d: "M28 34L60 21V48L28 61Z",
				fill: n
			}),
			/* @__PURE__ */ h("path", {
				d: "M7 19L28 32L58 21M29 35V58",
				fill: "none",
				stroke: "#fff5d9",
				strokeOpacity: ".42",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ h("path", {
				d: "M36 36V49M43 31V54M51 30V45",
				stroke: i,
				strokeWidth: ".7",
				opacity: ".19"
			}),
			/* @__PURE__ */ h("path", {
				d: "M12 28V44M20 34V49",
				stroke: "#fff3d2",
				strokeWidth: ".65",
				opacity: ".17"
			})
		] })
	});
}
function Ne({ type: e }) {
	return /* @__PURE__ */ h("img", {
		className: "tinytowns-type",
		src: p(`games/tinytowns/live/icon-${e}.svg`),
		alt: "",
		draggable: !1
	});
}
function Pe({ type: e }) {
	return /* @__PURE__ */ h("span", {
		className: "tinytowns-wood-piece",
		children: /* @__PURE__ */ h(Ne, { type: e })
	});
}
function Fe() {
	return /* @__PURE__ */ h("svg", {
		className: "tinytowns-hammer-art",
		viewBox: "0 0 44 50",
		"aria-hidden": "true",
		children: /* @__PURE__ */ g("g", {
			transform: "translate(21 12) rotate(-24)",
			children: [
				/* @__PURE__ */ h("path", {
					d: "M-4 3H5V31Q0 36-4 31Z",
					fill: "#c19357",
					stroke: "#694c32"
				}),
				/* @__PURE__ */ h("path", {
					d: "M-17-5Q0-10 18-5V7Q0 11-17 7Z",
					fill: "#e3e0d1",
					stroke: "#746d5d",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ h("path", {
					d: "M-14-3H13",
					stroke: "#fff8df",
					strokeWidth: "2"
				})
			]
		})
	});
}
function Ie({ pattern: e }) {
	let t = o(), n = Math.max(...e.map((e) => e[0])) + 1, r = Math.max(...e.map((e) => e[1])) + 1;
	return /* @__PURE__ */ h("div", {
		className: "tinytowns-pattern",
		role: "img",
		"aria-label": e.map(([e, n, r]) => `${t(je[r])} ${e + 1},${n + 1}`).join("; "),
		style: {
			"--tinytowns-pattern-w": n,
			"--tinytowns-pattern-h": r
		},
		children: e.map(([e, t, n]) => /* @__PURE__ */ h("span", {
			style: {
				gridColumn: e + 1,
				gridRow: t + 1
			},
			children: /* @__PURE__ */ h(Q, {
				resource: n,
				flat: !0
			})
		}, `${e}:${t}`))
	});
}
function Le({ id: e, selected: t = !1, available: n = !1, onSelect: r, onDetails: i, compact: a = !1 }) {
	let s = o(), c = T[e], { ref: d } = u(`tinytowns-card:${e}`), { ref: f } = u(`tinytowns-card-piece:${e}`);
	return /* @__PURE__ */ g("div", {
		ref: d,
		className: `tinytowns-card${a ? " tinytowns-card-compact" : ""}`,
		"data-selected": t,
		"data-available": n,
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			className: "tinytowns-card-face",
			onClick: r ?? i,
			disabled: !r && !i,
			"aria-pressed": r ? t : void 0,
			"aria-label": s(Z(e).name),
			children: [
				/* @__PURE__ */ g("div", {
					className: "tinytowns-card-title",
					children: [/* @__PURE__ */ h("strong", { children: s(Z(e).name) }), /* @__PURE__ */ h("span", {
						className: "tinytowns-category",
						ref: f,
						children: /* @__PURE__ */ h(Ne, { type: c.group })
					})]
				}),
				/* @__PURE__ */ h("img", {
					className: "tinytowns-card-art",
					src: p(`games/tinytowns/live/art-${c.art}.svg`),
					alt: "",
					draggable: !1
				}),
				/* @__PURE__ */ h("div", {
					className: "tinytowns-card-pattern",
					children: /* @__PURE__ */ h(Ie, { pattern: c.pattern })
				})
			]
		}), /* @__PURE__ */ g("button", {
			type: "button",
			className: "tinytowns-card-detail",
			onClick: i,
			disabled: !i,
			"aria-label": `${s("games.tinytowns.details")} · ${s(Z(e).name)}`,
			children: [/* @__PURE__ */ h("span", { children: s(Z(e).effect) }), /* @__PURE__ */ h(l, { size: 16 })]
		})]
	});
}
function Re() {
	return /* @__PURE__ */ h("svg", {
		className: "tinytowns-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ h("rect", {
			x: "3",
			y: "3",
			width: "94",
			height: "94",
			rx: "4",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "7 5",
			vectorEffect: "non-scaling-stroke"
		})
	});
}
function ze({ resource: e, anchor: t }) {
	let { ref: n, hidden: r } = u(t);
	return /* @__PURE__ */ h("span", {
		ref: n,
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ h(Q, { resource: e })
	});
}
function Be({ town: e, index: t, legal: n, selected: r, preview: i, onClick: a, disabled: s }) {
	let c = o(), l = e.cells[t], d = l.building ? T[l.building].group : null, { ref: f, hidden: p } = u(`tinytowns-cell:${e.rid}:${t}`), m = [
		c("games.tinytowns.cell", {
			row: (t >> 2) + 1,
			col: t % 4 + 1
		}),
		l.building ? c(Z(l.building).name) : l.resource ? c(je[l.resource]) : c("games.tinytowns.empty"),
		e.fed.includes(t) ? c("games.tinytowns.fed") : ""
	].filter(Boolean).join(" · ");
	return /* @__PURE__ */ g("button", {
		ref: f,
		type: "button",
		className: "tinytowns-square",
		"data-fx-hidden": p,
		"data-legal": n,
		"data-selected": r,
		"aria-label": m,
		"aria-pressed": r,
		disabled: s,
		onClick: () => a(t),
		children: [
			d && /* @__PURE__ */ g("span", {
				className: "tinytowns-building",
				"data-fed": e.fed.includes(t),
				children: [/* @__PURE__ */ h(Pe, { type: d }), F(l) > 0 && /* @__PURE__ */ h("span", {
					className: "tinytowns-fed",
					"aria-hidden": "true",
					children: e.fed.includes(t) ? "✓" : "○"
				})]
			}),
			l.resource && /* @__PURE__ */ h("span", {
				className: "tinytowns-resource-piece",
				children: /* @__PURE__ */ h(Q, { resource: l.resource })
			}),
			i && !l.resource && !l.building && /* @__PURE__ */ h("span", {
				className: "tinytowns-preview-piece",
				children: /* @__PURE__ */ h(Q, { resource: i })
			}),
			l.marker && /* @__PURE__ */ h("span", {
				className: "tinytowns-marker",
				children: /* @__PURE__ */ h(Q, {
					resource: l.marker,
					flat: !0
				})
			}),
			l.stored.length > 0 && /* @__PURE__ */ h("span", {
				className: "tinytowns-stored",
				children: l.stored.map((n, r) => /* @__PURE__ */ h(ze, {
					resource: n,
					anchor: `tinytowns-stored:${e.rid}:${t}:${r}`
				}, r))
			}),
			n && /* @__PURE__ */ h(Re, {})
		]
	});
}
function Ve({ town: e, name: t, legal: n = [], selected: r = [], preview: i, onClick: a, readOnly: s = !1 }) {
	let c = o(), { ref: l } = u(`tinytowns-town:${e.rid}`);
	return /* @__PURE__ */ g("div", {
		className: "tinytowns-town-area",
		ref: l,
		children: [/* @__PURE__ */ g("div", {
			className: "tinytowns-town-plaque",
			children: [/* @__PURE__ */ h("strong", { children: c("games.tinytowns.board", { name: t }) }), /* @__PURE__ */ g("span", { children: [
				e.score.total,
				" ",
				/* @__PURE__ */ h("small", { children: c("games.tinytowns.score") })
			] })]
		}), /* @__PURE__ */ h("div", {
			className: "tinytowns-board",
			style: { backgroundImage: `url("${p("games/tinytowns/live/meadow.svg")}")` },
			role: "group",
			"aria-label": c("games.tinytowns.board", { name: t }),
			children: e.cells.map((t, o) => /* @__PURE__ */ h(Be, {
				town: e,
				index: o,
				legal: n.includes(o),
				selected: r.includes(o),
				preview: n.includes(o) ? i : void 0,
				onClick: a,
				disabled: s ? !e.cells[o].building && !e.cells[o].resource : !1
			}, o))
		})]
	});
}
function He({ town: e }) {
	return /* @__PURE__ */ h("span", {
		className: "tinytowns-mini-town",
		"aria-hidden": "true",
		style: { backgroundImage: `url("${p("games/tinytowns/live/meadow.svg")}")` },
		children: e.cells.map((e, t) => /* @__PURE__ */ h("span", { children: e.building ? /* @__PURE__ */ h(Ne, { type: T[e.building].group }) : e.resource ? /* @__PURE__ */ h(Q, { resource: e.resource }) : null }, t))
	});
}
function Ue({ resource: e, selected: t = !1, disabled: n = !1, onClick: r, offer: i, supplyAnchor: a = !0 }) {
	let s = o(), { ref: c } = u(a ? `tinytowns-supply:${e}${i === void 0 ? "" : `:${i}`}` : null);
	return /* @__PURE__ */ g("button", {
		type: "button",
		className: "tinytowns-supply-piece",
		"data-selected": t,
		disabled: n,
		"aria-pressed": t,
		"aria-label": s(je[e]),
		onClick: r,
		children: [/* @__PURE__ */ h("span", {
			className: "tinytowns-supply-cube",
			ref: c,
			children: /* @__PURE__ */ h(Q, { resource: e })
		}), /* @__PURE__ */ h("span", { children: s(je[e]) })]
	});
}
function We({ title: e, onClose: t, children: r, className: a = "" }) {
	let s = i(null), c = o();
	return n(() => {
		let e = document.activeElement;
		return s.current?.focus(), () => e?.focus();
	}, []), /* @__PURE__ */ h("div", {
		className: "tinytowns-modal-backdrop",
		onClick: t,
		children: /* @__PURE__ */ g("section", {
			ref: s,
			className: `tinytowns-dialog ${a}`,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			tabIndex: -1,
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				if (e.key === "Escape" && (e.stopPropagation(), t()), e.key === "Tab") {
					let t = [...s.current?.querySelectorAll("button:not(:disabled),[tabindex=\"0\"],input") ?? []].filter((e) => e.offsetParent !== null), n = t[0], r = t.at(-1);
					e.shiftKey && (document.activeElement === n || document.activeElement === s.current) ? (e.preventDefault(), r?.focus()) : !e.shiftKey && (document.activeElement === r || document.activeElement === s.current) && (e.preventDefault(), n?.focus());
				}
			},
			children: [/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("h2", { children: e }), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: t,
				"aria-label": c("games.tinytowns.close"),
				children: "×"
			})] }), r]
		})
	});
}
function Ge({ id: e, onClose: t, secret: n = !1 }) {
	let r = o(), i = T[e];
	return /* @__PURE__ */ g(We, {
		title: r(Z(e).name),
		onClose: t,
		className: "tinytowns-details",
		children: [
			/* @__PURE__ */ h("img", {
				className: "tinytowns-detail-art",
				src: p(`games/tinytowns/live/art-${i.art}.svg`),
				alt: ""
			}),
			/* @__PURE__ */ h("div", {
				className: "tinytowns-detail-pattern",
				children: /* @__PURE__ */ h(Ie, { pattern: i.pattern })
			}),
			/* @__PURE__ */ g("span", {
				className: "tinytowns-type-caption",
				children: [
					/* @__PURE__ */ h(Ne, { type: i.group }),
					r(Me[i.group]),
					n && /* @__PURE__ */ h("small", { children: r("games.tinytowns.privateCard") })
				]
			}),
			/* @__PURE__ */ h("p", { children: r(Z(e).effect) }),
			/* @__PURE__ */ h("button", {
				type: "button",
				onClick: t,
				children: r("games.tinytowns.returnBoard")
			})
		]
	});
}
//#endregion
//#region src/games/tinytowns/decisions.ts
function Ke(e, t, n) {
	let r = Object.fromEntries(e.towns.map((e) => [e.rid, {
		...e,
		options: e.rid === n ? t?.options ?? [] : [],
		monument: e.rid === n ? t?.monument ?? e.monument : e.monument,
		effects: e.effect ? [e.effect] : [],
		fed: null
	}]));
	return {
		...e,
		towns: r,
		seed: 0,
		cursor: 0,
		deck: [],
		selectedOffer: null
	};
}
//#endregion
//#region src/games/tinytowns/view-player.tsx
function qe(e) {
	let t = e.public, n = e.private, r = o(), [i, c] = a(null), [p, _] = a(null), [v, y] = a(null), [ee, b] = a(0), [te, ne] = a(null), [S, C] = a(null), [w, re] = a(null), [ie, ae] = a(null), [E, D] = a("wood"), [O, oe] = a([]), [k, se] = a(null), { ref: ce } = u(`tinytowns-cavern:${e.myRid}`), A = t.towns.find((t) => t.rid === e.myRid), le = i ?? e.myRid, j = t.towns.find((e) => e.rid === le) ?? A, M = j.rid === e.myRid, ue = t.phase !== "done", P = M && ue && A.completed === null && !A.ready, de = Ke(t, n, e.myRid), I = A.effect, pe = (t) => e.members.find((e) => e.rid === t)?.name ?? t, he = t.phase === "name" && t.master === e.myRid, L = t.phase === "play" && !A.placed && P, R = P && t.phase === "play" && A.placed && I !== null, z = P && t.phase === "play" && A.placed && !I, V = (z || R) && v && (t.cards.includes(v) || v === n?.monument && !A.monumentBuilt) ? v : null, H = Ee(de, e.myRid), U = te?.round === t.round ? te.offer : 0, _e = te?.round === t.round ? te.resource : t.resource ?? t.offers[0] ?? "wood", W = H.filter((e) => e.resource === _e && (t.mode !== "solo" || e.offer === U)), G = V && z ? fe(A.cells, V) : [], ve = G.length ? G[ee % G.length] : void 0, K = ie !== null && A.cells[ie].building && T[A.cells[ie].building].group !== "monument" && !I?.used.includes(ie) ? ie : null, be = V === "bank" ? B(A.cells) : x, xe = be.includes(E) ? E : be[0], J = [];
	M && k ? J = A.cells.flatMap((e, t) => F(e) ? [t] : []) : L ? J = S ? W.filter((e) => e.warehouse === S.warehouse && e.swap === S.swap).map((e) => e.at) : W.map((e) => e.at) : ve && V ? J = me(A.cells, V, ve, A.cells.some((e) => e.building === "obelisk")) : R && I?.kind === "guild" && K === null ? J = A.cells.flatMap((e, t) => e.building && T[e.building].group !== "monument" && !I.used.includes(t) ? [t] : []) : R && V && (J = I?.kind === "guild" && K !== null ? V === "shed" ? A.cells.flatMap((e, t) => N(e) || t === K ? [t] : []) : [K] : A.cells.flatMap((e, t) => N(e) ? [t] : []));
	let Y = (t) => {
		e.send(t), y(null), b(0), C(null), re(null), ae(null), oe([]), se(null);
	}, Se = (e) => {
		if (e === A.monument && A.monumentBuilt) {
			_(e);
			return;
		}
		if (!P || !z && !R || I?.kind === "watch") {
			_(e);
			return;
		}
		if (I?.kind === "watchTrigger" && !I.choices.includes(e)) {
			_(e);
			return;
		}
		y(v === e ? null : e), b(0), D("wood");
	}, Ce = (t) => {
		if (M && k) {
			se(k.includes(t) ? k.filter((e) => e !== t) : [...k, t]);
			return;
		}
		if (!M || !ue || !P) {
			j.cells[t].building && _(j.cells[t].building);
			return;
		}
		if (L) {
			let n = S ? W.find((e) => e.at === t && e.warehouse === S.warehouse && e.swap === S.swap) : W.find((e) => e.at === t && e.warehouse === void 0);
			if (n) {
				Y(n);
				return;
			}
			if (j.cells[t].building === "warehouse" && q(de, e.myRid)) {
				re(t);
				return;
			}
		}
		if (R && I?.kind === "guild" && K === null && J.includes(t)) {
			ae(t);
			return;
		}
		if (V && J.includes(t)) {
			let e = V === "bank" || V === "factory" ? xe : void 0;
			R ? Y({
				type: "effect",
				id: V,
				at: t,
				source: K ?? void 0,
				resource: e
			}) : ve && Y({
				type: "build",
				id: V,
				cells: ve.cells,
				at: t,
				resource: e
			});
			return;
		}
		j.cells[t].building && _(j.cells[t].building);
	}, we = () => {
		y(null), ae(null), C(null), se(null);
	}, Te = A.completed !== null, De = t.phase === "done" ? r("games.tinytowns.completed") : t.phase === "monument" ? r("games.tinytowns.chooseMonument") : Te ? r("games.tinytowns.completed") : he ? r("games.tinytowns.nameResource") : t.phase === "name" || A.ready ? r("games.tinytowns.waiting") : L ? r("games.tinytowns.placeResource") : I?.kind === "watch" ? r("games.tinytowns.watchPrompt") : I?.kind === "guild" ? r("games.tinytowns.guildPrompt") : I?.kind === "watchTrigger" ? r("games.tinytowns.watchTrigger") : r(I ? "games.tinytowns.grovePrompt" : "games.tinytowns.buildPrompt"), Oe = (e) => z && !(e === n?.monument && A.monumentBuilt) && fe(A.cells, e).length > 0 && (e !== "bank" || B(A.cells).length > 0), X = M ? n?.monument : j.monument, ke = t.phase === "monument" && !!n?.options.length, Ae = R && I?.kind === "watch", Me = p !== null || w !== null, Pe = /* @__PURE__ */ g("div", {
		className: "tinytowns-resources",
		"data-passive": !he && !L,
		"aria-label": r("games.tinytowns.placeResource"),
		children: [t.mode === "solo" && /* @__PURE__ */ h("div", {
			className: "tinytowns-offers",
			children: t.offers.map((e, n) => /* @__PURE__ */ h(Ue, {
				resource: e,
				offer: n,
				selected: U === n,
				disabled: !L,
				onClick: () => {
					ne({
						round: t.round,
						resource: e,
						offer: n
					}), C(null);
				}
			}, n))
		}), /* @__PURE__ */ h("div", {
			className: "tinytowns-supply",
			children: x.map((e) => /* @__PURE__ */ h(Ue, {
				resource: e,
				selected: (he || L) && _e === e,
				disabled: he ? !B(A.cells).includes(e) : !L || !H.some((n) => n.resource === e && (t.mode !== "solo" || n.offer === U)),
				onClick: () => he ? Y({
					type: "name",
					resource: e
				}) : (ne({
					round: t.round,
					resource: e,
					offer: U
				}), C(null))
			}, e))
		})]
	}), Re = /* @__PURE__ */ h("div", {
		className: "tinytowns-local-tools",
		"data-active": !!V || !!k,
		children: k ? /* @__PURE__ */ g("div", {
			className: "tinytowns-feed-choice",
			children: [/* @__PURE__ */ h("span", { children: r("games.tinytowns.feedPrompt") }), !ge(A.cells, k) && /* @__PURE__ */ h("span", {
				role: "alert",
				children: r("games.tinytowns.feedInvalid")
			})]
		}) : V ? /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "tinytowns-current-card",
				onClick: () => _(V),
				"aria-label": `${r("games.tinytowns.details")} · ${r(Z(V).name)}`,
				children: [
					/* @__PURE__ */ h(Ne, { type: T[V].group }),
					/* @__PURE__ */ h("strong", { children: r(Z(V).name) }),
					/* @__PURE__ */ h(l, { size: 16 }),
					/* @__PURE__ */ h("small", { children: ve ? r("games.tinytowns.layout", {
						n: ee % G.length + 1,
						total: G.length
					}) : r(z ? "games.tinytowns.noLayout" : "games.tinytowns.selectTarget") })
				]
			}),
			/* @__PURE__ */ h(Ie, { pattern: T[V].pattern }),
			G.length > 1 && /* @__PURE__ */ g("div", {
				className: "tinytowns-layout-switch",
				children: [/* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => b((ee + G.length - 1) % G.length),
					"aria-label": r("games.tinytowns.previousLayout"),
					children: /* @__PURE__ */ h(s, { size: 18 })
				}), /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => b((ee + 1) % G.length),
					"aria-label": r("games.tinytowns.nextLayout"),
					children: /* @__PURE__ */ h(s, {
						size: 18,
						className: "tinytowns-next-icon"
					})
				})]
			}),
			(V === "bank" || V === "factory") && /* @__PURE__ */ h("div", {
				className: "tinytowns-marker-choices",
				"aria-label": r("games.tinytowns.chooseMarker"),
				children: be.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					"aria-label": r(je[e]),
					"aria-pressed": xe === e,
					onClick: () => D(e),
					children: /* @__PURE__ */ h(Q, {
						resource: e,
						flat: !0
					})
				}, e))
			})
		] }) : null
	});
	return /* @__PURE__ */ g("div", {
		className: "tinytowns tinytowns-root",
		children: [
			/* @__PURE__ */ h("div", {
				className: "tinytowns-game-content",
				inert: Me,
				children: /* @__PURE__ */ h(f, {
					adaptive: !0,
					scroll: !1,
					className: "tinytowns-screen",
					banner: /* @__PURE__ */ g("div", {
						className: "tinytowns-banner",
						children: [
							/* @__PURE__ */ g("div", {
								className: "tinytowns-brand",
								children: [/* @__PURE__ */ h("strong", { children: r("games.tinytowns.name") }), /* @__PURE__ */ h("small", { children: "T I N Y  T O W N S" })]
							}),
							/* @__PURE__ */ g("div", {
								className: "tinytowns-phase",
								role: "status",
								children: [/* @__PURE__ */ h("strong", { children: r("games.tinytowns.round", { n: t.round }) }), /* @__PURE__ */ h("span", { children: V ? r("games.tinytowns.selectTarget") : De })]
							}),
							/* @__PURE__ */ h("div", {
								className: "tinytowns-players",
								children: t.players.map((n) => {
									let i = t.towns.find((e) => e.rid === n), a = e.members.find((e) => e.rid === n);
									return /* @__PURE__ */ g("button", {
										type: "button",
										className: "tinytowns-player",
										"aria-pressed": le === n,
										onClick: () => {
											c(n), we();
										},
										children: [
											/* @__PURE__ */ h("span", {
												className: "tinytowns-avatar",
												style: { background: d[a?.colorIndex ?? 0]?.hex },
												children: pe(n).slice(0, 1)
											}),
											/* @__PURE__ */ h("span", {
												className: "tinytowns-player-name",
												children: pe(n)
											}),
											/* @__PURE__ */ g("small", { children: [n === e.myRid ? `${r("games.tinytowns.yourSeat")} · ` : "", i.completed === null ? i.ready ? r("games.tinytowns.roundReady") : i.placed ? r("games.tinytowns.buildingNow") : r("games.tinytowns.placeResource") : r("games.tinytowns.completed")] }),
											t.mode === "master" && t.master === n && /* @__PURE__ */ h("span", {
												className: "tinytowns-hammer",
												title: r("games.tinytowns.master"),
												children: /* @__PURE__ */ h(Fe, {})
											})
										]
									}, n);
								})
							})
						]
					}),
					actionsHeight: "tinytowns-actions-slot",
					actions: /* @__PURE__ */ g("div", {
						className: "tinytowns-actions",
						children: [
							/* @__PURE__ */ h("div", {
								className: "tinytowns-action-status",
								children: M ? /* @__PURE__ */ h("span", { children: Te ? r("games.tinytowns.completed") : A.ready ? r("games.tinytowns.waiting") : S ? r("games.tinytowns.warehouseSwap") : V ? r(Z(V).name) : t.resource ? /* @__PURE__ */ g(m, { children: [
									/* @__PURE__ */ h("span", {
										className: "tinytowns-status-cube",
										children: /* @__PURE__ */ h(Q, { resource: t.resource })
									}),
									r(je[t.resource]),
									A.placed && /* @__PURE__ */ g(m, { children: [" · ", r("games.tinytowns.placed")] })
								] }) : null }) : /* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => {
										c(e.myRid), we();
									},
									children: pe(e.myRid)
								})
							}),
							(V || S || k) && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: we,
								children: r("games.tinytowns.cancel")
							}),
							t.config.cavern && t.mode !== "solo" && /* @__PURE__ */ g("button", {
								type: "button",
								ref: ce,
								className: "tinytowns-cavern",
								style: { visibility: L ? "visible" : "hidden" },
								disabled: !L || !q(de, e.myRid) || A.cavernUsed >= 2,
								onClick: () => Y({ type: "cavern" }),
								children: [
									r("games.tinytowns.cavern"),
									" · ",
									2 - A.cavernUsed
								]
							}),
							z && !V && !k && A.cells.some((e) => F(e) > 0) && /* @__PURE__ */ h("button", {
								type: "button",
								className: "tinytowns-secondary",
								onClick: () => se([...A.fed]),
								children: r("games.tinytowns.feed")
							}),
							k ? /* @__PURE__ */ h("button", {
								type: "button",
								className: "tinytowns-primary",
								disabled: !ge(A.cells, k),
								onClick: () => Y({
									type: "feed",
									cells: k
								}),
								children: r("games.tinytowns.confirm")
							}) : R && I?.kind !== "watch" ? /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => Y({
									type: "effect",
									skip: !0
								}),
								children: r("games.tinytowns.skip")
							}) : P && t.phase === "play" && A.placed && !I ? /* @__PURE__ */ h("button", {
								type: "button",
								className: "tinytowns-primary",
								onClick: () => Y({ type: "ready" }),
								children: r(A.cells.some(N) ? "games.tinytowns.ready" : "games.tinytowns.finish")
							}) : P && ye(de, e.myRid) ? /* @__PURE__ */ h("button", {
								type: "button",
								className: "tinytowns-primary",
								onClick: () => Y({ type: "finish" }),
								children: r("games.tinytowns.finish")
							}) : null
						]
					}),
					children: /* @__PURE__ */ g("div", {
						className: "tinytowns-layout",
						children: [
							/* @__PURE__ */ g("section", {
								className: "tinytowns-town-column",
								children: [/* @__PURE__ */ h(Ve, {
									town: j,
									name: pe(j.rid),
									legal: J,
									selected: k ?? ve?.cells ?? (K === null ? [] : [K]),
									preview: L && !S ? _e : void 0,
									onClick: Ce,
									readOnly: !P
								}), /* @__PURE__ */ g("div", {
									className: "tinytowns-context",
									"data-show-tools": !!V || !!k,
									children: [Pe, Re]
								})]
							}),
							/* @__PURE__ */ g("section", {
								className: "tinytowns-library",
								"aria-label": r("games.tinytowns.optBuildings"),
								children: [/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("span", { children: r("games.tinytowns.optBuildings") }), X && /* @__PURE__ */ g("div", {
									className: "tinytowns-monument-controls",
									children: [/* @__PURE__ */ g("button", {
										type: "button",
										onClick: () => Se(X),
										children: [/* @__PURE__ */ h(Ne, { type: "monument" }), /* @__PURE__ */ h("span", { children: r("games.tinytowns.monument") })]
									}), /* @__PURE__ */ h("button", {
										type: "button",
										"aria-label": `${r("games.tinytowns.details")} · ${r(Z(X).name)}`,
										onClick: () => _(X),
										children: /* @__PURE__ */ h(l, { size: 15 })
									})]
								})] }), /* @__PURE__ */ g("div", {
									className: "tinytowns-cards",
									children: [t.cards.map((e) => /* @__PURE__ */ h(Le, {
										id: e,
										selected: V === e,
										available: Oe(e),
										onSelect: () => Se(e),
										onDetails: () => _(e)
									}, e)), X ? /* @__PURE__ */ g("div", {
										className: "tinytowns-side-monument",
										children: [/* @__PURE__ */ h(Le, {
											id: X,
											selected: V === X,
											available: Oe(X),
											onSelect: () => Se(X),
											onDetails: () => _(X)
										}), M && !A.monumentBuilt && /* @__PURE__ */ h("small", { children: r("games.tinytowns.privateCard") })]
									}) : t.config.monuments && /* @__PURE__ */ h("div", {
										className: "tinytowns-secret-monument",
										"aria-label": r("games.tinytowns.monumentHidden"),
										children: /* @__PURE__ */ h(Ne, { type: "monument" })
									})]
								})]
							}),
							(ke || Ae) && /* @__PURE__ */ g("div", {
								className: "tinytowns-choice-screen",
								children: [
									/* @__PURE__ */ h("h2", { children: r(ke ? "games.tinytowns.chooseMonument" : "games.tinytowns.watchPrompt") }),
									/* @__PURE__ */ h("div", {
										className: "tinytowns-choice-cards",
										children: (ke ? n.options : t.cards).map((e) => /* @__PURE__ */ h(Le, {
											id: e,
											selected: O.includes(e),
											onDetails: () => _(e),
											onSelect: () => ke ? Y({
												type: "monument",
												id: e
											}) : oe(O.includes(e) ? O.filter((t) => t !== e) : O.length < 3 ? [...O, e] : O)
										}, e))
									}),
									Ae && /* @__PURE__ */ g("button", {
										type: "button",
										className: "tinytowns-primary",
										disabled: O.length !== 3,
										onClick: () => Y({
											type: "effect",
											choices: O
										}),
										children: [
											r("games.tinytowns.confirm"),
											" (",
											O.length,
											"/3)"
										]
									})
								]
							})
						]
					})
				})
			}),
			p && /* @__PURE__ */ h(Ge, {
				id: p,
				onClose: () => _(null),
				secret: p === n?.monument && !A.monumentBuilt
			}),
			w !== null && /* @__PURE__ */ g(We, {
				title: r("games.tinytowns.warehouseSwap"),
				onClose: () => re(null),
				children: [/* @__PURE__ */ h("div", {
					className: "tinytowns-storage-choice",
					children: A.cells[w].stored.map((e, t) => /* @__PURE__ */ h(Ue, {
						resource: e,
						supplyAnchor: !1,
						onClick: () => {
							C({
								warehouse: w,
								swap: t
							}), re(null);
						}
					}, t))
				}), A.cells[w].stored.length < 3 && /* @__PURE__ */ h("button", {
					type: "button",
					className: "tinytowns-primary",
					onClick: () => {
						let e = W.find((e) => e.warehouse === w && e.swap === void 0);
						e && Y(e);
					},
					children: r("games.tinytowns.warehouseStore")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/tinytowns/bot.ts
var Je = {
	progress: 1.8,
	completion: 5,
	space: .3,
	food: 1.4,
	score: 1
};
function Ye(e) {
	let t = 2 ** 32 - 2 ** 32 % e.length, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return e[n[0] % e.length];
}
function $(e, t, n) {
	let r = T[t], i = e.filter((e) => e.building === t).length, a = e.filter((e) => P(e) === "cottage").length, o = e.filter((e) => P(e) === "food").length;
	return r.group === "food" ? (a > o * 3.5 ? 8 : o ? 2 : 6) * n.food : r.group === "cottage" ? a < 6 ? 7 : 4 : r.group === "monument" ? t === "elderTree" ? 10 : 8 : t === "almshouse" ? [
		3,
		9,
		-3,
		17,
		-4,
		24
	][Math.min(5, i)] : t === "tavern" ? [
		4,
		5,
		6,
		7,
		8,
		1
	][Math.min(5, i)] : t === "chapel" ? Math.max(3, a) : t === "warehouse" ? i ? 1 : 4 : t === "factory" ? i ? 2 : 6 : t === "tradingPost" ? i < 3 ? 6 : 2 : 4;
}
function Xe(e, t, n) {
	let r = Array(16).fill(0), i = 0;
	for (let a of t) {
		let t = $(e, a, n);
		for (let o of I(T[a].pattern)) {
			let a = Math.max(...o.map((e) => e[0])) + 1, s = Math.max(...o.map((e) => e[1])) + 1;
			for (let c = 0; c <= 4 - s; c++) for (let s = 0; s <= 4 - a; s++) {
				let a = o.map(([e, t]) => (c + t) * 4 + s + e);
				if (a.some((t, n) => e[t].building && e[t].building !== "tradingPost" || e[t].resource && e[t].resource !== o[n][2])) continue;
				let l = a.filter((t) => !N(e[t])).length;
				if (!l) continue;
				let u = (l / a.length) ** 2 * t * n.progress + (l === a.length ? n.completion : 0);
				i = Math.max(i, u);
				for (let t of a) e[t].resource && (r[t] = Math.max(r[t], u / a.length));
			}
		}
	}
	return r.reduce((e, t) => e + t, 0) + i * .4 + e.filter(N).length * n.space;
}
var Ze = (e, t) => t === "factory" ? "wood" : t === "bank" ? B(e)[0] : void 0;
function Qe(e = Je) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.towns.find((e) => e.rid === n.rid);
		if (!a || r.phase === "done") return null;
		if (r.phase === "monument") return i?.options.length ? { action: {
			type: "monument",
			id: n.difficulty === "weak" ? Ye(i.options) : [...i.options].sort((e, t) => {
				let n = [
					"cathedralCaterina",
					"mausoleum",
					"obelisk",
					"groveUniversity",
					"elderTree",
					"archive",
					"mandrasPalace",
					"silvaForum",
					"starloom",
					"architectGuild",
					"skyBaths",
					"barrettCastle",
					"bondmaker",
					"opaleye",
					"fortIronweed"
				];
				return n.indexOf(e) - n.indexOf(t);
			})[0]
		} } : null;
		if (a.completed !== null || a.ready) return null;
		let o = Ke(r, i, n.rid), s = o.towns[n.rid], c = [...r.cards, ...i?.monument && !s.monumentBuilt ? [i.monument] : []];
		if (r.phase === "name" && r.master !== n.rid) return null;
		if (r.phase === "play" && !s.placed) {
			let t = Ee(o, n.rid);
			if (!t.length) return ye(o, n.rid) ? { action: { type: "finish" } } : null;
			if (n.difficulty === "weak") return { action: Ye(t) };
			let i = t[0], a = -Infinity;
			for (let n of t) {
				let t = structuredClone(s.cells);
				n.warehouse === void 0 ? n.bondmaker ? t[n.at].stored.push(n.resource) : t[n.at].resource = n.resource : n.swap === void 0 ? t[n.warehouse].stored.push(n.resource) : (t[n.at].resource = t[n.warehouse].stored[n.swap], t[n.warehouse].stored[n.swap] = n.resource);
				let r = Xe(t, c, e) - (n.warehouse === void 0 ? 0 : .7);
				r > a && (a = r, i = n);
			}
			return r.config.cavern && r.mode !== "solo" && s.cavernUsed < 2 && q(o, n.rid) && a < Xe(s.cells, c, e) - 1 ? { action: { type: "cavern" } } : { action: i };
		}
		if (r.phase === "name") {
			let t = B(s.cells);
			if (!t.length) return ye(o, n.rid) ? { action: { type: "finish" } } : null;
			if (n.difficulty === "weak") return { action: {
				type: "name",
				resource: Ye(t)
			} };
			let r = t[0], i = -Infinity;
			for (let n of t) for (let t = 0; t < 16; t++) if (N(s.cells[t])) {
				let a = structuredClone(s.cells);
				a[t].resource = n;
				let o = Xe(a, c, e);
				o > i && (i = o, r = n);
			}
			return { action: {
				type: "name",
				resource: r
			} };
		}
		if (s.effects.length) {
			let t = s.effects[0];
			if (t.kind === "watch") return { action: {
				type: "effect",
				choices: [...r.cards].sort((e, t) => T[e].pattern.length - T[t].pattern.length).slice(0, 3)
			} };
			let n = s.cells.flatMap((e, t) => N(e) ? [t] : []);
			if (t.kind === "guild") {
				let n = s.cells.flatMap((e, n) => e.building && T[e.building].group !== "monument" && !t.used.includes(n) ? [n] : []);
				if (!n.length) return { action: {
					type: "effect",
					skip: !0
				} };
				let i = n.sort((t, n) => $(s.cells, s.cells[t].building, e) - $(s.cells, s.cells[n].building, e))[0], a = [...r.cards].filter((e) => e !== s.cells[i].building && $e(s.cells, e)).sort((t, n) => $(s.cells, n, e) - $(s.cells, t, e))[0];
				return a ? { action: {
					type: "effect",
					id: a,
					source: i,
					at: i,
					resource: Ze(s.cells, a)
				} } : { action: {
					type: "effect",
					skip: !0
				} };
			}
			if (!n.length) return { action: {
				type: "effect",
				skip: !0
			} };
			let i = (t.kind === "watchTrigger" ? t.choices : r.cards).filter((e) => $e(s.cells, e)).sort((t, n) => $(s.cells, n, e) - $(s.cells, t, e))[0];
			if (!i) return { action: {
				type: "effect",
				skip: !0
			} };
			let a = n[0], o = -Infinity;
			for (let e of n) {
				let t = structuredClone(s.cells);
				t[e] = {
					...M(),
					building: i
				};
				let n = z({
					...s,
					cells: t,
					fed: null
				}).total;
				n > o && (o = n, a = e);
			}
			return { action: {
				type: "effect",
				id: i,
				at: a,
				resource: Ze(s.cells, i)
			} };
		}
		let l = [];
		for (let e of c) if ($e(s.cells, e)) for (let t of fe(s.cells, e)) for (let n of me(s.cells, e, t, s.cells.some((e) => e.building === "obelisk"))) l.push({
			type: "build",
			id: e,
			cells: t.cells,
			at: n,
			resource: Ze(s.cells, e)
		});
		if (l.length) {
			if (n.difficulty === "weak") return { action: Ye(l) };
			let t = l[0], r = -Infinity;
			for (let n of l) {
				let i = structuredClone(s.cells);
				for (let e of n.cells) i[e].resource && !i[e].building && (i[e] = M());
				i[n.at] = {
					...M(),
					building: n.id,
					marker: n.resource ?? null
				};
				let a = z({
					...s,
					cells: i,
					fed: null
				}).total * e.score + Xe(i, c, e) * .4 + $(s.cells, n.id, e);
				a > r && (r = a, t = n);
			}
			return { action: t };
		}
		return { action: { type: "ready" } };
	};
}
function $e(e, t) {
	return t !== "bank" || B(e).length > 0;
}
var et = Qe();
//#endregion
//#region src/games/tinytowns/fx.tsx
function tt({ to: e, parts: t, id: n, ms: a }) {
	let o = i(null);
	return r(() => {
		let n = o.current;
		if (!n) return;
		let r = [...n.children].map((n, r) => {
			if (r === t.length) return n.animate([
				{
					transform: "translateY(-12px) scale(.2)",
					opacity: 0
				},
				{
					transform: "translateY(-7px) scale(.85)",
					opacity: .8,
					offset: .55
				},
				{
					transform: "translateY(2px) scale(1.06)",
					opacity: 1,
					offset: .84
				},
				{
					transform: "translateY(0) scale(1)",
					opacity: 1
				}
			], {
				duration: a,
				easing: "cubic-bezier(.2,.7,.3,1)",
				fill: "both"
			});
			let i = t[r].from, o = e.x + e.w / 2 - i.x - i.w / 2, s = e.y + e.h / 2 - i.y - i.h / 2;
			return n.animate([
				{
					transform: "translate(0,0) scale(1)",
					opacity: 1
				},
				{
					transform: `translate(${o * .8}px,${s * .8 - 8}px) scale(.65)`,
					opacity: .9,
					offset: .58
				},
				{
					transform: `translate(${o}px,${s}px) scale(.1)`,
					opacity: 0
				}
			], {
				duration: a * .8,
				easing: "cubic-bezier(.3,.7,.25,1)",
				fill: "both"
			});
		});
		return () => r.forEach((e) => e.cancel());
	}, [
		e,
		t,
		a
	]), /* @__PURE__ */ g("div", {
		ref: o,
		children: [t.map(({ from: e, resource: t }, n) => /* @__PURE__ */ h("div", {
			style: {
				position: "absolute",
				left: e.x + e.w * .18,
				top: e.y + e.h * .18,
				width: e.w * .64,
				height: e.h * .64
			},
			children: /* @__PURE__ */ h(Q, { resource: t })
		}, n)), /* @__PURE__ */ h("div", {
			style: {
				position: "absolute",
				left: e.x + e.w * .17,
				top: e.y + e.h * .145,
				width: e.w * .66,
				height: e.h * .71,
				display: "flex",
				alignItems: "center",
				justifyContent: "center"
			},
			children: /* @__PURE__ */ h(Pe, { type: T[n].group })
		})]
	});
}
var nt = {
	place(e, t) {
		let n = e.data, r = n.stored === void 0 ? `tinytowns-cell:${e.rid}:${n.at}` : `tinytowns-stored:${e.rid}:${n.at}:${n.stored}`, i = t.anchor(r), a = t.anchor(n.from === void 0 ? `tinytowns-supply:${n.resource}${n.offer === void 0 ? "" : `:${n.offer}`}` : n.fromStored === void 0 ? `tinytowns-cell:${e.rid}:${n.from}` : `tinytowns-stored:${e.rid}:${n.from}:${n.fromStored}`);
		if (!a || !i) return null;
		let o = t.queued ? 130 : H.place, s = n.stored === void 0 ? {
			...i,
			x: i.x + i.w * .18,
			y: i.y + i.h * .18,
			w: i.w * .64,
			h: i.h * .64
		} : i, c = n.from !== void 0 && n.fromStored === void 0 ? {
			...a,
			x: a.x + a.w * .18,
			y: a.y + a.h * .18,
			w: a.w * .64,
			h: a.h * .64
		} : a;
		return {
			ms: o,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ h(_, {
				from: c,
				to: s,
				ms: o,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: c.w,
						height: c.h
					},
					children: /* @__PURE__ */ h(Q, { resource: n.resource })
				})
			})
		};
	},
	build(e, t) {
		let n = e.data, r = `tinytowns-cell:${e.rid}:${n.at}`, i = t.anchor(r);
		if (!i) return null;
		let a = (n.consumed ?? []).flatMap((n) => {
			let r = t.anchor(`tinytowns-cell:${e.rid}:${n.at}`);
			return r ? [{
				from: r,
				resource: n.resource
			}] : [];
		}), o = t.queued ? 150 : H.build;
		if (!a.length) {
			let e = t.anchor(`tinytowns-card-piece:${n.id}`);
			if (e && e.w > 0 && e.h > 0) {
				let a = {
					x: e.x + 3,
					y: e.y + 3,
					w: e.w - 6,
					h: e.h - 6
				}, s = {
					x: i.x + i.w * .17,
					y: i.y + i.h * .145,
					w: i.w * .66,
					h: i.h * .71
				};
				return {
					ms: o,
					hide: t.queued ? [] : [r],
					node: /* @__PURE__ */ h(_, {
						from: a,
						to: s,
						ms: o,
						children: /* @__PURE__ */ h("div", {
							style: {
								width: a.w,
								height: a.h
							},
							children: /* @__PURE__ */ h(Pe, { type: T[n.id].group })
						})
					})
				};
			}
		}
		return {
			ms: o,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ h(tt, {
				to: i,
				parts: a,
				id: n.id,
				ms: o
			})
		};
	},
	name(e, t) {
		let n = e.data, r = t.anchor(`tinytowns-supply:${n.resource}`);
		return r ? {
			ms: H.reveal,
			node: /* @__PURE__ */ h(v, {
				at: r,
				ms: H.reveal
			})
		} : null;
	},
	cavern(e, t) {
		let n = e.data, r = t.anchor(`tinytowns-cavern:${e.rid}`), i = t.anchor(`tinytowns-supply:${n.resource}`);
		if (!r || !i) return null;
		let a = i;
		return {
			ms: H.place,
			node: /* @__PURE__ */ h(_, {
				from: a,
				to: {
					...r,
					x: r.x + r.w / 2 - 10,
					y: r.y + r.h / 2 - 10,
					w: 20,
					h: 20
				},
				ms: H.place,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ h(Q, { resource: n.resource })
				})
			})
		};
	},
	finish(e, t) {
		let n = t.anchor(`tinytowns-town:${e.rid}`);
		return n ? {
			ms: H.reveal,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: H.reveal
			})
		} : null;
	}
};
//#endregion
//#region src/games/tinytowns/game-over.tsx
function rt(e) {
	let t = o(), r = e.public, [s, l] = a(!0), [u, d] = a(null), f = i(null), m = i(null), _ = i(null), v = e.result.winner ?? [], y = (t) => e.members.find((e) => e.rid === t)?.name ?? t, ee = v.map(y).join("、"), b = r.players.length === 1, x = r.towns[0].score.total, ne = x >= 38 ? 1 : x >= 32 ? 2 : x >= 25 ? 3 : x >= 18 ? 4 : x >= 10 ? 5 : 6, S = [
		"games.tinytowns.soloRank1",
		"games.tinytowns.soloRank2",
		"games.tinytowns.soloRank3",
		"games.tinytowns.soloRank4",
		"games.tinytowns.soloRank5",
		"games.tinytowns.soloRank6"
	], C = r.towns.find((e) => v.includes(e.rid))?.monument ?? "cottage";
	n(() => {
		f.current?.focus();
	}, []);
	let w = (e) => {
		d(null), l(e), requestAnimationFrame(() => {
			(e ? f : m).current?.focus();
		});
	}, re = () => {
		u === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(), d(null);
	};
	return /* @__PURE__ */ g("div", {
		className: "tinytowns tinytowns-result-wrap",
		children: [
			/* @__PURE__ */ h("div", {
				className: "tinytowns-result-board",
				inert: s,
				children: /* @__PURE__ */ h(qe, {
					...e,
					send: () => {}
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "tinytowns-result-overlay",
				hidden: !s,
				children: /* @__PURE__ */ g("section", {
					ref: _,
					className: "tinytowns-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.tinytowns.result"),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), u ? d(null) : w(!1)), e.key === "Tab") {
							let t = [..._.current?.querySelectorAll("button:not(:disabled)") ?? []].filter((e) => e.offsetParent !== null), n = t[0], r = t.at(-1);
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
						}
					},
					children: [
						/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("strong", { children: t("games.tinytowns.result") }), /* @__PURE__ */ h("button", {
							ref: f,
							type: "button",
							"aria-label": t("games.tinytowns.returnBoard"),
							onClick: () => w(!1),
							children: /* @__PURE__ */ h(c, { size: 20 })
						})] }),
						/* @__PURE__ */ g("div", {
							className: "tinytowns-result-body",
							inert: u !== null,
							children: [
								/* @__PURE__ */ g("div", {
									className: "tinytowns-result-heading",
									children: [/* @__PURE__ */ h("img", {
										src: p(`games/tinytowns/live/art-${T[C].art}.svg`),
										alt: ""
									}), /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("h1", { children: b ? t("games.tinytowns.soloResult") : t(v.length > 1 ? "games.tinytowns.tie" : "games.tinytowns.winner", { names: ee }) }), b && /* @__PURE__ */ h("p", {
										className: "tinytowns-result-subtitle",
										children: t(S[ne - 1])
									})] })]
								}),
								/* @__PURE__ */ h("div", {
									className: "tinytowns-score-scroll",
									tabIndex: 0,
									children: /* @__PURE__ */ g("table", {
										className: "tinytowns-score-table",
										style: { minWidth: r.players.length > 4 ? 80 + r.players.length * 64 : void 0 },
										"aria-label": t("games.tinytowns.score"),
										children: [
											/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "col",
												children: t("games.tinytowns.score")
											}), r.players.map((e) => /* @__PURE__ */ g("th", {
												scope: "col",
												"data-winner": v.includes(e),
												children: [/* @__PURE__ */ h(He, { town: r.towns.find((t) => t.rid === e) }), /* @__PURE__ */ h("span", { children: y(e) })]
											}, e))] }) }),
											/* @__PURE__ */ g("tbody", { children: [te.map((e) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: t(Me[e])
											}), r.players.map((t) => /* @__PURE__ */ h("td", { children: r.towns.find((e) => e.rid === t).score[e] }, t))] }, e)), /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: t("games.tinytowns.emptyPenalty")
											}), r.players.map((e) => /* @__PURE__ */ h("td", { children: r.towns.find((t) => t.rid === e).score.empty }, e))] })] }),
											/* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: t("games.tinytowns.total")
											}), r.players.map((e) => /* @__PURE__ */ h("td", { children: r.towns.find((t) => t.rid === e).score.total }, e))] }) })
										]
									})
								}),
								/* @__PURE__ */ g("div", {
									className: "tinytowns-result-meta",
									children: [e.hintCount !== void 0 && /* @__PURE__ */ h("span", { children: t("games.tinytowns.hintCount", { n: e.hintCount }) }), r.players.filter((t) => !!e.result.autopilot?.[t]).map((n) => /* @__PURE__ */ g("span", { children: [
										y(n),
										" · ",
										t("games.tinytowns.autopilot", { n: Math.round(e.result.autopilot[n] * 100) })
									] }, n))]
								})
							]
						}),
						u ? /* @__PURE__ */ g("div", {
							className: "tinytowns-result-confirm",
							children: [
								/* @__PURE__ */ h("span", { children: t("games.tinytowns.endConfirm") }),
								/* @__PURE__ */ h("button", {
									type: "button",
									autoFocus: !0,
									onClick: re,
									children: t("games.tinytowns.confirm")
								}),
								/* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => d(null),
									children: t("games.tinytowns.cancel")
								})
							]
						}) : /* @__PURE__ */ g("footer", { children: [
							e.onBackToLobby && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => d("lobby"),
								children: t("session.result.backToLobby")
							}),
							e.onPlayAgain && /* @__PURE__ */ h("button", {
								type: "button",
								className: "tinytowns-primary",
								onClick: () => d("again"),
								children: t("session.result.playAgain")
							}),
							!e.onBackToLobby && !e.onPlayAgain && /* @__PURE__ */ h("span", { children: t("session.result.waitHost") })
						] })
					]
				})
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "tinytowns-result-restore",
				ref: m,
				hidden: s,
				onClick: () => w(!0),
				children: t("games.tinytowns.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/tinytowns/options.tsx
function it({ value: e, onChange: t }) {
	let n = o(), r = O.safeParse(e), i = r.success ? r.data : O.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ h(ee, {
				title: n("games.tinytowns.optMode"),
				children: ["master", "townHall"].map((e) => /* @__PURE__ */ h(y, {
					name: "tinytowns-mode",
					value: e,
					checked: i.mode === e,
					label: n(e === "master" ? "games.tinytowns.masterMode" : "games.tinytowns.townHallMode"),
					accent: V.accent,
					onChange: () => t({
						...i,
						mode: e
					})
				}, e))
			}),
			/* @__PURE__ */ h(ee, {
				title: n("games.tinytowns.optBuildings"),
				children: ["first", "random"].map((e) => /* @__PURE__ */ h(y, {
					name: "tinytowns-cards",
					value: e,
					checked: i.buildings === e,
					label: n(e === "first" ? "games.tinytowns.firstBuildings" : "games.tinytowns.randomBuildings"),
					accent: V.accent,
					onChange: () => t({
						...i,
						buildings: e
					})
				}, e))
			}),
			/* @__PURE__ */ h(b, {
				checked: i.monuments,
				label: n("games.tinytowns.optMonuments"),
				accent: V.accent,
				onChange: () => t({
					...i,
					monuments: !i.monuments
				})
			}),
			/* @__PURE__ */ h(b, {
				checked: i.cavern,
				label: n("games.tinytowns.optCavern"),
				accent: V.accent,
				onChange: () => t({
					...i,
					cavern: !i.cavern
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tinytowns/entry.tsx
var at = {
	definition: ke,
	View: qe,
	bot: et,
	fx: nt,
	OverView: rt,
	Options: it,
	locales: {
		zh: {
			name: "小小城鎮",
			desc: "在四行四列城镇中巧用五种资源，拼出建筑配方，建设繁荣小镇。",
			round: "第 {{n}} 轮",
			nameResource: "指定一种资源",
			placeResource: "将资源放入城镇",
			buildPrompt: "选择建筑，再选择配方与落点",
			waiting: "等待其他玩家完成本轮",
			chooseMonument: "选择自己的纪念碑",
			ready: "完成本轮",
			finish: "完成城镇",
			completed: "城镇已完成",
			cancel: "取消",
			close: "关闭",
			confirm: "确认",
			skip: "放弃此效果",
			build: "建造",
			details: "查看卡牌",
			nextLayout: "下一组配方",
			previousLayout: "上一组配方",
			rotate: "旋转配方",
			mirror: "镜像配方",
			layout: "配方 {{n}} / {{total}}",
			noLayout: "尚无完整配方",
			selectTarget: "选择建筑落点",
			chooseMarker: "为建筑选定一种资源",
			cavern: "放入洞穴",
			cavernLeft: "洞穴余量 {{n}}",
			score: "得分",
			board: "{{name}}的城镇",
			cell: "第{{row}}行，第{{col}}列",
			empty: "空格",
			stored: "存储资源",
			warehouseStore: "存入仓库",
			warehouseSwap: "选择换出的资源",
			returnBoard: "回看城镇",
			showResult: "查看计分",
			result: "城镇档案",
			winner: "{{names}}获胜",
			tie: "{{names}}共同获胜",
			soloResult: "城镇建设完成",
			total: "总分",
			emptyPenalty: "空地",
			fed: "已供食",
			feed: "分配供食",
			feedPrompt: "选择获得供食的住宅",
			feedInvalid: "供食数量或范围不符合当前供食建筑的能力。",
			automatic: "自动分配",
			masterTurns: "担任建筑师",
			turns: "{{n}}次",
			monumentHidden: "未公开的纪念碑",
			monument: "纪念碑",
			privateCard: "仅自己可见",
			yourSeat: "你",
			placed: "已放置",
			buildingNow: "建造中",
			roundReady: "已完成本轮",
			watchPrompt: "选择3种不同建筑",
			watchTrigger: "邻居触发了瞭望塔，可放置对应建筑",
			grovePrompt: "在任意空格放置一座普通建筑",
			guildPrompt: "选择被替换的建筑，再选择新建筑",
			effectAt: "选择空格放置建筑",
			endConfirm: "确认结束本局并继续？",
			error: "当前无法执行此操作，请重新选择合法目标。",
			master: "建筑师",
			inspect: "查看城镇",
			optMode: "资源选择",
			masterMode: "轮流指定",
			townHallMode: "市政厅",
			optBuildings: "建筑组合",
			firstBuildings: "首次游玩推荐",
			randomBuildings: "随机组合",
			optMonuments: "纪念碑",
			monumentsOn: "使用纪念碑",
			monumentsOff: "不使用纪念碑",
			optCavern: "洞穴规则",
			cavernOn: "允许2次舍弃",
			cavernOff: "不使用洞穴",
			hintName: "指定{{resource}}。",
			hintPlace: "将{{resource}}放在第{{row}}行、第{{col}}列。",
			hintBuild: "在第{{row}}行、第{{col}}列建造{{name}}。",
			hintReady: "完成本轮。",
			hintMonument: "选择{{name}}。",
			hintEffect: "处理纪念碑的建造效果。",
			hintFinish: "完成城镇并结算得分。",
			hintCavern: "将本轮资源放入洞穴。",
			hintFeed: "分配住宅的供食。",
			resourceCard: "资源牌",
			soloRank1: "建筑大师",
			soloRank2: "城镇规划师",
			soloRank3: "工程师",
			soloRank4: "木匠",
			soloRank5: "建筑学徒",
			soloRank6: "见习建筑师",
			hintCount: "求助{{n}}次",
			autopilot: "托管{{n}}%",
			on: "启用",
			off: "关闭",
			resources: {
				wood: "木材",
				wheat: "麦子",
				brick: "砖块",
				glass: "玻璃",
				stone: "石料"
			},
			groups: {
				cottage: "住宅",
				food: "供食建筑",
				civic: "公共设施",
				faith: "宗教建筑",
				tavern: "酒馆建筑",
				trade: "商业建筑",
				industry: "工业建筑",
				monument: "纪念碑"
			},
			rules: "# 建设自己的小小城镇\n每人拥有一块四行四列城镇。将木材、麦子、砖块、玻璃和石料摆成建筑牌上的配方，移除对应资源，建造建筑并争取得分。每局使用住宅，以及其他六类各一张建筑牌；随机组合会改变可用建筑。若启用纪念碑，每人从私有的两张牌中选择一张，只能建造一次，建成时才向所有人公开。\n\n## 每轮流程\n建筑师指定一种资源，所有尚未完成城镇的玩家先将该资源放入一个空格，再自由决定是否建造建筑。所有玩家完成本轮后，建筑师顺时针传给下一位玩家。已完成城镇的玩家退出后续资源选择。只剩一位玩家时，该玩家可以继续自行指定资源，直到城镇完成。\n\n## 建造与建筑效果\n配方可旋转和镜像，资源的相对位置及种类必须完全相符。每次移除完整配方的资源，再将建筑放在本次移除资源的一个格子上。资源不能自由移动，建筑不能任意移走或搬动；同轮可以依次建造多座建筑，也可以保留配方等待以后建造。棚屋、交易站、仓库、工厂及纪念碑的例外以对应卡牌详情为准。普通建筑和资源没有数量上限。“相邻”仅指上下左右，不含斜角；粮仓明确包含周围8格。\n\n住宅可先于供食建筑建造。最终得分时，农场为任意位置的4座住宅供食，粮仓为周围8格供食，果园为所在行和列供食，温室为一组相连住宅供食。每座住宅只需供食一次。可在城镇中调整供食分配；自动分配会选择得分最高的合法方案。未供食住宅不移除，但通常不获得住宅分。巴雷特城堡对于建筑计分视为2座住宅，供食时也占用两座住宅的容量。各建筑的完整计分与能力见卡牌详情。\n\n## 城镇完成与胜负\n城镇已满时，可以继续使用完整配方建造，或选择完成城镇。本项目对银行作以下边界裁定：五座银行封禁全部资源后，轮到自己指定资源或市政厅自由选择轮时，可以完成城镇；其他玩家指定和资源牌抽取轮仍照常放置资源。所有城镇完成后，移除城镇格内的剩余资源；仓库中的资源保留并按牌面扣分。每个没有建筑的格子扣1分，已供食住宅每座3分，其他建筑与纪念碑分别计分，总分最高者获胜。平分依次比较担任建筑师次数较少、空格较少、住宅较多；仍相同则共同获胜。观星台按同轮完成共享名次计分。\n\n## 可选模式\n洞穴规则：整局最多两次，可以不放置其他玩家指定的资源，将其放入洞穴；洞穴资源不计分也不扣分，自己指定的资源不能使用此能力。市政厅模式中可用于抽牌轮，不能用于每第三轮的自由选择；单人模式不使用洞穴。\n\n市政厅：将15张资源牌洗匀，背面弃掉5张。每个三轮循环，前两轮按翻出的牌放置资源，第三轮每人自行选择资源。牌堆耗尽时重新洗匀全部15张并再次弃5张。工厂、仓库和联结者雕像可用于抽牌轮；银行限制自由选择轮。铁草堡持有者跳过自由选择轮，独自留场时除外。\n\n单人：不使用旅店、银行、铁草堡及欧泊瞭望塔。15张资源牌洗匀后翻开3张，每轮从中选1张并放置对应资源。完成本轮后，将选中的牌放到牌堆底，补1张。工厂、仓库及联结者雕像可以作用于所选资源。最终38分以上为建筑大师，32–37为城镇规划师，25–31为工程师，18–24为木匠，10–17为建筑学徒，9分以下为见习建筑师。",
			cards: {
				warehouse: {
					name: "仓库",
					effect: "每座可存放3个资源。其他玩家指定资源时，可将其存入仓库，或用其交换仓库中的1个资源并将换出的资源放入空格。终局每个存储资源扣1分。"
				},
				tradingPost: {
					name: "交易站",
					effect: "每座1分。可在未来配方中代替任意资源，使用后保留。每次建造至少消耗1个真实资源，建筑不能放在交易站上。"
				},
				factory: {
					name: "工厂",
					effect: "建成时选定1种资源。其他玩家指定该资源时，可改放任意一种资源。"
				},
				bank: {
					name: "银行",
					effect: "每座4分。建成时选定一种尚未被自己其他银行选用的资源。自己担任建筑师时，不能指定银行上选定的资源。"
				},
				well: {
					name: "水井",
					effect: "每座与住宅相邻的边各得1分；住宅不必得到供食。"
				},
				shed: {
					name: "棚屋",
					effect: "每座1分。建成时可放在城镇任意空格，包括本次移除资源后空出的格子。"
				},
				millstone: {
					name: "磨盘",
					effect: "与供食建筑或商业建筑相邻时得2分，最多2分。"
				},
				fountain: {
					name: "喷泉",
					effect: "与另一座喷泉相邻时得2分，最多2分。"
				},
				theater: {
					name: "剧院",
					effect: "同一行或同一列中，每种其他建筑类型得1分；同一类型只计一次，不计剧院。"
				},
				tailor: {
					name: "裁缝铺",
					effect: "每座得1分，再加城镇中央4格中的裁缝铺数量；每座最多5分。"
				},
				market: {
					name: "市场",
					effect: "在其所在行或列中，选择市场较多的一侧，每座市场得1分，包含自身。"
				},
				bakery: {
					name: "面包坊",
					effect: "与供食建筑或工业建筑相邻时得3分。"
				},
				tavern: {
					name: "酒馆",
					effect: "城镇有1至5座酒馆时，共得2、5、9、14、20分。超过5座仍为20分。"
				},
				inn: {
					name: "旅店",
					effect: "所在行和列均没有其他旅店时得3分。单人模式不使用。"
				},
				feastHall: {
					name: "宴会厅",
					effect: "每座2分。如果自己的宴会厅数量多于右手边玩家，每座改得3分。"
				},
				almshouse: {
					name: "济贫院",
					effect: "城镇有1至6座时，共得−1、5、−3、15、−5、26分。超过6座仍为26分。"
				},
				orchard: {
					name: "果园",
					effect: "为与其同一行或同一列的全部住宅供食。"
				},
				greenhouse: {
					name: "温室",
					effect: "每座为一整组上下左右相连的住宅供食。这组住宅不必与温室相邻。"
				},
				granary: {
					name: "粮仓",
					effect: "为周围8格中的住宅供食，包含斜角。"
				},
				farm: {
					name: "农场",
					effect: "每座可为城镇任意位置的4座住宅供食。"
				},
				temple: {
					name: "神庙",
					effect: "与至少2座已供食住宅相邻时得4分。"
				},
				cloister: {
					name: "回廊",
					effect: "城镇四个角落中的每座回廊，使每座回廊得1分。"
				},
				chapel: {
					name: "礼拜堂",
					effect: "每座得分等于城镇中已供食住宅的数量。"
				},
				abbey: {
					name: "修道院",
					effect: "不与住宅、商业或工业建筑相邻时得3分。"
				},
				cottage: {
					name: "住宅",
					effect: "已供食时每座3分，未供食时0分；未供食住宅仍留在城镇中。"
				},
				silvaForum: {
					name: "席尔瓦广场",
					effect: "得1分，再加城镇内最大一组同类型相连建筑的数量。"
				},
				elderTree: {
					name: "古树神龛",
					effect: "建成时，城镇共有1至6座建筑，分别锁定1、2、3、4、5、8分；更多建筑仍为8分。包含自身。"
				},
				opaleye: {
					name: "欧泊瞭望塔",
					effect: "建成时选3种不同普通建筑。左右相邻玩家建造其中一种时，将对应建筑从此牌移到自己任意空格，每种只能触发一次。"
				},
				obelisk: {
					name: "新月方尖碑",
					effect: "此后建造的建筑均可放在城镇任意空格。"
				},
				mandrasPalace: {
					name: "曼德拉斯宫",
					effect: "每种与其相邻的不同建筑类型得2分。"
				},
				groveUniversity: {
					name: "林地大学",
					effect: "得3分。建成后，立即在任意空格放置一座普通建筑。"
				},
				mausoleum: {
					name: "罗迪纳大陵墓",
					effect: "未供食住宅每座也得3分。"
				},
				fortIronweed: {
					name: "铁草堡",
					effect: "得7分。此后不再担任建筑师，除非只剩自己尚未完成城镇。市政厅每第三轮也跳过个人资源，独自留场时除外。"
				},
				cathedralCaterina: {
					name: "卡特琳娜大教堂",
					effect: "得2分。自己城镇的空格不再扣分。"
				},
				barrettCastle: {
					name: "巴雷特城堡",
					effect: "已供食时得5分。对于所有建筑计分，视为2座住宅，不视为纪念碑类型。"
				},
				archive: {
					name: "第二纪元档案馆",
					effect: "城镇中每种不同普通建筑类型得1分，不计纪念碑类型。"
				},
				architectGuild: {
					name: "建筑师公会",
					effect: "得1分。建成时可将至多2座普通建筑分别替换为其他普通建筑，不能选纪念碑；未使用的次数不能保留。"
				},
				starloom: {
					name: "观星台",
					effect: "按城镇完成名次得分：第1名6分、第2名3分、第3名2分，其后0分。同轮完成者共享对应名次分数。"
				},
				skyBaths: {
					name: "天空浴场",
					effect: "城镇每缺少一种建筑类型得2分。包含普通建筑类型及纪念碑类型。"
				},
				bondmaker: {
					name: "联结者雕像",
					effect: "其他玩家指定资源时，可将其放在一座住宅上。每座住宅限存1个资源，该资源不能用于建造。"
				}
			}
		},
		en: {
			name: "Tiny Towns",
			desc: "Arrange five resources into building patterns on a 4×4 grid and create a thriving little town.",
			round: "Round {{n}}",
			nameResource: "Name a resource",
			placeResource: "Place a resource in your town",
			buildPrompt: "Choose a building, layout, and destination",
			waiting: "Waiting for the other players",
			chooseMonument: "Choose your monument",
			ready: "Finish round",
			finish: "Complete town",
			completed: "Town complete",
			cancel: "Cancel",
			close: "Close",
			confirm: "Confirm",
			skip: "Decline this benefit",
			build: "Construct",
			details: "Card details",
			nextLayout: "Next layout",
			previousLayout: "Previous layout",
			rotate: "Rotate pattern",
			mirror: "Mirror pattern",
			layout: "Layout {{n}} / {{total}}",
			noLayout: "No complete layout yet",
			selectTarget: "Choose the building destination",
			chooseMarker: "Assign a resource to this building",
			cavern: "Use cavern",
			cavernLeft: "Cavern spaces: {{n}}",
			score: "Score",
			board: "{{name}}’s town",
			cell: "Row {{row}}, column {{col}}",
			empty: "Empty square",
			stored: "Stored resources",
			warehouseStore: "Store in Warehouse",
			warehouseSwap: "Choose a resource to exchange",
			returnBoard: "View towns",
			showResult: "Show scores",
			result: "Town records",
			winner: "{{names}} wins",
			tie: "{{names}} share victory",
			soloResult: "Your town is complete",
			total: "Total",
			emptyPenalty: "Empty squares",
			fed: "Fed",
			feed: "Allocate food",
			feedPrompt: "Choose cottages to feed",
			feedInvalid: "These cottages exceed the capacity or reach of your food buildings.",
			automatic: "Automatic allocation",
			masterTurns: "Master Builder",
			turns: "{{n}} turns",
			monumentHidden: "Secret monument",
			monument: "Monument",
			privateCard: "Only visible to you",
			yourSeat: "You",
			placed: "Placed",
			buildingNow: "Building",
			roundReady: "Round finished",
			watchPrompt: "Choose 3 distinct buildings",
			watchTrigger: "Your neighbor triggered the Watch; place its building",
			grovePrompt: "Place a regular building in an empty square",
			guildPrompt: "Choose a building to replace and its replacement",
			effectAt: "Choose an empty square for the building",
			endConfirm: "End this game and continue?",
			error: "This action is not available. Choose a legal target again.",
			master: "Master Builder",
			inspect: "View town",
			optMode: "Resource selection",
			masterMode: "Take turns naming",
			townHallMode: "Town Hall",
			optBuildings: "Building selection",
			firstBuildings: "Recommended first game",
			randomBuildings: "Random selection",
			optMonuments: "Monuments",
			monumentsOn: "Use monuments",
			monumentsOff: "No monuments",
			optCavern: "Cavern rule",
			cavernOn: "Allow 2 discards",
			cavernOff: "No cavern",
			hintName: "Name {{resource}}.",
			hintPlace: "Place {{resource}} in row {{row}}, column {{col}}.",
			hintBuild: "Construct {{name}} in row {{row}}, column {{col}}.",
			hintReady: "Finish this round.",
			hintMonument: "Choose {{name}}.",
			hintEffect: "Resolve the monument’s construction benefit.",
			hintFinish: "Complete your town and score it.",
			hintCavern: "Place this resource in your cavern.",
			hintFeed: "Allocate food to your cottages.",
			resourceCard: "Resource card",
			soloRank1: "Master Architect",
			soloRank2: "Town Planner",
			soloRank3: "Engineer",
			soloRank4: "Carpenter",
			soloRank5: "Builder’s Apprentice",
			soloRank6: "Aspiring Architect",
			hintCount: "{{n}} hints used",
			autopilot: "{{n}}% autopilot",
			on: "On",
			off: "Off",
			resources: {
				wood: "Wood",
				wheat: "Wheat",
				brick: "Brick",
				glass: "Glass",
				stone: "Stone"
			},
			groups: {
				cottage: "Cottages",
				food: "Food",
				civic: "Civic",
				faith: "Religious",
				tavern: "Taverns",
				trade: "Trade",
				industry: "Industry",
				monument: "Monument"
			},
			rules: "# Build your Tiny Town\nEach player has a 4×4 town. Arrange wood, wheat, brick, glass, and stone into the patterns on building cards, then replace the resources with buildings. Use Cottage and one card from each of six other building types. Random selection changes the available buildings. With monuments enabled, privately choose one of two cards; only its owner may build it, once, and reveal it when constructed.\n\n## Each round\nThe Master Builder names one resource. Every active player must first place it in an empty square, then may construct buildings. After all players finish, pass the hammer clockwise. Completed players leave future resource rounds. The final active player continues naming resources until their town is complete.\n\n## Construction and abilities\nPatterns may be rotated and mirrored. Resource types and relative positions must match exactly. Remove the full pattern, then place the building on one of the cleared squares. Resources cannot move freely, and buildings cannot be moved or removed without an ability. You may construct several buildings sequentially or save patterns for later. Shed, Trading Post, Warehouse, Factory, and monuments have the exceptions detailed on their cards. Resources and regular buildings are unlimited. Adjacent means orthogonal, except Granary explicitly covers all 8 surrounding squares.\n\nCottages may be built before food buildings. At scoring, each Farm feeds 4 cottages anywhere; Granary feeds the surrounding squares; Orchard feeds its row and column; Greenhouse feeds one connected cottage group. A cottage only needs feeding once. Food allocation can be changed in the town; automatic allocation chooses a highest-scoring legal allocation. Unfed cottages stay on the board but normally score no cottage points. Barrett Castle counts as 2 cottages for building scoring and uses two cottage units of food capacity. See each card for complete abilities and scoring.\n\n## Completing towns and winning\nWhen full, construct available patterns or complete your town. This implementation uses the following Bank edge-case ruling: if five Banks prohibit all resources, you may complete your town when naming a resource yourself or in a Town Hall choice round. Resources named by others or drawn from cards can still be placed normally. Once all towns are complete, remove remaining resources from town squares; keep stored Warehouse resources and score their penalties. Each square without a building scores −1. Fed cottages score 3 each, and other buildings and monuments score by their cards. Highest total wins. Break ties by fewer Master Builder turns, then fewer empty squares, then more cottages; otherwise share victory. The Starloom gives players completing in the same round the same finishing place.\n\n## Optional modes\nCavern: twice per game, discard a resource named by another player instead of placing it. These resources score neither points nor penalties. You cannot discard your own named resource. In Town Hall this applies to drawn-resource rounds, not free-choice rounds. Do not use Cavern in solo play.\n\nTown Hall: shuffle the 15 resource cards and discard 5 unseen. In each three-round cycle, draw a resource in the first two rounds; in the third, everyone chooses individually. When the deck runs out, reshuffle all 15 and discard 5 again. Factory, Warehouse, and Statue of the Bondmaker apply to drawn rounds. Banks restrict choice rounds. Fort Ironweed skips choice rounds unless its owner is the final active player.\n\nSolo: exclude Inn, Bank, Fort Ironweed, and Opaleye’s Watch. Shuffle 15 resource cards and reveal 3. Each round choose one to place. After finishing the round, put the selected card on the bottom of the deck and replace it with the top card. Factory, Warehouse, and Statue of the Bondmaker apply to the selected resource. Score 38+ for Master Architect, 32–37 Town Planner, 25–31 Engineer, 18–24 Carpenter, 10–17 Builder’s Apprentice, and 9 or less Aspiring Architect.",
			cards: {
				warehouse: {
					name: "Warehouse",
					effect: "Holds 3 resources. When another player names a resource, store it here or exchange it for a stored resource, placing that resource in an empty square. Each stored resource scores −1."
				},
				tradingPost: {
					name: "Trading Post",
					effect: "1 point. Acts as a wild resource in future layouts and remains in place. A build must use at least 1 real resource and cannot occupy the Trading Post."
				},
				factory: {
					name: "Factory",
					effect: "When constructed, select a resource. When another player names that resource, you may place a different resource instead."
				},
				bank: {
					name: "Bank",
					effect: "4 points. Assign a resource not assigned to another Bank in your town. You cannot name that resource as Master Builder."
				},
				well: {
					name: "Well",
					effect: "1 point for each adjacent cottage, fed or unfed."
				},
				shed: {
					name: "Shed",
					effect: "1 point. May be constructed on any empty square in your town, including a square just cleared by this build."
				},
				millstone: {
					name: "Millstone",
					effect: "2 points if adjacent to a food or trade building; at most 2 points."
				},
				fountain: {
					name: "Fountain",
					effect: "2 points if adjacent to another Fountain; at most 2 points."
				},
				theater: {
					name: "Theater",
					effect: "1 point per other unique building type in the same row and column. Do not count Theaters; count each type once."
				},
				tailor: {
					name: "Tailor",
					effect: "1 point, plus 1 point for each Tailor in the 4 center squares, to a maximum of 5 per Tailor."
				},
				market: {
					name: "Market",
					effect: "1 point per Market in its row or column, whichever is greater, including itself."
				},
				bakery: {
					name: "Bakery",
					effect: "3 points if adjacent to a food or industry building."
				},
				tavern: {
					name: "Tavern",
					effect: "1–5 Taverns score 2, 5, 9, 14, or 20 points total. More than 5 still score 20."
				},
				inn: {
					name: "Inn",
					effect: "3 points if no other Inn is in the same row or column. Excluded in solo play."
				},
				feastHall: {
					name: "Feast Hall",
					effect: "2 points each, or 3 each if you have more Feast Halls than the player to your right."
				},
				almshouse: {
					name: "Almshouse",
					effect: "1–6 Almshouses score −1, 5, −3, 15, −5, or 26 points total. More than 6 still score 26."
				},
				orchard: {
					name: "Orchard",
					effect: "Feeds all cottages in the same row and column."
				},
				greenhouse: {
					name: "Greenhouse",
					effect: "Feeds 1 contiguous group of orthogonally connected cottages anywhere in your town."
				},
				granary: {
					name: "Granary",
					effect: "Feeds all cottages in the 8 surrounding squares, including diagonals."
				},
				farm: {
					name: "Farm",
					effect: "Feeds up to 4 cottages anywhere in your town."
				},
				temple: {
					name: "Temple",
					effect: "4 points if adjacent to at least 2 fed cottages."
				},
				cloister: {
					name: "Cloister",
					effect: "1 point for each Cloister in a corner of your town, scored by every Cloister."
				},
				chapel: {
					name: "Chapel",
					effect: "1 point for every fed cottage in your town."
				},
				abbey: {
					name: "Abbey",
					effect: "3 points if not adjacent to a cottage, trade building, or industry building."
				},
				cottage: {
					name: "Cottage",
					effect: "3 points if fed, otherwise 0. Unfed cottages remain in your town."
				},
				silvaForum: {
					name: "Silva Forum",
					effect: "1 point, plus 1 per building in your largest orthogonally connected group of one building type."
				},
				elderTree: {
					name: "Shrine of the Elder Tree",
					effect: "Locks in 1, 2, 3, 4, 5, or 8 points when built as your 1st–6th building. Later builds still score 8; include this monument."
				},
				opaleye: {
					name: "Opaleye’s Watch",
					effect: "Choose 3 distinct regular building types when built. When either neighboring player builds one, place its building in any empty square of your town; each choice triggers once."
				},
				obelisk: {
					name: "Obelisk of the Crescent",
					effect: "All future buildings may be placed on any empty square in your town."
				},
				mandrasPalace: {
					name: "Mandras Palace",
					effect: "2 points for each unique adjacent building type."
				},
				groveUniversity: {
					name: "Grove University",
					effect: "3 points. When constructed, immediately place a regular building on any empty square."
				},
				mausoleum: {
					name: "Grand Mausoleum of the Rodina",
					effect: "Your unfed cottages are worth 3 points each."
				},
				fortIronweed: {
					name: "Fort Ironweed",
					effect: "7 points. You no longer act as Master Builder unless you are the last active player. Also skip Town Hall choice rounds unless you are alone."
				},
				cathedralCaterina: {
					name: "Cathedral of Caterina",
					effect: "2 points. Empty squares in your town score 0 instead of −1."
				},
				barrettCastle: {
					name: "Barrett Castle",
					effect: "5 points if fed. Counts as 2 cottages rather than a monument for all building scoring."
				},
				archive: {
					name: "Archive of the Second Age",
					effect: "1 point for each unique building type in your town other than monument."
				},
				architectGuild: {
					name: "Architect’s Guild",
					effect: "1 point. Immediately replace up to 2 regular buildings with other regular building types. Neither may be a monument; unused replacements cannot be saved."
				},
				starloom: {
					name: "The Starloom",
					effect: "Scores 6, 3, 2, or 0 points for finishing 1st, 2nd, 3rd, or later. Players finishing in the same round share that placing."
				},
				skyBaths: {
					name: "The Sky Baths",
					effect: "2 points for each building type missing from your town, including regular types and monument."
				},
				bondmaker: {
					name: "Statue of the Bondmaker",
					effect: "When another player names a resource, you may place it on a cottage. Each cottage holds 1 resource, which cannot be used in a building layout."
				}
			}
		}
	}
};
//#endregion
export { at as default };
