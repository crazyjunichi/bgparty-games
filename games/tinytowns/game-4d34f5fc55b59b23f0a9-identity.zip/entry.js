import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { AVATARS as n } from "@bgparty/sdk/avatars";
import { useEffect as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconBack as c, IconDown as l, IconInfo as u } from "@bgparty/sdk/icons";
import { useFxAnchor as d } from "@bgparty/sdk/fx/anchors";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as p } from "@bgparty/sdk/assets";
import { Fragment as te, jsx as m, jsxs as h } from "react/jsx-runtime";
import { FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as ne, OptionSection as v, OptionSwitch as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/tinytowns/data.ts
var b = [
	"wood",
	"wheat",
	"brick",
	"glass",
	"stone"
], re = [
	"cottage",
	"food",
	"civic",
	"faith",
	"tavern",
	"trade",
	"industry",
	"monument"
], ie = {
	w: "wood",
	h: "wheat",
	b: "brick",
	g: "glass",
	s: "stone"
};
function x(e) {
	return e.flatMap((e, t) => [...e].flatMap((e, n) => ie[e] ? [[
		n,
		t,
		ie[e]
	]] : []));
}
function S(e, t, n, ...r) {
	return {
		id: e,
		group: t,
		art: n,
		pattern: x(r)
	};
}
var C = [
	S("warehouse", "industry", 0, "hwh", "b.b"),
	S("tradingPost", "industry", 1, "sw.", "swb"),
	S("factory", "industry", 2, "w...", "bssb"),
	S("bank", "industry", 3, "hh.", "wgb"),
	S("well", "civic", 4, "ws"),
	S("shed", "civic", 5, "ws"),
	S("millstone", "civic", 6, "ws"),
	S("fountain", "civic", 7, "ws"),
	S("theater", "trade", 8, ".s.", "wgw"),
	S("tailor", "trade", 9, ".h.", "sgs"),
	S("market", "trade", 10, ".w.", "sgs"),
	S("bakery", "trade", 11, ".h.", "bgb"),
	S("tavern", "tavern", 12, "bbg"),
	S("inn", "tavern", 13, "hsg"),
	S("feastHall", "tavern", 14, "wwg"),
	S("almshouse", "tavern", 15, "ssg"),
	S("orchard", "food", 16, "sh", "hw"),
	S("greenhouse", "food", 17, "hg", "ww"),
	S("granary", "food", 18, "hh", "wb"),
	S("farm", "food", 19, "hh", "ww"),
	S("temple", "faith", 20, "..g", "bbs"),
	S("cloister", "faith", 21, "..g", "wbs"),
	S("chapel", "faith", 22, "..g", "sgs"),
	S("abbey", "faith", 23, "...g", "bsss"),
	S("cottage", "cottage", 24, ".h", "bg"),
	S("silvaForum", "monument", 25, "..h.", "bbsw"),
	S("elderTree", "monument", 26, "bhs", "wgw"),
	S("opaleye", "monument", 27, "w...", "bghh", "s..."),
	S("obelisk", "monument", 28, "h..", "bgb"),
	S("mandrasPalace", "monument", 29, "hg", "bw"),
	S("groveUniversity", "monument", 30, ".b.", "sgs"),
	S("mausoleum", "monument", 31, "ww", "bs"),
	S("fortIronweed", "monument", 32, "h.b", "sws"),
	S("cathedralCaterina", "monument", 33, ".h", "sg"),
	S("barrettCastle", "monument", 34, "h..s", "wggb"),
	S("archive", "monument", 35, "hh", "bg"),
	S("architectGuild", "monument", 36, "..g", ".hs", "wb."),
	S("starloom", "monument", 37, "gg", "wh"),
	S("skyBaths", "monument", 38, ".h.", "sgw", "b.b"),
	S("bondmaker", "monument", 39, "wssg", "h...")
], w = Object.fromEntries(C.map((e) => [e.id, e])), ae = [
	"cottage",
	"farm",
	"well",
	"chapel",
	"tavern",
	"bakery",
	"warehouse"
], oe = C.filter((e) => e.group === "monument").map((e) => e.id), se = {
	wood: "#634331",
	wheat: "#f3ab25",
	brick: "#e54636",
	glass: "#269ca6",
	stone: "#b3aa90"
}, T = t.enum(b), E = t.int().min(0).max(15), D = t.object({
	mode: t.enum(["master", "townHall"]).default("master"),
	buildings: t.enum(["first", "random"]).default("first"),
	monuments: t.boolean().default(!0),
	cavern: t.boolean().default(!1)
}).default({
	mode: "master",
	buildings: "first",
	monuments: !0,
	cavern: !1
}), ce = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("monument"),
		id: t.string()
	}),
	t.object({
		type: t.literal("name"),
		resource: T
	}),
	t.object({
		type: t.literal("place"),
		at: E,
		resource: T,
		offer: t.int().min(0).max(2).optional(),
		warehouse: E.optional(),
		swap: t.int().min(0).max(2).optional(),
		bondmaker: t.boolean().optional()
	}),
	t.object({
		type: t.literal("cavern"),
		offer: t.int().min(0).max(2).optional()
	}),
	t.object({
		type: t.literal("build"),
		id: t.string(),
		cells: t.array(E).min(2).max(8),
		at: E,
		resource: T.optional()
	}),
	t.object({
		type: t.literal("effect"),
		id: t.string().optional(),
		at: E.optional(),
		source: E.optional(),
		resource: T.optional(),
		choices: t.array(t.string()).max(3).optional(),
		skip: t.boolean().optional()
	}),
	t.object({
		type: t.literal("feed"),
		cells: t.array(E).max(16)
	}),
	t.object({ type: t.literal("ready") }),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), O = t.object({
	resource: T.nullable(),
	building: t.string().nullable(),
	stored: t.array(T).max(3),
	marker: T.nullable()
}), le = t.object({
	kind: t.enum([
		"grove",
		"guild",
		"watch",
		"watchTrigger",
		"obelisk"
	]),
	remaining: t.int(),
	choices: t.array(t.string()),
	used: t.array(E),
	source: t.string().nullable()
}), ue = t.object({
	cottage: t.number(),
	food: t.number(),
	civic: t.number(),
	faith: t.number(),
	tavern: t.number(),
	trade: t.number(),
	industry: t.number(),
	monument: t.number(),
	empty: t.number(),
	total: t.number(),
	fed: t.array(E),
	emptyCount: t.int(),
	cottages: t.int()
}), k = t.object({
	rid: t.string(),
	cells: t.array(O).length(16),
	monument: t.string().nullable(),
	monumentBuilt: t.boolean(),
	placed: t.boolean(),
	ready: t.boolean(),
	completed: t.int().nullable(),
	masterTurns: t.int(),
	cavernUsed: t.int(),
	effect: le.nullable(),
	watched: t.array(t.string()),
	shrineValue: t.int(),
	starloomValue: t.int(),
	fed: t.array(E),
	score: ue
}), de = t.object({
	players: t.array(t.string()),
	towns: t.array(k),
	cards: t.array(t.string()),
	phase: t.enum([
		"monument",
		"name",
		"play",
		"done"
	]),
	round: t.int(),
	master: t.string(),
	resource: T.nullable(),
	mode: t.enum([
		"master",
		"townHall",
		"solo"
	]),
	offers: t.array(T),
	config: D,
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		id: t.string().optional(),
		at: E.optional(),
		resource: T.optional()
	}))
}), A = t.object({
	monument: t.string().nullable(),
	options: t.array(t.string()),
	effect: le.nullable()
}), j = () => ({
	resource: null,
	building: null,
	stored: [],
	marker: null
}), fe = (e) => [
	e % 4 ? e - 1 : -1,
	e % 4 < 3 ? e + 1 : -1,
	e >= 4 ? e - 4 : -1,
	e < 12 ? e + 4 : -1
].filter((e) => e >= 0), M = (e) => !e.building && !e.resource, N = (e) => e.building === "barrettCastle" ? "cottage" : e.building ? w[e.building].group : null, P = (e) => e.building === "barrettCastle" ? 2 : +(N(e) === "cottage"), pe = /* @__PURE__ */ new Map();
function F(e) {
	let t = pe.get(e);
	if (t) return t;
	let n = [], r = /* @__PURE__ */ new Set();
	for (let t = 0; t < 2; t++) for (let i = 0; i < 4; i++) {
		let a = e.map(([e, n, r]) => [
			t ? -e : e,
			n,
			r
		]);
		for (let e = 0; e < i; e++) a = a.map(([e, t, n]) => [
			-t,
			e,
			n
		]);
		let o = Math.min(...a.map((e) => e[0])), s = Math.min(...a.map((e) => e[1]));
		a = a.map(([e, t, n]) => [
			e - o,
			t - s,
			n
		]).sort((e, t) => e[1] - t[1] || e[0] - t[0]);
		let c = JSON.stringify(a);
		r.has(c) || (r.add(c), n.push(a));
	}
	return pe.set(e, n), n;
}
function me(e, t) {
	let n = w[t];
	if (!n) return [];
	let r = [], i = /* @__PURE__ */ new Set();
	for (let t of F(n.pattern)) {
		let n = Math.max(...t.map((e) => e[0])) + 1, a = Math.max(...t.map((e) => e[1])) + 1;
		for (let o = 0; o <= 4 - a; o++) for (let a = 0; a <= 4 - n; a++) {
			let n = t.map(([e, t]) => (o + t) * 4 + a + e);
			if (!n.every((n, r) => e[n].resource === t[r][2] || e[n].building === "tradingPost")) continue;
			let s = n.filter((t) => e[t].resource !== null && !e[t].building);
			if (!s.length) continue;
			let c = [...n].sort((e, t) => e - t).join(",");
			i.has(c) || (i.add(c), r.push({
				cells: n,
				removed: s,
				pattern: t
			}));
		}
	}
	return r;
}
var he = (e, t) => e.length === t.length && new Set(e).size === e.length && e.every((e) => t.includes(e)), ge = (e, t, n, r) => t === "shed" || r ? e.flatMap((e, t) => M(e) || n.removed.includes(t) ? [t] : []) : n.removed;
function _e(e) {
	let t = e.flatMap((e, t) => P(e) ? [t] : []), n = e.filter((e) => e.building === "greenhouse").length, r = e.filter((e) => e.building === "farm").length * 4, i = /* @__PURE__ */ new Set();
	for (let n = 0; n < 16; n++) e[n].building === "granary" && t.filter((e) => Math.abs(n % 4 - e % 4) <= 1 && Math.abs((n >> 2) - (e >> 2)) <= 1).forEach((e) => i.add(e)), e[n].building === "orchard" && t.filter((e) => n % 4 == e % 4 || n >> 2 == e >> 2).forEach((e) => i.add(e));
	let a = [], o = new Set(t);
	for (; o.size;) {
		let e = o.values().next().value;
		o.delete(e);
		let t = [e];
		for (let e = 0; e < t.length; e++) for (let n of fe(t[e])) o.has(n) && (o.delete(n), t.push(n));
		a.push(t);
	}
	return {
		cottages: t,
		greens: n,
		farms: r,
		fixed: i,
		groups: a
	};
}
function ve(e, t) {
	if (new Set(t).size !== t.length || t.some((t) => !P(e[t]))) return !1;
	let n = _e(e), r = new Set(t);
	return n.groups.map((t) => t.reduce((t, i) => t + (r.has(i) && !n.fixed.has(i) ? P(e[i]) : 0), 0)).sort((e, t) => t - e).slice(n.greens).reduce((e, t) => e + t, 0) <= n.farms;
}
function I(e, t) {
	let n = new Set(t), r = t.reduce((t, n) => t + P(e[n]), 0), i = e.some((e) => e.building === "mausoleum");
	return t.reduce((t, n) => t + (e[n].building === "barrettCastle" ? 5 : i ? 0 : 3), 0) + e.filter((e) => e.building === "chapel").length * r + e.reduce((t, r, i) => t + (r.building === "temple" && fe(i).reduce((t, r) => t + (n.has(r) ? P(e[r]) : 0), 0) >= 2 ? 4 : 0), 0);
}
function L(e) {
	let t = _e(e);
	if (!t.farms && !t.greens) return t.cottages.filter((e) => t.fixed.has(e));
	if (ve(e, t.cottages)) return t.cottages;
	let n = [], r = -Infinity;
	for (let i = 0; i < 2 ** t.cottages.length; i++) {
		let a = t.cottages.filter((e, t) => i & 1 << t);
		if (!ve(e, a)) continue;
		let o = I(e, a);
		o > r && (r = o, n = a);
	}
	return n;
}
function R(e, t) {
	let n = e.cells, r = e.fed !== null && ve(n, e.fed) ? e.fed : L(n), i = new Set(r), a = (e) => n.filter((t) => t.building === e).length, o = r.reduce((e, t) => e + P(n[t]), 0), s = (e) => a(e) > 0, c = {
		cottage: 0,
		food: 0,
		civic: 0,
		faith: 0,
		tavern: 0,
		trade: 0,
		industry: 0,
		monument: 0,
		empty: 0,
		total: 0,
		fed: r,
		emptyCount: n.filter((e) => !e.building).length,
		cottages: ((e) => n.reduce((t, n) => t + (N(n) === e ? e === "cottage" ? P(n) : 1 : 0), 0))("cottage")
	};
	for (let r = 0; r < 16; r++) {
		let l = n[r], u = l.building;
		if (!u) continue;
		let d = fe(r), f = (e) => d.filter((t) => N(n[t]) === e), ee = (e) => r !== e && (r % 4 == e % 4 || r >> 2 == e >> 2), p = 0;
		switch (u) {
			case "cottage":
				p = i.has(r) || s("mausoleum") ? 3 : 0;
				break;
			case "barrettCastle":
				p = i.has(r) ? 5 : 0;
				break;
			case "well":
				p = d.reduce((e, t) => e + P(n[t]), 0);
				break;
			case "shed":
				p = 1;
				break;
			case "millstone":
				p = f("food").length || f("trade").length ? 2 : 0;
				break;
			case "fountain":
				p = d.some((e) => n[e].building === "fountain") ? 2 : 0;
				break;
			case "abbey":
				p = d.some((e) => [
					"cottage",
					"industry",
					"trade"
				].includes(N(n[e]) ?? "")) ? 0 : 3;
				break;
			case "chapel":
				p = o;
				break;
			case "cloister":
				p = [
					0,
					3,
					12,
					15
				].filter((e) => n[e].building === "cloister").length;
				break;
			case "temple":
				p = d.reduce((e, t) => e + (i.has(t) ? P(n[t]) : 0), 0) >= 2 ? 4 : 0;
				break;
			case "feastHall":
				p = 2 + +(a("feastHall") > (t?.cells.filter((e) => e.building === "feastHall").length ?? a("feastHall")));
				break;
			case "inn":
				p = n.some((e, t) => e.building === "inn" && ee(t)) ? 0 : 3;
				break;
			case "bakery":
				p = f("food").length || f("industry").length ? 3 : 0;
				break;
			case "market":
				p = Math.max(n.filter((e, t) => e.building === "market" && t % 4 == r % 4).length, n.filter((e, t) => e.building === "market" && t >> 2 == r >> 2).length);
				break;
			case "tailor":
				p = 1 + [
					5,
					6,
					9,
					10
				].filter((e) => n[e].building === "tailor").length;
				break;
			case "theater":
				p = new Set(n.flatMap((e, t) => ee(t) && N(e) && N(e) !== "trade" ? [N(e)] : [])).size;
				break;
			case "bank":
				p = 4;
				break;
			case "tradingPost":
				p = 1;
				break;
			case "warehouse":
				p = -l.stored.length;
				break;
			case "silvaForum": {
				let e = 0, t = /* @__PURE__ */ new Set();
				for (let r = 0; r < 16; r++) {
					if (!n[r].building || t.has(r)) continue;
					let i = N(n[r]), a = [r];
					t.add(r);
					for (let e = 0; e < a.length; e++) for (let r of fe(a[e])) N(n[r]) === i && !t.has(r) && (t.add(r), a.push(r));
					e = Math.max(e, a.reduce((e, t) => e + (N(n[t]) === "cottage" ? P(n[t]) : 1), 0));
				}
				p = 1 + e;
				break;
			}
			case "elderTree":
				p = e.shrineValue;
				break;
			case "mandrasPalace":
				p = 2 * new Set(d.flatMap((e) => N(n[e]) ? [N(n[e])] : [])).size;
				break;
			case "groveUniversity":
				p = 3;
				break;
			case "fortIronweed":
				p = 7;
				break;
			case "cathedralCaterina":
				p = 2;
				break;
			case "archive":
				p = new Set(n.flatMap((e) => N(e) && N(e) !== "monument" ? [N(e)] : [])).size;
				break;
			case "architectGuild":
				p = 1;
				break;
			case "starloom":
				p = e.starloomValue;
				break;
			case "skyBaths": p = 2 * re.filter((e) => !n.some((t) => N(t) === e)).length;
		}
		c[N(l) ?? "monument"] += p;
	}
	return c.tavern += ([
		0,
		2,
		5,
		9,
		14,
		20
	][Math.min(5, a("tavern"))] ?? 0) + ([
		0,
		-1,
		5,
		-3,
		15,
		-5,
		26
	][Math.min(6, a("almshouse"))] ?? 0), c.empty = s("cathedralCaterina") ? 0 : -c.emptyCount, c.total = re.reduce((e, t) => e + c[t], c.empty), c;
}
var z = (e) => b.filter((t) => !e.some((e) => e.building === "bank" && e.marker === t)), B = {
	id: "tinytowns",
	tier: "alpha",
	mechanics: ["tile-placement", "set-collection"],
	interactionTags: [],
	nameKey: "games.tinytowns.name",
	descKey: "games.tinytowns.desc",
	rulesKey: "games.tinytowns.rules",
	icon: "🏘️",
	iconImg: "games/tinytowns.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1823399538538672090/A62373A1C42BB89D0CB8AD9CA4AA6167FCF8321E/" },
	minPlayers: 1,
	maxPlayers: 6,
	bestPlayers: [3, 4],
	accent: "#986035",
	releasedAt: "2026-10-31T14:13:00+08:00",
	search: {
		py: "xiao xiao cheng zhen tiny towns",
		init: "xxcz"
	},
	hotseat: "cover",
	botDelayMs: 320
}, V = {
	place: 280,
	build: 400,
	reveal: 360
}, H = () => ({ code: "games.tinytowns.error" });
function ye(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var U = () => b.flatMap((e) => [
	e,
	e,
	e
]), W = (e) => e.players.filter((t) => e.towns[t].completed === null), G = (e) => !e.cells.some(M), K = (e, t) => e.cells.some((e) => e.building === t), q = (e, t) => e.mode === "solo" || e.mode === "townHall" ? e.mode === "solo" || e.round % 3 != 0 : e.master !== t;
function be(e, t) {
	let n = e.towns[t];
	return !n || n.completed !== null || n.ready || e.phase === "done" || e.phase === "monument" ? !1 : G(n) ? !0 : (e.phase === "name" && e.master === t || e.phase === "play" && e.mode === "townHall" && e.resource === null && !n.placed) && z(n.cells).length === 0;
}
function xe(e, t = !1) {
	t || e.round++;
	for (let t of W(e)) e.towns[t].placed = !1, e.towns[t].ready = !1;
	if (e.resource = null, e.mode === "master") {
		let n = W(e), r = e.players.indexOf(e.master);
		t || (r = (r + 1) % e.players.length);
		for (let t = 0; t < e.players.length; t++) {
			let i = e.players[(r + t) % e.players.length];
			if (n.includes(i) && (n.length === 1 || !K(e.towns[i], "fortIronweed"))) {
				e.master = i;
				break;
			}
		}
		e.phase = "name";
	} else if (e.phase = "play", e.mode === "solo") {
		if (e.selectedOffer !== null) {
			let t = e.offers[e.selectedOffer];
			e.deck.push(t), e.offers[e.selectedOffer] = e.deck.shift(), e.selectedOffer = null;
		}
	} else if (e.round % 3 != 0) e.deck.length || (e.deck = ye(e, U()).slice(5)), e.resource = e.deck.shift();
	else {
		let t = W(e);
		for (let n of t) t.length > 1 && K(e.towns[n], "fortIronweed") && (e.towns[n].placed = !0);
	}
}
function Se(t, n, r) {
	let i = D.safeParse(t), a = i.success ? i.data : D.parse(void 0), o = {
		players: [...n],
		towns: {},
		cards: [],
		config: a,
		phase: a.monuments ? "monument" : "name",
		round: 1,
		master: n[0],
		resource: null,
		mode: n.length === 1 ? "solo" : a.mode,
		seed: r,
		cursor: 0,
		deck: [],
		offers: [],
		selectedOffer: null,
		log: []
	};
	o.cards = a.buildings === "first" ? [...ae] : ["cottage", ...[
		"food",
		"civic",
		"faith",
		"tavern",
		"trade",
		"industry"
	].map((t) => {
		let i = C.filter((e) => e.group === t && (n.length > 1 || !["inn", "bank"].includes(e.id)));
		return i[e(r, o.cursor++, i.length)].id;
	})];
	let s = oe.filter((e) => n.length > 1 || !["opaleye", "fortIronweed"].includes(e));
	s = ye(o, s);
	for (let e of n) o.towns[e] = {
		rid: e,
		cells: Array.from({ length: 16 }, j),
		monument: null,
		options: a.monuments ? s.splice(0, 2) : [],
		monumentBuilt: !1,
		placed: !1,
		ready: !1,
		completed: null,
		masterTurns: 0,
		cavernUsed: 0,
		effects: [],
		watched: [],
		shrineValue: 0,
		starloomValue: 0,
		fed: null
	};
	return o.mode === "solo" && (o.deck = ye(o, U()), o.offers = o.deck.splice(0, 3)), o.mode === "townHall" && (o.deck = ye(o, U()).slice(5)), a.monuments || xe(o, !0), {
		state: o,
		fx: []
	};
}
function J(e, t) {
	t.completed = e.round, t.ready = !0, t.starloomValue = [
		0,
		6,
		3,
		2
	][1 + e.players.filter((t) => e.towns[t].completed !== null && e.towns[t].completed < e.round).length] ?? 0, e.log.push({
		rid: t.rid,
		kind: "finish"
	});
}
function Y(e) {
	if (e.players.every((t) => e.towns[t].completed !== null)) {
		e.phase = "done";
		for (let t of e.players) for (let n of e.towns[t].cells) n.resource = null;
	} else W(e).every((t) => e.towns[t].ready && e.towns[t].effects.length === 0) && xe(e);
}
function Ce(e, t, n) {
	return t !== "bank" && t !== "factory" || !!n && (t !== "bank" || !e.cells.some((e) => e.building === "bank" && e.marker === n));
}
function we(e, t, n) {
	if (n === "elderTree") {
		let e = t.cells.filter((e) => e.building).length;
		t.shrineValue = [
			0,
			1,
			2,
			3,
			4,
			5,
			8
		][Math.min(6, e)];
	}
	n === "groveUniversity" && t.effects.push({
		kind: "grove",
		remaining: 1,
		choices: [],
		used: [],
		source: null
	}), n === "architectGuild" && t.effects.push({
		kind: "guild",
		remaining: 2,
		choices: [],
		used: [],
		source: null
	}), n === "opaleye" && t.effects.push({
		kind: "watch",
		remaining: 3,
		choices: [],
		used: [],
		source: null
	});
	let r = e.players.indexOf(t.rid), i = /* @__PURE__ */ new Set([e.players[(r + 1) % e.players.length], e.players[(r + e.players.length - 1) % e.players.length]]);
	for (let r of i) {
		let i = e.towns[r];
		r !== t.rid && i.completed === null && i.watched.includes(n) && (i.watched = i.watched.filter((e) => e !== n), i.effects.push({
			kind: "watchTrigger",
			remaining: 1,
			choices: [n],
			used: [],
			source: t.rid
		}), i.ready = !1);
	}
}
function Te(e, t, n, r, i, a, o = []) {
	t.cells[r] = {
		...j(),
		building: n,
		marker: i ?? null
	}, t.fed = null, w[n].group === "monument" && (t.monumentBuilt = !0), e.log.push({
		rid: t.rid,
		kind: "build",
		id: n,
		at: r
	}), a.push({
		kind: "build",
		rid: t.rid,
		data: {
			id: n,
			at: r,
			consumed: o
		}
	}), we(e, t, n);
}
function Ee(e, t, n) {
	let r = e.resource;
	if (e.mode === "solo") {
		if (n.offer === void 0 || !e.offers[n.offer]) return !1;
		r = e.offers[n.offer];
	}
	return r === null ? z(t.cells).includes(n.resource) : n.resource === r || q(e, t.rid) && t.cells.some((e) => e.building === "factory" && e.marker === r);
}
function De(e, t) {
	let n = e.towns[t];
	if (e.phase !== "play" || !n || n.placed || n.ready || n.completed !== null) return [];
	let r = [];
	for (let i of b) for (let a of e.mode === "solo" ? [
		0,
		1,
		2
	] : [void 0]) {
		let o = {
			type: "place",
			resource: i,
			at: 0,
			...a === void 0 ? {} : { offer: a }
		};
		if (Ee(e, n, o)) {
			for (let i = 0; i < 16; i++) M(n.cells[i]) && r.push({
				...o,
				at: i
			}), q(e, t) && K(n, "bondmaker") && n.cells[i].building === "cottage" && !n.cells[i].stored.length && r.push({
				...o,
				at: i,
				bondmaker: !0
			});
			if (q(e, t)) for (let e = 0; e < 16; e++) {
				let t = n.cells[e];
				if (t.building === "warehouse") {
					t.stored.length < 3 && r.push({
						...o,
						at: e,
						warehouse: e
					});
					for (let i = 0; i < t.stored.length; i++) for (let t = 0; t < 16; t++) M(n.cells[t]) && r.push({
						...o,
						at: t,
						warehouse: e,
						swap: i
					});
				}
			}
		}
	}
	return r;
}
function Oe(e, t, n) {
	if (t.type === "tick") return {
		state: e,
		fx: []
	};
	if (!e.towns[n.by] || e.phase === "done") return H();
	let r = structuredClone(e), i = r.towns[n.by], a = [];
	if (t.type === "monument") return r.phase !== "monument" || i.monument || !i.options.includes(t.id) ? H() : (i.monument = t.id, i.options = [], r.players.every((e) => r.towns[e].monument) && xe(r, !0), {
		state: r,
		fx: a
	});
	if (t.type === "name") return r.phase !== "name" || r.master !== n.by || !z(i.cells).includes(t.resource) ? H() : (r.resource = t.resource, r.phase = "play", i.masterTurns++, r.log.push({
		rid: n.by,
		kind: "name",
		resource: t.resource
	}), {
		state: r,
		fx: [{
			kind: "name",
			rid: n.by,
			data: { resource: t.resource }
		}]
	});
	if (t.type === "feed") return r.phase !== "play" || i.completed !== null || i.ready || !i.placed || i.effects.length || !ve(i.cells, t.cells) ? H() : (i.fed = t.cells, {
		state: r,
		fx: a
	});
	if (t.type === "finish") return be(r, n.by) ? (i.effects = [], J(r, i), Y(r), r.phase === "name" && r.master === n.by && i.completed !== null && xe(r, !0), {
		state: r,
		fx: [{
			kind: "finish",
			rid: n.by
		}]
	}) : H();
	if (r.phase !== "play" || i.completed !== null || i.ready) return H();
	if (t.type === "effect") {
		let e = i.effects[0];
		if (!e || !i.placed) return H();
		if (t.skip) return e.kind === "watch" ? H() : (i.effects.shift(), Y(r), {
			state: r,
			fx: a
		});
		if (e.kind === "watch") {
			let e = t.choices;
			return !e || e.length !== 3 || new Set(e).size !== 3 || e.some((e) => !r.cards.includes(e)) ? H() : (i.watched = [...e], i.effects.shift(), {
				state: r,
				fx: a
			});
		}
		let n = t.id, o = t.at;
		if (!n || o === void 0 || !r.cards.includes(n) || !Ce(i, n, t.resource) || e.kind === "watchTrigger" && !e.choices.includes(n)) return H();
		if (e.kind === "guild") {
			let r = t.source;
			if (r === void 0 || e.used.includes(r) || !i.cells[r].building || w[i.cells[r].building].group === "monument" || i.cells[r].building === n) return H();
			if (n === "shed") {
				if (o !== r && !M(i.cells[o])) return H();
			} else if (o !== r) return H();
			i.cells[r] = j(), e.used.push(r);
		} else if (!M(i.cells[o])) return H();
		return e.remaining--, e.remaining <= 0 && i.effects.shift(), Te(r, i, n, o, t.resource, a), {
			state: r,
			fx: a
		};
	}
	if (i.effects.length && t.type !== "place" && t.type !== "cavern") return H();
	if (t.type === "place") {
		if (i.placed || !Ee(r, i, t)) return H();
		let e = i.cells[t.at];
		if (t.warehouse !== void 0) {
			let o = i.cells[t.warehouse];
			if (!q(r, n.by) || o.building !== "warehouse" || t.bondmaker) return H();
			if (t.swap !== void 0) {
				if (!M(e) || t.swap >= o.stored.length) return H();
				let r = o.stored[t.swap];
				o.stored[t.swap] = t.resource, e.resource = r, a.push({
					kind: "place",
					rid: n.by,
					data: {
						resource: r,
						at: t.at,
						from: t.warehouse,
						fromStored: t.swap
					}
				});
			} else {
				if (o.stored.length >= 3 || t.at !== t.warehouse) return H();
				o.stored.push(t.resource);
			}
		} else if (t.bondmaker) {
			if (!q(r, n.by) || !K(i, "bondmaker") || e.building !== "cottage" || e.stored.length) return H();
			e.stored.push(t.resource);
		} else {
			if (!M(e)) return H();
			e.resource = t.resource;
		}
		return i.placed = !0, r.mode === "solo" && (r.selectedOffer = t.offer), r.log.push({
			rid: n.by,
			kind: "place",
			at: t.at,
			resource: t.resource
		}), a.unshift({
			kind: "place",
			rid: n.by,
			data: {
				resource: t.resource,
				at: t.warehouse ?? t.at,
				...t.warehouse === void 0 ? t.bondmaker ? { stored: 0 } : {} : { stored: t.swap ?? i.cells[t.warehouse].stored.length - 1 },
				...t.offer === void 0 ? {} : { offer: t.offer }
			}
		}), a.length > 1 && (a[1].with = !0), {
			state: r,
			fx: a
		};
	}
	if (t.type === "cavern") return i.placed || !r.config.cavern || r.mode === "solo" || !q(r, n.by) || i.cavernUsed >= 2 ? H() : (i.cavernUsed++, i.placed = !0, r.log.push({
		rid: n.by,
		kind: "cavern"
	}), {
		state: r,
		fx: [{
			kind: "cavern",
			rid: n.by,
			data: { resource: r.resource }
		}]
	});
	if (t.type === "build") {
		if (!i.placed || !r.cards.includes(t.id) && (i.monument !== t.id || i.monumentBuilt) || !Ce(i, t.id, t.resource)) return H();
		let e = me(i.cells, t.id).find((e) => he(e.cells, t.cells));
		if (!e || !ge(i.cells, t.id, e, K(i, "obelisk")).includes(t.at)) return H();
		let n = e.removed.map((e) => ({
			at: e,
			resource: i.cells[e].resource
		}));
		for (let t of e.removed) i.cells[t] = j();
		return Te(r, i, t.id, t.at, t.resource, a, n), {
			state: r,
			fx: a
		};
	}
	return t.type === "ready" && i.placed ? (G(i) ? (J(r, i), a.push({
		kind: "finish",
		rid: n.by
	})) : i.ready = !0, Y(r), {
		state: r,
		fx: a
	}) : H();
}
function ke(e, t) {
	let n = e.towns[t];
	return {
		public: {
			players: e.players,
			cards: e.cards,
			phase: e.phase,
			round: e.round,
			master: e.master,
			resource: e.resource,
			mode: e.mode,
			offers: e.offers,
			config: e.config,
			log: e.log,
			towns: e.players.map((t, n) => {
				let r = e.towns[t], i = R(r, e.towns[e.players[(n + e.players.length - 1) % e.players.length]]);
				return {
					rid: t,
					cells: r.cells,
					monument: r.monumentBuilt || e.phase === "done" ? r.monument : null,
					monumentBuilt: r.monumentBuilt,
					placed: r.placed,
					ready: r.ready,
					completed: r.completed,
					masterTurns: r.masterTurns,
					cavernUsed: r.cavernUsed,
					effect: r.effects[0] ?? null,
					watched: r.watched,
					shrineValue: r.shrineValue,
					starloomValue: r.starloomValue,
					fed: i.fed,
					score: i
				};
			})
		},
		private: {
			monument: n?.monument ?? null,
			options: n?.options ?? [],
			effect: n?.effects[0] ?? null
		}
	};
}
function X(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t, n) => [t, R(e.towns[t], e.towns[e.players[(n + e.players.length - 1) % e.players.length]])])), n = (n, r) => t[r].total - t[n].total || e.towns[n].masterTurns - e.towns[r].masterTurns || t[n].emptyCount - t[r].emptyCount || t[r].cottages - t[n].cottages, r = [...e.players].sort(n);
	return {
		phase: "done",
		ranking: r,
		winner: r.filter((e) => n(e, r[0]) === 0),
		scores: Object.fromEntries(e.players.map((e) => [e, t[e].total]))
	};
}
var Ae = {
	meta: B,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ce,
		publicView: de,
		privateView: A,
		config: D
	},
	setup: Se,
	reduce: Oe,
	viewFor: ke,
	status: X
}, je = {
	warehouse: {
		name: "games.tinytowns.cards.warehouse.name",
		effect: "games.tinytowns.cards.warehouse.effect"
	},
	tradingPost: {
		name: "games.tinytowns.cards.tradingPost.name",
		effect: "games.tinytowns.cards.tradingPost.effect"
	},
	factory: {
		name: "games.tinytowns.cards.factory.name",
		effect: "games.tinytowns.cards.factory.effect"
	},
	bank: {
		name: "games.tinytowns.cards.bank.name",
		effect: "games.tinytowns.cards.bank.effect"
	},
	well: {
		name: "games.tinytowns.cards.well.name",
		effect: "games.tinytowns.cards.well.effect"
	},
	shed: {
		name: "games.tinytowns.cards.shed.name",
		effect: "games.tinytowns.cards.shed.effect"
	},
	millstone: {
		name: "games.tinytowns.cards.millstone.name",
		effect: "games.tinytowns.cards.millstone.effect"
	},
	fountain: {
		name: "games.tinytowns.cards.fountain.name",
		effect: "games.tinytowns.cards.fountain.effect"
	},
	theater: {
		name: "games.tinytowns.cards.theater.name",
		effect: "games.tinytowns.cards.theater.effect"
	},
	tailor: {
		name: "games.tinytowns.cards.tailor.name",
		effect: "games.tinytowns.cards.tailor.effect"
	},
	market: {
		name: "games.tinytowns.cards.market.name",
		effect: "games.tinytowns.cards.market.effect"
	},
	bakery: {
		name: "games.tinytowns.cards.bakery.name",
		effect: "games.tinytowns.cards.bakery.effect"
	},
	tavern: {
		name: "games.tinytowns.cards.tavern.name",
		effect: "games.tinytowns.cards.tavern.effect"
	},
	inn: {
		name: "games.tinytowns.cards.inn.name",
		effect: "games.tinytowns.cards.inn.effect"
	},
	feastHall: {
		name: "games.tinytowns.cards.feastHall.name",
		effect: "games.tinytowns.cards.feastHall.effect"
	},
	almshouse: {
		name: "games.tinytowns.cards.almshouse.name",
		effect: "games.tinytowns.cards.almshouse.effect"
	},
	orchard: {
		name: "games.tinytowns.cards.orchard.name",
		effect: "games.tinytowns.cards.orchard.effect"
	},
	greenhouse: {
		name: "games.tinytowns.cards.greenhouse.name",
		effect: "games.tinytowns.cards.greenhouse.effect"
	},
	granary: {
		name: "games.tinytowns.cards.granary.name",
		effect: "games.tinytowns.cards.granary.effect"
	},
	farm: {
		name: "games.tinytowns.cards.farm.name",
		effect: "games.tinytowns.cards.farm.effect"
	},
	temple: {
		name: "games.tinytowns.cards.temple.name",
		effect: "games.tinytowns.cards.temple.effect"
	},
	cloister: {
		name: "games.tinytowns.cards.cloister.name",
		effect: "games.tinytowns.cards.cloister.effect"
	},
	chapel: {
		name: "games.tinytowns.cards.chapel.name",
		effect: "games.tinytowns.cards.chapel.effect"
	},
	abbey: {
		name: "games.tinytowns.cards.abbey.name",
		effect: "games.tinytowns.cards.abbey.effect"
	},
	cottage: {
		name: "games.tinytowns.cards.cottage.name",
		effect: "games.tinytowns.cards.cottage.effect"
	},
	silvaForum: {
		name: "games.tinytowns.cards.silvaForum.name",
		effect: "games.tinytowns.cards.silvaForum.effect"
	},
	elderTree: {
		name: "games.tinytowns.cards.elderTree.name",
		effect: "games.tinytowns.cards.elderTree.effect"
	},
	opaleye: {
		name: "games.tinytowns.cards.opaleye.name",
		effect: "games.tinytowns.cards.opaleye.effect"
	},
	obelisk: {
		name: "games.tinytowns.cards.obelisk.name",
		effect: "games.tinytowns.cards.obelisk.effect"
	},
	mandrasPalace: {
		name: "games.tinytowns.cards.mandrasPalace.name",
		effect: "games.tinytowns.cards.mandrasPalace.effect"
	},
	groveUniversity: {
		name: "games.tinytowns.cards.groveUniversity.name",
		effect: "games.tinytowns.cards.groveUniversity.effect"
	},
	mausoleum: {
		name: "games.tinytowns.cards.mausoleum.name",
		effect: "games.tinytowns.cards.mausoleum.effect"
	},
	fortIronweed: {
		name: "games.tinytowns.cards.fortIronweed.name",
		effect: "games.tinytowns.cards.fortIronweed.effect"
	},
	cathedralCaterina: {
		name: "games.tinytowns.cards.cathedralCaterina.name",
		effect: "games.tinytowns.cards.cathedralCaterina.effect"
	},
	barrettCastle: {
		name: "games.tinytowns.cards.barrettCastle.name",
		effect: "games.tinytowns.cards.barrettCastle.effect"
	},
	archive: {
		name: "games.tinytowns.cards.archive.name",
		effect: "games.tinytowns.cards.archive.effect"
	},
	architectGuild: {
		name: "games.tinytowns.cards.architectGuild.name",
		effect: "games.tinytowns.cards.architectGuild.effect"
	},
	starloom: {
		name: "games.tinytowns.cards.starloom.name",
		effect: "games.tinytowns.cards.starloom.effect"
	},
	skyBaths: {
		name: "games.tinytowns.cards.skyBaths.name",
		effect: "games.tinytowns.cards.skyBaths.effect"
	},
	bondmaker: {
		name: "games.tinytowns.cards.bondmaker.name",
		effect: "games.tinytowns.cards.bondmaker.effect"
	}
}, Me = {
	wood: "games.tinytowns.resources.wood",
	wheat: "games.tinytowns.resources.wheat",
	brick: "games.tinytowns.resources.brick",
	glass: "games.tinytowns.resources.glass",
	stone: "games.tinytowns.resources.stone"
}, Ne = {
	cottage: "games.tinytowns.groups.cottage",
	food: "games.tinytowns.groups.food",
	civic: "games.tinytowns.groups.civic",
	faith: "games.tinytowns.groups.faith",
	tavern: "games.tinytowns.groups.tavern",
	trade: "games.tinytowns.groups.trade",
	industry: "games.tinytowns.groups.industry",
	monument: "games.tinytowns.groups.monument"
}, Z = (e) => je[e];
function Q({ resource: e, flat: t = !1 }) {
	let n = se[e], [r, i] = {
		wood: ["#91664c", "#422d25"],
		wheat: ["#ffd15c", "#c77a19"],
		brick: ["#fb7961", "#b62d2d"],
		glass: ["#70d2cf", "#16727e"],
		stone: ["#d8d0b4", "#8b826e"]
	}[e];
	return /* @__PURE__ */ m("svg", {
		className: "tinytowns-cube",
		viewBox: "0 0 64 64",
		"aria-hidden": "true",
		children: t ? /* @__PURE__ */ h(te, { children: [/* @__PURE__ */ m("rect", {
			x: "2",
			y: "2",
			width: "60",
			height: "60",
			rx: "1",
			fill: n,
			stroke: "#fff",
			strokeWidth: "2"
		}), /* @__PURE__ */ m("path", {
			d: "M5 5H59",
			stroke: r,
			strokeWidth: "2"
		})] }) : /* @__PURE__ */ h(te, { children: [
			/* @__PURE__ */ m("path", {
				d: "M5 19L38 7L60 21L28 34Z",
				fill: r
			}),
			/* @__PURE__ */ m("path", {
				d: "M5 19L28 34V61L5 46Z",
				fill: i
			}),
			/* @__PURE__ */ m("path", {
				d: "M28 34L60 21V48L28 61Z",
				fill: n
			}),
			/* @__PURE__ */ m("path", {
				d: "M7 19L28 32L58 21M29 35V58",
				fill: "none",
				stroke: "#fff5d9",
				strokeOpacity: ".42",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ m("path", {
				d: "M36 36V49M43 31V54M51 30V45",
				stroke: i,
				strokeWidth: ".7",
				opacity: ".19"
			}),
			/* @__PURE__ */ m("path", {
				d: "M12 28V44M20 34V49",
				stroke: "#fff3d2",
				strokeWidth: ".65",
				opacity: ".17"
			})
		] })
	});
}
function Pe({ type: e }) {
	return /* @__PURE__ */ m("img", {
		className: "tinytowns-type",
		src: p(`games/tinytowns/live/icon-${e}.svg`),
		alt: "",
		draggable: !1
	});
}
function Fe({ type: e }) {
	return /* @__PURE__ */ m("span", {
		className: "tinytowns-wood-piece",
		children: /* @__PURE__ */ m(Pe, { type: e })
	});
}
function Ie() {
	return /* @__PURE__ */ m("svg", {
		className: "tinytowns-hammer-art",
		viewBox: "0 0 44 50",
		"aria-hidden": "true",
		children: /* @__PURE__ */ h("g", {
			transform: "translate(21 12) rotate(-24)",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M-4 3H5V31Q0 36-4 31Z",
					fill: "#c19357",
					stroke: "#694c32"
				}),
				/* @__PURE__ */ m("path", {
					d: "M-17-5Q0-10 18-5V7Q0 11-17 7Z",
					fill: "#e3e0d1",
					stroke: "#746d5d",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ m("path", {
					d: "M-14-3H13",
					stroke: "#fff8df",
					strokeWidth: "2"
				})
			]
		})
	});
}
function Le({ pattern: e }) {
	let t = s(), n = Math.max(...e.map((e) => e[0])) + 1, r = Math.max(...e.map((e) => e[1])) + 1;
	return /* @__PURE__ */ m("div", {
		className: "tinytowns-pattern",
		role: "img",
		"aria-label": e.map(([e, n, r]) => `${t(Me[r])} ${e + 1},${n + 1}`).join("; "),
		style: {
			"--tinytowns-pattern-w": n,
			"--tinytowns-pattern-h": r
		},
		children: e.map(([e, t, n]) => /* @__PURE__ */ m("span", {
			style: {
				gridColumn: e + 1,
				gridRow: t + 1
			},
			children: /* @__PURE__ */ m(Q, {
				resource: n,
				flat: !0
			})
		}, `${e}:${t}`))
	});
}
function Re({ id: e, selected: t = !1, available: n = !1, onSelect: r, onDetails: i, compact: a = !1 }) {
	let o = s(), c = w[e], { ref: l } = d(`tinytowns-card:${e}`), { ref: f } = d(`tinytowns-card-piece:${e}`);
	return /* @__PURE__ */ h("div", {
		ref: l,
		className: `tinytowns-card${a ? " tinytowns-card-compact" : ""}`,
		"data-selected": t,
		"data-available": n,
		children: [/* @__PURE__ */ h("button", {
			type: "button",
			className: "tinytowns-card-face",
			onClick: r ?? i,
			disabled: !r && !i,
			"aria-pressed": r ? t : void 0,
			"aria-label": o(Z(e).name),
			children: [
				/* @__PURE__ */ h("div", {
					className: "tinytowns-card-title",
					children: [/* @__PURE__ */ m("strong", { children: o(Z(e).name) }), /* @__PURE__ */ m("span", {
						className: "tinytowns-category",
						ref: f,
						children: /* @__PURE__ */ m(Pe, { type: c.group })
					})]
				}),
				/* @__PURE__ */ m("img", {
					className: "tinytowns-card-art",
					src: p(`games/tinytowns/live/art-${c.art}.svg`),
					alt: "",
					draggable: !1
				}),
				/* @__PURE__ */ m("div", {
					className: "tinytowns-card-pattern",
					children: /* @__PURE__ */ m(Le, { pattern: c.pattern })
				})
			]
		}), /* @__PURE__ */ h("button", {
			type: "button",
			className: "tinytowns-card-detail",
			onClick: i,
			disabled: !i,
			"aria-label": `${o("games.tinytowns.details")} · ${o(Z(e).name)}`,
			children: [/* @__PURE__ */ m("span", { children: o(Z(e).effect) }), /* @__PURE__ */ m(u, { size: 16 })]
		})]
	});
}
function ze() {
	return /* @__PURE__ */ m("svg", {
		className: "tinytowns-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ m("rect", {
			x: "3",
			y: "3",
			width: "94",
			height: "94",
			rx: "4",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "7 5",
			vectorEffect: "non-scaling-stroke"
		})
	});
}
function Be({ resource: e, anchor: t }) {
	let { ref: n, hidden: r } = d(t);
	return /* @__PURE__ */ m("span", {
		ref: n,
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ m(Q, { resource: e })
	});
}
function Ve({ town: e, index: t, legal: n, selected: r, preview: i, onClick: a, disabled: o }) {
	let c = s(), l = e.cells[t], u = l.building ? w[l.building].group : null, { ref: f, hidden: ee } = d(`tinytowns-cell:${e.rid}:${t}`), p = [
		c("games.tinytowns.cell", {
			row: (t >> 2) + 1,
			col: t % 4 + 1
		}),
		l.building ? c(Z(l.building).name) : l.resource ? c(Me[l.resource]) : c("games.tinytowns.empty"),
		e.fed.includes(t) ? c("games.tinytowns.fed") : ""
	].filter(Boolean).join(" · ");
	return /* @__PURE__ */ h("button", {
		ref: f,
		type: "button",
		className: "tinytowns-square",
		"data-fx-hidden": ee,
		"data-legal": n,
		"data-selected": r,
		"aria-label": p,
		"aria-pressed": r,
		disabled: o,
		onClick: () => a(t),
		children: [
			u && /* @__PURE__ */ h("span", {
				className: "tinytowns-building",
				"data-fed": e.fed.includes(t),
				children: [/* @__PURE__ */ m(Fe, { type: u }), P(l) > 0 && /* @__PURE__ */ m("span", {
					className: "tinytowns-fed",
					"aria-hidden": "true",
					children: e.fed.includes(t) ? "✓" : "○"
				})]
			}),
			l.resource && /* @__PURE__ */ m("span", {
				className: "tinytowns-resource-piece",
				children: /* @__PURE__ */ m(Q, { resource: l.resource })
			}),
			i && !l.resource && !l.building && /* @__PURE__ */ m("span", {
				className: "tinytowns-preview-piece",
				children: /* @__PURE__ */ m(Q, { resource: i })
			}),
			l.marker && /* @__PURE__ */ m("span", {
				className: "tinytowns-marker",
				children: /* @__PURE__ */ m(Q, {
					resource: l.marker,
					flat: !0
				})
			}),
			l.stored.length > 0 && /* @__PURE__ */ m("span", {
				className: "tinytowns-stored",
				children: l.stored.map((n, r) => /* @__PURE__ */ m(Be, {
					resource: n,
					anchor: `tinytowns-stored:${e.rid}:${t}:${r}`
				}, r))
			}),
			n && /* @__PURE__ */ m(ze, {})
		]
	});
}
function He({ town: e, name: t, legal: n = [], selected: r = [], preview: i, onClick: a, readOnly: o = !1 }) {
	let c = s(), { ref: l } = d(`tinytowns-town:${e.rid}`);
	return /* @__PURE__ */ h("div", {
		className: "tinytowns-town-area",
		ref: l,
		children: [/* @__PURE__ */ h("div", {
			className: "tinytowns-town-plaque",
			children: [/* @__PURE__ */ m("strong", { children: c("games.tinytowns.board", { name: t }) }), /* @__PURE__ */ h("span", { children: [
				e.score.total,
				" ",
				/* @__PURE__ */ m("small", { children: c("games.tinytowns.score") })
			] })]
		}), /* @__PURE__ */ m("div", {
			className: "tinytowns-board",
			style: { backgroundImage: `url("${p("games/tinytowns/live/meadow.svg")}")` },
			role: "group",
			"aria-label": c("games.tinytowns.board", { name: t }),
			children: e.cells.map((t, s) => /* @__PURE__ */ m(Ve, {
				town: e,
				index: s,
				legal: n.includes(s),
				selected: r.includes(s),
				preview: n.includes(s) ? i : void 0,
				onClick: a,
				disabled: o ? !e.cells[s].building && !e.cells[s].resource : !1
			}, s))
		})]
	});
}
function Ue({ town: e }) {
	return /* @__PURE__ */ m("span", {
		className: "tinytowns-mini-town",
		"aria-hidden": "true",
		style: { backgroundImage: `url("${p("games/tinytowns/live/meadow.svg")}")` },
		children: e.cells.map((e, t) => /* @__PURE__ */ m("span", { children: e.building ? /* @__PURE__ */ m(Pe, { type: w[e.building].group }) : e.resource ? /* @__PURE__ */ m(Q, { resource: e.resource }) : null }, t))
	});
}
function We({ resource: e, selected: t = !1, disabled: n = !1, onClick: r, offer: i, supplyAnchor: a = !0 }) {
	let o = s(), { ref: c } = d(a ? `tinytowns-supply:${e}${i === void 0 ? "" : `:${i}`}` : null);
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: "tinytowns-supply-piece",
		"data-selected": t,
		disabled: n,
		"aria-pressed": t,
		"aria-label": o(Me[e]),
		onClick: r,
		children: [/* @__PURE__ */ m("span", {
			className: "tinytowns-supply-cube",
			ref: c,
			children: /* @__PURE__ */ m(Q, { resource: e })
		}), /* @__PURE__ */ m("span", { children: o(Me[e]) })]
	});
}
function Ge({ title: e, onClose: t, children: n, className: i = "" }) {
	let o = a(null), c = s();
	return r(() => {
		let e = document.activeElement;
		return o.current?.focus(), () => e?.focus();
	}, []), /* @__PURE__ */ m("div", {
		className: "tinytowns-modal-backdrop",
		onClick: t,
		children: /* @__PURE__ */ h("section", {
			ref: o,
			className: `tinytowns-dialog ${i}`,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			tabIndex: -1,
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				if (e.key === "Escape" && (e.stopPropagation(), t()), e.key === "Tab") {
					let t = [...o.current?.querySelectorAll("button:not(:disabled),[tabindex=\"0\"],input") ?? []].filter((e) => e.offsetParent !== null), n = t[0], r = t.at(-1);
					e.shiftKey && (document.activeElement === n || document.activeElement === o.current) ? (e.preventDefault(), r?.focus()) : !e.shiftKey && (document.activeElement === r || document.activeElement === o.current) && (e.preventDefault(), n?.focus());
				}
			},
			children: [/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("h2", { children: e }), /* @__PURE__ */ m("button", {
				type: "button",
				onClick: t,
				"aria-label": c("games.tinytowns.close"),
				children: "×"
			})] }), n]
		})
	});
}
function Ke({ id: e, onClose: t, secret: n = !1 }) {
	let r = s(), i = w[e];
	return /* @__PURE__ */ h(Ge, {
		title: r(Z(e).name),
		onClose: t,
		className: "tinytowns-details",
		children: [
			/* @__PURE__ */ m("img", {
				className: "tinytowns-detail-art",
				src: p(`games/tinytowns/live/art-${i.art}.svg`),
				alt: ""
			}),
			/* @__PURE__ */ m("div", {
				className: "tinytowns-detail-pattern",
				children: /* @__PURE__ */ m(Le, { pattern: i.pattern })
			}),
			/* @__PURE__ */ h("span", {
				className: "tinytowns-type-caption",
				children: [
					/* @__PURE__ */ m(Pe, { type: i.group }),
					r(Ne[i.group]),
					n && /* @__PURE__ */ m("small", { children: r("games.tinytowns.privateCard") })
				]
			}),
			/* @__PURE__ */ m("p", { children: r(Z(e).effect) }),
			/* @__PURE__ */ m("button", {
				type: "button",
				onClick: t,
				children: r("games.tinytowns.returnBoard")
			})
		]
	});
}
//#endregion
//#region src/games/tinytowns/decisions.ts
function qe(e, t, n) {
	let r = Object.fromEntries(e.towns.map((e) => [e.rid, {
		...e,
		options: e.rid === n ? t?.options ?? [] : [],
		monument: e.rid === n ? t?.monument ?? e.monument : e.monument,
		effects: e.effect ? [e.effect] : [],
		fed: null
	}]));
	return {
		...e,
		towns: r,
		seed: 0,
		cursor: 0,
		deck: [],
		selectedOffer: null
	};
}
//#endregion
//#region src/games/tinytowns/view-player.tsx
function Je(e) {
	let t = e.public, r = e.private, i = s(), [a, l] = o(null), [p, g] = o(null), [_, ne] = o(null), [v, y] = o(0), [re, ie] = o(null), [x, S] = o(null), [C, ae] = o(null), [oe, se] = o(null), [T, E] = o("wood"), [D, ce] = o([]), [O, le] = o(null), { ref: ue } = d(`tinytowns-cavern:${e.myRid}`), k = t.towns.find((t) => t.rid === e.myRid), de = a ?? e.myRid, A = t.towns.find((e) => e.rid === de) ?? k, j = A.rid === e.myRid, fe = t.phase !== "done", N = j && fe && k.completed === null && !k.ready, pe = qe(t, r, e.myRid), F = k.effect, he = (t) => e.members.find((e) => e.rid === t)?.name ?? t, _e = t.phase === "name" && t.master === e.myRid, I = t.phase === "play" && !k.placed && N, L = N && t.phase === "play" && k.placed && F !== null, R = N && t.phase === "play" && k.placed && !F, B = (R || L) && _ && (t.cards.includes(_) || _ === r?.monument && !k.monumentBuilt) ? _ : null, V = De(pe, e.myRid), H = re?.round === t.round ? re.offer : 0, ye = re?.round === t.round ? re.resource : t.resource ?? t.offers[0] ?? "wood", U = V.filter((e) => e.resource === ye && (t.mode !== "solo" || e.offer === H)), W = B && R ? me(k.cells, B) : [], G = W.length ? W[v % W.length] : void 0, K = oe !== null && k.cells[oe].building && w[k.cells[oe].building].group !== "monument" && !F?.used.includes(oe) ? oe : null, xe = B === "bank" ? z(k.cells) : b, Se = xe.includes(T) ? T : xe[0], J = [];
	j && O ? J = k.cells.flatMap((e, t) => P(e) ? [t] : []) : I ? J = x ? U.filter((e) => e.warehouse === x.warehouse && e.swap === x.swap).map((e) => e.at) : U.map((e) => e.at) : G && B ? J = ge(k.cells, B, G, k.cells.some((e) => e.building === "obelisk")) : L && F?.kind === "guild" && K === null ? J = k.cells.flatMap((e, t) => e.building && w[e.building].group !== "monument" && !F.used.includes(t) ? [t] : []) : L && B && (J = F?.kind === "guild" && K !== null ? B === "shed" ? k.cells.flatMap((e, t) => M(e) || t === K ? [t] : []) : [K] : k.cells.flatMap((e, t) => M(e) ? [t] : []));
	let Y = (t) => {
		e.send(t), ne(null), y(0), S(null), ae(null), se(null), ce([]), le(null);
	}, Ce = (e) => {
		if (e === k.monument && k.monumentBuilt) {
			g(e);
			return;
		}
		if (!N || !R && !L || F?.kind === "watch") {
			g(e);
			return;
		}
		if (F?.kind === "watchTrigger" && !F.choices.includes(e)) {
			g(e);
			return;
		}
		ne(_ === e ? null : e), y(0), E("wood");
	}, we = (t) => {
		if (j && O) {
			le(O.includes(t) ? O.filter((e) => e !== t) : [...O, t]);
			return;
		}
		if (!j || !fe || !N) {
			A.cells[t].building && g(A.cells[t].building);
			return;
		}
		if (I) {
			let n = x ? U.find((e) => e.at === t && e.warehouse === x.warehouse && e.swap === x.swap) : U.find((e) => e.at === t && e.warehouse === void 0);
			if (n) {
				Y(n);
				return;
			}
			if (A.cells[t].building === "warehouse" && q(pe, e.myRid)) {
				ae(t);
				return;
			}
		}
		if (L && F?.kind === "guild" && K === null && J.includes(t)) {
			se(t);
			return;
		}
		if (B && J.includes(t)) {
			let e = B === "bank" || B === "factory" ? Se : void 0;
			L ? Y({
				type: "effect",
				id: B,
				at: t,
				source: K ?? void 0,
				resource: e
			}) : G && Y({
				type: "build",
				id: B,
				cells: G.cells,
				at: t,
				resource: e
			});
			return;
		}
		A.cells[t].building && g(A.cells[t].building);
	}, Te = () => {
		ne(null), se(null), S(null), le(null);
	}, Ee = k.completed !== null, Oe = t.phase === "done" ? i("games.tinytowns.completed") : t.phase === "monument" ? i("games.tinytowns.chooseMonument") : Ee ? i("games.tinytowns.completed") : _e ? i("games.tinytowns.nameResource") : t.phase === "name" || k.ready ? i("games.tinytowns.waiting") : I ? i("games.tinytowns.placeResource") : F?.kind === "watch" ? i("games.tinytowns.watchPrompt") : F?.kind === "guild" ? i("games.tinytowns.guildPrompt") : F?.kind === "watchTrigger" ? i("games.tinytowns.watchTrigger") : i(F ? "games.tinytowns.grovePrompt" : "games.tinytowns.buildPrompt"), ke = (e) => R && !(e === r?.monument && k.monumentBuilt) && me(k.cells, e).length > 0 && (e !== "bank" || z(k.cells).length > 0), X = j ? r?.monument : A.monument, Ae = t.phase === "monument" && !!r?.options.length, je = L && F?.kind === "watch", Ne = p !== null || C !== null, Fe = /* @__PURE__ */ h("div", {
		className: "tinytowns-resources",
		"data-passive": !_e && !I,
		"aria-label": i("games.tinytowns.placeResource"),
		children: [t.mode === "solo" && /* @__PURE__ */ m("div", {
			className: "tinytowns-offers",
			children: t.offers.map((e, n) => /* @__PURE__ */ m(We, {
				resource: e,
				offer: n,
				selected: H === n,
				disabled: !I,
				onClick: () => {
					ie({
						round: t.round,
						resource: e,
						offer: n
					}), S(null);
				}
			}, n))
		}), /* @__PURE__ */ m("div", {
			className: "tinytowns-supply",
			children: b.map((e) => /* @__PURE__ */ m(We, {
				resource: e,
				selected: (_e || I) && ye === e,
				disabled: _e ? !z(k.cells).includes(e) : !I || !V.some((n) => n.resource === e && (t.mode !== "solo" || n.offer === H)),
				onClick: () => _e ? Y({
					type: "name",
					resource: e
				}) : (ie({
					round: t.round,
					resource: e,
					offer: H
				}), S(null))
			}, e))
		})]
	}), ze = /* @__PURE__ */ m("div", {
		className: "tinytowns-local-tools",
		"data-active": !!B || !!O,
		children: O ? /* @__PURE__ */ h("div", {
			className: "tinytowns-feed-choice",
			children: [/* @__PURE__ */ m("span", { children: i("games.tinytowns.feedPrompt") }), !ve(k.cells, O) && /* @__PURE__ */ m("span", {
				role: "alert",
				children: i("games.tinytowns.feedInvalid")
			})]
		}) : B ? /* @__PURE__ */ h(te, { children: [
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "tinytowns-current-card",
				onClick: () => g(B),
				"aria-label": `${i("games.tinytowns.details")} · ${i(Z(B).name)}`,
				children: [
					/* @__PURE__ */ m(Pe, { type: w[B].group }),
					/* @__PURE__ */ m("strong", { children: i(Z(B).name) }),
					/* @__PURE__ */ m(u, { size: 16 }),
					/* @__PURE__ */ m("small", { children: G ? i("games.tinytowns.layout", {
						n: v % W.length + 1,
						total: W.length
					}) : i(R ? "games.tinytowns.noLayout" : "games.tinytowns.selectTarget") })
				]
			}),
			/* @__PURE__ */ m(Le, { pattern: w[B].pattern }),
			W.length > 1 && /* @__PURE__ */ h("div", {
				className: "tinytowns-layout-switch",
				children: [/* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => y((v + W.length - 1) % W.length),
					"aria-label": i("games.tinytowns.previousLayout"),
					children: /* @__PURE__ */ m(c, { size: 18 })
				}), /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => y((v + 1) % W.length),
					"aria-label": i("games.tinytowns.nextLayout"),
					children: /* @__PURE__ */ m(c, {
						size: 18,
						className: "tinytowns-next-icon"
					})
				})]
			}),
			(B === "bank" || B === "factory") && /* @__PURE__ */ m("div", {
				className: "tinytowns-marker-choices",
				"aria-label": i("games.tinytowns.chooseMarker"),
				children: xe.map((e) => /* @__PURE__ */ m("button", {
					type: "button",
					"aria-label": i(Me[e]),
					"aria-pressed": Se === e,
					onClick: () => E(e),
					children: /* @__PURE__ */ m(Q, {
						resource: e,
						flat: !0
					})
				}, e))
			})
		] }) : null
	});
	return /* @__PURE__ */ h("div", {
		className: "tinytowns tinytowns-root",
		children: [
			/* @__PURE__ */ m("div", {
				className: "tinytowns-game-content",
				inert: Ne,
				children: /* @__PURE__ */ m(ee, {
					adaptive: !0,
					scroll: !1,
					className: "tinytowns-screen",
					banner: /* @__PURE__ */ h("div", {
						className: "tinytowns-banner",
						children: [
							/* @__PURE__ */ h("div", {
								className: "tinytowns-brand",
								children: [/* @__PURE__ */ m("strong", { children: i("games.tinytowns.name") }), /* @__PURE__ */ m("small", { children: "T I N Y  T O W N S" })]
							}),
							/* @__PURE__ */ h("div", {
								className: "tinytowns-phase",
								role: "status",
								children: [/* @__PURE__ */ m("strong", { children: i("games.tinytowns.round", { n: t.round }) }), /* @__PURE__ */ m("span", { children: B ? i("games.tinytowns.selectTarget") : Oe })]
							}),
							/* @__PURE__ */ m("div", {
								className: "tinytowns-players",
								children: t.players.map((r) => {
									let a = t.towns.find((e) => e.rid === r), o = e.members.find((e) => e.rid === r);
									return /* @__PURE__ */ h("button", {
										type: "button",
										className: "tinytowns-player",
										"aria-pressed": de === r,
										onClick: () => {
											l(r), Te();
										},
										children: [
											/* @__PURE__ */ m("span", {
												className: "tinytowns-avatar",
												style: { background: f[o?.colorIndex ?? 0]?.hex },
												children: /* @__PURE__ */ m("img", {
													src: n[(e.members.find((e) => e.rid === r)?.avatar ?? 0) % n.length],
													alt: "",
													draggable: !1,
													style: {
														width: "1.75em",
														height: "1.75em",
														maxWidth: "100%",
														maxHeight: "100%",
														display: "block",
														objectFit: "contain",
														pointerEvents: "none",
														borderRadius: "inherit"
													}
												})
											}),
											/* @__PURE__ */ m("span", {
												className: "tinytowns-player-name",
												children: he(r)
											}),
											/* @__PURE__ */ h("small", { children: [r === e.myRid ? `${i("games.tinytowns.yourSeat")} · ` : "", a.completed === null ? a.ready ? i("games.tinytowns.roundReady") : a.placed ? i("games.tinytowns.buildingNow") : i("games.tinytowns.placeResource") : i("games.tinytowns.completed")] }),
											t.mode === "master" && t.master === r && /* @__PURE__ */ m("span", {
												className: "tinytowns-hammer",
												title: i("games.tinytowns.master"),
												children: /* @__PURE__ */ m(Ie, {})
											})
										]
									}, r);
								})
							})
						]
					}),
					actionsHeight: "tinytowns-actions-slot",
					actions: /* @__PURE__ */ h("div", {
						className: "tinytowns-actions",
						children: [
							/* @__PURE__ */ m("div", {
								className: "tinytowns-action-status",
								children: j ? /* @__PURE__ */ m("span", { children: Ee ? i("games.tinytowns.completed") : k.ready ? i("games.tinytowns.waiting") : x ? i("games.tinytowns.warehouseSwap") : B ? i(Z(B).name) : t.resource ? /* @__PURE__ */ h(te, { children: [
									/* @__PURE__ */ m("span", {
										className: "tinytowns-status-cube",
										children: /* @__PURE__ */ m(Q, { resource: t.resource })
									}),
									i(Me[t.resource]),
									k.placed && /* @__PURE__ */ h(te, { children: [" · ", i("games.tinytowns.placed")] })
								] }) : null }) : /* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => {
										l(e.myRid), Te();
									},
									children: he(e.myRid)
								})
							}),
							(B || x || O) && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: Te,
								children: i("games.tinytowns.cancel")
							}),
							t.config.cavern && t.mode !== "solo" && /* @__PURE__ */ h("button", {
								type: "button",
								ref: ue,
								className: "tinytowns-cavern",
								style: { visibility: I ? "visible" : "hidden" },
								disabled: !I || !q(pe, e.myRid) || k.cavernUsed >= 2,
								onClick: () => Y({ type: "cavern" }),
								children: [
									i("games.tinytowns.cavern"),
									" · ",
									2 - k.cavernUsed
								]
							}),
							R && !B && !O && k.cells.some((e) => P(e) > 0) && /* @__PURE__ */ m("button", {
								type: "button",
								className: "tinytowns-secondary",
								onClick: () => le([...k.fed]),
								children: i("games.tinytowns.feed")
							}),
							O ? /* @__PURE__ */ m("button", {
								type: "button",
								className: "tinytowns-primary",
								disabled: !ve(k.cells, O),
								onClick: () => Y({
									type: "feed",
									cells: O
								}),
								children: i("games.tinytowns.confirm")
							}) : L && F?.kind !== "watch" ? /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => Y({
									type: "effect",
									skip: !0
								}),
								children: i("games.tinytowns.skip")
							}) : N && t.phase === "play" && k.placed && !F ? /* @__PURE__ */ m("button", {
								type: "button",
								className: "tinytowns-primary",
								onClick: () => Y({ type: "ready" }),
								children: i(k.cells.some(M) ? "games.tinytowns.ready" : "games.tinytowns.finish")
							}) : N && be(pe, e.myRid) ? /* @__PURE__ */ m("button", {
								type: "button",
								className: "tinytowns-primary",
								onClick: () => Y({ type: "finish" }),
								children: i("games.tinytowns.finish")
							}) : null
						]
					}),
					children: /* @__PURE__ */ h("div", {
						className: "tinytowns-layout",
						children: [
							/* @__PURE__ */ h("section", {
								className: "tinytowns-town-column",
								children: [/* @__PURE__ */ m(He, {
									town: A,
									name: he(A.rid),
									legal: J,
									selected: O ?? G?.cells ?? (K === null ? [] : [K]),
									preview: I && !x ? ye : void 0,
									onClick: we,
									readOnly: !N
								}), /* @__PURE__ */ h("div", {
									className: "tinytowns-context",
									"data-show-tools": !!B || !!O,
									children: [Fe, ze]
								})]
							}),
							/* @__PURE__ */ h("section", {
								className: "tinytowns-library",
								"aria-label": i("games.tinytowns.optBuildings"),
								children: [/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("span", { children: i("games.tinytowns.optBuildings") }), X && /* @__PURE__ */ h("div", {
									className: "tinytowns-monument-controls",
									children: [/* @__PURE__ */ h("button", {
										type: "button",
										onClick: () => Ce(X),
										children: [/* @__PURE__ */ m(Pe, { type: "monument" }), /* @__PURE__ */ m("span", { children: i("games.tinytowns.monument") })]
									}), /* @__PURE__ */ m("button", {
										type: "button",
										"aria-label": `${i("games.tinytowns.details")} · ${i(Z(X).name)}`,
										onClick: () => g(X),
										children: /* @__PURE__ */ m(u, { size: 15 })
									})]
								})] }), /* @__PURE__ */ h("div", {
									className: "tinytowns-cards",
									children: [t.cards.map((e) => /* @__PURE__ */ m(Re, {
										id: e,
										selected: B === e,
										available: ke(e),
										onSelect: () => Ce(e),
										onDetails: () => g(e)
									}, e)), X ? /* @__PURE__ */ h("div", {
										className: "tinytowns-side-monument",
										children: [/* @__PURE__ */ m(Re, {
											id: X,
											selected: B === X,
											available: ke(X),
											onSelect: () => Ce(X),
											onDetails: () => g(X)
										}), j && !k.monumentBuilt && /* @__PURE__ */ m("small", { children: i("games.tinytowns.privateCard") })]
									}) : t.config.monuments && /* @__PURE__ */ m("div", {
										className: "tinytowns-secret-monument",
										"aria-label": i("games.tinytowns.monumentHidden"),
										children: /* @__PURE__ */ m(Pe, { type: "monument" })
									})]
								})]
							}),
							(Ae || je) && /* @__PURE__ */ h("div", {
								className: "tinytowns-choice-screen",
								children: [
									/* @__PURE__ */ m("h2", { children: i(Ae ? "games.tinytowns.chooseMonument" : "games.tinytowns.watchPrompt") }),
									/* @__PURE__ */ m("div", {
										className: "tinytowns-choice-cards",
										children: (Ae ? r.options : t.cards).map((e) => /* @__PURE__ */ m(Re, {
											id: e,
											selected: D.includes(e),
											onDetails: () => g(e),
											onSelect: () => Ae ? Y({
												type: "monument",
												id: e
											}) : ce(D.includes(e) ? D.filter((t) => t !== e) : D.length < 3 ? [...D, e] : D)
										}, e))
									}),
									je && /* @__PURE__ */ h("button", {
										type: "button",
										className: "tinytowns-primary",
										disabled: D.length !== 3,
										onClick: () => Y({
											type: "effect",
											choices: D
										}),
										children: [
											i("games.tinytowns.confirm"),
											" (",
											D.length,
											"/3)"
										]
									})
								]
							})
						]
					})
				})
			}),
			p && /* @__PURE__ */ m(Ke, {
				id: p,
				onClose: () => g(null),
				secret: p === r?.monument && !k.monumentBuilt
			}),
			C !== null && /* @__PURE__ */ h(Ge, {
				title: i("games.tinytowns.warehouseSwap"),
				onClose: () => ae(null),
				children: [/* @__PURE__ */ m("div", {
					className: "tinytowns-storage-choice",
					children: k.cells[C].stored.map((e, t) => /* @__PURE__ */ m(We, {
						resource: e,
						supplyAnchor: !1,
						onClick: () => {
							S({
								warehouse: C,
								swap: t
							}), ae(null);
						}
					}, t))
				}), k.cells[C].stored.length < 3 && /* @__PURE__ */ m("button", {
					type: "button",
					className: "tinytowns-primary",
					onClick: () => {
						let e = U.find((e) => e.warehouse === C && e.swap === void 0);
						e && Y(e);
					},
					children: i("games.tinytowns.warehouseStore")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/tinytowns/bot.ts
var Ye = {
	progress: 1.8,
	completion: 5,
	space: .3,
	food: 1.4,
	score: 1
};
function Xe(e) {
	let t = 2 ** 32 - 2 ** 32 % e.length, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return e[n[0] % e.length];
}
function $(e, t, n) {
	let r = w[t], i = e.filter((e) => e.building === t).length, a = e.filter((e) => N(e) === "cottage").length, o = e.filter((e) => N(e) === "food").length;
	return r.group === "food" ? (a > o * 3.5 ? 8 : o ? 2 : 6) * n.food : r.group === "cottage" ? a < 6 ? 7 : 4 : r.group === "monument" ? t === "elderTree" ? 10 : 8 : t === "almshouse" ? [
		3,
		9,
		-3,
		17,
		-4,
		24
	][Math.min(5, i)] : t === "tavern" ? [
		4,
		5,
		6,
		7,
		8,
		1
	][Math.min(5, i)] : t === "chapel" ? Math.max(3, a) : t === "warehouse" ? i ? 1 : 4 : t === "factory" ? i ? 2 : 6 : t === "tradingPost" ? i < 3 ? 6 : 2 : 4;
}
function Ze(e, t, n) {
	let r = Array(16).fill(0), i = 0;
	for (let a of t) {
		let t = $(e, a, n);
		for (let o of F(w[a].pattern)) {
			let a = Math.max(...o.map((e) => e[0])) + 1, s = Math.max(...o.map((e) => e[1])) + 1;
			for (let c = 0; c <= 4 - s; c++) for (let s = 0; s <= 4 - a; s++) {
				let a = o.map(([e, t]) => (c + t) * 4 + s + e);
				if (a.some((t, n) => e[t].building && e[t].building !== "tradingPost" || e[t].resource && e[t].resource !== o[n][2])) continue;
				let l = a.filter((t) => !M(e[t])).length;
				if (!l) continue;
				let u = (l / a.length) ** 2 * t * n.progress + (l === a.length ? n.completion : 0);
				i = Math.max(i, u);
				for (let t of a) e[t].resource && (r[t] = Math.max(r[t], u / a.length));
			}
		}
	}
	return r.reduce((e, t) => e + t, 0) + i * .4 + e.filter(M).length * n.space;
}
var Qe = (e, t) => t === "factory" ? "wood" : t === "bank" ? z(e)[0] : void 0;
function $e(e = Ye) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.towns.find((e) => e.rid === n.rid);
		if (!a || r.phase === "done") return null;
		if (r.phase === "monument") return i?.options.length ? { action: {
			type: "monument",
			id: n.difficulty === "weak" ? Xe(i.options) : [...i.options].sort((e, t) => {
				let n = [
					"cathedralCaterina",
					"mausoleum",
					"obelisk",
					"groveUniversity",
					"elderTree",
					"archive",
					"mandrasPalace",
					"silvaForum",
					"starloom",
					"architectGuild",
					"skyBaths",
					"barrettCastle",
					"bondmaker",
					"opaleye",
					"fortIronweed"
				];
				return n.indexOf(e) - n.indexOf(t);
			})[0]
		} } : null;
		if (a.completed !== null || a.ready) return null;
		let o = qe(r, i, n.rid), s = o.towns[n.rid], c = [...r.cards, ...i?.monument && !s.monumentBuilt ? [i.monument] : []];
		if (r.phase === "name" && r.master !== n.rid) return null;
		if (r.phase === "play" && !s.placed) {
			let t = De(o, n.rid);
			if (!t.length) return be(o, n.rid) ? { action: { type: "finish" } } : null;
			if (n.difficulty === "weak") return { action: Xe(t) };
			let i = t[0], a = -Infinity;
			for (let n of t) {
				let t = structuredClone(s.cells);
				n.warehouse === void 0 ? n.bondmaker ? t[n.at].stored.push(n.resource) : t[n.at].resource = n.resource : n.swap === void 0 ? t[n.warehouse].stored.push(n.resource) : (t[n.at].resource = t[n.warehouse].stored[n.swap], t[n.warehouse].stored[n.swap] = n.resource);
				let r = Ze(t, c, e) - (n.warehouse === void 0 ? 0 : .7);
				r > a && (a = r, i = n);
			}
			return r.config.cavern && r.mode !== "solo" && s.cavernUsed < 2 && q(o, n.rid) && a < Ze(s.cells, c, e) - 1 ? { action: { type: "cavern" } } : { action: i };
		}
		if (r.phase === "name") {
			let t = z(s.cells);
			if (!t.length) return be(o, n.rid) ? { action: { type: "finish" } } : null;
			if (n.difficulty === "weak") return { action: {
				type: "name",
				resource: Xe(t)
			} };
			let r = t[0], i = -Infinity;
			for (let n of t) for (let t = 0; t < 16; t++) if (M(s.cells[t])) {
				let a = structuredClone(s.cells);
				a[t].resource = n;
				let o = Ze(a, c, e);
				o > i && (i = o, r = n);
			}
			return { action: {
				type: "name",
				resource: r
			} };
		}
		if (s.effects.length) {
			let t = s.effects[0];
			if (t.kind === "watch") return { action: {
				type: "effect",
				choices: [...r.cards].sort((e, t) => w[e].pattern.length - w[t].pattern.length).slice(0, 3)
			} };
			let n = s.cells.flatMap((e, t) => M(e) ? [t] : []);
			if (t.kind === "guild") {
				let n = s.cells.flatMap((e, n) => e.building && w[e.building].group !== "monument" && !t.used.includes(n) ? [n] : []);
				if (!n.length) return { action: {
					type: "effect",
					skip: !0
				} };
				let i = n.sort((t, n) => $(s.cells, s.cells[t].building, e) - $(s.cells, s.cells[n].building, e))[0], a = [...r.cards].filter((e) => e !== s.cells[i].building && et(s.cells, e)).sort((t, n) => $(s.cells, n, e) - $(s.cells, t, e))[0];
				return a ? { action: {
					type: "effect",
					id: a,
					source: i,
					at: i,
					resource: Qe(s.cells, a)
				} } : { action: {
					type: "effect",
					skip: !0
				} };
			}
			if (!n.length) return { action: {
				type: "effect",
				skip: !0
			} };
			let i = (t.kind === "watchTrigger" ? t.choices : r.cards).filter((e) => et(s.cells, e)).sort((t, n) => $(s.cells, n, e) - $(s.cells, t, e))[0];
			if (!i) return { action: {
				type: "effect",
				skip: !0
			} };
			let a = n[0], o = -Infinity;
			for (let e of n) {
				let t = structuredClone(s.cells);
				t[e] = {
					...j(),
					building: i
				};
				let n = R({
					...s,
					cells: t,
					fed: null
				}).total;
				n > o && (o = n, a = e);
			}
			return { action: {
				type: "effect",
				id: i,
				at: a,
				resource: Qe(s.cells, i)
			} };
		}
		let l = [];
		for (let e of c) if (et(s.cells, e)) for (let t of me(s.cells, e)) for (let n of ge(s.cells, e, t, s.cells.some((e) => e.building === "obelisk"))) l.push({
			type: "build",
			id: e,
			cells: t.cells,
			at: n,
			resource: Qe(s.cells, e)
		});
		if (l.length) {
			if (n.difficulty === "weak") return { action: Xe(l) };
			let t = l[0], r = -Infinity;
			for (let n of l) {
				let i = structuredClone(s.cells);
				for (let e of n.cells) i[e].resource && !i[e].building && (i[e] = j());
				i[n.at] = {
					...j(),
					building: n.id,
					marker: n.resource ?? null
				};
				let a = R({
					...s,
					cells: i,
					fed: null
				}).total * e.score + Ze(i, c, e) * .4 + $(s.cells, n.id, e);
				a > r && (r = a, t = n);
			}
			return { action: t };
		}
		return { action: { type: "ready" } };
	};
}
function et(e, t) {
	return t !== "bank" || z(e).length > 0;
}
var tt = $e();
//#endregion
//#region src/games/tinytowns/fx.tsx
function nt({ to: e, parts: t, id: n, ms: r }) {
	let o = a(null);
	return i(() => {
		let n = o.current;
		if (!n) return;
		let i = [...n.children].map((n, i) => {
			if (i === t.length) return n.animate([
				{
					transform: "translateY(-12px) scale(.2)",
					opacity: 0
				},
				{
					transform: "translateY(-7px) scale(.85)",
					opacity: .8,
					offset: .55
				},
				{
					transform: "translateY(2px) scale(1.06)",
					opacity: 1,
					offset: .84
				},
				{
					transform: "translateY(0) scale(1)",
					opacity: 1
				}
			], {
				duration: r,
				easing: "cubic-bezier(.2,.7,.3,1)",
				fill: "both"
			});
			let a = t[i].from, o = e.x + e.w / 2 - a.x - a.w / 2, s = e.y + e.h / 2 - a.y - a.h / 2;
			return n.animate([
				{
					transform: "translate(0,0) scale(1)",
					opacity: 1
				},
				{
					transform: `translate(${o * .8}px,${s * .8 - 8}px) scale(.65)`,
					opacity: .9,
					offset: .58
				},
				{
					transform: `translate(${o}px,${s}px) scale(.1)`,
					opacity: 0
				}
			], {
				duration: r * .8,
				easing: "cubic-bezier(.3,.7,.25,1)",
				fill: "both"
			});
		});
		return () => i.forEach((e) => e.cancel());
	}, [
		e,
		t,
		r
	]), /* @__PURE__ */ h("div", {
		ref: o,
		children: [t.map(({ from: e, resource: t }, n) => /* @__PURE__ */ m("div", {
			style: {
				position: "absolute",
				left: e.x + e.w * .18,
				top: e.y + e.h * .18,
				width: e.w * .64,
				height: e.h * .64
			},
			children: /* @__PURE__ */ m(Q, { resource: t })
		}, n)), /* @__PURE__ */ m("div", {
			style: {
				position: "absolute",
				left: e.x + e.w * .17,
				top: e.y + e.h * .145,
				width: e.w * .66,
				height: e.h * .71,
				display: "flex",
				alignItems: "center",
				justifyContent: "center"
			},
			children: /* @__PURE__ */ m(Fe, { type: w[n].group })
		})]
	});
}
var rt = {
	place(e, t) {
		let n = e.data, r = n.stored === void 0 ? `tinytowns-cell:${e.rid}:${n.at}` : `tinytowns-stored:${e.rid}:${n.at}:${n.stored}`, i = t.anchor(r), a = t.anchor(n.from === void 0 ? `tinytowns-supply:${n.resource}${n.offer === void 0 ? "" : `:${n.offer}`}` : n.fromStored === void 0 ? `tinytowns-cell:${e.rid}:${n.from}` : `tinytowns-stored:${e.rid}:${n.from}:${n.fromStored}`);
		if (!a || !i) return null;
		let o = t.queued ? 130 : V.place, s = n.stored === void 0 ? {
			...i,
			x: i.x + i.w * .18,
			y: i.y + i.h * .18,
			w: i.w * .64,
			h: i.h * .64
		} : i, c = n.from !== void 0 && n.fromStored === void 0 ? {
			...a,
			x: a.x + a.w * .18,
			y: a.y + a.h * .18,
			w: a.w * .64,
			h: a.h * .64
		} : a;
		return {
			ms: o,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ m(g, {
				from: c,
				to: s,
				ms: o,
				children: /* @__PURE__ */ m("div", {
					style: {
						width: c.w,
						height: c.h
					},
					children: /* @__PURE__ */ m(Q, { resource: n.resource })
				})
			})
		};
	},
	build(e, t) {
		let n = e.data, r = `tinytowns-cell:${e.rid}:${n.at}`, i = t.anchor(r);
		if (!i) return null;
		let a = (n.consumed ?? []).flatMap((n) => {
			let r = t.anchor(`tinytowns-cell:${e.rid}:${n.at}`);
			return r ? [{
				from: r,
				resource: n.resource
			}] : [];
		}), o = t.queued ? 150 : V.build;
		if (!a.length) {
			let e = t.anchor(`tinytowns-card-piece:${n.id}`);
			if (e && e.w > 0 && e.h > 0) {
				let a = {
					x: e.x + 3,
					y: e.y + 3,
					w: e.w - 6,
					h: e.h - 6
				}, s = {
					x: i.x + i.w * .17,
					y: i.y + i.h * .145,
					w: i.w * .66,
					h: i.h * .71
				};
				return {
					ms: o,
					hide: t.queued ? [] : [r],
					node: /* @__PURE__ */ m(g, {
						from: a,
						to: s,
						ms: o,
						children: /* @__PURE__ */ m("div", {
							style: {
								width: a.w,
								height: a.h
							},
							children: /* @__PURE__ */ m(Fe, { type: w[n.id].group })
						})
					})
				};
			}
		}
		return {
			ms: o,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ m(nt, {
				to: i,
				parts: a,
				id: n.id,
				ms: o
			})
		};
	},
	name(e, t) {
		let n = e.data, r = t.anchor(`tinytowns-supply:${n.resource}`);
		return r ? {
			ms: V.reveal,
			node: /* @__PURE__ */ m(_, {
				at: r,
				ms: V.reveal
			})
		} : null;
	},
	cavern(e, t) {
		let n = e.data, r = t.anchor(`tinytowns-cavern:${e.rid}`), i = t.anchor(`tinytowns-supply:${n.resource}`);
		if (!r || !i) return null;
		let a = i;
		return {
			ms: V.place,
			node: /* @__PURE__ */ m(g, {
				from: a,
				to: {
					...r,
					x: r.x + r.w / 2 - 10,
					y: r.y + r.h / 2 - 10,
					w: 20,
					h: 20
				},
				ms: V.place,
				children: /* @__PURE__ */ m("div", {
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ m(Q, { resource: n.resource })
				})
			})
		};
	},
	finish(e, t) {
		let n = t.anchor(`tinytowns-town:${e.rid}`);
		return n ? {
			ms: V.reveal,
			node: /* @__PURE__ */ m(_, {
				at: n,
				ms: V.reveal
			})
		} : null;
	}
};
//#endregion
//#region src/games/tinytowns/game-over.tsx
function it(e) {
	let t = s(), n = e.public, [i, c] = o(!0), [u, d] = o(null), f = a(null), ee = a(null), te = a(null), g = e.result.winner ?? [], _ = (t) => e.members.find((e) => e.rid === t)?.name ?? t, ne = g.map(_).join("、"), v = n.players.length === 1, y = n.towns[0].score.total, b = y >= 38 ? 1 : y >= 32 ? 2 : y >= 25 ? 3 : y >= 18 ? 4 : y >= 10 ? 5 : 6, ie = [
		"games.tinytowns.soloRank1",
		"games.tinytowns.soloRank2",
		"games.tinytowns.soloRank3",
		"games.tinytowns.soloRank4",
		"games.tinytowns.soloRank5",
		"games.tinytowns.soloRank6"
	], x = n.towns.find((e) => g.includes(e.rid))?.monument ?? "cottage";
	r(() => {
		f.current?.focus();
	}, []);
	let S = (e) => {
		d(null), c(e), requestAnimationFrame(() => {
			(e ? f : ee).current?.focus();
		});
	}, C = () => {
		u === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(), d(null);
	};
	return /* @__PURE__ */ h("div", {
		className: "tinytowns tinytowns-result-wrap",
		children: [
			/* @__PURE__ */ m("div", {
				className: "tinytowns-result-board",
				inert: i,
				children: /* @__PURE__ */ m(Je, {
					...e,
					send: () => {}
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "tinytowns-result-overlay",
				hidden: !i,
				children: /* @__PURE__ */ h("section", {
					ref: te,
					className: "tinytowns-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.tinytowns.result"),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), u ? d(null) : S(!1)), e.key === "Tab") {
							let t = [...te.current?.querySelectorAll("button:not(:disabled)") ?? []].filter((e) => e.offsetParent !== null), n = t[0], r = t.at(-1);
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
						}
					},
					children: [
						/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("strong", { children: t("games.tinytowns.result") }), /* @__PURE__ */ m("button", {
							ref: f,
							type: "button",
							"aria-label": t("games.tinytowns.returnBoard"),
							onClick: () => S(!1),
							children: /* @__PURE__ */ m(l, { size: 20 })
						})] }),
						/* @__PURE__ */ h("div", {
							className: "tinytowns-result-body",
							inert: u !== null,
							children: [
								/* @__PURE__ */ h("div", {
									className: "tinytowns-result-heading",
									children: [/* @__PURE__ */ m("img", {
										src: p(`games/tinytowns/live/art-${w[x].art}.svg`),
										alt: ""
									}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("h1", { children: v ? t("games.tinytowns.soloResult") : t(g.length > 1 ? "games.tinytowns.tie" : "games.tinytowns.winner", { names: ne }) }), v && /* @__PURE__ */ m("p", {
										className: "tinytowns-result-subtitle",
										children: t(ie[b - 1])
									})] })]
								}),
								/* @__PURE__ */ m("div", {
									className: "tinytowns-score-scroll",
									tabIndex: 0,
									children: /* @__PURE__ */ h("table", {
										className: "tinytowns-score-table",
										style: { minWidth: n.players.length > 4 ? 80 + n.players.length * 64 : void 0 },
										"aria-label": t("games.tinytowns.score"),
										children: [
											/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
												scope: "col",
												children: t("games.tinytowns.score")
											}), n.players.map((e) => /* @__PURE__ */ h("th", {
												scope: "col",
												"data-winner": g.includes(e),
												children: [/* @__PURE__ */ m(Ue, { town: n.towns.find((t) => t.rid === e) }), /* @__PURE__ */ m("span", { children: _(e) })]
											}, e))] }) }),
											/* @__PURE__ */ h("tbody", { children: [re.map((e) => /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
												scope: "row",
												children: t(Ne[e])
											}), n.players.map((t) => /* @__PURE__ */ m("td", { children: n.towns.find((e) => e.rid === t).score[e] }, t))] }, e)), /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
												scope: "row",
												children: t("games.tinytowns.emptyPenalty")
											}), n.players.map((e) => /* @__PURE__ */ m("td", { children: n.towns.find((t) => t.rid === e).score.empty }, e))] })] }),
											/* @__PURE__ */ m("tfoot", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
												scope: "row",
												children: t("games.tinytowns.total")
											}), n.players.map((e) => /* @__PURE__ */ m("td", { children: n.towns.find((t) => t.rid === e).score.total }, e))] }) })
										]
									})
								}),
								/* @__PURE__ */ h("div", {
									className: "tinytowns-result-meta",
									children: [e.hintCount !== void 0 && /* @__PURE__ */ m("span", { children: t("games.tinytowns.hintCount", { n: e.hintCount }) }), n.players.filter((t) => !!e.result.autopilot?.[t]).map((n) => /* @__PURE__ */ h("span", { children: [
										_(n),
										" · ",
										t("games.tinytowns.autopilot", { n: Math.round(e.result.autopilot[n] * 100) })
									] }, n))]
								})
							]
						}),
						u ? /* @__PURE__ */ h("div", {
							className: "tinytowns-result-confirm",
							children: [
								/* @__PURE__ */ m("span", { children: t("games.tinytowns.endConfirm") }),
								/* @__PURE__ */ m("button", {
									type: "button",
									autoFocus: !0,
									onClick: C,
									children: t("games.tinytowns.confirm")
								}),
								/* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => d(null),
									children: t("games.tinytowns.cancel")
								})
							]
						}) : /* @__PURE__ */ h("footer", { children: [
							e.onBackToLobby && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => d("lobby"),
								children: t("session.result.backToLobby")
							}),
							e.onPlayAgain && /* @__PURE__ */ m("button", {
								type: "button",
								className: "tinytowns-primary",
								onClick: () => d("again"),
								children: t("session.result.playAgain")
							}),
							!e.onBackToLobby && !e.onPlayAgain && /* @__PURE__ */ m("span", { children: t("session.result.waitHost") })
						] })
					]
				})
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "tinytowns-result-restore",
				ref: ee,
				hidden: i,
				onClick: () => S(!0),
				children: t("games.tinytowns.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/tinytowns/options.tsx
function at({ value: e, onChange: t }) {
	let n = s(), r = D.safeParse(e), i = r.success ? r.data : D.parse(void 0);
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ m(v, {
				title: n("games.tinytowns.optMode"),
				children: ["master", "townHall"].map((e) => /* @__PURE__ */ m(ne, {
					name: "tinytowns-mode",
					value: e,
					checked: i.mode === e,
					label: n(e === "master" ? "games.tinytowns.masterMode" : "games.tinytowns.townHallMode"),
					accent: B.accent,
					onChange: () => t({
						...i,
						mode: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(v, {
				title: n("games.tinytowns.optBuildings"),
				children: ["first", "random"].map((e) => /* @__PURE__ */ m(ne, {
					name: "tinytowns-cards",
					value: e,
					checked: i.buildings === e,
					label: n(e === "first" ? "games.tinytowns.firstBuildings" : "games.tinytowns.randomBuildings"),
					accent: B.accent,
					onChange: () => t({
						...i,
						buildings: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(y, {
				checked: i.monuments,
				label: n("games.tinytowns.optMonuments"),
				accent: B.accent,
				onChange: () => t({
					...i,
					monuments: !i.monuments
				})
			}),
			/* @__PURE__ */ m(y, {
				checked: i.cavern,
				label: n("games.tinytowns.optCavern"),
				accent: B.accent,
				onChange: () => t({
					...i,
					cavern: !i.cavern
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tinytowns/entry.tsx
var ot = {
	definition: Ae,
	View: Je,
	bot: tt,
	fx: rt,
	OverView: it,
	Options: at,
	locales: {
		zh: {
			name: "小小城鎮",
			desc: "在四行四列城镇中巧用五种资源，拼出建筑配方，建设繁荣小镇。",
			round: "第 {{n}} 轮",
			nameResource: "指定一种资源",
			placeResource: "将资源放入城镇",
			buildPrompt: "选择建筑，再选择配方与落点",
			waiting: "等待其他玩家完成本轮",
			chooseMonument: "选择自己的纪念碑",
			ready: "完成本轮",
			finish: "完成城镇",
			completed: "城镇已完成",
			cancel: "取消",
			close: "关闭",
			confirm: "确认",
			skip: "放弃此效果",
			build: "建造",
			details: "查看卡牌",
			nextLayout: "下一组配方",
			previousLayout: "上一组配方",
			rotate: "旋转配方",
			mirror: "镜像配方",
			layout: "配方 {{n}} / {{total}}",
			noLayout: "尚无完整配方",
			selectTarget: "选择建筑落点",
			chooseMarker: "为建筑选定一种资源",
			cavern: "放入洞穴",
			cavernLeft: "洞穴余量 {{n}}",
			score: "得分",
			board: "{{name}}的城镇",
			cell: "第{{row}}行，第{{col}}列",
			empty: "空格",
			stored: "存储资源",
			warehouseStore: "存入仓库",
			warehouseSwap: "选择换出的资源",
			returnBoard: "回看城镇",
			showResult: "查看计分",
			result: "城镇档案",
			winner: "{{names}}获胜",
			tie: "{{names}}共同获胜",
			soloResult: "城镇建设完成",
			total: "总分",
			emptyPenalty: "空地",
			fed: "已供食",
			feed: "分配供食",
			feedPrompt: "选择获得供食的住宅",
			feedInvalid: "供食数量或范围不符合当前供食建筑的能力。",
			automatic: "自动分配",
			masterTurns: "担任建筑师",
			turns: "{{n}}次",
			monumentHidden: "未公开的纪念碑",
			monument: "纪念碑",
			privateCard: "仅自己可见",
			yourSeat: "你",
			placed: "已放置",
			buildingNow: "建造中",
			roundReady: "已完成本轮",
			watchPrompt: "选择3种不同建筑",
			watchTrigger: "邻居触发了瞭望塔，可放置对应建筑",
			grovePrompt: "在任意空格放置一座普通建筑",
			guildPrompt: "选择被替换的建筑，再选择新建筑",
			effectAt: "选择空格放置建筑",
			endConfirm: "确认结束本局并继续？",
			error: "当前无法执行此操作，请重新选择合法目标。",
			master: "建筑师",
			inspect: "查看城镇",
			optMode: "资源选择",
			masterMode: "轮流指定",
			townHallMode: "市政厅",
			optBuildings: "建筑组合",
			firstBuildings: "首次游玩推荐",
			randomBuildings: "随机组合",
			optMonuments: "纪念碑",
			monumentsOn: "使用纪念碑",
			monumentsOff: "不使用纪念碑",
			optCavern: "洞穴规则",
			cavernOn: "允许2次舍弃",
			cavernOff: "不使用洞穴",
			hintName: "指定{{resource}}。",
			hintPlace: "将{{resource}}放在第{{row}}行、第{{col}}列。",
			hintBuild: "在第{{row}}行、第{{col}}列建造{{name}}。",
			hintReady: "完成本轮。",
			hintMonument: "选择{{name}}。",
			hintEffect: "处理纪念碑的建造效果。",
			hintFinish: "完成城镇并结算得分。",
			hintCavern: "将本轮资源放入洞穴。",
			hintFeed: "分配住宅的供食。",
			resourceCard: "资源牌",
			soloRank1: "建筑大师",
			soloRank2: "城镇规划师",
			soloRank3: "工程师",
			soloRank4: "木匠",
			soloRank5: "建筑学徒",
			soloRank6: "见习建筑师",
			hintCount: "求助{{n}}次",
			autopilot: "托管{{n}}%",
			on: "启用",
			off: "关闭",
			resources: {
				wood: "木材",
				wheat: "麦子",
				brick: "砖块",
				glass: "玻璃",
				stone: "石料"
			},
			groups: {
				cottage: "住宅",
				food: "供食建筑",
				civic: "公共设施",
				faith: "宗教建筑",
				tavern: "酒馆建筑",
				trade: "商业建筑",
				industry: "工业建筑",
				monument: "纪念碑"
			},
			rules: "建设自己的小小城镇：\n每人拥有一块四行四列城镇。将木材、麦子、砖块、玻璃和石料摆成建筑牌上的配方，移除对应资源，建造建筑并争取得分。每局使用住宅，以及其他六类各一张建筑牌；随机组合会改变可用建筑。若启用纪念碑，每人从私有的两张牌中选择一张，只能建造一次，建成时才向所有人公开。\n\n每轮流程：\n建筑师指定一种资源，所有尚未完成城镇的玩家先将该资源放入一个空格，再自由决定是否建造建筑。所有玩家完成本轮后，建筑师顺时针传给下一位玩家。已完成城镇的玩家退出后续资源选择。只剩一位玩家时，该玩家可以继续自行指定资源，直到城镇完成。\n\n建造与建筑效果：\n配方可旋转和镜像，资源的相对位置及种类必须完全相符。每次移除完整配方的资源，再将建筑放在本次移除资源的一个格子上。资源不能自由移动，建筑不能任意移走或搬动；同轮可以依次建造多座建筑，也可以保留配方等待以后建造。棚屋、交易站、仓库、工厂及纪念碑的例外以对应卡牌详情为准。普通建筑和资源没有数量上限。“相邻”仅指上下左右，不含斜角；粮仓明确包含周围8格。\n\n住宅可先于供食建筑建造。最终计分时，各建筑的供食范围如下：\n· 农场：为任意位置的4座住宅供食。\n· 粮仓：为周围8格内的住宅供食。\n· 果园：为所在行和列的住宅供食。\n· 温室：为一组相连的住宅供食。\n每座住宅只需供食一次。可在城镇中调整供食分配；自动分配会选择得分最高的合法方案。未供食住宅不移除，但通常不获得住宅分。巴雷特城堡对于建筑计分视为2座住宅，供食时也占用两座住宅的容量。各建筑的完整计分与能力见卡牌详情。\n\n城镇完成与胜负：\n城镇已满时，可以继续使用完整配方建造，或选择完成城镇。本项目对银行作以下边界裁定：五座银行封禁全部资源后，轮到自己指定资源或市政厅自由选择轮时，可以完成城镇；其他玩家指定和资源牌抽取轮仍照常放置资源。所有城镇完成后，移除城镇格内的剩余资源；仓库中的资源保留并按牌面扣分。每个没有建筑的格子扣1分，已供食住宅每座3分，其他建筑与纪念碑分别计分，总分最高者获胜。平分依次比较担任建筑师次数较少、空格较少、住宅较多；仍相同则共同获胜。观星台按同轮完成共享名次计分。\n\n可选模式：\n洞穴规则：整局最多两次，可以不放置其他玩家指定的资源，将其放入洞穴；洞穴资源不计分也不扣分，自己指定的资源不能使用此能力。市政厅模式中可用于抽牌轮，不能用于每第三轮的自由选择；单人模式不使用洞穴。\n\n市政厅：将15张资源牌洗匀，背面弃掉5张。每个三轮循环，前两轮按翻出的牌放置资源，第三轮每人自行选择资源。牌堆耗尽时重新洗匀全部15张并再次弃5张。工厂、仓库和联结者雕像可用于抽牌轮；银行限制自由选择轮。铁草堡持有者跳过自由选择轮，独自留场时除外。\n\n单人：不使用旅店、银行、铁草堡及欧泊瞭望塔。15张资源牌洗匀后翻开3张，每轮从中选1张并放置对应资源。完成本轮后，将选中的牌放到牌堆底，补1张。工厂、仓库及联结者雕像可以作用于所选资源。最终38分以上为建筑大师，32–37为城镇规划师，25–31为工程师，18–24为木匠，10–17为建筑学徒，9分以下为见习建筑师。",
			cards: {
				warehouse: {
					name: "仓库",
					effect: "每座可存放3个资源。其他玩家指定资源时，可将其存入仓库，或用其交换仓库中的1个资源并将换出的资源放入空格。终局每个存储资源扣1分。"
				},
				tradingPost: {
					name: "交易站",
					effect: "每座1分。可在未来配方中代替任意资源，使用后保留。每次建造至少消耗1个真实资源，建筑不能放在交易站上。"
				},
				factory: {
					name: "工厂",
					effect: "建成时选定1种资源。其他玩家指定该资源时，可改放任意一种资源。"
				},
				bank: {
					name: "银行",
					effect: "每座4分。建成时选定一种尚未被自己其他银行选用的资源。自己担任建筑师时，不能指定银行上选定的资源。"
				},
				well: {
					name: "水井",
					effect: "每座与住宅相邻的边各得1分；住宅不必得到供食。"
				},
				shed: {
					name: "棚屋",
					effect: "每座1分。建成时可放在城镇任意空格，包括本次移除资源后空出的格子。"
				},
				millstone: {
					name: "磨盘",
					effect: "与供食建筑或商业建筑相邻时得2分，最多2分。"
				},
				fountain: {
					name: "喷泉",
					effect: "与另一座喷泉相邻时得2分，最多2分。"
				},
				theater: {
					name: "剧院",
					effect: "同一行或同一列中，每种其他建筑类型得1分；同一类型只计一次，不计剧院。"
				},
				tailor: {
					name: "裁缝铺",
					effect: "每座得1分，再加城镇中央4格中的裁缝铺数量；每座最多5分。"
				},
				market: {
					name: "市场",
					effect: "在其所在行或列中，选择市场较多的一侧，每座市场得1分，包含自身。"
				},
				bakery: {
					name: "面包坊",
					effect: "与供食建筑或工业建筑相邻时得3分。"
				},
				tavern: {
					name: "酒馆",
					effect: "城镇有1至5座酒馆时，共得2、5、9、14、20分。超过5座仍为20分。"
				},
				inn: {
					name: "旅店",
					effect: "所在行和列均没有其他旅店时得3分。单人模式不使用。"
				},
				feastHall: {
					name: "宴会厅",
					effect: "每座2分。如果自己的宴会厅数量多于右手边玩家，每座改得3分。"
				},
				almshouse: {
					name: "济贫院",
					effect: "城镇有1至6座时，共得−1、5、−3、15、−5、26分。超过6座仍为26分。"
				},
				orchard: {
					name: "果园",
					effect: "为与其同一行或同一列的全部住宅供食。"
				},
				greenhouse: {
					name: "温室",
					effect: "每座为一整组上下左右相连的住宅供食。这组住宅不必与温室相邻。"
				},
				granary: {
					name: "粮仓",
					effect: "为周围8格中的住宅供食，包含斜角。"
				},
				farm: {
					name: "农场",
					effect: "每座可为城镇任意位置的4座住宅供食。"
				},
				temple: {
					name: "神庙",
					effect: "与至少2座已供食住宅相邻时得4分。"
				},
				cloister: {
					name: "回廊",
					effect: "城镇四个角落中的每座回廊，使每座回廊得1分。"
				},
				chapel: {
					name: "礼拜堂",
					effect: "每座得分等于城镇中已供食住宅的数量。"
				},
				abbey: {
					name: "修道院",
					effect: "不与住宅、商业或工业建筑相邻时得3分。"
				},
				cottage: {
					name: "住宅",
					effect: "已供食时每座3分，未供食时0分；未供食住宅仍留在城镇中。"
				},
				silvaForum: {
					name: "席尔瓦广场",
					effect: "得1分，再加城镇内最大一组同类型相连建筑的数量。"
				},
				elderTree: {
					name: "古树神龛",
					effect: "建成时，城镇共有1至6座建筑，分别锁定1、2、3、4、5、8分；更多建筑仍为8分。包含自身。"
				},
				opaleye: {
					name: "欧泊瞭望塔",
					effect: "建成时选3种不同普通建筑。左右相邻玩家建造其中一种时，将对应建筑从此牌移到自己任意空格，每种只能触发一次。"
				},
				obelisk: {
					name: "新月方尖碑",
					effect: "此后建造的建筑均可放在城镇任意空格。"
				},
				mandrasPalace: {
					name: "曼德拉斯宫",
					effect: "每种与其相邻的不同建筑类型得2分。"
				},
				groveUniversity: {
					name: "林地大学",
					effect: "得3分。建成后，立即在任意空格放置一座普通建筑。"
				},
				mausoleum: {
					name: "罗迪纳大陵墓",
					effect: "未供食住宅每座也得3分。"
				},
				fortIronweed: {
					name: "铁草堡",
					effect: "得7分。此后不再担任建筑师，除非只剩自己尚未完成城镇。市政厅每第三轮也跳过个人资源，独自留场时除外。"
				},
				cathedralCaterina: {
					name: "卡特琳娜大教堂",
					effect: "得2分。自己城镇的空格不再扣分。"
				},
				barrettCastle: {
					name: "巴雷特城堡",
					effect: "已供食时得5分。对于所有建筑计分，视为2座住宅，不视为纪念碑类型。"
				},
				archive: {
					name: "第二纪元档案馆",
					effect: "城镇中每种不同普通建筑类型得1分，不计纪念碑类型。"
				},
				architectGuild: {
					name: "建筑师公会",
					effect: "得1分。建成时可将至多2座普通建筑分别替换为其他普通建筑，不能选纪念碑；未使用的次数不能保留。"
				},
				starloom: {
					name: "观星台",
					effect: "按城镇完成名次得分：第1名6分、第2名3分、第3名2分，其后0分。同轮完成者共享对应名次分数。"
				},
				skyBaths: {
					name: "天空浴场",
					effect: "城镇每缺少一种建筑类型得2分。包含普通建筑类型及纪念碑类型。"
				},
				bondmaker: {
					name: "联结者雕像",
					effect: "其他玩家指定资源时，可将其放在一座住宅上。每座住宅限存1个资源，该资源不能用于建造。"
				}
			}
		},
		en: {
			name: "Tiny Towns",
			desc: "Arrange five resources into building patterns on a 4×4 grid and create a thriving little town.",
			round: "Round {{n}}",
			nameResource: "Name a resource",
			placeResource: "Place a resource in your town",
			buildPrompt: "Choose a building, layout, and destination",
			waiting: "Waiting for the other players",
			chooseMonument: "Choose your monument",
			ready: "Finish round",
			finish: "Complete town",
			completed: "Town complete",
			cancel: "Cancel",
			close: "Close",
			confirm: "Confirm",
			skip: "Decline this benefit",
			build: "Construct",
			details: "Card details",
			nextLayout: "Next layout",
			previousLayout: "Previous layout",
			rotate: "Rotate pattern",
			mirror: "Mirror pattern",
			layout: "Layout {{n}} / {{total}}",
			noLayout: "No complete layout yet",
			selectTarget: "Choose the building destination",
			chooseMarker: "Assign a resource to this building",
			cavern: "Use cavern",
			cavernLeft: "Cavern spaces: {{n}}",
			score: "Score",
			board: "{{name}}’s town",
			cell: "Row {{row}}, column {{col}}",
			empty: "Empty square",
			stored: "Stored resources",
			warehouseStore: "Store in Warehouse",
			warehouseSwap: "Choose a resource to exchange",
			returnBoard: "View towns",
			showResult: "Show scores",
			result: "Town records",
			winner: "{{names}} wins",
			tie: "{{names}} share victory",
			soloResult: "Your town is complete",
			total: "Total",
			emptyPenalty: "Empty squares",
			fed: "Fed",
			feed: "Allocate food",
			feedPrompt: "Choose cottages to feed",
			feedInvalid: "These cottages exceed the capacity or reach of your food buildings.",
			automatic: "Automatic allocation",
			masterTurns: "Master Builder",
			turns: "{{n}} turns",
			monumentHidden: "Secret monument",
			monument: "Monument",
			privateCard: "Only visible to you",
			yourSeat: "You",
			placed: "Placed",
			buildingNow: "Building",
			roundReady: "Round finished",
			watchPrompt: "Choose 3 distinct buildings",
			watchTrigger: "Your neighbor triggered the Watch; place its building",
			grovePrompt: "Place a regular building in an empty square",
			guildPrompt: "Choose a building to replace and its replacement",
			effectAt: "Choose an empty square for the building",
			endConfirm: "End this game and continue?",
			error: "This action is not available. Choose a legal target again.",
			master: "Master Builder",
			inspect: "View town",
			optMode: "Resource selection",
			masterMode: "Take turns naming",
			townHallMode: "Town Hall",
			optBuildings: "Building selection",
			firstBuildings: "Recommended first game",
			randomBuildings: "Random selection",
			optMonuments: "Monuments",
			monumentsOn: "Use monuments",
			monumentsOff: "No monuments",
			optCavern: "Cavern rule",
			cavernOn: "Allow 2 discards",
			cavernOff: "No cavern",
			hintName: "Name {{resource}}.",
			hintPlace: "Place {{resource}} in row {{row}}, column {{col}}.",
			hintBuild: "Construct {{name}} in row {{row}}, column {{col}}.",
			hintReady: "Finish this round.",
			hintMonument: "Choose {{name}}.",
			hintEffect: "Resolve the monument’s construction benefit.",
			hintFinish: "Complete your town and score it.",
			hintCavern: "Place this resource in your cavern.",
			hintFeed: "Allocate food to your cottages.",
			resourceCard: "Resource card",
			soloRank1: "Master Architect",
			soloRank2: "Town Planner",
			soloRank3: "Engineer",
			soloRank4: "Carpenter",
			soloRank5: "Builder’s Apprentice",
			soloRank6: "Aspiring Architect",
			hintCount: "{{n}} hints used",
			autopilot: "{{n}}% autopilot",
			on: "On",
			off: "Off",
			resources: {
				wood: "Wood",
				wheat: "Wheat",
				brick: "Brick",
				glass: "Glass",
				stone: "Stone"
			},
			groups: {
				cottage: "Cottages",
				food: "Food",
				civic: "Civic",
				faith: "Religious",
				tavern: "Taverns",
				trade: "Trade",
				industry: "Industry",
				monument: "Monument"
			},
			rules: "Build your Tiny Town:\nEach player has a 4×4 town. Arrange wood, wheat, brick, glass, and stone into the patterns on building cards, then replace the resources with buildings. Use Cottage and one card from each of six other building types. Random selection changes the available buildings. With monuments enabled, privately choose one of two cards; only its owner may build it, once, and reveal it when constructed.\n\nEach round:\nThe Master Builder names one resource. Every active player must first place it in an empty square, then may construct buildings. After all players finish, pass the hammer clockwise. Completed players leave future resource rounds. The final active player continues naming resources until their town is complete.\n\nConstruction and abilities:\nPatterns may be rotated and mirrored. Resource types and relative positions must match exactly. Remove the full pattern, then place the building on one of the cleared squares. Resources cannot move freely, and buildings cannot be moved or removed without an ability. You may construct several buildings sequentially or save patterns for later. Shed, Trading Post, Warehouse, Factory, and monuments have the exceptions detailed on their cards. Resources and regular buildings are unlimited. Adjacent means orthogonal, except Granary explicitly covers all 8 surrounding squares.\n\nCottages may be built before food buildings. At scoring, food buildings feed cottages as follows:\n· Farm: Feed 4 cottages anywhere.\n· Granary: Feed cottages in the surrounding squares.\n· Orchard: Feed cottages in its row and column.\n· Greenhouse: Feed one connected cottage group.\nA cottage only needs feeding once. Food allocation can be changed in the town; automatic allocation chooses a highest-scoring legal allocation. Unfed cottages stay on the board but normally score no cottage points. Barrett Castle counts as 2 cottages for building scoring and uses two cottage units of food capacity. See each card for complete abilities and scoring.\n\nCompleting towns and winning:\nWhen full, construct available patterns or complete your town. This implementation uses the following Bank edge-case ruling: if five Banks prohibit all resources, you may complete your town when naming a resource yourself or in a Town Hall choice round. Resources named by others or drawn from cards can still be placed normally. Once all towns are complete, remove remaining resources from town squares; keep stored Warehouse resources and score their penalties. Each square without a building scores −1. Fed cottages score 3 each, and other buildings and monuments score by their cards. Highest total wins. Break ties by fewer Master Builder turns, then fewer empty squares, then more cottages; otherwise share victory. The Starloom gives players completing in the same round the same finishing place.\n\nOptional modes:\nCavern: twice per game, discard a resource named by another player instead of placing it. These resources score neither points nor penalties. You cannot discard your own named resource. In Town Hall this applies to drawn-resource rounds, not free-choice rounds. Do not use Cavern in solo play.\n\nTown Hall: shuffle the 15 resource cards and discard 5 unseen. In each three-round cycle, draw a resource in the first two rounds; in the third, everyone chooses individually. When the deck runs out, reshuffle all 15 and discard 5 again. Factory, Warehouse, and Statue of the Bondmaker apply to drawn rounds. Banks restrict choice rounds. Fort Ironweed skips choice rounds unless its owner is the final active player.\n\nSolo: exclude Inn, Bank, Fort Ironweed, and Opaleye’s Watch. Shuffle 15 resource cards and reveal 3. Each round choose one to place. After finishing the round, put the selected card on the bottom of the deck and replace it with the top card. Factory, Warehouse, and Statue of the Bondmaker apply to the selected resource. Score 38+ for Master Architect, 32–37 Town Planner, 25–31 Engineer, 18–24 Carpenter, 10–17 Builder’s Apprentice, and 9 or less Aspiring Architect.",
			cards: {
				warehouse: {
					name: "Warehouse",
					effect: "Holds 3 resources. When another player names a resource, store it here or exchange it for a stored resource, placing that resource in an empty square. Each stored resource scores −1."
				},
				tradingPost: {
					name: "Trading Post",
					effect: "1 point. Acts as a wild resource in future layouts and remains in place. A build must use at least 1 real resource and cannot occupy the Trading Post."
				},
				factory: {
					name: "Factory",
					effect: "When constructed, select a resource. When another player names that resource, you may place a different resource instead."
				},
				bank: {
					name: "Bank",
					effect: "4 points. Assign a resource not assigned to another Bank in your town. You cannot name that resource as Master Builder."
				},
				well: {
					name: "Well",
					effect: "1 point for each adjacent cottage, fed or unfed."
				},
				shed: {
					name: "Shed",
					effect: "1 point. May be constructed on any empty square in your town, including a square just cleared by this build."
				},
				millstone: {
					name: "Millstone",
					effect: "2 points if adjacent to a food or trade building; at most 2 points."
				},
				fountain: {
					name: "Fountain",
					effect: "2 points if adjacent to another Fountain; at most 2 points."
				},
				theater: {
					name: "Theater",
					effect: "1 point per other unique building type in the same row and column. Do not count Theaters; count each type once."
				},
				tailor: {
					name: "Tailor",
					effect: "1 point, plus 1 point for each Tailor in the 4 center squares, to a maximum of 5 per Tailor."
				},
				market: {
					name: "Market",
					effect: "1 point per Market in its row or column, whichever is greater, including itself."
				},
				bakery: {
					name: "Bakery",
					effect: "3 points if adjacent to a food or industry building."
				},
				tavern: {
					name: "Tavern",
					effect: "1–5 Taverns score 2, 5, 9, 14, or 20 points total. More than 5 still score 20."
				},
				inn: {
					name: "Inn",
					effect: "3 points if no other Inn is in the same row or column. Excluded in solo play."
				},
				feastHall: {
					name: "Feast Hall",
					effect: "2 points each, or 3 each if you have more Feast Halls than the player to your right."
				},
				almshouse: {
					name: "Almshouse",
					effect: "1–6 Almshouses score −1, 5, −3, 15, −5, or 26 points total. More than 6 still score 26."
				},
				orchard: {
					name: "Orchard",
					effect: "Feeds all cottages in the same row and column."
				},
				greenhouse: {
					name: "Greenhouse",
					effect: "Feeds 1 contiguous group of orthogonally connected cottages anywhere in your town."
				},
				granary: {
					name: "Granary",
					effect: "Feeds all cottages in the 8 surrounding squares, including diagonals."
				},
				farm: {
					name: "Farm",
					effect: "Feeds up to 4 cottages anywhere in your town."
				},
				temple: {
					name: "Temple",
					effect: "4 points if adjacent to at least 2 fed cottages."
				},
				cloister: {
					name: "Cloister",
					effect: "1 point for each Cloister in a corner of your town, scored by every Cloister."
				},
				chapel: {
					name: "Chapel",
					effect: "1 point for every fed cottage in your town."
				},
				abbey: {
					name: "Abbey",
					effect: "3 points if not adjacent to a cottage, trade building, or industry building."
				},
				cottage: {
					name: "Cottage",
					effect: "3 points if fed, otherwise 0. Unfed cottages remain in your town."
				},
				silvaForum: {
					name: "Silva Forum",
					effect: "1 point, plus 1 per building in your largest orthogonally connected group of one building type."
				},
				elderTree: {
					name: "Shrine of the Elder Tree",
					effect: "Locks in 1, 2, 3, 4, 5, or 8 points when built as your 1st–6th building. Later builds still score 8; include this monument."
				},
				opaleye: {
					name: "Opaleye’s Watch",
					effect: "Choose 3 distinct regular building types when built. When either neighboring player builds one, place its building in any empty square of your town; each choice triggers once."
				},
				obelisk: {
					name: "Obelisk of the Crescent",
					effect: "All future buildings may be placed on any empty square in your town."
				},
				mandrasPalace: {
					name: "Mandras Palace",
					effect: "2 points for each unique adjacent building type."
				},
				groveUniversity: {
					name: "Grove University",
					effect: "3 points. When constructed, immediately place a regular building on any empty square."
				},
				mausoleum: {
					name: "Grand Mausoleum of the Rodina",
					effect: "Your unfed cottages are worth 3 points each."
				},
				fortIronweed: {
					name: "Fort Ironweed",
					effect: "7 points. You no longer act as Master Builder unless you are the last active player. Also skip Town Hall choice rounds unless you are alone."
				},
				cathedralCaterina: {
					name: "Cathedral of Caterina",
					effect: "2 points. Empty squares in your town score 0 instead of −1."
				},
				barrettCastle: {
					name: "Barrett Castle",
					effect: "5 points if fed. Counts as 2 cottages rather than a monument for all building scoring."
				},
				archive: {
					name: "Archive of the Second Age",
					effect: "1 point for each unique building type in your town other than monument."
				},
				architectGuild: {
					name: "Architect’s Guild",
					effect: "1 point. Immediately replace up to 2 regular buildings with other regular building types. Neither may be a monument; unused replacements cannot be saved."
				},
				starloom: {
					name: "The Starloom",
					effect: "Scores 6, 3, 2, or 0 points for finishing 1st, 2nd, 3rd, or later. Players finishing in the same round share that placing."
				},
				skyBaths: {
					name: "The Sky Baths",
					effect: "2 points for each building type missing from your town, including regular types and monument."
				},
				bondmaker: {
					name: "Statue of the Bondmaker",
					effect: "When another player names a resource, you may place it on a cottage. Each cottage holds 1 resource, which cannot be used in a building layout."
				}
			}
		}
	}
};
//#endregion
export { ot as default };
