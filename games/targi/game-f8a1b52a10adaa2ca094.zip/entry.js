import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { seatName as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Floater as m, FlySprite as h } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as g } from "@bgparty/sdk/confirm-button";
import { OptionSwitch as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/targi/data.ts
var v = [
	"games.targi.date",
	"games.targi.salt",
	"games.targi.pepper",
	"games.targi.gold",
	"games.targi.water"
], y = [
	"oasis",
	"rider",
	"camp",
	"well",
	"targia"
], b = () => [
	0,
	0,
	0,
	0,
	0
], x = (e) => {
	let t = b();
	for (let n of e) {
		let e = "dspgw".indexOf(n);
		e >= 0 && t[e]++;
	}
	return t;
}, S = (e) => e[0] + e[1] + e[2], C = (e, t) => e.every((e, n) => e >= t[n]), ee = [
	[0, 1],
	[0, 2],
	[0, 3],
	[0, 4],
	[1, 4],
	[2, 4],
	[3, 4],
	[4, 4],
	[4, 3],
	[4, 2],
	[4, 1],
	[4, 0],
	[3, 0],
	[2, 0],
	[1, 0],
	[0, 0]
], w = {
	0: 10,
	1: 9,
	2: 8,
	4: 14,
	5: 13,
	6: 12,
	8: 2,
	9: 1,
	10: 0,
	12: 6,
	13: 5,
	14: 4
}, T = {
	1: 0,
	2: 1,
	5: 2,
	6: 0,
	10: 2,
	14: 1
}, E = (e) => e % 4 == 3, D = (e) => {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set();
	for (let r of e.filter((e) => e >= 0)) {
		let [e, i] = ee[r];
		e === 0 || e === 4 ? n.add(i) : t.add(e);
	}
	return [...t].flatMap((e) => [...n].map((t) => (e - 1) * 3 + t - 1));
}, te = [
	"joker",
	"targi",
	"marker",
	"waiver"
], ne = [
	"ss",
	"s",
	"dd",
	"g",
	"g",
	"p",
	"g",
	"v",
	"d",
	"pp",
	"?",
	"sd",
	"?",
	"d",
	"s",
	"?",
	"p",
	"dp",
	"ps"
], O = [
	"w",
	"ww/g",
	"ww",
	"w/v",
	"w"
], k = (e) => (e.startsWith("w") ? O[Number(e.slice(1))] : ne[Number(e.slice(1))]).split("/"), A = (e) => j[e], re = (e) => e === "wild" || !A(e)?.effect, j = {
	b0: {
		id: "b0",
		group: "oasis",
		vp: 1,
		costs: ["pg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b0",
		textKey: "games.targi.effects.b0"
	},
	b1: {
		id: "b1",
		group: "rider",
		vp: 3,
		costs: ["dppss"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b2: {
		id: "b2",
		group: "oasis",
		vp: 1,
		costs: ["spg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b2",
		textKey: "games.targi.effects.b2"
	},
	b3: {
		id: "b3",
		group: "rider",
		vp: 3,
		costs: ["dsg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b4: {
		id: "b4",
		group: "rider",
		vp: 1,
		costs: ["sg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b4",
		textKey: "games.targi.effects.b4"
	},
	b5: {
		id: "b5",
		group: "rider",
		vp: 2,
		costs: ["ssddp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b5",
		textKey: "games.targi.effects.b5"
	},
	b6: {
		id: "b6",
		group: "oasis",
		vp: 1,
		costs: ["ssp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b6",
		textKey: "games.targi.effects.b6"
	},
	b7: {
		id: "b7",
		group: "well",
		vp: 2,
		costs: ["psg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b7",
		textKey: "games.targi.effects.b7"
	},
	b8: {
		id: "b8",
		group: "targia",
		vp: 2,
		costs: ["sdpp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b8",
		textKey: "games.targi.effects.b8"
	},
	b9: {
		id: "b9",
		group: "camp",
		vp: 2,
		costs: ["sdpp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b9",
		textKey: "games.targi.effects.b9"
	},
	b10: {
		id: "b10",
		group: "camp",
		vp: 3,
		costs: ["pddss"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b11: {
		id: "b11",
		group: "targia",
		vp: 2,
		costs: ["ddg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b11",
		textKey: "games.targi.effects.b11"
	},
	b12: {
		id: "b12",
		group: "targia",
		vp: 1,
		costs: ["ppg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b12",
		textKey: "games.targi.effects.b12"
	},
	b13: {
		id: "b13",
		group: "rider",
		vp: 1,
		costs: ["g"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b13",
		textKey: "games.targi.effects.b13"
	},
	b14: {
		id: "b14",
		group: "well",
		vp: 1,
		costs: ["sg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b14",
		textKey: "games.targi.effects.b14"
	},
	b15: {
		id: "b15",
		group: "oasis",
		vp: 2,
		costs: ["dpg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b15",
		textKey: "games.targi.effects.b15"
	},
	b16: {
		id: "b16",
		group: "oasis",
		vp: 3,
		costs: ["sdg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b17: {
		id: "b17",
		group: "oasis",
		vp: 1,
		costs: ["ssp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b17",
		textKey: "games.targi.effects.b17"
	},
	b18: {
		id: "b18",
		group: "targia",
		vp: 2,
		costs: ["dspp"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b19: {
		id: "b19",
		group: "oasis",
		vp: 2,
		costs: ["spg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b19",
		textKey: "games.targi.effects.b19"
	},
	b20: {
		id: "b20",
		group: "camp",
		vp: 1,
		costs: ["pd"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b20",
		textKey: "games.targi.effects.b20"
	},
	b21: {
		id: "b21",
		group: "camp",
		vp: 1,
		costs: ["dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b21",
		textKey: "games.targi.effects.b21"
	},
	b22: {
		id: "b22",
		group: "camp",
		vp: 1,
		costs: ["dpp", "g"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b22",
		textKey: "games.targi.effects.b22"
	},
	b23: {
		id: "b23",
		group: "camp",
		vp: 1,
		costs: ["dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b23",
		textKey: "games.targi.effects.b23"
	},
	b24: {
		id: "b24",
		group: "camp",
		vp: 3,
		costs: ["pdg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b25: {
		id: "b25",
		group: "well",
		vp: 2,
		costs: ["spdd"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b26: {
		id: "b26",
		group: "well",
		vp: 1,
		costs: ["ssd"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b26",
		textKey: "games.targi.effects.b26"
	},
	b27: {
		id: "b27",
		group: "targia",
		vp: 1,
		costs: ["dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b27",
		textKey: "games.targi.effects.b27"
	},
	b28: {
		id: "b28",
		group: "targia",
		vp: 3,
		costs: ["dsspp"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b29: {
		id: "b29",
		group: "rider",
		vp: 2,
		costs: ["dpss"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b30: {
		id: "b30",
		group: "targia",
		vp: 1,
		costs: ["ssd", "g"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b30",
		textKey: "games.targi.effects.b30"
	},
	b31: {
		id: "b31",
		group: "oasis",
		vp: 3,
		costs: ["sppdd"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b32: {
		id: "b32",
		group: "well",
		vp: 3,
		costs: ["sdg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b33: {
		id: "b33",
		group: "rider",
		vp: 2,
		costs: ["ppg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b33",
		textKey: "games.targi.effects.b33"
	},
	b34: {
		id: "b34",
		group: "camp",
		vp: 2,
		costs: ["dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b34",
		textKey: "games.targi.effects.b34"
	},
	b35: {
		id: "b35",
		group: "well",
		vp: 1,
		costs: ["dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b35",
		textKey: "games.targi.effects.b35"
	},
	b36: {
		id: "b36",
		group: "well",
		vp: 2,
		costs: ["ssdp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b36",
		textKey: "games.targi.effects.b36"
	},
	b37: {
		id: "b37",
		group: "well",
		vp: 1,
		costs: ["dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b37",
		textKey: "games.targi.effects.b37"
	},
	b38: {
		id: "b38",
		group: "camp",
		vp: 2,
		costs: ["pg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b39: {
		id: "b39",
		group: "rider",
		vp: 1,
		costs: ["dds"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b39",
		textKey: "games.targi.effects.b39"
	},
	b40: {
		id: "b40",
		group: "targia",
		vp: 3,
		costs: ["dpg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b41: {
		id: "b41",
		group: "rider",
		vp: 1,
		costs: ["g"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b41",
		textKey: "games.targi.effects.b41"
	},
	b42: {
		id: "b42",
		group: "targia",
		vp: 1,
		costs: ["pg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "b42",
		textKey: "games.targi.effects.b42"
	},
	b43: {
		id: "b43",
		group: "oasis",
		vp: 2,
		costs: ["pg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	b44: {
		id: "b44",
		group: "well",
		vp: 3,
		costs: ["sppdd"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e0: {
		id: "e0",
		group: "oasis",
		vp: 2,
		costs: ["pww", "ppss"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e1: {
		id: "e1",
		group: "oasis",
		vp: 1,
		costs: ["pg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e1",
		textKey: "games.targi.effects.e1"
	},
	e2: {
		id: "e2",
		group: "rider",
		vp: 2,
		costs: ["sww", "sspd"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e3: {
		id: "e3",
		group: "rider",
		vp: 2,
		costs: ["g"],
		bonusCost: "sss",
		bonusVp: 2,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e4: {
		id: "e4",
		group: "well",
		vp: 1,
		costs: ["ssdd"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e4",
		textKey: "games.targi.effects.e4"
	},
	e5: {
		id: "e5",
		group: "camp",
		vp: 3,
		costs: ["psww", "psg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e6: {
		id: "e6",
		group: "well",
		vp: 1,
		costs: ["pg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e6",
		textKey: "games.targi.effects.e6"
	},
	e7: {
		id: "e7",
		group: "camp",
		vp: 1,
		costs: ["dsp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e7",
		textKey: "games.targi.effects.e7"
	},
	e8: {
		id: "e8",
		group: "targia",
		vp: 1,
		costs: ["ssdd", "dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e8",
		textKey: "games.targi.effects.e8"
	},
	e9: {
		id: "e9",
		group: "targia",
		vp: 2,
		costs: ["pppds"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e9",
		textKey: "games.targi.effects.e9"
	},
	e10: {
		id: "e10",
		group: "oasis",
		vp: 1,
		costs: ["dsp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e10",
		textKey: "games.targi.effects.e10"
	},
	e11: {
		id: "e11",
		group: "camp",
		vp: 2,
		costs: ["g"],
		bonusCost: "ppp",
		bonusVp: 2,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e12: {
		id: "e12",
		group: "well",
		vp: 2,
		costs: ["spg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e12",
		textKey: "games.targi.effects.e12"
	},
	e13: {
		id: "e13",
		group: "oasis",
		vp: 1,
		costs: ["spg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e13",
		textKey: "games.targi.effects.e13"
	},
	e14: {
		id: "e14",
		group: "oasis",
		vp: 1,
		costs: ["dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e14",
		textKey: "games.targi.effects.e14"
	},
	e15: {
		id: "e15",
		group: "oasis",
		vp: 3,
		costs: ["ddww", "ddg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e16: {
		id: "e16",
		group: "well",
		vp: 1,
		costs: ["sppp", "sg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e16",
		textKey: "games.targi.effects.e16"
	},
	e17: {
		id: "e17",
		group: "camp",
		vp: 1,
		costs: ["dssp", "sg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e17",
		textKey: "games.targi.effects.e17"
	},
	e18: {
		id: "e18",
		group: "rider",
		vp: 1,
		costs: ["pdss"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e18",
		textKey: "games.targi.effects.e18"
	},
	e19: {
		id: "e19",
		group: "camp",
		vp: 1,
		costs: ["ddp", "g"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e19",
		textKey: "games.targi.effects.e19"
	},
	e20: {
		id: "e20",
		group: "targia",
		vp: 1,
		costs: ["psg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e20",
		textKey: "games.targi.effects.e20"
	},
	e21: {
		id: "e21",
		group: "targia",
		vp: 1,
		costs: ["sg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e21",
		textKey: "games.targi.effects.e21"
	},
	e22: {
		id: "e22",
		group: "oasis",
		vp: 1,
		costs: ["dsp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e22",
		textKey: "games.targi.effects.e22"
	},
	e23: {
		id: "e23",
		group: "targia",
		vp: 1,
		costs: ["dsp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e23",
		textKey: "games.targi.effects.e23"
	},
	e24: {
		id: "e24",
		group: "targia",
		vp: 1,
		costs: ["ssg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e24",
		textKey: "games.targi.effects.e24"
	},
	e25: {
		id: "e25",
		group: "camp",
		vp: 1,
		costs: ["pdds"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e25",
		textKey: "games.targi.effects.e25"
	},
	e26: {
		id: "e26",
		group: "well",
		vp: 1,
		costs: ["ddg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e26",
		textKey: "games.targi.effects.e26"
	},
	e27: {
		id: "e27",
		group: "rider",
		vp: 2,
		costs: ["pppd"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e27",
		textKey: "games.targi.effects.e27"
	},
	e28: {
		id: "e28",
		group: "rider",
		vp: 1,
		costs: ["sssd", "sg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e28",
		textKey: "games.targi.effects.e28"
	},
	e29: {
		id: "e29",
		group: "rider",
		vp: 1,
		costs: ["dg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e29",
		textKey: "games.targi.effects.e29"
	},
	e30: {
		id: "e30",
		group: "rider",
		vp: 1,
		costs: ["pg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e30",
		textKey: "games.targi.effects.e30"
	},
	e31: {
		id: "e31",
		group: "well",
		vp: 2,
		costs: ["sww", "spdd"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e32: {
		id: "e32",
		group: "oasis",
		vp: 2,
		costs: ["g"],
		bonusCost: "dps",
		bonusVp: 2,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e33: {
		id: "e33",
		group: "well",
		vp: 1,
		costs: ["dsp"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e33",
		textKey: "games.targi.effects.e33"
	},
	e34: {
		id: "e34",
		group: "well",
		vp: 3,
		costs: ["pdww", "pdg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e35: {
		id: "e35",
		group: "oasis",
		vp: 2,
		costs: ["pddss"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e35",
		textKey: "games.targi.effects.e35"
	},
	e36: {
		id: "e36",
		group: "well",
		vp: 2,
		costs: ["g"],
		bonusCost: "dps",
		bonusVp: 2,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e37: {
		id: "e37",
		group: "targia",
		vp: 2,
		costs: ["dww", "ddpp"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e38: {
		id: "e38",
		group: "camp",
		vp: 2,
		costs: ["dww", "dpss"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e39: {
		id: "e39",
		group: "targia",
		vp: 3,
		costs: ["pdww", "pdg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e40: {
		id: "e40",
		group: "targia",
		vp: 2,
		costs: ["g"],
		bonusCost: "ddd",
		bonusVp: 2,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e41: {
		id: "e41",
		group: "rider",
		vp: 3,
		costs: ["ddww", "ddg"],
		bonusCost: "",
		bonusVp: 0,
		effect: null,
		textKey: "games.targi.noAbility"
	},
	e42: {
		id: "e42",
		group: "camp",
		vp: 1,
		costs: ["pg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e42",
		textKey: "games.targi.effects.e42"
	},
	e43: {
		id: "e43",
		group: "rider",
		vp: 1,
		costs: ["ppg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e43",
		textKey: "games.targi.effects.e43"
	},
	e44: {
		id: "e44",
		group: "camp",
		vp: 2,
		costs: ["pdg"],
		bonusCost: "",
		bonusVp: 0,
		effect: "e44",
		textKey: "games.targi.effects.e44"
	}
}, M = (e) => e.rows.flat(), N = (e, t) => e.waived !== t && M(e).includes(t), P = (e, t) => N(e, t) && !e.used.includes(t), F = (e, t) => e.players.find((e) => e.rid !== t.rid), I = (e) => e.players.find((t) => t.rid === e.turn), ie = (e, t) => {
	for (let n = 0; n < 5; n++) e.bag[n] -= t[n];
}, L = (e, t) => {
	for (let n = 0; n < 5; n++) e.bag[n] += t[n];
};
function R(e, t = "control", n = [], r = "", i = b(), a = b(), o = 0) {
	return {
		id: [
			e,
			t,
			r,
			...n,
			i.join(","),
			a.join(","),
			o
		].join(":"),
		kind: e,
		target: t,
		args: n,
		card: r,
		pay: i,
		gain: a,
		vp: o
	};
}
var z = (e, ...t) => {
	e.tasks.unshift(...t);
}, B = (e, ...t) => {
	e.tasks.push(...t);
}, V = (e = 1) => ({
	kind: "gain",
	n: e
}), ae = (e) => !!e && [
	"drawTribe",
	"goods",
	"reward",
	"roundGood",
	"raidBonus",
	"postRaid",
	"startActions",
	"startPlacement"
].includes(e.kind);
function oe(e, t, n, r) {
	let i = A(t);
	if (!i) return [];
	let a = [], o = {
		oasis: "b6",
		camp: "b22",
		well: "b26",
		targia: "b30",
		rider: "b41"
	};
	for (let t of r ? [r] : i.costs) {
		let s = [x(t)], c = Number(N(e, o[i.group])) + Number(n === "noble" && N(e, "b34"));
		for (let e = 0; e < c && !r; e++) s = s.flatMap((e) => S(e) ? [
			0,
			1,
			2
		].filter((t) => e[t] > 0).map((t) => {
			let n = [...e];
			return n[t]--, n;
		}) : [e]);
		n === "freehand" && (s = s.flatMap((e) => [
			0,
			1,
			2
		].filter((e) => x(t)[e] > 0).map((t) => {
			let n = [...e];
			return n[t]++, n;
		}))), n === "noble" && N(e, "e25") && (s = s.flatMap((e) => e[3] ? [e, ...[
			0,
			1,
			2
		].map((t) => {
			let n = [...e];
			return n[3]--, n[4]++, n[t]++, n;
		})] : [e]));
		for (let t of s) for (let n of i.bonusCost && !r ? [!1, !0] : [!1]) {
			let r = [...t];
			n && L({ bag: r }, x(i.bonusCost));
			for (let t of r[3] && (e.cache.b35 ?? 0) > 0 && N(e, "b35") ? [0, 1] : [0]) {
				let i = [...r];
				i[3] -= t, C(e.bag, i) && a.push({
					pay: i,
					cacheGold: t,
					bonus: n
				});
			}
		}
	}
	let s = /* @__PURE__ */ new Set();
	return a.filter((e) => {
		let t = JSON.stringify(e);
		return !s.has(t) && (s.add(t), !0);
	});
}
function se(e, t) {
	let n = M(t), r = (e) => n.filter((t) => t === "wild" || A(t).group === e).length, i = 0, a = 0, o = 0, s = t.waived ? 2 : 0;
	for (let e of t.rows.filter((e) => e.length === 4)) {
		let t = e.filter((e) => e !== "wild").map((e) => A(e).group);
		new Set(t).size <= 1 ? i += 4 : new Set(t).size === t.length ? (i += 2, a++) : o++;
	}
	for (let [e, n] of [
		["b0", "well"],
		["b4", "camp"],
		["b14", "targia"],
		["b23", "oasis"],
		["b42", "rider"]
	]) N(t, e) && (s += Math.floor(r(n) / 2));
	if (N(t, "b5") && t.rows.some((e) => e.length === 4 && e[3] === "b5") && (s += 2), N(t, "b12") && (s += Math.min(2, a) * 2), N(t, "b13") && n.length > M(F(e, t)).length && s++, N(t, "b20") && n.length >= 10 && s++, N(t, "e4") && y.filter((e) => n.some((t) => t !== "wild" && A(t).group === e)).length + n.filter((e) => e === "wild").length >= y.length && (s += 2), N(t, "e12") && t.cache.e12 === 2 && (s += 2), N(t, "e13") && o && (s += 2), N(t, "e24") && (s += Math.floor(n.filter((e) => re(e) || e === t.waived).length / 2)), N(t, "e30") && (s += Math.floor(S(t.bag) / 3)), N(t, "e44") && (s += Math.floor(n.filter((e) => e !== "wild" && A(e).vp === 1).length / 3)), N(t, "e26")) for (let e = 0; e < 4; e++) {
		let n = t.rows.map((t) => t[e]);
		if (n.some((e) => !e)) continue;
		let r = n.filter((e) => e !== "wild").map((e) => A(e).group);
		new Set(r).size === r.length && s++;
	}
	for (let e = 0; e < 3; e++) for (let n = 0; n < t.rows[e].length; n++) {
		let r = t.rows[e][n];
		if (!N(t, r)) continue;
		let i = (e) => e && e !== "wild" ? A(e).vp : 0;
		r === "e1" && (s += i(t.rows[e][n - 1])), r === "e29" && (s += i(t.rows[e][n + 1])), r === "e21" && (s += Math.max(i(t.rows[e - 1]?.[n]), i(t.rows[e + 1]?.[n])));
	}
	let c = n.reduce((e, t) => e + (t === "wild" ? 0 : A(t).vp), 0), l = e.config.expansion ? Math.floor(t.bag[4] / 2) : 0;
	return {
		tokens: t.vp,
		cards: c,
		rows: i,
		abilities: s,
		water: l,
		total: t.vp + c + i + s + l
	};
}
//#endregion
//#region src/games/targi/choices.ts
function H(e, t = 1, n = "resource") {
	return [
		0,
		1,
		2
	].map((r) => {
		let i = b();
		return i[r] = t, R(e, n, [r], "", b(), i);
	});
}
var U = (e, t) => e.players.some((e) => e.markers.includes(t) || e.specialMarker === t);
function ce(e, t, n) {
	let r = n.card, i = [];
	for (let e = 0; e < 3; e++) if (t.rows[e].length < 4) for (let a of oe(t, r, n.source ?? "", n.n === 1 ? "w" : void 0)) for (let n of t.mini.includes("waiver") && M(t).length < 9 ? [0, 1] : [0]) i.push(R("buy", `row:${t.rid}:${e}`, [
		e,
		a.cacheGold,
		Number(a.bonus),
		n
	], r, a.pay, b(), a.bonus ? A(r).bonusVp : 0));
	return ![
		"noble",
		"freehand",
		"swap"
	].includes(n.source ?? "") && t.hand.length < (N(t, "e27") ? 2 : 1) && i.push(R("keep", "pending", [], r)), ["noble", "freehand"].includes(n.source ?? "") ? i.push(R("cancel", "control")) : i.push(R("discardTribe", "pending", [], r)), n.source === "expansion" && t.bag[4] > 0 && e.tribeDeck.length && i.push(R("rerollTribe", "pending", [], r, x("w"))), i;
}
function le(e, t, n) {
	let r = [], i = () => r.push(R("done", "control"));
	switch (n.kind) {
		case "discardHand": return t.hand.map((e, t) => R("discardHand", `hand:${t}`, [t], e));
		case "gain": return H("gain");
		case "tribe": return ce(e, t, n);
		case "goodsChoice":
			for (let [e, t] of (n.source ?? "").split("/").entries()) t === "?" ? r.push(...H("goodsGain").map((t) => ({
				...t,
				args: [e, t.args[0]],
				id: t.id + ":" + e
			}))) : r.push(R("goodsGain", "pending", [e, -1], n.card ?? "", b(), x(t), +!!t.includes("v")));
			return r;
		case "order": return [R("targiaFirst", "pending"), R("borderFirst", "pending")];
		case "border": {
			let a = n.n;
			if (a in T) {
				let e = T[a], n = [
					"e16",
					"e28",
					"e14"
				][e];
				return N(t, n) ? H("borderGain") : [H("borderGain")[e]];
			}
			if (a === 0) for (let e = 0; e < t.hand.length; e++) oe(t, t.hand[e], "noble").length && M(t).length < 12 && r.push(R("noblePlay", `hand:${e}`, [e], t.hand[e])), r.push(R("nobleDiscard", `hand:${e}`, [e], t.hand[e]));
			if (a === 4) {
				for (let e = 0; e < 3; e++) {
					if (t.bag[e] >= 3) {
						let t = b();
						t[e] = 3, r.push(R("trade", "resource", [e, 3], "", t, x("g")));
					}
					let n = N(t, "b21") ? 1 : 2;
					if (t.bag[e] >= n) {
						for (let t = 0; t < 3; t++) if (e !== t) {
							let i = b(), a = b();
							i[e] = n, a[t] = 1, r.push(R("trade", "resource", [e, t], "", i, a));
						}
					}
				}
				if (e.config.expansion && (t.bag[4] >= 2 && r.push(R("trade", "resource", [4, 3], "", x("ww"), x("g"))), t.bag[4] >= 1)) for (let e of H("trade")) r.push({
					...e,
					id: e.id + ":water",
					pay: x("w")
				});
			}
			if (a === 8) {
				let i = P(t, "e10") && t.markers.length >= 2 && !n.args?.includes(1);
				for (let a of t.markers.filter((e) => n.source !== "second" || e !== n.args?.[2])) for (let t = 0; t < 9; t++) {
					let n = Math.abs(Math.floor(a / 3) - Math.floor(t / 3)) + Math.abs(a % 3 - t % 3) === 1;
					!U(e, t) && e.central[t].face && (!e.config.expansion || n) && (r.push(R("moveMarker", `central:${t}`, [
						a,
						t,
						0
					])), i && r.push(R("moveMarker", `central:${t}`, [
						a,
						t,
						1
					])));
				}
			}
			if (a === 9) {
				let i = n.args?.[0] ?? 0;
				if (i < (e.config.expansion ? 2 : 1)) {
					if (e.config.expansion) {
						for (let e = 0; e < 3; e++) for (let n = e; n < 3; n++) {
							let a = b();
							a[e]++, a[n]++, C(t.bag, a) && r.push(R("silver", "resource", [i], "", a, b(), 1));
						}
						t.bag[3] && r.push(R("silver", "resource", [i], "", x("g"), b(), 2));
					} else {
						for (let e = 0; e < 3; e++) for (let n of [2, 4]) if (t.bag[e] >= n) {
							let t = b();
							t[e] = n, r.push(R("silver", "resource", [i], "", t, b(), n === 2 ? 1 : 3));
						}
						for (let e of [1, 2]) if (t.bag[3] >= e) {
							let t = b();
							t[3] = e, r.push(R("silver", "resource", [i], "", t, b(), e * 2));
						}
					}
				}
			}
			return a === 12 && r.push(R(e.config.expansion ? "waterHole" : "caravan", "pending", [], "", b(), e.config.expansion ? x("w") : b())), a === 13 && e.tribeDeck.length && r.push(R("expand", "deck")), a === 13 && P(t, "e18") && e.tribeDiscard.length && r.push(R("discardTop", "discard", [], e.tribeDiscard.at(-1))), i(), r;
		}
		case "targia":
			r.push(...H("targiaGain")), N(t, "e22") && r.push(R("targiaGain", "resource", [4], "", b(), x("w")));
			for (let e = 0; e < 3; e++) if (t.bag[e]) {
				let t = b();
				t[e] = 1, r.push(R("targiaDraw", "resource", [e], "", t));
			}
			return i(), r;
		case "gamble":
			r.push(R("acceptGoods", "pending", [], n.card));
			for (let e = 0; e < 3; e++) if (t.bag[e]) {
				let t = b();
				t[e] = 1, r.push(R("targiaRedraw", "resource", [e], "", t));
			}
			return r;
		case "raid": {
			if (N(t, "b2")) return [R("raidFree")];
			let n = e.raids, i = n === 3 ? 2 : n === 4 ? 3 : 1;
			if (!(e.config.expansion && n === 4) && t.vp >= i && r.push(R("raidVp", "resource", [], "", b(), b(), -i)), n === 4) {
				if (t.bag[3] && r.push(R("raidPay", "resource", [], "", x("g"))), e.config.expansion) for (let e = 0; e < 3; e++) t.rows[e].length && r.push(R("raidCard", `row:${t.rid}:${e}`, [e], t.rows[e].at(-1)));
			} else if (e.config.expansion) {
				let e = x(n === 1 ? "p" : n === 2 ? "ds" : "dsp");
				C(t.bag, e) && r.push(R("raidPay", "resource", [], "", e));
			} else S(t.bag) >= n && r.push(R("raidGoods", "resource", [n]));
			return r.length || r.push(R("raidUnable")), r;
		}
		case "payGoods": return [
			0,
			1,
			2
		].filter((e) => t.bag[e]).map((e) => {
			let t = b();
			return t[e] = 1, R("payGoods", "resource", [e], "", t);
		});
		case "discardResources":
			if (S(t.bag) > 10) {
				for (let e = 0; e < 3; e++) if (t.bag[e]) {
					let t = b();
					t[e] = 1, r.push(R("discardResource", "resource", [e], "", t));
				}
			}
			if (t.bag[3] > 3) {
				let e = b();
				e[3] = t.bag[3] - 3, r.push(R("discardResource", "resource", [3], "", e));
			}
			if (t.bag[4] > 10) {
				let e = b();
				e[4] = t.bag[4] - 10, r.push(R("discardResource", "resource", [4], "", e));
			}
			return r;
		case "gift": return [
			R("giftGoods", "resource"),
			R("giftGold", "resource", [], "", b(), x("g")),
			R("giftVp", "resource", [], "", b(), b(), 1)
		];
		case "waterOrVp": return [R("waterOrVp", "resource", [0], "", b(), x("w")), R("waterOrVp", "resource", [1], "", b(), b(), 1)];
		case "stash": return e.dunes.forEach((t, n) => {
			t && !e.players.some((e) => e.workers.includes(-n - 1)) && r.push(R("stash", `dune:${n}`, [n], t));
		}), e.duneDeck.length && r.push(R("stash", "deck", [-1])), i(), r;
		case "swapHand": return t.hand.forEach((t, n) => e.central.forEach((i, a) => {
			i.type === "tribe" && i.face && !U(e, a) && r.push(R("swapHand", `central:${a}`, [n, a], t));
		})), i(), r;
		case "exchangeGoods":
			for (let e = 0; e < 3; e++) if (t.bag[e]) {
				for (let t = 0; t < 3; t++) if (e !== t) {
					let n = b(), i = b();
					n[e] = 1, i[t] = 1, r.push(R("trade", "resource", [e, t], "", n, i));
				}
			}
			return i(), r;
		case "rearrange":
			for (let e = 0; e < 3; e++) for (let i = 0; i < t.rows[e].length; i++) {
				if (n.source !== "base" || !n.n) for (let n = e; n < 3; n++) for (let a = 0; a < t.rows[n].length; a++) (e !== n || a > i) && r.push(R("swapDisplay", `row:${t.rid}:${n}`, [
					e,
					i,
					n,
					a
				], t.rows[e][i]));
				if (n.source === "base" && t.rows[e][i] !== n.card && i === t.rows[e].length - 1) for (let n = 0; n < 3; n++) n !== e && t.rows[n].length < 4 && r.push(R("moveDisplay", `row:${t.rid}:${n}`, [
					e,
					i,
					n
				], t.rows[e][i]));
				if (n.source === "dune") for (let n = 0; n < t.hand.length; n++) r.push(R("swapDisplayHand", `row:${t.rid}:${e}`, [
					e,
					i,
					n
				], t.hand[n]));
			}
			return i(), r;
		case "dune": {
			let a = Number(n.card.slice(1));
			if (a === 0 && t.bag[4] >= 2) for (let e = 0; e < 3; e++) t.rows[e].length < 4 && r.push(R("wild", `row:${t.rid}:${e}`, [e], "wild", x("ww")));
			if (a === 1) for (let n of t.markers) e.central[n].type === "tribe" && e.central[n].face && t.bag[4] && r.push(R("discountTribe", `central:${n}`, [n], e.central[n].card));
			if (a === 10) for (let e = 0; e < 16; e++) E(e) || r.push(R("anyBorder", `border:${e}`, [e]));
			if (a === 16 && e.central.forEach((t, n) => {
				t.type === "tribe" && t.face && !U(e, n) && r.push(R("unoccupiedTribe", `central:${n}`, [n], t.card));
			}), a === 17) for (let e of [
				"e6",
				"e7",
				"e10",
				"e18",
				"e23",
				"e33"
			]) N(t, e) && t.used.includes(e) && r.push(R("resetAbility", "ability", [], e));
			return a === 18 && e.tribeDiscard.forEach((e, t) => r.push(R("discardPick", "discard", [t], e))), [
				2,
				3,
				4,
				5,
				6,
				7,
				8,
				9,
				11,
				12,
				13,
				14,
				15,
				19
			].includes(a) && r.push(R("useDune", "pending", [a], n.card)), i(), r;
		}
		case "costReward": {
			let e = A(n.card);
			for (let [t, i] of e.costs.entries()) r.push(R("costReward", "pending", [t], n.card, b(), x(i)));
			return r;
		}
		default: return [];
	}
}
function ue(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || e.phase === "done" || e.phase === "between" || e.phase === "advance" && !e.tasks.length) return [];
	if (e.phase === "select") return n.omitted === null ? te.map((e, t) => R("omit", "mini", [t], e)) : [];
	if (e.turn !== t || ae(e.tasks[0])) return [];
	let r = [];
	if (e.tasks.length) r = le(e, n, e.tasks[0]);
	else if (e.phase === "placement" || e.phase === "extra") {
		let t = e.phase === "extra", i = F(e, n);
		if (!t || n.mini.includes("targi")) for (let a = 0; a < 16; a++) {
			if (E(a) || n.workers.includes(a) || n.extra === a) continue;
			let o = i.workers.includes(a) || i.extra === a, s = i.workers.includes(w[a]), c = o || !t && s, l = !t && P(n, "e23") && c;
			(a !== e.robber || N(n, "b37")) && (!t || a !== e.robber && !o) && (!c || l) && r.push(R(t ? "extra" : "place", `border:${a}`, [a, Number(l)]));
		}
		!t && e.config.expansion && e.dunes.forEach((e, t) => {
			if (!e || n.workers.includes(-t - 1)) return;
			let a = i.workers.includes(-t - 1);
			(!a || P(n, "e6")) && r.push(R("placeDune", `dune:${t}`, [-t - 1, Number(a)], e));
		}), t && r.push(R("skipExtra"));
	} else if (e.phase === "marker") {
		if (n.mini.includes("marker")) for (let t of D([e.robber, ...n.workers.filter((e) => e >= 0)])) !D(n.workers).includes(t) && !U(e, t) && e.central[t].face && r.push(R("extraMarker", `central:${t}`, [t]));
		r.push(R("skipMarker"));
	} else if (e.phase === "actions") {
		for (let t of n.work) {
			let n = Number(t.slice(1)), i = t.startsWith("m") || t.startsWith("z") ? e.central[n].card : t.startsWith("d") ? e.dunes[n] ?? "" : "";
			(!t.startsWith("m") && !t.startsWith("z") || e.central[n].face) && r.push(R("work", t.startsWith("m") || t.startsWith("z") ? `central:${n}` : t.startsWith("d") ? `dune:${n}` : `border:${n}`, [n], i));
		}
		P(n, "e7") && n.hand.length && r.push(R("abilitySwap", "ability", [], "e7")), P(n, "e33") && S(n.bag) && r.push(R("abilityTrade", "ability", [], "e33")), N(n, "b7") && n.hand.forEach((e, t) => {
			oe(n, e, "freehand").length && M(n).length < 12 && r.push(R("freehand", `hand:${t}`, [t], e));
		}), n.stash && r.push(R("stashUse", "stash", [], n.stash)), r.push(R("end"));
	}
	if ([
		"placement",
		"extra",
		"marker",
		"actions",
		"raid"
	].includes(e.phase) && !ae(e.tasks[0])) {
		if (e.config.expansion) {
			if (n.bag[4] >= 2) for (let e of H("waterTrade")) r.push({
				...e,
				id: e.id + ":two",
				pay: x("ww")
			});
			n.bag[4] >= 3 && r.push(R("waterTrade", "resource", [3], "", x("www"), x("g"))), N(n, "e12") && n.cache.e12 > 0 && r.push(R("cacheWater", "ability", [], "e12", b(), x("w")));
		}
		n.mini.includes("joker") && r.push(...H("joker"));
	}
	return r;
}
//#endregion
//#region src/games/targi/meta.ts
var W = {
	id: "targi",
	tier: "alpha",
	nameKey: "games.targi.name",
	descKey: "games.targi.desc",
	rulesKey: "games.targi.rules",
	icon: "🐪",
	iconImg: "games/targi.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/2033971236068563421/0FE47D217E6C52120618398F875AE020851A5383/" },
	mechanics: [
		"worker-placement",
		"set-collection",
		"hand-management"
	],
	interactionTags: [],
	accent: "#ae7429",
	releasedAt: "2026-10-31T12:40:00+08:00",
	search: {
		py: "da mo shang hao",
		init: "dmsh"
	},
	hotseat: "cover"
}, de = (e) => e < 0 ? `dune:${-e - 1}` : `border:${e}`;
function fe(e, t, n) {
	let r = [], i = [], a = [], o = (e, n, i = "", a = t.turn, o = !1, s = !1, c = !1, l = "") => r.push({
		from: e,
		to: n,
		card: i,
		owner: a,
		pawn: o,
		marker: s,
		special: c,
		hide: l
	});
	for (let r = 0; r < e.players.length; r++) {
		let i = e.players[r], s = t.players[r], c = s.bag.map((e, t) => e - i.bag[t]), l = s.vp - i.vp, u = e.tasks[0], d = u?.kind === "border" ? `border:${u.n}` : e.phase === "raid" ? `border:${e.robber}` : n?.kind === "buy" ? `row:${i.rid}:${n.args[0]}` : n?.target.startsWith("border:") ? n.target : "pending";
		(c.some(Boolean) || l) && a.push({
			rid: i.rid,
			resources: c,
			vp: l,
			source: d
		});
		for (let e of [!1, !0]) {
			let t = e ? [...i.markers, ...i.specialMarker === null ? [] : [i.specialMarker]] : [...i.workers, ...i.extra === null ? [] : [i.extra]], n = e ? [...s.markers, ...s.specialMarker === null ? [] : [s.specialMarker]] : [...s.workers, ...s.extra === null ? [] : [s.extra]], r = t.filter((e) => !n.includes(e)), a = n.filter((e) => !t.includes(e));
			for (; r.length || a.length;) {
				let t = r.shift(), n = a.shift(), c = n === void 0 ? `seat:${i.rid}` : e ? `central:${n}` : de(n), l = e ? (n ?? t) === (s.specialMarker ?? i.specialMarker) : (n ?? t) === (s.extra ?? i.extra);
				o(t === void 0 ? `seat:${i.rid}` : e ? `central:${t}` : de(t), c, "", i.rid, !0, e, l, n === void 0 ? "" : `pawn:${i.rid}:${e ? "m" : "w"}:${n}`);
			}
		}
		let f = new Map(i.rows.flatMap((e, t) => e.map((e, n) => [e, `card:${i.rid}:${t}:${n}`]))), p = new Map(s.rows.flatMap((e, t) => e.map((e, n) => [e, `card:${i.rid}:${t}:${n}`])));
		for (let [e, t] of p) {
			let n = f.get(e) ?? (i.hand.includes(e) ? `hand:${i.rid}` : "pending");
			n !== t && o(n, t, e, i.rid, !1, !1, !1, t);
		}
		for (let [e, t] of f) p.has(e) || o(t, s.hand.includes(e) ? `hand:${i.rid}` : "discard", e, i.rid);
		n?.kind === "keep" && n.card && s.hand.includes(n.card) && !i.hand.includes(n.card) && o("pending", `hand:${i.rid}`, n.card, i.rid), (n?.kind === "nobleDiscard" || n?.kind === "discardHand") && i.rid === e.turn && o(`hand:${i.rid}`, "discard", n.card, i.rid), s.stash && s.stash !== i.stash && o(n?.target.startsWith("dune:") ? n.target : "deck", `stash:${i.rid}`, s.stash, i.rid, !1, !1, !1, `stash:${i.rid}`), i.stash && !s.stash && n?.kind === "stashUse" && o(`stash:${i.rid}`, "pending", i.stash, i.rid);
	}
	for (let n = 0; n < 9; n++) {
		let r = e.central[n], a = t.central[n];
		!r.face && a.face && a.card && i.push({
			at: `central:${n}`,
			card: a.card
		}), r.face && !a.face && (r.card && o(`central:${n}`, "pending", r.card), o(a.type === "goods" ? "goodsDeck" : "deck", `central:${n}`, "back", t.turn, !1, !1, !1, `central:${n}`)), r.face && a.face && r.card !== a.card && (o(`central:${n}`, `hand:${e.turn}`, r.card), o(`hand:${e.turn}`, `central:${n}`, a.card, t.turn, !1, !1, !1, `central:${n}`));
	}
	let s = e.tasks[0], c = t.tasks[0];
	return c?.card && c.card !== s?.card && [
		"tribe",
		"gamble",
		"goodsChoice",
		"reward",
		"costReward"
	].includes(c.kind) && !["noble", "freehand"].includes(c.source ?? "") && !r.some((e) => e.card === c.card && e.to === "pending") && o(n?.kind === "discardPick" || n?.kind === "discardTop" ? "discard" : c.card.startsWith("g") || c.card.startsWith("w") ? "goodsDeck" : "deck", "pending", c.card), (n?.kind === "discardTribe" || n?.kind === "rerollTribe") && o("pending", "discard", n.card), n?.kind === "work" && n.target.startsWith("dune") && o(n.target, "pending", n.card), e.robber !== t.robber && o(`border:${e.robber}`, `border:${t.robber}`, "", "robber", !0, !1, !1, "pawn:robber"), e.targia !== t.targia && o(`border:${e.targia}`, `border:${t.targia}`, "", "targia", !0, !1, !1, "pawn:targia"), {
		moves: r,
		flips: i,
		deltas: a
	};
}
//#endregion
//#region src/games/targi/schema.ts
var pe = t.object({
	expansion: t.boolean().default(!1),
	mixed: t.boolean().default(!1),
	tokens: t.boolean().default(!1)
}).default({
	expansion: !1,
	mixed: !1,
	tokens: !1
}), me = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(160)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), G = t.tuple([
	t.int(),
	t.int(),
	t.int(),
	t.int(),
	t.int()
]), he = t.object({
	id: t.string(),
	kind: t.string(),
	target: t.string(),
	args: t.array(t.int()),
	card: t.string(),
	pay: G,
	gain: G,
	vp: t.int()
}), ge = t.object({
	rid: t.string(),
	bag: G,
	vp: t.int(),
	rows: t.array(t.array(t.string())),
	handCount: t.int(),
	workers: t.array(t.int()),
	markers: t.array(t.int()),
	specialMarker: t.int().nullable(),
	extra: t.int().nullable(),
	work: t.array(t.string()),
	mini: t.array(t.string()),
	chosen: t.boolean(),
	waived: t.string().nullable(),
	cache: t.record(t.string(), t.int()),
	used: t.array(t.string()),
	stash: t.string().nullable()
}), _e = t.object({
	tokens: t.int(),
	cards: t.int(),
	rows: t.int(),
	abilities: t.int(),
	water: t.int(),
	total: t.int()
}), ve = t.object({
	config: pe,
	phase: t.string(),
	round: t.int(),
	turn: t.string(),
	starter: t.string(),
	robber: t.int(),
	targia: t.int(),
	raids: t.int(),
	central: t.array(t.object({
		card: t.string().nullable(),
		type: t.enum(["goods", "tribe"]),
		face: t.boolean()
	})),
	dunes: t.array(t.string().nullable()),
	tribesLeft: t.int(),
	goodsLeft: t.int(),
	tribeTop: t.string().nullable(),
	discard: t.array(t.string()),
	players: t.array(ge),
	pending: t.object({
		kind: t.string(),
		card: t.string(),
		source: t.string()
	}).nullable(),
	last: t.object({
		kind: t.string(),
		rid: t.string(),
		card: t.string(),
		target: t.string(),
		gain: G,
		pay: G,
		vp: t.int()
	}).nullable(),
	scores: t.record(t.string(), _e)
}), ye = t.object({
	hand: t.array(t.string()),
	choices: t.array(he),
	pendingCard: t.string(),
	stash: t.string().nullable()
});
function K(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function q(e) {
	return e.goodsDeck.length || (e.goodsDeck = K(e, e.goodsDiscard.splice(0))), e.goodsDeck.pop() ?? "";
}
function be(e, t) {
	let n = e.central[t], r = n.type === "tribe" ? "goods" : "tribe";
	n.card = r === "goods" ? q(e) : e.tribeDeck.pop() ?? "", n.type = r, n.face = !1;
}
function xe(e, t) {
	delete e.cache[t], e.used = e.used.filter((e) => e !== t), e.waived === t && (e.waived = null);
}
function Se(e, t, n, r, i) {
	if (t.rows[r].push(n), i) {
		t.waived = n, t.mini = t.mini.filter((e) => e !== "waiver");
		return;
	}
	if (n === "b8" && z(e, { kind: "gift" }), n === "b9" && (F(e, t).limited = e.round + 1), n === "b19" && z(e, {
		kind: "rearrange",
		source: "base"
	}), n === "b35" && (t.cache.b35 = 1), n === "b36") {
		let n = Math.floor(M(t).length / 2);
		n && z(e, V(n));
	}
	if (n === "b39") {
		let n = Math.floor((12 - M(t).length) / 2);
		n && z(e, V(n));
	}
	if ([
		"b11",
		"b17",
		"b33"
	].includes(n)) {
		let e = [
			"b11",
			"b17",
			"b33"
		].indexOf(n);
		t.goodsReceived[e] && !t.goodsBonus[e] && (t.bag[e]++, t.goodsBonus[e] = 1);
	}
	n === "e12" && (t.cache.e12 = 2), n === "e20" && z(e, { kind: "stash" }), n === "e42" && L(t, x("dspw")), n === "e43" && e.raids && z(e, {
		kind: "waterOrVp",
		n: e.raids
	});
}
function Ce(e, t, n) {
	if (!n) return;
	if (n === "?") {
		z(e, {
			kind: "goodsChoice",
			source: "?"
		});
		return;
	}
	let r = x(n);
	L(t, r), n.includes("v") && t.vp++;
	for (let e = 0; e < 3; e++) r[e] && (t.goodsReceived[e] += r[e], N(t, [
		"b11",
		"b17",
		"b33"
	][e]) && !t.goodsBonus[e] && (t.bag[e]++, t.goodsBonus[e] = 1));
}
function we(e, t) {
	let n = k(t);
	n.length > 1 || n[0] === "?" ? z(e, {
		kind: "goodsChoice",
		card: t,
		source: n.join("/")
	}) : z(e, {
		kind: "reward",
		card: t,
		source: n[0]
	});
}
function Te(e, t, n) {
	n === 8 && N(t, "e9") ? z(e, V(), {
		kind: "border",
		n
	}) : z(e, {
		kind: "border",
		n
	});
}
function Ee(e) {
	e.phase = "placement", e.turn = e.starter;
}
function De(e, t, n) {
	let r = {
		config: e,
		phase: e.tokens ? "select" : "placement",
		round: 1,
		turn: t[0],
		starter: t[0],
		robber: 0,
		targia: 14,
		raids: 0,
		central: [],
		dunes: [],
		players: [],
		tribeDeck: [],
		goodsDeck: [],
		goodsDiscard: [],
		tribeDiscard: [],
		duneDeck: [],
		tasks: [],
		seed: n,
		cursor: 0,
		last: null
	};
	r.players = t.map((t) => ({
		rid: t,
		bag: e.expansion ? x("dspgww") : x("ddssppg"),
		vp: 4,
		rows: [
			[],
			[],
			[]
		],
		hand: [],
		workers: [],
		markers: [],
		specialMarker: null,
		extra: null,
		work: [],
		mini: e.tokens ? [...te] : [],
		omitted: null,
		waived: null,
		cache: {},
		used: [],
		stash: null,
		goodsReceived: [
			0,
			0,
			0
		],
		goodsBonus: [
			0,
			0,
			0
		],
		limited: 0
	})), r.tribeDeck = e.expansion && e.mixed ? y.flatMap((e) => K(r, Object.values(j).filter((t) => t.group === e).map((e) => e.id)).slice(0, 9)) : Object.keys(j).filter((t) => t.startsWith(e.expansion ? "e" : "b")), K(r, r.tribeDeck), r.goodsDeck = K(r, [...Array.from({ length: 19 }, (e, t) => "g" + t), ...e.expansion ? Array.from({ length: 5 }, (e, t) => "w" + t) : []]), r.duneDeck = K(r, Array.from({ length: 20 }, (e, t) => "d" + t)), e.expansion && (r.dunes = r.duneDeck.splice(-3));
	for (let t = 0; t < 9; t++) {
		let n = t % 2 == 0 === e.expansion ? "tribe" : "goods";
		r.central.push({
			type: n,
			card: n === "goods" ? q(r) : r.tribeDeck.pop(),
			face: !0
		});
	}
	return { state: r };
}
function Oe(e) {
	for (let t of e.players) {
		let e = Math.max(0, 2 - t.workers.filter((e) => e < 0).length);
		t.markers = D(t.workers).slice(0, e);
	}
}
function ke(e) {
	e.phase = "actions", e.turn = e.starter;
	for (let t of e.players) t.work = [
		...t.workers.map((e) => e < 0 ? "d" + (-e - 1) : "w" + e),
		...t.markers.map((e) => "m" + e),
		...t.extra === null ? [] : ["x" + t.extra],
		...t.specialMarker === null ? [] : ["z" + t.specialMarker]
	];
}
function Ae(e, t) {
	e.turn === e.starter ? e.turn = F(e, I(e)).rid : t === "extra" ? (Oe(e), e.phase = "marker", e.turn = e.starter) : ke(e);
}
function je(e) {
	let t = I(e), n = F(e, t), r = (t) => t.limited === e.round ? 2 : 3;
	n.workers.length < r(n) ? e.turn = n.rid : t.workers.length < r(t) ? e.turn = t.rid : e.config.tokens ? (e.phase = "extra", e.turn = e.starter) : (Oe(e), ke(e));
}
function Me(e, t) {
	e.players.some((e) => e.workers.includes(-t - 1)) || (e.dunes[t] = null);
}
function Ne(e, t) {
	for (let n of t.workers.filter((e) => e < 0)) t.workers = t.workers.filter((e) => e !== n), Me(e, -n - 1);
	t.workers = [], t.markers = [], t.specialMarker = null, t.extra = null, t.work = [], t.rid === e.starter ? e.turn = F(e, t).rid : e.phase = e.players.some((e) => M(e).length === 12) ? "done" : "between";
}
function Pe(e, t) {
	if (N(t, "b15") && !t.goodsReceived.some(Boolean) && !t.used.includes("roundGift")) {
		t.used.push("roundGift"), z(e, V(), { kind: "finish" });
		return;
	}
	S(t.bag) > 10 || t.bag[3] > 3 || t.bag[4] > 10 ? z(e, { kind: "discardResources" }) : Ne(e, t);
}
function Fe(e, t, n, r = "central", i = !1) {
	let a = e.central[n], o = a.card;
	t.markers = t.markers.filter((e) => e !== n), t.specialMarker === n && (t.specialMarker = null), t.work = t.work.filter((e) => e !== "m" + n && e !== "z" + n), o && a.face && (a.type === "goods" ? (e.goodsDiscard.push(o), we(e, o)) : z(e, {
		kind: "tribe",
		card: o,
		source: r,
		n: +!!i
	}), be(e, n));
}
function Ie(e, t, n) {
	switch (n) {
		case 2:
			z(e, {
				kind: "rearrange",
				source: "dune"
			});
			break;
		case 3:
			t.vp++, L(t, x("w")), z(e, V());
			break;
		case 4:
			t.vp++, z(e, { kind: "targia" });
			break;
		case 5:
			Te(e, t, w[e.robber]), Te(e, t, e.robber);
			break;
		case 6:
			t.vp += 2;
			break;
		case 7:
			L(t, x("wg"));
			break;
		case 8: {
			let n = M(t).filter((e) => re(e) || e === t.waived).length;
			n && z(e, V(n));
			break;
		}
		case 9:
			L(t, x("dsp")), z(e, V());
			break;
		case 11:
			L(t, x("www"));
			break;
		case 12: {
			let t = e.tribeDeck.pop();
			t && (e.tribeDiscard.push(t), z(e, {
				kind: "costReward",
				card: t
			}));
			break;
		}
		case 13:
			L(t, x("ww")), z(e, V());
			break;
		case 14:
			t.vp++, z(e, V(2));
			break;
		case 15:
			L(t, x("g")), z(e, V());
			break;
		case 19: z(e, { kind: "goods" }, { kind: "goods" });
	}
}
function Le(e) {
	e.round++, e.starter = F(e, e.players.find((t) => t.rid === e.starter)).rid, e.turn = e.starter;
	for (let t of e.players) t.goodsReceived = [
		0,
		0,
		0
	], t.goodsBonus = [
		0,
		0,
		0
	], t.used = t.used.filter((e) => e !== "roundGift");
	e.phase = "advance";
	for (let t of e.players) N(t, "e19") && S(t.bag) < 4 && B(e, {
		kind: "roundGood",
		rid: t.rid
	});
}
function Re(e) {
	if (e.robber++, e.config.expansion) do
		e.targia = (e.targia + 15) % 16;
	while (E(e.targia));
	if (E(e.robber)) {
		e.raids++, e.phase = "raid", e.turn = e.starter;
		for (let t of [I(e), F(e, I(e))]) B(e, {
			kind: "raidBonus",
			rid: t.rid
		}, {
			kind: "raid",
			rid: t.rid
		});
		B(e, { kind: "postRaid" });
	} else {
		for (let t of e.players) N(t, "e17") && e.robber in T && t.bag[T[e.robber]]++;
		e.config.expansion && !e.dunes.some(Boolean) && e.duneDeck.length && (e.dunes = [e.duneDeck.pop()]), Ee(e);
	}
}
function ze(e) {
	let t = e.tasks.shift(), n = t.rid ? e.players.find((e) => e.rid === t.rid) : I(e);
	switch (t.rid && (e.turn = t.rid), t.kind) {
		case "drawTribe": {
			let t = e.tribeDeck.pop();
			t && z(e, {
				kind: "tribe",
				card: t,
				source: e.config.expansion ? "expansion" : "draw"
			});
			break;
		}
		case "goods": {
			let t = q(e);
			t && (e.goodsDiscard.push(t), we(e, t));
			break;
		}
		case "reward":
			Ce(e, n, t.source);
			break;
		case "raidBonus":
			N(n, "e8") && n.bag[4]++;
			break;
		case "roundGood":
			z(e, {
				kind: "gain",
				n: 1,
				rid: n.rid
			});
			break;
		case "postRaid":
			if (e.raids === 4) {
				e.phase = "done";
				break;
			}
			e.robber++, e.config.expansion && (e.dunes = e.duneDeck.splice(-3));
			for (let t of e.players) N(t, "e17") && e.robber in T && t.bag[T[e.robber]]++;
			Ee(e);
			break;
		case "startPlacement":
			Ee(e);
			break;
		case "startActions": ke(e);
	}
	return t;
}
function Be(e, t) {
	N(t, "b27") && t.vp++, e.tasks[0]?.rid && (e.turn = e.tasks[0].rid);
}
function Ve(e, t, n) {
	let r = e.tasks[0], i = n.args[0];
	switch (ie(t, n.pay), L(t, n.gain), t.vp += n.vp, n.kind) {
		case "omit":
			t.omitted = te[i], t.mini = t.mini.filter((e) => e !== t.omitted), e.players.every((e) => e.omitted !== null) && Ee(e);
			break;
		case "place":
		case "placeDune":
			t.workers.push(i), n.args[1] && t.used.push(n.kind === "place" ? "e23" : "e6"), je(e);
			break;
		case "extra":
			t.extra = i, t.mini = t.mini.filter((e) => e !== "targi"), Ae(e, "extra");
			break;
		case "skipExtra":
			Ae(e, "extra");
			break;
		case "extraMarker":
			t.specialMarker = i, t.mini = t.mini.filter((e) => e !== "marker"), Ae(e, "marker");
			break;
		case "skipMarker":
			Ae(e, "marker");
			break;
		case "waterTrade": break;
		case "cacheWater":
			t.cache.e12--;
			break;
		case "joker":
			t.mini = t.mini.filter((e) => e !== "joker");
			break;
		case "work": {
			let r = t.work.find((e) => {
				let t = Number(e.slice(1));
				return n.target === (e[0] === "m" || e[0] === "z" ? `central:${t}` : e[0] === "d" ? `dune:${t}` : `border:${t}`);
			});
			if (t.work.splice(t.work.indexOf(r), 1), r[0] === "m" || r[0] === "z") Fe(e, t, i);
			else if (r[0] === "d") {
				t.workers = t.workers.filter((e) => e !== -i - 1);
				let n = e.dunes[i];
				n && z(e, {
					kind: "dune",
					card: n,
					n: i
				}), Me(e, i);
			} else r[0] === "x" ? t.extra = null : t.workers = t.workers.filter((e) => e !== i), e.config.expansion && (i === e.targia || N(t, "e35") && w[i] === e.targia) ? z(e, {
				kind: "order",
				n: i
			}) : Te(e, t, i);
			break;
		}
		case "targiaFirst":
		case "borderFirst": {
			e.tasks.shift();
			let i = {
				kind: "border",
				n: r.n
			}, a = n.kind === "targiaFirst" ? [{ kind: "targia" }, i] : [i, { kind: "targia" }];
			r.n === 8 && N(t, "e9") && a.unshift(V()), z(e, ...a);
			break;
		}
		case "end":
			Pe(e, t);
			break;
		case "done":
		case "cancel":
			e.tasks.shift();
			break;
		case "gain":
			--r.n === 0 && e.tasks.shift();
			break;
		case "goodsGain":
			e.tasks.shift();
			for (let e = 0; e < 3; e++) n.gain[e] && (t.goodsReceived[e] += n.gain[e], N(t, [
				"b11",
				"b17",
				"b33"
			][e]) && !t.goodsBonus[e] && (t.bag[e]++, t.goodsBonus[e] = 1));
			break;
		case "borderGain":
		case "waterHole":
			e.tasks.shift();
			break;
		case "trade": break;
		case "silver":
			r.args = [(r.args?.[0] ?? 0) + 1], r.args[0] === (e.config.expansion ? 2 : 1) && e.tasks.shift();
			break;
		case "noblePlay":
		case "freehand":
			n.kind === "noblePlay" && e.tasks.shift(), z(e, {
				kind: "tribe",
				card: t.hand[i],
				source: n.kind === "noblePlay" ? "noble" : "freehand",
				args: [i]
			});
			break;
		case "nobleDiscard": {
			e.tasks.shift();
			let n = t.hand.splice(i, 1)[0];
			e.tribeDiscard.push(n), e.config.expansion && (t.bag[4]++, z(e, V()));
			break;
		}
		case "discardHand":
			e.tasks.shift(), e.tribeDiscard.push(t.hand.splice(i, 1)[0]);
			break;
		case "caravan":
			e.tasks.shift(), z(e, { kind: "goods" });
			break;
		case "expand":
			e.tasks.shift(), z(e, { kind: "drawTribe" });
			break;
		case "discardTop":
			e.tasks.shift(), t.used.push("e18"), z(e, {
				kind: "tribe",
				card: e.tribeDiscard.pop(),
				source: "discard"
			});
			break;
		case "buy":
			e.tasks.shift(), ["noble", "freehand"].includes(r.source ?? "") && t.hand.splice(r.args[0], 1), n.args[1] && t.cache.b35--, Se(e, t, n.card, i, n.args[3] === 1);
			break;
		case "keep":
			e.tasks.shift(), t.hand.push(n.card);
			break;
		case "discardTribe":
			e.tasks.shift(), e.tribeDiscard.push(n.card);
			break;
		case "rerollTribe":
			e.tasks.shift(), e.tribeDiscard.push(r.card), z(e, { kind: "drawTribe" });
			break;
		case "moveMarker": {
			let i = n.args[0], a = n.args[1];
			t.markers[t.markers.indexOf(i)] = a, t.work = t.work.map((e) => e === "m" + i ? "m" + a : e), n.args[2] ? (t.used.push("e10"), r.args = [
				1,
				i,
				a
			], r.source = "second") : e.tasks.shift();
			break;
		}
		case "targiaGain":
			e.tasks.shift();
			break;
		case "targiaDraw":
		case "targiaRedraw": {
			n.kind === "targiaRedraw" && e.goodsDiscard.push(r.card), e.tasks.shift();
			let t = q(e);
			t && z(e, {
				kind: "gamble",
				card: t
			});
			break;
		}
		case "acceptGoods":
			e.tasks.shift(), e.goodsDiscard.push(n.card), we(e, n.card);
			break;
		case "raidFree":
			e.tasks.shift();
			break;
		case "raidVp":
		case "raidPay":
			e.tasks.shift(), Be(e, t);
			break;
		case "raidGoods":
			e.tasks.shift(), z(e, {
				kind: "payGoods",
				n: i
			});
			break;
		case "payGoods":
			--r.n === 0 && (e.tasks.shift(), Be(e, t));
			break;
		case "raidCard": {
			let n = t.rows[i].pop();
			xe(t, n), e.tribeDiscard.push(n), e.tasks.shift(), Be(e, t);
			break;
		}
		case "raidUnable":
			e.tasks.shift(), F(e, t).vp += e.raids === 3 ? 2 : e.raids === 4 ? 3 : 1;
			break;
		case "discardResource":
			S(t.bag) <= 10 && t.bag[3] <= 3 && t.bag[4] <= 10 && (e.tasks.shift(), Ne(e, t));
			break;
		case "giftGoods":
			e.tasks.shift(), z(e, V(3));
			break;
		case "giftGold":
		case "giftVp":
			e.tasks.shift();
			break;
		case "waterOrVp":
			--r.n === 0 && e.tasks.shift();
			break;
		case "stash":
			e.tasks.shift(), t.stash = i < 0 ? e.duneDeck.pop() ?? null : e.dunes[i], i >= 0 && (e.dunes[i] = null);
			break;
		case "stashUse": {
			let n = t.stash;
			t.stash = null, z(e, {
				kind: "dune",
				card: n,
				n: -1
			});
			break;
		}
		case "abilitySwap":
			t.used.push("e7"), z(e, { kind: "swapHand" });
			break;
		case "swapHand": {
			let r = n.args[1], a = e.central[r].card;
			e.central[r].card = t.hand[i], t.hand[i] = a, e.tasks.shift();
			break;
		}
		case "abilityTrade":
			t.used.push("e33"), z(e, { kind: "exchangeGoods" });
			break;
		case "swapDisplay": {
			let [r, i, a, o] = n.args;
			[t.rows[r][i], t.rows[a][o]] = [t.rows[a][o], t.rows[r][i]], e.tasks.shift();
			break;
		}
		case "moveDisplay": {
			let [i, , a] = n.args, o = t.rows[i].pop();
			t.rows[a].push(o), r.n === 1 ? e.tasks.shift() : (r.n = 1, r.card = o);
			break;
		}
		case "swapDisplayHand": {
			let [r, i, a] = n.args, o = t.rows[r][i], s = t.hand[a];
			xe(t, o), t.hand[a] = o, t.rows[r].splice(i, 1), e.tasks.shift(), Se(e, t, s, r, !1), t.rows[r].splice(t.rows[r].length - 1, 1), t.rows[r].splice(i, 0, s);
			break;
		}
		case "wild":
			e.tasks.shift(), t.rows[i].push("wild"), r.n >= 0 && (e.dunes[r.n] = null);
			break;
		case "discountTribe":
		case "unoccupiedTribe":
			e.tasks.shift(), Fe(e, t, i, "dune", n.kind === "discountTribe");
			break;
		case "anyBorder":
			e.tasks.shift(), Te(e, t, i), z(e, V());
			break;
		case "resetAbility":
			e.tasks.shift(), t.used = t.used.filter((e) => e !== n.card);
			break;
		case "discardPick":
			e.tasks.shift(), e.tribeDiscard.splice(i, 1), z(e, {
				kind: "tribe",
				card: n.card,
				source: "discard"
			});
			break;
		case "useDune":
			e.tasks.shift(), Ie(e, t, i);
			break;
		case "costReward": e.tasks.shift();
	}
	e.tasks[0]?.kind === "finish" && (e.tasks.shift(), Pe(e, t)), e.tasks[0]?.kind === "discardResources" && S(t.bag) <= 10 && t.bag[3] <= 3 && t.bag[4] <= 10 && (e.tasks.shift(), Ne(e, t)), e.phase === "actions" && t.hand.length > (N(t, "e27") ? 2 : 1) && e.tasks[0]?.kind !== "discardHand" && z(e, {
		kind: "discardHand",
		rid: t.rid
	}), e.phase === "raid" && e.tasks[0]?.rid && (e.turn = e.tasks[0].rid);
}
function He(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "done") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = t.tasks[0]?.rid ?? t.turn, r = t.players.find((e) => e.rid === n), i = r.bag.slice(), a, o = "";
		if (ae(t.tasks[0])) {
			let e = ze(t);
			a = e.kind, o = e.card ?? "";
		} else if (t.phase === "between") t.central.forEach((e) => {
			e.face = !!e.card;
		}), Le(t), a = "reveal";
		else if (t.phase === "advance" && !t.tasks.length) Re(t), a = "robber";
		else return {
			state: e,
			fx: []
		};
		t.last = {
			kind: a,
			rid: r.rid,
			card: o,
			target: "board",
			gain: b(),
			pay: b(),
			vp: 0
		};
		for (let e = 0; e < 5; e++) t.last.gain[e] = Math.max(0, r.bag[e] - i[e]);
		return {
			state: t,
			fx: [{
				kind: "scene",
				rid: r.rid,
				data: fe(e, t)
			}]
		};
	}
	let r = ue(e, n.by).find((e) => e.id === t.id);
	if (!r) return { code: "games.targi.invalid" };
	let i = structuredClone(e), a = i.players.find((e) => e.rid === n.by);
	return Ve(i, a, r), i.last = {
		kind: r.kind,
		rid: a.rid,
		card: [
			"omit",
			"freehand",
			"noblePlay"
		].includes(r.kind) ? "" : r.card,
		target: r.target,
		gain: r.gain,
		pay: r.pay,
		vp: r.vp
	}, {
		state: i,
		fx: [{
			kind: "scene",
			rid: a.rid,
			data: fe(e, i, r)
		}]
	};
}
function Ue(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.tasks[0], i = r?.kind === "tribe" && ["noble", "freehand"].includes(r.source ?? "");
	return {
		public: {
			config: e.config,
			phase: e.phase,
			round: e.round,
			turn: e.turn,
			starter: e.starter,
			robber: e.robber,
			targia: e.targia,
			raids: e.raids,
			central: e.central.map((e) => ({
				...e,
				card: e.face && e.card || null
			})),
			dunes: e.dunes,
			tribesLeft: e.tribeDeck.length,
			goodsLeft: e.goodsDeck.length,
			tribeTop: e.config.expansion ? e.tribeDeck.at(-1) ?? null : null,
			discard: e.tribeDiscard,
			players: e.players.map((t) => ({
				rid: t.rid,
				bag: t.bag,
				vp: t.vp,
				rows: t.rows,
				handCount: t.hand.length,
				workers: t.workers,
				markers: t.markers,
				specialMarker: t.specialMarker,
				extra: t.extra,
				work: t.work,
				mini: e.phase === "select" ? [] : t.mini,
				chosen: t.omitted !== null,
				waived: t.waived,
				cache: t.cache,
				used: t.used,
				stash: t.stash
			})),
			pending: r ? {
				kind: r.kind,
				card: i ? "" : r.card ?? "",
				source: r.source ?? ""
			} : null,
			last: e.last,
			scores: Object.fromEntries(e.players.map((t) => [t.rid, se(e, t)]))
		},
		private: {
			hand: n?.hand ?? [],
			choices: ue(e, t),
			pendingCard: e.turn === t ? r?.card ?? "" : "",
			stash: n?.stash ?? null
		}
	};
}
function We(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => [
		se(e, t).total,
		t.bag[3],
		S(t.bag)
	], n = (e, n) => {
		let r = t(e), i = t(n);
		for (let e = 0; e < 3; e++) if (r[e] !== i[e]) return i[e] - r[e];
		return 0;
	}, r = [...e.players].sort(n);
	return {
		phase: "done",
		winner: r.filter((e) => n(e, r[0]) === 0).map((e) => e.rid),
		ranking: r.map((e) => e.rid),
		scores: Object.fromEntries(e.players.map((t) => [t.rid, se(e, t).total]))
	};
}
var Ge = {
	meta: W,
	saveCompatibility: { version: "1" },
	schemas: {
		action: me,
		publicView: ve,
		privateView: ye,
		config: pe
	},
	setup: De,
	reduce: He,
	viewFor: Ue,
	status: We,
	nextTickIn: (e) => ae(e.tasks[0]) || e.phase === "between" || e.phase === "advance" && !e.tasks.length ? 560 : null
}, Ke = {
	0: "games.targi.border.0",
	1: "games.targi.border.1",
	2: "games.targi.border.2",
	3: "games.targi.border.3",
	4: "games.targi.border.4",
	5: "games.targi.border.5",
	6: "games.targi.border.6",
	7: "games.targi.border.7",
	8: "games.targi.border.8",
	9: "games.targi.border.9",
	10: "games.targi.border.10",
	11: "games.targi.border.11",
	12: "games.targi.border.12",
	13: "games.targi.border.13",
	14: "games.targi.border.14",
	15: "games.targi.border.15"
}, qe = {
	0: "games.targi.borderText.0",
	1: "games.targi.borderText.1",
	2: "games.targi.borderText.2",
	3: "games.targi.borderText.3",
	4: "games.targi.borderText.4",
	5: "games.targi.borderText.5",
	6: "games.targi.borderText.6",
	7: "games.targi.borderText.7",
	8: "games.targi.borderText.8",
	9: "games.targi.borderText.9",
	10: "games.targi.borderText.10",
	11: "games.targi.borderText.11",
	12: "games.targi.borderText.12",
	13: "games.targi.borderText.13",
	14: "games.targi.borderText.14",
	15: "games.targi.borderText.15"
}, Je = {
	0: "games.targi.dunes.0",
	1: "games.targi.dunes.1",
	2: "games.targi.dunes.2",
	3: "games.targi.dunes.3",
	4: "games.targi.dunes.4",
	5: "games.targi.dunes.5",
	6: "games.targi.dunes.6",
	7: "games.targi.dunes.7",
	8: "games.targi.dunes.8",
	9: "games.targi.dunes.9",
	10: "games.targi.dunes.10",
	11: "games.targi.dunes.11",
	12: "games.targi.dunes.12",
	13: "games.targi.dunes.13",
	14: "games.targi.dunes.14",
	15: "games.targi.dunes.15",
	16: "games.targi.dunes.16",
	17: "games.targi.dunes.17",
	18: "games.targi.dunes.18",
	19: "games.targi.dunes.19"
}, Ye = {
	joker: "games.targi.mini.joker",
	targi: "games.targi.mini.targi",
	marker: "games.targi.mini.marker",
	waiver: "games.targi.mini.waiver"
}, Xe = {
	oasis: "games.targi.group.oasis",
	rider: "games.targi.group.rider",
	camp: "games.targi.group.camp",
	well: "games.targi.group.well",
	targia: "games.targi.group.targia"
}, Ze = {
	select: "games.targi.phase.select",
	placement: "games.targi.phase.placement",
	extra: "games.targi.phase.extra",
	marker: "games.targi.phase.marker",
	actions: "games.targi.phase.actions",
	raid: "games.targi.phase.raid",
	between: "games.targi.phase.between",
	advance: "games.targi.phase.advance",
	done: "games.targi.phase.done"
}, Qe = {
	discardHand: "games.targi.task.discardHand",
	gain: "games.targi.task.gain",
	tribe: "games.targi.task.tribe",
	goodsChoice: "games.targi.task.goodsChoice",
	border: "games.targi.task.border",
	order: "games.targi.task.order",
	targia: "games.targi.task.targia",
	gamble: "games.targi.task.gamble",
	raid: "games.targi.task.raid",
	payGoods: "games.targi.task.payGoods",
	discardResources: "games.targi.task.discardResources",
	gift: "games.targi.task.gift",
	waterOrVp: "games.targi.task.waterOrVp",
	stash: "games.targi.task.stash",
	swapHand: "games.targi.task.swapHand",
	exchangeGoods: "games.targi.task.exchangeGoods",
	rearrange: "games.targi.task.rearrange",
	dune: "games.targi.task.dune",
	costReward: "games.targi.task.costReward",
	roundGood: "games.targi.task.roundGood",
	drawTribe: "games.targi.task.drawTribe",
	goods: "games.targi.task.goods",
	reward: "games.targi.task.reward",
	raidBonus: "games.targi.task.raidBonus",
	postRaid: "games.targi.task.postRaid",
	startActions: "games.targi.task.startActions",
	startPlacement: "games.targi.task.startPlacement"
}, $e = {
	discardHand: "games.targi.actions.discardHand",
	omit: "games.targi.actions.omit",
	place: "games.targi.actions.place",
	placeDune: "games.targi.actions.placeDune",
	extra: "games.targi.actions.extra",
	skipExtra: "games.targi.actions.skipExtra",
	extraMarker: "games.targi.actions.extraMarker",
	skipMarker: "games.targi.actions.skipMarker",
	work: "games.targi.actions.work",
	buy: "games.targi.actions.buy",
	keep: "games.targi.actions.keep",
	discardTribe: "games.targi.actions.discardTribe",
	cancel: "games.targi.actions.cancel",
	done: "games.targi.actions.done",
	gain: "games.targi.actions.gain",
	goodsGain: "games.targi.actions.goodsGain",
	borderGain: "games.targi.actions.borderGain",
	trade: "games.targi.actions.trade",
	silver: "games.targi.actions.silver",
	noblePlay: "games.targi.actions.noblePlay",
	nobleDiscard: "games.targi.actions.nobleDiscard",
	caravan: "games.targi.actions.caravan",
	waterHole: "games.targi.actions.waterHole",
	expand: "games.targi.actions.expand",
	discardTop: "games.targi.actions.discardTop",
	rerollTribe: "games.targi.actions.rerollTribe",
	moveMarker: "games.targi.actions.moveMarker",
	targiaFirst: "games.targi.actions.targiaFirst",
	borderFirst: "games.targi.actions.borderFirst",
	targiaGain: "games.targi.actions.targiaGain",
	targiaDraw: "games.targi.actions.targiaDraw",
	targiaRedraw: "games.targi.actions.targiaRedraw",
	acceptGoods: "games.targi.actions.acceptGoods",
	raidFree: "games.targi.actions.raidFree",
	raidVp: "games.targi.actions.raidVp",
	raidPay: "games.targi.actions.raidPay",
	raidGoods: "games.targi.actions.raidGoods",
	payGoods: "games.targi.actions.payGoods",
	raidCard: "games.targi.actions.raidCard",
	raidUnable: "games.targi.actions.raidUnable",
	discardResource: "games.targi.actions.discardResource",
	giftGoods: "games.targi.actions.giftGoods",
	giftGold: "games.targi.actions.giftGold",
	giftVp: "games.targi.actions.giftVp",
	waterOrVp: "games.targi.actions.waterOrVp",
	stash: "games.targi.actions.stash",
	stashUse: "games.targi.actions.stashUse",
	abilitySwap: "games.targi.actions.abilitySwap",
	swapHand: "games.targi.actions.swapHand",
	abilityTrade: "games.targi.actions.abilityTrade",
	freehand: "games.targi.actions.freehand",
	swapDisplay: "games.targi.actions.swapDisplay",
	moveDisplay: "games.targi.actions.moveDisplay",
	swapDisplayHand: "games.targi.actions.swapDisplayHand",
	wild: "games.targi.actions.wild",
	discountTribe: "games.targi.actions.discountTribe",
	unoccupiedTribe: "games.targi.actions.unoccupiedTribe",
	anyBorder: "games.targi.actions.anyBorder",
	resetAbility: "games.targi.actions.resetAbility",
	discardPick: "games.targi.actions.discardPick",
	useDune: "games.targi.actions.useDune",
	costReward: "games.targi.actions.costReward",
	waterTrade: "games.targi.actions.waterTrade",
	cacheWater: "games.targi.actions.cacheWater",
	joker: "games.targi.actions.joker",
	end: "games.targi.actions.end"
}, J = [
	"date",
	"salt",
	"pepper",
	"gold",
	"water",
	"points"
];
function Y({ name: e, className: t = "" }) {
	return /* @__PURE__ */ f("img", {
		className: `targi-art ${t}`,
		src: `./games/targi/${e}.svg`,
		alt: "",
		draggable: !1
	});
}
function X({ value: e, points: t = 0, signed: n = !1 }) {
	let r = s();
	return /* @__PURE__ */ p("span", {
		className: "targi-resource-line",
		children: [e.map((e, t) => e !== 0 && /* @__PURE__ */ p("span", {
			title: r(v[t]),
			"aria-label": `${e} ${r(v[t])}`,
			children: [/* @__PURE__ */ f(Y, { name: J[t] }), /* @__PURE__ */ p("b", { children: [n && e > 0 ? "+" : "", e] })]
		}, t)), t !== 0 && /* @__PURE__ */ p("span", {
			title: r("games.targi.points"),
			"aria-label": `${t} ${r("games.targi.points")}`,
			children: [/* @__PURE__ */ f(Y, { name: "points" }), /* @__PURE__ */ p("b", { children: [n && t > 0 ? "+" : "", t] })]
		})]
	});
}
function Z({ id: e, detail: t = !1, waived: n = !1 }) {
	let r = s(), i = A(e);
	return i ? /* @__PURE__ */ p("span", {
		className: `targi-card-face targi-tribe${t ? " targi-detail-card" : ""}`,
		"data-group": i.group,
		children: [
			/* @__PURE__ */ f("span", {
				className: "targi-card-cost",
				children: i.costs.map((e, t) => /* @__PURE__ */ p("span", { children: [t > 0 && /* @__PURE__ */ f("i", { children: "/" }), /* @__PURE__ */ f(X, { value: x(e) })] }, t))
			}),
			/* @__PURE__ */ f(Y, {
				name: i.group,
				className: "targi-illustration"
			}),
			/* @__PURE__ */ f("span", {
				className: "targi-card-name",
				children: r(Xe[i.group])
			}),
			/* @__PURE__ */ p("span", {
				className: "targi-card-points",
				children: [/* @__PURE__ */ f(Y, { name: "points" }), i.vp]
			}),
			i.effect && /* @__PURE__ */ f("span", {
				className: "targi-ability-mark",
				"aria-hidden": !0,
				children: "✧"
			}),
			t && /* @__PURE__ */ p("span", {
				className: "targi-card-text",
				children: [r(n ? "games.targi.waiver" : i.textKey), i.bonusCost && /* @__PURE__ */ p("span", {
					className: "targi-optional",
					children: [/* @__PURE__ */ f(X, { value: x(i.bonusCost) }), r("games.targi.optional", { n: i.bonusVp })]
				})]
			})
		]
	}) : e === "wild" ? /* @__PURE__ */ p("span", {
		className: "targi-card-face targi-wild",
		children: [/* @__PURE__ */ f("span", {
			className: "targi-symbols",
			children: [
				"oasis",
				"camp",
				"well",
				"rider",
				"targia"
			].map((e) => /* @__PURE__ */ f(Y, { name: e }, e))
		}), /* @__PURE__ */ f("b", { children: r("games.targi.wild") })]
	}) : e.startsWith("d") ? /* @__PURE__ */ p("span", {
		className: `targi-card-face targi-dune-card${t ? " targi-detail-card" : ""}`,
		children: [
			/* @__PURE__ */ f("span", {
				className: "targi-dunes-art",
				"aria-hidden": !0,
				children: /* @__PURE__ */ p("svg", {
					viewBox: "0 0 200 110",
					children: [
						/* @__PURE__ */ f("path", {
							d: "M0 75Q45 65 83 12Q119 60 200 65V110H0Z",
							fill: "#c59150"
						}),
						/* @__PURE__ */ f("path", {
							d: "M0 87Q75 32 144 48Q120 69 200 81V110H0Z",
							fill: "#e8bb7b"
						}),
						/* @__PURE__ */ f("path", {
							d: "M0 97Q63 79 104 86T200 90V110H0Z",
							fill: "#f3d7a1"
						})
					]
				})
			}),
			/* @__PURE__ */ p("b", { children: [
				r("games.targi.dune"),
				" ",
				Number(e.slice(1)) + 1
			] }),
			t && /* @__PURE__ */ f("span", {
				className: "targi-card-text",
				children: r(Je[e.slice(1)])
			})
		]
	}) : e.startsWith("g") || e.startsWith("w") ? /* @__PURE__ */ f("span", {
		className: "targi-card-face targi-goods-card",
		children: /* @__PURE__ */ f("span", {
			className: "targi-goods-art",
			children: k(e).map((e, t) => /* @__PURE__ */ p("span", { children: [t > 0 && /* @__PURE__ */ f("i", { children: "/" }), e === "?" ? /* @__PURE__ */ f("span", {
				className: "targi-any-good",
				children: J.slice(0, 3).map((e) => /* @__PURE__ */ f(Y, { name: e }, e))
			}) : /* @__PURE__ */ f(X, {
				value: x(e),
				points: +!!e.includes("v")
			})] }, t))
		})
	}) : /* @__PURE__ */ f("span", {
		className: "targi-card-face targi-card-back",
		"aria-label": r("games.targi.tribes"),
		children: /* @__PURE__ */ f("span", {
			"aria-hidden": !0,
			children: "⟡"
		})
	});
}
function Q({ color: e, marker: t = !1, special: n = !1 }) {
	return /* @__PURE__ */ p("svg", {
		className: `targi-pawn${n ? " targi-special" : ""}`,
		viewBox: "0 0 40 50",
		"aria-hidden": !0,
		style: { color: e },
		children: [t ? /* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("ellipse", {
				cx: "20",
				cy: "35",
				rx: "15",
				ry: "7",
				fill: "currentColor",
				stroke: "#34231c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("path", {
				d: "M5 35V28Q20 15 35 28V35Q20 47 5 35",
				fill: "currentColor",
				stroke: "#34231c",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "20",
				cy: "28",
				rx: "15",
				ry: "7",
				fill: "currentColor",
				stroke: "#34231c",
				strokeWidth: "2"
			})
		] }) : /* @__PURE__ */ f("path", {
			d: "M8 46L10 30L6 26L12 18L13 9Q20 0 27 9L28 18L34 26L30 30L32 46L23 46L20 36L17 46Z",
			fill: "currentColor",
			stroke: "#34231c",
			strokeWidth: "2"
		}), n && /* @__PURE__ */ f("path", {
			d: "M14 26H26M20 20V32",
			stroke: "#fff4d9",
			strokeWidth: "3"
		})]
	});
}
function et() {
	return /* @__PURE__ */ f("svg", {
		className: "targi-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ f("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "5",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "6 5",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ f("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-22",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
//#endregion
//#region src/games/targi/view-player.tsx
function $({ id: e, children: t, className: n = "", style: r }) {
	let { ref: i, hidden: o } = a(e);
	return /* @__PURE__ */ f("div", {
		ref: i,
		className: n,
		style: {
			...r,
			visibility: o ? "hidden" : void 0
		},
		children: t
	});
}
var tt = (e, t) => e.target === "ability" ? `ability:${e.card}` : e.target === "resource" ? `resource:${t}` : e.target === "stash" ? `stash:${t}` : e.target;
function nt(e) {
	return /* @__PURE__ */ f(rt, { ...e });
}
function rt({ public: e, private: t, members: n, myRid: r, send: a }) {
	let m = e, h = t, g = s(), _ = o((e) => e.locale), y = m.phase === "done" ? [] : h?.choices ?? [], b = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? u(t, _) : e;
	}, x = (e) => c[(n.find((t) => t.rid === e)?.colorIndex ?? m.players.findIndex((t) => t.rid === e)) % c.length].hex, [S, C] = i(null), [w, D] = i(!1), ne = `${m.round}|${m.phase}|${m.turn}|${y.map((e) => e.id).join(";")}`, O = S?.stamp === ne ? S : null, k = (e) => y.filter((t) => t.kind === "raidCard" ? e === `ability:${t.card}` : [
		"swapDisplay",
		"moveDisplay",
		"swapDisplayHand"
	].includes(t.kind) ? e === `ability:${m.players.find((e) => e.rid === r)?.rows[t.args[0]][t.args[1]]}` : tt(t, r) === e), re = (e, t, n = "", r) => {
		let i = e.currentTarget.getBoundingClientRect(), a = Math.min(390, window.innerWidth - 24);
		C({
			target: t,
			card: n,
			border: r,
			stamp: ne,
			x: Math.min(window.innerWidth - a - 12, Math.max(12, i.right + 8)),
			y: Math.max(12, Math.min(window.innerHeight - Math.min(600, window.innerHeight * .75) - 12, i.top))
		});
	}, j = (e) => {
		a({
			type: "choose",
			id: e.id
		}), C(null);
	}, M = (e, t, n = "", r, i = "") => /* @__PURE__ */ p("button", {
		type: "button",
		className: `targi-piece ${i}`,
		"data-legal": k(e).length > 0,
		"data-selected": O?.target === e,
		onClick: (t) => re(t, e, n, r),
		children: [t, k(e).length > 0 && /* @__PURE__ */ f(et, {})]
	}), N = (e, t, n) => /* @__PURE__ */ p("span", {
		className: "targi-piece-pawns",
		children: [
			m.players.flatMap((r) => {
				let i = e ?? (n === void 0 ? -99 : -n - 1), a = [];
				return t === void 0 && r.workers.includes(i) && a.push(/* @__PURE__ */ f($, {
					id: `pawn:${r.rid}:w:${i}`,
					children: /* @__PURE__ */ f(Q, { color: x(r.rid) })
				}, `${r.rid}:w`)), e !== void 0 && r.extra === e && a.push(/* @__PURE__ */ f($, {
					id: `pawn:${r.rid}:w:${e}`,
					children: /* @__PURE__ */ f(Q, {
						color: x(r.rid),
						special: !0
					})
				}, `${r.rid}:x`)), t !== void 0 && (r.markers.includes(t) || r.specialMarker === t) && a.push(/* @__PURE__ */ f($, {
					id: `pawn:${r.rid}:m:${t}`,
					children: /* @__PURE__ */ f(Q, {
						color: x(r.rid),
						marker: !0,
						special: r.specialMarker === t
					})
				}, `${r.rid}:m`)), a;
			}),
			e === m.robber && /* @__PURE__ */ f($, {
				id: "pawn:robber",
				children: /* @__PURE__ */ f("span", {
					title: g("games.targi.robber"),
					children: /* @__PURE__ */ f(Q, { color: "#b33d38" })
				})
			}),
			m.config.expansion && e === m.targia && /* @__PURE__ */ f($, {
				id: "pawn:targia",
				children: /* @__PURE__ */ f("span", {
					title: g("games.targi.targia"),
					children: /* @__PURE__ */ f(Q, { color: "#8e4f91" })
				})
			})
		]
	}), P = h?.pendingCard || m.pending?.card || "", F = O ? k(O.target) : [], I = (e) => g($e[e.kind] ?? "games.targi.choose", { n: (e.args[0] ?? 0) + 1 }), ie = (e) => /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("strong", { children: I(e) }),
		e.card && (e.kind === "omit" ? /* @__PURE__ */ f("span", { children: g(Ye[e.card]) }) : A(e.card) && [
			"discardPick",
			"resetAbility",
			"abilityTrade",
			"abilitySwap"
		].includes(e.kind) ? /* @__PURE__ */ f(Z, {
			id: e.card,
			detail: !0
		}) : null),
		e.kind === "moveMarker" && /* @__PURE__ */ p("span", { children: [
			Math.floor(e.args[0] / 3) + 1,
			"·",
			e.args[0] % 3 + 1,
			" → ",
			Math.floor(e.args[1] / 3) + 1,
			"·",
			e.args[1] % 3 + 1,
			e.args[2] ? " ×2" : ""
		] }),
		[
			"swapDisplay",
			"moveDisplay",
			"swapDisplayHand"
		].includes(e.kind) && /* @__PURE__ */ p("span", { children: [
			g("games.targi.moveFrom", {
				r: e.args[0] + 1,
				c: e.args[1] + 1
			}),
			e.kind === "swapDisplay" && /* @__PURE__ */ p(d, { children: [" → ", g("games.targi.swapPosition", {
				r: e.args[2] + 1,
				c: e.args[3] + 1
			})] }),
			e.kind === "moveDisplay" && /* @__PURE__ */ p(d, { children: [" → ", g("games.targi.row", { n: e.args[2] + 1 })] })
		] }),
		["swapHand", "swapDisplayHand"].includes(e.kind) && /* @__PURE__ */ f(Z, {
			id: e.card,
			detail: !0
		}),
		e.pay.some(Boolean) && /* @__PURE__ */ p("span", {
			className: "targi-choice-res",
			children: [g("games.targi.pay"), /* @__PURE__ */ f(X, { value: e.pay })]
		}),
		(e.gain.some(Boolean) || e.vp !== 0) && /* @__PURE__ */ p("span", {
			className: "targi-choice-res",
			children: [e.vp < 0 ? g("games.targi.pay") : g("games.targi.receive"), /* @__PURE__ */ f(X, {
				value: e.gain,
				points: Math.abs(e.vp)
			})]
		}),
		e.kind === "buy" && e.args[1] > 0 && /* @__PURE__ */ p("span", { children: [g("games.targi.cache"), /* @__PURE__ */ f(Y, { name: "gold" })] }),
		e.kind === "buy" && e.args[3] > 0 && /* @__PURE__ */ f("span", { children: g("games.targi.waiver") })
	] }), L = (e) => /* @__PURE__ */ p("section", {
		className: "targi-player",
		"data-expanded": w,
		"data-current": m.phase !== "done" && m.turn === e.rid,
		style: { "--targi-player": x(e.rid) },
		children: [
			/* @__PURE__ */ p($, {
				id: `seat:${e.rid}`,
				className: "targi-player-heading",
				children: [
					/* @__PURE__ */ f("span", { className: "targi-seat-color" }),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "targi-player-name",
						onClick: () => D(!w),
						"aria-expanded": w,
						children: b(e.rid)
					}),
					/* @__PURE__ */ p("span", { children: [e.vp, /* @__PURE__ */ f(Y, { name: "points" })] }),
					/* @__PURE__ */ f("small", { children: g("games.targi.handCount", { n: e.handCount }) })
				]
			}),
			/* @__PURE__ */ f($, {
				id: `resource:${e.rid}`,
				className: "targi-bag",
				children: M(`resource:${e.rid}`, /* @__PURE__ */ f(d, { children: e.bag.map((e, t) => (t < 4 || m.config.expansion) && /* @__PURE__ */ p("span", {
					title: g(v[t]),
					children: [/* @__PURE__ */ f(Y, { name: J[t] }), /* @__PURE__ */ f("b", { children: e })]
				}, t)) }))
			}),
			/* @__PURE__ */ f("div", {
				className: "targi-rows",
				children: e.rows.map((t, n) => /* @__PURE__ */ p($, {
					id: `row:${e.rid}:${n}`,
					className: "targi-row",
					children: [/* @__PURE__ */ f("span", {
						className: "targi-row-number",
						children: n + 1
					}), Array.from({ length: 4 }, (r, i) => /* @__PURE__ */ f($, {
						id: `card:${e.rid}:${n}:${i}`,
						className: "targi-row-slot",
						children: t[i] ? M(`ability:${t[i]}`, /* @__PURE__ */ p(d, { children: [
							/* @__PURE__ */ f(Z, {
								id: t[i],
								waived: e.waived === t[i]
							}),
							e.waived === t[i] && /* @__PURE__ */ p("span", {
								className: "targi-waived",
								children: ["2", /* @__PURE__ */ f(Y, { name: "points" })]
							}),
							e.cache[t[i]] > 0 && /* @__PURE__ */ p("span", {
								className: "targi-cache",
								children: [/* @__PURE__ */ f(Y, { name: t[i] === "b35" ? "gold" : "water" }), e.cache[t[i]]]
							}),
							e.used.includes(t[i]) && /* @__PURE__ */ f("span", {
								className: "targi-used",
								children: g("games.targi.used")
							})
						] }), t[i]) : i === t.length ? M(`row:${e.rid}:${n}`, /* @__PURE__ */ f("span", {
							className: "targi-empty",
							children: i + 1
						}), P) : /* @__PURE__ */ f("span", {
							className: "targi-empty",
							children: i + 1
						})
					}, i))]
				}, n))
			}),
			e.rid === r && /* @__PURE__ */ f($, {
				id: `hand:${e.rid}`,
				className: "targi-hand",
				children: (h?.hand ?? []).map((e, t) => /* @__PURE__ */ f($, {
					id: `hand:${t}`,
					children: M(`hand:${t}`, /* @__PURE__ */ f(Z, { id: e }), e)
				}, t))
			}),
			e.rid !== r && /* @__PURE__ */ f($, {
				id: `hand:${e.rid}`,
				className: "targi-hand-hidden",
				children: Array.from({ length: e.handCount }, (e, t) => /* @__PURE__ */ f(Z, { id: "back" }, t))
			}),
			e.mini.length > 0 && /* @__PURE__ */ f("div", {
				className: "targi-mini",
				children: e.mini.map((t) => /* @__PURE__ */ p("span", {
					title: g(Ye[t]),
					children: [t === "joker" ? /* @__PURE__ */ f(Y, { name: "date" }) : t === "targi" ? /* @__PURE__ */ f(Q, {
						color: x(e.rid),
						special: !0
					}) : t === "marker" ? /* @__PURE__ */ f(Q, {
						color: x(e.rid),
						marker: !0,
						special: !0
					}) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Y, { name: "points" }), /* @__PURE__ */ f("b", { children: "2" })] }), /* @__PURE__ */ f("small", { children: g(Ye[t]) })]
				}, t))
			}),
			e.stash && /* @__PURE__ */ p($, {
				id: `stash:${e.rid}`,
				className: "targi-stash",
				children: [/* @__PURE__ */ f("small", { children: g("games.targi.stash") }), M(`stash:${e.rid}`, /* @__PURE__ */ f(Z, { id: e.stash }), e.stash)]
			})
		]
	}, e.rid), R = m.pending ? g(Qe[m.pending.kind] ?? Ze[m.phase]) : g(Ze[m.phase]), z = k("control"), B = [m.players.find((e) => e.rid !== r), m.players.find((e) => e.rid === r)].filter((e) => !!e);
	return B.length !== 2 && B.splice(0, B.length, ...m.players), /* @__PURE__ */ p("div", {
		className: "targi-root",
		children: [/* @__PURE__ */ p(l, {
			adaptive: !0,
			className: "targi-screen",
			banner: /* @__PURE__ */ p("header", {
				className: "targi-phase",
				children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("b", { children: g("games.targi.round", { n: m.round }) }), /* @__PURE__ */ f("span", { children: m.phase === "done" ? g("games.targi.phase.done") : y.length ? R : g("games.targi.waiting", { name: b(m.turn) }) })] }), /* @__PURE__ */ p("small", { children: ["TARGI", /* @__PURE__ */ f("span", { children: m.config.expansion ? g("games.targi.expansion") : g("games.targi.base") })] })]
			}),
			actionsHeight: "targi-actions-height",
			actions: /* @__PURE__ */ f("div", {
				className: "targi-actions",
				children: z.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => j(e),
					children: I(e)
				}, e.id))
			}),
			children: [/* @__PURE__ */ p("div", {
				className: "targi-table",
				children: [
					L(B[0]),
					/* @__PURE__ */ p("main", {
						className: "targi-market",
						children: [
							m.config.expansion && /* @__PURE__ */ f("div", {
								className: "targi-dunes",
								children: m.dunes.map((e, t) => /* @__PURE__ */ f($, {
									id: `dune:${t}`,
									children: M(`dune:${t}`, /* @__PURE__ */ p(d, { children: [e ? /* @__PURE__ */ f(Z, { id: e }) : /* @__PURE__ */ f("span", { className: "targi-dune-empty" }), N(void 0, void 0, t)] }), e ?? "")
								}, t))
							}),
							/* @__PURE__ */ p($, {
								id: "board",
								className: "targi-board",
								children: [Array.from({ length: 25 }, (e, t) => {
									let n = Math.floor(t / 5), r = t % 5, i = ee.findIndex(([e, t]) => e === n && t === r);
									if (i >= 0) return /* @__PURE__ */ f($, {
										id: `border:${i}`,
										className: "targi-border",
										style: {
											gridRow: n + 1,
											gridColumn: r + 1
										},
										children: M(`border:${i}`, /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("span", {
											className: `targi-card-face targi-border-face${E(i) ? " targi-raid-card" : ""}`,
											children: [
												/* @__PURE__ */ f("small", { children: i + 1 }),
												i in T ? /* @__PURE__ */ f(Y, { name: J[T[i]] }) : /* @__PURE__ */ f("span", {
													className: "targi-border-emblem",
													"aria-hidden": !0,
													children: i === 0 ? "♜" : i === 4 ? "⇄" : i === 8 ? "↗" : i === 9 ? /* @__PURE__ */ f(Y, { name: "points" }) : i === 12 ? /* @__PURE__ */ f(Y, { name: m.config.expansion ? "water" : "camp" }) : i === 13 ? /* @__PURE__ */ f(Y, { name: "oasis" }) : /* @__PURE__ */ f(Q, { color: "#b33d38" })
												}),
												/* @__PURE__ */ f("strong", { children: i === 12 && m.config.expansion ? g("games.targi.waterHole") : g(Ke[i]) })
											]
										}), N(i)] }), "", i)
									}, t);
									let a = (n - 1) * 3 + r - 1, o = m.central[a];
									return /* @__PURE__ */ f($, {
										id: `central:${a}`,
										className: "targi-central",
										style: {
											gridRow: n + 1,
											gridColumn: r + 1
										},
										children: M(`central:${a}`, /* @__PURE__ */ p(d, { children: [o.card ? /* @__PURE__ */ f(Z, { id: o.card }) : /* @__PURE__ */ f(Z, { id: "back" }), N(void 0, a)] }), o.card ?? "")
									}, t);
								}), /* @__PURE__ */ f("svg", {
									className: "targi-intersections",
									viewBox: "0 0 500 500",
									"aria-hidden": !0,
									children: m.players.flatMap((e) => e.workers.filter((e) => e >= 0).map((t) => {
										let [n, r] = ee[t];
										return /* @__PURE__ */ f("line", {
											x1: n === 0 || n === 4 ? r * 100 + 50 : 100,
											y1: n === 0 || n === 4 ? 100 : n * 100 + 50,
											x2: n === 0 || n === 4 ? r * 100 + 50 : 400,
											y2: n === 0 || n === 4 ? 400 : n * 100 + 50,
											stroke: x(e.rid),
											strokeWidth: "2",
											strokeDasharray: "5 9",
											opacity: ".45"
										}, `${e.rid}:${t}`);
									}))
								})]
							}),
							/* @__PURE__ */ p("div", {
								className: "targi-supplies",
								children: [
									/* @__PURE__ */ f($, {
										id: "deck",
										children: M("deck", /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Z, { id: m.tribeTop ?? "back" }), /* @__PURE__ */ p("span", { children: [
											g("games.targi.tribes"),
											" ",
											m.tribesLeft
										] })] }), m.tribeTop ?? "")
									}),
									/* @__PURE__ */ p($, {
										id: "goodsDeck",
										children: [/* @__PURE__ */ f(Z, { id: "back" }), /* @__PURE__ */ p("span", { children: [
											g("games.targi.goods"),
											" ",
											m.goodsLeft
										] })]
									}),
									/* @__PURE__ */ f($, {
										id: "discard",
										children: M("discard", /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Z, { id: m.discard.at(-1) ?? "back" }), /* @__PURE__ */ p("span", { children: [
											g("games.targi.discard"),
											" ",
											m.discard.length
										] })] }), m.discard.at(-1) ?? "")
									}),
									/* @__PURE__ */ f($, {
										id: "pending",
										className: "targi-pending",
										children: M("pending", /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Z, { id: P || "back" }), /* @__PURE__ */ f("span", { children: g("games.targi.pending") })] }), P)
									})
								]
							})
						]
					}),
					L(B[1])
				]
			}), m.phase === "select" && h && !m.players.find((e) => e.rid === r)?.chosen && /* @__PURE__ */ p("div", {
				className: "targi-token-select",
				children: [/* @__PURE__ */ f("h2", { children: g("games.targi.phase.select") }), /* @__PURE__ */ f("div", { children: y.filter((e) => e.kind === "omit").map((e) => /* @__PURE__ */ p("button", {
					onClick: () => j(e),
					children: [/* @__PURE__ */ f("b", { children: g(Ye[te[e.args[0]]]) }), /* @__PURE__ */ f("span", { children: g("games.targi.actions.omit") })]
				}, e.id)) })]
			})]
		}), O && /* @__PURE__ */ f("div", {
			className: "targi-inspector-backdrop",
			onClick: () => C(null),
			children: /* @__PURE__ */ p("section", {
				className: "targi-inspector",
				role: "dialog",
				"aria-label": g("games.targi.details"),
				style: {
					left: O.x,
					top: O.y
				},
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("b", { children: O.border === void 0 ? g("games.targi.details") : g(Ke[O.border]) }), /* @__PURE__ */ f("button", {
					type: "button",
					"aria-label": g("games.targi.close"),
					onClick: () => C(null),
					children: "×"
				})] }), /* @__PURE__ */ p("div", {
					className: "targi-inspector-content",
					children: [
						O.card && /* @__PURE__ */ f(Z, {
							id: O.card,
							detail: !0,
							waived: m.players.some((e) => e.waived === O.card)
						}),
						O.border !== void 0 && /* @__PURE__ */ f("p", { children: g(qe[O.border]) }),
						F.map((e) => /* @__PURE__ */ f("button", {
							type: "button",
							className: "targi-choice",
							onClick: () => j(e),
							children: ie(e)
						}, e.id))
					]
				})]
			})
		})]
	});
}
//#endregion
//#region src/games/targi/bot.ts
var it = {
	goods: .35,
	gold: 1.8,
	water: .675,
	tribe: 2,
	engine: .9,
	row: 1,
	intersection: 1
};
function at(e, t, n) {
	return e.reduce((e, r, i) => e + r * (i === 3 ? n.gold : i === 4 ? n.water : n.goods * (t[i] >= 4 ? .5 : t[i] < 2 ? 1.25 : 1)), 0);
}
function ot(e, t, n, r) {
	let i = t.players.find((e) => e.rid === n), a = i.rows.flat(), o = Math.max(a.length, t.round * .7) / 12, s = (e) => {
		let t = A(e);
		if (!t) return 0;
		let n = Math.min(...t.costs.map((e) => at(x(e), i.bag, r))), a = Math.min(...t.costs.map((e) => x(e).reduce((e, t, n) => e + Math.max(0, t - i.bag[n]), 0)));
		return t.vp + r.tribe + (t.effect ? r.engine * (1 - o * .6) : 0) - n * .35 - a * .6;
	}, c = (e) => {
		let n = t.central[e];
		return !n.card || !n.face ? 0 : n.type === "tribe" ? s(n.card) : Math.max(...k(n.card).map((e) => e === "?" ? r.goods : at(x(e), i.bag, r) + Number(e.includes("v"))));
	}, l = (e) => {
		if (e in T) {
			let t = [
				0,
				0,
				0,
				0,
				0
			];
			return t[T[e]] = 1, at(t, i.bag, r);
		}
		return e === 0 ? i.handCount ? 1.9 : .1 : e === 4 ? S(i.bag) > 5 && i.bag[3] < 2 ? 1.5 : .35 : e === 8 ? i.markers.length ? .9 : .3 : e === 9 ? i.bag[3] > 1 || S(i.bag) > 6 ? 2 : .2 : e === 12 ? t.config.expansion ? r.water : 1.05 : e === 13 ? t.tribeTop ? s(t.tribeTop) : 1.8 : 0;
	}, u = (e) => e.reduce((e, t, n) => e + (n === 3 ? t * r.gold : n === 4 ? t * r.water : Array.from({ length: t }, (e, t) => r.goods * (t < 2 ? 1.25 : t < 4 ? 1 : .5)).reduce((e, t) => e + t, 0)), 0), d = i.bag.map((t, n) => t + e.gain[n] - e.pay[n]), f = e.vp + u(d) - u(i.bag);
	if (e.kind === "place" || e.kind === "extra") {
		let n = D(i.workers), a = D([...i.workers, e.args[0]]).filter((e) => !n.includes(e));
		if (f += l(e.args[0]) + r.intersection * a.reduce((e, t) => e + c(t), 0), i.workers.length === 0) {
			let t = [
				0,
				1,
				2,
				4,
				5,
				6,
				8,
				9,
				10,
				12,
				13,
				14
			].map((t) => D([t, e.args[0]]).reduce((e, t) => e + c(t), 0));
			f += Math.max(...t) * .55;
		}
		t.config.expansion && e.args[0] === t.targia && (f += r.goods), e.args[1] && (f -= .25);
	}
	if (e.kind === "placeDune" && (f += {
		d0: 2.1,
		d1: 3,
		d2: .8,
		d3: 2.2,
		d4: 1.7,
		d5: 2.5,
		d6: 2,
		d7: 2.3,
		d8: 2,
		d9: 3.2,
		d10: 2.4,
		d11: 1.5,
		d12: 2.4,
		d13: 1.6,
		d14: 2.1,
		d15: 2.6,
		d16: 2.5,
		d17: .5,
		d18: 1.5,
		d19: 2.2
	}[e.card] - (i.workers.some((e) => e < 0) ? .9 : .3)), e.kind === "buy") {
		let t = A(e.card), n = i.rows[e.args[0]].map((e) => e === "wild" ? t.group : A(e).group);
		f += t.vp + r.tribe + (t.effect && !e.args[3] ? r.engine * (1 - o * .7) : 0) + (e.args[3] ? 2 : 0), n.length && n.every((e) => e === t.group) ? f += r.row * (n.length === 3 ? 4 : n.length * .4) : !n.includes(t.group) && new Set(n).size === n.length && (f += r.row * (n.length === 3 ? 2 : .3)), e.args[1] && (f += .25);
	}
	return e.kind === "keep" && (f += s(e.card) * .4 - (o > .85 ? 1.5 : 0)), e.kind === "work" && (e.target.startsWith("central") ? f += c(e.args[0]) + (t.central[e.args[0]].type === "goods" ? .6 : -.5) : e.target.startsWith("border") ? f += l(e.args[0]) : f += 2), e.kind === "moveMarker" && (f += c(e.args[1]) - c(e.args[0]) - .2), e.kind === "wild" && (f += r.tribe + 1), [
		"noblePlay",
		"freehand",
		"expand",
		"unoccupiedTribe",
		"discountTribe",
		"discardTop",
		"discardPick"
	].includes(e.kind) && (f += e.card ? s(e.card) : 1.5), e.kind === "extraMarker" && (f += c(e.args[0])), e.kind === "omit" && (f += e.card === "marker" ? 1 : e.card === "joker" ? -1 : 0), [
		"end",
		"skipExtra",
		"skipMarker",
		"done",
		"cancel",
		"discardTribe"
	].includes(e.kind) && (f -= e.kind === "end" && i.work.length ? 20 : 0), e.kind === "cancel" && t.pending?.kind === "tribe" && (f -= 20), ["trade", "waterTrade"].includes(e.kind) && (f -= .1), e.kind === "cacheWater" && (f -= .6), e.kind === "targiaDraw" && --f, e.kind === "targiaRedraw" && (f -= 2), e.kind === "acceptGoods" && (f += 1), e.kind === "useDune" && (f += 1.5), e.kind === "raidCard" && (f -= A(e.card)?.vp ?? 0), (e.kind === "stash" || e.kind === "stashUse") && (f += 1), e.kind === "resetAbility" && (f += .5), f;
}
function st(e = it) {
	return (t, n) => {
		let r = t.private?.choices ?? [];
		if (!r.length) return null;
		let i = r.map((r) => ({
			c: r,
			value: ot(r, t.public, n.rid, e)
		})).sort((e, t) => t.value - e.value || e.c.id.localeCompare(t.c.id)), a = n.difficulty === "weak" ? i.slice(0, Math.max(1, Math.ceil(i.length * .5))) : i.slice(0, 1), o = a[0];
		if (a.length > 1) {
			let e = Math.floor(4294967296 / a.length) * a.length, t = /* @__PURE__ */ new Uint32Array(1);
			do
				crypto.getRandomValues(t);
			while (t[0] >= e);
			o = a[t[0] % a.length];
		}
		return { action: {
			type: "choose",
			id: o.c.id
		} };
	};
}
var ct = st(), lt = (e, t, n) => n("games.targi.hint");
//#endregion
//#region src/games/targi/fx.tsx
function ut({ box: e, card: t, ms: i }) {
	let a = r(null);
	return n(() => {
		let e = a.current?.animate([{ transform: "rotateY(180deg)" }, { transform: "rotateY(0deg)" }], {
			duration: i,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [i]), /* @__PURE__ */ f("div", {
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			perspective: 700
		},
		children: /* @__PURE__ */ p("div", {
			ref: a,
			className: "targi-flip",
			children: [/* @__PURE__ */ f("div", { children: /* @__PURE__ */ f(Z, { id: t }) }), /* @__PURE__ */ f("div", { children: /* @__PURE__ */ f(Z, { id: "back" }) })]
		})
	});
}
function dt(e, t = 28, n = 36) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
var ft = { scene(e, t) {
	let n = e.data;
	if (!n) return null;
	let r = t.queued ? 180 : 520, i = [], a = n.moves.map((e, n) => {
		let a = t.anchor(e.from) ?? t.anchor(`seat:${e.owner}`), o = t.anchor(e.to) ?? t.anchor(`seat:${e.owner}`);
		if (!a || !o || !a.w || !o.w) return null;
		e.hide && !t.queued && i.push(e.hide);
		let s = e.owner === "robber" ? "#b33d38" : e.owner === "targia" ? "#8e4f91" : c[(t.member(e.owner)?.colorIndex ?? 0) % c.length].hex;
		return /* @__PURE__ */ f(h, {
			from: e.pawn ? dt(a) : a,
			to: e.pawn ? dt(o) : o,
			ms: r,
			children: /* @__PURE__ */ f("span", {
				className: "targi-fx-sprite",
				style: {
					width: e.pawn ? 28 : a.w,
					height: e.pawn ? 36 : a.h
				},
				children: e.pawn ? /* @__PURE__ */ f(Q, {
					color: s,
					marker: e.marker,
					special: e.special
				}) : /* @__PURE__ */ f(Z, { id: e.card || "back" })
			})
		}, `m${n}`);
	});
	for (let [e, o] of n.flips.entries()) {
		let n = t.anchor(o.at);
		n?.w && (t.queued || i.push(o.at), a.push(/* @__PURE__ */ f(ut, {
			box: n,
			card: o.card,
			ms: r
		}, `f${e}`)));
	}
	for (let e of n.deltas) {
		let n = t.anchor(`resource:${e.rid}`), i = t.anchor(e.source) ?? t.anchor("board");
		if (n?.w && (a.push(/* @__PURE__ */ f(m, {
			at: n,
			ms: r,
			children: /* @__PURE__ */ f("span", {
				className: "targi-resource-float",
				children: /* @__PURE__ */ f(X, {
					value: e.resources,
					points: e.vp,
					signed: !0
				})
			})
		}, `r${e.rid}`)), i?.w)) for (let [t, o] of e.resources.entries()) o && a.push(/* @__PURE__ */ f(h, {
			from: dt(o > 0 ? i : n, 24, 24),
			to: dt(o > 0 ? n : i, 24, 24),
			ms: r,
			children: /* @__PURE__ */ f(Y, { name: J[t] })
		}, `r${e.rid}:${t}`));
	}
	return a.some(Boolean) ? {
		ms: 560,
		node: a,
		hide: i
	} : null;
} }, pt = [
	["tokens", "games.targi.tokensScore"],
	["cards", "games.targi.cardsScore"],
	["rows", "games.targi.rowsScore"],
	["abilities", "games.targi.abilitiesScore"],
	["water", "games.targi.waterScore"],
	["total", "games.targi.total"]
];
function mt(e) {
	let { result: t, members: n, myRid: r, onPlayAgain: a, onBackToLobby: c, hintCount: d } = e, m = e.public, h = s(), _ = o((e) => e.locale), [v, y] = i(!0), b = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? u(t, _) : e;
	};
	return /* @__PURE__ */ p("div", {
		className: "targi-over-root",
		children: [
			/* @__PURE__ */ f("div", {
				className: "targi-final-table",
				inert: v,
				children: /* @__PURE__ */ f(rt, {
					...e,
					send: () => void 0
				})
			}),
			/* @__PURE__ */ f("button", {
				className: "targi-return-score",
				type: "button",
				hidden: v,
				onClick: () => y(!0),
				children: h("games.targi.back")
			}),
			/* @__PURE__ */ f("div", {
				className: "targi-over-panel targi-root",
				hidden: !v,
				children: /* @__PURE__ */ f(l, {
					adaptive: !0,
					className: "targi-over-screen",
					banner: /* @__PURE__ */ p("header", {
						className: "targi-over-heading",
						children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("small", { children: "TARGI" }), /* @__PURE__ */ f("h1", { children: h("games.targi.final") })] }), /* @__PURE__ */ f("button", {
							type: "button",
							"aria-label": h("games.targi.review"),
							title: h("games.targi.review"),
							onClick: () => y(!1),
							children: "⌄"
						})]
					}),
					actionsHeight: "targi-over-actions-height",
					actions: /* @__PURE__ */ p("footer", {
						className: "targi-over-actions",
						children: [
							a && /* @__PURE__ */ f(g, {
								compact: !0,
								label: h("games.targi.again"),
								confirmLabel: h("games.targi.confirmAgain"),
								onConfirm: a,
								className: "targi-over-button"
							}),
							c && /* @__PURE__ */ f(g, {
								compact: !0,
								label: h("games.targi.lobby"),
								confirmLabel: h("games.targi.confirmLobby"),
								onConfirm: c,
								className: "targi-over-button"
							}),
							!a && !c && /* @__PURE__ */ f("span", { children: h("session.result.waitHost") })
						]
					}),
					children: /* @__PURE__ */ p("div", {
						className: "targi-over-content",
						children: [
							/* @__PURE__ */ p("div", {
								className: "targi-result-banner",
								children: [
									/* @__PURE__ */ f(Y, { name: "rider" }),
									/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", { children: t.winner.length > 1 ? h("games.targi.tie") : h("games.targi.win") }), /* @__PURE__ */ f("strong", { children: t.winner.map(b).join(" / ") })] }),
									/* @__PURE__ */ f(Y, { name: "oasis" })
								]
							}),
							d !== void 0 && d > 0 && /* @__PURE__ */ f("p", {
								className: "targi-over-hint",
								children: h("session.hint.usedCount", { n: d })
							}),
							/* @__PURE__ */ p("table", {
								className: "targi-score-table",
								children: [/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									"aria-label": h("games.targi.points"),
									children: /* @__PURE__ */ f(Y, { name: "points" })
								}), m.players.map((e) => /* @__PURE__ */ p("th", { children: [b(e.rid), e.rid === r && /* @__PURE__ */ f("small", { children: h("lobby.you") })] }, e.rid))] }) }), /* @__PURE__ */ f("tbody", { children: pt.filter(([e]) => e !== "water" || m.config.expansion).map(([e, t]) => /* @__PURE__ */ p("tr", {
									"data-total": e === "total",
									children: [/* @__PURE__ */ f("th", {
										scope: "row",
										children: h(t)
									}), m.players.map((t) => /* @__PURE__ */ f("td", { children: m.scores[t.rid][e] }, t.rid))]
								}, e)) })]
							}),
							/* @__PURE__ */ f("div", {
								className: "targi-over-displays",
								children: m.players.map((e) => /* @__PURE__ */ p("section", { children: [
									/* @__PURE__ */ p("h2", { children: [b(e.rid), /* @__PURE__ */ p("b", { children: [m.scores[e.rid].total, /* @__PURE__ */ f(Y, { name: "points" })] })] }),
									t.autopilot?.[e.rid] !== void 0 && t.autopilot[e.rid] > 0 && /* @__PURE__ */ f("p", { children: h("session.autopilot.share", { n: Math.round(t.autopilot[e.rid] * 100) }) }),
									/* @__PURE__ */ f("div", {
										className: "targi-over-cards",
										children: e.rows.map((t, n) => /* @__PURE__ */ f("div", { children: t.map((t, n) => /* @__PURE__ */ f(Z, {
											id: t,
											waived: e.waived === t
										}, n)) }, n))
									})
								] }, e.rid))
							})
						]
					})
				})
			})
		]
	});
}
//#endregion
//#region src/games/targi/options.tsx
function ht({ value: e, onChange: t }) {
	let n = s(), r = pe.safeParse(e), i = r.success ? r.data : pe.parse(void 0);
	return /* @__PURE__ */ p("div", { children: [
		/* @__PURE__ */ f(_, {
			checked: i.expansion,
			label: n("games.targi.optExpansion"),
			hint: n("games.targi.expansionOn"),
			accent: W.accent,
			onChange: () => t({
				...i,
				expansion: !i.expansion,
				mixed: !i.expansion && i.mixed
			})
		}),
		/* @__PURE__ */ f(_, {
			checked: i.mixed && i.expansion,
			disabled: !i.expansion,
			label: n("games.targi.optMixed"),
			hint: n("games.targi.mixedOn"),
			accent: W.accent,
			onChange: () => t({
				...i,
				mixed: !i.mixed
			})
		}),
		/* @__PURE__ */ f(_, {
			checked: i.tokens,
			label: n("games.targi.optTokens"),
			hint: n("games.targi.tokensOn"),
			accent: W.accent,
			onChange: () => t({
				...i,
				tokens: !i.tokens
			})
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/targi/entry.tsx
var gt = {
	definition: Ge,
	View: nt,
	bot: ct,
	describe: lt,
	fx: ft,
	OverView: mt,
	Options: ht,
	locales: {
		zh: {
			name: "大漠商豪",
			desc: "在沙漠卡阵中派遣塔尔吉，以交点获取货物，经营三行部族阵列。",
			date: "椰枣",
			salt: "盐",
			pepper: "胡椒",
			gold: "金币",
			water: "水",
			points: "分数",
			round: "第{{n}}轮",
			raid: "突袭",
			robber: "强盗",
			targia: "塔尔吉娅",
			worker: "塔尔吉",
			marker: "部族标记",
			goods: "货物",
			tribes: "部族",
			dune: "沙丘",
			hand: "手牌",
			pending: "当前卡牌",
			noAbility: "没有文字能力。",
			wild: "自由部族符号",
			close: "关闭",
			details: "查看卡牌",
			pay: "支付",
			receive: "获得",
			optional: "额外支付可获得{{n}}分",
			row: "第{{n}}行",
			choose: "选择",
			waiting: "等待{{name}}行动",
			yourTurn: "轮到你行动",
			handCount: "手牌{{n}}张",
			remaining: "剩余{{n}}张",
			title: "撒哈拉的商路",
			myTribe: "我的部族",
			opponent: "对手部族",
			turn: "当前行动者",
			invalid: "这个行动已不可用，请重新选择。",
			hint: "根据当前货物、部族费用与交点收益选择行动。",
			optExpansion: "官方扩展",
			expansionOn: "2016扩展：水、沙丘与塔尔吉娅",
			optMixed: "部族牌组",
			mixedOn: "基础与扩展混合，每种符号随机选9张",
			optTokens: "2015行动标记",
			tokensOn: "每人秘密选择四种标记中的三种",
			base: "基础版",
			expansion: "扩展版",
			bonus: "额外分数",
			waiver: "放弃文字能力，终局获得2分",
			cache: "卡上储备",
			stash: "保留的沙丘",
			final: "商路的收获",
			win: "获胜",
			tie: "共同获胜",
			review: "查看最终牌桌",
			back: "返回计分",
			again: "再来一局",
			lobby: "返回大厅",
			total: "总分",
			tokensScore: "分数标记",
			cardsScore: "部族牌分数",
			rowsScore: "横行奖励",
			abilitiesScore: "卡牌能力",
			waterScore: "剩余水",
			choosePayment: "选择支付方式与放置位置",
			opponentTurn: "对手正在行动",
			help: "点击卡牌查看能力；高亮物件可以操作。",
			mini: {
				joker: "万能货物",
				targi: "额外塔尔吉",
				marker: "额外部族标记",
				waiver: "弃权标记"
			},
			group: {
				oasis: "绿洲",
				rider: "骆驼骑手",
				camp: "营地",
				well: "水井",
				targia: "塔尔吉娅"
			},
			phase: {
				select: "秘密选择移除一种行动标记",
				placement: "将塔尔吉放在边界卡或沙丘上",
				extra: "使用额外塔尔吉，或跳过",
				marker: "使用额外部族标记，或跳过",
				actions: "选择一名塔尔吉或部族标记，执行所在卡牌的行动",
				raid: "支付突袭要求",
				between: "揭开补充的中央卡牌",
				advance: "新一轮开始",
				done: "对局结束"
			},
			border: {
				0: "贵族",
				1: "椰枣",
				2: "盐",
				3: "突袭",
				4: "商人",
				5: "胡椒",
				6: "椰枣",
				7: "突袭",
				8: "蜃景",
				9: "银匠",
				10: "胡椒",
				11: "突袭",
				12: "商队",
				13: "部族扩张",
				14: "盐",
				15: "突袭"
			},
			borderText: {
				0: "将1张手牌支付打出，或弃掉1张手牌。扩展中弃牌还获得1水及1个任意货物。",
				1: "获得1椰枣。",
				2: "获得1盐。",
				3: "基础版：支付1个任意货物或1分。扩展：支付1胡椒或1分。",
				4: "可以多次兑换：3个同种货物换1金币，2个同种货物换1个异种货物。扩展还允许2水换1金币、1水换1个货物。",
				5: "获得1胡椒。",
				6: "获得1椰枣。",
				7: "基础版：支付2个任意货物或1分。扩展：支付1椰枣和1盐，或1分。",
				8: "移动一枚部族标记至未被占据的中央卡牌。扩展中只能移至相邻格。",
				9: "基础版只兑换一次：2个同种货物换1分，4个同种货物换3分，1金币换2分，2金币换4分。扩展可兑换至多两次，每次2个任意货物换1分，或1金币换2分。",
				10: "获得1胡椒。",
				11: "基础版：支付3个任意货物或2分。扩展：支付1椰枣、1盐、1胡椒，或2分。",
				12: "翻开1张货物卡并获得其奖励。扩展改为水源，获得1水。",
				13: "翻开1张部族卡，可支付打出、保留为手牌或弃掉。扩展可支付1水弃掉重抽，次数不限。",
				14: "获得1盐。",
				15: "基础版：支付1金币或3分。扩展：支付1金币，或弃掉任一横行最右侧的部族卡。随后立即终局。"
			},
			dunes: {
				0: "支付2水，将沙丘放进任一横行，作为没有印刷分数的自由部族卡。终局时按不同奖励分别选择最有利的符号。",
				1: "从自己的部族标记处取一张中央部族卡，只支付1水打出。",
				2: "交换阵列中的两张部族卡，或将手牌与阵列中一张卡交换；新打出的手牌照常触发能力。",
				3: "获得1分、1水和1个任意货物。",
				4: "使用塔尔吉娅的能力，并获得1分。",
				5: "依次使用强盗所在边界卡与其正对边界卡的行动。",
				6: "获得2分。",
				7: "获得1水和1金币。",
				8: "自己的阵列中每有一张没有文字能力的部族卡，获得1个任意货物。",
				9: "各获得1椰枣、1盐、1胡椒，再获得1个任意货物。",
				10: "使用任意一张非角落边界卡的行动，并获得1个任意货物。",
				11: "获得3水。",
				12: "翻开部族牌堆顶牌，获得其一种费用组合所示资源；忽略括号中的资源，随后弃掉该牌。",
				13: "获得2水和1个任意货物。",
				14: "获得1分和2个任意货物。",
				15: "获得1金币和1个任意货物。",
				16: "取得一张未被占据的中央部族卡，可支付打出或保留为手牌。",
				17: "重新启用自己一张已使用的、每局一次的部族卡能力。",
				18: "从部族弃牌堆中选一张，可支付打出或保留为手牌。",
				19: "依次翻开2张货物卡，分别获得奖励。"
			},
			actions: {
				discardHand: "弃掉超额手牌",
				omit: "移除这个标记",
				place: "放置塔尔吉",
				placeDune: "前往沙丘",
				extra: "放置额外塔尔吉",
				skipExtra: "跳过",
				extraMarker: "放置额外标记",
				skipMarker: "跳过",
				work: "执行此处行动",
				buy: "放入第{{n}}行",
				keep: "保留为手牌",
				discardTribe: "弃掉此牌",
				cancel: "取消",
				done: "结束此行动",
				gain: "获得货物",
				goodsGain: "获得奖励",
				borderGain: "获得货物",
				trade: "兑换",
				silver: "兑换分数",
				noblePlay: "支付打出手牌",
				nobleDiscard: "弃掉手牌",
				caravan: "翻开货物卡",
				waterHole: "获得1水",
				expand: "翻开部族卡",
				discardTop: "改取弃牌堆顶牌",
				rerollTribe: "支付1水并重抽",
				moveMarker: "移动部族标记",
				targiaFirst: "先使用塔尔吉娅",
				borderFirst: "先使用边界卡",
				targiaGain: "接受塔尔吉娅的赠礼",
				targiaDraw: "支付货物并翻牌",
				targiaRedraw: "支付货物并重抽",
				acceptGoods: "接受这张货物卡",
				raidFree: "免于支付",
				raidVp: "支付分数",
				raidPay: "支付资源",
				raidGoods: "选择支付的货物",
				payGoods: "支付货物",
				raidCard: "弃掉行末部族卡",
				raidUnable: "无法支付，对手获得分数",
				discardResource: "退还超额资源",
				giftGoods: "获得3个任意货物",
				giftGold: "获得1金币",
				giftVp: "获得1分",
				waterOrVp: "选择奖励",
				stash: "保留此沙丘",
				stashUse: "使用保留的沙丘",
				abilitySwap: "交换手牌与中央卡牌",
				swapHand: "交换这两张卡牌",
				abilityTrade: "使用一次兑换能力",
				freehand: "打出手牌",
				swapDisplay: "交换部族卡位置",
				moveDisplay: "移动行末部族卡",
				swapDisplayHand: "与手牌交换",
				wild: "放入第{{n}}行",
				discountTribe: "支付1水取得此卡",
				unoccupiedTribe: "取得此部族卡",
				anyBorder: "使用此边界卡",
				resetAbility: "重新启用此能力",
				discardPick: "取得此弃牌",
				useDune: "使用沙丘能力",
				costReward: "获得这些资源",
				waterTrade: "用水兑换",
				cacheWater: "使用卡上1水",
				joker: "使用万能货物标记",
				end: "结束本轮行动"
			},
			task: {
				discardHand: "选择弃掉一张超额手牌",
				gain: "选择获得的货物",
				tribe: "支付打出、保留或弃掉这张部族卡",
				goodsChoice: "选择货物卡奖励",
				border: "选择边界卡行动",
				order: "选择先使用哪种能力",
				targia: "选择塔尔吉娅的奖励",
				gamble: "接受货物卡，或支付重抽",
				raid: "选择如何支付突袭",
				payGoods: "选择支付的货物",
				discardResources: "退还超过携带上限的资源",
				gift: "选择奖励",
				waterOrVp: "选择水或分数",
				stash: "选择保留的沙丘",
				swapHand: "选择手牌与未被占据的中央部族卡",
				exchangeGoods: "兑换货物，完成后结束行动",
				rearrange: "选择调整的部族卡与目标位置",
				dune: "选择沙丘能力的目标",
				costReward: "选择获得哪组资源",
				roundGood: "获得轮初奖励",
				drawTribe: "翻开部族卡",
				goods: "翻开货物卡",
				reward: "获得货物卡奖励",
				raidBonus: "突袭开始",
				postRaid: "突袭结束",
				startActions: "开始行动",
				startPlacement: "开始放置"
			},
			effects: {
				b0: "终局时，每有2张水井部族卡，获得1分。",
				b2: "免于支付突袭要求的资源或分数。",
				b4: "终局时，每有2张营地部族卡，获得1分。",
				b5: "终局时，若此卡位于一个完整横行的最右侧，获得2分。",
				b6: "此后打出绿洲部族卡时，少支付1个货物。",
				b7: "在自己的行动期间，可额外支付该手牌所需的一种货物，将手牌打出，无须使用贵族。",
				b8: "立即选择获得3个任意货物、1金币或1分。",
				b9: "下一轮，对手只能放置2名塔尔吉。",
				b11: "每轮首次通过货物卡获得椰枣时，额外获得1椰枣。",
				b12: "终局时，至多两个全异横行的奖励从2分提高至4分。",
				b13: "终局时，若部族卡数量多于对手，获得1分。",
				b14: "终局时，每有2张塔尔吉娅部族卡，获得1分。",
				b15: "每轮结束时，若本轮没有通过货物卡获得任何货物，获得1个任意货物。",
				b17: "每轮首次通过货物卡获得盐时，额外获得1盐。",
				b19: "立即移动至多2张已打出的部族卡，完成后各横行不得留空隙。",
				b20: "终局时，若拥有至少10张部族卡，获得1分。",
				b21: "使用商人时，可以按1比1兑换不同种货物。",
				b22: "此后打出营地部族卡时，少支付1个货物。",
				b23: "终局时，每有2张绿洲部族卡，获得1分。",
				b26: "此后打出水井部族卡时，少支付1个货物。",
				b27: "每次支付突袭要求后，获得1分。",
				b30: "此后打出塔尔吉娅部族卡时，少支付1个货物。",
				b33: "每轮首次通过货物卡获得胡椒时，额外获得1胡椒。",
				b34: "使用贵族打出手牌时，少支付1个货物。",
				b35: "在此卡上放置1金币；以后支付部族卡的金币费用时可以使用。",
				b36: "立即按当前每2张部族卡，获得1个任意货物。",
				b37: "可以在强盗所在的边界卡上放置塔尔吉。",
				b39: "立即按部族阵列中每2个空位，获得1个任意货物。",
				b41: "此后打出骆驼骑手部族卡时，少支付1个货物。",
				b42: "终局时，每有2张骆驼骑手部族卡，获得1分。",
				e1: "终局时，左邻卡的印刷分数加倍，不包含括号中的分数。",
				e4: "终局时，若集齐5种部族符号，获得2分。",
				e6: "每局一次，可以在对手占据的沙丘上放置1名塔尔吉。",
				e7: "每局一次，可以将1张手牌与中央未被占据的部族卡交换。",
				e8: "每次突袭开始时，获得1水。",
				e9: "每次使用蜃景时，获得1个任意货物。",
				e10: "每局一次，使用蜃景时可以将两枚部族标记分别移到相邻空格。",
				e12: "在此卡上放置2水，可随时使用；若终局时两枚水仍都留在此卡上，获得2分。",
				e13: "终局时，一个原本没有横行奖励的完整横行获得2分。",
				e14: "通过边界卡获得胡椒时，可以改为获得椰枣或盐。",
				e16: "通过边界卡获得椰枣时，可以改为获得盐或胡椒。",
				e17: "强盗移动到货物边界卡时，获得该货物1个。",
				e18: "每局一次，使用部族扩张时，可以改为取得弃牌堆顶的部族卡，支付打出或保留为手牌。",
				e19: "每轮开始、强盗移动前，若货物总数少于4，获得1个任意货物。",
				e20: "立即取一张未被占据的公开沙丘，或沙丘牌堆顶牌，保留供未来自己的行动期间免费使用一次。",
				e21: "终局时，选择上邻或下邻卡，其印刷分数加倍，不包含括号中的分数。",
				e22: "使用塔尔吉娅的能力时，可以获得1水代替货物。",
				e23: "每局一次，可以在对手塔尔吉所在边界卡，或其正对边界卡，放置1名塔尔吉。",
				e24: "终局时，每有2张没有文字能力的部族卡，获得1分。",
				e25: "使用贵族打出手牌时，可以用1水和1个任意货物代替1金币。",
				e26: "终局时，每个包含3种不同部族符号的完整竖列获得1分。",
				e27: "手牌上限提高至2张。",
				e28: "通过边界卡获得盐时，可以改为获得椰枣或胡椒。",
				e29: "终局时，右邻卡的印刷分数加倍，不包含括号中的分数。",
				e30: "终局时，每剩余3个货物，获得1分。",
				e33: "每局一次，可以按1比1将任意数量的货物兑换为不同种货物。",
				e35: "自己的塔尔吉位于塔尔吉娅正对的边界卡时，也可以使用她的能力。",
				e42: "立即各获得1椰枣、1盐、1胡椒和1水。",
				e43: "立即按已经发生的每次突袭，分别选择获得1水或1分。",
				e44: "终局时，每有3张印刷分数为1分的部族卡，获得1分。"
			},
			rules: "目标：\n建立部族阵列，获得最多分数。两人对战，每人拥有3名塔尔吉和2枚部族标记。\n准备：\n16张边界卡围成5行5列卡阵，中央放置5张货物卡和4张部族卡，交错排列。每人获得2椰枣、2盐、2胡椒、1金币与4分。强盗首轮位于贵族。\n每轮流程：\n· 从先手开始，轮流放置一名塔尔吉。不能放在四角、强盗处、已有塔尔吉处，或对手塔尔吉的正对边界卡；可以与自己的塔尔吉正对。\n· 以自己的塔尔吉所在横行和竖列画线，在线的交点放部族标记。重复的直线只计算一次；没有交点便没有标记。\n· 先手按任意顺序执行自己的全部塔尔吉和部族标记，再由后手执行。每个行动须完成后才能开始下一个，也可以放弃行动。主要操作直接点击所在卡牌。\n· 中央货物卡获得所示奖励；斜线分隔的奖励只能选择一种。部族卡可支付费用打出、保留为手牌或弃掉；手牌上限1张，不能自由更换或弃掉。贵族允许支付打出手牌，或弃掉手牌。\n· 打出的部族卡放在3行4列阵列中，任选一行从左往右放置，通常不能移动。卡文能力立即生效，详情点击卡牌查看；括号费用是可选额外支付，支付后立即获得括号分数。\n· 用过的中央卡立即补另一种类型的卡并盖住，整轮结束再同时揭开。货物牌堆耗尽时洗混货物弃牌。\n· 每人结束本轮行动时，货物总数最多10个、金币最多3个，超额部分自行退还；过程中可以超限。双方结束后交换先手，强盗顺时针前进。\n突袭与终局：\n· 强盗到四角时，双方依次支付卡上要求的货物或分数，随后强盗再前进一格。第4次突袭支付1金币或3分后立即终局。\n· 若有人打出第12张部族卡，完成整轮后终局。总分包括分数标记、部族卡印刷分数、卡文奖励和满行奖励：四张同符号4分、四张全异2分。\n· 平分时依次比较金币与货物数量，仍同则共享胜利。\n2016官方扩展（可选）：\n扩展更换45张部族卡与10张边界卡，中央改为5部族、4货物，部族牌堆顶公开。起始每种货物1个、1金币、2水与4分。塔尔吉娅从盐卡逆时针前进并跳过角落；在她所在边界放置塔尔吉，可先于或后于该边界行动使用她的奖励：获得1个任意货物，或支付1个货物翻开货物卡；可以继续支付重抽。水不属于货物，随时可按2水换1货物、3水换1金币，轮末最多10水，终局每2水1分。\n可以把塔尔吉放到公开沙丘上并使用其一次性能力；每放一名到沙丘，本轮可用交点标记减少1枚。沙丘用后弃掉；轮初没有沙丘时补1张，每次突袭后弃掉剩余并补3张。扩展蜃景仅能移动至相邻空格；银匠最多兑换两次；最终突袭支付1金币或弃掉任一行最右部族卡。混合牌组按每种符号从两套牌中随机选9张。\n2015行动标记（可选）：\n双方秘密移除四种标记中的一种，其余公开，每种每局一次。万能货物替代任意1货物；额外塔尔吉在双方放完工人后放到空边界，可与对手正对但不产生交点；额外部族标记放在强盗直线与自己塔尔吉直线的空交点，不能用蜃景移动；弃权标记在打出至多第9张部族卡时，放弃该牌文字能力换取终局2分。",
			waterHole: "水源",
			confirmAgain: "重新开始这局对局？",
			confirmLobby: "离开最终牌桌并返回大厅？",
			confirm: "确认",
			cancel: "取消",
			used: "已使用",
			empty: "空位",
			swapPosition: "第{{r}}行第{{c}}张",
			moveFrom: "从第{{r}}行第{{c}}张",
			miniHelp: "每种标记每局使用一次。",
			deck: "牌堆",
			discard: "弃牌堆"
		},
		en: {
			name: "Targi",
			desc: "Place Targis around a desert market, claim intersections, and build three rows of tribes.",
			date: "Dates",
			salt: "Salt",
			pepper: "Pepper",
			gold: "Gold",
			water: "Water",
			points: "Points",
			round: "Round {{n}}",
			raid: "Raid",
			robber: "Robber",
			targia: "Targia",
			worker: "Targi",
			marker: "Tribe marker",
			goods: "Goods",
			tribes: "Tribes",
			dune: "Sand dune",
			hand: "Hand",
			pending: "Current card",
			noAbility: "No text ability.",
			wild: "Wild tribe symbol",
			close: "Close",
			details: "Inspect card",
			pay: "Pay",
			receive: "Receive",
			optional: "Optional extra cost awards {{n}} VP",
			row: "Row {{n}}",
			choose: "Choose",
			waiting: "Waiting for {{name}}",
			yourTurn: "Your turn",
			handCount: "{{n}} cards in hand",
			remaining: "{{n}} cards left",
			title: "Caravans of the Sahara",
			myTribe: "My tribes",
			opponent: "Rival tribes",
			turn: "Acting player",
			invalid: "That action is no longer available. Choose again.",
			hint: "Consider your goods, tribe costs, and intersection rewards.",
			optExpansion: "Official expansion",
			expansionOn: "2016 expansion: water, dunes and the Targia",
			optMixed: "Tribe deck",
			mixedOn: "Mix base and expansion: randomly take 9 of each symbol",
			optTokens: "2015 action tokens",
			tokensOn: "Secretly choose three of the four action tokens",
			base: "Base game",
			expansion: "Expansion",
			bonus: "Bonus points",
			waiver: "Waive this ability for 2 VP at game end",
			cache: "Stored on card",
			stash: "Saved sand dune",
			final: "The fruits of the caravan",
			win: "Winner",
			tie: "Shared victory",
			review: "View final table",
			back: "Back to scoring",
			again: "Play again",
			lobby: "Back to lobby",
			total: "Total",
			tokensScore: "VP tokens",
			cardsScore: "Tribe cards",
			rowsScore: "Row bonuses",
			abilitiesScore: "Card abilities",
			waterScore: "Water left",
			choosePayment: "Choose payment and a row",
			opponentTurn: "Your rival is acting",
			help: "Inspect a card for its ability. Highlighted pieces can be used.",
			mini: {
				joker: "Joker good",
				targi: "Extra Targi",
				marker: "Extra tribe marker",
				waiver: "Waiver"
			},
			group: {
				oasis: "Oasis",
				rider: "Camel rider",
				camp: "Camp",
				well: "Well",
				targia: "Targia"
			},
			phase: {
				select: "Secretly remove one action token",
				placement: "Place a Targi on a border or sand dune",
				extra: "Use your extra Targi, or skip",
				marker: "Use your extra tribe marker, or skip",
				actions: "Choose a Targi or tribe marker and use its card",
				raid: "Pay the raid requirement",
				between: "Reveal the replacement center cards",
				advance: "A new round begins",
				done: "Game over"
			},
			border: {
				0: "Noble",
				1: "Dates",
				2: "Salt",
				3: "Raid",
				4: "Trader",
				5: "Pepper",
				6: "Dates",
				7: "Raid",
				8: "Fata Morgana",
				9: "Silversmith",
				10: "Pepper",
				11: "Raid",
				12: "Caravan",
				13: "Tribal Expansion",
				14: "Salt",
				15: "Raid"
			},
			borderText: {
				0: "Pay to display one hand card, or discard one hand card. With the expansion, discarding also gives 1 water and 1 good.",
				1: "Receive 1 date.",
				2: "Receive 1 salt.",
				3: "Base: pay 1 good or 1 VP. Expansion: pay 1 pepper or 1 VP.",
				4: "Trade repeatedly: 3 identical goods for 1 gold, or 2 identical goods for 1 different good. Expansion also offers 2 water for 1 gold, or 1 water for 1 good.",
				5: "Receive 1 pepper.",
				6: "Receive 1 date.",
				7: "Base: pay 2 goods or 1 VP. Expansion: pay 1 date and 1 salt, or 1 VP.",
				8: "Move a tribe marker to an unoccupied center card. In the expansion it must be adjacent.",
				9: "Base: make one exchange: 2 identical goods for 1 VP, 4 for 3 VP, 1 gold for 2 VP, or 2 gold for 4 VP. Expansion: up to two exchanges, each 2 goods for 1 VP or 1 gold for 2 VP.",
				10: "Receive 1 pepper.",
				11: "Base: pay 3 goods or 2 VP. Expansion: pay 1 date, 1 salt and 1 pepper, or 2 VP.",
				12: "Reveal a goods card and take its reward. In the expansion this is the watering hole: receive 1 water.",
				13: "Reveal a tribe card to buy, keep in hand, or discard. In the expansion you may pay 1 water to discard it and reveal another, repeatedly.",
				14: "Receive 1 salt.",
				15: "Base: pay 1 gold or 3 VP. Expansion: pay 1 gold or discard the rightmost tribe card in any row. The game then ends immediately."
			},
			dunes: {
				0: "Pay 2 water to display this as a wild tribe card with no printed VP. At game end its symbol may be chosen separately for each bonus.",
				1: "Take a center tribe card under your own tribe marker and display it for only 1 water.",
				2: "Swap two displayed tribe cards, or swap a hand card with a displayed card. Activate the newly displayed hand card normally.",
				3: "Receive 1 VP, 1 water and 1 good.",
				4: "Use the Targia and receive 1 VP.",
				5: "Use the border under the robber and then the opposite border.",
				6: "Receive 2 VP.",
				7: "Receive 1 water and 1 gold.",
				8: "Receive 1 good for each tribe card in your display with no text ability.",
				9: "Receive 1 date, 1 salt, 1 pepper and 1 good of your choice.",
				10: "Use any non-corner border card and receive 1 good.",
				11: "Receive 3 water.",
				12: "Reveal the top tribe card and receive one of its printed cost combinations, excluding parentheses. Discard it.",
				13: "Receive 2 water and 1 good.",
				14: "Receive 1 VP and 2 goods.",
				15: "Receive 1 gold and 1 good.",
				16: "Take an unoccupied center tribe card to buy or keep in hand.",
				17: "Reactivate a used once-per-game tribe ability.",
				18: "Choose a tribe card from the discard pile to buy or keep in hand.",
				19: "Reveal two goods cards and take each reward."
			},
			actions: {
				discardHand: "Discard excess hand card",
				omit: "Remove this token",
				place: "Place Targi",
				placeDune: "Visit dune",
				extra: "Place extra Targi",
				skipExtra: "Skip",
				extraMarker: "Place extra marker",
				skipMarker: "Skip",
				work: "Use this card",
				buy: "Display in row {{n}}",
				keep: "Keep in hand",
				discardTribe: "Discard card",
				cancel: "Cancel",
				done: "Finish action",
				gain: "Take a good",
				goodsGain: "Take reward",
				borderGain: "Take a good",
				trade: "Trade",
				silver: "Exchange for VP",
				noblePlay: "Display hand card",
				nobleDiscard: "Discard hand card",
				caravan: "Reveal goods card",
				waterHole: "Take 1 water",
				expand: "Reveal tribe card",
				discardTop: "Take top discard",
				rerollTribe: "Pay 1 water to redraw",
				moveMarker: "Move tribe marker",
				targiaFirst: "Use Targia first",
				borderFirst: "Use border first",
				targiaGain: "Take Targia gift",
				targiaDraw: "Pay a good to reveal",
				targiaRedraw: "Pay a good to redraw",
				acceptGoods: "Accept this goods card",
				raidFree: "Pay nothing",
				raidVp: "Pay VP",
				raidPay: "Pay resources",
				raidGoods: "Choose goods to pay",
				payGoods: "Pay a good",
				raidCard: "Discard rightmost tribe",
				raidUnable: "Unable to pay: rival gains VP",
				discardResource: "Return excess resources",
				giftGoods: "Take 3 goods",
				giftGold: "Take 1 gold",
				giftVp: "Take 1 VP",
				waterOrVp: "Choose reward",
				stash: "Save dune",
				stashUse: "Use saved dune",
				abilitySwap: "Swap hand with center",
				swapHand: "Swap these cards",
				abilityTrade: "Use trading ability",
				freehand: "Display hand card",
				swapDisplay: "Swap displayed tribes",
				moveDisplay: "Move rightmost tribe",
				swapDisplayHand: "Swap with hand",
				wild: "Display in row {{n}}",
				discountTribe: "Take this card for 1 water",
				unoccupiedTribe: "Take this tribe card",
				anyBorder: "Use this border",
				resetAbility: "Reactivate ability",
				discardPick: "Take this discard",
				useDune: "Use dune ability",
				costReward: "Take these resources",
				waterTrade: "Trade water",
				cacheWater: "Use 1 stored water",
				joker: "Use joker good",
				end: "End your turn"
			},
			task: {
				discardHand: "Choose an excess hand card to discard",
				gain: "Choose a good",
				tribe: "Buy, keep, or discard this tribe card",
				goodsChoice: "Choose a goods-card reward",
				border: "Choose a border action",
				order: "Choose which ability to use first",
				targia: "Choose the Targia reward",
				gamble: "Accept the goods card, or pay to redraw",
				raid: "Choose how to pay the raid",
				payGoods: "Choose a good to pay",
				discardResources: "Return resources above your carrying limits",
				gift: "Choose a reward",
				waterOrVp: "Choose water or VP",
				stash: "Choose a dune to save",
				swapHand: "Choose a hand card and an unoccupied center tribe",
				exchangeGoods: "Trade goods, then finish the action",
				rearrange: "Choose tribe cards and their destinations",
				dune: "Choose a target for this dune",
				costReward: "Choose a resource combination",
				roundGood: "Receive a start-of-round reward",
				drawTribe: "Reveal a tribe card",
				goods: "Reveal a goods card",
				reward: "Receive the goods-card reward",
				raidBonus: "The raid begins",
				postRaid: "The raid ends",
				startActions: "Begin actions",
				startPlacement: "Begin placement"
			},
			effects: {
				b0: "At the end of the game, score 1 VP for every 2 \"Well\" cards in your display.",
				b2: "You do not have to pay anything during a \"Raid\".",
				b4: "At the end of the game, score 1 VP for every 2 \"Camp\" cards in your display.",
				b5: "At the end of the game, if this card is on the rightmost space of a complete row, score and additional 2 VPs.",
				b6: "Pay 1 fewer goods to play additional \"Oasis\" cards.",
				b7: "If you pay 1 extra Goods of one of the kinds required, you may play the card from your hand without using the \"Noble\" action.",
				b8: "After playing the card, receive one of the following: 3 goods, 1 gold, or 1 VP.",
				b9: "For the next turn, your opponent is only allowed to play 2 targi figures.",
				b11: "Each turn where you get at least 1x Dates with a goods card, receive 1 more dates.",
				b12: "At the end of the game, of up to 2 rows with 4 different symbols, score 4 VPs instead of 2.",
				b13: "At the end of the game, if you have more cards in your display than your opponent, score one additional VP.",
				b14: "At the end of the game, score 1 VP for every 2 \"Targia\" cards in your display.",
				b15: "Each turn where you do not get any goods from a center region or caravan goods card, you receive 1 goods of your choice.",
				b17: "Each turn where you get at least 1x salt with a goods card, receive 1 more salt.",
				b19: "After playing this card, you may move 2 tribe cards in your display. (No gaps allowed after moving the cards.)",
				b20: "At the end of the game, if you have 10 or more cards in your display, you score 1 additional VP.",
				b21: "When you use the \"Trader\" action, you may exchange goods at a rate of 1 for 1.",
				b22: "Pay 1 fewer goods to play additional \"Camp\" cards.",
				b23: "At the end of the game, score 1 VP for every 2 \"Oasis\" card in your display.",
				b26: "Pay 1 fewer goods to play additional \"Well\" cards",
				b27: "After paying for a \"Raid\", receive 1 VP.",
				b30: "Pay 1 fewer goods to play additional \"Targia\" cards.",
				b33: "Each turn where you get at least 1x pepper with a goods card, receive 1 more pepper.",
				b34: "When you use the \"Noble\" action to play a card from your hand into your display, pay one fewer goods.",
				b35: "Put 1 gold from the bank on this card. Later in the game, if you play a card that cost gold, use this gold.",
				b36: "After playing this card, for every 2 cards in your display, receive 1 goods of your choice.",
				b37: "You can put a targi figure on the card occupied by the robber",
				b39: "After playing this card, for every 2 empty spaces in your display, receive 1 goods of your choice.",
				b41: "Pay 1 fewer goods to play additional \"Camel Rider\" cards.",
				b42: "At the end of the game, score 1 VP for every 2 \"Camel Rider\" cards in your display.",
				e1: "At the end of the Game, the VP on the card to the left of this card are doubled (excludes VP in parentheses)",
				e4: "At the end of the game, if you have at least one card of each of the 5 tribe symbols in your display receive 2 extra VP",
				e6: "Once per game, you may add 1 of your Targi figures to a Sand Dune already occupied by your  opponent.",
				e7: "Once per game, you may exchange the card in your hand for an unoccupied tribe card from the central area.",
				e8: "At the beginning of each Raid, you get 1 water",
				e9: "When you use the Fata Morgana action, you receive 1 good of your choice",
				e10: "Once per game, when using the Fata Morgana action, you may move BOTH tribe markers to adjacent unoccupied cards",
				e12: "Place 2 water tokens on this card. You may use them at any time. If BOTH water tokens are still here at the end of the game, they count as 2 VP",
				e13: "At the end of the game, you receive 2 VP for one of your completed rows which would otherwise receive no row bonus VP.",
				e14: "If you would receive pepper from a border card, you may take dates or salt instead.",
				e16: "If you would receive dates from a border card, you may take salt or pepper instead.",
				e17: "When the robber is placed on a border card on which a goods token is shown as an action, you receive one of these goods",
				e18: "Once per game, Isnstead of the tribal Expansion action, you can take the top Tribe card from the discard pile and purchase it or put it in your hand (if your hand  is empty).",
				e19: "If you have fewer than 4 goods at the beginning of a round (before the robber is advanced) you get 1 good of your choice.",
				e20: "Take 1 unoccupied sand dune card or the top card from the sand dune draw pile and place it face up on your side of the table. You may use during any round without having to place a targi on it. Discard card once used",
				e21: "At the end of the Game, the VP on the card above or below this card are doubled (excludes VP in parentheses)",
				e22: "When you use the function of the Targia, you may take 1 water instead of one goods item.",
				e23: "Once per game, you may place 1 of your Targi figures on a border card occupied by your opponent's Targi or on the border card across from it.",
				e24: "At the end of the game, you get 1 extra VP for every 2 tribe cards in your display that have no advantge (no writing on them)",
				e25: "When you use the noble action to play a card from your hand, instead of gold, you may pay 1 water and 1 good of your choice.",
				e26: "At the end of the game, you will receive 1 VP for each vertical column in your display with 3 different tribes symbols",
				e27: "You may hold 2 tribe cards in your hand.",
				e28: "If you would receive salt from a border card, you may take dates or pepper instead.",
				e29: "At the end of the Game, the VP on the card to the right of this card are doubled (excludes VP in parentheses)",
				e30: "At the end of the game, you get 1 VP for every 3 goods you have",
				e33: "Once per game, you may trade as many goods as you like in a 1:1 ratio for goods of a different type.",
				e35: "You may use the Targia;s function if one of your targi is standing on the border card across from her.",
				e42: "You receive 1 date, 1 salt, 1 pepper and 1 water.",
				e43: "For every Raid that has already occurred, you now receive 1 water or 1 VP",
				e44: "At the end of the game, you get 1 extra VP for every 3 tribe cards in you display that show 1 VP"
			},
			rules: "Goal:\nBuild your tribe display and score the most VP. Each of two players has 3 Targis and 2 tribe markers.\nSetup:\nSixteen border cards surround a 3×3 center of 5 goods and 4 tribe cards in alternating positions. Each player starts with 2 dates, 2 salt, 2 pepper, 1 gold and 4 VP. The robber starts on the Noble.\nEach round:\n· Alternate placing one Targi, starting with the first player. Corners, the robber, occupied borders, and borders opposite an opponent’s Targi are forbidden. You may face your own Targi.\n· Extend lines across the board from your Targis. Put tribe markers where your horizontal and vertical lines meet. Repeated lines count once; no intersection means no marker.\n· The first player uses all their pieces in any order, then the other player does so. Complete each card before starting another. You may forgo an action. Click the card occupied by a piece to act.\n· Goods cards award their reward; slash-separated alternatives offer a choice. Buy a tribe card, keep it in hand, or discard it. Your hand holds 1 card and cannot be freely exchanged or discarded. The Noble lets you pay to display a hand card, or discard it.\n· Display tribes in three rows of four, filling each row from left to right. Cards normally stay in place. Abilities activate immediately; inspect cards for full text. Parenthesized costs are optional and award their parenthesized VP immediately.\n· Replace a used center card with the opposite type face down. Reveal replacements together at round end. Reshuffle discarded goods when their deck empties.\n· At the end of your actions keep at most 10 goods and 3 gold, choosing any excess goods to return. You may exceed these limits during the round. Then exchange first player and advance the robber clockwise.\nRaids and game end:\n· At corners both players pay the indicated goods or VP, then the robber moves on. The fourth raid costs 1 gold or 3 VP and ends the game immediately.\n· If a player displays their twelfth tribe, finish the round, then score. Add VP tokens, printed tribe VP, card abilities and full-row bonuses: 4 VP for four matching symbols, or 2 VP for four different symbols.\n· Break ties by gold, then goods; if still tied, share victory.\nOfficial 2016 expansion (optional):\nReplace the 45 tribe cards and 10 borders. Start with 5 tribes and 4 goods in the center, and reveal the tribe-deck top card. Each player starts with 1 of each good, 1 gold, 2 water and 4 VP. The Targia begins at Salt and travels counterclockwise, skipping corners. Placing a Targi with her grants a reward before or after that border action: take 1 good, or pay 1 good to reveal a goods card. You may pay again to redraw. Water is not a good. At any time trade 2 water for 1 good or 3 water for 1 gold. Keep at most 10 water at turn end; each 2 water scores 1 VP at game end.\nYou may place Targis on face-up dunes for their one-use abilities. Each Targi on a dune reduces available tribe markers by one. Used dunes are discarded. If none remain at round start, reveal one; after raids replace all remaining dunes with three new ones. Expansion Fata Morgana only moves to adjacent empty cards; the Silversmith allows up to two trades. The final raid costs 1 gold or the rightmost tribe in any row. A mixed deck randomly selects 9 cards per symbol from both sets.\n2015 action tokens (optional):\nSecretly remove one of four tokens each; reveal the other three. Each is usable once. The Joker grants one good. After regular Targi placement, place the extra Targi on a free border, even opposite an opponent; it makes no intersections. The extra tribe marker goes at a free intersection of the robber’s line and your Targi’s line and cannot move through Fata Morgana. When displaying at most your ninth tribe card, the Waiver may cancel its text ability for 2 VP at game end.",
			waterHole: "Watering Hole",
			confirmAgain: "Start this game again?",
			confirmLobby: "Leave the final table and return to the lobby?",
			confirm: "Confirm",
			cancel: "Cancel",
			used: "Used",
			empty: "Empty space",
			swapPosition: "Row {{r}}, card {{c}}",
			moveFrom: "From row {{r}}, card {{c}}",
			miniHelp: "Each token is used once per game.",
			deck: "Deck",
			discard: "Discards"
		}
	}
};
//#endregion
export { gt as default };
