import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { GameScreen as i } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as a } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as o } from "@bgparty/sdk/ui/player-strip";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
import { GameOverScreen as l } from "@bgparty/sdk/ui/game-over-screen";
import { OptionSwitch as u } from "@bgparty/sdk/ui/game-options";
//#region src/games/lostcode/meta.ts
var d = {
	id: "lostcode",
	tier: "alpha",
	mechanics: ["deduction", "betting"],
	interactionTags: [],
	nameKey: "games.lostcode.name",
	descKey: "games.lostcode.desc",
	rulesKey: "games.lostcode.rules",
	icon: "🗿",
	iconImg: "games/lostcode.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/lostcode/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#0d9488",
	releasedAt: "2026-09-21",
	search: {
		py: "mi shi dai ma",
		init: "msdm"
	},
	hotseat: "cover"
}, f = t.int().min(0).max(5), p = t.int().min(0).max(7), m = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("flip"),
		die: t.int().min(0).max(2),
		symbol: f
	}),
	t.object({ type: t.literal("noFlip") }),
	t.object({
		type: t.literal("takeToken"),
		guess: t.array(p).min(1).max(3)
	}),
	t.object({ type: t.literal("passToken") }),
	t.object({
		type: t.literal("guess"),
		wheel: t.int().min(0).max(6),
		lo: t.int().min(0).max(21)
	}),
	t.object({
		type: t.literal("exchange"),
		symbol: f
	}),
	t.object({
		type: t.literal("finalGuess"),
		guesses: t.array(t.array(p).min(1).max(3).nullable()).length(6)
	}),
	t.object({
		type: t.literal("note"),
		symbol: f,
		value: p
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), h = t.string(), g = t.object({
	dice: t.array(f).length(3),
	results: t.array(t.object({
		rid: h,
		wheel: t.int().min(0).max(6),
		lo: t.int().min(0),
		ok: t.boolean(),
		dir: t.enum(["higher", "lower"]).nullable(),
		vp: t.int()
	})),
	discards: t.array(t.object({
		by: h,
		symbol: f,
		value: p
	}))
}), _ = t.object({
	round: t.int().min(1),
	totalRounds: t.int(),
	phase: t.enum([
		"roll",
		"token",
		"flip",
		"guess",
		"resolve",
		"exchange",
		"final",
		"done"
	]),
	pos: t.record(h, t.int()),
	stack: t.array(h),
	logs: t.array(t.object({ owner: h.nullable() })).length(4),
	piles: t.array(t.int().nonnegative()).length(6),
	discards: t.array(t.object({
		by: h,
		symbol: f,
		value: p
	})),
	dice: t.array(f).length(3).nullable(),
	roller: h.nullable(),
	tokenOffer: t.object({
		symbol: f,
		queue: t.array(h)
	}).nullable(),
	wheels: t.array(t.object({
		vp: t.int(),
		w: t.int(),
		by: h.nullable()
	})).length(7),
	guessOrder: t.array(h),
	guessIndex: t.int().nonnegative(),
	guesses: t.record(h, t.object({
		wheel: t.int().min(0).max(6),
		lo: t.int().min(0)
	})),
	resolveOrder: t.array(h),
	resolveIndex: t.int().nonnegative(),
	results: t.array(t.object({
		rid: h,
		ok: t.boolean(),
		dir: t.enum(["higher", "lower"]).nullable(),
		vp: t.int()
	})),
	exchangeQueue: t.array(h),
	exchangeIndex: t.int().nonnegative(),
	tokens: t.array(t.object({
		holder: h.nullable(),
		gone: t.boolean()
	})).length(6),
	curse: t.object({
		state: t.enum([
			"idle",
			"on",
			"off"
		]),
		owner: h.nullable()
	}),
	finalsIn: t.array(h),
	history: t.array(g)
}), v = t.object({
	logStones: t.array(t.array(p).length(6).nullable()).length(4),
	notes: t.array(t.array(t.int().min(0).max(2)).length(8)).length(6),
	myFinals: t.array(t.array(p).nullable()).length(6),
	myLocked: t.array(t.boolean()).length(6),
	myStones: t.array(p).length(6).nullable()
}), y = t.object({
	curse: t.boolean().default(!1),
	shortcut: t.boolean().default(!1)
}).default({
	curse: !1,
	shortcut: !1
}), b = {
	action: m,
	publicView: _,
	privateView: v,
	config: y
}, x = [
	{
		vp: 1,
		w: 10
	},
	{
		vp: 2,
		w: 7
	},
	{
		vp: 2,
		w: 5
	},
	{
		vp: 3,
		w: 4
	},
	{
		vp: 3,
		w: 3
	},
	{
		vp: 4,
		w: 2
	},
	{
		vp: 5,
		w: 1
	}
], S = (e) => e === 2 ? 10 : e === 3 ? 9 : 8, C = [
	0,
	5,
	2,
	1
];
function w(e) {
	let t = new Map(e.stack.map((e, t) => [e, t]));
	return [...e.players].sort((n, r) => e.pos[n] - e.pos[r] || (t.get(r) ?? 0) - (t.get(n) ?? 0));
}
function T(e, t, n) {
	e.pos[t] = n, e.stack = [...e.stack.filter((e) => e !== t), t], e.curse.state === "idle" && n >= 7 && (e.curse.state = "on", e.curse.owner = t);
}
function E(t, n, r) {
	let i = 0, a = [], o = Array.from({ length: 4 }, () => []);
	for (let t = 0; t < 6; t += 1) {
		let t = Array.from({ length: 8 }, (e, t) => t);
		t.splice(e(r, i++, 8), 1);
		for (let n = 0; n < 4; n += 1) {
			let a = e(r, i++, t.length);
			o[n].push(t.splice(a, 1)[0]);
		}
		a.push(t);
	}
	let s = o.map((e, t) => ({
		owner: t < n.length ? n[t] : null,
		stones: e
	})), c = [...n];
	for (let t = c.length - 1; t > 0; --t) {
		let n = e(r, i++, t + 1);
		[c[t], c[n]] = [c[n], c[t]];
	}
	let l = {}, u = {}, d = {}, f = {};
	for (let e of n) l[e] = 0, u[e] = [
		,
		,
		,
		,
		,
		,
	].fill(null), d[e] = [
		,
		,
		,
		,
		,
		,
	].fill(!1), f[e] = Array.from({ length: 6 }, () => Array(8).fill(0));
	return { state: {
		players: n,
		seed: r,
		logs: s,
		piles: a,
		discards: [],
		pos: l,
		stack: c,
		round: 1,
		totalRounds: S(n.length),
		phase: "roll",
		dice: null,
		roller: null,
		tokenOffer: null,
		wheelBy: Array(7).fill(null),
		guessOrder: [],
		guessIndex: 0,
		guesses: {},
		resolveOrder: [],
		results: [],
		exchangeQueue: [],
		exchangeIndex: 0,
		tokens: Array.from({ length: 6 }, () => ({
			holder: null,
			gone: !t.shortcut
		})),
		curse: {
			state: t.curse ? "idle" : "off",
			owner: null
		},
		finals: u,
		lockedFinals: d,
		finalsIn: [],
		notes: f,
		history: [],
		roundDiscards: [],
		rngCursor: i
	} };
}
function D(e) {
	e.phase = "guess", e.guessOrder = w(e), e.guessIndex = 0, e.wheelBy = Array(7).fill(null), e.guesses = {};
}
function O(e) {
	if (e.history.push({
		dice: e.dice ?? [],
		results: e.results.map((t) => ({
			...t,
			wheel: e.guesses[t.rid]?.wheel ?? 0,
			lo: e.guesses[t.rid]?.lo ?? 0
		})),
		discards: e.roundDiscards
	}), e.roundDiscards = [], e.curse.state !== "off") {
		if (e.players.some((t) => e.pos[t] >= 13) || e.round >= e.totalRounds - 1) e.curse = {
			state: "off",
			owner: null
		};
		else {
			let t = new Map(e.stack.map((e, t) => [e, t]));
			e.curse = {
				state: "on",
				owner: [...e.players].sort((n, r) => e.pos[r] - e.pos[n] || (t.get(n) ?? 0) - (t.get(r) ?? 0))[0]
			};
		}
	}
	if (e.round === e.totalRounds - 3) for (let t of e.tokens) t.gone = !0;
	if (e.round >= e.totalRounds) {
		e.phase = "final";
		return;
	}
	e.round += 1, e.phase = "roll", e.dice = null, e.roller = null, e.tokenOffer = null, e.guessOrder = [], e.guessIndex = 0, e.resolveOrder = [], e.exchangeQueue = [], e.exchangeIndex = 0;
}
function k(e) {
	let t = w(e);
	e.resolveOrder = t;
	let n = /* @__PURE__ */ new Map();
	for (let t of e.dice ?? []) n.set(t, (n.get(t) ?? 0) + 1);
	for (let r of t) {
		let t = e.logs.find((e) => e.owner === r), i = e.guesses[r];
		if (!t || !i) continue;
		let a = 0;
		for (let [e, r] of n) a += r * t.stones[e];
		let o = x[i.wheel], s = i.lo <= a && a <= i.lo + o.w - 1, c = s || o.w === 1 ? null : a > i.lo + o.w - 1 ? "higher" : "lower", l = 0;
		s ? (l = o.vp, T(e, r, e.pos[r] + o.vp)) : e.curse.state === "on" && e.curse.owner === r ? (l = -o.vp, T(e, r, e.pos[r] - o.vp)) : e.curse.state === "on" && e.curse.owner && T(e, e.curse.owner, e.pos[e.curse.owner] + 1), e.results.push({
			rid: r,
			ok: s,
			dir: c,
			vp: l
		});
	}
	let r = t.filter((t) => e.results.find((e) => e.rid === t)?.ok === !1);
	e.piles.some((e) => e.length > 0) && r.length > 0 ? (e.phase = "exchange", e.exchangeQueue = r, e.exchangeIndex = 0) : O(e);
}
function A(e) {
	for (let t of e.players) {
		let n = e.logs.find((e) => e.owner === t);
		if (!n) continue;
		let r = 0;
		for (let i = 0; i < 6; i += 1) {
			let a = e.finals[t][i], o = e.tokens[i].holder === t;
			a && a.includes(n.stones[i]) ? r += o ? C[a.length] * 2 : C[a.length] : r += o ? -4 : -2;
		}
		T(e, t, e.pos[t] + r);
	}
	e.phase = "done";
}
function j(t, n, r) {
	let i = structuredClone(t);
	switch (n.type) {
		case "tick": return { state: t };
		case "note": return t.phase === "done" ? { code: "games.lostcode.errPhase" } : (i.notes[r.by][n.symbol][n.value] = (i.notes[r.by][n.symbol][n.value] + 1) % 3, { state: i });
		case "roll": {
			if (t.phase !== "roll") return { code: "games.lostcode.errPhase" };
			if (r.by !== w(t)[0]) return { code: "games.lostcode.errNotLast" };
			let n = i.rngCursor;
			i.dice = [
				0,
				0,
				0
			].map(() => e(i.seed, n++, 6)), i.rngCursor = n, i.roller = r.by, i.results = [], i.guesses = {};
			let a = /* @__PURE__ */ new Map();
			for (let e of i.dice) a.set(e, (a.get(e) ?? 0) + 1);
			let o = [...a.entries()].find(([e, t]) => t >= 2 && !i.tokens[e].gone && !i.tokens[e].holder)?.[0];
			return o !== void 0 && i.round <= i.totalRounds - 3 ? (i.phase = "token", i.tokenOffer = {
				symbol: o,
				queue: w(i)
			}) : i.phase = "flip", { state: i };
		}
		case "takeToken": {
			if (t.phase !== "token" || !t.tokenOffer) return { code: "games.lostcode.errPhase" };
			if (t.tokenOffer.queue[0] !== r.by) return { code: "games.lostcode.errNotYourTurn" };
			if (new Set(n.guess).size !== n.guess.length) return { code: "games.lostcode.errBadGuess" };
			let e = t.tokenOffer.symbol;
			return i.tokens[e].holder = r.by, i.finals[r.by][e] = [...n.guess].sort((e, t) => e - t), i.lockedFinals[r.by][e] = !0, i.tokenOffer = null, i.phase = "flip", { state: i };
		}
		case "passToken": return t.phase !== "token" || !i.tokenOffer ? { code: "games.lostcode.errPhase" } : i.tokenOffer.queue[0] === r.by ? (i.tokenOffer.queue = i.tokenOffer.queue.slice(1), i.tokenOffer.queue.length === 0 && (i.tokenOffer = null, i.phase = "flip"), { state: i }) : { code: "games.lostcode.errNotYourTurn" };
		case "flip": return t.phase !== "flip" || r.by !== t.roller ? { code: "games.lostcode.errNotYourTurn" } : (i.dice[n.die] = n.symbol, D(i), { state: i });
		case "noFlip": return t.phase !== "flip" || r.by !== t.roller ? { code: "games.lostcode.errNotYourTurn" } : (D(i), { state: i });
		case "guess": {
			if (t.phase !== "guess") return { code: "games.lostcode.errPhase" };
			if (t.guessOrder[t.guessIndex] !== r.by) return { code: "games.lostcode.errNotYourTurn" };
			let e = x[n.wheel];
			return e ? t.wheelBy[n.wheel] ? { code: "games.lostcode.errWheelTaken" } : n.lo > 21 - e.w + 1 ? { code: "games.lostcode.errBadRange" } : (i.wheelBy[n.wheel] = r.by, i.guesses[r.by] = {
				wheel: n.wheel,
				lo: n.lo
			}, i.guessIndex += 1, i.guessIndex >= i.players.length && (i.phase = "resolve", k(i)), { state: i }) : { code: "games.lostcode.errBadWheel" };
		}
		case "exchange": {
			if (t.phase !== "exchange") return { code: "games.lostcode.errPhase" };
			if (t.exchangeQueue[t.exchangeIndex] !== r.by) return { code: "games.lostcode.errNotYourTurn" };
			let a = t.piles[n.symbol];
			if (!a || a.length === 0) return { code: "games.lostcode.errPileEmpty" };
			let o = i.logs.find((e) => e.owner === r.by);
			if (!o) return { code: "games.lostcode.errPhase" };
			let s = {
				by: r.by,
				symbol: n.symbol,
				value: o.stones[n.symbol]
			};
			i.discards.push(s), i.roundDiscards.push(s);
			let c = e(i.seed, i.rngCursor++, a.length);
			return o.stones[n.symbol] = i.piles[n.symbol].splice(c, 1)[0], i.exchangeIndex += 1, (i.exchangeIndex >= i.exchangeQueue.length || i.piles.every((e) => e.length === 0)) && O(i), { state: i };
		}
		case "finalGuess":
			if (t.phase !== "final") return { code: "games.lostcode.errPhase" };
			if (t.finalsIn.includes(r.by)) return { code: "games.lostcode.errNotYourTurn" };
			for (let e = 0; e < 6; e += 1) {
				let i = n.guesses[e];
				if (t.lockedFinals[r.by][e]) {
					let n = t.finals[r.by][e];
					if (!n || !i || i.length !== n.length || !n.every((e) => i.includes(e))) return { code: "games.lostcode.errLocked" };
				}
				if (i && new Set(i).size !== i.length) return { code: "games.lostcode.errBadGuess" };
			}
			return i.finals[r.by] = n.guesses.map((e) => e ? [...e].sort((e, t) => e - t) : null), i.finalsIn.push(r.by), i.finalsIn.length >= i.players.length && A(i), { state: i };
	}
}
function M(e, t) {
	return {
		public: {
			round: e.round,
			totalRounds: e.totalRounds,
			phase: e.phase,
			pos: { ...e.pos },
			stack: [...e.stack],
			logs: e.logs.map((e) => ({ owner: e.owner })),
			piles: e.piles.map((e) => e.length),
			discards: [...e.discards],
			dice: e.dice ? [...e.dice] : null,
			roller: e.roller,
			tokenOffer: e.tokenOffer ? {
				symbol: e.tokenOffer.symbol,
				queue: [...e.tokenOffer.queue]
			} : null,
			wheels: x.map((t, n) => ({
				vp: t.vp,
				w: t.w,
				by: e.wheelBy[n]
			})),
			guessOrder: [...e.guessOrder],
			guessIndex: e.guessIndex,
			guesses: { ...e.guesses },
			resolveOrder: [...e.resolveOrder],
			resolveIndex: e.results.length,
			results: [...e.results],
			exchangeQueue: [...e.exchangeQueue],
			exchangeIndex: e.exchangeIndex,
			tokens: e.tokens.map((e) => ({ ...e })),
			curse: { ...e.curse },
			finalsIn: [...e.finalsIn],
			history: e.history.map((e) => ({ ...e }))
		},
		private: {
			logStones: e.logs.map((e) => e.owner === t ? null : [...e.stones]),
			notes: e.notes[t] ?? Array.from({ length: 6 }, () => Array(8).fill(0)),
			myFinals: [...e.finals[t] ?? [
				,
				,
				,
				,
				,
				,
			].fill(null)],
			myLocked: [...e.lockedFinals[t] ?? [
				,
				,
				,
				,
				,
				,
			].fill(!1)],
			myStones: e.phase === "done" ? [...e.logs.find((e) => e.owner === t)?.stones ?? []] : null
		}
	};
}
function N(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = new Map(e.stack.map((e, t) => [e, t])), n = [...e.players].sort((n, r) => e.pos[r] - e.pos[n] || (t.get(n) ?? 0) - (t.get(r) ?? 0));
	return {
		phase: "done",
		winner: [n[0]],
		ranking: n,
		scores: { ...e.pos }
	};
}
var P = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: d,
	schemas: b,
	setup: E,
	reduce: j,
	viewFor: M,
	status: N
}, F = [
	"games.lostcode.symBird",
	"games.lostcode.symJaguar",
	"games.lostcode.symChameleon",
	"games.lostcode.symSnake",
	"games.lostcode.symHuman",
	"games.lostcode.symBear"
], I = [
	"🐦",
	"🐆",
	"🦎",
	"🐍",
	"🧍",
	"🐻"
], L = [
	"bg-sky-200 text-sky-900",
	"bg-amber-200 text-amber-900",
	"bg-violet-200 text-violet-900",
	"bg-emerald-200 text-emerald-900",
	"bg-pink-200 text-pink-900",
	"bg-red-200 text-red-900"
];
function R(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ s(B, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function z(e) {
	let t = new Map(e.stack.map((e, t) => [e, t]));
	return [...Object.keys(e.pos)].sort((n, r) => e.pos[n] - e.pos[r] || (t.get(r) ?? 0) - (t.get(n) ?? 0));
}
function B({ pub: e, priv: t, members: l, myRid: u, send: f }) {
	let p = r(), m = (e) => l.find((t) => t.rid === e)?.name ?? e, [h, g] = n(null), [_, v] = n(0), [y, b] = n(null), [S, C] = n([]), [w, T] = n([
		,
		,
		,
		,
		,
		,
	].fill(null)), [E, D] = n(!1), O = z(e)[0], k = e.phase === "guess" && e.guessOrder[e.guessIndex] === u, A = e.phase === "token" && e.tokenOffer?.queue[0] === u, j = e.phase === "exchange" && e.exchangeQueue[e.exchangeIndex] === u, M = e.roller === u, [N, P] = n(""), R = `${e.phase}:${e.round}`;
	N !== R && (P(R), g(null), v(0), b(null), C([]));
	let [B, K] = n(!1);
	e.phase === "final" && !B ? (K(!0), T(t?.myFinals.map((e) => e ? [...e] : null) ?? [
		,
		,
		,
		,
		,
		,
	].fill(null))) : e.phase !== "final" && B && K(!1);
	let q = "info", J, Y;
	e.phase === "roll" ? (q = O === u ? "accent" : "info", J = O === u ? p("games.lostcode.rollYou") : p("games.lostcode.rollWait", { name: m(O) })) : e.phase === "token" && e.tokenOffer ? (q = A ? "accent" : "info", J = A ? p("games.lostcode.tokenTitle", { symbol: p(F[e.tokenOffer.symbol]) }) : p("games.lostcode.tokenWait", { name: m(e.tokenOffer.queue[0]) }), A && (Y = p("games.lostcode.tokenPrompt"))) : e.phase === "flip" ? (q = M ? "accent" : "info", J = M ? p("games.lostcode.flipPrompt") : p("games.lostcode.rollWait", { name: m(e.roller ?? "") })) : e.phase === "guess" ? e.guesses[u] ? J = p("games.lostcode.guessDone") : k ? (q = "accent", J = p("games.lostcode.guessYou")) : J = p("games.lostcode.guessWait", { name: m(e.guessOrder[e.guessIndex] ?? "") }) : e.phase === "resolve" ? J = p("games.lostcode.resolveTitle") : e.phase === "exchange" ? (q = j ? "warn" : "info", J = j ? p("games.lostcode.exchangeYou") : p("games.lostcode.exchangeWait", { name: m(e.exchangeQueue[e.exchangeIndex] ?? "") }), j && (Y = p("games.lostcode.exchangeHint"))) : e.phase === "final" ? (q = e.finalsIn.includes(u) ? "info" : "accent", J = e.finalsIn.includes(u) ? p("games.lostcode.finalWait") : p("games.lostcode.finalTitle"), e.finalsIn.includes(u) || (Y = p("games.lostcode.finalPrompt"))) : (q = "done", J = p("games.lostcode.finalDone"));
	let X = (e, n) => {
		t?.myLocked[e] || T((t) => {
			let r = [...t], i = r[e] ?? [], a = i.includes(n) ? i.filter((e) => e !== n) : [...i, n];
			return r[e] = a.length === 0 ? null : a.length <= 3 ? [...a].sort((e, t) => e - t) : i, r;
		});
	}, Z = h === null ? null : x[h], Q = Z ? 21 - Z.w + 1 : 0, $ = Math.min(_, Q);
	return /* @__PURE__ */ c("div", {
		className: "lostcode-root relative h-full min-h-0",
		children: [/* @__PURE__ */ s(i, {
			adaptive: !0,
			className: "lostcode-screen",
			scroll: !1,
			actionsHeight: "lostcode-actions-height",
			banner: /* @__PURE__ */ c("div", {
				className: "lostcode-banner",
				children: [/* @__PURE__ */ s(a, {
					tone: q,
					text: J,
					sub: Y,
					chip: p("games.lostcode.roundShort", {
						n: Math.min(e.round, e.totalRounds),
						total: e.totalRounds
					}),
					accent: d.accent
				}), /* @__PURE__ */ s(o, {
					variant: "plate",
					members: l,
					myRid: u,
					status: (t) => t in e.pos ? /* @__PURE__ */ c("span", {
						className: "flex items-center gap-1 font-mono text-xs font-extrabold tabular-nums",
						children: [
							e.pos[t],
							e.curse.owner === t && e.curse.state === "on" && /* @__PURE__ */ s("span", {
								"aria-label": p("games.lostcode.curseBadge"),
								children: "💀"
							}),
							e.tokens.some((e) => e.holder === t) && /* @__PURE__ */ s("span", {
								"aria-label": p("games.lostcode.tokenBadge"),
								children: "⚡"
							})
						]
					}) : null,
					action: (t) => e.phase === "guess" ? e.guesses[t] ? "done" : "pending" : e.phase === "final" ? e.finalsIn.includes(t) ? "done" : "pending" : null
				})]
			}),
			actions: /* @__PURE__ */ c("div", {
				className: "lostcode-actions flex h-full min-h-0 items-center gap-2",
				children: [/* @__PURE__ */ c("button", {
					type: "button",
					onClick: () => D(!0),
					className: "btn-quiet min-h-12 flex-none px-3 text-sm font-extrabold",
					children: ["📝 ", p("games.lostcode.notesTitle")]
				}), /* @__PURE__ */ c("div", {
					className: "min-w-0 flex-1",
					children: [
						e.phase === "roll" && O === u && /* @__PURE__ */ c("button", {
							type: "button",
							onClick: () => f({ type: "roll" }),
							className: "tile-btn min-h-12 w-full border-3 border-ink text-base font-extrabold text-white",
							style: { background: d.accent },
							children: ["🎲 ", p("games.lostcode.roll")]
						}),
						e.phase === "flip" && M && /* @__PURE__ */ s("button", {
							type: "button",
							onClick: () => f({ type: "noFlip" }),
							className: "tile-btn min-h-12 w-full border-3 border-ink bg-surface text-base font-extrabold",
							children: p("games.lostcode.noFlip")
						}),
						e.phase === "token" && A && /* @__PURE__ */ c("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ s("button", {
								type: "button",
								onClick: () => f({ type: "passToken" }),
								className: "btn-quiet min-h-12 flex-1 text-sm font-extrabold",
								children: p("games.lostcode.passToken")
							}), /* @__PURE__ */ s("button", {
								type: "button",
								disabled: S.length === 0,
								onClick: () => f({
									type: "takeToken",
									guess: [...S].sort((e, t) => e - t)
								}),
								className: "tile-btn min-h-12 flex-2 border-3 border-ink text-sm font-extrabold text-white disabled:opacity-40",
								style: { background: d.accent },
								children: p("games.lostcode.takeToken")
							})]
						}),
						k && /* @__PURE__ */ c("button", {
							type: "button",
							disabled: h === null,
							onClick: () => f({
								type: "guess",
								wheel: h,
								lo: $
							}),
							className: "tile-btn min-h-12 w-full border-3 border-ink text-base font-extrabold text-white disabled:opacity-40",
							style: { background: d.accent },
							children: [p("games.lostcode.guessConfirm"), Z ? ` · ${p("games.lostcode.rangeLabel", {
								lo: $,
								hi: $ + Z.w - 1
							})}` : ""]
						}),
						e.phase === "final" && !e.finalsIn.includes(u) && /* @__PURE__ */ s("button", {
							type: "button",
							onClick: () => f({
								type: "finalGuess",
								guesses: w
							}),
							className: "tile-btn min-h-12 w-full border-3 border-ink text-base font-extrabold text-white",
							style: { background: d.accent },
							children: p("games.lostcode.finalSubmit")
						})
					]
				})]
			}),
			children: /* @__PURE__ */ c("div", {
				className: "lostcode-main",
				children: [
					/* @__PURE__ */ s(V, {
						pub: e,
						members: l,
						myRid: u
					}),
					/* @__PURE__ */ s(H, {
						pub: e,
						priv: t,
						myRid: u,
						nameOf: m,
						dummyLabel: p("games.lostcode.dummyLog"),
						myLabel: p("games.lostcode.myLog")
					}),
					/* @__PURE__ */ c("div", {
						className: "lostcode-roll-area",
						children: [/* @__PURE__ */ s("div", {
							className: "lostcode-dice-slot",
							children: e.dice && /* @__PURE__ */ s(U, {
								dice: e.dice,
								canFlip: e.phase === "flip" && M,
								flipDie: y,
								onPickDie: (e) => b(y === e ? null : e)
							})
						}), /* @__PURE__ */ s("div", {
							className: "lostcode-flip-slot",
							children: e.phase === "flip" && M && y !== null && /* @__PURE__ */ s("div", {
								className: "lostcode-flip-options flex justify-center gap-1.5",
								children: I.map((e, t) => /* @__PURE__ */ s("button", {
									type: "button",
									"aria-label": p(F[t]),
									onClick: () => f({
										type: "flip",
										die: y,
										symbol: t
									}),
									className: `tile-btn min-h-11 min-w-11 border-2 border-ink text-xl ${L[t]}`,
									children: e
								}, t))
							})
						})]
					}),
					e.discards.length > 0 && /* @__PURE__ */ c("div", {
						className: "lostcode-discards flex flex-wrap items-center gap-1",
						children: [/* @__PURE__ */ s("span", {
							className: "text-xs font-bold text-ink/60",
							children: p("games.lostcode.discardTitle")
						}), e.discards.map((e, t) => /* @__PURE__ */ c("span", {
							className: `rounded-md border border-ink px-1 font-mono text-xs font-extrabold ${L[e.symbol]}`,
							children: [I[e.symbol], e.value]
						}, t))]
					}),
					e.phase === "token" && e.tokenOffer && A && /* @__PURE__ */ s(ee, {
						title: p("games.lostcode.tokenBet", { symbol: p(F[e.tokenOffer.symbol]) }),
						picks: S,
						onToggle: (e) => C((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < 3 ? [...t, e] : t)
					}),
					e.phase === "guess" && k && /* @__PURE__ */ s(W, {
						pub: e,
						t: p,
						nameOf: m,
						wheel: h,
						onWheel: (e) => {
							g(e), v(0);
						},
						lo: $,
						maxLo: Q,
						onLo: v
					}),
					e.results.length > 0 && /* @__PURE__ */ s(G, {
						pub: e,
						t: p,
						nameOf: m
					}),
					e.phase === "exchange" && j && /* @__PURE__ */ s("div", {
						className: "lostcode-exchange grid grid-cols-3 gap-1.5",
						children: I.map((t, n) => /* @__PURE__ */ c("button", {
							type: "button",
							disabled: e.piles[n] === 0,
							onClick: () => f({
								type: "exchange",
								symbol: n
							}),
							className: `tile-btn min-h-12 border-2 border-ink text-sm font-extrabold disabled:opacity-30 ${L[n]}`,
							children: [
								t,
								" ",
								p(F[n]),
								/* @__PURE__ */ s("span", {
									className: "block font-mono text-[10px] font-bold opacity-70",
									children: p("games.lostcode.pileCount", { n: e.piles[n] })
								})
							]
						}, n))
					}),
					e.phase === "final" && !e.finalsIn.includes(u) && /* @__PURE__ */ s(te, {
						finals: w,
						locked: t?.myLocked ?? [
							,
							,
							,
							,
							,
							,
						].fill(!1),
						onToggle: X,
						t: p
					}),
					e.phase === "done" && t?.myStones && /* @__PURE__ */ c("div", {
						className: "frame p-2",
						children: [/* @__PURE__ */ s("p", {
							className: "section-label",
							children: p("games.lostcode.myStones")
						}), /* @__PURE__ */ s("div", {
							className: "mt-1 flex justify-center gap-1.5",
							children: t.myStones.map((e, t) => /* @__PURE__ */ c("span", {
								className: `min-w-9 rounded-lg border-2 border-ink px-1 py-1 text-center font-mono text-sm font-extrabold ${L[t]}`,
								children: [I[t], e]
							}, t))
						})]
					})
				]
			})
		}), E && t && /* @__PURE__ */ c("div", {
			className: "lostcode-notes absolute inset-0 z-10 flex flex-col rounded-2xl border-3 border-ink bg-surface shadow-[6px_6px_0_var(--color-ink)]",
			children: [
				/* @__PURE__ */ c("div", {
					className: "flex flex-none items-center justify-between px-3 py-2",
					children: [/* @__PURE__ */ c("p", {
						className: "text-sm font-extrabold",
						children: ["📝 ", p("games.lostcode.notesTitle")]
					}), /* @__PURE__ */ s("button", {
						type: "button",
						onClick: () => D(!1),
						className: "btn-quiet min-h-11 px-3 text-sm font-extrabold",
						"aria-label": p("games.lostcode.notesTitle"),
						children: "✕"
					})]
				}),
				/* @__PURE__ */ s("p", {
					className: "flex-none px-3 pb-1 text-[11px] font-bold text-ink/60",
					children: p("games.lostcode.noteEmpty")
				}),
				/* @__PURE__ */ s("div", {
					className: "min-h-0 flex-1 overflow-y-auto px-2 pb-2",
					children: /* @__PURE__ */ c("div", {
						className: "lostcode-notes-grid grid grid-cols-[2rem_repeat(6,1fr)] gap-1",
						children: [
							/* @__PURE__ */ s("span", {}),
							I.map((e, t) => /* @__PURE__ */ s("span", {
								className: `rounded-md border border-ink py-0.5 text-center text-sm ${L[t]}`,
								"aria-label": p(F[t]),
								children: e
							}, t)),
							Array.from({ length: 8 }, (e, n) => /* @__PURE__ */ c("div", {
								className: "contents",
								children: [/* @__PURE__ */ s("span", {
									className: "flex items-center justify-center font-mono text-xs font-extrabold text-ink/70",
									children: n
								}), Array.from({ length: 6 }, (e, r) => {
									let i = t.notes[r][n];
									return /* @__PURE__ */ s("button", {
										type: "button",
										"aria-label": `${p(F[r])} ${n}`,
										onClick: () => f({
											type: "note",
											symbol: r,
											value: n
										}),
										className: `min-h-11 rounded-md border-2 border-ink/30 font-mono text-sm font-extrabold ${i === 1 ? "bg-ink/10 text-ink line-through" : i === 2 ? "bg-done-soft text-done-ink" : "bg-surface"}`,
										children: i === 1 ? "✕" : i === 2 ? "◯" : ""
									}, r);
								})]
							}, n))
						]
					})
				})
			]
		})]
	});
}
function V({ pub: e, members: t, myRid: n }) {
	let r = Object.keys(e.pos), i = r.map((t) => e.pos[t]), a = Math.min(0, ...i), o = Math.max(10, ...i), l = Math.max(1, o - a), u = /* @__PURE__ */ new Map();
	return e.stack.forEach((t) => {
		let n = e.stack.filter((n) => e.pos[n] === e.pos[t]);
		u.set(t, n.indexOf(t));
	}), /* @__PURE__ */ c("div", {
		className: "lostcode-track frame relative flex-none overflow-hidden",
		children: [/* @__PURE__ */ s("div", { className: "lostcode-track-line absolute h-1 rounded bg-ink/15" }), r.map((r) => {
			let i = (e.pos[r] - a) / l * 100, o = u.get(r) ?? 0, c = r === n;
			return /* @__PURE__ */ s("div", {
				className: "lostcode-track-marker absolute flex items-center justify-center rounded-full border-2 border-ink px-1 font-mono font-extrabold tabular-nums",
				style: {
					left: `calc(var(--lostcode-track-inset) + (100% - 2 * var(--lostcode-track-inset)) * ${i / 100})`,
					bottom: `calc(var(--lostcode-track-padding) + ${o} * var(--lostcode-track-step))`,
					transform: "translateX(-50%)",
					background: c ? "var(--color-ink)" : "var(--color-surface)",
					color: c ? "var(--color-surface)" : "var(--color-ink)"
				},
				title: t.find((e) => e.rid === r)?.name ?? r,
				children: e.pos[r]
			}, r);
		})]
	});
}
function H({ pub: e, priv: t, myRid: n, nameOf: r, dummyLabel: i, myLabel: a }) {
	return /* @__PURE__ */ s("div", {
		className: "lostcode-logs grid flex-none grid-cols-4 gap-1.5",
		children: e.logs.map((e, o) => {
			let l = t?.logStones[o] ?? null, u = e.owner === n;
			return /* @__PURE__ */ c("div", {
				className: `lostcode-log frame p-1 ${u ? "border-ink" : ""}`,
				style: u ? { boxShadow: `3px 3px 0 ${d.accent}` } : void 0,
				children: [/* @__PURE__ */ s("p", {
					className: "lostcode-log-name text-center font-extrabold text-ink/70",
					children: e.owner ? u ? a : r(e.owner) : i
				}), /* @__PURE__ */ s("div", {
					className: "lostcode-stones mt-0.5 grid grid-cols-3 gap-0.5",
					children: I.map((e, t) => /* @__PURE__ */ s("span", {
						className: `lostcode-stone rounded border border-ink/40 py-0.5 text-center font-mono font-extrabold tabular-nums ${L[t]}`,
						title: e,
						children: l ? l[t] : "?"
					}, t))
				})]
			}, o);
		})
	});
}
function U({ dice: e, canFlip: t, flipDie: n, onPickDie: r }) {
	return /* @__PURE__ */ s("div", {
		className: "lostcode-dice flex flex-none justify-center gap-2",
		children: e.map((e, i) => t ? /* @__PURE__ */ s("button", {
			type: "button",
			onClick: () => r(i),
			className: `lostcode-die tile-btn h-12 w-12 rounded-xl border-3 border-ink text-2xl ${L[e]} ${n === i ? "ring-3 ring-ink" : ""}`,
			children: I[e]
		}, i) : /* @__PURE__ */ s("span", {
			className: `lostcode-die flex h-12 w-12 items-center justify-center rounded-xl border-3 border-ink text-2xl ${L[e]}`,
			children: I[e]
		}, i))
	});
}
function W({ pub: e, t, nameOf: n, wheel: r, onWheel: i, lo: a, maxLo: o, onLo: l }) {
	let u = r === null ? null : x[r];
	return /* @__PURE__ */ c("div", {
		className: "lostcode-guess flex flex-col gap-2",
		children: [/* @__PURE__ */ s("div", {
			className: "lostcode-wheels grid grid-cols-4 gap-1.5",
			children: e.wheels.map((e, a) => /* @__PURE__ */ c("button", {
				type: "button",
				disabled: !!e.by,
				onClick: () => i(a),
				className: `lostcode-wheel tile-btn min-h-12 border-2 border-ink px-1 text-xs font-extrabold disabled:opacity-40 ${r === a ? "text-white" : "bg-surface"}`,
				style: r === a ? { background: d.accent } : void 0,
				children: [
					t("games.lostcode.wheelVp", { n: e.vp }),
					" · ",
					t("games.lostcode.wheelWindow", { n: e.w }),
					e.by && /* @__PURE__ */ s("span", {
						className: "lostcode-wheel-owner block font-bold opacity-70",
						children: t("games.lostcode.wheelTaken", { name: n(e.by) })
					})
				]
			}, a))
		}), /* @__PURE__ */ s("div", {
			className: "lostcode-range-slot",
			children: u && /* @__PURE__ */ c("div", {
				className: "lostcode-range flex items-center justify-center gap-3",
				children: [
					/* @__PURE__ */ s("button", {
						type: "button",
						"aria-label": "-",
						disabled: a <= 0,
						onClick: () => l(Math.max(0, a - 1)),
						className: "btn-quiet min-h-11 min-w-11 text-lg font-extrabold disabled:opacity-30",
						children: "−"
					}),
					/* @__PURE__ */ s("span", {
						className: "font-mono text-lg font-extrabold tabular-nums",
						children: t("games.lostcode.rangeLabel", {
							lo: a,
							hi: a + u.w - 1
						})
					}),
					/* @__PURE__ */ s("button", {
						type: "button",
						"aria-label": "+",
						disabled: a >= o,
						onClick: () => l(Math.min(o, a + 1)),
						className: "btn-quiet min-h-11 min-w-11 text-lg font-extrabold disabled:opacity-30",
						children: "+"
					})
				]
			})
		})]
	});
}
function G({ pub: e, t, nameOf: n }) {
	return /* @__PURE__ */ s("div", {
		className: "lostcode-results flex flex-col gap-1",
		children: e.results.map((r, i) => {
			let a = e.guesses[r.rid], o = a ? x[a.wheel] : null;
			return /* @__PURE__ */ c("div", {
				className: "tile-enter flex items-center gap-2 rounded-xl border-2 border-ink bg-surface px-2 py-1 text-xs font-bold",
				children: [
					/* @__PURE__ */ s("span", {
						className: "min-w-0 flex-1 truncate",
						children: n(r.rid)
					}),
					o && a && /* @__PURE__ */ s("span", {
						className: "font-mono tabular-nums",
						children: t("games.lostcode.rangeLabel", {
							lo: a.lo,
							hi: a.lo + o.w - 1
						})
					}),
					/* @__PURE__ */ c("span", {
						className: r.ok ? "text-done-ink" : "text-warn-ink",
						children: [r.ok ? t("games.lostcode.hit", { n: r.vp }) : r.dir === "higher" ? t("games.lostcode.missHigher") : r.dir === "lower" ? t("games.lostcode.missLower") : t("games.lostcode.missOnly"), !r.ok && r.vp < 0 ? ` ${t("games.lostcode.curseBack", { n: -r.vp })}` : ""]
					})
				]
			}, i);
		})
	});
}
function ee({ title: e, picks: t, onToggle: n }) {
	return /* @__PURE__ */ c("div", {
		className: "lostcode-bet frame p-2",
		children: [/* @__PURE__ */ s("p", {
			className: "mb-1 text-xs font-extrabold",
			children: e
		}), /* @__PURE__ */ s("div", {
			className: "lostcode-number-grid grid grid-cols-4 gap-1",
			children: Array.from({ length: 8 }, (e, r) => /* @__PURE__ */ s("button", {
				type: "button",
				onClick: () => n(r),
				className: `min-h-11 rounded-lg border-2 border-ink font-mono text-sm font-extrabold ${t.includes(r) ? "bg-ink text-surface" : "bg-surface"}`,
				children: r
			}, r))
		})]
	});
}
function te({ finals: e, locked: t, onToggle: n, t: r }) {
	return /* @__PURE__ */ s("div", {
		className: "lostcode-finals flex flex-col gap-1.5",
		children: I.map((i, a) => /* @__PURE__ */ c("div", {
			className: "lostcode-final-row frame flex items-center gap-1.5 p-1.5",
			children: [
				/* @__PURE__ */ s("span", {
					className: `flex h-9 w-9 flex-none items-center justify-center rounded-lg border-2 border-ink text-lg ${L[a]}`,
					title: r(F[a]),
					children: i
				}),
				/* @__PURE__ */ s("div", {
					className: "lostcode-number-grid grid min-w-0 flex-1 grid-cols-4 gap-1",
					children: Array.from({ length: 8 }, (r, i) => {
						let o = e[a]?.includes(i) ?? !1;
						return /* @__PURE__ */ s("button", {
							type: "button",
							disabled: t[a],
							onClick: () => n(a, i),
							className: `min-h-11 rounded-md border-2 font-mono text-sm font-extrabold disabled:opacity-60 ${o ? "border-ink bg-ink text-surface" : "border-ink/30 bg-surface"}`,
							children: i
						}, i);
					})
				}),
				t[a] && /* @__PURE__ */ s("span", {
					className: "flex-none text-sm",
					title: r("games.lostcode.finalLocked"),
					children: "🔒"
				})
			]
		}, a))
	});
}
//#endregion
//#region src/games/lostcode/bot.ts
function K(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
function q(e) {
	let t = new Map(e.stack.map((e, t) => [e, t]));
	return Object.keys(e.pos).sort((n, r) => e.pos[n] - e.pos[r] || (t.get(r) ?? 0) - (t.get(n) ?? 0))[0];
}
function J(e, t) {
	let n = e.public, r = e.private, i = Array.from({ length: 6 }, (e, t) => {
		let i = /* @__PURE__ */ new Set();
		for (let e of r?.logStones ?? []) e && i.add(e[t]);
		for (let e of n.discards) e.symbol === t && i.add(e.value);
		return Array.from({ length: 8 }, (e, t) => t).filter((e) => !i.has(e));
	});
	if (!r) return i;
	let a = /* @__PURE__ */ new Map();
	n.history.forEach((e, n) => {
		for (let r of e.discards) {
			if (r.by !== t) continue;
			let e = a.get(r.symbol) ?? [];
			e.push({
				r: n,
				value: r.value
			}), a.set(r.symbol, e);
		}
	});
	let o = [];
	n.history.forEach((e, n) => {
		let r = e.results.find((e) => e.rid === t);
		if (!r) return;
		let i = x[r.wheel], s, c;
		if (r.ok) s = r.lo, c = r.lo + i.w - 1;
		else if (r.dir === "higher") s = r.lo + i.w, c = 21;
		else if (r.dir === "lower") s = 0, c = r.lo - 1;
		else return;
		let l = /* @__PURE__ */ new Map();
		for (let t of e.dice) l.set(t, (l.get(t) ?? 0) + 1);
		let u = [], d = 0;
		for (let [e, t] of l) {
			let r = a.get(e)?.find((e) => e.r >= n);
			r ? d += t * r.value : u.push([e, t]);
		}
		u.length > 0 && o.push({
			terms: u,
			base: d,
			lo: s,
			hi: c
		});
	});
	let s = !0;
	for (; s;) {
		s = !1;
		for (let e of o) for (let t = 0; t < e.terms.length; t += 1) {
			let [n, r] = e.terms[t], a = e.terms.filter((e, n) => n !== t), o = a.length === 0 ? [0] : a.length === 1 ? i[a[0][0]].map((e) => a[0][1] * e) : i[a[0][0]].flatMap((e) => i[a[1][0]].map((t) => a[0][1] * e + a[1][1] * t)), c = i[n].filter((t) => o.some((n) => e.lo <= e.base + r * t + n && e.base + r * t + n <= e.hi));
			c.length > 0 && c.length < i[n].length && (i[n] = c, s = !0);
		}
	}
	return i;
}
function Y(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t, (n.get(t) ?? 0) + 1);
	let r = [...n.entries()], i = Array(22).fill(0), a = (e, n) => {
		if (e >= r.length) {
			i[n] += 1;
			return;
		}
		let [o, s] = r[e];
		for (let r of t[o]) a(e + 1, n + s * r);
	};
	return a(0, 0), i;
}
function X(e, t, n, r) {
	let i = null;
	for (let a = 0; a < x.length; a += 1) {
		if (e.wheels[a].by) continue;
		let { vp: o, w: s } = x[a];
		for (let e = 0; e + s - 1 <= 21; e += 1) {
			let c = 0;
			for (let n = e; n < e + s; n += 1) c += t[n];
			let l = n > 0 ? c / n : 0, u = r ? o * (2 * l - 1) : o * l;
			(!i || u > i.ev || u === i.ev && l > i.p) && (i = {
				wheel: a,
				lo: e,
				ev: u,
				p: l
			});
		}
	}
	return i;
}
function Z(e, t) {
	if (e <= 0) return null;
	let n = t ? 4 : 2, r = t ? 2 : 1, i = null, a = 0;
	for (let t = 1; t <= Math.min(3, e); t += 1) {
		let o = t / e, s = o * C[t] * r - (1 - o) * n;
		s > a && (a = s, i = t);
	}
	return i;
}
var Q = (e, t) => {
	let n = e.public, r = e.private, i = t.rid, a = t.difficulty === "weak", o = n.curse.state === "on" && n.curse.owner === i;
	switch (n.phase) {
		case "roll": return q(n) === i ? { action: { type: "roll" } } : null;
		case "token": {
			if (!n.tokenOffer || n.tokenOffer.queue[0] !== i) return null;
			if (a) return { action: { type: "passToken" } };
			let t = n.tokenOffer.symbol, r = J(e, i)[t], o = Z(r.length, !0);
			return o ? { action: {
				type: "takeToken",
				guess: r.slice(0, o)
			} } : { action: { type: "passToken" } };
		}
		case "flip": {
			if (n.roller !== i || !n.dice) return null;
			if (a) return { action: { type: "noFlip" } };
			let t = J(e, i), r = (e) => {
				let r = Y(e, t), i = r.reduce((e, t) => e + t, 0);
				return X(n, r, i, o)?.ev ?? 0;
			}, s = r(n.dice), c = null;
			for (let e = 0; e < 3; e += 1) for (let t = 0; t < 6; t += 1) {
				if (t === n.dice[e]) continue;
				let i = r(n.dice.map((n, r) => r === e ? t : n));
				i > s + .25 && (!c || i > c.ev) && (c = {
					die: e,
					symbol: t,
					ev: i
				});
			}
			return c ? { action: {
				type: "flip",
				die: c.die,
				symbol: c.symbol
			} } : { action: { type: "noFlip" } };
		}
		case "guess": {
			if (n.guessOrder[n.guessIndex] !== i || !n.dice) return null;
			if (a) {
				let e = x.map((e, t) => t).filter((e) => !n.wheels[e].by), t = e[K(e.length)];
				return { action: {
					type: "guess",
					wheel: t,
					lo: K(21 - x[t].w + 2)
				} };
			}
			let t = Y(n.dice, J(e, i)), r = X(n, t, t.reduce((e, t) => e + t, 0), o);
			return r ? { action: {
				type: "guess",
				wheel: r.wheel,
				lo: r.lo
			} } : null;
		}
		case "exchange": {
			if (n.exchangeQueue[n.exchangeIndex] !== i) return null;
			let t = Array.from({ length: 6 }, (e, t) => t).filter((e) => n.piles[e] > 0);
			if (t.length === 0) return null;
			if (a) return { action: {
				type: "exchange",
				symbol: t[K(t.length)]
			} };
			let r = J(e, i), o = Math.max(...t.map((e) => r[e].length)), s = t.filter((e) => r[e].length === o);
			return { action: {
				type: "exchange",
				symbol: s[K(s.length)]
			} };
		}
		case "final": {
			if (n.finalsIn.includes(i) || !r) return null;
			let t = J(e, i);
			return { action: {
				type: "finalGuess",
				guesses: Array.from({ length: 6 }, (e, o) => {
					if (r.myLocked[o]) return r.myFinals[o] ? [...r.myFinals[o]] : null;
					if (a) {
						if (K(2) === 0) return null;
						let e = 1 + K(3), t = Array.from({ length: 8 }, (e, t) => t), n = [];
						for (; n.length < e && t.length > 0;) n.push(t.splice(K(t.length), 1)[0]);
						return n.sort((e, t) => e - t);
					}
					let s = Z(t[o].length, n.tokens[o].holder === i);
					return s ? t[o].slice(0, s) : null;
				})
			} };
		}
		default: return null;
	}
}, $ = [
	"games.lostcode.symBird",
	"games.lostcode.symJaguar",
	"games.lostcode.symChameleon",
	"games.lostcode.symSnake",
	"games.lostcode.symHuman",
	"games.lostcode.symBear"
], ne = (e, t, n) => {
	let r = (e) => n($[e]);
	switch (e.type) {
		case "roll": return n("games.lostcode.hintRoll");
		case "flip": {
			let i = t.public.dice?.[e.die];
			return n("games.lostcode.hintFlip", {
				from: i === void 0 ? "?" : r(i),
				to: r(e.symbol)
			});
		}
		case "noFlip": return n("games.lostcode.hintNoFlip");
		case "takeToken": return n("games.lostcode.hintTakeToken", {
			symbol: r(t.public.tokenOffer?.symbol ?? 0),
			values: e.guess.join("/")
		});
		case "passToken": return n("games.lostcode.hintPassToken");
		case "guess": {
			let t = x[e.wheel];
			return n("games.lostcode.hintGuess", {
				vp: t.vp,
				lo: e.lo,
				hi: e.lo + t.w - 1
			});
		}
		case "exchange": return n("games.lostcode.hintExchange", { symbol: r(e.symbol) });
		default: return n("games.lostcode.hintFinal");
	}
};
//#endregion
//#region src/games/lostcode/game-over.tsx
function re(e) {
	return /* @__PURE__ */ s("div", {
		className: "lostcode-game-over",
		children: /* @__PURE__ */ s(l, {
			...e,
			accent: d.accent
		})
	});
}
//#endregion
//#region src/games/lostcode/options.tsx
function ie({ value: e, onChange: t }) {
	let n = r(), i = y.safeParse(e), a = i.success ? i.data : y.parse(void 0), o = (e, n, r) => /* @__PURE__ */ s(u, {
		checked: a[e],
		label: n,
		hint: r,
		accent: d.accent,
		onChange: () => t({
			...a,
			[e]: !a[e]
		})
	}, e);
	return /* @__PURE__ */ c("div", {
		className: "flex flex-col gap-2",
		children: [o("curse", n("games.lostcode.optCurse"), n("games.lostcode.optCurseDesc")), o("shortcut", n("games.lostcode.optShortcut"), n("games.lostcode.optShortcutDesc"))]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/lostcode/entry.tsx
var ae = {
	definition: P,
	View: R,
	bot: Q,
	describe: ne,
	OverView: re,
	Options: ie,
	locales: {
		zh: {
			name: "迷失代码",
			desc: "看得见所有人的数字,唯独看不见自己的",
			rules: "目标:终局押注后,计分轨上最前者获胜(平局时并列堆底部者胜)。\n准备:\n· 6 种符号(鸟/美洲豹/变色龙/蛇/人/熊)各有数字 0-7 的石头;\n  每符号先秘密移出 1 块回盒。\n· 每个石板每符号插 1 块石头:数字只有主人看不见,其他人全可见;空位石板填满且完全公开。\n· 指示物在起点随机叠放(叠序是平局判据);2 人 10 轮、3 人 9 轮、4 人 8 轮。\n流程:\n· 每轮由计分轨最后一名掷 3 个符号骰,可把其中 1 个翻成任意符号。\n· 从最后一名起逆序选 1 个轮盘,并定出窗口覆盖的范围。\n  轮盘分值 1/2/2/3/3/4/5,对应窗口格数 10/7/5/4/3/2/1。\n· 从掷骰者起逐个结算:猜的是自己石板上被掷出符号对应数字之和。\n  命中获得轮盘分并前进;猜错由他人诚实告知真实和偏高或偏低(5 分轮盘只报对错)。\n· 全部结算完后,猜错者按计分逆序换石:\n  弃 1 块石头(公开),从同符号堆抽 1 块新石头(自己看不见)。\n结束:\n· 最后一轮后,每人为自己每个符号押 1-3 个数字:\n  押中分别获得 5/2/1 分,没押或押错扣 2 分,折算成轨道移动(可为负)。\n变体:\n· 神庙诅咒:首个到达第 7 格者被诅咒——别人猜错时自己获得 1 分,\n  自己猜错倒扣轮盘分并后退;有人到 13 格或最后一轮开始前移除。\n· 死亡捷径:掷出对子/三条时可认领该符号标记并立即锁定终局押注,\n  押中得分翻倍、押错扣 4 分;最后 3 轮禁用。",
			roundShort: "{{n}}/{{total}}",
			symBird: "鸟",
			symJaguar: "美洲豹",
			symChameleon: "变色龙",
			symSnake: "蛇",
			symHuman: "人",
			symBear: "熊",
			rollYou: "你排在最后一名,轮到你掷骰",
			rollWait: "等 {{name}} 掷骰…",
			roll: "掷骰",
			flipPrompt: "可把 1 个骰子翻成任意符号,或不翻",
			noFlip: "不翻骰",
			tokenTitle: "掷出重复的 {{symbol}}!",
			tokenPrompt: "认领死亡捷径标记?认领后需立即押注该符号(终局锁定)",
			tokenWait: "等 {{name}} 决定是否认领捷径…",
			takeToken: "认领并押注",
			passToken: "跳过",
			tokenBet: "为 {{symbol}} 押 1-3 个数字(终局锁定,押中得分翻倍、押错扣 4 分)",
			guessYou: "选一个轮盘并定范围",
			guessWait: "等 {{name}} 选轮盘…",
			wheelVp: "{{n}} 分",
			wheelWindow: "{{n}} 格",
			wheelTaken: "已被 {{name}} 拿走",
			rangeLabel: "范围 {{lo}} - {{hi}}",
			guessConfirm: "锁定猜测",
			guessDone: "已锁定,等其他人…",
			resolveTitle: "结算",
			hit: "命中 +{{n}}",
			missHigher: "猜错了:真实和更高",
			missLower: "猜错了:真实和更低",
			missOnly: "猜错了",
			curseBack: "诅咒 -{{n}}",
			exchangeYou: "猜错了:选一个符号换石头",
			exchangeWait: "等 {{name}} 换石头…",
			exchangeHint: "弃掉的石头公开;新石头只有你看不见",
			pileCount: "剩 {{n}} 块",
			discardTitle: "弃石",
			finalTitle: "终局押注",
			finalPrompt: "为每个符号押 1-3 个数字;押中 5/2/1 分,放弃或押错扣 2 分",
			finalLocked: "捷径已锁定",
			finalSubmit: "提交押注",
			finalWait: "已提交,等其他人…",
			finalDone: "全部提交,正在结算…",
			notesTitle: "推理纸",
			noteEmpty: "点格子涂叉,再点变圈,点第三次清除",
			dummyLog: "空位(公开)",
			myLog: "我的石板",
			curseBadge: "诅咒",
			tokenBadge: "捷径",
			myStones: "你的石头",
			optCurse: "神庙诅咒",
			optCurseDesc: "首个到达第 7 格者被诅咒:别人猜错时自己得 1 分,自己猜错倒扣分",
			optShortcut: "死亡捷径",
			optShortcutDesc: "掷出对子/三条可认领符号标记,锁定终局押注,押中得分翻倍",
			errPhase: "现在不能这么做",
			errNotYourTurn: "现在轮不到你",
			errNotLast: "只有最后一名能掷骰",
			errBadGuess: "押注数字不能重复",
			errBadWheel: "没有这个轮盘",
			errWheelTaken: "这个轮盘已被选走",
			errBadRange: "范围超出数字带",
			errPileEmpty: "该符号的石头堆已空",
			errLocked: "捷径锁定的押注不能改",
			hintRoll: "掷出 3 颗符号骰",
			hintFlip: "把 {{from}} 翻成 {{to}}",
			hintNoFlip: "不翻骰,直接进入猜测",
			hintTakeToken: "认领 {{symbol}} 捷径,押 {{values}}",
			hintPassToken: "放弃这次捷径",
			hintGuess: "选 {{vp}} 分轮盘,猜和在 {{lo}}~{{hi}}",
			hintExchange: "换掉 {{symbol}} 的石头",
			hintFinal: "提交终局押注"
		},
		en: {
			name: "The Lost Code",
			desc: "You can see everyone's numbers — except your own",
			rules: "Goal: after the final bets, whoever is farthest along the score track wins (ties go to the player at the bottom of the shared stack).\nSetup:\n· Six symbols (bird/jaguar/chameleon/snake/human/bear), stones numbered 0-7 each;\n  one stone per symbol is secretly returned to the box.\n· Each log holds one stone per symbol: the owner never sees their own numbers, everyone else does; empty logs are filled and fully public.\n· Pawns start stacked randomly on space 0 (stack order breaks ties); 10 rounds with 2 players, 9 with 3, 8 with 4.\nPlay:\n· Each round the last player on the track rolls 3 symbol dice and may flip one die to any symbol.\n· Starting from last place, players pick a wheel in turn and set the range its window covers.\n  Wheel values 1/2/2/3/3/4/5, window sizes 10/7/5/4/3/2/1.\n· From the roller on, guesses resolve: you guess the sum of your own stones of the rolled symbols.\n  Hit: gain the wheel value and move on. Miss: others must honestly say whether the true sum is higher or lower (the 5-point wheel only reveals right or wrong).\n· After all guesses, each misser in reverse score order swaps a stone:\n  discard one face-up (public) and draw 1 new stone from the same pile (hidden from yourself).\nEnd:\n· After the last round, bet 1-3 numbers on each of your symbols:\n  5/2/1 VP if right, lose 2 VP if wrong or skipped, applied as track movement (can go negative).\nVariants:\n· Curse of the Temple: the first player to reach space 7 is cursed — they gain 1 VP whenever anyone else misses,\n  but a miss of their own costs the wheel value and moves them back; the curse ends when someone reaches 13 or before the final round.\n· Deadly Shortcut: when doubles/triples are rolled, the matching token may be claimed to lock a final bet on that symbol —\n  double VP if right, lose 4 VP if wrong; unavailable in the last 3 rounds.",
			roundShort: "{{n}}/{{total}}",
			symBird: "Bird",
			symJaguar: "Jaguar",
			symChameleon: "Chameleon",
			symSnake: "Snake",
			symHuman: "Human",
			symBear: "Bear",
			rollYou: "You're last — roll the dice",
			rollWait: "Waiting for {{name}} to roll…",
			roll: "Roll",
			flipPrompt: "You may flip one die to any symbol, or keep them",
			noFlip: "Keep dice",
			tokenTitle: "Doubles on {{symbol}}!",
			tokenPrompt: "Claim the Deadly Shortcut token? You must bet on that symbol right away (locked for the endgame)",
			tokenWait: "Waiting for {{name}} to decide on the shortcut…",
			takeToken: "Claim & bet",
			passToken: "Pass",
			tokenBet: "Bet 1-3 numbers on {{symbol}} (locked; double VP if right, lose 4 VP if wrong)",
			guessYou: "Pick a wheel and set its range",
			guessWait: "Waiting for {{name}} to pick a wheel…",
			wheelVp: "{{n}} VP",
			wheelWindow: "{{n}} spaces",
			wheelTaken: "Taken by {{name}}",
			rangeLabel: "Range {{lo}} - {{hi}}",
			guessConfirm: "Lock guess",
			guessDone: "Locked — waiting for others…",
			resolveTitle: "Resolving",
			hit: "Hit +{{n}}",
			missHigher: "Miss — the true sum is higher",
			missLower: "Miss — the true sum is lower",
			missOnly: "Miss",
			curseBack: "Curse -{{n}}",
			exchangeYou: "You missed: pick a symbol to swap a stone",
			exchangeWait: "Waiting for {{name}} to swap a stone…",
			exchangeHint: "The discarded stone is public; the new one stays hidden from you",
			pileCount: "{{n}} left",
			discardTitle: "Discards",
			finalTitle: "Final bets",
			finalPrompt: "Bet 1-3 numbers per symbol: 5/2/1 VP if right, lose 2 VP if wrong or skipped",
			finalLocked: "Locked by shortcut",
			finalSubmit: "Submit bets",
			finalWait: "Submitted — waiting for others…",
			finalDone: "All bets in — scoring…",
			notesTitle: "Deduction sheet",
			noteEmpty: "Tap a cell to cross it, again to circle, a third time to clear",
			dummyLog: "Empty log (public)",
			myLog: "My log",
			curseBadge: "Cursed",
			tokenBadge: "Shortcut",
			myStones: "Your stones",
			optCurse: "Curse of the Temple",
			optCurseDesc: "First to space 7 is cursed: gain 1 VP when others miss, lose the wheel value on your own miss",
			optShortcut: "Deadly Shortcut",
			optShortcutDesc: "Claim a symbol token on doubles/triples to lock a final bet — double VP if right",
			errPhase: "Not allowed right now",
			errNotYourTurn: "Not your move right now",
			errNotLast: "Only the last player rolls",
			errBadGuess: "Bet numbers must be distinct",
			errBadWheel: "No such wheel",
			errWheelTaken: "That wheel is already taken",
			errBadRange: "Range is off the number strip",
			errPileEmpty: "That symbol pile is empty",
			errLocked: "Shortcut-locked bets cannot change",
			hintRoll: "Roll the 3 symbol dice",
			hintFlip: "Flip {{from}} into {{to}}",
			hintNoFlip: "Skip the flip and go straight to guessing",
			hintTakeToken: "Claim the {{symbol}} shortcut and bet {{values}}",
			hintPassToken: "Pass on this shortcut",
			hintGuess: "Take the {{vp}}-VP wheel and guess the sum is {{lo}}~{{hi}}",
			hintExchange: "Swap out the {{symbol}} stone",
			hintFinal: "Submit your final bets"
		}
	}
};
//#endregion
export { ae as default };
