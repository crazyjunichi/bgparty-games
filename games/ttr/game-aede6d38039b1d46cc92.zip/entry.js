import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useId as i, useMemo as a, useRef as o, useState as s } from "react";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as m, seatName as h } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as g } from "@bgparty/sdk/ui/game-screen";
import { IconBack as _, IconBot as v, IconExpand as y, IconLog as b, IconZoomIn as x, IconZoomOut as ee } from "@bgparty/sdk/icons";
import { Fragment as S, jsx as C, jsxs as w } from "react/jsx-runtime";
import { Floater as T, PulseBox as E } from "@bgparty/sdk/fx/primitives";
import { Confetti as D } from "@bgparty/sdk/ui/confetti";
//#region src/games/ttr/map-data.ts
var O = 1120, k = [
	"purple",
	"blue",
	"orange",
	"white",
	"green",
	"yellow",
	"black",
	"red"
], A = [
	{
		id: "atlanta",
		nameKey: "games.ttr.city.atlanta",
		x: 872.3,
		y: 642.5
	},
	{
		id: "boston",
		nameKey: "games.ttr.city.boston",
		x: 1060,
		y: 156
	},
	{
		id: "calgary",
		nameKey: "games.ttr.city.calgary",
		x: 249.7,
		y: 67.2
	},
	{
		id: "charleston",
		nameKey: "games.ttr.city.charleston",
		x: 976.5,
		y: 654.5
	},
	{
		id: "chicago",
		nameKey: "games.ttr.city.chicago",
		x: 762.1,
		y: 380.8
	},
	{
		id: "dallas",
		nameKey: "games.ttr.city.dallas",
		x: 614.5,
		y: 808.9
	},
	{
		id: "denver",
		nameKey: "games.ttr.city.denver",
		x: 427.1,
		y: 546.5
	},
	{
		id: "duluth",
		nameKey: "games.ttr.city.duluth",
		x: 624.8,
		y: 278.8
	},
	{
		id: "elpaso",
		nameKey: "games.ttr.city.elpaso",
		x: 412.8,
		y: 849.4
	},
	{
		id: "helena",
		nameKey: "games.ttr.city.helena",
		x: 361.5,
		y: 288.4
	},
	{
		id: "houston",
		nameKey: "games.ttr.city.houston",
		x: 661,
		y: 875.1
	},
	{
		id: "kansascity",
		nameKey: "games.ttr.city.kansascity",
		x: 614.9,
		y: 516.7
	},
	{
		id: "lasvegas",
		nameKey: "games.ttr.city.lasvegas",
		x: 218.7,
		y: 678.3
	},
	{
		id: "littlerock",
		nameKey: "games.ttr.city.littlerock",
		x: 692.9,
		y: 668.2
	},
	{
		id: "losangeles",
		nameKey: "games.ttr.city.losangeles",
		x: 147.1,
		y: 775.5
	},
	{
		id: "miami",
		nameKey: "games.ttr.city.miami",
		x: 1012.7,
		y: 918
	},
	{
		id: "montreal",
		nameKey: "games.ttr.city.montreal",
		x: 980.4,
		y: 60
	},
	{
		id: "nashville",
		nameKey: "games.ttr.city.nashville",
		x: 815.8,
		y: 583.5
	},
	{
		id: "neworleans",
		nameKey: "games.ttr.city.neworleans",
		x: 764.5,
		y: 855.4
	},
	{
		id: "newyork",
		nameKey: "games.ttr.city.newyork",
		x: 1001.5,
		y: 281.2
	},
	{
		id: "oklahomacity",
		nameKey: "games.ttr.city.oklahomacity",
		x: 592.6,
		y: 661.6
	},
	{
		id: "omaha",
		nameKey: "games.ttr.city.omaha",
		x: 591.8,
		y: 432.1
	},
	{
		id: "phoenix",
		nameKey: "games.ttr.city.phoenix",
		x: 280.4,
		y: 786.8
	},
	{
		id: "pittsburgh",
		nameKey: "games.ttr.city.pittsburgh",
		x: 907.7,
		y: 356.3
	},
	{
		id: "portland",
		nameKey: "games.ttr.city.portland",
		x: 75.9,
		y: 273.5
	},
	{
		id: "raleigh",
		nameKey: "games.ttr.city.raleigh",
		x: 945.4,
		y: 545.3
	},
	{
		id: "saintlouis",
		nameKey: "games.ttr.city.saintlouis",
		x: 710,
		y: 519.7
	},
	{
		id: "saltlakecity",
		nameKey: "games.ttr.city.saltlakecity",
		x: 281.6,
		y: 494.7
	},
	{
		id: "sanfrancisco",
		nameKey: "games.ttr.city.sanfrancisco",
		x: 60,
		y: 602
	},
	{
		id: "santafe",
		nameKey: "games.ttr.city.santafe",
		x: 418.8,
		y: 698
	},
	{
		id: "saultstmarie",
		nameKey: "games.ttr.city.saultstemarie",
		x: 767.2,
		y: 168.5
	},
	{
		id: "seattle",
		nameKey: "games.ttr.city.seattle",
		x: 100.2,
		y: 186.4
	},
	{
		id: "toronto",
		nameKey: "games.ttr.city.toronto",
		x: 889,
		y: 203.7
	},
	{
		id: "vancouver",
		nameKey: "games.ttr.city.vancouver",
		x: 105.3,
		y: 96.4
	},
	{
		id: "washington",
		nameKey: "games.ttr.city.washington",
		x: 1010.3,
		y: 432.7
	},
	{
		id: "winnipeg",
		nameKey: "games.ttr.city.winnipeg",
		x: 499.1,
		y: 85.6
	}
], j = [
	{
		a: "vancouver",
		b: "calgary",
		len: 3,
		color: "gray"
	},
	{
		a: "vancouver",
		b: "seattle",
		len: 1,
		color: "gray",
		double: 0
	},
	{
		a: "vancouver",
		b: "seattle",
		len: 1,
		color: "gray",
		double: 1
	},
	{
		a: "seattle",
		b: "calgary",
		len: 4,
		color: "gray"
	},
	{
		a: "seattle",
		b: "helena",
		len: 6,
		color: "yellow"
	},
	{
		a: "seattle",
		b: "portland",
		len: 1,
		color: "gray",
		double: 0
	},
	{
		a: "seattle",
		b: "portland",
		len: 1,
		color: "gray",
		double: 1
	},
	{
		a: "portland",
		b: "saltlakecity",
		len: 6,
		color: "blue"
	},
	{
		a: "portland",
		b: "sanfrancisco",
		len: 5,
		color: "green",
		double: 0
	},
	{
		a: "portland",
		b: "sanfrancisco",
		len: 5,
		color: "purple",
		double: 1
	},
	{
		a: "sanfrancisco",
		b: "saltlakecity",
		len: 5,
		color: "orange",
		double: 0
	},
	{
		a: "sanfrancisco",
		b: "saltlakecity",
		len: 5,
		color: "white",
		double: 1
	},
	{
		a: "sanfrancisco",
		b: "losangeles",
		len: 3,
		color: "yellow",
		double: 0
	},
	{
		a: "sanfrancisco",
		b: "losangeles",
		len: 3,
		color: "purple",
		double: 1
	},
	{
		a: "losangeles",
		b: "lasvegas",
		len: 2,
		color: "gray"
	},
	{
		a: "losangeles",
		b: "phoenix",
		len: 3,
		color: "gray"
	},
	{
		a: "losangeles",
		b: "elpaso",
		len: 6,
		color: "black",
		via: [283, 848]
	},
	{
		a: "calgary",
		b: "winnipeg",
		len: 6,
		color: "white"
	},
	{
		a: "calgary",
		b: "helena",
		len: 4,
		color: "gray"
	},
	{
		a: "helena",
		b: "winnipeg",
		len: 4,
		color: "blue"
	},
	{
		a: "helena",
		b: "saltlakecity",
		len: 3,
		color: "purple"
	},
	{
		a: "helena",
		b: "denver",
		len: 4,
		color: "green"
	},
	{
		a: "helena",
		b: "duluth",
		len: 6,
		color: "orange"
	},
	{
		a: "helena",
		b: "omaha",
		len: 5,
		color: "red"
	},
	{
		a: "saltlakecity",
		b: "denver",
		len: 3,
		color: "red",
		double: 0
	},
	{
		a: "saltlakecity",
		b: "denver",
		len: 3,
		color: "yellow",
		double: 1
	},
	{
		a: "lasvegas",
		b: "saltlakecity",
		len: 3,
		color: "orange"
	},
	{
		a: "phoenix",
		b: "denver",
		len: 5,
		color: "white"
	},
	{
		a: "phoenix",
		b: "santafe",
		len: 3,
		color: "gray"
	},
	{
		a: "phoenix",
		b: "elpaso",
		len: 3,
		color: "gray"
	},
	{
		a: "winnipeg",
		b: "saultstmarie",
		len: 6,
		color: "gray"
	},
	{
		a: "winnipeg",
		b: "duluth",
		len: 4,
		color: "black"
	},
	{
		a: "duluth",
		b: "saultstmarie",
		len: 3,
		color: "gray"
	},
	{
		a: "duluth",
		b: "toronto",
		len: 6,
		color: "purple"
	},
	{
		a: "duluth",
		b: "chicago",
		len: 3,
		color: "red"
	},
	{
		a: "duluth",
		b: "omaha",
		len: 2,
		color: "gray",
		double: 0
	},
	{
		a: "duluth",
		b: "omaha",
		len: 2,
		color: "gray",
		double: 1
	},
	{
		a: "omaha",
		b: "chicago",
		len: 4,
		color: "blue"
	},
	{
		a: "omaha",
		b: "kansascity",
		len: 1,
		color: "gray",
		double: 0
	},
	{
		a: "omaha",
		b: "kansascity",
		len: 1,
		color: "gray",
		double: 1
	},
	{
		a: "kansascity",
		b: "saintlouis",
		len: 2,
		color: "blue",
		double: 0
	},
	{
		a: "kansascity",
		b: "saintlouis",
		len: 2,
		color: "purple",
		double: 1
	},
	{
		a: "kansascity",
		b: "oklahomacity",
		len: 2,
		color: "gray",
		double: 0
	},
	{
		a: "kansascity",
		b: "oklahomacity",
		len: 2,
		color: "gray",
		double: 1
	},
	{
		a: "oklahomacity",
		b: "littlerock",
		len: 2,
		color: "gray"
	},
	{
		a: "oklahomacity",
		b: "dallas",
		len: 2,
		color: "gray",
		double: 0
	},
	{
		a: "oklahomacity",
		b: "dallas",
		len: 2,
		color: "gray",
		double: 1
	},
	{
		a: "dallas",
		b: "littlerock",
		len: 2,
		color: "gray"
	},
	{
		a: "dallas",
		b: "houston",
		len: 1,
		color: "gray",
		double: 0
	},
	{
		a: "dallas",
		b: "houston",
		len: 1,
		color: "gray",
		double: 1
	},
	{
		a: "houston",
		b: "neworleans",
		len: 2,
		color: "gray"
	},
	{
		a: "elpaso",
		b: "houston",
		len: 6,
		color: "green"
	},
	{
		a: "elpaso",
		b: "dallas",
		len: 4,
		color: "red"
	},
	{
		a: "elpaso",
		b: "oklahomacity",
		len: 5,
		color: "yellow"
	},
	{
		a: "elpaso",
		b: "santafe",
		len: 2,
		color: "gray"
	},
	{
		a: "santafe",
		b: "oklahomacity",
		len: 3,
		color: "blue"
	},
	{
		a: "oklahomacity",
		b: "denver",
		len: 4,
		color: "red"
	},
	{
		a: "santafe",
		b: "denver",
		len: 2,
		color: "gray"
	},
	{
		a: "denver",
		b: "kansascity",
		len: 4,
		color: "black",
		double: 0
	},
	{
		a: "denver",
		b: "kansascity",
		len: 4,
		color: "orange",
		double: 1
	},
	{
		a: "denver",
		b: "omaha",
		len: 4,
		color: "purple"
	},
	{
		a: "neworleans",
		b: "miami",
		len: 6,
		color: "red"
	},
	{
		a: "neworleans",
		b: "atlanta",
		len: 4,
		color: "orange",
		double: 0
	},
	{
		a: "neworleans",
		b: "atlanta",
		len: 4,
		color: "yellow",
		double: 1
	},
	{
		a: "neworleans",
		b: "littlerock",
		len: 3,
		color: "green"
	},
	{
		a: "littlerock",
		b: "nashville",
		len: 3,
		color: "white"
	},
	{
		a: "littlerock",
		b: "saintlouis",
		len: 2,
		color: "gray"
	},
	{
		a: "saintlouis",
		b: "nashville",
		len: 2,
		color: "gray"
	},
	{
		a: "saintlouis",
		b: "pittsburgh",
		len: 5,
		color: "green"
	},
	{
		a: "saintlouis",
		b: "chicago",
		len: 2,
		color: "green",
		double: 0
	},
	{
		a: "saintlouis",
		b: "chicago",
		len: 2,
		color: "white",
		double: 1
	},
	{
		a: "chicago",
		b: "pittsburgh",
		len: 3,
		color: "black",
		double: 0
	},
	{
		a: "chicago",
		b: "pittsburgh",
		len: 3,
		color: "orange",
		double: 1
	},
	{
		a: "chicago",
		b: "toronto",
		len: 4,
		color: "white"
	},
	{
		a: "saultstmarie",
		b: "montreal",
		len: 5,
		color: "black"
	},
	{
		a: "toronto",
		b: "montreal",
		len: 3,
		color: "gray"
	},
	{
		a: "saultstmarie",
		b: "toronto",
		len: 2,
		color: "gray"
	},
	{
		a: "toronto",
		b: "pittsburgh",
		len: 2,
		color: "gray"
	},
	{
		a: "pittsburgh",
		b: "newyork",
		len: 2,
		color: "white",
		double: 0
	},
	{
		a: "pittsburgh",
		b: "newyork",
		len: 2,
		color: "green",
		double: 1
	},
	{
		a: "pittsburgh",
		b: "washington",
		len: 2,
		color: "gray"
	},
	{
		a: "pittsburgh",
		b: "raleigh",
		len: 2,
		color: "gray"
	},
	{
		a: "nashville",
		b: "raleigh",
		len: 3,
		color: "black"
	},
	{
		a: "nashville",
		b: "atlanta",
		len: 1,
		color: "gray"
	},
	{
		a: "nashville",
		b: "pittsburgh",
		len: 4,
		color: "yellow"
	},
	{
		a: "atlanta",
		b: "miami",
		len: 5,
		color: "blue"
	},
	{
		a: "atlanta",
		b: "charleston",
		len: 2,
		color: "gray"
	},
	{
		a: "atlanta",
		b: "raleigh",
		len: 2,
		color: "gray",
		double: 0
	},
	{
		a: "atlanta",
		b: "raleigh",
		len: 2,
		color: "gray",
		double: 1
	},
	{
		a: "charleston",
		b: "miami",
		len: 4,
		color: "purple"
	},
	{
		a: "raleigh",
		b: "charleston",
		len: 2,
		color: "gray"
	},
	{
		a: "raleigh",
		b: "washington",
		len: 2,
		color: "gray",
		double: 0
	},
	{
		a: "raleigh",
		b: "washington",
		len: 2,
		color: "gray",
		double: 1
	},
	{
		a: "washington",
		b: "newyork",
		len: 2,
		color: "orange",
		double: 0
	},
	{
		a: "washington",
		b: "newyork",
		len: 2,
		color: "black",
		double: 1
	},
	{
		a: "newyork",
		b: "boston",
		len: 2,
		color: "yellow",
		double: 0
	},
	{
		a: "newyork",
		b: "boston",
		len: 2,
		color: "red",
		double: 1
	},
	{
		a: "newyork",
		b: "montreal",
		len: 3,
		color: "blue"
	},
	{
		a: "boston",
		b: "montreal",
		len: 2,
		color: "gray",
		double: 0
	},
	{
		a: "boston",
		b: "montreal",
		len: 2,
		color: "gray",
		double: 1
	}
], M = [
	{
		a: "losangeles",
		b: "newyork",
		points: 21
	},
	{
		a: "duluth",
		b: "houston",
		points: 8
	},
	{
		a: "saultstmarie",
		b: "nashville",
		points: 8
	},
	{
		a: "newyork",
		b: "atlanta",
		points: 6
	},
	{
		a: "portland",
		b: "nashville",
		points: 17
	},
	{
		a: "vancouver",
		b: "montreal",
		points: 20
	},
	{
		a: "duluth",
		b: "elpaso",
		points: 10
	},
	{
		a: "toronto",
		b: "miami",
		points: 10
	},
	{
		a: "portland",
		b: "phoenix",
		points: 11
	},
	{
		a: "dallas",
		b: "newyork",
		points: 11
	},
	{
		a: "calgary",
		b: "saltlakecity",
		points: 7
	},
	{
		a: "calgary",
		b: "phoenix",
		points: 13
	},
	{
		a: "losangeles",
		b: "miami",
		points: 20
	},
	{
		a: "winnipeg",
		b: "littlerock",
		points: 11
	},
	{
		a: "sanfrancisco",
		b: "atlanta",
		points: 17
	},
	{
		a: "kansascity",
		b: "houston",
		points: 5
	},
	{
		a: "losangeles",
		b: "chicago",
		points: 16
	},
	{
		a: "denver",
		b: "pittsburgh",
		points: 11
	},
	{
		a: "chicago",
		b: "santafe",
		points: 9
	},
	{
		a: "vancouver",
		b: "santafe",
		points: 13
	},
	{
		a: "boston",
		b: "miami",
		points: 12
	},
	{
		a: "chicago",
		b: "neworleans",
		points: 7
	},
	{
		a: "montreal",
		b: "atlanta",
		points: 9
	},
	{
		a: "seattle",
		b: "newyork",
		points: 22
	},
	{
		a: "denver",
		b: "elpaso",
		points: 4
	},
	{
		a: "helena",
		b: "losangeles",
		points: 8
	},
	{
		a: "winnipeg",
		b: "houston",
		points: 12
	},
	{
		a: "montreal",
		b: "neworleans",
		points: 13
	},
	{
		a: "saultstmarie",
		b: "oklahomacity",
		points: 9
	},
	{
		a: "seattle",
		b: "losangeles",
		points: 9
	}
], N = {
	1: 1,
	2: 2,
	3: 4,
	4: 7,
	5: 10,
	6: 15
}, P = {
	purple: "games.ttr.color.purple",
	blue: "games.ttr.color.blue",
	orange: "games.ttr.color.orange",
	white: "games.ttr.color.white",
	green: "games.ttr.color.green",
	yellow: "games.ttr.color.yellow",
	black: "games.ttr.color.black",
	red: "games.ttr.color.red",
	loco: "games.ttr.color.loco",
	gray: "games.ttr.color.gray"
}, F = {
	atlanta: "games.ttr.city.atlanta",
	boston: "games.ttr.city.boston",
	calgary: "games.ttr.city.calgary",
	charleston: "games.ttr.city.charleston",
	chicago: "games.ttr.city.chicago",
	dallas: "games.ttr.city.dallas",
	denver: "games.ttr.city.denver",
	duluth: "games.ttr.city.duluth",
	elpaso: "games.ttr.city.elpaso",
	helena: "games.ttr.city.helena",
	houston: "games.ttr.city.houston",
	kansascity: "games.ttr.city.kansascity",
	lasvegas: "games.ttr.city.lasvegas",
	littlerock: "games.ttr.city.littlerock",
	losangeles: "games.ttr.city.losangeles",
	miami: "games.ttr.city.miami",
	montreal: "games.ttr.city.montreal",
	nashville: "games.ttr.city.nashville",
	neworleans: "games.ttr.city.neworleans",
	newyork: "games.ttr.city.newyork",
	oklahomacity: "games.ttr.city.oklahomacity",
	omaha: "games.ttr.city.omaha",
	phoenix: "games.ttr.city.phoenix",
	pittsburgh: "games.ttr.city.pittsburgh",
	portland: "games.ttr.city.portland",
	raleigh: "games.ttr.city.raleigh",
	saintlouis: "games.ttr.city.saintlouis",
	saltlakecity: "games.ttr.city.saltlakecity",
	sanfrancisco: "games.ttr.city.sanfrancisco",
	santafe: "games.ttr.city.santafe",
	saultstmarie: "games.ttr.city.saultstemarie",
	seattle: "games.ttr.city.seattle",
	toronto: "games.ttr.city.toronto",
	vancouver: "games.ttr.city.vancouver",
	washington: "games.ttr.city.washington",
	winnipeg: "games.ttr.city.winnipeg"
}, I = {
	id: "ttr",
	tier: "beta",
	mechanics: ["route-building", "set-collection"],
	interactionTags: [],
	nameKey: "games.ttr.name",
	descKey: "games.ttr.desc",
	rulesKey: "games.ttr.rules",
	icon: "🚂",
	iconImg: "games/ttr.webp",
	rulesUrl: { en: "https://ncdn0.daysofwonder.com/tickettoride/en/img/tt_rules_2015_en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#398fa3",
	releasedAt: "2026-09-17",
	search: {
		py: "che piao zhi lv",
		init: "cpzl"
	},
	hotseat: "cover"
}, L = t.enum(k), R = t.int().min(0).max(99), z = t.int().min(0).max(29), B = t.string(), V = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("keepInitialTickets"),
		keep: t.array(z).min(2).max(3)
	}),
	t.object({
		type: t.literal("drawCard"),
		source: t.union([t.literal("deck"), t.object({ faceUp: t.int().min(0).max(4) })])
	}),
	t.object({
		type: t.literal("claim"),
		route: R,
		color: L,
		locos: t.int().min(0)
	}),
	t.object({ type: t.literal("drawTickets") }),
	t.object({
		type: t.literal("keepTickets"),
		keep: t.array(z).min(1).max(3)
	})
]), H = t.enum([...k, "loco"]), U = t.object({
	phase: t.enum([
		"keepInitial",
		"play",
		"done"
	]),
	faceUp: t.array(H),
	deckCount: t.int().nonnegative(),
	ticketDeckCount: t.int().nonnegative(),
	claims: t.record(t.string(), t.int()),
	players: t.array(t.object({
		rid: B,
		trainsLeft: t.int().nonnegative(),
		cardCount: t.int().nonnegative(),
		ticketCount: t.int().nonnegative(),
		score: t.int(),
		ready: t.boolean()
	})),
	turn: t.int().nullable(),
	drawsLeft: t.int().min(0).max(2),
	pickingTickets: t.boolean(),
	lastRoundFor: t.int().nullable()
}), W = t.object({
	id: z,
	a: t.string(),
	b: t.string(),
	points: t.int(),
	done: t.boolean()
}), te = t.object({
	hand: t.partialRecord(H, t.int().min(1)),
	myTickets: t.array(W),
	pendingPick: t.array(W.omit({ done: !0 })).nullable()
});
//#endregion
//#region src/games/ttr/rules.ts
function G(t, n) {
	let r = t.rngCursor;
	for (let i = n.length - 1; i > 0; --i) {
		let a = e(t.seed, r, i + 1);
		r += 1, [n[i], n[a]] = [n[a], n[i]];
	}
	return t.rngCursor = r, n;
}
var K = (() => {
	let e = /* @__PURE__ */ new Map();
	return j.forEach((t, n) => {
		let r = [t.a, t.b].sort().join("|"), i = e.get(r) ?? [];
		i.push(n), e.set(r, i);
	}), e;
})(), q = (e, t) => [e, t].sort().join("|");
function J() {
	let e = [];
	for (let t of k) for (let n = 0; n < 12; n += 1) e.push(t);
	for (let t = 0; t < 14; t += 1) e.push("loco");
	return e;
}
function ne(e) {
	return e.deck.length === 0 && e.discard.length > 0 && (e.deck = G(e, e.discard), e.discard = []), e.deck.pop() ?? null;
}
var re = 10;
function Y(e) {
	let t = 0;
	for (;;) {
		for (; e.faceUp.length < 5;) {
			let t = ne(e);
			if (t === null) break;
			e.faceUp.push(t);
		}
		if (e.faceUp.length < 5 || e.faceUp.filter((e) => e === "loco").length < 3 || t >= re) return;
		e.discard.push(...e.faceUp), e.faceUp = [], t += 1;
	}
}
function X(t, n, r) {
	let i = {
		players: n,
		phase: "keepInitial",
		deck: [],
		discard: [],
		faceUp: [],
		ticketDeck: [],
		hands: {},
		tickets: {},
		claims: {},
		trainsLeft: {},
		score: {},
		initialDeal: {},
		pendingTickets: null,
		turn: 0,
		drawsLeft: 2,
		lastRoundFor: null,
		starter: 0,
		seed: r,
		rngCursor: 0
	};
	i.deck = G(i, J()), i.ticketDeck = G(i, M.map((e, t) => t));
	for (let e of n) {
		i.hands[e] = [];
		for (let t = 0; t < 4; t += 1) i.hands[e].push(i.deck.pop());
		i.tickets[e] = [], i.trainsLeft[e] = 45, i.score[e] = 0, i.initialDeal[e] = [];
		for (let t = 0; t < 3; t += 1) i.initialDeal[e].push(i.ticketDeck.pop());
	}
	return Y(i), i.starter = e(i.seed, i.rngCursor, n.length), i.rngCursor += 1, {
		state: i,
		fx: [{ kind: "gameStart" }]
	};
}
var Z = (e) => ({ code: e });
function ie(e, t) {
	return e.players.indexOf(t);
}
function ae(e, t, n) {
	let r = j[t];
	if (r.double === void 0) return null;
	let i = K.get(q(r.a, r.b))?.find((e) => e !== t);
	if (i === void 0) return null;
	let a = e.claims[i];
	return a === void 0 ? null : a === n ? "samePlayer" : e.players.length <= 3 ? "closed" : null;
}
function oe(e, t, n, r) {
	if (n === r) return !0;
	let i = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e.claims)) {
		if (r !== t) continue;
		let e = j[Number(n)];
		(i.get(e.a) ?? i.set(e.a, []).get(e.a)).push(e.b), (i.get(e.b) ?? i.set(e.b, []).get(e.b)).push(e.a);
	}
	let a = /* @__PURE__ */ new Set([n]), o = [n];
	for (; o.length > 0;) {
		let e = o.pop();
		for (let t of i.get(e) ?? []) {
			if (t === r) return !0;
			a.has(t) || (a.add(t), o.push(t));
		}
	}
	return !1;
}
function se(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let [r, i] of Object.entries(e.claims)) {
		if (i !== t) continue;
		let e = Number(r), a = j[e];
		(n.get(a.a) ?? n.set(a.a, []).get(a.a)).push({
			to: a.b,
			len: a.len,
			id: e
		}), (n.get(a.b) ?? n.set(a.b, []).get(a.b)).push({
			to: a.a,
			len: a.len,
			id: e
		});
	}
	let r = 0;
	function i(e, t, a) {
		r = Math.max(r, a);
		for (let r of n.get(e) ?? []) t.has(r.id) || (t.add(r.id), i(r.to, t, a + r.len), t.delete(r.id));
	}
	for (let e of n.keys()) i(e, /* @__PURE__ */ new Set(), 0);
	return r;
}
function ce(e) {
	let t = e.players.map((t, n) => se(e, n)), n = Math.max(...t);
	return e.players.map((r, i) => {
		let a = i, o = 0, s = 0;
		for (let t of e.tickets[r]) {
			let n = M[t];
			oe(e, a, n.a, n.b) ? (o += n.points, s += 1) : o -= n.points;
		}
		let c = n > 0 && t[i] === n;
		return {
			rid: r,
			routePoints: e.score[r],
			ticketPoints: o,
			ticketsDone: s,
			longest: t[i],
			hasLongestBonus: c,
			total: e.score[r] + o + (c ? 10 : 0)
		};
	});
}
function le(e) {
	let t = e.turn;
	return e.lastRoundFor !== null && t === e.lastRoundFor ? (e.phase = "done", [{ kind: "gameEnd" }]) : (e.lastRoundFor === null && (e.trainsLeft[e.players[t]] ?? 0) <= 2 && (e.lastRoundFor = t), e.turn = (e.turn + 1) % e.players.length, e.drawsLeft = 2, []);
}
function ue(e, t, n) {
	let r = structuredClone(e), i = n.by, a = ie(r, i);
	if (a < 0) return Z("games.ttr.errNotYourTurn");
	switch (t.type) {
		case "keepInitialTickets": {
			if (r.phase !== "keepInitial") return Z("games.ttr.errNotInPhase");
			let e = r.initialDeal[i];
			if (e.length === 0) return Z("games.ttr.errNotInPhase");
			let n = new Set(t.keep);
			return n.size !== t.keep.length || t.keep.some((t) => !e.includes(t)) ? Z("games.ttr.errBadPick") : (r.tickets[i] = e.filter((e) => n.has(e)), r.ticketDeck.unshift(...e.filter((e) => !n.has(e))), r.initialDeal[i] = [], r.players.every((e) => r.initialDeal[e].length === 0 && r.tickets[e].length > 0) && (r.phase = "play", r.turn = r.starter, r.drawsLeft = 2), {
				state: r,
				fx: [{
					kind: "keepTickets",
					rid: i,
					data: { count: t.keep.length }
				}]
			});
		}
		case "drawCard": {
			if (r.phase !== "play" || r.turn !== a || r.pendingTickets !== null || r.drawsLeft === 0) return Z("games.ttr.errNotYourTurn");
			let e;
			if (t.source === "deck") {
				let t = ne(r);
				if (t === null) return Z("games.ttr.errDeckEmpty");
				e = t;
			} else {
				let n = t.source.faceUp;
				if (n >= r.faceUp.length) return Z("games.ttr.errBadPick");
				if (e = r.faceUp[n], e === "loco" && r.drawsLeft !== 2) return Z("games.ttr.errLocoFirst");
				r.faceUp.splice(n, 1), Y(r);
			}
			r.hands[i].push(e), r.drawsLeft = e === "loco" && t.source !== "deck" ? 0 : r.drawsLeft - 1;
			let n = [{
				kind: "draw",
				rid: i,
				data: t.source === "deck" ? { from: "deck" } : {
					from: "faceUp",
					idx: t.source.faceUp
				}
			}];
			return r.drawsLeft > 0 ? {
				state: r,
				fx: n
			} : {
				state: r,
				fx: [...n, ...le(r)]
			};
		}
		case "claim": {
			if (r.phase !== "play" || r.turn !== a || r.pendingTickets !== null || r.drawsLeft !== 2) return Z("games.ttr.errNotYourTurn");
			let e = j[t.route];
			if (r.claims[t.route] !== void 0) return Z("games.ttr.errRouteTaken");
			let n = ae(r, t.route, a);
			if (n === "samePlayer") return Z("games.ttr.errDoubleSame");
			if (n === "closed") return Z("games.ttr.errDoubleClosed");
			if (e.color !== "gray" && t.color !== e.color) return Z("games.ttr.errBadColor");
			if (t.locos > e.len) return Z("games.ttr.errCantPay");
			let o = e.len - t.locos, s = r.hands[i], c = s.filter((e) => e === t.color).length, l = s.filter((e) => e === "loco").length;
			if (c < o || l < t.locos) return Z("games.ttr.errCantPay");
			if (r.trainsLeft[i] < e.len) return Z("games.ttr.errNoTrains");
			let u = o;
			r.hands[i] = s.filter((e) => e === t.color && u > 0 ? (--u, r.discard.push(e), !1) : !0);
			let d = t.locos;
			return r.hands[i] = r.hands[i].filter((e) => e === "loco" && d > 0 ? (--d, r.discard.push(e), !1) : !0), r.claims[t.route] = a, r.trainsLeft[i] -= e.len, r.score[i] += N[e.len], {
				state: r,
				fx: [{
					kind: "claim",
					rid: i,
					data: {
						route: t.route,
						points: N[e.len]
					}
				}, ...le(r)]
			};
		}
		case "drawTickets":
			if (r.phase !== "play" || r.turn !== a || r.pendingTickets !== null || r.drawsLeft !== 2) return Z("games.ttr.errNotYourTurn");
			if (r.ticketDeck.length === 0) return Z("games.ttr.errDeckEmpty");
			r.pendingTickets = [];
			for (let e = 0; e < 3 && r.ticketDeck.length > 0; e += 1) r.pendingTickets.push(r.ticketDeck.pop());
			return {
				state: r,
				fx: [{
					kind: "drawTickets",
					rid: i
				}]
			};
		case "keepTickets": {
			if (r.phase !== "play" || r.pendingTickets === null || r.turn !== a) return Z("games.ttr.errNotYourTurn");
			let e = new Set(t.keep);
			if (e.size !== t.keep.length || t.keep.some((e) => !r.pendingTickets.includes(e))) return Z("games.ttr.errBadPick");
			let n = r.pendingTickets;
			return r.tickets[i].push(...n.filter((t) => e.has(t))), r.ticketDeck.unshift(...n.filter((t) => !e.has(t))), r.pendingTickets = null, {
				state: r,
				fx: [{
					kind: "keepTickets",
					rid: i,
					data: { count: t.keep.length }
				}, ...le(r)]
			};
		}
	}
}
function de(e, t, n) {
	let r = M[n];
	return {
		id: n,
		a: r.a,
		b: r.b,
		points: r.points,
		done: oe(e, t, r.a, r.b)
	};
}
function fe(e, t) {
	let n = ie(e, t), r = {
		phase: e.phase,
		faceUp: [...e.faceUp],
		deckCount: e.deck.length,
		ticketDeckCount: e.ticketDeck.length,
		claims: Object.fromEntries(Object.entries(e.claims).map(([e, t]) => [e, t])),
		players: e.players.map((t) => ({
			rid: t,
			trainsLeft: e.trainsLeft[t],
			cardCount: e.hands[t].length,
			ticketCount: e.tickets[t].length + e.initialDeal[t].length,
			score: e.score[t],
			ready: e.phase !== "keepInitial" || e.initialDeal[t].length === 0
		})),
		turn: e.phase === "play" ? e.turn : null,
		drawsLeft: e.drawsLeft,
		pickingTickets: e.pendingTickets !== null,
		lastRoundFor: e.lastRoundFor
	};
	if (n < 0) return { public: r };
	let i = e.phase === "keepInitial" && e.initialDeal[t].length > 0 ? e.initialDeal[t] : e.pendingTickets !== null && e.turn === n ? e.pendingTickets : null, a = {};
	for (let n of e.hands[t]) a[n] = (a[n] ?? 0) + 1;
	return {
		public: r,
		private: {
			hand: a,
			myTickets: e.tickets[t].map((t) => de(e, n, t)),
			pendingPick: i ? i.map((e) => ({
				id: e,
				a: M[e].a,
				b: M[e].b,
				points: M[e].points
			})) : null
		}
	};
}
function pe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = ce(e), n = [...t].sort((e, t) => t.total - e.total || t.ticketsDone - e.ticketsDone || t.longest - e.longest), r = n[0];
	return {
		phase: "done",
		winner: n.filter((e) => e.total === r.total && e.ticketsDone === r.ticketsDone && e.longest === r.longest).map((e) => e.rid),
		ranking: n.map((e) => e.rid),
		scores: Object.fromEntries(t.map((e) => [e.rid, e.total]))
	};
}
var me = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: I,
	schemas: {
		action: V,
		publicView: U,
		privateView: te
	},
	setup: X,
	reduce: ue,
	viewFor: fe,
	status: pe
}, he = "M-420 -3000H2960L1770 -700L1440 -320L1160 112L1100 198L1080 271L1050 312L1077 377L1065 449L1028 500L1048 560L1020 600L1053 681L1036 737L1058 786L1075 871L1053 936Q1035 958 1017 925L978 828L934 788L884 818L834 845L795 877L740 884L691 907L640 889L590 895L544 914L485 902L426 901L382 873L325 857L278 832L230 823L190 799L150 807L117 777L105 738L91 694L64 662L48 617L37 565L42 527L60 489L66 451L57 415L72 363L56 320L65 270L83 235L78 195L89 164L73 119L55 80L45 36L-50 -120L-160 -350L-330 -720Z";
function ge({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ w("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ C("ellipse", {
				cx: 0,
				cy: 12,
				rx: 30,
				ry: 10,
				fill: "#577b62",
				opacity: .13
			}),
			/* @__PURE__ */ C("path", {
				d: "M-27 9L-4 -36L29 11Z",
				fill: "#a8b998"
			}),
			/* @__PURE__ */ C("path", {
				d: "M-4 -36L3 8L29 11Z",
				fill: "#8ba898"
			}),
			/* @__PURE__ */ C("path", {
				d: "M-4 -36L-14 -17L-5 -20L0 -13L5 -23Z",
				fill: "#f6f5dc"
			})
		]
	});
}
function _e({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ w("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ C("ellipse", {
				cy: 5,
				rx: 6,
				ry: 2.5,
				fill: "#548b70",
				opacity: .13
			}),
			/* @__PURE__ */ C("path", {
				d: "M0 -14L-6 0H-3L-8 6H8L3 0H6Z",
				fill: "#8bb38c"
			}),
			/* @__PURE__ */ C("path", {
				d: "M0 -14V6H8L3 0H6Z",
				fill: "#709e81"
			}),
			/* @__PURE__ */ C("path", {
				d: "M0 6V10",
				stroke: "#829674",
				strokeWidth: 2
			})
		]
	});
}
function ve({ bounds: e }) {
	let t = i();
	return /* @__PURE__ */ w("g", {
		pointerEvents: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ w("defs", { children: [/* @__PURE__ */ w("linearGradient", {
				id: `${t}-land`,
				x1: 0,
				y1: 0,
				x2: .8,
				y2: 1,
				children: [
					/* @__PURE__ */ C("stop", { stopColor: "#eff1cf" }),
					/* @__PURE__ */ C("stop", {
						offset: .48,
						stopColor: "#dfeabb"
					}),
					/* @__PURE__ */ C("stop", {
						offset: 1,
						stopColor: "#c9e0ad"
					})
				]
			}), /* @__PURE__ */ C("pattern", {
				id: `${t}-waves`,
				width: 80,
				height: 64,
				patternUnits: "userSpaceOnUse",
				children: /* @__PURE__ */ C("path", {
					d: "M6 20Q13 14 20 20T34 20M44 46Q51 40 58 46T72 46",
					fill: "none",
					stroke: "#fff",
					opacity: .23,
					strokeWidth: 1.5
				})
			})] }),
			/* @__PURE__ */ C("rect", {
				x: e.x,
				y: e.y,
				width: e.w,
				height: e.h,
				fill: "#a1dce5"
			}),
			/* @__PURE__ */ C("rect", {
				x: e.x,
				y: e.y,
				width: e.w,
				height: e.h,
				fill: `url(#${t}-waves)`
			}),
			/* @__PURE__ */ C("path", {
				d: he,
				fill: "#468d8c",
				transform: "translate(0 11)",
				opacity: .28
			}),
			/* @__PURE__ */ C("path", {
				d: he,
				fill: `url(#${t}-land)`,
				stroke: "#f1f0c8",
				strokeWidth: 7
			}),
			/* @__PURE__ */ C("path", {
				d: "M112 0Q210 130 295 360T385 690Q430 780 500 900L410 902Q320 802 281 702T165 430Q110 260 58 150Z",
				fill: "#cfdbac",
				opacity: .7
			}),
			/* @__PURE__ */ C("path", {
				d: "M150 335Q270 398 289 558T432 783L352 860Q293 687 202 581T86 423Z",
				fill: "#f0dfb7",
				opacity: .68
			}),
			/* @__PURE__ */ C("path", {
				d: "M713 525Q861 439 925 477T980 704L898 747L818 637Z",
				fill: "#ccdda9",
				opacity: .6
			}),
			Array.from({ length: 19 }, (e, t) => /* @__PURE__ */ C(ge, {
				x: 177 + t * 8 + Math.sin(t * 2) * 32,
				y: 100 + t * 37,
				scale: .8 + t % 4 * .13
			}, `m${t}`)),
			Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ C(ge, {
				x: 102 + t * 10,
				y: 450 + t * 24,
				scale: .65 + t % 3 * .13
			}, `w${t}`)),
			Array.from({ length: 10 }, (e, t) => /* @__PURE__ */ C(ge, {
				x: 864 + t * 7,
				y: 458 + t * 17,
				scale: .47
			}, `e${t}`)),
			Array.from({ length: 42 }, (e, t) => {
				let n = 92 + t * 67 % 430, r = 28 + t * 109 % 740;
				return n < 175 || r < 180 ? /* @__PURE__ */ C(_e, {
					x: n,
					y: r,
					scale: .7 + t % 3 * .15
				}, `w${t}`) : null;
			}),
			Array.from({ length: 30 }, (e, t) => /* @__PURE__ */ C(_e, {
				x: 704 + t * 73 % 259,
				y: 316 + t * 37 % 400,
				scale: .6 + t % 4 * .09
			}, `e${t}`)),
			/* @__PURE__ */ w("g", {
				fill: "#92cbd3",
				stroke: "#edf3d4",
				strokeWidth: 3,
				children: [
					/* @__PURE__ */ C("path", { d: "M690 128Q728 110 750 125L790 160L770 184L752 172L726 183L701 160L672 165Z" }),
					/* @__PURE__ */ C("path", { d: "M790 200Q802 174 817 186L825 236L814 278L797 295L792 269Z" }),
					/* @__PURE__ */ C("path", { d: "M842 156L865 149L873 168L867 192L889 211L871 228L851 207L846 181Z" }),
					/* @__PURE__ */ C("path", { d: "M878 264L905 249L936 245L927 257L909 268Z" }),
					/* @__PURE__ */ C("path", { d: "M947 213L970 201L986 207L972 216Z" })
				]
			}),
			/* @__PURE__ */ C("path", {
				d: "M679 315Q652 393 687 436T694 545Q665 590 718 653T741 747L761 848",
				fill: "none",
				stroke: "#a4d0ba",
				strokeWidth: 3.5,
				opacity: .8
			}),
			/* @__PURE__ */ C("path", {
				d: "M443 548Q495 562 515 604T612 649L683 666",
				fill: "none",
				stroke: "#b8d2b1",
				strokeWidth: 2
			}),
			/* @__PURE__ */ w("g", {
				transform: "translate(67 865)",
				opacity: .45,
				children: [
					/* @__PURE__ */ C("circle", {
						r: 28,
						fill: "none",
						stroke: "#518d95"
					}),
					/* @__PURE__ */ C("path", {
						d: "M0 -40L7 -7L40 0L7 7L0 40L-7 7L-40 0L-7 -7Z",
						fill: "#518d95",
						opacity: .6
					}),
					/* @__PURE__ */ C("path", {
						d: "M0 -26L5 0L0 26L-5 0Z",
						fill: "#fff"
					})
				]
			})
		]
	});
}
function ye({ width: e, color: t, occupied: n }) {
	let r = Math.max(8, e);
	return n ? /* @__PURE__ */ w(S, { children: [
		/* @__PURE__ */ C("rect", {
			x: -r / 2 + 1,
			y: -5,
			width: r,
			height: 17,
			fill: "#274a50",
			rx: 3,
			opacity: .24
		}),
		/* @__PURE__ */ C("rect", {
			x: -r / 2,
			y: -7,
			width: r,
			height: 14,
			fill: "#294b59",
			rx: 3
		}),
		/* @__PURE__ */ C("rect", {
			x: -r / 2,
			y: -10,
			width: r,
			height: 14,
			fill: t,
			rx: 3,
			stroke: "#f6f7dd",
			strokeWidth: .8
		}),
		/* @__PURE__ */ C("rect", {
			x: -r / 2 + 2,
			y: -9,
			width: Math.max(1, r - 4),
			height: 4,
			fill: "#fff",
			rx: 2,
			opacity: .32
		}),
		/* @__PURE__ */ C("path", {
			d: `M${-r / 2 + 4} -4H${r / 2 - 4}`,
			stroke: "#fff3d4",
			strokeWidth: 1.6,
			opacity: .7
		}),
		/* @__PURE__ */ C("path", {
			d: `M${-r / 2 + 3} -8V1M${r / 2 - 3} -8V1`,
			stroke: "#fff",
			opacity: .45
		}),
		[-1, 1].map((e) => /* @__PURE__ */ C("circle", {
			cx: e * r * .27,
			cy: 6,
			r: 2.6,
			fill: "#243e48"
		}, e)),
		/* @__PURE__ */ C("path", {
			d: `M${-r * .27} 6H${r * .27}`,
			stroke: "#b3c0b8"
		})
	] }) : /* @__PURE__ */ w(S, { children: [
		/* @__PURE__ */ C("rect", {
			x: -r / 2,
			y: -6,
			width: r,
			height: 12,
			fill: t,
			rx: 2,
			opacity: .4
		}),
		/* @__PURE__ */ C("rect", {
			x: -r / 2 + 1,
			y: -4,
			width: Math.max(1, r - 2),
			height: 8,
			fill: "#fcf5d8",
			opacity: .62
		}),
		Array.from({ length: Math.max(1, Math.floor(r / 7)) }, (e, t) => /* @__PURE__ */ C("path", {
			d: `M${-r / 2 + 3 + t * 7} -5.1V5.1`,
			stroke: "#7c8373",
			strokeWidth: 1.7,
			opacity: .74
		}, t)),
		/* @__PURE__ */ C("path", {
			d: `M${-r / 2} -3H${r / 2}M${-r / 2} 3H${r / 2}`,
			stroke: "#52686b",
			strokeWidth: 1.35
		}),
		/* @__PURE__ */ C("path", {
			d: `M${-r / 2} -3.9H${r / 2}`,
			stroke: "#fff",
			strokeWidth: .65,
			opacity: .82
		}),
		/* @__PURE__ */ C("rect", {
			x: -r / 2,
			y: -6,
			width: r,
			height: 2.1,
			fill: t,
			rx: 1
		}),
		/* @__PURE__ */ C("rect", {
			x: -r / 2,
			y: 3.9,
			width: r,
			height: 2.1,
			fill: t,
			rx: 1
		})
	] });
}
//#endregion
//#region src/games/ttr/card-art.tsx
var be = {
	purple: "#965aca",
	blue: "#298bd3",
	orange: "#ec9440",
	white: "#fcf8e7",
	green: "#3d9d71",
	yellow: "#f2c83f",
	black: "#455965",
	red: "#df6254",
	gray: "#afb6a3",
	loco: "#23586a"
}, xe = {
	purple: "✿",
	blue: "●",
	orange: "▲",
	white: "◇",
	green: "♣",
	yellow: "✦",
	black: "▰",
	red: "◆",
	loco: "★"
};
function Se() {
	return /* @__PURE__ */ w(S, { children: [/* @__PURE__ */ C("path", {
		d: "M6 61H114",
		stroke: "#29434b",
		strokeWidth: 5
	}), [29, 90].map((e) => /* @__PURE__ */ w("g", { children: [/* @__PURE__ */ C("circle", {
		cx: e,
		cy: 65,
		r: 8,
		fill: "#2f4650"
	}), /* @__PURE__ */ C("circle", {
		cx: e,
		cy: 65,
		r: 4,
		fill: "#bcc2b8"
	})] }, e))] });
}
function Ce({ card: e }) {
	return /* @__PURE__ */ w("g", {
		fill: e === "white" || e === "yellow" ? "#c4a74f" : "#f6d392",
		children: [
			/* @__PURE__ */ C("ellipse", {
				cx: 60,
				cy: 72,
				rx: 55,
				ry: 5,
				fill: "#173e4a",
				opacity: .15
			}),
			e === "loco" ? /* @__PURE__ */ w(S, { children: [
				/* @__PURE__ */ C("path", {
					d: "M8 54H99L110 64H5Z",
					fill: "#253f4a"
				}),
				/* @__PURE__ */ C("path", { d: "M14 36H69V55H14Z" }),
				/* @__PURE__ */ C("path", {
					d: "M16 32H68L74 38H12Z",
					fill: "#fff",
					opacity: .5
				}),
				/* @__PURE__ */ C("rect", {
					x: 74,
					y: 15,
					width: 28,
					height: 41,
					rx: 3
				}),
				/* @__PURE__ */ C("path", {
					d: "M70 13H105V19H70ZM24 29V14H35V29Z",
					fill: "#314d54"
				}),
				/* @__PURE__ */ C("rect", {
					x: 81,
					y: 23,
					width: 14,
					height: 14,
					rx: 2,
					fill: "#fff1bf"
				}),
				/* @__PURE__ */ C("path", {
					d: "M11 43H67",
					stroke: "#ffdb85",
					strokeWidth: 3
				}),
				/* @__PURE__ */ C("circle", {
					cx: 11,
					cy: 41,
					r: 6,
					fill: "#ffe5a1"
				}),
				/* @__PURE__ */ C("path", {
					d: "M29 9Q19 -2 35 -4Q51 -5 47 -15",
					fill: "none",
					stroke: "#fff",
					opacity: .5,
					strokeWidth: 7,
					strokeLinecap: "round"
				})
			] }) : e === "blue" || e === "purple" ? /* @__PURE__ */ w(S, { children: [
				/* @__PURE__ */ C("rect", {
					x: 9,
					y: 25,
					width: 102,
					height: 36,
					rx: 8
				}),
				/* @__PURE__ */ C("path", {
					d: "M9 30Q9 16 24 16H96Q111 16 111 30Z",
					fill: "#fff",
					opacity: .5
				}),
				/* @__PURE__ */ C("path", {
					d: "M15 49H105",
					stroke: "#f4e2b7",
					strokeWidth: 4
				}),
				[
					18,
					37,
					56,
					75
				].map((e) => /* @__PURE__ */ C("rect", {
					x: e,
					y: 31,
					width: 12,
					height: 11,
					rx: 2,
					fill: "#224c5b"
				}, e)),
				/* @__PURE__ */ C("path", {
					d: "M95 29H104V59H95Z",
					fill: "#fff",
					opacity: .25
				})
			] }) : e === "yellow" || e === "black" ? /* @__PURE__ */ w(S, { children: [
				/* @__PURE__ */ C("rect", {
					x: 10,
					y: 25,
					width: 100,
					height: 32,
					rx: 16
				}),
				/* @__PURE__ */ C("path", {
					d: "M24 31H93",
					stroke: "#fff",
					opacity: .5,
					strokeWidth: 6,
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ C("rect", {
					x: 52,
					y: 18,
					width: 17,
					height: 9,
					rx: 2,
					fill: "#364f56"
				}),
				/* @__PURE__ */ C("path", {
					d: "M37 26V55M83 26V55",
					stroke: "#2b5057",
					strokeWidth: 3,
					opacity: .5
				})
			] }) : /* @__PURE__ */ w(S, { children: [
				/* @__PURE__ */ C("rect", {
					x: 10,
					y: 26,
					width: 99,
					height: 35,
					rx: 3
				}),
				/* @__PURE__ */ C("path", {
					d: "M10 26L18 17H103L109 26Z",
					fill: "#fff",
					opacity: .5
				}),
				/* @__PURE__ */ C("path", {
					d: "M15 26H105M20 31V57M30 31V57M40 31V57M78 31V57M88 31V57M98 31V57",
					stroke: "#264b52",
					opacity: .28,
					strokeWidth: 2
				}),
				/* @__PURE__ */ C("rect", {
					x: 47,
					y: 28,
					width: 24,
					height: 32,
					fill: "#fff",
					opacity: .22
				}),
				/* @__PURE__ */ C("path", {
					d: "M47 28H71V60H47Z",
					stroke: "#fff",
					opacity: .6,
					fill: "none"
				})
			] }),
			/* @__PURE__ */ C(Se, {})
		]
	});
}
function we({ card: e, back: t = !1 }) {
	let n = e === "white" || e === "yellow";
	return /* @__PURE__ */ w("svg", {
		className: "ttr-card-art",
		viewBox: "0 0 86 124",
		"aria-hidden": "true",
		focusable: "false",
		preserveAspectRatio: "none",
		children: [
			/* @__PURE__ */ C("rect", {
				x: 1,
				y: 1,
				width: 84,
				height: 122,
				rx: 5,
				fill: "#fff7dd",
				stroke: "#76847a"
			}),
			/* @__PURE__ */ C("rect", {
				x: 5,
				y: 5,
				width: 76,
				height: 114,
				rx: 3,
				fill: be[e]
			}),
			/* @__PURE__ */ C("path", {
				d: "M5 88Q43 64 81 88V119H5Z",
				fill: "#173e49",
				opacity: .19
			}),
			/* @__PURE__ */ C("path", {
				d: "M5 5H81V63L5 95Z",
				fill: "#fff",
				opacity: .07
			}),
			t && /* @__PURE__ */ w(S, { children: [/* @__PURE__ */ C("path", {
				d: "M9 12L77 112M9 112L77 12",
				stroke: "#eddfb8",
				opacity: .35
			}), /* @__PURE__ */ C("circle", {
				cx: 43,
				cy: 48,
				r: 28,
				fill: "none",
				stroke: "#eddfb8",
				opacity: .7
			})] }),
			!t && /* @__PURE__ */ C("text", {
				x: 11,
				y: 22,
				fontSize: 16,
				fontWeight: 800,
				fill: n ? "#665b3d" : "#fff8de",
				children: xe[e]
			}),
			/* @__PURE__ */ C("svg", {
				x: 4,
				y: 26,
				width: 78,
				height: 64,
				viewBox: "0 0 120 80",
				overflow: "visible",
				children: /* @__PURE__ */ C(Ce, { card: e })
			}),
			/* @__PURE__ */ C("path", {
				d: "M12 110H74M16 114H70",
				stroke: n ? "#827549" : "#fff0c6",
				opacity: .45
			})
		]
	});
}
function Te() {
	return /* @__PURE__ */ w("svg", {
		className: "ttr-card-art",
		viewBox: "0 0 86 124",
		"aria-hidden": "true",
		focusable: "false",
		preserveAspectRatio: "none",
		children: [
			/* @__PURE__ */ C("rect", {
				x: 1,
				y: 1,
				width: 84,
				height: 122,
				rx: 5,
				fill: "#fff1cc",
				stroke: "#b6a179"
			}),
			/* @__PURE__ */ C("rect", {
				x: 7,
				y: 7,
				width: 72,
				height: 110,
				rx: 3,
				fill: "none",
				stroke: "#ddc79a"
			}),
			/* @__PURE__ */ C("path", {
				d: "M17 37L31 19L55 23L69 42L57 61L30 63L18 51Z",
				fill: "#d8e2b6"
			}),
			/* @__PURE__ */ C("path", {
				d: "M23 49L38 31L60 42",
				fill: "none",
				stroke: "#80a28a",
				strokeWidth: 2
			}),
			/* @__PURE__ */ C("circle", {
				cx: 23,
				cy: 49,
				r: 4,
				fill: "#c48350"
			}),
			/* @__PURE__ */ C("circle", {
				cx: 60,
				cy: 42,
				r: 4,
				fill: "#c48350"
			}),
			/* @__PURE__ */ C("path", {
				d: "M12 76H74",
				stroke: "#c8b48b",
				strokeDasharray: "3 3"
			})
		]
	});
}
function Ee({ a: e, b: t, points: n, done: r }) {
	return /* @__PURE__ */ w("span", {
		className: `ttr-destination${r ? " ttr-destination-done" : ""}`,
		children: [/* @__PURE__ */ w("span", {
			className: "ttr-ticket-cities",
			children: [
				/* @__PURE__ */ C("span", { children: e }),
				/* @__PURE__ */ C("span", { children: t }),
				/* @__PURE__ */ C("span", {
					className: "ttr-ticket-line",
					"aria-hidden": "true"
				})
			]
		}), /* @__PURE__ */ w("span", {
			className: "ttr-ticket-points font-mono tabular-nums",
			children: [n, r && /* @__PURE__ */ C("span", {
				"aria-hidden": "true",
				children: "✓"
			})]
		})]
	});
}
//#endregion
//#region src/games/ttr/board-view.tsx
var De = 8, Oe = 16, ke = 18, Ae = 16;
function je() {
	let e = new Map(A.map((e) => [e.id, e]));
	return j.map((t) => {
		let n = e.get(t.a), r = e.get(t.b), i = [
			{
				x: n.x,
				y: n.y
			},
			...t.via ? [{
				x: t.via[0],
				y: t.via[1]
			}] : [],
			{
				x: r.x,
				y: r.y
			}
		];
		if (t.double !== void 0) {
			let e = i[1].x - i[0].x, n = i[1].y - i[0].y, r = Math.hypot(e, n) || 1, a = t.double === 0 ? ke / 2 : -9, o = -n / r * a, s = e / r * a;
			i = i.map((e) => ({
				x: e.x + o,
				y: e.y + s
			}));
		}
		let a = i.slice(0, -1).map((e, t) => Math.hypot(i[t + 1].x - e.x, i[t + 1].y - e.y)), o = a.reduce((e, t) => e + t, 0), s = (e) => {
			let t = e;
			for (let e = 0; e < a.length; e += 1) {
				if (t <= a[e] || e === a.length - 1) {
					let n = Math.min(1, t / a[e]);
					return {
						x: i[e].x + (i[e + 1].x - i[e].x) * n,
						y: i[e].y + (i[e + 1].y - i[e].y) * n,
						angle: Math.atan2(i[e + 1].y - i[e].y, i[e + 1].x - i[e].x) * 180 / Math.PI
					};
				}
				t -= a[e];
			}
			return {
				...i[i.length - 1],
				angle: 0
			};
		}, c = o - 32, l = [];
		for (let e = 0; e < t.len; e += 1) {
			let n = Oe + c * e / t.len, r = Oe + c * (e + 1) / t.len, i = s((n + r) / 2);
			l.push({
				x: i.x,
				y: i.y,
				angle: i.angle,
				w: (r - n) * .82
			});
		}
		return {
			path: i,
			slots: l
		};
	});
}
var Q = je(), Me = (() => {
	let e = /* @__PURE__ */ new Map(), t = new Map(A.map((e) => [e.id, e]));
	for (let n of j) for (let [r, i] of [[n.a, n.b], [n.b, n.a]]) {
		let n = t.get(r), a = t.get(i), o = Math.hypot(a.x - n.x, a.y - n.y) || 1, s = e.get(r) ?? {
			dx: 0,
			dy: 0
		};
		s.dx += (a.x - n.x) / o, s.dy += (a.y - n.y) / o, e.set(r, s);
	}
	let n = /* @__PURE__ */ new Map();
	for (let t of A) {
		let r = e.get(t.id) ?? {
			dx: 0,
			dy: 0
		}, i = Math.hypot(r.dx, r.dy), a = i > .01 ? -r.dx / i * 18 : 0, o = i > .01 ? -r.dy / i * 18 : -18, s = Math.abs(r.dx) < Math.abs(r.dy) * .6 ? "middle" : r.dx > 0 ? "end" : "start";
		n.set(t.id, {
			x: t.x + a,
			y: t.y + o,
			anchor: s
		});
	}
	let r = {
		vancouver: [
			-16,
			-21,
			"start"
		],
		calgary: [
			0,
			-23,
			"middle"
		],
		winnipeg: [
			0,
			-23,
			"middle"
		],
		montreal: [
			-5,
			-23,
			"middle"
		],
		boston: [
			12,
			-8,
			"start"
		],
		saultstmarie: [
			0,
			-23,
			"middle"
		],
		toronto: [
			12,
			-17,
			"start"
		],
		duluth: [
			0,
			-23,
			"middle"
		],
		helena: [
			0,
			-23,
			"middle"
		],
		seattle: [
			-18,
			-1,
			"end"
		],
		portland: [
			-15,
			-6,
			"end"
		],
		sanfrancisco: [
			14,
			27,
			"start"
		],
		losangeles: [
			-20,
			28,
			"start"
		],
		saltlakecity: [
			-10,
			29,
			"end"
		],
		denver: [
			0,
			30,
			"middle"
		],
		omaha: [
			-8,
			-20,
			"end"
		],
		kansascity: [
			-11,
			27,
			"end"
		],
		saintlouis: [
			9,
			27,
			"start"
		],
		pittsburgh: [
			-10,
			-20,
			"end"
		],
		newyork: [
			12,
			0,
			"start"
		],
		washington: [
			12,
			1,
			"start"
		],
		raleigh: [
			16,
			-8,
			"start"
		],
		atlanta: [
			-7,
			29,
			"end"
		],
		nashville: [
			-9,
			-23,
			"end"
		],
		charleston: [
			18,
			18,
			"start"
		],
		littlerock: [
			-2,
			28,
			"middle"
		],
		oklahomacity: [
			-10,
			-23,
			"end"
		],
		dallas: [
			-15,
			25,
			"end"
		],
		houston: [
			-2,
			28,
			"middle"
		],
		neworleans: [
			6,
			28,
			"start"
		],
		miami: [
			-1,
			29,
			"middle"
		],
		elpaso: [
			-16,
			27,
			"end"
		],
		santafe: [
			-20,
			-12,
			"end"
		],
		phoenix: [
			0,
			29,
			"middle"
		],
		lasvegas: [
			-15,
			5,
			"end"
		],
		chicago: [
			-20,
			13,
			"end"
		]
	};
	for (let e of A) {
		let t = r[e.id];
		t && n.set(e.id, {
			x: e.x + t[0],
			y: e.y + t[1],
			anchor: t[2]
		});
	}
	return n;
})();
function Ne(e, t) {
	let n = Infinity;
	for (let r = 0; r < t.length - 1; r += 1) {
		let i = t[r], a = t[r + 1], o = a.x - i.x, s = a.y - i.y, c = o * o + s * s, l = c === 0 ? 0 : Math.max(0, Math.min(1, ((e.x - i.x) * o + (e.y - i.y) * s) / c));
		n = Math.min(n, Math.hypot(e.x - (i.x + l * o), e.y - (i.y + l * s)));
	}
	return n;
}
var $ = (e) => e.map((e, t) => `${t === 0 ? "M" : "L"} ${e.x} ${e.y}`).join(" ");
function Pe({ claims: e, seatColor: t, eligible: n, selected: i, onTap: c, pulseCities: l, fitKey: u, ariaLabel: f, closed: p }) {
	let m = o(null), h = d(), [g, _] = s({
		w: 0,
		h: 0
	}), [v, y] = s(null), b = o({
		cx: O / 2,
		cy: 489,
		s: 1
	});
	r(() => {
		let e = m.current, t = new ResizeObserver(() => _({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let S = g.w > 0 ? Math.min(g.w / O, g.h / 978) : 1, T = a(() => ({
		cx: O / 2,
		cy: 489,
		s: S
	}), [S]), E = `${u}:${g.w}:${g.h}`, [D, k] = s("");
	D !== E && g.w > 0 && (k(E), y(T));
	let M = v ?? T;
	r(() => {
		b.current = M;
	});
	let N = (e) => Math.min(Math.max(e, S), S * 5), I = (e) => {
		let t = {
			...b.current,
			s: N(b.current.s * e)
		};
		b.current = t, y(t);
	};
	r(() => {
		let e = m.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = b.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = N(r.s * i), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			b.current = u, y(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [S]);
	let L = o(/* @__PURE__ */ new Map()), R = o(0), z = o(0), B = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), L.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), L.current.size === 1 && (R.current = 0), L.current.size === 2) {
			let [e, t] = [...L.current.values()];
			z.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, V = (e) => {
		let t = L.current.get(e.pointerId);
		if (!t) return;
		let n = m.current.getBoundingClientRect();
		if (L.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			R.current += Math.abs(n) + Math.abs(r);
			let i = b.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			b.current = a, y(a);
		} else if (L.current.size === 2) {
			L.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...L.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (z.current > 0 && i > 0) {
				let e = b.current, a = N(e.s * i / z.current), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				b.current = u, y(u);
			}
			z.current = i, R.current = 99;
			return;
		}
		L.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, H = (e) => {
		let t = L.current.size === 1 && R.current < 10;
		if (L.current.delete(e.pointerId), z.current = 0, !t || !c) return;
		let r = m.current.getBoundingClientRect(), i = b.current, a = {
			x: i.cx + (e.clientX - r.left - r.width / 2) / i.s,
			y: i.cy + (e.clientY - r.top - r.height / 2) / i.s
		}, o = n && n.size > 0 ? [...n] : j.map((e, t) => t), s = null, l = Ae;
		for (let e of o) {
			let t = Ne(a, Q[e].path);
			t < l && (l = t, s = e);
		}
		s !== null && c(s);
	}, U = i == null ? void 0 : /* @__PURE__ */ new Set([j[i].a, j[i].b]), W = {
		x: M.cx - g.w / (2 * M.s) - 1,
		y: M.cy - g.h / (2 * M.s) - 1,
		w: g.w / M.s + 2,
		h: g.h / M.s + 2
	};
	return /* @__PURE__ */ w("div", {
		ref: m,
		className: "ttr-map-viewport relative h-full w-full overflow-hidden",
		role: "group",
		"aria-label": f,
		children: [/* @__PURE__ */ C("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: B,
			onPointerMove: V,
			onPointerUp: H,
			onPointerCancel: H,
			children: /* @__PURE__ */ w("g", {
				transform: `translate(${g.w / 2 - M.cx * M.s}, ${g.h / 2 - M.cy * M.s}) scale(${M.s})`,
				children: [
					/* @__PURE__ */ C(ve, { bounds: W }),
					n && [...n].map((e) => /* @__PURE__ */ w("g", {
						pointerEvents: "none",
						className: "ttr-route-eligible",
						children: [
							/* @__PURE__ */ C("path", {
								d: $(Q[e].path),
								fill: "none",
								stroke: "#ffffff",
								strokeWidth: 24,
								strokeLinecap: "round",
								opacity: .35
							}),
							/* @__PURE__ */ C("path", {
								d: $(Q[e].path),
								fill: "none",
								stroke: "#ffffff",
								strokeWidth: 17,
								strokeLinecap: "round",
								opacity: .85
							}),
							/* @__PURE__ */ C("path", {
								d: $(Q[e].path),
								fill: "none",
								stroke: "#538d94",
								strokeWidth: 2,
								strokeDasharray: "5 10",
								strokeLinecap: "round"
							})
						]
					}, `e${e}`)),
					i != null && /* @__PURE__ */ w("g", {
						pointerEvents: "none",
						children: [/* @__PURE__ */ C("path", {
							d: $(Q[i].path),
							fill: "none",
							stroke: "#f5fbf6",
							strokeWidth: 28,
							strokeLinecap: "round",
							opacity: .95
						}), /* @__PURE__ */ C("path", {
							d: $(Q[i].path),
							fill: "none",
							stroke: "#2e98b5",
							strokeWidth: 22,
							strokeLinecap: "round",
							opacity: .42
						})]
					}),
					j.map((r, i) => {
						let a = Q[i], o = e[String(i)];
						return /* @__PURE__ */ w("g", {
							"data-ttr-route": i,
							opacity: p?.has(i) ? .5 : 1,
							role: n?.has(i) ? "button" : void 0,
							tabIndex: n?.has(i) ? 0 : void 0,
							"aria-label": h("games.ttr.routeAria", {
								a: h(F[r.a]),
								b: h(F[r.b]),
								color: h(P[r.color]),
								n: r.len
							}),
							onKeyDown: (e) => {
								n?.has(i) && (e.key === "Enter" || e.key === " ") && (e.preventDefault(), c?.(i));
							},
							children: [a.slots.map((e, n) => /* @__PURE__ */ C("g", {
								transform: `translate(${e.x} ${e.y}) rotate(${e.angle})`,
								children: /* @__PURE__ */ C(ye, {
									width: e.w,
									color: o === void 0 ? be[r.color] : t(o),
									occupied: o !== void 0
								})
							}, n)), p?.has(i) && /* @__PURE__ */ w("g", {
								transform: `translate(${a.slots[0].x} ${a.slots[0].y}) rotate(${a.slots[0].angle})`,
								children: [/* @__PURE__ */ C("path", {
									d: "M-5 -7L5 7M-5 7L5 -7",
									stroke: "#fff8df",
									strokeWidth: 5
								}), /* @__PURE__ */ C("path", {
									d: "M-5 -7L5 7M-5 7L5 -7",
									stroke: "#53686a",
									strokeWidth: 2.5
								})]
							})]
						}, i);
					}),
					A.map((e) => {
						let t = Me.get(e.id), n = U?.has(e.id) || l?.has(e.id);
						return /* @__PURE__ */ w("g", {
							pointerEvents: "none",
							children: [
								n && /* @__PURE__ */ C("circle", {
									cx: e.x,
									cy: e.y,
									r: 17,
									fill: "#d7f2ee",
									stroke: "#5aa2ad",
									strokeWidth: 1.7
								}),
								/* @__PURE__ */ C("ellipse", {
									cx: e.x + 1,
									cy: e.y + 3,
									rx: 8,
									ry: 6,
									fill: "#456656",
									opacity: .18
								}),
								/* @__PURE__ */ C("circle", {
									cx: e.x,
									cy: e.y,
									r: De,
									fill: "#fff9e7",
									stroke: "#8b9479",
									strokeWidth: 1.8
								}),
								/* @__PURE__ */ C("circle", {
									cx: e.x,
									cy: e.y,
									r: 3,
									fill: n ? "#3b99b0" : "#c77c4c"
								}),
								/* @__PURE__ */ C("text", {
									x: t.x,
									y: t.y,
									textAnchor: t.anchor,
									fontSize: 17,
									fontWeight: 800,
									fill: "#2b4b4e",
									stroke: "#f8f4da",
									strokeWidth: 4.3,
									paintOrder: "stroke",
									children: h(e.nameKey)
								})
							]
						}, e.id);
					}),
					l && [...l].map((e) => {
						let t = A.find((t) => t.id === e);
						return t ? /* @__PURE__ */ C("circle", {
							cx: t.x,
							cy: t.y,
							r: 16,
							fill: "none",
							stroke: "#398fa3",
							strokeWidth: 3,
							pointerEvents: "none"
						}, `p${e}`) : null;
					})
				]
			})
		}), /* @__PURE__ */ w("div", {
			className: "ttr-map-tools",
			children: [
				/* @__PURE__ */ C("button", {
					type: "button",
					onClick: () => I(1 / 1.4),
					disabled: M.s <= S,
					"aria-label": h("games.ttr.zoomOut"),
					children: /* @__PURE__ */ C(ee, {})
				}),
				/* @__PURE__ */ C("button", {
					type: "button",
					onClick: () => I(1.4),
					disabled: M.s >= S * 5,
					"aria-label": h("games.ttr.zoomIn"),
					children: /* @__PURE__ */ C(x, {})
				}),
				/* @__PURE__ */ C("button", {
					type: "button",
					onClick: () => {
						b.current = T, y(T);
					},
					children: h("games.ttr.fitMap")
				})
			]
		})]
	});
}
//#endregion
//#region src/games/ttr/view-player.tsx
function Fe({ card: e, count: t, ariaLabel: n }) {
	return /* @__PURE__ */ w("span", {
		role: "img",
		"aria-label": n,
		className: "ttr-card-chip",
		children: [/* @__PURE__ */ C(we, { card: e }), /* @__PURE__ */ C("span", {
			className: "ttr-hand-count font-mono tabular-nums",
			style: { color: e === "white" || e === "yellow" ? "#665b3d" : "#fff8de" },
			children: t
		})]
	});
}
function Ie({ card: e, onTap: t, anchor: n, ariaLabel: r }) {
	let { ref: i } = c(n), a = d();
	return /* @__PURE__ */ w("button", {
		ref: i,
		type: "button",
		"aria-label": r,
		disabled: !t,
		onClick: t,
		className: "ttr-face-up",
		children: [/* @__PURE__ */ C(we, { card: e }), /* @__PURE__ */ C("span", {
			className: "ttr-card-caption",
			style: { color: e === "white" || e === "yellow" ? "#665b3d" : "#fff8de" },
			children: a(P[e])
		})]
	});
}
function Le(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ C(Re, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Re({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let o = d(), { ref: u } = c("deck"), { ref: h } = c("ticketDeck"), { ref: _ } = c("hand"), [v, y] = s(null), [b, x] = s(null), [ee, T] = s(0), [E, D] = s(/* @__PURE__ */ new Set()), [O, A] = s(!1), [M, N] = s(/* @__PURE__ */ new Set()), L = (e) => n.find((t) => t.rid === e)?.name ?? e, R = e.players.findIndex((e) => e.rid === r), z = R >= 0 ? e.players[R] : void 0, B = e.phase === "play" && e.turn === R, V = t?.pendingPick ?? null, H = a(() => t?.hand ?? {}, [t?.hand]), U = H.loco ?? 0, W = e.phase === "keepInitial" ? 2 : 1, te = a(() => {
		if (!B || e.drawsLeft !== 2 || e.pickingTickets || !z) return;
		let t = e.players.length, n = /* @__PURE__ */ new Map();
		for (let [t, r] of Object.entries(e.claims)) {
			let e = j[Number(t)];
			n.set([e.a, e.b].sort().join("|"), r);
		}
		let r = /* @__PURE__ */ new Set();
		return j.forEach((i, a) => {
			if (e.claims[String(a)] === void 0 && !(i.len > z.trainsLeft)) {
				if (i.double !== void 0) {
					let e = n.get([i.a, i.b].sort().join("|"));
					if (e === R || e !== void 0 && t <= 3) return;
				}
				(i.color === "gray" ? k : [i.color]).some((e) => (H[e] ?? 0) + U >= i.len) && r.add(a);
			}
		}), r;
	}, [
		B,
		e.drawsLeft,
		e.pickingTickets,
		e.claims,
		e.players.length,
		z,
		R,
		H,
		U
	]), G = a(() => new Set(j.flatMap((t, n) => e.players.length > 3 || t.double === void 0 || e.claims[String(n)] !== void 0 ? [] : j.some((r, i) => i !== n && r.a === t.a && r.b === t.b && e.claims[String(i)] !== void 0) ? [n] : [])), [e.claims, e.players.length]), K = v === null ? null : j[v], q = K ? K.color === "gray" ? k.filter((e) => (H[e] ?? 0) + U >= K.len) : [K.color] : [], J = b && q.includes(b) ? b : q[0], ne = J ? H[J] ?? 0 : 0, re = K ? Math.max(0, K.len - ne) : 0, Y = K ? Math.min(K.len, U) : 0, X = Math.min(Math.max(ee, re), Y), Z = (e) => {
		if (!te?.has(e)) return;
		y(e);
		let t = j[e], n = [...t.color === "gray" ? k.filter((e) => (H[e] ?? 0) + U >= t.len) : [t.color]].sort((e, t) => (H[t] ?? 0) - (H[e] ?? 0))[0];
		x(n ?? null), T(n ? Math.max(0, t.len - (H[n] ?? 0)) : 0);
	}, ie = () => {
		v !== null && J && (i({
			type: "claim",
			route: v,
			color: J,
			locos: X
		}), y(null));
	}, ae = (e) => {
		let t = new Set(E);
		t.has(e) ? t.delete(e) : t.add(e), D(t);
	}, oe = () => {
		E.size < W || (i(e.phase === "keepInitial" ? {
			type: "keepInitialTickets",
			keep: [...E]
		} : {
			type: "keepTickets",
			keep: [...E]
		}), D(/* @__PURE__ */ new Set()));
	}, se = (() => {
		if (e.phase === "keepInitial") return z?.ready ? {
			tone: "info",
			text: o("games.ttr.waitingKeep")
		} : {
			tone: "accent",
			text: o("games.ttr.keepInitialPrompt", { min: 2 })
		};
		if (B && e.pickingTickets) return {
			tone: "accent",
			text: o("games.ttr.keepTicketsPrompt", { min: 1 })
		};
		if (B) return {
			tone: "accent",
			text: e.drawsLeft === 1 ? o("games.ttr.drawMore", { n: 1 }) : o("games.ttr.yourTurn")
		};
		let t = e.turn === null ? null : e.players[e.turn];
		return {
			tone: "info",
			text: t ? o("games.ttr.waitingTurn", { name: L(t.rid) }) : ""
		};
	})(), ce = (t) => {
		let r = e.players[t]?.rid, i = n.find((e) => e.rid === r);
		return f[(i?.colorIndex ?? t) % f.length].hex;
	}, le = e.players.map((e) => n.find((t) => t.rid === e.rid)).filter((e) => e !== void 0);
	return /* @__PURE__ */ C("div", {
		className: "ttr-view h-full min-h-0",
		"data-seats": e.players.length,
		style: { "--ttr-seats": e.players.length },
		children: /* @__PURE__ */ C(g, {
			adaptive: !0,
			className: "ttr-screen",
			scroll: !1,
			banner: /* @__PURE__ */ w("div", {
				className: "ttr-banner flex flex-col gap-2",
				children: [/* @__PURE__ */ C(p, {
					tone: se.tone,
					text: se.text,
					accent: I.accent,
					chip: e.lastRoundFor === null ? void 0 : o("games.ttr.lastRoundChip")
				}), /* @__PURE__ */ C(m, {
					members: le,
					myRid: r,
					variant: "plate",
					anchorOf: (e) => `seat:${e}`,
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ w("span", {
							className: "ttr-status flex items-center gap-1.5 font-mono text-xs font-bold tabular-nums",
							children: [
								/* @__PURE__ */ C(l, {
									value: n.score,
									className: "ttr-score text-sm font-black"
								}),
								/* @__PURE__ */ w("span", {
									"aria-label": o("games.ttr.statusTrains", { n: n.trainsLeft }),
									children: ["🚃", n.trainsLeft]
								}),
								/* @__PURE__ */ w("span", { children: ["🃏", n.cardCount] }),
								/* @__PURE__ */ w("span", { children: ["🎫", n.ticketCount] })
							]
						}) : null;
					},
					action: (t) => e.phase === "keepInitial" ? e.players.find((e) => e.rid === t)?.ready ? "done" : "pending" : e.turn !== null && e.players[e.turn]?.rid === t ? "pending" : null
				})]
			}),
			actionsHeight: "ttr-action-slot",
			actions: /* @__PURE__ */ w("div", {
				className: "ttr-actions safe-b flex h-full min-h-0 shrink-0 flex-col gap-2",
				children: [
					/* @__PURE__ */ w("div", {
						className: "ttr-market flex h-12 items-center justify-center gap-1.5",
						children: [
							e.faceUp.map((t, n) => /* @__PURE__ */ C(Ie, {
								card: t,
								anchor: `faceUp:${n}`,
								ariaLabel: o("games.ttr.faceUpAria", { color: o(P[t]) }),
								onTap: B && !e.pickingTickets && e.drawsLeft > 0 && (t !== "loco" || e.drawsLeft === 2) ? () => i({
									type: "drawCard",
									source: { faceUp: n }
								}) : void 0
							}, n)),
							/* @__PURE__ */ w("button", {
								type: "button",
								ref: u,
								"aria-label": o("games.ttr.deckAria", { n: e.deckCount }),
								disabled: !B || e.pickingTickets || e.drawsLeft === 0 || e.deckCount === 0,
								onClick: () => i({
									type: "drawCard",
									source: "deck"
								}),
								className: "ttr-deck ttr-train-deck",
								children: [/* @__PURE__ */ C(we, {
									card: "loco",
									back: !0
								}), /* @__PURE__ */ C("span", {
									className: "ttr-deck-count font-mono tabular-nums",
									children: e.deckCount
								})]
							}),
							/* @__PURE__ */ w("button", {
								type: "button",
								ref: h,
								"aria-label": o("games.ttr.ticketDeckAria", { n: e.ticketDeckCount }),
								disabled: !B || e.pickingTickets || e.drawsLeft !== 2 || e.ticketDeckCount === 0,
								onClick: () => i({ type: "drawTickets" }),
								className: "ttr-deck ttr-ticket-deck",
								children: [/* @__PURE__ */ C(Te, {}), /* @__PURE__ */ C("span", {
									className: "ttr-deck-count font-mono tabular-nums",
									children: e.ticketDeckCount
								})]
							})
						]
					}),
					/* @__PURE__ */ w("div", {
						ref: _,
						"data-tickets": O,
						className: "ttr-hand flex h-9 items-center gap-1.5 overflow-x-auto px-1",
						children: [/* @__PURE__ */ w("div", {
							className: "ttr-my-tickets",
							children: [
								(t?.myTickets.length ?? 0) > 0 && /* @__PURE__ */ C("h3", {
									className: "ttr-section-title",
									children: o("games.ttr.ticketsMine")
								}),
								/* @__PURE__ */ w("button", {
									type: "button",
									onClick: () => A(!1),
									className: "ttr-hand-toggle btn-quiet h-9 shrink-0 px-2 text-xs font-bold",
									children: ["← ", o("games.ttr.handTitle")]
								}),
								(t?.myTickets ?? []).map((e) => /* @__PURE__ */ C("button", {
									type: "button",
									onClick: () => N(/* @__PURE__ */ new Set([e.a, e.b])),
									className: "ttr-ticket-button",
									"aria-label": `${o(F[e.a])}–${o(F[e.b])} ${e.points} · ${o(e.done ? "games.ttr.ticketDone" : "games.ttr.ticketUndone")}`,
									children: /* @__PURE__ */ C(Ee, {
										a: o(F[e.a]),
										b: o(F[e.b]),
										points: e.points,
										done: e.done
									})
								}, e.id))
							]
						}), /* @__PURE__ */ w("div", {
							className: "ttr-hand-cards",
							children: [
								/* @__PURE__ */ C("h3", {
									className: "ttr-section-title",
									children: o("games.ttr.handTitle")
								}),
								[...k, "loco"].filter((e) => (H[e] ?? 0) > 0).map((e) => /* @__PURE__ */ C(Fe, {
									card: e,
									count: H[e] ?? 0,
									ariaLabel: `${o(P[e])} ${H[e] ?? 0}`
								}, e)),
								(t?.myTickets.length ?? 0) > 0 && /* @__PURE__ */ w("button", {
									type: "button",
									onClick: () => A(!0),
									className: "ttr-hand-toggle btn-quiet ml-auto h-9 shrink-0 px-2 text-xs font-bold",
									children: [
										o("games.ttr.ticketsMine"),
										" (",
										t?.myTickets.length ?? 0,
										")"
									]
								})
							]
						})]
					}),
					/* @__PURE__ */ C("div", {
						className: "ttr-controls flex min-h-12 items-stretch gap-2",
						children: V ? /* @__PURE__ */ w(S, { children: [/* @__PURE__ */ C("div", {
							className: "ttr-ticket-options flex flex-1 items-center gap-1.5 overflow-x-auto",
							children: V.map((e) => /* @__PURE__ */ C("button", {
								type: "button",
								"aria-pressed": E.has(e.id),
								onClick: () => ae(e.id),
								className: "ttr-ticket-button",
								children: /* @__PURE__ */ C(Ee, {
									a: o(F[e.a]),
									b: o(F[e.b]),
									points: e.points
								})
							}, e.id))
						}), /* @__PURE__ */ C("button", {
							type: "button",
							disabled: E.size < W,
							onClick: oe,
							className: "btn-base min-h-12 shrink-0 px-4 text-sm font-black text-white disabled:opacity-40",
							style: { background: I.accent },
							children: o("games.ttr.keepConfirm", { n: E.size })
						})] }) : v !== null && K ? /* @__PURE__ */ w("div", {
							className: "ttr-payment flex flex-1 items-center gap-2 px-2 py-1",
							children: [
								/* @__PURE__ */ w("span", {
									className: "min-w-0 flex-1 truncate text-xs font-bold",
									children: [
										o(F[K.a]),
										"–",
										o(F[K.b]),
										" · ",
										K.len
									]
								}),
								K.color === "gray" && /* @__PURE__ */ C("span", {
									className: "flex gap-1",
									children: q.map((e) => /* @__PURE__ */ C("button", {
										type: "button",
										"aria-label": o(P[e]),
										"aria-pressed": J === e,
										onClick: () => {
											x(e), T(Math.max(0, K.len - (H[e] ?? 0)));
										},
										className: `size-7 rounded-md border-2 ${J === e ? "border-ink ring-2 ring-ink" : "border-ink/40"}`,
										style: { background: be[e] }
									}, e))
								}),
								Y > re && /* @__PURE__ */ w("span", {
									className: "flex items-center gap-1 font-mono text-xs font-black tabular-nums",
									children: [
										/* @__PURE__ */ C("button", {
											type: "button",
											"aria-label": o("games.ttr.locoLess"),
											onClick: () => T(X - 1),
											disabled: X <= re,
											className: "btn-quiet size-7",
											children: "−"
										}),
										"🚂",
										X,
										/* @__PURE__ */ C("button", {
											type: "button",
											"aria-label": o("games.ttr.locoMore"),
											onClick: () => T(X + 1),
											disabled: X >= Y,
											className: "btn-quiet size-7",
											children: "+"
										})
									]
								}),
								/* @__PURE__ */ C("button", {
									type: "button",
									onClick: ie,
									className: "btn-base min-h-11 shrink-0 px-3 text-sm font-black text-white",
									style: { background: I.accent },
									children: o("games.ttr.claimConfirm")
								}),
								/* @__PURE__ */ C("button", {
									type: "button",
									onClick: () => y(null),
									className: "btn-quiet min-h-11 shrink-0 px-2 text-sm font-bold",
									"aria-label": o("games.ttr.claimCancel"),
									children: "✕"
								})
							]
						}) : /* @__PURE__ */ C("div", {
							className: "flex flex-1 items-center justify-center text-xs font-bold opacity-60",
							children: e.lastRoundFor === null ? "" : o("games.ttr.lastRound")
						})
					})
				]
			}),
			children: /* @__PURE__ */ C("div", {
				className: "ttr-board h-full min-h-0 overflow-hidden",
				children: /* @__PURE__ */ C(Pe, {
					claims: e.claims,
					seatColor: ce,
					eligible: te,
					selected: v,
					onTap: Z,
					pulseCities: M,
					fitKey: "main",
					ariaLabel: o("games.ttr.name"),
					closed: G
				})
			})
		})
	});
}
//#endregion
//#region src/games/ttr/bot.ts
var ze = (e, t) => [e, t].sort().join("|");
function Be(e, t) {
	let n = e.public, r = /* @__PURE__ */ new Map();
	for (let [e, t] of Object.entries(n.claims)) {
		let n = j[Number(e)];
		r.set(ze(n.a, n.b), t);
	}
	let i = [];
	return j.forEach((e, a) => {
		let o = n.claims[String(a)];
		if (o !== t && o === void 0) {
			if (e.double !== void 0) {
				let i = r.get(ze(e.a, e.b));
				if (i === t || i !== void 0 && n.players.length <= 3) return;
			}
			i.push({
				idx: a,
				len: e.len
			});
		}
	}), i;
}
function Ve(e, t, n, r) {
	let i = e.public, a = Be(e, t), o = new Set(Object.entries(i.claims).filter(([, e]) => e === t).map(([e]) => Number(e))), s = /* @__PURE__ */ new Map(), c = (e, t, n, r) => {
		let i = s.get(e) ?? [];
		i.push({
			to: t,
			idx: n,
			cost: o.has(n) ? 0 : r
		}), s.set(e, i);
	};
	for (let e of a) c(j[e.idx].a, j[e.idx].b, e.idx, e.len), c(j[e.idx].b, j[e.idx].a, e.idx, e.len);
	for (let e of o) c(j[e].a, j[e].b, e, 0), c(j[e].b, j[e].a, e, 0);
	let l = /* @__PURE__ */ new Map([[n, 0]]), u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set();
	for (;;) {
		let e = null, t = Infinity;
		for (let [n, r] of l) !d.has(n) && r < t && (t = r, e = n);
		if (e === null) return {
			cost: Infinity,
			edges: []
		};
		if (e === r) break;
		d.add(e);
		for (let n of s.get(e) ?? []) {
			let r = t + n.cost;
			r < (l.get(n.to) ?? Infinity) && (l.set(n.to, r), u.set(n.to, {
				from: e,
				idx: n.idx
			}));
		}
	}
	let f = [], p = r;
	for (; p !== n;) {
		let e = u.get(p);
		if (!e) break;
		f.push(e.idx), p = e.from;
	}
	return {
		cost: l.get(r) ?? Infinity,
		edges: f
	};
}
function He(e, t) {
	let n = e.public, r = /* @__PURE__ */ new Map();
	for (let i of e.private?.myTickets ?? []) {
		if (i.done) continue;
		let { edges: a } = Ve(e, t, i.a, i.b);
		for (let e of a) n.claims[String(e)] === void 0 && r.set(e, (r.get(e) ?? 0) + 1);
	}
	return r;
}
function Ue(e, t) {
	let n = e.loco ?? 0;
	return (t.color === "gray" ? k : [t.color]).some((r) => (e[r] ?? 0) + n >= t.len);
}
function We(e, t) {
	let n = e.loco ?? 0, r = (t.color === "gray" ? k : [t.color]).filter((r) => (e[r] ?? 0) + n >= t.len);
	if (r.length === 0) return null;
	let i = [...r].sort((t, n) => (e[n] ?? 0) - (e[t] ?? 0))[0];
	return {
		color: i,
		locos: Math.max(0, t.len - (e[i] ?? 0))
	};
}
var Ge = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = n.players.findIndex((e) => e.rid === t.rid);
	if (i < 0) return null;
	let a = n.players[i], o = r.hand;
	if (r.pendingPick) {
		let t = n.phase === "keepInitial" ? 2 : 1, a = r.pendingPick.map((t) => ({
			id: t.id,
			cost: Ve(e, i, t.a, t.b).cost,
			points: t.points
		})).sort((e, t) => e.cost - t.cost), o = [];
		for (let e of a) (o.length < t || e.cost <= 10 || n.phase === "keepInitial" && e.cost <= 14) && o.push(e.id);
		for (let e of a) {
			if (o.length >= t) break;
			o.includes(e.id) || o.push(e.id);
		}
		return { action: n.phase === "keepInitial" ? {
			type: "keepInitialTickets",
			keep: o
		} : {
			type: "keepTickets",
			keep: o
		} };
	}
	if (n.phase !== "play" || n.turn !== i || n.pickingTickets) return null;
	let s = He(e, i);
	if (n.drawsLeft === 1) {
		let e = /* @__PURE__ */ new Set();
		for (let t of s.keys()) {
			let n = j[t];
			n.color !== "gray" && e.add(n.color);
		}
		let t = n.faceUp.findIndex((t) => t !== "loco" && e.has(t));
		if (t >= 0) return { action: {
			type: "drawCard",
			source: { faceUp: t }
		} };
		if (n.deckCount > 0) return { action: {
			type: "drawCard",
			source: "deck"
		} };
		let r = n.faceUp.findIndex((e) => e !== "loco");
		return r >= 0 ? { action: {
			type: "drawCard",
			source: { faceUp: r }
		} } : null;
	}
	let c = [...s.entries()].filter(([e]) => j[e].len <= a.trainsLeft && Ue(o, j[e])).sort((e, t) => t[1] - e[1] || j[t[0]].len - j[e[0]].len);
	if (c.length > 0) {
		let e = c[0][0], t = We(o, j[e]);
		if (t) return { action: {
			type: "claim",
			route: e,
			color: t.color,
			locos: t.locos
		} };
	}
	let l = /* @__PURE__ */ new Set();
	for (let e of s.keys()) {
		let t = j[e];
		t.color !== "gray" && l.add(t.color);
	}
	if (l.size > 0 || r.myTickets.some((e) => !e.done)) {
		let e = n.faceUp.findIndex((e) => e === "loco"), t = n.faceUp.findIndex((e) => e !== "loco" && l.has(e));
		if (t >= 0) return { action: {
			type: "drawCard",
			source: { faceUp: t }
		} };
		if (e >= 0 && s.size > 0) return { action: {
			type: "drawCard",
			source: { faceUp: e }
		} };
		if (n.deckCount > 0) return { action: {
			type: "drawCard",
			source: "deck"
		} };
	}
	if (r.myTickets.every((e) => e.done) && n.ticketDeckCount > 0) return { action: { type: "drawTickets" } };
	let u = new Set(Be(e, i).map((e) => e.idx)), d = j.map((e, t) => ({
		r: e,
		i: t
	})).filter(({ r: e, i: t }) => u.has(t) && e.len <= a.trainsLeft && Ue(o, e)).sort((e, t) => t.r.len - e.r.len);
	for (let { r: e, i: t } of d) {
		let n = We(o, e);
		if (n) return { action: {
			type: "claim",
			route: t,
			color: n.color,
			locos: n.locos
		} };
	}
	if (n.deckCount > 0) return { action: {
		type: "drawCard",
		source: "deck"
	} };
	let f = n.faceUp.findIndex((e) => e !== "loco");
	return f >= 0 ? { action: {
		type: "drawCard",
		source: { faceUp: f }
	} } : n.ticketDeckCount > 0 ? { action: { type: "drawTickets" } } : null;
}, Ke = (e, t, n) => {
	switch (e.type) {
		case "keepInitialTickets":
		case "keepTickets": return n("games.ttr.hintKeepTickets", { n: e.keep.length });
		case "drawCard": return e.source === "deck" ? n("games.ttr.hintDrawDeck") : n("games.ttr.hintDrawFaceUp", { color: n(P[t.public.faceUp[e.source.faceUp] ?? "loco"]) });
		case "claim": {
			let t = j[e.route];
			return n("games.ttr.hintClaim", {
				a: n(F[t.a]),
				b: n(F[t.b]),
				color: n(P[t.color]),
				n: t.len
			});
		}
		case "drawTickets": return n("games.ttr.hintDrawTickets");
	}
}, qe = {
	claim(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.points != "number" ? null : {
			ms: 1300,
			node: /* @__PURE__ */ w(S, { children: [/* @__PURE__ */ C(E, {
				at: r,
				ms: 600
			}), /* @__PURE__ */ C(T, {
				at: r,
				ms: 1300,
				children: /* @__PURE__ */ w("span", {
					style: { fontSize: Math.max(18, Math.min(36, r.w * 18 / 44)) },
					children: ["🛤️+", n.points]
				})
			})] })
		};
	},
	draw(e, t) {
		let n = e.data, r = n?.from === "faceUp" && typeof n.idx == "number" ? t.anchor(`faceUp:${n.idx}`) : t.anchor("deck");
		return r ? {
			ms: 500,
			node: /* @__PURE__ */ C(E, {
				at: r,
				ms: 500
			})
		} : null;
	},
	drawTickets(e, t) {
		let n = t.anchor("ticketDeck");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ C(E, {
				at: n,
				ms: 500
			})
		} : null;
	},
	keepTickets(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.count != "number" ? null : {
			ms: 1100,
			node: /* @__PURE__ */ C(T, {
				at: r,
				ms: 1100,
				children: /* @__PURE__ */ w("span", {
					style: { fontSize: Math.max(18, Math.min(36, r.w * 18 / 44)) },
					children: ["🎫×", n.count]
				})
			})
		};
	}
};
//#endregion
//#region src/games/ttr/endgame-review.tsx
function Je({ board: e, renderResult: t, ...n }) {
	let i = d(), [c, l] = s(!0), [u, f] = s(null), p = o(null), m = o(null), h = o(null);
	r(() => {
		if (!u) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let g = (e) => {
		f(null), l(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, v = a(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), x = {
		...n,
		...v
	};
	return /* @__PURE__ */ w("div", {
		className: "ttr-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ C("div", {
				className: "ttr-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ C("div", {
				className: "ttr-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ w("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), g(!1));
					},
					className: "ttr-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ w("header", {
							className: "ttr-endgame-heading",
							children: [/* @__PURE__ */ w("div", {
								className: "ttr-endgame-brand",
								children: [/* @__PURE__ */ C("span", {
									"aria-hidden": "true",
									children: I.icon
								}), i(I.nameKey)]
							}), /* @__PURE__ */ C("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": i("games.ttr.reviewHide"),
								title: i("games.ttr.reviewHide"),
								onClick: () => g(!1),
								children: /* @__PURE__ */ C(y, { size: 19 })
							})]
						}),
						/* @__PURE__ */ C("div", {
							className: "ttr-endgame-result",
							inert: u !== null,
							children: t(x)
						}),
						u && /* @__PURE__ */ w("div", {
							className: "ttr-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ C("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									f(null), e();
								},
								children: i(u.label === "again" ? "games.ttr.reviewConfirmAgain" : "games.ttr.reviewConfirmLobby")
							}), /* @__PURE__ */ C("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: i("games.ttr.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ C("div", {
				className: "ttr-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ w("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => g(!0),
					children: [
						/* @__PURE__ */ C(b, { size: 18 }),
						i("games.ttr.reviewShow"),
						/* @__PURE__ */ C(_, { size: 18 })
					]
				})
			})
		]
	});
}
function Ye({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: c, renderRowExtra: l, summary: f, navigation: p, content: m, afterRanking: g, scoreUnit: _, rankOf: b }) {
	let x = d(), ee = u((e) => e.locale), [T, E] = s({}), O = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? h(n, ee) : e;
	}, k = (t, n) => b?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), A = e.ranking.some((t) => e.scores?.[t] !== void 0), j = (t, n) => /* @__PURE__ */ w("div", {
		className: "ttr-score-identity",
		children: [
			/* @__PURE__ */ w("span", {
				className: "ttr-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ C("span", {
					"aria-label": x("games.ttr.reviewWinner"),
					children: "♛ "
				}), A && k(t, n)]
			}),
			/* @__PURE__ */ w("span", {
				className: "ttr-score-name",
				children: [O(t), t === r && /* @__PURE__ */ C("small", { children: x("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ w("small", {
				className: "ttr-score-autopilot",
				children: [
					/* @__PURE__ */ C(v, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), M = (t) => e.ranking.map((n) => /* @__PURE__ */ C("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ w("div", {
		className: "ttr-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ C(D, {}),
			p,
			/* @__PURE__ */ w("div", {
				className: "ttr-score-body",
				children: [
					f && /* @__PURE__ */ C("div", {
						className: "ttr-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ C("p", {
						className: "ttr-score-hints",
						children: x("session.hint.usedCount", { n: i })
					}),
					m ?? (c?.length ? /* @__PURE__ */ C("div", {
						className: "ttr-score-table-scroll",
						children: /* @__PURE__ */ w("table", {
							className: "ttr-score-table",
							"aria-label": x(I.nameKey),
							children: [
								/* @__PURE__ */ C("thead", { children: /* @__PURE__ */ w("tr", { children: [/* @__PURE__ */ C("th", { scope: "col" }), /* @__PURE__ */ C(S, { children: e.ranking.map((t, n) => /* @__PURE__ */ C("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: j(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ C("tbody", { children: c.map((e, t) => /* @__PURE__ */ w(n, { children: [/* @__PURE__ */ w("tr", { children: [/* @__PURE__ */ C("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ w("button", {
										type: "button",
										"aria-expanded": !!T[t],
										onClick: () => E((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ C(y, { size: 15 }), e.label]
									}) : e.label
								}), M(e)] }), T[t] && e.details?.map((e, t) => /* @__PURE__ */ w("tr", {
									className: "ttr-score-sub",
									children: [/* @__PURE__ */ C("th", {
										scope: "row",
										children: e.label
									}), M(e)]
								}, t))] }, t)) }),
								A && /* @__PURE__ */ C("tfoot", { children: /* @__PURE__ */ w("tr", { children: [/* @__PURE__ */ C("th", {
									scope: "row",
									children: x("games.ttr.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ C("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ C("ol", {
						className: "ttr-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ w("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ w("div", {
								className: "ttr-score-rankline",
								children: [j(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ w("strong", {
									className: "ttr-score-points",
									children: [e.scores[t], _ && /* @__PURE__ */ C("small", { children: _ })]
								})]
							}), l?.(t)]
						}, t))
					})),
					g,
					!!c?.length && l && /* @__PURE__ */ C("div", {
						className: "ttr-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ w("details", { children: [/* @__PURE__ */ C("summary", { children: O(e) }), l(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ w("footer", {
				className: "ttr-score-actions",
				children: [
					o && /* @__PURE__ */ C("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: x("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ C("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: x("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ C("p", { children: x("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/ttr/game-over.tsx
function Xe(e) {
	return /* @__PURE__ */ C(Ye, {
		hintCount: e.hintCount,
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: I.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby
	});
}
function Ze(e) {
	return /* @__PURE__ */ C(Je, {
		...e,
		board: /* @__PURE__ */ C(Le, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ C(Xe, { ...e })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/ttr/entry.tsx
var Qe = {
	definition: me,
	View: Le,
	bot: Ge,
	describe: Ke,
	fx: qe,
	OverView: Ze,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "车票之旅",
			desc: "铺铁路连城市,完成车票赢高分",
			rules: "目标:铺设铁路连接城市,完成车票、铺长路,总分最高者获胜。\n准备:\n· 每人 45 节车厢、4 张火车卡;桌面翻出 5 张明牌。\n· 每人发 3 张车票,至少保留 2 张,其余放回票堆底部。\n流程:\n· 每回合三选一:摸 2 张火车卡;或占一条铁路;或摸 3 张车票至少留 1 张。\n· 摸卡可从牌堆盲摸,也可拿明牌;拿明牌火车头则本回合只能拿这 1 张。明牌中火车头达到 3 张时,5 张全部弃掉并重翻。\n· 占路:打出与路线同色、同数量的一套卡(灰色路线可用任意一种颜色),火车头是百搭;把车厢放上路格并立刻得分,路越长分越高。\n· 部分城市间有两条平行路线,同一人不能占两条;2~3 人局平行路线只开放一条。\n结束:\n· 有人回合结束时车厢剩 2 节或更少,所有人(含他)再打最后一轮后结算。\n· 结算:完成的车票加分、未完成扣分;拥有最长连续铁路的玩家加 10 分(并列则都获得)。平分则完成车票多者胜。",
			city: {
				atlanta: "亚特兰大",
				boston: "波士顿",
				calgary: "卡尔加里",
				charleston: "查尔斯顿",
				chicago: "芝加哥",
				dallas: "达拉斯",
				denver: "丹佛",
				duluth: "德卢斯",
				elpaso: "埃尔帕索",
				helena: "海伦娜",
				houston: "休斯顿",
				kansascity: "堪萨斯城",
				lasvegas: "拉斯维加斯",
				littlerock: "小石城",
				losangeles: "洛杉矶",
				miami: "迈阿密",
				montreal: "蒙特利尔",
				nashville: "纳什维尔",
				neworleans: "新奥尔良",
				newyork: "纽约",
				oklahomacity: "俄克拉荷马城",
				omaha: "奥马哈",
				phoenix: "菲尼克斯",
				pittsburgh: "匹兹堡",
				portland: "波特兰",
				raleigh: "罗利",
				saintlouis: "圣路易斯",
				saltlakecity: "盐湖城",
				sanfrancisco: "旧金山",
				santafe: "圣达菲",
				saultstemarie: "苏圣玛丽",
				seattle: "西雅图",
				toronto: "多伦多",
				vancouver: "温哥华",
				washington: "华盛顿",
				winnipeg: "温尼伯"
			},
			color: {
				purple: "紫色",
				blue: "蓝色",
				orange: "橙色",
				white: "白色",
				green: "绿色",
				yellow: "黄色",
				black: "黑色",
				red: "红色",
				loco: "火车头",
				gray: "灰色"
			},
			keepInitialPrompt: "开局车票:至少保留 {{min}} 张",
			keepTicketsPrompt: "摸到的车票:至少保留 {{min}} 张",
			keepConfirm: "保留 {{n}} 张",
			waitingKeep: "等其他人选留车票…",
			yourTurn: "轮到你了",
			waitingTurn: "等 {{name}} 行动…",
			drawMore: "再摸 {{n}} 张",
			drawDeck: "摸牌堆",
			drawTickets: "摸车票",
			claimTitle: "占领这条铁路",
			claimNeed: "需要 {{n}} 张同色卡",
			claimPay: "支付:{{color}} ×{{n}} + 火车头 ×{{locos}}",
			claimConfirm: "占路",
			claimCancel: "取消",
			locoLess: "少用一张火车头",
			locoMore: "多用一张火车头",
			claimPickColor: "灰色路线:选一种颜色支付",
			ticketsMine: "我的车票",
			ticketDone: "已完成",
			ticketUndone: "未完成",
			lastRound: "最后一轮!",
			lastRoundChip: "末轮",
			handTitle: "手牌",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			fitMap: "全图",
			statusScore: "{{n}} 分",
			statusTrains: "{{n}} 节",
			routeAria: "{{a}} 到 {{b}},{{color}},{{n}} 格",
			faceUpAria: "明牌:{{color}}",
			deckAria: "牌堆,剩 {{n}} 张",
			ticketDeckAria: "车票堆,剩 {{n}} 张",
			finalRoute: "铁路 {{n}}",
			finalTickets: "车票 {{n}}",
			finalLongest: "最长铁路 +{{n}}",
			hintDrawDeck: "从牌堆盲摸一张",
			hintDrawFaceUp: "拿明牌「{{color}}」",
			hintClaim: "占 {{a}}–{{b}}({{color}}{{n}} 格)",
			hintDrawTickets: "摸新车票",
			hintKeepTickets: "保留 {{n}} 张车票",
			errNotYourTurn: "现在轮不到你",
			errNotInPhase: "现在不能这么操作",
			errBadPick: "选的车票不对",
			errDeckEmpty: "牌堆空了",
			errLocoFirst: "明牌火车头只能作为本回合第一张拿",
			errRouteTaken: "这条铁路已被占领",
			errDoubleSame: "平行路线不能两条都占",
			errDoubleClosed: "2~3 人局平行路线只开放一条",
			errBadColor: "卡的颜色与路线不符",
			errCantPay: "手上的卡不够支付",
			errNoTrains: "车厢不够了"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Ticket to Ride",
			desc: "Claim railways, link cities, complete tickets",
			rules: "Goal: claim railway routes to connect cities, complete destination tickets, and score the most points.\nSetup:\n· Each player gets 45 trains and 4 train car cards; five cards are dealt face up.\n· Each player is dealt 3 destination tickets and keeps at least 2; the rest go to the bottom of the ticket deck.\nPlay:\n· On your turn, do one of: draw 2 train car cards; claim a route; or draw 3 destination tickets and keep at least 1.\n· Draw blind from the deck or take a face-up card; a face-up locomotive is the only card you may take that turn. If three of the five face-up cards are locomotives, discard all five and refill.\n· To claim a route, play a set of cards matching its color and length (gray routes accept any one color); locomotives are wild. Score immediately — longer routes are worth more.\n· Some city pairs have two parallel routes; one player cannot claim both, and in 2~3 player games only one of the pair may be used.\nEnd:\n· When a player has 2 or fewer trains left at the end of a turn, everyone (including that player) takes one final turn.\n· Scoring: completed tickets add their value, uncompleted tickets subtract it; the longest continuous railway earns 10 points (tied players all score it). Ties go to the most completed tickets.",
			city: {
				atlanta: "Atlanta",
				boston: "Boston",
				calgary: "Calgary",
				charleston: "Charleston",
				chicago: "Chicago",
				dallas: "Dallas",
				denver: "Denver",
				duluth: "Duluth",
				elpaso: "El Paso",
				helena: "Helena",
				houston: "Houston",
				kansascity: "Kansas City",
				lasvegas: "Las Vegas",
				littlerock: "Little Rock",
				losangeles: "Los Angeles",
				miami: "Miami",
				montreal: "Montréal",
				nashville: "Nashville",
				neworleans: "New Orleans",
				newyork: "New York",
				oklahomacity: "Oklahoma City",
				omaha: "Omaha",
				phoenix: "Phoenix",
				pittsburgh: "Pittsburgh",
				portland: "Portland",
				raleigh: "Raleigh",
				saintlouis: "Saint Louis",
				saltlakecity: "Salt Lake City",
				sanfrancisco: "San Francisco",
				santafe: "Santa Fe",
				saultstemarie: "Sault Ste. Marie",
				seattle: "Seattle",
				toronto: "Toronto",
				vancouver: "Vancouver",
				washington: "Washington",
				winnipeg: "Winnipeg"
			},
			color: {
				purple: "Purple",
				blue: "Blue",
				orange: "Orange",
				white: "White",
				green: "Green",
				yellow: "Yellow",
				black: "Black",
				red: "Red",
				loco: "Locomotive",
				gray: "Gray"
			},
			keepInitialPrompt: "Starting tickets: keep at least {{min}}",
			keepTicketsPrompt: "Drawn tickets: keep at least {{min}}",
			keepConfirm: "Keep {{n}}",
			waitingKeep: "Waiting for others to pick tickets…",
			yourTurn: "Your turn",
			waitingTurn: "Waiting for {{name}}…",
			drawMore: "Draw {{n}} more",
			drawDeck: "Draw deck",
			drawTickets: "Tickets",
			claimTitle: "Claim this route",
			claimNeed: "Needs {{n}} cards of one color",
			claimPay: "Pay: {{color}} ×{{n}} + Locomotive ×{{locos}}",
			claimConfirm: "Claim",
			claimCancel: "Cancel",
			locoLess: "Use one fewer locomotive",
			locoMore: "Use one more locomotive",
			claimPickColor: "Gray route: pick a color to pay",
			ticketsMine: "My tickets",
			ticketDone: "Done",
			ticketUndone: "Open",
			lastRound: "Final round!",
			lastRoundChip: "Final",
			handTitle: "Hand",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			fitMap: "Full map",
			statusScore: "{{n}} pts",
			statusTrains: "{{n}} trains",
			routeAria: "{{a}} to {{b}}, {{color}}, {{n}} spaces",
			faceUpAria: "Face-up: {{color}}",
			deckAria: "Deck, {{n}} left",
			ticketDeckAria: "Ticket deck, {{n}} left",
			finalRoute: "Routes {{n}}",
			finalTickets: "Tickets {{n}}",
			finalLongest: "Longest +{{n}}",
			hintDrawDeck: "Draw one blind from the deck",
			hintDrawFaceUp: "Take the face-up {{color}}",
			hintClaim: "Claim {{a}}–{{b}} ({{color}}, {{n}} spaces)",
			hintDrawTickets: "Draw new tickets",
			hintKeepTickets: "Keep {{n}} tickets",
			errNotYourTurn: "Not your turn",
			errNotInPhase: "Not allowed right now",
			errBadPick: "Invalid ticket selection",
			errDeckEmpty: "The deck is empty",
			errLocoFirst: "A face-up locomotive must be your first draw",
			errRouteTaken: "Route already claimed",
			errDoubleSame: "You cannot claim both parallel routes",
			errDoubleClosed: "Only one parallel route in 2~3 player games",
			errBadColor: "Card color does not match the route",
			errCantPay: "Not enough cards to pay",
			errNoTrains: "Not enough trains left"
		}
	}
};
//#endregion
export { Qe as default };
