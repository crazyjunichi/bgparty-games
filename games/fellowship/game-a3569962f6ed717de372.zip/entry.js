import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { IconCheck as i, IconClose as a, IconWarning as o } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { OptionRadio as m, OptionSection as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/fellowship/cards.ts
var g = {
	s: "rings",
	v: 1
};
function _(e, t) {
	return e.s === t.s && e.v === t.v;
}
function v(e) {
	let t = [];
	for (let e of [
		"hills",
		"mountains",
		"shadows",
		"forests"
	]) for (let n = 1; n <= 8; n += 1) t.push({
		s: e,
		v: n
	});
	for (let e = 1; e <= 5; e += 1) t.push({
		s: "rings",
		v: e
	});
	for (let n = 1; n <= e; n += 1) t.push({
		s: "river",
		v: n
	});
	return t;
}
var ee = {
	witchking: "rings",
	terror: "hills"
}, y = {
	frodo: {
		id: "frodo",
		num: "1.02",
		goal: {
			k: "winCards",
			suits: ["rings"],
			min: 2
		}
	},
	frodo3: {
		id: "frodo3",
		num: "1.02.3",
		goal: {
			k: "winCards",
			suits: ["rings"],
			min: 4
		}
	},
	bilbo: {
		id: "bilbo",
		num: "1.03",
		goal: {
			k: "tricks",
			min: 3,
			max: 99
		}
	},
	gandalf: {
		id: "gandalf",
		num: "1.04",
		goal: {
			k: "tricks",
			min: 1,
			max: 99
		},
		setup: {
			takeLost: !0,
			exchange: ["frodo", "frodo3"]
		}
	},
	pippin: {
		id: "pippin",
		num: "1.05",
		goal: { k: "tricksLeast" },
		setup: { exchange: [
			"frodo",
			"frodo3",
			"sam",
			"merry"
		] }
	},
	sam: {
		id: "sam",
		num: "2.02",
		goal: {
			k: "threatCard",
			suits: ["hills"]
		},
		setup: {
			drawThreat: !0,
			exchange: [
				"frodo",
				"frodo3",
				"merry",
				"pippin"
			]
		}
	},
	merry: {
		id: "merry",
		num: "2.03",
		goal: {
			k: "tricks",
			min: 1,
			max: 2
		},
		setup: { exchange: [
			"frodo",
			"frodo3",
			"sam",
			"pippin"
		] }
	},
	gildor: {
		id: "gildor",
		num: "2.09",
		goal: {
			k: "lastTrickPlay",
			suits: ["forests"]
		},
		setup: { exchange: ["frodo", "frodo3"] }
	},
	maggot: {
		id: "maggot",
		num: "2.10",
		goal: {
			k: "threatCardAny",
			min: 2
		},
		setup: {
			drawThreat: !0,
			exchange: ["pippin", "merry"]
		}
	},
	fatty: {
		id: "fatty",
		num: "2.12",
		goal: {
			k: "tricks",
			min: 1,
			max: 1
		},
		setup: { giveEach: !0 }
	},
	tom: {
		id: "tom",
		num: "2.16",
		goal: {
			k: "lostSuitCards",
			min: 3
		},
		setup: {
			takeLost: !0,
			exchange: ["frodo", "frodo3"]
		}
	},
	goldberry: {
		id: "goldberry",
		num: "2.19",
		goal: {
			k: "consecutiveTricks",
			n: 3
		},
		setup: { openHand: !0 }
	},
	underhill: {
		id: "underhill",
		num: "2.21",
		goal: { k: "tricksWithRing" },
		setup: { leadFirst: !0 }
	},
	barliman: {
		id: "barliman",
		num: "2.22",
		goal: {
			k: "winInLastTricks",
			n: 3
		},
		setup: { exchange: "any" }
	},
	strider: {
		id: "strider",
		num: "2.24",
		goal: { k: "tricksVsThreat" },
		setup: {
			drawThreat: !0,
			threatDir: !0,
			exchange: ["frodo", "frodo3"]
		}
	},
	glorfindel: {
		id: "glorfindel",
		num: "2.28",
		goal: {
			k: "winAllOfSuit",
			suit: "shadows"
		},
		setup: {
			takeLost: !0,
			exchange: "all",
			leadFirst: !0
		}
	},
	bill: {
		id: "bill",
		num: "2.29",
		goal: {
			k: "tricks",
			min: 1,
			max: 1
		},
		setup: {
			exchange: [
				"sam",
				"frodo",
				"frodo3"
			],
			exchangeAll: !0
		}
	},
	elrond: {
		id: "elrond",
		num: "2.35",
		goal: { k: "allWinRing" },
		setup: {
			leadFirst: !0,
			passRight: !0
		}
	},
	arwen: {
		id: "arwen",
		num: "2.36",
		goal: {
			k: "mostCards",
			suit: "forests",
			exclusive: !0
		},
		setup: { exchange: ["elrond", "aragorn"] }
	},
	gloin: {
		id: "gloin",
		num: "2.37",
		goal: {
			k: "mostCards",
			suit: "mountains",
			exclusive: !1
		},
		setup: { exchange: [
			"bilbo",
			"bilbo2",
			"gimli"
		] }
	},
	bilbo2: {
		id: "bilbo2",
		num: "2.38",
		goal: {
			k: "tricks",
			min: 3,
			max: 99
		},
		failIf: "winRing1",
		setup: { directAfterWin: !0 }
	},
	aragorn: {
		id: "aragorn",
		num: "2.40",
		goal: { k: "tricksEqualThreat" },
		setup: {
			chooseThreat: !0,
			exchange: "any"
		}
	},
	boromir: {
		id: "boromir",
		num: "2.41",
		goal: { k: "winLastTrick" },
		failIf: "winRing1",
		setup: { exchange: "anyExceptFrodo" }
	},
	gwaihir: {
		id: "gwaihir",
		num: "2.46",
		goal: {
			k: "tricksWithSuit",
			suit: "mountains",
			min: 2
		},
		setup: {
			exchange: ["gandalf"],
			exchangeTimes: 2
		}
	},
	shadowfax: {
		id: "shadowfax",
		num: "2.47",
		goal: {
			k: "tricksWithSuit",
			suit: "hills",
			min: 2
		},
		setup: { tuck: !0 }
	},
	radagast: {
		id: "radagast",
		num: "2.48",
		goal: {
			k: "tricksWithSuit",
			suit: "forests",
			min: 2
		},
		setup: {
			asideLast: !0,
			preplay: !0
		}
	},
	legolas: {
		id: "legolas",
		num: "3.09/3.44",
		goal: {
			k: "threatCard",
			suits: ["forests"]
		},
		setup: {
			drawThreat: !0,
			exchange: [
				"gimli",
				"aragorn",
				"aragorn2",
				"aragorn2b"
			]
		}
	},
	gimli: {
		id: "gimli",
		num: "3.10/3.45",
		goal: {
			k: "threatCard",
			suits: ["mountains"]
		},
		setup: {
			drawThreat: !0,
			exchange: [
				"legolas",
				"aragorn",
				"aragorn2",
				"aragorn2b"
			]
		}
	},
	orophin: {
		id: "orophin",
		num: "3.21",
		goal: {
			k: "threatCard",
			suits: ["forests"]
		},
		setup: {
			drawThreat: !0,
			exchange: ["haldir"],
			leadFirst: !0
		}
	},
	haldir: {
		id: "haldir",
		num: "3.22",
		goal: {
			k: "threatCard",
			suits: ["forests"]
		},
		setup: {
			drawThreat: !0,
			exchange: "anyExceptGimli"
		}
	},
	galadriel: {
		id: "galadriel",
		num: "3.25",
		goal: { k: "tricksMiddle" },
		setup: {
			exchange: ["gandalf"],
			exchangeLost: !0
		}
	},
	celeborn: {
		id: "celeborn",
		num: "3.26",
		goal: {
			k: "sameValueCards",
			min: 3
		},
		setup: { exchange: "any" }
	},
	gandalf2: {
		id: "gandalf2",
		num: "3.17",
		goal: { k: "none" },
		setup: {
			takeLost: !0,
			ignoreSuit: !0
		}
	},
	sam2: {
		id: "sam2",
		num: "3.39",
		goal: {
			k: "threatCard",
			suits: ["hills"]
		},
		setup: {
			drawThreat: !0,
			exchange: [
				"frodo",
				"frodo3",
				"merry2",
				"pippin2"
			]
		}
	},
	sam2b: {
		id: "sam2b",
		num: "3.39.1",
		goal: {
			k: "threatCard",
			suits: ["hills", "shadows"]
		},
		setup: { drawThreat: !0 }
	},
	pippin2: {
		id: "pippin2",
		num: "3.40",
		goal: { k: "tricksLeast" },
		setup: { exchange: [
			"frodo",
			"frodo3",
			"sam2",
			"merry2"
		] }
	},
	pippin2b: {
		id: "pippin2b",
		num: "3.40.1",
		goal: { k: "zeroAndOthersWin" },
		setup: { exchange: "any" }
	},
	merry2: {
		id: "merry2",
		num: "3.41",
		goal: {
			k: "tricks",
			min: 1,
			max: 2
		},
		setup: { exchange: [
			"frodo",
			"frodo3",
			"sam2",
			"pippin2"
		] }
	},
	merry2b: {
		id: "merry2b",
		num: "3.41.1",
		goal: {
			k: "tricks",
			min: 2,
			max: 2
		},
		setup: {
			exchange: [
				"frodo",
				"frodo3",
				"sam2",
				"pippin2"
			],
			redrawAura: !0
		}
	},
	aragorn2: {
		id: "aragorn2",
		num: "3.42",
		goal: { k: "tricksEqualThreat" },
		setup: {
			chooseThreat: !0,
			exchange: "any"
		}
	},
	aragorn2b: {
		id: "aragorn2b",
		num: "3.42.1",
		goal: { k: "tricksEqualThreat" },
		setup: {
			chooseThreat: !0,
			chooseThreatTop: 2,
			exchange: "any"
		}
	},
	boromir2: {
		id: "boromir2",
		num: "3.43",
		goal: { k: "winLastTrick" },
		failIf: "winRing1",
		setup: { exchange: "anyExceptFrodo" }
	},
	boromir2b: {
		id: "boromir2b",
		num: "3.43.1",
		goal: { k: "winLastTrick" },
		failIf: "winAnyRing",
		setup: { exchange: "anyExceptFrodo" }
	},
	legolas2b: {
		id: "legolas2b",
		num: "3.44.1",
		goal: {
			k: "threatCard",
			suits: ["forests", "shadows"]
		},
		setup: {
			drawThreat: !0,
			exchange: [
				"gimli",
				"aragorn2",
				"aragorn2b"
			]
		}
	},
	gimli2b: {
		id: "gimli2b",
		num: "3.45.1",
		goal: {
			k: "threatCard",
			suits: ["mountains", "shadows"]
		},
		setup: {
			drawThreat: !0,
			exchange: [
				"legolas",
				"aragorn2",
				"aragorn2b"
			]
		}
	}
}, b = [
	"doors",
	"tomb",
	"dark",
	"bridge"
], x = [
	1,
	2,
	3,
	4
], S = [
	1,
	2,
	3,
	4,
	5,
	6,
	7
], C = (e, t = !1) => ({
	id: e,
	star: t
}), w = [
	{
		n: 1,
		characters: [
			C("frodo", !0),
			C("bilbo", !0),
			C("gandalf"),
			C("pippin")
		],
		threats: [],
		length: "short"
	},
	{
		n: 2,
		characters: [
			C("frodo", !0),
			C("sam", !0),
			C("merry", !0),
			C("gandalf"),
			C("pippin")
		],
		threats: x,
		length: "short"
	},
	{
		n: 3,
		characters: [
			C("frodo", !0),
			C("maggot", !0),
			C("gildor", !0),
			C("sam"),
			C("merry"),
			C("pippin")
		],
		threats: x,
		length: "short"
	},
	{
		n: 4,
		characters: [
			C("frodo", !0),
			C("fatty", !0),
			C("sam"),
			C("merry", !0),
			C("pippin")
		],
		threats: x,
		length: "short"
	},
	{
		n: 5,
		characters: [
			C("frodo", !0),
			C("tom", !0),
			C("goldberry", !0),
			C("sam"),
			C("merry"),
			C("pippin")
		],
		threats: x,
		length: "short",
		deal: {
			hand: [9, 7],
			lost: [2, 1],
			omw: !0
		}
	},
	{
		n: 6,
		characters: [
			C("frodo", !0),
			C("tom", !0),
			C("goldberry", !0),
			C("sam"),
			C("merry"),
			C("pippin")
		],
		threats: x,
		length: "short",
		deal: {
			hand: [9, 8],
			lost: [0, 0],
			barrow: 10
		}
	},
	{
		n: 7,
		characters: [
			C("underhill", !0),
			C("barliman", !0),
			C("sam"),
			C("merry"),
			C("pippin")
		],
		threats: x,
		length: "short"
	},
	{
		n: 8,
		characters: [
			C("frodo", !0),
			C("merry", !0),
			C("strider", !0),
			C("sam"),
			C("pippin"),
			C("barliman")
		],
		threats: x,
		length: "short",
		specialThreats: {
			frodo: "witchking",
			merry: "blackbreath"
		}
	},
	{
		n: 9,
		characters: [
			C("glorfindel", !0),
			C("frodo"),
			C("sam"),
			C("merry"),
			C("pippin"),
			C("strider"),
			C("bill")
		],
		threats: x,
		length: "long",
		specialThreats: {
			frodo: "witchking",
			merry: "blackbreath",
			pippin: "wraith",
			strider: "unseen",
			sam: "terror"
		}
	},
	{
		n: 10,
		characters: [
			C("elrond", !0),
			C("bilbo2", !0),
			C("gloin"),
			C("arwen"),
			C("gandalf")
		],
		threats: [],
		length: "short"
	},
	{
		n: 11,
		characters: [
			C("frodo", !0),
			C("aragorn", !0),
			C("boromir", !0),
			C("gloin"),
			C("bilbo2")
		],
		threats: [],
		length: "short",
		grants: { aragorn: { goal: { k: "tricksRangeThreat" } } },
		horn: !0
	},
	{
		n: 12,
		characters: [
			C("gandalf", !0),
			C("radagast"),
			C("shadowfax"),
			C("gwaihir")
		],
		threats: [],
		length: "short",
		grants: { gandalf: {
			leadFirst: !0,
			extraGoal: { k: "winEachRank" }
		} }
	},
	{
		n: 13,
		characters: [
			C("frodo", !0),
			C("gandalf"),
			C("aragorn"),
			C("legolas"),
			C("gimli"),
			C("boromir"),
			C("sam"),
			C("merry"),
			C("pippin"),
			C("bill")
		],
		threats: S,
		length: "long",
		skipComplete: ["bill"],
		mithril: !0
	},
	{
		n: 14,
		characters: [
			C("frodo", !0),
			C("gandalf"),
			C("aragorn"),
			C("legolas"),
			C("gimli"),
			C("boromir"),
			C("sam"),
			C("merry"),
			C("pippin")
		],
		threats: S,
		length: "long",
		mithril: !0,
		moria: !0
	},
	{
		n: 15,
		characters: [
			C("gimli", !0),
			C("haldir", !0),
			C("orophin", !0),
			C("legolas")
		],
		threats: S,
		length: "short",
		blindfolded: "gimli"
	},
	{
		n: 16,
		characters: [
			C("frodo", !0),
			C("galadriel", !0),
			C("celeborn", !0),
			C("sam")
		],
		threats: S,
		length: "short",
		mirror: !0
	},
	{
		n: 17,
		characters: [
			C("frodo", !0),
			C("aragorn"),
			C("legolas"),
			C("gimli"),
			C("boromir"),
			C("sam"),
			C("merry"),
			C("pippin"),
			C("galadriel"),
			C("celeborn")
		],
		threats: S,
		length: "long",
		skipComplete: ["celeborn"],
		mithril: !0,
		deal: {
			hand: [14, 11],
			lost: [1, 1]
		},
		river: {
			count: [6, 8],
			wins: !0
		}
	},
	{
		n: 18,
		characters: [
			C("frodo", !0),
			C("boromir2b", !0),
			C("sam2"),
			C("aragorn2"),
			C("merry2b", !0),
			C("pippin2b", !0),
			C("legolas"),
			C("gimli")
		],
		threats: S,
		length: "special",
		breakingGroups: [[
			"frodo",
			"boromir2b",
			"sam2",
			"aragorn2"
		], [
			"merry2b",
			"pippin2b",
			"legolas",
			"gimli"
		]],
		maxRounds: 2,
		deal: {
			hand: [14, 11],
			lost: [1, 1]
		},
		river: {
			count: [6, 8],
			wins: !1
		}
	}
];
function te(e) {
	let t = w.find((t) => t.n === e);
	if (!t) throw Error(`unknown chapter ${e}`);
	return t;
}
function T(e, t) {
	return e === "frodo" && t < 4 ? "frodo3" : e;
}
var E = w.filter((e) => !e.wip).map((e) => e.n), D = [
	["sam2", "sam2b"],
	["pippin2", "pippin2b"],
	["merry2", "merry2b"],
	["aragorn2", "aragorn2b"],
	["boromir2", "boromir2b"],
	["legolas", "legolas2b"],
	["gimli", "gimli2b"]
], ne = /* @__PURE__ */ "bilbo.gandalf.pippin.sam.merry.gildor.maggot.fatty.tom.goldberry.underhill.barliman.strider.glorfindel.bill.elrond.arwen.gloin.bilbo2.aragorn.boromir.gwaihir.shadowfax.radagast.orophin.haldir.galadriel.celeborn".split("."), re = [
	{
		kind: "mithril",
		targets: ["frodo", "frodo3"]
	},
	{
		kind: "sting",
		targets: ["frodo", "frodo3"]
	},
	{
		kind: "glamdring",
		targets: ["gandalf"]
	},
	{
		kind: "sword",
		targets: [
			"aragorn",
			"aragorn2",
			"aragorn2b"
		]
	},
	{
		kind: "horn",
		targets: [
			"boromir",
			"boromir2",
			"boromir2b"
		]
	}
], O = t.enum([
	"hills",
	"mountains",
	"shadows",
	"forests",
	"rings",
	"river"
]), k = t.object({
	s: O,
	v: t.int().min(1).max(8)
}), ie = t.enum([
	"doors",
	"tomb",
	"dark",
	"bridge"
]), ae = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		character: t.string()
	}),
	t.object({
		type: t.literal("pickGroup"),
		group: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("pickEvent"),
		event: ie
	}),
	t.object({
		type: t.literal("give"),
		to: t.int().min(0),
		card: k
	}),
	t.object({
		type: t.literal("offer"),
		to: t.int().min(0),
		card: k
	}),
	t.object({
		type: t.literal("back"),
		card: k
	}),
	t.object({
		type: t.literal("exchangeLost"),
		give: k,
		take: k
	}),
	t.object({
		type: t.literal("threatDir"),
		dir: t.enum(["more", "less"])
	}),
	t.object({
		type: t.literal("chooseThreat"),
		value: t.int().min(1).max(7)
	}),
	t.object({
		type: t.literal("redraw"),
		again: t.boolean()
	}),
	t.object({
		type: t.literal("pass"),
		card: k
	}),
	t.object({
		type: t.literal("tuck"),
		card: k
	}),
	t.object({
		type: t.literal("aside"),
		card: k
	}),
	t.object({
		type: t.literal("preplay"),
		card: k
	}),
	t.object({
		type: t.literal("direct"),
		seat: t.int().min(0)
	}),
	t.object({ type: t.literal("skipSetup") }),
	t.object({
		type: t.literal("play"),
		card: k,
		declare: t.boolean().optional()
	}),
	t.object({ type: t.literal("nextRound") }),
	t.object({ type: t.literal("retry") })
]), A = t.object({ chapter: t.int().min(0).max(18).catch(1) }).default({ chapter: 1 }), oe = t.string(), j = t.enum([
	"witchking",
	"blackbreath",
	"wraith",
	"unseen",
	"terror"
]), se = t.object({
	card: k.nullable(),
	faceUp: t.boolean(),
	covered: t.boolean(),
	pad: t.boolean()
}), ce = t.object({
	seat: t.int().min(0),
	owner: oe,
	character: t.string().nullable(),
	handCount: t.int().nonnegative(),
	openHand: t.array(k).nullable(),
	wonCount: t.int().nonnegative(),
	threat: t.int().min(1).max(7).nullable(),
	threatDir: t.enum(["more", "less"]).nullable(),
	special: j.nullable(),
	hornSuits: t.array(O).nullable(),
	aside: k.nullable(),
	tuckedCount: t.int().min(0).max(1),
	blind: t.boolean(),
	pyramid: t.array(se).nullable(),
	goal: t.enum([
		"done",
		"failed",
		"pending"
	])
}), M = t.array(t.object({
	seat: t.int().min(0),
	card: k,
	declare: t.boolean(),
	blind: t.boolean().optional()
})), le = t.object({
	kind: t.enum([
		"give",
		"exchangeOffer",
		"exchangeBack",
		"exchangeLost",
		"threatDir",
		"chooseThreat",
		"redraw",
		"pass",
		"tuck",
		"aside",
		"preplay"
	]),
	seat: t.int().min(0),
	from: t.int().min(0).optional(),
	candidates: t.array(t.int().min(0)).optional(),
	values: t.array(t.int()).optional(),
	lostOptions: t.array(k).optional(),
	pending: t.array(t.int().min(0)).optional()
}), N = t.object({
	s: O,
	v: t.int().min(1).max(9)
}), ue = t.object({
	phase: t.enum([
		"choose",
		"moriaPick",
		"setup",
		"play",
		"roundEnd",
		"won",
		"lost"
	]),
	chapter: t.int().min(0).max(18),
	round: t.int().min(1),
	length: t.enum([
		"short",
		"long",
		"special"
	]),
	mode: t.enum([
		"standard",
		"pyramid",
		"solo"
	]),
	seats: t.array(ce),
	chooser: t.int().min(0).nullable(),
	available: t.array(t.object({
		id: t.string(),
		star: t.boolean()
	})),
	breaking: t.object({
		groups: t.array(t.array(t.string())),
		picked: t.int().min(0).nullable()
	}).nullable(),
	moria: t.object({
		done: t.array(ie),
		current: ie.nullable(),
		picker: t.int().min(0).nullable()
	}).nullable(),
	setupStep: le.nullable(),
	trick: t.object({
		leader: t.int().min(0),
		plays: M
	}),
	turn: t.int().min(0).nullable(),
	pendingDirect: t.int().min(0).nullable(),
	lastTrick: t.object({
		plays: M,
		winner: t.int().min(-1),
		balrog: t.object({
			cards: t.array(N),
			sum: t.int().nonnegative()
		}).nullable()
	}).nullable(),
	tricksPlayed: t.int().nonnegative(),
	totalTricks: t.int().min(1).nullable(),
	lostCards: t.array(k),
	omw: t.object({
		remaining: t.int().nonnegative(),
		up: N.nullable(),
		pot: t.int().nonnegative()
	}).nullable(),
	balrog: t.object({ remaining: t.int().nonnegative() }).nullable(),
	drawPile: t.int().nonnegative().nullable(),
	broken: t.boolean(),
	gift: t.enum([
		"mithril",
		"sting",
		"glamdring",
		"sword",
		"horn"
	]).nullable(),
	mithrilUsed: t.boolean(),
	completed: t.array(t.string()),
	failedSeat: t.int().min(0).nullable()
}), de = t.object({
	hand: t.array(k),
	mySeats: t.array(t.int().min(0)),
	mustFollow: O.nullable(),
	canDeclareRing: t.boolean(),
	exchangeReceived: t.array(k),
	tucked: k.nullable()
}), P = (e) => e.won.flat();
function F(e) {
	return e.tricks.flatMap((e) => e.plays.map((e) => e.card));
}
function I(e, t) {
	return e === "rings" ? 5 : e === "river" ? t ? 8 : 0 : 8;
}
function L(e, t) {
	return +(e <= 5) + 4 + (t && e <= 8 ? 1 : 0);
}
function fe(e, t) {
	let n = new Set(e);
	for (let e of n) {
		let r = !0;
		for (let i = 0; i < t; i += 1) n.has(e + i) || (r = !1);
		if (r) return !0;
	}
	return !1;
}
function R(e, t) {
	let n = t.seats[e], r = [n.goal, ...n.extraGoals].map((n) => pe(n, e, t));
	return r.includes("failed") ? "failed" : r.every((e) => e === "done") ? "done" : "pending";
}
function pe(e, t, n) {
	let r = n.seats[t], i = n.seats.filter((e, n) => n !== t), a = r.won.length, o = P(r), s = n.tricksLeftOverride ?? n.totalTricks - n.tricks.length;
	switch (e.k) {
		case "none": return "done";
		case "winCards": {
			let t = o.filter((t) => e.suits.includes(t.s)).length;
			if (t >= e.min) return "done";
			let r = F(n).filter((t) => e.suits.includes(t.s)).length;
			return t + (e.suits.reduce((e, t) => e + I(t, n.withRiver), 0) - r) < e.min ? "failed" : "pending";
		}
		case "winAllOfSuit": return o.filter((t) => t.s === e.suit).length >= I(e.suit, n.withRiver) ? "done" : i.some((t) => P(t).some((t) => t.s === e.suit)) ? "failed" : "pending";
		case "tricks": return a > e.max ? "failed" : a >= e.min && a <= e.max && n.roundOver || e.max >= 99 && a >= e.min ? "done" : a + s < e.min ? "failed" : "pending";
		case "tricksLeast": return n.roundOver ? a <= Math.min(...i.map((e) => e.won.length)) ? "done" : "failed" : i.some((e) => e.won.length < a) ? "failed" : "pending";
		case "tricksMiddle": {
			if (n.roundOver) {
				let e = n.seats.map((e) => e.won.length), t = Math.max(...e), r = Math.min(...e), i = e.filter((e) => e === a).length;
				return a < t && a > r && i === 1 ? "done" : "failed";
			}
			let e = Math.max(...i.map((e) => e.won.length)), t = Math.min(...i.map((e) => e.won.length));
			return a > e || a < t ? "failed" : "pending";
		}
		case "threatCard": return r.threat === null ? "pending" : o.some((t) => e.suits.includes(t.s) && t.v === r.threat) ? "done" : i.some((t) => P(t).some((t) => e.suits.includes(t.s) && t.v === r.threat)) ? "failed" : "pending";
		case "threatCardAny": {
			if (r.threat === null) return "pending";
			let t = o.filter((e) => e.v === r.threat).length;
			if (t >= e.min) return "done";
			let i = F(n).filter((e) => e.v === r.threat).length;
			return t + (L(r.threat, n.withRiver) - i) < e.min ? "failed" : "pending";
		}
		case "tricksEqualThreat": return r.threat === null ? "pending" : a > r.threat ? "failed" : a === r.threat && n.roundOver ? "done" : a + s < r.threat ? "failed" : "pending";
		case "tricksRangeThreat": return r.threat === null ? "pending" : a > r.threat + 1 ? "failed" : n.roundOver ? a >= r.threat ? "done" : "failed" : a + s < r.threat ? "failed" : "pending";
		case "tricksVsThreat": return r.threat === null || r.threatDir === null ? "pending" : r.threatDir === "more" ? a > r.threat ? "done" : a + s <= r.threat ? "failed" : "pending" : a >= r.threat ? "failed" : n.roundOver ? "done" : "pending";
		case "lastTrickPlay": {
			let i = n.tricks[n.tricks.length - 1];
			if (n.roundOver && i) {
				let n = i.plays.find((e) => e.seat === t);
				return n && e.suits.includes(n.card.s) ? "done" : "failed";
			}
			return n.slidingWindow || r.hand.some((t) => e.suits.includes(t.s)) ? "pending" : "failed";
		}
		case "winLastTrick": {
			if (!n.roundOver) return "pending";
			let e = n.tricks[n.tricks.length - 1];
			return e && e.winner === t ? "done" : "failed";
		}
		case "winInLastTricks": {
			if (n.slidingWindow && !n.roundOver) return "pending";
			let r = (n.slidingWindow ? n.tricks.length : n.totalTricks) - e.n;
			return n.tricks.length > r && n.tricks.slice(r).some((e) => e.winner === t) ? "done" : n.roundOver ? "failed" : "pending";
		}
		case "tricksWithRing": return r.won.some((e) => !e.some((e) => e.s === "rings")) ? "failed" : n.roundOver ? a >= 1 ? "done" : "failed" : "pending";
		case "consecutiveTricks": {
			if (a > e.n) return "failed";
			let r = 0, i = 0;
			for (let e of n.tricks) r = e.winner === t ? r + 1 : 0, i = Math.max(i, r);
			return i > e.n ? "failed" : n.roundOver ? a === e.n && i === e.n ? "done" : "failed" : "pending";
		}
		case "lostSuitCards": {
			let t = [...new Set(r.hand.map((e) => e.s))];
			if (n.roundOver) return t.some((t) => o.filter((e) => e.s === t).length >= e.min) ? "done" : "failed";
			if (t.some((t) => o.filter((e) => e.s === t).length >= e.min)) return "done";
			let i = F(n), a = t.every((t) => o.filter((e) => e.s === t).length + (I(t, n.withRiver) - i.filter((e) => e.s === t).length) < e.min);
			return t.length === 0 || a ? "failed" : "pending";
		}
		case "mostCards": {
			let t = (t) => P(t).filter((t) => t.s === e.suit).length, a = t(r);
			if (n.roundOver) return i.every((n) => e.exclusive ? t(n) < a : t(n) <= a) ? "done" : "failed";
			let o = F(n).filter((t) => t.s === e.suit).length, s = a + (I(e.suit, n.withRiver) - o), c = Math.max(...i.map(t));
			return e.exclusive ? s <= c ? "failed" : "pending" : s < c ? "failed" : "pending";
		}
		case "sameValueCards": {
			let t = /* @__PURE__ */ new Map();
			for (let e of o) t.set(e.v, (t.get(e.v) ?? 0) + 1);
			if ([...t.values()].some((t) => t >= e.min)) return "done";
			let r = F(n);
			return [
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].every((i) => {
				let a = L(i, n.withRiver) - r.filter((e) => e.v === i).length;
				return (t.get(i) ?? 0) + a < e.min;
			}) ? "failed" : "pending";
		}
		case "tricksWithSuit": {
			let t = r.won.filter((t) => t.some((t) => t.s === e.suit)).length;
			return t >= e.min ? "done" : t + s < e.min ? "failed" : "pending";
		}
		case "allWinRing": return n.seats.filter((e) => !P(e).some((e) => e.s === "rings")).length === 0 ? "done" : 5 - F(n).filter((e) => e.s === "rings").length <= 0 ? "failed" : "pending";
		case "zeroAndOthersWin": return a > 0 ? "failed" : n.roundOver ? i.every((e) => e.won.length >= 1) ? "done" : "failed" : "pending";
		case "consecutiveValues": {
			let t = o.filter((t) => t.s === e.suit).map((e) => e.v);
			if (fe(t, e.n)) return "done";
			let r = F(n).filter((t) => t.s === e.suit).map((e) => e.v), i = [...t];
			for (let e = 1; e <= 8; e += 1) !r.includes(e) && !i.includes(e) && i.push(e);
			return fe(i, e.n) ? "pending" : "failed";
		}
		case "winEachSuit": {
			let t = e.suits.filter((e) => !o.some((t) => t.s === e));
			if (t.length === 0) return "done";
			let r = F(n);
			return t.some((e) => r.filter((t) => t.s === e).length >= I(e, n.withRiver)) ? "failed" : "pending";
		}
		case "winEachRank": {
			let e = new Set(o.map((e) => e.v));
			if ([
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].every((t) => e.has(t))) return "done";
			let t = F(n);
			return [
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			].some((r) => !e.has(r) && t.filter((e) => e.v === r).length >= L(r, n.withRiver)) ? "failed" : "pending";
		}
		case "noWinValue": return o.some((t) => t.v === e.v) ? "failed" : n.roundOver ? "done" : "pending";
	}
}
function me(e) {
	let t = e.failIf;
	if (!t) return !1;
	let n = P(e);
	return t === "winRing1" ? n.some((e) => e.s === "rings" && e.v === 1) : n.some((e) => e.s === "rings");
}
//#endregion
//#region src/games/fellowship/meta.ts
var z = {
	id: "fellowship",
	tier: "alpha",
	mechanics: ["trick-taking"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.fellowship.name",
	descKey: "games.fellowship.desc",
	rulesKey: "games.fellowship.rules",
	icon: "💍",
	iconImg: "games/fellowship.webp",
	rulesUrl: { en: "https://cdn.svc.asmodee.net/production-officedog/uploads/2024/11/ODLO01_Rulebook.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#a16207",
	releasedAt: "2026-09-25",
	search: {
		py: "mo jie tong meng",
		init: "mjtm"
	},
	hotseat: "cover"
}, he = {
	s: "forests",
	v: 9
}, ge = {
	s: "shadows",
	v: 5
}, B = 2, V = (e) => ({ code: e });
function H(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var _e = (e) => e === "frodo" || e === "frodo3";
function ve(e) {
	return Math.floor(36 / e);
}
function U(e) {
	return e.mode === "standard" ? e.seats.length : 3;
}
function W(e) {
	return e.chapter !== 0 || !e.road ? te(e.chapter) : {
		n: 0,
		characters: [{
			id: "frodo",
			star: !0
		}, ...e.road.pool.map((e) => ({
			id: e,
			star: !1
		}))],
		threats: [
			1,
			2,
			3,
			4,
			5,
			6,
			7
		],
		length: "long"
	};
}
var ye = (e) => W(e).mithril === !0 || e.road?.gift?.kind === "mithril", be = (e) => ye(e) && !e.mithrilUsed;
function G(e) {
	return e.seats.findIndex((e) => e.hand.some((e) => _(e, g)) || (e.pyramid ?? []).some((e) => e.card !== null && _(e.card, g)));
}
function xe(e) {
	let t = G(e), n = e.seats.length, r = [];
	for (let e = 1; e <= n; e += 1) r.push((t + e) % n);
	return r;
}
function Se(e) {
	return e >= 14 ? [
		2,
		3,
		4,
		5
	] : e <= 9 ? [
		2,
		3,
		4
	] : [
		3,
		4,
		5
	];
}
function Ce(e, t) {
	let n = [], r = 0;
	for (let i = 0; i < t.length; i += 1) for (let a = 0; a < t[i]; a += 1) {
		let o;
		o = i === t.length - 1 ? !0 : i === t.length - 2 || t.length === 4 && i === 0 ? !1 : a === 0 || a === t[i] - 1, n.push({
			card: e[r],
			faceUp: o
		}), r += 1;
	}
	return n;
}
function we(e, t, n) {
	let r = e.seats[t].pyramid;
	if (!r) return !1;
	let i = e.pyramidRows, a = n;
	for (let e = 0; e < i.length; e += 1) {
		if (a < i[e]) {
			if (e === i.length - 1) return !1;
			let t = i.slice(0, e + 1).reduce((e, t) => e + t, 0);
			return !!r[t + a]?.card || !!r[t + a + 1]?.card;
		}
		a -= i[e];
	}
	return !1;
}
function Te(e) {
	let t = e.pyramidRows;
	return t.slice(0, t.length - 1).reduce((e, t) => e + t, 0);
}
function K(e, t, n) {
	let r = e.seats[t];
	if (r.pyramid) {
		let t = Te(e);
		for (let e = t; e < r.pyramid.length; e += 1) {
			let t = r.pyramid[e];
			if (t.card && !t.pad && _(t.card, n)) return t.card = null, !0;
		}
		return !1;
	}
	let i = r.hand.findIndex((e) => _(e, n));
	return i < 0 ? !1 : (r.hand.splice(i, 1), !0);
}
function q(e, t, n, r) {
	let i = e.seats[t];
	if (i.pyramid) {
		i.pyramid.push({
			card: n,
			faceUp: !0,
			pad: r
		});
		return;
	}
	i.hand.push(n);
}
function Ee(e, t) {
	e.mode === "solo" && e.soloExchangeSeat === -1 && (e.soloExchangeSeat = t, e.setupQueue = e.setupQueue.filter((n, r) => r <= e.setupIdx || n.kind !== "exchange" && n.kind !== "exchangeLost" || n.seat === t));
}
function De(e, t) {
	let n = y[e.seats[t].character ?? ""];
	n?.setup?.exchange && n.setup.exchangeLost && (e.setupQueue = e.setupQueue.filter((n, r) => r <= e.setupIdx || n.kind !== "exchange" && n.kind !== "exchangeLost" || n.seat !== t));
}
function Oe(e, t) {
	let n = e.seats[t], r = [];
	if (n.pyramid) for (let i = 0; i < n.pyramid.length; i += 1) {
		let a = n.pyramid[i];
		a.card && a.faceUp && !a.pad && !we(e, t, i) && r.push(a.card);
	}
	else n.hand.length > n.padding && r.push(...n.hand);
	return n.tucked && r.push(n.tucked), n.aside && Ae(e, t) && r.push(n.aside), r;
}
var J = (e, t) => Oe(e, t).length > 0, ke = (e) => e.seats.filter((t, n) => J(e, n)).length;
function Ae(e, t) {
	if (e.mode === "solo") {
		let n = e.seats[t];
		return e.drawPile.length === 0 && n.hand.length <= n.padding && !n.tucked;
	}
	return e.tricks.length === e.totalTricks - 1;
}
function je(e, t, n) {
	let r = e.seats[t];
	if (r.pyramid) {
		let i = r.pyramid.findIndex((r, i) => r.card !== null && _(r.card, n) && r.faceUp && !r.pad && !we(e, t, i));
		if (i >= 0) {
			r.pyramid[i].card = null;
			return;
		}
	}
	if (r.tucked && _(r.tucked, n)) {
		r.tucked = null;
		return;
	}
	if (r.aside && _(r.aside, n)) {
		r.aside = null;
		return;
	}
	let i = r.hand.findIndex((e) => _(e, n));
	i >= 0 && r.hand.splice(i, 1);
}
function Me(e, t) {
	let n = e.seats.length;
	for (let r = 0; r < n; r += 1) {
		let i = (t + r) % n;
		if (J(e, i) && !e.trick.plays.some((e) => e.seat === i)) return i;
	}
	return t;
}
function Ne(e, t) {
	let n = e.seats.length;
	for (let r = 0; r < n; r += 1) {
		let i = (t + r) % n;
		if (J(e, i)) return i;
	}
	return t;
}
function Pe(e, t) {
	let n = Ne(e, t);
	if (e.trick = {
		leader: n,
		plays: [],
		active: 0
	}, e.omwDeck.length > 0 && (e.omwUp = e.omwDeck.shift() ?? null), e.balrogDeck.length > 0 || e.balrogDisc.length > 0) {
		let t = e.seats.length === 3 ? 2 : 3;
		e.balrogUp = [];
		for (let n = 0; n < t && (e.balrogDeck.length === 0 && (e.balrogDeck = H(e, e.balrogDisc), e.balrogDisc = []), e.balrogDeck.length !== 0); n += 1) e.balrogUp.push(e.balrogDeck.shift());
	}
	e.lastBalrog = null, e.trick.active = ke(e), e.turn = n;
}
function Fe(e, t) {
	let n = e.seats[t], r = y[n.character ?? ""], i = e.threatDeck.shift() ?? 0, a = r?.goal;
	a?.k === "threatCard" && e.lostCards.some((e) => e.v === i && a.suits.includes(e.s)) && (e.threatDeck.push(i), i = e.threatDeck.shift() ?? i), n.threat = i;
}
function Ie(t) {
	let n = U(t), r = t.mode === "solo" || t.players.length >= 4, i = r ? 5 : 4, a = r ? 6 : 3, o = H(t, [...D]).slice(0, i), s = e(t.seed, t.rngCursor, i);
	t.rngCursor += 1;
	let c = o.map((e, t) => t === s ? e[1] : e[0]), l = H(t, [...ne]).slice(0, a), u = [...c, ...l], d = [T("frodo", n), ...u], f = re.filter((e) => e.targets.some((e) => d.includes(T(e, n)))), p = f[e(t.seed, t.rngCursor, f.length)];
	t.rngCursor += 1;
	let m = p.targets.map((e) => T(e, n)).find((e) => d.includes(e)), h = [
		"witchking",
		"blackbreath",
		"wraith",
		"unseen",
		"terror"
	], g = h[e(t.seed, t.rngCursor, h.length)];
	t.rngCursor += 1;
	let _ = new Set(D.map((e) => e[1])), v = u.filter((e) => !_.has(e));
	if (g === "unseen") {
		let e = v.filter((e) => {
			let t = y[e]?.setup;
			return t?.drawThreat === !0 || t?.chooseThreat === !0;
		});
		e.length > 0 && (v = e);
	}
	let ee = v[e(t.seed, t.rngCursor, v.length)];
	t.rngCursor += 1, t.road = {
		pool: u,
		gift: {
			kind: p.kind,
			char: m
		},
		special: {
			char: ee,
			sp: g
		}
	};
}
function Le(t) {
	let n = W(t), r = t.seats.length, i = U(t), a = t.mode === "solo", o = n.moria === !0 && t.moriaCurrent === "bridge", s = r === 3 ? 0 : 1, c, l;
	a ? (c = 4, l = 0) : o ? (c = r === 3 ? 9 : 7, l = r === 3 ? 2 : 1) : n.deal ? (c = n.deal.hand[s], l = n.deal.lost[s]) : (c = ve(r), l = 1);
	let u = n.river ? n.river.count[a ? 1 : s] : 0;
	t.riverCount = u, t.riverWins = n.river?.wins ?? !1;
	let d, f, p, m, h, ee = [], y = [];
	for (;;) {
		p = [], m = [], h = [];
		let i = v(u);
		if (n.deal?.omw) {
			let e = i.filter((e) => e.s === "forests");
			i = i.filter((e) => e.s !== "forests"), p = H(t, [...e, he]);
		}
		if (o) {
			let e = i.filter((e) => e.s === "shadows");
			i = i.filter((e) => e.s !== "shadows"), h = H(t, [...e, ge]);
		}
		if (i = H(t, i), n.deal?.barrow) {
			let e = i.filter((e) => e.s === "rings"), o = H(t, i.filter((e) => e.s !== "rings")), s = a || r === 4 ? 5 : n.deal.barrow;
			m = o.slice(0, s), i = H(t, [...o.slice(s), ...e]);
		}
		if (a) {
			let a = n.n === 5 ? 12 : n.n === 6 ? 16 : o ? 12 : n.river ? 28 : 21, s = i.length - 15 - a, l = e(t.seed, t.rngCursor, r);
			t.rngCursor += 1;
			let u = i.filter((e) => !_(e, g));
			d = [];
			let p = 0;
			for (let e = 0; e < r; e += 1) {
				let t = e === l ? c - 1 : c;
				d.push(u.slice(p, p + t)), p += t;
			}
			d[l].push(g), f = u.slice(p, p + s), ee = u.slice(p + s);
			break;
		}
		if (f = i.slice(r * c, r * c + l), !f.some((e) => _(e, g))) {
			if (n.mirror) {
				d = [];
				let e = 0;
				for (let n = 0; n < r; n += 1) {
					let r = t.mode === "pyramid" && n === B ? c : 4;
					d.push(i.slice(e, e + r)), e += r;
				}
				if (y = i.slice(e, r * c), y.some((e) => _(e, g))) continue;
			} else {
				d = [];
				for (let e = 0; e < r; e += 1) d.push(i.slice(e * c, (e + 1) * c));
			}
			break;
		}
	}
	for (let e = 0; e < r; e += 1) {
		let n = t.seats[e];
		n.hand = d[e], n.won = [], n.threat = null, n.threatDir = null, n.padding = 0, n.character = null, n.special = null, n.goalOverride = null, n.extraGoals = [], n.grantLeadFirst = !1, n.hornSuits = null, n.tucked = null, n.aside = null, n.preplayed = null, n.pyramid = null, n.noDraw = !1, n.glamdring = !1;
	}
	if (t.mode === "pyramid") {
		let e = d[B];
		t.pyramidRows = Se(e.length);
		let n = e.some((e) => _(e, g)), i = d.findIndex((e) => e.some((e) => _(e, g)));
		t.seats[B].owner = n ? t.seats[(1 + r) % r].owner : t.seats[i].owner, t.seats[B].pyramid = Ce(e, t.pyramidRows), t.seats[B].hand = [];
	} else t.pyramidRows = [];
	t.lostCards = f, t.lostTaken = !1, t.barrowDeck = m, t.outOfPlay = [], t.omwDeck = p, t.omwUp = null, t.omwPot = [], t.balrogDeck = h, t.balrogDisc = [], t.balrogUp = [], t.lastBalrog = null, t.drawPile = ee, t.mirrorDeck = y, t.darkRound = n.moria === !0 && t.moriaCurrent === "dark" && !a, t.breakingGroup = null, t.mithrilSeat = null, t.soloExchangeSeat = -1, t.broken = !1, t.tricks = [], t.lastTrick = null, t.trick = {
		leader: 0,
		plays: [],
		active: 0
	}, t.turn = 0, t.totalTricks = c, t.failedSeat = null, t.setupQueue = [], t.setupIdx = 0, t.pendingExchanges = [], t.pendingPasses = [], t.pendingDirect = null, t.threatDeck = [];
	let b = n.characters.map((e) => ({
		id: T(e.id, i),
		star: e.star
	}));
	if (n.moria && t.moriaCurrent) {
		if (t.moriaCurrent === "bridge") b = b.filter((e) => e.id !== "gandalf"), b.push({
			id: "gandalf2",
			star: !0
		});
		else {
			let e = {
				doors: "gandalf",
				tomb: "gimli",
				dark: "aragorn"
			}, n = b.find((n) => n.id === e[t.moriaCurrent]);
			n && (n.star = !0);
		}
	}
	let x = G(t);
	if (n.moria && t.moriaCurrent === null) {
		t.chooseOrder = [], t.chooseIdx = 0, t.moriaPickerSeat = x, t.phase = "moriaPick";
		return;
	}
	if (n.mirror) {
		let e = b;
		r <= 3 && (e = e.filter((e) => e.id !== "sam"));
		let n = H(t, e.map((e) => e.id));
		if (a) {
			t.seats[x].character = T("frodo", i);
			let e = n.filter((e) => !_e(e)), a = 0;
			for (let n = 0; n < r; n += 1) n !== x && (t.seats[n].character = e[a], a += 1);
		} else for (let e = 0; e < r; e += 1) t.seats[e].character = n[e];
		t.available = [], t.chooseOrder = [], t.chooseIdx = 0;
	} else {
		let e = n.breakingGroups ? void 0 : b.find((e) => _e(e.id));
		e ? (t.seats[x].character = e.id, t.available = b.filter((t) => t.id !== e.id)) : t.available = b, t.chooseOrder = n.breakingGroups ? [x, ...xe(t).slice(0, r - 1)] : xe(t).filter((e) => !t.seats[e].character), t.chooseIdx = 0;
	}
	t.chooseOrder.length === 0 ? Be(t) : t.phase = "choose";
}
function Re(e, t, n) {
	let r = e.seats.map((e, t) => t).filter((n) => n !== t && e.seats[n].special !== "wraith");
	return n === "any" || n === "all" ? r : n === "anyExceptFrodo" ? r.filter((t) => !_e(e.seats[t].character)) : n === "anyExceptGimli" ? r.filter((t) => e.seats[t].character !== "gimli") : r.filter((t) => n.includes(e.seats[t].character ?? ""));
}
function ze(e, t) {
	if (e.road && e.seats[t].character === e.road.special.char) return e.road.special.sp;
	let n = W(e);
	if (!n.specialThreats) return null;
	let r = U(e);
	for (let [i, a] of Object.entries(n.specialThreats)) if (T(i, r) === e.seats[t].character) return a;
	return null;
}
function Be(e) {
	let t = W(e), n = e.seats.length, r = e.mode === "solo";
	for (let t = 0; t < n; t += 1) {
		let n = e.seats[t];
		if (y[n.character ?? ""]?.setup?.takeLost && e.lostCards.length > 0 && !e.lostTaken) {
			for (let n of e.lostCards) q(e, t, n, !0);
			n.pyramid || (n.padding += e.lostCards.length), e.lostTaken = !0;
		}
	}
	if (e.barrowDeck.length > 0) {
		let t = e.seats.findIndex((e) => e.character === "tom");
		if (t >= 0) {
			let n = e.barrowDeck.splice(0, 5);
			for (let r of n) q(e, t, r, !0);
			e.seats[t].pyramid || (e.seats[t].padding += n.length);
		}
		e.outOfPlay.push(...e.barrowDeck), e.barrowDeck = [];
	}
	if (r) {
		if (t.n === 4) {
			let t = e.seats.findIndex((e) => e.character === "fatty");
			t >= 0 && (e.seats[t].hand.push(...e.drawPile.splice(0, 5)), e.seats[t].noDraw = !0);
		}
		if (t.n === 6) {
			let t = e.seats.findIndex((e) => e.character === "goldberry");
			t >= 0 && (e.seats[t].hand.push(...e.drawPile.splice(0, 4)), e.seats[t].noDraw = !0);
		}
	}
	if (e.mode === "pyramid" && e.seats[B].character === "goldberry") for (let t of e.seats[B].pyramid ?? []) t.faceUp = !0;
	for (let t = 0; t < n; t += 1) {
		let n = ze(e, t);
		n && (e.seats[t].special = n, n === "blackbreath" && e.seats[t].extraGoals.push({
			k: "noWinValue",
			v: 8
		}));
	}
	if (t.grants) for (let [n, r] of Object.entries(t.grants)) {
		let t = e.seats.findIndex((t) => t.character === T(n, U(e)));
		t < 0 || (r.goal && (e.seats[t].goalOverride = r.goal), r.extraGoal && e.seats[t].extraGoals.push(r.extraGoal), r.leadFirst && (e.seats[t].grantLeadFirst = !0));
	}
	if (e.road?.gift) {
		let t = e.road.gift, n = e.seats.findIndex((e) => e.character === t.char);
		n >= 0 && (t.kind === "sword" && (e.seats[n].goalOverride = { k: "tricksRangeThreat" }), t.kind === "glamdring" && (e.seats[n].glamdring = !0));
	}
	if (t.moria && e.moriaCurrent === "doors") {
		let t = e.seats.findIndex((e) => e.character === "gandalf");
		t >= 0 && e.seats[t].extraGoals.push({
			k: "winEachSuit",
			suits: [
				"hills",
				"mountains",
				"forests"
			]
		});
	}
	if (t.moria && e.moriaCurrent === "tomb") {
		let t = e.seats.findIndex((e) => e.character === "gimli");
		t >= 0 && (e.seats[t].goalOverride = {
			k: "consecutiveValues",
			suit: "mountains",
			n: 4
		});
	}
	e.threatDeck = H(e, t.threats);
	let i = xe(e), a = e.seats.some((e) => y[e.character ?? ""]?.setup?.redrawAura === !0), o = [];
	for (let n of i) {
		let r = e.seats[n];
		y[r.character ?? ""]?.setup?.drawThreat && e.threatDeck.length !== 0 && (t.moria && e.moriaCurrent === "tomb" && r.character === "gimli" || (Fe(e, n), o.push(n)));
	}
	if (e.setupQueue = [], t.mirror && !r) {
		let t = e.seats.map((e, t) => t).filter((t) => !e.seats[t].pyramid);
		for (let n of t) e.setupQueue.push({
			kind: "give",
			seat: n,
			remaining: t.filter((e) => e !== n)
		});
		e.setupQueue.push({
			kind: "mirrorDeal",
			per: 4
		});
		for (let n of t) e.setupQueue.push({
			kind: "give",
			seat: n,
			remaining: t.filter((e) => e !== n)
		});
		e.setupQueue.push({
			kind: "mirrorDeal",
			per: e.totalTricks - 8
		});
	}
	for (let t of i) {
		let n = e.seats[t], r = y[n.character ?? ""]?.setup;
		if (a && o.includes(t) && e.threatDeck.length > 0 && e.setupQueue.push({
			kind: "redraw",
			seat: t
		}), !r) continue;
		if (r.passRight && (e.pendingPasses = e.seats.map(() => null), e.setupQueue.push({ kind: "pass" })), r.threatDir && n.threat !== null && e.setupQueue.push({
			kind: "threatDir",
			seat: t
		}), r.chooseThreat) {
			let i = e.road?.gift?.kind === "sword" && n.character === e.road.gift.char, a = !i && e.threatDeck.length > 0, o = i || e.threatDeck.length === 0 ? [
				1,
				3,
				5
			] : r.chooseThreatTop ? e.threatDeck.slice(0, r.chooseThreatTop) : [...e.threatDeck];
			e.setupQueue.push({
				kind: "chooseThreat",
				seat: t,
				values: o,
				fromDeck: a
			});
		}
		if (r.tuck && e.setupQueue.push({
			kind: "tuck",
			seat: t
		}), r.asideLast && e.setupQueue.push({
			kind: "aside",
			seat: t
		}), r.preplay && e.setupQueue.push({
			kind: "preplay",
			seat: t
		}), r.giveEach && e.setupQueue.push({
			kind: "give",
			seat: t,
			remaining: e.seats.map((e, t) => t).filter((e) => e !== t)
		}), r.exchange && n.special !== "wraith") {
			let n = Re(e, t, r.exchange);
			if (r.exchangeAll) n.length > 0 && e.setupQueue.push({
				kind: "exchange",
				seat: t,
				candidates: n,
				count: n.length,
				done: []
			});
			else if (r.exchange === "all") for (let r of n) e.setupQueue.push({
				kind: "exchange",
				seat: t,
				candidates: [r],
				count: 1,
				done: []
			});
			else {
				let i = r.exchangeTimes ?? 1;
				for (let r = 0; r < i && n.length > 0; r += 1) e.setupQueue.push({
					kind: "exchange",
					seat: t,
					candidates: n,
					count: 1,
					done: []
				});
			}
		}
		let i = e.road?.gift?.kind === "sting" && n.character === e.road.gift.char;
		(r.exchangeLost || i) && !e.lostTaken && e.lostCards.length > 0 && e.setupQueue.push({
			kind: "exchangeLost",
			seat: t
		});
	}
	e.setupIdx = 0, e.pendingExchanges = [], e.phase = "setup", Y(e);
}
function Y(e) {
	for (;;) {
		let t = e.setupQueue[e.setupIdx];
		if (!t || t.kind !== "mirrorDeal") break;
		for (let n = 0; n < e.seats.length; n += 1) e.seats[n].pyramid || e.seats[n].hand.push(...e.mirrorDeck.splice(0, t.per));
		e.setupIdx += 1;
	}
	if (e.setupIdx < e.setupQueue.length) return;
	if (W(e).horn === !0 && e.mode !== "solo" || e.road?.gift?.kind === "horn") for (let t of e.seats) {
		if (!t.character?.startsWith("boromir")) continue;
		let e = t.pyramid ? t.pyramid.filter((e) => e.card && e.faceUp).map((e) => e.card) : t.hand, n = /* @__PURE__ */ new Map();
		for (let t of e) n.set(t.s, (n.get(t.s) ?? 0) + 1);
		let r = Math.max(...n.values());
		t.hornSuits = [...n.entries()].filter(([, e]) => e === r).map(([e]) => e);
	}
	let t = e.road ? -1 : e.seats.findIndex((e) => y[e.character ?? ""]?.setup?.leadFirst || e.grantLeadFirst), n = t >= 0 ? t : G(e);
	e.phase = "play", Pe(e, n);
	let r = e.seats.findIndex((e) => e.preplayed);
	r >= 0 && (e.trick.plays.push({
		seat: r,
		card: e.seats[r].preplayed,
		declare: !1,
		pre: !0
	}), e.seats[r].preplayed = null, e.trick.active = ke(e) + +!J(e, r), e.turn = Me(e, e.trick.leader));
}
function Ve(e) {
	return e.drawPile.length > 0 ? !1 : e.seats.every((t, n) => !J(e, n) && t.hand.length <= t.padding);
}
function He(e) {
	return e.find((e) => !e.pre)?.card.s ?? null;
}
function Ue(e, t) {
	let n = e.find((e) => e.declare);
	if (n) return n;
	if (t) {
		let t = e.filter((e) => e.card.s === "river");
		if (t.length > 0) return t.reduce((e, t) => t.card.v > e.card.v ? t : e);
	}
	let r = He(e);
	return e.filter((e) => e.card.s === r).reduce((e, t) => t.card.v > e.card.v ? t : e);
}
function We(e, t) {
	let n = e.seats.find((e) => e.character === "sam2b"), r = n ? n.won.flat().filter((e) => e.s === "rings") : [], i = e.mode === "solo", a = 0;
	if (i) {
		for (let t of e.seats) a += Math.max(0, t.hand.length - t.padding) + +!!t.tucked + +!!t.aside;
		a += e.drawPile.length;
	}
	return {
		seats: e.seats.map((e) => {
			let t = y[e.character ?? "gandalf2"], n = e.won;
			return r.length > 0 && _e(e.character) && (n = [...n, ...r.map((e) => [e])]), {
				goal: e.goalOverride ?? t.goal,
				failIf: t.failIf,
				extraGoals: e.extraGoals,
				won: n,
				hand: e.pyramid ? e.pyramid.filter((e) => e.card && e.pad).map((e) => e.card) : e.hand,
				threat: e.threat,
				threatDir: e.threatDir
			};
		}),
		tricks: e.tricks,
		totalTricks: e.totalTricks,
		withRiver: e.riverCount > 0,
		roundOver: t,
		tricksLeftOverride: i ? Math.ceil(a / 2) : void 0,
		slidingWindow: i
	};
}
function Ge(e, t) {
	if (!e.seats[t].character) return "pending";
	if (e.mithrilSeat === t) return "done";
	let n = We(e, Ve(e));
	return me(n.seats[t]) ? "failed" : R(t, n);
}
function Ke(e, t) {
	let n = W(e), r = U(e), i = (n.skipComplete ?? []).map((e) => T(e, r)), a = (t) => {
		let n = e.seats[t].character;
		return n !== null && !i.includes(n);
	}, o = Ve(e), s = We(e, o);
	for (let t = 0; t < e.seats.length; t += 1) if (a(t) && me(s.seats[t])) {
		e.phase = "lost", e.failedSeat = t;
		return;
	}
	let c = [];
	for (let t = 0; t < e.seats.length; t += 1) a(t) && e.mithrilSeat !== t && R(t, s) === "failed" && c.push(t);
	if (c.length >= 2) {
		e.phase = "lost", e.failedSeat = c[0];
		return;
	}
	if (c.length === 1) {
		if (!be(e)) {
			e.phase = "lost", e.failedSeat = c[0];
			return;
		}
		e.mithrilSeat = c[0], e.mithrilUsed = !0;
	}
	if (!o) {
		if (y[e.seats[t]?.character ?? ""]?.setup?.directAfterWin) {
			e.pendingDirect = t, e.trick = {
				leader: t,
				plays: [],
				active: 0
			};
			return;
		}
		Pe(e, t);
		return;
	}
	let l = [];
	for (let t = 0; t < e.seats.length; t += 1) a(t) && e.mithrilSeat !== t && R(t, s) !== "done" && l.push(t);
	if (l.length >= 2) {
		e.phase = "lost", e.failedSeat = l[0];
		return;
	}
	if (l.length === 1) {
		if (!be(e)) {
			e.phase = "lost", e.failedSeat = l[0];
			return;
		}
		e.mithrilSeat = l[0], e.mithrilUsed = !0;
	}
	if (n.length === "short") {
		e.phase = "won";
		return;
	}
	if (n.moria) {
		if (e.moriaCurrent && !e.moriaDone.includes(e.moriaCurrent) && e.moriaDone.push(e.moriaCurrent), b.every((t) => e.moriaDone.includes(t))) {
			e.phase = "won";
			return;
		}
		e.round += 1, e.moriaPickerSeat = G(e), e.phase = "moriaPick";
		return;
	}
	if (n.maxRounds) {
		e.phase = e.round >= n.maxRounds ? "won" : "roundEnd";
		return;
	}
	for (let t of e.seats) t.character && !e.completed.includes(t.character) && e.completed.push(t.character);
	if (e.road) {
		let t = [T("frodo", r), ...e.road.pool].every((t) => e.completed.includes(t)), n = e.seats.some((t) => t.character !== null && t.character === e.road?.special.char);
		e.phase = t && n ? "won" : "roundEnd";
		return;
	}
	e.phase = n.characters.map((e) => T(e.id, r)).filter((e) => !i.includes(e)).every((t) => e.completed.includes(t)) ? "won" : "roundEnd";
}
function qe(e) {
	let t = Ue(e.trick.plays, e.riverWins), n = t.seat;
	e.omwUp && !t.declare && e.omwUp.v > t.card.v && (n = -1);
	let r = {
		plays: [...e.trick.plays],
		winner: n
	};
	n >= 0 ? e.seats[n].won.push(r.plays.map((e) => e.card)) : e.omwPot.push(...r.plays.map((e) => e.card)), e.omwUp &&= (e.omwPot.push(e.omwUp), null), e.tricks.push(r), e.lastTrick = r;
	let i = e.trick.leader;
	if (e.trick = {
		leader: i,
		plays: [],
		active: 0
	}, e.balrogUp.length > 0) {
		let t = e.balrogUp.reduce((e, t) => e + t.v, 0), n = r.plays.reduce((e, t) => e + t.card.v, 0);
		if (e.lastBalrog = {
			cards: [...e.balrogUp],
			sum: t
		}, e.balrogDisc.push(...e.balrogUp), e.balrogUp = [], t > n) {
			e.phase = "lost", e.failedSeat = null;
			return;
		}
	}
	if (e.mode === "pyramid") {
		let t = e.seats[B].pyramid;
		if (t) for (let n = 0; n < t.length; n += 1) t[n].card && !t[n].faceUp && !we(e, B, n) && (t[n].faceUp = !0);
	}
	if (e.mode === "solo") for (let t of e.seats) t.noDraw || e.drawPile.length === 0 || t.hand.push(e.drawPile.shift());
	Ke(e, n >= 0 ? n : i);
}
function Je(e, t, n) {
	let r = t.length === 1 ? "solo" : t.length === 2 ? "pyramid" : "standard", i = r === "standard" ? t.length : 3, a = [];
	for (let e = 0; e < i; e += 1) a.push({
		owner: t[Math.min(e, t.length - 1)],
		character: null,
		hand: [],
		won: [],
		threat: null,
		threatDir: null,
		padding: 0,
		special: null,
		goalOverride: null,
		extraGoals: [],
		grantLeadFirst: !1,
		hornSuits: null,
		tucked: null,
		aside: null,
		preplayed: null,
		pyramid: null,
		noDraw: !1,
		glamdring: !1
	});
	let o = {
		phase: "choose",
		seed: n,
		rngCursor: 0,
		players: t,
		chapter: e.chapter,
		mode: r,
		round: 1,
		seats: a,
		chooseOrder: [],
		chooseIdx: 0,
		available: [],
		setupQueue: [],
		setupIdx: 0,
		pendingExchanges: [],
		pendingPasses: [],
		lostCards: [],
		lostTaken: !1,
		barrowDeck: [],
		outOfPlay: [],
		omwDeck: [],
		omwUp: null,
		omwPot: [],
		balrogDeck: [],
		balrogDisc: [],
		balrogUp: [],
		lastBalrog: null,
		threatDeck: [],
		broken: !1,
		tricks: [],
		trick: {
			leader: 0,
			plays: [],
			active: 0
		},
		lastTrick: null,
		turn: 0,
		pendingDirect: null,
		totalTricks: 0,
		completed: [],
		failedSeat: null,
		riverCount: 0,
		riverWins: !1,
		drawPile: [],
		mirrorDeck: [],
		moriaDone: [],
		moriaCurrent: null,
		moriaPickerSeat: 0,
		darkRound: !1,
		breakingGroup: null,
		mithrilUsed: !1,
		mithrilSeat: null,
		road: null,
		pyramidRows: [],
		soloExchangeSeat: -1
	};
	return e.chapter === 0 && Ie(o), Le(o), { state: o };
}
function Ye(e, t, n) {
	let r = structuredClone(e), i = n.by, a = (e) => r.seats[e]?.owner === i, o = W(r), s = U(r);
	switch (t.type) {
		case "choose": {
			if (r.phase !== "choose") return V("games.fellowship.errPhase");
			let e = r.chooseOrder[r.chooseIdx];
			if (e === void 0 || !a(e)) return V("games.fellowship.errTurn");
			let n = r.available.find((e) => e.id === t.character);
			if (!n) return V("games.fellowship.errCharacter");
			if (o.breakingGroups) {
				if (r.breakingGroup === null) return V("games.fellowship.errGroup");
				let n = o.breakingGroups.map((e) => e.map((e) => T(e, s)));
				if (!(e === r.chooseOrder[0] ? n[r.breakingGroup] : n[1 - r.breakingGroup]).includes(t.character)) return V("games.fellowship.errGroup");
			} else if (!n.star && r.available.some((e) => e.star)) return V("games.fellowship.errStar");
			if (r.mode === "pyramid" && o.blindfolded) {
				let n = T(o.blindfolded, s);
				if (e === B && t.character === n) return V("games.fellowship.errCharacter");
				if (e !== B && t.character !== n && r.available.some((e) => e.id === n)) {
					let e = r.chooseOrder.slice(r.chooseIdx + 1);
					if (e.length > 0 && e.every((e) => e === B)) return V("games.fellowship.errStar");
				}
			}
			return r.seats[e].character = t.character, r.available = r.available.filter((e) => e.id !== t.character), r.chooseIdx += 1, r.chooseIdx >= r.chooseOrder.length && Be(r), { state: r };
		}
		case "pickGroup": return r.phase !== "choose" || !o.breakingGroups || r.breakingGroup !== null ? V("games.fellowship.errPhase") : a(r.chooseOrder[0]) ? (r.breakingGroup = t.group, { state: r }) : V("games.fellowship.errTurn");
		case "pickEvent": {
			if (r.phase !== "moriaPick") return V("games.fellowship.errPhase");
			if (!a(r.moriaPickerSeat)) return V("games.fellowship.errTurn");
			let e = t.event, n = e === "dark" || !r.moriaDone.includes(e), i = e !== "bridge" || r.moriaDone.length >= b.length - 1;
			return !n || !i ? V("games.fellowship.errEvent") : (r.moriaCurrent = e, Le(r), { state: r });
		}
		case "give": {
			let e = r.setupQueue[r.setupIdx];
			return r.phase !== "setup" || !e || e.kind !== "give" ? V("games.fellowship.errPhase") : a(e.seat) ? e.remaining.includes(t.to) ? K(r, e.seat, t.card) ? (q(r, t.to, t.card, !1), e.remaining = e.remaining.filter((e) => e !== t.to), e.remaining.length === 0 && (r.setupIdx += 1, Y(r)), { state: r }) : V("games.fellowship.errCard") : V("games.fellowship.errGive") : V("games.fellowship.errTurn");
		}
		case "offer": {
			let e = r.setupQueue[r.setupIdx];
			return r.phase !== "setup" || !e || e.kind !== "exchange" ? V("games.fellowship.errPhase") : a(e.seat) ? !e.candidates.includes(t.to) || e.done.includes(t.to) ? V("games.fellowship.errExchange") : _(t.card, g) ? V("games.fellowship.errRingSwap") : K(r, e.seat, t.card) ? (r.pendingExchanges.push({
				from: e.seat,
				to: t.to,
				card: t.card
			}), e.done.push(t.to), Ee(r, e.seat), { state: r }) : V("games.fellowship.errCard") : V("games.fellowship.errTurn");
		}
		case "back": {
			let e = r.setupQueue[r.setupIdx];
			if (r.phase !== "setup" || !e || e.kind !== "exchange") return V("games.fellowship.errPhase");
			let n = r.pendingExchanges.findIndex((t) => t.from === e.seat && a(t.to));
			if (n < 0) return V("games.fellowship.errTurn");
			let i = r.pendingExchanges[n];
			return _(t.card, g) ? V("games.fellowship.errRingSwap") : K(r, i.to, t.card) ? (q(r, i.to, i.card, !1), q(r, i.from, t.card, !1), r.pendingExchanges.splice(n, 1), e.done.length >= e.count && !r.pendingExchanges.some((t) => t.from === e.seat) && (r.setupIdx += 1, De(r, e.seat), Y(r)), { state: r }) : V("games.fellowship.errCard");
		}
		case "exchangeLost": {
			let e = r.setupQueue[r.setupIdx];
			if (r.phase !== "setup" || !e || e.kind !== "exchangeLost") return V("games.fellowship.errPhase");
			if (!a(e.seat)) return V("games.fellowship.errTurn");
			if (_(t.give, g)) return V("games.fellowship.errRingSwap");
			let n = r.lostCards.findIndex((e) => _(e, t.take));
			return n < 0 || !K(r, e.seat, t.give) ? V("games.fellowship.errCard") : (r.lostCards.splice(n, 1), r.lostCards.push(t.give), q(r, e.seat, t.take, !1), r.setupIdx += 1, Ee(r, e.seat), De(r, e.seat), Y(r), { state: r });
		}
		case "threatDir": {
			let e = r.setupQueue[r.setupIdx];
			return r.phase !== "setup" || !e || e.kind !== "threatDir" ? V("games.fellowship.errPhase") : a(e.seat) ? (r.seats[e.seat].threatDir = t.dir, r.setupIdx += 1, Y(r), { state: r }) : V("games.fellowship.errTurn");
		}
		case "chooseThreat": {
			let e = r.setupQueue[r.setupIdx];
			return r.phase !== "setup" || !e || e.kind !== "chooseThreat" ? V("games.fellowship.errPhase") : a(e.seat) ? e.values.includes(t.value) ? (e.fromDeck && (r.threatDeck = r.threatDeck.filter((e) => e !== t.value)), r.seats[e.seat].threat = t.value, r.setupIdx += 1, Y(r), { state: r }) : V("games.fellowship.errThreat") : V("games.fellowship.errTurn");
		}
		case "redraw": {
			let e = r.setupQueue[r.setupIdx];
			if (r.phase !== "setup" || !e || e.kind !== "redraw") return V("games.fellowship.errPhase");
			if (!a(e.seat)) return V("games.fellowship.errTurn");
			if (t.again && r.threatDeck.length > 0) {
				let t = r.seats[e.seat].threat;
				t !== null && r.threatDeck.push(t), Fe(r, e.seat);
			}
			return r.setupIdx += 1, Y(r), { state: r };
		}
		case "pass": {
			let e = r.setupQueue[r.setupIdx];
			if (r.phase !== "setup" || !e || e.kind !== "pass") return V("games.fellowship.errPhase");
			let n = r.pendingPasses.findIndex((e, t) => e === null && a(t));
			if (n < 0) return V("games.fellowship.errTurn");
			if (!K(r, n, t.card)) return V("games.fellowship.errCard");
			if (r.pendingPasses[n] = t.card, r.pendingPasses.every((e) => e !== null)) {
				let e = r.seats.length;
				for (let t = 0; t < e; t += 1) q(r, (t + 1) % e, r.pendingPasses[t], !1);
				r.pendingPasses = [], r.setupIdx += 1, Y(r);
			}
			return { state: r };
		}
		case "tuck": {
			let e = r.setupQueue[r.setupIdx];
			return r.phase !== "setup" || !e || e.kind !== "tuck" ? V("games.fellowship.errPhase") : a(e.seat) ? K(r, e.seat, t.card) ? (r.seats[e.seat].tucked = t.card, r.setupIdx += 1, Y(r), { state: r }) : V("games.fellowship.errCard") : V("games.fellowship.errTurn");
		}
		case "aside": {
			let e = r.setupQueue[r.setupIdx];
			return r.phase !== "setup" || !e || e.kind !== "aside" ? V("games.fellowship.errPhase") : a(e.seat) ? K(r, e.seat, t.card) ? (r.seats[e.seat].aside = t.card, r.setupIdx += 1, Y(r), { state: r }) : V("games.fellowship.errCard") : V("games.fellowship.errTurn");
		}
		case "preplay": {
			let e = r.setupQueue[r.setupIdx];
			return r.phase !== "setup" || !e || e.kind !== "preplay" ? V("games.fellowship.errPhase") : a(e.seat) ? K(r, e.seat, t.card) ? (r.seats[e.seat].preplayed = t.card, r.setupIdx += 1, Y(r), { state: r }) : V("games.fellowship.errCard") : V("games.fellowship.errTurn");
		}
		case "direct": return r.phase !== "play" || r.pendingDirect === null ? V("games.fellowship.errPhase") : a(r.pendingDirect) ? J(r, t.seat) ? (r.pendingDirect = null, Pe(r, t.seat), { state: r }) : V("games.fellowship.errDirect") : V("games.fellowship.errTurn");
		case "skipSetup": {
			let e = r.setupQueue[r.setupIdx];
			return r.mode !== "solo" || r.phase !== "setup" || !e || e.kind !== "exchange" && e.kind !== "exchangeLost" ? V("games.fellowship.errPhase") : a(e.seat) ? r.pendingExchanges.some((t) => t.from === e.seat) ? V("games.fellowship.errPhase") : (r.setupQueue.splice(r.setupIdx, 1), Y(r), { state: r }) : V("games.fellowship.errTurn");
		}
		case "play": {
			if (r.phase !== "play") return V("games.fellowship.errPhase");
			let e = r.turn;
			if (!a(e)) return V("games.fellowship.errTurn");
			let n = r.seats[e], i = Oe(r, e);
			if (!i.some((e) => _(e, t.card))) return V("games.fellowship.errCard");
			let o = t.declare === !0;
			if (o && !_(t.card, g)) return V("games.fellowship.errDeclare");
			if (n.aside && Ae(r, e) && !_(t.card, n.aside)) return V("games.fellowship.errAside");
			let s = !r.trick.plays.some((e) => !e.pre);
			if (s) {
				if (t.card.s === "rings" && !r.broken && !o && i.some((e) => e.s !== "rings")) return V("games.fellowship.errLeadRing");
				let a = n.special ? ee[n.special] : void 0;
				if (a && t.card.s === a) return i.some((e) => e.s !== a) ? V("games.fellowship.errLeadThreat") : (je(r, e, t.card), t.card.s === "rings" && (r.broken = !0), r.trick.plays.push({
					seat: e,
					card: t.card,
					declare: o
				}), r.phase = "lost", r.failedSeat = e, { state: r });
			} else {
				let e = He(r.trick.plays);
				if (e && t.card.s !== e && !(y[n.character ?? ""]?.setup?.ignoreSuit === !0 || n.glamdring && r.tricks.length === 0) && i.some((t) => t.s === e)) return V("games.fellowship.errFollow");
			}
			return je(r, e, t.card), t.card.s === "rings" && !s && (r.broken = !0), r.trick.plays.push({
				seat: e,
				card: t.card,
				declare: o
			}), r.trick.plays.length >= r.trick.active ? qe(r) : r.turn = Me(r, (e + 1) % r.seats.length), { state: r };
		}
		case "nextRound": return r.phase === "roundEnd" ? r.players.includes(i) ? (r.round += 1, Le(r), { state: r }) : V("games.fellowship.errTurn") : V("games.fellowship.errPhase");
		case "retry": return r.phase === "lost" ? r.players.includes(i) ? (Le(r), { state: r }) : V("games.fellowship.errTurn") : V("games.fellowship.errPhase");
	}
}
function Xe(e) {
	let t = e.setupQueue[e.setupIdx];
	if (!t) return null;
	switch (t.kind) {
		case "give": return {
			kind: "give",
			seat: t.seat,
			candidates: [...t.remaining]
		};
		case "exchange": {
			let n = e.pendingExchanges.filter((e) => e.from === t.seat);
			return n.length > 0 ? {
				kind: "exchangeBack",
				seat: n[0].to,
				from: t.seat,
				pending: n.map((e) => e.to)
			} : {
				kind: "exchangeOffer",
				seat: t.seat,
				candidates: t.candidates.filter((e) => !t.done.includes(e))
			};
		}
		case "exchangeLost": return {
			kind: "exchangeLost",
			seat: t.seat,
			lostOptions: [...e.lostCards]
		};
		case "threatDir": return {
			kind: "threatDir",
			seat: t.seat
		};
		case "chooseThreat": return {
			kind: "chooseThreat",
			seat: t.seat,
			values: [...t.values]
		};
		case "redraw": return {
			kind: "redraw",
			seat: t.seat
		};
		case "pass": {
			let t = e.seats.map((e, t) => t).filter((t) => e.pendingPasses[t] === null);
			return {
				kind: "pass",
				seat: t[0] ?? 0,
				pending: t
			};
		}
		case "tuck": return {
			kind: "tuck",
			seat: t.seat
		};
		case "aside": return {
			kind: "aside",
			seat: t.seat
		};
		case "preplay": return {
			kind: "preplay",
			seat: t.seat
		};
		case "mirrorDeal": return null;
	}
}
function Ze(e, t) {
	let n = W(e), r = U(e), i = e.seats.map((e, t) => t).filter((n) => e.seats[n].owner === t), a = i.find((t) => !e.seats[t].pyramid) ?? i[0] ?? 0, o = n.blindfolded && e.mode === "standard" ? e.seats.findIndex((e) => e.character === T(n.blindfolded, r)) : -1, s = (n) => {
		let r = e.seats[n];
		return r.threat === null || e.darkRound && Ge(e, n) !== "done" || r.special === "unseen" && Ge(e, n) !== "done" && r.owner !== t ? null : r.threat;
	}, c = (t) => e.seats[t].threat !== null && s(t) === null, l = {
		phase: e.phase,
		chapter: e.chapter,
		round: e.round,
		length: n.length,
		mode: e.mode,
		seats: e.seats.map((t, n) => ({
			seat: n,
			owner: t.owner,
			character: t.character,
			handCount: t.pyramid ? t.pyramid.filter((e) => e.card !== null).length : t.hand.length,
			openHand: !t.pyramid && (y[t.character ?? ""]?.setup?.openHand === !0 || e.mode === "solo") ? [...t.hand] : null,
			wonCount: t.won.length,
			threat: s(n),
			threatDir: c(n) ? null : t.threatDir,
			special: t.special,
			hornSuits: t.hornSuits ? [...t.hornSuits] : null,
			aside: t.aside,
			tuckedCount: +!!t.tucked,
			blind: n === o,
			pyramid: t.pyramid ? t.pyramid.map((t, r) => ({
				card: t.faceUp ? t.card : null,
				faceUp: t.faceUp,
				covered: t.card !== null && we(e, n, r),
				pad: t.pad === !0
			})) : null,
			goal: Ge(e, n)
		})),
		chooser: e.phase === "choose" ? e.chooseOrder[e.chooseIdx] ?? null : null,
		available: e.phase === "choose" ? e.available.map((e) => ({ ...e })) : [],
		breaking: n.breakingGroups ? {
			groups: n.breakingGroups.map((e) => e.map((e) => T(e, r))),
			picked: e.breakingGroup
		} : null,
		moria: n.moria ? {
			done: [...e.moriaDone],
			current: e.moriaCurrent,
			picker: e.phase === "moriaPick" ? e.moriaPickerSeat : null
		} : null,
		setupStep: e.phase === "setup" ? Xe(e) : null,
		trick: {
			leader: e.trick.leader,
			plays: e.trick.plays.map((n) => n.seat === o && e.seats[n.seat].owner !== t ? {
				seat: n.seat,
				card: {
					s: n.card.s,
					v: 1
				},
				declare: n.declare,
				blind: !0
			} : {
				seat: n.seat,
				card: n.card,
				declare: n.declare
			})
		},
		turn: e.phase === "play" ? e.turn : null,
		pendingDirect: e.pendingDirect,
		lastTrick: e.lastTrick ? {
			plays: e.lastTrick.plays.map((e) => ({
				seat: e.seat,
				card: e.card,
				declare: e.declare
			})),
			winner: e.lastTrick.winner,
			balrog: e.lastBalrog ? {
				cards: [...e.lastBalrog.cards],
				sum: e.lastBalrog.sum
			} : null
		} : null,
		tricksPlayed: e.tricks.length,
		totalTricks: e.mode === "solo" ? null : e.totalTricks,
		lostCards: e.lostTaken ? [] : [...e.lostCards],
		omw: n.deal?.omw ? {
			remaining: e.omwDeck.length,
			up: e.omwUp,
			pot: e.omwPot.length
		} : null,
		balrog: n.moria === !0 && e.moriaCurrent === "bridge" ? { remaining: e.balrogDeck.length } : null,
		drawPile: e.mode === "solo" ? e.drawPile.length : null,
		broken: e.broken,
		gift: e.road?.gift?.kind ?? null,
		mithrilUsed: e.mithrilUsed,
		completed: [...e.completed],
		failedSeat: e.failedSeat
	}, u = null, d = !1;
	if (e.phase === "play" && i.includes(e.turn)) {
		let t = Oe(e, e.turn);
		d = t.some((e) => _(e, g));
		let n = He(e.trick.plays);
		if (n) {
			let r = e.seats[e.turn];
			!(y[r.character ?? ""]?.setup?.ignoreSuit === !0 || r.glamdring && e.tricks.length === 0) && t.some((e) => e.s === n) && (u = n);
		}
	}
	return {
		public: l,
		private: {
			hand: [...e.seats[a].hand],
			mySeats: i,
			mustFollow: u,
			canDeclareRing: d,
			exchangeReceived: e.pendingExchanges.filter((n) => e.seats[n.to].owner === t).map((e) => e.card),
			tucked: e.seats[i.find((t) => e.seats[t].tucked) ?? -1]?.tucked ?? null
		}
	};
}
var Qe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: z,
	schemas: {
		action: ae,
		publicView: ue,
		privateView: de,
		config: A
	},
	setup: Je,
	reduce: Ye,
	viewFor: Ze,
	status: (e) => ({ phase: e.phase })
}, $e = {
	hills: {
		chip: "bg-amber-600 text-white",
		num: "text-amber-700",
		glyph: "●"
	},
	mountains: {
		chip: "bg-slate-500 text-white",
		num: "text-slate-600",
		glyph: "▲"
	},
	shadows: {
		chip: "bg-violet-700 text-white",
		num: "text-violet-700",
		glyph: "◆"
	},
	forests: {
		chip: "bg-emerald-600 text-white",
		num: "text-emerald-700",
		glyph: "■"
	},
	rings: {
		chip: "bg-yellow-500 text-ink",
		num: "text-yellow-600",
		glyph: "◎"
	},
	river: {
		chip: "bg-sky-500 text-white",
		num: "text-sky-600",
		glyph: "≈"
	}
}, X = {
	hills: "games.fellowship.suitHills",
	mountains: "games.fellowship.suitMountains",
	shadows: "games.fellowship.suitShadows",
	forests: "games.fellowship.suitForests",
	rings: "games.fellowship.suitRings",
	river: "games.fellowship.suitRiver"
}, Z = (e) => `${e.s}-${e.v}`, et = {
	hand: "fellowship-card-hand",
	table: "fellowship-card-table",
	mini: "fellowship-card-mini"
};
function tt({ size: e }) {
	let t = e === "mini" ? "h-8 w-6 rounded-sm border" : "h-16 w-11 rounded border-2";
	return /* @__PURE__ */ f("span", {
		"aria-hidden": !0,
		className: `fellowship-card fellowship-card-back ${et[e]} inline-flex flex-none items-center justify-center border-ink bg-violet-800 ${t}`,
		children: /* @__PURE__ */ f("span", {
			className: "text-[10px] text-white/70",
			children: "💍"
		})
	});
}
var nt = (e) => e.s === "rings" && e.v === 1;
function Q({ card: e, size: t, dimmed: n }) {
	let i = r(), a = $e[e.s], o = `${i(X[e.s])} ${e.v}`;
	if (t === "mini") return /* @__PURE__ */ p("span", {
		"aria-label": o,
		className: `fellowship-card fellowship-card-mini inline-flex h-8 w-6 flex-none flex-col items-center justify-center rounded-sm border border-ink bg-surface ${n ? "grayscale brightness-75" : ""}`,
		children: [/* @__PURE__ */ f("span", {
			className: `fellowship-card-number font-display text-xs leading-none font-extrabold tabular-nums ${a.num}`,
			children: e.v
		}), /* @__PURE__ */ f("span", {
			"aria-hidden": !0,
			className: `fellowship-card-glyph grid size-3 place-items-center rounded-full text-[8px] leading-none ${a.chip}`,
			children: a.glyph
		})]
	});
	let s = t === "hand" ? "h-20 w-14 rounded border-2 p-1" : "h-16 w-11 rounded border-2 p-0.5", c = t === "hand" ? "text-2xl" : "text-base", l = t === "hand" ? "size-4 text-[10px]" : "size-3.5 text-[9px]";
	return /* @__PURE__ */ p("span", {
		"aria-label": o,
		className: `fellowship-card ${et[t]} relative inline-flex flex-none flex-col items-start border-ink bg-surface ${s} ${n ? "grayscale brightness-75" : ""}`,
		children: [
			/* @__PURE__ */ f("span", {
				className: `fellowship-card-number font-display leading-none font-extrabold tabular-nums ${c} ${a.num}`,
				children: e.v
			}),
			/* @__PURE__ */ f("span", {
				"aria-hidden": !0,
				className: `fellowship-card-glyph grid place-items-center rounded-full ${l} leading-none ${a.chip}`,
				children: a.glyph
			}),
			nt(e) && /* @__PURE__ */ f("span", {
				"aria-hidden": !0,
				className: "fellowship-card-ring absolute right-0.5 bottom-0.5 text-xs leading-none",
				children: "💍"
			})
		]
	});
}
//#endregion
//#region src/games/fellowship/view-player.tsx
function rt(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ f(pt, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var $ = {
	frodo: "games.fellowship.chars.frodo",
	frodo3: "games.fellowship.chars.frodo3",
	bilbo: "games.fellowship.chars.bilbo",
	gandalf: "games.fellowship.chars.gandalf",
	pippin: "games.fellowship.chars.pippin",
	sam: "games.fellowship.chars.sam",
	merry: "games.fellowship.chars.merry",
	gildor: "games.fellowship.chars.gildor",
	maggot: "games.fellowship.chars.maggot",
	fatty: "games.fellowship.chars.fatty",
	tom: "games.fellowship.chars.tom",
	goldberry: "games.fellowship.chars.goldberry",
	underhill: "games.fellowship.chars.underhill",
	barliman: "games.fellowship.chars.barliman",
	strider: "games.fellowship.chars.strider",
	glorfindel: "games.fellowship.chars.glorfindel",
	bill: "games.fellowship.chars.bill",
	elrond: "games.fellowship.chars.elrond",
	arwen: "games.fellowship.chars.arwen",
	gloin: "games.fellowship.chars.gloin",
	bilbo2: "games.fellowship.chars.bilbo2",
	aragorn: "games.fellowship.chars.aragorn",
	boromir: "games.fellowship.chars.boromir",
	gwaihir: "games.fellowship.chars.gwaihir",
	shadowfax: "games.fellowship.chars.shadowfax",
	radagast: "games.fellowship.chars.radagast",
	legolas: "games.fellowship.chars.legolas",
	gimli: "games.fellowship.chars.gimli",
	orophin: "games.fellowship.chars.orophin",
	haldir: "games.fellowship.chars.haldir",
	galadriel: "games.fellowship.chars.galadriel",
	celeborn: "games.fellowship.chars.celeborn",
	gandalf2: "games.fellowship.chars.gandalf2",
	sam2: "games.fellowship.chars.sam2",
	sam2b: "games.fellowship.chars.sam2b",
	pippin2: "games.fellowship.chars.pippin2",
	pippin2b: "games.fellowship.chars.pippin2b",
	merry2: "games.fellowship.chars.merry2",
	merry2b: "games.fellowship.chars.merry2b",
	aragorn2: "games.fellowship.chars.aragorn2",
	aragorn2b: "games.fellowship.chars.aragorn2b",
	boromir2: "games.fellowship.chars.boromir2",
	boromir2b: "games.fellowship.chars.boromir2b",
	legolas2b: "games.fellowship.chars.legolas2b",
	gimli2b: "games.fellowship.chars.gimli2b"
}, it = {
	doors: "games.fellowship.moriaEvents.doors",
	tomb: "games.fellowship.moriaEvents.tomb",
	dark: "games.fellowship.moriaEvents.dark",
	bridge: "games.fellowship.moriaEvents.bridge"
}, at = {
	mithril: "games.fellowship.gifts.mithril",
	sting: "games.fellowship.gifts.sting",
	glamdring: "games.fellowship.gifts.glamdring",
	sword: "games.fellowship.gifts.sword",
	horn: "games.fellowship.gifts.horn"
};
function ot(e, t, n, r) {
	let i = (e) => e.map((e) => r(X[e])).join(" / "), a = t ?? "?";
	switch (e.k) {
		case "none": return r("games.fellowship.goals.none");
		case "winCards": return r("games.fellowship.goals.winCards", {
			n: e.min,
			suits: i(e.suits)
		});
		case "winAllOfSuit": return r("games.fellowship.goals.winAllOfSuit", { suit: r(X[e.suit]) });
		case "tricks": return e.min === e.max ? r("games.fellowship.goals.tricksExact", { n: e.min }) : e.max >= 99 ? r("games.fellowship.goals.tricksAtLeast", { n: e.min }) : r("games.fellowship.goals.tricksRange", {
			min: e.min,
			max: e.max
		});
		case "tricksLeast": return r("games.fellowship.goals.tricksLeast");
		case "tricksMiddle": return r("games.fellowship.goals.tricksMiddle");
		case "threatCard": return r("games.fellowship.goals.threatCard", {
			threat: a,
			suits: i(e.suits)
		});
		case "threatCardAny": return r("games.fellowship.goals.threatCardAny", {
			n: e.min,
			threat: a
		});
		case "tricksEqualThreat": return r("games.fellowship.goals.tricksEqualThreat", { threat: a });
		case "tricksRangeThreat": return r("games.fellowship.goals.tricksRangeThreat", {
			min: a,
			max: t === null ? "?" : t + 1
		});
		case "tricksVsThreat": return n === "more" ? r("games.fellowship.goals.tricksVsThreatMore", { threat: a }) : n === "less" ? r("games.fellowship.goals.tricksVsThreatLess", { threat: a }) : r("games.fellowship.goals.tricksVsThreat");
		case "lastTrickPlay": return r("games.fellowship.goals.lastTrickPlay", { suits: i(e.suits) });
		case "winLastTrick": return r("games.fellowship.goals.winLastTrick");
		case "winInLastTricks": return r("games.fellowship.goals.winInLastTricks", { n: e.n });
		case "tricksWithRing": return r("games.fellowship.goals.tricksWithRing");
		case "consecutiveTricks": return r("games.fellowship.goals.consecutiveTricks", { n: e.n });
		case "lostSuitCards": return r("games.fellowship.goals.lostSuitCards", { n: e.min });
		case "mostCards": return e.exclusive ? r("games.fellowship.goals.mostCardsExclusive", { suit: r(X[e.suit]) }) : r("games.fellowship.goals.mostCards", { suit: r(X[e.suit]) });
		case "sameValueCards": return r("games.fellowship.goals.sameValueCards", { n: e.min });
		case "tricksWithSuit": return r("games.fellowship.goals.tricksWithSuit", {
			n: e.min,
			suit: r(X[e.suit])
		});
		case "allWinRing": return r("games.fellowship.goals.allWinRing");
		case "zeroAndOthersWin": return r("games.fellowship.goals.zeroAndOthersWin");
		case "consecutiveValues": return r("games.fellowship.goals.consecutiveValues", {
			n: e.n,
			suit: r(X[e.suit])
		});
		case "winEachSuit": return r("games.fellowship.goals.winEachSuit", { suits: i(e.suits) });
		case "winEachRank": return r("games.fellowship.goals.winEachRank");
		case "noWinValue": return r("games.fellowship.goals.noWinValue", { v: e.v });
	}
}
var st = {
	witchking: "games.fellowship.specials.witchking",
	blackbreath: "games.fellowship.specials.blackbreath",
	wraith: "games.fellowship.specials.wraith",
	unseen: "games.fellowship.specials.unseen",
	terror: "games.fellowship.specials.terror"
};
function ct(e, t, n) {
	let r = y[t], i = e > 0 ? te(e).grants : void 0, a = [], o = r?.goal ?? { k: "none" };
	if (i) for (let [e, r] of Object.entries(i)) T(e, n) === t && (r.goal && (o = r.goal), r.extraGoal && a.push(r.extraGoal));
	return {
		goal: o,
		extras: a
	};
}
function lt({ state: e }) {
	return e === "done" ? /* @__PURE__ */ f("span", {
		className: "fellowship-goal-dot grid size-5 flex-none place-items-center rounded-full border-2 border-ink bg-emerald-500 text-white",
		children: /* @__PURE__ */ f(i, {
			size: 12,
			strokeWidth: 3.5,
			"aria-hidden": !0
		})
	}) : e === "failed" ? /* @__PURE__ */ f("span", {
		className: "fellowship-goal-dot grid size-5 flex-none place-items-center rounded-full border-2 border-ink bg-rose-500 text-white",
		children: /* @__PURE__ */ f(a, {
			size: 12,
			strokeWidth: 3.5,
			"aria-hidden": !0
		})
	}) : /* @__PURE__ */ f("span", {
		className: "fellowship-goal-dot grid size-5 flex-none place-items-center rounded-full border-2 border-dashed border-ink/40",
		"aria-hidden": !0
	});
}
var ut = [
	"hills",
	"mountains",
	"shadows",
	"forests",
	"rings",
	"river"
];
function dt(e) {
	return [...e].sort((e, t) => ut.indexOf(e.s) - ut.indexOf(t.s) || e.v - t.v);
}
function ft(e) {
	return e >= 14 ? [
		2,
		3,
		4,
		5
	] : e <= 9 ? [
		2,
		3,
		4
	] : [
		3,
		4,
		5
	];
}
function pt({ pub: e, priv: t, members: i, myRid: a, send: m }) {
	let h = r(), v = (e) => i.find((t) => t.rid === e)?.name ?? e, x = (e) => {
		let t = i.find((t) => t.rid === e);
		return t ? s[t.colorIndex % s.length].hex : void 0;
	}, S = (t) => {
		let n = e.seats[t];
		return n?.character ? h($[n.character]) : v(n?.owner ?? "");
	}, C = dt(t?.hand ?? []), [w, T] = n(null), [E, D] = n(null), [ne, re] = n(!1), O = `${e.phase}|${e.round}|${e.turn}|${e.tricksPlayed}|${C.length}|${e.setupStep?.kind ?? ""}`, [k, ie] = n(O);
	k !== O && (ie(O), T(null), D(null), re(!1));
	let ae = t?.mySeats ?? [], A = (e) => ae.includes(e), oe = ae.some((t) => {
		let n = e.seats[t];
		return C.some((e) => _(e, g)) || (n?.pyramid ?? []).some((e) => e.card !== null && _(e.card, g));
	}), j = e.phase === "choose" && e.chooser !== null && A(e.chooser), se = e.breaking !== null && e.breaking.picked === null, ce = e.phase === "moriaPick" && e.moria !== null && e.moria.picker !== null && A(e.moria.picker), M = e.setupStep, le = M && (M.kind === "pass" || M.kind === "exchangeBack") ? (M.pending ?? [M.seat]).find((e) => A(e)) : void 0, N = e.phase === "setup" && M !== null && (M.kind === "pass" || M.kind === "exchangeBack" ? le !== void 0 : A(M.seat)), ue = e.phase === "play" && e.pendingDirect !== null && A(e.pendingDirect), de = e.phase === "play" && e.pendingDirect === null && e.turn !== null && A(e.turn), P = e.phase === "setup" && M ? le ?? M.seat : e.phase === "play" ? e.turn ?? -1 : -1, F = P >= 0 ? e.seats[P] : void 0, I = (t) => {
		let n = e.seats[t];
		return n ? n.pyramid ? n.pyramid.filter((e) => e.card !== null && e.faceUp && !e.covered && !e.pad).map((e) => e.card) : n.openHand ? n.openHand : A(t) ? C : [] : [];
	}, L = F?.aside ?? null, fe = F && F.tuckedCount > 0 && A(P) ? t?.tucked ?? null : null, R = P >= 0 ? [
		...I(P),
		...fe ? [fe] : [],
		...L ? [L] : []
	] : [], pe = L !== null && e.totalTricks !== null && e.tricksPlayed === e.totalTricks - 1, me = F?.special ? ee[F.special] : void 0, he = e.trick.plays.length === 0, ge = (n) => R.some((e) => _(e, n)) ? e.phase === "setup" ? !N || !M ? !1 : M.kind !== "threatDir" && M.kind !== "chooseThreat" && M.kind !== "redraw" : de ? pe ? L !== null && _(n, L) : !(L && _(n, L) || t?.mustFollow && n.s !== t.mustFollow || he && n.s === "rings" && !e.broken && R.some((e) => e.s !== "rings") || he && me && n.s === me && R.some((e) => e.s !== me)) : !1 : !1, B = e.gift === "mithril" || e.chapter > 0 && te(e.chapter).mithril === !0, V, H;
	if (e.phase === "choose") V = j ? "accent" : "info", H = j ? h(se ? "games.fellowship.pickGroupPrompt" : "games.fellowship.choosePrompt") : se ? h("games.fellowship.pickGroupWaiting") : h("games.fellowship.chooseWaiting", { name: v(e.seats[e.chooser ?? 0]?.owner ?? "") });
	else if (e.phase === "moriaPick") V = ce ? "accent" : "info", H = ce ? h("games.fellowship.moriaPickPrompt") : h("games.fellowship.moriaPickWaiting", { name: S(e.moria?.picker ?? 0) });
	else if (e.phase === "setup" && M) {
		V = N ? "accent" : "info";
		let t = S(M.seat);
		if (M.kind === "give") H = N ? h("games.fellowship.givePrompt") : h("games.fellowship.giveWaiting", { name: t });
		else if (M.kind === "exchangeBack") {
			let e = M.from === void 0 ? "" : S(M.from);
			H = N ? h("games.fellowship.exchangeBackPrompt", { name: e }) : h("games.fellowship.exchangeBackWaiting", { name: t });
		} else if (M.kind === "exchangeOffer") H = N ? h("games.fellowship.exchangePrompt") : h("games.fellowship.exchangeWaiting", { name: t });
		else if (M.kind === "exchangeLost") H = N ? h("games.fellowship.exchangeLostPrompt") : h("games.fellowship.exchangeLostWaiting", { name: t });
		else if (M.kind === "redraw") {
			let n = e.seats[M.seat]?.threat ?? "?";
			H = N ? h("games.fellowship.redrawPrompt", { n }) : h("games.fellowship.redrawWaiting", { name: t });
		} else if (M.kind === "threatDir") {
			let n = F?.threat ?? e.seats[M.seat]?.threat ?? 0;
			H = N ? h("games.fellowship.threatDirPrompt", { n }) : h("games.fellowship.threatDirWaiting", { name: t });
		} else H = M.kind === "chooseThreat" ? N ? h("games.fellowship.chooseThreatPrompt") : h("games.fellowship.chooseThreatWaiting", { name: t }) : M.kind === "pass" ? h(N ? "games.fellowship.passPrompt" : "games.fellowship.passWaiting") : M.kind === "tuck" ? N ? h("games.fellowship.tuckPrompt") : h("games.fellowship.setupCardWaiting", { name: t }) : M.kind === "aside" ? N ? h("games.fellowship.asidePrompt") : h("games.fellowship.setupCardWaiting", { name: t }) : N ? h("games.fellowship.preplayPrompt") : h("games.fellowship.setupCardWaiting", { name: t });
	} else e.phase === "play" && ue ? (V = "accent", H = h("games.fellowship.directPrompt")) : e.phase === "play" && e.pendingDirect !== null ? (V = "info", H = h("games.fellowship.directWaiting", { name: S(e.pendingDirect) })) : e.phase === "play" ? (V = de ? "accent" : "info", H = de ? h("games.fellowship.turnYou") : h("games.fellowship.turnWait", { name: S(e.turn ?? 0) })) : e.phase === "won" ? (V = "done", H = h("games.fellowship.won")) : e.phase === "lost" ? (V = "warn", H = h("games.fellowship.lost")) : (V = "done", H = h("games.fellowship.roundChip", { n: e.round }));
	let _e = e.length === "short" ? h("games.fellowship.chapterChip", { n: e.chapter }) : h("games.fellowship.roundChip", { n: e.round }), ve = (t) => e.phase === "choose" ? e.chooser === t : e.phase === "moriaPick" ? e.moria?.picker === t : e.phase === "setup" ? P === t : e.phase === "play" && (e.pendingDirect ?? e.turn) === t, U = e.phase === "play" || e.phase === "roundEnd" || e.phase === "won" || e.phase === "lost", W = /* @__PURE__ */ p("div", {
		className: "fellowship-chips flex flex-wrap items-center justify-center gap-2 pb-1 text-[10px] font-bold opacity-80",
		children: [
			e.lostCards.length > 0 && /* @__PURE__ */ p("span", {
				className: "flex items-center gap-1",
				children: [h("games.fellowship.lostCardLabel"), e.lostCards.map((e) => /* @__PURE__ */ f(Q, {
					card: e,
					size: "mini"
				}, Z(e)))]
			}),
			e.omw && /* @__PURE__ */ p("span", {
				className: "flex items-center gap-1",
				children: [
					"🌳 ",
					h("games.fellowship.omwLabel"),
					" ×",
					e.omw.remaining,
					e.omw.up && /* @__PURE__ */ f(Q, {
						card: e.omw.up,
						size: "mini"
					})
				]
			}),
			e.lastTrick?.winner === -1 && /* @__PURE__ */ p("span", {
				className: "text-amber-600",
				children: ["🌳 ", h("games.fellowship.omwStolen")]
			}),
			e.broken && /* @__PURE__ */ f("span", { children: h("games.fellowship.brokenLabel") }),
			e.moria && /* @__PURE__ */ p("span", { children: [
				"🕳 ",
				h("games.fellowship.moriaDoneLabel"),
				": ",
				e.moria.done.length === 0 ? "—" : e.moria.done.map((e) => h(it[e])).join("/"),
				e.moria.current ? ` · ${h(it[e.moria.current])}` : ""
			] }),
			e.moria?.current === "dark" && /* @__PURE__ */ f("span", {
				className: "text-violet-700",
				children: h("games.fellowship.darkLabel")
			}),
			e.balrog && /* @__PURE__ */ p("span", { children: ["🌋 ", h("games.fellowship.balrogLabel", { n: e.balrog.remaining })] }),
			e.lastTrick?.balrog && /* @__PURE__ */ p("span", {
				className: "flex items-center gap-1 text-rose-600",
				children: [e.lastTrick.balrog.cards.map((e, t) => /* @__PURE__ */ f(Q, {
					card: e,
					size: "mini"
				}, `${Z(e)}-${t}`)), h("games.fellowship.balrogSumLabel", { sum: e.lastTrick.balrog.sum })]
			}),
			e.drawPile !== null && /* @__PURE__ */ p("span", { children: ["🂠 ", h("games.fellowship.drawPileLabel", { n: e.drawPile })] }),
			e.gift && e.gift !== "mithril" && /* @__PURE__ */ p("span", { children: [
				"🎁 ",
				h("games.fellowship.giftLabel"),
				": ",
				h(at[e.gift])
			] }),
			B && /* @__PURE__ */ p("span", { children: ["🛡 ", e.mithrilUsed ? h("games.fellowship.mithrilUsed") : h("games.fellowship.mithrilReady")] })
		]
	}), ye = /* @__PURE__ */ p("div", {
		className: "fellowship-bars flex h-12 flex-none items-center",
		children: [
			e.phase === "setup" && N && M && (M.kind === "give" || M.kind === "exchangeOffer") && /* @__PURE__ */ f("div", {
				className: "plate flex w-full flex-wrap items-center gap-2 px-3 py-1.5",
				children: (M.candidates ?? []).map((t) => /* @__PURE__ */ f("button", {
					type: "button",
					disabled: !w,
					onClick: () => {
						w && (m(M.kind === "give" ? {
							type: "give",
							to: t,
							card: w
						} : {
							type: "offer",
							to: t,
							card: w
						}), T(null));
					},
					className: `btn-quiet min-h-11 px-3 text-xs font-extrabold ${w ? "" : "opacity-40"}`,
					style: { color: x(e.seats[t]?.owner ?? "") },
					children: S(t)
				}, t))
			}),
			e.phase === "setup" && N && M?.kind === "exchangeBack" && /* @__PURE__ */ p("div", {
				className: "plate flex w-full items-center gap-2 px-3 py-1.5",
				children: [
					/* @__PURE__ */ f("span", {
						className: "min-w-0 flex-1 truncate text-sm font-extrabold",
						children: w ? /* @__PURE__ */ f(Q, {
							card: w,
							size: "mini"
						}) : null
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => T(null),
						children: h("games.fellowship.cancel")
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						disabled: !w,
						className: "btn-base min-h-11 px-4 text-sm text-white",
						style: { background: z.accent },
						onClick: () => {
							w && (m({
								type: "back",
								card: w
							}), T(null));
						},
						children: h("games.fellowship.exchangeBackConfirm")
					})
				]
			}),
			e.phase === "setup" && N && M?.kind === "exchangeLost" && /* @__PURE__ */ p("div", {
				className: "plate flex w-full items-center gap-2 px-3 py-1.5",
				children: [
					/* @__PURE__ */ p("span", {
						className: "flex min-w-0 flex-1 items-center gap-1 text-sm font-extrabold",
						children: [
							w ? /* @__PURE__ */ f(Q, {
								card: w,
								size: "mini"
							}) : null,
							w && E ? "→" : null,
							E ? /* @__PURE__ */ f(Q, {
								card: E,
								size: "mini"
							}) : null
						]
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => {
							T(null), D(null);
						},
						children: h("games.fellowship.cancel")
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						disabled: !w || !E,
						className: "btn-base min-h-11 px-4 text-sm text-white",
						style: { background: z.accent },
						onClick: () => {
							w && E && (m({
								type: "exchangeLost",
								give: w,
								take: E
							}), T(null), D(null));
						},
						children: h("games.fellowship.playCard")
					})
				]
			}),
			e.phase === "setup" && N && M && (M.kind === "pass" || M.kind === "tuck" || M.kind === "aside" || M.kind === "preplay") && w && /* @__PURE__ */ p("div", {
				className: "plate flex w-full items-center gap-2 px-3 py-1.5",
				children: [
					/* @__PURE__ */ f(Q, {
						card: w,
						size: "mini"
					}),
					/* @__PURE__ */ f("span", { className: "flex-1" }),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => T(null),
						children: h("games.fellowship.cancel")
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base min-h-11 px-4 text-sm text-white",
						style: { background: z.accent },
						onClick: () => {
							m({
								type: M.kind,
								card: w
							}), T(null);
						},
						children: h("games.fellowship.playCard")
					})
				]
			}),
			e.phase === "play" && ue && /* @__PURE__ */ f("div", {
				className: "plate flex w-full flex-wrap items-center gap-2 px-3 py-1.5",
				children: e.seats.map((e) => {
					let t = e.character !== null && (e.handCount > 0 || e.tuckedCount > 0 || e.aside !== null);
					return /* @__PURE__ */ f("button", {
						type: "button",
						disabled: !t,
						onClick: () => m({
							type: "direct",
							seat: e.seat
						}),
						className: `btn-quiet min-h-11 px-3 text-xs font-extrabold ${t ? "" : "opacity-40"}`,
						style: { color: x(e.owner) },
						children: S(e.seat)
					}, e.seat);
				})
			}),
			e.phase === "play" && de && w && /* @__PURE__ */ p("div", {
				className: "plate flex w-full items-center gap-2 px-3 py-1.5",
				children: [
					/* @__PURE__ */ f(Q, {
						card: w,
						size: "mini"
					}),
					_(w, g) && t?.canDeclareRing && /* @__PURE__ */ p("button", {
						type: "button",
						className: `btn-quiet min-h-11 px-2 text-xs font-extrabold ${ne ? "" : "opacity-50"}`,
						onClick: () => re(!ne),
						children: ["💍 ", h("games.fellowship.declareRing")]
					}),
					/* @__PURE__ */ f("span", { className: "flex-1" }),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet min-h-11 px-3 text-sm",
						onClick: () => T(null),
						children: h("games.fellowship.cancel")
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base min-h-11 px-4 text-sm text-white",
						style: { background: z.accent },
						onClick: () => {
							m({
								type: "play",
								card: w,
								...ne ? { declare: !0 } : {}
							}), T(null), re(!1);
						},
						children: h("games.fellowship.playCard")
					})
				]
			})
		]
	}), be = e.mode !== "solo" && (C.length > 0 || t?.tucked || F?.aside) ? /* @__PURE__ */ f("div", {
		className: "fellowship-hand flex flex-none overflow-x-auto px-2 pb-1",
		children: /* @__PURE__ */ p("div", {
			className: "fellowship-fan flex",
			children: [C.map((e, t) => {
				let n = ge(e), r = w !== null && Z(w) === Z(e);
				return /* @__PURE__ */ f("button", {
					type: "button",
					disabled: !n,
					onClick: () => T(r ? null : e),
					className: `${t > 0 ? "fellowship-card-overlap" : ""} ${r ? "-translate-y-2" : ""} transition-transform`,
					"aria-label": `${h(X[e.s])} ${e.v}`,
					children: /* @__PURE__ */ f(Q, {
						card: e,
						size: "hand",
						dimmed: !n
					})
				}, Z(e));
			}), [t?.tucked ?? null, e.phase === "play" ? F?.aside ?? null : null].map((e) => {
				if (!e) return null;
				let t = ge(e), n = w !== null && Z(w) === Z(e);
				return /* @__PURE__ */ f("button", {
					type: "button",
					disabled: !t,
					onClick: () => T(n ? null : e),
					className: `fellowship-card-overlap ${n ? "-translate-y-2" : ""} transition-transform`,
					"aria-label": `${h(X[e.s])} ${e.v}`,
					children: /* @__PURE__ */ f(Q, {
						card: e,
						size: "hand",
						dimmed: !t
					})
				}, `x-${Z(e)}`);
			})]
		})
	}) : null, G = e.seats.find((e) => e.pyramid !== null);
	return /* @__PURE__ */ f(c, {
		adaptive: !0,
		className: "fellowship-screen",
		banner: /* @__PURE__ */ p("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ f(l, {
				tone: V,
				text: H,
				chip: _e,
				accent: z.accent
			}), /* @__PURE__ */ f(u, {
				adaptive: !0,
				variant: "medal",
				scroll: !0,
				members: i,
				myRid: a,
				action: (t) => e.seats.some((e) => e.owner === t && ve(e.seat)) ? "pending" : null,
				status: (t) => {
					let n = e.seats.find((e) => e.owner === t && ve(e.seat)) ?? e.seats.find((e) => e.owner === t);
					return n?.character ? /* @__PURE__ */ p("span", {
						className: "fellowship-player-status flex items-center gap-1 text-[10px] leading-4 font-bold",
						children: [
							/* @__PURE__ */ f("span", { children: h($[n.character]) }),
							/* @__PURE__ */ p("span", {
								className: "font-mono tabular-nums",
								children: ["🃏", n.wonCount]
							}),
							n.threat !== null && /* @__PURE__ */ p("span", {
								className: "font-mono tabular-nums",
								children: ["☠", n.threat]
							}),
							/* @__PURE__ */ f(lt, { state: n.goal })
						]
					}) : null;
				}
			})]
		}),
		scroll: !1,
		overlay: U ? W : void 0,
		actionsHeight: e.mode === "solo" ? "fellowship-actions-solo" : "fellowship-actions-height",
		actions: /* @__PURE__ */ p("div", {
			className: "fellowship-actions flex h-full flex-col gap-1",
			children: [ye, be]
		}),
		children: /* @__PURE__ */ p("div", {
			className: "fellowship-main frame",
			"data-has-goals": e.phase !== "choose" && e.phase !== "moriaPick",
			children: [e.phase !== "choose" && e.phase !== "moriaPick" && /* @__PURE__ */ f(ht, {
				pub: e,
				t: h,
				nameOf: v,
				colorOf: x,
				mySeats: ae
			}), /* @__PURE__ */ p("div", {
				className: "fellowship-table",
				children: [
					e.phase === "choose" && /* @__PURE__ */ p("div", {
						className: "fellowship-choices",
						children: [oe && /* @__PURE__ */ f("p", {
							className: "plate mb-2 p-2 text-xs font-bold",
							children: h("games.fellowship.ringBearerYou")
						}), e.breaking && se ? /* @__PURE__ */ f("div", {
							className: "flex flex-col gap-2",
							children: e.breaking.groups.map((e, t) => /* @__PURE__ */ p("button", {
								type: "button",
								disabled: !j,
								onClick: () => m({
									type: "pickGroup",
									group: t
								}),
								className: `card flex min-h-12 w-full flex-col gap-0.5 p-2 text-left ${j ? "cursor-pointer" : "opacity-80"}`,
								children: [
									/* @__PURE__ */ f("span", {
										className: "text-sm font-extrabold",
										children: h("games.fellowship.groupLabel", { n: t + 1 })
									}),
									/* @__PURE__ */ f("span", {
										className: "text-xs opacity-75",
										children: e.map((e) => h($[e])).join(" / ")
									}),
									j && /* @__PURE__ */ f("span", {
										className: "text-xs font-extrabold",
										style: { color: z.accent },
										children: h("games.fellowship.groupPick")
									})
								]
							}, t))
						}) : e.breaking ? /* @__PURE__ */ f("div", {
							className: "flex flex-col gap-2",
							children: e.breaking.groups.map((t, n) => {
								let r = t.filter((t) => e.available.some((e) => e.id === t));
								return r.length === 0 ? null : /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("p", {
									className: "section-label",
									children: [h("games.fellowship.groupLabel", { n: n + 1 }), n === e.breaking?.picked ? ` · ${h("games.fellowship.groupBearerTag")}` : ""]
								}), /* @__PURE__ */ f("ul", {
									className: "flex flex-col gap-1.5",
									children: r.map((t) => {
										let n = e.available.find((e) => e.id === t), r = y[t];
										return /* @__PURE__ */ f("li", { children: /* @__PURE__ */ p("button", {
											type: "button",
											disabled: !j,
											onClick: () => m({
												type: "choose",
												character: t
											}),
											className: `card flex min-h-11 w-full flex-col gap-0.5 p-2 text-left ${j ? "cursor-pointer" : "opacity-80"}`,
											children: [/* @__PURE__ */ p("span", {
												className: "flex items-center gap-2 text-sm font-extrabold",
												children: [h($[t]), n?.star && /* @__PURE__ */ f("span", {
													className: "rounded-md bg-amber-400 px-1 text-[10px] text-ink",
													children: h("games.fellowship.starBadge")
												})]
											}), r && /* @__PURE__ */ f("span", {
												className: "text-xs opacity-75",
												children: ot(r.goal, null, null, h)
											})]
										}) }, t);
									})
								})] }, n);
							})
						}) : /* @__PURE__ */ f("ul", {
							className: "flex flex-col gap-1.5",
							children: e.available.map((e) => {
								let t = y[e.id];
								return /* @__PURE__ */ f("li", { children: /* @__PURE__ */ p("button", {
									type: "button",
									disabled: !j,
									onClick: () => m({
										type: "choose",
										character: e.id
									}),
									className: `card flex min-h-11 w-full flex-col gap-0.5 p-2 text-left ${j ? "cursor-pointer" : "opacity-80"}`,
									children: [/* @__PURE__ */ p("span", {
										className: "flex items-center gap-2 text-sm font-extrabold",
										children: [h($[e.id]), e.star && /* @__PURE__ */ f("span", {
											className: "rounded-md bg-amber-400 px-1 text-[10px] text-ink",
											children: h("games.fellowship.starBadge")
										})]
									}), t && /* @__PURE__ */ f("span", {
										className: "text-xs opacity-75",
										children: ot(t.goal, null, null, h)
									})]
								}) }, e.id);
							})
						})]
					}),
					e.phase === "moriaPick" && e.moria && /* @__PURE__ */ f("div", {
						className: "fellowship-events flex flex-col gap-1.5",
						children: b.map((t) => {
							let n = e.moria?.done.includes(t) ?? !1, r = t === "bridge" && (e.moria?.done.length ?? 0) < b.length - 1, i = !ce || n && t !== "dark" || r;
							return /* @__PURE__ */ p("button", {
								type: "button",
								disabled: i,
								onClick: () => m({
									type: "pickEvent",
									event: t
								}),
								className: `card flex min-h-12 w-full items-center gap-2 p-2 text-left text-sm font-extrabold ${i ? "opacity-50" : "cursor-pointer"}`,
								children: [/* @__PURE__ */ f(lt, { state: n ? "done" : "pending" }), h(it[t])]
							}, t);
						})
					}),
					e.phase === "setup" && /* @__PURE__ */ p("div", {
						className: "fellowship-setup flex flex-col gap-2",
						children: [
							M?.kind === "exchangeBack" && N && (t?.exchangeReceived.length ?? 0) > 0 && /* @__PURE__ */ p("div", {
								className: "plate flex items-center gap-2 p-2 text-xs font-bold",
								children: [(t?.exchangeReceived ?? []).map((e) => /* @__PURE__ */ f(Q, {
									card: e,
									size: "table"
								}, Z(e))), /* @__PURE__ */ f("span", {
									className: "min-w-0 flex-1",
									children: h("games.fellowship.exchangeBackPrompt", { name: M.from === void 0 ? "" : S(M.from) })
								})]
							}),
							M?.kind === "exchangeLost" && N && /* @__PURE__ */ p("div", {
								className: "plate flex flex-wrap items-center gap-2 p-2",
								children: [/* @__PURE__ */ p("span", {
									className: "text-xs font-extrabold",
									children: [h("games.fellowship.lostCardLabel"), ":"]
								}), (M.lostOptions ?? []).map((e) => {
									let t = E !== null && _(E, e);
									return /* @__PURE__ */ f("button", {
										type: "button",
										onClick: () => D(t ? null : e),
										className: t ? "-translate-y-1" : "",
										children: /* @__PURE__ */ f(Q, {
											card: e,
											size: "table"
										})
									}, Z(e));
								})]
							}),
							M?.kind === "redraw" && N && /* @__PURE__ */ p("div", {
								className: "plate flex flex-wrap items-center gap-2 p-2",
								children: [/* @__PURE__ */ f("button", {
									type: "button",
									className: "btn-base min-h-12 flex-1 px-3 text-sm font-extrabold text-white",
									style: { background: z.accent },
									onClick: () => m({
										type: "redraw",
										again: !1
									}),
									children: h("games.fellowship.redrawKeep", { n: e.seats[M.seat]?.threat ?? "?" })
								}), /* @__PURE__ */ f("button", {
									type: "button",
									className: "btn-base min-h-12 flex-1 px-3 text-sm font-extrabold text-white",
									style: { background: z.accent },
									onClick: () => m({
										type: "redraw",
										again: !0
									}),
									children: h("games.fellowship.redrawAgain")
								})]
							}),
							e.mode === "solo" && N && M && (M.kind === "exchangeOffer" || M.kind === "exchangeLost") && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet min-h-11 px-3 text-xs font-extrabold",
								onClick: () => m({ type: "skipSetup" }),
								children: h("games.fellowship.skipSetup")
							}),
							M?.kind === "chooseThreat" && N && /* @__PURE__ */ f("div", {
								className: "plate flex flex-wrap items-center gap-2 p-2",
								children: (M.values ?? []).map((e) => /* @__PURE__ */ f("button", {
									type: "button",
									className: "btn-base min-h-12 min-w-12 px-3 font-mono text-lg font-extrabold text-white",
									style: { background: z.accent },
									onClick: () => m({
										type: "chooseThreat",
										value: e
									}),
									children: e
								}, e))
							}),
							M?.kind === "threatDir" && N && /* @__PURE__ */ p("div", {
								className: "plate flex flex-wrap items-center gap-2 p-2",
								children: [/* @__PURE__ */ f("button", {
									type: "button",
									className: "btn-base min-h-12 flex-1 px-3 text-sm font-extrabold text-white",
									style: { background: z.accent },
									onClick: () => m({
										type: "threatDir",
										dir: "more"
									}),
									children: h("games.fellowship.threatDirMore", { n: F?.threat ?? "?" })
								}), /* @__PURE__ */ f("button", {
									type: "button",
									className: "btn-base min-h-12 flex-1 px-3 text-sm font-extrabold text-white",
									style: { background: z.accent },
									onClick: () => m({
										type: "threatDir",
										dir: "less"
									}),
									children: h("games.fellowship.threatDirLess", { n: F?.threat ?? "?" })
								})]
							})
						]
					}),
					(e.phase === "play" || e.phase === "roundEnd" || e.phase === "won" || e.phase === "lost") && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("div", {
						className: "fellowship-trick flex flex-none flex-col items-center gap-1",
						children: [/* @__PURE__ */ f("div", {
							className: "fellowship-trick-cards flex items-center justify-center gap-2",
							children: e.trick.plays.map((t) => /* @__PURE__ */ p("span", {
								className: "flex flex-col items-center gap-0.5",
								children: [t.blind ? /* @__PURE__ */ f(tt, { size: "table" }) : /* @__PURE__ */ f(Q, {
									card: t.card,
									size: "table"
								}), /* @__PURE__ */ p("span", {
									className: "fellowship-trick-name text-[10px] font-bold",
									style: { color: x(e.seats[t.seat]?.owner ?? "") },
									children: [
										t.declare ? "💍 " : "",
										S(t.seat),
										t.blind ? ` · ${h("games.fellowship.blindLabel")}` : ""
									]
								})]
							}, `${t.seat}-${Z(t.card)}`))
						}), e.phase === "play" && e.totalTricks !== null && /* @__PURE__ */ f("span", {
							className: "fellowship-trick-count text-[10px] font-bold opacity-60",
							children: h("games.fellowship.trickChip", {
								n: e.tricksPlayed + 1,
								total: e.totalTricks
							})
						})]
					}), (e.phase === "won" || e.phase === "lost" || e.phase === "roundEnd") && /* @__PURE__ */ p("div", {
						className: "fellowship-round-result plate flex flex-none flex-col gap-2 p-3",
						children: [
							e.phase === "lost" && e.failedSeat !== null && /* @__PURE__ */ p("p", {
								className: "flex items-center gap-1.5 text-xs font-bold text-rose-600",
								children: [/* @__PURE__ */ f(o, {
									size: 14,
									"aria-hidden": !0
								}), h("games.fellowship.failedBy", { name: S(e.failedSeat) })]
							}),
							e.phase === "lost" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-12 w-full text-sm font-extrabold text-white",
								style: { background: z.accent },
								onClick: () => m({ type: "retry" }),
								children: h("games.fellowship.retry")
							}),
							e.phase === "roundEnd" && /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-base min-h-12 w-full text-sm font-extrabold text-white",
								style: { background: z.accent },
								onClick: () => m({ type: "nextRound" }),
								children: h("games.fellowship.nextRound")
							})
						]
					})] }),
					e.phase !== "won" && G && /* @__PURE__ */ f(mt, {
						seat: G,
						t: h,
						selCard: w,
						onPick: (e) => T(w !== null && _(w, e) ? null : e),
						legalCard: ge
					}),
					e.phase !== "won" && e.mode === "solo" && /* @__PURE__ */ f("div", {
						className: "fellowship-solo flex flex-none flex-col gap-1 px-1 pb-1",
						children: ae.map((n) => {
							let r = e.seats[n];
							if (!r) return null;
							let i = r.openHand ?? [], a = [...r.tuckedCount > 0 && t?.tucked ? [t.tucked] : [], ...e.phase === "play" && r.aside ? [r.aside] : []];
							if (i.length === 0 && a.length === 0) return null;
							let o = ve(n);
							return /* @__PURE__ */ p("div", {
								className: `fellowship-solo-row flex items-center gap-1 rounded-lg px-1 ${o ? "bg-sky-100" : ""}`,
								children: [/* @__PURE__ */ f("span", {
									className: `fellowship-solo-name flex-none text-[10px] font-extrabold ${o ? "" : "opacity-60"}`,
									children: r.character ? h($[r.character]) : S(n)
								}), /* @__PURE__ */ f("div", {
									className: "fellowship-solo-hand flex min-w-0 flex-1 overflow-x-auto py-0.5",
									children: /* @__PURE__ */ f("div", {
										className: "flex",
										children: [...i, ...a].map((e, t) => {
											let r = ge(e), i = w !== null && Z(w) === Z(e);
											return /* @__PURE__ */ f("button", {
												type: "button",
												disabled: !r,
												onClick: () => T(i ? null : e),
												className: `${t > 0 ? "fellowship-card-overlap" : ""} ${i ? "-translate-y-2" : ""} transition-transform`,
												"aria-label": `${h(X[e.s])} ${e.v}`,
												children: /* @__PURE__ */ f(Q, {
													card: e,
													size: "table",
													dimmed: !r
												})
											}, `${n}-${Z(e)}-${t}`);
										})
									})
								})]
							}, n);
						})
					})
				]
			})]
		})
	});
}
function mt({ seat: e, t, selCard: n, onPick: r, legalCard: i }) {
	let a = e.pyramid ?? [], o = [];
	{
		let e = 0;
		for (let t of ft(a.length)) o.push(a.slice(e, e + t)), e += t;
	}
	return /* @__PURE__ */ p("div", {
		className: "fellowship-pyramid flex flex-none flex-col items-center gap-0.5",
		children: [/* @__PURE__ */ f("span", {
			className: "text-[10px] font-extrabold opacity-60",
			children: t("games.fellowship.pyramidLabel")
		}), o.map((e, a) => /* @__PURE__ */ f("div", {
			className: "flex justify-center gap-1",
			children: e.map((e, a) => {
				if (e.card === null && e.faceUp) return /* @__PURE__ */ f("span", {
					className: "fellowship-pyramid-empty rounded border-2 border-dashed border-ink/20",
					"aria-hidden": !0
				}, a);
				if (e.card === null) return /* @__PURE__ */ f(tt, { size: "table" }, a);
				let o = !e.covered && !e.pad && i(e.card), s = n !== null && _(n, e.card);
				return /* @__PURE__ */ f("button", {
					type: "button",
					disabled: !o,
					onClick: () => r(e.card),
					className: s ? "-translate-y-2 transition-transform" : "transition-transform",
					"aria-label": `${t(X[e.card.s])} ${e.card.v}`,
					title: e.pad ? t("games.fellowship.pyramidPad") : e.covered ? t("games.fellowship.pyramidCovered") : void 0,
					children: /* @__PURE__ */ f(Q, {
						card: e.card,
						size: "table",
						dimmed: !o
					})
				}, a);
			})
		}, a))]
	});
}
function ht({ pub: e, t, nameOf: n, colorOf: r, mySeats: i }) {
	return /* @__PURE__ */ p("div", {
		className: "fellowship-goals",
		children: [/* @__PURE__ */ f("ul", {
			className: "flex flex-col gap-1",
			children: e.seats.map((a) => {
				if (!a.character) return null;
				let o = ct(e.chapter, a.character, e.seats.length);
				return /* @__PURE__ */ p("li", {
					className: "fellowship-goal-row flex items-center gap-1.5 rounded-lg border-2 border-ink/15 bg-surface px-2 py-1 text-xs font-bold",
					children: [
						/* @__PURE__ */ f(lt, { state: a.goal }),
						/* @__PURE__ */ f("span", {
							className: "fellowship-goal-owner rounded-md px-1 text-[10px]",
							style: { color: r(a.owner) },
							children: n(a.owner)
						}),
						/* @__PURE__ */ f("span", {
							className: "fellowship-goal-character font-extrabold",
							children: t($[a.character])
						}),
						/* @__PURE__ */ p("span", {
							className: "fellowship-goal-description min-w-0 flex-1",
							children: [
								/* @__PURE__ */ f("span", {
									className: "opacity-75",
									children: ot(o.goal, a.threat, a.threatDir, t)
								}),
								o.extras.map((e, n) => /* @__PURE__ */ p("span", {
									className: "block text-[10px] text-amber-700",
									children: ["✦ ", ot(e, a.threat, a.threatDir, t)]
								}, n)),
								a.special && /* @__PURE__ */ p("span", {
									className: "block text-[10px] text-rose-600",
									children: ["✦ ", t(st[a.special])]
								}),
								a.blind && /* @__PURE__ */ p("span", {
									className: "block text-[10px] text-violet-700",
									children: ["✦ ", t("games.fellowship.blindLabel")]
								}),
								a.hornSuits && a.hornSuits.length > 0 && /* @__PURE__ */ p("span", {
									className: "block text-[10px] opacity-75",
									children: [
										"📯 ",
										t("games.fellowship.hornLabel"),
										": ",
										a.hornSuits.map((e) => t(X[e])).join("/")
									]
								}),
								a.openHand && !i.includes(a.seat) && e.mode !== "solo" && /* @__PURE__ */ f("span", {
									className: "mt-0.5 flex flex-wrap gap-0.5",
									children: a.openHand.map((e) => /* @__PURE__ */ f(Q, {
										card: e,
										size: "mini"
									}, Z(e)))
								})
							]
						}),
						a.aside && /* @__PURE__ */ f("span", {
							className: "flex flex-none items-center gap-0.5",
							title: t("games.fellowship.asideLabel"),
							children: /* @__PURE__ */ f(Q, {
								card: a.aside,
								size: "mini"
							})
						}),
						a.tuckedCount > 0 && /* @__PURE__ */ f("span", {
							className: "flex-none text-[10px]",
							children: "🂠"
						}),
						/* @__PURE__ */ p("span", {
							className: "flex-none font-mono tabular-nums",
							children: ["🃏", a.wonCount]
						})
					]
				}, a.seat);
			})
		}), e.completed.length > 0 && /* @__PURE__ */ p("p", {
			className: "mt-1 text-[10px] font-bold opacity-70",
			children: [
				t("games.fellowship.completedLabel"),
				": ",
				e.completed.map((e) => t($[e])).join(" / ")
			]
		})]
	});
}
//#endregion
//#region src/games/fellowship/bot.ts
function gt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function _t(e) {
	return e >= 14 ? [
		2,
		3,
		4,
		5
	] : e <= 9 ? [
		2,
		3,
		4
	] : [
		3,
		4,
		5
	];
}
var vt = (e) => [...e].sort((e, t) => e.v - t.v)[0], yt = (e) => vt(e.filter((e) => !_(e, g))), bt = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = (e) => r.mySeats.includes(e), a = t.difficulty === "weak", o = (e) => a ? e.length > 0 ? gt(e) : void 0 : vt(e), s = (e, t) => {
		let a = n.seats[e];
		if (!a) return [];
		if (a.pyramid) {
			let e = _t(a.pyramid.length), n = t ? a.pyramid.length - e[e.length - 1] : 0;
			return a.pyramid.filter((e, t) => t >= n && e.card !== null && e.faceUp && !e.covered && !e.pad).map((e) => e.card);
		}
		return a.openHand ? a.openHand : i(e) ? r.hand : [];
	};
	if (n.phase === "choose" && n.chooser !== null && i(n.chooser)) {
		if (n.breaking && n.breaking.picked === null) return { action: {
			type: "pickGroup",
			group: 0
		} };
		let e = n.available.map((e) => e.id);
		if (n.breaking && n.breaking.picked !== null) {
			let t = n.seats.every((e) => e.character === null), r = n.breaking.groups[t ? n.breaking.picked : 1 - n.breaking.picked];
			e = e.filter((e) => r.includes(e));
		} else {
			let t = n.available.filter((e) => e.star).map((e) => e.id);
			t.length > 0 && (e = e.filter((e) => t.includes(e)));
		}
		if (n.mode === "pyramid" && n.chapter > 0) {
			let t = te(n.chapter).blindfolded, r = n.seats.findIndex((e) => e.pyramid !== null);
			t && r >= 0 && (n.chooser === r ? e = e.filter((e) => e !== t) : e.includes(t) && n.seats[r]?.character === null && (e = [t]));
		}
		let t = a && e.length > 0 ? gt(e) : e[0];
		return t ? { action: {
			type: "choose",
			character: t
		} } : null;
	}
	if (n.phase === "moriaPick" && n.moria && n.moria.picker !== null && i(n.moria.picker)) {
		let e = n.moria.done;
		return { action: {
			type: "pickEvent",
			event: e.length >= b.length - 1 ? "bridge" : b.find((t) => t !== "bridge" && !e.includes(t)) ?? "dark"
		} };
	}
	if (n.phase === "setup" && n.setupStep) {
		let e = n.setupStep, t = e.kind === "pass" || e.kind === "exchangeBack" ? (e.pending ?? [e.seat]).find(i) : i(e.seat) ? e.seat : void 0;
		if (t === void 0) return null;
		let r = (e.kind === "exchangeOffer" || e.kind === "exchangeBack" || e.kind === "exchangeLost" ? yt : (e) => yt(e) ?? vt(e))(s(t, !0));
		switch (e.kind) {
			case "give": {
				let t = e.candidates?.[0];
				return t !== void 0 && r ? { action: {
					type: "give",
					to: t,
					card: r
				} } : null;
			}
			case "exchangeOffer": {
				let t = e.candidates?.[0];
				return t !== void 0 && r ? { action: {
					type: "offer",
					to: t,
					card: r
				} } : null;
			}
			case "exchangeBack": return r ? { action: {
				type: "back",
				card: r
			} } : null;
			case "exchangeLost": {
				let t = e.lostOptions?.[0];
				return r && t ? { action: {
					type: "exchangeLost",
					give: r,
					take: t
				} } : null;
			}
			case "threatDir": return { action: {
				type: "threatDir",
				dir: "more"
			} };
			case "chooseThreat": {
				let t = [...e.values ?? []].sort((e, t) => e - t), n = a && t.length > 0 ? gt(t) : t[Math.floor(t.length / 2)];
				return n === void 0 ? null : { action: {
					type: "chooseThreat",
					value: n
				} };
			}
			case "redraw": return { action: {
				type: "redraw",
				again: !1
			} };
			case "pass": return r ? { action: {
				type: "pass",
				card: r
			} } : null;
			case "tuck":
			case "aside":
			case "preplay": return r ? { action: {
				type: e.kind,
				card: r
			} } : null;
		}
	}
	if (n.phase === "play") {
		if (n.pendingDirect !== null) {
			if (!i(n.pendingDirect)) return null;
			let e = n.seats.find((e) => e.character !== null && (e.handCount > 0 || e.tuckedCount > 0 || e.aside !== null));
			return e ? { action: {
				type: "direct",
				seat: e.seat
			} } : null;
		}
		if (n.turn === null || !i(n.turn)) return null;
		let e = n.turn, t = n.seats[e];
		if (!t) return null;
		let a = s(e, !1);
		if (t.aside !== null && (n.totalTricks === null ? n.drawPile === 0 && a.length === 0 && t.tuckedCount === 0 : n.tricksPlayed === n.totalTricks - 1) && t.aside) {
			let e = _(t.aside, g) && r.canDeclareRing;
			return { action: {
				type: "play",
				card: t.aside,
				...e ? { declare: !0 } : {}
			} };
		}
		let c = t.aside ? a.filter((e) => !_(e, t.aside)) : [...a];
		if (t.tuckedCount > 0 && r.tucked && c.push(r.tucked), r.mustFollow) {
			let e = c.filter((e) => e.s === r.mustFollow);
			e.length > 0 && (c = e);
		}
		let l = n.trick.plays.length === 0;
		if (l) {
			!n.broken && c.some((e) => e.s !== "rings") && (c = c.filter((e) => e.s !== "rings"));
			let e = t.special ? ee[t.special] : void 0;
			e && c.some((t) => t.s !== e) && (c = c.filter((t) => t.s !== e));
		}
		if (c.length === 0) return null;
		let u = c.find((e) => _(e, g));
		if (!l && u && r.canDeclareRing && n.trick.plays.some((e) => e.card.s === "rings")) return { action: {
			type: "play",
			card: u,
			declare: !0
		} };
		let d = o(c);
		return d ? { action: {
			type: "play",
			card: d
		} } : null;
	}
	return null;
}, xt = {
	0: "games.fellowship.ch0",
	1: "games.fellowship.ch1",
	2: "games.fellowship.ch2",
	3: "games.fellowship.ch3",
	4: "games.fellowship.ch4",
	5: "games.fellowship.ch5",
	6: "games.fellowship.ch6",
	7: "games.fellowship.ch7",
	8: "games.fellowship.ch8",
	9: "games.fellowship.ch9",
	10: "games.fellowship.ch10",
	11: "games.fellowship.ch11",
	12: "games.fellowship.ch12",
	13: "games.fellowship.ch13",
	14: "games.fellowship.ch14",
	15: "games.fellowship.ch15",
	16: "games.fellowship.ch16",
	17: "games.fellowship.ch17",
	18: "games.fellowship.ch18"
};
function St({ value: e, onChange: t }) {
	let n = r(), i = A.safeParse(e), a = i.success ? i.data : A.parse(void 0);
	return /* @__PURE__ */ p(h, {
		title: n("games.fellowship.optChapter"),
		children: [/* @__PURE__ */ f(m, {
			name: "fellowship-chapter",
			value: "0",
			checked: a.chapter === 0,
			label: n(xt[0]),
			accent: z.accent,
			onChange: () => t({ chapter: 0 })
		}), w.map((e) => {
			let r = E.includes(e.n);
			return /* @__PURE__ */ f(m, {
				name: "fellowship-chapter",
				value: String(e.n),
				checked: a.chapter === e.n,
				disabled: !r,
				label: /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ p("span", {
						className: "font-mono tabular-nums",
						children: [e.n, "."]
					}),
					" ",
					n(xt[e.n])
				] }),
				accent: z.accent,
				onChange: () => t({ chapter: e.n })
			}, e.n);
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fellowship/entry.tsx
var Ct = {
	definition: Qe,
	View: rt,
	bot: bt,
	Options: St,
	locales: {
		zh: {
			name: "魔戒同盟",
			desc: "合作吃墩:扮演远征队角色,各自达成目标护送魔戒",
			rules: "目标:全队通过牌墩合作,每名角色完成自己的目标;全部达成则章节胜利,任一目标失败则全队失败,可重试。\n牌:\n· 丘陵、山脉、暗影和森林四种花色各有数字1至8的牌，魔戒花色有数字1至5的牌。\n· 必须跟花色;领出花色中点数最大者赢墩。\n· 魔戒不是将牌:魔戒花色被打破前不能领出(手上只剩魔戒牌除外);任何人打出魔戒牌后即告打破。\n· 至尊戒（魔戒花色的1号牌）:打出时可声明赢下本墩,无视花色与点数。\n流程:\n· 拿到至尊戒的玩家是持戒者,自动扮演弗罗多并领出第一墩。\n· 其余玩家从持戒者左手边依次选择角色,带星标的角色必须全部有人扮演。\n· 部分角色有准备动作:抽威胁牌、与其他角色交换手牌等。\n章节:\n· 短章节只进行一轮。长章节进行多轮，并保留已经完成目标的角色进度；全部角色完成各自目标后，章节成功。",
			optChapter: "章节",
			chapterChip: "第 {{n}} 章",
			roundChip: "第 {{n}} 轮",
			trickChip: "第 {{n}}/{{total}} 墩",
			ch1: "盼望已久的宴会",
			ch2: "夏尔的小耽搁",
			ch3: "魔戒启程",
			ch4: "克里克谷的密谋",
			ch5: "老林子",
			ch6: "古冢迷雾",
			ch7: "跃马客栈",
			ch8: "黑暗中的刀锋",
			ch9: "渡口逃亡",
			ch10: "幽谷休养",
			ch11: "埃尔隆德的会议",
			ch12: "艾森加德之阻",
			ch13: "魔戒南行",
			ch14: "墨瑞亚矿坑",
			ch15: "洛丝罗瑞恩的树叶",
			ch16: "加拉德瑞尔的水镜",
			ch17: "大河",
			ch18: "同盟决裂",
			suitHills: "丘陵",
			suitMountains: "山脉",
			suitShadows: "暗影",
			suitForests: "森林",
			suitRings: "魔戒",
			suitRiver: "大河",
			chars: {
				frodo: "弗罗多",
				frodo3: "弗罗多",
				bilbo: "比尔博",
				gandalf: "甘道夫",
				pippin: "皮平",
				sam: "山姆",
				merry: "梅里",
				gildor: "吉尔多",
				maggot: "马戈特",
				fatty: "小胖博尔杰",
				tom: "汤姆·邦巴迪尔",
				goldberry: "金莓",
				underhill: "山下先生",
				barliman: "巴利曼",
				strider: "大步佬",
				glorfindel: "格罗芬德尔",
				bill: "小马比尔",
				elrond: "埃尔隆德",
				arwen: "阿尔玟",
				gloin: "格罗因",
				bilbo2: "比尔博",
				aragorn: "阿拉贡",
				boromir: "波洛米尔",
				gwaihir: "格怀希尔",
				shadowfax: "影疾",
				radagast: "拉达加斯特",
				legolas: "莱戈拉斯",
				gimli: "吉姆利",
				orophin: "欧洛芬与卢米尔",
				haldir: "哈尔迪尔",
				galadriel: "加拉德瑞尔",
				celeborn: "凯勒博恩",
				gandalf2: "甘道夫",
				sam2: "山姆",
				sam2b: "山姆(负重)",
				pippin2: "皮平",
				pippin2b: "皮平(负重)",
				merry2: "梅里",
				merry2b: "梅里(负重)",
				aragorn2: "阿拉贡",
				aragorn2b: "阿拉贡(负重)",
				boromir2: "波洛米尔",
				boromir2b: "波洛米尔(负重)",
				legolas2b: "莱戈拉斯(负重)",
				gimli2b: "吉姆利(负重)"
			},
			goals: {
				none: "无目标:完成本章即可",
				winCards: "赢下至少 {{n}} 张{{suits}}牌",
				winAllOfSuit: "赢下全部 8 张{{suit}}牌",
				tricksAtLeast: "赢下至少 {{n}} 墩",
				tricksExact: "恰好赢 {{n}} 墩",
				tricksRange: "赢 {{min}} 或 {{max}} 墩",
				tricksLeast: "赢的墩数最少(可以并列)",
				tricksMiddle: "赢的墩数居中(不能并列)",
				threatCard: "赢下点数为 {{threat}} 的{{suits}}牌",
				threatCardAny: "赢下至少 {{n}} 张点数为 {{threat}} 的牌",
				tricksEqualThreat: "恰好赢 {{threat}} 墩",
				tricksVsThreat: "赢的墩数多于或少于威胁值(准备时选择)",
				tricksVsThreatMore: "赢的墩数多于 {{threat}}",
				tricksVsThreatLess: "赢的墩数少于 {{threat}}",
				lastTrickPlay: "在最后一墩打出{{suits}}牌(不必赢)",
				winLastTrick: "赢下最后一墩",
				winInLastTricks: "最后 {{n}} 墩内至少赢 1 墩",
				tricksWithRing: "至少赢 1 墩,且每个赢墩都含魔戒牌",
				consecutiveTricks: "恰好连赢 {{n}} 墩,不多不少",
				lostSuitCards: "赢下至少 {{n}} 张与轮末留牌同花色的牌",
				mostCards: "赢下的{{suit}}牌最多(可以并列)",
				mostCardsExclusive: "独自赢下的{{suit}}牌最多",
				sameValueCards: "赢下至少 {{n}} 张点数相同的牌",
				tricksWithSuit: "赢下至少 {{n}} 墩含{{suit}}牌的墩",
				allWinRing: "每名角色都额外赢下至少 1 张魔戒牌",
				zeroAndOthersWin: "自己一墩不赢,其余角色各赢至少 1 墩",
				consecutiveValues: "赢下 {{n}} 张点数连续的{{suit}}牌",
				winEachSuit: "每种花色各赢至少 1 张:{{suits}}",
				tricksRangeThreat: "赢 {{min}} 或 {{max}} 墩",
				winEachRank: "赢下 1~8 每个点数的牌各 1 张(至尊戒计 1)",
				noWinValue: "不得赢得任何点数 {{v}} 的牌",
				failIfRing1: "若赢得至尊戒则失败",
				failIfAnyRing: "若赢得任何魔戒牌则失败"
			},
			specials: {
				witchking: "巫王:不能领出魔戒牌,被迫领出则本轮失败",
				blackbreath: "黑息:不得赢得任何 8 点牌",
				wraith: "戒灵:不能参与任何交换",
				unseen: "隐匿:威胁值对他人保密,直到目标完成",
				terror: "恐惧:不能领出丘陵牌,被迫领出则本轮失败"
			},
			lostCardLabel: "迷失牌",
			threatLabel: "威胁 {{n}}",
			brokenLabel: "魔戒已破",
			omwLabel: "老柳头",
			omwStolen: "老柳头抢走了这一墩",
			hornLabel: "号角:最多的花色",
			tuckedLabel: "扣牌",
			asideLabel: "末墩扣牌",
			ringBearerYou: "你拿到了至尊戒,自动扮演持戒者",
			playCard: "出牌",
			cancel: "取消",
			exchangeBackConfirm: "回赠这张牌",
			choosePrompt: "轮到你选择角色",
			chooseWaiting: "等待 {{name}} 选择角色…",
			starBadge: "必选",
			givePrompt: "给其他每位角色各 1 张牌",
			giveWaiting: "等待 {{name}} 分牌…",
			exchangePrompt: "选择 1 张牌发起交换",
			exchangeWaiting: "等待 {{name}} 交换…",
			exchangeBackPrompt: "{{name}} 递给你 1 张牌,选择 1 张回赠",
			exchangeBackWaiting: "等待 {{name}} 回赠…",
			threatDirPrompt: "选择:赢的墩数多于还是少于威胁值 {{n}}",
			threatDirMore: "多于 {{n}} 墩",
			threatDirLess: "少于 {{n}} 墩",
			threatDirWaiting: "等待 {{name}} 选择威胁方向…",
			chooseThreatPrompt: "从威胁牌堆选择 1 张",
			chooseThreatWaiting: "等待 {{name}} 选择威胁牌…",
			passPrompt: "选择 1 张牌传给右手边的角色",
			passWaiting: "等待全员传牌…",
			tuckPrompt: "选择 1 张牌扣在角色卡下(之后可随时打出)",
			asidePrompt: "选择 1 张牌明置扣下,将在最后一墩强制打出",
			preplayPrompt: "选择 1 张牌预打进第一墩(该墩你不再出牌)",
			setupCardWaiting: "等待 {{name}} 准备…",
			directPrompt: "你赢下一墩:指定下一墩的领出者",
			directWaiting: "等待 {{name}} 指定领出者…",
			turnYou: "轮到你出牌",
			turnWait: "等待 {{name}} 出牌…",
			declareRing: "声明至尊戒:赢下本墩",
			won: "章节完成!",
			lost: "目标失败,本章未通过",
			failedBy: "{{name}} 的目标未能达成",
			retry: "重试本章",
			nextRound: "进入下一轮",
			completedLabel: "已完成",
			errPhase: "现在不能这么做",
			errTurn: "还没轮到你",
			errCharacter: "这个角色不可选",
			errStar: "必须先选带星标的角色",
			errCard: "没有这张牌",
			errGive: "不能给这位角色",
			errExchange: "不能与这位角色交换",
			errRingSwap: "持戒者不能换出至尊戒",
			errLeadRing: "魔戒未被打破,不能领出魔戒牌",
			errLeadThreat: "威胁限制:不能领出这个花色",
			errFollow: "必须跟花色",
			errDeclare: "只有至尊戒能声明赢墩",
			errThreat: "这个威胁值不可选",
			errDirect: "该角色无法领出下一墩",
			errAside: "最后一墩必须打出扣下的牌",
			errGroup: "只能在本组/另一组中选择角色",
			errEvent: "这个事件现在不可选",
			ch0: "长路漫漫",
			moriaEvents: {
				doors: "都林之门",
				tomb: "巴林之墓",
				dark: "长暗",
				bridge: "凯萨督姆之桥"
			},
			gifts: {
				mithril: "秘银甲",
				sting: "刺叮",
				glamdring: "格拉姆德凛",
				sword: "断剑",
				horn: "号角"
			},
			moriaPickPrompt: "选择本轮要面对的墨瑞亚事件",
			moriaPickWaiting: "等待 {{name}} 选择墨瑞亚事件…",
			moriaDoneLabel: "已通过的事件",
			pickGroupPrompt: "持戒者,先选择你要加入的一组",
			pickGroupWaiting: "等待持戒者选择组别…",
			groupPick: "选这组",
			groupLabel: "第 {{n}} 组",
			groupBearerTag: "持戒者",
			darkLabel: "长暗:威胁值全部隐藏",
			redrawPrompt: "要把威胁牌 {{n}} 放回堆底重抽一次吗?",
			redrawKeep: "保留 {{n}}",
			redrawAgain: "重抽一次",
			redrawWaiting: "等待 {{name}} 决定是否重抽威胁牌…",
			exchangeLostPrompt: "用 1 张手牌换 1 张迷失牌",
			exchangeLostWaiting: "等待 {{name}} 与迷失牌交换…",
			skipSetup: "跳过(本轮不再交换)",
			pyramidLabel: "金字塔",
			pyramidCovered: "被压住",
			pyramidPad: "轮末留牌",
			drawPileLabel: "抽牌堆 ×{{n}}",
			blindLabel: "盲打",
			balrogLabel: "炎魔堆 ×{{n}}",
			balrogSumLabel: "炎魔堆翻出 {{sum}} 点",
			mithrilReady: "秘银甲可用",
			mithrilUsed: "秘银甲已用",
			giftLabel: "礼物"
		},
		en: {
			name: "Fellowship of the Ring",
			desc: "Co-op trick-taking: play fellowship characters and fulfil every goal",
			rules: "Goal: cooperate through tricks — every character must complete their own goal; all goals met wins the chapter, any single failure loses the round (retry allowed).\nCards:\n· Hills, Mountains, Shadows and Forests of 1–8, plus Rings 1–5.\n· You must follow suit; the highest card of the led suit wins the trick.\n· Rings are not trump: they cannot be led until the ring suit is broken (someone has played a ring), unless you hold only rings.\n· The One Ring (Ring 1): when played, you may declare it to win any trick.\nFlow:\n· The player dealt the One Ring is the ring-bearer, plays Frodo and leads the first trick.\n· Starting to the ring-bearer’s left, players pick characters in turn; every starred character must be picked.\n· Some characters have setup steps: drawing threat cards, exchanging cards with others, and so on.\nChapters:\n· Short chapters last one round; long chapters run several rounds and keep completed characters — finish them all to clear the chapter.",
			optChapter: "Chapter",
			chapterChip: "Chapter {{n}}",
			roundChip: "Round {{n}}",
			trickChip: "Trick {{n}}/{{total}}",
			ch1: "A Long-expected Party",
			ch2: "A Little Delay in the Shire",
			ch3: "The Ring Sets Out",
			ch4: "A Conspiracy in Crickhollow",
			ch5: "The Old Forest",
			ch6: "Fog on the Barrow-downs",
			ch7: "At the Sign of the Prancing Pony",
			ch8: "A Knife in the Dark",
			ch9: "Flight to the Ford",
			ch10: "Recovery in Rivendell",
			ch11: "The Council of Elrond",
			ch12: "Delayed in Isengard",
			ch13: "The Ring Goes South",
			ch14: "The Mines of Moria",
			ch15: "The Leaves of Lothlórien",
			ch16: "Mirror of Galadriel",
			ch17: "The Great River",
			ch18: "The Breaking of the Fellowship",
			suitHills: "Hills",
			suitMountains: "Mountains",
			suitShadows: "Shadows",
			suitForests: "Forests",
			suitRings: "Rings",
			suitRiver: "River",
			chars: {
				frodo: "Frodo",
				frodo3: "Frodo",
				bilbo: "Bilbo",
				gandalf: "Gandalf",
				pippin: "Pippin",
				sam: "Sam",
				merry: "Merry",
				gildor: "Gildor",
				maggot: "Farmer Maggot",
				fatty: "Fatty Bolger",
				tom: "Tom Bombadil",
				goldberry: "Goldberry",
				underhill: "Mr. Underhill",
				barliman: "Barliman",
				strider: "Strider",
				glorfindel: "Glorfindel",
				bill: "Bill the Pony",
				elrond: "Elrond",
				arwen: "Arwen",
				gloin: "Glóin",
				bilbo2: "Bilbo",
				aragorn: "Aragorn",
				boromir: "Boromir",
				gwaihir: "Gwaihir",
				shadowfax: "Shadowfax",
				radagast: "Radagast",
				legolas: "Legolas",
				gimli: "Gimli",
				orophin: "Orophin & Rúmil",
				haldir: "Haldir",
				galadriel: "Galadriel",
				celeborn: "Celeborn",
				gandalf2: "Gandalf",
				sam2: "Sam",
				sam2b: "Sam (Burdened)",
				pippin2: "Pippin",
				pippin2b: "Pippin (Burdened)",
				merry2: "Merry",
				merry2b: "Merry (Burdened)",
				aragorn2: "Aragorn",
				aragorn2b: "Aragorn (Burdened)",
				boromir2: "Boromir",
				boromir2b: "Boromir (Burdened)",
				legolas2b: "Legolas (Burdened)",
				gimli2b: "Gimli (Burdened)"
			},
			goals: {
				none: "No goal: just finish the chapter",
				winCards: "Win at least {{n}} {{suits}} cards",
				winAllOfSuit: "Win all 8 {{suit}} cards",
				tricksAtLeast: "Win at least {{n}} tricks",
				tricksExact: "Win exactly {{n}} tricks",
				tricksRange: "Win {{min}} or {{max}} tricks",
				tricksLeast: "Win the fewest tricks (ties allowed)",
				tricksMiddle: "Win a middle number of tricks (no ties)",
				threatCard: "Win the {{suits}} card of value {{threat}}",
				threatCardAny: "Win at least {{n}} cards of value {{threat}}",
				tricksEqualThreat: "Win exactly {{threat}} tricks",
				tricksVsThreat: "Win more or fewer tricks than the threat (you choose at setup)",
				tricksVsThreatMore: "Win more than {{threat}} tricks",
				tricksVsThreatLess: "Win fewer than {{threat}} tricks",
				lastTrickPlay: "Play a {{suits}} card on the last trick (no need to win)",
				winLastTrick: "Win the last trick",
				winInLastTricks: "Win at least 1 of the last {{n}} tricks",
				tricksWithRing: "Win at least 1 trick, every won trick holding a ring",
				consecutiveTricks: "Win exactly {{n}} tricks in a row, no more, no less",
				lostSuitCards: "Win at least {{n}} cards matching a suit left in your hand at round’s end",
				mostCards: "Win the most {{suit}} cards (ties allowed)",
				mostCardsExclusive: "Win strictly the most {{suit}} cards",
				sameValueCards: "Win at least {{n}} cards of the same value",
				tricksWithSuit: "Win at least {{n}} tricks containing a {{suit}} card",
				allWinRing: "Every character also wins at least 1 ring card",
				zeroAndOthersWin: "Win no tricks while every other character wins at least 1",
				consecutiveValues: "Win {{n}} {{suit}} cards of consecutive values",
				winEachSuit: "Win at least 1 card of each: {{suits}}",
				tricksRangeThreat: "Win {{min}} or {{max}} tricks",
				winEachRank: "Win one card of every rank 1–8 (the One Ring counts as 1)",
				noWinValue: "Win no card of rank {{v}}",
				failIfRing1: "Lose if you win the One Ring",
				failIfAnyRing: "Lose if you win any ring card"
			},
			specials: {
				witchking: "Witch-king: cannot lead rings; forced to, the round is lost",
				blackbreath: "Black Breath: win no card of rank 8",
				wraith: "Wraith: cannot take part in any exchange",
				unseen: "Unseen: threat value hidden from others until the goal is done",
				terror: "Terror: cannot lead hills; forced to, the round is lost"
			},
			lostCardLabel: "Lost card",
			threatLabel: "Threat {{n}}",
			brokenLabel: "Ring suit broken",
			omwLabel: "Old Man Willow",
			omwStolen: "Old Man Willow stole the trick",
			hornLabel: "Horn: most-held suits",
			tuckedLabel: "Tucked",
			asideLabel: "Last-trick card",
			ringBearerYou: "You hold the One Ring — you are the ring-bearer",
			playCard: "Play",
			cancel: "Cancel",
			exchangeBackConfirm: "Send this card back",
			choosePrompt: "Pick your character",
			chooseWaiting: "Waiting for {{name}} to pick a character…",
			starBadge: "Required",
			givePrompt: "Give 1 card to every other character",
			giveWaiting: "Waiting for {{name}} to deal out cards…",
			exchangePrompt: "Pick 1 card to offer for exchange",
			exchangeWaiting: "Waiting for {{name}} to exchange…",
			exchangeBackPrompt: "{{name}} passed you a card — pick 1 to send back",
			exchangeBackWaiting: "Waiting for {{name}} to pass back…",
			threatDirPrompt: "Choose: win more or fewer tricks than threat {{n}}",
			threatDirMore: "More than {{n}}",
			threatDirLess: "Fewer than {{n}}",
			threatDirWaiting: "Waiting for {{name}} to choose a threat direction…",
			chooseThreatPrompt: "Pick 1 card from the threat deck",
			chooseThreatWaiting: "Waiting for {{name}} to pick a threat card…",
			passPrompt: "Pick 1 card to pass to the character on your right",
			passWaiting: "Waiting for everyone to pass…",
			tuckPrompt: "Tuck 1 card under your character (playable any time later)",
			asidePrompt: "Set 1 card aside face-up; it must be played on the last trick",
			preplayPrompt: "Pre-play 1 card into the first trick (you sit that trick out)",
			setupCardWaiting: "Waiting for {{name}} to prepare…",
			directPrompt: "You won a trick: choose who leads the next one",
			directWaiting: "Waiting for {{name}} to choose the next leader…",
			turnYou: "Your turn to play",
			turnWait: "Waiting for {{name}} to play…",
			declareRing: "Declare the One Ring: win this trick",
			won: "Chapter complete!",
			lost: "A goal failed — chapter not cleared",
			failedBy: "{{name}} failed their goal",
			retry: "Retry this chapter",
			nextRound: "Next round",
			completedLabel: "Completed",
			errPhase: "Not allowed right now",
			errTurn: "Not your turn",
			errCharacter: "That character is not available",
			errStar: "Starred characters must be picked first",
			errCard: "You do not have that card",
			errGive: "Cannot give to that character",
			errExchange: "Cannot exchange with that character",
			errRingSwap: "The ring-bearer cannot trade away the One Ring",
			errLeadRing: "Rings cannot be led until the suit is broken",
			errLeadThreat: "Your threat forbids leading that suit",
			errFollow: "You must follow suit",
			errDeclare: "Only the One Ring can be declared",
			errThreat: "That threat value is not available",
			errDirect: "That character cannot lead the next trick",
			errAside: "The set-aside card must be played on the last trick",
			errGroup: "You may only pick from your own / the other group",
			errEvent: "That event is not available now",
			ch0: "The Road Goes Ever On",
			moriaEvents: {
				doors: "Doors of Durin",
				tomb: "Balin's Tomb",
				dark: "The Long Dark",
				bridge: "Bridge of Khazad-dûm"
			},
			gifts: {
				mithril: "Mithril Coat",
				sting: "Sting",
				glamdring: "Glamdring",
				sword: "The Broken Sword",
				horn: "Horn"
			},
			moriaPickPrompt: "Pick the Moria event for this round",
			moriaPickWaiting: "Waiting for {{name}} to pick a Moria event…",
			moriaDoneLabel: "Cleared events",
			pickGroupPrompt: "Ring-bearer: pick your group first",
			pickGroupWaiting: "Waiting for the ring-bearer to pick a group…",
			groupPick: "Pick this group",
			groupLabel: "Group {{n}}",
			groupBearerTag: "Ring-bearer",
			darkLabel: "The Long Dark: all threats hidden",
			redrawPrompt: "Put threat {{n}} on the bottom and draw again?",
			redrawKeep: "Keep {{n}}",
			redrawAgain: "Draw again",
			redrawWaiting: "Waiting for {{name}} to decide on redrawing…",
			exchangeLostPrompt: "Trade 1 hand card for 1 lost card",
			exchangeLostWaiting: "Waiting for {{name}} to trade with the lost cards…",
			skipSetup: "Skip (no more exchanges this round)",
			pyramidLabel: "Pyramid",
			pyramidCovered: "Covered",
			pyramidPad: "Leftover",
			drawPileLabel: "Draw pile ×{{n}}",
			blindLabel: "Blind",
			balrogLabel: "Balrog pile ×{{n}}",
			balrogSumLabel: "Balrog pile revealed {{sum}}",
			mithrilReady: "Mithril available",
			mithrilUsed: "Mithril used",
			giftLabel: "Gift"
		}
	}
};
//#endregion
export { Ct as default };
