import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { botAvatarOf as r } from "@bgparty/sdk/lobby";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as a, useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { Texture as c } from "@bgparty/sdk/texture";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g } from "@bgparty/sdk/fx/primitives";
import { playBell as _, playSettle as v } from "@bgparty/sdk/sfx";
import { GameOverScreen as ee } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/lacuenta/cards.ts
var y = [
	"vegetal",
	"carne",
	"pescado"
], b = [
	10,
	20,
	30,
	40,
	50,
	60,
	70,
	100
], te = {
	vegetal: [
		"games.lacuenta.dish.aceitunas",
		"games.lacuenta.dish.gazpacho",
		"games.lacuenta.dish.patatasBravas",
		"games.lacuenta.dish.tortilla",
		"games.lacuenta.dish.pimientos",
		"games.lacuenta.dish.ensaladilla",
		"games.lacuenta.dish.berenjenas",
		"games.lacuenta.dish.tablaQuesos"
	],
	carne: [
		"games.lacuenta.dish.chorizo",
		"games.lacuenta.dish.croquetas",
		"games.lacuenta.dish.albondigas",
		"games.lacuenta.dish.pinchito",
		"games.lacuenta.dish.morcilla",
		"games.lacuenta.dish.callos",
		"games.lacuenta.dish.raboDeToro",
		"games.lacuenta.dish.jamon"
	],
	pescado: [
		"games.lacuenta.dish.mejillones",
		"games.lacuenta.dish.sardinas",
		"games.lacuenta.dish.calamares",
		"games.lacuenta.dish.chipirones",
		"games.lacuenta.dish.anchoa",
		"games.lacuenta.dish.pulpo",
		"games.lacuenta.dish.gambas",
		"games.lacuenta.dish.percebes"
	]
}, ne = {
	vegetal: [
		"🫒",
		"🥣",
		"🥔",
		"🍳",
		"🫑",
		"🥗",
		"🍆",
		"🧀"
	],
	carne: [
		"🌭",
		"🍘",
		"🧆",
		"🍢",
		"🥓",
		"🍲",
		"🥩",
		"🍖"
	],
	pescado: [
		"🦪",
		"🐟",
		"🦑",
		"🍤",
		"🐠",
		"🐙",
		"🦐",
		"🐚"
	]
};
function re(e) {
	return e.kind !== "tapa" || !e.tapa ? null : ne[e.tapa][b.indexOf(e.value)] ?? null;
}
var x = {
	vino: "games.lacuenta.card.vino",
	quemado: "games.lacuenta.card.quemado",
	cambio: "games.lacuenta.card.cambio",
	premium: "games.lacuenta.card.premium",
	toilette: "games.lacuenta.card.toilette",
	cafe: "games.lacuenta.card.cafe",
	pastel: "games.lacuenta.card.pastel",
	medias: "games.lacuenta.card.medias",
	pachas: "games.lacuenta.card.pachas",
	propina: "games.lacuenta.card.propina"
}, S = [
	0,
	-10,
	-20,
	-30,
	-40,
	-50,
	-60,
	-70
];
function C() {
	let e = [];
	for (let t of y) b.forEach((n, r) => {
		for (let i = 0; i < 2; i += 1) e.push({
			id: e.length,
			kind: "tapa",
			tapa: t,
			value: n,
			nameKey: te[t][r]
		});
	});
	for (let t = 0; t < 10; t += 1) e.push({
		id: e.length,
		kind: "vino",
		nameKey: x.vino
	});
	for (let t of S) e.push({
		id: e.length,
		kind: "quemado",
		value: t,
		nameKey: x.quemado
	});
	for (let t = 0; t < 4; t += 1) e.push({
		id: e.length,
		kind: "cambio",
		nameKey: x.cambio
	});
	for (let t = 0; t < 4; t += 1) e.push({
		id: e.length,
		kind: "premium",
		nameKey: x.premium
	});
	for (let t = 0; t < 5; t += 1) e.push({
		id: e.length,
		kind: "toilette",
		nameKey: x.toilette
	});
	for (let t = 0; t < 10; t += 1) e.push({
		id: e.length,
		kind: "cafe",
		nameKey: x.cafe
	});
	e.push({
		id: e.length,
		kind: "pastel",
		value: 40,
		nameKey: x.pastel
	});
	for (let t = 0; t < 3; t += 1) e.push({
		id: e.length,
		kind: "medias",
		nameKey: x.medias
	});
	e.push({
		id: e.length,
		kind: "pachas",
		nameKey: x.pachas
	});
	for (let t = 0; t < 6; t += 1) e.push({
		id: e.length,
		kind: "propina",
		nameKey: x.propina
	});
	return e;
}
var w = C();
function T(e) {
	let t = w[e];
	if (!t) throw Error(`lacuenta 卡 id 越界: ${e}`);
	return t;
}
var E = [
	30,
	60,
	120,
	180,
	240
];
function D(e) {
	return E[e % E.length];
}
var O = {
	3: 900,
	4: 1e3,
	5: 1100,
	6: 1200,
	7: 1300,
	8: 1400
}, k = {
	id: "lacuenta",
	tier: "beta",
	mechanics: ["hand-management"],
	interactionTags: [],
	nameKey: "games.lacuenta.name",
	descKey: "games.lacuenta.desc",
	rulesKey: "games.lacuenta.rules",
	icon: "🧾",
	iconImg: "games/lacuenta.webp",
	rulesUrl: { es: "https://rules.bgparty.uuppi.com/lacuenta/es.pdf" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [6],
	accent: "#0d9488",
	releasedAt: "2026-09-25",
	search: {
		py: "shui lai mai dan",
		init: "slmd"
	},
	hotseat: "cover"
}, A = t.int().min(0).max(99), j = t.string(), M = t.enum([
	"vegetal",
	"carne",
	"pescado"
]), N = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: A,
		premiums: t.array(A).max(4).optional(),
		column: M.optional()
	}),
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("askBill") }),
	t.object({
		type: t.literal("tip"),
		card: A
	}),
	t.object({
		type: t.literal("split"),
		card: A,
		target: j.optional()
	}),
	t.object({ type: t.literal("billDone") }),
	t.object({
		type: t.literal("discard"),
		cards: t.array(A)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), P = t.object({
	card: A,
	premiums: t.array(A)
}), F = t.object({
	by: j,
	forced: t.boolean(),
	tips: t.array(t.object({
		card: A,
		by: j
	})),
	split: t.union([t.object({
		kind: t.literal("medias"),
		card: A,
		target: j
	}), t.object({
		kind: t.literal("pachas"),
		card: A
	})]).nullable(),
	confirmed: t.array(j)
}), ie = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"play",
		"bill",
		"discard",
		"done"
	]),
	direction: t.union([t.literal(1), t.literal(-1)]),
	activeRid: j,
	deckCount: t.int().nonnegative(),
	columns: t.object({
		vegetal: t.array(P),
		carne: t.array(P),
		pescado: t.array(P)
	}),
	blocked: t.object({
		vegetal: t.boolean(),
		carne: t.boolean(),
		pescado: t.boolean()
	}),
	quemados: t.array(t.object({
		card: A,
		column: M,
		premiums: t.array(A)
	})),
	extras: t.array(t.object({
		card: A,
		by: j
	})),
	wines: t.array(A),
	playedCount: t.int().nonnegative(),
	threshold: t.int().positive(),
	cafe: t.boolean(),
	toilet: t.array(j),
	birthday: j.nullable(),
	players: t.array(t.object({
		rid: j,
		savings: t.int(),
		handCount: t.int().nonnegative(),
		handLimit: t.int().positive()
	})),
	bill: F.nullable(),
	settle: t.object({
		by: j,
		total: t.int(),
		paid: t.record(j, t.int().nonnegative()),
		thresholdMet: t.boolean()
	}).nullable(),
	discardRid: j.nullable(),
	billTotal: t.int(),
	cheapestTapa: t.int().positive().nullable()
}), I = t.object({ hand: t.array(A) }), L = 2e4, R = 15e3;
function z(e, t) {
	return (T(e).value ?? 0) * 2 ** t;
}
function ae(e, t) {
	let n = e.columns[t];
	if (!n.length) return null;
	let r = n[n.length - 1];
	return z(r.card, r.premiums.length);
}
function B(e) {
	let t = null;
	for (let n of y) for (let r of e.columns[n]) {
		let e = z(r.card, r.premiums.length);
		(t === null || e < t) && (t = e);
	}
	return t;
}
function V(e) {
	let t = 0;
	for (let n = 0; n < e; n += 1) t += D(n);
	return t;
}
function H(e) {
	let t = V(e.wines.length);
	for (let n of y) for (let r of e.columns[n]) t += z(r.card, r.premiums.length);
	for (let n of e.quemados) t += z(n.card, n.premiums.length);
	for (let n of e.extras) T(n.card).kind === "pastel" && (t += T(n.card).value ?? 0);
	return t += (e.bill?.tips.length ?? 0) * (B(e) ?? 0), t;
}
function U(e) {
	let t = new Set(e.toilet);
	return e.birthday && t.add(e.birthday), t;
}
function W(e, t, n, r) {
	let i = T(t);
	if (n > 0 && i.kind !== "tapa" && i.kind !== "quemado") return !1;
	switch (i.kind) {
		case "tapa": {
			if (e.cafe || !i.tapa || e.blocked[i.tapa]) return !1;
			let r = ae(e, i.tapa);
			return r === null || z(t, n) >= r;
		}
		case "quemado": return !e.cafe && r !== void 0 && !e.blocked[r];
		case "vino":
		case "cambio":
		case "pastel": return !e.cafe;
		case "toilette": return !0;
		case "cafe": return y.every((t) => e.columns[t].length > 0);
		default: return !1;
	}
}
function oe(e, t) {
	let n = t.filter((e) => T(e).kind === "premium").length;
	return t.some((t) => {
		let r = T(t);
		return r.kind === "quemado" ? W(e, t, 0, y.find((t) => !e.blocked[t])) : W(e, t, r.kind === "tapa" ? n : 0);
	});
}
function G(e, t, n, r, i) {
	return e.phase !== "play" || e.players[e.activeIdx] !== t || !e.hands[t]?.includes(n) ? !1 : W(e, n, r, i);
}
function K(e, t) {
	return e.phase !== "play" || e.players[e.activeIdx] !== t ? !1 : oe(e, e.hands[t] ?? []);
}
function q(e, t) {
	return e.phase === "play" && e.players[e.activeIdx] === t && e.birthday !== t && !K(e, t);
}
var J = (e) => ({ code: e });
function se(t, n) {
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.seed, t.rngCursor, r + 1);
		t.rngCursor += 1, [n[r], n[i]] = [n[i], n[r]];
	}
}
function Y(e, t) {
	let n = [];
	for (let r = 0; r < t; r += 1) {
		if (e.deck.length === 0) {
			if (e.discard.length === 0) break;
			e.deck = e.discard.splice(0), se(e, e.deck);
		}
		n.push(e.deck.pop());
	}
	return n;
}
function ce(t, n, r) {
	let i = {
		players: n,
		seed: r,
		rngCursor: 0,
		round: 1,
		phase: "play",
		direction: 1,
		activeIdx: 0,
		hands: {},
		handLimit: {},
		savings: {},
		deck: [],
		discard: [],
		columns: {
			vegetal: [],
			carne: [],
			pescado: []
		},
		blocked: {
			vegetal: !1,
			carne: !1,
			pescado: !1
		},
		quemados: [],
		extras: [],
		wines: [],
		playedCount: 0,
		cafe: !1,
		toilet: [],
		birthday: null,
		bill: null,
		settle: null,
		discardRid: null,
		beatMs: 0
	}, a = O[n.length] ?? 1e3;
	for (let e of n) i.hands[e] = [], i.handLimit[e] = 5, i.savings[e] = a;
	i.deck = w.map((e) => e.id), se(i, i.deck), i.activeIdx = e(i.seed, i.rngCursor, n.length), i.rngCursor += 1;
	let o = [];
	for (let e of n) {
		let t = Y(i, 5);
		i.hands[e] = t, o.push({
			kind: "deal",
			rid: e,
			data: { count: t.length },
			for: [e],
			secret: { cards: t },
			...o.length > 0 ? { with: !0 } : {}
		});
	}
	return {
		state: i,
		fx: o
	};
}
function le(e) {
	let t = e.players.length;
	e.activeIdx = (e.activeIdx + e.direction + t) % t, e.toilet = e.toilet.filter((t) => t !== e.players[e.activeIdx]);
}
function ue(e) {
	let t = e.bill, n = H(e), r = Math.max(0, n), i = U(e), a = {};
	if (t.split?.kind === "medias" && t.split.target !== t.by && !i.has(t.split.target)) a[t.by] = r - r / 2, a[t.split.target] = r / 2;
	else if (t.split?.kind === "pachas") {
		let t = e.players.filter((e) => !i.has(e)), n = Math.ceil(r / t.length / 5) * 5;
		for (let e of t) a[e] = n;
	} else a[t.by] = r;
	for (let [t, n] of Object.entries(a)) e.savings[t] -= n;
	let o = e.playedCount >= e.players.length;
	e.settle = {
		by: t.by,
		total: r,
		paid: a,
		thresholdMet: o
	};
	for (let t of y) for (let n of e.columns[t]) e.discard.push(n.card, ...n.premiums);
	for (let t of e.quemados) e.discard.push(t.card, ...t.premiums);
	for (let t of e.extras) e.discard.push(t.card);
	e.discard.push(...e.wines);
	for (let n of t.tips) e.discard.push(n.card);
	t.split && e.discard.push(t.split.card), e.bill = null, e.columns = {
		vegetal: [],
		carne: [],
		pescado: []
	}, e.blocked = {
		vegetal: !1,
		carne: !1,
		pescado: !1
	}, e.quemados = [], e.extras = [], e.wines = [], e.cafe = !1;
	let s = [{
		kind: "settle",
		rid: t.by,
		data: {
			total: r,
			paid: a,
			thresholdMet: o
		}
	}];
	return Object.values(e.savings).some((e) => e <= 0) ? (e.phase = "done", s) : o ? (e.handLimit[t.by] = Math.min(10, e.handLimit[t.by] + 1), e.discardRid = t.by, e.phase = "discard", e.beatMs = R, s) : (e.discard.push(...e.hands[t.by]), e.hands[t.by] = [], [...s, ...de(e)]);
}
function de(e) {
	let t = e.settle.by;
	e.round += 1, e.phase = "play", e.direction = 1, e.columns = {
		vegetal: [],
		carne: [],
		pescado: []
	}, e.blocked = {
		vegetal: !1,
		carne: !1,
		pescado: !1
	}, e.quemados = [], e.extras = [], e.wines = [], e.playedCount = 0, e.cafe = !1, e.birthday = null, e.settle = null, e.discardRid = null, e.beatMs = 0, e.activeIdx = e.players.indexOf(t);
	let n = {};
	for (let t of e.players) {
		let r = Y(e, e.handLimit[t] - e.hands[t].length);
		e.hands[t].push(...r), n[t] = r;
	}
	let r = 0;
	for (; !K(e, t) && r < 10;) {
		e.discard.push(...e.hands[t]);
		let i = Y(e, e.handLimit[t]);
		e.hands[t] = i, n[t] = i, r += 1;
	}
	return e.players.map((e, t) => ({
		kind: "deal",
		rid: e,
		data: { count: n[e].length },
		for: [e],
		secret: { cards: n[e] },
		...t > 0 ? { with: !0 } : {}
	}));
}
function fe(e, t, n) {
	if (e.phase !== "play") return J("games.lacuenta.errBadPhase");
	if (e.players[e.activeIdx] !== n.by) return J("games.lacuenta.errNotYourTurn");
	let r = e.hands[n.by];
	if (!r?.includes(t.card)) return J("games.lacuenta.errBadCard");
	let i = T(t.card), a = t.premiums ?? [];
	if (a.length > 0 && i.kind !== "tapa" && i.kind !== "quemado") return J("games.lacuenta.errBadCard");
	{
		let e = r.filter((e) => e !== t.card);
		for (let t of a) {
			let n = e.indexOf(t);
			if (n < 0 || T(t).kind !== "premium") return J("games.lacuenta.errBadCard");
			e.splice(n, 1);
		}
	}
	if (!G(e, n.by, t.card, a.length, t.column)) return J("games.lacuenta.errBadCard");
	let o = structuredClone(e), s = o.hands[n.by];
	s.splice(s.indexOf(t.card), 1);
	for (let e of a) s.splice(s.indexOf(e), 1);
	let c = null;
	switch (i.kind) {
		case "tapa": {
			let e = i.tapa;
			o.columns[e].push({
				card: t.card,
				premiums: a
			}), c = e;
			break;
		}
		case "quemado": {
			let e = t.column;
			o.quemados.push({
				card: t.card,
				column: e,
				premiums: a
			}), o.blocked[e] = !0, c = e;
			break;
		}
		case "vino":
			o.wines.push(t.card);
			break;
		case "cambio":
			o.direction = o.direction === 1 ? -1 : 1, o.extras.push({
				card: t.card,
				by: n.by
			});
			break;
		case "toilette":
			o.toilet.includes(n.by) || o.toilet.push(n.by), o.extras.push({
				card: t.card,
				by: n.by
			});
			break;
		case "cafe":
			o.cafe = !0, o.extras.push({
				card: t.card,
				by: n.by
			});
			break;
		case "pastel":
			o.birthday = n.by, o.extras.push({
				card: t.card,
				by: n.by
			});
			break;
		default: return J("games.lacuenta.errBadCard");
	}
	return o.playedCount += 1 + a.length, le(o), {
		state: o,
		fx: [{
			kind: "play",
			rid: n.by,
			data: {
				card: t.card,
				kind: i.kind,
				column: c,
				premiums: a.length
			}
		}]
	};
}
function pe(e, t, n) {
	if (t.type === "tick") {
		let t = structuredClone(e);
		return e.phase === "bill" && e.bill ? {
			state: t,
			fx: ue(t)
		} : e.phase === "discard" && e.discardRid ? {
			state: t,
			fx: de(t)
		} : {
			state: e,
			fx: []
		};
	}
	if (t.type === "play") return fe(e, t, n);
	if (t.type === "pass") {
		if (e.phase !== "play" || e.players[e.activeIdx] !== n.by || e.birthday !== n.by) return J("games.lacuenta.errNotYourTurn");
		let t = structuredClone(e);
		return le(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "askBill") {
		if (e.phase !== "play") return J("games.lacuenta.errBadPhase");
		if (!e.players.includes(n.by) || U(e).has(n.by)) return J("games.lacuenta.errImmune");
		let t = q(e, n.by);
		if (!t && e.playedCount < e.players.length) return J("games.lacuenta.errNoThreshold");
		let r = structuredClone(e);
		return r.phase = "bill", r.bill = {
			by: n.by,
			forced: t,
			tips: [],
			split: null,
			confirmed: []
		}, r.beatMs = L, {
			state: r,
			fx: [{
				kind: "askBill",
				rid: n.by,
				data: {
					forced: t,
					total: H(r)
				}
			}]
		};
	}
	if (t.type === "tip") {
		let r = e.bill;
		if (e.phase !== "bill" || !r) return J("games.lacuenta.errBadPhase");
		if (U(e).has(n.by)) return J("games.lacuenta.errImmune");
		if (T(t.card).kind !== "propina" || !e.hands[n.by]?.includes(t.card)) return J("games.lacuenta.errBadCard");
		let i = structuredClone(e), a = i.hands[n.by];
		a.splice(a.indexOf(t.card), 1);
		let o = B(i) ?? 0;
		return i.bill.tips.push({
			card: t.card,
			by: n.by
		}), i.bill.confirmed = [], i.beatMs = L, {
			state: i,
			fx: [{
				kind: "tip",
				rid: n.by,
				data: { value: o }
			}]
		};
	}
	if (t.type === "split") {
		let r = e.bill;
		if (e.phase !== "bill" || !r || r.by !== n.by) return J("games.lacuenta.errBadPhase");
		let i = r.split !== null && r.split.card === t.card, a = T(t.card).kind;
		if (!i) {
			if (a !== "medias" && a !== "pachas" || !e.hands[n.by]?.includes(t.card)) return J("games.lacuenta.errBadCard");
			if (a === "medias") {
				let r = t.target;
				if (!r || r === n.by || !e.players.includes(r) || U(e).has(r)) return J("games.lacuenta.errBadTarget");
			}
		}
		let o = structuredClone(e), s = o.hands[n.by], c = o.bill;
		return c.split && s.push(c.split.card), i ? c.split = null : (s.splice(s.indexOf(t.card), 1), c.split = a === "medias" ? {
			kind: "medias",
			card: t.card,
			target: t.target
		} : {
			kind: "pachas",
			card: t.card
		}), c.confirmed = [], o.beatMs = L, {
			state: o,
			fx: [{
				kind: "split",
				rid: n.by,
				data: i ? { kind: "cancel" } : a === "medias" ? {
					kind: a,
					target: t.target ?? null
				} : { kind: a }
			}]
		};
	}
	if (t.type === "billDone") {
		let t = e.bill;
		if (e.phase !== "bill" || !t) return J("games.lacuenta.errBadPhase");
		if (t.confirmed.includes(n.by)) return {
			state: e,
			fx: []
		};
		if (!e.players.includes(n.by)) return J("games.lacuenta.errBadPhase");
		let r = structuredClone(e), i = r.bill;
		return i.confirmed.push(n.by), r.players.filter((e) => !U(r).has(e)).every((e) => i.confirmed.includes(e)) ? {
			state: r,
			fx: ue(r)
		} : {
			state: r,
			fx: []
		};
	}
	if (e.phase !== "discard" || e.discardRid !== n.by) return J("games.lacuenta.errNotYourTurn");
	{
		let r = [...e.hands[n.by]];
		for (let e of t.cards) {
			let t = r.indexOf(e);
			if (t < 0) return J("games.lacuenta.errBadDiscard");
			r.splice(t, 1);
		}
	}
	let r = structuredClone(e), i = r.hands[n.by];
	return r.hands[n.by] = i.filter((e) => !t.cards.includes(e)), r.discard.push(...t.cards), {
		state: r,
		fx: de(r)
	};
}
function me(e, t) {
	return {
		public: {
			round: e.round,
			phase: e.phase,
			direction: e.direction,
			activeRid: e.players[e.activeIdx],
			deckCount: e.deck.length,
			columns: e.columns,
			blocked: e.blocked,
			quemados: e.quemados,
			extras: e.extras,
			wines: e.wines,
			playedCount: e.playedCount,
			threshold: e.players.length,
			cafe: e.cafe,
			toilet: e.toilet,
			birthday: e.birthday,
			players: e.players.map((t) => ({
				rid: t,
				savings: e.savings[t],
				handCount: e.hands[t].length,
				handLimit: e.handLimit[t]
			})),
			bill: e.bill,
			settle: e.settle,
			discardRid: e.discardRid,
			billTotal: H(e),
			cheapestTapa: B(e)
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function he(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.savings[n] - e.savings[t]), n = e.savings[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.savings[t] === n),
		ranking: t,
		scores: { ...e.savings }
	};
}
function ge(e) {
	return e.phase === "bill" || e.phase === "discard" ? e.beatMs : null;
}
var _e = {
	saveCompatibility: { version: "2" },
	meta: k,
	schemas: {
		action: N,
		publicView: ie,
		privateView: I
	},
	setup: ce,
	reduce: pe,
	viewFor: me,
	status: he,
	nextTickIn: ge
};
//#endregion
//#region src/games/lacuenta/card.tsx
function ve(e) {
	return e ? {
		"--lc-card-w": `${e.w}px`,
		"--lc-card-h": `${e.h}px`
	} : {};
}
var ye = {
	vegetal: "#499327",
	carne: "#de7b22",
	pescado: "#2788b6"
}, be = {
	vino: "🍷",
	quemado: "🔥",
	cambio: "🔄",
	premium: "⭐",
	toilette: "🚻",
	cafe: "☕",
	pastel: "🎂",
	medias: "🤝",
	pachas: "🍻",
	propina: "🪙"
}, xe = {
	vegetal: "🥬",
	carne: "🥩",
	pescado: "🐟"
}, Se = "#fdf5df", Ce = "./games/lacuenta/live/";
function we({ src: e, emoji: t, sm: r }) {
	let [i, a] = n(!1);
	return /* @__PURE__ */ m("span", {
		className: "relative grid min-h-0 flex-1 place-items-center overflow-hidden",
		style: { backgroundColor: Se },
		children: [/* @__PURE__ */ p("span", {
			"aria-hidden": !0,
			className: r ? "text-sm" : "text-2xl",
			children: t
		}), !i && /* @__PURE__ */ p("img", {
			src: e,
			alt: "",
			draggable: !1,
			onError: () => a(!0),
			className: "absolute inset-0 size-full object-contain"
		})]
	});
}
function X({ kind: e, className: t = "", fallbackClassName: r = "text-2xl" }) {
	let [i, a] = n(!1);
	return /* @__PURE__ */ m("span", {
		className: `relative grid min-h-0 place-items-center overflow-hidden ${t}`,
		style: { backgroundColor: Se },
		children: [/* @__PURE__ */ p("span", {
			"aria-hidden": !0,
			className: r,
			children: be[e]
		}), !i && /* @__PURE__ */ p("img", {
			src: `${Ce}${e}.webp`,
			alt: "",
			draggable: !1,
			onError: () => a(!0),
			className: "absolute inset-0 size-full object-contain"
		})]
	});
}
var Te = "M3 1 H21 V25 L18 22.5 L15 25 L12 22.5 L9 25 L6 22.5 L3 25 Z";
function Z({ id: e, premiums: t = 0, size: n = "md", dimensions: r }) {
	let i = s(), a = T(e), o = n === "sm", c = `lc-card lc-card--${n} rounded border-2 border-ink ${o ? "h-[76px] w-[54px]" : "h-22 w-16 shadow-[2px_2px_0_var(--color-ink)]"}`, l = {
		backgroundColor: Se,
		...ve(r)
	}, u = i(a.nameKey), d = re(a);
	if (d && a.tapa) {
		let e = ye[a.tapa], n = (a.value ?? 0) * 2 ** t, r = `${Ce}${a.nameKey.slice(20)}.webp`;
		return /* @__PURE__ */ m("span", {
			className: `relative flex flex-col overflow-hidden ${c}`,
			style: l,
			"aria-label": `${u} ${n}€`,
			children: [
				/* @__PURE__ */ m("span", {
					className: "lc-card-price relative flex flex-none items-center justify-between px-1 text-[10px] leading-4 font-extrabold text-white",
					style: { background: e },
					children: [/* @__PURE__ */ p("span", {
						"aria-hidden": !0,
						children: xe[a.tapa]
					}), /* @__PURE__ */ m("span", {
						className: "font-mono tabular-nums",
						children: [n, "€"]
					})]
				}),
				/* @__PURE__ */ p(we, {
					src: r,
					emoji: d,
					sm: o
				}, r),
				/* @__PURE__ */ p("span", {
					className: "lc-card-caption relative flex-none truncate px-0.5 text-center text-[9px] leading-3 font-bold",
					children: u
				}),
				t > 0 && /* @__PURE__ */ m("span", {
					className: "lc-card-caption relative flex-none bg-warn-soft text-center text-[9px] leading-3 font-extrabold text-warn-ink",
					children: ["⭐×", 2 ** t]
				})
			]
		});
	}
	return /* @__PURE__ */ m("span", {
		className: `relative flex flex-col overflow-hidden ${c}`,
		style: l,
		"aria-label": u,
		children: [
			a.value !== void 0 && a.value !== 0 && /* @__PURE__ */ m("span", {
				className: `lc-card-special-price relative flex-none text-center font-mono font-extrabold tabular-nums ${o ? "text-[10px] leading-4" : "text-[11px] leading-4.5"} ${a.value < 0 ? "text-danger-ink" : ""}`,
				children: [a.value > 0 ? `+${a.value}` : a.value, "€"]
			}),
			/* @__PURE__ */ p(X, {
				kind: a.kind,
				className: "flex-1",
				fallbackClassName: o ? "text-base" : "text-2xl"
			}),
			a.kind === "premium" && /* @__PURE__ */ p("span", {
				className: `lc-card-special-price relative flex-none text-center font-mono font-extrabold text-warn-ink ${o ? "text-[10px]" : "text-[11px]"}`,
				children: "×2"
			}),
			/* @__PURE__ */ p("span", {
				className: "lc-card-caption relative flex-none truncate bg-ink px-0.5 text-center text-[9px] leading-3 font-bold text-surface",
				children: u
			})
		]
	});
}
function Ee({ size: e = "md", stacked: t = !1, dimensions: n }) {
	let r = s(), i = `lc-card lc-card--${e} rounded border-2 border-ink ${e === "sm" ? "h-[76px] w-[54px]" : "h-22 w-16"} ${t ? "shadow-[4px_4px_0_var(--color-ink)]" : ""}`;
	return /* @__PURE__ */ p("span", {
		className: `inline-flex flex-none overflow-hidden ${i}`,
		style: {
			background: k.accent,
			...ve(n)
		},
		"aria-label": r("games.lacuenta.cardBack"),
		children: /* @__PURE__ */ m("svg", {
			className: "size-full",
			viewBox: "0 0 64 88",
			preserveAspectRatio: "xMidYMid slice",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ p("path", {
				d: "M-16 24 L80 -16 M-16 48 L80 8 M-16 72 L80 32 M-16 96 L80 56",
				stroke: "#ffffff",
				strokeWidth: 6,
				opacity: .14,
				fill: "none"
			}), /* @__PURE__ */ p("path", {
				d: Te,
				transform: "translate(32 44) translate(-14 -15) scale(1.15)",
				fill: "#ffffff",
				opacity: .92
			})]
		})
	});
}
//#endregion
//#region src/games/lacuenta/view-player.tsx
function De(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(ke, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Oe(e, t) {
	return r(e.rid) === null ? e.name : a(t, e.avatar);
}
function ke({ pub: e, priv: t, members: r, myRid: a, send: h }) {
	let g = s(), _ = o((e) => e.locale), v = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? Oe(t, _) : e;
	}, { ref: ee } = i("table"), { ref: b } = i("deck"), { ref: te } = i("deck-card"), { ref: ne } = i("hand"), { ref: re } = i("hand-card"), x = t?.hand ?? [], S = {
		columns: e.columns,
		blocked: e.blocked,
		cafe: e.cafe
	}, C = e.phase === "play" && e.activeRid === a, w = e.toilet.includes(a) || e.birthday === a, E = e.phase === "play" && !w && e.playedCount >= e.threshold, D = C && e.birthday !== a && !oe(S, x), O = x.filter((e) => T(e).kind === "premium"), [A, j] = n(null), [M, N] = n(0), [P, F] = n([]), [ie, I] = n(!1), [L, R] = n(null), z = `${e.phase}|${e.round}|${e.bill !== null}`, [ae, B] = n(z);
	ae !== z && (B(z), j(null), N(0), F([]), I(!1), R(null));
	let V = r.filter((t) => e.players.some((e) => e.rid === t.rid)), H = A === null ? null : T(A), U = /* @__PURE__ */ new Set([...e.toilet, ...e.birthday ? [e.birthday] : []]), G = "info", K, q;
	if (e.phase === "bill" && e.bill ? (G = e.bill.by === a ? "accent" : "warn", K = e.bill.by === a ? g("games.lacuenta.billMine") : g("games.lacuenta.billWaiting", { name: v(e.bill.by) }), q = `${g("games.lacuenta.billWindow")} · ${g("games.lacuenta.billProgress", {
		n: e.bill.confirmed.length,
		total: V.filter((e) => !U.has(e.rid)).length
	})}`) : e.phase === "discard" ? (G = e.discardRid === a ? "accent" : "info", K = e.discardRid === a ? g("games.lacuenta.discardPrompt") : g("games.lacuenta.discardWaiting", { name: v(e.discardRid ?? "") })) : C ? (G = "accent", K = D ? g("games.lacuenta.forcedBill") : e.birthday === a ? g("games.lacuenta.birthdayTurn") : g("games.lacuenta.yourTurn")) : K = g("games.lacuenta.waiting", { name: v(e.activeRid) }), e.phase === "play") {
		let t = [e.direction === -1 ? g("games.lacuenta.reversed") : null, e.cafe ? g("games.lacuenta.cafeLock") : null].filter(Boolean);
		t.length && (q = t.join(" · "));
	}
	let J = (e, t) => {
		A !== null && (h({
			type: "play",
			card: A,
			...e > 0 ? { premiums: O.slice(0, e) } : {},
			...t ? { column: t } : {}
		}), j(null), N(0));
	};
	return /* @__PURE__ */ p(l, {
		adaptive: !0,
		className: "lc-screen",
		banner: /* @__PURE__ */ m("div", {
			className: "lc-banner flex flex-col gap-2",
			children: [/* @__PURE__ */ p("div", {
				className: "lc-phase",
				children: /* @__PURE__ */ p(u, {
					tone: G,
					text: K,
					sub: q,
					chip: g("games.lacuenta.roundShort", { n: e.round }),
					accent: k.accent
				})
			}), /* @__PURE__ */ p("div", {
				className: "lc-seats",
				children: /* @__PURE__ */ p(d, {
					members: V,
					myRid: a,
					variant: "medal",
					scroll: !0,
					anchorOf: (e) => `seat:${e}`,
					action: (t) => e.phase === "play" ? t === e.activeRid ? "pending" : null : e.phase === "bill" && e.bill ? U.has(t) ? null : e.bill.confirmed.includes(t) ? "done" : "pending" : e.phase === "discard" && t === e.discardRid ? "pending" : null,
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ m("span", {
							className: "lc-seat-status flex items-center gap-0.5 whitespace-nowrap text-[10px] leading-3.5 font-bold",
							children: [
								/* @__PURE__ */ m("span", {
									className: "font-mono tabular-nums",
									"aria-label": g("games.lacuenta.savings", { amount: n.savings }),
									children: [n.savings, "€"]
								}),
								/* @__PURE__ */ m("span", {
									"aria-label": g("games.lacuenta.handCount", { n: n.handCount }),
									children: [/* @__PURE__ */ p("span", {
										"aria-hidden": !0,
										children: "🃏"
									}), /* @__PURE__ */ p("span", {
										className: "font-mono tabular-nums",
										children: n.handCount
									})]
								}),
								e.toilet.includes(t) && /* @__PURE__ */ p("span", {
									role: "img",
									"aria-label": g("games.lacuenta.toiletBadge"),
									children: /* @__PURE__ */ p(X, {
										kind: "toilette",
										className: "size-4 rounded",
										fallbackClassName: "text-xs"
									})
								}),
								e.birthday === t && /* @__PURE__ */ p("span", {
									role: "img",
									"aria-label": g("games.lacuenta.birthdayBadge"),
									children: /* @__PURE__ */ p(X, {
										kind: "pastel",
										className: "size-4 rounded",
										fallbackClassName: "text-xs"
									})
								})
							]
						}) : null;
					}
				})
			})]
		}),
		actionsHeight: "lc-actions-slot h-40 wide:short:h-24",
		actions: /* @__PURE__ */ m("div", {
			className: "lc-actions flex h-full flex-col gap-1.5",
			children: [/* @__PURE__ */ p("ul", {
				ref: ne,
				"aria-label": g("games.lacuenta.handAria"),
				className: "lc-hand flex min-h-0 flex-1 items-end gap-1.5 overflow-x-auto px-1 pt-2 pb-1",
				children: x.map((t, n) => {
					let r = e.phase === "discard" && e.discardRid === a, i = C && !D && W(S, t, T(t).kind === "tapa" ? O.length : 0, y.find((t) => !e.blocked[t])), o = r ? P.includes(t) : A === t;
					return /* @__PURE__ */ p("li", {
						ref: n === 0 ? re : void 0,
						className: "flex-none",
						children: /* @__PURE__ */ p("button", {
							type: "button",
							disabled: !r && !C && e.phase !== "bill",
							"aria-pressed": o,
							onClick: () => {
								r ? F((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]) : C && (j((e) => e === t ? null : t), N(0));
							},
							className: `transition-transform ${o ? "-translate-y-2" : ""} ${C && !i && !r ? "opacity-45" : ""}`,
							children: /* @__PURE__ */ p(Z, { id: t })
						})
					}, t);
				})
			}), /* @__PURE__ */ p("div", {
				className: "lc-controls relative flex h-12 flex-none items-stretch gap-2",
				children: e.phase === "bill" && e.bill ? w ? /* @__PURE__ */ p("p", {
					className: "grid flex-1 place-items-center text-xs font-bold opacity-60",
					children: g("games.lacuenta.billWaiting", { name: v(e.bill.by) })
				}) : /* @__PURE__ */ p(Pe, {
					pub: e,
					myRid: a,
					hand: x,
					pickingMedias: ie,
					setPickingMedias: I,
					send: h
				}) : e.phase === "discard" ? e.discardRid === a ? /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => h({
						type: "discard",
						cards: P
					}),
					className: "btn-base min-h-12 flex-1 text-base",
					style: { background: k.accent },
					children: g("games.lacuenta.discardConfirm", { n: P.length })
				}) : /* @__PURE__ */ p("p", {
					className: "grid flex-1 place-items-center text-xs font-bold opacity-60",
					children: g("games.lacuenta.discardWaiting", { name: v(e.discardRid ?? "") })
				}) : C ? /* @__PURE__ */ m(f, { children: [
					D ? /* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => h({ type: "askBill" }),
						className: "btn-base min-h-12 flex-1 text-base",
						style: { background: k.accent },
						children: g("games.lacuenta.askBill")
					}) : /* @__PURE__ */ p(Ne, {
						sel: A,
						table: S,
						premiumsInHand: O.length,
						quemadoPremium: M,
						setQuemadoPremium: N,
						onPlay: J,
						birthday: e.birthday === a
					}),
					E && !D && /* @__PURE__ */ p("button", {
						type: "button",
						"aria-label": g("games.lacuenta.askBillAria"),
						onClick: () => h({ type: "askBill" }),
						className: "btn-base min-h-12 flex-none px-4 text-base",
						style: { background: k.accent },
						children: g("games.lacuenta.askBill")
					}),
					e.birthday === a && /* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => h({ type: "pass" }),
						className: "btn-quiet min-h-12 flex-none px-3 text-sm",
						children: g("games.lacuenta.pass")
					})
				] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("p", {
					className: "grid flex-1 place-items-center text-xs font-bold opacity-60",
					children: E ? g("games.lacuenta.askBillHint", {
						n: e.playedCount,
						total: e.threshold
					}) : g("games.lacuenta.waiting", { name: v(e.activeRid) })
				}), E && /* @__PURE__ */ p("button", {
					type: "button",
					"aria-label": g("games.lacuenta.askBillAria"),
					onClick: () => h({ type: "askBill" }),
					className: "btn-base min-h-12 flex-none px-4 text-base",
					style: { background: k.accent },
					children: g("games.lacuenta.askBill")
				})] })
			})]
		}),
		overlay: ie && e.bill && x.some((e) => T(e).kind === "medias") ? /* @__PURE__ */ p("div", {
			className: "lc-targets card pointer-events-auto mx-2 mb-1 flex flex-wrap gap-1.5 p-2",
			children: e.players.filter((e) => e.rid !== a && !U.has(e.rid)).map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => {
					let t = x.find((e) => T(e).kind === "medias");
					t !== void 0 && h({
						type: "split",
						card: t,
						target: e.rid
					}), I(!1);
				},
				className: "btn-quiet min-h-11 px-3 text-sm",
				children: v(e.rid)
			}, e.rid))
		}) : void 0,
		scroll: !1,
		children: /* @__PURE__ */ m("div", {
			ref: ee,
			className: "lc-table",
			children: [
				/* @__PURE__ */ p("div", {
					className: "lc-cloth",
					children: /* @__PURE__ */ p(c, {
						kind: "hatch",
						base: "var(--color-lc-linen)",
						line: "var(--color-lc-linen-line)",
						className: "absolute inset-0 size-full"
					})
				}),
				/* @__PURE__ */ p("div", {
					className: "lc-scroll",
					children: /* @__PURE__ */ m("div", {
						className: "lc-scene",
						children: [
							/* @__PURE__ */ m("div", {
								className: "lc-top",
								children: [
									/* @__PURE__ */ m("div", {
										ref: b,
										className: "lc-deck",
										"aria-label": g("games.lacuenta.deckAria", { n: e.deckCount }),
										children: [/* @__PURE__ */ p("span", {
											ref: te,
											className: "lc-deck-card inline-flex",
											children: /* @__PURE__ */ p(Ee, {
												size: "sm",
												stacked: !0
											})
										}), /* @__PURE__ */ m("span", {
											className: "font-mono tabular-nums",
											children: ["×", e.deckCount]
										})]
									}),
									/* @__PURE__ */ p(Ae, {
										pub: e,
										nameOf: v
									}),
									/* @__PURE__ */ p(Me, { pub: e })
								]
							}),
							/* @__PURE__ */ p("div", {
								className: "lc-plates",
								children: y.map((t) => {
									let n = C && A !== null && H?.kind === "tapa" && H.tapa === t && Array.from({ length: O.length + 1 }, (e, t) => t).some((e) => W(S, A, e)), r = C && H?.kind === "quemado" && !e.blocked[t];
									return /* @__PURE__ */ p(je, {
										pub: e,
										type: t,
										legal: n,
										target: r,
										onPick: r ? () => J(M, t) : void 0,
										onDetail: () => R(t)
									}, t);
								})
							}),
							/* @__PURE__ */ p("ul", {
								"aria-label": g("games.lacuenta.extrasAria"),
								className: "lc-extras",
								children: e.extras.length > 0 ? e.extras.map((e, t) => /* @__PURE__ */ p("li", {
									className: "flex-none",
									title: v(e.by),
									children: /* @__PURE__ */ p(Z, {
										id: e.card,
										size: "sm"
									})
								}, t)) : [
									"cafe",
									"toilette",
									"quemado",
									"premium"
								].map((e) => /* @__PURE__ */ m("li", {
									"aria-hidden": !0,
									className: "lc-extra-slot",
									children: [/* @__PURE__ */ p("span", {
										className: "lc-extra-placeholder",
										children: /* @__PURE__ */ p(X, {
											kind: e,
											className: "size-[34px] rounded-full",
											fallbackClassName: "text-base"
										})
									}), /* @__PURE__ */ p("span", {
										className: "lc-extra-label",
										children: g(`games.lacuenta.card.${e}`)
									})]
								}, e))
							})
						]
					})
				}),
				L && /* @__PURE__ */ p("div", {
					className: "lc-detail-shade",
					onClick: () => R(null),
					children: /* @__PURE__ */ m("div", {
						className: "card lc-detail-panel p-3",
						onClick: (e) => e.stopPropagation(),
						children: [
							/* @__PURE__ */ m("div", {
								className: "mb-2 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ p("strong", { children: g(L === "vegetal" ? "games.lacuenta.colVegetal" : L === "carne" ? "games.lacuenta.colCarne" : "games.lacuenta.colPescado") }), /* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => R(null),
									"aria-label": g("common.close"),
									className: "btn-quiet min-h-11 px-3",
									children: "×"
								})]
							}),
							/* @__PURE__ */ p("p", {
								className: "mb-2 text-xs font-bold",
								children: g("games.lacuenta.receiptPlateRule")
							}),
							/* @__PURE__ */ m("div", {
								className: "flex flex-wrap gap-2",
								children: [[...e.columns[L]].reverse().map((e, t) => /* @__PURE__ */ m("div", {
									className: "flex flex-col items-center gap-1",
									children: [/* @__PURE__ */ p(Z, {
										id: e.card,
										premiums: e.premiums.length,
										size: "sm"
									}), /* @__PURE__ */ p("span", {
										className: "text-[10px] font-bold",
										children: g(t === 0 ? "games.lacuenta.receiptTopCard" : "games.lacuenta.receiptCoveredCard")
									})]
								}, e.card)), e.quemados.filter((e) => e.column === L).map((e) => /* @__PURE__ */ m("div", {
									className: "flex flex-col items-center gap-1",
									children: [/* @__PURE__ */ p(Z, {
										id: e.card,
										premiums: e.premiums.length,
										size: "sm"
									}), /* @__PURE__ */ p("span", {
										className: "text-[10px] font-bold",
										children: g("games.lacuenta.receiptBurntCard")
									})]
								}, e.card))]
							}),
							/* @__PURE__ */ p("p", {
								className: "mt-2 border-t border-ink pt-2 text-sm font-extrabold",
								children: g("games.lacuenta.columnSubtotal", {
									n: e.columns[L].length + e.quemados.filter((e) => e.column === L).length,
									total: [...e.columns[L], ...e.quemados.filter((e) => e.column === L)].reduce((e, t) => e + (T(t.card).value ?? 0) * 2 ** t.premiums.length, 0)
								})
							}),
							e.cheapestTapa !== null && /* @__PURE__ */ p("p", {
								className: "mt-1 text-xs font-bold",
								children: g("games.lacuenta.receiptTipUnit", { value: e.cheapestTapa })
							})
						]
					})
				})
			]
		})
	});
}
function Ae({ pub: e, nameOf: t }) {
	let n = s(), r = !!(e.bill || e.settle), i = e.cheapestTapa ?? 0;
	return /* @__PURE__ */ m("div", {
		className: `lc-receipt ${r ? "lc-receipt--expanded" : ""}`,
		children: [
			/* @__PURE__ */ p("span", {
				className: "lc-receipt-title",
				children: n("games.lacuenta.receiptTitle")
			}),
			/* @__PURE__ */ m("span", {
				className: `lc-receipt-total ${e.billTotal < 0 ? "text-done-ink" : ""}`,
				children: [e.settle?.total ?? e.billTotal, "€"]
			}),
			e.bill ? /* @__PURE__ */ m("div", {
				className: "lc-receipt-lines",
				children: [
					/* @__PURE__ */ m("div", {
						className: "lc-receipt-line",
						children: [/* @__PURE__ */ p("span", { children: n("games.lacuenta.receiptPayer") }), /* @__PURE__ */ p("span", { children: t(e.bill.by) })]
					}),
					/* @__PURE__ */ m("div", {
						className: "lc-receipt-line",
						children: [/* @__PURE__ */ p("span", { children: n("games.lacuenta.receiptTips", {
							n: e.bill.tips.length,
							value: i
						}) }), /* @__PURE__ */ m("span", { children: [
							"+",
							e.bill.tips.length * i,
							"€"
						] })]
					}),
					e.bill.split && /* @__PURE__ */ m("div", {
						className: "lc-receipt-line",
						children: [/* @__PURE__ */ p("span", { children: n("games.lacuenta.receiptSplit") }), /* @__PURE__ */ p("span", { children: e.bill.split.kind === "medias" ? n("games.lacuenta.splitMedias") : n("games.lacuenta.splitPachas") })]
					}),
					/* @__PURE__ */ p("div", {
						className: "lc-receipt-line",
						children: /* @__PURE__ */ p("span", { children: n("games.lacuenta.billProgress", {
							n: e.bill.confirmed.length,
							total: e.players.filter((t) => !e.toilet.includes(t.rid) && t.rid !== e.birthday).length
						}) })
					})
				]
			}) : e.settle ? /* @__PURE__ */ m("div", {
				className: "lc-receipt-lines",
				children: [Object.entries(e.settle.paid).map(([e, n]) => /* @__PURE__ */ m("div", {
					className: "lc-receipt-line",
					children: [/* @__PURE__ */ p("span", { children: t(e) }), /* @__PURE__ */ m("span", { children: [n, "€"] })]
				}, e)), !e.settle.thresholdMet && /* @__PURE__ */ p("span", {
					className: "text-warn-ink",
					children: n("games.lacuenta.thresholdMiss")
				})]
			}) : /* @__PURE__ */ p("span", {
				className: "lc-receipt-foot",
				children: n("games.lacuenta.playedCount", {
					n: e.playedCount,
					total: e.threshold
				})
			})
		]
	});
}
function je({ pub: e, type: t, legal: n, target: r, onPick: a, onDetail: o }) {
	let c = s(), { ref: l } = i(`col:${t}`), { ref: u } = i(`col-card:${t}`), d = e.columns[t], f = d[d.length - 1], h = e.quemados.filter((e) => e.column === t), g = [...d, ...h].reduce((e, t) => e + (T(t.card).value ?? 0) * 2 ** t.premiums.length, 0), _ = f ? (T(f.card).value ?? 0) * 2 ** f.premiums.length : null, v = c(t === "vegetal" ? "games.lacuenta.colVegetal" : t === "carne" ? "games.lacuenta.colCarne" : "games.lacuenta.colPescado");
	return /* @__PURE__ */ m("div", {
		ref: l,
		className: `lc-plate lc-plate--${t} ${n ? "lc-plate--legal" : ""} ${r ? "lc-plate--target" : ""} ${e.blocked[t] ? "lc-plate--blocked" : ""}`,
		children: [
			/* @__PURE__ */ p("span", {
				className: "lc-plate-title",
				children: v
			}),
			a ? /* @__PURE__ */ p("button", {
				type: "button",
				onClick: a,
				className: "lc-plate-disc",
				"aria-label": `${c("games.lacuenta.chooseColumn")} · ${v}`,
				children: /* @__PURE__ */ m("span", {
					className: "text-center text-sm font-extrabold text-danger-ink",
					children: [/* @__PURE__ */ p(X, {
						kind: "quemado",
						className: "mx-auto size-8 rounded-full",
						fallbackClassName: "text-base"
					}), c("games.lacuenta.burnHere")]
				})
			}) : f || h.length ? /* @__PURE__ */ p("button", {
				type: "button",
				onClick: o,
				className: "lc-plate-disc",
				"aria-label": c("games.lacuenta.receiptPlateDetail", { name: v }),
				children: /* @__PURE__ */ m("span", {
					ref: f ? u : void 0,
					className: "relative inline-flex",
					children: [f ? /* @__PURE__ */ p(Z, {
						id: f.card,
						premiums: f.premiums.length,
						size: "sm"
					}) : /* @__PURE__ */ p(X, {
						kind: "quemado",
						className: "size-10 rounded-full",
						fallbackClassName: "text-xl"
					}), e.blocked[t] && /* @__PURE__ */ p("span", {
						className: "absolute -right-2 -bottom-1 rounded-full border border-ink bg-danger-soft p-0.5",
						"aria-label": c("games.lacuenta.colBlocked"),
						children: /* @__PURE__ */ p(X, {
							kind: "quemado",
							className: "size-4 rounded-full",
							fallbackClassName: "text-xs"
						})
					})]
				})
			}) : /* @__PURE__ */ p("div", {
				className: "lc-plate-disc",
				children: /* @__PURE__ */ p("span", {
					className: "text-xs font-bold opacity-60",
					children: c(n ? "games.lacuenta.receiptPlayable" : "games.lacuenta.receiptEmptyPlate")
				})
			}),
			/* @__PURE__ */ p("span", {
				className: "lc-plate-summary font-mono tabular-nums",
				children: d.length > 0 || h.length > 0 ? c("games.lacuenta.columnSubtotal", {
					n: d.length + h.length,
					total: g
				}) : " "
			}),
			/* @__PURE__ */ p("span", {
				className: "lc-plate-price",
				children: e.blocked[t] ? c("games.lacuenta.colBlocked") : _ === null ? c("games.lacuenta.colEmpty") : c("games.lacuenta.colNext", { value: _ })
			})
		]
	});
}
function Me({ pub: e }) {
	let t = s(), { ref: n } = i("wine");
	return /* @__PURE__ */ m("div", {
		ref: n,
		className: "lc-wine",
		"aria-label": t("games.lacuenta.card.vino"),
		children: [
			/* @__PURE__ */ p("span", {
				className: "lc-wine-coaster",
				children: /* @__PURE__ */ p(X, {
					kind: "vino",
					className: "size-[37px] rounded-full",
					fallbackClassName: "text-lg"
				})
			}),
			/* @__PURE__ */ p("span", { children: t("games.lacuenta.wineCount", { n: e.wines.length }) }),
			/* @__PURE__ */ p("span", {
				className: "font-mono tabular-nums",
				children: t("games.lacuenta.wineNext", { value: D(e.wines.length) })
			})
		]
	});
}
function Ne({ sel: e, table: t, premiumsInHand: n, quemadoPremium: r, setQuemadoPremium: i, onPlay: a, birthday: o }) {
	let c = s();
	if (e === null) return /* @__PURE__ */ p("p", {
		className: "grid flex-1 place-items-center text-xs font-bold opacity-60",
		children: c(o ? "games.lacuenta.birthdayTurn" : "games.lacuenta.yourTurn")
	});
	let l = T(e);
	if (l.kind === "quemado") return /* @__PURE__ */ m("div", {
		className: "flex flex-1 items-stretch gap-2",
		children: [/* @__PURE__ */ p("p", {
			className: "grid flex-1 place-items-center text-xs font-bold",
			children: c("games.lacuenta.chooseColumn")
		}), n > 0 && /* @__PURE__ */ p("div", {
			className: "flex flex-none items-center gap-1",
			children: [
				0,
				1,
				2
			].filter((e) => e <= n).map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => i(e),
				"aria-pressed": r === e,
				className: `plate min-h-11 px-2 font-mono text-xs font-extrabold ${r === e ? "bg-warn-soft" : ""}`,
				children: e === 0 ? "×1" : `⭐×${2 ** e}`
			}, e))
		})]
	});
	if (l.kind === "tapa") {
		let r = Array.from({ length: n + 1 }, (e, t) => t).filter((n) => W(t, e, n));
		return /* @__PURE__ */ m("div", {
			className: "flex min-w-0 flex-1 items-stretch gap-2 overflow-x-auto",
			children: [r.map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => a(e),
				className: "btn-base min-h-12 min-w-20 flex-1 text-base",
				style: { background: k.accent },
				children: e === 0 ? c("games.lacuenta.play") : c("games.lacuenta.playPremium", { mult: 2 ** e })
			}, e)), r.length === 0 && /* @__PURE__ */ p("p", {
				className: "grid flex-1 place-items-center text-xs font-bold opacity-60",
				children: c("games.lacuenta.errBadCard")
			})]
		});
	}
	return /* @__PURE__ */ p("button", {
		type: "button",
		disabled: !W(t, e, 0),
		onClick: () => a(0),
		className: "btn-base min-h-12 flex-1 text-base disabled:opacity-40",
		style: { background: k.accent },
		children: c("games.lacuenta.play")
	});
}
function Pe({ pub: e, myRid: t, hand: n, pickingMedias: r, setPickingMedias: i, send: a }) {
	let o = s(), c = e.bill;
	if (!c) return null;
	let l = n.find((e) => T(e).kind === "propina"), u = n.find((e) => T(e).kind === "medias"), d = n.find((e) => T(e).kind === "pachas"), f = c.by === t, h = c.confirmed.includes(t), g = /* @__PURE__ */ new Set([...e.toilet, ...e.birthday ? [e.birthday] : []]), _ = e.cheapestTapa ?? 0;
	return /* @__PURE__ */ m("div", {
		className: "flex min-w-0 flex-1 items-stretch gap-2 overflow-x-auto",
		children: [
			l !== void 0 && /* @__PURE__ */ p("button", {
				type: "button",
				"aria-label": o("games.lacuenta.tipAria"),
				onClick: () => a({
					type: "tip",
					card: l
				}),
				className: "btn-quiet min-h-12 flex-none px-3 text-sm",
				children: o("games.lacuenta.tip", { value: _ })
			}),
			f && u !== void 0 && /* @__PURE__ */ p("button", {
				type: "button",
				"aria-label": o("games.lacuenta.splitMediasAria"),
				onClick: () => i(!r),
				className: "btn-quiet min-h-12 flex-none px-3 text-sm",
				children: o("games.lacuenta.splitMedias")
			}),
			f && d !== void 0 && /* @__PURE__ */ p("button", {
				type: "button",
				"aria-label": o("games.lacuenta.splitPachasAria"),
				onClick: () => a({
					type: "split",
					card: d
				}),
				className: "btn-quiet min-h-12 flex-none px-3 text-sm",
				children: o("games.lacuenta.splitPachas")
			}),
			f && c.split && /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => a({
					type: "split",
					card: c.split?.card
				}),
				className: "btn-quiet min-h-12 flex-none px-3 text-sm",
				children: o("games.lacuenta.cancelSplit")
			}),
			h ? /* @__PURE__ */ p("p", {
				className: "grid flex-1 place-items-center text-xs font-bold opacity-60",
				children: o("games.lacuenta.billProgress", {
					n: c.confirmed.length,
					total: e.players.filter((e) => !g.has(e.rid)).length
				})
			}) : /* @__PURE__ */ p("button", {
				type: "button",
				"aria-label": o("games.lacuenta.billDoneAria"),
				onClick: () => a({ type: "billDone" }),
				className: "btn-base min-h-12 min-w-24 flex-1 text-base",
				style: { background: k.accent },
				children: o("games.lacuenta.billDone")
			})
		]
	});
}
//#endregion
//#region src/games/lacuenta/bot.ts
function Fe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Ie() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Le(e) {
	return {
		columns: e.columns,
		blocked: e.blocked,
		cafe: e.cafe
	};
}
function Re(e) {
	let t = null, n = -1;
	for (let r of y) {
		if (e.blocked[r]) continue;
		let i = e.columns[r], a = i.length ? z(i[i.length - 1].card, i[i.length - 1].premiums.length) : 0;
		a > n && (n = a, t = r);
	}
	return t;
}
function ze(e, t) {
	let n = Le(e), r = t.filter((e) => T(e).kind === "premium"), i = [], a = Re(e);
	for (let e of t) {
		let t = T(e);
		if (t.kind === "quemado") a && W(n, e, 0, a) && i.push({
			type: "play",
			card: e,
			column: a
		});
		else if (W(n, e, 0)) i.push({
			type: "play",
			card: e
		});
		else if (t.kind === "tapa") {
			for (let t = 1; t <= r.length; t += 1) if (W(n, e, t)) {
				i.push({
					type: "play",
					card: e,
					premiums: r.slice(0, t)
				});
				break;
			}
		}
	}
	return i;
}
var Be = (e, t) => {
	let n = e.public, r = e.private?.hand ?? [], i = t.rid, a = n.toilet.includes(i) || n.birthday === i;
	if (n.phase === "bill") {
		let e = n.bill;
		if (!e || a || e.confirmed.includes(i)) return null;
		let t = r.find((e) => T(e).kind === "propina");
		if (t !== void 0) return { action: {
			type: "tip",
			card: t
		} };
		if (e.by === i && !e.split) {
			let e = Math.max(0, n.billTotal), t = n.players.filter((e) => e.rid !== i && !n.toilet.includes(e.rid) && n.birthday !== e.rid), a = r.find((e) => T(e).kind === "pachas"), o = r.find((e) => T(e).kind === "medias");
			if (a !== void 0 && t.length >= 2 && e >= 150) return { action: {
				type: "split",
				card: a
			} };
			if (o !== void 0 && t.length > 0 && e >= 120) return { action: {
				type: "split",
				card: o,
				target: t.reduce((e, t) => e.savings >= t.savings ? e : t).rid
			} };
		}
		return { action: { type: "billDone" } };
	}
	if (n.phase === "discard") return n.discardRid === i ? { action: {
		type: "discard",
		cards: r.filter((e) => T(e).kind === "tapa").sort((e, t) => (T(e).value ?? 0) - (T(t).value ?? 0)).slice(0, Math.max(0, Math.min(2, r.length - 5)))
	} } : null;
	if (n.phase !== "play") return null;
	let o = n.players.find((e) => e.rid === i)?.savings ?? 0, s = Math.max(0, n.billTotal), c = !a && n.playedCount >= n.threshold;
	if (c && s <= Math.max(30, o * .06)) return { action: { type: "askBill" } };
	if (n.activeRid !== i) return null;
	if (t.difficulty === "weak") {
		let e = ze(n, r);
		return c && Ie() < .3 ? { action: { type: "askBill" } } : e.length ? { action: Fe(e) } : n.birthday === i ? { action: { type: "pass" } } : { action: { type: "askBill" } };
	}
	let l = Le(n), u = r.filter((e) => T(e).kind === "premium"), d = (() => {
		let e = r.filter((e) => T(e).kind === "tapa" && W(l, e, 0)).sort((e, t) => (T(e).value ?? 0) - (T(t).value ?? 0));
		if (e.length) return {
			type: "play",
			card: e[0]
		};
		let t = r.filter((e) => T(e).kind === "tapa").sort((e, t) => (T(e).value ?? 0) - (T(t).value ?? 0));
		for (let e of t) for (let t = 1; t <= u.length; t += 1) if (W(l, e, t)) return {
			type: "play",
			card: e,
			premiums: u.slice(0, t)
		};
		let i = r.find((e) => T(e).kind === "quemado");
		if (i !== void 0) {
			let e = Re(n);
			if (e && W(l, i, 0, e)) return {
				type: "play",
				card: i,
				column: e
			};
		}
		for (let e of [
			"pastel",
			"toilette",
			"vino",
			"cambio",
			"cafe"
		]) {
			let t = r.find((t) => T(t).kind === e);
			if (t !== void 0 && W(l, t, 0)) return {
				type: "play",
				card: t
			};
		}
		return null;
	})();
	return d ? n.birthday !== i && c && s <= o * .12 && Ie() < .6 ? { action: { type: "askBill" } } : { action: d } : n.birthday === i ? { action: { type: "pass" } } : { action: { type: "askBill" } };
}, Ve = (e, t, n) => {
	switch (e.type) {
		case "play": {
			let t = n(T(e.card).nameKey), r = e.premiums?.length ? ` ×${2 ** e.premiums.length}` : "";
			return `${n("games.lacuenta.play")}:${t}${r}`;
		}
		case "pass": return n("games.lacuenta.pass");
		case "askBill": return n("games.lacuenta.askBillAria");
		case "tip": return n("games.lacuenta.tip", { value: t.public.cheapestTapa ?? 0 });
		case "split": return n(T(e.card).kind === "medias" ? "games.lacuenta.splitMediasAria" : "games.lacuenta.splitPachasAria");
		case "billDone": return n("games.lacuenta.billDoneAria");
		case "discard": return n("games.lacuenta.discardConfirm", { n: e.cards.length });
		default: return "";
	}
};
//#endregion
//#region src/games/lacuenta/fx.tsx
function He(e) {
	let t = e.anchor("deck-card");
	if (!t) return {
		w: 54,
		h: 76
	};
	let n = 7 * Math.PI / 180, r = t.w / (Math.cos(n) + 76 / 54 * Math.sin(n));
	return {
		w: r,
		h: r * 76 / 54
	};
}
function Ue(e) {
	for (let t of [
		"vegetal",
		"carne",
		"pescado"
	]) {
		let n = e.anchor(`col-card:${t}`);
		if (n) return {
			w: n.w,
			h: n.h
		};
	}
	return He(e);
}
function Q(e, t, n) {
	let r = e.anchor("table");
	return r ? {
		x: r.x + r.w / 2 - t / 2,
		y: r.y + r.h / 2 - n / 2,
		w: t,
		h: n
	} : null;
}
function $(e, t, n) {
	return e ? {
		x: e.x + e.w / 2 - t / 2,
		y: e.y + e.h / 2 - n / 2,
		w: t,
		h: n
	} : null;
}
function We(e, t, n, r) {
	if (t && t !== e.myRid) return $(e.anchor(`seat:${t}`), n, r) ?? Q(e, n, r);
	let i = e.anchor("hand-card");
	return i ? $(e.anchor("hand"), i.w, i.h) ?? Q(e, i.w, i.h) : $(e.anchor("hand"), n, r) ?? Q(e, n, r);
}
var Ge = {
	deal(e, t) {
		let { w: n, h: r } = He(t), i = $(t.anchor("deck-card") ?? t.anchor("deck"), n, r) ?? Q(t, n, r), a = e.rid === t.myRid ? We(t, e.rid, n, r) : $(e.rid ? t.anchor(`seat:${e.rid}`) : null, n, r);
		return !i || !a ? null : {
			ms: 320,
			node: /* @__PURE__ */ p(g, {
				from: i,
				to: a,
				ms: 300,
				children: /* @__PURE__ */ p(Ee, {
					size: "sm",
					dimensions: i
				})
			})
		};
	},
	play(e, t) {
		let n = e.data;
		if (typeof n?.card != "number") return null;
		let { w: r, h: i } = Ue(t), a = We(t, e.rid, r, i), o = typeof n.column == "string" ? t.anchor(`col-card:${n.column}`) ?? $(t.anchor(`col:${n.column}`), r, i) ?? Q(t, r, i) : n.kind === "vino" ? $(t.anchor("wine"), r, i) ?? Q(t, r, i) : Q(t, r, i);
		return !a || !o ? null : {
			ms: 380,
			node: /* @__PURE__ */ p(g, {
				from: a,
				to: o,
				ms: 360,
				children: /* @__PURE__ */ p(Z, {
					id: n.card,
					premiums: typeof n.premiums == "number" ? n.premiums : 0,
					size: "sm",
					dimensions: a
				})
			})
		};
	},
	askBill(e, t) {
		_();
		let n = Q(t, 96, 96);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ p("span", {
				className: "absolute grid place-items-center",
				style: {
					left: n.x,
					top: n.y,
					width: n.w,
					height: n.h
				},
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "bell-ring text-6xl",
					children: "🧾"
				})
			})
		} : {
			ms: 900,
			node: null
		};
	},
	tip(e, t) {
		let n = e.data, r = Q(t, 64, 32);
		return !r || typeof n?.value != "number" ? null : {
			ms: 800,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 750,
				children: /* @__PURE__ */ m("span", {
					className: "inline-flex items-center gap-0.5 text-warn-ink",
					children: [
						"🪙+",
						n.value,
						"€"
					]
				})
			})
		};
	},
	split(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!r || typeof n?.kind != "string") return null;
		let i = n.kind === "medias" ? "🤝" : n.kind === "pachas" ? "🍻" : "✖️";
		return {
			ms: 900,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 850,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "text-2xl",
					children: i
				})
			})
		};
	},
	settle(e, t) {
		v();
		let n = e.data;
		if (!n?.paid || typeof n.paid != "object") return null;
		let r = Object.entries(n.paid).map(([e, n]) => {
			let r = t.anchor(`seat:${e}`);
			return !r || n <= 0 ? null : /* @__PURE__ */ p(h, {
				at: r,
				ms: 1300,
				children: /* @__PURE__ */ m("span", {
					className: "font-mono font-extrabold tabular-nums text-danger",
					children: [
						"-",
						n,
						"€"
					]
				})
			}, e);
		});
		return {
			ms: 1400,
			node: /* @__PURE__ */ p(f, { children: r })
		};
	}
};
//#endregion
//#region src/games/lacuenta/game-over.tsx
function Ke({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ p("div", {
		className: "lc-game-over",
		children: /* @__PURE__ */ p(ee, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: k.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/lacuenta/entry.tsx
var qe = {
	definition: _e,
	View: De,
	bot: Be,
	describe: Ve,
	fx: Ge,
	OverView: Ke,
	locales: {
		zh: {
			name: "谁来买单",
			desc: "轮流出菜品堆高账单,谁敢喊「买单」谁掏钱——盯紧便宜账单,别当最后的冤大头!",
			rules: "目标:\n· 任意玩家存款耗尽时游戏立即结束,存款最多的玩家获胜。\n准备:\n· 每名玩家获得 5 张手牌和一笔初始存款。玩家人数越多，初始存款越多。\n· 牌堆耗尽时,将弃牌堆洗回作为新的牌堆。\n出牌:\n· 自己的回合中打出 1 张牌,出牌后不补牌;结账后统一补至各自的手牌上限。\n· 菜品分素菜、肉类、海鲜三列。\n· 向已有牌的列出牌时,新牌价格不得低于列顶牌;向空列出牌不受价格限制。\n· 每列的全部菜品牌，包括被其他牌盖住的菜品牌，其价格均计入账单。\n· 红酒不属于任何菜品列,随时可以打出。\n· 红酒每五杯为一组循环计算。同组内第一至第五杯的价值依次为 30 欧元、60 欧元、120 欧元、180 欧元和 240 欧元。\n特殊牌:\n· 烧焦的菜:封锁一条菜品列,本轮该列不能再出牌,并按牌面负值冲减账单。\n· 精品卡与一张菜品或烧焦的菜叠加打出,使其价格翻倍;可叠加多张,每张再翻一倍。\n· 反转:将行动顺序反向,下一轮开始时恢复。\n· 厕所:你不参与结账与分摊,该状态在你的下个回合开始时解除。\n· 咖啡:仅当三类菜品列均已有牌时可以打出;打出后,本轮其余时间只能打出咖啡与厕所。\n· 打出生日蛋糕时，账单增加 40 欧元。本轮你可以跳过自己的回合，并且不参与结账与费用分摊。\n叫账:\n· 本轮已出牌数达到玩家人数后,任何玩家均可叫账,由叫账人支付账单。\n· 处于厕所与生日状态的玩家不能叫账。\n· 自己的回合中没有可以打出的牌时,必须叫账。\n结账:\n· 叫账后,所有参与结账的玩家可以补打小费。\n· 每张小费按桌上最便宜的一张菜品(含被盖住的牌)的价格计入账单。\n· 账单发生变化后,所有玩家须重新确认。\n· 叫账人可以打出 AA 制:指定一名参与结账的玩家,两人各付一半。\n· 叫账人也可以打出「大家分摊」，由所有参与结账的玩家平均分摊账单，每人的应付金额向上取整至 5 欧元的倍数。\n· 处于厕所与生日状态的玩家不参与结账。\n结算:\n· 叫账时已出牌数未达到玩家人数:叫账人弃掉全部手牌。\n· 叫账时已出牌数达到玩家人数:叫账人的手牌上限增加 1 张(至多 10 张)。\n· 随后叫账人可以弃掉任意张手牌。\n· 随后桌面清空,全员补牌至各自的手牌上限,由叫账人开始下一轮。\n· 若叫账人新一轮开始没有可以打出的牌,则弃掉全部手牌并重新摸至手牌上限。",
			roundShort: "第 {{n}} 轮",
			yourTurn: "轮到你点单",
			waiting: "等 {{name}} 点单…",
			birthdayTurn: "你过生日:可以出牌,也可以跳过",
			pass: "跳过(生日免单)",
			forcedBill: "没有能出的牌,必须喊买单",
			billMine: "你喊了买单,这顿你请!",
			billWaiting: "{{name}} 喊了买单,结账中…",
			billWindow: "可补打小费,完毕请确认",
			billProgress: "已确认 {{n}}/{{total}}",
			discardPrompt: "出牌数已达标:可弃掉任意张手牌,手牌上限增加 1 张",
			discardWaiting: "等 {{name}} 弃牌…",
			discardConfirm: "好了(弃 {{n}} 张)",
			settleTitle: "结账:共 {{total}}€",
			paysOther: "{{name}} 付 {{amount}}€",
			thresholdMiss: "未达门槛,弃掉全部手牌",
			askBill: "买单!",
			askBillAria: "喊买单,由你支付当前账单",
			askBillHint: "已出 {{n}}/{{total}} 张,可以喊买单",
			tip: "加小费 +{{value}}€",
			tipAria: "加一张小费",
			splitMedias: "AA 制",
			splitMediasAria: "指定一位玩家与你各付一半",
			splitPachas: "大家分摊",
			splitPachasAria: "所有人均摊账单",
			cancelSplit: "改回一人全付",
			billDone: "完毕",
			billDoneAria: "确认结账",
			play: "打出",
			playPremium: "打出 ×{{mult}}",
			chooseColumn: "点上方一列烧焦它",
			burnHere: "烧焦此盘",
			colVegetal: "素菜",
			colCarne: "肉类",
			colPescado: "海鲜",
			colEmpty: "任意开列",
			colNext: "需 ≥{{value}}€",
			colBlocked: "已烧焦",
			columnSubtotal: "×{{n}} · 小计 {{total}}€",
			receiptTitle: "LA CUENTA · 聚餐账单",
			receiptPayer: "买单人",
			receiptTips: "小费 {{n}}×{{value}}€",
			receiptSplit: "分摊方式",
			receiptPlateDetail: "查看{{name}}盘全部菜牌",
			receiptPlateRule: "顶牌决定下一张的出牌门槛；整摞都计入账单。",
			receiptTopCard: "顶牌",
			receiptCoveredCard: "被盖住",
			receiptBurntCard: "烧焦冲减",
			receiptTipUnit: "小费按全桌最便宜的菜计算，含被盖住的菜：{{value}}€",
			receiptPlayable: "↓ 可出",
			receiptEmptyPlate: "空盘",
			wineNext: "下一杯 {{value}}€",
			wineCount: "已上 {{n}} 杯",
			cafeLock: "只收咖啡与厕所",
			reversed: "顺序已反转",
			playedCount: "已出 {{n}}/{{total}} 张",
			savings: "存款 {{amount}}€",
			handCount: "{{n}} 张",
			handAria: "手牌",
			toiletBadge: "厕所中",
			birthdayBadge: "过生日",
			deckAria: "牌堆余 {{n}} 张",
			extrasAria: "本轮打出的特殊牌",
			cardBack: "卡背",
			card: {
				vino: "红酒",
				quemado: "烧焦的菜",
				cambio: "反转方向",
				premium: "精品 ×2",
				toilette: "厕所",
				cafe: "咖啡",
				pastel: "生日蛋糕",
				medias: "AA 制",
				pachas: "大家分摊",
				propina: "小费"
			},
			dish: {
				aceitunas: "油橄榄",
				gazpacho: "冷汤",
				patatasBravas: "辣汁土豆",
				tortilla: "土豆蛋饼",
				pimientos: "帕德龙青椒",
				ensaladilla: "俄式沙拉",
				berenjenas: "蜂蜜茄子",
				tablaQuesos: "奶酪拼盘",
				chorizo: "辣香肠",
				croquetas: "可乐饼",
				albondigas: "肉丸",
				pinchito: "摩洛哥烤串",
				morcilla: "血肠",
				callos: "炖牛肚",
				raboDeToro: "炖牛尾",
				jamon: "伊比利亚火腿",
				mejillones: "贻贝",
				sardinas: "炸沙丁鱼",
				calamares: "炸鱿鱼圈",
				chipirones: "炸小鱿鱼",
				anchoa: "凤尾鱼",
				pulpo: "加利西亚章鱼",
				gambas: "蒜香虾",
				percebes: "鹅颈藤壶"
			},
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张牌现在打不了",
			errNoThreshold: "出的牌还不够人数,不能喊买单",
			errImmune: "厕所与生日中不能这么做",
			errBadPhase: "现在不能这么做",
			errBadTarget: "不能选这位玩家",
			errBadDiscard: "这些牌不在你手里"
		},
		en: {
			name: "La Cuenta",
			desc: "Play tapas to inflate the bill — whoever calls \"la cuenta\" pays it. Snatch the cheap ones, dodge the pricey ones!",
			rules: "Goal:\n· The game ends immediately when any player runs out of savings; the player with the most savings wins.\nSetup:\n· Each player is dealt 5 cards and receives starting savings; the more players, the larger the amount.\n· When the deck is exhausted, shuffle the discard pile to form a new deck.\nPlaying:\n· On your turn, play 1 card without drawing a replacement; everyone refills to their hand limit after the bill is settled.\n· Tapas are played into three columns: veggie, meat, and seafood.\n· A tapa played into a column must cost at least as much as the card on top; an empty column accepts any price.\n· Every tapa in each stack, including covered cards, adds to the bill.\n· Wine is not bound to any column and may be played at any time.\n· Wine is counted in repeating groups of five glasses. Within each group, the first through fifth glasses are worth €30, €60, €120, €180 and €240 respectively.\nSpecials:\n· Burnt dish: blocks one tapa column for the rest of the round and reduces the bill by the amount shown on the card.\n· Premium cards are played stacked on a tapa or burnt dish and double its price; several may stack, each doubling again.\n· Reversal: reverses the order of play until the next round begins.\n· Toilet: you take no part in checkout or splitting; the effect ends when your next turn begins.\n· Coffee: playable only when all three tapa columns hold at least one card; afterwards, only coffee and toilet may be played for the rest of the round.\n· Birthday cake: adds 40€ to the bill; this round you may skip your turns and take no part in checkout or splitting.\nThe bill:\n· Once the number of cards played this round reaches the number of players, any player may call the bill; the caller pays it.\n· Players in the toilet or having a birthday may not call the bill.\n· If you have no playable card on your turn, you must call the bill.\nCheckout:\n· After the call, every player taking part in checkout may add tips.\n· Each tip uses the cheapest tapa on the table, including covered cards.\n· Whenever the bill changes, all players must confirm again.\n· The caller may play Split: the caller and a chosen player each pay half.\n· Or play Share: the bill is split evenly among the players taking part, each share rounded up to a multiple of 5€.\n· Players in the toilet or having a birthday take no part in checkout.\nAftermath:\n· If fewer cards were played than there are players, the caller discards their entire hand.\n· If the threshold was met, the caller's hand limit increases by 1 (up to 10).\n· The caller may then discard any number of cards.\n· The table is then cleared, everyone draws up to their hand limit, and the caller opens the next round.\n· If the caller has no playable card at that point, they discard their entire hand and redraw up to their hand limit.",
			roundShort: "Round {{n}}",
			yourTurn: "Your turn to order",
			waiting: "Waiting for {{name}}…",
			birthdayTurn: "It's your birthday: play or skip",
			pass: "Skip (birthday treat)",
			forcedBill: "Nothing playable — you must call the bill",
			billMine: "You called the bill. Treat time!",
			billWaiting: "{{name}} called the bill…",
			billWindow: "Add tips, then confirm",
			billProgress: "Confirmed {{n}}/{{total}}",
			discardPrompt: "Threshold met: discard any number of cards, hand limit increases by 1",
			discardWaiting: "Waiting for {{name}} to discard…",
			discardConfirm: "Done ({{n}} discarded)",
			settleTitle: "Bill: {{total}}€",
			paysOther: "{{name}} pays {{amount}}€",
			thresholdMiss: "Below threshold — whole hand discarded",
			askBill: "La cuenta!",
			askBillAria: "Call the bill and pay it yourself",
			askBillHint: "{{n}}/{{total}} cards played — you may call the bill",
			tip: "Tip +{{value}}€",
			tipAria: "Add a tip",
			splitMedias: "Split",
			splitMediasAria: "Pick a player to pay half each",
			splitPachas: "Share",
			splitPachasAria: "Split the bill among everyone",
			cancelSplit: "Pay it all myself",
			billDone: "Done",
			billDoneAria: "Confirm checkout",
			play: "Play",
			playPremium: "Play ×{{mult}}",
			chooseColumn: "Tap a column above to burn it",
			burnHere: "Burn plate",
			colVegetal: "Veggie",
			colCarne: "Meat",
			colPescado: "Seafood",
			colEmpty: "Any price opens",
			colNext: "Needs ≥{{value}}€",
			colBlocked: "Burnt",
			columnSubtotal: "×{{n}} · {{total}}€ total",
			receiptTitle: "LA CUENTA · DINNER BILL",
			receiptPayer: "Payer",
			receiptTips: "Tips {{n}}×{{value}}€",
			receiptSplit: "Split",
			receiptPlateDetail: "View all cards on the {{name}} plate",
			receiptPlateRule: "The top card sets the next play minimum; the whole stack adds to the bill.",
			receiptTopCard: "Top card",
			receiptCoveredCard: "Covered",
			receiptBurntCard: "Burnt deduction",
			receiptTipUnit: "Tips use the cheapest tapa on the table, including covered cards: {{value}}€",
			receiptPlayable: "↓ Playable",
			receiptEmptyPlate: "Empty",
			wineNext: "Next glass {{value}}€",
			wineCount: "{{n}} glasses served",
			cafeLock: "Coffee & toilet only",
			reversed: "Order reversed",
			playedCount: "{{n}}/{{total}} cards played",
			savings: "Savings {{amount}}€",
			handCount: "{{n}} cards",
			handAria: "Hand",
			toiletBadge: "In the toilet",
			birthdayBadge: "Birthday",
			deckAria: "{{n}} cards left in deck",
			extrasAria: "Special cards played this round",
			cardBack: "Card back",
			card: {
				vino: "Wine",
				quemado: "Burnt Dish",
				cambio: "Reversal",
				premium: "Premium ×2",
				toilette: "Toilet",
				cafe: "Coffee",
				pastel: "Birthday Cake",
				medias: "Split",
				pachas: "Share",
				propina: "Tip"
			},
			dish: {
				aceitunas: "Olives",
				gazpacho: "Gazpacho",
				patatasBravas: "Patatas Bravas",
				tortilla: "Potato Omelette",
				pimientos: "Padrón Peppers",
				ensaladilla: "Russian Salad",
				berenjenas: "Honey Eggplant",
				tablaQuesos: "Cheese Board",
				chorizo: "Chorizo",
				croquetas: "Croquettes",
				albondigas: "Meatballs",
				pinchito: "Moorish Skewer",
				morcilla: "Blood Sausage",
				callos: "Tripe Stew",
				raboDeToro: "Oxtail Stew",
				jamon: "Jamón Ibérico",
				mejillones: "Mussels",
				sardinas: "Fried Sardines",
				calamares: "Calamari",
				chipirones: "Fried Baby Squid",
				anchoa: "Anchovy",
				pulpo: "Galician Octopus",
				gambas: "Garlic Shrimp",
				percebes: "Goose Barnacles"
			},
			errNotYourTurn: "Not your turn",
			errBadCard: "Can't play this card now",
			errNoThreshold: "Not enough cards played to call the bill",
			errImmune: "Not while in the toilet or on your birthday",
			errBadPhase: "Not right now",
			errBadTarget: "Can't pick that player",
			errBadDiscard: "Those cards are not in your hand"
		}
	}
};
//#endregion
export { qe as default };
