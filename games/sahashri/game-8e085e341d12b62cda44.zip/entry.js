import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { ConfirmButton as o } from "@bgparty/sdk/confirm-button";
import { useT as s } from "@bgparty/sdk/i18n";
import { PhaseBanner as c } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as l } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { Confetti as m } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as h, OptionSection as g } from "@bgparty/sdk/ui/game-options";
//#region src/games/sahashri/cards.ts
var _ = [
	"gold",
	"red",
	"blue",
	"green",
	"purple"
], ee = (e, t) => {
	let n = t >= 3;
	switch (e) {
		case "gold": return n ? "goldRescue" : "goldReturn";
		case "red": return n ? "redCut2" : "redCut1";
		case "blue": return n ? "blueEcho" : "blueShift";
		case "green": return n ? "greenWild" : "greenSpin";
		case "purple": return n ? "purpleBlock" : "purpleVeil";
	}
}, v = {
	gold: [
		[1, [
			!1,
			!1,
			!1,
			!0
		]],
		[1, [
			!1,
			!0,
			!1,
			!1
		]],
		[2, [
			!0,
			!1,
			!0,
			!1
		]],
		[2, [
			!1,
			!0,
			!1,
			!0
		]],
		[3, [
			!0,
			!1,
			!1,
			!0
		]],
		[4, [
			!1,
			!0,
			!0,
			!1
		]],
		[5, [
			!0,
			!1,
			!0,
			!0
		]]
	],
	blue: [
		[1, [
			!1,
			!1,
			!0,
			!1
		]],
		[1, [
			!0,
			!1,
			!1,
			!1
		]],
		[2, [
			!0,
			!1,
			!1,
			!0
		]],
		[2, [
			!1,
			!0,
			!0,
			!1
		]],
		[3, [
			!1,
			!0,
			!1,
			!0
		]],
		[4, [
			!0,
			!1,
			!0,
			!1
		]],
		[5, [
			!0,
			!0,
			!1,
			!0
		]]
	],
	green: [
		[1, [
			!1,
			!0,
			!1,
			!1
		]],
		[1, [
			!0,
			!1,
			!1,
			!1
		]],
		[2, [
			!0,
			!1,
			!0,
			!1
		]],
		[2, [
			!1,
			!0,
			!1,
			!0
		]],
		[3, [
			!1,
			!1,
			!0,
			!0
		]],
		[4, [
			!0,
			!0,
			!1,
			!1
		]],
		[5, [
			!1,
			!0,
			!0,
			!0
		]]
	],
	purple: [
		[1, [
			!0,
			!1,
			!0,
			!1
		]],
		[1, [
			!1,
			!0,
			!1,
			!0
		]],
		[2, [
			!1,
			!1,
			!0,
			!0
		]],
		[2, [
			!0,
			!0,
			!1,
			!1
		]],
		[3, [
			!0,
			!1,
			!1,
			!0
		]],
		[4, [
			!1,
			!0,
			!0,
			!1
		]],
		[5, [
			!1,
			!1,
			!0,
			!0
		]]
	],
	red: [
		[1, [
			!1,
			!1,
			!1,
			!0
		]],
		[1, [
			!1,
			!1,
			!0,
			!1
		]],
		[2, [
			!1,
			!0,
			!0,
			!1
		]],
		[2, [
			!0,
			!1,
			!1,
			!0
		]],
		[3, [
			!0,
			!0,
			!1,
			!1
		]],
		[4, [
			!1,
			!1,
			!0,
			!0
		]],
		[5, [
			!0,
			!0,
			!0,
			!1
		]]
	]
}, y = {
	gold: "g",
	red: "r",
	blue: "b",
	green: "n",
	purple: "p"
}, b = _.flatMap((e) => {
	let t = y[e], n = v[e];
	return n.map(([r, i], a) => {
		let o = n.filter(([e]) => e === r).length === 2 ? n.findIndex(([e]) => e === r) === a ? "a" : "b" : "";
		return {
			id: `${t}${r}${o}`,
			color: e,
			value: r,
			ability: ee(e, r),
			pattern: i
		};
	});
}), x = new Map(b.map((e) => [e.id, e])), te = {
	gold: "raven-gold",
	red: "raven-red",
	blue: "raven-blue",
	green: "raven-green",
	purple: "raven-purple"
};
_.map((e) => te[e]);
var S = (e) => e.startsWith("raven-");
function C(e) {
	return [
		e[3],
		e[2],
		e[1],
		e[0]
	];
}
var ne = /* @__PURE__ */ new Set([
	"goldReturn",
	"goldRescue",
	"redCut1",
	"redCut2"
]), w = [
	7,
	7,
	7,
	5
], T = {
	id: "sahashri",
	tier: "alpha",
	mechanics: ["tile-placement", "push-your-luck"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.sahashri.name",
	descKey: "games.sahashri.desc",
	rulesKey: "games.sahashri.rules",
	icon: "🐦‍⬛",
	iconImg: "games/sahashri.webp",
	rulesUrl: { en: "https://www.ospreypublishing.com/media/1mokvhb4/rots-rulebook-for-web.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#4338ca",
	releasedAt: "2026-09-15",
	search: {
		py: "san qian ya sha",
		init: "sqys"
	},
	hotseat: "cover"
}, E = t.string().min(1), D = t.enum([
	"gold",
	"red",
	"blue",
	"green",
	"purple"
]), re = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("arrangeHearts"),
		order: t.array(E).length(4)
	}),
	t.object({ type: t.literal("draw") }),
	t.object({ type: t.literal("finishDraw") }),
	t.object({ type: t.literal("useVeil") }),
	t.object({
		type: t.literal("placeCard"),
		card: E,
		x: t.int().min(-20).max(20),
		y: t.int().min(-20).max(20),
		rot: t.boolean(),
		shift: t.int().min(-4).max(4),
		echo: E.nullable(),
		wild: t.boolean()
	}),
	t.object({ type: t.literal("finishPlace") }),
	t.object({
		type: t.literal("takeCard"),
		card: E,
		scoreCards: t.array(E).max(10)
	}),
	t.object({
		type: t.literal("revealHeart"),
		index: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("chooseChunk"),
		keep: t.int().min(0).max(15)
	}),
	t.object({
		type: t.literal("stealBlock"),
		color: D
	}),
	t.object({ type: t.literal("stealPass") }),
	t.object({
		type: t.literal("useRed"),
		targets: t.array(E).min(1).max(2),
		hi: t.boolean()
	}),
	t.object({
		type: t.literal("useGoldReturn"),
		picks: t.array(E).length(3)
	}),
	t.object({
		type: t.literal("peekStolen"),
		color: D
	}),
	t.object({
		type: t.literal("goldRescue"),
		card: E
	}),
	t.object({ type: t.literal("cancelPeek") }),
	t.object({ type: t.literal("endDream") })
]), ie = t.object({ hostRole: t.enum([
	"random",
	"ren",
	"feth"
]).default("random") }).default({ hostRole: "random" }), ae = t.enum([
	"deck",
	"row",
	"chased",
	"defeated"
]), O = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("heartReveal"),
		color: D,
		candidates: t.array(t.int())
	}),
	t.object({
		kind: t.literal("splitChoice"),
		chunks: t.array(t.array(E))
	}),
	t.object({
		kind: t.literal("steal"),
		groups: t.array(t.object({
			color: D,
			count: t.int()
		}))
	}),
	t.object({
		kind: t.literal("peekStolen"),
		color: D
	})
]), oe = t.object({
	dream: t.int().min(1).max(3),
	phase: t.enum([
		"arrange",
		"draw",
		"place",
		"renTake",
		"dreamEnd",
		"done"
	]),
	roles: t.object({
		ren: t.string(),
		feth: t.string()
	}),
	deckCount: t.int().nonnegative(),
	discard: t.array(E),
	ravens: t.record(D, ae),
	stolenCounts: t.record(D, t.int().nonnegative()),
	atman: t.array(t.object({
		id: E,
		x: t.int(),
		y: t.int(),
		rot: t.boolean()
	})),
	memoryRow: t.array(t.object({
		id: E,
		safe: t.boolean()
	})),
	safeN: t.int().nonnegative(),
	hearts: t.array(t.object({
		color: D.nullable(),
		value: t.int().nullable(),
		faceUp: t.boolean(),
		sideways: t.boolean()
	})),
	poemRows: t.array(t.object({ cards: t.array(t.object({
		id: E,
		used: t.boolean()
	})) })),
	rowsDone: t.array(t.boolean()),
	score: t.array(E),
	scoreRavens: t.int().nonnegative(),
	placedThisTurn: t.int().nonnegative(),
	pending: O.nullable(),
	loseReason: t.string().nullable()
}), k = t.object({
	hearts: t.array(E).optional(),
	peek: t.array(E).optional()
}), A = [
	[0, 0],
	[1, 0],
	[0, 1],
	[1, 1]
];
function se(e) {
	let t = x.get(e.id).pattern;
	return e.rot ? C(t) : t;
}
var ce = (e, t, n) => t >= e.x && t <= e.x + 1 && n >= e.y && n <= e.y + 1;
function j(e, t, n) {
	for (let r = e.length - 1; r >= 0; --r) if (ce(e[r], t, n)) return r;
	return -1;
}
function M(e, t) {
	let n = e[t];
	return A.some(([r, i]) => j(e, n.x + r, n.y + i) === t);
}
function N(e) {
	return e.map((e, t) => t).filter((t) => M(e, t));
}
function P(e) {
	let t = N(e), n = new Map(t.map((e) => [e, e])), r = (e) => {
		let t = e;
		for (; n.get(t) !== t;) t = n.get(t);
		return n.set(e, t), t;
	};
	for (let i = 0; i < t.length; i += 1) for (let a = i + 1; a < t.length; a += 1) {
		let o = e[t[i]], s = e[t[a]];
		if (A.some(([e, t]) => ce(s, o.x + e, o.y + t))) {
			let e = r(t[i]), o = r(t[a]);
			e !== o && n.set(e, o);
		}
	}
	let i = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = r(e);
		i.has(t) || i.set(t, []), i.get(t).push(e);
	}
	return [...i.values()];
}
function le(e, t, n) {
	let [r, i] = t < n ? [t, n] : [n, t], a = e[t], o = e[n];
	for (let [t, n] of A) {
		let s = a.x + t, c = a.y + n;
		if (!ce(o, s, c)) continue;
		let l = !1;
		for (let t = r + 1; t < i; t += 1) if (ce(e[t], s, c)) {
			l = !0;
			break;
		}
		if (!l) return !0;
	}
	return !1;
}
function F(e, t, n, r, i, a) {
	let o = x.get(t), s = i ? C(o.pattern) : o.pattern, c = !1, l = !1, u = /* @__PURE__ */ new Set();
	for (let t = 0; t < 4; t += 1) {
		let [i, o] = A[t], d = j(e, n + i, r + o);
		if (d < 0) continue;
		c = !0, u.add(d);
		let f = se(e[d])[(r + o - e[d].y) * 2 + (n + i - e[d].x)];
		if (!a) {
			if (f !== s[t]) return "games.sahashri.errMismatch";
			s[t] && (l = !0);
		}
	}
	if (!c) return "games.sahashri.errNoOverlap";
	if (!a && !l) return "games.sahashri.errNoFaded";
	if (u.size === 1) {
		let t = e[[...u][0]];
		if (t.x === n && t.y === r && se(t).every((e, t) => e === s[t])) return "games.sahashri.errSamePattern";
	}
	return null;
}
function ue(e, t, n) {
	let r = [], i = /* @__PURE__ */ new Set(), a = [];
	for (let t of e) for (let e = -1; e <= 1; e += 1) for (let n = -1; n <= 1; n += 1) {
		let r = `${t.x + e},${t.y + n}`;
		i.has(r) || (i.add(r), a.push({
			x: t.x + e,
			y: t.y + n
		}));
	}
	let o = n.rot ? [!1, !0] : [!1];
	for (let i of o) for (let { x: o, y: s } of a) F(e, t, o, s, i, n.wild) === null && r.push({
		x: o,
		y: s,
		rot: i
	});
	return r;
}
function I(e, t) {
	return e.poemRows.flatMap((e) => e.cards).filter((e) => !e.used && x.get(e.id).ability === t).length;
}
function L(e, t) {
	for (let n of e.poemRows) for (let e of n.cards) if (!e.used && x.get(e.id).ability === t) return e.used = !0, !0;
	return !1;
}
function de(t, n) {
	let r = [...t];
	for (let t = r.length - 1; t > 0; --t) {
		let i = e(n.seed, n.rngCursor, t + 1);
		n.rngCursor += 1, [r[t], r[i]] = [r[i], r[t]];
	}
	return r;
}
function R(e, t, n) {
	e.phase = "done", e.loseReason = n, e.pending = [], e.result = {
		win: !1,
		score: e.score.length,
		ending: "normal"
	}, t.push({
		kind: "lose",
		data: { reason: n }
	});
}
function fe(e, t) {
	let n = e.score.length, r = n >= 11 && e.scoreRavens >= 2 ? "happy" : n >= 4 ? "good" : "normal";
	e.phase = "done", e.pending = [], e.result = {
		win: !0,
		score: n,
		ending: r
	}, t.push({
		kind: "win",
		data: {
			score: n,
			ending: r
		}
	});
}
var pe = (e, t) => x.get(e.hearts[t].id).value + e.poemRows[t].cards.reduce((e, t) => e + x.get(t.id).value, 0), z = (e, t) => t === 3 && e.row3Auto ? !0 : e.hearts.length === 4 && pe(e, t) === w[t], me = (e) => z(e, 0) && z(e, 1) && z(e, 2) && z(e, 3);
function B(e, t, n, r) {
	let i = /* @__PURE__ */ new Map(), a = [];
	for (let t of n) {
		let n = x.get(t).color;
		e.ravens[n] === "row" ? (i.has(n) || i.set(n, []), i.get(n).push(t)) : a.push(t);
	}
	if (e.discard.push(...a), a.length > 0 && t.push({
		kind: "discard",
		data: { count: a.length }
	}), i.size === 0) {
		he(e, t, r);
		return;
	}
	if (I(e, "purpleBlock") > 0) {
		e.pending.push({
			kind: "steal",
			groups: [...i].map(([e, t]) => ({
				color: e,
				cards: t
			})),
			resume: r
		}), t.push({
			kind: "stealWarn",
			data: { colors: [...i.keys()] }
		});
		return;
	}
	for (let [t, n] of i) e.stolen[t].push(...n);
	t.push({
		kind: "steal",
		data: { colors: [...i.keys()] }
	}), he(e, t, r);
}
function he(e, t, n) {
	n === "finishPlace" ? (e.memoryRow = [], e.phase = "renTake", e.awaiting = "take") : n === "dreamEnd" && be(e, t);
}
function ge(e, t) {
	if (e.awaiting = "take", N(e.atman).length === 0) return R(e, t, "games.sahashri.loseAtman");
	if (me(e)) {
		let n = new Set(e.hearts.map((e) => x.get(e.id).color));
		if ([...new Set(N(e.atman).map((t) => x.get(e.atman[t].id).color))].every((e) => n.has(e))) {
			e.phase = "dreamEnd", t.push({
				kind: "poemComplete",
				data: { dream: e.dream }
			});
			return;
		}
		if (e.dream === 3) return R(e, t, "games.sahashri.loseDream3Color");
	}
	V(e, t);
}
function V(e, t) {
	if (e.deck.length === 0) return R(e, t, "games.sahashri.loseDeck");
	e.phase = "draw", e.turnSafe = _.filter((t) => e.ravens[t] === "row").length, e.veil = 0, e.drawn = 0, e.placedThisTurn = 0, t.push({
		kind: "turn",
		data: { dream: e.dream }
	});
}
function _e(e, t) {
	e.phase === "renTake" && e.awaiting === "settle" && e.pending.length === 0 && ge(e, t);
}
function ve(e, t, n, r) {
	let i = x.get(e[t].id).color, a = (t) => n !== null && e[t].id === n ? i : x.get(e[t].id).color, o = (n) => n === t ? r : x.get(e[n].id).value, s = N(e).filter((e) => a(e) === i);
	if (!s.includes(t)) return !1;
	let c = /* @__PURE__ */ new Set([t]), l = [t];
	for (; l.length > 0;) {
		let t = l.pop();
		for (let n of s) !c.has(n) && le(e, t, n) && (c.add(n), l.push(n));
	}
	let u = [...c].filter((e) => e !== t), d = 7 - o(t);
	if (d < 0) return !1;
	let f = (n) => {
		let r = 0, i = [];
		for (let e = 0; e < u.length; e += 1) n & 1 << e && (i.push(u[e]), r += o(u[e]));
		if (r !== d) return !1;
		let a = /* @__PURE__ */ new Set([t, ...i]), s = /* @__PURE__ */ new Set([t]), c = [t];
		for (; c.length > 0;) {
			let t = c.pop();
			for (let n of a) !s.has(n) && le(e, t, n) && (s.add(n), c.push(n));
		}
		return s.size === a.size;
	};
	for (let e = 0; e < 1 << u.length; e += 1) if (f(e)) return !0;
	return !1;
}
function H(e, t, n) {
	t.push({
		kind: "relive",
		data: { color: n }
	}), e.ravens[n] === "row" && (e.dream === 3 ? (e.ravens[n] = "defeated", e.score.push(`raven-${n}`, ...e.stolen[n]), e.scoreRavens += 1, e.stolen[n] = [], t.push({
		kind: "ravenDefeated",
		data: { color: n }
	})) : (e.ravens[n] = "chased", e.discard.push(...e.stolen[n]), e.stolen[n] = [], t.push({
		kind: "ravenChased",
		data: { color: n }
	})));
	let r = e.hearts.map((e, t) => ({
		h: e,
		i: t
	})).filter(({ h: e }) => !e.faceUp && x.get(e.id).color === n).map(({ i: e }) => e);
	r.length === 1 ? U(e, t, r[0]) : r.length > 1 && e.pending.push({
		kind: "heartReveal",
		color: n,
		candidates: r
	});
}
function U(e, t, n) {
	e.hearts[n].faceUp = !0;
	for (let t of e.poemRows[n].cards) t.used = !1;
	t.push({
		kind: "heartReveal",
		data: {
			index: n,
			color: x.get(e.hearts[n].id).color
		}
	});
}
function ye(e, t) {
	let n = [], r = [];
	for (let t of e.deck) !S(t) && n.length < 5 ? n.push(t) : r.push(t);
	return n.length < 5 ? !1 : (e.deck = r, e.atman = [{
		id: n[0],
		x: 0,
		y: 0,
		rot: !1
	}], e.hearts = n.slice(1).map((e) => ({
		id: e,
		faceUp: !1,
		sideways: !1
	})), e.poemRows = [
		{ cards: [] },
		{ cards: [] },
		{ cards: [] },
		{ cards: [] }
	], e.row3Auto = !1, e.phase = "arrange", e.awaiting = "take", t.push({
		kind: "dreamStart",
		data: { dream: e.dream }
	}), !0);
}
function be(e, t) {
	for (let t of _) e.removed.push(...e.stolen[t]), e.stolen[t] = [];
	for (let t of _) e.ravens[t] === "chased" && (e.ravens[t] = "row");
	if (e.dream === 3) return fe(e, t);
	e.dream += 1, e.deck = de([...e.deck, ...e.discard], e), e.discard = [], e.memoryRow = [], ye(e, t) || R(e, t, "games.sahashri.loseDeck");
}
function xe(t, n, r) {
	let i = {
		seed: r,
		rngCursor: 0,
		players: n,
		roles: {
			ren: "",
			feth: ""
		},
		dream: 1,
		phase: "arrange",
		deck: [],
		discard: [],
		removed: [],
		ravens: {
			gold: "deck",
			red: "deck",
			blue: "deck",
			green: "deck",
			purple: "deck"
		},
		stolen: {
			gold: [],
			red: [],
			blue: [],
			green: [],
			purple: []
		},
		atman: [],
		memoryRow: [],
		turnSafe: 0,
		veil: 0,
		drawn: 0,
		placedThisTurn: 0,
		hearts: [],
		poemRows: [
			{ cards: [] },
			{ cards: [] },
			{ cards: [] },
			{ cards: [] }
		],
		row3Auto: !1,
		score: [],
		scoreRavens: 0,
		pending: [],
		awaiting: "take",
		result: null,
		loseReason: null
	}, a = t.hostRole === "ren" || t.hostRole === "random" && e(r, i.rngCursor, 2) === 0;
	t.hostRole === "random" && (i.rngCursor += 1), i.roles = a ? {
		ren: n[0],
		feth: n[1]
	} : {
		ren: n[1],
		feth: n[0]
	}, i.deck = de([...b.map((e) => e.id), ..._.map((e) => `raven-${e}`)], i);
	let o = [];
	return ye(i, o), {
		state: i,
		fx: o
	};
}
var W = (e) => ({ code: e });
function Se(e, t, n) {
	let r = structuredClone(e), i = [], a = r.pending[0];
	if (a) {
		if (t.type === "revealHeart" && a.kind === "heartReveal") return n.by === r.roles.ren ? a.candidates.includes(t.index) ? (r.pending.shift(), U(r, i, t.index), _e(r, i), {
			state: r,
			fx: i
		}) : W("games.sahashri.errBadCard") : W("games.sahashri.errNotYourTurn");
		if (t.type === "chooseChunk" && a.kind === "splitChoice") {
			if (n.by !== r.roles.ren) return W("games.sahashri.errNotYourTurn");
			if (t.keep < 0 || t.keep >= a.chunks.length) return W("games.sahashri.errBadCard");
			r.pending.shift();
			let e = new Set(a.chunks.filter((e, n) => n !== t.keep).flat());
			return r.atman = r.atman.filter((t) => !e.has(t.id)), i.push({
				kind: "split",
				data: { keep: a.chunks[t.keep] }
			}), B(r, i, [...e], "none"), _e(r, i), {
				state: r,
				fx: i
			};
		}
		if ((t.type === "stealBlock" || t.type === "stealPass") && a.kind === "steal") {
			if (n.by !== r.roles.feth) return W("games.sahashri.errNotYourTurn");
			r.pending.shift();
			let e = null;
			if (t.type === "stealBlock") {
				if (!a.groups.some((e) => e.color === t.color)) return W("games.sahashri.errBadCard");
				if (!L(r, "purpleBlock")) return W("games.sahashri.errNoAbility");
				e = t.color;
			}
			for (let t of a.groups) t.color === e ? r.discard.push(...t.cards) : r.stolen[t.color].push(...t.cards);
			return i.push({
				kind: "steal",
				data: {
					colors: a.groups.map((e) => e.color),
					blocked: e
				}
			}), he(r, i, a.resume), _e(r, i), {
				state: r,
				fx: i
			};
		}
		if ((t.type === "goldRescue" || t.type === "cancelPeek") && a.kind === "peekStolen") {
			if (n.by !== a.by) return W("games.sahashri.errNotYourTurn");
			if (t.type === "cancelPeek") return r.pending.shift(), {
				state: r,
				fx: i
			};
			let e = r.stolen[a.color];
			return e.includes(t.card) ? L(r, "goldRescue") ? (r.pending.shift(), r.stolen[a.color] = e.filter((e) => e !== t.card), r.deck.unshift(t.card), i.push({
				kind: "ability",
				data: {
					ability: "goldRescue",
					color: a.color
				}
			}), {
				state: r,
				fx: i
			}) : W("games.sahashri.errNoAbility") : W("games.sahashri.errBadCard");
		}
		return W("games.sahashri.errPending");
	}
	switch (t.type) {
		case "arrangeHearts": {
			if (r.phase !== "arrange" || n.by !== r.roles.ren) return W("games.sahashri.errNotYourTurn");
			let e = r.hearts.map((e) => e.id);
			return t.order.length !== 4 || !t.order.every((t) => e.includes(t)) ? W("games.sahashri.errBadOrder") : (r.hearts = t.order.map((e) => r.hearts.find((t) => t.id === e)), V(r, i), {
				state: r,
				fx: i
			});
		}
		case "draw": {
			if (r.phase !== "draw" || n.by !== r.roles.feth) return W("games.sahashri.errNotYourTurn");
			if (r.deck.length === 0) return W("games.sahashri.errEmptyDeck");
			let e = r.deck.shift(), t = r.drawn < r.turnSafe + r.veil;
			return r.drawn += 1, S(e) ? t ? (r.discard.push(e), i.push({
				kind: "ravenSafe",
				data: { color: e.slice(6) }
			})) : (r.memoryRow.push({
				id: e,
				safe: t
			}), i.push({
				kind: "draw",
				data: { raven: e.slice(6) }
			})) : (r.memoryRow.push({
				id: e,
				safe: t
			}), i.push({
				kind: "draw",
				data: { card: e }
			})), {
				state: r,
				fx: i
			};
		}
		case "finishDraw": {
			if (r.phase !== "draw" || n.by !== r.roles.feth) return W("games.sahashri.errNotYourTurn");
			let e = r.memoryRow.filter((e) => S(e.id));
			for (let t of e) r.ravens[t.id.slice(6)] = "row", i.push({
				kind: "ravenRow",
				data: { color: t.id.slice(6) }
			});
			return r.memoryRow = r.memoryRow.filter((e) => !S(e.id)), _.every((e) => r.ravens[e] === "row") ? (R(r, i, "games.sahashri.loseRavens"), {
				state: r,
				fx: i
			}) : (r.phase = "place", {
				state: r,
				fx: i
			});
		}
		case "useVeil": return r.phase !== "draw" || n.by !== r.roles.feth ? W("games.sahashri.errNotYourTurn") : L(r, "purpleVeil") ? (r.veil += 2, i.push({
			kind: "ability",
			data: { ability: "purpleVeil" }
		}), {
			state: r,
			fx: i
		}) : W("games.sahashri.errNoAbility");
		case "placeCard": {
			if (r.phase !== "place" || n.by !== r.roles.feth) return W("games.sahashri.errNotYourTurn");
			if (!r.memoryRow.find((e) => e.id === t.card) || S(t.card)) return W("games.sahashri.errBadCard");
			let e = Math.abs(t.shift);
			if (t.rot && I(r, "greenSpin") === 0 || t.wild && I(r, "greenWild") === 0 || e > I(r, "blueShift")) return W("games.sahashri.errNoAbility");
			if (t.echo !== null) {
				if (I(r, "blueEcho") === 0) return W("games.sahashri.errNoAbility");
				let e = r.atman.findIndex((e) => e.id === t.echo);
				if (!(e >= 0 && M(r.atman, e) && A.some(([n, i]) => ce(r.atman[e], t.x + n, t.y + i)))) return W("games.sahashri.errBadEcho");
			}
			let a = F(r.atman, t.card, t.x, t.y, t.rot, t.wild);
			if (a) return W(a);
			t.rot && L(r, "greenSpin"), t.wild && L(r, "greenWild");
			for (let t = 0; t < e; t += 1) L(r, "blueShift");
			t.echo !== null && L(r, "blueEcho"), r.memoryRow = r.memoryRow.filter((e) => e.id !== t.card), r.atman.push({
				id: t.card,
				x: t.x,
				y: t.y,
				rot: t.rot
			}), r.placedThisTurn += 1, i.push({
				kind: "place",
				data: {
					card: t.card,
					x: t.x,
					y: t.y
				}
			});
			let o = x.get(t.card), s = Math.min(5, Math.max(1, o.value + t.shift));
			ve(r.atman, r.atman.length - 1, t.echo, s) && H(r, i, o.color);
			let c = P(r.atman);
			return c.length > 1 && (r.pending.push({
				kind: "splitChoice",
				chunks: c.map((e) => e.map((e) => r.atman[e].id))
			}), i.push({
				kind: "splitWarn",
				data: { chunks: c.length }
			})), {
				state: r,
				fx: i
			};
		}
		case "finishPlace": {
			if (r.phase !== "place" || n.by !== r.roles.feth) return W("games.sahashri.errNotYourTurn");
			if (r.placedThisTurn === 0) return R(r, i, "games.sahashri.loseNoPlace"), {
				state: r,
				fx: i
			};
			let e = [], t = [];
			for (let n of r.memoryRow) (n.safe ? e : t).push(n.id);
			return r.discard.push(...e), B(r, i, t, "finishPlace"), {
				state: r,
				fx: i
			};
		}
		case "takeCard": {
			if (r.phase !== "renTake" || r.awaiting !== "take" || n.by !== r.roles.ren) return W("games.sahashri.errNotYourTurn");
			let e = r.atman.findIndex((e) => e.id === t.card);
			if (e < 0 || !M(r.atman, e)) return W("games.sahashri.errBadCard");
			let a = x.get(t.card), o = t.scoreCards;
			if (r.dream !== 3 && o.length > 0) return W("games.sahashri.errBadTake");
			let s = new Set(o);
			if (s.size !== o.length || !o.every((e) => r.score.includes(e) && x.has(e))) return W("games.sahashri.errBadTake");
			r.atman = r.atman.filter((t, n) => n !== e), r.awaiting = "settle";
			let c = [
				0,
				1,
				2,
				3
			].find((e) => !z(r, e)), l = c === void 0 ? 0 : w[c] - pe(r, c);
			if (r.dream === 3 && c !== void 0) {
				let e = a.value, n = o.reduce((e, t) => e + x.get(t).value, 0), u = e + n === l, d = e <= l && Ce(r.score.map((e) => x.get(e)).filter((e) => e !== void 0).map((e) => e.value), l - e);
				if (!u && (d || n !== l)) return d || Ce(r.score.filter((e) => x.has(e)).map((e) => x.get(e).value), l) ? W("games.sahashri.errBadTake") : (R(r, i, "games.sahashri.loseDream3Row"), {
					state: r,
					fx: i
				});
				let f = u ? [t.card, ...o] : o;
				r.score = r.score.filter((e) => !s.has(e));
				for (let e of f) r.poemRows[c].cards.push({
					id: e,
					used: !1
				});
				i.push({
					kind: "take",
					data: {
						card: t.card,
						row: c,
						score: o
					}
				}), u || B(r, i, [t.card], "none"), we(r, i, c, f);
			} else c !== void 0 && a.value <= l ? (r.poemRows[c].cards.push({
				id: t.card,
				used: !1
			}), i.push({
				kind: "take",
				data: {
					card: t.card,
					row: c
				}
			}), we(r, i, c, [t.card])) : (i.push({
				kind: "take",
				data: {
					card: t.card,
					row: null
				}
			}), B(r, i, [t.card], "none"));
			let u = P(r.atman);
			return u.length > 1 && (r.pending.push({
				kind: "splitChoice",
				chunks: u.map((e) => e.map((e) => r.atman[e].id))
			}), i.push({
				kind: "splitWarn",
				data: { chunks: u.length }
			})), _e(r, i), {
				state: r,
				fx: i
			};
		}
		case "useRed": {
			if (!Te(r, n.by)) return W("games.sahashri.errNotYourTurn");
			let e = t.targets.length === 2 || t.hi ? "redCut2" : I(r, "redCut1") > 0 ? "redCut1" : "redCut2";
			if (I(r, e) === 0) return W("games.sahashri.errNoAbility");
			let a = new Set(N(r.atman).map((e) => r.atman[e].id));
			if (new Set(t.targets).size !== t.targets.length || !t.targets.every((e) => a.has(e))) return W("games.sahashri.errBadTargets");
			if (L(r, e), r.atman = r.atman.filter((e) => !t.targets.includes(e.id)), i.push({
				kind: "ability",
				data: {
					ability: e,
					targets: t.targets
				}
			}), B(r, i, t.targets, "none"), N(r.atman).length === 0) return R(r, i, "games.sahashri.loseAtman"), {
				state: r,
				fx: i
			};
			let o = P(r.atman);
			return o.length > 1 && r.pending.push({
				kind: "splitChoice",
				chunks: o.map((e) => e.map((e) => r.atman[e].id))
			}), _e(r, i), {
				state: r,
				fx: i
			};
		}
		case "useGoldReturn": {
			if (!Te(r, n.by)) return W("games.sahashri.errNotYourTurn");
			if (I(r, "goldReturn") === 0) return W("games.sahashri.errNoAbility");
			let e = new Set(r.discard);
			return new Set(t.picks).size !== 3 || !t.picks.every((t) => e.has(t)) ? W("games.sahashri.errBadPicks") : (L(r, "goldReturn"), r.discard = r.discard.filter((e) => !t.picks.includes(e)), r.deck.unshift(...t.picks), i.push({
				kind: "ability",
				data: { ability: "goldReturn" }
			}), {
				state: r,
				fx: i
			});
		}
		case "peekStolen": return Te(r, n.by) ? r.ravens[t.color] === "row" ? I(r, "goldRescue") === 0 ? W("games.sahashri.errNoAbility") : (r.pending.push({
			kind: "peekStolen",
			color: t.color,
			by: n.by
		}), i.push({
			kind: "ability",
			data: {
				ability: "peekStolen",
				color: t.color
			}
		}), {
			state: r,
			fx: i
		}) : W("games.sahashri.errBadCard") : W("games.sahashri.errNotYourTurn");
		case "endDream": {
			if (r.phase !== "dreamEnd" || n.by !== r.roles.ren && n.by !== r.roles.feth) return W("games.sahashri.errNotYourTurn");
			let e = r.hearts.filter((e) => e.faceUp && !e.sideways).map((e) => e.id);
			r.score.push(...e), e.length > 0 && i.push({
				kind: "score",
				data: { count: e.length }
			});
			let t = [
				...r.atman.map((e) => e.id),
				...r.poemRows.flatMap((e) => e.cards.map((e) => e.id)),
				...r.hearts.filter((e) => !(e.faceUp && !e.sideways)).map((e) => e.id)
			];
			return r.atman = [], r.poemRows = [
				{ cards: [] },
				{ cards: [] },
				{ cards: [] },
				{ cards: [] }
			], r.hearts = [], B(r, i, t, "dreamEnd"), {
				state: r,
				fx: i
			};
		}
		default: return W("games.sahashri.errPhase");
	}
}
function Ce(e, t) {
	if (t === 0) return !0;
	if (t < 0) return !1;
	let n = 1;
	for (let t of e) n |= n << t;
	return (n >> t & 1) == 1;
}
function we(e, t, n, r) {
	let i = e.hearts[n], a = x.get(i.id);
	!i.sideways && r.some((e) => x.get(e).color === a.color) && (i.faceUp = !0, i.sideways = !0, t.push({
		kind: "heartSideways",
		data: {
			index: n,
			color: a.color
		}
	})), pe(e, n) === w[n] && (t.push({
		kind: "rowComplete",
		data: { row: n }
	}), n === 2 && x.get(e.hearts[3].id).value === 5 && (e.row3Auto = !0, t.push({
		kind: "rowComplete",
		data: { row: 3 }
	})));
}
function Te(e, t) {
	return [
		"draw",
		"place",
		"renTake",
		"dreamEnd"
	].includes(e.phase) ? t === e.roles.ren || t === e.roles.feth : !1;
}
function Ee(e, t) {
	let n = e, r = n.pending[0], i = {
		dream: n.dream,
		phase: n.phase,
		roles: { ...n.roles },
		deckCount: n.deck.length,
		discard: [...n.discard],
		ravens: { ...n.ravens },
		stolenCounts: {
			gold: n.stolen.gold.length,
			red: n.stolen.red.length,
			blue: n.stolen.blue.length,
			green: n.stolen.green.length,
			purple: n.stolen.purple.length
		},
		atman: n.atman.map(({ id: e, x: t, y: n, rot: r }) => ({
			id: e,
			x: t,
			y: n,
			rot: r
		})),
		memoryRow: n.memoryRow.map((e) => ({ ...e })),
		safeN: n.turnSafe + n.veil,
		hearts: n.hearts.map((e) => {
			let t = x.get(e.id);
			return e.faceUp ? {
				color: t.color,
				value: t.value,
				faceUp: !0,
				sideways: e.sideways
			} : {
				color: null,
				value: null,
				faceUp: !1,
				sideways: !1
			};
		}),
		poemRows: n.poemRows.map((e) => ({ cards: e.cards.map((e) => ({ ...e })) })),
		rowsDone: [
			0,
			1,
			2,
			3
		].map((e) => z(n, e)),
		score: [...n.score],
		scoreRavens: n.scoreRavens,
		placedThisTurn: n.placedThisTurn,
		pending: r ? r.kind === "steal" ? {
			kind: "steal",
			groups: r.groups.map((e) => ({
				color: e.color,
				count: e.cards.length
			}))
		} : r.kind === "splitChoice" ? {
			kind: "splitChoice",
			chunks: r.chunks.map((e) => [...e])
		} : r.kind === "heartReveal" ? {
			kind: "heartReveal",
			color: r.color,
			candidates: [...r.candidates]
		} : {
			kind: "peekStolen",
			color: r.color
		} : null,
		loseReason: n.loseReason
	}, a = {};
	return t === n.roles.ren && (a.hearts = n.hearts.map((e) => e.id)), r?.kind === "peekStolen" && r.by === t && (a.peek = [...n.stolen[r.color]]), {
		public: i,
		private: a
	};
}
function De(e) {
	let t = e;
	if (t.phase !== "done" || !t.result) return { phase: t.phase };
	let n = Object.fromEntries(t.players.map((e) => [e, t.result.score]));
	return {
		phase: "done",
		winner: t.result.win ? [...t.players] : [],
		ranking: [...t.players],
		scores: n
	};
}
var Oe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: T,
	schemas: {
		action: re,
		publicView: oe,
		privateView: k,
		config: ie
	},
	setup: xe,
	reduce: Se,
	viewFor: Ee,
	status: De
}, G = {
	gold: "#c9940a",
	red: "#d94545",
	blue: "#3f6fd1",
	green: "#43a35c",
	purple: "#8e5cc7"
};
function ke(e, t) {
	let n = x.get(e).pattern;
	return t ? C(n) : n;
}
function Ae({ id: e, rot: t, px: n }) {
	let r = ke(e, t), i = G[x.get(e).color], a = n / 2;
	return /* @__PURE__ */ f("span", {
		className: "sah-quad inline-grid flex-none overflow-hidden rounded-sm border border-ink/60",
		style: {
			width: n,
			height: n,
			gridTemplateColumns: "1fr 1fr"
		},
		"aria-hidden": !0,
		children: r.map((e, t) => /* @__PURE__ */ f("span", { style: {
			width: a,
			height: a,
			background: i,
			opacity: e ? .35 : 1
		} }, t))
	});
}
function K({ id: e, faceDown: t, used: n, selected: r, dimmed: i, onClick: a, ariaLabel: o }) {
	let s = x.get(e), c = t || !s ? /* @__PURE__ */ f("span", {
		className: "flex h-full w-full items-center justify-center text-lg",
		"aria-hidden": !0,
		children: "🌙"
	}) : /* @__PURE__ */ p("span", {
		className: "sah-chip-face flex h-full w-full flex-col items-center justify-center gap-0.5",
		children: [/* @__PURE__ */ f("span", {
			className: "font-mono text-lg leading-none font-extrabold tabular-nums text-white",
			style: { textShadow: "0 1px 0 rgba(0,0,0,.35)" },
			children: s.value
		}), /* @__PURE__ */ f(Ae, {
			id: e,
			rot: !1,
			px: 18
		})]
	}), l = `sah-chip relative h-12 w-12 flex-none overflow-hidden rounded-xl border-2 border-ink ${a ? "cursor-pointer" : ""} ${n ? "rotate-90" : ""} ${i ? "opacity-50" : ""}`, u = {
		background: t || !s ? "var(--color-ink)" : G[s.color],
		...r ? {
			outline: "3px solid var(--color-info-ink)",
			outlineOffset: 2
		} : {}
	};
	return a ? /* @__PURE__ */ f("button", {
		type: "button",
		"aria-label": o,
		onClick: a,
		className: `${l} min-h-12 min-w-12`,
		style: u,
		children: c
	}) : /* @__PURE__ */ f("span", {
		className: l,
		style: u,
		"aria-label": o,
		children: c
	});
}
function je({ color: e, state: t, stolen: n }) {
	return /* @__PURE__ */ p("span", {
		className: `sah-raven relative flex h-11 w-11 flex-none items-center justify-center rounded-xl border-2 ${t === "row" ? "border-ink" : "border-ink/30"} ${t === "chased" ? "opacity-45" : ""} ${t === "defeated" ? "opacity-30" : ""}`,
		style: { background: t === "deck" ? "transparent" : G[e] },
		"aria-hidden": !0,
		children: [/* @__PURE__ */ f("span", {
			className: `text-lg ${t === "chased" ? "-rotate-90" : ""} ${t === "defeated" ? "grayscale" : ""}`,
			children: t === "defeated" ? "🏵️" : "🐦‍⬛"
		}), t === "row" && n > 0 && /* @__PURE__ */ f("span", {
			className: "absolute -top-1.5 -right-1.5 rounded-md border border-ink bg-surface px-1 font-mono text-[10px] font-extrabold tabular-nums",
			children: n
		})]
	});
}
function q({ id: e, rot: t, ghost: n, highlight: r }) {
	let i = x.get(e), a = ke(e, t), o = G[i.color];
	return /* @__PURE__ */ p("g", {
		opacity: n ? .55 : 1,
		children: [
			/* @__PURE__ */ f("rect", {
				width: 100,
				height: 100,
				rx: 10,
				fill: o,
				className: "stroke-ink",
				strokeWidth: 3,
				strokeDasharray: n ? "8 6" : void 0
			}),
			a.map((e, t) => /* @__PURE__ */ f("rect", {
				x: 18 + t % 2 * 34,
				y: 18 + Math.floor(t / 2) * 34,
				width: 30,
				height: 30,
				rx: 5,
				fill: "#fff",
				opacity: e ? .75 : .18,
				stroke: "rgba(0,0,0,.4)",
				strokeWidth: 1.5
			}, t)),
			/* @__PURE__ */ f("circle", {
				cx: 20,
				cy: 80,
				r: 14,
				fill: "var(--color-surface)",
				className: "stroke-ink",
				strokeWidth: 2.5
			}),
			/* @__PURE__ */ f("text", {
				x: 20,
				y: 86,
				textAnchor: "middle",
				fontSize: 20,
				fontWeight: 800,
				className: "fill-ink font-mono",
				children: i.value
			}),
			r && /* @__PURE__ */ f("rect", {
				x: -4,
				y: -4,
				width: 108,
				height: 108,
				rx: 14,
				fill: "none",
				stroke: r,
				strokeWidth: 5
			})
		]
	});
}
//#endregion
//#region src/games/sahashri/atman-board.tsx
function J(e, t) {
	if (e.length === 0 || t.w === 0) return {
		cx: 0,
		cy: 0,
		s: 1
	};
	let n = e.flatMap((e) => [e.x * 50, e.x * 50 + 100]), r = e.flatMap((e) => [e.y * 50, e.y * 50 + 100]), i = Math.min(...n) - 50, a = Math.max(...n) + 50, o = Math.min(...r) - 50, s = Math.max(...r) + 50, c = Math.min(t.w / (a - i), t.h / (s - o), 3);
	return {
		cx: (i + a) / 2,
		cy: (o + s) / 2,
		s: c
	};
}
function Me({ atman: e, visible: t, legalSpots: o, spotCard: s, chunkOf: c, chunkColors: l, selectedId: u, onTapSpot: d, onTapCard: m }) {
	let h = i(null), [g, _] = a({
		w: 0,
		h: 0
	}), [ee, v] = a(null), y = i({
		cx: 0,
		cy: 0,
		s: 1
	});
	n(() => {
		let e = h.current, t = new ResizeObserver(() => _({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let b = g.w > 0 ? `${g.w}x${g.h}` : "wait", [x, te] = a("");
	x !== b && g.w > 0 && (te(b), v(J(e, g)));
	let S = ee ?? J(e, g);
	n(() => {
		y.current = S;
	}), n(() => {
		let e = h.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = y.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .35), 3), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			y.current = u, v(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let C = i(/* @__PURE__ */ new Map()), ne = i(0), w = i(0), T = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), C.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), C.current.size === 1 && (ne.current = 0), C.current.size === 2) {
			let [e, t] = [...C.current.values()];
			w.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, E = (e) => {
		let t = C.current.get(e.pointerId);
		if (!t) return;
		let n = h.current.getBoundingClientRect();
		if (C.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			ne.current += Math.abs(n) + Math.abs(r);
			let i = y.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			y.current = a, v(a);
		} else if (C.current.size === 2) {
			C.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...C.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (w.current > 0 && i > 0) {
				let e = y.current, a = Math.min(Math.max(e.s * i / w.current, .35), 3), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				y.current = u, v(u);
			}
			w.current = i, ne.current = 99;
			return;
		}
		C.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, D = (t) => {
		let n = C.current.size === 1 && ne.current < 10;
		if (C.current.delete(t.pointerId), w.current = 0, !n) return;
		let r = h.current.getBoundingClientRect(), i = y.current, a = i.cx + (t.clientX - r.left - r.width / 2) / i.s, s = i.cy + (t.clientY - r.top - r.height / 2) / i.s;
		if (o && o.length > 0 && d) {
			let e = null, t = 80;
			for (let n of o) {
				let r = Math.hypot(n.x * 50 + 50 - a, n.y * 50 + 50 - s);
				r < t && (t = r, e = n);
			}
			e && d(e);
			return;
		}
		if (m) for (let t = e.length - 1; t >= 0; --t) {
			let n = e[t];
			if (a >= n.x * 50 && a <= n.x * 50 + 100 && s >= n.y * 50 && s <= n.y * 50 + 100) {
				m(n.id);
				return;
			}
		}
	}, re = r(() => e, [e]);
	return /* @__PURE__ */ f("div", {
		ref: h,
		className: "relative h-full w-full overflow-hidden",
		children: /* @__PURE__ */ f("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: T,
			onPointerMove: E,
			onPointerUp: D,
			onPointerCancel: D,
			children: /* @__PURE__ */ p("g", {
				transform: `translate(${g.w / 2 - S.cx * S.s}, ${g.h / 2 - S.cy * S.s}) scale(${S.s})`,
				children: [o?.map((e) => /* @__PURE__ */ f("g", {
					transform: `translate(${e.x * 50}, ${e.y * 50})`,
					children: s ? /* @__PURE__ */ f(q, {
						id: s,
						rot: e.rot,
						ghost: !0
					}) : /* @__PURE__ */ f("rect", {
						width: 100,
						height: 100,
						rx: 10,
						fill: "var(--color-done-soft)",
						fillOpacity: .5,
						className: "stroke-done-ink",
						strokeWidth: 3,
						strokeDasharray: "9 7"
					})
				}, `${e.x},${e.y},${+!!e.rot}`)), re.map((e) => {
					let n = c?.get(e.id);
					return /* @__PURE__ */ f("g", {
						transform: `translate(${e.x * 50}, ${e.y * 50})`,
						children: /* @__PURE__ */ f(q, {
							id: e.id,
							rot: e.rot,
							ghost: !t.has(e.id),
							highlight: n !== void 0 && l ? l[n % l.length] : e.id === u ? "var(--color-info-ink)" : void 0
						})
					}, `${e.id}-${e.x}-${e.y}`);
				})]
			})
		})
	});
}
//#endregion
//#region src/games/sahashri/view-player.tsx
var Ne = {
	goldReturn: "abGoldReturn",
	goldRescue: "abGoldRescue",
	redCut1: "abRedCut1",
	redCut2: "abRedCut2",
	blueShift: "abBlueShift",
	blueEcho: "abBlueEcho",
	greenSpin: "abGreenSpin",
	greenWild: "abGreenWild",
	purpleVeil: "abPurpleVeil",
	purpleBlock: "abPurpleBlock"
}, Pe = {
	gold: "colorGold",
	red: "colorRed",
	blue: "colorBlue",
	green: "colorGreen",
	purple: "colorPurple"
}, Fe = [
	"#e05252",
	"#3f6fd1",
	"#43a35c",
	"#c9940a",
	"#8e5cc7",
	"#0ea5e9"
];
function Ie(e, t) {
	if (t === 0) return !0;
	if (t < 0) return !1;
	let n = 1;
	for (let t of e) n |= n << t;
	return (n >> t & 1) == 1;
}
function Le(e, t) {
	return N(e).filter((n) => {
		let r = e[n];
		return Math.abs(r.x - t.x) <= 1 && Math.abs(r.y - t.y) <= 1;
	}).map((t) => e[t].id);
}
function Y(e) {
	let t = e.public, n = e.private, { members: i, myRid: m, send: h } = e, g = s(), ee = (e) => i.find((t) => t.rid === e)?.name ?? e, v = t.roles.ren === m, y = t.roles.feth === m, b = t.pending, [te, S] = a(null), [C, E] = a(null), [D, re] = a(null), [ie, ae] = a(!1), [O, oe] = a(!1), [k, A] = a(0), [se, ce] = a(!1), [j, M] = a(null), [P, le] = a(null), [F, I] = a([]), [L, de] = a(null), [R, fe] = a(null), pe = `${t.phase}|${t.dream}|${b?.kind ?? ""}|${t.memoryRow.map((e) => e.id).join(".")}|${t.atman.length}|${t.placedThisTurn}`, [z, me] = a(pe);
	z !== pe && (me(pe), re(null), ae(!1), oe(!1), A(0), ce(!1), M(null), le(null), I([]), de(null), fe(null));
	let B = r(() => {
		let e = /* @__PURE__ */ new Map();
		for (let n of t.poemRows) for (let t of n.cards) {
			if (t.used) continue;
			let n = x.get(t.id)?.ability;
			n && e.set(n, (e.get(n) ?? 0) + 1);
		}
		return e;
	}, [t.poemRows]), he = r(() => new Set(N(t.atman).map((e) => t.atman[e].id)), [t.atman]), ge = r(() => [...B.keys()].filter((e) => !v || ne.has(e)), [B, v]), V = t.rowsDone.findIndex((e) => !e), _e = (e) => {
		let r = n?.hearts?.[e];
		if (r) return x.get(r);
		let i = t.hearts[e];
		return i?.color !== null && i?.value != null ? {
			color: i.color,
			value: i.value
		} : null;
	}, ve = (e) => {
		let n = _e(e);
		return (n ? n.value : 0) + t.poemRows[e].cards.reduce((e, t) => e + (x.get(t.id)?.value ?? 0), 0);
	}, H = V >= 0 ? w[V] - ve(V) : 0, U = P ? x.get(P) : void 0, ye = t.score.filter((e) => x.has(e)), be = F.reduce((e, t) => e + (x.get(t)?.value ?? 0), 0), xe = ye.map((e) => x.get(e).value), W = U?.value ?? 0, Se = W <= H && Ie(xe, H - W), Ce = P !== null && W + be === H || P !== null && !Se && be === H, we = Se || Ie(xe, H), Te = U !== void 0 && V >= 0 && U.value <= H, Ee = y && t.phase === "place" && !b, De = Ee && D ? ue(t.atman, D, {
		rot: ie,
		wild: O
	}) : void 0, Oe = r(() => {
		if (b?.kind !== "splitChoice") return null;
		let e = /* @__PURE__ */ new Map();
		return b.chunks.forEach((t, n) => t.forEach((t) => e.set(t, n))), e;
	}, [b]), ke = (e) => {
		if (D) {
			if (se && (B.get("blueEcho") ?? 0) > 0) {
				let n = Le(t.atman, e);
				if (n.length > 1) {
					M({
						spot: e,
						candidates: n
					});
					return;
				}
				h({
					type: "placeCard",
					card: D,
					x: e.x,
					y: e.y,
					rot: e.rot,
					shift: k,
					echo: n[0] ?? null,
					wild: O
				});
			} else h({
				type: "placeCard",
				card: D,
				x: e.x,
				y: e.y,
				rot: e.rot,
				shift: k,
				echo: null,
				wild: O
			});
			re(null);
		}
	}, Ae = (e) => {
		if (b?.kind === "splitChoice" && v) {
			let t = Oe?.get(e);
			t !== void 0 && h({
				type: "chooseChunk",
				keep: t
			});
			return;
		}
		if (L !== null) {
			if (!he.has(e)) return;
			de(L.includes(e) ? L.filter((t) => t !== e) : L.length >= 2 ? L : [...L, e]);
			return;
		}
		v && t.phase === "renTake" && !b && he.has(e) && le(P === e ? null : e);
	}, q = "info", J = "", Y = "", X = ee(t.roles.ren), Z = ee(t.roles.feth);
	b ? (q = "warn", b.kind === "heartReveal" ? (J = g("games.sahashri.pendingHeart", { color: g(`games.sahashri.${Pe[b.color]}`) }), v || (Y = g("games.sahashri.waitOther", { name: X }))) : b.kind === "splitChoice" ? (J = g("games.sahashri.pendingSplit"), v || (Y = g("games.sahashri.waitOther", { name: X }))) : b.kind === "steal" ? (J = g("games.sahashri.pendingSteal"), y || (Y = g("games.sahashri.waitOther", { name: Z }))) : J = g("games.sahashri.pendingPeek")) : t.phase === "arrange" ? (q = v ? "accent" : "info", J = g("games.sahashri.phaseArrange"), v || (Y = g("games.sahashri.waitOther", { name: X }))) : t.phase === "draw" ? (q = y ? "accent" : "info", J = g("games.sahashri.phaseDraw"), Y = y ? g("games.sahashri.safeArea", { n: t.safeN }) : g("games.sahashri.waitOther", { name: Z })) : t.phase === "place" ? (q = y ? "accent" : "info", J = g("games.sahashri.phasePlace"), Y = y ? g("games.sahashri.placeHint") : g("games.sahashri.waitOther", { name: Z })) : t.phase === "renTake" ? (q = v ? "accent" : "info", J = g("games.sahashri.phaseRenTake"), Y = v ? g(t.dream === 3 ? "games.sahashri.takeHintDream3" : "games.sahashri.takeHint") : g("games.sahashri.waitOther", { name: X })) : t.phase === "dreamEnd" && (q = "done", J = g("games.sahashri.phaseDreamEnd"));
	let Q = null;
	if (b?.kind === "heartReveal" && v) Q = /* @__PURE__ */ f("div", {
		className: "flex flex-wrap gap-2",
		children: b.candidates.map((e) => {
			let t = n?.hearts?.[e], r = t ? x.get(t) : void 0;
			return /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => h({
					type: "revealHeart",
					index: e
				}),
				className: "card flex min-h-12 cursor-pointer items-center gap-2 px-3",
				children: [/* @__PURE__ */ f("span", {
					className: "font-mono text-lg font-extrabold tabular-nums",
					children: r ? `${g(`games.sahashri.${Pe[r.color]}`)} ${r.value}` : "?"
				}), /* @__PURE__ */ f("span", {
					className: "text-xs font-bold opacity-70",
					children: g("games.sahashri.rowTarget", { n: w[e] })
				})]
			}, e);
		})
	});
	else if (b?.kind === "steal" && y) Q = /* @__PURE__ */ p("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [b.groups.map((e) => /* @__PURE__ */ p("button", {
			type: "button",
			onClick: () => h({
				type: "stealBlock",
				color: e.color
			}),
			className: "card flex min-h-12 cursor-pointer items-center gap-2 px-3 text-sm font-extrabold",
			style: { borderColor: G[e.color] },
			children: [
				"🐦‍⬛ ",
				g(`games.sahashri.${Pe[e.color]}`),
				" ×",
				e.count
			]
		}, e.color)), /* @__PURE__ */ f("button", {
			type: "button",
			onClick: () => h({ type: "stealPass" }),
			className: "btn-quiet min-h-12 cursor-pointer",
			children: g("games.sahashri.stealPass")
		})]
	});
	else if (b?.kind === "peekStolen" && n?.peek) Q = /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ p("div", {
			className: "flex flex-wrap gap-2",
			children: [n.peek.map((e) => /* @__PURE__ */ f(K, {
				id: e,
				onClick: () => h({
					type: "goldRescue",
					card: e
				}),
				ariaLabel: e
			}, e)), n.peek.length === 0 && /* @__PURE__ */ f("span", {
				className: "text-sm font-bold opacity-60",
				children: "—"
			})]
		}), /* @__PURE__ */ f("button", {
			type: "button",
			onClick: () => h({ type: "cancelPeek" }),
			className: "btn-quiet min-h-11 cursor-pointer",
			children: g("games.sahashri.peekCancel")
		})]
	});
	else if (t.phase === "arrange" && !b && v && n?.hearts) {
		let e = te ?? n.hearts;
		Q = /* @__PURE__ */ p("div", {
			className: "flex flex-col gap-2",
			children: [
				/* @__PURE__ */ f("p", {
					className: "text-xs font-bold opacity-70",
					children: g("games.sahashri.arrangeHint")
				}),
				/* @__PURE__ */ f("div", {
					className: "flex gap-2",
					children: e.map((t, n) => /* @__PURE__ */ p("button", {
						type: "button",
						"aria-label": t,
						onClick: () => {
							if (C === null) S(e), E(n);
							else {
								let t = [...e];
								[t[C], t[n]] = [t[n], t[C]], S(t), E(null);
							}
						},
						className: `flex flex-col items-center gap-1 rounded-xl p-1 ${C === n ? "bg-info-soft" : ""}`,
						children: [/* @__PURE__ */ f(K, { id: t }), /* @__PURE__ */ f("span", {
							className: "font-mono text-[10px] font-bold tabular-nums opacity-70",
							children: w[n]
						})]
					}, t))
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => {
						h({
							type: "arrangeHearts",
							order: e
						}), S(null), E(null);
					},
					className: "btn-base min-h-12 cursor-pointer text-white",
					style: { background: T.accent },
					children: g("games.sahashri.arrangeConfirm")
				})
			]
		});
	} else if (t.phase === "draw" && !b && y) Q = /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [(B.get("purpleVeil") ?? 0) > 0 && /* @__PURE__ */ p("button", {
			type: "button",
			onClick: () => h({ type: "useVeil" }),
			className: "btn-quiet min-h-11 cursor-pointer",
			children: [
				"🔮 ",
				g("games.sahashri.abPurpleVeil"),
				"(",
				g("games.sahashri.safeArea", { n: t.safeN + 2 }),
				")"
			]
		}), /* @__PURE__ */ p("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ f("button", {
				type: "button",
				onClick: () => h({ type: "draw" }),
				disabled: t.deckCount === 0,
				className: "btn-base min-h-12 flex-1 cursor-pointer text-white disabled:opacity-40",
				style: { background: T.accent },
				children: g("games.sahashri.drawBtn")
			}), /* @__PURE__ */ f("button", {
				type: "button",
				onClick: () => h({ type: "finishDraw" }),
				className: "btn-base min-h-12 flex-1 cursor-pointer",
				children: g("games.sahashri.finishDrawBtn")
			})]
		})]
	});
	else if (Ee) {
		let e = B.get("blueShift") ?? 0;
		Q = /* @__PURE__ */ p("div", {
			className: "flex flex-col gap-2",
			children: [
				D && /* @__PURE__ */ p("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						(B.get("greenSpin") ?? 0) > 0 && /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => ae(!ie),
							className: `card min-h-11 cursor-pointer px-3 text-xs font-extrabold ${ie ? "bg-info-soft" : ""}`,
							children: ["↻ ", g("games.sahashri.modRot")]
						}),
						(B.get("greenWild") ?? 0) > 0 && /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => oe(!O),
							className: `card min-h-11 cursor-pointer px-3 text-xs font-extrabold ${O ? "bg-info-soft" : ""}`,
							children: ["✦ ", g("games.sahashri.modWild")]
						}),
						e > 0 && /* @__PURE__ */ p("span", {
							className: "card flex min-h-11 items-center gap-1 px-2",
							children: [
								/* @__PURE__ */ f("button", {
									type: "button",
									"aria-label": "−",
									onClick: () => A(Math.max(-e, k - 1)),
									className: "min-h-9 min-w-9 cursor-pointer font-mono text-lg font-extrabold",
									children: "−"
								}),
								/* @__PURE__ */ f("span", {
									className: "font-mono text-sm font-extrabold tabular-nums",
									children: g("games.sahashri.modShift", { n: k })
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									"aria-label": "+",
									onClick: () => A(Math.min(e, k + 1)),
									className: "min-h-9 min-w-9 cursor-pointer font-mono text-lg font-extrabold",
									children: "+"
								})
							]
						}),
						(B.get("blueEcho") ?? 0) > 0 && /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => ce(!se),
							className: `card min-h-11 cursor-pointer px-3 text-xs font-extrabold ${se ? "bg-info-soft" : ""}`,
							children: ["⌁ ", g("games.sahashri.modEcho")]
						})
					]
				}),
				/* @__PURE__ */ f(o, {
					label: g("games.sahashri.finishPlaceBtn"),
					confirmLabel: t.placedThisTurn === 0 ? g("games.sahashri.declareLossConfirm") : g("games.sahashri.finishPlaceBtn"),
					onConfirm: () => h({ type: "finishPlace" }),
					ariaLabel: g("games.sahashri.finishPlaceBtn")
				}),
				t.placedThisTurn === 0 && /* @__PURE__ */ f("p", {
					className: "text-xs font-bold text-warn-ink",
					children: g("games.sahashri.loseNoPlace")
				})
			]
		});
	} else t.phase === "renTake" && v && !b ? Q = /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [P && t.dream === 3 && V >= 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("p", {
			className: "text-xs font-bold opacity-70",
			children: g("games.sahashri.scorePickHint", { n: H })
		}), /* @__PURE__ */ f("div", {
			className: "flex flex-wrap gap-2",
			children: ye.map((e) => /* @__PURE__ */ f(K, {
				id: e,
				selected: F.includes(e),
				onClick: () => I(F.includes(e) ? F.filter((t) => t !== e) : [...F, e]),
				ariaLabel: e
			}, e))
		})] }), P && t.dream === 3 && !we ? /* @__PURE__ */ f(o, {
			label: g("games.sahashri.declareLoss"),
			confirmLabel: g("games.sahashri.declareLossConfirm"),
			onConfirm: () => h({
				type: "takeCard",
				card: P,
				scoreCards: []
			})
		}) : /* @__PURE__ */ p("button", {
			type: "button",
			disabled: !P || t.dream === 3 && !Ce,
			onClick: () => {
				h({
					type: "takeCard",
					card: P,
					scoreCards: t.dream === 3 ? F : []
				}), le(null), I([]);
			},
			className: "btn-base min-h-12 cursor-pointer text-white disabled:opacity-40",
			style: { background: T.accent },
			children: [
				g("games.sahashri.confirmTake"),
				U ? ` (${U.value})` : "",
				t.dream !== 3 && U ? Te ? " →" : " ✕" : ""
			]
		})]
	}) : t.phase === "dreamEnd" && !b && (Q = /* @__PURE__ */ f("button", {
		type: "button",
		onClick: () => h({ type: "endDream" }),
		className: "btn-base min-h-12 w-full cursor-pointer text-white",
		style: { background: T.accent },
		children: g("games.sahashri.endDreamBtn")
	}));
	let Re = !b && [
		"draw",
		"place",
		"renTake",
		"dreamEnd"
	].includes(t.phase) && ge.some((e) => ne.has(e)) ? /* @__PURE__ */ p("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [
			/* @__PURE__ */ f("span", {
				className: "section-label",
				children: g("games.sahashri.abilitiesTitle")
			}),
			(B.get("redCut1") ?? 0) + (B.get("redCut2") ?? 0) > 0 && /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => de(L === null ? [] : null),
				className: `card min-h-11 cursor-pointer px-3 text-xs font-extrabold ${L === null ? "" : "bg-info-soft"}`,
				children: [
					"✂ ",
					g("games.sahashri.abRedCut1"),
					L === null ? "" : ` ${L.length}/2`
				]
			}),
			(B.get("goldReturn") ?? 0) > 0 && /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => fe(R === null ? [] : null),
				className: `card min-h-11 cursor-pointer px-3 text-xs font-extrabold ${R === null ? "" : "bg-info-soft"}`,
				children: ["↩ ", g("games.sahashri.abGoldReturn")]
			}),
			(B.get("goldRescue") ?? 0) > 0 && /* @__PURE__ */ f("div", {
				className: "flex gap-1",
				children: _.filter((e) => t.ravens[e] === "row" && t.stolenCounts[e] > 0).map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => h({
						type: "peekStolen",
						color: e
					}),
					className: "card min-h-11 cursor-pointer px-2 text-xs font-extrabold",
					style: { borderColor: G[e] },
					children: ["⚑ ", g(`games.sahashri.${Pe[e]}`)]
				}, e))
			})
		]
	}) : null, $ = null;
	L === null ? R === null ? j && ($ = /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ f("p", {
			className: "text-xs font-bold opacity-70",
			children: g("games.sahashri.modEcho")
		}), /* @__PURE__ */ f("div", {
			className: "flex flex-wrap gap-2",
			children: j.candidates.map((e) => /* @__PURE__ */ f(K, {
				id: e,
				onClick: () => {
					D && h({
						type: "placeCard",
						card: D,
						x: j.spot.x,
						y: j.spot.y,
						rot: j.spot.rot,
						shift: k,
						echo: e,
						wild: O
					}), M(null), re(null);
				},
				ariaLabel: e
			}, e))
		})]
	})) : $ = /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ f("div", {
			className: "flex flex-wrap gap-1.5",
			children: t.discard.map((e, t) => x.has(e) ? /* @__PURE__ */ f(K, {
				id: e,
				selected: R.includes(e),
				onClick: () => fe(R.includes(e) ? R.filter((t) => t !== e) : R.length >= 3 ? R : [...R, e]),
				ariaLabel: e
			}, `${e}-${t}`) : null)
		}), /* @__PURE__ */ p("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ p("button", {
				type: "button",
				disabled: R.length !== 3,
				onClick: () => {
					h({
						type: "useGoldReturn",
						picks: R
					}), fe(null);
				},
				className: "btn-base min-h-11 flex-1 cursor-pointer text-white disabled:opacity-40",
				style: { background: T.accent },
				children: [
					"↩ ",
					R.length,
					"/3"
				]
			}), /* @__PURE__ */ f("button", {
				type: "button",
				onClick: () => fe(null),
				className: "btn-quiet min-h-11 cursor-pointer",
				children: g("games.sahashri.peekCancel")
			})]
		})]
	}) : $ = /* @__PURE__ */ p("div", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ p("button", {
			type: "button",
			disabled: L.length === 0,
			onClick: () => {
				h({
					type: "useRed",
					targets: L,
					hi: L.length === 2
				}), de(null);
			},
			className: "btn-base min-h-11 flex-1 cursor-pointer text-white disabled:opacity-40",
			style: { background: T.accent },
			children: [
				g("games.sahashri.abRedCut1"),
				" ×",
				L.length
			]
		}), /* @__PURE__ */ f("button", {
			type: "button",
			onClick: () => de(null),
			className: "btn-quiet min-h-11 cursor-pointer",
			children: g("games.sahashri.peekCancel")
		})]
	});
	let ze = b ? b.kind === "steal" ? t.roles.feth : b.kind === "peekStolen" ? null : t.roles.ren : t.phase === "renTake" || t.phase === "arrange" ? t.roles.ren : t.roles.feth;
	return /* @__PURE__ */ f(u, {
		adaptive: !0,
		scroll: !1,
		className: "sah-screen",
		banner: /* @__PURE__ */ p("div", {
			className: "sah-banner",
			children: [/* @__PURE__ */ f(c, {
				tone: q,
				text: J,
				sub: Y,
				chip: g("games.sahashri.dreamN", { n: t.dream }),
				accent: T.accent
			}), /* @__PURE__ */ f("div", {
				className: "sah-players",
				children: /* @__PURE__ */ f(l, {
					variant: "plate",
					members: i,
					myRid: m,
					action: (e) => t.phase !== "done" && e === ze ? "pending" : null,
					status: (e) => e === t.roles.ren || e === t.roles.feth ? /* @__PURE__ */ f("span", {
						className: "text-xs font-bold opacity-80",
						children: g(e === t.roles.ren ? "games.sahashri.roleRen" : "games.sahashri.roleFeth")
					}) : null
				})
			})]
		}),
		children: /* @__PURE__ */ p("div", {
			className: "sah-table",
			children: [/* @__PURE__ */ f("div", {
				className: "sah-board frame min-h-0 overflow-hidden",
				children: /* @__PURE__ */ f(Me, {
					atman: t.atman,
					visible: he,
					legalSpots: De,
					spotCard: D,
					chunkOf: Oe,
					chunkColors: Fe,
					selectedId: P,
					onTapSpot: Ee && D ? ke : void 0,
					onTapCard: Ae
				})
			}), /* @__PURE__ */ p("div", {
				className: "sah-console",
				children: [
					/* @__PURE__ */ p("div", {
						className: "sah-status",
						children: [/* @__PURE__ */ f("div", {
							className: "sah-ravens",
							children: _.map((e) => /* @__PURE__ */ f(je, {
								color: e,
								state: t.ravens[e],
								stolen: t.stolenCounts[e]
							}, e))
						}), /* @__PURE__ */ p("div", {
							className: "sah-counts font-mono font-bold tabular-nums opacity-70",
							children: [
								/* @__PURE__ */ f("span", { children: g("games.sahashri.deckN", { n: t.deckCount }) }),
								/* @__PURE__ */ f("span", { children: g("games.sahashri.discardN", { n: t.discard.length }) }),
								/* @__PURE__ */ f("span", { children: g("games.sahashri.scoreN", { n: t.score.length }) })
							]
						})]
					}),
					/* @__PURE__ */ f("div", {
						className: "sah-poems",
						children: [
							0,
							1,
							2,
							3
						].map((e) => {
							let r = n?.hearts?.[e], i = t.hearts[e], a = t.rowsDone[e];
							return /* @__PURE__ */ p("div", {
								className: `sah-poem frame flex min-h-14 items-center gap-1 p-1 ${e === V && !a ? "border-info-ink" : ""} ${a ? "bg-done-soft" : ""}`,
								children: [r ? /* @__PURE__ */ f(K, {
									id: r,
									used: i?.sideways
								}) : i ? i.faceUp && i.color ? /* @__PURE__ */ f("span", {
									className: `sah-chip relative flex h-12 w-12 flex-none items-center justify-center rounded-xl border-2 border-ink ${i.sideways ? "rotate-90" : ""}`,
									style: { background: G[i.color] },
									children: /* @__PURE__ */ f("span", {
										className: "font-mono text-lg font-extrabold tabular-nums text-white",
										children: i.value
									})
								}) : /* @__PURE__ */ f("span", {
									className: "sah-chip flex h-12 w-12 flex-none items-center justify-center rounded-xl border-2 border-ink bg-ink text-lg",
									"aria-label": g("games.sahashri.heartHidden"),
									children: "🌙"
								}) : null, /* @__PURE__ */ p("div", {
									className: "sah-poem-body flex min-w-0 flex-1 flex-col",
									children: [/* @__PURE__ */ p("span", {
										className: "sah-poem-progress font-mono text-xs font-extrabold tabular-nums",
										children: [
											a ? "✓ " : "",
											t.hearts[e]?.faceUp || r ? ve(e) : "?",
											/* @__PURE__ */ p("span", {
												className: "opacity-60",
												children: ["/", w[e]]
											})
										]
									}), /* @__PURE__ */ f("div", {
										className: "sah-poem-cards flex gap-0.5",
										children: t.poemRows[e]?.cards.map((e) => {
											let t = x.get(e.id);
											return t ? /* @__PURE__ */ f("span", {
												className: `sah-poem-card flex h-5 w-5 items-center justify-center rounded border border-ink/60 font-mono text-[10px] font-extrabold text-white ${e.used ? "rotate-90 opacity-60" : ""}`,
												style: { background: G[t.color] },
												title: g(`games.sahashri.${Ne[t.ability]}`),
												children: t.value
											}, e.id) : null;
										})
									})]
								})]
							}, e);
						})
					}),
					/* @__PURE__ */ f("div", {
						className: "sah-memory",
						children: t.memoryRow.length > 0 && /* @__PURE__ */ p("div", {
							className: "sah-memory-row",
							children: [/* @__PURE__ */ f("span", {
								className: "section-label flex-none",
								children: g("games.sahashri.memoryRow")
							}), t.memoryRow.map((e) => x.has(e.id) ? /* @__PURE__ */ f(K, {
								id: e.id,
								selected: D === e.id,
								dimmed: !e.safe,
								onClick: Ee ? () => re(D === e.id ? null : e.id) : void 0,
								ariaLabel: e.id
							}, e.id) : /* @__PURE__ */ f("span", {
								className: "sah-chip flex h-12 w-12 flex-none items-center justify-center rounded-xl border-2 border-ink bg-ink text-lg",
								"aria-hidden": !0,
								children: "🐦‍⬛"
							}, e.id))]
						})
					}),
					/* @__PURE__ */ p("div", {
						className: "sah-controls",
						children: [
							Re,
							$,
							Q
						]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/games/sahashri/bot.ts
var X = (e) => x.get(e).value, Z = (e) => x.get(e).color;
function Q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Re(e) {
	let t = [...e], n = crypto.getRandomValues(new Uint32Array(t.length));
	for (let e = t.length - 1; e > 0; --e) {
		let r = n[e] % (e + 1);
		[t[e], t[r]] = [t[r], t[e]];
	}
	return t;
}
function $(e, t) {
	return e.poemRows.flatMap((e) => e.cards).filter((e) => !e.used && x.get(e.id).ability === t).length;
}
function ze(e, t) {
	if (t === 0) return [];
	let n = e.filter((e) => x.has(e)), r = Array(t + 1).fill(null), i = Array(t + 1).fill(!1);
	i[0] = !0;
	for (let e of n) {
		let n = X(e);
		for (let a = t; a >= n; --a) !i[a] && i[a - n] && (i[a] = !0, r[a] = {
			id: e,
			from: a - n
		});
	}
	if (!i[t]) return null;
	let a = [];
	for (let e = t; e > 0; e = r[e].from) a.push(r[e].id);
	return a;
}
function Be(e, t) {
	if (t) return {
		type: "arrangeHearts",
		order: Re(e)
	};
	let n = e.find((e) => X(e) === 5), r = e.filter((e) => e !== n).sort((e, t) => X(t) - X(e));
	return {
		type: "arrangeHearts",
		order: n ? [...r, n] : r
	};
}
function Ve(e, t) {
	let n = e.memoryRow, r = n.filter((e) => !S(e.id)), i = n.length - r.length, a = _.filter((t) => e.ravens[t] === "row").length, o = $(e, "greenSpin") > 0, s = $(e, "greenWild") > 0, c = r.some((t) => ue(e.atman, t.id, {
		rot: o,
		wild: !1
	}).length > 0) || s && r.some((t) => ue(e.atman, t.id, {
		rot: o,
		wild: !0
	}).length > 0), l = n.length < e.safeN, u = !l && a + i >= 4;
	return e.deckCount === 0 ? { type: "finishDraw" } : n.length === 0 ? { type: "draw" } : u ? { type: "finishDraw" } : t ? r.length >= 2 || r.length >= 1 && c ? { type: "finishDraw" } : { type: "draw" } : c ? r.length >= 2 || !l ? { type: "finishDraw" } : { type: "draw" } : !l && $(e, "purpleVeil") > 0 ? { type: "useVeil" } : n.length >= 6 ? { type: "finishDraw" } : { type: "draw" };
}
function He(e, t, n) {
	return e.filter((r, i) => M(e, i) && r.x <= t + 1 && r.x + 1 >= t && r.y <= n + 1 && r.y + 1 >= n).map((e) => e.id);
}
function Ue(e, t, n) {
	let r = N(e.atman).length, i = e.hearts.some((e) => !e.faceUp), a = $(e, "blueShift"), o = $(e, "blueEcho"), s = $(e, "greenWild"), c = null;
	for (let l of t) {
		let t = x.get(l.id);
		for (let u of [!1, !0]) if (!(u && s === 0)) for (let s of ue(e.atman, l.id, {
			rot: n,
			wild: u
		})) {
			let n = [...e.atman, {
				id: l.id,
				x: s.x,
				y: s.y,
				rot: s.rot
			}], d = 30 + (N(n).length - r) * 20;
			P(n).length > 1 && (d -= 1e3);
			let f = e.ravens[t.color] === "row";
			f && !u && (d += l.safe ? -40 : 30);
			let p = null;
			for (let e of [
				0,
				-1,
				1
			]) {
				if (e !== 0 && a === 0) continue;
				let r = Math.min(5, Math.max(1, t.value + e));
				if (ve(n, n.length - 1, null, r)) {
					p = {
						shift: e,
						echo: null
					};
					break;
				}
			}
			if (!p && o > 0) {
				for (let r of He(e.atman, s.x, s.y)) if (ve(n, n.length - 1, r, t.value)) {
					p = {
						shift: 0,
						echo: r
					};
					break;
				}
			}
			p && (d += 200, f && (d += 150), i && (d += 50));
			let m = {
				card: l.id,
				x: s.x,
				y: s.y,
				rot: s.rot,
				shift: p?.shift ?? 0,
				echo: p?.echo ?? null,
				wild: u,
				score: d
			};
			(!c || m.score > c.score) && (c = m);
		}
	}
	return c;
}
function We(e, t) {
	let n = e.memoryRow.filter((e) => !S(e.id));
	if (n.length === 0) return { type: "finishPlace" };
	if (t) {
		for (let t of n) {
			let n = ue(e.atman, t.id, {
				rot: !1,
				wild: !1
			})[0];
			if (n) return {
				type: "placeCard",
				card: t.id,
				x: n.x,
				y: n.y,
				rot: n.rot,
				shift: 0,
				echo: null,
				wild: !1
			};
		}
		return { type: "finishPlace" };
	}
	let r = Ue(e, n, $(e, "greenSpin") > 0);
	return !r || e.placedThisTurn > 0 && r.score <= 0 ? { type: "finishPlace" } : {
		type: "placeCard",
		card: r.card,
		x: r.x,
		y: r.y,
		rot: r.rot,
		shift: r.shift,
		echo: r.echo,
		wild: r.wild
	};
}
function Ge(e, t, n) {
	let r = N(e.atman).map((t) => e.atman[t]);
	if (r.length === 0) return null;
	let i = new Set(t.map(Z)), a = (t) => t.map((t) => {
		let n = P(e.atman.filter((e) => e.id !== t.id)).length > 1, r = e.ravens[Z(t.id)] === "row";
		return {
			p: t,
			key: (n ? -50 : 0) + (r ? -10 : 0) - X(t.id)
		};
	}).sort((e, t) => t.key - e.key)[0].p;
	if (e.rowsDone.every(Boolean)) {
		let e = r.filter((e) => !i.has(Z(e.id)));
		return {
			type: "takeCard",
			card: (n ? e[0] ?? r[0] : a(e.length > 0 ? e : r)).id,
			scoreCards: []
		};
	}
	let o = e.rowsDone.findIndex((e) => !e), s = w[o] - (X(t[o]) + e.poemRows[o].cards.reduce((e, t) => e + X(t.id), 0));
	if (e.dream === 3) {
		for (let t of [...r].sort((e, t) => X(t.id) - X(e.id))) {
			let n = X(t.id);
			if (n > s) continue;
			let r = ze(e.score, s - n);
			if (r) return {
				type: "takeCard",
				card: t.id,
				scoreCards: r
			};
		}
		let t = ze(e.score, s);
		if (t) {
			let n = r.find((t) => X(t.id) > s || !ze(e.score, s - X(t.id)));
			if (n) return {
				type: "takeCard",
				card: n.id,
				scoreCards: t
			};
		}
		return {
			type: "takeCard",
			card: [...r].sort((e, t) => X(e.id) - X(t.id))[0].id,
			scoreCards: []
		};
	}
	let c = r.filter((e) => X(e.id) <= s);
	if (n) return {
		type: "takeCard",
		card: (c[0] ?? r[0]).id,
		scoreCards: []
	};
	if (c.length === 0) return {
		type: "takeCard",
		card: a(r).id,
		scoreCards: []
	};
	let l = Z(t[o]);
	return {
		type: "takeCard",
		card: c.map((t) => {
			let n = e.atman.filter((e) => e.id !== t.id), r = X(t.id);
			return {
				p: t,
				key: (r === s ? 100 : 0) + (P(n).length > 1 ? -50 : 0) + (Z(t.id) === l ? -20 : 0) + r
			};
		}).sort((e, t) => t.key - e.key)[0].p.id,
		scoreCards: []
	};
}
function Ke(e, t) {
	let n = e.rowsDone.filter((e) => !e).length;
	if (n > 1) return null;
	let r = N(e.atman).map((t) => e.atman[t]), i = new Set(t.map(Z)), a = r.filter((e) => !i.has(Z(e.id))).map((e) => e.id);
	return a.length === 0 || n === 0 && a.length < 2 || r.length <= Math.min(a.length, 2) ? null : a.length >= 2 && $(e, "redCut2") > 0 ? {
		type: "useRed",
		targets: a.slice(0, 2),
		hi: !1
	} : $(e, "redCut1") > 0 || $(e, "redCut2") > 0 ? {
		type: "useRed",
		targets: [a[0]],
		hi: !1
	} : null;
}
function qe(e, t, n) {
	if (n) return Q(t);
	let r = t[0], i = -Infinity;
	for (let n of t) {
		let t = e.poemRows[n].cards.filter((e) => e.used).length * 10 + (e.rowsDone[n] ? 0 : 5);
		t > i && (i = t, r = n);
	}
	return r;
}
function Je(e, t, n) {
	if (n) return Q(t.map((e, t) => t));
	let r = e ? new Set(e.map(Z)) : null, i = 0, a = -Infinity;
	return t.forEach((e, t) => {
		let n = e.length * 10 + e.reduce((e, t) => e + X(t), 0) + (r ? e.filter((e) => r.has(Z(e))).length * 5 : 0);
		n > a && (a = n, i = t);
	}), i;
}
var Ye = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "done" || !r) return null;
	let i = t.difficulty === "weak", a = n.roles.ren === t.rid, o = n.roles.feth === t.rid;
	if (!a && !o) return null;
	let s = n.pending;
	if (s) switch (s.kind) {
		case "heartReveal": return a ? { action: {
			type: "revealHeart",
			index: qe(n, s.candidates, i)
		} } : null;
		case "splitChoice": return a ? { action: {
			type: "chooseChunk",
			keep: Je(r.hearts, s.chunks, i)
		} } : null;
		case "steal": return o ? i && Q([!0, !1]) ? { action: { type: "stealPass" } } : { action: {
			type: "stealBlock",
			color: [...s.groups].sort((e, t) => t.count - e.count)[0].color
		} } : null;
		case "peekStolen": {
			let e = r.peek;
			return !e || e.length === 0 ? e ? { action: { type: "cancelPeek" } } : null : { action: {
				type: "goldRescue",
				card: [...e].sort((e, t) => X(t) - X(e))[0]
			} };
		}
	}
	if (n.phase === "arrange") return a && r.hearts ? { action: Be(r.hearts, i) } : null;
	if (n.phase === "dreamEnd") return { action: { type: "endDream" } };
	if (n.deckCount <= 4 && $(n, "goldReturn") > 0) {
		let e = n.discard.filter((e) => x.has(e)).sort((e, t) => X(t) - X(e)).slice(0, 3);
		if (e.length === 3) return { action: {
			type: "useGoldReturn",
			picks: e
		} };
	}
	if (o && n.phase === "draw") return { action: Ve(n, i) };
	if (o && n.phase === "place") return { action: We(n, i) };
	if (a && n.phase === "renTake" && r.hearts) {
		if (!i && n.dream === 3) {
			let e = Ke(n, r.hearts);
			if (e) return { action: e };
		}
		let e = Ge(n, r.hearts, i);
		return e ? { action: e } : null;
	}
	return null;
};
//#endregion
//#region src/games/sahashri/game-over.tsx
function Xe({ result: e, public: t, members: n, hintCount: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = s(), c = t, l = e.winner.length > 0, u = e.scores?.[e.ranking[0]] ?? 0, d = u >= 11 && c.scoreRavens >= 2 ? "games.sahashri.endingHappy" : u >= 4 ? "games.sahashri.endingGood" : "games.sahashri.endingNormal", h = (e) => n.find((t) => t.rid === e)?.name ?? e, g = i ?? a;
	return /* @__PURE__ */ f("div", {
		className: "sah-over",
		children: /* @__PURE__ */ p("div", {
			className: "sah-over-content",
			children: [
				/* @__PURE__ */ p("div", {
					className: "sah-over-summary",
					children: [
						l && /* @__PURE__ */ f(m, {}),
						/* @__PURE__ */ f("span", {
							"aria-hidden": !0,
							className: "sah-over-symbol",
							children: l ? "🌅" : "🐦‍⬛"
						}),
						/* @__PURE__ */ f("h1", {
							className: "flex-none text-center font-display text-2xl font-extrabold",
							children: o(l ? "games.sahashri.overWin" : "games.sahashri.overLose")
						}),
						!l && c.loseReason && /* @__PURE__ */ f("p", {
							className: "flex-none text-sm font-bold text-warn-ink",
							children: o(c.loseReason)
						}),
						/* @__PURE__ */ p("p", {
							className: "flex-none text-sm font-bold opacity-70",
							children: [
								l && `${o(d)} · `,
								o("games.sahashri.overScore", { n: u }),
								l && c.scoreRavens > 0 ? ` · ${o("games.sahashri.overRavens", { n: c.scoreRavens })}` : ""
							]
						}),
						r !== void 0 && /* @__PURE__ */ f("p", {
							className: "sah-over-hints",
							children: o("session.hint.usedCount", { n: r })
						})
					]
				}),
				/* @__PURE__ */ p("ul", {
					className: "sah-over-partners",
					children: [/* @__PURE__ */ p("li", {
						className: "frame flex items-center gap-2 px-3 py-1.5 text-sm font-bold",
						children: [
							/* @__PURE__ */ f("span", {
								"aria-hidden": !0,
								children: "🌙"
							}),
							/* @__PURE__ */ f("span", {
								className: "min-w-0 flex-1 truncate",
								children: h(c.roles.ren)
							}),
							/* @__PURE__ */ f("span", {
								className: "text-xs opacity-70",
								children: o("games.sahashri.roleRen")
							})
						]
					}), /* @__PURE__ */ p("li", {
						className: "frame flex items-center gap-2 px-3 py-1.5 text-sm font-bold",
						children: [
							/* @__PURE__ */ f("span", {
								"aria-hidden": !0,
								children: "🔮"
							}),
							/* @__PURE__ */ f("span", {
								className: "min-w-0 flex-1 truncate",
								children: h(c.roles.feth)
							}),
							/* @__PURE__ */ f("span", {
								className: "text-xs opacity-70",
								children: o("games.sahashri.roleFeth")
							})
						]
					})]
				}),
				g ? /* @__PURE__ */ p("div", {
					className: "sah-over-actions safe-b",
					children: [i && /* @__PURE__ */ f("button", {
						className: "btn-base w-full cursor-pointer text-white",
						style: { background: T.accent },
						onClick: i,
						children: o("session.result.playAgain")
					}), a && /* @__PURE__ */ f("button", {
						className: "btn-quiet w-full cursor-pointer",
						onClick: a,
						children: o("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ f("p", {
					className: "sah-over-wait safe-b text-sm font-bold opacity-70",
					children: o("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region src/games/sahashri/options.tsx
function Ze({ value: e, onChange: t }) {
	let n = s(), r = ie.safeParse(e), i = r.success ? r.data : ie.parse(void 0);
	return /* @__PURE__ */ f(g, {
		title: n("games.sahashri.optHostRole"),
		columns: 3,
		children: [
			{
				v: "random",
				key: "games.sahashri.optRandom"
			},
			{
				v: "ren",
				key: "games.sahashri.optRen"
			},
			{
				v: "feth",
				key: "games.sahashri.optFeth"
			}
		].map(({ v: e, key: r }) => /* @__PURE__ */ f(h, {
			name: "sahashri-host-role",
			value: e,
			checked: i.hostRole === e,
			label: n(r),
			accent: T.accent,
			onChange: () => t({ hostRole: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/sahashri/entry.tsx
var Qe = {
	definition: Oe,
	View: Y,
	bot: Ye,
	OverView: Xe,
	Options: Ze,
	locales: {
		zh: {
			name: "三千鸦杀",
			desc: "双人合作:Feth 以记忆牌搭建幻境,Ren 寻回失落的内心写成诗,赶在乌鸦吞尽记忆前做完三场梦",
			rules: "目标:两人合作完成三场梦。每场梦中,Ren 将 4 张心牌写成「7-7-7-5」四行诗;诗成时幻境颜色与心牌颜色一致,梦才圆满。\n分工:\n· Feth(通灵者)负责抽牌与搭建幻境;Ren(忆主)负责从幻境取牌写诗。\nFeth 回合:\n· 从牌堆任意抽牌放入记忆列:安全区大小等于乌鸦列的乌鸦数,区内抽到的乌鸦作废,区外的进入乌鸦列。\n· 随后至少叠放 1 张牌进幻境:象限明暗必须一致,且至少一处褪色压褪色;用不上的牌弃掉,若同色乌鸦在列则被其偷走。\n共鸣:\n· 放入的牌与同色相连牌恰好凑满 7 点时,赶走该色乌鸦(最终梦中为击败),Ren 翻开一张同色心牌。\nRen 回合:\n· 从幻境取 1 张可见牌:能放进当前诗行就必须放,否则弃掉。\n· 取牌可能使幻境分裂,须选择一簇保留。\n诗牌能力:\n· 入诗的牌提供一次性能力:金 = 回牌堆,红 = 剪幻境,蓝 = 凑 7 辅助,绿 = 摆放辅助,紫 = 防乌鸦。\n· 红与金双方皆可使用,其余仅 Feth 可用。\n败北(任一触发):\n· 牌堆抽空;五色乌鸦齐聚乌鸦列;幻境清空;Feth 无牌可放。\n· 最终梦中 Ren 未完成诗行,或诗成时幻境颜色与心牌不合。\n计分与结局:\n· 每场梦结算时,因共鸣翻开的心牌进入得分堆;最终梦中击败的乌鸦连同其赃物一并计分。\n· 0~3 分为普通结局,4~10 分为好结局,11 分以上且击败至少 2 只乌鸦为圆满结局。",
			roleRen: "Ren(忆主)",
			roleFeth: "Feth(通灵者)",
			dreamN: "第 {{n}} 场梦",
			phaseArrange: "Ren 排定心牌顺序(对应四行诗)",
			phaseDraw: "Feth 抽牌",
			phasePlace: "Feth 搭建幻境",
			phaseRenTake: "Ren 取牌写诗",
			phaseDreamEnd: "梦境将尽,可用金/紫能力挽回牌",
			deckN: "牌堆 {{n}}",
			discardN: "弃牌 {{n}}",
			ravenRow: "乌鸦列",
			safeArea: "安全区 {{n}}",
			memoryRow: "记忆列",
			scoreN: "得分 {{n}}",
			atmanName: "幻境",
			poemName: "都都逸",
			rowTarget: "目标 {{n}}",
			colorGold: "金",
			colorRed: "红",
			colorBlue: "蓝",
			colorGreen: "绿",
			colorPurple: "紫",
			abGoldReturn: "回三张",
			abGoldReturnDesc: "从弃牌堆选 3 张,按任意顺序放回牌堆顶",
			abGoldRescue: "鸦口夺牌",
			abGoldRescueDesc: "从一只乌鸦处救 1 张回牌堆顶",
			abRedCut1: "剪除",
			abRedCut1Desc: "弃掉幻境中 1 张牌",
			abRedCut2: "剪除×2",
			abRedCut2Desc: "弃掉幻境中至多 2 张牌",
			abBlueShift: "忆值±1",
			abBlueShiftDesc: "下一张放入的牌点数 ±1(仅用于凑 7 共鸣)",
			abBlueEcho: "同鸣",
			abBlueEchoDesc: "下一张牌压住的 1 张牌,视为同色参与凑 7",
			abGreenSpin: "旋转",
			abGreenSpinDesc: "下一张牌可旋转 180° 再放",
			abGreenWild: "任意门",
			abGreenWildDesc: "下一张牌无视图案规则",
			abPurpleVeil: "帷幕",
			abPurpleVeilDesc: "本回合安全区 +2",
			abPurpleBlock: "拦鸦",
			abPurpleBlockDesc: "阻止一只乌鸦偷牌(同一瞬间全部)",
			abilitiesTitle: "诗牌能力",
			arrangeHint: "拖动或点选排定心牌顺序:第 1-3 行凑 7,第 4 行凑 5",
			arrangeConfirm: "排好了",
			drawBtn: "抽一张",
			finishDrawBtn: "抽完进放置",
			placeHint: "先点记忆列的牌,再点幻境高亮落点",
			finishPlaceBtn: "放置完毕",
			takeHint: "点幻境中一张可见牌取走",
			takeHintDream3: "取一张牌并凑齐当前诗行(可从得分堆补牌)",
			scorePickHint: "再从得分堆选牌,与取牌合计凑齐 {{n}}",
			confirmTake: "确认取牌",
			declareLoss: "无法凑齐,梦碎于此",
			declareLossConfirm: "确认无法完成本行?这局就输了",
			endDreamBtn: "让这场梦落幕",
			pendingHeart: "共鸣!选择要翻开的{{color}}色心牌",
			pendingSplit: "幻境分裂:选择保留哪一簇",
			pendingSteal: "乌鸦要偷牌!拦下一只,或放行",
			stealPass: "放行",
			pendingPeek: "选择要救回牌堆顶的牌",
			peekCancel: "算了",
			modRot: "旋转 180°",
			modWild: "无视图案",
			modShift: "点数 {{n}}",
			modEcho: "选同鸣目标",
			heartHidden: "背面",
			overWin: "Ren 睁开了眼睛",
			overLose: "梦碎鸦群",
			endingNormal: "普通结局",
			endingGood: "好结局",
			endingHappy: "圆满结局",
			overScore: "得分 {{n}}",
			overRavens: "击败乌鸦 {{n}} 只",
			waitOther: "等 {{name}} …",
			optHostRole: "主机扮演",
			optRandom: "随机",
			optRen: "Ren(写诗)",
			optFeth: "Feth(搭幻境)",
			errNotYourTurn: "还没轮到你",
			errPhase: "当前阶段不能这么做",
			errPending: "先处理眼前的抉择",
			errBadCard: "这张牌现在选不了",
			errBadOrder: "心牌顺序不对",
			errEmptyDeck: "牌堆已抽空",
			errNoAbility: "没有可用的诗牌能力",
			errNoOverlap: "必须与幻境中已有的牌重叠",
			errMismatch: "象限明暗不一致:褪色只能压褪色",
			errNoFaded: "至少要有一处褪色压褪色",
			errSamePattern: "不能用相同图案直接盖死一张牌",
			errBadEcho: "同鸣目标必须是被这张牌压住的可见牌",
			errBadTargets: "目标必须是幻境中的可见牌",
			errBadPicks: "从弃牌堆选 3 张",
			errBadTake: "这组牌凑不齐当前诗行",
			loseDeck: "牌堆抽空,记忆耗尽",
			loseRavens: "五鸦齐聚,梦境被吞噬",
			loseNoPlace: "Feth 一张牌也放不进幻境",
			loseAtman: "幻境崩塌一空",
			loseDream3Row: "最终梦里 Ren 没能完成诗行",
			loseDream3Color: "诗成时幻境颜色与心牌不合"
		},
		en: {
			name: "The Ravens of Thri Sahashri",
			desc: "2-player co-op: Feth builds the Atman from memory cards while Ren writes her heart into a poem — finish three dreams before the ravens devour everything",
			rules: "Goal: complete three Dreams together. Each Dream, Ren turns 4 Heart cards into a 7-7-7-5 poem; the Dream only closes if the Atman’s colors match her Heart colors.\nRoles:\n· Feth (the psychic) draws cards and builds the Atman; Ren (the dreamer) takes cards from the Atman to write the poem.\nFeth’s turn:\n· Draw any number of cards into the Memory Row: the safe zone equals the ravens in the Raven Row; ravens drawn inside it are discarded, outside they join the Row.\n· Then place at least 1 card onto the Atman: quadrants must match light and dark, with at least one faded-on-faded; unused cards are discarded — stolen instead if that color’s raven is in the Row.\nRelive:\n· If the placed card plus connected same-color cards sum to exactly 7, chase that raven away (defeat it in the final Dream) and Ren reveals a matching Heart card.\nRen’s turn:\n· Take 1 visible Atman card: if it fits the current poem row she must add it, otherwise discard it.\n· Taking may split the Atman; she chooses one chunk to keep.\nPoem abilities:\n· Cards in poem rows grant one-shot powers: gold returns cards to the deck, red cuts the Atman, blue aids reliving, green aids placement, purple wards off ravens.\n· Red and gold are usable by both; the rest only by Feth.\nDefeat (any one triggers):\n· The deck runs out; all five ravens gather in the Row; the Atman empties; Feth cannot place.\n· In the final Dream Ren fails a row, or the Atman colors mismatch her Hearts when the poem closes.\nScoring and endings:\n· At each Dream’s end, Hearts revealed by reliving enter the score pile; ravens defeated in the final Dream score together with their loot.\n· 0-3 is the normal ending, 4-10 the good ending, 11 or more with at least 2 defeated ravens the happy ending.",
			roleRen: "Ren (the dreamer)",
			roleFeth: "Feth (the psychic)",
			dreamN: "Dream {{n}}",
			phaseArrange: "Ren orders her Heart cards (one per poem row)",
			phaseDraw: "Feth draws cards",
			phasePlace: "Feth builds the Atman",
			phaseRenTake: "Ren takes a card for her poem",
			phaseDreamEnd: "Dream ending: gold/purple powers still usable",
			deckN: "Deck {{n}}",
			discardN: "Discard {{n}}",
			ravenRow: "Raven Row",
			safeArea: "Safe {{n}}",
			memoryRow: "Memory Row",
			scoreN: "Score {{n}}",
			atmanName: "Atman",
			poemName: "Dodoitsu",
			rowTarget: "Target {{n}}",
			colorGold: "Gold",
			colorRed: "Red",
			colorBlue: "Blue",
			colorGreen: "Green",
			colorPurple: "Purple",
			abGoldReturn: "Return 3",
			abGoldReturnDesc: "Put 3 discards back on the deck in any order",
			abGoldRescue: "Rescue",
			abGoldRescueDesc: "Rescue 1 card from a raven onto the deck",
			abRedCut1: "Cut 1",
			abRedCut1Desc: "Discard 1 Atman card",
			abRedCut2: "Cut 2",
			abRedCut2Desc: "Discard up to 2 Atman cards",
			abBlueShift: "Shift ±1",
			abBlueShiftDesc: "Next placed card counts ±1 for reliving",
			abBlueEcho: "Echo",
			abBlueEchoDesc: "One card under the next counts as its color",
			abGreenSpin: "Rotate",
			abGreenSpinDesc: "Next card may be rotated 180°",
			abGreenWild: "Wild",
			abGreenWildDesc: "Next card ignores pattern rules",
			abPurpleVeil: "Veil",
			abPurpleVeilDesc: "Safe area +2 this turn",
			abPurpleBlock: "Ward",
			abPurpleBlockDesc: "Block one raven from stealing right now",
			abilitiesTitle: "Poem abilities",
			arrangeHint: "Order the Heart cards: rows 1-3 aim for 7, row 4 for 5",
			arrangeConfirm: "Done",
			drawBtn: "Draw",
			finishDrawBtn: "Stop drawing",
			placeHint: "Tap a Memory Row card, then a highlighted spot",
			finishPlaceBtn: "Done placing",
			takeHint: "Tap a visible Atman card to take it",
			takeHintDream3: "Take a card and complete the row (may add Score Pile cards)",
			scorePickHint: "Pick Score Pile cards so they total {{n}} with the taken card",
			confirmTake: "Confirm",
			declareLoss: "Cannot complete — the dream breaks",
			declareLossConfirm: "Sure you cannot complete this row? The game is lost",
			endDreamBtn: "End this Dream",
			pendingHeart: "Relived! Choose a {{color}} Heart to reveal",
			pendingSplit: "The Atman split: choose a chunk to keep",
			pendingSteal: "Ravens are stealing! Ward one off, or let them",
			stealPass: "Let them",
			pendingPeek: "Choose a card to rescue onto the deck",
			peekCancel: "Never mind",
			modRot: "Rotate 180°",
			modWild: "Ignore pattern",
			modShift: "Value {{n}}",
			modEcho: "Pick echo target",
			heartHidden: "Hidden",
			overWin: "Ren opens her eyes",
			overLose: "The dream is devoured",
			endingNormal: "Normal Ending",
			endingGood: "Good Ending",
			endingHappy: "Happy Ending",
			overScore: "Score {{n}}",
			overRavens: "Ravens defeated: {{n}}",
			waitOther: "Waiting for {{name}}…",
			optHostRole: "Host plays",
			optRandom: "Random",
			optRen: "Ren (poem)",
			optFeth: "Feth (Atman)",
			errNotYourTurn: "Not your turn",
			errPhase: "Not allowed right now",
			errPending: "Resolve the pending choice first",
			errBadCard: "That card is not available",
			errBadOrder: "Invalid Heart order",
			errEmptyDeck: "The deck is empty",
			errNoAbility: "No usable poem ability",
			errNoOverlap: "Must overlap an existing card",
			errMismatch: "Quadrants must match: faded on faded only",
			errNoFaded: "Need at least one faded-on-faded overlap",
			errSamePattern: "Cannot directly bury a card with the same pattern",
			errBadEcho: "Echo target must be a visible card under this one",
			errBadTargets: "Targets must be visible Atman cards",
			errBadPicks: "Pick 3 cards from the discard pile",
			errBadTake: "These cards cannot complete the row",
			loseDeck: "The deck ran out — memories exhausted",
			loseRavens: "All five ravens gathered — the dream is devoured",
			loseNoPlace: "Feth could not place a single card",
			loseAtman: "The Atman collapsed to nothing",
			loseDream3Row: "Ren failed to complete a row in the final Dream",
			loseDream3Color: "The poem finished but the colors did not match"
		}
	}
};
//#endregion
export { Qe as default };
