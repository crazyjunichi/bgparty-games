import { randomAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { AVATARS as n } from "@bgparty/sdk/avatars";
import { useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { useWakeLock as s } from "@bgparty/sdk/use-wake-lock";
import { BottomSheet as c } from "@bgparty/sdk/bottom-sheet";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { SheetFxProbe as f, SheetView as p } from "@bgparty/sdk/sheet-view";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { useFxAnchor as _, useFxAnchorsMaybe as v } from "@bgparty/sdk/fx/anchors";
import { Floater as y, FlySprite as ee, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/searchforuaps/meta.ts
var te = {
	id: "searchforuaps",
	tier: "alpha",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.searchforuaps.name",
	descKey: "games.searchforuaps.desc",
	rulesKey: "games.searchforuaps.rules",
	icon: "🛸",
	iconImg: "games/searchforuaps.webp",
	rulesUrl: { en: "https://renegadegamestudios.com/content/File%20Storage%20for%20site/Rulebooks/Search%20for%20UAPs/SUAP_Rulebook_WEB.pdf" },
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [
		2,
		3,
		4
	],
	accent: "#68b345",
	releasedAt: "2026-11-01T00:43:00+08:00",
	search: {
		py: "xun zhao uap",
		init: "xzuap"
	},
	hotseat: "cover"
}, C = t.enum([
	"luna",
	"hubble",
	"iss",
	"spy",
	"meteor",
	"comm",
	"nav",
	"junk",
	"uap"
]), w = [
	"hubble",
	"iss",
	"comm",
	"spy",
	"nav",
	"meteor"
], ne = t.enum(w), T = t.int().min(0).max(23), E = t.int().min(0).max(3), D = [
	"blank",
	"charter",
	"hitch",
	"hurricane",
	"border",
	"quantum",
	"advancedDetection",
	"government",
	"fullMoon",
	"overcast",
	"atmospheric",
	"brainTrust",
	"rapidFire",
	"lunarEclipse",
	"carbon",
	"lowBandwidth",
	"emp",
	"coronal",
	"hadron",
	"grant",
	"advancedTech",
	"copied",
	"group",
	"unique"
], O = t.enum(D), re = t.object({
	board: t.enum(["basic", "expert"]).default("basic"),
	modifiers: t.enum([
		"blank",
		"random",
		"custom"
	]).default("blank"),
	quadrants: t.array(O).length(4).default([
		"blank",
		"blank",
		"blank",
		"blank"
	])
}).refine((e) => e.modifiers !== "custom" || new Set(e.quadrants.filter((e) => e !== "blank")).size === e.quadrants.filter((e) => e !== "blank").length, { message: "Each nonblank modifier is unique" }).default({
	board: "basic",
	modifiers: "blank",
	quadrants: [
		"blank",
		"blank",
		"blank",
		"blank"
	]
}), ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("prepare"),
		quadrant: E,
		difficulty: t.enum([
			"beginner",
			"experienced",
			"genius"
		])
	}),
	t.object({
		type: t.literal("move"),
		quadrant: E
	}),
	t.object({
		type: t.literal("follow"),
		accept: t.boolean()
	}),
	t.object({
		type: t.literal("survey"),
		scope: t.enum([
			"quadrant",
			"inner",
			"outer",
			"stack",
			"sector"
		]),
		sector: T,
		objects: t.array(C.exclude(["uap"])).min(1).max(2)
	}),
	t.object({
		type: t.literal("target"),
		sectors: t.array(T).min(1).max(2)
	}),
	t.object({
		type: t.literal("photo"),
		entries: t.array(t.object({
			sector: T,
			object: ne
		})).min(1).max(3)
	}),
	t.object({
		type: t.literal("analyze"),
		topic: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("locate"),
		sector: T,
		neighbors: t.array(C.exclude(["uap"])).length(3)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("note"),
		sector: T,
		object: C,
		mark: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("memo"),
		text: t.string().max(2400)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ae = t.object({
	kind: t.enum([
		"not",
		"quantity",
		"allOpposite",
		"noOppositeSelf",
		"sameOrbit",
		"differentOrbit",
		"odd",
		"even",
		"allNext",
		"noNextSelf",
		"noNext",
		"nextOne",
		"someNext",
		"someBetween",
		"between",
		"opposite",
		"someOpposite",
		"noOpposite",
		"uapNotNext",
		"uapNotWithinTwo",
		"uapNotOpposite"
	]),
	object: C,
	other: C.optional(),
	sector: T.optional(),
	count: t.int().optional()
}), k = t.object({
	kind: t.enum([
		"start",
		"survey",
		"target",
		"analyze",
		"report",
		"locate"
	]),
	time: t.int(),
	rotation: t.int(),
	sectors: t.array(T),
	objects: t.array(C),
	counts: t.array(t.int()),
	fact: ae.optional(),
	topic: t.int().optional(),
	success: t.boolean().optional()
}), oe = t.object({
	rid: t.string(),
	time: t.int(),
	arrival: t.int(),
	quadrant: E,
	prepared: t.boolean(),
	locatePoints: t.int(),
	photoPoints: t.int(),
	photos: t.int(),
	score: t.int()
}), A = t.object({
	id: t.int(),
	rid: t.string(),
	sector: T,
	object: ne.optional(),
	verified: t.boolean()
}), j = t.object({
	phase: t.enum([
		"prepare",
		"turn",
		"follow",
		"rotate",
		"verify",
		"reveal",
		"final",
		"done"
	]),
	n: t.int(),
	rotation: t.int(),
	turn: t.string().nullable(),
	players: t.array(oe),
	modifiers: t.array(O),
	luna: T,
	photos: t.array(A),
	topics: t.array(t.array(C)),
	locator: t.string().nullable(),
	behind: t.int(),
	finalPhotos: t.int(),
	follow: t.object({
		pending: t.array(t.string()),
		destination: E
	}).nullable(),
	board: t.array(C).nullable(),
	history: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		time: t.int(),
		sectors: t.array(T),
		objects: t.array(C),
		success: t.boolean().optional()
	})),
	solo: t.boolean()
}), se = t.object({
	clues: t.array(k),
	notes: t.record(t.string(), t.int()),
	memo: t.string(),
	topics: t.array(ae.nullable()),
	myPhotos: t.array(A),
	analyzed: t.array(t.int()),
	used: t.array(t.int())
}), M = [
	"luna",
	"hubble",
	"iss",
	"spy",
	"meteor",
	"comm",
	"nav",
	"junk",
	"uap"
], N = {
	hubble: 4,
	iss: 4,
	comm: 3,
	spy: 3,
	nav: 2,
	meteor: 2
}, P = (e, t) => (e % t + t) % t, F = (e, t) => Math.floor(e / t) * t + P(e + t / 2, t), I = (e, t) => [Math.floor(e / t) * t + P(e - 1, t), Math.floor(e / t) * t + P(e + 1, t)], ce = (e, t, n) => e < t ? t + P(e - n, t) : P(e - t + n, t), le = (e, t, n) => [...I(e, t), ce(e, t, n)], L = (e, t, n) => Math.floor((e < t ? e : P(e - t + n, t)) / (t / 4)), R = (e, t, n) => Array.from({ length: t * 2 }, (e, t) => t).filter((r) => L(r, t, n) === e), z = (e) => e === "uap" ? "junk" : e;
function ue(e) {
	return [
		1,
		1,
		e === 8 ? 2 : 4,
		e === 8 ? 2 : 4,
		e === 8 ? 6 : 8,
		e === 8 ? 6 : 8
	];
}
function de(e, t) {
	let n = (t) => e.flatMap((e, n) => e === t ? [n] : []), r = (e) => n(e).length;
	return e.length !== t * 2 || [
		"luna",
		"hubble",
		"iss",
		"uap"
	].some((e) => r(e) !== 1) || n("luna")[0] < t || n("hubble")[0] < t || I(n("luna")[0], t).includes(n("hubble")[0]) || n("iss")[0] >= t || !I(n("iss")[0], t).some((t) => e[t] === "junk") || r("spy") < 1 || r("spy") > (t === 8 ? 2 : 4) || n("spy").some((e) => e >= t || e % 2 != 0) || r("comm") < 1 || r("comm") > (t === 8 ? 2 : 4) || n("comm").some((e) => e % 2 != 1) || t === 12 && [0, 1].some((e) => n("comm").filter((n) => Math.floor(n / t) === e).length > 2) || r("meteor") > (t === 8 ? 6 : 8) || n("meteor").some((n) => e[(n + t) % (2 * t)] !== "meteor") || r("nav") < 2 || r("nav") > (t === 8 ? 6 : 8) || n("nav").some((n) => e[F(n, t)] !== "nav") ? !1 : r("junk") >= 1 && r("junk") <= (t === 8 ? 5 : 8) && !n("junk").some((n) => I(n, t).every((t) => e[t] === "junk"));
}
function fe(e, t) {
	let n = (e) => {
		for (let n = e.length - 1; n > 0; n--) {
			let r = Math.floor(t() * (n + 1));
			[e[n], e[r]] = [e[r], e[n]];
		}
		return e;
	};
	for (let r = 0; r < 1e5; r++) {
		let r = Array(e * 2).fill(null), i = () => r.flatMap((e, t) => e === null ? [t] : []), a = (e, n) => {
			let a = i().filter(n);
			return a.length ? (r[a[Math.floor(t() * a.length)]] = e, !0) : !1;
		};
		if (a("luna", (t) => t >= e), !a("hubble", (t) => t >= e && !I(r.indexOf("luna"), e).includes(t))) continue;
		let o = Math.floor(t() * (e === 8 ? 4 : 5)), s = n(Array.from({ length: e }, (e, t) => t).filter((t) => r[t] === null && r[e + t] === null));
		if (s.length < o) continue;
		for (let t of s.slice(0, o)) r[t] = r[t + e] = "meteor";
		let c = 1 + Math.floor(t() * (e === 8 ? 3 : 4)), l = n(i().filter((t) => t % e < e / 2 && r[F(t, e)] === null));
		if (l.length < c) continue;
		for (let t of l.slice(0, c)) r[t] = r[F(t, e)] = "nav";
		let u = !0, d = 1 + Math.floor(t() * (e === 8 ? 2 : 4)), f = 1 + Math.floor(t() * (e === 8 ? 2 : 4));
		for (let t = 0; t < d; t++) a("spy", (t) => t < e && t % 2 == 0) || (u = !1);
		for (let t = 0; t < f; t++) a("comm", (t) => t % 2 == 1 && (e === 8 || r.filter((n, r) => n === "comm" && Math.floor(r / e) === Math.floor(t / e)).length < 2)) || (u = !1);
		if (!u || !a("iss", (t) => t < e) || !a("uap", () => !0)) continue;
		let p = r.map((e) => e ?? "junk");
		if (de(p, e)) return p;
	}
	throw Error("Unable to generate an orbit layout");
}
function B(e, t, n) {
	let r = e.flatMap((e, t) => e === n.object ? [t] : []), i = e.flatMap((e, t) => e === n.other ? [t] : []), a = (e, n) => I(e, t).includes(n), o = (e, n) => F(e, t) === n;
	switch (n.kind) {
		case "not": return e[n.sector] !== n.object;
		case "quantity": return r.length === n.count;
		case "allOpposite": return r.length > 0 && r.every((r) => e[F(r, t)] === n.object);
		case "noOppositeSelf": return r.length > 0 && r.every((r) => e[F(r, t)] !== n.object);
		case "sameOrbit": return r.length > 1 && r.every((e) => Math.floor(e / t) === Math.floor(r[0] / t));
		case "differentOrbit": return r.length === 2 && Math.floor(r[0] / t) !== Math.floor(r[1] / t);
		case "odd": return r.length > 0 && r.every((e) => e % 2 == 0);
		case "even": return r.length > 0 && r.every((e) => e % 2 == 1);
		case "allNext": return r.length > 0 && r.every((r) => I(r, t).some((t) => e[t] === n.object));
		case "noNextSelf": return r.length > 0 && r.every((r) => I(r, t).every((t) => e[t] !== n.object));
		case "noNext": return r.length > 0 && i.length > 0 && r.every((e) => i.every((t) => !a(e, t)));
		case "nextOne": return r.length === 1 && i.filter((e) => a(r[0], e)).length === 1;
		case "someNext": return r.some((e) => i.some((t) => a(e, t)));
		case "someBetween": return r.some((r) => I(r, t).every((t) => e[t] === n.other));
		case "between": return r.length === 1 && I(r[0], t).every((t) => e[t] === n.other);
		case "opposite": return r.length === 1 && i.some((e) => o(r[0], e));
		case "someOpposite": return r.some((e) => i.some((t) => o(e, t)));
		case "noOpposite": return r.length > 0 && i.length > 0 && r.every((e) => i.every((t) => !o(e, t)));
		case "uapNotNext": return i.length > 0 && i.every((t) => !a(e.indexOf("uap"), t));
		case "uapNotWithinTwo": return i.length > 0 && i.every((n) => Math.floor(n / t) !== Math.floor(e.indexOf("uap") / t) || Math.min(P(n - e.indexOf("uap"), t), P(e.indexOf("uap") - n, t)) > 2);
		case "uapNotOpposite": return i.length > 0 && i.every((t) => !o(e.indexOf("uap"), t));
	}
}
function V(e, t) {
	let n = [
		[],
		[],
		[],
		[]
	];
	for (let r of M.filter((e) => e !== "uap")) if (e.includes(r)) {
		for (let i of [
			"allOpposite",
			"noOppositeSelf",
			"sameOrbit",
			"differentOrbit",
			"odd",
			"even",
			"allNext",
			"noNextSelf"
		]) {
			let a = {
				kind: i,
				object: r
			};
			B(e, t, a) && n[0].push(a);
		}
		n[2].push({
			kind: "quantity",
			object: r,
			count: e.filter((e) => e === r).length
		});
		for (let i of M.filter((e) => e !== "uap" && e !== r)) for (let a of [
			"noNext",
			"nextOne",
			"someNext",
			"someBetween",
			"between",
			"opposite",
			"someOpposite",
			"noOpposite"
		]) {
			let o = {
				kind: a,
				object: r,
				other: i
			};
			B(e, t, o) && n[1].push(o);
		}
		for (let i of [
			"uapNotNext",
			"uapNotWithinTwo",
			"uapNotOpposite"
		]) {
			let a = {
				kind: i,
				object: "uap",
				other: r
			};
			B(e, t, a) && n[3].push(a);
		}
	}
	return n;
}
function H(e, t, n) {
	return e === t || n[t] === "border" && P(t - e, 4) !== 2 ? null : n[e] === "charter" || n[t] === "charter" ? 0 : Math.min(P(t - e, 4), P(e - t, 4)) + +(n[e] === "hurricane") + +(n[t] === "hurricane");
}
//#endregion
//#region src/games/searchforuaps/strategy.ts
function U(e, t) {
	let n = Array(e.n * 2).fill(null);
	n[e.luna] = "luna";
	for (let t of e.photos) t.verified && t.object && (n[t.sector] = t.object);
	for (let e of t.clues) e.kind === "target" && e.sectors.forEach((t, r) => n[t] = e.objects[r]), e.kind === "survey" && e.sectors.length === 1 && e.objects.forEach((t, r) => {
		e.counts[r] > 0 && (n[e.sectors[0]] = t);
	});
	for (let r = 0; r < n.length; r++) if (n[r] === null) {
		let i = M.filter((t) => t !== "uap" && t !== "luna" && !(r < e.n && t === "hubble") && !(r >= e.n && ["iss", "spy"].includes(t)) && (t !== "spy" || r % 2 == 0) && (t !== "comm" || r % 2 != 0)).filter((e) => !t.clues.some((t) => t.sectors.includes(r) && (t.kind === "survey" || t.kind === "start") && t.objects.some((n, r) => n === e && t.counts[r] === 0)));
		i.length === 1 && (n[r] = i[0]);
	}
	return n;
}
function W(e, t, n) {
	let r = e.public, i = e.private;
	if (!i || r.turn !== t) return null;
	if (r.phase === "prepare") return {
		type: "prepare",
		quadrant: r.players.findIndex((e) => e.rid === t) % 4,
		difficulty: "experienced"
	};
	if (r.phase === "follow") return {
		type: "follow",
		accept: !1
	};
	if (!["turn", "final"].includes(r.phase)) return null;
	let a = r.players.find((e) => e.rid === t), o = r.modifiers[a.quadrant], s = r.phase === "final", c = U(r, i), l = R(a.quadrant, r.n, r.rotation), u = o === "atmospheric" || o === "fullMoon" && l.includes(r.luna), d = o === "emp" || o === "fullMoon" && l.includes(r.luna), f = (s ? Array.from({ length: r.n * 2 }, (e, t) => t) : l).flatMap((e) => {
		let n = c[e];
		return !w.includes(n) || o === "overcast" || r.photos.some((n) => n.sector === e && (n.verified || n.rid === t)) || i.used[w.indexOf(n)] >= ue(r.n)[w.indexOf(n)] ? [] : [{
			sector: e,
			object: n
		}];
	}).sort((e, t) => N[t.object] - N[e.object]), p = [];
	if (c.every((e) => e !== null)) {
		for (let e = 0; e < c.length; e++) if (c[e] === "junk") {
			let t = [...c];
			if (t[e] = "uap", !de(t, r.n) || !i.clues.every((e) => !e.fact || B(t, r.n, e.fact)) || i.clues.some((e) => e.kind === "locate" && e.success === !1 && e.sectors.every((n, r) => t[n] === e.objects[r]))) continue;
			p.push(t);
		}
	}
	let m = () => {
		let e = p[0];
		if (!e) return null;
		let t = e.indexOf("uap");
		return {
			type: "locate",
			sector: t,
			neighbors: le(t, r.n, r.rotation).map((t) => e[t])
		};
	};
	if (s) {
		if (p.length === 1 && r.behind * 2 >= f.slice(0, r.finalPhotos).reduce((e, t) => e + N[t.object], 0)) return m();
		let e = [], t = [...i.used];
		for (let n of f) e.length < r.finalPhotos && t[w.indexOf(n.object)] < ue(r.n)[w.indexOf(n.object)] && (e.push(n), t[w.indexOf(n.object)]++);
		return e.length ? {
			type: "photo",
			entries: e
		} : m() ?? { type: "pass" };
	}
	if (n === "normal" && f.length) return {
		type: "photo",
		entries: f.slice(0, 1)
	};
	if (p.length) return m();
	let h = l.filter((e) => c[e] === null);
	if (h.length && !u) return {
		type: "target",
		sectors: h.slice(0, o === "rapidFire" ? 2 : 1)
	};
	if (h.length && !d) {
		for (let e of h) for (let t of M.filter((e) => e !== "uap")) if (!(o === "coronal" && [
			"spy",
			"comm",
			"nav"
		].includes(t)) && !(t === "luna" || e < r.n && t === "hubble" || e >= r.n && ["iss", "spy"].includes(t) || t === "spy" && e % 2 != 0 || t === "comm" && e % 2 == 0) && !i.clues.some((n) => n.kind === "survey" && n.sectors.length === 1 && n.sectors[0] === e && n.objects.includes(t))) return {
			type: "survey",
			scope: "sector",
			sector: e,
			objects: [t]
		};
	}
	if (!h.length && n === "weak" && f.length) return {
		type: "photo",
		entries: f.slice(0, 1)
	};
	let g = [
		0,
		1,
		2,
		3
	].filter((e) => H(a.quadrant, e, r.modifiers) !== null);
	return g.sort((e, t) => {
		let n = (e) => R(e, r.n, r.rotation).filter((e) => c[e] === null).length * 5 - (H(a.quadrant, e, r.modifiers) ?? 9);
		return n(t) - n(e);
	}), g.length ? {
		type: "move",
		quadrant: g[0]
	} : {
		type: "locate",
		sector: c.findIndex((e) => e === "junk") >= 0 ? c.findIndex((e) => e === "junk") : 0,
		neighbors: [
			"junk",
			"junk",
			"junk"
		]
	};
}
var G = "$uaps-ai", K = () => ({ code: "games.searchforuaps.invalid" }), q = (e, t) => e.players.find((e) => e.rid === t), J = (e, t, n) => e.clues[t.rid].push({
	...n,
	time: t.time,
	rotation: e.rotation
}), Y = (e, t, n, r = [], i = [], a) => e.history.push({
	rid: t.rid,
	kind: n,
	time: t.time,
	sectors: r,
	objects: i,
	...a === void 0 ? {} : { success: a }
}), pe = (e, t) => e.modifiers[t.quadrant] === "emp" || e.modifiers[t.quadrant] === "fullMoon" && L(e.board.indexOf("luna"), e.n, e.rotation) === t.quadrant, me = (e, t, n, r, i) => n < e.n * 2 && (i || L(n, e.n, e.rotation) === t.quadrant) && e.modifiers[t.quadrant] !== "overcast" && !e.photos.some((e) => e.sector === n && (e.verified || e.rid === t.rid)) && t.used[w.indexOf(r)] < ue(e.n)[w.indexOf(r)];
function X(e, t) {
	for (let n = 0; n < e.reports.length; n++) t.time >= e.reports[n].time && !e.clues[t.rid].some((e) => e.kind === "report" && e.topic === n) && J(e, t, {
		kind: "report",
		sectors: [],
		objects: [],
		counts: [],
		topic: n,
		fact: e.reports[n].fact
	});
}
function he(e, t, n) {
	t.time += n, t.arrival = e.arrival++, X(e, t);
}
function ge(e) {
	e.phase = "turn", e.turn = [...e.players].sort((e, t) => e.time - t.time || e.arrival - t.arrival)[0].rid;
}
function _e(e) {
	let t = Math.floor((Math.min(...e.players.map((e) => e.time)) - 1) / 3);
	e.pendingRotations += Math.max(0, t - e.timeLines), e.timeLines = t, e.pendingRotations > 0 ? (e.phase = "rotate", e.turn = null) : ge(e);
}
function ve(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let r of e.photos.filter((e) => !e.verified)) {
		let i = e.board[r.sector] === r.object;
		Y(e, q(e, r.rid), "verify", [r.sector], [r.object], i), i ? r.verified = !0 : (n.add(r.id), t && he(e, q(e, r.rid), 1));
	}
	e.photos = e.photos.filter((e) => !n.has(e.id));
}
function ye(e) {
	ve(e, !1);
	for (let t of e.players) {
		let n = e.photos.filter((e) => e.rid === t.rid && e.verified);
		t.photos = n.length, t.photoPoints = n.reduce((t, n) => {
			let r = e.modifiers[L(n.sector, e.n, e.rotation)], i = e.photos.filter((e) => e.sector === n.sector).length;
			return t + (r === "copied" ? 0 : N[n.object] + +(r === "unique" && i === 1 || r === "group" && i > 1));
		}, 0), t.score = t.locatePoints + t.photoPoints;
	}
	e.phase = "done", e.turn = null;
}
function be(e) {
	e.turn = e.finalQueue.shift() ?? null, e.phase = e.turn ? "final" : "verify";
}
function xe(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return {
		clues: e.clues[t] ?? [],
		notes: e.notes[t] ?? {},
		memo: e.memos[t] ?? "",
		topics: e.topics.map((e, t) => n?.analyzed.includes(t) ? e : null),
		myPhotos: e.photos.filter((e) => e.rid === t),
		analyzed: n?.analyzed ?? [],
		used: n?.used ?? [
			0,
			0,
			0,
			0,
			0,
			0
		]
	};
}
function Se(e) {
	let t = e.turn ? q(e, e.turn) : null, n = e.locator ? q(e, e.locator) : null, r = t && n ? Math.max(0, n.time - t.time) : 0;
	return {
		phase: e.phase,
		n: e.n,
		rotation: e.rotation,
		turn: e.turn,
		players: e.players.map(({ analyzed: e, used: t, ...n }) => n),
		modifiers: e.modifiers,
		luna: e.board.indexOf("luna"),
		photos: e.photos.map((e) => e.verified ? { ...e } : {
			id: e.id,
			rid: e.rid,
			sector: e.sector,
			verified: !1
		}),
		topics: e.topics.map((t, n) => {
			let r = [
				"comm",
				"comm",
				"nav",
				"nav",
				"spy",
				"spy"
			][n];
			return e.modifiers.includes("advancedDetection") || e.photos.some((e) => e.verified && e.object === r) || e.phase === "done" ? [t.object, ...t.other ? [t.other] : []] : [];
		}),
		locator: e.locator,
		behind: r,
		finalPhotos: Math.ceil(Math.min(5, r) / 2),
		follow: e.follow,
		board: e.phase === "done" ? e.board : null,
		history: e.history,
		solo: e.solo
	};
}
var Ce = {
	meta: te,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ie,
		config: re,
		publicView: j,
		privateView: se
	},
	setup(t, n, r) {
		let i = 0, a = () => e(r, i++), o = t.board === "expert" || n.length === 5 ? 12 : 8, s = fe(o, a), c = (e) => e[Math.floor(a() * e.length)], l = (e) => e.map((e) => ({
			x: e,
			k: a()
		})).sort((e, t) => e.k - t.k).map((e) => e.x), u = V(s, o), d = u.slice(0, 3).flatMap((e) => l(e).slice(0, 2)), f = l(u[3]).slice(0, 1 + Math.floor(a() * 4)).map((e, t) => ({
			fact: e,
			time: 7 + t * 5 + Math.floor(a() * 3)
		})), p = n.length === 1, m = l(p ? [...n, G] : n), h = m.map((e, t) => ({
			rid: e,
			time: 1,
			arrival: t,
			quadrant: Math.floor(a() * 4),
			prepared: e === G,
			analyzed: [],
			used: [
				0,
				0,
				0,
				0,
				0,
				0
			],
			locatePoints: 0,
			photoPoints: 0,
			photos: 0,
			score: 0
		})), g = t.modifiers === "blank" ? [
			,
			,
			,
			,
		].fill("blank") : t.modifiers === "custom" ? [...t.quadrants] : l(D.filter((e) => e !== "blank")).slice(0, 4), _ = {
			n: o,
			seed: r,
			cursor: i,
			board: s,
			rotation: 0,
			phase: "prepare",
			turn: null,
			players: h,
			clues: {},
			notes: {},
			memos: {},
			modifiers: g,
			topics: d,
			reports: f,
			photos: [],
			arrival: h.length,
			nextPhoto: 0,
			prepareQueue: [...m].reverse().filter((e) => e !== G),
			locator: null,
			finalQueue: [],
			finalMode: !1,
			follow: null,
			pendingRotations: 0,
			timeLines: 0,
			history: [],
			solo: p
		};
		for (let e of h) if (_.clues[e.rid] = [], _.notes[e.rid] = {}, _.memos[e.rid] = "", e.rid === "$uaps-ai") for (let t = 0; t < 4; t++) {
			let t = Math.floor(a() * o * 2), n = c(M.filter((e) => e !== z(s[t]) && e !== "uap"));
			J(_, e, {
				kind: "start",
				sectors: [t],
				objects: [n],
				counts: [0]
			});
		}
		return _.cursor = i, _.turn = _.prepareQueue.shift() ?? null, { state: _ };
	},
	reduce(t, n, r) {
		if (n.type === "tick") {
			if (r.by !== "$engine") return K();
			if (t.turn === "$uaps-ai" && [
				"turn",
				"final",
				"follow"
			].includes(t.phase)) {
				let e = W({
					public: Se(t),
					private: xe(t, G)
				}, G, "normal");
				return e ? Ce.reduce(t, e, { by: G }) : K();
			}
			let e = structuredClone(t);
			if (e.phase === "rotate") return e.rotation++, e.pendingRotations--, e.phase = "verify", {
				state: e,
				fx: [{
					kind: "uapsRotate",
					data: {
						rotation: e.rotation,
						n: e.n
					}
				}]
			};
			if (e.phase === "verify") {
				let t = e.photos.filter((t) => !t.verified && e.board[t.sector] !== t.object).map((e) => ({
					sector: e.sector,
					rid: e.rid
				}));
				return ve(e, !e.finalMode), e.finalMode ? e.phase = "reveal" : _e(e), {
					state: e,
					fx: [{
						kind: "uapsVerify",
						data: { wrong: t }
					}]
				};
			}
			return e.phase === "reveal" ? (ye(e), { state: e }) : K();
		}
		if (!t.players.some((e) => e.rid === r.by) || t.phase === "done") return K();
		let i = structuredClone(t), a = q(i, r.by);
		if (n.type === "note") return n.sector >= i.n * 2 ? K() : (i.notes[r.by][`${n.sector}:${n.object}`] = n.mark, { state: i });
		if (n.type === "memo") return i.memos[r.by] = n.text, { state: i };
		if (i.turn !== r.by) return K();
		if (n.type === "prepare") {
			if (i.phase !== "prepare") return K();
			a.quadrant = n.quadrant, a.prepared = !0;
			let t = n.difficulty === "beginner" ? 8 : n.difficulty === "experienced" ? 4 : 0, r = Array.from({ length: i.n * 2 }, (e, t) => M.filter((e) => e !== "uap" && e !== "luna" && e !== z(i.board[t])).map((e) => ({
				sector: t,
				object: e
			}))).flat();
			for (let n = 0; n < t; n++) {
				let t = Math.floor(e(i.seed, i.cursor++) * r.length), n = r.splice(t, 1)[0];
				J(i, a, {
					kind: "start",
					sectors: [n.sector],
					objects: [n.object],
					counts: [0]
				});
			}
			return i.turn = i.prepareQueue.shift() ?? null, i.turn || ge(i), { state: i };
		}
		if (n.type === "follow") {
			if (i.phase !== "follow" || !i.follow) return K();
			let e = a.quadrant;
			return n.accept && (a.quadrant = i.follow.destination), Y(i, a, n.accept ? "follow" : "decline"), i.follow.pending.shift(), i.turn = i.follow.pending[0] ?? null, i.turn || (i.follow = null, _e(i)), {
				state: i,
				fx: n.accept ? [{
					kind: "uapsMove",
					rid: a.rid,
					data: {
						from: e,
						to: a.quadrant
					}
				}] : []
			};
		}
		let o = i.phase === "final";
		if (!o && i.phase !== "turn" || o && ![
			"photo",
			"locate",
			"pass"
		].includes(n.type)) return K();
		let s = i.modifiers[a.quadrant], c = R(a.quadrant, i.n, i.rotation), l = 0, u = [];
		switch (n.type) {
			case "move": {
				let e = H(a.quadrant, n.quadrant, i.modifiers);
				if (e === null) return K();
				l = e;
				let t = a.quadrant;
				if (a.quadrant = n.quadrant, Y(i, a, "move", [t, n.quadrant]), u = [{
					kind: "uapsMove",
					rid: a.rid,
					data: {
						from: t,
						to: n.quadrant
					}
				}], s === "hitch") {
					let e = i.players.filter((e) => e.rid !== a.rid && e.quadrant === t).map((e) => e.rid);
					e.length && (i.follow = {
						pending: e,
						destination: n.quadrant
					});
				}
				break;
			}
			case "survey": {
				if (pe(i, a) || n.objects.length > (s === "grant" ? 2 : 1) || new Set(n.objects).size !== n.objects.length || s === "coronal" && n.objects.some((e) => [
					"spy",
					"comm",
					"nav"
				].includes(e))) return K();
				let e;
				if (n.scope === "quadrant") e = c, l = 1;
				else if (n.scope === "inner" || n.scope === "outer") e = c.filter((e) => n.scope === "inner" ? e < i.n : e >= i.n), l = 2;
				else if (c.includes(n.sector)) n.scope === "stack" ? (e = [n.sector, ce(n.sector, i.n, i.rotation)], l = 2) : (e = [n.sector], l = 3);
				else return K();
				s === "advancedTech" && (l = 1), s === "lowBandwidth" && l++;
				let t = n.objects.map((t) => e.filter((e) => z(i.board[e]) === t).length);
				J(i, a, {
					kind: "survey",
					sectors: e,
					objects: n.objects,
					counts: t
				}), Y(i, a, "survey", e, n.objects), u = [{
					kind: "uapsScan",
					rid: a.rid,
					data: { sectors: e }
				}], s === "hadron" && i.pendingRotations++;
				break;
			}
			case "target":
				if (s === "atmospheric" || pe(i, a) && s === "fullMoon" || n.sectors.some((e) => !c.includes(e)) || new Set(n.sectors).size !== n.sectors.length || n.sectors.length > (s === "rapidFire" ? 2 : 1)) return K();
				l = n.sectors.length === 2 ? 6 : s === "carbon" || s === "brainTrust" && i.players.filter((e) => e.quadrant === a.quadrant).length > 1 ? 3 : s === "lunarEclipse" && c.includes(i.board.indexOf("luna")) ? 2 : 4, J(i, a, {
					kind: "target",
					sectors: n.sectors,
					objects: n.sectors.map((e) => z(i.board[e])),
					counts: []
				}), Y(i, a, "target", n.sectors), u = [{
					kind: "uapsScan",
					rid: a.rid,
					data: { sectors: n.sectors }
				}];
				break;
			case "photo": {
				let e = o ? Math.ceil(Math.min(5, q(i, i.locator).time - a.time) / 2) : 1;
				if (n.entries.length > e || new Set(n.entries.map((e) => e.sector)).size !== n.entries.length) return K();
				for (let e of n.entries) {
					if (!me(i, a, e.sector, e.object, o)) return K();
					a.used[w.indexOf(e.object)]++, i.photos.push({
						id: i.nextPhoto++,
						rid: a.rid,
						...e,
						verified: !1
					});
				}
				l = 1, Y(i, a, "photo", n.entries.map((e) => e.sector)), u = [{
					kind: "uapsPhoto",
					rid: a.rid,
					data: { photos: i.photos.filter((e) => e.rid === a.rid && n.entries.some((t) => t.sector === e.sector)).map((e) => ({
						id: e.id,
						sector: e.sector
					})) }
				}];
				break;
			}
			case "analyze": {
				let e = [
					"comm",
					"comm",
					"nav",
					"nav",
					"spy",
					"spy"
				][n.topic], t = i.photos.some((t) => t.verified && t.object === e);
				if (s === "government" || !t && s !== "advancedDetection" || a.analyzed.includes(n.topic)) return K();
				l = (e === "spy" ? 2 : 1) + +!t;
				let r = s === "quantum" ? [Math.floor(n.topic / 2) * 2, Math.floor(n.topic / 2) * 2 + 1] : [n.topic];
				for (let e of r) a.analyzed.includes(e) || (a.analyzed.push(e), J(i, a, {
					kind: "analyze",
					sectors: [],
					objects: [],
					counts: [],
					topic: e,
					fact: i.topics[e]
				}));
				Y(i, a, "analyze", [], [e]), u = [{
					kind: "uapsIntel",
					for: [a.rid],
					secret: { topic: n.topic }
				}];
				break;
			}
			case "locate": {
				if (n.sector >= i.n * 2) return K();
				let e = le(n.sector, i.n, i.rotation), t = i.board[n.sector] === "uap" && e.every((e, t) => i.board[e] === n.neighbors[t]);
				if (J(i, a, {
					kind: "locate",
					sectors: [n.sector, ...e],
					objects: ["uap", ...n.neighbors],
					counts: [],
					success: t
				}), Y(i, a, "locate", [], [], t), l = 5, t && (a.locatePoints = o ? 2 * Math.min(5, q(i, i.locator).time - a.time) : 10, !o)) return i.locator = a.rid, he(i, a, 5), i.finalMode = !0, i.finalQueue = [...i.players].filter((e) => e.rid !== a.rid && e.time < a.time).sort((e, t) => e.time - t.time || e.arrival - t.arrival).map((e) => e.rid), be(i), {
					state: i,
					fx: [{
						kind: "uapsFound",
						rid: a.rid
					}]
				};
				u = [{
					kind: t ? "uapsFound" : "uapsMiss",
					rid: a.rid
				}];
				break;
			}
			case "pass":
				if (!o) return K();
				break;
			default: return K();
		}
		return o ? (be(i), {
			state: i,
			fx: u
		}) : (he(i, a, l), i.follow ? (i.phase = "follow", i.turn = i.follow.pending[0]) : _e(i), {
			state: i,
			fx: u
		});
	},
	viewFor(e, t) {
		return {
			public: Se(e),
			private: xe(e, t)
		};
	},
	nextTickIn(e) {
		return [
			"rotate",
			"verify",
			"reveal"
		].includes(e.phase) || e.turn === "$uaps-ai" ? 650 : null;
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => n.score - t.score || (e.solo ? t.rid === "$uaps-ai" ? -1 : +(n.rid === "$uaps-ai") : 0) || n.locatePoints - t.locatePoints || n.photos - t.photos || (t.rid === e.locator ? -1 : +(n.rid === e.locator))), n = t[0], r = t.filter((t) => t.score === n.score && t.locatePoints === n.locatePoints && t.photos === n.photos && (!e.solo || t.rid === n.rid) && (n.rid !== e.locator || t.rid === n.rid)).map((e) => e.rid);
		return {
			phase: "done",
			ranking: t.map((e) => e.rid),
			winner: r,
			scores: Object.fromEntries(t.map((e) => [e.rid, e.score]))
		};
	}
}, Z = {
	luna: "games.searchforuaps.luna",
	hubble: "games.searchforuaps.hubble",
	iss: "games.searchforuaps.iss",
	spy: "games.searchforuaps.spy",
	meteor: "games.searchforuaps.meteor",
	comm: "games.searchforuaps.comm",
	nav: "games.searchforuaps.nav",
	junk: "games.searchforuaps.junk",
	uap: "games.searchforuaps.uap"
}, we = {
	blank: "games.searchforuaps.mBlank",
	charter: "games.searchforuaps.mCharter",
	hitch: "games.searchforuaps.mHitch",
	hurricane: "games.searchforuaps.mHurricane",
	border: "games.searchforuaps.mBorder",
	quantum: "games.searchforuaps.mQuantum",
	advancedDetection: "games.searchforuaps.mAdvancedDetection",
	government: "games.searchforuaps.mGovernment",
	fullMoon: "games.searchforuaps.mFullMoon",
	overcast: "games.searchforuaps.mOvercast",
	atmospheric: "games.searchforuaps.mAtmospheric",
	brainTrust: "games.searchforuaps.mBrainTrust",
	rapidFire: "games.searchforuaps.mRapidFire",
	lunarEclipse: "games.searchforuaps.mLunarEclipse",
	carbon: "games.searchforuaps.mCarbon",
	lowBandwidth: "games.searchforuaps.mLowBandwidth",
	emp: "games.searchforuaps.mEmp",
	coronal: "games.searchforuaps.mCoronal",
	hadron: "games.searchforuaps.mHadron",
	grant: "games.searchforuaps.mGrant",
	advancedTech: "games.searchforuaps.mAdvancedTech",
	copied: "games.searchforuaps.mCopied",
	group: "games.searchforuaps.mGroup",
	unique: "games.searchforuaps.mUnique"
}, Te = {
	blank: "games.searchforuaps.dBlank",
	charter: "games.searchforuaps.dCharter",
	hitch: "games.searchforuaps.dHitch",
	hurricane: "games.searchforuaps.dHurricane",
	border: "games.searchforuaps.dBorder",
	quantum: "games.searchforuaps.dQuantum",
	advancedDetection: "games.searchforuaps.dAdvancedDetection",
	government: "games.searchforuaps.dGovernment",
	fullMoon: "games.searchforuaps.dFullMoon",
	overcast: "games.searchforuaps.dOvercast",
	atmospheric: "games.searchforuaps.dAtmospheric",
	brainTrust: "games.searchforuaps.dBrainTrust",
	rapidFire: "games.searchforuaps.dRapidFire",
	lunarEclipse: "games.searchforuaps.dLunarEclipse",
	carbon: "games.searchforuaps.dCarbon",
	lowBandwidth: "games.searchforuaps.dLowBandwidth",
	emp: "games.searchforuaps.dEmp",
	coronal: "games.searchforuaps.dCoronal",
	hadron: "games.searchforuaps.dHadron",
	grant: "games.searchforuaps.dGrant",
	advancedTech: "games.searchforuaps.dAdvancedTech",
	copied: "games.searchforuaps.dCopied",
	group: "games.searchforuaps.dGroup",
	unique: "games.searchforuaps.dUnique"
}, Ee = {
	not: "games.searchforuaps.notObject",
	quantity: "games.searchforuaps.fQuantity",
	allOpposite: "games.searchforuaps.fAllOpposite",
	noOppositeSelf: "games.searchforuaps.fNoOppositeSelf",
	sameOrbit: "games.searchforuaps.fSameOrbit",
	differentOrbit: "games.searchforuaps.fDifferentOrbit",
	odd: "games.searchforuaps.fOdd",
	even: "games.searchforuaps.fEven",
	allNext: "games.searchforuaps.fAllNext",
	noNextSelf: "games.searchforuaps.fNoNextSelf",
	noNext: "games.searchforuaps.fNoNext",
	nextOne: "games.searchforuaps.fNextOne",
	someNext: "games.searchforuaps.fSomeNext",
	someBetween: "games.searchforuaps.fSomeBetween",
	between: "games.searchforuaps.fBetween",
	opposite: "games.searchforuaps.fOpposite",
	someOpposite: "games.searchforuaps.fSomeOpposite",
	noOpposite: "games.searchforuaps.fNoOpposite",
	uapNotNext: "games.searchforuaps.fUapNotNext",
	uapNotWithinTwo: "games.searchforuaps.fUapNotWithinTwo",
	uapNotOpposite: "games.searchforuaps.fUapNotOpposite"
}, De = (e, t) => t(Ee[e.kind], {
	object: t(Z[e.object]),
	other: e.other ? t(Z[e.other]) : "",
	n: e.count ?? (e.sector ?? 0) + 1
});
function Oe(e, t) {
	return e.fact ? De(e.fact, t) : e.kind === "locate" ? t(e.success ? "games.searchforuaps.found" : "games.searchforuaps.miss") : e.kind === "start" ? t("games.searchforuaps.notObject", {
		n: e.sectors[0] + 1,
		object: t(Z[e.objects[0]])
	}) : e.kind === "target" ? e.sectors.map((n, r) => t("games.searchforuaps.targetResult", {
		n: n + 1,
		object: t(Z[e.objects[r]])
	})).join(" · ") : `${e.sectors.map((e) => e + 1).join(", ")} — ${e.objects.map((n, r) => t("games.searchforuaps.count", {
		object: t(Z[n]),
		n: e.counts[r]
	})).join(" · ")}`;
}
//#endregion
//#region src/games/searchforuaps/icon-data.ts
var ke = {
	luna: {
		viewBox: "100.374 58.162 15.364 15.233",
		paths: [{
			d: "M111.032 59.300 C110.771 59.162 110.453 59.205 110.243 59.408 C110.031 59.611 109.974 59.928 110.100 60.192 C110.478 60.977 110.669 61.790 110.669 62.606 C110.669 65.701 108.152 68.218 105.056 68.218 C104.164 68.218 103.281 67.988 102.432 67.535 C102.171 67.395 101.854 67.440 101.643 67.644 C101.431 67.847 101.374 68.162 101.500 68.427 C102.676 70.875 105.077 72.395 107.768 72.395 C111.611 72.395 114.738 69.269 114.738 65.426 C114.738 62.869 113.318 60.521 111.032 59.300",
			fill: "#ffcf01",
			stroke: "none",
			strokeWidth: 0,
			fillRule: "nonzero"
		}]
	},
	hubble: {
		viewBox: "99.008 75.847 19.615 16.873",
		paths: [
			{
				d: "M110.957 79.234 C111.068 79.239 111.170 79.282 111.230 79.360 C111.334 79.497 111.270 79.693 111.087 79.798 C108.984 80.999 107.942 81.612 105.873 82.867 C105.694 82.976 106.365 83.082 106.233 82.902 C106.101 82.722 105.218 82.329 105.401 82.224 C107.505 81.024 108.565 80.438 110.703 79.291 C110.783 79.249 110.873 79.230 110.957 79.234",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M113.601 83.246 C113.715 83.233 113.820 83.277 113.875 83.373 C113.959 83.522 113.864 83.632 113.611 83.951 C111.663 85.394 110.792 86.024 108.816 87.424 C108.644 87.546 108.414 87.489 108.301 87.297 C108.189 87.105 108.240 86.855 108.416 86.737 C110.427 85.393 111.426 84.709 113.409 83.322 C113.471 83.278 113.537 83.253 113.601 83.246",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.695 82.386 C108.832 82.385 108.962 82.459 109.028 82.589 C109.124 82.779 109.050 83.021 108.863 83.130 C108.325 83.440 108.055 83.593 107.512 83.897 C107.323 84.004 107.083 83.922 106.978 83.719 C106.873 83.515 106.944 83.269 107.136 83.168 C107.688 82.878 107.962 82.731 108.509 82.434 C108.569 82.401 108.633 82.386 108.695 82.386",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.378 87.564 L107.638 87.141 C107.638 87.141 107.979 86.609 107.962 86.359 C107.941 86.042 107.917 85.733 107.882 85.302 C107.543 84.730 107.374 84.444 107.035 83.874 C106.602 83.591 106.316 83.407 105.987 83.199 C105.823 83.096 105.314 83.357 105.314 83.357 C105.314 83.357 105.207 82.499 105.315 82.298 C105.424 82.098 105.655 82.023 105.835 82.137 C106.501 82.556 106.838 82.774 107.524 83.231 C107.576 83.266 107.620 83.312 107.653 83.367 C108.040 84.020 108.235 84.345 108.622 84.999 C108.655 85.054 108.674 85.115 108.680 85.177 C108.753 86.000 108.784 86.402 108.835 87.188 C108.849 87.401 108.673 87.570 108.446 87.569 C108.423 87.569 108.378 87.564 108.378 87.564",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.728 86.586 C109.537 86.563 109.389 86.422 109.386 86.243 C109.374 85.603 109.363 85.275 109.336 84.607 C108.937 83.928 108.738 83.588 108.340 82.908 C107.773 82.565 107.495 82.400 106.946 82.085 C106.777 81.987 106.731 81.753 106.841 81.558 C106.953 81.362 107.179 81.282 107.351 81.382 C107.934 81.724 108.231 81.903 108.833 82.276 C108.882 82.307 108.924 82.349 108.954 82.400 C109.400 83.161 109.622 83.541 110.069 84.303 C110.099 84.354 110.116 84.412 110.119 84.471 C110.155 85.185 110.169 85.535 110.187 86.219 C110.193 86.420 110.015 86.584 109.793 86.589 C109.771 86.590 109.749 86.589 109.728 86.586",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.801 84.144 C109.905 84.168 110.000 84.230 110.059 84.325 C110.170 84.506 110.107 84.741 109.919 84.848 C109.380 85.159 109.110 85.316 108.574 85.634 C108.388 85.745 108.141 85.677 108.023 85.481 C107.905 85.284 107.962 85.038 108.151 84.932 C108.694 84.628 108.966 84.478 109.512 84.183 C109.602 84.133 109.706 84.122 109.801 84.144",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M113.289 83.784 L113.286 83.784 L113.289 83.784 M110.638 79.328 C110.947 79.218 111.291 79.195 111.642 79.246 C111.921 79.287 112.205 79.375 112.482 79.507 C113.058 79.781 113.547 80.217 113.874 80.767 C114.202 81.317 114.339 81.929 114.279 82.524 C114.214 83.171 113.945 83.731 113.468 84.058 C113.339 83.841 113.257 83.730 113.128 83.514 C113.407 83.335 113.576 82.990 113.616 82.559 C113.661 82.074 113.536 81.557 113.253 81.081 C112.970 80.605 112.563 80.231 112.096 80.004 C111.679 79.803 111.273 79.749 110.960 79.870 C110.832 79.653 110.767 79.544 110.638 79.328",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M100.691 85.667 C100.908 86.018 101.016 86.195 101.233 86.546 C100.990 86.668 100.954 86.981 100.956 87.159 C100.958 87.520 101.105 87.962 101.355 88.369 C101.836 89.149 102.576 89.607 102.971 89.368 C103.188 89.720 103.297 89.896 103.514 90.249 C102.713 90.765 101.438 90.118 100.612 88.779 C100.235 88.168 100.020 87.512 100.014 86.946 C100.008 86.329 100.258 85.869 100.691 85.667",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M100.654 85.681 C100.870 86.033 100.979 86.209 101.195 86.562 C101.425 86.421 101.731 86.546 101.893 86.635 C102.224 86.815 102.558 87.154 102.808 87.561 C103.287 88.343 103.344 89.180 102.931 89.389 C103.147 89.741 103.256 89.918 103.473 90.270 C104.340 89.864 104.373 88.491 103.550 87.149 C103.174 86.537 102.678 86.036 102.162 85.752 C101.599 85.443 101.053 85.423 100.654 85.681",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M100.952 86.359 C100.825 86.347 100.707 86.269 100.646 86.141 C100.551 85.941 100.627 85.691 100.814 85.583 C102.904 84.375 103.954 83.783 106.066 82.620 C106.257 82.515 106.507 82.629 106.626 82.871 C106.744 83.115 106.804 83.218 106.611 83.317 C104.468 84.424 103.283 85.163 101.164 86.315 C101.095 86.352 101.022 86.366 100.952 86.359",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.254 85.830 C108.373 85.836 108.491 85.889 108.571 85.986 C108.712 86.156 108.686 86.399 108.512 86.529 C106.583 87.975 105.541 88.671 103.650 90.167 C103.479 90.302 103.291 90.280 103.119 90.069 C102.950 89.858 102.952 89.582 103.127 89.452 C105.055 88.007 106.028 87.298 107.993 85.904 C108.071 85.849 108.162 85.826 108.254 85.830",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.958 89.426 L111.433 90.764 L116.626 84.780 L115.146 83.799 L109.958 89.426 M111.399 91.713 C111.327 91.701 111.258 91.668 111.202 91.618 L109.134 89.743 C109.056 89.672 109.011 89.574 109.005 89.469 C109.001 89.363 109.038 89.262 109.110 89.184 L114.793 83.018 C114.925 82.876 115.140 82.850 115.301 82.957 L117.434 84.372 C117.529 84.434 117.592 84.535 117.607 84.647 C117.623 84.759 117.588 84.872 117.514 84.958 L111.765 91.584 C111.695 91.664 111.596 91.712 111.491 91.719 C111.460 91.720 111.429 91.719 111.399 91.713",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M101.802 82.043 L102.711 82.862 L107.215 78.474 L106.179 77.782 L101.802 82.043 M102.653 83.790 C102.583 83.778 102.514 83.746 102.458 83.695 L100.963 82.346 C100.882 82.274 100.834 82.170 100.832 82.062 C100.830 81.953 100.873 81.847 100.951 81.772 L105.857 76.995 C105.992 76.866 106.196 76.847 106.352 76.949 L108.058 78.089 C108.158 78.154 108.220 78.262 108.231 78.381 C108.243 78.499 108.200 78.616 108.114 78.699 L102.996 83.684 C102.902 83.776 102.774 83.811 102.653 83.790",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M105.948 82.545 L103.222 80.494 L103.694 79.863 L106.420 81.914 L105.948 82.545",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M113.818 88.416 L110.257 85.837 L110.728 85.205 L114.289 87.784 L113.818 88.416",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M110.402 90.584 C110.358 90.576 110.315 90.556 110.279 90.524 C110.176 90.432 110.166 90.274 110.258 90.171 L115.882 83.848 C115.975 83.745 116.133 83.736 116.236 83.827 C116.340 83.919 116.349 84.078 116.257 84.181 L110.633 90.504 C110.573 90.571 110.485 90.599 110.402 90.584",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M102.015 82.818 C101.978 82.811 101.942 82.794 101.913 82.765 C101.840 82.690 101.842 82.571 101.916 82.499 L106.698 77.817 C106.773 77.744 106.890 77.745 106.964 77.820 C107.037 77.894 107.035 78.013 106.961 78.086 L102.179 82.767 C102.134 82.811 102.072 82.828 102.015 82.818",
				fill: "#329bd6",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			}
		]
	},
	iss: {
		viewBox: "100.455 114.272 15.193 16.381",
		paths: [
			{
				d: "M106.919 124.774 C106.873 124.948 106.707 125.069 106.522 125.052 C106.315 125.034 106.162 124.851 106.180 124.644 L106.561 120.324 C106.579 120.120 106.762 119.963 106.968 119.982 C107.176 120.000 107.329 120.183 107.310 120.390 L106.930 124.710 C106.928 124.732 106.925 124.754 106.919 124.774",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.233 121.137 C107.192 121.292 107.053 121.409 106.884 121.416 L106.086 121.449 C105.880 121.458 105.703 121.296 105.695 121.089 C105.688 120.881 105.847 120.705 106.056 120.697 L106.854 120.665 C107.062 120.656 107.237 120.818 107.245 121.025 C107.247 121.064 107.243 121.101 107.233 121.137",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M106.999 123.926 C106.958 124.081 106.819 124.198 106.650 124.205 L105.852 124.238 C105.645 124.247 105.469 124.085 105.461 123.878 C105.453 123.670 105.614 123.495 105.822 123.486 L106.619 123.454 C106.827 123.445 107.003 123.607 107.011 123.814 C107.013 123.853 107.008 123.890 106.999 123.926",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.956 128.738 L107.206 128.672 L108.309 116.231 L109.058 116.298 L107.956 128.738",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.061 128.535 C109.042 128.607 108.980 128.664 108.900 128.671 L106.775 128.875 C106.673 128.884 106.583 128.810 106.574 128.709 C106.564 128.608 106.638 128.518 106.740 128.508 L108.865 128.304 C108.966 128.295 109.057 128.369 109.066 128.470 C109.068 128.493 109.066 128.515 109.061 128.535",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M110.230 122.169 C110.191 122.317 110.063 122.432 109.903 122.447 L106.516 122.846 C106.309 122.865 106.124 122.715 106.104 122.507 C106.084 122.301 106.236 122.117 106.442 122.096 L109.829 121.698 C110.036 121.678 110.221 121.829 110.241 122.036 C110.245 122.082 110.241 122.127 110.230 122.169",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.582 124.586 C109.536 124.760 109.370 124.881 109.185 124.864 C108.977 124.846 108.824 124.662 108.843 124.456 L109.202 120.434 C109.221 120.226 109.404 120.074 109.610 120.093 C109.818 120.111 109.971 120.293 109.952 120.501 L109.593 124.523 C109.591 124.544 109.587 124.566 109.582 124.586",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.067 128.121 C107.066 128.123 107.066 128.125 107.066 128.127 L106.721 129.349 C106.676 129.510 106.529 129.622 106.362 129.623 L102.411 129.653 C102.264 129.654 102.129 129.568 102.067 129.434 L101.508 128.219 C101.455 128.102 101.465 127.966 101.533 127.859 C101.601 127.751 101.720 127.686 101.848 127.684 L106.701 127.648 C106.819 127.647 106.931 127.703 107.002 127.796 C107.073 127.889 107.097 128.009 107.067 128.121",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M113.726 129.294 C113.716 129.333 113.699 129.370 113.677 129.404 C113.608 129.509 113.491 129.573 113.364 129.574 L108.729 129.604 C108.611 129.605 108.500 129.550 108.428 129.456 C108.356 129.362 108.327 129.246 108.365 129.126 L108.709 127.903 C108.754 127.742 108.901 127.631 109.068 127.629 L112.498 127.602 C112.650 127.601 113.131 127.692 113.190 127.831 L113.709 129.050 C113.742 129.129 113.747 129.214 113.726 129.294",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.158 126.285 C109.139 126.357 109.076 126.414 108.996 126.421 L106.870 126.625 C106.770 126.634 106.680 126.560 106.670 126.459 C106.660 126.359 106.733 126.268 106.836 126.258 L108.962 126.054 C109.062 126.045 109.154 126.119 109.162 126.220 C109.165 126.243 109.162 126.265 109.158 126.285",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.164 125.870 C107.163 125.872 107.163 125.874 107.163 125.876 L106.818 127.098 C106.773 127.259 106.626 127.371 106.459 127.372 L102.508 127.402 C102.361 127.403 102.226 127.317 102.164 127.183 L101.605 125.967 C101.551 125.851 101.561 125.716 101.630 125.608 C101.698 125.500 101.817 125.435 101.945 125.433 L106.798 125.397 C106.916 125.396 107.028 125.452 107.099 125.545 C107.170 125.638 107.194 125.758 107.164 125.870",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M113.822 127.043 C113.812 127.082 113.795 127.119 113.773 127.154 C113.704 127.258 113.587 127.322 113.460 127.323 L108.825 127.353 C108.707 127.354 108.595 127.299 108.524 127.204 C108.452 127.111 108.431 126.989 108.461 126.875 L108.805 125.652 C108.850 125.492 108.997 125.379 109.164 125.378 L112.937 125.351 C113.089 125.350 113.227 125.441 113.286 125.580 L113.805 126.799 C113.838 126.878 113.843 126.963 113.822 127.043",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.859 118.484 C109.840 118.556 109.778 118.613 109.698 118.620 L107.573 118.824 C107.471 118.833 107.381 118.759 107.372 118.658 C107.362 118.557 107.436 118.467 107.538 118.457 L109.663 118.253 C109.764 118.244 109.855 118.318 109.864 118.419 C109.866 118.442 109.864 118.464 109.859 118.484",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.865 118.069 C107.864 118.070 107.864 118.073 107.864 118.075 L107.520 119.297 C107.475 119.458 107.328 119.570 107.160 119.571 L103.209 119.601 C103.062 119.602 102.927 119.516 102.865 119.382 L102.306 118.166 C102.253 118.050 102.262 117.915 102.331 117.807 C102.399 117.699 102.518 117.634 102.646 117.632 L107.499 117.596 C107.617 117.595 107.729 117.651 107.800 117.744 C107.871 117.837 107.895 117.957 107.865 118.069",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M114.524 119.242 C114.514 119.281 114.497 119.318 114.475 119.352 C114.406 119.457 114.289 119.521 114.162 119.522 L109.527 119.552 C109.409 119.553 109.298 119.498 109.226 119.404 C109.154 119.310 109.128 119.186 109.163 119.074 L109.507 117.851 C109.552 117.690 109.699 117.578 109.866 117.577 L113.639 117.550 C113.791 117.549 113.929 117.640 113.988 117.779 L114.507 118.998 C114.540 119.077 114.545 119.162 114.524 119.242",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.963 116.207 C109.944 116.279 109.882 116.336 109.802 116.343 L107.676 116.547 C107.575 116.556 107.485 116.482 107.475 116.381 C107.466 116.280 107.539 116.190 107.641 116.180 L109.767 115.976 C109.868 115.967 109.959 116.041 109.968 116.142 C109.970 116.165 109.968 116.187 109.963 116.207",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.969 115.792 C107.968 115.794 107.968 115.796 107.968 115.798 L107.623 117.020 C107.578 117.181 107.431 117.293 107.264 117.294 L103.313 117.324 C103.166 117.325 103.031 117.239 102.969 117.105 L102.410 115.890 C102.357 115.773 102.367 115.638 102.435 115.530 C102.503 115.422 102.622 115.357 102.750 115.355 L107.603 115.319 C107.721 115.318 107.833 115.374 107.904 115.467 C107.975 115.560 107.999 115.680 107.969 115.792",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M114.627 116.965 C114.617 117.004 114.600 117.041 114.578 117.075 C114.509 117.180 114.392 117.244 114.265 117.245 L109.630 117.275 C109.512 117.276 109.400 117.221 109.329 117.126 C109.257 117.033 109.237 116.908 109.265 116.797 L109.610 115.574 C109.655 115.414 109.802 115.302 109.969 115.300 L113.742 115.273 C113.894 115.272 114.032 115.363 114.091 115.502 L114.610 116.721 C114.643 116.800 114.648 116.885 114.627 116.965",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.806 122.323 C109.823 122.298 109.835 122.255 109.832 122.226 C109.814 122.250 109.803 122.292 109.806 122.323 M110.537 122.464 C110.443 122.819 110.045 123.022 109.649 122.917 C109.252 122.812 109.006 122.438 109.100 122.084 C109.194 121.729 109.593 121.526 109.989 121.631 C110.385 121.737 110.631 122.110 110.537 122.464",
				fill: "#bcbec0",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			}
		]
	},
	spy: {
		viewBox: "100.241 131.553 15.885 15.886",
		paths: [
			{
				d: "M108.183 145.469 C111.476 145.469 114.156 142.790 114.156 139.496 C114.156 136.203 111.476 133.523 108.183 133.523 C104.890 133.523 102.210 136.203 102.210 139.496 C102.210 142.790 104.890 145.469 108.183 145.469 M108.183 132.553 C112.011 132.553 115.126 135.669 115.126 139.496 C115.126 143.325 112.011 146.439 108.183 146.439 C104.355 146.439 101.241 143.325 101.241 139.496 C101.241 135.669 104.355 132.553 108.183 132.553",
				fill: "#ce3950",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.183 143.803 C110.558 143.803 112.490 141.871 112.490 139.497 C112.490 137.121 110.558 135.189 108.183 135.189 C105.809 135.189 103.877 137.121 103.877 139.497 C103.877 141.871 105.809 143.803 108.183 143.803 M108.183 134.247 C111.078 134.247 113.432 136.602 113.432 139.497 C113.432 142.391 111.078 144.745 108.183 144.745 C105.288 144.745 102.934 142.391 102.934 139.497 C102.934 136.602 105.288 134.247 108.183 134.247",
				fill: "#ce3950",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M106.893 138.206 C106.181 138.918 106.181 140.073 106.893 140.786 C107.605 141.499 108.760 141.499 109.473 140.786 C110.186 140.073 110.186 138.918 109.473 138.206 C108.760 137.494 107.605 137.494 106.893 138.206",
				fill: "#ce3950",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M111.915 139.496 C111.361 138.970 109.880 137.734 108.183 137.734 C106.486 137.734 105.005 138.970 104.451 139.496 C105.005 140.022 106.486 141.258 108.183 141.258 C109.880 141.258 111.361 140.022 111.915 139.496 M108.183 137.036 C110.643 137.036 112.584 139.173 112.666 139.263 C112.785 139.396 112.784 139.596 112.666 139.729 C112.584 139.819 110.643 141.955 108.183 141.955 C105.723 141.955 103.782 139.819 103.700 139.729 C103.582 139.596 103.582 139.396 103.700 139.263 C103.782 139.173 105.723 137.036 108.183 137.036",
				fill: "#ce3950",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			}
		]
	},
	meteor: {
		viewBox: "99.724 169.585 16.791 16.097",
		paths: [
			{
				d: "M107.610 183.421 L107.467 183.442 C107.448 183.445 107.430 183.447 107.411 183.447 C107.227 183.447 107.066 183.313 107.038 183.126 C107.007 182.920 107.149 182.728 107.355 182.696 L107.498 182.675 C107.703 182.642 107.896 182.786 107.927 182.992 C107.958 183.198 107.816 183.390 107.610 183.421 M115.322 173.662 C115.160 173.525 114.917 173.535 114.767 173.688 L107.745 180.797 C107.711 180.818 107.665 180.846 107.612 180.880 C106.974 181.276 106.544 181.560 106.372 181.758 C106.123 182.044 106.091 182.330 106.067 182.539 C106.063 182.578 106.059 182.616 106.056 182.642 C106.049 182.661 106.019 182.712 105.998 182.746 C105.913 182.891 105.770 183.134 105.863 183.416 C105.946 183.667 106.091 183.895 106.284 184.076 C106.492 184.271 106.748 184.408 107.027 184.470 C107.050 184.475 107.113 184.508 107.154 184.529 C107.277 184.593 107.450 184.682 107.651 184.682 C107.710 184.682 107.770 184.675 107.832 184.657 C108.072 184.591 108.803 184.388 109.002 183.640 C109.064 183.405 109.348 182.709 109.473 182.408 L115.389 174.214 C115.515 174.041 115.485 173.800 115.322 173.662",
				fill: "#f7941e",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M103.035 177.503 C102.965 177.622 102.839 177.689 102.710 177.689 C102.644 177.689 102.579 177.672 102.518 177.636 L102.473 177.608 C102.293 177.503 102.233 177.272 102.339 177.093 C102.445 176.912 102.677 176.853 102.856 176.959 L102.902 176.986 C103.082 177.093 103.141 177.323 103.035 177.503 M108.874 171.574 C108.727 171.429 108.495 171.416 108.333 171.545 L103.412 175.439 C103.114 175.575 102.430 175.878 102.198 175.948 C101.457 176.170 101.277 176.906 101.216 177.157 C101.149 177.430 101.280 177.666 101.367 177.822 C101.390 177.863 101.424 177.924 101.430 177.948 C101.501 178.223 101.645 178.476 101.847 178.677 C102.034 178.865 102.267 179.003 102.519 179.078 C102.579 179.096 102.636 179.103 102.690 179.103 C102.900 179.103 103.072 178.993 103.185 178.922 C103.218 178.901 103.269 178.869 103.275 178.865 C103.313 178.858 103.352 178.852 103.390 178.847 C103.598 178.817 103.883 178.776 104.161 178.518 C104.354 178.339 104.626 177.900 105.001 177.250 C105.038 177.186 105.069 177.133 105.090 177.097 L108.912 172.114 C109.037 171.950 109.021 171.719 108.874 171.574",
				fill: "#f7941e",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M103.064 182.979 L102.893 183.192 C102.819 183.285 102.709 183.334 102.598 183.334 C102.516 183.334 102.432 183.307 102.363 183.251 C102.200 183.121 102.174 182.884 102.304 182.721 L102.475 182.508 C102.605 182.345 102.843 182.318 103.005 182.449 C103.168 182.579 103.194 182.816 103.064 182.979 M113.764 170.728 C113.603 170.585 113.360 170.590 113.206 170.739 L103.450 180.222 C103.076 180.391 102.236 180.764 101.945 180.851 C101.082 181.111 100.869 181.980 100.797 182.278 C100.724 182.578 100.869 182.839 100.975 183.028 C101.010 183.092 101.053 183.170 101.062 183.207 C101.145 183.531 101.315 183.828 101.552 184.065 C101.772 184.285 102.045 184.448 102.342 184.536 C102.406 184.555 102.467 184.563 102.526 184.563 C102.756 184.563 102.949 184.441 103.087 184.354 C103.135 184.324 103.207 184.277 103.231 184.270 C103.279 184.260 103.329 184.254 103.378 184.247 C103.623 184.212 103.958 184.164 104.280 183.865 C104.507 183.654 104.837 183.121 105.295 182.328 C105.345 182.243 105.385 182.172 105.413 182.126 L113.814 171.284 C113.946 171.114 113.924 170.871 113.764 170.728",
				fill: "#f7941e",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			}
		]
	},
	comm: {
		viewBox: "99.365 224.580 17.672 15.090",
		paths: [
			{
				d: "M108.200 230.955 C107.956 230.955 107.710 231.028 107.497 231.181 C107.235 231.370 107.062 231.649 107.010 231.967 C106.957 232.286 107.032 232.605 107.221 232.867 C107.409 233.129 107.688 233.303 108.006 233.355 C108.326 233.408 108.645 233.332 108.906 233.144 C109.169 232.955 109.341 232.677 109.393 232.358 C109.446 232.040 109.371 231.720 109.183 231.458 L109.182 231.458 C108.947 231.130 108.576 230.955 108.200 230.955 M108.205 234.422 C107.501 234.422 106.807 234.096 106.366 233.481 C106.013 232.991 105.873 232.393 105.971 231.797 C106.069 231.202 106.392 230.679 106.883 230.327 C107.895 229.600 109.311 229.832 110.037 230.844 C110.390 231.334 110.530 231.932 110.432 232.528 C110.334 233.124 110.010 233.647 109.520 233.999 C109.122 234.285 108.661 234.422 108.205 234.422",
				fill: "#509883",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M110.433 236.686 C110.261 236.686 110.092 236.602 109.991 236.447 C109.833 236.203 109.902 235.877 110.146 235.719 C111.225 235.017 111.927 233.979 112.120 232.797 C112.303 231.674 111.999 230.546 111.264 229.619 C110.953 229.227 110.576 228.886 110.145 228.606 C109.901 228.447 109.832 228.121 109.991 227.877 C110.149 227.634 110.475 227.564 110.719 227.723 C111.245 228.066 111.706 228.484 112.088 228.965 C113.010 230.127 113.390 231.548 113.158 232.967 C112.917 234.445 112.051 235.735 110.719 236.601 C110.631 236.659 110.531 236.686 110.433 236.686",
				fill: "#509883",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M111.937 238.670 C111.765 238.670 111.596 238.586 111.495 238.431 C111.337 238.187 111.406 237.861 111.650 237.703 C113.301 236.628 114.374 235.039 114.669 233.227 C114.951 231.501 114.485 229.768 113.357 228.347 C112.817 227.666 112.152 227.089 111.383 226.633 C111.132 226.485 111.049 226.162 111.198 225.912 C111.346 225.662 111.668 225.580 111.919 225.727 C112.800 226.249 113.561 226.910 114.183 227.693 C115.497 229.349 116.038 231.374 115.709 233.397 C115.364 235.505 114.127 237.347 112.224 238.585 C112.135 238.642 112.035 238.670 111.937 238.670",
				fill: "#509883",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.220 232.867 C107.409 233.129 107.688 233.302 108.007 233.354 C108.326 233.408 108.645 233.331 108.906 233.143 C109.168 232.955 109.341 232.676 109.395 232.358 C109.445 232.040 109.371 231.719 109.183 231.458 C108.793 230.918 108.037 230.792 107.497 231.181 C106.956 231.570 106.832 232.326 107.220 232.867 M108.205 234.422 C107.501 234.422 106.807 234.095 106.367 233.481 L106.365 233.481 C105.639 232.468 105.870 231.054 106.882 230.326 C107.896 229.599 109.312 229.832 110.038 230.843 C110.390 231.334 110.529 231.932 110.432 232.528 C110.334 233.124 110.010 233.646 109.520 233.998 C109.121 234.285 108.661 234.422 108.205 234.422",
				fill: "#509883",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M105.972 236.686 C105.874 236.686 105.774 236.659 105.686 236.601 C105.159 236.260 104.699 235.841 104.316 235.359 C103.394 234.198 103.015 232.777 103.246 231.358 C103.487 229.880 104.354 228.589 105.685 227.723 C105.928 227.565 106.254 227.634 106.413 227.877 C106.572 228.121 106.502 228.447 106.259 228.606 C105.179 229.308 104.477 230.346 104.285 231.527 C104.101 232.650 104.405 233.778 105.140 234.705 C105.452 235.098 105.828 235.439 106.259 235.719 C106.502 235.877 106.572 236.203 106.414 236.447 C106.313 236.602 106.144 236.686 105.972 236.686",
				fill: "#509883",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M104.753 238.670 C104.662 238.670 104.570 238.646 104.485 238.597 C103.605 238.075 102.843 237.414 102.221 236.631 C100.907 234.976 100.365 232.950 100.695 230.928 C101.040 228.819 102.277 226.977 104.180 225.739 C104.424 225.580 104.751 225.650 104.909 225.893 C105.067 226.137 104.998 226.463 104.754 226.621 C103.103 227.696 102.030 229.285 101.734 231.098 C101.452 232.823 101.919 234.556 103.046 235.977 C103.587 236.659 104.252 237.235 105.022 237.691 C105.272 237.839 105.355 238.162 105.206 238.412 C105.108 238.578 104.933 238.670 104.753 238.670",
				fill: "#509883",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			}
		]
	},
	nav: {
		viewBox: "98.691 244.364 19.847 19.846",
		paths: [
			{
				d: "M108.615 252.574 C107.670 252.574 106.902 253.342 106.902 254.287 C106.902 255.231 107.670 256.001 108.615 256.001 C109.560 256.001 110.328 255.231 110.328 254.287 C110.328 253.342 109.560 252.574 108.615 252.574 M108.615 257.108 C107.060 257.108 105.795 255.843 105.795 254.287 C105.795 252.732 107.060 251.467 108.615 251.467 C110.170 251.467 111.435 252.732 111.435 254.287 C111.435 255.843 110.170 257.108 108.615 257.108",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.615 249.624 C106.044 249.624 103.952 251.716 103.952 254.287 C103.952 256.859 106.044 258.951 108.615 258.951 C111.186 258.951 113.278 256.859 113.278 254.287 C113.278 251.716 111.186 249.624 108.615 249.624 M108.615 259.975 C105.479 259.975 102.927 257.423 102.927 254.287 C102.927 251.151 105.479 248.599 108.615 248.599 C111.751 248.599 114.303 251.151 114.303 254.287 C114.303 257.423 111.751 259.975 108.615 259.975",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.837 252.027 L108.616 245.741 L109.394 252.027 L107.837 252.027",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.889 252.292 L112.003 250.900 L110.611 253.014 L109.889 252.292",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.837 252.027 L108.616 245.741 L109.394 252.027 L107.837 252.027",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.264 251.650 L108.967 251.650 L108.615 248.812 L108.264 251.650 M109.394 252.405 L107.837 252.405 C107.728 252.405 107.626 252.359 107.554 252.278 C107.482 252.196 107.449 252.088 107.462 251.981 L108.241 245.695 C108.265 245.505 108.425 245.364 108.615 245.364 C108.806 245.364 108.967 245.505 108.990 245.695 L109.769 251.981 C109.782 252.088 109.749 252.196 109.677 252.278 C109.605 252.359 109.503 252.405 109.394 252.405",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M110.875 253.508 L117.161 254.287 L110.875 255.065 L110.875 253.508",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M111.253 253.935 L111.253 254.639 L114.092 254.286 L111.253 253.935 M110.875 255.443 C110.784 255.443 110.695 255.410 110.626 255.349 C110.544 255.277 110.498 255.174 110.498 255.066 L110.498 253.508 C110.498 253.399 110.544 253.297 110.626 253.225 C110.707 253.153 110.814 253.121 110.922 253.133 L117.208 253.912 C117.398 253.936 117.539 254.096 117.539 254.286 C117.539 254.477 117.398 254.638 117.208 254.661 L110.922 255.441 C110.907 255.442 110.891 255.443 110.875 255.443",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M110.610 255.560 L112.002 257.674 L109.888 256.282 L110.610 255.560",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.394 256.547 L108.615 262.833 L107.837 256.547 L109.394 256.547",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.264 256.924 L108.615 259.762 L108.967 256.924 L108.264 256.924 M108.615 263.210 C108.425 263.210 108.265 263.069 108.241 262.879 L107.462 256.593 C107.449 256.486 107.482 256.378 107.554 256.296 C107.626 256.215 107.728 256.169 107.837 256.169 L109.394 256.169 C109.503 256.169 109.605 256.215 109.677 256.296 C109.749 256.378 109.782 256.486 109.769 256.593 L108.990 262.879 C108.967 263.069 108.806 263.210 108.615 263.210",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M107.342 256.282 L105.228 257.674 L106.620 255.560 L107.342 256.282",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M106.355 255.066 L100.069 254.287 L106.355 253.509 L106.355 255.066",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M103.139 254.287 L105.978 254.639 L105.978 253.936 L103.139 254.287 M106.355 255.443 C106.339 255.443 106.324 255.443 106.309 255.441 L100.022 254.662 C99.833 254.638 99.691 254.478 99.691 254.287 C99.691 254.096 99.833 253.936 100.022 253.912 L106.309 253.134 C106.416 253.122 106.523 253.154 106.605 253.225 C106.686 253.297 106.732 253.400 106.732 253.508 L106.732 255.066 C106.732 255.174 106.686 255.277 106.605 255.349 C106.535 255.411 106.446 255.443 106.355 255.443",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M106.620 253.014 L105.228 250.900 L107.342 252.292 L106.620 253.014",
				fill: "#7e67ad",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			}
		]
	},
	junk: {
		viewBox: "99.562 265.681 17.314 15.801",
		paths: [
			{
				d: "M108.079 273.253 L107.530 272.465 L107.309 273.451 L106.942 274.135 L107.897 274.057 L108.723 274.625 L109.155 273.285 L108.079 273.253",
				fill: "#94785d",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M106.735 277.583 L101.303 280.098 L100.562 275.237 L102.322 275.089 L101.711 273.635 L105.432 272.841 L106.735 277.583",
				fill: "#94785d",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M111.949 274.554 L110.259 276.776 L114.855 279.015 L114.298 276.535 L115.876 274.053 L112.044 272.321 L111.949 274.554",
				fill: "#94785d",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M109.473 271.380 L108.140 269.761 L108.084 267.726 C108.081 267.617 108.148 267.519 108.249 267.482 L110.427 266.681 L110.632 268.284 C110.663 268.520 110.777 268.737 110.955 268.895 L111.841 269.682 C111.971 269.798 111.949 270.008 111.796 270.093 L109.473 271.380",
				fill: "#94785d",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M114.388 269.691 L115.090 271.501 L113.276 270.822 L114.388 269.691",
				fill: "#94785d",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M104.387 267.527 L103.251 267.991 L102.838 269.691 L104.717 271.501 L104.901 269.691 L106.425 269.030 L104.387 267.527",
				fill: "#94785d",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.443 277.669 C108.522 277.560 108.672 277.531 108.786 277.604 L110.679 278.809 L109.719 278.992 C109.644 279.006 109.578 279.054 109.543 279.122 L108.912 280.306 C108.841 280.439 108.670 280.482 108.545 280.398 L107.363 279.605 C107.244 279.524 107.215 279.360 107.299 279.243 L108.443 277.669",
				fill: "#94785d",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			}
		]
	},
	uap: {
		viewBox: "99.638 284.494 17.093 17.092",
		paths: [
			{
				d: "M108.821 294.096 L108.821 294.589 C108.821 295.067 108.494 295.300 108.169 295.300 C107.842 295.300 107.517 295.067 107.517 294.589 L107.517 293.480 L109.922 290.621 L109.922 289.772 C109.458 289.485 108.919 289.307 108.328 289.307 C107.740 289.307 106.912 289.527 106.184 289.978 C106.046 290.060 105.920 290.101 105.795 290.101 C105.418 290.101 105.167 289.772 105.167 289.403 C105.167 289.184 105.280 288.951 105.532 288.774 C106.309 288.253 107.224 287.885 108.328 287.885 C109.470 287.885 110.449 288.363 111.226 289.006 L111.226 291.236 L108.821 294.096",
				fill: "#57b94f",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.185 286.548 C104.606 286.548 101.693 289.460 101.693 293.040 C101.693 296.620 104.606 299.531 108.185 299.531 C111.764 299.531 114.677 296.620 114.677 293.040 C114.677 289.460 111.764 286.548 108.185 286.548 M108.185 300.586 C104.024 300.586 100.638 297.201 100.638 293.040 C100.638 288.879 104.024 285.494 108.185 285.494 C112.346 285.494 115.731 288.879 115.731 293.040 C115.731 297.201 112.346 300.586 108.185 300.586",
				fill: "#57b94f",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			},
			{
				d: "M108.458 298.439 L107.943 298.439 C107.492 298.439 107.291 298.220 107.291 297.727 L107.291 297.180 C107.291 296.687 107.492 296.468 107.943 296.468 L108.458 296.468 C108.910 296.468 109.110 296.687 109.110 297.180 L109.110 297.727 C109.110 298.220 108.910 298.439 108.458 298.439",
				fill: "#57b94f",
				stroke: "none",
				strokeWidth: 0,
				fillRule: "nonzero"
			}
		]
	}
};
//#endregion
//#region src/games/searchforuaps/art.tsx
function Q({ object: e, size: t = 32 }) {
	let n = ke[e];
	return /* @__PURE__ */ h("svg", {
		width: t,
		height: t,
		viewBox: n.viewBox,
		"aria-hidden": "true",
		children: n.paths.map((e, t) => /* @__PURE__ */ h("path", { ...e }, t))
	});
}
function Ae({ object: e, verified: t = !1 }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 64 48",
		width: "100%",
		height: "100%",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("rect", {
				x: "1",
				y: "1",
				width: "62",
				height: "46",
				rx: "3",
				fill: "#0c1834",
				stroke: "#a7b8d2",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M7 16V7H17M47 7H57V16M57 32V41H47M17 41H7V32",
				fill: "none",
				stroke: t ? "#b9d8a2" : "#d5dded",
				strokeWidth: "2"
			}),
			e ? /* @__PURE__ */ h("svg", {
				x: "15",
				y: "7",
				width: "34",
				height: "34",
				viewBox: ke[e].viewBox,
				children: ke[e].paths.map((e, t) => /* @__PURE__ */ h("path", { ...e }, t))
			}) : /* @__PURE__ */ g("g", {
				fill: "none",
				stroke: "#d7dfe7",
				strokeWidth: "2",
				children: [/* @__PURE__ */ h("path", { d: "M19 17H24L27 12H37L40 17H45V35H19Z" }), /* @__PURE__ */ h("circle", {
					cx: "32",
					cy: "25",
					r: "6"
				})]
			})
		]
	});
}
function je() {
	return /* @__PURE__ */ g("g", { children: [
		/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("radialGradient", {
			id: "uaps-earth",
			children: [
				/* @__PURE__ */ h("stop", { stopColor: "#43818b" }),
				/* @__PURE__ */ h("stop", {
					offset: ".75",
					stopColor: "#174f70"
				}),
				/* @__PURE__ */ h("stop", {
					offset: "1",
					stopColor: "#092237"
				})
			]
		}) }),
		/* @__PURE__ */ h("circle", {
			cx: "300",
			cy: "300",
			r: "102",
			fill: "url(#uaps-earth)",
			stroke: "#91bac7",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ h("path", {
			d: "M222 270L229 249L251 231L273 227L281 235L279 249L270 258L268 277L255 286L260 296L249 299L238 285L226 280ZM264 301L277 300L291 314L289 328L281 336L277 358L266 370L261 354L263 338L254 323Z",
			fill: "#72947c",
			stroke: "#8eaa8c",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ h("path", {
			d: "M303 240L315 227L342 231L360 242L362 254L376 269L369 283L354 278L346 284L333 271L323 277L312 268L300 263L295 249ZM307 277L323 276L340 289L336 307L325 322L315 343L303 332L302 310L292 298ZM350 332L372 328L381 344L369 357L347 350Z",
			fill: "#72947c",
			stroke: "#8eaa8c",
			strokeWidth: "1.3"
		}),
		/* @__PURE__ */ h("path", {
			d: "M205 295Q300 335 395 295M215 266Q300 291 385 266M218 338Q300 362 382 338M300 198Q246 300 300 402M300 198Q354 300 300 402",
			stroke: "#d1e4dc",
			strokeWidth: ".8",
			fill: "none",
			opacity: ".23"
		}),
		/* @__PURE__ */ h("circle", {
			cx: "300",
			cy: "300",
			r: "106",
			fill: "none",
			stroke: "#8ba8b2",
			strokeOpacity: ".3",
			strokeWidth: "5"
		})
	] });
}
//#endregion
//#region src/games/searchforuaps/board.tsx
function $(e, t) {
	let n = t * Math.PI / 180;
	return {
		x: 300 + e * Math.sin(n),
		y: 300 - e * Math.cos(n)
	};
}
function Me(e, t, n, r) {
	let i = $(t, n), a = $(t, r), o = $(e, r), s = $(e, n);
	return `M${i.x} ${i.y} A${t} ${t} 0 ${+(r - n > 180)} 1 ${a.x} ${a.y} L${o.x} ${o.y} A${e} ${e} 0 ${+(r - n > 180)} 0 ${s.x} ${s.y}Z`;
}
function Ne({ object: e, x: t, y: n, size: r = 34 }) {
	let i = ke[e];
	return /* @__PURE__ */ h("svg", {
		x: t - r / 2,
		y: n - r / 2,
		width: r,
		height: r,
		viewBox: i.viewBox,
		children: i.paths.map((e, t) => /* @__PURE__ */ h("path", { ...e }, t))
	});
}
function Pe({ photo: e, object: t, x: n, y: a }) {
	let o = `uaps-photo:${e.id}`, { hidden: s } = _(o), c = v(), l = i(null);
	return r(() => (c?.registerProbe(o, () => {
		let e = l.current?.getBoundingClientRect();
		return e ? {
			x: e.x,
			y: e.y,
			w: e.width,
			h: e.height
		} : null;
	}), () => c?.registerProbe(o, null)), [o, c]), /* @__PURE__ */ h("g", {
		transform: `translate(${n} ${a})`,
		style: { visibility: s ? "hidden" : void 0 },
		children: /* @__PURE__ */ h("g", {
			className: "uaps-photo-turn",
			style: {
				transform: `rotate(${e.verified ? 0 : -12}deg)`,
				transformOrigin: "24px 18px"
			},
			children: /* @__PURE__ */ h("svg", {
				ref: l,
				width: "48",
				height: "36",
				viewBox: "0 0 64 48",
				className: e.verified ? "uaps-photo-flip" : "",
				children: /* @__PURE__ */ h(Ae, {
					object: t,
					verified: e.verified
				})
			})
		})
	});
}
function Fe({ pub: e, priv: t, members: r = [], selected: i = [], legal: a = [], quadrants: o = [], onSector: s, onQuadrant: c, readOnly: u = !1 }) {
	let d = 360 / e.n, m = (n) => Array.from({ length: e.n }, (r, o) => {
		let s = n * e.n + o, c = (o + .5) * d, l = $(n ? 231 : 151, c), p = $(n ? 263 : 180, c), m = Me(n ? 196 : 111, n ? 277 : 190, o * d + 1, (o + 1) * d - 1), _ = e.photos.filter((e) => e.sector === s), v = t?.myPhotos.filter((e) => e.sector === s) ?? [], y = e.board?.[s] ?? (s === e.luna ? "luna" : void 0);
		return /* @__PURE__ */ g("g", { children: [
			/* @__PURE__ */ h("path", {
				d: m,
				fill: i.includes(s) ? "#244b67" : "#102c40",
				fillOpacity: i.includes(s) ? .95 : .5,
				stroke: i.includes(s) ? "#e5eff0" : "#69828d",
				strokeWidth: i.includes(s) ? 2.4 : .7
			}),
			a.includes(s) && !u && /* @__PURE__ */ h("path", {
				d: m,
				fill: "#e8f0e8",
				fillOpacity: ".07",
				stroke: "#c6e4ed",
				strokeWidth: "1.8",
				strokeDasharray: "7 5",
				className: "uaps-eligible",
				children: /* @__PURE__ */ h("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-24",
					dur: "1s",
					repeatCount: "indefinite"
				})
			}),
			/* @__PURE__ */ h("text", {
				x: p.x,
				y: p.y,
				textAnchor: "middle",
				dominantBaseline: "middle",
				fill: "#dce9eb",
				fontSize: "15",
				fontWeight: "700",
				children: s + 1
			}),
			y && /* @__PURE__ */ h(Ne, {
				object: y,
				x: l.x,
				y: l.y,
				size: 36
			}),
			!y && _.map((e, t) => /* @__PURE__ */ h(Pe, {
				photo: e,
				object: e.object ?? v.find((t) => t.id === e.id)?.object,
				x: l.x - 24 + t % 2 * 7,
				y: l.y - 18 + t % 2 * 5
			}, e.id)),
			!y && _.length === 0 && t && /* @__PURE__ */ h("g", { children: Object.entries(t.notes).filter(([e, t]) => e.startsWith(`${s}:`) && t === 2).slice(0, 1).map(([e]) => /* @__PURE__ */ h(Ne, {
				object: e.split(":")[1],
				x: l.x,
				y: l.y,
				size: 27
			}, e)) }),
			t && Object.entries(t.notes).some(([e, t]) => e.startsWith(`${s}:`) && t === 1) && /* @__PURE__ */ g("text", {
				x: l.x,
				y: l.y + 29,
				textAnchor: "middle",
				fill: "#e5b8ad",
				fontSize: "12",
				children: ["× ", Object.entries(t.notes).filter(([e, t]) => e.startsWith(`${s}:`) && t === 1).length]
			}),
			/* @__PURE__ */ h(f, {
				name: `uaps-sector:${s}`,
				r: {
					x: l.x - 25,
					y: l.y - 20,
					w: 50,
					h: 40
				}
			})
		] }, s);
	}), _ = Array.from({ length: e.n * 2 }, (e, t) => t), v = [...u ? [] : _.map((t) => {
		let n = (t % e.n + .5) * d - (t < e.n ? e.rotation * d : 0), r = $(t < e.n ? 150 : 232, n);
		return {
			key: `s:${t}`,
			rect: {
				x: r.x - 35,
				y: r.y - 35,
				w: 70,
				h: 70
			}
		};
	}), ...u ? [] : o.map((t) => {
		let n = $(63, (t + .5) * 90 - e.rotation * d);
		return {
			key: `q:${t}`,
			rect: {
				x: n.x - 27,
				y: n.y - 25,
				w: 54,
				h: 50
			}
		};
	})];
	return /* @__PURE__ */ g(p, {
		sheetW: 600,
		sheetH: 600,
		fitKey: `uaps:${e.n}`,
		clampToSheet: !0,
		eligible: v,
		highlight: "off",
		readOnly: u,
		onTapEligible: (e) => e.startsWith("s:") ? s?.(Number(e.slice(2))) : c?.(Number(e.slice(2))),
		children: [
			/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("radialGradient", {
				id: "uaps-space",
				children: [/* @__PURE__ */ h("stop", { stopColor: "#16364b" }), /* @__PURE__ */ h("stop", {
					offset: "1",
					stopColor: "#061322"
				})]
			}) }),
			/* @__PURE__ */ h("circle", {
				cx: "300",
				cy: "300",
				r: "298",
				fill: "url(#uaps-space)"
			}),
			Array.from({ length: 110 }, (e, t) => /* @__PURE__ */ h("circle", {
				cx: P(t * 137 + 41, 580) + 10,
				cy: P(t * t * 31 + 47, 580) + 10,
				r: t % 6 == 0 ? 1.1 : .55,
				fill: "#c5e0e4",
				opacity: .15 + t % 4 * .12
			}, t)),
			/* @__PURE__ */ h("circle", {
				cx: "300",
				cy: "300",
				r: "279",
				fill: "none",
				stroke: "#d6e4e5",
				strokeWidth: "2"
			}),
			m(1),
			/* @__PURE__ */ g("g", {
				className: "uaps-inner",
				style: {
					transform: `rotate(${-e.rotation * d}deg)`,
					transformOrigin: "300px 300px"
				},
				children: [
					m(0),
					/* @__PURE__ */ h(je, {}),
					[
						0,
						1,
						2,
						3
					].map((e) => {
						let t = $(65, (e + .5) * 90);
						return /* @__PURE__ */ g("g", { children: [
							/* @__PURE__ */ h("path", {
								d: Me(26, 96, e * 90 + 2, (e + 1) * 90 - 2),
								fill: o.includes(e) ? "#3c6a67" : "#193b48",
								fillOpacity: ".6",
								stroke: "#d9e9e2",
								strokeWidth: ".8"
							}),
							/* @__PURE__ */ h("text", {
								x: t.x,
								y: t.y,
								fill: "#f0f4e6",
								fontSize: "22",
								fontWeight: "700",
								textAnchor: "middle",
								dominantBaseline: "middle",
								children: e + 1
							}),
							/* @__PURE__ */ h(f, {
								name: `uaps-quadrant:${e}`,
								r: {
									x: t.x - 18,
									y: t.y - 18,
									w: 36,
									h: 36
								}
							})
						] }, e);
					})
				]
			}),
			/* @__PURE__ */ h("circle", {
				cx: "300",
				cy: "300",
				r: "192",
				fill: "none",
				stroke: "#d3e1e3",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "300",
				cy: "300",
				r: "110",
				fill: "none",
				stroke: "#d3e1e3",
				strokeWidth: "1.6"
			}),
			e.players.map((t) => {
				let i = e.players.filter((e) => e.quadrant === t.quadrant), a = i.indexOf(t), o = $(88, (t.quadrant + .5) * 90 - e.rotation * d + (a - (i.length - 1) / 2) * 19), s = l[r.find((e) => e.rid === t.rid)?.colorIndex ?? 0].hex;
				return /* @__PURE__ */ g("g", {
					className: "uaps-pawn",
					style: { transform: `translate(${o.x}px,${o.y}px)` },
					children: [
						/* @__PURE__ */ h("circle", {
							r: "11",
							fill: s,
							stroke: "#eef5ee",
							strokeWidth: "1.4"
						}),
						/* @__PURE__ */ h("image", {
							href: n[(r.find((e) => e.rid === t.rid)?.avatar ?? 0) % n.length],
							x: -9,
							y: -9,
							width: 18,
							height: 18,
							preserveAspectRatio: "xMidYMid meet",
							pointerEvents: "none"
						}),
						/* @__PURE__ */ h(f, {
							name: `uaps-researcher:${t.rid}`,
							r: {
								x: -11,
								y: -11,
								w: 22,
								h: 22
							}
						})
					]
				}, t.rid);
			})
		]
	});
}
//#endregion
//#region src/games/searchforuaps/view-player.tsx
var Ie = {
	survey: "games.searchforuaps.survey",
	target: "games.searchforuaps.target",
	photo: "games.searchforuaps.photo",
	analyze: "games.searchforuaps.analyze",
	locate: "games.searchforuaps.locate",
	move: "games.searchforuaps.move",
	note: "games.searchforuaps.note"
}, Le = {
	quadrant: "games.searchforuaps.quadrant",
	inner: "games.searchforuaps.inner",
	outer: "games.searchforuaps.outer",
	stack: "games.searchforuaps.stack",
	sector: "games.searchforuaps.sector"
};
function Re(e) {
	s();
	let t = o(), r = e.public, i = e.private, [f, p] = a("target"), [_, v] = a([]), [y, ee] = a(0), [b, x] = a(["junk"]), [S, te] = a("quadrant"), [C, ne] = a("beginner"), [T, E] = a([
		"junk",
		"junk",
		"junk"
	]), [D, O] = a(0), [re, ie] = a(!1), [ae, k] = a(!1), [oe, A] = a(null), j = r.turn === e.myRid, se = r.players.find((t) => t.rid === e.myRid), P = r.phase === "final", F = r.phase === "prepare", [I, L] = a([]), [z, de] = a(""), fe = `${e.myRid}:${r.turn}:${r.phase}`;
	z !== fe && (z.startsWith(`${e.myRid}:`) || (A(null), E([
		"junk",
		"junk",
		"junk"
	]), x(["junk"])), de(fe), v([]), L([]), O(0), k(!1), P && (p("photo"), x(["hubble"])));
	let B = (n) => e.members.find((e) => e.rid === n)?.name ?? t("games.searchforuaps.ai"), V = se?.quadrant ?? 0, U = r.modifiers[V], W = R(V, r.n, r.rotation), G = W.includes(r.luna), K = U === "emp" || U === "fullMoon" && G, q = U === "atmospheric" || U === "fullMoon" && G, J = ue(r.n), Y = (t) => U !== "overcast" && !I.some((e) => e.sector === t) && !r.photos.some((n) => n.sector === t && (n.verified || n.rid === e.myRid)), pe = j && !F ? f === "move" || f === "analyze" ? [] : f === "locate" || f === "note" ? Array.from({ length: r.n * 2 }, (e, t) => t) : f === "photo" ? (P ? Array.from({ length: r.n * 2 }, (e, t) => t) : W).filter(Y) : f === "target" && !q || f === "survey" && !K ? W : [] : [], me = _;
	f === "survey" && j && (me = S === "quadrant" ? W : S === "inner" ? W.filter((e) => e < r.n) : S === "outer" ? W.filter((e) => e >= r.n) : S === "stack" && _.length ? [_[0], ce(_[0], r.n, r.rotation)] : _);
	let X = (t) => {
		e.send(t), v([]), L([]), O(0), k(!1);
	}, he = (e) => {
		p(e), v([]), L([]), O(0), k(e !== "target" && e !== "move"), x([e === "photo" ? "hubble" : "junk"]);
	}, ge = (e) => {
		(j || f === "note") && (f === "note" || pe.includes(e)) && (v(f === "target" && U === "rapidFire" ? (t) => t.includes(e) ? t.filter((t) => t !== e) : [...t.slice(-1), e] : [e]), [
			"photo",
			"note",
			"locate"
		].includes(f) && k(!0));
	}, _e = f === "photo" ? w : f === "locate" ? M.filter((e) => e !== "uap") : f === "note" ? M : M.filter((e) => e !== "uap" && !(U === "coronal" && [
		"comm",
		"nav",
		"spy"
	].includes(e))), ve = (e) => {
		if (f === "locate") {
			E((t) => t.map((t, n) => n === D ? e : t)), O(Math.min(2, D + 1));
			return;
		}
		x(f === "survey" && U === "grant" ? (t) => t.includes(e) ? t.length > 1 ? t.filter((t) => t !== e) : t : [...t.slice(-1), e] : [e]);
	}, ye = f === "locate" ? 5 : f === "photo" ? 1 : f === "move" ? H(V, y, r.modifiers) ?? 0 : f === "target" ? _.length === 2 ? 6 : U === "carbon" || U === "brainTrust" && r.players.filter((e) => e.quadrant === V).length > 1 ? 3 : U === "lunarEclipse" && G ? 2 : 4 : f === "survey" ? (U === "advancedTech" || S === "quadrant" ? 1 : S === "sector" ? 3 : 2) + +(U === "lowBandwidth") : 0, be = _.length > 0 && Y(_[0]) && w.includes(b[0]) && i.used[w.indexOf(b[0])] + I.filter((e) => e.object === b[0]).length < J[w.indexOf(b[0])], xe = j && (F || f === "move" && y !== V && H(V, y, r.modifiers) !== null || f === "target" && !q && _.length > 0 || f === "survey" && !K && (S === "quadrant" || S === "inner" || S === "outer" || _.length > 0) || f === "photo" && (P ? I.length > 0 : be) || f === "locate" && _.length > 0), Se = () => {
		if (F) {
			X({
				type: "prepare",
				quadrant: y,
				difficulty: C
			});
			return;
		}
		switch (f) {
			case "move":
				X({
					type: "move",
					quadrant: y
				});
				break;
			case "target":
				X({
					type: "target",
					sectors: _
				});
				break;
			case "survey":
				X({
					type: "survey",
					scope: S,
					sector: _[0] ?? W[0],
					objects: b
				});
				break;
			case "photo":
				X({
					type: "photo",
					entries: P ? I : [{
						sector: _[0],
						object: b[0]
					}]
				});
				break;
			case "locate": X({
				type: "locate",
				sector: _[0],
				neighbors: T
			});
		}
	}, Ce = F ? t("games.searchforuaps.prepare") : r.phase === "rotate" ? t("games.searchforuaps.rotating") : ["verify", "reveal"].includes(r.phase) ? t("games.searchforuaps.verifying") : r.phase === "follow" ? t("games.searchforuaps.follow") : j ? t(P ? "games.searchforuaps.final" : "games.searchforuaps.yourTurn") : t("games.searchforuaps.waiting", { name: B(r.turn ?? "") }), Ee = /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ g("div", {
			className: "uaps-context-title",
			children: [/* @__PURE__ */ h("h2", { children: t(F ? "games.searchforuaps.prepare" : Ie[f]) }), /* @__PURE__ */ h("button", {
				onClick: () => k(!1),
				"aria-label": t("games.searchforuaps.close"),
				children: "×"
			})]
		}),
		F ? /* @__PURE__ */ h("div", {
			className: "uaps-choices",
			children: [
				"beginner",
				"experienced",
				"genius"
			].map((e) => /* @__PURE__ */ h("button", {
				"aria-pressed": C === e,
				onClick: () => ne(e),
				children: t(e === "beginner" ? "games.searchforuaps.beginner" : e === "experienced" ? "games.searchforuaps.experienced" : "games.searchforuaps.genius")
			}, e))
		}) : f === "analyze" ? /* @__PURE__ */ h("div", {
			className: "uaps-topics",
			children: r.topics.map((e, n) => {
				let a = [
					"comm",
					"comm",
					"nav",
					"nav",
					"spy",
					"spy"
				][n], o = r.photos.some((e) => e.verified && e.object === a), s = i.analyzed.includes(n);
				return /* @__PURE__ */ g("button", {
					disabled: !(j && !P && U !== "government" && (o || U === "advancedDetection") && !s),
					onClick: () => X({
						type: "analyze",
						topic: n
					}),
					className: "uaps-topic",
					children: [
						/* @__PURE__ */ h("b", { children: String.fromCharCode(65 + n) }),
						/* @__PURE__ */ h(Q, { object: a }),
						/* @__PURE__ */ g("span", { children: [e.map((e) => t(Z[e])).join(" · ") || t("games.searchforuaps.locked"), /* @__PURE__ */ h("small", { children: s ? t("games.searchforuaps.learned") : t("games.searchforuaps.cost", { n: (n < 4 ? 1 : 2) + +!o }) })] })
					]
				}, n);
			})
		}) : /* @__PURE__ */ g(m, { children: [
			f === "survey" && /* @__PURE__ */ h("div", {
				className: "uaps-choices",
				children: Object.keys(Le).map((e) => /* @__PURE__ */ h("button", {
					"aria-pressed": S === e,
					onClick: () => te(e),
					children: t(Le[e])
				}, e))
			}),
			f === "locate" && _.length > 0 && /* @__PURE__ */ h("div", {
				className: "uaps-choices",
				children: le(_[0], r.n, r.rotation).map((e, t) => /* @__PURE__ */ g("button", {
					"aria-pressed": D === t,
					onClick: () => O(t),
					children: [e + 1, /* @__PURE__ */ h(Q, {
						object: T[t],
						size: 22
					})]
				}, e))
			}),
			[
				"survey",
				"photo",
				"note",
				"locate"
			].includes(f) && /* @__PURE__ */ h("div", {
				className: "uaps-palette",
				children: _e.map((e) => {
					let n = w.indexOf(e), r = f === "photo" ? J[n] - i.used[n] - I.filter((t) => t.object === e).length : null;
					return /* @__PURE__ */ g("button", {
						disabled: r !== null && r <= 0,
						"aria-pressed": f === "locate" ? T[D] === e : b.includes(e),
						onClick: () => ve(e),
						children: [
							/* @__PURE__ */ h(Q, { object: e }),
							/* @__PURE__ */ h("span", { children: t(Z[e]) }),
							r !== null && /* @__PURE__ */ g("small", { children: [
								r,
								" · ",
								N[e]
							] })
						]
					}, e);
				})
			}),
			f === "photo" && P && /* @__PURE__ */ g("div", {
				className: "uaps-photo-cart",
				children: [
					/* @__PURE__ */ h("p", { children: t("games.searchforuaps.photoCapacity", { n: r.finalPhotos }) }),
					I.map((e) => /* @__PURE__ */ g("button", {
						onClick: () => L((t) => t.filter((t) => t.sector !== e.sector)),
						children: [
							e.sector + 1,
							" · ",
							t(Z[e.object]),
							" ×"
						]
					}, e.sector)),
					/* @__PURE__ */ h("button", {
						disabled: !be || I.length >= r.finalPhotos,
						onClick: () => {
							L((e) => [...e, {
								sector: _[0],
								object: b[0]
							}]), v([]), k(!1);
						},
						children: t("games.searchforuaps.addPhoto")
					})
				]
			}),
			f === "note" && /* @__PURE__ */ h("div", {
				className: "uaps-choices",
				children: [
					1,
					2,
					0
				].map((n) => /* @__PURE__ */ h("button", {
					disabled: _.length === 0,
					onClick: () => e.send({
						type: "note",
						sector: _[0],
						object: b[0],
						mark: n
					}),
					children: t(n === 1 ? "games.searchforuaps.exclude" : n === 2 ? "games.searchforuaps.certain" : "games.searchforuaps.clear")
				}, n))
			}),
			f === "note" && _.length > 0 && /* @__PURE__ */ h("div", {
				className: "uaps-mark-list",
				children: Object.entries(i?.notes ?? {}).filter(([e, t]) => e.startsWith(`${_[0]}:`) && t > 0).map(([e, n]) => /* @__PURE__ */ g("span", { children: [
					/* @__PURE__ */ h(Q, {
						object: e.split(":")[1],
						size: 22
					}),
					t(Z[e.split(":")[1]]),
					" · ",
					t(n === 1 ? "games.searchforuaps.exclude" : "games.searchforuaps.certain")
				] }, e))
			})
		] }),
		/* @__PURE__ */ g("p", {
			className: "uaps-current-mod",
			children: [
				/* @__PURE__ */ h("strong", { children: t(we[U]) }),
				" ",
				t(Te[U])
			]
		})
	] }), De = /* @__PURE__ */ g("div", {
		className: "uaps-notes-content",
		children: [
			/* @__PURE__ */ h("div", {
				className: "uaps-mod-list",
				children: r.modifiers.map((e, n) => /* @__PURE__ */ g("details", { children: [/* @__PURE__ */ g("summary", { children: [
					n + 1,
					" · ",
					t(we[e])
				] }), /* @__PURE__ */ h("p", { children: t(Te[e]) })] }, n))
			}),
			/* @__PURE__ */ h("ol", {
				className: "uaps-clues",
				children: i?.clues.map((e, n) => /* @__PURE__ */ g("li", { children: [/* @__PURE__ */ g("small", { children: [
					e.time,
					" · ",
					e.kind === "start" ? t("games.searchforuaps.startInfo") : e.kind === "report" ? t("games.searchforuaps.report") : e.kind === "analyze" ? String.fromCharCode(65 + (e.topic ?? 0)) : e.sectors.map((e) => e + 1).join(", ")
				] }), /* @__PURE__ */ h("span", { children: Oe(e, t) })] }, n))
			}),
			/* @__PURE__ */ h("div", {
				className: "uaps-mark-list",
				children: Object.entries(i?.notes ?? {}).filter(([, e]) => e > 0).map(([e, n]) => /* @__PURE__ */ g("span", { children: [
					Number(e.split(":")[0]) + 1,
					" · ",
					/* @__PURE__ */ h(Q, {
						object: e.split(":")[1],
						size: 20
					}),
					t(Z[e.split(":")[1]]),
					" · ",
					t(n === 1 ? "games.searchforuaps.exclude" : "games.searchforuaps.certain")
				] }, e))
			}),
			/* @__PURE__ */ g("details", {
				className: "uaps-public-log",
				children: [/* @__PURE__ */ h("summary", { children: t("games.searchforuaps.publicActions") }), /* @__PURE__ */ h("ol", { children: r.history.map((e, n) => /* @__PURE__ */ g("li", { children: [
					B(e.rid),
					" · ",
					e.time,
					" · ",
					t({
						survey: "games.searchforuaps.survey",
						target: "games.searchforuaps.target",
						photo: "games.searchforuaps.photo",
						analyze: "games.searchforuaps.analyze",
						locate: "games.searchforuaps.locate",
						move: "games.searchforuaps.move",
						follow: "games.searchforuaps.yes",
						decline: "games.searchforuaps.decline",
						verify: "games.searchforuaps.verifyAction"
					}[e.kind] ?? "games.searchforuaps.note"),
					e.sectors.length > 0 && ` · ${e.kind === "move" ? e.sectors.map((e) => t("games.searchforuaps.quadrantLabel", { n: e + 1 })).join(" → ") : e.sectors.map((e) => e + 1).join(", ")}`,
					e.objects.length > 0 && ` · ${e.objects.map((e) => t(Z[e])).join(", ")}`,
					e.success !== void 0 && ` · ${t(e.kind === "verify" ? e.success ? "games.searchforuaps.verified" : "games.searchforuaps.incorrect" : e.success ? "games.searchforuaps.found" : "games.searchforuaps.miss")}`
				] }, n)) })]
			}),
			/* @__PURE__ */ g("label", {
				className: "uaps-memo",
				children: [t("games.searchforuaps.memo"), /* @__PURE__ */ h("textarea", {
					value: oe ?? i?.memo ?? "",
					maxLength: 2400,
					onChange: (e) => A(e.target.value)
				})]
			}),
			/* @__PURE__ */ h("button", {
				className: "uaps-primary",
				onClick: () => {
					e.send({
						type: "memo",
						text: oe ?? i?.memo ?? ""
					}), A(null);
				},
				children: t("games.searchforuaps.saveMemo")
			})
		]
	});
	return /* @__PURE__ */ g(u, {
		adaptive: !0,
		scroll: !1,
		className: "uaps-game",
		banner: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(d, {
			text: Ce,
			tone: j ? "accent" : "info",
			accent: "#37644d"
		}), /* @__PURE__ */ h("div", {
			className: "uaps-researchers",
			children: r.players.map((t) => {
				let i = e.members.find((e) => e.rid === t.rid), a = l[i?.colorIndex ?? 0].hex;
				return /* @__PURE__ */ g("div", {
					className: r.turn === t.rid ? "uaps-researcher is-active" : "uaps-researcher",
					style: { borderColor: a },
					children: [
						/* @__PURE__ */ h("b", {
							style: {
								background: a,
								width: 24,
								height: 24,
								borderRadius: "50%"
							},
							children: /* @__PURE__ */ h("img", {
								src: n[(i?.avatar ?? 0) % n.length],
								alt: "",
								draggable: !1,
								style: {
									width: "1.75em",
									height: "1.75em",
									maxWidth: "100%",
									maxHeight: "100%",
									display: "block",
									objectFit: "contain",
									pointerEvents: "none",
									borderRadius: "inherit"
								}
							})
						}),
						/* @__PURE__ */ h("span", { children: B(t.rid) }),
						/* @__PURE__ */ h("strong", { children: t.time }),
						/* @__PURE__ */ g("small", { children: ["Q", t.quadrant + 1] })
					]
				}, t.rid);
			})
		})] }),
		actionsHeight: "uaps-action-height",
		actions: /* @__PURE__ */ g("div", {
			className: "uaps-actions",
			children: [/* @__PURE__ */ g("nav", {
				"aria-label": t("games.searchforuaps.chooseObject"),
				children: [Object.keys(Ie).filter((e) => !P || [
					"photo",
					"locate",
					"note"
				].includes(e)).map((e) => /* @__PURE__ */ h("button", {
					"aria-pressed": f === e,
					disabled: F || !j && e !== "note",
					onClick: () => he(e),
					children: t(Ie[e])
				}, e)), /* @__PURE__ */ h("button", {
					onClick: () => ie(!0),
					children: t("games.searchforuaps.history")
				})]
			}), /* @__PURE__ */ g("div", {
				className: "uaps-commit",
				children: [
					/* @__PURE__ */ g("span", { children: [F || f === "move" ? t("games.searchforuaps.quadrantLabel", { n: y + 1 }) : _.length ? _.map((e) => e + 1).join(" · ") : t("games.searchforuaps.selectSector"), /* @__PURE__ */ h("small", { children: j && f !== "note" && !F && !P ? t("games.searchforuaps.cost", { n: ye }) : "" })] }),
					P && j && /* @__PURE__ */ h("button", {
						onClick: () => X({ type: "pass" }),
						children: t("games.searchforuaps.skip")
					}),
					r.phase === "follow" && j ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
						onClick: () => X({
							type: "follow",
							accept: !1
						}),
						children: t("games.searchforuaps.no")
					}), /* @__PURE__ */ h("button", {
						className: "uaps-primary",
						onClick: () => X({
							type: "follow",
							accept: !0
						}),
						children: t("games.searchforuaps.yes")
					})] }) : /* @__PURE__ */ h("button", {
						className: "uaps-primary",
						disabled: !xe || f === "note" || f === "analyze",
						onClick: Se,
						children: t(F ? "games.searchforuaps.start" : "games.searchforuaps.confirm")
					})
				]
			})]
		}),
		children: [
			/* @__PURE__ */ g("div", {
				className: "uaps-workspace",
				children: [/* @__PURE__ */ g("div", {
					className: "uaps-chart",
					children: [
						/* @__PURE__ */ h(Fe, {
							pub: r,
							priv: i,
							members: e.members,
							selected: me,
							legal: pe,
							quadrants: j && (F || f === "move") ? [
								0,
								1,
								2,
								3
							] : [],
							onSector: ge,
							onQuadrant: (e) => {
								j && (F || f === "move") && ee(e);
							}
						}),
						/* @__PURE__ */ h("div", {
							className: "uaps-selection-label",
							children: _.length > 0 && t("games.searchforuaps.sectorLabel", { n: _[0] + 1 })
						}),
						i?.clues.at(-1) && i.clues.at(-1).kind !== "start" && /* @__PURE__ */ h("div", {
							className: "uaps-latest",
							role: "status",
							children: Oe(i.clues.at(-1), t)
						})
					]
				}), /* @__PURE__ */ g("aside", {
					className: "uaps-desktop",
					children: [
						/* @__PURE__ */ h("div", {
							className: "uaps-context",
							children: Ee
						}),
						/* @__PURE__ */ h("h2", { children: t("games.searchforuaps.history") }),
						De
					]
				})]
			}),
			F && j && /* @__PURE__ */ g("button", {
				className: "uaps-prepare-toggle",
				onClick: () => k((e) => !e),
				children: [
					t("games.searchforuaps.startInfo"),
					" · ",
					t(C === "beginner" ? "games.searchforuaps.beginner" : C === "experienced" ? "games.searchforuaps.experienced" : "games.searchforuaps.genius")
				]
			}),
			/* @__PURE__ */ h("div", {
				className: `uaps-mobile-context ${ae ? "is-open" : ""}`,
				children: Ee
			}),
			/* @__PURE__ */ h(c, {
				open: re,
				onClose: () => ie(!1),
				label: t("games.searchforuaps.notes"),
				title: t("games.searchforuaps.notes"),
				tall: !0,
				children: De
			})
		]
	});
}
//#endregion
//#region src/games/searchforuaps/bot.ts
var ze = (e, t) => {
	let n = W(e, t.rid, t.difficulty);
	return n ? { action: n } : null;
}, Be = {
	uapsPhoto(e, t) {
		let n = e.data, r = t.anchor(`uaps-researcher:${e.rid}`);
		if (!r) return null;
		let i = n.photos.flatMap((e) => {
			let n = t.anchor(`uaps-photo:${e.id}`);
			return n ? [{
				...e,
				to: n
			}] : [];
		});
		return {
			ms: 650,
			hide: t.queued ? [] : i.map((e) => `uaps-photo:${e.id}`),
			node: /* @__PURE__ */ h(m, { children: i.map((e) => /* @__PURE__ */ h(ee, {
				from: {
					...r,
					w: e.to.w,
					h: e.to.h
				},
				to: e.to,
				ms: 600,
				children: /* @__PURE__ */ h("div", {
					style: {
						width: e.to.w,
						height: e.to.h
					},
					children: /* @__PURE__ */ h(Ae, {})
				})
			}, e.id)) })
		};
	},
	uapsScan(e, t) {
		let n = e.data;
		return {
			ms: 650,
			node: /* @__PURE__ */ h(m, { children: n.sectors.map((e) => {
				let n = t.anchor(`uaps-sector:${e}`);
				return n ? /* @__PURE__ */ h(b, {
					at: n,
					ms: 650
				}, e) : null;
			}) })
		};
	},
	uapsVerify(e, t) {
		let n = e.data;
		return {
			ms: 650,
			node: /* @__PURE__ */ h(m, { children: n.wrong.map((e, n) => {
				let r = t.anchor(`uaps-sector:${e.sector}`), i = t.anchor(`uaps-researcher:${e.rid}`);
				return r && i ? /* @__PURE__ */ h(ee, {
					from: r,
					to: i,
					ms: 600,
					children: /* @__PURE__ */ h("div", {
						style: {
							width: r.w,
							height: r.h,
							opacity: .7
						},
						children: /* @__PURE__ */ h(Ae, {})
					})
				}, n) : null;
			}) })
		};
	},
	uapsMove() {
		return null;
	},
	uapsRotate() {
		return null;
	},
	uapsIntel(e, t) {
		let n = t.anchor(`uaps-researcher:${t.myRid}`);
		return n ? {
			ms: 650,
			node: /* @__PURE__ */ h(b, {
				at: n,
				ms: 650
			})
		} : null;
	},
	uapsFound(e, t) {
		let n = t.anchor(`uaps-researcher:${e.rid}`);
		return n ? {
			ms: 650,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 650,
				children: /* @__PURE__ */ h(Q, {
					object: "uap",
					size: 48
				})
			})
		} : null;
	},
	uapsMiss(e, t) {
		let n = t.anchor(`uaps-researcher:${e.rid}`);
		return n ? {
			ms: 650,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 650,
				children: /* @__PURE__ */ h("span", {
					style: {
						color: "#ecb478",
						fontSize: 28
					},
					children: "×"
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/searchforuaps/game-over.tsx
function Ve(e) {
	let t = o(), n = e.public, r = e.private, [i, s] = a(!0), [c, l] = a(!1), u = (n) => e.members.find((e) => e.rid === n)?.name ?? t("games.searchforuaps.ai"), d = e.result.ranking.map((e) => n.players.find((t) => t.rid === e)).filter(Boolean);
	return /* @__PURE__ */ g("div", {
		className: "uaps-ending",
		children: [
			/* @__PURE__ */ h("div", {
				className: "uaps-final-chart",
				inert: i,
				children: /* @__PURE__ */ h(Fe, {
					pub: n,
					priv: r,
					members: e.members,
					readOnly: !0
				})
			}),
			/* @__PURE__ */ h("button", {
				onClick: () => s(!0),
				children: t("games.searchforuaps.showResult")
			}),
			/* @__PURE__ */ h("div", {
				className: "uaps-result-mask",
				hidden: !i,
				style: i ? void 0 : { display: "none" },
				children: /* @__PURE__ */ g("section", {
					className: "uaps-result-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.searchforuaps.result"),
					children: [
						/* @__PURE__ */ g("header", { children: [
							/* @__PURE__ */ h(Q, {
								object: "uap",
								size: 45
							}),
							/* @__PURE__ */ h("h1", { children: t("games.searchforuaps.result") }),
							/* @__PURE__ */ h("button", {
								onClick: () => s(!1),
								"aria-label": t("games.searchforuaps.review"),
								children: "⌄"
							})
						] }),
						/* @__PURE__ */ g("div", {
							className: "uaps-result-scroll",
							children: [
								/* @__PURE__ */ g("p", {
									className: "uaps-winner",
									children: [
										e.result.winner.map(u).join(" · "),
										" · ",
										t("games.searchforuaps.winner")
									]
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ h("small", { children: t("games.searchforuaps.hintCount", { n: e.hintCount }) }),
								/* @__PURE__ */ g("table", { children: [
									/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {}), d.map((n) => /* @__PURE__ */ g("th", { children: [u(n.rid), (e.result.autopilot?.[n.rid] ?? 0) > 0 && /* @__PURE__ */ h("small", { children: t("games.searchforuaps.autopilot", { n: Math.round(e.result.autopilot[n.rid] * 100) }) })] }, n.rid))] }) }),
									/* @__PURE__ */ g("tbody", { children: [/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: t("games.searchforuaps.photos") }), d.map((e) => /* @__PURE__ */ g("td", { children: [e.photoPoints, /* @__PURE__ */ g("small", { children: [
										e.photos,
										" ",
										t("games.searchforuaps.photos")
									] })] }, e.rid))] }), /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: t("games.searchforuaps.discovery") }), d.map((e) => /* @__PURE__ */ h("td", { children: e.locatePoints }, e.rid))] })] }),
									/* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: t("games.searchforuaps.total") }), d.map((t) => /* @__PURE__ */ h("td", {
										className: e.result.winner.includes(t.rid) ? "uaps-winner" : "",
										children: t.score
									}, t.rid))] }) })
								] })
							]
						}),
						/* @__PURE__ */ g("footer", { children: [
							e.onPlayAgain && /* @__PURE__ */ h("button", {
								className: "uaps-primary",
								onClick: e.onPlayAgain,
								children: t("games.searchforuaps.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ h("button", {
								onClick: () => c ? e.onBackToLobby?.() : l(!0),
								children: t(c ? "games.searchforuaps.confirmLeave" : "games.searchforuaps.lobby")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ h("p", { children: t("games.searchforuaps.waitHost") })
						] })
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/searchforuaps/options.tsx
function He({ value: e, onChange: t }) {
	let n = o(), r = re.safeParse(e), i = r.success ? r.data : re.parse(void 0), a = (e) => t({
		...i,
		...e
	});
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ h(S, {
				title: n("games.searchforuaps.board"),
				children: ["basic", "expert"].map((e) => /* @__PURE__ */ h(x, {
					name: "uaps-board",
					value: e,
					checked: i.board === e,
					label: n(e === "basic" ? "games.searchforuaps.basic" : "games.searchforuaps.expert"),
					onChange: () => a({ board: e })
				}, e))
			}),
			/* @__PURE__ */ h(S, {
				title: n("games.searchforuaps.modifiers"),
				columns: 3,
				children: [
					"blank",
					"random",
					"custom"
				].map((e) => /* @__PURE__ */ h(x, {
					name: "uaps-modifiers",
					value: e,
					checked: i.modifiers === e,
					label: n(e === "blank" ? "games.searchforuaps.blankMode" : e === "random" ? "games.searchforuaps.randomMode" : "games.searchforuaps.customMode"),
					onChange: () => a({ modifiers: e })
				}, e))
			}),
			i.modifiers === "custom" && [
				0,
				1,
				2,
				3
			].map((e) => /* @__PURE__ */ g("label", {
				className: "flex flex-col gap-1",
				children: [
					/* @__PURE__ */ h("span", { children: n("games.searchforuaps.quadrantLabel", { n: e + 1 }) }),
					/* @__PURE__ */ h("select", {
						className: "rounded border p-2",
						value: i.quadrants[e],
						onChange: (t) => {
							let n = [...i.quadrants];
							n[e] = t.target.value, a({ quadrants: n });
						},
						children: D.map((t) => /* @__PURE__ */ h("option", {
							value: t,
							disabled: t !== "blank" && i.quadrants.some((n, r) => r !== e && n === t),
							children: n(we[t])
						}, t))
					}),
					/* @__PURE__ */ h("small", { children: n(Te[i.quadrants[e]]) })
				]
			}, e))
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/searchforuaps/entry.tsx
var Ue = {
	definition: Ce,
	View: Re,
	bot: ze,
	fx: Be,
	OverView: Ve,
	Options: He,
	locales: {
		zh: {
			name: "寻找UAP",
			desc: "转动双轨星空，调查卫星与流星，为未知飞行现象拍下证据。",
			rules: "目标：\n调查双轨中的天体，用正确照片得分，并寻找 UAP 及其三个邻居。分数最高者获胜。\n准备：\n基础版每轨8个扇区，专家版每轨12个；5人必须使用专家版。每格恰有一个天体。\n· 月亮公开且在外轨，哈勃也在外轨并且不与月亮相邻。\n· 国际空间站在内轨，至少邻接一块真实太空垃圾。\n· 间谍卫星仅在内轨奇数扇区。\n· 通讯卫星仅在偶数扇区。\n· 流星雨：游戏开始时，成对占据内外轨中上下对应的两个扇区。\n· 导航卫星：始终在同轨对径成对。\n· 真实太空垃圾：不能连续占据三个扇区。\n· UAP恰有一个，调查和锁定时显示为垃圾。\n基础版间谍和通讯各1–2个，流星0／2／4／6个，导航2／4／6个，垃圾1–5个。专家版间谍和通讯各1–4个（通讯每轨至多2个），流星0／2／4／6／8个，导航2／4／6／8个，垃圾1–8个。月亮、哈勃、国际空间站各1个。\n每人选择起始象限和初始线索难度。初学者获得8条排除线索，熟练者4条，天才0条。单人对抗仅依据自身情报行动的电脑研究员。\n流程：\n时间最落后的研究员行动，同格先到先行动。每次完成一项行动，按费用向前推进时间。移入相邻象限花费1点时间，移入对面的象限花费2点时间。\n· 调查：本象限全部扇区花费1点时间，单轨或上下堆叠花费2点时间，单个扇区花费3点时间。选择一种天体，私下获知数量。垃圾数量包含UAP。\n· 锁定：花费4点时间，私下获知本象限一个扇区中的天体。显示垃圾时也可能是UAP。\n· 拍照：花费1点时间，选本象限尚未验证的扇区，放置一张相应天体的照片。基础版中，每人持有哈勃和国际空间站的照片各1张，通讯卫星和间谍卫星的照片各2张，导航卫星和流星雨的照片各6张。专家版中，通讯卫星、间谍卫星、导航卫星和流星雨的照片各增加2张。错误照片弃置。不能重复拍自己已有照片的扇区。\n· 分析：任意玩家已验证通讯／导航／间谍卫星后，选择其A–F情报中的一项，私下获得固定线索。通讯与导航花费1点时间，间谍花费2点时间。未学过的另一项可在之后分析。\n· 寻找UAP：花费5点时间，在任意象限选择UAP位置，再填写同轨两侧与当前上下堆叠的三个天体。四项全部正确才成功。只公布成功与否，不公布地点。\n全体研究员每跨过一条粗线（3点时间），地球和内轨逆时针转动一格，外轨固定。研究员与象限随地球转动，扇区编号始终跟随原扇区。旋转后验证所有照片：正确照片公开留存，错误照片移除，持有者多花费1点时间。各玩家按自己的用时收到1–4份固定解密报告，不能主动分享未解密的内容。个人排除、确认与笔记仅自己可见。\n象限修正：\n可以为四个象限使用空白修正，也可以随机选择4种修正，或分别配置每个象限的修正。修正效果随象限转动，作用于该象限中的研究员；详细效果显示在象限资料中。跟车需要主动接受，移动本身花费0点时间。照片计分修正按终局所在象限决定。分析双情报、双类型调查和双锁定分别按对应修正执行。\n结束与计分：\n第一位成功寻找UAP的玩家获得10分，仍推进5点时间。其他落后1–5点时间的玩家按从后向前顺序获得一次最后机会：寻找UAP，成功获得落后时间乘2分；或在任意象限拍照，落后1／2点时间可拍1张，3／4点时间可拍2张，5点时间可拍3张。最后机会不再推进时间，也不能移动。\n最后验证所有照片，终局错误照片不罚时间。正确哈勃、国际空间站每张4分，通讯、间谍每张3分，导航、流星每张2分。加上象限修正与寻找UAP的分数。总分相同时依次比较寻找UAP分数、正确照片数量、是否最先找到UAP；仍相同共同获胜。单人模式总分相同则电脑获胜。",
			invalid: "这项行动当前不可用，请重新选择。",
			ai: "电脑研究员",
			addPhoto: "加入照片",
			photoCapacity: "本次最多拍摄 {{n}} 张照片",
			publicActions: "公共行动记录",
			decline: "留在原地",
			verifyAction: "验证照片",
			incorrect: "照片不正确",
			board: "版图",
			basic: "基础 · 16扇区",
			expert: "专家 · 24扇区",
			modifiers: "象限修正",
			blankMode: "全部空白",
			randomMode: "随机四种",
			customMode: "自行配置",
			prepare: "选择起始象限与初始线索",
			beginner: "初学者 · 8条",
			experienced: "熟练者 · 4条",
			genius: "天才 · 0条",
			start: "开始研究",
			yourTurn: "轮到你了",
			waiting: "等待 {{name}}",
			rotating: "地球正在旋转",
			verifying: "正在验证照片",
			final: "最后机会",
			found: "已找到UAP",
			miss: "尚未找到UAP",
			move: "移动",
			survey: "调查",
			target: "锁定",
			photo: "拍照",
			analyze: "分析",
			locate: "寻找UAP",
			note: "记录",
			history: "研究笔记",
			close: "关闭",
			confirm: "确认",
			cancel: "取消",
			skip: "放弃最后机会",
			follow: "是否免费跟随移动？",
			yes: "跟随",
			no: "留在原地",
			quadrant: "整个象限",
			inner: "内轨",
			outer: "外轨",
			stack: "上下堆叠",
			sector: "单个扇区",
			sectorLabel: "扇区 {{n}}",
			quadrantLabel: "象限 {{n}}",
			time: "时间 {{n}}",
			cost: "花费 {{n}} 时间",
			selectSector: "在星图中选择扇区",
			selectQuadrant: "在地球上选择象限",
			chooseObject: "选择天体",
			chooseNeighbors: "依次填写三个相邻扇区",
			count: "{{object}}：{{n}}",
			notObject: "扇区 {{n}} 没有{{object}}",
			targetResult: "扇区 {{n}}：{{object}}",
			unverified: "待验证照片",
			verified: "已验证",
			notes: "私人笔记",
			memo: "补充记录",
			saveMemo: "保存记录",
			exclude: "排除",
			certain: "确认",
			clear: "清除",
			markHelp: "选择天体后记录排除或确认",
			satellite: "卫星情报",
			locked: "尚未验证",
			learned: "已分析",
			report: "解密报告",
			startInfo: "初始线索",
			result: "研究报告",
			photos: "照片",
			discovery: "寻找UAP",
			total: "总分",
			winner: "获胜",
			review: "回看星图",
			showResult: "查看研究报告",
			playAgain: "再来一局",
			lobby: "返回大厅",
			confirmLeave: "确认返回大厅",
			waitHost: "等待主机决定",
			hintCount: "求助 {{n}} 次",
			autopilot: "托管 {{n}}%",
			luna: "月亮",
			hubble: "哈勃空间望远镜",
			iss: "国际空间站",
			spy: "间谍卫星",
			meteor: "流星雨",
			comm: "通讯卫星",
			nav: "导航卫星",
			junk: "太空垃圾",
			uap: "UAP",
			fQuantity: "{{object}}恰有{{n}}个。",
			fAllOpposite: "所有{{object}}都与另一个同类天体在同轨对径相对。",
			fNoOppositeSelf: "没有{{object}}与同类天体在同轨对径相对。",
			fSameOrbit: "所有{{object}}位于同一轨道。",
			fDifferentOrbit: "两个{{object}}位于不同轨道。",
			fOdd: "所有{{object}}都在奇数扇区。",
			fEven: "所有{{object}}都在偶数扇区。",
			fAllNext: "每个{{object}}都与至少一个同类天体同轨相邻。",
			fNoNextSelf: "没有{{object}}与同类天体同轨相邻。",
			fNoNext: "没有{{object}}与{{other}}同轨相邻。",
			fNextOne: "{{object}}恰好与一个{{other}}同轨相邻。",
			fSomeNext: "至少一个{{object}}与至少一个{{other}}同轨相邻。",
			fSomeBetween: "至少一个{{object}}同轨两侧都是{{other}}。",
			fBetween: "{{object}}同轨两侧都是{{other}}。",
			fOpposite: "{{object}}与{{other}}在同轨对径相对。",
			fSomeOpposite: "至少一个{{object}}与{{other}}在同轨对径相对。",
			fNoOpposite: "没有{{object}}与{{other}}在同轨对径相对。",
			fUapNotNext: "UAP不与{{other}}同轨相邻。",
			fUapNotWithinTwo: "UAP同轨前后两格内没有{{other}}。",
			fUapNotOpposite: "UAP不与{{other}}在同轨对径相对。",
			mBlank: "空白",
			mCharter: "包机",
			mHitch: "搭便车",
			mHurricane: "飓风",
			mBorder: "边境守卫",
			mQuantum: "量子计算",
			mAdvancedDetection: "先进侦测",
			mGovernment: "政府监控",
			mFullMoon: "满月",
			mOvercast: "阴天",
			mAtmospheric: "大气扰动",
			mBrainTrust: "智囊团",
			mRapidFire: "连续锁定",
			mLunarEclipse: "月食",
			mCarbon: "碳素准星",
			mLowBandwidth: "低带宽",
			mEmp: "电磁脉冲",
			mCoronal: "日冕物质抛射",
			mHadron: "强子扰动",
			mGrant: "经费批准",
			mAdvancedTech: "先进技术",
			mCopied: "复制档案",
			mGroup: "集体照片",
			mUnique: "独家照片",
			dBlank: "无额外效果。",
			dCharter: "移入或移出此象限免费；不能借道后继续移动。",
			dHitch: "其他玩家从此象限移动时，同在此象限的你可以免费跟随。",
			dHurricane: "移入或移出此象限额外花费1时间。",
			dBorder: "只能从正对象限直接移入。",
			dQuantum: "分析一次卫星获得该卫星的两项情报。",
			dAdvancedDetection: "可以分析未验证卫星，额外花费1时间。",
			dGovernment: "不能分析卫星。",
			dFullMoon: "月亮位于此象限时，不能调查或锁定。",
			dOvercast: "不能在此象限拍照。",
			dAtmospheric: "不能锁定。",
			dBrainTrust: "此象限有多位研究员时，锁定花费3时间。",
			dRapidFire: "可以花费6时间锁定两个扇区。",
			dLunarEclipse: "月亮位于此象限时，锁定花费2时间。",
			dCarbon: "锁定花费3时间。",
			dLowBandwidth: "调查额外花费1时间。",
			dEmp: "不能调查。",
			dCoronal: "不能调查通讯、导航和间谍卫星。",
			dHadron: "调查后额外旋转地球一格，并验证照片。",
			dGrant: "同一范围可调查两种天体，费用不变。",
			dAdvancedTech: "任何范围的调查均花费1时间。",
			dCopied: "终局此象限照片为0分。",
			dGroup: "终局同扇区多张照片时，此象限每张照片额外1分。",
			dUnique: "终局同扇区仅一张照片时，此象限该照片额外1分。"
		},
		en: {
			name: "The Search for UAPs",
			desc: "Rotate the double orbit, investigate satellites and meteors, and photograph evidence of the unknown.",
			rules: "Goal:\nInvestigate the two orbits, score verified photographs and locate the UAP with all three neighbors. Highest score wins.\nSetup:\nBasic has 8 sectors per orbit; Expert has 12. Five players must use Expert. Each sector contains exactly one object.\n· Luna is public in the outer orbit. Hubble is also in the outer orbit and never next to Luna.\n· The ISS is in the inner orbit next to real space junk.\n· Spy satellites occupy odd inner sectors.\n· Communications satellites occupy even sectors.\n· Meteors begin in stacked pairs.\n· Navigation satellites are in opposite pairs in the same orbit.\n· There are never three consecutive real space junk sectors.\n· Exactly one UAP appears as space junk when surveyed or targeted.\nBasic: 1–2 spies, 1–2 communications satellites, 0/2/4/6 meteors, 2/4/6 navigation satellites and 1–5 junk. Expert: 1–4 spies, 1–4 communications satellites (at most two per orbit), 0/2/4/6/8 meteors, 2/4/6/8 navigation satellites and 1–8 junk. Luna, Hubble and ISS each occur once.\nChoose a starting quadrant and initial information: Beginner gives 8 exclusions, Experienced 4, Genius none. Solo includes a computer researcher acting only on its own information.\nPlay:\nThe researcher furthest back acts; earlier arrivals act first on tied spaces. Perform one action and advance by its time cost. Moving to an adjacent quadrant costs 1 time unit; moving to the opposite quadrant costs 2 time units.\n· Survey: Surveying your entire quadrant costs 1 time unit. Surveying one orbit or one stack costs 2 time units; surveying a single sector costs 3 time units. Privately learn the count of one object. Junk counts include the UAP.\n· Target: Spend 4 time units to privately learn the apparent object in one sector of your quadrant. Junk may be the UAP.\n· Photo: Spend 1 time unit to place a photo in an unverified sector of your quadrant. Basic supply per player: one Hubble, one ISS, two communications, two spies, six navigation and six meteors. Expert adds two each of communications, spies, navigation and meteors. Incorrect photos are discarded. You cannot photograph a sector where you already have a photo.\n· Analyze: once any player has a verified photo of the satellite type, select one of its A–F topics. Analyzing communications or navigation costs 1 time unit; analyzing spies costs 2 time units. Privately learn a fixed fact. Its other topic can be analyzed later.\n· Find UAP: Spend 5 time units. Select its sector anywhere, then identify the two same-orbit neighbors and the current stacked neighbor. All four must be correct. Only success or failure is public, never the location.\nWhenever all researchers cross a thick time-track line (every 3 time units), rotate Earth and the inner orbit one sector counterclockwise. The outer orbit stays fixed. Researchers and quadrant modifiers rotate with Earth; sector numbers stay with their original sectors. Verify all photos: correct photos remain face up; incorrect photos are removed and cost the owner 1 extra time unit. Each player privately receives 1–4 fixed declassified reports when their own time reaches the relevant spaces. Personal marks and notes are private.\nQuadrant modifiers:\nUse four blanks, four random modifiers or configure each quadrant. Effects rotate with their quadrant. Read the full effect in quadrant details. Following a researcher requires accepting the offer and costs no time. Photo scoring modifiers use the final quadrant. Quantum Computing, Grant Approval and Rapid Fire respectively grant two satellite topics, two survey types and two targets.\nEnding and scoring:\nThe first player to find the UAP scores 10 and still advances 5 time units. Other researchers 1–5 time units behind get one final opportunity, back to front: locate the UAP for twice the time behind, or photograph any quadrant. Being 1 or 2 time units behind permits one photo; being 3 or 4 behind permits two; being 5 behind permits three. No time advances and no moving during final opportunities.\nVerify remaining photos without time penalties. Each correct Hubble or ISS photo scores 4 points. Each correct communications or spy photo scores 3 points, and each correct navigation or meteor photo scores 2 points. Apply final quadrant modifiers and UAP points. Break score ties by UAP points, then verified photo count, then first to find the UAP; otherwise share victory. In solo, the computer wins tied total scores.",
			invalid: "That action is unavailable. Please choose again.",
			ai: "Computer researcher",
			addPhoto: "Add photo",
			photoCapacity: "Take up to {{n}} photos",
			publicActions: "Public actions",
			decline: "Stayed here",
			verifyAction: "Verify photos",
			incorrect: "Incorrect photo",
			board: "Board",
			basic: "Basic · 16 sectors",
			expert: "Expert · 24 sectors",
			modifiers: "Quadrant modifiers",
			blankMode: "All blank",
			randomMode: "Four random",
			customMode: "Custom",
			prepare: "Choose your starting quadrant and information",
			beginner: "Beginner · 8 facts",
			experienced: "Experienced · 4 facts",
			genius: "Genius · 0 facts",
			start: "Start research",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}",
			rotating: "Earth is rotating",
			verifying: "Verifying photos",
			final: "Final opportunity",
			found: "UAP located",
			miss: "UAP not located",
			move: "Move",
			survey: "Survey",
			target: "Target",
			photo: "Take photo",
			analyze: "Analyze",
			locate: "Find UAP",
			note: "Mark",
			history: "Research notes",
			close: "Close",
			confirm: "Confirm",
			cancel: "Cancel",
			skip: "Skip final opportunity",
			follow: "Follow for free?",
			yes: "Follow",
			no: "Stay here",
			quadrant: "Entire quadrant",
			inner: "Inner orbit",
			outer: "Outer orbit",
			stack: "Stack",
			sector: "One sector",
			sectorLabel: "Sector {{n}}",
			quadrantLabel: "Quadrant {{n}}",
			time: "Time {{n}}",
			cost: "Costs {{n}} time",
			selectSector: "Select a sector on the chart",
			selectQuadrant: "Select a quadrant on Earth",
			chooseObject: "Choose an object",
			chooseNeighbors: "Identify the three neighboring sectors",
			count: "{{object}}: {{n}}",
			notObject: "Sector {{n}}: no {{object}}",
			targetResult: "Sector {{n}}: {{object}}",
			unverified: "Unverified photo",
			verified: "Verified",
			notes: "Private notes",
			memo: "Additional notes",
			saveMemo: "Save notes",
			exclude: "Exclude",
			certain: "Confirm",
			clear: "Clear",
			markHelp: "Choose an object to exclude or confirm",
			satellite: "Satellite information",
			locked: "Not yet verified",
			learned: "Analyzed",
			report: "Declassified report",
			startInfo: "Starting information",
			result: "Research report",
			photos: "Photos",
			discovery: "Find UAP",
			total: "Total",
			winner: "Winner",
			review: "Review star chart",
			showResult: "Show research report",
			playAgain: "Play again",
			lobby: "Back to lobby",
			confirmLeave: "Confirm return to lobby",
			waitHost: "Waiting for the host",
			hintCount: "{{n}} hints used",
			autopilot: "{{n}}% autopilot",
			luna: "Luna",
			hubble: "Hubble Space Telescope",
			iss: "International Space Station",
			spy: "Spy Satellite",
			meteor: "Meteor Shower",
			comm: "Communications Satellite",
			nav: "Navigation Satellite",
			junk: "Space Junk",
			uap: "UAP",
			fQuantity: "There are exactly {{n}} {{object}}.",
			fAllOpposite: "All {{object}} are opposite another of their kind in the same orbit.",
			fNoOppositeSelf: "No {{object}} is opposite another of its kind.",
			fSameOrbit: "All {{object}} are in the same orbit.",
			fDifferentOrbit: "The two {{object}} are in different orbits.",
			fOdd: "All {{object}} are in odd sectors.",
			fEven: "All {{object}} are in even sectors.",
			fAllNext: "Every {{object}} is next to another of its kind.",
			fNoNextSelf: "No {{object}} is next to another of its kind.",
			fNoNext: "No {{object}} is next to {{other}}.",
			fNextOne: "{{object}} is next to exactly one {{other}}.",
			fSomeNext: "At least one {{object}} is next to at least one {{other}}.",
			fSomeBetween: "At least one {{object}} is between two {{other}}.",
			fBetween: "{{object}} is between two {{other}}.",
			fOpposite: "{{object}} is opposite {{other}} in the same orbit.",
			fSomeOpposite: "At least one {{object}} is opposite {{other}}.",
			fNoOpposite: "No {{object}} is opposite {{other}}.",
			fUapNotNext: "The UAP is not next to {{other}}.",
			fUapNotWithinTwo: "The UAP is not within two sectors of {{other}} in the same orbit.",
			fUapNotOpposite: "The UAP is not opposite {{other}} in the same orbit.",
			mBlank: "Blank",
			mCharter: "Charter Flight",
			mHitch: "Hitch a Ride",
			mHurricane: "Hurricane",
			mBorder: "Border Guards",
			mQuantum: "Quantum Computing",
			mAdvancedDetection: "Advanced Detection",
			mGovernment: "Government Monitoring",
			mFullMoon: "Full Moon",
			mOvercast: "Overcast",
			mAtmospheric: "Atmospheric Disturbance",
			mBrainTrust: "Brain Trust",
			mRapidFire: "Rapid Fire",
			mLunarEclipse: "Lunar Eclipse",
			mCarbon: "Carbon Reticle",
			mLowBandwidth: "Low Bandwidth",
			mEmp: "Electromagnetic Pulse",
			mCoronal: "Coronal Mass Ejection",
			mHadron: "Hadron Disruption",
			mGrant: "Grant Approval",
			mAdvancedTech: "Advanced Tech",
			mCopied: "Copied Files",
			mGroup: "Group Photos",
			mUnique: "Unique Photos",
			dBlank: "No additional effect.",
			dCharter: "Moving here or from here is free. You cannot pass through it on the way elsewhere.",
			dHitch: "When another researcher moves from here, you may follow for free.",
			dHurricane: "Moving here or from here costs 1 extra time.",
			dBorder: "You can only move here directly from the opposite quadrant.",
			dQuantum: "Analyzing a satellite gives both its topics.",
			dAdvancedDetection: "Analyze an unverified satellite for 1 extra time.",
			dGovernment: "No analyzing satellites.",
			dFullMoon: "While Luna is here, no surveying or targeting.",
			dOvercast: "No photos in this quadrant.",
			dAtmospheric: "No targeting.",
			dBrainTrust: "Targeting costs 3 while multiple researchers are here.",
			dRapidFire: "Target two sectors for 6 time.",
			dLunarEclipse: "Targeting costs 2 while Luna is here.",
			dCarbon: "Targeting costs 3.",
			dLowBandwidth: "Surveying costs 1 extra time.",
			dEmp: "No surveying.",
			dCoronal: "No surveying for communications, navigation or spy satellites.",
			dHadron: "Surveying rotates Earth one extra sector and verifies photos.",
			dGrant: "Survey two object types in the same area for the same cost.",
			dAdvancedTech: "Any survey range costs 1 time.",
			dCopied: "Photos here score 0 at the end.",
			dGroup: "At the end, photos here score 1 extra if their sector has multiple photos.",
			dUnique: "At the end, a photo here scores 1 extra if it is alone in its sector."
		}
	}
};
//#endregion
export { Ue as default };
