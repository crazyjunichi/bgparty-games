import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { useWakeLock as ee } from "@bgparty/sdk/use-wake-lock";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as te, jsx as f, jsxs as p } from "react/jsx-runtime";
import { IconBack as m, IconBot as ne, IconExpand as re, IconLog as ie } from "@bgparty/sdk/icons";
import { seatName as ae } from "@bgparty/sdk/ui/player-strip";
import { Confetti as h } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as oe, OptionSection as se, OptionSwitch as ce } from "@bgparty/sdk/ui/game-options";
//#region src/games/duneimperium/catalog.ts
var g = {
	duneTheDesertPlanet: {
		id: "duneTheDesertPlanet",
		nameKey: "games.duneimperium.cards.duneTheDesertPlanet.name",
		textKey: "games.duneimperium.cards.duneTheDesertPlanet.text",
		set: "starter",
		count: 2,
		cost: 0,
		icons: ["yellow"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	seekAllies: {
		id: "seekAllies",
		nameKey: "games.duneimperium.cards.seekAllies.name",
		textKey: "games.duneimperium.cards.seekAllies.text",
		set: "starter",
		count: 1,
		cost: 0,
		icons: [
			"emperor",
			"spacingGuild",
			"beneGesserit",
			"fremen"
		],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	signetRing: {
		id: "signetRing",
		nameKey: "games.duneimperium.cards.signetRing.name",
		textKey: "games.duneimperium.cards.signetRing.text",
		set: "starter",
		count: 1,
		cost: 0,
		icons: [
			"green",
			"blue",
			"yellow"
		],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	diplomacy: {
		id: "diplomacy",
		nameKey: "games.duneimperium.cards.diplomacy.name",
		textKey: "games.duneimperium.cards.diplomacy.text",
		set: "starter",
		count: 1,
		cost: 0,
		icons: [
			"emperor",
			"spacingGuild",
			"beneGesserit",
			"fremen"
		],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	reconnaissance: {
		id: "reconnaissance",
		nameKey: "games.duneimperium.cards.reconnaissance.name",
		textKey: "games.duneimperium.cards.reconnaissance.text",
		set: "starter",
		count: 1,
		cost: 0,
		icons: ["blue"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	convincingArgument: {
		id: "convincingArgument",
		nameKey: "games.duneimperium.cards.convincingArgument.name",
		textKey: "games.duneimperium.cards.convincingArgument.text",
		set: "starter",
		count: 2,
		cost: 0,
		icons: [],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	dagger: {
		id: "dagger",
		nameKey: "games.duneimperium.cards.dagger.name",
		textKey: "games.duneimperium.cards.dagger.text",
		set: "starter",
		count: 2,
		cost: 0,
		icons: ["green", "blue"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	controlTheSpice: {
		id: "controlTheSpice",
		nameKey: "games.duneimperium.cards.controlTheSpice.name",
		textKey: "games.duneimperium.cards.controlTheSpice.text",
		set: "starter",
		count: 1,
		cost: 0,
		icons: ["yellow"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	arrakisLiaison: {
		id: "arrakisLiaison",
		nameKey: "games.duneimperium.cards.arrakisLiaison.name",
		textKey: "games.duneimperium.cards.arrakisLiaison.text",
		set: "reserve",
		count: 8,
		cost: 2,
		icons: ["blue"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	foldspace: {
		id: "foldspace",
		nameKey: "games.duneimperium.cards.foldspace.name",
		textKey: "games.duneimperium.cards.foldspace.text",
		set: "reserve",
		count: 6,
		cost: 0,
		icons: [
			"emperor",
			"spacingGuild",
			"beneGesserit",
			"fremen",
			"green",
			"blue",
			"yellow"
		],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	theSpiceMustFlow: {
		id: "theSpiceMustFlow",
		nameKey: "games.duneimperium.cards.theSpiceMustFlow.name",
		textKey: "games.duneimperium.cards.theSpiceMustFlow.text",
		set: "reserve",
		count: 10,
		cost: 9,
		icons: [],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	sardaukarLegion: {
		id: "sardaukarLegion",
		nameKey: "games.duneimperium.cards.sardaukarLegion.name",
		textKey: "games.duneimperium.cards.sardaukarLegion.text",
		set: "base",
		count: 2,
		cost: 5,
		icons: ["emperor", "green"],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	},
	drYueh: {
		id: "drYueh",
		nameKey: "games.duneimperium.cards.drYueh.name",
		textKey: "games.duneimperium.cards.drYueh.text",
		set: "base",
		count: 1,
		cost: 1,
		icons: ["blue"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	assassinationMission: {
		id: "assassinationMission",
		nameKey: "games.duneimperium.cards.assassinationMission.name",
		textKey: "games.duneimperium.cards.assassinationMission.text",
		set: "base",
		count: 2,
		cost: 1,
		icons: [],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	sardaukarInfantry: {
		id: "sardaukarInfantry",
		nameKey: "games.duneimperium.cards.sardaukarInfantry.name",
		textKey: "games.duneimperium.cards.sardaukarInfantry.text",
		set: "base",
		count: 2,
		cost: 1,
		icons: [],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	},
	beneGesseritInitiate: {
		id: "beneGesseritInitiate",
		nameKey: "games.duneimperium.cards.beneGesseritInitiate.name",
		textKey: "games.duneimperium.cards.beneGesseritInitiate.text",
		set: "base",
		count: 2,
		cost: 3,
		icons: [
			"green",
			"blue",
			"yellow"
		],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	guildAdministrator: {
		id: "guildAdministrator",
		nameKey: "games.duneimperium.cards.guildAdministrator.name",
		textKey: "games.duneimperium.cards.guildAdministrator.text",
		set: "base",
		count: 2,
		cost: 2,
		icons: ["spacingGuild", "yellow"],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !1
	},
	theVoice: {
		id: "theVoice",
		nameKey: "games.duneimperium.cards.theVoice.name",
		textKey: "games.duneimperium.cards.theVoice.text",
		set: "base",
		count: 2,
		cost: 2,
		icons: ["blue", "yellow"],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	scout: {
		id: "scout",
		nameKey: "games.duneimperium.cards.scout.name",
		textKey: "games.duneimperium.cards.scout.text",
		set: "base",
		count: 2,
		cost: 1,
		icons: ["blue", "yellow"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	imperialSpy: {
		id: "imperialSpy",
		nameKey: "games.duneimperium.cards.imperialSpy.name",
		textKey: "games.duneimperium.cards.imperialSpy.text",
		set: "base",
		count: 2,
		cost: 2,
		icons: ["emperor"],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	},
	beneGesseritSister: {
		id: "beneGesseritSister",
		nameKey: "games.duneimperium.cards.beneGesseritSister.name",
		textKey: "games.duneimperium.cards.beneGesseritSister.text",
		set: "base",
		count: 3,
		cost: 3,
		icons: ["beneGesserit", "green"],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	missionariaProtectiva: {
		id: "missionariaProtectiva",
		nameKey: "games.duneimperium.cards.missionariaProtectiva.name",
		textKey: "games.duneimperium.cards.missionariaProtectiva.text",
		set: "base",
		count: 2,
		cost: 1,
		icons: ["blue"],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	spiceHunter: {
		id: "spiceHunter",
		nameKey: "games.duneimperium.cards.spiceHunter.name",
		textKey: "games.duneimperium.cards.spiceHunter.text",
		set: "base",
		count: 2,
		cost: 2,
		icons: ["fremen", "yellow"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	spiceSmugglers: {
		id: "spiceSmugglers",
		nameKey: "games.duneimperium.cards.spiceSmugglers.name",
		textKey: "games.duneimperium.cards.spiceSmugglers.text",
		set: "base",
		count: 2,
		cost: 2,
		icons: ["blue"],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !1
	},
	fedaykinDeathCommando: {
		id: "fedaykinDeathCommando",
		nameKey: "games.duneimperium.cards.fedaykinDeathCommando.name",
		textKey: "games.duneimperium.cards.fedaykinDeathCommando.text",
		set: "base",
		count: 2,
		cost: 3,
		icons: ["blue", "yellow"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	geneManipulation: {
		id: "geneManipulation",
		nameKey: "games.duneimperium.cards.geneManipulation.name",
		textKey: "games.duneimperium.cards.geneManipulation.text",
		set: "base",
		count: 2,
		cost: 3,
		icons: ["green", "blue"],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	guildBankers: {
		id: "guildBankers",
		nameKey: "games.duneimperium.cards.guildBankers.name",
		textKey: "games.duneimperium.cards.guildBankers.text",
		set: "base",
		count: 1,
		cost: 3,
		icons: [
			"emperor",
			"spacingGuild",
			"green"
		],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !1
	},
	choamDirectorship: {
		id: "choamDirectorship",
		nameKey: "games.duneimperium.cards.choamDirectorship.name",
		textKey: "games.duneimperium.cards.choamDirectorship.text",
		set: "base",
		count: 1,
		cost: 8,
		icons: [],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	crysknife: {
		id: "crysknife",
		nameKey: "games.duneimperium.cards.crysknife.name",
		textKey: "games.duneimperium.cards.crysknife.text",
		set: "base",
		count: 1,
		cost: 3,
		icons: ["fremen", "yellow"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	chani: {
		id: "chani",
		nameKey: "games.duneimperium.cards.chani.name",
		textKey: "games.duneimperium.cards.chani.text",
		set: "base",
		count: 1,
		cost: 5,
		icons: [
			"fremen",
			"blue",
			"yellow"
		],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	spaceTravel: {
		id: "spaceTravel",
		nameKey: "games.duneimperium.cards.spaceTravel.name",
		textKey: "games.duneimperium.cards.spaceTravel.text",
		set: "base",
		count: 2,
		cost: 3,
		icons: ["spacingGuild"],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !1
	},
	duncanIdaho: {
		id: "duncanIdaho",
		nameKey: "games.duneimperium.cards.duncanIdaho.name",
		textKey: "games.duneimperium.cards.duncanIdaho.text",
		set: "base",
		count: 1,
		cost: 4,
		icons: ["blue"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	shiftingAllegiances: {
		id: "shiftingAllegiances",
		nameKey: "games.duneimperium.cards.shiftingAllegiances.name",
		textKey: "games.duneimperium.cards.shiftingAllegiances.text",
		set: "base",
		count: 2,
		cost: 3,
		icons: ["green", "yellow"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	kwisatzHaderach: {
		id: "kwisatzHaderach",
		nameKey: "games.duneimperium.cards.kwisatzHaderach.name",
		textKey: "games.duneimperium.cards.kwisatzHaderach.text",
		set: "base",
		count: 1,
		cost: 8,
		icons: ["any"],
		factions: ["beneGesserit"],
		infiltrate: !0,
		unload: !1
	},
	sietchReverendMother: {
		id: "sietchReverendMother",
		nameKey: "games.duneimperium.cards.sietchReverendMother.name",
		textKey: "games.duneimperium.cards.sietchReverendMother.text",
		set: "base",
		count: 1,
		cost: 4,
		icons: ["beneGesserit", "fremen"],
		factions: ["beneGesserit", "fremen"],
		infiltrate: !1,
		unload: !1
	},
	arrakisRecruiter: {
		id: "arrakisRecruiter",
		nameKey: "games.duneimperium.cards.arrakisRecruiter.name",
		textKey: "games.duneimperium.cards.arrakisRecruiter.text",
		set: "base",
		count: 2,
		cost: 2,
		icons: ["blue"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	firmGrip: {
		id: "firmGrip",
		nameKey: "games.duneimperium.cards.firmGrip.name",
		textKey: "games.duneimperium.cards.firmGrip.text",
		set: "base",
		count: 1,
		cost: 4,
		icons: ["emperor", "green"],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	},
	smugglersThopter: {
		id: "smugglersThopter",
		nameKey: "games.duneimperium.cards.smugglersThopter.name",
		textKey: "games.duneimperium.cards.smugglersThopter.text",
		set: "base",
		count: 2,
		cost: 4,
		icons: ["yellow"],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !1
	},
	carryall: {
		id: "carryall",
		nameKey: "games.duneimperium.cards.carryall.name",
		textKey: "games.duneimperium.cards.carryall.text",
		set: "base",
		count: 1,
		cost: 5,
		icons: ["yellow"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	gunThopter: {
		id: "gunThopter",
		nameKey: "games.duneimperium.cards.gunThopter.name",
		textKey: "games.duneimperium.cards.gunThopter.text",
		set: "base",
		count: 2,
		cost: 4,
		icons: ["blue", "yellow"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	guildAmbassador: {
		id: "guildAmbassador",
		nameKey: "games.duneimperium.cards.guildAmbassador.name",
		textKey: "games.duneimperium.cards.guildAmbassador.text",
		set: "base",
		count: 1,
		cost: 4,
		icons: ["green"],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !1
	},
	testOfHumanity: {
		id: "testOfHumanity",
		nameKey: "games.duneimperium.cards.testOfHumanity.name",
		textKey: "games.duneimperium.cards.testOfHumanity.text",
		set: "base",
		count: 1,
		cost: 3,
		icons: [
			"beneGesserit",
			"green",
			"blue"
		],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	fremenCamp: {
		id: "fremenCamp",
		nameKey: "games.duneimperium.cards.fremenCamp.name",
		textKey: "games.duneimperium.cards.fremenCamp.text",
		set: "base",
		count: 2,
		cost: 4,
		icons: ["yellow"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	opulence: {
		id: "opulence",
		nameKey: "games.duneimperium.cards.opulence.name",
		textKey: "games.duneimperium.cards.opulence.text",
		set: "base",
		count: 1,
		cost: 6,
		icons: ["emperor"],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	},
	ladyJessica: {
		id: "ladyJessica",
		nameKey: "games.duneimperium.cards.ladyJessica.name",
		textKey: "games.duneimperium.cards.ladyJessica.text",
		set: "base",
		count: 1,
		cost: 7,
		icons: [
			"beneGesserit",
			"green",
			"blue",
			"yellow"
		],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	stilgar: {
		id: "stilgar",
		nameKey: "games.duneimperium.cards.stilgar.name",
		textKey: "games.duneimperium.cards.stilgar.text",
		set: "base",
		count: 1,
		cost: 5,
		icons: [
			"fremen",
			"blue",
			"yellow"
		],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	piterDeVries: {
		id: "piterDeVries",
		nameKey: "games.duneimperium.cards.piterDeVries.name",
		textKey: "games.duneimperium.cards.piterDeVries.text",
		set: "base",
		count: 1,
		cost: 5,
		icons: ["green", "blue"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	gurneyHalleck: {
		id: "gurneyHalleck",
		nameKey: "games.duneimperium.cards.gurneyHalleck.name",
		textKey: "games.duneimperium.cards.gurneyHalleck.text",
		set: "base",
		count: 1,
		cost: 6,
		icons: ["blue"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	thufirHawat: {
		id: "thufirHawat",
		nameKey: "games.duneimperium.cards.thufirHawat.name",
		textKey: "games.duneimperium.cards.thufirHawat.text",
		set: "base",
		count: 1,
		cost: 5,
		icons: [
			"emperor",
			"spacingGuild",
			"beneGesserit",
			"fremen",
			"blue",
			"yellow"
		],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	otherMemory: {
		id: "otherMemory",
		nameKey: "games.duneimperium.cards.otherMemory.name",
		textKey: "games.duneimperium.cards.otherMemory.text",
		set: "base",
		count: 1,
		cost: 4,
		icons: ["blue", "yellow"],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	lietKynes: {
		id: "lietKynes",
		nameKey: "games.duneimperium.cards.lietKynes.name",
		textKey: "games.duneimperium.cards.lietKynes.text",
		set: "base",
		count: 1,
		cost: 5,
		icons: ["fremen", "blue"],
		factions: ["emperor", "fremen"],
		infiltrate: !1,
		unload: !1
	},
	wormRiders: {
		id: "wormRiders",
		nameKey: "games.duneimperium.cards.wormRiders.name",
		textKey: "games.duneimperium.cards.wormRiders.text",
		set: "base",
		count: 2,
		cost: 6,
		icons: ["blue", "yellow"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	reverendMotherMohiam: {
		id: "reverendMotherMohiam",
		nameKey: "games.duneimperium.cards.reverendMotherMohiam.name",
		textKey: "games.duneimperium.cards.reverendMotherMohiam.text",
		set: "base",
		count: 1,
		cost: 6,
		icons: ["emperor", "beneGesserit"],
		factions: ["emperor", "beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	powerPlay: {
		id: "powerPlay",
		nameKey: "games.duneimperium.cards.powerPlay.name",
		textKey: "games.duneimperium.cards.powerPlay.text",
		set: "base",
		count: 3,
		cost: 5,
		icons: [
			"emperor",
			"spacingGuild",
			"beneGesserit",
			"fremen"
		],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	guildChiefAdministrator: {
		id: "guildChiefAdministrator",
		nameKey: "games.duneimperium.cards.guildChiefAdministrator.name",
		textKey: "games.duneimperium.cards.guildChiefAdministrator.text",
		set: "ix",
		count: 1,
		cost: 4,
		icons: [
			"spacingGuild",
			"blue",
			"yellow"
		],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !1
	},
	guildAccord: {
		id: "guildAccord",
		nameKey: "games.duneimperium.cards.guildAccord.name",
		textKey: "games.duneimperium.cards.guildAccord.text",
		set: "ix",
		count: 1,
		cost: 6,
		icons: ["spacingGuild"],
		factions: ["spacingGuild"],
		infiltrate: !0,
		unload: !0
	},
	localFence: {
		id: "localFence",
		nameKey: "games.duneimperium.cards.localFence.name",
		textKey: "games.duneimperium.cards.localFence.text",
		set: "ix",
		count: 1,
		cost: 3,
		icons: ["blue"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	shaiHulud: {
		id: "shaiHulud",
		nameKey: "games.duneimperium.cards.shaiHulud.name",
		textKey: "games.duneimperium.cards.shaiHulud.text",
		set: "ix",
		count: 1,
		cost: 7,
		icons: ["yellow"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	ixGuildCompact: {
		id: "ixGuildCompact",
		nameKey: "games.duneimperium.cards.ixGuildCompact.name",
		textKey: "games.duneimperium.cards.ixGuildCompact.text",
		set: "ix",
		count: 1,
		cost: 3,
		icons: ["spacingGuild"],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !0
	},
	choamDelegate: {
		id: "choamDelegate",
		nameKey: "games.duneimperium.cards.choamDelegate.name",
		textKey: "games.duneimperium.cards.choamDelegate.text",
		set: "ix",
		count: 1,
		cost: 1,
		icons: ["yellow"],
		factions: [],
		infiltrate: !0,
		unload: !0
	},
	bountyHunter: {
		id: "bountyHunter",
		nameKey: "games.duneimperium.cards.bountyHunter.name",
		textKey: "games.duneimperium.cards.bountyHunter.text",
		set: "ix",
		count: 1,
		cost: 1,
		icons: ["blue"],
		factions: [],
		infiltrate: !0,
		unload: !1
	},
	embeddedAgent: {
		id: "embeddedAgent",
		nameKey: "games.duneimperium.cards.embeddedAgent.name",
		textKey: "games.duneimperium.cards.embeddedAgent.text",
		set: "ix",
		count: 1,
		cost: 5,
		icons: ["green"],
		factions: ["beneGesserit"],
		infiltrate: !0,
		unload: !1
	},
	esmarTuek: {
		id: "esmarTuek",
		nameKey: "games.duneimperium.cards.esmarTuek.name",
		textKey: "games.duneimperium.cards.esmarTuek.text",
		set: "ix",
		count: 1,
		cost: 5,
		icons: ["blue", "yellow"],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !0
	},
	courtIntrigue: {
		id: "courtIntrigue",
		nameKey: "games.duneimperium.cards.courtIntrigue.name",
		textKey: "games.duneimperium.cards.courtIntrigue.text",
		set: "ix",
		count: 1,
		cost: 2,
		icons: ["emperor"],
		factions: ["emperor"],
		infiltrate: !0,
		unload: !1
	},
	sayyadina: {
		id: "sayyadina",
		nameKey: "games.duneimperium.cards.sayyadina.name",
		textKey: "games.duneimperium.cards.sayyadina.text",
		set: "ix",
		count: 1,
		cost: 3,
		icons: ["beneGesserit", "fremen"],
		factions: ["beneGesserit", "fremen"],
		infiltrate: !1,
		unload: !1
	},
	imperialShockTrooper: {
		id: "imperialShockTrooper",
		nameKey: "games.duneimperium.cards.imperialShockTrooper.name",
		textKey: "games.duneimperium.cards.imperialShockTrooper.text",
		set: "ix",
		count: 1,
		cost: 3,
		icons: [],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	},
	appropriate: {
		id: "appropriate",
		nameKey: "games.duneimperium.cards.appropriate.name",
		textKey: "games.duneimperium.cards.appropriate.text",
		set: "ix",
		count: 1,
		cost: 5,
		icons: ["green", "yellow"],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	},
	desertAmbush: {
		id: "desertAmbush",
		nameKey: "games.duneimperium.cards.desertAmbush.name",
		textKey: "games.duneimperium.cards.desertAmbush.text",
		set: "ix",
		count: 1,
		cost: 3,
		icons: ["yellow"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	inTheShadows: {
		id: "inTheShadows",
		nameKey: "games.duneimperium.cards.inTheShadows.name",
		textKey: "games.duneimperium.cards.inTheShadows.text",
		set: "ix",
		count: 2,
		cost: 2,
		icons: ["green", "blue"],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !0
	},
	satelliteBan: {
		id: "satelliteBan",
		nameKey: "games.duneimperium.cards.satelliteBan.name",
		textKey: "games.duneimperium.cards.satelliteBan.text",
		set: "ix",
		count: 1,
		cost: 5,
		icons: ["spacingGuild", "fremen"],
		factions: ["spacingGuild", "fremen"],
		infiltrate: !1,
		unload: !1
	},
	freighterFleet: {
		id: "freighterFleet",
		nameKey: "games.duneimperium.cards.freighterFleet.name",
		textKey: "games.duneimperium.cards.freighterFleet.text",
		set: "ix",
		count: 2,
		cost: 2,
		icons: ["yellow"],
		factions: [],
		infiltrate: !1,
		unload: !0
	},
	imperialBashar: {
		id: "imperialBashar",
		nameKey: "games.duneimperium.cards.imperialBashar.name",
		textKey: "games.duneimperium.cards.imperialBashar.text",
		set: "ix",
		count: 1,
		cost: 4,
		icons: ["blue"],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	},
	jamis: {
		id: "jamis",
		nameKey: "games.duneimperium.cards.jamis.name",
		textKey: "games.duneimperium.cards.jamis.text",
		set: "ix",
		count: 1,
		cost: 2,
		icons: ["fremen"],
		factions: ["fremen"],
		infiltrate: !0,
		unload: !1
	},
	landingRights: {
		id: "landingRights",
		nameKey: "games.duneimperium.cards.landingRights.name",
		textKey: "games.duneimperium.cards.landingRights.text",
		set: "ix",
		count: 1,
		cost: 4,
		icons: ["blue"],
		factions: ["spacingGuild"],
		infiltrate: !1,
		unload: !1
	},
	waterPeddler: {
		id: "waterPeddler",
		nameKey: "games.duneimperium.cards.waterPeddler.name",
		textKey: "games.duneimperium.cards.waterPeddler.text",
		set: "ix",
		count: 1,
		cost: 1,
		icons: [],
		factions: [],
		infiltrate: !1,
		unload: !0
	},
	treachery: {
		id: "treachery",
		nameKey: "games.duneimperium.cards.treachery.name",
		textKey: "games.duneimperium.cards.treachery.text",
		set: "ix",
		count: 2,
		cost: 6,
		icons: [
			"emperor",
			"spacingGuild",
			"beneGesserit",
			"fremen"
		],
		factions: [],
		infiltrate: !1,
		unload: !0
	},
	truthsayer: {
		id: "truthsayer",
		nameKey: "games.duneimperium.cards.truthsayer.name",
		textKey: "games.duneimperium.cards.truthsayer.text",
		set: "ix",
		count: 2,
		cost: 3,
		icons: [
			"emperor",
			"beneGesserit",
			"green"
		],
		factions: ["emperor", "beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	spiceTrader: {
		id: "spiceTrader",
		nameKey: "games.duneimperium.cards.spiceTrader.name",
		textKey: "games.duneimperium.cards.spiceTrader.text",
		set: "ix",
		count: 1,
		cost: 4,
		icons: ["blue", "yellow"],
		factions: ["fremen"],
		infiltrate: !1,
		unload: !1
	},
	ixianEngineer: {
		id: "ixianEngineer",
		nameKey: "games.duneimperium.cards.ixianEngineer.name",
		textKey: "games.duneimperium.cards.ixianEngineer.text",
		set: "ix",
		count: 2,
		cost: 5,
		icons: ["yellow"],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	webOfPower: {
		id: "webOfPower",
		nameKey: "games.duneimperium.cards.webOfPower.name",
		textKey: "games.duneimperium.cards.webOfPower.text",
		set: "ix",
		count: 1,
		cost: 4,
		icons: ["beneGesserit"],
		factions: ["beneGesserit"],
		infiltrate: !0,
		unload: !1
	},
	weirdingWay: {
		id: "weirdingWay",
		nameKey: "games.duneimperium.cards.weirdingWay.name",
		textKey: "games.duneimperium.cards.weirdingWay.text",
		set: "ix",
		count: 1,
		cost: 3,
		icons: ["blue", "yellow"],
		factions: ["beneGesserit"],
		infiltrate: !1,
		unload: !1
	},
	negotiatedWithdrawal: {
		id: "negotiatedWithdrawal",
		nameKey: "games.duneimperium.cards.negotiatedWithdrawal.name",
		textKey: "games.duneimperium.cards.negotiatedWithdrawal.text",
		set: "ix",
		count: 2,
		cost: 4,
		icons: [
			"green",
			"blue",
			"yellow"
		],
		factions: [],
		infiltrate: !1,
		unload: !1
	},
	fullScaleAssault: {
		id: "fullScaleAssault",
		nameKey: "games.duneimperium.cards.fullScaleAssault.name",
		textKey: "games.duneimperium.cards.fullScaleAssault.text",
		set: "ix",
		count: 1,
		cost: 8,
		icons: ["emperor", "blue"],
		factions: ["emperor"],
		infiltrate: !1,
		unload: !1
	}
}, _ = [
	"emperor",
	"spacingGuild",
	"beneGesserit",
	"fremen"
], v = (e, t) => ({
	kind: "gain",
	resource: e,
	n: t
}), y = (e = 1) => ({
	kind: "draw",
	n: e
}), b = (e = 1) => ({
	kind: "intrigue",
	n: e
}), x = (e = 1) => ({
	kind: "troop",
	n: e
}), S = (e, t = 1) => ({
	kind: "influence",
	n: t,
	...e ? { faction: e } : {}
}), C = (e, t) => ({
	kind: "special",
	id: e,
	...t === void 0 ? {} : { n: t }
}), w = (e, t = 1) => ({
	kind: "flag",
	flag: e,
	n: t
}), T = (e, ...t) => ({
	kind: "pay",
	cost: e,
	effects: t
}), E = (...e) => ({
	kind: "choice",
	options: e
}), le = (e, t, n, r) => ({
	kind: "if",
	condition: {
		kind: e,
		faction: n,
		n: r
	},
	effects: t
}), D = (e = "all", t, n = !1) => ({
	kind: "trash",
	zone: e,
	after: t,
	required: n
}), O = (e, t, n = !1) => ({
	kind: "discard",
	n: e,
	after: t,
	required: n
}), k = (e = 1) => ({
	kind: "shipment",
	n: e
}), A = (e = 0, t = !1, n = !1) => ({
	kind: "tech",
	discount: e,
	solari: t,
	negotiate: n
}), ue = (e, t = !1) => ({
	kind: "deploy",
	n: e,
	units: t
}), de = (e, t = !1, n = !1, r) => ({
	kind: "retreat",
	n: e,
	units: t,
	exact: n,
	after: r
}), j = (e) => v("persuasion", e), M = (e) => v("sword", e), fe = (...e) => le("bond", e), pe = (...e) => le("bg", e), me = (e, ...t) => le("alliance", t, e), he = (e, ...t) => le("friendship", t, e), ge = {
	duneTheDesertPlanet: {
		agent: [],
		reveal: [j(1)]
	},
	seekAllies: {
		agent: [D("self", void 0, !0)],
		reveal: []
	},
	signetRing: {
		agent: [C("signet")],
		reveal: [j(1)]
	},
	diplomacy: {
		agent: [],
		reveal: [j(1)]
	},
	reconnaissance: {
		agent: [],
		reveal: [j(1)]
	},
	convincingArgument: {
		agent: [],
		reveal: [j(2)]
	},
	dagger: {
		agent: [],
		reveal: [M(1)]
	},
	controlTheSpice: {
		agent: [T({ spice: 1 }, D(), x())],
		reveal: [j(1), v("spice", 1)]
	},
	arrakisLiaison: {
		agent: [],
		reveal: [j(2)]
	},
	foldspace: {
		agent: [y(), D("self", void 0, !0)],
		reveal: []
	},
	theSpiceMustFlow: {
		agent: [],
		reveal: [v("spice", 1)],
		acquire: [v("vp", 1)]
	},
	sardaukarLegion: {
		agent: [x(2)],
		reveal: [j(1), ue(3)]
	},
	drYueh: {
		agent: [y()],
		reveal: [j(1)]
	},
	assassinationMission: {
		agent: [],
		reveal: [M(1), v("solari", 1)]
	},
	sardaukarInfantry: {
		agent: [],
		reveal: [j(1), M(2)]
	},
	beneGesseritInitiate: {
		agent: [y()],
		reveal: [j(1)]
	},
	guildAdministrator: {
		agent: [D()],
		reveal: [j(1)]
	},
	theVoice: {
		agent: [],
		reveal: [j(2)],
		acquire: [C("voice")]
	},
	scout: {
		agent: [],
		reveal: [
			j(1),
			M(1),
			de(2)
		]
	},
	imperialSpy: {
		agent: [D("self", [b()])],
		reveal: [j(1), M(1)]
	},
	beneGesseritSister: {
		agent: [],
		reveal: [E([j(2)], [M(2)])]
	},
	missionariaProtectiva: {
		agent: [pe(S())],
		reveal: [j(1)]
	},
	spiceHunter: {
		agent: [],
		reveal: [
			j(1),
			M(1),
			fe(v("spice", 1))
		]
	},
	spiceSmugglers: {
		agent: [T({ spice: 2 }, S("spacingGuild"), v("solari", 3))],
		reveal: [j(1), M(1)]
	},
	fedaykinDeathCommando: {
		agent: [D()],
		reveal: [j(1), fe(M(3))]
	},
	geneManipulation: {
		agent: [D(), pe(v("spice", 2))],
		reveal: [j(2)]
	},
	guildBankers: {
		agent: [],
		reveal: [w("spiceDiscount", 3)]
	},
	choamDirectorship: {
		agent: [],
		reveal: [v("solari", 3)],
		acquire: [
			S("emperor"),
			S("spacingGuild"),
			S("beneGesserit"),
			S("fremen")
		]
	},
	crysknife: {
		agent: [v("solari", 1)],
		reveal: [M(1), fe(S("fremen"))]
	},
	chani: {
		agent: [],
		reveal: [j(2), de(12)],
		acquire: [v("water", 1)]
	},
	spaceTravel: {
		agent: [y()],
		reveal: [j(2)]
	},
	duncanIdaho: {
		agent: [T({ water: 1 }, x(), y())],
		reveal: [M(2), v("water", 1)]
	},
	shiftingAllegiances: {
		agent: [C("shift")],
		reveal: [j(2)]
	},
	kwisatzHaderach: {
		agent: [y()],
		reveal: []
	},
	sietchReverendMother: {
		agent: [D()],
		reveal: [fe(j(3)), v("spice", 1)]
	},
	arrakisRecruiter: {
		agent: [x()],
		reveal: [j(1), M(1)]
	},
	firmGrip: {
		agent: [T({ solari: 2 }, {
			kind: "influence",
			n: 1,
			exclude: ["emperor"]
		})],
		reveal: [me("emperor", j(4))]
	},
	smugglersThopter: {
		agent: [he("spacingGuild", y(2))],
		reveal: [j(1), v("spice", 1)]
	},
	carryall: {
		agent: [],
		reveal: [j(1), v("spice", 1)]
	},
	gunThopter: {
		agent: [C("gunThopter")],
		reveal: [M(3), ue(1)]
	},
	guildAmbassador: {
		agent: [E([S("spacingGuild")], [j(2)])],
		reveal: [me("spacingGuild", T({ spice: 3 }, v("vp", 1)))]
	},
	testOfHumanity: {
		agent: [C("humanity")],
		reveal: [j(2)]
	},
	fremenCamp: {
		agent: [T({ spice: 2 }, x(3))],
		reveal: [j(2), M(1)]
	},
	opulence: {
		agent: [v("solari", 3)],
		reveal: [j(1), T({ solari: 6 }, v("vp", 1))]
	},
	ladyJessica: {
		agent: [y(2)],
		reveal: [j(3), M(1)],
		acquire: [S()]
	},
	stilgar: {
		agent: [v("water", 1)],
		reveal: [j(2), M(3)]
	},
	piterDeVries: {
		agent: [b()],
		reveal: [j(3), M(1)]
	},
	gurneyHalleck: {
		agent: [x(2), y()],
		reveal: [j(2), T({ solari: 3 }, C("recruitDeploy", 2))]
	},
	thufirHawat: {
		agent: [y()],
		reveal: [j(1), b()]
	},
	otherMemory: {
		agent: [C("memory")],
		reveal: [j(2)]
	},
	lietKynes: {
		agent: [],
		reveal: [C("liet")],
		acquire: [S("emperor")]
	},
	wormRiders: {
		agent: [v("spice", 2)],
		reveal: [he("fremen", M(4)), me("fremen", M(2))]
	},
	reverendMotherMohiam: {
		agent: [pe(C("mohiam"))],
		reveal: [j(2), v("spice", 2)]
	},
	powerPlay: {
		agent: [D("self", void 0, !0)],
		reveal: []
	},
	guildChiefAdministrator: {
		agent: [O(1, [D()])],
		reveal: [j(1), k()]
	},
	guildAccord: {
		agent: [],
		reveal: [v("water", 1), me("spacingGuild", v("spice", 3))]
	},
	localFence: {
		agent: [{
			kind: "choice",
			optional: !0,
			options: [[T({ spice: 2 }, v("solari", 5))], [T({ solari: 5 }, v("spice", 4))]]
		}],
		reveal: [j(2)]
	},
	shaiHulud: {
		agent: [D("all", [x(2)])],
		reveal: [fe(M(5))],
		acquire: [D()]
	},
	ixGuildCompact: {
		agent: [O(2, [A()])],
		reveal: [{
			kind: "negotiator",
			n: 2
		}]
	},
	choamDelegate: {
		agent: [],
		reveal: [v("solari", 3)]
	},
	bountyHunter: {
		agent: [C("bounty")],
		reveal: [j(1), M(1)]
	},
	embeddedAgent: {
		agent: [pe(k(2))],
		reveal: [j(1), b()]
	},
	esmarTuek: {
		agent: [T({ spice: 1 }, S("spacingGuild"), y())],
		reveal: [v("spice", 2), v("solari", 2)]
	},
	courtIntrigue: {
		agent: [C("exchangeIntrigue", 1)],
		reveal: [j(1), M(1)]
	},
	sayyadina: {
		agent: [T({ water: 3 }, v("vp", 1))],
		reveal: [fe(j(3))]
	},
	imperialShockTrooper: {
		agent: [],
		reveal: [
			j(1),
			M(2),
			le("emperorAgent", [M(3)])
		]
	},
	appropriate: {
		agent: [he("emperor", A(0, !0))],
		reveal: [j(2)],
		acquire: [k()]
	},
	desertAmbush: {
		agent: [w("ambush")],
		reveal: [j(1), M(1)]
	},
	inTheShadows: {
		agent: [he("beneGesserit", O(1, [{
			kind: "influence",
			n: 1,
			exclude: ["beneGesserit"]
		}]))],
		reveal: [S("beneGesserit")]
	},
	satelliteBan: {
		agent: [O(1, [v("spice", 1), v("water", 1)])],
		reveal: [j(1), de(2)]
	},
	freighterFleet: {
		agent: [],
		reveal: [k()]
	},
	imperialBashar: {
		agent: [E([x()], [D()])],
		reveal: [
			j(1),
			M(2),
			w("bashar")
		]
	},
	jamis: {
		agent: [D()],
		reveal: [j(1), M(2)]
	},
	landingRights: {
		agent: [k()],
		reveal: [j(2)]
	},
	waterPeddler: {
		agent: [],
		reveal: [v("water", 1)],
		acquire: [v("water", 1)]
	},
	treachery: {
		agent: [D("self", void 0, !0)],
		reveal: [C("recruitDeploy", 2)]
	},
	truthsayer: {
		agent: [O(1, [y()])],
		reveal: [j(1), M(1)]
	},
	spiceTrader: {
		agent: [he("fremen", O(1, [v("spice", 2)]))],
		reveal: [j(2), M(1)]
	},
	ixianEngineer: {
		agent: [A()],
		reveal: [le("techs", [D("self", [v("vp", 1)])], void 0, 3)]
	},
	webOfPower: {
		agent: [
			he("emperor", v("solari", 2)),
			he("spacingGuild", y()),
			he("fremen", v("water", 1))
		],
		reveal: [j(1), S()]
	},
	weirdingWay: {
		agent: [C("extraTurn")],
		reveal: [j(1), M(2)]
	},
	negotiatedWithdrawal: {
		agent: [],
		reveal: [j(2), de(3, !0, !0, [S()])],
		acquire: [x()]
	},
	fullScaleAssault: {
		agent: [x(2)],
		reveal: [j(2), w("fullAssault", 3)],
		acquire: [{
			kind: "dread",
			n: 1
		}]
	}
}, _e = [
	{
		id: "vladimirHarkonnen",
		nameKey: "games.duneimperium.leaders.vladimirHarkonnen.name",
		textKey: "games.duneimperium.leaders.vladimirHarkonnen.text",
		ix: !1
	},
	{
		id: "glossuRabban",
		nameKey: "games.duneimperium.leaders.glossuRabban.name",
		textKey: "games.duneimperium.leaders.glossuRabban.text",
		ix: !1
	},
	{
		id: "ilbanRichese",
		nameKey: "games.duneimperium.leaders.ilbanRichese.name",
		textKey: "games.duneimperium.leaders.ilbanRichese.text",
		ix: !1
	},
	{
		id: "helenaRichese",
		nameKey: "games.duneimperium.leaders.helenaRichese.name",
		textKey: "games.duneimperium.leaders.helenaRichese.text",
		ix: !1
	},
	{
		id: "letoAtreides",
		nameKey: "games.duneimperium.leaders.letoAtreides.name",
		textKey: "games.duneimperium.leaders.letoAtreides.text",
		ix: !1
	},
	{
		id: "paulAtreides",
		nameKey: "games.duneimperium.leaders.paulAtreides.name",
		textKey: "games.duneimperium.leaders.paulAtreides.text",
		ix: !1
	},
	{
		id: "arianaThorvald",
		nameKey: "games.duneimperium.leaders.arianaThorvald.name",
		textKey: "games.duneimperium.leaders.arianaThorvald.text",
		ix: !1
	},
	{
		id: "memnonThorvald",
		nameKey: "games.duneimperium.leaders.memnonThorvald.name",
		textKey: "games.duneimperium.leaders.memnonThorvald.text",
		ix: !1
	},
	{
		id: "armandEcaz",
		nameKey: "games.duneimperium.leaders.armandEcaz.name",
		textKey: "games.duneimperium.leaders.armandEcaz.text",
		ix: !0
	},
	{
		id: "ilesaEcaz",
		nameKey: "games.duneimperium.leaders.ilesaEcaz.name",
		textKey: "games.duneimperium.leaders.ilesaEcaz.text",
		ix: !0
	},
	{
		id: "rhomburVernius",
		nameKey: "games.duneimperium.leaders.rhomburVernius.name",
		textKey: "games.duneimperium.leaders.rhomburVernius.text",
		ix: !0
	},
	{
		id: "tessiaVernius",
		nameKey: "games.duneimperium.leaders.tessiaVernius.name",
		textKey: "games.duneimperium.leaders.tessiaVernius.text",
		ix: !0
	},
	{
		id: "yunaMoritani",
		nameKey: "games.duneimperium.leaders.yunaMoritani.name",
		textKey: "games.duneimperium.leaders.yunaMoritani.text",
		ix: !0
	},
	{
		id: "hundroMoritani",
		nameKey: "games.duneimperium.leaders.hundroMoritani.name",
		textKey: "games.duneimperium.leaders.hundroMoritani.text",
		ix: !0
	}
], ve = {
	bribery: {
		id: "bribery",
		nameKey: "games.duneimperium.intrigues.bribery.name",
		textKey: "games.duneimperium.intrigues.bribery.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	refocus: {
		id: "refocus",
		nameKey: "games.duneimperium.intrigues.refocus.name",
		textKey: "games.duneimperium.intrigues.refocus.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	ambush: {
		id: "ambush",
		nameKey: "games.duneimperium.intrigues.ambush.name",
		textKey: "games.duneimperium.intrigues.ambush.text",
		ix: !1,
		count: 2,
		timing: ["combat"]
	},
	alliedArmada: {
		id: "alliedArmada",
		nameKey: "games.duneimperium.intrigues.alliedArmada.name",
		textKey: "games.duneimperium.intrigues.alliedArmada.text",
		ix: !1,
		count: 1,
		timing: ["combat"]
	},
	favoredSubject: {
		id: "favoredSubject",
		nameKey: "games.duneimperium.intrigues.favoredSubject.name",
		textKey: "games.duneimperium.intrigues.favoredSubject.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	demandRespect: {
		id: "demandRespect",
		nameKey: "games.duneimperium.intrigues.demandRespect.name",
		textKey: "games.duneimperium.intrigues.demandRespect.text",
		ix: !1,
		count: 1,
		timing: ["win"]
	},
	poisonSnooper: {
		id: "poisonSnooper",
		nameKey: "games.duneimperium.intrigues.poisonSnooper.name",
		textKey: "games.duneimperium.intrigues.poisonSnooper.text",
		ix: !1,
		count: 2,
		timing: ["plot"]
	},
	guildAuthorization: {
		id: "guildAuthorization",
		nameKey: "games.duneimperium.intrigues.guildAuthorization.name",
		textKey: "games.duneimperium.intrigues.guildAuthorization.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	dispatchAnEnvoy: {
		id: "dispatchAnEnvoy",
		nameKey: "games.duneimperium.intrigues.dispatchAnEnvoy.name",
		textKey: "games.duneimperium.intrigues.dispatchAnEnvoy.text",
		ix: !1,
		count: 2,
		timing: ["plot"]
	},
	infiltrate: {
		id: "infiltrate",
		nameKey: "games.duneimperium.intrigues.infiltrate.name",
		textKey: "games.duneimperium.intrigues.infiltrate.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	knowTheirWays: {
		id: "knowTheirWays",
		nameKey: "games.duneimperium.intrigues.knowTheirWays.name",
		textKey: "games.duneimperium.intrigues.knowTheirWays.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	masterTactician: {
		id: "masterTactician",
		nameKey: "games.duneimperium.intrigues.masterTactician.name",
		textKey: "games.duneimperium.intrigues.masterTactician.text",
		ix: !1,
		count: 3,
		timing: ["combat"]
	},
	plansWithinPlans: {
		id: "plansWithinPlans",
		nameKey: "games.duneimperium.intrigues.plansWithinPlans.name",
		textKey: "games.duneimperium.intrigues.plansWithinPlans.text",
		ix: !1,
		count: 1,
		timing: ["end"]
	},
	privateArmy: {
		id: "privateArmy",
		nameKey: "games.duneimperium.intrigues.privateArmy.name",
		textKey: "games.duneimperium.intrigues.privateArmy.text",
		ix: !1,
		count: 2,
		timing: ["combat"]
	},
	doubleCross: {
		id: "doubleCross",
		nameKey: "games.duneimperium.intrigues.doubleCross.name",
		textKey: "games.duneimperium.intrigues.doubleCross.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	councilorsDispensation: {
		id: "councilorsDispensation",
		nameKey: "games.duneimperium.intrigues.councilorsDispensation.name",
		textKey: "games.duneimperium.intrigues.councilorsDispensation.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	cornerTheMarket: {
		id: "cornerTheMarket",
		nameKey: "games.duneimperium.intrigues.cornerTheMarket.name",
		textKey: "games.duneimperium.intrigues.cornerTheMarket.text",
		ix: !1,
		count: 1,
		timing: ["end"]
	},
	charisma: {
		id: "charisma",
		nameKey: "games.duneimperium.intrigues.charisma.name",
		textKey: "games.duneimperium.intrigues.charisma.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	calculatedHire: {
		id: "calculatedHire",
		nameKey: "games.duneimperium.intrigues.calculatedHire.name",
		textKey: "games.duneimperium.intrigues.calculatedHire.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	choamShares: {
		id: "choamShares",
		nameKey: "games.duneimperium.intrigues.choamShares.name",
		textKey: "games.duneimperium.intrigues.choamShares.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	bypassProtocol: {
		id: "bypassProtocol",
		nameKey: "games.duneimperium.intrigues.bypassProtocol.name",
		textKey: "games.duneimperium.intrigues.bypassProtocol.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	recruitmentMission: {
		id: "recruitmentMission",
		nameKey: "games.duneimperium.intrigues.recruitmentMission.name",
		textKey: "games.duneimperium.intrigues.recruitmentMission.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	reinforcements: {
		id: "reinforcements",
		nameKey: "games.duneimperium.intrigues.reinforcements.name",
		textKey: "games.duneimperium.intrigues.reinforcements.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	binduSuspension: {
		id: "binduSuspension",
		nameKey: "games.duneimperium.intrigues.binduSuspension.name",
		textKey: "games.duneimperium.intrigues.binduSuspension.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	secretOfTheSisterhood: {
		id: "secretOfTheSisterhood",
		nameKey: "games.duneimperium.intrigues.secretOfTheSisterhood.name",
		textKey: "games.duneimperium.intrigues.secretOfTheSisterhood.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	rapidMobilization: {
		id: "rapidMobilization",
		nameKey: "games.duneimperium.intrigues.rapidMobilization.name",
		textKey: "games.duneimperium.intrigues.rapidMobilization.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	stagedIncident: {
		id: "stagedIncident",
		nameKey: "games.duneimperium.intrigues.stagedIncident.name",
		textKey: "games.duneimperium.intrigues.stagedIncident.text",
		ix: !1,
		count: 1,
		timing: ["combat"]
	},
	theSleeperMustAwaken: {
		id: "theSleeperMustAwaken",
		nameKey: "games.duneimperium.intrigues.theSleeperMustAwaken.name",
		textKey: "games.duneimperium.intrigues.theSleeperMustAwaken.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	tiebreaker: {
		id: "tiebreaker",
		nameKey: "games.duneimperium.intrigues.tiebreaker.name",
		textKey: "games.duneimperium.intrigues.tiebreaker.text",
		ix: !1,
		count: 1,
		timing: ["combat", "end"]
	},
	toTheVictor: {
		id: "toTheVictor",
		nameKey: "games.duneimperium.intrigues.toTheVictor.name",
		textKey: "games.duneimperium.intrigues.toTheVictor.text",
		ix: !1,
		count: 1,
		timing: ["win"]
	},
	waterPeddlersUnion: {
		id: "waterPeddlersUnion",
		nameKey: "games.duneimperium.intrigues.waterPeddlersUnion.name",
		textKey: "games.duneimperium.intrigues.waterPeddlersUnion.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	windfall: {
		id: "windfall",
		nameKey: "games.duneimperium.intrigues.windfall.name",
		textKey: "games.duneimperium.intrigues.windfall.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	waterOfLife: {
		id: "waterOfLife",
		nameKey: "games.duneimperium.intrigues.waterOfLife.name",
		textKey: "games.duneimperium.intrigues.waterOfLife.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	urgentMission: {
		id: "urgentMission",
		nameKey: "games.duneimperium.intrigues.urgentMission.name",
		textKey: "games.duneimperium.intrigues.urgentMission.text",
		ix: !1,
		count: 1,
		timing: ["plot"]
	},
	diversion: {
		id: "diversion",
		nameKey: "games.duneimperium.intrigues.diversion.name",
		textKey: "games.duneimperium.intrigues.diversion.text",
		ix: !0,
		count: 1,
		timing: ["plot"]
	},
	warChest: {
		id: "warChest",
		nameKey: "games.duneimperium.intrigues.warChest.name",
		textKey: "games.duneimperium.intrigues.warChest.text",
		ix: !0,
		count: 1,
		timing: ["combat", "end"]
	},
	advancedWeaponry: {
		id: "advancedWeaponry",
		nameKey: "games.duneimperium.intrigues.advancedWeaponry.name",
		textKey: "games.duneimperium.intrigues.advancedWeaponry.text",
		ix: !0,
		count: 1,
		timing: ["plot", "combat"]
	},
	secretForces: {
		id: "secretForces",
		nameKey: "games.duneimperium.intrigues.secretForces.name",
		textKey: "games.duneimperium.intrigues.secretForces.text",
		ix: !0,
		count: 1,
		timing: ["plot"]
	},
	grandConspiracy: {
		id: "grandConspiracy",
		nameKey: "games.duneimperium.intrigues.grandConspiracy.name",
		textKey: "games.duneimperium.intrigues.grandConspiracy.text",
		ix: !0,
		count: 1,
		timing: ["end"]
	},
	cull: {
		id: "cull",
		nameKey: "games.duneimperium.intrigues.cull.name",
		textKey: "games.duneimperium.intrigues.cull.text",
		ix: !0,
		count: 1,
		timing: ["plot"]
	},
	strategicPush: {
		id: "strategicPush",
		nameKey: "games.duneimperium.intrigues.strategicPush.name",
		textKey: "games.duneimperium.intrigues.strategicPush.text",
		ix: !0,
		count: 1,
		timing: ["combat"]
	},
	blackmail: {
		id: "blackmail",
		nameKey: "games.duneimperium.intrigues.blackmail.name",
		textKey: "games.duneimperium.intrigues.blackmail.text",
		ix: !0,
		count: 1,
		timing: ["combat"]
	},
	machineCulture: {
		id: "machineCulture",
		nameKey: "games.duneimperium.intrigues.machineCulture.name",
		textKey: "games.duneimperium.intrigues.machineCulture.text",
		ix: !0,
		count: 1,
		timing: ["plot", "end"]
	},
	cannonTurrets: {
		id: "cannonTurrets",
		nameKey: "games.duneimperium.intrigues.cannonTurrets.name",
		textKey: "games.duneimperium.intrigues.cannonTurrets.text",
		ix: !0,
		count: 1,
		timing: ["combat"]
	},
	expedite: {
		id: "expedite",
		nameKey: "games.duneimperium.intrigues.expedite.name",
		textKey: "games.duneimperium.intrigues.expedite.text",
		ix: !0,
		count: 1,
		timing: ["plot"]
	},
	ixianProbe: {
		id: "ixianProbe",
		nameKey: "games.duneimperium.intrigues.ixianProbe.name",
		textKey: "games.duneimperium.intrigues.ixianProbe.text",
		ix: !0,
		count: 1,
		timing: ["plot"]
	},
	secondWave: {
		id: "secondWave",
		nameKey: "games.duneimperium.intrigues.secondWave.name",
		textKey: "games.duneimperium.intrigues.secondWave.text",
		ix: !0,
		count: 1,
		timing: ["combat"]
	},
	glimpseThePath: {
		id: "glimpseThePath",
		nameKey: "games.duneimperium.intrigues.glimpseThePath.name",
		textKey: "games.duneimperium.intrigues.glimpseThePath.text",
		ix: !0,
		count: 1,
		timing: ["plot"]
	},
	finesse: {
		id: "finesse",
		nameKey: "games.duneimperium.intrigues.finesse.name",
		textKey: "games.duneimperium.intrigues.finesse.text",
		ix: !0,
		count: 1,
		timing: ["plot", "combat"]
	},
	strongarm: {
		id: "strongarm",
		nameKey: "games.duneimperium.intrigues.strongarm.name",
		textKey: "games.duneimperium.intrigues.strongarm.text",
		ix: !0,
		count: 1,
		timing: ["plot"]
	},
	quidProQuo: {
		id: "quidProQuo",
		nameKey: "games.duneimperium.intrigues.quidProQuo.name",
		textKey: "games.duneimperium.intrigues.quidProQuo.text",
		ix: !0,
		count: 1,
		timing: ["plot"]
	}
}, N = {
	windtraps: {
		id: "windtraps",
		nameKey: "games.duneimperium.techs.windtraps.name",
		textKey: "games.duneimperium.techs.windtraps.text",
		cost: 2,
		hagal: !0
	},
	detonationDevices: {
		id: "detonationDevices",
		nameKey: "games.duneimperium.techs.detonationDevices.name",
		textKey: "games.duneimperium.techs.detonationDevices.text",
		cost: 3,
		hagal: !0
	},
	memocorders: {
		id: "memocorders",
		nameKey: "games.duneimperium.techs.memocorders.name",
		textKey: "games.duneimperium.techs.memocorders.text",
		cost: 2,
		hagal: !0
	},
	flagship: {
		id: "flagship",
		nameKey: "games.duneimperium.techs.flagship.name",
		textKey: "games.duneimperium.techs.flagship.text",
		cost: 8,
		hagal: !0
	},
	spaceport: {
		id: "spaceport",
		nameKey: "games.duneimperium.techs.spaceport.name",
		textKey: "games.duneimperium.techs.spaceport.text",
		cost: 5,
		hagal: !1
	},
	artillery: {
		id: "artillery",
		nameKey: "games.duneimperium.techs.artillery.name",
		textKey: "games.duneimperium.techs.artillery.text",
		cost: 1,
		hagal: !1
	},
	holoprojectors: {
		id: "holoprojectors",
		nameKey: "games.duneimperium.techs.holoprojectors.name",
		textKey: "games.duneimperium.techs.holoprojectors.text",
		cost: 3,
		hagal: !1
	},
	restrictedOrdnance: {
		id: "restrictedOrdnance",
		nameKey: "games.duneimperium.techs.restrictedOrdnance.name",
		textKey: "games.duneimperium.techs.restrictedOrdnance.text",
		cost: 4,
		hagal: !1
	},
	shuttleFleet: {
		id: "shuttleFleet",
		nameKey: "games.duneimperium.techs.shuttleFleet.name",
		textKey: "games.duneimperium.techs.shuttleFleet.text",
		cost: 6,
		hagal: !0
	},
	spySatellites: {
		id: "spySatellites",
		nameKey: "games.duneimperium.techs.spySatellites.name",
		textKey: "games.duneimperium.techs.spySatellites.text",
		cost: 4,
		hagal: !0
	},
	disposalFacility: {
		id: "disposalFacility",
		nameKey: "games.duneimperium.techs.disposalFacility.name",
		textKey: "games.duneimperium.techs.disposalFacility.text",
		cost: 3,
		hagal: !1
	},
	chaumurky: {
		id: "chaumurky",
		nameKey: "games.duneimperium.techs.chaumurky.name",
		textKey: "games.duneimperium.techs.chaumurky.text",
		cost: 4,
		hagal: !0
	},
	sonicSnoopers: {
		id: "sonicSnoopers",
		nameKey: "games.duneimperium.techs.sonicSnoopers.name",
		textKey: "games.duneimperium.techs.sonicSnoopers.text",
		cost: 2,
		hagal: !0
	},
	trainingDrones: {
		id: "trainingDrones",
		nameKey: "games.duneimperium.techs.trainingDrones.name",
		textKey: "games.duneimperium.techs.trainingDrones.text",
		cost: 3,
		hagal: !0
	},
	troopTransports: {
		id: "troopTransports",
		nameKey: "games.duneimperium.techs.troopTransports.name",
		textKey: "games.duneimperium.techs.troopTransports.text",
		cost: 2,
		hagal: !0
	},
	holtzmanEngine: {
		id: "holtzmanEngine",
		nameKey: "games.duneimperium.techs.holtzmanEngine.name",
		textKey: "games.duneimperium.techs.holtzmanEngine.text",
		cost: 6,
		hagal: !0
	},
	minimicFilm: {
		id: "minimicFilm",
		nameKey: "games.duneimperium.techs.minimicFilm.name",
		textKey: "games.duneimperium.techs.minimicFilm.text",
		cost: 2,
		hagal: !1
	},
	invasionShips: {
		id: "invasionShips",
		nameKey: "games.duneimperium.techs.invasionShips.name",
		textKey: "games.duneimperium.techs.invasionShips.text",
		cost: 5,
		hagal: !0
	}
}, ye = {
	skirmishA: "games.duneimperium.conflicts.skirmishA",
	skirmishB: "games.duneimperium.conflicts.skirmishB",
	skirmishC: "games.duneimperium.conflicts.skirmishC",
	skirmishD: "games.duneimperium.conflicts.skirmishD",
	skirmishE: "games.duneimperium.conflicts.skirmishE",
	skirmishF: "games.duneimperium.conflicts.skirmishF",
	desertPower: "games.duneimperium.conflicts.desertPower",
	raidStockpiles: "games.duneimperium.conflicts.raidStockpiles",
	cloakAndDagger: "games.duneimperium.conflicts.cloakAndDagger",
	machinations: "games.duneimperium.conflicts.machinations",
	sortThroughTheChaos: "games.duneimperium.conflicts.sortThroughTheChaos",
	terriblePurpose: "games.duneimperium.conflicts.terriblePurpose",
	guildBankRaid: "games.duneimperium.conflicts.guildBankRaid",
	siegeOfArrakeen: "games.duneimperium.conflicts.siegeOfArrakeen",
	siegeOfCarthag: "games.duneimperium.conflicts.siegeOfCarthag",
	secureImperialBasin: "games.duneimperium.conflicts.secureImperialBasin",
	tradeMonopoly: "games.duneimperium.conflicts.tradeMonopoly",
	battleForImperialBasin: "games.duneimperium.conflicts.battleForImperialBasin",
	grandVision: "games.duneimperium.conflicts.grandVision",
	battleForCarthag: "games.duneimperium.conflicts.battleForCarthag",
	battleForArrakeen: "games.duneimperium.conflicts.battleForArrakeen",
	economicSupremacy: "games.duneimperium.conflicts.economicSupremacy"
}, P = [
	{
		id: "conspire",
		nameKey: "games.duneimperium.spaces.conspire",
		icon: "emperor",
		cost: { spice: 4 },
		effects: [
			S("emperor"),
			v("solari", 5),
			x(2),
			b()
		]
	},
	{
		id: "wealth",
		nameKey: "games.duneimperium.spaces.wealth",
		icon: "emperor",
		effects: [S("emperor"), v("solari", 2)]
	},
	{
		id: "heighliner",
		nameKey: "games.duneimperium.spaces.heighliner",
		icon: "spacingGuild",
		cost: { spice: 6 },
		combat: !0,
		effects: [
			S("spacingGuild"),
			x(5),
			v("water", 2)
		]
	},
	{
		id: "foldspace",
		nameKey: "games.duneimperium.spaces.foldspace",
		icon: "spacingGuild",
		effects: [S("spacingGuild"), C("foldspace")]
	},
	{
		id: "selectiveBreeding",
		nameKey: "games.duneimperium.spaces.selectiveBreeding",
		icon: "beneGesserit",
		cost: { spice: 2 },
		effects: [S("beneGesserit"), D("all", [y(2)])]
	},
	{
		id: "secrets",
		nameKey: "games.duneimperium.spaces.secrets",
		icon: "beneGesserit",
		effects: [
			S("beneGesserit"),
			b(),
			C("stealIntrigues")
		]
	},
	{
		id: "hardyWarriors",
		nameKey: "games.duneimperium.spaces.hardyWarriors",
		icon: "fremen",
		cost: { water: 1 },
		combat: !0,
		effects: [S("fremen"), x(2)]
	},
	{
		id: "stillsuits",
		nameKey: "games.duneimperium.spaces.stillsuits",
		icon: "fremen",
		combat: !0,
		effects: [S("fremen"), v("water", 1)]
	},
	{
		id: "highCouncil",
		nameKey: "games.duneimperium.spaces.highCouncil",
		icon: "green",
		cost: { solari: 5 },
		effects: [C("council")]
	},
	{
		id: "mentat",
		nameKey: "games.duneimperium.spaces.mentat",
		icon: "green",
		cost: { solari: 2 },
		effects: [y(), C("mentat")]
	},
	{
		id: "swordmaster",
		nameKey: "games.duneimperium.spaces.swordmaster",
		icon: "green",
		cost: { solari: 8 },
		effects: [C("swordmaster")]
	},
	{
		id: "rallyTroops",
		nameKey: "games.duneimperium.spaces.rallyTroops",
		icon: "green",
		baseOnly: !0,
		cost: { solari: 4 },
		effects: [x(4)]
	},
	{
		id: "hallOfOratory",
		nameKey: "games.duneimperium.spaces.hallOfOratory",
		icon: "green",
		baseOnly: !0,
		effects: [x(), v("persuasion", 1)]
	},
	{
		id: "secureContract",
		nameKey: "games.duneimperium.spaces.secureContract",
		icon: "yellow",
		baseOnly: !0,
		effects: [v("solari", 3)]
	},
	{
		id: "sellMelange",
		nameKey: "games.duneimperium.spaces.sellMelange",
		icon: "yellow",
		baseOnly: !0,
		effects: []
	},
	{
		id: "arrakeen",
		nameKey: "games.duneimperium.spaces.arrakeen",
		icon: "blue",
		combat: !0,
		effects: [x(), y()]
	},
	{
		id: "carthag",
		nameKey: "games.duneimperium.spaces.carthag",
		icon: "blue",
		combat: !0,
		effects: [x(), b()]
	},
	{
		id: "researchStation",
		nameKey: "games.duneimperium.spaces.researchStation",
		icon: "blue",
		combat: !0,
		cost: { water: 2 },
		effects: [y(3)]
	},
	{
		id: "sietchTabr",
		nameKey: "games.duneimperium.spaces.sietchTabr",
		icon: "blue",
		combat: !0,
		requires: "fremen",
		effects: [x(), v("water", 1)]
	},
	{
		id: "imperialBasin",
		nameKey: "games.duneimperium.spaces.imperialBasin",
		icon: "yellow",
		combat: !0,
		harvest: 1,
		effects: [C("harvest")]
	},
	{
		id: "haggaBasin",
		nameKey: "games.duneimperium.spaces.haggaBasin",
		icon: "yellow",
		combat: !0,
		harvest: 2,
		cost: { water: 1 },
		effects: [C("harvest")]
	},
	{
		id: "theGreatFlat",
		nameKey: "games.duneimperium.spaces.theGreatFlat",
		icon: "yellow",
		combat: !0,
		harvest: 3,
		cost: { water: 2 },
		effects: [C("harvest")]
	},
	{
		id: "smuggling",
		nameKey: "games.duneimperium.spaces.smuggling",
		icon: "yellow",
		ix: !0,
		effects: [k(), v("solari", 1)]
	},
	{
		id: "interstellarShipping",
		nameKey: "games.duneimperium.spaces.interstellarShipping",
		icon: "yellow",
		ix: !0,
		requires: "spacingGuild",
		effects: [k(2)]
	},
	{
		id: "techNegotiation",
		nameKey: "games.duneimperium.spaces.techNegotiation",
		icon: "green",
		ix: !0,
		effects: [v("persuasion", 1), A(1, !1, !0)]
	},
	{
		id: "dreadnought",
		nameKey: "games.duneimperium.spaces.dreadnought",
		icon: "green",
		ix: !0,
		cost: { solari: 3 },
		effects: [{
			kind: "dread",
			n: 1
		}, A()]
	}
], F = Object.fromEntries(P.map((e) => [e.id, e])), be = [
	"imperialBasin",
	"arrakeen",
	"carthag"
], xe = {
	emperor: [v("solari", 2)],
	spacingGuild: [v("solari", 3)],
	beneGesserit: [b()],
	fremen: [v("water", 1)]
};
C("dividend"), C("shippingTroops"), S();
var Se = [T({ solari: 6 }, v("vp", 1)), T({ spice: 4 }, v("vp", 1))], I = (e) => v("vp", e), L = (e) => v("spice", e), R = (e) => v("solari", e), z = (e) => v("water", e), Ce = (e) => ({
	kind: "special",
	id: "control",
	arg: e
}), B = (e, t, n, r = !1, i) => ({
	id: e,
	nameKey: ye[e],
	level: t,
	rewards: n,
	ix: r,
	control: i
}), we = [
	B("skirmishA", 1, [
		[I(1)],
		[b(), R(2)],
		[R(2)]
	]),
	B("skirmishB", 1, [
		[I(1)],
		[z(1)],
		[L(1)]
	]),
	B("skirmishC", 1, [
		[S(), L(1)],
		[L(2)],
		[L(1)]
	]),
	B("skirmishD", 1, [
		[S(), R(2)],
		[R(3)],
		[R(2)]
	]),
	B("skirmishE", 1, [
		[k(), L(1)],
		[R(3)],
		[R(2)]
	], !0),
	B("skirmishF", 1, [
		[k(), x()],
		[L(2)],
		[L(1)]
	], !0),
	B("desertPower", 2, [
		[I(1), z(1)],
		[z(1), L(1)],
		[L(1)]
	]),
	B("raidStockpiles", 2, [
		[b(), L(3)],
		[L(2)],
		[L(1)]
	]),
	B("cloakAndDagger", 2, [
		[S(), b(2)],
		[b(), L(1)],
		[E([b()], [L(1)])]
	]),
	B("machinations", 2, [
		[C("twoFactions")],
		[z(1), R(2)],
		[z(1)]
	]),
	B("sortThroughTheChaos", 2, [
		[
			C("mentatNext"),
			b(),
			R(2)
		],
		[b(), R(2)],
		[R(2)]
	]),
	B("terriblePurpose", 2, [
		[I(1), D()],
		[z(1), L(1)],
		[L(1)]
	]),
	B("guildBankRaid", 2, [
		[R(6)],
		[R(4)],
		[R(2)]
	]),
	B("siegeOfArrakeen", 2, [
		[I(1), Ce("arrakeen")],
		[R(4)],
		[R(2)]
	], !1, "arrakeen"),
	B("siegeOfCarthag", 2, [
		[I(1), Ce("carthag")],
		[b(), L(1)],
		[L(1)]
	], !1, "carthag"),
	B("secureImperialBasin", 2, [
		[I(1), Ce("imperialBasin")],
		[z(2)],
		[z(1)]
	], !1, "imperialBasin"),
	B("tradeMonopoly", 2, [
		[k(2), x()],
		[b(), z(1)],
		[E([b()], [z(1)])]
	], !0),
	B("battleForImperialBasin", 3, [
		[I(2), Ce("imperialBasin")],
		[L(5)],
		[L(3)]
	], !1, "imperialBasin"),
	B("grandVision", 3, [
		[S(void 0, 2), b()],
		[b(), L(3)],
		[L(3)]
	]),
	B("battleForCarthag", 3, [
		[I(2), Ce("carthag")],
		[b(), L(3)],
		[L(3)]
	], !1, "carthag"),
	B("battleForArrakeen", 3, [
		[I(2), Ce("arrakeen")],
		[C("arrakeenSecond")],
		[b(), R(2)]
	], !1, "arrakeen"),
	B("economicSupremacy", 3, [
		[I(1), ...Se],
		[I(1)],
		[L(2), R(2)]
	], !0)
], Te = Object.fromEntries(we.map((e) => [e.id, e])), Ee = {
	bribery: { plot: [T({ solari: 2 }, S())] },
	refocus: { plot: [C("refocus"), y()] },
	ambush: { combat: [v("sword", 4)] },
	alliedArmada: { combat: [T({ spice: 2 }, v("sword", 7))] },
	favoredSubject: { plot: [S("emperor")] },
	demandRespect: { win: [E([S()], [T({ spice: 2 }, S(void 0, 2))])] },
	poisonSnooper: { plot: [C("peek")] },
	guildAuthorization: { plot: [S("spacingGuild")] },
	dispatchAnEnvoy: { plot: [w("envoy")] },
	infiltrate: { plot: [w("infiltrate")] },
	knowTheirWays: { plot: [S("fremen")] },
	masterTactician: { combat: [E([v("sword", 3)], [de(3)])] },
	plansWithinPlans: { end: [C("scorePlans")] },
	privateArmy: { combat: [T({ spice: 2 }, v("sword", 5))] },
	doubleCross: { plot: [T({ solari: 1 }, C("doubleCross"))] },
	councilorsDispensation: { plot: [v("spice", 2)] },
	cornerTheMarket: { end: [C("scoreCorner")] },
	charisma: { plot: [C("revealPersuasion", 2)] },
	calculatedHire: { plot: [T({ spice: 1 }, C("mentat"))] },
	choamShares: { plot: [T({ solari: 7 }, v("vp", 1))] },
	bypassProtocol: { plot: [E([C("freeCard", 3)], [T({ spice: 2 }, C("freeCardTop", 5))])] },
	recruitmentMission: { plot: [C("revealPersuasion", 1), w("recruitment")] },
	reinforcements: { plot: [T({ solari: 3 }, C("reinforcements"))] },
	binduSuspension: { plot: [y(), C("bindu")] },
	secretOfTheSisterhood: { plot: [S("beneGesserit")] },
	rapidMobilization: { plot: [ue(12)] },
	stagedIncident: { combat: [C("stagedIncident")] },
	theSleeperMustAwaken: { plot: [T({ spice: 4 }, v("vp", 1))] },
	tiebreaker: {
		combat: [v("sword", 2)],
		end: [v("spice", 10)]
	},
	toTheVictor: { win: [v("spice", 3)] },
	waterPeddlersUnion: { plot: [v("water", 1)] },
	windfall: { plot: [v("solari", 2)] },
	waterOfLife: { plot: [T({
		water: 1,
		spice: 1
	}, y(3))] },
	urgentMission: { plot: [C("recallAgent")] },
	diversion: { plot: [k()] },
	warChest: {
		combat: [T({ solari: 2 }, v("sword", 4))],
		end: [v("vp", 1)]
	},
	advancedWeaponry: {
		plot: [T({ solari: 3 }, {
			kind: "dread",
			n: 1
		})],
		combat: [v("sword", 4)]
	},
	secretForces: { plot: [x(2)] },
	grandConspiracy: { end: [C("scoreGrand")] },
	cull: { plot: [T({ solari: 1 }, D("all", void 0, !0))] },
	strategicPush: { combat: [v("sword", 2), w("strategicPush")] },
	blackmail: { combat: [C("blackmail")] },
	machineCulture: {
		plot: [A()],
		end: [v("vp", 1)]
	},
	cannonTurrets: { combat: [v("sword", 2), C("cannonTurrets")] },
	expedite: { plot: [T({ spice: 1 }, k())] },
	ixianProbe: { plot: [O(2, [y(2)], !0)] },
	secondWave: { combat: [v("sword", 2), ue(2, !0)] },
	glimpseThePath: { plot: [T({ spice: 1 }, v("water", 1), y())] },
	finesse: {
		plot: [C("finesse")],
		combat: [v("sword", 2)]
	},
	strongarm: { plot: [C("strongarm")] },
	quidProQuo: { plot: [T({ spice: 2 }, C("quidProQuo"))] }
};
function De(e) {
	return e.map((e) => e.kind === "pay" ? {
		...e,
		required: !0,
		effects: De(e.effects)
	} : e.kind === "choice" ? {
		...e,
		options: e.options.map(De)
	} : e);
}
//#endregion
//#region src/games/duneimperium/engine.ts
var V = (e) => e.humans.length === 1, Oe = (e, t) => !t.npc || V(e), ke = (e) => [
	...e.deck,
	...e.hand,
	...e.discard,
	...e.played,
	...e.revealedCards,
	...e.aside ? [e.aside] : []
], H = (e) => 12 - e.garrison - e.combat - e.negotiators, Ae = (e, t) => t.dreadGarrison + t.dreadCombat + e.dreadControl.filter((e) => e.rid === t.rid).length, je = (e, t) => {
	let n = `c${e.serial++}`;
	return e.cardIds[n] = t, {
		id: t,
		uid: n
	};
}, Me = (e) => e.combat + e.dreadCombat, Ne = (e) => ({
	rid: e,
	mode: "start",
	card: null,
	space: null,
	selected: null,
	relocate: null,
	recruited: 0,
	recruitedDread: 0,
	deployed: 0,
	deployedTroops: 0,
	deployAllowance: 0,
	extra: !1,
	started: !1
});
function U(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rngCursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Pe(e, t, n, r, i) {
	e.log.push({
		key: t,
		rid: n,
		source: r,
		n: i
	}), e.log.length > 36 && e.log.shift();
}
var Fe = (e, t, n, r) => ({
	id: e.serial++,
	owner: t,
	source: n,
	effect: r
});
function W(e, t, n, r, i = !0) {
	let a = r.map((r) => Fe(e, t, n, r));
	e.queue = i ? [...a, ...e.queue] : [...e.queue, ...a];
}
function G(e, t, n, r) {
	e.pool.push(...r.map((r) => Fe(e, t, n, r)));
}
function Ie(e, t) {
	if (!e.players[t].npc) return t;
	let n = e.order.indexOf(e.first);
	return Array.from({ length: e.order.length }, (t, r) => e.order[(n + r) % e.order.length]).find((t) => !e.players[t].npc);
}
function K(e, t, n, r, i, a = !1) {
	let o = i.filter((n) => tt(e, e.players[t], n.effects));
	if (a && o.push({
		id: "no",
		key: "games.duneimperium.skip",
		effects: []
	}), o.length) {
		if (e.players[t].npc && o.length === 1) {
			W(e, t, n, o[0].effects);
			return;
		}
		e.decision = {
			owner: Ie(e, t),
			for: t,
			source: n,
			key: r,
			options: o
		};
	}
}
function q(e, t, n = "games.duneimperium.confirm") {
	return {
		id: e,
		key: n,
		effects: t
	};
}
function Le(e, t) {
	return Object.entries(t).every(([t, n]) => e[t] >= n);
}
function Re(e, t) {
	for (let [n, r] of Object.entries(t)) e[n] -= r;
}
function ze(e, t) {
	if (t.npc && V(e)) {
		for (let [n, r] of [
			["solari", 7],
			["water", 3],
			["spice", 7]
		]) if (!(n === "spice" && e.config.ix && e.conflict && Te[e.conflict].level < 3)) for (; t[n] >= r;) t[n] -= r, t.vp++;
		for (; t.intrigues.length >= 3;) e.intrigueDiscard.push(...t.intrigues.splice(0, 3)), t.vp++;
	}
}
function J(e, t, n, r, i) {
	(Oe(e, t) || n === "sword") && (n === "solari" && r > 0 && t.leader === "yunaMoritani" && !t.npc && e.phase === "turns" && e.active === t.rid && r++, n === "sword" && e.turn.mode === "reveal" && t.rid === e.turn.rid && t.revealedCards.some((e) => e.uid === i) ? t.swordCards[i] = (t.swordCards[i] ?? 0) + r : t[n] += r, ze(e, t));
}
function Be(e, t, n) {
	if (Oe(e, t)) {
		for (let r = 0; r < n; r++) {
			e.intrigueDeck.length || (e.intrigueDeck = U(e, e.intrigueDiscard), e.intrigueDiscard = []);
			let n = e.intrigueDeck.shift();
			n && t.intrigues.push(n);
		}
		ze(e, t);
	}
}
function Ve(e, t, n) {
	t.revealedCards.push(n), t.roundCards.push(n.id), G(e, t.rid, n.uid, ge[n.id].reveal);
}
function He(e, t, n) {
	if (!t.npc) for (let r = 0; r < n; r++) {
		t.deck.length || (t.deck = U(e, t.discard), t.discard = []);
		let n = t.deck.shift();
		if (!n) break;
		e.phase === "turns" && e.turn.rid === t.rid && e.turn.mode === "reveal" ? Ve(e, t, n) : t.hand.push(n);
	}
}
function Ue(e, t, n) {
	let r = Math.min(n, H(t));
	return t.garrison += r, e.phase === "turns" && e.turn.rid === t.rid && e.turn.mode !== "reveal" && (e.turn.recruited += r), r;
}
function We(e, t, n) {
	let r = Math.min(n, 2 - Ae(e, t));
	return t.dreadGarrison += r, e.phase === "turns" && e.turn.rid === t.rid && e.turn.mode !== "reveal" && (e.turn.recruitedDread += r), r;
}
function Ge(e, t, n, r, i) {
	switch (n) {
		case "bond": return [...t.played, ...t.revealedCards].filter((e) => g[e.id].factions.includes("fremen")).length >= 2;
		case "bg": return t.played.filter((e) => g[e.id].factions.includes("beneGesserit")).length >= 2;
		case "alliance": return r ? e.alliance[r] === t.rid : _.some((n) => e.alliance[n] === t.rid);
		case "friendship": return !!r && t.influence[r] >= (i ?? 2);
		case "council": return t.council;
		case "techs": return t.techs.length >= (i ?? 3);
		case "emperorAgent": return P.some((n) => n.icon === "emperor" && e.agents[n.id]?.includes(t.rid));
	}
}
function Ke(e, t, n) {
	let r = e.alliance[t];
	r !== n && (r && Oe(e, e.players[r]) && e.players[r].vp--, e.alliance[t] = n, n && Oe(e, e.players[n]) && e.players[n].vp++);
}
function qe(e, t, n, r, i) {
	let a = t.influence[n];
	t.influence[n] = Math.min(6, Math.max(0, a + r)), Oe(e, t) && (t.vp += Number(t.influence[n] >= 2) - Number(a >= 2)), a < 4 && t.influence[n] >= 4 && !t.npc && G(e, t.rid, n, xe[n]);
	let o = e.alliance[n];
	if (t.influence[n] >= 4 && (!o || t.influence[n] > e.players[o].influence[n])) Ke(e, n, t.rid);
	else if (o === t.rid && r < 0) {
		let r = Math.max(...e.order.map((t) => e.players[t].influence[n])), a = e.order.filter((t) => e.players[t].influence[n] === r && r >= 4);
		a.includes(t.rid) || (Ke(e, n, null), a.length === 1 ? Ke(e, n, a[0]) : a.length > 1 && K(e, t.rid, i, "games.duneimperium.chooseAlliance", a.map((e) => ({
			...q(e, [{
				kind: "special",
				id: "setAlliance",
				arg: `${n}:${e}`
			}], "games.duneimperium.choosePlayer"),
			target: e
		}))));
	}
	if (!t.npc && t.leader === "tessiaVernius" && t.influence[n] >= 2 && t.snoopers.includes(n)) {
		let r = 4 - t.snoopers.length;
		t.snoopers = t.snoopers.filter((e) => e !== n);
		let i = r === 0 ? [O(1, [v("spice", 1)])] : r === 1 ? xe[n] : r === 2 ? [S(n)] : [...xe[n], S(n)];
		W(e, t.rid, t.leader, i);
	}
}
function Je(e, t) {
	return e.cardIds[t] ? {
		uid: t,
		id: e.cardIds[t]
	} : void 0;
}
function Ye(e, t) {
	for (let n of [
		"hand",
		"discard",
		"played",
		"revealedCards",
		"deck"
	]) {
		let r = e[n].findIndex((e) => e.uid === t);
		if (r >= 0) return e[n].splice(r, 1)[0];
	}
}
function Xe(e, t, n) {
	let r = Ye(t, n);
	r && (g[r.id].set === "reserve" && e.reserve[r.id]++, r.id === "assassinationMission" && J(e, t, "solari", 4, n), g[r.id].unload && W(e, t.rid, n, ge[r.id].reveal), Pe(e, "games.duneimperium.logTrashed", t.rid, r.id));
}
function Ze(e, t, n) {
	let r = t.hand.findIndex((e) => e.uid === n);
	if (r < 0) return;
	let i = t.hand.splice(r, 1)[0];
	t.discard.push(i), g[i.id].unload && W(e, t.rid, n, ge[i.id].reveal);
}
function Qe(e, t, n, r = !1) {
	let i = ge[n.id].acquire ?? [];
	r ? t.deck.unshift(n) : t.techs.includes("spaceport") || t.flags.recruitment && e.turn.mode === "reveal" && e.phase === "turns" ? K(e, t.rid, n.id, "games.duneimperium.chooseAcquire", [q("top", [{
		kind: "special",
		id: "placeAcquired",
		arg: `${n.id}:${n.uid}:top`
	}], "games.duneimperium.toDeck"), q("discard", [{
		kind: "special",
		id: "placeAcquired",
		arg: `${n.id}:${n.uid}:discard`
	}], "games.duneimperium.toDiscard")]) : t.discard.push(n), G(e, t.rid, n.id, i), Pe(e, "games.duneimperium.logAcquired", t.rid, n.id);
}
function $e(e) {
	for (; e.market.length < 5 && e.deck.length;) e.market.push(e.deck.shift());
}
function et(e, t, n) {
	return t.zone === "self" ? [
		...e.played,
		...e.revealedCards,
		...e.discard,
		...e.hand
	].filter((e) => e.uid === n) : t.zone === "top" ? e.deck.slice(0, 1) : t.zone === "play" ? [...e.played, ...e.revealedCards] : [
		...e.hand,
		...e.discard,
		...e.played,
		...e.revealedCards
	];
}
function tt(e, t, n) {
	return n.every((n) => n.kind === "bundle" ? tt(e, t, n.effects) : n.kind === "pay" ? Le(t, n.cost) && tt(e, t, n.effects) : n.kind === "choice" ? !!n.optional || n.options.some((n) => tt(e, t, n)) : n.kind === "discard" ? t.hand.length >= n.n : n.kind === "influence" && n.n < 0 && n.faction ? t.influence[n.faction] >= -n.n : n.kind === "dread" ? e.config.ix && Ae(e, t) < 2 : n.kind === "trash" && n.required && n.zone !== "self" ? et(t, n, "").length > 0 : n.kind === "special" && (n.id === "freeCard" || n.id === "freeCardTop") ? [
		...e.market,
		...t.reserved,
		...Object.entries(e.reserve).filter(([e, t]) => e !== "foldspace" && t > 0).map(([e]) => ({ id: e }))
	].some((e) => g[e.id].cost <= (n.n ?? 1)) : !0);
}
function nt(e, t, n, r) {
	t.garrison -= n, t.combat += n, t.dreadGarrison -= r, t.dreadCombat += r, (e.phase === "turns" || e.phase === "combat") && (t.flags.turnTroops = (t.flags.turnTroops ?? 0) + n, t.leader === "vladimirHarkonnen" && !t.npc && !t.flags.masterstroke && t.flags.turnTroops >= 4 && (t.flags.masterstroke = 1, W(e, t.rid, t.leader, t.secrets.map((e) => S(e))), Pe(e, "games.duneimperium.logMasterstroke", t.rid, t.leader))), e.phase === "turns" && e.turn.rid === t.rid && (e.turn.recruited = Math.max(0, e.turn.recruited - n), e.turn.recruitedDread = Math.max(0, e.turn.recruitedDread - r), e.turn.deployed += n + r, e.turn.deployedTroops += n, t.flags.ambush && n && W(e, t.rid, "desertAmbush", Array.from({ length: n }, () => C("ambushRetreat"))));
}
function rt(e, t) {
	if (Me(t) === 0) return 0;
	let n = Object.values(t.swordCards).filter((e) => e > 0).length, r = t.flags.bashar ?? 0;
	return t.combat * 2 + t.dreadCombat * (t.leader === "rhomburVernius" && !t.npc ? 4 : 3) + t.sword + Object.values(t.swordCards).reduce((e, t) => e + t, 0) + (t.techs.includes("artillery") ? n : 0) + r * Math.max(0, n - 1) + (t.flags.fullAssault ?? 0) * t.dreadCombat;
}
function it(e, t) {
	return t === 0 ? [[]] : e.flatMap((n, r) => it(e.slice(r + 1), t - 1).map((e) => [n, ...e]));
}
function at(e, t, n, r, i = !1) {
	let a = n === "combat" ? e.combat : e.garrison, o = r ? n === "combat" ? e.dreadCombat : e.dreadGarrison : 0, s = [];
	for (let e = 0; e <= Math.min(a, t); e++) for (let n = 0; n <= Math.min(o, t - e); n++) (!i || e + n === t) && s.push({
		troops: e,
		dreads: n
	});
	return s;
}
function ot(e, t, n) {
	return e.techDecks.flatMap((e, r) => {
		let i = e[0];
		if (!i || t.npc && !N[i].hagal) return [];
		let a = Math.max(0, N[i].cost - n.discount), o = [];
		for (let e = 0; e <= Math.min(a, t.negotiators); e++) for (let s of n.solari ? ["spice", "solari"] : ["spice"]) {
			let n = a - e;
			t[s] < n || o.push({
				...q(`t${r}:${e}:${s}`, [{
					kind: "special",
					id: "buyTech",
					arg: `${r}:${e}:${s}:${n}`
				}], "games.duneimperium.buyTech"),
				target: i,
				params: {
					n,
					negotiators: e,
					currency: s
				}
			});
		}
		return o;
	});
}
function st(e, t) {
	let n = e.players[t.owner], r = t.effect, i = t.source;
	switch (r.kind) {
		case "bundle":
			G(e, n.rid, i, r.effects);
			return;
		case "gain":
			J(e, n, r.resource, r.n, i);
			return;
		case "draw":
			He(e, n, r.n);
			return;
		case "intrigue":
			Be(e, n, r.n);
			return;
		case "troop":
			Ue(e, n, r.n);
			return;
		case "dread":
			We(e, n, r.n);
			return;
		case "flag":
			n.flags[r.flag] = (n.flags[r.flag] ?? 0) + (r.n ?? 1);
			return;
		case "if":
			Ge(e, n, r.condition.kind, r.condition.faction, r.condition.n) && G(e, n.rid, i, r.effects);
			return;
		case "pay":
			if (!Le(n, r.cost) || !tt(e, n, r.effects)) return;
			r.required ? (Re(n, r.cost), G(e, n.rid, i, r.effects)) : K(e, n.rid, i, "games.duneimperium.choosePayment", [q("yes", [{
				...r,
				required: !0
			}], "games.duneimperium.pay")], !0);
			return;
		case "choice":
			K(e, n.rid, i, "games.duneimperium.chooseEffect", r.options.map((e, t) => ({
				...q(String(t), [{
					kind: "bundle",
					effects: e
				}], "games.duneimperium.effectOption"),
				params: { n: t + 1 }
			})), !!r.optional);
			return;
		case "influence":
			if (r.faction) qe(e, n, r.faction, r.n, i);
			else {
				let t = _.filter((e) => !r.exclude?.includes(e) && (r.n > 0 ? n.influence[e] < 6 : n.influence[e] >= -r.n));
				if (n.npc) {
					let e = Math.min(...t.map((e) => n.influence[e]));
					t = t.filter((t) => n.influence[t] === e);
				}
				K(e, n.rid, i, "games.duneimperium.chooseFaction", t.map((e) => ({
					...q(e, [S(e, r.n)], "games.duneimperium.factionChoice"),
					target: e,
					n: r.n
				})));
			}
			return;
		case "trash": {
			if (n.npc) return;
			let t = et(n, r, i).map((e) => ({
				...q(e.uid, [{
					kind: "special",
					id: "trashCard",
					arg: e.uid
				}, ...r.after ? [{
					kind: "bundle",
					effects: r.after
				}] : []], "games.duneimperium.trashCard"),
				card: e
			}));
			r.zone === "self" && r.required && t[0] ? W(e, n.rid, i, t[0].effects) : K(e, n.rid, i, "games.duneimperium.chooseTrash", t, !r.required);
			return;
		}
		case "discard": {
			if (n.npc) return;
			let t = r.required ? Math.min(r.n, n.hand.length) : r.n, a = it(n.hand, t).map((e) => ({
				...q(e.map((e) => e.uid).join(","), [...e.map((e) => ({
					kind: "special",
					id: "discardCard",
					arg: e.uid
				})), ...r.after ? [{
					kind: "bundle",
					effects: r.after
				}] : []], "games.duneimperium.discardCards"),
				params: {
					cards: e.map((e) => e.id).join(","),
					n: t
				},
				...e.length === 1 ? { card: e[0] } : {}
			}));
			K(e, n.rid, i, "games.duneimperium.chooseDiscard", a, !r.required);
			return;
		}
		case "negotiator": {
			let t = Math.min(r.n, H(n));
			K(e, n.rid, i, "games.duneimperium.chooseNegotiators", Array.from({ length: t + 1 }, (e, t) => ({
				...q(String(t), [{
					kind: "special",
					id: "addNegotiators",
					n: t
				}], "games.duneimperium.negotiatorsChoice"),
				n: t
			})));
			return;
		}
		case "tech":
			if (n.npc) {
				lt(e, n, r.discount, !!r.negotiate);
				return;
			}
			K(e, n.rid, i, "games.duneimperium.chooseTech", [...ot(e, n, r), ...r.negotiate && H(n) > 0 ? [q("negotiate", [{
				kind: "special",
				id: "addNegotiators",
				n: 1
			}], "games.duneimperium.placeNegotiator")] : []], !0);
			return;
		case "shipment":
			if (r.n > 1 && W(e, n.rid, i, [{
				kind: "shipment",
				n: r.n - 1
			}]), n.npc) {
				n.shipment < 2 ? n.shipment++ : ct(e, n);
				return;
			}
			K(e, n.rid, i, "games.duneimperium.chooseShipping", [...n.shipment < 3 ? [q("advance", [C("advanceShip")], "games.duneimperium.advanceShip")] : [], ...n.shipment > 0 ? [q("recall", [C("recallShip")], "games.duneimperium.recallShip")] : []]);
			return;
		case "deploy":
		case "retreat": {
			let t = at(n, r.n, r.kind === "deploy" ? "garrison" : "combat", !!r.units, !!(r.kind === "retreat" && r.exact)).map(({ troops: e, dreads: t }) => ({
				...q(`${e}:${t}`, [{
					kind: "special",
					id: r.kind === "deploy" ? "deployUnits" : "retreatUnits",
					arg: `${e}:${t}`
				}, ..."after" in r && r.after ? [{
					kind: "bundle",
					effects: r.after
				}] : []], r.kind === "deploy" ? "games.duneimperium.deployUnits" : "games.duneimperium.retreatUnits"),
				params: {
					troops: e,
					dreads: t
				},
				n: e + t
			}));
			K(e, n.rid, i, r.kind === "deploy" ? "games.duneimperium.chooseDeployment" : "games.duneimperium.chooseRetreat", t, r.kind === "retreat" && !!r.exact);
			return;
		}
		case "special":
			ft(e, n, i, r.id, r.arg, r.n);
			return;
	}
}
function ct(e, t) {
	let n = t.shipment;
	t.shipment = 0, n >= 1 && G(e, t.rid, "shipping", [t.npc ? C("dividend") : E([C("dividend")], [v("spice", 2)])]), n >= 2 && G(e, t.rid, "shipping", [C("shippingTroops"), S()]), n >= 3 && G(e, t.rid, "shipping", [A(2)]);
}
function lt(e, t, n, r) {
	if (!V(e) || !e.config.ix) return;
	let i = e.techDecks.map((e, t) => ({
		id: e[0],
		i: t
	})).filter((e) => e.id && N[e.id].hagal && Math.max(0, N[e.id].cost - n - t.negotiators) <= t.spice).sort((e, t) => N[t.id].cost - N[e.id].cost || e.i - t.i);
	if (i[0]) {
		let { id: r, i: a } = i[0], o = Math.max(0, N[r].cost - n), s = Math.min(o, t.negotiators);
		ut(e, t, a, s, "spice", o - s);
	} else r && H(t) > 0 && t.negotiators++;
}
function ut(e, t, n, r, i, a) {
	let o = e.techDecks[n].shift();
	t[i] -= a, t.negotiators -= r, t.techs.push(o);
	let s = {
		windtraps: [v("water", 1)],
		memocorders: [S()],
		flagship: [v("vp", 1)],
		spaceport: [y(2)],
		shuttleFleet: [C("twoFactions")],
		disposalFacility: [D()],
		chaumurky: [b(2)],
		sonicSnoopers: [b()],
		invasionShips: [x(4)]
	};
	G(e, t.rid, o, s[o] ?? []), Pe(e, "games.duneimperium.logTech", t.rid, o);
}
function dt(e, t, n, r) {
	let i = [];
	for (let e of _) if (!(t.influence[e] < 1)) {
		if (r === "blackmail") {
			i.push({
				...q(e, [S(e, -1), v("sword", 5)], "games.duneimperium.factionChoice"),
				target: e,
				n: -1
			});
			continue;
		}
		for (let n of _) {
			if (r === "tessia" && !t.snoopers.includes(n) || t.influence[n] >= 6 && e !== n) continue;
			let a = [S(e, -1), S(n, r === "shift" ? 2 : 1)];
			r === "shift" && t.spice < 2 || i.push({
				...q(`${e}:${n}`, r === "shift" ? [{
					kind: "special",
					id: "shiftInfluence",
					arg: `${e}:${n}`
				}] : a, "games.duneimperium.changeInfluence"),
				params: {
					from: e,
					to: n,
					n: r === "shift" ? 2 : 1
				}
			});
		}
	}
	K(e, t.rid, n, "games.duneimperium.chooseFaction", i, r === "shift" || r === "tessia");
}
function ft(t, n, r, i, a, o = 1) {
	switch (i) {
		case "chooseRivalLeader": {
			let e = _e.filter((e) => (!e.ix || t.config.ix && ["rhomburVernius", "hundroMoritani"].includes(e.id)) && !["paulAtreides", "helenaRichese"].includes(e.id) && !Object.values(t.players).some((t) => t.leader === e.id));
			K(t, n.rid, "rivalLeader", "games.duneimperium.chooseRivalLeader", e.map((e) => ({
				...q(e.id, [{
					kind: "special",
					id: "setRivalLeader",
					arg: e.id
				}], "games.duneimperium.chooseLeader"),
				target: e.id
			})));
			return;
		}
		case "setRivalLeader":
			n.leader = a;
			return;
		case "defend":
			H(n) > 0 && n.combat++;
			return;
		case "shiftInfluence": {
			let [e, i] = a.split(":");
			n.spice -= 2, W(t, n.rid, r, [S(e, -1), S(i, 2)]);
			return;
		}
		case "normalDeploy": {
			let [e, r] = a.split(":").map(Number);
			t.turn.deployAllowance -= Math.max(0, e - t.turn.recruited) + Math.max(0, r - t.turn.recruitedDread), nt(t, n, e, r);
			return;
		}
		case "trashCard":
			Xe(t, n, a);
			return;
		case "discardCard":
			Ze(t, n, a);
			return;
		case "addNegotiators":
			n.negotiators += Math.min(o, H(n));
			return;
		case "deployUnits": {
			let [e, r] = a.split(":").map(Number);
			nt(t, n, e, r);
			return;
		}
		case "retreatUnits": {
			let [e, t] = a.split(":").map(Number);
			n.combat -= e, n.garrison += e, n.dreadCombat -= t, n.dreadGarrison += t;
			return;
		}
		case "buyTech": {
			let [e, r, i, o] = a.split(":");
			ut(t, n, Number(e), Number(r), i, Number(o));
			return;
		}
		case "advanceShip":
			n.shipment++;
			return;
		case "recallShip":
			ct(t, n);
			return;
		case "dividend":
			J(t, n, "solari", 5, r);
			for (let e of t.order) e !== n.rid && J(t, t.players[e], "solari", 1, r);
			return;
		case "shippingTroops": {
			let e = Ue(t, n, n.techs.includes("troopTransports") ? 3 : 2);
			n.techs.includes("troopTransports") && (n.npc ? nt(t, n, Math.min(e, kt(t, n)), 0) : G(t, n.rid, r, [ue(e)]));
			return;
		}
		case "setAlliance": {
			let [e, n] = a.split(":");
			Ke(t, e, n);
			return;
		}
		case "foldspace":
			t.reserve.foldspace > 0 && (t.reserve.foldspace--, Qe(t, n, je(t, "foldspace")));
			return;
		case "placeAcquired": {
			let [e, t, r] = a.split(":"), i = {
				id: e,
				uid: t
			};
			r === "top" ? n.deck.unshift(i) : n.discard.push(i);
			return;
		}
		case "council":
			n.council = !0, n.leader === "memnonThorvald" && !n.npc && G(t, n.rid, n.leader, [S()]);
			return;
		case "swordmaster":
			n.swordmaster = !0, n.agents++;
			return;
		case "mentat":
			t.mentat || (t.mentat = n.rid, n.agents++);
			return;
		case "mentatNext":
			t.mentatNext = n.rid;
			return;
		case "control":
			t.control[a] = n.npc && !V(t) ? null : n.rid;
			return;
		case "twoFactions":
			if (n.npc) {
				let e = Math.min(..._.filter((e) => n.influence[e] < 6).map((e) => n.influence[e]));
				K(t, n.rid, r, "games.duneimperium.chooseFaction", _.filter((t) => n.influence[t] === e).map((e) => ({
					...q(e, [S(e), {
						kind: "influence",
						n: 1,
						exclude: [e]
					}], "games.duneimperium.factionChoice"),
					target: e
				})));
				return;
			}
			K(t, n.rid, r, "games.duneimperium.chooseTwoFactions", _.flatMap((e) => _.filter((t) => t !== e).map((t) => ({
				...q(`${e}:${t}`, [S(e), S(t)], "games.duneimperium.twoFactions"),
				params: {
					from: e,
					to: t
				}
			}))));
			return;
		case "voice":
			K(t, n.rid, r, "games.duneimperium.chooseVoice", P.filter((e) => yt(t, e.id)).map((e) => ({
				...q(e.id, [{
					kind: "special",
					id: "setVoice",
					arg: e.id
				}], "games.duneimperium.chooseSpace"),
				space: e.id
			})));
			return;
		case "setVoice":
			t.voice.push({
				rid: n.rid,
				space: a
			});
			return;
		case "harvest": {
			let e = t.turn.space, i = F[e].harvest * (Je(t, t.turn.card ?? "")?.id === "carryall" ? 2 : 1) + t.bonus[e];
			t.bonus[e] = 0, n.leader === "arianaThorvald" && !n.npc && (i--, G(t, n.rid, n.leader, [y()])), J(t, n, "spice", i, r);
			return;
		}
		case "stealIntrigues":
			for (let r of vt(t, n.rid).filter((e) => e !== n.rid)) {
				let i = t.players[r];
				i.intrigues.length >= 4 && n.intrigues.push(i.intrigues.splice(e(t.seed, t.rngCursor++, i.intrigues.length), 1)[0]);
			}
			return;
		case "bounty":
			t.turn.space && t.agents[t.turn.space].some((e) => e !== n.rid) && J(t, n, "solari", 2, r);
			return;
		case "gunThopter":
			for (let e of t.order) e !== n.rid && t.players[e].garrison > 0 && t.players[e].garrison--;
			return;
		case "mohiam":
			W(t, n.rid, r, vt(t, n.rid).slice(1).map((e) => ({
				kind: "special",
				id: "opponentDiscard",
				arg: e,
				n: 2
			})));
			return;
		case "opponentDiscard":
			W(t, a, r, [O(o, [], !0)]);
			return;
		case "humanity":
			W(t, n.rid, r, vt(t, n.rid).slice(1).map((e) => ({
				kind: "special",
				id: "humanityChoice",
				arg: e
			})));
			return;
		case "humanityChoice": {
			let e = t.players[a], n = [...e.hand.length ? [q("discard", [O(1, [], !0)], "games.duneimperium.discardOne")] : [], ...e.combat ? [q("lose", [{
				kind: "special",
				id: "loseCombat",
				n: 1
			}], "games.duneimperium.loseTroop")] : []];
			K(t, e.rid, r, "games.duneimperium.chooseHumanity", n);
			return;
		}
		case "loseCombat":
			n.combat -= Math.min(o, n.combat);
			return;
		case "ambushRetreat": {
			let e = t.order.filter((e) => e !== n.rid).flatMap((e) => ["troop", "dread"].filter((n) => n === "troop" ? t.players[e].combat > 0 : t.players[e].dreadCombat > 0).map((t) => ({
				...q(`${e}:${t}`, [{
					kind: "special",
					id: "enemyRetreat",
					arg: `${e}:${t}`
				}], "games.duneimperium.enemyRetreat"),
				target: e,
				params: { unit: t }
			})));
			K(t, n.rid, r, "games.duneimperium.chooseOpponent", e, !0);
			return;
		}
		case "enemyRetreat": {
			let [e, n] = a.split(":"), r = t.players[e];
			n === "troop" ? (r.combat--, r.garrison++) : (r.dreadCombat--, r.dreadGarrison++);
			return;
		}
		case "shift":
			dt(t, n, r, "shift");
			return;
		case "finesse":
			dt(t, n, r, "finesse");
			return;
		case "blackmail":
			dt(t, n, r, "blackmail");
			return;
		case "tessia":
			dt(t, n, r, "tessia");
			return;
		case "memory":
			K(t, n.rid, r, "games.duneimperium.chooseMemory", [q("draw", [y()], "games.duneimperium.drawCard"), ...n.discard.filter((e) => g[e.id].factions.includes("beneGesserit")).map((e) => ({
				...q(e.uid, [{
					kind: "special",
					id: "returnMemory",
					arg: e.uid
				}], "games.duneimperium.returnCard"),
				card: e
			}))]);
			return;
		case "returnMemory": {
			let e = Ye(n, a);
			e && n.hand.push(e);
			return;
		}
		case "liet":
			J(t, n, "persuasion", n.roundCards.filter((e) => g[e].factions.includes("fremen")).length * 2, r);
			return;
		case "extraTurn":
			t.turn.extra = !0;
			return;
		case "recruitDeploy": {
			let e = Ue(t, n, o);
			G(t, n.rid, r, [ue(e)]);
			return;
		}
		case "reinforcements":
			t.turn.mode === "start" ? K(t, n.rid, r, "games.duneimperium.chooseReinforcements", [q("agent", [x(3)], "games.duneimperium.agentTurn"), q("reveal", [C("revealNow"), C("recruitDeploy", 3)], "games.duneimperium.revealTurn")]) : t.turn.mode === "reveal" ? ft(t, n, r, "recruitDeploy", void 0, 3) : Ue(t, n, 3);
			return;
		case "revealNow":
			St(t, n);
			return;
		case "refocus":
			n.deck = U(t, [...n.deck, ...n.discard]), n.discard = [];
			return;
		case "peek": {
			let e = n.deck[0];
			e && K(t, n.rid, r, "games.duneimperium.choosePeek", [{
				...q("draw", [y()], "games.duneimperium.drawCard"),
				card: e
			}, {
				...q("trash", [{
					kind: "special",
					id: "trashCard",
					arg: e.uid
				}], "games.duneimperium.trashCard"),
				card: e
			}]);
			return;
		}
		case "revealPersuasion":
			t.turn.mode === "reveal" ? J(t, n, "persuasion", o, r) : n.flags.revealPersuasion = (n.flags.revealPersuasion ?? 0) + o;
			return;
		case "bindu":
			K(t, n.rid, r, "games.duneimperium.chooseBindu", [q("pass", [C("passTurn")], "games.duneimperium.passTurn")], !0);
			return;
		case "passTurn":
			xt(t, n, !0);
			return;
		case "doubleCross":
			K(t, n.rid, r, "games.duneimperium.chooseOpponent", t.order.filter((e) => e !== n.rid && t.players[e].combat > 0).map((e) => ({
				...q(e, [{
					kind: "special",
					id: "crossTroop",
					arg: e
				}], "games.duneimperium.choosePlayer"),
				target: e
			})));
			return;
		case "crossTroop":
			t.players[a].combat--, H(n) > 0 && (Ue(t, n, 1), nt(t, n, 1, 0));
			return;
		case "stagedIncident":
			n.combat -= 3, J(t, n, "vp", 1, r);
			return;
		case "cannonTurrets":
			for (let e of t.order) e !== n.rid && t.players[e].dreadCombat > 0 && (t.players[e].dreadCombat--, t.players[e].dreadGarrison++);
			return;
		case "quidProQuo":
			G(t, n.rid, r, _.filter((e) => P.some((r) => r.icon === e && t.agents[r.id]?.includes(n.rid))).map((e) => S(e)));
			return;
		case "strongarm": {
			let e = t.turn.space ? F[t.turn.space].icon : null;
			if (!_.includes(e)) return;
			K(t, n.rid, r, "games.duneimperium.chooseTroop", [...n.garrison ? [q("garrison", [{
				kind: "special",
				id: "loseGarrison"
			}, S(e)], "games.duneimperium.fromGarrison")] : [], ...n.combat ? [q("combat", [{
				kind: "special",
				id: "loseCombat"
			}, S(e)], "games.duneimperium.fromConflict")] : []]);
			return;
		}
		case "loseGarrison":
			n.garrison--;
			return;
		case "recallAgent":
			K(t, n.rid, r, "games.duneimperium.chooseRecall", P.filter((e) => t.agents[e.id]?.includes(n.rid)).map((e) => ({
				...q(e.id, [{
					kind: "special",
					id: "returnAgent",
					arg: e.id
				}], "games.duneimperium.chooseSpace"),
				space: e.id
			})));
			return;
		case "returnAgent": {
			let e = t.agents[a];
			e.splice(e.indexOf(n.rid), 1), n.agents++;
			return;
		}
		case "freeCard":
		case "freeCardTop": {
			let e = [
				...t.market,
				...n.reserved,
				...Object.entries(t.reserve).filter(([e, t]) => e !== "foldspace" && t > 0).map(([e]) => ({
					id: e,
					uid: `reserve:${e}`
				}))
			].filter((e) => g[e.id].cost <= o);
			K(t, n.rid, r, "games.duneimperium.chooseAcquire", e.map((e) => ({
				...q(e.uid, [{
					kind: "special",
					id: "takeFreeCard",
					arg: `${e.uid}|${i === "freeCardTop" ? "top" : "discard"}`
				}], "games.duneimperium.acquireCard"),
				card: e
			})), i === "freeCard" && !ve[Je(t, r)?.id ?? ""]);
			return;
		}
		case "takeFreeCard": {
			let [e, r] = a.split("|"), i = mt(t, n, e);
			i && Qe(t, n, i, r === "top");
			return;
		}
		case "exchangeIntrigue":
			n.flags.exchangeCount = 0, ht(t, n, r, o);
			return;
		case "exchangeOne": {
			let e = n.intrigues.findIndex((e) => e.uid === a);
			e >= 0 && t.intrigueDeck.push(...n.intrigues.splice(e, 1)), n.flags.exchangeCount++, ht(t, n, r, o);
			return;
		}
		case "exchangeFinish":
			Be(t, n, n.flags.exchangeCount ?? 0), n.flags.exchangeCount = 0;
			return;
		case "scorePlans": {
			let e = _.filter((e) => n.influence[e] >= 3).length;
			J(t, n, "vp", e >= 4 ? 2 : +(e === 3), r);
			return;
		}
		case "scoreCorner": {
			let e = pt(n);
			J(t, n, "vp", Number(e >= 2) + Number(t.order.every((r) => r === n.rid || (t.players[r].npc ? 2 : pt(t.players[r])) < e)), r);
			return;
		}
		case "scoreGrand": {
			let e = Number(Ae(t, n) === 2) + Number(pt(n) > 0) + Number(_.filter((e) => n.influence[e] >= 4).length >= 2) + Number(n.council);
			J(t, n, "vp", e === 4 ? 2 : +(e === 3), r);
			return;
		}
		case "arrakeenSecond": {
			let e = [
				b(),
				v("spice", 2),
				v("solari", 3)
			];
			K(t, n.rid, r, "games.duneimperium.chooseEffect", it([
				0,
				1,
				2
			], 2).map((t) => ({
				...q(t.join(","), [{
					kind: "bundle",
					effects: t.map((t) => e[t])
				}], "games.duneimperium.effectOption"),
				params: { n: t.map((e) => e + 1).join(" + ") }
			})));
			return;
		}
		case "signet":
			gt(t, n, r);
			return;
		case "reserveHelena":
			K(t, n.rid, r, "games.duneimperium.chooseReserve", t.market.map((e) => ({
				...q(e.uid, [{
					kind: "special",
					id: "reserveMarket",
					arg: e.uid
				}], "games.duneimperium.reserveCard"),
				card: e
			})));
			return;
		case "reserveMarket": {
			let e = t.market.findIndex((e) => e.uid === a);
			e >= 0 && n.reserved.push(...t.market.splice(e, 1)), $e(t);
			return;
		}
		case "letoSignet": {
			let e = _.filter((e) => t.order.some((r) => r !== n.rid && t.players[r].influence[e] > n.influence[e]));
			if (n.npc) {
				let t = Math.min(...e.map((e) => n.influence[e]));
				e = e.filter((e) => n.influence[e] === t);
			}
			let i = e.map((e) => ({
				...q(e, [{
					kind: "pay",
					cost: { spice: 1 },
					required: !0,
					effects: [S(e)]
				}], "games.duneimperium.factionChoice"),
				target: e,
				n: 1
			}));
			K(t, n.rid, r, "games.duneimperium.chooseFaction", i, !n.npc);
			return;
		}
		case "setupLeader":
			_t(t, n);
			return;
		case "baronSecrets":
			n.secrets = a.split(",");
			return;
		case "hundroKeep": {
			let e = t.intrigueDeck.splice(0, 2), r = e.find((e) => e.uid === a);
			n.intrigues.push(r), t.intrigueDeck.unshift(...e.filter((e) => e.uid !== a));
			return;
		}
		case "ilesaAside":
			K(t, n.rid, n.leader, "games.duneimperium.chooseAside", n.hand.map((e) => ({
				...q(e.uid, [{
					kind: "special",
					id: "setAside",
					arg: e.uid
				}], "games.duneimperium.setAside"),
				card: e
			})));
			return;
		case "setAside": {
			let e = n.hand.findIndex((e) => e.uid === a);
			e >= 0 && (n.aside = n.hand.splice(e, 1)[0]);
			return;
		}
		case "dreadVictory": {
			let e = be.filter((e) => !t.dreadControl.some((t) => t.space === e)).map((e) => ({
				...q(e, [{
					kind: "special",
					id: "setDreadControl",
					arg: e
				}], "games.duneimperium.chooseSpace"),
				space: e
			}));
			if (n.techs.includes("detonationDevices") && e.push(q("detonate", [C("detonate")], "games.duneimperium.detonate")), n.npc) {
				if (n.techs.includes("detonationDevices")) {
					ft(t, n, r, "detonate");
					return;
				}
				e.sort((e, r) => Number(t.control[r.space] !== null && t.control[r.space] !== n.rid) - Number(t.control[e.space] !== null && t.control[e.space] !== n.rid) || Number(t.control[e.space] === n.rid) - Number(t.control[r.space] === n.rid) || be.indexOf(e.space) - be.indexOf(r.space)), e[0] && W(t, n.rid, r, e[0].effects);
			} else K(t, n.rid, r, "games.duneimperium.chooseDreadControl", e);
			return;
		}
		case "setDreadControl":
			n.dreadCombat--, t.dreadControl.push({
				rid: n.rid,
				space: a,
				round: t.round
			});
			return;
		case "detonate":
			n.dreadCombat--, J(t, n, "vp", 1, r);
			return;
		case "useSonic":
			n.techs = n.techs.filter((e) => e !== "sonicSnoopers"), ft(t, n, r, "exchangeIntrigue", void 0, -1);
			return;
		case "useSatellites":
			n.spice -= 3, n.techs = n.techs.filter((e) => e !== "spySatellites"), J(t, n, "vp", 1, r);
			return;
	}
}
function pt(e) {
	return ke(e).filter((e) => e.id === "theSpiceMustFlow").length;
}
function mt(e, t, n) {
	if (n.startsWith("reserve:")) {
		let t = n.slice(8);
		return e.reserve[t] > 0 ? (e.reserve[t]--, je(e, t)) : void 0;
	}
	let r = t.reserved.findIndex((e) => e.uid === n);
	if (r >= 0) return t.reserved.splice(r, 1)[0];
	let i = e.market.findIndex((e) => e.uid === n);
	if (i < 0) return;
	let a = e.market.splice(i, 1)[0];
	return $e(e), a;
}
function ht(e, t, n, r) {
	if ((t.flags.exchangeCount ?? 0) === r || !t.intrigues.length) {
		W(e, t.rid, n, [C("exchangeFinish")]);
		return;
	}
	K(e, t.rid, n, "games.duneimperium.chooseIntrigueExchange", [...t.intrigues.map((e) => ({
		...q(e.uid, [{
			kind: "special",
			id: "exchangeOne",
			arg: e.uid,
			n: r
		}], "games.duneimperium.returnIntrigue"),
		card: e
	})), ...r < 0 ? [q("done", [C("exchangeFinish")], "games.duneimperium.finish")] : [q("no", [], "games.duneimperium.skip")]]);
}
function gt(e, t, n) {
	let r = {
		vladimirHarkonnen: [T({ solari: 1 }, b())],
		glossuRabban: [x(Ge(e, t, "alliance") ? 2 : 1)],
		ilbanRichese: [v("solari", 1)],
		helenaRichese: [C("reserveHelena")],
		letoAtreides: [C("letoSignet")],
		paulAtreides: [y()],
		arianaThorvald: [v("water", 1)],
		memnonThorvald: [v("spice", 1)],
		armandEcaz: [C("freeCard", 3)],
		ilesaEcaz: [T({ solari: 1 }, C("foldspace"))],
		rhomburVernius: [A(0, !1, !0)],
		tessiaVernius: [C("tessia")],
		yunaMoritani: [T({ solari: 7 }, S(), x(), v("spice", 1))],
		hundroMoritani: [T({ spice: 1 }, k())]
	};
	if (t.npc) for (let i of r[t.leader] ?? []) i.kind === "pay" ? Le(t, i.cost) && (Re(t, i.cost), G(e, t.rid, n, i.effects)) : G(e, t.rid, n, [i]);
	else G(e, t.rid, n, r[t.leader] ?? []);
}
function _t(e, t) {
	t.npc || (t.leader === "glossuRabban" && (J(e, t, "spice", 1, t.leader), J(e, t, "solari", 1, t.leader)), t.leader === "yunaMoritani" && (t.water = 0), t.leader === "tessiaVernius" && (t.snoopers = [..._]), t.leader === "vladimirHarkonnen" && K(e, t.rid, t.leader, "games.duneimperium.chooseSecretFactions", it([..._], 2).map((e) => ({
		...q(e.join(","), [{
			kind: "special",
			id: "baronSecrets",
			arg: e.join(",")
		}], "games.duneimperium.twoFactions"),
		params: {
			from: e[0],
			to: e[1]
		}
	}))), t.leader === "hundroMoritani" && K(e, t.rid, t.leader, "games.duneimperium.chooseStartingIntrigue", e.intrigueDeck.slice(0, 2).map((e) => ({
		...q(e.uid, [{
			kind: "special",
			id: "hundroKeep",
			arg: e.uid
		}], "games.duneimperium.keepIntrigue"),
		card: e
	}))));
}
var vt = (e, t) => {
	let n = e.order.indexOf(t);
	return [...e.order.slice(n), ...e.order.slice(0, n)];
};
function yt(e, t) {
	let n = F[t];
	return !!n && (!n.ix || e.config.ix) && (!n.baseOnly || !e.config.ix);
}
function bt(e, t) {
	e.active = t, e.turn = Ne(t), e.stage = 0;
	for (let t of Object.values(e.players)) delete t.flags.turnTroops;
	e.voice = e.voice.filter((e) => e.rid !== t);
	let n = e.players[t];
	n.turns++;
	for (let e of [
		"envoy",
		"infiltrate",
		"ambush"
	]) delete n.flags[e];
	n.asideReturned = null, n.turns === 2 && n.aside && (n.asideReturned = n.aside.uid, n.hand.push(n.aside), n.aside = null);
}
function xt(e, t, n = !1) {
	if (e.turn.mode === "reveal" && !n && (t.revealed = !0, t.revealOrder = e.serial++, t.discard.push(...t.played, ...t.revealedCards), t.played = [], t.revealedCards = [], t.persuasion = 0, t.reserved = []), e.turn.extra && !n) {
		bt(e, t.rid);
		return;
	}
	if (e.humans.length === 2 && t.rid === e.first && e.turn.mode === "agent" && !n) {
		let t = e.players[e.order.find((t) => e.players[t].npc)];
		if (t.agents > 0) {
			bt(e, t.rid);
			return;
		}
	}
	let r = vt(e, t.npc && e.humans.length === 2 ? e.first : t.rid).slice(1).find((t) => {
		let n = e.players[t];
		return (!n.npc || e.humans.length !== 2) && (n.npc ? n.agents > 0 : !n.revealed);
	});
	r ? bt(e, r) : (e.phase = "combatStart", e.stage = 0, e.active = "", e.turn = Ne(""));
}
function St(e, t) {
	e.turn.mode = "reveal", e.turn.started = !0, t.aside &&= (t.hand.push(t.aside), null);
	let n = t.hand;
	t.hand = [];
	for (let r of n) Ve(e, t, r);
	t.council && G(e, t.rid, "highCouncil", [v("persuasion", 2)]), t.flags.revealPersuasion && (G(e, t.rid, "recruitment", [v("persuasion", t.flags.revealPersuasion)]), delete t.flags.revealPersuasion), t.techs.includes("minimicFilm") && G(e, t.rid, "minimicFilm", [v("persuasion", 1)]), t.techs.includes("restrictedOrdnance") && t.council && G(e, t.rid, "restrictedOrdnance", [v("sword", 4)]), t.leader === "armandEcaz" && P.filter((e) => [
		"green",
		"blue",
		"yellow"
	].includes(e.icon)).reduce((n, r) => n + (e.agents[r.id]?.filter((e) => e === t.rid).length ?? 0), 0) >= 2 && G(e, t.rid, t.leader, [D("play")]), Pe(e, "games.duneimperium.logRevealed", t.rid, void 0, n.length);
}
function Ct(e, t, n, r, i = 0) {
	let a = { ...F[n].cost };
	return n === "mentat" && V(e) && e.config.difficulty !== "mercenary" && (a.solari = 5), t.leader === "letoAtreides" && !t.npc && F[n].icon === "green" && a.solari && (a.solari = Math.max(0, a.solari - 1)), n === "heighliner" && r.id === "guildAccord" && (a.spice = Math.max(0, (a.spice ?? 0) - 2)), n === "sellMelange" && (a.spice = i), a;
}
function wt(e, t, n, r, i = 0) {
	let a = F[r];
	if (!yt(e, r) || t.revealed || e.voice.some((e) => e.space === r && e.rid !== t.rid) || r === "highCouncil" && t.council || r === "swordmaster" && (t.swordmaster || V(e) && e.config.difficulty === "expertPlus") || a.requires && t.influence[a.requires] < 2) return !1;
	let o = n.id === "kwisatzHaderach";
	if (o && !P.some((n) => e.agents[n.id]?.includes(t.rid)) || !o && t.agents < 1 || !o && !g[n.id].icons.includes(a.icon) && !g[n.id].icons.includes("any") && !(t.flags.envoy && _.includes(a.icon))) return !1;
	let s = e.agents[r] ?? [];
	if (!o && s.includes(t.rid)) return !1;
	let c = g[n.id].infiltrate && g[n.id].icons.includes(a.icon) || t.flags.infiltrate || t.leader === "helenaRichese" && !t.npc && ["green", "blue"].includes(a.icon);
	return s.length && !o && !c || r === "sellMelange" && (i < 2 || i > 5) ? !1 : Le(t, Ct(e, t, r, n, i));
}
function Tt(e, t, n, r, i, a) {
	let o = Ct(e, t, r, n, i), s = F[r];
	Re(t, o);
	let c = t.hand.findIndex((e) => e.uid === n.uid);
	if (t.hand.splice(c, 1), t.played.push(n), t.roundCards.push(n.id), a) {
		let n = e.agents[a];
		n.splice(n.indexOf(t.rid), 1);
	} else t.agents--;
	e.agents[r] ??= [], e.agents[r].push(t.rid), e.turn.mode = "agent", e.turn.started = !0, e.turn.card = n.uid, e.turn.space = r, e.turn.selected = null, e.turn.relocate = null, s.combat && (e.turn.deployAllowance = 2), o.solari && t.leader === "ilbanRichese" && !t.npc && G(e, t.rid, t.leader, [y()]), t.asideReturned === n.uid && t.leader === "ilesaEcaz" && !t.npc && G(e, t.rid, t.leader, [v(g[n.id].icons.length === 1 ? "spice" : "solari", 1)]), n.id === "desertAmbush" && (t.flags.ambush = 1), G(e, t.rid, n.uid, ge[n.id].agent.filter((e) => e.kind !== "flag" || e.flag !== "ambush")), G(e, t.rid, r, s.effects.map((e) => (n.id === "powerPlay" || n.id === "treachery") && e.kind === "influence" ? {
		...e,
		n: 2
	} : e)), r === "sellMelange" && G(e, t.rid, r, [v("solari", [
		0,
		0,
		6,
		8,
		10,
		12
	][i])]), Et(e, r), Pe(e, "games.duneimperium.logPlaced", t.rid, r);
}
function Et(e, t) {
	let n = e.dreadControl.find((e) => e.space === t)?.rid ?? e.control[t];
	n && J(e, e.players[n], t === "imperialBasin" ? "spice" : "solari", 1, t);
}
var Dt = {
	conspire: 4,
	wealth: 3,
	heighliner: 6,
	foldspace: 1,
	selectiveBreeding: 2,
	secrets: 1,
	hardyWarriors: 5,
	stillsuits: 4,
	rallyTroops: 3,
	hallOfOratory: 0,
	carthag: 0,
	arrakeen: 1,
	harvestSpice: 2,
	interstellarShipping: 3,
	foldspaceShipping: 2,
	smugglingShipping: 2,
	techNegotiation: 0,
	dreadnought: 3
};
function Ot(e) {
	e.hagalDeck.length || (e.hagalDeck = U(e, e.hagalDiscard), e.hagalDiscard = []);
	let t = e.hagalDeck.shift();
	return t ? (e.hagalDiscard.push(t), t === "reshuffle" ? (e.hagalDeck = U(e, [...e.hagalDeck, ...e.hagalDiscard]), e.hagalDiscard = [], null) : t) : null;
}
function kt(e, t) {
	if (!V(e) || !["expert", "expertPlus"].includes(e.config.difficulty) || !e.conflict || Te[e.conflict].level === 3) return 99;
	let n = Math.max(0, ...e.order.filter((e) => e !== t.rid).map((t) => rt(e, e.players[t])));
	return Math.max(0, Math.ceil((n + 4 - rt(e, t)) / 2));
}
function At(e, t) {
	if (!e.turn.space || !F[e.turn.space].combat) return;
	let n = 2 + e.turn.recruitedDread + e.turn.recruited;
	for (; n > 0 && t.dreadGarrison && kt(e, t) > 0;) nt(e, t, 0, 1), n--;
	if (nt(e, t, Math.min(t.garrison, n, kt(e, t)), 0), t.techs.includes("flagship") && !t.exhausted.includes("flagship") && t.solari >= 4 && H(t) >= 3) {
		t.solari -= 4, t.exhausted.push("flagship");
		let n = Ue(e, t, 3);
		nt(e, t, Math.min(n, kt(e, t)), 0);
	}
}
function jt(e, t) {
	if (t.techs.includes("trainingDrones") && !t.exhausted.includes("trainingDrones") && H(t) > 0) {
		t.exhausted.push("trainingDrones"), Ue(e, t, 1);
		return;
	}
	if (t.techs.includes("spySatellites") && t.spice >= 3 && V(e)) {
		ft(e, t, "spySatellites", "useSatellites");
		return;
	}
	if (e.turn.mode === "agent") {
		At(e, t), xt(e, t);
		return;
	}
	let n = Ot(e);
	if (!n) return;
	let r = n;
	if (n === "foldspaceShipping" && (r = t.influence.spacingGuild >= 2 ? "interstellarShipping" : "foldspace"), n === "smugglingShipping" && (r = t.influence.spacingGuild >= 2 ? "interstellarShipping" : "smuggling"), n === "harvestSpice") {
		let n = P.filter((n) => n.harvest && e.bonus[n.id] > 0 && !e.agents[n.id]?.length && !e.voice.some((e) => e.space === n.id && e.rid !== t.rid)).sort((t, n) => e.bonus[n.id] - e.bonus[t.id] || n.harvest + e.bonus[n.id] - (t.harvest + e.bonus[t.id]));
		if (!n[0]) return;
		r = n[0].id;
	}
	if (!yt(e, r) || e.voice.some((e) => e.space === r && e.rid !== t.rid) || r === "interstellarShipping" && t.influence.spacingGuild < 2 || r === "dreadnought" && Ae(e, t) >= 2) return;
	if (e.agents[r]?.length) {
		if (t.techs.includes("invasionShips") && !t.exhausted.includes("invasionShips") && !e.agents[r].includes(t.rid)) t.exhausted.push("invasionShips");
		else return;
	}
	t.agents--, e.agents[r] ??= [], e.agents[r].push(t.rid), e.turn.mode = "agent", e.turn.space = r;
	let i = {
		conspire: [S("emperor"), x(2)],
		wealth: [S("emperor")],
		heighliner: [S("spacingGuild"), x(3)],
		foldspace: [S("spacingGuild")],
		selectiveBreeding: [S("beneGesserit")],
		secrets: [S("beneGesserit")],
		hardyWarriors: [S("fremen"), x(2)],
		stillsuits: [S("fremen")],
		rallyTroops: [x(4)],
		hallOfOratory: [x()],
		carthag: [x()],
		arrakeen: [x(), ...V(e) ? [C("signet")] : []],
		interstellarShipping: [k(2)],
		smuggling: [k()],
		techNegotiation: [A(1, !1, !0)],
		dreadnought: [{
			kind: "dread",
			n: 1
		}, ...V(e) ? [A()] : [x()]]
	};
	G(e, t.rid, r, i[r] ?? []), n === "harvestSpice" && (J(e, t, "spice", F[r].harvest + e.bonus[r], r), e.bonus[r] = 0), Et(e, r), Pe(e, "games.duneimperium.logPlaced", t.rid, r);
}
function Mt(e) {
	e.phase = "rewards", e.rewardQueue = [], e.stage = 0;
	let t = e.order.filter((t) => rt(e, e.players[t]) > 0).sort((t, n) => rt(e, e.players[n]) - rt(e, e.players[t]));
	e.victor = t[0] && (t.length === 1 || rt(e, e.players[t[0]]) > rt(e, e.players[t[1]])) ? t[0] : null;
	for (let n = 0; n < t.length;) {
		let r = t.filter((r) => rt(e, e.players[r]) === rt(e, e.players[t[n]])), i = n + 1 + Number(r.length > 1);
		if (i <= 2 || i === 3 && (e.humans.length === 4 || r.length > 1)) for (let t of r) e.rewardQueue.push({
			rid: t,
			rank: i
		});
		n += r.length;
	}
}
function Nt(e, t) {
	t.techs.includes("memocorders") && _.every((e) => t.influence[e] >= 3) && t.vp++, t.techs.includes("holtzmanEngine") && (t.npc || pt(t) >= 2) && t.vp++, t.techs.includes("spySatellites") && (t.vp += _.filter((e) => t.influence[e] <= 1).length);
}
function Pt(e) {
	return e.order.filter((t) => Oe(e, e.players[t])).sort((t, n) => {
		let r = e.players[t], i = e.players[n];
		return i.vp - r.vp || Number(i.techs.includes("chaumurky")) - Number(r.techs.includes("chaumurky")) || i.spice - r.spice || i.solari - r.solari || i.water - r.water || i.garrison - r.garrison || i.revealOrder - r.revealOrder;
	});
}
function Ft(e) {
	return !V(e) || !e.config.ix || !e.techDecks.some((e) => e.length) || e.techDecks.some((e) => e[0] && N[e[0]].hagal) ? -1 : e.techDecks.findIndex((t) => t.length === Math.max(...e.techDecks.map((e) => e.length)));
}
function It(e) {
	return e.decision || e.phase === "done" ? !1 : Ft(e) >= 0 || e.queue.length ? !0 : e.pool.length ? e.pool.every((t) => e.players[t.owner].npc) : e.phase === "turns" ? e.players[e.active]?.npc ?? !1 : e.phase === "leaders" || e.phase === "combat" || e.phase === "victory" ? e.phase === "victory" && (!e.victor || e.players[e.victor].npc) : e.phase !== "endgame" || e.endingPassed.length === e.humans.length;
}
function Lt(e) {
	let t = Ft(e);
	if (t >= 0) {
		Pe(e, "games.duneimperium.logTechRemoved", void 0, e.techDecks[t].shift());
		return;
	}
	if (e.queue.length) {
		st(e, e.queue.shift());
		return;
	}
	if (e.pool.length) {
		st(e, e.pool.shift());
		return;
	}
	switch (e.phase) {
		case "prepare":
			if (e.stage === 0) {
				e.round++, e.conflict = e.conflicts.shift() ?? null, e.stage++;
				for (let t of Object.values(e.players)) {
					let n = t.flags.masterstroke ?? 0;
					t.flags = n ? { masterstroke: n } : {}, t.swordCards = {}, t.sword = 0, t.persuasion = 0, t.revealed = !1, t.turns = 0, t.roundCards = [], t.exhausted = [], t.asideReturned = null;
					let r = e.config.difficulty === "mercenary" ? 6 : e.config.difficulty === "veteran" ? 5 : 4;
					t.npc && V(e) && e.round >= r && (t.swordmaster = !0), t.agents = t.npc && !V(e) ? 3 : 2 + Number(t.swordmaster), e.mentatNext === t.rid && t.agents++;
				}
				e.mentat = e.mentatNext, e.mentatNext = null;
				for (let t of Object.values(e.players)) ze(e, t);
				let t = e.conflict ? Te[e.conflict].control : null, n = t ? e.dreadControl.find((e) => e.space === t)?.rid ?? e.control[t] : null;
				n && H(e.players[n]) > 0 && (e.players[n].npc ? e.players[n].combat++ : K(e, n, t, "games.duneimperium.chooseDefense", [q("defend", [C("defend")], "games.duneimperium.defend")], !0)), Pe(e, "games.duneimperium.logRound", void 0, e.conflict ?? void 0, e.round);
			} else if (e.stage <= e.order.length) {
				let t = e.players[e.order[e.stage - 1]];
				e.stage++, He(e, t, 5 + Number(t.techs.includes("holtzmanEngine"))), t.techs.includes("shuttleFleet") && J(e, t, "solari", 2, "shuttleFleet"), t.leader === "ilesaEcaz" && !t.npc && W(e, t.rid, t.leader, [C("ilesaAside")]);
			} else e.phase = "turns", bt(e, e.first);
			return;
		case "turns":
			jt(e, e.players[e.active]);
			return;
		case "combatStart": {
			let t = vt(e, e.first).filter((t) => e.players[t].npc && Me(e.players[t]) > 0);
			if (e.stage < t.length) {
				let n = Ot(e);
				n && (e.players[t[e.stage]].sword += Dt[n] ?? 0, e.stage++);
			} else {
				e.combatActors = vt(e, e.first).filter((t) => !e.players[t].npc && Me(e.players[t]) > 0), e.combatPassed = 0;
				for (let t of Object.values(e.players)) delete t.flags.turnTroops;
				e.combatActors.length ? (e.phase = "combat", e.active = e.combatActors[0]) : Mt(e);
			}
			return;
		}
		case "rewards": {
			let t = e.rewardQueue.shift();
			if (t && e.conflict) {
				let n = e.players[t.rid], r = Te[e.conflict];
				n.npc && !V(e) ? t.rank === 1 && r.control && (e.control[r.control] = null) : G(e, n.rid, r.id, r.rewards[t.rank - 1]), Pe(e, "games.duneimperium.logReward", n.rid, r.id, t.rank);
			} else if (e.phase = "victory", e.active = e.victor ?? "", e.stage = 0, e.victor) {
				let t = e.players[e.victor];
				t.flags.strategicPush && G(e, t.rid, "strategicPush", [v("solari", 2)]), t.techs.includes("windtraps") && G(e, t.rid, "windtraps", [v("water", 1)]), t.dreadCombat && G(e, t.rid, "dreadnought", [C("dreadVictory")]);
			}
			return;
		}
		case "victory":
			e.phase = "battleEnd", e.stage = 0;
			return;
		case "battleEnd":
			if (e.stage < e.order.length) {
				let t = e.players[e.order[e.stage++]];
				t.combat = 0, t.dreadGarrison += t.dreadCombat, t.dreadCombat = 0;
			} else {
				for (let t of e.dreadControl.filter((t) => t.round < e.round)) e.players[t.rid].dreadGarrison++;
				e.dreadControl = e.dreadControl.filter((t) => t.round === e.round), e.phase = "makers", e.stage = 0;
			}
			return;
		case "makers": {
			let t = [
				"imperialBasin",
				"haggaBasin",
				"theGreatFlat"
			][e.stage++];
			t ? e.agents[t]?.length || e.bonus[t]++ : (e.phase = "recall", e.stage = 0);
			return;
		}
		case "recall":
			!e.conflicts.length || Object.values(e.players).some((t) => Oe(e, t) && t.vp >= (e.config.epic ? 12 : 10)) ? (e.phase = "endgame", e.active = e.humans[0], e.endingPassed = [], e.stage = 0) : (e.agents = {}, e.voice = [], e.first = e.humans.length === 2 ? e.humans[(e.humans.indexOf(e.first) + 1) % 2] : e.order[(e.order.indexOf(e.first) + 1) % e.order.length], e.phase = "prepare", e.stage = 0);
			return;
		case "endgame":
			e.stage < e.order.length ? Nt(e, e.players[e.order[e.stage++]]) : (e.ranking = Pt(e), e.phase = "done", e.active = "");
			return;
	}
}
function Rt(e, t, n) {
	let r = [...t, ...Array.from({ length: t.length === 1 ? 2 : +(t.length === 2) }, (e, t) => `$hagal${t}`)], i = {
		emperor: 0,
		spacingGuild: 0,
		beneGesserit: 0,
		fremen: 0
	}, a = {
		config: e,
		humans: [...t],
		order: r,
		players: {},
		seed: n,
		rngCursor: 0,
		serial: 1,
		round: 0,
		first: t.length === 1 ? r[1] : t[0],
		phase: "leaders",
		active: t[0],
		turn: Ne(t[0]),
		deck: [],
		market: [],
		intrigueDeck: [],
		intrigueDiscard: [],
		reserve: {
			foldspace: 6,
			arrakisLiaison: 8,
			theSpiceMustFlow: 10
		},
		conflicts: [],
		conflict: null,
		techDecks: [],
		agents: {},
		control: {
			imperialBasin: null,
			arrakeen: null,
			carthag: null
		},
		dreadControl: [],
		alliance: {
			emperor: null,
			spacingGuild: null,
			beneGesserit: null,
			fremen: null
		},
		bonus: {
			imperialBasin: 0,
			haggaBasin: 0,
			theGreatFlat: 0
		},
		voice: [],
		mentat: null,
		mentatNext: null,
		pool: [],
		queue: [],
		decision: null,
		combatPassed: 0,
		combatPlayed: !1,
		combatActors: [],
		rewardQueue: [],
		victor: null,
		endingPassed: [],
		log: [],
		ranking: [],
		stage: 0,
		hagalDeck: [],
		hagalDiscard: [],
		cardIds: {}
	};
	for (let n of r) {
		let r = !t.includes(n), o = {
			rid: n,
			npc: r,
			leader: "",
			solari: 0,
			spice: 0,
			water: 1,
			vp: +(t.length === 4),
			persuasion: 0,
			sword: 0,
			influence: { ...i },
			garrison: r ? t.length === 1 && e.difficulty !== "mercenary" ? 3 : 0 : e.epic ? 5 : 3,
			combat: 0,
			dreadGarrison: 0,
			dreadCombat: 0,
			negotiators: 0,
			shipment: 0,
			agents: 2,
			swordmaster: !1,
			council: !1,
			revealed: !1,
			deck: [],
			hand: [],
			discard: [],
			played: [],
			revealedCards: [],
			intrigues: [],
			techs: [],
			exhausted: [],
			reserved: [],
			aside: null,
			asideReturned: null,
			turns: 0,
			flags: {},
			swordCards: {},
			roundCards: [],
			secrets: [],
			snoopers: [],
			revealOrder: 0
		};
		a.players[n] = o, r || (o.deck = U(a, [
			"duneTheDesertPlanet",
			e.epic ? "controlTheSpice" : "duneTheDesertPlanet",
			"dagger",
			"dagger",
			"convincingArgument",
			"convincingArgument",
			"reconnaissance",
			"diplomacy",
			"seekAllies",
			"signetRing"
		].map((e) => je(a, e))), t.length === 1 && e.difficulty === "mercenary" && (o.solari = 1, o.spice = 1));
	}
	a.deck = U(a, Object.values(g).filter((t) => t.set === "base" || t.set === "ix" && e.ix).flatMap((e) => Array.from({ length: e.count }, () => je(a, e.id)))), $e(a), a.intrigueDeck = U(a, Object.values(ve).filter((t) => !t.ix || e.ix).flatMap((e) => Array.from({ length: e.count }, () => je(a, e.id))));
	for (let n of Object.values(a.players)) (!n.npc && e.epic || n.npc && t.length === 1 && e.difficulty !== "mercenary") && Be(a, n, 1);
	let o = we.filter((t) => !t.ix || e.ix || e.epic && t.level === 3);
	if (a.conflicts = e.epic ? [...U(a, o.filter((e) => e.level === 2)).slice(0, 5), ...U(a, o.filter((e) => e.level === 3)).slice(0, 5)].map((e) => e.id) : [
		...U(a, o.filter((e) => e.level === 1)).slice(0, 1),
		...U(a, o.filter((e) => e.level === 2)).slice(0, 5),
		...U(a, o.filter((e) => e.level === 3)).slice(0, 4)
	].map((e) => e.id), e.ix) {
		let e = U(a, Object.keys(N));
		a.techDecks = [
			e.slice(0, 6),
			e.slice(6, 12),
			e.slice(12, 18)
		];
	}
	let s = {
		conspire: 2,
		wealth: 1,
		heighliner: 1,
		foldspace: 2,
		selectiveBreeding: 2,
		secrets: 1,
		hardyWarriors: 1,
		stillsuits: 2,
		rallyTroops: 2,
		hallOfOratory: 2,
		carthag: 3,
		harvestSpice: 5,
		arrakeen: 3,
		...t.length === 2 ? { reshuffle: 1 } : {}
	};
	return e.ix && (delete s.rallyTroops, delete s.hallOfOratory, Object.assign(s, {
		interstellarShipping: 1,
		foldspaceShipping: 1,
		smugglingShipping: 1,
		dreadnought: 2,
		...t.length === 1 ? { techNegotiation: 2 } : {}
	})), t.length < 3 && (a.hagalDeck = U(a, Object.entries(s).flatMap(([e, t]) => Array.from({ length: t }, () => e)))), a;
}
function zt(e) {
	if (e.decision) return e.decision.owner;
	let t = e.pool.find((t) => !e.players[t.owner].npc);
	return t ? t.owner : It(e) ? "" : e.active;
}
function Bt(e, t) {
	return [
		...e.market,
		...t.reserved,
		...Object.entries(e.reserve).filter(([e, t]) => e !== "foldspace" && t > 0).map(([e]) => ({
			id: e,
			uid: `reserve:${e}`
		}))
	].flatMap((e) => {
		let n = Math.max(0, g[e.id].cost - (e.id === "theSpiceMustFlow" ? t.flags.spiceDiscount ?? 0 : 0) - Number(t.reserved.some((t) => t.uid === e.uid)));
		return n <= t.persuasion ? [{
			id: `buy:${e.uid}`,
			key: "games.duneimperium.buyCard",
			group: "buy",
			card: e,
			n,
			value: e.id === "theSpiceMustFlow" ? 100 : g[e.id].cost * 4,
			params: { n }
		}] : [];
	});
}
function Vt(e, t, n, r) {
	let i = Ee[n]?.[r];
	if (!i || !tt(e, t, i) || r === "combat" && !Me(t)) return !1;
	switch (n) {
		case "alliedArmada": return Ge(e, t, "alliance");
		case "councilorsDispensation":
		case "secretForces": return t.council;
		case "doubleCross": return e.order.some((n) => n !== t.rid && e.players[n].combat > 0);
		case "dispatchAnEnvoy":
		case "infiltrate": return e.turn.mode === "start";
		case "calculatedHire": return !e.mentat;
		case "binduSuspension": return e.turn.mode === "start" && !e.turn.started;
		case "stagedIncident": return t.combat >= 3;
		case "urgentMission": return P.some((n) => e.agents[n.id]?.includes(t.rid));
		case "diversion": return e.turn.deployed >= 4;
		case "advancedWeaponry": return r === "combat" ? t.techs.length >= 3 : Ae(e, t) < 2;
		case "blackmail":
		case "finesse": return r === "combat" && n === "finesse" || _.some((e) => t.influence[e] > 0);
		case "machineCulture": return r === "end" ? t.techs.length >= 3 : ot(e, t, {
			kind: "tech",
			discount: 0
		}).length > 0;
		case "strongarm": return e.turn.mode === "agent" && !!e.turn.space && _.includes(F[e.turn.space].icon) && t.garrison + t.combat > 0;
		case "quidProQuo": return P.some((n) => _.includes(n.icon) && e.agents[n.id]?.includes(t.rid));
		case "warChest": return r !== "end" || t.solari >= 10;
		default: return !0;
	}
}
function Ht(e, t, n) {
	return t.intrigues.filter((r) => Vt(e, t, r.id, n)).map((e) => ({
		id: `intrigue:${e.uid}:${n}`,
		key: "games.duneimperium.playIntrigue",
		group: "intrigue",
		card: e,
		source: n,
		value: 25,
		preview: Ee[e.id][n]
	}));
}
function Ut(e, t) {
	let n = [], r = (e, r, i) => {
		t.techs.includes(e) && i && n.push({
			id: `tech:${e}`,
			key: "games.duneimperium.useTech",
			group: "tech",
			source: e,
			effects: r,
			preview: r,
			value: 20
		});
	};
	return r("trainingDrones", [x()], !t.exhausted.includes("trainingDrones") && H(t) > 0), r("flagship", [T({ solari: 4 }, x(3))], !t.exhausted.includes("flagship") && t.solari >= 4 && H(t) > 0), r("holoprojectors", [O(1, [y()], !0)], !t.exhausted.includes("holoprojectors") && t.hand.length > 0), r("invasionShips", [O(1, [w("infiltrate")], !0)], !t.exhausted.includes("invasionShips") && e.turn.mode === "start" && t.hand.length > 0), r("spySatellites", [C("useSatellites")], t.spice >= 3), r("sonicSnoopers", [C("useSonic")], t.intrigues.length > 0), r("disposalFacility", [D("play")], e.turn.mode === "reveal" && t.persuasion >= 6 && !t.flags.disposal && t.played.length + t.revealedCards.length > 0), n;
}
function Wt(e, t) {
	if (!e.humans.includes(t) || e.phase === "done" || It(e)) return [];
	if (e.decision) return e.decision.owner === t ? e.decision.options.map((t) => ({
		id: `decision:${t.id}`,
		key: t.key,
		group: "decision",
		source: e.cardIds[e.decision.source] ?? e.decision.source,
		params: t.params,
		card: t.card,
		space: t.space,
		target: t.target,
		n: t.n,
		preview: t.effects
	})) : [];
	let n = e.players[t], r = [];
	if (e.queue.length) return [];
	for (let n of e.pool.filter((e) => e.owner === t)) r.push({
		id: `effect:${n.id}`,
		key: "games.duneimperium.resolveEffect",
		group: "effect",
		n: n.id,
		source: e.cardIds[n.source] ?? n.source,
		preview: [n.effect],
		value: 50
	});
	if (e.pool.some((e) => e.owner !== t)) return r;
	if (e.phase === "leaders") return e.active === t ? _e.filter((t) => (!t.ix || e.config.ix) && !Object.values(e.players).some((e) => e.leader === t.id)).map((e) => ({
		id: `leader:${e.id}`,
		key: "games.duneimperium.chooseLeader",
		group: "decision",
		source: e.id,
		target: e.id,
		value: e.id === "memnonThorvald" ? 10 : 1
	})) : [];
	if (e.phase === "turns" && e.active === t) {
		if (e.turn.selected) {
			let i = n.hand.find((t) => t.uid === e.turn.selected);
			if (i.id === "kwisatzHaderach" && !e.turn.relocate) r.push(...P.filter((n) => e.agents[n.id]?.includes(t)).map((e) => ({
				id: `relocate:${e.id}`,
				key: "games.duneimperium.chooseSpace",
				group: "space",
				space: e.id,
				value: 1
			})));
			else for (let t of P) for (let a of t.id === "sellMelange" ? [
				2,
				3,
				4,
				5
			] : [0]) wt(e, n, i, t.id, a) && r.push({
				id: `place:${t.id}:${a}`,
				key: "games.duneimperium.sendAgent",
				group: "space",
				card: i,
				space: t.id,
				n: a,
				params: { n: a },
				value: Gt(e, n, t.id)
			});
			return r.push({
				id: "cancel",
				key: "games.duneimperium.cancel",
				group: "main"
			}), r;
		}
		if (r.push(...Ht(e, n, "plot"), ...Ut(e, n)), e.turn.mode === "start" && !e.pool.length) {
			for (let t of n.hand) P.some((r) => (r.id === "sellMelange" ? [
				2,
				3,
				4,
				5
			] : [0]).some((i) => wt(e, n, t, r.id, i))) && r.push({
				id: `play:${t.uid}`,
				key: "games.duneimperium.playCard",
				group: "play",
				card: t,
				value: t.id === "seekAllies" ? 15 : 10
			});
			r.push({
				id: "reveal",
				key: "games.duneimperium.reveal",
				group: "main",
				value: n.agents > 0 ? -5 : 20
			});
		}
		e.turn.mode === "agent" && (e.turn.space && F[e.turn.space].combat && at(n, n.garrison + n.dreadGarrison, "garrison", !0).some(({ troops: t, dreads: n }) => t + n > 0 && Math.max(0, t - e.turn.recruited) + Math.max(0, n - e.turn.recruitedDread) <= e.turn.deployAllowance) && r.push({
			id: "deploy",
			key: "games.duneimperium.deploy",
			group: "main",
			value: 12
		}), e.pool.length || r.push({
			id: "finish",
			key: "games.duneimperium.finishTurn",
			group: "main",
			value: 0
		})), e.turn.mode === "reveal" && (r.push(...Bt(e, n)), e.pool.length || r.push({
			id: "finish",
			key: "games.duneimperium.finishReveal",
			group: "main",
			value: 0
		}));
	}
	return e.phase === "combat" && e.active === t && !e.pool.length && (r.push(...Ht(e, n, "combat")), r.push({
		id: "combatPass",
		key: e.combatPlayed ? "games.duneimperium.finishCombatTurn" : "games.duneimperium.passCombat",
		group: "main",
		value: rt(e, n) > Math.max(0, ...e.order.filter((e) => e !== t).map((t) => rt(e, e.players[t]))) ? 30 : 0
	})), e.phase === "victory" && e.victor === t && !e.pool.length && r.push(...Ht(e, n, "win"), {
		id: "victoryDone",
		key: "games.duneimperium.finish",
		group: "main",
		value: 0
	}), e.phase === "endgame" && e.active === t && !e.pool.length && r.push(...Ht(e, n, "end"), {
		id: "endDone",
		key: "games.duneimperium.finishEndgame",
		group: "main",
		value: -10
	}), r;
}
function Gt(e, t, n) {
	let r = F[n], i = 8;
	if (_.includes(r.icon)) {
		let e = t.influence[r.icon];
		i += e === 1 || e === 3 ? 18 : 8;
	}
	return n === "swordmaster" && (i += 40), n === "highCouncil" && (i += 25), r.harvest && (i += r.harvest * 2 + e.bonus[n] * 3), n === "wealth" && t.solari < 8 && (i += 10), n === "stillsuits" && t.water === 0 && (i += 14), n === "mentat" && (i += 12), n === "interstellarShipping" && (i += 20), n === "arrakeen" && (i += 9), i;
}
function Kt(e, t, n) {
	let r = e.players[t], i = n.id;
	if (i.startsWith("decision:")) {
		let t = e.decision, n = t.options.find((e) => `decision:${e.id}` === i);
		e.decision = null, W(e, t.for, t.source, n.effects);
	} else if (i.startsWith("effect:")) {
		let t = e.pool.findIndex((e) => e.id === n.n), r = e.pool.splice(t, 1)[0];
		st(e, r);
	} else if (i.startsWith("leader:")) {
		r.leader = n.target;
		let t = e.humans.find((t) => !e.players[t].leader);
		if (t) e.active = t;
		else {
			if (e.phase = "prepare", e.stage = 0, V(e)) for (let t of e.order.filter((t) => e.players[t].npc)) W(e, t, "rivalLeader", [C("chooseRivalLeader")], !1);
			for (let t of e.humans) W(e, t, e.players[t].leader, [C("setupLeader")], !1);
		}
	} else if (i.startsWith("play:")) e.turn.selected = n.card.uid;
	else if (i.startsWith("relocate:")) e.turn.relocate = n.space;
	else if (i.startsWith("place:")) Tt(e, r, n.card, n.space, n.n ?? 0, e.turn.relocate ?? void 0);
	else if (i === "cancel") e.turn.selected = null, e.turn.relocate = null;
	else if (i === "reveal") St(e, r);
	else if (i === "finish") xt(e, r);
	else if (i === "deploy") {
		let t = at(r, r.garrison + r.dreadGarrison, "garrison", !0).filter(({ troops: t, dreads: n }) => Math.max(0, t - e.turn.recruited) + Math.max(0, n - e.turn.recruitedDread) <= e.turn.deployAllowance).map(({ troops: e, dreads: t }) => ({
			...q(`${e}:${t}`, [{
				kind: "special",
				id: "normalDeploy",
				arg: `${e}:${t}`
			}], "games.duneimperium.deployUnits"),
			params: {
				troops: e,
				dreads: t
			},
			n: e + t
		}));
		K(e, r.rid, e.turn.space, "games.duneimperium.chooseDeployment", t);
	} else if (i.startsWith("buy:")) {
		r.persuasion -= n.n;
		let t = mt(e, r, n.card.uid);
		t && Qe(e, r, t);
	} else if (i.startsWith("intrigue:")) {
		let i = n.card, a = n.source;
		r.intrigues.splice(r.intrigues.findIndex((e) => e.uid === i.uid), 1), e.intrigueDiscard.push(i), e.turn.started = !0, e.turn.selected = null, a === "combat" && (e.combatPassed = 0, e.combatPlayed = !0), W(e, t, i.uid, De(Ee[i.id][a])), Pe(e, "games.duneimperium.logIntrigue", t, i.id);
	} else if (i.startsWith("tech:")) n.source === "disposalFacility" ? r.flags.disposal = 1 : r.exhausted.push(n.source), e.turn.started = !0, G(e, t, n.source, n.effects);
	else if (i === "combatPass") {
		e.combatPlayed || e.combatPassed++, e.combatPlayed = !1;
		for (let t of Object.values(e.players)) delete t.flags.turnTroops;
		let n = e.order.filter((t) => !e.players[t].npc && Me(e.players[t]) > 0);
		e.combatPassed >= n.length ? Mt(e) : e.active = vt(e, t).slice(1).find((e) => n.includes(e)) ?? (n.includes(t) ? t : n[0]);
	} else i === "victoryDone" ? (e.phase = "battleEnd", e.stage = 0) : i === "endDone" && (e.endingPassed.push(t), e.active = e.humans.find((t) => !e.endingPassed.includes(t)) ?? "");
}
//#endregion
//#region src/games/duneimperium/meta.ts
var qt = {
	id: "duneimperium",
	tier: "beta",
	mechanics: [
		"worker-placement",
		"deck-bag-building",
		"area-control"
	],
	interactionTags: [],
	nameKey: "games.duneimperium.name",
	descKey: "games.duneimperium.desc",
	rulesKey: "games.duneimperium.rules",
	icon: "🏜️",
	iconImg: "games/duneimperium.webp",
	rulesUrl: {
		zh: "https://d19y2ttatozxjp.cloudfront.net/pdfs/SCN_DUNE_IMPERIUM_Rulebook_24-10-22.pdf",
		en: "https://d19y2ttatozxjp.cloudfront.net/pdfs/DUNE_IMPERIUM_Rulebook_20-10-26.pdf"
	},
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#ad711d",
	releasedAt: "2026-10-22T01:55:22+08:00",
	search: {
		py: "sha qiu di guo yi ke si jue qi",
		init: "sqdgyksjq"
	},
	hotseat: "cover"
}, Jt = t.object({
	ix: t.boolean().default(!1),
	epic: t.boolean().default(!1),
	difficulty: t.enum([
		"mercenary",
		"veteran",
		"expert",
		"expertPlus"
	]).default("veteran")
}).prefault({}), Yt = t.discriminatedUnion("type", [t.object({
	type: t.literal("act"),
	id: t.string().min(1).max(180)
}).strict(), t.object({
	type: t.literal("tick"),
	now: t.number().finite()
}).strict()]), Y = t.object({
	uid: t.string(),
	id: t.string()
}), Xt = t.lazy(() => t.union([
	t.object({
		kind: t.literal("bundle"),
		effects: t.array(Xt)
	}),
	t.object({
		kind: t.literal("gain"),
		resource: t.enum([
			"solari",
			"spice",
			"water",
			"vp",
			"persuasion",
			"sword"
		]),
		n: t.number()
	}),
	t.object({
		kind: t.enum([
			"draw",
			"intrigue",
			"troop",
			"dread",
			"shipment",
			"negotiator"
		]),
		n: t.number()
	}),
	t.object({
		kind: t.literal("influence"),
		n: t.number(),
		faction: t.enum([
			"emperor",
			"spacingGuild",
			"beneGesserit",
			"fremen"
		]).optional(),
		exclude: t.array(t.enum([
			"emperor",
			"spacingGuild",
			"beneGesserit",
			"fremen"
		])).optional()
	}),
	t.object({
		kind: t.literal("if"),
		condition: t.object({
			kind: t.enum([
				"bond",
				"bg",
				"alliance",
				"friendship",
				"council",
				"techs",
				"emperorAgent"
			]),
			faction: t.enum([
				"emperor",
				"spacingGuild",
				"beneGesserit",
				"fremen"
			]).optional(),
			n: t.number().optional()
		}),
		effects: t.array(Xt)
	}),
	t.object({
		kind: t.literal("pay"),
		cost: t.object({
			solari: t.number().optional(),
			spice: t.number().optional(),
			water: t.number().optional(),
			vp: t.number().optional(),
			persuasion: t.number().optional(),
			sword: t.number().optional()
		}),
		effects: t.array(Xt),
		required: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("choice"),
		options: t.array(t.array(Xt)),
		optional: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("trash"),
		zone: t.enum([
			"play",
			"all",
			"self",
			"top"
		]).optional(),
		required: t.boolean().optional(),
		after: t.array(Xt).optional()
	}),
	t.object({
		kind: t.literal("discard"),
		n: t.number(),
		after: t.array(Xt).optional(),
		required: t.boolean().optional()
	}),
	t.object({
		kind: t.literal("tech"),
		discount: t.number(),
		solari: t.boolean().optional(),
		negotiate: t.boolean().optional()
	}),
	t.object({
		kind: t.enum(["deploy", "retreat"]),
		n: t.number(),
		units: t.boolean().optional(),
		exact: t.boolean().optional(),
		after: t.array(Xt).optional()
	}),
	t.object({
		kind: t.literal("flag"),
		flag: t.string(),
		n: t.number().optional()
	}),
	t.object({
		kind: t.literal("special"),
		id: t.string(),
		arg: t.string().optional(),
		n: t.number().optional()
	})
])), Zt = t.object({
	id: t.string(),
	key: t.string(),
	group: t.string(),
	params: t.record(t.string(), t.union([t.string(), t.number()])).optional(),
	source: t.string().optional(),
	card: Y.optional(),
	space: t.string().optional(),
	target: t.string().optional(),
	n: t.number().optional(),
	value: t.number().optional(),
	preview: t.array(Xt).optional()
}), Qt = t.object({
	emperor: t.number(),
	spacingGuild: t.number(),
	beneGesserit: t.number(),
	fremen: t.number()
}), $t = t.object({
	rid: t.string(),
	npc: t.boolean(),
	leader: t.string(),
	solari: t.number(),
	spice: t.number(),
	water: t.number(),
	vp: t.number(),
	persuasion: t.number(),
	strength: t.number(),
	influence: Qt,
	garrison: t.number(),
	combat: t.number(),
	dreadGarrison: t.number(),
	dreadCombat: t.number(),
	negotiators: t.number(),
	shipment: t.number(),
	agents: t.number(),
	swordmaster: t.boolean(),
	council: t.boolean(),
	revealed: t.boolean(),
	deckCount: t.number(),
	handCount: t.number(),
	intrigueCount: t.number(),
	discard: t.array(Y),
	played: t.array(Y),
	revealedCards: t.array(Y),
	techs: t.array(t.string()),
	exhausted: t.array(t.string()),
	reserved: t.array(Y),
	shownCard: Y.nullable(),
	snoopers: t.array(t.string()),
	revealedSecrets: t.array(t.string())
}), en = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: qt,
	schemas: {
		action: Yt,
		publicView: t.object({
			config: Jt,
			phase: t.string(),
			round: t.number(),
			first: t.string(),
			active: t.string(),
			acting: t.string(),
			players: t.array($t),
			market: t.array(Y),
			reserve: t.record(t.string(), t.number()),
			deckCount: t.number(),
			intrigueDeckCount: t.number(),
			intrigueDiscard: t.array(Y),
			conflict: t.string().nullable(),
			conflictCount: t.number(),
			techTops: t.array(t.string().nullable()),
			techCounts: t.array(t.number()),
			agents: t.record(t.string(), t.array(t.string())),
			control: t.record(t.string(), t.string().nullable()),
			dreadControl: t.array(t.object({
				rid: t.string(),
				space: t.string(),
				round: t.number()
			})),
			alliance: t.record(t.string(), t.string().nullable()),
			bonus: t.record(t.string(), t.number()),
			voice: t.array(t.object({
				rid: t.string(),
				space: t.string()
			})),
			mentat: t.string().nullable(),
			victor: t.string().nullable(),
			mode: t.string(),
			selected: t.string().nullable(),
			prompt: t.object({
				owner: t.string(),
				key: t.string(),
				source: t.string()
			}).nullable(),
			log: t.array(t.object({
				key: t.string(),
				rid: t.string().optional(),
				source: t.string().optional(),
				n: t.number().optional()
			})),
			ranking: t.array(t.string())
		}),
		privateView: t.object({
			hand: t.array(Y),
			intrigues: t.array(Y),
			aside: Y.nullable(),
			peek: Y.nullable(),
			secrets: t.array(t.string()),
			choices: t.array(Zt),
			selected: t.string().nullable()
		}),
		config: Jt
	},
	setup(e, t, n) {
		return { state: Rt(Jt.parse(e), t, n) };
	},
	reduce(e, t, { by: n }) {
		if (t.type === "tick") {
			if (n !== "$engine" || !It(e)) return { code: "games.duneimperium.invalidAction" };
			let t = structuredClone(e);
			return Lt(t), { state: t };
		}
		let r = Wt(e, n).find((e) => e.id === t.id);
		if (!r) return { code: "games.duneimperium.invalidAction" };
		let i = structuredClone(e);
		return Kt(i, n, r), { state: i };
	},
	viewFor(e, t) {
		let n = e.players[t];
		return {
			public: {
				config: e.config,
				phase: e.phase,
				round: e.round,
				first: e.first,
				active: e.active,
				acting: zt(e),
				players: e.order.map((t) => {
					let n = e.players[t];
					return {
						rid: n.rid,
						npc: n.npc,
						leader: n.leader,
						solari: n.solari,
						spice: n.spice,
						water: n.water,
						vp: n.vp,
						persuasion: n.persuasion,
						strength: rt(e, n),
						influence: n.influence,
						garrison: n.garrison,
						combat: n.combat,
						dreadGarrison: n.dreadGarrison,
						dreadCombat: n.dreadCombat,
						negotiators: n.negotiators,
						shipment: n.shipment,
						agents: n.agents,
						swordmaster: n.swordmaster,
						council: n.council,
						revealed: n.revealed,
						deckCount: n.deck.length,
						handCount: n.hand.length,
						intrigueCount: n.intrigues.length,
						discard: n.discard,
						played: n.played,
						revealedCards: n.revealedCards,
						techs: n.techs,
						exhausted: n.exhausted,
						reserved: n.reserved,
						shownCard: n.hand.find((e) => e.uid === n.asideReturned) ?? null,
						snoopers: n.snoopers,
						revealedSecrets: n.flags.masterstroke ? n.secrets : []
					};
				}),
				market: e.market,
				reserve: e.reserve,
				deckCount: e.deck.length,
				intrigueDeckCount: e.intrigueDeck.length,
				intrigueDiscard: e.intrigueDiscard,
				conflict: e.conflict,
				conflictCount: e.conflicts.length,
				techTops: e.techDecks.map((e) => e[0] ?? null),
				techCounts: e.techDecks.map((e) => e.length),
				agents: e.agents,
				control: e.control,
				dreadControl: e.dreadControl,
				alliance: e.alliance,
				bonus: e.bonus,
				voice: e.voice,
				mentat: e.mentat,
				victor: e.victor,
				mode: e.turn.mode,
				selected: null,
				prompt: e.decision ? {
					owner: e.decision.owner,
					key: e.decision.key,
					source: e.cardIds[e.decision.source] ?? e.decision.source
				} : null,
				log: e.log,
				ranking: e.ranking
			},
			...n && !n.npc ? { private: {
				hand: n.hand,
				intrigues: n.intrigues,
				aside: n.aside,
				peek: n.leader === "paulAtreides" ? n.deck[0] ?? null : null,
				secrets: n.secrets,
				choices: Wt(e, t).map((e) => ({
					id: e.id,
					key: e.key,
					group: e.group,
					params: e.params,
					source: e.source,
					card: e.card,
					space: e.space,
					target: e.target,
					n: e.n,
					value: e.value,
					preview: e.preview
				})),
				selected: e.turn.rid === t ? e.turn.selected : null
			} } : {}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.ranking.slice(0, 1),
			ranking: e.ranking,
			scores: Object.fromEntries(e.ranking.map((t) => [t, e.players[t].vp]))
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return It(e) ? 280 : null;
	}
}, tn = {
	emperor: "games.duneimperium.factions.emperor",
	spacingGuild: "games.duneimperium.factions.spacingGuild",
	beneGesserit: "games.duneimperium.factions.beneGesserit",
	fremen: "games.duneimperium.factions.fremen",
	green: "games.duneimperium.factions.green",
	blue: "games.duneimperium.factions.blue",
	yellow: "games.duneimperium.factions.yellow",
	any: "games.duneimperium.factions.any"
}, nn = {
	solari: "games.duneimperium.resources.solari",
	spice: "games.duneimperium.resources.spice",
	water: "games.duneimperium.resources.water",
	vp: "games.duneimperium.resources.vp",
	persuasion: "games.duneimperium.resources.persuasion",
	sword: "games.duneimperium.resources.sword"
};
function X(e, t) {
	return e ? t((g[e]?.nameKey ?? ve[e]?.nameKey ?? N[e]?.nameKey ?? _e.find((t) => t.id === e)?.nameKey ?? F[e]?.nameKey ?? Te[e]?.nameKey ?? tn[e]) || (e === "shipping" ? "games.duneimperium.shipping" : e === "rivalLeader" ? "games.duneimperium.chooseRivalLeader" : "games.duneimperium.effectCard")) : "";
}
function rn(e, t) {
	let n = g[e]?.textKey ?? ve[e]?.textKey ?? N[e]?.textKey ?? _e.find((t) => t.id === e)?.textKey;
	return n ? t(n) : "";
}
function Z(e, t) {
	switch (e.kind) {
		case "bundle": return e.effects.map((e) => Z(e, t)).join(" · ");
		case "gain": return t("games.duneimperium.effectGain", {
			n: e.n,
			resource: t(nn[e.resource])
		});
		case "draw": return t("games.duneimperium.effectDraw", { n: e.n });
		case "intrigue": return t("games.duneimperium.effectIntrigue", { n: e.n });
		case "troop": return t("games.duneimperium.effectTroop", { n: e.n });
		case "dread": return t("games.duneimperium.effectDread", { n: e.n });
		case "shipment": return t("games.duneimperium.effectShipping", { n: e.n });
		case "negotiator": return t("games.duneimperium.effectNegotiator", { n: e.n });
		case "influence": return t("games.duneimperium.effectInfluence", {
			faction: e.faction ? t(tn[e.faction]) : t("games.duneimperium.anyFaction"),
			n: e.n
		});
		case "pay": return t("games.duneimperium.effectPay", {
			cost: Object.entries(e.cost).map(([e, n]) => `${n} ${t(nn[e])}`).join(" + "),
			effect: e.effects.map((e) => Z(e, t)).join(" · ")
		});
		case "choice": return e.options.map((e) => e.map((e) => Z(e, t)).join(" · ")).join(" / ");
		case "if": return t("games.duneimperium.effectConditional", { effect: e.effects.map((e) => Z(e, t)).join(" · ") });
		case "trash": return t("games.duneimperium.effectTrash") + (e.after ? ` → ${e.after.map((e) => Z(e, t)).join(" · ")}` : "");
		case "discard": return t("games.duneimperium.effectDiscard", { n: e.n }) + (e.after?.length ? ` → ${e.after.map((e) => Z(e, t)).join(" · ")}` : "");
		case "tech": return t("games.duneimperium.effectTech", { n: e.discount });
		case "deploy": return t("games.duneimperium.effectDeploy", { n: e.n });
		case "retreat": return t("games.duneimperium.effectRetreat", { n: e.n }) + (e.after ? ` → ${e.after.map((e) => Z(e, t)).join(" · ")}` : "");
		case "flag": return e.flag === "spiceDiscount" ? t("games.duneimperium.effectDiscount", { n: e.n ?? 0 }) : e.flag === "bashar" || e.flag === "fullAssault" ? t("games.duneimperium.effectSwords") : t("games.duneimperium.effectCard");
		case "special": {
			let n = {
				signet: "games.duneimperium.effectSignet",
				harvest: "games.duneimperium.effectHarvest",
				extraTurn: "games.duneimperium.effectTurn",
				dividend: "games.duneimperium.effectDividend",
				twoFactions: "games.duneimperium.effectTwoFactions",
				advanceShip: "games.duneimperium.advanceShip",
				recallShip: "games.duneimperium.recallShip",
				trashCard: "games.duneimperium.trashCard",
				discardCard: "games.duneimperium.discardOne",
				passTurn: "games.duneimperium.passTurn",
				useSatellites: "games.duneimperium.detonate",
				exchangeFinish: "games.duneimperium.finish"
			};
			if (e.id === "recruitDeploy") return t("games.duneimperium.effectRecruitDeploy", { n: e.n ?? 1 });
			if (e.id === "control") return t("games.duneimperium.effectControl", { space: X(e.arg, t) });
			if (e.id === "freeCard" || e.id === "freeCardTop") return t(e.id === "freeCardTop" ? "games.duneimperium.effectFreeTop" : "games.duneimperium.effectFreeCard", { n: e.n ?? 1 });
			if (e.id === "revealPersuasion") return t("games.duneimperium.effectRevealPersuasion", { n: e.n ?? 1 });
			if (e.id === "shiftInfluence") return t("games.duneimperium.effectShift");
			let r = {
				council: "games.duneimperium.effectCouncil",
				swordmaster: "games.duneimperium.effectSwordmaster",
				mentat: "games.duneimperium.effectMentat",
				mentatNext: "games.duneimperium.effectMentatNext",
				foldspace: "games.duneimperium.effectFoldspace",
				shippingTroops: "games.duneimperium.effectShippingTroops",
				voice: "games.duneimperium.chooseVoice",
				stealIntrigues: "games.duneimperium.effectStealIntrigues",
				bounty: "games.duneimperium.effectBounty",
				gunThopter: "games.duneimperium.effectGunThopter",
				mohiam: "games.duneimperium.effectMohiam",
				humanity: "games.duneimperium.effectHumanity",
				shift: "games.duneimperium.effectShift",
				finesse: "games.duneimperium.effectFinesse",
				blackmail: "games.duneimperium.effectBlackmail",
				tessia: "games.duneimperium.effectTessia",
				memory: "games.duneimperium.chooseMemory",
				liet: "games.duneimperium.effectLiet",
				reinforcements: "games.duneimperium.effectReinforcements",
				refocus: "games.duneimperium.effectRefocus",
				peek: "games.duneimperium.effectPeek",
				bindu: "games.duneimperium.chooseBindu",
				doubleCross: "games.duneimperium.effectCross",
				stagedIncident: "games.duneimperium.effectStaged",
				cannonTurrets: "games.duneimperium.effectCannon",
				quidProQuo: "games.duneimperium.effectQuid",
				strongarm: "games.duneimperium.effectStrongarm",
				recallAgent: "games.duneimperium.chooseRecall",
				exchangeIntrigue: "games.duneimperium.chooseIntrigueExchange",
				reserveHelena: "games.duneimperium.chooseReserve",
				letoSignet: "games.duneimperium.effectLeto",
				scorePlans: "games.duneimperium.effectScorePlans",
				scoreCorner: "games.duneimperium.effectScoreCorner",
				scoreGrand: "games.duneimperium.effectScoreGrand",
				arrakeenSecond: "games.duneimperium.effectArrakeenSecond",
				dreadVictory: "games.duneimperium.chooseDreadControl",
				useSonic: "games.duneimperium.effectSonic",
				useSatellites: "games.duneimperium.effectSatellites",
				defend: "games.duneimperium.defend"
			};
			return r[e.id] ? t(r[e.id]) : t(n[e.id] ?? "games.duneimperium.effectCard");
		}
	}
}
function an(e, t) {
	let n = { ...e.params };
	(n.currency === "solari" || n.currency === "spice") && (n.currency = t(nn[n.currency])), typeof e.n == "number" && n.n === void 0 && (n.n = e.n);
	for (let e of ["from", "to"]) typeof n[e] == "string" && (n[e] = X(n[e], t));
	let r = t(e.key, n);
	return e.key === "games.duneimperium.effectOption" && e.preview?.length && (r = e.preview.map((e) => Z(e, t)).join(" · ")), e.card && (r = `${X(e.card.id, t)} · ${r}`), e.space && (r = `${X(e.space, t)} · ${r}`), e.target && (tn[e.target] || N[e.target] || _e.some((t) => t.id === e.target)) && (r = `${X(e.target, t)} · ${r}`), typeof n.cards == "string" && !e.card && (r += ` · ${n.cards.split(",").map((e) => X(e, t)).join(" / ")}`), r;
}
//#endregion
//#region src/games/duneimperium/art-assets.ts
var on = "\n  <linearGradient id=\"di-metal\" x2=\"0.9\" y2=\"1\"><stop stop-color=\"#425061\"/><stop offset=\".42\" stop-color=\"#1d2b3d\"/><stop offset=\"1\" stop-color=\"#121e2e\"/></linearGradient>\n  <linearGradient id=\"di-brass\" x2=\"0\" y2=\"1\"><stop stop-color=\"#e1c58c\"/><stop offset=\".45\" stop-color=\"#b38d55\"/><stop offset=\"1\" stop-color=\"#826443\"/></linearGradient>\n  <linearGradient id=\"di-terrain\" x2=\".7\" y2=\"1\"><stop stop-color=\"#d8bf92\"/><stop offset=\".42\" stop-color=\"#bb955f\"/><stop offset=\"1\" stop-color=\"#927147\"/></linearGradient>\n  <linearGradient id=\"di-sky\" x2=\"0\" y2=\"1\"><stop stop-color=\"#1b3449\"/><stop offset=\".7\" stop-color=\"#65777d\"/><stop offset=\"1\" stop-color=\"#cfb27c\"/></linearGradient>\n  <linearGradient id=\"di-cloth\" x2=\".9\" y2=\"1\"><stop stop-color=\"#738b99\"/><stop offset=\".4\" stop-color=\"#2e4d5e\"/><stop offset=\"1\" stop-color=\"#101d2b\"/></linearGradient>\n  <linearGradient id=\"di-paper\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f5e7c7\"/><stop offset=\"1\" stop-color=\"#cfb281\"/></linearGradient>\n  <pattern id=\"di-grain\" width=\"37\" height=\"41\" patternUnits=\"userSpaceOnUse\"><path d=\"M3 5h1m8 7h1m21 8h1M8 34h1m17 2h1M28 5h1M2 22h1\" stroke=\"#382e20\" stroke-width=\".5\" opacity=\".35\"/></pattern>\n  <pattern id=\"di-hatch\" width=\"6\" height=\"6\" patternUnits=\"userSpaceOnUse\" patternTransform=\"rotate(35)\"><path d=\"M0 0V6\" stroke=\"#f2d9a7\" stroke-opacity=\".16\" stroke-width=\"1\"/></pattern>\n  <clipPath id=\"di-viewport\"><rect width=\"375\" height=\"812\"/></clipPath>\n  <clipPath id=\"di-mapclip\"><rect x=\"103\" y=\"236\" width=\"263\" height=\"210\" rx=\"3\"/></clipPath>\n  <symbol id=\"di-solari\" viewBox=\"0 0 24 24\"><circle cx=\"12\" cy=\"12\" r=\"8.8\" fill=\"currentColor\"/><circle cx=\"12\" cy=\"12\" r=\"5.5\" fill=\"none\" stroke=\"#302b25\" stroke-width=\"1.5\"/><path d=\"M10 8h4l-4 8h4\" fill=\"none\" stroke=\"#302b25\" stroke-width=\"1.7\"/></symbol>\n  <symbol id=\"di-spice\" viewBox=\"0 0 24 24\"><path d=\"m12 2 9 5v10l-9 5-9-5V7Z\" fill=\"currentColor\"/><path d=\"m12 5 6 3-6 4-6-4Zm0 7v7\" fill=\"none\" stroke=\"#ffe4b0\" stroke-width=\"1\" opacity=\".7\"/></symbol>\n  <symbol id=\"di-water\" viewBox=\"0 0 24 24\"><path d=\"M12 1C9 7 4 12 4 16a8 8 0 0 0 16 0c0-4-5-9-8-15Z\" fill=\"currentColor\"/><path d=\"M8 13q-3 5 1 6\" fill=\"none\" stroke=\"#f8f1d8\" stroke-width=\"1.5\"/></symbol>\n  <symbol id=\"di-vp\" viewBox=\"0 0 24 24\"><path d=\"m12 1 3 7 8 4-8 3-3 8-3-8-8-3 8-4Z\" fill=\"currentColor\"/></symbol>\n  <symbol id=\"di-sword\" viewBox=\"0 0 24 24\"><path d=\"m16 2 5-1-1 6-10 11-4-4Z\" fill=\"currentColor\"/><path d=\"m3 12 9 9M3 21l4-4\" stroke=\"currentColor\" stroke-width=\"2.7\"/></symbol>\n  <symbol id=\"di-persuasion\" viewBox=\"0 0 24 24\"><path d=\"m12 1 10 11-10 11L2 12Z\" fill=\"currentColor\"/><path d=\"M8 9h8M10 12h6M8 15h5\" stroke=\"#293747\" stroke-width=\"1.4\"/></symbol>\n  <symbol id=\"di-agent\" viewBox=\"0 0 24 24\"><circle cx=\"12\" cy=\"4.5\" r=\"3.2\" fill=\"currentColor\" stroke=\"#0d1828\" stroke-width=\".8\"/><path d=\"M7 8h10l3 9-4 1 1 5H7l1-5-4-1Z\" fill=\"currentColor\" stroke=\"#0d1828\" stroke-width=\".8\"/></symbol>\n  <symbol id=\"di-agent-outline\" viewBox=\"0 0 24 24\"><circle cx=\"12\" cy=\"4.5\" r=\"3.2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\"/><path d=\"M7 9h10l3 8-4 1 1 5H7l1-5-4-1Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\"/></symbol>\n  <symbol id=\"di-draw\" viewBox=\"0 0 24 24\"><path d=\"M4 3h13v16H4Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"/><path d=\"M8 6h13v16H8Z\" fill=\"#31414e\" stroke=\"currentColor\" stroke-width=\"1.7\"/><path d=\"m11 14 3-3 4 4m-4-4v8\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\"/></symbol>\n  <symbol id=\"di-intrigue\" viewBox=\"0 0 24 24\"><path d=\"M5 2h14v20H5Z\" fill=\"#212737\" stroke=\"currentColor\" stroke-width=\"1.4\"/><path d=\"M8 13c0-7 8-8 8-3s-8 4-8 8m0-5h8\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.3\"/></symbol>\n  <symbol id=\"di-lock\" viewBox=\"0 0 24 24\"><rect x=\"4\" y=\"10\" width=\"16\" height=\"12\" rx=\"2\" fill=\"currentColor\"/><path d=\"M7 11V7a5 5 0 0 1 10 0v4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\"/><path d=\"M12 14v4\" stroke=\"#31414e\" stroke-width=\"2\"/></symbol>\n  <symbol id=\"di-check\" viewBox=\"0 0 24 24\"><path d=\"m5 12 5 5L20 6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.8\" stroke-linecap=\"round\"/></symbol>\n  <symbol id=\"di-back\" viewBox=\"0 0 24 24\"><path d=\"m14 5-7 7 7 7M7 12h14\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\"/></symbol>\n  <symbol id=\"di-zoom\" viewBox=\"0 0 24 24\"><path d=\"M3 9V3h6M15 3h6v6M21 15v6h-6M9 21H3v-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\"/></symbol>\n  <symbol id=\"di-city\" viewBox=\"0 0 24 24\"><path d=\"M2 21V9h6V3h8v9h6v9Zm8-13h4m-4 5h4m-4 5h4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/></symbol>\n  <symbol id=\"di-green\" viewBox=\"0 0 24 24\"><path d=\"m12 2 10 5-10 5L2 7Zm-8 9v8m6-6v8m5-8v8m5-10v8M2 22h20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"/></symbol>\n  <symbol id=\"di-yellow\" viewBox=\"0 0 24 24\"><path d=\"m12 2 9 18H3Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"/><path d=\"m7 16 4-6 3 6 3-3\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/></symbol>\n  <symbol id=\"di-emperor\" viewBox=\"0 0 24 24\"><path d=\"m2 6 5 4 5-8 5 8 5-4-3 13H5Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/><path d=\"M5 22h14M8 15h8\" stroke=\"currentColor\" stroke-width=\"1.7\"/></symbol>\n  <symbol id=\"di-guild\" viewBox=\"0 0 24 24\"><path d=\"M3 12C4 1 20 1 21 12M3 12c1 11 17 11 18 0M3 12h18m-9-10v20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/><path d=\"m7 12 5-4 5 4-5 4Z\" fill=\"currentColor\"/></symbol>\n  <symbol id=\"di-bene\" viewBox=\"0 0 24 24\"><path d=\"M12 12C-2-4-2 28 12 12S26-4 12 12 26 28 12 12Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/><path d=\"M12 4v16\" stroke=\"currentColor\" stroke-width=\"1.4\"/></symbol>\n  <symbol id=\"di-fremen\" viewBox=\"0 0 24 24\"><path d=\"M2 12c6-9 14-9 20 0-6 9-14 9-20 0Zm10-8v16M2 12h20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/><circle cx=\"12\" cy=\"12\" r=\"3\" fill=\"currentColor\"/></symbol>\n  <symbol id=\"di-freighter\" viewBox=\"0 0 32 24\"><path d=\"M4 8 24 4l6 6-6 7L4 16 1 12Z\" fill=\"currentColor\" stroke=\"#142235\" stroke-width=\"1\"/><path d=\"m8 9 14-2 4 3-4 4H8Z\" fill=\"#192d40\"/><path d=\"M10 10h11M6 19h17\" stroke=\"#ead4a6\" stroke-width=\"1\"/></symbol>\n  <symbol id=\"di-dread\" viewBox=\"0 0 42 24\"><path d=\"m1 13 10-6 12 1 5-5 6 2 7 9-13 5-16-1Z\" fill=\"currentColor\" stroke=\"#172331\" stroke-width=\"1.2\"/><path d=\"m10 11 15 1 6-4 4 6-10 1Z\" fill=\"#162637\"/><path d=\"M15 6V2m5 6V4M6 14l18 3\" fill=\"none\" stroke=\"#e0ca9b\" stroke-width=\"1\"/></symbol>\n<symbol id=\"di-art-planet\" viewBox=\"0 0 82 83\"><rect x=\"0\" y=\"0\" width=\"82\" height=\"83\" rx=\"0\" fill=\"url(#di-sky)\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"53\" cy=\"24\" r=\"24\" fill=\"#aa8c59\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M37 9q20-1 35 16m-43-9q19 0 47 18m-47-7q18-3 43 15\" fill=\"none\" stroke=\"#ddc48c\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"16\" cy=\"15\" r=\"5\" fill=\"#cdd5d0\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M-4 76q34-39 94-17L82 86H0Z\" fill=\"#b09567\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M-4 75q40-8 90 8H0Z\" fill=\"#dec18a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M4 77q23-18 47-12\" fill=\"none\" stroke=\"#f2d9a6\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></symbol><symbol id=\"di-art-dagger\" viewBox=\"0 0 82 83\"><rect x=\"0\" y=\"0\" width=\"82\" height=\"83\" rx=\"0\" fill=\"#3a444d\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M-5 70 85 9m-90 73L85 22\" fill=\"none\" stroke=\"#57616a\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m52 5 13-2-3 14-31 40-11-9Z\" fill=\"#becacd\" stroke=\"#e8e6d0\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m53 8-24 39m0-1 28-30\" fill=\"none\" stroke=\"#5b7881\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m16 43 22 18-5 6-23-17Z\" fill=\"#c5a768\" stroke=\"#5b4b37\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m22 57-13 19 7 5 13-20Z\" fill=\"#474c4b\" stroke=\"#b7a16e\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m18 63 7 6m-10-1 7 6\" fill=\"none\" stroke=\"#b4b09c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"12\" cy=\"77\" r=\"3\" fill=\"#d9bb76\" stroke=\"none\" stroke-width=\"1\"/></symbol><symbol id=\"di-art-diplomacy\" viewBox=\"0 0 82 83\"><rect x=\"0\" y=\"0\" width=\"82\" height=\"83\" rx=\"0\" fill=\"url(#di-sky)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M4 8v67m73-68v69\" fill=\"none\" stroke=\"#c6b17f\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M5 9h20v34L15 34 5 42Z\" fill=\"#72563c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><use href=\"#di-emperor\" x=\"7\" y=\"15\" width=\"16\" height=\"16\" style=\"color:#e2be75\" /><path d=\"M57 8h20v34L67 34l-10 8Z\" fill=\"#4b3655\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><use href=\"#di-bene\" x=\"59\" y=\"15\" width=\"16\" height=\"16\" style=\"color:#d4add8\" /><path d=\"M18 83 19 47l12-10 10 4 8-4 13 10 3 36Z\" fill=\"#1e3240\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M26 39 27 22l9-6 10 10-2 14-8 7Z\" fill=\"#b7a185\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 24 29 15h9l10 10-9-5-12 8Z\" fill=\"#3a3031\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m29 29 4-1m5 1 4 1m-6 0-1 7h3m-6 3h7\" fill=\"none\" stroke=\"#5c4b3f\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M17 83 14 61l12-10 10 12 10-12 16 12 7 20Z\" fill=\"#8d7d60\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m26 67 11 6 13-6m-26 0 3 12m24-12-3 12\" fill=\"none\" stroke=\"#e6ca95\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"37\" cy=\"73\" r=\"2\" fill=\"#e4c484\" stroke=\"none\" stroke-width=\"1\"/></symbol><symbol id=\"di-art-recon\" viewBox=\"0 0 82 83\"><rect x=\"0\" y=\"0\" width=\"82\" height=\"83\" rx=\"0\" fill=\"url(#di-sky)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M0 68q45-27 85-11v26H0Z\" fill=\"#b79c6e\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 83 24 53l12-8 18 4 20 34Z\" fill=\"#293e4a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 60 26 28 35 20l17 5 9 25-15 19Z\" fill=\"#506671\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M26 42 31 28l15-2 10 11-8 16-12 2Z\" fill=\"#bba27f\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m27 44 8-8 18 2-1 8-19 6Z\" fill=\"#1c2d3a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m35 43 4-1m8-1 3 1\" fill=\"none\" stroke=\"#8edbf3\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M25 55 18 83h50L53 59 38 67Z\" fill=\"#345061\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m37 67 4 15m-8-20 10 9 12-8\" fill=\"none\" stroke=\"#9aa7a3\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M62 46v35m-2-33 7 1\" fill=\"none\" stroke=\"#c2b186\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></symbol><symbol id=\"di-art-ring\" viewBox=\"0 0 82 83\"><rect x=\"0\" y=\"0\" width=\"82\" height=\"83\" rx=\"0\" fill=\"#283847\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M0 73 82 14M0 81 82 24\" fill=\"none\" stroke=\"#3e505b\" stroke-width=\"20\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"42\" cy=\"53\" rx=\"22\" ry=\"24\" fill=\"none\" stroke=\"#6d5433\" stroke-width=\"10\"/><ellipse cx=\"39\" cy=\"50\" rx=\"22\" ry=\"24\" fill=\"none\" stroke=\"#d2b475\" stroke-width=\"7\"/><path d=\"m19 36 1-18 18-9 20 9 2 18-20 11Z\" fill=\"#9f7b45\" stroke=\"#e5c993\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m24 32 1-12 13-6 15 6 1 12-15 8Z\" fill=\"#293e48\" stroke=\"#5e7778\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m28 24 10 3 10-3-7 7 1 3-4-2-4 2 1-3Z\" fill=\"#dec18a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 54q2 11 8 14\" fill=\"none\" stroke=\"#f4dfb2\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></symbol><symbol id=\"di-city-arrakeen\" viewBox=\"0 0 132 92\"><path d=\"M5 81 17 70h93l20 11Z\" fill=\"#7a6752\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M13 75V42h26V28h55v47Z\" fill=\"#a9a68f\" stroke=\"#454d4e\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M39 75V28h55v47Z\" fill=\"#ddd0ac\" stroke=\"#555b56\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M49 28V17h35v11Z\" fill=\"#c1bfa3\" stroke=\"#555b56\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M55 17V8h24v9Z\" fill=\"#d2ceb4\" stroke=\"#555b56\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M2 75V53h20v22m76 0V42h21v33\" fill=\"#aaa88f\" stroke=\"#4b5753\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m22 42 7-18 7 18m66 0 7-19 7 19\" fill=\"#b8bba1\" stroke=\"#4b5753\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><rect x=\"44\" y=\"42\" width=\"3\" height=\"22\" rx=\"0\" fill=\"#4d6568\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"52\" y=\"42\" width=\"3\" height=\"22\" rx=\"0\" fill=\"#4d6568\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"60\" y=\"42\" width=\"3\" height=\"22\" rx=\"0\" fill=\"#4d6568\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"68\" y=\"42\" width=\"3\" height=\"22\" rx=\"0\" fill=\"#4d6568\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"76\" y=\"42\" width=\"3\" height=\"22\" rx=\"0\" fill=\"#4d6568\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"84\" y=\"42\" width=\"3\" height=\"22\" rx=\"0\" fill=\"#4d6568\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"59\" y=\"61\" width=\"14\" height=\"15\" rx=\"0\" fill=\"#293f46\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M18 80h94m-90 4h84m-75 4h66\" fill=\"none\" stroke=\"#d6bd8b\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 8V0l11 4-11 3\" fill=\"#3978e4\" stroke=\"#31404b\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></symbol><symbol id=\"di-city-carthag\" viewBox=\"0 0 132 92\"><path d=\"M4 81 30 70l84 3 16 8Z\" fill=\"#785a45\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M12 76 22 29l15 8 2 39Z\" fill=\"#746e65\" stroke=\"#393d3d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M35 76 43 9l21 13 1 54Z\" fill=\"#a39a80\" stroke=\"#393d3d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m66 76 4-56 18-12 13 68Z\" fill=\"#8d8a78\" stroke=\"#393d3d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m100 76 1-37 14-15 10 52Z\" fill=\"#b1a48a\" stroke=\"#393d3d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m43 9 3 67m24-56 18-12 3 65m10-34 9 33\" fill=\"none\" stroke=\"#d8bc8b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m48 31 10 5m19 -3 10 -3\" fill=\"none\" stroke=\"#3d5053\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m48 38 10 5m19 -3 10 -3\" fill=\"none\" stroke=\"#3d5053\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m48 45 10 5m19 -3 10 -3\" fill=\"none\" stroke=\"#3d5053\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m48 52 10 5m19 -3 10 -3\" fill=\"none\" stroke=\"#3d5053\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m48 59 10 5m19 -3 10 -3\" fill=\"none\" stroke=\"#3d5053\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M14 79h108m-92 6h75\" fill=\"none\" stroke=\"#d7b87e\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></symbol><symbol id=\"di-city-research\" viewBox=\"0 0 132 92\"><path d=\"M7 80 25 70l82-1 18 11Z\" fill=\"#8f7c5a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M25 75V59Q25 34 50 34t25 25v16Z\" fill=\"#d0c6a6\" stroke=\"#4a5c61\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M34 73V58Q34 44 49 44t16 15v14Z\" fill=\"#a6b2aa\" stroke=\"#4a5c61\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><rect x=\"48\" y=\"59\" width=\"9\" height=\"16\" rx=\"0\" fill=\"#344b53\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"82\" y=\"53\" width=\"28\" height=\"22\" rx=\"0\" fill=\"#b3baa7\" stroke=\"#4a5c61\" stroke-width=\"1\" /><path d=\"M88 53V29M105 53V31M78 15q18 25 36 0-17 8-36 0Z\" fill=\"#a7b8b3\" stroke=\"#4a5c61\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m97 30 2-18 9-8M17 75V32m-6 8h13m-7-7 7-6\" fill=\"none\" stroke=\"#53696b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"108\" cy=\"4\" r=\"2\" fill=\"#88d9f3\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M8 79h111\" fill=\"none\" stroke=\"#d9c18f\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></symbol><symbol id=\"di-city-sietch\" viewBox=\"0 0 132 92\"><path d=\"M-2 81 14 54 24 47 31 21 42 7 57 19 66 51 76 35 88 42 97 19 107 10 117 43 134 81Z\" fill=\"#8b6c4e\" stroke=\"#70533b\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m31 21 11-14 7 37-4 22m52-47 10-9-2 55M14 54l19 6-5 14m48-39 7 30\" fill=\"none\" stroke=\"#d7b783\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M46 77V58q8-14 17 0v19Z\" fill=\"#273944\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M50 76V60q5-8 10 0v16Z\" fill=\"#162937\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m70 76 2-17 9-7 6 24Z\" fill=\"#3b4643\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M9 81h112m-80 4h54\" fill=\"none\" stroke=\"#d9b981\" stroke-width=\"1.1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M31 69q11-6 18 0m12 2q8-5 12-2\" fill=\"none\" stroke=\"#aa8a5e\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></symbol><symbol id=\"di-portrait-paul\" viewBox=\"0 0 60 60\"><defs><clipPath id=\"di-face-paul-0-0\"><rect width=\"60\" height=\"60\" rx=\"3\"/></clipPath></defs><g transform=\"translate(0 0)\" ><g clip-path=\"url(#di-face-paul-0-0)\"><rect x=\"0\" y=\"0\" width=\"60\" height=\"60\" rx=\"0\" fill=\"#253747\" stroke=\"none\" stroke-width=\"1\" /><g transform=\"scale(1 1)\"><path d=\"M0 58 7 27 17 8 29 1 42 8 54 28 60 58Z\" fill=\"url(#di-cloth)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M15 33 15 18 24 9 39 11 45 22 43 38 30 47 20 41Z\" fill=\"#c7a380\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m14 27 3-15 17-9 12 13-8-2-9 5-8 2-2 11Z\" fill=\"#222a30\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m18 32 8-2m9 0 6 2\" fill=\"none\" stroke=\"#183848\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"24\" cy=\"31\" r=\"1.3\" fill=\"#70d8ff\" stroke=\"none\" stroke-width=\"1\"/><circle cx=\"37\" cy=\"32\" r=\"1.3\" fill=\"#70d8ff\" stroke=\"none\" stroke-width=\"1\"/><path d=\"m30 31-2 6h4m-8 4h10\" fill=\"none\" stroke=\"#705745\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m9 44 13 3 11 12H0Zm31-2-5 6-3 10h28Z\" fill=\"#243b4a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g></g></g></symbol><symbol id=\"di-portrait-baron\" viewBox=\"0 0 60 60\"><defs><clipPath id=\"di-face-baron-0-0\"><rect width=\"60\" height=\"60\" rx=\"3\"/></clipPath></defs><g transform=\"translate(0 0)\" ><g clip-path=\"url(#di-face-baron-0-0)\"><rect x=\"0\" y=\"0\" width=\"60\" height=\"60\" rx=\"0\" fill=\"#253747\" stroke=\"none\" stroke-width=\"1\" /><g transform=\"scale(1 1)\"><path d=\"M0 58 4 32 20 25h23l15 15 2 18Z\" fill=\"#5d2927\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M10 25Q10 3 30 4T50 26L44 44 31 51 16 44Z\" fill=\"#c1a081\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M17 28h9m11 0h8m-15 3-2 7h8m-12 5h14\" fill=\"none\" stroke=\"#5a4c40\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m0 46 20-3 11 12 12-12 17 4v13H0Z\" fill=\"#392b2a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m20 8 21 2m-20 4 21 1\" fill=\"none\" stroke=\"#d5b899\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g></g></g></symbol><symbol id=\"di-portrait-tessia\" viewBox=\"0 0 60 60\"><defs><clipPath id=\"di-face-tessia-0-0\"><rect width=\"60\" height=\"60\" rx=\"3\"/></clipPath></defs><g transform=\"translate(0 0)\" ><g clip-path=\"url(#di-face-tessia-0-0)\"><rect x=\"0\" y=\"0\" width=\"60\" height=\"60\" rx=\"0\" fill=\"#253747\" stroke=\"none\" stroke-width=\"1\" /><g transform=\"scale(1 1)\"><path d=\"M0 58 6 36 17 30h25l15 18 3 10Z\" fill=\"#583d65\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M11 29Q5 2 28 2t23 30L41 46H16Z\" fill=\"#39313c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M18 17 27 10 39 13 44 24 39 40 30 46 20 39Z\" fill=\"#c5a58e\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m17 21 7-5 17 4-4-11-15-1Z\" fill=\"#302c35\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 28h7m6 0h7m-11 3-2 5h4m-7 5h10\" fill=\"none\" stroke=\"#665143\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M10 21v30m38-29v29\" fill=\"none\" stroke=\"#141d27\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m20 47 10 9 11-11\" fill=\"none\" stroke=\"#ae88b9\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g></g></g></symbol><symbol id=\"di-portrait-rhombur\" viewBox=\"0 0 60 60\"><defs><clipPath id=\"di-face-rhombur-0-0\"><rect width=\"60\" height=\"60\" rx=\"3\"/></clipPath></defs><g transform=\"translate(0 0)\" ><g clip-path=\"url(#di-face-rhombur-0-0)\"><rect x=\"0\" y=\"0\" width=\"60\" height=\"60\" rx=\"0\" fill=\"#253747\" stroke=\"none\" stroke-width=\"1\" /><g transform=\"scale(1 1)\"><path d=\"M0 58 9 37 22 31h20l13 13 5 14Z\" fill=\"#47366b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M14 24 17 8 29 3 43 9 48 26 41 43 29 48 18 39Z\" fill=\"#b99473\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M14 19 20 6 32 2 44 10l2 11-11-8-12 1Z\" fill=\"#76563d\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"m18 32 10 4 12-5-2 13-8 7-9-8Z\" fill=\"#66503e\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M34 19h11v12H33Z\" fill=\"#7b929d\" stroke=\"#c0d7df\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"39\" cy=\"25\" r=\"2\" fill=\"#80dbf4\" stroke=\"none\" stroke-width=\"1\"/><path d=\"m16 26 10-1\" fill=\"none\" stroke=\"#302d28\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M7 46 25 58m17-15 12 14\" fill=\"none\" stroke=\"#b5a1c5\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g></g></g></symbol>", sn = "<linearGradient id=\"di-r-metal\" x2=\".8\" y2=\"1\"><stop offset=\"0\" stop-color=\"#6c7474\"/><stop offset=\"0.22\" stop-color=\"#2e3a3f\"/><stop offset=\"0.65\" stop-color=\"#18252d\"/><stop offset=\"1\" stop-color=\"#0c151d\"/></linearGradient>\n<linearGradient id=\"di-r-paper\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#d8caaa\"/><stop offset=\"0.5\" stop-color=\"#b8a88c\"/><stop offset=\"1\" stop-color=\"#9b8c75\"/></linearGradient>\n<linearGradient id=\"di-r-sand\" x2=\".6\" y2=\"1\"><stop offset=\"0\" stop-color=\"#c8b18a\"/><stop offset=\"0.35\" stop-color=\"#b19a72\"/><stop offset=\"1\" stop-color=\"#776349\"/></linearGradient>\n<linearGradient id=\"di-r-sunlit\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#e8d7ae\"/><stop offset=\"0.45\" stop-color=\"#c3a476\"/><stop offset=\"1\" stop-color=\"#9b774c\"/></linearGradient>\n<linearGradient id=\"di-r-rock\" x2=\".7\" y2=\"1\"><stop offset=\"0\" stop-color=\"#7a776c\"/><stop offset=\"0.4\" stop-color=\"#55564f\"/><stop offset=\"1\" stop-color=\"#303c3d\"/></linearGradient>\n<linearGradient id=\"di-r-gold\" x2=\".9\" y2=\"1\"><stop offset=\"0\" stop-color=\"#e0c68a\"/><stop offset=\"0.25\" stop-color=\"#b99453\"/><stop offset=\"0.55\" stop-color=\"#f1dca0\"/><stop offset=\"0.8\" stop-color=\"#8a6735\"/><stop offset=\"1\" stop-color=\"#c5a66b\"/></linearGradient>\n<linearGradient id=\"di-r-sky\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#33484f\"/><stop offset=\"0.5\" stop-color=\"#7e8984\"/><stop offset=\"1\" stop-color=\"#e3d3b0\"/></linearGradient>\n<linearGradient id=\"di-r-night\" x2=\".8\" y2=\"1\"><stop offset=\"0\" stop-color=\"#0a1524\"/><stop offset=\"0.6\" stop-color=\"#203749\"/><stop offset=\"1\" stop-color=\"#52646a\"/></linearGradient>\n<linearGradient id=\"di-r-navy\" x2=\".4\" y2=\"1\"><stop offset=\"0\" stop-color=\"#233847\"/><stop offset=\"0.5\" stop-color=\"#142330\"/><stop offset=\"1\" stop-color=\"#0b1721\"/></linearGradient>\n<linearGradient id=\"di-r-skin\" x2=\".85\" y2=\".4\"><stop offset=\"0\" stop-color=\"#d6b18e\"/><stop offset=\"0.35\" stop-color=\"#c79c77\"/><stop offset=\"0.64\" stop-color=\"#a67758\"/><stop offset=\"1\" stop-color=\"#614c40\"/></linearGradient>\n<linearGradient id=\"di-r-skinBaron\" x2=\".9\" y2=\".3\"><stop offset=\"0\" stop-color=\"#c1b3a0\"/><stop offset=\"0.5\" stop-color=\"#a39786\"/><stop offset=\"1\" stop-color=\"#6b6a61\"/></linearGradient>\n<linearGradient id=\"di-r-cloth\" x2=\".8\" y2=\"1\"><stop offset=\"0\" stop-color=\"#8a9694\"/><stop offset=\"0.4\" stop-color=\"#566a70\"/><stop offset=\"1\" stop-color=\"#1a313f\"/></linearGradient>\n<linearGradient id=\"di-r-wine\" x2=\".5\" y2=\"1\"><stop offset=\"0\" stop-color=\"#514648\"/><stop offset=\"0.5\" stop-color=\"#33272e\"/><stop offset=\"1\" stop-color=\"#1c2026\"/></linearGradient>\n<linearGradient id=\"di-r-steel\" x2=\".8\" y2=\"1\"><stop offset=\"0\" stop-color=\"#dbdfd5\"/><stop offset=\"0.28\" stop-color=\"#8d9b9e\"/><stop offset=\"0.55\" stop-color=\"#e2dfc9\"/><stop offset=\"0.7\" stop-color=\"#5c737e\"/><stop offset=\"1\" stop-color=\"#293e49\"/></linearGradient>\n<linearGradient id=\"di-r-blade\" x2=\".85\" y2=\".3\"><stop offset=\"0\" stop-color=\"#f2ebd0\"/><stop offset=\"0.35\" stop-color=\"#bcc7c4\"/><stop offset=\"0.48\" stop-color=\"#f8f3d8\"/><stop offset=\"0.51\" stop-color=\"#859b9d\"/><stop offset=\"1\" stop-color=\"#273e4d\"/></linearGradient>\n<linearGradient id=\"di-r-haze\" x2=\".7\" y2=\"1\"><stop offset=\"0\" stop-color=\"#c6c3a6\"/><stop offset=\"1\" stop-color=\"#5f797f\"/></linearGradient>\n<pattern id=\"di-r-grain\" width=\"43\" height=\"47\" patternUnits=\"userSpaceOnUse\"><circle cx=\"3\" cy=\"5\" r=\"0.45\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"20\" cy=\"34\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"37\" cy=\"16\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"11\" cy=\"45\" r=\"0.45\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"28\" cy=\"27\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"2\" cy=\"9\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"19\" cy=\"38\" r=\"0.45\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"36\" cy=\"20\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"10\" cy=\"2\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"27\" cy=\"31\" r=\"0.45\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"1\" cy=\"13\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"18\" cy=\"42\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"35\" cy=\"24\" r=\"0.45\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"9\" cy=\"6\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"26\" cy=\"35\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"0\" cy=\"17\" r=\"0.45\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"17\" cy=\"46\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"34\" cy=\"28\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"8\" cy=\"10\" r=\"0.45\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"25\" cy=\"39\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"42\" cy=\"21\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"16\" cy=\"3\" r=\"0.45\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"33\" cy=\"32\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"7\" cy=\"14\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"24\" cy=\"43\" r=\"0.45\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"41\" cy=\"25\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"15\" cy=\"7\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"32\" cy=\"36\" r=\"0.45\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"6\" cy=\"18\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"23\" cy=\"0\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"40\" cy=\"29\" r=\"0.45\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"14\" cy=\"11\" r=\"0.28\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"31\" cy=\"40\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/><circle cx=\"5\" cy=\"22\" r=\"0.45\" fill=\"#fff4d0\" stroke=\"none\" opacity=\".055\"/><circle cx=\"22\" cy=\"4\" r=\"0.28\" fill=\"#152529\" stroke=\"none\" opacity=\".055\"/></pattern>\n<pattern id=\"di-r-etch\" width=\"7\" height=\"7\" patternTransform=\"rotate(34)\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0L0 7\" stroke=\"#e6d0a0\" stroke-width=\"0.55\" fill=\"none\" opacity=\".12\"/></pattern>\n<clipPath id=\"di-r-artClip\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"white\" stroke=\"none\" /></clipPath>\n<symbol id=\"di-r-art-desert\" viewBox=\"0 0 320 260\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-sky)\" stroke=\"none\" /><circle cx=\"247\" cy=\"45\" r=\"24\" fill=\"#d9d5bc\" stroke=\"none\" opacity=\".6\"/><path d=\"M0 127Q56 83 111 115T231 110 320 122V260H0Z\" fill=\"#c8b68f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M0 161Q66 95 161 135T320 119V260H0Z\" fill=\"url(#di-r-sunlit)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M0 170Q89 120 161 139 208 153 248 132 196 170 106 161T0 199Z\" fill=\"#ac885a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M0 213Q102 143 207 178T320 167V260H0Z\" fill=\"#d9bd8d\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M0 216q108-47 193-26t127-15v85H0Z\" fill=\"#b79563\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M20 221q92-32 158-22m45 3q53 8 96-5M1 174q46-31 98-34M179 150q52 14 100-13\" fill=\"none\" stroke=\"#ebd7aa\" stroke-width=\"1.3\" /><path d=\"M-35 230q105-35 215-9t155-4\" fill=\"none\" stroke=\"#876b4b\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M-28 233q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M-21 236q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M-14 239q105-35 215-9t155-4\" fill=\"none\" stroke=\"#876b4b\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M-7 242q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M0 245q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M7 248q105-35 215-9t155-4\" fill=\"none\" stroke=\"#876b4b\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M14 251q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M21 254q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M28 257q105-35 215-9t155-4\" fill=\"none\" stroke=\"#876b4b\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M35 260q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M42 263q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M49 266q105-35 215-9t155-4\" fill=\"none\" stroke=\"#876b4b\" stroke-width=\"0.45\" opacity=\".37\"/><path d=\"M56 269q105-35 215-9t155-4\" fill=\"none\" stroke=\"#e8cc99\" stroke-width=\"0.45\" opacity=\".37\"/><g transform=\"translate(106 155) scale(0.94)\"><path d=\"m-13 41 142-5 26 10-127 16Z\" fill=\"#7a6245\" stroke=\"none\" stroke-width=\"1\" opacity=\".45\"/><path d=\"M0 19 28 6l95 2 21 17-25 26H11Z\" fill=\"#3e4440\" stroke=\"#283637\" stroke-width=\"1.2\" /><path d=\"M0 10 28 0l97 1 19 15-28 13L0 25Z\" fill=\"#aea78e\" stroke=\"#4e554b\" stroke-width=\"1\" /><path d=\"M0 25 116 4l28 12-28 13v17L0 39Z\" fill=\"#7c7c65\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M17 8 100 7l17 6-86 11-14-4Z\" fill=\"#c4b99c\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"16\" y=\"25\" width=\"16\" height=\"27\" rx=\"2\" fill=\"#252f2f\" stroke=\"#7a7965\" /><path d=\"M18 31L30 31\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M18 37L30 37\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M18 43L30 43\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><rect x=\"47\" y=\"23.8\" width=\"16\" height=\"27\" rx=\"2\" fill=\"#252f2f\" stroke=\"#7a7965\" /><path d=\"M49 30L61 30\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M49 36L61 36\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M49 42L61 42\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><rect x=\"80\" y=\"22.6\" width=\"16\" height=\"27\" rx=\"2\" fill=\"#252f2f\" stroke=\"#7a7965\" /><path d=\"M82 29L94 29\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M82 35L94 35\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M82 41L94 41\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><rect x=\"111\" y=\"21.4\" width=\"16\" height=\"27\" rx=\"2\" fill=\"#252f2f\" stroke=\"#7a7965\" /><path d=\"M113 28L125 28\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M113 34L125 34\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M113 40L125 40\" stroke=\"#596052\" stroke-width=\"1\" fill=\"none\" /><path d=\"M37 5L50 14\" stroke=\"#6c6d58\" stroke-width=\"2\" fill=\"none\" /><path d=\"M47 5L60 14\" stroke=\"#6c6d58\" stroke-width=\"2\" fill=\"none\" /><path d=\"M57 5L70 14\" stroke=\"#6c6d58\" stroke-width=\"2\" fill=\"none\" /><path d=\"M67 5L80 14\" stroke=\"#6c6d58\" stroke-width=\"2\" fill=\"none\" /><path d=\"M77 5L90 14\" stroke=\"#6c6d58\" stroke-width=\"2\" fill=\"none\" /><path d=\"M87 5L100 14\" stroke=\"#6c6d58\" stroke-width=\"2\" fill=\"none\" /><rect x=\"8\" y=\"15\" width=\"24\" height=\"8\" rx=\"0.6\" fill=\"#26373a\" stroke=\"#c9b48b\" /><path d=\"M13 16L13 22\" stroke=\"#899d9c\" stroke-width=\"1\" fill=\"none\" /><path d=\"M23 16L23 22\" stroke=\"#899d9c\" stroke-width=\"1\" fill=\"none\" /><path d=\"m116 28 17-7-4 15-13 8Z\" fill=\"#3b4846\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"7\" cy=\"34\" r=\"1.8\" fill=\"#e0b357\" stroke=\"none\" /><circle cx=\"107\" cy=\"28\" r=\"1.8\" fill=\"#e0b357\" stroke=\"none\" /></g><path d=\"M0 255q103-24 177-9t143-5v19H0Z\" fill=\"#d2b581\" stroke=\"none\" stroke-width=\"1\" /></symbol>\n<symbol id=\"di-r-art-dagger\" viewBox=\"0 0 320 260\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-night)\" stroke=\"none\" /><path d=\"M200 0 150 260M267 0 197 260M314 19 244 260\" fill=\"none\" stroke=\"#87938a\" stroke-width=\"18\" opacity=\".08\"/><path d=\"M-10 3 31-7l43 39 26 8 7 31-15 28-29-3-25-34-22-4Z\" fill=\"url(#di-r-skin)\" stroke=\"#8b6850\" stroke-width=\"1\" /><path d=\"m34 47 29-9 31 20-4 22-20-12-29-1Z\" fill=\"#ba8d62\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m94 73 21-11 171 159-32-5-141-101Z\" fill=\"url(#di-r-blade)\" stroke=\"#d2cfaf\" stroke-width=\"0.8\" /><path d=\"m107 80 179 141-140-113Z\" fill=\"#ecedd9\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m107 80 39 28 117 105-141-105Z\" fill=\"#859c9f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m68 73 13-25 14-4 25 43-10 18-11-18-11 6-8 15-10-7 7-17Z\" fill=\"url(#di-r-gold)\" stroke=\"#524938\" stroke-width=\"1.2\" /><path d=\"m42 30 18-9 34 26-14 25-19-9Z\" fill=\"#263b3d\" stroke=\"#c3aa77\" stroke-width=\"1.2\" /><path d=\"m47 34 15 12\" fill=\"none\" stroke=\"#8e9c83\" stroke-width=\"2\" /><path d=\"m55 39 15 12\" fill=\"none\" stroke=\"#8e9c83\" stroke-width=\"2\" /><path d=\"m63 44 15 12\" fill=\"none\" stroke=\"#8e9c83\" stroke-width=\"2\" /><path d=\"m71 49 15 12\" fill=\"none\" stroke=\"#8e9c83\" stroke-width=\"2\" /><path d=\"M6 116q37-17 73 19t32 125H0Z\" fill=\"#17313d\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m10 150 23-7 19 34m12 31 18 18\" fill=\"none\" stroke=\"#4b6067\" stroke-width=\"2\" /><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-art-recon\" viewBox=\"0 0 320 260\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"#9caa9f\" stroke=\"none\" /><path d=\"M0 16 320 65M-40 106 320 156M-30 194 320 240\" fill=\"none\" stroke=\"#52655f\" stroke-width=\"15\" /><path d=\"M81-20 3 280M218-20 125 280M344-20 256 280\" fill=\"none\" stroke=\"#52655f\" stroke-width=\"15\" /><path d=\"m12 44 27 -7 10 6-27 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m12 44 10 7v12l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m22 51 27-8v12l-27 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"24\" y=\"42\" width=\"17\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m55 44 34 -7 10 6-34 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m55 44 10 7v17l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m65 51 34-8v17l-34 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"67\" y=\"42\" width=\"24\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m98 44 28 -7 10 6-28 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m98 44 10 7v14l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m108 51 28-8v14l-28 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"110\" y=\"42\" width=\"18\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m141 44 35 -7 10 6-35 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m141 44 10 7v19l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m151 51 35-8v19l-35 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"153\" y=\"42\" width=\"25\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m184 44 29 -7 10 6-29 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m184 44 10 7v16l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m194 51 29-8v16l-29 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"196\" y=\"42\" width=\"19\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m227 44 36 -7 10 6-36 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m227 44 10 7v13l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m237 51 36-8v13l-36 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"239\" y=\"42\" width=\"26\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m270 44 30 -7 10 6-30 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m270 44 10 7v18l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m280 51 30-8v18l-30 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"282\" y=\"42\" width=\"20\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m30 75 30 -7 10 6-30 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m30 75 10 7v15l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m40 82 30-8v15l-30 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"42\" y=\"73\" width=\"20\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m73 75 37 -7 10 6-37 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m73 75 10 7v12l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m83 82 37-8v12l-37 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"85\" y=\"73\" width=\"27\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m116 75 31 -7 10 6-31 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m116 75 10 7v17l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m126 82 31-8v17l-31 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"128\" y=\"73\" width=\"21\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m159 75 38 -7 10 6-38 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m159 75 10 7v14l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m169 82 38-8v14l-38 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"171\" y=\"73\" width=\"28\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m202 75 32 -7 10 6-32 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m202 75 10 7v19l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m212 82 32-8v19l-32 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"214\" y=\"73\" width=\"22\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m245 75 39 -7 10 6-39 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m245 75 10 7v16l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m255 82 39-8v16l-39 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"257\" y=\"73\" width=\"29\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m288 75 33 -7 10 6-33 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m288 75 10 7v13l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m298 82 33-8v13l-33 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"300\" y=\"73\" width=\"23\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m12 106 33 -7 10 6-33 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m12 106 10 7v18l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m22 113 33-8v18l-33 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"24\" y=\"104\" width=\"23\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m55 106 27 -7 10 6-27 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m55 106 10 7v15l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m65 113 27-8v15l-27 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"67\" y=\"104\" width=\"17\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m98 106 34 -7 10 6-34 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m98 106 10 7v12l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m108 113 34-8v12l-34 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"110\" y=\"104\" width=\"24\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m141 106 28 -7 10 6-28 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m141 106 10 7v17l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m151 113 28-8v17l-28 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"153\" y=\"104\" width=\"18\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m184 106 35 -7 10 6-35 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m184 106 10 7v14l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m194 113 35-8v14l-35 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"196\" y=\"104\" width=\"25\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m227 106 29 -7 10 6-29 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m227 106 10 7v19l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m237 113 29-8v19l-29 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"239\" y=\"104\" width=\"19\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m270 106 36 -7 10 6-36 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m270 106 10 7v16l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m280 113 36-8v16l-36 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"282\" y=\"104\" width=\"26\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m30 137 36 -7 10 6-36 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m30 137 10 7v13l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m40 144 36-8v13l-36 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"42\" y=\"135\" width=\"26\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m73 137 30 -7 10 6-30 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m73 137 10 7v18l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m83 144 30-8v18l-30 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"85\" y=\"135\" width=\"20\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m116 137 37 -7 10 6-37 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m116 137 10 7v15l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m126 144 37-8v15l-37 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"128\" y=\"135\" width=\"27\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m159 137 31 -7 10 6-31 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m159 137 10 7v12l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m169 144 31-8v12l-31 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"171\" y=\"135\" width=\"21\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m202 137 38 -7 10 6-38 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m202 137 10 7v17l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m212 144 38-8v17l-38 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"214\" y=\"135\" width=\"28\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m245 137 32 -7 10 6-32 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m245 137 10 7v14l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m255 144 32-8v14l-32 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"257\" y=\"135\" width=\"22\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m288 137 39 -7 10 6-39 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m288 137 10 7v19l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m298 144 39-8v19l-39 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"300\" y=\"135\" width=\"29\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m12 168 39 -7 10 6-39 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m12 168 10 7v16l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m22 175 39-8v16l-39 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"24\" y=\"166\" width=\"29\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m55 168 33 -7 10 6-33 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m55 168 10 7v13l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m65 175 33-8v13l-33 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"67\" y=\"166\" width=\"23\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m98 168 27 -7 10 6-27 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m98 168 10 7v18l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m108 175 27-8v18l-27 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"110\" y=\"166\" width=\"17\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m141 168 34 -7 10 6-34 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m141 168 10 7v15l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m151 175 34-8v15l-34 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"153\" y=\"166\" width=\"24\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m184 168 28 -7 10 6-28 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m184 168 10 7v12l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m194 175 28-8v12l-28 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"196\" y=\"166\" width=\"18\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m227 168 35 -7 10 6-35 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m227 168 10 7v17l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m237 175 35-8v17l-35 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"239\" y=\"166\" width=\"25\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m270 168 29 -7 10 6-29 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m270 168 10 7v14l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m280 175 29-8v14l-29 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"282\" y=\"166\" width=\"19\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m30 199 29 -7 10 6-29 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m30 199 10 7v19l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m40 206 29-8v19l-29 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"42\" y=\"197\" width=\"19\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m73 199 36 -7 10 6-36 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m73 199 10 7v16l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m83 206 36-8v16l-36 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"85\" y=\"197\" width=\"26\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m116 199 30 -7 10 6-30 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m116 199 10 7v13l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m126 206 30-8v13l-30 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"128\" y=\"197\" width=\"20\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m159 199 37 -7 10 6-37 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m159 199 10 7v18l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m169 206 37-8v18l-37 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"171\" y=\"197\" width=\"27\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m202 199 31 -7 10 6-31 8Z\" fill=\"#dad1b2\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m202 199 10 7v15l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m212 206 31-8v15l-31 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"214\" y=\"197\" width=\"21\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m245 199 38 -7 10 6-38 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m245 199 10 7v12l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m255 206 38-8v12l-38 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"257\" y=\"197\" width=\"28\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"m288 199 32 -7 10 6-32 8Z\" fill=\"#bbb9a1\" stroke=\"#5f6b61\" stroke-width=\"0.7\" /><path d=\"m288 199 10 7v17l-10-5Z\" fill=\"#7c8275\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m298 206 32-8v17l-32 8Z\" fill=\"#929786\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"300\" y=\"197\" width=\"22\" height=\"2\" rx=\"0\" fill=\"#737e72\" stroke=\"none\" /><path d=\"M105 73 155 52l44 10 22 27-12 44-52 18-43-22Z\" fill=\"#d3cbb0\" stroke=\"#65756a\" stroke-width=\"2\" /><path d=\"M121 81 157 65l30 7 18 19-6 31-40 13-30-16Z\" fill=\"#8d9b89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m141 86 23-10 20 6 3 23-22 10-23-9Z\" fill=\"#c5c1a4\" stroke=\"#687c6c\" stroke-width=\"1\" /><path d=\"m143 85 22 10 21-13m-21 13v18\" fill=\"none\" stroke=\"#81917a\" stroke-width=\"1.5\" /><path d=\"M0 0h320v44Q147 7 0 84Z\" fill=\"#e1d7b7\" stroke=\"none\" stroke-width=\"1\" opacity=\".31\"/><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-art-argument\" viewBox=\"0 0 320 260\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"#283940\" stroke=\"none\" /><path d=\"M23 0v145L80 180V0M277 0v145l-57 35V0\" fill=\"#536063\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M29 0V140m233 168V0\" fill=\"none\" stroke=\"#9ca89f\" stroke-width=\"2\" opacity=\".5\"/><path d=\"M41 0V147m245 161V0\" fill=\"none\" stroke=\"#9ca89f\" stroke-width=\"2\" opacity=\".5\"/><path d=\"M53 0V154m257 154V0\" fill=\"none\" stroke=\"#9ca89f\" stroke-width=\"2\" opacity=\".5\"/><path d=\"M65 0V161m269 147V0\" fill=\"none\" stroke=\"#9ca89f\" stroke-width=\"2\" opacity=\".5\"/><path d=\"M77 0V168m281 140V0\" fill=\"none\" stroke=\"#9ca89f\" stroke-width=\"2\" opacity=\".5\"/><path d=\"M139 0h43v120l-22 19-21-19Z\" fill=\"#b2b7a7\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M150 0v115h16V0\" fill=\"#dddac0\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"160\" cy=\"250\" rx=\"182\" ry=\"64\" fill=\"#a7b0a2\" stroke=\"#293e42\" stroke-width=\"3\"/><path d=\"M-22 253v10q182 92 364 0v-10\" fill=\"#3f5358\" stroke=\"#8c9a90\" stroke-width=\"1\" /><ellipse cx=\"160\" cy=\"230\" rx=\"152\" ry=\"53\" fill=\"#7c8a86\" stroke=\"#293e42\" stroke-width=\"3\"/><path d=\"M8 233v10q152 77 304 0v-10\" fill=\"#3f5358\" stroke=\"#8c9a90\" stroke-width=\"1\" /><ellipse cx=\"160\" cy=\"210\" rx=\"122\" ry=\"42\" fill=\"#a7b0a2\" stroke=\"#293e42\" stroke-width=\"3\"/><path d=\"M38 213v10q122 62 244 0v-10\" fill=\"#3f5358\" stroke=\"#8c9a90\" stroke-width=\"1\" /><ellipse cx=\"160\" cy=\"190\" rx=\"92\" ry=\"31\" fill=\"#7c8a86\" stroke=\"#293e42\" stroke-width=\"3\"/><path d=\"M68 193v10q92 47 184 0v-10\" fill=\"#3f5358\" stroke=\"#8c9a90\" stroke-width=\"1\" /><ellipse cx=\"160\" cy=\"170\" rx=\"62\" ry=\"20\" fill=\"#a7b0a2\" stroke=\"#293e42\" stroke-width=\"3\"/><path d=\"M98 173v10q62 32 124 0v-10\" fill=\"#3f5358\" stroke=\"#8c9a90\" stroke-width=\"1\" /><ellipse cx=\"160\" cy=\"170\" rx=\"58\" ry=\"21\" fill=\"#d6d6be\"/><rect x=\"145\" y=\"139\" width=\"30\" height=\"28\" rx=\"0\" fill=\"#a7afa0\" stroke=\"#2e4446\" /><rect x=\"143\" y=\"137\" width=\"34\" height=\"5\" rx=\"0\" fill=\"#e0dcc1\" stroke=\"none\" /><path d=\"m156 116 4-5 4 5 2 21h-13Z\" fill=\"#e1dcc1\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"160\" cy=\"108\" r=\"4\" fill=\"#c2b79b\" stroke=\"none\" /><circle cx=\"18\" cy=\"212\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M15 215h6l3 12h-12Z\" fill=\"#765248\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"40\" cy=\"225\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M37 228h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"62\" cy=\"238\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M59 241h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"84\" cy=\"212\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M81 215h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"106\" cy=\"225\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M103 228h6l3 12h-12Z\" fill=\"#765248\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"128\" cy=\"238\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M125 241h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"150\" cy=\"212\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M147 215h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"172\" cy=\"225\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M169 228h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"194\" cy=\"238\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M191 241h6l3 12h-12Z\" fill=\"#765248\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"216\" cy=\"212\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M213 215h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"238\" cy=\"225\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M235 228h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"260\" cy=\"238\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M257 241h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"282\" cy=\"212\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M279 215h6l3 12h-12Z\" fill=\"#765248\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"304\" cy=\"225\" r=\"2.4\" fill=\"#b4b09a\" stroke=\"none\" /><path d=\"M301 228h6l3 12h-12Z\" fill=\"#263d45\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-art-allies\" viewBox=\"0 0 320 260\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-night)\" stroke=\"none\" /><circle cx=\"19\" cy=\"7\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"90\" cy=\"50\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"161\" cy=\"93\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"232\" cy=\"136\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"303\" cy=\"179\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"54\" cy=\"222\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"125\" cy=\"5\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"196\" cy=\"48\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"267\" cy=\"91\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"18\" cy=\"134\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"89\" cy=\"177\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"160\" cy=\"220\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"231\" cy=\"3\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"302\" cy=\"46\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"53\" cy=\"89\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"124\" cy=\"132\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"195\" cy=\"175\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"266\" cy=\"218\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"17\" cy=\"1\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"88\" cy=\"44\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"159\" cy=\"87\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"230\" cy=\"130\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"301\" cy=\"173\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"52\" cy=\"216\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"123\" cy=\"259\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"194\" cy=\"42\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"265\" cy=\"85\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"16\" cy=\"128\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"87\" cy=\"171\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"158\" cy=\"214\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"229\" cy=\"257\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"300\" cy=\"40\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"51\" cy=\"83\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"122\" cy=\"126\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"193\" cy=\"169\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"264\" cy=\"212\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"15\" cy=\"255\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"86\" cy=\"38\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"157\" cy=\"81\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"228\" cy=\"124\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"299\" cy=\"167\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"50\" cy=\"210\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"121\" cy=\"253\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"192\" cy=\"36\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"263\" cy=\"79\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"14\" cy=\"122\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"85\" cy=\"165\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"156\" cy=\"208\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"227\" cy=\"251\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"298\" cy=\"34\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"49\" cy=\"77\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"120\" cy=\"120\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"191\" cy=\"163\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"262\" cy=\"206\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"13\" cy=\"249\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"84\" cy=\"32\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"155\" cy=\"75\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"226\" cy=\"118\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"297\" cy=\"161\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"48\" cy=\"204\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"119\" cy=\"247\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"190\" cy=\"30\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"54\" cy=\"195\" r=\"112\" fill=\"#365b65\" stroke=\"#83aab0\" /><path d=\"M0 109q67 28 91 2l43 43-18 30-50-8-12 40-54-2Z\" fill=\"#a2b6a8\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M0 130q31 30 82 4m-54 47q44-20 90 18m-95 34q50-15 91 5\" fill=\"none\" stroke=\"#e2e5cf\" stroke-width=\"8\" opacity=\".65\"/><path d=\"M0 109q63-46 125 16\" fill=\"none\" stroke=\"#d4dcd0\" stroke-width=\"3\" /><path d=\"M82 149 140 260H78L61 169Z\" fill=\"#bed7d2\" stroke=\"none\" stroke-width=\"1\" opacity=\".42\"/><g transform=\"translate(49 54) scale(1)\"><path d=\"M14 107C-7 85 24 25 78 9c32-12 59-1 67 28 10 39-45 100-88 104-18 2-32-15-43-34Z\" fill=\"url(#di-r-steel)\" stroke=\"#172d3b\" stroke-width=\"2\" /><path d=\"M26 99C18 66 51 26 91 20c23-3 39 5 41 22 3 30-32 64-64 77-16 6-33-3-42-20Z\" fill=\"#2e4855\" stroke=\"#98a8a8\" stroke-width=\"1.3\" /><path d=\"M44 89C40 72 67 39 94 32c17-4 27 1 29 11 4 18-22 47-49 59-18 7-26-3-30-13Z\" fill=\"#152a3a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m43 90 38-18 27-29-5 32-34 35-23 2Z\" fill=\"#536b76\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m30 114 4 19 18 8 13-7-18-4Z\" fill=\"#a6b1a8\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M80 9C54 29 34 55 20 86M94 14C58 32 40 56 32 77\" fill=\"none\" stroke=\"#d2d6c0\" stroke-width=\"1.1\" /><path d=\"m29 82 11 4\" fill=\"none\" stroke=\"#1b3441\" stroke-width=\"1.5\" /><path d=\"m33 88 11 4\" fill=\"none\" stroke=\"#1b3441\" stroke-width=\"1.5\" /><path d=\"m37 94 11 4\" fill=\"none\" stroke=\"#1b3441\" stroke-width=\"1.5\" /><path d=\"m41 100 11 4\" fill=\"none\" stroke=\"#1b3441\" stroke-width=\"1.5\" /><path d=\"m45 106 11 4\" fill=\"none\" stroke=\"#1b3441\" stroke-width=\"1.5\" /><path d=\"m49 112 11 4\" fill=\"none\" stroke=\"#1b3441\" stroke-width=\"1.5\" /><path d=\"m53 118 11 4\" fill=\"none\" stroke=\"#1b3441\" stroke-width=\"1.5\" /><path d=\"m116 22 13-5 7 6-13 5Z\" fill=\"#263f4d\" stroke=\"#b0bdb2\" stroke-width=\"0.7\" /><circle cx=\"62\" cy=\"124\" r=\"2\" fill=\"#bcd7d5\" stroke=\"none\" /><circle cx=\"69\" cy=\"128\" r=\"1.2\" fill=\"#bcd7d5\" stroke=\"none\" /></g><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-art-ring\" viewBox=\"0 0 320 260\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-wine)\" stroke=\"none\" /><path d=\"M0 0q111 29 153 124T320 240M0 36q110 32 145 128T270 260\" fill=\"none\" stroke=\"#986b4b\" stroke-width=\"27\" opacity=\".12\"/><ellipse cx=\"161\" cy=\"207\" rx=\"105\" ry=\"20\" fill=\"#172024\" opacity=\".6\"/><ellipse cx=\"159\" cy=\"139\" rx=\"88\" ry=\"61\" transform=\"rotate(-24 159 139)\" fill=\"url(#di-r-gold)\" stroke=\"#4d3a2a\" stroke-width=\"2\"/><ellipse cx=\"159\" cy=\"139\" rx=\"57\" ry=\"38\" transform=\"rotate(-24 159 139)\" fill=\"#18292b\" stroke=\"#72512e\" stroke-width=\"5\"/><path d=\"M77 103 91 64l59-20 45 25-9 44-57 20Z\" fill=\"url(#di-r-gold)\" stroke=\"#6b4d2a\" stroke-width=\"2\" /><path d=\"m91 71 54-18 39 21-7 30-48 19-39-22Z\" fill=\"#8f753f\" stroke=\"#e6ce8d\" stroke-width=\"1.5\" /><path d=\"m105 93 20 1 18-22 5 18 22-2-16 14-23 8-8-8Z\" fill=\"#2c4141\" stroke=\"#cdb16d\" stroke-width=\"1\" /><path d=\"M75 128q9 71 91 50t79-70M84 139q24 57 86 30\" fill=\"none\" stroke=\"#f0d695\" stroke-width=\"2.2\" /><path d=\"M197 94q16 7 20 22m-15-6 10 15m-13-8 7 15\" fill=\"none\" stroke=\"#78572e\" stroke-width=\"1.2\" /><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-art-diplomacy\" viewBox=\"0 25 700 568.75\"><use href=\"#di-r-p4-diplomacy\" x=\"0\" y=\"0\" width=\"700\" height=\"620\"/></symbol>\n<symbol id=\"di-r-art-jessica\" viewBox=\"0 25 700 568.75\"><use href=\"#di-r-p4-jessica\" x=\"0\" y=\"0\" width=\"700\" height=\"620\"/></symbol>\n<symbol id=\"di-r-art-duncan\" viewBox=\"0 25 700 568.75\"><use href=\"#di-r-p4-duncan\" x=\"0\" y=\"0\" width=\"700\" height=\"620\"/></symbol>\n<symbol id=\"di-r-art-travel\" viewBox=\"0 0 320 260\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-night)\" stroke=\"none\" /><circle cx=\"19\" cy=\"7\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"90\" cy=\"50\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"161\" cy=\"93\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"232\" cy=\"136\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"303\" cy=\"179\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"54\" cy=\"222\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"125\" cy=\"5\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"196\" cy=\"48\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"267\" cy=\"91\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"18\" cy=\"134\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"89\" cy=\"177\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"160\" cy=\"220\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"231\" cy=\"3\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"302\" cy=\"46\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"53\" cy=\"89\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"124\" cy=\"132\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"195\" cy=\"175\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"266\" cy=\"218\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"17\" cy=\"1\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"88\" cy=\"44\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"159\" cy=\"87\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"230\" cy=\"130\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"301\" cy=\"173\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"52\" cy=\"216\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"123\" cy=\"259\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"194\" cy=\"42\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"265\" cy=\"85\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"16\" cy=\"128\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"87\" cy=\"171\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"158\" cy=\"214\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"229\" cy=\"257\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"300\" cy=\"40\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"51\" cy=\"83\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"122\" cy=\"126\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"193\" cy=\"169\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"264\" cy=\"212\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"15\" cy=\"255\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"86\" cy=\"38\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"157\" cy=\"81\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"228\" cy=\"124\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"299\" cy=\"167\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"50\" cy=\"210\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"121\" cy=\"253\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"192\" cy=\"36\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"263\" cy=\"79\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"14\" cy=\"122\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"85\" cy=\"165\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"156\" cy=\"208\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"227\" cy=\"251\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"298\" cy=\"34\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"49\" cy=\"77\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"120\" cy=\"120\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"191\" cy=\"163\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"262\" cy=\"206\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"13\" cy=\"249\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"84\" cy=\"32\" r=\"1\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"155\" cy=\"75\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><circle cx=\"226\" cy=\"118\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.48000000000000004\"/><circle cx=\"297\" cy=\"161\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.6200000000000001\"/><circle cx=\"48\" cy=\"204\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.76\"/><circle cx=\"119\" cy=\"247\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.2\"/><circle cx=\"190\" cy=\"30\" r=\"0.45\" fill=\"#d7e4df\" stroke=\"none\" opacity=\"0.34\"/><path d=\"M0 193Q149 105 320 169v91H0Z\" fill=\"#9d9c82\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M0 218Q119 159 320 196v64H0Z\" fill=\"#b0a58b\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M102 232q73-20 144-14\" fill=\"none\" stroke=\"#ded2ac\" stroke-width=\"1.2\" /><g transform=\"translate(16 -48) scale(1.52)\"><path d=\"M35 108C8 63 32 21 94 12s113 15 119 56-38 84-98 83-64-19-80-43Z\" fill=\"url(#di-r-steel)\" stroke=\"#152b39\" stroke-width=\"2\" /><path d=\"M58 95c-12-29 7-51 45-55s75 8 81 30-21 44-61 47-55-7-65-22Z\" fill=\"#0b1a28\" stroke=\"#92a5a7\" stroke-width=\"2\" /><path d=\"M62 91c-5-23 13-38 43-41s60 6 67 22-17 32-48 35-53-1-62-16Z\" fill=\"#314c59\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M75 96c-2-16 13-27 34-30s43 2 48 11-14 21-35 22-38 2-47-3Z\" fill=\"#0b1b28\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M35 108q65 46 149-10m-145-40Q92 5 184 42\" fill=\"none\" stroke=\"#d3d5bb\" stroke-width=\"1.4\" /><path d=\"M58 124L64 138\" stroke=\"#283f4d\" stroke-width=\"2\" fill=\"none\" /><path d=\"M73 126L79 140\" stroke=\"#283f4d\" stroke-width=\"2\" fill=\"none\" /><path d=\"M88 128L94 142\" stroke=\"#283f4d\" stroke-width=\"2\" fill=\"none\" /><path d=\"M103 118L109 132\" stroke=\"#283f4d\" stroke-width=\"2\" fill=\"none\" /><path d=\"M118 116L124 130\" stroke=\"#283f4d\" stroke-width=\"2\" fill=\"none\" /><path d=\"M133 114L139 128\" stroke=\"#283f4d\" stroke-width=\"2\" fill=\"none\" /><path d=\"M148 112L154 126\" stroke=\"#283f4d\" stroke-width=\"2\" fill=\"none\" /><path d=\"M163 110L169 124\" stroke=\"#283f4d\" stroke-width=\"2\" fill=\"none\" /></g><path d=\"M180 160 216 205l-10-32Z\" fill=\"#d2e1d5\" stroke=\"none\" stroke-width=\"1\" opacity=\".35\"/><path d=\"m207 208 27-9 29 4-32 9Z\" fill=\"#2a3b43\" stroke=\"#99a8a1\" stroke-width=\"0.7\" /><rect x=\"0\" y=\"0\" width=\"320\" height=\"260\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-art-tech\" viewBox=\"0 0 320 190\"><rect x=\"0\" y=\"0\" width=\"320\" height=\"190\" rx=\"0\" fill=\"url(#di-r-metal)\" stroke=\"none\" /><path d=\"M0 126 150 52l170 54M0 156 150 80l170 57M83 180l122-64M140 190l112-60\" fill=\"none\" stroke=\"#708b8c\" stroke-width=\"0.6\" opacity=\".22\"/><path d=\"m61 132 84-42 109 36-82 45Z\" fill=\"#183342\" stroke=\"#9fb2ac\" stroke-width=\"1\" /><path d=\"m61 132 111 39v12L61 145Zm111 39 82-45v11l-82 46Z\" fill=\"#354c57\" stroke=\"#a4b4ad\" stroke-width=\"0.8\" /><path d=\"m87 121 57-28 77 24-56 30Z\" fill=\"#748d8c\" stroke=\"#b5c4b6\" stroke-width=\"1\" /><path d=\"m111 113 33-15 47 15-31 16Z\" fill=\"#1a4656\" stroke=\"#abc7c1\" stroke-width=\"1\" /><path d=\"m135 99v-47l20-11 26 9v51l-25 12Z\" fill=\"#42616b\" stroke=\"#94c4c3\" stroke-width=\"1\" /><path d=\"m135 52 21 10 25-12m-25 12v51\" fill=\"none\" stroke=\"#abcac4\" stroke-width=\"1\" /><path d=\"m142 61 8 3v30l-8-3Zm18 10 13-6v25l-13 7Z\" fill=\"#8fc4ca\" stroke=\"none\" stroke-width=\"1\" /><ellipse cx=\"157\" cy=\"32\" rx=\"43\" ry=\"13\" fill=\"none\" stroke=\"#85c2cc\" stroke-width=\"1.3\"/><ellipse cx=\"157\" cy=\"28\" rx=\"34\" ry=\"9\" fill=\"#7fa5a7\" opacity=\".1\"/><path d=\"M126 24V6h61v18M121 23h71M137 42l-18-20m56 20 17-20\" fill=\"none\" stroke=\"#add2cd\" stroke-width=\"1.2\" /><path d=\"M76 136L76 146\" stroke=\"#82a8a6\" stroke-width=\"1\" fill=\"none\" /><path d=\"M85 139L85 149\" stroke=\"#82a8a6\" stroke-width=\"1\" fill=\"none\" /><path d=\"M94 142L94 152\" stroke=\"#82a8a6\" stroke-width=\"1\" fill=\"none\" /><path d=\"M103 145L103 155\" stroke=\"#82a8a6\" stroke-width=\"1\" fill=\"none\" /><path d=\"M34 32L94 32\" stroke=\"#a0b9ae\" stroke-width=\"1\" fill=\"none\" /><path d=\"M34 32L34 95\" stroke=\"#a0b9ae\" stroke-width=\"1\" fill=\"none\" /><path d=\"M269 83L289 83\" stroke=\"#a0b9ae\" stroke-width=\"1\" fill=\"none\" /><path d=\"M289 83L289 147\" stroke=\"#a0b9ae\" stroke-width=\"1\" fill=\"none\" /><rect x=\"0\" y=\"0\" width=\"320\" height=\"190\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-city-arrakeen\" viewBox=\"0 0 300 145\"><path d=\"M7 111 40 91 87 97l41-18 39 13 52-6 35 19 39 9-4 21H11Z\" fill=\"#6d7161\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M24 105 49 88h195l32 18-18 30H32Z\" fill=\"#8c9683\" stroke=\"#4b5a54\" stroke-width=\"1\" /><path d=\"M51 87 75 65h143l27 22Z\" fill=\"#c2bda0\" stroke=\"#6c7665\" stroke-width=\"1\" /><rect x=\"72\" y=\"62\" width=\"148\" height=\"46\" rx=\"1\" fill=\"#a4aa92\" stroke=\"#536453\" /><rect x=\"86\" y=\"43\" width=\"121\" height=\"24\" rx=\"1\" fill=\"#c4c3a6\" stroke=\"#74816b\" /><rect x=\"111\" y=\"27\" width=\"71\" height=\"20\" rx=\"1\" fill=\"#d8ceb0\" stroke=\"#8d947b\" /><path d=\"M99 43 116 20h61l18 23Z\" fill=\"#c3c0a0\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M114 25 127 12h35l14 13Z\" fill=\"#ddd2ac\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m47 110 19-38 14 16v42H47Zm178 16V75l13-16 23 48v21Z\" fill=\"#b8b79b\" stroke=\"#6c7b65\" stroke-width=\"1\" /><rect x=\"81\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"91\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><rect x=\"95\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"102\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><rect x=\"109\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"113\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><rect x=\"123\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"124\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><rect x=\"137\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"135\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><rect x=\"151\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"146\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><rect x=\"165\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"157\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><rect x=\"179\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"168\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><rect x=\"193\" y=\"75\" width=\"5\" height=\"28\" rx=\"0\" fill=\"#354e4b\" stroke=\"none\" /><rect x=\"179\" y=\"49\" width=\"4\" height=\"12\" rx=\"0\" fill=\"#657d68\" stroke=\"none\" /><path d=\"M132 108V90h27v18m-50 2-12 19m75-19 13 20\" fill=\"none\" stroke=\"#465e53\" stroke-width=\"3\" /><path d=\"M147 27L147 8\" stroke=\"#6e7561\" stroke-width=\"1\" fill=\"none\" /><path d=\"m147 8 25 2-8 8h-17Z\" fill=\"#657b82\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M14 135h276m-232-8h173m-186-14h221\" fill=\"none\" stroke=\"#e3d4ad\" stroke-width=\"1\" /><path d=\"M74 64h147v5H74Zm12-19h122v4H86Zm25-16h71v4h-71Z\" fill=\"#e4d5b3\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"79\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M78 72L78 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><rect x=\"94\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M93 72L93 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><rect x=\"109\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M108 72L108 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><rect x=\"124\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M123 72L123 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><rect x=\"139\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M138 72L138 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><rect x=\"154\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M153 72L153 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><rect x=\"169\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M168 72L168 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><rect x=\"184\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M183 72L183 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><rect x=\"199\" y=\"96\" width=\"6\" height=\"8\" rx=\"0\" fill=\"#5d7764\" stroke=\"none\" /><path d=\"M198 72L198 107\" stroke=\"#d3c7a2\" stroke-width=\"0.7\" fill=\"none\" /><path d=\"m30 107 18-9 20 9v18H36Zm196 0 18-9 25 8-11 20h-28Z\" fill=\"#b4b89c\" stroke=\"#6a7f67\" stroke-width=\"0.6\" /><path d=\"m34 108 29 0m-21 0v14m7-14v14m7-14v14m177-14h31m-23 1v13m8-13v13m8-13v13\" fill=\"none\" stroke=\"#667e65\" stroke-width=\"1\" /><path d=\"m106 130 13-14h59l18 14m-65-8h54m-59 4h65\" fill=\"none\" stroke=\"#e0d2aa\" stroke-width=\"0.8\" /><rect x=\"0\" y=\"0\" width=\"300\" height=\"145\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-city-carthag\" viewBox=\"0 0 300 145\"><path d=\"M10 133 31 96l60-16 87 5 105 35-1 17Z\" fill=\"#616c62\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M46 131 67 37l33 18v76Zm55 0V19l39 22v90Zm40 0 8-104 31 24 11 80Z\" fill=\"#8b9382\" stroke=\"#465d54\" stroke-width=\"1\" /><path d=\"M68 37 80 45 64 132H46Zm34-18 13 9-6 103h-8Zm46 8 8 7-4 97h-12Z\" fill=\"#c2c0a2\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M182 132V76l38-14 49 30v41Z\" fill=\"#778777\" stroke=\"#425c50\" stroke-width=\"1\" /><path d=\"m183 76 38 4 48 12-49-30Z\" fill=\"#c5bda0\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M72 63l17 8m23-37 20 10m21-25 17 12\" fill=\"none\" stroke=\"#364f4a\" stroke-width=\"1.7\" /><path d=\"M72 73l17 8m23-35 20 10m21-23 17 12\" fill=\"none\" stroke=\"#364f4a\" stroke-width=\"1.7\" /><path d=\"M72 83l17 8m23-33 20 10m21-21 17 12\" fill=\"none\" stroke=\"#364f4a\" stroke-width=\"1.7\" /><path d=\"M72 93l17 8m23-31 20 10m21-19 17 12\" fill=\"none\" stroke=\"#364f4a\" stroke-width=\"1.7\" /><path d=\"M72 103l17 8m23-29 20 10m21-17 17 12\" fill=\"none\" stroke=\"#364f4a\" stroke-width=\"1.7\" /><path d=\"M72 113l17 8m23-27 20 10m21-15 17 12\" fill=\"none\" stroke=\"#364f4a\" stroke-width=\"1.7\" /><rect x=\"192\" y=\"102\" width=\"11\" height=\"30\" rx=\"0\" fill=\"#263d3c\" stroke=\"none\" /><rect x=\"215\" y=\"93\" width=\"15\" height=\"39\" rx=\"0\" fill=\"#344d45\" stroke=\"none\" /><rect x=\"240\" y=\"110\" width=\"8\" height=\"22\" rx=\"0\" fill=\"#263e3e\" stroke=\"none\" /><path d=\"M29 133h260m-227 3 26-5m17 0-6 5\" fill=\"none\" stroke=\"#d5c8a1\" stroke-width=\"1\" /><path d=\"M74 54l15 8M113 39l17 8M157 50l15 10\" fill=\"none\" stroke=\"#36574d\" stroke-width=\"1.1\" /><path d=\"M77 65l15 8M113.5 51l17 8M157.3 61l15 10\" fill=\"none\" stroke=\"#36574d\" stroke-width=\"1.1\" /><path d=\"M80 76l15 8M114 63l17 8M157.6 72l15 10\" fill=\"none\" stroke=\"#36574d\" stroke-width=\"1.1\" /><path d=\"M83 87l15 8M114.5 75l17 8M157.9 83l15 10\" fill=\"none\" stroke=\"#36574d\" stroke-width=\"1.1\" /><path d=\"M86 98l15 8M115 87l17 8M158.2 94l15 10\" fill=\"none\" stroke=\"#36574d\" stroke-width=\"1.1\" /><path d=\"M89 109l15 8M115.5 99l17 8M158.5 105l15 10\" fill=\"none\" stroke=\"#36574d\" stroke-width=\"1.1\" /><path d=\"M186 89h57m-55 7h61M190 104h7m9 0h8m17 0h12m-56 10h9m12 0h9m16 0h8\" fill=\"none\" stroke=\"#485f51\" stroke-width=\"1.2\" /><path d=\"M21 129 36 99l10 1-6 31m225 0 1-20 10 3 6 19\" fill=\"none\" stroke=\"#b3b399\" stroke-width=\"2\" /><rect x=\"204\" y=\"61\" width=\"20\" height=\"5\" rx=\"0\" fill=\"#8e9a83\" stroke=\"none\" /><rect x=\"0\" y=\"0\" width=\"300\" height=\"145\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-city-research\" viewBox=\"0 0 300 145\"><path d=\"M9 136 30 108l64-7 35-18 73 10 79 29 8 17Z\" fill=\"#7a7e6b\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M53 124V88a49 49 0 0 1 98 0v38Z\" fill=\"#c4c3a5\" stroke=\"#6c806e\" stroke-width=\"1.2\" /><path d=\"M67 121V90a35 35 0 0 1 70 0v31Z\" fill=\"#899e8d\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M84 122V94a19 19 0 0 1 38 0v28Z\" fill=\"#334c46\" stroke=\"none\" stroke-width=\"1\" /><rect x=\"133\" y=\"103\" width=\"78\" height=\"24\" rx=\"0\" fill=\"#abb39b\" stroke=\"#617a67\" /><rect x=\"174\" y=\"74\" width=\"62\" height=\"51\" rx=\"0\" fill=\"#c4c2a3\" stroke=\"#687c67\" /><path d=\"m157 62 77-11-30 20Z\" fill=\"#bbc6b6\" stroke=\"#5e796a\" stroke-width=\"1.3\" /><path d=\"m157 62 77-11q-36 47-77 11Z\" fill=\"#9eae9e\" stroke=\"#587666\" stroke-width=\"1\" /><path d=\"M203 70L203 112\" stroke=\"#647e6d\" stroke-width=\"3\" fill=\"none\" /><path d=\"M35 119V43m-9 13h18m-12-19 3-9 4 9m205 87V87h22v37\" fill=\"none\" stroke=\"#6a806a\" stroke-width=\"2\" /><circle cx=\"258\" cy=\"92\" r=\"5\" fill=\"#c7d1b7\" stroke=\"none\" /><rect x=\"186\" y=\"85\" width=\"9\" height=\"12\" rx=\"0\" fill=\"#506f63\" stroke=\"none\" /><rect x=\"212\" y=\"85\" width=\"9\" height=\"12\" rx=\"0\" fill=\"#506f63\" stroke=\"none\" /><rect x=\"18\" y=\"130\" width=\"270\" height=\"5\" rx=\"0\" fill=\"#b0b295\" stroke=\"none\" /><path d=\"M59 91a44 44 0 0 1 88 0m-78 27V90a34 34 0 0 1 68 0m-29-34v11m-28-4 8 8m45-8-8 8\" fill=\"none\" stroke=\"#e0d5b5\" stroke-width=\"0.9\" /><rect x=\"54\" y=\"113\" width=\"25\" height=\"8\" rx=\"0.5\" fill=\"#839c83\" stroke=\"#d2d2b2\" /><rect x=\"134\" y=\"111\" width=\"30\" height=\"9\" rx=\"0.5\" fill=\"#708d79\" stroke=\"#c6cbab\" /><path d=\"M144 115h6m3 0h5m23-36h49m-33 8v10m22-10v10m-36 25h47M243 104v18m8-18v18m8-18v18\" fill=\"none\" stroke=\"#6e8870\" stroke-width=\"0.8\" /><path d=\"M165 60q36 12 63-6m-35 1 9 10m5-13 5 7M35 45l-4 21m9-11-5 21\" fill=\"none\" stroke=\"#d1d5b7\" stroke-width=\"0.8\" /><rect x=\"0\" y=\"0\" width=\"300\" height=\"145\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<symbol id=\"di-r-city-sietch\" viewBox=\"0 0 300 145\"><path d=\"M2 137 31 97 63 88 88 28 119 66 160 15 192 77 219 53 258 111 299 139Z\" fill=\"url(#di-r-rock)\" stroke=\"#686c5c\" stroke-width=\"1\" /><path d=\"m31 97 32-9 25-60 17 77-48 26Zm88-31 41-51-5 97-28 25Zm73 11 27-24-3 73-22-8Z\" fill=\"#b4a68a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m88 28 17 77-13 28-10-35Zm72-13 32 62-22 53-15-18Zm59 38 39 58-42 15Z\" fill=\"#777a68\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M100 136v-24a17 17 0 0 1 34 0v24Zm50 0v-35a12 12 0 0 1 24 0v35Z\" fill=\"#203b3d\" stroke=\"#80957c\" stroke-width=\"1\" /><rect x=\"106\" y=\"121\" width=\"23\" height=\"15\" rx=\"0\" fill=\"#122d33\" stroke=\"none\" /><path d=\"m97 83 34-11m6-12 20-8m36 53 26-7M58 108l24-7m-35 19 41-10m75-32 22-7\" fill=\"none\" stroke=\"#d0bc94\" stroke-width=\"1\" /><path d=\"M37 139h219m-148-5 4-21m17 22-1-21m26 20 5-22\" fill=\"none\" stroke=\"#b5b18d\" stroke-width=\"1\" /><path d=\"m47 115 30-10m-24 4 27-10m-22 2 22-8m32-7 17-11m-9 3 16-10m8-10 8-6m5-7 6-4m32 46 24-7m-22 14 26-7m-19 13 24-6m-14 11 20-4\" fill=\"none\" stroke=\"#d8c39c\" stroke-width=\"0.8\" /><path d=\"M99 135v-22a18 18 0 0 1 36 0v22m-38-3v-21a20 20 0 0 1 40 0m12 20v-32a13 13 0 0 1 26 0\" fill=\"none\" stroke=\"#78947b\" stroke-width=\"1\" /><path d=\"m58 135 21-12 13 10m86 4 20-10 26 10m-63-9 6-23m-36-8 7-15\" fill=\"none\" stroke=\"#596c5a\" stroke-width=\"1.2\" /><rect x=\"0\" y=\"0\" width=\"300\" height=\"145\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>\n<linearGradient id=\"di-r-pv3-room\" gradientUnits=\"userSpaceOnUse\" x1=\"0\" y1=\"0\" x2=\"700\" y2=\"620\"><stop offset=\"0\" stop-color=\"#656f63\" stop-opacity=\"1\"/><stop offset=\"0.4\" stop-color=\"#444e44\" stop-opacity=\"1\"/><stop offset=\"0.72\" stop-color=\"#262f2c\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#8c8971\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-wall\" gradientUnits=\"userSpaceOnUse\" x1=\"80\" y1=\"0\" x2=\"560\" y2=\"470\"><stop offset=\"0\" stop-color=\"#a4ab95\" stop-opacity=\"1\"/><stop offset=\"0.5\" stop-color=\"#677065\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#39443d\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-room-baron\" gradientUnits=\"userSpaceOnUse\" x1=\"0\" y1=\"0\" x2=\"700\" y2=\"620\"><stop offset=\"0\" stop-color=\"#273b35\" stop-opacity=\"1\"/><stop offset=\"0.5\" stop-color=\"#28362e\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#78806b\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-stone\" gradientUnits=\"userSpaceOnUse\" x1=\"0\" y1=\"460\" x2=\"700\" y2=\"610\"><stop offset=\"0\" stop-color=\"#afb39b\" stop-opacity=\"1\"/><stop offset=\"0.45\" stop-color=\"#7e8672\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#b9b79a\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-paul-face\" gradientUnits=\"userSpaceOnUse\" x1=\"302\" y1=\"275\" x2=\"459\" y2=\"320\"><stop offset=\"0\" stop-color=\"#b28b6f\" stop-opacity=\"1\"/><stop offset=\"0.42\" stop-color=\"#c9a489\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#dab79c\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-paul-neck\" gradientUnits=\"userSpaceOnUse\" x1=\"266\" y1=\"430\" x2=\"353\" y2=\"523\"><stop offset=\"0\" stop-color=\"#745b47\" stop-opacity=\"1\"/><stop offset=\"0.35\" stop-color=\"#9f795b\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#bf9777\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-hair\" gradientUnits=\"userSpaceOnUse\" x1=\"238\" y1=\"143\" x2=\"432\" y2=\"365\"><stop offset=\"0\" stop-color=\"#141c1b\" stop-opacity=\"1\"/><stop offset=\"0.32\" stop-color=\"#282822\" stop-opacity=\"1\"/><stop offset=\"0.55\" stop-color=\"#3b3026\" stop-opacity=\"1\"/><stop offset=\"0.77\" stop-color=\"#201f1b\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#111c1b\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-hair-wave\" gradientUnits=\"userSpaceOnUse\" x1=\"252\" y1=\"120\" x2=\"427\" y2=\"270\"><stop offset=\"0\" stop-color=\"#242721\" stop-opacity=\"1\"/><stop offset=\"0.4\" stop-color=\"#483829\" stop-opacity=\"1\"/><stop offset=\"0.57\" stop-color=\"#5c4430\" stop-opacity=\"1\"/><stop offset=\"0.75\" stop-color=\"#302920\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#171f1c\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-hair-left\" gradientUnits=\"userSpaceOnUse\" x1=\"212\" y1=\"214\" x2=\"311\" y2=\"351\"><stop offset=\"0\" stop-color=\"#1a2420\" stop-opacity=\"1\"/><stop offset=\"0.5\" stop-color=\"#30332a\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#0f1918\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-uniform\" gradientUnits=\"userSpaceOnUse\" x1=\"105\" y1=\"511\" x2=\"536\" y2=\"620\"><stop offset=\"0\" stop-color=\"#1d2928\" stop-opacity=\"1\"/><stop offset=\"0.3\" stop-color=\"#172121\" stop-opacity=\"1\"/><stop offset=\"0.56\" stop-color=\"#10191b\" stop-opacity=\"1\"/><stop offset=\"0.85\" stop-color=\"#171c1c\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#242623\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-uniform-edge\" gradientUnits=\"userSpaceOnUse\" x1=\"244\" y1=\"482\" x2=\"406\" y2=\"574\"><stop offset=\"0\" stop-color=\"#202e2c\" stop-opacity=\"1\"/><stop offset=\"0.45\" stop-color=\"#152221\" stop-opacity=\"1\"/><stop offset=\"0.8\" stop-color=\"#111a1a\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#2b302c\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-metal\" gradientUnits=\"userSpaceOnUse\" x1=\"280\" y1=\"510\" x2=\"314\" y2=\"536\"><stop offset=\"0\" stop-color=\"#aeb8a6\" stop-opacity=\"1\"/><stop offset=\"0.45\" stop-color=\"#dadbc1\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#758b7f\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-baron-head\" gradientUnits=\"userSpaceOnUse\" x1=\"294\" y1=\"215\" x2=\"518\" y2=\"300\"><stop offset=\"0\" stop-color=\"#958789\" stop-opacity=\"1\"/><stop offset=\"0.38\" stop-color=\"#b5a3a0\" stop-opacity=\"1\"/><stop offset=\"0.72\" stop-color=\"#c7b5ac\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#b4a39f\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-baron-neck\" gradientUnits=\"userSpaceOnUse\" x1=\"305\" y1=\"351\" x2=\"475\" y2=\"538\"><stop offset=\"0\" stop-color=\"#766e70\" stop-opacity=\"1\"/><stop offset=\"0.4\" stop-color=\"#a2938e\" stop-opacity=\"1\"/><stop offset=\"0.76\" stop-color=\"#b7a59a\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#8a817a\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-robe\" gradientUnits=\"userSpaceOnUse\" x1=\"75\" y1=\"421\" x2=\"563\" y2=\"620\"><stop offset=\"0\" stop-color=\"#1a292c\" stop-opacity=\"1\"/><stop offset=\"0.27\" stop-color=\"#202b2f\" stop-opacity=\"1\"/><stop offset=\"0.55\" stop-color=\"#101b20\" stop-opacity=\"1\"/><stop offset=\"0.82\" stop-color=\"#1a2529\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#0f1b1e\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-shoulder\" gradientUnits=\"userSpaceOnUse\" x1=\"68\" y1=\"457\" x2=\"261\" y2=\"606\"><stop offset=\"0\" stop-color=\"#324046\" stop-opacity=\"1\"/><stop offset=\"0.28\" stop-color=\"#3c454a\" stop-opacity=\"1\"/><stop offset=\"0.6\" stop-color=\"#263439\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#17272c\" stop-opacity=\"1\"/></linearGradient><linearGradient id=\"di-r-pv3-fold\" gradientUnits=\"userSpaceOnUse\" x1=\"209\" y1=\"353\" x2=\"424\" y2=\"620\"><stop offset=\"0\" stop-color=\"#344146\" stop-opacity=\"1\"/><stop offset=\"0.3\" stop-color=\"#17262b\" stop-opacity=\"1\"/><stop offset=\"0.63\" stop-color=\"#111d22\" stop-opacity=\"1\"/><stop offset=\"0.82\" stop-color=\"#29353a\" stop-opacity=\"1\"/><stop offset=\"1\" stop-color=\"#19272c\" stop-opacity=\"1\"/></linearGradient><clipPath id=\"di-r-pv3-frame\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"white\" /></clipPath><pattern id=\"di-r-pv3-weave\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 .5h5M.5 0v5\" fill=\"none\" stroke=\"#bac3ae\" stroke-width=\"0.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".055\"/><path d=\"M0 3h5\" fill=\"none\" stroke=\"#050e15\" stroke-width=\"0.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".25\"/></pattern><symbol id=\"di-r-pv3-paul\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-pv3-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"url(#di-r-pv3-room)\" /><path d=\"M0 0h174L240 426 75 449 0 215Z\" fill=\"url(#di-r-pv3-wall)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M173 0h105L351 420l-111 6Z\" fill=\"#7f8875\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".45\"/><path d=\"M512 0h188v489L511 433Z\" fill=\"#998365\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".38\"/><path d=\"M579 0h121v76L578 303Z\" fill=\"#b39465\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".22\"/><path d=\"M0 456Q329 424 700 464v40Q331 468 0 498Z\" fill=\"url(#di-r-pv3-stone)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 504Q329 473 700 511v35Q331 511 0 541Z\" fill=\"#35443c\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 546Q329 515 700 555v65H0Z\" fill=\"url(#di-r-pv3-stone)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M0 461Q329 429 700 469M0 552Q329 521 700 561\" fill=\"none\" stroke=\"#d1cdb0\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".4\"/><path d=\"M62 620Q73 578 103 558C143 534 197 524 246 492L274 468 348 475 408 489C441 512 489 529 529 548Q551 571 559 620Z\" fill=\"url(#di-r-pv3-uniform)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M62 620Q73 578 103 558C143 534 197 524 246 492L274 468 348 475 408 489C441 512 489 529 529 548Q551 571 559 620Z\" fill=\"url(#di-r-pv3-weave)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M264 398C267 437 258 458 245 490C259 510 288 531 317 548L363 503C346 477 356 443 371 416Z\" fill=\"url(#di-r-pv3-paul-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M294 410C311 438 332 449 354 444L348 468Q317 477 285 451Z\" fill=\"#6a5847\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".28\"/><path d=\"M333 193C366 168 408 173 438 199C459 218 469 247 466 274C463 307 458 342 441 372C425 405 410 432 388 447C367 456 337 439 317 420C292 400 282 371 276 340C257 338 249 322 253 306C257 294 266 294 273 299C275 252 300 211 333 193Z\" fill=\"url(#di-r-pv3-paul-face)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M254 435Q232 422 231 402C215 400 208 386 214 370Q196 359 202 338C186 319 193 302 199 287Q185 271 198 253C191 235 202 218 217 208Q206 188 229 170C232 151 249 147 263 143C271 126 292 123 303 124C327 107 350 113 366 117C388 109 403 125 415 130C437 126 455 142 458 158C480 161 486 182 484 196C500 210 495 229 491 240C500 259 492 278 480 293Q493 314 478 333L467 326C478 304 466 284 461 264C451 240 449 217 437 202C416 195 401 193 382 202C361 216 349 236 332 245L313 280C292 312 285 349 282 377Q285 414 254 435Z\" fill=\"url(#di-r-pv3-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M230 371C200 365 207 333 219 316C196 302 207 275 228 264C216 243 236 220 260 218C255 239 239 251 245 271C252 291 233 311 233 330Q226 347 230 371Z\" fill=\"url(#di-r-pv3-hair-left)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M222 258C204 238 221 207 246 197C231 179 250 158 273 158Q314 119 352 133C310 139 290 163 269 186C250 211 231 224 222 258Z\" fill=\"url(#di-r-pv3-hair-wave)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M259 212C273 197 282 176 306 160C339 139 363 138 392 146C372 147 359 155 349 169C323 166 304 175 295 192Q281 210 259 212Z\" fill=\"#1a201c\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M280 225C304 217 312 188 341 179C371 169 399 165 413 182C393 179 389 193 378 203C363 221 349 230 330 233C338 215 352 209 358 194C328 186 318 213 302 223Q292 230 280 225Z\" fill=\"url(#di-r-pv3-hair-wave)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M273 295C268 263 296 245 319 241C346 240 364 224 370 205C375 236 351 252 333 263C317 274 307 283 304 304C299 319 287 326 278 330Q290 311 284 299Z\" fill=\"#1a211c\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M258 356C239 331 257 303 276 290C286 272 283 254 294 241C297 271 285 287 276 308C268 332 281 344 272 363Q266 374 255 380Q264 367 258 356Z\" fill=\"url(#di-r-pv3-hair-left)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M235 376Q249 389 256 371C265 401 241 400 247 415L262 421 249 429C226 419 237 404 230 398Z\" fill=\"#111c1a\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M378 128C406 117 434 145 436 166Q442 179 436 193C428 167 408 146 378 128Z\" fill=\"url(#di-r-pv3-hair-wave)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M430 143C458 144 469 168 461 181Q483 195 479 216C470 205 468 196 455 192C458 170 445 156 430 143Z\" fill=\"#3d3024\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M454 204C476 201 484 221 478 238C467 258 484 277 477 297C482 276 456 257 462 241Q471 218 454 204Z\" fill=\"url(#di-r-pv3-hair-wave)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M475 301Q497 331 478 349Q471 355 459 348C480 352 478 333 470 325Z\" fill=\"#47392b\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M326 120C340 111 356 117 368 124Q391 117 401 136C372 121 352 128 326 120Z\" fill=\"#3f3427\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M211 294Q205 312 219 325L214 345Q196 329 204 310Z\" fill=\"#26332b\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M221 251C211 233 236 213 253 204\" fill=\"none\" stroke=\"#b0a080\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.36\"/><path d=\"M235 212C226 187 258 166 278 160\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M248 196C266 177 280 154 308 142\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M267 180Q314 130 355 138\" fill=\"none\" stroke=\"#90704d\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M282 178Q327 137 362 147\" fill=\"none\" stroke=\"#b0a080\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.36\"/><path d=\"M309 163Q353 142 384 154\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M289 218C307 212 314 192 338 186Q363 178 382 181\" fill=\"none\" stroke=\"#90704d\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M306 214C321 203 333 188 353 188\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M331 229Q360 219 366 203\" fill=\"none\" stroke=\"#b0a080\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.36\"/><path d=\"M274 284C269 267 286 250 297 243\" fill=\"none\" stroke=\"#90704d\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M280 317Q276 294 290 274\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M230 275C224 291 214 305 228 320\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M222 337Q215 355 230 364\" fill=\"none\" stroke=\"#b0a080\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.36\"/><path d=\"M250 329Q243 346 255 357\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M386 135Q421 143 427 169\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M397 143Q419 153 423 174\" fill=\"none\" stroke=\"#90704d\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M441 158Q456 168 453 182\" fill=\"none\" stroke=\"#b0a080\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.36\"/><path d=\"M461 209Q479 217 471 234\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M468 249Q469 262 476 277\" fill=\"none\" stroke=\"#90704d\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M472 316Q486 337 475 343\" fill=\"none\" stroke=\"#72634a\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><path d=\"M307 132Q333 117 353 125\" fill=\"none\" stroke=\"#b0a080\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.36\"/><path d=\"M238 385Q235 400 246 405\" fill=\"none\" stroke=\"#90704d\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\"0.28\"/><g transform=\"translate(-2 3)\"><path d=\"M221 251C211 233 236 213 253 204\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M235 212C226 187 258 166 278 160\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(-2 3)\"><path d=\"M248 196C266 177 280 154 308 142\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M267 180Q314 130 355 138\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(-2 3)\"><path d=\"M282 178Q327 137 362 147\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M309 163Q353 142 384 154\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(-2 3)\"><path d=\"M289 218C307 212 314 192 338 186Q363 178 382 181\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M306 214C321 203 333 188 353 188\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(-2 3)\"><path d=\"M331 229Q360 219 366 203\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M274 284C269 267 286 250 297 243\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(-2 3)\"><path d=\"M280 317Q276 294 290 274\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M230 275C224 291 214 305 228 320\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(-2 3)\"><path d=\"M222 337Q215 355 230 364\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M250 329Q243 346 255 357\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(-2 3)\"><path d=\"M386 135Q421 143 427 169\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M397 143Q419 153 423 174\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(-2 3)\"><path d=\"M441 158Q456 168 453 182\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><g transform=\"translate(2 3)\"><path d=\"M461 209Q479 217 471 234\" fill=\"none\" stroke=\"#77674d\" stroke-width=\"0.55\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".23\"/></g><path d=\"M246 484 261 470C267 488 290 509 317 520L319 548 295 566C275 545 251 526 237 511Z\" fill=\"url(#di-r-pv3-uniform-edge)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M355 476 369 489 379 524 336 553 319 548 330 518Z\" fill=\"url(#di-r-pv3-uniform-edge)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M260 474Q275 501 316 521L318 546M356 480 330 521 319 546\" fill=\"none\" stroke=\"#99a68e\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".58\"/><path d=\"M318 547 342 620\" fill=\"none\" stroke=\"#071416\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M323 550 347 620\" fill=\"none\" stroke=\"#536359\" stroke-width=\"0.85\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".65\"/><path d=\"M105 559Q161 543 219 518C204 554 195 582 199 620H62Z\" fill=\"#23302e\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".55\"/><path d=\"M124 558Q155 551 180 542L162 620H91Z\" fill=\"#39443a\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".16\"/><path d=\"M222 520C205 556 195 588 200 620M112 565Q101 588 97 620\" fill=\"none\" stroke=\"#4e6055\" stroke-width=\"1.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".6\"/><path d=\"M226 523C211 555 202 587 207 620\" fill=\"none\" stroke=\"#080f14\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".7\"/><path d=\"M405 507 434 535Q463 553 477 581L492 620\" fill=\"none\" stroke=\"#4c5548\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".45\"/><path d=\"M414 516Q430 549 432 572L455 620M242 555Q267 568 285 590\" fill=\"none\" stroke=\"#071416\" stroke-width=\"6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".6\"/><path d=\"M246 560Q269 576 277 592M446 565Q461 578 466 592\" fill=\"none\" stroke=\"#5c6656\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".4\"/><path d=\"M488 553Q523 559 540 593L548 620\" fill=\"none\" stroke=\"#5c6556\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".3\"/><path d=\"M279 512 295 521 287 521 281 518 283 525 293 530 295 535 298 532 309 529 308 525 300 526 293 518 282 510Z\" fill=\"url(#di-r-pv3-metal)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M283 517 292 523M294 526 300 531\" fill=\"none\" stroke=\"#71887b\" stroke-width=\"0.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M312 528 314 531 312 534 309 533 309 530Z\" fill=\"#b9c3ad\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g></symbol><symbol id=\"di-r-pv3-baron\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-pv3-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"url(#di-r-pv3-room-baron)\" /><path d=\"M0 0h147L82 620H0Z\" fill=\"#344940\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".42\"/><path d=\"M551 0h149v620H472Z\" fill=\"#707a66\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".18\"/><path d=\"M16 620Q237 415 700 433v187Z\" fill=\"#a6aa8a\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".12\"/><path d=\"M-10 596Q260 364 710 402M-10 611Q260 379 710 417\" fill=\"none\" stroke=\"#abb291\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".16\"/><path d=\"M-22 620V553C21 484 70 438 129 411C171 384 191 345 236 335Q266 331 300 347L409 420 511 466C562 476 591 508 604 549L626 620Z\" fill=\"url(#di-r-pv3-robe)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-22 620V553C21 484 70 438 129 411C171 384 191 345 236 335Q266 331 300 347L409 420 511 466C562 476 591 508 604 549L626 620Z\" fill=\"url(#di-r-pv3-weave)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M218 361C257 331 281 321 302 304L444 380 500 456 493 536C443 539 392 501 341 461Z\" fill=\"url(#di-r-pv3-baron-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M298 346Q339 425 445 473L480 514Q388 483 332 435Z\" fill=\"#625d61\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".3\"/><path d=\"M272 233C263 185 278 131 311 99C346 66 398 58 442 73C491 89 511 128 516 168C521 204 522 222 532 250C545 283 549 315 543 350C544 387 538 425 517 451C499 474 474 484 449 482C407 480 370 461 341 429C310 396 292 358 285 324C265 322 255 307 252 285C249 266 258 251 271 257Z\" fill=\"url(#di-r-pv3-baron-head)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-16 620 17 529Q56 473 116 444C161 424 184 377 229 357Q246 350 258 356C302 390 317 444 359 486Q405 529 487 556L523 620Z\" fill=\"url(#di-r-pv3-fold)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M-4 620Q27 558 74 524C119 492 177 481 212 496C239 529 259 572 264 620Z\" fill=\"url(#di-r-pv3-shoulder)\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M33 574C74 514 133 489 187 498Q158 479 121 491C77 506 44 539 33 574Z\" fill=\"#485052\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".42\"/><path d=\"M90 489C127 466 158 449 177 421C193 400 211 377 236 373Q211 389 208 409C201 438 217 471 232 491C202 463 194 428 198 414C177 445 157 465 125 477Z\" fill=\"#101f24\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M121 457C166 433 184 393 224 374\" fill=\"none\" stroke=\"#738074\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".33\"/><path d=\"M215 377C253 386 268 433 294 474Q326 528 400 565L429 620\" fill=\"none\" stroke=\"#43514f\" stroke-width=\"3.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".55\"/><path d=\"M235 389C262 409 271 447 295 484Q329 532 401 572\" fill=\"none\" stroke=\"#0b171c\" stroke-width=\"9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".7\"/><path d=\"M246 393C270 415 281 460 308 493Q345 536 414 572\" fill=\"none\" stroke=\"#708072\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".4\"/><path d=\"M266 407C286 433 297 467 321 496Q370 546 459 568\" fill=\"none\" stroke=\"#33423f\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".6\"/><path d=\"M280 414C305 452 308 468 337 494Q380 534 469 559\" fill=\"none\" stroke=\"#07171c\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".8\"/><path d=\"M303 449C348 505 411 541 483 557\" fill=\"none\" stroke=\"#788172\" stroke-width=\"0.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".45\"/><path d=\"M351 483Q410 535 493 549\" fill=\"none\" stroke=\"#0a171c\" stroke-width=\"5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".75\"/><path d=\"M511 466C538 478 562 496 576 524L600 620H507C510 579 503 559 484 541Q513 531 511 466Z\" fill=\"#152329\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M523 480C542 510 532 541 548 579L565 620\" fill=\"none\" stroke=\"#48554f\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".6\"/><path d=\"M533 490Q558 522 551 552M563 541 585 620\" fill=\"none\" stroke=\"#788071\" stroke-width=\"0.85\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".4\"/><path d=\"M103 555Q139 546 165 565L202 620H183Q148 575 103 555Z\" fill=\"#101f26\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M128 540Q183 539 216 582L234 620H222Q191 564 128 540Z\" fill=\"#17282e\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M85 582Q118 585 140 620H123Q105 598 85 582Z\" fill=\"#4c5451\" stroke=\"none\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".5\"/><path d=\"M166 527Q204 538 218 563\" fill=\"none\" stroke=\"#647064\" stroke-width=\"1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".38\"/><path d=\"M62 561Q42 591 36 620M272 551Q289 588 289 620M319 547Q345 588 343 620\" fill=\"none\" stroke=\"#0b1920\" stroke-width=\"6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".6\"/><path d=\"M277 554Q294 586 296 620M326 554Q350 591 351 620\" fill=\"none\" stroke=\"#657262\" stroke-width=\"1.1\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".3\"/></g></symbol><linearGradient id=\"di-r-p4-skin\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#a5826a\"/><stop offset=\"0.5\" stop-color=\"#c6a38b\"/><stop offset=\"1\" stop-color=\"#d8bba3\"/></linearGradient><linearGradient id=\"di-r-p4-neck\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#715b4d\"/><stop offset=\"0.5\" stop-color=\"#ad8469\"/><stop offset=\"1\" stop-color=\"#be9e7e\"/></linearGradient><linearGradient id=\"di-r-p4-darkskin\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#715342\"/><stop offset=\"0.5\" stop-color=\"#976c50\"/><stop offset=\"1\" stop-color=\"#b18c69\"/></linearGradient><linearGradient id=\"di-r-p4-hair\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#15221e\"/><stop offset=\"0.5\" stop-color=\"#3b382b\"/><stop offset=\"1\" stop-color=\"#202923\"/></linearGradient><linearGradient id=\"di-r-p4-silverhair\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#48524b\"/><stop offset=\"0.5\" stop-color=\"#b8bca5\"/><stop offset=\"1\" stop-color=\"#758473\"/></linearGradient><linearGradient id=\"di-r-p4-goldhair\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#403a26\"/><stop offset=\"0.5\" stop-color=\"#948559\"/><stop offset=\"1\" stop-color=\"#645a39\"/></linearGradient><linearGradient id=\"di-r-p4-redhair\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#34251f\"/><stop offset=\"0.5\" stop-color=\"#7b422c\"/><stop offset=\"1\" stop-color=\"#432c21\"/></linearGradient><linearGradient id=\"di-r-p4-black\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#303c3c\"/><stop offset=\"0.5\" stop-color=\"#19262a\"/><stop offset=\"1\" stop-color=\"#0d1a20\"/></linearGradient><linearGradient id=\"di-r-p4-green\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#52654b\"/><stop offset=\"0.5\" stop-color=\"#263f31\"/><stop offset=\"1\" stop-color=\"#152a28\"/></linearGradient><linearGradient id=\"di-r-p4-red\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#8c4033\"/><stop offset=\"0.5\" stop-color=\"#5c2628\"/><stop offset=\"1\" stop-color=\"#281b22\"/></linearGradient><linearGradient id=\"di-r-p4-violet\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#8a83a1\"/><stop offset=\"0.5\" stop-color=\"#544563\"/><stop offset=\"1\" stop-color=\"#292d41\"/></linearGradient><linearGradient id=\"di-r-p4-blue\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#7cb0c0\"/><stop offset=\"0.5\" stop-color=\"#44758c\"/><stop offset=\"1\" stop-color=\"#243e5b\"/></linearGradient><linearGradient id=\"di-r-p4-pale\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#e2d8c1\"/><stop offset=\"0.5\" stop-color=\"#9ba8a0\"/><stop offset=\"1\" stop-color=\"#687981\"/></linearGradient><linearGradient id=\"di-r-p4-gold\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#a59053\"/><stop offset=\"0.5\" stop-color=\"#e3cd8b\"/><stop offset=\"1\" stop-color=\"#9e7944\"/></linearGradient><linearGradient id=\"di-r-p4-silver\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#d0d8c3\"/><stop offset=\"0.5\" stop-color=\"#6f918d\"/><stop offset=\"1\" stop-color=\"#c0c8b5\"/></linearGradient><linearGradient id=\"di-r-p4-wine\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".65\"><stop offset=\"0\" stop-color=\"#69434c\"/><stop offset=\"0.5\" stop-color=\"#3e2d3c\"/><stop offset=\"1\" stop-color=\"#242434\"/></linearGradient><clipPath id=\"di-r-p4-frame\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"white\" /></clipPath><symbol id=\"di-r-p4-leto\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#45524b\" /><path d=\"M0 0h120l30 620H0ZM540 0h160v620H550Z\" fill=\"#273a36\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M147 0h29v620h-29ZM500 0h20v620h-20Z\" fill=\"#9b9e83\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 461Q350 413 700 472v32Q350 466 0 506Z\" fill=\"#b6b49b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 520Q350 477 700 533v87H0Z\" fill=\"#71806c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M47 620Q53 548 75 507C113 483 171 470 238 444L278 421h126l53 39Q527 477 562 492C578 531 590 576 593 620Z\" fill=\"url(#di-r-p4-green)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M280 357 279 426 335 480 402 434 392 351Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M269 168C304 139 364 133 404 160C431 183 443 222 439 257L446 292Q445 345 417 379L374 410Q340 417 307 392C283 372 270 339 262 310C241 309 235 290 237 274Q239 258 256 264L252 215Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M254 284Q223 268 235 242C216 226 227 203 237 196C224 173 246 155 263 153Q276 126 303 131C331 112 356 121 376 125Q414 122 434 156L446 187 428 208Q417 173 383 173C348 165 328 169 304 188L277 232 269 275Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M269 313Q285 325 296 338C318 332 337 315 361 319C386 310 404 326 422 338L437 321C445 362 433 403 404 423Q377 448 342 440C305 432 284 410 276 376Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M251 203Q282 159 325 152\" fill=\"none\" stroke=\"#7c8068\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M260 195Q309 148 360 151\" fill=\"none\" stroke=\"#7c8068\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M321 141Q384 131 416 163\" fill=\"none\" stroke=\"#7c8068\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M248 249Q245 217 278 190\" fill=\"none\" stroke=\"#7c8068\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M307 365Q311 407 344 428\" fill=\"none\" stroke=\"#7c8068\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M326 372 353 435\" fill=\"none\" stroke=\"#7c8068\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M373 357Q395 386 380 431\" fill=\"none\" stroke=\"#7c8068\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M405 363Q428 395 404 418\" fill=\"none\" stroke=\"#7c8068\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M239 443 273 420Q291 461 334 477L338 515 294 543 235 479Z\" fill=\"url(#di-r-p4-green)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M402 421 425 446 438 481 372 543 338 515 347 474Z\" fill=\"url(#di-r-p4-green)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M271 425Q288 465 334 482L337 514\" fill=\"none\" stroke=\"#9caa8a\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M402 427 348 479 338 513\" fill=\"none\" stroke=\"#9caa8a\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M97 510Q161 481 220 474\" fill=\"none\" stroke=\"#9caa8a\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M102 515 78 620\" fill=\"none\" stroke=\"#9caa8a\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M535 506 560 620\" fill=\"none\" stroke=\"#9caa8a\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M340 516 355 620\" fill=\"none\" stroke=\"#9caa8a\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M289 480 308 492 297 492 306 502 317 504 305 510 291 500 288 490Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M390 477 373 492 384 489 374 502 362 506 374 508 389 497Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M79 508Q128 486 179 477C140 510 121 565 124 620H54Z\" fill=\"#637456\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".22\"/><path d=\"M481 484Q518 494 542 517C538 555 551 588 565 620H532Q500 556 481 484Z\" fill=\"#0e2624\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".5\"/><path d=\"M95 517Q109 539 100 571\" fill=\"none\" stroke=\"#7c8e70\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M91 548Q79 581 83 620\" fill=\"none\" stroke=\"#7c8e70\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M191 483Q204 529 192 556\" fill=\"none\" stroke=\"#7c8e70\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M201 513 211 565\" fill=\"none\" stroke=\"#7c8e70\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M290 559Q316 574 334 596\" fill=\"none\" stroke=\"#7c8e70\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M466 524Q484 557 482 587\" fill=\"none\" stroke=\"#7c8e70\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/></g></symbol><symbol id=\"di-r-p4-rabban\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#482b2c\" /><path d=\"M0 0h123l139 620H0Z\" fill=\"#2d2427\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M360 0h112l228 620H568Z\" fill=\"#8c5542\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".45\"/><path d=\"M0 477 700 378v32L0 524Z\" fill=\"#b68d70\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".55\"/><path d=\"M12 620Q15 544 43 491C78 470 114 451 150 443L240 404h174l101 48Q589 469 627 507C648 542 662 583 669 620Z\" fill=\"url(#di-r-p4-black)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M248 338 232 421Q301 469 402 435L415 339Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M231 215C229 134 269 90 329 92C393 85 435 142 435 216L436 264C456 249 471 264 464 288Q462 313 439 321C430 363 415 401 387 419C348 441 311 431 278 402Q245 371 237 322C214 317 205 298 208 276Q210 257 230 267Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M219 405 241 383C235 421 255 452 307 466L315 518 216 541 186 447Z\" fill=\"#2e3230\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M421 384 446 414 485 473 367 532 315 518 320 468Q396 462 421 384Z\" fill=\"url(#di-r-p4-black)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M239 396Q239 445 310 476L314 516\" fill=\"none\" stroke=\"#9e9f85\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M426 396Q407 463 322 479\" fill=\"none\" stroke=\"#9e9f85\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M211 450 225 523 312 529 477 476\" fill=\"none\" stroke=\"#9e9f85\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M468 455Q519 463 549 505L533 525Q496 484 460 479Z\" fill=\"#3e4541\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M495 473Q545 483 573 531L557 549Q520 504 486 498Z\" fill=\"#263234\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M522 491Q571 503 597 557L581 573Q544 524 512 517Z\" fill=\"#3e4541\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M70 505 110 478 158 620H89Z\" fill=\"#4b4640\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M76 507 111 619\" fill=\"none\" stroke=\"#a18c6c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M143 469 175 620\" fill=\"none\" stroke=\"#a18c6c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M483 539 523 620\" fill=\"none\" stroke=\"#a18c6c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M314 533 310 620\" fill=\"none\" stroke=\"#a18c6c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M526 560 561 536 578 581 566 620H548Z\" fill=\"url(#di-r-p4-pale)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M189 526Q218 560 205 620H175Q183 564 174 546Z\" fill=\"#0b181c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M347 550Q405 531 438 518L414 552Q383 556 347 567Z\" fill=\"#55605a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".27\"/><path d=\"M218 552Q246 572 247 602\" fill=\"none\" stroke=\"#66756d\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M366 576 424 554\" fill=\"none\" stroke=\"#66756d\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M367 585 432 570\" fill=\"none\" stroke=\"#66756d\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M451 574 474 609\" fill=\"none\" stroke=\"#66756d\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/></g></symbol><symbol id=\"di-r-p4-ilban\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#292e3e\" /><path d=\"M0 80 700 15v405L0 507Z\" fill=\"#703c43\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 158 131 302 194 223 320 354 374 246 578 382 700 246v180L0 520Z\" fill=\"#94534e\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M36 0h53l226 620h-58ZM700 0h-38L489 620h43Z\" fill=\"#1a242f\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M10 40 261 620\" fill=\"none\" stroke=\"#a6ada0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M683 0 492 620\" fill=\"none\" stroke=\"#a6ada0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M144 620Q157 541 185 480C202 463 224 451 245 444L309 426 402 433 467 468Q511 483 536 502C557 533 570 584 577 620Z\" fill=\"url(#di-r-p4-pale)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M283 358 278 437 333 481 396 442 391 353Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M274 171Q320 137 371 155C414 167 429 205 425 249L419 300Q409 354 378 385C356 409 334 414 308 397L274 366Q255 337 255 299C238 290 238 266 253 259L259 203Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M253 269Q239 254 242 232C233 205 244 183 250 170Q241 149 263 137C273 110 299 114 315 119Q340 100 364 119C394 112 416 133 421 150Q442 170 433 199L422 255 408 275 395 210 376 177Q323 158 280 187L262 245Z\" fill=\"url(#di-r-p4-silverhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M257 183Q283 139 318 136\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M262 185Q296 145 330 143\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M276 170Q304 136 350 134\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M301 146Q351 117 388 146\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M324 147Q378 129 409 159\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M351 155Q393 143 416 177\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M373 166Q406 160 421 190\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M395 184Q415 184 423 208\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M401 194 414 242\" fill=\"none\" stroke=\"#d7d6bd\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M268 417 287 420 331 466 393 423 412 445 420 474 347 512 294 498 265 461Z\" fill=\"url(#di-r-p4-green)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M275 436 286 431 329 477 343 478 399 444 404 457 346 495 326 492Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M269 472Q319 541 416 482\" fill=\"none\" stroke=\"#d8c88d\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M273 484Q324 555 421 495\" fill=\"none\" stroke=\"#d8c88d\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M255 465 270 469 260 518 238 530 232 513Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M436 457 482 477 467 516 437 537 419 507Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M443 477 464 484 452 494 435 499\" fill=\"none\" stroke=\"#2b463a\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M438 486 452 493\" fill=\"none\" stroke=\"#2b463a\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M432 495 446 502\" fill=\"none\" stroke=\"#2b463a\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M196 487 166 620\" fill=\"none\" stroke=\"#e1dfc6\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M491 495 550 620\" fill=\"none\" stroke=\"#e1dfc6\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M283 532 267 620\" fill=\"none\" stroke=\"#e1dfc6\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M440 539 473 620\" fill=\"none\" stroke=\"#e1dfc6\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M259 554h7v14h-7Zm-4 24h7v14h-7Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M274 554h7v14h-7Zm-4 24h7v14h-7Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M289 554h7v14h-7Zm-4 24h7v14h-7Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M304 554h7v14h-7Zm-4 24h7v14h-7Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M193 493Q223 504 231 548L212 620H158Q169 546 193 493Z\" fill=\"#ced2bc\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".45\"/><path d=\"M480 493Q511 513 516 547L549 620H507C514 570 494 527 480 493Z\" fill=\"#506972\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".35\"/><path d=\"M204 507Q191 549 195 593\" fill=\"none\" stroke=\"#eef0d9\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M217 533Q204 580 212 620\" fill=\"none\" stroke=\"#eef0d9\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M477 526 494 572\" fill=\"none\" stroke=\"#eef0d9\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M324 548 318 620\" fill=\"none\" stroke=\"#eef0d9\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M345 552 350 615\" fill=\"none\" stroke=\"#eef0d9\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/></g></symbol><symbol id=\"di-r-p4-helena\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#303a35\" /><ellipse cx=\"330\" cy=\"-50\" rx=\"400\" ry=\"540\" fill=\"#a7a890\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"340\" cy=\"-80\" rx=\"327\" ry=\"485\" fill=\"#d3caab\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"354\" cy=\"-106\" rx=\"250\" ry=\"440\" fill=\"#b7b39a\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M0 620V140l82 24 72 456Zm700 0V93l-91 55-62 472Z\" fill=\"#485148\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M173 620Q167 538 180 482C194 464 215 454 232 452L303 454Q348 459 382 478C414 501 439 529 453 551L486 620Z\" fill=\"url(#di-r-p4-green)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M271 395Q271 443 251 464L318 537 365 504 365 393Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M242 354C207 352 201 317 216 298Q201 268 215 239C205 214 221 190 243 181C247 155 279 145 302 151Q345 128 380 150C413 144 439 167 441 191Q463 210 453 241C472 265 459 294 445 308Q452 344 419 360L400 395 260 403Z\" fill=\"#152721\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><g transform=\"rotate(12 330 280)\"><path d=\"M266 190C301 169 351 173 378 200Q408 228 403 268L398 318C389 355 373 379 345 392Q317 405 290 383C262 362 248 335 246 306C227 299 224 277 240 267L246 220Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><path d=\"M240 275C224 257 226 229 250 213C255 189 292 172 320 181Q348 157 376 178C340 168 320 205 296 210C266 213 266 246 240 275Z\" fill=\"#172720\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M222 271Q215 241 243 219\" fill=\"none\" stroke=\"#75918a\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M241 213Q263 174 301 176\" fill=\"none\" stroke=\"#75918a\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M269 191Q293 161 329 166\" fill=\"none\" stroke=\"#75918a\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M323 165Q365 145 393 171\" fill=\"none\" stroke=\"#75918a\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M411 180Q451 201 440 227\" fill=\"none\" stroke=\"#75918a\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M434 245Q457 266 441 290\" fill=\"none\" stroke=\"#75918a\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M224 316Q218 339 245 343\" fill=\"none\" stroke=\"#75918a\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M185 485 219 465Q265 475 306 516L321 569 278 620H173Z\" fill=\"#243d36\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M201 481Q245 489 277 518\" fill=\"none\" stroke=\"#718579\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M211 490 239 517 224 549 263 568 251 607\" fill=\"none\" stroke=\"#718579\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M227 490 258 520 245 551 280 575\" fill=\"none\" stroke=\"#718579\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M247 320 256 323 246 345 255 354 238 368 245 379 229 406 227 371Z\" fill=\"url(#di-r-p4-silver)\" stroke=\"#46565b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M396 363 403 368 396 387 402 395 381 431 380 405Z\" fill=\"url(#di-r-p4-silver)\" stroke=\"#46565b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M403 620 398 557C393 526 412 502 431 480L465 444Q475 433 482 441L456 486 495 450Q506 442 511 451L475 500 517 471Q528 465 532 475L492 519 518 504Q531 499 535 509L510 544 483 566 458 620Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M426 550 451 519 475 499\" fill=\"none\" stroke=\"#98755e\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M437 564 468 543 493 519\" fill=\"none\" stroke=\"#98755e\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M202 508Q222 529 215 558L227 620H180Q180 552 202 508Z\" fill=\"#172f2b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M203 506Q233 519 242 543\" fill=\"none\" stroke=\"#87a38c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M237 559 252 585 242 620\" fill=\"none\" stroke=\"#87a38c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M278 545Q303 565 305 603\" fill=\"none\" stroke=\"#87a38c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M311 563Q324 591 320 620\" fill=\"none\" stroke=\"#87a38c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/></g></symbol><symbol id=\"di-r-p4-tessia\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#45524b\" /><path d=\"M0 0h120l30 620H0ZM540 0h160v620H550Z\" fill=\"#273a36\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M147 0h29v620h-29ZM500 0h20v620h-20Z\" fill=\"#9b9e83\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 461Q350 413 700 472v32Q350 466 0 506Z\" fill=\"#b6b49b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 520Q350 477 700 533v87H0Z\" fill=\"#71806c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M509 0 299 620h-96L409 0ZM700 95 381 620h-76L636 0Z\" fill=\"#655b77\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M451 0 231 620\" fill=\"none\" stroke=\"#b5a068\" stroke-width=\"9\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M489 0 277 620\" fill=\"none\" stroke=\"#b5a068\" stroke-width=\"9\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M700 128 377 620\" fill=\"none\" stroke=\"#b5a068\" stroke-width=\"9\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M219 620Q221 511 244 441L291 408 359 405 440 448C477 464 511 482 525 500Q555 551 561 620Z\" fill=\"url(#di-r-p4-blue)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M255 401V220Q250 109 331 98C414 80 473 157 463 243L482 457 423 488Z\" fill=\"#23394a\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M310 334 310 420 363 468 411 415 402 320Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M298 193C331 171 374 168 405 186Q435 212 430 258L420 305Q408 345 385 362C365 378 342 377 322 362Q293 337 288 304L280 252Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M284 278 284 197C290 160 321 141 359 149Q395 150 416 179C394 167 388 186 372 196L344 186 332 218 319 203 305 234 293 221Z\" fill=\"url(#di-r-p4-goldhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M302 193 316 174 320 199\" fill=\"none\" stroke=\"#c3b68a\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M321 185 332 165 333 199\" fill=\"none\" stroke=\"#c3b68a\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M341 180 352 158 349 186\" fill=\"none\" stroke=\"#c3b68a\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M364 179 379 163 373 189\" fill=\"none\" stroke=\"#c3b68a\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M251 464C236 411 231 311 241 238C244 145 284 91 347 89C425 83 470 140 475 228L481 410 504 486 444 461C427 401 423 322 416 251L398 202Q374 169 326 173C280 176 269 207 273 251L279 354C279 396 284 418 306 448Z\" fill=\"url(#di-r-p4-blue)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M263 447Q248 387 254 275C250 161 289 103 351 104\" fill=\"none\" stroke=\"#c1d9cd\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.75\"/><path d=\"M414 126Q456 161 462 245L466 397\" fill=\"none\" stroke=\"#c1d9cd\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.75\"/><path d=\"M273 251Q259 341 279 403\" fill=\"none\" stroke=\"#c1d9cd\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.75\"/><path d=\"M228 620 243 468Q294 458 330 473C371 488 414 444 453 447Q504 446 527 484L552 620Z\" fill=\"url(#di-r-p4-blue)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M249 469Q304 516 351 503C397 490 421 467 459 465Q420 516 383 532C317 562 278 532 244 508Z\" fill=\"#7bafbb\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M244 534Q315 578 390 545C427 528 466 484 501 485Q454 562 391 594L315 620H227Z\" fill=\"#507f96\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M247 474Q294 515 348 506C403 496 422 468 460 465\" fill=\"none\" stroke=\"#bed3c6\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M243 536Q317 584 391 548C431 528 463 491 498 487\" fill=\"none\" stroke=\"#bed3c6\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M340 615Q422 582 455 529\" fill=\"none\" stroke=\"#bed3c6\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M490 506Q532 533 530 588L547 620H492C498 584 481 555 478 542Z\" fill=\"#233e59\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".5\"/><path d=\"M499 520Q523 548 518 581\" fill=\"none\" stroke=\"#a4ccd0\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M463 555Q478 576 478 613\" fill=\"none\" stroke=\"#a4ccd0\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M279 576Q297 584 324 582\" fill=\"none\" stroke=\"#a4ccd0\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/></g></symbol><symbol id=\"di-r-p4-rhombur\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#292e3e\" /><path d=\"M0 80 700 15v405L0 507Z\" fill=\"#703c43\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 158 131 302 194 223 320 354 374 246 578 382 700 246v180L0 520Z\" fill=\"#94534e\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M36 0h53l226 620h-58ZM700 0h-38L489 620h43Z\" fill=\"#1a242f\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M10 40 261 620\" fill=\"none\" stroke=\"#a6ada0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M683 0 492 620\" fill=\"none\" stroke=\"#a6ada0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M90 620Q91 551 111 510C141 492 176 482 203 475L259 443 360 437 446 467Q508 488 538 524C558 552 573 587 587 620Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M264 352 263 449 316 495 377 447 375 342Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M250 170Q283 135 337 143C383 148 414 182 416 225L413 280Q403 338 374 374C350 403 323 416 297 402L262 372Q235 343 230 310C212 304 209 282 224 270L230 218Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M230 284Q208 257 215 230C203 202 220 182 230 174Q229 140 263 131C293 111 343 113 370 127C403 135 426 165 426 198L418 252 400 270 385 230C350 228 321 202 295 170Q275 195 256 217L240 274Z\" fill=\"url(#di-r-p4-goldhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M239 180Q255 139 301 136\" fill=\"none\" stroke=\"#c1bc8e\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M280 152Q331 142 388 177\" fill=\"none\" stroke=\"#c1bc8e\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M294 155Q332 176 390 193\" fill=\"none\" stroke=\"#c1bc8e\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M302 170Q340 199 394 210\" fill=\"none\" stroke=\"#c1bc8e\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M314 185Q345 212 388 217\" fill=\"none\" stroke=\"#c1bc8e\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M246 204 234 249\" fill=\"none\" stroke=\"#c1bc8e\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M253 428 274 448 312 485 299 537 239 512 204 478Z\" fill=\"url(#di-r-p4-pale)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M370 427 398 443 409 477 350 535 316 509 325 475Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M398 444Q458 459 490 495Q458 544 418 559L394 620H320Q321 565 355 524Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M111 512Q158 490 201 480L234 508 215 545Q153 553 108 575Z\" fill=\"#787092\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M399 451Q431 468 444 488L356 549 339 620\" fill=\"none\" stroke=\"#c4bac7\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M419 475Q436 505 388 532\" fill=\"none\" stroke=\"#c4bac7\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M118 520 158 552\" fill=\"none\" stroke=\"#c4bac7\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M171 506 194 541\" fill=\"none\" stroke=\"#c4bac7\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M258 448 308 489 297 532\" fill=\"none\" stroke=\"#c4bac7\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M366 483 388 476v8l-22 7Zm-5 18 22-7v8l-22 7Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M302 535 333 520 341 620h-66Z\" fill=\"url(#di-r-p4-pale)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M132 533Q151 570 141 620H96Q104 562 132 533Z\" fill=\"#a6a0b3\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".25\"/><path d=\"M459 522Q497 528 517 560L550 620H515Q484 575 459 554Z\" fill=\"#2b2d43\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".6\"/><path d=\"M150 532Q172 553 168 587\" fill=\"none\" stroke=\"#c3b4c0\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M170 544 179 607\" fill=\"none\" stroke=\"#c3b4c0\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M473 541Q502 555 508 580\" fill=\"none\" stroke=\"#c3b4c0\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M373 577Q386 586 406 583\" fill=\"none\" stroke=\"#c3b4c0\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/></g></symbol><symbol id=\"di-r-p4-ariana\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#879c98\" /><path d=\"M0 116 124 211 173 360 222 620H0ZM700 245 624 290 556 408 501 620h199Z\" fill=\"#4f6a64\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M37 170 141 590M89 233 188 620M675 297 554 620M632 347 568 565\" fill=\"none\" stroke=\"#bcc4b0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M128 620Q132 555 158 520C182 501 210 482 231 474L285 455 368 453 446 486Q490 505 507 535C521 558 527 587 530 620Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M252 437Q249 394 246 311C223 284 226 243 233 218C228 173 250 137 288 127C321 112 364 124 390 143C423 167 428 202 420 247L426 322 399 392 365 465 324 531 233 526Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M287 362 279 456 331 513 382 466 379 357Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M292 178C322 152 364 159 393 185Q422 214 420 253L421 292Q410 341 384 369C363 390 341 394 321 384Q286 366 270 338L263 289 266 232Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M251 322C227 283 243 226 259 196C277 159 304 142 340 147C311 187 301 226 279 253Q263 283 276 321L297 365 275 393 251 372Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M357 145C390 143 422 175 422 212L417 253C403 227 396 202 381 186Z\" fill=\"#1c2c25\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M274 357C259 387 270 415 294 437C320 460 330 487 321 510C303 552 313 586 334 620H268C246 591 247 551 256 519C272 493 250 469 239 450C216 415 235 381 274 357Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M254 278Q256 206 298 165\" fill=\"none\" stroke=\"#89917b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M262 284Q264 219 311 159\" fill=\"none\" stroke=\"#89917b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M250 383C233 426 286 439 292 480\" fill=\"none\" stroke=\"#89917b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M268 391C254 427 303 454 304 482\" fill=\"none\" stroke=\"#89917b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M281 489Q262 549 291 592\" fill=\"none\" stroke=\"#89917b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M245 300C264 217 283 166 334 143\" fill=\"none\" stroke=\"#d1b65e\" stroke-width=\"3.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.95\"/><path d=\"M246 302 255 348 270 369\" fill=\"none\" stroke=\"#d1b65e\" stroke-width=\"3.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.95\"/><path d=\"M161 537 248 486 265 521 223 620H122Z\" fill=\"#243b43\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M393 478 461 517 522 620H431L366 525Z\" fill=\"#253d48\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M161 548 250 504 257 519\" fill=\"none\" stroke=\"#c5a24d\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M405 490 391 521 465 576 489 620\" fill=\"none\" stroke=\"#c5a24d\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M414 512 472 548\" fill=\"none\" stroke=\"#c5a24d\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M234 530 215 620\" fill=\"none\" stroke=\"#c5a24d\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M304 473Q329 497 358 490L377 520\" fill=\"none\" stroke=\"#322d25\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M350 504 384 513 386 549 370 576 357 551 347 523Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M355 520 374 519 375 548 366 557Z\" fill=\"#e5a83b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M356 620 348 581 334 556Q329 545 337 540L354 554 358 537Q360 528 368 534L374 557 383 545Q389 540 393 546L390 571 407 620Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g></symbol><symbol id=\"di-r-p4-memnon\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#303a35\" /><ellipse cx=\"330\" cy=\"-50\" rx=\"400\" ry=\"540\" fill=\"#a7a890\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"340\" cy=\"-80\" rx=\"327\" ry=\"485\" fill=\"#d3caab\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"354\" cy=\"-106\" rx=\"250\" ry=\"440\" fill=\"#b7b39a\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M0 620V140l82 24 72 456Zm700 0V93l-91 55-62 472Z\" fill=\"#485148\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M92 620Q98 553 126 508C149 485 181 461 207 450L256 422 387 421 466 468Q500 491 520 526C535 557 544 591 548 620Z\" fill=\"url(#di-r-p4-wine)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M215 516V227C210 141 247 103 298 97C349 88 404 117 419 166L448 539 399 610 259 620Z\" fill=\"url(#di-r-p4-silverhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M269 338 263 427 322 483 380 435 378 339Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M260 170Q311 138 363 157C401 174 411 211 405 255L399 298C396 345 374 385 347 402Q317 420 286 395C256 369 242 337 239 303C220 296 219 273 236 263L240 209Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M253 303C223 258 226 197 251 158C267 124 307 110 343 123C381 126 406 156 412 184C376 164 355 150 327 153L277 171 261 215 266 387 285 484 278 620H242C220 499 219 404 226 337Z\" fill=\"url(#di-r-p4-silverhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M377 162C409 178 420 218 419 265L427 430 450 620H408L387 470 390 361 389 227Z\" fill=\"url(#di-r-p4-silverhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M271 322 293 341 319 341 344 330 379 318 389 350 375 388 352 418 324 427 299 414 277 386Z\" fill=\"url(#di-r-p4-silverhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M250 187Q270 128 318 128\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M267 170Q291 131 338 137\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M289 153Q333 127 365 152\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M239 223C229 352 232 515 264 613\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M247 234C241 385 250 521 272 612\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M392 217C412 336 390 449 432 614\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M402 261C419 391 400 509 438 617\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M292 355Q287 389 318 414\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M310 365 327 419\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M337 363 338 416\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M366 350Q379 382 352 412\" fill=\"none\" stroke=\"#e1ddbe\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M250 428 268 431 321 477 375 438 391 441 384 487 329 530 266 491Z\" fill=\"url(#di-r-p4-pale)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M207 452 222 418 240 426 237 518 275 620H215L180 487Z\" fill=\"#3b3540\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M410 429 433 449 442 497 405 620H361L388 501Z\" fill=\"#3b3540\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M215 451 203 487 239 620\" fill=\"none\" stroke=\"#99958b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M423 451 429 485 390 620\" fill=\"none\" stroke=\"#99958b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M269 439 322 486 378 450\" fill=\"none\" stroke=\"#99958b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M137 510Q169 537 160 582L166 620H100Q110 544 137 510Z\" fill=\"#5b5059\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".45\"/><path d=\"M455 482Q482 518 479 548L507 620H481Q452 558 447 517Z\" fill=\"#1f2230\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".6\"/><path d=\"M147 523Q132 562 138 599\" fill=\"none\" stroke=\"#a79c97\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.4\"/><path d=\"M166 544Q155 577 165 613\" fill=\"none\" stroke=\"#a79c97\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.4\"/><path d=\"M443 521Q456 555 452 577\" fill=\"none\" stroke=\"#a79c97\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.4\"/><path d=\"M316 558 320 620\" fill=\"none\" stroke=\"#a79c97\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.4\"/></g></symbol><symbol id=\"di-r-p4-armand\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#45524b\" /><path d=\"M0 0h120l30 620H0ZM540 0h160v620H550Z\" fill=\"#273a36\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M147 0h29v620h-29ZM500 0h20v620h-20Z\" fill=\"#9b9e83\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 461Q350 413 700 472v32Q350 466 0 506Z\" fill=\"#b6b49b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 520Q350 477 700 533v87H0Z\" fill=\"#71806c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M184 620V243Q184 203 226 203h272q32 0 32 40v377Z\" fill=\"#2a3e4c\" stroke=\"#a39060\" stroke-width=\"9\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M153 620V443h51v177M532 620V389h42v231\" fill=\"#796b45\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M168 620Q165 544 180 489C200 470 231 452 257 445L313 426 420 432 480 463Q540 476 569 507C586 539 593 582 595 620Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M365 155C420 148 449 192 445 243L453 384 413 445 369 374Z\" fill=\"url(#di-r-p4-silverhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M277 348 277 427 332 478 406 428 400 335Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M271 167C307 137 359 139 395 161Q429 186 427 227L417 293C414 339 396 377 369 393Q342 409 309 389L281 369Q257 339 255 306C236 302 229 281 243 266L249 211Z\" fill=\"url(#di-r-p4-darkskin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M249 264C223 214 239 164 271 143C302 116 353 116 392 137Q432 159 438 205L422 245 407 221 395 177Q334 148 277 184L261 241Z\" fill=\"url(#di-r-p4-silverhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M271 314 293 337 318 339 344 330 374 319 409 308Q408 359 380 389L354 408 322 404 289 385Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M255 186Q292 139 349 144\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M267 177Q312 139 373 155\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M286 167Q340 143 391 169\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M328 153Q389 155 417 188\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M421 237 430 365\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M430 253 438 373\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M295 353 315 391\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M321 354 337 400\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M373 343 365 393\" fill=\"none\" stroke=\"#ced0ad\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M265 406Q243 403 250 423Q225 427 246 447Q225 463 256 474Q244 494 274 499Q268 520 300 518L337 544 374 505Q404 510 400 485Q429 479 410 458Q437 443 413 425Q417 406 397 404L378 447 336 492 298 458Z\" fill=\"url(#di-r-p4-pale)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M266 412q-13 5 1 18t0 22 12 21 10 24 22 14\" fill=\"none\" stroke=\"#ddd9bc\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.95\"/><path d=\"M395 412q19 6 5 22t1 22-13 22-10 24-26 20\" fill=\"none\" stroke=\"#ddd9bc\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.95\"/><path d=\"M251 449 234 451 199 488 210 542 284 582 303 620H354L326 533 276 483Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M411 441 441 449 493 478 557 510 552 552 446 510 373 551 356 620h-24l-4-76Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M202 496 269 471\" fill=\"none\" stroke=\"#b3a9af\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M441 460 542 511 554 551\" fill=\"none\" stroke=\"#b3a9af\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M339 547 348 620\" fill=\"none\" stroke=\"#b3a9af\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M370 562 441 518 523 545\" fill=\"none\" stroke=\"#b3a9af\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><ellipse cx=\"358\" cy=\"564\" rx=\"5\" ry=\"5\" fill=\"#b9c3ac\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M494 490Q552 493 567 539L574 620H533Q547 570 494 490Z\" fill=\"#b3a5b0\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".23\"/><path d=\"M215 534Q239 565 232 620H186Q184 571 202 548Z\" fill=\"#292738\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".7\"/><path d=\"M507 514Q543 541 541 568\" fill=\"none\" stroke=\"#c3b7bd\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M531 553 532 605\" fill=\"none\" stroke=\"#c3b7bd\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M226 557 238 584\" fill=\"none\" stroke=\"#c3b7bd\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/><path d=\"M426 565Q462 553 498 570\" fill=\"none\" stroke=\"#c3b7bd\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.5\"/></g></symbol><symbol id=\"di-r-p4-ilesa\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#243f3d\" /><path d=\"M-20 128Q160 280 670 79L730 146Q280 317-20 218Z\" fill=\"#4f6556\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M4 577Q162 366 358 404T713 294v326H0Z\" fill=\"#172f30\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M34 0Q98 65 97 174\" fill=\"none\" stroke=\"#71908a\" stroke-width=\"8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M202 0Q160 117 260 210\" fill=\"none\" stroke=\"#71908a\" stroke-width=\"8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M502 0Q477 102 417 161\" fill=\"none\" stroke=\"#71908a\" stroke-width=\"8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><g transform=\"translate(30 20) rotate(-22)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#75968b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(78 43) rotate(28)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(126 66) rotate(-22)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(174 20) rotate(28)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#75968b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(222 43) rotate(-22)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(270 66) rotate(28)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(318 20) rotate(-22)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#75968b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(366 43) rotate(28)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(414 66) rotate(-22)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(462 20) rotate(28)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#75968b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(510 43) rotate(-22)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(558 66) rotate(28)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(606 20) rotate(-22)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#75968b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"translate(654 43) rotate(28)\"><path d=\"M0 0Q-30 34 0 63Q32 29 0 0Z\" fill=\"#427b81\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 5v51\" fill=\"none\" stroke=\"#a3b29d\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><path d=\"M259 620Q253 530 272 466L328 430 418 425 496 463Q535 473 555 491C584 525 596 575 601 620Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M377 197C367 157 403 127 437 138C481 131 507 169 498 213L503 316 468 385 438 460 393 457Z\" fill=\"#32281f\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M369 336 363 425 402 464 465 427 454 331Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M356 189Q386 156 425 167C468 177 484 206 480 242L473 294Q457 333 435 355C413 373 391 373 371 356Q344 335 333 304L329 260 336 219Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M344 235C321 209 334 170 361 154C384 133 430 135 451 149C477 152 497 181 492 209L479 252 465 256 456 214Q433 183 390 182L354 193Z\" fill=\"#3d3025\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M351 178Q394 144 438 162\" fill=\"none\" stroke=\"#9d7951\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M377 157Q434 143 474 186\" fill=\"none\" stroke=\"#9d7951\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M440 172Q468 184 478 210\" fill=\"none\" stroke=\"#9d7951\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M470 280C488 324 463 365 469 403C487 448 457 478 462 512C476 547 443 577 441 620H409C410 577 440 547 432 517C424 482 449 452 438 422C430 386 455 356 451 321Z\" fill=\"#35291f\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M449 361q27 16 3 33q-24-16-3-33Z\" fill=\"#735039\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M457 393q27 16 3 33q-24-16-3-33Z\" fill=\"#5a4230\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M449 425q27 16 3 33q-24-16-3-33Z\" fill=\"#735039\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M457 457q27 16 3 33q-24-16-3-33Z\" fill=\"#5a4230\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M449 489q27 16 3 33q-24-16-3-33Z\" fill=\"#735039\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M457 521q27 16 3 33q-24-16-3-33Z\" fill=\"#5a4230\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M449 553q27 16 3 33q-24-16-3-33Z\" fill=\"#735039\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M295 475C265 486 235 478 208 452L177 365 145 285 114 250 98 223Q97 212 105 214L128 232 111 198Q108 188 116 187L141 219 134 188Q136 178 144 185L161 217 167 196Q171 187 177 195L181 227 207 248Q224 265 213 287L240 343 273 422 307 442Z\" fill=\"url(#di-r-p4-darkskin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M126 234 164 252 186 254\" fill=\"none\" stroke=\"#c5a277\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.75\"/><path d=\"M159 264 187 277\" fill=\"none\" stroke=\"#c5a277\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.75\"/><path d=\"M177 324 209 313\" fill=\"none\" stroke=\"#c5a277\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.75\"/><path d=\"M165 310Q187 327 211 311\" fill=\"none\" stroke=\"#d2b86d\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M171 324Q191 340 216 325\" fill=\"none\" stroke=\"#d2b86d\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M269 444Q320 451 352 440Q401 465 459 447C503 450 557 475 571 514L600 620H257Z\" fill=\"url(#di-r-p4-violet)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M274 454Q328 507 401 492Q451 480 509 474L556 493Q440 506 400 525C335 544 292 514 267 484Z\" fill=\"#a1a6bf\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M279 462Q327 511 402 495L498 479\" fill=\"none\" stroke=\"#d2cfcd\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M272 494Q331 546 411 520Q489 493 552 499\" fill=\"none\" stroke=\"#d2cfcd\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M333 572Q405 587 469 550\" fill=\"none\" stroke=\"#d2cfcd\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M494 515Q552 563 565 620\" fill=\"none\" stroke=\"#d2cfcd\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M372 424 387 450M457 421 441 448\" fill=\"none\" stroke=\"#d3c187\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M536 522Q565 544 571 574L590 620H555Q554 566 523 549Z\" fill=\"#3b3b5b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".5\"/><path d=\"M294 547Q338 577 383 568\" fill=\"none\" stroke=\"#d8d3d2\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M357 583Q397 592 422 580\" fill=\"none\" stroke=\"#d8d3d2\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M502 537Q528 564 529 593\" fill=\"none\" stroke=\"#d8d3d2\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/></g></symbol><symbol id=\"di-r-p4-yuna\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#afb9ae\" /><path d=\"M0 620V222L105 152l43 468ZM163 620 196 51 286 0l13 620ZM485 620V194L590 115 700 228v392Z\" fill=\"#667b75\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M216 82 248 65 259 620h-49ZM582 181l32-18v457h-32Z\" fill=\"#9aa99b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M48 252v364M70 233v383M93 215v401M527 230v390M552 208v412\" fill=\"none\" stroke=\"#263f40\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M124 620Q124 547 155 502C180 481 209 468 236 460L286 435 382 430 440 457Q490 478 512 510C533 546 542 584 545 620Z\" fill=\"url(#di-r-p4-red)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M229 414Q206 395 221 366C199 337 216 316 216 291C194 269 211 239 219 219C206 193 227 167 243 159Q246 135 279 134C300 111 325 121 340 124Q378 112 398 142C434 147 447 172 438 201Q457 229 444 252C461 273 453 300 437 318Q450 348 430 370C446 396 426 419 413 442L388 491 267 492Z\" fill=\"url(#di-r-p4-redhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M276 354 275 443 320 498 391 452 386 350Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M268 190C300 162 346 162 376 185Q407 211 404 253L400 296Q387 341 366 367C346 387 322 394 299 377Q272 358 257 326L250 285 251 233Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M244 299C222 268 232 218 251 187Q277 141 323 147C353 141 387 160 402 186L407 222C389 210 374 182 352 179C320 165 298 187 285 204L267 263 262 304Z\" fill=\"url(#di-r-p4-redhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M397 221C422 247 409 288 419 316C431 345 403 367 418 393C430 426 398 449 406 472C414 500 390 529 373 548C381 520 365 507 376 482C391 449 368 434 382 407C402 373 375 360 389 328Q405 296 393 266Z\" fill=\"url(#di-r-p4-redhair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M240 264Q235 201 286 167\" fill=\"none\" stroke=\"#b98255\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M252 237Q257 182 300 160\" fill=\"none\" stroke=\"#b98255\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M301 153Q354 134 392 174\" fill=\"none\" stroke=\"#b98255\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M402 245Q425 277 409 307\" fill=\"none\" stroke=\"#b98255\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M401 328Q421 359 402 382\" fill=\"none\" stroke=\"#b98255\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M397 401Q414 428 392 453\" fill=\"none\" stroke=\"#b98255\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M388 477Q398 501 381 521\" fill=\"none\" stroke=\"#b98255\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M221 450 225 405 279 404 280 487 311 520 277 540 205 489Z\" fill=\"url(#di-r-p4-red)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M388 406 427 411 446 482 374 540 311 520 349 492Z\" fill=\"url(#di-r-p4-red)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M232 415h35v69L307 520\" fill=\"none\" stroke=\"#bd7254\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M398 419 418 425 433 481 375 530\" fill=\"none\" stroke=\"#bd7254\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M167 509Q201 510 220 531L215 620\" fill=\"none\" stroke=\"#bd7254\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M454 499Q491 529 503 620\" fill=\"none\" stroke=\"#bd7254\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><ellipse cx=\"223\" cy=\"554\" rx=\"21\" ry=\"21\" fill=\"url(#di-r-p4-silver)\" stroke=\"#344b48\" stroke-width=\"2\"/><ellipse cx=\"223\" cy=\"554\" rx=\"14\" ry=\"14\" fill=\"none\" stroke=\"#cbd0b8\" stroke-width=\"1.3\"/><path d=\"M211 554q12-23 25 0-14 22-25 0Zm6 0q5-9 10 0-5 9-10 0Z\" fill=\"none\" stroke=\"#4a6563\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"466\" cy=\"571\" rx=\"15\" ry=\"15\" fill=\"url(#di-r-p4-silver)\" stroke=\"#344b48\" stroke-width=\"2\"/><path d=\"M173 523Q198 551 189 587L191 620h-54Q143 554 173 523Z\" fill=\"#b56346\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".28\"/><path d=\"M473 522Q497 552 495 580L522 620H495Q473 566 460 554Z\" fill=\"#251e28\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\".5\"/><path d=\"M174 536Q166 568 172 600\" fill=\"none\" stroke=\"#c48360\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M250 568 286 585\" fill=\"none\" stroke=\"#c48360\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M362 576Q397 588 418 582\" fill=\"none\" stroke=\"#c48360\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M486 543 492 569\" fill=\"none\" stroke=\"#c48360\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/></g></symbol><symbol id=\"di-r-p4-hundro\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#afb9ae\" /><path d=\"M0 620V222L105 152l43 468ZM163 620 196 51 286 0l13 620ZM485 620V194L590 115 700 228v392Z\" fill=\"#667b75\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M216 82 248 65 259 620h-49ZM582 181l32-18v457h-32Z\" fill=\"#9aa99b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M48 252v364M70 233v383M93 215v401M527 230v390M552 208v412\" fill=\"none\" stroke=\"#263f40\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M86 620 111 532 192 497 506 498 594 559 618 620Z\" fill=\"url(#di-r-p4-red)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><g transform=\"rotate(-9 340 330)\"><path d=\"M67 620 91 479 203 445 256 418 385 423 449 445 579 478 624 620Z\" fill=\"url(#di-r-p4-red)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M262 339 261 429 322 475 393 424 389 339Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M253 174C284 144 335 140 374 159Q416 185 420 228L418 279C413 324 394 364 365 391Q341 409 314 403C282 394 253 364 243 328L236 298C218 288 219 266 233 257L235 216Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M233 294Q207 280 213 257C196 244 205 223 215 211C204 193 219 178 230 167Q224 147 251 140C268 112 292 119 308 125Q335 108 355 123C384 119 407 139 412 156Q442 168 435 190L447 218 421 256 403 247 393 203 366 176 347 180 324 166 301 183 282 175 264 209 246 229Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M233 281 216 311 227 322 210 338 233 342 222 361 246 357 239 377 266 375 282 400 265 410 237 393 210 398 216 380 189 380 204 358 189 351 209 330 196 317Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M236 189Q266 137 306 142\" fill=\"none\" stroke=\"#9b7a50\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M270 156Q304 125 340 139\" fill=\"none\" stroke=\"#9b7a50\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M309 139Q358 127 392 157\" fill=\"none\" stroke=\"#9b7a50\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M380 157 417 188\" fill=\"none\" stroke=\"#9b7a50\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M226 313 251 296\" fill=\"none\" stroke=\"#9b7a50\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M224 347 252 328\" fill=\"none\" stroke=\"#9b7a50\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M236 376 260 361\" fill=\"none\" stroke=\"#9b7a50\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M245 418 264 400 322 449 394 401 415 426 397 470 330 506 260 478Z\" fill=\"url(#di-r-p4-black)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M104 473 229 434 257 478 247 620H79Z\" fill=\"url(#di-r-p4-red)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M421 434 561 471 624 620H394l5-149Z\" fill=\"url(#di-r-p4-red)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M259 475 330 495 395 470 379 620H257Z\" fill=\"url(#di-r-p4-black)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M250 475 247 620\" fill=\"none\" stroke=\"#c1b293\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M400 470 390 620\" fill=\"none\" stroke=\"#c1b293\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.9\"/><path d=\"M90 478 198 446 218 467 199 487 99 512Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M448 447 555 474 569 508 466 491Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"443\" cy=\"523\" rx=\"29\" ry=\"23\" fill=\"url(#di-r-p4-silver)\" stroke=\"#475c54\" stroke-width=\"2\"/><path d=\"M426 524q16-28 33 0-17 24-33 0Z\" fill=\"none\" stroke=\"#617976\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M408 574 478 575 498 581\" fill=\"none\" stroke=\"#c16d4d\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M405 586 482 590\" fill=\"none\" stroke=\"#c16d4d\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M131 569 212 554\" fill=\"none\" stroke=\"#c16d4d\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/></g><g transform=\"rotate(-9 340 330)\"><path d=\"M101 494l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M111 491.8l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M121 489.6l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M131 487.4l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M141 485.2l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M151 483l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M161 480.8l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M171 478.6l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M181 476.4l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M191 474.2l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M201 472l-8 33\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M486 449l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M496 449.9l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M506 450.8l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M516 451.7l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M526 452.6l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M536 453.5l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M546 454.4l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M556 455.3l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M566 456.2l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M576 457.1l2 31\" fill=\"none\" stroke=\"#bc8e43\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g></g></symbol><symbol id=\"di-r-p4-diplomacy\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#45524b\" /><path d=\"M0 0h120l30 620H0ZM540 0h160v620H550Z\" fill=\"#273a36\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M147 0h29v620h-29ZM500 0h20v620h-20Z\" fill=\"#9b9e83\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 461Q350 413 700 472v32Q350 466 0 506Z\" fill=\"#b6b49b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 520Q350 477 700 533v87H0Z\" fill=\"#71806c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M155 620 192 421 267 374 371 378 439 419 483 620Z\" fill=\"url(#di-r-p4-pale)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M270 313 268 384 322 442 382 384 375 307Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M225 382V193Q218 106 299 102C382 79 432 140 426 218L430 397 380 436 259 436Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M265 164Q311 133 353 151C393 166 407 194 402 238L395 286Q380 326 357 346C334 365 307 358 287 342Q260 319 250 283L246 227Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M245 268C228 240 237 188 255 162Q282 118 329 128C368 124 399 145 410 183L407 214 379 189 353 166Q311 184 283 183L264 227 259 275Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M248 231Q246 171 289 146\" fill=\"none\" stroke=\"#8d8d6c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M268 168Q307 133 345 141\" fill=\"none\" stroke=\"#8d8d6c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M252 284Q241 337 264 376\" fill=\"none\" stroke=\"#8d8d6c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M402 238Q420 304 391 378\" fill=\"none\" stroke=\"#8d8d6c\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M261 379 321 441 379 377 408 413 346 498 307 498 237 414Z\" fill=\"#6d9498\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M197 427Q172 464 145 489L101 496 69 480Q57 479 55 487L77 503 55 503Q43 504 48 512L80 520 108 517 160 523 212 490 238 443Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M412 420Q443 456 453 495L467 536 491 544Q501 550 492 558L464 551 446 524 421 480 389 449Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M216 444 211 549\" fill=\"none\" stroke=\"#d0d3bb\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M403 455 418 553\" fill=\"none\" stroke=\"#d0d3bb\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M280 483 260 580\" fill=\"none\" stroke=\"#d0d3bb\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M357 485 377 576\" fill=\"none\" stroke=\"#d0d3bb\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.65\"/><path d=\"M-10 601Q350 470 710 582v38H0Z\" fill=\"#c7c7aa\" stroke=\"#e5ddbb\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M453 558 471 554 489 564 513 565Q519 571 511 574L481 574 462 569Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g></symbol><symbol id=\"di-r-p4-jessica\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#45524b\" /><path d=\"M0 0h120l30 620H0ZM540 0h160v620H550Z\" fill=\"#273a36\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M147 0h29v620h-29ZM500 0h20v620h-20Z\" fill=\"#9b9e83\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 461Q350 413 700 472v32Q350 466 0 506Z\" fill=\"#b6b49b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 520Q350 477 700 533v87H0Z\" fill=\"#71806c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M124 620 151 449 242 396 291 379 378 380 440 414 502 465 555 620Z\" fill=\"url(#di-r-p4-wine)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M233 434C220 379 220 272 236 206C242 127 278 91 335 91C393 87 440 142 444 209L454 438 399 492 275 493Z\" fill=\"url(#di-r-p4-wine)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M288 330 282 397 334 457 392 398 389 317Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M275 181Q318 147 361 163C405 180 419 215 412 256L402 300Q388 340 363 360C340 377 314 372 292 351Q267 326 258 290L254 234Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M255 258C243 219 260 171 292 154C321 136 360 141 385 160L412 190 408 220 388 184 365 171 327 175 297 166 275 206 265 264Z\" fill=\"#342c26\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M233 438Q217 358 227 260C227 163 272 100 331 101C398 97 439 154 444 235L451 436 423 473Q404 396 404 301L404 221Q392 175 350 158C305 151 269 181 265 228L268 338 283 414 298 454Z\" fill=\"url(#di-r-p4-wine)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M250 437C233 377 237 302 241 254C240 168 275 119 329 116\" fill=\"none\" stroke=\"#a6988d\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M384 140Q432 187 430 253L439 419\" fill=\"none\" stroke=\"#a6988d\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M271 333Q272 387 294 421\" fill=\"none\" stroke=\"#a6988d\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M209 458Q282 449 331 507Q385 449 448 452L475 518 430 620H224Z\" fill=\"url(#di-r-p4-wine)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M214 466 330 520 445 459\" fill=\"none\" stroke=\"#a99894\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M217 483 330 536 453 478\" fill=\"none\" stroke=\"#a99894\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M332 539 312 620\" fill=\"none\" stroke=\"#a99894\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M341 541 362 620\" fill=\"none\" stroke=\"#a99894\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M204 571 261 537Q279 532 296 545L353 579 362 596 347 605 290 574 258 573 224 595Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M369 589 410 552Q425 542 442 552L485 583 479 607 450 589 430 580 404 605 379 610 355 605 352 597Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M365 595 399 585 427 567\" fill=\"none\" stroke=\"#96715d\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/><path d=\"M373 605 410 594 433 578\" fill=\"none\" stroke=\"#96715d\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.55\"/></g></symbol><symbol id=\"di-r-p4-duncan\" viewBox=\"0 0 700 620\"><g clip-path=\"url(#di-r-p4-frame)\"><rect x=\"0\" y=\"0\" width=\"700\" height=\"620\" fill=\"#45524b\" /><path d=\"M0 0h120l30 620H0ZM540 0h160v620H550Z\" fill=\"#273a36\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M147 0h29v620h-29ZM500 0h20v620h-20Z\" fill=\"#9b9e83\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 461Q350 413 700 472v32Q350 466 0 506Z\" fill=\"#b6b49b\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M0 520Q350 477 700 533v87H0Z\" fill=\"#71806c\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M92 620 120 455 220 402 280 384 384 386 460 413 522 465 580 620Z\" fill=\"url(#di-r-p4-black)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M270 318 266 394 327 447 389 392 383 312Z\" fill=\"url(#di-r-p4-neck)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M237 344V214Q232 132 301 118C372 97 425 152 424 215L441 350 407 402 256 406Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M269 170Q314 142 357 157C398 174 414 207 408 247L399 289Q386 328 363 350C339 371 316 367 293 350Q263 327 252 295L247 247Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M249 261C227 238 234 190 254 166C268 134 304 121 337 128Q392 127 418 172L421 215 402 242 388 205 362 174 331 180 306 166 281 183 261 227Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M260 302 280 315 302 326 331 320 360 306 397 290Q392 332 370 355L344 377 313 373 282 353Z\" fill=\"url(#di-r-p4-hair)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M255 203Q265 154 307 145\" fill=\"none\" stroke=\"#82836b\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M279 160Q323 133 367 150\" fill=\"none\" stroke=\"#82836b\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M367 150Q400 165 410 197\" fill=\"none\" stroke=\"#82836b\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M244 264 250 345\" fill=\"none\" stroke=\"#82836b\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M420 259 429 349\" fill=\"none\" stroke=\"#82836b\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M285 331 310 360\" fill=\"none\" stroke=\"#82836b\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M348 334 344 366\" fill=\"none\" stroke=\"#82836b\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.45\"/><path d=\"M203 419 266 392 325 442 387 393 454 429 444 524 329 574 209 524Z\" fill=\"#526c70\" stroke=\"#b1b8a0\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M207 445 265 418 326 465 390 418 446 450 426 503 329 546 230 503Z\" fill=\"#3a555d\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M225 465 326 504 429 465\" fill=\"none\" stroke=\"#aab9ad\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.8\"/><path d=\"M231 494 328 532 421 494\" fill=\"none\" stroke=\"#aab9ad\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.8\"/><path d=\"M326 469 328 544\" fill=\"none\" stroke=\"#aab9ad\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.8\"/><path d=\"M125 456 184 430 211 467 187 528 129 557 102 525Z\" fill=\"#597174\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M461 435 506 459 532 523 489 552 449 507Z\" fill=\"#415d65\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M128 465 174 448 195 473\" fill=\"none\" stroke=\"#c0c5ac\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M121 487 181 472\" fill=\"none\" stroke=\"#c0c5ac\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M469 450 496 466 519 522\" fill=\"none\" stroke=\"#c0c5ac\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.6\"/><path d=\"M517 84 525 65 529 433 518 475 510 429Z\" fill=\"url(#di-r-p4-silver)\" stroke=\"#d4d5bc\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M483 443 551 436 553 448 534 456 535 538 517 540 513 455 484 456Z\" fill=\"url(#di-r-p4-gold)\" stroke=\"#6f6747\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M482 548 506 522 535 524 547 542 542 565 520 583 489 578 480 562Z\" fill=\"url(#di-r-p4-skin)\" stroke=\"none\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M502 542 529 541\" fill=\"none\" stroke=\"#8c6b56\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M500 552 532 550\" fill=\"none\" stroke=\"#8c6b56\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/><path d=\"M505 562 534 560\" fill=\"none\" stroke=\"#8c6b56\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" opacity=\"0.7\"/></g></symbol>\n<symbol id=\"di-r-terrain\" viewBox=\"0 0 1420 1110\"><rect x=\"0\" y=\"0\" width=\"1420\" height=\"1110\" rx=\"0\" fill=\"url(#di-r-sand)\" stroke=\"none\" /><path d=\"M355 216 557 224 639 267 715 252 777 305 886 275 952 318 1038 291 1114 334 1380 288v256l-101-65-87 21-106-57-80 18-91-43-85 28-83-53-83 8-102-52-107 9Z\" fill=\"#8b8b76\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m374 258 135 23 63-30 74 49 68-15 67 47 92-29 92 43 75-15 113 39 87-23 110 28v126l-134-40-111 8-98-28-114 4-115-35-79 3-88-48-86 7-44-50Z\" fill=\"#727b6c\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M367 419 431.9 343.94 455.5 349.5 485 280 510.96 324.48 538.1 320.31 603 419Z\" fill=\"#6d786a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M367 419 431.9 343.94 455.5 349.5 485 280 479.1 385.64 449.6 419Z\" fill=\"#c3b18a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m485 280 25.96 44.480000000000004 27.14 -4.17 64.9 98.69-89.68 -13.9-34.22 -19.46Z\" fill=\"#53675f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M412.65999999999997 343.94q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M414.65999999999997 349.5q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M416.65999999999997 355.06q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M418.65999999999997 360.62q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M420.65999999999997 366.18q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M422.65999999999997 371.74q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M424.65999999999997 377.3q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M426.65999999999997 382.86q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M428.65999999999997 388.42q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M430.65999999999997 393.98q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M432.65999999999997 399.54q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M434.65999999999997 405.1q18.88 -11.120000000000001 33.040000000000006 -9.73t33.040000000000006 -11.120000000000001\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M485 280l-15.34 43.089999999999996 4.72 23.630000000000003-14.16 19.46 3.54 20.849999999999998-24.779999999999998 26.41\" fill=\"none\" stroke=\"#e8d4a9\" stroke-width=\"1.3\" opacity=\".7\"/><path d=\"m510.96 324.48 -9.44 27.8 14.16 23.630000000000003-11.8 18.07 20.060000000000002 18.07\" fill=\"none\" stroke=\"#344e49\" stroke-width=\"1.6\" opacity=\".55\"/><path d=\"m408.3 393.98 11.8-16.68 7.08 9.73 11.8 4.17-9.44 15.290000000000001Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M408.3 393.98L424.82 387.03000000000003\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m434.26 400.93 11.8-16.68 7.08 9.73 11.8 4.17-9.44 15.290000000000001Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M434.26 400.93L450.78 393.98\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m460.22 407.88 11.8-16.68 7.08 9.73 11.8 4.17-9.44 15.290000000000001Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M460.22 407.88L476.74 400.93\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m486.18 393.98 11.8-16.68 7.08 9.73 11.8 4.17-9.44 15.290000000000001Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M486.18 393.98L502.7 387.03000000000003\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m512.14 400.93 11.8-16.68 7.08 9.73 11.8 4.17-9.44 15.290000000000001Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M512.14 400.93L528.66 393.98\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m538.1 407.88 11.8-16.68 7.08 9.73 11.8 4.17-9.44 15.290000000000001Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M538.1 407.88L554.62 400.93\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m564.06 393.98 11.8-16.68 7.08 9.73 11.8 4.17-9.44 15.290000000000001Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M564.06 393.98L580.5799999999999 387.03000000000003\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"M592 472 648.65 374.8 669.25 382 695 292 717.66 349.6 741.35 344.2 798 472Z\" fill=\"#6d786a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M592 472 648.65 374.8 669.25 382 695 292 689.85 428.8 664.1 472Z\" fill=\"#b7b293\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m695 292 22.66 57.6 23.69 -5.3999999999999995 56.650000000000006 127.8-78.28 -18-29.869999999999997 -25.200000000000003Z\" fill=\"#53675f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M632.11 374.8q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M634.11 382q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M636.11 389.20000000000005q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M638.11 396.40000000000003q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M640.11 403.6q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M642.11 410.8q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M644.11 418q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M646.11 425.20000000000005q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M648.11 432.40000000000003q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M650.11 439.6q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M652.11 446.8q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M654.11 454q16.48 -14.4 28.840000000000003 -12.600000000000001t28.840000000000003 -14.4\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M695 292l-13.39 55.8 4.12 30.6-12.36 25.200000000000003 3.09 27-21.63 34.2\" fill=\"none\" stroke=\"#e8d4a9\" stroke-width=\"1.3\" opacity=\".7\"/><path d=\"m717.66 349.6 -8.24 36 12.36 30.6-10.3 23.400000000000002 17.51 23.400000000000002\" fill=\"none\" stroke=\"#344e49\" stroke-width=\"1.6\" opacity=\".55\"/><path d=\"m628.05 439.6 10.3-21.599999999999998 6.18 12.600000000000001 10.3 5.3999999999999995-8.24 19.8Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M628.05 439.6L642.4699999999999 430.6\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m650.7099999999999 448.6 10.3-21.599999999999998 6.18 12.600000000000001 10.3 5.3999999999999995-8.24 19.8Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M650.7099999999999 448.6L665.1299999999999 439.6\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m673.37 457.6 10.3-21.599999999999998 6.18 12.600000000000001 10.3 5.3999999999999995-8.24 19.8Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M673.37 457.6L687.79 448.6\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m696.03 439.6 10.3-21.599999999999998 6.18 12.600000000000001 10.3 5.3999999999999995-8.24 19.8Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M696.03 439.6L710.4499999999999 430.6\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m718.6899999999999 448.6 10.3-21.599999999999998 6.18 12.600000000000001 10.3 5.3999999999999995-8.24 19.8Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M718.6899999999999 448.6L733.1099999999999 439.6\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m741.3499999999999 457.6 10.3-21.599999999999998 6.18 12.600000000000001 10.3 5.3999999999999995-8.24 19.8Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M741.3499999999999 457.6L755.7699999999999 448.6\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m764.01 439.6 10.3-21.599999999999998 6.18 12.600000000000001 10.3 5.3999999999999995-8.24 19.8Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M764.01 439.6L778.43 430.6\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"M772 444 836.35 377.58 859.75 382.5 889 321 914.74 360.36 941.65 356.67 1006 444Z\" fill=\"#6d786a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M772 444 836.35 377.58 859.75 382.5 889 321 883.15 414.48 853.9 444Z\" fill=\"#c3b18a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m889 321 25.74 39.36 26.91 -3.69 64.35000000000001 87.33-88.92 -12.3-33.93 -17.220000000000002Z\" fill=\"#53675f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M817.29 377.58q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M819.29 382.49999999999994q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M821.29 387.41999999999996q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M823.29 392.34q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M825.29 397.26q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M827.29 402.17999999999995q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M829.29 407.09999999999997q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M831.29 412.02q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M833.29 416.93999999999994q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M835.29 421.85999999999996q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M837.29 426.78q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M839.29 431.7q18.72 -9.84 32.760000000000005 -8.610000000000001t32.760000000000005 -9.84\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M889 321l-15.21 38.13 4.68 20.91-14.04 17.220000000000002 3.51 18.45-24.57 23.37\" fill=\"none\" stroke=\"#e8d4a9\" stroke-width=\"1.3\" opacity=\".7\"/><path d=\"m914.74 360.36 -9.36 24.6 14.04 20.91-11.700000000000001 15.99 19.89 15.99\" fill=\"none\" stroke=\"#344e49\" stroke-width=\"1.6\" opacity=\".55\"/><path d=\"m812.95 421.86 11.700000000000001-14.76 7.02 8.610000000000001 11.700000000000001 3.69-9.36 13.53Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M812.95 421.86L829.33 415.71000000000004\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m838.69 428.01 11.700000000000001-14.76 7.02 8.610000000000001 11.700000000000001 3.69-9.36 13.53Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M838.69 428.01L855.07 421.86\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m864.4300000000001 434.16 11.700000000000001-14.76 7.02 8.610000000000001 11.700000000000001 3.69-9.36 13.53Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M864.4300000000001 434.16L880.8100000000001 428.01000000000005\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m890.1700000000001 421.86 11.700000000000001-14.76 7.02 8.610000000000001 11.700000000000001 3.69-9.36 13.53Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M890.1700000000001 421.86L906.5500000000001 415.71000000000004\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m915.9100000000001 428.01 11.700000000000001-14.76 7.02 8.610000000000001 11.700000000000001 3.69-9.36 13.53Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M915.9100000000001 428.01L932.2900000000001 421.86\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m941.6500000000001 434.16 11.700000000000001-14.76 7.02 8.610000000000001 11.700000000000001 3.69-9.36 13.53Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M941.6500000000001 434.16L958.0300000000001 428.01000000000005\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m967.3900000000001 421.86 11.700000000000001-14.76 7.02 8.610000000000001 11.700000000000001 3.69-9.36 13.53Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M967.3900000000001 421.86L983.7700000000001 415.71000000000004\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"M974 475 1026.8 394 1046 400 1070 325 1091.12 373 1113.2 368.5 1166 475Z\" fill=\"#6d786a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M974 475 1026.8 394 1046 400 1070 325 1065.2 439 1041.2 475Z\" fill=\"#b7b293\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m1070 325 21.12 48 22.080000000000002 -4.5 52.800000000000004 106.5-72.96000000000001 -15-27.839999999999996 -21.000000000000004Z\" fill=\"#53675f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1011.52 394q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1013.52 400q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1015.52 406q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M1017.52 412q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1019.52 418q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1021.52 424q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M1023.52 430q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1025.52 436q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1027.52 442q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M1029.52 448q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1031.52 454q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1033.52 460q15.36 -12 26.880000000000003 -10.500000000000002t26.880000000000003 -12\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M1070 325l-12.48 46.5 3.84 25.500000000000004-11.52 21.000000000000004 2.88 22.5-20.16 28.5\" fill=\"none\" stroke=\"#e8d4a9\" stroke-width=\"1.3\" opacity=\".7\"/><path d=\"m1091.12 373 -7.68 30 11.52 25.500000000000004-9.600000000000001 19.5 16.32 19.5\" fill=\"none\" stroke=\"#344e49\" stroke-width=\"1.6\" opacity=\".55\"/><path d=\"m1007.6 448 9.600000000000001-18 5.76 10.500000000000002 9.600000000000001 4.5-7.68 16.5Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1007.6 448L1021.0400000000001 440.5\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1028.72 455.5 9.600000000000001-18 5.76 10.500000000000002 9.600000000000001 4.5-7.68 16.5Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1028.72 455.5L1042.16 448\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1049.84 463 9.600000000000001-18 5.76 10.500000000000002 9.600000000000001 4.5-7.68 16.5Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1049.84 463L1063.28 455.5\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1070.96 448 9.600000000000001-18 5.76 10.500000000000002 9.600000000000001 4.5-7.68 16.5Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1070.96 448L1084.4 440.5\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1092.08 455.5 9.600000000000001-18 5.76 10.500000000000002 9.600000000000001 4.5-7.68 16.5Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1092.08 455.5L1105.52 448\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1113.2 463 9.600000000000001-18 5.76 10.500000000000002 9.600000000000001 4.5-7.68 16.5Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1113.2 463L1126.64 455.5\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1134.32 448 9.600000000000001-18 5.76 10.500000000000002 9.600000000000001 4.5-7.68 16.5Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1134.32 448L1147.76 440.5\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"M1174 487 1232.3 413.02 1253.5 418.5 1280 350 1303.32 393.84000000000003 1327.7 389.73 1386 487Z\" fill=\"#6d786a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1174 487 1232.3 413.02 1253.5 418.5 1280 350 1274.7 454.12 1248.2 487Z\" fill=\"#c3b18a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m1280 350 23.32 43.84 24.380000000000003 -4.109999999999999 58.300000000000004 97.27-80.56 -13.700000000000001-30.74 -19.180000000000003Z\" fill=\"#53675f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1215.22 413.02000000000004q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1217.22 418.5q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1219.22 423.98q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M1221.22 429.46000000000004q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1223.22 434.94q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1225.22 440.42q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M1227.22 445.90000000000003q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1229.22 451.38q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1231.22 456.86q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M1233.22 462.34000000000003q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1235.22 467.82000000000005q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M1237.22 473.3q16.96 -10.96 29.680000000000003 -9.590000000000002t29.680000000000003 -10.96\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M1280 350l-13.780000000000001 42.47 4.24 23.290000000000003-12.719999999999999 19.180000000000003 3.1799999999999997 20.55-22.259999999999998 26.03\" fill=\"none\" stroke=\"#e8d4a9\" stroke-width=\"1.3\" opacity=\".7\"/><path d=\"m1303.32 393.84000000000003 -8.48 27.400000000000002 12.719999999999999 23.290000000000003-10.600000000000001 17.810000000000002 18.02 17.810000000000002\" fill=\"none\" stroke=\"#344e49\" stroke-width=\"1.6\" opacity=\".55\"/><path d=\"m1211.1 462.34 10.600000000000001-16.439999999999998 6.359999999999999 9.590000000000002 10.600000000000001 4.109999999999999-8.48 15.07Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1211.1 462.34L1225.9399999999998 455.48999999999995\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1234.4199999999998 469.19 10.600000000000001-16.439999999999998 6.359999999999999 9.590000000000002 10.600000000000001 4.109999999999999-8.48 15.07Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1234.4199999999998 469.19L1249.2599999999998 462.34\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1257.74 476.03999999999996 10.600000000000001-16.439999999999998 6.359999999999999 9.590000000000002 10.600000000000001 4.109999999999999-8.48 15.07Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1257.74 476.03999999999996L1272.58 469.18999999999994\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1281.06 462.34 10.600000000000001-16.439999999999998 6.359999999999999 9.590000000000002 10.600000000000001 4.109999999999999-8.48 15.07Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1281.06 462.34L1295.8999999999999 455.48999999999995\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1304.3799999999999 469.19 10.600000000000001-16.439999999999998 6.359999999999999 9.590000000000002 10.600000000000001 4.109999999999999-8.48 15.07Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1304.3799999999999 469.19L1319.2199999999998 462.34\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1327.6999999999998 476.03999999999996 10.600000000000001-16.439999999999998 6.359999999999999 9.590000000000002 10.600000000000001 4.109999999999999-8.48 15.07Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1327.6999999999998 476.03999999999996L1342.5399999999997 469.18999999999994\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1351.02 462.34 10.600000000000001-16.439999999999998 6.359999999999999 9.590000000000002 10.600000000000001 4.109999999999999-8.48 15.07Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1351.02 462.34L1365.86 455.48999999999995\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"M568 597 607.6 543 622 547 640 497 655.84 529 672.4 526 712 597Z\" fill=\"#6d786a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M568 597 607.6 543 622 547 640 497 636.4 573 618.4 597Z\" fill=\"#b7b293\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m640 497 15.84 32 16.560000000000002 -3 39.6 71-54.72 -10-20.88 -14.000000000000002Z\" fill=\"#53675f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M596.64 543q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M598.64 547q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M600.64 551q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M602.64 555q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M604.64 559q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M606.64 563q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M608.64 567q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M610.64 571q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M612.64 575q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M614.64 579q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M616.64 583q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M618.64 587q11.52 -8 20.160000000000004 -7.000000000000001t20.160000000000004 -8\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M640 497l-9.36 31 2.88 17-8.64 14.000000000000002 2.16 15-15.12 19\" fill=\"none\" stroke=\"#e8d4a9\" stroke-width=\"1.3\" opacity=\".7\"/><path d=\"m655.84 529 -5.76 20 8.64 17-7.2 13 12.24 13\" fill=\"none\" stroke=\"#344e49\" stroke-width=\"1.6\" opacity=\".55\"/><path d=\"m593.2 579 7.2-12 4.32 7.000000000000001 7.2 3-5.76 11Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M593.2 579L603.2800000000001 574\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m609.0400000000001 584 7.2-12 4.32 7.000000000000001 7.2 3-5.76 11Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M609.0400000000001 584L619.1200000000001 579\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m624.88 589 7.2-12 4.32 7.000000000000001 7.2 3-5.76 11Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M624.88 589L634.96 584\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m640.72 579 7.2-12 4.32 7.000000000000001 7.2 3-5.76 11Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M640.72 579L650.8000000000001 574\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m656.5600000000001 584 7.2-12 4.32 7.000000000000001 7.2 3-5.76 11Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M656.5600000000001 584L666.6400000000001 579\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m672.4000000000001 589 7.2-12 4.32 7.000000000000001 7.2 3-5.76 11Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M672.4000000000001 589L682.4800000000001 584\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m688.24 579 7.2-12 4.32 7.000000000000001 7.2 3-5.76 11Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M688.24 579L698.32 574\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"M880 602 928.4 551.24 946 555 968 508 987.36 538.08 1007.6 535.26 1056 602Z\" fill=\"#6d786a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M880 602 928.4 551.24 946 555 968 508 963.6 579.44 941.6 602Z\" fill=\"#c3b18a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"m968 508 19.36 30.080000000000002 20.240000000000002 -2.82 48.400000000000006 66.74-66.88 -9.4-25.52 -13.160000000000002Z\" fill=\"#53675f\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M914.56 551.24q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M916.56 555q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M918.56 558.76q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M920.56 562.52q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M922.56 566.28q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M924.56 570.04q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M926.56 573.8000000000001q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M928.56 577.5600000000001q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M930.56 581.32q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M932.56 585.08q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M934.56 588.84q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#8a866b\" stroke-width=\"0.7\" opacity=\".55\"/><path d=\"M936.56 592.6q14.08 -7.5200000000000005 24.64 -6.580000000000001t24.64 -7.5200000000000005\" fill=\"none\" stroke=\"#e0cda1\" stroke-width=\"1.3\" opacity=\".55\"/><path d=\"M968 508l-11.440000000000001 29.14 3.52 15.98-10.559999999999999 13.160000000000002 2.6399999999999997 14.1-18.48 17.86\" fill=\"none\" stroke=\"#e8d4a9\" stroke-width=\"1.3\" opacity=\".7\"/><path d=\"m987.36 538.08 -7.04 18.8 10.559999999999999 15.98-8.8 12.22 14.96 12.22\" fill=\"none\" stroke=\"#344e49\" stroke-width=\"1.6\" opacity=\".55\"/><path d=\"m910.8 585.08 8.8-11.28 5.279999999999999 6.580000000000001 8.8 2.82-7.04 10.34Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M910.8 585.08L923.12 580.38\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m930.16 589.7800000000001 8.8-11.28 5.279999999999999 6.580000000000001 8.8 2.82-7.04 10.34Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M930.16 589.7800000000001L942.48 585.08\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m949.52 594.48 8.8-11.28 5.279999999999999 6.580000000000001 8.8 2.82-7.04 10.34Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M949.52 594.48L961.84 589.78\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m968.88 585.08 8.8-11.28 5.279999999999999 6.580000000000001 8.8 2.82-7.04 10.34Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M968.88 585.08L981.2 580.38\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m988.24 589.7800000000001 8.8-11.28 5.279999999999999 6.580000000000001 8.8 2.82-7.04 10.34Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M988.24 589.7800000000001L1000.5600000000001 585.08\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1007.5999999999999 594.48 8.8-11.28 5.279999999999999 6.580000000000001 8.8 2.82-7.04 10.34Z\" fill=\"#92957a\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1007.5999999999999 594.48L1019.92 589.78\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"m1026.96 585.08 8.8-11.28 5.279999999999999 6.580000000000001 8.8 2.82-7.04 10.34Z\" fill=\"#b6ad89\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M1026.96 585.08L1039.28 580.38\" stroke=\"#d6c49a\" stroke-width=\"0.8\" fill=\"none\" opacity=\".6\"/><path d=\"M363 526q205-92 368-25t328 8 351 2v599H363Z\" fill=\"#bfa77c\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M358 623q169-124 352-42t387-9 313-2v540H358Z\" fill=\"#cdb58b\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M358 634q177-69 351-40t232 10q-119 36-252 4T358 671Z\" fill=\"#958460\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M901 599q298-91 509-20v87q-284-99-509-67Z\" fill=\"#e3cba0\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M361 828q221-179 445-85t604-13v380H361Z\" fill=\"#b7a17b\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M359 830q220-125 417-80-147 9-251 39t-166 72Z\" fill=\"#ead2a5\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M925 892q182-135 485-93v33q-215-39-485 60Z\" fill=\"#dec296\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M359 994q171-92 378-17t673-61v194H359Z\" fill=\"#c3ad85\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M365 580q155 -75 356 -13t674 -24\" fill=\"none\" stroke=\"#887755\" stroke-width=\"1.3\" opacity=\".37\"/><path d=\"M373 596q156 -74.6 359 -12.8t672 -23.7\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M381 612q157 -74.2 362 -12.6t670 -23.4\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M365 628q158 -73.8 365 -12.4t668 -23.1\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M373 644q159 -73.4 368 -12.2t666 -22.8\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M381 660q160 -73 371 -12t664 -22.5\" fill=\"none\" stroke=\"#887755\" stroke-width=\"1.3\" opacity=\".37\"/><path d=\"M365 676q161 -72.6 374 -11.8t662 -22.2\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M373 692q162 -72.2 377 -11.6t660 -21.9\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M381 708q163 -71.8 380 -11.4t658 -21.6\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M365 724q164 -71.4 383 -11.2t656 -21.3\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M373 740q165 -71 386 -11t654 -21\" fill=\"none\" stroke=\"#887755\" stroke-width=\"1.3\" opacity=\".37\"/><path d=\"M381 756q166 -70.6 389 -10.8t652 -20.7\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M365 772q167 -70.2 392 -10.6t650 -20.4\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M373 788q168 -69.8 395 -10.4t648 -20.1\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M381 804q169 -69.4 398 -10.2t646 -19.8\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M365 820q170 -69 401 -10t644 -19.5\" fill=\"none\" stroke=\"#887755\" stroke-width=\"1.3\" opacity=\".37\"/><path d=\"M373 836q171 -68.6 404 -9.8t642 -19.2\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M381 852q172 -68.2 407 -9.6t640 -18.9\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M365 868q173 -67.8 410 -9.4t638 -18.6\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M373 884q174 -67.4 413 -9.2t636 -18.3\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M381 900q175 -67 416 -9t634 -18\" fill=\"none\" stroke=\"#887755\" stroke-width=\"1.3\" opacity=\".37\"/><path d=\"M365 916q176 -66.6 419 -8.8t632 -17.7\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M373 932q177 -66.2 422 -8.6t630 -17.4\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M381 948q178 -65.8 425 -8.399999999999999t628 -17.1\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M365 964q179 -65.4 428 -8.2t626 -16.8\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M373 980q180 -65 431 -8t624 -16.5\" fill=\"none\" stroke=\"#887755\" stroke-width=\"1.3\" opacity=\".37\"/><path d=\"M381 996q181 -64.6 434 -7.8t622 -16.2\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M365 1012q182 -64.2 437 -7.6t620 -15.9\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M373 1028q183 -63.8 440 -7.3999999999999995t618 -15.6\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M381 1044q184 -63.4 443 -7.199999999999999t616 -15.3\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M365 1060q185 -63 446 -7t614 -15\" fill=\"none\" stroke=\"#887755\" stroke-width=\"1.3\" opacity=\".37\"/><path d=\"M373 1076q186 -62.6 449 -6.8t612 -14.700000000000001\" fill=\"none\" stroke=\"#ead5ac\" stroke-width=\"0.6\" opacity=\".37\"/><path d=\"M603 393q44 111 62 177t-35 115m434-249q-71 128-27 231\" fill=\"none\" stroke=\"#c3b893\" stroke-width=\"2\" stroke-dasharray=\"5 8\" opacity=\".45\"/><rect x=\"0\" y=\"0\" width=\"1420\" height=\"1110\" rx=\"0\" fill=\"url(#di-r-grain)\" stroke=\"none\" /></symbol>", cn = {
	spacingGuild: "guild",
	beneGesserit: "bene",
	blue: "city",
	shipment: "freighter",
	negotiator: "troop"
}, ln = {
	solari: "#dbba76",
	spice: "#db9558",
	water: "#75c7ed",
	vp: "#dbba76",
	persuasion: "#d3dce0",
	sword: "#d3dce0"
};
function un() {
	return /* @__PURE__ */ f("svg", {
		className: "di-definitions",
		"aria-hidden": "true",
		children: /* @__PURE__ */ f("defs", { dangerouslySetInnerHTML: { __html: on + sn } })
	});
}
function Q({ id: e, x: t = 0, y: n = 0, size: r = 24, color: i = "currentColor" }) {
	return e === "troop" || e === "negotiator" ? /* @__PURE__ */ p("g", {
		transform: `translate(${t} ${n}) scale(${r / 24})`,
		fill: i,
		stroke: "#172b35",
		strokeWidth: "1",
		children: [
			/* @__PURE__ */ f("path", { d: "m2 7 12-5 8 5-12 5Z" }),
			/* @__PURE__ */ f("path", { d: "m2 7 8 5v11L2 18Z" }),
			/* @__PURE__ */ f("path", { d: "m10 12 12-5v11l-12 5Z" }),
			/* @__PURE__ */ f("path", {
				d: "m10 12 12-5v11l-12 5Z",
				fill: "#000",
				opacity: ".15"
			})
		]
	}) : /* @__PURE__ */ f("use", {
		href: `#di-${cn[e] ?? e}`,
		x: t,
		y: n,
		width: r,
		height: r,
		style: { color: i }
	});
}
function dn({ id: e, color: t, size: n = 22 }) {
	return /* @__PURE__ */ f("svg", {
		width: n,
		height: n,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ f(Q, {
			id: e,
			color: t ?? ln[e] ?? "currentColor"
		})
	});
}
function fn({ effects: e, x: t = 0, y: n = 0, size: r = 21, limit: i = 4 }) {
	let a = e.flatMap((e) => e.kind === "gain" ? [{
		icon: e.resource,
		n: e.n
	}] : e.kind === "troop" || e.kind === "draw" || e.kind === "intrigue" || e.kind === "dread" || e.kind === "shipment" || e.kind === "negotiator" ? [{
		icon: e.kind,
		n: e.n
	}] : e.kind === "influence" && e.faction ? [{
		icon: e.faction,
		n: e.n
	}] : []);
	return /* @__PURE__ */ f("g", {
		transform: `translate(${t} ${n})`,
		children: a.slice(0, i).map((e, t) => /* @__PURE__ */ p("g", {
			transform: `translate(${r * 2.5 * t} 0)`,
			children: [/* @__PURE__ */ f(Q, {
				id: e.icon,
				size: r,
				color: ln[e.icon] ?? "#eee0bd"
			}), /* @__PURE__ */ f("text", {
				x: r + 4,
				y: r - 3,
				fontSize: r - 2,
				fill: "currentColor",
				children: e.n
			})]
		}, t))
	});
}
function pn({ id: e }) {
	let t = g[e], n = {
		duneTheDesertPlanet: "desert",
		dagger: "dagger",
		signetRing: "ring",
		diplomacy: "diplomacy",
		convincingArgument: "argument",
		reconnaissance: "recon",
		seekAllies: "allies",
		arrakisLiaison: "recon",
		theSpiceMustFlow: "desert",
		ladyJessica: "jessica",
		duncanIdaho: "duncan",
		spaceTravel: "travel"
	};
	if (n[e]) return /* @__PURE__ */ f("use", {
		href: `#di-r-art-${n[e]}`,
		width: "135",
		height: "114",
		preserveAspectRatio: "xMidYMid slice"
	});
	let r = /space|guild|thopter|flight|carryall|ship|fleet|landing|port|freighter/i.test(e) || t?.factions.includes("spacingGuild"), i = t?.factions.includes("beneGesserit"), a = t?.factions.includes("fremen"), o = /device|weapon|gun|sonic|lasgun|satellite|satellites|machine|training/i.test(e), s = /troop|sardaukar|commando|warrior|soldier|veteran|guard|sword|mercenary|drYueh/i.test(e);
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 135 96",
		width: "135",
		height: "114",
		preserveAspectRatio: "xMidYMid slice",
		overflow: "hidden",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M0 0h135v96H0Z",
				fill: "url(#di-r-sky)"
			}),
			/* @__PURE__ */ f("circle", {
				cx: "109",
				cy: "21",
				r: "14",
				fill: "#c9ae79"
			}),
			/* @__PURE__ */ f("path", {
				d: "M0 76q42-37 83-17t52-6v43H0Z",
				fill: "#ae8856"
			}),
			/* @__PURE__ */ f("path", {
				d: "M0 83q65-24 135 4v9H0Z",
				fill: "#d7b77f"
			}),
			/* @__PURE__ */ f("use", {
				href: `#di-r-art-${r ? "travel" : o ? "tech" : i ? "jessica" : a ? "recon" : s ? "duncan" : "diplomacy"}`,
				width: "135",
				height: "96",
				preserveAspectRatio: "xMidYMid slice"
			})
		]
	});
}
function mn({ id: e }) {
	let t = l(), n = g[e], r = ge[e], i = r?.agent.map((e) => Z(e, t)).join(" · ") ?? rn(e, t), a = r?.reveal.every((e) => [
		"gain",
		"draw",
		"intrigue",
		"troop",
		"shipment",
		"dread",
		"influence"
	].includes(e.kind));
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 145 216",
		className: "di-card-face",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("rect", {
				x: "1",
				y: "3",
				width: "143",
				height: "212",
				rx: "5",
				fill: "#0c1720"
			}),
			/* @__PURE__ */ f("rect", {
				x: "1",
				y: "1",
				width: "143",
				height: "211",
				rx: "4",
				fill: "#17252a",
				stroke: "#b0a28b"
			}),
			/* @__PURE__ */ f("foreignObject", {
				x: "9",
				y: "5",
				width: n && n.set !== "starter" ? 108 : 127,
				height: "22",
				children: /* @__PURE__ */ f("div", {
					className: "di-piece-name",
					children: X(e, t)
				})
			}),
			n && n.set !== "starter" && /* @__PURE__ */ p(te, { children: [/* @__PURE__ */ f("path", {
				d: "M122 1h22v21l-11 7-11-7Z",
				fill: "#567385",
				stroke: "#c7cbb2",
				strokeWidth: ".6"
			}), /* @__PURE__ */ f("text", {
				x: "133",
				y: "19",
				fontSize: "16",
				textAnchor: "middle",
				fill: "#f0ead3",
				children: n.cost
			})] }),
			/* @__PURE__ */ f("svg", {
				x: "5",
				y: "28",
				width: "135",
				height: "110",
				viewBox: "0 0 135 114",
				children: /* @__PURE__ */ f(pn, { id: e })
			}),
			/* @__PURE__ */ f("rect", {
				x: "5",
				y: "28",
				width: "135",
				height: "110",
				fill: "none",
				stroke: "#adb19d",
				strokeWidth: ".6"
			}),
			n?.icons.map((e, t) => /* @__PURE__ */ p("g", {
				transform: `translate(${7 + Math.floor(t / 4) * 21} ${33 + t % 4 * 23})`,
				children: [/* @__PURE__ */ f("rect", {
					width: "20",
					height: "21",
					rx: "2",
					fill: "#162b30",
					stroke: "#b6b49b",
					strokeWidth: ".7"
				}), /* @__PURE__ */ f(Q, {
					id: e,
					x: 2,
					y: 2,
					size: 17,
					color: "#ddd8bd"
				})]
			}, e)),
			/* @__PURE__ */ f("rect", {
				x: "5",
				y: "142",
				width: "135",
				height: "43",
				fill: "url(#di-r-paper)",
				stroke: "#b6a88c",
				strokeWidth: ".5"
			}),
			/* @__PURE__ */ f("foreignObject", {
				x: "11",
				y: "146",
				width: "124",
				height: "36",
				children: /* @__PURE__ */ f("div", {
					className: "di-piece-agent",
					children: i
				})
			}),
			/* @__PURE__ */ f("rect", {
				x: "5",
				y: "188",
				width: "135",
				height: "20",
				fill: "url(#di-r-navy)"
			}),
			a ? /* @__PURE__ */ f(fn, {
				effects: r?.reveal ?? [],
				x: 14,
				y: 189,
				size: 18,
				limit: 2
			}) : /* @__PURE__ */ f("foreignObject", {
				x: "10",
				y: "188",
				width: "126",
				height: "21",
				children: /* @__PURE__ */ f("div", {
					className: "di-piece-reveal",
					children: r?.reveal.map((e) => Z(e, t)).join(" · ")
				})
			}),
			n?.unload && /* @__PURE__ */ f(Q, {
				id: "freighter",
				x: 117,
				y: 166,
				size: 16,
				color: "#4f6570"
			})
		]
	});
}
function hn({ id: e, onClick: t, selected: n, legal: r, className: i = "", children: a }) {
	let o = l();
	return /* @__PURE__ */ p("div", {
		className: `di-card-piece ${i}`,
		"data-selected": n || void 0,
		"data-legal": r || void 0,
		children: [/* @__PURE__ */ f("button", {
			className: "di-card-button",
			onClick: (e) => {
				e.currentTarget.focus({ preventScroll: !0 }), t();
			},
			"aria-label": X(e, o),
			"aria-pressed": n === void 0 ? void 0 : n,
			children: /* @__PURE__ */ f(mn, { id: e })
		}), a]
	});
}
function gn({ id: e, full: t = !1 }) {
	let n = {
		paulAtreides: "pv3-paul",
		vladimirHarkonnen: "pv3-baron",
		letoAtreides: "p4-leto",
		glossuRabban: "p4-rabban",
		ilbanRichese: "p4-ilban",
		helenaRichese: "p4-helena",
		arianaThorvald: "p4-ariana",
		memnonThorvald: "p4-memnon",
		tessiaVernius: "p4-tessia",
		rhomburVernius: "p4-rhombur",
		armandEcaz: "p4-armand",
		ilesaEcaz: "p4-ilesa",
		yunaMoritani: "p4-yuna",
		hundroMoritani: "p4-hundro"
	};
	return /* @__PURE__ */ f("svg", {
		viewBox: t ? "0 0 700 620" : e === "paulAtreides" ? "110 50 540 540" : e === "vladimirHarkonnen" ? "60 30 580 580" : "75 35 570 570",
		"aria-hidden": "true",
		className: "di-portrait",
		children: n[e] ? /* @__PURE__ */ f("use", {
			href: `#di-r-${n[e]}`,
			width: "700",
			height: "620"
		}) : /* @__PURE__ */ f("rect", {
			width: "700",
			height: "620",
			fill: "#263b3b"
		})
	});
}
function _n({ id: e }) {
	if (e === "holoprojectors" || e === "minimicFilm") return /* @__PURE__ */ f("use", {
		href: "#di-r-art-tech",
		width: "320",
		height: "190"
	});
	if (/ship|fleet|port|transport/i.test(e)) return /* @__PURE__ */ f("use", {
		href: "#di-r-art-travel",
		width: "320",
		height: "190",
		preserveAspectRatio: "xMidYMid slice"
	});
	let t = e === "windtraps", n = /ordnance|artillery|detonation/i.test(e), r = /satellite|drone|snooper/i.test(e);
	return /* @__PURE__ */ p("g", {
		stroke: "#829e9c",
		strokeWidth: "1.2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M0 0h320v190H0Z",
				fill: "url(#di-r-metal)",
				stroke: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "m25 150 130-74 143 65-132 43Z",
				fill: "#1b3039"
			}),
			/* @__PURE__ */ f("path", {
				d: "m25 150 141 34v6L25 157Zm141 34 132-43v7l-132 42Z",
				fill: "#40585e"
			}),
			t ? /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m50 133 4-74 72-33 82 37-2 80-78 34Z",
					fill: "url(#di-r-steel)"
				}),
				/* @__PURE__ */ f("path", {
					d: "m54 59 74 31 80-27M128 90v87",
					fill: "none"
				}),
				[
					0,
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ f("path", {
					d: `m${63 + e * 10} ${69 + e * 4}v63l5 2V${71 + e * 4}Z`,
					fill: "#29414c",
					strokeWidth: ".6"
				}, e)),
				/* @__PURE__ */ f("path", {
					d: "m144 96 48-20v61l-48 21Z",
					fill: "#293f48"
				}),
				/* @__PURE__ */ f("path", {
					d: "m147 111 41-17m-41 28 41-17m-41 27 41-17m-41 27 41-17",
					stroke: "#bed0bf"
				}),
				/* @__PURE__ */ f("path", {
					d: "m206 115 42-18 24 9v44l-25 12-41-14Z",
					fill: "#637a7a"
				}),
				/* @__PURE__ */ f("path", {
					d: "M248 98V59l12-6v48M230 108V78l9-4v29",
					fill: "none",
					strokeWidth: "6"
				})
			] }) : n ? /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m77 141 32-40 79-9 40 52-66 28Z",
					fill: "url(#di-r-steel)"
				}),
				/* @__PURE__ */ f("path", {
					d: "m117 102 6-35 56-10 18 42-39 16Z",
					fill: "#4d6972"
				}),
				/* @__PURE__ */ f("path", {
					d: "m153 78 75-53 21 12-69 58Z",
					fill: "url(#di-r-steel)"
				}),
				/* @__PURE__ */ f("path", {
					d: "m228 25 21 12 8-9-21-12Z",
					fill: "#263f4c"
				}),
				/* @__PURE__ */ f("path", {
					d: "m236 18 16 9-5 5-15-9Z",
					fill: "#122b38"
				}),
				/* @__PURE__ */ f("path", {
					d: "m93 124-21 16 10 21 30-8m81-30 30 19-7 16-27-8",
					fill: "#29414c"
				}),
				[
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ f("path", {
					d: `m${124 + e * 9} 78 4-1 2 17-4 2Z`,
					fill: "#a6b5ac",
					strokeWidth: ".5"
				}, e)),
				/* @__PURE__ */ f("circle", {
					cx: "159",
					cy: "127",
					r: "15",
					fill: "#213e4a"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "159",
					cy: "127",
					r: "9",
					fill: "#8faaa6"
				}),
				/* @__PURE__ */ f("path", { d: "M159 115v24m-12-12h24" })
			] }) : r ? /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m123 89 36-25 41 15v43l-36 23-41-17Z",
					fill: "url(#di-r-steel)"
				}),
				/* @__PURE__ */ f("path", {
					d: "m123 89 41 19 36-29m-36 29v37",
					fill: "none"
				}),
				/* @__PURE__ */ f("path", {
					d: "m127 94-39-23m45 48-45 20m104-42 43-28m-37 50 37 20",
					fill: "none",
					strokeWidth: "7"
				}),
				[
					[78, 61],
					[242, 59],
					[78, 143],
					[242, 143]
				].map(([e, t]) => /* @__PURE__ */ p("g", { children: [
					/* @__PURE__ */ f("ellipse", {
						cx: e,
						cy: t,
						rx: "32",
						ry: "12",
						fill: "#1b333e"
					}),
					/* @__PURE__ */ f("ellipse", {
						cx: e,
						cy: t,
						rx: "23",
						ry: "7",
						fill: "#5c7d82"
					}),
					/* @__PURE__ */ f("path", {
						d: `M${e - 22} ${t}h44m-22-7v14`,
						stroke: "#b2c3b7"
					})
				] }, `${e}:${t}`)),
				/* @__PURE__ */ f("path", {
					d: "M161 68V37l26-14m-26 14-26-12",
					fill: "none",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "165",
					cy: "117",
					r: "7",
					fill: "#a4ceca"
				})
			] }) : /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ f("path", {
					d: "m85 126 1-56 74-29 75 31v58l-74 36Z",
					fill: "url(#di-r-steel)"
				}),
				/* @__PURE__ */ f("path", {
					d: "m86 70 75 31 74-29m-74 29v65",
					fill: "none"
				}),
				/* @__PURE__ */ f("path", {
					d: "m96 83 54 22v40l-54-22Z",
					fill: "#253e49"
				}),
				/* @__PURE__ */ f("path", {
					d: "m176 105 44-22v39l-44 22Z",
					fill: "#344e58"
				}),
				[
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ f("path", {
					d: `m103 ${94 + e * 9} 39 16m39 ${-e * 4} 32-16`,
					stroke: "#9fb7af"
				}, e)),
				/* @__PURE__ */ f("path", {
					d: "m134 50 1-22 25-10 28 12v22l-27 12Z",
					fill: "#75918f"
				}),
				/* @__PURE__ */ f("path", {
					d: "m135 28 26 12 27-10m-27 10v24",
					fill: "none"
				}),
				/* @__PURE__ */ f("path", {
					d: "m70 121-19 7v22l19 5m169-27 26 10v19l-26-2",
					fill: "#2e4b56"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "126",
					cy: "119",
					r: "5",
					fill: "#a4ceca"
				})
			] }),
			/* @__PURE__ */ f("path", {
				d: "M16 20h51m-51 0v31m237 107h51m0 0v-31",
				fill: "none",
				stroke: "#91aaa1",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ f("rect", {
				width: "320",
				height: "190",
				fill: "url(#di-r-grain)",
				stroke: "none"
			})
		]
	});
}
function vn({ id: e, count: t, exhausted: n, onClick: r }) {
	let i = l();
	return /* @__PURE__ */ f("button", {
		className: "di-tech-piece",
		onClick: r,
		"data-exhausted": n || void 0,
		"aria-label": `${X(e, i)}${n ? ` · ${i("games.duneimperium.techExhausted")}` : ""}`,
		children: /* @__PURE__ */ p("svg", {
			viewBox: "0 0 245 212",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ f("rect", {
					x: "3",
					y: "5",
					width: "239",
					height: "205",
					rx: "4",
					fill: "#101c22",
					stroke: "#7e8880"
				}),
				/* @__PURE__ */ f("rect", {
					x: "1",
					y: "1",
					width: "239",
					height: "205",
					rx: "3",
					fill: "url(#di-r-metal)",
					stroke: "#acb59f"
				}),
				/* @__PURE__ */ f("rect", {
					x: "6",
					y: "6",
					width: "229",
					height: "195",
					fill: "none",
					stroke: "#718d87",
					strokeWidth: ".7"
				}),
				/* @__PURE__ */ f("foreignObject", {
					x: "12",
					y: "10",
					width: "170",
					height: "28",
					children: /* @__PURE__ */ f("div", {
						className: "di-tech-name",
						children: X(e, i)
					})
				}),
				/* @__PURE__ */ f(Q, {
					id: "spice",
					x: 188,
					y: 12,
					size: 20,
					color: "#d0a16d"
				}),
				/* @__PURE__ */ f("text", {
					x: "213",
					y: "29",
					fontSize: "19",
					fill: "#e6e2cc",
					children: N[e].cost
				}),
				/* @__PURE__ */ f("svg", {
					x: "9",
					y: "43",
					width: "223",
					height: "111",
					viewBox: "0 0 320 190",
					preserveAspectRatio: "xMidYMid slice",
					children: /* @__PURE__ */ f(_n, { id: e })
				}),
				/* @__PURE__ */ f("path", {
					d: "M13 159h216",
					stroke: "#879b8c",
					strokeWidth: ".7"
				}),
				/* @__PURE__ */ f("foreignObject", {
					x: "13",
					y: "165",
					width: t === void 0 ? 215 : 188,
					height: "34",
					children: /* @__PURE__ */ f("div", {
						className: "di-tech-ability",
						children: rn(e, i)
					})
				}),
				t !== void 0 && /* @__PURE__ */ p("text", {
					x: "227",
					y: "196",
					textAnchor: "end",
					fontSize: "15",
					fill: "#c5cebc",
					children: ["×", t]
				}),
				n && /* @__PURE__ */ f("path", {
					d: "m8 8 224 191M8 199 224 8",
					stroke: "#c5cebc",
					opacity: ".45"
				})
			]
		})
	});
}
var yn = (e) => ({ "--di-player": e });
//#endregion
//#region src/games/duneimperium/board-view.tsx
function bn({ label: e, onClick: t, children: n, x: r = 0, y: i = 0 }) {
	return /* @__PURE__ */ f("g", {
		transform: `translate(${r} ${i})`,
		role: "button",
		tabIndex: 0,
		"aria-label": e,
		className: "di-board-target",
		onPointerDown: (e) => {
			e.preventDefault(), e.currentTarget.focus({ preventScroll: !0 });
		},
		onClick: (e) => {
			e.currentTarget.focus({ preventScroll: !0 }), t();
		},
		onKeyDown: (e) => {
			(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t());
		},
		children: n
	});
}
function $({ x: e, y: t, children: n, size: r = 20, width: i, fill: a = "#eee0bd", center: o = !1 }) {
	let s = String(n).split("").reduce((e, t) => e + (t.charCodeAt(0) > 255 ? 1 : .54), 0) * r;
	return /* @__PURE__ */ f("text", {
		x: e,
		y: t,
		fontSize: r,
		fill: a,
		fontWeight: "600",
		textAnchor: o ? "middle" : void 0,
		textLength: i && s > i ? i : void 0,
		lengthAdjust: "spacingAndGlyphs",
		children: n
	});
}
function xn({ pub: e, choices: t, color: n, name: r, inspectSpace: i, inspectEntity: a }) {
	let o = l(), s = (r, i, a) => {
		let o = e.agents[r] ?? [], s = t.some((e) => e.space === r);
		return /* @__PURE__ */ p("g", { children: [
			/* @__PURE__ */ f("circle", {
				cx: i,
				cy: a,
				r: "21",
				fill: "#132a3566",
				stroke: "#e8d8b3"
			}),
			/* @__PURE__ */ f("circle", {
				cx: i,
				cy: a,
				r: "15",
				fill: "none",
				stroke: "#e8d8b3",
				strokeWidth: ".8"
			}),
			o.length ? o.map((e, t) => /* @__PURE__ */ f(Q, {
				id: "agent",
				x: i - 14 + t * 16,
				y: a - 17,
				size: 29,
				color: n(e)
			}, `${e}:${t}`)) : /* @__PURE__ */ f(Q, {
				id: F[r].requires ? "lock" : "agent-outline",
				x: i - 11,
				y: a - 12,
				size: 23,
				color: "#e4d2ab"
			}),
			s && /* @__PURE__ */ f("path", {
				d: `M${i - 29} ${a - 13}v-16h16m26 0h16v16m0 26v16h-16m-26 0h-16v-16`,
				fill: "none",
				stroke: "#88d9f3",
				strokeWidth: "3"
			}),
			e.voice.some((e) => e.space === r) && /* @__PURE__ */ f("path", {
				d: `m${i - 20} ${a - 20} 40 40m-40 0 40-40`,
				stroke: "#bd78d2",
				strokeWidth: "5"
			})
		] });
	}, c = (t, n, r, i, a = 20) => {
		let s = F[t], c = s.harvest ? [{
			kind: "gain",
			resource: "spice",
			n: s.harvest + (e.bonus[t] ?? 0)
		}] : s.effects, l = {
			foldspace: "games.duneimperium.boardFoldspace",
			selectiveBreeding: "games.duneimperium.boardBreeding",
			highCouncil: "games.duneimperium.boardCouncil",
			mentat: "games.duneimperium.boardMentat",
			swordmaster: "games.duneimperium.boardSwordmaster",
			techNegotiation: "games.duneimperium.boardNegotiation",
			dreadnought: "games.duneimperium.boardTech"
		};
		return /* @__PURE__ */ p("g", {
			color: "#eee0bd",
			children: [/* @__PURE__ */ f(fn, {
				effects: c,
				x: n,
				y: r,
				size: a
			}), /* @__PURE__ */ f($, {
				x: n,
				y: r + 40,
				width: i,
				size: 16,
				children: l[t] ? o(l[t]) : ""
			})]
		});
	}, ee = (n) => `${X(n, o)}${t.some((e) => e.space === n) ? ` · ${o("games.duneimperium.sendAgent")}` : ""}${(e.agents[n] ?? []).map((e) => ` · ${r(e)}`).join("")}`, u = (t, n, r) => /* @__PURE__ */ f("g", {
		color: "#e7d0a4",
		children: Object.entries(Sn(e, t) ?? {}).map(([e, t], i) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f(Q, {
			id: e,
			x: n + i * 51,
			y: r,
			size: 20,
			color: ln[e]
		}), /* @__PURE__ */ f($, {
			x: n + 24 + i * 51,
			y: r + 17,
			size: 17,
			children: t
		})] }, e))
	}), d = (a, l, d, m, ne, re) => {
		let ie = F[a], ae = e.dreadControl.find((e) => e.space === a)?.rid ?? e.control[a], h = t.some((e) => e.space === a), oe = re ? 116 : 67;
		return /* @__PURE__ */ p(bn, {
			x: l,
			y: d,
			label: ee(a),
			onClick: () => i(a),
			children: [
				re ? /* @__PURE__ */ f("use", {
					href: `#di-r-city-${re}`,
					width: m,
					height: "116"
				}) : /* @__PURE__ */ p(te, { children: [/* @__PURE__ */ f("path", {
					d: `M0 62Q${m * .39} -21 ${m} 22Q${m * .59} 16 0 62Z`,
					fill: "#e6cea1"
				}), /* @__PURE__ */ f("path", {
					d: `M0 62Q${m * .45} 23 ${m} 22Q${m * .72} 37 0 76Z`,
					fill: "#99825d"
				})] }),
				/* @__PURE__ */ f("rect", {
					y: oe,
					width: m,
					height: ne - oe,
					fill: re ? "#304b54ed" : "#695a41ed",
					stroke: h ? "#9fcad4" : "#b5b497",
					strokeWidth: h ? 3 : 1,
					rx: "2"
				}),
				/* @__PURE__ */ f($, {
					x: 12,
					y: oe + 25,
					width: m - 72,
					children: X(a, o)
				}),
				s(a, m - 29, oe + 29),
				c(a, 12, oe + 38, m - 48),
				ie.combat && /* @__PURE__ */ f(Q, {
					id: "sword",
					x: m - 29,
					y: ne - 24,
					size: 17,
					color: "#c9b98b"
				}),
				Object.keys(Sn(e, a) ?? {}).length > 0 && /* @__PURE__ */ f("rect", {
					x: m - 85,
					y: oe - 24,
					width: "85",
					height: "23",
					rx: "2",
					fill: "#263e46",
					stroke: "#a7ae93",
					strokeWidth: ".6"
				}),
				u(a, m - 81, oe - 23),
				ie.requires && /* @__PURE__ */ p(te, { children: [/* @__PURE__ */ f(Q, {
					id: "lock",
					x: 10,
					y: ne - 23,
					size: 16,
					color: "#d6c8ab"
				}), /* @__PURE__ */ f($, {
					x: 31,
					y: ne - 8,
					size: 14,
					width: m - 63,
					children: o("games.duneimperium.requiresInfluence", { faction: X(ie.requires, o) })
				})] }),
				ae && /* @__PURE__ */ p("g", { children: [
					/* @__PURE__ */ f("path", {
						d: `M${m - 112} 10v44m0-42h70l-13 14 13 14h-70`,
						fill: n(ae),
						stroke: "#273b41"
					}),
					/* @__PURE__ */ f($, {
						x: m - 106,
						y: 31,
						size: 14,
						width: 62,
						children: r(ae)
					}),
					e.dreadControl.some((e) => e.space === a) && /* @__PURE__ */ f(Q, {
						id: "dread",
						x: m - 58,
						y: 42,
						size: 48,
						color: n(ae)
					})
				] })
			]
		}, a);
	}, m = e.conflict ? Te[e.conflict] : null, ne = [
		[584, 940],
		[1023, 658],
		[1016, 936],
		[595, 665]
	];
	return /* @__PURE__ */ p("svg", {
		className: "di-main-board",
		viewBox: "-5 -5 1440 1130",
		"aria-label": o("games.duneimperium.boardTitle"),
		children: [
			/* @__PURE__ */ f("rect", {
				x: "3",
				y: "5",
				width: "1420",
				height: "1110",
				rx: "8",
				fill: "#0b1820"
			}),
			/* @__PURE__ */ f("rect", {
				width: "1420",
				height: "1110",
				rx: "6",
				fill: "#a3987a",
				stroke: "#d0c5a7"
			}),
			/* @__PURE__ */ f("rect", {
				x: "8",
				y: "8",
				width: "1404",
				height: "1094",
				rx: "3",
				fill: "#404e4a"
			}),
			/* @__PURE__ */ f("svg", {
				x: "14",
				y: "14",
				width: "1392",
				height: "1082",
				viewBox: "14 14 1392 1082",
				children: /* @__PURE__ */ f("use", {
					href: "#di-r-terrain",
					width: "1420",
					height: "1110"
				})
			}),
			/* @__PURE__ */ f("rect", {
				x: "14",
				y: "14",
				width: "1392",
				height: "1082",
				rx: "2",
				fill: "none",
				stroke: "#c5ba96"
			}),
			_.map((a, l) => /* @__PURE__ */ p("g", {
				transform: `translate(20 ${20 + l * 264})`,
				children: [
					/* @__PURE__ */ f("rect", {
						width: "337",
						height: "252",
						rx: "2",
						fill: [
							"#524044",
							"#51473c",
							"#494252",
							"#3c535b"
						][l],
						stroke: "#b9b093"
					}),
					/* @__PURE__ */ f("rect", {
						x: "6",
						y: "6",
						width: "325",
						height: "240",
						fill: "none",
						stroke: "#c5b990",
						opacity: ".35"
					}),
					/* @__PURE__ */ f(Q, {
						id: a,
						x: 153,
						y: 67,
						size: 158,
						color: "#c1b9a00d"
					}),
					/* @__PURE__ */ f(Q, {
						id: a,
						x: 15,
						y: 15,
						size: 30,
						color: "#d6c8a5"
					}),
					/* @__PURE__ */ f($, {
						x: 57,
						y: 39,
						width: 227,
						size: 23,
						children: o(tn[a])
					}),
					/* @__PURE__ */ f("path", {
						d: "M97 52v189",
						stroke: "#d9bd82"
					}),
					Array.from({ length: 7 }, (e, t) => /* @__PURE__ */ p("g", { children: [
						/* @__PURE__ */ f("path", {
							d: `M29 ${222 - t * 26}h54`,
							stroke: "#aa976e"
						}),
						/* @__PURE__ */ f("circle", {
							cx: "55",
							cy: 222 - t * 26,
							r: t === 2 || t === 4 ? 10 : 5,
							fill: t === 2 ? "#dab66d" : "#293743",
							stroke: "#d2b483"
						}),
						/* @__PURE__ */ f($, {
							x: 12,
							y: 228 - t * 26,
							size: 16,
							fill: "#d0bc94",
							children: t
						}),
						t === 2 && /* @__PURE__ */ f(Q, {
							id: "vp",
							x: 49,
							y: 216 - t * 26,
							size: 12,
							color: "#473f35"
						}),
						t === 4 && /* @__PURE__ */ f(Q, {
							id: a,
							x: 46,
							y: 213 - t * 26,
							size: 18,
							color: "#dbba76"
						})
					] }, t)),
					e.players.map((e, t) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ p("title", { children: [
						r(e.rid),
						": ",
						e.influence[a]
					] }), /* @__PURE__ */ f(Q, {
						id: "troop",
						x: 38 + t % 2 * 22,
						y: 210 - e.influence[a] * 26 + Math.floor(t / 2) * 11,
						size: 14,
						color: n(e.rid)
					})] }, e.rid)),
					/* @__PURE__ */ f("g", {
						color: "#e9d8b2",
						children: /* @__PURE__ */ f(fn, {
							effects: xe[a],
							x: 108,
							y: 225,
							size: 18
						})
					}),
					e.alliance[a] && /* @__PURE__ */ p("g", { children: [
						/* @__PURE__ */ p("title", { children: [
							o("games.duneimperium.alliance"),
							" · ",
							r(e.alliance[a])
						] }),
						/* @__PURE__ */ f("circle", {
							cx: "312",
							cy: "29",
							r: "15",
							fill: n(e.alliance[a]),
							stroke: "#ead4a1"
						}),
						/* @__PURE__ */ f(Q, {
							id: a,
							x: 301,
							y: 18,
							size: 22,
							color: "#f4e4c5"
						})
					] }),
					P.filter((e) => e.icon === a).map((e, n) => /* @__PURE__ */ p(bn, {
						x: 110,
						y: 65 + n * 87,
						label: ee(e.id),
						onClick: () => i(e.id),
						children: [
							/* @__PURE__ */ f("rect", {
								width: "215",
								height: "76",
								fill: "#12253355",
								stroke: t.some((t) => t.space === e.id) ? "#88d9f3" : "#e0c79c70",
								strokeWidth: t.some((t) => t.space === e.id) ? 3 : .8,
								rx: "2"
							}),
							/* @__PURE__ */ f($, {
								x: 10,
								y: 24,
								width: 155,
								children: X(e.id, o)
							}),
							s(e.id, 190, 38),
							c(e.id, 10, 34, 154, 17),
							u(e.id, 117, 56),
							e.combat && /* @__PURE__ */ f(Q, {
								id: "sword",
								x: 177,
								y: 57,
								size: 16,
								color: "#dbba76"
							})
						]
					}, e.id))
				]
			}, a)),
			/* @__PURE__ */ f("rect", {
				x: "371",
				y: "20",
				width: "1009",
				height: "217",
				fill: "#3e5143",
				stroke: "#c0b594",
				rx: "2"
			}),
			/* @__PURE__ */ f("rect", {
				x: "377",
				y: "26",
				width: "997",
				height: "205",
				fill: "url(#di-r-etch)"
			}),
			/* @__PURE__ */ f(Q, {
				id: "green",
				x: 388,
				y: 29,
				size: 32,
				color: "#c6bc96"
			}),
			/* @__PURE__ */ f($, {
				x: 432,
				y: 54,
				size: 24,
				children: o("games.duneimperium.landsraad")
			}),
			[
				"highCouncil",
				"mentat",
				"swordmaster",
				...e.config.ix ? ["techNegotiation", "dreadnought"] : ["rallyTroops", "hallOfOratory"]
			].map((e, n) => /* @__PURE__ */ p(bn, {
				x: 385 + n * 198,
				y: 73,
				label: ee(e),
				onClick: () => i(e),
				children: [
					/* @__PURE__ */ f("rect", {
						width: "187",
						height: "146",
						rx: "3",
						fill: "#21382f",
						stroke: t.some((t) => t.space === e) ? "#88d9f3" : "#c1b28388",
						strokeWidth: t.some((t) => t.space === e) ? 3 : 1
					}),
					/* @__PURE__ */ f(Q, {
						id: "green",
						x: 12,
						y: 10,
						size: 26,
						color: "#c3c69d"
					}),
					/* @__PURE__ */ f($, {
						x: 12,
						y: 62,
						width: 163,
						children: X(e, o)
					}),
					s(e, 149, 29),
					u(e, 12, 75),
					c(e, 12, 103, 162, 17)
				]
			}, e)),
			/* @__PURE__ */ f("rect", {
				x: "1100",
				y: "258",
				width: "275",
				height: "203",
				fill: "#5f5140",
				stroke: "#d0ba91",
				rx: "2"
			}),
			/* @__PURE__ */ f(Q, {
				id: "yellow",
				x: 1114,
				y: 270,
				size: 27,
				color: "#c6bc96"
			}),
			/* @__PURE__ */ f($, {
				x: 1152,
				y: 294,
				size: 23,
				width: 210,
				children: o("games.duneimperium.spiceTrade")
			}),
			(e.config.ix ? ["smuggling", "interstellarShipping"] : ["secureContract", "sellMelange"]).map((e, n) => /* @__PURE__ */ p(bn, {
				x: 1113,
				y: 312 + n * 70,
				label: ee(e),
				onClick: () => i(e),
				children: [
					/* @__PURE__ */ f("rect", {
						width: "247",
						height: "61",
						rx: "2",
						fill: "#473a2c55",
						stroke: t.some((t) => t.space === e) ? "#88d9f3" : "#dac19a80",
						strokeWidth: t.some((t) => t.space === e) ? 3 : 1
					}),
					/* @__PURE__ */ f($, {
						x: 11,
						y: 26,
						width: 185,
						children: X(e, o)
					}),
					s(e, 216, 29),
					c(e, 11, 34, 190, 16),
					e === "sellMelange" && /* @__PURE__ */ f($, {
						x: 12,
						y: 50,
						size: 16,
						children: "2 → 6 · 3 → 8 · 4 → 10 · 5 → 12"
					}),
					F[e].requires && /* @__PURE__ */ p(te, { children: [/* @__PURE__ */ f(Q, {
						id: "spacingGuild",
						x: 136,
						y: 36,
						size: 17,
						color: "#dbba76"
					}), /* @__PURE__ */ f($, {
						x: 158,
						y: 51,
						size: 15,
						children: "≥2"
					})] })
				]
			}, e)),
			d("arrakeen", 398, 252, 245, 194, "arrakeen"),
			d("researchStation", 790, 252, 250, 214, "research"),
			d("carthag", 398, 470, 245, 194, "carthag"),
			d("sietchTabr", 790, 470, 250, 214, "sietch"),
			d("imperialBasin", 398, 701, 245, 151),
			d("haggaBasin", 1100, 497, 268, 151),
			d("theGreatFlat", 1100, 727, 268, 151),
			/* @__PURE__ */ f("path", {
				d: "M684 753 811 708 987 758 1025 923 869 1009 707 946Z",
				fill: "#736e50aa",
				stroke: "#ddd0a6",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ f("path", {
				d: "M704 771 813 733 967 775 999 911 869 982 731 930Z",
				fill: "url(#di-r-etch)",
				stroke: "#b5b08d"
			}),
			/* @__PURE__ */ f($, {
				x: 847,
				y: 806,
				size: 24,
				fill: "#3d4d45",
				center: !0,
				children: o("games.duneimperium.conflictTitle")
			}),
			e.players.map((e, t) => /* @__PURE__ */ p("g", { children: [
				/* @__PURE__ */ p("title", { children: [
					r(e.rid),
					" · ",
					o("games.duneimperium.resources.troop"),
					" ",
					e.combat,
					" · ",
					o("games.duneimperium.resources.strength"),
					" ",
					e.strength
				] }),
				Array.from({ length: e.combat }, (r, i) => /* @__PURE__ */ f(Q, {
					id: "troop",
					x: 736 + t % 2 * 126 + i % 6 * 18,
					y: 820 + Math.floor(t / 2) * 60 + Math.floor(i / 6) * 18,
					size: 18,
					color: n(e.rid)
				}, i)),
				Array.from({ length: e.dreadCombat }, (r, i) => /* @__PURE__ */ f(Q, {
					id: "dread",
					x: 742 + t % 2 * 126 + i * 33,
					y: 798 + Math.floor(t / 2) * 60,
					size: 39,
					color: n(e.rid)
				}, i)),
				/* @__PURE__ */ p("g", {
					transform: `translate(${ne[t][0]} ${ne[t][1]})`,
					children: [
						/* @__PURE__ */ f("ellipse", {
							cx: "59",
							cy: "43",
							rx: "66",
							ry: "40",
							fill: "#3f403a40",
							stroke: "#e0c79c"
						}),
						/* @__PURE__ */ f($, {
							x: 59,
							y: 24,
							size: 18,
							width: 106,
							fill: "#263844",
							center: !0,
							children: r(e.rid)
						}),
						Array.from({ length: e.garrison }, (t, r) => /* @__PURE__ */ f(Q, {
							id: "troop",
							x: 8 + r % 6 * 17,
							y: 34 + Math.floor(r / 6) * 17,
							size: 17,
							color: n(e.rid)
						}, r)),
						Array.from({ length: e.dreadGarrison }, (t, r) => /* @__PURE__ */ f(Q, {
							id: "dread",
							x: 12 + r * 34,
							y: 64,
							size: 36,
							color: n(e.rid)
						}, r))
					]
				})
			] }, e.rid)),
			/* @__PURE__ */ p(bn, {
				x: 394,
				y: 876,
				label: m ? X(m.id, o) : o("games.duneimperium.conflictTitle"),
				onClick: () => {
					e.conflict && a(e.conflict);
				},
				children: [
					/* @__PURE__ */ f("rect", {
						x: "3",
						y: "4",
						width: "180",
						height: "207",
						fill: "#0b1724",
						stroke: "#9d895d",
						rx: "4"
					}),
					/* @__PURE__ */ f("rect", {
						width: "180",
						height: "207",
						fill: "#182c3d",
						stroke: "#cfad71",
						rx: "4"
					}),
					m && /* @__PURE__ */ p(te, { children: [
						/* @__PURE__ */ f($, {
							x: 90,
							y: 30,
							width: 159,
							size: 23,
							center: !0,
							children: o(m.nameKey)
						}),
						/* @__PURE__ */ f($, {
							x: 90,
							y: 61,
							size: 27,
							fill: "#dbba76",
							center: !0,
							children: "ⅠⅡⅢ"[m.level - 1]
						}),
						m.rewards.map((e, t) => /* @__PURE__ */ p("g", {
							color: "#eee0bd",
							children: [/* @__PURE__ */ f($, {
								x: 13,
								y: 101 + t * 42,
								size: 22,
								fill: "#dbba76",
								children: t + 1
							}), /* @__PURE__ */ f(fn, {
								effects: e,
								x: 43,
								y: 80 + t * 42,
								size: 20,
								limit: 2
							})]
						}, t))
					] })
				]
			}),
			/* @__PURE__ */ f("rect", {
				x: "598",
				y: "1046",
				width: "776",
				height: "41",
				fill: "#28323a",
				stroke: "#b7a077",
				rx: "2"
			}),
			/* @__PURE__ */ f(Q, {
				id: "sword",
				x: 604,
				y: 1054,
				size: 25,
				color: "#dbba76"
			}),
			Array.from({ length: 21 }, (e, t) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("path", {
				d: `M${648 + t * 35} 1050v31`,
				stroke: "#a88b5d",
				strokeWidth: ".7"
			}), /* @__PURE__ */ f($, {
				x: 656 + t * 35,
				y: 1073,
				size: 16,
				fill: "#dac69e",
				children: t
			})] }, t)),
			e.players.map((e, t) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ p("title", { children: [
				r(e.rid),
				": ",
				e.strength
			] }), /* @__PURE__ */ f(Q, {
				id: "troop",
				x: 657 + Math.min(20, e.strength) * 35,
				y: 1020 - t * 8,
				size: 19,
				color: n(e.rid)
			})] }, e.rid)),
			Array.from({ length: 13 }, (e, t) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("path", {
				d: `M1385 ${280 + t * 58}h21`,
				stroke: "#a88b5d"
			}), /* @__PURE__ */ f($, {
				x: 1390,
				y: 301 + t * 58,
				size: 17,
				fill: "#463f32",
				children: t
			})] }, t)),
			e.players.map((e, t) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ p("title", { children: [
				r(e.rid),
				": ",
				e.vp
			] }), /* @__PURE__ */ f("circle", {
				cx: 1389 + t % 2 * 12,
				cy: 271 + Math.min(12, e.vp) * 58 + Math.floor(t / 2) * 12,
				r: "8",
				fill: n(e.rid),
				stroke: "#e8d1a0"
			})] }, e.rid))
		]
	});
}
function Sn(e, t) {
	return t === "mentat" && e.players.filter((e) => !e.npc).length === 1 && e.config.difficulty !== "mercenary" ? { solari: 5 } : F[t].cost;
}
function Cn({ cost: e }) {
	let t = l();
	return /* @__PURE__ */ f("div", {
		className: "di-cost-line",
		children: Object.entries(e ?? {}).map(([e, n]) => /* @__PURE__ */ p("span", { children: [
			/* @__PURE__ */ f("svg", {
				viewBox: "0 0 24 24",
				"aria-hidden": "true",
				children: /* @__PURE__ */ f(Q, {
					id: e,
					color: ln[e]
				})
			}),
			n,
			" ",
			t(`games.duneimperium.resources.${e}`)
		] }, e))
	});
}
//#endregion
//#region src/games/duneimperium/view-player.tsx
var wn = {
	leaders: "games.duneimperium.phaseLeaders",
	prepare: "games.duneimperium.phasePrepare",
	turns: "games.duneimperium.phaseTurns",
	combatStart: "games.duneimperium.phaseCombat",
	combat: "games.duneimperium.phaseCombat",
	rewards: "games.duneimperium.phaseRewards",
	victory: "games.duneimperium.phaseVictory",
	battleEnd: "games.duneimperium.phaseCombat",
	makers: "games.duneimperium.phaseMakers",
	recall: "games.duneimperium.phaseRecall",
	endgame: "games.duneimperium.phaseEndgame",
	done: "games.duneimperium.phaseDone"
};
function Tn({ title: e, children: t, close: n }) {
	let i = o(null), a = l();
	return r(() => {
		i.current?.focus({ preventScroll: !0 });
	}, []), /* @__PURE__ */ f("div", {
		ref: i,
		tabIndex: -1,
		className: "di-modal safe-x safe-t safe-b",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": e,
		onKeyDown: (e) => {
			if (e.key === "Escape" && n && (e.stopPropagation(), n()), e.key === "Tab") {
				let t = i.current?.querySelectorAll("button:not(:disabled), [tabindex=\"0\"]"), n = t?.[0], r = t?.[t.length - 1];
				n && r && (document.activeElement === i.current || e.shiftKey && document.activeElement === n || !e.shiftKey && document.activeElement === r) && (e.preventDefault(), (e.shiftKey ? r : n).focus());
			}
		},
		children: /* @__PURE__ */ p("section", {
			className: "di-dialog",
			children: [/* @__PURE__ */ p("header", {
				className: "di-dialog-title",
				children: [/* @__PURE__ */ f("h2", { children: e }), n && /* @__PURE__ */ f("button", {
					className: "di-button",
					onClick: n,
					children: a("games.duneimperium.close")
				})]
			}), /* @__PURE__ */ f("div", {
				className: "di-dialog-content",
				children: t
			})]
		})
	});
}
function En({ resource: e, n: t }) {
	let n = l();
	return /* @__PURE__ */ p("span", {
		className: "di-resource",
		title: n(nn[e]),
		children: [
			/* @__PURE__ */ f(dn, { id: e }),
			/* @__PURE__ */ f("b", { children: t }),
			/* @__PURE__ */ f("span", {
				className: "sr-only",
				children: n(nn[e])
			})
		]
	});
}
function Dn(e) {
	ee();
	let t = l(), n = e.public, r = e.private, [a, c] = s(null), [m, ne] = s(null), re = o(null), ie = o(null), ae = () => {
		ie.current = re.current?.parentElement?.scrollTop ?? 0;
	}, h = (e) => {
		ne(document.activeElement), ae(), c(e);
	}, oe = () => {
		ae(), c(null);
	}, se = () => {
		ne(document.activeElement), ae(), y(!0);
	}, ce = () => {
		ae(), y(!1);
	}, [v, y] = s(!1), [b, x] = s(!1), S = o(null), C = o(null), w = o(null), T = n.phase === "done" ? [] : r?.choices ?? [], E = n.players.find((t) => t.rid === e.myRid), le = T.length > 0, D = (r) => {
		let i = n.players.filter((e) => e.npc).findIndex((e) => e.rid === r);
		return i >= 0 ? t("games.duneimperium.npc", { n: i + 1 }) : e.members.find((e) => e.rid === r)?.name ?? r;
	}, O = (t) => {
		let r = e.members.find((e) => e.rid === t), i = u.filter((t, n) => !e.members.some((e) => e.colorIndex % u.length === n)), a = n.players.filter((e) => e.npc).findIndex((e) => e.rid === t);
		return r ? u[r.colorIndex % u.length].hex : (i[a] ?? u[0]).hex;
	}, k = (t) => {
		ae(), e.send({
			type: "act",
			id: t
		}), y(!1), c(null);
	}, A = (e) => h({
		entity: e.id,
		uid: e.uid
	}), ue = (e) => {
		let t = T.find((t) => t.group === "play" && t.card?.uid === e.uid), n = T.find((e) => e.id === "cancel");
		r?.selected === e.uid && n ? k(n.id) : t ? k(t.id) : A(e);
	}, de = T.filter((e) => e.group === "main"), j = r?.hand.find((e) => e.uid === r.selected), M = n.prompt ? t(n.prompt.key) : n.phase === "turns" && n.active === e.myRid ? t(r?.selected ? "games.duneimperium.chooseSpace" : n.mode === "agent" ? "games.duneimperium.agentTurn" : n.mode === "reveal" ? "games.duneimperium.revealTurn" : "games.duneimperium.startTurn") : n.acting ? t("games.duneimperium.wait", { name: D(n.acting) }) : t("games.duneimperium.resolving"), fe = le && (n.prompt?.owner === e.myRid || n.phase === "leaders");
	i(() => {
		let e = re.current?.parentElement;
		e && ie.current !== null && (e.scrollTo({ top: ie.current }), ie.current = null);
	}, [
		n,
		a,
		v,
		fe
	]), i(() => {
		!a && !v && !fe && m?.isConnected && m.focus({ preventScroll: !0 });
	}, [
		a,
		v,
		fe,
		m
	]);
	let pe = (e) => {
		let t = re.current?.parentElement;
		t && e && t.scrollTo({ top: t.scrollTop + e.getBoundingClientRect().top - t.getBoundingClientRect().top - 8 });
	}, me = (e, t = !1) => /* @__PURE__ */ f(hn, {
		id: e.id,
		onClick: () => A(e),
		legal: T.some((t) => t.group === "buy" && t.card?.uid === e.uid),
		className: t ? "di-reserve-card" : "di-supply-card"
	}, e.uid), he = r?.hand.length ? r.hand : E?.revealedCards ?? [], ve = (e) => /* @__PURE__ */ f("div", {
		className: "di-choice-list",
		children: e.map((e) => {
			let r = an(e, t), i = X(e.source, t), a = e.preview?.map((e) => Z(e, t)).filter((e) => e !== t("games.duneimperium.effectCard") && !r.includes(e)).join(" · ");
			return /* @__PURE__ */ p("button", {
				className: "di-choice",
				onClick: () => k(e.id),
				children: [
					e.source && e.source !== n.prompt?.source && !r.includes(i) && i !== (n.prompt && t(n.prompt.key)) && /* @__PURE__ */ f("strong", { children: i }),
					/* @__PURE__ */ p("span", { children: [
						r,
						e.target?.startsWith("$hagal") || n.players.some((t) => t.rid === e.target) ? ` · ${D(e.target)}` : "",
						e.space === "sellMelange" && e.n ? ` · ${t("games.duneimperium.tradeSpice", { n: e.n })}` : ""
					] }),
					a && e.key !== "games.duneimperium.effectOption" && /* @__PURE__ */ f("small", { children: a }),
					e.card && /* @__PURE__ */ f("p", { children: rn(e.card.id, t) }),
					e.target && _e.some((t) => t.id === e.target) && /* @__PURE__ */ p("div", {
						className: "di-leader-choice",
						children: [/* @__PURE__ */ f(gn, { id: e.target }), /* @__PURE__ */ f("p", { children: rn(e.target, t) })]
					})
				]
			}, e.id);
		})
	}), ye = a && "entity" in a ? T.filter((e) => e.card && e.card.uid === a.uid || e.group === "tech" && e.source === a.entity) : [], P = (e) => /* @__PURE__ */ p(te, { children: [
		/* @__PURE__ */ p("div", {
			className: "di-personal-content",
			children: [
				e.leader && /* @__PURE__ */ p("button", {
					className: "di-leader-piece",
					onClick: () => h({ entity: e.leader }),
					children: [/* @__PURE__ */ f(gn, { id: e.leader }), /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f("strong", { children: X(e.leader, t) }), /* @__PURE__ */ f("small", { children: t("games.duneimperium.leaderAbility") })] })]
				}),
				/* @__PURE__ */ p("div", {
					className: "di-public-counts",
					children: [
						/* @__PURE__ */ f("span", { children: t("games.duneimperium.deckCount", { n: e.deckCount }) }),
						/* @__PURE__ */ f("span", { children: t("games.duneimperium.intrigueCount", { n: e.intrigueCount }) }),
						/* @__PURE__ */ f("span", { children: t("games.duneimperium.supplyCount", { n: 12 - e.garrison - e.combat - e.negotiators }) }),
						/* @__PURE__ */ p("button", {
							className: "di-button di-quiet",
							onClick: () => h({
								list: e.discard,
								title: t("games.duneimperium.viewDiscard")
							}),
							children: [
								t("games.duneimperium.viewDiscard"),
								" (",
								e.discard.length,
								")"
							]
						}),
						/* @__PURE__ */ p("span", { children: [e.council ? t("games.duneimperium.councilSeat") : "", e.swordmaster ? ` · ${X("swordmaster", t)}` : ""] })
					]
				}),
				!!e.techs.length && /* @__PURE__ */ f("div", {
					className: "di-owned-tech",
					children: e.techs.map((t) => /* @__PURE__ */ f(vn, {
						id: t,
						exhausted: e.exhausted.includes(t),
						onClick: () => h({ entity: t })
					}, t))
				})
			]
		}),
		!!e.snoopers.length && /* @__PURE__ */ p("p", {
			className: "di-muted",
			children: [
				t("games.duneimperium.snoopers"),
				"：",
				e.snoopers.map((e) => X(e, t)).join(" · ")
			]
		}),
		!!e.revealedSecrets.length && /* @__PURE__ */ p("p", {
			className: "di-muted",
			children: [
				t("games.duneimperium.revealedSecrets"),
				"：",
				e.revealedSecrets.map((e) => X(e, t)).join(" · ")
			]
		}),
		!!e.played.length && /* @__PURE__ */ p("div", {
			className: "di-public-cards",
			children: [/* @__PURE__ */ f("h3", { children: t("games.duneimperium.playedCards") }), /* @__PURE__ */ f("div", {
				className: "di-hand-row",
				children: e.played.map((e) => /* @__PURE__ */ f(hn, {
					id: e.id,
					onClick: () => A(e)
				}, e.uid))
			})]
		}),
		!!e.revealedCards.length && /* @__PURE__ */ p("div", {
			className: "di-public-cards",
			children: [/* @__PURE__ */ f("h3", { children: t("games.duneimperium.revealedCards") }), /* @__PURE__ */ f("div", {
				className: "di-hand-row",
				children: e.revealedCards.map((e) => /* @__PURE__ */ f(hn, {
					id: e.id,
					onClick: () => A(e)
				}, e.uid))
			})]
		}),
		e.shownCard && /* @__PURE__ */ f("div", {
			className: "di-shown-card",
			children: me(e.shownCard)
		}),
		!!e.reserved.length && /* @__PURE__ */ f("div", {
			className: "di-reserve-grid",
			children: e.reserved.map((e) => me(e, !0))
		})
	] }), Se = /* @__PURE__ */ p("section", {
		ref: S,
		className: "di-own di-area",
		"aria-label": t("games.duneimperium.playerArea"),
		children: [
			/* @__PURE__ */ p("header", {
				className: "di-section-head",
				children: [/* @__PURE__ */ f("h2", { children: E ? D(E.rid) : t("games.duneimperium.playerArea") }), /* @__PURE__ */ f("div", {
					className: "di-own-resources",
					children: E && /* @__PURE__ */ p(te, { children: [[
						"solari",
						"spice",
						"water",
						"persuasion"
					].map((e) => /* @__PURE__ */ f(En, {
						resource: e,
						n: E[e]
					}, e)), /* @__PURE__ */ p("span", {
						className: "di-resource",
						title: t("games.duneimperium.resources.agent"),
						children: [
							/* @__PURE__ */ f(dn, {
								id: "agent",
								color: O(E.rid)
							}),
							/* @__PURE__ */ f("b", { children: E.agents }),
							/* @__PURE__ */ f("span", {
								className: "sr-only",
								children: t("games.duneimperium.resources.agent")
							})
						]
					})] })
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "di-hand-head",
				children: [/* @__PURE__ */ p("span", { children: [
					t(!r?.hand.length && E?.revealedCards.length ? "games.duneimperium.revealedCards" : "games.duneimperium.hand"),
					" ",
					/* @__PURE__ */ f("b", { children: he.length })
				] }), /* @__PURE__ */ p("div", {
					className: "di-turn-actions",
					children: [
						de.map((e) => /* @__PURE__ */ f("button", {
							className: `di-button ${e.id === "cancel" ? "di-quiet" : "di-primary"}`,
							onClick: () => k(e.id),
							children: t(e.key, e.params)
						}, e.id)),
						T.some((e) => e.group === "effect") && /* @__PURE__ */ f("button", {
							className: "di-button di-primary",
							onClick: se,
							children: t("games.duneimperium.resolveEffect")
						}),
						/* @__PURE__ */ f("button", {
							className: "di-button di-quiet",
							onClick: se,
							children: t("games.duneimperium.actionTitle")
						})
					]
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "di-hand-row",
				children: [he.map((e) => /* @__PURE__ */ f(hn, {
					id: e.id,
					selected: r?.selected === e.uid,
					legal: T.some((t) => t.group === "play" && t.card?.uid === e.uid),
					onClick: () => ue(e),
					children: /* @__PURE__ */ f("button", {
						className: "di-card-detail",
						onClick: () => A(e),
						"aria-label": `${X(e.id, t)} · ${t("games.duneimperium.details")}`,
						children: t("games.duneimperium.details")
					})
				}, e.uid)), !he.length && /* @__PURE__ */ f("span", {
					className: "di-empty-hand",
					children: t("games.duneimperium.noCards")
				})]
			}),
			E && /* @__PURE__ */ p("details", {
				className: "di-personal-details",
				children: [
					/* @__PURE__ */ f("summary", { children: t("games.duneimperium.personalDetails") }),
					P(E),
					(r?.peek || r?.aside || !!r?.secrets.length) && /* @__PURE__ */ p("details", {
						className: "di-personal-details",
						children: [/* @__PURE__ */ f("summary", { children: t("games.duneimperium.privateDetails") }), /* @__PURE__ */ p("div", {
							className: "di-private-cards",
							children: [
								r.peek && /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("h3", { children: t("games.duneimperium.peekTitle") }), me(r.peek)] }),
								r.aside && /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("h3", { children: t("games.duneimperium.aside") }), me(r.aside)] }),
								!!r.secrets.length && /* @__PURE__ */ p("p", { children: [
									t("games.duneimperium.secretsTitle"),
									"：",
									r.secrets.map((e) => X(e, t)).join(" · ")
								] })
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ p("details", {
				className: "di-personal-details",
				children: [/* @__PURE__ */ p("summary", { children: [
					t("games.duneimperium.intrigueHand"),
					" (",
					r?.intrigues.length ?? 0,
					")"
				] }), /* @__PURE__ */ p("div", {
					className: "di-intrigue-grid",
					children: [r?.intrigues.map((e) => /* @__PURE__ */ f(hn, {
						id: e.id,
						legal: T.some((t) => t.group === "intrigue" && t.card?.uid === e.uid),
						onClick: () => A(e)
					}, e.uid)), !r?.intrigues.length && /* @__PURE__ */ f("p", { children: t("games.duneimperium.noCards") })]
				})]
			})
		]
	}), I = /* @__PURE__ */ p("div", {
		className: `di-board-group${n.config.ix ? " di-with-ix" : ""}`,
		children: [/* @__PURE__ */ p("section", {
			ref: C,
			className: "di-board di-area",
			children: [/* @__PURE__ */ p("header", {
				className: "di-section-head",
				children: [/* @__PURE__ */ f("h2", { children: t("games.duneimperium.boardTitle") }), /* @__PURE__ */ f("button", {
					className: "di-button di-quiet",
					"aria-pressed": b,
					onClick: () => x(!b),
					children: t(b ? "games.duneimperium.fitBoard" : "games.duneimperium.zoomBoard")
				})]
			}), /* @__PURE__ */ f("div", {
				className: `di-board-scroll${b ? " di-zoomed" : ""}`,
				children: /* @__PURE__ */ f(xn, {
					pub: n,
					choices: T,
					color: O,
					name: D,
					inspectSpace: (e) => h({ space: e }),
					inspectEntity: (e) => h({ entity: e })
				})
			})]
		}), n.config.ix && /* @__PURE__ */ p("section", {
			className: "di-ix di-area",
			children: [/* @__PURE__ */ f("header", {
				className: "di-section-head",
				children: /* @__PURE__ */ f("h2", { children: t("games.duneimperium.ixTitle") })
			}), /* @__PURE__ */ p("div", {
				className: "di-ix-parts",
				children: [/* @__PURE__ */ p("div", {
					className: "di-tech-stack",
					children: [
						/* @__PURE__ */ f("h3", { children: t("games.duneimperium.techMarket") }),
						n.techTops.map((e, r) => e ? /* @__PURE__ */ f(vn, {
							id: e,
							count: n.techCounts[r],
							onClick: () => h({ entity: e })
						}, r) : /* @__PURE__ */ f("p", { children: t("games.duneimperium.noCards") }, r)),
						/* @__PURE__ */ p("div", {
							className: "di-brokers",
							children: [/* @__PURE__ */ f("span", { children: t("games.duneimperium.resources.negotiator") }), n.players.map((e) => /* @__PURE__ */ p("span", {
								title: D(e.rid),
								children: [/* @__PURE__ */ f(dn, {
									id: "troop",
									color: O(e.rid)
								}), e.negotiators]
							}, e.rid))]
						})
					]
				}), /* @__PURE__ */ p("div", {
					className: "di-shipping",
					children: [/* @__PURE__ */ f("h3", { children: t("games.duneimperium.shipping") }), /* @__PURE__ */ f("div", {
						className: "di-shipping-track",
						children: [
							3,
							2,
							1,
							0
						].map((e) => /* @__PURE__ */ p("div", {
							className: "di-shipping-stop",
							children: [/* @__PURE__ */ p("div", {
								className: "di-ship-node",
								children: [/* @__PURE__ */ f("b", { children: e }), n.players.filter((t) => t.shipment === e).map((e, t) => /* @__PURE__ */ p("span", {
									style: { top: -15 + t * 13 },
									title: D(e.rid),
									children: [/* @__PURE__ */ f(dn, {
										id: "freighter",
										color: O(e.rid),
										size: 37
									}), /* @__PURE__ */ f("span", {
										className: "sr-only",
										children: D(e.rid)
									})]
								}, e.rid))]
							}), /* @__PURE__ */ f("span", { children: t(e === 3 ? "games.duneimperium.shippingTop" : e === 2 ? "games.duneimperium.shippingMiddle" : e === 1 ? "games.duneimperium.shippingFirst" : "games.duneimperium.shippingStart") })]
						}, e))
					})]
				})]
			})]
		})]
	}), L = /* @__PURE__ */ p("section", {
		ref: w,
		className: "di-market di-area",
		children: [
			/* @__PURE__ */ p("header", {
				className: "di-section-head",
				children: [/* @__PURE__ */ f("h2", { children: t("games.duneimperium.market") }), /* @__PURE__ */ f("small", { children: n.deckCount })]
			}),
			/* @__PURE__ */ f("div", {
				className: "di-market-grid",
				children: n.market.map((e) => me(e))
			}),
			/* @__PURE__ */ f("header", {
				className: "di-section-head di-reserve-head",
				children: /* @__PURE__ */ f("h2", { children: t("games.duneimperium.reserves") })
			}),
			/* @__PURE__ */ f("div", {
				className: "di-reserve-grid",
				children: Object.entries(n.reserve).map(([e, t]) => /* @__PURE__ */ p("div", { children: [me({
					id: e,
					uid: `reserve:${e}`
				}, !0), /* @__PURE__ */ p("small", { children: ["×", t] })] }, e))
			}),
			/* @__PURE__ */ p("div", {
				className: "di-intrigue-decks",
				children: [
					/* @__PURE__ */ f(dn, { id: "intrigue" }),
					/* @__PURE__ */ f("span", { children: t("games.duneimperium.deckCount", { n: n.intrigueDeckCount }) }),
					/* @__PURE__ */ p("button", {
						className: "di-button di-quiet",
						onClick: () => h({
							list: n.intrigueDiscard,
							title: t("games.duneimperium.intrigueDiscard")
						}),
						children: [
							t("games.duneimperium.viewDiscard"),
							" ",
							n.intrigueDiscard.length
						]
					})
				]
			})
		]
	}), R = /* @__PURE__ */ p("section", {
		className: "di-other-players di-area",
		children: [/* @__PURE__ */ p("header", {
			className: "di-section-head",
			children: [/* @__PURE__ */ f("h2", { children: t("games.duneimperium.playersTitle") }), /* @__PURE__ */ f("button", {
				className: "di-button di-quiet",
				onClick: () => h({ history: !0 }),
				children: t("games.duneimperium.history")
			})]
		}), /* @__PURE__ */ f("div", {
			className: "di-opponents-grid",
			children: n.players.filter((t) => t.rid !== e.myRid).map((e) => /* @__PURE__ */ p("article", {
				className: "di-opponent",
				style: yn(O(e.rid)),
				children: [
					/* @__PURE__ */ p("header", {
						className: "di-opponent-head",
						children: [/* @__PURE__ */ f(gn, { id: e.leader }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("h3", { children: [D(e.rid), /* @__PURE__ */ p("span", {
							className: "di-resource",
							children: [/* @__PURE__ */ f(dn, { id: "vp" }), e.vp]
						})] }), /* @__PURE__ */ f("p", { children: X(e.leader, t) })] })]
					}),
					/* @__PURE__ */ f("div", {
						className: "di-opponent-resources",
						children: [
							"solari",
							"spice",
							"water",
							"persuasion"
						].map((t) => /* @__PURE__ */ f(En, {
							resource: t,
							n: e[t]
						}, t))
					}),
					/* @__PURE__ */ f("div", {
						className: "di-opponent-units",
						children: [
							"agent",
							"troop",
							...n.config.ix ? ["dread"] : [],
							"sword"
						].map((n) => /* @__PURE__ */ p("span", {
							title: t(`games.duneimperium.resources.${n}`),
							children: [/* @__PURE__ */ f(dn, {
								id: n,
								color: n === "sword" ? void 0 : O(e.rid)
							}), /* @__PURE__ */ f("b", { children: n === "agent" ? e.agents : n === "troop" ? e.garrison : n === "dread" ? e.dreadGarrison : e.strength })]
						}, n))
					}),
					/* @__PURE__ */ p("div", {
						className: "di-public-counts",
						children: [/* @__PURE__ */ f("span", { children: t("games.duneimperium.handCount", { n: e.handCount }) }), /* @__PURE__ */ f("span", { children: t("games.duneimperium.intrigueCount", { n: e.intrigueCount }) })]
					}),
					/* @__PURE__ */ f("div", {
						className: "di-player-factions",
						children: _.map((r) => /* @__PURE__ */ p("span", {
							title: t(tn[r]),
							children: [
								/* @__PURE__ */ f(dn, { id: r }),
								/* @__PURE__ */ f("b", { children: e.influence[r] }),
								n.alliance[r] === e.rid && /* @__PURE__ */ f(dn, {
									id: "vp",
									size: 15
								})
							]
						}, r))
					}),
					/* @__PURE__ */ p("details", {
						className: "di-personal-details",
						children: [/* @__PURE__ */ f("summary", { children: t("games.duneimperium.publicDetails") }), P(e)]
					})
				]
			}, e.rid))
		})]
	}), z = fe || v ? /* @__PURE__ */ p(Tn, {
		title: n.prompt?.owner === e.myRid ? t(n.prompt.key) : t("games.duneimperium.actionTitle"),
		close: fe ? void 0 : ce,
		children: [
			n.prompt && X(n.prompt.source, t) !== t(n.prompt.key) && /* @__PURE__ */ p("p", {
				className: "di-prompt-source",
				children: [
					X(n.prompt.source, t),
					" ",
					rn(n.prompt.source, t)
				]
			}),
			ve(T),
			!le && /* @__PURE__ */ f("p", { children: t("games.duneimperium.noChoices") })
		]
	}) : null, Ce = a ? /* @__PURE__ */ f(Tn, {
		title: "entity" in a ? X(a.entity, t) : "space" in a ? X(a.space, t) : "history" in a ? t("games.duneimperium.history") : a.title,
		close: oe,
		children: "entity" in a ? /* @__PURE__ */ p("div", {
			className: "di-inspection",
			children: [
				g[a.entity] ? /* @__PURE__ */ f("div", {
					className: "di-detail-card",
					children: /* @__PURE__ */ f(mn, { id: a.entity })
				}) : N[a.entity] ? /* @__PURE__ */ f(vn, {
					id: a.entity,
					onClick: () => {}
				}) : _e.some((e) => e.id === a.entity) ? /* @__PURE__ */ f("div", {
					className: "di-detail-portrait",
					children: /* @__PURE__ */ f(gn, {
						id: a.entity,
						full: !0
					})
				}) : null,
				/* @__PURE__ */ f("p", { children: rn(a.entity, t) }),
				g[a.entity] && /* @__PURE__ */ p(te, { children: [
					/* @__PURE__ */ f("div", {
						className: "di-card-icons",
						children: g[a.entity].icons.map((e) => /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(dn, { id: e }), t(tn[e])] }, e))
					}),
					g[a.entity].unload && /* @__PURE__ */ f("strong", { children: t("games.duneimperium.unload") }),
					g[a.entity].infiltrate && /* @__PURE__ */ f("strong", { children: t("games.duneimperium.infiltration") }),
					[
						"agent",
						"reveal",
						"acquire"
					].map((e) => ge[a.entity]?.[e]?.length ? /* @__PURE__ */ p("p", { children: [
						/* @__PURE__ */ f("b", { children: t(e === "agent" ? "games.duneimperium.agentBox" : e === "reveal" ? "games.duneimperium.revealBox" : "games.duneimperium.acquireBox") }),
						"：",
						ge[a.entity][e].map((e) => Z(e, t)).join(" · ")
					] }, e) : null)
				] }),
				Te[a.entity] && /* @__PURE__ */ p("div", {
					className: "di-conflict-detail",
					children: [/* @__PURE__ */ f("b", { children: "ⅠⅡⅢ"[Te[a.entity].level - 1] }), Te[a.entity].rewards.map((e, n) => /* @__PURE__ */ p("p", { children: [
						t("games.duneimperium.rank", { n: n + 1 }),
						"：",
						e.map((e) => Z(e, t)).join(" · ")
					] }, n))]
				}),
				ve(ye)
			]
		}) : "space" in a ? /* @__PURE__ */ p("div", {
			className: "di-inspection",
			children: [
				/* @__PURE__ */ f("div", {
					className: "di-space-detail-icon",
					children: /* @__PURE__ */ f(dn, {
						id: F[a.space].icon,
						size: 52
					})
				}),
				/* @__PURE__ */ f(Cn, { cost: Sn(n, a.space) }),
				/* @__PURE__ */ f("p", { children: F[a.space].harvest ? t("games.duneimperium.harvestAmount", { n: F[a.space].harvest + (n.bonus[a.space] ?? 0) }) : F[a.space].effects.map((e) => Z(e, t)).join(" · ") }),
				F[a.space].requires && /* @__PURE__ */ f("p", { children: t("games.duneimperium.requiresInfluence", { faction: X(F[a.space].requires, t) }) }),
				F[a.space].combat && /* @__PURE__ */ f("p", { children: t("games.duneimperium.combatSpace") }),
				!!n.agents[a.space]?.length && /* @__PURE__ */ p("p", { children: [
					t("games.duneimperium.occupied"),
					"：",
					n.agents[a.space].map(D).join(" · ")
				] }),
				be.includes(a.space) && (n.dreadControl.find((e) => e.space === a.space)?.rid ?? n.control[a.space]) && /* @__PURE__ */ f("p", { children: t("games.duneimperium.controlledBy", { name: D(n.dreadControl.find((e) => e.space === a.space)?.rid ?? n.control[a.space]) }) }),
				_.includes(F[a.space].icon) && /* @__PURE__ */ p("p", { children: [
					t("games.duneimperium.factionBonus"),
					"：",
					xe[F[a.space].icon].map((e) => Z(e, t)).join(" · ")
				] }),
				ve(T.filter((e) => e.space === a.space))
			]
		}) : "history" in a ? /* @__PURE__ */ f("ol", {
			className: "di-log",
			children: [...n.log].reverse().map((e, n) => /* @__PURE__ */ p("li", { children: [
				/* @__PURE__ */ f("b", { children: e.rid ? D(e.rid) : "" }),
				" ",
				t(e.key, { n: e.n ?? 0 }),
				" ",
				X(e.source, t)
			] }, n))
		}) : /* @__PURE__ */ p("div", {
			className: "di-inspect-grid",
			children: [a.list.map((e) => me(e)), !a.list.length && /* @__PURE__ */ f("p", { children: t("games.duneimperium.noCards") })]
		})
	}) : null;
	return /* @__PURE__ */ p(d, {
		className: "di-screen",
		banner: /* @__PURE__ */ p("div", {
			inert: !!(z || Ce),
			className: "di-status-bar",
			children: [
				/* @__PURE__ */ f("span", {
					className: "di-brand",
					children: t("games.duneimperium.name")
				}),
				/* @__PURE__ */ p("button", {
					className: "di-phase",
					onClick: se,
					title: M,
					children: [/* @__PURE__ */ f("small", { children: t("games.duneimperium.round", { n: n.round }) }), /* @__PURE__ */ f("strong", {
						"aria-live": "polite",
						children: j ? t("games.duneimperium.chooseSpace") : n.phase === "turns" && n.acting ? D(n.acting) : t(wn[n.phase] ?? "games.duneimperium.phaseTurns")
					})]
				}),
				/* @__PURE__ */ f("div", {
					className: "di-selection-slot",
					children: j && /* @__PURE__ */ p("button", {
						className: "di-selection",
						onClick: () => {
							let e = T.find((e) => e.id === "cancel");
							e && k(e.id);
						},
						title: M,
						children: [X(j.id, t), " ×"]
					})
				}),
				/* @__PURE__ */ p("nav", {
					className: "di-jump-links",
					"aria-label": t("games.duneimperium.jumpTo"),
					children: [
						/* @__PURE__ */ f("button", {
							onClick: () => pe(S.current),
							children: t("games.duneimperium.hand")
						}),
						/* @__PURE__ */ f("button", {
							onClick: () => pe(C.current),
							children: t("games.duneimperium.tabBoard")
						}),
						/* @__PURE__ */ f("button", {
							onClick: () => pe(w.current),
							children: t("games.duneimperium.tabMarket")
						})
					]
				})
			]
		}),
		overlay: z ?? Ce,
		children: [/* @__PURE__ */ f(un, {}), /* @__PURE__ */ p("div", {
			ref: re,
			inert: !!(z || Ce),
			children: [/* @__PURE__ */ f("div", {
				className: "di-players-overview",
				style: { gridTemplateColumns: `repeat(${n.players.length}, minmax(0, 1fr))` },
				children: n.players.map((e) => /* @__PURE__ */ p("button", {
					className: "di-seat",
					"data-active": n.active === e.rid || void 0,
					onClick: () => {
						e.leader && h({ entity: e.leader });
					},
					style: yn(O(e.rid)),
					children: [
						/* @__PURE__ */ f(gn, { id: e.leader }),
						/* @__PURE__ */ p("span", {
							className: "di-seat-copy",
							children: [/* @__PURE__ */ p("strong", { children: [e.rid === n.first ? "⚑ " : "", D(e.rid)] }), /* @__PURE__ */ f("small", { children: X(e.leader, t) })]
						}),
						/* @__PURE__ */ p("span", {
							className: "di-seat-score",
							children: [/* @__PURE__ */ f(dn, {
								id: "vp",
								size: 17
							}), e.vp]
						}),
						/* @__PURE__ */ f("span", {
							className: "di-seat-hand",
							children: t("games.duneimperium.handCount", { n: e.handCount })
						})
					]
				}, e.rid))
			}), /* @__PURE__ */ p("main", {
				className: "di-layout",
				children: [
					Se,
					I,
					L,
					R
				]
			})]
		})]
	});
}
//#endregion
//#region src/games/duneimperium/bot.ts
var On = {
	vp: 100,
	solari: 6,
	spice: 7,
	water: 10,
	persuasion: 4,
	sword: 6,
	draw: 10,
	intrigue: 15,
	shipment: 30,
	negotiator: 5,
	influenceStep: 60,
	influenceFlat: 22,
	influenceAny: 40,
	troop: 7,
	dread: 25,
	buy: 10,
	spiceMustFlow: 200,
	deployKeep: 0,
	swordReserve: 2,
	conflictBoost: 1,
	intrigueKeep: 2,
	foeForecast: 0,
	deployTiebreak: 1.5,
	pushRounds: 3,
	pushVp: 8,
	endgamePush: 0,
	swordmaster: 45,
	council: 28,
	harvest: 3,
	mentat: 12,
	lookaheadPlay: !0,
	planDeploy: !0,
	planCombat: !1,
	intrigueBase: 0
}, kn = (e) => ({
	solari: e.solari,
	spice: e.spice,
	water: e.water,
	vp: e.vp,
	persuasion: e.persuasion,
	sword: 0
});
function An(e, t) {
	let n = kn(e);
	return Object.entries(t).every(([e, t]) => n[e] >= t);
}
function jn(e, t, n = 0) {
	return t <= 0 ? e.foes.length + 2 : 1 + e.foes.filter((e) => e + n > t).length;
}
function Mn(e, t, n) {
	let r = (e.pub.conflict ? Te[e.pub.conflict] : null)?.rewards[n - 1];
	return !r || n === 3 && e.humans >= 4 ? 0 : r.reduce((n, r) => n + Fn(r, e, t), 0) * e.boost;
}
function Nn(e, t) {
	let n = e.condition;
	switch (n.kind) {
		case "friendship": return n.faction ? t.me.influence[n.faction] >= (n.n ?? 2) : !1;
		case "alliance": return n.faction ? t.pub.alliance[n.faction] === t.rid : !1;
		case "council": return t.me.council;
		case "techs": return t.me.techs.length >= (n.n ?? 3);
		case "emperorAgent": return P.some((e) => e.icon === "emperor" && t.pub.agents[e.id]?.includes(t.rid));
		case "bond": return t.me.played.concat(t.me.revealedCards).filter((e) => g[e.id].factions.includes("fremen")).length >= 2;
		case "bg": return t.me.played.filter((e) => g[e.id].factions.includes("beneGesserit")).length >= 2;
	}
}
function Pn(e, t, n, r) {
	if (!e) return t * r.influenceAny;
	let i = n.me.influence[e], a = Math.min(6, Math.max(0, i + t)), o = a - i;
	if (o <= 0) return 0;
	let s = o * (i === 1 || i === 3 ? r.influenceStep : i >= 6 ? 0 : r.influenceFlat), c = !n.me.npc || n.pub.players.some((e) => e.npc);
	return c && i < 2 && a >= 2 && (s += r.vp), i < 4 && a >= 4 && (s += In(xe[e], n, r), c && n.pub.alliance[e] !== n.rid && (s += r.vp)), s;
}
function Fn(e, t, n) {
	switch (e.kind) {
		case "gain": return e.n * {
			vp: n.vp,
			solari: t.me.swordmaster ? n.solari / 2 : n.solari,
			spice: n.spice,
			water: n.water,
			persuasion: n.persuasion,
			sword: t.me.combat + t.me.dreadCombat ? n.sword : 0
		}[e.resource];
		case "influence": return Pn(e.faction, e.n, t, n);
		case "troop": return Math.min(e.n, 12 - t.me.garrison - t.me.combat - t.me.negotiators) * n.troop;
		case "draw": return e.n * n.draw;
		case "intrigue": return e.n * n.intrigue;
		case "dread": return n.dread;
		case "shipment": return n.shipment * e.n;
		case "negotiator": return e.n * n.negotiator;
		case "bundle": return e.effects.reduce((e, r) => e + Fn(r, t, n), 0);
		case "if": {
			let r = Nn(e, t);
			return e.effects.reduce((e, r) => e + Fn(r, t, n), 0) * (r === null ? .7 : +!!r);
		}
		case "pay": return e.effects.reduce((e, r) => e + Fn(r, t, n), 0) - Object.entries(e.cost).reduce((e, [r, i]) => e + Fn({
			kind: "gain",
			resource: r,
			n: i
		}, t, n), 0);
		case "choice": return Math.max(0, ...e.options.map((e) => e.reduce((e, r) => e + Fn(r, t, n), 0)));
		case "trash": return 9 + (e.after?.reduce((e, r) => e + Fn(r, t, n), 0) ?? 0);
		case "discard": return -8 * e.n + (e.after?.reduce((e, r) => e + Fn(r, t, n), 0) ?? 0);
		case "deploy": return n.troop * 1.6 * Math.min(e.n, t.me.garrison);
		case "retreat": return -n.troop * Math.min(e.n, t.me.combat) + (e.after?.reduce((e, r) => e + Fn(r, t, n), 0) ?? 0);
		case "tech": return 15 + e.discount * 6;
		case "flag": return e.flag === "ambush" ? 30 : 10;
		case "special": return [
			"control",
			"mentatNext",
			"useSatellites"
		].includes(e.id) ? 80 : e.id === "recallShip" ? t.me.shipment * n.shipment : e.id === "advanceShip" ? n.shipment + 5 : e.id === "buyTech" ? 30 : 15;
	}
}
function In(e, t, n) {
	return e?.reduce((e, r) => e + Fn(r, t, n), 0) ?? 0;
}
function Ln(e, t, n, r) {
	let i = e * 2 + t * (n.me.leader === "rhomburVernius" ? 4 : 3), a = n.me.combat + n.me.dreadCombat > 0;
	return Mn(n, r, jn(n, (a ? n.me.strength : 0) + i + (!a && i > 0 ? r.swordReserve : 0), r.foeForecast)) - (e + t) * r.deployKeep + (e + t) * r.deployTiebreak;
}
function Rn(e, t, n) {
	let r = F[e];
	if (!r) return 0;
	let i = 8 + In(r.effects, t, n);
	if (_.includes(r.icon)) {
		let e = t.me.influence[r.icon];
		i += e === 1 || e === 3 ? n.influenceStep / 3 : n.influenceFlat / 3;
	}
	if (e === "swordmaster" && (i += n.swordmaster), e === "highCouncil" && (i += n.council), e === "mentat" && (i += n.mentat), r.harvest && (i += r.harvest * n.harvest + (t.pub.bonus[e] ?? 0) * n.harvest * 1.5), e === "wealth" && t.me.solari < 8 && (i += 10), e === "stillsuits" && t.me.water === 0 && (i += 14), e === "interstellarShipping" && (i += 20), e === "arrakeen" && (i += 9), e === "sellMelange") {
		let e = Math.max(2, Math.min(5, t.me.spice));
		i += [
			0,
			0,
			6,
			8,
			10,
			12
		][e] * n.solari - e * n.spice;
	}
	return i;
}
function zn(e, t, n) {
	let r = F[e];
	if (!r || r.ix && !n.pub.config.ix || r.baseOnly && n.pub.config.ix || n.pub.voice.some((t) => t.space === e && t.rid !== n.rid) || e === "highCouncil" && n.me.council || e === "swordmaster" && n.me.swordmaster || r.requires && n.me.influence[r.requires] < 2 || n.me.agents < 1) return !1;
	let i = g[t]?.icons ?? [];
	if (!i.includes(r.icon) && !i.includes("any")) return !1;
	let a = n.pub.agents[e] ?? [];
	if (a.includes(n.rid)) return !1;
	let o = g[t]?.infiltrate && i.includes(r.icon) || n.me.leader === "helenaRichese";
	if (a.length && !o) return !1;
	if (e === "sellMelange") return n.me.spice >= 2;
	let s = { ...r.cost };
	return n.me.leader === "letoAtreides" && r.icon === "green" && s.solari && (s.solari = Math.max(0, s.solari - 1)), e === "heighliner" && t === "guildAccord" && (s.spice = Math.max(0, (s.spice ?? 0) - 2)), An(n.me, s);
}
function Bn(e, t, n) {
	let r = -Infinity;
	for (let i of P) zn(i.id, e, t) && (r = Math.max(r, Rn(i.id, t, n)));
	return Number.isFinite(r) ? r : (g[e]?.cost ?? 0) * n.buy / 2;
}
function Vn(e, t) {
	return (g[e]?.cost ?? 0) * t.buy * .6;
}
function Hn(e = {}) {
	let t = {
		...On,
		...e
	};
	return (e, n) => {
		let r = e.private?.choices ?? [], i = e.public, a = i.players.find((e) => e.rid === n.rid);
		if (!r.length || !a) return null;
		let o = {
			rid: n.rid,
			pub: i,
			me: a,
			foes: i.players.filter((e) => e.rid !== n.rid).map((e) => e.strength),
			humans: i.players.filter((e) => !e.npc).length,
			boost: t.conflictBoost * (i.conflictCount <= t.pushRounds ? 1 + t.endgamePush : 1) * (a.vp >= t.pushVp ? 1 + t.endgamePush : 1)
		}, s = typeof n.memory == "object" && n.memory ? n.memory : { count: typeof n.memory == "number" ? n.memory : 0 }, c = (e) => {
			if (e.id === "cancel") return -1e4;
			if (e.id === "decision:no") return -20;
			if (e.id === "deploy" && s.last === "decision:0:0") return -1;
			if (e.key === "games.duneimperium.deployUnits") return t.planDeploy ? Ln(Number(e.params?.troops ?? 0), Number(e.params?.dreads ?? 0), o, t) : Number(e.params?.troops ?? 0) * 8 + Number(e.params?.dreads ?? 0) * 13 + In(e.preview, o, t);
			if (e.key === "games.duneimperium.retreatUnits") {
				let n = Number(e.params?.troops ?? 0), r = Number(e.params?.dreads ?? 0);
				return -(n * 8 + r * 13) + In(e.preview, o, t);
			}
			if (e.key === "games.duneimperium.trashCard" && e.card) return -Vn(e.card.id, t) + In(e.preview, o, t);
			if (e.key === "games.duneimperium.discardCards") return -(typeof e.params?.cards == "string" ? e.params.cards.split(",") : e.card ? [e.card.id] : []).reduce((e, n) => e + Vn(n, t), 0) + In(e.preview, o, t);
			if (e.key === "games.duneimperium.acquireCard" || e.key === "games.duneimperium.takeFreeCard") return (g[e.card?.id ?? ""]?.cost ?? 0) * t.buy;
			if (e.key === "games.duneimperium.buyTech" && e.target) return (N[e.target]?.cost ?? 0) * t.buy - Number(e.params?.n ?? 0) * (e.params?.currency === "solari" ? t.solari : t.spice);
			if (e.key === "games.duneimperium.negotiatorsChoice") return Number(e.n ?? 0) * t.negotiator;
			if (e.target && e.target in a.influence && e.key === "games.duneimperium.factionChoice") return In(e.preview, o, t) + Fn({
				kind: "influence",
				faction: e.target,
				n: 1
			}, o, t);
			switch (e.group) {
				case "effect": return 1e4 + In(e.preview, o, t);
				case "space": return (e.value ?? 0) + In(F[e.space]?.effects, o, t);
				case "play": return t.lookaheadPlay ? Bn(e.card.id, o, t) : 10 + (e.card?.id === "seekAllies" ? 5 : 0);
				case "buy": return (g[e.card?.id ?? ""]?.cost ?? 0) * t.buy + (e.card?.id === "theSpiceMustFlow" ? t.spiceMustFlow : 0);
				case "intrigue": {
					let n = t.intrigueBase + In(e.preview, o, t);
					if (e.source === "combat") {
						let r = (e.preview ?? []).reduce((e, t) => e + (t.kind === "gain" && t.resource === "sword" ? t.n : t.kind === "deploy" ? t.n * 2 : 0), 0);
						return r > 0 ? n - t.intrigueKeep + Math.max(0, Mn(o, t, jn(o, a.strength + r)) - Mn(o, t, jn(o, a.strength))) : n - t.intrigueKeep;
					}
					return n - t.intrigueKeep;
				}
				case "tech": return 20 + In(e.preview, o, t);
			}
			if (e.id === "deploy") {
				if (!t.planDeploy) return 12;
				let e = Math.min(2, a.garrison + a.dreadGarrison), n = Ln(0, 0, o, t), r = -Infinity;
				for (let n = 0; n <= Math.min(e, a.garrison); n++) for (let i = 0; i <= Math.min(e - n, a.dreadGarrison); i++) r = Math.max(r, Ln(n, i, o, t));
				return r - n > .5 ? r - n : -1;
			}
			if (e.id === "reveal") return e.value ?? 0;
			if (e.id === "combatPass") {
				if (!t.planCombat) return e.value ?? 0;
				let n = jn(o, a.strength);
				return Mn(o, t, n) * (n === 1 ? .85 : .7);
			}
			return e.id === "endDone" ? -10 : e.group === "decision" ? In(e.preview, o, t) : e.value ?? 0;
		}, l = s.count;
		if (n.difficulty === "weak") {
			let t = `${l}:${i.round}:${i.phase}:${i.mode}:${i.log.length}:${e.private?.hand.map((e) => e.uid).join(",")}`, n = r.map((e) => ({
				m: e,
				value: Un(t + e.id) % 35 + (e.id === "cancel" ? -1e4 : 0)
			})).sort((e, t) => t.value - e.value)[0];
			return {
				action: {
					type: "act",
					id: n.m.id
				},
				memory: {
					count: l + 1,
					last: n.m.id
				}
			};
		}
		let ee = r.map((e) => ({
			m: e,
			value: c(e) + Un(e.id) % 100 / 1e3
		})).sort((e, t) => t.value - e.value)[0].m;
		return {
			action: {
				type: "act",
				id: ee.id
			},
			memory: {
				count: l + 1,
				last: ee.id
			}
		};
	};
}
function Un(e) {
	let t = 2166136261;
	for (let n of e) t = Math.imul(t ^ n.charCodeAt(0), 16777619);
	return t >>> 0;
}
var Wn = Hn(), Gn = (e, t, n) => {
	let r = e.type === "act" ? t.private?.choices.find((t) => t.id === e.id) : void 0;
	return r ? an(r, n) : n("games.duneimperium.resolving");
};
//#endregion
//#region src/games/duneimperium/endgame-review.tsx
function Kn({ board: e, renderResult: t, ...n }) {
	let i = l(), [c, ee] = s(!0), [u, d] = s(null), te = o(null), ne = o(null), ae = o(null);
	r(() => {
		if (!u) return;
		ae.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => d(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let h = (e) => {
		d(null), ee(e), requestAnimationFrame(() => (e ? te : ne).current?.focus({ preventScroll: !0 }));
	}, oe = a(() => ({
		onPlayAgain: n.onPlayAgain && (() => d({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => d({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => d({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), se = {
		...n,
		...oe
	};
	return /* @__PURE__ */ p("div", {
		className: "duneimperium-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ f("div", {
				className: "duneimperium-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ f("div", {
				className: "duneimperium-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ p("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), h(!1));
					},
					className: "duneimperium-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ p("header", {
							className: "duneimperium-endgame-heading",
							children: [/* @__PURE__ */ p("div", {
								className: "duneimperium-endgame-brand",
								children: [/* @__PURE__ */ f("span", {
									"aria-hidden": "true",
									children: qt.icon
								}), i(qt.nameKey)]
							}), /* @__PURE__ */ f("button", {
								type: "button",
								ref: te,
								className: "btn-quiet",
								"aria-label": i("games.duneimperium.reviewHide"),
								title: i("games.duneimperium.reviewHide"),
								onClick: () => h(!1),
								children: /* @__PURE__ */ f(re, { size: 19 })
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "duneimperium-endgame-result",
							inert: u !== null,
							children: t(se)
						}),
						u && /* @__PURE__ */ p("div", {
							className: "duneimperium-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || d(null);
							},
							children: [/* @__PURE__ */ f("button", {
								type: "button",
								ref: ae,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									d(null), e();
								},
								children: i(u.label === "again" ? "games.duneimperium.reviewConfirmAgain" : "games.duneimperium.reviewConfirmLobby")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									d(null), te.current?.focus({ preventScroll: !0 });
								},
								children: i("games.duneimperium.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "duneimperium-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base",
					ref: ne,
					onClick: () => h(!0),
					children: [
						/* @__PURE__ */ f(ie, { size: 18 }),
						i("games.duneimperium.reviewShow"),
						/* @__PURE__ */ f(m, { size: 18 })
					]
				})
			})
		]
	});
}
function qn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: ee, renderRowExtra: u, summary: d, navigation: m, content: ie, afterRanking: oe, scoreUnit: se, rankOf: ce }) {
	let g = l(), _ = c((e) => e.locale), [v, y] = s({}), b = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? ae(n, _) : e;
	}, x = (t, n) => ce?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), S = e.ranking.some((t) => e.scores?.[t] !== void 0), C = (t, n) => /* @__PURE__ */ p("div", {
		className: "duneimperium-score-identity",
		children: [
			/* @__PURE__ */ p("span", {
				className: "duneimperium-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ f("span", {
					"aria-label": g("games.duneimperium.reviewWinner"),
					children: "♛ "
				}), S && x(t, n)]
			}),
			/* @__PURE__ */ p("span", {
				className: "duneimperium-score-name",
				children: [b(t), t === r && /* @__PURE__ */ f("small", { children: g("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ p("small", {
				className: "duneimperium-score-autopilot",
				children: [
					/* @__PURE__ */ f(ne, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), w = (t) => e.ranking.map((n) => /* @__PURE__ */ f("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ p("div", {
		className: "duneimperium-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ f(h, {}),
			m,
			/* @__PURE__ */ p("div", {
				className: "duneimperium-score-body",
				children: [
					d && /* @__PURE__ */ f("div", {
						className: "duneimperium-score-summary",
						children: d
					}),
					i !== void 0 && /* @__PURE__ */ f("p", {
						className: "duneimperium-score-hints",
						children: g("session.hint.usedCount", { n: i })
					}),
					ie ?? (ee?.length ? /* @__PURE__ */ f("div", {
						className: "duneimperium-score-table-scroll",
						children: /* @__PURE__ */ p("table", {
							className: "duneimperium-score-table",
							"aria-label": g(qt.nameKey),
							children: [
								/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { scope: "col" }), /* @__PURE__ */ f(te, { children: e.ranking.map((t, n) => /* @__PURE__ */ f("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: C(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ f("tbody", { children: ee.map((e, t) => /* @__PURE__ */ p(n, { children: [/* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ p("button", {
										type: "button",
										"aria-expanded": !!v[t],
										onClick: () => y((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ f(re, { size: 15 }), e.label]
									}) : e.label
								}), w(e)] }), v[t] && e.details?.map((e, t) => /* @__PURE__ */ p("tr", {
									className: "duneimperium-score-sub",
									children: [/* @__PURE__ */ f("th", {
										scope: "row",
										children: e.label
									}), w(e)]
								}, t))] }, t)) }),
								S && /* @__PURE__ */ f("tfoot", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: g("games.duneimperium.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ f("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ f("ol", {
						className: "duneimperium-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ p("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ p("div", {
								className: "duneimperium-score-rankline",
								children: [C(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ p("strong", {
									className: "duneimperium-score-points",
									children: [e.scores[t], se && /* @__PURE__ */ f("small", { children: se })]
								})]
							}), u?.(t)]
						}, t))
					})),
					oe,
					!!ee?.length && u && /* @__PURE__ */ f("div", {
						className: "duneimperium-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: b(e) }), u(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ p("footer", {
				className: "duneimperium-score-actions",
				children: [
					o && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: g("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: g("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ f("p", { children: g("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/duneimperium/game-over.tsx
function Jn(e) {
	let t = l(), n = e.public, r = n.players.filter((e) => e.npc), i = [...e.members.map((e) => {
		let n = r.findIndex((t) => t.rid === e.rid);
		return n < 0 ? e : {
			...e,
			name: t("games.duneimperium.npc", { n: n + 1 })
		};
	}), ...r.filter((t) => !e.members.some((e) => e.rid === t.rid)).map((n) => ({
		...e.members[0],
		rid: n.rid,
		name: t("games.duneimperium.npc", { n: r.indexOf(n) + 1 })
	}))];
	return /* @__PURE__ */ f(qn, {
		...e,
		members: i,
		renderRowExtra: (e) => {
			let r = n.players.find((t) => t.rid === e);
			return r && /* @__PURE__ */ p("div", {
				className: "duneimperium-result-resources",
				children: [/* @__PURE__ */ f("strong", { children: X(r.leader, t) }), /* @__PURE__ */ p("span", { children: [
					"⬢ ",
					r.spice,
					" · ◉ ",
					r.solari,
					" · 💧 ",
					r.water
				] })]
			});
		}
	});
}
function Yn(e) {
	return /* @__PURE__ */ f(Kn, {
		...e,
		board: /* @__PURE__ */ f(Dn, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ f(Jn, { ...e })
	});
}
//#endregion
//#region src/games/duneimperium/options.tsx
var Xn = {
	mercenary: "games.duneimperium.mercenary",
	veteran: "games.duneimperium.veteran",
	expert: "games.duneimperium.expert",
	expertPlus: "games.duneimperium.expertPlus"
};
function Zn({ value: e, onChange: t }) {
	let n = l(), r = Jt.safeParse(e), i = r.success ? r.data : Jt.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ f(ce, {
				label: n("games.duneimperium.optIx"),
				checked: i.ix,
				accent: qt.accent,
				onChange: () => t({
					...i,
					ix: !i.ix
				})
			}),
			/* @__PURE__ */ f(ce, {
				label: n("games.duneimperium.optEpic"),
				checked: i.epic,
				accent: qt.accent,
				onChange: () => t({
					...i,
					epic: !i.epic
				})
			}),
			/* @__PURE__ */ f(se, {
				title: n("games.duneimperium.optDifficulty"),
				children: Object.keys(Xn).map((e) => /* @__PURE__ */ f(oe, {
					name: "dune-difficulty",
					value: e,
					checked: i.difficulty === e,
					label: n(Xn[e]),
					accent: qt.accent,
					onChange: () => t({
						...i,
						difficulty: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/duneimperium/entry.tsx
var Qn = {
	definition: en,
	View: Dn,
	bot: Wn,
	describe: Gn,
	OverView: Yn,
	Options: Zn,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			leaders: {
				vladimirHarkonnen: {
					name: "弗拉基米尔·哈克南男爵",
					text: "开局秘密选择两个不同派系。一次回合部署至少4支军队时，揭示并获得这两个派系各1影响力，每局一次。印戒：可支付1宇宙索抽1张密谋牌。"
				},
				glossuRabban: {
					name: "“野兽”拉班·哈克南",
					text: "开局额外获得1香料和1宇宙索。印戒：征兵1次；若持有联盟标记，改为征兵2次。"
				},
				ilbanRichese: {
					name: "伊尔班·里切斯伯爵",
					text: "支付版图位置印刷费用中的宇宙索后，抽1张牌。印戒：获得1宇宙索。"
				},
				helenaRichese: {
					name: "海伦娜·里切斯",
					text: "敌方特使不阻挡你的兰兹拉德和城市位置。印戒：移出并补充一张帝国牌；仅你能在本轮揭示回合以少1招募点数获得它，未获得则移出游戏。"
				},
				letoAtreides: {
					name: "雷托·厄崔迪公爵",
					text: "前往兰兹拉德位置时少支付1宇宙索。印戒：可支付1香料，在影响力低于某位对手的派系获得1影响力。"
				},
				paulAtreides: {
					name: "保罗·厄崔迪",
					text: "随时可以查看自己的牌库顶牌；牌库空时不重洗。印戒：抽1张牌。"
				},
				arianaThorvald: {
					name: "阿里亚娜·索瓦尔德伯爵夫人",
					text: "从造物主位置收获香料时，少获得1香料，抽1张牌。印戒：获得1水资源。"
				},
				memnonThorvald: {
					name: "梅农·索瓦尔德伯爵",
					text: "取得最高委员会席位时，获得1任意派系影响力。印戒：获得1香料。"
				},
				armandEcaz: {
					name: "阿曼德·伊卡兹大公",
					text: "揭示时，若在兰兹拉德、城市和香料贸易位置合计有至少两名特使，可销毁1张已打出的牌。印戒：可免费获得一张费用不超过3的帝国牌。"
				},
				ilesaEcaz: {
					name: "伊莱莎·伊卡兹",
					text: "每轮开始，将1张手牌放在一旁。第二个回合开始收回并揭示该牌，若本回合用它派遣特使：仅有1个特使图标则获得1香料，否则获得1宇宙索。印戒：可支付1宇宙索获得空间折叠牌。"
				},
				rhomburVernius: {
					name: "龙伯·韦尔尼厄斯王子",
					text: "你的无畏舰战力为4。印戒：可获得1块技术板块；若不获得，可放置1名中间人。"
				},
				tessiaVernius: {
					name: "泰西亚·韦尔尼厄斯",
					text: "首次到达每个派系的2影响力时收回该派系探子。第1个：弃1手牌换1香料；第2个：获得该派系4级奖励；第3个：该派系影响力1；第4个：奖励与影响力各一次。印戒：可失去某派系1影响力，在仍有探子的派系获得1影响力。"
				},
				yunaMoritani: {
					name: "“公主”尤娜·莫里特尼",
					text: "开局没有水资源。在自己的回合中每次获得宇宙索时额外获得1宇宙索。印戒：可支付7宇宙索，获得1任意派系影响力，征兵1次并获得1香料。"
				},
				hundroMoritani: {
					name: "翁得罗·莫里特尼子爵",
					text: "开局查看密谋牌库顶两张，保留一张，另一张放回顶部。印戒：可支付1香料获得1运输舰图标。"
				}
			},
			intrigues: {
				bribery: {
					name: "贿赂",
					text: "支付2宇宙索，获得1任意派系影响力。"
				},
				refocus: {
					name: "重新专注",
					text: "将弃牌堆洗入牌库，抽1张牌。"
				},
				ambush: {
					name: "埋伏",
					text: "获得4剑刃。"
				},
				alliedArmada: {
					name: "联合舰队",
					text: "若持有联盟标记，支付2香料获得7剑刃。"
				},
				favoredSubject: {
					name: "宠臣",
					text: "获得1皇帝影响力。"
				},
				demandRespect: {
					name: "树立威信",
					text: "赢得冲突后：获得1任意派系影响力，或支付2香料获得同一派系2影响力。"
				},
				poisonSnooper: {
					name: "毒物探测器",
					text: "查看牌库顶牌，选择抽取或销毁它；牌库空时不重洗。"
				},
				guildAuthorization: {
					name: "公会授权",
					text: "获得1宇航公会影响力。"
				},
				dispatchAnEnvoy: {
					name: "派遣特使",
					text: "本回合派遣特使所用的卡牌额外具有四个派系图标。"
				},
				infiltrate: {
					name: "渗透",
					text: "本回合敌方特使不阻挡你的特使。"
				},
				knowTheirWays: {
					name: "知晓其道",
					text: "获得1弗雷曼影响力。"
				},
				masterTactician: {
					name: "战术大师",
					text: "选择获得3剑刃，或撤回至多3支军队。"
				},
				plansWithinPlans: {
					name: "谋中谋",
					text: "终局：三个派系影响力至少为3时获得1胜利点数；四个派系均满足时改为2点。"
				},
				privateArmy: {
					name: "私人军队",
					text: "支付2香料，获得5剑刃。"
				},
				doubleCross: {
					name: "背叛",
					text: "支付1宇宙索，一位对手失去战场上的1支军队，你从供应区部署1支军队。"
				},
				councilorsDispensation: {
					name: "议员特权",
					text: "若已取得最高委员会席位，获得2香料。"
				},
				cornerTheMarket: {
					name: "垄断市场",
					text: "终局：持有至少两张香料永流传时获得1胜利点数；持有数量超过每位对手时再获得1点。"
				},
				charisma: {
					name: "魅力",
					text: "本轮揭示回合获得2招募点数。"
				},
				calculatedHire: {
					name: "精准雇佣",
					text: "支付1香料，拿取版图位置上的门泰特。"
				},
				choamShares: {
					name: "宇联商会股份",
					text: "支付7宇宙索，获得1胜利点数。"
				},
				bypassProtocol: {
					name: "绕过规程",
					text: "免费获得一张费用不超过3的帝国牌；或支付2香料，获得一张费用不超过5的帝国牌并放在牌库顶。"
				},
				recruitmentMission: {
					name: "征募任务",
					text: "本轮揭示回合获得1招募点数，且该回合获得的牌可放到牌库顶。"
				},
				reinforcements: {
					name: "援军",
					text: "支付3宇宙索，征兵3次；若在揭示回合，可部署这些新兵。"
				},
				binduSuspension: {
					name: "宾度歇止",
					text: "仅在回合开始时：抽1张牌，可跳过本回合。"
				},
				secretOfTheSisterhood: {
					name: "姐妹会的秘密",
					text: "获得1贝尼·杰瑟里特影响力。"
				},
				rapidMobilization: {
					name: "快速动员",
					text: "可从军营部署任意数量的军队。"
				},
				stagedIncident: {
					name: "策划事端",
					text: "失去战场上的3支军队，获得1胜利点数。"
				},
				theSleeperMustAwaken: {
					name: "沉睡者必将觉醒",
					text: "支付4香料，获得1胜利点数。"
				},
				tiebreaker: {
					name: "破平者",
					text: "战斗：获得2剑刃；或终局：获得10香料。"
				},
				toTheVictor: {
					name: "致胜利者",
					text: "赢得冲突后：获得3香料。"
				},
				waterPeddlersUnion: {
					name: "卖水人联盟",
					text: "获得1水资源。"
				},
				windfall: {
					name: "横财",
					text: "获得2宇宙索。"
				},
				waterOfLife: {
					name: "生命之水",
					text: "支付1水资源和1香料，抽3张牌。"
				},
				urgentMission: {
					name: "紧急任务",
					text: "召回版图上的一名己方特使，本轮可再次使用。"
				},
				diversion: {
					name: "转移注意",
					text: "仅在本回合已部署至少4个战斗单位时：获得1运输舰图标。"
				},
				warChest: {
					name: "战争金库",
					text: "战斗：支付2宇宙索获得4剑刃；或终局：持有至少10宇宙索时获得1胜利点数。"
				},
				advancedWeaponry: {
					name: "先进武器",
					text: "密谋：支付3宇宙索雇佣1艘无畏舰；或战斗：持有至少3块技术板块时获得4剑刃。"
				},
				secretForces: {
					name: "秘密部队",
					text: "若已取得最高委员会席位，征兵2次。"
				},
				grandConspiracy: {
					name: "大阴谋",
					text: "终局条件：两艘无畏舰；至少一张香料永流传；至少两个派系影响力为4或以上；最高委员会席位。满足三项获得1胜利点数，四项获得2点。"
				},
				cull: {
					name: "淘汰",
					text: "支付1宇宙索，销毁1张牌。"
				},
				strategicPush: {
					name: "战略推进",
					text: "获得2剑刃；若赢得本次冲突，获得2宇宙索。"
				},
				blackmail: {
					name: "勒索",
					text: "失去某派系1影响力，获得5剑刃。"
				},
				machineCulture: {
					name: "机械文化",
					text: "密谋：可获得1块技术板块；或终局：持有至少3块技术板块时获得1胜利点数。"
				},
				cannonTurrets: {
					name: "炮塔",
					text: "获得2剑刃；每位对手撤回1艘无畏舰。"
				},
				expedite: {
					name: "加急运输",
					text: "支付1香料，获得1运输舰图标。"
				},
				ixianProbe: {
					name: "伊克斯探针",
					text: "弃置2张手牌，抽2张牌。"
				},
				secondWave: {
					name: "卷土重来",
					text: "获得2剑刃，可从军营部署至多2个战斗单位。"
				},
				glimpseThePath: {
					name: "窥见道路",
					text: "支付1香料，获得1水资源并抽1张牌。"
				},
				finesse: {
					name: "巧计",
					text: "密谋：失去某派系1影响力，在任意派系获得1影响力；或战斗：获得2剑刃。"
				},
				strongarm: {
					name: "强权",
					text: "失去1支军队，在本回合派遣特使所到的派系获得1影响力。"
				},
				quidProQuo: {
					name: "利益交换",
					text: "支付2香料，在至少有一名己方特使的每个派系获得1影响力。"
				}
			},
			techs: {
				windtraps: {
					name: "风阱",
					text: "获得时：获得1水资源。赢得冲突时，获得1水资源。"
				},
				detonationDevices: {
					name: "自爆装置",
					text: "使用无畏舰赢得冲突时，可将一艘战场无畏舰放回供应区获得1胜利点数，替代控制地点。"
				},
				memocorders: {
					name: "记忆记录器",
					text: "获得时：获得1任意派系影响力。终局：四个派系影响力均至少为3时，获得1胜利点数。"
				},
				flagship: {
					name: "旗舰",
					text: "获得时：获得1胜利点数。每轮一次，可支付4宇宙索征兵3次。"
				},
				spaceport: {
					name: "太空港",
					text: "获得时：抽2张牌。获得卡牌时，可将其放到牌库顶。"
				},
				artillery: {
					name: "火炮",
					text: "揭示回合中，每张实际提供剑刃的揭示牌额外提供1剑刃。"
				},
				holoprojectors: {
					name: "全息投影仪",
					text: "每轮一次，可弃置1张手牌，抽1张牌。"
				},
				restrictedOrdnance: {
					name: "弹药制约",
					text: "揭示时，若有最高委员会席位，获得4剑刃。"
				},
				shuttleFleet: {
					name: "穿梭机队",
					text: "获得时：选择两个不同派系，各获得1影响力。每轮开始，获得2宇宙索。"
				},
				spySatellites: {
					name: "间谍卫星",
					text: "可支付3香料并销毁此板块，获得1胜利点数。终局：每个影响力不超过1的派系提供1胜利点数。"
				},
				disposalFacility: {
					name: "处置设施",
					text: "获得时：可销毁1张牌。揭示回合中，拥有至少6招募点数时，可销毁1张已打出的牌。"
				},
				chaumurky: {
					name: "乔穆毒药",
					text: "获得时：抽2张密谋牌。终局胜利点数平手时，你赢得破平。"
				},
				sonicSnoopers: {
					name: "声波探测器",
					text: "获得时：抽1张密谋牌。可销毁此板块，将任意数量的密谋牌放回密谋牌库底，再抽取等量密谋牌。"
				},
				trainingDrones: {
					name: "训练无人机",
					text: "每轮一次，可征兵1次。"
				},
				troopTransports: {
					name: "部队运输",
					text: "从运输记录条征兵时额外征兵1次，可将这些新兵部署进冲突区域。"
				},
				holtzmanEngine: {
					name: "霍兹曼引擎",
					text: "每轮开始多抽1张牌。终局持有至少两张香料永流传时，获得1胜利点数。"
				},
				minimicFilm: {
					name: "微缩胶片",
					text: "每个揭示回合获得1招募点数。"
				},
				invasionShips: {
					name: "侵入船",
					text: "获得时：征兵4次。每轮一次，可弃置1张手牌，本回合无视敌方特使阻挡。"
				}
			},
			spaces: {
				conspire: "共谋",
				wealth: "财富",
				heighliner: "远航机",
				foldspace: "空间折叠",
				selectiveBreeding: "育种计划",
				secrets: "秘密",
				hardyWarriors: "善战勇士",
				stillsuits: "蒸馏服",
				highCouncil: "最高委员会",
				mentat: "门泰特",
				swordmaster: "剑术大师",
				rallyTroops: "部队集结",
				hallOfOratory: "辩论厅",
				secureContract: "缔约",
				sellMelange: "出售美琅脂",
				arrakeen: "厄拉奇恩",
				carthag: "迦太格城",
				researchStation: "研究站",
				sietchTabr: "泰布穴地",
				imperialBasin: "帝国盆地",
				haggaBasin: "哈戈盆地",
				theGreatFlat: "大平原",
				smuggling: "走私",
				interstellarShipping: "星际运输",
				techNegotiation: "技术交流",
				dreadnought: "无畏舰"
			},
			conflicts: {
				skirmishA: "小规模冲突Ⅰ",
				skirmishB: "小规模冲突Ⅱ",
				skirmishC: "小规模冲突Ⅲ",
				skirmishD: "小规模冲突Ⅳ",
				skirmishE: "小规模冲突Ⅴ",
				skirmishF: "小规模冲突Ⅵ",
				desertPower: "沙漠力量",
				raidStockpiles: "突袭储备",
				cloakAndDagger: "暗中行动",
				machinations: "权谋",
				sortThroughTheChaos: "乱中求序",
				terriblePurpose: "可怕的使命",
				guildBankRaid: "突袭公会银行",
				siegeOfArrakeen: "厄拉奇恩之围",
				siegeOfCarthag: "迦太格城之围",
				secureImperialBasin: "控制帝国盆地",
				tradeMonopoly: "贸易垄断",
				battleForImperialBasin: "帝国盆地之战",
				grandVision: "宏大愿景",
				battleForCarthag: "迦太格城之战",
				battleForArrakeen: "厄拉奇恩之战",
				economicSupremacy: "经济霸权"
			},
			cards: {
				duneTheDesertPlanet: {
					name: "沙漠星球厄拉科斯",
					text: "特使：无。揭示：获得1招募点数。"
				},
				seekAllies: {
					name: "寻找盟友",
					text: "特使：销毁此牌。"
				},
				signetRing: {
					name: "印戒",
					text: "特使：执行领袖的印戒能力。揭示：获得1招募点数。"
				},
				diplomacy: {
					name: "外交",
					text: "揭示：获得1招募点数。"
				},
				reconnaissance: {
					name: "侦察",
					text: "揭示：获得1招募点数。"
				},
				convincingArgument: {
					name: "有力论据",
					text: "揭示：获得2招募点数。"
				},
				dagger: {
					name: "匕首",
					text: "揭示：获得1剑刃。"
				},
				controlTheSpice: {
					name: "控制香料",
					text: "特使：可支付1香料，销毁1张牌并征兵1次。揭示：获得1招募点数和1香料。"
				},
				arrakisLiaison: {
					name: "厄拉科斯使团",
					text: "揭示：获得2招募点数。"
				},
				foldspace: {
					name: "空间折叠",
					text: "特使：抽1张牌，销毁此牌。"
				},
				theSpiceMustFlow: {
					name: "香料永流传",
					text: "获得时：获得1胜利点数。揭示：获得1香料。"
				},
				sardaukarLegion: {
					name: "萨多卡军团",
					text: "特使：征兵2次。揭示：获得1招募点数，可从军营部署至多3支军队。"
				},
				drYueh: {
					name: "岳医生",
					text: "特使：抽1张牌。揭示：获得1招募点数。"
				},
				assassinationMission: {
					name: "暗杀任务",
					text: "揭示：获得1宇宙索和1剑刃。此牌被销毁时，获得4宇宙索。"
				},
				sardaukarInfantry: {
					name: "萨多卡步兵",
					text: "揭示：获得1招募点数和2剑刃。"
				},
				beneGesseritInitiate: {
					name: "贝尼·杰瑟里特学徒",
					text: "特使：抽1张牌。揭示：获得1招募点数。"
				},
				guildAdministrator: {
					name: "公会管理员",
					text: "特使：可销毁1张牌。揭示：获得1招募点数。"
				},
				theVoice: {
					name: "音言",
					text: "获得时：选择一个版图位置，对手不能派遣特使到该位置，直到你的下个回合开始。揭示：获得2招募点数。"
				},
				scout: {
					name: "斥候",
					text: "揭示：获得1招募点数和1剑刃，可撤回至多2支军队。"
				},
				imperialSpy: {
					name: "帝国间谍",
					text: "特使：可销毁此牌，抽1张密谋牌。揭示：获得1招募点数和1剑刃。"
				},
				beneGesseritSister: {
					name: "贝尼·杰瑟里特姐妹",
					text: "揭示：选择获得2招募点数或2剑刃。"
				},
				missionariaProtectiva: {
					name: "传教使团",
					text: "特使：若已打出另一张贝尼·杰瑟里特牌，获得1任意派系影响力。揭示：获得1招募点数。"
				},
				spiceHunter: {
					name: "香料猎人",
					text: "揭示：获得1招募点数和1剑刃；有另一张弗雷曼牌时，另获得1香料。"
				},
				spiceSmugglers: {
					name: "香料走私者",
					text: "特使：可支付2香料，获得1宇航公会影响力和3宇宙索。揭示：获得1招募点数和1剑刃。"
				},
				fedaykinDeathCommando: {
					name: "敢死队突击兵",
					text: "特使：可销毁1张牌。揭示：获得1招募点数；有另一张弗雷曼牌时，获得3剑刃。"
				},
				geneManipulation: {
					name: "基因操纵",
					text: "特使：可销毁1张牌；若已打出另一张贝尼·杰瑟里特牌，获得2香料。揭示：获得2招募点数。"
				},
				guildBankers: {
					name: "公会银行家",
					text: "揭示：本回合获得的每张香料永流传少支付3招募点数。"
				},
				choamDirectorship: {
					name: "宇联商会董事",
					text: "获得时：获得四个派系各1影响力。揭示：获得3宇宙索。"
				},
				crysknife: {
					name: "晶牙匕",
					text: "特使：获得1宇宙索。揭示：获得1剑刃；有另一张弗雷曼牌时，获得1弗雷曼影响力。"
				},
				chani: {
					name: "契妮",
					text: "获得时：获得1水资源。揭示：获得2招募点数，可撤回任意数量的军队。"
				},
				spaceTravel: {
					name: "太空旅行",
					text: "特使：抽1张牌。揭示：获得2招募点数。"
				},
				duncanIdaho: {
					name: "邓肯·艾达荷",
					text: "特使：可支付1水资源，征兵1次并抽1张牌。揭示：获得2剑刃和1水资源。"
				},
				shiftingAllegiances: {
					name: "转移效忠",
					text: "特使：可支付2香料并失去某派系1影响力，获得另一个派系2影响力。揭示：获得2招募点数。"
				},
				kwisatzHaderach: {
					name: "魁萨茨·哈德拉克",
					text: "特使：将版图上的一名己方特使移到任意合法位置，可无视占用；抽1张牌。"
				},
				sietchReverendMother: {
					name: "穴地圣母",
					text: "特使：可销毁1张牌。揭示：获得1香料；有另一张弗雷曼牌时，获得3招募点数。"
				},
				arrakisRecruiter: {
					name: "厄拉科斯征募官",
					text: "特使：征兵1次。揭示：获得1招募点数和1剑刃。"
				},
				firmGrip: {
					name: "牢牢掌控",
					text: "特使：可支付2宇宙索，获得1宇航公会、贝尼·杰瑟里特或弗雷曼影响力。揭示：若与皇帝结盟，获得4招募点数。"
				},
				smugglersThopter: {
					name: "走私扑翼机",
					text: "特使：若宇航公会影响力至少为2，抽2张牌。揭示：获得1招募点数和1香料。"
				},
				carryall: {
					name: "运载机",
					text: "特使：本次收获的基础香料翻倍，不翻倍囤积香料。揭示：获得1招募点数和1香料。"
				},
				gunThopter: {
					name: "武装扑翼机",
					text: "特使：每位对手失去军营中的1支军队。揭示：获得3剑刃，可从军营部署1支军队。"
				},
				guildAmbassador: {
					name: "公会大使",
					text: "特使：选择获得1宇航公会影响力或2招募点数。揭示：若与宇航公会结盟，可支付3香料获得1胜利点数。"
				},
				testOfHumanity: {
					name: "戈姆刺的试炼",
					text: "特使：从左侧开始，每位对手选择弃置1张手牌或失去战场上的1支军队。揭示：获得2招募点数。"
				},
				fremenCamp: {
					name: "弗雷曼营地",
					text: "特使：可支付2香料，征兵3次。揭示：获得2招募点数和1剑刃。"
				},
				opulence: {
					name: "奢华",
					text: "特使：获得3宇宙索。揭示：获得1招募点数，可支付6宇宙索获得1胜利点数。"
				},
				ladyJessica: {
					name: "杰西卡夫人",
					text: "获得时：获得1任意派系影响力。特使：抽2张牌。揭示：获得3招募点数和1剑刃。"
				},
				stilgar: {
					name: "斯蒂尔格",
					text: "特使：获得1水资源。揭示：获得2招募点数和3剑刃。"
				},
				piterDeVries: {
					name: "彼得·德弗里斯",
					text: "特使：抽1张密谋牌。揭示：获得3招募点数和1剑刃。"
				},
				gurneyHalleck: {
					name: "哥尼·哈莱克",
					text: "特使：征兵2次，抽1张牌。揭示：获得2招募点数，可支付3宇宙索征兵2次并部署这些新兵。"
				},
				thufirHawat: {
					name: "瑟菲·哈瓦特",
					text: "特使：抽1张牌。揭示：获得1招募点数并抽1张密谋牌。"
				},
				otherMemory: {
					name: "先祖记忆",
					text: "特使：抽1张牌，或将弃牌堆中一张贝尼·杰瑟里特牌拿回手中。揭示：获得2招募点数。"
				},
				lietKynes: {
					name: "列特·凯恩斯",
					text: "获得时：获得1皇帝影响力。揭示：本轮每张已打出或揭示的弗雷曼牌提供2招募点数，包括此牌。"
				},
				wormRiders: {
					name: "沙虫骑手",
					text: "特使：获得2香料。揭示：弗雷曼影响力至少为2时获得4剑刃；与弗雷曼结盟时另获得2剑刃。"
				},
				reverendMotherMohiam: {
					name: "圣母莫希阿姆",
					text: "特使：若已打出另一张贝尼·杰瑟里特牌，每位对手按顺时针顺序弃置2张手牌。揭示：获得2招募点数和2香料。"
				},
				powerPlay: {
					name: "权力博弈",
					text: "特使：本次派往派系位置获得的影响力由1改为2，销毁此牌。"
				},
				guildChiefAdministrator: {
					name: "公会首席管理员",
					text: "特使：可弃置1张手牌，销毁1张牌。揭示：获得1招募点数和1运输舰图标。"
				},
				guildAccord: {
					name: "公会协议",
					text: "特使：前往远航机少支付2香料。揭示及卸除：获得1水资源；与宇航公会结盟时另获得3香料。"
				},
				localFence: {
					name: "本地销赃人",
					text: "特使：可支付2香料获得5宇宙索，或支付5宇宙索获得4香料。揭示：获得2招募点数。"
				},
				shaiHulud: {
					name: "夏胡鲁德",
					text: "获得时：可销毁1张牌。特使：可销毁1张牌，征兵2次。揭示：有另一张弗雷曼牌时，获得5剑刃。"
				},
				ixGuildCompact: {
					name: "伊克斯公会协约",
					text: "特使：可弃置2张手牌，获得1块技术板块。揭示及卸除：放置至多2名中间人。"
				},
				choamDelegate: {
					name: "宇联商会代表",
					text: "揭示及卸除：获得3宇宙索。"
				},
				bountyHunter: {
					name: "赏金猎人",
					text: "特使：若派往已有敌方特使的位置，获得2宇宙索。揭示：获得1招募点数和1剑刃。"
				},
				embeddedAgent: {
					name: "潜伏特工",
					text: "特使：若已打出另一张贝尼·杰瑟里特牌，获得2运输舰图标。揭示：获得1招募点数并抽1张密谋牌。"
				},
				esmarTuek: {
					name: "埃斯马·图克",
					text: "特使：可支付1香料，获得1宇航公会影响力并抽1张牌。揭示及卸除：获得2香料和2宇宙索。"
				},
				courtIntrigue: {
					name: "宫廷密谋",
					text: "特使：可将1张密谋牌放回密谋牌库底，抽1张密谋牌。揭示：获得1招募点数和1剑刃。"
				},
				sayyadina: {
					name: "虔信使女",
					text: "特使：可支付3水资源，获得1胜利点数。揭示：有另一张弗雷曼牌时，获得3招募点数。"
				},
				imperialShockTrooper: {
					name: "帝国突击兵",
					text: "揭示：获得1招募点数和2剑刃；若在皇帝位置有特使，另获得3剑刃。"
				},
				appropriate: {
					name: "合理诉求",
					text: "获得时：获得1运输舰图标。特使：皇帝影响力至少为2时，可获得1块技术板块，可用宇宙索代替香料支付。揭示：获得2招募点数。"
				},
				desertAmbush: {
					name: "沙漠伏击",
					text: "特使：本回合每部署1支军队，可令一位对手撤回1个战斗单位。揭示：获得1招募点数和1剑刃。"
				},
				inTheShadows: {
					name: "暗影之中",
					text: "特使：贝尼·杰瑟里特影响力至少为2时，可弃置1张手牌，获得1皇帝、宇航公会或弗雷曼影响力。揭示及卸除：获得1贝尼·杰瑟里特影响力。"
				},
				satelliteBan: {
					name: "卫星禁令",
					text: "特使：可弃置1张手牌，获得1香料和1水资源。揭示：获得1招募点数，可撤回至多2支军队。"
				},
				freighterFleet: {
					name: "运输舰队",
					text: "揭示及卸除：获得1运输舰图标。"
				},
				imperialBashar: {
					name: "霸撒统领",
					text: "特使：征兵1次或销毁1张牌。揭示：获得1招募点数和2剑刃；本回合每张其他实际提供剑刃的揭示牌另提供1剑刃。"
				},
				jamis: {
					name: "贾米斯",
					text: "特使：可销毁1张牌。揭示：获得1招募点数和2剑刃。"
				},
				landingRights: {
					name: "着陆许可",
					text: "特使：获得1运输舰图标。揭示：获得2招募点数。"
				},
				waterPeddler: {
					name: "卖水人",
					text: "获得时：获得1水资源。揭示及卸除：获得1水资源。"
				},
				treachery: {
					name: "背信弃义",
					text: "特使：本次派往派系位置获得的影响力由1改为2，销毁此牌。揭示及卸除：征兵2次，可部署这些新兵。"
				},
				truthsayer: {
					name: "辨言师",
					text: "特使：可弃置1张手牌，抽1张牌。揭示：获得1招募点数和1剑刃。"
				},
				spiceTrader: {
					name: "香料商人",
					text: "特使：弗雷曼影响力至少为2时，可弃置1张手牌，获得2香料。揭示：获得2招募点数和1剑刃。"
				},
				ixianEngineer: {
					name: "伊克斯工程师",
					text: "特使：可获得1块技术板块。揭示：若持有至少3块技术板块，可销毁此牌获得1胜利点数。"
				},
				webOfPower: {
					name: "权力之网",
					text: "特使：皇帝影响力至少为2时获得2宇宙索；公会至少为2时抽1张牌；弗雷曼至少为2时获得1水资源。揭示：获得1招募点数和1任意派系影响力。"
				},
				weirdingWay: {
					name: "奇异之道",
					text: "特使：本回合结束后立刻再执行一个回合。揭示：获得1招募点数和2剑刃。"
				},
				negotiatedWithdrawal: {
					name: "协商撤军",
					text: "获得时：征兵1次。揭示：获得2招募点数，可撤回3个战斗单位，获得1任意派系影响力。"
				},
				fullScaleAssault: {
					name: "全面进攻",
					text: "获得时：雇佣1艘无畏舰。特使：征兵2次。揭示：获得2招募点数；战场上每艘己方无畏舰提供3剑刃。"
				}
			},
			chooseRivalLeader: "选择哈葛尔劲敌的领袖",
			chooseReinforcements: "选择援军用于特使回合或立即开始揭示回合",
			snoopers: "尚未收回的探子",
			revealedSecrets: "已揭示的妙手派系",
			effectControl: "获得{{space}}的控制权",
			effectFreeCard: "免费获得费用不超过{{n}}的帝国牌",
			effectFreeTop: "免费获得费用不超过{{n}}的帝国牌并放在牌库顶",
			effectRevealPersuasion: "本轮揭示回合获得{{n}}招募点数",
			effectCouncil: "取得最高委员会席位",
			effectSwordmaster: "解锁剑术大师，获得第3名特使",
			effectMentat: "拿取可用的门泰特",
			effectMentatNext: "下一轮获得门泰特",
			effectFoldspace: "从储备区获得1张空间折叠牌",
			effectShippingTroops: "征兵2次；持有部队运输时另征兵1次并可部署这些新兵",
			effectStealIntrigues: "从每位持有至少4张密谋的对手手中随机拿取1张",
			effectBounty: "若该位置已有敌方特使，获得2宇宙索",
			effectGunThopter: "每位对手失去军营中的1支军队",
			effectMohiam: "每位对手弃置2张手牌",
			effectHumanity: "每位对手弃置1张手牌或失去战场上的1支军队",
			effectShift: "可支付2香料并失去1派系影响力，获得2派系影响力",
			effectFinesse: "失去某派系1影响力，获得某派系1影响力",
			effectBlackmail: "失去某派系1影响力，获得5剑刃",
			effectTessia: "可失去某派系1影响力，在仍有探子的派系获得1影响力",
			effectLiet: "本轮每张已打出或揭示的弗雷曼牌提供2招募点数",
			effectReinforcements: "征兵3次；揭示回合可部署这些新兵",
			effectRefocus: "将牌库与弃牌堆一起重洗",
			effectPeek: "查看牌库顶牌并选择抽取或销毁",
			effectCross: "一位对手失去战场上的1支军队，你从供应区部署1支军队",
			effectStaged: "失去战场上的3支军队，获得1胜利点数",
			effectCannon: "每位对手撤回1艘无畏舰",
			effectQuid: "在至少有一名己方特使的每个派系获得1影响力",
			effectStrongarm: "失去1支军队，在本回合派往的派系获得1影响力",
			effectLeto: "可支付1香料，在影响力落后于对手的派系获得1影响力",
			effectScorePlans: "按影响力满足的派系数量获得1或2胜利点数",
			effectScoreCorner: "按香料永流传的持有数量获得至多2胜利点数",
			effectScoreGrand: "按满足的条件数量获得1或2胜利点数",
			effectArrakeenSecond: "从1密谋、2香料、3宇宙索中选择两项",
			effectSonic: "销毁此板块，将任意数量密谋换成等量新牌",
			effectSatellites: "支付3香料并销毁此板块，获得1胜利点数",
			restartConfirm: "重新开始一局？",
			logTechRemoved: "移出技术板块",
			chooseDefense: "是否部署防御军队？",
			defend: "从供应区部署1支军队",
			name: "沙丘：帝国",
			desc: "派遣特使、构筑牌库，争夺厄拉科斯与帝国的影响力",
			round: "第 {{n}} 轮",
			wait: "等待{{name}}",
			resolving: "结算中",
			skip: "放弃此效果",
			confirm: "确认",
			finish: "完成",
			cancel: "取消",
			pay: "支付费用",
			choosePayment: "是否支付费用？",
			chooseEffect: "选择一个效果",
			effectOption: "选项 {{n}}",
			chooseFaction: "选择派系",
			chooseAlliance: "选择接收联盟标记的玩家",
			choosePlayer: "选择此玩家",
			factionChoice: "调整影响力",
			chooseTrash: "选择要销毁的卡牌",
			trashCard: "销毁此牌",
			chooseDiscard: "选择要弃置的手牌",
			discardCards: "弃置{{n}}张手牌",
			discardOne: "弃置1张手牌",
			chooseNegotiators: "选择中间人数量",
			negotiatorsChoice: "放置{{n}}名中间人",
			chooseTech: "选择技术板块或放弃",
			buyTech: "支付{{n}}{{currency}}并收回{{negotiators}}名中间人",
			placeNegotiator: "放置1名中间人",
			chooseShipping: "推进或召回运输舰",
			advanceShip: "推进运输舰1格",
			recallShip: "召回运输舰并领取奖励",
			chooseDeployment: "选择要部署的战斗单位",
			chooseRetreat: "选择要撤回的战斗单位",
			deployUnits: "部署{{troops}}支军队、{{dreads}}艘无畏舰",
			retreatUnits: "撤回{{troops}}支军队、{{dreads}}艘无畏舰",
			chooseTwoFactions: "选择两个不同派系",
			twoFactions: "{{from}}与{{to}}",
			chooseVoice: "选择禁止对手派遣特使的位置",
			chooseSpace: "选择此位置",
			chooseHumanity: "弃置手牌或失去军队",
			loseTroop: "失去战场上的1支军队",
			chooseOpponent: "选择对手的战斗单位",
			enemyRetreat: "令此玩家撤回1个单位",
			changeInfluence: "{{from}}失去1影响力，{{to}}获得{{n}}影响力",
			chooseMemory: "抽牌或收回弃牌",
			drawCard: "抽1张牌",
			returnCard: "拿回手中",
			choosePeek: "抽取或销毁这张牌",
			chooseBindu: "继续或跳过本回合",
			passTurn: "跳过本回合",
			chooseTroop: "选择要失去的军队",
			fromGarrison: "失去军营中的1支军队",
			fromConflict: "失去战场上的1支军队",
			chooseRecall: "选择要召回特使的位置",
			chooseAcquire: "选择要获得的卡牌或放置位置",
			acquireCard: "获得此牌",
			toDeck: "放在牌库顶",
			toDiscard: "放入弃牌堆",
			chooseIntrigueExchange: "选择要放回牌库底的密谋牌",
			returnIntrigue: "放回密谋牌库底",
			chooseReserve: "选择为自己保留的帝国牌",
			reserveCard: "保留此牌",
			chooseSecretFactions: "秘密选择两个派系",
			chooseStartingIntrigue: "选择保留的起始密谋牌",
			keepIntrigue: "保留此密谋牌",
			chooseAside: "选择本轮暂放在一旁的手牌",
			setAside: "放在一旁",
			chooseDreadControl: "选择无畏舰控制的地点",
			detonate: "放回1艘无畏舰，获得1胜利点数",
			buyCard: "支付{{n}}招募点数获得此牌",
			playIntrigue: "打出密谋牌",
			useTech: "使用技术板块",
			resolveEffect: "执行效果",
			chooseLeader: "选择领袖",
			sendAgent: "派遣特使",
			playCard: "使用此牌派遣特使",
			reveal: "揭示所有手牌",
			deploy: "部署战斗单位",
			finishTurn: "结束特使回合",
			finishReveal: "结束揭示回合",
			finishCombatTurn: "结束本次战斗出牌",
			passCombat: "跳过战斗出牌",
			finishEndgame: "完成终局计分",
			invalidAction: "此操作已不可用，请重新选择。",
			logTrashed: "销毁了卡牌",
			logAcquired: "获得了卡牌",
			logTech: "获得了技术板块",
			logPlaced: "派遣了特使",
			logRevealed: "揭示了{{n}}张牌",
			logMasterstroke: "发动了妙手",
			logRound: "第{{n}}轮开始",
			logReward: "领取第{{n}}栏冲突奖励",
			logIntrigue: "打出了密谋牌",
			optIx: "伊克斯崛起",
			optEpic: "史诗模式",
			optDifficulty: "单人劲敌难度",
			mercenary: "佣兵",
			veteran: "萨多卡",
			expert: "门泰特",
			expertPlus: "魁萨茨·哈德拉克",
			phaseLeaders: "选择领袖",
			phasePrepare: "轮次开始",
			phaseTurns: "玩家回合",
			phaseCombat: "战斗",
			phaseRewards: "冲突奖励",
			phaseVictory: "胜者收益",
			phaseMakers: "造物主",
			phaseRecall: "召回",
			phaseEndgame: "终局密谋",
			phaseDone: "游戏结束",
			agentTurn: "特使回合",
			revealTurn: "揭示回合",
			startTurn: "选择特使或揭示回合",
			hand: "手牌",
			intrigueHand: "密谋牌",
			market: "帝国牌供应区",
			reserves: "储备牌",
			playerArea: "个人区域",
			techMarket: "技术板块",
			conflictTitle: "本轮冲突",
			factionsTitle: "派系影响力",
			boardTitle: "厄拉科斯",
			landsraad: "兰兹拉德",
			spiceTrade: "香料贸易",
			cities: "城市",
			shipping: "运输记录条",
			firstPlayer: "起始玩家",
			noChoices: "当前没有需要你执行的操作。",
			noCards: "没有卡牌",
			close: "关闭",
			details: "查看详情",
			back: "返回",
			leaderAbility: "领袖能力",
			revealBox: "揭示效果",
			agentBox: "特使效果",
			acquireBox: "获得效果",
			cost: "费用{{n}}",
			unload: "卸除",
			infiltration: "渗透",
			combatSpace: "战斗位置",
			occupied: "特使",
			controlledBy: "控制：{{name}}",
			bonusSpice: "囤积香料{{n}}",
			requiresInfluence: "需要{{faction}}影响力至少为2",
			viewDiscard: "弃牌堆",
			deckCount: "牌库{{n}}张",
			intrigueCount: "密谋{{n}}张",
			supplyCount: "供应军队{{n}}支",
			aside: "暂放卡牌",
			peekTitle: "你的牌库顶牌",
			secretsTitle: "秘密派系",
			playersTitle: "玩家",
			npc: "哈葛尔劲敌{{n}}",
			score: "{{n}}胜利点数",
			winner: "{{name}}获胜",
			rank: "第{{n}}名",
			playAgain: "再来一局",
			backLobby: "返回大厅",
			waitingHost: "等待主机开始下一局",
			history: "近期记录",
			actionTitle: "当前操作",
			factionBonus: "达到4影响力的奖励",
			threshold: "胜利目标：{{n}}点",
			alliance: "联盟",
			agentIcons: "可前往的位置",
			effectGain: "获得{{n}}{{resource}}",
			effectDraw: "抽{{n}}张牌",
			effectIntrigue: "抽{{n}}张密谋牌",
			effectTroop: "征兵{{n}}次",
			effectDread: "雇佣{{n}}艘无畏舰",
			effectShipping: "获得{{n}}运输舰图标",
			effectNegotiator: "放置至多{{n}}名中间人",
			effectInfluence: "{{faction}}影响力调整{{n}}点",
			anyFaction: "任意派系",
			effectPay: "支付{{cost}}，{{effect}}",
			effectTrash: "销毁1张牌",
			effectDiscard: "弃置{{n}}张手牌",
			effectTech: "获得技术板块，折扣{{n}}",
			effectDeploy: "部署至多{{n}}个单位",
			effectRetreat: "撤回至多{{n}}个单位",
			effectChoice: "选择效果",
			effectConditional: "满足条件后：{{effect}}",
			effectCard: "执行卡牌效果",
			effectSignet: "执行印戒能力",
			effectHarvest: "收获香料",
			effectRecruitDeploy: "征兵{{n}}次，可部署这些新兵",
			effectTurn: "立刻再执行一个回合",
			effectDividend: "获得5宇宙索，对手各获得1宇宙索",
			effectTwoFactions: "两个不同派系各获得1影响力",
			effectSwords: "本回合增加剑刃效果",
			effectDiscount: "本回合香料永流传少支付{{n}}招募点数",
			techExhausted: "本轮已使用",
			tabBoard: "版图",
			tabMarket: "购牌",
			tabPlayers: "玩家",
			tabIntrigues: "密谋",
			tabLog: "记录",
			showAllActions: "全部可选操作",
			resources: {
				solari: "宇宙索",
				spice: "香料",
				water: "水资源",
				vp: "胜利点数",
				persuasion: "招募点数",
				sword: "剑刃",
				troop: "军队",
				dread: "无畏舰",
				agent: "特使",
				negotiator: "中间人",
				strength: "战力"
			},
			factions: {
				emperor: "皇帝",
				spacingGuild: "宇航公会",
				beneGesserit: "贝尼·杰瑟里特",
				fremen: "弗雷曼人",
				green: "兰兹拉德",
				blue: "城市",
				yellow: "香料贸易",
				any: "任意位置"
			},
			zoomBoard: "放大版图",
			fitBoard: "适合宽度",
			jumpTo: "区域定位",
			personalDetails: "领袖、技术与已打出卡牌",
			publicDetails: "公开个人区",
			privateDetails: "私有信息",
			playedCards: "已打出卡牌",
			revealedCards: "已揭示卡牌",
			handCount: "手牌{{n}}张",
			councilSeat: "最高委员会席位",
			ixTitle: "伊克斯",
			shippingTop: "技术折扣2",
			shippingMiddle: "征兵2次 · 影响力1",
			shippingFirst: "宇宙索5／香料2",
			shippingStart: "起点",
			intrigueDiscard: "密谋牌弃牌堆",
			tradeSpice: "支付{{n}}香料",
			harvestAmount: "收获{{n}}香料",
			boardFoldspace: "空间折叠牌",
			boardBreeding: "销毁1 → 抽2",
			boardCouncil: "每次揭示：招募+2",
			boardMentat: "临时特使",
			boardSwordmaster: "第三名特使",
			boardTech: "获得技术",
			boardNegotiation: "技术折扣1／中间人",
			rules: "目标：\n· 一轮结束时有人达到10胜利点数，或冲突牌耗尽，触发终局。\n· 结算终局密谋与技术后，胜利点数最多者获胜。\n· 平分先比较乔穆毒药，再比较香料、宇宙索、水资源和军营军队。\n· 若仍平分，最后执行揭示回合的玩家获胜。\n准备：\n· 每人获得10张起始牌、1份水资源和2名特使，并在军营中放置3支军队。\n· 四人游戏从1分开始，其他人数从0分开始。每人共有12支军队。\n· 选择领袖，按其能力调整初始资源。每轮开始翻开冲突牌并抽5张牌。\n特使回合：\n· 从起始玩家开始，按顺时针轮流执行特使回合或揭示回合。\n· 选择手牌，按其特使图标向一个合法位置派遣特使。\n· 先支付位置费用，再按自选顺序执行卡牌与位置效果。\n· 通常不能前往已有特使的位置。泰布穴地需要至少2点弗雷曼影响力。\n· 前往战斗位置时，可部署本回合新兵及军营中至多2个战斗单位。\n· 支付箭头费用的效果每次只能执行一次，且可选择不支付。\n· 密谋牌的费用与条件必须全部满足。阴谋密谋可在自己的回合打出。\n揭示回合：\n· 揭示所有剩余手牌，按自选顺序执行揭示效果，可穿插购牌。\n· 用招募点数获得帝国牌或储备牌，放入弃牌堆。购牌后立即补充供应区。\n· 先前特使回合打出的牌不再执行揭示效果。未用招募点数在本回合后失去。\n· 本回合抽取的新牌必须立即揭示；揭示回合后抽到的牌保留到下一轮。\n· 完成后清理已打出与揭示的牌，本轮不再执行回合。清理不触发卸除。\n派系：\n· 某派系的影响力达到2点时，获得1分；降至2点以下时，失去该分。每次升至4点时，获得该派系的奖励。\n· 某派系的影响力至少达到4点，且高于联盟持有者时，取得该派系的联盟标记和对应的1分。\n· 平手保留联盟。持有者降低影响力而失去联盟时，可指定并列继任者。\n战斗与奖励：\n· 每支军队提供2点战力，每艘无畏舰提供3点战力；剑刃另加战力。\n· 没有已部署的战斗单位时战力为0，且不能打出战斗密谋。\n· 从起始玩家开始，轮流打出一张或多张战斗密谋，或跳过。\n· 跳过后仍可再次出牌，所有参战玩家连续跳过才结算。\n· 按排名领取冲突奖励。普通第三名奖励仅在四人游戏发放。\n· 平局降低一档：并列第一领第二栏，并列第二领第三栏，并列第三无奖。\n· 战力为0无奖。获胜后的密谋在奖励后使用，平局不算获胜。\n· 战斗后军队返回供应区，无畏舰返回军营。\n造物主与召回：\n· 每个没有特使的香料收获位置增加1份囤积香料。\n· 未触发终局时，召回特使、轮转起始玩家，开始下一轮。\n伊克斯崛起：\n· 开局可启用扩展，替换兰兹拉德与香料贸易位置，加入新牌和技术。\n· 每个运输舰图标可推进1格，或召回并领取所在格及下方各格奖励。\n· 第一格可以选择获得2份香料，或获得5枚宇宙索并使每位对手获得1枚宇宙索。\n· 第二格可以征兵2次并获得1点影响力；第三格可以购买技术，并少支付2份香料。\n· 运输奖励可按自选顺序领取。中间人来自军队供应区；购买技术时，每收回1名中间人，可以少支付1份香料。\n· 技术从三叠顶部购买并立即补充。每轮一次的能力可在特使或揭示回合使用。\n· 持有已部署无畏舰的冲突胜者，须用一艘控制未被无畏舰占据的地点。\n· 无畏舰控制持续至下次战斗结束，期间覆盖原控制标记。\n· 渗透忽略敌方特使，不能绕过己方特使或音言。音言在使用者下回合开始移除。\n· 卸除在弃置或销毁时执行揭示效果，弃后再销毁可各触发一次。\n史诗模式：\n· 开局独立启用，胜利目标改为12分；使用5张二级与5张三级冲突。\n· 起始军营改为5支军队，抽1张密谋，并用控制香料替换1张沙漠星球厄拉科斯。\n双人游戏：\n· 加入一名哈葛尔劲敌，使用3名特使，起始军营没有军队。\n· 起始玩家每完成特使回合，劲敌行动一次；揭示回合不触发。\n· 劲敌不收集资源、不计分、不领取冲突奖励，但会争夺联盟。\n· 劲敌赢得控制地点的冲突时，移除该地点的控制标记。\n单人游戏：\n· 加入两名哈葛尔劲敌，按正常顺序轮流行动，左侧劲敌首先行动。\n· 劲敌使用领袖印戒，不使用左侧能力。派遣时只执行哈葛尔牌上的效果。\n· 到战斗位置时优先部署无畏舰，并部署新兵及至多2个驻军单位。\n· 劲敌自由选择派系时选择最低影响力派系，平手由玩家选择。\n· 劲敌每集齐3份水资源、3张密谋牌、7枚宇宙索或7份香料，立即将对应资源兑换为1分。\n· 伊克斯模式中，三级冲突前保留香料购入带哈葛尔纹章的技术。\n· 选择技术时，劲敌优先购买能够支付费用且原价最高的技术；同价时，选择位置更靠上的牌叠。没有可见的劲敌技术时，移除牌数最多的一叠的顶层技术板块。\n· 劲敌运输舰升至第二格后召回，第一格奖励固定选择宇宙索。\n· 佣兵、萨多卡、门泰特、魁萨茨·哈德拉克分别在第6、5、4、4轮获得第三名特使。\n· 佣兵劲敌军营与密谋为空，玩家额外获得1枚宇宙索和1份香料。\n· 其他难度劲敌以3支驻军和1张密谋牌开始，门泰特位置的费用改为5枚宇宙索。\n· 门泰特及更高难度的劲敌，在一、二级冲突中领先至少4点战力后停止部署。\n· 魁萨茨·哈德拉克难度禁止玩家解锁剑术大师。"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			leaders: {
				vladimirHarkonnen: {
					name: "Baron Vladimir Harkonnen",
					text: "Secretly choose 2 different Factions at setup. Once per game, after deploying at least 4 troops in one turn, reveal them and gain 1 Influence with each. Signet: you may pay 1 Solari to draw an Intrigue."
				},
				glossuRabban: {
					name: "“The Beast” Glossu Rabban",
					text: "Start with 1 extra spice and 1 extra Solari. Signet: recruit 1 troop, or 2 if you have an Alliance."
				},
				ilbanRichese: {
					name: "Count Ilban Richese",
					text: "After paying the printed Solari cost of a board space, draw a card. Signet: gain 1 Solari."
				},
				helenaRichese: {
					name: "Helena Richese",
					text: "Enemy Agents do not block you on Landsraad or City spaces. Signet: remove and replace a market card; only you may buy it for 1 less during your Reveal turn this round. Otherwise remove it from the game."
				},
				letoAtreides: {
					name: "Duke Leto Atreides",
					text: "Landsraad spaces cost 1 less Solari. Signet: you may pay 1 spice for 1 Influence with a Faction where an opponent has more Influence."
				},
				paulAtreides: {
					name: "Paul Atreides",
					text: "You may look at the top card of your deck at any time, without reshuffling an empty deck. Signet: draw a card."
				},
				arianaThorvald: {
					name: "Countess Ariana Thorvald",
					text: "Whenever you harvest spice at a maker space, gain 1 less spice and draw a card. Signet: gain 1 water."
				},
				memnonThorvald: {
					name: "Count Memnon Thorvald",
					text: "When you gain a High Council seat, gain 1 Influence with any Faction. Signet: gain 1 spice."
				},
				armandEcaz: {
					name: "Archduke Armand Ecaz",
					text: "Reveal: with at least 2 Agents across Landsraad, City, and Spice Trade spaces, you may trash a card in play. Signet: you may acquire a card costing 3 or less."
				},
				ilesaEcaz: {
					name: "Ilesa Ecaz",
					text: "Set aside a card at round start. Return and show it at the start of your second turn; if you use it to send an Agent that turn, gain 1 spice if it has exactly 1 Agent icon, otherwise 1 Solari. Signet: you may pay 1 Solari for Foldspace."
				},
				rhomburVernius: {
					name: "Prince Rhombur Vernius",
					text: "Your dreadnoughts have strength 4. Signet: you may acquire a Tech tile, or place a negotiator instead."
				},
				tessiaVernius: {
					name: "Tessia Vernius",
					text: "Recall a Snooper when you first reach 2 Influence with its Faction. First: discard a card for 1 spice. Second: take that Faction’s bonus. Third: gain 1 Influence there. Fourth: take its bonus and gain 1 Influence there. Signet: you may lose 1 Influence to gain 1 with a Faction still holding a Snooper."
				},
				yunaMoritani: {
					name: "“Princess” Yuna Moritani",
					text: "Start without water. Whenever you gain Solari on your turn, gain 1 more. Signet: you may pay 7 Solari for 1 Influence with any Faction, 1 troop, and 1 spice."
				},
				hundroMoritani: {
					name: "Viscount Hundro Moritani",
					text: "At setup, look at the top 2 Intrigues; keep one and return the other to the top. Signet: you may pay 1 spice for 1 shipping icon."
				}
			},
			intrigues: {
				bribery: {
					name: "Bribery",
					text: "Pay 2 Solari for 1 Influence with any Faction."
				},
				refocus: {
					name: "Refocus",
					text: "Shuffle your discard pile into your deck, then draw a card."
				},
				ambush: {
					name: "Ambush",
					text: "Gain 4 swords."
				},
				alliedArmada: {
					name: "Allied Armada",
					text: "With a Faction Alliance, pay 2 spice for 7 swords."
				},
				favoredSubject: {
					name: "Favored Subject",
					text: "Gain 1 Emperor Influence."
				},
				demandRespect: {
					name: "Demand Respect",
					text: "After winning a Conflict: gain 1 Influence with any Faction, or pay 2 spice for 2 Influence with one Faction."
				},
				poisonSnooper: {
					name: "Poison Snooper",
					text: "Look at the top card of your deck and draw or trash it, without reshuffling an empty deck."
				},
				guildAuthorization: {
					name: "Guild Authorization",
					text: "Gain 1 Spacing Guild Influence."
				},
				dispatchAnEnvoy: {
					name: "Dispatch an Envoy",
					text: "Add all four Faction Agent icons to the card you use to send an Agent this turn."
				},
				infiltrate: {
					name: "Infiltrate",
					text: "Enemy Agents do not block your Agent this turn."
				},
				knowTheirWays: {
					name: "Know Their Ways",
					text: "Gain 1 Fremen Influence."
				},
				masterTactician: {
					name: "Master Tactician",
					text: "Choose 3 swords or retreat up to 3 troops."
				},
				plansWithinPlans: {
					name: "Plans Within Plans",
					text: "Endgame: gain 1 victory point for 3 Factions at 3 or more Influence, or 2 points for all 4."
				},
				privateArmy: {
					name: "Private Army",
					text: "Pay 2 spice for 5 swords."
				},
				doubleCross: {
					name: "Double Cross",
					text: "Pay 1 Solari; an opponent loses a troop in the Conflict and you deploy a troop from your supply."
				},
				councilorsDispensation: {
					name: "Councilor’s Dispensation",
					text: "With a High Council seat, gain 2 spice."
				},
				cornerTheMarket: {
					name: "Corner the Market",
					text: "Endgame: gain 1 victory point with at least 2 The Spice Must Flow, and 1 more if you have more than each opponent."
				},
				charisma: {
					name: "Charisma",
					text: "Gain 2 persuasion during your Reveal turn this round."
				},
				calculatedHire: {
					name: "Calculated Hire",
					text: "Pay 1 spice to take the Mentat from its designated board space."
				},
				choamShares: {
					name: "CHOAM Shares",
					text: "Pay 7 Solari for 1 victory point."
				},
				bypassProtocol: {
					name: "Bypass Protocol",
					text: "Acquire a card costing 3 or less; or pay 2 spice to acquire a card costing 5 or less on top of your deck."
				},
				recruitmentMission: {
					name: "Recruitment Mission",
					text: "Gain 1 persuasion during your Reveal turn this round, when you may put acquired cards on top of your deck."
				},
				reinforcements: {
					name: "Reinforcements",
					text: "Pay 3 Solari to recruit 3 troops; during your Reveal turn, you may deploy them."
				},
				binduSuspension: {
					name: "Bindu Suspension",
					text: "Only at the start of your turn: draw a card, then you may pass your turn."
				},
				secretOfTheSisterhood: {
					name: "Secret of the Sisterhood",
					text: "Gain 1 Bene Gesserit Influence."
				},
				rapidMobilization: {
					name: "Rapid Mobilization",
					text: "You may deploy any number of troops from your garrison."
				},
				stagedIncident: {
					name: "Staged Incident",
					text: "Lose 3 troops in the Conflict for 1 victory point."
				},
				theSleeperMustAwaken: {
					name: "The Sleeper Must Awaken",
					text: "Pay 4 spice for 1 victory point."
				},
				tiebreaker: {
					name: "Tiebreaker",
					text: "Combat: gain 2 swords. Or endgame: gain 10 spice."
				},
				toTheVictor: {
					name: "To the Victor",
					text: "After winning a Conflict: gain 3 spice."
				},
				waterPeddlersUnion: {
					name: "Water Peddlers Union",
					text: "Gain 1 water."
				},
				windfall: {
					name: "Windfall",
					text: "Gain 2 Solari."
				},
				waterOfLife: {
					name: "Water of Life",
					text: "Pay 1 water and 1 spice to draw 3 cards."
				},
				urgentMission: {
					name: "Urgent Mission",
					text: "Recall one of your Agents from the board for use again this round."
				},
				diversion: {
					name: "Diversion",
					text: "After deploying at least 4 combat units this turn: gain 1 shipping icon."
				},
				warChest: {
					name: "War Chest",
					text: "Combat: pay 2 Solari for 4 swords. Or endgame: gain 1 victory point with at least 10 Solari."
				},
				advancedWeaponry: {
					name: "Advanced Weaponry",
					text: "Plot: pay 3 Solari to recruit a dreadnought. Or combat: with at least 3 Tech tiles, gain 4 swords."
				},
				secretForces: {
					name: "Secret Forces",
					text: "With a High Council seat, recruit 2 troops."
				},
				grandConspiracy: {
					name: "Grand Conspiracy",
					text: "Endgame conditions: 2 dreadnoughts; at least 1 The Spice Must Flow; at least 2 Factions at 4 Influence; a High Council seat. Gain 1 victory point for any 3, or 2 for all 4."
				},
				cull: {
					name: "Cull",
					text: "Pay 1 Solari to trash a card."
				},
				strategicPush: {
					name: "Strategic Push",
					text: "Gain 2 swords; if you win this Conflict, gain 2 Solari."
				},
				blackmail: {
					name: "Blackmail",
					text: "Lose 1 Influence with a Faction for 5 swords."
				},
				machineCulture: {
					name: "Machine Culture",
					text: "Plot: acquire a Tech tile. Or endgame: gain 1 victory point with at least 3 Tech tiles."
				},
				cannonTurrets: {
					name: "Cannon Turrets",
					text: "Gain 2 swords. Each opponent retreats a dreadnought."
				},
				expedite: {
					name: "Expedite",
					text: "Pay 1 spice for 1 shipping icon."
				},
				ixianProbe: {
					name: "Ixian Probe",
					text: "Discard 2 cards to draw 2 cards."
				},
				secondWave: {
					name: "Second Wave",
					text: "Gain 2 swords; you may deploy up to 2 combat units from your garrison."
				},
				glimpseThePath: {
					name: "Glimpse the Path",
					text: "Pay 1 spice for 1 water and a card."
				},
				finesse: {
					name: "Finesse",
					text: "Plot: lose 1 Influence with a Faction and gain 1 Influence with any Faction. Or combat: gain 2 swords."
				},
				strongarm: {
					name: "Strongarm",
					text: "Lose a troop for 1 Influence with the Faction space you sent an Agent to this turn."
				},
				quidProQuo: {
					name: "Quid Pro Quo",
					text: "Pay 2 spice; gain 1 Influence with each Faction where you have at least one Agent."
				}
			},
			techs: {
				windtraps: {
					name: "Windtraps",
					text: "Acquire: gain 1 water. Whenever you win a Conflict, gain 1 water."
				},
				detonationDevices: {
					name: "Detonation Devices",
					text: "When you win a Conflict with a dreadnought, you may return one to your supply for 1 victory point instead of controlling a space."
				},
				memocorders: {
					name: "Memocorders",
					text: "Acquire: gain 1 Influence with any Faction. Endgame: gain 1 victory point with at least 3 Influence in all four Factions."
				},
				flagship: {
					name: "Flagship",
					text: "Acquire: gain 1 victory point. Once per round, you may pay 4 Solari to recruit 3 troops."
				},
				spaceport: {
					name: "Spaceport",
					text: "Acquire: draw 2 cards. You may put acquired cards on top of your deck."
				},
				artillery: {
					name: "Artillery",
					text: "During your Reveal turn, each revealed card that provides swords gives 1 more sword."
				},
				holoprojectors: {
					name: "Holoprojectors",
					text: "Once per round, you may discard a card to draw a card."
				},
				restrictedOrdnance: {
					name: "Restricted Ordnance",
					text: "Reveal: with a High Council seat, gain 4 swords."
				},
				shuttleFleet: {
					name: "Shuttle Fleet",
					text: "Acquire: gain 1 Influence with each of 2 different Factions. Round start: gain 2 Solari."
				},
				spySatellites: {
					name: "Spy Satellites",
					text: "You may pay 3 spice and trash this tile for 1 victory point. Endgame: gain 1 victory point per Faction with at most 1 Influence."
				},
				disposalFacility: {
					name: "Disposal Facility",
					text: "Acquire: you may trash a card. Reveal: with at least 6 persuasion, you may trash a card in play."
				},
				chaumurky: {
					name: "Chaumurky",
					text: "Acquire: draw 2 Intrigues. You win endgame ties on victory points."
				},
				sonicSnoopers: {
					name: "Sonic Snoopers",
					text: "Acquire: draw an Intrigue. You may trash this tile to put any number of Intrigues under their deck and draw that many."
				},
				trainingDrones: {
					name: "Training Drones",
					text: "Once per round, you may recruit a troop."
				},
				troopTransports: {
					name: "Troop Transports",
					text: "When recruiting from the Shipping track, recruit 1 extra troop. You may deploy any of those troops."
				},
				holtzmanEngine: {
					name: "Holtzman Engine",
					text: "Round start: draw 1 additional card. Endgame: gain 1 victory point with at least 2 The Spice Must Flow."
				},
				minimicFilm: {
					name: "Minimic Film",
					text: "Gain 1 persuasion each Reveal turn."
				},
				invasionShips: {
					name: "Invasion Ships",
					text: "Acquire: recruit 4 troops. Once per round, you may discard a card to ignore enemy Agents this turn."
				}
			},
			spaces: {
				conspire: "Conspire",
				wealth: "Wealth",
				heighliner: "Heighliner",
				foldspace: "Foldspace",
				selectiveBreeding: "Selective Breeding",
				secrets: "Secrets",
				hardyWarriors: "Hardy Warriors",
				stillsuits: "Stillsuits",
				highCouncil: "High Council",
				mentat: "Mentat",
				swordmaster: "Swordmaster",
				rallyTroops: "Rally Troops",
				hallOfOratory: "Hall of Oratory",
				secureContract: "Secure Contract",
				sellMelange: "Sell Melange",
				arrakeen: "Arrakeen",
				carthag: "Carthag",
				researchStation: "Research Station",
				sietchTabr: "Sietch Tabr",
				imperialBasin: "Imperial Basin",
				haggaBasin: "Hagga Basin",
				theGreatFlat: "The Great Flat",
				smuggling: "Smuggling",
				interstellarShipping: "Interstellar Shipping",
				techNegotiation: "Tech Negotiation",
				dreadnought: "Dreadnought"
			},
			conflicts: {
				skirmishA: "Skirmish I",
				skirmishB: "Skirmish II",
				skirmishC: "Skirmish III",
				skirmishD: "Skirmish IV",
				skirmishE: "Skirmish V",
				skirmishF: "Skirmish VI",
				desertPower: "Desert Power",
				raidStockpiles: "Raid Stockpiles",
				cloakAndDagger: "Cloak and Dagger",
				machinations: "Machinations",
				sortThroughTheChaos: "Sort Through the Chaos",
				terriblePurpose: "Terrible Purpose",
				guildBankRaid: "Guild Bank Raid",
				siegeOfArrakeen: "Siege of Arrakeen",
				siegeOfCarthag: "Siege of Carthag",
				secureImperialBasin: "Secure Imperial Basin",
				tradeMonopoly: "Trade Monopoly",
				battleForImperialBasin: "Battle for Imperial Basin",
				grandVision: "Grand Vision",
				battleForCarthag: "Battle for Carthag",
				battleForArrakeen: "Battle for Arrakeen",
				economicSupremacy: "Economic Supremacy"
			},
			cards: {
				duneTheDesertPlanet: {
					name: "Dune, the Desert Planet",
					text: "Agent: no effect. Reveal: gain 1 persuasion."
				},
				seekAllies: {
					name: "Seek Allies",
					text: "Agent: trash this card."
				},
				signetRing: {
					name: "Signet Ring",
					text: "Agent: use your leader’s Signet Ring ability. Reveal: gain 1 persuasion."
				},
				diplomacy: {
					name: "Diplomacy",
					text: "Reveal: gain 1 persuasion."
				},
				reconnaissance: {
					name: "Reconnaissance",
					text: "Reveal: gain 1 persuasion."
				},
				convincingArgument: {
					name: "Convincing Argument",
					text: "Reveal: gain 2 persuasion."
				},
				dagger: {
					name: "Dagger",
					text: "Reveal: gain 1 sword."
				},
				controlTheSpice: {
					name: "Control the Spice",
					text: "Agent: you may pay 1 spice to trash a card and recruit a troop. Reveal: gain 1 persuasion and 1 spice."
				},
				arrakisLiaison: {
					name: "Arrakis Liaison",
					text: "Reveal: gain 2 persuasion."
				},
				foldspace: {
					name: "Foldspace",
					text: "Agent: draw a card and trash this card."
				},
				theSpiceMustFlow: {
					name: "The Spice Must Flow",
					text: "Acquire: gain 1 victory point. Reveal: gain 1 spice."
				},
				sardaukarLegion: {
					name: "Sardaukar Legion",
					text: "Agent: recruit 2 troops. Reveal: gain 1 persuasion; you may deploy up to 3 troops from your garrison."
				},
				drYueh: {
					name: "Dr. Yueh",
					text: "Agent: draw a card. Reveal: gain 1 persuasion."
				},
				assassinationMission: {
					name: "Assassination Mission",
					text: "Reveal: gain 1 Solari and 1 sword. When this card is trashed, gain 4 Solari."
				},
				sardaukarInfantry: {
					name: "Sardaukar Infantry",
					text: "Reveal: gain 1 persuasion and 2 swords."
				},
				beneGesseritInitiate: {
					name: "Bene Gesserit Initiate",
					text: "Agent: draw a card. Reveal: gain 1 persuasion."
				},
				guildAdministrator: {
					name: "Guild Administrator",
					text: "Agent: you may trash a card. Reveal: gain 1 persuasion."
				},
				theVoice: {
					name: "The Voice",
					text: "Acquire: choose a board space. Opponents cannot send Agents there until your next turn starts. Reveal: gain 2 persuasion."
				},
				scout: {
					name: "Scout",
					text: "Reveal: gain 1 persuasion and 1 sword; you may retreat up to 2 troops."
				},
				imperialSpy: {
					name: "Imperial Spy",
					text: "Agent: you may trash this card to draw an Intrigue. Reveal: gain 1 persuasion and 1 sword."
				},
				beneGesseritSister: {
					name: "Bene Gesserit Sister",
					text: "Reveal: choose 2 persuasion or 2 swords."
				},
				missionariaProtectiva: {
					name: "Missionaria Protectiva",
					text: "Agent: if you played another Bene Gesserit card, gain 1 Influence with any Faction. Reveal: gain 1 persuasion."
				},
				spiceHunter: {
					name: "Spice Hunter",
					text: "Reveal: gain 1 persuasion and 1 sword; with Fremen Bond, gain 1 spice."
				},
				spiceSmugglers: {
					name: "Spice Smugglers",
					text: "Agent: you may pay 2 spice for 1 Spacing Guild Influence and 3 Solari. Reveal: gain 1 persuasion and 1 sword."
				},
				fedaykinDeathCommando: {
					name: "Fedaykin Death Commando",
					text: "Agent: you may trash a card. Reveal: gain 1 persuasion; with Fremen Bond, gain 3 swords."
				},
				geneManipulation: {
					name: "Gene Manipulation",
					text: "Agent: you may trash a card. If you played another Bene Gesserit card, gain 2 spice. Reveal: gain 2 persuasion."
				},
				guildBankers: {
					name: "Guild Bankers",
					text: "Reveal: each The Spice Must Flow costs 3 less persuasion this turn."
				},
				choamDirectorship: {
					name: "CHOAM Directorship",
					text: "Acquire: gain 1 Influence with each Faction. Reveal: gain 3 Solari."
				},
				crysknife: {
					name: "Crysknife",
					text: "Agent: gain 1 Solari. Reveal: gain 1 sword; with Fremen Bond, gain 1 Fremen Influence."
				},
				chani: {
					name: "Chani",
					text: "Acquire: gain 1 water. Reveal: gain 2 persuasion; you may retreat any number of troops."
				},
				spaceTravel: {
					name: "Space Travel",
					text: "Agent: draw a card. Reveal: gain 2 persuasion."
				},
				duncanIdaho: {
					name: "Duncan Idaho",
					text: "Agent: you may pay 1 water to recruit a troop and draw a card. Reveal: gain 2 swords and 1 water."
				},
				shiftingAllegiances: {
					name: "Shifting Allegiances",
					text: "Agent: you may pay 2 spice and lose 1 Influence with a Faction to gain 2 Influence with a different Faction. Reveal: gain 2 persuasion."
				},
				kwisatzHaderach: {
					name: "Kwisatz Haderach",
					text: "Agent: move one of your Agents on the board to any legal space, ignoring occupancy, then draw a card."
				},
				sietchReverendMother: {
					name: "Sietch Reverend Mother",
					text: "Agent: you may trash a card. Reveal: gain 1 spice; with Fremen Bond, gain 3 persuasion."
				},
				arrakisRecruiter: {
					name: "Arrakis Recruiter",
					text: "Agent: recruit a troop. Reveal: gain 1 persuasion and 1 sword."
				},
				firmGrip: {
					name: "Firm Grip",
					text: "Agent: you may pay 2 Solari for 1 Influence with the Guild, Bene Gesserit, or Fremen. Reveal: with the Emperor Alliance, gain 4 persuasion."
				},
				smugglersThopter: {
					name: "Smuggler’s Thopter",
					text: "Agent: with 2 or more Spacing Guild Influence, draw 2 cards. Reveal: gain 1 persuasion and 1 spice."
				},
				carryall: {
					name: "Carryall",
					text: "Agent: double the base spice harvested this turn, excluding bonus spice. Reveal: gain 1 persuasion and 1 spice."
				},
				gunThopter: {
					name: "Gun Thopter",
					text: "Agent: each opponent loses a garrisoned troop. Reveal: gain 3 swords; you may deploy a troop from your garrison."
				},
				guildAmbassador: {
					name: "Guild Ambassador",
					text: "Agent: choose 1 Spacing Guild Influence or 2 persuasion. Reveal: with the Guild Alliance, you may pay 3 spice for 1 victory point."
				},
				testOfHumanity: {
					name: "Test of Humanity",
					text: "Agent: in clockwise order, each opponent discards a card or loses a troop in the Conflict. Reveal: gain 2 persuasion."
				},
				fremenCamp: {
					name: "Fremen Camp",
					text: "Agent: you may pay 2 spice to recruit 3 troops. Reveal: gain 2 persuasion and 1 sword."
				},
				opulence: {
					name: "Opulence",
					text: "Agent: gain 3 Solari. Reveal: gain 1 persuasion; you may pay 6 Solari for 1 victory point."
				},
				ladyJessica: {
					name: "Lady Jessica",
					text: "Acquire: gain 1 Influence with any Faction. Agent: draw 2 cards. Reveal: gain 3 persuasion and 1 sword."
				},
				stilgar: {
					name: "Stilgar",
					text: "Agent: gain 1 water. Reveal: gain 2 persuasion and 3 swords."
				},
				piterDeVries: {
					name: "Piter de Vries",
					text: "Agent: draw an Intrigue. Reveal: gain 3 persuasion and 1 sword."
				},
				gurneyHalleck: {
					name: "Gurney Halleck",
					text: "Agent: recruit 2 troops and draw a card. Reveal: gain 2 persuasion; you may pay 3 Solari to recruit 2 troops and deploy them."
				},
				thufirHawat: {
					name: "Thufir Hawat",
					text: "Agent: draw a card. Reveal: gain 1 persuasion and draw an Intrigue."
				},
				otherMemory: {
					name: "Other Memory",
					text: "Agent: draw a card or return a Bene Gesserit card from your discard pile to your hand. Reveal: gain 2 persuasion."
				},
				lietKynes: {
					name: "Liet Kynes",
					text: "Acquire: gain 1 Emperor Influence. Reveal: gain 2 persuasion for each Fremen card you played or revealed this round, including this card."
				},
				wormRiders: {
					name: "Worm Riders",
					text: "Agent: gain 2 spice. Reveal: with 2 or more Fremen Influence, gain 4 swords; with the Fremen Alliance, gain 2 more."
				},
				reverendMotherMohiam: {
					name: "Reverend Mother Mohiam",
					text: "Agent: if you played another Bene Gesserit card, each opponent discards 2 cards, clockwise. Reveal: gain 2 persuasion and 2 spice."
				},
				powerPlay: {
					name: "Power Play",
					text: "Agent: gain 2 Influence instead of 1 from the Faction space you visit, then trash this card."
				},
				guildChiefAdministrator: {
					name: "Guild Chief Administrator",
					text: "Agent: you may discard a card to trash a card. Reveal: gain 1 persuasion and 1 shipping icon."
				},
				guildAccord: {
					name: "Guild Accord",
					text: "Agent: Heighliner costs 2 less spice. Reveal and unload: gain 1 water; with the Guild Alliance, gain 3 spice."
				},
				localFence: {
					name: "Local Fence",
					text: "Agent: you may trade 2 spice for 5 Solari or 5 Solari for 4 spice. Reveal: gain 2 persuasion."
				},
				shaiHulud: {
					name: "Shai-Hulud",
					text: "Acquire: you may trash a card. Agent: you may trash a card to recruit 2 troops. Reveal: with Fremen Bond, gain 5 swords."
				},
				ixGuildCompact: {
					name: "Ix-Guild Compact",
					text: "Agent: you may discard 2 cards to acquire a Tech tile. Reveal and unload: place up to 2 negotiators."
				},
				choamDelegate: {
					name: "CHOAM Delegate",
					text: "Reveal and unload: gain 3 Solari."
				},
				bountyHunter: {
					name: "Bounty Hunter",
					text: "Agent: if you visit a space occupied by an enemy Agent, gain 2 Solari. Reveal: gain 1 persuasion and 1 sword."
				},
				embeddedAgent: {
					name: "Embedded Agent",
					text: "Agent: if you played another Bene Gesserit card, gain 2 shipping icons. Reveal: gain 1 persuasion and draw an Intrigue."
				},
				esmarTuek: {
					name: "Esmar Tuek",
					text: "Agent: you may pay 1 spice for 1 Guild Influence and a card. Reveal and unload: gain 2 spice and 2 Solari."
				},
				courtIntrigue: {
					name: "Court Intrigue",
					text: "Agent: you may put an Intrigue under its deck to draw an Intrigue. Reveal: gain 1 persuasion and 1 sword."
				},
				sayyadina: {
					name: "Sayyadina",
					text: "Agent: you may pay 3 water for 1 victory point. Reveal: with Fremen Bond, gain 3 persuasion."
				},
				imperialShockTrooper: {
					name: "Imperial Shock Trooper",
					text: "Reveal: gain 1 persuasion and 2 swords; with an Agent on an Emperor space, gain 3 more swords."
				},
				appropriate: {
					name: "Appropriate",
					text: "Acquire: gain 1 shipping icon. Agent: with 2 Emperor Influence, you may acquire a Tech, paying entirely in Solari or spice. Reveal: gain 2 persuasion."
				},
				desertAmbush: {
					name: "Desert Ambush",
					text: "Agent: for each troop you deploy this turn, you may make an opponent retreat a combat unit. Reveal: gain 1 persuasion and 1 sword."
				},
				inTheShadows: {
					name: "In the Shadows",
					text: "Agent: with 2 Bene Gesserit Influence, you may discard a card for 1 Emperor, Guild, or Fremen Influence. Reveal and unload: gain 1 Bene Gesserit Influence."
				},
				satelliteBan: {
					name: "Satellite Ban",
					text: "Agent: you may discard a card for 1 spice and 1 water. Reveal: gain 1 persuasion; you may retreat up to 2 troops."
				},
				freighterFleet: {
					name: "Freighter Fleet",
					text: "Reveal and unload: gain 1 shipping icon."
				},
				imperialBashar: {
					name: "Imperial Bashar",
					text: "Agent: recruit a troop or trash a card. Reveal: gain 1 persuasion and 2 swords, plus 1 sword per other revealed card that provides swords this turn."
				},
				jamis: {
					name: "Jamis",
					text: "Agent: you may trash a card. Reveal: gain 1 persuasion and 2 swords."
				},
				landingRights: {
					name: "Landing Rights",
					text: "Agent: gain 1 shipping icon. Reveal: gain 2 persuasion."
				},
				waterPeddler: {
					name: "Water Peddler",
					text: "Acquire: gain 1 water. Reveal and unload: gain 1 water."
				},
				treachery: {
					name: "Treachery",
					text: "Agent: gain 2 Influence instead of 1 at the Faction space, then trash this card. Reveal and unload: recruit 2 troops; you may deploy them."
				},
				truthsayer: {
					name: "Truthsayer",
					text: "Agent: you may discard a card to draw a card. Reveal: gain 1 persuasion and 1 sword."
				},
				spiceTrader: {
					name: "Spice Trader",
					text: "Agent: with 2 Fremen Influence, you may discard a card for 2 spice. Reveal: gain 2 persuasion and 1 sword."
				},
				ixianEngineer: {
					name: "Ixian Engineer",
					text: "Agent: you may acquire a Tech tile. Reveal: with 3 or more Tech tiles, you may trash this card for 1 victory point."
				},
				webOfPower: {
					name: "Web of Power",
					text: "Agent: with 2 Emperor Influence, gain 2 Solari; with 2 Guild Influence, draw a card; with 2 Fremen Influence, gain 1 water. Reveal: gain 1 persuasion and 1 Influence with any Faction."
				},
				weirdingWay: {
					name: "Weirding Way",
					text: "Agent: take another turn immediately after this turn. Reveal: gain 1 persuasion and 2 swords."
				},
				negotiatedWithdrawal: {
					name: "Negotiated Withdrawal",
					text: "Acquire: recruit a troop. Reveal: gain 2 persuasion; you may retreat 3 combat units for 1 Influence with any Faction."
				},
				fullScaleAssault: {
					name: "Full-Scale Assault",
					text: "Acquire: recruit a dreadnought. Agent: recruit 2 troops. Reveal: gain 2 persuasion and 3 swords per dreadnought you have in the Conflict."
				}
			},
			chooseRivalLeader: "Choose a Rival’s leader",
			chooseReinforcements: "Recruit for an Agent turn or begin your Reveal turn now",
			snoopers: "Remaining Snoopers",
			revealedSecrets: "Revealed Masterstroke Factions",
			effectControl: "Take control of {{space}}",
			effectFreeCard: "Acquire an Imperium card costing up to {{n}} for free",
			effectFreeTop: "Acquire a card costing up to {{n}} for free and put it on your deck",
			effectRevealPersuasion: "Gain {{n}} persuasion on your Reveal turn this round",
			effectCouncil: "Take a High Council seat",
			effectSwordmaster: "Gain the Swordmaster and your third Agent",
			effectMentat: "Take the Mentat if available",
			effectMentatNext: "Take the Mentat next round",
			effectFoldspace: "Acquire a Foldspace card from the reserve",
			effectShippingTroops: "Recruit 2 troops; Troop Transports adds 1 and permits deploying them",
			effectStealIntrigues: "Take a random Intrigue from each opponent holding at least 4",
			effectBounty: "Gain 2 Solari if the space already has an enemy Agent",
			effectGunThopter: "Each opponent loses 1 garrisoned troop",
			effectMohiam: "Each opponent discards 2 cards",
			effectHumanity: "Each opponent discards 1 card or loses 1 deployed troop",
			effectShift: "You may pay 2 spice and lose 1 Influence to gain 2 Influence",
			effectFinesse: "Lose 1 Influence with a Faction to gain 1 with a Faction",
			effectBlackmail: "Lose 1 Influence with a Faction to gain 5 swords",
			effectTessia: "You may lose 1 Influence to gain 1 with a Faction that still has your Snooper",
			effectLiet: "Gain 2 persuasion for each Fremen card played or revealed this round",
			effectReinforcements: "Recruit 3 troops; you may deploy them on a Reveal turn",
			effectRefocus: "Shuffle your deck and discard pile together",
			effectPeek: "Look at your top card, then draw or trash it",
			effectCross: "An opponent loses 1 deployed troop; deploy 1 troop from your supply",
			effectStaged: "Lose 3 deployed troops to gain 1 victory point",
			effectCannon: "Each opponent retreats 1 dreadnought",
			effectQuid: "Gain 1 Influence with each Faction where you have an Agent",
			effectStrongarm: "Lose 1 troop to gain 1 Influence with the Faction visited this turn",
			effectLeto: "You may pay 1 spice to gain 1 Influence where an opponent is ahead",
			effectScorePlans: "Score 1 or 2 victory points for Factions with at least 3 Influence",
			effectScoreCorner: "Score up to 2 victory points for The Spice Must Flow cards",
			effectScoreGrand: "Score 1 or 2 victory points for completed requirements",
			effectArrakeenSecond: "Choose two: 1 Intrigue, 2 spice, or 3 Solari",
			effectSonic: "Trash this tile to exchange any number of Intrigues",
			effectSatellites: "Pay 3 spice and trash this tile to gain 1 victory point",
			restartConfirm: "Start a new game?",
			logTechRemoved: "Removed Tech tile",
			chooseDefense: "Deploy the defense troop?",
			defend: "Deploy 1 troop from supply",
			name: "Dune: Imperium",
			desc: "Build your deck, send Agents, and compete for power on Arrakis",
			round: "Round {{n}}",
			wait: "Waiting for {{name}}",
			resolving: "Resolving",
			skip: "Decline",
			confirm: "Confirm",
			finish: "Done",
			cancel: "Cancel",
			pay: "Pay cost",
			choosePayment: "Pay the cost?",
			chooseEffect: "Choose an effect",
			effectOption: "Option {{n}}",
			chooseFaction: "Choose a Faction",
			chooseAlliance: "Choose who receives the Alliance",
			choosePlayer: "Choose this player",
			factionChoice: "Change Influence",
			chooseTrash: "Choose a card to trash",
			trashCard: "Trash this card",
			chooseDiscard: "Choose cards to discard",
			discardCards: "Discard {{n}} cards",
			discardOne: "Discard a card",
			chooseNegotiators: "Choose negotiators",
			negotiatorsChoice: "Place {{n}} negotiators",
			chooseTech: "Choose a Tech tile or decline",
			buyTech: "Pay {{n}} {{currency}} and return {{negotiators}} negotiators",
			placeNegotiator: "Place a negotiator",
			chooseShipping: "Advance or recall your freighter",
			advanceShip: "Advance freighter 1 space",
			recallShip: "Recall freighter for rewards",
			chooseDeployment: "Choose units to deploy",
			chooseRetreat: "Choose units to retreat",
			deployUnits: "Deploy {{troops}} troops and {{dreads}} dreadnoughts",
			retreatUnits: "Retreat {{troops}} troops and {{dreads}} dreadnoughts",
			chooseTwoFactions: "Choose 2 different Factions",
			twoFactions: "{{from}} and {{to}}",
			chooseVoice: "Choose a space to block opponents",
			chooseSpace: "Choose this space",
			chooseHumanity: "Discard a card or lose a troop",
			loseTroop: "Lose a troop in the Conflict",
			chooseOpponent: "Choose an opposing unit",
			enemyRetreat: "Retreat an enemy unit",
			changeInfluence: "Lose 1 {{from}} Influence; gain {{n}} {{to}} Influence",
			chooseMemory: "Draw or recover a card",
			drawCard: "Draw a card",
			returnCard: "Return to hand",
			choosePeek: "Draw or trash this card",
			chooseBindu: "Continue or pass this turn",
			passTurn: "Pass this turn",
			chooseTroop: "Choose a troop to lose",
			fromGarrison: "Lose a garrisoned troop",
			fromConflict: "Lose a troop in the Conflict",
			chooseRecall: "Choose an Agent to recall",
			chooseAcquire: "Choose a card or its destination",
			acquireCard: "Acquire this card",
			toDeck: "Place on top of deck",
			toDiscard: "Place in discard pile",
			chooseIntrigueExchange: "Choose an Intrigue to return under its deck",
			returnIntrigue: "Return under Intrigue deck",
			chooseReserve: "Choose a market card to reserve",
			reserveCard: "Reserve this card",
			chooseSecretFactions: "Secretly choose 2 Factions",
			chooseStartingIntrigue: "Choose an Intrigue to keep",
			keepIntrigue: "Keep this Intrigue",
			chooseAside: "Choose a card to set aside this round",
			setAside: "Set aside",
			chooseDreadControl: "Choose a space for your dreadnought",
			detonate: "Return a dreadnought to supply for 1 victory point",
			buyCard: "Acquire for {{n}} persuasion",
			playIntrigue: "Play Intrigue",
			useTech: "Use Tech tile",
			resolveEffect: "Resolve effect",
			chooseLeader: "Choose leader",
			sendAgent: "Send Agent",
			playCard: "Use card to send an Agent",
			reveal: "Reveal hand",
			deploy: "Deploy units",
			finishTurn: "End Agent turn",
			finishReveal: "End Reveal turn",
			finishCombatTurn: "End combat turn",
			passCombat: "Pass",
			finishEndgame: "Finish endgame scoring",
			invalidAction: "That action is no longer available. Choose again.",
			logTrashed: "Trashed a card",
			logAcquired: "Acquired a card",
			logTech: "Acquired a Tech tile",
			logPlaced: "Sent an Agent",
			logRevealed: "Revealed {{n}} cards",
			logMasterstroke: "Revealed Masterstroke",
			logRound: "Round {{n}} started",
			logReward: "Collected reward tier {{n}}",
			logIntrigue: "Played an Intrigue",
			optIx: "Rise of Ix",
			optEpic: "Epic mode",
			optDifficulty: "Solo Rival difficulty",
			mercenary: "Mercenary",
			veteran: "Sardaukar",
			expert: "Mentat",
			expertPlus: "Kwisatz Haderach",
			phaseLeaders: "Choose leaders",
			phasePrepare: "Round start",
			phaseTurns: "Player turns",
			phaseCombat: "Combat",
			phaseRewards: "Conflict rewards",
			phaseVictory: "Victory effects",
			phaseMakers: "Makers",
			phaseRecall: "Recall",
			phaseEndgame: "Endgame Intrigues",
			phaseDone: "Game over",
			agentTurn: "Agent turn",
			revealTurn: "Reveal turn",
			startTurn: "Send an Agent or reveal",
			hand: "Hand",
			intrigueHand: "Intrigues",
			market: "Imperium Row",
			reserves: "Reserve",
			playerArea: "Player area",
			techMarket: "Tech market",
			conflictTitle: "Current Conflict",
			factionsTitle: "Faction Influence",
			boardTitle: "Arrakis",
			landsraad: "Landsraad",
			spiceTrade: "Spice Trade",
			cities: "Cities",
			shipping: "Shipping track",
			firstPlayer: "First player",
			noChoices: "No action is required from you now.",
			noCards: "No cards",
			close: "Close",
			details: "Details",
			back: "Back",
			leaderAbility: "Leader ability",
			revealBox: "Reveal effect",
			agentBox: "Agent effect",
			acquireBox: "Acquire effect",
			cost: "Cost {{n}}",
			unload: "Unload",
			infiltration: "Infiltration",
			combatSpace: "Combat space",
			occupied: "Agents",
			controlledBy: "Controlled by {{name}}",
			bonusSpice: "Bonus spice {{n}}",
			requiresInfluence: "Requires 2 {{faction}} Influence",
			viewDiscard: "Discard pile",
			deckCount: "Deck: {{n}}",
			intrigueCount: "Intrigues: {{n}}",
			supplyCount: "Troop supply: {{n}}",
			aside: "Set-aside card",
			peekTitle: "Top of your deck",
			secretsTitle: "Secret Factions",
			playersTitle: "Players",
			npc: "Hagal Rival {{n}}",
			score: "{{n}} victory points",
			winner: "{{name}} wins",
			rank: "Rank {{n}}",
			playAgain: "Play again",
			backLobby: "Back to lobby",
			waitingHost: "Waiting for the host",
			history: "Recent events",
			actionTitle: "Current action",
			factionBonus: "Bonus at 4 Influence",
			threshold: "Victory target: {{n}}",
			alliance: "Alliance",
			agentIcons: "Agent access",
			effectGain: "Gain {{n}} {{resource}}",
			effectDraw: "Draw {{n}} cards",
			effectIntrigue: "Draw {{n}} Intrigues",
			effectTroop: "Recruit {{n}} troops",
			effectDread: "Recruit {{n}} dreadnoughts",
			effectShipping: "Use {{n}} shipping icons",
			effectNegotiator: "Place up to {{n}} negotiators",
			effectInfluence: "Change {{faction}} Influence by {{n}}",
			anyFaction: "Any Faction",
			effectPay: "Pay {{cost}}: {{effect}}",
			effectTrash: "Trash a card",
			effectDiscard: "Discard {{n}} cards",
			effectTech: "Acquire a Tech with discount {{n}}",
			effectDeploy: "Deploy up to {{n}} units",
			effectRetreat: "Retreat up to {{n}} units",
			effectChoice: "Choose an effect",
			effectConditional: "If eligible: {{effect}}",
			effectCard: "Resolve card effect",
			effectSignet: "Use Signet Ring",
			effectHarvest: "Harvest spice",
			effectRecruitDeploy: "Recruit {{n}} troops; you may deploy them",
			effectTurn: "Take another turn immediately",
			effectDividend: "Gain 5 Solari; each opponent gains 1",
			effectTwoFactions: "Gain 1 Influence with 2 different Factions",
			effectSwords: "Add swords this turn",
			effectDiscount: "The Spice Must Flow costs {{n}} less this turn",
			techExhausted: "Used this round",
			tabBoard: "Board",
			tabMarket: "Cards",
			tabPlayers: "Players",
			tabIntrigues: "Intrigues",
			tabLog: "Log",
			showAllActions: "All available actions",
			resources: {
				solari: "Solari",
				spice: "spice",
				water: "water",
				vp: "victory points",
				persuasion: "persuasion",
				sword: "swords",
				troop: "troops",
				dread: "dreadnoughts",
				agent: "Agents",
				negotiator: "negotiators",
				strength: "strength"
			},
			factions: {
				emperor: "Emperor",
				spacingGuild: "Spacing Guild",
				beneGesserit: "Bene Gesserit",
				fremen: "Fremen",
				green: "Landsraad",
				blue: "City",
				yellow: "Spice Trade",
				any: "Any space"
			},
			zoomBoard: "Enlarge board",
			fitBoard: "Fit width",
			jumpTo: "Jump to area",
			personalDetails: "Leader, technology & played cards",
			publicDetails: "Public player area",
			privateDetails: "Private information",
			playedCards: "Played cards",
			revealedCards: "Revealed cards",
			handCount: "{{n}} cards in hand",
			councilSeat: "High Council seat",
			ixTitle: "Ix",
			shippingTop: "Technology discount 2",
			shippingMiddle: "Recruit 2 troops · 1 influence",
			shippingFirst: "5 Solari / 2 Spice",
			shippingStart: "Start",
			intrigueDiscard: "Intrigue discard pile",
			tradeSpice: "Pay {{n}} Spice",
			harvestAmount: "Harvest {{n}} Spice",
			boardFoldspace: "Foldspace card",
			boardBreeding: "Trash 1 → draw 2",
			boardCouncil: "Reveal: +2 persuasion",
			boardMentat: "Temporary Agent",
			boardSwordmaster: "Third Agent",
			boardTech: "Acquire technology",
			boardNegotiation: "Discount 1 / negotiator",
			rules: "Goal:\n· End the game after a round with a player at 10 points, or when Conflicts run out.\n· Resolve Endgame Intrigues and Tech, then the most victory points wins.\n· Break ties with Chaumurky, then spice, Solari, water, and garrisoned troops.\n· If still tied, the player who most recently took a Reveal turn wins.\nSetup:\n· Each player starts with 10 cards, 1 water, 3 garrisoned troops, and 2 Agents.\n· Start at 1 point with four players, otherwise 0. Each player has 12 troops.\n· Choose leaders and apply setup abilities. Reveal a Conflict and draw 5 cards each round.\nAgent turns:\n· Starting with the first player, take Agent or Reveal turns clockwise.\n· Play a card and send an Agent to a legal space matching one of its icons.\n· Pay the space cost first, then resolve card and space effects in any order.\n· Normally, occupied spaces are blocked. Sietch Tabr requires 2 Fremen Influence.\n· At Combat spaces, deploy this turn’s recruits plus up to 2 garrisoned units.\n· An arrow’s cost may be paid once per effect; paying is optional.\n· Intrigue costs and conditions are mandatory. Play Plot Intrigues on your turn.\nReveal turns:\n· Reveal all remaining cards and resolve their effects in any order, buying between effects.\n· Spend persuasion on Imperium or reserve cards; discard acquired cards and refill immediately.\n· Previously played Agent cards do not reveal. Lose unused persuasion after this turn.\n· Immediately reveal cards drawn during this turn; keep cards drawn afterward for next round.\n· Clean up played and revealed cards when done; take no more turns this round. Cleanup is not Unload.\nFactions:\n· Reaching 2 Influence scores 1 point; falling below loses it. Crossing 4 grants the Faction bonus.\n· With at least 4 Influence, exceed the Alliance holder to take the token and its point.\n· Ties retain the Alliance. A losing holder chooses between tied eligible successors.\nCombat and rewards:\n· Troops give 2 strength, dreadnoughts 3; add swords to your strength.\n· With no deployed combat unit, strength is 0 and you cannot play Combat Intrigues.\n· Starting with the first player, play one or more Combat Intrigues, or pass.\n· You may play after passing. Resolve only after all participants pass consecutively.\n· Take rewards by rank. Ordinary third-place rewards apply only with four players.\n· Ties drop a tier: tied first gets tier 2, tied second tier 3; tied third earns nothing.\n· Zero strength earns no reward. Play victory Intrigues after rewards; ties are not wins.\n· After combat, return troops to supply and surviving dreadnoughts to garrison.\nMakers and Recall:\n· Add 1 bonus spice to each harvest space without an Agent.\n· If the game continues, recall Agents, rotate first player, and begin another round.\nRise of Ix:\n· Enable Ix at setup to replace Landsraad and trade spaces and add cards and Tech.\n· Each shipping icon advances one space or recalls for all rewards at and below your freighter.\n· Level 1 gives 2 spice, or 5 Solari with 1 Solari to each opponent.\n· Level 2 recruits 2 troops and gives 1 Influence; level 3 offers Tech with a 2-spice discount.\n· Resolve shipping rewards in any order. Negotiators use troop supply and discount Tech by 1 each.\n· Buy visible Tech and immediately reveal the next tile. Once-per-round abilities work on either turn type.\n· A winner with a deployed dreadnought must use one to control a space without a dreadnought.\n· Dreadnought control lasts through the next combat, overriding any control token.\n· Infiltration bypasses enemy Agents, never your own or The Voice. Voice expires on its owner’s next turn.\n· Unload resolves Reveal effects when discarded or trashed; discarding then trashing triggers it twice.\nEpic mode:\n· Enable independently at setup: play to 12 points with 5 level-II and 5 level-III Conflicts.\n· Start with 5 garrisoned troops and 1 Intrigue; replace one Dune, the Desert Planet with Control the Spice.\nTwo-player games:\n· Add one House Hagal Rival with 3 Agents and no starting garrison.\n· The Rival acts after each Agent turn of the first player; Reveal turns do not trigger it.\n· It collects no resources, scores no points, and earns no Conflict rewards, but contests Alliances.\n· When it wins a Conflict over a controlled space, remove that space’s control token.\nSolo games:\n· Add two Rivals taking normal turns; the Rival to your left starts.\n· Rivals use leader rings, not persistent abilities, and resolve Hagal card effects instead of space effects.\n· At Combat spaces, prioritize dreadnoughts and deploy recruits plus up to 2 garrisoned units.\n· For free Influence, choose a lowest-Influence Faction; the human breaks ties.\n· Rivals immediately trade each 3 water, 3 Intrigues, 7 Solari, or 7 spice for 1 point.\n· With Ix, save spice for Hagal-marked Tech until level-III Conflicts.\n· Buy the highest-cost affordable Tech, breaking ties upward. Clear a longest stack if no Rival Tech is visible.\n· Rivals advance freighters to level 2, then recall; always choose Solari.\n· Mercenary, Sardaukar, Mentat, and Kwisatz Haderach Rivals gain their third Agent in rounds 6, 5, 4, and 4.\n· Mercenary Rivals start without troops or Intrigues; the human gains 1 Solari and 1 spice.\n· Other Rivals start with 3 troops and 1 Intrigue; the Mentat space costs 5 Solari.\n· At Mentat or higher, Rivals stop deploying into level-I and II Conflicts once at least 4 strength ahead.\n· Kwisatz Haderach difficulty forbids the human Swordmaster."
		}
	}
};
//#endregion
export { Qn as default };
