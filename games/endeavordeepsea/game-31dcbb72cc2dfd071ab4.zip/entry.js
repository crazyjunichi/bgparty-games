import { z as e } from "zod";
import { Fragment as t, useEffect as n, useId as r, useMemo as i, useRef as a, useState as o } from "react";
import { createPortal as s } from "react-dom";
import { BottomSheet as c } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconBack as d, IconBot as f, IconClose as p, IconExpand as ee, IconInfo as te, IconLog as ne, IconPlayers as re, IconRecenter as ie, IconZoomIn as ae, IconZoomOut as m } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as oe } from "@bgparty/sdk/player-colors";
import { DeltaNumber as se } from "@bgparty/sdk/fx/delta-number";
import { useWakeLock as ce } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as le } from "@bgparty/sdk/ui/game-screen";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { seatName as ue } from "@bgparty/sdk/ui/player-strip";
import { Confetti as de } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as fe, OptionSection as pe, OptionSwitch as me } from "@bgparty/sdk/ui/game-options";
//#region src/games/endeavordeepsea/data.ts
var he = (e) => e ? e.split("/").map((e) => e.split("+")) : [], v = (e, t, n, r, i, a, o) => ({
	id: e,
	tier: t,
	count: n,
	junior: r,
	senior: i,
	actions: he(a),
	seniorActions: he(o)
}), ge = [
	v(393, 0, 4, "", "", "sail/sonar/dive/conserve/journal", "sail/sonar/dive/conserve/journal"),
	v(371, 1, 5, "C1", "C1", "sonar", "sail/sonar"),
	v(372, 1, 5, "R1", "R1", "dive", "dive/journal"),
	v(373, 1, 5, "h1", "I1 C1", "sail", "sail"),
	v(374, 2, 4, "G2", "", "", "sail/journal"),
	v(375, 2, 4, "I1", "", "sail/sonar", "sonar+dive"),
	v(376, 2, 4, "", "C2", "sail/conserve", "dive/conserve"),
	v(377, 3, 3, "", "", "sonar+journal", "sail+journal"),
	v(378, 3, 3, "I2", "", "conserve/journal", "conserve+conserve"),
	v(379, 3, 3, "", "R2", "sail+dive", "dive+conserve"),
	v(380, 4, 2, "G1", "G1", "sail+sail", "sail+sonar"),
	v(381, 4, 2, "h1", "r2", "dive+dive", "sail+conserve"),
	v(382, 4, 2, "a1", "h2", "sonar/journal", ""),
	v(383, 5, 1, "r4", "", "conserve+journal", ""),
	v(384, 5, 1, "I1", "", "dive+conserve+conserve", ""),
	v(386, 5, 1, "I3", "", "sonar+sonar", ""),
	v(387, 5, 1, "I2", "", "copy", ""),
	v(388, 5, 1, "G1", "", "sail+sail+sail", ""),
	v(389, 5, 1, "C2", "", "journal/promote", ""),
	v(390, 5, 1, "G3", "", "sail+dive", ""),
	v(391, 5, 1, "C1", "", "dive+dive+journal", ""),
	v(392, 5, 1, "G1", "", "sail+dive+conserve", "")
], y = Object.fromEntries(ge.map((e) => [e.id, e])), _e = {
	b: "blue",
	t: "brown",
	g: "green",
	y: "yellow"
}, b = (e, t, n, r, i = "", a = 0, o = [], s = !1) => ({
	id: e,
	cost: t,
	fields: [...n].map((e) => _e[e]),
	you: r,
	others: i,
	points: a,
	actions: o,
	anchor: s
}), ve = [
	b(0, 3, "y", "I1 h1 p1"),
	b(1, 4, "yg", "R2 p1", "", 0, ["conserveDepth", "conserveDepth"]),
	b(2, 2, "yt", "C1 G1 p1", "C1"),
	b(3, 3, "yt", "R1 p1", "r2", 0, ["promote"]),
	b(4, 2, "tg", "p1", "I1", 0, ["sailPlus", "sailPlus"]),
	b(5, 3, "tg", "I2 p1", "C1", 0, ["dive2"]),
	b(6, 3, "bt", "h1 p1", "r2", 0, ["conserveDepth", "conserveDepth"]),
	b(7, 2, "by", "G2", "", 2),
	b(8, 3, "by", "C1 p1", "", 2),
	b(9, 3, "by", "R1 p1", "", 2),
	b(10, 3, "yg", "C1 p1", "", 0, ["dive2"]),
	b(11, 3, "bg", "", "", 3, ["x3-5"]),
	b(12, 4, "b", "", "", 2, ["promote", "promote"]),
	b(13, 4, "bt", "R1 I1 C1", "d1", 2),
	b(14, 2, "b", "", "", 4),
	b(15, 0, "bt", "", "G1", 3),
	b(16, 0, "b", "", "", 2),
	b(17, 4, "by", "h2 G1", "", 2),
	b(18, 2, "yt", "C2 p1", "C1"),
	b(19, 2, "tg", "I2 p1", "I1"),
	b(20, 3, "g", "p1", "", 0, ["x3-5"]),
	b(21, 1, "g", "p1", "", 0, ["sailPlus"]),
	b(22, 4, "yt", "R2 h1 p1", "l1"),
	b(23, 3, "y", "G1 h1 p1"),
	b(24, 2, "t", "G2 p1", "G1", 0, [], !0),
	b(25, 0, "bt", "p1", "G1", 1, [], !0),
	b(26, 2, "t", "R2 p1", "R1", 0, [], !0),
	b(27, 3, "yt", "I2 p1", "d1", 0, [], !0),
	b(28, 1, "g", "p1", "", 0, ["conserveDepth"], !0),
	b(29, 3, "yg", "C1 p1", "", 0, ["sailPlus"], !0),
	b(30, 2, "y", "C1 p1", "", 0, [], !0),
	b(31, 2, "y", "R1 p1", "", 0, [], !0)
], x = Object.fromEntries(ve.map((e) => [e.id, e])), S = [
	{
		research: 4,
		effect: "p1"
	},
	{
		research: 3,
		effect: "h1"
	},
	{
		research: 3,
		effect: "sonar"
	},
	{
		research: 4,
		effect: "a1"
	},
	{
		research: 3,
		effect: "dive"
	},
	{
		research: 3,
		effect: "sail"
	},
	{
		research: 3,
		effect: "journal"
	},
	{
		research: 4,
		effect: "d1"
	},
	{
		research: 4,
		effect: ""
	},
	{
		research: 3,
		effect: "conserveCheap"
	},
	{
		research: 3,
		effect: "tradeDisc"
	},
	{
		research: 4,
		effect: "l1"
	}
], ye = [
	"journal",
	"sonar",
	"dive",
	"conserve",
	"sail"
], C = (e) => e < 2 ? 1 : e < 4 ? 2 : e < 7 ? 3 : e < 10 ? 4 : 5, w = (e) => [
	0,
	0,
	2,
	2,
	4,
	4,
	4,
	7,
	7,
	7,
	10,
	10,
	10
][e];
//#endregion
//#region src/games/endeavordeepsea/ocean.ts
function T(e, t, n, r, i, a = [], o = [], s = [], c = [], l, u = !1) {
	return {
		id: e,
		depth: t,
		arrival: n,
		discovery: r,
		dives: i,
		sites: [
			...a.flatMap((e, t) => e.map((e, n) => ({
				id: `s${t}-${n}`,
				kind: "sonar",
				track: t,
				cost: 0,
				reward: e
			}))),
			...o.map(([e, t, n], r) => ({
				id: `c${r}`,
				kind: "conserve",
				cost: e,
				reward: t,
				marked: n
			})),
			...s.map((e, t) => ({
				id: `j${t}`,
				kind: "journal",
				cost: 0,
				reward: "",
				field: Array.isArray(e) ? e[0] : e,
				marked: Array.isArray(e) ? e[1] : !1
			}))
		],
		links: c.map(([e, t, n]) => ({
			a: e,
			b: t,
			reward: n
		})),
		special: l,
		scenarioOnly: u
	};
}
var E = [
	T("seaStar", 1, "d1", "d2", [4], [[
		"x1-2",
		"x1-2",
		"x1-2"
	]], [], ["yellow", "brown"], [], void 0, !0),
	T("reef", 1, "h1", "R1 d1", [], [], [
		[1, "R1"],
		[4, "R1 h1"],
		[0, "R1"],
		[1, "h1"],
		[1, "C1"]
	], ["green"], [
		[
			"c0",
			"c1",
			"C1"
		],
		[
			"c0",
			"c4",
			"d1"
		],
		[
			"c1",
			"c4",
			"I1"
		],
		[
			"c1",
			"c2",
			"d1"
		],
		[
			"c1",
			"c3",
			"R1"
		]
	]),
	T("volcano", 1, "G1", "I1 d1", [2], [["x1-2", "x1-2"]], [], ["green", "brown"]),
	T("kelp", 1, "I1", "R1 r1", [4], [], [[2, "R1 C1"], [1, "C1"]], [], [[
		"c0",
		"c1",
		"C1"
	]]),
	T("anchorage", 1, "G1", "G1 d1", [], [[
		"x1-2",
		"x2-3",
		"G1 r1",
		"x3-5"
	]], [], ["blue"]),
	T("rig", 1, "R1", "C1 r1", [], [], [
		[1, "G1"],
		[4, "R1 h1"],
		[4, "C1 h1"],
		[1, "G1"]
	], [], [
		[
			"c0",
			"c1",
			"R1"
		],
		[
			"c1",
			"c2",
			"I2"
		],
		[
			"c2",
			"c3",
			"C1"
		]
	], "rig"),
	T("calm", 1, "r1", "G1 d1", [], [["I1 r1", "x3-5"], ["x1-2", "x1-2"]], [], ["brown"]),
	T("atoll", 1, "C1", "I1 d1", [4], [["x1-2", "x1-2"]]),
	T("lookingGlass", 2, "I1", "a1 d1 r1", [], [[
		"x1-3",
		"x1-3",
		"x1-3",
		"x4-5"
	]], [], ["yellow", "blue"], [], void 0, !0),
	T("dolphins", 2, "I1", "I1 G1", [3], [], [
		[4, "C1 h1"],
		[2, "h1 I1"],
		[3, "h1 I1"],
		[1, "I1"]
	], [], [
		[
			"c0",
			"c3",
			"R1"
		],
		[
			"c1",
			"c2",
			"I1"
		],
		[
			"c1",
			"c3",
			"d1"
		]
	]),
	T("ruins", 2, "d1", "G1 R1", [4], [["x2-3", "x2-3"]], [], [], [], "ruins"),
	T("pod", 2, "d1", "C1 G1", [], [[
		"x1-3",
		"x1-3",
		"G2"
	], [
		"x3-5",
		"x3-5",
		"x3-5"
	]], [], [], [
		[
			"s0-0",
			"s1-0",
			"d1"
		],
		[
			"s0-1",
			"s1-1",
			"R1"
		],
		[
			"s0-2",
			"s1-2",
			"d1"
		]
	]),
	T("cave", 2, "", "C1 G1", [
		1,
		2,
		1
	], [], [[2, "G1"]], ["blue", "green"], [
		[
			"c0",
			"j0",
			"R1"
		],
		[
			"j0",
			"j1",
			"G1"
		],
		[
			"j1",
			"c0",
			"I1"
		]
	], "cave"),
	T("wreck", 2, "R1", "I1 G1", [8], [["C1 r1", "x3-5"]], [], [], [], "wreck"),
	T("whales", 2, "r1", "R1 C1", [], [], [
		[1, "h1"],
		[2, "R2"],
		[4, "R1 h1"],
		[2, "R1 C1"],
		[0, "R1"],
		[2, "C1 I1"]
	], [["green", !0]], [
		[
			"c0",
			"c1",
			"R1"
		],
		[
			"c2",
			"c4",
			"h1"
		],
		[
			"c3",
			"c5",
			"I1"
		]
	], "whales"),
	T("elevator", 2, "G1", "R1 C1", [3], [[
		"G1 r1",
		"x3-5",
		"x3-5"
	]], [], ["yellow"], [[
		"s0-0",
		"s0-2",
		"G1"
	]]),
	T("turtles", 2, "C1", "R1 I1", [], [], [
		[2, "x1-3"],
		[4, "C1 h1"],
		[2, "x1-3"]
	], [], [[
		"c0",
		"c1",
		"h1"
	], [
		"c1",
		"c2",
		"h1"
	]], "turtles"),
	T("jellyfish", 3, "d1", "C2", [], [], [[
		5,
		"I2 C1",
		!0
	], [
		5,
		"R2 C1",
		!0
	]], [["yellow", !0]], [
		[
			"c0",
			"c1",
			"I1"
		],
		[
			"c0",
			"j0",
			"R1"
		],
		[
			"c1",
			"j0",
			"C1"
		]
	], "jellyfish"),
	T("vortex", 3, "R1", "G2", [], [
		["x3-3"],
		["C1 r1", "x1-4"],
		["I1 r1", "x4-5"]
	], [], [], [], "vortex"),
	T("vents", 3, "G1", "G2", [4], [], [], [["green", !0], ["blue", !0]], [], "vents"),
	T("sharks", 3, "C1", "I1 G1", [5], [], [], [], [], "sharks"),
	T("rift", 3, "C1", "C1 G1", [], [[
		"x2-3",
		"R1 r1",
		"x3-5",
		"G1 r1",
		"x3-5"
	]], [], ["blue"], [[
		"j0",
		"s0-2",
		"R1"
	], [
		"s0-0",
		"s0-4",
		"r1"
	]]),
	T("spires", 3, "r1", "R2", [], [["x3-5", "x3-5"]], [], [
		"blue",
		"brown",
		"green",
		"yellow"
	], [
		[
			"j0",
			"j1",
			"R1"
		],
		[
			"j1",
			"j2",
			"R1"
		],
		[
			"j2",
			"j3",
			"R1"
		],
		[
			"j3",
			"s0-1",
			"r1"
		],
		[
			"s0-0",
			"j0",
			"r1"
		]
	]),
	T("coldReef", 3, "R1", "I2", [], [], [
		[1, "R1"],
		[2, "C1"],
		[2, "I1"],
		[1, "R1"]
	], ["yellow", "green"], [
		[
			"c0",
			"j0",
			"h1"
		],
		[
			"j0",
			"c1",
			"h1"
		],
		[
			"c0",
			"c1",
			"R1"
		],
		[
			"j1",
			"c2",
			"I1"
		],
		[
			"j1",
			"c3",
			"C1"
		],
		[
			"c2",
			"c3",
			"C1"
		],
		[
			"c1",
			"c2",
			"R1"
		]
	]),
	T("whaleFall", 4, "I1", "I1 C2", [], [], [
		[2, "C1 h1"],
		[4, "h2"],
		[2, "I1 h1"]
	], ["yellow", "brown"], [
		[
			"c0",
			"j0",
			"C1"
		],
		[
			"j0",
			"c1",
			"h1"
		],
		[
			"c1",
			"j1",
			"h1"
		],
		[
			"j1",
			"c2",
			"I1"
		]
	]),
	T("plain", 4, "a1", "I1 G1 d1", [], [["x5-5", "x5-5"]], [], [], [], "plain"),
	T("snails", 4, "d1", "C1 G2", [3], [], [], [
		"blue",
		"brown",
		"yellow"
	], [], "snails"),
	T("lostStar", 4, "r2", "R1 G1 h1", [4], [["I1 h1", "I1 h1"]], [[6, "R1 h2"], [6, "C1 h2"]], ["green", "brown"], [
		[
			"c0",
			"c1",
			"I1"
		],
		[
			"c0",
			"j0",
			"R1"
		],
		[
			"c1",
			"j0",
			"C1"
		],
		[
			"s0-1",
			"j1",
			"d1"
		]
	], "lostStar", !0),
	T("trench", 4, "sonar", "I1 C1 G1", [], [[
		"I1 r1",
		"R1 r1",
		"I1 h1",
		"R1 h1",
		"h2",
		"h3"
	]], [], [], [], "trench"),
	T("smokers", 4, "d1 r1", "R1 G2", [4], [], [], ["brown", "blue"], [], "smokers"),
	T("recovery", 4, "conserve", "R1 C1 r1", [], [], [
		[1, "C1"],
		[5, "p1"],
		[1, "R1"],
		[1, "C1"],
		[2, "h1"],
		[1, "R1"]
	], [], [
		[
			"c0",
			"c1",
			"h1"
		],
		[
			"c1",
			"c2",
			"h1"
		],
		[
			"c2",
			"c3",
			"h1"
		],
		[
			"c3",
			"c4",
			"h1"
		],
		[
			"c4",
			"c5",
			"h1"
		],
		[
			"c5",
			"c0",
			"h1"
		]
	]),
	T("bioluminescence", 5, "G1", "I2 h1", [3, 3], [], [], [], [], "bioluminescence"),
	T("shelf", 5, "C1", "I1 G1 d1", [4], [], [], ["brown", "blue"], [[
		"j0",
		"j1",
		"h1"
	]]),
	T("squid", 5, "C1", "R2 r1", [3], [], [[0, ""], [0, ""]], ["yellow"], [[
		"c0",
		"c1",
		"h2"
	]]),
	T("brine", 5, "I1", "I1 G1 r1", [4], [], [], [], [], "brine"),
	T("sponge", 5, "r2", "R1 G1 r1", [], [], [], [
		"brown",
		"green",
		"blue"
	], [[
		"j0",
		"j1",
		"h1"
	], [
		"j1",
		"j2",
		"d1 r1"
	]]),
	T("seamount", 5, "d1", "G1 d1 r1", [4], [], [
		[
			1,
			"C1",
			!0
		],
		[
			3,
			"C2",
			!0
		],
		[
			1,
			"C1",
			!0
		]
	], [], [[
		"c0",
		"c1",
		"h1"
	], [
		"c1",
		"c2",
		"h1"
	]], "seamount"),
	T("orca", 1, "orca", "C1 d1", [], [["x1-3", "x1-3"]], [], ["green"], [], "orca"),
	T("academy", 2, "badge", "d2", [1], [["x1-2"]], [[1, "h1"]], ["blue"], [], "academy"),
	T("robot", 3, "robotMove", "R2", [], [], [], [
		"brown",
		"yellow",
		"green",
		"blue"
	], [], "robot")
], D = Object.fromEntries(E.map((e) => [e.id, e])), O = {
	b: "blue",
	t: "brown",
	g: "green",
	y: "yellow"
};
function k(e, t) {
	return t.flatMap((e) => e.trim().split(/\s+/).filter(Boolean)).map((t, n) => {
		let [r, i] = t.split(":"), [a, o] = r.split(",").map(Number), [s, c = "0", l] = i.replace(/[!^~]/g, "").split("/"), u = s === "_" || s === "inf" || O[s] ? "" : /^[RICGadrlph]\d*$/.test(s) ? /\d$/.test(s) ? s : `${s}1` : "";
		return {
			id: String(n),
			x: a / e,
			y: o / e,
			reward: u,
			points: Number(c),
			entry: i.includes("!"),
			infinite: s === "inf",
			rescue: i.includes("^"),
			polluted: i.includes("~"),
			field: O[s],
			group: l === void 0 ? void 0 : Number(l)
		};
	});
}
var A = (e, t, n, r, i, a, o) => ({
	id: e,
	columns: t,
	maxDepth: n,
	setup: r,
	random: i,
	launch: a,
	hexes: o
}), be = [
	A(1, 5, 5, [
		[
			"seaStar",
			1,
			1
		],
		[
			"volcano",
			2,
			1
		],
		[
			"lookingGlass",
			2,
			2
		]
	], [[3, 1]], "seaStar", k(65, [
		"86,249:R! 151,249:R 215,249:r/1 280,249:r/1 345,249:r/1 411,249:d/1 475,249:_/2",
		"119,305:R 509,305:_/2",
		"86,361:I! 151,361:I 476,361:r/1 541,361:_/2",
		"312,418:inf/2 378,418:r/1 443,418:d/1 508,418:d/1",
		"86,475:C! 151,475:C 476,475:r/1 541,475:_/2",
		"119,531:G 184,531:C 509,531:_/2",
		"86,587:G! 151,587:G 215,587:d/1 280,587:r/1 345,587:r/1 410,587:r/1 475,587:_/2"
	])),
	A(2, 5, 5, [
		[
			"seaStar",
			0,
			1
		],
		[
			"calm",
			1,
			1
		],
		[
			"anchorage",
			2,
			1
		],
		[
			"lookingGlass",
			0,
			2
		]
	], [], "seaStar", k(67, [
		"149,247:I! 268,247:_/2 387,247:_/2 506,247:_/2",
		"89,281:r! 208,281:_/2 327,281:_/2 446,281:C 565,281:_/2",
		"149,316:r 565,347:_/2",
		"89,347:C! 208,347:I 327,347:G 446,347:G",
		"506,381:I 89,414:C 208,414:R 327,414:R 446,414:C 565,414:d/1",
		"268,447:I",
		"89,480:r/1 208,480:r/1 327,480:r/1 446,480:r/1 565,480:d/1",
		"149,513:d/1 387,513:d/1",
		"89,546:_/2 208,546:_/2 327,546:_/2 446,546:_/2 565,546:inf/2"
	])),
	A(3, 5, 5, [
		[
			"seaStar",
			2,
			1
		],
		[
			"lookingGlass",
			2,
			2
		],
		[
			"spires",
			2,
			3
		]
	], [[3, 1]], "surface", k(64, [
		"86,246:y/1 151,246:g/1 215,246:_/2 279,246:_/2 471,246:_/2 535,246:p",
		"118,302:g/1 182,302:t/1 311,302:C 375,302:R 439,302:_/2 503,302:_/2",
		"86,357:b/1 150,357:y/1 279,357:R 343,357:C 471,357:R",
		"118,412:t/1 182,412:_/2 246,412:_/2 439,412:R! 503,412:G",
		"86,468:b/1 279,468:I! 343,468:R 471,468:G",
		"311,523:I 375,523:R 439,523:_/2 503,523:r/1 567,523:R",
		"150,578:inf/2 214,578:d/1 278,578:r/1 342,578:d/1 406,578:r/1 470,578:d/1 534,578:R 598,578:p"
	])),
	A(4, 5, 5, [
		[
			"seaStar",
			2,
			1
		],
		[
			"reef",
			3,
			1
		],
		[
			"lookingGlass",
			2,
			2
		]
	], [[1, 1]], "seaStar", k(84, [
		"190,247:I/2 432,280:_/2 515,292:_/2",
		"137,310:_/2 220,322:_/2 303,334:C/1 386,346:C/1 469,358:d/1 552,370:_/2",
		"166,385:_/2 249,397:r/1 332,409:R 415,421:R 498,433:d/1",
		"113,448:a! 196,460:a 279,472:C 362,484:C 445,496:C 528,508:a 611,520:_/1 694,532:inf/2",
		"143,523:_/2 226,535:r2/1 309,547:R 392,559:R 475,571:d/1",
		"89,586:_/2 172,598:_/2 255,610:C/1 338,622:C/1 421,634:d/1 504,646:_/2",
		"119,661:I/2 368,697:_/2 451,709:_/2",
		"819,666:inf/3"
	])),
	A(5, 7, 3, [
		[
			"atoll",
			0,
			1
		],
		[
			"calm",
			1,
			1
		],
		[
			"elevator",
			0,
			2
		]
	], [[2, 1], [3, 1]], "surface", k(84, [
		"308,250:p/1/0",
		"266,323:I/1/0 350,323:R/1/0 434,323:C/1/0 518,323:Cd/1/0",
		"224,396:Id/1/0 308,396:r2/1/0 392,396:r2/1/0 476,396:r2/1/0 560,396:ad/1/0",
		"182,469:a/1/0 266,469:Rd/1/0 434,469:a2/1/0 728,445:inf/1/0",
		"56,542:Rd/1/0! 140,542:a/1/0 98,615:Cd/1/0",
		"560,542:_/2/1 350,615:_/2/1 434,615:_/2/1 518,615:_/2/1 602,615:_/2/1 770,615:_/2/1 854,615:_/2/1!",
		"224,688:inf/2/1 392,688:d/1/1 476,688:d/1/1 560,688:d/1/1 644,688:_/2/1 728,688:_/2/1 518,761:_/2/1"
	])),
	A(6, 5, 5, [
		[
			"atoll",
			0,
			1
		],
		[
			"anchorage",
			2,
			1
		],
		[
			"calm",
			4,
			1
		],
		[
			"elevator",
			0,
			2
		],
		[
			"pod",
			2,
			2
		],
		[
			"wreck",
			4,
			2
		]
	], [], "surface", k(81, [
		"73,435:d! 143,395:R 213,435:d! 283,395:I 353,435:d! 423,395:C 493,435:d! 563,395:G 633,435:d!",
		"143,475:C 283,475:G 423,475:R 563,475:I",
		"73,594:_/2 143,554:r 213,594:_/2 283,554:r 353,594:_/2 423,554:r 493,594:_/2 563,554:r 633,594:_/2",
		"73,675:_/4 143,635:r 213,675:_/4 283,635:r 353,675:_/4 423,635:r 493,675:_/4 563,635:r 633,675:_/4",
		"73,755:_/6 143,715:l 213,755:_/6 283,715:l 353,755:_/6 423,715:l 493,755:_/6 563,715:l 633,755:_/6"
	])),
	A(7, 5, 5, [
		[
			"anchorage",
			2,
			1
		],
		[
			"pod",
			2,
			2
		],
		[
			"lostStar",
			2,
			5
		]
	], [[2, 3], [2, 4]], "anchorage", k(81, [
		"242,227:G 323,227:G",
		"202,297:G 283,297:Cd 364,297:G 445,297:Cd 526,297:R",
		"161,367:R 242,367:R 404,367:G 485,367:G 566,367:G",
		"121,437:r/1 283,437:Ir 364,437:R 445,437:Ir 526,437:R 607,437:G!",
		"161,507:r/1 121,577:inf/2",
		"283,596:l/1^ 364,596:l/1^ 607,596:_/3^",
		"242,666:l/1^ 404,666:l/1^ 485,666:_/3^ 566,666:_/3^",
		"121,736:r/2^ 202,736:l/1^ 283,736:l/1^ 445,736:r/2^ 526,736:r/2^!"
	])),
	A(8, 5, 5, [], [], "seaStar", k(81, [
		"108,242:_/1 189,242:_/1 270,242:_/1 351,242:t/1 432,242:_/1 513,242:b/1 594,242:r/1 675,242:t/1",
		"148,312:_/1 229,312:g/1 310,312:d/1 553,312:_/1 634,312:d/1 715,312:r/1",
		"108,382:t/1 189,382:_/1 270,382:_/1 351,382:_/1 432,382:_/1 594,382:y/1 675,382:_/1",
		"67,452:r/1 148,452:_/1 229,452:d/1 310,452:_/1 391,452:I/1 472,452:G/1 553,452:_/1 634,452:_/1 715,452:g/1",
		"108,522:y/1 270,522:_/1 351,522:I/1! 513,522:G/1! 594,522:_/1 675,522:b/1",
		"148,592:g/1 229,592:_/1 310,592:_/1 391,592:R/1 472,592:R/1 553,592:_/1 634,592:d/1 715,592:_/1",
		"189,662:_/1 270,662:d/1 351,662:_/1 432,662:_/1 675,662:_/1 815,662:inf/1",
		"108,732:_/1 189,732:_/1 270,732:_/1 351,732:y/1 432,732:_/1 513,732:b/1 594,732:_/1"
	])),
	A(9, 6, 4, [
		[
			"rig",
			2,
			1
		],
		[
			"seaStar",
			3,
			1
		],
		[
			"whales",
			2,
			2
		],
		[
			"lookingGlass",
			3,
			2
		]
	], [], "seaStar", k(83, [
		"141,440:a/0~ 282,440:a/0~ 423,440:l2/0~ 564,440:l2/0~ 705,440:a2/0~",
		"211,481:a/0~ 352,481:a/0~ 493,481:R2/0~ 634,481:I2/0~",
		"282,522:a/0~ 564,522:a/0~ 705,522:IC/0~",
		"211,563:RI/0~ 352,563:RC/0~ 493,563:G2/0~ 634,563:C2/0~",
		"70,587:inf/2! 211,646:C/1 352,646:I/1 493,646:G/1 634,646:C/1",
		"211,729:R/1 352,729:R/1 493,729:R/1 634,729:G/1!"
	])),
	A(10, 5, 5, [[
		"seaStar",
		2,
		1
	], [
		"lookingGlass",
		2,
		2
	]], [[1, 1], [3, 1]], "seaStar", k(66, [
		"140,224:r/0! 206,224:r/0 272,224:G/0 338,224:G/0 404,224:G/0 470,224:a/0",
		"140,313:a/0! 206,313:I/0 272,313:G/0 338,313:d/1 404,313:d/1 536,277:inf/1",
		"140,403:a/0! 206,403:R/0 272,403:r/1 338,403:r/1 404,403:r/1 470,403:r/1",
		"140,492:_/3! 206,492:_/2 272,492:r/1 338,492:r/1 404,492:r/1",
		"140,582:_/3! 206,582:_/3 272,582:_/3 338,582:_/2 404,582:_/2 470,582:_/2 536,538:inf/2"
	]))
];
for (let e of be) {
	if (e.id === 5 || e.id === 7 || e.id === 9) for (let t of e.hexes) {
		let n = {
			Cd: "C1 d1",
			Id: "I1 d1",
			ad: "a1 d1",
			Rd: "R1 d1",
			Ir: "I1 r1",
			IC: "I1 C1",
			RI: "R1 I1",
			RC: "R1 C1"
		}, r = e.id === 5 ? [
			"Cd",
			"Id",
			"ad",
			"Rd"
		] : e.id === 7 ? ["Cd", "Ir"] : [
			"IC",
			"RI",
			"RC"
		], i = e.id === 5 ? {
			"518,323": "Cd",
			"224,396": "Id",
			"560,396": "ad",
			"266,469": "Rd",
			"56,542": "Rd",
			"98,615": "Cd"
		} : e.id === 7 ? {
			"283,297": "Cd",
			"445,297": "Cd",
			"283,437": "Ir",
			"445,437": "Ir"
		} : {
			"705,522": "IC",
			"211,563": "RI",
			"352,563": "RC"
		}, a = e.id === 5 ? 84 : e.id === 7 ? 81 : 83, o = i[`${Math.round(t.x * a)},${Math.round(t.y * a)}`];
		r.includes(o) && (t.reward = n[o]);
	}
	if (e.id === 5) {
		let t = (t, n, r, i) => {
			let a = e.hexes.find((e) => Math.round(e.x * 84) === t && Math.round(e.y * 84) === n), o = e.hexes.find((e) => Math.round(e.x * 84) === r && Math.round(e.y * 84) === i);
			(a.neighbors ??= []).push(o.id), (o.neighbors ??= []).push(a.id);
		};
		t(560, 396, 728, 445), t(350, 615, 224, 688);
	}
	if (e.id === 6) for (let t of e.hexes) t.points && (t.column = Math.round((t.x * 81 - 73) / 140));
	if (e.id === 9) for (let t of e.hexes) t.polluted && (t.column = Math.min(3, Math.max(0, Math.round((t.x * 83 - 141) / 141))));
	if (e.id === 10) for (let t of e.hexes) t.depth = t.infinite ? 0 : Math.round((t.y * 66 - 224) / 89.5) + 1;
}
var j = Object.fromEntries(be.map((e) => [e.id, e])), M = (e, t) => !!e.neighbors?.includes(t.id) || Math.hypot(e.x - t.x, e.y - t.y) < 1.13;
//#endregion
//#region src/games/endeavordeepsea/scoring.ts
function N(e, t) {
	let n = {
		blue: 0,
		brown: 0,
		green: 0,
		yellow: 0
	};
	for (let r of e.zones) for (let e of D[r.id].sites) e.field && r.slots[e.id] === t.rid && n[e.field]++;
	for (let r of j[e.config.scenario].hexes) r.field && (n[r.field] += (e.impact[r.id] ?? []).filter((e) => e === t.rid).length);
	return n;
}
var P = (e, t, n = () => !0) => e.zones.flatMap((e) => Object.entries(e.slots).filter(([e, r]) => r === t.rid && n(e)).map(([t]) => ({
	z: e,
	id: t
}))), F = (e, t, n, r = "all", i = !1) => P(e, t, (e) => r === "all" || e.startsWith(r)).filter((e) => n(e.z)).length + (i ? t.vessels.filter((t) => n(e.zones.find((e) => e.id === t))).length : 0);
function xe(e, t) {
	let n = j[e.config.scenario].hexes.filter((n) => (e.impact[n.id] ?? []).includes(t) && !n.infinite), r = new Set(n.map((e) => e.id)), i = [];
	for (; r.size;) {
		let e = [r.values().next().value];
		r.delete(e[0]);
		for (let t = 0; t < e.length; t++) {
			let i = n.find((n) => n.id === e[t]);
			for (let t of n) r.has(t.id) && M(i, t) && (e.push(t.id), r.delete(t.id));
		}
		i.push(e);
	}
	return i.sort((e, t) => t.length - e.length || Number(e[0]) - Number(t[0]));
}
function Se(e, t, n) {
	let r = P(e, t);
	switch (n) {
		case 383: return new Set(r.filter((e) => e.id.startsWith("j")).map((e) => e.z.depth)).size;
		case 384: return Math.max(0, ...e.zones.map((e) => r.filter((t) => t.z.id === e.id && t.id.startsWith("c")).length));
		case 386: return Math.floor((/* @__PURE__ */ new Set([...r.map((e) => e.z.id), ...t.vessels])).size / 3);
		case 387: return 4;
		case 388: return Math.floor(e.zones.reduce((e, n) => e + n.linked.filter((e) => {
			let r = D[n.id].links[e];
			return n.slots[r.a] !== n.slots[r.b] && [n.slots[r.a], n.slots[r.b]].includes(t.rid);
		}).length, 0) / 2);
		case 389: return t.experts.filter((e) => e.senior && e.id !== 389).length;
		case 390: return Math.floor(e.zones.reduce((e, t) => e + t.dives.filter((e) => !e.length).length, 0) / 2);
		case 391: return 3 * Math.min(...Object.values(N(e, t)));
		case 392: return new Set(r.filter((e) => e.id.startsWith("c")).map((e) => e.z.id)).size;
		default: return 0;
	}
}
function I(e, t, n) {
	let r = e.config.scenario, i = () => !0, a = (e, t, n, r = e) => ({
		base: e,
		rank: r,
		first: t,
		second: n
	}), o = (e, t) => (n) => n.depth >= e && n.depth <= t;
	if (r === 1) return n === 0 ? a(F(e, t, i, "s"), 5, 3) : n === 1 ? a(F(e, t, i, "j"), 3, 1) : a(F(e, t, i, "c"), 7, 4);
	if (r === 2) return n === 0 ? a(F(e, t, (e) => e.x === 1, "s"), 4, 2) : n === 1 ? a(F(e, t, (e) => e.x === 3, "all", !0), 7, 4) : a(new Set(P(e, t).filter((e) => o(2, 4)(e.z)).map((e) => e.z.id)).size, 2, 1);
	if (r === 3) {
		if (n === 0) return a(F(e, t, o(1, 2), "s"), 6, 3);
		if (n === 1) return a(F(e, t, o(3, 5), "j", !0), 4, 2);
		let r = N(e, t);
		return a(Object.keys(r).filter((t) => r[t] > 0 && e.players.every((n) => N(e, n)[t] <= r[t])).length * 2, 0, 0);
	}
	if (r === 4) return n === 0 ? a(F(e, t, o(1, 3), "c"), 6, 3) : n === 1 ? a(F(e, t, (e) => e.x === 0 || e.x === 4, "j", !0), 7, 4) : a(F(e, t, o(4, 5)), 4, 2);
	if (r === 5) return n === 0 ? a(F(e, t, (e) => e.x < 2, "s", !0), 2, 1) : n === 1 ? a(F(e, t, (e) => e.x >= 4, "j", !0), 2, 1) : a(F(e, t, o(2, 3), "c"), 4, 2);
	if (r === 6) {
		if (n === 0) return a(new Set(P(e, t).filter((e) => o(2, 4)(e.z)).map((e) => e.z.id)).size, 4, 2);
		if (n === 1) {
			let n = [
				o(3, 3),
				o(4, 4),
				o(5, 5),
				(e) => e.x === 1,
				(e) => e.x === 3
			];
			return a(t.explored.length + 2 * n.filter((n) => {
				let r = t.explored.filter((t) => n(e.zones.find((e) => e.id === t))).length;
				return r > 0 && e.players.every((t) => t.explored.filter((t) => n(e.zones.find((e) => e.id === t))).length <= r);
			}).length, 0, 0);
		}
		return a(t.explored.includes("lostStar") && t.goals[2] !== null ? F(e, t, (e) => e.id === "lostStar", t.goals[2] === 0 ? "c" : "j") * 3 : 0, 0, 0);
	}
	if (r === 7) return n === 0 ? a((/* @__PURE__ */ new Set([...P(e, t).filter((e) => e.z.x === 2).map((e) => e.z.id), ...t.vessels.filter((t) => e.zones.find((e) => e.id === t).x === 2)])).size * 2, 2, 1, F(e, t, (e) => e.x === 2, "all", !0)) : n === 1 ? a(F(e, t, (e) => e.x !== 2, "c") + F(e, t, (e) => e.x !== 2, "j"), 6, 3) : a(0, 4, 2, j[r].hexes.filter((e) => e.rescue).reduce((n, r) => n + (e.impact[r.id] ?? []).filter((e) => e === t.rid).length, 0));
	if (r === 8) {
		if (t.goals[n] === null) return a(0, 0, 0);
		if (n === 0) {
			let n = e.zones.find((e) => e.id === "seaStar").x, r = t.goals[0] !== 1;
			return a(new Set(P(e, t).filter((e) => r ? Math.abs(e.z.x - n) <= 1 : Math.abs(e.z.x - n) >= 2).map((e) => e.z.id)).size, 2, 1);
		}
		if (n === 1) return a(F(e, t, t.goals[1] === 1 ? o(4, 5) : o(2, 3)), 2, 1);
		let r = Object.values(N(e, t));
		return a(t.goals[2] === 1 ? Math.min(...r) * 3 : Math.max(...r), 2, 1);
	}
	return r === 9 ? n === 0 ? a(t.cleanup, 2, 1) : n === 1 ? a(F(e, t, o(1, 1), "all", !0), 5, 3) : a(F(e, t, o(2, 3), "c"), 4, 2) : n === 0 ? a(t.firstDeep === 0 ? 4 : t.firstDeep === 1 ? 2 : 0, 0, 0) : n === 1 ? a(t.firstVisit === 0 ? 4 : t.firstVisit === 1 ? 3 : 0, 0, 0) : a(F(e, t, o(4, 5), "j"), 7, 4);
}
function L(e, t) {
	let n = j[e.config.scenario], r = xe(e, t.rid)[2] ?? [], i = n.hexes.reduce((n, i) => {
		let a = i.points;
		return e.config.scenario === 6 && i.column !== void 0 && e.zones.some((e) => e.id === "lostStar" && e.x === i.column) && (a += 2), e.config.scenario === 9 && i.polluted && (a = e.players.some((e) => e.cleanup >= ((i.column ?? 0) + 1) * 2) ? 0 : -2), n + (e.impact[i.id] ?? []).filter((e) => e === t.rid).length * a + (e.config.scenario === 8 && r.includes(i.id) ? 1 : 0);
	}, 0) + (e.config.scenario === 4 ? (e.impact.conserve ?? []).filter((e) => e.startsWith(`${t.rid}:`)).length * 3 : 0), a = [
		0,
		1,
		2
	].map((n) => {
		let r = I(e, t, n), i = e.players.filter((e) => e.rid !== t.rid).map((t) => I(e, t, n).rank), a = Math.max(r.rank, ...i), o = 0;
		return r.rank > 0 && r.rank === a ? o = r.first : r.rank > 0 && i.filter((e) => e === a).length === 1 && r.rank === Math.max(...i.filter((e) => e < a), r.rank) && (o = r.second), r.base + o;
	});
	return [
		Object.values(t.attributes).reduce((e, t) => e + w(t), 0),
		i,
		t.journals.reduce((e, t) => e + x[t.id].points, 0) + t.experts.filter((e) => e.senior).reduce((n, r) => n + Se(e, t, r.id), 0),
		...a,
		Math.floor((t.research + t.discs + t.tokens.reduce((e, t) => e + S[t].research, 0)) / 3)
	];
}
//#endregion
//#region src/games/endeavordeepsea/engine.ts
var Ce = [
	"R",
	"I",
	"C",
	"G"
];
function we(e) {
	let t = e.seed + Math.imul(++e.cursor, 2654435769) >>> 0;
	return t = Math.imul(t ^ t >>> 16, 569420461), t = Math.imul(t ^ t >>> 15, 1935289751), ((t ^ t >>> 15) >>> 0) / 4294967296;
}
function R(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = Math.floor(we(e) * (t + 1));
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
var Te = (e, t) => e.players.find((e) => e.rid === t), z = (e, t) => e.zones.find((e) => e.id === t), B = (e, t, n = {}) => ({
	kind: e,
	owner: t,
	...n
}), V = (e, ...t) => e.effects.unshift(...t), H = (e, t, n, r) => B("reward", e, {
	value: t,
	zone: n,
	source: r
});
function U(e, t, n, r, i) {
	e.log.push({
		kind: t,
		owner: n,
		...r === void 0 ? {} : { value: r },
		...i === void 0 ? {} : { n: i }
	}), e.log.length > 32 && e.log.shift();
}
var Ee = (e) => e.phase === "over" || e.phase === "roundEnd" ? null : e.effects[0]?.owner ?? e.players[e.active].rid, De = (e) => e.phase === "roundEnd" || !!e.effects[0] && [
	"atom",
	"income",
	"prepareDone",
	"setupDone",
	"preparePlayer",
	"turnNext",
	"beginDiscovery",
	"finishDiscovery",
	"returnDive",
	"gainDive",
	"finishConserve",
	"finishJournal",
	"specialArrival"
].includes(e.effects[0].kind);
function Oe(e) {
	!e.tokens.length && e.discard.length && (e.tokens = R(e, e.discard), e.discard = []);
}
function ke(e, t) {
	let n = [];
	for (let r = 0; r < t; r++) Oe(e), e.tokens.length && n.push(e.tokens.shift());
	return n;
}
function Ae(e, t, n, r) {
	let i = {
		id: t,
		x: n,
		depth: r,
		slots: {},
		dives: D[t].dives.map((t) => ke(e, t)),
		linked: [],
		orca: null,
		usedImpact: []
	};
	return e.zones.push(i), t === "orca" && (e.orcas = 5), t === "academy" && (e.badges = [
		0,
		1,
		2,
		3,
		4
	]), i;
}
function je(e) {
	e.phase = "prepare", e.prep = 0, e.players.forEach((e) => e.passed = !1), V(e, B("preparePlayer", e.players[e.start].rid));
}
function W(e, t, n) {
	let r = {
		phase: "setup",
		config: e,
		seed: n >>> 0,
		cursor: 0,
		serial: 0,
		round: 1,
		start: 0,
		active: 0,
		prep: 0,
		mainDone: !1,
		tokenTurn: !1,
		players: t.map((e) => ({
			rid: e,
			attributes: {
				R: 0,
				I: 0,
				C: 0,
				G: 0
			},
			research: 0,
			discs: 0,
			experts: [{
				uid: 0,
				id: 393,
				senior: !0,
				occupied: !0,
				badge: null,
				red: !1
			}],
			vessels: [],
			tokens: [],
			journals: [],
			passed: !1,
			orcas: 0,
			cleanup: 0,
			explored: [],
			firstDeep: null,
			firstVisit: null,
			hexGroup: null,
			goals: [
				null,
				null,
				null
			],
			score: []
		})),
		zones: [],
		oceans: [
			[],
			[],
			[],
			[],
			[]
		],
		tokens: [],
		discard: [],
		journals: [],
		market: [],
		experts: {},
		tier5: [],
		effects: [],
		impact: {},
		orcas: 0,
		badges: [],
		robot: null,
		upgrades: [],
		deepOrder: [],
		visitOrder: [],
		log: []
	};
	r.start = Math.floor(we(r) * t.length), r.active = r.start;
	let i = j[e.scenario];
	r.tokens = R(r, Array.from({ length: 36 }, (e, t) => t % 12)), r.journals = R(r, ve.filter((e) => !e.anchor).map((e) => e.id)), r.market = R(r, ve.filter((e) => e.anchor).map((e) => e.id)).slice(0, 4);
	let a = i.setup.map((e) => e[0]), o = E.filter((t) => t.depth <= i.maxDepth && (!t.scenarioOnly || a.includes(t.id)) && (t.id !== "orca" || e.orca) && (t.id !== "academy" || e.academy) && (t.id !== "robot" || e.robot));
	e.scenario === 6 && o.push(D.lostStar), e.scenario === 8 && o.push(D.seaStar, D.lookingGlass);
	for (let e = 1; e <= 5; e++) r.oceans[e - 1] = R(r, o.filter((t) => t.depth === e && !a.includes(t.id)).map((e) => e.id));
	for (let [e, t, n] of i.setup) Ae(r, e, t, n);
	e.scenario === 8 && (r.oceans[0] = r.oceans[0].filter((e) => e !== "seaStar"), R(r, ["seaStar", ...r.oceans[0].splice(0, 4)]).forEach((e, t) => Ae(r, e, t, 1)));
	for (let [e, t] of i.random) {
		let n = r.oceans[t - 1].shift();
		n && Ae(r, n, e, t);
	}
	if (e.scenario === 6) {
		r.oceans[3] = r.oceans[3].filter((e) => e !== "lostStar");
		let e = r.oceans[4];
		e.splice(Math.floor(we(r) * Math.min(e.length + 1, t.length <= 2 ? 4 : e.length + 1)), 0, "lostStar");
	}
	for (let e of ge.filter((e) => e.tier >= 1 && e.tier <= 4)) r.experts[e.id] = e.count;
	let s = R(r, ge.filter((e) => e.tier === 5).map((e) => e.id));
	r.tier5 = [
		s.slice(0, 3),
		s.slice(3, 6),
		s.slice(6, 9)
	], e.scenario === 9 && r.players.forEach((e) => e.cleanup = 0), r.zones.some((e) => e.id === "robot") && r.effects.push(B("robotPlace", r.players[r.start].rid, { zone: "robot" }));
	for (let e = 0; e < t.length; e++) r.effects.push(B("launch", r.players[(r.start + e) % t.length].rid));
	return r.effects.push(B("setupDone", r.players[r.start].rid)), r;
}
function Me(e, t, n) {
	let r = e.players.findIndex((e) => e.rid === n);
	return Array.from({ length: e.players.length }, (t, n) => e.players[(r + n) % e.players.length].rid).filter((e) => t.includes(e));
}
function Ne(e, t, n) {
	let r = D[t.id], i = {};
	return r.links.forEach((e, n) => {
		if (!t.linked.includes(n) && t.slots[e.a] && t.slots[e.b]) {
			t.linked.push(n);
			for (let n of /* @__PURE__ */ new Set([t.slots[e.a], t.slots[e.b]])) (i[n] ??= []).push(e.reward);
		}
	}), Me(e, Object.keys(i), n).map((e) => H(e, i[e].join(" "), t.id, "link"));
}
function Pe(e, t, n) {
	return t.vessels.includes(n.id) ? !0 : n.id === "cave" && t.vessels.some((t) => {
		let r = z(e, t);
		return r.depth === n.depth && Math.abs(r.x - n.x) === 1 || r.depth === n.depth - 1 && r.x === n.x;
	});
}
function Fe(e, t, n, r) {
	return r.zone && [
		"fixed",
		"freeJournal",
		"whale",
		"turtleDone"
	].includes(r.source ?? "") ? n.id === r.zone : r.value === "conserveDepth" && t.vessels.some((t) => z(e, t).depth === n.depth) ? !0 : Pe(e, t, n) || t.vessels.includes("robot") && e.robot === n.id;
}
var Ie = (e, t, n) => t.vessels.includes("robot") && e.robot === n.id;
function Le(e, t, n, r, i = 5) {
	let a = z(e, t.vessels[n]);
	return e.zones.filter((n) => {
		if (n.id === a.id || n.id === "cave" || n.id === "trench" && t.vessels.includes(n.id)) return !1;
		let o = C(t.attributes.G) + r + Number(a.id === "vortex" || n.id === "vortex"), s = Math.min(5, i, o);
		if (n.depth > s) return !1;
		let c = /* @__PURE__ */ new Map([[a.id, 0]]), l = [a];
		for (let t = 0; t < l.length; t++) for (let r of e.zones) {
			let e = c.get(l[t].id) + 1;
			if (!(r.id === "cave" || r.depth > s || e > o || Math.abs(l[t].x - r.x) + Math.abs(l[t].depth - r.depth) !== 1 || c.has(r.id))) {
				if (r.id === n.id) return !0;
				c.set(r.id, e), l.push(r);
			}
		}
		return !1;
	}).map((e) => e.id);
}
function Re(e) {
	let t = y[e.id], n = e.senior ? t.seniorActions : t.actions;
	if (e.badge === null) return n;
	let r = ye[e.badge];
	if (e.red) return (n.length ? n : [[]]).map((e) => [...e, r]);
	let i = n.flatMap((e) => e.map((t, n) => e.map((e, t) => n === t ? r : e)));
	return n.length || i.push([r]), [...n, ...i].filter((e, t, n) => n.findIndex((t) => t.join() === e.join()) === t);
}
function ze(e, t, n) {
	let r = j[e.config.scenario];
	return t > r.maxDepth || e.config.scenario === 9 && t >= 3 && e.players.every((e) => e.cleanup < (t === 3 ? 2 : 5)) ? [] : Array.from({ length: r.columns }, (e, t) => t).filter((r) => !e.zones.some((e) => e.x === r && e.depth === t) && (t === 1 || e.zones.some((e) => e.x === r && e.depth === t - 1) || n === "vortex" && t === 3 || n === "plain" && t === 5));
}
function Be(e, t) {
	let [n, r] = (t.value ?? "1-5").split("-").map(Number), i = [
		1,
		2,
		3,
		4,
		5
	].filter((i) => i >= n && i <= r && e.oceans[i - 1].length && ze(e, i, t.source).length);
	if (!i.length) {
		let n = [
			1,
			2,
			3,
			4,
			5
		].find((n) => e.oceans[n - 1].length && ze(e, n, t.source).length);
		n && (i = [n]);
	}
	return i;
}
function Ve(e, t, n) {
	let r = j[e.config.scenario].hexes, i = r.filter((t) => (e.impact[t.id] ?? []).length), a = r.filter((n) => (e.impact[n.id] ?? []).includes(t.rid)), o = [];
	e.config.scenario === 4 && n.source === "conserve" && n.zone && !z(e, n.zone).usedImpact.includes(t.rid) && o.push({
		id: "impact:conserve",
		kind: "impact",
		hex: "conserve",
		score: 3
	});
	for (let s of r) {
		if (!s.infinite && (e.impact[s.id] ?? []).length || e.config.scenario === 4 && s.points === 3 || e.config.scenario === 5 && t.hexGroup !== null && s.group !== t.hexGroup || e.config.scenario === 7 && s.rescue && n.zone !== "lostStar" || e.config.scenario === 8 && s.infinite && r.some((t) => !t.infinite && !(e.impact[t.id] ?? []).length) || e.config.scenario === 9 && s.infinite && n.source !== "conserve") continue;
		if (e.config.scenario === 10) {
			let t = n.zone ? z(e, n.zone)?.depth : 0;
			if (s.depth && t && s.depth !== t) continue;
			if (s.infinite) {
				if (![
					1,
					2,
					3,
					4,
					5
				].filter((e) => (!t || t === e) && (s.y < 5 ? e <= 3 : e >= 4)).some((t) => r.filter((e) => e.depth === t).every((t) => (e.impact[t.id] ?? []).length))) continue;
			} else if (!s.entry && !r.some((t) => t.depth === s.depth && t.x < s.x && Math.abs(t.x - s.x) < 1.13 && (e.impact[t.id] ?? []).length)) continue;
		}
		let c = i.some((e) => M(s, e));
		if (e.config.scenario === 6) {
			if (s.points && !e.players.some((e) => e.explored.includes("lostStar"))) continue;
			let t = a.filter((t) => (!t.points || r.some((n) => n.column === t.column && n.points > t.points && !(e.impact[n.id] ?? []).length)) && r.some((n) => !(e.impact[n.id] ?? []).length && M(t, n) && (!n.points || e.players.some((e) => e.explored.includes("lostStar")))));
			if (t.length) {
				for (let e of t) M(e, s) && o.push({
					id: `impact:${e.id}:${s.id}`,
					kind: "impact",
					hex: s.id,
					value: e.id,
					score: s.points + 2
				});
				continue;
			}
		}
		(s.entry || c || e.config.scenario === 9 && s.infinite || e.config.scenario === 10 && s.infinite || e.config.scenario === 8 && s.infinite) && o.push({
			id: `impact:${s.id}`,
			kind: "impact",
			hex: s.id,
			score: Math.max(0, s.points) + (s.reward ? 1.5 : 0) + (s.field ? 1.5 : 0)
		});
	}
	return o;
}
function G(e, t = {}) {
	return {
		id: e,
		kind: e,
		score: 1,
		...t
	};
}
function He(e, t) {
	if (Ee(e) !== t || De(e)) return [];
	let n = Te(e, t), r = e.effects[0], i = [];
	if (r) {
		switch (r.kind) {
			case "reward":
				i.push(G("accept", {
					value: r.value,
					zone: r.zone,
					score: 5
				}));
				break;
			case "launch":
				for (let t of e.zones) (j[e.config.scenario].launch === "surface" || e.config.scenario === 7 && n.vessels.length > 0 ? t.depth === 1 : t.id === j[e.config.scenario].launch) && t.id !== "cave" && i.push(G("launch", {
					id: `launch:${t.id}`,
					zone: t.id,
					score: D[t.id].arrival === "d1" ? 3 : 2
				}));
				return e.phase !== "setup" && i.push(G("skip")), i;
			case "recruit": {
				let t = [...ge.filter((t) => t.tier >= 1 && t.tier <= 4 && e.experts[t.id] > 0).map((e) => e.id), ...e.tier5.flatMap((e) => e.slice(0, 1))];
				for (let e of t) y[e].tier <= C(n.attributes.R) && i.push(G("recruit", {
					id: `recruit:${e}`,
					expert: e,
					score: y[e].tier * 1.5 + y[e].junior.length / 4
				}));
				return i.length ? i : [G("skip")];
			}
			case "refillExpert": return e.tier5.forEach((e, t) => {
				e.length > 1 && i.push(G("refillExpert", {
					id: `refillExpert:${t}`,
					n: t,
					expert: e[0],
					score: 1
				}));
			}), i;
			case "reassign":
				for (let e of n.experts) e.occupied && i.push(G("reassign", {
					id: `reassign:${e.uid}`,
					expert: e.uid,
					score: Math.max(1, ...Re(e).map((e) => e.length)) * 2
				}));
				break;
			case "attribute":
				for (let e of Ce) (r.value !== "lowest" || n.attributes[e] === Math.min(...Object.values(n.attributes))) && i.push(G("attribute", {
					id: `attribute:${e}`,
					value: e,
					score: (n.attributes[e] === 1 || n.attributes[e] === 3 || n.attributes[e] === 6 || n.attributes[e] === 9 ? 3 : 1) + (e === "G" ? .5 : 0)
				}));
				break;
			case "promote":
				for (let e of n.experts) e.senior || i.push(G("promote", {
					id: `promote:${e.uid}`,
					expert: e.uid,
					score: y[e.id].tier + Number(e.occupied) * 2 + Number(Re({
						...e,
						senior: !0
					}).length > 0)
				}));
				break;
			case "impact":
				i.push(...Ve(e, n, r));
				break;
			case "order":
				(r.value ?? "").split(",").filter(Boolean).forEach((e, t) => i.push(G("order", {
					id: `order:${t}`,
					n: t,
					value: e,
					score: e === "sail" ? 1.2 : 2
				})));
				break;
			case "copy":
				for (let e of n.experts) e.uid !== r.extra && Re(e).filter((e) => !e.includes("copy")).forEach((t, n) => i.push(G("copy", {
					id: `copy:${e.uid}:${n}`,
					expert: e.uid,
					n,
					value: t.join(","),
					score: t.length * 2
				})));
				break;
			case "sail":
				n.vessels.forEach((t, a) => {
					for (let t of Le(e, n, a, r.n ?? 0, r.extra ?? 5)) i.push(G("sail", {
						id: `sail:${a}:${t}`,
						n: a,
						zone: t,
						score: 1 + (D[t].arrival.length || 0) / 3 + Number(!n.vessels.includes(t)) * .5
					}));
				});
				break;
			case "sonar":
				for (let t of e.zones) if (Fe(e, n, t, r)) {
					let r = Ie(e, n, t) && e.upgrades.includes("sonar");
					if (!n.discs && !r) continue;
					for (let e of D[t.id].sites) e.kind === "sonar" && !t.slots[e.id] && !D[t.id].sites.some((n) => n.track === e.track && n.kind === "sonar" && n.id < e.id && !t.slots[n.id]) && i.push(G("sonar", {
						id: `sonar:${t.id}:${e.id}`,
						zone: t.id,
						value: e.id,
						score: e.reward.startsWith("x") ? 4 : 3
					}));
				}
				break;
			case "dive":
				for (let t of e.zones) Fe(e, n, t, r) && t.dives.forEach((e, n) => {
					e.length && i.push(G("dive", {
						id: `dive:${t.id}:${n}`,
						zone: t.id,
						n,
						score: 2 + Number([
							"sharks",
							"brine",
							"lostStar",
							"snails"
						].includes(t.id))
					}));
				});
				break;
			case "divePick":
				for (let e = 0; e < (r.cards?.length ?? 0); e++) i.push(G("divePick", {
					id: `divePick:${e}`,
					n: e,
					value: r.cards[e],
					score: S[Number(r.cards[e])].research
				}));
				return i;
			case "conserve":
				for (let t of e.zones) if (Fe(e, n, t, r)) {
					for (let a of D[t.id].sites) if (a.kind === "conserve" && !t.slots[a.id]) {
						let o = Math.max(0, a.cost - +(r.value === "conserveCheap") - (Ie(e, n, t) && e.upgrades.includes("conserve") ? 1 : 0)), s = e.config.scenario === 9 ? 0 : 1;
						if (n.discs < s) continue;
						let c = n.orcas > 0 && !t.orca;
						n.research >= o && i.push(G("conserve", {
							id: `conserve:${t.id}:${a.id}`,
							zone: t.id,
							value: a.id,
							n: o,
							score: 3 + a.reward.length / 3 - o * .2
						})), c && i.push(G("conserve", {
							id: `orcaConserve:${t.id}:${a.id}`,
							zone: t.id,
							value: a.id,
							n: 0,
							card: 1,
							score: 4 + a.reward.length / 3
						}));
					}
				}
				break;
			case "journal":
				if (n.discs) {
					for (let t of e.zones) if (Fe(e, n, t, r)) {
						for (let r of D[t.id].sites) if (r.kind === "journal" && !t.slots[r.id]) for (let a of e.market) {
							let o = x[a];
							o.cost <= n.research && (o.fields.includes(r.field) || Ie(e, n, t) && e.upgrades.includes("journal")) && i.push(G("journal", {
								id: `journal:${t.id}:${r.id}:${a}`,
								zone: t.id,
								value: r.id,
								card: a,
								field: r.field,
								score: 4 + o.points * .3 + o.you.length * .1 - o.cost * .1
							}));
						}
					}
				}
				break;
			case "discover": {
				let t = Be(e, r);
				for (let n = 0; n < t.length; n++) for (let r = n; r < t.length; r++) (n !== r || e.oceans[t[n] - 1].length >= 2 || t.length === 1) && i.push(G("draw", {
					id: `draw:${t[n]}:${t[r]}`,
					value: `${t[n]},${t[r]}`,
					score: t[n] + t[r]
				}));
				t.length || i.push(G("fullOcean", { score: 3 }));
				break;
			}
			case "relocateOcean":
				for (let t of ze(e, 2)) i.push(G("relocateOcean", {
					id: `relocate:${t}`,
					zone: r.zone,
					n: t
				}));
				return i;
			case "placeOcean":
				for (let t = 0; t < (r.cards?.length ?? 0); t++) for (let n of ze(e, r.depths[t], r.source)) i.push(G("placeOcean", {
					id: `place:${t}:${n}`,
					card: t,
					n,
					zone: r.cards[t],
					score: r.depths[t] + Number(D[r.cards[t]].arrival.includes("G")) * .5
				}));
				return i;
			case "robotPlace":
			case "robotMove":
				for (let t of e.zones) t.id !== "cave" && (r.kind === "robotPlace" || t.id !== e.robot && t.depth <= C(n.attributes.G)) && i.push(G(r.kind, {
					id: `${r.kind}:${t.id}`,
					zone: t.id,
					score: t.depth + Number(D[t.id].sites.some((e) => !t.slots[e.id]))
				}));
				break;
			case "upgrade":
				for (let t of [
					"sonar",
					"dive",
					"conserve",
					"journal"
				]) e.upgrades.includes(t) || i.push(G("upgrade", {
					id: `upgrade:${t}`,
					value: t,
					score: t === "sonar" ? 3 : 2
				}));
				break;
			case "badge":
				for (let t of e.badges) for (let e of n.experts) y[e.id].tier >= 1 && y[e.id].tier <= 2 && e.badge === null && i.push(G("badge", {
					id: `badge:${t}:${e.uid}`,
					n: t,
					expert: e.uid,
					score: 2
				}));
				break;
			case "badgeUpgrade":
				for (let e of n.experts) e.badge !== null && !e.red && i.push(G("badgeUpgrade", {
					id: `badgeUpgrade:${e.uid}`,
					expert: e.uid,
					score: 3
				}));
				break;
			case "goal": return i.push(G("goal", {
				id: "goal:0",
				n: 0,
				score: 1
			}), G("goal", {
				id: "goal:1",
				n: 1,
				score: 1
			})), i;
			case "tradeDisc": n.discs && i.push(G("tradeDisc", { score: n.research < 8 ? 3 : 1 }));
		}
		i.push(G("skip", { score: -10 }));
	} else if (e.phase === "playing") {
		if (!e.mainDone && !n.passed) {
			if (n.discs) for (let e of n.experts) e.occupied || Re(e).forEach((t, n) => i.push(G("activate", {
				id: `activate:${e.uid}:${n}`,
				expert: e.uid,
				n,
				value: t.join(","),
				score: t.length * 2 + Number(t.includes("conserve") || t.includes("sonar") || t.includes("journal"))
			})));
			if (n.discs) for (let e of n.journals) x[e.id].actions.forEach((t, n) => {
				e.used.includes(n) || i.push(G("journalAction", {
					id: `journalAction:${e.id}:${n}`,
					card: e.id,
					n,
					value: t,
					score: 2
				}));
			});
			i.push(G("pass", { score: -8 }));
		}
		(e.mainDone || e.tokenTurn) && n.tokens.length <= 2 && i.push(G("end", { score: 0 }));
	}
	return e.phase === "playing" && t === e.players[e.active].rid && (!r || ![
		"placeOcean",
		"relocateOcean",
		"divePick",
		"launch",
		"goal",
		"refillExpert"
	].includes(r.kind)) && n.tokens.forEach((e, t) => {
		i.push(G("tokenResearch", {
			id: `tokenResearch:${t}`,
			n: t,
			card: e,
			score: n.research < 5 ? 3 : -1
		})), S[e].effect && i.push(G("tokenEffect", {
			id: `tokenEffect:${t}`,
			n: t,
			card: e,
			value: S[e].effect,
			score: 1.5
		})), i.push(G("tokenDiscard", {
			id: `tokenDiscard:${t}`,
			n: t,
			card: e,
			score: -12
		}));
	}), i;
}
function Ue(e, t, n, r) {
	return t.split(/\s+/).filter(Boolean).map((t) => B("atom", e, {
		value: t,
		zone: n,
		source: r
	}));
}
function We(e, t, n) {
	return t.id === "academy" ? [B("badgeUpgrade", n, { zone: t.id })] : [];
}
function Ge(e, t, n, r) {
	let i = [];
	return r && r.id === "jellyfish" && Object.values(r.slots).includes(t.rid) && i.push(H(t.rid, "h1", r.id, "sail")), r && n.id === "jellyfish" && Object.values(n.slots).includes(t.rid) && i.push(H(t.rid, "h1", n.id, "sail")), n.depth === 5 && t.firstVisit === null && (t.firstVisit = e.visitOrder.length, e.visitOrder.push(t.rid)), i.push(H(t.rid, D[n.id].arrival, n.id, "arrival")), i;
}
function Ke(e, t) {
	let n = Te(e, t.owner), r = t.value ?? "", i = /^([RICGrdphal])(\d+)$/.exec(r);
	if (i) {
		let [, r, a] = i, o = Number(a);
		if (Ce.includes(r)) {
			let i = r, a = n.attributes[i], s = 0;
			for (let e = 0; e < o; e++) n.attributes[i] = Math.min(12, n.attributes[i] + 1), n.attributes[i] >= 10 && s++;
			let c = [];
			if (i === "G") for (let e of [2, 7]) a < e && n.attributes.G >= e && c.push(B("launch", n.rid));
			s && c.push(B("impact", n.rid, {
				n: s,
				zone: t.zone,
				source: t.source
			})), V(e, ...c);
		} else r === "r" ? n.research = Math.min(12, n.research + o) : r === "d" ? n.discs += o : r === "h" ? V(e, B("impact", n.rid, {
			n: o,
			zone: t.zone,
			source: t.source
		})) : r === "p" ? V(e, ...Array.from({ length: o }, () => B("promote", n.rid, { zone: t.zone }))) : (r === "a" || r === "l") && V(e, ...Array.from({ length: o }, () => B("attribute", n.rid, {
			value: r === "l" ? "lowest" : "any",
			zone: t.zone,
			source: t.source
		})));
		return;
	}
	r.startsWith("x") ? V(e, B("discover", n.rid, {
		value: r.slice(1),
		zone: t.zone,
		source: t.source === "vortex" || t.source === "plain" ? t.source : void 0
	})) : r === "orca" ? e.orcas && (e.orcas--, n.orcas++) : r === "badge" ? V(e, B("badge", n.rid, { zone: t.zone })) : r === "robotMove" ? V(e, B("robotMove", n.rid, { zone: t.zone })) : r === "sailPlus" ? V(e, B("sail", n.rid, {
		n: 1,
		zone: t.zone
	})) : r === "dive2" ? V(e, B("dive", n.rid, {
		n: 2,
		zone: t.zone
	})) : r === "conserveDepth" || r === "conserveCheap" ? V(e, B("conserve", n.rid, {
		value: r,
		zone: t.zone
	})) : V(e, B(r, n.rid, {
		zone: t.zone,
		source: t.zone === "trench" && r === "sonar" ? "fixed" : void 0
	}));
}
function qe(e) {
	if (e.players.every((e) => e.passed)) {
		e.phase = "roundEnd";
		return;
	}
	do
		e.active = (e.active + 1) % e.players.length;
	while (e.players[e.active].passed);
	e.mainDone = !1, e.tokenTurn = !1;
}
function Je(e) {
	if (e.phase === "roundEnd") {
		if (e.round === 6) {
			e.phase = "over", e.players.forEach((t) => t.score = L(e, t));
			return;
		}
		e.round++, e.start = (e.start + 1) % e.players.length, e.active = e.start, je(e);
		return;
	}
	let t = e.effects.shift();
	if (!t) return;
	let n = Te(e, t.owner);
	switch (t.kind) {
		case "atom":
			Ke(e, t);
			break;
		case "setupDone":
			je(e);
			break;
		case "preparePlayer": {
			let t = e.players[(e.start + e.prep) % e.players.length].rid;
			e.active = (e.start + e.prep) % e.players.length, V(e, B("recruit", t), B("income", t), B("reassign", t, { n: -1 }), B("prepareDone", t));
			break;
		}
		case "income":
			n.discs += C(n.attributes.I);
			break;
		case "prepareDone":
			e.prep++, e.prep < e.players.length ? V(e, B("preparePlayer", e.players[(e.start + e.prep) % e.players.length].rid)) : (e.phase = "playing", e.active = e.start, e.mainDone = !1, e.tokenTurn = !1);
			break;
		case "turnNext":
			qe(e);
			break;
		case "beginDiscovery": {
			let r = t.depths, i = [], a = [];
			for (let t of r) {
				let n = e.oceans[t - 1].shift();
				n && (i.push(n), a.push(t));
			}
			V(e, B("placeOcean", n.rid, {
				cards: i,
				depths: a,
				source: t.source,
				zone: t.zone
			}));
			break;
		}
		case "gainDive": {
			let r = z(e, t.zone), i = t.extra ?? 0, a = Math.min(t.n ?? 1, r.dives[i].length), o = Ie(e, n, r) && e.upgrades.includes("dive");
			if (!a) break;
			if (o) {
				V(e, B("divePick", n.rid, {
					cards: r.dives[i].map(String),
					zone: r.id,
					extra: i,
					n: a
				}));
				break;
			}
			let s = r.id === "wreck" ? r.dives[i].splice(0, Math.min(2, r.dives[i].length)) : r.dives[i].splice(0, a);
			if (r.id === "wreck" && s.length > 1) {
				V(e, B("divePick", n.rid, {
					cards: s.map(String),
					zone: r.id,
					extra: i,
					n: a,
					source: "wreck"
				}));
				break;
			}
			n.tokens.push(...s), Ye(e, n, r, i, s.length);
			break;
		}
		case "finishDiscovery":
			Ze(e, n, t.zone, t.n, t.extra, t.source);
			break;
		case "returnDive": {
			let n = z(e, t.zone);
			n.dives[t.extra ?? 0] = R(e, n.dives[t.extra ?? 0]);
			break;
		}
		case "finishConserve": Xe(e, n, z(e, t.zone), t.value, !!t.extra);
	}
}
function Ye(e, t, n, r, i) {
	let a = [];
	for (let e = 0; e < i; e++) {
		if (["brine", "lostStar"].includes(n.id) && a.push(H(t.rid, "h1", n.id, "dive")), n.id === "sharks" && a.push(H(t.rid, "R1", n.id, "dive")), n.id === "bioluminescence" && a.push(H(t.rid, r === 0 ? "r1" : "d1", n.id, "dive")), n.id === "seamount" && Object.entries(n.slots).some(([e, n]) => e.startsWith("c") && n === t.rid) && a.push(H(t.rid, "l1", n.id, "dive")), n.id === "vents") {
			let e = Object.values(n.slots).filter((e) => e === t.rid).length;
			e && a.push(H(t.rid, `r${e}`, n.id, "dive"));
		}
		n.id === "snails" && a.push(B("journal", t.rid, {
			zone: n.id,
			source: "freeJournal"
		})), n.id === "smokers" && a.push(B("sail", t.rid, { extra: 4 }));
	}
	if (n.id === "ruins" && n.dives.every((e) => !e.length)) for (let r of Me(e, e.players.filter((e) => e.vessels.includes(n.id)).map((e) => e.rid), t.rid)) a.push(B("sail", r));
	a.push(...We(e, n, t.rid)), V(e, ...a);
}
function Xe(e, t, n, r, i) {
	let a = D[n.id].sites.find((e) => e.id === r);
	if (n.slots[r]) return;
	n.slots[r] = t.rid, i && (t.orcas--, n.orca = t.rid), e.config.scenario === 9 && (t.cleanup = Math.min(8, t.cleanup + 1));
	let o = [H(t.rid, a.reward, n.id, "conserve"), ...Ne(e, n, t.rid)];
	if (n.id === "rig" && D[n.id].sites.filter((e) => e.kind === "conserve").every((e) => n.slots[e.id])) for (let r of Me(e, e.players.filter((e) => e.vessels.includes(n.id)).map((e) => e.rid), t.rid)) o.push(B("promote", r, { zone: n.id }));
	n.id === "whales" && n.slots.j0 === t.rid && o.push(B("conserve", t.rid, {
		zone: n.id,
		source: "whale"
	})), o.push(...We(e, n, t.rid)), V(e, ...o), U(e, "conserve", t.rid, n.id);
}
function Ze(e, t, n, r, i, a) {
	let o = Ae(e, n, r, i);
	t.explored.push(n), i === 5 && t.firstDeep === null && (t.firstDeep = e.deepOrder.length, e.deepOrder.push(t.rid));
	let s = [];
	e.config.scenario === 6 && n === "lostStar" && s.push(B("goal", t.rid, { n: 2 })), s.push(H(t.rid, D[n].discovery, n, "discovery")), a === "orca" && D[n].sites.some((e) => e.kind === "conserve") && s.push(H(t.rid, "R1", n, "discovery")), n === "robot" && s.push(B("robotPlace", t.rid, { zone: n })), V(e, ...s), U(e, "discovery", t.rid, o.id);
}
function Qe(e, t, n) {
	let r = Te(e, t), i = e.effects[0];
	if (n.kind.startsWith("token")) {
		let i = r.tokens.splice(n.n, 1)[0];
		e.discard.push(i), e.tokenTurn = !0, n.kind === "tokenResearch" && V(e, H(t, `r${S[i].research}`)), n.kind === "tokenEffect" && V(e, ...Ue(t, S[i].effect)), U(e, n.kind, t, void 0, i);
		return;
	}
	if (i && e.effects.shift(), n.kind !== "skip") switch (n.kind) {
		case "accept":
			V(e, ...Ue(t, i.value ?? "", i.zone, i.source));
			break;
		case "launch":
			r.vessels.push(n.zone), V(e, ...Ge(e, r, z(e, n.zone)));
			break;
		case "recruit": {
			let i = n.expert, a = y[i];
			if (a.tier === 5) {
				let n = e.tier5.find((e) => e[0] === i);
				n.shift(), !n.length && e.tier5.some((e) => e.length > 1) && V(e, B("refillExpert", t, { n: e.tier5.indexOf(n) }));
			} else e.experts[i]--;
			r.experts.push({
				uid: ++e.serial,
				id: i,
				senior: !1,
				occupied: !1,
				badge: null,
				red: !1
			}), V(e, H(t, a.junior)), U(e, "recruit", t, String(i));
			break;
		}
		case "refillExpert":
			e.tier5[i.n].push(e.tier5[n.n].shift());
			break;
		case "reassign": {
			r.experts.find((e) => e.uid === n.expert).occupied = !1, r.discs++;
			let a = i.n === -1 ? C(r.attributes.C) : i.n;
			a > 1 && r.experts.some((e) => e.occupied) && V(e, B("reassign", t, { n: a - 1 }));
			break;
		}
		case "attribute":
			V(e, B("atom", t, {
				value: `${n.value}1`,
				zone: i.zone,
				source: i.source
			}));
			break;
		case "promote": {
			let a = r.experts.find((e) => e.uid === n.expert);
			a.senior = !0, a.occupied = !1, V(e, H(t, y[a.id].senior, i.zone)), U(e, "promote", t, String(a.id));
			break;
		}
		case "activate": {
			let i = r.experts.find((e) => e.uid === n.expert);
			i.occupied = !0, r.discs--, e.mainDone = !0, V(e, B("order", t, {
				value: n.value,
				extra: i.uid
			})), U(e, "activate", t, String(i.id));
			break;
		}
		case "journalAction":
			r.journals.find((e) => e.id === n.card).used.push(n.n), r.discs--, e.mainDone = !0, V(e, ...Ue(t, n.value)), U(e, "journalAction", t, String(n.card));
			break;
		case "order": {
			let r = i.value.split(","), a = r.splice(n.n, 1)[0];
			r.length && V(e, B("order", t, {
				value: r.join(","),
				extra: i.extra
			})), V(e, B(a, t, { extra: a === "copy" ? i.extra : void 0 }));
			break;
		}
		case "copy":
			V(e, B("order", t, { value: n.value }));
			break;
		case "sail": {
			let i = z(e, r.vessels[n.n]), a = z(e, n.zone);
			r.vessels[n.n] = n.zone, V(e, ...Ge(e, r, a, i)), U(e, "sail", t, a.id);
			break;
		}
		case "sonar": {
			let i = z(e, n.zone), a = D[i.id].sites.find((e) => e.id === n.value);
			Ie(e, r, i) && e.upgrades.includes("sonar") || r.discs--, i.slots[a.id] = t, V(e, H(t, a.reward, i.id, i.id === "vortex" && a.id === "s0-0" ? "vortex" : i.id === "plain" ? "plain" : "sonar"), ...Ne(e, i, t), ...We(e, i, t)), U(e, "sonar", t, i.id);
			break;
		}
		case "dive":
			V(e, B("gainDive", t, {
				zone: n.zone,
				n: i.n ?? 1,
				extra: n.n
			})), U(e, "dive", t, n.zone);
			break;
		case "divePick": {
			let a = z(e, i.zone), o = i.extra ?? 0, s = Number(i.cards[n.n]);
			if (r.tokens.push(s), i.source === "wreck") {
				let r = i.cards.map(Number);
				r.splice(n.n, 1), e.discard.push(...r), (i.n ?? 1) > 1 && a.dives[o].length && V(e, B("gainDive", t, {
					zone: a.id,
					n: i.n - 1,
					extra: o
				}));
			} else a.dives[o].splice(a.dives[o].indexOf(s), 1), a.dives[o] = R(e, a.dives[o]), (i.n ?? 1) > 1 && a.dives[o].length && V(e, B("gainDive", t, {
				zone: a.id,
				n: i.n - 1,
				extra: o
			}));
			Ye(e, r, a, o, 1);
			break;
		}
		case "conserve": {
			let a = z(e, n.zone);
			r.research -= n.n, e.config.scenario !== 9 && r.discs--, a.id === "turtles" && i.source !== "turtleDone" ? V(e, B("sail", t), B("finishConserve", t, {
				zone: a.id,
				value: n.value,
				extra: +!!n.card
			})) : Xe(e, r, a, n.value, !!n.card);
			break;
		}
		case "journal": {
			let i = z(e, n.zone), a = x[n.card];
			r.research -= a.cost, r.discs--, i.slots[n.value] = t, r.journals.push({
				id: a.id,
				used: []
			}), e.market.splice(e.market.indexOf(a.id), 1), e.journals.length && e.market.push(e.journals.shift());
			let o = [H(t, a.you, i.id, "journal")];
			for (let n of Me(e, e.players.filter((e) => e.rid !== t).map((e) => e.rid), t)) a.others && o.push(H(n, a.others, i.id, "journal"));
			o.push(...Ne(e, i, t)), i.id === "robot" && o.push(B("upgrade", t, { zone: i.id })), o.push(...We(e, i, t)), V(e, ...o), U(e, "journal", t, String(a.id));
			break;
		}
		case "draw":
			V(e, B("beginDiscovery", t, {
				depths: n.value.split(",").map(Number),
				source: i.source,
				zone: i.zone
			}));
			break;
		case "fullOcean":
			V(e, H(t, "h1", i.zone, "sonar"));
			break;
		case "placeOcean": {
			let a = i.cards[n.card], o = i.depths[n.card];
			i.cards.forEach((t, r) => {
				r !== n.card && e.oceans[i.depths[r] - 1].push(t);
			});
			let s = n.n;
			if (e.config.scenario === 8 && a === "lookingGlass") {
				s = z(e, "seaStar").x;
				let n = e.zones.find((e) => e.x === s && e.depth === 2);
				if (n) {
					V(e, B("relocateOcean", t, { zone: n.id }), B("finishDiscovery", t, {
						zone: a,
						n: s,
						extra: o,
						source: i.zone
					}));
					break;
				}
			}
			Ze(e, r, a, s, o, i.zone);
			break;
		}
		case "relocateOcean":
			z(e, n.zone).x = n.n;
			break;
		case "impact":
			if (n.hex === "conserve") {
				let n = z(e, i.zone);
				n.usedImpact.push(t), (e.impact.conserve ??= []).push(`${t}:${n.id}`);
			} else {
				let a = j[e.config.scenario].hexes.find((e) => e.id === n.hex);
				if (n.value) {
					let r = e.impact[n.value];
					r.splice(r.indexOf(t), 1);
				}
				(e.impact[a.id] ??= []).push(t), e.config.scenario === 5 && r.hexGroup === null && (r.hexGroup = a.group ?? 0);
				let o = [H(t, a.reward, i.zone, i.source)];
				if (e.config.scenario === 8) {
					let e = a.x * 81, n = a.y * 81, i = n < 260 && e < 130 ? 2 : n > 700 && e < 130 ? 0 : n > 700 && e > 550 ? 1 : -1;
					i >= 0 && r.goals[i] === null && o.push(B("goal", t, { n: i }));
				}
				(i.n ?? 1) > 1 && o.push({
					...i,
					n: i.n - 1
				}), V(e, ...o);
			}
			n.hex === "conserve" && (i.n ?? 1) > 1 && V(e, {
				...i,
				n: i.n - 1
			});
			break;
		case "robotPlace":
			e.robot = n.zone;
			break;
		case "robotMove":
			e.robot = n.zone, V(e, H(t, D[n.zone].arrival, n.zone, "robot"));
			break;
		case "upgrade":
			e.upgrades.push(n.value);
			break;
		case "badge": {
			let t = r.experts.find((e) => e.uid === n.expert);
			t.badge = n.n, e.badges.splice(e.badges.indexOf(n.n), 1);
			break;
		}
		case "badgeUpgrade":
			r.experts.find((e) => e.uid === n.expert).red = !0;
			break;
		case "goal":
			for (let t of e.players) t.goals[i.n] = n.n;
			break;
		case "tradeDisc":
			r.discs--, r.research = Math.min(12, r.research + 5);
			break;
		case "pass":
			r.passed = !0, e.mainDone = !0, U(e, "pass", t);
			break;
		case "end": V(e, B("turnNext", t));
	}
}
//#endregion
//#region src/games/endeavordeepsea/meta.ts
var $e = {
	id: "endeavordeepsea",
	tier: "alpha",
	nameKey: "games.endeavordeepsea.name",
	descKey: "games.endeavordeepsea.desc",
	rulesKey: "games.endeavordeepsea.rules",
	mechanics: [
		"worker-placement",
		"engine-building",
		"tile-placement",
		"grid-movement",
		"set-collection"
	],
	interactionTags: [],
	icon: "🤿",
	iconImg: "games/endeavordeepsea.webp",
	minPlayers: 2,
	maxPlayers: 4,
	accent: "#126b83",
	releasedAt: "2026-10-26T23:02:29+08:00",
	search: {
		py: "fen jin hao shen hai",
		init: "fjhsh"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://www.burntislandgames.com/_files/ugd/69e02c_0ddb009651864556b89ed5ffb6ff5000.pdf" }
}, et = e.object({
	scenario: e.int().min(1).max(10).default(1),
	orca: e.boolean().default(!0),
	academy: e.boolean().default(!0),
	robot: e.boolean().default(!0)
}).default({
	scenario: 1,
	orca: !0,
	academy: !0,
	robot: !0
}), tt = e.discriminatedUnion("type", [e.object({
	type: e.literal("choose"),
	id: e.string().min(1).max(180)
}).strict(), e.object({
	type: e.literal("tick"),
	now: e.number().finite()
}).strict()]), nt = e.object({
	uid: e.int(),
	id: e.int(),
	senior: e.boolean(),
	occupied: e.boolean(),
	badge: e.int().nullable(),
	red: e.boolean()
}), rt = e.object({
	rid: e.string(),
	attributes: e.object({
		R: e.int(),
		I: e.int(),
		C: e.int(),
		G: e.int()
	}),
	research: e.int(),
	discs: e.int(),
	experts: e.array(nt),
	vessels: e.array(e.string()),
	tokens: e.array(e.int()),
	journals: e.array(e.object({
		id: e.int(),
		used: e.array(e.int())
	})),
	passed: e.boolean(),
	orcas: e.int(),
	cleanup: e.int(),
	explored: e.array(e.string()),
	firstDeep: e.int().nullable(),
	firstVisit: e.int().nullable(),
	hexGroup: e.int().nullable(),
	goals: e.array(e.int().nullable()),
	score: e.array(e.int())
}), it = e.object({
	id: e.string(),
	kind: e.string(),
	value: e.string().optional(),
	zone: e.string().optional(),
	expert: e.int().optional(),
	card: e.int().optional(),
	hex: e.string().optional(),
	n: e.number().optional(),
	field: e.enum([
		"blue",
		"brown",
		"green",
		"yellow"
	]).optional(),
	score: e.number()
}), at = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: $e,
	schemas: {
		action: tt,
		config: et,
		publicView: e.object({
			phase: e.enum([
				"setup",
				"prepare",
				"playing",
				"roundEnd",
				"over"
			]),
			config: et,
			round: e.int(),
			start: e.string(),
			active: e.string(),
			acting: e.string().nullable(),
			mainDone: e.boolean(),
			players: e.array(rt),
			zones: e.array(e.object({
				id: e.string(),
				x: e.int(),
				depth: e.int(),
				slots: e.record(e.string(), e.string()),
				dives: e.array(e.int()),
				linked: e.array(e.int()),
				orca: e.string().nullable(),
				usedImpact: e.array(e.string())
			})),
			market: e.array(e.int()),
			oceanCounts: e.array(e.int()),
			tokenCount: e.int(),
			journalCount: e.int(),
			experts: e.record(e.string(), e.int()),
			tier5: e.array(e.int()),
			impact: e.record(e.string(), e.array(e.string())),
			orcas: e.int(),
			badges: e.array(e.int()),
			robot: e.string().nullable(),
			upgrades: e.array(e.string()),
			effect: e.object({
				kind: e.string(),
				owner: e.string(),
				value: e.string().optional(),
				zone: e.string().optional(),
				n: e.int().optional()
			}).nullable(),
			log: e.array(e.object({
				kind: e.string(),
				owner: e.string(),
				value: e.string().optional(),
				n: e.int().optional()
			}))
		}),
		privateView: e.object({
			choices: e.array(it),
			discoveries: e.array(e.string())
		})
	},
	setup(e, t, n) {
		return { state: W(e, t, n) };
	},
	reduce(e, t, { by: n }) {
		let r = tt.safeParse(t);
		if (!r.success) return { code: "games.endeavordeepsea.invalidAction" };
		let i = structuredClone(e);
		if (r.data.type === "tick") return n !== "$engine" || !De(i) ? { code: "games.endeavordeepsea.invalidAction" } : (Je(i), { state: i });
		let a = r.data.id, o = He(i, n).find((e) => e.id === a);
		return o ? (Qe(i, n, o), { state: i }) : { code: "games.endeavordeepsea.invalidAction" };
	},
	viewFor(e, t) {
		let n = e.effects[0];
		return {
			public: {
				phase: e.phase,
				config: e.config,
				round: e.round,
				start: e.players[e.start].rid,
				active: e.players[e.active].rid,
				acting: Ee(e),
				mainDone: e.mainDone,
				players: e.players,
				zones: e.zones.map(({ dives: e, ...t }) => ({
					...t,
					dives: e.map((e) => e.length)
				})),
				market: e.market,
				oceanCounts: e.oceans.map((e) => e.length),
				tokenCount: e.tokens.length,
				journalCount: e.journals.length,
				experts: e.experts,
				tier5: e.tier5.flatMap((e) => e.slice(0, 1)),
				impact: e.impact,
				orcas: e.orcas,
				badges: e.badges,
				robot: e.robot,
				upgrades: e.upgrades,
				effect: n ? {
					kind: n.kind,
					owner: n.owner,
					value: n.value,
					zone: n.zone,
					n: n.n
				} : null,
				log: e.log
			},
			...e.players.some((e) => e.rid === t) ? { private: {
				choices: He(e, t),
				discoveries: n?.owner === t && n.kind === "placeOcean" ? n.cards ?? [] : []
			} } : {}
		};
	},
	status(e) {
		if (e.phase !== "over") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((e) => [e.rid, e.score.reduce((e, t) => e + t, 0)])), n = e.players.map((e) => e.rid).sort((e, n) => t[n] - t[e]);
		return {
			phase: e.phase,
			scores: t,
			ranking: n,
			winner: n.filter((e) => t[e] === t[n[0]])
		};
	},
	nextTickIn(e) {
		return De(e) ? 140 : null;
	}
}, ot = "<defs>\n<linearGradient id=\"sea1\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#72cbd5\"/><stop offset=\".54\" stop-color=\"#8bd6dc\"/><stop offset=\".545\" stop-color=\"#00b6d0\"/><stop offset=\"1\" stop-color=\"#007d9e\"/></linearGradient>\n<linearGradient id=\"sea2\" x1=\"0\" y1=\"0\" x2=\".2\" y2=\"1\"><stop stop-color=\"#00b6d4\"/><stop offset=\".44\" stop-color=\"#0088b4\"/><stop offset=\"1\" stop-color=\"#024e83\"/></linearGradient>\n<linearGradient id=\"sea3\" x1=\"0\" y1=\"0\" x2=\".2\" y2=\"1\"><stop stop-color=\"#046b94\"/><stop offset=\".5\" stop-color=\"#064c7a\"/><stop offset=\"1\" stop-color=\"#082748\"/></linearGradient>\n<linearGradient id=\"sea4\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#073350\"/><stop offset=\".6\" stop-color=\"#031930\"/><stop offset=\"1\" stop-color=\"#020e20\"/></linearGradient>\n<linearGradient id=\"sea5\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#111d42\"/><stop offset=\".65\" stop-color=\"#080e29\"/><stop offset=\"1\" stop-color=\"#03091a\"/></linearGradient>\n<linearGradient id=\"mapSea\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#e0e4d7\"/><stop offset=\".3\" stop-color=\"#bdd2d0\"/><stop offset=\"1\" stop-color=\"#728f9e\"/></linearGradient>\n<linearGradient id=\"steel\" x1=\"0\" y1=\"0\" x2=\".1\" y2=\"1\"><stop stop-color=\"#dfebeb\"/><stop offset=\".18\" stop-color=\"#b0bcc6\"/><stop offset=\".54\" stop-color=\"#6f899e\"/><stop offset=\".58\" stop-color=\"#c1cbd0\"/><stop offset=\"1\" stop-color=\"#546d84\"/></linearGradient>\n<linearGradient id=\"hull\" x1=\"0\" y1=\"0\" x2=\".2\" y2=\"1\"><stop stop-color=\"#8fa8b9\"/><stop offset=\".46\" stop-color=\"#bdcbd0\"/><stop offset=\".48\" stop-color=\"#f1c657\"/><stop offset=\".62\" stop-color=\"#e8bb45\"/><stop offset=\".64\" stop-color=\"#59758c\"/><stop offset=\"1\" stop-color=\"#2b526e\"/></linearGradient>\n<linearGradient id=\"window\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#145e77\"/><stop offset=\".48\" stop-color=\"#45c8cc\"/><stop offset=\".54\" stop-color=\"#c5f4df\"/><stop offset=\".69\" stop-color=\"#4ecac9\"/><stop offset=\"1\" stop-color=\"#277c93\"/></linearGradient>\n<linearGradient id=\"metalGold\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#f0d98e\"/><stop offset=\".24\" stop-color=\"#c4a04f\"/><stop offset=\".72\" stop-color=\"#a47b2e\"/><stop offset=\"1\" stop-color=\"#dfc078\"/></linearGradient>\n<linearGradient id=\"mat\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#212540\"/><stop offset=\".55\" stop-color=\"#151c31\"/><stop offset=\"1\" stop-color=\"#0f273a\"/></linearGradient>\n<linearGradient id=\"tealCard\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#1f7279\"/><stop offset=\".48\" stop-color=\"#145161\"/><stop offset=\"1\" stop-color=\"#10374c\"/></linearGradient>\n<linearGradient id=\"goldCard\" x1=\"0\" y1=\"0\" x2=\".7\" y2=\"1\"><stop stop-color=\"#cead63\"/><stop offset=\".38\" stop-color=\"#a7833d\"/><stop offset=\"1\" stop-color=\"#725329\"/></linearGradient>\n<linearGradient id=\"paper\" x1=\"0\" y1=\"0\" x2=\".7\" y2=\"1\"><stop stop-color=\"#fffaf0\"/><stop offset=\".8\" stop-color=\"#f3e8c9\"/><stop offset=\"1\" stop-color=\"#d8c99e\"/></linearGradient>\n<linearGradient id=\"enamel\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#227d90\"/><stop offset=\".48\" stop-color=\"#16687c\"/><stop offset=\"1\" stop-color=\"#124a61\"/></linearGradient>\n<linearGradient id=\"portraitWarm\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#efb15c\"/><stop offset=\".38\" stop-color=\"#b87f4c\"/><stop offset=\"1\" stop-color=\"#183a46\"/></linearGradient>\n<linearGradient id=\"skin\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".3\"><stop stop-color=\"#8e5549\"/><stop offset=\".5\" stop-color=\"#b5785c\"/><stop offset=\"1\" stop-color=\"#e3aa78\"/></linearGradient>\n<linearGradient id=\"suit\" x1=\"0\" y1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#758b9f\"/><stop offset=\".3\" stop-color=\"#354b69\"/><stop offset=\"1\" stop-color=\"#152641\"/></linearGradient>\n<linearGradient id=\"jelly\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#ffd3e6\" stop-opacity=\".82\"/><stop offset=\".44\" stop-color=\"#f484c4\" stop-opacity=\".52\"/><stop offset=\"1\" stop-color=\"#b34f9d\" stop-opacity=\".22\"/></linearGradient>\n<linearGradient id=\"beam\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#c4ffff\" stop-opacity=\".38\"/><stop offset=\"1\" stop-color=\"#1ea6e6\" stop-opacity=\"0\"/></linearGradient>\n<linearGradient id=\"disc\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#ffb272\"/><stop offset=\".4\" stop-color=\"#df753a\"/><stop offset=\"1\" stop-color=\"#b24d29\"/></linearGradient>\n<pattern id=\"grain\" width=\"28\" height=\"28\" patternUnits=\"userSpaceOnUse\"><path d=\"M2 3h.8M17 8h.8M9 20h.8M25 24h.6\" stroke=\"#786440\" stroke-opacity=\".09\" stroke-width=\".7\"/></pattern>\n<pattern id=\"chart\" width=\"60\" height=\"60\" patternUnits=\"userSpaceOnUse\"><path d=\"M60 0H0V60\" fill=\"none\" stroke=\"#324c63\" stroke-width=\".55\" opacity=\".11\"/></pattern>\n\n<clipPath id=\"personClip\"><rect width=\"180\" height=\"208\" rx=\"2\"/></clipPath>\n</defs>", st = {
	seaStar: "<path d=\"M0 142H420\" stroke=\"#c6f7e9\" stroke-width=\"1\"/><path d=\"M0 145q40-4 85 0t100 0t95 0t145 0M0 155q59-3 105 0t94 0t150 0\" fill=\"none\" stroke=\"#91e8dc\" stroke-width=\".8\"/><path d=\"M55 141V110H72v31M325 142v-26h14v26\" fill=\"#a1b6c1\"/><rect x=\"35\" y=\"114\" width=\"344\" height=\"39\" rx=\"5\" fill=\"url(#steel)\" stroke=\"#45667e\" stroke-width=\"1\"/><path d=\"M41 116H374M36 149H376\" stroke=\"#e4e9d6\" stroke-width=\"1\"/><rect x=\"45\" y=\"98\" width=\"64\" height=\"57\" rx=\"2\" fill=\"url(#steel)\" stroke=\"#395c77\" stroke-width=\"1\"/><rect x=\"270\" y=\"79\" width=\"53\" height=\"83\" rx=\"2\" fill=\"url(#steel)\" stroke=\"#49677f\" stroke-width=\"1\"/><rect x=\"112\" y=\"113\" width=\"155\" height=\"42\" rx=\"11\" fill=\"url(#steel)\" stroke=\"#4d6c82\" stroke-width=\"0.7\"/><rect x=\"50\" y=\"105\" width=\"53\" height=\"24\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"52\" y=\"107\" width=\"49\" height=\"20\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M55 126L97 126\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"278\" y=\"87\" width=\"37\" height=\"26\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"280\" y=\"89\" width=\"33\" height=\"22\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M283 110L309 110\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"130\" y=\"121\" width=\"53\" height=\"21\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"132\" y=\"123\" width=\"49\" height=\"17\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M135 139L177 139\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"189\" y=\"121\" width=\"58\" height=\"21\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"191\" y=\"123\" width=\"54\" height=\"17\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M194 139L241 139\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"49\" y=\"132\" width=\"20\" height=\"20\" rx=\"1\" fill=\"#879eac\" stroke=\"#cedcd8\" stroke-width=\"0.6\"/><path d=\"M51 136L66 136\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 137.71428571428572L66 137.71428571428572\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 139.42857142857142L66 139.42857142857142\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 141.14285714285714L66 141.14285714285714\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 142.85714285714286L66 142.85714285714286\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 144.57142857142858L66 144.57142857142858\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 146.28571428571428L66 146.28571428571428\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><rect x=\"291\" y=\"120\" width=\"13\" height=\"28\" rx=\"1\" fill=\"#9db4bc\" stroke=\"#e3e6d2\" stroke-width=\"0.7\"/><rect x=\"294\" y=\"123\" width=\"7\" height=\"21\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"296\" y=\"125\" width=\"3\" height=\"17\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M299 141L295 141\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"M274 115H319M274 150H319M48 101H105M276 82H319\" stroke=\"#e6be4f\" stroke-width=\"2.8\"/><path d=\"M151 113V60h5v53M154 60 255 91 253 97 155 68Z\" fill=\"#dfb443\" stroke=\"#7b7b68\" stroke-width=\".6\"/><path d=\"M158 65 176 70l-10 1 17 2-8 2 20 3-10 1 19 4-7 1 19 4-9 1 20 3-7 1 15 4M253 92v36q-1 7 4 4\" fill=\"none\" stroke=\"#f9df83\" stroke-width=\".6\"/><path d=\"M42 93L108 93\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M42 96L108 96\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M42 93L42 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M54 93L54 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M66 93L66 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M78 93L78 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M90 93L90 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M102 93L102 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M114 93L114 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M269 74L328 74\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M269 77L328 77\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M269 74L269 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M281 74L281 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M293 74L293 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M305 74L305 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M317 74L317 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M329 74L329 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M330 113L376 113\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M330 116L376 116\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M330 113L330 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M342 113L342 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M354 113L354 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M366 113L366 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M378 113L378 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M292 78V43M281 78V52M309 78V49M278 59h34M279 69h33M282 52v26M286 52v26\" stroke=\"#8ba4ad\" stroke-width=\"1\"/><path d=\"M292 46h19v4h-19\" fill=\"#dd7250\"/><path d=\"M28 155H128l-12 24H47Q29 175 28 155ZM261 157H382l-13 22h-95Z\" fill=\"url(#hull)\" stroke=\"#4c7487\" stroke-width=\".8\"/><path d=\"M24 179q44 7 106 0M254 181q63 6 128-2\" stroke=\"#c6faf0\" stroke-width=\"1.6\" fill=\"none\"/><circle cx=\"136\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><circle cx=\"162\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><circle cx=\"188\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><circle cx=\"214\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><circle cx=\"240\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><path d=\"M78 130v48M84 130v48\" stroke=\"#c8d9d4\" stroke-width=\"1\"/><path d=\"M78 133L84 133\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 139L84 139\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 145L84 145\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 151L84 151\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 157L84 157\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 163L84 163\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 169L84 169\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><g transform=\"translate(250 191) scale(0.6)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(122 237) scale(0.6)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><path d=\"m224 73 5-2 4 2m-14 5 3-1 3 1\" stroke=\"#edf5dc\" fill=\"none\"/>",
	volcano: "<path d=\"M7 149 55 125 80 130 123 74 157 106 215 58 250 108 281 92 311 123 361 131 397 149Z\" fill=\"#258880\"/><path d=\"m24 149 73-16 26-59 6 45 28-13 59-48-24 61 52-15 38 21-44 13 91-5 69 16Z\" fill=\"#49a68a\"/><path d=\"m123 74 18 47-19-6-20 17Z\" fill=\"#22696e\"/><path d=\"m215 58-23 61 39-24Z\" fill=\"#16666d\"/><path d=\"m206 71 9-13 14 16-12-2-5 4Z\" fill=\"#d5d7bd\"/><path d=\"M208 57q-21-22-3-38M214 52q22-27 9-43\" stroke=\"#d0e1d4\" fill=\"none\" stroke-width=\"9\" opacity=\".3\"/><path d=\"M4 151Q98 145 211 151T420 151M4 156Q98 150 211 157T420 157\" fill=\"none\" stroke=\"#d4edba\" stroke-width=\"1.7\"/><path d=\"M0 250 58 188 109 207 135 240 199 195 240 206 292 248 341 210 420 245V264H0Z\" fill=\"#095f84\"/><path d=\"m3 249 55-61 16 35 29-10-8 36 42-9-13 24H0M199 195l41 11 22 29-47-8-31 37h-45Z\" fill=\"#137d95\"/><g transform=\"translate(60 264) scale(0.7)\"><g stroke=\"#ef916d\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(320 260) scale(0.6)\"><g stroke=\"#e8bf6c\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(361 260) scale(0.6)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#159c8e\"/></g><g transform=\"translate(266 176) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(165 191) scale(0.35)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	rig: "<path d=\"M62 157 46 239M95 157 92 249M320 157l14 90M352 157l25 92\" stroke=\"#436b80\" stroke-width=\"8\"/><path d=\"M60 158 94 240M91 158 48 239M325 160l49 85M353 158l-19 87\" stroke=\"#849b94\" stroke-width=\"2\"/><rect x=\"28\" y=\"144\" width=\"365\" height=\"13\" rx=\"1\" fill=\"url(#steel)\"/><rect x=\"38\" y=\"146\" width=\"344\" height=\"3\" rx=\"0\" fill=\"#e1bc55\"/><rect x=\"279\" y=\"102\" width=\"75\" height=\"42\" rx=\"1\" fill=\"url(#steel)\" stroke=\"#3b5e74\" stroke-width=\"1\"/><rect x=\"291\" y=\"81\" width=\"40\" height=\"21\" rx=\"1\" fill=\"#a9bfc1\" stroke=\"#486a7a\" stroke-width=\"0.6\"/><rect x=\"286\" y=\"109\" width=\"59\" height=\"19\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"288\" y=\"111\" width=\"55\" height=\"15\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M291 125L339 125\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"48\" y=\"118\" width=\"50\" height=\"26\" rx=\"1\" fill=\"url(#steel)\"/><rect x=\"53\" y=\"124\" width=\"37\" height=\"11\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"55\" y=\"126\" width=\"33\" height=\"7\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M58 132L84 132\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"M130 144V47h19v97M131 49l17 17-17 14 17 16-17 13 17 15-17 17M132 47l129 42-112-22Z\" fill=\"none\" stroke=\"#ddb74e\" stroke-width=\"3\"/><path d=\"m150 54 13 15 12-7 12 14 12-6 12 12 9-4 13 11M259 89v37q0 8 6 3\" stroke=\"#ead587\" stroke-width=\".8\" fill=\"none\"/><path d=\"M32 137L390 137\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M32 140L390 140\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M32 137L32 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M44 137L44 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M56 137L56 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M68 137L68 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M80 137L80 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M92 137L92 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M104 137L104 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M116 137L116 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M128 137L128 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M140 137L140 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M152 137L152 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M164 137L164 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M176 137L176 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M188 137L188 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M200 137L200 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M212 137L212 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M224 137L224 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M236 137L236 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M248 137L248 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M260 137L260 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M272 137L272 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M284 137L284 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M296 137L296 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M308 137L308 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M320 137L320 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M332 137L332 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M344 137L344 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M356 137L356 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M368 137L368 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M380 137L380 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M392 137L392 147\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M310 81V57M328 81V62\" stroke=\"#496a79\" stroke-width=\"2\"/><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#07547a\"/><g transform=\"translate(189 185) scale(0.8)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73c7c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(369 263) scale(0.5)\"><g stroke=\"#b9b274\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(58 232) scale(0.65)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	lookingGlass: "<path d=\"M85 137V0M292 111V0\" stroke=\"#1a6484\" stroke-width=\"1.2\"/><path d=\"M91 136V0M298 111V0\" stroke=\"#b9f7db\" stroke-opacity=\".45\" stroke-width=\".5\"/><path d=\"M99 164 87 250M302 164l17 86M111 165v80M289 165v80M91 222h223\" stroke=\"#19476c\" stroke-width=\"6\"/><path d=\"m99 165 202 79M299 165 93 244\" stroke=\"#488e9e\" stroke-width=\"1\"/><rect x=\"62\" y=\"129\" width=\"134\" height=\"39\" rx=\"15\" fill=\"url(#steel)\" stroke=\"#1a5474\" stroke-width=\"1\"/><rect x=\"205\" y=\"104\" width=\"114\" height=\"64\" rx=\"6\" fill=\"url(#steel)\" stroke=\"#164863\" stroke-width=\"1\"/><rect x=\"190\" y=\"139\" width=\"18\" height=\"21\" rx=\"2\" fill=\"#7697a9\" stroke=\"#2d637b\" stroke-width=\"1\"/><rect x=\"78\" y=\"137\" width=\"91\" height=\"20\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"80\" y=\"139\" width=\"87\" height=\"16\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M83 154L163 154\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"217\" y=\"115\" width=\"90\" height=\"30\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"219\" y=\"117\" width=\"86\" height=\"26\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M222 142L301 142\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"M96 138v18M125 138v18M244 116v28M278 116v28M210 151h100\" stroke=\"#abd3cc\" stroke-width=\"2\"/><path d=\"M232 104V87h31v17M234 87l14-20 14 20\" fill=\"#99b5bd\" stroke=\"#3e7487\" stroke-width=\"1\"/><circle cx=\"292\" cy=\"95\" r=\"9\" fill=\"#60c6c8\" stroke=\"#acd5cc\" stroke-width=\"1\"/><path d=\"M292 87L292 103\" fill=\"none\" stroke=\"#c2e7d5\" stroke-width=\"1\"/><rect x=\"57\" y=\"167\" width=\"269\" height=\"7\" rx=\"1\" fill=\"#9ebabe\"/><path d=\"M64 122L193 122\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M64 125L193 125\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M64 122L64 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M76 122L76 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M88 122L88 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M100 122L100 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M112 122L112 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M124 122L124 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M136 122L136 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M148 122L148 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M160 122L160 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M172 122L172 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M184 122L184 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M196 122L196 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M306 150 397 194 393 252 301 157Z\" fill=\"url(#beam)\" opacity=\".65\"/><circle cx=\"306\" cy=\"152\" r=\"3\" fill=\"#d4fff0\"/><g transform=\"translate(326 103) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(30 181) scale(0.6)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#083653\"/><g transform=\"translate(354 264) scale(0.67)\"><g stroke=\"#e59a92\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(371 264) scale(0.5)\"><g stroke=\"#ba7fb0\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(30 267) scale(0.59)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#168c90\"/></g><g transform=\"translate(183 188) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><g transform=\"translate(338 164) scale(0.55)\"><ellipse rx=\"8\" ry=\"5\" fill=\"#173d61\"/><path d=\"m-6 2-10 9 5 3 9-10M7 0l12 3M2-4l-3-9M-4-1h15\" stroke=\"#c4d8c9\" stroke-width=\"2\"/><circle cx=\"7\" r=\"3\" fill=\"#c7f9e6\"/></g>",
	whales: "<g transform=\"translate(0 10) scale(1)\"><g transform=\"translate(220 125) scale(0.9 0.9)\"><path d=\"M-130-5Q-91-70-9-48Q37-35 75-12Q105-10 122-47L126-15 151 2Q120 15 87 5Q44 49-21 42Q-101 39-130-5Z\" fill=\"#254d69\" stroke=\"#153f59\" stroke-width=\"2\"/><path d=\"M-129-5Q-76 22-8 24Q30 27 68 5Q33 46-23 41Q-101 33-129-5Z\" fill=\"#8ebcc5\"/><path d=\"M-24 14Q-57 79 9 59L19 20\" fill=\"#326780\" stroke=\"#1e506a\" stroke-width=\"2\"/><path d=\"M-70-38-53-59-32-44\" fill=\"#306077\"/><circle cx=\"-103\" cy=\"-6\" r=\"3\" fill=\"#c8dbcf\"/><circle cx=\"-102\" cy=\"-6\" r=\"1.5\" fill=\"#173849\"/><path d=\"M-111 9Q-92 19-73 16M-108 16Q-75 34-48 29M-94 24Q-68 40-41 35\" stroke=\"#527d90\" fill=\"none\" stroke-width=\"2\"/></g></g><g transform=\"translate(0 0) scale(1)\"><g transform=\"translate(331 202) scale(-0.36 0.36)\"><path d=\"M-130-5Q-91-70-9-48Q37-35 75-12Q105-10 122-47L126-15 151 2Q120 15 87 5Q44 49-21 42Q-101 39-130-5Z\" fill=\"#254d69\" stroke=\"#153f59\" stroke-width=\"2\"/><path d=\"M-129-5Q-76 22-8 24Q30 27 68 5Q33 46-23 41Q-101 33-129-5Z\" fill=\"#8ebcc5\"/><path d=\"M-24 14Q-57 79 9 59L19 20\" fill=\"#326780\" stroke=\"#1e506a\" stroke-width=\"2\"/><path d=\"M-70-38-53-59-32-44\" fill=\"#306077\"/><circle cx=\"-103\" cy=\"-6\" r=\"3\" fill=\"#c8dbcf\"/><circle cx=\"-102\" cy=\"-6\" r=\"1.5\" fill=\"#173849\"/><path d=\"M-111 9Q-92 19-73 16M-108 16Q-75 34-48 29M-94 24Q-68 40-41 35\" stroke=\"#527d90\" fill=\"none\" stroke-width=\"2\"/></g></g><g transform=\"translate(71 217) scale(0.27 0.27)\"><path d=\"M-130-5Q-91-70-9-48Q37-35 75-12Q105-10 122-47L126-15 151 2Q120 15 87 5Q44 49-21 42Q-101 39-130-5Z\" fill=\"#254d69\" stroke=\"#153f59\" stroke-width=\"2\"/><path d=\"M-129-5Q-76 22-8 24Q30 27 68 5Q33 46-23 41Q-101 33-129-5Z\" fill=\"#8ebcc5\"/><path d=\"M-24 14Q-57 79 9 59L19 20\" fill=\"#326780\" stroke=\"#1e506a\" stroke-width=\"2\"/><path d=\"M-70-38-53-59-32-44\" fill=\"#306077\"/><circle cx=\"-103\" cy=\"-6\" r=\"3\" fill=\"#c8dbcf\"/><circle cx=\"-102\" cy=\"-6\" r=\"1.5\" fill=\"#173849\"/><path d=\"M-111 9Q-92 19-73 16M-108 16Q-75 34-48 29M-94 24Q-68 40-41 35\" stroke=\"#527d90\" fill=\"none\" stroke-width=\"2\"/></g><path d=\"M112 120q47 23 101 7M131 132q33 13 66 12\" stroke=\"#b6e4df\" stroke-width=\".8\" fill=\"none\" opacity=\".45\"/><g transform=\"translate(318 70) scale(0.5)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(100 89) scale(0.35)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#073c65\"/><g transform=\"translate(380 267) scale(0.4)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#218a91\"/></g><g transform=\"translate(48 185) scale(0.6)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	ruins: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#155a73\"/><path d=\"M56 225 70 126 96 126 93 225M142 238 149 128 174 128 184 238M238 235 238 134 264 134 268 235M318 243l4-79 23 1 9 78\" fill=\"#618f9c\" stroke=\"#abc4b5\" stroke-width=\"1\"/><path d=\"M61 122H101v10H61ZM140 121h44v10h-44ZM231 128h41v11h-41ZM315 159h37v10h-37Z\" fill=\"#adc3b3\"/><path d=\"M58 115 159 84 269 119v12H59Z\" fill=\"#a9c0af\" stroke=\"#4c8192\" stroke-width=\"1\"/><path d=\"m72 115 88-24 90 24Z\" fill=\"#6c9b9d\"/><path d=\"M74 141 70 219M83 144 81 224M155 144l-2 82M163 145l4 85M248 144v79M255 145l2 84M331 177l2 55\" stroke=\"#a7c3b3\" stroke-width=\"1.2\" opacity=\".65\"/><path d=\"m95 208 9 18-21 3M174 218l-6-22 8-11M245 151l11 10-10 18M159 86l13 14-11 6\" stroke=\"#437889\" stroke-width=\"1\" fill=\"none\"/><g transform=\"translate(295 264) scale(0.7)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#298e91\"/></g><g transform=\"translate(55 263) scale(0.62)\"><g stroke=\"#f7b27d\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(368 266) scale(0.55)\"><g stroke=\"#d17b99\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(295 108) scale(0.7)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#aadace\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(24 189) scale(0.45)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#67bac7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	rift: "<path d=\"M0 213 37 176 61 183 88 150 111 172 155 107 177 157 161 264H0Z\" fill=\"#1c6277\"/><path d=\"m155 107 22 50-16 107H90l29-52-12-30Z\" fill=\"#113d5b\"/><path d=\"m37 176 24 7-23 32 11 49H0v-51ZM88 150l23 22-29 29-10 63H45l9-43Z\" fill=\"#28748a\"/><path d=\"M263 264 246 174 277 134 304 160 347 108 420 179v85Z\" fill=\"#12415b\"/><path d=\"m347 108 31 57-32 30 17 69h57v-85ZM277 134l-31 40 17 90h38l-21-50 11-22-17-27Z\" fill=\"#20627b\"/><path d=\"m155 112-19 77 8 19-18 35M348 119l8 47-27 34 11 49M62 189l-21 34 10 23\" fill=\"none\" stroke=\"#3b889c\" stroke-width=\"1\" opacity=\".5\"/><path d=\"M259 140 163 224 252 264 279 145Z\" fill=\"url(#beam)\" opacity=\".45\"/><g transform=\"translate(81 261) scale(0.55)\"><g stroke=\"#dd8b9f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(350 261) scale(0.6)\"><g stroke=\"#e8ad7b\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(218 176) scale(0.4)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b4d9da\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(194 242) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><path d=\"M209 186v66M217 153l4 20\" stroke=\"#51a7b5\" stroke-opacity=\".35\" fill=\"none\"/>",
	jellyfish: "<g transform=\"translate(101 126) scale(1.14)\"><path d=\"M-34 0C-36-27-16-51 0-46C18-50 36-24 34 0Q13 11-5 5T-34 0Z\" fill=\"url(#jelly)\" stroke=\"#ef8eca\" stroke-opacity=\".8\" stroke-width=\"1.1\"/><path d=\"M-31-3Q0-19 32-3M-24-6Q-25-37-7-44M-7-6Q-14-33 1-45M10-6Q20-28 7-43M24-5Q31-19 19-35\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\".5\" stroke-width=\"1.3\"/><path d=\"M-22 4Q-15 31 0 20T17 4M-8 5q-9 31 9 28t7-29\" stroke=\"#ef8eca\" stroke-width=\"4\" opacity=\".45\" fill=\"none\"/><path d=\"M-26 3C-53 25 22 50 -6 88S-36 115 8 135\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.25\" stroke-width=\"0.8\"/><path d=\"M-18 3C-45 28 30 55 2 92S-28 118 16 138\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.31\" stroke-width=\"1.5\"/><path d=\"M-10 3C-37 31 38 60 10 96S-20 121 24 141\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.37\" stroke-width=\"0.8\"/><path d=\"M1 3C-26 34 49 65 21 100S-9 124 35 144\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.43\" stroke-width=\"1.5\"/><path d=\"M9 3C-18 37 57 70 29 104S-1 127 43 147\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.49\" stroke-width=\"0.8\"/><path d=\"M18 3C-9 40 66 75 38 108S8 130 52 150\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.55\" stroke-width=\"1.5\"/><path d=\"M28 3C1 43 76 80 48 112S18 133 62 153\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.61\" stroke-width=\"0.8\"/></g><g transform=\"translate(318 132) scale(0.7)\"><path d=\"M-34 0C-36-27-16-51 0-46C18-50 36-24 34 0Q13 11-5 5T-34 0Z\" fill=\"url(#jelly)\" stroke=\"#ef8eca\" stroke-opacity=\".8\" stroke-width=\"1.1\"/><path d=\"M-31-3Q0-19 32-3M-24-6Q-25-37-7-44M-7-6Q-14-33 1-45M10-6Q20-28 7-43M24-5Q31-19 19-35\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\".5\" stroke-width=\"1.3\"/><path d=\"M-22 4Q-15 31 0 20T17 4M-8 5q-9 31 9 28t7-29\" stroke=\"#ef8eca\" stroke-width=\"4\" opacity=\".45\" fill=\"none\"/><path d=\"M-26 3C-53 25 22 50 -6 88S-36 115 8 135\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.25\" stroke-width=\"0.8\"/><path d=\"M-18 3C-45 28 30 55 2 92S-28 118 16 138\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.31\" stroke-width=\"1.5\"/><path d=\"M-10 3C-37 31 38 60 10 96S-20 121 24 141\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.37\" stroke-width=\"0.8\"/><path d=\"M1 3C-26 34 49 65 21 100S-9 124 35 144\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.43\" stroke-width=\"1.5\"/><path d=\"M9 3C-18 37 57 70 29 104S-1 127 43 147\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.49\" stroke-width=\"0.8\"/><path d=\"M18 3C-9 40 66 75 38 108S8 130 52 150\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.55\" stroke-width=\"1.5\"/><path d=\"M28 3C1 43 76 80 48 112S18 133 62 153\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.61\" stroke-width=\"0.8\"/></g><g transform=\"translate(217 79) scale(0.35)\"><path d=\"M-34 0C-36-27-16-51 0-46C18-50 36-24 34 0Q13 11-5 5T-34 0Z\" fill=\"url(#jelly)\" stroke=\"#ef8eca\" stroke-opacity=\".8\" stroke-width=\"1.1\"/><path d=\"M-31-3Q0-19 32-3M-24-6Q-25-37-7-44M-7-6Q-14-33 1-45M10-6Q20-28 7-43M24-5Q31-19 19-35\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\".5\" stroke-width=\"1.3\"/><path d=\"M-22 4Q-15 31 0 20T17 4M-8 5q-9 31 9 28t7-29\" stroke=\"#ef8eca\" stroke-width=\"4\" opacity=\".45\" fill=\"none\"/><path d=\"M-26 3C-53 25 22 50 -6 88S-36 115 8 135\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.25\" stroke-width=\"0.8\"/><path d=\"M-18 3C-45 28 30 55 2 92S-28 118 16 138\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.31\" stroke-width=\"1.5\"/><path d=\"M-10 3C-37 31 38 60 10 96S-20 121 24 141\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.37\" stroke-width=\"0.8\"/><path d=\"M1 3C-26 34 49 65 21 100S-9 124 35 144\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.43\" stroke-width=\"1.5\"/><path d=\"M9 3C-18 37 57 70 29 104S-1 127 43 147\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.49\" stroke-width=\"0.8\"/><path d=\"M18 3C-9 40 66 75 38 108S8 130 52 150\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.55\" stroke-width=\"1.5\"/><path d=\"M28 3C1 43 76 80 48 112S18 133 62 153\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.61\" stroke-width=\"0.8\"/></g><g transform=\"translate(377 215) scale(0.42)\"><path d=\"M-34 0C-36-27-16-51 0-46C18-50 36-24 34 0Q13 11-5 5T-34 0Z\" fill=\"url(#jelly)\" stroke=\"#ef8eca\" stroke-opacity=\".8\" stroke-width=\"1.1\"/><path d=\"M-31-3Q0-19 32-3M-24-6Q-25-37-7-44M-7-6Q-14-33 1-45M10-6Q20-28 7-43M24-5Q31-19 19-35\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\".5\" stroke-width=\"1.3\"/><path d=\"M-22 4Q-15 31 0 20T17 4M-8 5q-9 31 9 28t7-29\" stroke=\"#ef8eca\" stroke-width=\"4\" opacity=\".45\" fill=\"none\"/><path d=\"M-26 3C-53 25 22 50 -6 88S-36 115 8 135\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.25\" stroke-width=\"0.8\"/><path d=\"M-18 3C-45 28 30 55 2 92S-28 118 16 138\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.31\" stroke-width=\"1.5\"/><path d=\"M-10 3C-37 31 38 60 10 96S-20 121 24 141\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.37\" stroke-width=\"0.8\"/><path d=\"M1 3C-26 34 49 65 21 100S-9 124 35 144\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.43\" stroke-width=\"1.5\"/><path d=\"M9 3C-18 37 57 70 29 104S-1 127 43 147\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.49\" stroke-width=\"0.8\"/><path d=\"M18 3C-9 40 66 75 38 108S8 130 52 150\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.55\" stroke-width=\"1.5\"/><path d=\"M28 3C1 43 76 80 48 112S18 133 62 153\" fill=\"none\" stroke=\"#ef8eca\" stroke-opacity=\"0.61\" stroke-width=\"0.8\"/></g><g transform=\"translate(34 188) scale(1.2)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><g transform=\"translate(269 207) scale(0.8)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><g transform=\"translate(170 183) scale(0.4)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73bacb\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	vents: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#071c35\"/><path d=\"m87 252 16-64 13-3 18 65M194 248l4-112 16-11 18 119M299 252l14-78 13 6 17 72\" fill=\"#173e53\" stroke=\"#3d6877\" stroke-width=\"1\"/><path d=\"m104 188 5 29-10 15M201 139l4 45-8 42M316 180l10 32-8 29\" stroke=\"#57908c\" stroke-width=\"1\" fill=\"none\"/><path d=\"M111 186C79 154 148 127 114 93S101 53 121 37M210 130C178 100 238 71 209 44M323 175c31-22-7-34 7-65\" stroke=\"#6dadb6\" stroke-width=\"14\" opacity=\".16\" fill=\"none\"/><path d=\"M109 187c-19-38 24-49 1-81M207 130c-17-28 16-52 1-78\" stroke=\"#abd9d2\" stroke-width=\"3\" opacity=\".19\" fill=\"none\"/><g transform=\"translate(49 264) scale(0.7)\"><g stroke=\"#cc7f96\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(369 267) scale(0.8)\"><g stroke=\"#c08091\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(267 109) scale(0.4)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(140 230) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	whaleFall: "<path d=\"M163 80 52 264H349L182 81Z\" fill=\"url(#beam)\"/><path d=\"M174 0v64\" stroke=\"#102e42\" stroke-width=\"2\"/><g transform=\"translate(174 74) scale(0.34)\"><path d=\"M-35-10h70v23h-70Z\" fill=\"#243e4b\" stroke=\"#6aa8b5\" stroke-width=\"2\"/><circle cx=\"-29\" cy=\"10\" r=\"6\" fill=\"#d5fff4\"/><circle cx=\"29\" cy=\"10\" r=\"6\" fill=\"#d5fff4\"/></g><path d=\"M0 251q84-33 173-10t247-2v25H0Z\" fill=\"#020d19\"/><path d=\"M41 228Q106 193 250 228L321 242\" stroke=\"#598b93\" stroke-width=\"6\" fill=\"none\"/><path d=\"M43 226 22 235l37 1 28-17-19-8Z\" fill=\"#4f828a\" stroke=\"#89b5b1\" stroke-width=\".6\"/><path d=\"M88 226Q78 182 93 176Q113 182 102 225\" fill=\"none\" stroke=\"#8db9b4\" stroke-width=\"3.3\"/><path d=\"M93 177q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M103 228.44656271835743Q93 185.44656271835743 108 179.44656271835743Q128 185.44656271835743 117 227.44656271835743\" fill=\"none\" stroke=\"#8db9b4\" stroke-width=\"3.3\"/><path d=\"M108 180.44656271835743q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M118 230.46785871982516Q108 188.46785871982516 123 182.46785871982516Q143 188.46785871982516 132 229.46785871982516\" fill=\"none\" stroke=\"#8db9b4\" stroke-width=\"3.3\"/><path d=\"M123 183.46785871982516q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M133 231.7125420495431Q123 190.7125420495431 138 184.7125420495431Q158 190.7125420495431 147 230.7125420495431\" fill=\"none\" stroke=\"#8db9b4\" stroke-width=\"3.3\"/><path d=\"M138 185.7125420495431q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M148 231.96425921318846Q138 191.96425921318846 153 185.96425921318846Q173 191.96425921318846 162 230.96425921318846\" fill=\"none\" stroke=\"#8db9b4\" stroke-width=\"3.3\"/><path d=\"M153 186.96425921318846q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M163 231.17925619989325Q153 192.17925619989325 168 186.17925619989325Q188 192.17925619989325 177 230.17925619989325\" fill=\"none\" stroke=\"#527d84\" stroke-width=\"3.3\"/><path d=\"M168 187.17925619989325q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M178 229.4939838971445Q168 191.4939838971445 183 185.4939838971445Q203 191.4939838971445 192 228.4939838971445\" fill=\"none\" stroke=\"#527d84\" stroke-width=\"3.3\"/><path d=\"M183 186.4939838971445q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M193 227.20137990833064Q183 190.20137990833064 198 184.20137990833064Q218 190.20137990833064 207 226.20137990833064\" fill=\"none\" stroke=\"#527d84\" stroke-width=\"3.3\"/><path d=\"M198 185.20137990833064q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M208 224.69994951767572Q198 188.69994951767572 213 182.69994951767572Q233 188.69994951767572 222 223.69994951767572\" fill=\"none\" stroke=\"#527d84\" stroke-width=\"3.3\"/><path d=\"M213 183.69994951767572q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M223 222.4244966571534Q213 187.4244966571534 228 181.4244966571534Q248 187.4244966571534 237 221.4244966571534\" fill=\"none\" stroke=\"#527d84\" stroke-width=\"3.3\"/><path d=\"M228 182.4244966571534q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><path d=\"M238 220.77054536551847Q228 186.77054536551847 243 180.77054536551847Q263 186.77054536551847 252 219.77054536551847\" fill=\"none\" stroke=\"#527d84\" stroke-width=\"3.3\"/><path d=\"M243 181.77054536551847q9 18 6 33\" stroke=\"#bbe1ce\" stroke-width=\".7\" fill=\"none\"/><g transform=\"translate(343 264) scale(0.48)\"><g stroke=\"#745e86\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g opacity=\"0.55\"><circle cx=\"8\" cy=\"40\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"79\" cy=\"87\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"150\" cy=\"134\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"221\" cy=\"181\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"292\" cy=\"228\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"363\" cy=\"61\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"29\" cy=\"108\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"100\" cy=\"155\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"171\" cy=\"202\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"242\" cy=\"249\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"313\" cy=\"82\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"384\" cy=\"129\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"50\" cy=\"176\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"121\" cy=\"223\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"192\" cy=\"56\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"263\" cy=\"103\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"334\" cy=\"150\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"405\" cy=\"197\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"71\" cy=\"244\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"142\" cy=\"77\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"213\" cy=\"124\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"284\" cy=\"171\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"355\" cy=\"218\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"21\" cy=\"51\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"92\" cy=\"98\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"163\" cy=\"145\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"234\" cy=\"192\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"305\" cy=\"239\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"376\" cy=\"72\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"42\" cy=\"119\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"113\" cy=\"166\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"184\" cy=\"213\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"255\" cy=\"46\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"326\" cy=\"93\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"397\" cy=\"140\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"63\" cy=\"187\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"134\" cy=\"234\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"205\" cy=\"67\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"276\" cy=\"114\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"347\" cy=\"161\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"13\" cy=\"208\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"84\" cy=\"41\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"155\" cy=\"88\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"226\" cy=\"135\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"297\" cy=\"182\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"368\" cy=\"229\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"34\" cy=\"62\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"105\" cy=\"109\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"176\" cy=\"156\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"247\" cy=\"203\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"318\" cy=\"250\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"389\" cy=\"83\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"55\" cy=\"130\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"126\" cy=\"177\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"197\" cy=\"224\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"268\" cy=\"57\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"339\" cy=\"104\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"410\" cy=\"151\" r=\"0.65\" fill=\"#72dbef\"/><circle cx=\"76\" cy=\"198\" r=\"0.9\" fill=\"#72dbef\"/><circle cx=\"147\" cy=\"245\" r=\"1.15\" fill=\"#72dbef\"/><circle cx=\"218\" cy=\"78\" r=\"0.4\" fill=\"#72dbef\"/><circle cx=\"289\" cy=\"125\" r=\"0.65\" fill=\"#72dbef\"/></g><g transform=\"translate(186 195) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	bioluminescence: "<g transform=\"translate(106 138) scale(0.76)\"><path d=\"M-34 0C-36-27-16-51 0-46C18-50 36-24 34 0Q13 11-5 5T-34 0Z\" fill=\"#1e918f\" stroke=\"#64f1d2\" stroke-opacity=\".8\" stroke-width=\"1.1\"/><path d=\"M-31-3Q0-19 32-3M-24-6Q-25-37-7-44M-7-6Q-14-33 1-45M10-6Q20-28 7-43M24-5Q31-19 19-35\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\".5\" stroke-width=\"1.3\"/><path d=\"M-22 4Q-15 31 0 20T17 4M-8 5q-9 31 9 28t7-29\" stroke=\"#64f1d2\" stroke-width=\"4\" opacity=\".45\" fill=\"none\"/><path d=\"M-26 3C-53 25 22 50 -6 88S-36 115 8 135\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.25\" stroke-width=\"0.8\"/><path d=\"M-18 3C-45 28 30 55 2 92S-28 118 16 138\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.31\" stroke-width=\"1.5\"/><path d=\"M-10 3C-37 31 38 60 10 96S-20 121 24 141\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.37\" stroke-width=\"0.8\"/><path d=\"M1 3C-26 34 49 65 21 100S-9 124 35 144\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.43\" stroke-width=\"1.5\"/><path d=\"M9 3C-18 37 57 70 29 104S-1 127 43 147\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.49\" stroke-width=\"0.8\"/><path d=\"M18 3C-9 40 66 75 38 108S8 130 52 150\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.55\" stroke-width=\"1.5\"/><path d=\"M28 3C1 43 76 80 48 112S18 133 62 153\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.61\" stroke-width=\"0.8\"/></g><g transform=\"translate(315 195) scale(0.46)\"><path d=\"M-34 0C-36-27-16-51 0-46C18-50 36-24 34 0Q13 11-5 5T-34 0Z\" fill=\"#1e918f\" stroke=\"#64f1d2\" stroke-opacity=\".8\" stroke-width=\"1.1\"/><path d=\"M-31-3Q0-19 32-3M-24-6Q-25-37-7-44M-7-6Q-14-33 1-45M10-6Q20-28 7-43M24-5Q31-19 19-35\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\".5\" stroke-width=\"1.3\"/><path d=\"M-22 4Q-15 31 0 20T17 4M-8 5q-9 31 9 28t7-29\" stroke=\"#64f1d2\" stroke-width=\"4\" opacity=\".45\" fill=\"none\"/><path d=\"M-26 3C-53 25 22 50 -6 88S-36 115 8 135\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.25\" stroke-width=\"0.8\"/><path d=\"M-18 3C-45 28 30 55 2 92S-28 118 16 138\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.31\" stroke-width=\"1.5\"/><path d=\"M-10 3C-37 31 38 60 10 96S-20 121 24 141\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.37\" stroke-width=\"0.8\"/><path d=\"M1 3C-26 34 49 65 21 100S-9 124 35 144\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.43\" stroke-width=\"1.5\"/><path d=\"M9 3C-18 37 57 70 29 104S-1 127 43 147\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.49\" stroke-width=\"0.8\"/><path d=\"M18 3C-9 40 66 75 38 108S8 130 52 150\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.55\" stroke-width=\"1.5\"/><path d=\"M28 3C1 43 76 80 48 112S18 133 62 153\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.61\" stroke-width=\"0.8\"/></g><g transform=\"translate(247 106) scale(0.3)\"><path d=\"M-34 0C-36-27-16-51 0-46C18-50 36-24 34 0Q13 11-5 5T-34 0Z\" fill=\"#1e918f\" stroke=\"#64f1d2\" stroke-opacity=\".8\" stroke-width=\"1.1\"/><path d=\"M-31-3Q0-19 32-3M-24-6Q-25-37-7-44M-7-6Q-14-33 1-45M10-6Q20-28 7-43M24-5Q31-19 19-35\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\".5\" stroke-width=\"1.3\"/><path d=\"M-22 4Q-15 31 0 20T17 4M-8 5q-9 31 9 28t7-29\" stroke=\"#64f1d2\" stroke-width=\"4\" opacity=\".45\" fill=\"none\"/><path d=\"M-26 3C-53 25 22 50 -6 88S-36 115 8 135\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.25\" stroke-width=\"0.8\"/><path d=\"M-18 3C-45 28 30 55 2 92S-28 118 16 138\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.31\" stroke-width=\"1.5\"/><path d=\"M-10 3C-37 31 38 60 10 96S-20 121 24 141\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.37\" stroke-width=\"0.8\"/><path d=\"M1 3C-26 34 49 65 21 100S-9 124 35 144\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.43\" stroke-width=\"1.5\"/><path d=\"M9 3C-18 37 57 70 29 104S-1 127 43 147\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.49\" stroke-width=\"0.8\"/><path d=\"M18 3C-9 40 66 75 38 108S8 130 52 150\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.55\" stroke-width=\"1.5\"/><path d=\"M28 3C1 43 76 80 48 112S18 133 62 153\" fill=\"none\" stroke=\"#64f1d2\" stroke-opacity=\"0.61\" stroke-width=\"0.8\"/></g><g transform=\"translate(176 171) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#78f0d8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(21 219) scale(0.5)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#47baac\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><path d=\"M26 264Q18 231 29 220\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"29\" cy=\"220\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M44 264Q36 244 47 233\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"47\" cy=\"233\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M62 264Q54 257 65 246\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"65\" cy=\"246\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M80 264Q72 270 83 259\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"83\" cy=\"259\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M98 264Q90 241 101 230\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"101\" cy=\"230\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M116 264Q108 254 119 243\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"119\" cy=\"243\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M134 264Q126 267 137 256\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"137\" cy=\"256\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M152 264Q144 238 155 227\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"155\" cy=\"227\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M170 264Q162 251 173 240\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"173\" cy=\"240\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M188 264Q180 264 191 253\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"191\" cy=\"253\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M206 264Q198 235 209 224\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"209\" cy=\"224\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M224 264Q216 248 227 237\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"227\" cy=\"237\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M242 264Q234 261 245 250\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"245\" cy=\"250\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M260 264Q252 232 263 221\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"263\" cy=\"221\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M278 264Q270 245 281 234\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"281\" cy=\"234\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M296 264Q288 258 299 247\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"299\" cy=\"247\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M314 264Q306 271 317 260\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"317\" cy=\"260\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M332 264Q324 242 335 231\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"335\" cy=\"231\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M350 264Q342 255 353 244\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"353\" cy=\"244\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M368 264Q360 268 371 257\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"371\" cy=\"257\" r=\"1.6\" fill=\"#84ffe0\"/><path d=\"M386 264Q378 239 389 228\" stroke=\"#359b96\" stroke-width=\".8\" fill=\"none\"/><circle cx=\"389\" cy=\"228\" r=\"1.6\" fill=\"#84ffe0\"/><g transform=\"translate(366 167) scale(0.6)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	reef: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#074766\"/><g transform=\"translate(20 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(63 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(106 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(149 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(192 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(235 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(278 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(321 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(364 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(407 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(117 106) scale(1)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	kelp: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#074766\"/><g transform=\"translate(22 276) scale(0.65)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#1e948d\"/></g><g transform=\"translate(63 276) scale(0.9)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#329d80\"/></g><g transform=\"translate(104 276) scale(1.15)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#5aa58c\"/></g><g transform=\"translate(145 276) scale(0.65)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#1e948d\"/></g><g transform=\"translate(186 276) scale(0.9)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#329d80\"/></g><g transform=\"translate(227 276) scale(1.15)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#5aa58c\"/></g><g transform=\"translate(268 276) scale(0.65)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#1e948d\"/></g><g transform=\"translate(309 276) scale(0.9)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#329d80\"/></g><g transform=\"translate(350 276) scale(1.15)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#5aa58c\"/></g><g transform=\"translate(391 276) scale(0.65)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#1e948d\"/></g><g transform=\"translate(117 106) scale(1)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	anchorage: "<path d=\"M0 142H420\" stroke=\"#c6f7e9\" stroke-width=\"1\"/><path d=\"M0 145q40-4 85 0t100 0t95 0t145 0M0 155q59-3 105 0t94 0t150 0\" fill=\"none\" stroke=\"#91e8dc\" stroke-width=\".8\"/><path d=\"M55 141V110H72v31M325 142v-26h14v26\" fill=\"#a1b6c1\"/><rect x=\"35\" y=\"114\" width=\"344\" height=\"39\" rx=\"5\" fill=\"url(#steel)\" stroke=\"#45667e\" stroke-width=\"1\"/><path d=\"M41 116H374M36 149H376\" stroke=\"#e4e9d6\" stroke-width=\"1\"/><rect x=\"45\" y=\"98\" width=\"64\" height=\"57\" rx=\"2\" fill=\"url(#steel)\" stroke=\"#395c77\" stroke-width=\"1\"/><rect x=\"270\" y=\"79\" width=\"53\" height=\"83\" rx=\"2\" fill=\"url(#steel)\" stroke=\"#49677f\" stroke-width=\"1\"/><rect x=\"112\" y=\"113\" width=\"155\" height=\"42\" rx=\"11\" fill=\"url(#steel)\" stroke=\"#4d6c82\" stroke-width=\"0.7\"/><rect x=\"50\" y=\"105\" width=\"53\" height=\"24\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"52\" y=\"107\" width=\"49\" height=\"20\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M55 126L97 126\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"278\" y=\"87\" width=\"37\" height=\"26\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"280\" y=\"89\" width=\"33\" height=\"22\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M283 110L309 110\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"130\" y=\"121\" width=\"53\" height=\"21\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"132\" y=\"123\" width=\"49\" height=\"17\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M135 139L177 139\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"189\" y=\"121\" width=\"58\" height=\"21\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"191\" y=\"123\" width=\"54\" height=\"17\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M194 139L241 139\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"49\" y=\"132\" width=\"20\" height=\"20\" rx=\"1\" fill=\"#879eac\" stroke=\"#cedcd8\" stroke-width=\"0.6\"/><path d=\"M51 136L66 136\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 137.71428571428572L66 137.71428571428572\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 139.42857142857142L66 139.42857142857142\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 141.14285714285714L66 141.14285714285714\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 142.85714285714286L66 142.85714285714286\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 144.57142857142858L66 144.57142857142858\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><path d=\"M51 146.28571428571428L66 146.28571428571428\" fill=\"none\" stroke=\"#3b586c\" stroke-width=\"0.8\"/><rect x=\"291\" y=\"120\" width=\"13\" height=\"28\" rx=\"1\" fill=\"#9db4bc\" stroke=\"#e3e6d2\" stroke-width=\"0.7\"/><rect x=\"294\" y=\"123\" width=\"7\" height=\"21\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"296\" y=\"125\" width=\"3\" height=\"17\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M299 141L295 141\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"M274 115H319M274 150H319M48 101H105M276 82H319\" stroke=\"#e6be4f\" stroke-width=\"2.8\"/><path d=\"M151 113V60h5v53M154 60 255 91 253 97 155 68Z\" fill=\"#dfb443\" stroke=\"#7b7b68\" stroke-width=\".6\"/><path d=\"M158 65 176 70l-10 1 17 2-8 2 20 3-10 1 19 4-7 1 19 4-9 1 20 3-7 1 15 4M253 92v36q-1 7 4 4\" fill=\"none\" stroke=\"#f9df83\" stroke-width=\".6\"/><path d=\"M42 93L108 93\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M42 96L108 96\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M42 93L42 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M54 93L54 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M66 93L66 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M78 93L78 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M90 93L90 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M102 93L102 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M114 93L114 103\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M269 74L328 74\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M269 77L328 77\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M269 74L269 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M281 74L281 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M293 74L293 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M305 74L305 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M317 74L317 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M329 74L329 84\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M330 113L376 113\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M330 116L376 116\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M330 113L330 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M342 113L342 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M354 113L354 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M366 113L366 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M378 113L378 123\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M292 78V43M281 78V52M309 78V49M278 59h34M279 69h33M282 52v26M286 52v26\" stroke=\"#8ba4ad\" stroke-width=\"1\"/><path d=\"M292 46h19v4h-19\" fill=\"#dd7250\"/><path d=\"M28 155H128l-12 24H47Q29 175 28 155ZM261 157H382l-13 22h-95Z\" fill=\"url(#hull)\" stroke=\"#4c7487\" stroke-width=\".8\"/><path d=\"M24 179q44 7 106 0M254 181q63 6 128-2\" stroke=\"#c6faf0\" stroke-width=\"1.6\" fill=\"none\"/><circle cx=\"136\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><circle cx=\"162\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><circle cx=\"188\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><circle cx=\"214\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><circle cx=\"240\" cy=\"150\" r=\"4.3\" fill=\"#a4ebdf\" stroke=\"#476e80\" stroke-width=\"1\"/><path d=\"M78 130v48M84 130v48\" stroke=\"#c8d9d4\" stroke-width=\"1\"/><path d=\"M78 133L84 133\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 139L84 139\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 145L84 145\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 151L84 151\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 157L84 157\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 163L84 163\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><path d=\"M78 169L84 169\" fill=\"none\" stroke=\"#dee5cf\" stroke-width=\"0.8\"/><g transform=\"translate(250 191) scale(0.6)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#63d4d1\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(122 237) scale(0.6)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><path d=\"m224 73 5-2 4 2m-14 5 3-1 3 1\" stroke=\"#edf5dc\" fill=\"none\"/>",
	calm: "<path d=\"M7 149 55 125 80 130 123 74 157 106 215 58 250 108 281 92 311 123 361 131 397 149Z\" fill=\"#258880\"/><path d=\"m24 149 73-16 26-59 6 45 28-13 59-48-24 61 52-15 38 21-44 13 91-5 69 16Z\" fill=\"#49a68a\"/><path d=\"m123 74 18 47-19-6-20 17Z\" fill=\"#22696e\"/><path d=\"m215 58-23 61 39-24Z\" fill=\"#16666d\"/><path d=\"m206 71 9-13 14 16-12-2-5 4Z\" fill=\"#d5d7bd\"/><path d=\"M208 57q-21-22-3-38M214 52q22-27 9-43\" stroke=\"#d0e1d4\" fill=\"none\" stroke-width=\"9\" opacity=\".3\"/><path d=\"M4 151Q98 145 211 151T420 151M4 156Q98 150 211 157T420 157\" fill=\"none\" stroke=\"#d4edba\" stroke-width=\"1.7\"/><path d=\"M0 250 58 188 109 207 135 240 199 195 240 206 292 248 341 210 420 245V264H0Z\" fill=\"#095f84\"/><path d=\"m3 249 55-61 16 35 29-10-8 36 42-9-13 24H0M199 195l41 11 22 29-47-8-31 37h-45Z\" fill=\"#137d95\"/><g transform=\"translate(60 264) scale(0.7)\"><g stroke=\"#ef916d\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(320 260) scale(0.6)\"><g stroke=\"#e8bf6c\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(361 260) scale(0.6)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#159c8e\"/></g><g transform=\"translate(266 176) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(165 191) scale(0.35)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	atoll: "<path d=\"M7 149 55 125 80 130 123 74 157 106 215 58 250 108 281 92 311 123 361 131 397 149Z\" fill=\"#258880\"/><path d=\"m24 149 73-16 26-59 6 45 28-13 59-48-24 61 52-15 38 21-44 13 91-5 69 16Z\" fill=\"#49a68a\"/><path d=\"m123 74 18 47-19-6-20 17Z\" fill=\"#22696e\"/><path d=\"m215 58-23 61 39-24Z\" fill=\"#16666d\"/><path d=\"m206 71 9-13 14 16-12-2-5 4Z\" fill=\"#d5d7bd\"/><path d=\"M208 57q-21-22-3-38M214 52q22-27 9-43\" stroke=\"#d0e1d4\" fill=\"none\" stroke-width=\"9\" opacity=\".3\"/><path d=\"M4 151Q98 145 211 151T420 151M4 156Q98 150 211 157T420 157\" fill=\"none\" stroke=\"#d4edba\" stroke-width=\"1.7\"/><path d=\"M0 250 58 188 109 207 135 240 199 195 240 206 292 248 341 210 420 245V264H0Z\" fill=\"#095f84\"/><path d=\"m3 249 55-61 16 35 29-10-8 36 42-9-13 24H0M199 195l41 11 22 29-47-8-31 37h-45Z\" fill=\"#137d95\"/><g transform=\"translate(60 264) scale(0.7)\"><g stroke=\"#ef916d\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(320 260) scale(0.6)\"><g stroke=\"#e8bf6c\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(361 260) scale(0.6)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#159c8e\"/></g><g transform=\"translate(266 176) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#deedb8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(165 191) scale(0.35)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b6e7cf\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	dolphins: "<g transform=\"translate(213 139) scale(0.8)\"><g transform=\"translate(0 0) scale(1 1)\"><path d=\"M-130-5Q-91-70-9-48Q37-35 75-12Q105-10 122-47L126-15 151 2Q120 15 87 5Q44 49-21 42Q-101 39-130-5Z\" fill=\"#254d69\" stroke=\"#153f59\" stroke-width=\"2\"/><path d=\"M-129-5Q-76 22-8 24Q30 27 68 5Q33 46-23 41Q-101 33-129-5Z\" fill=\"#8ebcc5\"/><path d=\"M-24 14Q-57 79 9 59L19 20\" fill=\"#326780\" stroke=\"#1e506a\" stroke-width=\"2\"/><path d=\"M-70-38-53-59-32-44\" fill=\"#306077\"/><circle cx=\"-103\" cy=\"-6\" r=\"3\" fill=\"#c8dbcf\"/><circle cx=\"-102\" cy=\"-6\" r=\"1.5\" fill=\"#173849\"/><path d=\"M-111 9Q-92 19-73 16M-108 16Q-75 34-48 29M-94 24Q-68 40-41 35\" stroke=\"#527d90\" fill=\"none\" stroke-width=\"2\"/></g></g><g transform=\"translate(321 209) scale(0.43)\"><g transform=\"translate(0 0) scale(-1 1)\"><path d=\"M-130-5Q-91-70-9-48Q37-35 75-12Q105-10 122-47L126-15 151 2Q120 15 87 5Q44 49-21 42Q-101 39-130-5Z\" fill=\"#254d69\" stroke=\"#153f59\" stroke-width=\"2\"/><path d=\"M-129-5Q-76 22-8 24Q30 27 68 5Q33 46-23 41Q-101 33-129-5Z\" fill=\"#8ebcc5\"/><path d=\"M-24 14Q-57 79 9 59L19 20\" fill=\"#326780\" stroke=\"#1e506a\" stroke-width=\"2\"/><path d=\"M-70-38-53-59-32-44\" fill=\"#306077\"/><circle cx=\"-103\" cy=\"-6\" r=\"3\" fill=\"#c8dbcf\"/><circle cx=\"-102\" cy=\"-6\" r=\"1.5\" fill=\"#173849\"/><path d=\"M-111 9Q-92 19-73 16M-108 16Q-75 34-48 29M-94 24Q-68 40-41 35\" stroke=\"#527d90\" fill=\"none\" stroke-width=\"2\"/></g></g><g transform=\"translate(38 97) scale(0.8)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	pod: "<path d=\"M85 137V0M292 111V0\" stroke=\"#1a6484\" stroke-width=\"1.2\"/><path d=\"M91 136V0M298 111V0\" stroke=\"#b9f7db\" stroke-opacity=\".45\" stroke-width=\".5\"/><path d=\"M99 164 87 250M302 164l17 86M111 165v80M289 165v80M91 222h223\" stroke=\"#19476c\" stroke-width=\"6\"/><path d=\"m99 165 202 79M299 165 93 244\" stroke=\"#488e9e\" stroke-width=\"1\"/><rect x=\"62\" y=\"129\" width=\"134\" height=\"39\" rx=\"15\" fill=\"url(#steel)\" stroke=\"#1a5474\" stroke-width=\"1\"/><rect x=\"205\" y=\"104\" width=\"114\" height=\"64\" rx=\"6\" fill=\"url(#steel)\" stroke=\"#164863\" stroke-width=\"1\"/><rect x=\"190\" y=\"139\" width=\"18\" height=\"21\" rx=\"2\" fill=\"#7697a9\" stroke=\"#2d637b\" stroke-width=\"1\"/><rect x=\"78\" y=\"137\" width=\"91\" height=\"20\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"80\" y=\"139\" width=\"87\" height=\"16\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M83 154L163 154\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"217\" y=\"115\" width=\"90\" height=\"30\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"219\" y=\"117\" width=\"86\" height=\"26\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M222 142L301 142\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"M96 138v18M125 138v18M244 116v28M278 116v28M210 151h100\" stroke=\"#abd3cc\" stroke-width=\"2\"/><path d=\"M232 104V87h31v17M234 87l14-20 14 20\" fill=\"#99b5bd\" stroke=\"#3e7487\" stroke-width=\"1\"/><circle cx=\"292\" cy=\"95\" r=\"9\" fill=\"#60c6c8\" stroke=\"#acd5cc\" stroke-width=\"1\"/><path d=\"M292 87L292 103\" fill=\"none\" stroke=\"#c2e7d5\" stroke-width=\"1\"/><rect x=\"57\" y=\"167\" width=\"269\" height=\"7\" rx=\"1\" fill=\"#9ebabe\"/><path d=\"M64 122L193 122\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M64 125L193 125\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M64 122L64 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M76 122L76 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M88 122L88 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M100 122L100 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M112 122L112 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M124 122L124 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M136 122L136 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M148 122L148 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M160 122L160 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M172 122L172 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M184 122L184 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M196 122L196 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M306 150 397 194 393 252 301 157Z\" fill=\"url(#beam)\" opacity=\".65\"/><circle cx=\"306\" cy=\"152\" r=\"3\" fill=\"#d4fff0\"/><g transform=\"translate(326 103) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(30 181) scale(0.6)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#083653\"/><g transform=\"translate(354 264) scale(0.67)\"><g stroke=\"#e59a92\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(371 264) scale(0.5)\"><g stroke=\"#ba7fb0\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(30 267) scale(0.59)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#168c90\"/></g><g transform=\"translate(183 188) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><g transform=\"translate(338 164) scale(0.55)\"><ellipse rx=\"8\" ry=\"5\" fill=\"#173d61\"/><path d=\"m-6 2-10 9 5 3 9-10M7 0l12 3M2-4l-3-9M-4-1h15\" stroke=\"#c4d8c9\" stroke-width=\"2\"/><circle cx=\"7\" r=\"3\" fill=\"#c7f9e6\"/></g>",
	cave: "<path d=\"M0 80 91 62 128 111 186 69 253 82 311 52 420 86V264H0Z\" fill=\"#285975\"/><path d=\"M74 264 99 151Q199 43 305 147L353 264Z\" fill=\"#061a32\"/><path d=\"M100 259 126 164Q208 86 281 163L319 264\" stroke=\"#3b8190\" stroke-width=\"3\" fill=\"none\"/><g transform=\"translate(62 264) scale(0.8)\"><g stroke=\"#d59f8e\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(357 266) scale(0.8)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#43877b\"/></g><g transform=\"translate(211 206) scale(1)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	wreck: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#061f39\"/><g transform=\"translate(39 160) rotate(-12)\"><path d=\"M0 0H313L263 57H55Z\" fill=\"#416877\" stroke=\"#90a396\"/><path d=\"M62 0v-46h102v46M179 0v-70h69v70\" fill=\"#57777d\" stroke=\"#77938f\"/><path d=\"M73-15h79M190-38h40M198-56v18\" stroke=\"#142f46\" stroke-width=\"8\"/><path d=\"M112 1 145 49 169 0M225 4l-18 48\" fill=\"#092c44\"/></g><g transform=\"translate(98 264) scale(0.8)\"><g stroke=\"#cf8896\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(240 101) scale(0.7)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	elevator: "<path d=\"M85 137V0M292 111V0\" stroke=\"#1a6484\" stroke-width=\"1.2\"/><path d=\"M91 136V0M298 111V0\" stroke=\"#b9f7db\" stroke-opacity=\".45\" stroke-width=\".5\"/><path d=\"M99 164 87 250M302 164l17 86M111 165v80M289 165v80M91 222h223\" stroke=\"#19476c\" stroke-width=\"6\"/><path d=\"m99 165 202 79M299 165 93 244\" stroke=\"#488e9e\" stroke-width=\"1\"/><rect x=\"62\" y=\"129\" width=\"134\" height=\"39\" rx=\"15\" fill=\"url(#steel)\" stroke=\"#1a5474\" stroke-width=\"1\"/><rect x=\"205\" y=\"104\" width=\"114\" height=\"64\" rx=\"6\" fill=\"url(#steel)\" stroke=\"#164863\" stroke-width=\"1\"/><rect x=\"190\" y=\"139\" width=\"18\" height=\"21\" rx=\"2\" fill=\"#7697a9\" stroke=\"#2d637b\" stroke-width=\"1\"/><rect x=\"78\" y=\"137\" width=\"91\" height=\"20\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"80\" y=\"139\" width=\"87\" height=\"16\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M83 154L163 154\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"217\" y=\"115\" width=\"90\" height=\"30\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"219\" y=\"117\" width=\"86\" height=\"26\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M222 142L301 142\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"M96 138v18M125 138v18M244 116v28M278 116v28M210 151h100\" stroke=\"#abd3cc\" stroke-width=\"2\"/><path d=\"M232 104V87h31v17M234 87l14-20 14 20\" fill=\"#99b5bd\" stroke=\"#3e7487\" stroke-width=\"1\"/><circle cx=\"292\" cy=\"95\" r=\"9\" fill=\"#60c6c8\" stroke=\"#acd5cc\" stroke-width=\"1\"/><path d=\"M292 87L292 103\" fill=\"none\" stroke=\"#c2e7d5\" stroke-width=\"1\"/><rect x=\"57\" y=\"167\" width=\"269\" height=\"7\" rx=\"1\" fill=\"#9ebabe\"/><path d=\"M64 122L193 122\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M64 125L193 125\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M64 122L64 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M76 122L76 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M88 122L88 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M100 122L100 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M112 122L112 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M124 122L124 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M136 122L136 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M148 122L148 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M160 122L160 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M172 122L172 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M184 122L184 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M196 122L196 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M306 150 397 194 393 252 301 157Z\" fill=\"url(#beam)\" opacity=\".65\"/><circle cx=\"306\" cy=\"152\" r=\"3\" fill=\"#d4fff0\"/><g transform=\"translate(326 103) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(30 181) scale(0.6)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#083653\"/><g transform=\"translate(354 264) scale(0.67)\"><g stroke=\"#e59a92\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(371 264) scale(0.5)\"><g stroke=\"#ba7fb0\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(30 267) scale(0.59)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#168c90\"/></g><g transform=\"translate(183 188) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><g transform=\"translate(338 164) scale(0.55)\"><ellipse rx=\"8\" ry=\"5\" fill=\"#173d61\"/><path d=\"m-6 2-10 9 5 3 9-10M7 0l12 3M2-4l-3-9M-4-1h15\" stroke=\"#c4d8c9\" stroke-width=\"2\"/><circle cx=\"7\" r=\"3\" fill=\"#c7f9e6\"/></g>",
	turtles: "<g transform=\"translate(90 130) scale(0.7)\"><ellipse rx=\"52\" ry=\"33\" fill=\"#5b9b89\" stroke=\"#a5cab1\"/><path d=\"m-27-23 27-7 26 7 12 23-12 22-26 8-27-8-11-22Z M0-30v60M-38 0h76\" fill=\"none\" stroke=\"#287069\" stroke-width=\"2\"/><path d=\"M-47-11q-39-24-32-34t40 28M-46 11q-33 36-20 41t33-34M44-13q35-27 28-36t-39 25M45 11q36 28 24 40t-36-30\" fill=\"#6fb19d\"/><ellipse cx=\"62\" rx=\"17\" ry=\"13\" fill=\"#91bb9f\"/></g><g transform=\"translate(210 177) scale(0.6)\"><ellipse rx=\"52\" ry=\"33\" fill=\"#5b9b89\" stroke=\"#a5cab1\"/><path d=\"m-27-23 27-7 26 7 12 23-12 22-26 8-27-8-11-22Z M0-30v60M-38 0h76\" fill=\"none\" stroke=\"#287069\" stroke-width=\"2\"/><path d=\"M-47-11q-39-24-32-34t40 28M-46 11q-33 36-20 41t33-34M44-13q35-27 28-36t-39 25M45 11q36 28 24 40t-36-30\" fill=\"#6fb19d\"/><ellipse cx=\"62\" rx=\"17\" ry=\"13\" fill=\"#91bb9f\"/></g><g transform=\"translate(330 130) scale(0.49999999999999994)\"><ellipse rx=\"52\" ry=\"33\" fill=\"#5b9b89\" stroke=\"#a5cab1\"/><path d=\"m-27-23 27-7 26 7 12 23-12 22-26 8-27-8-11-22Z M0-30v60M-38 0h76\" fill=\"none\" stroke=\"#287069\" stroke-width=\"2\"/><path d=\"M-47-11q-39-24-32-34t40 28M-46 11q-33 36-20 41t33-34M44-13q35-27 28-36t-39 25M45 11q36 28 24 40t-36-30\" fill=\"#6fb19d\"/><ellipse cx=\"62\" rx=\"17\" ry=\"13\" fill=\"#91bb9f\"/></g>",
	vortex: "<ellipse cx=\"210\" cy=\"120\" rx=\"145\" ry=\"32\" stroke=\"#67b5bd\" stroke-opacity=\"0.16\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"129\" rx=\"130\" ry=\"29.3\" stroke=\"#67b5bd\" stroke-opacity=\"0.2\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"138\" rx=\"115\" ry=\"26.6\" stroke=\"#67b5bd\" stroke-opacity=\"0.24\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"147\" rx=\"100\" ry=\"23.9\" stroke=\"#67b5bd\" stroke-opacity=\"0.28\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"156\" rx=\"85\" ry=\"21.2\" stroke=\"#67b5bd\" stroke-opacity=\"0.32\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"165\" rx=\"70\" ry=\"18.5\" stroke=\"#67b5bd\" stroke-opacity=\"0.36\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"174\" rx=\"55\" ry=\"15.799999999999997\" stroke=\"#67b5bd\" stroke-opacity=\"0.4\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"183\" rx=\"40\" ry=\"13.099999999999998\" stroke=\"#67b5bd\" stroke-opacity=\"0.44000000000000006\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"192\" rx=\"25\" ry=\"10.399999999999999\" stroke=\"#67b5bd\" stroke-opacity=\"0.48\" stroke-width=\"2\" fill=\"none\"/>",
	sharks: "<path d=\"M38 152Q96 105 226 129l37-56 13 66 73 16 48-39-14 49 19 24-58-13-97 12Q112 199 38 152Z\" fill=\"#3a7590\" stroke=\"#97bec5\"/><path d=\"M42 154q95 43 211 14l-54 43-15-35\" fill=\"#83afb4\"/><circle cx=\"65\" cy=\"148\" r=\"3\" fill=\"#071e34\"/><path d=\"M110 142v20m8-20v22m8-22v22\" stroke=\"#173e59\" fill=\"none\"/><g transform=\"translate(83 210) scale(0.6)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	spires: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#061b33\"/><path d=\"M-10 264 27 85 72 264Z\" fill=\"#16495d\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M66 264 103 109 148 264Z\" fill=\"#20576b\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M142 264 179 133 224 264Z\" fill=\"#12384f\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M218 264 255 85 300 264Z\" fill=\"#16495d\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M294 264 331 109 376 264Z\" fill=\"#20576b\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M370 264 407 133 452 264Z\" fill=\"#12384f\" stroke=\"#366a79\" stroke-width=\"1\"/><g transform=\"translate(148 105) scale(0.7)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	coldReef: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#074766\"/><g transform=\"translate(20 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(63 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(106 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(149 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(192 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(235 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(278 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(321 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(364 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(407 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(117 106) scale(1)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	plain: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#04152a\"/><path d=\"M0 204Q91 178 172 210T420 209V264H0Z\" fill=\"#123d51\"/><path d=\"M0 228Q101 204 206 236T420 229\" stroke=\"#36727b\" fill=\"none\"/><g transform=\"translate(14 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(47 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(80 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(113 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(146 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(179 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(212 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(245 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(278 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(311 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(344 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(377 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(410 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g>",
	snails: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#04152a\"/><path d=\"M0 204Q91 178 172 210T420 209V264H0Z\" fill=\"#123d51\"/><path d=\"M0 228Q101 204 206 236T420 229\" stroke=\"#36727b\" fill=\"none\"/><g transform=\"translate(14 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(47 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(80 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(113 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(146 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(179 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(212 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(245 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(278 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(311 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(344 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(377 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(410 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g>",
	lostStar: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#061f39\"/><g transform=\"translate(39 160) rotate(-12)\"><path d=\"M0 0H313L263 57H55Z\" fill=\"#416877\" stroke=\"#90a396\"/><path d=\"M62 0v-46h102v46M179 0v-70h69v70\" fill=\"#57777d\" stroke=\"#77938f\"/><path d=\"M73-15h79M190-38h40M198-56v18\" stroke=\"#142f46\" stroke-width=\"8\"/><path d=\"M112 1 145 49 169 0M225 4l-18 48\" fill=\"#092c44\"/></g><g transform=\"translate(98 264) scale(0.8)\"><g stroke=\"#cf8896\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(240 101) scale(0.7)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	trench: "<path d=\"M0 80 91 62 128 111 186 69 253 82 311 52 420 86V264H0Z\" fill=\"#285975\"/><path d=\"M74 264 99 151Q199 43 305 147L353 264Z\" fill=\"#061a32\"/><path d=\"M100 259 126 164Q208 86 281 163L319 264\" stroke=\"#3b8190\" stroke-width=\"3\" fill=\"none\"/><g transform=\"translate(62 264) scale(0.8)\"><g stroke=\"#d59f8e\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(357 266) scale(0.8)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#43877b\"/></g><g transform=\"translate(211 206) scale(1)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	smokers: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#071c35\"/><path d=\"m87 252 16-64 13-3 18 65M194 248l4-112 16-11 18 119M299 252l14-78 13 6 17 72\" fill=\"#173e53\" stroke=\"#3d6877\" stroke-width=\"1\"/><path d=\"m104 188 5 29-10 15M201 139l4 45-8 42M316 180l10 32-8 29\" stroke=\"#57908c\" stroke-width=\"1\" fill=\"none\"/><path d=\"M111 186C79 154 148 127 114 93S101 53 121 37M210 130C178 100 238 71 209 44M323 175c31-22-7-34 7-65\" stroke=\"#6dadb6\" stroke-width=\"14\" opacity=\".16\" fill=\"none\"/><path d=\"M109 187c-19-38 24-49 1-81M207 130c-17-28 16-52 1-78\" stroke=\"#abd9d2\" stroke-width=\"3\" opacity=\".19\" fill=\"none\"/><g transform=\"translate(49 264) scale(0.7)\"><g stroke=\"#cc7f96\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(369 267) scale(0.8)\"><g stroke=\"#c08091\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(267 109) scale(0.4)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#8ab4c7\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(140 230) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	recovery: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#074766\"/><g transform=\"translate(20 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(63 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(106 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(149 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(192 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(235 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(278 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(321 267) scale(0.78)\"><g stroke=\"#bf8db2\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(364 267) scale(1.01)\"><g stroke=\"#b7b46f\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(407 267) scale(0.55)\"><g stroke=\"#d69d89\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(117 106) scale(1)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#b2e2c8\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	shelf: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#061b33\"/><path d=\"M-10 264 27 123 72 264Z\" fill=\"#16495d\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M66 264 103 154 148 264Z\" fill=\"#20576b\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M142 264 179 185 224 264Z\" fill=\"#12384f\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M218 264 255 123 300 264Z\" fill=\"#16495d\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M294 264 331 154 376 264Z\" fill=\"#20576b\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M370 264 407 185 452 264Z\" fill=\"#12384f\" stroke=\"#366a79\" stroke-width=\"1\"/><g transform=\"translate(148 105) scale(0.7)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	squid: "<path d=\"M236 51Q171 91 180 151l-26 27 48-6 45 13-13-36Q268 92 236 51Z\" fill=\"#ad728e\" stroke=\"#d4a6b3\"/><path d=\"M190 163q-98 15-124 77m132-72q-55 65-109 81m117-79q-17 72-63 85m74-84q28 78 71 80m-56-83q59 19 79 67\" fill=\"none\" stroke=\"#ad809a\" stroke-width=\"6\"/><circle cx=\"197\" cy=\"147\" r=\"7\" fill=\"#dcebd1\"/><circle cx=\"196\" cy=\"147\" r=\"3\" fill=\"#26314d\"/>",
	brine: "<ellipse cx=\"210\" cy=\"120\" rx=\"145\" ry=\"32\" stroke=\"#67b5bd\" stroke-opacity=\"0.16\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"129\" rx=\"130\" ry=\"29.3\" stroke=\"#67b5bd\" stroke-opacity=\"0.2\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"138\" rx=\"115\" ry=\"26.6\" stroke=\"#67b5bd\" stroke-opacity=\"0.24\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"147\" rx=\"100\" ry=\"23.9\" stroke=\"#67b5bd\" stroke-opacity=\"0.28\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"156\" rx=\"85\" ry=\"21.2\" stroke=\"#67b5bd\" stroke-opacity=\"0.32\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"165\" rx=\"70\" ry=\"18.5\" stroke=\"#67b5bd\" stroke-opacity=\"0.36\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"174\" rx=\"55\" ry=\"15.799999999999997\" stroke=\"#67b5bd\" stroke-opacity=\"0.4\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"183\" rx=\"40\" ry=\"13.099999999999998\" stroke=\"#67b5bd\" stroke-opacity=\"0.44000000000000006\" stroke-width=\"2\" fill=\"none\"/><ellipse cx=\"210\" cy=\"192\" rx=\"25\" ry=\"10.399999999999999\" stroke=\"#67b5bd\" stroke-opacity=\"0.48\" stroke-width=\"2\" fill=\"none\"/><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#04152a\"/><path d=\"M0 204Q91 178 172 210T420 209V264H0Z\" fill=\"#123d51\"/><path d=\"M0 228Q101 204 206 236T420 229\" stroke=\"#36727b\" fill=\"none\"/><g transform=\"translate(14 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(47 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(80 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(113 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(146 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(179 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(212 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(245 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(278 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(311 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(344 269) scale(0.33)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(377 269) scale(0.43000000000000005)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(410 269) scale(0.23)\"><g stroke=\"#789a97\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g>",
	sponge: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#04152a\"/><path d=\"M0 204Q91 178 172 210T420 209V264H0Z\" fill=\"#123d51\"/><path d=\"M0 228Q101 204 206 236T420 229\" stroke=\"#36727b\" fill=\"none\"/><path d=\"M15 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M46 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M77 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M108 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M139 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M170 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M201 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M232 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M263 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M294 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M325 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M356 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/><path d=\"M387 264v-22q0-28 9-28t8 28v22\" fill=\"#696a87\" stroke=\"#9e9db5\"/>",
	seamount: "<path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#061b33\"/><path d=\"M-10 264 27 123 72 264Z\" fill=\"#16495d\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M66 264 103 154 148 264Z\" fill=\"#20576b\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M142 264 179 185 224 264Z\" fill=\"#12384f\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M218 264 255 123 300 264Z\" fill=\"#16495d\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M294 264 331 154 376 264Z\" fill=\"#20576b\" stroke=\"#366a79\" stroke-width=\"1\"/><path d=\"M370 264 407 185 452 264Z\" fill=\"#12384f\" stroke=\"#366a79\" stroke-width=\"1\"/><g transform=\"translate(148 105) scale(0.7)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#a4d7df\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g>",
	orca: "<g transform=\"translate(0 10) scale(1)\"><g transform=\"translate(220 125) scale(0.9 0.9)\"><path d=\"M-130-5Q-91-70-9-48Q37-35 75-12Q105-10 122-47L126-15 151 2Q120 15 87 5Q44 49-21 42Q-101 39-130-5Z\" fill=\"#254d69\" stroke=\"#153f59\" stroke-width=\"2\"/><path d=\"M-129-5Q-76 22-8 24Q30 27 68 5Q33 46-23 41Q-101 33-129-5Z\" fill=\"#8ebcc5\"/><path d=\"M-24 14Q-57 79 9 59L19 20\" fill=\"#326780\" stroke=\"#1e506a\" stroke-width=\"2\"/><path d=\"M-70-38-53-59-32-44\" fill=\"#306077\"/><circle cx=\"-103\" cy=\"-6\" r=\"3\" fill=\"#c8dbcf\"/><circle cx=\"-102\" cy=\"-6\" r=\"1.5\" fill=\"#173849\"/><path d=\"M-111 9Q-92 19-73 16M-108 16Q-75 34-48 29M-94 24Q-68 40-41 35\" stroke=\"#527d90\" fill=\"none\" stroke-width=\"2\"/></g></g><g transform=\"translate(0 0) scale(1)\"><g transform=\"translate(331 202) scale(-0.36 0.36)\"><path d=\"M-130-5Q-91-70-9-48Q37-35 75-12Q105-10 122-47L126-15 151 2Q120 15 87 5Q44 49-21 42Q-101 39-130-5Z\" fill=\"#254d69\" stroke=\"#153f59\" stroke-width=\"2\"/><path d=\"M-129-5Q-76 22-8 24Q30 27 68 5Q33 46-23 41Q-101 33-129-5Z\" fill=\"#8ebcc5\"/><path d=\"M-24 14Q-57 79 9 59L19 20\" fill=\"#326780\" stroke=\"#1e506a\" stroke-width=\"2\"/><path d=\"M-70-38-53-59-32-44\" fill=\"#306077\"/><circle cx=\"-103\" cy=\"-6\" r=\"3\" fill=\"#c8dbcf\"/><circle cx=\"-102\" cy=\"-6\" r=\"1.5\" fill=\"#173849\"/><path d=\"M-111 9Q-92 19-73 16M-108 16Q-75 34-48 29M-94 24Q-68 40-41 35\" stroke=\"#527d90\" fill=\"none\" stroke-width=\"2\"/></g></g><g transform=\"translate(71 217) scale(0.27 0.27)\"><path d=\"M-130-5Q-91-70-9-48Q37-35 75-12Q105-10 122-47L126-15 151 2Q120 15 87 5Q44 49-21 42Q-101 39-130-5Z\" fill=\"#254d69\" stroke=\"#153f59\" stroke-width=\"2\"/><path d=\"M-129-5Q-76 22-8 24Q30 27 68 5Q33 46-23 41Q-101 33-129-5Z\" fill=\"#8ebcc5\"/><path d=\"M-24 14Q-57 79 9 59L19 20\" fill=\"#326780\" stroke=\"#1e506a\" stroke-width=\"2\"/><path d=\"M-70-38-53-59-32-44\" fill=\"#306077\"/><circle cx=\"-103\" cy=\"-6\" r=\"3\" fill=\"#c8dbcf\"/><circle cx=\"-102\" cy=\"-6\" r=\"1.5\" fill=\"#173849\"/><path d=\"M-111 9Q-92 19-73 16M-108 16Q-75 34-48 29M-94 24Q-68 40-41 35\" stroke=\"#527d90\" fill=\"none\" stroke-width=\"2\"/></g><path d=\"M112 120q47 23 101 7M131 132q33 13 66 12\" stroke=\"#b6e4df\" stroke-width=\".8\" fill=\"none\" opacity=\".45\"/><g transform=\"translate(318 70) scale(0.5)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#73d5dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(100 89) scale(0.35)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#84d7db\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#073c65\"/><g transform=\"translate(380 267) scale(0.4)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#218a91\"/></g><g transform=\"translate(48 185) scale(0.6)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g>",
	academy: "<path d=\"M85 137V0M292 111V0\" stroke=\"#1a6484\" stroke-width=\"1.2\"/><path d=\"M91 136V0M298 111V0\" stroke=\"#b9f7db\" stroke-opacity=\".45\" stroke-width=\".5\"/><path d=\"M99 164 87 250M302 164l17 86M111 165v80M289 165v80M91 222h223\" stroke=\"#19476c\" stroke-width=\"6\"/><path d=\"m99 165 202 79M299 165 93 244\" stroke=\"#488e9e\" stroke-width=\"1\"/><rect x=\"62\" y=\"129\" width=\"134\" height=\"39\" rx=\"15\" fill=\"url(#steel)\" stroke=\"#1a5474\" stroke-width=\"1\"/><rect x=\"205\" y=\"104\" width=\"114\" height=\"64\" rx=\"6\" fill=\"url(#steel)\" stroke=\"#164863\" stroke-width=\"1\"/><rect x=\"190\" y=\"139\" width=\"18\" height=\"21\" rx=\"2\" fill=\"#7697a9\" stroke=\"#2d637b\" stroke-width=\"1\"/><rect x=\"78\" y=\"137\" width=\"91\" height=\"20\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"80\" y=\"139\" width=\"87\" height=\"16\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M83 154L163 154\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"217\" y=\"115\" width=\"90\" height=\"30\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"219\" y=\"117\" width=\"86\" height=\"26\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M222 142L301 142\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"M96 138v18M125 138v18M244 116v28M278 116v28M210 151h100\" stroke=\"#abd3cc\" stroke-width=\"2\"/><path d=\"M232 104V87h31v17M234 87l14-20 14 20\" fill=\"#99b5bd\" stroke=\"#3e7487\" stroke-width=\"1\"/><circle cx=\"292\" cy=\"95\" r=\"9\" fill=\"#60c6c8\" stroke=\"#acd5cc\" stroke-width=\"1\"/><path d=\"M292 87L292 103\" fill=\"none\" stroke=\"#c2e7d5\" stroke-width=\"1\"/><rect x=\"57\" y=\"167\" width=\"269\" height=\"7\" rx=\"1\" fill=\"#9ebabe\"/><path d=\"M64 122L193 122\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M64 125L193 125\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M64 122L64 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M76 122L76 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M88 122L88 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M100 122L100 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M112 122L112 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M124 122L124 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M136 122L136 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M148 122L148 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M160 122L160 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M172 122L172 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M184 122L184 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M196 122L196 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M306 150 397 194 393 252 301 157Z\" fill=\"url(#beam)\" opacity=\".65\"/><circle cx=\"306\" cy=\"152\" r=\"3\" fill=\"#d4fff0\"/><g transform=\"translate(326 103) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(30 181) scale(0.6)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#083653\"/><g transform=\"translate(354 264) scale(0.67)\"><g stroke=\"#e59a92\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(371 264) scale(0.5)\"><g stroke=\"#ba7fb0\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(30 267) scale(0.59)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#168c90\"/></g><g transform=\"translate(183 188) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><g transform=\"translate(338 164) scale(0.55)\"><ellipse rx=\"8\" ry=\"5\" fill=\"#173d61\"/><path d=\"m-6 2-10 9 5 3 9-10M7 0l12 3M2-4l-3-9M-4-1h15\" stroke=\"#c4d8c9\" stroke-width=\"2\"/><circle cx=\"7\" r=\"3\" fill=\"#c7f9e6\"/></g>",
	robot: "<path d=\"M85 137V0M292 111V0\" stroke=\"#1a6484\" stroke-width=\"1.2\"/><path d=\"M91 136V0M298 111V0\" stroke=\"#b9f7db\" stroke-opacity=\".45\" stroke-width=\".5\"/><path d=\"M99 164 87 250M302 164l17 86M111 165v80M289 165v80M91 222h223\" stroke=\"#19476c\" stroke-width=\"6\"/><path d=\"m99 165 202 79M299 165 93 244\" stroke=\"#488e9e\" stroke-width=\"1\"/><rect x=\"62\" y=\"129\" width=\"134\" height=\"39\" rx=\"15\" fill=\"url(#steel)\" stroke=\"#1a5474\" stroke-width=\"1\"/><rect x=\"205\" y=\"104\" width=\"114\" height=\"64\" rx=\"6\" fill=\"url(#steel)\" stroke=\"#164863\" stroke-width=\"1\"/><rect x=\"190\" y=\"139\" width=\"18\" height=\"21\" rx=\"2\" fill=\"#7697a9\" stroke=\"#2d637b\" stroke-width=\"1\"/><rect x=\"78\" y=\"137\" width=\"91\" height=\"20\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"80\" y=\"139\" width=\"87\" height=\"16\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M83 154L163 154\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"217\" y=\"115\" width=\"90\" height=\"30\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"219\" y=\"117\" width=\"86\" height=\"26\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M222 142L301 142\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"M96 138v18M125 138v18M244 116v28M278 116v28M210 151h100\" stroke=\"#abd3cc\" stroke-width=\"2\"/><path d=\"M232 104V87h31v17M234 87l14-20 14 20\" fill=\"#99b5bd\" stroke=\"#3e7487\" stroke-width=\"1\"/><circle cx=\"292\" cy=\"95\" r=\"9\" fill=\"#60c6c8\" stroke=\"#acd5cc\" stroke-width=\"1\"/><path d=\"M292 87L292 103\" fill=\"none\" stroke=\"#c2e7d5\" stroke-width=\"1\"/><rect x=\"57\" y=\"167\" width=\"269\" height=\"7\" rx=\"1\" fill=\"#9ebabe\"/><path d=\"M64 122L193 122\" fill=\"none\" stroke=\"#cedfd7\" stroke-width=\"1\"/><path d=\"M64 125L193 125\" fill=\"none\" stroke=\"#8b9eab\" stroke-width=\"0.7\"/><path d=\"M64 122L64 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M76 122L76 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M88 122L88 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M100 122L100 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M112 122L112 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M124 122L124 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M136 122L136 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M148 122L148 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M160 122L160 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M172 122L172 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M184 122L184 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M196 122L196 131\" fill=\"none\" stroke=\"#bacbd0\" stroke-width=\"1\"/><path d=\"M306 150 397 194 393 252 301 157Z\" fill=\"url(#beam)\" opacity=\".65\"/><circle cx=\"306\" cy=\"152\" r=\"3\" fill=\"#d4fff0\"/><g transform=\"translate(326 103) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#9cdfdc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(30 181) scale(0.6)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#5bd2d6\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><path d=\"M0 244Q46 226 92 240T192 237T292 232T420 242V264H0Z\" fill=\"#083653\"/><g transform=\"translate(354 264) scale(0.67)\"><g stroke=\"#e59a92\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(371 264) scale(0.5)\"><g stroke=\"#ba7fb0\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><g transform=\"translate(30 267) scale(0.59)\"><path d=\"M0 0C-30-40 13-66-10-107C39-67-9-40 18-7M-7-1Q-56-25-27-73Q-4-42-7-1\" fill=\"#168c90\"/></g><g transform=\"translate(183 188) scale(0.7)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><g transform=\"translate(338 164) scale(0.55)\"><ellipse rx=\"8\" ry=\"5\" fill=\"#173d61\"/><path d=\"m-6 2-10 9 5 3 9-10M7 0l12 3M2-4l-3-9M-4-1h15\" stroke=\"#c4d8c9\" stroke-width=\"2\"/><circle cx=\"7\" r=\"3\" fill=\"#c7f9e6\"/></g><g transform=\"translate(226 185) scale(0.7)\"><path d=\"M-36-18h72v31h-72Z\" fill=\"#cfb25e\" stroke=\"#25465c\" stroke-width=\"2\"/><path d=\"M-28-18v-17h56v17M-20 13l-15 17M20 13l15 17\" fill=\"none\" stroke=\"#92b5b4\" stroke-width=\"5\"/><circle cx=\"-22\" cy=\"-3\" r=\"8\" fill=\"#8bd8ce\"/><circle cx=\"22\" cy=\"-3\" r=\"8\" fill=\"#8bd8ce\"/></g>"
}, ct = {
	sonar: "<g clip-path=\"url(#personClip)\"><rect x=\"0\" y=\"0\" width=\"180\" height=\"208\" rx=\"0\" fill=\"url(#portraitWarm)\"/><path d=\"M1 0H34v130H1M38 0h9v127h-9\" fill=\"#e6b065\" opacity=\".4\"/><path d=\"M75 0h105v138H75Z\" fill=\"#50664e\"/><path d=\"M116 20h64v91h-64Z\" fill=\"#082e35\" stroke=\"#a09155\" stroke-width=\"2\"/><circle cx=\"153\" cy=\"65\" r=\"20\" fill=\"none\" stroke=\"#689f67\" stroke-width=\"0.7\"/><circle cx=\"153\" cy=\"65\" r=\"34\" fill=\"none\" stroke=\"#689f67\" stroke-width=\"0.7\"/><circle cx=\"153\" cy=\"65\" r=\"48\" fill=\"none\" stroke=\"#689f67\" stroke-width=\"0.7\"/><path d=\"M118 65h62M153 22v86M153 65l24-21\" stroke=\"#c2c575\" stroke-width=\".7\"/><path d=\"M143 118h37v28h-37Z\" fill=\"#3a5b53\" stroke=\"#9c9c6c\" stroke-width=\"1\"/><path d=\"M148 122L171 122\" fill=\"none\" stroke=\"#a5ac74\" stroke-width=\"0.8\"/><path d=\"M148 125.6L171 125.6\" fill=\"none\" stroke=\"#a5ac74\" stroke-width=\"0.8\"/><path d=\"M148 129.2L171 129.2\" fill=\"none\" stroke=\"#a5ac74\" stroke-width=\"0.8\"/><path d=\"M148 132.8L171 132.8\" fill=\"none\" stroke=\"#a5ac74\" stroke-width=\"0.8\"/><path d=\"M148 136.4L171 136.4\" fill=\"none\" stroke=\"#a5ac74\" stroke-width=\"0.8\"/><path d=\"M15 208 24 149Q34 123 65 118L91 120 126 146 142 208Z\" fill=\"url(#suit)\" stroke=\"#293749\" stroke-width=\"1\"/><path d=\"M64 116 65 98 85 96 91 123 77 139Z\" fill=\"url(#skin)\"/><path d=\"M65 117 80 136 64 151 48 129M88 119 79 137 95 155 104 135\" fill=\"#788c97\"/><path d=\"M77 138 85 200M28 150l21 13 5 45M35 150l8 39\" stroke=\"#81939b\" stroke-width=\"1.2\" opacity=\".6\"/><path d=\"M52 48Q63 25 87 34L104 50 102 68 111 83 103 88 101 102Q87 116 70 103L56 84Z\" fill=\"url(#skin)\" stroke=\"#704a43\" stroke-width=\".8\"/><path d=\"M57 86 49 66Q43 36 70 25Q102 19 110 47L91 43 85 51 68 49 69 79Z\" fill=\"#493834\"/><path d=\"M52 35Q29 10 17 34T29 72Q46 71 53 51M54 40Q41 35 30 47M62 31Q78 20 96 32M69 39Q87 25 103 43\" fill=\"#73504a\" stroke=\"#a36b53\" stroke-width=\"1\"/><path d=\"m93 58 10 3M94 84l9 2M89 98l10-1\" stroke=\"#794c44\" stroke-width=\"1.3\"/><path d=\"M52 71Q43 14 80 18Q105 19 112 39\" fill=\"none\" stroke=\"#152b40\" stroke-width=\"9\"/><path d=\"M51 55Q42 40 52 27\" fill=\"none\" stroke=\"#758398\" stroke-width=\"1.2\"/><ellipse cx=\"56\" cy=\"73\" rx=\"12\" ry=\"21\" fill=\"#1b3047\" stroke=\"#778da0\" stroke-width=\"1.4\"/><ellipse cx=\"57\" cy=\"74\" rx=\"8\" ry=\"15\" fill=\"#263b54\"/><path d=\"M66 67 106 62M80 62l1 13 15 2 11-6V59L87 58Z\" fill=\"#1c2639\" stroke=\"#342b33\" stroke-width=\"1\"/><path d=\"M89 60l10 2\" stroke=\"#c8a381\" stroke-width=\"1\"/><path d=\"M65 87q7 15 28 11\" fill=\"none\" stroke=\"#283e51\" stroke-width=\"2\"/><circle cx=\"94\" cy=\"98\" r=\"2\" fill=\"#132b3d\"/><path d=\"M110 181 180 155v53h-71Z\" fill=\"#1b3b49\" stroke=\"#547b78\" stroke-width=\"1\"/><path d=\"m118 179 48-17 9 18-47 13Z\" fill=\"#13544f\"/><path d=\"M125 181L130 188\" fill=\"none\" stroke=\"#8eae72\" stroke-width=\"1\"/><path d=\"M135 178L140 185\" fill=\"none\" stroke=\"#8eae72\" stroke-width=\"1\"/><path d=\"M145 175L150 182\" fill=\"none\" stroke=\"#8eae72\" stroke-width=\"1\"/><path d=\"M155 172L160 179\" fill=\"none\" stroke=\"#8eae72\" stroke-width=\"1\"/><path d=\"M71 166Q86 164 100 176L119 183 120 192 98 187 70 183\" fill=\"url(#suit)\"/><path d=\"m110 181 15-1 14 8-3 5-20-2Z\" fill=\"url(#skin)\"/></g>",
	diver: "<g clip-path=\"url(#personClip)\"><rect x=\"0\" y=\"0\" width=\"180\" height=\"208\" rx=\"0\" fill=\"url(#sea2)\"/><path d=\"M-20 0 53 0 180 208h-58Z\" fill=\"#9efce9\" opacity=\".13\"/><g transform=\"translate(116 46) scale(0.65)\"><g transform=\"translate(0 0) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(21.731767878463174 3.365883939231586) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(37.274379414605455 3.637189707302727) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(46.12896006447894 0.5644800322394689) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(53.94558003753657 -3.027209981231713) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-7.671394197305108 8.164302901347446) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(12.764676014408593 10.882338007204297) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(35.25589278975031 14.627946394875156) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(52.91486597298705 15.957432986493528) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(63.29694788193405 13.648473940967026) scale(0.1)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(-4.352168887114958 21.823915556442522) scale(0.125)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g><g transform=\"translate(7.000078347594372 20.000039173797187) scale(0.15000000000000002)\"><path d=\"M-14 0Q-2-10 12 0Q-2 10-14 0M12 0 21-9v18Z\" fill=\"#62d9dc\"/><circle cx=\"-7\" cy=\"-1\" r=\"1.1\" fill=\"#214c5b\"/></g></g><g transform=\"translate(160 208) scale(0.75)\"><g stroke=\"#c58d9b\" stroke-width=\"5\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M0 0Q2-25-3-52M-2-15-18-29M-3-29 13-43M-4-42-18-53M-17-29-19-43M13-43 14-54M-1-8 17-18M16-18 23-31\"/></g></g><path d=\"M50 81Q43 37 78 25Q111 23 128 65L120 108 88 124 58 111Z\" fill=\"#182e48\" stroke=\"#648c9b\" stroke-width=\"1.4\"/><path d=\"M35 208 27 145 56 115 115 111 144 137 161 208Z\" fill=\"url(#suit)\" stroke=\"#19384e\" stroke-width=\"1\"/><path d=\"M44 129 54 208M126 123l14 85\" stroke=\"#e1b854\" stroke-width=\"8\"/><path d=\"M43 129 53 208M125 123l14 85\" stroke=\"#f1cf7b\" stroke-width=\"2\"/><path d=\"M60 53q34-20 62 9v35H58Z\" fill=\"url(#skin)\"/><path d=\"M52 55q39-17 78 7l-2 30H50Z\" fill=\"#233c53\" stroke=\"#d6e9ce\" stroke-width=\"2\"/><rect x=\"57\" y=\"61\" width=\"28\" height=\"22\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"59\" y=\"63\" width=\"24\" height=\"18\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M62 80L79 80\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><rect x=\"96\" y=\"63\" width=\"27\" height=\"22\" rx=\"1\" fill=\"#d9d9c0\"/><rect x=\"98\" y=\"65\" width=\"23\" height=\"18\" rx=\"1\" fill=\"url(#window)\"/><path d=\"M101 82L117 82\" fill=\"none\" stroke=\"#c5ecdc\" stroke-width=\"0.6\"/><path d=\"m86 74 8 1M97 100q-4 27 33 30v34\" stroke=\"#e6bc65\" stroke-width=\"5\" fill=\"none\"/><ellipse cx=\"91\" cy=\"104\" rx=\"11\" ry=\"7\" fill=\"#314959\" stroke=\"#cfdbb8\" stroke-width=\"1\"/><path d=\"m65 155 16-7 27 10-3 38-36-2Z\" fill=\"#173b55\" stroke=\"#a7bcaf\" stroke-width=\"1\"/><g transform=\"translate(87 173) scale(0.8125)\" fill=\"none\" stroke=\"#8cd2d0\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M-5-10H5v5H-5ZM0-5V11M-11 1v5Q0 18 11 6V1M-14 3l3-3 3 3M8 3l3-3 3 3\"/></g><g transform=\"translate(137 107) scale(0.65)\"><circle cx=\"0\" cy=\"0\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"2.1\" cy=\"-8\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"4.2\" cy=\"-16\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-2.7\" cy=\"-24\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-0.6000000000000001\" cy=\"-32\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"1.5\" cy=\"-40\" r=\"1.8\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-5.4\" cy=\"-48\" r=\"1\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/><circle cx=\"-3.3\" cy=\"-56\" r=\"1.4\" fill=\"none\" stroke=\"#c3f9ed\" stroke-width=\"0.7\"/></g><path d=\"M13 163q31-15 53 1l38 19-7 16-41-17-28 15\" fill=\"#314e69\" stroke=\"#557b8b\" stroke-width=\"1\"/></g>",
	captain: "<g clip-path=\"url(#personClip)\"><rect x=\"0\" y=\"0\" width=\"180\" height=\"208\" rx=\"0\" fill=\"url(#portraitWarm)\"/><path d=\"M21 0h17v208H21M142 0h11v208h-11\" fill=\"#edce7a\" opacity=\".23\"/><path d=\"M0 141 180 112v96H0Z\" fill=\"#243644\"/><path d=\"M27 208 34 151Q42 125 66 121H99Q130 126 145 163L157 208Z\" fill=\"#25343b\"/><path d=\"M63 115V97h35v27l-20 17Z\" fill=\"#4a493f\"/><path d=\"M54 46Q58 18 83 22Q109 24 113 51L105 93Q97 115 76 114L57 91Z\" fill=\"#494d44\"/><path d=\"M59 35Q53 70 69 87L68 103 78 110 57 97 49 73 48 46Z\" fill=\"#243338\"/><path d=\"M58 35q30-23 55 5l-3-20Q85 5 63 18Z\" fill=\"#77745c\" stroke=\"#d8be79\" stroke-width=\"1\"/><path d=\"M54 40q31-8 60 5l-5 7-56-6Z\" fill=\"#263339\"/><path d=\"M53 57h57v25H53Z\" fill=\"#132a31\" stroke=\"#bea058\" stroke-width=\"2\"/><path d=\"M57 61h17v16H57ZM87 61h17v16H87Z\" fill=\"#6e795d\"/><path d=\"m60 63 10 2M90 63l10 2M75 69h10\" stroke=\"#c8be78\" stroke-width=\"1\"/><path d=\"M58 123 80 145 63 162 44 139M98 122l-18 23 21 19 16-27\" fill=\"#52605a\"/><path d=\"M81 145v63M53 157l5 51M119 159l9 49\" stroke=\"#94885d\" stroke-width=\"1.3\"/><g transform=\"translate(116 180) scale(0.6875)\" fill=\"none\" stroke=\"#b9a568\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle r=\"8\"/><circle r=\"3\"/><path d=\"M-13 0H-8M8 0h5M0-13V-8M0 8v5M-9-9-6-6M6 6l3 3M-9 9-6 6M6-6l3-3\"/></g><path d=\"M27 186q25-24 42-20l40 19-6 15-34-13-35 21M142 183l-26-13-16 9 23 24\" fill=\"#31464b\" stroke=\"#60736a\" stroke-width=\"1\"/></g>"
}, K = {
	journalActionUsed: "games.endeavordeepsea.journalActionUsed",
	journalActionAvailable: "games.endeavordeepsea.journalActionAvailable",
	and: "games.endeavordeepsea.and",
	or: "games.endeavordeepsea.or",
	abilityLevel: "games.endeavordeepsea.abilityLevel",
	attributeRange: "games.endeavordeepsea.attributeRange",
	reward_R: "games.endeavordeepsea.reward_R",
	reward_I: "games.endeavordeepsea.reward_I",
	reward_C: "games.endeavordeepsea.reward_C",
	reward_G: "games.endeavordeepsea.reward_G",
	reward_r: "games.endeavordeepsea.reward_r",
	reward_d: "games.endeavordeepsea.reward_d",
	reward_h: "games.endeavordeepsea.reward_h",
	reward_p: "games.endeavordeepsea.reward_p",
	reward_a: "games.endeavordeepsea.reward_a",
	reward_l: "games.endeavordeepsea.reward_l",
	discoverDepths: "games.endeavordeepsea.discoverDepths",
	drawSameDepth: "games.endeavordeepsea.drawSameDepth",
	drawDifferentDepths: "games.endeavordeepsea.drawDifferentDepths",
	diveTokenOptions: "games.endeavordeepsea.diveTokenOptions",
	releaseOrca: "games.endeavordeepsea.releaseOrca",
	travelRoute: "games.endeavordeepsea.travelRoute",
	log_recruit: "games.endeavordeepsea.log_recruit",
	log_promote: "games.endeavordeepsea.log_promote",
	log_activate: "games.endeavordeepsea.log_activate",
	log_journal: "games.endeavordeepsea.log_journal",
	log_journalAction: "games.endeavordeepsea.log_journalAction",
	log_sail: "games.endeavordeepsea.log_sail",
	log_sonar: "games.endeavordeepsea.log_sonar",
	log_dive: "games.endeavordeepsea.log_dive",
	log_conserve: "games.endeavordeepsea.log_conserve",
	log_discovery: "games.endeavordeepsea.log_discovery",
	log_tokenResearch: "games.endeavordeepsea.log_tokenResearch",
	log_tokenEffect: "games.endeavordeepsea.log_tokenEffect",
	log_tokenDiscard: "games.endeavordeepsea.log_tokenDiscard",
	log_pass: "games.endeavordeepsea.log_pass",
	scenarioRules: "games.endeavordeepsea.scenarioRules",
	goalUndecided: "games.endeavordeepsea.goalUndecided",
	expedition: "games.endeavordeepsea.expedition",
	trackScore: "games.endeavordeepsea.trackScore",
	ability_R: "games.endeavordeepsea.ability_R",
	ability_I: "games.endeavordeepsea.ability_I",
	ability_C: "games.endeavordeepsea.ability_C",
	ability_G: "games.endeavordeepsea.ability_G",
	subUnlock: "games.endeavordeepsea.subUnlock",
	confirmAction: "games.endeavordeepsea.confirmAction",
	cancelSelection: "games.endeavordeepsea.cancelSelection",
	zoomOut: "games.endeavordeepsea.zoomOut",
	zoomIn: "games.endeavordeepsea.zoomIn",
	oceanOverview: "games.endeavordeepsea.oceanOverview",
	selectSite: "games.endeavordeepsea.selectSite",
	showGoals: "games.endeavordeepsea.showGoals",
	name: "games.endeavordeepsea.name",
	desc: "games.endeavordeepsea.desc",
	invalidAction: "games.endeavordeepsea.invalidAction",
	round: "games.endeavordeepsea.round",
	waiting: "games.endeavordeepsea.waiting",
	resolving: "games.endeavordeepsea.resolving",
	ocean: "games.endeavordeepsea.ocean",
	team: "games.endeavordeepsea.team",
	impact: "games.endeavordeepsea.impact",
	market: "games.endeavordeepsea.market",
	supply: "games.endeavordeepsea.supply",
	scenario: "games.endeavordeepsea.scenario",
	expansions: "games.endeavordeepsea.expansions",
	actions: "games.endeavordeepsea.actions",
	choose: "games.endeavordeepsea.choose",
	details: "games.endeavordeepsea.details",
	all: "games.endeavordeepsea.all",
	noChoices: "games.endeavordeepsea.noChoices",
	noTokens: "games.endeavordeepsea.noTokens",
	disc: "games.endeavordeepsea.disc",
	research: "games.endeavordeepsea.research",
	depth: "games.endeavordeepsea.depth",
	arrival: "games.endeavordeepsea.arrival",
	discovery: "games.endeavordeepsea.discovery",
	junior: "games.endeavordeepsea.junior",
	senior: "games.endeavordeepsea.senior",
	tier: "games.endeavordeepsea.tier",
	occupied: "games.endeavordeepsea.occupied",
	available: "games.endeavordeepsea.available",
	published: "games.endeavordeepsea.published",
	others: "games.endeavordeepsea.others",
	you: "games.endeavordeepsea.you",
	points: "games.endeavordeepsea.points",
	cost: "games.endeavordeepsea.cost",
	left: "games.endeavordeepsea.left",
	diveSite: "games.endeavordeepsea.diveSite",
	journalSite: "games.endeavordeepsea.journalSite",
	conserveSite: "games.endeavordeepsea.conserveSite",
	sonarTrack: "games.endeavordeepsea.sonarTrack",
	emptyOcean: "games.endeavordeepsea.emptyOcean",
	vessels: "games.endeavordeepsea.vessels",
	tokens: "games.endeavordeepsea.tokens",
	launch: "games.endeavordeepsea.launch",
	startPlayer: "games.endeavordeepsea.startPlayer",
	passed: "games.endeavordeepsea.passed",
	log: "games.endeavordeepsea.log",
	board: "games.endeavordeepsea.board",
	links: "games.endeavordeepsea.links",
	upgrade: "games.endeavordeepsea.upgrade",
	badge: "games.endeavordeepsea.badge",
	blueBadge: "games.endeavordeepsea.blueBadge",
	redBadge: "games.endeavordeepsea.redBadge",
	orcaCount: "games.endeavordeepsea.orcaCount",
	cleanup: "games.endeavordeepsea.cleanup",
	journalUse: "games.endeavordeepsea.journalUse",
	goalChoice: "games.endeavordeepsea.goalChoice",
	goalOne: "games.endeavordeepsea.goalOne",
	goalTwo: "games.endeavordeepsea.goalTwo",
	privateDiscovery: "games.endeavordeepsea.privateDiscovery",
	column: "games.endeavordeepsea.column",
	allActions: "games.endeavordeepsea.allActions",
	afterMain: "games.endeavordeepsea.afterMain",
	main: "games.endeavordeepsea.main",
	over: "games.endeavordeepsea.over",
	scoreTracks: "games.endeavordeepsea.scoreTracks",
	scoreImpact: "games.endeavordeepsea.scoreImpact",
	scoreCards: "games.endeavordeepsea.scoreCards",
	scoreGoal1: "games.endeavordeepsea.scoreGoal1",
	scoreGoal2: "games.endeavordeepsea.scoreGoal2",
	scoreGoal3: "games.endeavordeepsea.scoreGoal3",
	scoreLeft: "games.endeavordeepsea.scoreLeft",
	choosePosition: "games.endeavordeepsea.choosePosition",
	tokenValue: "games.endeavordeepsea.tokenValue",
	special: "games.endeavordeepsea.special",
	remainingResearch: "games.endeavordeepsea.remainingResearch",
	hex: "games.endeavordeepsea.hex",
	linkPair: "games.endeavordeepsea.linkPair",
	sharedRobot: "games.endeavordeepsea.sharedRobot",
	attribute_R: "games.endeavordeepsea.attribute_R",
	attribute_I: "games.endeavordeepsea.attribute_I",
	attribute_C: "games.endeavordeepsea.attribute_C",
	attribute_G: "games.endeavordeepsea.attribute_G",
	field_blue: "games.endeavordeepsea.field_blue",
	field_brown: "games.endeavordeepsea.field_brown",
	field_green: "games.endeavordeepsea.field_green",
	field_yellow: "games.endeavordeepsea.field_yellow",
	action_sail: "games.endeavordeepsea.action_sail",
	action_sonar: "games.endeavordeepsea.action_sonar",
	action_dive: "games.endeavordeepsea.action_dive",
	action_conserve: "games.endeavordeepsea.action_conserve",
	action_journal: "games.endeavordeepsea.action_journal",
	action_promote: "games.endeavordeepsea.action_promote",
	action_copy: "games.endeavordeepsea.action_copy",
	action_accept: "games.endeavordeepsea.action_accept",
	action_skip: "games.endeavordeepsea.action_skip",
	action_launch: "games.endeavordeepsea.action_launch",
	action_recruit: "games.endeavordeepsea.action_recruit",
	action_reassign: "games.endeavordeepsea.action_reassign",
	action_attribute: "games.endeavordeepsea.action_attribute",
	action_impact: "games.endeavordeepsea.action_impact",
	action_order: "games.endeavordeepsea.action_order",
	action_divePick: "games.endeavordeepsea.action_divePick",
	action_draw: "games.endeavordeepsea.action_draw",
	action_placeOcean: "games.endeavordeepsea.action_placeOcean",
	action_fullOcean: "games.endeavordeepsea.action_fullOcean",
	action_robotPlace: "games.endeavordeepsea.action_robotPlace",
	action_robotMove: "games.endeavordeepsea.action_robotMove",
	action_upgrade: "games.endeavordeepsea.action_upgrade",
	action_badge: "games.endeavordeepsea.action_badge",
	action_badgeUpgrade: "games.endeavordeepsea.action_badgeUpgrade",
	action_goal: "games.endeavordeepsea.action_goal",
	action_tradeDisc: "games.endeavordeepsea.action_tradeDisc",
	action_activate: "games.endeavordeepsea.action_activate",
	action_journalAction: "games.endeavordeepsea.action_journalAction",
	action_pass: "games.endeavordeepsea.action_pass",
	action_end: "games.endeavordeepsea.action_end",
	action_tokenResearch: "games.endeavordeepsea.action_tokenResearch",
	action_tokenEffect: "games.endeavordeepsea.action_tokenEffect",
	action_tokenDiscard: "games.endeavordeepsea.action_tokenDiscard",
	action_conserveDepth: "games.endeavordeepsea.action_conserveDepth",
	action_conserveCheap: "games.endeavordeepsea.action_conserveCheap",
	action_sailPlus: "games.endeavordeepsea.action_sailPlus",
	action_dive2: "games.endeavordeepsea.action_dive2",
	"action_x3-5": "games.endeavordeepsea.action_x3-5",
	action_orca: "games.endeavordeepsea.action_orca",
	prompt_setup: "games.endeavordeepsea.prompt_setup",
	prompt_recruit: "games.endeavordeepsea.prompt_recruit",
	prompt_reassign: "games.endeavordeepsea.prompt_reassign",
	prompt_reward: "games.endeavordeepsea.prompt_reward",
	prompt_attribute: "games.endeavordeepsea.prompt_attribute",
	prompt_promote: "games.endeavordeepsea.prompt_promote",
	prompt_impact: "games.endeavordeepsea.prompt_impact",
	prompt_order: "games.endeavordeepsea.prompt_order",
	prompt_copy: "games.endeavordeepsea.prompt_copy",
	prompt_sail: "games.endeavordeepsea.prompt_sail",
	prompt_sonar: "games.endeavordeepsea.prompt_sonar",
	prompt_dive: "games.endeavordeepsea.prompt_dive",
	prompt_divePick: "games.endeavordeepsea.prompt_divePick",
	prompt_conserve: "games.endeavordeepsea.prompt_conserve",
	prompt_journal: "games.endeavordeepsea.prompt_journal",
	prompt_discover: "games.endeavordeepsea.prompt_discover",
	prompt_placeOcean: "games.endeavordeepsea.prompt_placeOcean",
	prompt_robotPlace: "games.endeavordeepsea.prompt_robotPlace",
	prompt_robotMove: "games.endeavordeepsea.prompt_robotMove",
	prompt_upgrade: "games.endeavordeepsea.prompt_upgrade",
	prompt_badge: "games.endeavordeepsea.prompt_badge",
	prompt_badgeUpgrade: "games.endeavordeepsea.prompt_badgeUpgrade",
	prompt_goal: "games.endeavordeepsea.prompt_goal",
	prompt_tradeDisc: "games.endeavordeepsea.prompt_tradeDisc",
	prompt_launch: "games.endeavordeepsea.prompt_launch",
	ocean_seaStar: "games.endeavordeepsea.ocean_seaStar",
	ocean_reef: "games.endeavordeepsea.ocean_reef",
	ocean_volcano: "games.endeavordeepsea.ocean_volcano",
	ocean_kelp: "games.endeavordeepsea.ocean_kelp",
	ocean_anchorage: "games.endeavordeepsea.ocean_anchorage",
	ocean_rig: "games.endeavordeepsea.ocean_rig",
	ocean_calm: "games.endeavordeepsea.ocean_calm",
	ocean_atoll: "games.endeavordeepsea.ocean_atoll",
	ocean_lookingGlass: "games.endeavordeepsea.ocean_lookingGlass",
	ocean_dolphins: "games.endeavordeepsea.ocean_dolphins",
	ocean_ruins: "games.endeavordeepsea.ocean_ruins",
	ocean_pod: "games.endeavordeepsea.ocean_pod",
	ocean_cave: "games.endeavordeepsea.ocean_cave",
	ocean_wreck: "games.endeavordeepsea.ocean_wreck",
	ocean_whales: "games.endeavordeepsea.ocean_whales",
	ocean_elevator: "games.endeavordeepsea.ocean_elevator",
	ocean_turtles: "games.endeavordeepsea.ocean_turtles",
	ocean_jellyfish: "games.endeavordeepsea.ocean_jellyfish",
	ocean_vortex: "games.endeavordeepsea.ocean_vortex",
	ocean_vents: "games.endeavordeepsea.ocean_vents",
	ocean_sharks: "games.endeavordeepsea.ocean_sharks",
	ocean_rift: "games.endeavordeepsea.ocean_rift",
	ocean_spires: "games.endeavordeepsea.ocean_spires",
	ocean_coldReef: "games.endeavordeepsea.ocean_coldReef",
	ocean_whaleFall: "games.endeavordeepsea.ocean_whaleFall",
	ocean_plain: "games.endeavordeepsea.ocean_plain",
	ocean_snails: "games.endeavordeepsea.ocean_snails",
	ocean_lostStar: "games.endeavordeepsea.ocean_lostStar",
	ocean_trench: "games.endeavordeepsea.ocean_trench",
	ocean_smokers: "games.endeavordeepsea.ocean_smokers",
	ocean_recovery: "games.endeavordeepsea.ocean_recovery",
	ocean_bioluminescence: "games.endeavordeepsea.ocean_bioluminescence",
	ocean_shelf: "games.endeavordeepsea.ocean_shelf",
	ocean_squid: "games.endeavordeepsea.ocean_squid",
	ocean_brine: "games.endeavordeepsea.ocean_brine",
	ocean_sponge: "games.endeavordeepsea.ocean_sponge",
	ocean_seamount: "games.endeavordeepsea.ocean_seamount",
	ocean_orca: "games.endeavordeepsea.ocean_orca",
	ocean_academy: "games.endeavordeepsea.ocean_academy",
	ocean_robot: "games.endeavordeepsea.ocean_robot",
	expert_371: "games.endeavordeepsea.expert_371",
	senior_371: "games.endeavordeepsea.senior_371",
	expert_372: "games.endeavordeepsea.expert_372",
	senior_372: "games.endeavordeepsea.senior_372",
	expert_373: "games.endeavordeepsea.expert_373",
	senior_373: "games.endeavordeepsea.senior_373",
	expert_374: "games.endeavordeepsea.expert_374",
	senior_374: "games.endeavordeepsea.senior_374",
	expert_375: "games.endeavordeepsea.expert_375",
	senior_375: "games.endeavordeepsea.senior_375",
	expert_376: "games.endeavordeepsea.expert_376",
	senior_376: "games.endeavordeepsea.senior_376",
	expert_377: "games.endeavordeepsea.expert_377",
	senior_377: "games.endeavordeepsea.senior_377",
	expert_378: "games.endeavordeepsea.expert_378",
	senior_378: "games.endeavordeepsea.senior_378",
	expert_379: "games.endeavordeepsea.expert_379",
	senior_379: "games.endeavordeepsea.senior_379",
	expert_380: "games.endeavordeepsea.expert_380",
	senior_380: "games.endeavordeepsea.senior_380",
	expert_381: "games.endeavordeepsea.expert_381",
	senior_381: "games.endeavordeepsea.senior_381",
	expert_382: "games.endeavordeepsea.expert_382",
	senior_382: "games.endeavordeepsea.senior_382",
	expert_383: "games.endeavordeepsea.expert_383",
	senior_383: "games.endeavordeepsea.senior_383",
	expert_384: "games.endeavordeepsea.expert_384",
	senior_384: "games.endeavordeepsea.senior_384",
	expert_386: "games.endeavordeepsea.expert_386",
	senior_386: "games.endeavordeepsea.senior_386",
	expert_387: "games.endeavordeepsea.expert_387",
	senior_387: "games.endeavordeepsea.senior_387",
	expert_388: "games.endeavordeepsea.expert_388",
	senior_388: "games.endeavordeepsea.senior_388",
	expert_389: "games.endeavordeepsea.expert_389",
	senior_389: "games.endeavordeepsea.senior_389",
	expert_390: "games.endeavordeepsea.expert_390",
	senior_390: "games.endeavordeepsea.senior_390",
	expert_391: "games.endeavordeepsea.expert_391",
	senior_391: "games.endeavordeepsea.senior_391",
	expert_392: "games.endeavordeepsea.expert_392",
	senior_392: "games.endeavordeepsea.senior_392",
	expert_393: "games.endeavordeepsea.expert_393",
	senior_393: "games.endeavordeepsea.senior_393",
	journal_0: "games.endeavordeepsea.journal_0",
	journal_1: "games.endeavordeepsea.journal_1",
	journal_2: "games.endeavordeepsea.journal_2",
	journal_3: "games.endeavordeepsea.journal_3",
	journal_4: "games.endeavordeepsea.journal_4",
	journal_5: "games.endeavordeepsea.journal_5",
	journal_6: "games.endeavordeepsea.journal_6",
	journal_7: "games.endeavordeepsea.journal_7",
	journal_8: "games.endeavordeepsea.journal_8",
	journal_9: "games.endeavordeepsea.journal_9",
	journal_10: "games.endeavordeepsea.journal_10",
	journal_11: "games.endeavordeepsea.journal_11",
	journal_12: "games.endeavordeepsea.journal_12",
	journal_13: "games.endeavordeepsea.journal_13",
	journal_14: "games.endeavordeepsea.journal_14",
	journal_15: "games.endeavordeepsea.journal_15",
	journal_16: "games.endeavordeepsea.journal_16",
	journal_17: "games.endeavordeepsea.journal_17",
	journal_18: "games.endeavordeepsea.journal_18",
	journal_19: "games.endeavordeepsea.journal_19",
	journal_20: "games.endeavordeepsea.journal_20",
	journal_21: "games.endeavordeepsea.journal_21",
	journal_22: "games.endeavordeepsea.journal_22",
	journal_23: "games.endeavordeepsea.journal_23",
	journal_24: "games.endeavordeepsea.journal_24",
	journal_25: "games.endeavordeepsea.journal_25",
	journal_26: "games.endeavordeepsea.journal_26",
	journal_27: "games.endeavordeepsea.journal_27",
	journal_28: "games.endeavordeepsea.journal_28",
	journal_29: "games.endeavordeepsea.journal_29",
	journal_30: "games.endeavordeepsea.journal_30",
	journal_31: "games.endeavordeepsea.journal_31",
	scenario_1: "games.endeavordeepsea.scenario_1",
	scenario_2: "games.endeavordeepsea.scenario_2",
	scenario_3: "games.endeavordeepsea.scenario_3",
	scenario_4: "games.endeavordeepsea.scenario_4",
	scenario_5: "games.endeavordeepsea.scenario_5",
	scenario_6: "games.endeavordeepsea.scenario_6",
	scenario_7: "games.endeavordeepsea.scenario_7",
	scenario_8: "games.endeavordeepsea.scenario_8",
	scenario_9: "games.endeavordeepsea.scenario_9",
	scenario_10: "games.endeavordeepsea.scenario_10",
	goal_1_0: "games.endeavordeepsea.goal_1_0",
	goal_1_1: "games.endeavordeepsea.goal_1_1",
	goal_1_2: "games.endeavordeepsea.goal_1_2",
	goal_2_0: "games.endeavordeepsea.goal_2_0",
	goal_2_1: "games.endeavordeepsea.goal_2_1",
	goal_2_2: "games.endeavordeepsea.goal_2_2",
	goal_3_0: "games.endeavordeepsea.goal_3_0",
	goal_3_1: "games.endeavordeepsea.goal_3_1",
	goal_3_2: "games.endeavordeepsea.goal_3_2",
	goal_4_0: "games.endeavordeepsea.goal_4_0",
	goal_4_1: "games.endeavordeepsea.goal_4_1",
	goal_4_2: "games.endeavordeepsea.goal_4_2",
	goal_5_0: "games.endeavordeepsea.goal_5_0",
	goal_5_1: "games.endeavordeepsea.goal_5_1",
	goal_5_2: "games.endeavordeepsea.goal_5_2",
	goal_6_0: "games.endeavordeepsea.goal_6_0",
	goal_6_1: "games.endeavordeepsea.goal_6_1",
	goal_6_2: "games.endeavordeepsea.goal_6_2",
	goal_7_0: "games.endeavordeepsea.goal_7_0",
	goal_7_1: "games.endeavordeepsea.goal_7_1",
	goal_7_2: "games.endeavordeepsea.goal_7_2",
	goal_8_0: "games.endeavordeepsea.goal_8_0",
	goal_8_1: "games.endeavordeepsea.goal_8_1",
	goal_8_2: "games.endeavordeepsea.goal_8_2",
	goal_9_0: "games.endeavordeepsea.goal_9_0",
	goal_9_1: "games.endeavordeepsea.goal_9_1",
	goal_9_2: "games.endeavordeepsea.goal_9_2",
	goal_10_0: "games.endeavordeepsea.goal_10_0",
	goal_10_1: "games.endeavordeepsea.goal_10_1",
	goal_10_2: "games.endeavordeepsea.goal_10_2",
	special_rig: "games.endeavordeepsea.special_rig",
	special_whales: "games.endeavordeepsea.special_whales",
	special_ruins: "games.endeavordeepsea.special_ruins",
	special_wreck: "games.endeavordeepsea.special_wreck",
	special_turtles: "games.endeavordeepsea.special_turtles",
	special_cave: "games.endeavordeepsea.special_cave",
	special_jellyfish: "games.endeavordeepsea.special_jellyfish",
	special_vortex: "games.endeavordeepsea.special_vortex",
	special_vents: "games.endeavordeepsea.special_vents",
	special_sharks: "games.endeavordeepsea.special_sharks",
	special_seamount: "games.endeavordeepsea.special_seamount",
	special_brine: "games.endeavordeepsea.special_brine",
	special_bioluminescence: "games.endeavordeepsea.special_bioluminescence",
	special_plain: "games.endeavordeepsea.special_plain",
	special_smokers: "games.endeavordeepsea.special_smokers",
	special_trench: "games.endeavordeepsea.special_trench",
	special_snails: "games.endeavordeepsea.special_snails",
	special_lostStar: "games.endeavordeepsea.special_lostStar",
	special_orca: "games.endeavordeepsea.special_orca",
	special_academy: "games.endeavordeepsea.special_academy",
	special_robot: "games.endeavordeepsea.special_robot",
	scenarioRule_1: "games.endeavordeepsea.scenarioRule_1",
	scenarioRule_2: "games.endeavordeepsea.scenarioRule_2",
	scenarioRule_3: "games.endeavordeepsea.scenarioRule_3",
	scenarioRule_4: "games.endeavordeepsea.scenarioRule_4",
	scenarioRule_5: "games.endeavordeepsea.scenarioRule_5",
	scenarioRule_6: "games.endeavordeepsea.scenarioRule_6",
	scenarioRule_7: "games.endeavordeepsea.scenarioRule_7",
	scenarioRule_8: "games.endeavordeepsea.scenarioRule_8",
	scenarioRule_9: "games.endeavordeepsea.scenarioRule_9",
	scenarioRule_10: "games.endeavordeepsea.scenarioRule_10",
	rules: "games.endeavordeepsea.rules",
	action_relocateOcean: "games.endeavordeepsea.action_relocateOcean",
	prompt_relocateOcean: "games.endeavordeepsea.prompt_relocateOcean",
	siteNumber: "games.endeavordeepsea.siteNumber",
	sonarPosition: "games.endeavordeepsea.sonarPosition",
	moveImpact: "games.endeavordeepsea.moveImpact",
	goal_near: "games.endeavordeepsea.goal_near",
	goal_far: "games.endeavordeepsea.goal_far",
	goal_shallow: "games.endeavordeepsea.goal_shallow",
	goal_deep: "games.endeavordeepsea.goal_deep",
	goal_specialize: "games.endeavordeepsea.goal_specialize",
	goal_diversify: "games.endeavordeepsea.goal_diversify",
	goal_conserve: "games.endeavordeepsea.goal_conserve",
	goal_journal: "games.endeavordeepsea.goal_journal",
	expertScore_383: "games.endeavordeepsea.expertScore_383",
	expertScore_384: "games.endeavordeepsea.expertScore_384",
	expertScore_386: "games.endeavordeepsea.expertScore_386",
	expertScore_387: "games.endeavordeepsea.expertScore_387",
	expertScore_388: "games.endeavordeepsea.expertScore_388",
	expertScore_389: "games.endeavordeepsea.expertScore_389",
	expertScore_390: "games.endeavordeepsea.expertScore_390",
	expertScore_391: "games.endeavordeepsea.expertScore_391",
	expertScore_392: "games.endeavordeepsea.expertScore_392",
	prompt_refillExpert: "games.endeavordeepsea.prompt_refillExpert",
	action_refillExpert: "games.endeavordeepsea.action_refillExpert"
}, lt = {
	R: "🗣",
	I: "💡",
	C: "🧭",
	G: "🧩",
	r: "🧬",
	d: "●",
	h: "★",
	p: "⇧",
	a: "◉",
	l: "⇡",
	sail: "⎈",
	sonar: "◉",
	dive: "⚓",
	conserve: "🐢",
	journal: "▤",
	promote: "⇧",
	copy: "▣",
	orca: "🐋",
	badge: "⬡",
	robotMove: "🤖",
	sailPlus: "⎈⁺",
	dive2: "⚓²",
	conserveDepth: "🐢↔",
	conserveCheap: "🐢⁻¹",
	tradeDisc: "●→🧬5"
}, ut = {
	blue: "#8dc6dc",
	brown: "#c69b75",
	green: "#b3c65a",
	yellow: "#f0cb65"
}, dt = {
	blue: "▲",
	brown: "⨝",
	green: "◆",
	yellow: "◒"
};
function ft(e) {
	return e.split(/\s+/).filter(Boolean).map((e) => {
		if (e.startsWith("x")) return `◉ ${e.slice(1)}`;
		let t = /^([RICGrdphal])(\d+)$/.exec(e);
		return t ? `${lt[t[1]]}${t[2]}` : lt[e] ?? e;
	}).join("  ");
}
function q(e, t) {
	return e.trim().split(/\s+/).filter(Boolean).map((e) => {
		let n = /^([RICGrdphal])(\d+)$/.exec(e);
		if (n) return t(K["reward_" + n[1]], { n: Number(n[2]) });
		let r = /^x(\d+)-(\d+)$/.exec(e);
		return r ? t(K.discoverDepths, {
			from: Number(r[1]),
			to: Number(r[2])
		}) : X(e, t);
	}).join(t(K.and));
}
var J = (e, t) => t(K[`ocean_${e}`]), Y = (e, t, n) => n(K[`${t ? "senior" : "expert"}_${e}`]), X = (e, t) => t(K[`action_${e}`] ?? K.choose);
function pt(e, t, n) {
	let r = t.players.find((e) => e.rid === t.acting);
	if (e.kind === "recruit") {
		let t = y[e.expert];
		return [
			Y(e.expert, !1, n),
			n(K.tier, { n: t.tier }),
			q(t.junior, n),
			t.actions.map((e) => e.map((e) => X(e, n)).join(n(K.and))).join(n(K.or))
		].filter(Boolean).join(" · ");
	}
	if (e.kind === "refillExpert") return `${X(e.kind, n)} · ${Y(e.expert, !1, n)}`;
	if (e.kind === "activate" || e.kind === "copy") {
		let t = r?.experts.find((t) => t.uid === e.expert);
		return `${t ? Y(t.id, t.senior, n) : ""} · ${(e.value ?? "").split(",").map((e) => X(e, n)).join(n(K.and))}`;
	}
	if (e.kind === "order") return X(e.value, n);
	if (e.kind === "attribute") return n(K[`attribute_${e.value}`]);
	if (e.kind === "promote" || e.kind === "reassign" || e.kind === "badgeUpgrade") {
		let t = r?.experts.find((t) => t.uid === e.expert);
		return `${X(e.kind, n)} · ${t ? Y(t.id, t.senior, n) : ""}`;
	}
	if (e.kind === "badge") {
		let t = r?.experts.find((t) => t.uid === e.expert);
		return `${X(ye[e.n], n)} · ${t ? Y(t.id, t.senior, n) : ""}`;
	}
	if (e.kind === "journal") return `${n(K[`journal_${e.card}`])} · ${J(e.zone, n)} · ${n(K.siteNumber, { n: Number(e.value?.slice(1)) + 1 })} · ${n(K.cost, { n: x[e.card].cost })}`;
	if (e.kind === "journalAction") return `${n(K[`journal_${e.card}`])} · ${X(e.value, n)}`;
	if (e.kind === "placeOcean" || e.kind === "relocateOcean") return `${J(e.zone, n)} · ${n(K.choosePosition, { col: String.fromCharCode(65 + e.n) })}`;
	if (e.kind === "draw") {
		let [t, r] = e.value.split(",").map(Number);
		return t === r ? n(K.drawSameDepth, { n: t }) : n(K.drawDifferentDepths, {
			from: t,
			to: r
		});
	}
	if (e.kind === "goal") return ht(t.config.scenario, t.effect?.n ?? 0, e.n, n);
	if (e.kind === "tokenResearch") return n(K.tokenValue, { n: e.card === void 0 ? 0 : S[e.card].research });
	if (e.kind === "tokenEffect") return q(e.value ?? "", n);
	if (e.kind === "divePick") {
		let t = S[Number(e.value)];
		return t.effect ? n(K.diveTokenOptions, {
			n: t.research,
			effect: q(t.effect, n)
		}) : n(K.tokenValue, { n: t.research });
	}
	if (e.kind === "upgrade") return `${X(e.kind, n)} · ${X(e.value, n)}`;
	if (e.kind === "impact") return e.hex === "conserve" ? n(K.points, { n: 3 }) : e.value ? n(K.moveImpact, {
		from: Number(e.value) + 1,
		to: Number(e.hex) + 1
	}) : n(K.hex, { n: Number(e.hex) + 1 });
	if (e.zone) {
		let t = D[e.zone]?.sites.find((t) => t.id === e.value), i = e.kind === "sonar" && t ? n(K.sonarPosition, {
			track: t.track + 1,
			n: Number(t.id.split("-")[1]) + 1
		}) : t ? n(K.siteNumber, { n: Number(t.id.slice(1)) + 1 }) : e.kind === "dive" ? n(K.siteNumber, { n: e.n + 1 }) : "";
		return e.kind === "sail" ? n(K.travelRoute, {
			from: J(r.vessels[e.n], n),
			to: J(e.zone, n)
		}) : `${X(e.kind, n)} · ${J(e.zone, n)}${i ? ` · ${i}` : ""}${e.kind === "conserve" ? ` · ${n(K.cost, { n: e.n ?? 0 })}${e.card ? " · " + n(K.releaseOrca) : ""}` : ""}${t?.reward ? ` · ${q(t.reward, n)}` : ""}`;
	}
	return e.kind === "accept" ? q(e.value ?? "", n) : X(e.kind, n);
}
function mt(e, t) {
	return e.kind === "recruit" ? t(K.log_recruit, { expert: Y(Number(e.value), !1, t) }) : e.kind === "promote" ? t(K.log_promote, { expert: Y(Number(e.value), !0, t) }) : e.kind === "activate" ? t(K.log_activate) : e.kind === "journal" || e.kind === "journalAction" ? t(K["log_" + e.kind], { journal: t(K["journal_" + e.value]) }) : e.kind === "tokenResearch" ? t(K.log_tokenResearch, { n: S[e.n].research }) : e.kind === "tokenEffect" ? t(K.log_tokenEffect, { effect: q(S[e.n].effect, t) }) : e.kind === "tokenDiscard" || e.kind === "pass" ? t(K["log_" + e.kind]) : e.value && D[e.value] ? t(K["log_" + e.kind], { ocean: J(e.value, t) }) : X(e.kind, t);
}
function ht(e, t, n, r) {
	return r((e === 6 ? [K.goal_conserve, K.goal_journal] : t === 0 ? [K.goal_near, K.goal_far] : t === 1 ? [K.goal_shallow, K.goal_deep] : [K.goal_specialize, K.goal_diversify])[n]);
}
//#endregion
//#region src/games/endeavordeepsea/art.tsx
var gt = {
	sonar: "<circle r=\"9\"/><path d=\"M-12 5A13 13 0 0 1 5-12M-6 5A7 7 0 0 1 5-6M0 5V0h5M-12 12 8-8\"/>",
	sail: "<circle r=\"8\"/><circle r=\"3\"/><path d=\"M-13 0H-8M8 0h5M0-13V-8M0 8v5M-9-9-6-6M6 6l3 3M-9 9-6 6M6-6l3-3\"/>",
	dive: "<path d=\"M-5-10H5v5H-5ZM0-5V11M-11 1v5Q0 18 11 6V1M-14 3l3-3 3 3M8 3l3-3 3 3\"/>",
	conserve: "<path d=\"M-7-6Q0-12 7-6L10 3Q0 13-10 3ZM0-8V8M-8-3 8 4M8-3-8 4M-11-5-15-8M11-5l4-3M-10 5-13 9M10 5l3 4M-2-11V-15h4v4\"/>",
	journal: "<path d=\"M-10-12H10V12H-10ZM-14-8h7M-14-1h7M-14 6h7M-3-5H6M-3 0H6M-3 5H4\"/>",
	R: "<path d=\"M-9-11H9v15H2L-5 10V4H-9Z\"/><path d=\"M-4-5H5M-4-1H3\"/>",
	I: "<path d=\"M-5 5C-5 0-10-1-8-7S8-14 8-6C8-1 4 1 5 5ZM-5 9H5M-3 13H3\"/>",
	C: "<circle r=\"12\"/><path d=\"m-5 5 3-8 8-3-3 8Z\"/>",
	G: "<path d=\"M-12-10H-4Q-7-16 0-16T4-10H12v8Q18-6 18 1T12 4V12H4Q7 6 0 6T-4 12H-12V4Q-6 7-6 0T-12-4Z\"/>",
	r: "<path d=\"M-8-13Q8-9-8 0T8 13M8-13Q-8-9 8 0T-8 13M-5-9H5M-5-3H5M-5 3H5M-5 9H5\"/>",
	d: "<circle r=\"11\"/><circle r=\"7\"/><path d=\"M-4 0H4M0-4v8\"/>",
	h: "<path d=\"m0-13 4 8 9 1-6 7 2 10-9-5-9 5 2-10-6-7 9-1Z\"/>",
	p: "<path d=\"M-10 9V1H10v8M0 1v-15m-7 7 7-7 7 7\"/>",
	a: "<path d=\"M-10 9V1H10v8M0 1v-15m-7 7 7-7 7 7\"/><circle r=\"15\"/>",
	l: "<path d=\"m-9 2 9-12 9 12M0-10v23\"/>",
	retrieve: "<circle r=\"6\"/><path d=\"M-12-3A13 13 0 1 1-8 10M-12-3v-8m0 8 8-2\"/>",
	people: "<circle cx=\"-5\" cy=\"-5\" r=\"5\"/><circle cx=\"9\" cy=\"-3\" r=\"4\"/><path d=\"M-15 12v-5Q-5-3 5 7v5M8 3q10-2 10 9\"/>",
	hex: "<path d=\"m-11-6 11-7 11 7V7L0 14-11 7Z\"/>",
	copy: "<path d=\"M-12-12H5V6H-12ZM-5-5H12V12H-5Z\"/>",
	orca: "<path d=\"M-14 4Q-3-11 8-4L14-10 12 1l3 7-9-3Q-6 12-14 4ZM0-4l3-9 3 10\"/>",
	robotMove: "<path d=\"M-12-8H12V10H-12ZM0-8v-7m-6 12v5m12-5v5M-7 6H7\"/>"
}, _t = {
	research: "r",
	disc: "d",
	star: "h",
	promote: "p",
	sailPlus: "sail",
	dive2: "dive",
	conserveDepth: "conserve",
	conserveCheap: "conserve",
	tradeDisc: "d",
	badge: "hex"
}, vt = {
	R: "#d88639",
	I: "#6fa546",
	C: "#e0b83e",
	G: "#3b9ac6",
	r: "#b95759",
	d: "#aebebc",
	h: "#9d5a96",
	p: "#adbeb7",
	a: "#abbdb6",
	l: "#8ab6b9"
};
function Z({ kind: e, size: t = 24, className: n = "" }) {
	return /* @__PURE__ */ g("svg", {
		className: "eds-glyph " + n,
		width: t,
		height: t,
		viewBox: "-18 -18 36 36",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0,
		dangerouslySetInnerHTML: { __html: gt[_t[e] ?? e] ?? gt.sonar }
	});
}
function yt({ kind: e, n: t }) {
	return /* @__PURE__ */ _("span", {
		className: "eds-coin",
		style: { background: vt[e] ?? "#b4ab70" },
		children: [/* @__PURE__ */ g(Z, {
			kind: e,
			size: 17
		}), t && String(t) !== "1" ? /* @__PURE__ */ g("b", { children: t }) : null]
	});
}
function Q({ value: e }) {
	let t = u();
	return /* @__PURE__ */ g("span", {
		className: "eds-reward",
		"aria-label": q(e, t),
		title: q(e, t),
		children: e.trim().split(/\s+/).filter(Boolean).map((e, t) => {
			let n = /^([RICGrdphal])(\d+)$/.exec(e);
			return n ? /* @__PURE__ */ g(yt, {
				kind: n[1],
				n: n[2]
			}, t) : e.startsWith("x") ? /* @__PURE__ */ _("span", {
				className: "eds-depth-reward",
				children: [/* @__PURE__ */ g(Z, {
					kind: "sonar",
					size: 15
				}), e.slice(1).replace("-", "–")]
			}, t) : /* @__PURE__ */ _("span", {
				className: "eds-effect-glyph",
				children: [/* @__PURE__ */ g(Z, { kind: e }), e === "dive2" ? "×2" : e === "sailPlus" ? "+" : e === "conserveCheap" ? "−1" : ""]
			}, t);
		})
	});
}
function bt({ name: e, color: t, className: n = "" }) {
	return /* @__PURE__ */ g("span", {
		className: "eds-player-disc " + n,
		style: { "--eds-player": t },
		title: e,
		children: e.slice(0, 1)
	});
}
function xt({ color: e = "#f4c759", size: t = 34 }) {
	return /* @__PURE__ */ _("svg", {
		width: t,
		height: t * .54,
		viewBox: "0 0 80 43",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ g("path", {
				d: "M9 19h52c16 0 19 22 0 22H13C-1 41-3 19 9 19Z",
				fill: e,
				stroke: "#123b51",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M29 19V8h18v11M35 8V2h16",
				fill: e,
				stroke: "#123b51",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "17",
				cy: "30",
				r: "5",
				fill: "#e2f6f5"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "34",
				cy: "30",
				r: "5",
				fill: "#e2f6f5"
			}),
			/* @__PURE__ */ g("circle", {
				cx: "51",
				cy: "30",
				r: "5",
				fill: "#e2f6f5"
			}),
			/* @__PURE__ */ g("path", {
				d: "m70 22 7-5v26l-7-6",
				fill: e,
				stroke: "#123b51",
				strokeWidth: "2"
			})
		]
	});
}
function St({ content: e, viewBox: t, className: n }) {
	let i = "eds" + r().replace(/[^a-zA-Z0-9]/g, ""), a = (ot + e).replace(/id="([^"]+)"/g, "id=\"" + i + "-$1\"").replace(/url\(#([^)]+)\)/g, "url(#" + i + "-$1)");
	return /* @__PURE__ */ g("svg", {
		className: n,
		viewBox: t,
		preserveAspectRatio: n === "eds-expert-art" ? "none" : "xMidYMid slice",
		"aria-hidden": !0,
		dangerouslySetInnerHTML: { __html: a }
	});
}
function Ct({ ocean: e }) {
	let t = e.depth === 1, n = e.depth === 2 ? "<path d=\"M57 0h42L42 264H0ZM197 0h21l-36 264h-30ZM325 0h10l62 264h-28Z\" fill=\"#a4ffe6\" opacity=\".055\"/>" : "", r = Array.from({ length: 22 }, (e, n) => "<circle cx=\"" + (9 + n * 71 % 402) + "\" cy=\"" + (40 + n * 47 % 214) + "\" r=\"" + (.5 + n % 3 * .3) + "\" fill=\"" + (t ? "#e1fff0" : "#72dbef") + "\" opacity=\".3\"/>").join("");
	return /* @__PURE__ */ g(St, {
		className: "eds-ocean-art",
		viewBox: "0 0 420 264",
		content: "<rect width=\"420\" height=\"264\" fill=\"url(#sea" + e.depth + ")\"/>" + n + st[e.id] + r
	});
}
function wt({ id: e }) {
	return /* @__PURE__ */ g(St, {
		className: "eds-expert-art",
		viewBox: "0 0 180 208",
		content: ct[e === 393 ? "captain" : [
			371,
			375,
			377,
			383,
			386,
			389,
			391
		].includes(e) ? "sonar" : "diver"]
	});
}
//#endregion
//#region src/games/endeavordeepsea/board.tsx
function Tt(e) {
	let t = {}, n = e.sites, r = n.filter((e) => e.kind === "conserve"), i = n.filter((e) => e.kind === "journal"), a = [...new Set(n.filter((e) => e.kind === "sonar").map((e) => e.track))], o = {
		rig: [
			[56, 110],
			[168, 110],
			[280, 130],
			[365, 198]
		],
		whales: [
			[65, 110],
			[173, 106],
			[294, 120],
			[78, 201],
			[212, 200],
			[358, 203]
		],
		jellyfish: [[100, 198], [309, 182]],
		whaleFall: [
			[75, 146],
			[211, 154],
			[352, 139]
		],
		cave: [[210, 152]]
	};
	return r.forEach((n, i) => {
		t[n.id] = o[e.id]?.[i] ?? (r.length === 1 ? [210, 146] : [65 + i % 3 * 142, r.length > 3 ? 107 + Math.floor(i / 3) * 93 : 160 + i % 2 * 28]);
	}), i.forEach((n, a) => {
		t[n.id] = e.id === "jellyfish" ? [220, 103] : e.id === "whales" ? [30, 161] : e.id === "whaleFall" ? [[132, 93], [300, 204]][a] : r.length > 3 ? [28 + a * 88, 155] : [65 + a * (i.length === 1 ? 0 : 290 / (i.length - 1)), 99];
	}), a.forEach((r, i) => {
		let o = n.filter((e) => e.track === r && e.kind === "sonar"), s = e.dives.length ? 280 : 344;
		o.forEach((e, n) => t[e.id] = [51 + n * Math.min(71, s / Math.max(1, o.length - 1)), a.length === 1 ? 222 : a.length === 2 ? 174 + i * 49 : 126 + i * 49]);
	}), t;
}
function Et({ v: e, id: t, t: n, color: r, name: i, legal: a, onClick: o, onChoice: s, choices: c = [], selected: l, large: u = !1 }) {
	let d = D[t], f = e.zones.find((e) => e.id === t), p = Tt(d), ee = e.players.flatMap((e) => e.vessels.filter((e) => e === t).map((t, n) => ({
		rid: e.rid,
		i: n
	}))), te = c.filter((e) => e.zone === t), ne = (e) => e.length && s ? s(e) : o?.(), re = te.filter((e) => [
		"sail",
		"launch",
		"robotPlace",
		"robotMove"
	].includes(e.kind));
	return /* @__PURE__ */ _("div", {
		className: "eds-ocean-tile eds-depth-" + d.depth + (a ? " eds-legal" : "") + (u ? " eds-ocean-large" : "") + (l?.zone === t ? " eds-selected" : ""),
		children: [
			/* @__PURE__ */ g(Ct, { ocean: d }),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "eds-tile-open",
				onClick: () => ne(re),
				"aria-label": J(t, n) + (re.length ? " · " + n(K.selectSite) : "")
			}),
			/* @__PURE__ */ _("div", {
				className: "eds-ocean-heading",
				children: [/* @__PURE__ */ g("strong", { children: J(t, n) }), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Z, {
					kind: "sail",
					size: 17
				}), d.depth] })]
			}),
			/* @__PURE__ */ _("div", {
				className: "eds-ocean-arrival",
				children: [/* @__PURE__ */ _("span", {
					title: n(K.arrival),
					children: [/* @__PURE__ */ g(Z, {
						kind: "sail",
						size: 16
					}), /* @__PURE__ */ g(Q, { value: d.arrival })]
				}), /* @__PURE__ */ _("span", {
					title: n(K.discovery),
					children: [/* @__PURE__ */ g(Z, {
						kind: "h",
						size: 16
					}), /* @__PURE__ */ g(Q, { value: d.discovery })]
				})]
			}),
			/* @__PURE__ */ _("div", {
				className: "eds-vessels",
				children: [
					ee.map((e) => /* @__PURE__ */ _("span", {
						title: i(e.rid),
						children: [/* @__PURE__ */ g(xt, {
							color: r(e.rid),
							size: 40
						}), /* @__PURE__ */ g("small", { children: i(e.rid) })]
					}, e.rid + "-" + e.i)),
					e.robot === t && /* @__PURE__ */ g("span", {
						className: "eds-robot",
						title: n(K.sharedRobot),
						children: /* @__PURE__ */ g(Z, { kind: "robotMove" })
					}),
					f?.orca && /* @__PURE__ */ g("span", {
						title: i(f.orca),
						className: "eds-orca",
						children: /* @__PURE__ */ g(Z, { kind: "orca" })
					})
				]
			}),
			/* @__PURE__ */ _("svg", {
				className: "eds-features",
				viewBox: "0 0 420 264",
				"aria-hidden": !0,
				children: [d.links.map((e, t) => /* @__PURE__ */ g("path", {
					d: "M" + p[e.a].join(",") + " L" + p[e.b].join(","),
					stroke: f?.linked.includes(t) ? "#e8c675" : "#b0d8d0",
					strokeWidth: f?.linked.includes(t) ? 2.5 : 1.4
				}, t)), d.sites.filter((e) => e.kind === "sonar").map((e) => {
					let t = d.sites.find((t) => t.track === e.track && t.kind === "sonar" && Number(t.id.split("-")[1]) === Number(e.id.split("-")[1]) + 1);
					return t ? /* @__PURE__ */ g("path", {
						d: "M" + p[e.id].join(",") + " L" + p[t.id].join(","),
						fill: "none",
						stroke: "#b5dcd1",
						strokeWidth: "1.8"
					}, e.id) : null;
				})]
			}),
			d.links.map((e, t) => /* @__PURE__ */ g("span", {
				className: "eds-link-reward" + (f?.linked.includes(t) ? " eds-link-complete" : ""),
				style: {
					left: (p[e.a][0] + p[e.b][0]) / 8.4 + "%",
					top: (p[e.a][1] + p[e.b][1]) / 5.28 + "%"
				},
				title: n(K.links),
				children: /* @__PURE__ */ g(Q, { value: e.reward })
			}, t)),
			d.sites.map((e) => {
				let [a, o] = p[e.id], s = f?.slots[e.id], c = te.filter((t) => t.value === e.id), u = l?.zone === t && l?.value === e.id;
				return /* @__PURE__ */ _("button", {
					type: "button",
					className: "eds-site" + (e.marked ? " eds-marked" : "") + (c.length ? " eds-site-legal" : "") + (u ? " eds-site-selected" : "") + (s ? " eds-site-owned" : ""),
					style: {
						left: a / 4.2 + "%",
						top: o / 2.64 + "%"
					},
					onClick: () => ne(c),
					"aria-pressed": u,
					"aria-label": J(t, n) + " · " + (e.kind === "sonar" ? n(K.sonarPosition, {
						track: e.track + 1,
						n: Number(e.id.split("-")[1]) + 1
					}) : n(e.kind === "conserve" ? K.conserveSite : K.journalSite) + " · " + n(K.siteNumber, { n: Number(e.id.slice(1)) + 1 })) + " " + (e.kind === "conserve" ? n(K.cost, { n: e.cost }) : q(e.reward, n)) + (e.field ? " · " + n(K["field_" + e.field]) : "") + (s ? " · " + i(s) : ""),
					children: [
						e.kind === "conserve" && /* @__PURE__ */ _("span", {
							className: "eds-cost",
							children: [/* @__PURE__ */ g(Z, {
								kind: "r",
								size: 14
							}), e.cost]
						}),
						/* @__PURE__ */ g("span", {
							className: "eds-site-face",
							children: s ? /* @__PURE__ */ g(bt, {
								name: i(s),
								color: r(s)
							}) : e.field ? /* @__PURE__ */ _("span", {
								className: "eds-field-book",
								style: { background: ut[e.field] },
								children: [/* @__PURE__ */ g("span", { children: dt[e.field] }), /* @__PURE__ */ g(Z, {
									kind: "journal",
									size: 21
								})]
							}) : e.kind === "conserve" ? /* @__PURE__ */ g(Z, {
								kind: "conserve",
								size: 29
							}) : /* @__PURE__ */ g(Q, { value: e.reward })
						}),
						e.kind === "conserve" && e.reward && /* @__PURE__ */ g("span", {
							className: "eds-site-reward",
							children: /* @__PURE__ */ g(Q, { value: e.reward })
						}),
						u && /* @__PURE__ */ g("span", {
							className: "eds-target-check",
							children: "✓"
						})
					]
				}, e.id);
			}),
			d.dives.map((e, r) => {
				let i = te.filter((e) => e.kind === "dive" && e.n === r), a = f?.dives[r] ?? e;
				return /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => ne(i),
					className: "eds-dive-site" + (i.length ? " eds-site-legal" : "") + (l?.kind === "dive" && l.zone === t && l.n === r ? " eds-site-selected" : ""),
					style: {
						left: (d.dives.length === 1 ? 366 : 80 + r * (260 / Math.max(1, d.dives.length - 1))) / 4.2 + "%",
						top: (d.dives.length > 1 ? 220 : d.sites.some((e) => e.kind === "conserve") ? 100 : 216) / 2.64 + "%"
					},
					"aria-label": J(t, n) + " · " + n(K.diveSite) + " " + (r + 1) + " · " + a,
					children: [/* @__PURE__ */ g(Z, { kind: "dive" }), /* @__PURE__ */ g("b", { children: a })]
				}, r);
			})
		]
	});
}
function Dt({ v: e, t, color: n, name: r, choices: i, onHex: a }) {
	let o = j[e.config.scenario].hexes, s = Math.min(...o.map((e) => e.x)), c = Math.min(...o.map((e) => e.y)), l = Math.max(...o.map((e) => e.x)), u = Math.max(...o.map((e) => e.y));
	return /* @__PURE__ */ g("div", {
		className: "eds-impact-scroll",
		children: /* @__PURE__ */ _("div", {
			className: "eds-impact-grid",
			style: {
				width: (l - s + 1.4) * 62,
				height: (u - c + 1.5) * 62
			},
			children: [o.map((o) => {
				let l = e.impact[o.id] ?? [], u = i.some((e) => e.hex === o.id), d = [
					t(K.hex, { n: Number(o.id) + 1 }),
					q(o.reward, t),
					o.field ? t(K["field_" + o.field]) : "",
					o.points ? t(K.points, { n: o.points }) : "",
					...l.map(r)
				].filter(Boolean).join(" · ");
				return /* @__PURE__ */ _("button", {
					className: `eds-hex${u ? " eds-hex-legal" : ""}${o.rescue ? " eds-rescue" : ""}`,
					style: {
						left: (o.x - s) * 62,
						top: (o.y - c) * 62,
						background: o.field ? ut[o.field] : o.points === 3 ? "#805e79" : o.points === 2 ? "#527f85" : o.points === 1 ? "#b29342" : "#28576a"
					},
					onClick: () => a(o.id),
					"aria-label": d,
					title: d,
					children: [
						/* @__PURE__ */ g("span", {
							className: "eds-hex-reward",
							children: o.field ? dt[o.field] : o.infinite ? "∞" : ft(o.reward)
						}),
						/* @__PURE__ */ _("span", {
							className: "eds-hex-points",
							children: [o.entry ? "➜ " : "", o.points ? `${o.points}★` : ""]
						}),
						l.length > 0 && /* @__PURE__ */ g("span", {
							className: "eds-hex-owners",
							children: [...new Set(l)].map((e) => /* @__PURE__ */ _("span", {
								title: r(e),
								style: { background: n(e) },
								children: [r(e).slice(0, 1), l.filter((t) => t === e).length > 1 ? l.filter((t) => t === e).length : ""]
							}, e))
						})
					]
				}, o.id);
			}), e.config.scenario === 4 && /* @__PURE__ */ _("button", {
				className: "eds-conserve-impact",
				onClick: () => a("conserve"),
				children: ["🐢 ★3 ", /* @__PURE__ */ g("span", { children: (e.impact.conserve ?? []).length })]
			})]
		})
	});
}
//#endregion
//#region src/games/endeavordeepsea/ui.tsx
function Ot({ variants: e }) {
	return /* @__PURE__ */ g("span", {
		className: "eds-action-variants",
		children: e.map((e, t) => /* @__PURE__ */ _("span", { children: [t > 0 && /* @__PURE__ */ g("i", { children: "/" }), e.map((e, t) => /* @__PURE__ */ _("span", { children: [t > 0 && /* @__PURE__ */ g("i", { children: "+" }), /* @__PURE__ */ g(Z, { kind: e })] }, t))] }, t))
	});
}
function kt({ e, t, ready: n, onClick: r, owner: i, color: a, selected: o = !1 }) {
	let s = y[e.id], c = Re(e);
	return /* @__PURE__ */ _("button", {
		type: "button",
		className: "eds-expert" + (e.senior ? " eds-senior" : "") + (n ? " eds-legal" : "") + (e.occupied ? " eds-occupied" : "") + (o ? " eds-selected" : ""),
		onClick: r,
		"aria-pressed": o,
		"aria-label": Y(e.id, e.senior, t) + " · " + t(e.occupied ? K.occupied : n ? K.available : e.senior ? K.senior : K.junior),
		children: [
			/* @__PURE__ */ _("span", {
				className: "eds-expert-title",
				children: [/* @__PURE__ */ g("strong", { children: Y(e.id, e.senior, t) }), /* @__PURE__ */ g("small", {
					title: t(e.senior ? K.senior : K.tier, { n: s.tier }),
					children: e.senior ? "★" : s.tier
				})]
			}),
			/* @__PURE__ */ _("span", {
				className: "eds-portrait",
				children: [
					/* @__PURE__ */ g(wt, { id: e.id }),
					/* @__PURE__ */ g("span", {
						className: "eds-activation",
						children: e.occupied ? /* @__PURE__ */ g(bt, {
							name: i ?? t(K.occupied),
							color: a ?? "#d98041"
						}) : /* @__PURE__ */ g(Z, { kind: "d" })
					}),
					e.badge !== null && /* @__PURE__ */ g("span", {
						title: t(e.red ? K.redBadge : K.blueBadge),
						className: e.red ? "eds-red-badge" : "eds-blue-badge",
						children: /* @__PURE__ */ g(Z, { kind: ye[e.badge] })
					})
				]
			}),
			/* @__PURE__ */ _("span", {
				className: "eds-expert-actions",
				children: [/* @__PURE__ */ g(Q, { value: e.senior ? s.senior : s.junior }), /* @__PURE__ */ g(Ot, { variants: c })]
			}),
			/* @__PURE__ */ _("span", {
				className: "eds-promotion",
				children: [/* @__PURE__ */ g("span", { children: t(e.senior ? K.senior : K.action_promote) }), s.tier === 5 ? /* @__PURE__ */ g("small", { children: t(K["expertScore_" + e.id]) }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Q, { value: s.senior }), !e.senior && /* @__PURE__ */ g(Ot, { variants: s.seniorActions })] })]
			})
		]
	});
}
function At({ j: e, used: t = [], t: n, onClick: r, ready: i, owner: a, color: o }) {
	return /* @__PURE__ */ _("button", {
		type: "button",
		className: "eds-journal" + (i ? " eds-legal" : ""),
		onClick: r,
		children: [
			/* @__PURE__ */ _("span", {
				className: "eds-card-meta",
				children: [/* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Z, { kind: "r" }), /* @__PURE__ */ g("b", { children: e.cost })] }), /* @__PURE__ */ g("span", { children: e.points ? n(K.points, { n: e.points }) : "" })]
			}),
			/* @__PURE__ */ g("strong", { children: n(K["journal_" + e.id]) }),
			/* @__PURE__ */ _("span", {
				className: "eds-journal-bonus",
				children: [/* @__PURE__ */ g("span", { children: /* @__PURE__ */ g(Q, { value: e.you }) }), e.others && /* @__PURE__ */ _("span", {
					className: "eds-other-reward",
					children: [
						n(K.others),
						" ",
						/* @__PURE__ */ g(Q, { value: e.others })
					]
				})]
			}),
			/* @__PURE__ */ _("span", {
				className: "eds-journal-foot",
				children: [e.anchor && /* @__PURE__ */ g(Z, { kind: "dive" }), e.actions.map((e, r) => /* @__PURE__ */ g("span", {
					className: t.includes(r) ? "eds-used-circle" : "eds-action-circle",
					title: n(t.includes(r) ? K.journalActionUsed : K.journalActionAvailable),
					children: t.includes(r) ? /* @__PURE__ */ g(bt, {
						name: a ?? n(K.you),
						color: o ?? "#d98041"
					}) : e.startsWith("x") ? /* @__PURE__ */ g(Q, { value: e }) : /* @__PURE__ */ g(Z, { kind: e })
				}, r))]
			}),
			/* @__PURE__ */ g("span", {
				className: "eds-fields",
				children: e.fields.map((e) => /* @__PURE__ */ g("span", {
					title: n(K["field_" + e]),
					style: { background: ut[e] },
					children: dt[e]
				}, e))
			})
		]
	});
}
var jt = [
	[0, 1],
	[2, 3],
	[4, 6],
	[7, 9],
	[10, 12]
], Mt = [
	"R",
	"I",
	"C",
	"G"
], Nt = {
	R: "#79512c",
	I: "#4d6736",
	C: "#7b6b2f",
	G: "#2f6382"
}, Pt = {
	R: "people",
	I: "d",
	C: "retrieve",
	G: "sail"
};
function Ft({ p: e, t, color: n = "#d98041", onAttribute: r }) {
	let i = l((e) => e.locale);
	return /* @__PURE__ */ _("div", {
		className: "eds-tracks",
		lang: i,
		style: { "--eds-player": n },
		children: [
			/* @__PURE__ */ _("div", {
				className: "eds-track-scores",
				children: [/* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(Z, {
					kind: "h",
					size: 11
				}), t(K.trackScore)] }), /* @__PURE__ */ g("div", {
					className: "eds-track-bands",
					children: jt.map(([e, t]) => /* @__PURE__ */ _("span", {
						style: { gridColumn: "span " + (t - e + 1) },
						children: [/* @__PURE__ */ g(Z, {
							kind: "h",
							size: 9
						}), w(e)]
					}, e))
				})]
			}),
			Mt.map((n) => /* @__PURE__ */ _("div", {
				className: "eds-track",
				style: {
					"--eds-track-color": vt[n],
					"--eds-track-shade": Nt[n]
				},
				children: [/* @__PURE__ */ _("button", {
					type: "button",
					className: "eds-track-label",
					onClick: () => r?.(n),
					title: t(K["ability_" + n], { n: C(e.attributes[n]) }),
					children: [/* @__PURE__ */ g(yt, { kind: n }), /* @__PURE__ */ g("span", { children: t(K["attribute_" + n]) })]
				}), /* @__PURE__ */ g("div", {
					className: "eds-track-bands",
					"aria-label": t(K["attribute_" + n]) + ": " + e.attributes[n] + " · " + t(K["ability_" + n], { n: C(e.attributes[n]) }),
					children: jt.map(([r, i], a) => /* @__PURE__ */ _("div", {
						className: "eds-track-band" + (e.attributes[n] >= r && e.attributes[n] <= i ? " eds-current-band" : ""),
						style: { gridColumn: "span " + (i - r + 1) },
						title: t(K["ability_" + n], { n: a + 1 }),
						children: [/* @__PURE__ */ g("div", {
							className: "eds-track-values",
							children: Array.from({ length: i - r + 1 }, (e, t) => r + t).map((r) => /* @__PURE__ */ _("span", { children: [e.attributes[n] === r ? /* @__PURE__ */ g("b", {
								className: "eds-track-cube",
								children: /* @__PURE__ */ g(se, { value: e.attributes[n] })
							}) : r, n === "G" && (r === 2 || r === 7) && /* @__PURE__ */ g("span", {
								className: "eds-sub-unlock",
								title: t(K.subUnlock),
								children: /* @__PURE__ */ g(xt, { size: 12 })
							})] }, r))
						}), /* @__PURE__ */ _("div", {
							className: "eds-track-ability",
							children: [
								/* @__PURE__ */ g(Z, {
									kind: Pt[n],
									size: 12
								}),
								/* @__PURE__ */ g("b", { children: a + 1 }),
								a === 4 && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Z, {
									kind: "h",
									size: 10
								}), /* @__PURE__ */ g("span", {
									className: "eds-overflow-arrow",
									children: "↻"
								})] })
							]
						})]
					}, r))
				})]
			}, n)),
			/* @__PURE__ */ _("div", {
				className: "eds-research-track",
				children: [/* @__PURE__ */ _("span", {
					className: "eds-track-label",
					children: [/* @__PURE__ */ g(Z, { kind: "r" }), /* @__PURE__ */ g("span", { children: t(K.research) })]
				}), /* @__PURE__ */ g("div", { children: Array.from({ length: 13 }, (t, n) => /* @__PURE__ */ g("span", { children: e.research === n ? /* @__PURE__ */ g("b", {
					className: "eds-track-cube",
					children: /* @__PURE__ */ g(se, { value: e.research })
				}) : n }, n)) })]
			})
		]
	});
}
//#endregion
//#region src/games/endeavordeepsea/view-player.tsx
function It({ public: e, private: t, members: r, myRid: i, send: l }) {
	ce();
	let d = u(), f = e, ee = t, ue = f.phase === "over" ? [] : ee?.choices ?? [], de = j[f.config.scenario], [fe, pe] = o("ocean"), [me, he] = o(i), [v, ge] = o(null), [y, _e] = o(1), [b, ve] = o(null), [ye, C] = o(null), w = f.players.find((e) => e.rid === i) ?? f.players[0], T = f.players.find((e) => e.rid === me) ?? w, E = (e) => r.find((t) => t.rid === e)?.name ?? e.slice(0, 5), O = (e) => oe[r.find((t) => t.rid === e)?.colorIndex ?? 0]?.hex ?? $e.accent, k = ue.find((e) => e.id === b), A = w.experts.find((e) => e.uid === (k?.expert ?? ye)), be = (e) => {
		l({
			type: "choose",
			id: e.id
		}), ge(null), ve(null);
	}, M = (e) => {
		ve(e.id), ge(null), e.expert !== void 0 && C(e.expert);
	}, N = ue.filter((e) => !e.kind.startsWith("token")), P = ue.filter((e) => e.kind.startsWith("token")), F = f.effect ? d(K["prompt_" + f.effect.kind] ?? K.resolving) : f.mainDone ? d(K.afterMain) : d(K.main), xe = N.filter((e) => [
		"accept",
		"skip",
		"end",
		"pass",
		"fullOcean"
	].includes(e.kind)), Se = N.filter((e) => !xe.includes(e)), I = N;
	v?.kind === "zone" && (I = N.filter((e) => e.zone === v.id)), v?.kind === "expert" && (I = T.rid === i ? N.filter((e) => e.expert === Number(v.id)) : []), v?.kind === "hex" && (I = N.filter((e) => e.hex === v.id)), v?.kind === "token" && (I = P.filter((e) => e.n === Number(v.id))), v?.kind === "journal" && (I = N.filter((e) => e.card === Number(v.id) && ["journal", "journalAction"].includes(e.kind))), v?.kind === "attribute" && (I = N.filter((e) => e.kind === "attribute" && e.value === v.id));
	let L = (e, t) => ge({
		kind: e,
		id: t
	}), Ce = (e) => {
		e.length === 1 ? M(e[0]) : e[0]?.zone ? L("zone", e[0].zone) : L("all");
	}, we = (e) => {
		let t = N.filter((t) => t.hex === e);
		t.length === 1 ? M(t[0]) : L("hex", e);
	}, R = (e) => {
		let t = T.rid === i ? N.filter((t) => t.expert === e) : [];
		t.length === 1 ? M(t[0]) : L("expert", String(e)), T.rid === i && C(e);
	}, Te = v?.kind === "zone" ? J(v.id, d) : v?.kind === "attribute" ? d(K["attribute_" + v.id]) : v?.kind === "scenario" ? d(K["scenario_" + f.config.scenario]) : v?.kind === "market" ? d(K.market) : v?.kind === "log" ? d(K.log) : d(K.choose), z = a(null), B = a(null), V = a(!1), H = a({
		tileWidth: 355,
		zoom: 1
	}), [U, Ee] = o(355);
	n(() => {
		let e = B.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => {
			let t = e.contentRect.width;
			t > 0 && Ee(t < 480 ? Math.max(292, t - 45) : Math.max(320, (t - 66) / 3));
		});
		return t.observe(e), () => t.disconnect();
	}, []);
	let De = () => {
		let e = z.current;
		e && (e.scrollLeft = Math.max(0, Math.min(...f.zones.map((e) => e.x)) * (U * y + 14)), e.scrollTop = 0);
	};
	n(() => {
		z.current && !V.current && (z.current.scrollLeft = Math.max(0, Math.min(...f.zones.map((e) => e.x)) * (U + 14) - 4), V.current = !0);
	}, [f.zones, U]), n(() => {
		let e = z.current, t = H.current;
		e && V.current && (t.tileWidth !== U || t.zoom !== y) && (e.scrollLeft = e.scrollLeft / (t.tileWidth * t.zoom + 14) * (U * y + 14)), H.current = {
			tileWidth: U,
			zoom: y
		};
	}, [U, y]);
	let Oe = /* @__PURE__ */ g("div", {
		ref: z,
		className: "eds-ocean-scroll",
		children: /* @__PURE__ */ _("div", {
			className: "eds-ocean-grid",
			style: {
				gridTemplateColumns: "28px repeat(" + de.columns + ", " + U * y + "px)",
				gridTemplateRows: "24px repeat(" + de.maxDepth + "," + U * y * 264 / 420 + "px)"
			},
			children: [
				/* @__PURE__ */ g("span", {}),
				Array.from({ length: de.columns }, (e, t) => /* @__PURE__ */ g("div", {
					className: "eds-column-label",
					children: String.fromCharCode(65 + t)
				}, "c" + t)),
				Array.from({ length: de.maxDepth }, (e, t) => /* @__PURE__ */ _("div", {
					className: "eds-depth-row",
					children: [/* @__PURE__ */ g("span", {
						className: "eds-depth-label eds-depth-label-" + (t + 1),
						children: /* @__PURE__ */ g("b", { children: t + 1 })
					}), Array.from({ length: de.columns }, (e, n) => {
						let r = f.zones.find((e) => e.x === n && e.depth === t + 1);
						return r ? /* @__PURE__ */ g(Et, {
							v: f,
							id: r.id,
							t: d,
							color: O,
							name: E,
							choices: N,
							selected: k,
							onChoice: Ce,
							legal: N.some((e) => e.zone === r.id),
							onClick: () => L("zone", r.id)
						}, n) : /* @__PURE__ */ g("button", {
							type: "button",
							className: "eds-unknown",
							onClick: () => L("all"),
							"aria-label": d(K.column, {
								col: String.fromCharCode(65 + n),
								n: t + 1
							}) + " · " + d(K.emptyOcean),
							children: /* @__PURE__ */ g("span", { children: "＋" })
						}, n);
					})]
				}, t))
			]
		})
	}), ke = /* @__PURE__ */ _("div", {
		className: "eds-personal",
		children: [
			/* @__PURE__ */ _("div", {
				className: "eds-personal-heading",
				children: [
					/* @__PURE__ */ g(re, { size: 23 }),
					/* @__PURE__ */ g("strong", { children: d(K.expedition, { name: E(T.rid) }) }),
					/* @__PURE__ */ _("button", {
						type: "button",
						className: "eds-inline-link",
						onClick: () => L("scenario"),
						children: [d(K.showGoals), " ›"]
					})
				]
			}),
			/* @__PURE__ */ g(Ft, {
				p: T,
				t: d,
				color: O(T.rid),
				onAttribute: (e) => L("attribute", e)
			}, T.rid),
			/* @__PURE__ */ _("div", {
				className: "eds-section-label",
				children: [/* @__PURE__ */ g("b", { children: d(K.team) }), /* @__PURE__ */ _("span", { children: [
					/* @__PURE__ */ g(bt, {
						name: E(T.rid),
						color: O(T.rid)
					}),
					/* @__PURE__ */ g(se, { value: T.discs }),
					T.orcas > 0 && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Z, { kind: "orca" }), T.orcas] }),
					f.config.scenario === 9 && /* @__PURE__ */ g("small", { children: d(K.cleanup, { n: T.cleanup }) })
				] })]
			}),
			/* @__PURE__ */ g("div", {
				className: "eds-expert-grid",
				children: T.experts.map((e) => /* @__PURE__ */ g(kt, {
					e,
					t: d,
					owner: E(T.rid),
					color: O(T.rid),
					selected: T.rid === i && k?.expert === e.uid,
					ready: T.rid === i && N.some((t) => t.expert === e.uid),
					onClick: () => R(e.uid)
				}, e.uid))
			}),
			T.journals.length > 0 && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("div", {
				className: "eds-section-label",
				children: /* @__PURE__ */ g("b", { children: d(K.published) })
			}), /* @__PURE__ */ g("div", {
				className: "eds-journal-grid",
				children: T.journals.map((e) => /* @__PURE__ */ g(At, {
					j: x[e.id],
					used: e.used,
					t: d,
					owner: E(T.rid),
					color: O(T.rid),
					ready: T.rid === i && N.some((t) => t.card === e.id),
					onClick: () => L("journal", String(e.id))
				}, e.id))
			})] })
		]
	}), Ae = /* @__PURE__ */ _("div", {
		className: "eds-impact-panel",
		children: [/* @__PURE__ */ g(Dt, {
			v: f,
			t: d,
			color: O,
			name: E,
			choices: N,
			onHex: we
		}), /* @__PURE__ */ _("div", {
			className: "eds-goals",
			children: [[
				0,
				1,
				2
			].map((e) => /* @__PURE__ */ _("p", { children: [
				/* @__PURE__ */ g("b", { children: d(K["scoreGoal" + (e + 1)]) }),
				d(K["goal_" + f.config.scenario + "_" + e]),
				f.config.scenario === 8 && /* @__PURE__ */ g("small", { children: f.players[0].goals[e] === null ? d(K.goalUndecided) : ht(f.config.scenario, e, f.players[0].goals[e], d) })
			] }, e)), /* @__PURE__ */ _("p", { children: [/* @__PURE__ */ g("b", { children: d(K.scenarioRules) }), d(K["scenarioRule_" + f.config.scenario])] })]
		})]
	}), je = I.filter((e) => e.kind === "recruit" || e.kind === "refillExpert"), W = k ?? xe.find((e) => e.kind === "accept") ?? xe.find((e) => e.kind === "end") ?? xe.find((e) => e.kind === "fullOcean"), Me = k ? pt(k, f, d) : f.acting === i ? F : d(K.noChoices), Ne = f.effect?.kind ?? "sail";
	return /* @__PURE__ */ _(le, {
		adaptive: !0,
		className: "eds-screen",
		scroll: !1,
		actionsHeight: "eds-actions-height",
		banner: /* @__PURE__ */ _("div", {
			className: "eds-banner",
			children: [/* @__PURE__ */ _("div", {
				className: "eds-phase",
				children: [
					/* @__PURE__ */ _("span", {
						className: "eds-round",
						children: [/* @__PURE__ */ _("b", { children: [f.round, "/6"] }), /* @__PURE__ */ g("small", { children: d(K.round, { n: f.round }) })]
					}),
					/* @__PURE__ */ g(Z, { kind: Ne }),
					/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("strong", { children: f.acting === i ? F : d(K.waiting, { name: E(f.acting ?? f.active) }) }), /* @__PURE__ */ g("small", { children: d(K["scenario_" + f.config.scenario]) })] })
				]
			}), /* @__PURE__ */ g("div", {
				className: "eds-players",
				children: r.map((e) => {
					let t = f.players.find((t) => t.rid === e.rid);
					return /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => {
							he(e.rid), pe("team");
						},
						"aria-label": d(K.expedition, { name: e.name }),
						className: e.rid === f.acting ? "eds-acting" : "",
						"aria-pressed": e.rid === T.rid,
						children: [
							/* @__PURE__ */ g(bt, {
								name: e.name,
								color: O(e.rid)
							}),
							/* @__PURE__ */ _("span", { children: [e.name, t?.passed && /* @__PURE__ */ g("small", { children: d(K.passed) })] }),
							e.rid === f.start && /* @__PURE__ */ g("span", {
								className: "eds-start-marker",
								title: d(K.startPlayer),
								children: "◆"
							})
						]
					}, e.rid);
				})
			})]
		}),
		actions: /* @__PURE__ */ _("div", {
			className: "eds-actions",
			children: [
				/* @__PURE__ */ g("div", {
					className: "eds-action-source",
					children: A && f.acting === i ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
						className: "eds-source-portrait" + (A.senior ? " eds-source-gold" : ""),
						children: /* @__PURE__ */ g(wt, { id: A.id })
					}), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g("b", { children: Y(A.id, A.senior, d) }), /* @__PURE__ */ g("small", { children: f.effect?.zone ? J(f.effect.zone, d) : d(K.team) })] })] }) : /* @__PURE__ */ _("span", {
						className: "eds-source-idle",
						children: [/* @__PURE__ */ g(Z, { kind: Ne }), /* @__PURE__ */ g("b", { children: f.acting === i ? F : d(K.waiting, { name: E(f.acting ?? f.active) }) })]
					})
				}),
				/* @__PURE__ */ _("div", {
					className: "eds-token-row",
					children: [
						/* @__PURE__ */ _("span", {
							className: "eds-wallet",
							title: d(K.disc),
							children: [/* @__PURE__ */ g(bt, {
								name: E(i),
								color: O(i)
							}), /* @__PURE__ */ g(se, { value: w.discs })]
						}),
						/* @__PURE__ */ _("span", {
							className: "eds-wallet",
							title: d(K.research),
							children: [/* @__PURE__ */ g(Z, { kind: "r" }), /* @__PURE__ */ g(se, { value: w.research })]
						}),
						w.tokens.map((e, t) => /* @__PURE__ */ _("button", {
							type: "button",
							className: "eds-token",
							onClick: () => L("token", String(t)),
							disabled: !P.some((e) => e.n === t),
							"aria-label": d(K.tokens) + " " + (t + 1) + " · " + d(K.tokenValue, { n: S[e].research }),
							children: [
								/* @__PURE__ */ g(Z, { kind: "dive" }),
								/* @__PURE__ */ g("b", { children: S[e].research }),
								/* @__PURE__ */ g(Q, { value: S[e].effect })
							]
						}, t))
					]
				}),
				/* @__PURE__ */ _("div", {
					className: "eds-action-decision",
					children: [/* @__PURE__ */ g("div", {
						className: "eds-current-decision",
						"aria-live": "polite",
						title: Me,
						children: Me
					}), /* @__PURE__ */ _("div", {
						className: "eds-action-row",
						children: [
							k ? /* @__PURE__ */ g("button", {
								type: "button",
								className: "eds-icon-button",
								onClick: () => ve(null),
								"aria-label": d(K.cancelSelection),
								children: /* @__PURE__ */ g(p, { size: 20 })
							}) : /* @__PURE__ */ g("button", {
								type: "button",
								className: "eds-quiet eds-all-actions",
								onClick: () => L("all"),
								children: d(K.actions)
							}),
							W ? /* @__PURE__ */ _("button", {
								type: "button",
								className: "eds-primary",
								onClick: () => be(W),
								children: [
									/* @__PURE__ */ g(Z, { kind: W.kind === "accept" ? "h" : W.kind === "activate" ? W.value?.split(",")[0] ?? "d" : W.kind }),
									/* @__PURE__ */ g("span", { children: k ? d(K.confirmAction) : X(W.kind, d) }),
									W.kind === "accept" && /* @__PURE__ */ g(Q, { value: W.value ?? "" })
								]
							}) : Se.length > 0 ? /* @__PURE__ */ _("button", {
								type: "button",
								className: "eds-primary",
								onClick: () => L("all"),
								children: [/* @__PURE__ */ g(Z, { kind: f.effect?.kind ?? "sonar" }), d(f.effect?.kind === "recruit" ? K.action_recruit : K.choose)]
							}) : /* @__PURE__ */ g("span", {
								className: "eds-waiting",
								children: d(K.noChoices)
							}),
							!k && xe.filter((e) => !W || e.id !== W.id).slice(0, 1).map((e) => /* @__PURE__ */ g("button", {
								type: "button",
								className: "eds-quiet eds-pass",
								onClick: () => be(e),
								children: X(e.kind, d)
							}, e.id))
						]
					})]
				})
			]
		}),
		children: [
			/* @__PURE__ */ _("div", {
				className: "eds-tabs",
				children: [/* @__PURE__ */ g("div", {
					className: "eds-view-tabs",
					children: [
						"ocean",
						"team",
						"impact"
					].map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						"aria-pressed": fe === e,
						onClick: () => pe(e),
						children: [/* @__PURE__ */ g(Z, {
							kind: e === "team" ? "people" : e === "impact" ? "hex" : "sail",
							size: 21
						}), d(K[e])]
					}, e))
				}), /* @__PURE__ */ _("div", {
					className: "eds-map-tools",
					children: [
						/* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => L("market"),
							title: d(K.market),
							"aria-label": d(K.market),
							children: /* @__PURE__ */ g(Z, {
								kind: "journal",
								size: 20
							})
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => L("scenario"),
							title: d(K.showGoals),
							"aria-label": d(K.showGoals),
							children: /* @__PURE__ */ g(te, { size: 19 })
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => L("log"),
							title: d(K.log),
							"aria-label": d(K.log),
							children: /* @__PURE__ */ g(ne, { size: 19 })
						})
					]
				})]
			}),
			/* @__PURE__ */ _("div", {
				className: "eds-main",
				"data-tab": fe,
				children: [
					/* @__PURE__ */ _("section", {
						ref: B,
						className: "eds-board-section",
						children: [Oe, /* @__PURE__ */ _("div", {
							className: "eds-zoom-controls",
							children: [
								/* @__PURE__ */ g("button", {
									type: "button",
									"aria-label": d(K.zoomOut),
									onClick: () => _e((e) => Math.max(.6, Math.round((e - .1) * 10) / 10)),
									children: /* @__PURE__ */ g(m, { size: 21 })
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									"aria-label": d(K.oceanOverview),
									onClick: De,
									children: /* @__PURE__ */ g(ie, { size: 21 })
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									"aria-label": d(K.zoomIn),
									onClick: () => _e((e) => Math.min(1.5, Math.round((e + .1) * 10) / 10)),
									children: /* @__PURE__ */ g(ae, { size: 21 })
								})
							]
						})]
					}),
					/* @__PURE__ */ g("section", {
						className: "eds-team-section",
						children: ke
					}),
					/* @__PURE__ */ g("section", {
						className: "eds-impact-section",
						children: Ae
					})
				]
			}),
			s(/* @__PURE__ */ g("div", {
				className: "eds-dialog",
				children: /* @__PURE__ */ g(c, {
					open: v !== null,
					onClose: () => ge(null),
					label: Te,
					title: Te,
					tall: !0,
					children: /* @__PURE__ */ _("div", {
						className: "eds-sheet",
						children: [
							v?.kind === "zone" && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Et, {
								large: !0,
								v: f,
								id: v.id,
								t: d,
								color: O,
								name: E,
								choices: N,
								selected: k,
								onChoice: Ce
							}), D[v.id].special && /* @__PURE__ */ g("p", {
								className: "eds-rule-note",
								children: d(K["special_" + D[v.id].special])
							})] }),
							v?.kind === "expert" && T.experts.find((e) => e.uid === Number(v.id)) && /* @__PURE__ */ g("div", {
								className: "eds-expert-detail",
								children: /* @__PURE__ */ g(kt, {
									t: d,
									e: T.experts.find((e) => e.uid === Number(v.id)),
									owner: E(T.rid),
									color: O(T.rid)
								})
							}),
							v?.kind === "journal" && /* @__PURE__ */ g(At, {
								j: x[Number(v.id)],
								t: d,
								used: T.journals.find((e) => e.id === Number(v.id))?.used
							}),
							v?.kind === "attribute" && /* @__PURE__ */ g("dl", {
								className: "eds-ability-list",
								children: [
									[0, 1],
									[2, 3],
									[4, 6],
									[7, 9],
									[10, 12]
								].map(([e, t], n) => /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ _("dt", { children: [/* @__PURE__ */ g("b", { children: d(K.abilityLevel, { n: n + 1 }) }), /* @__PURE__ */ g("small", { children: d(K.attributeRange, {
									lo: e,
									hi: t
								}) })] }), /* @__PURE__ */ g("dd", { children: d(K["ability_" + v.id], { n: n + 1 }) })] }, n))
							}),
							v?.kind === "scenario" ? Ae : v?.kind === "log" ? /* @__PURE__ */ g("div", {
								className: "eds-recent-log",
								children: f.log.slice().reverse().map((e, t) => /* @__PURE__ */ _("p", { children: [/* @__PURE__ */ g(bt, {
									name: E(e.owner),
									color: O(e.owner)
								}), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g("b", { children: E(e.owner) }), /* @__PURE__ */ g("span", { children: mt(e, d) })] })] }, t))
							}) : v?.kind === "market" ? /* @__PURE__ */ _(h, { children: [
								/* @__PURE__ */ g("div", {
									className: "eds-journal-grid",
									children: f.market.map((e) => /* @__PURE__ */ g(At, {
										j: x[e],
										t: d,
										onClick: () => L("journal", String(e))
									}, e))
								}),
								/* @__PURE__ */ g("div", {
									className: "eds-section-label",
									children: /* @__PURE__ */ g("b", { children: d(K.supply) })
								}),
								/* @__PURE__ */ g("div", {
									className: "eds-expert-grid",
									children: [...Object.entries(f.experts).filter(([, e]) => e > 0).map(([e]) => Number(e)), ...f.tier5].map((e) => /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g(kt, {
										e: {
											uid: e,
											id: e,
											senior: !1,
											occupied: !1,
											badge: null,
											red: !1
										},
										t: d,
										ready: N.some((t) => t.kind === "recruit" && t.expert === e),
										onClick: () => {
											let t = N.filter((t) => t.kind === "recruit" && t.expert === e);
											t.length === 1 && M(t[0]);
										}
									}), /* @__PURE__ */ g("small", { children: d(K.left, { n: f.experts[e] ?? 1 }) })] }, e))
								})
							] }) : /* @__PURE__ */ _(h, { children: [
								ee?.discoveries.length ? /* @__PURE__ */ g("div", {
									className: "eds-discoveries",
									children: ee.discoveries.map((e) => /* @__PURE__ */ g(Et, {
										v: f,
										id: e,
										t: d,
										color: O,
										name: E
									}, e))
								}) : null,
								je.length > 0 && /* @__PURE__ */ g("div", {
									className: "eds-expert-grid",
									children: je.map((e) => /* @__PURE__ */ g(kt, {
										e: {
											id: e.expert,
											uid: e.expert,
											senior: !1,
											occupied: !1,
											badge: null,
											red: !1
										},
										t: d,
										ready: !0,
										onClick: () => M(e)
									}, e.id))
								}),
								I.filter((e) => !je.includes(e)).length > 0 && /* @__PURE__ */ g("div", {
									className: "eds-choices",
									children: I.filter((e) => !je.includes(e)).map((e) => /* @__PURE__ */ _("button", {
										type: "button",
										onClick: () => M(e),
										className: "eds-choice",
										children: [/* @__PURE__ */ g(Z, { kind: e.kind === "activate" ? e.value?.split(",")[0] ?? "d" : e.kind }), /* @__PURE__ */ g("span", { children: pt(e, f, d) })]
									}, e.id))
								})
							] })
						]
					})
				})
			}), document.body)
		]
	});
}
//#endregion
//#region src/games/endeavordeepsea/bot-policy.ts
var Lt = (e, t) => {
	let n = e.public, r = e.private?.choices ?? [];
	if (!r.length) return /* @__PURE__ */ new Map();
	let i = n.players.find((e) => e.rid === t.rid), a = n.zones.filter((e) => i.vessels.includes(e.id) || i.vessels.includes("robot") && n.robot === e.id || e.id === "cave" && i.vessels.some((t) => {
		let r = n.zones.find((e) => e.id === t);
		return r.depth === e.depth && Math.abs(r.x - e.x) === 1 || r.depth === e.depth - 1 && r.x === e.x;
	})), o = (e, t = i.discs) => e === "sail" ? n.zones.length > 1 ? 1.8 : .1 : e === "sonar" ? t > 0 && a.some((e) => D[e.id].sites.some((t) => t.kind === "sonar" && !e.slots[t.id])) ? 3.5 : 0 : e === "dive" ? a.some((e) => e.dives.some((e) => e > 0)) ? 2.8 : 0 : e === "conserve" ? (t > 0 || n.config.scenario === 9) && a.some((e) => D[e.id].sites.some((t) => t.kind === "conserve" && !e.slots[t.id] && (t.cost <= i.research || i.orcas > 0 && !e.orca))) ? 4.2 : 0 : e === "journal" ? t > 0 && a.some((e) => D[e.id].sites.some((t) => t.kind === "journal" && !e.slots[t.id] && n.market.some((e) => x[e].cost <= i.research && x[e].fields.includes(t.field)))) ? 4.7 : 0 : e === "promote" ? i.experts.some((e) => !e.senior) ? 3.7 : 0 : e === "copy" ? 3.5 : 1, s = (e) => {
		let r = e.score;
		if (e.kind === "activate" && (r = (e.value ?? "").split(",").reduce((e, t) => e + o(t, i.discs - 1), 0) + .4), e.kind === "order" && (r = o(e.value) + (e.value === "sail" ? -.2 : 0)), e.kind === "recruit") {
			let t = y[e.expert];
			r = t.tier + t.actions.reduce((e, t) => Math.max(e, t.reduce((e, t) => e + o(t, Math.max(1, i.discs)), 0)), 0) * .4;
			for (let e of [
				"R",
				"I",
				"C",
				"G"
			]) {
				let n = Number(RegExp(`${e}(\\d)`).exec(t.junior)?.[1] ?? 0), a = C(i.attributes[e] + n) - C(i.attributes[e]);
				r += n * .6 + a * (e === "I" ? 3 : e === "G" ? 2.4 : 1.7);
			}
			t.junior.includes("h") && (r += 1.4), t.actions.length || (r -= 1.2);
		}
		if (e.kind === "sail") {
			let t = n.zones.find((t) => t.id === e.zone), a = D[t.id];
			r = 1 + a.sites.filter((e) => !t.slots[e.id]).length * .15 + Number(t.dives.some((e) => e)) * 1.2, a.arrival === "d1" && (r += i.discs < 2 ? 1.9 : .7), a.arrival === "I1" && (r += i.attributes.I < 7 ? 1.7 : .6), a.arrival === "G1" && (r += i.attributes.G < 7 ? 1.5 : .6), (a.arrival === "r1" || a.arrival === "r2") && (r += i.research < 3 ? 1.2 : 0), a.arrival === "h1" && (r += 1), t.depth === 5 && i.firstVisit === null && (r += 3), i.vessels.includes(t.id) && (r -= 2);
		}
		if (e.kind === "attribute" && (r += e.value === "I" && i.attributes.I < 7 ? 1 : e.value === "G" && i.attributes.G < 7 ? .8 : 0), e.kind === "tokenResearch" && (r = i.research <= 5 ? 2 : i.tokens.length > 2 ? 1 : -2), e.kind === "tokenEffect") {
			let t = S[e.card].effect;
			r = t.startsWith("p") ? o("promote") : t.startsWith("h") ? 2.8 : t.startsWith("a") || t.startsWith("l") ? 2.7 : t.startsWith("d") ? 3 : o(t), t === "tradeDisc" && (r = i.discs > 3 && i.research < 6 ? 2.8 : -3), t === "conserveCheap" && (r = o("conserve"));
		}
		if (e.kind === "divePick") {
			let t = S[Number(e.value)];
			r = t.research * .2 + (t.effect === "d1" ? 2 : t.effect === "h1" ? 1.6 : t.effect === "a1" || t.effect === "l1" ? 1.7 : 1);
		}
		if (e.kind === "impact" && n.config.scenario === 6) {
			let t = j[6].hexes.find((t) => t.id === e.hex);
			r = t.points * 3 + t.y * .3, [
				"R",
				"I",
				"C",
				"G"
			].some((e) => t.reward.includes(e) && i.attributes[e] >= 9) && (r -= 20);
		}
		e.kind === "end" && (r = -1), e.kind === "pass" && (r = -6), e.kind === "tokenDiscard" && (r = -14), e.kind === "skip" && (r = -15);
		let a = [...`${t.rid}:${n.round}:${n.log.length}:${e.id}`].reduce((e, t) => Math.imul(e, 31) + t.charCodeAt(0), 0) >>> 0;
		return r + a % 97 / 1e3 * (t.difficulty === "weak" ? 8 : 1);
	};
	return new Map(r.map((e) => [e.id, s(e)]));
}, Rt = {
	economy: .7,
	recovery: 1,
	recruitment: 0,
	technology: .8,
	disc: 1.3,
	research: .45,
	token: .7,
	expert: .5,
	ready: .45,
	access: .35,
	discovery: 1,
	future: 1,
	opponent: .15,
	promotion: 1,
	pending: 1.5,
	depth: 1,
	beam: 2,
	guide: 2
}, zt = {
	sail: 1.7,
	sonar: 3.2,
	dive: 2.8,
	conserve: 3.6,
	journal: 4,
	promote: 3.6,
	copy: 4
}, $ = (e) => e.reduce((e, t) => e + t, 0), Bt = (e) => {
	let t = [
		0,
		2,
		4,
		7,
		10,
		13
	], n = C(e) - 1;
	return n + (e - t[n]) / (t[n + 1] - t[n]) * .35;
};
function Vt(e, t) {
	let n = {
		...structuredClone(e),
		seed: 0,
		cursor: 0,
		serial: Math.max(0, ...e.players.flatMap((e) => e.experts.map((e) => e.uid))),
		start: e.players.findIndex((t) => t.rid === e.start),
		active: e.players.findIndex((t) => t.rid === e.active),
		prep: 0,
		tokenTurn: !1,
		players: structuredClone(e.players),
		zones: e.zones.map((e) => ({
			...structuredClone(e),
			dives: e.dives.map((e) => Array(e).fill(0))
		})),
		oceans: e.oceanCounts.map((e) => Array(e).fill("")),
		tokens: Array(e.tokenCount).fill(0),
		discard: [],
		journals: [],
		tier5: e.tier5.map((e) => [e]),
		effects: e.effect ? [{ ...e.effect }] : [],
		deepOrder: e.players.filter((e) => e.firstDeep !== null).sort((e, t) => e.firstDeep - t.firstDeep).map((e) => e.rid),
		visitOrder: e.players.filter((e) => e.firstVisit !== null).sort((e, t) => e.firstVisit - t.firstVisit).map((e) => e.rid)
	};
	return n.effects[0]?.kind === "placeOcean" && (n.effects[0].cards = t.discoveries, n.effects[0].depths = t.discoveries.map((t) => t === "lostStar" && e.config.scenario === 6 ? 5 : D[t].depth)), n;
}
var Ht = class {
	rid;
	w;
	scoreCache = /* @__PURE__ */ new Map();
	opportunityCache = /* @__PURE__ */ new Map();
	constructor(e, t) {
		this.rid = e, this.w = t;
	}
	player(e) {
		return e.players.find((e) => e.rid === this.rid);
	}
	future(e) {
		return (6 - e.round) * this.w.future;
	}
	quality(e) {
		return e.experts.map((e) => Math.max(0, ...Re(e).map((e) => $(e.map((e) => zt[e])))));
	}
	accessible(e, t, n) {
		if (t.vessels.includes(n) || t.vessels.includes("robot") && e.robot === n) return !0;
		let r = e.zones.find((e) => e.id === n);
		return n === "cave" && t.vessels.some((t) => {
			let n = e.zones.find((e) => e.id === t);
			return n.depth === r.depth && Math.abs(n.x - r.x) === 1 || n.depth === r.depth - 1 && n.x === r.x;
		});
	}
	attribute(e, t, n, r) {
		let i = Math.min(12, e.attributes[t] + n), a = e.attributes[t], o = this.future(r), s = w(i) - w(a), c = Bt(i) - Bt(a);
		return t === "I" && (s += c * o * this.w.economy), t === "C" && (s += c * o * (this.w.economy + this.w.recovery)), t === "R" && (s += c * o * this.w.recruitment), t === "G" && (s += c * (1 + o) * this.w.technology + [2, 7].filter((e) => a < e && i >= e).length * (.8 + o * .2)), s += Math.max(0, i - 9) * 1.8 - Math.max(0, a - 9) * 1.8, s;
	}
	reward(e, t, n = this.rid) {
		let r = t.players.find((e) => e.rid === n);
		return $(e.split(/\s+/).filter(Boolean).map((e) => {
			let i = /^([RICGrdphal])(\d+)$/.exec(e);
			if (i) {
				let e = Number(i[2]), n = i[1];
				if ("RICG".includes(n)) return this.attribute(r, n, e, t);
				if (n === "r") return Math.min(e, 12 - r.research) * (1 / 3 + this.w.research * (r.research < 5 ? 1 : .4));
				if (n === "d") return e * (1 / 3 + this.w.disc * (r.discs < 4 ? 1 : .4));
				if (n === "h") return e * 2.1;
				if (n === "p") return r.experts.some((e) => !e.senior) ? e * 3.5 * this.w.promotion : 0;
				let a = [
					"R",
					"I",
					"C",
					"G"
				].filter((e) => n !== "l" || r.attributes[e] === Math.min(...Object.values(r.attributes)));
				return Math.max(...a.map((n) => this.attribute(r, n, e, t)));
			}
			return e.startsWith("x") ? (2.7 + this.future(t) * .12) * this.w.discovery : e === "orca" ? t.orcas ? 1.8 : 0 : e === "badge" ? t.badges.length ? 1.3 : 0 : e === "robotMove" ? 2.2 : e === "tradeDisc" ? r.discs > 0 ? this.reward(`r${Math.min(5, 12 - r.research)}`, t, n) - this.w.disc - 1 / 3 : 0 : zt[e] ?? (e === "dive2" ? 5 : e.startsWith("conserve") ? 3.6 : e === "sailPlus" ? 2 : 0);
		}));
	}
	tokenValue(e, t) {
		let n = S[e], r = this.player(t);
		return this.w.token * Math.max(n.research * (1 / 3 + this.w.research * .65), this.reward(n.effect, t) * .8) * (r.tokens.length > 2 ? .9 : 1);
	}
	opportunity(e, t, n) {
		let r = e.zones.find((e) => e.id === n), i = D[n], a = JSON.stringify([
			n,
			r.slots,
			r.dives.map((e) => e.length),
			t.rid,
			t.attributes,
			t.research,
			t.discs,
			t.experts.some((e) => !e.senior),
			e.market,
			e.orcas,
			e.badges
		]), o = this.opportunityCache.get(a);
		if (o !== void 0) return o;
		let s = i.sites.filter((e) => !r.slots[e.id]).map((n) => n.kind === "sonar" ? this.reward(n.reward, e, t.rid) - this.w.disc : n.kind === "conserve" ? this.reward(n.reward, e, t.rid) - n.cost * (1 / 3 + this.w.research) - (e.config.scenario === 9 ? 0 : this.w.disc) + (e.config.scenario === 9 ? 2 : 0) : Math.max(0, ...e.market.filter((e) => x[e].fields.includes(n.field)).map((n) => {
			let r = x[n];
			return r.points + this.reward(r.you, e, t.rid) - r.cost * (1 / 3 + this.w.research) - this.w.disc;
		})));
		r.dives.some((e) => e.length) && s.push(2.2 + Number([
			"brine",
			"lostStar",
			"sharks",
			"snails"
		].includes(n)));
		let c = Math.max(0, ...s) + Math.min(3, s.length) * .15;
		return this.opportunityCache.set(a, c), c;
	}
	value(e) {
		let t = this.player(e), n = this.w, r = this.future(e), i = this.quality(t), a = JSON.stringify([
			e.zones.map((e) => [
				e.id,
				e.x,
				e.depth,
				e.slots,
				e.dives.map((e) => !e.length),
				e.linked
			]),
			e.impact,
			e.players.map((e) => [
				e.rid,
				e.attributes,
				e.vessels,
				e.explored,
				e.goals,
				e.cleanup,
				e.firstDeep,
				e.firstVisit,
				e.journals.map((e) => e.id),
				e.experts.filter((e) => e.senior).map((e) => e.id)
			])
		]), o = this.scoreCache.get(a);
		o || (o = e.players.map((t) => $(L(e, t).slice(0, 6))), this.scoreCache.set(a, o));
		let s = e.players.indexOf(t), c = o[s] + (t.research + t.discs) / 3;
		c -= n.opponent * $(o.filter((e, t) => t !== s)) / (e.players.length - 1);
		let l = i.filter((e) => e > 0).length;
		c += r * (Math.min(Bt(t.attributes.I) + 1 + Math.min(Bt(t.attributes.C) + 1, l), l * 1.7) * n.economy + Math.min(Bt(t.attributes.C) + 1, l) * n.recovery), c += r * Bt(t.attributes.R) * n.recruitment + (1 + r) * Bt(t.attributes.G) * n.technology, c += Math.min(t.discs, 4) * n.disc * (.25 + Math.min(1, r) * .75) + Math.max(0, t.discs - 4) * .05 + Math.min(t.research, 6) * n.research + Math.max(0, t.research - 6) * n.research * .3, c += $(t.tokens.map((t) => this.tokenValue(t, e)));
		let u = {};
		for (let e of t.experts) for (let t of new Set(Re(e).flat())) u[t] = (u[t] ?? 0) + 1;
		c += ($(i) * .1 + $(Object.entries(u).map(([e, t]) => Math.sqrt(t) * zt[e]))) * (.2 + r * .15) * n.expert, c += Math.min(t.discs, t.experts.filter((e, t) => !e.occupied && i[t] > 0).length) * n.ready, c += $(t.journals.map((e) => x[e.id].actions.filter((t, n) => !e.used.includes(n)).length)) * .6;
		let d = e.zones.filter((n) => this.accessible(e, t, n.id)).map((n) => this.opportunity(e, t, n.id)).sort((e, t) => t - e);
		return c += (d[0] ?? 0) * n.access + $(d.slice(1)) * n.access * .15, c += t.orcas * 1.3, c;
	}
	estimate(e, t) {
		let n = this.player(e), r = e.zones.find((e) => e.id === t.zone), i = r && D[r.id].sites.find((e) => e.id === t.value);
		if (t.kind === "sonar" || t.kind === "conserve") {
			let n = this.reward(i.reward, e) - (t.n ?? 0) * (1 / 3 + this.w.research) - (t.kind === "conserve" && e.config.scenario === 9 ? 0 : this.w.disc) + 1;
			for (let t of D[r.id].links) (t.a === i.id && r.slots[t.b] || t.b === i.id && r.slots[t.a]) && (n += this.reward(t.reward, e));
			return n;
		}
		if (t.kind === "journal") {
			let n = x[t.card];
			return n.points + this.reward(n.you, e) - n.cost * (1 / 3 + this.w.research) - this.w.disc + 1;
		}
		if (t.kind === "impact") return t.hex === "conserve" ? 3 : t.score + this.reward(j[e.config.scenario].hexes.find((e) => e.id === t.hex).reward, e);
		if (t.kind === "attribute") return this.attribute(n, t.value, 1, e);
		if (t.kind === "promote") {
			let r = n.experts.find((e) => e.uid === t.expert);
			return this.reward(y[r.id].senior, e) + Number(r.occupied) * 2 + y[r.id].tier * .3;
		}
		return t.kind === "sail" || t.kind === "launch" || t.kind === "robotMove" ? this.reward(D[t.zone].arrival, e) + this.opportunity(e, n, t.zone) * this.w.access : t.kind === "order" || t.kind === "activate" || t.kind === "copy" ? $((t.value ?? "").split(",").map((e) => zt[e] ?? 0)) : t.kind === "tokenEffect" || t.kind === "journalAction" ? this.reward(t.value, e) : t.kind === "tokenResearch" ? this.reward(`r${S[t.card].research}`, e) - this.tokenValue(t.card, e) : t.kind === "skip" || t.kind === "pass" || t.kind === "end" ? 0 : t.score;
	}
	pending(e) {
		let t = e.effects[0];
		if (!t || t.owner !== this.rid) return 0;
		if (t.kind === "order" || t.kind === "copy") return $((t.value ?? "").split(",").map((e) => zt[e] ?? 0)) * .75;
		let n = He(e, this.rid).filter((e) => !e.kind.startsWith("token"));
		return Math.max(0, ...n.map((t) => this.estimate(e, t))) * this.w.pending;
	}
	settle(e) {
		let t = 0;
		for (let n = 0; n < 64; n++) {
			let n = e.effects[0];
			if (!n || e.phase === "over" || e.phase === "roundEnd") break;
			if (n.kind === "beginDiscovery") {
				e.effects.shift();
				let r = n.depths ?? [1], i = Math.max(...r);
				t += (2.7 + this.future(e) * .12 + Number(e.config.scenario === 6) * .7 + Number(e.config.scenario === 10 && i === 5 && this.player(e).firstDeep === null) * 3) * this.w.discovery;
				continue;
			}
			if (n.kind === "gainDive") {
				let r = e.players.find((e) => e.rid === n.owner), i = r.tokens.length;
				if (Je(e), e.effects[0]?.kind === "divePick") {
					let t = He(e, n.owner)[0];
					t && Qe(e, n.owner, t);
				}
				let a = r.tokens.length - i;
				r.tokens.splice(i), n.owner === this.rid && (t += a * 2.7 * this.w.token);
				continue;
			}
			if (De(e)) {
				Je(e);
				continue;
			}
			if (n.kind === "reward") {
				Qe(e, n.owner, {
					id: "accept",
					kind: "accept",
					score: 0
				});
				continue;
			}
			if (n.kind === "order" && n.value?.split(",").length === 1) {
				Qe(e, n.owner, {
					id: "order:0",
					kind: "order",
					n: 0,
					value: n.value,
					score: 0
				});
				continue;
			}
			break;
		}
		return t;
	}
	apply(e, t) {
		let n = structuredClone(e);
		return t.kind === "divePick" ? (this.player(n).tokens.push(Number(t.value)), n.effects.shift()) : t.kind === "refillExpert" ? n.effects.shift() : Qe(n, this.rid, t), {
			s: n,
			bonus: this.settle(n)
		};
	}
	search(e, t, n, r) {
		let i = t.map((t) => {
			let n = this.apply(e, t);
			return {
				choice: t,
				...n,
				value: this.value(n.s) + n.bonus + this.pending(n.s) + (r?.get(t.id) ?? 0) * this.w.guide
			};
		}).sort((e, t) => t.value - e.value || e.choice.id.localeCompare(t.choice.id)), a = n > 0 ? i.slice(0, this.w.beam) : i;
		if (n > 0) for (let e of a) {
			if (e.s.effects[0]?.owner !== this.rid) continue;
			let t = He(e.s, this.rid).filter((e) => !e.kind.startsWith("token"));
			t.length && (e.value = this.search(e.s, t, n - 1).value + e.bonus + (r?.get(e.choice.id) ?? 0) * this.w.guide);
		}
		return a.sort((e, t) => t.value - e.value || e.choice.id.localeCompare(t.choice.id)), a[0];
	}
};
function Ut(e = {}) {
	let t = {
		...Rt,
		...e
	};
	return (e, n) => {
		let r = e.private?.choices ?? [];
		if (!r.length) return null;
		let i = Vt(e.public, e.private);
		return { action: {
			type: "choose",
			id: new Ht(n.rid, t).search(i, r, t.depth, Lt(e, n)).choice.id
		} };
	};
}
//#endregion
//#region src/games/endeavordeepsea/bot.ts
var Wt = Ut(), Gt = (e, t) => {
	if (t.difficulty !== "weak") return Wt(e, t);
	let n = e.private?.choices ?? [];
	if (!n.length) return null;
	let r = Lt(e, t);
	return { action: {
		type: "choose",
		id: n.reduce((e, t) => r.get(t.id) > r.get(e.id) ? t : e).id
	} };
};
//#endregion
//#region src/games/endeavordeepsea/endgame-review.tsx
function Kt({ board: e, renderResult: t, ...r }) {
	let s = u(), [c, l] = o(!0), [f, p] = o(null), te = a(null), re = a(null), ie = a(null);
	n(() => {
		if (!f) return;
		ie.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => p(null), 5e3);
		return () => clearTimeout(e);
	}, [f]);
	let ae = (e) => {
		p(null), l(e), requestAnimationFrame(() => (e ? te : re).current?.focus({ preventScroll: !0 }));
	}, m = i(() => ({
		onPlayAgain: r.onPlayAgain && (() => p({
			run: r.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: r.onBackToLobby && (() => p({
			run: r.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: r.onPlayAgainWithConfig && ((e) => p({
			run: () => r.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		r.onPlayAgain,
		r.onBackToLobby,
		r.onPlayAgainWithConfig
	]), oe = {
		...r,
		...m
	};
	return /* @__PURE__ */ _("div", {
		className: "endeavordeepsea-endgame",
		style: { "--endgame-seats": r.result.ranking.length },
		children: [
			/* @__PURE__ */ g("div", {
				className: "endeavordeepsea-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ g("div", {
				className: "endeavordeepsea-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ _("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), ae(!1));
					},
					className: "endeavordeepsea-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ _("header", {
							className: "endeavordeepsea-endgame-heading",
							children: [/* @__PURE__ */ _("div", {
								className: "endeavordeepsea-endgame-brand",
								children: [/* @__PURE__ */ g("span", {
									"aria-hidden": "true",
									children: $e.icon
								}), s($e.nameKey)]
							}), /* @__PURE__ */ g("button", {
								type: "button",
								ref: te,
								className: "btn-quiet",
								"aria-label": s("games.endeavordeepsea.reviewHide"),
								title: s("games.endeavordeepsea.reviewHide"),
								onClick: () => ae(!1),
								children: /* @__PURE__ */ g(ee, { size: 19 })
							})]
						}),
						/* @__PURE__ */ g("div", {
							className: "endeavordeepsea-endgame-result",
							inert: f !== null,
							children: t(oe)
						}),
						f && /* @__PURE__ */ _("div", {
							className: "endeavordeepsea-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || p(null);
							},
							children: [/* @__PURE__ */ g("button", {
								type: "button",
								ref: ie,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = f.run;
									p(null), e();
								},
								children: s(f.label === "again" ? "games.endeavordeepsea.reviewConfirmAgain" : "games.endeavordeepsea.reviewConfirmLobby")
							}), /* @__PURE__ */ g("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									p(null), te.current?.focus({ preventScroll: !0 });
								},
								children: s("games.endeavordeepsea.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ g("div", {
				className: "endeavordeepsea-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-base",
					ref: re,
					onClick: () => ae(!0),
					children: [
						/* @__PURE__ */ g(ne, { size: 18 }),
						s("games.endeavordeepsea.reviewShow"),
						/* @__PURE__ */ g(d, { size: 18 })
					]
				})
			})
		]
	});
}
function qt({ result: e, members: n, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: c, renderRowExtra: d, summary: p, navigation: te, content: ne, afterRanking: re, scoreUnit: ie, rankOf: ae }) {
	let m = u(), oe = l((e) => e.locale), [se, ce] = o({}), le = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ue(t, oe) : e;
	}, fe = (t, n) => ae?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), pe = e.ranking.some((t) => e.scores?.[t] !== void 0), me = (t, n) => /* @__PURE__ */ _("div", {
		className: "endeavordeepsea-score-identity",
		children: [
			/* @__PURE__ */ _("span", {
				className: "endeavordeepsea-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ g("span", {
					"aria-label": m("games.endeavordeepsea.reviewWinner"),
					children: "♛ "
				}), pe && fe(t, n)]
			}),
			/* @__PURE__ */ _("span", {
				className: "endeavordeepsea-score-name",
				children: [le(t), t === r && /* @__PURE__ */ g("small", { children: m("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ _("small", {
				className: "endeavordeepsea-score-autopilot",
				children: [
					/* @__PURE__ */ g(f, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), he = (t) => e.ranking.map((n) => /* @__PURE__ */ g("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ _("div", {
		className: "endeavordeepsea-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ g(de, {}),
			te,
			/* @__PURE__ */ _("div", {
				className: "endeavordeepsea-score-body",
				children: [
					p && /* @__PURE__ */ g("div", {
						className: "endeavordeepsea-score-summary",
						children: p
					}),
					i !== void 0 && /* @__PURE__ */ g("p", {
						className: "endeavordeepsea-score-hints",
						children: m("session.hint.usedCount", { n: i })
					}),
					ne ?? (c?.length ? /* @__PURE__ */ g("div", {
						className: "endeavordeepsea-score-table-scroll",
						children: /* @__PURE__ */ _("table", {
							className: "endeavordeepsea-score-table",
							"aria-label": m($e.nameKey),
							children: [
								/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", { scope: "col" }), /* @__PURE__ */ g(h, { children: e.ranking.map((t, n) => /* @__PURE__ */ g("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: me(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ g("tbody", { children: c.map((e, n) => /* @__PURE__ */ _(t, { children: [/* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ _("button", {
										type: "button",
										"aria-expanded": !!se[n],
										onClick: () => ce((e) => ({
											...e,
											[n]: !e[n]
										})),
										children: [/* @__PURE__ */ g(ee, { size: 15 }), e.label]
									}) : e.label
								}), he(e)] }), se[n] && e.details?.map((e, t) => /* @__PURE__ */ _("tr", {
									className: "endeavordeepsea-score-sub",
									children: [/* @__PURE__ */ g("th", {
										scope: "row",
										children: e.label
									}), he(e)]
								}, t))] }, n)) }),
								pe && /* @__PURE__ */ g("tfoot", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", {
									scope: "row",
									children: m("games.endeavordeepsea.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ g("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ g("ol", {
						className: "endeavordeepsea-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ _("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ _("div", {
								className: "endeavordeepsea-score-rankline",
								children: [me(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ _("strong", {
									className: "endeavordeepsea-score-points",
									children: [e.scores[t], ie && /* @__PURE__ */ g("small", { children: ie })]
								})]
							}), d?.(t)]
						}, t))
					})),
					re,
					!!c?.length && d && /* @__PURE__ */ g("div", {
						className: "endeavordeepsea-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ _("details", { children: [/* @__PURE__ */ g("summary", { children: le(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ _("footer", {
				className: "endeavordeepsea-score-actions",
				children: [
					s && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: m("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: m("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ g("p", { children: m("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/endeavordeepsea/endgame-scores.tsx
function Jt(e) {
	let t = u(), n = e.public, r = [
		"scoreTracks",
		"scoreImpact",
		"scoreCards",
		"scoreGoal1",
		"scoreGoal2",
		"scoreGoal3",
		"scoreLeft"
	].map((e, r) => ({
		label: t(K[e]),
		value: (e) => n.players.find((t) => t.rid === e)?.score[r] ?? "—"
	}));
	return /* @__PURE__ */ g(qt, {
		...e,
		renderRowExtra: void 0,
		rows: r
	});
}
//#endregion
//#region src/games/endeavordeepsea/game-over.tsx
function Yt(e) {
	return /* @__PURE__ */ g(Jt, { ...e });
}
function Xt(e) {
	return /* @__PURE__ */ g(Kt, {
		...e,
		board: /* @__PURE__ */ g(It, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ g(Yt, { ...e })
	});
}
//#endregion
//#region src/games/endeavordeepsea/game-over-row.tsx
function Zt({ public: e, rid: t }) {
	let n = u(), r = e.players.find((e) => e.rid === t);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-wrap gap-x-3 gap-y-1 text-xs",
		children: r?.score.map((e, t) => /* @__PURE__ */ _("span", { children: [
			n(K[[
				"scoreTracks",
				"scoreImpact",
				"scoreCards",
				"scoreGoal1",
				"scoreGoal2",
				"scoreGoal3",
				"scoreLeft"
			][t]]),
			" ",
			/* @__PURE__ */ g("b", { children: e })
		] }, t))
	});
}
//#endregion
//#region src/games/endeavordeepsea/options.tsx
function Qt({ value: e, onChange: t }) {
	let n = u(), r = et.safeParse(e), i = r.success ? r.data : et.parse(void 0);
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ g(pe, {
			title: n(K.scenario),
			children: Array.from({ length: 10 }, (e, t) => t + 1).map((e) => /* @__PURE__ */ g(fe, {
				name: "eds-scenario",
				value: String(e),
				checked: i.scenario === e,
				label: `${e}. ${n(K[`scenario_${e}`])}`,
				accent: $e.accent,
				onChange: () => t({
					...i,
					scenario: e
				})
			}, e))
		}), /* @__PURE__ */ g(pe, {
			title: n(K.expansions),
			children: [
				"orca",
				"academy",
				"robot"
			].map((e) => /* @__PURE__ */ g(me, {
				checked: i[e],
				label: n(K[`ocean_${e}`]),
				accent: $e.accent,
				onChange: () => t({
					...i,
					[e]: !i[e]
				})
			}, e))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/endeavordeepsea/entry.tsx
var $t = {
	definition: at,
	View: It,
	bot: Gt,
	OverView: Xt,
	RowView: Zt,
	Options: Qt,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "奋进号：深海",
			desc: "组建专家团队，探索海域、发表期刊并保护海洋。",
			invalidAction: "此时无法执行该操作，请重新选择。",
			round: "第 {{n}} / 6 轮",
			waiting: "等待 {{name}}",
			resolving: "正在领取奖励",
			ocean: "海洋",
			team: "专家团队",
			expedition: "{{name}}的考察队",
			trackScore: "终局得分",
			ability_R: "每轮可招募级别不超过 {{n}} 的专家",
			ability_I: "每轮获得 {{n}} 枚筹备圆片",
			ability_C: "每轮可从专家牌上取回至多 {{n}} 枚圆片",
			ability_G: "每次航行至多 {{n}} 格\n可到达的最大深度为 {{n}}",
			subUnlock: "创造力首次达到此数值时，获得 1 艘潜艇",
			confirmAction: "确认操作",
			cancelSelection: "取消选择",
			zoomOut: "缩小海图",
			zoomIn: "放大海图",
			oceanOverview: "重置海图位置",
			selectSite: "选择行动目标",
			showGoals: "剧本目标",
			impact: "影响力",
			market: "公开期刊",
			supply: "可招募专家",
			scenario: "剧本",
			expansions: "迷你扩展",
			actions: "可用行动",
			choose: "选择操作",
			details: "查看详情",
			all: "全部",
			noChoices: "等待其他玩家操作",
			noTokens: "没有潜水指示物",
			disc: "筹备圆片",
			research: "研究值",
			depth: "深度 {{n}}",
			arrival: "抵达奖励",
			discovery: "发现奖励",
			junior: "初级专家",
			senior: "资深专家",
			tier: "级别 {{n}}",
			occupied: "已激活",
			available: "可激活",
			journalActionUsed: "此期刊行动已使用",
			journalActionAvailable: "此期刊行动尚未使用",
			published: "已发表期刊",
			others: "其他玩家",
			you: "你",
			points: "{{n}} 分",
			cost: "支付 {{n}} 点研究值",
			left: "剩余 {{n}} 张",
			diveSite: "潜水位置",
			journalSite: "期刊发表位置",
			conserveSite: "生态保护位置",
			sonarTrack: "声呐轨道",
			emptyOcean: "尚未探索",
			vessels: "潜艇",
			tokens: "潜水指示物",
			launch: "启航区",
			startPlayer: "起始玩家",
			passed: "已退出本轮",
			log: "最近行动",
			board: "海域详情",
			links: "链接奖励",
			upgrade: "漫游者升级",
			badge: "训练徽章",
			blueBadge: "蓝色训练徽章：可替换专家的一项行动",
			redBadge: "红色训练徽章：额外执行一项徽章行动",
			orcaCount: "持有 {{n}} 只虎鲸",
			cleanup: "清理进度 {{n}} / 8",
			journalUse: "使用期刊行动",
			goalChoice: "选择目标的计分方式",
			goalOne: "选项一",
			goalTwo: "选项二",
			privateDiscovery: "选择海域板块及其放置位置",
			column: "{{col}} 列 · 深度 {{n}}",
			allActions: "查看全部操作（共 {{n}} 项）",
			afterMain: "可以使用潜水指示物，或结束回合",
			main: "激活专家、使用期刊或潜水指示物",
			over: "游戏结束",
			scoreTracks: "属性轨道",
			scoreImpact: "影响力网格",
			scoreCards: "期刊与专家得分",
			scoreGoal1: "目标一",
			scoreGoal2: "目标二",
			scoreGoal3: "目标三",
			scoreLeft: "剩余资源",
			choosePosition: "放置于 {{col}} 列",
			tokenValue: "获得 {{n}} 点研究值",
			special: "特殊规则",
			remainingResearch: "研究值：{{n}} / 12",
			hex: "影响力位置 {{n}}",
			linkPair: "{{a}} 与 {{b}}",
			sharedRobot: "公共漫游者",
			attribute_R: "声望",
			attribute_I: "灵感",
			attribute_C: "调配力",
			attribute_G: "创造力",
			field_blue: "地质学",
			field_brown: "生态学",
			field_green: "海洋生物学",
			field_yellow: "海洋学",
			action_sail: "航行",
			action_sonar: "声呐探测",
			action_dive: "潜水",
			action_conserve: "生态保护",
			action_journal: "发表期刊",
			action_promote: "晋升专家",
			action_copy: "复制专家行动",
			action_accept: "领取奖励",
			action_skip: "放弃本次效果",
			action_launch: "放置新潜艇",
			action_recruit: "招募专家",
			action_reassign: "调配圆片",
			action_attribute: "提升属性",
			action_impact: "放置影响力标记",
			action_order: "选择下一项行动",
			action_divePick: "选择潜水指示物",
			action_draw: "抽取海域板块",
			action_placeOcean: "放置海域板块",
			action_fullOcean: "获得 1 点影响力",
			action_robotPlace: "放置漫游者",
			action_robotMove: "移动漫游者",
			action_upgrade: "升级漫游者",
			action_badge: "装备训练徽章",
			action_badgeUpgrade: "升级训练徽章",
			action_goal: "选择目标",
			action_tradeDisc: "弃置 1 枚筹备圆片，获得 5 点研究值",
			action_activate: "激活专家",
			action_journalAction: "使用期刊行动",
			action_pass: "退出本轮",
			action_end: "结束回合",
			action_tokenResearch: "换取研究值",
			action_tokenEffect: "使用潜水指示物的效果",
			action_tokenDiscard: "弃置潜水指示物",
			action_conserveDepth: "在自己潜艇所在深度执行生态保护",
			action_conserveCheap: "执行生态保护，研究费用减少 1 点",
			action_sailPlus: "本次航行的创造力等级提高 1 级",
			action_dive2: "执行潜水，额外获得 1 枚潜水指示物",
			"action_x3-5": "发现深度为 3 至 5 的海域",
			action_orca: "领取 1 只虎鲸",
			prompt_setup: "准备启航",
			prompt_recruit: "选择一位专家加入团队",
			prompt_reassign: "选择要从专家牌上取回的圆片",
			prompt_reward: "领取奖励",
			prompt_attribute: "选择要提升的属性",
			prompt_promote: "选择一位初级专家晋升",
			prompt_impact: "选择影响力标记的位置",
			prompt_order: "选择专家的下一项行动",
			prompt_copy: "选择要复制的专家行动",
			prompt_sail: "选择潜艇与目的海域",
			prompt_sonar: "选择一条声呐轨道",
			prompt_dive: "选择潜水位置",
			prompt_divePick: "选择要保留的潜水指示物",
			prompt_conserve: "选择生态保护位置",
			prompt_journal: "选择期刊及其发表位置",
			prompt_discover: "选择要抽取的海域板块深度",
			prompt_placeOcean: "选择海域板块及其放置位置",
			prompt_robotPlace: "选择漫游者的起始海域",
			prompt_robotMove: "选择漫游者的目的海域",
			prompt_upgrade: "选择一项漫游者升级",
			prompt_badge: "选择徽章与专家",
			prompt_badgeUpgrade: "选择要升级的训练徽章",
			prompt_goal: "选择目标的计分方式",
			prompt_tradeDisc: "可以弃置一个筹备圆片换取研究值",
			prompt_launch: "选择启航区",
			ocean_seaStar: "海洋之星号",
			ocean_reef: "濒死的珊瑚礁",
			ocean_volcano: "火山岛",
			ocean_kelp: "海草林",
			ocean_anchorage: "偏远锚地",
			ocean_rig: "废弃的石油钻井",
			ocean_calm: "平静水域",
			ocean_atoll: "环礁",
			ocean_lookingGlass: "海洋观测境",
			ocean_dolphins: "海豚群",
			ocean_ruins: "沉没的遗迹",
			ocean_pod: "临时探测舱",
			ocean_cave: "沉没的洞穴系统",
			ocean_wreck: "沉船",
			ocean_whales: "鲸鱼保育区",
			ocean_elevator: "岩架电梯",
			ocean_turtles: "海龟迁徙地",
			ocean_jellyfish: "水母群",
			ocean_vortex: "巨型涡流",
			ocean_vents: "热液喷口",
			ocean_sharks: "深水鲨鱼",
			ocean_rift: "深海裂谷",
			ocean_spires: "碳化尖塔",
			ocean_coldReef: "冷水珊瑚群",
			ocean_whaleFall: "鲸落",
			ocean_plain: "深渊平原",
			ocean_snails: "鳞足蜗牛",
			ocean_lostStar: "陨落之星",
			ocean_trench: "深渊海沟",
			ocean_smokers: "海底黑烟囱",
			ocean_recovery: "海底污染恢复区",
			ocean_bioluminescence: "发光生物群",
			ocean_shelf: "海底大陆架",
			ocean_squid: "大王乌贼",
			ocean_brine: "深海盐水池",
			ocean_sponge: "海绵园地",
			ocean_seamount: "海底山",
			ocean_orca: "虎鲸归海",
			ocean_academy: "深海学院",
			ocean_robot: "漫游者控制船",
			expert_371: "声呐操作员",
			senior_371: "声学工程师",
			expert_372: "海礁潜水员",
			senior_372: "水下摄影师",
			expert_373: "驾驶员",
			senior_373: "舰长",
			expert_374: "海洋工程师",
			senior_374: "航海构造者",
			expert_375: "导航员",
			senior_375: "水文学家",
			expert_376: "生态学家",
			senior_376: "毒理学家",
			expert_377: "实地研究员",
			senior_377: "海洋科学家",
			expert_378: "水产养殖者",
			senior_378: "海洋生物培育师",
			expert_379: "遥控操作员",
			senior_379: "深海摄影师",
			expert_380: "潜艇队长",
			senior_380: "探险领队",
			expert_381: "深海潜水员",
			senior_381: "深海生态学家",
			expert_382: "海洋研究专家",
			senior_382: "环境大使",
			expert_383: "生物科技学家",
			senior_383: "资深生物科技学家",
			expert_384: "鱼类学家",
			senior_384: "资深鱼类学家",
			expert_386: "冒险家",
			senior_386: "著名冒险家",
			expert_387: "机械工程师",
			senior_387: "资深机械工程师",
			expert_388: "舰队统领",
			senior_388: "资深舰队统领",
			expert_389: "海洋专业导师",
			senior_389: "资深海洋专业导师",
			expert_390: "潜水冠军",
			senior_390: "资深潜水冠军",
			expert_391: "海洋历史学家",
			senior_391: "资深海洋历史学家",
			expert_392: "生物地理学家",
			senior_392: "资深生物地理学家",
			expert_393: "队长",
			senior_393: "队长",
			journal_0: "改善海洋科研的学习环境",
			journal_1: "保护濒危海洋栖息地",
			journal_2: "先进声呐通信系统",
			journal_3: "面向公众的海洋研究指南",
			journal_4: "先进压载系统",
			journal_5: "提高研究效率",
			journal_6: "相互联系的海洋系统",
			journal_7: "高级压力喷口技术",
			journal_8: "人工智能模型在深海研究中的应用",
			journal_9: "面向公众的科学成就",
			journal_10: "理解深渊生物",
			journal_11: "深海卫星测绘",
			journal_12: "航海日志编写",
			journal_13: "海洋保护模型",
			journal_14: "永久海洋实验室的可行性研究",
			journal_15: "荧光检测系统",
			journal_16: "全息海床地图",
			journal_17: "微塑料自动收集装置",
			journal_18: "深海通信网络",
			journal_19: "信息共享的益处",
			journal_20: "海洋学的新发展",
			journal_21: "潜艇安全航行规程",
			journal_22: "发现新物种",
			journal_23: "海洋哺乳动物的社会学研究",
			journal_24: "用于深海探险的有机套管",
			journal_25: "尚未记录的深海生物",
			journal_26: "多支考察队发现报告的编写",
			journal_27: "生态系统风险沟通",
			journal_28: "海洋保护区的扩展",
			journal_29: "水下探索移动设备",
			journal_30: "理解海洋变化",
			journal_31: "使用相机阵列拍摄珊瑚礁",
			scenario_1: "海洋的召唤",
			scenario_2: "地图与海图",
			scenario_3: "海洋期刊",
			scenario_4: "超乎想象",
			scenario_5: "陨落之星",
			scenario_6: "搜寻陨落之星",
			scenario_7: "寻回陨落之星",
			scenario_8: "新视野",
			scenario_9: "石油泄漏",
			scenario_10: "海洋最深处",
			goal_1_0: "自己的每枚声呐圆片获得 1 分。\n数量第一名额外获得 5 分，第二名额外获得 3 分。",
			goal_1_1: "自己的每枚期刊圆片获得 1 分。\n数量第一名额外获得 3 分，第二名额外获得 1 分。",
			goal_1_2: "自己的每枚生态保护圆片获得 1 分。\n数量第一名额外获得 7 分，第二名额外获得 4 分。",
			goal_2_0: "B 列中，自己的每枚声呐圆片获得 1 分。\n数量第一名额外获得 4 分，第二名额外获得 2 分。",
			goal_2_1: "D 列中，自己的每枚圆片和每艘潜艇分别获得 1 分。\n数量第一名额外获得 7 分，第二名额外获得 4 分。",
			goal_2_2: "深度 2 至 4 中，每个有自己圆片的海域获得 1 分。\n数量第一名额外获得 2 分，第二名额外获得 1 分。",
			goal_3_0: "深度 1 至 2 中，自己的每枚声呐圆片获得 1 分。\n数量第一名额外获得 6 分，第二名额外获得 3 分。",
			goal_3_1: "深度 3 至 5 中，自己的每枚期刊圆片和每艘潜艇分别获得 1 分。\n数量第一名额外获得 4 分，第二名额外获得 2 分。",
			goal_3_2: "四种领域分别比较。\n每种领域中，标记数量最多且不为零的玩家获得 2 分；并列者均获得奖励。",
			goal_4_0: "深度 1 至 3 中，自己的每枚生态保护圆片获得 1 分。\n数量第一名额外获得 6 分，第二名额外获得 3 分。",
			goal_4_1: "A 列和 E 列中，自己的每枚期刊圆片和每艘潜艇分别获得 1 分。\n数量第一名额外获得 7 分，第二名额外获得 4 分。",
			goal_4_2: "深度 4 至 5 中，自己的每枚圆片获得 1 分。\n数量第一名额外获得 4 分，第二名额外获得 2 分。",
			goal_5_0: "A 列和 B 列中，自己的每枚声呐圆片和每艘潜艇分别获得 1 分。\n数量第一名额外获得 2 分，第二名额外获得 1 分。",
			goal_5_1: "E 列、F 列和 G 列中，自己的每枚期刊圆片和每艘潜艇分别获得 1 分。\n数量第一名额外获得 2 分，第二名额外获得 1 分。",
			goal_5_2: "深度 2 至 3 中，自己的每枚生态保护圆片获得 1 分。\n数量第一名额外获得 4 分，第二名额外获得 2 分。",
			goal_6_0: "深度 2 至 4 中，每个有自己圆片的海域获得 1 分。\n数量第一名额外获得 4 分，第二名额外获得 2 分。",
			goal_6_1: "自己发现的每个海域获得 1 分。\n分别比较深度 3、4、5，以及 B 列、D 列的发现数量。\n每项数量最多且不为零的玩家额外获得 2 分；并列者均获得奖励。",
			goal_6_2: "发现陨落之星的玩家选择生态保护或发表期刊。\n该玩家在陨落之星的每枚所选类型圆片获得 3 分。",
			goal_7_0: "C 列中，每个有自己圆片或潜艇的海域获得 2 分。\n按自己在 C 列的圆片与潜艇总数排名，第一名额外获得 2 分，第二名获得 1 分。",
			goal_7_1: "C 列以外，自己的每枚生态保护圆片和期刊圆片分别获得 1 分。\n数量第一名额外获得 6 分，第二名额外获得 3 分。",
			goal_7_2: "按救援网格中的影响力标记数量排名。\n第一名获得 4 分，第二名获得 2 分。",
			goal_8_0: "近海指海洋之星号所在列及相邻两列，远海指其余各列。\n在选定范围内，每个有自己圆片的海域获得 1 分。\n海域数量第一名额外获得 2 分，第二名额外获得 1 分。",
			goal_8_1: "浅水海域指深度 2 至 3，深水海域指深度 4 至 5。\n在选定深度中，自己的每枚圆片获得 1 分。\n圆片数量第一名额外获得 2 分，第二名额外获得 1 分。",
			goal_8_2: "专攻：按自己数量最多的一种领域标记计分，每枚获得 1 分。\n博闻：每套包含四种领域的标记获得 3 分。\n本项目标得分第一名额外获得 2 分，第二名额外获得 1 分。",
			goal_9_0: "自己的清理进度每提高 1 格，获得 1 分。\n清理进度第一名额外获得 2 分，第二名额外获得 1 分。",
			goal_9_1: "深度 1 中，自己的每枚圆片和每艘潜艇分别获得 1 分。\n数量第一名额外获得 5 分，第二名额外获得 3 分。",
			goal_9_2: "深度 2 至 3 中，自己的每枚生态保护圆片获得 1 分。\n数量第一名额外获得 4 分，第二名额外获得 2 分。",
			goal_10_0: "按首次发现深度 5 海域的先后顺序计分。\n第一位玩家获得 4 分，第二位玩家获得 2 分。",
			goal_10_1: "按潜艇首次抵达深度 5 海域的先后顺序计分。\n第一位玩家获得 4 分，第二位玩家获得 3 分。",
			goal_10_2: "深度 4 至 5 中，自己的每枚期刊圆片获得 1 分。\n数量第一名额外获得 7 分，第二名额外获得 4 分。",
			special_rig: "所有生态保护位置均被占据后，每位在此拥有潜艇的玩家可以晋升 1 位初级专家。",
			special_whales: "若自己占据绿色期刊发表位置，每次在此完成生态保护后，可以再执行一次生态保护。",
			special_ruins: "潜水指示物堆被取空时，每位在此拥有潜艇的玩家可以执行一次航行。",
			special_wreck: "每次潜水抽取 2 枚潜水指示物，保留其中 1 枚，弃置另一枚。",
			special_turtles: "在此执行生态保护时，可以在完成生态保护前执行一次航行。",
			special_cave: "潜艇不能驶入或穿过此海域。\n自己在正上方、左侧或右侧海域拥有潜艇时，可以在此执行海域行动。",
			special_jellyfish: "若自己占据带黄色圆环的位置，每次航行驶入或驶出此海域时，获得 1 点影响力。",
			special_vortex: "航行驶入或驶出此海域时，创造力等级提高 1 级。\n使用指定声呐位置发现海域时，深度 3 的板块可以没有正上方海域。",
			special_vents: "每次获得潜水指示物时，自己在此海域的每枚圆片提供 1 点研究值。",
			special_sharks: "每获得 1 枚潜水指示物，同时提高 1 点声望。",
			special_seamount: "若自己占据任一生态保护位置，每获得 1 枚潜水指示物，可以将最低的属性提高 1 点。",
			special_brine: "每获得 1 枚潜水指示物，同时获得 1 点影响力。",
			special_bioluminescence: "从左侧潜水指示物堆获得指示物时，额外获得 1 点研究值。\n从右侧潜水指示物堆获得指示物时，额外获得 1 枚筹备圆片。",
			special_plain: "通过此海域的声呐轨道发现深度 5 海域时，板块正上方可以没有深度 4 海域。",
			special_smokers: "每获得 1 枚潜水指示物，可以执行一次航行，但本次航行不能进入深度 5 海域。",
			special_trench: "每位玩家在此海域至多拥有 1 艘潜艇。",
			special_snails: "每获得 1 枚潜水指示物，可以立即在此海域执行一次发表期刊。",
			special_lostStar: "每获得 1 枚潜水指示物，同时获得 1 点影响力。",
			special_orca: "抵达时领取 1 只虎鲸。\n在尚无虎鲸的海域执行生态保护时，可以放归 1 只虎鲸，免除本次研究费用。",
			special_academy: "抵达时，为一位级别 1 或 2、尚无徽章的专家装备蓝色训练徽章。\n在此执行海域行动后，可以将一枚蓝色训练徽章升级为红色。",
			special_robot: "抵达时可以移动公共漫游者。\n自己在此拥有潜艇时，可以通过漫游者在其所在海域执行海域行动。\n在此发表期刊后，可以选择一项公共漫游者升级。",
			scenarioRule_1: "将影响力标记放在入口，或与任一已占据位置相邻的空位。\n黄色位置每枚标记获得 1 分，橙色位置每枚获得 2 分。",
			scenarioRule_2: "从入口开始放置影响力标记，再沿相邻位置扩展。\n三个目标分别按 B 列、D 列和指定深度的情况计分。",
			scenarioRule_3: "影响力网格中的领域位置计入领域标记数量，但不提供即时奖励。\n新潜艇可以在任一深度 1 海域启航。",
			scenarioRule_4: "通过生态保护获得的影响力，可以放入独立的 3 分区域。\n每位玩家在每个海域至多使用一次此放置方式。",
			scenarioRule_5: "海洋最大深度为 3。\n首次放置影响力标记时选择一只海豚，此后只能使用同一只海豚的网格。",
			scenarioRule_6: "获得影响力时，将自己的一个已有标记移动到相邻空位。\n只有没有合法移动时，才放置一个新标记。\n发现陨落之星后，才能进入计分位置。",
			scenarioRule_7: "只有在陨落之星海域获得的影响力可以放入救援网格。\n其他来源的影响力放入主要影响力网格。",
			scenarioRule_8: "首次占据目标位置的玩家，为所有玩家选择该目标的计分方式。\n自己的第三大影响力集群中，每枚标记额外获得 1 分。",
			scenarioRule_9: "生态保护圆片直接从供应区取得，不消耗筹备圆片。\n每次执行生态保护，自己的清理进度提高 1 格。\n任一玩家的清理进度达到 2 后，开放深度 3；达到 5 后，开放深度 4。",
			scenarioRule_10: "影响力标记放在奖励来源海域所对应的深度轨道。\n从海域以外获得的影响力，可以选择任一深度轨道。",
			action_relocateOcean: "移动海域板块",
			prompt_relocateOcean: "选择该海域板块的新位置",
			siteNumber: "位置 {{n}}",
			sonarPosition: "声呐轨道 {{track}}，位置 {{n}}",
			moveImpact: "将影响力标记从位置 {{from}} 移至位置 {{to}}",
			goal_near: "近海：海洋之星号所在列及相邻两列",
			goal_far: "远海：其余各列",
			goal_shallow: "浅水海域：深度 2 至 3",
			goal_deep: "深水海域：深度 4 至 5",
			goal_specialize: "专攻：按自己数量最多的一种领域标记计分",
			goal_diversify: "博闻：按自己集齐的四种领域标记套数计分",
			goal_conserve: "生态保护：自己的每枚生态保护圆片获得 3 分",
			goal_journal: "发表期刊：自己的每枚期刊圆片获得 3 分",
			expertScore_383: "每个有自己期刊圆片的深度获得 1 分。",
			expertScore_384: "选择自己生态保护圆片最多的海域，其中每枚圆片获得 1 分。",
			expertScore_386: "每 3 个有自己圆片或潜艇的海域获得 1 分。",
			expertScore_387: "游戏结束时获得 4 分。",
			expertScore_388: "每 2 条与其他玩家共同完成的链接获得 1 分。",
			expertScore_389: "自己的其他资深专家，每位获得 1 分。",
			expertScore_390: "海洋中每 2 处已取空的潜水位置获得 1 分。",
			expertScore_391: "每套包含四种领域的标记获得 3 分。",
			expertScore_392: "每个有自己生态保护圆片的海域获得 1 分。",
			prompt_refillExpert: "选择补入空位的级别 5 专家",
			action_refillExpert: "补充专家供应",
			and: "；",
			or: "，或者",
			abilityLevel: "等级 {{n}}",
			attributeRange: "属性数值 {{lo}} 至 {{hi}}",
			reward_R: "声望提高 {{n}} 点",
			reward_I: "灵感提高 {{n}} 点",
			reward_C: "调配力提高 {{n}} 点",
			reward_G: "创造力提高 {{n}} 点",
			reward_r: "获得 {{n}} 点研究值",
			reward_d: "获得 {{n}} 枚筹备圆片",
			reward_h: "获得 {{n}} 点影响力",
			reward_p: "晋升 {{n}} 位初级专家",
			reward_a: "任选属性，合计提高 {{n}} 点",
			reward_l: "将最低的属性提高 {{n}} 点",
			discoverDepths: "发现深度为 {{from}} 至 {{to}} 的海域",
			drawSameDepth: "从深度 {{n}} 的海域牌堆抽取 2 张板块",
			drawDifferentDepths: "从深度 {{from}} 和 {{to}} 的海域牌堆各抽取 1 张板块",
			diveTokenOptions: "使用时可获得 {{n}} 点研究值，或执行以下效果：{{effect}}",
			releaseOrca: "放归 1 只虎鲸",
			travelRoute: "从{{from}}航行至{{to}}",
			log_recruit: "招募了{{expert}}。",
			log_promote: "将一位专家晋升为{{expert}}。",
			log_activate: "激活了一位专家。",
			log_journal: "发表了《{{journal}}》。",
			log_journalAction: "使用了《{{journal}}》上的行动。",
			log_sail: "航行至{{ocean}}。",
			log_sonar: "在{{ocean}}执行了声呐探测。",
			log_dive: "在{{ocean}}执行了潜水。",
			log_conserve: "在{{ocean}}执行了生态保护。",
			log_discovery: "发现了{{ocean}}。",
			log_tokenResearch: "使用潜水指示物，获得 {{n}} 点研究值。",
			log_tokenEffect: "使用了潜水指示物的效果：{{effect}}。",
			log_tokenDiscard: "弃置了 1 枚潜水指示物。",
			log_pass: "退出了本轮。",
			scenarioRules: "剧本特殊规则",
			goalUndecided: "尚未确定计分方式",
			rules: "游戏目标：\n游戏进行 6 轮，总分最高的玩家获胜；并列最高分的玩家共同获胜。\n游戏准备：\n选择一个剧本；虎鲸归海、深海学院和漫游者扩展可以分别开启。每位玩家获得一位资深队长，队长牌上放有 1 枚行动圆片。将自己的起始潜艇放入剧本指定的启航区，并领取抵达奖励。\n每轮准备：\n从起始玩家开始，按顺时针顺序，每位玩家依次完成以下三个步骤：\n· 招募专家：招募 1 位初级专家，其级别不能超过自己的声望等级。可以重复招募同一职业的专家；招募后领取该专家的奖励。\n· 获得圆片：获得等同于自己灵感等级的筹备圆片。\n· 调配圆片：从自己的专家牌上取回圆片，数量不能超过自己的调配力等级。海域板块和期刊上的圆片不能通过调配取回。\n属性数值与等级：\n声望、灵感、调配力和创造力均有数值与等级。数值 0 至 1 对应等级 1，数值 2 至 3 对应等级 2，数值 4 至 6 对应等级 3，数值 7 至 9 对应等级 4，数值 10 至 12 对应等级 5。\n玩家回合：\n从起始玩家开始轮流行动。每个回合可以执行一次主要行动，选择以下一种方式：\n· 激活专家：将 1 枚筹备圆片放到自己一位尚无圆片的专家上。斜线分隔的行动方案只能选择一组；加号连接的行动可以全部执行。同一组内的多项行动可以自行决定顺序，也可以放弃其中的行动。\n· 使用期刊：将 1 枚筹备圆片放到自己已发表期刊的未使用行动位置，并执行该位置的行动。每个期刊行动位置只能使用一次，其上的圆片不能调回筹备区。\n潜水指示物可以在主要行动前后，或专家的两项行动之间使用；抽取和放置海域板块等尚未完成的选择，必须先处理完毕。使用时，选择获得指示物的研究值，或执行其效果，随后将其弃置。\n也可以使用潜水指示物，然后结束回合，代替本回合的主要行动。回合结束时至多保留 2 枚潜水指示物。\n可以选择退出本轮。退出后，不再参加本轮后续回合。\n海域行动的条件：\n声呐探测、潜水、生态保护和发表期刊，通常须在自己潜艇所在海域执行。海域特殊规则、期刊或扩展可以允许在其他海域执行行动。\n航行：\n移动自己的一艘潜艇，航程上限等于自己的创造力等级。航行沿上下左右相邻的已发现海域进行，不能穿过空位；经过和抵达的海域深度，均不能超过自己的创造力等级。只领取目的海域的抵达奖励，不领取途经海域的抵达奖励。\n声呐探测与发现：\n额外支付 1 枚筹备圆片，将其放入所选声呐轨道最左侧的空位，并领取该位置的奖励。\n若获得发现海域的奖励，在奖励标示的范围内选择抽取深度，共抽取 2 张海域板块，可以来自同一深度，也可以来自两个深度。选择其中 1 张放入海洋，将另一张放回对应牌堆底部。\n放置位置必须为空。深度 1 的板块须放在剧本允许的列中；更深的板块通常须有正上方海域。发现海域不受自己的创造力等级限制。\n指定深度没有可放置位置时，改用最浅的可发现深度。海洋已无可发现的海域时，改为获得 1 点影响力。\n潜水：\n选择一处仍有指示物的潜水位置，取得堆顶的 1 枚潜水指示物。潜水本身不额外消耗筹备圆片或研究值。\n生态保护：\n选择一个空置的生态保护位置，额外支付 1 枚筹备圆片和该位置标示的研究值。将圆片放在该位置，并领取其奖励。\n发表期刊：\n选择一个空置的期刊发表位置，再从公开期刊中选择一张包含该位置领域的期刊。额外支付 1 枚筹备圆片和期刊标示的研究值，将圆片放在该位置，并将期刊加入自己的考察队。自己和其他玩家分别领取期刊上对应的奖励，随后从期刊牌堆补充公开期刊；牌堆用尽后不再补充。\n晋升与链接奖励：\n晋升时，将一位初级专家翻至资深面，并领取晋升奖励。晋升不会扣除此前获得的属性；牌上原有圆片归还供应区。\n链接两端均有圆片后，两端的所属玩家各领取一次链接奖励。若两端均属于自己，只领取一次；每条链接只结算一次。\n属性与影响力奖励：\n创造力首次达到 2 和 7 时，分别获得 1 艘新潜艇。每项属性达到数值 10、11、12 时，分别获得 1 点影响力；属性达到 12 后，每次继续提高 1 点，改为获得 1 点影响力。研究值上限为 12，超过上限的部分不保留。\n每获得 1 点影响力，放置 1 枚影响力标记并领取位置上的奖励。通常可放在入口，或与任一已占据位置相邻的空位；标有无限符号的位置可容纳任意数量的标记。各剧本可能改变放置方式、开放条件和计分方式，详见剧本目标。\n虎鲸归海扩展：\n抵达虎鲸归海海域时，领取 1 只虎鲸。在尚无虎鲸的海域执行生态保护时，可以放归 1 只虎鲸，免除本次研究费用，但仍须支付生态保护所需的圆片。\n在虎鲸归海海域执行声呐探测，发现带生态保护位置的海域后，声望提高 1 点。\n深海学院扩展：\n抵达深海学院时，为一位级别 1 或 2、尚无徽章的专家装备训练徽章。蓝色训练徽章允许用徽章行动替换专家的一项行动；红色训练徽章则在专家行动之外，额外提供一项徽章行动。\n在深海学院执行海域行动后，可以将一枚蓝色训练徽章升级为红色。专家晋升后保留其训练徽章。\n漫游者扩展：\n抵达漫游者控制船时，可以将公共漫游者移动至另一海域。移动距离不限，但目的海域深度不能超过自己的创造力等级；移动后，可以领取目的海域的抵达奖励。\n自己在控制船拥有潜艇时，可以通过漫游者在其所在海域执行声呐探测、潜水、生态保护和发表期刊，通常仍需支付相应费用。漫游者不属于潜艇，不计入涉及潜艇数量的目标。\n在控制船发表期刊后，可以选择一项公共升级：\n· 声呐探测：通过漫游者执行时，不再额外支付圆片。\n· 潜水：通过漫游者潜水时，可以查看整堆并选择指示物。\n· 生态保护：通过漫游者执行时，研究费用减少 1 点。\n· 发表期刊：通过漫游者发表时，不受位置领域限制。\n游戏结束与计分：\n所有玩家均退出本轮后，起始玩家顺时针移交给下一位玩家。第 6 轮结束后，计算以下各项得分：\n· 四项属性：等级 1 至 5 分别获得 0、2、4、7、10 分。\n· 影响力：按影响力网格的位置和剧本规则计分。\n· 期刊与专家：计算期刊上的分数，以及资深级别 5 专家的计分能力。\n· 剧本目标：分别计算三个目标的基础分数和排名奖励。\n· 剩余资源：合计研究值、潜水指示物的研究值和筹备圆片数量，每满 3 点获得 1 分，不足 3 点的部分不计分。\n计算目标排名奖励时，统计数量为零的玩家不能获得该目标的排名奖励。并列第一的玩家均获得第一名奖励，不再发放第二名奖励；没有并列第一时，并列第二的玩家均获得第二名奖励。"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Endeavor: Deep Sea",
			desc: "Build your team, explore the ocean, publish journals and conserve marine habitats.",
			invalidAction: "This action is unavailable. Please choose again.",
			round: "Round {{n}} / 6",
			waiting: "Waiting for {{name}}",
			resolving: "Collecting rewards",
			ocean: "Ocean",
			team: "Team",
			expedition: "{{name}}'s expedition",
			trackScore: "Final score",
			ability_R: "Recruit a specialist of tier {{n}} or lower each round",
			ability_I: "Gain {{n}} staging discs each round",
			ability_C: "Retrieve up to {{n}} discs from specialist cards each round",
			ability_G: "Travel range (spaces): {{n}}\nMaximum depth: {{n}}",
			subUnlock: "Gain one submarine when ingenuity first reaches this value",
			confirmAction: "Confirm action",
			cancelSelection: "Cancel selection",
			zoomOut: "Zoom out",
			zoomIn: "Zoom in",
			oceanOverview: "Reset map position",
			selectSite: "Select a target",
			showGoals: "Scenario goals",
			impact: "Impact",
			market: "Journal display",
			supply: "Specialist supply",
			scenario: "Scenario",
			expansions: "Mini expansions",
			actions: "Actions",
			choose: "Choose an action",
			details: "Details",
			all: "All",
			noChoices: "Waiting for another player",
			noTokens: "No dive tokens",
			disc: "Staging discs",
			research: "Research",
			depth: "Depth {{n}}",
			arrival: "Arrival bonus",
			discovery: "Discovery bonus",
			junior: "Junior specialist",
			senior: "Senior specialist",
			tier: "Tier {{n}}",
			occupied: "Activated",
			available: "Ready",
			journalActionUsed: "This journal action has been used",
			journalActionAvailable: "This journal action is unused",
			published: "Published journals",
			others: "Others",
			you: "You",
			points: "{{n}} points",
			cost: "Pay {{n}} research",
			left: "{{n}} cards remaining",
			diveSite: "Dive site",
			journalSite: "Publication site",
			conserveSite: "Conservation site",
			sonarTrack: "Sonar track",
			emptyOcean: "Unexplored",
			vessels: "Vessels",
			tokens: "Dive tokens",
			launch: "Launch zone",
			startPlayer: "Start player",
			passed: "Passed",
			log: "Recent actions",
			board: "Zone details",
			links: "Link rewards",
			upgrade: "Wanderer upgrades",
			badge: "Training badge",
			blueBadge: "Blue training badge: may replace one specialist action",
			redBadge: "Red training badge: perform an additional badge action",
			orcaCount: "{{n}} orcas available",
			cleanup: "Cleanup {{n}} / 8",
			journalUse: "Use a journal action",
			goalChoice: "Choose the scoring option",
			goalOne: "Option one",
			goalTwo: "Option two",
			privateDiscovery: "Choose an ocean board and where to place it",
			column: "Column {{col}} · Depth {{n}}",
			allActions: "View all {{n}} available actions",
			afterMain: "Spend dive tokens or end your turn",
			main: "Activate a specialist, journal or dive token",
			over: "Game over",
			scoreTracks: "Attributes",
			scoreImpact: "Impact board",
			scoreCards: "Journal and specialist scores",
			scoreGoal1: "Goal one",
			scoreGoal2: "Goal two",
			scoreGoal3: "Goal three",
			scoreLeft: "Leftovers",
			choosePosition: "Place in column {{col}}",
			tokenValue: "Gain {{n}} research",
			special: "Special rule",
			remainingResearch: "Research: {{n}} / 12",
			hex: "Impact space {{n}}",
			linkPair: "{{a}} and {{b}}",
			sharedRobot: "Shared Wanderer",
			attribute_R: "Reputation",
			attribute_I: "Inspiration",
			attribute_C: "Coordination",
			attribute_G: "Ingenuity",
			field_blue: "Geology",
			field_brown: "Ecology",
			field_green: "Marine biology",
			field_yellow: "Oceanography",
			action_sail: "Travel",
			action_sonar: "Sonar",
			action_dive: "Dive",
			action_conserve: "Conserve",
			action_journal: "Journal",
			action_promote: "Promote",
			action_copy: "Copy specialist actions",
			action_accept: "Collect bonus",
			action_skip: "Decline this effect",
			action_launch: "Deploy a vessel",
			action_recruit: "Recruit",
			action_reassign: "Reassign",
			action_attribute: "Advance an attribute",
			action_impact: "Place impact",
			action_order: "Choose the next action",
			action_divePick: "Choose a dive token",
			action_draw: "Draw ocean boards",
			action_placeOcean: "Place an ocean board",
			action_fullOcean: "Gain one impact",
			action_robotPlace: "Place the Wanderer",
			action_robotMove: "Move the Wanderer",
			action_upgrade: "Upgrade the Wanderer",
			action_badge: "Equip a training badge",
			action_badgeUpgrade: "Upgrade a training badge",
			action_goal: "Choose a goal",
			action_tradeDisc: "Discard one staging disc to gain five research",
			action_activate: "Activate a specialist",
			action_journalAction: "Use a journal action",
			action_pass: "Pass this round",
			action_end: "End turn",
			action_tokenResearch: "Exchange for research",
			action_tokenEffect: "Use the dive token effect",
			action_tokenDiscard: "Discard a dive token",
			action_conserveDepth: "Conserve at a depth occupied by one of your submarines",
			action_conserveCheap: "Conserve with a discount of one research",
			action_sailPlus: "Travel with your ingenuity level increased by one",
			action_dive2: "Dive and take one additional dive token",
			"action_x3-5": "Discover an ocean zone at depth 3 to 5",
			action_orca: "Take one orca",
			prompt_setup: "Prepare to launch",
			prompt_recruit: "Recruit a specialist",
			prompt_reassign: "Choose a disc to retrieve from a specialist",
			prompt_reward: "Collect a bonus",
			prompt_attribute: "Choose an attribute",
			prompt_promote: "Promote a junior specialist",
			prompt_impact: "Choose an impact space",
			prompt_order: "Choose the specialist’s next action",
			prompt_copy: "Choose specialist actions to copy",
			prompt_sail: "Choose a vessel and destination",
			prompt_sonar: "Choose a sonar track",
			prompt_dive: "Choose a dive site",
			prompt_divePick: "Choose a dive token to keep",
			prompt_conserve: "Choose a conservation site",
			prompt_journal: "Choose a journal and its publication site",
			prompt_discover: "Choose the depths of the ocean boards to draw",
			prompt_placeOcean: "Choose an ocean board and where to place it",
			prompt_robotPlace: "Choose the Wanderer’s starting zone",
			prompt_robotMove: "Choose the Wanderer’s destination",
			prompt_upgrade: "Choose a Wanderer upgrade",
			prompt_badge: "Choose a badge and specialist",
			prompt_badgeUpgrade: "Choose a badge to upgrade",
			prompt_goal: "Choose a goal’s scoring option",
			prompt_tradeDisc: "You may trade a staging disc for research",
			prompt_launch: "Choose a launch zone",
			ocean_seaStar: "The Sea Star",
			ocean_reef: "Dying Reef",
			ocean_volcano: "Volcanic Island",
			ocean_kelp: "Kelp Forest",
			ocean_anchorage: "Remote Anchorage",
			ocean_rig: "Abandoned Oil Rig",
			ocean_calm: "Calm Seas",
			ocean_atoll: "Atoll",
			ocean_lookingGlass: "The Looking Glass",
			ocean_dolphins: "Dolphin Pod",
			ocean_ruins: "Sunken Ruins",
			ocean_pod: "Survey Pod",
			ocean_cave: "Underwater Cave System",
			ocean_wreck: "Shipwreck",
			ocean_whales: "Whale Sanctuary",
			ocean_elevator: "Ledge Elevator",
			ocean_turtles: "Turtle Migration",
			ocean_jellyfish: "Jellyfish Bloom",
			ocean_vortex: "Giant Vortex",
			ocean_vents: "Thermal Vents",
			ocean_sharks: "Deepwater Sharks",
			ocean_rift: "Deep Rift",
			ocean_spires: "Carbon Spires",
			ocean_coldReef: "Coldwater Reef",
			ocean_whaleFall: "Whale Fall",
			ocean_plain: "Abyssal Plain",
			ocean_snails: "Scaly-foot Snails",
			ocean_lostStar: "The Lost Star",
			ocean_trench: "Abyssal Trench",
			ocean_smokers: "Black Smokers",
			ocean_recovery: "Pollution Recovery Zone",
			ocean_bioluminescence: "Bioluminescent Bloom",
			ocean_shelf: "Continental Shelf",
			ocean_squid: "Giant Squid",
			ocean_brine: "Brine Pool",
			ocean_sponge: "Sponge Garden",
			ocean_seamount: "Seamount",
			ocean_orca: "Orca Reintroduction",
			ocean_academy: "Underwave Academy",
			ocean_robot: "Wanderer Control Ship",
			expert_371: "Sonar Operator",
			senior_371: "Acoustic Engineer",
			expert_372: "Reef Diver",
			senior_372: "Underwater Photographer",
			expert_373: "Pilot",
			senior_373: "Skipper",
			expert_374: "Marine Engineer",
			senior_374: "Naval Architect",
			expert_375: "Navigator",
			senior_375: "Hydrographer",
			expert_376: "Ecologist",
			senior_376: "Toxicologist",
			expert_377: "Field Researcher",
			senior_377: "Ocean Scientist",
			expert_378: "Aquaculturist",
			senior_378: "Marine Cultivator",
			expert_379: "Remote Operator",
			senior_379: "Deep Sea Photographer",
			expert_380: "Submarine Captain",
			senior_380: "Expedition Leader",
			expert_381: "Deep Sea Diver",
			senior_381: "Deep Sea Ecologist",
			expert_382: "Marine Researcher",
			senior_382: "Environmental Ambassador",
			expert_383: "Biotechnologist",
			senior_383: "Senior Biotechnologist",
			expert_384: "Ichthyologist",
			senior_384: "Senior Ichthyologist",
			expert_386: "Adventurer",
			senior_386: "Renowned Adventurer",
			expert_387: "Mechanical Engineer",
			senior_387: "Senior Mechanical Engineer",
			expert_388: "Fleet Commander",
			senior_388: "Senior Fleet Commander",
			expert_389: "Marine Mentor",
			senior_389: "Senior Marine Mentor",
			expert_390: "Diving Champion",
			senior_390: "Senior Diving Champion",
			expert_391: "Marine Historian",
			senior_391: "Senior Marine Historian",
			expert_392: "Biogeographer",
			senior_392: "Senior Biogeographer",
			expert_393: "Team Leader",
			senior_393: "Team Leader",
			journal_0: "Improving Marine Learning Environments",
			journal_1: "Protecting Endangered Marine Habitats",
			journal_2: "Advanced Sonar Communication",
			journal_3: "Public Guide to Marine Research",
			journal_4: "Advanced Ballast Systems",
			journal_5: "Improving Research Efficiency",
			journal_6: "Interconnected Ocean Systems",
			journal_7: "Advanced Pressure Vent Technology",
			journal_8: "AI Models for Deep Sea Research",
			journal_9: "Public Scientific Achievement",
			journal_10: "Understanding Abyssal Life",
			journal_11: "Deep Sea Satellite Mapping",
			journal_12: "Writing Navigation Logs",
			journal_13: "Marine Conservation Models",
			journal_14: "Permanent Ocean Laboratory Feasibility",
			journal_15: "Fluorescence Detection Systems",
			journal_16: "Holographic Seabed Maps",
			journal_17: "Automated Microplastic Collection",
			journal_18: "Deep Sea Communication Networks",
			journal_19: "Benefits of Information Sharing",
			journal_20: "Reshaping Oceanography",
			journal_21: "Vessel Safety Procedures",
			journal_22: "Discovering New Species",
			journal_23: "Marine Mammal Social Research",
			journal_24: "Organic Casings for Deep Sea Exploration",
			journal_25: "Uncharted Deep Sea Organisms",
			journal_26: "Optimizing Multi-team Discovery Reports",
			journal_27: "Effective Communication of Ecosystemic Risk",
			journal_28: "Effective Expansion of Protected Areas",
			journal_29: "Underwater Exploration Mobility",
			journal_30: "Understanding Ocean Change",
			journal_31: "Reef Photography with Camera Arrays",
			scenario_1: "Call of the Ocean",
			scenario_2: "Maps and Charts",
			scenario_3: "Ocean Journals",
			scenario_4: "Beyond Imagination",
			scenario_5: "The Lost Star",
			scenario_6: "Searching for the Lost Star",
			scenario_7: "Recovering the Lost Star",
			scenario_8: "New Horizons",
			scenario_9: "Oil Spill",
			scenario_10: "The Deepest Ocean",
			goal_1_0: "Score one point per sonar disc of your color.\nThe highest count earns 5 extra points; the second highest earns 3.",
			goal_1_1: "Score one point per publication disc of your color.\nThe highest count earns 3 extra points; the second highest earns 1.",
			goal_1_2: "Score one point per conservation disc of your color.\nThe highest count earns 7 extra points; the second highest earns 4.",
			goal_2_0: "In column B, score one point per sonar disc of your color.\nThe highest count earns 4 extra points; the second highest earns 2.",
			goal_2_1: "In column D, score one point for each of your discs and submarines.\nThe highest count earns 7 extra points; the second highest earns 4.",
			goal_2_2: "At depths 2 to 4, score one point per zone with a disc of your color.\nThe highest count earns 2 extra points; the second highest earns 1.",
			goal_3_0: "At depths 1 to 2, score one point per sonar disc of your color.\nThe highest count earns 6 extra points; the second highest earns 3.",
			goal_3_1: "At depths 3 to 5, score one point for each of your publication discs and submarines.\nThe highest count earns 4 extra points; the second highest earns 2.",
			goal_3_2: "Compare the four fields separately.\nFor each field, every player tied for the highest nonzero symbol count scores two points.",
			goal_4_0: "At depths 1 to 3, score one point per conservation disc of your color.\nThe highest count earns 6 extra points; the second highest earns 3.",
			goal_4_1: "In columns A and E, score one point for each of your publication discs and submarines.\nThe highest count earns 7 extra points; the second highest earns 4.",
			goal_4_2: "At depths 4 to 5, score one point per disc of your color.\nThe highest count earns 4 extra points; the second highest earns 2.",
			goal_5_0: "In columns A and B, score one point for each of your sonar discs and submarines.\nThe highest count earns 2 extra points; the second highest earns 1.",
			goal_5_1: "In columns E, F and G, score one point for each of your publication discs and submarines.\nThe highest count earns 2 extra points; the second highest earns 1.",
			goal_5_2: "At depths 2 to 3, score one point per conservation disc of your color.\nThe highest count earns 4 extra points; the second highest earns 2.",
			goal_6_0: "At depths 2 to 4, score one point per zone with a disc of your color.\nThe highest count earns 4 extra points; the second highest earns 2.",
			goal_6_1: "Score one point for each zone you discovered.\nCompare discoveries at depths 3, 4 and 5, and in columns B and D separately.\nFor each comparison, every player tied for the highest nonzero count scores two extra points.",
			goal_6_2: "The player who discovers the Lost Star chooses conservation or publication discs.\nThat player scores three points for each of their chosen discs in the Lost Star.",
			goal_7_0: "In column C, score two points per zone with one of your discs or submarines.\nRank by your total discs and submarines in column C: first earns two extra points; second earns one.",
			goal_7_1: "Outside column C, score one point for each of your conservation and publication discs.\nThe highest count earns 6 extra points; the second highest earns 3.",
			goal_7_2: "Rank by the number of your impact markers in the rescue grid.\nFirst place scores four points; second place scores two.",
			goal_8_0: "Nearby zones are in the Sea Star column and its adjacent columns; distant zones are in all other columns.\nIn the chosen area, score one point per zone with your disc.\nThe highest zone count earns two extra points; the second highest earns one.",
			goal_8_1: "Shallow zones are at depths 2 to 3; deep zones are at depths 4 to 5.\nAt the chosen depths, score one point per disc of your color.\nThe highest disc count earns two extra points; the second highest earns one.",
			goal_8_2: "Specialize: score one point per symbol in your most numerous field.\nDiversify: score three points per complete set of four field symbols.\nThe highest score for this goal earns two extra points; the second highest earns one.",
			goal_9_0: "Score one point for each step on your cleanup track.\nThe highest cleanup progress earns two extra points; the second highest earns one.",
			goal_9_1: "At depth 1, score one point for each of your discs and submarines.\nThe highest count earns 5 extra points; the second highest earns 3.",
			goal_9_2: "At depths 2 to 3, score one point per conservation disc of your color.\nThe highest count earns 4 extra points; the second highest earns 2.",
			goal_10_0: "Score by the order in which players first discover a depth-5 zone.\nThe first player scores four points; the second scores two.",
			goal_10_1: "Score by the order in which players first reach a depth-5 zone with a submarine.\nThe first player scores four points; the second scores three.",
			goal_10_2: "At depths 4 to 5, score one point per publication disc of your color.\nThe highest count earns 7 extra points; the second highest earns 4.",
			special_rig: "When all conservation sites are occupied, each player with a submarine here may promote one junior specialist.",
			special_whales: "If you occupy the green publication site, you may conserve here again after each conservation action.",
			special_ruins: "When the dive token stack empties, each player with a submarine here may travel once.",
			special_wreck: "When diving, draw two dive tokens, keep one and discard the other.",
			special_turtles: "When conserving here, you may travel once before completing the conservation action.",
			special_cave: "Submarines cannot enter or pass through this zone.\nA submarine immediately above, left or right of this zone allows you to perform zone actions here.",
			special_jellyfish: "If you occupy a site with a yellow ring, gain one impact whenever you travel into or out of this zone.",
			special_vortex: "Travel into or out of this zone with your ingenuity level increased by one.\nDiscovery from the marked sonar space may place a depth-3 board without a zone immediately above it.",
			special_vents: "Whenever you take a dive token here, gain one research for each of your discs in this zone.",
			special_sharks: "Whenever you take a dive token here, increase reputation by one.",
			special_seamount: "If you occupy a conservation site here, each dive token taken lets you advance a lowest attribute by one.",
			special_brine: "Whenever you take a dive token here, gain one impact.",
			special_bioluminescence: "Each token taken from the left dive stack also grants one research.\nEach token taken from the right dive stack also grants one staging disc.",
			special_plain: "When discovering a depth-5 zone through this sonar track, no depth-4 zone is required immediately above it.",
			special_smokers: "Whenever you take a dive token here, you may travel once, but cannot enter depth 5 during that action.",
			special_trench: "Each player may have at most one submarine in this zone.",
			special_snails: "Whenever you take a dive token here, you may immediately publish a journal in this zone.",
			special_lostStar: "Whenever you take a dive token here, gain one impact.",
			special_orca: "Take one orca on arrival.\nWhen conserving in a zone without an orca, you may release one orca to waive the research cost.",
			special_academy: "On arrival, equip a tier-1 or tier-2 specialist without a badge with a blue training badge.\nAfter performing a zone action here, you may upgrade one blue training badge to red.",
			special_robot: "On arrival, you may move the shared Wanderer.\nA submarine here lets you perform zone actions through the Wanderer in its current zone.\nAfter publishing a journal here, you may choose a shared Wanderer upgrade.",
			scenarioRule_1: "Place impact at an entry or in an empty space adjacent to any occupied space.\nEach marker in a yellow space scores one point; each in an orange space scores two.",
			scenarioRule_2: "Place impact starting at an entry, then expand into adjacent spaces.\nThe three goals score column B, column D and the specified depths.",
			scenarioRule_3: "Field spaces on the impact board count as field symbols but grant no immediate bonus.\nNew submarines may launch in any depth-1 zone.",
			scenarioRule_4: "Impact earned through conservation may be placed in the separate three-point area.\nEach player may use this placement once per ocean zone.",
			scenarioRule_5: "The maximum ocean depth is three.\nChoose a dolphin when placing your first impact marker; all your later markers must use that dolphin’s grid.",
			scenarioRule_6: "When gaining impact, move one of your existing markers to an adjacent empty space.\nPlace a new marker only when no legal move is available.\nScoring spaces become available after the Lost Star is discovered.",
			scenarioRule_7: "Only impact earned in the Lost Star zone may be placed in the rescue grid.\nPlace impact from other sources on the main impact board.",
			scenarioRule_8: "The first player to occupy a goal space chooses that goal’s scoring option for everyone.\nEach marker in your third-largest impact cluster scores one extra point.",
			scenarioRule_9: "Take conservation discs from supply without spending staging discs.\nEach conservation action advances your cleanup track by one.\nDepth 3 opens when any player reaches cleanup 2; depth 4 opens at cleanup 5.",
			scenarioRule_10: "Place impact on the depth track matching the zone where it was earned.\nFor impact earned outside an ocean zone, choose any depth track.",
			action_relocateOcean: "Relocate an ocean board",
			prompt_relocateOcean: "Choose a new position for this ocean board",
			siteNumber: "Site {{n}}",
			sonarPosition: "Sonar track {{track}}, space {{n}}",
			moveImpact: "Move your impact marker from space {{from}} to space {{to}}",
			goal_near: "Nearby zones: the Sea Star column and its adjacent columns",
			goal_far: "Distant zones: all other columns",
			goal_shallow: "Shallow zones: depths 2 to 3",
			goal_deep: "Deep zones: depths 4 to 5",
			goal_specialize: "Specialize: score your most numerous field symbol",
			goal_diversify: "Diversify: score your complete sets of four field symbols",
			goal_conserve: "Conservation: score three points per conservation disc",
			goal_journal: "Journals: score three points per publication disc",
			expertScore_383: "Score one point for each depth with your publication disc.",
			expertScore_384: "In the zone with the most of your conservation discs, score one point per disc.",
			expertScore_386: "Score one point per three zones with your discs or submarines.",
			expertScore_387: "Score four points at the end of the game.",
			expertScore_388: "Score one point per two links completed with another player.",
			expertScore_389: "Score one point for each of your other senior specialists.",
			expertScore_390: "Score one point per two empty dive sites in the ocean.",
			expertScore_391: "Score three points per complete set of four field symbols.",
			expertScore_392: "Score one point per zone with your conservation disc.",
			prompt_refillExpert: "Choose a tier-5 specialist to refill the empty space",
			action_refillExpert: "Refill specialist supply",
			and: " and ",
			or: " or ",
			abilityLevel: "Level {{n}}",
			attributeRange: "Attribute value {{lo}} to {{hi}}",
			reward_R: "Increase reputation by {{n}}",
			reward_I: "Increase inspiration by {{n}}",
			reward_C: "Increase coordination by {{n}}",
			reward_G: "Increase ingenuity by {{n}}",
			reward_r: "Gain {{n}} research",
			reward_d: "Gain {{n}} staging discs",
			reward_h: "Gain {{n}} impact",
			reward_p: "Promote {{n}} junior specialists",
			reward_a: "Advance attributes of your choice by {{n}} in total",
			reward_l: "Advance a lowest attribute by {{n}}",
			discoverDepths: "Discover an ocean zone at depth {{from}} to {{to}}",
			drawSameDepth: "Draw two ocean boards from depth {{n}}",
			drawDifferentDepths: "Draw one ocean board at depth {{from}} and one at depth {{to}}",
			diveTokenOptions: "When spent, gain {{n}} research or use this effect: {{effect}}",
			releaseOrca: "Release one orca",
			travelRoute: "Travel from {{from}} to {{to}}",
			log_recruit: "Recruited {{expert}}.",
			log_promote: "Promoted a specialist to {{expert}}.",
			log_activate: "Activated a specialist.",
			log_journal: "Published “{{journal}}”.",
			log_journalAction: "Used an action on “{{journal}}”.",
			log_sail: "Traveled to {{ocean}}.",
			log_sonar: "Performed sonar in {{ocean}}.",
			log_dive: "Dived in {{ocean}}.",
			log_conserve: "Completed conservation in {{ocean}}.",
			log_discovery: "Discovered {{ocean}}.",
			log_tokenResearch: "Spent a dive token to gain {{n}} research.",
			log_tokenEffect: "Spent a dive token for its effect: {{effect}}.",
			log_tokenDiscard: "Discarded one dive token.",
			log_pass: "Passed for the rest of the round.",
			scenarioRules: "Scenario rules",
			goalUndecided: "Scoring option not yet chosen",
			rules: "Goal:\nPlay six rounds. The highest total score wins; tied players share victory.\nSetup:\nChoose a scenario. Orca Reintroduction, Academy and Wanderer may each be enabled.\nEach player starts with a senior Team Leader occupied by one action disc. Deploy your starting submarine in a launch zone allowed by the scenario and collect its arrival bonus.\nRound preparation:\nStarting with the first player and proceeding clockwise, each player completes these three steps in order:\n· Recruit a specialist: recruit one junior specialist whose tier does not exceed your reputation level, then collect its bonus. You may recruit a profession you already have.\n· Gain discs: gain staging discs equal to your inspiration level.\n· Reassign discs: retrieve discs from your specialist cards, up to your coordination level. Discs on ocean boards and journals cannot be retrieved through reassignment.\nAttributes:\nReputation, inspiration, coordination and ingenuity each have a value and a level. Values 0 to 1 give level 1; values 2 to 3 give level 2; values 4 to 6 give level 3; values 7 to 9 give level 4; and values 10 to 12 give level 5.\nPlayer turns:\nTake turns starting with the first player. On your turn, you may perform one main action in either of these ways:\n· Activate a specialist: place one staging disc on one of your unoccupied specialists. Choose one option separated by slashes; you may perform all actions joined by plus signs. Perform the actions in your chosen option in any order, and decline any individual actions you do not wish to perform.\n· Use a journal: place one staging disc on an unused action space of a journal you published, then perform that action. Each journal action space can be used once, and its disc cannot return to your staging area.\nYou may spend dive tokens before or after your main action, or between specialist actions. Finish pending choices such as drawing and placing ocean boards before spending a token. To spend a dive token, take its research value or use its effect, then discard it.\nInstead of a main action, you may spend dive tokens and then end your turn. Keep at most two dive tokens at the end of your turn.\nYou may pass for the rest of the round. You then take no further turns that round.\nZone actions:\nSonar, diving, conservation and publication normally require your submarine in that zone. Zone rules, journals and expansions may allow actions in other zones.\nTravel:\nMove one of your submarines up to a distance equal to your ingenuity level. Travel through discovered zones adjacent above, below, left or right, without crossing empty spaces. The depth of every zone entered or crossed must not exceed your ingenuity level. Collect the destination’s arrival bonus, but not those of zones passed through.\nSonar and discovery:\nSpend one additional staging disc, place it in the leftmost empty space of a chosen sonar track and collect that space’s bonus.\nFor a discovery bonus, choose draw depths within its indicated range. Draw two ocean boards, either from the same depth or from two different depths. Place one board in the ocean and return the other to the bottom of its depth stack.\nThe destination must be empty. Place depth-1 boards within the scenario’s allowed columns; deeper boards normally require a zone immediately above them. Discovery is not limited by your ingenuity level.\nIf the specified depths cannot be placed, use the shallowest available discovery depth. If no further zones can be discovered, gain one impact instead.\nDive:\nChoose a nonempty dive site and take the top dive token from its stack. Diving itself costs no additional staging discs or research.\nConserve:\nChoose an empty conservation site, spend one additional staging disc and pay the research cost printed at that site. Place your disc at the site and collect its bonus.\nPublish a journal:\nChoose an empty publication site and a displayed journal that includes the field shown at that site. Spend one additional staging disc and pay the journal’s printed research cost. Place your disc at the site, add the journal to your expedition, and let each player collect the bonuses indicated for them.\nRefill the journal display from the deck. Stop refilling when the deck is empty.\nPromotion and links:\nTo promote, turn a junior specialist to its senior side and collect its promotion bonus. Keep attributes already gained, and return any disc on that specialist to supply.\nWhen both ends of a link are occupied, each owner collects the link bonus once. If you own both ends, collect the bonus only once. Each link resolves once.\nImpact and bonuses:\nGain one new submarine when ingenuity first reaches 2, and another when it first reaches 7. Each attribute grants one impact when it reaches 10, 11 and 12; once it is at 12, each further advance grants one impact instead. Research is capped at 12, and any excess is lost.\nFor each impact gained, place one impact marker and collect its space’s bonus. Normally, place it at an entry or in an empty space adjacent to any occupied space. Spaces with the infinity symbol may hold any number of markers. Scenario rules may change placement, access and scoring; see the scenario goals.\nOrca Reintroduction:\nTake one orca when you arrive at the Orca Reintroduction zone. When conserving in a zone without an orca, you may release one orca there. This waives the research cost, but not the required conservation disc.\nPerforming sonar in the Orca Reintroduction zone increases your reputation by one if you discover a zone with a conservation site.\nAcademy:\nOn arrival at the Academy, equip a tier-1 or tier-2 specialist without a badge. A blue training badge lets you replace one specialist action with the badge action; a red training badge adds its action to the specialist’s actions.\nAfter a zone action at the Academy, you may upgrade one blue training badge to red. A specialist keeps its training badge after promotion.\nWanderer:\nOn arrival at the Wanderer Control Ship, you may move the shared Wanderer to another zone. Distance is unlimited, but the destination depth cannot exceed your ingenuity level. After moving it, you may collect the destination’s arrival bonus.\nA submarine at the Control Ship lets you perform sonar, diving, conservation and publication in the Wanderer’s zone through the Wanderer. Normally, pay their usual costs. The Wanderer is not a submarine and does not count for submarine goals.\nAfter publishing at the Control Ship, you may choose a shared upgrade:\n· Sonar: performing sonar through the Wanderer no longer costs an additional disc.\n· Diving: when diving through the Wanderer, inspect the whole stack and choose a token.\n· Conservation: conservation through the Wanderer costs one less research.\n· Publication: publication through the Wanderer ignores the site’s field restriction.\nEndgame scoring:\nWhen everyone has passed, the next player clockwise becomes the first player. After round six, add the following scores:\n· Attributes: each attribute scores 0, 2, 4, 7 or 10 points at levels 1 to 5 respectively.\n· Impact: score your impact markers according to their spaces and the scenario rules.\n· Journals and specialists: add journal points and the scoring abilities of senior tier-5 specialists.\n· Scenario goals: score the base points and ranking bonuses for each of the three goals.\n· Remaining resources: total your research, dive token research values and staging discs. Score one point for every complete group of three; any remainder scores nothing.\nFor goal ranking bonuses, a count of zero is ineligible. Players tied for first all receive the first-place bonus, and no second-place bonus is awarded. If first place is not tied, players tied for second all receive the second-place bonus."
		}
	}
};
//#endregion
export { $t as default };
