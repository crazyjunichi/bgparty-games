import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { useFxAnchor as c, useFxAnchorsMaybe as l } from "@bgparty/sdk/fx/anchors";
import { Texture as u } from "@bgparty/sdk/texture";
import { IconCheck as d, IconClose as f, IconExpand as p, IconMirror as m, IconRecenter as ee, IconRotate as h, IconSearch as te, IconZoomIn as g, IconZoomOut as ne } from "@bgparty/sdk/icons";
import { GameScreen as re } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as ie } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as S } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as C, OptionRadio as w, OptionSection as T } from "@bgparty/sdk/ui/game-options";
//#region src/games/kingdomino/data.ts
var E = [
	"wheat",
	"forest",
	"lake",
	"grass",
	"swamp",
	"mine"
], D = [
	{
		id: 1,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 2,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 3,
		halves: [{
			terrain: "forest",
			crowns: 0
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 4,
		halves: [{
			terrain: "forest",
			crowns: 0
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 5,
		halves: [{
			terrain: "forest",
			crowns: 0
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 6,
		halves: [{
			terrain: "forest",
			crowns: 0
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 7,
		halves: [{
			terrain: "lake",
			crowns: 0
		}, {
			terrain: "lake",
			crowns: 0
		}]
	},
	{
		id: 8,
		halves: [{
			terrain: "lake",
			crowns: 0
		}, {
			terrain: "lake",
			crowns: 0
		}]
	},
	{
		id: 9,
		halves: [{
			terrain: "lake",
			crowns: 0
		}, {
			terrain: "lake",
			crowns: 0
		}]
	},
	{
		id: 10,
		halves: [{
			terrain: "grass",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: 11,
		halves: [{
			terrain: "grass",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: 12,
		halves: [{
			terrain: "swamp",
			crowns: 0
		}, {
			terrain: "swamp",
			crowns: 0
		}]
	},
	{
		id: 13,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 14,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "lake",
			crowns: 0
		}]
	},
	{
		id: 15,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: 16,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "swamp",
			crowns: 0
		}]
	},
	{
		id: 17,
		halves: [{
			terrain: "forest",
			crowns: 0
		}, {
			terrain: "lake",
			crowns: 0
		}]
	},
	{
		id: 18,
		halves: [{
			terrain: "forest",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: 19,
		halves: [{
			terrain: "wheat",
			crowns: 1
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 20,
		halves: [{
			terrain: "wheat",
			crowns: 1
		}, {
			terrain: "lake",
			crowns: 0
		}]
	},
	{
		id: 21,
		halves: [{
			terrain: "wheat",
			crowns: 1
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: 22,
		halves: [{
			terrain: "wheat",
			crowns: 1
		}, {
			terrain: "swamp",
			crowns: 0
		}]
	},
	{
		id: 23,
		halves: [{
			terrain: "wheat",
			crowns: 1
		}, {
			terrain: "mine",
			crowns: 0
		}]
	},
	{
		id: 24,
		halves: [{
			terrain: "forest",
			crowns: 1
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 25,
		halves: [{
			terrain: "forest",
			crowns: 1
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 26,
		halves: [{
			terrain: "forest",
			crowns: 1
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 27,
		halves: [{
			terrain: "forest",
			crowns: 1
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 28,
		halves: [{
			terrain: "forest",
			crowns: 1
		}, {
			terrain: "lake",
			crowns: 0
		}]
	},
	{
		id: 29,
		halves: [{
			terrain: "forest",
			crowns: 1
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: 30,
		halves: [{
			terrain: "lake",
			crowns: 1
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 31,
		halves: [{
			terrain: "lake",
			crowns: 1
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 32,
		halves: [{
			terrain: "lake",
			crowns: 1
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 33,
		halves: [{
			terrain: "lake",
			crowns: 1
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 34,
		halves: [{
			terrain: "lake",
			crowns: 1
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 35,
		halves: [{
			terrain: "lake",
			crowns: 1
		}, {
			terrain: "forest",
			crowns: 0
		}]
	},
	{
		id: 36,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 1
		}]
	},
	{
		id: 37,
		halves: [{
			terrain: "lake",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 1
		}]
	},
	{
		id: 38,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "swamp",
			crowns: 1
		}]
	},
	{
		id: 39,
		halves: [{
			terrain: "grass",
			crowns: 0
		}, {
			terrain: "swamp",
			crowns: 1
		}]
	},
	{
		id: 40,
		halves: [{
			terrain: "mine",
			crowns: 1
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 41,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 2
		}]
	},
	{
		id: 42,
		halves: [{
			terrain: "lake",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 2
		}]
	},
	{
		id: 43,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "swamp",
			crowns: 2
		}]
	},
	{
		id: 44,
		halves: [{
			terrain: "grass",
			crowns: 0
		}, {
			terrain: "swamp",
			crowns: 2
		}]
	},
	{
		id: 45,
		halves: [{
			terrain: "mine",
			crowns: 2
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: 46,
		halves: [{
			terrain: "swamp",
			crowns: 0
		}, {
			terrain: "mine",
			crowns: 2
		}]
	},
	{
		id: 47,
		halves: [{
			terrain: "swamp",
			crowns: 0
		}, {
			terrain: "mine",
			crowns: 2
		}]
	},
	{
		id: 48,
		halves: [{
			terrain: "wheat",
			crowns: 0
		}, {
			terrain: "mine",
			crowns: 3
		}]
	},
	{
		id: -6,
		halves: [{
			terrain: "forest",
			crowns: 0
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: -5,
		halves: [{
			terrain: "forest",
			crowns: 0
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: -4,
		halves: [{
			terrain: "lake",
			crowns: 0
		}, {
			terrain: "wheat",
			crowns: 0
		}]
	},
	{
		id: -3,
		halves: [{
			terrain: "mine",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: -2,
		halves: [{
			terrain: "swamp",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: -1,
		halves: [{
			terrain: "lake",
			crowns: 0
		}, {
			terrain: "grass",
			crowns: 0
		}]
	},
	{
		id: 49,
		halves: [{
			terrain: "wheat",
			crowns: 2
		}, {
			terrain: "forest",
			crowns: 1
		}]
	},
	{
		id: 50,
		halves: [{
			terrain: "forest",
			crowns: 2
		}, {
			terrain: "lake",
			crowns: 1
		}]
	},
	{
		id: 51,
		halves: [{
			terrain: "lake",
			crowns: 2
		}, {
			terrain: "grass",
			crowns: 1
		}]
	},
	{
		id: 52,
		halves: [{
			terrain: "grass",
			crowns: 2
		}, {
			terrain: "swamp",
			crowns: 1
		}]
	},
	{
		id: 53,
		halves: [{
			terrain: "swamp",
			crowns: 2
		}, {
			terrain: "mine",
			crowns: 1
		}]
	},
	{
		id: 54,
		halves: [{
			terrain: "mine",
			crowns: 2
		}, {
			terrain: "swamp",
			crowns: 1
		}]
	}
], O = [
	{
		id: 0,
		terrain: "wheat",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 1,
		terrain: "wheat",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 2,
		crowns: 0,
		base: 3,
		kind: "character",
		condition: "wheat",
		amount: 3,
		warrior: !1
	},
	{
		id: 3,
		terrain: "wheat",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 4,
		crowns: 0,
		base: 2,
		kind: "character",
		condition: "resource",
		amount: 2,
		warrior: !1
	},
	{
		id: 5,
		terrain: "forest",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 6,
		terrain: "forest",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 7,
		crowns: 0,
		base: 3,
		kind: "character",
		condition: "wood",
		amount: 3,
		warrior: !1
	},
	{
		id: 8,
		terrain: "forest",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 9,
		crowns: 0,
		base: 4,
		kind: "character",
		condition: "none",
		amount: 0,
		warrior: !0
	},
	{
		id: 10,
		terrain: "lake",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 11,
		terrain: "lake",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 12,
		crowns: 0,
		base: 3,
		kind: "character",
		condition: "fish",
		amount: 3,
		warrior: !1
	},
	{
		id: 13,
		terrain: "lake",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 14,
		crowns: 0,
		base: 4,
		kind: "character",
		condition: "none",
		amount: 0,
		warrior: !0
	},
	{
		id: 15,
		terrain: "grass",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 16,
		terrain: "grass",
		crowns: 2,
		base: 0,
		kind: "building"
	},
	{
		id: 17,
		crowns: 0,
		base: 3,
		kind: "character",
		condition: "sheep",
		amount: 3,
		warrior: !1
	},
	{
		id: 18,
		crowns: 0,
		base: 1,
		kind: "character",
		condition: "warrior",
		amount: 3,
		warrior: !0
	},
	{
		id: 19,
		crowns: 0,
		base: 3,
		kind: "character",
		condition: "none",
		amount: 0,
		warrior: !0
	},
	{
		id: 20,
		terrain: "swamp",
		crowns: 1,
		base: 0,
		kind: "building"
	},
	{
		id: 21,
		terrain: "swamp",
		crowns: 2,
		base: 0,
		kind: "building"
	},
	{
		id: 22,
		crowns: 0,
		base: 0,
		kind: "character",
		condition: "crowns",
		amount: 1,
		warrior: !1
	},
	{
		id: 23,
		crowns: 0,
		base: 2,
		kind: "character",
		condition: "character",
		amount: 2,
		warrior: !1
	},
	{
		id: 24,
		crowns: 0,
		base: 3,
		kind: "character",
		condition: "none",
		amount: 0,
		warrior: !0
	}
], k = (e) => D.find((t) => t.id === e), A = (e) => ({
	wheat: "wheat",
	forest: "wood",
	lake: "fish",
	grass: "sheep"
})[e], j = [
	"harmony",
	"middle",
	"corner",
	"lines",
	"bleak",
	...E.flatMap((e) => ["local:" + e, "corners:" + e])
];
function M(e) {
	return e < 0 ? String.fromCharCode(71 + e) : String(e % 100);
}
//#endregion
//#region src/games/kingdomino/board.ts
var N = [
	[1, 0],
	[0, 1],
	[-1, 0],
	[0, -1]
], P = (e, t) => `${e},${t}`, F = (e) => e.split(",").map(Number), I = (e) => e > 100 ? e - 100 : e;
function L(e) {
	let t = Object.keys(e).map(F);
	return {
		minX: Math.min(...t.map((e) => e[0])),
		maxX: Math.max(...t.map((e) => e[0])),
		minY: Math.min(...t.map((e) => e[1])),
		maxY: Math.max(...t.map((e) => e[1]))
	};
}
var R = (e) => e.crowns + (e.court === void 0 ? 0 : O[e.court].crowns) - e.giants;
function z(e, t, n, r, i, a) {
	let [o, s] = N[a], c = [[r, i], [r + o, i + s]];
	if (c.some(([t, n]) => e[P(t, n)])) return !1;
	let l = L(e);
	return Math.max(l.maxX, ...c.map((e) => e[0])) - Math.min(l.minX, ...c.map((e) => e[0])) >= n || Math.max(l.maxY, ...c.map((e) => e[1])) - Math.min(l.minY, ...c.map((e) => e[1])) >= n ? !1 : c.some(([n, r], i) => N.some(([a, o]) => {
		let s = e[P(n + a, r + o)];
		return s && (s.terrain === "castle" || s.terrain === k(I(t)).halves[i].terrain);
	}));
}
function B(e, t, n) {
	let r = L(e), i = [];
	for (let a = Math.max(1 - n, r.maxX - n + 1); a <= Math.min(n - 1, r.minX + n - 1); a++) for (let o = Math.max(1 - n, r.maxY - n + 1); o <= Math.min(n - 1, r.minY + n - 1); o++) for (let r = 0; r < 4; r++) z(e, t, n, a, o, r) && i.push({
		x: a,
		y: o,
		dir: r
	});
	return i;
}
function V(e, t) {
	let n = L(e), r = [];
	for (let e = n.maxX - t + 1; e <= n.minX; e++) for (let i = n.maxY - t + 1; i <= n.minY; i++) r.push({
		x: e,
		y: i
	});
	return r;
}
function H(e, t, n = []) {
	let r = O[t];
	return Object.keys(e).filter((t) => {
		let i = e[t];
		return i.terrain !== "castle" && i.crowns === 0 && i.court === void 0 && (!i.resource || n.includes(t)) && (r.kind === "character" || r.terrain === i.terrain);
	});
}
function U(e, t, n) {
	let r = e.board, i = /* @__PURE__ */ new Set(), a = [];
	for (let e of Object.keys(r)) {
		if (i.has(e) || r[e].terrain === "castle") continue;
		let t = r[e].terrain, n = [e];
		i.add(e);
		for (let e = 0; e < n.length; e++) {
			let [a, o] = F(n[e]);
			for (let [e, s] of N) {
				let c = P(a + e, o + s);
				r[c]?.terrain === t && !i.has(c) && (i.add(c), n.push(c));
			}
		}
		let o = n.reduce((e, t) => e + R(r[t]), 0);
		a.push({
			terrain: t,
			keys: n,
			area: n.length,
			crowns: o,
			score: n.length * o
		});
	}
	let o = 0;
	for (let [e, t] of Object.entries(r)) {
		if (t.court === void 0) continue;
		let n = O[t.court];
		if (n.kind !== "character") continue;
		let [i, a] = F(e), s = Object.entries(r).filter(([t]) => {
			let [n, r] = F(t);
			return t !== e && Math.abs(n - i) <= 1 && Math.abs(r - a) <= 1;
		}).map(([, e]) => e), c;
		c = n.condition === "resource" ? s.filter((e) => e.resource).length : n.condition === "crowns" ? s.reduce((e, t) => e + R(t), 0) : n.condition === "character" ? s.filter((e) => e.court !== void 0 && O[e.court].kind === "character").length : n.condition === "warrior" ? s.filter((e) => e.court !== void 0 && O[e.court].warrior).length : s.filter((e) => e.resource === n.condition).length, o += n.base + c * (n.amount ?? 0);
	}
	let s = e.frame ?? V(r, t)[0], c = [
		[s.x, s.y],
		[s.x + t - 1, s.y],
		[s.x, s.y + t - 1],
		[s.x + t - 1, s.y + t - 1]
	], l = n.map((n) => {
		let i = 0;
		if (n === "harmony") i = Object.keys(r).length === t * t && !e.discarded.length ? 5 : 0;
		else if (n === "middle") i = s.x === -(t - 1) / 2 && s.y === -(t - 1) / 2 ? 10 : 0;
		else if (n === "corner") i = c.some(([e, t]) => e === 0 && t === 0) ? 20 : 0;
		else if (n.startsWith("local:")) i = Object.entries(r).filter(([e, t]) => {
			let [r, i] = F(e);
			return Math.abs(r) <= 1 && Math.abs(i) <= 1 && t.terrain === n.slice(6);
		}).length * 5;
		else if (n.startsWith("corners:")) i = c.filter(([e, t]) => r[P(e, t)]?.terrain === n.slice(8)).length * 5;
		else if (n === "bleak") i = a.filter((e) => [
			"wheat",
			"forest",
			"lake",
			"grass"
		].includes(e.terrain) && e.area === 5 && e.crowns === 0).length * 10;
		else if (n === "lines") {
			for (let [e, t] of Object.entries(r)) if (R(t) > 0) {
				let [t, n] = F(e);
				for (let [e, a] of [
					[1, 0],
					[0, 1],
					[1, 1],
					[1, -1]
				]) {
					if (r[P(t - e, n - a)] && R(r[P(t - e, n - a)]) > 0) continue;
					let o = 0;
					for (; r[P(t + o * e, n + o * a)] && R(r[P(t + o * e, n + o * a)]) > 0;) o++;
					o >= 3 && (i += 10);
				}
			}
		}
		return {
			quest: n,
			score: i
		};
	});
	return {
		total: a.reduce((e, t) => e + t.score, o) + l.reduce((e, t) => e + t.score, 0),
		regions: a,
		court: o,
		bonuses: l,
		largest: Math.max(0, ...a.map((e) => e.area)),
		crowns: a.reduce((e, t) => e + t.crowns, 0)
	};
}
//#endregion
//#region src/games/kingdomino/meta.ts
var W = {
	id: "kingdomino",
	tier: "alpha",
	nameKey: "games.kingdomino.name",
	descKey: "games.kingdomino.desc",
	rulesKey: "games.kingdomino.rules",
	mechanics: ["drafting", "tile-placement"],
	interactionTags: ["team-based"],
	icon: "🏰",
	iconImg: "games/kingdomino.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [
		2,
		3,
		4
	],
	playerRange(e) {
		let t = e, n = t?.teamCount === 4 ? 8 : 6;
		return t?.mode === "teams" ? {
			min: n,
			max: n
		} : t?.mode === "large" ? {
			min: 3,
			max: 4
		} : t?.mode === "duel" ? {
			min: 2,
			max: 2
		} : {
			min: 2,
			max: t?.giants ? 5 : 4
		};
	},
	accent: "#a47221",
	releasedAt: "2026-10-31T12:40:00+08:00",
	search: {
		py: "duo mi nuo wang guo",
		init: "dmnwg"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/998053608226003267/B5C8108C4FE84B2EC66DC530B629206EDE15954C/" }
}, G = t.object({
	mode: t.enum([
		"standard",
		"duel",
		"large",
		"teams"
	]).default("standard"),
	teamCount: t.union([t.literal(3), t.literal(4)]).default(3),
	giants: t.boolean().default(!1),
	court: t.boolean().default(!1),
	harmony: t.boolean().default(!1),
	middle: t.boolean().default(!1)
}).default({
	mode: "standard",
	teamCount: 3,
	giants: !1,
	court: !1,
	harmony: !1,
	middle: !1
}), K = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		index: t.int().min(0).max(7)
	}),
	t.object({
		type: t.literal("place"),
		x: t.int().min(-6).max(6),
		y: t.int().min(-6).max(6),
		dir: t.int().min(0).max(3)
	}),
	t.object({ type: t.literal("discard") }),
	t.object({
		type: t.literal("cover"),
		key: t.string().max(10)
	}),
	t.object({
		type: t.literal("sendGiant"),
		key: t.string().max(10),
		target: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("buy"),
		card: t.int().min(0).max(24),
		pay: t.array(t.string().max(10)).length(2),
		key: t.string().max(10)
	}),
	t.object({
		type: t.literal("search"),
		pay: t.array(t.string().max(10)).length(4)
	}),
	t.object({
		type: t.literal("recruit"),
		card: t.int().min(0).max(24),
		key: t.string().max(10)
	}),
	t.object({ type: t.literal("skip") }),
	t.object({
		type: t.literal("frame"),
		x: t.int().min(-6).max(0),
		y: t.int().min(-6).max(0)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), q = t.object({
	terrain: t.enum([
		"castle",
		"wheat",
		"forest",
		"lake",
		"grass",
		"swamp",
		"mine"
	]),
	crowns: t.int().min(0).max(3),
	tile: t.int(),
	half: t.int().min(0).max(1),
	giants: t.int().min(0).max(3),
	resource: t.enum([
		"wheat",
		"wood",
		"fish",
		"sheep"
	]).optional(),
	court: t.int().min(0).max(24).optional()
}), J = t.object({
	rids: t.array(t.string()),
	board: t.record(t.string(), q),
	discarded: t.array(t.int()),
	frame: t.object({
		x: t.int(),
		y: t.int()
	}).nullable()
}), ae = t.object({
	id: t.int(),
	rid: t.string().nullable(),
	placed: t.boolean()
}), Y = t.object({
	config: G,
	players: t.array(t.string()),
	kingdoms: t.array(J),
	size: t.int(),
	phase: t.enum([
		"chooseFirst",
		"refill",
		"place",
		"chooseNext",
		"giantSend",
		"giantCover",
		"court",
		"search",
		"frame",
		"done"
	]),
	active: t.string(),
	turn: t.int(),
	round: t.int(),
	rounds: t.int(),
	row: t.array(ae),
	next: t.array(ae),
	market: t.array(t.int()),
	courtLeft: t.int(),
	quests: t.array(t.string()),
	supply: t.int(),
	coverTarget: t.int().nullable(),
	pending: t.int().nullable(),
	frameIndex: t.int(),
	scores: t.array(t.object({
		total: t.number(),
		regions: t.array(t.object({
			terrain: t.string(),
			keys: t.array(t.string()),
			area: t.int(),
			crowns: t.int(),
			score: t.int()
		})),
		court: t.int(),
		bonuses: t.array(t.object({
			quest: t.string(),
			score: t.int()
		})),
		largest: t.int(),
		crowns: t.int()
	}))
}), oe = t.object({ court: t.array(t.int()) }), X = (e, t) => e.kingdoms.findIndex((e) => e.rids.includes(t));
function Z(e) {
	return e.phase === "done" || e.phase === "refill" ? "" : e.phase === "chooseFirst" ? e.initialOrder[e.initialIndex] : e.phase === "giantCover" ? e.kingdoms[e.coverTarget].rids[0] : e.phase === "frame" ? e.kingdoms[e.frameIndex].rids[0] : e.row[e.turn].rid;
}
function Q(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function se(e) {
	let t = e.config.giants ? 5 : e.initialOrder.length;
	return e.decks[(e.round - 1) % e.decks.length].splice(0, t).sort((e, t) => I(e) - I(t)).filter((t, n) => !e.config.giants || (e.players.length === 3 ? n !== 1 && n !== 3 : e.players.length === 5 || n !== 2)).map((e) => ({
		id: e,
		rid: null,
		placed: !1
	}));
}
function ce(e) {
	return e.quests.some((e) => e === "middle" || e === "corner" || e.startsWith("corners:"));
}
function le(e) {
	if (e.frameIndex = 0, e.phase = ce(e) ? "frame" : "done", !ce(e)) for (let t of e.kingdoms) t.frame = V(t.board, e.size)[0];
}
function ue(e) {
	e.turn++, e.turn < e.row.length ? e.phase = "place" : e.next.length ? e.phase = "refill" : le(e);
}
function de(e) {
	ue(e);
}
function fe(e) {
	e.coverTarget = null, e.next.length ? e.phase = "chooseNext" : e.config.court ? e.phase = "court" : ue(e);
}
function pe(e, t, n) {
	let r = G.parse(e);
	if ((r.mode === "large" || r.mode === "teams") && (r.giants = !1, r.court = !1), r.giants && (r.middle = !1, r.harmony = !1), !(r.mode === "teams" ? t.length === r.teamCount * 2 : r.mode === "large" ? [3, 4].includes(t.length) : r.mode === "duel" ? t.length === 2 : t.length >= 2 && t.length <= (r.giants ? 5 : 4))) throw Error("Unsupported Kingdomino player count");
	let i = [];
	for (let e = 0; e < t.length; e += r.mode === "teams" ? 2 : 1) i.push({
		rids: t.slice(e, e + (r.mode === "teams" ? 2 : 1)),
		board: { "0,0": {
			terrain: "castle",
			crowns: 0,
			tile: 0,
			half: 0,
			giants: 0
		} },
		discarded: [],
		frame: null
	});
	let a = {
		config: r,
		players: [...t],
		kingdoms: i,
		size: r.mode === "standard" ? 5 : 7,
		phase: "chooseFirst",
		turn: 0,
		round: 1,
		rounds: r.mode === "large" ? 24 : r.mode === "duel" || t.length > 2 ? 12 : 6,
		row: [],
		next: [],
		market: [],
		quests: [],
		supply: 6,
		coverTarget: null,
		frameIndex: 0,
		seed: n,
		cursor: 0,
		decks: [],
		courtDeck: [],
		initialOrder: [],
		initialIndex: 0
	}, o = D.filter((e) => r.giants || e.id > 0 && e.id <= 48).map((e) => e.id);
	return a.decks = r.mode === "standard" || r.mode === "duel" ? [Q(a, o).slice(0, r.giants ? 60 : r.mode === "duel" ? 48 : t.length === 2 ? 24 : t.length === 3 ? 36 : 48)] : [0, 1].map((e) => Q(a, o).slice(0, (r.mode === "teams" ? t.length / 2 : t.length) === 3 ? 36 : 48).map((t) => t + e * 100)), a.initialOrder = Q(a, t.length === 2 ? t.flatMap((e) => [e, e]) : [...t]), a.row = se(a), r.court && (a.courtDeck = Q(a, O.map((e) => e.id)), a.market = a.courtDeck.splice(0, 3)), a.quests = r.giants ? Q(a, j).slice(0, 2) : [...r.harmony ? ["harmony"] : [], ...r.middle ? ["middle"] : []], { state: a };
}
var $ = () => ({ code: "games.kingdomino.errAction" }), me = {
	meta: W,
	saveCompatibility: { version: "1" },
	schemas: {
		action: K,
		config: G,
		publicView: Y,
		privateView: oe
	},
	setup: pe,
	reduce(e, t, n) {
		if (t.type === "tick") {
			if (n.by !== "$engine" || e.phase !== "refill") return { state: e };
			let t = structuredClone(e);
			t.next.length && (t.row = t.next, t.round++);
			let r = t.round;
			for (t.round++, t.next = r < t.rounds ? se(t) : [], t.round = r; t.market.length < 3 && t.courtDeck.length && t.config.court;) t.market.push(t.courtDeck.shift());
			return t.turn = 0, t.phase = "place", {
				state: t,
				fx: [{
					kind: "reveal",
					data: { ids: t.next.map((e) => e.id) }
				}]
			};
		}
		if (n.by !== Z(e)) return { code: "games.kingdomino.errTurn" };
		let r = structuredClone(e), i = X(r, n.by), a = r.kingdoms[i], o = a.board;
		if (t.type === "choose" && (r.phase === "chooseFirst" || r.phase === "chooseNext")) {
			let e = (r.phase === "chooseFirst" ? r.row : r.next)[t.index];
			return !e || e.rid ? $() : (e.rid = n.by, r.phase === "chooseFirst" ? (r.initialIndex++, r.initialIndex === r.initialOrder.length && (r.phase = "refill")) : r.config.court ? r.phase = "court" : ue(r), {
				state: r,
				fx: [{
					kind: "claim",
					rid: n.by,
					data: {
						id: e.id,
						kingdom: i
					}
				}]
			});
		}
		if ((t.type === "place" || t.type === "discard") && r.phase === "place") {
			let e = r.row[r.turn], s = e.id;
			if (t.type === "discard") return B(o, s, r.size).length ? { code: "games.kingdomino.errDiscard" } : (a.discarded.push(s), e.placed = !0, fe(r), {
				state: r,
				fx: [{
					kind: "discard",
					rid: n.by,
					data: { id: s }
				}]
			});
			if (!z(o, s, r.size, t.x, t.y, t.dir)) return { code: "games.kingdomino.errPlace" };
			let [c, l] = N[t.dir];
			return k(I(s)).halves.forEach((e, n) => {
				o[P(t.x + n * c, t.y + n * l)] = {
					...e,
					tile: s,
					half: n,
					giants: 0,
					...r.config.court && e.crowns === 0 && A(e.terrain) ? { resource: A(e.terrain) } : {}
				};
			}), e.placed = !0, s < 0 && r.supply > 0 && Object.values(o).some((e) => R(e) > 0) ? (r.supply--, r.coverTarget = i, r.phase = "giantCover") : I(s) >= 49 && Object.values(o).some((e) => e.giants > 0) && r.kingdoms.some((e, t) => t !== i && Object.values(e.board).some((e) => R(e) > 0)) ? r.phase = "giantSend" : fe(r), {
				state: r,
				fx: [{
					kind: "place",
					rid: n.by,
					data: {
						id: s,
						x: t.x,
						y: t.y,
						dir: t.dir,
						kingdom: i
					}
				}]
			};
		}
		if (t.type === "cover" && r.phase === "giantCover") {
			let e = r.kingdoms[r.coverTarget].board[t.key];
			if (!e || R(e) <= 0) return $();
			e.giants++;
			let i = r.coverTarget;
			return fe(r), {
				state: r,
				fx: [{
					kind: "giant",
					rid: n.by,
					data: {
						key: t.key,
						kingdom: i
					}
				}]
			};
		}
		if (t.type === "sendGiant" && r.phase === "giantSend") {
			let e = r.kingdoms[t.target];
			return !o[t.key]?.giants || !e || t.target === i || !Object.values(e.board).some((e) => R(e) > 0) ? $() : (o[t.key].giants--, r.coverTarget = t.target, r.phase = "giantCover", {
				state: r,
				fx: [{
					kind: "sendGiant",
					rid: n.by,
					data: {
						key: t.key,
						source: i,
						target: t.target
					}
				}]
			});
		}
		if ((t.type === "buy" || t.type === "search") && r.phase === "court") {
			let e = t.pay.map((e) => o[e]?.resource);
			if (e.some((e) => !e) || new Set(e).size !== t.pay.length) return $();
			if (t.type === "search") {
				if (!r.courtDeck.length || !r.courtDeck.some((e) => H(o, e, t.pay).length)) return $();
				let e = t.pay.map((e) => ({
					key: e,
					resource: o[e].resource
				}));
				return t.pay.forEach((e) => {
					delete o[e].resource;
				}), r.phase = "search", {
					state: r,
					fx: [{
						kind: "pay",
						rid: n.by,
						data: {
							paid: e,
							kingdom: i
						}
					}]
				};
			}
			if (!r.market.includes(t.card) || !H(o, t.card, t.pay).includes(t.key)) return $();
			let a = t.pay.map((e) => ({
				key: e,
				resource: o[e].resource
			}));
			return t.pay.forEach((e) => {
				delete o[e].resource;
			}), o[t.key].court = t.card, r.market = r.market.filter((e) => e !== t.card), de(r), {
				state: r,
				fx: [{
					kind: "recruit",
					rid: n.by,
					data: {
						key: t.key,
						card: t.card,
						kingdom: i,
						paid: a
					}
				}]
			};
		}
		return t.type === "recruit" && r.phase === "search" ? !r.courtDeck.includes(t.card) || !H(o, t.card).includes(t.key) ? $() : (o[t.key].court = t.card, r.courtDeck = Q(r, r.courtDeck.filter((e) => e !== t.card)), de(r), {
			state: r,
			fx: [{
				kind: "recruit",
				rid: n.by,
				data: {
					key: t.key,
					card: t.card,
					kingdom: i
				}
			}]
		}) : t.type === "skip" && (r.phase === "court" || r.phase === "giantSend") ? (r.phase === "court" ? de(r) : fe(r), { state: r }) : t.type === "frame" && r.phase === "frame" && V(o, r.size).some((e) => e.x === t.x && e.y === t.y) ? (a.frame = {
			x: t.x,
			y: t.y
		}, r.frameIndex++, r.frameIndex === r.kingdoms.length && (r.phase = "done"), {
			state: r,
			fx: [{
				kind: "frame",
				rid: n.by
			}]
		}) : $();
	},
	viewFor(e, t) {
		return {
			public: {
				config: e.config,
				players: e.players,
				kingdoms: e.kingdoms,
				size: e.size,
				phase: e.phase,
				active: Z(e),
				turn: e.turn,
				round: e.round,
				rounds: e.rounds,
				row: e.row,
				next: e.next,
				market: e.market,
				courtLeft: e.courtDeck.length,
				quests: e.quests,
				supply: e.supply,
				coverTarget: e.coverTarget,
				pending: e.phase === "place" ? e.row[e.turn].id : null,
				frameIndex: e.frameIndex,
				scores: e.kingdoms.map((t) => U(t, e.size, e.quests))
			},
			private: { court: e.phase === "search" && Z(e) === t ? [...e.courtDeck].sort((e, t) => e - t) : [] }
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.kingdoms.map((t) => U(t, e.size, e.quests)), n = e.kingdoms.map((e, t) => t).sort((e, n) => t[n].total - t[e].total || t[n].largest - t[e].largest || t[n].crowns - t[e].crowns), r = t[n[0]];
		return {
			phase: "done",
			winner: n.filter((e) => t[e].total === r.total && t[e].largest === r.largest && t[e].crowns === r.crowns).flatMap((t) => e.kingdoms[t].rids),
			ranking: n.flatMap((t) => e.kingdoms[t].rids),
			scores: Object.fromEntries(e.kingdoms.flatMap((e, n) => e.rids.map((e) => [e, t[n].total])))
		};
	},
	nextTickIn: (e) => e.phase === "refill" ? 650 : null
}, he = {
	wheat: "games.kingdomino.wheat",
	forest: "games.kingdomino.forest",
	lake: "games.kingdomino.lake",
	grass: "games.kingdomino.grass",
	swamp: "games.kingdomino.swamp",
	mine: "games.kingdomino.mine",
	castle: "games.kingdomino.castle"
}, ge = {
	wheat: "games.kingdomino.resourceWheat",
	wood: "games.kingdomino.wood",
	fish: "games.kingdomino.fish",
	sheep: "games.kingdomino.sheep"
}, _e = {
	2: "games.kingdomino.farmer",
	4: "games.kingdomino.merchant",
	7: "games.kingdomino.lumberjack",
	9: "games.kingdomino.warrior",
	12: "games.kingdomino.fisherman",
	14: "games.kingdomino.warrior",
	17: "games.kingdomino.shepherd",
	18: "games.kingdomino.captain",
	19: "games.kingdomino.warrior",
	22: "games.kingdomino.king",
	23: "games.kingdomino.queen",
	24: "games.kingdomino.warrior"
};
function ve(e, t) {
	let n = O[e], r = t(_e[e] ?? "games.kingdomino.building"), i = t("games.kingdomino.buildingRule", { n: n.crowns });
	return n.kind === "character" && (i = n.condition === "resource" ? t("games.kingdomino.merchantRule") : n.condition === "warrior" ? t("games.kingdomino.captainRule") : n.condition === "crowns" ? t("games.kingdomino.kingRule") : n.condition === "character" ? t("games.kingdomino.queenRule") : n.condition === "none" ? t("games.kingdomino.warriorRule", { n: n.base }) : t("games.kingdomino.resourceRule", {
		base: n.base,
		n: n.amount ?? 0,
		resource: t(ge[n.condition])
	})), t("games.kingdomino.courtTile", {
		name: r,
		rule: i
	});
}
function ye(e, t) {
	let n = {
		harmony: "games.kingdomino.harmony",
		middle: "games.kingdomino.middle",
		corner: "games.kingdomino.corner",
		lines: "games.kingdomino.lines",
		bleak: "games.kingdomino.bleak"
	};
	if (n[e]) return t(n[e]);
	let [r, i] = e.split(":");
	return t(r === "local" ? "games.kingdomino.localQuest" : "games.kingdomino.cornerQuest", { terrain: t(he[i]) });
}
function be({ x: e = 0, y: t = 0, covered: n = !1 }) {
	return /* @__PURE__ */ v("image", {
		href: "games/kingdomino/icon-crown.svg",
		x: e,
		y: t,
		width: "30",
		height: "28",
		opacity: n ? .28 : 1
	});
}
function xe({ x: e = 0, y: t = 0 }) {
	return /* @__PURE__ */ v("image", {
		href: "games/kingdomino/icon-giant.svg",
		x: e,
		y: t,
		width: "32",
		height: "50"
	});
}
function Se() {
	return /* @__PURE__ */ v("img", {
		src: "games/kingdomino/icon-king.svg",
		className: "kd-king-image",
		alt: ""
	});
}
function Ce() {
	return /* @__PURE__ */ y("g", { children: [
		/* @__PURE__ */ v("rect", {
			width: "100",
			height: "100",
			fill: "#a9ba72"
		}),
		/* @__PURE__ */ v("path", {
			d: "M0 22 22 12 42 22 62 9 100 25V100H0Z",
			fill: "#bccc85"
		}),
		/* @__PURE__ */ v("path", {
			d: "M14 79 14 35 36 35 36 50 63 50 63 28 86 28 86 79Z",
			fill: "#f5d79a",
			stroke: "#735633",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ v("path", {
			d: "M8 35 25 12 42 35ZM58 28 74 5 92 28Z",
			fill: "#c95736",
			stroke: "#735633",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ v("path", {
			d: "M28 78V61Q38 47 48 61V78",
			fill: "#77512f"
		}),
		/* @__PURE__ */ v("path", {
			d: "M52 78V67H63V78M20 43H28V53H20M70 37H78V47H70",
			fill: "#6e8d8b"
		}),
		/* @__PURE__ */ v("path", {
			d: "M9 84H91M48 89H72M20 93H35",
			stroke: "#e0d7a1",
			strokeWidth: "3"
		})
	] });
}
function we({ cell: e, hideCourt: t = !1, hideGiants: n = !1 }) {
	if (e.terrain === "castle") return /* @__PURE__ */ v(Ce, {});
	let r = e.crowns + (e.court === void 0 ? 0 : O[e.court].crowns);
	return /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ v("svg", {
			viewBox: `${e.half * 120} 0 120 120`,
			width: "100",
			height: "100",
			children: /* @__PURE__ */ v("image", {
				href: `games/kingdomino/tile-${I(e.tile)}.svg`,
				width: "240",
				height: "120"
			})
		}),
		e.court !== void 0 && /* @__PURE__ */ v("image", {
			href: `games/kingdomino/court-${e.court}.svg`,
			width: "100",
			height: "100",
			visibility: t ? "hidden" : void 0
		}),
		Array.from({ length: r }, (t, n) => /* @__PURE__ */ v(be, {
			x: 4 + n * 29,
			y: 5,
			covered: n >= R(e)
		}, n)),
		e.giants > 0 && Array.from({ length: e.giants }, (t, r) => /* @__PURE__ */ v("g", {
			visibility: n && r === e.giants - 1 ? "hidden" : void 0,
			children: /* @__PURE__ */ v(xe, {
				x: 8 + r * 24,
				y: 8
			})
		}, r)),
		e.resource && /* @__PURE__ */ v("image", {
			href: `games/kingdomino/icon-${e.resource}.svg`,
			x: "59",
			y: "60",
			width: "38",
			height: "38"
		})
	] });
}
function Te({ id: e }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 200 100",
		className: "kd-domino-art",
		"aria-hidden": !0,
		children: [
			k(I(e)).halves.map((t, n) => /* @__PURE__ */ v("g", {
				transform: `translate(${n * 100} 0)`,
				children: /* @__PURE__ */ v(we, { cell: {
					...t,
					tile: e,
					half: n,
					giants: 0
				} })
			}, n)),
			/* @__PURE__ */ v("path", {
				d: "M100 0V100",
				stroke: "#5c5839",
				opacity: ".3"
			}),
			/* @__PURE__ */ v("rect", {
				x: "80",
				y: "75",
				width: "40",
				height: "25",
				rx: "5",
				fill: "#fff3cc",
				stroke: "#6a5235"
			}),
			/* @__PURE__ */ v("text", {
				x: "100",
				y: "93",
				textAnchor: "middle",
				fontSize: "19",
				fontWeight: "800",
				fill: "#443827",
				children: M(e)
			})
		]
	});
}
//#endregion
//#region src/games/kingdomino/kingdom-board.tsx
function Ee({ name: e, r: t }) {
	let r = l(), i = n((t) => {
		r?.registerProbe(e, t ? () => {
			let e = t.getBoundingClientRect();
			return {
				x: e.left,
				y: e.top,
				w: e.width,
				h: e.height
			};
		} : null);
	}, [r, e]);
	return /* @__PURE__ */ v("rect", {
		ref: i,
		x: t.x,
		y: t.y,
		width: t.w,
		height: t.h,
		fill: "none",
		pointerEvents: "none"
	});
}
function De({ cell: e, cellKey: t, kingdomIndex: n, label: r }) {
	let i = `kd-cell:${n}:${t}`, { hidden: a } = c(i), o = `kd-court:${n}:${t}`, { hidden: s } = c(o), [l, u] = F(t), d = `kd-giant:${n}:${t}`, { hidden: f } = c(d);
	return /* @__PURE__ */ y("g", {
		transform: `translate(${l * 100} ${u * 100})`,
		"aria-label": r,
		visibility: a ? "hidden" : void 0,
		children: [
			/* @__PURE__ */ v(we, {
				cell: e,
				hideCourt: s,
				hideGiants: f
			}),
			/* @__PURE__ */ v("rect", {
				width: "100",
				height: "100",
				fill: "none",
				stroke: "#655b35",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v(Ee, {
				name: i,
				r: {
					x: 0,
					y: 0,
					w: 100,
					h: 100
				}
			}),
			/* @__PURE__ */ v(Ee, {
				name: o,
				r: {
					x: 0,
					y: 0,
					w: 100,
					h: 100
				}
			}),
			/* @__PURE__ */ v(Ee, {
				name: d,
				r: {
					x: 8 + Math.max(0, e.giants - 1) * 24,
					y: 8,
					w: 32,
					h: 50
				}
			})
		]
	});
}
function Oe({ board: e, size: t, kingdomIndex: n, eligible: i, selected: c = [], onTap: l, preview: u, pending: p, onRotate: te, onSwap: re, onConfirm: ie, onCancel: _, frame: b, readOnly: x = !1 }) {
	let S = s(), C = a(null), [w, T] = o({
		w: 1,
		h: 1
	}), [E, D] = o({
		x: 0,
		y: 0,
		z: 1
	}), [O, A] = o(""), j = a(/* @__PURE__ */ new Map()), M = a(!1), z = a(null), B = a({
		x: 0,
		y: 0
	}), V = L(e), H = Math.min(w.w / ((Math.max(t, V.maxX - V.minX + 1) + 1.4) * 100), w.h / ((Math.max(t, V.maxY - V.minY + 1) + 1.4) * 100));
	r(() => {
		let e = C.current, t = new ResizeObserver(() => T({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let U = `${n}:${w.w}:${w.h}`;
	O !== U && w.w > 1 && (A(U), D({
		x: (V.minX + V.maxX + 1) * 50,
		y: (V.minY + V.maxY + 1) * 50,
		z: H
	}));
	let W = (e) => ({
		x: Math.max(-t * 100, Math.min(t * 100, e.x)),
		y: Math.max(-t * 100, Math.min(t * 100, e.y)),
		z: Math.max(H * .65, Math.min(H * 4, e.z))
	}), G = (e, t = w.w / 2, n = w.h / 2) => D((r) => {
		let i = W({
			...r,
			z: r.z * e
		}).z;
		return W({
			z: i,
			x: r.x + (t - w.w / 2) * (1 / r.z - 1 / i),
			y: r.y + (n - w.h / 2) * (1 / r.z - 1 / i)
		});
	}), K = () => {
		let e = [...j.current.values()];
		return {
			x: e.reduce((e, t) => e + t.x, 0) / e.length,
			y: e.reduce((e, t) => e + t.y, 0) / e.length,
			distance: e.length > 1 ? Math.hypot(e[0].x - e[1].x, e[0].y - e[1].y) : 0
		};
	}, q = (e) => {
		e.currentTarget.setPointerCapture(e.pointerId), j.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), j.current.size === 1 ? (M.current = !1, B.current = {
			x: e.clientX,
			y: e.clientY
		}) : M.current = !0, z.current = K();
	}, J = (e) => {
		if (!j.current.has(e.pointerId)) return;
		j.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
		let t = K(), n = z.current;
		if (n && (M.current || Math.hypot(e.clientX - B.current.x, e.clientY - B.current.y) > 6)) {
			M.current = !0;
			let e = C.current.getBoundingClientRect(), r = t.x - e.left, i = t.y - e.top;
			D((e) => {
				let a = n.distance && t.distance ? W({
					...e,
					z: e.z * t.distance / n.distance
				}).z : e.z;
				return W({
					z: a,
					x: e.x - (t.x - n.x) / e.z + (r - w.w / 2) * (1 / e.z - 1 / a),
					y: e.y - (t.y - n.y) / e.z + (i - w.h / 2) * (1 / e.z - 1 / a)
				});
			});
		}
		z.current = t;
	}, ae = (e) => {
		j.current.delete(e.pointerId), z.current = j.current.size ? K() : null;
	}, Y = E.x - w.w / (2 * E.z), oe = E.y - w.h / (2 * E.z), X = new Set(i), Z = u ? [P(u.x, u.y), P(u.x + N[u.dir][0], u.y + N[u.dir][1])] : [], Q = u ? (u.x * 100 - Y) * E.z : 0, se = u ? (u.y * 100 - oe) * E.z : 0;
	return /* @__PURE__ */ y("div", {
		ref: C,
		className: "kd-board-viewport",
		"data-kd-board": !0,
		children: [
			/* @__PURE__ */ y("svg", {
				className: "kd-board-svg",
				viewBox: `${Y} ${oe} ${w.w / E.z} ${w.h / E.z}`,
				onPointerDown: q,
				onPointerMove: J,
				onPointerUp: ae,
				onPointerCancel: (e) => {
					M.current = !0, ae(e);
				},
				onClick: (e) => {
					if (M.current || x) return;
					let t = e.currentTarget.getBoundingClientRect(), n = P(Math.floor((Y + (e.clientX - t.left) / E.z) / 100), Math.floor((oe + (e.clientY - t.top) / E.z) / 100));
					X.has(n) && l(n);
				},
				onWheel: (e) => {
					e.preventDefault();
					let t = e.currentTarget.getBoundingClientRect();
					G(Math.exp(-e.deltaY * .002), e.clientX - t.left, e.clientY - t.top);
				},
				children: [
					/* @__PURE__ */ v("defs", { children: /* @__PURE__ */ y("pattern", {
						id: `kd-grid-${n}`,
						width: "100",
						height: "100",
						patternUnits: "userSpaceOnUse",
						children: [/* @__PURE__ */ v("rect", {
							x: "1",
							y: "1",
							width: "98",
							height: "98",
							fill: "#b8c896",
							stroke: "#8fa16b",
							strokeWidth: "1"
						}), /* @__PURE__ */ v("path", {
							d: "M5 5H18M5 5V18M95 95H82M95 95V82",
							stroke: "#dce3bc",
							strokeWidth: "2"
						})]
					}) }),
					/* @__PURE__ */ v("rect", {
						x: (1 - t) * 100,
						y: (1 - t) * 100,
						width: (t * 2 - 1) * 100,
						height: (t * 2 - 1) * 100,
						fill: `url(#kd-grid-${n})`
					}),
					Object.entries(e).map(([e, t]) => {
						let [r, i] = F(e);
						return /* @__PURE__ */ v(De, {
							cell: t,
							cellKey: e,
							kingdomIndex: n,
							label: S("games.kingdomino.cell", {
								x: r,
								y: i,
								terrain: S(he[t.terrain]),
								n: R(t)
							})
						}, e);
					}),
					u && p !== null && k(I(p)).halves.map((e, t) => /* @__PURE__ */ y("g", {
						opacity: ".86",
						transform: `translate(${(u.x + t * N[u.dir][0]) * 100} ${(u.y + t * N[u.dir][1]) * 100})`,
						children: [/* @__PURE__ */ v(we, { cell: {
							...e,
							tile: p,
							half: t,
							giants: 0
						} }), /* @__PURE__ */ v("rect", {
							x: "3",
							y: "3",
							width: "94",
							height: "94",
							rx: "5",
							fill: "none",
							stroke: "#fffbea",
							strokeWidth: "6"
						})]
					}, t)),
					i.map((t) => {
						let [n, r] = F(t);
						return /* @__PURE__ */ y("g", {
							className: "kd-legal",
							transform: `translate(${n * 100} ${r * 100})`,
							children: [
								/* @__PURE__ */ v("rect", {
									x: "5",
									y: "5",
									width: "90",
									height: "90",
									rx: "7",
									fill: "#ffffff",
									fillOpacity: Z.includes(t) ? .05 : .22,
									stroke: "#fff",
									strokeWidth: "5"
								}),
								/* @__PURE__ */ v("rect", {
									x: "7",
									y: "7",
									width: "86",
									height: "86",
									rx: "6",
									fill: "none",
									stroke: "#344c36",
									strokeWidth: "2.6",
									strokeDasharray: "12 8",
									children: /* @__PURE__ */ v("animate", {
										attributeName: "stroke-dashoffset",
										from: "0",
										to: "-20",
										dur: ".8s",
										repeatCount: "indefinite"
									})
								}),
								/* @__PURE__ */ v("rect", {
									x: "4",
									y: "4",
									width: "92",
									height: "92",
									fill: "transparent",
									tabIndex: 0,
									role: "button",
									"aria-label": e[t] ? S("games.kingdomino.cell", {
										x: n,
										y: r,
										terrain: S(he[e[t].terrain]),
										n: R(e[t])
									}) : S("games.kingdomino.emptyCell", {
										x: n,
										y: r
									}),
									onKeyDown: (e) => {
										(e.key === "Enter" || e.key === " ") && (e.preventDefault(), l(t));
									}
								})
							]
						}, t);
					}),
					b && /* @__PURE__ */ v("rect", {
						x: b.x * 100 - 3,
						y: b.y * 100 - 3,
						width: t * 100 + 6,
						height: t * 100 + 6,
						rx: "8",
						fill: "none",
						stroke: "#fff0ad",
						strokeWidth: "10",
						strokeDasharray: "25 8",
						pointerEvents: "none"
					}),
					c.map((e) => {
						let [t, n] = F(e);
						return /* @__PURE__ */ v("rect", {
							x: t * 100 + 4,
							y: n * 100 + 4,
							width: "92",
							height: "92",
							rx: "5",
							fill: "#d8f4ff",
							fillOpacity: ".25",
							stroke: "#187fa5",
							strokeWidth: "7",
							pointerEvents: "none"
						}, e);
					})
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "kd-view-tools",
				children: [
					/* @__PURE__ */ v("button", {
						onClick: () => G(.8),
						"aria-label": S("games.kingdomino.zoomOut"),
						children: /* @__PURE__ */ v(ne, {})
					}),
					/* @__PURE__ */ v("button", {
						onClick: () => G(1.25),
						"aria-label": S("games.kingdomino.zoomIn"),
						children: /* @__PURE__ */ v(g, {})
					}),
					/* @__PURE__ */ v("button", {
						onClick: () => D({
							x: (V.minX + V.maxX + 1) * 50,
							y: (V.minY + V.maxY + 1) * 50,
							z: H
						}),
						"aria-label": S("games.kingdomino.fit"),
						children: /* @__PURE__ */ v(ee, {})
					})
				]
			}),
			u && ie && /* @__PURE__ */ y("div", {
				className: "kd-place-tools",
				style: {
					left: Math.max(8, Math.min(w.w - 172, Q - 34)),
					top: Math.max(48, Math.min(w.h - 48, se + (N[u.dir][1] > 0 ? 200 : 100) * E.z + 6))
				},
				children: [
					/* @__PURE__ */ v("button", {
						onClick: te,
						"aria-label": S("games.kingdomino.rotate"),
						children: /* @__PURE__ */ v(h, {})
					}),
					/* @__PURE__ */ v("button", {
						onClick: re,
						"aria-label": S("games.kingdomino.swap"),
						children: /* @__PURE__ */ v(m, {})
					}),
					/* @__PURE__ */ v("button", {
						onClick: ie,
						className: "kd-confirm",
						"aria-label": S("games.kingdomino.confirm"),
						children: /* @__PURE__ */ v(d, {})
					}),
					/* @__PURE__ */ v("button", {
						onClick: _,
						"aria-label": S("games.kingdomino.cancel"),
						children: /* @__PURE__ */ v(f, {})
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/kingdomino/view-player.tsx
var ke = {
	chooseFirst: "games.kingdomino.chooseFirst",
	chooseNext: "games.kingdomino.chooseNext",
	place: "games.kingdomino.place",
	giantCover: "games.kingdomino.giantCover",
	giantSend: "games.kingdomino.giantSend",
	court: "games.kingdomino.courtPrompt",
	search: "games.kingdomino.searchPrompt",
	frame: "games.kingdomino.framePrompt",
	refill: "games.kingdomino.refill",
	done: "games.kingdomino.done"
};
function Ae({ index: e, selected: t, onClick: n, children: r }) {
	let { ref: i } = c(`kd-seat:${e}`);
	return /* @__PURE__ */ v("button", {
		ref: i,
		role: "tab",
		"aria-selected": t,
		className: t ? "kd-selected" : "",
		onClick: n,
		children: r
	});
}
function je({ id: e }) {
	let { ref: t, hidden: n } = c(`kd-claim:${e}`);
	return /* @__PURE__ */ v("span", {
		ref: t,
		style: { visibility: n ? "hidden" : void 0 },
		children: /* @__PURE__ */ v(Se, {})
	});
}
function Me({ slot: e, index: t, line: n, enabled: r, active: i, name: a, send: o }) {
	let l = s(), { ref: u, hidden: d } = c(`kd-tile:${e.id}`);
	return /* @__PURE__ */ y("button", {
		ref: u,
		className: `kd-draft-tile${r ? " kd-available" : ""}${i ? " kd-current" : ""}${e.placed ? " kd-placed" : ""}`,
		"data-kd-tile": `${n}-${t}`,
		disabled: !r,
		onClick: () => o({
			type: "choose",
			index: t
		}),
		"aria-label": l("games.kingdomino.chooseTile", { n: M(e.id) }),
		style: { visibility: d ? "hidden" : void 0 },
		children: [/* @__PURE__ */ v(Te, { id: e.id }), /* @__PURE__ */ v("span", {
			className: "kd-claim",
			children: e.rid ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(je, { id: e.id }), a] }) : " "
		})]
	});
}
function Ne(e) {
	let t = s(), n = e.public, r = e.private, { ref: i } = c("kd-market"), { ref: a } = c("kd-deck"), l = n.active === e.myRid, p = X(n, n.active), ee = Math.max(0, X(n, e.myRid)), g = (t) => e.members.find((e) => e.rid === t)?.name ?? t, ne = `${n.phase}:${n.active}:${n.round}:${n.turn}`, [_, b] = o(ne), [x, S] = o(l ? p : ee), [C, w] = o(null), [T, E] = o(0), [D, O] = o([]), [k, A] = o(null), [j, M] = o(null), [I, L] = o(null);
	ne !== _ && (b(ne), w(null), O([]), A(null), M(null), L(null), l && p >= 0 && S(p));
	let U = Math.min(Math.max(0, x), n.kingdoms.length - 1), G = n.kingdoms[U], K = G.board, q = l && U === p, J = (t) => e.send(t), ae = q && n.phase === "place" ? B(K, n.pending, n.size) : [], Y = [];
	q && (n.phase === "place" ? Y = [...new Set(ae.filter((e) => e.dir === T).map((e) => P(e.x, e.y)))] : n.phase === "giantCover" ? Y = Object.keys(K).filter((e) => R(K[e]) > 0) : n.phase === "giantSend" ? Y = Object.keys(K).filter((e) => K[e].giants > 0) : n.phase === "court" ? Y = k !== null && D.length === 2 ? H(K, k, D) : Object.keys(K).filter((e) => K[e].resource) : n.phase === "search" && k !== null ? Y = H(K, k) : n.phase === "frame" && (Y = V(K, n.size).map((e) => P(e.x, e.y))));
	let oe = (e) => {
		if (q) {
			if (n.phase === "place") {
				let [t, n] = F(e);
				w({
					x: t,
					y: n,
					dir: T
				});
			} else if (n.phase === "giantCover") J({
				type: "cover",
				key: e
			});
			else if (n.phase === "giantSend") M(j === e ? null : e);
			else if (n.phase === "court") {
				if (k !== null && D.length === 2 && H(K, k, D).includes(e)) {
					J({
						type: "buy",
						card: k,
						key: e,
						pay: D
					});
					return;
				}
				let t = K[e]?.resource;
				t && O(D.includes(e) ? D.filter((t) => t !== e) : [...D.filter((e) => K[e].resource !== t), e].slice(-4));
			} else if (n.phase === "search" && k !== null) J({
				type: "recruit",
				card: k,
				key: e
			});
			else if (n.phase === "frame") {
				let [t, n] = F(e);
				L({
					x: t,
					y: n
				});
			}
		}
	}, Z = (e) => {
		let t = (T + (e ? 2 : 1)) % 4;
		if (E(t), C) {
			let r = e ? C.x + N[C.dir][0] : C.x, i = e ? C.y + N[C.dir][1] : C.y;
			z(K, n.pending, n.size, r, i, t) ? w({
				x: r,
				y: i,
				dir: t
			}) : w(null);
		}
	}, Q = n.phase === "search" && l ? r?.court ?? [] : n.market, se = Object.keys(K).filter((e) => K[e].resource);
	return q && n.phase === "court" && (k === null || D.length !== 2) && (Y = se), /* @__PURE__ */ v(re, {
		adaptive: !0,
		scroll: !1,
		className: "kd-game",
		banner: /* @__PURE__ */ y("div", {
			className: "kd-header",
			children: [/* @__PURE__ */ v(ie, {
				tone: l ? "accent" : n.phase === "done" ? "done" : "info",
				text: n.phase === "refill" ? t(ke.refill) : l || n.phase === "done" ? t(ke[n.phase]) : t("games.kingdomino.waiting", { name: g(n.active) }),
				chip: t("games.kingdomino.round", {
					n: n.round,
					total: n.rounds
				}),
				accent: W.accent
			}), /* @__PURE__ */ v("div", {
				className: "kd-player-tabs",
				role: "tablist",
				children: n.kingdoms.map((e, t) => /* @__PURE__ */ y(Ae, {
					index: t,
					selected: U === t,
					onClick: () => S(t),
					children: [
						/* @__PURE__ */ v("span", {
							className: "kd-player-names",
							children: e.rids.map(g).join(" · ")
						}),
						/* @__PURE__ */ v("strong", { children: n.scores[t].total }),
						e.rids.includes(n.active) && /* @__PURE__ */ v(Se, {})
					]
				}, t))
			})]
		}),
		actionsHeight: "h-12",
		actions: /* @__PURE__ */ y("div", {
			className: "kd-actions",
			children: [
				l && n.phase === "place" && ae.length === 0 && /* @__PURE__ */ v("button", {
					className: "kd-main-button",
					onClick: () => J({ type: "discard" }),
					children: t("games.kingdomino.discard")
				}),
				l && (n.phase === "court" || n.phase === "giantSend") && /* @__PURE__ */ v("button", {
					className: "kd-main-button",
					onClick: () => J({ type: "skip" }),
					children: n.phase === "court" ? t("games.kingdomino.endTurn") : t("games.kingdomino.skipGiant")
				}),
				l && n.phase === "frame" && I && /* @__PURE__ */ y("button", {
					className: "kd-main-button",
					onClick: () => J({
						type: "frame",
						...I
					}),
					children: [/* @__PURE__ */ v(d, {}), t("games.kingdomino.confirmFrame")]
				}),
				n.config.giants && /* @__PURE__ */ v("span", { children: t("games.kingdomino.giantSupply", { n: n.supply }) }),
				n.quests.map((e) => /* @__PURE__ */ v("span", {
					className: "kd-quest-chip",
					children: ye(e, t)
				}, e))
			]
		}),
		children: /* @__PURE__ */ y("div", {
			className: "kd-table",
			children: [
				/* @__PURE__ */ v(u, {
					kind: "sheen",
					base: "#dce7bf",
					className: "absolute inset-0 size-full"
				}),
				/* @__PURE__ */ y("div", {
					className: "kd-board-panel",
					children: [
						/* @__PURE__ */ v(Oe, {
							board: K,
							size: n.size,
							kingdomIndex: U,
							eligible: Y,
							selected: [...D, ...j ? [j] : []],
							onTap: oe,
							preview: C,
							pending: n.pending,
							onRotate: () => Z(!1),
							onSwap: () => Z(!0),
							onCancel: () => w(null),
							onConfirm: C ? () => J({
								type: "place",
								...C
							}) : void 0,
							frame: I ?? G.frame
						}),
						q && n.phase === "place" && !C && n.pending !== null && /* @__PURE__ */ y("div", {
							className: "kd-held-tile",
							children: [/* @__PURE__ */ v(Te, { id: n.pending }), /* @__PURE__ */ y("div", {
								className: "kd-held-tools",
								children: [/* @__PURE__ */ v("button", {
									onClick: () => Z(!1),
									"aria-label": t("games.kingdomino.rotate"),
									children: /* @__PURE__ */ v(h, {})
								}), /* @__PURE__ */ v("button", {
									onClick: () => Z(!0),
									"aria-label": t("games.kingdomino.swap"),
									children: /* @__PURE__ */ v(m, {})
								})]
							})]
						}),
						l && n.phase === "giantSend" && j && /* @__PURE__ */ v("div", {
							className: "kd-recipient-choices",
							children: n.kingdoms.map((e, n) => n !== p && Object.values(e.board).some((e) => R(e) > 0) ? /* @__PURE__ */ v("button", {
								onClick: () => J({
									type: "sendGiant",
									key: j,
									target: n
								}),
								children: t("games.kingdomino.selectRecipient", { name: e.rids.map(g).join(" · ") })
							}, n) : null)
						}),
						D.length > 0 && q && n.phase === "court" && /* @__PURE__ */ y("div", {
							className: "kd-payment",
							children: [
								/* @__PURE__ */ v("span", { children: t("games.kingdomino.payResources", { n: D.length }) }),
								/* @__PURE__ */ v("button", {
									onClick: () => {
										O([]), A(null);
									},
									"aria-label": t("games.kingdomino.cancel"),
									children: /* @__PURE__ */ v(f, {})
								}),
								D.length === 4 && n.courtLeft > 0 && /* @__PURE__ */ y("button", {
									onClick: () => J({
										type: "search",
										pay: D
									}),
									children: [/* @__PURE__ */ v(te, {}), t("games.kingdomino.search")]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ y("aside", {
					className: `kd-draft-panel${n.config.court ? " kd-with-court" : ""}${n.phase === "court" || n.phase === "search" ? " kd-court-active" : ""}`,
					children: [
						/* @__PURE__ */ y("div", {
							ref: a,
							className: "kd-deck",
							"aria-hidden": !0,
							children: [
								/* @__PURE__ */ v("span", {}),
								/* @__PURE__ */ v("span", {}),
								/* @__PURE__ */ v("span", {})
							]
						}),
						/* @__PURE__ */ v("div", {
							className: "kd-lines",
							children: [{
								line: "current",
								title: "games.kingdomino.currentRow",
								slots: n.row
							}, {
								line: "next",
								title: "games.kingdomino.nextRow",
								slots: n.next
							}].map(({ line: e, title: r, slots: i }) => /* @__PURE__ */ y("section", {
								className: "kd-line",
								children: [/* @__PURE__ */ v("h2", { children: t(r) }), /* @__PURE__ */ v("div", {
									className: "kd-domino-line",
									children: i.map((t, r) => /* @__PURE__ */ v(Me, {
										slot: t,
										index: r,
										line: e,
										enabled: l && !t.rid && (e === "current" && n.phase === "chooseFirst" || e === "next" && n.phase === "chooseNext"),
										active: e === "current" && r === n.turn && n.phase !== "chooseFirst" && !t.placed,
										name: t.rid ? g(t.rid) : "",
										send: J
									}, t.id))
								})]
							}, e))
						}),
						n.config.court && /* @__PURE__ */ y("section", {
							className: "kd-court-panel",
							children: [
								/* @__PURE__ */ v("h2", { children: n.phase === "search" ? t("games.kingdomino.darkPile", { n: n.courtLeft }) : t("games.kingdomino.market") }),
								/* @__PURE__ */ v("div", {
									ref: i,
									className: "kd-market",
									children: Q.map((e) => /* @__PURE__ */ v("button", {
										className: `kd-court-tile${k === e ? " kd-selected" : ""}`,
										disabled: !l || n.phase !== "court" && n.phase !== "search",
										onClick: () => {
											S(p), A(k === e ? null : e);
										},
										"aria-label": ve(e, t),
										children: /* @__PURE__ */ v("img", {
											src: `games/kingdomino/court-${e}.svg`,
											alt: ""
										})
									}, e))
								}),
								/* @__PURE__ */ v("div", {
									className: "kd-court-detail",
									role: "status",
									children: k === null ? "" : ve(k, t)
								})
							]
						})
					]
				})
			]
		})
	});
}
var Pe = {
	future: 0,
	compact: 0,
	order: 0
};
function Fe(e, t, n, r) {
	let i = {
		...e,
		board: { ...e.board }
	}, [a, o] = N[n.dir];
	return k(I(t)).halves.forEach((e, s) => {
		i.board[P(n.x + s * a, n.y + s * o)] = {
			...e,
			tile: t,
			half: s,
			giants: 0,
			...r && !e.crowns ? { resource: A(e.terrain) } : {}
		};
	}), i;
}
function Ie(e, t, n) {
	let r = U(e, t.size, t.quests), i = L(e.board);
	return r.total + n.future * r.regions.reduce((e, t) => e + (t.crowns ? Math.sqrt(t.area) : t.area ** .9), 0) - n.compact * ((i.maxX - i.minX + 1) * (i.maxY - i.minY + 1) - Object.keys(e.board).length);
}
function Le(e) {
	let t = 4294967296 - 4294967296 % e.length, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return e[n % e.length];
}
function Re(e, t, n, r = Pe, i = !1) {
	if (e.active !== n || e.phase === "done" || e.phase === "refill") return null;
	let a = X(e, n), o = e.kingdoms[a], s = (e, t) => i ? Le(e) : e.reduce((e, n) => t(n) > t(e) ? n : e), c = (t, n) => Ie(Fe(o, t, n, e.config.court), e, r);
	if (e.phase === "chooseFirst" || e.phase === "chooseNext") return {
		type: "choose",
		index: s((e.phase === "chooseFirst" ? e.row : e.next).flatMap((e, t) => e.rid ? [] : [{
			index: t,
			id: e.id
		}]).map((t) => {
			let n = B(o.board, t.id, e.size);
			return {
				...t,
				value: n.length ? Math.max(...n.map((e) => c(t.id, e))) - r.order * Math.max(0, I(t.id)) : -1e3
			};
		}), (e) => e.value).index
	};
	if (e.phase === "place") {
		let t = B(o.board, e.pending, e.size);
		return t.length ? {
			type: "place",
			...s(t, (t) => c(e.pending, t))
		} : { type: "discard" };
	}
	if (e.phase === "giantCover") {
		let t = e.kingdoms[e.coverTarget];
		return {
			type: "cover",
			key: s(Object.keys(t.board).filter((e) => R(t.board[e]) > 0), (n) => U({
				...t,
				board: {
					...t.board,
					[n]: {
						...t.board[n],
						giants: t.board[n].giants + 1
					}
				}
			}, e.size, e.quests).total)
		};
	}
	if (e.phase === "giantSend") {
		let t = Object.keys(o.board).filter((e) => o.board[e].giants > 0), n = e.kingdoms.map((e, t) => ({
			kingdom: e,
			i: t
		})).filter((e) => e.i !== a && Object.values(e.kingdom.board).some((e) => R(e) > 0));
		return !t.length || !n.length ? { type: "skip" } : {
			type: "sendGiant",
			key: s(t, (t) => {
				let [n, r] = F(t);
				return U({
					...o,
					board: {
						...o.board,
						[P(n, r)]: {
							...o.board[t],
							giants: o.board[t].giants - 1
						}
					}
				}, e.size, e.quests).total;
			}),
			target: s(n, (t) => e.scores[t.i].total).i
		};
	}
	if (e.phase === "frame") return {
		type: "frame",
		...s(V(o.board, e.size), (t) => U({
			...o,
			frame: t
		}, e.size, e.quests).total)
	};
	if (e.phase === "search") {
		let n = (t?.court ?? []).flatMap((e) => H(o.board, e).map((t) => ({
			card: e,
			key: t
		})));
		return n.length ? {
			type: "recruit",
			...s(n, (t) => Ie({
				...o,
				board: {
					...o.board,
					[t.key]: {
						...o.board[t.key],
						court: t.card
					}
				}
			}, e, r))
		} : null;
	}
	if (e.phase === "court") {
		let t = Object.keys(o.board).filter((e) => o.board[e].resource), n = [];
		for (let i = 0; i < t.length; i++) for (let a = i + 1; a < t.length; a++) if (o.board[t[i]].resource !== o.board[t[a]].resource) {
			let s = [t[i], t[a]], c = { ...o.board };
			s.forEach((e) => {
				c[e] = {
					...c[e],
					resource: void 0
				};
			});
			for (let t of e.market) for (let i of H(c, t)) n.push({
				card: t,
				key: i,
				pay: s,
				score: Ie({
					...o,
					board: {
						...c,
						[i]: {
							...c[i],
							court: t
						}
					}
				}, e, r)
			});
		}
		if (n.length) {
			let t = s(n, (e) => e.score);
			if (i || t.score > Ie(o, e, r)) return {
				type: "buy",
				card: t.card,
				key: t.key,
				pay: t.pay
			};
		}
		let a = [...new Set(t.map((e) => o.board[e].resource))].map((e) => t.find((t) => o.board[t].resource === e)), c = /* @__PURE__ */ new Set([...e.market, ...e.kingdoms.flatMap((e) => Object.values(e.board).flatMap((e) => e.court === void 0 ? [] : [e.court]))]);
		return a.length === 4 && e.courtLeft > 0 && O.some((e) => !c.has(e.id) && H(o.board, e.id, a).length) ? {
			type: "search",
			pay: a
		} : { type: "skip" };
	}
	return null;
}
function ze(e = Pe) {
	return (t, n) => {
		let r = Re(t.public, t.private, n.rid, e, n.difficulty === "weak");
		return r ? { action: r } : null;
	};
}
var Be = ze(), Ve = (e, t, n) => e.type === "choose" ? n("games.kingdomino.chooseTile", { n: M((t.public.phase === "chooseFirst" ? t.public.row : t.public.next)[e.index].id) }) : e.type === "place" ? n("games.kingdomino.emptyCell", {
	x: e.x,
	y: e.y
}) : e.type === "discard" ? n("games.kingdomino.discard") : e.type === "frame" ? n("games.kingdomino.confirmFrame") : e.type === "cover" ? n("games.kingdomino.coverCrown") : e.type === "sendGiant" ? n("games.kingdomino.giantSend") : e.type === "search" ? n("games.kingdomino.search") : e.type === "buy" || e.type === "recruit" ? n("games.kingdomino.searchPrompt") : n("games.kingdomino.endTurn");
//#endregion
//#region src/games/kingdomino/fx.tsx
function He({ at: e, ms: t, children: n }) {
	let r = a(null);
	return i(() => {
		let e = r.current?.animate([{
			transform: "scale(1)",
			opacity: 1
		}, {
			transform: "scale(.15)",
			opacity: 0
		}], {
			duration: t,
			easing: "ease-in",
			fill: "both"
		});
		return () => e?.cancel();
	}, [t]), /* @__PURE__ */ v("div", {
		ref: r,
		className: "absolute",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: n
	});
}
function Ue(e, t, n) {
	return e?.map(({ key: e, resource: r }) => {
		let i = n.anchor(`kd-cell:${t}:${e}`);
		if (!i) return null;
		let a = {
			x: i.x + i.w * .59,
			y: i.y + i.h * .6,
			w: i.w * .38,
			h: i.h * .38
		};
		return /* @__PURE__ */ v(He, {
			at: a,
			ms: 300,
			children: /* @__PURE__ */ v("img", {
				src: `games/kingdomino/icon-${r}.svg`,
				width: "100%",
				height: "100%",
				alt: ""
			})
		}, e);
	});
}
var We = {
	claim(e, t) {
		let n = e.data, r = `kd-claim:${n.id}`, i = t.anchor(r), a = t.anchor(`kd-seat:${n.kingdom}`);
		return i ? !a || t.queued ? {
			ms: 180,
			node: /* @__PURE__ */ v(x, {
				at: i,
				ms: 180
			})
		} : {
			ms: 340,
			hide: [r],
			node: /* @__PURE__ */ v(b, {
				from: {
					...a,
					w: 17,
					h: 23
				},
				to: i,
				ms: 340,
				children: /* @__PURE__ */ v(Se, {})
			})
		} : null;
	},
	place(e, t) {
		let n = e.data, r = t.anchor(`kd-tile:${n.id}`), i = t.anchor(`kd-cell:${n.kingdom}:${n.x},${n.y}`);
		if (!i) return null;
		if (!r || t.queued > 0) return {
			ms: 230,
			node: /* @__PURE__ */ v(x, {
				at: i,
				ms: 230
			})
		};
		let [a, o] = N[n.dir], s = [0, 1].map((e) => `kd-cell:${n.kingdom}:${P(n.x + e * a, n.y + e * o)}`), c = s.map((e) => t.anchor(e));
		return c.some((e) => !e) ? {
			ms: 230,
			node: /* @__PURE__ */ v(x, {
				at: i,
				ms: 230
			})
		} : {
			ms: 420,
			hide: s,
			node: /* @__PURE__ */ v(_, { children: k(I(n.id)).halves.map((e, t) => {
				let i = c[t], a = {
					...r,
					x: r.x + t * r.w / 2,
					w: r.w / 2,
					h: r.w / 2
				};
				return /* @__PURE__ */ v(b, {
					from: a,
					to: i,
					ms: 420,
					children: /* @__PURE__ */ v("div", {
						style: {
							width: i.w,
							height: i.h
						},
						children: /* @__PURE__ */ v("svg", {
							viewBox: "0 0 100 100",
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ v(we, { cell: {
								...e,
								tile: n.id,
								half: t,
								giants: 0
							} })
						})
					})
				}, t);
			}) })
		};
	},
	giant(e, t) {
		let n = e.data, r = `kd-giant:${n.kingdom}:${n.key}`, i = t.anchor(r), a = t.anchor(`kd-seat:${n.kingdom}`);
		return i ? !a || t.queued ? {
			ms: 230,
			node: /* @__PURE__ */ v(x, {
				at: i,
				ms: 230
			})
		} : {
			ms: 360,
			hide: [r],
			node: /* @__PURE__ */ v(b, {
				from: {
					...a,
					w: 32,
					h: 50
				},
				to: i,
				ms: 360,
				children: /* @__PURE__ */ v("div", {
					style: {
						width: i.w,
						height: i.h
					},
					children: /* @__PURE__ */ v("svg", {
						viewBox: "0 0 32 50",
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ v(xe, {})
					})
				})
			})
		} : null;
	},
	recruit(e, t) {
		let n = e.data, r = `kd-court:${n.kingdom}:${n.key}`, i = t.anchor(r), a = t.anchor(`kd-seat:${n.kingdom}`), o = t.anchor("kd-market");
		if (!i) return a ? {
			ms: 230,
			node: /* @__PURE__ */ v(x, {
				at: a,
				ms: 230
			})
		} : null;
		let s = o && o.w > 0 && o.h > 0 ? {
			...o,
			w: o.h,
			h: o.h
		} : null;
		return {
			ms: 420,
			hide: s && !t.queued ? [r] : [],
			node: /* @__PURE__ */ y(_, { children: [Ue(n.paid, n.kingdom, t), s && !t.queued ? /* @__PURE__ */ v(b, {
				from: s,
				to: i,
				ms: 420,
				children: /* @__PURE__ */ v("img", {
					src: `games/kingdomino/court-${n.card}.svg`,
					alt: "",
					style: {
						width: i.w,
						height: i.h
					}
				})
			}) : /* @__PURE__ */ v(x, {
				at: i,
				ms: 230
			})] })
		};
	},
	pay(e, t) {
		let n = e.data;
		return {
			ms: 300,
			node: /* @__PURE__ */ v(_, { children: Ue(n.paid, n.kingdom, t) })
		};
	},
	sendGiant(e, t) {
		let n = e.data, r = t.anchor(`kd-cell:${n.source}:${n.key}`) ?? t.anchor(`kd-seat:${n.source}`), i = t.anchor(`kd-seat:${n.target}`);
		return r && i ? {
			ms: 360,
			node: /* @__PURE__ */ v(b, {
				from: {
					...r,
					w: 32,
					h: 50
				},
				to: {
					...i,
					w: 32,
					h: 50
				},
				ms: 360,
				children: /* @__PURE__ */ v("svg", {
					width: "32",
					height: "50",
					viewBox: "0 0 32 50",
					children: /* @__PURE__ */ v(xe, {})
				})
			})
		} : null;
	},
	discard(e, t) {
		let n = e.data, r = `kd-tile:${n.id}`, i = t.anchor(r);
		return i ? {
			ms: 230,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ v(He, {
				at: i,
				ms: 230,
				children: /* @__PURE__ */ v(Te, { id: n.id })
			})
		} : null;
	},
	reveal(e, t) {
		let n = e.data, r = t.anchor("kd-deck"), i = n.ids.map((e) => ({
			id: e,
			name: `kd-tile:${e}`,
			to: t.anchor(`kd-tile:${e}`)
		})).filter((e) => e.to);
		return !r || !i.length ? null : {
			ms: 340,
			hide: t.queued ? [] : i.map((e) => e.name),
			node: /* @__PURE__ */ v(_, { children: i.map(({ id: e, to: n }) => t.queued ? /* @__PURE__ */ v(x, {
				at: n,
				ms: 180
			}, e) : /* @__PURE__ */ v(b, {
				from: r,
				to: n,
				ms: 340,
				children: /* @__PURE__ */ v("div", {
					style: {
						width: n.w,
						height: n.w / 2
					},
					children: /* @__PURE__ */ v(Te, { id: e })
				})
			}, e)) })
		};
	},
	frame() {
		return null;
	}
};
//#endregion
//#region src/games/kingdomino/game-over.tsx
function Ge({ public: e, members: t, myRid: n, result: r, hintCount: i, onPlayAgain: a, onBackToLobby: c }) {
	let l = e, f = s(), [m, ee] = o(Math.max(0, X(l, n))), [h, te] = o(!1), [g, ne] = o([]), ie = (e) => t.find((t) => t.rid === e)?.name ?? e, b = l.kingdoms[m], x = l.scores[m], C = [...new Set(r.winner.map((e) => l.kingdoms[X(l, e)].rids.map(ie).join(" · ")))].join(" / ");
	return /* @__PURE__ */ v(re, {
		adaptive: !0,
		scroll: !1,
		className: "kd-game kd-over",
		banner: /* @__PURE__ */ y("div", {
			className: "kd-header",
			children: [/* @__PURE__ */ y("div", {
				className: "kd-result-title",
				children: [/* @__PURE__ */ y("span", { children: ["🏰 ", f("games.kingdomino.resultTitle")] }), /* @__PURE__ */ v("strong", { children: f(r.winner.length > (l.config.mode === "teams" ? 2 : 1) ? "games.kingdomino.tied" : "games.kingdomino.winner", { name: C }) })]
			}), /* @__PURE__ */ v("div", {
				className: "kd-player-tabs",
				role: "tablist",
				children: l.kingdoms.map((e, t) => /* @__PURE__ */ y("button", {
					role: "tab",
					"aria-selected": m === t,
					className: m === t ? "kd-selected" : "",
					onClick: () => {
						ee(t), ne([]);
					},
					children: [
						/* @__PURE__ */ v("span", {
							className: "kd-player-names",
							children: e.rids.map(ie).join(" · ")
						}),
						/* @__PURE__ */ v("strong", { children: l.scores[t].total }),
						e.rids.some((e) => r.winner.includes(e)) && /* @__PURE__ */ v("img", {
							src: "games/kingdomino/icon-crown.svg",
							width: "25",
							height: "23",
							alt: ""
						})
					]
				}, t))
			})]
		}),
		actionsHeight: "h-12",
		actions: /* @__PURE__ */ y("div", {
			className: "kd-actions",
			children: [
				a && /* @__PURE__ */ v(S, {
					compact: !0,
					className: "kd-main-button",
					label: f("games.kingdomino.playAgain"),
					confirmLabel: f("games.kingdomino.confirmAgain"),
					onConfirm: a
				}),
				c && /* @__PURE__ */ v(S, {
					compact: !0,
					className: "kd-main-button",
					label: f("games.kingdomino.lobby"),
					confirmLabel: f("games.kingdomino.confirmLobby"),
					onConfirm: c
				}),
				!a && !c && /* @__PURE__ */ v("span", { children: f("games.kingdomino.waitHost") })
			]
		}),
		children: /* @__PURE__ */ y("div", {
			className: `kd-end-table${h ? " kd-folded" : ""}`,
			children: [
				/* @__PURE__ */ v(u, {
					kind: "sheen",
					base: "#dce7bf",
					className: "absolute inset-0 size-full"
				}),
				/* @__PURE__ */ v("div", {
					className: "kd-end-board",
					children: /* @__PURE__ */ v(Oe, {
						board: b.board,
						size: l.size,
						kingdomIndex: m,
						eligible: [],
						selected: g,
						onTap: () => {},
						preview: null,
						pending: null,
						frame: b.frame,
						readOnly: !0
					})
				}),
				/* @__PURE__ */ v("div", {
					className: "kd-ledger-toggle",
					children: /* @__PURE__ */ y("button", {
						className: "kd-main-button",
						onClick: () => te(!h),
						children: [/* @__PURE__ */ v(p, {}), f(h ? "games.kingdomino.showScores" : "games.kingdomino.hideScores")]
					})
				}),
				/* @__PURE__ */ y("aside", {
					className: "kd-ledger",
					hidden: h,
					children: [
						/* @__PURE__ */ y("div", {
							className: "kd-score-total",
							children: [
								/* @__PURE__ */ v("span", { children: f("games.kingdomino.total") }),
								/* @__PURE__ */ v("strong", { children: x.total }),
								/* @__PURE__ */ v(d, {})
							]
						}),
						i !== void 0 && i > 0 && /* @__PURE__ */ v("p", {
							className: "kd-session-note",
							children: f("session.hint.usedCount", { n: i })
						}),
						b.rids.map((e) => (r.autopilot?.[e] ?? 0) > 0 ? /* @__PURE__ */ y("p", {
							className: "kd-session-note",
							children: [
								ie(e),
								" · ",
								f("session.autopilot.share", { n: Math.round(r.autopilot[e] * 100) })
							]
						}, e) : null),
						/* @__PURE__ */ v("h2", { children: f("games.kingdomino.domains") }),
						x.regions.map((e, t) => /* @__PURE__ */ y("button", {
							className: "kd-region-row",
							onClick: () => ne(g === e.keys ? [] : e.keys),
							children: [/* @__PURE__ */ v("span", { children: f("games.kingdomino.region", {
								terrain: f(he[e.terrain]),
								area: e.area,
								crowns: e.crowns
							}) }), /* @__PURE__ */ v("strong", { children: e.score })]
						}, t)),
						l.config.court && /* @__PURE__ */ y("div", {
							className: "kd-ledger-row",
							children: [/* @__PURE__ */ v("span", { children: f("games.kingdomino.characters") }), /* @__PURE__ */ v("strong", { children: x.court })]
						}),
						x.bonuses.length > 0 && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("h2", { children: f("games.kingdomino.quests") }), x.bonuses.map((e) => /* @__PURE__ */ y("div", {
							className: "kd-ledger-row",
							children: [/* @__PURE__ */ v("span", { children: ye(e.quest, f) }), /* @__PURE__ */ v("strong", { children: e.score })]
						}, e.quest))] }),
						/* @__PURE__ */ y("div", {
							className: "kd-score-ties",
							children: [
								/* @__PURE__ */ y("span", { children: [
									f("games.kingdomino.largest"),
									" ",
									x.largest
								] }),
								/* @__PURE__ */ y("span", { children: [
									f("games.kingdomino.crowns"),
									" ",
									x.crowns
								] }),
								/* @__PURE__ */ v("span", { children: f("games.kingdomino.discarded", { n: b.discarded.length }) })
							]
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/games/kingdomino/options.tsx
function Ke({ value: e, onChange: t }) {
	let n = s(), r = G.safeParse(e), i = r.success ? r.data : G.parse(void 0), a = [
		[
			"standard",
			"games.kingdomino.standard",
			"games.kingdomino.standardHint"
		],
		[
			"duel",
			"games.kingdomino.duel",
			"games.kingdomino.duelHint"
		],
		[
			"large",
			"games.kingdomino.large",
			"games.kingdomino.largeHint"
		],
		[
			"teams",
			"games.kingdomino.teams",
			"games.kingdomino.teamsHint"
		]
	], o = (e) => t({
		...i,
		...e
	});
	return /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ v(T, {
			title: n("games.kingdomino.mode"),
			children: a.map(([e, t, r]) => /* @__PURE__ */ v(w, {
				name: "kingdomino-mode",
				value: e,
				checked: i.mode === e,
				label: n(t),
				hint: n(r),
				accent: W.accent,
				onChange: () => o({
					mode: e,
					...e === "large" || e === "teams" ? {
						giants: !1,
						court: !1
					} : {}
				})
			}, e))
		}),
		i.mode === "teams" && /* @__PURE__ */ v(T, {
			title: n("games.kingdomino.teamCount"),
			children: [3, 4].map((e) => /* @__PURE__ */ v(w, {
				name: "kingdomino-teams",
				value: String(e),
				checked: i.teamCount === e,
				label: n("games.kingdomino.teamCountLabel", {
					n: e,
					players: e * 2
				}),
				accent: W.accent,
				onChange: () => o({ teamCount: e })
			}, e))
		}),
		/* @__PURE__ */ y(T, {
			title: n("games.kingdomino.variants"),
			children: [(i.mode === "standard" || i.mode === "duel") && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(C, {
				name: "kingdomino-giants",
				value: "giants",
				checked: i.giants,
				label: n("games.kingdomino.giants"),
				onChange: () => o({
					giants: !i.giants,
					harmony: !1,
					middle: !1
				})
			}), /* @__PURE__ */ v(C, {
				name: "kingdomino-court",
				value: "court",
				checked: i.court,
				label: n("games.kingdomino.court"),
				onChange: () => o({ court: !i.court })
			})] }), !i.giants && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(C, {
				name: "kingdomino-harmony",
				value: "harmony",
				checked: i.harmony,
				label: n("games.kingdomino.harmony"),
				onChange: () => o({ harmony: !i.harmony })
			}), /* @__PURE__ */ v(C, {
				name: "kingdomino-middle",
				value: "middle",
				checked: i.middle,
				label: n("games.kingdomino.middle"),
				onChange: () => o({ middle: !i.middle })
			})] })]
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/kingdomino/entry.tsx
var qe = {
	definition: me,
	View: Ne,
	bot: Be,
	describe: Ve,
	fx: We,
	OverView: Ge,
	Options: Ke,
	locales: {
		zh: {
			name: "多米諾王國",
			desc: "选择多米诺板块，连接地形与王冠，建造自己的王国。",
			rules: "目标：将相同地形连接成领地。每片领地的面积乘以有效王冠数，就是该领地的得分。总分最高者获胜；平分时依次比较最大领地面积、有效王冠总数，仍相同则共同获胜。\n准备与选择：基础版有48块双格板块。2人随机使用24块，每人有2名国王，每轮展示4块，共6轮；3人随机使用36块，每轮3块，共12轮；4人使用全部48块，每轮4块，共12轮。第一轮按随机国王次序选板块。此后按上一行板块编号从小到大行动：先放置自己已选的板块，再从下一行选择一块。最后一行只放置，不再选择。\n放置：两格必须一起放入王国，不能重叠。至少一格须与已有的同类地形正交相邻，或正交接触城堡；城堡可以连接任何地形。整个王国必须能放入5 行 5 列的方框，城堡不必居中。只要存在合法位置，就必须放置；完全无处可放时才弃置。点击合法格预览板块，在预览旁旋转后确认。\n计分：同类地形按正交连接构成领地。无王冠的领地计为 0 分。基础可选规则“和谐”在完整铺满且未弃置时加5分；“中王国”在城堡位于最终方框中心时加10分。涉及边界的计分会在终局前要求选定包含全部已铺格子的最终方框。\n巨人时代（Age of Giants）：默认关闭，支持2至5人。加入12块扩展板块，每轮始终取5块排序，字母A至F在数字前。2或4人弃第3块；3人弃第2和第4块；5人保留全部。2人各用2名国王，其余每人1名。标准2人局共6轮，其他人数及巅峰对决共12轮。放置字母板块后必须从公共供应拿取1个巨人，盖住自己1个尚未被盖的王冠；没有可盖王冠或供应耗尽时忽略。放置49至54号脚印板块后，可以把自己的1个巨人送给任意有可盖王冠的对手，由对方选王冠；也可以不转移。公共供应共6个巨人，每个遮住1个王冠。\n巨人任务：开局随机公开2项任务，替代基础可选加分。和谐加5分；中王国加10分；城堡在最终方框角落加20分；指定地形在城堡周围8格每格加5分，或在方框4角每格加5分；每片恰好5格且没有有效王冠的麦田、森林、湖泊或草原领地加10分；水平、垂直或对角方向，每条连续至少3个有有效王冠格子的最长直线加10分，同一直线不重复计算重叠的三连格。巨人遮住的王冠不参与任务与宫廷计分。\n宫廷（The Court）：默认关闭，可与标准王国的巨人时代组合。每块无王冠的麦田、森林、湖泊、草原格分别带有麦子、木材、鱼、羊资源。回合结束时，可以从王国中支付2种不同资源购买公开市场的一块角色或建筑；也可以支付4种不同资源，从暗堆中选择一块，再将余下暗堆洗匀。每回合最多购买一次，也可以跳过。所获宫廷板块必须放在没有王冠、资源或其他宫廷板块的非城堡格，可使用刚支付资源的格子；建筑须匹配地形，角色可放任意地形。市场保持3块，空位只在下一行形成时补充。若没有可放位置则不能购买或搜索。\n宫廷计分：建筑提供领地王冠。农夫、樵夫、渔夫、牧羊人各有3分，并按周围8格的对应资源每个加3分；商人有2分，每个相邻资源加2分；战士按牌面获得 3 或 4 分；队长有1分，每名相邻战士加3分，队长本身也属于战士；国王按相邻有效王冠每个获得 1 分；王后有2分，每名相邻角色加2分。相邻均含对角，不含自身，资源保留在具体格子上直到被支付。\n巅峰对决：仅限2人，每人2名国王，使用全套48块基础板块，建造7 行 7 列的王国，共12轮。可加入宫廷或巨人时代；加入巨人时代时使用60块，每行5块并弃置第3块。\n双盒大王国：仅使用基础板块，支持3或4人，每人建造7 行 7 列的王国。使用两盒板块，3人每盒随机36块，4人每盒48块；各轮交替从两盒取一行，共24轮。基础可选加分仍可使用。\n双盒团队：仅使用基础板块，支持6或8人，相邻座位每2人一队，每人1名国王。每队共建7 行 7 列的王国，队友可以讨论，轮到的成员自己作决定。每行6或8块，两盒交替供牌，共12轮。队伍同分时比较共享王国的最大领地和有效王冠，获胜队成员共同获胜。双盒模式不与巨人时代或宫廷组合。",
			standard: "标准王国",
			duel: "巅峰对决",
			duelHint: "2人，使用全套板块建造7 行 7 列的王国。",
			large: "双盒大王国",
			teams: "双盒团队",
			mode: "游戏模式",
			variants: "扩展与加分",
			standardHint: "2–4人，巨人时代可增加至5人。",
			largeHint: "3–4人，各自建造7 行 7 列的王国。",
			teamsHint: "6或8人，相邻座位每2人一队，共建7 行 7 列的王国。",
			giants: "巨人时代",
			court: "宫廷",
			harmony: "和谐",
			middle: "中王国",
			teamCount: "队伍数量",
			teamCountLabel: "{{n}} 队（{{players}} 人）",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			chooseFirst: "选择一块板块",
			chooseNext: "选择下一轮的板块",
			place: "放置你的板块",
			giantCover: "选择一个王冠放置巨人",
			giantSend: "选择自己的巨人，再选择对手",
			courtPrompt: "选择资源和宫廷板块，或结束回合",
			searchPrompt: "从暗堆选择一块，放入王国",
			framePrompt: "选定王国的最终边界",
			refill: "准备下一行板块",
			done: "王国建造完成",
			waiting: "等待 {{name}}",
			round: "第 {{n}} / {{total}} 轮",
			currentRow: "本轮",
			nextRow: "下一轮",
			market: "宫廷市场",
			darkPile: "暗堆 · {{n}}",
			confirm: "确认放置",
			confirmFrame: "确认边界",
			discard: "弃置板块",
			endTurn: "结束回合",
			skipGiant: "不转移",
			search: "支付4种资源搜索",
			cancel: "取消选择",
			rotate: "旋转板块",
			swap: "调换两格",
			zoomIn: "放大王国",
			zoomOut: "缩小王国",
			fit: "完整显示",
			chooseTile: "选择 {{n}} 号板块",
			tile: "{{n}} 号板块",
			cell: "格子（{{x}}，{{y}}）：{{terrain}}，{{n}} 个有效王冠",
			emptyCell: "在（{{x}}，{{y}}）预览板块",
			courtTile: "{{name}} · {{rule}}",
			payResources: "已选资源 {{n}} / 4",
			selectRecipient: "送给 {{name}}",
			playerKingdom: "{{name}}的王国",
			score: "{{n}} 分",
			total: "总分",
			domains: "领地",
			characters: "宫廷角色",
			quests: "任务与加分",
			largest: "最大领地",
			crowns: "有效王冠",
			discarded: "弃置 {{n}} 块",
			resultTitle: "王国计分簿",
			winner: "{{name}}获胜",
			tied: "共同获胜：{{name}}",
			review: "查看王国",
			hideScores: "收起计分簿",
			showScores: "展开计分簿",
			playAgain: "再来一局",
			lobby: "返回大厅",
			waitHost: "等待主机开始下一局",
			region: "{{terrain}}：{{area}} 格 × {{crowns}} 王冠",
			wheat: "麦田",
			forest: "森林",
			lake: "湖泊",
			grass: "草原",
			swamp: "沼泽",
			mine: "矿山",
			castle: "城堡",
			resourceWheat: "麦子",
			wood: "木材",
			fish: "鱼",
			sheep: "羊",
			building: "建筑",
			farmer: "农夫",
			merchant: "商人",
			lumberjack: "樵夫",
			fisherman: "渔夫",
			shepherd: "牧羊人",
			warrior: "战士",
			captain: "队长",
			king: "国王",
			queen: "王后",
			buildingRule: "提供 {{n}} 个王冠",
			resourceRule: "{{base}} 分，每个相邻{{resource}}加 {{n}} 分",
			merchantRule: "2 分，每个相邻资源加 2 分",
			warriorRule: "{{n}} 分",
			captainRule: "1 分，每名相邻战士加 3 分",
			kingRule: "每个相邻有效王冠得 1 分",
			queenRule: "2 分，每名相邻角色加 2 分",
			corner: "失落一角",
			lines: "宏伟之线",
			bleak: "荒凉国王",
			localQuest: "城堡周围：{{terrain}}",
			cornerQuest: "王国四角：{{terrain}}",
			giantSupply: "巨人 {{n}} / 6",
			chooseGiant: "选择这个巨人",
			coverCrown: "在此处放置巨人",
			errTurn: "现在轮不到你行动。",
			errAction: "这个选择当前不可用。",
			errPlace: "板块不能放在这里，请选择合法位置。",
			errDiscard: "仍有合法位置，不能弃置这块板块。"
		},
		en: {
			name: "Kingdomino",
			desc: "Draft dominoes, connect landscapes and crowns, and build your kingdom.",
			rules: "Goal: Connect matching terrain into properties. Each property scores its area multiplied by its uncovered crowns. Highest total wins; ties break by largest property, then total uncovered crowns. Remaining ties share victory.\nDrafting: The base game has 48 dominoes. With 2 players, randomly use 24, with 2 kings per player and 4 dominoes per line for 6 rounds. With 3 players, use 36 and lines of 3 for 12 rounds; with 4, use all 48 and lines of 4 for 12 rounds. Draft the first line in random king order. Thereafter, act in ascending order of your chosen domino numbers: place that domino, then claim one in the next line. The final line only involves placement.\nPlacement: Place both squares together without overlap. At least one square must touch matching terrain orthogonally, or touch the castle, which matches any terrain. Your kingdom must fit inside a 5×5 frame; the castle need not be central. You must place a domino if any legal placement exists, and may discard only if none exists. Click a legal square to preview, rotate beside the preview, and confirm.\nScoring: Properties connect orthogonally. A property with no crown scores zero. Optional Harmony scores 5 for a complete kingdom with no discarded dominoes. Optional Middle Kingdom scores 10 if the castle is at the centre of the final frame. If scoring depends on boundaries, choose a final frame containing every placed square before scoring.\nAge of Giants: Off by default, for 2–5 players. Add 12 dominoes and always draw 5 each round. Sort letters A–F before numbers. With 2 or 4 players, discard the third; with 3, discard the second and fourth; with 5, retain all. Two players use 2 kings each; otherwise 1 each. Standard 2-player games last 6 rounds; other player counts and The Mighty Duel last 12. Placing a lettered domino requires taking a giant from the supply and covering one of your uncovered crowns. Ignore this if no crown or giant is available. After placing a footsteps domino (49–54), you may move one of your giants to an opponent with an available crown; the recipient chooses which crown to cover. You may decline. There are 6 giants, each covering 1 crown.\nQuests: Reveal 2 random quests, replacing the base optional bonuses. Harmony scores 5; Middle Kingdom 10; a corner castle 20. The specified terrain scores 5 per square around the castle (8 neighbours), or in the 4 corners of the final frame. Each exactly 5-square, crownless wheat, forest, lake or grassland property scores 10. Each maximal uninterrupted horizontal, vertical or diagonal run of at least 3 crowned squares scores 10; overlapping triples within one run do not score again. Covered crowns do not count for quests or Court scoring.\nThe Court: Off by default; may combine with Giants in standard kingdoms. Each crownless wheat, forest, lake or grassland square supplies wheat, wood, fish or sheep. At the end of your turn you may spend 2 different resources to buy a visible Court tile, or 4 different resources to choose a tile from the face-down pile, then shuffle the remainder. You may buy once per turn or skip. Place the acquired tile on a non-castle square containing no crown, resource or other Court tile, including a square just emptied by payment. Buildings require matching terrain; characters accept any terrain. Refill the 3-tile market only when the next domino line forms. Buying or searching requires a legal destination.\nCourt scoring: Buildings add crowns to properties. Farmer, lumberjack, fisherman and shepherd score 3 plus 3 per matching neighbouring resource. Merchant scores 2 plus 2 per neighbouring resource of any type. Warriors score 3 or 4 as printed. Captain scores 1 plus 3 per neighbouring warrior; the captain is also a warrior. King scores 1 per neighbouring uncovered crown. Queen scores 2 plus 2 per neighbouring character. Neighbours include diagonals but exclude the tile itself. Resources remain on specific squares until spent.\nThe Mighty Duel: For 2 players with 2 kings each, all 48 base dominoes, 7×7 kingdoms and 12 rounds. May combine with Court or Giants. With Giants, use all 60 dominoes, drawing lines of 5 and discarding the third domino.\nTwo-set large kingdoms: Base dominoes only, for 3–4 players with individual 7×7 kingdoms. With 3, randomly use 36 dominoes from each set; with 4, use all 48 from each. Alternate sets each line for 24 rounds. Base optional bonuses remain available.\nTwo-set teams: Base dominoes only, for 6 or 8 players. Adjacent pairs are teams. Each player has 1 king; each pair shares a 7×7 kingdom. Partners may discuss, while the acting player makes the final choice. Lines contain 6 or 8 dominoes, alternating sets for 12 rounds. Ties compare shared largest property and uncovered crowns; winning partners share victory. Two-set modes cannot combine with Giants or Court.",
			standard: "Standard kingdom",
			duel: "The Mighty Duel",
			duelHint: "2 players, full domino set, 7×7 kingdoms.",
			large: "Two-set large kingdom",
			teams: "Two-set teams",
			mode: "Game mode",
			variants: "Expansions & bonuses",
			standardHint: "2–4 players, or up to 5 with Giants.",
			largeHint: "3–4 players, individual 7×7 kingdoms.",
			teamsHint: "6 or 8 players; adjacent pairs share a 7×7 kingdom.",
			giants: "Age of Giants",
			court: "The Court",
			harmony: "Harmony",
			middle: "Middle Kingdom",
			teamCount: "Number of teams",
			teamCountLabel: "{{n}} teams ({{players}} players)",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			chooseFirst: "Choose a domino",
			chooseNext: "Claim your next domino",
			place: "Place your domino",
			giantCover: "Choose a crown for the giant",
			giantSend: "Choose your giant, then an opponent",
			courtPrompt: "Select resources and a Court tile, or end your turn",
			searchPrompt: "Choose a tile from the pile and place it",
			framePrompt: "Choose the final kingdom boundary",
			refill: "Preparing the next line",
			done: "Kingdoms complete",
			waiting: "Waiting for {{name}}",
			round: "Round {{n}} / {{total}}",
			currentRow: "This round",
			nextRow: "Next round",
			market: "The Court",
			darkPile: "Face-down pile · {{n}}",
			confirm: "Place domino",
			confirmFrame: "Confirm boundary",
			discard: "Discard domino",
			endTurn: "End turn",
			skipGiant: "Keep giant",
			search: "Spend 4 types to search",
			cancel: "Clear selection",
			rotate: "Rotate domino",
			swap: "Swap squares",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			fit: "Fit kingdom",
			chooseTile: "Claim domino {{n}}",
			tile: "Domino {{n}}",
			cell: "Square ({{x}}, {{y}}): {{terrain}}, {{n}} uncovered crowns",
			emptyCell: "Preview at ({{x}}, {{y}})",
			courtTile: "{{name}} · {{rule}}",
			payResources: "Selected resources {{n}} / 4",
			selectRecipient: "Send to {{name}}",
			playerKingdom: "{{name}}’s kingdom",
			score: "{{n}} points",
			total: "Total",
			domains: "Properties",
			characters: "Court characters",
			quests: "Quests & bonuses",
			largest: "Largest property",
			crowns: "Uncovered crowns",
			discarded: "{{n}} discarded",
			resultTitle: "Kingdom ledger",
			winner: "{{name}} wins",
			tied: "Shared victory: {{name}}",
			review: "Inspect kingdom",
			hideScores: "Fold ledger",
			showScores: "Open ledger",
			playAgain: "Play again",
			lobby: "Back to lobby",
			waitHost: "Waiting for the host",
			region: "{{terrain}}: {{area}} squares × {{crowns}} crowns",
			wheat: "Wheat fields",
			forest: "Forest",
			lake: "Lake",
			grass: "Grassland",
			swamp: "Swamp",
			mine: "Mine",
			castle: "Castle",
			resourceWheat: "Wheat",
			wood: "Wood",
			fish: "Fish",
			sheep: "Sheep",
			building: "Building",
			farmer: "Farmer",
			merchant: "Merchant",
			lumberjack: "Lumberjack",
			fisherman: "Fisherman",
			shepherd: "Shepherd",
			warrior: "Warrior",
			captain: "Captain",
			king: "King",
			queen: "Queen",
			buildingRule: "Adds {{n}} crowns",
			resourceRule: "{{base}} points, +{{n}} per neighbouring {{resource}}",
			merchantRule: "2 points, +2 per neighbouring resource",
			warriorRule: "{{n}} points",
			captainRule: "1 point, +3 per neighbouring warrior",
			kingRule: "1 point per neighbouring uncovered crown",
			queenRule: "2 points, +2 per neighbouring character",
			corner: "The lost corner",
			lines: "La folie des grandeurs",
			bleak: "Bleak king",
			localQuest: "Around castle: {{terrain}}",
			cornerQuest: "Four corners: {{terrain}}",
			giantSupply: "Giants {{n}} / 6",
			chooseGiant: "Select this giant",
			coverCrown: "Place giant here",
			errTurn: "It is not your turn.",
			errAction: "That choice is not available now.",
			errPlace: "That placement is not legal. Choose another position.",
			errDiscard: "A legal placement exists, so this domino cannot be discarded."
		}
	}
};
//#endregion
export { qe as default };
