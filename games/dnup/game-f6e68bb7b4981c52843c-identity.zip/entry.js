import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { playTurn as u, useSoundEdge as d } from "@bgparty/sdk/sfx";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Floater as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { AVATARS as b } from "@bgparty/sdk/avatars";
import { IconBot as x } from "@bgparty/sdk/icons";
import { Confetti as ee } from "@bgparty/sdk/ui/confetti";
//#region src/games/dnup/meta.ts
var S = {
	id: "dnup",
	tier: "released",
	mechanics: ["hand-management"],
	interactionTags: [],
	nameKey: "games.dnup.name",
	descKey: "games.dnup.desc",
	rulesKey: "games.dnup.rules",
	icon: "🔄",
	iconImg: "games/dnup.webp",
	rulesUrl: {
		zh: "https://rules.bgparty.uuppi.com/dnup/zh.pdf",
		en: "https://www.dnup.game/rules/rules_en.pdf"
	},
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#16a34a",
	releasedAt: "2026-10-06",
	search: {
		py: "fan zhuan wang pai",
		init: "fzwp"
	},
	hotseat: "cover"
}, C = t.object({
	id: t.int().min(0).max(39),
	up: t.union([t.literal(0), t.literal(1)])
}), w = t.object({
	value: t.int().min(1).max(10),
	cards: t.array(C).min(1)
}), T = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		cards: t.array(t.int().min(0).max(39)).min(1)
	}),
	t.object({
		type: t.literal("add"),
		target: t.string(),
		zone: t.union([t.literal(0), t.literal(1)]).optional(),
		card: t.int().min(0).max(39)
	}),
	t.object({
		type: t.literal("take"),
		target: t.string(),
		zone: t.union([t.literal(0), t.literal(1)]).optional()
	}),
	t.object({ type: t.literal("rotate") }),
	t.object({ type: t.literal("next") })
]), E = t.string(), te = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"play",
		"roundOver",
		"done"
	]),
	turn: E,
	zone: t.union([t.literal(0), t.literal(1)]),
	twoPlayer: t.boolean(),
	sets: t.record(E, t.array(w.nullable())),
	out: t.array(E),
	roundResult: t.object({
		first: E,
		second: E.nullable()
	}).nullable(),
	players: t.array(t.object({
		rid: E,
		handCount: t.int().nonnegative(),
		score: t.int().nonnegative(),
		roundWins: t.int().nonnegative(),
		out: t.boolean(),
		decided: t.boolean()
	}))
}), D = t.object({ hand: t.array(C) }), O = [
	{
		a: 1,
		b: 2,
		minPlayers: 2
	},
	{
		a: 1,
		b: 3,
		minPlayers: 2
	},
	{
		a: 1,
		b: 4,
		minPlayers: 2
	},
	{
		a: 1,
		b: 5,
		minPlayers: 2,
		star: !0
	},
	{
		a: 1,
		b: 6,
		minPlayers: 2
	},
	{
		a: 1,
		b: 7,
		minPlayers: 2
	},
	{
		a: 1,
		b: 7,
		minPlayers: 2
	},
	{
		a: 2,
		b: 3,
		minPlayers: 2
	},
	{
		a: 2,
		b: 4,
		minPlayers: 2
	},
	{
		a: 2,
		b: 4,
		minPlayers: 2
	},
	{
		a: 2,
		b: 5,
		minPlayers: 2
	},
	{
		a: 2,
		b: 9,
		minPlayers: 2
	},
	{
		a: 2,
		b: 10,
		minPlayers: 2
	},
	{
		a: 3,
		b: 6,
		minPlayers: 2
	},
	{
		a: 3,
		b: 7,
		minPlayers: 2
	},
	{
		a: 3,
		b: 8,
		minPlayers: 2
	},
	{
		a: 3,
		b: 9,
		minPlayers: 2
	},
	{
		a: 4,
		b: 6,
		minPlayers: 2
	},
	{
		a: 4,
		b: 7,
		minPlayers: 2
	},
	{
		a: 4,
		b: 8,
		minPlayers: 2
	},
	{
		a: 5,
		b: 6,
		minPlayers: 2
	},
	{
		a: 5,
		b: 7,
		minPlayers: 2
	},
	{
		a: 5,
		b: 8,
		minPlayers: 2
	},
	{
		a: 5,
		b: 9,
		minPlayers: 2
	},
	{
		a: 6,
		b: 7,
		minPlayers: 2
	},
	{
		a: 6,
		b: 8,
		minPlayers: 2
	},
	{
		a: 1,
		b: 10,
		minPlayers: 3
	},
	{
		a: 2,
		b: 8,
		minPlayers: 3
	},
	{
		a: 3,
		b: 6,
		minPlayers: 3
	},
	{
		a: 4,
		b: 5,
		minPlayers: 3
	},
	{
		a: 1,
		b: 8,
		minPlayers: 4
	},
	{
		a: 1,
		b: 9,
		minPlayers: 4
	},
	{
		a: 2,
		b: 6,
		minPlayers: 4
	},
	{
		a: 2,
		b: 7,
		minPlayers: 4
	},
	{
		a: 3,
		b: 4,
		minPlayers: 4
	},
	{
		a: 3,
		b: 5,
		minPlayers: 4
	},
	{
		a: 3,
		b: 10,
		minPlayers: 5
	},
	{
		a: 4,
		b: 9,
		minPlayers: 5
	},
	{
		a: 5,
		b: 8,
		minPlayers: 5
	},
	{
		a: 6,
		b: 7,
		minPlayers: 5
	}
], k = {
	discard: 340,
	fly: 400,
	stagger: 55,
	bounce: 400,
	settle: 800,
	tail: 80
}, A = (e) => e.up === 0 ? O[e.id].a : O[e.id].b, j = (e) => e.up === 0 ? O[e.id].b : O[e.id].a, M = (e) => ({
	id: e.id,
	up: e.up ^ 1
});
function N(t) {
	let n = O.map((e, t) => t).filter((e) => O[e].minPlayers <= t.players.length);
	for (let r = n.length - 1; r > 0; --r) {
		let i = e(t.seed, t.rngCursor, r + 1);
		t.rngCursor += 1, [n[r], n[i]] = [n[i], n[r]];
	}
	let r = Math.floor(n.length / t.players.length);
	t.players.forEach((i, a) => {
		let o = [];
		for (let i = 0; i < r; i += 1) o.push({
			id: n[a * r + i],
			up: e(t.seed, t.rngCursor, 2)
		}), t.rngCursor += 1;
		t.hands[i] = o, t.sets[i] = t.twoPlayer ? [null, null] : [null], t.decided[i] = !1;
	}), t.out = [], t.roundResult = null, t.turnIdx = t.players.findIndex((e) => t.hands[e].some((e) => O[e.id].star)), t.zone = +!!t.twoPlayer, t.phase = "play";
}
function P(e, t, n) {
	for (let r of e.players) for (let i = 0; i < e.sets[r].length; i += 1) {
		let a = e.sets[r][i];
		if (a && a.cards.length === t && !(n && n.owner === r && n.zi === i)) return {
			owner: r,
			zi: i,
			set: a
		};
	}
	return null;
}
function F(e, t, n) {
	let r = e.sets[t][n];
	r && (e.sets[t][n] = null, !e.out.includes(t) && e.hands[t].push(...r.cards.map(M)));
}
function ne(e, t, n) {
	let r = e.sets[t][n];
	return r ? (e.sets[t][n] = null, {
		owner: t,
		zi: n,
		cards: r.cards
	}) : null;
}
function I(e) {
	if (e.twoPlayer) return e.zone = +(e.zone === 0), e.zone === 0 && (e.turnIdx = (e.turnIdx + 1) % e.players.length), {
		expired: null,
		cleared: ne(e, e.players[e.turnIdx], e.zone)
	};
	let t = null;
	for (;;) {
		e.turnIdx = (e.turnIdx + 1) % e.players.length;
		let n = e.players[e.turnIdx];
		if (!e.out.includes(n)) return {
			expired: t,
			cleared: ne(e, n, 0)
		};
		let r = e.sets[n][0];
		r && (t = {
			owner: n,
			zi: 0,
			cards: r.cards
		}), e.sets[n][0] = null;
	}
}
function L(e, t) {
	if (e.hands[t].length > 0) return {
		out: null,
		scores: null,
		...I(e)
	};
	if (e.twoPlayer) {
		e.roundWins[t] += 1, e.roundResult = {
			first: t,
			second: null
		}, e.phase = "roundOver";
		for (let t of e.players) e.decided[t] = !1;
		return {
			out: "win",
			scores: [{
				rid: t,
				n: 1
			}],
			expired: null,
			cleared: null
		};
	}
	if (e.out.push(t), e.out.length >= 2) {
		e.scores[e.out[0]] += 2, e.scores[e.out[1]] += 1, e.roundResult = {
			first: e.out[0],
			second: e.out[1]
		}, e.phase = "roundOver";
		for (let t of e.players) e.decided[t] = !1;
		return {
			out: "second",
			scores: [{
				rid: e.out[0],
				n: 2
			}, {
				rid: e.out[1],
				n: 1
			}],
			expired: null,
			cleared: null
		};
	}
	return {
		out: "first",
		scores: null,
		...I(e)
	};
}
function R(e, t, n, r) {
	return [{
		kind: e,
		rid: t,
		data: {
			...n,
			...r.expired ? { expired: r.expired } : {},
			...r.cleared ? { cleared: r.cleared } : {},
			...r.out ? { out: r.out } : {},
			...r.scores ? { scores: r.scores } : {}
		}
	}];
}
function z(e) {
	return e.players.map((t, n) => ({
		kind: "deal",
		rid: t,
		data: { count: e.hands[t].length },
		for: [t],
		secret: { cards: e.hands[t] },
		...n > 0 ? { with: !0 } : {}
	}));
}
function re(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		players: t,
		twoPlayer: t.length === 2,
		round: 1,
		phase: "play",
		turnIdx: 0,
		zone: 0,
		hands: {},
		sets: {},
		out: [],
		scores: Object.fromEntries(t.map((e) => [e, 0])),
		roundWins: Object.fromEntries(t.map((e) => [e, 0])),
		decided: {},
		roundResult: null
	};
	return N(r), {
		state: r,
		fx: z(r)
	};
}
function ie(e, t, n) {
	if (e.phase === "done") return { code: "games.dnup.errNotYourTurn" };
	if (t.type === "next") {
		if (e.phase !== "roundOver" || e.decided[n.by]) return { code: "games.dnup.errNotYourTurn" };
		let t = structuredClone(e);
		return t.decided[n.by] = !0, t.players.every((e) => t.decided[e]) ? (t.twoPlayer ? t.players.some((e) => t.roundWins[e] >= 2) : t.players.some((e) => t.scores[e] >= 4)) ? (t.phase = "done", {
			state: t,
			fx: []
		}) : (t.round += 1, N(t), {
			state: t,
			fx: z(t)
		}) : {
			state: t,
			fx: []
		};
	}
	if (e.phase !== "play" || n.by !== e.players[e.turnIdx]) return { code: "games.dnup.errNotYourTurn" };
	if (t.type === "rotate") {
		let t = structuredClone(e);
		t.hands[n.by] = t.hands[n.by].map(M);
		let r = L(t, n.by);
		return {
			state: t,
			fx: R("rotate", n.by, {}, r)
		};
	}
	if (t.type === "play") {
		let r = e.hands[n.by], i = t.cards.map((e) => r.find((t) => t.id === e));
		if (i.some((e) => !e)) return { code: "games.dnup.errBadCards" };
		let a = i, o = A(a[0]);
		if (!a.every((e) => A(e) === o)) return { code: "games.dnup.errBadCards" };
		let s = structuredClone(e), c = s.twoPlayer ? s.zone : 0, l = P(s, a.length);
		if (s.hands[n.by] = r.filter((e) => !t.cards.includes(e.id)), l) {
			if (s.twoPlayer && l.owner === n.by) {
				if (o <= l.set.value) {
					s.hands[n.by].push(...a.map(M));
					let e = L(s, n.by);
					return {
						state: s,
						fx: R("play", n.by, {
							cards: a,
							zi: c,
							selfBounce: !0
						}, e)
					};
				}
			} else if (o <= l.set.value) return { code: "games.dnup.errTooWeak" };
			let e = {
				owner: l.owner,
				zi: l.zi,
				cards: l.set.cards,
				toPile: s.out.includes(l.owner)
			};
			F(s, l.owner, l.zi), s.sets[n.by][c] = {
				value: o,
				cards: a
			};
			let t = L(s, n.by);
			return {
				state: s,
				fx: R("play", n.by, {
					cards: a,
					zi: c,
					bounced: e
				}, t)
			};
		}
		s.sets[n.by][c] = {
			value: o,
			cards: a
		};
		let u = L(s, n.by);
		return {
			state: s,
			fx: R("play", n.by, {
				cards: a,
				zi: c
			}, u)
		};
	}
	if (t.target === n.by || !e.players.includes(t.target)) return { code: "games.dnup.errBadTarget" };
	let r = e.twoPlayer ? t.zone ?? 0 : 0, i = e.sets[t.target]?.[r];
	if (!i) return { code: "games.dnup.errNoSet" };
	if (t.type === "take") {
		let a = structuredClone(e);
		a.sets[t.target][r] = null;
		let o = i.cards.map(M);
		a.hands[n.by].push(...o);
		let s = L(a, n.by);
		return {
			state: a,
			fx: R("take", n.by, {
				cards: o,
				from: t.target,
				zi: r
			}, s)
		};
	}
	let a = e.hands[n.by].find((e) => e.id === t.card);
	if (!a || A(a) !== i.value) return { code: "games.dnup.errBadCard" };
	let o = structuredClone(e);
	o.sets[t.target][r] = {
		value: i.value,
		cards: [...i.cards, a]
	};
	let s = P(o, i.cards.length + 1, {
		owner: t.target,
		zi: r
	});
	if (s && i.value <= s.set.value) return { code: "games.dnup.errTooWeak" };
	o.hands[n.by] = o.hands[n.by].filter((e) => e.id !== t.card);
	let c = s ? {
		owner: s.owner,
		zi: s.zi,
		cards: s.set.cards,
		toPile: o.out.includes(s.owner)
	} : null;
	s && F(o, s.owner, s.zi);
	let l = L(o, n.by);
	return {
		state: o,
		fx: R("add", n.by, {
			card: a,
			target: t.target,
			zi: r,
			...c ? { bounced: c } : {}
		}, l)
	};
}
function ae(e, t) {
	return {
		public: {
			round: e.round,
			phase: e.phase,
			turn: e.players[e.turnIdx],
			zone: e.zone,
			twoPlayer: e.twoPlayer,
			sets: e.sets,
			out: e.out,
			roundResult: e.roundResult,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t]?.length ?? 0,
				score: e.scores[t] ?? 0,
				roundWins: e.roundWins[t] ?? 0,
				out: e.out.includes(t),
				decided: e.decided[t] ?? !1
			}))
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function B(e) {
	if (e.phase !== "done") return { phase: e.phase };
	if (e.twoPlayer) {
		let t = [...e.players].sort((t, n) => e.roundWins[n] - e.roundWins[t]);
		return {
			phase: "done",
			winner: [t[0]],
			ranking: t,
			scores: { ...e.roundWins }
		};
	}
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.roundResult?.first;
	return {
		phase: "done",
		winner: [n && e.scores[n] >= 4 ? n : t[0]],
		ranking: t,
		scores: { ...e.scores }
	};
}
var V = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: S,
	schemas: {
		action: T,
		publicView: te,
		privateView: D
	},
	setup: re,
	reduce: ie,
	viewFor: ae,
	status: B
}, H = {
	1: "#91b932",
	2: "#9a298e",
	3: "#00a7b0",
	4: "#f36a28",
	5: "#f4ba12",
	6: "#d12d8b",
	7: "#ef639f",
	8: "#344e9e",
	9: "#78355e",
	10: "#2f9c55"
}, U = {
	1: "#eff2ca",
	2: "#e4cee7",
	3: "#c9ebee",
	4: "#ffdfc7",
	5: "#fff0c0",
	6: "#f6d3e9",
	7: "#f9d8e6",
	8: "#d8dff2",
	9: "#e7d7e6",
	10: "#d7eddb"
};
function W({ card: e, size: t, selected: n, style: r }) {
	let i = A(e), a = j(e), o = O[e.id].star === !0;
	return /* @__PURE__ */ _("span", {
		className: `dnup-card dnup-card-${t} ${n ? "is-selected" : ""}`,
		style: {
			"--dnup-card-color": H[i],
			"--dnup-card-down-color": H[a],
			"--dnup-card-light": U[i],
			"--dnup-card-down-light": U[a],
			...r
		},
		children: [
			/* @__PURE__ */ _("span", {
				className: "dnup-card-pattern",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ g("i", { children: i }), /* @__PURE__ */ g("i", { children: a })]
			}),
			/* @__PURE__ */ g("span", {
				className: `dnup-card-up ${i >= 10 ? "is-double" : ""} ${i === 6 || i === 9 ? "is-underlined" : ""}`,
				children: i
			}),
			/* @__PURE__ */ g("span", {
				className: `dnup-card-down ${a >= 10 ? "is-double" : ""} ${a === 6 || a === 9 ? "is-underlined" : ""}`,
				"aria-hidden": !0,
				children: a
			}),
			o && /* @__PURE__ */ g("span", {
				className: "dnup-card-star",
				"aria-hidden": !0,
				children: "★"
			}),
			n && /* @__PURE__ */ g("span", {
				className: "dnup-card-select",
				"aria-hidden": !0
			})
		]
	});
}
function G({ style: e }) {
	return /* @__PURE__ */ _("span", {
		className: "dnup-card dnup-card-hand dnup-card-back",
		style: e,
		"aria-hidden": !0,
		children: [/* @__PURE__ */ g("span", {
			className: "dnup-card-back-pattern",
			children: "2 7 9"
		}), /* @__PURE__ */ g("span", {
			className: "dnup-card-back-logo",
			children: "dnup"
		})]
	});
}
//#endregion
//#region src/games/dnup/view-player.tsx
var oe = [
	"d",
	"n",
	"u",
	"p"
];
function se(e) {
	return /* @__PURE__ */ g(K, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function K({ pub: e, priv: t, members: v, myRid: y, send: b }) {
	let x = c(), ee = s((e) => e.locale), { ref: S } = o("table"), C = (e) => {
		let t = v.find((t) => t.rid === e);
		return t ? m(t, ee) : e;
	}, w = (e) => l[(v.find((t) => t.rid === e)?.colorIndex ?? 0) % l.length].hex, T = r(() => [...t?.hand ?? []].sort((e, t) => A(e) - A(t) || j(e) - j(t) || e.id - t.id), [t]), E = T, te = e.players.find((e) => e.rid === y), D = e.phase === "play" && e.turn === y, O = e.phase === "roundOver" && te !== void 0 && !te.decided;
	d(D || O, u);
	let [k, M] = a(null), [N, P] = a(null), [F, ne] = a(() => /* @__PURE__ */ new Map());
	{
		let t = !1, n = new Map(F);
		for (let r of e.players) for (let [i, a] of (e.sets[r.rid] ?? []).entries()) a && n.get(`${r.rid}:${i}`) !== a.cards.length && (n.set(`${r.rid}:${i}`, a.cards.length), t = !0);
		t && ne(n);
	}
	let I = `${e.phase}|${e.turn}|${e.zone}|${E.length}|${E.map((e) => `${e.id}:${e.up}`).join(",")}`, [L, R] = a(I);
	L !== I && (R(I), M(null), P(null));
	let z = i(null), re = i(null), [ie, ae] = a(12);
	n(() => {
		let e = z.current, t = re.current;
		if (!t) return;
		let n = t.querySelector(".dnup-table"), r = [...t.querySelectorAll(".dnup-set-zone")], i = (e, t, n) => {
			e.style.getPropertyValue(t) !== n && e.style.setProperty(t, n);
		}, a = () => {
			let t = getComputedStyle(n).getPropertyValue("--dnup-wide").trim() === "1";
			for (let e of r) {
				if (!t) {
					e.style.removeProperty("--dnup-table-w");
					continue;
				}
				let n = Number(e.dataset.cardCount), r = e.clientHeight - 48 - 4, a = e.clientWidth - 4, o = Math.max(64, Math.min(180, r * 40 / 58, (a - (n - 1) * 2) / n));
				i(e, "--dnup-table-w", `${Math.floor(o * 100) / 100}px`);
			}
			if (!e) return;
			if (!t) {
				if (e.style.removeProperty("--dnup-hand-w"), e.style.removeProperty("--dnup-hand-columns"), T.length > 1 && e.clientWidth) {
					let t = Math.ceil((T.length * 46 + 8 - e.clientWidth) / (T.length - 1));
					ae(Math.min(14, Math.max(10, t)));
				}
				return;
			}
			let a = Math.max(1, T.length), o = e.clientWidth - 16, s = e.clientHeight - 22, c = Math.min(a, 2), l = 0;
			for (let e = Math.min(a, 2); e <= Math.min(a, 4); e++) {
				let t = Math.ceil(a / e), n = Math.min((o - (e - 1) * 12) / e, (s - (t - 1) * 12) * 46 / 64 / t);
				n > l && (l = n, c = e);
			}
			l < 72 && (c = Math.max(1, Math.min(a, 4, Math.floor((o + 12) / 84)))), i(e, "--dnup-hand-w", `${Math.floor(Math.max(72, Math.min(136, l)) * 100) / 100}px`), i(e, "--dnup-hand-columns", String(c));
		};
		a();
		let o = new ResizeObserver(a);
		for (let n of [
			t,
			e,
			...r
		]) n && o.observe(n);
		return () => o.disconnect();
	}, [
		T.length,
		e.players,
		e.sets
	]), n(() => {
		if (!k || !z.current) return;
		let e = z.current, t = e.querySelectorAll(".dnup-hand-button")[k.to];
		if (!t) return;
		let n = e.getBoundingClientRect(), r = t.getBoundingClientRect();
		r.right > n.right - 10 ? e.scrollLeft += r.right - n.right + 10 : r.left < n.left + 10 && (e.scrollLeft -= n.left + 10 - r.left), r.bottom > n.bottom - 8 ? e.scrollTop += r.bottom - n.bottom + 8 : r.top < n.top + 8 && (e.scrollTop -= n.top + 8 - r.top);
	}, [k, ie]);
	let B = k ? T.slice(k.from, k.to + 1) : [], V = B.length > 0 && B.every((e) => A(e) === A(B[0])) ? A(B[0]) : null, H = (t, n) => {
		for (let r of e.players) {
			let i = e.sets[r.rid] ?? [];
			for (let e = 0; e < i.length; e += 1) {
				let a = i[e];
				if (a && a.cards.length === t && !(n && n.rid === r.rid && n.zi === e)) return {
					rid: r.rid,
					zi: e,
					set: a
				};
			}
		}
		return null;
	}, U = B.length > 0 ? H(B.length) : null, W = U !== null && V !== null && !(e.twoPlayer && U.rid === y) && V <= U.set.value, G = D && B.length > 0 && V !== null && !W, se = G && e.twoPlayer && U?.rid === y && V !== null && V <= U.set.value, K = N ? e.sets[N.rid]?.[N.zi] ?? null : null, q = N !== null && K !== null && B.length === 1 && V === K.value, fe = q && N ? H(K.cards.length + 1, N) : null, J = D && q && !(fe && K.value <= fe.set.value), Y = D && N !== null && K !== null, pe = [];
	if (D && B.length === 1 && V !== null) {
		for (let t of e.players) if (t.rid !== y) for (let [n, r] of (e.sets[t.rid] ?? []).entries()) {
			if (!r || r.value !== V) continue;
			let e = {
				rid: t.rid,
				zi: n
			}, i = H(r.cards.length + 1, e);
			i && r.value <= i.set.value || pe.push({
				...e,
				conflict: i,
				sourceSize: r.cards.length
			});
		}
	}
	let me = /* @__PURE__ */ new Map();
	G && U && !se && me.set(`${U.rid}:${U.zi}`, {
		kind: "play",
		toPile: e.players.some((e) => e.rid === U.rid && e.out)
	});
	for (let t of pe) t.conflict && me.set(`${t.conflict.rid}:${t.conflict.zi}`, {
		kind: "add",
		sourceSize: t.sourceSize,
		toPile: e.players.some((e) => e.rid === t.conflict?.rid && e.out)
	});
	let he = (e) => {
		if (D) {
			if (!k) {
				M({
					from: e,
					to: e
				});
				return;
			}
			if (e >= k.from && e <= k.to) {
				M(null);
				return;
			}
			if (P(null), e === k.from - 1) {
				M({
					from: e,
					to: k.to
				});
				return;
			}
			if (e === k.to + 1) {
				M({
					from: k.from,
					to: e
				});
				return;
			}
			M(e < k.from ? {
				from: e,
				to: k.to
			} : {
				from: k.from,
				to: e
			});
		}
	}, ge = (e, t) => {
		D && e !== y && (k && k.to > k.from && M(null), P(N && N.rid === e && N.zi === t ? null : {
			rid: e,
			zi: t
		}));
	}, _e = e.phase === "roundOver" ? x(O ? "games.dnup.roundOverTitle" : "games.dnup.roundWaiting") : e.phase === "done" ? x("games.dnup.roundOverTitle") : D ? x("games.dnup.turnYou") : x("games.dnup.turnWait", { name: C(e.turn) }), ve = B.length > 0 && V === null ? x("games.dnup.badSame") : W && !N ? x("games.dnup.tooWeak") : N && B.length === 1 && K && !q ? x("games.dnup.mismatch") : N && q && !J ? x("games.dnup.addTooWeak") : se && !N ? x("games.dnup.selfBounce") : null, X = N && !k ? "take" : N && B.length === 1 ? "add" : "play", Z = X === "take" ? Y : X === "add" ? J : G, ye = X === "play" && B.length > 0 ? x("games.dnup.playCount", { n: B.length }) : x(X === "take" ? "games.dnup.take" : X === "add" ? "games.dnup.add" : "games.dnup.play"), Q = () => {
		X === "take" && N && Y && b({
			type: "take",
			target: N.rid,
			zone: N.zi
		}), X === "add" && N && B[0] && J && b({
			type: "add",
			target: N.rid,
			zone: N.zi,
			card: B[0].id
		}), X === "play" && G && b({
			type: "play",
			cards: B.map((e) => e.id)
		}), M(null), P(null);
	}, be = [...e.players.filter((e) => e.rid !== y), ...e.players.filter((e) => e.rid === y)];
	return /* @__PURE__ */ g("div", {
		ref: re,
		className: "dnup-game-shell",
		children: /* @__PURE__ */ g(f, {
			adaptive: !0,
			banner: /* @__PURE__ */ g("div", {
				className: `dnup-banner ${e.players.length <= 3 ? "is-roomy" : ""}`,
				children: /* @__PURE__ */ g(p, {
					tone: D || O ? "accent" : "info",
					accent: "#55df29",
					chip: x("games.dnup.roundStage", { n: e.round }),
					text: _e
				})
			}),
			actionsHeight: "dnup-actions-height",
			overlay: e.roundResult && (e.phase === "roundOver" || e.phase === "done") ? /* @__PURE__ */ g("div", {
				className: "dnup-result-wrap pointer-events-auto",
				children: /* @__PURE__ */ _("div", {
					className: "dnup-result",
					children: [
						/* @__PURE__ */ g("h2", {
							className: "dnup-result-title",
							children: x("games.dnup.roundOverTitle")
						}),
						e.twoPlayer && /* @__PURE__ */ g("p", {
							className: "dnup-result-award",
							children: x("games.dnup.roundWin2p", { name: C(e.roundResult.first) })
						}),
						!e.twoPlayer && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("p", {
							className: "dnup-result-award",
							children: x("games.dnup.firstOut", { name: C(e.roundResult.first) })
						}), e.roundResult.second && /* @__PURE__ */ g("p", {
							className: "dnup-result-award",
							children: x("games.dnup.secondOut", { name: C(e.roundResult.second) })
						})] }),
						/* @__PURE__ */ g("ul", {
							className: "dnup-result-list",
							children: e.players.map((t) => /* @__PURE__ */ _("li", { children: [/* @__PURE__ */ g("span", { children: C(t.rid) }), /* @__PURE__ */ g("span", { children: e.twoPlayer ? x("games.dnup.wins2p", { n: t.roundWins }) : x("games.dnup.letters", { n: t.score }) })] }, t.rid))
						})
					]
				})
			}) : void 0,
			actions: /* @__PURE__ */ _("div", {
				className: "dnup-actions",
				children: [
					/* @__PURE__ */ g("div", {
						className: "dnup-action-row",
						children: O || e.phase === "done" ? O && /* @__PURE__ */ g("button", {
							type: "button",
							className: "dnup-action-primary",
							onClick: () => b({ type: "next" }),
							children: x(e.players.some((t) => e.twoPlayer ? t.roundWins >= 2 : t.score >= 4) ? "games.dnup.showFinal" : "games.dnup.nextRound")
						}) : D ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("button", {
							type: "button",
							className: "dnup-action-secondary",
							onClick: () => b({ type: "rotate" }),
							children: x("games.dnup.rotateAll")
						}), /* @__PURE__ */ g("button", {
							type: "button",
							className: "dnup-action-primary",
							disabled: !Z,
							onClick: Q,
							children: ye
						})] }) : /* @__PURE__ */ g("span", {
							className: "dnup-action-wait",
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "dnup-hint",
						role: ve ? "alert" : void 0,
						children: ve ?? " "
					}),
					t && /* @__PURE__ */ g("div", {
						ref: z,
						className: "dnup-hand-rail scrollbar-none",
						children: /* @__PURE__ */ g("div", {
							className: "dnup-hand-cards",
							children: T.map((e, t) => {
								let n = k !== null && t >= k.from && t <= k.to;
								return /* @__PURE__ */ g(ue, {
									card: e,
									selected: n,
									disabled: !D,
									ariaLabel: x("games.dnup.cardAria", {
										a: A(e),
										b: j(e)
									}),
									overlap: t > 0 ? ie : 0,
									zIndex: t,
									onTap: () => he(t)
								}, e.id);
							})
						})
					})
				]
			}),
			children: /* @__PURE__ */ g("div", {
				ref: S,
				className: "dnup-table",
				"data-players": e.players.length,
				children: be.map((t) => {
					let n = e.sets[t.rid] ?? [];
					return /* @__PURE__ */ _("div", {
						className: `dnup-board ${e.phase === "play" && e.turn === t.rid ? "is-turn" : ""} ${t.rid === y ? "is-mine" : ""} ${t.out ? "is-out" : ""}`,
						style: { "--dnup-player-color": w(t.rid) },
						children: [/* @__PURE__ */ _("div", {
							className: "dnup-board-head",
							children: [
								/* @__PURE__ */ _("span", {
									className: "dnup-board-name",
									children: [/* @__PURE__ */ g(ce, {
										rid: t.rid,
										name: C(t.rid)
									}), t.out && /* @__PURE__ */ g("span", {
										className: "sr-only",
										children: x("games.dnup.outStay")
									})]
								}),
								/* @__PURE__ */ g(le, {
									rid: t.rid,
									count: t.handCount
								}),
								e.twoPlayer ? /* @__PURE__ */ g("span", {
									className: "dnup-score-track dnup-wins",
									"aria-label": x("games.dnup.wins2p", { n: t.roundWins }),
									children: [0, 1].map((e) => /* @__PURE__ */ g("i", { className: `dnup-win-dot ${e < t.roundWins ? "is-earned" : ""}` }, e))
								}) : /* @__PURE__ */ g("span", {
									className: "dnup-score-track",
									"aria-label": x("games.dnup.letters", { n: t.score }),
									children: oe.map((e, n) => /* @__PURE__ */ g("i", {
										className: `dnup-letter ${n < t.score ? "is-earned" : ""}`,
										children: e
									}, e))
								})
							]
						}), /* @__PURE__ */ g("div", {
							className: "dnup-board-sets",
							children: n.map((n, r) => {
								let i = pe.find((e) => e.rid === t.rid && e.zi === r), a = me.get(`${t.rid}:${r}`), o = a ? a.kind === "play" ? x(a.toPile ? "games.dnup.playDiscardHint" : "games.dnup.playBounceHint") : x(a.toPile ? "games.dnup.addDiscardHint" : "games.dnup.addBounceHint", { n: a.sourceSize ?? 0 }) : void 0;
								return /* @__PURE__ */ g(de, {
									rid: t.rid,
									zi: r,
									set: n,
									ghostN: F.get(`${t.rid}:${r}`) ?? 1,
									zoneLabel: e.twoPlayer ? String(r + 1) : null,
									myZoneMark: t.rid === y && e.twoPlayer && e.turn === y && e.zone === r,
									canTarget: D && t.rid !== y && n !== null,
									pressed: N?.rid === t.rid && N.zi === r,
									addAvailable: !!i,
									takeAvailable: N?.rid === t.rid && N.zi === r && k === null && Y,
									outcomeText: o,
									outcomeToPile: a?.toPile === !0,
									ariaLabel: n ? `${e.twoPlayer ? `${x(r === 0 ? "games.dnup.zone1" : "games.dnup.zone2")}，` : ""}${x("games.dnup.setAria", {
										name: C(t.rid),
										v: n.value,
										n: n.cards.length
									})}` : void 0,
									onTap: () => ge(t.rid, r),
									onAdd: () => {
										i && B[0] && (b({
											type: "add",
											target: t.rid,
											zone: r,
											card: B[0].id
										}), M(null), P(null));
									},
									onTake: () => {
										Y && N && N.rid === t.rid && N.zi === r && k === null && (b({
											type: "take",
											target: t.rid,
											zone: r
										}), P(null));
									}
								}, r);
							})
						})]
					}, t.rid);
				})
			})
		})
	});
}
function ce({ rid: e, name: t }) {
	let { ref: n } = o(`seat:${e}`);
	return /* @__PURE__ */ g("span", {
		ref: n,
		className: "dnup-seat-name",
		title: t,
		children: t
	});
}
function le({ rid: e, count: t }) {
	let n = c(), { ref: r, hidden: i } = o(`stock:${e}`);
	return /* @__PURE__ */ _("span", {
		className: "dnup-hand-stock",
		"aria-label": n("games.dnup.stripHand", { n: t }),
		children: [/* @__PURE__ */ _("span", {
			ref: r,
			className: "dnup-mini-back",
			style: { visibility: i ? "hidden" : void 0 },
			"aria-hidden": !0,
			children: [/* @__PURE__ */ g("i", {}), /* @__PURE__ */ g("b", { children: "dnup" })]
		}), /* @__PURE__ */ g("strong", { children: n("games.dnup.stripHand", { n: t }) })]
	});
}
function ue({ card: e, selected: t, disabled: n, ariaLabel: r, overlap: i, zIndex: a, onTap: s }) {
	let { ref: c, hidden: l } = o(`hand:${e.id}`);
	return /* @__PURE__ */ g("button", {
		ref: c,
		type: "button",
		disabled: n,
		"aria-label": r,
		"aria-pressed": t,
		onClick: s,
		className: `dnup-hand-button ${t ? "is-selected" : ""}`,
		style: {
			"--dnup-hand-overlap": `${i}px`,
			zIndex: a,
			visibility: l ? "hidden" : void 0
		},
		children: /* @__PURE__ */ g(W, {
			card: e,
			size: "hand",
			selected: t
		})
	});
}
function q({ card: e }) {
	let { ref: t, hidden: n } = o(`tcard:${e.id}`);
	return /* @__PURE__ */ g("span", {
		ref: t,
		className: "dnup-tcard",
		style: { visibility: n ? "hidden" : void 0 },
		children: /* @__PURE__ */ g(W, {
			card: e,
			size: "table"
		})
	});
}
function de({ rid: e, zi: t, set: n, ghostN: r, zoneLabel: i, myZoneMark: a, canTarget: s, pressed: l, addAvailable: u, takeAvailable: d, outcomeText: f, outcomeToPile: p, ariaLabel: m, onTap: h, onAdd: v, onTake: y }) {
	let b = c(), { ref: x } = o(`set:${e}:${t}`), { ref: ee } = o(`set-zone:${e}:${t}`), { ref: S } = o(`set-area:${e}:${t}`);
	return /* @__PURE__ */ _("div", {
		ref: ee,
		className: "dnup-set-zone",
		"data-card-count": n?.cards.length ?? r,
		"data-zoned": i !== null,
		children: [
			/* @__PURE__ */ g("span", {
				ref: S,
				className: "dnup-set-fx-area",
				"aria-hidden": !0
			}),
			i !== null && /* @__PURE__ */ g("span", {
				className: `dnup-zone-index ${a ? "is-current" : ""}`,
				"aria-label": b(t === 0 ? "games.dnup.zone1" : "games.dnup.zone2"),
				children: i
			}),
			n ? /* @__PURE__ */ g("button", {
				ref: x,
				type: "button",
				disabled: !s,
				"aria-label": m,
				"aria-pressed": l,
				onClick: h,
				className: `dnup-set ${l ? "is-target" : ""} ${s ? "is-available" : ""}`,
				children: n.cards.map((e) => /* @__PURE__ */ g(q, { card: e }, e.id))
			}) : /* @__PURE__ */ g("span", {
				ref: x,
				className: "dnup-empty-area",
				style: { "--dnup-ghost-n": r },
				"aria-hidden": !0
			}),
			/* @__PURE__ */ _("div", {
				className: "dnup-set-controls",
				children: [
					u && /* @__PURE__ */ g("button", {
						type: "button",
						className: "dnup-set-action",
						"aria-label": m ? `${b("games.dnup.addToSet")}：${m}` : void 0,
						onClick: v,
						children: b("games.dnup.addToSet")
					}),
					d && /* @__PURE__ */ g("button", {
						type: "button",
						className: "dnup-set-action",
						"aria-label": m ? `${b("games.dnup.take")}：${m}` : void 0,
						onClick: y,
						children: b("games.dnup.take")
					}),
					f && /* @__PURE__ */ g("span", {
						className: `dnup-set-outcome ${p ? "is-discard" : ""}`,
						role: "status",
						children: f
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/dnup/bot.ts
function fe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function J(e, t, n) {
	for (let r of e.players) {
		let i = e.sets[r.rid] ?? [];
		for (let e = 0; e < i.length; e += 1) {
			let a = i[e];
			if (a && a.cards.length === t && !(n && n.owner === r.rid && n.zi === e)) return {
				owner: r.rid,
				zi: e,
				set: a
			};
		}
	}
	return null;
}
function Y(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = A(n);
		t.set(e, [...t.get(e) ?? [], n]);
	}
	return t;
}
function pe(e, t, n) {
	let r = [{ type: "rotate" }], i = e.twoPlayer ? e.zone : 0;
	for (let [a, o] of Y(t)) {
		let t = o.map((e) => e.id);
		for (let o = 1; o <= t.length; o += 1) {
			let s = J(e, o);
			if (!s) {
				r.push({
					type: "play",
					cards: t.slice(0, o)
				});
				continue;
			}
			if (e.twoPlayer && s.owner === n && s.zi !== i) {
				a > s.set.value && r.push({
					type: "play",
					cards: t.slice(0, o)
				});
				continue;
			}
			a > s.set.value && r.push({
				type: "play",
				cards: t.slice(0, o)
			});
		}
	}
	for (let i of e.players) i.rid !== n && (e.sets[i.rid] ?? []).forEach((n, a) => {
		if (n) {
			for (let o of t) {
				if (A(o) !== n.value) continue;
				let t = J(e, n.cards.length + 1, {
					owner: i.rid,
					zi: a
				});
				(!t || n.value > t.set.value) && r.push({
					type: "add",
					target: i.rid,
					zone: a,
					card: o.id
				});
			}
			r.push({
				type: "take",
				target: i.rid,
				zone: a
			});
		}
	});
	return r;
}
function me(e, t, n, r) {
	if (r.type === "rotate") {
		let e = Math.max(0, ...[...Y(t.map((e) => ({
			id: e.id,
			up: e.up ^ 1
		}))).values()].map((e) => e.length));
		return Math.max(0, ...[...Y(t).values()].map((e) => e.length)) <= 1 && e >= 3 ? 1.5 : -1;
	}
	if (r.type === "play") {
		let i = t.filter((e) => r.cards.includes(e.id)), a = A(i[0]), o = i.length, s = o + a * .3 + o * .5, c = J(e, o);
		return c && (c.owner === n ? s -= c.set.cards.length * 1.5 : s += c.set.cards.length * 1.5), t.length === o && (s += 1e3), s;
	}
	if (r.type === "add") {
		let t = e.twoPlayer ? r.zone ?? 0 : 0, n = e.sets[r.target]?.[t];
		if (!n) return -1;
		let i = J(e, n.cards.length + 1, {
			owner: r.target,
			zi: t
		});
		return .5 + (i ? i.set.cards.length * 1.5 : 0);
	}
	if (r.type !== "take") return -1;
	let i = e.twoPlayer ? r.zone ?? 0 : 0, a = e.sets[r.target]?.[i];
	if (!a) return -1;
	let o = [...t, ...a.cards.map((e) => ({
		id: e.id,
		up: e.up ^ 1
	}))], s = Math.max(0, ...[...Y(o).values()].map((e) => e.length)), c = Math.max(0, ...[...Y(t).values()].map((e) => e.length));
	return s >= c + 2 ? (s - c) * .8 - a.cards.length * .5 : -1;
}
var he = (e, t) => {
	let n = e.public;
	if (n.phase === "roundOver") {
		let e = n.players.find((e) => e.rid === t.rid);
		return e && !e.decided ? { action: { type: "next" } } : null;
	}
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	let r = e.private?.hand ?? [];
	if (r.length === 0) return null;
	let i = pe(n, r, t.rid);
	if (t.difficulty === "weak") return { action: fe(i) };
	let a = i[0], o = -Infinity;
	for (let e of i) {
		let i = me(n, r, t.rid, e);
		i > o && (o = i, a = e);
	}
	return { action: a };
}, ge = (e, t, n) => {
	if (e.type === "next") return n("games.dnup.nextRound");
	if (e.type === "rotate") return n("games.dnup.hintRotate");
	if (e.type === "play") {
		let r = (t.private?.hand ?? []).find((t) => t.id === e.cards[0]);
		return n("games.dnup.hintPlay", {
			n: e.cards.length,
			v: r ? A(r) : 0
		});
	}
	let r = t.public.twoPlayer ? e.zone ?? 0 : 0, i = t.public.sets[e.target]?.[r];
	return e.type === "add" ? n("games.dnup.hintAdd", { v: i?.value ?? 0 }) : n("games.dnup.hintTake", {
		v: i?.value ?? 0,
		n: i?.cards.length ?? 0
	});
};
//#endregion
//#region src/games/dnup/fx.tsx
function _e(e, t, n) {
	let r = Math.max(1, e.h - 4), i = r <= 46 ? 32 : r * 40 / 58, a = n * i + (n - 1) * 2;
	return {
		x: e.x + (e.w - a) / 2 + t * (i + 2),
		y: e.y + 2,
		w: i,
		h: r
	};
}
function ve(e, t, n) {
	let r = Math.max(64, Math.min(180, (e.h - 4) * 40 / 58, (e.w - 4 - (n - 1) * 2) / n)), i = Math.floor(r * 100) / 100, a = i * 58 / 40, o = n * i + (n - 1) * 2;
	return {
		x: e.x + Math.max(2, (e.w - o) / 2) + t * (i + 2),
		y: e.y + (e.h - a) / 2,
		w: i,
		h: a
	};
}
function X(e, t) {
	if (!t) return "inset(0%)";
	let n = (e, t) => Math.max(0, Math.min(100, e / t * 100));
	return `inset(${n(t.y - e.y, e.h)}% ${n(e.x + e.w - t.x - t.w, e.w)}% ${n(e.y + e.h - t.y - t.h, e.h)}% ${n(t.x - e.x, e.w)}%)`;
}
function Z({ from: e, to: t, card: r, back: a, size: o = "table", ms: s, delay: c = 0, fromClip: l, toClip: u }) {
	let d = i(null), f = e.w > t.w ? e : t;
	n(() => {
		let n = d.current;
		if (!n) return;
		let r = t.x - e.x, i = t.y - e.y, a = e.w / f.w, o = e.h / f.h, p = t.w / f.w, m = t.h / f.h, h = l !== void 0 || u !== void 0, g = n.animate([
			{
				transform: `translate(0px, 0px) scale(${a}, ${o})`,
				...h ? { clipPath: X(e, l) } : {}
			},
			{
				transform: `translate(${r * .55}px, ${i * .55 - 14}px) scale(${(a + p) / 2}, ${(o + m) / 2})`,
				offset: .55,
				...h ? { clipPath: "inset(0%)" } : {}
			},
			{
				transform: `translate(${r}px, ${i}px) scale(${p}, ${m})`,
				...h ? { clipPath: X(t, u) } : {}
			}
		], {
			duration: s,
			delay: c,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => g.cancel();
	}, [
		e,
		t,
		f,
		s,
		c,
		l,
		u
	]);
	let p = {
		width: f.w,
		height: f.h
	};
	return /* @__PURE__ */ g("div", {
		ref: d,
		className: "absolute",
		style: {
			left: e.x,
			top: e.y,
			...p,
			transformOrigin: "0 0"
		},
		children: a ? /* @__PURE__ */ g(G, { style: p }) : r && /* @__PURE__ */ g(W, {
			card: r,
			size: o,
			style: p
		})
	});
}
function ye(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Q(e, t) {
	return t ? e.anchor(`stock:${t}`) ?? ye(e, t) : null;
}
function be({ from: e, card: t, delay: r, ms: a }) {
	let o = i(null);
	return n(() => {
		let t = o.current;
		if (!t) return;
		let n = t.animate([
			{
				opacity: 1,
				transform: "translateX(0)"
			},
			{
				opacity: .8,
				transform: `translateX(${Math.max(32, e.w * .8)}px)`,
				offset: .5
			},
			{
				opacity: 0,
				transform: `translateX(${Math.max(72, e.w * 1.8)}px)`
			}
		], {
			duration: a,
			delay: r,
			easing: "ease-in",
			fill: "both"
		});
		return () => n.cancel();
	}, [
		r,
		a,
		e.w
	]), /* @__PURE__ */ g("div", {
		ref: o,
		className: "dnup-fx-discard-slide absolute",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ g(W, {
			card: t,
			size: "table",
			style: {
				width: e.w,
				height: e.h
			}
		})
	});
}
function xe({ at: e, ms: t }) {
	let r = i(null);
	return n(() => {
		let n = r.current?.querySelectorAll(".dnup-fx-rotate-card");
		if (!n) return;
		let i = Array.from(n, (n, r) => n.animate([
			{
				transform: "translateY(0) rotate(0deg)",
				opacity: 1
			},
			{
				transform: `translateY(${r * e.h * .32}px) rotate(18deg)`,
				opacity: 1,
				offset: .36
			},
			{
				transform: `translateY(${r * e.h * .32}px) rotate(180deg)`,
				opacity: 1,
				offset: .76
			},
			{
				transform: "translateY(0) rotate(180deg)",
				opacity: 0
			}
		], {
			duration: t,
			easing: "ease-in-out",
			fill: "both"
		}));
		return () => i.forEach((e) => e.cancel());
	}, [t, e.h]), /* @__PURE__ */ g("div", {
		ref: r,
		className: "dnup-fx-rotate-stock absolute",
		style: {
			left: e.x - e.w / 3,
			top: e.y,
			width: e.w * 4 / 3,
			height: e.h + 4
		},
		children: [
			0,
			1,
			2
		].map((t) => /* @__PURE__ */ g("span", {
			className: "dnup-fx-rotate-card",
			style: {
				width: e.w,
				height: e.h,
				left: t * e.w / 6,
				top: (2 - t) * e.h * .08
			}
		}, t))
	});
}
function Se(e) {
	return !Array.isArray(e) || !e.every((e) => typeof e == "object" && !!e && typeof e.id == "number") ? null : e;
}
function Ce(e) {
	return typeof e == "object" && e && typeof e.id == "number" ? e : null;
}
function we(e) {
	if (typeof e != "object" || !e) return null;
	let t = e, n = Se(t.cards);
	return typeof t.zi == "number" && n ? {
		zi: t.zi,
		cards: n
	} : null;
}
function Te(e) {
	if (typeof e != "object" || !e) return null;
	let t = e, n = we(e);
	return typeof t.owner == "string" && n ? {
		...n,
		owner: t.owner,
		toPile: t.toPile === !0
	} : null;
}
var Ee = {
	nodes: [],
	hide: [],
	dur: 0
};
function $(e, t, n, r, i) {
	let a = e.anchor(`set:${t.owner}:${t.zi}`);
	if (!a) return Ee;
	let o = r + (t.cards.length - 1) * i;
	return {
		nodes: t.cards.map((e, o) => /* @__PURE__ */ g(be, {
			from: _e(a, o, t.cards.length),
			card: e,
			ms: r,
			delay: n + o * i
		}, `p${e.id}`)),
		hide: [],
		dur: o
	};
}
function De(e, t, n, r, i, a) {
	let o = e.anchor(`set:${t.owner}:${t.zi}`);
	if (!o) return Ee;
	let s = Q(e, n);
	if (!s) return Ee;
	let c = n === e.myRid, l = [], u = [];
	return t.cards.forEach((n, d) => {
		c && e.anchor(`hand:${n.id}`) && u.push(`hand:${n.id}`), l.push(/* @__PURE__ */ g(Z, {
			from: _e(o, d, t.cards.length),
			to: s,
			card: n,
			ms: i,
			delay: r + d * a
		}, `b${n.id}`));
	}), l.length ? {
		nodes: l,
		hide: u,
		dur: i + (t.cards.length - 1) * a
	} : Ee;
}
function Oe(e, t, n) {
	let r = e.rid;
	if (!r) return null;
	let i = e.data ?? {}, a = t.queued > 0, o = k, s = a ? 220 : o.fly, c = a ? 0 : o.stagger, l = [], u = [], d = 0, f = (e) => {
		l.push(...e.nodes), u.push(...e.hide), d += e.dur;
	};
	if (n === "play") {
		let e = Se(i.cards), n = typeof i.zi == "number" ? i.zi : 0, f = Q(t, r);
		if (e && f) {
			if (i.selfBounce === !0) {
				let i = t.anchor(`set:${r}:${n}`);
				if (i) {
					let p = t.anchor(`set-area:${r}:${n}`), m = t.anchor(`set-zone:${r}:${n}`), h = p && p.w > 0 && p.h > 0 && m ? {
						x: m.x,
						y: m.y + 48,
						w: m.w,
						h: Math.max(0, m.h - 48)
					} : void 0, _ = t.myRid === r;
					e.forEach((n, r) => {
						let p = h ? ve(h, r, e.length) : _e(i, r, e.length), m = f;
						l.push(/* @__PURE__ */ g(Z, {
							from: f,
							to: p,
							toClip: h,
							card: n,
							ms: s,
							delay: d + r * c
						}, `f${n.id}`)), m && (_ && t.anchor(`hand:${n.id}`) && u.push(`hand:${n.id}`), l.push(/* @__PURE__ */ g(Z, {
							from: p,
							fromClip: h,
							to: m,
							card: n,
							ms: a ? 240 : o.bounce,
							delay: d + s + (e.length - 1) * c + r * c
						}, `r${n.id}`)));
					}), d += s + (a ? 240 : o.bounce) + (e.length - 1) * c * 2;
				}
			} else {
				let n = 0;
				e.forEach((e, r) => {
					let i = t.anchor(`tcard:${e.id}`);
					i && (u.push(`tcard:${e.id}`), l.push(/* @__PURE__ */ g(Z, {
						from: f,
						to: i,
						card: e,
						ms: s,
						delay: d + r * c
					}, `f${e.id}`)), n += 1);
				}), n && (d += s + (n - 1) * c);
			}
		}
	} else if (n === "add") {
		let e = Ce(i.card), n = Q(t, r), a = e ? t.anchor(`tcard:${e.id}`) : null;
		e && n && a && (u.push(`tcard:${e.id}`), l.push(/* @__PURE__ */ g(Z, {
			from: n,
			to: a,
			card: e,
			ms: s,
			delay: d
		}, "add")), d += s);
	} else {
		let e = Se(i.cards), n = typeof i.from == "string" ? i.from : null, a = typeof i.zi == "number" ? i.zi : 0;
		e && n && f(De(t, {
			owner: n,
			zi: a,
			cards: e
		}, r, d, s, c));
	}
	let p = Te(i.bounced);
	p && f(p.toPile ? $(t, p, d, a ? 240 : o.bounce, c) : De(t, p, p.owner, d, a ? 240 : o.bounce, c));
	let m = i.out;
	if (m === "first" || m === "second" || m === "win") {
		let e = ye(t, r);
		if (e && l.push(/* @__PURE__ */ g(y, {
			at: e,
			ms: a ? 300 : o.settle,
			delay: d
		}, "out")), Array.isArray(i.scores)) for (let e of i.scores) {
			if (typeof e?.rid != "string" || typeof e.n != "number") continue;
			let n = ye(t, e.rid);
			n && l.push(/* @__PURE__ */ g(v, {
				at: n,
				ms: a ? 500 : o.settle,
				delay: d + 100,
				children: /* @__PURE__ */ _("span", {
					className: "dnup-fx-score",
					style: { fontSize: Math.max(18, Math.min(48, n.h * 1.1)) },
					children: ["+", e.n]
				})
			}, `s${e.rid}`));
		}
		d += a ? 300 : o.settle;
	}
	let h = Te(i.expired);
	h && f($(t, h, d, a ? 200 : o.discard, c));
	let b = Te(i.cleared);
	return b && f($(t, b, d, a ? 200 : o.discard, c)), l.length ? {
		ms: d + o.tail,
		node: l,
		hide: a ? [] : u
	} : null;
}
var ke = {
	deal(e, t) {
		let n = t.queued > 0, r = n ? 240 : 320, i = n ? 18 : 45, a = e.secret, o = a ? Se(a.cards) : null, s = t.anchor("table");
		if (o) {
			if (!s) return null;
			let e = [], a = [];
			for (let [n, c] of o.entries()) {
				let o = t.anchor(`hand:${c.id}`);
				if (!o) continue;
				let l = {
					x: s.x + s.w / 2 - o.w / 2,
					y: s.y + s.h / 2 - o.h / 2,
					w: o.w,
					h: o.h
				};
				a.push(`hand:${c.id}`), e.push(/* @__PURE__ */ g(Z, {
					from: l,
					to: o,
					card: c,
					size: "hand",
					ms: r,
					delay: n * i
				}, c.id));
			}
			return e.length ? {
				ms: r + e.length * i,
				node: e,
				hide: n ? [] : a
			} : null;
		}
		let c = Q(t, e.rid);
		if (!s || !c) return null;
		let l = Math.max(40, c.w * 2), u = l * 58 / 40, d = {
			x: s.x + s.w / 2 - l / 2,
			y: s.y + s.h / 2 - u / 2,
			w: l,
			h: u
		}, f = e.data?.count, p = typeof f == "number" ? f : 8;
		return {
			ms: r + p * i,
			node: Array.from({ length: p }, (e, t) => /* @__PURE__ */ g(Z, {
				from: d,
				to: c,
				back: !0,
				ms: r,
				delay: t * i
			}, t))
		};
	},
	play(e, t) {
		return Oe(e, t, "play");
	},
	add(e, t) {
		return Oe(e, t, "add");
	},
	take(e, t) {
		return Oe(e, t, "take");
	},
	rotate(e, t) {
		let n = e.rid;
		if (!n) return null;
		let r = e.data ?? {}, i = t.queued > 0, a = k, o = i ? 0 : a.stagger, s = [], c = [], l = 0, u = Q(t, n);
		if (u) {
			let e = i ? 260 : 600;
			n === t.myRid ? s.push(/* @__PURE__ */ g(y, {
				at: u,
				ms: e
			}, "flip")) : (s.push(/* @__PURE__ */ g(xe, {
				at: u,
				ms: e
			}, "flip")), i || c.push(`stock:${n}`)), l += e;
		}
		for (let e of [r.expired, r.cleared]) {
			let n = Te(e);
			if (!n) continue;
			let r = $(t, n, l, i ? 200 : a.discard, o);
			s.push(...r.nodes), l += r.dur;
		}
		return s.length ? {
			ms: l + a.tail,
			node: s,
			hide: c
		} : null;
	}
}, Ae = [
	"d",
	"n",
	"u",
	"p"
];
function je(e, t, n, r) {
	let i = 0, a = 1;
	for (let o = 1; o <= n; o++) {
		let s = Math.ceil(n / o), c = Math.min((e - (o - 1) * r) / o, (t - (s - 1) * r) * 40 / 58 / s);
		c > i && (i = c, a = o);
	}
	return {
		width: Math.floor(Math.max(96, Math.min(360, i)) * 100) / 100,
		columns: a
	};
}
function Me({ result: e, public: t, members: r, myRid: a, onPlayAgain: o, onBackToLobby: u }) {
	let d = t, f = c(), p = s((e) => e.locale), v = i(null), y = i(null), S = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? m(t, p) : e;
	}, C = d.players.map((e) => {
		let t = d.sets[e.rid] ?? [];
		return {
			player: e,
			sets: t,
			filled: t.filter((e) => e !== null && e.cards.length > 0).length
		};
	}), w = C.filter((e) => e.filled > 0), T = C.filter((e) => e.filled === 0);
	n(() => {
		let e = v.current, t = y.current;
		if (!e || !t) return;
		let n = [...t.querySelectorAll(".dnup-over-board")], r = [...t.querySelectorAll(".dnup-over-area")], i = t.querySelector(".dnup-over-table-list"), a = t.querySelector(".dnup-over-empty-list"), o = (e, t, n) => {
			e.style.getPropertyValue(t) !== n && e.style.setProperty(t, n);
		}, s = (e, t = "y") => {
			let n = getComputedStyle(e);
			return t === "x" ? Number.parseFloat(n.paddingLeft) + Number.parseFloat(n.paddingRight) + Number.parseFloat(n.borderLeftWidth) + Number.parseFloat(n.borderRightWidth) : Number.parseFloat(n.paddingTop) + Number.parseFloat(n.paddingBottom) + Number.parseFloat(n.borderTopWidth) + Number.parseFloat(n.borderBottomWidth);
		}, c = () => {
			if (!i) return;
			if (getComputedStyle(e).getPropertyValue("--dnup-over-wide").trim() !== "1") {
				i.style.removeProperty("--dnup-over-row-height"), i.style.removeProperty("--dnup-over-board-columns"), delete i.dataset.columns;
				for (let e of r) e.style.removeProperty("--dnup-over-card-w"), e.style.removeProperty("--dnup-over-columns");
				return;
			}
			let c = Math.max(0, t.clientHeight - (a ? a.offsetHeight + 12 : 0)), l = n.map((e) => {
				let t = e.querySelector(".dnup-over-board-name"), n = [...e.querySelectorAll(".dnup-over-area")], r = n.filter((e) => Number(e.dataset.count) > 0), i = n.filter((e) => Number(e.dataset.count) === 0).reduce((e, t) => e + t.offsetHeight + 12, 0), a = s(e) + t.offsetHeight + 10 + i;
				return {
					inline: s(e, "x"),
					filled: r.map((e) => {
						let t = e.querySelector("h3");
						return {
							area: e,
							inline: s(e, "x"),
							count: Number(e.dataset.count),
							chrome: a + s(e) + t.offsetHeight + 8
						};
					})
				};
			}), u = [];
			for (let e = 1; e <= Math.min(2, n.length); e++) {
				let t = Math.ceil(n.length / e), r = (c - (t - 1) * 12) / t, a = l.flatMap((t, r) => {
					let a = (e === 2 && n.length % 2 == 1 && r === n.length - 1 ? i.clientWidth : (i.clientWidth - (e - 1) * 12) / e) - t.inline;
					return t.filled.map((e) => ({
						...e,
						width: (a - (t.filled.length - 1) * 12) / t.filled.length - e.inline
					}));
				}), o = Math.max(0, r);
				for (let e of a) {
					let t = Math.max(1, Math.min(e.count, Math.floor((e.width + 12) / 108))), n = Math.ceil(e.count / t);
					o = Math.max(o, e.chrome + n * 96 * 58 / 40 + (n - 1) * 12);
				}
				o = Math.ceil(o);
				let s = a.map((e) => ({
					...e,
					fit: je(e.width, o - e.chrome, e.count, 12)
				}));
				u.push({
					columns: e,
					height: o,
					fitted: s,
					overflow: Math.max(0, t * o + (t - 1) * 12 - c),
					minimum: Math.min(...s.map((e) => e.fit.width))
				});
			}
			u.sort((e, t) => {
				let n = e.overflow < 2;
				return n === t.overflow < 2 ? !n && Math.abs(e.overflow - t.overflow) >= 2 ? e.overflow - t.overflow : t.minimum - e.minimum : n ? -1 : 1;
			});
			let d = u[0];
			if (d) {
				o(i, "--dnup-over-row-height", `${d.height}px`), o(i, "--dnup-over-board-columns", String(d.columns)), i.dataset.columns = String(d.columns);
				for (let e of d.fitted) o(e.area, "--dnup-over-card-w", `${e.fit.width}px`), o(e.area, "--dnup-over-columns", String(e.fit.columns));
			}
		};
		c();
		let l = new ResizeObserver(c);
		for (let n of [
			e,
			t,
			a,
			...r
		]) n && l.observe(n);
		return () => l.disconnect();
	}, [
		d.players,
		d.sets,
		p
	]);
	let E = o ?? u;
	return /* @__PURE__ */ g("div", {
		className: "dnup-over",
		children: /* @__PURE__ */ _("div", {
			ref: v,
			className: "dnup-over-layout",
			"data-players": d.players.length,
			children: [
				e.winner.length > 0 && /* @__PURE__ */ g(ee, {}),
				/* @__PURE__ */ _("header", {
					className: "dnup-over-heading",
					children: [
						/* @__PURE__ */ g("strong", {
							"aria-hidden": !0,
							children: "dnup"
						}),
						/* @__PURE__ */ g("h1", { children: f("games.dnup.resultTitle") }),
						/* @__PURE__ */ g("span", { children: f("games.dnup.roundStage", { n: d.round }) })
					]
				}),
				/* @__PURE__ */ _("div", {
					className: "dnup-over-main",
					children: [/* @__PURE__ */ g("ol", {
						className: "dnup-over-ranking",
						style: { "--dnup-over-players": e.ranking.length },
						children: e.ranking.map((t, n) => {
							let i = d.players.find((e) => e.rid === t), o = r.find((e) => e.rid === t), s = S(t), c = e.scores?.[t] ?? (d.twoPlayer ? i.roundWins : i.score), u = e.winner.includes(t), p = e.autopilot?.[t];
							return /* @__PURE__ */ _("li", {
								className: "dnup-over-player",
								"data-winner": u,
								children: [
									/* @__PURE__ */ g("span", {
										className: "dnup-over-avatar",
										style: { background: l[(o?.colorIndex ?? 0) % l.length].hex },
										children: o && /* @__PURE__ */ g("img", {
											src: b[o.avatar % b.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ _("div", {
										className: "dnup-over-person",
										children: [
											/* @__PURE__ */ _("h2", {
												title: s,
												children: [
													/* @__PURE__ */ _("span", { children: [n + 1, "."] }),
													" ",
													s
												]
											}),
											/* @__PURE__ */ _("div", {
												className: "dnup-over-person-flags",
												children: [t === a && /* @__PURE__ */ g("small", { children: f("lobby.you") }), u && /* @__PURE__ */ g("b", { children: f("games.dnup.resultWinner") })]
											}),
											p !== void 0 && p > 0 && /* @__PURE__ */ _("small", {
												className: "dnup-over-autopilot",
												children: [/* @__PURE__ */ g(x, { size: 14 }), f("session.autopilot.share", { n: Math.round(p * 100) })]
											})
										]
									}),
									/* @__PURE__ */ _("div", {
										className: "dnup-over-score",
										"aria-label": f(d.twoPlayer ? "games.dnup.resultWinsProgress" : "games.dnup.resultLettersProgress", { n: c }),
										children: [
											/* @__PURE__ */ g("span", { children: f(d.twoPlayer ? "games.dnup.resultWins" : "games.dnup.resultLetters") }),
											/* @__PURE__ */ _("strong", { children: [c, /* @__PURE__ */ _("small", { children: [" / ", d.twoPlayer ? 2 : 4] })] }),
											/* @__PURE__ */ g("span", {
												className: `dnup-score-track ${d.twoPlayer ? "dnup-wins" : ""}`,
												"aria-hidden": !0,
												children: d.twoPlayer ? [0, 1].map((e) => /* @__PURE__ */ g("i", { className: `dnup-win-dot ${e < c ? "is-earned" : ""}` }, e)) : Ae.map((e, t) => /* @__PURE__ */ g("i", {
													className: `dnup-letter ${t < c ? "is-earned" : ""}`,
													children: e
												}, e))
											})
										]
									})
								]
							}, t);
						})
					}), /* @__PURE__ */ _("section", {
						className: "dnup-over-table",
						children: [
							/* @__PURE__ */ g("h2", { children: f("games.dnup.resultTable") }),
							d.roundResult && /* @__PURE__ */ g("div", {
								className: "dnup-over-round",
								children: d.twoPlayer ? /* @__PURE__ */ g("p", { children: f("games.dnup.roundWin2p", { name: S(d.roundResult.first) }) }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("p", { children: f("games.dnup.firstOut", { name: S(d.roundResult.first) }) }), d.roundResult.second && /* @__PURE__ */ g("p", { children: f("games.dnup.secondOut", { name: S(d.roundResult.second) }) })] })
							}),
							/* @__PURE__ */ _("div", {
								ref: y,
								className: "dnup-over-table-scroll",
								children: [T.length > 0 && /* @__PURE__ */ g("div", {
									className: "dnup-over-empty-list",
									children: T.map(({ player: e, sets: t }) => /* @__PURE__ */ _("section", {
										className: "dnup-over-empty-player",
										children: [/* @__PURE__ */ g("h3", {
											title: S(e.rid),
											children: S(e.rid)
										}), /* @__PURE__ */ g("div", {
											className: "dnup-over-empty-zones",
											children: d.twoPlayer ? t.map((e, t) => /* @__PURE__ */ _("p", { children: [
												f(t === 0 ? "games.dnup.zone1" : "games.dnup.zone2"),
												" · ",
												f("games.dnup.emptyArea")
											] }, t)) : /* @__PURE__ */ g("p", { children: f("games.dnup.emptyArea") })
										})]
									}, e.rid))
								}), w.length > 0 && /* @__PURE__ */ g("div", {
									className: "dnup-over-table-list",
									children: w.map(({ player: e, sets: t, filled: n }) => /* @__PURE__ */ _("section", {
										className: "dnup-over-board",
										children: [/* @__PURE__ */ g("h2", {
											className: "dnup-over-board-name",
											title: S(e.rid),
											children: S(e.rid)
										}), /* @__PURE__ */ g("div", {
											className: "dnup-over-areas",
											"data-two": d.twoPlayer,
											"data-filled": n,
											children: t.map((e, t) => /* @__PURE__ */ _("div", {
												className: "dnup-over-area",
												"data-count": e?.cards.length ?? 0,
												children: [/* @__PURE__ */ _("h3", { children: [d.twoPlayer && /* @__PURE__ */ _("span", { children: [f(t === 0 ? "games.dnup.zone1" : "games.dnup.zone2"), e ? " · " : ""] }), e && f("games.dnup.setReadout", {
													v: e.value,
													n: e.cards.length
												})] }), e ? /* @__PURE__ */ g("div", {
													className: "dnup-over-cards",
													children: e.cards.map((e) => /* @__PURE__ */ g(W, {
														card: e,
														size: "table"
													}, e.id))
												}) : /* @__PURE__ */ g("p", {
													className: "dnup-over-empty",
													children: f("games.dnup.emptyArea")
												})]
											}, t))
										})]
									}, e.rid))
								})]
							})
						]
					})]
				}),
				E ? /* @__PURE__ */ _("div", {
					className: "dnup-over-actions safe-b",
					children: [o && /* @__PURE__ */ g("button", {
						type: "button",
						onClick: o,
						children: f("session.result.playAgain")
					}), u && /* @__PURE__ */ g("button", {
						type: "button",
						onClick: u,
						children: f("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ g("p", {
					className: "dnup-over-wait safe-b",
					children: f("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/dnup/entry.tsx
var Ne = {
	definition: V,
	View: se,
	bot: he,
	describe: ge,
	fx: ke,
	OverView: Me,
	locales: {
		zh: {
			name: "反转王牌",
			desc: "双端数字牌:压场、塞牌、整套反转,先出空手牌拿到字母标记",
			rules: "目标:最先获得至少 4 个字母标记的玩家获胜。\n牌与设置:\n· 每张牌两端各有一个 1 到 10 的点数,有效点数朝上,无效点数朝下;旋转 180° 后两端互换。\n· 按人数移除带设置标记的牌后,混洗全部牌并发完;持 ★ 牌的玩家开始本轮。\n回合:先弃掉自己面前的牌组,再从四个行动中执行一个:\n· 打出牌组:同点数的手牌任意张放到自己面前;桌上已有同规模牌组时,点数必须更大,被压的牌组旋转后回到主人手牌。\n· 加牌:恰好一张加入对手面前的牌组,点数必须相同;加入后与桌上另一牌组同规模时,目标牌组点数必须更大。\n· 拿取:拿走一位对手面前的整套牌组,每张旋转后加入自己手牌。\n· 旋转:自己全部手牌翻转,有效与无效点数互换。\n轮末:首位将手牌全部打出的玩家获得 2 个字母标记,该玩家的牌组继续留在场上一个完整的行动周期;第二位将手牌全部打出的玩家获得 1 个,本轮立即结束并重新洗牌发牌。\n双人变体:每人两个游戏区,连续行动两回合;与自家另一区同规模且点数更低的牌组会弹回手牌;率先将手牌全部打出的玩家赢得本轮；率先赢得两轮的玩家获得游戏胜利。",
			roundStage: "第 {{n}} 轮",
			turnYou: "轮到你",
			turnWait: "等待 {{name}}",
			zone1: "1 号区",
			zone2: "2 号区",
			outStay: "已出空",
			setReadout: "点数 {{v}} · {{n}} 张",
			play: "打出",
			playCount: "打出 {{n}} 张",
			add: "加入",
			addToSet: "加入此牌组",
			playBounceHint: "打出后弹回",
			playDiscardHint: "打出后弃掉",
			addBounceHint: "加至 {{n}} 张组后弹回",
			addDiscardHint: "加至 {{n}} 张组后弃掉",
			selfBounce: "打出后，这组牌会弹回手牌",
			take: "拿取",
			rotateAll: "旋转",
			cancel: "取消",
			pickCards: "点选同点数的手牌,或点选对手牌组",
			targetPicked: "已选 {{name}} 的牌组",
			badSame: "所选牌点数不同",
			mismatch: "所加牌点数须与牌组相同",
			tooWeak: "打出点数须高于同张数牌组",
			addTooWeak: "加入后须高于同张数牌组",
			roundOverTitle: "本轮结束",
			firstOut: "{{name}}  +2 字母",
			secondOut: "{{name}}  +1 字母",
			roundWin2p: "{{name}} 赢下本轮",
			nextRound: "进入下一轮",
			showFinal: "查看最终结算",
			roundWaiting: "等待其他玩家",
			handLabel: "手牌",
			stripHand: "{{n}} 张",
			letters: "字母标记 {{n}}",
			wins2p: "胜场 {{n}}",
			cardAria: "有效点数 {{a}},无效点数 {{b}}",
			setAria: "{{name}} 的牌组,点数 {{v}},{{n}} 张",
			emptyArea: "无牌组",
			resultTitle: "最终结算",
			resultTable: "最终回合牌组",
			resultWinner: "获胜者",
			resultWins: "胜场",
			resultLetters: "字母标记",
			resultWinsProgress: "胜场 {{n}} / 2",
			resultLettersProgress: "字母标记 {{n}} / 4",
			errNotYourTurn: "现在轮不到你",
			errBadCards: "所选牌点数不同",
			errTooWeak: "桌上有同规模牌组,点数必须更大",
			errBadTarget: "只能指定对手面前的牌组",
			errNoSet: "目标面前没有牌组",
			errBadCard: "所加牌点数须与牌组相同",
			hintPlay: "打出 {{n}} 张 {{v}} 点的牌组",
			hintAdd: "把 1 张 {{v}} 点加入对手的牌组",
			hintTake: "拿走对手点数 {{v}} 的整套牌组({{n}} 张)",
			hintRotate: "旋转全部手牌"
		},
		en: {
			name: "Dnup",
			desc: "Double-ended number cards: beat sets, sneak cards in, steal whole sets — empty your hand for letter tokens",
			rules: "Goal: the first player to collect at least 4 letter tokens wins.\nCards and setup:\n· Each card has a value from 1 to 10 on both ends; the active value faces up, the inactive value faces down, and rotating a card 180° swaps them.\n· After removing the marked setup cards for the player count, shuffle the whole deck and deal it all out; the player holding the ★ card starts the round.\nTurn: first discard the set in front of you, then perform exactly one of four actions:\n· Play a set: place any number of same-value cards in front of you; if a set of the same size is on the table, your value must be higher, and the beaten set rotates back into its owner's hand.\n· Add: put exactly one card onto an opponent's set with a matching value; if it then matches another set's size, the target set's value must be higher.\n· Take: take an opponent's whole set, rotating each card into your hand.\n· Rotate: flip all your hand cards, swapping active and inactive values.\nRound end: the first player to empty their hand gains 2 letter tokens and their set stays for one more turn cycle; the second gains 1 token and the round ends immediately with a full reshuffle and redealt hand.\nTwo-player variant: each player has two play areas and takes two consecutive turns; a set matching your other area's size with a lower value bounces back to your hand; emptying your hand wins the round, and the first to win two rounds wins the game.",
			roundStage: "Round {{n}}",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}",
			zone1: "Area 1",
			zone2: "Area 2",
			outStay: "Out",
			setReadout: "Value {{v}} · {{n}} cards",
			play: "Play set",
			playCount: "Play {{n}} cards",
			add: "Add",
			addToSet: "Add to this set",
			playBounceHint: "Play → returns",
			playDiscardHint: "Play → discarded",
			addBounceHint: "Add to {{n}}-card set → returns",
			addDiscardHint: "Add to {{n}}-card set → discarded",
			selfBounce: "Playing this set returns it to your hand",
			take: "Take set",
			rotateAll: "Rotate",
			cancel: "Cancel",
			pickCards: "Tap same-value cards, or an opponent's set",
			targetPicked: "Selected {{name}}'s set",
			badSame: "Selected cards differ in value",
			mismatch: "The added card must match the set value",
			tooWeak: "Play value must beat the same-size set",
			addTooWeak: "The grown set must beat the same-size set",
			roundOverTitle: "Round over",
			firstOut: "{{name}}  +2 letters",
			secondOut: "{{name}}  +1 letter",
			roundWin2p: "{{name}} wins the round",
			nextRound: "Next round",
			showFinal: "Final results",
			roundWaiting: "Waiting for other players",
			handLabel: "Hand",
			stripHand: "{{n}} cards",
			letters: "Letter tokens {{n}}",
			wins2p: "Rounds won {{n}}",
			cardAria: "Active value {{a}}, inactive value {{b}}",
			setAria: "{{name}}'s set, value {{v}}, {{n}} cards",
			emptyArea: "No set",
			resultTitle: "Final results",
			resultTable: "Final round sets",
			resultWinner: "Winner",
			resultWins: "Rounds won",
			resultLetters: "Letter tokens",
			resultWinsProgress: "Rounds won {{n}} / 2",
			resultLettersProgress: "Letter tokens {{n}} / 4",
			errNotYourTurn: "Not your turn",
			errBadCards: "Selected cards differ in value",
			errTooWeak: "A same-size set exists; your value must be higher",
			errBadTarget: "Only an opponent's set can be targeted",
			errNoSet: "No set in front of the target",
			errBadCard: "The added card must match the set value",
			hintPlay: "Play a set of {{n}} cards of value {{v}}",
			hintAdd: "Add one card of value {{v}} to an opponent's set",
			hintTake: "Take the opponent's set of value {{v}} ({{n}} cards)",
			hintRotate: "Rotate your whole hand"
		}
	}
};
//#endregion
export { Ne as default };
