import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { Texture as l } from "@bgparty/sdk/texture";
import { DeltaNumber as u } from "@bgparty/sdk/fx/delta-number";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { jsx as h, jsxs as g } from "react/jsx-runtime";
import { IconBot as _, IconMirror as v, IconRotate as y } from "@bgparty/sdk/icons";
import { botAvatarOf as b } from "@bgparty/sdk/lobby";
import { botPersonality as x } from "@bgparty/sdk/bot-personality";
import { PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { AVATARS as C } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as w } from "@bgparty/sdk/player-colors";
import { Confetti as T } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as E } from "@bgparty/sdk/ui/game-over-screen";
var D = [
	"green",
	"orange",
	"purple",
	"blue",
	"pink"
], O = /* @__PURE__ */ new Set([
	18,
	23,
	24,
	32,
	33,
	46,
	55,
	60
]), k = [
	10,
	10,
	10,
	5,
	10
], A = [
	[
		0,
		0,
		0,
		2
	],
	[
		0,
		1,
		0,
		2
	],
	[
		0,
		2,
		0,
		2
	],
	[
		0,
		3,
		0,
		2
	],
	[
		0,
		4,
		0,
		2
	],
	[
		0,
		5,
		0,
		2
	],
	[
		1,
		6,
		0,
		5
	],
	[
		1,
		7,
		0,
		5
	],
	[
		1,
		8,
		0,
		5
	],
	[
		2,
		0,
		3,
		8
	],
	[
		2,
		1,
		3,
		8
	],
	[
		2,
		2,
		3,
		4
	],
	[
		2,
		2,
		7,
		8
	],
	[
		3,
		3,
		3,
		4
	],
	[
		3,
		4,
		3,
		5
	],
	[
		3,
		5,
		3,
		5
	],
	[
		4,
		3,
		7,
		8
	],
	[
		4,
		4,
		6,
		8
	],
	[
		4,
		5,
		6,
		8
	],
	[
		4,
		6,
		6,
		8
	],
	[
		4,
		7,
		6,
		8
	],
	[
		4,
		8,
		6,
		8
	]
], j = (() => {
	let e = Array(81).fill(-1);
	for (let [t, n, r, i] of A) for (let a = r; a <= i; a++) e[n * 9 + a] = t;
	for (let t of O) e[t] = -1;
	return e;
})(), M = (() => {
	let e = k.map(() => []);
	for (let t = 0; t < 81; t++) j[t] >= 0 && e[j[t]].push(t);
	return e;
})();
function ee(e, t) {
	return j[e * 9 + t] !== j[(e + 1) * 9 + t];
}
function te(e, t) {
	return j[e * 9 + t] !== j[e * 9 + t + 1];
}
//#endregion
//#region src/games/mindspace/cards.ts
var N = [
	[[0, 0], [1, 0]],
	[
		[0, 0],
		[1, 0],
		[2, 0]
	],
	[
		[0, 0],
		[0, 1],
		[1, 1]
	],
	[
		[0, 0],
		[1, 0],
		[2, 0],
		[3, 0]
	],
	[
		[0, 0],
		[1, 0],
		[0, 1],
		[1, 1]
	],
	[
		[0, 0],
		[1, 0],
		[2, 0],
		[1, 1]
	],
	[
		[0, 0],
		[0, 1],
		[1, 1],
		[2, 1]
	],
	[
		[1, 0],
		[2, 0],
		[0, 1],
		[1, 1]
	],
	[
		[0, 0],
		[0, 1],
		[1, 1],
		[2, 1],
		[1, 2]
	],
	[
		[0, 0],
		[1, 0],
		[2, 0],
		[3, 0],
		[4, 0]
	],
	[
		[0, 0],
		[1, 0],
		[2, 0],
		[3, 0],
		[0, 1]
	],
	[
		[0, 0],
		[1, 0],
		[2, 0],
		[1, 1],
		[2, 1]
	],
	[
		[0, 0],
		[2, 0],
		[0, 1],
		[1, 1],
		[2, 1]
	],
	[
		[0, 0],
		[0, 1],
		[0, 2],
		[1, 2],
		[2, 2]
	],
	[
		[1, 0],
		[0, 1],
		[1, 1],
		[2, 1],
		[1, 2]
	],
	[
		[0, 0],
		[1, 0],
		[2, 0],
		[3, 0],
		[2, 1]
	],
	[
		[0, 0],
		[0, 1],
		[1, 1],
		[2, 1],
		[2, 2]
	]
], ne = [[0, 0], [1, 0]];
function P(e) {
	let t = e.map(([e, t]) => [e, t]), n = "";
	for (let e = 0; e < 2; e++) for (let r = 0; r < 4; r++) {
		let i = t.map(([t, n]) => {
			let i = e === 0 ? t : -t;
			switch (r) {
				case 0: return [i, n];
				case 1: return [-n, i];
				case 2: return [-i, -n];
				default: return [n, -i];
			}
		}), a = Math.min(...i.map((e) => e[0])), o = Math.min(...i.map((e) => e[1])), s = i.map(([e, t]) => `${e - a},${t - o}`).sort().join(";");
		(n === "" || s < n) && (n = s);
	}
	return n;
}
var F = (e, t) => e * 9 + t;
function I(e, t) {
	return O.has(t) || e.filled.has(t);
}
var re = [
	F(4, 0),
	F(4, 1),
	F(4, 2),
	F(5, 0),
	F(5, 2),
	F(6, 0),
	F(6, 2),
	F(7, 0),
	F(7, 1),
	F(7, 2)
], ie = [
	F(1, 4),
	F(1, 5),
	F(1, 6),
	F(1, 7),
	F(2, 4),
	F(2, 7),
	F(3, 4),
	F(3, 7),
	F(4, 4),
	F(4, 5),
	F(4, 6),
	F(4, 7)
];
function ae(e, ...t) {
	return t.every((t) => M[t].every((t) => I(e, t)));
}
var L = [
	{
		id: "sympathy",
		deck: "A",
		hi: 7,
		lo: 4,
		nameKey: "games.mindspace.goal.sympathy.name",
		descKey: "games.mindspace.goal.sympathy.desc",
		check: (e) => re.every((t) => I(e, t))
	},
	{
		id: "perfectDay",
		deck: "A",
		hi: 7,
		lo: 4,
		nameKey: "games.mindspace.goal.perfectDay.name",
		descKey: "games.mindspace.goal.perfectDay.desc",
		check: (e) => M.some((t) => D.every((n) => t.some((t) => e.filled.get(t) === n)))
	},
	{
		id: "overachiever",
		deck: "A",
		hi: 7,
		lo: 4,
		nameKey: "games.mindspace.goal.overachiever.name",
		descKey: "games.mindspace.goal.overachiever.desc",
		check: (e) => {
			for (let t = 0; t < 9; t++) {
				let n = !0;
				for (let r = 0; r < 9; r++) if (!I(e, F(t, r))) {
					n = !1;
					break;
				}
				if (n) return !0;
			}
			for (let t = 0; t < 9; t++) {
				let n = !0;
				for (let r = 0; r < 9; r++) if (!I(e, F(r, t))) {
					n = !1;
					break;
				}
				if (n) return !0;
			}
			return !1;
		}
	},
	{
		id: "serenity",
		deck: "B",
		hi: 11,
		lo: 6,
		nameKey: "games.mindspace.goal.serenity.name",
		descKey: "games.mindspace.goal.serenity.desc",
		check: (e) => M.filter((t) => t.every((t) => I(e, t)) && t.every((t) => e.filled.get(t) !== "green")).length >= 2
	},
	{
		id: "soulmate",
		deck: "B",
		hi: 9,
		lo: 5,
		nameKey: "games.mindspace.goal.soulmate.name",
		descKey: "games.mindspace.goal.soulmate.desc",
		check: (e) => M.every((t) => t.some((t) => e.filled.get(t) === "pink"))
	},
	{
		id: "adventure",
		deck: "C",
		hi: 9,
		lo: 5,
		nameKey: "games.mindspace.goal.adventure.name",
		descKey: "games.mindspace.goal.adventure.desc",
		check: (e) => ae(e, 0, 4)
	},
	{
		id: "lifeOfPeace",
		deck: "C",
		hi: 9,
		lo: 5,
		nameKey: "games.mindspace.goal.lifeOfPeace.name",
		descKey: "games.mindspace.goal.lifeOfPeace.desc",
		check: (e) => ae(e, 2, 1)
	},
	{
		id: "empathy",
		deck: "C",
		hi: 9,
		lo: 5,
		nameKey: "games.mindspace.goal.empathy.name",
		descKey: "games.mindspace.goal.empathy.desc",
		check: (e) => ie.every((t) => I(e, t))
	}
];
function oe(e) {
	return L.find((t) => t.id === e);
}
//#endregion
//#region src/games/mindspace/geo.ts
var se = (e, t) => e * 9 + t, R = (e) => Math.floor(e / 9), z = (e) => e % 9;
function ce(e) {
	let t = R(e), n = z(e), r = [];
	return t > 0 && r.push(e - 9), t < 8 && r.push(e + 9), n > 0 && r.push(e - 1), n < 8 && r.push(e + 1), r;
}
function le(e) {
	return P(e.map((e) => [z(e), R(e)]));
}
function B(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < 2; r++) for (let i = 0; i < 4; i++) {
		let a = e.map(([e, t]) => {
			let n = r === 0 ? e : -e;
			switch (i) {
				case 0: return [n, t];
				case 1: return [-t, n];
				case 2: return [-n, -t];
				default: return [t, -n];
			}
		}), o = Math.min(...a.map((e) => e[0])), s = Math.min(...a.map((e) => e[1])), c = a.map(([e, t]) => [e - o, t - s]), l = c.map((e) => e.join(",")).sort().join(";");
		t.has(l) || (t.add(l), n.push(c));
	}
	return n;
}
function ue(e) {
	let t = e.map(([e, t]) => [-t, e]), n = Math.min(...t.map(([e]) => e)), r = Math.min(...t.map(([, e]) => e));
	return t.map(([e, t]) => [e - n, t - r]);
}
function V(e, t) {
	let n = R(t), r = z(t), i = [];
	for (let [t, a] of e) {
		let e = n + a, o = r + t;
		if (e < 0 || e >= 9 || o < 0 || o >= 9) return null;
		let s = se(e, o);
		if (O.has(s)) return null;
		i.push(s);
	}
	return i;
}
function H(e, t, n, r) {
	for (let n of t) if (n < 0 || n >= 81 || O.has(n) || e.has(n)) return !1;
	if (r) return !0;
	let i = !1;
	for (let r of t) for (let t of ce(r)) {
		let r = e.get(t);
		if (r !== void 0 && (i = !0, r === n && n !== "black")) return !1;
	}
	return i;
}
//#endregion
//#region src/games/mindspace/meta.ts
var de = {
	id: "mindspace",
	tier: "released",
	mechanics: [
		"roll-and-write",
		"tile-placement",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.mindspace.name",
	descKey: "games.mindspace.desc",
	rulesKey: "games.mindspace.rules",
	icon: "🧠",
	iconImg: "games/mindspace.webp",
	rulesUrl: { en: "https://assets.allplay.com/board-games-mind-space-rulebook-link.pdf" },
	precacheAssets: ["brain-board.webp"],
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2],
	accent: "#7c3aed",
	releasedAt: "2026-09-12",
	search: {
		py: "xin ling kong jian",
		init: "xlkj"
	},
	hotseat: "cover"
}, fe = [
	0,
	3,
	6,
	10,
	15,
	20
], pe = [
	0,
	-4,
	-7,
	-9,
	-12,
	-16
];
function me(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) for (let e of t.cells) n.set(e, t.color);
	let r = (e) => O.has(e) || n.has(e), i = 0;
	for (let e = 0; e < k.length; e++) M[e].every(r) && (i += k[e]);
	let a = Object.values(t).reduce((e, t) => e + t, 0), o = /* @__PURE__ */ new Set(), s = 0;
	for (let t of e) if (t.color === "orange") {
		s += 1;
		for (let e of t.cells) o.add(e);
	}
	let c = fe[Math.min(s, 5)], l = 0;
	for (let t of e) if (t.color === "purple") for (let e of t.cells) ce(e).some((e) => o.has(e)) && (l += 2);
	let u = 0;
	for (let t of e) if (t.color === "pink") for (let n of e) n.color !== "pink" && n.shape === t.shape && (u += n.cells.length);
	let d = 0;
	for (let e = 0; e < k.length; e++) M[e].some((e) => n.get(e) === "blue") && (d += 1);
	let f = pe[5 - d], p = 0;
	for (let e = 0; e < k.length; e++) {
		let t = M[e].filter((e) => !r(e)).length;
		t > p && (p = t);
	}
	let m = -p, h = i + a + l + c + u + f + m;
	return {
		sections: i,
		goals: a,
		purple: l,
		orange: c,
		pink: u,
		blue: f,
		empty: m,
		total: h
	};
}
//#endregion
//#region src/games/mindspace/schema.ts
var U = [
	"green",
	"orange",
	"purple",
	"blue",
	"pink"
], he = t.enum(U), ge = t.enum([...U, "black"]), _e = t.int().min(0).max(80), W = t.union([t.int().min(1).max(5), t.literal("domino")]), G = t.object({
	slot: W,
	color: he,
	cells: t.array(_e).min(1).max(5),
	recolor: t.literal(!0).optional()
}), K = t.discriminatedUnion("type", [t.object({
	type: t.literal("submitTurn"),
	base: G.nullable(),
	extras: t.array(G).max(4),
	blacks: t.array(_e).max(9)
})]), ve = t.string(), ye = t.object({
	cells: t.array(_e).min(1).max(5),
	color: ge,
	shape: t.string()
}), q = t.object({
	sections: t.number(),
	goals: t.number(),
	purple: t.number(),
	orange: t.number(),
	pink: t.number(),
	blue: t.number(),
	empty: t.number(),
	total: t.number()
}), be = t.object({
	round: t.int().min(1).max(12),
	phase: t.enum(["draw", "done"]),
	row: t.tuple([
		t.int().min(0).max(16),
		t.int().min(0).max(16),
		t.int().min(0).max(16),
		t.int().min(0).max(16),
		t.int().min(0).max(16)
	]),
	dice: t.tuple([
		t.int().min(1).max(6),
		t.int().min(1).max(6),
		t.int().min(1).max(6),
		t.int().min(1).max(6),
		t.int().min(1).max(6)
	]),
	goals: t.array(t.object({
		id: t.string(),
		flipped: t.boolean()
	})).length(3),
	players: t.array(t.object({
		rid: ve,
		placements: t.array(ye),
		money: t.int().min(0).max(9),
		submitted: t.boolean(),
		goalScores: t.record(t.string(), t.number()),
		breakdown: q.optional()
	}))
}), xe = t.object({}), Se = t.object({ boardSide: t.enum(["A"]).default("A") }).default({ boardSide: "A" }), Ce = 1, we = 9, Te = 2, Ee = 3, De = 1;
function Oe(t, n, r) {
	let i = 0, a = Array.from({ length: N.length }, (e, t) => t);
	for (let t = a.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [a[t], a[n]] = [a[n], a[t]];
	}
	let o = [
		"A",
		"B",
		"C"
	].map((t) => {
		let n = L.filter((e) => e.deck === t);
		return {
			id: n[e(r, i++, n.length)].id,
			flipped: !1,
			claimed: !1
		};
	}), s = D.map(() => e(r, i++, 6) + 1), c = {};
	for (let e of n) c[e] = {
		placements: [],
		money: Ce,
		submitted: !1,
		goalScores: {}
	};
	return {
		state: {
			players: n,
			seed: r,
			rngCursor: i,
			round: 1,
			phase: "draw",
			row: a.slice(0, 5),
			deck: a.slice(6),
			dice: s,
			goals: o,
			boards: c
		},
		fx: []
	};
}
function J(e, t) {
	return D.filter((n, r) => e[r] === t);
}
function ke(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.placements) for (let e of n.cells) t.set(e, n.color);
	return t;
}
function Ae(e, t, n) {
	e.color === "green" && (t = Math.min(we, t + 1));
	for (let r of new Set(e.cells.map((e) => j[e]))) r >= 0 && M[r].every((e) => n.has(e)) && (t = Math.min(we, t + 1));
	return t;
}
function je(t, n, r) {
	if (t.phase !== "draw") return { code: "games.mindspace.errNotNow" };
	let i = t.boards[r.by];
	if (!i) return { code: "games.mindspace.errNotNow" };
	if (i.submitted) return { code: "games.mindspace.errAlready" };
	if (n.base === null && n.extras.length > 0) return { code: "games.mindspace.errNoBase" };
	let a = structuredClone(t), o = a.boards[r.by], s = ke(o), c = o.money, l = /* @__PURE__ */ new Set(), u = [], d = (e, t) => {
		let n = e.slot === "domino" ? P(ne) : P(N[a.row[e.slot - 1]]);
		if (new Set(e.cells).size !== e.cells.length || le(e.cells) !== n) return { code: "games.mindspace.errBadShape" };
		if (t) {
			if (e.recolor) {
				if (c < Te) return { code: "games.mindspace.errNoMoney" };
				c -= Te;
			} else if (e.slot !== "domino") {
				let t = J(a.dice, e.slot);
				if (t.length === 0) return { code: "games.mindspace.errNoDie" };
				if (!t.includes(e.color)) return { code: "games.mindspace.errBadColor" };
			}
		} else {
			if (e.slot === "domino" || e.recolor) return { code: "games.mindspace.errBadExtra" };
			if (!J(a.dice, e.slot).includes(e.color)) return { code: "games.mindspace.errBadColor" };
			if (l.has(e.color)) return { code: "games.mindspace.errColorUsed" };
			if (c < Ee) return { code: "games.mindspace.errNoMoney" };
			c -= Ee;
		}
		if (!H(s, e.cells, e.color, s.size === 0)) return { code: "games.mindspace.errBadPlace" };
		let r = {
			cells: [...e.cells],
			color: e.color,
			shape: n
		};
		for (let t of e.cells) s.set(t, e.color);
		return o.placements.push(r), u.push(r), l.add(e.color), c = Ae(r, c, s), null;
	};
	if (n.base) {
		let e = d(n.base, !0);
		if (e) return e;
	}
	for (let e of n.extras) {
		let t = d(e, !1);
		if (t) return t;
	}
	for (let e of n.blacks) {
		if (c < De) return { code: "games.mindspace.errNoMoney" };
		if (O.has(e) || s.has(e) || s.size === 0 || !ce(e).some((e) => s.has(e))) return { code: "games.mindspace.errBadPlace" };
		c -= De;
		let t = {
			cells: [e],
			color: "black",
			shape: "black"
		};
		s.set(e, "black"), o.placements.push(t), u.push(t), c = Ae(t, c, s);
	}
	o.money = c;
	let f = [], p = { filled: s };
	for (let e of a.goals) {
		if (e.id in o.goalScores) continue;
		let t = oe(e.id);
		if (!t || !t.check(p)) continue;
		let n = e.flipped ? t.lo : t.hi;
		o.goalScores[e.id] = n, e.claimed = !0, f.push({
			kind: "goal",
			rid: r.by,
			data: {
				id: e.id,
				points: n
			}
		});
	}
	if (o.submitted = !0, f.unshift({
		kind: "place",
		rid: r.by,
		data: { placements: u }
	}), a.players.every((e) => a.boards[e].submitted)) {
		for (let e of a.goals) e.claimed && !e.flipped && (e.flipped = !0), e.claimed = !1;
		if (a.round >= 12) a.phase = "done";
		else {
			a.round += 1, a.row.pop(), a.row.unshift(a.deck.shift()), a.dice = D.map(() => e(a.seed, a.rngCursor++, 6) + 1);
			for (let e of a.players) a.boards[e].submitted = !1;
			f.push({
				kind: "round",
				data: {
					round: a.round,
					dice: a.dice
				}
			});
		}
	}
	return {
		state: a,
		fx: f
	};
}
function Me(e) {
	let t = e.phase === "done";
	return {
		public: {
			round: e.round,
			phase: e.phase,
			row: e.row,
			dice: e.dice,
			goals: e.goals.map(({ id: e, flipped: t }) => ({
				id: e,
				flipped: t
			})),
			players: e.players.map((n) => {
				let r = e.boards[n];
				return {
					rid: n,
					placements: r.placements,
					money: r.money,
					submitted: r.submitted,
					goalScores: r.goalScores,
					...t ? { breakdown: me(r.placements, r.goalScores) } : {}
				};
			})
		},
		private: {}
	};
}
function Ne(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = new Map(e.players.map((t) => {
		let n = e.boards[t];
		return [t, me(n.placements, n.goalScores).total];
	})), n = [...e.players].sort((e, n) => (t.get(n) ?? 0) - (t.get(e) ?? 0)), r = t.get(n[0]) ?? 0;
	return {
		phase: "done",
		winner: n.filter((e) => t.get(e) === r),
		ranking: n,
		scores: Object.fromEntries(t)
	};
}
var Pe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: de,
	schemas: {
		action: K,
		publicView: be,
		privateView: xe,
		config: Se
	},
	setup: Oe,
	reduce: je,
	viewFor: Me,
	status: Ne
}, Y = {
	green: "#16a34a",
	orange: "#ea580c",
	purple: "#7c3aed",
	blue: "#2563eb",
	pink: "#ec4899",
	black: "#292524"
}, X = 100, Fe = 36, Ie = .92;
function Le(e, t, n) {
	if (!e) return null;
	let r = e.getBoundingClientRect(), i = Math.floor(((t - r.left) / r.width * 9 * X - Fe) / (X * Ie)), a = Math.floor(((n - r.top) / r.height * 9 * X - Fe) / (X * Ie));
	return a < 0 || a >= 9 || i < 0 || i >= 9 ? null : se(a, i);
}
function Re({ filled: e, staged: t, ghost: n, interactive: r, onCellDown: i, onCellMove: o, onCellUp: s, boardRef: c, selectedStagedKey: l, legalAnchors: u = [] }) {
	let d = a(null), f = a(!1), p = (e) => Le(d.current, e.clientX, e.clientY), m = /* @__PURE__ */ new Map();
	for (let e of t) for (let t of e.cells) m.set(t, e);
	return /* @__PURE__ */ g("svg", {
		ref: (e) => {
			d.current = e, c && (c.current = e);
		},
		viewBox: `0 0 ${9 * X} ${9 * X}`,
		className: `h-full max-h-full w-auto max-w-full touch-none select-none ${r ? "cursor-pointer" : ""}`,
		onPointerDown: (e) => {
			if (!r) return;
			let t = p(e);
			t !== null && (f.current = !0, e.currentTarget.setPointerCapture(e.pointerId), i?.(t, e));
		},
		onPointerMove: (e) => {
			f.current && o?.(p(e));
		},
		onPointerUp: (e) => {
			f.current && (f.current = !1, s?.(p(e), !1));
		},
		onPointerCancel: () => {
			f.current = !1, s?.(null, !0);
		},
		children: [
			/* @__PURE__ */ h("image", {
				href: "games/mindspace/brain-board.webp",
				width: 9 * X,
				height: 9 * X,
				preserveAspectRatio: "none",
				pointerEvents: "none"
			}),
			/* @__PURE__ */ g("g", {
				className: "mindspace-conscious-lines",
				pointerEvents: "none",
				fill: "none",
				children: [
					/* @__PURE__ */ h("path", { d: "M43 87 Q17 164 42 239 M858 76 Q880 155 855 239 M42 679 Q17 762 52 824 M855 668 Q880 752 845 826" }),
					/* @__PURE__ */ h("path", { d: "M72 31 Q160 12 236 38 M666 35 Q755 11 830 41 M93 862 Q161 881 230 858 M675 860 Q756 880 820 850" }),
					/* @__PURE__ */ h("circle", {
						cx: "67",
						cy: "67",
						r: "19"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "832",
						cy: "67",
						r: "19"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "67",
						cy: "833",
						r: "19"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "832",
						cy: "833",
						r: "19"
					})
				]
			}),
			/* @__PURE__ */ g("g", {
				transform: `translate(${Fe} ${Fe}) scale(${Ie})`,
				children: [
					Array.from({ length: 81 }, (t, n) => {
						let r = n % 9 * X, i = Math.floor(n / 9) * X;
						if (O.has(n)) return /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("rect", {
							x: r + 3,
							y: i + 3,
							width: 94,
							height: 94,
							rx: 7,
							fill: "#9b929e",
							stroke: "#493b49",
							strokeWidth: 5
						}), /* @__PURE__ */ h("path", {
							d: `M${r + 24} ${i + 19}l-10 27m30-29-10 27m30-29-10 27`,
							stroke: "#eee6ed",
							strokeWidth: 3,
							opacity: .55
						})] }, n);
						let a = e.get(n);
						return a ? /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("rect", {
							x: r + 3,
							y: i + 3,
							width: 94,
							height: 94,
							rx: 8,
							fill: Y[a],
							stroke: "#4a2740",
							strokeWidth: 5
						}), /* @__PURE__ */ h(ze, {
							color: a,
							x: r,
							y: i
						})] }, n) : null;
					}),
					[...m.entries()].map(([e, t]) => /* @__PURE__ */ h("rect", {
						x: e % 9 * X + 4,
						y: Math.floor(e / 9) * X + 4,
						width: 92,
						height: 92,
						fill: Y[t.color],
						fillOpacity: .55,
						strokeWidth: 5,
						strokeDasharray: "14 10",
						className: `mindspace-staged-cell stroke-ink ${l === t.key ? "is-selected" : ""}`
					}, `s${e}`)),
					[...m.entries()].map(([e, t]) => /* @__PURE__ */ h(ze, {
						color: t.color,
						x: e % 9 * X,
						y: Math.floor(e / 9) * X
					}, `sm${e}`)),
					u.map((e) => /* @__PURE__ */ h("circle", {
						cx: e % 9 * X + 80,
						cy: Math.floor(e / 9) * X + 80,
						r: 8,
						fill: "#2e9764",
						opacity: .7,
						pointerEvents: "none"
					}, `a${e}`)),
					n?.cells.map((e) => /* @__PURE__ */ h("rect", {
						x: e % 9 * X + 4,
						y: Math.floor(e / 9) * X + 4,
						width: 92,
						height: 92,
						fill: Y[n.color],
						fillOpacity: .4,
						strokeWidth: 6,
						className: n.valid ? "stroke-done" : "stroke-danger"
					}, `g${e}`)),
					Array.from({ length: 10 }, (e, t) => /* @__PURE__ */ h("line", {
						x1: t * X,
						y1: 0,
						x2: t * X,
						y2: 9 * X,
						className: "stroke-ink/15",
						strokeWidth: 2
					}, `v${t}`)),
					Array.from({ length: 10 }, (e, t) => /* @__PURE__ */ h("line", {
						x1: 0,
						y1: t * X,
						x2: 9 * X,
						y2: t * X,
						className: "stroke-ink/15",
						strokeWidth: 2
					}, `h${t}`)),
					Array.from({ length: 8 }, (e, t) => Array.from({ length: 9 }, (e, n) => ee(t, n) ? /* @__PURE__ */ h("line", {
						x1: n * X,
						y1: (t + 1) * X,
						x2: (n + 1) * X,
						y2: (t + 1) * X,
						className: "stroke-ink",
						strokeWidth: 8
					}, `th${t}-${n}`) : null)),
					Array.from({ length: 9 }, (e, t) => Array.from({ length: 8 }, (e, n) => te(t, n) ? /* @__PURE__ */ h("line", {
						x1: (n + 1) * X,
						y1: t * X,
						x2: (n + 1) * X,
						y2: (t + 1) * X,
						className: "stroke-ink",
						strokeWidth: 8
					}, `tv${t}-${n}`) : null)),
					k.map((t, n) => {
						let r = M[n][0], i = M[n].filter((t) => e.has(t) || m.has(t)).length, a = r % 9 * X + 7, o = Math.floor(r / 9) * X + 7;
						return /* @__PURE__ */ g("g", {
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ h("rect", {
									x: a,
									y: o,
									width: 70,
									height: 43,
									rx: 10,
									fill: i === M[n].length ? "#bbefc8" : "#fff7df",
									stroke: "#493b3a",
									strokeWidth: 3
								}),
								/* @__PURE__ */ h("text", {
									x: a + 35,
									y: o + 27,
									textAnchor: "middle",
									fontSize: 24,
									fontWeight: 800,
									fill: "#35232b",
									children: t
								}),
								/* @__PURE__ */ h("rect", {
									x: a + 8,
									y: o + 33,
									width: 54,
									height: 4,
									rx: 2,
									fill: "#c7b8ae"
								}),
								/* @__PURE__ */ h("rect", {
									x: a + 8,
									y: o + 33,
									width: 54 * i / M[n].length,
									height: 4,
									rx: 2,
									fill: "#2f9d72"
								})
							]
						}, `section${n}`);
					})
				]
			})
		]
	});
}
function ze({ color: e, x: t, y: n }) {
	let r = {
		stroke: "#fff9ed",
		strokeWidth: 7,
		strokeLinecap: "round",
		fill: "none"
	};
	return e === "green" ? /* @__PURE__ */ h("path", {
		d: `M${t + 31} ${n + 67}q27-48 43-30-6 28-43 30z`,
		...r
	}) : e === "orange" ? /* @__PURE__ */ h("path", {
		d: `M${t + 50} ${n + 19}l28 31-28 31-28-31z`,
		...r
	}) : e === "purple" ? /* @__PURE__ */ g("g", {
		fill: "#fff9ed",
		children: [
			/* @__PURE__ */ h("circle", {
				cx: t + 34,
				cy: n + 36,
				r: 7
			}),
			/* @__PURE__ */ h("circle", {
				cx: t + 65,
				cy: n + 36,
				r: 7
			}),
			/* @__PURE__ */ h("circle", {
				cx: t + 50,
				cy: n + 66,
				r: 7
			})
		]
	}) : e === "blue" ? /* @__PURE__ */ h("path", {
		d: `M${t + 18} ${n + 48}q16-22 32 0t32 0`,
		...r
	}) : e === "pink" ? /* @__PURE__ */ h("path", {
		d: `M${t + 25} ${n + 74}l50-49`,
		...r
	}) : /* @__PURE__ */ h("path", {
		d: `M${t + 30} ${n + 30}l40 40m0-40-40 40`,
		...r
	});
}
function Be({ shape: e, color: t, cellPx: n = 16 }) {
	let r = Math.max(...e.map(([e]) => e)) + 1, i = Math.max(...e.map(([, e]) => e)) + 1;
	return /* @__PURE__ */ h("svg", {
		viewBox: `0 0 ${r * n} ${i * n}`,
		className: "mindspace-shape-mini",
		style: {
			width: `calc(var(--ms-shape-cell, ${n}px) * ${r})`,
			height: `calc(var(--ms-shape-cell, ${n}px) * ${i})`
		},
		"aria-hidden": !0,
		children: e.map(([e, r]) => /* @__PURE__ */ h("rect", {
			x: e * n + 1,
			y: r * n + 1,
			width: n - 2,
			height: n - 2,
			rx: 1.2,
			fill: Y[t],
			stroke: "#1c1917",
			strokeWidth: 1.2
		}, `${e},${r}`))
	});
}
var Ve = {
	1: [[12, 12]],
	2: [[7, 7], [17, 17]],
	3: [
		[6, 6],
		[12, 12],
		[18, 18]
	],
	4: [
		[7, 7],
		[17, 7],
		[7, 17],
		[17, 17]
	],
	5: [
		[6.5, 6.5],
		[17.5, 6.5],
		[12, 12],
		[6.5, 17.5],
		[17.5, 17.5]
	],
	6: [
		[7, 6],
		[17, 6],
		[7, 12],
		[17, 12],
		[7, 18],
		[17, 18]
	]
};
function He({ color: e, pips: t, size: n = 20 }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 24 24",
		style: {
			width: `min(var(--ms-die-size, ${n}px), var(--ms-die-fit, 100%))`,
			height: "auto"
		},
		className: "mindspace-die flex-none",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ h("rect", {
			x: 1,
			y: 1,
			width: 22,
			height: 22,
			rx: 6,
			fill: Y[e],
			stroke: "#1c1917",
			strokeWidth: 1.5
		}), (Ve[t] ?? Ve[1]).map(([e, t], n) => /* @__PURE__ */ h("circle", {
			cx: e,
			cy: t,
			r: 2.2,
			fill: "#fff"
		}, n))]
	});
}
//#endregion
//#region src/games/mindspace/piece-toolbar.tsx
var Ue = 900, Z = 36, We = 92;
function Ge({ group: e, boardRef: t, wellRef: n, options: i, onRotate: s, onMirror: c, onColor: l, onRemove: u, labels: d }) {
	let f = a(null), [p, m] = o(!1), [_, b] = o(null);
	return r(() => {
		let r = t.current, i = n.current;
		if (!r || !i) return;
		let a = () => {
			let t = r.getBoundingClientRect(), n = i.getBoundingClientRect(), a = i.clientWidth, o = i.clientHeight, s = t.left - n.left - i.clientLeft, c = t.top - n.top - i.clientTop, l = e.cells.map(z), u = e.cells.map(R), d = Math.min(...l), p = Math.max(...l), m = Math.min(...u), h = Math.max(...u), g = s + (Z + (d + p + 1) * We / 2) / Ue * t.width, _ = c + (Z + (m + h + 1) * We / 2) / Ue * t.height, v = c + (Z + m * We) / Ue * t.height, y = c + (Z + (h + 1) * We) / Ue * t.height, x = f.current;
			if (!x) return;
			let S = window.matchMedia("(orientation: landscape) and (max-height: 480px)").matches;
			x.classList.toggle("is-vertical", S), x.classList.remove("is-compact");
			let C = x.querySelector(".mindspace-piece-toolbar-row")?.getBoundingClientRect().height ?? 188, w = S && C + 8 > o;
			x.classList.toggle("is-compact", w);
			let T = x.getBoundingClientRect();
			if (S) {
				let e = g >= a / 2, n = T.width, r = x.querySelector(".mindspace-piece-toolbar-row")?.getBoundingClientRect().height ?? 188, i = e ? s + t.width + 4 : s - n - 4, c = Math.min(a - n - 4, Math.max(4, i)), l = Math.min(o - r - 4, Math.max(4, _ - r / 2)), u = x.querySelector(".mindspace-piece-palette");
				if (u) {
					let t = u.getBoundingClientRect(), i = e ? c - t.width - 4 : c + n + 4, s = Math.max(4, Math.min(a - t.width - 4, i)), d = Math.max(4, Math.min(o - t.height - 4, l));
					if (w) {
						let e = r + t.height + 4, n = Math.max(4, Math.min(o - e - 4, _ - e / 2)), i = _ >= o / 2;
						l = i ? n + t.height + 4 : n, d = i ? n : n + r + 4;
					}
					u.style.left = `${s - c}px`, u.style.right = "auto", u.style.top = `${d - l}px`;
				}
				b((t) => t?.left === c && t.top === l && t.vertical && t.right === e && t.compact === w ? t : {
					left: c,
					top: l,
					vertical: S,
					right: e,
					compact: w
				});
				return;
			}
			let E = T.height, D = T.width, O = Math.max(4, a - D - 4), k = Math.min(O, Math.max(4, g - D / 2)), A = v - E - 6, j = y + 6, M = A >= 4 ? A : Math.min(Math.max(4, o - E - 4), j);
			b((e) => e?.left === k && e.top === M && !e.vertical ? e : {
				left: k,
				top: M,
				vertical: !1,
				right: !1,
				compact: !1
			});
		};
		a();
		let o = typeof ResizeObserver > "u" ? null : new ResizeObserver(a);
		return o?.observe(r), o?.observe(i), f.current && o?.observe(f.current), window.addEventListener("resize", a), () => {
			o?.disconnect(), window.removeEventListener("resize", a);
		};
	}, [
		t,
		n,
		e,
		p
	]), /* @__PURE__ */ g("div", {
		ref: f,
		className: `mindspace-piece-toolbar ${_?.vertical ? "is-vertical" : ""} ${_?.right ? "is-right" : ""} ${_?.compact ? "is-compact" : ""}`,
		style: _ ? {
			left: _.left,
			top: _.top
		} : { visibility: "hidden" },
		onPointerDown: (e) => e.stopPropagation(),
		children: [/* @__PURE__ */ g("div", {
			className: "mindspace-piece-toolbar-row",
			children: [
				/* @__PURE__ */ h("button", {
					type: "button",
					"aria-label": d.rotate,
					onClick: s,
					className: "mindspace-piece-action",
					children: /* @__PURE__ */ h(y, {
						size: 19,
						"aria-hidden": !0
					})
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					"aria-label": d.mirror,
					onClick: c,
					className: "mindspace-piece-action",
					children: /* @__PURE__ */ h(v, {
						size: 19,
						"aria-hidden": !0
					})
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					"aria-label": d.color,
					"aria-expanded": p,
					onClick: () => m((e) => !e),
					className: "mindspace-piece-action",
					children: /* @__PURE__ */ h("span", {
						className: "mindspace-piece-color-icon",
						style: { background: Y[e.color] }
					})
				}),
				/* @__PURE__ */ h("button", {
					type: "button",
					"aria-label": d.remove,
					onClick: u,
					className: "mindspace-piece-action mindspace-piece-remove",
					children: "×"
				})
			]
		}), p && /* @__PURE__ */ h("div", {
			className: "mindspace-piece-palette",
			children: i.map((t) => /* @__PURE__ */ g("button", {
				type: "button",
				"aria-label": t.label,
				"aria-pressed": e.color === t.color,
				disabled: !t.available,
				onClick: () => {
					l(t.color), m(!1);
				},
				className: "mindspace-piece-swatch",
				children: [/* @__PURE__ */ h("span", { style: { background: Y[t.color] } }), t.cost > 0 && /* @__PURE__ */ h("b", { children: "2¢" })]
			}, t.color))
		})]
	});
}
//#endregion
//#region src/games/mindspace/view-player.tsx
var Ke = {
	green: "games.mindspace.colorGreen",
	orange: "games.mindspace.colorOrange",
	purple: "games.mindspace.colorPurple",
	blue: "games.mindspace.colorBlue",
	pink: "games.mindspace.colorPink",
	black: "games.mindspace.colorBlack"
};
function qe(e, t) {
	return D.filter((n, r) => e[r] === t);
}
var Je = 0;
function Ye(e) {
	let t = e.public;
	return /* @__PURE__ */ h(Xe, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Xe({ pub: e, members: t, myRid: n, send: r }) {
	let _ = c(), v = s((e) => e.locale), y = e.players.find((e) => e.rid === n), [b, x] = o(n), [S, C] = o(n), [w, T] = o({
		base: null,
		extras: [],
		blacks: []
	}), [E, k] = o(null), [A, j] = o(!1), [M, ee] = o(!1), [te, P] = o(null), [F, I] = o(null), [re, ie] = o(!1), [ae, L] = o(null), se = a(null), ce = a(null), le = a(null), fe = a(!1), pe = a(null), U = e.phase === "draw" && !!y && !y.submitted && b === n, [he, ge] = o(""), _e = `${n}:${e.round}:${+!!y?.submitted}`;
	S !== n && (C(n), x(n), L(null), ie(!1)), he !== _e && (ge(_e), T({
		base: null,
		extras: [],
		blacks: []
	}), k(null), j(!1), ee(!1), P(null), I(null));
	let W = i(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of y?.placements ?? []) for (let n of t.cells) e.set(n, t.color);
		return e;
	}, [y?.placements]), G = i(() => {
		let e = [];
		w.base && e.push({
			key: w.base.key,
			cells: w.base.cells,
			color: w.base.color
		});
		for (let t of w.extras) e.push({
			key: t.key,
			cells: t.cells,
			color: t.color
		});
		for (let t of w.blacks) e.push({
			key: `b${t}`,
			cells: [t],
			color: "black"
		});
		return e;
	}, [w]), K = (e) => {
		let t = new Map(W);
		for (let n of G) if (n.key !== e) for (let e of n.cells) t.set(e, n.color);
		return t;
	}, ve = w.extras.length * 3 + w.blacks.length + (w.base?.recolor ? 2 : 0), ye = y?.money ?? 0, q = 0, be = new Map(W), xe = (e, t) => {
		ye -= t, q = Math.max(q, -ye);
		for (let t of e.cells) be.set(t, e.color);
		ye = Ae({
			cells: e.cells,
			color: e.color,
			shape: "staged"
		}, ye, be);
	};
	w.base && xe(w.base, w.base.recolor ? 2 : 0);
	for (let e of w.extras) xe(e, 3);
	for (let e of w.blacks) xe({
		cells: [e],
		color: "black"
	}, 1);
	let Se = (t) => {
		let r = e.players.find((e) => e.rid === t);
		if (!r) return null;
		let i = [...r.placements];
		if (t === n) for (let e of G) i.push({
			cells: e.cells,
			color: e.color,
			shape: "staged"
		});
		return me(i, r.goalScores);
	}, Ce = (e) => Se(e)?.total ?? 0, we = /* @__PURE__ */ new Set();
	w.base && we.add(w.base.color);
	for (let e of w.extras) we.add(e.color);
	let Te = [
		1,
		2,
		3,
		4,
		5
	].some((t) => qe(e.dice, t).some((e) => !we.has(e))), Ee = (t, n) => {
		if (n === "extra" && t === "domino") return null;
		let r = t === "domino" ? ne : N[e.row[t - 1]], i = t === "domino" ? [...D] : qe(e.dice, t), a = n === "extra" ? i.filter((e) => !we.has(e)) : i;
		if (n === "extra" && a.length === 0) return null;
		let o = n === "base" ? W : K(), s = B(r), c = (e) => {
			for (let t of e) for (let e = 0; e < s.length; e++) for (let n = 0; n < 81; n++) {
				let r = V(s[e], n);
				if (r && H(o, r, t, o.size === 0)) return {
					color: t,
					oi: e
				};
			}
			return null;
		}, l = c(a), u = n === "base" && t !== "domino" && !l ? c(D) : null, d = l ?? u ?? {
			color: a[0] ?? D[0],
			oi: 0
		};
		return {
			tool: n,
			slot: t,
			shape: r,
			...d,
			recolor: n === "base" && t !== "domino" && !i.includes(d.color)
		};
	}, De = (e, t) => {
		let n = Ee(e, t);
		n && (ee(!1), I(null), k(n));
	}, Oe = (e) => {
		if (!E) return null;
		let t = B(E.shape);
		return V(t[E.oi % t.length], e);
	}, J = (e, t, n, r = !1) => {
		if (!e) return null;
		let i = r ? W : K(n);
		return {
			cells: e,
			color: t,
			valid: H(i, e, t, i.size === 0)
		};
	}, ke = [];
	if (U && E && !M) {
		let e = B(E.shape)[E.oi % B(E.shape).length];
		for (let t = 0; t < 81; t++) {
			let n = V(e, t);
			n && J(n, E.color, void 0, E.tool === "base")?.valid && ke.push(t);
		}
	}
	let je = (e) => {
		if (!U) return;
		if (M) {
			T((t) => t.blacks.includes(e) ? {
				...t,
				blacks: t.blacks.filter((t) => t !== e)
			} : O.has(e) || W.has(e) || G.some((t) => t.cells.includes(e)) ? t : {
				...t,
				blacks: [...t.blacks, e]
			});
			return;
		}
		let t = G.find((t) => t.cells.includes(e));
		if (t) {
			I(t.key), k(null), j(!1), pe.current = {
				source: t.key,
				anchor: e
			};
			return;
		}
		E && (pe.current = {
			source: "armed",
			anchor: e
		}, P(J(Oe(e), E.color, void 0, E.tool === "base")));
	}, Me = (e, t, n) => {
		if (e === "armed") return J(Oe(n), E?.color ?? "black", void 0, E?.tool === "base");
		let r = G.find((t) => t.key === e);
		if (!r) return null;
		let i = R(n) - R(t), a = z(n) - z(t), o = r.cells.every((e) => {
			let t = R(e) + i, n = z(e) + a;
			return t >= 0 && t < 9 && n >= 0 && n < 9;
		});
		return J(o ? r.cells.map((e) => (R(e) + i) * 9 + (z(e) + a)) : null, r.color, r.key);
	}, Ne = (e) => {
		let t = pe.current;
		P(t && e !== null && (t.source === "armed" || e !== t.anchor) ? Me(t.source, t.anchor, e) : null);
	}, Pe = (e) => {
		U && (T((t) => t.base?.key === e ? {
			...t,
			base: null,
			extras: []
		} : {
			...t,
			extras: t.extras.filter((t) => t.key !== e)
		}), I(null));
	}, Y = (e, t) => {
		let n = w.base?.key === e ? w.base : w.extras.find((t) => t.key === e);
		if (!n) return;
		let r = Math.min(...n.cells.map(R)), i = Math.min(...n.cells.map(z)), a = t(n.cells.map((e) => [z(e) - i, R(e) - r])), o = Math.min(...a.map(([e]) => e)), s = Math.min(...a.map(([, e]) => e)), c = a.map(([e, t]) => [e - o, t - s]), l = [];
		for (let e = 0; e <= 3; e++) for (let t = -e; t <= e; t++) for (let n = -e; n <= e; n++) Math.abs(t) + Math.abs(n) === e && l.push([t, n]);
		let u = K(e), d = l.map(([e, t]) => {
			let n = r + e, a = i + t;
			return n >= 0 && n < 9 && a >= 0 && a < 9 ? V(c, n * 9 + a) : null;
		}).find((e) => e && H(u, e, n.color, u.size === 0));
		d && T((t) => t.base?.key === e ? {
			...t,
			base: {
				...t.base,
				cells: d
			}
		} : {
			...t,
			extras: t.extras.map((t) => t.key === e ? {
				...t,
				cells: d
			} : t)
		});
	}, X = (e) => Y(e, ue), Fe = (e) => Y(e, (e) => e.map(([e, t]) => [-e, t])), Ie = (t, n) => {
		let r = w.base?.key === t, i = r ? w.base : w.extras.find((e) => e.key === t);
		if (!i) return;
		let a = i.slot === "domino" ? [...D] : qe(e.dice, i.slot);
		if (!r && (!a.includes(n) || [...w.extras, w.base].some((e) => e && e.key !== t && e.color === n))) return;
		let o = K(t);
		if (!H(o, i.cells, n, o.size === 0)) return;
		let s = r && i.slot !== "domino" && !a.includes(n);
		T((e) => r && e.base ? {
			...e,
			base: {
				...e.base,
				color: n,
				...s ? { recolor: !0 } : { recolor: void 0 }
			}
		} : {
			...e,
			extras: e.extras.map((e) => e.key === t ? {
				...e,
				color: n
			} : e)
		});
	}, ze = (e, t) => {
		let n = pe.current;
		if (pe.current = null, P(null), !n || t || e === null) return;
		if (n.source !== "armed" && e === n.anchor) {
			X(n.source);
			return;
		}
		let r = Me(n.source, n.anchor, e);
		if (r?.valid) {
			if (n.source === "armed" && E) {
				let e = {
					key: `s${Je++}`,
					slot: E.slot,
					color: E.color,
					cells: r.cells,
					...E.recolor ? { recolor: !0 } : {}
				};
				T((t) => E.tool === "base" ? {
					base: e,
					extras: [],
					blacks: []
				} : {
					...t,
					extras: [...t.extras, e]
				}), k(null), j(!1), I(e.key);
			} else if (n.source !== "armed") {
				let e = n.source;
				T((t) => t.base?.key === e ? {
					...t,
					base: {
						...t.base,
						cells: r.cells
					}
				} : {
					...t,
					extras: t.extras.map((t) => t.key === e ? {
						...t,
						cells: r.cells
					} : t)
				});
			}
		}
	}, Ve = (e, t) => {
		if (!U) return;
		let n = A ? "extra" : "base", r = E?.slot === t && E.tool === n ? E : Ee(t, n);
		r && (le.current = {
			pointerId: e.pointerId,
			armed: r,
			startX: e.clientX,
			startY: e.clientY,
			moved: !1
		}, e.currentTarget.setPointerCapture(e.pointerId));
	}, Ue = (e) => {
		let t = le.current;
		if (!t || t.pointerId !== e.pointerId || !t.moved && Math.hypot(e.clientX - t.startX, e.clientY - t.startY) < 7) return;
		t.moved = !0, I(null), k(t.armed);
		let n = Le(se.current, e.clientX, e.clientY), r = B(t.armed.shape)[t.armed.oi % B(t.armed.shape).length];
		P(n === null ? null : J(V(r, n), t.armed.color, void 0, t.armed.tool === "base"));
	}, Z = (e, t = !1) => {
		let n = le.current;
		if (!n || n.pointerId !== e.pointerId || (le.current = null, P(null), !n.moved) || (fe.current = !0, window.setTimeout(() => {
			fe.current = !1;
		}, 0), t)) return;
		let r = Le(se.current, e.clientX, e.clientY);
		if (r === null) return;
		let i = B(n.armed.shape)[n.armed.oi % B(n.armed.shape).length], a = J(V(i, r), n.armed.color, void 0, n.armed.tool === "base");
		if (!a?.valid) return;
		let o = {
			key: `s${Je++}`,
			slot: n.armed.slot,
			color: n.armed.color,
			cells: a.cells,
			...n.armed.recolor ? { recolor: !0 } : {}
		};
		T((e) => n.armed.tool === "base" ? {
			base: o,
			extras: [],
			blacks: []
		} : {
			...e,
			extras: [...e.extras, o]
		}), k(null), j(!1), I(o.key);
	}, We = (e) => {
		if (!fe.current && U) {
			if (E?.slot === e && E.tool === (A ? "extra" : "base")) {
				k(null), j(!1);
				return;
			}
			De(e, A ? "extra" : "base");
		}
	}, Ye = () => {
		r({
			type: "submitTurn",
			base: w.base ? {
				slot: w.base.slot,
				color: w.base.color,
				cells: w.base.cells,
				...w.base.recolor ? { recolor: !0 } : {}
			} : null,
			extras: w.extras.map((e) => ({
				slot: e.slot,
				color: e.color,
				cells: e.cells
			})),
			blacks: w.blacks
		});
	}, Xe = "info", Ze = "";
	e.phase === "draw" && (y ? y.submitted ? (Xe = "done", Ze = _("games.mindspace.waitingSubmit", {
		n: e.players.filter((e) => e.submitted).length,
		total: e.players.length
	})) : (Xe = "accent", Ze = _("games.mindspace.drawPrompt")) : Ze = _("games.mindspace.drawPrompt"));
	let Qe = e.players.find((e) => e.rid === b), $e = t.find((e) => e.rid === b), Q = Se(b), et = ae ? oe(ae) : null, tt = !!w.base || w.extras.length > 0 || w.blacks.length > 0, nt = b !== n, $ = w.base?.key === F ? w.base : w.extras.find((e) => e.key === F), rt = G.find((e) => e.key === F), it = !!$ && $.key === w.base?.key, at = $?.slot === "domino" ? [...D] : $ ? qe(e.dice, $.slot) : [], ot = $ ? K($.key) : null, st = $ && ot ? D.map((e) => {
		let t = it && $.slot !== "domino" && !at.includes(e) ? 2 : 0, n = [...w.extras, w.base].some((t) => t && t.key !== $.key && t.color === e);
		return {
			color: e,
			cost: t,
			available: (it || at.includes(e) && !n) && H(ot, $.cells, e, ot.size === 0),
			label: `${_(Ke[e])}${t ? " · 2¢" : ""}`
		};
	}) : [], ct = /* @__PURE__ */ new Map();
	if (Qe) for (let e of Qe.placements) for (let t of e.cells) ct.set(t, e.color);
	return /* @__PURE__ */ h("div", {
		className: "mindspace-root",
		children: /* @__PURE__ */ h(f, {
			adaptive: !0,
			banner: /* @__PURE__ */ g("div", {
				className: "mindspace-top",
				children: [/* @__PURE__ */ h(d, {
					tone: Xe,
					text: Ze,
					chip: _("games.mindspace.roundShort", {
						n: e.round,
						total: 12
					}),
					accent: de.accent
				}), /* @__PURE__ */ h("div", {
					className: "mindspace-player-rail",
					children: /* @__PURE__ */ h(p, {
						members: t.filter((t) => e.players.some((e) => e.rid === t.rid)),
						myRid: n,
						variant: "plate",
						anchorOf: (e) => `seat:${e}`,
						action: (t) => e.phase === "draw" ? e.players.find((e) => e.rid === t)?.submitted ? "done" : "pending" : null,
						onPick: (e) => x(e),
						picked: (e) => b === e,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ g("span", {
								className: "mindspace-player-stats",
								children: [/* @__PURE__ */ g("span", {
									"aria-label": _("games.mindspace.moneyAria", { n: n.money }),
									className: "mindspace-money-chip",
									children: [/* @__PURE__ */ h("span", {
										"aria-hidden": !0,
										className: "mindspace-coin-mark",
										children: "◎"
									}), /* @__PURE__ */ h("span", {
										className: "font-mono tabular-nums",
										children: n.money
									})]
								}), /* @__PURE__ */ g("button", {
									type: "button",
									onClick: (e) => {
										e.stopPropagation(), x(t), L(null), ie(!0);
									},
									className: "mindspace-estimate",
									children: [/* @__PURE__ */ h("span", { children: _("games.mindspace.estimatedScore") }), /* @__PURE__ */ h(u, {
										value: Ce(t),
										className: "font-mono tabular-nums"
									})]
								})]
							}) : null;
						}
					})
				})]
			}),
			actions: /* @__PURE__ */ h("div", {
				className: "mindspace-actions",
				children: /* @__PURE__ */ g("div", {
					className: "mindspace-controls",
					children: [/* @__PURE__ */ g("div", {
						className: "mindspace-buy-row",
						children: [
							/* @__PURE__ */ h("button", {
								type: "button",
								disabled: !U,
								"aria-pressed": M,
								onClick: () => {
									ee((e) => !e), k(null), j(!1), I(null);
								},
								className: "mindspace-buy-black",
								children: _("games.mindspace.buyBlack")
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								disabled: !U || !w.base || !Te,
								"aria-pressed": A,
								onClick: () => {
									ee(!1), k(null), I(null), j((e) => !e);
								},
								className: "mindspace-buy-extra",
								children: _("games.mindspace.buyExtra")
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								disabled: !U,
								onClick: () => {
									T({
										base: null,
										extras: [],
										blacks: []
									}), I(null), j(!1), k(null);
								},
								className: "mindspace-clear-staging",
								children: _("games.mindspace.clearStaging")
							}),
							/* @__PURE__ */ g("span", {
								"aria-label": q > 0 ? _("games.mindspace.budgetShortfall", { n: q }) : _("games.mindspace.budgetPreview", {
									cost: ve,
									left: ye
								}),
								className: `mindspace-budget-chip ${q > 0 ? "is-short" : ""}`,
								children: [
									/* @__PURE__ */ g("span", { children: ["🪙", y?.money ?? 0] }),
									ve > 0 && /* @__PURE__ */ g("span", { children: ["−", ve] }),
									q > 0 && /* @__PURE__ */ h("strong", { children: _("games.mindspace.shortfall", { n: q }) })
								]
							})
						]
					}), /* @__PURE__ */ h("button", {
						type: "button",
						disabled: !U || q > 0,
						onClick: Ye,
						className: `mindspace-submit btn-base min-h-12 w-full text-base text-white ${tt ? "is-ready" : ""} ${q > 0 ? "is-short" : ""}`,
						style: { background: q > 0 ? "#a02952" : de.accent },
						children: q > 0 ? _("games.mindspace.submitShortfall", { n: q }) : ve > 0 ? _("games.mindspace.submitWithCost", { n: ve }) : _("games.mindspace.submit")
					})]
				})
			}),
			actionsHeight: "mindspace-actions-height",
			scroll: !1,
			overlay: re && Q ? /* @__PURE__ */ g("div", {
				className: "mindspace-detail-sheet pointer-events-auto",
				children: [
					/* @__PURE__ */ g("div", {
						className: "mindspace-detail-head",
						children: [/* @__PURE__ */ h("strong", { children: _("games.mindspace.scoreDetail") }), /* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => ie(!1),
							"aria-label": _("games.mindspace.close"),
							children: "×"
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "mindspace-score-grid",
						children: [
							["scoreSections", Q.sections],
							["scoreGoals", Q.goals],
							["scorePurple", Q.purple],
							["scoreOrange", Q.orange],
							["scorePink", Q.pink],
							["scoreBlue", Q.blue],
							["scoreEmpty", Q.empty]
						].map(([e, t]) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("span", { children: _(`games.mindspace.${e}`) }), /* @__PURE__ */ h("b", {
							className: "font-mono tabular-nums",
							children: t
						})] }, e))
					}),
					/* @__PURE__ */ g("div", {
						className: "mindspace-score-total",
						children: [/* @__PURE__ */ h("span", { children: _("games.mindspace.estimatedScore") }), /* @__PURE__ */ h("strong", {
							className: "font-mono tabular-nums",
							children: Q.total
						})]
					})
				]
			}) : et ? /* @__PURE__ */ g("div", {
				className: "mindspace-detail-sheet pointer-events-auto",
				children: [/* @__PURE__ */ g("div", {
					className: "mindspace-detail-head",
					children: [/* @__PURE__ */ h("strong", { children: _(et.nameKey) }), /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => L(null),
						"aria-label": _("games.mindspace.close"),
						children: "×"
					})]
				}), /* @__PURE__ */ h("p", { children: _(et.descKey) })]
			}) : null,
			children: /* @__PURE__ */ g("div", {
				className: "mindspace-stage",
				children: [
					/* @__PURE__ */ h("ul", {
						className: "mindspace-goals flex flex-none gap-1.5",
						children: e.goals.map((e) => {
							let t = oe(e.id);
							if (!t) return null;
							let n = Qe?.goalScores[e.id];
							return /* @__PURE__ */ g("li", {
								className: `mindspace-goal-card min-w-0 flex-1 rounded-lg border-2 border-ink px-1.5 py-1 ${e.flipped ? "is-flipped" : ""}`,
								role: "button",
								tabIndex: 0,
								onClick: () => {
									L(e.id), ie(!1);
								},
								onKeyDown: (t) => {
									(t.key === "Enter" || t.key === " ") && (L(e.id), ie(!1));
								},
								children: [/* @__PURE__ */ g("p", {
									className: "mindspace-goal-head",
									children: [
										/* @__PURE__ */ h("span", {
											"aria-hidden": !0,
											className: `mindspace-goal-deck is-${t.deck.toLowerCase()}`,
											children: t.deck
										}),
										/* @__PURE__ */ h("span", {
											className: "mindspace-goal-name",
											children: _(t.nameKey)
										}),
										/* @__PURE__ */ h("span", {
											className: "mindspace-goal-score font-mono tabular-nums",
											children: n === void 0 ? e.flipped ? t.lo : t.hi : `✓${n}`
										})
									]
								}), /* @__PURE__ */ h("p", {
									className: "mindspace-goal-desc",
									children: _(t.descKey)
								})]
							}, e.id);
						})
					}),
					/* @__PURE__ */ g("div", {
						ref: ce,
						className: "mindspace-board-well relative flex min-h-0 flex-1 items-center justify-center overflow-hidden",
						children: [
							/* @__PURE__ */ h(l, {
								kind: "sheen",
								base: "#e9ded1",
								className: "absolute inset-0 size-full"
							}),
							/* @__PURE__ */ h("div", {
								className: "mindspace-aura",
								"aria-hidden": !0
							}),
							/* @__PURE__ */ h("div", {
								className: "mindspace-board-image relative flex min-h-0 w-full flex-1 items-center justify-center",
								children: b === n ? /* @__PURE__ */ h(Re, {
									filled: W,
									staged: G,
									ghost: te,
									legalAnchors: ke,
									interactive: U,
									onCellDown: je,
									onCellMove: Ne,
									onCellUp: ze,
									boardRef: se,
									selectedStagedKey: F
								}) : /* @__PURE__ */ h(Re, {
									filled: ct,
									staged: [],
									ghost: null,
									interactive: !1
								})
							}),
							U && $ && rt && /* @__PURE__ */ h(Ge, {
								group: rt,
								boardRef: se,
								wellRef: ce,
								options: st,
								onRotate: () => X($.key),
								onMirror: () => Fe($.key),
								onColor: (e) => Ie($.key, e),
								onRemove: () => Pe($.key),
								labels: {
									rotate: _("games.mindspace.rotate"),
									mirror: _("games.mindspace.mirror"),
									color: _("games.mindspace.changeColor"),
									remove: _("games.mindspace.removePiece")
								}
							}, $.key),
							/* @__PURE__ */ g("div", {
								className: "mindspace-board-plaque",
								children: [
									/* @__PURE__ */ h("span", {
										"aria-hidden": !0,
										children: "✦"
									}),
									nt && $e ? _("games.mindspace.boardOf", { name: m($e, v) }) : _("games.mindspace.boardLabel"),
									/* @__PURE__ */ h("span", {
										"aria-hidden": !0,
										children: "✦"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ g("div", {
						className: "mindspace-tray flex flex-none items-end justify-center gap-1.5",
						children: [e.row.map((t, n) => {
							let r = n + 1, i = qe(e.dice, r), a = i.length === 0, o = i.some((e) => !we.has(e)), s = !U || A && !o, c = E?.slot === r;
							return /* @__PURE__ */ g("div", {
								className: "mindspace-card-slot flex flex-col items-center justify-end gap-0.5",
								children: [/* @__PURE__ */ h("span", {
									className: "mindspace-dice-row",
									"data-count": i.length,
									children: i.map((e) => /* @__PURE__ */ h(He, {
										color: e,
										pips: r,
										size: i.length >= 3 ? 16 : 20
									}, e))
								}), /* @__PURE__ */ g("button", {
									type: "button",
									"aria-label": `${_("games.mindspace.hintSlot", { n: r })}${a && !A ? ` · ${_("games.mindspace.freeDrawCost")}` : ""}`,
									disabled: s,
									onClick: () => We(r),
									onPointerDown: (e) => Ve(e, r),
									onPointerMove: Ue,
									onPointerUp: Z,
									onPointerCancel: (e) => Z(e, !0),
									className: `mindspace-shape-card relative grid min-h-11 min-w-11 flex-none place-items-center p-1 ${c ? "is-active" : ""} ${a ? "is-paid-only" : ""} ${s ? "is-unavailable" : ""}`,
									children: [
										/* @__PURE__ */ h("span", {
											className: "mindspace-card-number",
											children: r
										}),
										a && !A && /* @__PURE__ */ h("span", {
											className: "mindspace-card-cost",
											children: "2¢"
										}),
										/* @__PURE__ */ h(Be, {
											shape: N[t],
											color: "black",
											cellPx: 9
										})
									]
								})]
							}, n);
						}), /* @__PURE__ */ g("div", {
							className: "mindspace-card-slot flex flex-col items-center justify-end gap-0.5",
							children: [/* @__PURE__ */ h("span", {
								className: "mindspace-dice-row",
								"data-count": e.dice.filter((e) => e === 6).length,
								children: D.filter((t, n) => e.dice[n] === 6).map((e, t, n) => /* @__PURE__ */ h(He, {
									color: e,
									pips: 6,
									size: n.length >= 3 ? 16 : 20
								}, e))
							}), /* @__PURE__ */ g("button", {
								type: "button",
								"aria-label": _("games.mindspace.domino"),
								disabled: !U || A,
								onClick: () => We("domino"),
								onPointerDown: (e) => Ve(e, "domino"),
								onPointerMove: Ue,
								onPointerUp: Z,
								onPointerCancel: (e) => Z(e, !0),
								className: `mindspace-shape-card grid min-h-11 min-w-11 flex-none place-items-center p-1 ${E?.slot === "domino" ? "is-active" : ""} ${!U || A ? "is-unavailable" : ""}`,
								children: [/* @__PURE__ */ h(Be, {
									shape: ne,
									color: "black",
									cellPx: 9
								}), /* @__PURE__ */ h("span", {
									className: "mindspace-domino-label mt-0.5 text-[9px] leading-3 font-bold opacity-60",
									children: _("games.mindspace.domino")
								})]
							})]
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/mindspace/bot.ts
function Ze(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Qe() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function $e(e, t) {
	return D.filter((n, r) => e[r] === t);
}
var Q = (e, t) => {
	let n = e.public;
	if (n.phase !== "draw") return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r || r.submitted) return null;
	let i = /* @__PURE__ */ new Map();
	for (let e of r.placements) for (let t of e.cells) i.set(t, e.color);
	let a = i.size === 0, o = me(r.placements, r.goalScores).total, s = x(b(t.rid)), c = (e, t) => {
		let a = {
			cells: [...t],
			color: e,
			shape: le(t)
		}, c = new Map(i);
		for (let n of t) c.set(n, e);
		let l = { ...r.goalScores }, u = 0;
		for (let e of n.goals) {
			if (e.id in l) continue;
			let t = oe(e.id);
			t && t.check({ filled: c }) && (l[e.id] = e.flipped ? t.lo : t.hi, u += l[e.id]);
		}
		let d = me([...r.placements, a], l).total - o;
		return d += u * s.greed * .5, e === "green" && (d += .5), d += (Qe() - .5) * s.noise * 2, {
			score: d,
			record: a
		};
	}, l = [], u = (e, t, n, r) => {
		for (let o of n) for (let n of B(t)) for (let t = 0; t < 81; t++) {
			let s = V(n, t);
			if (!s || !H(i, s, o, a)) continue;
			let { score: u } = c(o, s);
			r && (u -= 2), l.push({
				slot: e,
				color: o,
				cells: s,
				recolor: r,
				score: u
			});
		}
	};
	for (let e = 1; e <= 5; e++) {
		let t = $e(n.dice, e);
		t.length ? u(e, N[n.row[e - 1]], t) : r.money >= 3 && u(e, N[n.row[e - 1]], D, !0);
	}
	if (u("domino", ne, D), l.length) {
		let e = t.difficulty === "weak" ? Ze(l) : l.reduce((e, t) => t.score > e.score ? t : e);
		return { action: {
			type: "submitTurn",
			base: {
				slot: e.slot,
				color: e.color,
				cells: e.cells,
				...e.recolor ? { recolor: !0 } : {}
			},
			extras: [],
			blacks: []
		} };
	}
	if (r.money >= 1 && i.size > 0) {
		let e = [];
		for (let t = 0; t < 81; t++) O.has(t) || i.has(t) || ce(t).some((e) => i.has(e)) && e.push(t);
		if (e.length) return { action: {
			type: "submitTurn",
			base: null,
			extras: [],
			blacks: [Ze(e)]
		} };
	}
	return { action: {
		type: "submitTurn",
		base: null,
		extras: [],
		blacks: []
	} };
}, et = {
	green: "games.mindspace.colorGreen",
	orange: "games.mindspace.colorOrange",
	purple: "games.mindspace.colorPurple",
	blue: "games.mindspace.colorBlue",
	pink: "games.mindspace.colorPink"
}, tt = (e, t, n) => {
	let { base: r, blacks: i } = e;
	if (r) {
		let e = r.slot === "domino" ? n("games.mindspace.domino") : n("games.mindspace.hintSlot", { n: r.slot });
		return n(r.recolor ? "games.mindspace.hintPlaceRecolor" : "games.mindspace.hintPlace", {
			slot: e,
			color: n(et[r.color])
		});
	}
	return i.length > 0 ? n("games.mindspace.hintBlack", { n: i.length }) : n("games.mindspace.hintSkip");
}, nt = {
	name: "心灵空间",
	desc: "在12轮中根据骰子绘制形状，填满脑区、完成目标卡，并按颜色效果争取最高分。",
	rules: "目标:\n· 游戏进行12轮。终局时按目标卡、脑区和颜色效果计分，总分最高者获胜。\n· 如果多人并列最高分，这些玩家共同获胜。\n准备:\n· 每名玩家获得一张九行九列的脑板和1分钱。\n· 脑板分为五个脑区；灰质格不可绘制。\n· 灰质格仅在判断脑区、整行或整列是否填满时视为已填。\n· 开局展示五张形状卡，并从A、B、C三组目标卡中各抽出一张。\n· 掷五颗不同颜色的骰子，骰子点数决定免费可用的形状卡。\n每轮流程:\n· 所有玩家同时在各自的脑板上安排本轮操作，完成后提交。\n· 点数1至5分别对应同序号的形状卡；免费绘制使用对应骰子的颜色。\n· 点数6不对应形状卡；两格骨牌每轮都可作为免费基础形状，颜色任选。\n· 每轮最多放置一块基础形状；不放置形状也可以提交。\n· 从第二轮起，每轮移走最旧的形状卡，补充一张新卡并重新掷骰。\n放置:\n· 形状可以旋转或镜像，不能越出脑板，也不能覆盖灰质格或已填格。\n· 脑板尚无笔画时，第一块形状可以放在任意可用位置。\n· 此后放置的形状必须与至少一个已填格共享边。\n· 彩色形状不能与相同颜色的已填格共享边；角部相接不算相邻。\n· 排练中的形状可以移动、旋转、镜像或撤回；提交后才正式放置。\n分钱与额外绘制:\n· 花费2分钱可自由绘制基础形状：任选五张现有形状卡之一，并使用任意骰子颜色。\n· 自由绘制只替代本轮的基础形状，不增加可放置的形状数量。\n· 放置基础形状后，每花费3分钱可额外绘制一块形状，每轮最多四块。\n· 额外形状必须选有骰子的形状卡，使用该卡对应且本轮尚未使用的颜色。\n· 额外形状不能使用两格骨牌，也不能选择没有骰子的形状卡。\n· 花费1分钱可填入一个黑格；黑格须与已绘制的格共享边，可与黑格相邻。\n· 每轮最多购买九个黑格；黑格不能作为第一笔。\n· 每绘制一块绿色形状获得1分钱；每填满一个脑区再获得1分钱。\n· 最多持有9分钱。提交时按基础形状、额外形状、黑格的顺序结算收支。\n· 若结算过程中无法支付费用，本轮提交不生效，排练内容可继续调整。\n目标卡:\n· 每名玩家对每张目标卡最多得分一次；提交后判定是否达成。\n· 同一轮达成目标的玩家均获得翻面前分数；该轮结束后目标卡翻面。\n· 翻面后首次达成目标的玩家获得牌面较低的分数。\n· 同情：填满两格灰质周围指定的10格。\n· 完美的一天：在同一个脑区绘制全部五种骰子颜色。\n· 卷王：填满脑板上的任意一整行或一整列。\n· 心如止水：填满两个不含绿色格的脑区。\n· 灵魂伴侣：每个脑区内至少有一个粉色格。\n· 大冒险：填满左侧和右侧脑区。\n· 平静一生：填满右上方和左下方脑区。\n· 感同身受：填满四格灰质周围指定的12格。\n结算:\n· 每填满一个外侧脑区获得10分；填满中央脑区获得5分。\n· 每个与橙色格共享边的紫色格获得2分；相邻多个橙色格仍只计一次。\n· 按橙色形状数量计分：0至4块依次获得0、3、6、10、15分；5块及以上获得20分。\n· 每对同形的粉色与非粉色形状，按非粉色形状的格数得分；旋转和镜像视为同形。\n· 根据缺少蓝色格的脑区数量扣分：缺0至5区，依次扣0、4、7、9、12、16分。\n· 找出空格最多的脑区，按该脑区的空格数量扣分；灰质格不计为空格。\n· 已获得的目标卡分数计入总分；绿色形状、黑格和剩余分钱不直接计分。",
	roundShort: "{{n}}/{{total}}",
	drawPrompt: "选形状,画进大脑",
	boardLabel: "脑板 A · 五个脑区",
	boardOf: "{{name}} 的脑板",
	playerDrawing: "本轮正在绘画",
	playerDone: "本轮已完成",
	guideEmptyTitle: "选择形状，画进大脑",
	guideEmptyDetail: "第一块可放在任意非灰质格",
	guideArmedTitle: "将形状拖入脑板",
	guideArmedDetail: "点格放置，或旋转、镜像调整",
	guideStagedTitle: "已排练形状",
	guideStagedDetail: "拖动重摆；轻点旋转或用旁侧工具",
	guidePaidTitle: "自由绘制 · 2¢",
	guidePaidDetail: "可拖入脑板，落下后在旁边换色",
	guideExtraTitle: "额外形状 · 3¢",
	guideExtraDetail: "选有未用骰色的卡牌",
	guideShortfallTitle: "还差 {{n}}¢",
	guideShortfallDetail: "可继续调整，提交前不会扣钱",
	guideBlackTitle: "选择黑格填缝",
	guideBlackDetail: "轻点空格添加或撤销",
	guideViewingTitle: "正在查看其他脑板",
	guideViewingDetail: "选择自己的名牌继续绘画",
	returnBoard: "返回我的脑板",
	estimatedScore: "预计分",
	scoreDetail: "预计得分明细",
	removePiece: "撤回这块",
	close: "关闭",
	waitingSubmit: "已提交,等其他人 {{n}}/{{total}}…",
	submit: "提交",
	submitWithCost: "确认提交 · 支出 {{n}}¢",
	submitShortfall: "还差 {{n}}¢ · 暂不能提交",
	clearStaging: "清空重摆",
	cancelPick: "取消选中",
	rotate: "旋转",
	mirror: "镜像",
	changeColor: "换色",
	domino: "2×1",
	buyBlack: "黑格 1¢",
	buyRecolor: "自由绘制 2¢",
	buyExtra: "额外 3¢",
	freeDrawCost: "自由绘制 2¢",
	extraCost: "额外 3¢",
	readyToPlace: "拖入脑板",
	budgetPreview: "本轮预计支出 {{cost}} 分钱，提交后预计剩余 {{left}} 分钱",
	budgetShortfall: "本轮费用还差 {{n}} 分钱",
	shortfall: "差{{n}}¢",
	moneyAria: "现有 {{n}} 分钱",
	goalDone: "达成「{{name}}」+{{n}} 分",
	viewBoardAria: "查看 {{name}} 的大脑",
	colorGreen: "绿",
	colorOrange: "橙",
	colorPurple: "紫",
	colorBlue: "蓝",
	colorPink: "粉",
	colorBlack: "黑",
	scoreSections: "脑区填满",
	scoreGoals: "目标卡",
	scorePurple: "紫·贴橙",
	scoreOrange: "橙·形状轨",
	scorePink: "粉·同形配对",
	scoreBlue: "蓝·缺区",
	scoreEmpty: "空格最多区",
	scoreTotal: "总分",
	goal: {
		sympathy: {
			name: "同情",
			desc: "填满 1×2 灰质周围一圈的 10 格"
		},
		perfectDay: {
			name: "完美的一天",
			desc: "在同一个脑区内画齐 5 种颜色"
		},
		overachiever: {
			name: "卷王",
			desc: "填满任意一整行或一整列"
		},
		serenity: {
			name: "心如止水",
			desc: "不用绿色,填满任意两个脑区"
		},
		soulmate: {
			name: "灵魂伴侣",
			desc: "每个脑区都至少有 1 格粉色"
		},
		adventure: {
			name: "大冒险",
			desc: "填满左侧与右侧两个脑区"
		},
		lifeOfPeace: {
			name: "平静一生",
			desc: "填满右上与左下两个脑区"
		},
		empathy: {
			name: "感同身受",
			desc: "填满 2×2 灰质周围一圈的 12 格"
		}
	},
	errNotNow: "现在不能操作",
	errAlready: "本轮已经提交过了",
	errNoBase: "先画基础形状,才能买额外形状",
	errBadShape: "这组格和形状对不上",
	errNoDie: "这张卡这轮没有骰子",
	errBadColor: "这个颜色对不上骰子",
	errColorUsed: "这个颜色本轮已经用过了",
	errBadExtra: "额外形状必须取自卡列",
	errBadPlace: "放不下:要挨着已有笔画、不挨同色、避开灰质",
	errNoMoney: "钱不够了",
	hintSlot: "第 {{n}} 张卡的形状",
	hintPlace: "画{{slot}}({{color}})",
	hintPlaceRecolor: "画{{slot}}(改色成{{color}},2¢)",
	hintBlack: "买 {{n}} 个黑格填缝",
	hintSkip: "无处可画,空过本轮"
}, $ = {
	green: "绿",
	orange: "橙",
	purple: "紫",
	blue: "蓝",
	pink: "粉",
	black: "黑"
}, rt = {
	green: "G",
	orange: "O",
	purple: "P",
	blue: "B",
	pink: "K",
	black: "#"
}, it = (e) => {
	let t = Math.max(...e.map(([e]) => e)) + 1, n = Math.max(...e.map(([, e]) => e)) + 1, r = [];
	for (let i = 0; i < n; i += 1) {
		let n = "";
		for (let r = 0; r < t; r += 1) n += e.some(([e, t]) => e === r && t === i) ? "#" : "·";
		r.push(n);
	}
	return r.join("/");
}, at = (e, t) => D.filter((n, r) => e[r] === t), ot = (e) => {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) for (let e of n.cells) t.set(e, n.color);
	return t;
}, st = (e, t, n, r) => {
	t === "green" && (n = Math.min(9, n + 1));
	for (let t of e) {
		let e = j[t];
		e >= 0 && M[e].every((e) => r.has(e)) && (n = Math.min(9, n + 1));
	}
	return n;
}, ct = {
	needsAction: (e, t) => e.public.phase === "draw" && e.public.players.find((e) => e.rid === t.rid)?.submitted === !1,
	describeView(e, t) {
		let n = e.public, r = n.players.find((e) => e.rid === t.rid), i = [
			`第 ${n.round}/12 轮。规则:脑板 9×9,格号 = 行×9+列(行 0 在最上,列 0 在最左);X 是灰质不可填。每轮按骰子从卡列选形状画上去:base 形状免费用「点数=卡位」的骰色(掷 6 的色只能画 domino 万能 2×1,domino 可用任意骰色);可花 3¢ 加画额外形状(每色每轮限一次)、花 2¢ 给 base 改色、花 1¢ 填黑格。非首块必须挨着已有笔画,且不得与同色相挨(黑除外)。`,
			`骰子: ${D.map((e, t) => `${e}(${$[e]})=${n.dice[t]}`).join(" ")}`,
			`卡列(slot1 最新): ${n.row.map((e, t) => `slot${t + 1}=形状${e} ${it(N[e])}`).join(" | ")}`,
			`可用骰色: ${[
				1,
				2,
				3,
				4,
				5
			].map((e) => `slot${e}→[${at(n.dice, e).join(",") || "无"}]`).join(" ")};掷 6 的色只能画 domino`,
			`目标卡: ${n.goals.map((e) => {
				let t = nt.goal[e.id];
				return `${t?.name ?? e.id}(${t?.desc ?? ""},${e.flipped ? "已被达成过,低分" : "高分"})`;
			}).join("; ")}`
		];
		if (r) {
			i.push(`你的钱: ${r.money}¢`);
			let e = ot(r.placements), t = [];
			for (let n = 0; n < 9; n += 1) {
				let r = "";
				for (let t = 0; t < 9; t += 1) {
					let i = n * 9 + t;
					r += O.has(i) ? "X" : e.has(i) ? rt[e.get(i)] : ".";
				}
				t.push(`    行${n}: ${r}`);
			}
			i.push("你的脑板(G绿 O橙 P紫 B蓝 K粉 #黑 X灰质 .空):", ...t), i.push("输出 submitTurn:base(首个形状,可 null 空过)+ extras(额外形状)+ blacks(黑格格号数组)。每个形状给 cells=绝对格号数组;base 可带 recolor:true(2¢ 改用任意骰色)。");
		}
		return i.join("\n");
	},
	actionJsonSchema: {
		type: "object",
		properties: {
			type: { const: "submitTurn" },
			base: {
				type: ["object", "null"],
				properties: {
					slot: { anyOf: [{
						type: "integer",
						minimum: 1,
						maximum: 5
					}, { const: "domino" }] },
					color: { enum: [
						"green",
						"orange",
						"purple",
						"blue",
						"pink"
					] },
					cells: {
						type: "array",
						items: {
							type: "integer",
							minimum: 0,
							maximum: 80
						}
					},
					recolor: {
						type: "boolean",
						description: "可选,仅 base:花 2¢ 改用任意骰色"
					}
				},
				required: [
					"slot",
					"color",
					"cells"
				],
				additionalProperties: !1
			},
			extras: {
				type: "array",
				maxItems: 4,
				items: {
					type: "object",
					properties: {
						slot: {
							type: "integer",
							minimum: 1,
							maximum: 5
						},
						color: { enum: [
							"green",
							"orange",
							"purple",
							"blue",
							"pink"
						] },
						cells: {
							type: "array",
							items: {
								type: "integer",
								minimum: 0,
								maximum: 80
							}
						}
					},
					required: [
						"slot",
						"color",
						"cells"
					],
					additionalProperties: !1
				}
			},
			blacks: {
				type: "array",
				maxItems: 9,
				items: {
					type: "integer",
					minimum: 0,
					maximum: 80
				}
			}
		},
		required: [
			"type",
			"base",
			"extras",
			"blacks"
		],
		additionalProperties: !1
	},
	parseAction(e, t, n) {
		let r = K.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public;
		if (a.phase !== "draw") return null;
		let o = a.players.find((e) => e.rid === n.rid);
		if (!o || o.submitted || i.base === null && i.extras.length > 0) return null;
		let s = ot(o.placements), c = o.money, l = /* @__PURE__ */ new Set(), u = (e, t) => {
			let n = e.slot === "domino" ? P(ne) : P(N[a.row[e.slot - 1]]);
			if (new Set(e.cells).size !== e.cells.length || le(e.cells) !== n) return !1;
			if (t) {
				if ("recolor" in e && e.recolor) {
					if (c < 2) return !1;
					c -= 2;
				} else if (e.slot !== "domino" && !at(a.dice, e.slot).includes(e.color)) return !1;
			} else {
				if (e.slot === "domino" || !at(a.dice, e.slot).includes(e.color) || l.has(e.color) || c < 3) return !1;
				c -= 3;
			}
			if (!H(s, e.cells, e.color, s.size === 0)) return !1;
			for (let t of e.cells) s.set(t, e.color);
			return l.add(e.color), c = st(e.cells, e.color, c, s), !0;
		};
		if (i.base && !u(i.base, !0)) return null;
		for (let e of i.extras) if (!u(e, !1)) return null;
		for (let e of i.blacks) {
			if (c < 1 || O.has(e) || s.has(e) || s.size === 0 || !ce(e).some((e) => s.has(e))) return null;
			--c, s.set(e, "black"), c = st([e], "black", c, s);
		}
		return i;
	}
};
//#endregion
//#region src/games/mindspace/fx.tsx
function lt({ at: e, id: t, points: i }) {
	let o = c(), s = oe(t), l = a(null), u = e.h > 48 ? Math.max(14, e.h * .36) : 14;
	return r(() => {
		let t = l.current;
		if (!t) return;
		let n = t.getBoundingClientRect().width, r = t.offsetParent?.clientWidth;
		if (!r) return;
		let i = Math.max(n / 2 + 8, Math.min(r - n / 2 - 8, e.x + e.w / 2));
		t.style.left = `${i}px`;
	}, [e, u]), n(() => {
		let e = l.current;
		if (!e) return;
		let t = e.animate([
			{
				transform: "translate(-50%, 0)",
				opacity: 0
			},
			{
				transform: "translate(-50%, -6px)",
				opacity: 1,
				offset: .2
			},
			{
				transform: "translate(-50%, -28px)",
				opacity: 0
			}
		], {
			duration: 1200,
			delay: 150,
			easing: "ease-out",
			fill: "both"
		});
		return () => t.cancel();
	}, [e]), /* @__PURE__ */ h("div", {
		ref: l,
		className: "mindspace-goal-floater text-done-ink",
		style: {
			left: e.x + e.w / 2,
			top: Math.max(36, e.y - 6),
			fontSize: u
		},
		children: o("games.mindspace.goalDone", {
			name: s ? o(s.nameKey) : t,
			n: i
		})
	});
}
var ut = {
	place(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ h(S, {
				at: n,
				ms: 600
			})
		} : null;
	},
	goal(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.id != "string" || typeof n.points != "number" ? null : {
			ms: 1300,
			node: /* @__PURE__ */ h(lt, {
				at: r,
				id: n.id,
				points: n.points
			})
		};
	},
	round() {
		return null;
	}
}, dt = [
	{
		key: "games.mindspace.scoreSections",
		field: "sections"
	},
	{
		key: "games.mindspace.scoreGoals",
		field: "goals"
	},
	{
		key: "games.mindspace.scorePurple",
		field: "purple"
	},
	{
		key: "games.mindspace.scoreOrange",
		field: "orange"
	},
	{
		key: "games.mindspace.scorePink",
		field: "pink"
	},
	{
		key: "games.mindspace.scoreBlue",
		field: "blue"
	},
	{
		key: "games.mindspace.scoreEmpty",
		field: "empty"
	}
];
function ft(e) {
	let t = be.safeParse(e.public), n = e.result.ranking;
	return t.success && t.data.phase === "done" && n.length >= 1 && n.length <= 5 && new Set(n).size === n.length && n.every((e) => t.data.players.some((t) => t.rid === e)) ? /* @__PURE__ */ h(mt, {
		...e,
		pub: t.data
	}) : /* @__PURE__ */ h(E, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: de.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby
	});
}
function pt(e, t) {
	let n = a(null);
	return r(() => {
		let r = n.current;
		if (!r) return;
		let i = window.matchMedia("(orientation: landscape)"), a = [
			"pad",
			"gap",
			"top",
			"action",
			"heading",
			"rank-w",
			"rank-h",
			"board-w",
			"avatar",
			"name",
			"meta",
			"rank-score",
			"plaque",
			"board-label",
			"sheet-pad",
			"sheet-head",
			"sheet-name",
			"total",
			"row",
			"label",
			"value",
			"goals",
			"goal-font",
			"button"
		], o = () => {
			let { width: n, height: a } = r.getBoundingClientRect(), o = i.matches && n >= 900 && a >= 480, s = i.matches && n >= 600 && !o, c = o ? "table" : s ? "low" : "flow", l = Math.max(4, Math.min(n, a) * .008), u = Math.max(6, l), d = o ? Math.max(40, a * .065) : 40, f = t > 1 && !o && !s ? 104 : t > 0 ? Math.max(48, o ? a * .075 : 48) : Math.max(40, o ? a * .06 : 40), p = a - 2 * l - d - f - 2 * u, m = n - 2 * l, h = (o || s) && e > 1, g = h ? o ? Math.max(200, Math.min(m * .22, p * .42)) : Math.max(168, m * .23) : m, _ = h ? o ? Math.max(72, (p - 7 - (e - 1) * u) / e) : 78 : o ? Math.max(80, a * .1) : s ? 80 : 88, v = h ? m - g - u : m, y = h ? p : p - _ - u, b = o ? Math.min(y, v * .6) : s ? Math.min(y, v * .44) : v, x = o || s ? v - b - u : v, S = o ? Math.max(8, Math.min(n, a) * .012) : 9, C = o ? Math.max(60, y * .11) : 62, w = o ? Math.max(72, y * .14) : 78, T = o ? Math.max(32, (y - 4 - 2 * S - C - w) / 7) : 34, E = o ? Math.max(14, Math.min(T * .37, x * .067)) : 14, D = o && _ >= 190 && e > 1, O = o ? Math.max(15, Math.min(_ * (D ? .13 : .19), g * (D ? .1 : .075))) : 16, k = o ? Math.max(11, Math.min(_ * (D ? .07 : .1), g * (D ? .055 : .043))) : 11, A = o ? Math.max(28, Math.min(_ * (D ? .23 : .29), g * (D ? .22 : .16))) : 27, j = 2 * (Math.max(14, k * 1.2) + 2), M = D ? _ - O * 1.2 - 3 - j - A - 2 * u - 16 : _, ee = o ? Math.max(38, Math.min(_ * (D ? .35 : .58), g * (D ? .42 : .24), M)) : 44, te = {
				pad: l,
				gap: u,
				top: d,
				action: f,
				heading: d * .53,
				"rank-w": g,
				"rank-h": _,
				"board-w": b,
				avatar: ee,
				name: O,
				meta: k,
				"rank-score": A,
				plaque: o ? Math.max(24, a * .032) : 24,
				"board-label": o ? Math.max(11, a * .017) : 11,
				"sheet-pad": S,
				"sheet-head": C,
				"sheet-name": o ? Math.max(18, Math.min(C * .36, x * .075)) : 18,
				total: o ? Math.max(34, C * .65) : 34,
				row: T,
				label: E,
				value: o ? Math.max(23, T * .55) : 22,
				goals: w,
				"goal-font": o ? Math.max(13, Math.min(E * .85, x * .045)) : 12,
				button: o ? Math.max(18, f * .31) : 17
			};
			r.dataset.layout = c, r.dataset.verticalRank = String(D), r.dataset.columns = String(h), r.dataset.single = String(e === 1);
			for (let [e, t] of Object.entries(te)) {
				let n = `${t.toFixed(4)}px`;
				r.style.getPropertyValue(`--ms-final-${e}`) !== n && r.style.setProperty(`--ms-final-${e}`, n);
			}
		}, s = new ResizeObserver(o);
		return s.observe(r), i.addEventListener("change", o), o(), () => {
			s.disconnect(), i.removeEventListener("change", o), delete r.dataset.layout, delete r.dataset.verticalRank, delete r.dataset.columns, delete r.dataset.single;
			for (let e of a) r.style.removeProperty(`--ms-final-${e}`);
		};
	}, [e, t]), n;
}
function mt({ pub: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let l = c(), u = s((e) => e.locale), d = pt(t.ranking.length, Number(!!i) + Number(!!a)), [p, v] = o(null), y = p && t.ranking.includes(p) ? p : t.ranking[0], b = e.players.find((e) => e.rid === y), x = /* @__PURE__ */ new Map();
	for (let e of b.placements) for (let t of e.cells) x.set(t, e.color);
	let S = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, u) : e;
	};
	return /* @__PURE__ */ g("div", {
		ref: d,
		className: "mindspace-final",
		children: [t.winner.length > 0 && /* @__PURE__ */ h(T, {}), /* @__PURE__ */ h(f, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "mindspace-final-action-height",
			banner: /* @__PURE__ */ g("h1", {
				className: "mindspace-final-title",
				children: [/* @__PURE__ */ h("img", {
					src: "games/mindspace/brain-board.webp",
					alt: "",
					"aria-hidden": !0
				}), l("session.result.title")]
			}),
			actions: i || a ? /* @__PURE__ */ g("div", {
				className: "mindspace-final-actions",
				children: [i && /* @__PURE__ */ h("button", {
					type: "button",
					className: "mindspace-final-play",
					onClick: i,
					children: l("session.result.playAgain")
				}), a && /* @__PURE__ */ h("button", {
					type: "button",
					className: "mindspace-final-back",
					onClick: a,
					children: l("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ h("p", {
				className: "mindspace-final-wait",
				children: l("session.result.waitHost")
			}),
			children: /* @__PURE__ */ g("div", {
				className: "mindspace-final-body",
				children: [/* @__PURE__ */ h("nav", {
					className: "mindspace-final-ranking",
					"aria-label": l("session.result.title"),
					children: /* @__PURE__ */ h("ol", { children: t.ranking.map((e, i) => {
						let a = n.find((t) => t.rid === e), o = t.autopilot?.[e], s = S(e);
						return /* @__PURE__ */ h("li", { children: /* @__PURE__ */ g("button", {
							type: "button",
							className: "mindspace-final-person",
							"aria-pressed": e === y,
							onClick: () => v(e),
							children: [
								/* @__PURE__ */ g("span", {
									className: "mindspace-final-avatar",
									style: { backgroundColor: w[(a?.colorIndex ?? 0) % w.length].hex },
									children: [
										a && /* @__PURE__ */ h("img", {
											src: C[a.avatar % C.length],
											alt: "",
											draggable: !1
										}),
										/* @__PURE__ */ h("b", {
											className: "mindspace-final-rank",
											children: i + 1
										}),
										t.winner.includes(e) && /* @__PURE__ */ h("span", {
											className: "mindspace-final-crown",
											"aria-hidden": !0,
											children: "👑"
										})
									]
								}),
								/* @__PURE__ */ g("span", {
									className: "mindspace-final-person-copy",
									children: [/* @__PURE__ */ h("strong", {
										title: s,
										children: s
									}), /* @__PURE__ */ g("span", {
										className: "mindspace-final-meta",
										children: [e === r && /* @__PURE__ */ h("small", { children: l("lobby.you") }), o !== void 0 && o > 0 && /* @__PURE__ */ g("small", { children: [/* @__PURE__ */ h(_, { size: 14 }), l("session.autopilot.share", { n: Math.round(o * 100) })] })]
									})]
								}),
								/* @__PURE__ */ h("b", {
									className: "mindspace-final-rank-score",
									children: t.scores?.[e] ?? "—"
								})
							]
						}) }, e);
					}) })
				}), /* @__PURE__ */ g("div", {
					className: "mindspace-final-detail",
					tabIndex: 0,
					"aria-label": l("games.mindspace.viewBoardAria", { name: S(y) }),
					children: [/* @__PURE__ */ g("section", {
						className: "mindspace-final-board",
						"aria-label": l("games.mindspace.boardOf", { name: S(y) }),
						children: [/* @__PURE__ */ h("div", {
							className: "mindspace-final-board-image",
							children: /* @__PURE__ */ h(Re, {
								filled: x,
								staged: [],
								ghost: null,
								interactive: !1
							})
						}), /* @__PURE__ */ g("div", {
							className: "mindspace-board-plaque",
							children: [
								/* @__PURE__ */ h("span", {
									"aria-hidden": !0,
									children: "✦"
								}),
								l("games.mindspace.boardLabel"),
								/* @__PURE__ */ h("span", {
									"aria-hidden": !0,
									children: "✦"
								})
							]
						})]
					}), /* @__PURE__ */ g("section", {
						className: "mindspace-final-sheet",
						tabIndex: 0,
						"aria-label": l("games.mindspace.scoreTotal"),
						children: [
							/* @__PURE__ */ g("header", {
								className: "mindspace-final-sheet-head",
								children: [/* @__PURE__ */ h("h2", {
									title: S(y),
									children: S(y)
								}), /* @__PURE__ */ g("span", {
									className: "mindspace-final-sheet-total",
									children: [l("games.mindspace.scoreTotal"), /* @__PURE__ */ h("b", { children: t.scores?.[y] ?? "—" })]
								})]
							}),
							/* @__PURE__ */ h("ul", {
								className: "mindspace-final-scores",
								children: dt.map(({ key: e, field: t }) => {
									let n = b.breakdown?.[t];
									return /* @__PURE__ */ g("li", {
										"data-zero": n === 0,
										children: [/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("i", {
											"data-ink": t,
											"aria-hidden": !0
										}), l(e)] }), /* @__PURE__ */ h("b", { children: n === void 0 ? "—" : n > 0 ? `+${n}` : n })]
									}, t);
								})
							}),
							/* @__PURE__ */ h("ul", {
								className: "mindspace-final-goals",
								children: Object.entries(b.goalScores).map(([e, t]) => {
									let n = oe(e);
									return /* @__PURE__ */ g("li", { children: [
										n ? l(n.nameKey) : e,
										" +",
										t
									] }, e);
								})
							})
						]
					})]
				})]
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/mindspace/entry.tsx
var ht = {
	definition: Pe,
	View: Ye,
	bot: Q,
	describe: tt,
	llm: ct,
	fx: ut,
	OverView: ft,
	locales: {
		zh: nt,
		en: {
			name: "Mind Space",
			desc: "Draw shapes according to the dice across 12 rounds, complete brain sections and objective cards, and score color effects.",
			rules: "Goal:\n· The game lasts 12 rounds. At the end, score objective cards, brain sections, and color effects; the highest total wins.\n· Players tied for the highest score share the victory.\nSetup:\n· Each player receives a nine-by-nine brain board and 1 cent.\n· The board has five sections; gray matter spaces cannot be drawn on.\n· Gray matter counts as filled only when checking whether a section, row, or column is complete.\n· Display five shape cards and draw one objective card from each of the A, B, and C groups.\n· Roll five dice of different colors; their values determine which shape cards can be used without paying.\nEach round:\n· All players plan their actions on their own boards at the same time, then submit them.\n· Values 1 through 5 refer to the shape card with the same number; a shape placed without paying uses a matching die color.\n· A value of 6 does not refer to a shape card; the two-space domino may always serve as the base shape without paying and use any die color.\n· At most one base shape may be placed each round; a player may also submit without placing a shape.\n· From round 2 onward, remove the oldest shape card, add a new card, and roll the dice again.\nPlacement:\n· Shapes may be rotated or mirrored, but may not extend beyond the board or cover gray matter or filled spaces.\n· If the board has no marks, the first shape may be placed on any available spaces.\n· Every later shape must share an edge with at least one filled space.\n· A colored shape may not share an edge with a filled space of the same color; touching at a corner does not count.\n· Staged shapes may be moved, rotated, mirrored, or removed; they become permanent only after submission.\nMoney and additional drawing:\n· For 2 cents, Free Draw lets you choose any of the five visible shape cards and any die color for the base shape.\n· Free Draw replaces the normal base shape; it does not increase the number of shapes you may place.\n· After placing a base shape, pay 3 cents per additional shape, up to four additional shapes per round.\n· An additional shape must come from a card with a die and use one of its die colors that has not been used this round.\n· Additional shapes cannot use the two-space domino or a card with no die.\n· Pay 1 cent to fill one black space; it must share an edge with a drawn space and may touch other black spaces.\n· You may buy at most nine black spaces per round; a black space cannot be the first mark.\n· Gain 1 cent for each green shape drawn and 1 cent for each section completed.\n· You may hold at most 9 cents. On submission, resolve the base shape, additional shapes, then black spaces in that order.\n· If you cannot pay at any point, the submission fails and the staged pieces can be adjusted.\nObjective cards:\n· Each player may score each objective card once; check its condition after submission.\n· All players who meet an objective in the same round receive its unflipped score; flip the card at the end of that round.\n· Players who first meet it after the flip receive the lower score shown on the card.\n· Sympathy: fill the 10 designated spaces around the two-space gray matter area.\n· The Perfect Day: place all five die colors within one section.\n· Overachiever: fill any complete row or column of the board.\n· Serenity: complete two sections that contain no green spaces.\n· Soulmate: place at least one pink space in each section.\n· Adventure: complete the left and right sections.\n· A Life of Peace: complete the upper-right and lower-left sections.\n· Empathy: fill the 12 designated spaces around the four-space gray matter area.\nScoring:\n· Gain 10 points for each completed outer section and 5 points for the completed center section.\n· Each purple space sharing an edge with an orange space scores 2 points, even if several orange spaces touch it.\n· Score orange shapes as follows: zero through four shapes score 0, 3, 6, 10, and 15 points; five or more score 20.\n· For each pair of matching pink and non-pink shapes, score the number of spaces in the non-pink shape; rotations and reflections still match.\n· Penalize sections without blue: zero through five missing sections cost 0, 4, 7, 9, 12, and 16 points.\n· Find the section with the most empty spaces and lose that many points; gray matter is not empty.\n· Add points earned from objective cards; green shapes, black spaces, and leftover cents do not score directly.",
			roundShort: "{{n}}/{{total}}",
			drawPrompt: "Pick a shape, draw it in your brain",
			boardLabel: "BRAIN BOARD A · FIVE AREAS",
			boardOf: "{{name}}'s brain board",
			playerDrawing: "Drawing this round",
			playerDone: "Finished this round",
			guideEmptyTitle: "Pick a shape, draw a thought",
			guideEmptyDetail: "Your first piece can go on any free cell",
			guideArmedTitle: "Place the shape on your brain",
			guideArmedDetail: "Tap a cell, or rotate and flip first",
			guideStagedTitle: "Piece staged",
			guideStagedDetail: "Drag to move; tap or use nearby tools",
			guidePaidTitle: "Free draw · 2¢",
			guidePaidDetail: "Drag onto the board, then change color nearby",
			guideExtraTitle: "Extra shape · 3¢",
			guideExtraDetail: "Pick a card with an unused die color",
			guideShortfallTitle: "{{n}}¢ short",
			guideShortfallDetail: "Keep editing; money is spent on submit",
			guideBlackTitle: "Fill a black cell",
			guideBlackDetail: "Tap a free cell to add or undo",
			guideViewingTitle: "Viewing another brain",
			guideViewingDetail: "Pick your name to keep drawing",
			returnBoard: "My brain board",
			estimatedScore: "Est.",
			scoreDetail: "Estimated score",
			removePiece: "Remove piece",
			close: "Close",
			waitingSubmit: "Submitted, waiting {{n}}/{{total}}…",
			submit: "Submit",
			submitWithCost: "Submit · spend {{n}}¢",
			submitShortfall: "{{n}}¢ short · cannot submit",
			clearStaging: "Clear",
			cancelPick: "Cancel selection",
			rotate: "Rotate",
			mirror: "Flip",
			changeColor: "Change color",
			domino: "2×1",
			buyBlack: "Black 1¢",
			buyRecolor: "Free draw 2¢",
			buyExtra: "Extra 3¢",
			freeDrawCost: "Free draw 2¢",
			extraCost: "Extra 3¢",
			readyToPlace: "Drag to brain",
			budgetPreview: "Expected cost {{cost}} cents; about {{left}} cents left after submitting",
			budgetShortfall: "{{n}} cents short for this turn",
			shortfall: "{{n}}¢ short",
			moneyAria: "{{n}} cents left",
			goalDone: "{{name}} achieved, +{{n}}",
			viewBoardAria: "View {{name}}'s brain",
			colorGreen: "Green",
			colorOrange: "Orange",
			colorPurple: "Purple",
			colorBlue: "Blue",
			colorPink: "Pink",
			colorBlack: "Black",
			scoreSections: "Sections",
			scoreGoals: "Goals",
			scorePurple: "Purple×orange",
			scoreOrange: "Orange track",
			scorePink: "Pink matches",
			scoreBlue: "Blue penalty",
			scoreEmpty: "Empty spaces",
			scoreTotal: "Total",
			goal: {
				sympathy: {
					name: "Sympathy",
					desc: "Fill the 10 spaces around the 2×1 gray area"
				},
				perfectDay: {
					name: "The Perfect Day",
					desc: "Fill one section with all 5 colors"
				},
				overachiever: {
					name: "Overachiever",
					desc: "Fill any complete row or column"
				},
				serenity: {
					name: "Serenity",
					desc: "Fill two sections without using green"
				},
				soulmate: {
					name: "Soulmate",
					desc: "Have at least 1 pink space in every section"
				},
				adventure: {
					name: "Adventure",
					desc: "Fill the left and right sections"
				},
				lifeOfPeace: {
					name: "A Life of Peace",
					desc: "Fill the top-right and bottom-left sections"
				},
				empathy: {
					name: "Empathy",
					desc: "Fill the 12 spaces around the 2×2 gray area"
				}
			},
			errNotNow: "Not right now",
			errAlready: "Already submitted this round",
			errNoBase: "Draw your base shape before buying extras",
			errBadShape: "Those cells don’t match the shape",
			errNoDie: "No die on that card this round",
			errBadColor: "That color doesn’t match the dice",
			errColorUsed: "Color already used this turn",
			errBadExtra: "Extra shapes must come from the card row",
			errBadPlace: "No fit: must touch your drawing, avoid same color and gray matter",
			errNoMoney: "Not enough money",
			hintSlot: "the shape of card {{n}}",
			hintPlace: "Draw {{slot}} ({{color}})",
			hintPlaceRecolor: "Draw {{slot}} (recolored to {{color}}, 2¢)",
			hintBlack: "Buy {{n}} black cells",
			hintSkip: "Nothing fits — skip this round"
		}
	}
};
//#endregion
export { ht as default };
