import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { DICE_ROLL_MS as t } from "@bgparty/sdk/fx/dice-roll-ms";
import { z as n } from "zod";
import { useCallback as r, useEffect as i, useId as a, useLayoutEffect as o, useRef as s, useState as c } from "react";
import { useFxAnchor as l, useFxAnchorsMaybe as u } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as d, useI18nSettings as f, useT as p } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as m } from "@bgparty/sdk/player-colors";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as g } from "@bgparty/sdk/ui/log-sheet";
import { IconClose as _ } from "@bgparty/sdk/icons";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { DeltaNumber as x } from "@bgparty/sdk/fx/delta-number";
import { usePrefersReducedMotion as ee } from "@bgparty/sdk/fx/use-reduced-motion";
import { createDiceRollRenderer as S } from "@bgparty/sdk/fx/dice-roll";
import { Flash as C, Floater as w, FlySprite as T, PulseBox as E } from "@bgparty/sdk/fx/primitives";
import { botAvatarOf as te } from "@bgparty/sdk/lobby";
import { Confetti as D } from "@bgparty/sdk/ui/confetti";
//#region src/games/magicalathlete/meta.ts
var O = {
	id: "magicalathlete",
	tier: "beta",
	mechanics: [
		"drafting",
		"race",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.magicalathlete.name",
	descKey: "games.magicalathlete.desc",
	rulesKey: "games.magicalathlete.rules",
	icon: "🏅",
	iconImg: "games/magicalathlete.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/magicalathlete/en.pdf" },
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [5, 6],
	accent: "#f97316",
	releasedAt: "2026-09-21",
	search: {
		py: "hu nao yun dong hui",
		init: "hnydh"
	},
	hotseat: "cover"
}, k = /* @__PURE__ */ "alchemist.babayaga.banana.blimp.centaur.cheerleader.coach.copycat.dicemonger.duelist.egg.flipflop.genius.gunk.hare.heckler.hugebaby.hypnotist.inchworm.lackey.leaptoad.legs.lovableloser.mouth.magician.mastermind.partyanimal.rocket.romantic.scoocher.sisyphus.skipper.stickler.suckerfish.thirdwheel.twin".split("."), ne = /* @__PURE__ */ new Set([
	"egg",
	"twin",
	"sisyphus"
]), A = {
	1: { kind: "star" },
	5: { kind: "trip" },
	7: {
		kind: "arrow",
		n: 3
	},
	11: {
		kind: "arrow",
		n: 1
	},
	13: { kind: "star" },
	16: {
		kind: "arrow",
		n: -4
	},
	17: { kind: "trip" },
	23: {
		kind: "arrow",
		n: 2
	},
	24: {
		kind: "arrow",
		n: -2
	},
	26: { kind: "trip" }
}, re = [
	"mild",
	"wild",
	"mild",
	"wild"
], ie = (e) => e + 2, ae = (e) => e, j = n.enum(k), M = n.string(), N = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("tick"),
		now: n.number()
	}),
	n.object({
		type: n.literal("draftPick"),
		racer: j
	}),
	n.object({
		type: n.literal("selectRacer"),
		racer: j
	}),
	n.object({
		type: n.literal("roll"),
		predict: n.int().min(1).max(6).optional()
	}),
	n.object({
		type: n.literal("altMove"),
		kind: n.enum(["flipflop", "legs"]),
		target: j.optional()
	}),
	n.object({
		type: n.literal("prePower"),
		power: n.enum([
			"cheerleader",
			"hypnotist",
			"thirdwheel",
			"none"
		]),
		target: j.optional(),
		space: n.int().min(0).max(29).optional()
	}),
	n.object({
		type: n.literal("respond"),
		accept: n.boolean().optional(),
		racerIdx: n.int().optional(),
		racerId: j.optional()
	})
]), P = n.discriminatedUnion("kind", [
	n.object({
		kind: n.literal("prePower"),
		who: M,
		powers: n.array(n.enum([
			"cheerleader",
			"hypnotist",
			"thirdwheel"
		]))
	}),
	n.object({
		kind: n.enum([
			"alchemist",
			"rocket",
			"magician",
			"dicemonger"
		]),
		who: M,
		die: n.int().min(1).max(6)
	}),
	n.object({
		kind: n.literal("suckerfish"),
		who: M,
		mover: n.int(),
		dest: n.int()
	}),
	n.object({
		kind: n.literal("duelist"),
		who: M,
		candidates: n.array(n.int())
	}),
	n.object({
		kind: n.literal("copycat"),
		who: M,
		leaders: n.array(n.int())
	}),
	n.object({
		kind: n.literal("mastermind"),
		who: M
	}),
	n.object({
		kind: n.literal("egg"),
		who: M
	}),
	n.object({
		kind: n.literal("twin"),
		who: M,
		winners: n.array(j)
	})
]), F = n.object({
	id: j,
	owner: M,
	pos: n.int(),
	tripped: n.boolean(),
	eliminated: n.boolean(),
	place: n.int(),
	copied: j.nullable(),
	power: j.nullable()
}), oe = n.discriminatedUnion("k", [
	n.object({
		k: n.literal("draft"),
		rid: M,
		racer: j
	}),
	n.object({
		k: n.literal("raceStart"),
		n: n.int(),
		track: n.enum(["mild", "wild"])
	}),
	n.object({ k: n.literal("select") }),
	n.object({
		k: n.literal("roll"),
		rid: M,
		n: n.int(),
		reroll: n.boolean().optional()
	}),
	n.object({
		k: n.literal("move"),
		racer: j,
		n: n.int()
	}),
	n.object({
		k: n.literal("trip"),
		racer: j
	}),
	n.object({
		k: n.literal("points"),
		rid: M,
		n: n.int()
	}),
	n.object({
		k: n.literal("elim"),
		racer: j
	}),
	n.object({
		k: n.literal("warp"),
		racer: j
	}),
	n.object({
		k: n.literal("swap"),
		a: j,
		b: j
	}),
	n.object({
		k: n.literal("finish"),
		racer: j,
		n: n.int()
	}),
	n.object({
		k: n.literal("award"),
		rid: M,
		medal: n.enum(["gold", "silver"]),
		n: n.int()
	}),
	n.object({
		k: n.literal("duel"),
		a: j
	}),
	n.object({
		k: n.literal("predict"),
		rid: M,
		racer: j
	}),
	n.object({
		k: n.literal("genius"),
		rid: M,
		n: n.int()
	}),
	n.object({
		k: n.literal("skip"),
		racer: j
	}),
	n.object({
		k: n.literal("power"),
		racer: j
	})
]), I = n.object({
	num: n.int().min(1).max(4),
	track: n.enum(["mild", "wild"]),
	racers: n.array(n.object({
		owner: M,
		id: j,
		copied: j.nullable(),
		eliminated: n.boolean(),
		gold: n.boolean(),
		silver: n.boolean(),
		medalPoints: n.int(),
		gained: n.int().min(0),
		lost: n.int().min(0),
		points: n.int()
	}))
}), L = n.object({
	phase: n.enum([
		"draft",
		"select",
		"race",
		"done"
	]),
	raceNum: n.int().min(1).max(4),
	players: n.array(M),
	scores: n.record(n.string(), n.int()),
	winners: n.array(j),
	results: n.array(I).optional(),
	draft: n.object({
		pool: n.array(j),
		picker: M,
		round: n.int(),
		hands: n.record(n.string(), n.array(j))
	}).nullable(),
	select: n.object({ picked: n.array(M) }).nullable(),
	race: n.object({
		track: n.enum(["mild", "wild"]),
		step: n.enum([
			"preMove",
			"preOffer",
			"rollChoice",
			"postRoll",
			"moving"
		]),
		die: n.int().nullable(),
		predictedRoll: n.int().nullable(),
		predictions: n.array(n.int().nullable()),
		racers: n.array(F),
		turn: M,
		pending: P.nullable(),
		busy: n.boolean(),
		finishedCount: n.int()
	}).nullable(),
	log: n.array(oe)
}), se = n.object({
	myPick: j.nullable(),
	eggOptions: n.array(j),
	myHand: n.array(j),
	myUsed: n.array(j)
}), R = {
	move: (e) => Math.min(620 + 110 * Math.abs(e), 1750),
	trip: 680,
	points: 700,
	elim: 850,
	warp: 720,
	swap: 850,
	duel: 900,
	recover: 620,
	skip: 620
}, ce = t.banner(1), le = 360;
function z(e) {
	let t = [];
	return e.racers.forEach((e, n) => {
		!e.eliminated && e.place === 0 && t.push(n);
	}), t;
}
function ue(e, t) {
	return e.racers.some((e) => !e.eliminated && e.place === 0 && e.pos === t);
}
function B(e, t) {
	let n = e.racers[t];
	return n.eliminated || n.place !== 0 || n.id === "copycat" ? null : n.copied ? ne.has(n.copied) ? null : n.copied : n.id;
}
function de(e, t) {
	let n = -1;
	for (let t of z(e)) n = Math.max(n, e.racers[t].pos);
	return z(e).filter((r) => r !== t && e.racers[r].pos === n && B(e, r) !== null);
}
function V(e, t) {
	let n = e.racers[t];
	if (n.eliminated || n.place !== 0) return null;
	if (n.id === "copycat" || n.copied === "copycat") {
		let n = de(e, t);
		if (n.length === 0) return null;
		let r = n.length === 1 ? n[0] : e.copycatChoice[t];
		return r === null || !n.includes(r) ? null : B(e, r);
	}
	return n.copied ? ne.has(n.copied) ? null : n.copied : n.id;
}
function H(e, t) {
	return z(e).filter((n) => V(e, n) === t);
}
function U(e, t, n, r) {
	let i = e.racers[t], a = r ?? V(e, t);
	if (!a) return;
	let o = n.powers ??= [];
	o.some((e) => e.owner === i.owner && e.power === a) || o.push({
		owner: i.owner,
		racer: i.id,
		power: a,
		pos: i.pos
	});
}
function W(e, t, n) {
	if (U(e, t, n), V(e, t) !== "scoocher") for (let n of H(e, "scoocher")) n !== t && e.queue.push({
		k: "move",
		i: n,
		n: 1,
		main: !1,
		cause: "scoocher"
	});
}
function fe(e, t) {
	let n = z(e), r = e.racers[t].pos;
	return n.every((n) => n === t || e.racers[n].pos < r);
}
function G(e, t) {
	let n = z(e), r = e.racers[t].pos;
	return n.every((n) => n === t || e.racers[n].pos > r);
}
function K(e) {
	return e.turnOrder[e.turnIdx];
}
function pe(e, t, n) {
	let r = (r) => r !== n && e.racers[r].pos === t && !e.racers[r].eliminated && e.racers[r].place === 0, i = z(e).find((t) => r(t) && e.racers[t].id === "hugebaby" && !e.racers[t].copied);
	return i === void 0 ? z(e).find((t) => r(t) && V(e, t) === "hugebaby") ?? null : i;
}
function q(e, t) {
	if (t.powers?.length) {
		let n = t.fx.find((e) => e.kind === "move"), r = Math.max(60, t.fx.length ? e.beatMs : Math.min(e.beatMs, 600));
		t.fx.splice(Math.min(1, t.fx.length), 0, {
			kind: "power",
			with: t.fx.length > 0,
			data: {
				cues: t.powers,
				ms: r,
				delay: n ? Math.max(0, r - 280) : 0
			}
		});
		for (let e of t.powers) t.log.some((t) => t.k === "power" && t.racer === e.racer) || t.log.push({
			k: "power",
			racer: e.racer
		});
	}
	e.log.push(...t.log), e.log.length > 100 && (e.log = e.log.slice(-100)), t.log = [];
}
function me(e, t, n, r, i, a = 0) {
	let o = t.racers[n];
	if (a < 3 && o.pos !== 0) {
		let r = pe(t, o.pos, n);
		if (r !== null) {
			o.pos = Math.max(0, t.racers[r].pos - 1), i.fx.push({
				kind: "warp",
				rid: o.owner,
				data: {
					i: n,
					to: o.pos,
					cause: "hugebaby",
					racer: o.id
				}
			}), W(t, r, i), me(e, t, n, !1, i, a + 1);
			return;
		}
		if (V(t, n) === "hugebaby") {
			let r = z(t).filter((e) => e !== n && t.racers[e].pos === o.pos);
			for (let s of r) t.racers[s].pos = Math.max(0, o.pos - 1), i.fx.push({
				kind: "warp",
				rid: t.racers[s].owner,
				data: {
					i: s,
					to: t.racers[s].pos,
					cause: "hugebaby",
					racer: t.racers[s].id
				}
			}), W(t, n, i), me(e, t, s, !1, i, a + 1);
		}
	}
	if (r && t.track === "wild") {
		let e = A[o.pos];
		e && (e.kind === "star" ? t.queue.push({
			k: "points",
			i: n,
			n: 1
		}) : e.kind === "arrow" ? t.queue.push({
			k: "move",
			i: n,
			n: e.n,
			main: !1,
			cause: "arrow"
		}) : t.queue.push({
			k: "trip",
			i: n
		}));
	}
	let s = z(t).filter((e) => t.racers[e].pos === o.pos);
	if (V(t, n) === "babayaga") for (let e of s) e !== n && (t.queue.push({
		k: "trip",
		i: e
	}), W(t, n, i));
	for (let e of s) e !== n && V(t, e) === "babayaga" && (t.queue.push({
		k: "trip",
		i: n
	}), W(t, e, i));
	let c = s.filter((e) => e !== n);
	if (V(t, n) === "mouth" && c.length === 1 && (t.queue.push({
		k: "elim",
		i: c[0]
	}), W(t, n, i)), s.length === 2) for (let e of H(t, "romantic")) t.queue.push({
		k: "move",
		i: e,
		n: 2,
		main: !1,
		cause: "romantic"
	}), W(t, e, i);
	let l = s.filter((e) => V(t, e) === "duelist");
	for (let e of l) {
		let n = s.filter((t) => t !== e);
		if (n.length > 0 && !t.pending) {
			t.pending = {
				kind: "duelist",
				who: t.racers[e].owner,
				duelist: e,
				candidates: n,
				rest: l.slice(l.indexOf(e) + 1)
			};
			break;
		}
	}
}
function he(e, t, n, r, i, a, o, s, c) {
	let l = t.racers[n], u = i >= 30;
	if (l.pos = Math.min(i, 30), c.fx.push({
		kind: "move",
		rid: l.owner,
		data: {
			i: n,
			from: r,
			to: l.pos,
			cause: o,
			main: a,
			racer: l.id
		}
	}), c.log.push({
		k: "move",
		racer: l.id,
		n: i - r
	}), u) {
		if (l.place = ++t.finishedCount, c.fx.push({
			kind: "finish",
			rid: l.owner,
			data: {
				i: n,
				place: l.place
			}
		}), c.log.push({
			k: "finish",
			racer: l.id,
			n: l.place
		}), l.place === 1) {
			for (let e of H(t, "mastermind")) if (t.predictions[e] === n) {
				t.mastermindHit = e, U(t, e, c, "mastermind"), e !== n && t.finishedCount < 2 && (t.racers[e].place = 2, t.finishedCount = 2);
				break;
			}
		}
		return;
	}
	let d = z(t).filter((e) => e !== n && r < t.racers[e].pos && i > t.racers[e].pos);
	if (me(e, t, n, !0, c), V(t, n) === "centaur") {
		let e = [...d].sort((e, n) => t.racers[e].pos - t.racers[n].pos);
		for (let r of e) t.queue.push({
			k: "move",
			i: r,
			n: -2,
			main: !1,
			cause: "centaur"
		}), W(t, n, c);
	}
	for (let e of d) V(t, e) === "banana" && (t.queue.push({
		k: "trip",
		i: n
	}), W(t, e, c));
	s && t.queue.push({
		k: "trip",
		i: n
	});
}
function ge(e, t, n, r, i, a, o, s) {
	let c = t.racers[n];
	if (c.eliminated || c.place !== 0 || r === 0) return !0;
	let l = c.pos, u;
	if (V(t, n) === "leaptoad") {
		let e = l, i = Math.abs(r), a = Math.sign(r);
		for (; i > 0;) {
			if (e += a, a > 0 && e >= 30) {
				e = 30 + i - 1;
				break;
			}
			if (a < 0 && e <= 0) {
				e = 0;
				break;
			}
			ue(t, e) ? W(t, n, s) : --i;
		}
		u = Math.max(0, e);
	} else u = Math.max(0, l + r);
	if (u >= 30 && u !== 30) {
		let e = H(t, "stickler").find((e) => e !== n);
		if (e !== void 0) return s.log.push({
			k: "power",
			racer: t.racers[e].id
		}), W(t, e, s), !0;
	}
	let d = z(t).filter((e) => e !== n && t.racers[e].pos === l && V(t, e) === "suckerfish");
	return d.length > 0 ? (t.pending = {
		kind: "suckerfish",
		who: t.racers[d[0]].owner,
		mover: n,
		dest: u,
		n: r,
		main: i,
		cause: a,
		thenTrip: o,
		fishes: d,
		accepted: []
	}, !1) : (he(e, t, n, l, u, i, a, o, s), !0);
}
function _e(e) {
	switch (e.k) {
		case "move": return R.move(e.n);
		case "follow": return R.move(1);
		case "trip": return R.trip;
		case "points": return R.points;
		case "elim": return R.elim;
		case "warp": return R.warp;
		case "swap": return R.swap;
		case "recover":
		case "skip": return R.skip;
		default: return 0;
	}
}
function ve(e, t, n, r) {
	switch (n.k) {
		case "move":
			n.cause === "scoocher" && U(t, n.i, r), ge(e, t, n.i, n.n, n.main, n.cause, n.thenTrip ?? !1, r);
			break;
		case "follow": {
			let i = t.racers[n.fish];
			!i.eliminated && i.place === 0 && (W(t, n.fish, r), ge(e, t, n.fish, n.to - i.pos, !1, "suckerfish", !1, r));
			break;
		}
		case "trip": {
			let e = t.racers[n.i];
			!e.eliminated && e.place === 0 && !e.tripped && (e.tripped = !0, r.fx.push({
				kind: "trip",
				rid: e.owner,
				data: {
					i: n.i,
					pos: e.pos,
					racer: e.id
				}
			}), r.log.push({
				k: "trip",
				racer: e.id
			}));
			break;
		}
		case "points": {
			let i = t.racers[n.i], a = e.scores[i.owner];
			e.scores[i.owner] = Math.max(0, e.scores[i.owner] + n.n);
			let o = e.scores[i.owner] - a;
			i.gained += Math.max(0, o), i.lost += Math.max(0, -o), r.fx.push({
				kind: "points",
				rid: i.owner,
				data: { n: n.n }
			}), r.log.push({
				k: "points",
				rid: i.owner,
				n: n.n
			});
			break;
		}
		case "elim": {
			let e = t.racers[n.i];
			!e.eliminated && e.place === 0 && (e.eliminated = !0, t.elimOrder.push(n.i), r.fx.push({
				kind: "elim",
				rid: e.owner,
				data: {
					i: n.i,
					pos: e.pos,
					racer: e.id
				}
			}), r.log.push({
				k: "elim",
				racer: e.id
			}));
			break;
		}
		case "warp": {
			let i = t.racers[n.i];
			if (!i.eliminated && i.place === 0) {
				let a = i.pos;
				i.pos = Math.max(0, Math.min(n.to, 29)), r.fx.push({
					kind: "warp",
					rid: i.owner,
					data: {
						i: n.i,
						from: a,
						to: i.pos,
						racer: i.id
					}
				}), r.log.push({
					k: "warp",
					racer: i.id
				}), me(e, t, n.i, !1, r);
			}
			break;
		}
		case "swap": {
			let i = t.racers[n.a], a = t.racers[n.b], o = i.pos;
			i.pos = a.pos, a.pos = o, r.fx.push({
				kind: "swap",
				rid: i.owner,
				data: {
					a: n.a,
					b: n.b,
					aPos: a.pos,
					bPos: i.pos,
					aRacer: i.id,
					bRacer: a.id,
					bOwner: a.owner
				}
			}), r.log.push({
				k: "swap",
				a: i.id,
				b: a.id
			}), me(e, t, n.a, !1, r), t.pending || me(e, t, n.b, !1, r);
			break;
		}
		case "recover": {
			let e = t.racers[n.i];
			e.tripped = !1, r.fx.push({
				kind: "skip",
				rid: e.owner,
				data: {
					i: n.i,
					pos: e.pos,
					reason: "trip",
					racer: e.id
				}
			}), r.log.push({
				k: "skip",
				racer: e.id
			});
			break;
		}
		case "skip": {
			let e = t.racers[n.i];
			r.fx.push({
				kind: "skip",
				rid: e.owner,
				data: {
					i: n.i,
					pos: e.pos,
					reason: "hare",
					racer: e.id
				}
			}), r.log.push({
				k: "skip",
				racer: e.id
			});
			break;
		}
	}
}
function ye(e, t) {
	let n = V(e, t), r = [];
	for (let t of [
		"cheerleader",
		"hypnotist",
		"thirdwheel"
	]) n === t && !e.usedPre.includes(t) && r.push(t);
	return r;
}
function be(e, t, n) {
	let r = e.racers[t];
	if (e.turnStartPos = r.pos, e.turnTaken[t] = !0, e.cascade = 0, e.die = null, e.rerollsLeft = 0, e.dicemongerUsed = !1, e.rocketArmed = !1, e.transmuted = !1, e.predictedRoll = null, e.usedPre = [], e.postStage = null, r.tripped) {
		e.step = "moving", e.queue.push({
			k: "recover",
			i: t
		}, {
			k: "flow",
			stage: "endTurn"
		});
		return;
	}
	if (V(e, t) === "hare" && fe(e, t)) {
		e.step = "moving", U(e, t, n), e.queue.push({
			k: "skip",
			i: t
		}, {
			k: "flow",
			stage: "endTurn"
		});
		return;
	}
	if (e.step = "preMove", V(e, t) === "mastermind" && e.predictions[t] === null) {
		e.pending = {
			kind: "mastermind",
			who: r.owner,
			racer: t
		};
		return;
	}
	xe(e, t, n);
}
function xe(e, t, n) {
	let r = e.racers[t], i = V(e, t);
	if (i === "partyanimal") {
		let i = !1;
		for (let n of z(e)) {
			if (n === t) continue;
			let a = Math.sign(r.pos - e.racers[n].pos);
			a !== 0 && (e.queue.push({
				k: "move",
				i: n,
				n: a,
				main: !1,
				cause: "partyanimal"
			}), i = !0);
		}
		i && W(e, t, n);
	}
	i === "lovableloser" && G(e, t) && (e.queue.push({
		k: "points",
		i: t,
		n: 1
	}), W(e, t, n)), e.queue.push({
		k: "flow",
		stage: "preOffer"
	});
}
function Se(e, t, n) {
	let r = K(e);
	if (t === "preOffer") {
		let t = ye(e, r);
		t.length > 0 ? (e.step = "preOffer", e.pending = {
			kind: "prePower",
			who: e.racers[r].owner,
			powers: t
		}) : e.step = "rollChoice";
		return;
	}
	if (t === "endTurn") {
		let t = e.racers[r];
		if (!t.eliminated && t.place === 0 && Math.abs(t.pos - e.turnStartPos) <= 1) for (let t of H(e, "heckler")) e.queue.push({
			k: "move",
			i: t,
			n: 2,
			main: !1,
			cause: "heckler"
		}), W(e, t, n);
		e.queue.push({
			k: "flow",
			stage: "nextTurn"
		});
		return;
	}
	if (e.extraTurn) {
		e.extraTurn = !1, be(e, r, n);
		return;
	}
	if (e.overrideNext !== null) {
		let t = e.turnOrder.indexOf(e.overrideNext);
		if (e.overrideNext = null, t >= 0 && !e.racers[e.turnOrder[t]].eliminated && e.racers[e.turnOrder[t]].place === 0) {
			e.turnIdx = t, be(e, K(e), n);
			return;
		}
	}
	let i = e.turnOrder.length;
	for (let t = 1; t <= i; t++) {
		let r = (e.turnIdx + t) % i, a = e.racers[e.turnOrder[r]];
		if (!a.eliminated && a.place === 0) {
			e.turnIdx = r, be(e, K(e), n);
			return;
		}
	}
	e.over = !0;
}
function Ce(e, t) {
	let n = K(e), r = e.racers[n];
	for (;;) {
		if (e.postStage === "magician") {
			if (e.rerollsLeft > 0) {
				e.pending = {
					kind: "magician",
					who: r.owner
				};
				return;
			}
			e.postStage = "dicemonger";
		}
		if (e.postStage === "dicemonger") {
			if (!e.dicemongerUsed && H(e, "dicemonger").length > 0) {
				e.pending = {
					kind: "dicemonger",
					who: r.owner
				};
				return;
			}
			e.postStage = "alchemist";
		}
		if (e.postStage === "alchemist") {
			if (V(e, n) === "alchemist" && (e.die === 1 || e.die === 2)) {
				e.pending = {
					kind: "alchemist",
					who: r.owner
				};
				return;
			}
			e.postStage = "rocket";
		}
		if (e.postStage === "rocket") {
			if (V(e, n) === "rocket" && (V(e, n) !== "sisyphus" || e.die !== 6)) {
				e.pending = {
					kind: "rocket",
					who: r.owner
				};
				return;
			}
			e.postStage = null;
		}
		Te(e, t);
		return;
	}
}
function we(e, t, n) {
	let r = 0, i = V(e, t), a = e.racers[t];
	if (i === "blimp" && (r += e.turnStartPos < 15 ? 3 : -1, U(e, t, n)), i === "hare" && (r += 2, U(e, t, n)), i === "partyanimal") for (let i of z(e)) i !== t && e.racers[i].pos === a.pos && (r += 1, U(e, t, n));
	for (let i of H(e, "gunk")) i !== t && (--r, W(e, i, n));
	for (let t of H(e, "coach")) e.racers[t].pos === a.pos && (r += 1, W(e, t, n));
	return r;
}
function Te(e, t) {
	let n = K(e), r = e.die;
	if (e.step = "moving", r === null) return;
	if (e.predictedRoll !== null && e.predictedRoll === r && (e.extraTurn = !0, U(e, n, t)), r === 1) {
		for (let n of H(e, "skipper")) e.overrideNext = n, W(e, n, t);
		let r = H(e, "inchworm").filter((e) => e !== n);
		if (r.length > 0) {
			for (let n of r) e.queue.push({
				k: "move",
				i: n,
				n: 1,
				main: !1,
				cause: "inchworm"
			}), W(e, n, t);
			e.queue.push({
				k: "flow",
				stage: "endTurn"
			});
			return;
		}
	}
	if (r === 6 && V(e, n) === "sisyphus") {
		e.queue.push({
			k: "warp",
			i: n,
			to: 0
		}, {
			k: "points",
			i: n,
			n: -1
		}, {
			k: "flow",
			stage: "endTurn"
		}), W(e, n, t);
		return;
	}
	if (r === 6) for (let r of H(e, "lackey")) r !== n && (e.queue.push({
		k: "move",
		i: r,
		n: 2,
		main: !1,
		cause: "lackey"
	}), W(e, r, t));
	let i = e.transmuted ? 4 : e.rocketArmed ? r * 2 : r, a = Math.max(0, i + we(e, n, t));
	a > 0 && e.queue.push({
		k: "move",
		i: n,
		n: a,
		main: !0,
		cause: "die",
		thenTrip: e.rocketArmed
	}), e.queue.push({
		k: "flow",
		stage: "endTurn"
	});
}
function Ee(t, n, r) {
	let i = [...r];
	for (let r = i.length - 1; r > 0; r--) {
		let a = e(t, n.c++, r + 1);
		[i[r], i[a]] = [i[a], i[r]];
	}
	return i;
}
function De(e, t) {
	let n = Array.from({ length: e }, (n, r) => (t + r) % e);
	return [...n, ...[...n].reverse()];
}
function Oe(t, n, r) {
	let i = { c: 0 }, a = Ee(r, i, [...k]), o = n.length, s = a.slice(0, 2 * o), c = a.slice(2 * o), l = e(r, i.c++, o), u = {}, d = {}, f = {};
	for (let e of n) u[e] = [], d[e] = [], f[e] = 0;
	return {
		state: {
			players: n,
			seed: r,
			rngCursor: i.c,
			phase: "draft",
			raceNum: 1,
			scores: f,
			hands: u,
			used: d,
			deck: c,
			draft: {
				round: 1,
				pool: s,
				order: De(o, l),
				pickIdx: 0
			},
			select: null,
			race: null,
			winners: [],
			results: [],
			nextStarter: null,
			beatMs: 0,
			log: []
		},
		fx: []
	};
}
function ke(t, n) {
	let r = t.players.length, i = t.select?.picks ?? {}, a = re[t.raceNum - 1], o = t.players.map((e) => {
		let n = i[e];
		return t.used[e].push(n), {
			id: n,
			owner: e,
			pos: 0,
			tripped: !1,
			eliminated: !1,
			place: 0,
			copied: null,
			gained: 0,
			lost: 0
		};
	}), s;
	s = t.nextStarter === null ? e(t.seed, t.rngCursor++, r) : Math.max(0, t.players.indexOf(t.nextStarter));
	let c = {
		track: a,
		racers: o,
		turnOrder: Array.from({ length: r }, (e, t) => (s + t) % r),
		turnIdx: 0,
		overrideNext: null,
		extraTurn: !1,
		step: "preMove",
		postStage: null,
		pending: null,
		queue: [],
		die: null,
		rerollsLeft: 0,
		dicemongerUsed: !1,
		rocketArmed: !1,
		transmuted: !1,
		turnStartPos: 0,
		predictedRoll: null,
		turnTaken: Array(r).fill(!1),
		predictions: Array(r).fill(null),
		copycatChoice: Array(r).fill(null),
		usedPre: [],
		finishedCount: 0,
		mastermindHit: null,
		elimOrder: [],
		preRaceQueue: [],
		started: !1,
		cascade: 0,
		over: !1
	};
	t.race = c, t.select = null, t.phase = "race", n.fx.push({
		kind: "raceStart",
		data: {
			track: a,
			n: t.raceNum
		}
	}), n.log.push({
		k: "raceStart",
		n: t.raceNum,
		track: a
	}), c.preRaceQueue = c.turnOrder.filter((e) => [
		"egg",
		"twin",
		"sisyphus"
	].includes(o[e].id)), Ae(t, c, n);
}
function Ae(t, n, r) {
	for (; n.preRaceQueue.length > 0;) {
		let i = n.preRaceQueue[0], a = n.racers[i], o = a.copied ?? a.id;
		if (a.id === "egg" && a.copied === null) {
			let r = [];
			for (let n = 0; n < 3 && t.deck.length > 0; n++) {
				let n = e(t.seed, t.rngCursor++, t.deck.length);
				r.push(t.deck.splice(n, 1)[0]);
			}
			if (r.length > 0) {
				n.pending = {
					kind: "egg",
					who: a.owner,
					racer: i,
					options: r
				};
				return;
			}
		}
		if (a.id === "twin" && a.copied === null && t.winners.length > 0) {
			n.pending = {
				kind: "twin",
				who: a.owner,
				racer: i,
				winners: [...t.winners]
			};
			return;
		}
		o === "sisyphus" && (U(n, i, r, "sisyphus"), n.queue.push({
			k: "points",
			i,
			n: 4
		})), n.preRaceQueue.shift();
	}
	je(n), n.pending || (n.started = !0, be(n, n.turnOrder[0], r));
}
function je(e) {
	if (!e.pending) for (let t of z(e)) {
		let n = e.racers[t];
		if (n.id !== "copycat" && n.copied !== "copycat") continue;
		let r = de(e, t);
		if (r.length <= 1) {
			e.copycatChoice[t] = r[0] ?? null;
			continue;
		}
		let i = e.copycatChoice[t];
		if (i === null || !r.includes(i)) {
			e.pending = {
				kind: "copycat",
				who: n.owner,
				cat: t,
				leaders: r
			};
			return;
		}
	}
}
function Me(e, t, n = !1) {
	let r = e.race;
	if (!r || (!r.over && (r.finishedCount >= 2 || r.mastermindHit !== null || z(r).length === 0) && (r.over = !0), !r.over) || (r.queue = [], r.pending = null, !n)) return;
	let i = ie(e.raceNum), a = ae(e.raceNum), o = r.racers.findIndex((e) => e.place === 1), s = r.racers.findIndex((e) => e.place === 2);
	if (o >= 0) {
		let n = r.racers[o];
		e.scores[n.owner] += i, e.winners.push(n.id), t.fx.push({
			kind: "award",
			rid: n.owner,
			data: {
				medal: "gold",
				n: i
			}
		}), t.log.push({
			k: "award",
			rid: n.owner,
			medal: "gold",
			n: i
		});
	}
	if (s >= 0) {
		let n = r.racers[s];
		e.scores[n.owner] += a, t.fx.push({
			kind: "award",
			rid: n.owner,
			data: {
				medal: "silver",
				n: a
			}
		}), t.log.push({
			k: "award",
			rid: n.owner,
			medal: "silver",
			n: a
		});
	} else if (r.mastermindHit !== null && r.mastermindHit === o && o >= 0) {
		let n = r.racers[o];
		e.scores[n.owner] += a, t.fx.push({
			kind: "award",
			rid: n.owner,
			data: {
				medal: "silver",
				n: a
			}
		}), t.log.push({
			k: "award",
			rid: n.owner,
			medal: "silver",
			n: a
		});
	}
	if (e.results.push({
		num: e.raceNum,
		track: r.track,
		racers: r.racers.map((e, t) => {
			let n = t === o, c = t === s || s < 0 && o >= 0 && r.mastermindHit === o && t === o, l = (n ? i : 0) + (c ? a : 0);
			return {
				owner: e.owner,
				id: e.id,
				copied: e.copied,
				eliminated: e.eliminated,
				gold: n,
				silver: c,
				medalPoints: l,
				gained: e.gained,
				lost: e.lost,
				points: l + e.gained - e.lost
			};
		})
	}), r.elimOrder.length > 0) e.nextStarter = r.racers[r.elimOrder[0]].owner;
	else {
		let t = null;
		for (let e of r.turnOrder) {
			let n = r.racers[e];
			n.place !== 0 || n.eliminated || (t === null || n.pos < r.racers[t].pos) && (t = e);
		}
		e.nextStarter = t === null ? null : r.racers[t].owner;
	}
	e.raceNum >= 4 ? (e.phase = "done", e.race = null) : (e.raceNum += 1, e.phase = "select", e.select = { picks: {} }, e.race = null);
}
function Ne(e, t) {
	let n = e.race;
	if (!n) return;
	if (n.over) {
		Me(e, t, !0);
		return;
	}
	if (n.pending) return;
	let r = 0;
	for (; r++ < 40;) {
		let r = n.queue[0];
		if (!r || n.pending || n.over) break;
		if (r.k === "flow") {
			n.queue.shift(), Se(n, r.stage, t);
			continue;
		}
		if (r.k === "postRoll") {
			n.queue.shift(), Ce(n, t);
			continue;
		}
		n.queue.shift();
		let i = t.fx.length;
		ve(e, n, r, t), e.beatMs = _e(r);
		let a = t.fx.slice(i).find((e) => e.kind === "move")?.data;
		typeof a?.from == "number" && typeof a.to == "number" && (e.beatMs = R.move(a.to - a.from)), n.cascade += 1, n.cascade > 150 && (n.queue = [], n.step === "moving" && n.queue.push({
			k: "flow",
			stage: "endTurn"
		}));
		break;
	}
	r >= 40 && (n.queue = []), e.race && je(e.race), Me(e, t);
}
function J(e) {
	return { code: e };
}
function Pe(t, n, r) {
	let i = structuredClone(t), a = {
		fx: [],
		log: []
	};
	if (n.type === "tick") return i.phase === "race" ? (Ne(i, a), q(i, a), {
		state: i,
		fx: a.fx
	}) : {
		state: t,
		fx: []
	};
	if (i.phase === "done") return J("games.magicalathlete.errOver");
	if (n.type === "draftPick") {
		let e = i.draft;
		if (i.phase !== "draft" || !e) return J("games.magicalathlete.errBadAction");
		let t = i.players[e.order[e.pickIdx]];
		if (r.by !== t) return J("games.magicalathlete.errNotYourTurn");
		let o = e.pool.indexOf(n.racer);
		if (o < 0) return J("games.magicalathlete.errBadRacer");
		if (e.pool.splice(o, 1), i.hands[r.by].push(n.racer), e.pickIdx += 1, a.fx.push({
			kind: "draft",
			rid: r.by,
			data: { racer: n.racer }
		}), a.log.push({
			k: "draft",
			rid: r.by,
			racer: n.racer
		}), e.pickIdx >= e.order.length) {
			if (e.round === 1) {
				let t = e.order[0];
				e.round = 2, e.pool = i.deck.splice(0, 2 * i.players.length), e.order = De(i.players.length, (t + 1) % i.players.length), e.pickIdx = 0;
			} else i.draft = null, i.phase = "select", i.select = { picks: {} };
		}
		return q(i, a), {
			state: i,
			fx: a.fx
		};
	}
	if (n.type === "selectRacer") return i.phase !== "select" || !i.select || i.select.picks[r.by] ? J("games.magicalathlete.errBadAction") : !i.hands[r.by].includes(n.racer) || i.used[r.by].includes(n.racer) ? J("games.magicalathlete.errBadRacer") : (i.select.picks[r.by] = n.racer, a.fx.push({
		kind: "selectPick",
		rid: r.by
	}), Object.keys(i.select.picks).length === i.players.length && (a.log.push({ k: "select" }), ke(i, a)), q(i, a), {
		state: i,
		fx: a.fx
	});
	let o = i.race;
	if (i.phase !== "race" || !o || o.over) return J("games.magicalathlete.errBadAction");
	if (n.type === "roll") {
		let t = K(o);
		if (o.step !== "rollChoice" || o.pending || o.queue.length > 0) return J("games.magicalathlete.errBadAction");
		if (r.by !== o.racers[t].owner) return J("games.magicalathlete.errNotYourTurn");
		if (n.predict !== void 0) {
			if (V(o, t) !== "genius") return J("games.magicalathlete.errBadAction");
			o.predictedRoll = n.predict, a.log.push({
				k: "genius",
				rid: r.by,
				n: n.predict
			});
		}
		return o.die = e(i.seed, i.rngCursor++, 6) + 1, o.rerollsLeft = V(o, t) === "magician" ? 2 : 0, o.postStage = "magician", o.step = "postRoll", a.fx.push({
			kind: "diceRoll",
			rid: r.by,
			data: {
				dice: [o.die],
				banner: !0,
				target: "dice"
			}
		}), a.log.push({
			k: "roll",
			rid: r.by,
			n: o.die
		}), i.beatMs = ce, o.queue.unshift({ k: "postRoll" }), q(i, a), {
			state: i,
			fx: a.fx
		};
	}
	if (n.type === "altMove") {
		let e = K(o);
		if (o.step !== "rollChoice" || o.pending || o.queue.length > 0) return J("games.magicalathlete.errBadAction");
		if (r.by !== o.racers[e].owner) return J("games.magicalathlete.errNotYourTurn");
		let t = V(o, e);
		if (n.kind === "legs") {
			if (t !== "legs") return J("games.magicalathlete.errBadAction");
			W(o, e, a);
			let n = Math.max(0, 5 + we(o, e, a));
			n > 0 && o.queue.push({
				k: "move",
				i: e,
				n,
				main: !0,
				cause: "legs"
			}), o.queue.push({
				k: "flow",
				stage: "endTurn"
			}), o.step = "moving", i.beatMs = 300;
		} else {
			if (t !== "flipflop") return J("games.magicalathlete.errBadAction");
			let r = o.racers.findIndex((e) => e.id === n.target && !e.eliminated && e.place === 0);
			if (r < 0 || r === e) return J("games.magicalathlete.errBadRacer");
			W(o, e, a), o.queue.push({
				k: "swap",
				a: e,
				b: r
			}, {
				k: "flow",
				stage: "endTurn"
			}), o.step = "moving", i.beatMs = 300;
		}
		return q(i, a), {
			state: i,
			fx: a.fx
		};
	}
	if (n.type === "prePower") {
		let e = K(o);
		if (o.step !== "preOffer" || o.pending?.kind !== "prePower") return J("games.magicalathlete.errBadAction");
		if (r.by !== o.pending.who) return J("games.magicalathlete.errNotYourTurn");
		if (n.power === "none") return o.pending = null, o.step = "rollChoice", q(i, a), {
			state: i,
			fx: a.fx
		};
		if (!o.pending.powers.includes(n.power)) return J("games.magicalathlete.errBadAction");
		if (o.usedPre.push(n.power), W(o, e, a), n.power === "cheerleader") {
			let t = z(o), n = Math.min(...t.map((e) => o.racers[e].pos)), r = o.turnOrder.filter((e) => t.includes(e) && o.racers[e].pos === n);
			for (let e of r) o.queue.push({
				k: "move",
				i: e,
				n: 2,
				main: !1,
				cause: "cheerleader"
			});
			o.queue.push({
				k: "move",
				i: e,
				n: 1,
				main: !1,
				cause: "cheerleader"
			});
		} else if (n.power === "hypnotist") {
			let t = o.racers.findIndex((e) => e.id === n.target && !e.eliminated && e.place === 0);
			if (t < 0 || t === e) return J("games.magicalathlete.errBadRacer");
			o.queue.push({
				k: "warp",
				i: t,
				to: o.racers[e].pos
			});
		} else {
			let t = n.space ?? -1;
			if (z(o).filter((e) => o.racers[e].pos === t).length !== 2) return J("games.magicalathlete.errBadAction");
			o.queue.push({
				k: "warp",
				i: e,
				to: t
			});
		}
		a.log.push({
			k: "power",
			racer: o.racers[e].id
		});
		let t = ye(o, e);
		return t.length > 0 ? o.pending = {
			kind: "prePower",
			who: o.pending.who,
			powers: t
		} : (o.pending = null, o.step = "moving", o.queue.push({
			k: "flow",
			stage: "preOffer"
		})), i.beatMs = 300, q(i, a), {
			state: i,
			fx: a.fx
		};
	}
	if (n.type === "respond") {
		let t = o.pending;
		if (!t) return J("games.magicalathlete.errBadAction");
		if (r.by !== t.who) return J("games.magicalathlete.errNotYourTurn");
		if (t.kind === "alchemist" || t.kind === "rocket" || t.kind === "magician" || t.kind === "dicemonger") {
			if (n.accept === void 0) return J("games.magicalathlete.errBadAction");
			let s = K(o);
			if (n.accept) {
				if (t.kind === "magician") o.die = e(i.seed, i.rngCursor++, 6) + 1, --o.rerollsLeft, a.fx.push({
					kind: "diceRoll",
					rid: r.by,
					data: {
						dice: [o.die],
						banner: !0,
						target: "dice"
					}
				}), a.log.push({
					k: "roll",
					rid: r.by,
					n: o.die,
					reroll: !0
				}), W(o, s, a);
				else if (t.kind === "dicemonger") {
					o.die = e(i.seed, i.rngCursor++, 6) + 1, o.dicemongerUsed = !0, a.fx.push({
						kind: "diceRoll",
						rid: r.by,
						data: {
							dice: [o.die],
							banner: !0,
							target: "dice"
						}
					}), a.log.push({
						k: "roll",
						rid: r.by,
						n: o.die,
						reroll: !0
					});
					for (let e of H(o, "dicemonger")) e !== s && o.queue.push({
						k: "move",
						i: e,
						n: 1,
						main: !1,
						cause: "dicemonger"
					}), W(o, e, a);
				} else t.kind === "alchemist" ? (o.transmuted = !0, W(o, s, a), a.log.push({
					k: "power",
					racer: o.racers[s].id
				})) : (o.rocketArmed = !0, W(o, s, a), a.log.push({
					k: "power",
					racer: o.racers[s].id
				}));
			}
			o.postStage = t.kind === "magician" ? n.accept ? "magician" : "dicemonger" : t.kind === "dicemonger" ? "alchemist" : t.kind === "alchemist" ? "rocket" : null, o.pending = null;
			let c = n.accept && (t.kind === "magician" || t.kind === "dicemonger");
			return i.beatMs = c ? ce : le, c ? o.queue.unshift({ k: "postRoll" }) : o.postStage === null ? Te(o, a) : Ce(o, a), q(i, a), {
				state: i,
				fx: a.fx
			};
		}
		if (t.kind === "suckerfish") {
			if (n.accept === void 0) return J("games.magicalathlete.errBadAction");
			if (n.accept && t.accepted.push(t.fishes[0]), t.fishes.shift(), t.fishes.length > 0) return t.who = o.racers[t.fishes[0]].owner, q(i, a), {
				state: i,
				fx: a.fx
			};
			let { mover: e, dest: r, main: s, cause: c, thenTrip: l, accepted: u } = t;
			o.pending = null;
			let d = o.racers[e].pos;
			he(i, o, e, d, r, s, c, l, a), i.beatMs = R.move(o.racers[e].pos - d);
			let f = u.map((t) => ({
				k: "follow",
				fish: t,
				to: o.racers[e].pos
			}));
			return o.queue.unshift(...f), je(o), Me(i, a), q(i, a), {
				state: i,
				fx: a.fx
			};
		}
		if (t.kind === "duelist") {
			let r = t.duelist;
			if (n.accept && n.racerIdx !== void 0) {
				let s = n.racerIdx;
				if (!t.candidates.includes(s)) return J("games.magicalathlete.errBadRacer");
				let c = e(i.seed, i.rngCursor++, 6) + 1, l = e(i.seed, i.rngCursor++, 6) + 1, u = c >= l ? r : s;
				W(o, r, a), a.fx.push({
					kind: "duel",
					rid: o.racers[r].owner,
					data: {
						a: r,
						b: s,
						ra: c,
						rb: l,
						winner: u,
						pos: o.racers[r].pos
					}
				}), a.log.push({
					k: "duel",
					a: o.racers[u].id
				}), o.queue.unshift({
					k: "move",
					i: u,
					n: 2,
					main: !1,
					cause: "duel"
				}), i.beatMs = R.duel;
			}
			let s = t.rest[0];
			if (s !== void 0) {
				let e = z(o).filter((e) => o.racers[e].pos === o.racers[s].pos).filter((e) => e !== s);
				if (e.length > 0) return o.pending = {
					kind: "duelist",
					who: o.racers[s].owner,
					duelist: s,
					candidates: e,
					rest: t.rest.slice(1)
				}, q(i, a), {
					state: i,
					fx: a.fx
				};
			}
			return o.pending = null, je(o), Me(i, a), q(i, a), {
				state: i,
				fx: a.fx
			};
		}
		if (t.kind === "copycat") return n.racerIdx === void 0 || !t.leaders.includes(n.racerIdx) ? J("games.magicalathlete.errBadRacer") : (o.copycatChoice[t.cat] = n.racerIdx, U(o, t.cat, a, "copycat"), o.pending = null, o.started ? je(o) : (o.started = !0, je(o), o.pending || be(o, o.turnOrder[0], a)), q(i, a), {
			state: i,
			fx: a.fx
		});
		if (t.kind === "mastermind") return n.racerIdx === void 0 || !o.racers[n.racerIdx] || o.racers[n.racerIdx].eliminated ? J("games.magicalathlete.errBadRacer") : (o.predictions[t.racer] = n.racerIdx, U(o, t.racer, a, "mastermind"), o.pending = null, a.log.push({
			k: "predict",
			rid: r.by,
			racer: o.racers[n.racerIdx].id
		}), xe(o, t.racer, a), i.beatMs = 300, q(i, a), {
			state: i,
			fx: a.fx
		});
		if (t.kind === "egg") return !n.racerId || !t.options.includes(n.racerId) ? J("games.magicalathlete.errBadRacer") : (o.racers[t.racer].copied = n.racerId, U(o, t.racer, a, t.kind), o.pending = null, Ae(i, o, a), q(i, a), {
			state: i,
			fx: a.fx
		});
		if (t.kind !== "twin") return J("games.magicalathlete.errBadAction");
		if (n.racerId && t.winners.includes(n.racerId)) o.racers[t.racer].copied = n.racerId, U(o, t.racer, a, "twin");
		else if (n.accept !== !1) return J("games.magicalathlete.errBadRacer");
		return o.pending = null, Ae(i, o, a), q(i, a), {
			state: i,
			fx: a.fx
		};
	}
	return J("games.magicalathlete.errBadAction");
}
function Fe(e) {
	let t = e.pending;
	if (!t) return null;
	switch (t.kind) {
		case "prePower": return {
			kind: "prePower",
			who: t.who,
			powers: t.powers
		};
		case "alchemist":
		case "rocket":
		case "magician":
		case "dicemonger": return {
			kind: t.kind,
			who: t.who,
			die: e.die ?? 1
		};
		case "suckerfish": return {
			kind: "suckerfish",
			who: t.who,
			mover: t.mover,
			dest: t.dest
		};
		case "duelist": return {
			kind: "duelist",
			who: t.who,
			candidates: t.candidates
		};
		case "copycat": return {
			kind: "copycat",
			who: t.who,
			leaders: t.leaders
		};
		case "mastermind": return {
			kind: "mastermind",
			who: t.who
		};
		case "egg": return {
			kind: "egg",
			who: t.who
		};
		case "twin": return {
			kind: "twin",
			who: t.who,
			winners: t.winners
		};
	}
}
function Ie(e, t) {
	let n = e.race;
	return {
		public: {
			phase: e.phase,
			raceNum: e.raceNum,
			players: e.players,
			scores: e.scores,
			winners: e.winners,
			results: e.phase === "done" ? e.results : [],
			draft: e.draft ? {
				pool: e.draft.pool,
				picker: e.players[e.draft.order[e.draft.pickIdx]] ?? e.players[0],
				round: e.draft.round,
				hands: e.hands
			} : null,
			select: e.select ? { picked: Object.keys(e.select.picks) } : null,
			race: n ? {
				track: n.track,
				step: n.step,
				die: n.die,
				predictedRoll: n.predictedRoll,
				predictions: n.predictions,
				racers: n.racers.map((e, t) => ({
					id: e.id,
					owner: e.owner,
					pos: e.pos,
					tripped: e.tripped,
					eliminated: e.eliminated,
					place: e.place,
					copied: e.copied,
					power: V(n, t)
				})),
				turn: n.racers[K(n)]?.owner ?? e.players[0],
				pending: Fe(n),
				busy: n.over || n.queue.length > 0,
				finishedCount: n.finishedCount
			} : null,
			log: e.log
		},
		private: {
			myPick: e.select?.picks[t] ?? null,
			eggOptions: n?.pending?.kind === "egg" && n.pending.who === t ? n.pending.options : [],
			myHand: e.hands[t] ?? [],
			myUsed: e.used[t] ?? []
		}
	};
}
function Le(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: { ...e.scores }
	};
}
function Re(e) {
	return e.phase === "race" && e.race && !e.race.pending && (e.race.over || e.race.queue.length > 0) ? Math.max(e.beatMs, 60) : null;
}
var ze = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: O,
	schemas: {
		action: N,
		publicView: L,
		privateView: se
	},
	setup: Oe,
	reduce: Pe,
	viewFor: Ie,
	status: Le,
	nextTickIn: Re
}, Y = {
	alchemist: "games.magicalathlete.rAlchemist",
	babayaga: "games.magicalathlete.rBabayaga",
	banana: "games.magicalathlete.rBanana",
	blimp: "games.magicalathlete.rBlimp",
	centaur: "games.magicalathlete.rCentaur",
	cheerleader: "games.magicalathlete.rCheerleader",
	coach: "games.magicalathlete.rCoach",
	copycat: "games.magicalathlete.rCopycat",
	dicemonger: "games.magicalathlete.rDicemonger",
	duelist: "games.magicalathlete.rDuelist",
	egg: "games.magicalathlete.rEgg",
	flipflop: "games.magicalathlete.rFlipflop",
	genius: "games.magicalathlete.rGenius",
	gunk: "games.magicalathlete.rGunk",
	hare: "games.magicalathlete.rHare",
	heckler: "games.magicalathlete.rHeckler",
	hugebaby: "games.magicalathlete.rHugebaby",
	hypnotist: "games.magicalathlete.rHypnotist",
	inchworm: "games.magicalathlete.rInchworm",
	lackey: "games.magicalathlete.rLackey",
	leaptoad: "games.magicalathlete.rLeaptoad",
	legs: "games.magicalathlete.rLegs",
	lovableloser: "games.magicalathlete.rLovableloser",
	mouth: "games.magicalathlete.rMouth",
	magician: "games.magicalathlete.rMagician",
	mastermind: "games.magicalathlete.rMastermind",
	partyanimal: "games.magicalathlete.rPartyanimal",
	rocket: "games.magicalathlete.rRocket",
	romantic: "games.magicalathlete.rRomantic",
	scoocher: "games.magicalathlete.rScoocher",
	sisyphus: "games.magicalathlete.rSisyphus",
	skipper: "games.magicalathlete.rSkipper",
	stickler: "games.magicalathlete.rStickler",
	suckerfish: "games.magicalathlete.rSuckerfish",
	thirdwheel: "games.magicalathlete.rThirdwheel",
	twin: "games.magicalathlete.rTwin"
}, Be = {
	alchemist: "games.magicalathlete.pAlchemist",
	babayaga: "games.magicalathlete.pBabayaga",
	banana: "games.magicalathlete.pBanana",
	blimp: "games.magicalathlete.pBlimp",
	centaur: "games.magicalathlete.pCentaur",
	cheerleader: "games.magicalathlete.pCheerleader",
	coach: "games.magicalathlete.pCoach",
	copycat: "games.magicalathlete.pCopycat",
	dicemonger: "games.magicalathlete.pDicemonger",
	duelist: "games.magicalathlete.pDuelist",
	egg: "games.magicalathlete.pEgg",
	flipflop: "games.magicalathlete.pFlipflop",
	genius: "games.magicalathlete.pGenius",
	gunk: "games.magicalathlete.pGunk",
	hare: "games.magicalathlete.pHare",
	heckler: "games.magicalathlete.pHeckler",
	hugebaby: "games.magicalathlete.pHugebaby",
	hypnotist: "games.magicalathlete.pHypnotist",
	inchworm: "games.magicalathlete.pInchworm",
	lackey: "games.magicalathlete.pLackey",
	leaptoad: "games.magicalathlete.pLeaptoad",
	legs: "games.magicalathlete.pLegs",
	lovableloser: "games.magicalathlete.pLovableloser",
	mouth: "games.magicalathlete.pMouth",
	magician: "games.magicalathlete.pMagician",
	mastermind: "games.magicalathlete.pMastermind",
	partyanimal: "games.magicalathlete.pPartyanimal",
	rocket: "games.magicalathlete.pRocket",
	romantic: "games.magicalathlete.pRomantic",
	scoocher: "games.magicalathlete.pScoocher",
	sisyphus: "games.magicalathlete.pSisyphus",
	skipper: "games.magicalathlete.pSkipper",
	stickler: "games.magicalathlete.pStickler",
	suckerfish: "games.magicalathlete.pSuckerfish",
	thirdwheel: "games.magicalathlete.pThirdwheel",
	twin: "games.magicalathlete.pTwin"
}, Ve = {
	alchemist: "games.magicalathlete.cueAlchemist",
	babayaga: "games.magicalathlete.cueBabayaga",
	banana: "games.magicalathlete.cueBanana",
	blimp: "games.magicalathlete.cueBlimp",
	centaur: "games.magicalathlete.cueCentaur",
	cheerleader: "games.magicalathlete.cueCheerleader",
	coach: "games.magicalathlete.cueCoach",
	copycat: "games.magicalathlete.cueCopycat",
	dicemonger: "games.magicalathlete.cueDicemonger",
	duelist: "games.magicalathlete.cueDuelist",
	egg: "games.magicalathlete.cueEgg",
	flipflop: "games.magicalathlete.cueFlipflop",
	genius: "games.magicalathlete.cueGenius",
	gunk: "games.magicalathlete.cueGunk",
	hare: "games.magicalathlete.cueHare",
	heckler: "games.magicalathlete.cueHeckler",
	hugebaby: "games.magicalathlete.cueHugebaby",
	hypnotist: "games.magicalathlete.cueHypnotist",
	inchworm: "games.magicalathlete.cueInchworm",
	lackey: "games.magicalathlete.cueLackey",
	leaptoad: "games.magicalathlete.cueLeaptoad",
	legs: "games.magicalathlete.cueLegs",
	lovableloser: "games.magicalathlete.cueLovableloser",
	mouth: "games.magicalathlete.cueMouth",
	magician: "games.magicalathlete.cueMagician",
	mastermind: "games.magicalathlete.cueMastermind",
	partyanimal: "games.magicalathlete.cuePartyanimal",
	rocket: "games.magicalathlete.cueRocket",
	romantic: "games.magicalathlete.cueRomantic",
	scoocher: "games.magicalathlete.cueScoocher",
	sisyphus: "games.magicalathlete.cueSisyphus",
	skipper: "games.magicalathlete.cueSkipper",
	stickler: "games.magicalathlete.cueStickler",
	suckerfish: "games.magicalathlete.cueSuckerfish",
	thirdwheel: "games.magicalathlete.cueThirdwheel",
	twin: "games.magicalathlete.cueTwin"
}, He = {
	alchemist: "11.5 7 189 189",
	babayaga: "6 12 184 184",
	banana: "11.5 8 181 181",
	blimp: "15 -49 204 204",
	centaur: "10.5 16 181 181",
	cheerleader: "1 -22 215 215",
	coach: "15.5 10 183 183",
	copycat: "11 14 183 183",
	dicemonger: "21 9 185 185",
	duelist: "-0.5 9 183 183",
	egg: "18 11 184 184",
	flipflop: "19.5 19 175 175",
	genius: "17 3 187 187",
	gunk: "17 23 170 170",
	hare: "4 0 189 189",
	heckler: "10 18 179 179",
	hugebaby: "15.5 21 180 180",
	hypnotist: "16 10 183 183",
	inchworm: "22 9 180 180",
	lackey: "38 42 145 145",
	leaptoad: "6 -11 201 201",
	legs: "15 11 180 180",
	lovableloser: "17 4 185 185",
	mouth: "7 -17 202 202",
	magician: "19 5 181 181",
	mastermind: "10.5 3 194 194",
	partyanimal: "12.5 9 192 192",
	rocket: "16 4 197 197",
	romantic: "22 14 180 180",
	scoocher: "9 -10 200 200",
	sisyphus: "6.5 6 194 194",
	skipper: "18.5 10 185 185",
	stickler: "16.5 10 187 187",
	suckerfish: "16 -16 181 181",
	thirdwheel: "24 16 185 185",
	twin: "23 26 183 183"
}, Ue = {
	alchemist: {
		svg: "<path d=\"M50 142L44 178L58 185L72 170L71 141Z\" fill=\"#445e62\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M140 143L153 181L170 184L168 169L158 138Z\" fill=\"#445e62\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M54 80Q68 46 107 44Q140 43 157 78L153 133L60 141L42 120Z\" fill=\"#4c9864\" stroke=\"#30213c\" stroke-width=\"3.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M94 29Q62 25 50 50Q48 65 33 71L57 69L50 94Q70 92 82 75L121 65L137 43L124 36Z\" fill=\"#4c9864\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M51 57Q78 39 117 41M61 67Q82 50 116 49\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M79 66Q98 50 116 61L120 92L103 115L79 100Z\" fill=\"#c47c9b\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M86 65L106 60L106 71L87 76Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M92 63L93 69\" fill=\"none\" stroke=\"#fff7e6\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M99 61L100 67\" fill=\"none\" stroke=\"#fff7e6\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M107 72Q135 72 131 86L122 92L106 87Z\" fill=\"#c47c9b\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M80 85L92 95L109 88L120 102L120 128L110 121L105 142L92 127L81 139L73 119L65 126L70 100Z\" fill=\"#df9744\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M80 102L79 120M89 109L92 125M105 106L107 120M115 105L114 116\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M139 45L148 41L155 128L147 132Z\" fill=\"#d3a650\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M141 62L148 60M142 80L150 78M144 101L152 99\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M129 87L139 82L148 85L148 93L140 94L150 98L149 105L140 106L149 111L145 119L132 114L125 100Z\" fill=\"#c47c9b\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M41 132Q100 109 174 133L181 166Q170 190 110 194Q54 194 36 170Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"108\" cy=\"133\" rx=\"71\" ry=\"17\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\"/><ellipse cx=\"108\" cy=\"132\" rx=\"61\" ry=\"10\" fill=\"#91bf9c\" stroke=\"#30213c\" stroke-width=\"2\"/><path d=\"M57 153Q106 164 163 148M65 179Q107 187 153 173\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 119L84 99L104 119L91 140L72 137Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><polygon points=\"87,111 89.1160269082529,116.08753882025019 94.60845213036123,116.52786404500043 90.42380345866255,120.11246117974981 91.70228201833979,125.47213595499957 87,122.6 82.29771798166021,125.47213595499957 83.57619654133745,120.11246117974981 79.39154786963877,116.52786404500043 84.8839730917471,116.08753882025019\" fill=\"#6b91b9\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\"/><ellipse cx=\"155\" cy=\"46\" rx=\"8\" ry=\"8\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.8\"/><ellipse cx=\"169\" cy=\"25\" rx=\"11\" ry=\"11\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.8\"/><ellipse cx=\"178\" cy=\"63\" rx=\"5\" ry=\"5\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\"/><path d=\"M159 38L164 32M169 14L171 8M177 22L182 19\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M39 125L28 116M35 137L23 136M173 133L189 126\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#8a67a3",
		background: "#f5d85b"
	},
	babayaga: {
		svg: "<path d=\"M66 132L48 185L36 191H78L88 154M129 143L148 181L168 185L165 194H127L109 152\" fill=\"#f2d652\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M47 65L113 20L158 68L148 145H53Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M43 68L111 15L166 65L145 71L113 42L64 75Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M56 82L149 82\" fill=\"none\" stroke=\"#958798\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M56 96L149 96\" fill=\"none\" stroke=\"#958798\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M56 110L149 110\" fill=\"none\" stroke=\"#958798\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M56 124L149 124\" fill=\"none\" stroke=\"#958798\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M54 90L28 75L15 88L44 107M147 94L184 111L177 124L144 112\" fill=\"#f2d652\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M25 77L13 53L8 60L12 95L30 100Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M83 95Q96 77 119 93L122 116H83Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"91\" cy=\"94\" rx=\"4\" ry=\"6\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"93\" cy=\"96\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"111\" cy=\"94\" rx=\"4\" ry=\"6\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"113\" cy=\"96\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M153 64L174 43L188 49L171 73Z\" fill=\"#d6a657\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M166 50L179 25L184 52Z\" fill=\"#edc555\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M94 117L94 143\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/>",
		accent: "#e99b64",
		background: "#84cfd1"
	},
	banana: {
		svg: "<path d=\"M50 153L44 172L31 178L42 182L57 176L66 157Z\" fill=\"#b88b48\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M91 158L102 175L91 183L105 187L119 177L109 155Z\" fill=\"#b88b48\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M130 145L146 164L135 174L150 177L165 165L151 143Z\" fill=\"#b88b48\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M26 131Q80 119 121 76Q149 45 157 24L172 23Q192 53 189 102L179 121L165 117Q156 145 119 155Q67 176 28 148L16 143L17 136Z\" fill=\"#f5d83e\" stroke=\"#30213c\" stroke-width=\"3.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M30 138Q87 142 126 109Q154 84 166 39\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M123 146Q144 134 157 114\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M158 25L156 15L168 10L179 19L174 29Z\" fill=\"#4b3c40\" stroke=\"#30213c\" stroke-width=\"2.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M18 134L27 136L24 150L15 145Z\" fill=\"#4b3c40\" stroke=\"#30213c\" stroke-width=\"2.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M139 34L176 31L183 36L145 41Z\" fill=\"#cb8c54\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M151 30L154 17L165 22L173 18L177 32Z\" fill=\"#cb8c54\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M151 31L176 29L177 34L151 37Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"170\" cy=\"74\" rx=\"6\" ry=\"10\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.2\"/><ellipse cx=\"172\" cy=\"77\" rx=\"2.5\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M162 66Q169 61 178 67\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M176 96Q157 92 155 105Q151 115 162 113\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M139 116Q150 125 163 116\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M135 116L126 123L140 128L134 141L147 145L158 124Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M41 168L54 167M100 170L111 167M140 158L151 155\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#547ba6",
		background: "#ed96be"
	},
	blimp: {
		svg: "<path d=\"M146 73L179 41L187 61L209 56L201 79L215 94L194 105L207 124L183 130L181 151L159 136L138 153L133 129Z\" fill=\"#f1ad4e\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M143 81L175 61L172 80L197 77L186 96L201 110L179 114L175 135L158 121L141 134Z\" fill=\"#e87346\" stroke=\"#30213c\" stroke-width=\"2.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M169 57Q154 39 174 29Q193 24 194 43Q213 36 217 54Q221 68 207 75Q220 89 204 99Q191 105 184 90Q167 97 165 81Q150 77 160 64Z\" fill=\"#fff2c7\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M173 43Q182 34 189 47Q191 54 181 58Q172 59 173 50\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M180 79Q192 69 197 81Q202 91 190 90\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M28 126Q11 109 20 88Q39 50 104 49Q149 48 165 79L162 121Q142 148 83 148Q45 148 28 126Z\" fill=\"#bebdc4\" stroke=\"#30213c\" stroke-width=\"3.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M118 52Q103 99 119 143L145 133Q131 97 144 63Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 97Q68 60 116 60M22 106Q72 82 112 82M24 116Q72 111 111 105M34 127Q72 135 116 128\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"34\" cy=\"99\" rx=\"5\" ry=\"6\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"33\" cy=\"100\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"48\" cy=\"96\" rx=\"5\" ry=\"6\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"47\" cy=\"97\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M27 88L33 84M43 84L49 86\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"27\" cy=\"109\" rx=\"3.5\" ry=\"4\" fill=\"#dd7954\" stroke=\"#30213c\" stroke-width=\"1.5\"/><path d=\"M31 123Q40 114 49 123L48 129L33 128Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M36 127L47 127\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M150 53L155 40M157 134L165 147M192 139L201 148\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#9480b7",
		background: "#b2a0d4"
	},
	centaur: {
		svg: "<path d=\"M61 133L48 175L23 183L22 195H60L77 150M129 134L155 168L153 188H173L180 170L159 132\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M57 91Q20 69 27 126Q14 108 19 84Q29 58 69 81\" fill=\"#d8d0e8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"100\" cy=\"118\" rx=\"61\" ry=\"40\" fill=\"#c95b65\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M131 108L122 69L131 38L149 24L169 33L163 65L173 89L152 109Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M130 40Q116 38 108 52L87 51L70 36Q80 72 119 65L126 78\" fill=\"#eee1ee\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M153 37L169 43L183 54L166 59L154 53Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"156\" cy=\"38\" rx=\"5\" ry=\"8\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"158\" cy=\"40\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M144 68L166 74L179 63L184 72L168 91L145 84Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M137 37L136 20L144 25L151 18L154 31\" fill=\"#d8d0e8\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M149 113L153 143\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/>",
		accent: "#df7855",
		background: "#f9aa67"
	},
	cheerleader: {
		svg: "<path d=\"M65 141L50 168L33 153L20 163L44 190L65 188L87 160M131 142L148 169L166 155L180 165L157 191L138 185L113 158\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"101\" cy=\"115\" rx=\"48\" ry=\"63\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M64 87L40 62L29 76L60 118M141 91L166 64L179 79L144 119\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M6 55l9-13 8 7 7-18 7 11 12-8 2 15 13 5-8 10 7 13-16 1-7 12-10-9-12 8-2-15-13-6Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M156 56l9-13 8 7 7-18 7 11 12-8 2 15 13 5-8 10 7 13-16 1-7 12-10-9-12 8-2-15-13-6Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"91\" cy=\"69\" rx=\"10\" ry=\"14\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"93\" cy=\"71\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"113\" cy=\"69\" rx=\"10\" ry=\"14\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"115\" cy=\"71\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"102\" cy=\"95\" rx=\"26\" ry=\"22\" fill=\"#8162a4\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M73 119Q102 143 133 117Q124 161 105 163Q83 157 73 119Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M90 151Q104 143 118 152L109 163Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M68 129L72 137\" fill=\"none\" stroke=\"#bc593f\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M84 129L88 137\" fill=\"none\" stroke=\"#bc593f\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M100 129L104 137\" fill=\"none\" stroke=\"#bc593f\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M116 129L120 137\" fill=\"none\" stroke=\"#bc593f\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M132 129L136 137\" fill=\"none\" stroke=\"#bc593f\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>",
		accent: "#9777b7",
		background: "#bad76f"
	},
	coach: {
		svg: "<path d=\"M75 145L55 177L40 179L38 190H85L97 151M123 146L133 178L159 179L165 191H120L105 153\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M72 84L124 76L150 112L157 163H55L59 119Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M76 89L54 104L32 92L24 103L54 125L76 118M135 90L154 65L167 74L154 109\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M79 91L69 60L77 34L97 25L121 40L127 50L152 56L149 73L121 78L116 96Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M81 36L70 15L95 21L109 12L117 33Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"105\" cy=\"45\" rx=\"6\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"107\" cy=\"47\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M144 45L177 27L174 96L145 76Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"177\" cy=\"62\" rx=\"13\" ry=\"35\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M172 42L181 82\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M169 71L184 52\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M75 85L93 107L112 88L127 109L143 94\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"92\" cy=\"119\" rx=\"4\" ry=\"4\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"101\" cy=\"139\" rx=\"4\" ry=\"4\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"111\" cy=\"157\" rx=\"4\" ry=\"4\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2\"/>",
		accent: "#8a67a3",
		background: "#f5dc61"
	},
	copycat: {
		svg: "<path d=\"M42 153Q5 161 15 187Q35 203 62 183L65 159M149 161Q186 145 192 170Q196 194 164 194\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M48 112L87 105L110 127L135 109L166 120L174 185H37Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M43 76l-4-31 18 12q14-8 27 0l18-13-3 34q-2 33-29 33T43 76Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"59\" cy=\"71\" rx=\"6\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"61\" cy=\"73\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"81\" cy=\"71\" rx=\"6\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"83\" cy=\"73\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M65 84l10 0-5 7Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M34 83L57 87\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M85 87L110 82\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M115 79l-4-31 18 12q14-8 27 0l18-13-3 34q-2 33-29 33T115 79Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"131\" cy=\"74\" rx=\"6\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"133\" cy=\"76\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"153\" cy=\"74\" rx=\"6\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"155\" cy=\"76\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M137 87l10 0-5 7Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M106 86L129 90\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M157 90L182 85\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M48 113L64 142L77 116M124 118L143 146L157 120\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 132L75 134L78 164L69 172L62 158Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M143 135L151 138L154 166L146 175L138 159Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M83 171L84 195\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M127 171L125 195\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M43 155L40 166\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M50 155L47 166\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M57 155L54 166\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>",
		accent: "#e99b64",
		background: "#84cfd1"
	},
	dicemonger: {
		svg: "<path d=\"M42 98L83 79L125 115L131 191H34Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M68 85Q37 82 39 57Q39 30 68 30L89 40L104 46L97 61L81 61L84 85Z\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"72\" cy=\"44\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"74\" cy=\"46\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M46 31L49 11L70 14L77 36Z\" fill=\"#d55377\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M81 101L116 80L178 85L182 98L116 100L95 124Z\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M55 125L69 143L102 148L100 162L61 159L42 143\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M104 110L189 102L193 181L105 192Z\" fill=\"#d95d83\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M111 116l13-2 2 14-13 2Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"118\" cy=\"122\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M129 116l13-2 2 14-13 2Z\" fill=\"#7fd4d0\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"136\" cy=\"122\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M147 116l13-2 2 14-13 2Z\" fill=\"#f4da5c\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"154\" cy=\"122\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M165 116l13-2 2 14-13 2Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"172\" cy=\"122\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M111 138l13-2 2 14-13 2Z\" fill=\"#7fd4d0\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"118\" cy=\"144\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M129 138l13-2 2 14-13 2Z\" fill=\"#f4da5c\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"136\" cy=\"144\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M147 138l13-2 2 14-13 2Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"154\" cy=\"144\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M165 138l13-2 2 14-13 2Z\" fill=\"#7fd4d0\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"172\" cy=\"144\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M111 160l13-2 2 14-13 2Z\" fill=\"#f4da5c\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"118\" cy=\"166\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M129 160l13-2 2 14-13 2Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"136\" cy=\"166\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M147 160l13-2 2 14-13 2Z\" fill=\"#7fd4d0\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"154\" cy=\"166\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M165 160l13-2 2 14-13 2Z\" fill=\"#f4da5c\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"172\" cy=\"166\" rx=\"2\" ry=\"2\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M47 172L54 186\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/>",
		accent: "#547ba6",
		background: "#ed96be"
	},
	duelist: {
		svg: "<path d=\"M72 120L44 157L31 172L44 186L75 161L94 141M118 132L131 171L161 177L168 189H127L104 148\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 83L122 74L154 102L169 174L139 161L131 190L111 174L102 122L68 130Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M79 89Q55 77 59 54Q58 31 88 29L118 43L123 62L103 77L104 93Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M68 34L72 11L99 22L122 17L117 49L100 36Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"90\" cy=\"43\" rx=\"6\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"92\" cy=\"45\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"64\" cy=\"55\" rx=\"10\" ry=\"10\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2.5\"/><path d=\"M61 72L78 84L106 76L117 93L75 102L55 83Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M80 109L54 101L38 69L27 73L35 114L70 132\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M31 76L13 26\" fill=\"none\" stroke=\"#b6b2be\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M19 70L44 62\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><ellipse cx=\"104\" cy=\"108\" rx=\"3.5\" ry=\"3.5\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"1.5\"/><ellipse cx=\"115\" cy=\"122\" rx=\"3.5\" ry=\"3.5\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"1.5\"/><ellipse cx=\"126\" cy=\"136\" rx=\"3.5\" ry=\"3.5\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"1.5\"/>",
		accent: "#9480b7",
		background: "#b2a0d4"
	},
	egg: {
		svg: "<path d=\"M55 178L165 178L179 193H42Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M90 117L73 157L94 167L115 151L133 171L153 158L133 120Z\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M108 108Q80 91 89 68L129 67Q147 94 127 111Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M39 80Q69 38 108 13Q147 33 181 85L157 92L135 88L113 95L90 88L67 94Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M47 80Q110 57 175 83L153 87L131 81L110 88L89 81L66 88Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"103\" cy=\"53\" rx=\"5\" ry=\"8\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"105\" cy=\"55\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"119\" cy=\"53\" rx=\"5\" ry=\"8\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"121\" cy=\"55\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"106\" cy=\"91\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"108\" cy=\"93\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"126\" cy=\"91\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"128\" cy=\"93\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M103 115Q87 130 102 144Q118 154 132 139L127 120Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M109 129L113 121L119 128L126 123\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M78 148L66 173\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M145 148L155 173\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/>",
		accent: "#df7855",
		background: "#f9aa67"
	},
	flipflop: {
		svg: "<ellipse cx=\"107\" cy=\"180\" rx=\"71\" ry=\"12\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M75 165Q55 115 85 88L103 83L121 84Q159 112 142 169Q112 181 75 165Z\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M90 98Q72 69 90 45L111 51L119 87Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M111 88Q120 56 137 51L147 64L130 103Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M78 54q-9-12 0-27q7-11 13-2q7 10-1 27Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"89\" cy=\"39\" rx=\"3\" ry=\"8\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M95 58q-9-12 0-27q7-11 13-2q7 10-1 27Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"106\" cy=\"43\" rx=\"3\" ry=\"8\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M121 62q-9-12 0-27q7-11 13-2q7 10-1 27Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"132\" cy=\"47\" rx=\"3\" ry=\"8\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M137 59q-9-12 0-27q7-11 13-2q7 10-1 27Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"148\" cy=\"44\" rx=\"3\" ry=\"8\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M89 86L112 105L124 86L133 101L116 128L84 115Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M82 105L52 143L45 138L63 99Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M133 103L166 134L174 127L152 97Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M88 135L83 155\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M131 136L136 155\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/>",
		accent: "#9777b7",
		background: "#bad76f"
	},
	genius: {
		svg: "<path d=\"M61 145L46 185H80L100 154M126 144L151 182L170 188H129L109 154\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M56 131L80 102L136 107L160 152L128 165L84 163Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M81 110Q59 110 58 77Q54 55 74 34Q89 20 104 35L126 47L150 48L166 64L158 87L137 104Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M65 89L42 83L54 70L35 64L51 51L41 43L61 39L60 23L81 31L88 17L99 35L87 50L73 62Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"108\" cy=\"58\" rx=\"9\" ry=\"11\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"110\" cy=\"60\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"133\" cy=\"59\" rx=\"9\" ry=\"11\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"135\" cy=\"61\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M79 86Q113 100 155 83L150 108L119 120L86 108Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M94 94L96 109\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M108 94L110 109\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M122 94L124 109\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M136 94L138 109\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M87 129L106 143L129 119\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M144 129L178 116L186 144L155 157Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"156\" cy=\"130\" rx=\"3\" ry=\"3\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1\"/><ellipse cx=\"172\" cy=\"126\" rx=\"3\" ry=\"3\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1\"/><ellipse cx=\"163\" cy=\"142\" rx=\"3\" ry=\"3\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1\"/><polygon points=\"161,16 163.64503363531614,22.359423525312735 170.51056516295154,22.909830056250527 165.27975432332818,27.390576474687265 166.87785252292474,34.09016994374947 161,30.5 155.12214747707526,34.09016994374947 156.72024567667182,27.390576474687265 151.48943483704846,22.909830056250527 158.35496636468386,22.359423525312735\" fill=\"#edc946\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\"/><path d=\"M96 23L88 5L74 13L71 31Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#8a67a3",
		background: "#f5dc61"
	},
	gunk: {
		svg: "<path d=\"M25 161Q39 142 59 151Q53 123 81 109Q86 93 102 99Q117 98 121 124Q153 131 147 153Q176 147 183 165L169 172L185 186L139 184L120 191L82 185L40 190L49 179L25 176Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M32 51L183 60L178 93L19 79Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M47 83L37 127L46 138L57 129L68 87M94 89L86 111M131 94L124 123L136 133L146 120L154 96M176 94L169 145\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"101\" cy=\"120\" rx=\"6\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"103\" cy=\"122\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"120\" cy=\"123\" rx=\"5\" ry=\"8\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"122\" cy=\"125\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M91 148Q113 159 130 144\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"58\" cy=\"165\" rx=\"8\" ry=\"3\" fill=\"#557d36\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"141\" cy=\"169\" rx=\"8\" ry=\"3\" fill=\"#557d36\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"88\" cy=\"176\" rx=\"8\" ry=\"3\" fill=\"#557d36\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M30 49L41 29L171 38L185 60Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#e99b64",
		background: "#84cfd1"
	},
	hare: {
		svg: "<path d=\"M119 59Q67 26 16 38L6 50Q59 65 113 71Z\" fill=\"#72b8d1\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M128 52Q81 10 21 17L9 28Q78 35 121 65Z\" fill=\"#72b8d1\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M29 26Q85 28 113 50\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M144 71Q176 86 168 121Q159 152 126 168Q84 190 56 162Q30 132 64 110L106 101Z\" fill=\"#72b8d1\" stroke=\"#30213c\" stroke-width=\"3.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M117 66Q127 41 153 45Q177 44 179 65L182 78L171 87Q146 105 122 88Z\" fill=\"#72b8d1\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"153\" cy=\"53\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"155\" cy=\"53\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"169\" cy=\"51\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"171\" cy=\"51\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M145 44L158 42M165 40L175 44\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"181\" cy=\"66\" rx=\"10\" ry=\"8\" fill=\"#dc7457\" stroke=\"#30213c\" stroke-width=\"2.7\"/><path d=\"M156 80Q169 87 178 78L171 93L159 92Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M166 85L165 93\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.6\" stroke-linecap=\"round\"/><path d=\"M124 89L163 101L161 111L119 100Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M121 101L104 111L114 119L104 126L121 131L133 106Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M137 107Q132 123 143 131L152 123L145 117L154 119L157 112L148 106Z\" fill=\"#72b8d1\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M173 105L182 105L186 114L181 122L173 118L171 110Z\" fill=\"#72b8d1\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M101 145Q110 162 133 163L147 170L143 179L116 177L90 163Z\" fill=\"#72b8d1\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"73\" cy=\"149\" rx=\"40\" ry=\"35\" fill=\"#72b8d1\" stroke=\"#30213c\" stroke-width=\"2\"/><path d=\"M76 124Q49 118 43 144Q40 174 75 178Q106 181 107 151Q108 131 88 126Q65 120 55 141Q46 164 72 166Q94 169 95 150Q96 136 79 137Q63 139 65 151Q67 160 79 155\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M27 128L18 121M27 145L14 144M29 161L17 165M40 180L32 188\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M105 144L118 142M104 153L119 151\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#e99b64",
		background: "#84cfd1"
	},
	heckler: {
		svg: "<path d=\"M66 145L52 179L30 186L35 195H70L88 160M127 148L144 179L164 182L172 193H136L110 161\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M56 154Q46 125 70 104L85 89L134 95Q166 120 159 158L135 171H83Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M75 102L57 68L40 54L28 30L58 37L83 59L99 49L122 51L142 35L181 31L167 57L146 76L137 108Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M87 57L78 35L95 41L106 20L111 42L131 29L127 53Z\" fill=\"#edd253\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"90\" cy=\"67\" rx=\"9\" ry=\"11\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"92\" cy=\"69\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"121\" cy=\"66\" rx=\"8\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"123\" cy=\"68\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"103\" cy=\"83\" rx=\"24\" ry=\"13\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"80\" cy=\"83\" rx=\"10\" ry=\"10\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2\"/><path d=\"M81 95L133 89L125 114L103 124L88 115Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M89 97L97 106L103 94L113 105L121 94\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M103 118Q125 108 135 126L124 139L107 131Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M64 116L38 95L20 96L18 108L38 110L57 134Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"81\" cy=\"139\" rx=\"6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"108\" cy=\"148\" rx=\"6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"140\" cy=\"137\" rx=\"6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"75\" cy=\"161\" rx=\"6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/>",
		accent: "#9480b7",
		background: "#b2a0d4"
	},
	hugebaby: {
		svg: "<path d=\"M40 147Q27 80 57 43L84 23L136 25L165 49Q185 100 172 156L150 183L61 181Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M47 154L63 133L89 149L116 144L151 132L170 158L155 191H58Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M41 104L20 122L25 153L47 150M169 104L191 126L184 154L165 148\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"88\" cy=\"79\" rx=\"5\" ry=\"7\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"90\" cy=\"81\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"128\" cy=\"79\" rx=\"5\" ry=\"7\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"130\" cy=\"81\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M103 85L97 105L110 107\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"108\" cy=\"120\" rx=\"16\" ry=\"11\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\"/><ellipse cx=\"108\" cy=\"120\" rx=\"6\" ry=\"6\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\"/><path d=\"M81 144Q107 165 136 143\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M86 36L99 44\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M60 178L47 188L55 199H83L87 183M132 183L138 199H164L172 191L151 178\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M83 157L105 171L128 156\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#df7855",
		background: "#f9aa67"
	},
	hypnotist: {
		svg: "<path d=\"M55 166L75 113L125 105L162 169L154 191H63Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M69 149L56 121L29 119L20 103L33 95L67 103L89 132M130 123L151 99L175 92L186 105L156 121L145 147\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M69 111L63 70L78 43L111 38L136 57L143 90L123 119Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M69 57L47 38L52 22L72 30L90 12L106 27L129 18L143 38L126 54Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"96\" cy=\"73\" rx=\"34\" ry=\"25\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"3\"/><ellipse cx=\"96\" cy=\"73\" rx=\"26\" ry=\"19\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2\"/><path d=\"M100 74q-14-12-21 0q-6 11 10 13q17-1 17-15q-1-14-21-13\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M77 102L61 117L93 113L103 131L118 111L146 119L130 96Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M91 141L109 150L132 138L137 158L108 170L85 160Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"178\" cy=\"82\" rx=\"17\" ry=\"17\" fill=\"#ddd7d7\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M177 65L183 35\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M182 34L165 24\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/>",
		accent: "#9777b7",
		background: "#bad76f"
	},
	inchworm: {
		svg: "<path d=\"M30 168Q26 112 59 109Q85 108 88 147L103 153Q97 88 127 81Q161 75 167 131L174 138Q172 110 192 120Q209 141 190 165Q174 183 151 163L142 144Q144 108 128 110Q116 116 124 158Q122 184 99 184Q76 183 65 163L61 140Q45 137 50 170Z\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"35\" cy=\"153\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"44\" cy=\"126\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"65\" cy=\"120\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"80\" cy=\"145\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"111\" cy=\"157\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"115\" cy=\"122\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"124\" cy=\"97\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"148\" cy=\"102\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"156\" cy=\"128\" rx=\"12\" ry=\"9\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2\"/><path d=\"M175 135L174 115L186 122L198 113L198 144L188 159L174 153Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"183\" cy=\"134\" rx=\"5\" ry=\"8\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"185\" cy=\"136\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"195\" cy=\"131\" rx=\"5\" ry=\"8\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"197\" cy=\"133\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M180 146q8.5 14 17 0l-6 16q-8.5 12-11-16Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M188.5 152L188.5 162\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M175 119L171 100L180 107L181 94L188 102L195 90L200 112\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M39 175L34 187\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M75 175L70 187\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M111 175L106 187\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M147 175L142 187\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/>",
		accent: "#8a67a3",
		background: "#f5dc61"
	},
	lackey: {
		svg: "<path d=\"M56 168L46 185H82L94 167M122 166L143 185H173L157 172\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M47 147L50 90Q62 51 92 52L127 71L154 119L162 174H69Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M53 89L40 111L53 120L66 100M63 75L78 90L89 72\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M111 84L118 63L143 57L158 67L157 80L181 91L179 103L154 104L149 125L128 123L117 105Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"147\" cy=\"72\" rx=\"6\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"149\" cy=\"74\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M131 109L136 124L153 130L153 147L124 135L111 118Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M132 137L151 150L161 135L168 140L160 159L146 165L120 149Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M49 88Q74 44 116 67L131 61L106 45L75 44L59 57\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M75 165L84 136L109 145L106 174Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#e99b64",
		background: "#84cfd1"
	},
	leaptoad: {
		svg: "<path d=\"M64 113Q43 122 50 144L28 155L14 151L8 160L32 170L72 149Q82 135 69 125L99 135Z\" fill=\"#62a9cf\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M109 143L127 166L100 178L100 188L129 182L148 163L135 141Z\" fill=\"#62a9cf\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M59 95L42 78L29 42L19 42L20 77L42 112Z\" fill=\"#62a9cf\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 46L12 35L14 24L21 35L23 19L29 20L30 36L36 27L42 30L35 49Z\" fill=\"#62a9cf\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M188 78L203 105L198 178\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M188 78L203 105L198 178\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M65 99Q72 61 118 57Q157 48 175 88Q194 106 170 131Q145 162 104 148Q66 140 65 99Z\" fill=\"#62a9cf\" stroke=\"#30213c\" stroke-width=\"3.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M80 87L73 106L82 130L98 136\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M91 83L75 65L57 59L51 46L64 37L90 41L112 57Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M53 43L42 19L61 9L89 22L88 39L105 48L94 57Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M49 33L87 29L89 39L54 45Z\" fill=\"#edbd4c\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"134\" cy=\"67\" rx=\"16\" ry=\"33\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.8\"/><ellipse cx=\"166\" cy=\"75\" rx=\"15\" ry=\"33\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.8\"/><ellipse cx=\"138\" cy=\"63\" rx=\"5\" ry=\"20\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"170\" cy=\"72\" rx=\"5\" ry=\"20\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M118 47Q128 33 140 34M153 48Q165 40 176 45\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M121 108Q148 120 168 102Q166 133 146 135Q132 130 121 108Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"2.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M126 114L136 119L136 130L130 125ZM140 119L149 119L150 133L142 132ZM153 116L161 111L160 124L154 131Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M167 132L185 125L193 133L186 142L176 138L172 145L166 139Z\" fill=\"#62a9cf\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M85 107L91 101M92 117L99 110M100 127L106 121M117 140L123 135\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#5b9b62",
		background: "#f9aa67"
	},
	legs: {
		svg: "<path d=\"M48 17L73 21L75 129L61 163L31 170L20 189H84L98 163L108 58L119 162L144 182L183 182L190 168L151 155L148 23Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M61 28L58 134\" fill=\"none\" stroke=\"#3d6e46\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M72 28L67 134\" fill=\"none\" stroke=\"#3d6e46\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M83 28L76 134\" fill=\"none\" stroke=\"#3d6e46\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M94 28L85 134\" fill=\"none\" stroke=\"#3d6e46\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M87 44Q124 34 143 57L148 87L132 102L119 101L114 79L86 65Z\" fill=\"#f0d449\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"134\" cy=\"74\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"136\" cy=\"76\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M106 51L98 33L117 43L129 25L137 46L158 43L146 61L124 57Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M113 105L100 92L91 102L105 119L120 119\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M29 169L63 164L78 181H17Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M142 163L175 164L193 182H145Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M23 185L79 185\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M149 186L192 186\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/>",
		accent: "#9480b7",
		background: "#b2a0d4"
	},
	lovableloser: {
		svg: "<ellipse cx=\"87\" cy=\"108\" rx=\"68\" ry=\"69\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M105 104q-40-45-62-7q-15 40 24 49q43 6 53-34q6-51-39-58\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M54 168Q76 154 118 158L150 156Q155 120 161 111L178 114Q196 141 184 170L169 187H65L41 180Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M159 125L155 87L164 78L170 87L167 121M179 122L180 81L189 76L195 89L187 129\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"163\" cy=\"83\" rx=\"6\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"165\" cy=\"85\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"186\" cy=\"83\" rx=\"6\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"188\" cy=\"85\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"171\" cy=\"134\" rx=\"7\" ry=\"10\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2\"/><path d=\"M163 151Q174 145 181 153\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M159 116L147 99M187 110L200 96\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M133 158L140 137\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><ellipse cx=\"139\" cy=\"135\" rx=\"5\" ry=\"4\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\"/><ellipse cx=\"134\" cy=\"129\" rx=\"5\" ry=\"4\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\"/><ellipse cx=\"146\" cy=\"129\" rx=\"5\" ry=\"4\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\"/><ellipse cx=\"140\" cy=\"123\" rx=\"5\" ry=\"4\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1.5\"/><ellipse cx=\"140\" cy=\"130\" rx=\"3\" ry=\"3\" fill=\"#f0cd4b\" stroke=\"#30213c\" stroke-width=\"1\"/>",
		accent: "#df7855",
		background: "#f9aa67"
	},
	mouth: {
		svg: "<path d=\"M60 138L48 164L22 156L12 166L24 179L57 182L79 154Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M142 144L157 157L188 147L202 157L196 173L159 183L135 164Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M49 86L21 91L13 106L28 116L47 108\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"11\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M168 87L197 94L203 109L187 118L169 106\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"11\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M49 86L21 91L13 106L28 116L47 108\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M168 87L197 94L203 109L187 118L169 106\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M46 55Q75 66 103 53Q117 46 139 56Q166 68 185 56Q189 113 167 147Q139 177 94 172Q46 166 34 111L31 67Z\" fill=\"#d9505b\" stroke=\"#30213c\" stroke-width=\"3.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M43 72Q77 89 111 72Q146 89 177 70L163 137Q144 158 107 154Q66 156 49 125Z\" fill=\"#2e2533\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M42 70L57 78L61 98L45 92ZM58 78L77 83L80 105L62 101ZM78 82L98 79L99 104L81 106ZM99 79L119 77L121 105L101 105ZM121 80L141 83L139 104L123 105ZM142 83L162 78L157 101L141 105ZM162 78L178 69L174 90L159 101Z\" fill=\"#fff8de\" stroke=\"#30213c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M79 142Q84 122 104 122Q123 111 143 129L142 146Q111 162 79 142Z\" fill=\"#e88a56\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M107 127L110 139\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M57 137L72 144L74 158L61 150ZM73 143L91 148L93 164L76 159ZM94 149L114 150L115 166L96 165ZM117 149L136 144L132 162L118 166ZM138 144L154 136L147 154L134 161Z\" fill=\"#fff8de\" stroke=\"#30213c\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"105\" cy=\"52\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"106\" cy=\"53\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"121\" cy=\"51\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"122\" cy=\"52\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M55 57L58 67M72 63L74 72M143 63L141 72M160 66L159 73M84 161L84 168M129 164L128 170\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M22 92L38 99L50 94L55 100L44 106L54 106L55 111L43 115L30 110L20 105Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M195 94L181 100L170 95L165 101L177 107L167 107L165 113L179 117L191 110L201 105Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#68a6c8",
		background: "#bad76f"
	},
	magician: {
		svg: "<path d=\"M61 128L49 184H161L146 122Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M56 115L64 91L119 91L151 111L162 165L139 153L125 180L101 142L75 173L68 145L40 155Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 91Q49 76 59 50L74 31L100 35L116 46L140 64L135 78L113 77L110 100L85 107Z\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M62 52L57 34L73 38L83 22L99 36L119 33L126 52\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"108\" cy=\"55\" rx=\"6\" ry=\"8\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"110\" cy=\"57\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M88 104L74 116L94 124L105 113L117 126L133 115L114 100Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M60 119L36 98L28 107L45 137L64 140M138 118L165 111L171 125L148 138\" fill=\"#a48bc6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M31 101L23 38\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M23 38L22 28\" fill=\"none\" stroke=\"#fff7e6\" stroke-width=\"5\" stroke-linecap=\"round\"/><path d=\"M154 140L188 140L185 184H159Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"171\" cy=\"139\" rx=\"27\" ry=\"7\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\"/><polygon points=\"167,87 169.38053027178452,92.72348117278146 175.55950864665638,93.21884705062547 170.85177889099538,97.25151882721853 172.29006727063225,103.28115294937453 167,100.05 161.70993272936775,103.28115294937453 163.14822110900462,97.25151882721853 158.44049135334362,93.21884705062547 164.61946972821548,92.72348117278146\" fill=\"#f0d148\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\"/><polygon points=\"189,110 190.8515235447213,114.45159646771891 195.65739561406608,114.83688103937537 191.99582802632975,117.97340353228108 193.11449676604732,122.66311896062463 189,120.15 184.88550323395268,122.66311896062463 186.00417197367025,117.97340353228108 182.34260438593392,114.83688103937537 187.1484764552787,114.45159646771891\" fill=\"#f0d148\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\"/><ellipse cx=\"173\" cy=\"121\" rx=\"6\" ry=\"6\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2\"/>",
		accent: "#8a67a3",
		background: "#f5dc61"
	},
	mastermind: {
		svg: "<path d=\"M50 170L64 111L156 107L176 179L159 195H68Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 107L52 63L58 30L84 38L112 29L146 35L167 21L166 69L146 112L123 136L91 128Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M72 60L87 51L114 58L130 49L147 56L145 80L123 92L105 88L87 98L76 85Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M92 71L123 75L134 89L114 96L122 114L99 108L92 91Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"109\" cy=\"65\" rx=\"5\" ry=\"7\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"111\" cy=\"67\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M90 119L111 141L132 119L145 154L126 174L90 169L74 150Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M60 32L39 14L73 17L84 5L103 18L126 8L141 22L170 11L164 31L132 46L109 36L85 44Z\" fill=\"#e2ddc4\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M71 23L86 34\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M89 23L97 34\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M107 23L108 34\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M125 23L119 34\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M143 23L130 34\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M79 169L108 155L145 172\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M107 156L111 186\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/>",
		accent: "#e99b64",
		background: "#84cfd1"
	},
	partyanimal: {
		svg: "<path d=\"M62 173l20 3 15 12-5 9h-42l-4-9Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M137 175l20 3 15 12-5 9h-42l-4-9Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M52 102L88 90L133 96L167 135L165 180H47Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M57 105L75 113L99 180H76ZM97 97L115 102L145 180H123Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M78 98L63 76L70 46L92 37L117 45L127 62L145 75L135 90L111 88L109 107Z\" fill=\"#efd548\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"113\" cy=\"57\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"115\" cy=\"59\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M72 47L85 15L108 43Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M85 16L93 28L80 31Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"85\" cy=\"14\" rx=\"4\" ry=\"4\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"2\"/><path d=\"M64 115L39 105L34 82L22 86L26 121L53 139M143 114L167 90L177 97L163 127L153 143\" fill=\"#efd548\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M23 89L18 74L24 68L31 80L32 65L40 66L41 84L49 78L54 85L39 101M167 95L166 80L171 76L178 88L179 71L186 74L186 91L196 86L199 94L182 107\" fill=\"#efd548\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M92 87q15.5 14 31 0l-6 16q-15.5 12-25-16Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M107.5 93L107.5 103\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><ellipse cx=\"111\" cy=\"124\" rx=\"5\" ry=\"5\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2\"/><ellipse cx=\"119\" cy=\"143\" rx=\"5\" ry=\"5\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2\"/>",
		accent: "#547ba6",
		background: "#ed96be"
	},
	rocket: {
		svg: "<path d=\"M63 119L45 168L60 187L86 166L103 145M119 132L139 172L164 182L177 168L151 145\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M64 114L73 85L124 78L149 117L142 160L91 163Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M86 91L73 58L89 35L111 32L135 48L138 73L117 94Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M86 49L79 34L85 12L98 17L107 39M109 40L115 15L129 13L137 29L128 51\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"91\" cy=\"30\" rx=\"5\" ry=\"12\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"123\" cy=\"29\" rx=\"5\" ry=\"12\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M139 61L159 23L184 41L184 145L159 164L140 141Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M159 23L170 6L184 41Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M147 147L150 192L166 178L176 199L179 158Z\" fill=\"#f4d54f\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M150 56h11v12h-11Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M161 56h11v12h-11Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M172 56h11v12h-11Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M78 113L60 105L47 115L70 135L92 132M126 112L146 98L158 110L144 135L127 138\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#9480b7",
		background: "#b2a0d4"
	},
	romantic: {
		svg: "<path d=\"M57 115L73 95L129 88L159 110L173 185H50Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M72 90L59 65L65 44L87 31L110 37L124 51L153 65L159 87L139 101L105 97L95 116Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M74 43L63 21L80 29L87 16L98 35M116 45L126 25L130 49\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"92\" cy=\"48\" rx=\"7\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"94\" cy=\"50\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"111\" cy=\"49\" rx=\"6\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"113\" cy=\"51\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M75 75L140 81L130 94L87 88Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M84 78l5 8 5-7Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M96 79l5 8 5-7Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M108 80l5 8 5-7Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M120 81l5 8 5-7Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M88 114L111 125L137 109L142 136L111 145L86 132Z\" fill=\"#edd45e\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M40 151L95 145L112 155L130 146L184 151L174 188L125 184L112 192L98 183L53 188Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M112 157L112 190\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M57 162L94 158\" fill=\"none\" stroke=\"#a894b0\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M133 161L174 164\" fill=\"none\" stroke=\"#a894b0\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M136 119q-11-13-16-1q-2 8 16 17q18-10 15-18q-6-11-15 2Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"150\" cy=\"136\" rx=\"5\" ry=\"5\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2\"/>",
		accent: "#df7855",
		background: "#f9aa67"
	},
	scoocher: {
		svg: "<path d=\"M68 142L57 181L39 188H81L95 151M121 148L139 183L163 188H124L106 161\" fill=\"#b99b50\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M57 154Q42 123 60 95L82 76L125 81L144 114L147 174L116 188L72 179Z\" fill=\"#b99b50\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M67 92L58 63L75 43L112 37L141 52L147 80L133 102L98 113Z\" fill=\"#b99b50\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M67 56Q42 34 18 56L11 77L48 68L74 73M133 56Q157 32 190 49L207 69L169 62L141 77\" fill=\"#b99b50\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"113\" cy=\"80\" rx=\"27\" ry=\"15\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M112 97Q135 93 132 118Q121 143 112 118Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M76 66L101 62L111 68L132 65L140 70L136 82L115 85L102 79L79 82Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M99 67L98 78\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M113 70L116 83\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M60 126l5-7 1 9 5-5\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M76 155l5-7 1 9 5-5\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M126 163l5-7 1 9 5-5\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M101 139l5-7 1 9 5-5\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#9777b7",
		background: "#bad76f"
	},
	sisyphus: {
		svg: "<path d=\"M65 156L53 181L38 190L50 197H79L93 165M124 157L137 182L158 186L165 198H133L108 169\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M56 114L86 91L127 92L151 125L141 171L80 175L58 153Z\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M73 117L49 111L32 86L20 93L37 128L65 140M135 112L161 93L176 64L187 69L175 111L151 132\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M81 102L75 71L86 54L106 50L127 64L127 84L152 91L148 102L124 106L105 126Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"108\" cy=\"70\" rx=\"6\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"110\" cy=\"72\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M88 61L76 49L91 44L103 49L114 41L130 54\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M57 30L79 10L130 8L164 28L160 59L119 63L88 51L58 53Z\" fill=\"#9c94a3\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M82 15L97 32L144 36M67 43L107 39\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M64 124L94 142L140 126M75 149L97 161L134 148\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M51 114L66 124L75 115\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#8a67a3",
		background: "#f5dc61"
	},
	skipper: {
		svg: "<path d=\"M55 141L46 179L73 185L89 158M125 146L149 177L170 181L176 192H133L108 161\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M59 115L75 91L116 92L143 116L159 166L123 178L73 164Z\" fill=\"#ecd050\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M78 95L65 65L73 40L98 31L120 43L130 56L159 67L154 78L120 81L113 102Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"109\" cy=\"48\" rx=\"6\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"111\" cy=\"50\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M73 42L57 30L80 12L113 24L123 41Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M76 24L82 15L94 29L106 19L113 35Z\" fill=\"#edcf4a\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M76 101L89 117L111 105L126 120L145 115\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M67 131L90 141L109 127M129 125L145 137L159 128\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"126\" cy=\"166\" rx=\"45\" ry=\"27\" fill=\"#dc6889\" stroke=\"#30213c\" stroke-width=\"3\"/><ellipse cx=\"126\" cy=\"166\" rx=\"30\" ry=\"19\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M126 146L126 186\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"M95 166L157 166\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/><ellipse cx=\"126\" cy=\"166\" rx=\"8\" ry=\"8\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"2\"/>",
		accent: "#e99b64",
		background: "#84cfd1"
	},
	stickler: {
		svg: "<ellipse cx=\"110\" cy=\"179\" rx=\"77\" ry=\"16\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M53 164L54 107L69 64L99 40L133 49L152 83L163 165Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 84Q51 54 75 29Q95 19 114 40L129 54L122 75Z\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M87 39L93 19L108 12L124 23L120 42Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"111\" cy=\"57\" rx=\"5\" ry=\"8\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"113\" cy=\"59\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M109 70L134 77L130 86L109 84Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M82 97L65 121L81 141L96 132L86 117M135 100L156 118L145 138L130 130\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M86 132L114 126L137 133L138 165L110 170L84 160Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M113 132L154 117L172 124L133 145Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M126 129L129 135\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M134 126L137 132\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M142 123L145 129\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M150 120L153 126\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M158 117L161 123\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M90 158L127 158\" fill=\"none\" stroke=\"#fff7e6\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M62 155L48 167L65 176M147 155L165 167L149 178\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#547ba6",
		background: "#ed96be"
	},
	suckerfish: {
		svg: "<path d=\"M53 91L19 65L29 116L18 153L60 141Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M48 103Q95 61 150 82L179 110L178 149Q116 179 53 144Z\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M163 99Q181 88 189 97L195 119L191 151L180 159L171 147L175 125Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M64 109L42 87L73 94M69 144L52 163L91 152\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"143\" cy=\"105\" rx=\"11\" ry=\"10\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"145\" cy=\"107\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M124 100L154 98\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M65 90L50 65L99 59L130 72L115 84Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M42 73L132 67L141 73L40 82Z\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M50 66L20 43L64 57L92 42L99 59\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M75 112L68 125\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M88 112L81 125\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M101 112L94 125\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M114 112L107 125\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"1.5\" stroke-linecap=\"round\"/><path d=\"M121 140L148 136\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#9480b7",
		background: "#b2a0d4"
	},
	thirdwheel: {
		svg: "<ellipse cx=\"109\" cy=\"171\" rx=\"28\" ry=\"28\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"3\"/><ellipse cx=\"109\" cy=\"171\" rx=\"18\" ry=\"18\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"3\"/><path d=\"M109 171L126 171\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M109 171L114.2532889043741 187.1679607770176\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M109 171L95.2467110956259 180.99234928897204\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M109 171L95.2467110956259 161.00765071102796\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M109 171L114.2532889043741 154.8320392229824\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M61 117L70 75L103 65L137 75L162 129L144 158L82 152Z\" fill=\"#edd14c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M67 99L140 89L148 103L64 116M69 129L156 116L157 131L78 144\" fill=\"#e57ba8\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M86 76L69 55L80 34L104 27L125 39L139 53L165 62L158 76L132 74L117 90Z\" fill=\"#edd14c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"117\" cy=\"44\" rx=\"6\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"119\" cy=\"46\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M75 42L49 34L62 24L88 32L101 18L109 31\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M65 88L37 70L28 77L49 105L64 110M142 92L173 64L185 69L165 107L149 118\" fill=\"#edd14c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M172 69L171 52L177 48L183 61L187 45L194 49L192 65L201 60L205 68L189 82\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M142 146L173 151L170 171L146 163Z\" fill=\"#6cb5cf\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M90 151L108 171\" fill=\"none\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linecap=\"round\"/>",
		accent: "#df7855",
		background: "#f9aa67"
	},
	twin: {
		svg: "<path d=\"M37 128L72 111L102 132L123 112L163 125L180 185H36Z\" fill=\"__TEAM__\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M40 130L49 141L43 183H60L66 131L79 129L75 184H93L95 142L108 145L111 184H127L129 132L144 127L149 184H166L162 139\" fill=\"#fff7e6\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M52 115L38 78L47 51L69 44L87 56L88 70L113 81L108 95L81 94L84 121Z\" fill=\"#e4ce4d\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M132 118L118 78L130 49L149 42L166 55L167 70L193 82L187 98L163 94L165 126Z\" fill=\"#e4ce4d\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"76\" cy=\"62\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"78\" cy=\"64\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><ellipse cx=\"156\" cy=\"61\" rx=\"7\" ry=\"9\" fill=\"#fffdf0\" stroke=\"#30213c\" stroke-width=\"2.5\"/><ellipse cx=\"158\" cy=\"63\" rx=\"2.6\" ry=\"4\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"0\"/><path d=\"M48 53L48 32L61 43L74 30L80 49M128 51L129 29L141 42L156 28L163 48\" fill=\"#81aa48\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M63 99L83 106L81 115L65 110M142 99L160 108L155 116L139 109\" fill=\"#ed9053\" stroke=\"#30213c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M74 143L98 158L119 144L129 155L105 176L87 168M145 145L126 158\" fill=\"#e4ce4d\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M53 181l20 3 15 12-5 9h-42l-4-9Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M143 183l20 3 15 12-5 9h-42l-4-9Z\" fill=\"#30213c\" stroke=\"#30213c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
		accent: "#9777b7",
		background: "#bad76f"
	}
};
function We(e) {
	return Ue[e].background;
}
function X({ id: e, playerColor: t, className: n, normalized: r = !1 }) {
	let i = Ue[e];
	return /* @__PURE__ */ y("svg", {
		className: n,
		viewBox: r ? He[e] : "0 0 220 210",
		"aria-hidden": "true",
		focusable: "false",
		"data-athlete": e,
		children: /* @__PURE__ */ y("g", { dangerouslySetInnerHTML: { __html: i.svg.replaceAll("__TEAM__", t ?? i.accent) } })
	});
}
//#endregion
//#region src/games/magicalathlete/track-art.tsx
function Ge({ className: e }) {
	return /* @__PURE__ */ y("svg", {
		className: e,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: /* @__PURE__ */ y("path", {
			d: "m16 3 4 8 9 1-7 7 2 10-8-5-8 5 2-10-7-7 9-1Z",
			fill: "#ffe148",
			stroke: "#30213c",
			strokeWidth: "2.2",
			strokeLinejoin: "round"
		})
	});
}
function Ke({ className: e }) {
	return /* @__PURE__ */ b("svg", {
		className: e,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ y("path", {
			d: "m3 24 6-15 14-4 6 16-4 7Z",
			fill: "#94849f",
			stroke: "#30213c",
			strokeWidth: "2.4",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ y("path", {
			d: "m11 13 7-3",
			stroke: "#fff7e6",
			strokeWidth: "2.5",
			strokeLinecap: "round"
		})]
	});
}
function qe({ backwards: e = !1, className: t }) {
	return /* @__PURE__ */ y("svg", {
		className: t,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: /* @__PURE__ */ y("path", {
			d: e ? "M26 4 6 16l20 12Z" : "M6 4l20 12L6 28Z",
			fill: "currentColor",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinejoin: "round"
		})
	});
}
function Je({ finish: e = !1 }) {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ y("path", {
			d: "M7 29V4m1 1h19v16H8",
			fill: e ? "#fff8e9" : "#e6ab6d",
			stroke: "currentColor",
			strokeWidth: "2.4",
			strokeLinejoin: "round"
		}), e && /* @__PURE__ */ y("path", {
			d: "M8 5h6v5H8m12-5h7v5h-7m-6 0h6v6h-6m-6 0h6v5H8m12-5h7v5h-7",
			fill: "currentColor"
		})]
	});
}
function Ye() {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: /* @__PURE__ */ y("path", {
			d: "M7 28V11h19m-8-7 8 7-8 7",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "3.5",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function Xe({ className: e }) {
	return /* @__PURE__ */ b("svg", {
		className: e,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ y("circle", {
			cx: "16",
			cy: "16",
			r: "14",
			fill: "#d7efcc",
			stroke: "#30213c",
			strokeWidth: "2"
		}), /* @__PURE__ */ y("path", {
			d: "m9 16 5 5 10-12",
			fill: "none",
			stroke: "#30213c",
			strokeWidth: "3",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
function Ze({ value: e }) {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ y("rect", {
			x: "1.5",
			y: "1.5",
			width: "29",
			height: "29",
			rx: "5",
			fill: "#fff7e6",
			stroke: "#30213c",
			strokeWidth: "2.5"
		}), {
			1: [[16, 16]],
			2: [[9, 9], [23, 23]],
			3: [
				[9, 9],
				[16, 16],
				[23, 23]
			],
			4: [
				[9, 9],
				[23, 9],
				[9, 23],
				[23, 23]
			],
			5: [
				[9, 9],
				[23, 9],
				[16, 16],
				[9, 23],
				[23, 23]
			],
			6: [
				[9, 8],
				[23, 8],
				[9, 16],
				[23, 16],
				[9, 24],
				[23, 24]
			]
		}[e ?? 5].map(([e, t]) => /* @__PURE__ */ y("circle", {
			cx: e,
			cy: t,
			r: "2.2",
			fill: "#30213c"
		}, `${e}:${t}`))]
	});
}
//#endregion
//#region src/games/magicalathlete/race-cell-sheet.tsx
function Qe({ inspection: e, race: t, colorOf: n, racerName: r, onClose: i }) {
	let c = p(), d = s(null), f = s(null), { ref: m } = l("mag-inspection-layer"), h = u(), g = a(), v = e?.kind === "racer" ? t.racers.find((t) => t.owner === e.owner) : void 0, x = e?.kind === "cell" && t.track === "wild" ? A[e.pos] : void 0, ee = e.kind === "cell" && e.pos === 15 && t.racers.some((e) => e.id === "blimp" || e.copied === "blimp" || e.power === "blimp"), S = x?.kind === "star" ? "★" : x?.kind === "trip" ? "!" : x?.kind === "arrow" ? `${x.n > 0 ? "+" : "−"}${Math.abs(x.n)}` : null, C = x?.kind === "star" ? c("games.magicalathlete.cellStarEffect") : x?.kind === "trip" ? c("games.magicalathlete.cellTripEffect") : x?.kind === "arrow" ? c(x.n > 0 ? "games.magicalathlete.cellArrowForward" : "games.magicalathlete.cellArrowBack", { n: Math.abs(x.n) }) : ee ? c("games.magicalathlete.cellCornerEffect") : e.kind === "cell" && e.pos === 0 ? c("games.magicalathlete.cellStartEffect") : e.kind === "cell" && e.pos === 29 ? c("games.magicalathlete.cellFinishEffect") : c("games.magicalathlete.cellNormalEffect"), w = v ? r(v.id) : ee ? c("games.magicalathlete.secondCorner") : c("games.magicalathlete.cellTitle", { n: e?.kind === "cell" ? e.pos : 0 }), T = e.kind === "racer" ? `pawn:${e.owner}` : `effect:${e.pos}`;
	return o(() => {
		if (!h) return;
		let t = 0, n = 0, r = () => {
			let a = h.measure("mag-inspection-layer"), o = h.measure("mag-viewport"), s = e.kind === "racer" ? h.measure(`motion:${e.owner}`) ?? h.measure(T) : h.measure(T) ?? h.measure(`cell:${e.pos}`), c = d.current;
			if (!s) {
				if (++n > 2) {
					i();
					return;
				}
				t = requestAnimationFrame(r);
				return;
			}
			if (n = 0, a && o && c) {
				let e = s.x + s.w > o.x && s.x < o.x + o.w && s.y + s.h > o.y && s.y < o.y + o.h;
				c.style.visibility = e ? "visible" : "hidden";
				let t = s.y - a.y, n = a.h - t - s.h - 16, r = t - 16, i = r >= 140 || r >= n ? "above" : "below";
				c.dataset.side = i, c.style.maxHeight = `${Math.min(320, Math.max(100, i === "above" ? r : n))}px`;
				let l = s.x + s.w / 2 - a.x, u = Math.max(8, Math.min(l - c.offsetWidth / 2, a.w - c.offsetWidth - 8));
				c.style.left = `${u}px`, c.style.top = `${Math.max(8, i === "above" ? t - c.offsetHeight - 10 : t + s.h + 10)}px`, c.style.setProperty("--mag-tip-x", `${Math.max(15, Math.min(l - u, c.offsetWidth - 15))}px`);
			}
			t = requestAnimationFrame(r);
		};
		return t = requestAnimationFrame(r), () => cancelAnimationFrame(t);
	}, [
		h,
		e,
		T,
		i
	]), o(() => {
		let e = document.activeElement, t = requestAnimationFrame(() => f.current?.focus({ preventScroll: !0 })), n = (e) => {
			e.key === "Escape" && (e.preventDefault(), i());
		}, r = (e) => {
			e.composedPath().some((e) => e === d.current || e instanceof Element && e.matches(".mag-pawn, .mag-column__marker, .mag-column__surface")) || i();
		};
		window.addEventListener("keydown", n), document.addEventListener("click", r);
		let a = d.current;
		return () => {
			cancelAnimationFrame(t), window.removeEventListener("keydown", n), document.removeEventListener("click", r), a?.contains(document.activeElement) && e instanceof HTMLElement && e.isConnected && e.focus({ preventScroll: !0 });
		};
	}, [T, i]), /* @__PURE__ */ y("div", {
		ref: m,
		className: "mag-inspection-layer",
		children: /* @__PURE__ */ b("div", {
			ref: d,
			role: "region",
			"aria-labelledby": g,
			className: "mag-inspection",
			style: { "--player-color": v ? n(v.owner) : "var(--mag-purple)" },
			children: [/* @__PURE__ */ b("div", {
				className: "mag-inspection__head",
				children: [
					v && /* @__PURE__ */ b("div", {
						className: "mag-athlete-detail__portrait",
						children: [/* @__PURE__ */ y(X, {
							id: v.id,
							playerColor: n(v.owner)
						}), v.tripped && /* @__PURE__ */ y("span", { children: c("games.magicalathlete.trippedMark") })]
					}),
					/* @__PURE__ */ y("strong", {
						id: g,
						children: w
					}),
					/* @__PURE__ */ y("button", {
						ref: f,
						type: "button",
						"aria-label": c("common.close"),
						onClick: i,
						children: /* @__PURE__ */ y(_, { size: 19 })
					})
				]
			}), /* @__PURE__ */ y("div", {
				className: "mag-inspection__body",
				children: v ? /* @__PURE__ */ b("article", {
					className: "mag-athlete-detail",
					children: [/* @__PURE__ */ y("p", { children: c(Be[v.id]) }), v.power !== v.id && /* @__PURE__ */ b("div", {
						className: "mag-athlete-detail__effective",
						children: [/* @__PURE__ */ y("h3", { children: v.power ? c("games.magicalathlete.cellEffectivePower", { name: r(v.power) }) : c("games.magicalathlete.cellNoEffectivePower") }), v.power && /* @__PURE__ */ y("p", { children: c(Be[v.power]) })]
					})]
				}) : /* @__PURE__ */ b("div", {
					className: "mag-space-detail",
					children: [S && /* @__PURE__ */ y("span", {
						"aria-hidden": !0,
						children: x?.kind === "star" ? /* @__PURE__ */ y(Ge, {}) : x?.kind === "trip" ? /* @__PURE__ */ y(Ke, {}) : S
					}), /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("h3", { children: c("games.magicalathlete.cellEffect") }), /* @__PURE__ */ y("p", { children: C })] })]
				})
			})]
		})
	});
}
//#endregion
//#region src/games/magicalathlete/race-dialog.tsx
function $e({ title: e, children: t, footer: n, onCancel: r, className: i = "" }) {
	let c = s(null), l = a();
	return o(() => {
		let e = c.current;
		if (e) return e.showModal(), () => e.close();
	}, []), /* @__PURE__ */ b("dialog", {
		ref: c,
		className: `mag-dialog ${i}`,
		"aria-modal": "true",
		"aria-labelledby": l,
		onCancel: (e) => {
			e.preventDefault(), r?.();
		},
		children: [
			/* @__PURE__ */ y("h2", {
				id: l,
				className: "mag-dialog__title",
				children: e
			}),
			/* @__PURE__ */ y("div", {
				className: "mag-dialog__body",
				children: t
			}),
			/* @__PURE__ */ y("div", {
				className: "mag-dialog__footer",
				children: n
			})
		]
	});
}
//#endregion
//#region src/games/magicalathlete/race-result.tsx
function et({ race: e, raceNum: t, log: n, colorOf: r, nameOf: a, racerName: o, onContinue: s }) {
	let c = p();
	i(() => {
		let e = window.setTimeout(s, 3500);
		return () => window.clearTimeout(e);
	}, [s]);
	let l = n.map((e) => e.k).lastIndexOf("raceStart"), u = n.slice(l < 0 ? 0 : l).filter((e) => e.k === "award"), d = new Set(u.map((e) => e.rid)), f = e.racers.filter((e) => !d.has(e.owner));
	return /* @__PURE__ */ y($e, {
		title: c("games.magicalathlete.roundPlacings", { n: t }),
		className: "mag-result-dialog",
		onCancel: s,
		footer: /* @__PURE__ */ y("button", {
			type: "button",
			className: "mag-confirm-button",
			onClick: s,
			children: c("games.magicalathlete.nextRace")
		}),
		children: /* @__PURE__ */ b("div", {
			className: "mag-results",
			children: [/* @__PURE__ */ y("ol", {
				className: "mag-results__medals",
				children: u.map((t) => {
					let n = e.racers.find((e) => e.owner === t.rid);
					return /* @__PURE__ */ b("li", {
						className: `mag-result mag-result--${t.medal}`,
						style: { "--player-color": r(t.rid) },
						children: [
							/* @__PURE__ */ b("span", {
								className: "mag-result__place",
								children: [t.medal === "gold" ? "🥇" : "🥈", /* @__PURE__ */ y("strong", { children: c("games.magicalathlete.roundPlace", { n: t.medal === "gold" ? 1 : 2 }) })]
							}),
							/* @__PURE__ */ y("span", {
								className: "mag-result__stage",
								children: n && /* @__PURE__ */ y(X, {
									id: n.id,
									playerColor: r(t.rid),
									className: "mag-result__portrait"
								})
							}),
							/* @__PURE__ */ b("span", {
								className: "mag-result__name",
								children: [/* @__PURE__ */ y("strong", { children: a(t.rid) }), n && /* @__PURE__ */ y("span", { children: o(n.id) })]
							}),
							/* @__PURE__ */ b("strong", {
								className: "mag-result__points",
								children: [
									"+",
									t.n,
									" ★"
								]
							})
						]
					}, t.medal);
				})
			}), f.length > 0 && /* @__PURE__ */ y("div", {
				className: "mag-results__others",
				children: f.map((e) => /* @__PURE__ */ b("div", {
					className: "mag-result",
					style: { "--player-color": r(e.owner) },
					children: [
						/* @__PURE__ */ y(X, {
							id: e.id,
							playerColor: r(e.owner),
							className: "mag-result__portrait"
						}),
						/* @__PURE__ */ b("span", {
							className: "mag-result__name",
							children: [/* @__PURE__ */ y("strong", { children: a(e.owner) }), /* @__PURE__ */ y("span", { children: o(e.id) })]
						}),
						/* @__PURE__ */ y("span", { children: c(e.eliminated ? "games.magicalathlete.eliminatedMark" : "games.magicalathlete.didNotFinish") })
					]
				}, e.owner))
			})]
		})
	});
}
//#endregion
//#region src/games/magicalathlete/race-presentation.ts
function tt(e, t) {
	let n = 0, r = e.scrollLeft, i = e.scrollLeft, a = 0, o = 0, s = (t) => {
		let c = Math.min(50, t - a) / 1e3;
		a = t;
		let l = i - r, u = Math.exp(-18 * c), d = (o + 18 * l) * c, f = r + (l + d) * u;
		i = l > 0 ? Math.max(r, f) : Math.min(r, f), e.scrollLeft = i, o = (o - 18 * d) * u, Math.abs(i - r) > .75 || Math.abs(o) > 8 ? n = requestAnimationFrame(s) : (i = r, e.scrollLeft = r, n = 0, o = 0);
	};
	return {
		to(c) {
			if (r = Math.max(0, Math.min(c, e.scrollWidth - e.clientWidth)), o * (r - e.scrollLeft) < 0 && (o = 0), t) {
				i = r, e.scrollLeft = r;
				return;
			}
			n ||= (i = e.scrollLeft, a = performance.now(), requestAnimationFrame(s));
		},
		track(t) {
			cancelAnimationFrame(n), n = 0, o = 0, i = r = Math.max(0, Math.min(t, e.scrollWidth - e.clientWidth)), e.scrollLeft = i;
		},
		stop() {
			cancelAnimationFrame(n), n = 0, o = 0, r = e.scrollLeft, i = r;
		}
	};
}
var nt = /* @__PURE__ */ new WeakMap();
function rt(e, t) {
	return nt.set(e, t), () => {
		nt.get(e) === t && nt.delete(e);
	};
}
function it(e) {
	return e ? nt.get(e) : void 0;
}
//#endregion
//#region src/games/magicalathlete/standee.tsx
function at({ racer: e, color: t, tripped: n = !1, running: r = !1 }) {
	return /* @__PURE__ */ b("span", {
		className: `mag-standee ${n ? "mag-standee--tripped" : ""} ${r ? "mag-standee--running" : ""}`,
		style: { "--player-color": t },
		children: [
			/* @__PURE__ */ y("span", { className: "mag-standee__base" }),
			/* @__PURE__ */ y("span", {
				className: "mag-standee__body",
				children: /* @__PURE__ */ y(X, {
					id: e,
					playerColor: t,
					normalized: !0
				})
			}),
			n && /* @__PURE__ */ y(Ge, { className: "mag-standee__trip" })
		]
	});
}
//#endregion
//#region src/games/magicalathlete/race-track.tsx
function ot({ racer: e, color: t, label: n, left: r, top: i, active: a, powered: o, powerKey: s, disabled: c, onInspect: u }) {
	let { ref: d, hidden: f } = l(`pawn:${e.owner}`);
	return /* @__PURE__ */ b("button", {
		ref: d,
		type: "button",
		disabled: c,
		className: `mag-pawn ${a ? "mag-pawn--active" : ""} ${o ? "mag-pawn--power" : ""}`,
		style: {
			left: r,
			top: i,
			"--player-color": t,
			visibility: f ? "hidden" : void 0
		},
		"aria-label": n,
		onClick: u,
		children: [o && /* @__PURE__ */ b("span", {
			className: "mag-power-rings",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ y("i", {}), /* @__PURE__ */ y("i", {})]
		}, `rings:${s}`), /* @__PURE__ */ y(at, {
			racer: e.id,
			color: t,
			tripped: e.tripped
		}, o ? `standee:${s}` : "idle")]
	});
}
function st({ owner: e, left: t, top: n }) {
	let { ref: r } = l(`lane:${e}`);
	return /* @__PURE__ */ y("span", {
		ref: r,
		className: "mag-runner-slot",
		style: {
			left: t,
			top: n
		},
		"aria-hidden": !0
	});
}
function ct({ pos: e, race: t, showCorner: n, left: r, top: i, height: a, selected: o, legal: s, selecting: c, impact: u, onInspect: d, onSelect: f }) {
	let m = p(), { ref: h } = l(`cell:${e}`), { ref: g } = l(`effect:${e}`), _ = t.track === "wild" ? A[e] : void 0, x = n && e === 15, ee = e === 0 || e === 29, S = _?.kind === "star" ? /* @__PURE__ */ y(Ge, {}) : _?.kind === "trip" ? /* @__PURE__ */ y(Ke, {}) : _?.kind === "arrow" ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(qe, { backwards: _.n < 0 }), /* @__PURE__ */ y("span", { children: Math.abs(_.n) })] }) : x ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(Ye, {}), /* @__PURE__ */ y("span", { children: m("games.magicalathlete.secondCorner") })] }) : ee ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(Je, { finish: e !== 0 }), /* @__PURE__ */ y("span", { children: m(e === 0 ? "games.magicalathlete.startMark" : "games.magicalathlete.finishMark") })] }) : null;
	return /* @__PURE__ */ b("div", {
		ref: h,
		className: `mag-column ${_ ? `mag-column--${_.kind}` : ""} ${_?.kind === "arrow" && _.n < 0 ? "mag-column--backward" : ""} ${e === 0 || e === 29 ? "mag-column--line" : ""} ${o ? "mag-column--selected" : ""} ${s ? "mag-column--legal" : ""}`,
		style: {
			left: r,
			top: i,
			height: a
		},
		children: [
			/* @__PURE__ */ b("button", {
				type: "button",
				className: "mag-column__surface",
				disabled: c && !s,
				"aria-label": m(c ? "games.magicalathlete.selectCell" : "games.magicalathlete.inspectCell", { n: e }),
				onClick: c ? f : d,
				children: [_?.kind === "arrow" && /* @__PURE__ */ y("span", {
					className: "mag-column__direction",
					"aria-hidden": !0,
					children: Array.from({ length: Math.max(3, Math.floor(a / 48)) }, (e, t) => /* @__PURE__ */ y(qe, { backwards: _.n < 0 }, t))
				}), u && /* @__PURE__ */ y("span", {
					className: "mag-column__flash",
					style: { animationDuration: `${u.ms}ms` },
					"aria-hidden": !0
				}, u.id)]
			}),
			S ? /* @__PURE__ */ y("button", {
				ref: g,
				type: "button",
				className: `mag-column__marker ${_?.kind === "arrow" ? "mag-column__marker--arrow" : ""}`,
				"aria-label": m("games.magicalathlete.inspectCell", { n: e }),
				onClick: d,
				children: S
			}) : /* @__PURE__ */ y("span", {
				className: "mag-column__number",
				"aria-hidden": !0,
				children: e
			}),
			s && /* @__PURE__ */ y(Xe, { className: "mag-column__check" })
		]
	});
}
function lt({ race: e, raceNum: t, myRid: n, log: r, logLine: i, onOpenLog: a, colorOf: d, racerName: f, selectedPos: m, onInspectCell: h, onInspectRacer: g, legalPositions: _, onSelectCell: v }) {
	let x = p(), S = u(), C = ee(), w = s(null), { ref: T } = l("mag-viewport"), [E, te] = c({
		w: 375,
		h: 500
	}), [D, O] = c([]), [k, ne] = c(!1), [A, re] = c(0), [ie, ae] = c({}), j = s(null), M = s(!1), N = E.w >= 1400 && E.h >= 620 ? 84 : E.w >= 600 && E.h >= 300 ? 60 : 48, P = E.h < (N + 4) * 6 + 102, F = P ? 3 : 6, oe = Math.max(N + 4, Math.min(N + 28, (E.h - 110) / F)), I = F * oe, L = P ? N * 2 + 20 : N + 10, se = E.w < 600 ? -.24 : P ? -.26 : -.4, R = I * Math.abs(se) / 2 + N * .7 + 16, ce = Math.max(80, (E.h - I) / 2), le = R * 2 + 31 * L, z = (t) => {
		let n = Math.floor(t * 6 / e.racers.length), r = ((P ? Math.floor(n / 2) : n) + .5) * oe;
		return {
			x: R + L / 2 + se * (r - I / 2) + (P ? (n % 2 ? 1 : -1) * N * .53 : 0) - N / 2,
			y: ce + r - N * .66
		};
	}, ue = s(e);
	o(() => {
		ue.current = e;
	}, [e]), o(() => {
		let e = w.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => te({
			w: e.contentRect.width,
			h: e.contentRect.height
		}));
		return t.observe(e), () => t.disconnect();
	}, []), o(() => {
		let e = w.current;
		if (!S || !e) return;
		let t = tt(e, C);
		j.current = t;
		let n = !1, r = 0, i = [], a = 0, o = 0, s = /* @__PURE__ */ new Map(), c = () => {
			n = !0, t.stop();
		};
		e.addEventListener("pointerdown", c), e.addEventListener("wheel", c, { passive: !0 });
		let l = (t, n) => {
			let r = ue.current.racers.findIndex((e) => e.owner === n), i = z(Math.max(0, r)).x + N / 2 + Math.max(0, Math.min(t, 30)) * L;
			return Math.max(0, Math.min(i - e.clientWidth * .45, e.scrollWidth - e.clientWidth));
		}, u = (e, n) => t.to(l(e, n)), d = rt(S, {
			follow: (r, i, o) => {
				let s = l(r, i);
				M.current || (n = !1, a = e.scrollLeft - s, t.stop()), M.current = !0, n || t.track(s + a * (1 - o) ** 2);
			},
			power: (e, t) => {
				O(e), ne(t), re((e) => e + 1), M.current || (n = !1), r = t ? performance.now() + 900 : 0, i = e.map((e) => e.owner);
			},
			powered: (e) => performance.now() < r && i.includes(e),
			focusPower: (e, t) => {
				if (M.current) return !1;
				let r = ue.current.racers.find((e) => e.owner === t);
				return n || u(r?.pos ?? e, t), !0;
			},
			flash: (e, t) => {
				window.clearTimeout(s.get(e));
				let n = ++o;
				ae((r) => ({
					...r,
					[e]: {
						id: n,
						ms: t
					}
				})), s.set(e, window.setTimeout(() => {
					ae((t) => {
						let n = { ...t };
						return delete n[e], n;
					}), s.delete(e);
				}, t));
			},
			release: () => {
				M.current = !1;
			}
		});
		return () => {
			d(), t.stop(), s.forEach((e) => window.clearTimeout(e)), e.removeEventListener("pointerdown", c), e.removeEventListener("wheel", c), j.current = null, M.current = !1;
		};
	}, [
		S,
		E.w,
		E.h,
		C
	]), o(() => {
		if (!k) return;
		let e = window.setTimeout(() => ne(!1), 900);
		return () => window.clearTimeout(e);
	}, [k, A]), o(() => {
		let t = w.current, r = e.racers.findIndex((e) => e.owner === n);
		t && r >= 0 && (t.scrollLeft = Math.max(0, z(r).x + e.racers[r].pos * L - t.clientWidth * .35));
	}, [
		t,
		E.w,
		E.h,
		n
	]), o(() => {
		if (e.busy || !e.turn) return;
		let t = e.racers.findIndex((t) => t.owner === e.turn && !t.eliminated && !t.place), n = w.current;
		t >= 0 && n && j.current?.to(z(t).x + N / 2 + e.racers[t].pos * L - n.clientWidth * .45);
	}, [
		e.turn,
		e.busy,
		E.w,
		E.h
	]);
	let B = r.slice(Math.max(0, r.map((e) => e.k).lastIndexOf("raceStart"))), de = C ? [...B].reverse().find((e) => e.k === "power") : void 0, V = de?.k === "power" ? e.racers.find((e) => e.id === de.racer) : void 0, H = C && V ? [{
		owner: V.owner,
		racer: V.id,
		power: V.power ?? V.id,
		pos: V.pos
	}] : D, U = B.at(-1), W = e.racers.some((e) => e.id === "blimp" || e.copied === "blimp" || e.power === "blimp");
	return /* @__PURE__ */ b("div", {
		className: "mag-arena",
		children: [
			/* @__PURE__ */ b("div", {
				className: "mag-arena__top",
				children: [
					/* @__PURE__ */ y("strong", { children: x(e.track === "wild" ? "games.magicalathlete.trackWild" : "games.magicalathlete.trackMild") }),
					/* @__PURE__ */ b("span", {
						className: "mag-arena__medals",
						children: [
							x("games.magicalathlete.medalGold"),
							" +",
							t + 2,
							" · ",
							x("games.magicalathlete.medalSilver"),
							" +",
							t
						]
					}),
					/* @__PURE__ */ y("button", {
						type: "button",
						onClick: a,
						children: x("games.magicalathlete.raceHistory")
					}),
					/* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => {
							let t = e.racers.findIndex((e) => e.owner === n), r = w.current;
							t >= 0 && r && j.current?.to(z(t).x + Math.min(e.racers[t].pos, 29) * L - r.clientWidth * .4);
						},
						children: x("games.magicalathlete.backToMe")
					})
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "mag-track-stage",
				children: /* @__PURE__ */ y("div", {
					ref: (e) => {
						w.current = e, T(e);
					},
					className: "mag-track-viewport",
					tabIndex: 0,
					"aria-label": x("games.magicalathlete.trackScroll"),
					children: /* @__PURE__ */ b("div", {
						className: "mag-track-world",
						style: {
							width: le,
							minHeight: ce + I + 22,
							"--mag-runner-size": `${N}px`,
							"--mag-step": `${L}px`,
							"--mag-shear": `${Math.atan(se)}rad`,
							"--mag-head-shift": `${-se * I / 2}px`
						},
						children: [
							/* @__PURE__ */ y("div", {
								className: "mag-track-deck",
								style: {
									left: R,
									top: ce,
									width: 31 * L,
									height: I
								}
							}),
							Array.from({ length: 30 }, (t, n) => /* @__PURE__ */ y(ct, {
								pos: n,
								race: e,
								showCorner: W,
								left: R + n * L,
								top: ce,
								height: I,
								selected: m === n,
								selecting: !!v,
								legal: _?.includes(n) ?? !1,
								impact: ie[n],
								onInspect: () => h(n),
								onSelect: () => v?.(n)
							}, n)),
							e.racers.map((e, t) => {
								let n = z(t);
								return /* @__PURE__ */ y(st, {
									owner: e.owner,
									left: n.x,
									top: n.y
								}, e.owner);
							}),
							e.racers.map((t, n) => {
								if (t.eliminated) return null;
								let r = z(n);
								return /* @__PURE__ */ y(ot, {
									racer: t,
									color: d(t.owner),
									label: f(t.id),
									left: r.x + t.pos * L,
									top: r.y,
									active: t.owner === e.turn && !t.place,
									powered: k && H.some((e) => e.owner === t.owner),
									powerKey: A,
									disabled: !!v && !_?.includes(t.pos),
									onInspect: () => v ? v(t.pos) : g(t.owner)
								}, t.owner);
							})
						]
					})
				})
			}),
			/* @__PURE__ */ y("div", {
				className: `mag-race-news ${k ? "mag-race-news--power" : ""}`,
				role: "status",
				"aria-live": "polite",
				children: H.length ? H.map((e) => /* @__PURE__ */ b("span", { children: [
					/* @__PURE__ */ y("strong", { children: x("games.magicalathlete.powerActivated", { name: x(Y[e.racer]) }) }),
					" · ",
					x(Ve[e.power])
				] }, `${e.owner}:${e.power}`)) : U ? i(U) : x("games.magicalathlete.commentaryTitle")
			})
		]
	});
}
//#endregion
//#region src/games/magicalathlete/race-scene.tsx
function ut({ member: e, score: t, racer: n, color: r, myRid: i, ready: a, active: o }) {
	let s = p(), { ref: c } = l(`seat:${e.rid}`), u = n ? n.eliminated ? s("games.magicalathlete.eliminatedMark") : n.place > 0 ? s("games.magicalathlete.finishPlace", { n: n.place }) : "" : s(a ? "games.magicalathlete.seatReady" : "games.magicalathlete.seatWaiting");
	return /* @__PURE__ */ b("div", {
		ref: c,
		className: `mag-seat ${e.rid === i ? "mag-seat--mine" : ""} ${o ? "mag-seat--active" : ""}`,
		style: { "--player-color": r },
		"aria-current": o ? "true" : void 0,
		children: [
			/* @__PURE__ */ y("span", {
				className: "mag-seat__portrait",
				"aria-hidden": !0,
				children: n ? /* @__PURE__ */ y(X, {
					id: n.id,
					playerColor: r
				}) : e.name.slice(0, 1)
			}),
			/* @__PURE__ */ y("span", {
				className: "mag-seat__name",
				children: e.name
			}),
			/* @__PURE__ */ b("span", {
				className: "mag-seat__score",
				children: ["★ ", /* @__PURE__ */ y(x, {
					value: t,
					className: "font-mono tabular-nums"
				})]
			}),
			/* @__PURE__ */ b("span", {
				className: "mag-seat__position",
				children: [n && /* @__PURE__ */ b("span", {
					className: "mag-seat__racer-name",
					children: [s(Y[n.id]), u ? " · " : ""]
				}), u]
			}),
			a && !n && /* @__PURE__ */ y(Xe, { className: "mag-seat__ready" })
		]
	});
}
function dt({ members: e, race: t, raceNum: n, scores: r, status: i, myRid: a, colorOf: o, readyRids: s, activeRid: c, chip: l }) {
	let u = p();
	return /* @__PURE__ */ b("div", {
		className: "mag-race-head",
		children: [/* @__PURE__ */ b("div", {
			className: "mag-race-head__banner",
			children: [
				/* @__PURE__ */ y("span", {
					className: "mag-race-head__title",
					children: u("games.magicalathlete.name")
				}),
				/* @__PURE__ */ y("span", {
					className: "mag-race-head__status",
					children: i
				}),
				/* @__PURE__ */ y("span", {
					className: "mag-race-head__round",
					children: l ?? u("games.magicalathlete.raceChip", { n })
				})
			]
		}), /* @__PURE__ */ y("div", {
			className: "mag-seats",
			style: { "--mag-seat-count": e.length },
			children: e.map((e) => /* @__PURE__ */ y(ut, {
				member: e,
				score: r[e.rid] ?? 0,
				racer: t?.racers.find((t) => t.owner === e.rid),
				color: o(e.rid),
				myRid: a,
				ready: s?.includes(e.rid),
				active: e.rid === (c ?? t?.turn)
			}, e.rid))
		})]
	});
}
//#endregion
//#region src/games/magicalathlete/racer-card.tsx
function ft({ id: e, selected: t, onTap: n, anchor: r, locked: i, used: a, ownerName: o, playerColor: s, activePower: c }) {
	let u = p(), { ref: d } = l(r ? `card:${e}` : null);
	return /* @__PURE__ */ b("button", {
		ref: d,
		type: "button",
		disabled: !n,
		onClick: n,
		"aria-pressed": t ?? !1,
		className: `mag-racer-card ${t ? "mag-racer-card--selected" : ""} ${a ? "mag-racer-card--used" : ""}`,
		style: {
			"--athlete-background": We(e),
			"--player-color": s
		},
		children: [
			o && /* @__PURE__ */ y("span", {
				className: "mag-racer-card__owner",
				children: o
			}),
			/* @__PURE__ */ y("span", {
				className: "mag-racer-card__name",
				children: u(Y[e])
			}),
			/* @__PURE__ */ y("span", {
				className: "mag-racer-card__stage",
				children: /* @__PURE__ */ y(X, {
					id: e,
					playerColor: s
				})
			}),
			/* @__PURE__ */ b("span", {
				className: "mag-racer-card__power",
				children: [u(Be[e]), c !== void 0 && c !== e && /* @__PURE__ */ b("span", {
					className: "mag-racer-card__active-power",
					children: [/* @__PURE__ */ y("strong", { children: c ? u("games.magicalathlete.cellEffectivePower", { name: u(Y[c]) }) : u("games.magicalathlete.cellNoEffectivePower") }), c && u(Be[c])]
				})]
			}),
			t && /* @__PURE__ */ y(Xe, { className: "mag-racer-card__check" }),
			(i || a) && /* @__PURE__ */ y("span", {
				className: "mag-racer-card__state",
				children: u(a ? "games.magicalathlete.usedUp" : "games.magicalathlete.seatReady")
			})
		]
	});
}
//#endregion
//#region src/games/magicalathlete/racer-choice.tsx
function pt({ title: e, choices: t, colorOf: n, nameOf: r, onCancel: i, cancelLabel: a }) {
	let o = p(), [s, l] = c(null), u = t.find((e) => e.key === s);
	return /* @__PURE__ */ y($e, {
		title: e,
		className: "mag-choice-dialog",
		onCancel: i,
		footer: /* @__PURE__ */ b(v, { children: [i && /* @__PURE__ */ y("button", {
			type: "button",
			className: "mag-secondary-button",
			onClick: i,
			children: a ?? o("games.magicalathlete.decline")
		}), /* @__PURE__ */ y("button", {
			type: "button",
			className: "mag-confirm-button",
			disabled: !u,
			onClick: () => u?.choose(),
			children: u ? o("games.magicalathlete.chooseRacer", { name: o(Y[u.id]) }) : o("games.magicalathlete.pickThis")
		})] }),
		children: /* @__PURE__ */ y("div", {
			className: "mag-choice-grid",
			children: t.map((e) => /* @__PURE__ */ y(ft, {
				id: e.id,
				ownerName: e.owner ? r(e.owner) : void 0,
				playerColor: e.owner ? n(e.owner) : void 0,
				activePower: e.power,
				selected: e.key === s,
				onTap: () => l(e.key)
			}, e.key))
		})
	});
}
//#endregion
//#region src/games/magicalathlete/view-player.tsx
function mt(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ y(ht, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ht({ pub: e, priv: t, members: n, myRid: i, send: a }) {
	let o = p(), s = (e) => n.find((t) => t.rid === e)?.name ?? e, l = (e) => m[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % m.length].hex, u = (e) => o(Y[e]), d = e.race, [f, _] = c(null), [v, x] = c(null), [ee, S] = c(0);
	f && e.raceNum > f.num && ee < f.num && v?.num !== f.num && x({
		...f,
		log: e.log
	}), d && f?.race !== d && _({
		race: d,
		num: e.raceNum
	});
	let C = v?.race ?? d, w = v?.num ?? e.raceNum, T = v?.log ?? e.log, E = v?.num ?? 0, te = r(() => {
		S((e) => Math.max(e, E)), x(null);
	}, [E]), D = v ? null : C?.pending ?? null, O = D !== null && D.who === i, k = !v && e.phase === "race" && C !== null && C.turn === i && !C.busy && D === null, [ne, A] = c(null), [re, ie] = c(null), [ae, j] = c(null), [M, N] = c(!1), [P, F] = c(null), oe = r(() => F(null), []), I = `${e.phase}:${e.raceNum}`, [L, se] = c(I);
	L !== I && (se(I), F(null));
	let R = `${e.phase}:${e.raceNum}:${C?.turn ?? ""}:${D?.kind ?? ""}:${D?.who ?? ""}:${C?.die ?? ""}`, [ce, le] = c(R);
	ce !== R && (le(R), A(null), ie(null), j(null));
	let z = "";
	v ? z = o("games.magicalathlete.raceOver", { n: w }) : e.phase === "draft" && e.draft ? z = e.draft.picker === i ? o("games.magicalathlete.draftPrompt") : o("games.magicalathlete.draftWaiting", { name: s(e.draft.picker) }) : e.phase === "select" ? z = t?.myPick ? o("games.magicalathlete.selectDone") : o("games.magicalathlete.selectPrompt") : e.phase === "done" ? z = o("games.magicalathlete.raceOver", { n: 4 }) : C && (z = C.busy ? o("games.magicalathlete.resolving") : O ? o("games.magicalathlete.prePowerAsk") : D ? o("games.magicalathlete.waitTurn", { name: s(D.who) }) : C.turn === i ? o("games.magicalathlete.yourTurn") : o("games.magicalathlete.turnOf", { name: s(C.turn) }));
	let ue = (e) => {
		switch (e.k) {
			case "draft": return o("games.magicalathlete.logDraft", {
				name: s(e.rid),
				racer: u(e.racer)
			});
			case "raceStart": return o("games.magicalathlete.logRaceStart", {
				n: e.n,
				track: o(e.track === "wild" ? "games.magicalathlete.trackWild" : "games.magicalathlete.trackMild")
			});
			case "select": return o("games.magicalathlete.logSelect");
			case "roll": return o(e.reroll ? "games.magicalathlete.logReroll" : "games.magicalathlete.logRoll", {
				name: s(e.rid),
				n: e.n
			});
			case "move": return o("games.magicalathlete.logMove", {
				racer: u(e.racer),
				n: e.n
			});
			case "trip": return o("games.magicalathlete.logTrip", { racer: u(e.racer) });
			case "points": return o("games.magicalathlete.logPoints", {
				name: s(e.rid),
				n: e.n
			});
			case "elim": return o("games.magicalathlete.logElim", { racer: u(e.racer) });
			case "warp": return o("games.magicalathlete.logWarp", { racer: u(e.racer) });
			case "swap": return o("games.magicalathlete.logSwap", {
				a: u(e.a),
				b: u(e.b)
			});
			case "finish": return o("games.magicalathlete.logFinish", {
				racer: u(e.racer),
				n: e.n
			});
			case "award": return o("games.magicalathlete.logAward", {
				name: s(e.rid),
				medal: o(e.medal === "gold" ? "games.magicalathlete.medalGold" : "games.magicalathlete.medalSilver"),
				n: e.n
			});
			case "duel": return o("games.magicalathlete.logDuel", { a: u(e.a) });
			case "predict": return o("games.magicalathlete.logPredict", {
				name: s(e.rid),
				racer: u(e.racer)
			});
			case "genius": return o("games.magicalathlete.logGenius", {
				name: s(e.rid),
				n: e.n
			});
			case "skip": return o("games.magicalathlete.logSkip", { racer: u(e.racer) });
			case "power": return o("games.magicalathlete.logPower", { racer: u(e.racer) });
		}
	}, B = /* @__PURE__ */ y(dt, {
		members: n,
		raceNum: e.raceNum,
		scores: e.scores,
		status: z,
		myRid: i,
		colorOf: l,
		readyRids: e.select?.picked,
		activeRid: e.draft?.picker,
		chip: e.phase === "draft" && e.draft ? o("games.magicalathlete.draftRound", { n: e.draft.round }) : void 0
	});
	if (e.phase === "draft" && e.draft) return /* @__PURE__ */ y(gt, {
		pub: e,
		myRid: i,
		send: a,
		banner: B
	});
	if (!v && e.phase === "select" && t) return /* @__PURE__ */ y(_t, {
		pub: e,
		priv: t,
		send: a,
		banner: B
	});
	if (!C || !v && e.phase !== "race") return /* @__PURE__ */ y(h, {
		adaptive: !0,
		className: "mag-screen",
		banner: B,
		children: /* @__PURE__ */ y("div", {
			className: "frame grid h-full place-items-center text-4xl",
			children: "🏅"
		})
	});
	let de = C.racers.find((e) => e.owner === i)?.power ?? null, V = O && !C.busy && D?.kind === "prePower" && D.powers.includes("thirdwheel") && re === "thirdwheel", H = V ? Array.from({ length: 30 }, (e, t) => t).filter((e) => C.racers.filter((t) => !t.eliminated && t.place === 0 && t.pos === e).length === 2) : [], U = (e) => {
		F(null), N(!1), ie(e);
	}, W = (e) => a({
		type: "respond",
		...e
	}), fe = (e, t) => {
		let n = C.racers[e];
		return {
			key: n.owner,
			id: n.id,
			owner: n.owner,
			power: n.power,
			choose: t
		};
	}, G = null;
	if (O && D) switch (D.kind) {
		case "egg":
			G = {
				key: "egg",
				title: o("games.magicalathlete.eggAsk"),
				choices: (t?.eggOptions ?? []).map((e) => ({
					key: e,
					id: e,
					choose: () => W({ racerId: e })
				}))
			};
			break;
		case "twin":
			G = {
				key: "twin",
				title: o("games.magicalathlete.twinAsk"),
				choices: D.winners.map((e) => ({
					key: e,
					id: e,
					choose: () => W({ racerId: e })
				})),
				onCancel: () => W({ accept: !1 })
			};
			break;
		case "copycat":
			G = {
				key: "copycat",
				title: o("games.magicalathlete.copycatAsk"),
				choices: D.leaders.map((e) => fe(e, () => W({ racerIdx: e })))
			};
			break;
		case "mastermind":
			G = {
				key: "mastermind",
				title: o("games.magicalathlete.mastermindAsk"),
				choices: C.racers.flatMap((e, t) => e.eliminated ? [] : [fe(t, () => W({ racerIdx: t }))])
			};
			break;
		case "duelist":
			G = {
				key: `duelist:${D.candidates.join(",")}`,
				title: o("games.magicalathlete.duelistAsk", { name: u(C.racers[D.candidates[0]]?.id ?? "egg") }),
				choices: D.candidates.map((e) => fe(e, () => W({
					accept: !0,
					racerIdx: e
				}))),
				onCancel: () => W({ accept: !1 })
			};
			break;
		case "prePower": re === "hypnotist" && (G = {
			key: "hypnotist",
			title: o("games.magicalathlete.useHypnotist"),
			choices: C.racers.flatMap((e, t) => e.eliminated || e.place !== 0 || e.owner === D.who ? [] : [fe(t, () => a({
				type: "prePower",
				power: "hypnotist",
				target: e.id
			}))]),
			onCancel: () => ie(null),
			cancelLabel: o("games.magicalathlete.backToPowers")
		});
	}
	else k && ne === "flipflop" && (G = {
		key: "flipflop",
		title: o("games.magicalathlete.actFlipFlop"),
		choices: C.racers.flatMap((e, t) => e.eliminated || e.place !== 0 || e.owner === i ? [] : [fe(t, () => a({
			type: "altMove",
			kind: "flipflop",
			target: e.id
		}))]),
		onCancel: () => A(null),
		cancelLabel: o("common.close")
	});
	let K = V || G ? null : O && D ? /* @__PURE__ */ y("div", {
		className: "mag-overlay flex max-h-56 flex-col gap-1.5 overflow-y-auto",
		children: /* @__PURE__ */ y(vt, {
			pending: D,
			race: C,
			send: a,
			racerName: u,
			onPreMode: U
		})
	}) : k && ne === "predict" ? /* @__PURE__ */ b("div", {
		className: "mag-overlay flex flex-wrap items-center justify-center gap-1.5",
		children: [
			/* @__PURE__ */ y("span", {
				className: "w-full text-center text-sm font-extrabold",
				children: o("games.magicalathlete.predictPick")
			}),
			[
				1,
				2,
				3,
				4,
				5,
				6
			].map((e) => /* @__PURE__ */ y("button", {
				type: "button",
				onClick: () => {
					j(e), A(null);
				},
				className: "btn-quiet min-h-11 min-w-11 font-mono font-black",
				children: e
			}, e)),
			/* @__PURE__ */ y("button", {
				type: "button",
				onClick: () => {
					j(null), A(null);
				},
				className: "btn-quiet min-h-11 px-2",
				children: o("games.magicalathlete.noPredict")
			})
		]
	}) : null;
	return /* @__PURE__ */ b("div", {
		className: "mag-race relative h-full min-h-0",
		children: [
			/* @__PURE__ */ y(h, {
				adaptive: !0,
				className: "mag-screen",
				banner: /* @__PURE__ */ y(dt, {
					members: n,
					race: C,
					raceNum: w,
					scores: e.scores,
					status: z,
					myRid: i,
					colorOf: l,
					activeRid: v ? "" : void 0
				}),
				actionsHeight: "mag-race-actions-height",
				actions: V ? /* @__PURE__ */ b("div", {
					className: "mag-actions mag-space-actions",
					children: [/* @__PURE__ */ y("strong", { children: o("games.magicalathlete.selectSpacePrompt") }), /* @__PURE__ */ y("button", {
						type: "button",
						className: "mag-secondary-button",
						onClick: () => U(null),
						children: o("games.magicalathlete.backToPowers")
					})]
				}) : /* @__PURE__ */ y(yt, {
					race: C,
					myTurn: k,
					myPending: O,
					pending: D,
					myRid: i,
					send: a,
					predict: ae,
					power: de,
					setPickMode: A,
					nameOf: s,
					finishedNum: v?.num
				}),
				overlay: K,
				scroll: !1,
				children: /* @__PURE__ */ y(lt, {
					race: C,
					raceNum: w,
					myRid: i,
					log: T,
					logLine: ue,
					onOpenLog: () => {
						F(null), N(!0);
					},
					colorOf: l,
					racerName: u,
					selectedPos: P?.kind === "cell" ? P.pos : null,
					onInspectCell: (e) => {
						N(!1), F({
							kind: "cell",
							pos: e
						});
					},
					onInspectRacer: (e) => {
						N(!1), F({
							kind: "racer",
							owner: e
						});
					},
					legalPositions: H,
					onSelectCell: V ? (e) => {
						a({
							type: "prePower",
							power: "thirdwheel",
							space: e
						}), ie(null);
					} : void 0
				}, w)
			}),
			M && /* @__PURE__ */ y(g, {
				log: e.log,
				line: ue,
				onClose: () => N(!1)
			}),
			P !== null && /* @__PURE__ */ y(Qe, {
				race: C,
				inspection: P,
				colorOf: l,
				racerName: u,
				onClose: oe
			}),
			G && /* @__PURE__ */ y(pt, {
				title: G.title,
				choices: G.choices,
				onCancel: G.onCancel,
				cancelLabel: G.cancelLabel,
				colorOf: l,
				nameOf: s
			}, `${w}:${D?.who ?? i}:${G.key}`),
			v && /* @__PURE__ */ y(et, {
				race: v.race,
				raceNum: v.num,
				log: v.log,
				colorOf: l,
				nameOf: s,
				racerName: u,
				onContinue: te
			})
		]
	});
}
function gt({ pub: e, myRid: t, send: n, banner: r }) {
	let i = p(), a = e.draft, [o, s] = c(null), l = `${a?.round}:${a?.picker ?? ""}:${a?.pool.join(",") ?? ""}`, [u, d] = c(l);
	if (u !== l && (d(l), s(null)), !a) return null;
	let f = a.picker === t;
	return /* @__PURE__ */ y(h, {
		adaptive: !0,
		className: "mag-screen mag-selection-screen",
		banner: r,
		actionsHeight: "mag-selection-actions-height",
		actions: /* @__PURE__ */ b("div", {
			className: "mag-actions mag-selection-actions",
			children: [/* @__PURE__ */ y("span", { children: f ? i("games.magicalathlete.draftPrompt") : i("games.magicalathlete.draftRound", { n: a.round }) }), f && /* @__PURE__ */ y("button", {
				type: "button",
				disabled: o === null,
				onClick: () => o && n({
					type: "draftPick",
					racer: o
				}),
				className: "mag-confirm-button",
				children: o ? i("games.magicalathlete.chooseRacer", { name: i(Y[o]) }) : i("games.magicalathlete.pickThis")
			})]
		}),
		children: /* @__PURE__ */ y("div", {
			className: "mag-selection-board mag-draft-grid",
			children: a.pool.map((e) => /* @__PURE__ */ y(ft, {
				id: e,
				anchor: !0,
				selected: o === e,
				onTap: f ? () => s(o === e ? null : e) : void 0
			}, e))
		})
	});
}
function _t({ pub: e, priv: t, send: n, banner: r }) {
	let i = p(), [a, o] = c(null), s = t.myPick !== null, l = t.myHand.filter((e) => !t.myUsed.includes(e));
	return /* @__PURE__ */ y(h, {
		adaptive: !0,
		className: "mag-screen mag-selection-screen",
		banner: r,
		actionsHeight: "mag-selection-actions-height",
		actions: /* @__PURE__ */ y("div", {
			className: "mag-actions mag-selection-actions",
			children: s ? /* @__PURE__ */ y("span", { children: i("games.magicalathlete.selectDone") }) : /* @__PURE__ */ y("button", {
				type: "button",
				disabled: a === null,
				onClick: () => a && n({
					type: "selectRacer",
					racer: a
				}),
				className: "mag-confirm-button",
				children: a ? i("games.magicalathlete.chooseRacer", { name: i(Y[a]) }) : i("games.magicalathlete.pickThis")
			})
		}),
		children: /* @__PURE__ */ b("div", {
			className: "mag-selection-board mag-hand-board",
			children: [
				/* @__PURE__ */ y("p", {
					className: "section-label flex-none",
					children: i("games.magicalathlete.selectTitle", { n: e.raceNum })
				}),
				/* @__PURE__ */ y("div", {
					className: "mag-hand-grid",
					children: l.map((e) => /* @__PURE__ */ y(ft, {
						id: e,
						locked: s && t.myPick === e,
						selected: (s ? t.myPick : a) === e,
						onTap: s ? void 0 : () => o(a === e ? null : e)
					}, e))
				}),
				t.myUsed.length > 0 && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("p", {
					className: "section-label",
					children: i("games.magicalathlete.usedUp")
				}), /* @__PURE__ */ y("div", {
					className: "mag-hand-grid",
					children: t.myUsed.map((e) => /* @__PURE__ */ y(ft, {
						id: e,
						used: !0
					}, e))
				})] })
			]
		})
	});
}
function vt({ pending: e, race: t, send: n, racerName: r, onPreMode: i }) {
	let a = p(), o = (e) => n({
		type: "respond",
		accept: e
	}), s = (e) => /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("p", {
		className: "text-center text-xs leading-5 font-bold",
		children: e
	}), /* @__PURE__ */ b("div", {
		className: "mt-auto grid grid-cols-2 gap-1.5",
		children: [/* @__PURE__ */ y("button", {
			type: "button",
			onClick: () => o(!0),
			className: "btn-base flex min-h-12 items-center justify-center text-white",
			style: { background: O.accent },
			children: a("games.magicalathlete.accept")
		}), /* @__PURE__ */ y("button", {
			type: "button",
			onClick: () => o(!1),
			className: "btn-quiet flex min-h-12 items-center justify-center",
			children: a("games.magicalathlete.decline")
		})]
	})] });
	switch (e.kind) {
		case "alchemist": return s(a("games.magicalathlete.alchemistAsk", { n: e.die }));
		case "rocket": return s(a("games.magicalathlete.rocketAsk", {
			n: e.die,
			m: e.die * 2
		}));
		case "magician": return s(a("games.magicalathlete.magicianAsk", { n: e.die }));
		case "dicemonger": return s(a("games.magicalathlete.dicemongerAsk", { n: e.die }));
		case "suckerfish": return s(a("games.magicalathlete.suckerfishAsk", { name: t.racers[e.mover] ? r(t.racers[e.mover].id) : "" }));
		case "prePower": {
			let r = Array.from({ length: 30 }, (e, t) => t).some((e) => t.racers.filter((t) => !t.eliminated && t.place === 0 && t.pos === e).length === 2);
			return /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ y("p", {
					className: "text-center text-xs leading-5 font-bold",
					children: a("games.magicalathlete.prePowerAsk")
				}),
				/* @__PURE__ */ b("div", {
					className: "flex flex-col gap-1.5",
					children: [
						e.powers.includes("cheerleader") && /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => n({
								type: "prePower",
								power: "cheerleader"
							}),
							className: "btn-quiet flex min-h-11 items-center justify-center gap-1",
							children: ["📣 ", a("games.magicalathlete.useCheerleader")]
						}),
						e.powers.includes("hypnotist") && /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => i("hypnotist"),
							className: "btn-quiet flex min-h-11 items-center justify-center gap-1",
							children: ["🌀 ", a("games.magicalathlete.useHypnotist")]
						}),
						e.powers.includes("thirdwheel") && /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => i("thirdwheel"),
							disabled: !r,
							className: "btn-quiet flex min-h-11 items-center justify-center gap-1 disabled:opacity-40",
							children: ["🛞 ", a("games.magicalathlete.useThirdWheel")]
						})
					]
				}),
				/* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => n({
						type: "prePower",
						power: "none"
					}),
					className: "btn-quiet mt-auto flex min-h-11 items-center justify-center",
					children: a("games.magicalathlete.decline")
				})
			] });
		}
		default: return null;
	}
}
function yt({ race: e, myTurn: t, myPending: n, pending: r, myRid: i, send: a, predict: o, power: s, setPickMode: c, nameOf: u, finishedNum: d }) {
	let f = p(), { ref: m, hidden: h } = l("dice"), g = t && e.step === "rollChoice", _ = d ? f("games.magicalathlete.raceOver", { n: d }) : n ? f("games.magicalathlete.respondAbove") : e.busy ? f("games.magicalathlete.resolving") : r ? f("games.magicalathlete.waitTurn", { name: u(r.who) }) : g ? f("games.magicalathlete.yourTurn") : f("games.magicalathlete.turnOf", { name: u(e.turn) });
	return /* @__PURE__ */ b("div", {
		className: "mag-actions",
		children: [/* @__PURE__ */ b("div", {
			className: "mag-actions__label",
			children: [/* @__PURE__ */ y("span", { children: g ? `${u(i)} · ${f("games.magicalathlete.yourTurn")}` : _ }), /* @__PURE__ */ b("span", { children: [
				g && s === "genius" && /* @__PURE__ */ b("button", {
					type: "button",
					onClick: () => c("predict"),
					children: [
						f("games.magicalathlete.actPredict"),
						o === null ? "" : ` ${o}`,
						" ›"
					]
				}),
				g && s === "flipflop" && /* @__PURE__ */ b("button", {
					type: "button",
					onClick: () => c("flipflop"),
					children: [f("games.magicalathlete.actFlipFlop"), " ›"]
				}),
				g && s === "legs" && /* @__PURE__ */ b("button", {
					type: "button",
					onClick: () => a({
						type: "altMove",
						kind: "legs"
					}),
					children: [f("games.magicalathlete.actLegs"), " ›"]
				})
			] })]
		}), /* @__PURE__ */ b("button", {
			type: "button",
			disabled: !g,
			onClick: () => a({
				type: "roll",
				...o === null ? {} : { predict: o }
			}),
			className: "mag-actions__button",
			children: [/* @__PURE__ */ y("span", {
				ref: m,
				"aria-hidden": !0,
				className: "mag-die",
				style: { visibility: h ? "hidden" : void 0 },
				children: /* @__PURE__ */ y(Ze, { value: e.die })
			}), g ? f("games.magicalathlete.actRoll") : _]
		})]
	});
}
//#endregion
//#region src/games/magicalathlete/bot.ts
function bt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function xt(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 100 < e * 100;
}
var St = (e, t) => {
	let n = e.public, r = e.private, i = t.rid;
	if (n.phase === "draft" && n.draft) return n.draft.picker !== i || n.draft.pool.length === 0 ? null : { action: {
		type: "draftPick",
		racer: bt(n.draft.pool)
	} };
	if (n.phase === "select") {
		if (!r || r.myPick) return null;
		let e = r.myHand.filter((e) => !r.myUsed.includes(e));
		return e.length === 0 ? null : { action: {
			type: "selectRacer",
			racer: bt(e)
		} };
	}
	let a = n.race;
	if (n.phase !== "race" || !a) return null;
	let o = a.pending;
	if (o) {
		if (o.who !== i) return null;
		switch (o.kind) {
			case "prePower": {
				let e = a.racers.findIndex((e) => e.owner === i), t = a.racers.map((e, t) => ({
					rc: e,
					i: t
				})).filter(({ rc: e }) => !e.eliminated && e.place === 0), n = Math.max(...t.map(({ rc: e }) => e.pos));
				if (o.powers.includes("hypnotist")) {
					let r = t.find(({ rc: t, i: r }) => r !== e && t.pos === n);
					if (r && r.rc.pos > (a.racers[e]?.pos ?? 0)) return { action: {
						type: "prePower",
						power: "hypnotist",
						target: r.rc.id
					} };
				}
				if (o.powers.includes("cheerleader")) {
					let n = Math.min(...t.map(({ rc: e }) => e.pos));
					if (e >= 0 && a.racers[e].pos === n) return { action: {
						type: "prePower",
						power: "cheerleader"
					} };
				}
				if (o.powers.includes("thirdwheel") && xt(.5)) {
					let e = Array.from({ length: 30 }, (e, t) => t).find((e) => t.filter(({ rc: t }) => t.pos === e).length === 2);
					if (e !== void 0) return { action: {
						type: "prePower",
						power: "thirdwheel",
						space: e
					} };
				}
				return { action: {
					type: "prePower",
					power: "none"
				} };
			}
			case "alchemist": return { action: {
				type: "respond",
				accept: !0
			} };
			case "magician":
			case "dicemonger": return { action: {
				type: "respond",
				accept: o.die <= 2
			} };
			case "rocket": {
				let e = a.racers.find((e) => e.owner === i), t = Math.max(...a.racers.filter((e) => !e.eliminated && e.place === 0).map((e) => e.pos));
				return { action: {
					type: "respond",
					accept: (e?.pos ?? 99) < t
				} };
			}
			case "suckerfish": {
				let e = a.racers[o.mover], t = a.racers.find((e) => e.owner === i);
				return { action: {
					type: "respond",
					accept: e !== void 0 && t !== void 0 && o.dest > t.pos
				} };
			}
			case "duelist": return { action: {
				type: "respond",
				accept: xt(.5),
				racerIdx: bt(o.candidates)
			} };
			case "copycat": return { action: {
				type: "respond",
				racerIdx: bt(o.leaders)
			} };
			case "mastermind": return { action: {
				type: "respond",
				racerIdx: a.racers.map((e, t) => ({
					rc: e,
					i: t
				})).filter(({ rc: e }) => !e.eliminated).reduce((e, t) => t.rc.pos > e.rc.pos ? t : e).i
			} };
			case "egg": {
				let e = r?.eggOptions ?? [];
				return e.length === 0 ? null : { action: {
					type: "respond",
					racerId: bt(e)
				} };
			}
			case "twin": return o.winners.length === 0 || xt(.3) ? { action: {
				type: "respond",
				accept: !1
			} } : { action: {
				type: "respond",
				racerId: bt(o.winners)
			} };
		}
	}
	if (a.busy || a.turn !== i || a.step !== "rollChoice") return null;
	let s = a.racers.find((e) => e.owner === i);
	if (!s) return null;
	if (s.power === "legs") return { action: {
		type: "altMove",
		kind: "legs"
	} };
	if (s.power === "flipflop") {
		let e = a.racers.find((e) => !e.eliminated && e.place === 0 && e.owner !== i && e.pos - s.pos >= 6);
		if (e) return { action: {
			type: "altMove",
			kind: "flipflop",
			target: e.id
		} };
	}
	return s.power === "genius" ? { action: {
		type: "roll",
		predict: 4
	} } : { action: { type: "roll" } };
}, Ct = (e, t, n) => e.type === "roll" ? n("games.magicalathlete.actRoll") : e.type === "altMove" ? n(e.kind === "legs" ? "games.magicalathlete.actLegs" : "games.magicalathlete.actFlipFlop") : e.type === "prePower" && e.power === "none" ? n("games.magicalathlete.decline") : e.type === "respond" && e.accept === !0 ? n("games.magicalathlete.accept") : e.type === "respond" && e.accept === !1 ? n("games.magicalathlete.decline") : e.type === "draftPick" || e.type === "selectRacer" ? n("games.magicalathlete.pickThis") : "";
//#endregion
//#region src/games/magicalathlete/fx.tsx
function wt(e, t, n = 24) {
	let r = e.anchor(`cell:${Math.max(0, Math.min(t, 29))}`);
	if (!r) return null;
	let i = n;
	return {
		x: r.x + r.w / 2 - i / 2,
		y: r.y + r.h / 2 - i / 2,
		w: i,
		h: i
	};
}
function Z(e, t, n) {
	let r = n ? e.anchor(`lane:${n}`) : null, i = e.anchor("cell:0"), a = e.anchor(`cell:${Math.max(0, Math.min(t, 29))}`), o = t >= 30 ? e.anchor("cell:1") : null;
	if (r && i && a) return {
		...r,
		x: r.x + a.x - i.x + (o ? (o.x - i.x) * (t - 30 + 1) : 0)
	};
	let s = n ? e.anchor(`pawn:${n}`) : null;
	return wt(e, t, s ? Math.min(s.w, s.h) : 24);
}
function Q(e) {
	return k.includes(e) ? e : "egg";
}
function $(e, t) {
	let n = t ? e.member(t) : void 0;
	return m[(n?.colorIndex ?? 0) % m.length].hex;
}
function Tt({ from: e, to: t, owner: n, ctx: r, ms: i, racer: a, color: c, running: d = !0, follow: f = !0 }) {
	let p = s(null), m = s(null), { ref: h } = l(n ? `motion:${n}` : null), g = u();
	return o(() => {
		let a = p.current, o = m.current;
		if (!a || !o) return;
		let s = it(g), c = performance.now(), l = 0, u = (d) => {
			let p = Math.min(1, (d - c) / i), m = p * p * (3 - 2 * p), h = e + (t - e) * m;
			f && s?.follow(h, n, m);
			let g = Z(r, e, n), _ = Z(r, t, n), v = r.anchor("mag-viewport");
			g && _ && v && (Object.assign(a.style, {
				left: `${v.x}px`,
				top: `${v.y}px`,
				width: `${v.w}px`,
				height: `${v.h}px`
			}), Object.assign(o.style, {
				width: `${g.w}px`,
				height: `${g.h}px`,
				transform: `translate(${g.x + (_.x - g.x) * m - v.x}px, ${g.y + (_.y - g.y) * m - v.y}px)`
			}), o.classList.toggle("mag-motion--power", !!(n && s?.powered(n))), m < 1 ? l = requestAnimationFrame(u) : f && s?.release());
		};
		return u(c), () => {
			cancelAnimationFrame(l), f && s?.release();
		};
	}, [
		g,
		r,
		e,
		t,
		n,
		i,
		f
	]), /* @__PURE__ */ y("div", {
		ref: p,
		className: "absolute overflow-hidden pointer-events-none",
		children: /* @__PURE__ */ b("div", {
			ref: (e) => {
				m.current = e, h(e);
			},
			className: "absolute left-0 top-0 mag-motion",
			style: { color: c },
			children: [/* @__PURE__ */ b("span", {
				className: "mag-power-rings",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ y("i", {}), /* @__PURE__ */ y("i", {})]
			}), /* @__PURE__ */ y(at, {
				racer: a,
				color: c,
				running: d
			})]
		})
	});
}
function Et({ pos: e, ms: t }) {
	let n = u();
	return o(() => {
		it(n)?.flash(e, t);
	}, [
		n,
		e,
		t
	]), null;
}
function Dt({ cues: e, delay: t }) {
	let n = u();
	return o(() => {
		let r = it(n), i = 0, a = window.setTimeout(() => {
			r?.power(e, !0);
			let t = !1, n = () => {
				let a = e[0];
				!t && a && (t = r?.focusPower(a.pos, a.owner) ?? !1), i = requestAnimationFrame(n);
			};
			n();
		}, t);
		return () => {
			clearTimeout(a), cancelAnimationFrame(i);
		};
	}, [
		n,
		e,
		t
	]), null;
}
function Ot(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
var kt = {
	diceRoll: S(),
	power(e) {
		let t = e.data;
		return t?.cues?.length ? {
			ms: t.ms ?? 300,
			node: /* @__PURE__ */ y(Dt, {
				cues: t.cues,
				delay: t.delay ?? 0
			})
		} : null;
	},
	move(e, t) {
		let n = e.data;
		if (typeof n?.from != "number" || typeof n.to != "number") return null;
		let r = Math.max(0, Math.min(n.from, 30)), i = Math.max(0, Math.min(n.to, 30));
		if (!Z(t, r, e.rid)) return null;
		let a = e.rid ? t.anchor(`pawn:${e.rid}`) : null, o = R.move(n.to - n.from);
		return {
			ms: o,
			hide: e.rid && a ? [`pawn:${e.rid}`] : void 0,
			node: /* @__PURE__ */ y(Tt, {
				from: r,
				to: i,
				owner: e.rid,
				ctx: t,
				ms: o - 100,
				racer: Q(n.racer),
				color: $(t, e.rid)
			})
		};
	},
	trip(e, t) {
		let n = e.data, r = typeof n?.pos == "number" ? t.anchor(`cell:${n.pos}`) : null;
		return r ? {
			ms: R.trip,
			node: /* @__PURE__ */ b(v, { children: [typeof n?.pos == "number" && /* @__PURE__ */ y(Et, {
				pos: n.pos,
				ms: R.trip
			}), /* @__PURE__ */ y(w, {
				at: r,
				ms: R.trip,
				children: /* @__PURE__ */ b("span", {
					className: "flex items-center rounded border-2 border-ink bg-pink-300 p-1",
					children: [/* @__PURE__ */ y(X, {
						id: Q(n?.racer),
						playerColor: $(t, e.rid),
						className: "size-8"
					}), /* @__PURE__ */ y(Ge, { className: "size-5" })]
				})
			})] })
		} : null;
	},
	points(e, t) {
		let n = e.data;
		if (typeof n?.n != "number") return null;
		let r = Ot(t, e.rid);
		return r ? {
			ms: R.points,
			node: /* @__PURE__ */ y(w, {
				at: r,
				ms: R.points,
				children: /* @__PURE__ */ b("span", {
					className: n.n > 0 ? "text-done-ink" : "text-danger-ink",
					children: [
						n.n > 0 ? "+" : "",
						n.n,
						" ⭐"
					]
				})
			})
		} : null;
	},
	elim(e, t) {
		let n = e.data, r = typeof n?.pos == "number" ? t.anchor(`cell:${n.pos}`) : null;
		return r ? {
			ms: R.elim,
			node: /* @__PURE__ */ b(v, { children: [typeof n?.pos == "number" && /* @__PURE__ */ y(Et, {
				pos: n.pos,
				ms: R.elim
			}), /* @__PURE__ */ y(w, {
				at: r,
				ms: R.elim,
				children: /* @__PURE__ */ b("span", {
					className: "flex items-center rounded border-2 border-ink bg-surface p-1",
					children: [/* @__PURE__ */ y(X, {
						id: Q(n?.racer),
						playerColor: $(t, e.rid),
						className: "size-8"
					}), /* @__PURE__ */ y("span", {
						"aria-hidden": !0,
						children: "×"
					})]
				})
			})] })
		} : null;
	},
	warp(e, t) {
		let n = e.data;
		if (typeof n?.to != "number") return null;
		let r = e.rid ? t.anchor(`pawn:${e.rid}`) : null, i = r ?? Z(t, n.to, e.rid);
		if (!i) return null;
		let a = typeof n.from == "number" ? Z(t, n.from, e.rid) : null;
		return {
			ms: R.warp,
			hide: a && r && e.rid ? [`pawn:${e.rid}`] : void 0,
			node: /* @__PURE__ */ b(v, { children: [a && /* @__PURE__ */ y(Tt, {
				from: typeof n.from == "number" ? n.from : n.to,
				to: n.to,
				owner: e.rid,
				ctx: t,
				ms: R.warp - 120,
				racer: Q(n.racer),
				color: $(t, e.rid),
				running: !1
			}), /* @__PURE__ */ y(E, {
				at: {
					x: i.x - 4,
					y: i.y - 4,
					w: i.w + 8,
					h: i.h + 8
				},
				ms: R.warp
			})] })
		};
	},
	swap(e, t) {
		let n = e.data;
		if (typeof n?.aPos != "number" || typeof n.bPos != "number") return null;
		let r = Z(t, n.aPos, e.rid), i = Z(t, n.bPos, typeof n.bOwner == "string" ? n.bOwner : void 0);
		if (!r || !i) return null;
		let a = e.rid ? t.anchor(`pawn:${e.rid}`) : null, o = typeof n.bOwner == "string" ? t.anchor(`pawn:${n.bOwner}`) : null;
		return {
			ms: R.swap,
			hide: [e.rid && a ? `pawn:${e.rid}` : null, typeof n.bOwner == "string" && o ? `pawn:${n.bOwner}` : null].filter((e) => e !== null),
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(Tt, {
				from: n.aPos,
				to: n.bPos,
				owner: e.rid,
				ctx: t,
				ms: R.swap - 120,
				racer: Q(n.aRacer),
				color: $(t, e.rid),
				running: !1
			}), /* @__PURE__ */ y(Tt, {
				from: n.bPos,
				to: n.aPos,
				owner: typeof n.bOwner == "string" ? n.bOwner : void 0,
				ctx: t,
				ms: R.swap - 120,
				racer: Q(n.bRacer),
				color: $(t, typeof n.bOwner == "string" ? n.bOwner : void 0),
				running: !1,
				follow: !1
			})] })
		};
	},
	finish(e, t) {
		let n = e.data, r = Ot(t, e.rid);
		return r ? {
			ms: 900,
			node: /* @__PURE__ */ y(w, {
				at: r,
				ms: 900,
				children: /* @__PURE__ */ y("span", {
					className: "text-xl",
					children: n?.place === 1 ? "🥇" : "🥈"
				})
			})
		} : null;
	},
	award(e, t) {
		let n = e.data, r = Ot(t, e.rid);
		return r ? {
			ms: 1e3,
			node: /* @__PURE__ */ y(w, {
				at: r,
				ms: 1e3,
				children: /* @__PURE__ */ b("span", {
					className: "font-mono font-black text-amber-600 tabular-nums",
					children: [
						n?.medal === "gold" ? "🥇" : "🥈",
						" +",
						typeof n?.n == "number" ? n.n : 0
					]
				})
			})
		} : null;
	},
	duel(e, t) {
		let n = e.data;
		if (typeof n?.ra != "number" || typeof n.rb != "number") return null;
		let r = typeof n.pos == "number" ? t.anchor(`cell:${n.pos}`) : Ot(t, e.rid);
		return r ? {
			ms: R.duel,
			node: /* @__PURE__ */ y(w, {
				at: r,
				ms: R.duel,
				children: /* @__PURE__ */ b("span", {
					className: "rounded-lg border-2 border-ink bg-surface px-1.5 py-0.5 font-mono text-sm font-black shadow-[2px_2px_0_var(--color-ink)]",
					children: [
						"⚔️ ",
						n.ra,
						":",
						n.rb
					]
				})
			})
		} : null;
	},
	draft(e, t) {
		let n = e.data;
		if (typeof n?.racer != "string") return null;
		let r = t.anchor(`card:${n.racer}`), i = Ot(t, e.rid);
		return !r || !i ? null : {
			ms: 500,
			node: /* @__PURE__ */ y(T, {
				from: r,
				to: i,
				ms: 420,
				children: /* @__PURE__ */ y("span", {
					className: "grid size-7 place-items-center rounded-md border-2 border-ink bg-surface text-base shadow-[2px_2px_0_var(--color-ink)]",
					children: /* @__PURE__ */ y(X, {
						id: Q(n.racer),
						playerColor: $(t, e.rid),
						className: "size-full"
					})
				})
			})
		};
	},
	selectPick(e, t) {
		let n = Ot(t, e.rid);
		return n ? {
			ms: 420,
			node: /* @__PURE__ */ y(E, {
				at: n,
				ms: 420
			})
		} : null;
	},
	raceStart() {
		return {
			ms: 600,
			node: /* @__PURE__ */ y(C, {
				ms: 600,
				className: "bg-amber-200/50"
			})
		};
	},
	skip(e, t) {
		let n = e.data, r = typeof n?.pos == "number" ? t.anchor(`cell:${n.pos}`) : Ot(t, e.rid);
		return r ? {
			ms: R.skip,
			node: /* @__PURE__ */ y(w, {
				at: r,
				ms: R.skip,
				children: /* @__PURE__ */ b("span", {
					className: "flex items-center rounded border border-ink bg-surface p-1",
					children: [/* @__PURE__ */ y(X, {
						id: Q(n?.racer),
						playerColor: $(t, e.rid),
						className: "size-8"
					}), /* @__PURE__ */ y("span", {
						"aria-hidden": !0,
						children: "⏸"
					})]
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/magicalathlete/game-over-art.tsx
function At({ kind: e }) {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 30 44",
		"aria-hidden": "true",
		focusable: "false",
		className: `mag-finale-medal mag-finale-medal--${e}`,
		children: [
			/* @__PURE__ */ y("path", {
				d: "M4 1h8l5 17-8 4ZM18 1h8l-5 21-8-4Z",
				className: "mag-finale-medal__ribbon"
			}),
			/* @__PURE__ */ y("circle", {
				cx: "15",
				cy: "28",
				r: "12",
				className: "mag-finale-medal__coin"
			}),
			/* @__PURE__ */ y("text", {
				x: "15",
				y: "33",
				textAnchor: "middle",
				children: e === "gold" ? 1 : 2
			})
		]
	});
}
function jt() {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 100 110",
		"aria-hidden": "true",
		focusable: "false",
		className: "mag-finale-trophy",
		children: /* @__PURE__ */ b("g", {
			stroke: "currentColor",
			strokeWidth: "3",
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ y("path", {
					d: "M24 18H7v21q0 21 28 23m41-44h17v21q0 21-28 23",
					fill: "none"
				}),
				/* @__PURE__ */ y("path", {
					d: "M19 9h62l-5 40Q73 66 58 72v20h15v11H27V92h15V72Q27 66 24 49Z",
					className: "mag-finale-trophy__cup"
				}),
				/* @__PURE__ */ y("path", {
					d: "M28 17h10l-2 37-9-5Z",
					className: "mag-finale-trophy__shine",
					stroke: "none"
				}),
				/* @__PURE__ */ y("path", {
					d: "m50 25 5 11 12 1-9 8 3 13-11-7-11 7 3-13-9-8 12-1Z",
					className: "mag-finale-trophy__star",
					strokeWidth: "2"
				})
			]
		})
	});
}
function Mt() {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 500 70",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		focusable: "false",
		className: "mag-finale-flags",
		children: [/* @__PURE__ */ y("path", {
			d: "M5 6Q250 70 495 6",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2"
		}), Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ y("path", {
			d: "m0 0 19 5-12 25Z",
			transform: `translate(${8 + t * 59} ${7 + 26 * Math.sin(t / 8 * Math.PI)})`,
			className: `mag-finale-flag mag-finale-flag--${t % 3}`
		}, t))]
	});
}
//#endregion
//#region src/games/magicalathlete/game-over.tsx
function Nt(e) {
	let t = p(), n = f((e) => e.locale), r = e.public, i = r.results ?? [], [a, o] = c(null), s = (t) => {
		let r = e.members.find((e) => e.rid === t);
		return r ? te(t) === null ? r.name : d(n, r.avatar) : t;
	}, l = (t) => m[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % m.length].hex, u = (t) => e.result.scores?.[t] ?? r.scores[t] ?? 0, g = e.result.winner.length > 1, _ = (e, t) => o({
		round: e,
		racer: t
	}), v = e.onPlayAgain || e.onBackToLobby;
	return /* @__PURE__ */ b("div", {
		className: "mag-over mag-finale",
		children: [
			/* @__PURE__ */ y(D, {}),
			/* @__PURE__ */ y(h, {
				adaptive: !0,
				className: "mag-finale-screen",
				actionsHeight: "mag-finale-actions-height",
				banner: /* @__PURE__ */ b("header", {
					className: "mag-finale-heading",
					children: [
						/* @__PURE__ */ y("h1", { children: t("games.magicalathlete.name") }),
						/* @__PURE__ */ y("span", { children: t("games.magicalathlete.finaleTitle") }),
						e.hintCount !== void 0 && /* @__PURE__ */ y("small", { children: t("session.hint.usedCount", { n: e.hintCount }) })
					]
				}),
				actions: /* @__PURE__ */ y("footer", {
					className: "mag-finale-actions safe-b",
					children: v ? /* @__PURE__ */ b("div", { children: [e.onBackToLobby && /* @__PURE__ */ y("button", {
						type: "button",
						className: "mag-finale-back",
						onClick: e.onBackToLobby,
						children: t("session.result.backToLobby")
					}), e.onPlayAgain && /* @__PURE__ */ y("button", {
						type: "button",
						className: "mag-finale-again",
						onClick: e.onPlayAgain,
						children: t("session.result.playAgain")
					})] }) : /* @__PURE__ */ y("p", { children: t("session.result.waitHost") })
				}),
				children: /* @__PURE__ */ b("div", {
					className: "mag-finale-main",
					"data-shared": g,
					children: [/* @__PURE__ */ y("section", {
						className: "mag-finale-stage",
						"aria-label": t(g ? "games.magicalathlete.finaleShared" : "games.magicalathlete.finaleChampion"),
						children: e.result.winner.map((e) => /* @__PURE__ */ b("div", {
							className: "mag-finale-winner",
							style: { "--player-color": l(e) },
							children: [
								/* @__PURE__ */ y(Mt, {}),
								/* @__PURE__ */ y("strong", {
									className: "mag-finale-crown",
									children: t(g ? "games.magicalathlete.finaleShared" : "games.magicalathlete.finaleChampion")
								}),
								/* @__PURE__ */ y("h2", { children: s(e) }),
								/* @__PURE__ */ b("div", {
									className: "mag-finale-winning-score",
									children: [/* @__PURE__ */ y("strong", { children: u(e) }), /* @__PURE__ */ y("span", { children: t("games.magicalathlete.finalePoints") })]
								}),
								/* @__PURE__ */ y(jt, {}),
								/* @__PURE__ */ y(Pt, {
									rounds: i,
									rid: e
								}),
								/* @__PURE__ */ y("div", {
									className: "mag-finale-team",
									children: i.map((n) => {
										let r = n.racers.find((t) => t.owner === e);
										return r && /* @__PURE__ */ b("button", {
											type: "button",
											onClick: () => _(n, r),
											"aria-label": t("games.magicalathlete.finaleInspect", {
												n: n.num,
												name: t(Y[r.id])
											}),
											children: [/* @__PURE__ */ y(X, {
												id: r.id,
												playerColor: l(e),
												normalized: !0
											}), /* @__PURE__ */ y("span", { children: t(Y[r.id]) })]
										}, n.num);
									})
								}),
								/* @__PURE__ */ y("div", {
									className: "mag-finale-stage-line",
									"aria-hidden": "true"
								})
							]
						}, e))
					}), /* @__PURE__ */ b("section", {
						className: "mag-finale-board",
						"aria-labelledby": "mag-finale-results-title",
						children: [
							/* @__PURE__ */ b("div", {
								className: "mag-finale-board-heading",
								children: [/* @__PURE__ */ y("h2", {
									id: "mag-finale-results-title",
									children: t("games.magicalathlete.finaleStandings")
								}), /* @__PURE__ */ y("span", { children: t("games.magicalathlete.finalePlayers", { n: e.result.ranking.length }) })]
							}),
							i.length === 0 && /* @__PURE__ */ y("p", {
								className: "mag-finale-missing",
								children: t("games.magicalathlete.finaleMissing")
							}),
							/* @__PURE__ */ y("div", {
								className: "mag-finale-track-schedule",
								children: t("games.magicalathlete.finaleSchedule")
							}),
							/* @__PURE__ */ b("div", {
								className: "mag-finale-columns",
								"aria-hidden": "true",
								children: [
									/* @__PURE__ */ y("span", { children: t("games.magicalathlete.finalePlayer") }),
									[
										1,
										2,
										3,
										4
									].map((e) => /* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y("strong", { children: t("games.magicalathlete.finaleRound", { n: e }) }), /* @__PURE__ */ y("small", { children: t(e % 2 ? "games.magicalathlete.trackMild" : "games.magicalathlete.trackWild") })] }, e)),
									/* @__PURE__ */ y("span", { children: t("games.magicalathlete.finaleTotal") })
								]
							}),
							/* @__PURE__ */ y("ol", {
								className: "mag-finale-standings",
								children: e.result.ranking.map((n) => {
									let r = e.result.ranking.findIndex((e) => u(e) === u(n)) + 1, a = e.result.autopilot?.[n];
									return /* @__PURE__ */ b("li", {
										className: "mag-finale-player",
										"data-winner": e.result.winner.includes(n),
										style: { "--player-color": l(n) },
										children: [
											/* @__PURE__ */ b("div", {
												className: "mag-finale-player-head",
												children: [/* @__PURE__ */ y("strong", {
													className: "mag-finale-rank",
													children: r
												}), /* @__PURE__ */ b("div", {
													className: "mag-finale-player-identity",
													children: [
														/* @__PURE__ */ b("strong", { children: [s(n), n === e.myRid && /* @__PURE__ */ y("span", {
															className: "mag-finale-you",
															children: t("lobby.you")
														})] }),
														/* @__PURE__ */ y(Pt, {
															rounds: i,
															rid: n
														}),
														a !== void 0 && a > 0 && /* @__PURE__ */ y("small", { children: t("session.autopilot.share", { n: Math.round(a * 100) }) })
													]
												})]
											}),
											/* @__PURE__ */ y("div", {
												className: "mag-finale-rounds",
												children: [
													1,
													2,
													3,
													4
												].map((e) => {
													let r = i.find((t) => t.num === e), a = r?.racers.find((e) => e.owner === n);
													return /* @__PURE__ */ b("div", {
														className: "mag-finale-round",
														children: [/* @__PURE__ */ y("span", {
															className: "mag-finale-round-number",
															children: t("games.magicalathlete.finaleRound", { n: e })
														}), r && a ? /* @__PURE__ */ b("button", {
															type: "button",
															className: "mag-finale-race",
															onClick: () => _(r, a),
															"aria-label": t("games.magicalathlete.finaleInspect", {
																n: e,
																name: t(Y[a.id])
															}),
															children: [
																/* @__PURE__ */ y(X, {
																	id: a.id,
																	playerColor: l(n),
																	normalized: !0
																}),
																/* @__PURE__ */ y("strong", {
																	className: "mag-finale-racer-name",
																	children: t(Y[a.id])
																}),
																/* @__PURE__ */ y(Ft, { racer: a }),
																/* @__PURE__ */ y("strong", {
																	className: "mag-finale-race-points",
																	children: a.points
																}),
																/* @__PURE__ */ y("span", {
																	className: "mag-finale-breakdown",
																	children: t("games.magicalathlete.finaleBreakdown", {
																		medal: a.medalPoints,
																		other: It(a.gained - a.lost)
																	})
																})
															]
														}) : /* @__PURE__ */ y("span", {
															className: "mag-finale-no-race",
															"aria-label": t("games.magicalathlete.finaleMissingRace"),
															children: "—"
														})]
													}, e);
												})
											}),
											/* @__PURE__ */ b("div", {
												className: "mag-finale-total",
												children: [/* @__PURE__ */ y("strong", { children: u(n) }), /* @__PURE__ */ y("span", { children: t("games.magicalathlete.finalePoints") })]
											})
										]
									}, n);
								})
							})
						]
					})]
				})
			}),
			a && /* @__PURE__ */ b($e, {
				title: t(Y[a.racer.id]),
				className: "mag-finale-detail",
				onCancel: () => o(null),
				footer: /* @__PURE__ */ y("button", {
					type: "button",
					className: "mag-confirm-button",
					onClick: () => o(null),
					children: t("games.magicalathlete.finaleClose")
				}),
				children: [
					/* @__PURE__ */ y(X, {
						id: a.racer.id,
						playerColor: l(a.racer.owner),
						normalized: !0,
						className: "mag-finale-detail-art"
					}),
					/* @__PURE__ */ b("p", {
						className: "mag-finale-detail-owner",
						children: [
							s(a.racer.owner),
							" · ",
							t("games.magicalathlete.finaleRound", { n: a.round.num }),
							" · ",
							t(a.round.track === "mild" ? "games.magicalathlete.trackMild" : "games.magicalathlete.trackWild")
						]
					}),
					/* @__PURE__ */ y(Ft, { racer: a.racer }),
					/* @__PURE__ */ y("p", {
						className: "mag-finale-detail-score",
						children: t("games.magicalathlete.finaleDetailedScore", {
							medal: a.racer.medalPoints,
							gained: a.racer.gained,
							lost: a.racer.lost,
							total: a.racer.points
						})
					}),
					/* @__PURE__ */ y("p", {
						className: "mag-finale-detail-power",
						children: t(Be[a.racer.id])
					}),
					a.racer.copied && /* @__PURE__ */ b("div", {
						className: "mag-finale-detail-copy",
						children: [/* @__PURE__ */ y("strong", { children: t("games.magicalathlete.finaleCopied", { name: t(Y[a.racer.copied]) }) }), /* @__PURE__ */ y("p", { children: t(Be[a.racer.copied]) })]
					})
				]
			})
		]
	});
}
function Pt({ rounds: e, rid: t }) {
	let n = p(), r = e.flatMap((e) => e.racers.filter((e) => e.owner === t)), i = r.filter((e) => e.gold).length, a = r.filter((e) => e.silver).length;
	return i + a > 0 && /* @__PURE__ */ b("span", {
		className: "mag-finale-medals",
		children: [i > 0 && /* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(At, { kind: "gold" }), n("games.magicalathlete.finaleMedalCount", {
			medal: n("games.magicalathlete.medalGold"),
			n: i
		})] }), a > 0 && /* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(At, { kind: "silver" }), n("games.magicalathlete.finaleMedalCount", {
			medal: n("games.magicalathlete.medalSilver"),
			n: a
		})] })]
	});
}
function Ft({ racer: e }) {
	let t = p(), n = e.gold && e.silver ? "games.magicalathlete.finaleDouble" : e.gold ? "games.magicalathlete.finaleFirst" : e.silver ? "games.magicalathlete.finaleSecond" : e.eliminated ? "games.magicalathlete.eliminatedMark" : "games.magicalathlete.didNotFinish";
	return /* @__PURE__ */ b("span", {
		className: "mag-finale-placing",
		"data-medal": e.gold || e.silver,
		"data-eliminated": e.eliminated,
		children: [
			e.gold && /* @__PURE__ */ y(At, { kind: "gold" }),
			e.silver && /* @__PURE__ */ y(At, { kind: "silver" }),
			/* @__PURE__ */ y("span", { children: t(n) })
		]
	});
}
function It(e) {
	return e < 0 ? `−${-e}` : `+${e}`;
}
//#endregion
//#region .bgparty/cache/pack-entry/magicalathlete/entry.tsx
var Lt = {
	definition: ze,
	View: mt,
	bot: St,
	describe: Ct,
	fx: kt,
	OverView: Nt,
	locales: {
		zh: {
			cueAlchemist: "将低点数改为移动四格",
			cueBabayaga: "令同格的其他运动员绊倒",
			cueBanana: "令超越自己的运动员在停下后绊倒",
			cueBlimp: "按第二个拐角调整主移动步数",
			cueCentaur: "令被超越的运动员后退两格",
			cueCheerleader: "带动末位运动员前进",
			cueCoach: "同格运动员主移动增加一格",
			cueCopycat: "复制领先运动员的技能",
			cueDicemonger: "提供一次重掷机会",
			cueDuelist: "与同格运动员展开决斗",
			cueEgg: "孵化并获得所选技能",
			cueFlipflop: "与另一名运动员交换位置",
			cueGenius: "预言命中，获得额外回合",
			cueGunk: "其他运动员主移动减少一格",
			cueHare: "额外移动两格，独自领先时休息",
			cueHeckler: "回合结束移动不远，自己前进两格",
			cueHugebaby: "将停在自己格子的运动员挤到身后",
			cueHypnotist: "将目标运动员带到自己所在格",
			cueInchworm: "掷出一点，自己前进并取消对方主移动",
			cueLackey: "别人掷出六点，自己先前进两格",
			cueLeaptoad: "跳过被占据的格子",
			cueLegs: "放弃掷骰，移动五格",
			cueLovableloser: "独自垫底，获得一分",
			cueMouth: "吞掉同格的唯一其他运动员",
			cueMagician: "再次掷骰，以新结果为准",
			cueMastermind: "预言本场冠军",
			cuePartyanimal: "将其他运动员拉近自己",
			cueRocket: "主移动翻倍，随后绊倒",
			cueRomantic: "出现两人同格，自己前进两格",
			cueScoocher: "其他技能发动，自己前进一格",
			cueSisyphus: "赛前得分；掷出六点则退回起点并失分",
			cueSkipper: "下一回合由自己行动",
			cueStickler: "超过终点的移动作废",
			cueSuckerfish: "跟随同格运动员到达新位置",
			cueThirdwheel: "加入恰好有两名运动员的格子",
			cueTwin: "获得所选往届冠军的技能",
			backToMe: "回到我",
			raceHistory: "记录",
			secondCorner: "第二个拐角",
			trackScroll: "赛场，左右滑动查看",
			powerActivated: "{{name}}发动技能",
			name: "胡闹运动会",
			desc: "选秀组建怪咖战队,四场混乱竞速,技能乱飞笑到最后",
			rules: "目标:四场比赛后总分最高者获胜(并列共享胜利)。\n准备:\n· 亮出人数两倍的运动员卡,蛇形选两轮,每人共 4 名运动员。\n流程:共四场比赛,赛道按温和→狂野→温和→狂野交替。\n· 每场赛前,所有人同时从手中暗选一名未用过的运动员亮出;每名运动员整场游戏只能用一次。\n· 第 1 场随机决定先手,之后各场由上一场最靠后(或最先被淘汰)的玩家先动。\n· 回合掷骰移动;运动员技能在移动前中后互相连锁触发。绊倒的运动员跳过下一次主移动。\n· 狂野赛道上:星星格停下获得 1 分;箭头格停下按箭头进退;石头格停下绊倒。\n结算:\n· 第 2 名冲线时比赛立即结束:第 1 名拿金牌、第 2 名拿银牌,\n  分值随场次递增(金 3/4/5/6,银 1/2/3/4)。\n· 四场后总分最高者胜。",
			draftRound: "选秀第 {{n}}/2 轮",
			draftPrompt: "轮到你:选一名运动员",
			draftWaiting: "选秀中,等 {{name}} 选将…",
			draftHint: "点卡片查看技能,再点「选 TA」收下",
			pickThis: "确认选择",
			chooseRacer: "选择{{name}}",
			seatReady: "已选定",
			seatWaiting: "待选择",
			selectTitle: "第 {{n}} 场:选择出场运动员",
			selectPrompt: "从你剩余的运动员中选一名上场",
			selectWaiting: "等全员选定出场运动员…",
			selectDone: "已选定,等其他人…",
			raceChip: "第 {{n}}/4 场",
			spaceNumber: "{{n}} 格",
			startMark: "起跑",
			finishMark: "终点",
			selectCell: "选择第 {{n}} 格",
			selectSpacePrompt: "选择一个有两名运动员的格子",
			backToPowers: "返回技能选择",
			commentaryTitle: "赛事解说",
			commentaryAll: "查看完整解说",
			trackMild: "温和一英里",
			trackWild: "狂野荒野",
			yourTurn: "轮到你:掷骰或使用技能",
			waitTurn: "等 {{name}} 行动…",
			resolving: "连锁结算中…",
			respondAbove: "回应上方弹出的询问…",
			actRoll: "掷骰",
			actFlipFlop: "换位(放弃掷骰)",
			actLegs: "走 5 格(放弃掷骰)",
			actPredict: "预言点数",
			predictPick: "预言将掷出的点数(可不预言)",
			noPredict: "不预言",
			trippedRecover: "{{name}} 绊倒恢复中,跳过本次移动",
			hareSkip: "{{name}} 独自领先,傲娇休息一轮",
			turnOf: "{{name}} 的回合",
			prePowerAsk: "回合开始:要发动技能吗?",
			useCheerleader: "加油:末位运动员移动 2 格,自己移动 1 格",
			useHypnotist: "催眠:拉一名运动员到我格",
			useThirdWheel: "插队到二人格",
			alchemistAsk: "掷出 {{n}}:改为移动 4 格?",
			rocketAsk: "掷出 {{n}}:移动双倍({{m}} 格)然后绊倒?",
			magicianAsk: "要重掷吗?(还可重掷 {{n}} 次,必须用最后一次)",
			dicemongerAsk: "骰子贩子:要重掷一次吗?",
			suckerfishAsk: "{{name}} 要移动了:吸盘鱼跟随吗?",
			duelistAsk: "与 {{name}} 同格:喊「决斗!」吗?",
			duelResult: "决斗!{{a}} {{na}} 点 vs {{b}} {{nb}} 点",
			copycatAsk: "并列领先:模仿猫复制谁的技能?",
			mastermindAsk: "幕后黑手:预言本场冠军(猜中即第 2 名)",
			eggAsk: "蛋:选择要孵化的技能",
			twinAsk: "双胞胎:复制一名往届冠军的技能(可放弃)",
			accept: "发动",
			decline: "算了",
			trippedMark: "绊倒",
			eliminatedMark: "淘汰",
			inspectCell: "查看第 {{n}} 格",
			cellTitle: "第 {{n}} 格",
			cellEffect: "格面效果",
			cellNormalEffect: "没有特殊格面效果。",
			cellCornerEffect: "飞艇技能的分界：回合开始时在本格之前，主移动多走 3 格；在本格或之后，主移动少走 1 格。复制该技能的运动员同样适用。",
			cellStartEffect: "所有运动员从这里起跑，向右前进。",
			cellFinishEffect: "向右越过本格即冲线。",
			cellStarEffect: "移动后停在这里：获得 1 分。",
			cellTripEffect: "移动后停在这里：绊倒，下次主移动跳过。",
			cellArrowForward: "移动后停在这里：继续前进 {{n}} 格。",
			cellArrowBack: "移动后停在这里：后退 {{n}} 格。",
			cellRacers: "格上运动员 · {{n}}",
			cellEmpty: "当前没有运动员。",
			cellOwner: "玩家：{{name}}",
			cellEffectivePower: "当前生效技能：{{name}}",
			cellNoEffectivePower: "当前没有生效的复制技能",
			finishPlace: "第 {{n}} 名冲线!",
			raceOver: "第 {{n}} 场结束",
			roundPlacings: "第 {{n}} 场名次",
			roundPlace: "第 {{n}} 名",
			didNotFinish: "未完赛",
			nextRace: "进入下一场",
			awardGold: "金牌 +{{n}}",
			awardSilver: "银牌 +{{n}}",
			awardNone: "本场银牌无人获得",
			score: "分",
			usedUp: "已上场",
			myStable: "我的运动员",
			powerOf: "技能",
			copiedFrom: "复制自「{{name}}」",
			copycatNow: "正在复制「{{name}}」",
			logDraft: "{{name}} 选择了 {{racer}}",
			logRaceStart: "第 {{n}} 场在{{track}}开赛",
			logSelect: "全员亮出运动员",
			logRoll: "{{name}} 掷出 {{n}}",
			logReroll: "{{name}} 重掷出 {{n}}",
			logMove: "{{racer}} 移动 {{n}} 格",
			logTrip: "{{racer}} 绊倒了",
			logPoints: "{{name}} {{n}} 分",
			logElim: "{{racer}} 被淘汰",
			logWarp: "{{racer}} 瞬移了",
			logSwap: "{{a}} 与 {{b}} 交换位置",
			logFinish: "{{racer}} 第 {{n}} 名冲线",
			logAward: "{{name}} 获得{{medal}} +{{n}}",
			logDuel: "决斗!{{a}} 胜",
			logPredict: "{{name}} 预言 {{racer}} 夺冠",
			logGenius: "{{name}} 预言点数 {{n}}",
			logSkip: "{{racer}} 跳过回合",
			logPower: "{{racer}} 发动了技能",
			medalGold: "金牌",
			finaleTitle: "闭幕颁奖礼",
			finalePoints: "分",
			finaleShared: "并列冠军",
			finaleChampion: "总冠军",
			finaleInspect: "查看第 {{n}} 场的{{name}}",
			finaleStandings: "四场赛果",
			finalePlayers: "{{n}} 位选手",
			finaleMissing: "本局未保存逐场赛果。",
			finaleSchedule: "第 1、3 场：温和一英里 · 第 2、4 场：狂野荒野",
			finalePlayer: "选手",
			finaleRound: "第 {{n}} 场",
			finaleTotal: "总分",
			finaleMissingRace: "无本场记录",
			finaleBreakdown: "奖牌 {{medal}} · 其他 {{other}}",
			finaleClose: "关闭",
			finaleDetailedScore: "奖牌 {{medal}} 分 · 额外得分 {{gained}} · 失分 {{lost}} · 本场合计 {{total}} 分",
			finaleCopied: "本场获得{{name}}的技能",
			finaleMedalCount: "{{medal}} ×{{n}}",
			finaleDouble: "金银双牌",
			finaleFirst: "第一名",
			finaleSecond: "第二名",
			medalSilver: "银牌",
			errNotYourTurn: "还没轮到你",
			errBadRacer: "这名运动员不可用",
			errBadAction: "当前不能这么做",
			errOver: "对局已结束",
			rAlchemist: "炼金术士",
			pAlchemist: "主移动掷出 1 或 2 时,可改为移动 4 格。",
			rBabayaga: "芭芭雅嘎",
			pBabayaga: "任何运动员停在我的格子,或我停在别人的格子:对方绊倒。",
			rBanana: "香蕉皮",
			pBanana: "任何超越我的运动员,在其移动完成后绊倒。",
			rBlimp: "飞艇",
			pBlimp: "回合开始时,我在第二个拐角之前:主移动多走 3 格;在拐角或之后:主移动少走 1 格。",
			rCentaur: "半人马",
			pCentaur: "我超越一名运动员时,其向后移动 2 格(不会退过起点)。",
			rCheerleader: "啦啦队长",
			pCheerleader: "主移动前,可令并列最后的运动员们移动 2 格;若如此做,我移动 1 格。",
			rCoach: "教练",
			pCoach: "与我同格的所有人(含我)主移动多走 1 格。",
			rCopycat: "模仿猫",
			pCopycat: "我持续拥有领先运动员的技能;并列领先时由我选一个。不复制「赛前」技能。",
			rDicemonger: "骰子贩子",
			pDicemonger: "每人每回合可将自己的主移动骰重掷一次;别人重掷时,我移动 1 格。",
			rDuelist: "决斗家",
			pDuelist: "任何人与我同格时,我可喊「决斗!」:双方掷骰,点数大者移动 2 格;平局算我赢。",
			rEgg: "蛋",
			pEgg: "赛前:从牌堆抽 3 张运动员并选 1 张,我拥有其技能(棋子不变)。",
			rFlipflop: "人字拖",
			pFlipflop: "主移动可放弃掷骰,改为与另一名运动员交换位置(不算移动)。",
			rGenius: "天才",
			pGenius: "可预言我主移动将掷出的点数;若猜中,本回合后我再行动一回合。",
			rGunk: "黏液怪",
			pGunk: "其他运动员主移动少走 1 格(减的是移动量,不是骰面)。",
			rHare: "野兔",
			pHare: "主移动多走 2 格;回合开始时若我独自领先,跳过主移动。",
			rHeckler: "起哄者",
			pHeckler: "任何人回合结束时停在回合起点 1 格以内,我移动 2 格(对绊倒恢复者也生效)。",
			rHugebaby: "巨婴",
			pHugebaby: "除起点外,无人能停在我的格子;若会发生,改为放到我身后一格(不算移动)。",
			rHypnotist: "催眠师",
			pHypnotist: "主移动前,可将一名运动员瞬移到我的格子(不算移动)。",
			rInchworm: "尺蠖",
			pInchworm: "别人主移动掷出 1 时,其跳过该次移动,我移动 1 格。",
			rLackey: "跟班",
			pLackey: "别人主移动掷出 6 时,在其移动前,我先移动 2 格。",
			rLeaptoad: "跳跳蛙",
			pLeaptoad: "移动时跳过有人的格子(不计入步数)。",
			rLegs: "飞毛腿",
			pLegs: "主移动可放弃掷骰,改为移动 5 格(仍算主移动)。",
			rLovableloser: "可爱倒霉蛋",
			pLovableloser: "主移动前,若我独自垫底,得 1 分。",
			rMouth: "大嘴",
			pMouth: "我停在恰好有 1 名其他运动员的格子时:其被淘汰出本场比赛。",
			rMagician: "魔术师",
			pMagician: "主移动可重掷至多 2 次,必须使用最后一次结果。",
			rMastermind: "幕后黑手",
			pMastermind: "我本场首个回合开始时预言胜者;若猜中,比赛立即结束且我获第 2 名(预言自己可同时获第 1、2 名)。",
			rPartyanimal: "派对动物",
			pPartyanimal: "主移动前,所有运动员向我移动 1 格;之后每个与我同格的别人使我主移动多走 1 格。",
			rRocket: "火箭科学家",
			pRocket: "主移动掷骰后,可选择移动双倍点数;若如此做,移动后绊倒。",
			rRomantic: "浪漫主义者",
			pRomantic: "任何人停在恰好有 1 名其他运动员的格子时,我移动 2 格。",
			rScoocher: "蹭蹭蟹",
			pScoocher: "每当别人的技能发动,我移动 1 格。",
			rSisyphus: "西西弗斯",
			pSisyphus: "赛前获得 4 分。主移动掷出 6 时:不移动,改为回到起点并失去 1 分。",
			rSkipper: "插队长",
			pSkipper: "任何人主移动掷出 1 时,下一个轮到我行动(之后从我左手边继续)。",
			rStickler: "较真鬼",
			pStickler: "其他运动员只能用恰好点数冲线;超出点数则该次移动作废,原地不动。",
			rSuckerfish: "吸盘鱼",
			pSuckerfish: "与我同格的运动员移动时,我可跟着移动到其新位置(须跟到该次移动结束)。",
			rThirdwheel: "电灯泡",
			pThirdwheel: "主移动前,可瞬移到任意恰好有 2 名运动员的格子(不算移动)。",
			rTwin: "双胞胎",
			pTwin: "赛前:可选一名赢过此前某场比赛的运动员,我拥有其技能(棋子不变)。"
		},
		en: {
			cueAlchemist: "Change a low roll to a four-space move",
			cueBabayaga: "Trip the other athletes on this space",
			cueBanana: "Trip an overtaking athlete after their move",
			cueBlimp: "Adjust movement at the second corner",
			cueCentaur: "Move overtaken athletes back two spaces",
			cueCheerleader: "Help the last-place athletes advance",
			cueCoach: "Add one to main moves from this space",
			cueCopycat: "Copy a leading athlete’s power",
			cueDicemonger: "Offer one reroll",
			cueDuelist: "Challenge an athlete on this space",
			cueEgg: "Hatch with the chosen power",
			cueFlipflop: "Swap places with another athlete",
			cueGenius: "Correct prediction: take an extra turn",
			cueGunk: "Reduce other athletes’ main moves by one",
			cueHare: "Move two extra spaces; rest when alone in front",
			cueHeckler: "Advance two after a short turn",
			cueHugebaby: "Push arrivals to the space behind",
			cueHypnotist: "Bring a target to this space",
			cueInchworm: "On a one, advance and cancel the other main move",
			cueLackey: "On another athlete’s six, advance two first",
			cueLeaptoad: "Skip occupied spaces",
			cueLegs: "Move five instead of rolling",
			cueLovableloser: "Earn a point when alone in last place",
			cueMouth: "Eliminate the only other athlete on this space",
			cueMagician: "Roll again and use the new result",
			cueMastermind: "Predict this race’s winner",
			cuePartyanimal: "Pull the other athletes closer",
			cueRocket: "Double the main move, then trip",
			cueRomantic: "Advance two when exactly two athletes meet",
			cueScoocher: "Advance one when another power activates",
			cueSisyphus: "Score before racing; a six returns to start and loses a point",
			cueSkipper: "Take the next turn",
			cueStickler: "Cancel moves that overshoot the finish",
			cueSuckerfish: "Follow an athlete to their new space",
			cueThirdwheel: "Join a space with exactly two athletes",
			cueTwin: "Gain a previous winner’s power",
			backToMe: "Find me",
			raceHistory: "History",
			secondCorner: "Second corner",
			trackScroll: "Race track. Scroll horizontally to explore.",
			powerActivated: "{{name}} activates a power",
			name: "Magical Athlete",
			desc: "Draft a squad of weirdos, race four chaotic heats, chain powers to victory",
			rules: "Goal: after four races, the most points wins (ties share the win).\nSetup:\n· Reveal twice as many racer cards as players; snake-draft two rounds so everyone has 4 racers.\nPlay: four races on tracks alternating Mild → Wild → Mild → Wild.\n· Before each race, everyone secretly picks one unused racer and reveals together; each racer races only once per game.\n· Race 1 start player is random; later races start with the player farthest behind (or eliminated first) last time.\n· On your turn, roll and move; racer powers chain off each other before, during and after moves. A tripped racer skips its next main move.\n· On the Wild track: stopping on a star scores 1 point; arrows move you on; rocks trip you.\nScoring:\n· A race ends the moment the 2nd racer crosses: 1st takes gold, 2nd takes silver,\n  with values rising by race (gold 3/4/5/6, silver 1/2/3/4).\n· After four races, the highest total wins.",
			draftRound: "Draft round {{n}}/2",
			draftPrompt: "Your pick: choose a racer",
			draftWaiting: "Drafting — waiting for {{name}}…",
			draftHint: "Tap a card to read its power, then \"Pick\" to take it",
			pickThis: "Pick",
			chooseRacer: "Choose {{name}}",
			seatReady: "Ready",
			seatWaiting: "Choosing",
			selectTitle: "Race {{n}}: pick your racer",
			selectPrompt: "Choose one of your remaining racers",
			selectWaiting: "Waiting for everyone to pick a racer…",
			selectDone: "Locked in, waiting for others…",
			raceChip: "Race {{n}}/4",
			spaceNumber: "Space {{n}}",
			startMark: "START",
			finishMark: "FINISH",
			selectCell: "Choose space {{n}}",
			selectSpacePrompt: "Choose a space with exactly two racers",
			backToPowers: "Back to powers",
			commentaryTitle: "RACE CALL",
			commentaryAll: "Full commentary",
			trackMild: "Mild Mile",
			trackWild: "Wild Wilds",
			yourTurn: "Your turn: roll or use a power",
			waitTurn: "Waiting for {{name}}…",
			resolving: "Resolving chains…",
			respondAbove: "Respond to the prompt above…",
			actRoll: "Roll",
			actFlipFlop: "Swap instead of rolling",
			actLegs: "Move 5 instead of rolling",
			actPredict: "Predict",
			predictPick: "Predict your roll (optional)",
			noPredict: "No prediction",
			trippedRecover: "{{name}} is recovering from a trip and skips the move",
			hareSkip: "{{name}} is alone in the lead and rests",
			turnOf: "{{name}}'s turn",
			prePowerAsk: "Start of turn: use a power?",
			useCheerleader: "Cheer: last-place racers move 2, I move 1",
			useHypnotist: "Hypnotize: warp a racer to my space",
			useThirdWheel: "Warp to a space with exactly 2 racers",
			alchemistAsk: "Rolled {{n}}: move 4 instead?",
			rocketAsk: "Rolled {{n}}: move double ({{m}}) and trip?",
			magicianAsk: "Reroll? ({{n}} left; must keep the last roll)",
			dicemongerAsk: "Dicemonger: reroll once?",
			suckerfishAsk: "{{name}} is moving: follow along?",
			duelistAsk: "Sharing a space with {{name}}: shout \"DUEL!\"?",
			duelResult: "Duel! {{a}} rolled {{na}} vs {{b}} rolled {{nb}}",
			copycatAsk: "Tied for the lead: whose power does Copycat copy?",
			mastermindAsk: "Mastermind: predict the race winner (a hit makes you 2nd)",
			eggAsk: "Egg: pick a power to hatch",
			twinAsk: "Twin: copy a past race winner (optional)",
			accept: "Use",
			decline: "Skip",
			trippedMark: "Tripped",
			eliminatedMark: "Out",
			inspectCell: "Inspect space {{n}}",
			cellTitle: "Space {{n}}",
			cellEffect: "Space effect",
			cellNormalEffect: "This space has no special effect.",
			cellCornerEffect: "Blimp’s power uses this boundary: start a turn before this space to add 3 to the main move; at or beyond it, subtract 1. Racers copying this power use the same boundary.",
			cellStartEffect: "All racers start here and move to the right.",
			cellFinishEffect: "Move past this space to the right to cross the finish line.",
			cellStarEffect: "Stop here after moving: gain 1 point.",
			cellTripEffect: "Stop here after moving: trip and skip your next main move.",
			cellArrowForward: "Stop here after moving: move forward {{n}} more spaces.",
			cellArrowBack: "Stop here after moving: move back {{n}} spaces.",
			cellRacers: "Racers here · {{n}}",
			cellEmpty: "No racers on this space.",
			cellOwner: "Player: {{name}}",
			cellEffectivePower: "Active power: {{name}}",
			cellNoEffectivePower: "No copied power is active right now",
			finishPlace: "Finished {{n}}!",
			raceOver: "Race {{n}} over",
			roundPlacings: "Race {{n}} placings",
			roundPlace: "Place {{n}}",
			didNotFinish: "Did not finish",
			nextRace: "Next race",
			awardGold: "Gold +{{n}}",
			awardSilver: "Silver +{{n}}",
			awardNone: "No silver awarded this race",
			score: "pts",
			usedUp: "Raced",
			myStable: "My racers",
			powerOf: "Power",
			copiedFrom: "copying \"{{name}}\"",
			copycatNow: "copying \"{{name}}\"",
			logDraft: "{{name}} drafted {{racer}}",
			logRaceStart: "Race {{n}} begins on {{track}}",
			logSelect: "All racers revealed",
			logRoll: "{{name}} rolled {{n}}",
			logReroll: "{{name}} rerolled {{n}}",
			logMove: "{{racer}} moved {{n}}",
			logTrip: "{{racer}} tripped",
			logPoints: "{{name}} {{n}} pts",
			logElim: "{{racer}} is eliminated",
			logWarp: "{{racer}} warped",
			logSwap: "{{a}} swapped with {{b}}",
			logFinish: "{{racer}} finished {{n}}",
			logAward: "{{name}} takes {{medal}} +{{n}}",
			logDuel: "Duel! {{a}} wins",
			logPredict: "{{name}} predicts {{racer}} wins",
			logGenius: "{{name}} predicts rolling {{n}}",
			logSkip: "{{racer}} skips the turn",
			logPower: "{{racer}}'s power triggers",
			medalGold: "gold",
			finaleTitle: "Closing Ceremony",
			finalePoints: "pts",
			finaleShared: "Joint Champions",
			finaleChampion: "Champion",
			finaleInspect: "Inspect {{name}} in race {{n}}",
			finaleStandings: "Four-Race Results",
			finalePlayers: "{{n}} players",
			finaleMissing: "Race details were not saved for this game.",
			finaleSchedule: "Races 1 & 3: Mild Mile · Races 2 & 4: Wild Wilds",
			finalePlayer: "Player",
			finaleRound: "Race {{n}}",
			finaleTotal: "Total",
			finaleMissingRace: "No race record",
			finaleBreakdown: "Medals {{medal}} · Other {{other}}",
			finaleClose: "Close",
			finaleDetailedScore: "Medals {{medal}} · Gained {{gained}} · Lost {{lost}} · Race total {{total}} pts",
			finaleCopied: "Gained {{name}}’s power this race",
			finaleMedalCount: "{{medal}} ×{{n}}",
			finaleDouble: "Gold & silver",
			finaleFirst: "1st place",
			finaleSecond: "2nd place",
			medalSilver: "silver",
			errNotYourTurn: "Not your turn",
			errBadRacer: "That racer is unavailable",
			errBadAction: "Not allowed right now",
			errOver: "The game is over",
			rAlchemist: "Alchemist",
			pAlchemist: "When I roll a 1 or 2 for my main move, I can move 4 instead.",
			rBabayaga: "Baba Yaga",
			pBabayaga: "Trip any racer that stops on my space, or when I stop on theirs.",
			rBanana: "Banana",
			pBanana: "When a racer passes me, they trip (after finishing their move).",
			rBlimp: "Blimp",
			pBlimp: "When I start my turn before the second corner, my main move goes 3 extra spaces; on or after it, 1 space fewer.",
			rCentaur: "Centaur",
			pCentaur: "When I pass a racer, they move -2 (never past the Start).",
			rCheerleader: "Cheerleader",
			pCheerleader: "Before my main move, I can make the racer(s) in last place move 2. If I do, I move 1.",
			rCoach: "Coach",
			pCoach: "Everyone on my space (including me) moves 1 extra space on their main move.",
			rCopycat: "Copycat",
			pCopycat: "I have the power of the racer currently in the lead; if tied, I pick. Never copies \"before race\" powers.",
			rDicemonger: "Dicemonger",
			pDicemonger: "Anyone can reroll their main move once per turn; when another racer does, I move 1.",
			rDuelist: "Duelist",
			pDuelist: "Whenever a racer shares my space, I can shout \"DUEL!\": we both roll, the higher moves 2; I win ties.",
			rEgg: "Egg",
			pEgg: "Before my race: draw 3 new racers from the deck and pick one; I have its powers (same token).",
			rFlipflop: "Flip Flop",
			pFlipflop: "I can skip rolling for my main move and swap spaces with another racer instead (not a move).",
			rGenius: "Genius",
			pGenius: "I can predict what number I will roll for my main move; if right, I take another turn after this one.",
			rGunk: "Gunk",
			pGunk: "Other racers move 1 space fewer on their main move (the move amount, not the die).",
			rHare: "Hare",
			pHare: "My main move goes 2 extra spaces; when I start my turn alone in the lead, I skip my main move.",
			rHeckler: "Heckler",
			pHeckler: "When a racer ends their turn within 1 space of where they started, I move 2 (works for trip recovery).",
			rHugebaby: "Huge Baby",
			pHugebaby: "No one can stop on my space except at the Start; whoever would is put on the space behind me (not a move).",
			rHypnotist: "Hypnotist",
			pHypnotist: "Before my main move, I can warp a racer to my space (not a move).",
			rInchworm: "Inchworm",
			pInchworm: "When another racer rolls a 1 for their main move, they skip that move and I move 1.",
			rLackey: "Lackey",
			pLackey: "When another racer rolls a 6 for their main move, I move 2 before they move.",
			rLeaptoad: "Leaptoad",
			pLeaptoad: "While moving, I skip spaces with other racers on them (they cost no steps).",
			rLegs: "Legs",
			pLegs: "I can skip rolling for my main move and move 5 instead (still counts as my main move).",
			rLovableloser: "Lovable Loser",
			pLovableloser: "Before my main move, I get 1 point if I am alone in last place.",
			rMouth: "M.O.U.T.H.",
			pMouth: "When I stop on a space with exactly one other racer, they are eliminated from the race.",
			rMagician: "Magician",
			pMagician: "I can reroll my main move up to two times; I must use the last roll.",
			rMastermind: "Mastermind",
			pMastermind: "At the start of my first turn, I predict the winner; if right, the race ends at once and I finish 2nd (predicting myself can win both).",
			rPartyanimal: "Party Animal",
			pPartyanimal: "Before my main move, all racers move 1 space towards me; then each other racer on my space gives my main move 1 extra space.",
			rRocket: "Rocket Scientist",
			pRocket: "When I roll for my main move, I can move double that number; if I do, I trip after moving.",
			rRomantic: "Romantic",
			pRomantic: "When anyone stops on a space with exactly one other racer, I move 2.",
			rScoocher: "Scoocher",
			pScoocher: "Whenever another racer's power happens, I move 1.",
			rSisyphus: "Sisyphus",
			pSisyphus: "Before my race, I gain 4 points. When I roll a 6 for my main move: instead of moving, I warp to the Start and lose 1 point.",
			rSkipper: "Skipper",
			pSkipper: "When anyone rolls a 1 for their main move, I go next (order then continues to my left).",
			rStickler: "Stickler",
			pStickler: "Other racers can only cross the finish line by moving the exact amount needed; overshooting cancels that move entirely.",
			rSuckerfish: "Suckerfish",
			pSuckerfish: "When a racer on my space moves, I can move along to their new space (must follow to the end of that move).",
			rThirdwheel: "Third Wheel",
			pThirdwheel: "Before my main move, I can warp to any space with exactly 2 racers on it (not a move).",
			rTwin: "Twin",
			pTwin: "Before my race, I can pick a racer who won a previous race; I have their powers (same token)."
		}
	}
};
//#endregion
export { Lt as default };
