import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { useWakeLock as s } from "@bgparty/sdk/use-wake-lock";
import { IconClose as c, IconSearch as l } from "@bgparty/sdk/icons";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as d } from "@bgparty/sdk/assets";
import { useFxAnchor as f } from "@bgparty/sdk/fx/anchors";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as ee, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as v } from "@bgparty/sdk/confirm-button";
//#endregion
//#region src/games/arnak/data.ts
var y = Object.fromEntries((/* @__PURE__ */ JSON.parse("[{\"id\":\"1208\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":5207,\"effect\":\"returnIdol\",\"nameKey\":\"games.arnak.card1208Name\",\"textKey\":\"games.arnak.card1208Text\"},{\"id\":\"0218\",\"kind\":\"artifact\",\"cost\":3,\"points\":2,\"travel\":[\"plane\"],\"cardId\":4803,\"effect\":\"fear;cccc\",\"nameKey\":\"games.arnak.card0218Name\",\"textKey\":\"games.arnak.card0218Text\"},{\"id\":\"0201\",\"kind\":\"artifact\",\"cost\":4,\"points\":3,\"travel\":[\"plane\"],\"cardId\":4704,\"effect\":\"draw;c\",\"nameKey\":\"games.arnak.card0201Name\",\"textKey\":\"games.arnak.card0201Text\"},{\"id\":\"0213\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":5006,\"effect\":\"hammer\",\"nameKey\":\"games.arnak.card0213Name\",\"textKey\":\"games.arnak.card0213Text\"},{\"id\":\"0216\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":5014,\"effect\":\"trade:c>twoCamps\",\"nameKey\":\"games.arnak.card0216Name\",\"textKey\":\"games.arnak.card0216Text\"},{\"id\":\"0214\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":5104,\"effect\":\"scry:3\",\"nameKey\":\"games.arnak.card0214Name\",\"textKey\":\"games.arnak.card0214Text\"},{\"id\":\"0206\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":4911,\"effect\":\"exile;a\",\"nameKey\":\"games.arnak.card0206Name\",\"textKey\":\"games.arnak.card0206Text\"},{\"id\":\"0205\",\"kind\":\"artifact\",\"cost\":4,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4701,\"effect\":\"relocate:1\",\"nameKey\":\"games.arnak.card0205Name\",\"textKey\":\"games.arnak.card0205Text\"},{\"id\":\"0204\",\"kind\":\"artifact\",\"cost\":4,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4923,\"effect\":\"fear;cttt\",\"nameKey\":\"games.arnak.card0204Name\",\"textKey\":\"games.arnak.card0204Text\"},{\"id\":\"0225\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5003,\"effect\":\"relocate:0\",\"nameKey\":\"games.arnak.card0225Name\",\"textKey\":\"games.arnak.card0225Text\"},{\"id\":\"0210\",\"kind\":\"artifact\",\"cost\":4,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4910,\"effect\":\"overcome\",\"nameKey\":\"games.arnak.card0210Name\",\"textKey\":\"games.arnak.card0210Text\"},{\"id\":\"0208\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":4908,\"effect\":\"exile;activate:0:empty\",\"nameKey\":\"games.arnak.card0208Name\",\"textKey\":\"games.arnak.card0208Text\"},{\"id\":\"0217\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\",\"plane\"],\"cardId\":4808,\"effect\":\"returnWorker;allPlanes\",\"nameKey\":\"games.arnak.card0217Name\",\"textKey\":\"games.arnak.card0217Text\"},{\"id\":\"0223\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4912,\"effect\":\"shell\",\"nameKey\":\"games.arnak.card0223Name\",\"textKey\":\"games.arnak.card0223Text\"},{\"id\":\"0212\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":4817,\"effect\":\"upgrade;ccc\",\"nameKey\":\"games.arnak.card0212Name\",\"textKey\":\"games.arnak.card0212Text\"},{\"id\":\"0235\",\"kind\":\"artifact\",\"cost\":2,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4713,\"effect\":\"choice:tt/passj\",\"nameKey\":\"games.arnak.card0235Name\",\"textKey\":\"games.arnak.card0235Text\"},{\"id\":\"0234\",\"kind\":\"artifact\",\"cost\":2,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5005,\"effect\":\"exchangeAssistant\",\"nameKey\":\"games.arnak.card0234Name\",\"textKey\":\"games.arnak.card0234Text\"},{\"id\":\"0228\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5013,\"effect\":\"revealSite:1\",\"nameKey\":\"games.arnak.card0228Name\",\"textKey\":\"games.arnak.card0228Text\"},{\"id\":\"0220\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4705,\"effect\":\"draw;exile\",\"nameKey\":\"games.arnak.card0220Name\",\"textKey\":\"games.arnak.card0220Text\"},{\"id\":\"0219\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5018,\"effect\":\"upgrade;cc\",\"nameKey\":\"games.arnak.card0219Name\",\"textKey\":\"games.arnak.card0219Text\"},{\"id\":\"0215\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":5001,\"effect\":\"moveGuardian\",\"nameKey\":\"games.arnak.card0215Name\",\"textKey\":\"games.arnak.card0215Text\"},{\"id\":\"0211\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":4707,\"effect\":\"scryBottom:2\",\"nameKey\":\"games.arnak.card0211Name\",\"textKey\":\"games.arnak.card0211Text\"},{\"id\":\"0231\",\"kind\":\"artifact\",\"cost\":2,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4901,\"effect\":\"fear;j\",\"nameKey\":\"games.arnak.card0231Name\",\"textKey\":\"games.arnak.card0231Text\"},{\"id\":\"0207\",\"kind\":\"artifact\",\"cost\":4,\"points\":2,\"travel\":[\"plane\"],\"cardId\":4702,\"effect\":\"gainItemTop\",\"nameKey\":\"games.arnak.card0207Name\",\"textKey\":\"games.arnak.card0207Text\"},{\"id\":\"0226\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5017,\"effect\":\"a;noFear\",\"nameKey\":\"games.arnak.card0226Name\",\"textKey\":\"games.arnak.card0226Text\"},{\"id\":\"0203\",\"kind\":\"artifact\",\"cost\":4,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5020,\"effect\":\"fear;aa\",\"nameKey\":\"games.arnak.card0203Name\",\"textKey\":\"games.arnak.card0203Text\"},{\"id\":\"0233\",\"kind\":\"artifact\",\"cost\":2,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4806,\"effect\":\"research:either:discount\",\"nameKey\":\"games.arnak.card0233Name\",\"textKey\":\"games.arnak.card0233Text\"},{\"id\":\"0202\",\"kind\":\"artifact\",\"cost\":4,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4914,\"effect\":\"trade:s>revealSite2\",\"nameKey\":\"games.arnak.card0202Name\",\"textKey\":\"games.arnak.card0202Text\"},{\"id\":\"0221\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4816,\"effect\":\"exile;cc\",\"nameKey\":\"games.arnak.card0221Name\",\"textKey\":\"games.arnak.card0221Text\"},{\"id\":\"0222\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4709,\"effect\":\"trade:c>copyGold\",\"nameKey\":\"games.arnak.card0222Name\",\"textKey\":\"games.arnak.card0222Text\"},{\"id\":\"0232\",\"kind\":\"artifact\",\"cost\":2,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5012,\"effect\":\"draw\",\"nameKey\":\"games.arnak.card0232Name\",\"textKey\":\"games.arnak.card0232Text\"},{\"id\":\"0227\",\"kind\":\"artifact\",\"cost\":3,\"points\":2,\"travel\":[\"plane\"],\"cardId\":4917,\"effect\":\"trade:cc>copySilver\",\"nameKey\":\"games.arnak.card0227Name\",\"textKey\":\"games.arnak.card0227Text\"},{\"id\":\"0224\",\"kind\":\"artifact\",\"cost\":3,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5010,\"effect\":\"research:either:j\",\"nameKey\":\"games.arnak.card0224Name\",\"textKey\":\"games.arnak.card0224Text\"},{\"id\":\"0209\",\"kind\":\"artifact\",\"cost\":4,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4915,\"effect\":\"discard;refresh:2\",\"nameKey\":\"games.arnak.card0209Name\",\"textKey\":\"games.arnak.card0209Text\"},{\"id\":\"0230\",\"kind\":\"artifact\",\"cost\":3,\"points\":2,\"travel\":[\"plane\"],\"cardId\":5022,\"effect\":\"refresh:1\",\"nameKey\":\"games.arnak.card0230Name\",\"textKey\":\"games.arnak.card0230Text\"},{\"id\":\"0109\",\"kind\":\"item\",\"cost\":2,\"points\":1,\"travel\":[\"boat\"],\"cardId\":4919,\"effect\":\"discard;draw:2\",\"nameKey\":\"games.arnak.card0109Name\",\"textKey\":\"games.arnak.card0109Text\"},{\"id\":\"0110\",\"kind\":\"item\",\"cost\":3,\"points\":1,\"travel\":[\"car\",\"car\"],\"cardId\":5008,\"effect\":\"draw;expedition:car\",\"nameKey\":\"games.arnak.card0110Name\",\"textKey\":\"games.arnak.card0110Text\"},{\"id\":\"0108\",\"kind\":\"item\",\"cost\":1,\"points\":1,\"travel\":[\"boat\"],\"cardId\":4722,\"effect\":\"choice:cc/passccc\",\"nameKey\":\"games.arnak.card0108Name\",\"textKey\":\"games.arnak.card0108Text\"},{\"id\":\"0107\",\"kind\":\"item\",\"cost\":1,\"points\":1,\"travel\":[\"car\"],\"cardId\":4802,\"effect\":\"trade:s>j\",\"nameKey\":\"games.arnak.card0107Name\",\"textKey\":\"games.arnak.card0107Text\"},{\"id\":\"0132\",\"kind\":\"item\",\"cost\":3,\"points\":2,\"travel\":[\"boat\",\"boat\"],\"cardId\":4909,\"effect\":\"choice:cs/passsss\",\"nameKey\":\"games.arnak.card0132Name\",\"textKey\":\"games.arnak.card0132Text\"},{\"id\":\"0106\",\"kind\":\"item\",\"cost\":2,\"points\":1,\"travel\":[\"boat\"],\"cardId\":4916,\"effect\":\"tt\",\"nameKey\":\"games.arnak.card0106Name\",\"textKey\":\"games.arnak.card0106Text\"},{\"id\":\"0105\",\"kind\":\"item\",\"cost\":4,\"points\":1,\"travel\":[\"car\",\"car\"],\"cardId\":4902,\"effect\":\"draw;cs\",\"nameKey\":\"games.arnak.card0105Name\",\"textKey\":\"games.arnak.card0105Text\"},{\"id\":\"0104\",\"kind\":\"item\",\"cost\":4,\"points\":1,\"travel\":[\"boat\"],\"cardId\":5004,\"effect\":\"activate:1\",\"nameKey\":\"games.arnak.card0104Name\",\"textKey\":\"games.arnak.card0104Text\"},{\"id\":\"0103\",\"kind\":\"item\",\"cost\":2,\"points\":1,\"travel\":[\"boat\"],\"cardId\":5101,\"effect\":\"exileSelf;draw:3\",\"nameKey\":\"games.arnak.card0103Name\",\"textKey\":\"games.arnak.card0103Text\"},{\"id\":\"0101\",\"kind\":\"item\",\"cost\":3,\"points\":1,\"travel\":[\"car\",\"boat\"],\"cardId\":4903,\"effect\":\"exileSelf;research:book:free\",\"nameKey\":\"games.arnak.card0101Name\",\"textKey\":\"games.arnak.card0101Text\"},{\"id\":\"0102\",\"kind\":\"item\",\"cost\":3,\"points\":1,\"travel\":[\"car\"],\"cardId\":4716,\"effect\":\"s;activate:0:empty\",\"nameKey\":\"games.arnak.card0102Name\",\"textKey\":\"games.arnak.card0102Text\"},{\"id\":\"0119\",\"kind\":\"item\",\"cost\":1,\"points\":1,\"travel\":[\"car\"],\"cardId\":5023,\"effect\":\"trade:s>ta\",\"nameKey\":\"games.arnak.card0119Name\",\"textKey\":\"games.arnak.card0119Text\"},{\"id\":\"0120\",\"kind\":\"item\",\"cost\":4,\"points\":1,\"travel\":[\"boat\"],\"cardId\":4717,\"effect\":\"buy:artifact:3:top\",\"nameKey\":\"games.arnak.card0120Name\",\"textKey\":\"games.arnak.card0120Text\"},{\"id\":\"0118\",\"kind\":\"item\",\"cost\":2,\"points\":2,\"travel\":[\"boat\"],\"cardId\":4922,\"effect\":\"exile;t\",\"nameKey\":\"games.arnak.card0118Name\",\"textKey\":\"games.arnak.card0118Text\"},{\"id\":\"0117\",\"kind\":\"item\",\"cost\":4,\"points\":1,\"travel\":[\"car\",\"car\"],\"cardId\":4809,\"effect\":\"draw:2\",\"nameKey\":\"games.arnak.card0117Name\",\"textKey\":\"games.arnak.card0117Text\"},{\"id\":\"0116\",\"kind\":\"item\",\"cost\":1,\"points\":1,\"travel\":[\"boat\"],\"cardId\":4913,\"effect\":\"exileSelf;sss\",\"nameKey\":\"games.arnak.card0116Name\",\"textKey\":\"games.arnak.card0116Text\"},{\"id\":\"0111\",\"kind\":\"item\",\"cost\":1,\"points\":1,\"travel\":[\"car\",\"car\"],\"cardId\":4811,\"effect\":\"s;expedition:boot\",\"nameKey\":\"games.arnak.card0111Name\",\"textKey\":\"games.arnak.card0111Text\"},{\"id\":\"0112\",\"kind\":\"item\",\"cost\":2,\"points\":1,\"travel\":[\"plane\"],\"cardId\":5019,\"effect\":\"exileSelf;gainItemHand\",\"nameKey\":\"games.arnak.card0112Name\",\"textKey\":\"games.arnak.card0112Text\"},{\"id\":\"0130\",\"kind\":\"item\",\"cost\":1,\"points\":1,\"travel\":[\"boat\",\"boat\"],\"cardId\":5015,\"effect\":\"cc\",\"nameKey\":\"games.arnak.card0130Name\",\"textKey\":\"games.arnak.card0130Text\"},{\"id\":\"0129\",\"kind\":\"item\",\"cost\":2,\"points\":2,\"travel\":[\"car\"],\"cardId\":4711,\"effect\":\"discard;draw;exile\",\"nameKey\":\"games.arnak.card0129Name\",\"textKey\":\"games.arnak.card0129Text\"},{\"id\":\"0115\",\"kind\":\"item\",\"cost\":3,\"points\":1,\"travel\":[\"car\"],\"cardId\":4706,\"effect\":\"c;drawBottom\",\"nameKey\":\"games.arnak.card0115Name\",\"textKey\":\"games.arnak.card0115Text\"},{\"id\":\"0127\",\"kind\":\"item\",\"cost\":3,\"points\":1,\"travel\":[\"boat\",\"boat\"],\"cardId\":4800,\"effect\":\"draw;expedition:boat\",\"nameKey\":\"games.arnak.card0127Name\",\"textKey\":\"games.arnak.card0127Text\"},{\"id\":\"0123\",\"kind\":\"item\",\"cost\":2,\"points\":2,\"travel\":[\"car\"],\"cardId\":4920,\"effect\":\"guardiansCompass\",\"nameKey\":\"games.arnak.card0123Name\",\"textKey\":\"games.arnak.card0123Text\"},{\"id\":\"0122\",\"kind\":\"item\",\"cost\":3,\"points\":2,\"travel\":[\"car\"],\"cardId\":4904,\"effect\":\"activate:0\",\"nameKey\":\"games.arnak.card0122Name\",\"textKey\":\"games.arnak.card0122Text\"},{\"id\":\"0121\",\"kind\":\"item\",\"cost\":2,\"points\":2,\"travel\":[\"boat\"],\"cardId\":4708,\"effect\":\"exile;s\",\"nameKey\":\"games.arnak.card0121Name\",\"textKey\":\"games.arnak.card0121Text\"},{\"id\":\"0114\",\"kind\":\"item\",\"cost\":3,\"points\":3,\"travel\":[\"car\"],\"cardId\":4714,\"effect\":\"idolsCompass\",\"nameKey\":\"games.arnak.card0114Name\",\"textKey\":\"games.arnak.card0114Text\"},{\"id\":\"0126\",\"kind\":\"item\",\"cost\":3,\"points\":1,\"travel\":[\"car\",\"boat\"],\"cardId\":4906,\"effect\":\"knife\",\"nameKey\":\"games.arnak.card0126Name\",\"textKey\":\"games.arnak.card0126Text\"},{\"id\":\"0139\",\"kind\":\"item\",\"cost\":3,\"points\":1,\"travel\":[\"boat\"],\"cardId\":4815,\"effect\":\"c;workersCompass\",\"nameKey\":\"games.arnak.card0139Name\",\"textKey\":\"games.arnak.card0139Text\"},{\"id\":\"0137\",\"kind\":\"item\",\"cost\":2,\"points\":1,\"travel\":[\"car\"],\"cardId\":4918,\"effect\":\"exileSelf;buy:artifact:3\",\"nameKey\":\"games.arnak.card0137Name\",\"textKey\":\"games.arnak.card0137Text\"},{\"id\":\"0136\",\"kind\":\"item\",\"cost\":1,\"points\":1,\"travel\":[\"boat\"],\"cardId\":5002,\"effect\":\"cs\",\"nameKey\":\"games.arnak.card0136Name\",\"textKey\":\"games.arnak.card0136Text\"},{\"id\":\"0113\",\"kind\":\"item\",\"cost\":4,\"points\":1,\"travel\":[\"boat\",\"boat\"],\"cardId\":4814,\"effect\":\"trade:s>overcome\",\"nameKey\":\"games.arnak.card0113Name\",\"textKey\":\"games.arnak.card0113Text\"},{\"id\":\"0125\",\"kind\":\"item\",\"cost\":3,\"points\":3,\"travel\":[\"car\",\"car\"],\"cardId\":4715,\"effect\":\"ss\",\"nameKey\":\"games.arnak.card0125Name\",\"textKey\":\"games.arnak.card0125Text\"},{\"id\":\"0140\",\"kind\":\"item\",\"cost\":3,\"points\":3,\"travel\":[\"boat\",\"boat\"],\"cardId\":4723,\"effect\":\"ss\",\"nameKey\":\"games.arnak.card0140Name\",\"textKey\":\"games.arnak.card0140Text\"},{\"id\":\"0135\",\"kind\":\"item\",\"cost\":2,\"points\":2,\"travel\":[\"boat\"],\"cardId\":4810,\"effect\":\"buy:item:3:top\",\"nameKey\":\"games.arnak.card0135Name\",\"textKey\":\"games.arnak.card0135Text\"},{\"id\":\"0133\",\"kind\":\"item\",\"cost\":2,\"points\":1,\"travel\":[\"car\"],\"cardId\":5100,\"effect\":\"exileSelf;trap\",\"nameKey\":\"games.arnak.card0133Name\",\"textKey\":\"games.arnak.card0133Text\"},{\"id\":\"0128\",\"kind\":\"item\",\"cost\":4,\"points\":2,\"travel\":[\"car\"],\"cardId\":4710,\"effect\":\"tent\",\"nameKey\":\"games.arnak.card0128Name\",\"textKey\":\"games.arnak.card0128Text\"},{\"id\":\"0124\",\"kind\":\"item\",\"cost\":2,\"points\":1,\"travel\":[\"plane\"],\"cardId\":4718,\"effect\":\"exileSelf;expedition:plane:3\",\"nameKey\":\"games.arnak.card0124Name\",\"textKey\":\"games.arnak.card0124Text\"},{\"id\":\"0138\",\"kind\":\"item\",\"cost\":2,\"points\":2,\"travel\":[\"boat\"],\"cardId\":4812,\"effect\":\"discard;j\",\"nameKey\":\"games.arnak.card0138Name\",\"textKey\":\"games.arnak.card0138Text\"},{\"id\":\"0134\",\"kind\":\"item\",\"cost\":4,\"points\":1,\"travel\":[\"car\"],\"cardId\":4813,\"effect\":\"exile;ss\",\"nameKey\":\"games.arnak.card0134Name\",\"textKey\":\"games.arnak.card0134Text\"},{\"id\":\"0131\",\"kind\":\"item\",\"cost\":4,\"points\":3,\"travel\":[\"plane\",\"plane\"],\"cardId\":4712,\"effect\":\"expedition:plane:2\",\"nameKey\":\"games.arnak.card0131Name\",\"textKey\":\"games.arnak.card0131Text\"}]")).map((e) => [e.id, e]));
for (let [e, t, n, r, i] of [
	[
		"fund-car",
		"games.arnak.cardfundcarName",
		"games.arnak.cardfundcarText",
		"car",
		"c"
	],
	[
		"fund-boat",
		"games.arnak.cardfundboatName",
		"games.arnak.cardfundboatText",
		"boat",
		"c"
	],
	[
		"explore-car",
		"games.arnak.cardexplorecarName",
		"games.arnak.cardexplorecarText",
		"car",
		"s"
	],
	[
		"explore-boat",
		"games.arnak.cardexploreboatName",
		"games.arnak.cardexploreboatText",
		"boat",
		"s"
	],
	[
		"fear",
		"games.arnak.cardfearName",
		"games.arnak.cardfearText",
		"boot",
		""
	],
	[
		"fear-tile",
		"games.arnak.cardfeartileName",
		"games.arnak.cardfeartileText",
		"",
		""
	]
]) y[e] = {
	id: e,
	nameKey: t,
	textKey: n,
	kind: e.startsWith("fear") ? "fear" : "starter",
	cost: 0,
	points: e === "fear-tile" ? -2 : e === "fear" ? -1 : 0,
	travel: r ? [r] : [],
	effect: i,
	cardId: 0
};
var te = /* @__PURE__ */ new Set([
	"0108",
	"0132",
	"0106",
	"0130",
	"0136",
	"0125",
	"0140"
]), b = [
	"c",
	"s",
	"t",
	"a",
	"j"
], ne = {
	c: "games.arnak.resourcec",
	s: "games.arnak.resources",
	t: "games.arnak.resourcet",
	a: "games.arnak.resourcea",
	j: "games.arnak.resourcej",
	boot: "games.arnak.resourceboot",
	car: "games.arnak.resourcecar",
	boat: "games.arnak.resourceboat",
	plane: "games.arnak.resourceplane"
}, x = [
	{
		id: 1800,
		effect: "draw;ct"
	},
	{
		id: 1801,
		effect: "ta"
	},
	{
		id: 1802,
		effect: "fear;tj"
	},
	{
		id: 1803,
		effect: "choice:ss/gainItem"
	},
	{
		id: 1804,
		effect: "ca"
	},
	{
		id: 1805,
		effect: "fear;sj"
	},
	{
		id: 1806,
		effect: "j"
	},
	{
		id: 1807,
		effect: "draw;a"
	},
	{
		id: 1808,
		effect: "sa"
	},
	{
		id: 1809,
		effect: "ctt"
	},
	{
		id: 1601,
		effect: "aj"
	},
	{
		id: 1602,
		effect: "ttj"
	},
	{
		id: 1603,
		effect: "csta"
	},
	{
		id: 1604,
		effect: "draw;tj"
	},
	{
		id: 1605,
		effect: "fear;ttaa"
	},
	{
		id: 1606,
		effect: "ssj"
	}
], S = Object.fromEntries(x.map((e) => [e.id, e])), C = [
	[
		1301,
		"games.arnak.guardian1301",
		"discard;sa",
		"",
		"draw"
	],
	[
		1302,
		"games.arnak.guardian1302",
		"ttt",
		"",
		"plane"
	],
	[
		1303,
		"games.arnak.guardian1303",
		"j",
		"boot",
		"plane"
	],
	[
		1304,
		"games.arnak.guardian1304",
		"ssa",
		"",
		"boat"
	],
	[
		1305,
		"games.arnak.guardian1305",
		"s",
		"boot,boot",
		"exile"
	],
	[
		1306,
		"games.arnak.guardian1306",
		"a",
		"plane",
		"exile"
	],
	[
		1307,
		"games.arnak.guardian1307",
		"discard;ca",
		"",
		"exile"
	],
	[
		1308,
		"games.arnak.guardian1308",
		"cca",
		"",
		"car"
	],
	[
		1309,
		"games.arnak.guardian1309",
		"ta",
		"boot",
		"exile"
	],
	[
		1310,
		"games.arnak.guardian1310",
		"a",
		"car",
		"boat"
	],
	[
		1400,
		"games.arnak.guardian1400",
		"a",
		"boat",
		"car"
	],
	[
		1401,
		"games.arnak.guardian1401",
		"ca",
		"boot",
		"car"
	],
	[
		1402,
		"games.arnak.guardian1402",
		"a",
		"plane",
		"exile"
	],
	[
		1403,
		"games.arnak.guardian1403",
		"cccc",
		"",
		"upgrade"
	],
	[
		1404,
		"games.arnak.guardian1404",
		"sca",
		"",
		"boat"
	]
].map(([e, t, n, r, i]) => ({
	id: Number(e),
	nameKey: t,
	cost: String(n),
	travel: r ? String(r).split(",") : [],
	boon: String(i)
})), w = Object.fromEntries(C.map((e) => [e.id, e])), re = [
	[
		600,
		"games.arnak.assistant600",
		"cc",
		"ccc"
	],
	[
		601,
		"games.arnak.assistant601",
		"t",
		"ct"
	],
	[
		602,
		"games.arnak.assistant602",
		"travelTrade:boot>a",
		"a"
	],
	[
		603,
		"games.arnak.assistant603",
		"trade:c>a",
		"choice:trade:c>a/trade:c>j"
	],
	[
		604,
		"games.arnak.assistant604",
		"exile",
		"s;exile"
	],
	[
		605,
		"games.arnak.assistant605",
		"drawDiscard",
		"draw"
	],
	[
		606,
		"games.arnak.assistant606",
		"choice:c/travel:plane",
		"choice:cc/travel:plane,plane"
	],
	[
		607,
		"games.arnak.assistant607",
		"choice:s/travel:car",
		"choice:cs/travel:car,car"
	],
	[
		608,
		"games.arnak.assistant608",
		"choice:s/travel:boat",
		"choice:cs/travel:boat,boat"
	],
	[
		609,
		"games.arnak.assistant609",
		"choice:buy:item:1/buy:artifact:1",
		"choice:buy:item:2/buy:artifact:2"
	],
	[
		610,
		"games.arnak.assistant610",
		"upgrade",
		"upgrade;s"
	],
	[
		611,
		"games.arnak.assistant611",
		"s",
		"ss"
	]
].map(([e, t, n, r]) => ({
	id: Number(e),
	nameKey: t,
	silver: String(n),
	gold: String(r)
})), T = Object.fromEntries(re.map((e) => [e.id, e])), E = [
	"c",
	"c",
	"c",
	"s",
	"s",
	"s",
	"t",
	"t",
	"t",
	"exile",
	"exile",
	"exile",
	"upgrade",
	"upgrade",
	"refresh:1",
	"refresh:1"
], ie = [
	"c",
	"s",
	"t",
	"exile",
	"draw",
	"upgrade"
].flatMap((e) => [
	e,
	e,
	e
]), ae = [
	"ctt",
	"j",
	"sa",
	"cttj",
	"jsa",
	"cttjsa"
], D = [
	2,
	2,
	2,
	6,
	6,
	11
], oe = [
	{
		costs: [],
		next: [[0, 1]],
		glass: 0,
		book: 0,
		glassEffect: "",
		bookEffect: "",
		bonus: []
	},
	{
		costs: ["sa", "j"],
		next: [[0, 1], [1]],
		glass: 1,
		book: 0,
		glassEffect: "c",
		bookEffect: "recruit",
		bonus: []
	},
	{
		costs: ["j", "ta"],
		next: [[0], [0]],
		glass: 2,
		book: 1,
		glassEffect: "s",
		bookEffect: "promote",
		bonus: [2, 2]
	},
	{
		costs: ["tta"],
		next: [[
			0,
			1,
			2
		]],
		glass: 4,
		book: 2,
		glassEffect: "s",
		bookEffect: "recruit",
		bonus: [4]
	},
	{
		costs: [
			"cta",
			"tj",
			"aa"
		],
		next: [
			[0],
			[0],
			[0]
		],
		glass: 6,
		book: 4,
		glassEffect: "s",
		bookEffect: "promote",
		bonus: [
			2,
			2,
			2
		]
	},
	{
		costs: ["cj"],
		next: [[0, 1]],
		glass: 9,
		book: 6,
		glassEffect: "s",
		bookEffect: "sss",
		bonus: [4]
	},
	{
		costs: ["sj", "tta"],
		next: [[0], [0, 1]],
		glass: 12,
		book: 8,
		glassEffect: "draw",
		bookEffect: "freeArtifact",
		bonus: [2, 2]
	},
	{
		costs: ["cta", "tj"],
		next: [[0], [0]],
		glass: 16,
		book: 10,
		glassEffect: "s",
		bookEffect: "overcome",
		bonus: [3, 3]
	},
	{
		costs: ["csj"],
		next: [],
		glass: 0,
		book: 0,
		glassEffect: "",
		bookEffect: "",
		bonus: []
	}
], se = [
	{
		costs: [],
		next: [[0, 1]],
		glass: 0,
		book: 0,
		glassEffect: "",
		bookEffect: "",
		bonus: []
	},
	{
		costs: ["st", "j"],
		next: [[0, 1], [1, 2]],
		glass: 1,
		book: 0,
		glassEffect: "c",
		bookEffect: "recruit",
		bonus: []
	},
	{
		costs: [
			"csa",
			"tj",
			"aa"
		],
		next: [
			[0],
			[0, 1],
			[1]
		],
		glass: 2,
		book: 3,
		glassEffect: "cc",
		bookEffect: "exile",
		bonus: [
			2,
			3,
			2
		]
	},
	{
		costs: ["tta", "cj"],
		next: [[0], [0]],
		glass: 3,
		book: 4,
		glassEffect: "draw",
		bookEffect: "promote",
		bonus: [2, 2]
	},
	{
		costs: ["idol"],
		next: [[0, 1]],
		glass: 4,
		book: 5,
		glassEffect: "rescue",
		bookEffect: "freeArtifact",
		bonus: []
	},
	{
		costs: ["aa", "tj"],
		next: [[0, 1], [1]],
		glass: 5,
		book: 8,
		glassEffect: "promote",
		bookEffect: "refresh:1",
		bonus: [4, 4]
	},
	{
		costs: ["tj", "sttt"],
		next: [[0], [0]],
		glass: 10,
		book: 12,
		glassEffect: "fear",
		bookEffect: "draw",
		bonus: [2, 2]
	},
	{
		costs: ["cta"],
		next: [[0]],
		glass: 15,
		book: 15,
		glassEffect: "overcome",
		bookEffect: "j",
		bonus: []
	},
	{
		costs: ["saj"],
		next: [],
		glass: 0,
		book: 0,
		glassEffect: "",
		bookEffect: "",
		bonus: []
	}
], ce = {
	id: "arnak",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"deck-bag-building",
		"race"
	],
	interactionTags: [],
	nameKey: "games.arnak.name",
	descKey: "games.arnak.desc",
	rulesKey: "games.arnak.rules",
	icon: "🗿",
	iconImg: "games/arnak.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1862807004109932371/9A4D586E437791451A40777E19146716284F95AF/" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#287c77",
	releasedAt: "2026-11-04T21:50:39+08:00",
	search: {
		py: "a na ke yi ji lost ruins of arnak",
		init: "ankyjlroa"
	},
	hotseat: "cover"
}, O = t.object({
	temple: t.enum(["bird", "snake"]).default("bird"),
	rivalDifficulty: t.int().min(0).max(5).default(0)
}).prefault({}), le = t.discriminatedUnion("type", [t.object({
	type: t.literal("move"),
	id: t.string().min(1).max(600)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), k = t.object({
	c: t.int().nonnegative(),
	s: t.int().nonnegative(),
	t: t.int().nonnegative(),
	a: t.int().nonnegative(),
	j: t.int().nonnegative()
}), A = t.enum([
	"boot",
	"car",
	"boat",
	"plane"
]), ue = t.object({
	id: t.int(),
	gold: t.boolean(),
	ready: t.boolean()
}), j = t.object({
	row: t.int().min(0).max(8),
	col: t.int().nonnegative()
}), de = t.object({
	research: t.int(),
	temple: t.int(),
	idols: t.int(),
	slots: t.int(),
	guardians: t.int(),
	cards: t.int(),
	fear: t.int(),
	total: t.int()
}), fe = t.object({
	rid: t.string(),
	resources: k,
	handCount: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	played: t.array(t.string()),
	assistants: t.array(ue),
	idols: t.array(t.string()),
	usedIdols: t.array(t.string()),
	guardians: t.array(t.object({
		id: t.int(),
		ready: t.boolean()
	})),
	glass: j,
	book: j,
	templePoints: t.int(),
	templeTiles: t.array(t.int()),
	passed: t.boolean(),
	freeWorkers: t.int(),
	score: de
}), pe = t.object({
	id: t.int(),
	level: t.int().min(0).max(2),
	tile: t.int().nullable(),
	guardian: t.int().nullable(),
	workers: t.array(t.string().nullable()),
	blocked: t.array(t.boolean()),
	travel: t.array(t.array(A)),
	idols: t.array(t.string())
}), M = t.object({
	key: t.string(),
	vars: t.record(t.string(), t.union([t.string(), t.number()]))
}), N = t.object({
	id: t.string(),
	label: M,
	target: t.string(),
	kind: t.string(),
	value: t.number(),
	cards: t.array(t.string()),
	cost: t.string(),
	remainingTravel: t.array(A).optional()
}), me = t.object({
	config: O,
	round: t.int().min(1).max(5),
	phase: t.enum([
		"play",
		"rival",
		"return",
		"cleanup",
		"done"
	]),
	turn: t.string(),
	start: t.string(),
	mainUsed: t.boolean(),
	players: t.array(fe),
	sites: t.array(pe),
	items: t.array(t.string()),
	artifacts: t.array(t.string()),
	itemCount: t.int(),
	artifactCount: t.int(),
	assistantStacks: t.array(t.object({
		top: t.int().nullable(),
		count: t.int()
	})),
	rescueTop: t.int().nullable(),
	rescueCount: t.int(),
	bonuses: t.record(t.string(), t.array(t.string())),
	templeTiles: t.array(t.int()),
	templeOrder: t.array(t.string()),
	exile: t.array(t.string()),
	log: t.array(t.object({
		rid: t.string(),
		label: M
	})),
	pending: t.string(),
	revealed: t.array(t.string()),
	rival: t.object({
		glass: j,
		idols: t.array(t.string()),
		cards: t.array(t.string()),
		guardians: t.array(t.int()),
		templePoints: t.int(),
		templeTiles: t.array(t.int()),
		actionsLeft: t.int(),
		score: t.int()
	}).nullable()
}), he = t.object({
	hand: t.array(t.string()),
	moves: t.array(N),
	travel: t.array(A),
	revealed: t.array(t.string()),
	rescue: t.array(t.int())
}), P = "$rival", ge = () => ({
	c: 0,
	s: 0,
	t: 0,
	a: 0,
	j: 0
}), F = (e) => e.config.temple === "bird" ? oe : se, I = (e, t = {}) => ({
	key: e,
	vars: t
}), L = (e, t, n = e.turn) => {
	e.log.push({
		rid: n,
		label: t
	});
};
function R(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var z = (e, t, n = "", r) => {
	let i = t.split(";").filter(Boolean).map((e) => ({
		effect: e,
		source: n,
		...r ? { arg: r } : {}
	}));
	e.tasks.unshift(...i);
}, B = (e, t) => b.every((n) => e.resources[n] >= [...t].filter((e) => e === n).length), V = (e, t) => {
	for (let n of t) b.includes(n) && e.resources[n]--;
}, _e = (e, t) => {
	for (let n of t) b.includes(n) && e.resources[n]++;
};
function H(e, t = 1, n = !1) {
	let r = [];
	for (let i = 0; i < t; i++) {
		let t = n ? e.deck.pop() : e.deck.shift();
		t && (e.hand.push(t), r.push(t));
	}
	return r;
}
function U(e, t) {
	e.fearSupply > 0 ? (t.played.push("fear"), e.fearSupply--) : t.played.push("fear-tile");
}
function ve(e, t, n, r) {
	let [i] = t[n].splice(r, 1);
	i === "fear" ? e.fearSupply++ : (y[i].kind === "item" || y[i].kind === "artifact") && e.exile.push(i);
}
function ye(e) {
	for (; e.artifacts.length < e.round && e.artifactDeck.length;) e.artifacts.push(e.artifactDeck.shift());
	for (; e.items.length < 6 - e.round && e.itemDeck.length;) e.items.unshift(e.itemDeck.shift());
}
function be(e) {
	let t = R(e, [
		0,
		1,
		2,
		3,
		4
	]).slice(0, e.players.length <= 2 ? 5 : e.players.length === 3 ? 3 : 0);
	for (let n = 0; n < 5; n++) e.sites.push({
		id: n,
		level: 0,
		tile: null,
		guardian: null,
		workers: [null, null],
		blocked: [!1, t.includes(n)],
		travel: [["boot"], ["boot", "boot"]],
		idols: []
	});
	let n = R(e, E);
	for (let t = 0; t < 12; t++) {
		let r = t < 8 ? 1 : 2, i = r === 1 ? [t % 4 < 2 ? "car" : "boat"] : [t % 4 < 2 ? "car" : "boat", t % 4 < 2 ? "car" : "boat"];
		e.config.temple === "snake" && (t === 5 && i.splice(0, i.length, "boot"), t === 6 && i.splice(0, i.length, "plane"), t === 9 && i.splice(0, i.length, "boot", "plane"), t === 10 && i.splice(0, i.length, "car", "boat"));
		let a = n.splice(0, r === 1 ? 1 : 2);
		e.sites.push({
			id: t + 5,
			level: r,
			tile: null,
			guardian: null,
			workers: [null],
			blocked: [!1],
			travel: [i],
			idols: r === 2 ? [a[0], "$back"] : a
		});
	}
}
function xe(e, t, n) {
	let r = {
		config: O.parse(e),
		players: t,
		people: {},
		seed: n,
		cursor: 0,
		round: 1,
		phase: "play",
		turn: t[0],
		start: 0,
		mainUsed: !1,
		sites: [],
		items: [],
		artifacts: [],
		itemDeck: [],
		artifactDeck: [],
		sites1: [],
		sites2: [],
		guardianDeck: [],
		assistantStacks: [],
		rescue: [],
		bonuses: {},
		templeTiles: [],
		templeOrder: [],
		exile: [],
		tasks: [],
		revealed: [],
		travel: [],
		fearSupply: 19,
		cleanupAt: 0,
		rival: null,
		log: [],
		beat: 480
	};
	r.itemDeck = R(r, Object.values(y).filter((e) => e.kind === "item").map((e) => e.id)), r.artifactDeck = R(r, Object.values(y).filter((e) => e.kind === "artifact").map((e) => e.id)), r.sites1 = R(r, x.filter((e) => e.id >= 1800).map((e) => e.id)), r.sites2 = R(r, x.filter((e) => e.id < 1800).map((e) => e.id)), r.guardianDeck = R(r, C.map((e) => e.id));
	let i = R(r, re.map((e) => e.id)), a = Math.max(2, t.length);
	r.config.temple === "snake" && (r.rescue = i.splice(0, a)), r.assistantStacks = [
		i.splice(0, r.config.temple === "snake" ? 3 : 4),
		i.splice(0, r.config.temple === "snake" ? 3 : 4),
		i
	];
	let o = R(r, ie);
	if (F(r).forEach((e, t) => e.bonus.forEach((e, n) => {
		a >= e && (r.bonuses[`${t}:${n}`] = [o.shift()]);
	})), r.config.temple === "snake" && (r.bonuses["7:0"] = o.splice(0, a >= 3 ? 3 : 2)), r.bonuses["8:0"] = o.splice(0, a), r.templeTiles = [
		a,
		a,
		a,
		a,
		a,
		a
	], t.forEach((e, n) => {
		let i = t.length === 1 ? 1 : n, a = ge();
		a.c = i % 2 == 0 ? 2 : 1, a.s = [
			0,
			1,
			1,
			2
		][i];
		let o = R(r, [
			"fund-car",
			"fund-boat",
			"explore-car",
			"explore-boat",
			"fear",
			"fear"
		]);
		r.fearSupply -= 2;
		let s = {
			rid: e,
			resources: a,
			deck: o,
			hand: [],
			played: [],
			assistants: [],
			idols: [],
			usedIdols: [
				"",
				"",
				"",
				""
			],
			guardians: [],
			glass: {
				row: 0,
				col: 0
			},
			book: {
				row: 0,
				col: 0
			},
			templePoints: 0,
			templeTiles: [],
			passed: !1,
			freeWorkers: 2,
			allPlanes: !1,
			noFear: !1
		};
		H(s, 5), r.people[e] = s;
	}), be(r), ye(r), t.length === 1) {
		let e = new Set(R(r, [
			"discover",
			"research",
			"guardian",
			"item",
			"artifact"
		]).slice(0, r.config.rivalDifficulty)), t = [
			1,
			0,
			1,
			0,
			1,
			0,
			1,
			0,
			1,
			0
		], n = [
			"c",
			"s",
			"t",
			"a",
			"j"
		].map((e, n) => `dig:${e}:${t[n]}`);
		[
			"discover",
			"research",
			"guardian",
			"item",
			"artifact"
		].forEach((r, i) => n.push(`${r}:${e.has(r) ? "red" : "green"}:${t[i + 5]}`)), r.rival = {
			glass: {
				row: 0,
				col: 0
			},
			idols: [],
			cards: [],
			guardians: [],
			templePoints: 0,
			templeTiles: [],
			deck: n,
			stack: R(r, n),
			used: []
		}, r.phase = "rival";
	}
	return L(r, I("games.arnak.logArrival")), {
		state: r,
		fx: []
	};
}
var Se = (e, t) => e === "plane" || e === t || t === "boot";
function Ce(e, t) {
	if (!t.length) return [[...e]];
	let n = [];
	return e.forEach((r, i) => {
		Se(r, t[0]) && n.push(...Ce(e.filter((e, t) => i !== t), t.slice(1)));
	}), n.filter((e, t, n) => n.findIndex((t) => t.join() === e.join()) === t);
}
function we(e, t, n, r) {
	let i = [{
		cards: [],
		pool: t.map((t) => e.allPlanes ? "plane" : t),
		next: 0
	}], a = [];
	for (let t = 0; t <= n.length; t++) {
		let o = [];
		for (let s of i) {
			for (let e = 0; e <= n.length * 2 && e <= r; e += 2) for (let t of Ce([...s.pool, ...Array(e / 2).fill("plane")], n)) a.push({
				cards: s.cards,
				coins: e,
				remaining: t
			});
			if (t !== n.length) for (let t = s.next; t < e.hand.length; t++) {
				let n = y[e.hand[t]].travel.map((t) => e.allPlanes ? "plane" : t);
				n.length && o.push({
					cards: [...s.cards, t],
					pool: [...s.pool, ...n],
					next: t + 1
				});
			}
		}
		i = o;
	}
	let o = a.filter((e, t, n) => n.findIndex((t) => t.cards.join() === e.cards.join() && t.coins === e.coins && t.remaining.join() === e.remaining.join()) === t);
	return o.filter((e) => !o.some((t) => t.cards.length < e.cards.length && t.cards.every((t) => e.cards.includes(t)) && t.coins <= e.coins && t.remaining.length >= e.remaining.length));
}
function Te(e, t, n) {
	t.resources.c -= n.coins, e.travel = n.remaining;
	for (let e of [...n.cards].sort((e, t) => t - e)) t.played.push(t.hand.splice(e, 1)[0]);
}
function W(e, t) {
	z(e, t.level === 0 ? [
		"cc",
		"ss",
		"tt",
		"a",
		"discard;j"
	][t.id] : S[t.tile].effect, `site:${t.id}`);
}
function Ee(e, t, n, r = !0) {
	n.tile = (n.level === 1 ? e.sites1 : e.sites2).shift() ?? null;
	let i = n.idols.splice(0);
	return t.idols.push(...i), r && (n.guardian = e.guardianDeck.shift() ?? null), i[0];
}
function De(e, t, n, r = "deck") {
	let i = y[n], a = i.kind === "item" ? e.items : e.artifacts, o = i.kind === "item" ? e.itemDeck : e.artifactDeck;
	a.includes(n) ? a.splice(a.indexOf(n), 1) : o[0] === n && o.shift(), r === "hand" ? t.hand.push(n) : r === "top" ? t.deck.unshift(n) : i.kind === "item" ? t.deck.push(n) : (t.played.push(n), z(e, i.effect, n)), L(e, I("games.arnak.logGained", { name: "$card:" + i.id }));
}
function Oe(e, t, n, r, i = !1) {
	n.workers[r] = null, t.freeWorkers++, i && n.guardian && !t.noFear && U(e, t);
}
function ke(e) {
	if (ye(e), e.travel = [], e.mainUsed = !1, e.revealed = [], e.players.every((t) => e.people[t].passed)) {
		if (e.rival?.stack.length) {
			e.phase = "rival";
			return;
		}
		e.phase = "return";
		return;
	}
	if (e.rival?.stack.length) {
		e.phase = "rival";
		return;
	}
	let t = e.players.indexOf(e.turn);
	for (let n = 1; n <= e.players.length; n++) {
		let r = e.players[(t + n) % e.players.length];
		if (!e.people[r].passed) {
			e.turn = r;
			break;
		}
	}
}
function Ae(e, t, n, r, i) {
	for (let a of ["glass", "book"]) {
		if (n !== "either" && n !== a) continue;
		let o = t[a], s = o.row + 1;
		if (s > 8 || a === "book" && (s > t.glass.row || s === 8)) continue;
		let c = F(e)[o.row].next[o.col] ?? [];
		for (let n of c) {
			let o = F(e)[s].costs[n];
			if (o !== "idol" || t.idols.length || r === "free") {
				if (r === "free") o = "";
				else for (let e of r) o = o.replace(e, "");
				(o === "idol" || B(t, o)) && i({
					label: I("games.arnak.advanceResearch", {
						name: "$" + a,
						n: s
					}),
					target: `research:${s}:${n}`,
					kind: "research",
					value: s * .4 + (a === "book" && s <= 4 ? 3 : 0),
					cards: [],
					cost: o,
					run: (e) => {
						let t = e.people[e.turn];
						o === "idol" ? t.idols.shift() : V(t, o), t[a] = {
							row: s,
							col: n
						}, s === 8 && (t.templePoints = [
							23,
							21,
							20,
							19
						][e.templeOrder.length], e.templeOrder.push(e.turn));
						let r = e.bonuses[`${s}:${n}`], i = [F(e)[s][a === "glass" ? "glassEffect" : "bookEffect"], r?.length ? `researchBonus:${s}:${n}` : ""].filter(Boolean);
						z(e, i.length > 1 ? `order:${i.join("|")}` : i.join(""), "research"), L(e, I("games.arnak.logResearch", { name: "$" + a }));
					}
				}, `${a}:${s}:${n}:${r}`);
			}
		}
	}
	n !== "book" && t.glass.row === 8 && e.templeTiles.forEach((e, n) => {
		if (!e) return;
		let a = ae[n];
		if (r === "free") a = "";
		else for (let e of r) a = a.replace(e, "");
		B(t, a) && i({
			label: I("games.arnak.buyTemple", { n: D[n] }),
			target: `temple:${n}`,
			kind: "temple",
			value: D[n] * .7,
			cards: [],
			cost: a,
			run: (e) => {
				V(e.people[e.turn], a), e.templeTiles[n]--, e.people[e.turn].templeTiles.push(n);
			}
		}, `temple:${n}:${r}`);
	});
}
function je(e, t, n, r, i, a = !1) {
	t.freeWorkers && e.sites.forEach((o) => {
		a && o.level !== 0 || o.workers.forEach((s, c) => {
			if (s || o.blocked[c]) return;
			let l = o.level > 0 && o.tile === null, u = "s".repeat(l ? Math.max(0, (o.level === 1 ? 3 : 6) - r) : 0);
			if (!B(t, u)) return;
			let d = [...o.travel[c]];
			if (a) d = [];
			else if (n) {
				let e = d.findIndex((e) => Se(n, e));
				e >= 0 && d.splice(e, 1);
			}
			we(t, e.travel, d, t.resources.c).forEach((e, n) => {
				let r = e.cards.map((e) => t.hand[e]);
				i({
					label: I(l ? "games.arnak.discoverSite" : "games.arnak.deployWorker", { n: o.level }),
					target: `site:${o.id}`,
					kind: l ? "discover" : "dig",
					value: l ? 5 + o.level : 2,
					cards: r,
					cost: u + "c".repeat(e.coins),
					remainingTravel: e.remaining,
					run: (t) => {
						let n = t.people[t.turn];
						Te(t, n, e), V(n, u), n.freeWorkers--;
						let r = t.sites[o.id];
						if (r.workers[c] = t.turn, l) {
							let e = Ee(t, n, r);
							z(t, `order:rewardSite:${r.id}|rewardIdol:${e}`, "discovery");
						} else W(t, r);
						a && W(t, r), L(t, I("games.arnak.logExpedition", { name: l ? "$discovery" : "$deployment" }));
					}
				}, `site:${o.id}:${c}:${n}`);
			});
		});
	});
}
function Me(e, t, n, r, i) {
	for (let a of e.sites) {
		if (!a.guardian || (r ? a.workers.some((e) => e && e !== t.rid) : !a.workers.includes(t.rid))) continue;
		let o = w[a.guardian], s = n ? "" : o.cost.replace("discard;", "");
		B(t, s) && (n || !o.cost.includes("discard") || t.hand.length) && we(t, e.travel, n ? [] : o.travel, t.resources.c - s.split("c").length + 1).forEach((r, c) => {
			!n && o.cost.includes("discard") && r.cards.length >= t.hand.length || (!n && o.cost.includes("discard") ? t.hand.map((e, t) => t).filter((e) => !r.cards.includes(e)) : [-1]).forEach((n) => i({
				label: I("games.arnak.overcomeGuardian", { name: "$guardian:" + o.id }),
				target: `guardian:${a.id}`,
				kind: "overcome",
				value: 6 + +(e.round < 5),
				cards: [...r.cards.map((e) => t.hand[e]), ...n >= 0 ? [t.hand[n]] : []],
				cost: s + "c".repeat(r.coins),
				remainingTravel: r.remaining,
				run: (e) => {
					let t = e.people[e.turn], i = [...r.cards, ...n >= 0 ? [n] : []];
					t.resources.c -= r.coins, e.travel = r.remaining;
					for (let e of i.sort((e, t) => t - e)) t.played.push(t.hand.splice(e, 1)[0]);
					V(t, s), t.guardians.push({
						id: a.guardian,
						ready: !0
					}), e.sites[a.id].guardian = null;
				}
			}, `guardian:${a.id}:${c}:${n}`));
		});
	}
}
var G = (e, t, n = "", r = 0, i = "effect", a = "", o = []) => ({
	label: e,
	run: t,
	target: n,
	value: r,
	kind: i,
	cost: a,
	cards: o
});
function Ne(e, t, n, r, i, a = !1, o = "deck") {
	let s = n === "item" ? e.items : e.artifacts, c = a ? (n === "item" ? e.itemDeck : e.artifactDeck).slice(0, 1) : [];
	for (let a of [...s, ...c]) {
		let s = y[a], c = (n === "item" ? "c" : "s").repeat(Math.max(0, s.cost - r));
		B(t, c) && i(G(I("games.arnak.buyCard", { name: "$card:" + s.id }), (e) => {
			V(e.people[e.turn], c), De(e, e.people[e.turn], a, o);
		}, `market:${a}`, s.points * .7 + (6 - e.round) * .65, "buy", c), `buy:${a}:${o}`);
	}
}
function Pe(e, t, n) {
	if (!t.passed && (t.hand.forEach((e, t) => {
		let r = y[e];
		(r.kind === "starter" || te.has(e)) && n(G(I("games.arnak.playCard", { name: "$card:" + r.id }), (n) => {
			let i = n.people[n.turn];
			i.played.push(i.hand.splice(t, 1)[0]), z(n, r.effect, e);
		}, `hand:${t}`, 2, "free", "", [e]), `free:${t}`);
	}), t.assistants.forEach((e, t) => {
		if (!e.ready || e.id === 609) return;
		let r = T[e.id];
		n(G(I("games.arnak.useAssistant", { name: "$assistant:" + r.id }), (n) => {
			n.people[n.turn].assistants[t].ready = !1, z(n, e.gold ? r.gold : r.silver, `assistant:${e.id}`);
		}, `assistant:${t}`, 2.2, "assistant"), `assistant:${t}`);
	}), t.guardians.forEach((e, t) => {
		if (!e.ready) return;
		let r = w[e.id];
		n(G(I("games.arnak.useBoon", { name: "$guardian:" + r.id }), (e) => {
			e.people[e.turn].guardians[t].ready = !1, z(e, [
				"boot",
				"car",
				"boat",
				"plane"
			].includes(r.boon) ? `travel:${r.boon}` : r.boon, "boon");
		}, `boon:${t}`, 1.1, "boon"), `boon:${t}`);
	}), t.idols.length && t.usedIdols.some((e) => !e))) for (let e of [
		"trade:c>j",
		"a",
		"tt",
		"draw",
		"upgrade"
	]) n(G(I("games.arnak.useIdol"), (t) => {
		let n = t.people[t.turn];
		n.usedIdols[n.usedIdols.findIndex((e) => !e)] = n.idols.shift(), z(t, e, "idolSlot");
	}, `idol:${e}`, 1.5 - t.usedIdols.filter(Boolean).length * .4, "idol"), `idol:${e}`);
}
function Fe(e) {
	let t = e.tasks[0];
	if (!t) return [];
	let n = e.people[e.turn], r = t.effect, i = [], a = (e, t) => i.push({
		...e,
		id: `task:${t}`,
		run: (t) => {
			t.tasks.shift(), e.run(t);
		}
	}), o = (e, n) => z(e, n, t.source, t.arg), [s, c, l, u] = r.split(":");
	if (s === "choice" || s === "order") {
		let n = r.slice(s.length + 1).split(s === "choice" ? "/" : "|");
		n.forEach((r, i) => {
			r.startsWith("pass") && e.mainUsed && t.source !== "0235" || a(G(I("games.arnak.chooseEffect"), (e) => {
				if (s === "order") {
					let t = n.filter((e, t) => t !== i);
					o(e, [r, ...t].join(";"));
				} else o(e, r);
			}, `effect:${r}`, 1, "choose", "", []), `choice:${i}:${r}`);
		});
	} else if (s === "draw" || s === "drawBottom" || s === "drawDiscard") {
		let e = Math.min(s === "drawDiscard" ? 1 : Number(c ?? 1), n.deck.length);
		for (let n = 1; n <= e; n++) a(G(I(s === "drawDiscard" ? "games.arnak.drawDiscard" : "games.arnak.drawN", { n }), (e) => {
			H(e.people[e.turn], n, s === "drawBottom"), s === "drawDiscard" && z(e, "discardRequired", t.source);
		}, "deck", n * 1.5, "draw"), `draw:${n}`);
	} else if (s === "discard" || s === "discardRequired" || s === "exile") for (let e of s === "exile" ? ["hand", "played"] : ["hand"]) n[e].forEach((t, n) => {
		a(G(I("games.arnak.removeCard", {
			action: s === "exile" ? "$exile" : "$discard",
			name: "$card:" + t
		}), (t) => {
			let r = t.people[t.turn];
			s === "exile" ? ve(t, r, e, n) : r.played.push(r.hand.splice(n, 1)[0]);
		}, `${e}:${n}`, y[t].kind === "fear" ? 4 : -1 - y[t].points, s, "", [t]), `${s}:${e}:${n}`);
	});
	else if (s === "trade") {
		let [e, t] = r.slice(6).split(">");
		B(n, e) && a(G(I("games.arnak.trade"), (n) => {
			V(n.people[n.turn], e), o(n, t);
		}, `effect:${t}`, 1.8, "trade", e), `trade:${t}`);
	} else if (s === "travelTrade") {
		let [t, r] = c.split(">");
		we(n, e.travel, [t], n.resources.c).forEach((e, t) => a({
			...G(I("games.arnak.travelTrade"), (t) => {
				Te(t, t.people[t.turn], e), o(t, r);
			}, `effect:${r}`, 1.5, "trade", "c".repeat(e.coins), e.cards.map((e) => n.hand[e])),
			remainingTravel: e.remaining
		}, `travelTrade:${t}`));
	} else if (s === "upgrade") for (let [e, t] of [["t", "a"], ["a", "j"]]) n.resources[e] && a(G(I("games.arnak.upgradeResource"), (n) => {
		let r = n.people[n.turn];
		r.resources[e]--, r.resources[t]++;
	}, `upgrade:${e}:${t}`, 2, "upgrade", e), `upgrade:${e}`);
	else if (s === "recruit" || s === "rescue") s === "rescue" ? e.rescue.forEach((e, t) => a(G(I("games.arnak.rescueAssistant", { name: "$assistant:" + e }), (n) => {
		n.rescue.splice(t, 1), n.people[n.turn].assistants.push({
			id: e,
			gold: !1,
			ready: !1
		});
	}, `rescue:${e}`, 2, "recruit"), `rescue:${e}`)) : e.assistantStacks.forEach((t, n) => {
		let r = t[0];
		r && a(G(I("games.arnak.recruitAssistant", { name: "$assistant:" + r }), (e) => {
			e.assistantStacks[n].shift(), e.people[e.turn].assistants.push({
				id: r,
				gold: !1,
				ready: !0
			});
		}, `recruit:${n}`, 5 - e.round * .5, "recruit"), `recruit:${n}`);
	});
	else if (s === "promote" || s === "refresh") n.assistants.forEach((e, n) => {
		if (s === "promote" ? e.gold : e.ready) return;
		let r = T[e.id];
		a(G(I("games.arnak.refreshAssistant", {
			action: s === "promote" ? "$promote" : "$refresh",
			name: "$assistant:" + r.id
		}), (e) => {
			let r = e.people[e.turn];
			r.assistants[n].ready = !0, s === "promote" ? r.assistants[n].gold = !0 : Number(c) > 1 && z(e, `refresh:${Number(c) - 1}`, t.source, String(n));
		}, `assistant:${n}`, 3, s), `${s}:${n}`);
	});
	else if (s === "research") {
		if (l === "discount") for (let t of ["a", "tt"]) Ae(e, n, c, t, a);
		else Ae(e, n, c, l ?? "", a);
	} else if (s === "overcome" || s === "trap") Me(e, n, !0, s === "trap", a);
	else if (s === "expedition" || s === "shell") je(e, n, s === "shell" ? null : c, Number(l ?? 0), a, s === "shell");
	else if (s === "buy" || s === "freeArtifact" || s.startsWith("gainItem")) Ne(e, n, s.startsWith("gainItem") ? "item" : s === "freeArtifact" ? "artifact" : c, s === "buy" ? Number(l) : 99, a, u === "top", s === "gainItemHand" ? "hand" : s === "gainItemTop" ? "top" : "deck");
	else if (s === "activate" || s === "tent" || s === "twoCamps") e.sites.forEach((e) => {
		if (e.level > 0 && e.tile === null || s === "activate" && e.level !== Number(c) || s === "twoCamps" && (e.level !== 0 || String(e.id) === t.arg) || l === "empty" && e.workers.some(Boolean) || s === "tent" && !e.workers.includes(n.rid)) return;
		let r = s === "tent" && e.level === 2 ? "ss" : "";
		B(n, r) && a(G(I("games.arnak.activateSite"), (n) => {
			V(n.people[n.turn], r), s === "twoCamps" && !t.arg && z(n, "twoCamps", t.source, String(e.id)), W(n, n.sites[e.id]);
		}, `site:${e.id}`, e.level + 2, "activate", r), `activate:${e.id}`);
	});
	else if (s === "relocate") for (let t of e.sites) t.workers.forEach((r, i) => {
		r === n.rid && e.sites.forEach((e) => {
			e.id === t.id || e.level > Number(c) || e.level > 0 && !e.tile || e.workers.forEach((r, o) => {
				r || e.blocked[o] || a(G(I("games.arnak.relocateWorker", { n: t.id + 1 }), (r) => {
					r.sites[t.id].workers[i] = null, r.sites[e.id].workers[o] = n.rid, W(r, r.sites[e.id]);
				}, `site:${e.id}`, 3, "relocate"), `relocate:${t.id}:${i}:${e.id}:${o}`);
			});
		});
	});
	else if (s === "returnWorker") e.sites.forEach((e) => e.workers.forEach((t, r) => {
		t === n.rid && a(G(I("games.arnak.returnWorker"), (t) => Oe(t, t.people[t.turn], t.sites[e.id], r), `site:${e.id}`, 4, "return"), `return:${e.id}:${r}`);
	}));
	else if (s === "moveGuardian") {
		for (let t of e.sites) if (t.guardian && t.workers.includes(n.rid)) for (let n of e.sites) n.level > 1 || n.level > 0 && !n.tile || n.guardian || n.workers.some(Boolean) || a(G(I("games.arnak.moveGuardian"), (e) => {
			e.sites[n.id].guardian = t.guardian, e.sites[t.id].guardian = null, W(e, e.sites[n.id]);
		}, `guardian:${n.id}`, 2, "guardian"), `moveGuardian:${t.id}:${n.id}`);
	} else if (s === "returnIdol") n.usedIdols.forEach((e, t) => {
		e && a(G(I("games.arnak.returnIdol"), (e) => {
			let n = e.people[e.turn];
			n.idols.push(n.usedIdols[t]), n.usedIdols[t] = "";
		}, `idolSlot:${t}`, t + 1, "idol"), `returnIdol:${t}`);
	});
	else if (s === "exchangeAssistant") n.assistants.forEach((t, n) => e.assistantStacks.forEach((e, r) => {
		let i = e[0];
		i && a(G(I("games.arnak.exchangeAssistant", {
			old: "$assistant:" + t.id,
			name: "$assistant:" + i
		}), (e) => {
			e.assistantStacks[r][0] = t.id, e.people[e.turn].assistants[n] = {
				id: i,
				gold: t.gold,
				ready: !0
			};
		}, `recruit:${r}`, t.ready ? 0 : 2, "exchange"), `exchange:${n}:${r}`);
	}));
	else if (s === "copyGold" || s === "copySilver") e.assistantStacks.forEach((e, t) => {
		let n = T[e[0]];
		n && a(G(I("games.arnak.copyAssistant", { name: "$assistant:" + n.id }), (e) => o(e, s === "copyGold" ? n.gold : n.silver), `recruit:${t}`, 2, "copy"), `copy:${n.id}`);
	});
	else if (s === "knife") for (let e of [
		"c",
		"s",
		"t",
		"exile"
	]) t.chosen?.includes(e) || a(G(I("games.arnak.chooseBenefit"), (n) => {
		t.chosen?.length || n.tasks.unshift({
			...t,
			chosen: [e]
		}), o(n, e);
	}, `effect:${e}`, 1, "choose"), `knife:${e}`);
	else if (s === "researchBonus") {
		let t = `${c}:${l}`;
		e.bonuses[t]?.forEach((e, n) => a(G(I("games.arnak.takeBonus"), (r) => {
			r.bonuses[t].splice(n, 1), o(r, e);
		}, `effect:${e}`, 1.5, "bonus"), `bonus:${n}`));
	} else if (s === "scry" || s === "scryBottom") for (let e = 1; e <= Math.min(Number(c), n.deck.length); e++) a(G(I("games.arnak.lookCards", { n: e }), (n) => {
		let r = n.people[n.turn];
		n.revealed = s === "scry" ? r.deck.splice(0, e) : r.deck.splice(-e).reverse(), z(n, s === "scry" ? "keepScry" : "keepBottom", t.source);
	}, "deck", e * .3, "scry"), `scry:${e}`);
	else if (s === "keepScry" || s === "keepBottom") e.revealed.forEach((e, n) => a(G(I("games.arnak.keepCard", { name: "$card:" + e }), (e) => {
		e.people[e.turn].hand.push(e.revealed.splice(n, 1)[0]), s === "keepScry" && e.revealed.length ? z(e, "topScry", t.source) : (e.people[e.turn].played.push(...e.revealed), e.revealed = []);
	}, `revealed:${n}`, y[e].kind === "fear" ? -2 : y[e].cost + 1, "keep", "", [e]), `keep:${n}`));
	else if (s === "topScry") e.revealed.forEach((e, t) => a(G(I("games.arnak.topCard", { name: "$card:" + e }), (e) => {
		e.people[e.turn].deck.unshift(e.revealed.splice(t, 1)[0]), e.people[e.turn].played.push(...e.revealed), e.revealed = [];
	}, `revealed:${t}`, y[e].kind === "fear" ? -2 : y[e].cost * .5, "top", "", [e]), `top:${t}`));
	else if (s === "exileItem") e.exile.forEach((e, t) => {
		y[e].kind === "item" && a(G(I("games.arnak.gainCard", { name: "$card:" + e }), (n) => {
			n.exile.splice(t, 1), n.people[n.turn].deck.push(e);
		}, `market:${e}`, y[e].cost * .4 + y[e].points, "buy"), `exileItem:${t}`);
	});
	else return null;
	return s !== "keepScry" && s !== "keepBottom" && (s !== "discardRequired" || !n.hand.length) && a(G(I("games.arnak.skip"), (e) => {
		s === "discard" && (e.tasks = e.tasks.filter((e) => e.source !== t.source)), s === "topScry" && (e.people[e.turn].played.push(...e.revealed), e.revealed = []);
	}, "", -10, "skip"), "skip"), i;
}
function Ie(e) {
	let t = e.tasks.shift(), n = e.people[e.turn], r = t.effect, [i, a] = r.split(":");
	if (/^[cstaj]+$/.test(r)) _e(n, r);
	else if (i === "draw" || i === "drawBottom") H(n, Number(a ?? 1), i === "drawBottom");
	else if (i === "fear") U(e, n);
	else if (i === "rewardSite") W(e, e.sites[Number(a)]);
	else if (i === "rewardIdol") z(e, r.slice(11), "idol");
	else if (i === "travel") e.travel.push(...a.split(","));
	else if (i === "exileSelf") {
		let r = n.played.lastIndexOf(t.source);
		r >= 0 && ve(e, n, "played", r);
	} else if (i === "allPlanes") n.allPlanes = !0;
	else if (i === "noFear") n.noFear = !0;
	else if (i === "guardiansCompass") n.resources.s += Math.min(3, n.guardians.length + e.sites.filter((e) => e.guardian && e.workers.includes(n.rid)).length);
	else if (i === "idolsCompass") n.resources.s += Math.min(3, n.idols.length + n.usedIdols.filter(Boolean).length);
	else if (i === "workersCompass") n.resources.s += 2 - n.freeWorkers;
	else if (i === "revealSite" || i === "revealSite2") {
		let t = i === "revealSite2" || a === "2" ? e.sites2 : e.sites1;
		if (t.length) {
			let n = t.shift();
			t.push(n), z(e, S[n].effect, `siteTile:${n}`);
		}
	} else if (i === "hammer") e.items.length && e.exile.push(e.items.pop()), z(e, "exileItem", t.source);
	else if (i.startsWith("pass")) _e(n, i.slice(4)), n.passed = !0, e.mainUsed = !0, z(e, "finishPass", t.source);
	else if (i === "finishPass") ke(e);
	else throw Error(`Unimplemented effect: ${r}`);
}
function Le(e) {
	if (e.phase === "cleanup") return [...e.people[e.turn].hand.map((e, t) => ({
		...G(I("games.arnak.discardCard", { name: "$card:" + e }), (e) => {
			let n = e.people[e.turn];
			n.played.push(n.hand.splice(t, 1)[0]);
		}, `hand:${t}`, y[e].kind === "fear" ? 1 : -1, "cleanup", "", [e]),
		id: `cleanup:discard:${t}`
	})), {
		...G(I("games.arnak.prepareRound"), (e) => {
			let t = e.people[e.turn];
			t.deck.push(...R(e, t.played.filter((e) => e !== "fear-tile"))), t.played = t.played.filter((e) => e === "fear-tile"), H(t, Math.max(0, 5 - t.hand.length)), t.assistants.forEach((e) => {
				e.ready = !0;
			}), t.passed = !1, t.allPlanes = !1, t.noFear = !1, e.cleanupAt++, e.cleanupAt < e.players.length ? e.turn = e.players[e.cleanupAt] : Re(e);
		}, "", 0, "ready"),
		id: "cleanup:ready"
	}];
	if (e.phase !== "play" || !e.people[e.turn] || e.people[e.turn].passed) return [];
	let t = e.people[e.turn], n = [], r = (e, t) => n.push({
		...e,
		id: t
	});
	if (e.tasks.length) {
		let i = Fe(e);
		return i === null ? [] : (n.push(...i), !e.tasks[0].effect.startsWith("keep") && e.tasks[0].effect !== "topScry" && e.tasks[0].effect !== "discardRequired" && Pe(e, t, r), n);
	}
	if (Pe(e, t, r), e.mainUsed) r(G(I("games.arnak.endTurn"), ke, "", 0, "end"), "end");
	else {
		let n = (e, t) => r({
			...e,
			run: (t) => {
				t.mainUsed = !0, e.run(t);
			}
		}, `main:${t}`);
		je(e, t, null, 0, n), Me(e, t, !1, !1, n), Ae(e, t, "either", "", n), Ne(e, t, "item", 0, n), Ne(e, t, "artifact", 0, n), t.hand.forEach((e, r) => {
			let i = y[e];
			i.kind === "fear" || i.kind === "starter" || te.has(e) || i.kind === "artifact" && !t.resources.t || n(G(I("games.arnak.playCard", { name: "$card:" + i.id }), (t) => {
				let n = t.people[t.turn];
				n.played.push(n.hand.splice(r, 1)[0]), i.kind === "artifact" && n.resources.t--, z(t, i.effect, e);
			}, `hand:${r}`, 2, "play", i.kind === "artifact" ? "t" : "", [e]), `play:${r}`);
		}), t.assistants.forEach((e, t) => {
			if (e.id !== 609 || !e.ready) return;
			let r = T[e.id];
			n(G(I("games.arnak.useAssistant", { name: "$assistant:" + r.id }), (n) => {
				n.people[n.turn].assistants[t].ready = !1, z(n, e.gold ? r.gold : r.silver, "assistant:609");
			}, `assistant:${t}`, 2, "assistant"), `assistant:${t}`);
		}), r(G(I("games.arnak.pass"), (e) => {
			e.people[e.turn].passed = !0, ke(e);
		}, "", -20, "pass"), "pass");
	}
	return n;
}
function Re(e) {
	e.round++, e.start = (e.start + 1) % e.players.length, e.turn = e.players[e.start], e.items.length && e.exile.push(e.items.pop()), e.artifacts.length && e.exile.push(e.artifacts.shift()), ye(e), e.mainUsed = !1, e.tasks = [], e.travel = [], e.cleanupAt = 0, e.rival ? (e.rival.stack = R(e, e.rival.deck), e.rival.used = [], e.phase = "rival") : e.phase = "play", L(e, I("games.arnak.logRound", { n: e.round }));
}
function ze(e, t, n) {
	let r = e.rival, i = r.glass;
	if (i.row === 8) {
		let n = [3, 4].filter((t) => e.templeTiles[t] > 0), i = t ? n.at(-1) : n[0];
		i !== void 0 && (e.templeTiles[i]--, r.templeTiles.push(i));
	} else {
		let n = i.row + 1, a = F(e)[i.row].next[i.col], o = t ? a.at(-1) : a[0];
		r.glass = {
			row: n,
			col: o
		};
		let s = e.bonuses[`${n}:${o}`];
		s?.length && (n === 8 || e.config.temple === "snake" && n === 7 ? s.shift() : e.bonuses[`${n}:${o}`] = []), n === 8 && (r.templePoints = [
			23,
			21,
			20,
			19
		][e.templeOrder.length], e.templeOrder.push(P)), e.config.temple === "snake" && n === 4 && e.rescue.shift();
	}
	if (n) {
		let n = Math.max(...e.assistantStacks.map((e) => e.length));
		if (n) {
			let r = e.assistantStacks.filter((e) => e.length === n);
			(t ? r.at(-1) : r[0]).shift();
		}
	}
}
function Be(e) {
	let t = e.rival, n = t.stack.shift();
	if (!n) {
		e.phase = e.people[e.turn].passed ? "return" : "play";
		return;
	}
	let [r, i] = n.split(":");
	t.used.push(n);
	let a = (t.stack[0] ?? t.used[0]).split(":").at(-1) === "1", o = (e) => a ? e.at(-1) : e[0], s = (e) => e.level === 0 ? 0 : e.id < 9 ? 1 : e.id < 13 ? 2 : 3, c = (e) => {
		let t = e.workers.findIndex((t, n) => t === null && !e.blocked[n]);
		e.workers[t] = P;
	}, l = e.sites.reduce((e, t) => e + t.workers.filter((e) => e === P).length, 0);
	if (r === "dig" && l < 6) {
		let t = (e) => /^[cstaj]+$/.test(e) ? e.includes(i) : e.startsWith("choice:") ? e.slice(7).split("/").some(t) : e.includes(";") ? e.split(";").some(t) : !1, n = e.sites.filter((e) => (e.level === 0 || e.tile) && e.workers.some((t, n) => !t && !e.blocked[n]) && t(e.level === 0 ? [
			"cc",
			"ss",
			"tt",
			"a",
			"j"
		][e.id] : S[e.tile].effect)), r = Math.max(...n.map(s)), a = o(n.filter((e) => s(e) === r));
		a && c(a);
	} else if (r === "discover" && l < 6 && (i === "red" || e.round < 5)) {
		let n = e.round < 4 ? 1 : 2, r = e.sites.filter((e) => e.level === n && e.tile === null), a = Math.min(...r.map(s)), l = o(r.filter((e) => s(e) === a));
		l && (c(l), l.tile = (n === 1 ? e.sites1 : e.sites2).shift(), l.idols.splice(0).forEach((e, n) => t.idols.push(n === 0 && !t.idols.includes(e) ? e : "$duplicate")), (i === "red" ? [
			2,
			4,
			5
		].includes(e.round) : [1, 3].includes(e.round)) && (l.guardian = e.guardianDeck.shift() ?? null));
	} else if ((r === "research" || r === "guardian") && (i === "red" || e.round < 5)) {
		let n = r === "guardian" ? e.sites.filter((e) => e.guardian && e.workers.includes(P)) : [], i = Math.max(...n.map(s)), c = o(n.filter((e) => s(e) === i));
		c ? (t.guardians.push(c.guardian), c.guardian = null) : ze(e, a, r === "research");
	} else if (r === "item" || r === "artifact") {
		let n = r === "item" ? e.items : e.artifacts, a = (i === "red" ? Math.max : Math.min)(...n.map((e) => y[e].points)), s = o(n.filter((e) => y[e].points === a));
		s && (n.splice(n.indexOf(s), 1), t.cards.push(s), ye(e));
	}
	L(e, I("games.arnak.logRival"), P), e.phase = e.people[e.turn].passed ? t.stack.length ? "rival" : "return" : "play";
}
function Ve(e, t) {
	let n = e.people[t], r = F(e), i = [
		...n.hand,
		...n.deck,
		...n.played
	], a = {
		research: r[n.glass.row].glass + r[n.book.row].book + n.templePoints,
		temple: n.templeTiles.reduce((e, t) => e + D[t], 0),
		idols: (n.idols.length + n.usedIdols.filter(Boolean).length) * 3,
		slots: n.usedIdols.reduce((e, t, n) => e + (t ? 0 : n + 1), 0),
		guardians: n.guardians.length * 5,
		cards: i.filter((e) => y[e].kind !== "fear").reduce((e, t) => e + y[t].points, 0),
		fear: i.filter((e) => y[e].kind === "fear").reduce((e, t) => e + y[t].points, 0),
		total: 0
	};
	return a.total = a.research + a.temple + a.idols + a.slots + a.guardians + a.cards + a.fear, a;
}
function He(e) {
	let t = e.rival;
	return F(e)[t.glass.row].glass + t.templePoints + t.idols.reduce((e, t) => e + (t === "$duplicate" ? 2 : 3), 0) + t.guardians.length * 5 + t.cards.reduce((e, t) => e + y[t].points, 0) + t.templeTiles.reduce((e, t) => e + D[t], 0);
}
function Ue(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine" || qe(e) === null) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return t.phase === "rival" ? Be(t) : t.phase === "return" ? (t.sites.forEach((e) => e.workers.forEach((n, r) => {
			n === P ? e.workers[r] = null : n && Oe(t, t.people[n], e, r, !0);
		})), t.round === 5 ? t.phase = "done" : (t.phase = "cleanup", t.cleanupAt = 0, t.turn = t.players[0])) : Ie(t), {
			state: t,
			fx: We(e, t, "resolve")
		};
	}
	if (n.by !== e.turn || !e.people[n.by]) return { code: "games.arnak.errTurn" };
	let r = Le(e).find((e) => e.id === t.id);
	if (!r) return { code: "games.arnak.errMove" };
	let i = structuredClone(e);
	return r.run(i), {
		state: i,
		fx: We(e, i, r.kind, r.target)
	};
}
function We(e, t, n, r = "") {
	let i = [], a = e.turn, o = e.people[a], s = t.people[a], c = (e) => i.push({
		...e,
		...i.length ? { with: !0 } : {}
	}), l = (e, t) => {
		let n = [...t];
		return e.filter((e) => {
			let t = n.indexOf(e);
			return t < 0 || (n.splice(t, 1), !1);
		});
	}, u = (t) => {
		let n = y[t].kind, r = (n === "item" ? e.items : e.artifacts).indexOf(t);
		return r >= 0 ? `marketSlot:${n}:${r}` : e.exile.includes(t) ? "exileSupply" : n === "item" ? "itemDeck" : "artifactDeck";
	}, d = [], f = [];
	for (let n of e.sites) {
		let e = t.sites[n.id];
		n.workers.forEach((t, r) => {
			t && t !== e.workers[r] && d.push({
				who: t,
				site: n.id
			}), e.workers[r] && e.workers[r] !== t && f.push({
				who: e.workers[r],
				site: n.id,
				slot: r
			});
		}), !n.tile && e.tile && c({
			kind: "reveal",
			data: {
				target: `siteArt:${n.id}`,
				art: `site-${e.tile}`
			}
		});
	}
	for (let e of f) {
		let t = d.findIndex((t) => t.who === e.who), n = t < 0 ? void 0 : d.splice(t, 1)[0];
		c({
			kind: "worker",
			rid: e.who,
			data: {
				from: n ? `site:${n.site}` : `inventory:${e.who}`,
				to: `worker:${e.site}:${e.slot}`,
				fallback: `site:${e.site}`
			}
		});
	}
	for (let e of d) c({
		kind: "worker",
		rid: e.who,
		data: {
			from: `site:${e.site}`,
			to: `inventory:${e.who}`
		}
	});
	for (let r of e.players) {
		let i = e.people[r], a = t.people[r];
		for (let e of ["glass", "book"]) (i[e].row !== a[e].row || i[e].col !== a[e].col) && c({
			kind: "research",
			rid: r,
			data: {
				token: e,
				from: `research:${i[e].row}:${i[e].col}`,
				to: `token:${r}:${e}`
			}
		});
		let o = l(a.played, i.played);
		o.forEach((e, t) => c({
			kind: "card",
			rid: r,
			data: {
				id: e,
				from: e.startsWith("fear") ? "fearSupply" : i.hand.includes(e) ? `hand:${r}` : u(e),
				to: `piece:${r}:played:${a.played.length - o.length + t}`
			}
		}));
		let s = l(a.hand, i.hand);
		s.forEach((t, o) => {
			n !== "ready" && !i.deck.includes(t) && !e.revealed.includes(t) ? c({
				kind: "card",
				rid: r,
				data: {
					id: t,
					from: u(t),
					to: `piece:${r}:hand:${a.hand.length - s.length + o}`
				}
			}) : c({
				kind: "draw",
				rid: r,
				data: {
					from: `deck:${r}`,
					to: `piece:${r}:hand:${a.hand.length - s.length + o}`
				},
				for: [r],
				secret: { id: t }
			});
		});
		for (let t of l(a.deck, i.deck)) !i.hand.includes(t) && !i.played.includes(t) && !e.revealed.includes(t) && c({
			kind: "card",
			rid: r,
			data: {
				id: t,
				from: u(t),
				to: `deck:${r}`
			}
		});
		if (n === "exile" || e.tasks[0]?.effect === "exileSelf") for (let e of ["hand", "played"]) for (let t of l(i[e], a[e])) c({
			kind: "removeCard",
			rid: r,
			data: {
				id: t,
				from: `${e}:${r}`
			}
		});
		n === "ready" && i.played.some((e) => e !== "fear-tile") && c({
			kind: "draw",
			rid: r,
			data: {
				from: `played:${r}`,
				to: `deck:${r}`
			}
		}), a.guardians.forEach((t, n) => {
			i.guardians.some((e) => e.id === t.id) || c({
				kind: "object",
				rid: r,
				data: {
					shape: "guardian",
					id: t.id,
					from: `site:${e.sites.find((e) => e.guardian === t.id)?.id}`,
					to: `piece:${r}:boon:${n}`
				}
			});
		});
		for (let n of e.sites) n.idols.length && !t.sites[n.id].idols.length && t.sites[n.id].workers.includes(r) && n.idols.forEach(() => c({
			kind: "object",
			rid: r,
			data: {
				shape: "idol",
				from: `site:${n.id}`,
				to: `idolPile:${r}`
			}
		}));
		a.usedIdols.forEach((e, t) => {
			e && !i.usedIdols[t] && c({
				kind: "object",
				rid: r,
				data: {
					shape: "idol",
					from: `idolPile:${r}`,
					to: `piece:${r}:idolSlot:${t}`
				}
			}), !e && i.usedIdols[t] && c({
				kind: "object",
				rid: r,
				data: {
					shape: "idol",
					from: `piece:${r}:idolSlot:${t}`,
					to: `idolPile:${r}`
				}
			});
		}), a.templeTiles.length > i.templeTiles.length && c({
			kind: "object",
			rid: r,
			data: {
				shape: "temple",
				id: a.templeTiles.at(-1),
				from: `temple:${a.templeTiles.at(-1)}`,
				to: `seat:${r}`
			}
		}), a.assistants.forEach((t, n) => {
			let a = i.assistants.find((e) => e.id === t.id);
			a ? (a.ready !== t.ready || a.gold !== t.gold) && c({
				kind: "turnObject",
				rid: r,
				data: {
					target: `piece:${r}:assistant:${n}`,
					id: t.id,
					gold: Number(t.gold),
					ready: Number(t.ready)
				}
			}) : c({
				kind: "object",
				rid: r,
				data: {
					shape: "assistant",
					id: t.id,
					gold: Number(t.gold),
					ready: Number(t.ready),
					from: `recruit:${e.assistantStacks.findIndex((e) => e[0] === t.id)}`,
					to: `piece:${r}:assistant:${n}`
				}
			});
		});
	}
	if (r && ![
		"research",
		"dig",
		"discover",
		"play",
		"free",
		"return"
	].includes(n) && c({
		kind: "action",
		rid: a,
		data: {
			kind: n,
			target: r
		}
	}), o && s) for (let e of b) {
		let t = s.resources[e] - o.resources[e];
		t && c({
			kind: "resource",
			rid: a,
			data: {
				resource: e,
				amount: t
			}
		});
	}
	return e.phase === "rival" && c({
		kind: "action",
		rid: P,
		data: {
			kind: "rival",
			target: "rival"
		}
	}), e.round !== t.round && c({
		kind: "round",
		data: { round: t.round }
	}), i;
}
function Ge(e, t) {
	let n = t === e.turn, r = e.people[t];
	return {
		public: {
			config: e.config,
			round: e.round,
			phase: e.phase,
			turn: e.turn,
			start: e.players[e.start],
			mainUsed: e.mainUsed,
			players: e.players.map((t) => {
				let n = e.people[t];
				return {
					rid: t,
					resources: { ...n.resources },
					handCount: n.hand.length,
					deckCount: n.deck.length,
					played: [...n.played],
					assistants: structuredClone(n.assistants),
					idols: [...n.idols],
					usedIdols: [...n.usedIdols],
					guardians: structuredClone(n.guardians),
					glass: { ...n.glass },
					book: { ...n.book },
					templePoints: n.templePoints,
					templeTiles: [...n.templeTiles],
					passed: n.passed,
					freeWorkers: n.freeWorkers,
					score: Ve(e, t)
				};
			}),
			sites: structuredClone(e.sites),
			items: [...e.items],
			artifacts: [...e.artifacts],
			itemCount: e.itemDeck.length,
			artifactCount: e.artifactDeck.length,
			assistantStacks: e.assistantStacks.map((e) => ({
				top: e[0] ?? null,
				count: e.length
			})),
			rescueTop: e.rescue[0] ?? null,
			rescueCount: e.rescue.length,
			bonuses: Object.fromEntries(Object.entries(e.bonuses).map(([e, t]) => [e, e === "8:0" ? t.map(() => "$hidden") : [...t]])),
			templeTiles: [...e.templeTiles],
			templeOrder: [...e.templeOrder],
			exile: [...e.exile],
			log: e.log.slice(-80),
			pending: e.tasks[0]?.effect ?? "",
			revealed: e.tasks[0]?.effect.endsWith(":top") ? (e.tasks[0].effect.includes(":item:") ? e.itemDeck : e.artifactDeck).slice(0, 1) : [],
			rival: e.rival ? {
				glass: { ...e.rival.glass },
				idols: [...e.rival.idols],
				cards: [...e.rival.cards],
				guardians: [...e.rival.guardians],
				templePoints: e.rival.templePoints,
				templeTiles: [...e.rival.templeTiles],
				actionsLeft: e.rival.stack.length,
				score: He(e)
			} : null
		},
		private: {
			hand: r ? [...r.hand] : [],
			moves: n ? Le(e).map((e) => ({
				id: e.id,
				label: e.label,
				target: e.target,
				kind: e.kind,
				value: e.value,
				cards: e.cards,
				cost: e.cost,
				...e.remainingTravel ? { remainingTravel: e.remainingTravel } : {}
			})) : [],
			travel: n ? [...e.travel] : [],
			revealed: n ? [...e.revealed] : [],
			rescue: n && e.tasks[0]?.effect === "rescue" ? [...e.rescue] : []
		}
	};
}
function Ke(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t, Ve(e, t).total])), n = (t, n) => {
		let r = e.templeOrder.indexOf(t), i = e.templeOrder.indexOf(n);
		return r >= 0 || i >= 0 ? (r < 0 ? 10 : r) - (i < 0 ? 10 : i) : Ve(e, n).research - Ve(e, t).research;
	}, r = [...e.players].sort((e, r) => t[r] - t[e] || n(e, r));
	return {
		phase: "done",
		ranking: r,
		winner: e.rival ? t[r[0]] > He(e) ? [r[0]] : [] : r.filter((e) => t[e] === t[r[0]] && n(e, r[0]) === 0),
		scores: t
	};
}
function qe(e) {
	return e.phase === "rival" || e.phase === "return" || e.phase === "play" && e.tasks.length > 0 && Fe(e) === null ? e.beat : null;
}
var Je = {
	meta: ce,
	saveCompatibility: { version: "1" },
	schemas: {
		action: le,
		config: O,
		publicView: me,
		privateView: he
	},
	setup: xe,
	reduce: Ue,
	viewFor: Ge,
	status: Ke,
	nextTickIn: qe
}, Ye = {
	glass: "games.arnak.glass",
	book: "games.arnak.book",
	discard: "games.arnak.discard",
	exile: "games.arnak.exile",
	promote: "games.arnak.promote",
	refresh: "games.arnak.refresh",
	discovery: "games.arnak.discovery",
	deployment: "games.arnak.deployment"
};
function Xe(e, t) {
	let n = (e) => {
		if (typeof e != "string" || !e.startsWith("$")) return e;
		let [n, r] = e.slice(1).split(":"), i = n === "card" ? y[r]?.nameKey : n === "assistant" ? T[Number(r)]?.nameKey : n === "guardian" ? w[Number(r)]?.nameKey : Ye[n];
		return i ? t(i) : "";
	};
	return t(e.key, Object.fromEntries(Object.entries(e.vars).map(([e, t]) => [e, n(t)])));
}
function Ze(e, t) {
	return Xe(e.label, t);
}
var Qe = {
	draw: "games.arnak.draw",
	drawDiscard: "games.arnak.drawDiscard",
	exile: "games.arnak.exile",
	upgrade: "games.arnak.upgrade",
	recruit: "games.arnak.recruit",
	promote: "games.arnak.promote",
	refresh: "games.arnak.refresh",
	fear: "games.arnak.fear",
	freeArtifact: "games.arnak.freeArtifact",
	overcome: "games.arnak.overcome",
	allPlanes: "games.arnak.allPlanes",
	noFear: "games.arnak.noFear",
	discard: "games.arnak.discard",
	rescue: "games.arnak.rescue",
	gainItem: "games.arnak.gainItem",
	returnWorker: "games.arnak.returnWorker",
	exileSelf: "games.arnak.exileSelf",
	rewardSite: "games.arnak.activateSite",
	researchBonus: "games.arnak.takeBonus",
	pass: "games.arnak.pass"
}, K = (e) => d(`games/arnak/${e}.svg`);
function q({ name: e, className: t, children: n, style: r, title: i }) {
	let { ref: a, hidden: o } = f(e);
	return /* @__PURE__ */ m("div", {
		ref: a,
		className: t,
		title: i,
		style: {
			...r,
			visibility: o ? "hidden" : void 0
		},
		children: n
	});
}
function J({ name: e }) {
	let t = a(), n = ne[e];
	return /* @__PURE__ */ m("img", {
		className: "arnak-icon",
		src: K(`icons/${e}`),
		alt: t(n || (e === "idol" ? "games.arnak.idols" : e === "glass" ? "games.arnak.glass" : e === "book" ? "games.arnak.book" : "games.arnak.expedition")),
		draggable: !1
	});
}
function Y({ cost: e }) {
	return e === "idol" ? /* @__PURE__ */ m(J, { name: "idol" }) : /* @__PURE__ */ m("span", {
		className: "arnak-resources",
		children: [
			"c",
			"s",
			"t",
			"a",
			"j"
		].map((t) => {
			let n = [...e].filter((e) => e === t).length;
			return n ? /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { name: t }), n > 1 && n] }, t) : null;
		})
	});
}
function X({ effect: e }) {
	let t = a();
	if (!e) return null;
	if (/^[cstaj]+$/.test(e)) return /* @__PURE__ */ m(Y, { cost: e });
	if (e.includes(";")) return /* @__PURE__ */ m("span", {
		className: "arnak-effect",
		children: e.split(";").map((e, t) => /* @__PURE__ */ m(X, { effect: e }, t))
	});
	if (e.startsWith("choice:")) return /* @__PURE__ */ m("span", {
		className: "arnak-effect",
		children: e.slice(7).split("/").map((e, t) => /* @__PURE__ */ h("span", { children: [t > 0 && /* @__PURE__ */ m("span", { children: " / " }), /* @__PURE__ */ m(X, { effect: e })] }, e))
	});
	if (e.startsWith("rewardIdol:")) return /* @__PURE__ */ m(X, { effect: e.slice(11) });
	if (e.startsWith("pass")) return /* @__PURE__ */ h("span", { children: [
		t("games.arnak.pass"),
		" → ",
		/* @__PURE__ */ m(Y, { cost: e.slice(4) })
	] });
	if (e.startsWith("trade:")) {
		let [t, n] = e.slice(6).split(">");
		return /* @__PURE__ */ h("span", { children: [
			/* @__PURE__ */ m(Y, { cost: t }),
			" → ",
			/* @__PURE__ */ m(X, { effect: n })
		] });
	}
	if (e.startsWith("travelTrade:")) {
		let [t, n] = e.slice(12).split(">");
		return /* @__PURE__ */ h("span", { children: [
			/* @__PURE__ */ m(J, { name: t }),
			" → ",
			/* @__PURE__ */ m(X, { effect: n })
		] });
	}
	let [n, r] = e.split(":");
	if (n === "travel") return /* @__PURE__ */ m("span", { children: r.split(",").map((e, t) => /* @__PURE__ */ m(J, { name: e }, t)) });
	if (n === "draw" || n === "drawBottom") return /* @__PURE__ */ m("span", { children: t("games.arnak.drawN", { n: Number(r ?? 1) }) });
	if (n === "buy") return /* @__PURE__ */ m("span", { children: t(r === "item" ? "games.arnak.buyItemDiscount" : "games.arnak.buyArtifactDiscount", { n: Number(e.split(":")[2]) }) });
	let i = Qe[n];
	return /* @__PURE__ */ m("span", { children: t(i || "games.arnak.choose") });
}
function $e({ id: e, compact: t = !1 }) {
	let n = a(), r = y[e], i = /^\d{4}$/.test(e);
	return /* @__PURE__ */ h("div", {
		className: `arnak-card arnak-card-${r.kind}${t ? " arnak-card-compact" : ""}`,
		children: [
			/* @__PURE__ */ m("div", {
				className: "arnak-card-name",
				children: n(r.nameKey)
			}),
			/* @__PURE__ */ h("div", {
				className: "arnak-card-picture",
				children: [i ? /* @__PURE__ */ m("img", {
					src: K(`card-${e}`),
					alt: "",
					draggable: !1
				}) : /* @__PURE__ */ m("div", {
					className: "arnak-starter-mark",
					children: /* @__PURE__ */ m(J, { name: r.kind === "fear" ? "glass" : e.startsWith("fund") ? "c" : "s" })
				}), /* @__PURE__ */ m("span", {
					className: "arnak-card-travel",
					children: r.travel.map((e, t) => /* @__PURE__ */ m(J, { name: e }, t))
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "arnak-card-text",
				children: n(r.textKey)
			}),
			/* @__PURE__ */ h("div", {
				className: "arnak-card-foot",
				children: [/* @__PURE__ */ m("span", { children: r.cost > 0 && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(J, { name: r.kind === "artifact" ? "s" : "c" }), r.cost] }) }), /* @__PURE__ */ m("span", {
					className: "arnak-vp",
					children: n("games.arnak.points", { n: r.points })
				})]
			})
		]
	});
}
function Z({ id: e, gold: t = !1, ready: n = !0 }) {
	let r = a(), i = T[e];
	return /* @__PURE__ */ h("div", {
		className: `arnak-assistant${t ? " arnak-gold" : ""}${n ? "" : " arnak-exhausted"}`,
		children: [
			/* @__PURE__ */ m("img", {
				src: K(`assistant-${e}`),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ m("strong", { children: r(i.nameKey) }),
			/* @__PURE__ */ h("small", { children: [
				r(t ? "games.arnak.gold" : "games.arnak.silver"),
				" · ",
				r(n ? "games.arnak.ready" : "games.arnak.exhausted")
			] }),
			/* @__PURE__ */ m(X, { effect: t ? i.gold : i.silver })
		]
	});
}
function et({ on: e }) {
	return e ? /* @__PURE__ */ m("svg", {
		className: "arnak-legal-edge",
		"aria-hidden": "true",
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ m("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "8",
			fill: "none",
			stroke: "#fff2a4",
			strokeWidth: "3",
			strokeDasharray: "7 5",
			children: /* @__PURE__ */ m("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-24",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	}) : null;
}
//#endregion
//#region src/games/arnak/view-player.tsx
function tt(e) {
	return /* @__PURE__ */ m(nt, { ...e }, e.myRid);
}
function nt({ public: e, private: t, myRid: n, members: r, send: d, readOnly: f = !1, onBackToReport: ee }) {
	s();
	let g = a(), _ = e, v = t, [te, ne] = i("map"), [x, C] = i(null), [re, E] = i(null), [ie, ce] = i(n), [O, le] = i(!1), k = _.players.find((e) => e.rid === n), A = _.players.find((e) => e.rid === ie) ?? k ?? _.players[0], ue = f ? [] : v?.moves ?? [], j = (e) => e === "$rival" ? g("games.arnak.rival") : r.find((t) => t.rid === e)?.name ?? e, de = (e) => e === "$rival" ? "#63516f" : o[(r.find((t) => t.rid === e)?.colorIndex ?? 0) % o.length].hex, fe = (e) => ue.filter((t) => t.target === e || e.startsWith("idolSlot:") && t.target.startsWith("idol:")), pe = (e) => {
		C(e), E(null);
	}, M = (e) => {
		d({
			type: "move",
			id: e.id
		}), C(null), [
			"idol",
			"assistant",
			"promote",
			"refresh",
			"recruit",
			"overcome"
		].includes(e.kind) && (ce(n), E("expedition"), le(!0));
	}, N = (e, t, n = "", r) => /* @__PURE__ */ h("button", {
		type: "button",
		className: `arnak-object ${n}`,
		onClick: () => pe(e),
		"aria-label": r,
		children: [/* @__PURE__ */ m(q, {
			name: e,
			children: t
		}), /* @__PURE__ */ m(et, { on: fe(e).length > 0 })]
	}, e), me = (e, t) => N(t, /* @__PURE__ */ m($e, { id: e }), "arnak-card-object", g(y[e].nameKey)), he = ue.filter((e) => !e.target || e.target === "deck" || e.target.startsWith("effect:") || e.target.startsWith("upgrade:")), P = he.filter((e) => [
		"end",
		"pass",
		"ready",
		"skip"
	].includes(e.kind)), ge = he.filter((e) => ![
		"end",
		"pass",
		"ready",
		"skip"
	].includes(e.kind)), F = _.pending === "exileItem" ? _.exile.filter((e) => y[e].kind === "item") : _.revealed.length ? _.revealed : v?.revealed ?? [], I = x ? fe(x) : [], L = re === "expedition" && O && ue.some((e) => e.id.startsWith("task:") && e.kind !== "skip") ? null : re, R = f ? g("games.arnak.reviewBoard") : _.phase === "return" ? g("games.arnak.returning") : _.phase === "rival" ? g("games.arnak.rival") : _.turn === n ? _.phase === "cleanup" ? g("games.arnak.cleanup") : _.pending ? g("games.arnak.choose") : g(_.mainUsed ? "games.arnak.mainUsed" : "games.arnak.mainAvailable") : g("games.arnak.waiting", { name: j(_.turn) }), z = (e) => /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("strong", { children: Ze(e, g) }),
		e.cost && /* @__PURE__ */ h("span", { children: [
			g("games.arnak.pay"),
			" ",
			/* @__PURE__ */ m(Y, { cost: e.cost })
		] }),
		e.target.startsWith("effect:") && /* @__PURE__ */ m(X, { effect: e.target.slice(7) }),
		" ",
		e.target.startsWith("idol:") && /* @__PURE__ */ m(X, { effect: e.target.slice(5) }),
		" ",
		e.target.startsWith("upgrade:") && /* @__PURE__ */ h("span", { children: [
			/* @__PURE__ */ m(J, { name: e.target.split(":")[1] }),
			" → ",
			/* @__PURE__ */ m(J, { name: e.target.split(":")[2] })
		] }),
		e.remainingTravel && e.remainingTravel.length > 0 && /* @__PURE__ */ h("span", { children: [
			g("games.arnak.remainingTravel"),
			" ",
			e.remainingTravel.map((e, t) => /* @__PURE__ */ m(J, { name: e }, t))
		] }),
		e.cards.length > 0 && ![
			"play",
			"free",
			"keep",
			"top",
			"cleanup",
			"exile",
			"discard",
			"discardRequired"
		].includes(e.kind) && /* @__PURE__ */ h("span", {
			className: "arnak-payment-cards",
			children: [
				g("games.arnak.paymentCards"),
				": ",
				e.cards.map((e) => g(y[e].nameKey)).join(" · "),
				/* @__PURE__ */ m("span", { children: e.cards.flatMap((e, t) => y[e].travel.map((e, n) => /* @__PURE__ */ m(J, { name: e }, `${t}:${n}`))) })
			]
		})
	] }), B = /* @__PURE__ */ m("div", {
		className: "arnak-map",
		style: { backgroundImage: `linear-gradient(#123a2d55,#183f3055),url(${K("canyon")})` },
		children: [
			2,
			1,
			0
		].map((e) => /* @__PURE__ */ m("div", {
			className: `arnak-site-row arnak-site-row-${e}`,
			children: _.sites.filter((t) => t.level === e).map((t) => /* @__PURE__ */ h("div", {
				className: "arnak-site-group",
				children: [N(`site:${t.id}`, /* @__PURE__ */ h("div", {
					className: `arnak-site ${t.tile ? "arnak-discovered" : ""}`,
					children: [
						/* @__PURE__ */ m("header", { children: e === 0 ? /* @__PURE__ */ m(X, { effect: [
							"cc",
							"ss",
							"tt",
							"a",
							"discard;j"
						][t.id] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", { children: g(t.tile ? "games.arnak.site" : "games.arnak.level", { n: t.tile ? t.id - 4 : t.level }) }), !t.tile && /* @__PURE__ */ m("span", { children: /* @__PURE__ */ m(Y, { cost: "s".repeat(e === 1 ? 3 : 6) }) })] }) }),
						t.tile ? /* @__PURE__ */ m(q, {
							name: `siteArt:${t.id}`,
							className: "arnak-site-art",
							children: /* @__PURE__ */ m("img", {
								src: K(`site-${t.tile}`),
								alt: ""
							})
						}) : e > 0 ? /* @__PURE__ */ m("div", {
							className: "arnak-undiscovered",
							children: t.idols.map((e, t) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { name: "idol" }), e === "$back" ? /* @__PURE__ */ m("span", { children: "?" }) : /* @__PURE__ */ m(X, { effect: e })] }, t))
						}) : null,
						t.tile && /* @__PURE__ */ m("div", {
							className: "arnak-site-yield",
							children: /* @__PURE__ */ m(X, { effect: S[t.tile].effect })
						}),
						/* @__PURE__ */ m("div", {
							className: "arnak-worker-slots",
							children: t.workers.map((e, n) => /* @__PURE__ */ h("span", {
								className: t.blocked[n] ? "arnak-blocked" : "",
								children: [t.travel[n].map((e, t) => /* @__PURE__ */ m(J, { name: e }, t)), e ? /* @__PURE__ */ h(q, {
									name: `worker:${t.id}:${n}`,
									className: "arnak-worker-name",
									style: { "--arnak-player": de(e) },
									children: [/* @__PURE__ */ m(J, { name: "worker" }), j(e)]
								}) : t.blocked[n] ? /* @__PURE__ */ m("span", { children: "×" }) : /* @__PURE__ */ m("span", {
									className: "arnak-vacant",
									children: "○"
								})]
							}, n))
						})
					]
				}), "", g("games.arnak.site", { n: t.id + 1 })), t.guardian && N(`guardian:${t.id}`, /* @__PURE__ */ h("div", {
					className: "arnak-guardian",
					children: [/* @__PURE__ */ m("img", {
						src: K(`guardian-${t.guardian}`),
						alt: ""
					}), /* @__PURE__ */ h("span", { children: [
						/* @__PURE__ */ m("strong", { children: g(w[t.guardian].nameKey) }),
						/* @__PURE__ */ m(Y, { cost: w[t.guardian].cost }),
						w[t.guardian].cost.includes("discard") && /* @__PURE__ */ m("span", { children: g("games.arnak.discardOne") }),
						w[t.guardian].travel.map((e, t) => /* @__PURE__ */ m(J, { name: e }, t))
					] })]
				}), "arnak-guardian-object", g(w[t.guardian].nameKey))]
			}, t.id))
		}, e))
	}), V = _.config.temple === "bird" ? oe : se, _e = /* @__PURE__ */ h("div", {
		className: "arnak-research",
		children: [
			/* @__PURE__ */ m("h2", { children: g(_.config.temple === "bird" ? "games.arnak.bird" : "games.arnak.snake") }),
			/* @__PURE__ */ m("div", {
				className: "arnak-track",
				children: V.map((e, t) => /* @__PURE__ */ h("div", {
					className: "arnak-track-row",
					children: [
						/* @__PURE__ */ m("svg", {
							className: "arnak-paths",
							viewBox: "0 0 100 14",
							preserveAspectRatio: "none",
							"aria-hidden": "true",
							children: t < 8 && e.next.flatMap((n, r) => n.map((n) => /* @__PURE__ */ m("line", {
								x1: (r + .5) * 100 / e.next.length,
								y1: "14",
								x2: (n + .5) * 100 / V[t + 1].costs.length,
								y2: "0",
								stroke: "#947347",
								strokeWidth: ".65"
							}, `${r}:${n}`)))
						}),
						/* @__PURE__ */ m("span", {
							className: "arnak-track-vp",
							children: t === 8 ? "23 / 21 / 20 / 19" : /* @__PURE__ */ h(p, { children: [
								/* @__PURE__ */ m(J, { name: "glass" }),
								e.glass,
								" ",
								/* @__PURE__ */ m(J, { name: "book" }),
								e.book
							] })
						}),
						/* @__PURE__ */ m("div", {
							className: "arnak-track-cells",
							children: (t === 0 ? [""] : e.costs).map((e, n) => N(`research:${t}:${n}`, /* @__PURE__ */ h("div", {
								className: "arnak-track-cell",
								children: [
									/* @__PURE__ */ m(Y, { cost: e }),
									/* @__PURE__ */ h("span", {
										className: "arnak-track-tokens",
										children: [_.players.flatMap((e) => ["glass", "book"].filter((r) => e[r].row === t && e[r].col === n).map((t) => /* @__PURE__ */ h(q, {
											name: `token:${e.rid}:${t}`,
											style: { "--arnak-player": de(e.rid) },
											title: j(e.rid),
											children: [/* @__PURE__ */ m(J, { name: t }), /* @__PURE__ */ m("small", { children: j(e.rid) })]
										}, `${e.rid}:${t}`))), _.rival?.glass.row === t && _.rival.glass.col === n && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { name: "glass" }), /* @__PURE__ */ m("small", { children: g("games.arnak.rival") })] })]
									}),
									/* @__PURE__ */ m("span", {
										className: "arnak-track-bonus",
										children: _.bonuses[`${t}:${n}`]?.map((e, t) => e === "$hidden" ? /* @__PURE__ */ m("span", { children: "?" }, t) : /* @__PURE__ */ m(X, { effect: e }, t))
									})
								]
							}), "arnak-research-object", g("games.arnak.researchRow", { n: t })))
						}),
						/* @__PURE__ */ h("div", {
							className: "arnak-track-effects",
							children: [e.glassEffect && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { name: "glass" }), /* @__PURE__ */ m(X, { effect: e.glassEffect })] }), e.bookEffect && /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { name: "book" }), /* @__PURE__ */ m(X, { effect: e.bookEffect })] })]
						})
					]
				}, t)).reverse()
			}),
			/* @__PURE__ */ m("div", {
				className: "arnak-temple-tiles",
				children: _.templeTiles.map((e, t) => N(`temple:${t}`, /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("strong", { children: g("games.arnak.points", { n: D[t] }) }),
					/* @__PURE__ */ m(Y, { cost: ae[t] }),
					/* @__PURE__ */ h("small", { children: ["× ", e] })
				] }), "arnak-temple-tile", g("games.arnak.buyTemple", { n: D[t] })))
			}),
			/* @__PURE__ */ m("h3", { children: g("games.arnak.supply") }),
			/* @__PURE__ */ m("div", {
				className: "arnak-assistant-supply",
				children: _.assistantStacks.map((e, t) => e.top && /* @__PURE__ */ h("div", { children: [N(`recruit:${t}`, /* @__PURE__ */ m(Z, { id: e.top }), "", g(T[e.top].nameKey)), /* @__PURE__ */ h("small", { children: ["× ", e.count] })] }, t))
			}),
			!!_.rescueCount && /* @__PURE__ */ h("p", { children: [
				g("games.arnak.rescue"),
				" × ",
				_.rescueCount
			] })
		]
	}), H = /* @__PURE__ */ h("div", {
		className: "arnak-market",
		children: [
			/* @__PURE__ */ h(q, {
				name: "itemDeck",
				className: "arnak-deck-counter",
				children: [/* @__PURE__ */ m("span", { children: g("games.arnak.item") }), /* @__PURE__ */ m("strong", { children: _.itemCount })]
			}),
			[..._.items, ..._.artifacts].map((e) => /* @__PURE__ */ m(q, {
				name: `marketSlot:${y[e].kind}:${(y[e].kind === "item" ? _.items : _.artifacts).indexOf(e)}`,
				children: me(e, `market:${e}`)
			}, e)),
			/* @__PURE__ */ h(q, {
				name: "artifactDeck",
				className: "arnak-deck-counter",
				children: [/* @__PURE__ */ m("span", { children: g("games.arnak.artifact") }), /* @__PURE__ */ m("strong", { children: _.artifactCount })]
			})
		]
	}), U = (e) => A.rid === n ? e : `inspect:${A.rid}:${e}`, ve = /* @__PURE__ */ h("div", {
		className: "arnak-expedition-panel",
		children: [
			/* @__PURE__ */ m("div", {
				className: "arnak-materials",
				children: b.map((e) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { name: e }), A.resources[e]] }, e))
			}),
			/* @__PURE__ */ h("p", { children: [
				/* @__PURE__ */ m(J, { name: "worker" }),
				g("games.arnak.workers", { n: A.freeWorkers }),
				" · ",
				g("games.arnak.deck"),
				" ",
				A.deckCount,
				" · ",
				g("games.arnak.hand"),
				" ",
				A.handCount
			] }),
			/* @__PURE__ */ m("div", {
				className: "arnak-personal-assistants",
				children: A.assistants.map((e, t) => N(U(`assistant:${t}`), /* @__PURE__ */ m(q, {
					name: `piece:${A.rid}:assistant:${t}`,
					children: /* @__PURE__ */ m(Z, { ...e })
				}), "", g(T[e.id].nameKey)))
			}),
			/* @__PURE__ */ h("div", {
				className: "arnak-idol-board",
				children: [/* @__PURE__ */ m(q, {
					name: `idolPile:${A.rid}`,
					children: /* @__PURE__ */ h("span", { children: [
						g("games.arnak.idols"),
						" ",
						/* @__PURE__ */ m(J, { name: "idol" }),
						" × ",
						A.idols.length
					] })
				}), A.usedIdols.map((e, t) => N(U(`idolSlot:${t}`), /* @__PURE__ */ m(q, {
					name: `piece:${A.rid}:idolSlot:${t}`,
					children: /* @__PURE__ */ h("span", { children: [e ? /* @__PURE__ */ m(J, { name: "idol" }) : /* @__PURE__ */ m("strong", { children: t + 1 }), /* @__PURE__ */ m("small", { children: g(e ? "games.arnak.usedSlot" : "games.arnak.emptySlot", { n: t + 1 }) })] })
				}), "arnak-idol-slot", g("games.arnak.slot", { n: t + 1 })))]
			}),
			/* @__PURE__ */ m("h3", { children: g("games.arnak.boons") }),
			/* @__PURE__ */ m("div", {
				className: "arnak-personal-guardians",
				children: A.guardians.map((e, t) => N(U(`boon:${t}`), /* @__PURE__ */ m(q, {
					name: `piece:${A.rid}:boon:${t}`,
					children: /* @__PURE__ */ h("div", {
						className: e.ready ? "" : "arnak-exhausted",
						children: [
							/* @__PURE__ */ m("img", {
								src: K(`guardian-${e.id}`),
								alt: ""
							}),
							/* @__PURE__ */ m("strong", { children: g(w[e.id].nameKey) }),
							/* @__PURE__ */ m(X, { effect: [
								"car",
								"boat",
								"plane"
							].includes(w[e.id].boon) ? `travel:${w[e.id].boon}` : w[e.id].boon }),
							/* @__PURE__ */ m("small", { children: g(e.ready ? "games.arnak.ready" : "games.arnak.exhausted") })
						]
					})
				}), "", g(w[e.id].nameKey)))
			}),
			/* @__PURE__ */ m("h3", { children: g("games.arnak.played") }),
			/* @__PURE__ */ m(q, {
				name: `played:${A.rid}`,
				className: "arnak-played",
				children: A.played.map((e, t) => /* @__PURE__ */ m(q, {
					name: `piece:${A.rid}:played:${t}`,
					children: me(e, U(`played:${t}`))
				}, t))
			})
		]
	});
	return /* @__PURE__ */ h("div", {
		className: "arnak-root",
		children: [/* @__PURE__ */ m(u, {
			adaptive: !0,
			scroll: !1,
			className: "arnak-screen",
			banner: /* @__PURE__ */ h("header", {
				className: "arnak-header",
				children: [
					/* @__PURE__ */ h("div", {
						className: "arnak-title",
						children: [
							/* @__PURE__ */ m("strong", { children: g("games.arnak.name") }),
							/* @__PURE__ */ m("span", { children: g("games.arnak.round", { n: _.round }) }),
							/* @__PURE__ */ m("button", {
								className: "arnak-tool",
								onClick: () => E("log"),
								"aria-label": g("games.arnak.log"),
								children: /* @__PURE__ */ m(l, { size: 18 })
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "arnak-player-strip",
						children: [_.players.map((e) => /* @__PURE__ */ m(q, {
							name: `seat:${e.rid}`,
							children: /* @__PURE__ */ h("button", {
								style: { "--arnak-player": de(e.rid) },
								className: `arnak-player${_.turn === e.rid ? " arnak-active-player" : ""}`,
								onClick: () => {
									ce(e.rid), E("expedition"), le(!1);
								},
								children: [
									j(e.rid),
									" ",
									/* @__PURE__ */ m("strong", { children: e.score.total }),
									e.passed && /* @__PURE__ */ m("small", { children: g("games.arnak.passed") })
								]
							})
						}, e.rid)), _.rival && /* @__PURE__ */ m(q, {
							name: "rival",
							children: /* @__PURE__ */ h("span", {
								className: "arnak-rival-score",
								children: [
									g("games.arnak.rival"),
									" ",
									_.rival.score,
									" · ",
									g("games.arnak.actionsLeft", { n: _.rival.actionsLeft })
								]
							})
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "arnak-resource-strip",
						children: [/* @__PURE__ */ m(q, {
							name: `inventory:${n}`,
							className: "arnak-materials",
							children: k && b.map((e) => /* @__PURE__ */ h(q, {
								name: `resource:${n}:${e}`,
								children: [/* @__PURE__ */ m(J, { name: e }), /* @__PURE__ */ m("strong", { children: k.resources[e] })]
							}, e))
						}), /* @__PURE__ */ m("span", { children: ee ? /* @__PURE__ */ m("button", {
							className: "arnak-return-inline",
							onClick: ee,
							children: g("games.arnak.backResult")
						}) : R })]
					})
				]
			}),
			actionsHeight: "arnak-dock-height",
			actions: /* @__PURE__ */ h("div", {
				className: "arnak-dock",
				children: [
					/* @__PURE__ */ h("div", {
						className: "arnak-dock-toolbar",
						children: [
							/* @__PURE__ */ h("span", { children: [
								g("games.arnak.hand"),
								" ",
								v?.hand.length ?? 0
							] }),
							/* @__PURE__ */ h("button", {
								onClick: () => {
									ce(n), E("expedition"), le(!1);
								},
								children: [
									g("games.arnak.expedition"),
									" ",
									/* @__PURE__ */ m(J, { name: "worker" }),
									k?.freeWorkers ?? 0
								]
							}),
							/* @__PURE__ */ m("span", {
								className: "arnak-travel-pool",
								children: v?.travel.map((e, t) => /* @__PURE__ */ m(J, { name: e }, t))
							}),
							/* @__PURE__ */ m("div", {
								className: "arnak-quick-actions",
								children: P.map((e) => /* @__PURE__ */ m("button", {
									onClick: () => e.kind === "pass" ? C("$pass") : M(e),
									children: Ze(e, g)
								}, e.id))
							})
						]
					}),
					/* @__PURE__ */ m(q, {
						name: `hand:${n}`,
						className: "arnak-hand",
						children: v?.hand.map((e, t) => /* @__PURE__ */ m(q, {
							name: `piece:${n}:hand:${t}`,
							children: me(e, `hand:${t}`)
						}, `${t}:${e}`))
					}),
					/* @__PURE__ */ m(q, {
						name: `deck:${n}`,
						className: "arnak-hidden-deck"
					})
				]
			}),
			children: /* @__PURE__ */ h("div", {
				className: "arnak-table",
				children: [/* @__PURE__ */ m("nav", {
					className: "arnak-scenes",
					children: [
						"map",
						"research",
						"market"
					].map((e) => /* @__PURE__ */ m("button", {
						"aria-pressed": te === e,
						onClick: () => ne(e),
						children: g(e === "map" ? "games.arnak.map" : e === "research" ? "games.arnak.research" : "games.arnak.market")
					}, e))
				}), /* @__PURE__ */ h("div", {
					className: `arnak-stage arnak-scene-${te}`,
					children: [
						/* @__PURE__ */ m("section", {
							className: "arnak-market-region",
							children: H
						}),
						/* @__PURE__ */ m("section", {
							className: "arnak-map-region",
							children: B
						}),
						/* @__PURE__ */ m("section", {
							className: "arnak-research-region",
							children: _e
						})
					]
				})]
			})
		}), (ge.length > 0 || F.length || v?.rescue.length || x || L) && /* @__PURE__ */ m("div", {
			className: `arnak-modal-layer${!x && !L ? " arnak-decision-layer" : ""}`,
			children: /* @__PURE__ */ h("section", {
				className: "arnak-dialog",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": g(L === "log" ? "games.arnak.log" : L === "expedition" ? "games.arnak.expedition" : "games.arnak.choose"),
				children: [/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ m("strong", { children: L === "log" ? g("games.arnak.log") : L === "expedition" ? j(A.rid) : g("games.arnak.choose") }), (x || L) && /* @__PURE__ */ m("button", {
					className: "arnak-tool",
					onClick: () => {
						C(null), E(null);
					},
					"aria-label": g("games.arnak.close"),
					children: /* @__PURE__ */ m(c, { size: 20 })
				})] }), /* @__PURE__ */ m("div", {
					className: "arnak-dialog-body",
					children: L === "log" ? /* @__PURE__ */ m("ol", {
						className: "arnak-log",
						children: _.log.map((e, t) => /* @__PURE__ */ h("li", { children: [
							/* @__PURE__ */ m("strong", { children: j(e.rid) }),
							" ",
							Xe(e.label, g)
						] }, t))
					}) : L === "expedition" ? ve : /* @__PURE__ */ h(p, { children: [
						/* @__PURE__ */ m("div", {
							className: "arnak-detail-object",
							children: (() => {
								if (!x) return null;
								let [e, t] = x.replace(/^inspect:[^:]+:/, "").split(":"), n = Number(t), r = e === "market" ? t : e === "hand" ? v?.hand[n] : e === "played" ? A.played[n] : e === "revealed" ? F[n] : void 0;
								if (r) return /* @__PURE__ */ m($e, { id: r });
								if (e === "site") {
									let e = _.sites[n];
									return e?.tile ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("img", {
										className: "arnak-detail-art",
										src: K(`site-${e.tile}`),
										alt: ""
									}), /* @__PURE__ */ m(X, { effect: S[e.tile].effect })] }) : null;
								}
								if (e === "guardian" && _.sites[n]?.guardian) {
									let e = w[_.sites[n].guardian];
									return /* @__PURE__ */ h(p, { children: [
										/* @__PURE__ */ m("img", {
											className: "arnak-detail-art",
											src: K(`guardian-${e.id}`),
											alt: ""
										}),
										/* @__PURE__ */ m("h3", { children: g(e.nameKey) }),
										/* @__PURE__ */ m(X, { effect: [
											"car",
											"boat",
											"plane"
										].includes(e.boon) ? `travel:${e.boon}` : e.boon })
									] });
								}
								if (e === "recruit") {
									let e = _.assistantStacks[n]?.top;
									return e ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Z, { id: e }), /* @__PURE__ */ h("p", { children: [
										/* @__PURE__ */ m(J, { name: "glass" }),
										g("games.arnak.gold"),
										": ",
										/* @__PURE__ */ m(X, { effect: T[e].gold })
									] })] }) : null;
								}
								if (e === "assistant") {
									let e = A.assistants[n];
									return e ? /* @__PURE__ */ m(Z, { ...e }) : null;
								}
								return null;
							})()
						}),
						/* @__PURE__ */ h("div", {
							className: "arnak-choices",
							children: [x === "$pass" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("p", { children: g("games.arnak.passConfirm") }), P.filter((e) => e.kind === "pass").map((e) => /* @__PURE__ */ m("button", {
								onClick: () => M(e),
								children: Ze(e, g)
							}, e.id))] }) : (x ? I : ge).map((e) => /* @__PURE__ */ m("button", {
								onClick: () => M(e),
								children: z(e)
							}, e.id)), !x && /* @__PURE__ */ h(p, { children: [F.map((e, t) => /* @__PURE__ */ h("div", { children: [me(e, `revealed:${t}`), ue.filter((t) => t.target === `market:${e}`).map((e) => /* @__PURE__ */ m("button", {
								onClick: () => M(e),
								children: z(e)
							}, e.id))] }, t)), v?.rescue.map((e) => /* @__PURE__ */ m("div", { children: N(`rescue:${e}`, /* @__PURE__ */ m(Z, { id: e }), "", g(T[e].nameKey)) }, e))] })]
						}),
						x && !I.length && x !== "$pass" && /* @__PURE__ */ m("p", { children: g("games.arnak.noMoves") }),
						!x && P.filter((e) => e.kind === "skip").map((e) => /* @__PURE__ */ m("button", {
							className: "arnak-control",
							onClick: () => M(e),
							children: Ze(e, g)
						}, e.id))
					] })
				})]
			})
		})]
	});
}
//#endregion
//#region src/games/arnak/bot.ts
var rt = {
	research: 1,
	discover: 1,
	buy: 1,
	worker: 1,
	future: 1,
	slot: 1
};
function it(e, t, n, r, i = rt) {
	let a = t.players.find((e) => e.rid === r), o = t.config.temple === "bird" ? oe : se, s = {
		c: .65,
		s: .95,
		t: 1,
		a: 1.7,
		j: 2.4
	}, c = a.glass.row < 8 ? o[a.glass.row + 1].costs : ["cttj", "jsa"];
	for (let e of b) {
		let t = Math.min(...c.filter((e) => e !== "idol").map((t) => [...t].filter((t) => t === e).length));
		a.resources[e] < t && (s[e] *= 1.35), a.resources[e] > 5 && (s[e] *= .6);
	}
	let l = (e) => [...e].reduce((e, t) => e + (s[t] ?? 0), 0), u = (e) => {
		if (/^[cstaj]+$/.test(e)) return l(e);
		if (e.startsWith("choice:")) return Math.max(...e.slice(7).split("/").map(u));
		if (e.includes(";")) return e.split(";").reduce((e, t) => e + u(t), 0);
		if (e.startsWith("pass")) return t.mainUsed ? -100 : l(e.slice(4)) - .4;
		if (e === "fear") return -1.2;
		if (e.startsWith("draw")) return a.deckCount ? 1.4 * Math.min(a.deckCount, Number(e.split(":")[1] ?? 1)) : 0;
		if (e === "exile") return [...n.hand, ...a.played].some((e) => y[e].kind === "fear") ? 1.6 : .2;
		if (e.startsWith("trade:")) {
			let [t, n] = e.slice(6).split(">");
			return u(n) - l(t);
		}
		return e.startsWith("travel:") ? a.freeWorkers ? 1.2 : .1 : e === "upgrade" ? Math.max(a.resources.t ? s.a - s.t : 0, a.resources.a ? s.j - s.a : 0) : e === "recruit" ? (6 - t.round) * 1.5 : e.startsWith("refresh") ? a.assistants.some((e) => !e.ready) ? 2 : 0 : e.startsWith("research") ? 4 : e.startsWith("expedition") ? a.freeWorkers ? 3.5 : 0 : e === "overcome" || e === "trap" ? t.sites.some((e) => e.guardian && e.workers.includes(r)) ? 5.5 : 0 : 1.5;
	};
	if (e.kind === "end") return -5;
	if (e.kind === "pass") return -100;
	if (e.kind === "skip") return -6;
	if (e.kind === "ready") return 0;
	if (e.kind === "cleanup") return y[e.cards[0]].kind === "fear" ? 4 : y[e.cards[0]].kind === "starter" ? 2 : -1;
	let d = e.value, [f, p] = e.target.split(":");
	if (e.kind === "research") {
		let n = e.id.includes(":book:") ? "book" : "glass", r = Number(p), s = o[a[n].row][n];
		d = ((r === 8 ? Math.max(19, 23 - t.templeOrder.length * 2) : o[r][n]) - s) * i.research, d += u(o[r][n === "glass" ? "glassEffect" : "bookEffect"]), n === "glass" && a.book.row === a.glass.row && (d += 1), n === "glass" && (d += (8 - a.glass.row) * .12 * i.future);
	} else if (e.kind === "temple") d = e.value / .7;
	else if (e.kind === "discover") d = (4.6 + Number(t.sites[Number(p)]?.level ?? 1)) * i.discover + (6 - t.round) * .25;
	else if (e.kind === "dig" || e.kind === "activate" || e.kind === "relocate") {
		let n = t.sites[Number(p)];
		n && (d = u(n.level === 0 ? [
			"cc",
			"ss",
			"tt",
			"a",
			"discard;j"
		][n.id] : S[n.tile].effect) * i.worker), e.kind === "relocate" && (d += .5);
	} else if (e.kind === "overcome") d = 5 + (t.sites[Number(p)]?.workers.filter((e) => e === r).length ?? 0) * 1.1;
	else if (e.kind === "buy") {
		let e = y[p];
		e && (d = (e.points + u(e.effect) * (e.kind === "artifact" ? 1 : .4) + Math.max(0, 5 - t.round) * .4 * i.future) * i.buy);
	} else if (e.kind === "play" || e.kind === "free") {
		let t = y[e.cards[0]];
		d = u(t.effect), e.kind === "free" && (d += .4);
	} else if (e.kind === "boon") {
		let e = a.guardians[Number(p)], t = e ? w[e.id].boon : "";
		d = [
			"car",
			"boat",
			"plane"
		].includes(t) ? a.freeWorkers && !n.travel.length ? 1.1 : -4 : u(t);
	} else e.kind === "idol" ? d = f === "idolSlot" ? Number(p) + 1 : u(e.target.slice(5)) - (a.usedIdols.findIndex((e) => !e) + 1) * i.slot + (t.round < 5 ? .4 : 0) : f === "effect" ? d = u(e.target.slice(7)) : e.kind === "upgrade" && (d = s[e.target.split(":")[2]] - s[p]);
	d -= l(e.cost);
	for (let t of e.cards) e.kind !== "play" && e.kind !== "free" && e.kind !== "keep" && e.kind !== "exile" && e.kind !== "discard" && (d -= y[t].kind === "fear" ? .05 : Math.max(.25, u(y[t].effect) * .5));
	return d;
}
function at(e) {
	let t = 4294967296 - 4294967296 % e, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return n % e;
}
function ot(e = rt) {
	return (t, n) => {
		let r = t.private;
		if (t.public.turn !== n.rid || !r?.moves.length) return null;
		let i;
		return i = n.difficulty === "weak" ? r.moves[at(r.moves.length)] : r.moves.reduce((i, a) => it(a, t.public, r, n.rid, e) > it(i, t.public, r, n.rid, e) ? a : i), { action: {
			type: "move",
			id: i.id
		} };
	};
}
var st = ot(), Q = (e, t, n) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
});
function ct({ at: e, children: t, flip: i = !1 }) {
	let a = r(null);
	return n(() => {
		let e = a.current?.animate(i ? [{
			transform: "perspective(700px) rotateY(90deg)",
			opacity: .2
		}, {
			transform: "perspective(700px) rotateY(0)",
			opacity: 1
		}] : [{ transform: "rotate(-16deg) scale(.85)" }, { transform: "rotate(0) scale(1)" }], {
			duration: 480,
			easing: "ease-out"
		});
		return () => e?.cancel();
	}, [i]), /* @__PURE__ */ m("div", {
		ref: a,
		className: "arnak-fx-turn",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: t
	});
}
function lt({ at: e, id: t }) {
	let i = r(null);
	return n(() => {
		let e = i.current?.animate([{
			transform: "translateY(0) scale(1)",
			opacity: 1
		}, {
			transform: "translateY(-70px) scale(.6)",
			opacity: 0
		}], {
			duration: 480,
			easing: "ease-in"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ m("div", {
		ref: i,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ m($e, {
			id: t,
			compact: !0
		})
	});
}
var $ = (e) => e.data, ut = {
	worker(e, t) {
		let n = $(e), r = t.anchor(String(n.from)) ?? t.anchor(`seat:${e.rid}`), i = String(n.to), a = t.anchor(i) ?? t.anchor(String(n.fallback)) ?? t.anchor(`seat:${e.rid}`);
		return !r || !a ? null : {
			ms: 480,
			hide: t.anchor(i) && i.startsWith("worker:") ? [i] : [],
			node: /* @__PURE__ */ m(g, {
				from: Q(r, 30, 38),
				to: Q(a, 30, 38),
				ms: 480,
				children: /* @__PURE__ */ m("div", {
					className: "arnak-fx-worker",
					children: /* @__PURE__ */ m(J, { name: "worker" })
				})
			})
		};
	},
	research(e, t) {
		let n = $(e), r = t.anchor(String(n.from)), i = t.anchor(String(n.to));
		return !r || !i ? null : {
			ms: 480,
			hide: [String(n.to)],
			node: /* @__PURE__ */ m(g, {
				from: Q(r, 28, 32),
				to: Q(i, 28, 32),
				ms: 480,
				children: /* @__PURE__ */ m(J, { name: String(n.token) })
			})
		};
	},
	reveal(e, t) {
		let n = $(e), r = t.anchor(String(n.target));
		return r ? {
			ms: 480,
			hide: [String(n.target)],
			node: /* @__PURE__ */ m(ct, {
				at: r,
				flip: !0,
				children: /* @__PURE__ */ m("img", {
					src: K(String(n.art)),
					alt: "",
					style: {
						width: "100%",
						height: "100%",
						objectFit: "cover",
						border: "3px solid #b89a69",
						borderRadius: 7
					}
				})
			})
		} : null;
	},
	card(e, t) {
		let n = $(e), r = t.anchor(String(n.from)) ?? t.anchor(`seat:${e.rid}`), i = t.anchor(String(n.to)) ?? t.anchor(`seat:${e.rid}`);
		return !r || !i ? null : {
			ms: 480,
			hide: t.anchor(String(n.to)) ? [String(n.to)] : [],
			node: /* @__PURE__ */ m(g, {
				from: Q(r, 110, 158),
				to: Q(i, 110, 158),
				ms: 480,
				children: /* @__PURE__ */ m("div", {
					style: {
						width: 110,
						height: 158
					},
					children: /* @__PURE__ */ m($e, {
						id: String(n.id),
						compact: !0
					})
				})
			})
		};
	},
	removeCard(e, t) {
		let n = $(e), r = t.anchor(String(n.from)) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 480,
			node: /* @__PURE__ */ m(lt, {
				at: Q(r, 110, 158),
				id: String(n.id)
			})
		} : null;
	},
	object(e, t) {
		let n = $(e), r = t.anchor(String(n.from)) ?? t.anchor(`seat:${e.rid}`), i = String(n.to), a = t.anchor(i), o = a ?? t.anchor(`seat:${e.rid}`);
		if (!r || !o) return null;
		let s = n.shape === "idol" ? 38 : 100, c = n.shape === "idol" ? 42 : 130, l = n.shape === "idol" ? /* @__PURE__ */ m(J, { name: "idol" }) : n.shape === "assistant" ? /* @__PURE__ */ m(Z, {
			id: Number(n.id),
			gold: !!n.gold,
			ready: !!n.ready
		}) : n.shape === "guardian" ? /* @__PURE__ */ m("img", {
			src: K(`guardian-${n.id}`),
			alt: "",
			style: {
				width: "100%",
				height: "100%",
				objectFit: "contain"
			}
		}) : /* @__PURE__ */ h("div", {
			className: "arnak-temple-tile",
			children: [/* @__PURE__ */ m("strong", { children: D[Number(n.id)] }), /* @__PURE__ */ m(Y, { cost: ae[Number(n.id)] })]
		});
		return {
			ms: 480,
			hide: a && i.startsWith("piece:") ? [i] : [],
			node: /* @__PURE__ */ m(g, {
				from: Q(r, s, c),
				to: Q(o, s, c),
				ms: 480,
				children: /* @__PURE__ */ m("div", {
					style: {
						width: s,
						height: c
					},
					children: l
				})
			})
		};
	},
	draw(e, t) {
		let n = $(e), r = t.anchor(String(n.from)) ?? t.anchor("itemDeck"), i = t.anchor(e.rid === t.myRid ? String(n.to) : `seat:${e.rid}`);
		if (!r || !i) return null;
		let a = e.secret?.id;
		return {
			ms: 480,
			hide: e.rid === t.myRid && t.anchor(String(n.to)) ? [String(n.to)] : [],
			node: /* @__PURE__ */ m(g, {
				from: Q(r, 80, 115),
				to: Q(i, 80, 115),
				ms: 480,
				children: /* @__PURE__ */ m("div", {
					style: {
						width: 80,
						height: 115
					},
					children: a ? /* @__PURE__ */ m($e, {
						id: a,
						compact: !0
					}) : /* @__PURE__ */ m("div", {
						className: "arnak-fx-back",
						children: /* @__PURE__ */ m(J, { name: "glass" })
					})
				})
			})
		};
	},
	resource(e, t) {
		let n = $(e), r = t.anchor(`resource:${e.rid}:${n.resource}`) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 480,
			node: /* @__PURE__ */ m(ee, {
				at: r,
				ms: 480,
				children: /* @__PURE__ */ h("span", {
					className: "arnak-fx-resource",
					children: [
						Number(n.amount) > 0 ? "+" : "",
						n.amount,
						/* @__PURE__ */ m(J, { name: String(n.resource) })
					]
				})
			})
		} : null;
	},
	action(e, t) {
		let n = $(e), r = t.anchor(String(n.target)) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 480,
			node: /* @__PURE__ */ m(_, {
				at: r,
				ms: 480
			})
		} : null;
	},
	turnObject(e, t) {
		let n = $(e), r = String(n.target), i = t.anchor(r), a = i ?? t.anchor(`seat:${e.rid}`);
		return a ? {
			ms: 480,
			hide: i ? [r] : [],
			node: /* @__PURE__ */ m(ct, {
				at: i ?? Q(a, 100, 140),
				flip: !0,
				children: /* @__PURE__ */ m(Z, {
					id: Number(n.id),
					gold: !!n.gold,
					ready: !!n.ready
				})
			})
		} : null;
	},
	round(e, t) {
		let n = t.anchor(`inventory:${t.myRid}`);
		return n ? {
			ms: 480,
			node: /* @__PURE__ */ m(ee, {
				at: n,
				ms: 480,
				children: /* @__PURE__ */ m(q, {
					name: "roundFx",
					children: /* @__PURE__ */ h("strong", {
						className: "arnak-fx-resource",
						children: [String($(e).round), " / 5"]
					})
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/arnak/game-over.tsx
function dt(e) {
	let t = a(), [n, r] = i(!0), o = e.public, s = (t) => e.members.find((e) => e.rid === t)?.name ?? t, c = [
		["research", "games.arnak.resultResearch"],
		["temple", "games.arnak.resultTemple"],
		["idols", "games.arnak.resultIdols"],
		["slots", "games.arnak.resultSlots"],
		["guardians", "games.arnak.resultGuardians"],
		["cards", "games.arnak.resultCards"],
		["fear", "games.arnak.resultFear"],
		["total", "games.arnak.resultTotal"]
	], l = o.players[0], u = o.rival, d = u ? l.score.total > u.score ? t("games.arnak.resultWinner") : l.score.total === u.score ? t("games.arnak.resultDraw") : t("games.arnak.resultDefeat") : t(e.result.winner.length > 1 ? "games.arnak.resultDraw" : "games.arnak.resultWinner");
	return /* @__PURE__ */ h("div", {
		className: "arnak-root arnak-result-root",
		children: [/* @__PURE__ */ m(nt, {
			...e,
			send: () => {},
			readOnly: !0,
			onBackToReport: () => r(!0)
		}), n && /* @__PURE__ */ m("div", {
			className: "arnak-result-layer",
			children: /* @__PURE__ */ h("section", {
				className: "arnak-ledger",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": t("games.arnak.resultTitle"),
				children: [
					/* @__PURE__ */ m("h1", { children: t("games.arnak.resultTitle") }),
					/* @__PURE__ */ h("p", {
						className: "arnak-ledger-result",
						children: [d, e.result.winner.length > 0 && ` · ${e.result.winner.map(s).join(" · ")}`]
					}),
					/* @__PURE__ */ h("table", {
						className: "arnak-score-table",
						children: [/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [
							/* @__PURE__ */ m("th", { children: t("games.arnak.expedition") }),
							e.result.ranking.map((e) => /* @__PURE__ */ m("th", { children: s(e) }, e)),
							u && /* @__PURE__ */ m("th", { children: t("games.arnak.rival") })
						] }) }), /* @__PURE__ */ m("tbody", { children: c.map(([n, r]) => /* @__PURE__ */ h("tr", { children: [
							/* @__PURE__ */ m("th", { children: t(r) }),
							e.result.ranking.map((e) => /* @__PURE__ */ m("td", { children: o.players.find((t) => t.rid === e).score[n] }, e)),
							u && /* @__PURE__ */ m("td", { children: n === "total" ? u.score : n === "research" ? (o.config.temple === "bird" ? [
								0,
								1,
								2,
								4,
								6,
								9,
								12,
								16,
								0
							] : [
								0,
								1,
								2,
								3,
								4,
								5,
								10,
								15,
								0
							])[u.glass.row] + u.templePoints : n === "guardians" ? u.guardians.length * 5 : n === "idols" ? u.idols.reduce((e, t) => e + (t === "$duplicate" ? 2 : 3), 0) : n === "cards" ? u.cards.reduce((e, t) => e + y[t].points, 0) : n === "temple" ? u.templeTiles.reduce((e, t) => e + D[t], 0) : 0 })
						] }, n)) })]
					}),
					/* @__PURE__ */ h("footer", {
						className: "arnak-ledger-foot",
						children: [
							/* @__PURE__ */ m("button", {
								onClick: () => r(!1),
								children: t("games.arnak.reviewBoard")
							}),
							e.onPlayAgain && /* @__PURE__ */ m(v, {
								label: t("games.arnak.playAgain"),
								confirmLabel: t("games.arnak.confirmAgain"),
								onConfirm: e.onPlayAgain
							}),
							" ",
							e.onBackToLobby && /* @__PURE__ */ m(v, {
								label: t("games.arnak.backLobby"),
								confirmLabel: t("games.arnak.confirmLobby"),
								onConfirm: e.onBackToLobby
							}),
							" ",
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ m("span", { children: t("games.arnak.waitHost") })
						]
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/games/arnak/options.tsx
function ft({ value: e, onChange: t }) {
	let n = a(), r = O.parse(e ?? {});
	return /* @__PURE__ */ h("div", {
		className: "arnak-options",
		children: [/* @__PURE__ */ h("label", { children: [n("games.arnak.templeOption"), /* @__PURE__ */ h("select", {
			value: r.temple,
			onChange: (e) => t({
				...r,
				temple: e.target.value
			}),
			children: [/* @__PURE__ */ m("option", {
				value: "bird",
				children: n("games.arnak.bird")
			}), /* @__PURE__ */ m("option", {
				value: "snake",
				children: n("games.arnak.snake")
			})]
		})] }), /* @__PURE__ */ h("label", { children: [
			n("games.arnak.difficulty"),
			/* @__PURE__ */ m("input", {
				type: "range",
				min: 0,
				max: 5,
				value: r.rivalDifficulty,
				onChange: (e) => t({
					...r,
					rivalDifficulty: Number(e.target.value)
				})
			}),
			/* @__PURE__ */ m("span", { children: n("games.arnak.difficultyHint", { n: r.rivalDifficulty }) })
		] })]
	});
}
//#endregion
//#region src/games/arnak/guide.tsx
function pt() {
	let e = a();
	return /* @__PURE__ */ m("article", {
		className: "arnak-guide",
		children: /* @__PURE__ */ m("div", {
			className: "arnak-guide-legend",
			children: Object.entries(ne).map(([t, n]) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m(J, { name: t }), e(n)] }, t))
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/arnak/entry.tsx
var mt = {
	definition: Je,
	View: tt,
	bot: st,
	fx: ut,
	OverView: dt,
	Options: ft,
	Guide: pt,
	locales: {
		zh: {
			rescue: "救助助手",
			gainItem: "免费获得一张物品",
			exileSelf: "放逐此牌",
			buyItemDiscount: "购买物品，少支付 {{n}} 金币",
			buyArtifactDiscount: "购买神器，少支付 {{n}} 罗盘",
			researchRow: "研究第 {{n}} 层",
			usedSlot: "已放入神像",
			discardOne: "弃 1 张手牌",
			confirmAgain: "确认再次考察",
			confirmLobby: "确认返回大厅",
			name: "阿纳克遗迹",
			desc: "探索失落岛屿，构筑考察牌库，揭开古文明的秘密",
			errTurn: "当前不能行动。",
			errMove: "此行动已经不可用，请重新选择。",
			logArrival: "考察队抵达阿纳克。",
			logGained: "获得{{name}}。",
			logResearch: "推进了{{name}}。",
			logExpedition: "{{name}}。",
			logRound: "第 {{n}} 轮开始。",
			logRival: "对手完成了一次行动。",
			buyCard: "购买{{name}}",
			playCard: "打出{{name}}",
			useAssistant: "使用{{name}}",
			useBoon: "使用{{name}}的恩赐",
			useIdol: "使用神像插槽",
			chooseEffect: "选择此项效果",
			removeCard: "{{action}}{{name}}",
			trade: "支付并获得收益",
			travelTrade: "支付旅行符号并获得收益",
			upgradeResource: "升级资源",
			rescueAssistant: "救助{{name}}",
			recruitAssistant: "招募{{name}}",
			refreshAssistant: "{{action}}{{name}}",
			activateSite: "激活此地点",
			relocateWorker: "从地点 {{n}} 迁移考古学家并激活目标",
			returnWorker: "收回考古学家",
			moveGuardian: "转移守护者",
			returnIdol: "退回神像",
			exchangeAssistant: "以{{old}}换取{{name}}",
			copyAssistant: "使用{{name}}的效果",
			chooseBenefit: "选择一种收益",
			takeBonus: "领取研究奖励",
			lookCards: "查看 {{n}} 张牌",
			keepCard: "保留{{name}}",
			topCard: "将{{name}}放回牌堆顶",
			gainCard: "获得{{name}}",
			skip: "放弃此项效果",
			discardCard: "弃置{{name}}",
			prepareRound: "保留剩余手牌并准备下一轮",
			pass: "结束本轮行动",
			endTurn: "结束回合",
			advanceResearch: "推进{{name}}至第 {{n}} 层",
			buyTemple: "购买 {{n}} 分神庙板块",
			discoverSite: "发现 {{n}} 级遗址",
			deployWorker: "派遣考古学家",
			overcomeGuardian: "克服{{name}}",
			glass: "放大镜",
			book: "笔记本",
			discard: "弃置",
			exile: "放逐",
			promote: "升级",
			refresh: "刷新",
			discovery: "发现了新的遗址",
			deployment: "派出了考古学家",
			map: "探险地图",
			research: "研究",
			market: "市场",
			expedition: "考察队",
			round: "第 {{n}} / 5 轮",
			yourTurn: "轮到你行动",
			waiting: "等待{{name}}行动",
			rival: "对手考察队",
			returning: "考古学家返回营地",
			cleanup: "选择留到下一轮的手牌",
			choose: "选择效果",
			mainAvailable: "选择一项主行动",
			mainUsed: "可使用免费效果或结束回合",
			hand: "手牌",
			played: "打出区",
			deck: "牌堆",
			details: "查看详情",
			close: "关闭",
			confirm: "确认行动",
			cancel: "取消",
			pay: "支付",
			gain: "获得",
			free: "免费",
			points: "{{n}} 分",
			camp: "营地",
			site: "遗址 {{n}}",
			level: "{{n}} 级遗址",
			unknown: "未发现",
			guardian: "守护者",
			idols: "神像",
			assistants: "助手",
			boons: "守护者恩赐",
			supply: "补给区",
			ready: "可使用",
			exhausted: "已使用",
			passed: "已结束本轮",
			workers: "考古学家 {{n}} / 2",
			noMoves: "暂无可执行的行动",
			paymentCards: "用于付款的手牌",
			passConfirm: "结束本轮后，你将不再获得回合。",
			log: "考察记录",
			bird: "鸟神庙",
			snake: "蛇神庙",
			templeOption: "版图",
			difficulty: "单人对手难度",
			difficultyHint: "红色行动牌数量：{{n}} / 5",
			resultTitle: "阿纳克考察报告",
			resultWinner: "最卓越的考察队",
			resultDefeat: "对手赢得了这次探索",
			resultDraw: "考察队并列",
			resultResearch: "研究",
			resultTemple: "神庙板块",
			resultIdols: "神像",
			resultSlots: "空神像槽",
			resultGuardians: "守护者",
			resultCards: "卡牌",
			resultFear: "恐惧",
			resultTotal: "总分",
			reviewBoard: "回看最终局面",
			backResult: "返回考察报告",
			playAgain: "再次考察",
			backLobby: "返回大厅",
			waitHost: "等待主机继续",
			item: "物品",
			artifact: "神器",
			fear: "恐惧",
			starter: "起始牌",
			slot: "神像槽 {{n}}",
			travel: "旅行",
			bonus: "研究奖励",
			temple: "失落神庙",
			actionsLeft: "剩余 {{n}} 次行动",
			silver: "银级",
			gold: "金级",
			retain: "保留",
			draw: "抽一张牌",
			draw2: "抽两张牌",
			overcome: "免费克服守护者",
			recruit: "招募助手",
			freeArtifact: "免费获得神器",
			upgrade: "升级一件资源",
			drawN: "抽 {{n}} 张牌",
			drawDiscard: "抽 1 张牌，然后弃置 1 张手牌",
			none: "无",
			allPlanes: "本轮旅行均视为飞机",
			noFear: "本轮不因守护者获得恐惧",
			choosePayment: "选择付款组合",
			emptySlot: "空槽得 {{n}} 分",
			useSlot: "放入神像并选择效果",
			showAll: "全部行动",
			inspect: "查看物件",
			notOccupied: "无人占据",
			blocked: "不可用",
			buyPlane: "可用 2 金币支付一个飞机符号",
			resourceCount: "{{name}}：{{n}}",
			actionEffect: "效果",
			orderFirst: "先结算",
			card1208Name: "石钥匙",
			card1208Text: "将玩家板插槽中的 1 个神像移回自己的储备区。",
			card0218Name: "巨蛇黄金",
			card0218Text: "获得 1 张恐惧牌和 4 金币。",
			card0201Name: "宝箱",
			card0201Text: "抽 1 张牌，获得 1 金币。",
			card0213Name: "雕饰锤",
			card0213Text: "放逐市场最右侧物品，再从放逐区获得一张物品并放入自己牌堆底。",
			card0216Name: "星图",
			card0216Text: "支付 1 金币，激活两处不同的营地地点。",
			card0214Name: "水晶耳环",
			card0214Text: "从牌堆顶抽至多 3 张，保留 1 张；可将另外 1 张放回牌堆顶，其余弃入打出区。",
			card0206Name: "仪式匕首",
			card0206Text: "放逐 1 张手牌或打出区的牌，获得 1 箭头。",
			card0205Name: "寻路者之杖",
			card0205Text: "将一名已派出的考古学家移至空置的营地或一级遗址并激活该地点。",
			card0204Name: "亡者符文",
			card0204Text: "获得 1 张恐惧牌、1 金币和 3 石板。",
			card0225Name: "寻路者凉鞋",
			card0225Text: "将一名已派出的考古学家移至空置的营地地点并激活该地点。",
			card0210Name: "战棍",
			card0210Text: "免费克服一名自己占据地点上的守护者。",
			card0208Name: "虎爪发簪",
			card0208Text: "放逐一张牌，然后激活一处没有考古学家的营地地点。",
			card0217Name: "守护者陶笛",
			card0217Text: "收回一名已派出的考古学家；本轮自己的每个旅行符号均可视为飞机。",
			card0223Name: "通行海螺",
			card0223Text: "免费派遣考古学家至营地地点，可将该地点激活两次。",
			card0212Name: "商人天平",
			card0212Text: "升级 1 个资源，获得 3 金币。",
			card0235Name: "日晷",
			card0235Text: "获得 2 石板；或结束本轮行动并获得 1 宝石。",
			card0234Name: "装饰号角",
			card0234Text: "以自己的一名助手换取供应区顶牌助手，等级不变并刷新。",
			card0228Name: "指引石",
			card0228Text: "揭示一级遗址牌堆顶板块，激活后放到该牌堆底。",
			card0220Name: "净化坩埚",
			card0220Text: "抽 1 张牌，然后可放逐 1 张手牌或打出区的牌。",
			card0219Name: "商人钱币",
			card0219Text: "升级 1 个资源，获得 2 金币。",
			card0215Name: "守护者王冠",
			card0215Text: "把自己占据地点上的守护者移至一处没有守护者且未被占据的营地或一级遗址，并激活目标地点。",
			card0211Name: "黑曜石耳环",
			card0211Text: "从牌堆底抽至多 2 张，保留 1 张，其余弃入打出区。",
			card0231Name: "巨蛇神像",
			card0231Text: "获得 1 张恐惧牌和 1 宝石。",
			card0207Name: "猴子护符",
			card0207Text: "免费获得一张市场物品并放在自己牌堆顶。",
			card0226Name: "战面具",
			card0226Text: "获得 1 箭头；本轮从有守护者的地点收回考古学家时，不获得恐惧牌。",
			card0203Name: "狩猎箭",
			card0203Text: "获得 1 张恐惧牌和 2 箭头。",
			card0233Name: "铭文刀",
			card0233Text: "推进任一研究标记，少支付 1 箭头或 2 石板。",
			card0202Name: "指引头骨",
			card0202Text: "支付 1 罗盘，揭示二级遗址牌堆顶板块，激活后放到该牌堆底。",
			card0221Name: "研钵",
			card0221Text: "放逐 1 张手牌或打出区的牌，获得 2 金币。",
			card0222Name: "古酒",
			card0222Text: "支付 1 金币，使用供应区一名顶牌助手的金色面效果。",
			card0232Name: "石罐",
			card0232Text: "抽 1 张牌。",
			card0227Name: "椰子水壶",
			card0227Text: "支付 2 金币，使用供应区一名顶牌助手的银色面效果。",
			card0224Name: "阿拉阿努神像",
			card0224Text: "推进任一研究标记，少支付 1 宝石。",
			card0209Name: "神圣鼓",
			card0209Text: "弃 1 张手牌，刷新自己的两名助手。",
			card0230Name: "仪式摇铃",
			card0230Text: "刷新自己的一名助手。",
			card0109Name: "绳索",
			card0109Text: "弃 1 张手牌，然后抽 2 张牌。",
			card0110Name: "鸵鸟",
			card0110Text: "抽 1 张牌，然后派遣考古学家，少支付 1 个汽车旅行符号。",
			card0108Name: "怀表",
			card0108Text: "免费获得 2 金币；或结束本轮行动并获得 3 金币。",
			card0107Name: "泥铲",
			card0107Text: "支付 1 罗盘，获得 1 宝石。",
			card0132Name: "计时器",
			card0132Text: "免费获得 1 金币和 1 罗盘；或结束本轮行动并获得 3 罗盘。",
			card0106Name: "信鸽",
			card0106Text: "免费获得 2 石板。",
			card0105Name: "马匹",
			card0105Text: "抽 1 张牌，获得 1 金币和 1 罗盘。",
			card0104Name: "望远镜",
			card0104Text: "激活任意一处已发现的一级遗址。",
			card0103Name: "水壶",
			card0103Text: "放逐此牌，抽 3 张牌。",
			card0101Name: "日志",
			card0101Text: "放逐此牌，免费推进笔记本一次。",
			card0102Name: "猎犬",
			card0102Text: "获得 1 罗盘，然后激活一处没有考古学家的营地地点。",
			card0119Name: "鹤嘴锄",
			card0119Text: "支付 1 罗盘，获得 1 石板和 1 箭头。",
			card0120Name: "精密罗盘",
			card0120Text: "购买一张神器，少支付 3 罗盘；也可选择神器牌堆顶牌。",
			card0118Name: "火把",
			card0118Text: "放逐 1 张手牌或打出区的牌，获得 1 石板。",
			card0117Name: "驮驴",
			card0117Text: "抽 2 张牌。",
			card0116Name: "简略地图",
			card0116Text: "放逐此牌，获得 3 罗盘。",
			card0111Name: "耐用靴子",
			card0111Text: "获得 1 罗盘，然后派遣考古学家，少支付 1 个步行旅行符号。",
			card0112Name: "空投",
			card0112Text: "放逐此牌，免费获得一张市场物品并加入手牌。",
			card0130Name: "淘金盘",
			card0130Text: "免费获得 2 金币。",
			card0129Name: "抓钩",
			card0129Text: "弃 1 张手牌，抽 1 张牌，然后可放逐 1 张手牌或打出区的牌。",
			card0115Name: "大背包",
			card0115Text: "获得 1 金币，从牌堆底抽 1 张牌。",
			card0127Name: "海龟",
			card0127Text: "抽 1 张牌，然后派遣考古学家，少支付 1 个船只旅行符号。",
			card0123Name: "弓箭",
			card0123Text: "每有一名已克服的守护者或自己占据地点上的守护者，获得 1 罗盘，最多 3 罗盘。",
			card0122Name: "提灯",
			card0122Text: "激活任意一处营地地点。",
			card0121Name: "斧头",
			card0121Text: "放逐 1 张手牌或打出区的牌，获得 1 罗盘。",
			card0114Name: "毛刷",
			card0114Text: "每有 1 个神像获得 1 罗盘，最多 3 罗盘。",
			card0126Name: "军刀",
			card0126Text: "从放逐一张牌、获得 1 金币、1 罗盘或 1 石板中选择两种不同效果。",
			card0139Name: "经纬仪",
			card0139Text: "获得 1 金币；每有一名已派出的考古学家，再获得 1 罗盘。",
			card0137Name: "鞭子",
			card0137Text: "放逐此牌，购买一张市场神器，少支付 3 罗盘。",
			card0136Name: "帽子",
			card0136Text: "免费获得 1 金币和 1 罗盘。",
			card0113Name: "左轮手枪",
			card0113Text: "支付 1 罗盘，免费克服一名自己占据地点上的守护者。",
			card0125Name: "汽车",
			card0125Text: "免费获得 2 罗盘。",
			card0140Name: "汽船",
			card0140Text: "免费获得 2 罗盘。",
			card0135Name: "钓竿",
			card0135Text: "购买一张物品，少支付 3 金币；也可选择物品牌堆顶牌。",
			card0133Name: "捕兽夹",
			card0133Text: "放逐此牌，免费克服一名所在地点没有其他玩家考古学家的守护者。",
			card0128Name: "帐篷",
			card0128Text: "激活一处自己占据的地点；若为二级遗址，先支付 2 罗盘。",
			card0124Name: "热气球",
			card0124Text: "放逐此牌，然后派遣考古学家，少支付 1 个飞机旅行符号；发现新遗址还少支付 3 罗盘。",
			card0138Name: "鹦鹉",
			card0138Text: "弃 1 张手牌，获得 1 宝石。",
			card0134Name: "砍刀",
			card0134Text: "放逐 1 张手牌或打出区的牌，获得 2 罗盘。",
			card0131Name: "飞机",
			card0131Text: "派遣考古学家，少支付 1 个飞机旅行符号；发现新遗址还少支付 2 罗盘。",
			cardfundcarName: "资助",
			cardfundcarText: "免费获得 1 金币。",
			cardfundboatName: "资助",
			cardfundboatText: "免费获得 1 金币。",
			cardexplorecarName: "探索",
			cardexplorecarText: "免费获得 1 罗盘。",
			cardexploreboatName: "探索",
			cardexploreboatText: "免费获得 1 罗盘。",
			cardfearName: "恐惧",
			cardfearText: "不能作为效果打出。",
			cardfeartileName: "恐惧板块",
			cardfeartileText: "不能作为效果打出。",
			guardian1301: "巨蝎",
			guardian1302: "巨枭",
			guardian1303: "赤羽巨鸟",
			guardian1304: "赤蛇",
			guardian1305: "巨蚁",
			guardian1306: "赤蜥",
			guardian1307: "巨蛛",
			guardian1308: "圣甲虫",
			guardian1309: "角龙",
			guardian1310: "巨蛙",
			guardian1400: "独角兽",
			guardian1401: "荒原巨兽",
			guardian1402: "飞龙",
			guardian1403: "蝎尾狮",
			guardian1404: "青蛇",
			assistant601: "铭文学者",
			assistant602: "地质学家",
			assistant603: "珠宝商",
			assistant604: "驯犬师",
			assistant605: "搬运工",
			assistant606: "飞行员",
			assistant607: "向导",
			assistant608: "船长",
			assistant609: "商人",
			assistant610: "资源专家",
			assistant611: "勘探员",
			assistant600: "矿工",
			resourcec: "金币",
			resources: "罗盘",
			resourcet: "石板",
			resourcea: "箭头",
			resourcej: "宝石",
			remainingTravel: "本回合剩余旅行",
			resourceboot: "步行",
			resourcecar: "汽车",
			resourceboat: "船只",
			resourceplane: "飞机",
			rules: "目标：\n带领考察队探索阿纳克，在五轮后获得最多分数。基础版包含鸟神庙、蛇神庙和单人对手。\n准备：\n每人有两名考古学家，起始牌库为两张资助、两张探索和两张恐惧。首轮每人抽取五张牌。按照行动顺序，各座位获得以下起始物资：\n· 第一位获得两枚金币。\n· 第二位获得一枚金币和一枚罗盘。\n· 第三位获得两枚金币和一枚罗盘。\n· 第四位获得一枚金币和两枚罗盘。\n单人玩家使用第二位的起始物资，对手始终先行动。\n回合：\n每回合选择一项主行动：派遣考古学家、发现遗址、克服守护者、购买卡牌、打出一张有效果的牌、推进研究，或结束本轮行动。免费效果可在主行动前后及其中使用；主行动完成后点击结束回合。结束本轮后不再获得回合。\n旅行与探索：\n从手牌支付旅行符号；汽车和船只可代替步行，飞机可代替任何符号，汽车与船只不能互换。可以支付2枚金币购买一个飞机符号。同一张牌的剩余旅行符号仅在本回合有效。派遣考古学家到空位并激活地点；发现一级或二级遗址另外支付3枚或6枚罗盘。发现后获得神像、结算正面神像收益、激活遗址并放置守护者。遗址和神像收益可选择结算顺序。\n守护者与神像：\n克服自己考古学家所在遗址的守护者需要支付其费用。守护者值五分，恩赐一局可使用一次。轮末从仍有守护者的地点收回每名考古学家时各获得一张恐惧。神像各值三分；可将储备中的神像放入最左空槽作为免费行动，选择下列一种效果：\n· 支付1枚金币，换取1颗宝石。\n· 获得1枚箭头。\n· 获得2块石板。\n· 抽取1张牌。\n· 升级1件资源。\n空槽依次值一、二、三、四分。\n卡牌与助手：\n市场共六张牌，神器数量等于轮数。物品支付金币，购入后放自己牌堆底；神器支付罗盘，购入后放打出区并立即使用效果。以后从手牌打出神器需要另付一石板。市场在回合结束补满。恐惧不能打出效果，每张扣一分；恐惧牌供应耗尽时获得扣两分的恐惧板块。放逐可从手牌或打出区选择。付费箭头左侧必须支付，才能领取右侧收益。升级资源可将石板换为箭头，或箭头换为宝石。助手招募后可使用一次，轮末刷新；升级助手也会刷新。商人的购牌效果使用主行动，其他助手效果为免费行动。\n研究：\n支付连接路径上的费用，将放大镜或笔记本上移一层，结算对应行收益及尚存的抢先奖励。笔记本不能高于放大镜，不能进入失落神庙。放大镜抵达神庙依顺序获得二十三、二十一、二十、十九分，并私下从隐藏奖励堆选一枚；以后研究可改买神庙板块。蛇神庙跨桥需要移除一个未入槽神像；救助助手时可私下查看整堆并选一名，新助手为已使用状态。\n轮末与结束：\n全部玩家结束本轮后，先收回人物并获得恐惧，再选择保留或弃置剩余手牌。将打出区洗好放现有牌堆底，刷新助手，将月杖两侧各一张牌放逐，准备下一轮并补手牌至五张。轮中不会洗牌。第五轮只收回人物并结算恐惧，随后计分。\n计分：\n合计研究、神庙板块、神像、空神像槽、守护者和卡牌分数，再扣恐惧。总分相同则先抵达神庙者胜；无人抵达时比较研究分，仍同分则并列。\n单人对手：\n按难度零至五随机选择对应数量的红色行动牌，其余使用绿色。对手每轮执行十张行动牌，与你交替；它不收支资源、不获得恐惧。它会占位、发现、研究、克服和购买卡牌，并按行动堆箭头选择左右。绿色发现、研究、克服在第五轮不执行。对手的重复或背面神像各值两分。"
		},
		en: {
			rescue: "Rescue an assistant",
			gainItem: "Gain an item for free",
			exileSelf: "Exile this card",
			buyItemDiscount: "Buy an item with a {{n}}-coin discount",
			buyArtifactDiscount: "Buy an artifact with a {{n}}-compass discount",
			researchRow: "Research row {{n}}",
			usedSlot: "Idol placed",
			discardOne: "Discard 1 hand card",
			confirmAgain: "Start another expedition?",
			confirmLobby: "Return to lobby?",
			name: "Lost Ruins of Arnak",
			desc: "Explore a lost island, build your expedition deck and uncover an ancient civilization",
			errTurn: "You cannot act now.",
			errMove: "This action is no longer available. Choose again.",
			logArrival: "The expeditions arrive on Arnak.",
			logGained: "Gained {{name}}.",
			logResearch: "Advanced the {{name}}.",
			logExpedition: "{{name}}.",
			logRound: "Round {{n}} begins.",
			logRival: "The rival resolved an action.",
			buyCard: "Buy {{name}}",
			playCard: "Play {{name}}",
			useAssistant: "Use {{name}}",
			useBoon: "Use the {{name}}’s boon",
			useIdol: "Use an idol slot",
			chooseEffect: "Choose this effect",
			removeCard: "{{action}} {{name}}",
			trade: "Pay to gain the benefit",
			travelTrade: "Spend travel to gain the benefit",
			upgradeResource: "Upgrade a resource",
			rescueAssistant: "Rescue {{name}}",
			recruitAssistant: "Recruit {{name}}",
			refreshAssistant: "{{action}} {{name}}",
			activateSite: "Activate this site",
			relocateWorker: "Relocate from site {{n}} and activate the destination",
			returnWorker: "Return an archaeologist",
			moveGuardian: "Move the guardian",
			returnIdol: "Return an idol from a slot",
			exchangeAssistant: "Exchange {{old}} for {{name}}",
			copyAssistant: "Use {{name}}’s effect",
			chooseBenefit: "Choose a benefit",
			takeBonus: "Take a research bonus",
			lookCards: "Look at {{n}} cards",
			keepCard: "Keep {{name}}",
			topCard: "Return {{name}} to the top",
			gainCard: "Gain {{name}}",
			skip: "Skip this effect",
			discardCard: "Discard {{name}}",
			prepareRound: "Keep remaining cards and prepare next round",
			pass: "Pass for this round",
			endTurn: "End turn",
			advanceResearch: "Advance {{name}} to row {{n}}",
			buyTemple: "Buy a {{n}}-point temple tile",
			discoverSite: "Discover a level {{n}} site",
			deployWorker: "Deploy an archaeologist",
			overcomeGuardian: "Overcome {{name}}",
			glass: "Magnifying glass",
			book: "Notebook",
			discard: "Discard",
			exile: "Exile",
			promote: "Upgrade",
			refresh: "Refresh",
			discovery: "Discovered a new site",
			deployment: "Deployed an archaeologist",
			map: "Island",
			research: "Research",
			market: "Market",
			expedition: "Expedition",
			round: "Round {{n}} / 5",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}",
			rival: "Rival expedition",
			returning: "Returning to camp",
			cleanup: "Choose cards to keep for next round",
			choose: "Choose an effect",
			mainAvailable: "Choose a main action",
			mainUsed: "Use free effects or end your turn",
			hand: "Hand",
			played: "Play area",
			deck: "Deck",
			details: "Details",
			close: "Close",
			confirm: "Confirm action",
			cancel: "Cancel",
			pay: "Pay",
			gain: "Gain",
			free: "Free",
			points: "{{n}} VP",
			camp: "Camp",
			site: "Site {{n}}",
			level: "Level {{n}} site",
			unknown: "Undiscovered",
			guardian: "Guardian",
			idols: "Idols",
			assistants: "Assistants",
			boons: "Guardian boons",
			supply: "Supply",
			ready: "Ready",
			exhausted: "Exhausted",
			passed: "Passed",
			workers: "Archaeologists {{n}} / 2",
			noMoves: "No action is available",
			paymentCards: "Cards used for payment",
			passConfirm: "You will take no more turns this round.",
			log: "Expedition log",
			bird: "Bird Temple",
			snake: "Snake Temple",
			templeOption: "Board",
			difficulty: "Solo rival difficulty",
			difficultyHint: "Red action tiles: {{n}} / 5",
			resultTitle: "Arnak Expedition Report",
			resultWinner: "Leading expedition",
			resultDefeat: "The rival wins this expedition",
			resultDraw: "Expeditions tied",
			resultResearch: "Research",
			resultTemple: "Temple tiles",
			resultIdols: "Idols",
			resultSlots: "Empty idol slots",
			resultGuardians: "Guardians",
			resultCards: "Cards",
			resultFear: "Fear",
			resultTotal: "Total",
			reviewBoard: "Review final island",
			backResult: "Back to report",
			playAgain: "Explore again",
			backLobby: "Back to lobby",
			waitHost: "Waiting for the host",
			item: "Item",
			artifact: "Artifact",
			fear: "Fear",
			starter: "Starting card",
			slot: "Idol slot {{n}}",
			travel: "Travel",
			bonus: "Research bonus",
			temple: "Lost Temple",
			actionsLeft: "{{n}} actions left",
			silver: "Silver",
			gold: "Gold",
			retain: "Keep",
			draw: "Draw a card",
			draw2: "Draw two cards",
			overcome: "Overcome a guardian for free",
			recruit: "Recruit an assistant",
			freeArtifact: "Gain an artifact for free",
			upgrade: "Upgrade a resource",
			drawN: "Draw {{n}} cards",
			drawDiscard: "Draw 1 card, then discard 1 hand card",
			none: "None",
			allPlanes: "All travel icons count as airplanes this round",
			noFear: "No Fear from guardians this round",
			choosePayment: "Choose payment",
			emptySlot: "Empty slot: {{n}} VP",
			useSlot: "Place an idol and choose an effect",
			showAll: "All actions",
			inspect: "Inspect",
			notOccupied: "Unoccupied",
			blocked: "Blocked",
			buyPlane: "You may pay 2 coins for an airplane icon",
			resourceCount: "{{name}}: {{n}}",
			actionEffect: "Effect",
			orderFirst: "Resolve first",
			card1208Name: "Stone Key",
			card1208Text: "Move one idol from a slot on your player board back to your supply crates.",
			card0218Name: "Serpent's Gold",
			card0218Text: "Gain a Fear card and 4 coins.",
			card0201Name: "Treasure Chest",
			card0201Text: "Draw a card and gain 1 coin.",
			card0213Name: "Ornate Hammer",
			card0213Text: "Exile the rightmost item in the card row, then gain any item from exile to the bottom of your deck.",
			card0216Name: "Star Charts",
			card0216Text: "Pay 1 coin to activate two different camp sites.",
			card0214Name: "Crystal Earring",
			card0214Text: "Draw up to 3 cards and keep 1. You may return 1 other card to the top of your deck; discard the rest.",
			card0206Name: "Ritual Dagger",
			card0206Text: "Exile a card from your hand or play area and gain 1 arrowhead.",
			card0205Name: "Pathfinder's Staff",
			card0205Text: "Relocate a placed archaeologist to an unoccupied camp or level I site and activate it.",
			card0204Name: "Runes of the Dead",
			card0204Text: "Gain a Fear card, 1 coin and 3 tablets.",
			card0225Name: "Pathfinder's Sandals",
			card0225Text: "Relocate a placed archaeologist to an unoccupied camp site and activate it.",
			card0210Name: "War Club",
			card0210Text: "Overcome a guardian on a site you occupy for free.",
			card0208Name: "Tigerclaw Hairpin",
			card0208Text: "Exile a card, then activate an unoccupied camp site.",
			card0217Name: "Guardian's Ocarina",
			card0217Text: "Return a placed archaeologist. Each of your travel icons counts as an airplane this round.",
			card0223Name: "Passage Shell",
			card0223Text: "Deploy an archaeologist onto a camp site for free. You may activate it twice.",
			card0212Name: "Trader's Scales",
			card0212Text: "Upgrade 1 resource and gain 3 coins.",
			card0235Name: "Sundial",
			card0235Text: "Gain 2 tablets, or pass to gain 1 jewel.",
			card0234Name: "Decorated Horn",
			card0234Text: "Exchange an assistant with one on top of a supply stack. The new assistant keeps the same level and is refreshed.",
			card0228Name: "Guiding Stone",
			card0228Text: "Reveal the top level I site tile, activate it, then put it on the bottom of that stack.",
			card0220Name: "Cleansing Cauldron",
			card0220Text: "Draw a card, then you may exile a card from your hand or play area.",
			card0219Name: "Trader's Coins",
			card0219Text: "Upgrade 1 resource and gain 2 coins.",
			card0215Name: "Guardian's Crown",
			card0215Text: "Move a guardian from a site you occupy to an unoccupied camp or level I site without a guardian. Activate that site.",
			card0211Name: "Obsidian Earring",
			card0211Text: "Draw up to 2 cards from the bottom of your deck. Keep 1 and discard the other.",
			card0231Name: "Serpent Idol",
			card0231Text: "Gain a Fear card and 1 jewel.",
			card0207Name: "Monkey Medallion",
			card0207Text: "Gain an item from the card row for free and put it on top of your deck.",
			card0226Name: "War Mask",
			card0226Text: "Gain 1 arrowhead. Do not gain Fear from guardians when returning archaeologists this round.",
			card0203Name: "Hunting Arrows",
			card0203Text: "Gain a Fear card and 2 arrowheads.",
			card0233Name: "Inscribed Blade",
			card0233Text: "Research with a discount of either 1 arrowhead or 2 tablets.",
			card0202Name: "Guiding Skull",
			card0202Text: "Pay 1 compass to reveal and activate the top level II site tile, then put it on the bottom of its stack.",
			card0221Name: "Mortar",
			card0221Text: "Exile a card from your hand or play area and gain 2 coins.",
			card0222Name: "Ancient Wine",
			card0222Text: "Pay 1 coin to use the gold effect of an assistant on top of a supply stack.",
			card0232Name: "Stone Jar",
			card0232Text: "Draw a card.",
			card0227Name: "Coconut Flask",
			card0227Text: "Pay 2 coins to use the silver effect of an assistant on top of a supply stack.",
			card0224Name: "Idol of Ara-Anu",
			card0224Text: "Research with a discount of 1 jewel.",
			card0209Name: "Sacred Drum",
			card0209Text: "Discard a card to refresh both your assistants.",
			card0230Name: "Ceremonial Rattle",
			card0230Text: "Refresh 1 assistant.",
			card0109Name: "Rope",
			card0109Text: "Discard a card, then draw 2 cards.",
			card0110Name: "Ostrich",
			card0110Text: "Draw a card, then deploy an archaeologist with a discount of 1 car.",
			card0108Name: "Watch",
			card0108Text: "Gain 2 coins as a free action, or pass to gain 3 coins.",
			card0107Name: "Trowel",
			card0107Text: "Pay 1 compass to gain 1 jewel.",
			card0132Name: "Chronometer",
			card0132Text: "Gain 1 coin and 1 compass as a free action, or pass to gain 3 compasses.",
			card0106Name: "Carrier Pigeon",
			card0106Text: "Gain 2 tablets as a free action.",
			card0105Name: "Horse",
			card0105Text: "Draw a card and gain 1 coin and 1 compass.",
			card0104Name: "Binoculars",
			card0104Text: "Activate any discovered level I site.",
			card0103Name: "Flask",
			card0103Text: "Exile this card to draw 3 cards.",
			card0101Name: "Journal",
			card0101Text: "Exile this card to research with your notebook for free.",
			card0102Name: "Dog",
			card0102Text: "Gain 1 compass and activate an unoccupied camp site.",
			card0119Name: "Pickaxe",
			card0119Text: "Pay 1 compass to gain 1 tablet and 1 arrowhead.",
			card0120Name: "Precision Compass",
			card0120Text: "Buy an artifact with a discount of 3 compasses, including the top card of the artifact deck.",
			card0118Name: "Torch",
			card0118Text: "Exile a card from your hand or play area and gain 1 tablet.",
			card0117Name: "Pack Donkey",
			card0117Text: "Draw 2 cards.",
			card0116Name: "Rough Map",
			card0116Text: "Exile this card to gain 3 compasses.",
			card0111Name: "Sturdy Boots",
			card0111Text: "Gain 1 compass, then deploy an archaeologist with a discount of 1 boot.",
			card0112Name: "Airdrop",
			card0112Text: "Exile this card to gain an item from the card row to your hand for free.",
			card0130Name: "Gold Pan",
			card0130Text: "Gain 2 coins as a free action.",
			card0129Name: "Grappling Hook",
			card0129Text: "Discard a card, draw a card, then you may exile a card from your hand or play area.",
			card0115Name: "Large Backpack",
			card0115Text: "Gain 1 coin and draw a card from the bottom of your deck.",
			card0127Name: "Sea Turtle",
			card0127Text: "Draw a card, then deploy an archaeologist with a discount of 1 boat.",
			card0123Name: "Bow and Arrows",
			card0123Text: "Gain 1 compass for each guardian you have overcome and each guardian on a site you occupy, up to 3.",
			card0122Name: "Lantern",
			card0122Text: "Activate any camp site.",
			card0121Name: "Axe",
			card0121Text: "Exile a card from your hand or play area and gain 1 compass.",
			card0114Name: "Brush",
			card0114Text: "Gain 1 compass for each idol you have, up to 3.",
			card0126Name: "Army Knife",
			card0126Text: "Choose two different benefits: exile a card, gain 1 coin, gain 1 compass, or gain 1 tablet.",
			card0139Name: "Theodolite",
			card0139Text: "Gain 1 coin and 1 compass for each of your archaeologists already placed on the board.",
			card0137Name: "Whip",
			card0137Text: "Exile this card to buy an artifact from the card row with a discount of 3 compasses.",
			card0136Name: "Hat",
			card0136Text: "Gain 1 coin and 1 compass as a free action.",
			card0113Name: "Revolver",
			card0113Text: "Pay 1 compass to overcome a guardian on a site you occupy for free.",
			card0125Name: "Automobile",
			card0125Text: "Gain 2 compasses as a free action.",
			card0140Name: "Steam Boat",
			card0140Text: "Gain 2 compasses as a free action.",
			card0135Name: "Fishing Rod",
			card0135Text: "Buy an item with a discount of 3 coins, including the top card of the item deck.",
			card0133Name: "Bear Trap",
			card0133Text: "Exile this card to overcome a guardian on a site not occupied by another player for free.",
			card0128Name: "Tent",
			card0128Text: "Activate a site you occupy. Pay 2 compasses first if it is a level II site.",
			card0124Name: "Hot Air Balloon",
			card0124Text: "Exile this card to deploy an archaeologist with a discount of 1 airplane; if discovering, also discount 3 compasses.",
			card0138Name: "Parrot",
			card0138Text: "Discard a card to gain 1 jewel.",
			card0134Name: "Machete",
			card0134Text: "Exile a card from your hand or play area and gain 2 compasses.",
			card0131Name: "Aeroplane",
			card0131Text: "Deploy an archaeologist with a discount of 1 airplane; if discovering, also discount 2 compasses.",
			cardfundcarName: "Funding",
			cardfundcarText: "Gain 1 coin as a free action.",
			cardfundboatName: "Funding",
			cardfundboatText: "Gain 1 coin as a free action.",
			cardexplorecarName: "Exploration",
			cardexplorecarText: "Gain 1 compass as a free action.",
			cardexploreboatName: "Exploration",
			cardexploreboatText: "Gain 1 compass as a free action.",
			cardfearName: "Fear",
			cardfearText: "Cannot be played for an effect.",
			cardfeartileName: "Fear tile",
			cardfeartileText: "Cannot be played for an effect.",
			guardian1301: "Scorpion",
			guardian1302: "Owl",
			guardian1303: "Bird",
			guardian1304: "Red Snake",
			guardian1305: "Ant",
			guardian1306: "Lizard",
			guardian1307: "Spider",
			guardian1308: "Beetle",
			guardian1309: "Dragon",
			guardian1310: "Frog",
			guardian1400: "Rhino",
			guardian1401: "Boar",
			guardian1402: "Flying Dragon",
			guardian1403: "Manticore",
			guardian1404: "Green Snake",
			assistant601: "Epigrapher",
			assistant602: "Geologist",
			assistant603: "Jeweler",
			assistant604: "Dog trainer",
			assistant605: "Porter",
			assistant606: "Pilot",
			assistant607: "Guide",
			assistant608: "Captain",
			assistant609: "Trader",
			assistant610: "Resource specialist",
			assistant611: "Prospector",
			assistant600: "Miner",
			resourcec: "Coin",
			resources: "Compass",
			resourcet: "Tablet",
			resourcea: "Arrowhead",
			resourcej: "Jewel",
			remainingTravel: "Travel left this turn",
			resourceboot: "Boot",
			resourcecar: "Car",
			resourceboat: "Boat",
			resourceplane: "Airplane",
			rules: "Goal:\nLead an expedition over five rounds and score the most points. The base game includes the Bird Temple, Snake Temple and solo rival.\nSetup:\nEach player has two archaeologists and a deck of two Funding, two Exploration and two Fear cards. Each player draws five cards. Starting supplies follow turn order:\n· The first seat receives 2 coins.\n· The second seat receives 1 coin and 1 compass.\n· The third seat receives 2 coins and 1 compass.\n· The fourth seat receives 1 coin and 2 compasses.\nIn solo play, use the second seat’s supplies; the rival always starts.\nTurns:\nTake one main action: deploy an archaeologist, discover a site, overcome a guardian, buy a card, play a card for its effect, research, or pass for the round. Free effects may be used before, during and after your main action. End your turn when finished. After passing, you take no more turns that round.\nTravel and discovery:\nPay travel icons using cards from your hand. Cars and boats replace boots; airplanes replace any icon. Cars and boats cannot replace each other. You may pay 2 coins for an airplane. Unspent icons from the same card last only for this turn. Deploy to a vacant space and activate its site. Discovering a level I or II site also costs 3 or 6 compasses. Gain its idols, resolve the face-up idol benefit, activate the site and add a guardian. You may choose the order of the site and idol benefits.\nGuardians and idols:\nPay the printed cost to overcome a guardian at a site with your archaeologist. Each is worth 5 VP and has a boon usable once per game. At round end, each archaeologist returning from a site with a guardian gains a Fear card. Each idol is worth 3 VP. As a free action, place a supply idol in your leftmost empty slot and choose one effect:\n· Pay 1 coin to gain 1 jewel.\n· Gain 1 arrowhead.\n· Gain 2 tablets.\n· Draw 1 card.\n· Upgrade a resource.\n\nEmpty slots are worth 1, 2, 3 and 4 VP.\nCards and assistants:\nThe six-card market contains as many artifacts as the round number. Buy items with coins and put them on the bottom of your deck. Buy artifacts with compasses, put them in your play area and immediately use their effects. Playing an artifact from your hand later costs 1 tablet. Refill the market at turn end. Fear cannot be played for an effect and costs 1 VP; when the Fear supply is empty, gain a fear tile worth −2 VP. Exile from your hand or play area. Costs to the left of an arrow must be paid to gain its benefit. Upgrade a tablet to an arrowhead, or an arrowhead to a jewel. Recruited assistants are ready and exhaust after use. They refresh at round end and on promotion. The Trader uses a main action; other assistants are free actions.\nResearch:\nPay a connected path’s cost to move your magnifying glass or notebook up one row. Resolve that token’s row benefit and any remaining first-arrival bonus. Your notebook cannot pass your magnifying glass or enter the Lost Temple. Arrival at the temple scores 23, 21, 20 or 19 VP in order, and lets you privately choose one hidden bonus. Later research can buy temple tiles. On the Snake Temple bridge, remove an idol from your supply. When rescuing, privately inspect the stack and choose an exhausted assistant.\nRound end:\nAfter everyone passes, return archaeologists and gain Fear, then choose whether to keep or discard remaining hand cards. Shuffle your play area onto the bottom of your existing deck, refresh assistants, exile the cards beside the moon staff and draw back to five for the next round. Never shuffle during a round. After round V, only return archaeologists and gain Fear before scoring.\nScoring:\nAdd research, temple tiles, idols, empty idol slots, guardians and card VP; subtract Fear. Ties favor earlier temple arrival; if no one arrived, compare research scores. Remaining ties are shared.\nSolo rival:\nDifficulty 0–5 randomly selects that many red action tiles; use green for the others. The rival resolves ten tiles each round, alternating with you. It never gains or spends resources or takes Fear. It blocks sites, discovers, researches, overcomes and buys, using the stack’s decision arrow for left/right choices. Green discovery, research and guardian actions do nothing in round V. Duplicate and face-down rival idols score 2 VP each."
		}
	}
};
//#endregion
export { mt as default };
