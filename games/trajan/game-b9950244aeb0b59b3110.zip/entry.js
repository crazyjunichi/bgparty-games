import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s, useFxAnchorsMaybe as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { Texture as d } from "@bgparty/sdk/texture";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as m } from "@bgparty/sdk/ui/player-strip";
import { useI18nSettings as h, useT as g } from "@bgparty/sdk/i18n";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { Floater as b, FlySprite as ee } from "@bgparty/sdk/fx/primitives";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
//#region src/games/trajan/data.ts
var S = [
	"port",
	"forum",
	"military",
	"senate",
	"trajan",
	"construction"
], C = [
	"W",
	"Y",
	"G",
	"P",
	"O",
	"B"
], te = [
	"#f4efda",
	"#e9c448",
	"#a9c671",
	"#d791b4",
	"#da8b3f",
	"#72b1c7"
], ne = [
	"bread",
	"flame",
	"helmet"
], re = [
	"port",
	"forum",
	"senate",
	"military",
	"trajan"
], w = [
	"I",
	"II",
	"III",
	"IV",
	"V",
	"VI"
], T = [
	0,
	0,
	10,
	14,
	18
], E = {
	sow: 240,
	tile: 700,
	score: 650,
	round: 650
}, D = [
	[
		"PP",
		"GP",
		"WP",
		"YP",
		"PW",
		"OP",
		"WW",
		"GW",
		"BP"
	],
	[
		"PW",
		"GP",
		"YG",
		"YY",
		"WB",
		"BB",
		"OO",
		"BO",
		"OY"
	],
	[
		"WW",
		"WG",
		"PP",
		"GG",
		"YG",
		"OG",
		"BO",
		"GG",
		"PG"
	],
	[
		"PP",
		"YW",
		"YY",
		"GG",
		"WW",
		"BB",
		"OW",
		"OO",
		"BW"
	],
	[
		"OY",
		"GO",
		"WO",
		"OO",
		"BG",
		"PO",
		"YO",
		"BY",
		"YY"
	],
	[
		"WY",
		"WB",
		"OB",
		"GB",
		"PY",
		"YB",
		"GY",
		"BB",
		"PB"
	]
].flatMap((e, t) => e.map((e, n) => ({
	id: t * 9 + n,
	group: t,
	colors: [...e].map((e) => C.indexOf(e)),
	vp: [
		4,
		3,
		1,
		9,
		[
			2,
			5,
			5,
			2,
			5,
			5,
			5,
			2,
			2
		][n],
		[
			2,
			5,
			2,
			5,
			5,
			5,
			2,
			5,
			5
		][n]
	][t],
	amount: t === 4 ? [
		2,
		1,
		1,
		2,
		1,
		1,
		1,
		2,
		2
	][n] : t === 5 ? [
		2,
		1,
		2,
		1,
		1,
		1,
		2,
		1,
		1
	][n] : 0,
	demand: t === 2 ? [
		1,
		1,
		0,
		2,
		2,
		0,
		1,
		0,
		2
	][n] : -1
}))), O = [
	...[
		3,
		5,
		4,
		2
	].flatMap((e) => Array.from({ length: 3 }, () => ({
		kind: "votes",
		value: e
	}))),
	...Array.from({ length: 3 }, () => ({
		kind: "demandWild",
		value: 0
	})),
	...Array.from({ length: 3 }, () => ({
		kind: "goodsWild",
		value: 0
	})),
	...Array.from({ length: 2 }, () => ({
		kind: "buildingWild",
		value: 0
	})),
	...Array.from({ length: 2 }, () => ({
		kind: "extraWild",
		value: 0
	})),
	...S.map((e, t) => ({
		kind: "extra",
		value: t
	})),
	...ne.flatMap((e, t) => Array.from({ length: 14 }, () => ({
		kind: "demand",
		value: t
	}))),
	...S.flatMap((e, t) => Array.from({ length: 2 }, () => ({
		kind: "extra",
		value: t
	})))
].map((e, t) => ({
	...e,
	id: t
})), k = {
	0: [0, 1],
	1: [2, 3],
	3: [4, 5],
	6: [6, 7],
	9: [8, 9],
	11: [10, 11]
}, A = {
	2: 2,
	7: 0,
	10: 1
}, j = [
	{
		name: "Britannia",
		vp: 10,
		x: 23,
		y: 10,
		adjacent: [
			1,
			3,
			4
		]
	},
	{
		name: "Germania Inferior",
		vp: 10,
		x: 62,
		y: 17,
		adjacent: [
			0,
			2,
			3
		]
	},
	{
		name: "Germania Superior",
		vp: 6,
		x: 81,
		y: 35,
		adjacent: [
			1,
			3,
			8,
			9
		]
	},
	{
		name: "Belgica",
		vp: 6,
		x: 48,
		y: 34,
		adjacent: [
			0,
			1,
			2,
			4,
			7,
			8
		]
	},
	{
		name: "Lugdunensis",
		vp: 6,
		x: 26,
		y: 38,
		adjacent: [
			0,
			3,
			5,
			6,
			7
		]
	},
	{
		name: "Aquitania",
		vp: 10,
		x: 11,
		y: 59,
		adjacent: [4, 6]
	},
	{
		name: "Narbonensis",
		vp: 6,
		x: 27,
		y: 80,
		adjacent: [
			4,
			5,
			7
		]
	},
	{
		name: "Alpes",
		vp: 3,
		x: 49,
		y: 65,
		adjacent: [
			3,
			4,
			6,
			8,
			10
		]
	},
	{
		name: "Raetia",
		vp: 3,
		x: 69,
		y: 54,
		adjacent: [
			2,
			3,
			7,
			9,
			10
		]
	},
	{
		name: "Noricum",
		vp: 5,
		x: 87,
		y: 64,
		adjacent: [
			2,
			8,
			10
		]
	},
	{
		name: "Italia",
		vp: 0,
		x: 66,
		y: 86,
		adjacent: [
			7,
			8,
			9
		]
	}
], M = [
	[[
		2,
		6,
		12,
		20
	], [
		0,
		1,
		7,
		15
	]],
	[[
		5,
		10,
		15
	], [
		1,
		6,
		11
	]],
	[[
		2,
		4,
		6,
		8
	], [
		0,
		1,
		3,
		5
	]]
], ie = {
	id: "trajan",
	tier: "alpha",
	nameKey: "games.trajan.name",
	descKey: "games.trajan.desc",
	rulesKey: "games.trajan.rules",
	icon: "🏛️",
	iconImg: "games/trajan.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#98502d",
	mechanics: [
		"action-programming",
		"set-collection",
		"worker-placement"
	],
	interactionTags: [],
	releasedAt: "2026-10-31T13:43:12+08:00",
	rulesUrl: { en: "https://www.ultraboardgames.com/trajan/game-rules.php" },
	search: {
		py: "tu la zhen",
		init: "tlz"
	},
	hotseat: "cover"
};
//#endregion
//#region src/games/trajan/motion.ts
function N(e, t, n, r) {
	let i = e.players[e.active], a = t.players[e.active], o = i.rid, s = r.filter((e) => e.kind === "score"), c = (e, t = o) => `${e}:${t}`, l = (e, t, n, r, i = n, a = r, c = o, l = !1, u = {}) => {
		s.push({
			kind: "piece",
			rid: c,
			data: {
				piece: e,
				id: l ? -1 : t,
				from: n,
				to: r,
				fromArea: i,
				toArea: a,
				...u
			},
			...l ? {
				for: [c],
				secret: { id: t }
			} : {}
		});
	}, u = (e) => c("inventory") + `:${e}`, d = (e, t, n) => l("forum", e, t, u(e), n, c("inventory-area")), f = (e, t = "goods-deck", n = !1) => a.hand.slice(e).forEach((r, i) => l("goods", r, t, c("hand") + `:${e + i}`, t, c("hand-area"), o, !n));
	if (n.type === "initialCard") f(i.hand.length, n.pile ? `discard:${n.pile - 1}` : "goods-deck", n.pile > 0), n.pile && e.discards[n.pile - 1].length === 1 && t.discards[n.pile - 1].length && l("goods", t.discards[n.pile - 1][0], "goods-deck", `discard:${n.pile - 1}`);
	else if (n.type === "initialTile") l("trajan", a.tiles[n.slot], `stack:${n.group}`, c("tile") + `:${n.slot}`);
	else if (n.type === "takeBowl") i.bowls[n.bowl].forEach((e) => l("marker", e, c("bowl") + `:${n.bowl}`, c("held-color") + `:${e}`, c("bowl") + `:${n.bowl}`, c("held")));
	else if (n.type === "sow") l("marker", n.color, c("held-color") + `:${n.color}`, c("bowl-marker") + `:${e.nextBowl}:${i.bowls[e.nextBowl].length}`, c("held"), c("bowl") + `:${e.nextBowl}`);
	else if (n.type === "reward") {
		if (D[e.reward].group === 0) l("double", n.value, c("completed"), c("double") + `:${n.value}`, c("completed"), c("bowl") + `:${n.value}`);
		else for (let t = 0; t < n.value; t++) l("person", t, c("supply"), c(D[e.reward].group === 4 ? "workers" : "soldiers"));
	} else if (n.type === "discard") l("goods", n.card, c("hand-area"), `discard:${n.pile}`);
	else if (n.type === "extra" && n.tile >= 0) l("forum", n.tile, u(n.tile), c("bowl") + `:${e.action}`, c("inventory-area"));
	else if (n.type === "pay") n.tiles.forEach((e) => l("forum", e, u(e), "demands-area", c("inventory-area")));
	else if (n.type === "bonus") for (let [n, r] of t.players.entries()) for (let t of r.bonus.slice(e.players[n].bonus.length)) l("bonus", t.id, `bonus:${t.id}`, `owned-bonus:${r.rid}:${t.id}`, `bonus-place:${e.bonuses.indexOf(t.id)}`, `bonuses:${r.rid}`, r.rid, !1, { yellow: t.yellow });
	else if (n.type === "act") {
		let t = n.target ?? -1;
		if (n.mode === "draw") f(i.hand.length);
		else if (n.mode === "take") f(i.hand.length, `discard:${t}`, !0);
		else if (n.mode === "display" || n.mode === "ship") {
			let e = n.cards ?? [];
			e.forEach((e, r) => l("goods", e, c("hand-area"), c("display") + `:${i.display.length + r}`, c("hand-area"), c("display-area"), o, !1, n.mode === "ship" ? { via: `ship:${t}` } : {})), n.mode === "display" ? f(i.hand.length - e.length) : i.inventory.filter((e) => O[e].kind === "goodsWild").slice(0, n.wild?.length ?? 0).forEach((e) => l("forum", e, u(e), `ship:${t}`, c("inventory-area")));
		} else n.mode === "forum" ? d(t, `forum-slot:${e.forum.indexOf(t)}`, "forum-area") : n.mode === "recruit" ? l("person", 0, c("supply"), c(e.action === 2 ? "soldiers" : "workers")) : n.mode === "move" ? (l("leader", 0, `province:${i.leader}`, c("leader"), `province:${i.leader}`, `province:${a.leader}`), e.provinces[t] >= 0 && d(e.provinces[t], `province:${t}`, "map-area")) : n.mode === "deploy" ? l("person", 0, c("soldiers"), c("legion") + `:${a.leader}`, c("soldiers"), `province:${a.leader}`) : n.mode === "senate" ? l("disc", 0, `senate:${i.senate}`, c("senate-disc"), `senate:${i.senate}`, `senate:${a.senate}`) : n.mode === "trajan" ? l("trajan", a.tiles[i.arch], `stack:${t}`, c("tile") + `:${i.arch}`) : n.mode === "build" && (l("person", 0, c("workers"), c("worker") + `:${t}`, c("workers"), `build:${t}`), e.construction[t] >= 0 && l("building", e.construction[t], `build:${t}`, c("building") + `:${e.construction[t]}`, `build:${t}`, c("buildings")));
	} else if (n.type === "tick") {
		if (e.phase === "checkTile" && i.tiles[e.targetBowl] >= 0 && a.tiles[e.targetBowl] < 0) {
			let t = i.tiles[e.targetBowl], n = D[t];
			l("trajan", t, c("tile") + `:${e.targetBowl}`, n.group === 2 ? c("permanent") + `:${a.permanent.length - 1}` : c("completed")), f(i.hand.length);
		}
		if (t.demands.length > e.demands.length && l("demand", t.demands.at(-1), "demand-deck", `demand:${t.demands.length - 1}`), e.phase === "reset") {
			for (let [n, r] of t.players.entries()) l("disc", 0, `senate:${e.players[n].senate}`, `senate-disc:${r.rid}`, `senate:${e.players[n].senate}`, "senate:0", r.rid), e.players[n].inventory.filter((e) => O[e].kind === "votes").forEach((e) => l("forum", e, `inventory:${r.rid}:${e}`, "forum-supply", `inventory-area:${r.rid}`, "forum-supply", r.rid));
			t.forum.forEach((t, n) => {
				e.forum.includes(t) || l("forum", t, "forum-supply", `forum-slot:${n}`);
			}), t.provinces.forEach((t, n) => {
				t >= 0 && t !== e.provinces[n] && l("forum", t, "forum-supply", `province:${n}`);
			}), t.bonuses.forEach((e) => l("bonus", e, "bonus-supply", `bonus:${e}`, "bonus-supply", "bonus-pool", o, !1, { yellow: !0 }));
		}
	}
	if (i.arch !== a.arch && l("arch", 0, i.arch < 0 ? c("arch-centre") : c("tile") + `:${i.arch}`, c("arch"), c("mat"), a.arch < 0 ? c("arch-centre") : c("tile") + `:${a.arch}`), !s.some((e) => e.kind === "score")) for (let [n, r] of t.players.entries()) r.vp !== e.players[n].vp && s.push({
		kind: "score",
		rid: r.rid,
		data: { vp: r.vp - e.players[n].vp }
	});
	return s.map((e, t) => ({
		...e,
		...t > 0 ? { with: !0 } : {}
	}));
}
//#endregion
//#region src/games/trajan/schema.ts
var P = t.int().nonnegative(), F = t.int().min(0).max(5), I = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("arrange"),
		colors: t.array(F).length(12)
	}),
	t.object({
		type: t.literal("initialCard"),
		pile: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("initialTile"),
		group: F,
		slot: F
	}),
	t.object({
		type: t.literal("takeBowl"),
		bowl: F
	}),
	t.object({
		type: t.literal("sow"),
		color: F
	}),
	t.object({
		type: t.literal("reward"),
		value: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("act"),
		mode: t.enum([
			"skip",
			"draw",
			"take",
			"display",
			"ship",
			"forum",
			"recruit",
			"move",
			"deploy",
			"senate",
			"trajan",
			"build"
		]),
		target: P.optional(),
		cards: t.array(t.int().min(0).max(11)).max(6).optional(),
		wild: t.array(t.int().min(0).max(11)).max(3).optional()
	}),
	t.object({
		type: t.literal("discard"),
		card: P,
		pile: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("extra"),
		tile: t.int().min(-1)
	}),
	t.object({
		type: t.literal("pay"),
		tiles: t.array(P).max(3)
	}),
	t.object({
		type: t.literal("bonus"),
		tile: t.int().min(0).max(11)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), L = t.object({
	rid: t.string(),
	vp: t.int(),
	bowls: t.array(t.array(F)).length(6),
	tiles: t.array(t.int().min(-1).max(53)).length(6),
	arch: t.int().min(-1).max(5),
	inventory: t.array(P),
	permanent: t.array(t.int().min(0).max(2)),
	doubled: t.array(F),
	bonus: t.array(t.object({
		id: P,
		yellow: t.boolean()
	})),
	supply: P,
	workers: P,
	soldiers: P,
	leader: t.int().min(0).max(10),
	built: t.array(P),
	legions: t.array(P),
	buildings: t.array(P),
	display: t.array(t.int().min(0).max(11)),
	handCount: P,
	senate: P,
	order: P,
	final: t.array(t.int())
}), ae = t.object({
	players: t.array(L),
	phase: t.enum([
		"arrange",
		"initialCards",
		"initialTiles",
		"choose",
		"sow",
		"checkTile",
		"reward",
		"action",
		"discard",
		"extra",
		"round",
		"demand",
		"bonus",
		"reset",
		"final",
		"done"
	]),
	active: t.string(),
	quarter: t.int(),
	round: t.int(),
	time: P,
	track: P,
	demands: t.array(t.int().min(0).max(2)),
	forum: t.array(P),
	provinces: t.array(t.int().min(-1)),
	construction: t.array(t.int().min(-1)),
	stacks: t.array(t.object({
		top: t.int().min(-1).max(53),
		count: P
	})),
	goodsLeft: P,
	discards: t.array(t.object({
		top: t.int().min(-1).max(11),
		count: P
	})),
	bonuses: t.array(P),
	ships: t.array(t.boolean()),
	held: t.array(F),
	nextBowl: F,
	action: t.int().min(-1).max(5),
	reward: t.int().min(-1).max(53),
	log: t.array(t.object({
		rid: t.string(),
		event: t.string(),
		value: t.int(),
		target: t.int()
	}))
}), oe = t.object({
	hand: t.array(t.int().min(0).max(11)),
	legal: t.array(I)
}), se = () => Array.from({ length: 6 }, () => []);
function R(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ce(e) {
	return e.goods.length || (e.goods = R(e, e.discards.flatMap((e) => e.splice(0, Math.max(0, e.length - 1))))), e.goods.pop();
}
function le(e, t, n) {
	for (let r = 0; r < n; r++) {
		let n = ce(e);
		n !== void 0 && t.hand.push(n);
	}
}
function ue(e) {
	for (let t of e.discards) if (!t.length) {
		let n = ce(e);
		n !== void 0 && t.push(n);
	}
}
function de(e) {
	e.forum = e.forumBag.splice(-3 * e.players.length), e.forum.push(...e.extraBag.splice(-3));
	for (let t = 0; t < 10; t++) e.provinces[t] === -1 && !e.players.some((e) => e.leader === t || e.legions.includes(t)) && (e.provinces[t] = e.forumBag.pop() ?? -1);
	e.bonuses = e.bonusBag.splice(-2), e.ships = [
		!0,
		!0,
		!0
	];
}
function z(e, t, n = 0, r = -1, i = e.active) {
	e.log.push({
		rid: e.players[i].rid,
		event: t,
		value: n,
		target: r
	});
}
function fe(e, t, n) {
	let r = {
		players: t.map((e, t) => ({
			rid: e,
			vp: 0,
			bowls: se(),
			tiles: [
				,
				,
				,
				,
				,
				,
			].fill(-1),
			arch: 0,
			inventory: [],
			permanent: [],
			doubled: [],
			bonus: [],
			supply: 13,
			workers: 1,
			soldiers: 1,
			leader: 10,
			built: [],
			legions: [],
			buildings: [],
			hand: [],
			display: [],
			senate: 0,
			order: t,
			final: []
		})),
		phase: "arrange",
		active: 0,
		quarter: 1,
		round: 1,
		time: 0,
		seed: n,
		cursor: 0,
		forumBag: [],
		extraBag: [],
		bonusBag: [],
		demandBag: [],
		goods: [],
		discards: [[], []],
		stacks: [],
		forum: [],
		provinces: Array(10).fill(-1),
		construction: [],
		bonuses: [],
		ships: [
			!0,
			!0,
			!0
		],
		demands: [],
		held: [],
		nextBowl: 0,
		targetBowl: 0,
		action: -1,
		reward: -1,
		tasks: [],
		extraUsed: !1,
		crossings: 0,
		setupCount: 0,
		setupGroups: [],
		senateOrder: [],
		payIndex: 0,
		endTurnSeat: 0,
		finalIndex: 0,
		log: [],
		beat: E.round
	};
	r.forumBag = R(r, Array.from({ length: 70 }, (e, t) => t)), r.extraBag = R(r, Array.from({ length: 12 }, (e, t) => 70 + t)), r.bonusBag = R(r, Array.from({ length: 12 }, (e, t) => t)), r.demandBag = R(r, Array.from({ length: 15 }, (e, t) => t % 3)).slice(0, 12), r.goods = R(r, Array.from({ length: 60 }, (e, t) => t % 12)), r.stacks = Array.from({ length: 6 }, (e, t) => R(r, D.filter((e) => e.group === t).map((e) => e.id))), r.construction = R(r, Array.from({ length: 20 }, (e, t) => t));
	for (let e of r.players) e.bonus.push({
		id: r.bonusBag.pop(),
		yellow: !0
	});
	return de(r), ue(r), {
		state: r,
		fx: []
	};
}
function pe(e, t) {
	let n = [...e];
	for (let e of t) {
		let t = n.indexOf(e);
		if (t < 0) return !1;
		n.splice(t, 1);
	}
	return !0;
}
function me(e, t) {
	return e.workers > 0 && !e.built.includes(t) && (e.built.length === 0 || e.built.some((e) => Math.abs(e - t) === 5 || Math.floor(e / 5) === Math.floor(t / 5) && Math.abs(e - t) === 1));
}
function he(e, t) {
	return e.inventory.filter((e) => O[e].kind === "extraWild" || O[e].kind === "extra" && O[e].value === t);
}
function B(e) {
	for (e.reward = -1; e.tasks.length;) {
		let t = e.tasks.shift();
		if (e.action = t.action, !t.offer) {
			e.phase = "action";
			return;
		}
		if (!e.extraUsed && he(e.players[e.active], t.action).length) {
			e.phase = "extra";
			return;
		}
	}
	e.action = -1, e.crossings > 0 ? (e.phase = "round", e.beat = E.round) : (e.active = (e.active + 1) % e.players.length, e.phase = "choose");
}
function ge(e, t, n = -1) {
	t && e.tasks.unshift({
		action: e.action,
		offer: !0
	}), n >= 0 && e.tasks.unshift({
		action: n,
		offer: !1
	}), B(e);
}
function V(e) {
	e.tasks = [{
		action: e.targetBowl,
		offer: !1
	}], B(e);
}
function _e(e, t) {
	if (!pe(e.hand, t)) return !1;
	for (let n of t) e.hand.splice(e.hand.indexOf(n), 1);
	return !0;
}
function H(e, t, n) {
	let r = Array.from({ length: 12 }, (e, n) => t.filter((e) => e === n).length).filter(Boolean);
	return e === 0 && r.length === 1 && t.length <= 4 ? M[0][+!n][t.length - 1] : e === 1 && r.length >= 1 && r.length <= 3 && r.every((e) => e === 2) ? M[1][+!n][r.length - 1] : e === 2 && t.length >= 1 && t.length <= 4 && r.every((e) => e === 1) ? M[2][+!n][t.length - 1] : null;
}
function ve(e, t, n) {
	let r = [];
	function i(a, o) {
		if (o.length >= t && r.push(o), o.length !== n) for (let t = a; t < e.length; t++) i(t + 1, [...o, e[t]]);
	}
	return i(0, []), r;
}
function ye(e, t) {
	let n = [...t];
	for (let t of e.permanent) {
		let e = n.indexOf(t);
		e >= 0 && n.splice(e, 1);
	}
	return n;
}
function be(e, t) {
	let n = ye(e, t), r = e.inventory.filter((e) => O[e].kind === "demandWild" || O[e].kind === "demand" && n.includes(O[e].value)), i = [], a = {};
	for (let e of r) {
		let t = O[e], n = `${t.kind}:${t.value}`;
		(a[n] ?? 0) < 3 && (i.push(e), a[n] = (a[n] ?? 0) + 1);
	}
	let o = 0, s = [[]];
	for (let e of ve(i, 1, n.length)) {
		let t = [...n], r = !0, i = [...e].sort((e, t) => Number(O[e].kind === "demandWild") - Number(O[t].kind === "demandWild"));
		for (let e of i) {
			let n = O[e], i = n.kind === "demandWild" ? t.length ? 0 : -1 : t.indexOf(n.value);
			if (i < 0) {
				r = !1;
				break;
			}
			t.splice(i, 1);
		}
		r && e.length >= o && (e.length > o && (s = []), o = e.length, s.push(e));
	}
	let c = /* @__PURE__ */ new Set();
	return s.filter((e) => {
		let t = e.map((e) => `${O[e].kind}:${O[e].value}`).sort().join(",");
		return !c.has(t) && (c.add(t), !0);
	});
}
function xe(e, t, n) {
	if (new Set(n).size !== n.length || n.some((t) => !e.inventory.includes(t))) return !1;
	let r = be(e, t), i = (e) => e.map((e) => `${O[e].kind}:${O[e].value}`).sort().join(",");
	return r.some((e) => i(e) === i(n));
}
function Se(e) {
	let t = e.hand.length + e.workers + e.soldiers + e.tiles.filter((e) => e >= 0).length, n = Array.from({ length: 5 }, (t, n) => e.buildings.filter((e) => Math.floor(e / 4) === n).length), r = e.inventory.filter((e) => O[e].kind === "buildingWild").length, i = 0;
	function a(e, t) {
		let n = t.reduce((e, t) => e + (t >= 4 ? 20 : t === 3 ? 10 : 0), 0);
		if (i = Math.max(i, n), e) {
			for (let n = 0; n < 5; n++) if (t[n] < 4) {
				let r = [...t];
				r[n]++, a(e - 1, r);
			}
		}
	}
	a(r, n);
	let o = Array(12).fill(0), s = 0;
	for (let t of e.bonus) if (k[t.id]) for (let e of k[t.id]) o[e] += t.yellow ? 3 : 2;
	else A[t.id] === void 0 ? t.id === 4 ? s += e.bonus.filter((e) => e.yellow).length * (t.yellow ? 3 : 2) : t.id === 5 ? s += e.legions.length * (t.yellow ? 2 : 1) : t.id === 8 && (s += Math.ceil(e.built.length * (t.yellow ? 1 : .5))) : e.inventory.some((e) => O[e].kind === "demand" && O[e].value === A[t.id]) && (s += t.yellow ? 9 : 6);
	return s += e.display.reduce((e, t) => e + o[t], 0), s += e.inventory.filter((e) => O[e].kind === "goodsWild").length * Math.max(...o), [
		e.vp,
		t,
		i,
		s
	];
}
function Ce(e, t) {
	let n = [];
	(e.goods.length || e.discards.some((e) => e.length > 1)) && n.push({
		type: "act",
		mode: "draw"
	}), e.discards.forEach((e, t) => {
		e.length && n.push({
			type: "act",
			mode: "take",
			target: t
		});
	});
	let r = [...new Set(t.hand)].sort((e, t) => e - t);
	for (let e of r) {
		n.push({
			type: "act",
			mode: "display",
			cards: [e]
		});
		for (let i of r) i >= e && (e !== i || t.hand.filter((t) => t === e).length >= 2) && n.push({
			type: "act",
			mode: "display",
			cards: [e, i]
		});
	}
	let i = t.inventory.filter((e) => O[e].kind === "goodsWild").length;
	for (let e = 0; e < 3; e++) {
		let r = e === 0 ? Array.from({ length: 12 }, (e, t) => [t]) : ve(Array.from({ length: 12 }, (e, t) => t), 1, e === 1 ? 3 : 4);
		for (let a of r) for (let r = 1; r <= (e === 0 ? 4 : 1); r++) {
			let o = [], s = [];
			for (let n of a) {
				let i = e === 1 ? 2 : r, a = Math.min(i, t.hand.filter((e) => e === n).length);
				o.push(...Array(a).fill(n)), s.push(...Array(i - a).fill(n));
			}
			s.length <= i && n.push({
				type: "act",
				mode: "ship",
				target: e,
				cards: o,
				wild: s
			});
		}
	}
	return n;
}
function we(e, t) {
	let n = e.players[e.active];
	if (n.rid !== t) return [];
	if (e.phase === "arrange") return [{
		type: "arrange",
		colors: Array.from({ length: 12 }, (e, t) => t % 6)
	}];
	if (e.phase === "initialCards") return [
		0,
		1,
		2
	].filter((t) => t === 0 ? e.goods.length > 0 : e.discards[t - 1].length > 0).map((e) => ({
		type: "initialCard",
		pile: e
	}));
	if (e.phase === "initialTiles") return e.stacks.flatMap((t, r) => t.length && !e.setupGroups.includes(r) ? [
		1,
		3,
		5
	].filter((e) => n.tiles[e] < 0).map((e) => ({
		type: "initialTile",
		group: r,
		slot: e
	})) : []);
	if (e.phase === "choose") return n.bowls.flatMap((e, t) => e.length ? [{
		type: "takeBowl",
		bowl: t
	}] : []);
	if (e.phase === "sow") return [...new Set(e.held)].map((e) => ({
		type: "sow",
		color: e
	}));
	if (e.phase === "reward") {
		let t = D[e.reward];
		return t.group === 0 ? S.flatMap((e, t) => n.doubled.includes(t) ? [] : [{
			type: "reward",
			value: t
		}]) : Array.from({ length: Math.min(t.amount, n.supply) + 1 }, (e, t) => ({
			type: "reward",
			value: t
		}));
	}
	if (e.phase === "discard") return [...new Set(n.hand)].flatMap((e) => [0, 1].map((t) => ({
		type: "discard",
		card: e,
		pile: t
	})));
	if (e.phase === "extra") return [-1, ...he(n, e.action)].map((e) => ({
		type: "extra",
		tile: e
	}));
	if (e.phase === "demand") return be(n, e.demands).map((e) => ({
		type: "pay",
		tiles: e
	}));
	if (e.phase === "bonus") return e.bonuses.map((e) => ({
		type: "bonus",
		tile: e
	}));
	if (e.phase !== "action") return [];
	let r = [{
		type: "act",
		mode: "skip"
	}];
	return e.action === 0 && r.push(...Ce(e, n)), e.action === 1 && r.push(...e.forum.map((e) => ({
		type: "act",
		mode: "forum",
		target: e
	}))), e.action === 2 && (n.supply && r.push({
		type: "act",
		mode: "recruit"
	}), r.push(...j[n.leader].adjacent.map((e) => ({
		type: "act",
		mode: "move",
		target: e
	}))), n.soldiers && n.leader < 10 && !n.legions.includes(n.leader) && r.push({
		type: "act",
		mode: "deploy"
	})), e.action === 3 && n.senate < 7 && r.push({
		type: "act",
		mode: "senate"
	}), e.action === 4 && n.arch >= 0 && r.push(...e.stacks.flatMap((e, t) => e.length ? [{
		type: "act",
		mode: "trajan",
		target: t
	}] : [])), e.action === 5 && (n.supply && r.push({
		type: "act",
		mode: "recruit"
	}), r.push(...e.construction.flatMap((e, t) => me(n, t) ? [{
		type: "act",
		mode: "build",
		target: t
	}] : []))), r;
}
function Te(e, t, n) {
	let r = I.safeParse(t);
	if (!r.success) return { code: "games.trajan.invalid" };
	let i = r.data;
	if (i.type !== "tick" && e.players[e.active].rid !== n.by) return { code: "games.trajan.notTurn" };
	let a = structuredClone(e), o = a.players[a.active], s = { code: "games.trajan.invalid" }, c = [], l = () => ({
		state: a,
		fx: N(e, a, i, c)
	});
	if (i.type === "tick") {
		if (a.phase === "checkTile") {
			let e = o.tiles[a.targetBowl];
			if (e < 0 || !pe(o.bowls[a.targetBowl], D[e].colors)) return V(a), l();
			let t = D[e];
			o.tiles[a.targetBowl] = -1, o.vp += t.vp, o.arch < 0 && (o.arch = a.targetBowl), z(a, "complete", t.vp, e), a.beat = E.tile, t.group === 2 ? (o.permanent.push(t.demand), V(a)) : t.group === 1 ? (le(a, o, 2), V(a)) : t.group === 0 && o.doubled.length < 6 || t.group >= 4 ? (a.reward = e, a.phase = "reward") : V(a);
		} else if (a.phase === "round") {
			if (a.crossings--, z(a, "round", a.round, a.quarter), a.round < 4) {
				let e = a.demandBag.pop();
				e !== void 0 && a.demands.push(e), a.round++, B(a);
			} else a.endTurnSeat = a.active, a.active = 0, a.payIndex = 0, a.phase = "demand";
		} else if (a.phase === "reset") a.senateOrder.forEach((e, t) => {
			let n = a.players[e];
			n.senate = 0, n.order = a.players.length - t - 1, n.inventory = n.inventory.filter((e) => O[e].kind !== "votes");
		}), a.active = a.endTurnSeat, a.demands = [], a.round = 1, a.quarter === 4 ? (a.phase = "final", a.finalIndex = 0) : (a.quarter++, de(a), B(a));
		else if (a.phase === "final") {
			let e = a.finalIndex++, t = a.players[e];
			t.final = Se(t), t.vp = t.final.reduce((e, t) => e + t, 0), z(a, "final", t.vp, -1, e), c = [{
				kind: "score",
				rid: t.rid,
				data: { vp: t.final.slice(1).reduce((e, t) => e + t, 0) }
			}], a.finalIndex === a.players.length && (a.phase = "done");
		} else return {
			state: e,
			fx: []
		};
		return l();
	}
	if (i.type === "arrange" && a.phase === "arrange") {
		if (Array.from({ length: 6 }, (e, t) => i.colors.filter((e) => e === t).length).some((e) => e !== 2)) return s;
		o.bowls = Array.from({ length: 6 }, (e, t) => i.colors.slice(t * 2, t * 2 + 2)), a.active++, a.active === a.players.length && (a.active = 0, a.phase = "initialCards");
	} else if (i.type === "initialCard" && a.phase === "initialCards") {
		let e = i.pile === 0 ? ce(a) : a.discards[i.pile - 1].pop();
		if (e === void 0) return s;
		o.hand.push(e), ue(a), ++a.setupCount === 3 && (a.setupCount = 0, a.active++, a.active === a.players.length && (a.active = 0, a.phase = "initialTiles"));
	} else if (i.type === "initialTile" && a.phase === "initialTiles") {
		if (![
			1,
			3,
			5
		].includes(i.slot) || o.tiles[i.slot] >= 0 || a.setupGroups.includes(i.group) || !a.stacks[i.group].length) return s;
		o.tiles[i.slot] = a.stacks[i.group].pop(), a.setupGroups.push(i.group), a.setupGroups.length === 3 && (a.setupGroups = [], a.active++, a.active === a.players.length && (a.active = 0, a.phase = "choose"));
	} else if (i.type === "takeBowl" && a.phase === "choose") {
		if (!o.bowls[i.bowl].length) return s;
		a.held = o.bowls[i.bowl], o.bowls[i.bowl] = [], a.nextBowl = (i.bowl + 1) % 6, a.targetBowl = (i.bowl + a.held.length) % 6, a.extraUsed = !1;
		let e = a.time + a.held.length;
		a.crossings = Math.floor(e / T[a.players.length]), a.time = e % T[a.players.length], a.phase = "sow", z(a, "sow", a.held.length, i.bowl);
	} else if (i.type === "sow" && a.phase === "sow") {
		let e = a.held.indexOf(i.color);
		if (e < 0) return s;
		a.held.splice(e, 1), o.bowls[a.nextBowl].push(i.color), a.nextBowl = (a.nextBowl + 1) % 6, a.beat = E.sow, a.held.length || (a.phase = "checkTile");
	} else if (i.type === "reward" && a.phase === "reward") {
		let e = D[a.reward];
		if (e.group === 0) {
			if (o.doubled.includes(i.value)) return s;
			o.doubled.push(i.value);
		} else {
			if (i.value > Math.min(e.amount, o.supply)) return s;
			o.supply -= i.value, e.group === 4 ? o.workers += i.value : o.soldiers += i.value;
		}
		V(a);
	} else if (i.type === "discard" && a.phase === "discard") {
		if (!_e(o, [i.card])) return s;
		a.discards[i.pile].push(i.card), ge(a, !0);
	} else if (i.type === "extra" && a.phase === "extra") {
		if (i.tile >= 0) {
			if (a.extraUsed || !he(o, a.action).includes(i.tile)) return s;
			o.inventory.splice(o.inventory.indexOf(i.tile), 1), a.extraUsed = !0, a.tasks.unshift(...Array.from({ length: o.doubled.includes(a.action) ? 2 : 1 }, () => ({
				action: a.action,
				offer: !1
			}))), z(a, "extra", o.doubled.includes(a.action) ? 2 : 1, a.action);
		}
		B(a);
	} else if (i.type === "pay" && a.phase === "demand") {
		if (!xe(o, a.demands, i.tiles)) return s;
		let e = ye(o, a.demands).length - i.tiles.length, t = [
			0,
			4,
			9,
			15
		][e];
		if (o.vp -= t, o.inventory = o.inventory.filter((e) => !i.tiles.includes(e)), z(a, "demand", -t, e), c = [{
			kind: "score",
			rid: o.rid,
			data: { vp: -t }
		}], a.active = ++a.payIndex, a.payIndex === a.players.length) {
			let e = (e) => (e.senate ? e.senate + 1 : 0) + e.inventory.reduce((e, t) => e + (O[t].kind === "votes" ? O[t].value : 0), 0);
			a.senateOrder = a.players.map((e, t) => t).sort((t, n) => e(a.players[n]) - e(a.players[t]) || a.players[n].senate - a.players[t].senate || a.players[n].order - a.players[t].order), a.active = a.senateOrder[0], a.phase = "bonus";
		}
	} else if (i.type === "bonus" && a.phase === "bonus") {
		if (!a.bonuses.includes(i.tile)) return s;
		o.bonus.push({
			id: i.tile,
			yellow: !0
		}), a.players[a.senateOrder[1]].bonus.push({
			id: a.bonuses.find((e) => e !== i.tile),
			yellow: !1
		}), z(a, "bonus", i.tile), a.bonuses = [], a.phase = "reset", a.beat = E.score;
	} else if (i.type === "act" && a.phase === "action") {
		if (i.mode === "skip") return ge(a, !1), l();
		let e = i.target ?? -1, t = i.cards ?? [], n = i.wild ?? [], r = 0, c = -1;
		if (a.action === 0) {
			if (i.mode === "draw") {
				let e = o.hand.length;
				return le(a, o, 2), o.hand.length === e ? s : (a.phase = "discard", l());
			}
			if (i.mode === "take") {
				if (e > 1 || e < 0) return s;
				let t = a.discards[e].pop();
				if (t === void 0) return s;
				o.hand.push(t);
			} else if (i.mode === "display") {
				if (t.length < 1 || t.length > 2 || n.length || !_e(o, t)) return s;
				o.display.push(...t), le(a, o, t.length);
			} else if (i.mode === "ship") {
				let i = H(e, [...t, ...n], a.ships[e]);
				if (i == null || !_e(o, t)) return s;
				let c = o.inventory.filter((e) => O[e].kind === "goodsWild");
				if (n.length > c.length) return s;
				o.inventory = o.inventory.filter((e) => !c.slice(0, n.length).includes(e)), o.display.push(...t), r = i, a.ships[e] = !1;
			} else return s;
		} else if (a.action === 1 && i.mode === "forum") {
			let t = a.forum.indexOf(e);
			if (t < 0) return s;
			a.forum.splice(t, 1), o.inventory.push(e);
		} else if ((a.action === 2 || a.action === 5) && i.mode === "recruit") {
			if (!o.supply) return s;
			o.supply--, a.action === 2 ? o.soldiers++ : o.workers++;
		} else if (a.action === 2 && i.mode === "move") {
			if (!j[o.leader].adjacent.includes(e)) return s;
			o.leader = e, e < 10 && a.provinces[e] >= 0 && (o.inventory.push(a.provinces[e]), a.provinces[e] = -1);
		} else if (a.action === 2 && i.mode === "deploy") {
			if (!o.soldiers || o.leader === 10 || o.legions.includes(o.leader)) return s;
			o.soldiers--, o.legions.push(o.leader), r = Math.max(0, j[o.leader].vp - 3 * a.players.filter((e) => e.rid !== o.rid && e.legions.includes(o.leader)).length);
		} else if (a.action === 3 && i.mode === "senate") {
			if (o.senate === 7) return s;
			o.senate++, o.order = Math.max(...a.players.map((e) => e.order)) + 1, r = o.senate + 1;
		} else if (a.action === 4 && i.mode === "trajan") {
			if (o.arch < 0 || !a.stacks[e]?.length) return s;
			o.tiles[o.arch] = a.stacks[e].pop();
			let t = o.arch;
			o.arch = -1;
			for (let e = 1; e <= 6; e++) {
				let n = (t + e) % 6;
				if (o.tiles[n] < 0) {
					o.arch = n;
					break;
				}
			}
		} else if (a.action === 5 && i.mode === "build") {
			if (e < 0 || e >= 20 || !me(o, e)) return s;
			o.workers--, o.built.push(e);
			let t = a.construction[e];
			if (t >= 0) {
				let n = Math.floor(t / 4);
				o.buildings.some((e) => Math.floor(e / 4) === n) || (c = S.indexOf(re[n])), o.buildings.push(t), r = t % 4 + 2, a.construction[e] = -1;
			}
		} else return s;
		o.vp += r, z(a, i.mode, r, e), ge(a, !0, c);
	} else return s;
	return l();
}
function Ee(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return {
		public: {
			players: e.players.map(({ hand: e, ...t }) => ({
				...t,
				handCount: e.length
			})),
			phase: e.phase,
			active: e.players[e.active]?.rid ?? e.players[0].rid,
			quarter: e.quarter,
			round: e.round,
			time: e.time,
			track: T[e.players.length],
			demands: e.demands,
			forum: e.forum,
			provinces: e.provinces,
			construction: e.construction,
			stacks: e.stacks.map((e) => ({
				top: e.at(-1) ?? -1,
				count: e.length
			})),
			goodsLeft: e.goods.length,
			discards: e.discards.map((e) => ({
				top: e.at(-1) ?? -1,
				count: e.length
			})),
			bonuses: e.bonuses,
			ships: e.ships,
			held: e.held,
			nextBowl: e.nextBowl,
			action: e.action,
			reward: e.reward,
			log: e.log
		},
		private: {
			hand: n?.hand ?? [],
			legal: we(e, t)
		}
	};
}
function De(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((e, t) => t.vp - e.vp || t.order - e.order).map((e) => e.rid);
	return {
		phase: "done",
		winner: [t[0]],
		ranking: t,
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.vp]))
	};
}
var Oe = {
	meta: ie,
	saveCompatibility: { version: "1" },
	schemas: {
		action: I,
		publicView: ae,
		privateView: oe
	},
	setup: fe,
	reduce: Te,
	viewFor: Ee,
	status: De,
	nextTickIn: (e) => [
		"checkTile",
		"round",
		"reset",
		"final"
	].includes(e.phase) ? e.beat : null
};
//#endregion
//#region src/games/trajan/anchors.ts
function ke(e) {
	let t = e.getBoundingClientRect(), n = Math.max(0, t.left), r = Math.max(0, t.top), i = Math.min(innerWidth, t.right), a = Math.min(innerHeight, t.bottom);
	for (let t = e.parentElement; t; t = t.parentElement) {
		let e = getComputedStyle(t), o = t.getBoundingClientRect(), s = o.left + t.clientLeft, c = o.top + t.clientTop;
		e.overflowX !== "visible" && (n = Math.max(n, s), i = Math.min(i, s + t.clientWidth)), e.overflowY !== "visible" && (r = Math.max(r, c), a = Math.min(a, c + t.clientHeight));
	}
	return i > n && a > r ? {
		x: n,
		y: r,
		w: i - n,
		h: a - r
	} : null;
}
function U(e) {
	let { ref: t, hidden: r } = s(e), i = c();
	return {
		ref: n((n) => {
			t(n), n?.setAttribute("data-tr-anchor", e), i?.registerProbe(`visible:${e}`, n ? () => ke(n) : null), i?.registerProbe(`whole:${e}`, n ? () => {
				let e = ke(n), t = n.getBoundingClientRect();
				return e && e.w >= t.width - .5 && e.h >= t.height - .5 ? e : null;
			} : null);
		}, [
			t,
			i,
			e
		]),
		hidden: r
	};
}
//#endregion
//#region src/games/trajan/locales/zh.ts
var Ae = {
	name: "圖拉真",
	desc: "以六盘播撒调度罗马，在贸易、建设与政治之间争取荣誉。",
	rules: "目标：\n四个季度结束后，胜利分最高者获胜；平分时，最终元老院顺位较高者获胜。\n准备：\n· 每位玩家有 12 枚行动标记，六色各 2 枚。先自由分配到六个行动盘，每盘恰好 2 枚；领袖在意大利，军营和工营各有 1 人，个人储备还有 13 人。\n· 按玩家顺序各选 3 张商品，可以从暗牌堆或两个明牌堆中逐张选择。准备期间明牌堆空时补入一张暗牌。每人获得一块随机黄色奖励。\n· 按玩家顺序，各取三个不同类别的圖拉真堆顶，放在 II、IV、VI 槽，自由决定对应位置。拱门从 I 槽开始。\n流程：\n· 从非空盘拿起全部标记，顺时针逐盘各放一枚；可以自由决定颜色顺序。最后放入的盘决定本次行动。时间标记前进拿起的标记数，2／3／4 人的时间轨分别有 10／14／18 格。\n· 若落盘旁的圖拉真颜色需求已满足，必须完成它。盘内可以有多余标记，标记不消耗；同色需求需要两枚。获得片上分数及奖励，需求图案永久保留，其他片移出游戏。拱门原先在中央时移到刚空出的槽。\n· 然后可执行落盘行动，也可放弃。行动结束后，可弃一块对应的额外行动片再执行一次；若该行动已放置额外行动加倍标记，则再执行两次。额外行动百搭可代替对应片，每回合最多使用一块额外行动片。首次取得某类建筑所触发的行动也可以使用它。\n六种行动：\n· 港口：选择暗抽 2 张后将任意手牌 1 张弃到任一明牌堆；或取任一明牌堆顶；或展示 1–2 张手牌并暗补同数；或向船交付商品得分。交付和展示的实际商品都保留在个人展示区。\n· 同类船收 1／2／3／4 张同类商品，黄面获得 2／6／12／20 分，灰面获得 0／1／7／15 分。成对船收 1／2／3 对不同类别商品，黄面获得 5／10／15 分，灰面获得 1／6／11 分。不同类船收 1／2／3／4 张不同商品，黄面获得 2／4／6／8 分，灰面获得 0／1／3／5 分。黄船使用后翻灰，灰船仍可使用；每季度恢复黄面。商品百搭使用后消耗。\n· 广场：取任意一块广场片。需求片用于季度支付；投票片参与本季度选举；另有商品、需求、建筑和额外行动百搭。\n· 军事：从储备派 1 人到军营；或领袖移到相邻省并取得当地广场片；或从军营派 1 军团到领袖所在省。自己在该省不能已有军团，立即获得省分，每个其他玩家的军团使其减少 3 分，最低 0 分。军团留在该省。\n· 元老院：前进一格，依次获得 2、3、4、5、6、7、8 分，同格后来者叠在上面；到顶后本季度不能继续前进。\n· 圖拉真：取任一类别堆顶，放到拱门所在槽，拱门顺时针移到下一空槽。六槽全满时拱门置于中央，此时不能取片。\n· 建造：从储备派 1 人到工营；或从工营派 1 工人到建筑格。首次可选任意格，以后须与自己的工人正交相邻，不能重复进入自己的格。可进入别人的格，但没有建筑片就没有片分。取得片时获得其分数；首次获得该类额外执行：喷泉为港口、台阶为广场、门为元老院、柱为军事、屋顶为圖拉真，可继续连锁。\n季度结算：\n· 时间到达或越过起点后，当前玩家完成整回合再处理轮末，余数保留。前三轮各翻一块需求，第四轮进行季度结算。\n· 每人以永久圖拉真及相应广场片满足三个需求。每块永久片每季度只能使用一次；普通需求与需求百搭支付后消耗。未满足 1／2／3 个需求扣 4／9／15 分，分数可以为负。\n· 票数等于元老院位置票（起点 0，其他依次 2–8）加投票片。平票依次比较位置与同格叠放顺序。第一名任选一块公共奖励并保留黄面，第二名取得另一块灰面。依选举顺位重叠到起点，第一名在最上。\n· 清除全部投票片和广场剩余片，补充广场与额外行动片；只有没有片、领袖和军团的省才补片。船翻回黄面。建筑和圖拉真不补充。最后季度仍先完成需求与奖励结算。\n终局：\n· 每张手牌、军营和工营中的每个人、行动盘上每块未完成圖拉真各获得 1 分。\n· 同类建筑 3 块获得 10 分，4 块获得 20 分，每类只计一次，建筑百搭分配到一类，不能重复使用。\n· 商品奖励：对应展示商品每张黄面 3 分、灰面 2 分；图案需求奖励：剩余相应广场片至少一块时黄面 9 分、灰面 6 分（永久圖拉真与百搭不算该图案）；军团奖励：每个已部署军团黄面 2 分、灰面 1 分；工人奖励：每个已部署工人黄面 1 分、灰面半分并向上取整；黄色奖励数量奖励：每块黄色奖励黄面 3 分、灰面 2 分，包括该奖励本身。未用商品百搭和建筑百搭自动分配到总分最高的合法用途。",
	invalid: "这个操作当前不能执行。",
	notTurn: "现在轮不到你。",
	actions: [
		"港口",
		"广场",
		"军事",
		"元老院",
		"圖拉真",
		"建造"
	],
	goods: [
		"书",
		"皮革",
		"水果",
		"碗",
		"卷轴",
		"油灯",
		"牛",
		"小麦",
		"葡萄酒",
		"鱼",
		"戒指",
		"宝石"
	],
	demands: [
		"面包",
		"祭火",
		"竞技"
	],
	colors: [
		"白",
		"黄",
		"绿",
		"粉",
		"橙",
		"蓝"
	],
	buildings: [
		"喷泉",
		"台阶",
		"门",
		"柱",
		"屋顶"
	],
	phases: {
		arrange: "分配行动标记，每盘放置两枚",
		initialCards: "选择起始商品",
		initialTiles: "选择三个不同类别，放入 II、IV、VI 槽",
		choose: "选择一个非空行动盘",
		sow: "选择下一枚播撒的标记",
		checkTile: "完成圖拉真",
		reward: "选择圖拉真奖励",
		action: "选择行动",
		discard: "选择一张手牌和弃牌堆",
		extra: "是否使用额外行动片？",
		round: "轮末结算",
		demand: "选择用于满足需求的广场片",
		bonus: "选择一块黄色奖励",
		reset: "准备下一季度",
		final: "终局计分",
		done: "终局"
	},
	quarter: "季度",
	round: "轮",
	time: "时间",
	vp: "分",
	public: "公共版图",
	personal: "个人版图",
	hand: "手牌",
	inventory: "收藏",
	supply: "储备",
	workers: "工营",
	soldiers: "军营",
	confirm: "确认",
	cancel: "取消",
	skip: "放弃本次行动",
	finish: "不使用额外行动",
	waiting: "等待",
	draw: "暗抽两张，再弃一张",
	display: "展示并补牌",
	ship: "交付商品",
	take: "取得明牌",
	recruit: "从储备派遣一人",
	deploy: "部署军团",
	advance: "前进一格",
	same: "同类",
	pairs: "成对",
	different: "不同类",
	yellow: "黄面",
	gray: "灰面",
	goodsWild: "商品百搭",
	demandWild: "需求百搭",
	buildingWild: "建筑百搭",
	extraWild: "额外行动百搭",
	votes: "票",
	troopReward: "派往军营的人数",
	workerReward: "派往工营的人数",
	doubleReward: "选择放置 +2 的行动",
	pay: "支付选中的需求片",
	noPay: "确认需求结算",
	bonus: "奖励",
	tileGroups: [
		"额外行动 +2",
		"抽两张商品",
		"永久需求",
		"胜利分",
		"工营增援",
		"军营增援"
	],
	finalTitle: "罗马的荣誉",
	scoreParts: [
		"行动得分",
		"余留资源",
		"建筑套组",
		"奖励"
	],
	review: "回看最终版图",
	back: "返回计分表",
	selected: "已选",
	initialSlot: "选择放置槽位",
	swap: "依次选择两枚标记以交换位置",
	detail: "查看详情",
	close: "关闭",
	confirmReplay: "确认再来一局",
	confirmLobby: "确认返回大厅",
	scoreItem: "计分项目",
	totalScore: "总分"
}, je = {
	confirmReplay: "Confirm new game",
	confirmLobby: "Confirm return to lobby",
	name: "Trajan",
	desc: "Sow markers through six trays to win prestige through trade, construction and politics.",
	rules: "Goal:\nAfter four quarters, most victory points wins. Ties favour the higher final senate order.\nSetup:\n· Each player distributes twelve markers, two of each of six colours, into six trays with exactly two per tray. The leader starts in Italia, one token in each camp, and thirteen in personal supply.\n· In player order, choose three commodity cards one at a time from the face-down deck or either discard pile. Empty discard piles refill during setup. Each player receives one random yellow bonus tile.\n· In player order, take three top Trajan tiles of different categories and assign them freely to slots II, IV and VI. The arch starts at I.\nPlay:\n· Take every marker from a non-empty tray and sow them clockwise, one per tray, choosing their colour order. The last tray determines the action. Advance time by the number taken: tracks have 10/14/18 spaces for 2/3/4 players.\n· If the target tray meets its Trajan tile's two-colour requirement, accomplish it. Extra markers are allowed; markers are never spent. Repeated colours require two markers. Gain its points and effect; demand tiles remain permanently, others leave play. An arch in the centre moves to the newly empty slot.\n· You may then perform or forgo the target action. After performing an action, discard one matching extra-action tile to repeat it once, or twice if that action has an extra-action doubling marker. An extra-action wild substitutes for any action. Only one extra-action tile may be used per turn, including during construction chains.\nActions:\n· Seaport: draw two cards and discard any one to either discard pile; take either face-up top card; display one or two cards and draw the same number; or ship a matching combination. Actual cards shipped or displayed stay in your personal display.\n· Same-goods ship: 1/2/3/4 identical goods score 2/6/12/20 on yellow or 0/1/7/15 on grey. Pair ship: 1/2/3 pairs of different goods score 5/10/15 or 1/6/11. Different-goods ship: 1/2/3/4 different goods score 2/4/6/8 or 0/1/3/5. Using yellow flips it grey; grey remains usable. All ships reset each quarter. Used commodity wilds are removed.\n· Forum: take any forum tile. Demand tiles pay quarterly demands; votes count this quarter. Wilds substitute for goods, demands, buildings or extra actions.\n· Military: move one supply token to camp; move your leader to an adjacent province and take its forum tile; or deploy a camp legionnaire to your leader's province if you have none there. Score the province value minus three per opposing legion, minimum zero. Legionnaires stay in their province.\n· Senate: advance one space, scoring 2,3,4,5,6,7,8 in order. Arriving discs stack on top. At the end of the track, this action is unavailable for the quarter.\n· Trajan: take any category's top tile into the arch's slot. Move the arch clockwise to the next empty slot. With all six slots occupied, put the arch in the centre; no new tile can be taken.\n· Construction: move one supply token to worker camp, or place one camp worker in the district. Your first placement may be anywhere; later placements must be orthogonally adjacent to one of your workers, never on your own occupied space. Opponents may share spaces. Take and score the building tile if present. Your first tile of each kind grants an immediate action: fountain = seaport, stairs = forum, door = senate, columns = military, roof = Trajan. These actions can chain.\nQuarterly scoring:\n· Reaching or crossing the time start ends the round after the whole current turn. Retain the remainder. Reveal one demand after each of the first three rounds; score the quarter after the fourth.\n· Each player meets three demands using permanent Trajan tiles and matching forum tiles. Each permanent tile works once per quarter. Ordinary and wild demand tiles used are spent. Missing 1/2/3 demands loses 4/9/15 points; negative scores are allowed.\n· Votes equal senate position (zero at start, otherwise 2–8) plus vote tiles. Ties compare position, then stack order. The consul chooses a yellow public bonus; the vice consul takes the other grey. Reset discs to start in vote order, consul on top.\n· Remove all vote tiles and unclaimed forum tiles. Refill the forum and extra actions. Refill only provinces containing no tile, leader or legion. Reset ships to yellow. Buildings and Trajan stacks do not refill. The final quarter still includes demands and bonus selection.\nFinal scoring:\n· Gain one point per hand card, worker or legionnaire in camp, and uncompleted Trajan tile in your action circle.\n· Three buildings of one kind score ten; four score twenty, once per kind. Each building wild belongs to one set only.\n· Goods bonuses: each matching displayed card scores 3 yellow/2 grey. Demand bonuses: at least one remaining matching forum icon scores 9/6 (permanent Trajan and wild tiles do not supply that icon). Legions deployed score 2/1 each; workers deployed score 1/half each, rounded up; yellow-bonus-count tiles score 3/2 per yellow bonus, including themselves. Unused commodity and building wilds are assigned to maximise the total.",
	invalid: "That action is not available now.",
	notTurn: "It is not your turn.",
	actions: [
		"Seaport",
		"Forum",
		"Military",
		"Senate",
		"Trajan",
		"Construction"
	],
	goods: [
		"Books",
		"Hide",
		"Fruit",
		"Bowl",
		"Scroll",
		"Oil lamp",
		"Cattle",
		"Wheat",
		"Wine",
		"Fish",
		"Ring",
		"Gems"
	],
	demands: [
		"Bread",
		"Religion",
		"Games"
	],
	colors: [
		"White",
		"Yellow",
		"Green",
		"Pink",
		"Orange",
		"Blue"
	],
	buildings: [
		"Fountain",
		"Stairs",
		"Door",
		"Columns",
		"Roof"
	],
	phases: {
		arrange: "Distribute markers: two per tray",
		initialCards: "Choose your starting commodities",
		initialTiles: "Choose three categories for slots II, IV and VI",
		choose: "Choose a non-empty tray",
		sow: "Choose the next marker to sow",
		checkTile: "Accomplish Trajan tile",
		reward: "Choose the Trajan reward",
		action: "Choose an action",
		discard: "Choose a hand card and discard pile",
		extra: "Use an extra-action tile?",
		round: "End of round",
		demand: "Choose forum tiles to meet demands",
		bonus: "Choose a yellow bonus",
		reset: "Prepare the next quarter",
		final: "Final scoring",
		done: "Finished"
	},
	quarter: "Quarter",
	round: "Round",
	time: "Time",
	vp: "VP",
	public: "Common board",
	personal: "Player mat",
	hand: "Hand",
	inventory: "Collection",
	supply: "Supply",
	workers: "Worker camp",
	soldiers: "Military camp",
	confirm: "Confirm",
	cancel: "Cancel",
	skip: "Forgo this action",
	finish: "No extra action",
	waiting: "Waiting for",
	draw: "Draw two, then discard one",
	display: "Display and refill",
	ship: "Ship goods",
	take: "Take face-up card",
	recruit: "Send one supply token to camp",
	deploy: "Deploy legionnaire",
	advance: "Advance one space",
	same: "Identical",
	pairs: "Pairs",
	different: "Different",
	yellow: "Yellow",
	gray: "Grey",
	goodsWild: "Commodity wild",
	demandWild: "Demand wild",
	buildingWild: "Building wild",
	extraWild: "Extra-action wild",
	votes: "votes",
	troopReward: "Tokens sent to military camp",
	workerReward: "Tokens sent to worker camp",
	doubleReward: "Choose an action for +2",
	pay: "Spend selected demand tiles",
	noPay: "Resolve demands",
	bonus: "Bonus",
	tileGroups: [
		"Extra-action +2",
		"Draw two goods",
		"Permanent demand",
		"Victory points",
		"Worker reinforcement",
		"Military reinforcement"
	],
	finalTitle: "The glory of Rome",
	scoreParts: [
		"Action points",
		"Remaining resources",
		"Building sets",
		"Bonuses"
	],
	review: "Review final board",
	back: "Back to scores",
	selected: "Selected",
	initialSlot: "Choose a slot",
	swap: "Select two markers to swap them",
	detail: "View details",
	close: "Close",
	scoreItem: "Scoring",
	totalScore: "Total"
};
//#endregion
//#region src/games/trajan/art.tsx
function W() {
	return h((e) => e.locale) === "zh" ? Ae : je;
}
var G = (e, t) => `games/trajan/g${e}-${t}.svg`, Me = (e, t) => G(t ? 1 : 13, e), Ne = [
	[
		14,
		19,
		11,
		16
	],
	[
		4,
		5,
		15,
		6
	],
	[
		7,
		8,
		17,
		18
	],
	[
		13,
		10,
		12,
		9
	],
	[
		3,
		1,
		2,
		0
	]
];
function Pe(e) {
	let t = O[e];
	return e >= 70 ? G(5, [
		6,
		1,
		4,
		3,
		2,
		0
	][t.value]) : G(4, t.kind === "votes" ? {
		3: 0,
		5: 1,
		4: 6,
		2: 9
	}[t.value] : t.kind === "demand" ? [
		28,
		42,
		56
	][t.value] : t.kind === "extra" ? [
		26,
		23,
		27,
		25,
		24,
		22
	][t.value] : {
		demandWild: 12,
		goodsWild: 13,
		buildingWild: 18,
		extraWild: 20
	}[t.kind]);
}
function Fe(e, t) {
	let n = O[e];
	return n.kind === "demand" ? t.demands[n.value] : n.kind === "votes" ? `${n.value} ${t.votes}` : n.kind === "extra" ? `${t.actions[n.value]} +1` : t[n.kind];
}
function K({ color: e }) {
	return /* @__PURE__ */ v("span", {
		className: "tr-marker",
		style: { backgroundColor: te[e] },
		children: C[e]
	});
}
function q({ action: e }) {
	return /* @__PURE__ */ v("img", {
		className: "tr-action-icon",
		src: G(5, [
			6,
			1,
			4,
			3,
			2,
			0
		][e]),
		alt: "",
		draggable: !1
	});
}
function J({ id: e, label: t }) {
	return /* @__PURE__ */ v("img", {
		className: "tr-piece",
		src: Pe(e),
		alt: t ?? "",
		draggable: !1
	});
}
function Ie({ id: e }) {
	return /* @__PURE__ */ v("img", {
		className: "tr-piece",
		src: G(2, Ne[Math.floor(e / 4)][e % 4]),
		alt: "",
		draggable: !1
	});
}
function Le({ id: e }) {
	let t = D[e];
	return /* @__PURE__ */ y("span", {
		className: "tr-trajan-art",
		children: [/* @__PURE__ */ v("img", {
			className: "tr-piece",
			src: G(t.group + 6, e % 9),
			alt: "",
			draggable: !1
		}), /* @__PURE__ */ y("span", { children: [t.colors.map((e, t) => /* @__PURE__ */ v(K, { color: e }, t)), /* @__PURE__ */ v("b", { children: t.vp })] })]
	});
}
function Re({ good: e }) {
	let t = [
		0,
		1,
		3,
		6,
		9,
		11
	][Math.floor(e / 2)];
	return /* @__PURE__ */ v("svg", {
		className: "tr-good-art",
		viewBox: `85 ${e % 2 ? 211 : 83} 80 92`,
		"aria-hidden": !0,
		children: /* @__PURE__ */ v("image", {
			href: G(1, t),
			width: "180",
			height: "326"
		})
	});
}
function Y({ good: e }) {
	let t = W();
	return /* @__PURE__ */ y("span", {
		className: "tr-good",
		children: [/* @__PURE__ */ v(Re, { good: e }), /* @__PURE__ */ v("small", { children: t.goods[e] })]
	});
}
function ze({ slot: e }) {
	return /* @__PURE__ */ v("span", {
		className: "tr-slot-no",
		children: w[e]
	});
}
function Be() {
	return /* @__PURE__ */ v("svg", {
		className: "tr-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ v("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "9",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "5 4",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ v("animate", {
				attributeName: "stroke-dashoffset",
				from: "18",
				to: "0",
				dur: "0.9s",
				repeatCount: "indefinite"
			})
		})
	});
}
//#endregion
//#region src/games/trajan/view-player.tsx
function X({ name: e, allowed: t, selected: n, onClick: r, children: i, className: a = "", style: o, anchor: s }) {
	let { ref: c, hidden: l } = U(s);
	return /* @__PURE__ */ y("button", {
		type: "button",
		"data-tr-anchor": s,
		ref: c,
		className: `tr-target ${a}`,
		style: {
			...o,
			visibility: l ? "hidden" : o?.visibility
		},
		"aria-label": e,
		"aria-pressed": n,
		"data-legal": t || void 0,
		"data-selected": n || void 0,
		onClick: r,
		children: [i, t && /* @__PURE__ */ v(Be, {})]
	});
}
function Z({ anchor: e, children: t, className: n, style: r }) {
	let { ref: i, hidden: a } = U(e);
	return /* @__PURE__ */ v("span", {
		"data-tr-anchor": e,
		ref: i,
		className: n,
		style: {
			...r,
			visibility: a ? "hidden" : r?.visibility
		},
		children: t
	});
}
function Q({ anchor: e, children: t, className: n }) {
	let { ref: r } = U(e);
	return /* @__PURE__ */ v("div", {
		"data-tr-anchor": e,
		ref: r,
		className: n,
		children: t
	});
}
function Ve(e, t, n) {
	return e.players.filter((e) => e.leader === t || e.legions.includes(t)).map((e) => n.find((t) => t.rid === e.rid)?.name ?? e.rid).join(" · ");
}
function He({ pub: e, members: t, legal: n = [], send: r, initialGroup: i, chooseGroup: a, selectedGoods: o = [], wild: s = [] }) {
	let c = W(), { ref: l } = U("map-area"), { ref: d } = U("forum-area"), { ref: f } = U("forum-supply"), { ref: p } = U("bonus-supply"), { ref: m } = U("bonus-pool"), h = (e, t) => n.some((n) => n.type === "act" && n.mode === e && (t === void 0 || n.target === t)), g = (e) => n.some((t) => t.type === "initialCard" && t.pile === e), _ = (e) => u[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % u.length].hex;
	return /* @__PURE__ */ y("div", {
		className: "tr-common",
		children: [/* @__PURE__ */ y("section", {
			ref: l,
			className: "tr-map",
			"aria-label": c.actions[2],
			children: [
				/* @__PURE__ */ v("svg", {
					className: "tr-map-art",
					viewBox: "90 110 660 350",
					preserveAspectRatio: "xMidYMid slice",
					"aria-hidden": !0,
					children: /* @__PURE__ */ v("image", {
						href: "games/trajan/board.svg",
						width: "760",
						height: "1068"
					})
				}),
				/* @__PURE__ */ v("svg", {
					className: "tr-map-roads",
					viewBox: "0 0 100 100",
					preserveAspectRatio: "none",
					"aria-hidden": !0,
					children: j.flatMap((e, t) => e.adjacent.filter((e) => e > t).map((n) => /* @__PURE__ */ v("path", { d: `M${e.x},${e.y}L${j[n].x},${j[n].y}` }, `${t}:${n}`)))
				}),
				j.map((n, i) => {
					let a = e.provinces[i] ?? -1;
					return /* @__PURE__ */ y(X, {
						name: `${n.name} · ${n.vp} ${c.vp}${Ve(e, i, t) ? ` · ${Ve(e, i, t)}` : ""}`,
						anchor: `province:${i}`,
						className: "tr-province",
						style: {
							left: `${n.x}%`,
							top: `${Math.max(13, n.y)}%`
						},
						allowed: h("move", i),
						onClick: () => h("move", i) && r?.({
							type: "act",
							mode: "move",
							target: i
						}),
						children: [
							/* @__PURE__ */ v("strong", { children: n.name }),
							/* @__PURE__ */ y("span", {
								className: "tr-province-body",
								children: [a >= 0 && /* @__PURE__ */ v(J, { id: a }), /* @__PURE__ */ v("b", { children: n.vp || "•" })]
							}),
							/* @__PURE__ */ v("span", {
								className: "tr-troops",
								children: e.players.flatMap((e) => [e.leader === i ? /* @__PURE__ */ v(Z, {
									anchor: `leader:${e.rid}`,
									children: /* @__PURE__ */ v("i", {
										title: t.find((t) => t.rid === e.rid)?.name,
										className: "tr-leader",
										style: { background: _(e.rid) },
										children: "L"
									})
								}, `${e.rid}L`) : null, e.legions.includes(i) ? /* @__PURE__ */ v(Z, {
									anchor: `legion:${e.rid}:${i}`,
									children: /* @__PURE__ */ v("i", {
										title: t.find((t) => t.rid === e.rid)?.name,
										style: { background: _(e.rid) },
										children: "I"
									})
								}, `${e.rid}A`) : null])
							})
						]
					}, n.name);
				}),
				h("deploy") && /* @__PURE__ */ v("button", {
					className: "tr-deploy",
					type: "button",
					onClick: () => r?.({
						type: "act",
						mode: "deploy"
					}),
					children: c.deploy
				})
			]
		}), /* @__PURE__ */ y("div", {
			className: "tr-city",
			children: [
				/* @__PURE__ */ y("section", {
					className: "tr-harbour tr-stone",
					children: [
						/* @__PURE__ */ y("h3", { children: [/* @__PURE__ */ v(q, { action: 0 }), c.actions[0]] }),
						/* @__PURE__ */ y("div", {
							className: "tr-decks",
							children: [/* @__PURE__ */ y(X, {
								anchor: "goods-deck",
								className: "tr-deck tr-back",
								name: c.draw,
								allowed: g(0) || h("draw"),
								onClick: () => g(0) ? r?.({
									type: "initialCard",
									pile: 0
								}) : h("draw") && r?.({
									type: "act",
									mode: "draw"
								}),
								children: [/* @__PURE__ */ v(q, { action: 0 }), /* @__PURE__ */ v("b", { children: e.goodsLeft })]
							}), e.discards.map((t, i) => /* @__PURE__ */ y(X, {
								anchor: `discard:${i}`,
								className: "tr-deck",
								name: `${c.take} ${i + 1}`,
								allowed: g(i + 1) || h("take", i) || e.phase === "discard" && n.length > 0 && o.length === 1,
								onClick: () => {
									g(i + 1) ? r?.({
										type: "initialCard",
										pile: i + 1
									}) : e.phase === "discard" && o.length === 1 ? r?.({
										type: "discard",
										card: o[0],
										pile: i
									}) : h("take", i) && r?.({
										type: "act",
										mode: "take",
										target: i
									});
								},
								children: [t.top >= 0 ? /* @__PURE__ */ v(Z, {
									anchor: `discard-face:${i}`,
									className: "tr-discard-face",
									children: /* @__PURE__ */ v(Y, { good: t.top })
								}) : /* @__PURE__ */ v("span", { children: "—" }), /* @__PURE__ */ v("small", { children: t.count })]
							}, i))]
						}),
						/* @__PURE__ */ v("div", {
							className: "tr-ships",
							children: e.ships.map((t, i) => {
								let a = H(i, [...o, ...s], t), l = e.action === 0 && e.phase === "action" && n.length > 0 && a !== null;
								return /* @__PURE__ */ y(X, {
									name: `${[
										c.same,
										c.pairs,
										c.different
									][i]} · ${t ? c.yellow : c.gray}`,
									anchor: `ship:${i}`,
									className: "tr-ship",
									allowed: l,
									style: { filter: t ? void 0 : "saturate(.12)" },
									onClick: () => l && r?.({
										type: "act",
										mode: "ship",
										target: i,
										cards: o,
										wild: s
									}),
									children: [
										/* @__PURE__ */ y("svg", {
											viewBox: "0 0 130 70",
											"aria-hidden": !0,
											children: [
												/* @__PURE__ */ v("path", {
													d: "M6 47H122L104 65H25Z",
													fill: "#7b4f31",
													stroke: "#4e3528",
													strokeWidth: "3"
												}),
												/* @__PURE__ */ v("path", {
													d: "M40 5V48M88 6V48",
													stroke: "#49392a",
													strokeWidth: "3"
												}),
												/* @__PURE__ */ v("path", {
													d: "M41 6Q80 23 43 43Z M89 7Q126 24 91 44Z",
													fill: t ? "#e4be58" : "#b6b2a7",
													stroke: "#846735",
													strokeWidth: "2"
												}),
												/* @__PURE__ */ v("path", {
													d: "M4 68Q20 60 35 68T68 68T101 68T129 68",
													fill: "none",
													stroke: "#7caaad",
													strokeWidth: "3"
												})
											]
										}),
										/* @__PURE__ */ v("strong", { children: [
											c.same,
											c.pairs,
											c.different
										][i] }),
										/* @__PURE__ */ v("small", { children: M[i][+!t].join(" / ") }),
										l && /* @__PURE__ */ y("b", { children: [
											a,
											" ",
											c.vp
										] })
									]
								}, i);
							})
						})
					]
				}),
				/* @__PURE__ */ y("section", {
					className: "tr-construction tr-stone",
					children: [/* @__PURE__ */ y("h3", { children: [/* @__PURE__ */ v(q, { action: 5 }), c.actions[5]] }), /* @__PURE__ */ v("div", {
						className: "tr-building-grid",
						children: e.construction.map((n, i) => /* @__PURE__ */ y(X, {
							name: `${c.actions[5]} ${i + 1}${n >= 0 ? ` · ${c.buildings[Math.floor(n / 4)]} ${n % 4 + 2}` : ""}`,
							anchor: `build:${i}`,
							className: "tr-site",
							allowed: h("build", i),
							onClick: () => h("build", i) && r?.({
								type: "act",
								mode: "build",
								target: i
							}),
							children: [n >= 0 ? /* @__PURE__ */ v(Ie, { id: n }) : /* @__PURE__ */ v("span", {
								className: "tr-empty-site",
								children: i + 1
							}), /* @__PURE__ */ v("span", {
								className: "tr-site-workers",
								children: e.players.filter((e) => e.built.includes(i)).map((e) => /* @__PURE__ */ v(Z, {
									anchor: `worker:${e.rid}:${i}`,
									children: /* @__PURE__ */ v("i", {
										title: t.find((t) => t.rid === e.rid)?.name,
										style: { background: _(e.rid) },
										children: "I"
									})
								}, e.rid))
							})]
						}, i))
					})]
				}),
				/* @__PURE__ */ y("section", {
					className: "tr-trajan-stacks tr-stone",
					children: [/* @__PURE__ */ y("h3", { children: [/* @__PURE__ */ v(q, { action: 4 }), c.actions[4]] }), /* @__PURE__ */ v("div", { children: e.stacks.map((e, t) => {
						let o = n.some((e) => e.type === "initialTile" && e.group === t);
						return /* @__PURE__ */ y(X, {
							name: `${c.tileGroups[t]} · ${e.count}`,
							anchor: `stack:${t}`,
							className: "tr-stack",
							allowed: o || h("trajan", t),
							selected: i === t,
							onClick: () => o ? a?.(t) : h("trajan", t) && r?.({
								type: "act",
								mode: "trajan",
								target: t
							}),
							children: [e.top >= 0 ? /* @__PURE__ */ v(Le, { id: e.top }) : /* @__PURE__ */ v("span", { children: "—" }), /* @__PURE__ */ v("small", { children: e.count })]
						}, t);
					}) })]
				}),
				/* @__PURE__ */ y("section", {
					className: "tr-forum tr-stone",
					children: [/* @__PURE__ */ y("h3", {
						ref: f,
						children: [/* @__PURE__ */ v(q, { action: 1 }), c.actions[1]]
					}), /* @__PURE__ */ v("div", {
						ref: d,
						children: e.forum.map((e, t) => /* @__PURE__ */ v(X, {
							name: Fe(e, c),
							anchor: `forum-slot:${t}`,
							className: "tr-forum-tile",
							allowed: h("forum", e),
							onClick: () => h("forum", e) && r?.({
								type: "act",
								mode: "forum",
								target: e
							}),
							children: /* @__PURE__ */ v(J, { id: e })
						}, e))
					})]
				}),
				/* @__PURE__ */ y("section", {
					className: "tr-senate tr-stone",
					children: [
						/* @__PURE__ */ y("h3", {
							ref: p,
							children: [/* @__PURE__ */ v(q, { action: 3 }), c.actions[3]]
						}),
						/* @__PURE__ */ v("div", {
							className: "tr-senate-track",
							children: [
								0,
								2,
								3,
								4,
								5,
								6,
								7,
								8
							].map((n, i) => /* @__PURE__ */ y(X, {
								name: `${c.actions[3]} ${n}`,
								anchor: `senate:${i}`,
								allowed: h("senate") && e.players.find((t) => t.rid === e.active)?.senate === i - 1,
								onClick: () => h("senate") && e.players.find((t) => t.rid === e.active)?.senate === i - 1 && r?.({
									type: "act",
									mode: "senate"
								}),
								children: [/* @__PURE__ */ v("b", { children: n || "•" }), /* @__PURE__ */ v("span", { children: [...e.players].filter((e) => e.senate === i).sort((e, t) => t.order - e.order).map((e) => /* @__PURE__ */ v(Z, {
									anchor: `senate-disc:${e.rid}`,
									children: /* @__PURE__ */ v("i", {
										title: t.find((t) => t.rid === e.rid)?.name,
										style: { background: _(e.rid) },
										children: "●"
									})
								}, e.rid)) })]
							}, i))
						}),
						/* @__PURE__ */ v("div", {
							ref: m,
							className: "tr-bonus-pool",
							children: [0, 1].map((t) => /* @__PURE__ */ v(Q, {
								anchor: `bonus-place:${t}`,
								className: "tr-bonus-place",
								children: e.bonuses[t] !== void 0 && ((e) => /* @__PURE__ */ v(X, {
									name: `${c.bonus} ${e + 1}`,
									anchor: `bonus:${e}`,
									allowed: n.some((t) => t.type === "bonus" && t.tile === e),
									onClick: () => n.some((t) => t.type === "bonus" && t.tile === e) && r?.({
										type: "bonus",
										tile: e
									}),
									children: /* @__PURE__ */ v("img", {
										src: G(1, e),
										alt: ""
									})
								}, e))(e.bonuses[t])
							}, t))
						})
					]
				})
			]
		})]
	});
}
function Ue(e, t) {
	return [
		[
			t.supply,
			e.supply,
			"supply"
		],
		[
			t.workers,
			e.workers,
			"workers"
		],
		[
			t.soldiers,
			e.soldiers,
			"soldiers"
		]
	];
}
function We({ p: e, pub: t, legal: n = [], send: r, arranged: i, swapAt: a, onSwap: o, initialGroup: s, selectedTiles: c = [], toggleTile: l, addWild: u }) {
	let d = W(), f = e.rid === t.active && n.length > 0, { ref: p } = U(`mat:${e.rid}`);
	return /* @__PURE__ */ y("div", {
		ref: p,
		className: "tr-mat",
		"data-arrange": !!i || void 0,
		children: [
			/* @__PURE__ */ v("div", {
				className: "tr-camps",
				children: Ue(e, d).map(([t, n, r]) => /* @__PURE__ */ y(Z, {
					anchor: `${r}:${e.rid}`,
					children: [t, /* @__PURE__ */ v("b", { children: n })]
				}, r))
			}),
			/* @__PURE__ */ y("div", {
				className: "tr-wheel",
				"aria-label": d.personal,
				children: [
					/* @__PURE__ */ y("svg", {
						viewBox: "0 0 420 420",
						className: "tr-wheel-stone",
						"aria-hidden": !0,
						children: [
							/* @__PURE__ */ v("circle", {
								cx: "210",
								cy: "210",
								r: "205",
								fill: "#e4d5ae",
								stroke: "#7e6748",
								strokeWidth: "4"
							}),
							/* @__PURE__ */ v("circle", {
								cx: "210",
								cy: "210",
								r: "95",
								fill: "#c2ad7d",
								stroke: "#aa8c5e",
								strokeWidth: "4"
							}),
							Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ v("path", {
								d: "M210 8V113",
								transform: `rotate(${t * 60} 210 210)`,
								stroke: "#ac9162",
								strokeWidth: "2"
							}, t)),
							/* @__PURE__ */ v("path", {
								d: "M185 225V176H235V225 M177 176V165H243V176M199 225V201Q210 186 221 201V225",
								fill: "none",
								stroke: "#715638",
								strokeWidth: "9"
							}),
							/* @__PURE__ */ v("path", {
								d: "M190 241H230",
								stroke: "#715638",
								strokeWidth: "4"
							})
						]
					}),
					e.bowls.map((c, l) => {
						let u = (l * 60 - 90) * Math.PI / 180, p = e.tiles[l], m = f && n.some((e) => e.type === "takeBowl" && e.bowl === l), h = f && s !== void 0 && n.some((e) => e.type === "initialTile" && e.group === s && e.slot === l);
						return /* @__PURE__ */ y("div", {
							className: "tr-wheel-sector",
							"data-next": t.phase === "sow" && t.active === e.rid && t.nextBowl === l || void 0,
							style: {
								left: `${50 + Math.cos(u) * 33}%`,
								top: `${50 + Math.sin(u) * 33}%`
							},
							children: [
								/* @__PURE__ */ y(X, {
									anchor: `bowl:${e.rid}:${l}`,
									name: `${w[l]} · ${d.actions[l]} · ${c.length}`,
									className: "tr-bowl",
									allowed: m,
									onClick: () => m && r?.({
										type: "takeBowl",
										bowl: l
									}),
									children: [
										/* @__PURE__ */ v(q, { action: l }),
										/* @__PURE__ */ v("span", {
											className: "tr-bowl-markers",
											children: (i ? i.slice(l * 2, l * 2 + 2) : c).map((t, n) => /* @__PURE__ */ v(Z, {
												anchor: `bowl-marker:${e.rid}:${l}:${n}`,
												children: /* @__PURE__ */ v(K, { color: t })
											}, n))
										}),
										/* @__PURE__ */ v(ze, { slot: l }),
										e.doubled.includes(l) && /* @__PURE__ */ v(Z, {
											anchor: `double:${e.rid}:${l}`,
											className: "tr-double",
											children: "+2"
										})
									]
								}),
								i && /* @__PURE__ */ v("span", {
									className: "tr-arrange-markers",
									children: i.slice(l * 2, l * 2 + 2).map((e, t) => /* @__PURE__ */ v("button", {
										type: "button",
										"aria-label": `${w[l]} ${d.colors[e]}`,
										"aria-pressed": a === l * 2 + t,
										onClick: () => o?.(l * 2 + t),
										children: /* @__PURE__ */ v(K, { color: e })
									}, t))
								}),
								/* @__PURE__ */ v(X, {
									anchor: `tile:${e.rid}:${l}`,
									className: "tr-circle-tile",
									name: `${w[l]}${p >= 0 ? ` · ${d.tileGroups[D[p].group]} · ${D[p].vp} ${d.vp}` : ""}`,
									allowed: h,
									onClick: () => h && r?.({
										type: "initialTile",
										group: s,
										slot: l
									}),
									children: p >= 0 ? /* @__PURE__ */ v(Le, { id: p }) : e.arch === l ? /* @__PURE__ */ v(Z, {
										anchor: `arch:${e.rid}`,
										children: "⌒"
									}) : /* @__PURE__ */ v("span", { children: w[l] })
								})
							]
						}, l);
					}),
					/* @__PURE__ */ v(Z, {
						anchor: `arch-centre:${e.rid}`,
						className: "tr-central-arch",
						children: e.arch < 0 ? /* @__PURE__ */ v(Z, {
							anchor: `arch:${e.rid}`,
							children: "⌒"
						}) : /* @__PURE__ */ v("span", {
							className: "tr-completed-icon",
							"aria-hidden": !0,
							children: "⌒"
						})
					})
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "tr-inventory tr-stone",
				children: [
					/* @__PURE__ */ v("h3", { children: /* @__PURE__ */ v(Z, {
						anchor: `completed:${e.rid}`,
						children: d.inventory
					}) }),
					/* @__PURE__ */ v("div", {
						className: "tr-permanent",
						children: e.permanent.map((t, n) => /* @__PURE__ */ v(Z, {
							anchor: `permanent:${e.rid}:${n}`,
							children: /* @__PURE__ */ v("img", {
								src: G(4, [
									28,
									42,
									56
								][t]),
								alt: d.demands[t]
							})
						}, n))
					}),
					/* @__PURE__ */ v(Q, {
						anchor: `inventory-area:${e.rid}`,
						className: "tr-inventory-tiles",
						children: e.inventory.map((i) => {
							let a = n.some((e) => e.type === "extra" && e.tile === i) || f && t.phase === "demand" && ["demand", "demandWild"].includes(O[i].kind) || f && t.action === 0 && t.phase === "action" && O[i].kind === "goodsWild";
							return /* @__PURE__ */ v(X, {
								anchor: `inventory:${e.rid}:${i}`,
								name: Fe(i, d),
								allowed: a,
								selected: c.includes(i),
								className: "tr-inventory-tile",
								onClick: () => {
									n.some((e) => e.type === "extra" && e.tile === i) ? r?.({
										type: "extra",
										tile: i
									}) : f && t.phase === "demand" ? l?.(i) : a && O[i].kind === "goodsWild" && u?.();
								},
								children: /* @__PURE__ */ v(J, { id: i })
							}, i);
						})
					}),
					/* @__PURE__ */ v(Q, {
						anchor: `buildings:${e.rid}`,
						className: "tr-collected-buildings",
						children: e.buildings.map((t) => /* @__PURE__ */ v(Z, {
							anchor: `building:${e.rid}:${t}`,
							children: /* @__PURE__ */ v(Ie, { id: t })
						}, t))
					}),
					/* @__PURE__ */ v(Q, {
						anchor: `bonuses:${e.rid}`,
						className: "tr-bonuses",
						children: e.bonus.map((t) => /* @__PURE__ */ y("figure", { children: [/* @__PURE__ */ v(Z, {
							anchor: `owned-bonus:${e.rid}:${t.id}`,
							children: /* @__PURE__ */ v("img", {
								src: Me(t.id, t.yellow),
								alt: `${d.bonus} ${t.id + 1}`
							})
						}), /* @__PURE__ */ v("figcaption", { children: t.yellow ? d.yellow : d.gray })] }, t.id))
					}),
					/* @__PURE__ */ v(Q, {
						anchor: `display-area:${e.rid}`,
						className: "tr-displayed",
						children: e.display.map((t, n) => /* @__PURE__ */ v(Z, {
							anchor: `display:${e.rid}:${n}`,
							children: /* @__PURE__ */ v(Y, { good: t })
						}, n))
					})
				]
			})
		]
	});
}
function Ge(e) {
	let t = e.public, n = e.private, r = W(), [i, a] = o("common"), [s, c] = o(e.myRid), [u, h] = o({
		rid: "",
		colors: [],
		at: -1
	}), [g, b] = o(-1), [ee, x] = o({
		stamp: "",
		hand: [],
		tiles: [],
		wild: []
	}), [S, C] = o(!1), { ref: te } = U("tr-viewport"), { ref: ne } = U(`held:${e.myRid}`), { ref: re } = U(`hand-area:${e.myRid}`), { ref: w } = U("demands-area"), { ref: T } = U("demand-deck"), E = `${t.active}:${t.phase}:${t.log.length}:${t.time}`, k = ee.stamp === E ? ee : {
		stamp: E,
		hand: [],
		tiles: [],
		wild: []
	}, A = n?.legal ?? [], j = A.length > 0, M = t.players.find((e) => e.rid === s) ?? t.players[0], ie = t.players.find((t) => t.rid === e.myRid), N = u.rid === e.myRid ? u.colors : Array.from({ length: 12 }, (e, t) => t % 6), P = (t) => e.members.find((e) => e.rid === t)?.name ?? t, F = k.hand.map((e) => n?.hand[e] ?? -1).filter((e) => e >= 0), I = (e) => x({
		...k,
		hand: t.phase === "discard" ? [e] : k.hand.includes(e) ? k.hand.filter((t) => t !== e) : [...k.hand, e]
	}), L = (t) => {
		e.send(t), x({
			stamp: "",
			hand: [],
			tiles: [],
			wild: []
		}), C(!1);
	}, ae = (e) => A.some((t) => t.type === "act" && t.mode === e), oe = (e) => e.map((e) => `${O[e].kind}:${O[e].value}`).sort().join(","), se = A.some((e) => e.type === "pay" && oe(e.tiles) === oe(k.tiles)), R = A.some((e) => e.type === "initialTile" && e.group === g) ? g : void 0;
	return /* @__PURE__ */ v("div", {
		ref: te,
		className: "tr-screen",
		children: /* @__PURE__ */ v(f, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ y("div", {
				className: "tr-header",
				children: [
					/* @__PURE__ */ v(p, {
						tone: j ? "accent" : "info",
						text: j ? r.phases[t.phase] : `${r.waiting} ${P(t.active)}`,
						chip: `${r.quarter} ${t.quarter} · ${r.round} ${t.round}`,
						accent: "#98502d"
					}),
					/* @__PURE__ */ v(m, {
						variant: "plate",
						members: e.members,
						myRid: e.myRid,
						anchorOf: (e) => `seat:${e}`,
						action: (e) => e === t.active ? "pending" : null,
						status: (e) => /* @__PURE__ */ y("span", { children: [
							/* @__PURE__ */ v(l, { value: t.players.find((t) => t.rid === e)?.vp ?? 0 }),
							" ",
							r.vp
						] })
					}),
					/* @__PURE__ */ y("div", {
						className: "tr-time",
						children: [
							/* @__PURE__ */ y("span", {
								ref: T,
								children: [
									r.time,
									" ",
									t.time,
									"/",
									t.track
								]
							}),
							/* @__PURE__ */ v("div", { children: /* @__PURE__ */ v("i", { style: { width: `${t.time / t.track * 100}%` } }) }),
							/* @__PURE__ */ v("span", {
								ref: w,
								className: "tr-demands",
								children: t.demands.map((e, t) => /* @__PURE__ */ v(Z, {
									anchor: `demand:${t}`,
									children: /* @__PURE__ */ v("img", {
										src: G(4, [
											28,
											42,
											56
										][e]),
										alt: r.demands[e]
									})
								}, t))
							})
						]
					})
				]
			}),
			actionsHeight: "tr-controls",
			actions: /* @__PURE__ */ y("div", {
				className: "tr-control-inner",
				children: [/* @__PURE__ */ v("div", {
					ref: re,
					className: "tr-hand",
					"aria-label": r.hand,
					children: n?.hand.map((t, n) => /* @__PURE__ */ v(X, {
						anchor: `hand:${e.myRid}:${n}`,
						name: r.goods[t],
						className: "tr-hand-card",
						selected: k.hand.includes(n),
						onClick: () => I(n),
						children: /* @__PURE__ */ v(Y, { good: t })
					}, n))
				}), /* @__PURE__ */ y("div", {
					className: "tr-choices",
					ref: ne,
					children: [
						j && t.phase === "arrange" && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("small", { children: r.swap }), /* @__PURE__ */ v("button", {
							type: "button",
							onClick: () => L({
								type: "arrange",
								colors: N
							}),
							children: r.confirm
						})] }),
						/* @__PURE__ */ v("div", {
							className: "tr-held",
							"data-active": j && t.phase === "sow" || void 0,
							"aria-hidden": !j || t.phase !== "sow",
							children: [
								0,
								1,
								2,
								3,
								4,
								5
							].map((n) => /* @__PURE__ */ y("button", {
								type: "button",
								disabled: !j || t.phase !== "sow" || !t.held.includes(n),
								"aria-label": r.colors[n],
								onClick: () => L({
									type: "sow",
									color: n
								}),
								children: [/* @__PURE__ */ v(Z, {
									anchor: `held-color:${e.myRid}:${n}`,
									children: /* @__PURE__ */ v(K, { color: n })
								}), /* @__PURE__ */ v("b", { children: t.held.filter((e) => e === n).length })]
							}, n))
						}),
						j && t.phase === "reward" && /* @__PURE__ */ v("span", {
							className: "tr-reward-choices",
							children: A.map((e, n) => e.type === "reward" ? /* @__PURE__ */ v("button", {
								type: "button",
								onClick: () => L(e),
								children: D[t.reward].group === 0 ? /* @__PURE__ */ y(_, { children: [
									/* @__PURE__ */ v(q, { action: e.value }),
									r.actions[e.value],
									" +2"
								] }) : `${D[t.reward].group === 4 ? r.workerReward : r.troopReward} ${e.value}`
							}, n) : null)
						}),
						ae("recruit") && /* @__PURE__ */ v("button", {
							type: "button",
							onClick: () => L({
								type: "act",
								mode: "recruit"
							}),
							children: r.recruit
						}),
						ae("display") && F.length > 0 && F.length <= 2 && /* @__PURE__ */ v("button", {
							type: "button",
							onClick: () => L({
								type: "act",
								mode: "display",
								cards: F
							}),
							children: r.display
						}),
						j && t.phase === "action" && /* @__PURE__ */ v("button", {
							type: "button",
							className: "tr-quiet",
							onClick: () => L({
								type: "act",
								mode: "skip"
							}),
							children: r.skip
						}),
						j && t.phase === "extra" && /* @__PURE__ */ v("button", {
							type: "button",
							className: "tr-quiet",
							onClick: () => L({
								type: "extra",
								tile: -1
							}),
							children: r.finish
						}),
						j && t.phase === "demand" && /* @__PURE__ */ v("button", {
							type: "button",
							disabled: !se,
							onClick: () => L({
								type: "pay",
								tiles: k.tiles
							}),
							children: k.tiles.length ? r.pay : r.noPay
						}),
						k.wild.length > 0 && /* @__PURE__ */ y("button", {
							type: "button",
							className: "tr-quiet",
							onClick: () => x({
								...k,
								wild: []
							}),
							children: [
								r.goodsWild,
								": ",
								k.wild.map((e) => r.goods[e]).join(" · "),
								" ×"
							]
						}),
						k.hand.length > 0 && /* @__PURE__ */ v("button", {
							type: "button",
							className: "tr-quiet",
							onClick: () => x({
								...k,
								hand: []
							}),
							children: r.cancel
						})
					]
				})]
			}),
			overlay: S && /* @__PURE__ */ y("div", {
				className: "tr-wild-picker",
				children: [
					/* @__PURE__ */ v("b", { children: r.goodsWild }),
					/* @__PURE__ */ v("div", { children: r.goods.map((e, t) => /* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => {
							let e = ie?.inventory.filter((e) => O[e].kind === "goodsWild").length ?? 0;
							k.wild.length < e && x({
								...k,
								wild: [...k.wild, t]
							}), C(!1);
						},
						children: /* @__PURE__ */ v(Y, { good: t })
					}, e)) }),
					/* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => C(!1),
						children: r.cancel
					})
				]
			}),
			children: /* @__PURE__ */ y("div", {
				className: "tr-tabletop",
				children: [
					/* @__PURE__ */ v(d, {
						kind: "sheen",
						base: "#d5c3a0",
						className: "absolute inset-0"
					}),
					/* @__PURE__ */ y("nav", {
						className: "tr-tabs",
						children: [/* @__PURE__ */ v("button", {
							type: "button",
							"aria-pressed": i === "common",
							onClick: () => a("common"),
							children: r.public
						}), /* @__PURE__ */ v("button", {
							type: "button",
							"aria-pressed": i === "mat",
							onClick: () => a("mat"),
							children: r.personal
						})]
					}),
					/* @__PURE__ */ y("div", {
						className: "tr-main-grid",
						"data-tab": i,
						children: [/* @__PURE__ */ v("div", {
							className: "tr-common-scroll",
							children: /* @__PURE__ */ v(He, {
								pub: t,
								members: e.members,
								legal: A,
								send: L,
								selectedGoods: F,
								wild: k.wild,
								initialGroup: R,
								chooseGroup: (t) => {
									b(t), a("mat"), c(e.myRid);
								}
							})
						}), /* @__PURE__ */ y("div", {
							className: "tr-mat-scroll",
							children: [/* @__PURE__ */ v("div", {
								className: "tr-mat-owners",
								children: t.players.map((e) => /* @__PURE__ */ v("button", {
									type: "button",
									"aria-pressed": M.rid === e.rid,
									onClick: () => c(e.rid),
									children: P(e.rid)
								}, e.rid))
							}), /* @__PURE__ */ v(We, {
								p: M,
								pub: t,
								legal: M.rid === e.myRid ? A : [],
								send: L,
								arranged: j && t.phase === "arrange" && M.rid === e.myRid ? N : void 0,
								swapAt: u.at,
								onSwap: (t) => {
									if (u.at < 0 || u.rid !== e.myRid) h({
										rid: e.myRid,
										colors: N,
										at: t
									});
									else {
										let n = [...N];
										[n[t], n[u.at]] = [n[u.at], n[t]], h({
											rid: e.myRid,
											colors: n,
											at: -1
										});
									}
								},
								initialGroup: R,
								selectedTiles: k.tiles,
								toggleTile: (e) => {
									["demand", "demandWild"].includes(O[e].kind) && x({
										...k,
										tiles: k.tiles.includes(e) ? k.tiles.filter((t) => t !== e) : [...k.tiles, e]
									});
								},
								addWild: () => C(!0)
							})]
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/trajan/bot.ts
var Ke = {
	completion: 1,
	demand: 1,
	building: 1
};
function qe(e, t, n) {
	let r = O[e];
	if (r.kind === "demand" || r.kind === "demandWild") {
		let e = r.kind === "demandWild" || t.demands.filter((e) => e === r.value).length > ((e) => n.permanent.filter((t) => t === e).length + n.inventory.filter((t) => O[t].kind === "demand" && O[t].value === e).length)(r.value);
		return (e ? 4.5 : 1.6) + t.round * (e ? .3 : 0);
	}
	return r.kind === "votes" ? r.value * .65 : r.kind === "extra" || r.kind === "extraWild" ? 3.5 : r.kind === "buildingWild" ? n.buildings.length > 3 ? 5 : 2.5 : 2;
}
function Je(e, t, n) {
	return e === 0 ? n.handCount >= 3 ? 4 : 2 : e === 1 ? t.forum.length ? Math.max(...t.forum.map((e) => qe(e, t, n))) : 0 : e === 2 ? n.soldiers && n.leader < 10 && !n.legions.includes(n.leader) ? j[n.leader].vp : 3 : e === 3 ? n.senate < 7 ? n.senate + 2.6 : 0 : e === 4 ? n.arch >= 0 && t.stacks.some((e) => e.count) ? 3 : 0 : n.workers ? 5 : n.supply ? 2 : 0;
}
function Ye(e, t) {
	let n = D[e];
	return n.vp + (n.group === 2 ? 7 / (1 + t.permanent.filter((e) => e === n.demand).length) : n.group === 0 ? 4 : n.group >= 4 ? 2 : 1);
}
function $(e, t) {
	let n = [...t];
	for (let t of e) {
		let e = n.indexOf(t);
		e >= 0 && n.splice(e, 1);
	}
	return n;
}
function Xe(e, t) {
	return k[e] ? t.display.filter((t) => k[e].includes(t)).length * 3 + 2 : A[e] === void 0 ? e === 4 ? t.bonus.filter((e) => e.yellow).length * 3 + 3 : e === 5 ? t.legions.length * 2 + 2 : t.built.length + 2 : t.inventory.some((t) => O[t].kind === "demand" && O[t].value === A[e]) ? 9 : 1;
}
function Ze(e, t, n, r, i) {
	let a = t.players.find((e) => e.rid === r);
	if (e.type === "initialTile") return Ye(t.stacks[e.group].top, a) + +(e.group === 2);
	if (e.type === "initialCard") return e.pile ? n.hand.includes(t.discards[e.pile - 1].top) ? 2 : 1 : .9;
	if (e.type === "takeBowl") {
		let n = a.bowls[e.bowl], r = (e.bowl + n.length) % 6, o = a.tiles[r], s = Je(r, t, a);
		if (o >= 0) {
			let t = $(r === e.bowl ? [] : a.bowls[r], D[o].colors), c = Math.ceil(n.length / 6);
			t.length <= c && $(n, t).length === 0 && (s += i.completion * Ye(o, a));
		}
		return s / (1 + n.length * .07);
	}
	if (e.type === "sow") {
		let n = (t.nextBowl + t.held.length - 1) % 6, r = a.tiles[n];
		if (r < 0) return 0;
		let i = [...t.held];
		i.splice(i.indexOf(e.color), 1);
		let o = $([...a.bowls[n], ...t.nextBowl === n ? [e.color] : []], D[r].colors), s = Array.from({ length: i.length }, (e, n) => (t.nextBowl + n + 1) % 6).filter((e) => e === n).length;
		return o.length <= s && $(i, o).length === 0 ? 20 : -o.length;
	}
	if (e.type === "reward") return t.reward >= 0 && D[t.reward].group === 0 ? Je(e.value, t, a) : e.value;
	if (e.type === "discard") return -n.hand.filter((t) => t === e.card).length;
	if (e.type === "extra") return e.tile < 0 ? 0 : Je(t.action, t, a) - 1;
	if (e.type === "pay") return -e.tiles.reduce((e, t) => e + +(O[t].kind === "demandWild") + a.bonus.filter((e) => A[e.id] === O[t].value).length * 3, 0);
	if (e.type === "bonus") return Xe(e.tile, a);
	if (e.type !== "act") return 0;
	if (e.mode === "skip") return -100;
	if (e.mode === "forum") return i.demand * qe(e.target, t, a);
	if (e.mode === "senate") return a.senate + 2.7;
	if (e.mode === "deploy") return Math.max(0, j[a.leader].vp - t.players.filter((e) => e.rid !== r && e.legions.includes(a.leader)).length * 3);
	if (e.mode === "move") {
		let n = e.target, r = t.provinces[n] ?? -1;
		return (r >= 0 ? qe(r, t, a) : 0) + (a.soldiers && !a.legions.includes(n) ? j[n].vp * .45 : 0) - .3;
	}
	if (e.mode === "recruit") return (t.action === 2 ? a.soldiers : a.workers) < 2 ? 2.5 : .5;
	if (e.mode === "trajan") return Ye(t.stacks[e.target].top, a) * .45;
	if (e.mode === "build") {
		let n = t.construction[e.target];
		if (n < 0) return .4;
		let r = Math.floor(n / 4), o = a.buildings.filter((e) => Math.floor(e / 4) === r).length;
		return n % 4 + 2 + i.building * (o === 0 ? 3 : o === 2 ? 7 : o === 3 ? 8 : 1);
	}
	return e.mode === "ship" ? (H(e.target, [...e.cards ?? [], ...e.wild ?? []], t.ships[e.target]) ?? 0) - (e.cards?.length ?? 0) * .75 - (e.wild?.length ?? 0) * 2 : e.mode === "draw" ? n.hand.length < 4 ? 2.5 : .5 : e.mode === "take" ? n.hand.includes(t.discards[e.target].top) ? 3 : 1.5 : e.mode === "display" ? (e.cards ?? []).reduce((e, t) => e + a.bonus.reduce((e, n) => e + (k[n.id]?.includes(t) ? n.yellow ? 3 : 2 : 0), 0), 0) + .5 : 0;
}
function Qe(e = Ke) {
	return (t, n) => {
		let r = t.private?.legal ?? [];
		if (!r.length) return null;
		if (n.difficulty === "weak") return { action: r[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % r.length] };
		let i = r[0], a = -Infinity;
		for (let o of r) {
			let r = Ze(o, t.public, t.private, n.rid, e);
			r > a && (a = r, i = o);
		}
		return { action: i };
	};
}
var $e = Qe();
//#endregion
//#region src/games/trajan/fx.tsx
function et(e, t) {
	return e.piece === "goods" ? e.id >= 0 ? /* @__PURE__ */ v(Y, { good: e.id }) : /* @__PURE__ */ v("span", {
		className: "tr-fx-back",
		children: /* @__PURE__ */ v(q, { action: 0 })
	}) : e.piece === "trajan" ? /* @__PURE__ */ v(Le, { id: e.id }) : e.piece === "forum" ? /* @__PURE__ */ v(J, { id: e.id }) : e.piece === "building" ? /* @__PURE__ */ v(Ie, { id: e.id }) : e.piece === "marker" ? /* @__PURE__ */ v(K, { color: e.id }) : e.piece === "bonus" ? /* @__PURE__ */ v("img", {
		className: "tr-piece",
		src: Me(e.id, e.yellow ?? !0),
		alt: ""
	}) : e.piece === "demand" ? /* @__PURE__ */ v("img", {
		className: "tr-piece",
		src: G(4, [
			28,
			42,
			56
		][e.id]),
		alt: ""
	}) : e.piece === "double" ? /* @__PURE__ */ v("b", {
		className: "tr-fx-double",
		children: "+2"
	}) : e.piece === "arch" ? /* @__PURE__ */ v("b", {
		className: "tr-fx-arch",
		children: "⌒"
	}) : /* @__PURE__ */ v("i", {
		className: `tr-fx-person ${e.piece === "disc" ? "tr-fx-disc" : ""}`,
		style: { background: t },
		children: e.piece === "leader" ? "L" : ""
	});
}
function tt(e, t, n) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
function nt({ from: e, via: t, to: n, ms: r, children: o }) {
	let s = a(null);
	return i(() => {
		let i = s.current;
		if (!i) return;
		let a = i.animate([
			{ transform: "translate(0,0) scale(1)" },
			{
				transform: `translate(${t.x - e.x}px,${t.y - e.y}px) scale(1)`,
				offset: .45
			},
			{ transform: `translate(${n.x - e.x}px,${n.y - e.y}px) scale(${n.w / e.w})` }
		], {
			duration: r,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => a.cancel();
	}, [
		e,
		t,
		n,
		r
	]), /* @__PURE__ */ v("div", {
		ref: s,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			transformOrigin: "top left"
		},
		children: o
	});
}
var rt = {
	piece(e, t) {
		let n = {
			...e.data,
			...e.secret
		}, r = (e, n = !1) => {
			let r = t.anchor(`${n ? "whole" : "visible"}:${e}`) ?? (e.startsWith("seat:") ? t.anchor(e) : null);
			return r && r.w > 0 && r.h > 0 ? r : null;
		}, i = r(n.from, !0) ?? r(n.fromArea) ?? r(`seat:${e.rid}`), a = r(n.to, !0), o = a ?? r(n.toArea) ?? r(`seat:${e.rid}`);
		if (!i || !o) return null;
		let s = n.piece === "marker", c = t.queued ? 160 : s ? E.sow : n.piece === "trajan" ? E.tile : E.score, l = n.piece === "goods" || n.piece === "bonus", d = [
			"marker",
			"person",
			"leader",
			"disc",
			"arch",
			"double"
		].includes(n.piece), f = d ? 22 : l ? 48 : 42, p = l ? 68 : f, m = tt(i, f, p), h = tt(o, a && !d ? Math.min(o.w, f) : f, a && !d ? Math.min(o.h, p) : p), g = u[(t.member(e.rid ?? "")?.colorIndex ?? 0) % u.length].hex, _ = /* @__PURE__ */ v("span", {
			className: "tr-fx-piece",
			style: {
				width: f,
				height: p
			},
			children: et(n, g)
		}), y = n.via ? r(n.via) : null, b = n.to.startsWith("discard:") ? n.to.replace("discard:", "discard-face:") : n.to;
		return {
			ms: c,
			hide: !t.queued && a && /^(hand|display|tile|inventory|owned-bonus|permanent|worker|legion|senate-disc|leader|double|arch|bowl-marker|held-color|building|forum-slot|bonus|discard-face|demand):/.test(b) ? [b] : [],
			node: y ? /* @__PURE__ */ v(nt, {
				from: m,
				via: tt(y, f, p),
				to: h,
				ms: c,
				children: _
			}) : /* @__PURE__ */ v(ee, {
				from: m,
				to: h,
				ms: c,
				children: _
			})
		};
	},
	score(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		if (!n) return null;
		let { vp: r } = e.data;
		return {
			ms: E.score,
			node: /* @__PURE__ */ v(b, {
				at: n,
				ms: E.score,
				children: /* @__PURE__ */ y("b", {
					className: "tr-fx-points",
					children: [r > 0 ? "+" : "", r]
				})
			})
		};
	}
};
//#endregion
//#region src/games/trajan/game-over.tsx
function it({ label: e, confirm: t, run: n }) {
	let [i, a] = o(!1);
	return r(() => {
		if (!i) return;
		let e = setTimeout(() => a(!1), 3e3);
		return () => clearTimeout(e);
	}, [i]), /* @__PURE__ */ v("button", {
		type: "button",
		className: i ? "tr-result-armed danger-stripes" : void 0,
		onBlur: () => a(!1),
		onClick: () => {
			i ? (a(!1), n()) : a(!0);
		},
		children: i ? t : e
	});
}
function at(e) {
	let t = e.public, n = W(), r = g(), [i, a] = o(!1), [s, c] = o(e.myRid), l = t.players.find((e) => e.rid === s) ?? t.players[0], u = (t) => e.members.find((e) => e.rid === t)?.name ?? t;
	return /* @__PURE__ */ y("div", {
		className: "tr-result",
		children: [
			e.result.winner.length > 0 && /* @__PURE__ */ v(x, {}),
			/* @__PURE__ */ y("div", {
				className: "tr-result-review",
				inert: !i,
				"aria-hidden": !i,
				children: [/* @__PURE__ */ v(He, {
					pub: t,
					members: e.members
				}), /* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("div", {
					className: "tr-mat-owners",
					children: t.players.map((e) => /* @__PURE__ */ v("button", {
						type: "button",
						"aria-pressed": e.rid === s,
						onClick: () => c(e.rid),
						children: u(e.rid)
					}, e.rid))
				}), /* @__PURE__ */ v(We, {
					p: l,
					pub: t
				})] })]
			}),
			/* @__PURE__ */ y("section", {
				className: "tr-result-summary",
				hidden: i,
				children: [/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("h1", { children: n.finalTitle }), /* @__PURE__ */ v("button", {
					type: "button",
					"aria-label": n.review,
					onClick: () => a(!0),
					children: "⌄"
				})] }), /* @__PURE__ */ v("div", {
					className: "tr-score-scroll",
					children: /* @__PURE__ */ y("table", {
						className: "tr-score-table",
						children: [/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
							scope: "col",
							children: n.scoreItem
						}), e.result.ranking.map((t, n) => /* @__PURE__ */ y("th", {
							scope: "col",
							"data-winner": e.result.winner.includes(t) || void 0,
							children: [
								n + 1,
								". ",
								u(t)
							]
						}, t))] }) }), /* @__PURE__ */ y("tbody", { children: [/* @__PURE__ */ y("tr", {
							className: "tr-score-total",
							children: [/* @__PURE__ */ v("th", {
								scope: "row",
								children: n.totalScore
							}), e.result.ranking.map((e) => /* @__PURE__ */ v("td", { children: t.players.find((t) => t.rid === e).vp }, e))]
						}), n.scoreParts.map((n, r) => /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
							scope: "row",
							children: n
						}), e.result.ranking.map((e) => /* @__PURE__ */ v("td", { children: t.players.find((t) => t.rid === e).final[r] }, e))] }, n))] })]
					})
				})]
			}),
			/* @__PURE__ */ y("div", {
				className: "tr-result-controls",
				children: [
					i && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => a(!1),
						children: n.back
					}),
					e.onPlayAgain && /* @__PURE__ */ v(it, {
						label: r("session.result.playAgain"),
						confirm: n.confirmReplay,
						run: e.onPlayAgain
					}),
					e.onBackToLobby && /* @__PURE__ */ v(it, {
						label: r("session.result.backToLobby"),
						confirm: n.confirmLobby,
						run: e.onBackToLobby
					})
				]
			}),
			!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ v("p", {
				className: "text-center",
				children: r("session.result.waitHost")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/trajan/entry.tsx
var ot = {
	definition: Oe,
	View: Ge,
	bot: $e,
	fx: rt,
	OverView: at,
	locales: {
		zh: Ae,
		en: je
	}
};
//#endregion
export { ot as default };
