import { randomIntAt as e } from "@bgparty/sdk/core";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { DeltaNumber as a, PhaseBanner as o, PlayerStrip as s } from "@bgparty/sdk/ui";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { ConfirmButton as p } from "@bgparty/sdk/confirm-button";
import { BottomSheet as m } from "@bgparty/sdk/bottom-sheet";
import { LogSheet as h } from "@bgparty/sdk/ui/log-sheet";
import { gameAssetUrl as g } from "@bgparty/sdk/assets";
import { useFxAnchor as _ } from "@bgparty/sdk/fx/anchors";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { FlySprite as x, PulseBox as ee } from "@bgparty/sdk/fx/primitives";
import { IconBot as te, IconExpand as ne, IconLog as re } from "@bgparty/sdk/icons";
import { Confetti as ie } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as S, OptionSection as ae, OptionSwitch as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/fromage/data.ts
var w = [
	"bistro",
	"fromagerie",
	"festival",
	"villes"
], T = [
	"structure",
	"livestock",
	"fruit",
	"order"
], E = [
	"soft",
	"hard",
	"bleu"
], D = /* @__PURE__ */ "cafe.sharedWarehouse.cheeseTrolley.groceryShop.depot.diningRoom.showroom.largeBooth.feedlot.farmhouse.tradingHouse.utilityRoom.jammery.briningRoom.mouldCave.creamery.giftShop.cellar.openRange.salesOffice.packagingPlant.foundation.byre.stanchionBarn.pasteurizingChamber.makeRoom.agingRoom.fermentingChamber.distributionCentre.annex.visitorsCentre.workersQuarters".split("."), oe = [
	3,
	2,
	3,
	2,
	3,
	3,
	3,
	3,
	2,
	1,
	4,
	3,
	3,
	2,
	4,
	3,
	3,
	1,
	1,
	3,
	3,
	1,
	2,
	2,
	2,
	3,
	4,
	3,
	2,
	2,
	2,
	3
], O = [
	[
		"barn",
		"greenhouse",
		"loadingDock",
		"headquarters"
	],
	[
		"toolShed",
		"tastingRoom",
		"market",
		"specialtyCheeseShop"
	],
	[
		"gardenShed",
		"calfBarn",
		"delicatessen",
		"restaurant"
	],
	[
		"kitchen",
		"workshop",
		"spiceGarden",
		"groomingHouse"
	]
], se = [
	[
		2,
		3,
		2,
		5
	],
	[
		1,
		3,
		2,
		5
	],
	[
		1,
		3,
		1,
		5
	],
	[
		2,
		3,
		2,
		5
	]
], ce = [
	"livestock",
	"structure",
	"fruit",
	"order"
], le = [
	"fruit",
	"order",
	"livestock",
	"structure"
], ue = [
	"fromagerie",
	"festival",
	"villes",
	"bistro"
], k = [
	"order",
	"livestock",
	"structure",
	"fruit"
], de = [
	[
		"soft",
		"hard",
		"bleu"
	],
	[
		"soft",
		"soft",
		"hard"
	],
	[
		"bleu",
		"soft",
		"bleu"
	],
	[
		"bleu",
		"hard",
		"hard"
	]
], A = (e) => E[Math.floor(e / 12)], j = (e) => Math.floor(e / 4) % 3 + 1, M = (e) => e < 7 ? [
	0,
	1,
	3,
	5,
	8,
	11,
	14
][e] : 14 + (e - 6) * 4, N = (e) => e < 8 ? [
	0,
	0,
	2,
	4,
	6,
	9,
	12,
	15
][e] : 15 + (e - 7) * 5, fe = (e) => [
	0,
	0,
	2,
	5,
	9,
	14,
	20
][e] ?? 0, P = [
	15,
	17,
	18,
	19
], F = [
	99,
	10,
	8,
	6
];
function I(e, t) {
	return e === 1 ? t < 10 ? 30 : [
		31,
		32,
		34,
		36,
		38,
		40
	][Math.min(5, t - 10)] : t < 11 ? 35 : [
		36,
		37,
		38,
		39,
		41,
		43,
		45,
		47,
		50
	][Math.min(8, t - 11)];
}
var L = [
	[
		"Pont-l’Évêque",
		.42,
		.07,
		1,
		[1]
	],
	[
		"Lille",
		.61,
		.07,
		2,
		[1, 3]
	],
	[
		"Rennes",
		.12,
		.18,
		2,
		[0, 1]
	],
	[
		"Orléans",
		.29,
		.28,
		3,
		[
			0,
			1,
			2
		]
	],
	[
		"Paris",
		.49,
		.28,
		2,
		[1, 2]
	],
	[
		"Troyes",
		.68,
		.28,
		3,
		[
			1,
			2,
			3
		]
	],
	[
		"Nantes",
		.06,
		.41,
		1,
		[0]
	],
	[
		"Chavignol",
		.41,
		.41,
		1,
		[2]
	],
	[
		"Strasbourg",
		.84,
		.41,
		1,
		[3]
	],
	[
		"Tours",
		.28,
		.53,
		3,
		[
			0,
			2,
			4
		]
	],
	[
		"Dijon",
		.69,
		.53,
		3,
		[
			2,
			4,
			3
		]
	],
	[
		"Limoges",
		.43,
		.65,
		1,
		[4]
	],
	[
		"Caylus",
		.28,
		.78,
		3,
		[
			0,
			4,
			5
		]
	],
	[
		"Laguiole",
		.52,
		.78,
		2,
		[4, 5]
	],
	[
		"Lyon",
		.74,
		.78,
		3,
		[
			4,
			3,
			5
		]
	],
	[
		"Grenoble",
		.92,
		.78,
		2,
		[3, 5]
	],
	[
		"Toulouse",
		.12,
		.94,
		2,
		[0, 5]
	],
	[
		"Montpellier",
		.43,
		.94,
		1,
		[5]
	]
], R = [
	[0, 1],
	[0, 3],
	[1, 0],
	[1, 1],
	[1, 2],
	[1, 3],
	[1, 4],
	[2, 0],
	[2, 1],
	[2, 3],
	[2, 4],
	[3, 0],
	[3, 1],
	[3, 2],
	[3, 3],
	[3, 4],
	[4, 1],
	[4, 3]
], z = [
	0,
	2,
	4,
	12,
	20,
	22,
	24
];
function pe(e, t) {
	if (e === "bistro") {
		let e = Math.floor(t / 6), n = t % 6;
		return {
			age: [
				[2, 1],
				[3, 1],
				[3, 2]
			][e][n % 2],
			x: (n + .5) / 6,
			y: (e + .5) / 3,
			group: e * 3 + Math.floor(n / 2)
		};
	}
	if (e === "fromagerie") {
		let e = Math.floor(t / 3), n = t % 3;
		return {
			age: 3 - n,
			x: (n + .5) / 3,
			y: (e + .5) / 6,
			group: Math.floor(e / 3) * 3 + n
		};
	}
	if (e === "festival") {
		let [e, n] = R[t];
		return {
			age: z.filter((t) => Math.abs(Math.floor(t / 5) - e) + Math.abs(t % 5 - n) === 1).length + 1,
			x: (n + .5) / 5,
			y: (e + .5) / 5,
			group: e * 5 + n
		};
	}
	let [, n, r, i] = L[t];
	return {
		age: i,
		x: n,
		y: r,
		group: t
	};
}
var me = {
	"2-I": {
		bistro: "X X Hj H B Bf X X Bj B Sf S X X H Hf S S".split(" "),
		fromagerie: "X X X H B Hj B Sj S X X X Bj H B S Sf Hf".split(" "),
		festival: "X Sj X S Hf H S X Bf H Sf X X H Bj B X B".split(" "),
		villes: "X X Sf S H Bf H S Sj X X B H B Hj Bj X X".split(" ")
	},
	"2-II": {
		bistro: "X X H Bf Bj Hj X X Bj S S B X X H B Bf Sj".split(" "),
		fromagerie: "X X B X Bj H Sj S S H X X B Hj X S S Sf".split(" "),
		festival: "H X H Hf Bf X X B Bf Sj S X X Sj Hf H X H".split(" "),
		villes: "S S X X Sf S Hf X B Hf B X Hj B X X H B".split(" ")
	},
	"3-I": {
		bistro: "Hf H B Bj Sj Sf X X Hj B S S H H Bf B S S".split(" "),
		fromagerie: "X X X Hf B B S Sj Hj Bj Bf B H H H S S Sf".split(" "),
		festival: "Sf X S S Hj X X B Hf H Sj Bj H H Bf S B B".split(" "),
		villes: "S X Sf Sj H S Hf S H X H Bj Bf Hj B B B X".split(" ")
	},
	"3-II": {
		bistro: "X X B H Hf Sj H H B Bf Sf S S B Bf H H S".split(" "),
		fromagerie: "S S S Sj Sj B B Bj Bf X X X H H H Hj Hf Hj".split(" "),
		festival: "Bj B X B S H Hj Sj H S X B S H Bj B X Hf".split(" "),
		villes: "H S Bf B B S H S Sf Sf H Bj X Hf Bj Sf X X".split(" ")
	},
	"4-0": {
		bistro: "B Bj Hj Hf S Sf Bf B H H Sj S B B H Hf S S".split(" "),
		fromagerie: "B B B H H Hj Sf Sj S Bj Bf Bf H Hj H S S S".split(" "),
		festival: "H S Hf Sj Sf S S H Sf Bj B H H Hj Bf B B B".split(" "),
		villes: "S Sj S S H Sj H Sf Hj H Hf B B H Bj Bf B B".split(" ")
	},
	"4-I": {
		bistro: "H B Sf Hf B S Hj H Bf B Sf S S B Bj H H S".split(" "),
		fromagerie: "Hf Hj Hj H H H B B Bf B Bf B S S S Sf Sf Sj".split(" "),
		festival: "Hf H Hf H Sj Hj H S S S Sj Bj Bf S B B B Bj".split(" "),
		villes: "H B Bj B S Sj S Sf Hf H H B S Hj B S H Bj".split(" ")
	},
	"4-II": {
		bistro: "Hj H Hf Sj Bf Bf H B S Hj B S B B H H Sf S".split(" "),
		fromagerie: "Hj H H H Sj Bj S B B S Hf H Bj S Sf Bf B S".split(" "),
		festival: "S Bf B H Hf S Hj Sj B S H H Sf S B Sj B H".split(" "),
		villes: "B H Bf B Sf B B S H Sf Hj S B S Sj H Bj Hf".split(" ")
	}
};
function B(e, t) {
	return me[t][e].map((t, n) => ({
		...pe(e, n),
		type: t === "X" ? null : t[0] === "S" ? "soft" : t[0] === "H" ? "hard" : "bleu",
		fruit: t[1] === "f" ? "fruit" : t[1] === "j" ? "jam" : null
	}));
}
//#endregion
//#region src/games/fromage/meta.ts
var he = {
	id: "fromage",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"engine-building",
		"area-control",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.fromage.name",
	descKey: "games.fromage.desc",
	rulesKey: "games.fromage.rules",
	icon: "🧀",
	iconImg: "games/fromage.webp",
	rulesUrl: { en: "https://r2igames.com/rules/Fromage_Rulebook_20231208.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#39796b",
	releasedAt: "2026-10-30T21:42:23+08:00",
	search: {
		py: "nai lao shi jia",
		init: "nlsj"
	},
	hotseat: "cover",
	botDelayMs: 650
}, V = t.object({
	advanced: t.boolean().default(!1),
	bistro: t.enum([
		"I",
		"II",
		"random",
		"0"
	]).default("I"),
	fromagerie: t.enum([
		"I",
		"II",
		"random",
		"0"
	]).default("I"),
	festival: t.enum([
		"I",
		"II",
		"random",
		"0"
	]).default("I"),
	villes: t.enum([
		"I",
		"II",
		"random",
		"0"
	]).default("I"),
	soloLevel: t.int().min(1).max(4).default(1)
}).default({
	advanced: !1,
	bistro: "I",
	fromagerie: "I",
	festival: "I",
	villes: "I",
	soloLevel: 1
}), ge = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(160)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), _e = t.object({
	id: t.string(),
	kind: t.enum([
		"make",
		"gather",
		"build",
		"milk",
		"activate",
		"complete",
		"skip",
		"resource",
		"draft",
		"replace",
		"ready",
		"corp"
	]),
	spot: t.int().optional(),
	worker: t.int().optional(),
	building: t.string().optional(),
	slot: t.int().optional(),
	resource: t.enum([
		"structure",
		"livestock",
		"fruit",
		"order"
	]).optional(),
	card: t.int().optional(),
	count: t.int().optional(),
	fruit: t.enum(["fruit", "jam"]).optional()
}), ve = t.object({
	delay: t.int(),
	q: t.int(),
	spot: t.int(),
	location: t.enum([
		"hand",
		"cheese",
		"resource",
		"building"
	])
}), ye = t.object({
	rid: t.string(),
	seat: t.int(),
	board: t.int(),
	resources: t.object({
		structure: t.int(),
		livestock: t.int(),
		fruit: t.int()
	}),
	workers: t.array(ve),
	buildings: t.array(t.string()),
	built: t.array(t.boolean()),
	paid: t.array(t.int()),
	milk: t.array(t.int()),
	milkPaid: t.int(),
	fruited: t.int(),
	jam: t.int(),
	orders: t.array(t.int()),
	complete: t.array(t.int()),
	placed: t.int(),
	ready: t.boolean(),
	made: t.boolean(),
	gathered: t.boolean(),
	bonusUsed: t.boolean(),
	extraMilkUsed: t.boolean()
}), be = t.object({
	bistro: t.number(),
	fromagerie: t.number(),
	festival: t.number(),
	villes: t.number(),
	structures: t.number(),
	fruit: t.number(),
	orders: t.number(),
	unused: t.number(),
	total: t.number()
}), xe = t.object({
	phase: t.enum([
		"draft",
		"install",
		"play",
		"corp",
		"rotate",
		"done"
	]),
	round: t.int(),
	rotation: t.int(),
	extra: t.boolean(),
	finalRound: t.boolean(),
	players: t.array(ye),
	venues: t.array(t.enum([
		"bistro",
		"fromagerie",
		"festival",
		"villes"
	])),
	resources: t.array(t.enum([
		"structure",
		"livestock",
		"fruit",
		"order"
	])),
	layouts: t.record(t.string(), t.string()),
	cheeses: t.record(t.string(), t.array(t.string().nullable())),
	customers: t.array(t.int()),
	corporation: t.object({
		level: t.int(),
		used: t.int(),
		fruit: t.int(),
		scored: t.array(t.int()),
		card: t.int().nullable(),
		left: t.int(),
		lastAge: t.int()
	}),
	deckCount: t.int(),
	draftRound: t.int(),
	scores: t.record(t.string(), be),
	corpScore: t.number(),
	log: t.array(t.object({
		round: t.int(),
		rid: t.string(),
		kind: t.string(),
		venue: t.string().optional(),
		count: t.int().optional(),
		building: t.string().optional()
	}))
}), Se = t.object({
	choices: t.array(_e),
	draft: t.array(t.string()),
	kept: t.array(t.string()),
	pending: t.string().nullable()
}), Ce = {
	rotate: 700,
	corporation: 500
}, we = () => ({
	delay: 0,
	q: -1,
	spot: -1,
	location: "hand"
}), H = (e, t) => (t.seat - e.rotation + 4) % 4, Te = (e, t) => e.venues[H(e, t)], U = (e, t) => e.buildings.some((n, r) => n === t && e.built[r]), Ee = (e, t) => e.built[t] && e.buildings[t] === O[e.board][t], De = (e) => e.resources.structure + e.resources.livestock + e.resources.fruit + e.orders.length;
function W(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function G(e, t, n, r, i, a = 1) {
	e.push({
		kind: "move",
		rid: t,
		data: {
			from: n,
			to: r,
			sprite: i,
			count: a
		},
		...e.length ? { with: !0 } : {}
	});
}
function K(e, t, n, r = {}) {
	e.log.push({
		round: e.round,
		rid: t.rid,
		kind: n,
		...r
	});
}
function Oe(e) {
	return !e.deck.length && e.discard.length && (e.deck = W(e, e.discard), e.discard = []), e.deck.shift() ?? null;
}
function q(e, t, n, r, i) {
	if (!(r <= 0)) {
		if (Ee(t, 1) && n === le[t.board] && !t.bonusUsed && (t.bonusUsed = !0, r++), n === "order") for (let n = 0; n < r; n++) {
			let n = Oe(e);
			n !== null && (t.orders.push(n), G(i, t.rid, "deck", `order:${t.rid}:${n}`, "order"));
		}
		else t.resources[n] += r, G(i, t.rid, `supply:${n}`, `resource:${t.rid}:${n}`, n, r);
	}
}
function ke(e, t) {
	return t === "order" || e.resources[t] < 1 ? !1 : (e.resources[t]--, !0);
}
function Ae(e, t, n) {
	e.tasks[t.rid].push(n);
}
function je(e, t, n, r) {
	t.orders = t.orders.filter((e) => e !== n), t.complete.push(n), G(r, t.rid, `order:${t.rid}:${n}`, `completed:${t.rid}`, "order"), U(t, "salesOffice") && q(e, t, "livestock", 1, r), K(e, t, "complete", { count: t.complete.length });
}
function Me(e, t) {
	let n = e.buildings[t], r = D.indexOf(n), i = r < 0 ? se[e.board][t] : oe[r];
	return Math.max(0, i - (r >= 0 && n !== "foundation" && U(e, "foundation") ? 1 : 0));
}
function Ne(e, t, n) {
	let r = Te(e, t), i = B(r, e.layouts[r])[n];
	return t.placed < 15 && !!i?.type && e.cheeses[r][n] === null && (!i.fruit || t.resources.fruit > 0);
}
function Pe(e, t, n, r, i) {
	let a = Te(e, t), o = H(e, t), s = B(a, e.layouts[a])[n], c = t.orders.filter((e) => A(e) === s.type && j(e) === s.age);
	if (e.cheeses[a][n] = t.rid, t.placed++, G(i, t.rid, `cheeses:${t.rid}`, `cheese:${a}:${n}`, "cheese"), r !== null && (t.workers[r] = {
		delay: s.age,
		q: o,
		spot: n,
		location: "cheese"
	}, t.made = !0, G(i, t.rid, `worker:${t.rid}:${r}`, `worker-board:${t.rid}:${r}`, `worker${r}`)), s.fruit && (t.resources.fruit--, t[s.fruit === "fruit" ? "fruited" : "jam"]++, G(i, t.rid, `resource:${t.rid}:fruit`, `spent:${t.rid}:${s.fruit}`, "fruit")), c.length && Ae(e, t, {
		kind: "order",
		cards: c,
		extra: !1
	}), a === "fromagerie" && n >= 9) {
		let n = s.age, r = U(t, "groceryShop") ? 2 : 1;
		for (let i = 0; i < r; i++) Ae(e, t, {
			kind: "resource",
			left: n === 3 ? 2 : 1,
			excluded: [],
			trade: n === 1
		});
	}
	Ee(t, 2) && a === ue[t.board] && q(e, t, k[t.board], 1, i), s.fruit && s.type === "soft" && U(t, "creamery") && q(e, t, "fruit", 1, i), s.fruit && U(t, "packagingPlant") && q(e, t, "order", 1, i), s.age === 1 && U(t, "makeRoom") && q(e, t, "order", 1, i), s.age === 2 && U(t, "fermentingChamber") && q(e, t, "fruit", 1, i), s.age === 3 && U(t, "agingRoom") && q(e, t, "livestock", 1, i), a === "bistro" && s.fruit && U(t, "diningRoom") && t.resources.fruit > 0 && Ae(e, t, { kind: "dining" }), t.placed === 15 && (e.finalRound = !0), K(e, t, "make", {
		venue: a,
		count: s.age
	});
}
function Fe(e, t, n = !1) {
	for (let r of e.players) if (r.ready = e.extra && !U(r, "workersQuarters"), r.made = !1, r.gathered = !1, r.bonusUsed = !1, !n) for (let e = 0; e < 3; e++) r.workers[e].delay > 0 && (r.workers[e].delay--, r.workers[e].delay || (G(t, r.rid, `worker-board:${r.rid}:${e}`, `worker:${r.rid}:${e}`, `worker${e}`), r.workers[e] = we()));
	if (e.players.length === 1 && !e.extra) {
		e.phase = "corp";
		let t = e.corporation;
		t.card = null, t.left = t.used >= F[t.level - 1] ? 2 : 1, t.lastAge = 0;
	} else e.phase = "play";
}
function Ie(t, n, r) {
	let i = V.parse(t), a = {
		phase: i.advanced ? "draft" : "play",
		round: 1,
		rotation: 0,
		extra: !1,
		finalRound: !1,
		players: [],
		venues: [],
		resources: [],
		layouts: {},
		cheeses: {},
		customers: [],
		corporation: {
			level: i.soloLevel,
			used: 0,
			fruit: 0,
			scored: [],
			card: null,
			left: 0,
			lastAge: 0
		},
		draftRound: 1,
		log: [],
		seed: r,
		cursor: 0,
		deck: [],
		discard: [],
		draftDeck: [],
		draft: {},
		kept: {},
		picks: {},
		tasks: {}
	};
	a.venues = W(a, w), a.resources = W(a, T), a.deck = W(a, Array.from({ length: 36 }, (e, t) => t)), a.draftDeck = W(a, D), a.customers = W(a, [
		1,
		1,
		2,
		2,
		3,
		3
	]);
	let o = W(a, [
		0,
		1,
		2,
		3
	]);
	for (let t of w) {
		let r = i[t], o = r === "random" ? e(a.seed, a.cursor++, 2) ? "I" : "II" : r === "0" && n.length < 4 ? "I" : r;
		a.layouts[t] = `${Math.max(2, n.length)}-${o}`, a.cheeses[t] = Array(18).fill(null);
	}
	let s = [];
	return n.forEach((e, t) => {
		let r = o[t], c = n.length === 2 ? t * 2 : t, l = {
			rid: e,
			seat: c,
			board: r,
			resources: {
				structure: 0,
				livestock: 0,
				fruit: 0
			},
			workers: E.map(we),
			buildings: [...O[r]],
			built: [
				!1,
				!1,
				!1,
				!1
			],
			paid: [
				0,
				0,
				0,
				0
			],
			milk: [
				0,
				0,
				0,
				0
			],
			milkPaid: 0,
			fruited: 0,
			jam: 0,
			orders: [],
			complete: [],
			placed: 0,
			ready: !1,
			made: !1,
			gathered: !1,
			bonusUsed: !1,
			extraMilkUsed: !1
		};
		a.players.push(l), a.tasks[e] = [], a.kept[e] = [], a.draft[e] = i.advanced ? a.draftDeck.splice(0, 4) : [], q(a, l, a.resources[(c + 1) % 4], 2, s), q(a, l, a.resources[(c + 2) % 4], 1, s);
	}), i.advanced || Fe(a, s, !0), {
		state: a,
		fx: s
	};
}
function J(e, t) {
	e.push({
		...t,
		id: JSON.stringify(t)
	});
}
function Le(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n || n.ready || e.phase === "done" || e.phase === "rotate") return [];
	let r = [];
	if (e.phase === "draft") {
		if (!(t in e.picks)) for (let n of e.draft[t]) J(r, {
			kind: "draft",
			building: n
		});
		return r;
	}
	if (e.phase === "install") {
		for (let n of e.kept[t]) for (let e = 0; e < 4; e++) J(r, {
			kind: "replace",
			building: n,
			slot: e
		});
		for (let e = 0; e < 4; e++) n.buildings[e] !== O[n.board][e] && J(r, {
			kind: "replace",
			building: O[n.board][e],
			slot: e
		});
		return J(r, { kind: "ready" }), r;
	}
	if (e.phase === "corp") {
		let t = e.corporation;
		if (t.card === null || t.used >= P[t.level - 1]) return r;
		let i = Te(e, n);
		return B(i, e.layouts[i]).forEach((n, a) => {
			n.type === A(t.card) && n.age === j(t.card) && e.cheeses[i][a] === null && J(r, {
				kind: "corp",
				spot: a
			});
		}), r;
	}
	let i = e.tasks[t][0];
	if (i) {
		if (i.kind === "order") {
			for (let e of i.cards) n.orders.includes(e) && J(r, {
				kind: "complete",
				card: e
			});
			return J(r, { kind: "skip" }), r;
		}
		if (i.kind === "dining") {
			if (n.resources.fruit > 0) for (let e of ["fruit", "jam"]) J(r, {
				kind: "activate",
				building: "diningRoom",
				fruit: e
			});
			return J(r, { kind: "skip" }), r;
		}
		if (i.trade) for (let e of T) if (e === "order") for (let t of n.orders) J(r, {
			kind: "resource",
			resource: e,
			card: t,
			count: -1
		});
		else n.resources[e] > 0 && J(r, {
			kind: "resource",
			resource: e,
			count: -1
		});
		else for (let e of T) i.excluded.includes(e) || J(r, {
			kind: "resource",
			resource: e
		});
		return J(r, { kind: "skip" }), r;
	}
	let a = Te(e, n), o = H(e, n), s = n.workers.flatMap((e, t) => e.delay === 0 ? [t] : []);
	for (let e = 0; e < 4; e++) !n.built[e] && n.resources.structure >= Me(n, e) && J(r, {
		kind: "build",
		slot: e,
		building: n.buildings[e]
	});
	for (let t = 0; t < 18; t++) if (Ne(e, n, t)) {
		let i = B(a, e.layouts[a])[t];
		if (!n.made) for (let e of s) (E[e] === i.type || e === 1 && U(n, "briningRoom")) && J(r, {
			kind: "make",
			spot: t,
			worker: e
		});
		for (let e = 0; e < 4; e++) {
			let a = e + 2 - +!!U(n, "byre"), o = n.milk[e] === 1 && U(n, "pasteurizingChamber") && !n.extraMilkUsed;
			(n.milk[e] === 0 || o) && n.resources.livestock >= a && (e === 3 || i.age === e + 1 && (i.type === de[n.board][e] || U(n, "stanchionBarn"))) && J(r, {
				kind: "milk",
				spot: t,
				slot: e
			});
		}
	}
	if (!n.gathered) for (let t of s) for (let n = 1; n <= 3; n++) {
		let i = e.players.some((e) => e.workers.some((e) => e.location === "resource" && e.q === o && e.spot === n && e.delay > 0)), a = e.corporation, s = e.players.length === 1 && a.level === 4 && (a.lastAge === 2 && n === 2 || a.lastAge === 3 && n === 3);
		!i && !s && J(r, {
			kind: "gather",
			worker: t,
			count: n,
			resource: e.resources[o]
		});
	}
	if (Ee(n, 0)) for (let e of s) J(r, {
		kind: "activate",
		building: n.buildings[0],
		worker: e,
		resource: ce[n.board]
	});
	if (U(n, "feedlot") && n.resources.fruit && J(r, {
		kind: "activate",
		building: "feedlot"
	}), U(n, "farmhouse")) for (let e of n.orders) J(r, {
		kind: "activate",
		building: "farmhouse",
		card: e
	});
	if (U(n, "tradingHouse") && n.resources.structure) for (let e of T) e !== "structure" && J(r, {
		kind: "activate",
		building: "tradingHouse",
		resource: e
	});
	if (U(n, "utilityRoom") && s.includes(2)) for (let e of T) J(r, {
		kind: "activate",
		building: "utilityRoom",
		worker: 2,
		resource: e
	});
	if (U(n, "jammery") && s.includes(1) && n.resources.fruit && J(r, {
		kind: "activate",
		building: "jammery",
		worker: 1
	}), U(n, "giftShop") && s.includes(0)) for (let e of n.orders) J(r, {
		kind: "activate",
		building: "giftShop",
		worker: 0,
		card: e
	});
	if (U(n, "mouldCave") && n.workers[2].delay > 0 && ["resource", "cheese"].includes(n.workers[2].location) && n.workers[2].q !== o) for (let e of n.orders) J(r, {
		kind: "activate",
		building: "mouldCave",
		card: e
	});
	return J(r, { kind: "ready" }), r;
}
function Re(e, t, n) {
	if (e.picks[t.rid] = n, e.players.length === 1) e.kept[t.rid].push(n), e.draft[t.rid] = e.draftDeck.splice(0, 4 - e.draftRound), e.picks = {}, e.draftRound++;
	else if (e.players.every((t) => t.rid in e.picks)) {
		let t = e.players.map((t) => (e.kept[t.rid].push(e.picks[t.rid]), e.draft[t.rid].filter((n) => n !== e.picks[t.rid])));
		e.players.forEach((n, r) => e.draft[n.rid] = t[(r + e.players.length - 1) % e.players.length]), e.picks = {}, e.draftRound++;
	}
	e.draftRound === 5 && (e.phase = "install", e.players.forEach((e) => e.ready = !1));
}
function ze(e, t, n, r) {
	if (n.kind === "draft") {
		Re(e, t, n.building);
		return;
	}
	if (n.kind === "replace") {
		let i = t.buildings[n.slot];
		t.buildings[n.slot] = n.building, e.kept[t.rid] = e.kept[t.rid].filter((e) => e !== n.building), D.includes(i) && e.kept[t.rid].push(i), G(r, t.rid, `draft:${t.rid}`, `building:${t.rid}:${n.slot}`, "structure");
		return;
	}
	if (n.kind === "ready") {
		t.ready = !0, e.players.every((e) => e.ready) && (e.phase === "install" ? (e.players.forEach((e) => e.ready = !1), Fe(e, r, !0)) : e.phase = "rotate");
		return;
	}
	if (n.kind === "corp") {
		let i = Te(e, t), a = e.corporation, o = B(i, e.layouts[i])[n.spot];
		e.cheeses[i][n.spot] = "$corporation", a.used++, a.level >= 3 && o.fruit && a.fruit++, e.discard.push(a.card), a.card = null, a.left--, a.used === P[a.level - 1] && (e.finalRound = !0), G(r, t.rid, "corporation", `cheese:${i}:${n.spot}`, "corporation"), K(e, t, "corp", { venue: i });
		return;
	}
	let i = e.tasks[t.rid][0];
	if (n.kind === "skip") {
		e.tasks[t.rid].shift();
		return;
	}
	if (n.kind === "complete") {
		e.tasks[t.rid].shift(), je(e, t, n.card, r), i?.kind === "order" && !i.extra && Te(e, t) === "villes" && U(t, "depot") && t.orders.length && e.tasks[t.rid].unshift({
			kind: "order",
			cards: [...t.orders],
			extra: !0
		});
		return;
	}
	if (n.kind === "resource" && i?.kind === "resource") {
		n.count === -1 ? (n.resource === "order" ? (t.orders = t.orders.filter((e) => e !== n.card), e.deck.push(n.card)) : ke(t, n.resource), i.trade = !1) : (q(e, t, n.resource, 1, r), i.left--, i.excluded.push(n.resource), i.left === 0 && e.tasks[t.rid].shift());
		return;
	}
	if (n.kind === "build") {
		let i = Me(t, n.slot);
		t.resources.structure -= i, t.paid[n.slot] = i, t.built[n.slot] = !0, G(r, t.rid, `resource:${t.rid}:structure`, `building:${t.rid}:${n.slot}`, "structure", i), D.includes(n.building) && U(t, "cellar") && q(e, t, "order", 1, r), K(e, t, "build", { building: n.building });
		return;
	}
	if (n.kind === "make") {
		Pe(e, t, n.spot, n.worker, r);
		return;
	}
	if (n.kind === "milk") {
		let i = n.slot + 2 - +!!U(t, "byre");
		t.milk[n.slot] === 1 && (t.extraMilkUsed = !0), t.resources.livestock -= i, t.milkPaid += i, t.milk[n.slot]++, G(r, t.rid, `resource:${t.rid}:livestock`, `milk:${t.rid}:${n.slot}`, "livestock", i), Pe(e, t, n.spot, null, r), U(t, "openRange") && q(e, t, "fruit", 1, r);
		return;
	}
	if (n.kind === "gather") {
		let i = H(e, t);
		t.workers[n.worker] = {
			delay: n.count,
			q: i,
			spot: n.count,
			location: "resource"
		}, t.gathered = !0, G(r, t.rid, `worker:${t.rid}:${n.worker}`, `worker-board:${t.rid}:${n.worker}`, `worker${n.worker}`), q(e, t, n.resource, n.count + (n.count === 3 && U(t, "annex") ? 1 : 0), r), K(e, t, "gather", { count: n.count });
		return;
	}
	if (n.kind === "activate") {
		let i = n.building;
		if (i === "diningRoom") {
			t.resources.fruit--, t[n.fruit === "fruit" ? "fruited" : "jam"]++, e.tasks[t.rid].shift(), G(r, t.rid, `resource:${t.rid}:fruit`, `spent:${t.rid}:${n.fruit}`, "fruit"), U(t, "packagingPlant") && q(e, t, "order", 1, r);
			return;
		}
		n.worker !== void 0 && (t.workers[n.worker] = {
			delay: 1,
			q: -1,
			spot: t.buildings.indexOf(i),
			location: "building"
		}, G(r, t.rid, `worker:${t.rid}:${n.worker}`, `worker-board:${t.rid}:${n.worker}`, `worker${n.worker}`)), (i === t.buildings[0] && Ee(t, 0) || i === "utilityRoom") && q(e, t, n.resource, 1, r), i === "feedlot" && (t.resources.fruit--, q(e, t, "livestock", 1, r)), i === "tradingHouse" && (t.resources.structure--, q(e, t, n.resource, 1, r)), i === "jammery" && (t.resources.fruit--, t.jam++, G(r, t.rid, `resource:${t.rid}:fruit`, `spent:${t.rid}:jam`, "fruit"), U(t, "packagingPlant") && q(e, t, "order", 1, r)), i === "giftShop" && je(e, t, n.card, r), (i === "farmhouse" || i === "mouldCave") && (t.orders = t.orders.filter((e) => e !== n.card), e.deck.push(n.card), G(r, t.rid, `order:${t.rid}:${n.card}`, "deck", "order"), i === "farmhouse" ? q(e, t, "structure", 1, r) : (G(r, t.rid, `worker-board:${t.rid}:2`, `worker:${t.rid}:2`, "worker2"), t.workers[2] = we())), K(e, t, "activate", { building: i });
	}
}
function Be(e, t) {
	if (e.phase === "rotate") {
		if (e.finalRound) {
			if (e.extra || !e.players.some((e) => U(e, "workersQuarters"))) {
				e.phase = "done";
				for (let n of e.players) for (let e = 0; e < 3; e++) n.workers[e].delay > 0 && (G(t, n.rid, `worker-board:${n.rid}:${e}`, `worker:${n.rid}:${e}`, `worker${e}`), n.workers[e] = we());
				return;
			}
			e.extra = !0;
		}
		e.rotation = (e.rotation + 1) % 4, e.round++, Fe(e, t), t.push({
			kind: "rotate",
			data: { rotation: e.rotation }
		});
		return;
	}
	if (e.phase === "corp") {
		let n = e.corporation, r = e.players[0];
		if (n.card !== null) {
			n.scored.push(n.card), n.card = null, n.left--, K(e, r, "corpOrder"), G(t, r.rid, "corp-order", "corporation", "order");
			return;
		}
		if (n.left === 0) {
			e.phase = "play";
			return;
		}
		if (n.card = Oe(e), n.card === null) {
			n.left = 0, e.phase = "play";
			return;
		}
		n.lastAge = j(n.card), G(t, r.rid, "deck", "corp-order", "order");
	}
}
function Ve(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "rotate" && (e.phase !== "corp" || Le(e, e.players[0].rid).length)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = [];
		return Be(t, n), {
			state: t,
			fx: n
		};
	}
	let r = Le(e, n.by).find((e) => e.id === t.id);
	if (!r) return { code: "games.fromage.errChoice" };
	let i = structuredClone(e), a = i.players.find((e) => e.rid === n.by), o = [];
	return ze(i, a, r, o), {
		state: i,
		fx: o
	};
}
function He(e, t) {
	let n = (n) => e.cheeses[n].map((e, n) => e === t.rid ? n : -1).filter((e) => e >= 0), r = n("bistro"), i = B("bistro", e.layouts.bistro), a = Array.from({ length: 9 }, (e, t) => r.filter((e) => i[e].group === t).length === 2).filter(Boolean).length, o = [
		[
			0,
			2,
			4
		],
		[
			1,
			3,
			5
		],
		[
			2,
			4,
			6
		],
		[
			3,
			6,
			9
		]
	][Math.min(3, a)], s = r.reduce((e, t) => e + o[i[t].age - 1], 0);
	U(t, "cafe") && (s += new Set(r.map((e) => i[e].group)).size * 2);
	let c = n("fromagerie"), l = B("fromagerie", e.layouts.fromagerie), u = fe(new Set(c.map((e) => l[e].group)).size) + c.filter((e) => e < 9).reduce((e, n) => e + l[n].age * (U(t, "showroom") ? 2 : 1), 0), d = /* @__PURE__ */ new Set([...z, ...n("festival").map((e) => R[e][0] * 5 + R[e][1])]), f = 0, p = /* @__PURE__ */ new Set();
	for (let e of d) {
		if (p.has(e)) continue;
		let t = [e];
		p.add(e);
		for (let e = 0; e < t.length; e++) for (let n of d) !p.has(n) && Math.abs(Math.floor(n / 5) - Math.floor(t[e] / 5)) + Math.abs(n % 5 - t[e] % 5) === 1 && (p.add(n), t.push(n));
		f += N(t.length);
	}
	let m = 0;
	if (U(t, "cheeseTrolley") && (m += z.filter((e) => n("festival").some((t) => {
		let [n, r] = R[t];
		return Math.abs(n - Math.floor(e / 5)) + Math.abs(r - e % 5) === 1;
	})).length * 2), U(t, "largeBooth")) {
		let e = !1;
		for (let t = 0; t < 4; t++) for (let n = 0; n < 4; n++) [
			t * 5 + n,
			t * 5 + n + 1,
			(t + 1) * 5 + n,
			(t + 1) * 5 + n + 1
		].every((e) => d.has(e)) && (e = !0);
		e && (m += 7);
	}
	let h = 0;
	for (let n = 0; n < 6; n++) {
		let r = [...e.players.map((e) => e.rid), ...e.players.length === 1 ? ["$corporation"] : []].map((t) => ({
			rid: t,
			n: e.cheeses.villes.filter((e, r) => e === t && L[r][4].includes(n)).length
		})), i = Math.max(...r.map((e) => e.n)), a = r.filter((e) => e.n === i);
		i > 0 && a.some((e) => e.rid === t.rid) && (a.length === 1 ? h += e.customers[n] + (e.players.length === 4 ? 6 : e.players.length === 3 ? 4 : 2) : (h += e.players.length === 4 ? 3 : e.players.length === 3 ? 2 : 0, U(t, "sharedWarehouse") && (m += 2)));
	}
	Ee(t, 3) && (m += t.board === 0 ? t.paid.reduce((e, t) => e + t, 0) : t.board === 1 ? t.fruited + t.jam : t.board === 2 ? t.complete.length : t.milkPaid), U(t, "distributionCentre") && w.every((e) => n(e).length >= 3) && (m += 6), U(t, "visitorsCentre") && De(t) === 0 && (m += 5);
	let g = t.fruited * t.jam, _ = M(t.complete.length), v = Math.floor(De(t) / 2);
	return u = Math.max(0, u), {
		bistro: s,
		fromagerie: u,
		festival: f,
		villes: h,
		structures: m,
		fruit: g,
		orders: _,
		unused: v,
		total: s + u + f + h + m + g + _ + v
	};
}
function Ue(e) {
	let t = e.corporation, n = I(t.level, t.used) + t.scored.length * 3;
	for (let t = 0; t < 6; t++) {
		let r = (n) => e.cheeses.villes.filter((e, r) => e === n && L[r][4].includes(t)).length;
		r("$corporation") > r(e.players[0].rid) && (n += e.customers[t] + 2);
	}
	if (t.level >= 3) {
		let e = Math.floor(t.fruit / 2);
		n += e < 5 ? [
			0,
			1,
			3,
			6,
			10
		][e] : 10 + (e - 4) * 5;
	}
	return n;
}
function We(e, t) {
	return {
		public: {
			phase: e.phase,
			round: e.round,
			rotation: e.rotation,
			extra: e.extra,
			finalRound: e.finalRound,
			players: e.players,
			venues: e.venues,
			resources: e.resources,
			layouts: e.layouts,
			cheeses: e.cheeses,
			customers: e.customers,
			corporation: e.corporation,
			deckCount: e.deck.length,
			draftRound: e.draftRound,
			scores: Object.fromEntries(e.players.map((t) => [t.rid, He(e, t)])),
			corpScore: e.players.length === 1 ? Ue(e) : 0,
			log: e.log
		},
		private: {
			choices: Le(e, t),
			draft: e.draft[t] ?? [],
			kept: e.kept[t] ?? [],
			pending: e.tasks[t]?.[0]?.kind ?? null
		}
	};
}
function Ge(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t.rid, He(e, t).total])), n = [...e.players].sort((e, n) => t[n.rid] - t[e.rid] || n.placed - e.placed).map((e) => e.rid), r = e.players.find((e) => e.rid === n[0]), i = n.filter((n) => t[n] === t[r.rid] && e.players.find((e) => e.rid === n).placed === r.placed);
	return e.players.length === 1 && (t[r.rid] < Ue(e) || t[r.rid] === Ue(e) && r.placed < e.corporation.used) && (i = []), {
		phase: "done",
		scores: t,
		ranking: n,
		winner: i
	};
}
var Ke = {
	meta: he,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ge,
		config: V,
		publicView: xe,
		privateView: Se
	},
	setup: Ie,
	reduce: Ve,
	viewFor: We,
	status: Ge,
	nextTickIn: (e) => e.phase === "rotate" ? Ce.rotate : e.phase === "corp" && !Le(e, e.players[0].rid).length ? Ce.corporation : null
}, qe = {
	name: "奶酪世家",
	desc: "经营法式奶酪工坊，随着转盘安排熟成、拓展市场与订单。",
	rules: "目标：\n经营自己的奶酪工坊，在餐酒馆、奶酪店、节庆和城市四个场地放置奶酪，结合建筑、水果和订单获得最多声望。采用第二印基础版，支持1–4人；本版本未包含《Formaggio》扩展。\n准备：\n每名玩家获得15枚奶酪、一名软质工人、一名硬质工人、一名蓝纹工人，以及一块随机分配的玩家板。转盘的场地与资源随机配置。每名玩家从左侧资源区领取两份资源，从对面资源区领取一份资源。1–2人、3人、4人使用各自插板；I、II可分别配置，0面仅供4人使用。选择高级建筑时，每名玩家从4块建筑板块中保留1块，将其余板块向左传递；重复这个过程，直到每名玩家保留4块；单人依次从新抽的4、3、2、1片中各留1片。可用保留的高级建筑替换任意默认建筑，也可保留默认建筑。\n回合：\n所有玩家同时操作自己面前的象限。每回合至多派一位工人制酪、派一位工人采集资源，两者顺序任意，也可不做。可随时建造、挤奶或使用已建成建筑。所有人完成后，转盘顺时针旋转90度，进入下一回合。\n· 制酪：选择可用工人，再选择当前场地的空格，类型须与工人一致。在该格放一枚奶酪，工人等待该格标示的1、2或3回合后收回。每次放置时可完成一张类型与熟成都匹配的已有订单；不能追溯完成新抽到的订单。在果味或果酱格放置奶酪时，必须支付一份水果，将其移至对应已用区。\n· 采集：可用任意工人占据当前资源的空置1、2或3位，立即获得相应数量资源，等待相应回合后收回。已被工人占据的资源位不能使用。\n· 挤奶：支付2份、3份、4份或5份牲畜资源，选择个人板上尚未用过的挤奶位，立即在当前场地放置符合其类型、熟成要求的额外奶酪，不派工人，不占用普通制酪行动；果味或果酱格仍须支付水果。每个挤奶位通常一局只能使用一次。\n· 建筑：支付建筑资源后建成并启用对应能力。能力可在条件满足时使用，默认第二能力每回合只额外获得一次资源。高级建筑的效果见建筑详情。放置时以已建成的能力处理触发，事件发生后才建成的能力不能追溯生效。\n场地计分：\n餐酒馆：每完整占据一张双人桌，所有自家奶酪的分值都会提高。按完整占据的双人桌数量计分：\n· 没有完整占据双人桌时，每枚铜奶酪获得 0 分，银奶酪获得 2 分，金奶酪获得 4 分。\n· 完整占据一张双人桌时，每枚铜奶酪获得 1 分，银奶酪获得 3 分，金奶酪获得 5 分。\n· 完整占据两张双人桌时，每枚铜奶酪获得 2 分，银奶酪获得 4 分，金奶酪获得 6 分。\n· 完整占据至少三张双人桌时，每枚铜奶酪获得 3 分，银奶酪获得 6 分，金奶酪获得 9 分。\n奶酪店：占据一至六个不同货架时，依次获得 0 分、2 分、5 分、9 分、14 分和 20 分。各位置另有以下奖励：\n· 上半货架：每枚铜奶酪另获得 1 分，每枚银奶酪另获得 2 分，每枚金奶酪另获得 3 分。\n· 下半货架的铜位：可以弃置一份资源，换取任意一份资源。\n· 下半货架的银位：获得任意一份资源。\n· 下半货架的金位：获得两份种类不同的资源。\n节庆：自家奶酪与免费试吃点按上下左右相邻形成连通组；不同玩家的奶酪不能连接。每组1–7枚分别获得0、2、4、6、9、12、15分，此后，连通组每增加一枚奶酪，再获得 5 分。\n城市：每枚奶酪影响其接触的所有区域。每区影响最多者获得该区客户分：一至两人游戏中，各区域的客户分为 3 分、4 分或 5 分；三人游戏中为 5 分、6 分或 7 分；四人游戏中为 7 分、8 分或 9 分，具体数值以区域标示为准。影响力并列最多时，一至两人游戏的并列玩家各获得 0 分，三人游戏各获得 2 分，四人游戏各获得 3 分。\n其他计分与结束：\n· 将已用果味水果的数量乘以已用果酱水果的数量，获得等于乘积的分数。\n· 完成1–6张订单分别获得1、3、5、8、11、14分，此后每多完成一张订单，再获得 4 分。\n· 每两份闲置资源获得1分，未完成订单也算闲置资源。\n· 另计所有已建成建筑的终局分。\n任一玩家放完15枚奶酪后，本回合全员完成即结束。工人是否熟成不影响奶酪计分。工人宿舍允许拥有者在转盘额外旋转一次后多行动一回合。总分最高者获胜，平分时放置奶酪更多者获胜，仍平则共享胜利。\n单人公司：\n公司先抽订单，由玩家在当前场地选择类型、熟成匹配的空格放置公司奶酪，不支付水果；没有匹配空格或奶酪时，公司保留该订单并在终局每张获得3分。\n· 第一至第四难度的公司分别有 15 枚、17 枚、18 枚和 19 枚奶酪，其基础声望随已放奶酪的数量按公司板提高。公司只争夺城市客户，不计算其他场地分，各区域的客户分为3分、4分或5分，具体以区域标示为准。\n· 第二难度放置第 10 枚奶酪、第三难度放置第 8 枚奶酪、第四难度放置第 6 枚奶酪后，公司从下一回合开始每回合抽取两张订单。\n· 第三难度起，公司在果味或果酱格放置奶酪时获得水果，累计获得 2 份、4 份、6 份或 8 份水果时，分别获得 1 分、3 分、6 分或 10 分；此后每多获得 2 份水果，再获得 5 分。\n· 在第四难度中，若公司最后抽到银色订单，本回合封锁标有 2 的资源位；若最后抽到金色订单，则封锁标有 3 的资源位。\n玩家或公司用完奶酪都会触发本回合结束；比较总分，再比较已放奶酪数，仍平时共享胜利。",
	round: "第 {{n}} 回合",
	extra: "额外回合",
	final: "最后一回合",
	draft: "选择一栋高级建筑",
	install: "安排工坊建筑",
	play: "制作与采集",
	corp: "为公司选择匹配的空格",
	rotate: "转盘旋转中",
	done: "对局结束",
	wait: "等待其他玩家完成",
	ready: "完成回合",
	confirmReady: "确认完成回合",
	skip: "跳过",
	build: "建造",
	use: "使用",
	replace: "替换此处",
	keep: "完成安排",
	chooseSlot: "选择要替换的建筑",
	orders: "未完成订单",
	complete: "完成订单",
	completed: "已完成 {{n}} 单",
	cheeses: "奶酪 {{n}}/15",
	workers: "工人",
	milk: "挤奶",
	available: "可用",
	returns: "{{n}} 回合后收回",
	current: "当前象限",
	viewing: "查看工坊",
	cost: "费用 {{n}}",
	score: "声望",
	corpName: "奶酪公司",
	company: "公司声望 {{n}}",
	level: "公司难度",
	advanced: "高级建筑轮抽",
	layout: "场地插板",
	random: "随机",
	default: "默认建筑",
	buildingDetails: "建筑详情",
	close: "关闭",
	chooseResource: "选择要获得的资源",
	trade: "选择要交出的资源",
	chooseOrder: "选择要完成的订单",
	dining: "额外使用一水果",
	fruited: "果味",
	jam: "果酱",
	unused: "闲置资源",
	structures: "建筑",
	fruitScore: "水果",
	orderScore: "订单",
	total: "总分",
	ledger: "工坊年度账簿",
	winner: "{{names}} 获胜",
	sharedWinner: "{{names}} 共享胜利",
	companyWins: "奶酪公司获胜",
	reviewHide: "收起结算并回看盘面",
	reviewShow: "查看结算",
	confirmAgain: "确认再来一局",
	confirmLobby: "确认返回大厅",
	errChoice: "当前无法执行此行动，请重新选择。",
	target: "{{type}}，熟成 {{age}} 回合{{fruit}}",
	fruitNeed: "，需要水果",
	occupied: "{{name}} 的奶酪",
	gather: "获得 {{n}} 份{{resource}}",
	make: "制作奶酪",
	draftPicked: "已选定，等待其他玩家",
	allVenues: "全部场地",
	empty: "暂无",
	free: "免费试吃",
	influence: "区域 {{n}}：{{points}} 分",
	actionLog: "对局记录",
	selectWorker: "选择可用工人",
	soft: "软质",
	hard: "硬质",
	bleu: "蓝纹",
	structure: "建筑资源",
	livestock: "牲畜",
	fruit: "水果",
	order: "订单",
	bistro: "餐酒馆",
	fromagerie: "奶酪店",
	festival: "节庆",
	villes: "城市",
	logMake: "在{{venue}}放置了奶酪",
	logGather: "采集了 {{n}} 份资源",
	logBuild: "建成了{{building}}",
	logComplete: "完成了订单",
	logActivate: "使用了{{building}}",
	logCorp: "公司在{{venue}}放置了奶酪",
	logCorpOrder: "公司保留了一张订单",
	more: "详情",
	restoreDefault: "恢复默认建筑",
	passive: "建成后生效",
	milkUsed: "已经使用",
	noActions: "当前没有可执行的行动",
	points: "{{n}} 分",
	draftRound: "轮抽 {{n}}/4",
	fruitProduct: "果味 {{n}} · 果酱 {{m}}",
	normal: "基础建筑",
	soloNote: "仅单人局生效",
	buildings: {
		cafe: {
			name: "咖啡馆",
			effect: "每占据一张餐酒馆桌子，终局额外获得2分。"
		},
		sharedWarehouse: {
			name: "共享仓库",
			effect: "在城市影响并列第一的每个区域，终局额外获得2分。"
		},
		cheeseTrolley: {
			name: "奶酪推车",
			effect: "每个与自家奶酪相邻的免费试吃点，终局获得2分。"
		},
		groceryShop: {
			name: "杂货店",
			effect: "在奶酪店下半货架放置奶酪时，将该货架资源奖励再执行一次。"
		},
		depot: {
			name: "货运站",
			effect: "在城市完成一张订单后，可额外完成另一张任意订单。"
		},
		diningRoom: {
			name: "餐厅",
			effect: "在餐酒馆制作果味或果酱奶酪时，可额外支付一水果，移至果味或果酱区。"
		},
		showroom: {
			name: "展示厅",
			effect: "奶酪店上半货架的印制分值计算两次。"
		},
		largeBooth: {
			name: "大型展位",
			effect: "节庆中有自家奶酪与免费试吃点组成的2×2方块时，终局获得7分。"
		},
		feedlot: {
			name: "饲养场",
			effect: "弃一闲置水果，获得一牲畜。"
		},
		farmhouse: {
			name: "农舍",
			effect: "将一张未完成订单放到牌堆底，获得一建筑资源。"
		},
		tradingHouse: {
			name: "贸易行",
			effect: "弃一闲置建筑资源，获得任意一资源。"
		},
		utilityRoom: {
			name: "杂务间",
			effect: "派蓝纹工人至此，获得任意一资源；下回合收回。"
		},
		jammery: {
			name: "果酱坊",
			effect: "派硬质工人至此，将一水果移至果酱区；下回合收回。"
		},
		briningRoom: {
			name: "盐渍间",
			effect: "硬质工人也可制作软质或蓝纹奶酪。"
		},
		mouldCave: {
			name: "霉菌洞窟",
			effect: "将一张未完成订单放到牌堆底，取回位于其他象限的蓝纹工人。"
		},
		creamery: {
			name: "奶油坊",
			effect: "制作软质果味或果酱奶酪后，获得一水果。"
		},
		giftShop: {
			name: "礼品店",
			effect: "派软质工人至此，完成任意一张已有订单；下回合收回。"
		},
		cellar: {
			name: "地窖",
			effect: "每建成一片高级建筑，包括本建筑，获得一订单。"
		},
		openRange: {
			name: "开放牧场",
			effect: "每使用一次挤奶位，获得一水果。"
		},
		salesOffice: {
			name: "销售处",
			effect: "每完成一张订单，获得一牲畜。"
		},
		packagingPlant: {
			name: "包装厂",
			effect: "每使用一水果制作果味或果酱，获得一订单。"
		},
		foundation: {
			name: "地基",
			effect: "其他高级建筑片的建造费用减少一建筑资源。"
		},
		byre: {
			name: "牛舍",
			effect: "每个挤奶位的费用减少一牲畜。"
		},
		stanchionBarn: {
			name: "颈架牛棚",
			effect: "挤奶奖励奶酪可为任意类型，熟成要求不变。"
		},
		pasteurizingChamber: {
			name: "巴氏杀菌室",
			effect: "可选择一个已用挤奶位，按相同费用额外使用一次。"
		},
		makeRoom: {
			name: "制酪间",
			effect: "每放置一枚铜奶酪，获得一订单。"
		},
		agingRoom: {
			name: "熟成室",
			effect: "每放置一枚金奶酪，获得一牲畜。"
		},
		fermentingChamber: {
			name: "发酵室",
			effect: "每放置一枚银奶酪，获得一水果。"
		},
		distributionCentre: {
			name: "配送中心",
			effect: "四个场地各有至少3枚自家奶酪，终局获得6分。"
		},
		annex: {
			name: "附属房",
			effect: "采集时使用3资源位，额外获得一份该资源。"
		},
		visitorsCentre: {
			name: "游客中心",
			effect: "终局没有闲置资源时，获得5分。"
		},
		workersQuarters: {
			name: "工人宿舍",
			effect: "正常最后一回合后，转盘额外旋转一次，可再行动一回合。"
		},
		barn: {
			name: "谷仓",
			effect: "派任意可用工人至此，获得一牲畜，下回合收回。"
		},
		greenhouse: {
			name: "温室",
			effect: "每回合首次获得水果时，额外获得一水果。"
		},
		loadingDock: {
			name: "装卸码头",
			effect: "每次在奶酪店放置奶酪，获得一订单。"
		},
		headquarters: {
			name: "总部",
			effect: "每支付一建筑资源建造，终局获得1分。"
		},
		toolShed: {
			name: "工具棚",
			effect: "派任意可用工人至此，获得一建筑资源，下回合收回。"
		},
		tastingRoom: {
			name: "品鉴室",
			effect: "每回合首次获得订单时，额外获得一订单。"
		},
		market: {
			name: "市场",
			effect: "每次在节庆放置奶酪，获得一牲畜。"
		},
		specialtyCheeseShop: {
			name: "特色奶酪店",
			effect: "每使用一水果制作果味或果酱，终局获得1分。"
		},
		gardenShed: {
			name: "园艺棚",
			effect: "派任意可用工人至此，获得一水果，下回合收回。"
		},
		calfBarn: {
			name: "犊牛舍",
			effect: "每回合首次获得牲畜时，额外获得一牲畜。"
		},
		delicatessen: {
			name: "熟食店",
			effect: "每次在城市放置奶酪，获得一建筑资源。"
		},
		restaurant: {
			name: "餐馆",
			effect: "每完成一订单，终局获得1分。"
		},
		kitchen: {
			name: "厨房",
			effect: "派任意可用工人至此，获得一订单，下回合收回。"
		},
		workshop: {
			name: "工坊",
			effect: "每回合首次获得建筑资源时，额外获得一建筑资源。"
		},
		spiceGarden: {
			name: "香料园",
			effect: "每次在餐酒馆放置奶酪，获得一水果。"
		},
		groomingHouse: {
			name: "梳理房",
			effect: "每支付一牲畜挤奶，终局获得1分。"
		}
	}
}, Je = {
	name: "Fromage",
	desc: "Run a French creamery: age cheese, expand your workshop, and compete for customers.",
	rules: "Goal:\nEarn the most Prestige through four Venues, Structures, Fruit, and Orders. This is the second-printing base game for 1–4 players; Formaggio is not included.\nSetup:\nEach player receives 15 Cheese Tokens, one Soft, Hard, and Bleu Worker, and a random Player Board. Venues and Resources are randomized. Start with 2 Resources from the quadrant to your left and 1 from the opposite quadrant. Use the appropriate inserts for 1–2, 3, or 4 players; choose I or II separately for each Venue. Side 0 is for four players only. With advanced Structures, each player drafts four tiles: keep one of the four tiles and pass the others left. Repeat until each player has kept four tiles. Solo players choose one tile from fresh sets of 4, 3, 2, then 1. Replace any default abilities with kept tiles, or retain the defaults.\nTurns:\nAll players act simultaneously in their current quadrant. Once per turn, assign one available Worker to Make Cheese and one to Gather Resources, in either order. Either action is optional. Build, milk Livestock, and use completed Structures at any time. When everyone finishes, rotate the board 90 degrees clockwise.\n· Make Cheese: choose an available Worker, then an empty space matching its type. Place a Cheese Token there. The Worker returns after the indicated 1, 2, or 3 turns. You may immediately complete one existing Order matching that cheese type and age. Newly drawn Orders cannot be completed retroactively. Fruited Cheese and Jam spaces require one Fruit, moved to the appropriate spent area.\n· Gather: any available Worker can occupy an empty Resource space labeled 1, 2, or 3 in the current quadrant. Immediately gain that many Resources; the Worker returns after that many turns. Occupied spaces are unavailable.\n· Milk: pay 2, 3, 4, or 5 Livestock to use an unused Milking Parlour. Place its Bonus Cheese in a matching type/age space in the current Venue, without a Worker or consuming your Make Cheese action. Fruit is still required where shown. Each Parlour is normally usable once per game.\n· Build: pay Structure Tokens to unlock an ability. Abilities apply whenever their conditions are met; the second default ability grants its extra Resource only once per turn. Read each advanced tile for its effect. Newly completed abilities do not apply retroactively to past events.\nVenues:\nBistro: completing pairs at tables improves the value of all your cheese. Score according to the number of complete tables:\n· With no complete tables, each Bronze cheese scores 0 points, each Silver cheese 2 points and each Gold cheese 4 points.\n· With one complete table, each Bronze cheese scores 1 point, each Silver cheese 3 points and each Gold cheese 5 points.\n· With two complete tables, each Bronze cheese scores 2 points, each Silver cheese 4 points and each Gold cheese 6 points.\n· With at least three complete tables, each Bronze cheese scores 3 points, each Silver cheese 6 points and each Gold cheese 9 points.\nFromagerie: occupying one through six different shelves scores 0, 2, 5, 9, 14 and 20 points respectively. Shelf positions also provide these rewards:\n· Upper shelves add 1 point per Bronze cheese, 2 points per Silver cheese and 3 points per Gold cheese.\n· A lower Bronze position lets you discard one Resource to gain any one Resource.\n· A lower Silver position gives any one Resource.\n· A lower Gold position gives two different Resources.\nFestival: your cheese and Free Samples form orthogonally connected groups; opposing cheese cannot connect them. A group of 1–7 scores 0, 2, 4, 6, 9, 12, or 15, then 5 more per additional token.\nVilles: each cheese influences every region it touches. The most influence wins that region’s Customer: With one or two players, Customers are worth 3, 4 or 5 points according to the region; with three players, 5, 6 or 7; with four, 7, 8 or 9. Use the value printed for the region. Tied leaders each score 0 points with one or two players, 2 points with three, or 3 points with four.\nScoring and end:\n· Multiply the amount of Fruit spent on Fruited Cheese by the amount spent on Jam, and score points equal to the result.\n· Completing 1–6 Orders scores 1, 3, 5, 8, 11, or 14 points respectively; each further completed Order adds 4 points.\n· Every two unused Resources, including incomplete Orders, score 1.\n· Add all completed Structure bonuses.\nWhen anyone places their 15th Cheese Token, finish the current turn. Cheese scores regardless of whether its Worker has returned. Workers’ Quarters grants its owner one extra turn after one more board rotation. Highest Prestige wins; break ties by cheese placed, then share victory.\nSolo corporation:\nThe corporation draws first. Choose any matching empty space in your current Venue for its cheese, without paying Fruit. If none matches, or it has no cheese left, it keeps the Order for 3 points at game-end.\n· At Levels 1, 2, 3 and 4, the corporation has 15, 17, 18 and 19 cheese respectively; their printed base Prestige increases as cheese is placed. The corporation competes only for Villes Customers, worth 3, 4 or 5 points as printed. It does not score other Venues.\n· Level 2 draws twice from the turn after its 10th cheese, Level 3 after its 8th, and Level 4 after its 6th.\n· At Level 3 or higher, the corporation gains one Fruit when it places cheese on a Fruited Cheese or Jam space. Totals of 2, 4, 6 and 8 Fruit score 1, 3, 6 and 10 points respectively. Each further pair adds 5 points.\n· At Level 4, the last drawn Silver Order blocks the 2 Resource space that turn, and Gold blocks the 3 space.\nEither side exhausting cheese triggers the final turn. Compare Prestige, then cheese placed; remaining ties share victory.",
	round: "Turn {{n}}",
	extra: "Extra turn",
	final: "Final turn",
	draft: "Choose an advanced Structure",
	install: "Arrange your creamery",
	play: "Make cheese or gather",
	corp: "Choose a matching space for the corporation",
	rotate: "Rotating the board",
	done: "Game over",
	wait: "Waiting for other players",
	ready: "Finish turn",
	confirmReady: "Confirm finish turn",
	skip: "Skip",
	build: "Build",
	use: "Use",
	replace: "Replace this ability",
	keep: "Finish arrangement",
	chooseSlot: "Choose an ability to replace",
	orders: "Incomplete Orders",
	complete: "Complete Order",
	completed: "{{n}} Orders completed",
	cheeses: "Cheese {{n}}/15",
	workers: "Workers",
	milk: "Milk",
	available: "Available",
	returns: "Returns in {{n}} turns",
	current: "Current quadrant",
	viewing: "View creamery",
	cost: "Cost {{n}}",
	score: "Prestige",
	corpName: "Cheese corporation",
	company: "Corporation Prestige {{n}}",
	level: "Corporation level",
	advanced: "Draft advanced Structures",
	layout: "Venue inserts",
	random: "Random",
	default: "Default ability",
	buildingDetails: "Structure details",
	close: "Close",
	chooseResource: "Choose a Resource to gain",
	trade: "Choose a Resource to discard",
	chooseOrder: "Choose an Order to complete",
	dining: "Spend one additional Fruit",
	fruited: "Fruited Cheese",
	jam: "Jam",
	unused: "Unused Resources",
	structures: "Structures",
	fruitScore: "Fruit",
	orderScore: "Orders",
	total: "Total",
	ledger: "The creamery ledger",
	winner: "{{names}} wins",
	sharedWinner: "{{names}} share victory",
	companyWins: "The corporation wins",
	reviewHide: "Collapse results and review the board",
	reviewShow: "Show results",
	confirmAgain: "Confirm play again",
	confirmLobby: "Confirm return to lobby",
	errChoice: "That action is unavailable. Please choose again.",
	target: "{{type}}, {{age}}-turn maturation{{fruit}}",
	fruitNeed: ", requires Fruit",
	occupied: "{{name}}’s cheese",
	gather: "Gain {{n}} {{resource}}",
	make: "Make cheese",
	draftPicked: "Selected; waiting for other players",
	allVenues: "All Venues",
	empty: "None",
	free: "Free Sample",
	influence: "Region {{n}}: {{points}} points",
	actionLog: "Game record",
	selectWorker: "Choose an available Worker",
	soft: "Soft",
	hard: "Hard",
	bleu: "Bleu",
	structure: "Structure Tokens",
	livestock: "Livestock",
	fruit: "Fruit",
	order: "Orders",
	bistro: "Bistro",
	fromagerie: "Fromagerie",
	festival: "Festival",
	villes: "Villes",
	logMake: "Placed cheese in {{venue}}",
	logGather: "Gathered {{n}} Resources",
	logBuild: "Built {{building}}",
	logComplete: "Completed an Order",
	logActivate: "Used {{building}}",
	logCorp: "The corporation placed cheese in {{venue}}",
	logCorpOrder: "The corporation kept an Order",
	more: "Details",
	restoreDefault: "Restore default ability",
	passive: "Applies when built",
	milkUsed: "Used",
	noActions: "No actions available",
	points: "{{n}} points",
	draftRound: "Draft {{n}}/4",
	fruitProduct: "Fruited {{n}} · Jam {{m}}",
	normal: "Default Structures",
	soloNote: "Solo games only",
	buildings: {
		cafe: {
			name: "Café",
			effect: "At game-end, score 2 per Bistro table containing your cheese."
		},
		sharedWarehouse: {
			name: "Shared Warehouse",
			effect: "At game-end, score 2 per Villes region where you tie for the most influence."
		},
		cheeseTrolley: {
			name: "Cheese Trolley",
			effect: "At game-end, score 2 per Free Sample adjacent to your Festival cheese."
		},
		groceryShop: {
			name: "Grocery Shop",
			effect: "When placing on a Fromagerie Resource shelf, gain its bonus a second time."
		},
		depot: {
			name: "Depot",
			effect: "After completing an Order in Villes, you may complete one other Order of your choice."
		},
		diningRoom: {
			name: "Dining Room",
			effect: "When making cheese with Fruit in the Bistro, you may spend one more Fruit on Fruited Cheese or Jam."
		},
		showroom: {
			name: "Showroom",
			effect: "Double the printed points of your cheese on upper Fromagerie shelves."
		},
		largeBooth: {
			name: "Large Booth",
			effect: "Score 7 if your Festival cheese and Free Samples form a 2×2 square."
		},
		feedlot: {
			name: "Feedlot",
			effect: "Discard an unused Fruit to gain a Livestock."
		},
		farmhouse: {
			name: "Farmhouse",
			effect: "Put an incomplete Order on the bottom of the deck to gain a Structure Token."
		},
		tradingHouse: {
			name: "Trading House",
			effect: "Discard an unused Structure Token to gain any one Resource."
		},
		utilityRoom: {
			name: "Utility Room",
			effect: "Place your Bleu Worker here to gain any one Resource; retrieve it next turn."
		},
		jammery: {
			name: "Jammery",
			effect: "Place your Hard Worker here to move one Fruit to Jam; retrieve it next turn."
		},
		briningRoom: {
			name: "Brining Room",
			effect: "Your Hard Worker may also make Soft or Bleu cheese."
		},
		mouldCave: {
			name: "Mould Cave",
			effect: "Put an incomplete Order on the bottom of the deck to retrieve your Bleu Worker from another quadrant."
		},
		creamery: {
			name: "Creamery",
			effect: "After making Soft cheese with Fruit, gain a Fruit."
		},
		giftShop: {
			name: "Gift Shop",
			effect: "Place your Soft Worker here to complete any existing Order; retrieve it next turn."
		},
		cellar: {
			name: "Cellar",
			effect: "After completing any advanced Structure tile, including this one, gain an Order."
		},
		openRange: {
			name: "Open Range",
			effect: "After using a Milking Parlour, gain a Fruit."
		},
		salesOffice: {
			name: "Sales Office",
			effect: "After completing an Order, gain a Livestock."
		},
		packagingPlant: {
			name: "Packaging Plant",
			effect: "After spending Fruit on Fruited Cheese or Jam, gain an Order."
		},
		foundation: {
			name: "Foundation",
			effect: "Other advanced Structure tiles cost one fewer Structure Token."
		},
		byre: {
			name: "Byre",
			effect: "Milking Parlours cost one fewer Livestock."
		},
		stanchionBarn: {
			name: "Stanchion Barn",
			effect: "Bonus Cheese from milking may be any type; its age must still match."
		},
		pasteurizingChamber: {
			name: "Pasteurizing Chamber",
			effect: "Use one of your used Milking Parlours a second time by paying its cost again."
		},
		makeRoom: {
			name: "Make Room",
			effect: "After placing Bronze cheese, gain an Order."
		},
		agingRoom: {
			name: "Aging Room",
			effect: "After placing Gold cheese, gain a Livestock."
		},
		fermentingChamber: {
			name: "Fermenting Chamber",
			effect: "After placing Silver cheese, gain a Fruit."
		},
		distributionCentre: {
			name: "Distribution Centre",
			effect: "Score 6 if you have at least 3 cheese in each of the four Venues."
		},
		annex: {
			name: "Annex",
			effect: "When gathering from the 3 Resource space, gain one extra of that Resource."
		},
		visitorsCentre: {
			name: "Visitors Centre",
			effect: "Score 5 if you have no unused Resources at game-end."
		},
		workersQuarters: {
			name: "Workers’ Quarters",
			effect: "After the final turn, rotate once more and take one additional turn."
		},
		barn: {
			name: "Barn",
			effect: "Place any available Worker here to gain one Livestock; retrieve it next turn."
		},
		greenhouse: {
			name: "Greenhouse",
			effect: "Once per turn, when gaining Fruit, gain one additional Fruit."
		},
		loadingDock: {
			name: "Loading Dock",
			effect: "When placing cheese in the Fromagerie, gain an Order."
		},
		headquarters: {
			name: "Headquarters",
			effect: "Score 1 per Structure Token spent on construction."
		},
		toolShed: {
			name: "Tool Shed",
			effect: "Place any available Worker here to gain one Structure Token; retrieve it next turn."
		},
		tastingRoom: {
			name: "Tasting Room",
			effect: "Once per turn, when gaining Orders, gain one additional Order."
		},
		market: {
			name: "Market",
			effect: "When placing cheese in the Festival, gain a Livestock."
		},
		specialtyCheeseShop: {
			name: "Specialty Cheese Shop",
			effect: "Score 1 per Fruit spent on Fruited Cheese or Jam."
		},
		gardenShed: {
			name: "Garden Shed",
			effect: "Place any available Worker here to gain one Fruit; retrieve it next turn."
		},
		calfBarn: {
			name: "Calf Barn",
			effect: "Once per turn, when gaining Livestock, gain one additional Livestock."
		},
		delicatessen: {
			name: "Delicatessen",
			effect: "When placing cheese in Villes, gain a Structure Token."
		},
		restaurant: {
			name: "Restaurant",
			effect: "Score 1 per completed Order."
		},
		kitchen: {
			name: "Kitchen",
			effect: "Place any available Worker here to gain one Order; retrieve it next turn."
		},
		workshop: {
			name: "Workshop",
			effect: "Once per turn, when gaining Structure Tokens, gain one additional Structure Token."
		},
		spiceGarden: {
			name: "Spice Garden",
			effect: "When placing cheese in the Bistro, gain a Fruit."
		},
		groomingHouse: {
			name: "Grooming House",
			effect: "Score 1 per Livestock spent on milking."
		}
	}
}, Ye = (e) => g(`games/fromage/${e}.svg`);
function Y({ name: e, className: t = "", style: n }) {
	return /* @__PURE__ */ y("img", {
		className: `fm-art ${t}`,
		src: Ye(e),
		alt: "",
		draggable: !1,
		style: n
	});
}
function X({ name: e, children: t, className: n = "", style: r }) {
	let { ref: i, hidden: a } = _(e);
	return /* @__PURE__ */ y("span", {
		ref: i,
		className: n,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: t
	});
}
function Xe() {
	return l((e) => e.locale) === "en" ? Je : qe;
}
var Z = (e, t) => e.replace(/\{\{(\w+)\}\}/g, (e, n) => String(t[n] ?? "")), Q = (e, t) => e.buildings[t], Ze = {
	bistro: [
		260,
		35,
		470,
		300
	],
	fromagerie: [
		700,
		305,
		275,
		400
	],
	festival: [
		30,
		320,
		320,
		340
	],
	villes: [
		260,
		620,
		470,
		355
	]
};
function Qe(e, t) {
	if (e === "bistro") return [[
		345,
		400,
		478,
		533,
		610,
		665
	][t % 6], [
		116,
		193,
		270
	][Math.floor(t / 6)]];
	if (e === "fromagerie") return [[
		755,
		837,
		916
	][t % 3], [
		365,
		424,
		483,
		542,
		601,
		660
	][Math.floor(t / 3)]];
	if (e === "festival") {
		let [e, n] = R[t];
		return [72 + n * 61, 359 + e * 61];
	}
	let [, n, r] = L[t];
	return [280 + n * 420, 630 + r * 310];
}
function $e(e) {
	return /* @__PURE__ */ y(et, { ...e }, e.myRid);
}
function et({ public: e, private: t, members: n, myRid: r, send: u }) {
	let g = e, _ = t, x = Xe(), ee = l((e) => e.locale), [te, ne] = i(r), [re, ie] = i(null), [S, ae] = i(null), [C, O] = i(null), [se, ce] = i(null), [le, ue] = i(!1), k = g.players.find((e) => e.rid === r), M = g.players.find((e) => e.rid === te) ?? k ?? g.players[0], N = g.phase === "done", fe = k ? g.venues[H(g, k)] : g.venues[0], P = re ?? fe, F = N ? [] : _?.choices ?? [], I = k?.rid === M.rid, L = (e) => e === "$corporation" ? x.corpName : n.find((t) => t.rid === e) ? d(n.find((t) => t.rid === e), ee) : e, R = (e) => e === "$corporation" ? "#3e535b" : f[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % f.length].hex, z = (e) => {
		u({
			type: "choose",
			id: e.id
		}), ae(null), O(null);
	}, pe = (e) => P === fe ? F.find((t) => t.spot === e && (t.kind === "corp" || S === `w${t.worker}` && t.kind === "make" || S === `m${t.slot}` && t.kind === "milk")) : void 0, me = N ? x.done : g.phase === "play" ? k?.ready ? x.wait : _?.pending === "order" ? x.chooseOrder : _?.pending === "resource" ? F.some((e) => e.count === -1) ? x.trade : x.chooseResource : _?.pending === "dining" ? x.dining : x.play : g.phase === "draft" && !F.length ? x.draftPicked : x[g.phase], B = (e) => `${L(e.rid)} · ${Z(e.kind === "make" ? x.logMake : e.kind === "gather" ? x.logGather : e.kind === "build" ? x.logBuild : e.kind === "complete" ? x.logComplete : e.kind === "activate" ? x.logActivate : e.kind === "corp" ? x.logCorp : x.logCorpOrder, {
		venue: x[e.venue] ?? "",
		n: e.count ?? 0,
		building: Q(x, e.building ?? "")?.name ?? ""
	})}`, he = F.find((e) => e.kind === "ready"), V = F.find((e) => e.kind === "skip"), ge = F.filter((e) => e.kind === "resource" || e.kind === "activate" && e.building === "diningRoom");
	return /* @__PURE__ */ b("div", {
		className: "fm-root",
		children: [
			/* @__PURE__ */ y(c, {
				adaptive: !0,
				className: "fm-screen",
				scroll: !1,
				banner: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(o, {
					text: me,
					chip: g.extra ? x.extra : Z(x.round, { n: g.round }),
					tone: N ? "done" : k?.ready ? "info" : "accent",
					accent: "#39796b"
				}), /* @__PURE__ */ y(s, {
					members: n,
					myRid: r,
					variant: "mini",
					anchorOf: (e) => `seat:${e}`,
					action: (e) => {
						let t = g.players.find((t) => t.rid === e);
						return N ? null : t?.ready ? "done" : "pending";
					},
					status: (e) => g.scores[e] ? /* @__PURE__ */ y("span", {
						className: "fm-player-score",
						children: /* @__PURE__ */ y(a, { value: g.scores[e].total })
					}) : null
				})] }),
				actionsHeight: N ? void 0 : "fm-actions-height",
				actions: /* @__PURE__ */ b("div", {
					className: "fm-actions",
					children: [/* @__PURE__ */ b("div", {
						className: "fm-tools",
						children: [
							k && E.map((e, t) => /* @__PURE__ */ b("button", {
								type: "button",
								className: "fm-worker",
								"aria-pressed": S === `w${t}`,
								disabled: N || !F.some((e) => e.worker === t && ["make", "gather"].includes(e.kind)),
								onClick: () => {
									ae(S === `w${t}` ? null : `w${t}`), ie(null);
								},
								title: k.workers[t].delay ? Z(x.returns, { n: k.workers[t].delay }) : x[e],
								children: [
									/* @__PURE__ */ y(X, {
										name: `worker:${r}:${t}`,
										children: /* @__PURE__ */ y(Y, { name: `${e}-1` })
									}),
									/* @__PURE__ */ y("small", { children: x[e] }),
									/* @__PURE__ */ y("b", { children: k.workers[t].delay || "✓" })
								]
							}, e)),
							/* @__PURE__ */ y("span", { className: "fm-tools-divider" }),
							k && [
								0,
								1,
								2,
								3
							].map((e) => /* @__PURE__ */ b("button", {
								type: "button",
								className: "fm-milk",
								"aria-pressed": S === `m${e}`,
								disabled: N || !F.some((t) => t.kind === "milk" && t.slot === e),
								title: x.milk,
								onClick: () => {
									ae(S === `m${e}` ? null : `m${e}`), ie(null);
								},
								children: [
									/* @__PURE__ */ y(Y, { name: "livestock" }),
									/* @__PURE__ */ y("small", { children: e === 3 ? "∗" : x[de[k.board][e]] }),
									/* @__PURE__ */ y("b", { children: e + 2 - +!!k.buildings.some((e, t) => e === "byre" && k.built[t]) })
								]
							}, e))
						]
					}), /* @__PURE__ */ b("div", {
						className: "fm-turn-buttons",
						children: [
							g.finalRound && !N && /* @__PURE__ */ y("small", {
								className: "fm-final",
								children: x.final
							}),
							V && /* @__PURE__ */ y("button", {
								className: "fm-quiet",
								onClick: () => z(V),
								children: x.skip
							}),
							he && (g.phase === "install" ? /* @__PURE__ */ y("button", {
								className: "fm-primary",
								onClick: () => z(he),
								children: x.keep
							}) : /* @__PURE__ */ y(p, {
								className: "fm-primary",
								label: x.ready,
								confirmLabel: x.confirmReady,
								onConfirm: () => z(he)
							})),
							!he && !V && /* @__PURE__ */ y("span", {
								className: "fm-action-status",
								children: me
							})
						]
					})]
				}),
				overlay: ge.length > 0 && /* @__PURE__ */ y("div", {
					className: "fm-pending",
					children: ge.map((e) => /* @__PURE__ */ b("button", {
						className: "fm-resource-choice",
						onClick: () => z(e),
						children: [e.resource && /* @__PURE__ */ y(Y, { name: e.resource === "order" ? "order" : e.resource }), /* @__PURE__ */ b("span", { children: [e.resource ? x[e.resource] : e.fruit === "fruit" ? x.fruited : x.jam, e.card !== void 0 && ` · ${x[A(e.card)]} ${j(e.card)}`] })]
					}, e.id))
				}),
				children: /* @__PURE__ */ b("div", {
					className: "fm-tabletop",
					children: [
						/* @__PURE__ */ b("aside", {
							className: "fm-turntable-column",
							children: [
								/* @__PURE__ */ b("div", {
									className: "fm-turntable-wrap",
									children: [/* @__PURE__ */ b("div", {
										className: "fm-turntable",
										style: { transform: `rotate(${g.rotation * 90}deg)` },
										children: [/* @__PURE__ */ y(nt, {
											pub: g,
											color: R
										}), g.venues.map((e, t) => /* @__PURE__ */ b("button", {
											className: `fm-wheel-label fm-wheel-q${t}`,
											"aria-pressed": P === e,
											onClick: () => ie(e),
											style: { "--counter-rotation": `${-g.rotation * 90}deg` },
											children: [/* @__PURE__ */ y("strong", { children: x[e] }), /* @__PURE__ */ b("span", { children: [g.cheeses[e].filter(Boolean).length, "/18"] })]
										}, e))]
									}), /* @__PURE__ */ b(X, {
										name: "deck",
										className: "fm-deck",
										children: [/* @__PURE__ */ y(Y, { name: "order" }), /* @__PURE__ */ y("b", { children: g.deckCount })]
									})]
								}),
								/* @__PURE__ */ y("div", {
									className: "fm-venue-nav",
									children: w.map((e) => /* @__PURE__ */ b("button", {
										className: "fm-tab",
										"aria-pressed": P === e,
										onClick: () => ie(e),
										children: [x[e], e === fe && /* @__PURE__ */ y("span", { children: "◆" })]
									}, e))
								}),
								g.players.length === 1 && /* @__PURE__ */ b(X, {
									name: "corporation",
									className: "fm-company",
									children: [
										/* @__PURE__ */ b("strong", { children: [
											x.corpName,
											" ",
											g.corporation.level
										] }),
										/* @__PURE__ */ b("span", { children: [
											Z(x.company, { n: g.corpScore }),
											" · ",
											g.corporation.used
										] }),
										/* @__PURE__ */ y(X, {
											name: "corp-order",
											children: g.corporation.card !== null && /* @__PURE__ */ y(Y, { name: `${A(g.corporation.card)}-${j(g.corporation.card)}` })
										})
									]
								}),
								/* @__PURE__ */ y("button", {
									type: "button",
									className: "fm-log",
									onClick: () => ue(!0),
									children: g.log.length ? B(g.log[g.log.length - 1]) : x.actionLog
								})
							]
						}),
						/* @__PURE__ */ b("main", {
							className: "fm-venue-column",
							children: [
								/* @__PURE__ */ b("header", {
									className: "fm-section-title",
									children: [/* @__PURE__ */ b("div", { children: [/* @__PURE__ */ b("small", { children: [
										P === fe ? x.current : x.allVenues,
										" · ",
										g.layouts[P]
									] }), /* @__PURE__ */ y("h2", { children: x[P] })] }), /* @__PURE__ */ b("strong", { children: [
										g.scores[M.rid][P],
										" ",
										/* @__PURE__ */ y("small", { children: x.score })
									] })]
								}),
								g.phase === "draft" || g.phase === "install" ? /* @__PURE__ */ b("div", {
									className: "fm-draft-area",
									children: [/* @__PURE__ */ y("h3", { children: g.phase === "draft" ? Z(x.draftRound, { n: g.draftRound }) : x.chooseSlot }), /* @__PURE__ */ y("div", {
										className: "fm-draft-tiles",
										children: (g.phase === "draft" ? _?.draft : _?.kept)?.map((e) => /* @__PURE__ */ b("button", {
											type: "button",
											className: "fm-structure-tile",
											"aria-pressed": C === e,
											disabled: g.phase === "draft" && !F.some((t) => t.building === e),
											onClick: () => {
												if (g.phase === "draft") {
													let t = F.find((t) => t.building === e);
													t && z(t);
												} else O(C === e ? null : e);
											},
											children: [
												/* @__PURE__ */ y(Y, { name: "structure" }),
												/* @__PURE__ */ y("b", { children: Q(x, e)?.name }),
												/* @__PURE__ */ y("small", { children: Z(x.cost, { n: oe[D.indexOf(e)] }) }),
												/* @__PURE__ */ y("p", { children: Q(x, e)?.effect })
											]
										}, e))
									})]
								}) : /* @__PURE__ */ y(tt, {
									pub: g,
									v: P,
									l: x,
									target: pe,
									onChoice: z,
									name: L,
									color: R
								}),
								/* @__PURE__ */ b("div", {
									className: "fm-resource-dock",
									children: [/* @__PURE__ */ y("span", { children: x[g.resources[k ? H(g, k) : 0]] }), [
										1,
										2,
										3
									].map((e) => {
										let t = F.find((t) => t.kind === "gather" && t.count === e && S === `w${t.worker}`), n = k ? H(g, k) : 0, r = g.players.flatMap((e) => e.workers.map((t, n) => ({
											p: e,
											w: t,
											i: n
										}))).find((t) => t.w.location === "resource" && t.w.q === n && t.w.spot === e && t.w.delay > 0);
										return /* @__PURE__ */ b("button", {
											type: "button",
											className: `fm-resource-space ${t ? "fm-target" : ""}`,
											disabled: !t,
											"aria-label": Z(x.gather, {
												n: e,
												resource: x[g.resources[n]]
											}),
											onClick: () => t && z(t),
											children: [
												/* @__PURE__ */ y(Y, { name: g.resources[n] === "order" ? "order" : g.resources[n] }),
												/* @__PURE__ */ y("b", { children: e }),
												r && /* @__PURE__ */ b(X, {
													name: `worker-board:${r.p.rid}:${r.i}`,
													className: "fm-resource-worker",
													children: [/* @__PURE__ */ y(Y, { name: `${E[r.i]}-1` }), /* @__PURE__ */ y("small", { children: L(r.p.rid) })]
												})
											]
										}, e);
									})]
								})
							]
						}),
						/* @__PURE__ */ b("aside", {
							className: "fm-creamery",
							children: [
								/* @__PURE__ */ b("header", {
									className: "fm-section-title",
									children: [/* @__PURE__ */ b("label", { children: [x.viewing, /* @__PURE__ */ y("select", {
										value: M.rid,
										onChange: (e) => ne(e.target.value),
										children: g.players.map((e) => /* @__PURE__ */ y("option", {
											value: e.rid,
											children: L(e.rid)
										}, e.rid))
									})] }), /* @__PURE__ */ b(X, {
										name: `cheeses:${M.rid}`,
										children: [/* @__PURE__ */ y(Y, { name: "cheese" }), /* @__PURE__ */ y("strong", { children: 15 - M.placed })]
									})]
								}),
								/* @__PURE__ */ y("div", {
									className: "fm-stores",
									children: T.map((e) => /* @__PURE__ */ b(X, {
										name: e === "order" ? `completed:${M.rid}` : `resource:${M.rid}:${e}`,
										className: "fm-store",
										children: [
											/* @__PURE__ */ y(Y, { name: e === "order" ? "order" : e }),
											/* @__PURE__ */ y("b", { children: /* @__PURE__ */ y(a, { value: e === "order" ? M.complete.length : M.resources[e] }) }),
											/* @__PURE__ */ y("small", { children: e === "order" ? x.orderScore : x[e] })
										]
									}, e))
								}),
								/* @__PURE__ */ y("div", {
									className: "fm-buildings",
									children: M.buildings.map((e, t) => {
										let n = I ? F.find((e) => e.kind === "build" && e.slot === t) : null, r = I && C ? F.find((e) => e.kind === "replace" && e.slot === t && e.building === C) : null, i = F.find((e) => e.kind === "replace" && e.slot === t && !D.includes(e.building));
										return /* @__PURE__ */ b(X, {
											name: `building:${M.rid}:${t}`,
											className: `fm-building ${M.built[t] ? "is-built" : ""}`,
											children: [
												/* @__PURE__ */ b("button", {
													type: "button",
													className: r || n ? "fm-target" : "",
													onClick: () => {
														r ? z(r) : n ? z(n) : ce(e);
													},
													children: [
														/* @__PURE__ */ y(Y, { name: "structure" }),
														/* @__PURE__ */ y("b", { children: Q(x, e)?.name }),
														/* @__PURE__ */ y("small", { children: M.built[t] ? "✓" : Z(x.cost, { n: Me(M, t) }) })
													]
												}),
												/* @__PURE__ */ y("button", {
													type: "button",
													className: "fm-building-info",
													"aria-label": `${Q(x, e)?.name} · ${x.more}`,
													onClick: () => ce(e),
													children: "i"
												}),
												i && I && /* @__PURE__ */ y("button", {
													className: "fm-restore-default",
													onClick: () => z(i),
													children: x.restoreDefault
												})
											]
										}, t);
									})
								}),
								/* @__PURE__ */ y("div", {
									className: "fm-activations",
									children: I && F.filter((e) => e.kind === "activate" && e.building !== "diningRoom").map((e) => /* @__PURE__ */ b("button", {
										type: "button",
										onClick: () => z(e),
										children: [
											Q(x, e.building)?.name,
											e.worker !== void 0 && ` · ${x[E[e.worker]]}`,
											e.resource && ` · ${x[e.resource]}`,
											e.card !== void 0 && ` · ${x[A(e.card)]} ${j(e.card)}`
										]
									}, e.id))
								}),
								/* @__PURE__ */ b("div", {
									className: "fm-fruit-track",
									children: [
										/* @__PURE__ */ b(X, {
											name: `spent:${M.rid}:fruit`,
											children: [
												/* @__PURE__ */ y(Y, { name: "fruit" }),
												/* @__PURE__ */ y("b", { children: M.fruited }),
												/* @__PURE__ */ y("small", { children: x.fruited })
											]
										}),
										/* @__PURE__ */ y("span", { children: "×" }),
										/* @__PURE__ */ b(X, {
											name: `spent:${M.rid}:jam`,
											children: [
												/* @__PURE__ */ y(Y, { name: "jam" }),
												/* @__PURE__ */ y("b", { children: M.jam }),
												/* @__PURE__ */ y("small", { children: x.jam })
											]
										}),
										/* @__PURE__ */ y("strong", { children: g.scores[M.rid].fruit })
									]
								}),
								/* @__PURE__ */ y("div", {
									className: "fm-milk-track",
									children: M.milk.map((e, t) => /* @__PURE__ */ b(X, {
										name: `milk:${M.rid}:${t}`,
										className: e ? "is-used" : "",
										children: [
											/* @__PURE__ */ y(Y, { name: "livestock" }),
											/* @__PURE__ */ y("b", { children: e ? `✓ ${e}` : t + 2 }),
											/* @__PURE__ */ y("small", { children: t === 3 ? "∗" : `${x[de[M.board][t]]} ${t + 1}` })
										]
									}, t))
								}),
								/* @__PURE__ */ y("h3", { children: x.orders }),
								/* @__PURE__ */ b("div", {
									className: "fm-orders",
									children: [M.orders.map((e) => {
										let t = I ? F.find((t) => t.kind === "complete" && t.card === e) : null;
										return /* @__PURE__ */ y(X, {
											name: `order:${M.rid}:${e}`,
											children: /* @__PURE__ */ b("button", {
												type: "button",
												disabled: !t,
												className: t ? "fm-target" : "",
												"aria-label": `${x.complete} · ${x[A(e)]} ${j(e)}`,
												onClick: () => t && z(t),
												children: [/* @__PURE__ */ y(Y, { name: `${A(e)}-${j(e)}` }), /* @__PURE__ */ b("small", { children: [
													x[A(e)],
													" · ",
													j(e)
												] })]
											})
										}, e);
									}), !M.orders.length && /* @__PURE__ */ y("small", { children: x.empty })]
								}),
								/* @__PURE__ */ y("div", {
									className: "fm-creamery-art",
									children: /* @__PURE__ */ y("img", {
										src: Ye("creamery"),
										alt: ""
									})
								}),
								/* @__PURE__ */ y("div", {
									className: "fm-waiting-workers",
									children: M.workers.map((e, t) => e.location === "building" ? /* @__PURE__ */ b(X, {
										name: `worker-board:${M.rid}:${t}`,
										children: [/* @__PURE__ */ y(Y, { name: `${E[t]}-1` }), /* @__PURE__ */ b("small", { children: [
											Q(x, M.buildings[e.spot])?.name,
											" · ",
											Z(x.returns, { n: e.delay })
										] })]
									}, t) : null)
								})
							]
						})
					]
				})
			}),
			se && /* @__PURE__ */ y(m, {
				open: !0,
				label: x.buildingDetails,
				title: Q(x, se)?.name ?? x.buildingDetails,
				onClose: () => ce(null),
				children: /* @__PURE__ */ b("div", {
					className: "fm-detail",
					children: [/* @__PURE__ */ y(Y, { name: "structure" }), /* @__PURE__ */ y("p", { children: Q(x, se)?.effect })]
				})
			}),
			le && /* @__PURE__ */ y(h, {
				log: g.log,
				line: B,
				onClose: () => ue(!1)
			})
		]
	});
}
function tt({ pub: e, v: t, l: n, target: r, onChoice: i, name: a, color: o }) {
	let [s, c, l, u] = Ze[t], d = B(t, e.layouts[t]);
	return /* @__PURE__ */ b("div", {
		className: `fm-board fm-board-${t}`,
		style: { aspectRatio: `${l}/${u}` },
		children: [
			/* @__PURE__ */ y("svg", {
				className: "fm-board-background",
				viewBox: `${s} ${c} ${l} ${u}`,
				"aria-hidden": "true",
				children: /* @__PURE__ */ y("image", {
					href: Ye("table"),
					width: "1000",
					height: "1000"
				})
			}),
			d.map((d, f) => {
				let [p, m] = Qe(t, f), h = e.cheeses[t][f], g = r(f), _ = e.players.flatMap((e) => e.workers.map((t, n) => ({
					p: e,
					worker: t,
					wi: n
				}))).filter((n) => n.worker.location === "cheese" && n.worker.spot === f && e.venues[n.worker.q] === t && n.worker.delay > 0);
				return /* @__PURE__ */ b("div", {
					className: `fm-space ${d.type ? "" : "is-closed"}`,
					style: {
						left: `${(p - s) / l * 100}%`,
						top: `${(m - c) / u * 100}%`,
						"--owner": h ? o(h) : void 0
					},
					children: [/* @__PURE__ */ y("button", {
						type: "button",
						className: `${g ? "fm-target" : ""} ${h ? "is-occupied" : ""}`,
						disabled: !g,
						title: d.type ? h ? Z(n.occupied, { name: a(h) }) : Z(n.target, {
							type: n[d.type],
							age: d.age,
							fruit: d.fruit ? n.fruitNeed : ""
						}) : "",
						"aria-label": d.type ? h ? Z(n.occupied, { name: a(h) }) : Z(n.target, {
							type: n[d.type],
							age: d.age,
							fruit: d.fruit ? n.fruitNeed : ""
						}) : void 0,
						onClick: () => g && i(g),
						children: /* @__PURE__ */ b(X, {
							name: `cheese:${t}:${f}`,
							className: "fm-space-content",
							children: [
								d.type ? /* @__PURE__ */ y(Y, { name: `${d.type}-${d.age}` }) : /* @__PURE__ */ y("span", { children: "×" }),
								h && /* @__PURE__ */ b("span", {
									className: "fm-owner-mark",
									children: [/* @__PURE__ */ y(Y, { name: h === "$corporation" ? "structure" : "cheese" }), /* @__PURE__ */ y("small", { children: a(h) })]
								}),
								d.fruit && /* @__PURE__ */ y(Y, {
									name: d.fruit === "fruit" ? "fruit" : "jam",
									className: "fm-fruit-requirement"
								}),
								/* @__PURE__ */ y("b", {
									className: "fm-space-age",
									children: d.age
								})
							]
						})
					}), _.map(({ p: e, worker: t, wi: n }) => /* @__PURE__ */ b(X, {
						name: `worker-board:${e.rid}:${n}`,
						className: "fm-board-worker",
						children: [/* @__PURE__ */ y(Y, { name: `${E[n]}-1` }), /* @__PURE__ */ b("small", { children: [
							a(e.rid),
							" · ",
							t.delay
						] })]
					}, e.rid + n))]
				}, f);
			}),
			t === "villes" && e.customers.map((t, r) => /* @__PURE__ */ y("span", {
				className: `fm-customer fm-customer-${r}`,
				title: Z(n.influence, {
					n: r + 1,
					points: t + (e.players.length === 4 ? 6 : e.players.length === 3 ? 4 : 2)
				}),
				children: t + (e.players.length === 4 ? 6 : e.players.length === 3 ? 4 : 2)
			}, r))
		]
	});
}
function nt({ pub: e, color: t }) {
	let n = {
		bistro: 0,
		fromagerie: 1,
		villes: 2,
		festival: 3
	};
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 1000 1000",
		className: "fm-turntable-art",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ y("defs", { children: [
				0,
				1,
				2,
				3
			].map((e) => /* @__PURE__ */ y("clipPath", {
				id: `fm-quarter-${e}`,
				children: /* @__PURE__ */ y("path", {
					d: "M0 0H1000L500 500Z",
					transform: `rotate(${e * 90} 500 500)`
				})
			}, e)) }),
			/* @__PURE__ */ y("circle", {
				cx: "500",
				cy: "500",
				r: "498",
				fill: "#e3d5b6"
			}),
			e.venues.map((r, i) => /* @__PURE__ */ b("g", {
				transform: `rotate(${(i - n[r]) * 90} 500 500)`,
				children: [/* @__PURE__ */ y("image", {
					clipPath: `url(#fm-quarter-${n[r]})`,
					href: Ye("table"),
					width: "1000",
					height: "1000"
				}), e.cheeses[r].map((e, n) => {
					let [i, a] = Qe(r, n);
					return e ? /* @__PURE__ */ y("circle", {
						cx: i,
						cy: a,
						r: "15",
						fill: t(e),
						stroke: "#fff4d3",
						strokeWidth: "3"
					}, n) : null;
				})]
			}, r))
		]
	});
}
//#endregion
//#region src/games/fromage/bot.ts
var rt = {
	exactScore: .8,
	cheese: 6,
	workerDelay: .7,
	order: 2.5,
	engine: 1.8,
	gather: 2.8,
	potential: 0
}, it = /* @__PURE__ */ new Set([
	"greenhouse",
	"tastingRoom",
	"calfBarn",
	"workshop",
	"loadingDock",
	"market",
	"delicatessen",
	"spiceGarden",
	"cellar",
	"makeRoom",
	"fermentingChamber",
	"agingRoom",
	"salesOffice",
	"packagingPlant",
	"openRange",
	"byre",
	"foundation",
	"briningRoom"
]);
function $(e, t) {
	let n = t === "order" ? e.orders.length : e.resources[t];
	return t === "structure" ? n < 3 ? 1.7 : n < 6 ? 1 : .25 : t === "livestock" ? n < 5 ? 1.35 : .5 : t === "fruit" ? n < 2 ? 1.8 : n < 5 ? 1 : .3 : n < 3 ? 1.3 : .35;
}
function at(e, t, n, r) {
	let i = e.venues[H(e, t)], a = n.spot === void 0 ? null : B(i, e.layouts[i])[n.spot];
	if (n.kind === "ready") return -100;
	if (n.kind === "skip") return -30;
	if (n.kind === "complete") return 40;
	if (n.kind === "corp") {
		let r = structuredClone(e);
		return r.cheeses[i][n.spot] = "$corporation", -He(r, t).total + (a?.fruit ? -1 : 0);
	}
	if (n.kind === "resource") return n.count === -1 ? -$(t, n.resource) : $(t, n.resource) * 5;
	if (n.kind === "draft") return (it.has(n.building) ? 10 : 4) + (6 - oe[D.indexOf(n.building)]);
	if (n.kind === "replace") return !D.includes(n.building) || D.includes(t.buildings[n.slot]) ? -200 : (it.has(n.building) ? 8 : 1) - (n.slot === 2 ? 6 : n.slot === 1 ? 5 : n.slot === 0 ? 2 : 0);
	if (n.kind === "make" || n.kind === "milk") {
		if (!a) return -1e3;
		let o = structuredClone(e), s = o.players.find((e) => e.rid === t.rid);
		o.cheeses[i][n.spot] = t.rid, s.placed++, a.fruit && (s.resources.fruit--, s[a.fruit === "fruit" ? "fruited" : "jam"]++);
		let c = He(o, s).total - He(e, t).total, l = t.orders.some((e) => A(e) === a.type && j(e) === a.age), u = e.cheeses[i], d = B(i, e.layouts[i]), f = 0;
		i === "bistro" && (f = u.some((e, n) => e === t.rid && d[n].group === a.group) ? 3 : 1), i === "fromagerie" && (f = u.some((e, n) => e === t.rid && d[n].group === a.group) ? 0 : 3), i === "festival" && (f = u.filter((e, n) => e === t.rid && Math.abs(d[n].x - a.x) + Math.abs(d[n].y - a.y) < .21).length);
		let p = n.kind === "milk" ? (n.slot + 2) * .8 : a.age * r.workerDelay;
		return r.cheese + a.age * .7 + c * r.exactScore + f * r.potential + (l ? r.order : 0) - p;
	}
	if (n.kind === "gather") return r.gather * n.count * $(t, n.resource) / Math.sqrt(n.count);
	if (n.kind === "build") {
		let i = Math.max(0, 15 - Math.max(...e.players.map((e) => e.placed))), a = Me(t, n.slot);
		return r.engine * (it.has(n.building) ? i / 2 : i > 4 ? 1 : 3) - a * .5;
	}
	return n.kind === "activate" ? n.building === "giftShop" ? 12 : n.building === "diningRoom" ? n.fruit === "fruit" ? t.jam * 2 + 1 : t.fruited * 2 + 1 : n.building === "mouldCave" ? t.workers[2].delay * 2 - t.orders.length * .1 : n.building === "jammery" ? t.fruited * 1.5 - $(t, "fruit") : n.building === "feedlot" ? t.resources.fruit > 2 && t.resources.livestock < 5 ? 2 : -200 : n.building === "farmhouse" ? t.orders.length > 3 && t.resources.structure < 4 ? 2 : -200 : n.building === "tradingHouse" ? t.resources.structure > 5 && n.resource !== "order" ? $(t, n.resource) : -200 : $(t, n.resource ?? "order") - 1 : -200;
}
function ot(e = rt) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid), a = t.private?.choices ?? [];
		if (!i || !a.length) return null;
		let o;
		if (n.difficulty === "weak") {
			let e = a.filter((e) => ![
				"activate",
				"replace",
				"ready"
			].includes(e.kind)), t = e.length ? e : a.filter((e) => e.kind !== "replace"), n = t.length ? t : a;
			o = n[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % n.length];
		} else o = a.reduce((t, n) => at(r, i, n, e) > at(r, i, t, e) ? n : t);
		return { action: {
			type: "choose",
			id: o.id
		} };
	};
}
var st = ot(), ct = (e, t, n) => {
	let r = e.type === "choose" ? t.private?.choices.find((t) => t.id === e.id) : null;
	return r ? r.kind === "gather" ? n("games.fromage.gather", {
		n: r.count,
		resource: n(`games.fromage.${r.resource}`)
	}) : r.kind === "make" || r.kind === "milk" ? n("games.fromage.make") : r.kind === "complete" ? n("games.fromage.complete") : r.kind === "ready" ? n("games.fromage.ready") : r.kind === "skip" ? n("games.fromage.skip") : r.kind === "build" ? n("games.fromage.build") : r.kind === "draft" ? n("games.fromage.draft") : r.kind === "replace" ? n("games.fromage.replace") : r.kind === "corp" ? n("games.fromage.corp") : n("games.fromage.use") : "";
}, lt = {
	move(e, t) {
		let n = e.data, r = t.anchor(n.to) ?? t.anchor(`seat:${e.rid}`), i = t.anchor(n.from) ?? (n.from.startsWith("supply:") ? t.anchor("deck") : null) ?? t.anchor(`seat:${e.rid}`);
		if (!i || !r) return null;
		let a = t.queued ? 150 : 320, o = n.sprite === "order" ? "order" : n.sprite === "worker0" ? "soft-1" : n.sprite === "worker1" ? "hard-1" : n.sprite === "worker2" ? "bleu-1" : n.sprite === "corporation" ? "structure" : n.sprite;
		return {
			ms: a,
			node: /* @__PURE__ */ y(x, {
				from: i,
				to: r,
				ms: a,
				children: /* @__PURE__ */ b("span", {
					className: "fm-flying",
					children: [/* @__PURE__ */ y(Y, { name: o }), n.count > 1 && /* @__PURE__ */ y("b", { children: n.count })]
				})
			}),
			...t.queued ? {} : { hide: [n.to] }
		};
	},
	rotate(e, t) {
		let n = t.anchor("deck");
		return n ? {
			ms: Ce.rotate,
			node: /* @__PURE__ */ y(ee, {
				at: n,
				ms: Ce.rotate
			})
		} : null;
	}
}, ut = () => {};
function dt({ public: e, private: t, result: a, members: o, myRid: s, hintCount: c, onPlayAgain: f, onBackToLobby: m }) {
	let g = e, _ = Xe(), v = u(), x = l((e) => e.locale), [ee, S] = i(!0), [ae, C] = i(!1), w = r(null), T = r(null), E = r(null), D = (e) => {
		let t = o.find((t) => t.rid === e);
		return t ? d(t, x) : e;
	}, oe = (e) => {
		S(e), requestAnimationFrame(() => (e ? T : E).current?.focus({ preventScroll: !0 }));
	};
	n(() => {
		T.current?.focus({ preventScroll: !0 });
	}, []);
	let O = (e) => {
		if (e.key === "Escape" && (e.stopPropagation(), oe(!1)), e.key === "Tab") {
			let t = [...w.current?.querySelectorAll("button:not(:disabled),summary") ?? []].filter((e) => e.getClientRects().length), n = t[0], r = t.at(-1);
			e.shiftKey && document.activeElement === n && (e.preventDefault(), r?.focus()), !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
		}
	}, se = (e) => e === "fruit" ? _.fruitScore : e === "orders" ? _.orderScore : _[e];
	return /* @__PURE__ */ b("div", {
		className: "fm-root fm-endgame",
		children: [
			/* @__PURE__ */ y(ie, {}),
			/* @__PURE__ */ y("div", {
				className: "fm-final-board",
				inert: ee,
				children: /* @__PURE__ */ y($e, {
					public: g,
					private: t,
					members: o,
					myRid: s,
					send: ut
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "fm-result-layer",
				hidden: !ee,
				children: /* @__PURE__ */ b("section", {
					ref: w,
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "fm-ledger-title",
					className: "fm-ledger",
					onKeyDown: O,
					children: [
						/* @__PURE__ */ b("header", { children: [/* @__PURE__ */ b("span", { children: ["FROMAGE · ", _.name] }), /* @__PURE__ */ y("button", {
							ref: T,
							type: "button",
							"aria-label": _.reviewHide,
							title: _.reviewHide,
							onClick: () => oe(!1),
							children: /* @__PURE__ */ y(ne, { size: 20 })
						})] }),
						/* @__PURE__ */ b("div", {
							className: "fm-result-scroll",
							children: [
								/* @__PURE__ */ b("div", {
									className: "fm-result-hero",
									children: [
										/* @__PURE__ */ y(Y, { name: "cheese" }),
										/* @__PURE__ */ y("h1", {
											id: "fm-ledger-title",
											children: _.ledger
										}),
										/* @__PURE__ */ y("p", { children: a.winner.length ? Z(a.winner.length > 1 ? _.sharedWinner : _.winner, { names: a.winner.map(D).join(" · ") }) : _.companyWins })
									]
								}),
								/* @__PURE__ */ b("table", {
									className: "fm-scoretable",
									"aria-label": _.ledger,
									children: [
										/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
											scope: "col",
											children: _.score
										}), a.ranking.map((e) => /* @__PURE__ */ b("th", {
											scope: "col",
											"data-winner": a.winner.includes(e),
											children: [/* @__PURE__ */ y("strong", { children: D(e) }), !!a.autopilot?.[e] && /* @__PURE__ */ b("small", { children: [/* @__PURE__ */ y(te, { size: 11 }), v("session.autopilot.share", { n: Math.round(a.autopilot[e] * 100) })] })]
										}, e))] }) }),
										/* @__PURE__ */ y("tbody", { children: [
											"bistro",
											"fromagerie",
											"festival",
											"villes",
											"structures",
											"fruit",
											"orders",
											"unused"
										].map((e) => /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
											scope: "row",
											children: se(e)
										}), a.ranking.map((t) => /* @__PURE__ */ y("td", { children: g.scores[t][e] }, t))] }, e)) }),
										/* @__PURE__ */ y("tfoot", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
											scope: "row",
											children: _.total
										}), a.ranking.map((e) => /* @__PURE__ */ y("td", {
											"data-winner": a.winner.includes(e),
											children: g.scores[e].total
										}, e))] }) })
									]
								}),
								g.players.length === 1 && /* @__PURE__ */ b("div", {
									className: "fm-final-company",
									children: [
										/* @__PURE__ */ y(Y, { name: "structure" }),
										/* @__PURE__ */ y("b", { children: _.corpName }),
										/* @__PURE__ */ y("strong", { children: g.corpScore }),
										/* @__PURE__ */ b("span", { children: [
											g.corporation.used,
											" / ",
											[
												15,
												17,
												18,
												19
											][g.corporation.level - 1]
										] })
									]
								}),
								/* @__PURE__ */ b("details", {
									className: "fm-result-details",
									children: [/* @__PURE__ */ y("summary", { children: _.more }), g.players.map((e) => /* @__PURE__ */ b("div", { children: [
										/* @__PURE__ */ y("b", { children: D(e.rid) }),
										/* @__PURE__ */ y("span", { children: Z(_.cheeses, { n: e.placed }) }),
										/* @__PURE__ */ y("span", { children: Z(_.completed, { n: e.complete.length }) }),
										/* @__PURE__ */ y("span", { children: Z(_.fruitProduct, {
											n: e.fruited,
											m: e.jam
										}) })
									] }, e.rid))]
								}),
								/* @__PURE__ */ b("button", {
									className: "fm-result-log",
									onClick: () => C(!0),
									children: [/* @__PURE__ */ y(re, { size: 16 }), _.actionLog]
								})
							]
						}),
						/* @__PURE__ */ b("footer", { children: [c !== void 0 && /* @__PURE__ */ y("small", { children: v("session.hint.usedCount", { n: c }) }), /* @__PURE__ */ b("div", { children: [
							m && /* @__PURE__ */ y(p, {
								className: "fm-quiet",
								label: v("session.result.backToLobby"),
								confirmLabel: _.confirmLobby,
								onConfirm: m
							}),
							" ",
							f && /* @__PURE__ */ y(p, {
								className: "fm-primary",
								label: v("session.result.playAgain"),
								confirmLabel: _.confirmAgain,
								onConfirm: f
							}),
							" ",
							!m && !f && /* @__PURE__ */ y("p", { children: v("session.result.waitHost") })
						] })] })
					]
				})
			}),
			/* @__PURE__ */ b("button", {
				ref: E,
				className: "fm-result-restore fm-primary",
				type: "button",
				hidden: ee,
				onClick: () => oe(!0),
				children: [/* @__PURE__ */ y(re, { size: 16 }), _.reviewShow]
			}),
			ae && /* @__PURE__ */ y(h, {
				log: g.log,
				line: (e) => `${D(e.rid)} · ${Z(e.kind === "make" ? _.logMake : e.kind === "gather" ? _.logGather : e.kind === "build" ? _.logBuild : e.kind === "complete" ? _.logComplete : e.kind === "activate" ? _.logActivate : e.kind === "corp" ? _.logCorp : _.logCorpOrder, {
					venue: _[e.venue] ?? "",
					n: e.count ?? 0,
					building: Q(_, e.building ?? "")?.name ?? ""
				})}`,
				onClose: () => C(!1)
			})
		]
	});
}
//#endregion
//#region src/games/fromage/options.tsx
function ft({ value: e, onChange: t }) {
	let n = V.safeParse(e), r = n.success ? n.data : V.parse(void 0), i = Xe();
	return /* @__PURE__ */ b("div", { children: [
		/* @__PURE__ */ y(C, {
			label: i.advanced,
			checked: r.advanced,
			onChange: () => t({
				...r,
				advanced: !r.advanced
			}),
			accent: "#39796b"
		}),
		w.map((e) => /* @__PURE__ */ y(ae, {
			title: `${i[e]} · ${i.layout}`,
			columns: 2,
			children: [
				"I",
				"II",
				"random",
				"0"
			].map((n) => /* @__PURE__ */ y(S, {
				name: `fromage-${e}`,
				value: n,
				checked: r[e] === n,
				label: n === "random" ? i.random : n,
				accent: "#39796b",
				onChange: () => t({
					...r,
					[e]: n
				})
			}, n))
		}, e)),
		/* @__PURE__ */ y(ae, {
			title: i.level,
			columns: 2,
			children: [
				1,
				2,
				3,
				4
			].map((e) => /* @__PURE__ */ y(S, {
				name: "fromage-level",
				value: String(e),
				checked: r.soloLevel === e,
				label: String(e),
				accent: "#39796b",
				onChange: () => t({
					...r,
					soloLevel: e
				})
			}, e))
		}),
		/* @__PURE__ */ y("small", { children: i.soloNote })
	] });
}
//#endregion
//#region src/games/fromage/guide.tsx
function pt() {
	let e = Xe();
	return /* @__PURE__ */ b("div", {
		className: "fm-guide",
		children: [
			/* @__PURE__ */ y("div", {
				className: "fm-guide-types",
				children: [
					"soft",
					"hard",
					"bleu"
				].map((t) => /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("b", { children: e[t] }), [
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Y, { name: `${t}-${e}` }), e] }, e))] }, t))
			}),
			/* @__PURE__ */ b("table", { children: [/* @__PURE__ */ y("caption", { children: e.orderScore }), /* @__PURE__ */ b("tbody", { children: [/* @__PURE__ */ y("tr", { children: [
				1,
				2,
				3,
				4,
				5,
				6
			].map((e) => /* @__PURE__ */ y("th", { children: e }, e)) }), /* @__PURE__ */ y("tr", { children: [
				1,
				3,
				5,
				8,
				11,
				14
			].map((e) => /* @__PURE__ */ y("td", { children: e }, e)) })] })] }),
			/* @__PURE__ */ b("div", {
				className: "fm-guide-fruit",
				children: [
					/* @__PURE__ */ y(Y, { name: "fruit" }),
					e.fruited,
					" × ",
					/* @__PURE__ */ y(Y, { name: "jam" }),
					e.jam
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fromage/entry.tsx
var mt = {
	definition: Ke,
	View: $e,
	bot: st,
	describe: ct,
	fx: lt,
	OverView: dt,
	Options: ft,
	Guide: pt,
	locales: {
		zh: qe,
		en: Je
	}
};
//#endregion
export { mt as default };
