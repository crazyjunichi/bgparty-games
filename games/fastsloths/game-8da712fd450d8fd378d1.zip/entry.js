import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { GameOverScreen as m } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/fastsloths/boards.ts
var h = {
	A: {
		cols: [
			"RPPPMWFHFPPR",
			"PFFPPWPPPPP",
			"HPFFPPBRPFFP",
			"PFMPRWPPFHP",
			"PFHFPPWPFHHP",
			"PHHWBWPFFHM",
			"PFWWPPWPPMMM",
			"BWHFPRWWPPH",
			"RPFHPWWPFPPP",
			"PFMMPPWWFFP",
			"PFHFMPWFRFPR",
			"PFHMFPWFFPP",
			"PPHFFPWMFFPP",
			"PFHPPWWMWWB",
			"HPPPPWPWWPPP",
			"HRPRWWPWPHP",
			"HHPPBPPPPHHP",
			"HHPWPFFFHHP",
			"RHWWFFRFPPPR"
		],
		trees: [
			"-1,0",
			"-1,11",
			"15,6",
			"17,0",
			"17,11",
			"2,7",
			"7,11",
			"8,5",
			"9,0"
		],
		resorts: [
			"-1,0",
			"-1,11",
			"1,7",
			"14,1",
			"14,3",
			"17,0",
			"17,11",
			"17,6",
			"2,4",
			"6,5",
			"7,0",
			"9,11",
			"9,8"
		],
		bridges: [
			{
				cell: "6,0",
				ends: ["5,0", "7,0"]
			},
			{
				cell: "4,4",
				ends: ["3,4", "5,5"]
			},
			{
				cell: "1,6",
				ends: ["1,5", "1,7"]
			},
			{
				cell: "15,4",
				ends: ["14,3", "16,4"]
			},
			{
				cell: "12,10",
				ends: ["11,10", "13,11"]
			}
		],
		pathEdges: [
			["-1,0", "0,0"],
			["0,0", "0,0"],
			["0,0", "1,1"],
			["1,1", "2,0"],
			["2,0", "3,0"],
			["3,0", "4,0"],
			["4,0", "5,0"],
			["5,0", "6,0"],
			["6,0", "7,0"],
			["7,0", "8,0"],
			["8,0", "9,1"],
			["9,1", "10,0"],
			["10,0", "11,1"],
			["11,1", "12,0"],
			["12,0", "13,1"],
			["13,1", "14,1"],
			["14,1", "15,1"],
			["15,1", "16,0"],
			["16,0", "17,0"],
			["-1,0", "-1,1"],
			["-1,1", "-1,2"],
			["-1,2", "-1,3"],
			["-1,3", "0,3"],
			["0,3", "1,4"],
			["1,4", "2,4"],
			["1,5", "2,4"],
			["1,5", "1,6"],
			["1,6", "1,7"],
			["0,7", "1,7"],
			["0,7", "0,8"],
			["0,8", "0,9"],
			["0,9", "0,10"],
			["-1,11", "0,10"],
			["1,7", "2,6"],
			["2,6", "3,7"],
			["3,7", "4,7"],
			["4,7", "5,8"],
			["5,8", "6,8"],
			["6,8", "7,9"],
			["7,9", "8,8"],
			["8,8", "9,8"],
			["9,8", "9,9"],
			["9,9", "9,10"],
			["9,10", "9,11"],
			["9,8", "10,8"],
			["10,8", "11,9"],
			["11,9", "11,10"],
			["11,10", "12,10"],
			["12,10", "13,11"],
			["13,11", "14,10"],
			["14,10", "15,11"],
			["15,11", "16,10"],
			["16,10", "17,11"],
			["2,4", "3,4"],
			["3,4", "4,4"],
			["4,4", "5,5"],
			["5,5", "6,5"],
			["6,4", "6,5"],
			["6,4", "7,4"],
			["7,4", "8,4"],
			["8,4", "9,5"],
			["9,5", "10,4"],
			["10,4", "11,5"],
			["11,5", "12,4"],
			["12,4", "13,4"],
			["13,4", "14,3"],
			["14,3", "15,4"],
			["15,4", "16,4"],
			["16,4", "17,5"],
			["17,5", "17,6"],
			["17,6", "17,7"],
			["17,7", "17,8"],
			["17,8", "17,9"],
			["17,9", "17,10"],
			["17,10", "17,11"],
			["14,1", "14,2"],
			["14,2", "14,3"]
		],
		resortGraph: {
			edges: [
				["-1,0", "2,4"],
				["-1,0", "7,0"],
				["-1,11", "1,7"],
				["1,7", "2,4"],
				["1,7", "9,8"],
				["2,4", "6,5"],
				["6,5", "14,3"],
				["7,0", "14,1"],
				["9,8", "9,11"],
				["9,8", "17,11"],
				["14,1", "14,3"],
				["14,1", "17,0"],
				["14,3", "17,6"],
				["17,6", "17,11"]
			],
			paths: [
				[
					"-1,0",
					"-1,1",
					"-1,2",
					"-1,3",
					"0,3",
					"1,4",
					"2,4"
				],
				[
					"-1,0",
					"0,0",
					"0,0",
					"1,1",
					"2,0",
					"3,0",
					"4,0",
					"5,0",
					"6,0",
					"7,0"
				],
				[
					"-1,11",
					"0,10",
					"0,9",
					"0,8",
					"0,7",
					"1,7"
				],
				[
					"1,7",
					"1,6",
					"1,5",
					"2,4"
				],
				[
					"1,7",
					"2,6",
					"3,7",
					"4,7",
					"5,8",
					"6,8",
					"7,9",
					"8,8",
					"9,8"
				],
				[
					"2,4",
					"3,4",
					"4,4",
					"5,5",
					"6,5"
				],
				[
					"6,5",
					"6,4",
					"7,4",
					"8,4",
					"9,5",
					"10,4",
					"11,5",
					"12,4",
					"13,4",
					"14,3"
				],
				[
					"7,0",
					"8,0",
					"9,1",
					"10,0",
					"11,1",
					"12,0",
					"13,1",
					"14,1"
				],
				[
					"9,8",
					"9,9",
					"9,10",
					"9,11"
				],
				[
					"9,8",
					"10,8",
					"11,9",
					"11,10",
					"12,10",
					"13,11",
					"14,10",
					"15,11",
					"16,10",
					"17,11"
				],
				[
					"14,1",
					"14,2",
					"14,3"
				],
				[
					"14,1",
					"15,1",
					"16,0",
					"17,0"
				],
				[
					"14,3",
					"15,4",
					"16,4",
					"17,5",
					"17,6"
				],
				[
					"17,6",
					"17,7",
					"17,8",
					"17,9",
					"17,10",
					"17,11"
				]
			]
		}
	},
	B: {
		cols: [
			"RPHMHWWFHHHR",
			"PHMHFPWPPPF",
			"PHHHFPHWPFPF",
			"PHHHPPPBFPW",
			"PPPPPHHRWFPW",
			"PFRHMMHWPPW",
			"PFHFHHHFWWWW",
			"FFMMHHPWPPW",
			"RFMMRPPBPRPP",
			"PFMMPPWWFFP",
			"PPPPPBWPPPPR",
			"PPPPWPPRPPP",
			"HHHWWWWPFPPF",
			"HHWFPFWPPPF",
			"FFWFFHFWRPFH",
			"FWWFFWWPPHH",
			"FFPBWWPPHMHH",
			"FFPPPPPPHMH",
			"RPPPPPPRPPHR"
		],
		trees: [
			"-1,0",
			"-1,11",
			"1,5",
			"12,4",
			"17,0",
			"17,11",
			"7,11",
			"8,5",
			"9,0"
		],
		resorts: [
			"-1,0",
			"-1,11",
			"10,7",
			"13,8",
			"17,0",
			"17,11",
			"17,7",
			"3,7",
			"4,2",
			"7,0",
			"7,4",
			"7,9",
			"9,11"
		],
		bridges: [
			{
				cell: "2,7",
				ends: ["1,8", "3,7"]
			},
			{
				cell: "7,7",
				ends: ["7,6", "7,8"]
			},
			{
				cell: "9,5",
				ends: ["8,4", "10,5"]
			},
			{
				cell: "15,3",
				ends: ["14,3", "16,2"]
			}
		],
		pathEdges: [
			["-1,0", "0,0"],
			["-1,11", "0,10"],
			["0,0", "1,1"],
			["0,10", "1,10"],
			["1,1", "2,1"],
			["1,8", "1,9"],
			["1,8", "2,7"],
			["1,9", "1,10"],
			["2,1", "3,2"],
			["2,7", "3,7"],
			["3,2", "4,2"],
			["3,7", "4,6"],
			["4,1", "4,2"],
			["4,1", "5,1"],
			["4,2", "5,3"],
			["4,6", "5,6"],
			["5,1", "6,0"],
			["5,3", "6,3"],
			["5,5", "5,6"],
			["5,5", "6,4"],
			["6,0", "7,0"],
			["6,3", "7,4"],
			["6,4", "7,4"],
			["7,0", "8,0"],
			["7,4", "7,5"],
			["7,4", "8,4"],
			["7,5", "7,6"],
			["7,6", "7,7"],
			["7,7", "7,8"],
			["7,8", "7,9"],
			["7,9", "8,8"],
			["8,0", "9,1"],
			["8,4", "9,5"],
			["8,8", "9,8"],
			["9,1", "10,0"],
			["9,5", "10,5"],
			["9,8", "10,7"],
			["9,11", "10,10"],
			["10,0", "11,0"],
			["10,5", "10,6"],
			["10,6", "10,7"],
			["10,7", "10,8"],
			["10,7", "11,8"],
			["10,8", "10,9"],
			["10,9", "10,10"],
			["11,0", "12,0"],
			["11,8", "12,7"],
			["12,0", "13,1"],
			["12,7", "13,8"],
			["13,1", "14,0"],
			["13,8", "14,7"],
			["14,0", "15,1"],
			["14,7", "15,7"],
			["15,1", "16,0"],
			["15,7", "16,6"],
			["16,0", "17,0"],
			["16,6", "17,7"],
			["17,7", "17,8"],
			["17,8", "17,9"],
			["17,9", "17,10"],
			["17,10", "17,11"]
		],
		resortGraph: {
			edges: [
				["-1,0", "4,2"],
				["-1,11", "3,7"],
				["3,7", "7,4"],
				["4,2", "7,0"],
				["4,2", "7,4"],
				["7,0", "17,0"],
				["7,4", "7,9"],
				["7,4", "10,7"],
				["7,9", "10,7"],
				["9,11", "10,7"],
				["10,7", "13,8"],
				["13,8", "17,7"],
				["17,7", "17,11"]
			],
			paths: [
				[
					"-1,0",
					"0,0",
					"1,1",
					"2,1",
					"3,2",
					"4,2"
				],
				[
					"-1,11",
					"0,10",
					"1,10",
					"1,9",
					"1,8",
					"2,7",
					"3,7"
				],
				[
					"3,7",
					"4,6",
					"5,6",
					"5,5",
					"6,4",
					"7,4"
				],
				[
					"4,2",
					"4,1",
					"5,1",
					"6,0",
					"7,0"
				],
				[
					"4,2",
					"5,3",
					"6,3",
					"7,4"
				],
				[
					"7,0",
					"8,0",
					"9,1",
					"10,0",
					"11,0",
					"12,0",
					"13,1",
					"14,0",
					"15,1",
					"16,0",
					"17,0"
				],
				[
					"7,4",
					"7,5",
					"7,6",
					"7,7",
					"7,8",
					"7,9"
				],
				[
					"7,4",
					"8,4",
					"9,5",
					"10,5",
					"10,6",
					"10,7"
				],
				[
					"7,9",
					"8,8",
					"9,8",
					"10,7"
				],
				[
					"9,11",
					"10,10",
					"10,9",
					"10,8",
					"10,7"
				],
				[
					"10,7",
					"11,8",
					"12,7",
					"13,8"
				],
				[
					"13,8",
					"14,7",
					"15,7",
					"16,6",
					"17,7"
				],
				[
					"17,7",
					"17,8",
					"17,9",
					"17,10",
					"17,11"
				]
			]
		}
	},
	C: {
		cols: [
			"RPHMHWWFHHHR",
			"PHMHFPWPPPF",
			"PHHHFPHWPFPF",
			"PHHHPPPBFPW",
			"PPPPPHHRWFPW",
			"PFRHMMHWPPW",
			"PFHFHHHFWWWW",
			"FFMMHHPWPPW",
			"RFMMRPPBPRPP",
			"PFMMPPWWFFP",
			"PFHFMPWFRFPR",
			"PFHMFPWFFPP",
			"PPHFFPWMFFPP",
			"PFHPPWWMWWB",
			"HPPPPWPWWPPP",
			"HRPRWWPWPHP",
			"HHPPBPPPPHHP",
			"HHPWPFFFHHP",
			"RHWWFFRFPPPR"
		],
		trees: [
			"-1,0",
			"-1,11",
			"1,5",
			"15,6",
			"17,0",
			"17,11",
			"7,11",
			"8,5",
			"9,0"
		],
		resorts: [
			"-1,0",
			"-1,11",
			"14,1",
			"14,3",
			"17,0",
			"17,11",
			"17,6",
			"3,7",
			"4,2",
			"7,0",
			"7,4",
			"7,9",
			"9,11",
			"9,8"
		],
		bridges: [
			{
				cell: "2,7",
				ends: ["1,8", "3,7"]
			},
			{
				cell: "7,7",
				ends: ["7,6", "7,8"]
			},
			{
				cell: "12,10",
				ends: ["11,10", "13,11"]
			},
			{
				cell: "15,4",
				ends: ["14,3", "16,4"]
			}
		],
		pathEdges: [
			["-1,0", "0,0"],
			["-1,11", "0,10"],
			["0,0", "1,1"],
			["0,10", "1,10"],
			["1,1", "2,1"],
			["1,8", "1,9"],
			["1,8", "2,7"],
			["1,9", "1,10"],
			["2,1", "3,2"],
			["2,7", "3,7"],
			["3,2", "4,2"],
			["3,7", "4,6"],
			["4,1", "4,2"],
			["4,1", "5,1"],
			["4,2", "5,3"],
			["4,6", "5,6"],
			["5,1", "6,0"],
			["5,3", "6,3"],
			["5,5", "5,6"],
			["5,5", "6,4"],
			["6,0", "7,0"],
			["6,3", "7,4"],
			["6,4", "7,4"],
			["7,0", "8,0"],
			["7,4", "7,5"],
			["7,4", "8,4"],
			["7,5", "7,6"],
			["7,6", "7,7"],
			["7,7", "7,8"],
			["7,8", "7,9"],
			["7,9", "8,8"],
			["8,0", "9,1"],
			["8,4", "9,5"],
			["8,8", "9,8"],
			["9,1", "10,0"],
			["9,5", "10,4"],
			["9,8", "9,9"],
			["9,8", "10,8"],
			["9,9", "9,10"],
			["9,10", "9,11"],
			["10,0", "11,1"],
			["10,4", "11,5"],
			["10,8", "11,9"],
			["11,1", "12,0"],
			["11,5", "12,4"],
			["11,9", "11,10"],
			["11,10", "12,10"],
			["12,0", "13,1"],
			["12,4", "13,4"],
			["12,10", "13,11"],
			["13,1", "14,1"],
			["13,4", "14,3"],
			["13,11", "14,10"],
			["14,1", "14,2"],
			["14,1", "15,1"],
			["14,2", "14,3"],
			["14,3", "15,4"],
			["14,10", "15,11"],
			["15,1", "16,0"],
			["15,4", "16,4"],
			["15,11", "16,10"],
			["16,0", "17,0"],
			["16,4", "17,5"],
			["16,10", "17,11"],
			["17,5", "17,6"],
			["17,6", "17,7"],
			["17,7", "17,8"],
			["17,8", "17,9"],
			["17,9", "17,10"],
			["17,10", "17,11"]
		],
		resortGraph: {
			edges: [
				["-1,0", "4,2"],
				["-1,11", "3,7"],
				["3,7", "7,4"],
				["4,2", "7,0"],
				["4,2", "7,4"],
				["7,0", "14,1"],
				["7,4", "7,9"],
				["7,4", "14,3"],
				["7,9", "9,8"],
				["9,8", "9,11"],
				["9,8", "17,11"],
				["14,1", "14,3"],
				["14,1", "17,0"],
				["14,3", "17,6"],
				["17,6", "17,11"]
			],
			paths: [
				[
					"-1,0",
					"0,0",
					"1,1",
					"2,1",
					"3,2",
					"4,2"
				],
				[
					"-1,11",
					"0,10",
					"1,10",
					"1,9",
					"1,8",
					"2,7",
					"3,7"
				],
				[
					"3,7",
					"4,6",
					"5,6",
					"5,5",
					"6,4",
					"7,4"
				],
				[
					"4,2",
					"4,1",
					"5,1",
					"6,0",
					"7,0"
				],
				[
					"4,2",
					"5,3",
					"6,3",
					"7,4"
				],
				[
					"7,0",
					"8,0",
					"9,1",
					"10,0",
					"11,1",
					"12,0",
					"13,1",
					"14,1"
				],
				[
					"7,4",
					"7,5",
					"7,6",
					"7,7",
					"7,8",
					"7,9"
				],
				[
					"7,4",
					"8,4",
					"9,5",
					"10,4",
					"11,5",
					"12,4",
					"13,4",
					"14,3"
				],
				[
					"7,9",
					"8,8",
					"9,8"
				],
				[
					"9,8",
					"9,9",
					"9,10",
					"9,11"
				],
				[
					"9,8",
					"10,8",
					"11,9",
					"11,10",
					"12,10",
					"13,11",
					"14,10",
					"15,11",
					"16,10",
					"17,11"
				],
				[
					"14,1",
					"14,2",
					"14,3"
				],
				[
					"14,1",
					"15,1",
					"16,0",
					"17,0"
				],
				[
					"14,3",
					"15,4",
					"16,4",
					"17,5",
					"17,6"
				],
				[
					"17,6",
					"17,7",
					"17,8",
					"17,9",
					"17,10",
					"17,11"
				]
			]
		}
	},
	D: {
		cols: [
			"RPPPMWFHFPPR",
			"PFFPPWPPPPP",
			"HPFFPPBRPFFP",
			"PFMPRWPPFHP",
			"PFHFPPWPFHHP",
			"PHHWBWPFFHM",
			"PFWWPPWPPMMM",
			"BWHFPRWWPPH",
			"RPFHPWWPFPPP",
			"PFMMPPWWFFP",
			"PPPPPBWPPPPR",
			"PPPPWPPRPPP",
			"HHHWWWWPFPPF",
			"HHWFPFWPPPF",
			"FFWFFHFWRPFH",
			"FWWFFWWPPHH",
			"FFPBWWPPHMHH",
			"FFPPPPPPHMH",
			"RPPPPPPRPPHR"
		],
		trees: [
			"-1,0",
			"-1,11",
			"12,4",
			"17,0",
			"17,11",
			"2,7",
			"7,11",
			"8,5",
			"9,0"
		],
		resorts: [
			"-1,0",
			"-1,11",
			"1,7",
			"10,7",
			"13,8",
			"17,0",
			"17,11",
			"17,7",
			"2,4",
			"6,5",
			"7,0",
			"9,11"
		],
		bridges: [
			{
				cell: "1,6",
				ends: ["1,5", "1,7"]
			},
			{
				cell: "4,4",
				ends: ["3,4", "5,5"]
			},
			{
				cell: "6,0",
				ends: ["5,0", "7,0"]
			},
			{
				cell: "9,5",
				ends: ["8,4", "10,5"]
			},
			{
				cell: "15,3",
				ends: ["14,3", "16,2"]
			}
		],
		pathEdges: [
			["-1,0", "-1,1"],
			["-1,0", "0,0"],
			["-1,1", "-1,2"],
			["-1,2", "-1,3"],
			["-1,3", "0,3"],
			["-1,11", "0,10"],
			["0,0", "1,1"],
			["0,3", "1,4"],
			["0,7", "0,8"],
			["0,7", "1,7"],
			["0,8", "0,9"],
			["0,9", "0,10"],
			["1,1", "2,0"],
			["1,4", "2,4"],
			["1,5", "1,6"],
			["1,5", "2,4"],
			["1,6", "1,7"],
			["1,7", "2,6"],
			["2,0", "3,0"],
			["2,4", "3,4"],
			["2,6", "3,7"],
			["3,0", "4,0"],
			["3,4", "4,4"],
			["3,7", "4,7"],
			["4,0", "5,0"],
			["4,4", "5,5"],
			["4,7", "5,8"],
			["5,0", "6,0"],
			["5,5", "6,5"],
			["5,8", "6,8"],
			["6,0", "7,0"],
			["6,4", "6,5"],
			["6,4", "7,4"],
			["6,8", "7,9"],
			["7,0", "8,0"],
			["7,4", "8,4"],
			["7,9", "8,8"],
			["8,0", "9,1"],
			["8,4", "9,5"],
			["8,8", "9,8"],
			["9,1", "10,0"],
			["9,5", "10,5"],
			["9,8", "10,7"],
			["9,11", "10,10"],
			["10,0", "11,0"],
			["10,5", "10,6"],
			["10,6", "10,7"],
			["10,7", "10,8"],
			["10,7", "11,8"],
			["10,8", "10,9"],
			["10,9", "10,10"],
			["11,0", "12,0"],
			["11,8", "12,7"],
			["12,0", "13,1"],
			["12,7", "13,8"],
			["13,1", "14,0"],
			["13,8", "14,7"],
			["14,0", "15,1"],
			["14,7", "15,7"],
			["15,1", "16,0"],
			["15,7", "16,6"],
			["16,0", "17,0"],
			["16,6", "17,7"],
			["17,7", "17,8"],
			["17,8", "17,9"],
			["17,9", "17,10"],
			["17,10", "17,11"]
		],
		resortGraph: {
			edges: [
				["-1,0", "2,4"],
				["-1,0", "7,0"],
				["-1,11", "1,7"],
				["1,7", "2,4"],
				["1,7", "10,7"],
				["2,4", "6,5"],
				["6,5", "10,7"],
				["7,0", "17,0"],
				["9,11", "10,7"],
				["10,7", "13,8"],
				["13,8", "17,7"],
				["17,7", "17,11"]
			],
			paths: [
				[
					"-1,0",
					"-1,1",
					"-1,2",
					"-1,3",
					"0,3",
					"1,4",
					"2,4"
				],
				[
					"-1,0",
					"0,0",
					"1,1",
					"2,0",
					"3,0",
					"4,0",
					"5,0",
					"6,0",
					"7,0"
				],
				[
					"-1,11",
					"0,10",
					"0,9",
					"0,8",
					"0,7",
					"1,7"
				],
				[
					"1,7",
					"1,6",
					"1,5",
					"2,4"
				],
				[
					"1,7",
					"2,6",
					"3,7",
					"4,7",
					"5,8",
					"6,8",
					"7,9",
					"8,8",
					"9,8",
					"10,7"
				],
				[
					"2,4",
					"3,4",
					"4,4",
					"5,5",
					"6,5"
				],
				[
					"6,5",
					"6,4",
					"7,4",
					"8,4",
					"9,5",
					"10,5",
					"10,6",
					"10,7"
				],
				[
					"7,0",
					"8,0",
					"9,1",
					"10,0",
					"11,0",
					"12,0",
					"13,1",
					"14,0",
					"15,1",
					"16,0",
					"17,0"
				],
				[
					"9,11",
					"10,10",
					"10,9",
					"10,8",
					"10,7"
				],
				[
					"10,7",
					"11,8",
					"12,7",
					"13,8"
				],
				[
					"13,8",
					"14,7",
					"15,7",
					"16,6",
					"17,7"
				],
				[
					"17,7",
					"17,8",
					"17,9",
					"17,10",
					"17,11"
				]
			]
		}
	}
}, g = {
	0: {
		board: "A",
		species: [
			"donkey",
			"unicorn",
			"crocodile",
			"elephant",
			"eagle",
			"ant"
		],
		start: {
			donkey: [
				"-1,10",
				"14,6",
				"17,1"
			],
			unicorn: ["8,4"],
			crocodile: ["13,5", "2,6"],
			elephant: ["-1,1", "16,10"],
			eagle: ["8,2"],
			ant: [
				"1,2",
				"10,0",
				"12,0",
				"13,1",
				"13,3",
				"2,3",
				"5,5",
				"5,8",
				"7,9",
				"9,10"
			]
		}
	},
	1: {
		board: "B",
		species: [
			"rabbit",
			"human",
			"dolphin",
			"giraffe",
			"goat",
			"orangutan"
		],
		start: {
			rabbit: [
				"0,0",
				"7,10",
				"9,1"
			],
			human: ["10,7"],
			dolphin: ["8,7"],
			giraffe: ["1,10", "17,1"],
			goat: ["17,10", "5,2"],
			orangutan: [
				"-1,7",
				"0,3",
				"12,0",
				"12,3",
				"15,8",
				"6,5"
			]
		}
	},
	2: {
		board: "C",
		species: [
			"rabbit",
			"human",
			"crocodile",
			"elephant",
			"goat",
			"ant"
		],
		start: {
			rabbit: [
				"15,5",
				"16,2",
				"2,5"
			],
			human: ["17,0"],
			crocodile: ["12,8", "4,7"],
			elephant: ["10,0", "7,10"],
			goat: ["-1,1", "17,10"],
			ant: [
				"-1,9",
				"0,10",
				"0,7",
				"10,9",
				"12,1",
				"13,11",
				"13,3",
				"14,10",
				"14,2",
				"3,9"
			]
		}
	},
	3: {
		board: "D",
		species: [
			"donkey",
			"unicorn",
			"dolphin",
			"giraffe",
			"eagle",
			"orangutan"
		],
		start: {
			donkey: [
				"-1,1",
				"16,0",
				"7,10"
			],
			unicorn: ["8,0"],
			dolphin: ["7,5"],
			giraffe: ["0,9", "14,5"],
			eagle: ["8,3"],
			orangutan: [
				"11,8",
				"12,10",
				"13,1",
				"16,10",
				"3,2",
				"3,8"
			]
		}
	},
	6: {
		board: "A",
		species: [
			"donkey",
			"unicorn",
			"dolphin",
			"giraffe",
			"goat",
			"ant"
		],
		start: {
			donkey: [
				"0,0",
				"10,0",
				"8,10"
			],
			unicorn: ["9,5"],
			dolphin: ["12,10"],
			giraffe: ["17,10", "3,4"],
			goat: ["6,10", "8,0"],
			ant: [
				"0,10",
				"0,9",
				"1,8",
				"15,2",
				"15,4",
				"16,0",
				"16,4",
				"16,6",
				"3,8",
				"5,8"
			]
		}
	}
}, _ = [
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	4,
	4,
	5
], v = [
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7
], y = {
	donkey: {
		discs: 3,
		cards: _,
		mod: 0,
		terrain: [
			"R",
			"F",
			"H",
			"P"
		],
		bridge: "never",
		kind: "walk"
	},
	rabbit: {
		discs: 3,
		cards: [
			2,
			2,
			2,
			2,
			3,
			3,
			3,
			3,
			4,
			4
		],
		mod: 2,
		terrain: ["P"],
		bridge: "never",
		kind: "walk"
	},
	unicorn: {
		discs: 1,
		cards: v,
		mod: 0,
		terrain: [
			"R",
			"H",
			"P",
			"M"
		],
		bridge: "land",
		singleCard: !0,
		kind: "walk"
	},
	human: {
		discs: 1,
		cards: _,
		mod: 0,
		terrain: ["R"],
		bridge: "never",
		kind: "human"
	},
	crocodile: {
		discs: 2,
		cards: _,
		mod: 1,
		terrain: [
			"W",
			"R",
			"F",
			"P"
		],
		bridge: "water",
		kind: "walk"
	},
	dolphin: {
		discs: 1,
		cards: v,
		mod: 0,
		terrain: ["W"],
		bridge: "water",
		kind: "walk"
	},
	elephant: {
		discs: 2,
		cards: _,
		mod: -1,
		terrain: ["P", "W"],
		bridge: "water",
		kind: "elephant"
	},
	giraffe: {
		discs: 2,
		cards: _,
		mod: 0,
		terrain: ["P", "W"],
		bridge: "water",
		kind: "giraffe"
	},
	eagle: {
		discs: 1,
		cards: [
			2,
			2,
			2,
			3,
			3,
			3,
			3,
			4,
			4,
			4
		],
		mod: 0,
		terrain: [
			"R",
			"F",
			"H",
			"P",
			"M"
		],
		bridge: "land",
		kind: "eagle"
	},
	goat: {
		discs: 2,
		cards: _,
		mod: 0,
		terrain: [
			"R",
			"F",
			"H",
			"P",
			"M"
		],
		bridge: "land",
		kind: "walk"
	},
	ant: {
		discs: 10,
		cards: _,
		mod: 0,
		terrain: [
			"R",
			"F",
			"H",
			"P"
		],
		bridge: "land",
		multiDisc: !0,
		kind: "ant"
	},
	orangutan: {
		discs: 6,
		cards: _,
		mod: 0,
		terrain: ["F", "H"],
		bridge: "never",
		multiDisc: !0,
		kind: "orangutan"
	}
};
Object.keys(y);
var b = [
	{
		draw: 3,
		discard1: !1,
		limit: 7
	},
	{
		draw: 3,
		discard1: !0,
		limit: 7
	},
	{
		draw: 3,
		discard1: !0,
		limit: 6
	},
	{
		draw: 2,
		discard1: !1,
		limit: 6
	},
	{
		draw: 2,
		discard1: !1,
		limit: 5
	},
	{
		draw: 2,
		discard1: !1,
		limit: 5
	},
	{
		draw: 2,
		discard1: !0,
		limit: 4
	},
	{
		draw: 2,
		discard1: !0,
		limit: 4
	}
];
function x(e) {
	return b[Math.min(Math.max(e, 1), 8) - 1];
}
var S = {
	donkey: "#b08968",
	rabbit: "#9d4edd",
	unicorn: "#ff70a6",
	human: "#e05a6d",
	crocodile: "#2e933c",
	dolphin: "#3a86ff",
	elephant: "#8d99ae",
	giraffe: "#e9c46a",
	eagle: "#7bdff2",
	goat: "#e8e0d0",
	ant: "#9b2226",
	orangutan: "#7f4f24"
}, ee = {
	donkey: "games.fastsloths.spDonkey",
	rabbit: "games.fastsloths.spRabbit",
	unicorn: "games.fastsloths.spUnicorn",
	human: "games.fastsloths.spHuman",
	crocodile: "games.fastsloths.spCrocodile",
	dolphin: "games.fastsloths.spDolphin",
	elephant: "games.fastsloths.spElephant",
	giraffe: "games.fastsloths.spGiraffe",
	eagle: "games.fastsloths.spEagle",
	goat: "games.fastsloths.spGoat",
	ant: "games.fastsloths.spAnt",
	orangutan: "games.fastsloths.spOrangutan"
};
//#endregion
//#region src/games/fastsloths/grid.ts
function C(e) {
	let t = e.indexOf(",");
	return [Number(e.slice(0, t)), Number(e.slice(t + 1))];
}
function w(e, t) {
	return `${e},${t}`;
}
function T(e) {
	return e % 2 == 0 ? 11 : 12;
}
function E(e, t) {
	return e >= -1 && e <= 17 && t >= 0 && t < T(e);
}
function D(e) {
	let [t, n] = C(e), r = t % 2 == 0 ? [
		[t - 1, n],
		[t - 1, n + 1],
		[t + 1, n],
		[t + 1, n + 1],
		[t, n - 1],
		[t, n + 1]
	] : [
		[t - 1, n - 1],
		[t - 1, n],
		[t + 1, n - 1],
		[t + 1, n],
		[t, n - 1],
		[t, n + 1]
	], i = [];
	for (let [e, t] of r) E(e, t) && i.push(w(e, t));
	return i;
}
function O(e, t) {
	let [n, r] = C(t);
	return e.cols[n + 1].charAt(r);
}
function k(e, t) {
	let n = O(e, t);
	return n === "W" || n === "B";
}
function A(e, t) {
	return e.trees.includes(t);
}
function j(e, t) {
	return e.bridges.find((e) => e.cell === t);
}
function M(e, t, n, r) {
	if (t === n) return !1;
	let i = [t], a = /* @__PURE__ */ new Set([t]);
	for (let t = 1; t <= r; t += 1) {
		let t = [];
		for (let r of i) for (let i of D(r)) if (!a.has(i)) {
			if (a.add(i), i === n) return !0;
			O(e, i) !== "M" && t.push(i);
		}
		i = t;
	}
	return !1;
}
function N(e) {
	return e === "R" || e === "F" || e === "H" || e === "P" || e === "B";
}
function te(e) {
	let [t, n] = C(e), r = t + 1;
	return [1.5 * r, Math.sqrt(3) * (n + r % 2 * .5)];
}
(() => {
	let e = 0, t = 0;
	for (let n = -1; n <= 17; n += 1) for (let r = 0; r < T(n); r += 1) {
		let [i, a] = te(w(n, r));
		e = Math.max(e, i), t = Math.max(t, a);
	}
	return `-1.6 -1.4 ${(e + 3.2).toFixed(2)} ${(t + 2.8).toFixed(2)}`;
})();
function P(e, t) {
	let n = [];
	for (let [r, i] of e.resortGraph.edges) r === t ? n.push(i) : i === t && n.push(r);
	return n;
}
function F(e, t, n) {
	for (let r of e.resortGraph.paths) {
		if (r[0] === t && r[r.length - 1] === n) return r;
		if (r[0] === n && r[r.length - 1] === t) return [...r].reverse();
	}
	return null;
}
//#endregion
//#region src/games/fastsloths/move.ts
function ne(e, t, n, r, i, a) {
	return {
		board: e,
		sp: t,
		total: n,
		left: n,
		discs: [...r],
		others: i,
		sloth: a,
		carried: !1,
		picked: !1,
		dropped: !1,
		active: -1,
		usedAnts: /* @__PURE__ */ new Set(),
		phase2: !1,
		lastHopPath: null,
		eagle: "none",
		flyLeft: 0,
		leafCells: []
	};
}
function I(e, t, n) {
	let r = y[t], i = O(e, n);
	return i === "B" ? r.bridge === "land" || r.bridge === "water" && r.terrain.includes("W") : r.terrain.includes(i) ? t === "crocodile" && (i === "R" || i === "F" || i === "P") ? D(n).some((t) => k(e, t)) : !0 : !1;
}
function re(e, t, n, r) {
	if (!D(n).includes(r)) return "errStep";
	if (!I(e, t, r)) return "errTerrain";
	if (y[t].bridge === "land") {
		let t = O(e, r), i = O(e, n);
		if (t === "B" && !j(e, r)?.ends.includes(n) || i === "B" && !j(e, n)?.ends.includes(r)) return "errBridge";
	}
	if (t === "crocodile" && !k(e, n) && !k(e, r)) {
		let t = new Set(D(r));
		if (!D(n).some((n) => t.has(n) && k(e, n))) return "errCroc";
	}
	return null;
}
function ie(e, t, n) {
	return t === "goat" && O(e, n) === "M" ? 0 : 1;
}
function L(e, t) {
	A(e.board, t) && e.leafCells.push(t);
}
function R(e, t) {
	let n = y[e.sp];
	if (t < 0 || t >= e.discs.length) return "errDisc";
	if (n.multiDisc) return null;
	if (e.active === -1) e.active = t;
	else if (e.active !== t) return "errDisc";
	return null;
}
function z(e, t, n) {
	if (n === t) return !0;
	let r = y[e.sp];
	return O(e.board, t) === "B" && r.bridge === "land" ? j(e.board, t)?.ends.includes(n) ?? !1 : D(t).includes(n);
}
function ae(e, t) {
	let n = y[e.sp];
	switch (t.k) {
		case "step": {
			if (e.dropped || e.phase2 || n.kind === "human" || n.kind === "eagle") return "errOrder";
			let r = R(e, t.disc);
			if (r) return r;
			let i = e.discs[t.disc], a = re(e.board, e.sp, i, t.to);
			if (a) return a;
			let o = ie(e.board, e.sp, t.to);
			return o === 0 && e.left <= 0 || e.left < o ? "errPoints" : (e.left -= o, e.discs[t.disc] = t.to, e.carried && L(e, t.to), null);
		}
		case "pickup": {
			if (n.kind !== "walk" && n.kind !== "elephant" && n.kind !== "human" || e.carried || e.dropped) return "errOrder";
			let r = R(e, t.disc);
			if (r) return r;
			let i = e.discs[t.disc], a = z(e, i, e.sloth);
			return !a && n.kind === "human" && e.lastHopPath && (a = e.lastHopPath.some((t) => e.sloth === t || D(t).includes(e.sloth))), a ? (e.carried = !0, e.picked = !0, L(e, e.sloth), e.lastHopPath = null, null) : "errSloth";
		}
		case "drop": {
			if (!e.carried || n.kind === "giraffe" || n.kind === "ant" || n.kind === "orangutan") return "errOrder";
			let r = e.discs[e.active === -1 ? 0 : e.active];
			if (n.kind === "eagle") {
				if (e.eagle !== "flying") return "errOrder";
				if (e.others.has(r)) return "errOccupied";
				if (O(e.board, r) === "W") return "errTerrain";
			}
			return z(e, r, t.to) ? N(O(e.board, t.to)) ? (n.kind === "eagle" && L(e, r), e.sloth = t.to, e.carried = !1, e.dropped = !0, n.kind === "eagle" && (e.eagle = "done"), L(e, t.to), null) : "errDropCell" : "errSloth";
		}
		case "neckPick": {
			if (n.kind !== "giraffe" || e.carried || e.dropped) return "errOrder";
			let r = R(e, t.disc);
			if (r) return r;
			let i = e.discs[t.disc];
			return e.sloth !== i && !M(e.board, i, e.sloth, 2) ? "errSloth" : (e.carried = !0, e.picked = !0, L(e, e.sloth), null);
		}
		case "neckDrop": {
			if (n.kind !== "giraffe" || !e.carried) return "errOrder";
			let r = e.discs[e.active];
			return t.to !== r && !M(e.board, r, t.to, 2) ? "errStep" : N(O(e.board, t.to)) ? (e.sloth = t.to, e.carried = !1, e.dropped = !0, L(e, t.to), null) : "errDropCell";
		}
		case "throw": {
			if (n.kind !== "elephant" && n.kind !== "orangutan") return "errOrder";
			if (t.disc < 0 || t.disc >= e.discs.length) return "errDisc";
			let r = e.discs[t.disc];
			if (n.kind === "elephant") {
				if (!e.carried || e.dropped) return "errOrder";
				if (e.active !== t.disc) return "errDisc";
			} else {
				if (e.phase2 = !0, e.left < 2) return "errPoints";
				if (e.left -= 2, e.sloth !== r && !D(r).includes(e.sloth)) return "errSloth";
			}
			return t.to !== r && !M(e.board, r, t.to, 3) ? "errStep" : N(O(e.board, t.to)) ? (e.sloth = t.to, n.kind === "elephant" && (e.carried = !1, e.dropped = !0), L(e, t.to), null) : "errDropCell";
		}
		case "carry": {
			if (n.kind !== "ant") return "errOrder";
			if (e.phase2 = !0, e.left < 1) return "errPoints";
			if (t.ants.length === 0) return "errChain";
			let r = /* @__PURE__ */ new Set();
			for (let n of t.ants) {
				if (n < 0 || n >= e.discs.length || e.usedAnts.has(n) || r.has(n)) return "errChain";
				r.add(n);
			}
			let i = t.ants.map((t) => e.discs[t]), a = (e, t) => D(e).includes(t), o = [i[0]], s = /* @__PURE__ */ new Set([i[0]]);
			for (; o.length;) {
				let e = o.pop();
				for (let t of i) !s.has(t) && a(e, t) && (s.add(t), o.push(t));
			}
			if (s.size !== i.length) return "errChain";
			if (!i.some((t) => e.sloth === t || D(t).includes(e.sloth)) || !i.some((e) => t.to === e || D(e).includes(t.to))) return "errSloth";
			if (!N(O(e.board, t.to))) return "errDropCell";
			--e.left;
			for (let n of t.ants) e.usedAnts.add(n);
			return e.sloth = t.to, L(e, t.to), null;
		}
		case "hop": {
			if (n.kind !== "human" || e.dropped) return "errOrder";
			let r = e.discs[0];
			if (!P(e.board, r).includes(t.to)) return "errStep";
			if (e.left < 3) return "errPoints";
			e.left -= 3;
			let i = F(e.board, r, t.to);
			if (e.discs[0] = t.to, e.carried && i) for (let t of i) L(e, t);
			return e.lastHopPath = i, null;
		}
		case "fetch": return n.kind !== "eagle" || e.eagle !== "none" ? "errOrder" : e.total < 6 ? "errEagle" : e.sloth !== t.to && !D(e.sloth).includes(t.to) ? "errSloth" : O(e.board, t.to) === "W" ? "errTerrain" : (e.discs[0] = t.to, e.eagle = "flying", e.flyLeft = 6, e.carried = !0, e.picked = !0, L(e, e.sloth), null);
		case "fly": {
			if (n.kind !== "eagle" || e.eagle !== "flying") return "errOrder";
			if (e.flyLeft <= 0) return "errPoints";
			let r = e.discs[0];
			return D(r).includes(t.to) ? (--e.flyLeft, e.discs[0] = t.to, null) : "errStep";
		}
	}
}
function oe(e) {
	if (e.carried) return "errCarried";
	let t = /* @__PURE__ */ new Set();
	for (let n of e.discs) {
		if (t.has(n) || e.others.has(n)) return "errOccupied";
		t.add(n);
	}
	return null;
}
function B(e, t, n, r, i, a, o) {
	let s = ne(e, t, n, r, i, a);
	for (let e of o) {
		let t = ae(s, e);
		if (t) return { err: t };
	}
	let c = oe(s);
	return c ? { err: c } : {
		discs: s.discs,
		sloth: s.sloth,
		leafCells: s.leafCells
	};
}
function V() {
	let e = [];
	for (let t = -1; t <= 17; t += 1) {
		let n = t % 2 == 0 ? 11 : 12;
		for (let r = 0; r < n; r += 1) e.push(`${t},${r}`);
	}
	return e;
}
function se(e) {
	let t = y[e.sp], n = {
		steps: [],
		pickup: [],
		drop: [],
		neckPick: [],
		neckDrop: [],
		throws: [],
		hops: [],
		fetch: [],
		fly: []
	};
	if (e.dropped) return n;
	let r = V();
	if (!e.phase2 && t.kind !== "human" && t.kind !== "eagle") {
		for (let r = 0; r < e.discs.length; r += 1) if (t.multiDisc || e.active === -1 || e.active === r) for (let t of D(e.discs[r])) {
			if (re(e.board, e.sp, e.discs[r], t)) continue;
			let i = ie(e.board, e.sp, t);
			i === 0 && e.left <= 0 || e.left < i || n.steps.push({
				disc: r,
				to: t
			});
		}
	}
	if ((t.kind === "walk" || t.kind === "elephant" || t.kind === "human") && !e.carried) for (let r = 0; r < e.discs.length; r += 1) {
		if (!t.multiDisc && e.active !== -1 && e.active !== r) continue;
		let i = e.discs[r], a = z(e, i, e.sloth);
		!a && t.kind === "human" && e.lastHopPath && (a = e.lastHopPath.some((t) => e.sloth === t || D(t).includes(e.sloth))), a && n.pickup.push(r);
	}
	if (e.carried && (t.kind === "walk" || t.kind === "elephant" || t.kind === "human" || t.kind === "eagle")) {
		let r = e.discs[e.active === -1 ? 0 : e.active];
		if (t.kind !== "eagle" || e.eagle === "flying" && !e.others.has(r) && O(e.board, r) !== "W") for (let t of [r, ...D(r)]) z(e, r, t) && N(O(e.board, t)) && n.drop.push(t);
	}
	if (t.kind === "giraffe") {
		if (e.carried) {
			let t = e.discs[e.active];
			for (let i of r) N(O(e.board, i)) && (i === t || M(e.board, t, i, 2)) && n.neckDrop.push(i);
		} else for (let t = 0; t < e.discs.length; t += 1) {
			if (e.active !== -1 && e.active !== t) continue;
			let r = e.discs[t];
			(e.sloth === r || M(e.board, r, e.sloth, 2)) && n.neckPick.push(t);
		}
	}
	if (t.kind === "elephant" && e.carried) {
		let t = e.discs[e.active];
		for (let i of r) N(O(e.board, i)) && (i === t || M(e.board, t, i, 3)) && n.throws.push({
			disc: e.active,
			to: i
		});
	}
	if (t.kind === "orangutan" && e.left >= 2 && !e.carried) for (let t = 0; t < e.discs.length; t += 1) {
		let i = e.discs[t];
		if (e.sloth === i || D(i).includes(e.sloth)) for (let a of r) N(O(e.board, a)) && (a === i || M(e.board, i, a, 3)) && n.throws.push({
			disc: t,
			to: a
		});
	}
	return t.kind === "human" && e.left >= 3 && (n.hops = P(e.board, e.discs[0])), t.kind === "eagle" && (e.eagle === "none" && e.total >= 6 ? n.fetch = [e.sloth, ...D(e.sloth)].filter((t) => O(e.board, t) !== "W") : e.eagle === "flying" && e.flyLeft > 0 && (n.fly = D(e.discs[0]))), n;
}
function ce(e, t) {
	let n = [], r = [];
	if (e.left < 1) return {
		add: n,
		to: r
	};
	let i = new Set(t);
	for (let r = 0; r < e.discs.length; r += 1) {
		if (e.usedAnts.has(r) || i.has(r)) continue;
		let a = e.discs[r];
		t.length === 0 ? (e.sloth === a || D(a).includes(e.sloth)) && n.push(r) : t.some((t) => D(e.discs[t]).includes(a)) && n.push(r);
	}
	if (t.length > 0) {
		let n = t.map((t) => e.discs[t]);
		if (n.some((t) => e.sloth === t || D(t).includes(e.sloth))) {
			let t = /* @__PURE__ */ new Set();
			for (let r of n) for (let n of [r, ...D(r)]) N(O(e.board, n)) && t.add(n);
			r.push(...t);
		}
	}
	return {
		add: n,
		to: r
	};
}
//#endregion
//#region src/games/fastsloths/meta.ts
var H = {
	id: "fastsloths",
	tier: "beta",
	mechanics: ["race"],
	interactionTags: [],
	nameKey: "games.fastsloths.name",
	descKey: "games.fastsloths.desc",
	rulesKey: "games.fastsloths.rules",
	icon: "🦥",
	iconImg: "games/fastsloths.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/fastsloths/en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#65a30d",
	releasedAt: "2026-10-07",
	search: {
		py: "shu lan kuai pao",
		init: "slkp"
	},
	hotseat: "cover"
}, U = t.string().regex(/^-?\d+,\d+$/), W = t.enum([
	"donkey",
	"rabbit",
	"unicorn",
	"human",
	"crocodile",
	"dolphin",
	"elephant",
	"giraffe",
	"eagle",
	"goat",
	"ant",
	"orangutan"
]), le = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("step"),
		disc: t.int().nonnegative(),
		to: U
	}),
	t.object({
		k: t.literal("pickup"),
		disc: t.int().nonnegative()
	}),
	t.object({
		k: t.literal("drop"),
		to: U
	}),
	t.object({
		k: t.literal("neckPick"),
		disc: t.int().nonnegative()
	}),
	t.object({
		k: t.literal("neckDrop"),
		to: U
	}),
	t.object({
		k: t.literal("throw"),
		disc: t.int().nonnegative(),
		to: U
	}),
	t.object({
		k: t.literal("carry"),
		ants: t.array(t.int().nonnegative()).min(1).max(10),
		to: U
	}),
	t.object({
		k: t.literal("hop"),
		to: U
	}),
	t.object({
		k: t.literal("fetch"),
		to: U
	}),
	t.object({
		k: t.literal("fly"),
		to: U
	})
]), ue = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("pickTree"),
		cell: U
	}),
	t.object({
		type: t.literal("placeDisc"),
		species: W,
		cell: U
	}),
	t.object({
		type: t.literal("draw"),
		piles: t.array(W).max(3)
	}),
	t.object({
		type: t.literal("discard"),
		cards: t.array(t.object({
			sp: W,
			v: t.int().min(2).max(7)
		})).min(1).max(8)
	}),
	t.object({
		type: t.literal("play"),
		species: W,
		cards: t.array(t.int().min(2).max(7)).min(1).max(8),
		plan: t.array(le).min(1).max(80)
	}),
	t.object({ type: t.literal("pass") })
]), G = [
	"donkey",
	"unicorn",
	"crocodile",
	"elephant",
	"eagle",
	"ant"
], K = t.object({
	mode: t.enum(["scenario", "draft"]).default("scenario"),
	scenario: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.literal(3),
		t.literal(6)
	]).default(0),
	board: t.enum([
		"A",
		"B",
		"C",
		"D"
	]).default("A"),
	species: t.array(W).length(6).default([...G])
}).default({
	mode: "scenario",
	scenario: 0,
	board: "A",
	species: [...G]
}), q = t.string(), de = t.object({
	sp: W,
	v: t.int()
}), fe = t.object({
	board: t.enum([
		"A",
		"B",
		"C",
		"D"
	]),
	species: t.array(W),
	piles: t.partialRecord(W, t.object({
		top: t.int().nullable(),
		count: t.int().nonnegative()
	})),
	discs: t.partialRecord(W, t.array(U)),
	sloths: t.record(q, U),
	treeLeaves: t.record(U, t.array(q)),
	leaves: t.record(q, t.int().nonnegative()),
	handCounts: t.record(q, t.int().nonnegative()),
	turn: q,
	phase: t.enum([
		"setup",
		"turn",
		"done"
	]),
	turnPhase: t.enum([
		"draw",
		"discard1",
		"play",
		"limit"
	]).nullable(),
	setup: t.object({
		rid: q,
		kind: t.enum(["tree", "disc"]),
		supply: t.partialRecord(W, t.int().nonnegative())
	}).nullable(),
	final: t.boolean()
}), pe = t.object({ hand: t.array(de) }), J = (e) => ({ code: `games.fastsloths.${e}` });
function me(t, n, r) {
	let i = K.parse(t), a = e(r, 0, n.length), o = [...n.slice(a), ...n.slice(0, a)], s, c, l = {}, u = {}, d = [], f = [...o].reverse();
	if (i.mode === "draft") {
		s = i.board;
		let e = [...new Set(i.species)];
		c = e.length === 6 ? e : [
			"donkey",
			"unicorn",
			"crocodile",
			"elephant",
			"eagle",
			"ant"
		];
		for (let e of c) u[e] = y[e].discs;
		for (let e of c) l[e] = [];
		for (let e of f) d.push({
			kind: "tree",
			rid: e
		}, {
			kind: "disc",
			rid: e
		});
		let t = c.reduce((e, t) => e + y[t].discs, 0) - n.length, r = 0;
		for (; t > 0;) d.push({
			kind: "disc",
			rid: f[r % f.length]
		}), r += 1, --t;
	} else {
		let e = g[i.scenario];
		s = e.board, c = [...e.species];
		for (let t of c) l[t] = [...e.start[t] ?? []];
		for (let e of f) d.push({
			kind: "tree",
			rid: e
		});
	}
	let p = h[s], m = {};
	for (let e of c) m[e] = [...y[e].cards];
	let _ = {};
	for (let e of p.trees) _[e] = [...n];
	let v = {}, b = {};
	for (let e of n) v[e] = 0, b[e] = [];
	return {
		state: {
			players: o,
			board: s,
			species: c,
			piles: m,
			discs: l,
			sloths: {},
			treeLeaves: _,
			leaves: v,
			hands: b,
			turn: o[0],
			phase: "setup",
			turnPhase: null,
			setup: {
				steps: d,
				supply: u
			},
			final: null,
			rngCursor: 1
		},
		fx: []
	};
}
function he(e) {
	if (e.final) {
		let t = e.final.shift();
		if (!t) {
			e.phase = "done", e.turnPhase = null;
			return;
		}
		e.turn = t;
	} else {
		let t = e.players.indexOf(e.turn);
		e.turn = e.players[(t + 1) % e.players.length];
	}
	e.turnPhase = "draw";
}
function ge(e) {
	let t = x(e.leaves[e.turn]);
	e.hands[e.turn].length > t.limit ? e.turnPhase = "limit" : he(e);
}
function _e(e, t, n) {
	let r = e.treeLeaves[n];
	r?.includes(t) && (e.treeLeaves[n] = r.filter((e) => e !== t), e.leaves[t] = Math.min(e.leaves[t] + 1, 9));
}
function ve(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = n.get(e.sp) ?? [];
		t.push(e.v), n.set(e.sp, t);
	}
	for (let [t, r] of n) {
		let n = e.piles[t];
		n && n.push(...r.sort((e, t) => e - t));
	}
}
function ye(e, t, n) {
	let r = [...e.hands[t]];
	for (let e of n) {
		let t = r.findIndex((t) => t.sp === e.sp && t.v === e.v);
		if (t < 0) return !1;
		r.splice(t, 1);
	}
	return e.hands[t] = r, !0;
}
function be(e) {
	e.setup = null, e.phase = "turn", e.turnPhase = "draw", e.turn = e.players[0];
}
function xe(e, t, n) {
	if (t.type === "tick") return {
		state: e,
		fx: []
	};
	let r = structuredClone(e);
	if (t.type === "pickTree") {
		let e = r.setup?.steps[0];
		return r.phase !== "setup" || !e || e.kind !== "tree" ? J("errPhase") : e.rid === n.by ? h[r.board].trees.includes(t.cell) ? Object.values(r.sloths).includes(t.cell) ? J("errTree") : (r.sloths[n.by] = t.cell, _e(r, n.by, t.cell), r.setup?.steps.shift(), r.setup && r.setup.steps.length === 0 && be(r), {
			state: r,
			fx: []
		}) : J("errCell") : J("errTurn");
	}
	if (t.type === "placeDisc") {
		let e = r.setup?.steps[0];
		if (r.phase !== "setup" || !e || e.kind !== "disc") return J("errPhase");
		if (e.rid !== n.by) return J("errTurn");
		let i = t.species;
		if (!r.species.includes(i) || !(r.setup?.supply[i] ?? 0)) return J("errSpecies");
		let a = h[r.board];
		return I(a, i, t.cell) ? Y(r).has(t.cell) ? J("errOccupied") : (r.discs[i]?.push(t.cell), r.setup && (r.setup.supply[i] = (r.setup.supply[i] ?? 1) - 1, r.setup.steps.shift(), r.setup.steps.length === 0 && be(r)), {
			state: r,
			fx: []
		}) : J("errTerrain");
	}
	if (r.phase !== "turn" || r.turn !== n.by) return J("errTurn");
	if (t.type === "draw") {
		if (r.turnPhase !== "draw") return J("errPhase");
		let e = x(r.leaves[n.by]), i = r.species.filter((e) => (r.piles[e]?.length ?? 0) > 0), a = Math.min(e.draw, i.length), o = t.piles;
		if (o.length !== a || new Set(o).size !== o.length) return J("errPiles");
		for (let e of o) {
			let t = r.piles[e];
			if (!t || t.length === 0) return J("errPiles");
		}
		for (let e of o) {
			let t = r.piles[e]?.shift();
			t !== void 0 && r.hands[n.by].push({
				sp: e,
				v: t
			});
		}
		return r.turnPhase = e.discard1 ? "discard1" : "play", {
			state: r,
			fx: []
		};
	}
	if (t.type === "discard") {
		if (r.turnPhase === "discard1") {
			if (t.cards.length !== 1) return J("errDiscard");
		} else if (r.turnPhase === "limit") {
			let e = x(r.leaves[n.by]);
			if (r.hands[n.by].length - t.cards.length !== e.limit) return J("errDiscard");
		} else return J("errPhase");
		return ye(r, n.by, t.cards) ? (ve(r, t.cards), r.turnPhase === "discard1" ? r.turnPhase = "play" : he(r), {
			state: r,
			fx: []
		}) : J("errCard");
	}
	if (t.type === "pass") return r.turnPhase === "play" ? (ge(r), {
		state: r,
		fx: []
	}) : J("errPhase");
	if (r.turnPhase !== "play") return J("errPhase");
	let i = t.species;
	if (!r.species.includes(i)) return J("errSpecies");
	let a = y[i];
	if (a.singleCard && t.cards.length !== 1) return J("errCard");
	let o = t.cards.map((e) => ({
		sp: i,
		v: e
	}));
	if (!ye(r, n.by, o)) return J("errCard");
	let s = t.cards.reduce((e, t) => e + t, 0) + a.mod, c = h[r.board], l = Y(r, i), u = B(c, i, s, r.discs[i] ?? [], l, r.sloths[n.by], [...t.plan]);
	if ("err" in u) return J(u.err);
	r.discs[i] = u.discs, r.sloths[n.by] = u.sloth;
	for (let e of u.leafCells) _e(r, n.by, e);
	if (ve(r, o), r.leaves[n.by] >= 8 && !r.final) {
		let e = r.players.indexOf(n.by);
		r.final = [...r.players.slice(e + 1), ...r.players.slice(0, e)];
	}
	return ge(r), {
		state: r,
		fx: []
	};
}
function Y(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let r of e.species) if (r !== t) for (let t of e.discs[r] ?? []) n.add(t);
	return n;
}
function Se(e, t) {
	let n = {};
	for (let t of e.species) {
		let r = e.piles[t] ?? [];
		n[t] = {
			top: r[0] ?? null,
			count: r.length
		};
	}
	let r = {};
	for (let t of e.players) r[t] = e.hands[t]?.length ?? 0;
	let i = e.setup?.steps[0];
	return {
		public: {
			board: e.board,
			species: e.species,
			piles: n,
			discs: e.discs,
			sloths: e.sloths,
			treeLeaves: e.treeLeaves,
			leaves: e.leaves,
			handCounts: r,
			turn: e.turn,
			phase: e.phase,
			turnPhase: e.turnPhase,
			setup: i && e.setup ? {
				rid: i.rid,
				kind: i.kind,
				supply: e.setup.supply
			} : null,
			final: e.final !== null
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function Ce(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => (e.hands[t] ?? []).reduce((e, t) => e + t.v, 0), n = [...e.players].sort((n, r) => e.leaves[r] - e.leaves[n] || t(r) - t(n)), r = n[0], i = n.filter((n) => e.leaves[n] === e.leaves[r] && t(n) === t(r)), a = {};
	for (let t of e.players) a[t] = e.leaves[t];
	return {
		phase: "done",
		winner: i,
		ranking: n,
		scores: a
	};
}
var we = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: H,
	schemas: {
		action: ue,
		publicView: fe,
		privateView: pe,
		config: K
	},
	setup: me,
	reduce: xe,
	viewFor: Se,
	status: Ce
}, X = "#263e37", Te = "#fff9e9", Ee = {
	R: "#efd296",
	F: "#4f9b66",
	H: "#d8af74",
	P: "#c9df8a",
	M: "#9eaaa5",
	W: "#67bfd2",
	B: "#67bfd2"
}, De = "M60 0 30 52 -30 52 -60 0 -30 -52 30 -52Z";
function Oe({ terrain: e, x: t, y: n, variant: r = 0 }) {
	let i = r % 3 * 120;
	return /* @__PURE__ */ p("g", {
		transform: `translate(${t} ${n})`,
		children: [
			/* @__PURE__ */ f("path", {
				d: De,
				fill: Ee[e],
				stroke: e === "W" || e === "B" ? "#286f86" : "#3d5542",
				strokeWidth: 2.8
			}),
			(e === "P" || e === "R") && /* @__PURE__ */ f("g", {
				transform: `rotate(${i})`,
				children: e === "P" ? /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f("path", {
						d: "M-43 16l3-7 3 7m13-38l3-7 3 7M5 19l3-7 3 7m24-26l3-7 3 7m-48 44l2-5 2 5",
						fill: "none",
						stroke: "#609951",
						strokeWidth: 2.5,
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					/* @__PURE__ */ f("circle", {
						cx: -6,
						cy: -12,
						r: 2.5,
						fill: "#f9f5d9"
					}),
					/* @__PURE__ */ f("circle", {
						cx: -6,
						cy: -12,
						r: 1,
						fill: "#dcb653"
					})
				] }) : /* @__PURE__ */ f("g", {
					fill: "none",
					stroke: "#bf985f",
					strokeWidth: 2,
					strokeLinecap: "round",
					children: /* @__PURE__ */ f("path", { d: "M-39-25l4-2 3 2m26 15l4-2 3 2m27-18l4-2 3 2M-27 23l4-2 3 2M7 30l4-2 3 2m24-10l4-2 3 2" })
				})
			}),
			e === "F" && /* @__PURE__ */ p("g", {
				transform: `rotate(${i})`,
				children: [
					/* @__PURE__ */ f("circle", {
						cx: -25,
						cy: -10,
						r: 16,
						fill: "#2d7154"
					}),
					/* @__PURE__ */ f("circle", {
						cx: -9,
						cy: -23,
						r: 18,
						fill: "#39845d"
					}),
					/* @__PURE__ */ f("circle", {
						cx: 13,
						cy: -15,
						r: 17,
						fill: "#2b7658"
					}),
					/* @__PURE__ */ f("circle", {
						cx: 30,
						cy: 3,
						r: 14,
						fill: "#377f55"
					}),
					/* @__PURE__ */ f("circle", {
						cx: -21,
						cy: 16,
						r: 15,
						fill: "#348858"
					}),
					/* @__PURE__ */ f("circle", {
						cx: 3,
						cy: 15,
						r: 17,
						fill: "#236e50"
					}),
					/* @__PURE__ */ f("circle", {
						cx: 22,
						cy: 20,
						r: 12,
						fill: "#4d9d61"
					}),
					/* @__PURE__ */ f("path", {
						d: "M-23-11l6-4M8-13l6-4M-2 19l6-4M23 22l5-4",
						fill: "none",
						stroke: "#8cc080",
						strokeWidth: 2.5,
						strokeLinecap: "round",
						opacity: .75
					})
				]
			}),
			e === "H" && /* @__PURE__ */ f("g", {
				fill: "none",
				stroke: "#966b4d",
				strokeWidth: 3,
				strokeLinecap: "round",
				opacity: .8,
				children: /* @__PURE__ */ f("path", { d: "M-45-24q18-12 33-2t27-2q18-8 30 3M-48-5q15-10 32-3T16-10q16-5 31 5M-44 18q20-13 37-2t31-1q10-4 18 0M-27 36q15-8 29-1t23-1" })
			}),
			e === "M" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", {
					d: "M-49 28l25-48 13 19 18-35 32 62Z",
					fill: "#657670",
					stroke: "#43534d",
					strokeWidth: 2.5
				}),
				/* @__PURE__ */ f("path", {
					d: "M-29-10l5-10 7 11-7-3ZM1-26l6-10 8 12-9-3Z",
					fill: "#f0eee1"
				}),
				/* @__PURE__ */ f("path", {
					d: "M-13 35l12-21 6 6 8-16 12 31",
					fill: "none",
					stroke: "#d4d5c8",
					strokeWidth: 3,
					opacity: .8
				})
			] }),
			(e === "W" || e === "B") && /* @__PURE__ */ f("g", {
				fill: "none",
				stroke: "#d8f2e8",
				strokeWidth: 3,
				strokeLinecap: "round",
				opacity: .8,
				children: /* @__PURE__ */ f("path", { d: "M-46-27q10-8 20 0t20 0 20 0 20 0 20 0M-50-4q10-8 20 0t20 0 20 0 20 0 20 0M-46 19q10-8 20 0t20 0 20 0 20 0 20 0M-36 38q10-8 20 0t20 0 20 0 20 0" })
			})
		]
	});
}
function ke({ x: e, y: t }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${e} ${t}) rotate(-18)`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ f("rect", {
				x: -44,
				y: -12,
				width: 88,
				height: 29,
				rx: 2,
				fill: "#6b513a",
				stroke: X,
				strokeWidth: 2.5
			}),
			/* @__PURE__ */ f("rect", {
				x: -40,
				y: -10,
				width: 80,
				height: 24,
				fill: "#d5b47c"
			}),
			[
				-30,
				-18,
				-6,
				6,
				18,
				30
			].map((e) => /* @__PURE__ */ f("path", {
				d: `M${e} -10v24`,
				stroke: "#73543b",
				strokeWidth: 2.5
			}, e)),
			/* @__PURE__ */ f("path", {
				d: "M-46-15h92M-46 19h92",
				stroke: "#5c4635",
				strokeWidth: 3
			})
		]
	});
}
function Ae({ x: e, y: t }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${e} ${t - 14}) scale(.77)`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M-3 12v31m6-31v31",
				stroke: "#69452f",
				strokeWidth: 9,
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M-33 17Q-43-4-22-19q3-21 22-20 21-11 32 9 19 5 14 25 7 18-12 29-20 9-36-1-19 7-31-6Z",
				fill: "#297e56",
				stroke: "#24583f",
				strokeWidth: 4
			}),
			/* @__PURE__ */ f("path", {
				d: "M-23-9q6-12 16-11m22-9q13 2 15 13M13 7q11-2 17-10m-54 12q9 5 18 0",
				fill: "none",
				stroke: "#91c678",
				strokeWidth: 5,
				strokeLinecap: "round"
			})
		]
	});
}
function je({ x: e, y: t }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${e} ${t + 5}) scale(.67)`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M-28 12v27h56V12L0-11Z",
				fill: "#f8e8bf",
				stroke: "#5c4b36",
				strokeWidth: 4
			}),
			/* @__PURE__ */ f("path", {
				d: "M-36 10L0-21l37 31-9 3L0-9l-28 22Z",
				fill: "#bd784b",
				stroke: "#5c4b36",
				strokeWidth: 4
			}),
			/* @__PURE__ */ f("path", {
				d: "M-8 39V15H8v24m10-22h8v9h-8Z",
				fill: "#79b7c0",
				stroke: "#5c4b36",
				strokeWidth: 3
			})
		]
	});
}
function Me({ color: e = "#94ba50" }) {
	return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
		d: "M0 16C-18 12-23-8-1-20 20-15 20 5 0 16Z",
		fill: e,
		stroke: X,
		strokeWidth: 3
	}), /* @__PURE__ */ f("path", {
		d: "M0 16Q-1 0 11-10M-1 4l-9-8m9 2l9-8",
		fill: "none",
		stroke: "#eaf0ad",
		strokeWidth: 2.5,
		strokeLinecap: "round"
	})] });
}
function Ne({ size: e = 16, color: t }) {
	return /* @__PURE__ */ f("svg", {
		width: e,
		height: e,
		viewBox: "-22 -22 44 44",
		"aria-hidden": !0,
		className: "inline-block flex-none",
		children: /* @__PURE__ */ f(Me, { color: t })
	});
}
function Pe({ size: e = 16 }) {
	return /* @__PURE__ */ p("svg", {
		width: e,
		height: e,
		viewBox: "0 0 20 20",
		"aria-hidden": !0,
		className: "inline-block flex-none",
		children: [/* @__PURE__ */ f("rect", {
			x: 3,
			y: 2,
			width: 14,
			height: 17,
			rx: 2,
			fill: Te,
			stroke: X,
			strokeWidth: 2
		}), /* @__PURE__ */ f("path", {
			d: "M6 6h8M6 10h8",
			stroke: "#83a85d",
			strokeWidth: 2
		})]
	});
}
function Fe({ species: e }) {
	let t = {
		stroke: X,
		strokeWidth: 3,
		strokeLinecap: "round",
		strokeLinejoin: "round"
	};
	switch (e) {
		case "donkey": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M17 29 10 6q9-2 13 18M47 29 54 6q-9-2-13 18",
					fill: "#c4936a"
				}),
				/* @__PURE__ */ f("path", {
					d: "M17 24q15-10 30 0l-3 23q-12 14-24 0Z",
					fill: "#b78360"
				}),
				/* @__PURE__ */ f("path", {
					d: "M24 39q8-6 16 0l-2 13q-6 5-12 0Z",
					fill: "#f4dfbd"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "24",
					cy: "33",
					r: "2",
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "40",
					cy: "33",
					r: "2",
					fill: X,
					stroke: "none"
				})
			]
		});
		case "rabbit": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M19 29 15 4q8-5 12 0l4 24m4 0 4-24q8-5 12 0l-4 25",
					fill: "#d6b9e7"
				}),
				/* @__PURE__ */ f("path", {
					d: "M14 29q18-13 36 0l-3 21q-15 14-30 0Z",
					fill: "#fff5f1"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "25",
					cy: "38",
					r: "2",
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "39",
					cy: "38",
					r: "2",
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("path", {
					d: "M30 45h4l-2 2Z",
					fill: "#d78298"
				})
			]
		});
		case "unicorn": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M31 25 35 2l8 24",
					fill: "#e9c260"
				}),
				/* @__PURE__ */ f("path", {
					d: "M20 16q21-5 29 17l-9 19H20L13 35Z",
					fill: "#fff7e9"
				}),
				/* @__PURE__ */ f("path", {
					d: "M17 23q-8-13 3-18 5 13 5 20m20 1q9-17-2-18l-6 16",
					fill: "#eeb3d2"
				}),
				/* @__PURE__ */ f("path", {
					d: "M17 14q18-8 31 6",
					fill: "none",
					stroke: "#cb77a7",
					strokeWidth: 5
				}),
				/* @__PURE__ */ f("circle", {
					cx: "35",
					cy: "36",
					r: "2",
					fill: X,
					stroke: "none"
				})
			]
		});
		case "human": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("circle", {
					cx: 32,
					cy: 16,
					r: 10,
					fill: "#e8bb91"
				}),
				/* @__PURE__ */ f("path", {
					d: "M20 55V36q1-12 12-12t12 12v19Z",
					fill: "#cb6659"
				}),
				/* @__PURE__ */ f("path", {
					d: "M17 31 9 45m38-14 8 14M27 55v6m10-6v6",
					fill: "none",
					strokeWidth: 6
				}),
				/* @__PURE__ */ f("path", {
					d: "M23 13q8-13 20-2",
					fill: "none",
					stroke: "#584632",
					strokeWidth: 5
				})
			]
		});
		case "crocodile": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M6 34q10-15 31-13l17 10-11 3 11 7-18 8Q19 47 6 34Z",
					fill: "#63a858"
				}),
				/* @__PURE__ */ f("path", {
					d: "M7 34q15 8 37 5",
					fill: "none"
				}),
				/* @__PURE__ */ f("path", {
					d: "m9 38 5 7 5-5 5 8 5-6 5 8",
					fill: "none",
					stroke: "#fff6d9",
					strokeWidth: 3
				}),
				/* @__PURE__ */ f("circle", {
					cx: 34,
					cy: 27,
					r: 2,
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("path", {
					d: "M14 26l-4-7m13 4-2-8m12 8 2-8",
					fill: "none"
				})
			]
		});
		case "dolphin": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M7 40Q22 15 48 29l10-8-2 13-11 7Q25 56 7 40Z",
					fill: "#6ec0d8"
				}),
				/* @__PURE__ */ f("path", {
					d: "M28 28 35 14l6 14M10 41 2 31m8 10-8 10",
					fill: "#5bacc8"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 45,
					cy: 32,
					r: 2,
					fill: X,
					stroke: "none"
				})
			]
		});
		case "elephant": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M18 23q-14-1-12 18 4 12 19 5m21-23q14-1 12 18-4 12-19 5",
					fill: "#adb6bb"
				}),
				/* @__PURE__ */ f("path", {
					d: "M18 20q14-12 28 0l-2 23-7 6-2 11q-8 3-9-5V43l-8-4Z",
					fill: "#c8d0d1"
				}),
				/* @__PURE__ */ f("path", {
					d: "M25 43q-7 9-11 2m25-2q7 9 11 2",
					fill: "none",
					stroke: "#fff7e6",
					strokeWidth: 4
				}),
				/* @__PURE__ */ f("circle", {
					cx: 24,
					cy: 31,
					r: 2,
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 40,
					cy: 31,
					r: 2,
					fill: X,
					stroke: "none"
				})
			]
		});
		case "giraffe": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M25 43 29 13 45 11 43 43q-9 12-18 0Z",
					fill: "#f1cb76"
				}),
				/* @__PURE__ */ f("path", {
					d: "M22 14q12-11 25 0l-1 16q-12 7-24 0Z",
					fill: "#f5d88a"
				}),
				/* @__PURE__ */ f("path", {
					d: "M26 12 24 3m17 9 2-9",
					fill: "none",
					stroke: "#9b6c3e",
					strokeWidth: 4
				}),
				/* @__PURE__ */ f("circle", {
					cx: 28,
					cy: 23,
					r: 2,
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 40,
					cy: 23,
					r: 2,
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 35,
					cy: 39,
					r: 4,
					fill: "#a97545",
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 29,
					cy: 51,
					r: 3,
					fill: "#a97545",
					stroke: "none"
				})
			]
		});
		case "eagle": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M31 27Q17 11 3 26l20 15 9-7 9 7 20-15Q47 11 33 27Z",
					fill: "#ab7852"
				}),
				/* @__PURE__ */ f("path", {
					d: "M24 17q8-9 16 0l-1 24-7 11-7-11Z",
					fill: "#f1eee1"
				}),
				/* @__PURE__ */ f("path", {
					d: "M27 37h10l-5 9Z",
					fill: "#e7b651"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 28,
					cy: 29,
					r: 2,
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 36,
					cy: 29,
					r: 2,
					fill: X,
					stroke: "none"
				})
			]
		});
		case "goat": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M18 24Q5 9 12 4q13 1 17 21m17-1Q59 9 52 4q-13 1-17 21",
					fill: "#d9aa67"
				}),
				/* @__PURE__ */ f("path", {
					d: "M17 21q-14-7-16 4 6 9 17 6m29-10q14-7 16 4-6 9-17 6",
					fill: "#f1e5c9"
				}),
				/* @__PURE__ */ f("path", {
					d: "M17 18q15-12 30 0l-3 28q-12 15-24 0Z",
					fill: "#fff7e2"
				}),
				/* @__PURE__ */ f("path", {
					d: "M27 47q5 5 10 0l-5 14Z",
					fill: "#efe5ce"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 25,
					cy: 33,
					r: 2.3,
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 39,
					cy: 33,
					r: 2.3,
					fill: X,
					stroke: "none"
				})
			]
		});
		case "ant": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("circle", {
					cx: 14,
					cy: 33,
					r: 8,
					fill: "#9d4b42"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 32,
					cy: 33,
					r: 10,
					fill: "#ab5046"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 51,
					cy: 33,
					r: 8,
					fill: "#9d4b42"
				}),
				/* @__PURE__ */ f("path", {
					d: "m9 23-5-10m13 11 2-11m3 37-4 9m-4-9-8 6m27-6-2 9m11-10 5 10m5-10 8 6m-18-31 2-10m7 12 6-8",
					fill: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 49,
					cy: 30,
					r: 1.8,
					fill: X,
					stroke: "none"
				})
			]
		});
		case "orangutan": return /* @__PURE__ */ p("g", {
			...t,
			children: [
				/* @__PURE__ */ f("path", {
					d: "M14 21Q9 5 22 5l10 8L42 5Q55 5 50 21l6 21q-5 16-24 16T8 42Z",
					fill: "#ac6845"
				}),
				/* @__PURE__ */ f("path", {
					d: "M18 24q14-12 28 0l-1 22q-13 13-26 0Z",
					fill: "#e4ad7f"
				}),
				/* @__PURE__ */ f("path", {
					d: "M15 38q-9 2-9 13m43-13q9 2 9 13",
					fill: "none",
					strokeWidth: 6
				}),
				/* @__PURE__ */ f("circle", {
					cx: 25,
					cy: 35,
					r: 2,
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("circle", {
					cx: 39,
					cy: 35,
					r: 2,
					fill: X,
					stroke: "none"
				}),
				/* @__PURE__ */ f("path", {
					d: "M27 46q5 4 10 0",
					fill: "none"
				})
			]
		});
	}
}
function Ie({ species: e, size: t = 24 }) {
	return /* @__PURE__ */ f("svg", {
		width: t,
		height: t,
		viewBox: "0 0 64 64",
		"aria-hidden": !0,
		className: "inline-block flex-none",
		children: /* @__PURE__ */ f(Fe, { species: e })
	});
}
function Le({ species: e, x: t, y: n, selected: r = !1, available: i = !1, stepCount: a = 0 }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${t} ${n})`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ f("circle", {
				cy: 4,
				r: 32,
				fill: "#5e5948"
			}),
			/* @__PURE__ */ f("circle", {
				r: 32,
				fill: S[e],
				stroke: X,
				strokeWidth: 3.5
			}),
			/* @__PURE__ */ f("circle", {
				r: 26,
				fill: Te,
				stroke: "#a89572",
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ f("g", {
				transform: "translate(-21 -21) scale(.66)",
				children: /* @__PURE__ */ f(Fe, { species: e })
			}),
			i && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("circle", {
				r: 38,
				fill: "none",
				stroke: "#fffdf3",
				strokeWidth: 5
			}), /* @__PURE__ */ f("path", {
				d: "M0-44-8-55H8Z",
				fill: "#fffdf3",
				stroke: X,
				strokeWidth: 2
			})] }),
			r && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("circle", {
				r: 39,
				fill: "none",
				stroke: X,
				strokeWidth: 6
			}), /* @__PURE__ */ f("path", {
				d: "M-20 43h40",
				stroke: X,
				strokeWidth: 5,
				strokeLinecap: "round"
			})] }),
			a > 0 && /* @__PURE__ */ p("g", {
				transform: "translate(34 -35)",
				children: [/* @__PURE__ */ f("circle", {
					r: 17,
					fill: Te,
					stroke: X,
					strokeWidth: 3
				}), /* @__PURE__ */ f("text", {
					y: 6,
					textAnchor: "middle",
					fontFamily: "var(--font-display)",
					fontSize: 19,
					fontWeight: 800,
					fill: X,
					children: a
				})]
			})
		]
	});
}
function Re({ x: e, y: t, color: n }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${e} ${t}) scale(.73)`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ f("circle", {
				cy: 4,
				r: 29,
				fill: "#5e5948"
			}),
			/* @__PURE__ */ f("circle", {
				r: 29,
				fill: n,
				stroke: X,
				strokeWidth: 3
			}),
			/* @__PURE__ */ f("path", {
				d: "M-19-16q19-13 38 0 12 19 0 34-19 14-38 0-12-15 0-34Z",
				fill: "#a6764f",
				stroke: "#4b3d34",
				strokeWidth: 2.5
			}),
			/* @__PURE__ */ f("path", {
				d: "M-17-7q8-10 17-5 9-5 17 5 7 13-4 20-13 9-26 0-11-7-4-20Z",
				fill: "#f2dfbb"
			}),
			/* @__PURE__ */ f("path", {
				d: "M-13-8q-5 8-2 12l10 2 5-10m13-4q5 8 2 12L5 6 0-4",
				fill: "#765b51"
			}),
			/* @__PURE__ */ f("circle", {
				cx: -9,
				r: 2.5,
				fill: X
			}),
			/* @__PURE__ */ f("circle", {
				cx: 9,
				r: 2.5,
				fill: X
			}),
			/* @__PURE__ */ f("path", {
				d: "M-3 9q3 3 6 0",
				fill: "none",
				stroke: "#594438",
				strokeWidth: 2,
				strokeLinecap: "round"
			})
		]
	});
}
function ze({ x: e, y: t, kind: n }) {
	return /* @__PURE__ */ p("g", {
		transform: `translate(${e} ${t})`,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M53 0 27 46h-54L-53 0l26-46h54Z",
				fill: "#fff9df",
				fillOpacity: .42,
				stroke: "#fffdf3",
				strokeWidth: 6
			}),
			/* @__PURE__ */ f("path", {
				d: "M45 0 23 39h-46L-45 0l22-39h46Z",
				fill: "none",
				stroke: "#254f44",
				strokeWidth: 4,
				strokeDasharray: n === "step" ? "7 6" : void 0
			}),
			n === "step" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", {
					d: "m-14 7 8-11 7 5 7-10 9 11-8 10-10-5-7 9Z",
					fill: "#fffdf3",
					stroke: X,
					strokeWidth: 2.5
				}),
				/* @__PURE__ */ f("circle", {
					cx: -6,
					cy: -16,
					r: 3,
					fill: X
				}),
				/* @__PURE__ */ f("circle", {
					cx: 6,
					cy: -17,
					r: 3,
					fill: X
				})
			] }),
			n === "place" && /* @__PURE__ */ f("path", {
				d: "M-15 0h30M0-15v30",
				stroke: X,
				strokeWidth: 6,
				strokeLinecap: "round"
			}),
			n === "tree" && /* @__PURE__ */ f("g", {
				transform: "scale(.8)",
				children: /* @__PURE__ */ f(Me, {})
			}),
			n === "disc" && /* @__PURE__ */ f("path", {
				d: "M0-20-15 5h30ZM-15 14h30",
				fill: "#fffdf3",
				stroke: X,
				strokeWidth: 3,
				strokeLinejoin: "round"
			}),
			n === "ant" && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("circle", {
					cx: -15,
					r: 6,
					fill: X
				}),
				/* @__PURE__ */ f("circle", {
					r: 6,
					fill: X
				}),
				/* @__PURE__ */ f("circle", {
					cx: 15,
					r: 6,
					fill: X
				}),
				/* @__PURE__ */ f("path", {
					d: "M-9 0h3M6 0h3",
					stroke: X,
					strokeWidth: 4
				})
			] })
		]
	});
}
function Be({ species: e, value: t }) {
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 56 76",
		"aria-hidden": !0,
		className: "block h-full w-full",
		children: [
			/* @__PURE__ */ f("rect", {
				x: 1.5,
				y: 1.5,
				width: 53,
				height: 73,
				rx: 5,
				fill: Te,
				stroke: X,
				strokeWidth: 2.5
			}),
			/* @__PURE__ */ f("rect", {
				x: 5,
				y: 5,
				width: 46,
				height: 66,
				rx: 3,
				fill: S[e],
				opacity: .55
			}),
			/* @__PURE__ */ f("path", {
				d: "M5 18h46M5 57h46",
				stroke: X,
				strokeWidth: 1.4,
				opacity: .65
			}),
			/* @__PURE__ */ f("circle", {
				cx: 28,
				cy: 36,
				r: 20,
				fill: Te,
				stroke: X,
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ f("g", {
				transform: "translate(10 18) scale(.57)",
				children: /* @__PURE__ */ f(Fe, { species: e })
			}),
			/* @__PURE__ */ f("text", {
				x: 45,
				y: 69,
				textAnchor: "end",
				fontFamily: "var(--font-display)",
				fontSize: 20,
				fontWeight: 800,
				fill: X,
				children: t
			}),
			/* @__PURE__ */ f("path", {
				d: "M9 65h12",
				stroke: X,
				strokeWidth: 2
			})
		]
	});
}
//#endregion
//#region src/games/fastsloths/board-viewport.tsx
function Ve(e, t, n, r, i) {
	let a = t / (2 * e.scale), o = n / (2 * e.scale);
	return {
		...e,
		cx: a >= r / 2 ? r / 2 : Math.min(Math.max(e.cx, a), r - a),
		cy: o >= i / 2 ? i / 2 : Math.min(Math.max(e.cy, o), i - o)
	};
}
function He({ sheetW: e, sheetH: t, focus: s, progress: c, eligible: l, onTap: u, children: d }) {
	let m = o(), h = i(null), g = i(/* @__PURE__ */ new Map()), _ = i(0), v = i(0), y = i({
		cx: e / 2,
		cy: t / 2,
		scale: 1
	}), [b, x] = a({
		width: 0,
		height: 0
	}), [S, ee] = a(null), C = i(c), [w, T] = a(null);
	n(() => {
		let e = C.current;
		if (C.current = c, c <= e) return;
		T(c - 1);
		let t = window.setTimeout(() => T(null), 650);
		return () => window.clearTimeout(t);
	}, [c]), n(() => {
		let e = h.current;
		if (!e) return;
		let t = new ResizeObserver(() => x({
			width: e.clientWidth,
			height: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let E = r(() => b.width && b.height ? Math.min(b.width / e, b.height / t) : 1, [
		b,
		e,
		t
	]), D = Math.max(E * 6, .8), O = r(() => ({
		cx: e / 2,
		cy: t / 2,
		scale: E
	}), [
		e,
		t,
		E
	]), k = Ve({
		cx: s?.x ?? e / 2,
		cy: s?.y ?? t / 2,
		scale: Math.min(D, Math.max(E * 2.35, .38))
	}, b.width, b.height, e, t), A = S ? Ve({
		...S,
		scale: Math.min(Math.max(S.scale, E), D)
	}, b.width, b.height, e, t) : k;
	n(() => {
		y.current = A;
	}, [A]);
	let j = (n) => {
		let r = Ve(n, b.width, b.height, e, t);
		y.current = r, ee(r);
	};
	n(() => {
		let e = h.current;
		if (!e) return;
		let t = (t) => {
			t.preventDefault();
			let n = t.deltaY < 0 ? 1.16 : 1 / 1.16, r = y.current, i = Math.min(Math.max(r.scale * n, E), D), a = e.getBoundingClientRect(), o = t.clientX - a.left - a.width / 2, s = t.clientY - a.top - a.height / 2;
			j({
				cx: r.cx + o / r.scale - o / i,
				cy: r.cy + s / r.scale - s / i,
				scale: i
			});
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [
		E,
		D,
		b.width,
		b.height
	]);
	let M = (e) => {
		let t = y.current;
		j({
			...t,
			scale: Math.min(Math.max(t.scale * e, E), D)
		});
	};
	return /* @__PURE__ */ p("div", {
		ref: h,
		className: "fs-board-viewport",
		children: [
			/* @__PURE__ */ f("svg", {
				className: "fs-board-svg",
				onPointerDown: (e) => {
					if (e.currentTarget.setPointerCapture(e.pointerId), g.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					}), g.current.size === 1 && (_.current = 0), g.current.size === 2) {
						let [e, t] = [...g.current.values()];
						v.current = Math.hypot(e.x - t.x, e.y - t.y);
					}
				},
				onPointerMove: (e) => {
					let t = g.current.get(e.pointerId);
					if (!t) return;
					let n = y.current;
					if (g.current.size === 1) {
						let r = e.clientX - t.x, i = e.clientY - t.y;
						_.current += Math.abs(r) + Math.abs(i), j({
							...n,
							cx: n.cx - r / n.scale,
							cy: n.cy - i / n.scale
						});
					} else if (g.current.size === 2) {
						g.current.set(e.pointerId, {
							x: e.clientX,
							y: e.clientY
						});
						let [t, r] = [...g.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
						if (v.current && i) {
							let e = Math.min(Math.max(n.scale * i / v.current, E), D), a = h.current.getBoundingClientRect(), o = (t.x + r.x) / 2 - a.left - a.width / 2, s = (t.y + r.y) / 2 - a.top - a.height / 2;
							j({
								cx: n.cx + o / n.scale - o / e,
								cy: n.cy + s / n.scale - s / e,
								scale: e
							});
						}
						v.current = i, _.current = 99;
						return;
					}
					g.current.set(e.pointerId, {
						x: e.clientX,
						y: e.clientY
					});
				},
				onPointerUp: (e) => {
					let t = g.current.size === 1 && _.current < 10;
					if (g.current.delete(e.pointerId), v.current = 0, !t || !l.length) return;
					let n = h.current.getBoundingClientRect(), r = y.current, i = r.cx + (e.clientX - n.left - n.width / 2) / r.scale, a = r.cy + (e.clientY - n.top - n.height / 2) / r.scale, o, s = 3364;
					for (let e of l) {
						let t = (e.x - i) ** 2 + (e.y - a) ** 2;
						t < s && (o = e, s = t);
					}
					o && u(o.key);
				},
				onPointerCancel: (e) => {
					g.current.delete(e.pointerId), v.current = 0;
				},
				children: /* @__PURE__ */ f("g", {
					transform: `translate(${b.width / 2 - A.cx * A.scale} ${b.height / 2 - A.cy * A.scale}) scale(${A.scale})`,
					children: d
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "fs-leaf-track",
				"aria-label": m("games.fastsloths.leaves", { n: c }),
				children: Array.from({ length: 8 }, (e, t) => /* @__PURE__ */ f("span", {
					className: `fs-leaf-step ${t < c ? "is-done" : ""} ${t === c ? "is-next" : ""} ${t === w ? "is-earned" : ""}`,
					children: /* @__PURE__ */ f(Ne, {
						size: 14,
						color: t < c ? "#91b955" : "#d3d3bc"
					})
				}, t))
			}),
			/* @__PURE__ */ p("div", {
				className: "fs-map-controls",
				children: [
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "fs-map-control",
						"aria-label": m("games.fastsloths.zoomOut"),
						disabled: A.scale <= E + .001,
						onClick: () => M(1 / 1.5),
						children: "−"
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "fs-map-control",
						"aria-label": m("games.fastsloths.zoomIn"),
						disabled: A.scale >= D - .001,
						onClick: () => M(1.5),
						children: "+"
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "fs-map-control fs-map-control-fit",
						onClick: () => j(O),
						children: m("games.fastsloths.fullMap")
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/fastsloths/view-player.tsx
var Z = 60;
function Q(e) {
	let [t, n] = C(e), r = t + 1;
	return [1.5 * r * Z + Z, Math.sqrt(3) * (n + r % 2 * .5) * Z + Z];
}
function Ue(e, t = Z) {
	let [n, r] = Q(e), i = [];
	for (let e = 0; e < 6; e += 1) {
		let a = Math.PI / 3 * e;
		i.push(`${(n + t * Math.cos(a)).toFixed(1)},${(r + t * Math.sin(a)).toFixed(1)}`);
	}
	return i.join(" ");
}
var We = (() => {
	let e = [];
	for (let t = -1; t <= 17; t += 1) for (let n = 0; n < T(t); n += 1) e.push(w(t, n));
	return e;
})(), Ge = 1770, Ke = Math.sqrt(3) * 12 * Z + Z;
function qe(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ f(Je, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Je({ pub: e, priv: t, members: n, myRid: i, send: m }) {
	let g = o(), _ = h[e.board], v = (e) => n.find((t) => t.rid === e)?.name ?? e, b = (e) => s[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % s.length].hex, C = i in e.leaves, w = e.phase === "turn" && e.turn === i, T = e.phase === "setup" && e.setup?.rid === i, [E, D] = a([]), [k, A] = a([]), [j, M] = a(null), [N, te] = a([]), [P, F] = a([]), [re, ie] = a(null), [L, R] = a(null), [z, B] = a([]), [V, U] = a(null), W = `${e.phase}|${e.turn}|${e.turnPhase}`, [le, ue] = a(W);
	le !== W && (ue(W), D([]), A([]), M(null), te([]), F([]), ie(null), R(null), B([]));
	let G = r(() => {
		if (!j || !C) return null;
		let t = y[j], n = N.reduce((e, t) => e + t, 0) + t.mod, r = /* @__PURE__ */ new Set();
		for (let t of e.species) if (t !== j) for (let n of e.discs[t] ?? []) r.add(n);
		let a = ne(_, j, n, e.discs[j] ?? [], r, e.sloths[i]);
		for (let e of P) ae(a, e);
		return a;
	}, [
		j,
		N,
		P,
		e,
		i,
		C,
		_
	]), K = r(() => G ? se(G) : null, [G]), q = G !== null && P.length > 0 && oe(G) === null, de = () => {
		if (!t) return;
		let e = k.length > 0 ? t.hand[k[0]].sp : null;
		e && (M(e), te(k.map((e) => t.hand[e].v)), F([]), ie(null), R(null), B([]));
	}, fe = () => {
		M(null), F([]), ie(null), R(null), B([]);
	}, pe = r(() => {
		let t = /* @__PURE__ */ new Map();
		if (e.phase === "setup" && T && e.setup) {
			if (e.setup.kind === "tree") for (let n of _.trees) Object.values(e.sloths).includes(n) || t.set(n, { kind: "tree" });
			else if (V) {
				let n = /* @__PURE__ */ new Set();
				for (let t of e.species) for (let r of e.discs[t] ?? []) n.add(r);
				for (let e of We) !n.has(e) && I(_, V, e) && t.set(e, { kind: "place" });
			}
			return t;
		}
		if (!G || !K || !j) return t;
		let n = y[j], r = G.active === -1 ? re : G.active;
		if (L === "carry" && j === "ant") {
			let e = ce(G, z);
			for (let n of e.add) t.set(G.discs[n], {
				kind: "ant",
				ant: n
			});
			for (let n of e.to) z.length > 0 && t.set(n, {
				kind: "step",
				step: {
					k: "carry",
					ants: z,
					to: n
				}
			});
			return t;
		}
		if (L === "throw") {
			let e = [...new Set(K.throws.map((e) => e.disc))];
			if (r === null && e.length > 1) {
				for (let n of e) t.set(G.discs[n], {
					kind: "disc",
					disc: n
				});
				return t;
			}
			for (let e of K.throws) (r === null || e.disc === r) && t.set(e.to, {
				kind: "step",
				step: {
					k: "throw",
					disc: e.disc,
					to: e.to
				}
			});
			return t;
		}
		if (L === "drop") {
			for (let e of K.drop) t.set(e, {
				kind: "step",
				step: {
					k: "drop",
					to: e
				}
			});
			for (let e of K.neckDrop) t.set(e, {
				kind: "step",
				step: {
					k: "neckDrop",
					to: e
				}
			});
			return t;
		}
		if (r === null && (n.multiDisc || G.discs.length > 1)) {
			let e = /* @__PURE__ */ new Set([...K.steps.map((e) => e.disc), ...K.neckPick]);
			if (e.size > 0) {
				for (let n of e) t.set(G.discs[n], {
					kind: "disc",
					disc: n
				});
				return t;
			}
		}
		for (let e of K.steps) (r === null || e.disc === r) && t.set(e.to, {
			kind: "step",
			step: {
				k: "step",
				disc: e.disc,
				to: e.to
			}
		});
		for (let e of K.hops) t.set(e, {
			kind: "step",
			step: {
				k: "hop",
				to: e
			}
		});
		for (let e of K.fetch) t.set(e, {
			kind: "step",
			step: {
				k: "fetch",
				to: e
			}
		});
		for (let e of K.fly) t.set(e, {
			kind: "step",
			step: {
				k: "fly",
				to: e
			}
		});
		return t;
	}, [
		e,
		G,
		K,
		j,
		re,
		L,
		z,
		V,
		T,
		_
	]), J = (e) => {
		let t = pe.get(e);
		t && (t.kind === "tree" ? m({
			type: "pickTree",
			cell: e
		}) : t.kind === "place" && V ? m({
			type: "placeDisc",
			species: V,
			cell: e
		}) : t.kind === "disc" ? ie(t.disc) : t.kind === "ant" ? B((e) => e.includes(t.ant) ? e.filter((e) => e !== t.ant) : [...e, t.ant]) : t.kind === "step" && (F((e) => [...e, t.step]), t.step.k === "carry" && B([])));
	}, me = t?.hand ?? [], he = x(e.leaves[i] ?? 1), ge = Math.min(he.draw, e.species.filter((t) => (e.piles[t]?.count ?? 0) > 0).length), _e = w && e.turnPhase === "draw", ve = T && e.setup?.kind === "disc", ye = G && G.active !== -1 ? G.active : re, be = e.sloths[i] ? (() => {
		let [t, n] = Q(e.sloths[i]);
		return {
			x: t,
			y: n
		};
	})() : void 0, xe = "info", Y = "";
	if (e.phase === "setup" && e.setup) {
		let t = e.setup.rid === i;
		xe = t ? "accent" : "info", Y = t ? g(e.setup.kind === "tree" ? "games.fastsloths.setupTree" : "games.fastsloths.setupDisc") : g("games.fastsloths.waiting", { name: v(e.setup.rid) });
	} else if (e.phase === "turn") {
		let t = x(e.leaves[e.turn] ?? 1);
		w ? (xe = "accent", Y = e.turnPhase === "draw" ? g("games.fastsloths.drawPrompt", { n: ge }) : e.turnPhase === "discard1" ? g("games.fastsloths.discard1Prompt") : e.turnPhase === "limit" ? g("games.fastsloths.limitPrompt", { n: t.limit }) : g("games.fastsloths.playPrompt")) : Y = g("games.fastsloths.waiting", { name: v(e.turn) });
	}
	let Se = C ? g("games.fastsloths.leaves", { n: e.leaves[i] ?? 0 }) : void 0;
	return /* @__PURE__ */ f("div", {
		className: "fs-view",
		children: /* @__PURE__ */ f(c, {
			adaptive: !0,
			className: "fs-screen",
			scroll: !1,
			banner: /* @__PURE__ */ p("div", {
				className: "fs-banner",
				children: [/* @__PURE__ */ f(l, {
					tone: xe,
					text: e.final && e.phase === "turn" ? `${Y} · ${g("games.fastsloths.finalRound")}` : Y,
					chip: Se,
					accent: H.accent
				}), /* @__PURE__ */ f("div", {
					className: "fs-seats",
					children: /* @__PURE__ */ f(u, {
						variant: "plate",
						members: n,
						myRid: i,
						action: (t) => e.phase === "setup" ? e.setup?.rid === t ? "pending" : null : e.phase === "turn" && e.turn === t ? "pending" : null,
						status: (t) => t in e.leaves ? /* @__PURE__ */ p("span", {
							className: "fs-seat-status flex items-center gap-2 text-xs font-bold",
							children: [/* @__PURE__ */ p("span", {
								className: "flex items-center gap-0.5",
								children: [/* @__PURE__ */ f(Ne, { size: 13 }), /* @__PURE__ */ f("span", {
									className: "font-mono tabular-nums",
									children: e.leaves[t]
								})]
							}), /* @__PURE__ */ p("span", {
								className: "flex items-center gap-0.5",
								children: [/* @__PURE__ */ f(Pe, { size: 13 }), /* @__PURE__ */ f("span", {
									className: "font-mono tabular-nums",
									children: e.handCounts[t] ?? 0
								})]
							})]
						}) : null
					})
				})]
			}),
			actionsHeight: "fs-actions-slot",
			actions: /* @__PURE__ */ p("div", {
				className: "fs-actions",
				children: [/* @__PURE__ */ f("div", {
					className: "fs-hand-scroll",
					children: _e ? e.species.map((t) => {
						let n = e.piles[t], r = E.includes(t);
						return /* @__PURE__ */ p("button", {
							type: "button",
							disabled: !n?.count,
							onClick: () => D((e) => r ? e.filter((e) => e !== t) : [...e, t]),
							className: `fs-pile-button ${r ? "is-selected" : ""}`,
							style: { borderTopColor: S[t] },
							"aria-pressed": r,
							"aria-label": `${g(ee[t])} ${g("games.fastsloths.pileCount", { n: n?.count ?? 0 })}`,
							children: [/* @__PURE__ */ p("span", {
								className: "fs-pile-top",
								children: [/* @__PURE__ */ f(Ie, {
									species: t,
									size: 19
								}), n?.top ?? "–"]
							}), /* @__PURE__ */ f("span", { children: g("games.fastsloths.pileCount", { n: n?.count ?? 0 }) })]
						}, t);
					}) : ve ? e.species.map((t) => {
						let n = e.setup?.supply[t] ?? 0;
						if (!n) return null;
						let r = V === t;
						return /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => U(r ? null : t),
							"aria-pressed": r,
							className: `fs-species-button ${r ? "is-selected" : ""}`,
							style: { borderTopColor: S[t] },
							children: [/* @__PURE__ */ f(Ie, {
								species: t,
								size: 24
							}), /* @__PURE__ */ p("span", { children: [
								g(ee[t]),
								" ×",
								n
							] })]
						}, t);
					}) : me.length ? me.map((t, n) => {
						let r = k.includes(n), i = w && (e.turnPhase === "discard1" || e.turnPhase === "limit" || e.turnPhase === "play" && !j);
						return /* @__PURE__ */ f("button", {
							type: "button",
							disabled: !i,
							"aria-pressed": r,
							"aria-label": `${g(ee[t.sp])} ${t.v}`,
							className: `fs-card-button ${r ? "is-selected" : ""}`,
							onClick: () => A((r) => r.includes(n) ? r.filter((e) => e !== n) : e.turnPhase === "play" && r.length > 0 && me[r[0]].sp !== t.sp || y[t.sp].singleCard ? [n] : [...r, n]),
							children: /* @__PURE__ */ f(Be, {
								species: t.sp,
								value: t.v
							})
						}, n);
					}) : /* @__PURE__ */ f("div", {
						className: "fs-progress-rail",
						"aria-label": g("games.fastsloths.leaves", { n: e.leaves[i] ?? 0 }),
						children: Array.from({ length: 8 }, (t, n) => /* @__PURE__ */ f("span", {
							className: `fs-progress-cell ${n < (e.leaves[i] ?? 0) ? "is-done" : n === (e.leaves[i] ?? 0) ? "is-next" : ""}`,
							children: n < (e.leaves[i] ?? 0) ? /* @__PURE__ */ f(Ne, { size: 17 }) : n + 1
						}, n))
					})
				}), /* @__PURE__ */ p("div", {
					className: "fs-action-row",
					children: [
						_e && /* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-base px-3",
							style: { backgroundColor: H.accent },
							disabled: E.length !== ge,
							onClick: () => m({
								type: "draw",
								piles: E
							}),
							children: [
								g("games.fastsloths.confirm"),
								" · ",
								E.length,
								"/",
								ge
							]
						}),
						w && (e.turnPhase === "discard1" || e.turnPhase === "limit") && /* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-base px-3",
							style: { backgroundColor: H.accent },
							disabled: k.length !== (e.turnPhase === "discard1" ? 1 : Math.max(0, me.length - he.limit)),
							onClick: () => m({
								type: "discard",
								cards: k.map((e) => me[e])
							}),
							children: [
								g("games.fastsloths.confirm"),
								" · ",
								g("games.fastsloths.selectedCards", { n: k.length })
							]
						}),
						w && e.turnPhase === "play" && !j && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-base px-3",
							style: { backgroundColor: H.accent },
							disabled: !k.length,
							onClick: de,
							children: g("games.fastsloths.startMove")
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-quiet px-3",
							onClick: () => m({ type: "pass" }),
							children: g("games.fastsloths.pass")
						})] }),
						w && e.turnPhase === "play" && j && G && K && /* @__PURE__ */ f(Xe, {
							sim: G,
							av: K,
							sp: j,
							selDisc: re,
							op: L,
							chain: z,
							planOk: q,
							onOp: (e) => {
								R(e), B([]);
							},
							onPickup: (e) => F((t) => [...t, {
								k: "pickup",
								disc: e
							}]),
							onNeckPick: (e) => F((t) => [...t, {
								k: "neckPick",
								disc: e
							}]),
							onUndo: () => {
								F((e) => e.slice(0, -1)), B([]);
							},
							onCancel: fe,
							onConfirm: () => {
								m({
									type: "play",
									species: j,
									cards: N,
									plan: P
								}), fe(), A([]);
							}
						}),
						!w && !T && /* @__PURE__ */ p("div", {
							className: "fs-wait-card",
							children: [/* @__PURE__ */ f(Ne, { size: 16 }), Y]
						}),
						T && /* @__PURE__ */ f("div", {
							className: "fs-wait-card",
							children: Y
						})
					]
				})]
			}),
			overlay: j && G ? /* @__PURE__ */ p("div", {
				className: "fs-points-pill",
				children: [/* @__PURE__ */ f(Ie, {
					species: j,
					size: 18
				}), g("games.fastsloths.pointsLeft", { n: G.left })]
			}) : void 0,
			children: /* @__PURE__ */ p(He, {
				sheetW: Ge,
				sheetH: Ke,
				focus: be,
				progress: e.leaves[i] ?? 0,
				eligible: [...pe.keys()].map((e) => {
					let [t, n] = Q(e);
					return {
						key: e,
						x: t,
						y: n
					};
				}),
				onTap: J,
				children: [
					We.map((e, t) => {
						let [n, r] = Q(e);
						return /* @__PURE__ */ f(Oe, {
							terrain: O(_, e),
							x: n,
							y: r,
							variant: t
						}, e);
					}),
					_.resortGraph.paths.map((e, t) => /* @__PURE__ */ p("g", {
						pointerEvents: "none",
						children: [/* @__PURE__ */ f("polyline", {
							points: e.map((e) => Q(e).join(",")).join(" "),
							fill: "none",
							stroke: "#806849",
							strokeWidth: 16,
							strokeLinecap: "round",
							strokeLinejoin: "round"
						}), /* @__PURE__ */ f("polyline", {
							points: e.map((e) => Q(e).join(",")).join(" "),
							fill: "none",
							stroke: "#f5e7ad",
							strokeWidth: 10,
							strokeLinecap: "round",
							strokeLinejoin: "round"
						})]
					}, `path${t}`)),
					_.bridges.map((e) => {
						let [t, n] = Q(e.cell);
						return /* @__PURE__ */ f(ke, {
							x: t,
							y: n
						}, `b${e.cell}`);
					}),
					[...pe].filter(([, e]) => e.kind !== "disc" && e.kind !== "ant").map(([e, t]) => {
						let [n, r] = Q(e);
						return /* @__PURE__ */ f(ze, {
							x: n,
							y: r,
							kind: t.kind
						}, `h${e}`);
					}),
					_.resorts.map((e) => {
						let [t, n] = Q(e);
						return /* @__PURE__ */ f(je, {
							x: t,
							y: n
						}, `r${e}`);
					}),
					_.trees.map((e) => {
						let [t, n] = Q(e);
						return /* @__PURE__ */ f(Ae, {
							x: t,
							y: n
						}, `t${e}`);
					}),
					_.trees.flatMap((t) => (e.treeLeaves[t] ?? []).map((e, n) => {
						let [r, i] = Q(t);
						return /* @__PURE__ */ f("g", {
							transform: `translate(${r - 30 + n * 15} ${i + 30}) scale(.37)`,
							pointerEvents: "none",
							children: /* @__PURE__ */ f(Me, { color: b(e) })
						}, `${t}${e}`);
					})),
					G && P.length > 0 && j && /* @__PURE__ */ f(Ye, {
						plan: P,
						start: e.discs[j] ?? [],
						sloth: e.sloths[i]
					}),
					e.species.flatMap((t) => (t === j && G ? G.discs : e.discs[t] ?? []).map((e, n) => {
						let [r, i] = Q(e), a = pe.get(e);
						return /* @__PURE__ */ f(Le, {
							species: t,
							x: r,
							y: i,
							available: a?.kind === "disc" || a?.kind === "ant",
							selected: t === j && n === ye,
							stepCount: t === j && n === ye ? P.length : 0
						}, `${t}${n}`);
					})),
					Object.entries(e.sloths).map(([e, t], n) => {
						let [r, a] = Q(e === i && G ? G.sloth : t);
						return /* @__PURE__ */ f(Re, {
							x: r + n % 3 * 16 - 16,
							y: a + 34,
							color: b(e)
						}, e);
					}),
					L === "carry" && z.map((e) => {
						let t = G?.discs[e];
						return t ? /* @__PURE__ */ f("polygon", {
							points: Ue(t, 46),
							fill: "none",
							stroke: "#fffdf3",
							strokeWidth: 6,
							pointerEvents: "none"
						}, `ca${e}`) : null;
					})
				]
			}, e.board)
		})
	});
}
function Ye({ plan: e, start: t, sloth: n }) {
	let r = [...t], i = [], a = n;
	for (let t of e) t.k === "step" ? (i.push([r[t.disc], t.to]), r[t.disc] = t.to, a = t.to) : t.k === "drop" || t.k === "neckDrop" || t.k === "throw" || t.k === "carry" ? (a && i.push([a, t.to]), a = t.to) : t.k === "hop" ? (i.push([r[0], t.to]), r[0] = t.to, a = t.to) : t.k === "fetch" || t.k === "fly" ? (i.push([r[0], t.to]), r[0] = t.to) : (t.k === "pickup" || t.k === "neckPick") && a && i.push([r[t.disc], a]);
	return /* @__PURE__ */ f("g", {
		pointerEvents: "none",
		children: i.map(([e, t], n) => {
			let [r, i] = Q(e), [a, o] = Q(t);
			return /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("line", {
				x1: r,
				y1: i,
				x2: a,
				y2: o,
				stroke: "#fff9e9",
				strokeWidth: 12,
				strokeLinecap: "round",
				opacity: .9
			}), /* @__PURE__ */ f("line", {
				x1: r,
				y1: i,
				x2: a,
				y2: o,
				stroke: "#263e37",
				strokeWidth: 5,
				strokeDasharray: "7 8",
				strokeLinecap: "round"
			})] }, n);
		})
	});
}
function Xe({ sim: e, av: t, sp: n, selDisc: r, op: i, chain: a, planOk: s, onOp: c, onPickup: l, onNeckPick: u, onUndo: m, onCancel: h, onConfirm: g }) {
	let _ = o(), v = y[n], b = e.active === -1 ? r : e.active, x = t.pickup.length === 1 ? t.pickup[0] : b !== null && t.pickup.includes(b) ? b : null, S = t.neckPick.length === 1 ? t.neckPick[0] : b !== null && t.neckPick.includes(b) ? b : null;
	return /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base px-3",
			style: { backgroundColor: H.accent },
			disabled: !s,
			onClick: g,
			children: _("games.fastsloths.endMove")
		}),
		(v.kind === "walk" || v.kind === "elephant" || v.kind === "human") && !e.carried && t.pickup.length > 0 && /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-quiet min-h-11 px-2",
			disabled: x === null,
			onClick: () => x !== null && l(x),
			children: _("games.fastsloths.actPickup")
		}),
		v.kind === "giraffe" && !e.carried && t.neckPick.length > 0 && /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-quiet min-h-11 px-2",
			disabled: S === null,
			onClick: () => S !== null && u(S),
			children: _("games.fastsloths.actNeckPick")
		}),
		(t.drop.length > 0 || t.neckDrop.length > 0) && /* @__PURE__ */ f("button", {
			type: "button",
			className: `btn-quiet min-h-11 px-2 ${i === "drop" ? "is-active" : ""}`,
			"aria-pressed": i === "drop",
			onClick: () => c(i === "drop" ? null : "drop"),
			children: v.kind === "giraffe" ? _("games.fastsloths.actNeckDrop") : _("games.fastsloths.actDrop")
		}),
		v.kind === "orangutan" && t.throws.length > 0 && /* @__PURE__ */ f("button", {
			type: "button",
			className: `btn-quiet min-h-11 px-2 ${i === "throw" ? "is-active" : ""}`,
			"aria-pressed": i === "throw",
			onClick: () => c(i === "throw" ? null : "throw"),
			children: _("games.fastsloths.actThrow")
		}),
		v.kind === "elephant" && t.throws.length > 0 && /* @__PURE__ */ f("button", {
			type: "button",
			className: `btn-quiet min-h-11 px-2 ${i === "throw" ? "is-active" : ""}`,
			"aria-pressed": i === "throw",
			onClick: () => c(i === "throw" ? null : "throw"),
			children: _("games.fastsloths.actThrow")
		}),
		v.kind === "ant" && !e.dropped && /* @__PURE__ */ p("button", {
			type: "button",
			className: `btn-quiet min-h-11 px-2 ${i === "carry" ? "is-active" : ""}`,
			"aria-pressed": i === "carry",
			onClick: () => c(i === "carry" ? null : "carry"),
			children: [_("games.fastsloths.actCarry"), a.length > 0 ? `(${a.length})` : ""]
		}),
		/* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-quiet min-h-11 px-2",
			disabled: e === null,
			onClick: m,
			children: _("games.fastsloths.undo")
		}),
		/* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-quiet min-h-11 px-2",
			onClick: h,
			children: _("games.fastsloths.cancel")
		})
	] });
}
//#endregion
//#region src/games/fastsloths/bot.ts
function Ze(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var $ = (e, t) => {
	let [n, r] = te(e), [i, a] = te(t);
	return Math.hypot(n - i, r - a);
}, Qe = (e, t) => t.reduce((t, n) => $(e, n) < $(e, t) ? n : t);
function $e(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let r of e.species) if (r !== t) for (let t of e.discs[r] ?? []) n.add(t);
	return n;
}
function et(e, t, n) {
	let r = t.trees.filter((t) => e.treeLeaves[t]?.includes(n));
	return r.length > 0 ? r : t.trees;
}
function tt(e, t, n) {
	let r = /* @__PURE__ */ new Map(), i = [];
	for (let a of n) !r.has(a) && I(e, t, a) && (r.set(a, 0), i.push(a));
	for (let n = 0; n < i.length; n += 1) {
		let a = (r.get(i[n]) ?? 0) + 1;
		for (let o of D(i[n])) !r.has(o) && I(e, t, o) && (r.set(o, a), i.push(o));
	}
	return r;
}
function nt(e, t, n) {
	return t.filter((t) => (n.get(t.to) ?? Infinity) < (n.get(e.discs[t.disc]) ?? Infinity)).sort((e, t) => (n.get(e.to) ?? 0) - (n.get(t.to) ?? 0))[0];
}
function rt(e, t, n, r, i) {
	let a = h[e.board], o = y[n], s = r.reduce((e, t) => e + t, 0) + o.mod, c = e.sloths[t];
	if (!c) return i?.push("no-sloth"), null;
	let l = ne(a, n, s, e.discs[n] ?? [], $e(e, n), c), u = [], d = null, f = null, p = (e) => {
		if (!d) {
			let t = e.flatMap((e) => [e, ...D(e)]);
			d = tt(a, n, t);
		}
		return d;
	}, m = () => (f ||= tt(a, n, [c, ...D(c)]), f);
	for (let r = 0; r < 60 && !l.dropped; r += 1) {
		let r = se(l), i = et(e, a, t), o = (e) => !ae(l, e) && (u.push(e), !0);
		if (l.carried) {
			let e = l.discs[l.active === -1 ? 0 : l.active], t = [...r.drop, ...r.neckDrop], n = t.find((e) => i.includes(e));
			if (n) {
				o(r.drop.includes(n) ? {
					k: "drop",
					to: n
				} : {
					k: "neckDrop",
					to: n
				});
				break;
			}
			let a = Qe(e, i), s = $(e, a), c = p(i), u = nt(l, r.steps, c), d = r.hops.filter((e) => $(e, a) < s - 1e-6).sort((e, t) => $(e, a) - $(t, a))[0], f = r.fly.filter((e) => $(e, a) < s - 1e-6).sort((e, t) => $(e, a) - $(t, a))[0], m = r.throws.filter((e) => i.includes(e.to))[0] ?? r.throws.filter((e) => $(e.to, a) < s - 1e-6).sort((e, t) => $(e.to, a) - $(t.to, a))[0];
			if (m && (i.includes(m.to) || !u)) {
				if (o({
					k: "throw",
					disc: m.disc,
					to: m.to
				})) break;
			} else if (d) {
				if (!o({
					k: "hop",
					to: d
				})) break;
			} else if (f) {
				if (!o({
					k: "fly",
					to: f
				})) break;
			} else if (u) {
				if (!o({
					k: "step",
					disc: u.disc,
					to: u.to
				})) break;
			} else if (c.get(e) === void 0 && r.steps.length > 0) {
				let e = r.steps.filter((e) => $(e.to, a) < s - 1e-6).sort((e, t) => $(e.to, a) - $(t.to, a))[0];
				if (e && o({
					k: "step",
					disc: e.disc,
					to: e.to
				})) continue;
				t.length > 0 && o(r.drop.length > 0 ? {
					k: "drop",
					to: t[0]
				} : {
					k: "neckDrop",
					to: t[0]
				});
				break;
			} else if (t.length > 0) {
				o(r.drop.length > 0 ? {
					k: "drop",
					to: t[0]
				} : {
					k: "neckDrop",
					to: t[0]
				});
				break;
			} else break;
			continue;
		}
		if (r.fetch.length > 0) {
			if (!o({
				k: "fetch",
				to: r.fetch.find((e) => i.includes(e)) ?? r.fetch[0]
			})) break;
			continue;
		}
		if (r.pickup.length > 0) {
			if (!o({
				k: "pickup",
				disc: r.pickup[0]
			})) break;
			continue;
		}
		if (r.neckPick.length > 0) {
			if (!o({
				k: "neckPick",
				disc: r.neckPick[0]
			})) break;
			continue;
		}
		if (n === "ant") {
			let e = !1;
			for (let t = 0; t < l.discs.length && !e; t += 1) {
				let n = [];
				for (;;) {
					let r = ce(l, n);
					if (n.length === 0) {
						if (!r.add.includes(t)) break;
						n.push(t);
					} else {
						if (r.add.length === 0) break;
						n.push(r.add[0]);
					}
					let a = ce(l, n), s = a.to.filter((e) => i.includes(e))[0] ?? [...a.to].filter((e) => e !== l.sloth).sort((e, t) => $(e, Qe(l.sloth, i)) - $(t, Qe(l.sloth, i)))[0];
					if (s !== void 0) {
						e = o({
							k: "carry",
							ants: n,
							to: s
						});
						break;
					}
				}
			}
			if (e) continue;
		}
		let s = nt(l, r.steps, m());
		if (s) {
			if (!o({
				k: "step",
				disc: s.disc,
				to: s.to
			})) break;
			continue;
		}
		if (r.hops.length > 0) {
			let e = [...r.hops].sort((e, t) => $(e, c) - $(t, c))[0];
			if ($(e, c) < $(l.discs[0], c) - 1e-6) {
				if (!o({
					k: "hop",
					to: e
				})) break;
				continue;
			}
		}
		let d = nt(l, r.steps, p(i));
		if (d) {
			if (!o({
				k: "step",
				disc: d.disc,
				to: d.to
			})) break;
			continue;
		}
		break;
	}
	if (l.carried) {
		let n = se(l), r = [...n.drop, ...n.neckDrop];
		if (r.length === 0) return i?.push("no-drop"), null;
		let o = et(e, a, t), s = r.find((e) => o.includes(e)) ?? r[0];
		if (ae(l, n.drop.includes(s) ? {
			k: "drop",
			to: s
		} : {
			k: "neckDrop",
			to: s
		})) return i?.push("drop-rej"), null;
		u.push(n.drop.includes(s) ? {
			k: "drop",
			to: s
		} : {
			k: "neckDrop",
			to: s
		});
	}
	if (u.length === 0) return i?.push("empty"), null;
	let g = oe(l);
	return g === null ? u : (i?.push(`finish:${g}`), null);
}
function it(e, t, n, r, i) {
	let a = h[e.board], o = y[n], s = r.reduce((e, t) => e + t, 0) + o.mod, c = e.discs[n] ?? [], l = e.sloths[t], u = ne(a, n, s, c, $e(e, n), l);
	for (let e of i) ae(u, e);
	let d = et(e, a, t), f = new Set(u.leafCells.filter((n) => e.treeLeaves[n]?.includes(t))).size, p = $(l, Qe(l, d)), m = $(u.sloth, Qe(u.sloth, d)), g = 0;
	if (u.sloth === l) for (let e = 0; e < c.length; e += 1) g += Math.max(0, $(c[e], l) - $(u.discs[e], l));
	return f * 1e3 + (p - m) * 10 + g * 3 + (u.carried ? 5 : 0) - i.length * .1;
}
var at = (e, t) => {
	let n = e.public, r = e.private, i = t.rid, a = t.difficulty === "weak", o = h[n.board];
	if (n.phase === "setup" && n.setup?.rid === i) {
		if (n.setup.kind === "tree") {
			let e = o.trees.filter((e) => !Object.values(n.sloths).includes(e));
			if (e.length === 0) return null;
			if (a) return { action: {
				type: "pickTree",
				cell: Ze(e)
			} };
			let t = n.species.flatMap((e) => n.discs[e] ?? []);
			return { action: {
				type: "pickTree",
				cell: [...e].sort((e, n) => t.reduce((t, n) => t + $(e, n), 0) - t.reduce((e, t) => e + $(n, t), 0))[0]
			} };
		}
		let e = n.species.filter((e) => (n.setup?.supply[e] ?? 0) > 0).sort((e, t) => (n.setup?.supply[t] ?? 0) - (n.setup?.supply[e] ?? 0))[0];
		if (!e) return null;
		let t = /* @__PURE__ */ new Set();
		for (let e of n.species) for (let r of n.discs[e] ?? []) t.add(r);
		let r = [];
		for (let n = -1; n <= 17; n += 1) {
			let i = n % 2 == 0 ? 11 : 12;
			for (let a = 0; a < i; a += 1) {
				let i = `${n},${a}`;
				!t.has(i) && I(o, e, i) && r.push(i);
			}
		}
		if (r.length === 0) return null;
		if (a) return { action: {
			type: "placeDisc",
			species: e,
			cell: Ze(r)
		} };
		let i = r.filter((e) => o.trees.some((t) => $(e, t) < 3));
		return { action: {
			type: "placeDisc",
			species: e,
			cell: Ze(i.length > 0 ? i : r)
		} };
	}
	if (n.phase !== "turn" || n.turn !== i || !r) return null;
	let s = x(n.leaves[i] ?? 1);
	if (n.turnPhase === "draw") {
		let e = n.species.filter((e) => (n.piles[e]?.count ?? 0) > 0), t = Math.min(s.draw, e.length);
		if (t === 0) return null;
		let i = new Set(r.hand.map((e) => e.sp));
		return { action: {
			type: "draw",
			piles: (a ? [...e].sort(() => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 2 - .5) : [...e].sort((e, t) => {
				let r = +!!i.has(e), a = +!!i.has(t);
				return r === a ? (n.piles[t]?.top ?? 0) - (n.piles[e]?.top ?? 0) : r - a;
			})).slice(0, t)
		} };
	}
	if (n.turnPhase === "discard1" || n.turnPhase === "limit") {
		let e = n.turnPhase === "discard1" ? 1 : r.hand.length - s.limit;
		if (e <= 0) return null;
		let t = /* @__PURE__ */ new Map();
		for (let e of r.hand) t.set(e.sp, (t.get(e.sp) ?? 0) + 1);
		return { action: {
			type: "discard",
			cards: [...r.hand].sort((e, n) => (t.get(n.sp) ?? 0) - (t.get(e.sp) ?? 0) || e.v - n.v).slice(0, e)
		} };
	}
	if (n.turnPhase === "play") {
		let e = /* @__PURE__ */ new Map();
		for (let t of r.hand) n.species.includes(t.sp) && (e.has(t.sp) || e.set(t.sp, []), e.get(t.sp)?.push(t.v));
		let t = null;
		for (let [r, o] of e) {
			let e = y[r], s = [...o].sort((e, t) => t - e), c = e.singleCard || a ? [s[0]] : s, l = rt(n, i, r, c);
			if (!l) continue;
			let u = it(n, i, r, c, l);
			a && u < 1e3 && crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 2 == 0 || (!t || u > t.score) && (t = {
				sp: r,
				values: c,
				plan: l,
				score: u
			});
		}
		return t && t.score > .5 ? { action: {
			type: "play",
			species: t.sp,
			cards: t.values,
			plan: t.plan
		} } : { action: { type: "pass" } };
	}
	return null;
};
//#endregion
//#region src/games/fastsloths/game-over.tsx
function ot(e) {
	return /* @__PURE__ */ f("div", {
		className: "fs-result",
		children: /* @__PURE__ */ f(m, {
			result: e.result,
			hintCount: e.hintCount,
			members: e.members,
			myRid: e.myRid,
			accent: H.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby
		})
	});
}
//#endregion
//#region src/games/fastsloths/options.tsx
var st = [
	0,
	1,
	2,
	3,
	6
], ct = [
	"A",
	"B",
	"C",
	"D"
], lt = [
	"donkey",
	"rabbit",
	"unicorn",
	"human",
	"crocodile",
	"dolphin",
	"elephant",
	"giraffe",
	"eagle",
	"goat",
	"ant",
	"orangutan"
];
function ut({ value: e, onChange: t }) {
	let n = o(), r = K.safeParse(e), i = r.success ? r.data : K.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "fs-options flex flex-col gap-3",
		children: [/* @__PURE__ */ f("div", {
			className: "grid grid-cols-2 gap-2",
			children: ["scenario", "draft"].map((e) => /* @__PURE__ */ f("button", {
				type: "button",
				onClick: () => t({
					...i,
					mode: e
				}),
				className: `card fs-option-card min-h-11 cursor-pointer p-2 text-center text-sm font-bold ${i.mode === e ? "is-selected" : ""}`,
				"aria-pressed": i.mode === e,
				children: n(e === "scenario" ? "games.fastsloths.modeScenario" : "games.fastsloths.modeDraft")
			}, e))
		}), i.mode === "scenario" ? /* @__PURE__ */ f("div", {
			className: "grid grid-cols-5 gap-2",
			children: st.map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => t({
					...i,
					scenario: e
				}),
				className: `card fs-option-card flex min-h-11 cursor-pointer items-center justify-center gap-1 p-2 text-center text-sm font-bold ${i.scenario === e ? "is-selected" : ""}`,
				"aria-pressed": i.scenario === e,
				children: [/* @__PURE__ */ f(Ne, { size: 15 }), e]
			}, e))
		}) : /* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("p", {
				className: "section-label",
				children: n("games.fastsloths.board")
			}),
			/* @__PURE__ */ f("div", {
				className: "grid grid-cols-4 gap-2",
				children: ct.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => t({
						...i,
						board: e
					}),
					className: `card fs-option-card min-h-11 cursor-pointer p-2 text-center text-sm font-bold ${i.board === e ? "is-selected" : ""}`,
					"aria-pressed": i.board === e,
					children: e
				}, e))
			}),
			/* @__PURE__ */ f("p", {
				className: "section-label",
				children: n("games.fastsloths.speciesPick")
			}),
			/* @__PURE__ */ f("div", {
				className: "grid grid-cols-4 gap-2",
				children: lt.map((e) => {
					let r = i.species.includes(e);
					return /* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => {
							let n = i.species, a = r ? n.filter((t) => t !== e) : n.length < 6 ? [...n, e] : n;
							t({
								...i,
								species: a
							});
						},
						className: `card fs-option-card flex min-h-11 cursor-pointer flex-col items-center p-1 text-xs font-bold ${r ? "is-selected" : ""}`,
						"aria-pressed": r,
						children: [/* @__PURE__ */ f(Ie, {
							species: e,
							size: 28
						}), n(ee[e])]
					}, e);
				})
			})
		] })]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fastsloths/entry.tsx
var dt = {
	definition: we,
	View: qe,
	bot: at,
	OverView: ot,
	Options: ut,
	locales: {
		zh: {
			name: "树懒快跑",
			desc: "偷懒的树懒让动物驮着环游度假村,先收集八枚树叶者获胜",
			rules: "目标:让动物驮着你的树懒环游度假村,最先收集八枚树叶者获胜。\n准备:\n· 按场景摆好版图与动物圆片,每种动物一叠十张牌,牌面从小到大堆放。\n· 从末位玩家开始倒序选择起始树:把树懒放到一棵空树上,收下自己在该树的树叶。\n流程:每回合依次进行三个阶段。\n· 抽牌(必做):按树懒板当前列抽取三张或两张,每张须来自不同牌堆的堆顶。\n· 弃牌:第二、三、七、八列抽牌后,须从手牌中选一张放回对应牌堆底。\n· 移动(可选):打出单一物种的任意张牌,点数相加后移动该物种一只圆片。\n· 移动中可在圆片所在格或邻格免费接起树懒;放下树懒即结束移动,剩余点数作废。\n· 阶段末检查手牌上限,超出则弃至上限;打出的牌从小到大放回对应牌堆底。\n动物:\n· 驴永不过河;兔子只走平原并加两点;独角兽每回合只能打一张牌。\n· 鳄鱼走河与邻河岸,不能跨越内陆边界;海豚只走河;大象与长颈鹿可下水。\n· 山羊进山不耗点;人类沿小径在度假村间跳跃;老鹰集满六点可飞来驮你。\n· 蚂蚁先各自移动再结成蚁链驮运;猩猩先移动再花两点把你抛出三格。\n收叶:树懒被接起、驮行经过或被放在树格时,收下自己在该树的树叶。\n结算:有人集齐第八枚树叶后,其余玩家各补一回合;树叶多者胜,平手比手牌点数总和。",
			spDonkey: "驴",
			spRabbit: "兔子",
			spUnicorn: "独角兽",
			spHuman: "人类",
			spCrocodile: "鳄鱼",
			spDolphin: "海豚",
			spElephant: "大象",
			spGiraffe: "长颈鹿",
			spEagle: "老鹰",
			spGoat: "山羊",
			spAnt: "蚂蚁",
			spOrangutan: "猩猩",
			modeScenario: "场景",
			modeDraft: "自选",
			scenario: "场景 {{n}}",
			board: "版图",
			speciesPick: "选择六种动物",
			setupTree: "选择你的起始树",
			setupDisc: "摆放一只动物圆片",
			waitingSetup: "等待其他玩家摆放",
			drawPrompt: "抽牌:选择 {{n}} 个不同牌堆",
			discard1Prompt: "从手牌中选一张弃到对应牌堆底",
			playPrompt: "打牌移动,或跳过",
			limitPrompt: "弃牌至手牌上限 {{n}} 张",
			waiting: "等待 {{name}}",
			finalRound: "末轮:有人集齐了八枚树叶",
			confirm: "确认",
			cancel: "取消",
			pass: "跳过",
			undo: "撤销一步",
			startMove: "开始移动",
			endMove: "完成移动",
			actPickup: "接我",
			actDrop: "放下",
			actThrow: "抛掷",
			actNeckPick: "颈接",
			actNeckDrop: "颈放",
			actCarry: "蚁链驮运",
			actHop: "跳往度假村",
			actFetch: "飞来",
			pointsLeft: "剩余 {{n}} 点",
			leaves: "树叶 {{n}}/8",
			handLimit: "手牌上限 {{n}}",
			pileCount: "{{n}} 张",
			selectedCards: "已选 {{n}} 张",
			handEmpty: "白手起家:先抽牌",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			fullMap: "全图",
			errTurn: "还没轮到你",
			errPhase: "当前阶段不能这样做",
			errCard: "手牌中没有这些牌",
			errPiles: "请从不同的非空牌堆抽牌",
			errDiscard: "弃牌数量不对",
			errTree: "这棵树已被占据",
			errCell: "目标格不可用",
			errSpecies: "该物种不在本局或已无圆片",
			errTerrain: "该物种不能进入这种地形",
			errOccupied: "终点已有其他动物",
			errStep: "不能走到该格",
			errBridge: "只能从桥的两端上下桥",
			errCroc: "鳄鱼不能跨越内陆边界",
			errPoints: "移动力不足",
			errSloth: "树懒不在接送范围内",
			errDropCell: "树懒不能被放到山上或河里",
			errCarried: "移动结束时树懒必须已被放下",
			errEagle: "老鹰需要至少六点移动力才能激活",
			errChain: "蚁链必须相连,且每只蚂蚁每回合只能驮一次",
			errDisc: "一次只能移动一只圆片",
			errOrder: "动作顺序不合法"
		},
		en: {
			name: "Fast Sloths",
			desc: "Lazy sloths hitch rides on animals around the resort; first to eight leaves wins",
			rules: "Goal: let the animals carry your sloth around the resort; the first to collect eight leaves wins.\nSetup:\n· Lay out the board and animal discs of the scenario; each species has a stack of ten cards in ascending order.\n· Starting from the last player in reverse order, pick a starting tree: place your sloth on an empty tree and take your leaf from it.\nPlay: each turn has three steps in order.\n· Draw (mandatory): draw three or two cards as shown on your sloth board, each from the top of a different stack.\n· Discard: on columns two, three, seven and eight, discard one card from your hand below its matching stack.\n· Move (optional): play any number of cards of a single species, sum their points, and move one disc of that species.\n· During movement, picking up your sloth on the disc's space or an adjacent one is free; dropping the sloth ends the movement and remaining points are lost.\n· At the end of the turn, check your hand limit and discard excess cards; played cards return below their stacks in ascending order.\nAnimals:\n· Donkeys never cross the river; rabbits move on plains only and add two points; only one card per turn moves the unicorn.\n· Crocodiles swim the river and adjacent banks but never cross hinterland borders; dolphins stay in the river; elephants and giraffes may enter the water.\n· Goats enter mountains for free; the human hops between resorts along the paths; the eagle needs six points to fly to you.\n· Ants first move one by one, then carry you in chains; orangutans first move, then throw you up to three spaces for two points.\nLeaves: when your sloth is picked up on, carried through, or dropped on a tree space, collect your leaf from that tree.\nScoring: once someone collects the eighth leaf, everyone else takes one more turn; most leaves wins, ties break on hand card points.",
			spDonkey: "Donkey",
			spRabbit: "Rabbit",
			spUnicorn: "Unicorn",
			spHuman: "Human",
			spCrocodile: "Crocodile",
			spDolphin: "Dolphin",
			spElephant: "Elephant",
			spGiraffe: "Giraffe",
			spEagle: "Eagle",
			spGoat: "Goat",
			spAnt: "Ant",
			spOrangutan: "Orangutan",
			modeScenario: "Scenario",
			modeDraft: "Draft",
			scenario: "Scenario {{n}}",
			board: "Board",
			speciesPick: "Pick six species",
			setupTree: "Choose your starting tree",
			setupDisc: "Place an animal disc",
			waitingSetup: "Waiting for others to set up",
			drawPrompt: "Draw: pick {{n}} different stacks",
			discard1Prompt: "Discard one card from your hand below its stack",
			playPrompt: "Play cards to move, or pass",
			limitPrompt: "Discard down to the hand limit of {{n}}",
			waiting: "Waiting for {{name}}",
			finalRound: "Final round: someone collected the eighth leaf",
			confirm: "Confirm",
			cancel: "Cancel",
			pass: "Pass",
			undo: "Undo",
			startMove: "Start moving",
			endMove: "Done",
			actPickup: "Pick me up",
			actDrop: "Drop",
			actThrow: "Throw",
			actNeckPick: "Neck pick",
			actNeckDrop: "Neck drop",
			actCarry: "Ant carry",
			actHop: "Hop to resort",
			actFetch: "Fetch",
			pointsLeft: "{{n}} points left",
			leaves: "Leaves {{n}}/8",
			handLimit: "Hand limit {{n}}",
			pileCount: "{{n}} cards",
			selectedCards: "{{n}} selected",
			handEmpty: "Empty-handed: draw first",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			fullMap: "Full map",
			errTurn: "Not your turn",
			errPhase: "Not allowed in this phase",
			errCard: "Those cards are not in your hand",
			errPiles: "Pick distinct non-empty stacks",
			errDiscard: "Wrong number of discards",
			errTree: "That tree is taken",
			errCell: "Space not available",
			errSpecies: "Species not in this game or out of discs",
			errTerrain: "This species cannot enter that terrain",
			errOccupied: "Another animal occupies the destination",
			errStep: "Cannot move there",
			errBridge: "Bridges can only be entered from their ends",
			errCroc: "Crocodiles cannot cross hinterland borders",
			errPoints: "Not enough movement points",
			errSloth: "Your sloth is out of reach",
			errDropCell: "Sloths cannot be dropped on mountains or in the river",
			errCarried: "The sloth must be dropped before the movement ends",
			errEagle: "The eagle needs at least six movement points",
			errChain: "The ant chain must be connected; each ant carries once per turn",
			errDisc: "Only one disc may move per play",
			errOrder: "Illegal action order"
		}
	}
};
//#endregion
export { dt as default };
