import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useState as r } from "react";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { IconCheck as s, IconClose as c } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { Texture as u } from "@bgparty/sdk/texture";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as b, OptionSection as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/deepsea/schema.ts
var S = t.object({
	s: t.enum([
		"pink",
		"blue",
		"green",
		"yellow",
		"sub"
	]),
	v: t.int().min(1).max(9)
}), C = t.enum([
	"top",
	"middle",
	"bottom"
]), w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pick"),
		taskId: t.int().min(1).max(96),
		prediction: t.int().min(0).max(13).optional()
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("play"),
		card: S
	}),
	t.object({
		type: t.literal("comm"),
		card: S,
		pos: C
	}),
	t.object({
		type: t.literal("retry"),
		redraw: t.boolean()
	}),
	t.object({ type: t.literal("next") })
]), T = t.object({ difficulty: t.int().min(1).max(10).catch(2) }).default({ difficulty: 2 }), E = t.string(), ee = t.array(t.object({
	rid: E,
	card: S
})), te = t.object({
	id: t.int().min(1).max(96),
	owner: E,
	status: t.enum([
		"done",
		"failed",
		"pending"
	]),
	prediction: t.int().min(0).max(13).nullable()
}), ne = t.object({
	phase: t.enum([
		"pick",
		"play",
		"won",
		"lost"
	]),
	difficulty: t.int().min(1),
	attempts: t.int().min(1),
	captain: E,
	totalTricks: t.int().min(1),
	pool: t.array(t.int().min(1).max(96)),
	picker: E.nullable(),
	canPass: t.boolean(),
	players: t.array(t.object({
		rid: E,
		handCount: t.int().nonnegative(),
		tricksWon: t.int().nonnegative(),
		captured: t.array(S),
		commUsed: t.boolean(),
		comm: t.object({
			card: S,
			pos: C
		}).nullable()
	})),
	trick: t.object({
		leader: E,
		plays: ee
	}),
	lastTrick: t.object({
		plays: ee,
		winner: E
	}).nullable(),
	tasks: t.array(te),
	failedTask: t.object({
		id: t.int().min(1).max(96),
		owner: E
	}).nullable()
}), D = t.object({
	hand: t.array(S),
	mustFollow: t.enum([
		"pink",
		"blue",
		"green",
		"yellow",
		"sub"
	]).nullable(),
	canComm: t.boolean()
}), O = (e, t) => ({
	s: e,
	v: t
}), re = [
	{
		id: 1,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t1",
		slots: [],
		kind: {
			k: "cmpAll",
			cmp: "more"
		}
	},
	{
		id: 2,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t2",
		slots: [],
		kind: { k: "moreCombined" }
	},
	{
		id: 3,
		diff: [
			2,
			2,
			3
		],
		text: "games.deepsea.tasks.t3",
		slots: [],
		kind: {
			k: "cmpAll",
			cmp: "fewer"
		}
	},
	{
		id: 4,
		diff: [
			2,
			2,
			3
		],
		text: "games.deepsea.tasks.t4",
		slots: [],
		kind: {
			k: "cmpCaptain",
			cmp: "more"
		}
	},
	{
		id: 5,
		diff: [
			2,
			2,
			2
		],
		text: "games.deepsea.tasks.t5",
		slots: [],
		kind: {
			k: "cmpCaptain",
			cmp: "fewer"
		}
	},
	{
		id: 6,
		diff: [
			4,
			3,
			3
		],
		text: "games.deepsea.tasks.t6",
		slots: [],
		kind: {
			k: "cmpCaptain",
			cmp: "same"
		}
	},
	{
		id: 7,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t7",
		slots: [],
		kind: {
			k: "trickAllCmp",
			cmp: "below",
			n: 7
		}
	},
	{
		id: 8,
		diff: [
			2,
			3,
			4
		],
		text: "games.deepsea.tasks.t8",
		slots: [],
		kind: {
			k: "trickAllCmp",
			cmp: "above",
			n: 5
		}
	},
	{
		id: 9,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t9",
		slots: [{
			kind: "value",
			v: 6
		}],
		kind: {
			k: "winTrickWith",
			v: 6
		}
	},
	{
		id: 10,
		diff: [
			2,
			3,
			4
		],
		text: "games.deepsea.tasks.t10",
		slots: [{
			kind: "value",
			v: 5
		}],
		kind: {
			k: "winTrickWith",
			v: 5
		}
	},
	{
		id: 11,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t11",
		slots: [{
			kind: "value",
			v: 3
		}],
		kind: {
			k: "winTrickWith",
			v: 3
		}
	},
	{
		id: 12,
		diff: [
			1,
			2,
			2
		],
		text: "games.deepsea.tasks.t12",
		slots: [{
			kind: "value",
			v: 5
		}, {
			kind: "value",
			v: 7
		}],
		kind: {
			k: "winCardWith",
			win: 5,
			use: 7
		}
	},
	{
		id: 13,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t13",
		slots: [{
			kind: "value",
			v: 8
		}, {
			kind: "value",
			v: 4
		}],
		kind: {
			k: "winCardWith",
			win: 8,
			use: 4
		}
	},
	{
		id: 14,
		diff: [
			2,
			3,
			4
		],
		text: "games.deepsea.tasks.t14",
		slots: [{
			kind: "value",
			v: 6
		}],
		kind: {
			k: "winCardWith",
			win: 6,
			use: 6
		}
	},
	{
		id: 15,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t15",
		slots: [{
			kind: "value",
			v: 2
		}],
		kind: {
			k: "winTrickWith",
			v: 2
		}
	},
	{
		id: 16,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t16",
		slots: [{
			kind: "card",
			card: O("pink", 3)
		}],
		kind: {
			k: "winCards",
			cards: [O("pink", 3)]
		}
	},
	{
		id: 17,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t17",
		slots: [{
			kind: "card",
			card: O("yellow", 1)
		}],
		kind: {
			k: "winCards",
			cards: [O("yellow", 1)]
		}
	},
	{
		id: 18,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t18",
		slots: [{
			kind: "card",
			card: O("blue", 4)
		}],
		kind: {
			k: "winCards",
			cards: [O("blue", 4)]
		}
	},
	{
		id: 19,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t19",
		slots: [{
			kind: "card",
			card: O("green", 6)
		}],
		kind: {
			k: "winCards",
			cards: [O("green", 6)]
		}
	},
	{
		id: 20,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t20",
		slots: [{
			kind: "value",
			v: 3
		}],
		kind: {
			k: "winValue",
			v: 3,
			count: 4,
			mode: "atLeast"
		}
	},
	{
		id: 21,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t21",
		slots: [{
			kind: "value",
			v: 5
		}],
		kind: {
			k: "winValue",
			v: 5,
			count: 3,
			mode: "atLeast"
		}
	},
	{
		id: 22,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t22",
		slots: [{
			kind: "value",
			v: 9
		}],
		kind: {
			k: "winValue",
			v: 9,
			count: 3,
			mode: "atLeast"
		}
	},
	{
		id: 23,
		diff: [
			2,
			2,
			2
		],
		text: "games.deepsea.tasks.t23",
		slots: [{
			kind: "value",
			v: 7
		}],
		kind: {
			k: "winValue",
			v: 7,
			count: 2,
			mode: "atLeast"
		}
	},
	{
		id: 24,
		diff: [
			4,
			5,
			6
		],
		text: "games.deepsea.tasks.t24",
		slots: [{
			kind: "value",
			v: 9
		}],
		kind: {
			k: "winValue",
			v: 9,
			count: 4,
			mode: "atLeast"
		}
	},
	{
		id: 25,
		diff: [
			3,
			4,
			4
		],
		text: "games.deepsea.tasks.t25",
		slots: [{
			kind: "value",
			v: 6
		}],
		kind: {
			k: "winValue",
			v: 6,
			count: 3,
			mode: "exactly"
		}
	},
	{
		id: 26,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t26",
		slots: [{
			kind: "value",
			v: 9
		}],
		kind: {
			k: "winValue",
			v: 9,
			count: 2,
			mode: "exactly"
		}
	},
	{
		id: 27,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t27",
		slots: [
			{
				kind: "card",
				card: O("blue", 1)
			},
			{
				kind: "card",
				card: O("blue", 2)
			},
			{
				kind: "card",
				card: O("blue", 3)
			}
		],
		kind: {
			k: "winCards",
			cards: [
				O("blue", 1),
				O("blue", 2),
				O("blue", 3)
			]
		}
	},
	{
		id: 28,
		diff: [
			2,
			2,
			3
		],
		text: "games.deepsea.tasks.t28",
		slots: [{
			kind: "card",
			card: O("blue", 6)
		}, {
			kind: "card",
			card: O("yellow", 7)
		}],
		kind: {
			k: "winCards",
			cards: [O("blue", 6), O("yellow", 7)]
		}
	},
	{
		id: 29,
		diff: [
			2,
			2,
			3
		],
		text: "games.deepsea.tasks.t29",
		slots: [{
			kind: "card",
			card: O("pink", 5)
		}, {
			kind: "card",
			card: O("yellow", 6)
		}],
		kind: {
			k: "winCards",
			cards: [O("pink", 5), O("yellow", 6)]
		}
	},
	{
		id: 30,
		diff: [
			2,
			2,
			3
		],
		text: "games.deepsea.tasks.t30",
		slots: [{
			kind: "card",
			card: O("green", 5)
		}, {
			kind: "card",
			card: O("blue", 8)
		}],
		kind: {
			k: "winCards",
			cards: [O("green", 5), O("blue", 8)]
		}
	},
	{
		id: 31,
		diff: [
			2,
			2,
			3
		],
		text: "games.deepsea.tasks.t31",
		slots: [{
			kind: "card",
			card: O("blue", 5)
		}, {
			kind: "card",
			card: O("pink", 8)
		}],
		kind: {
			k: "winCards",
			cards: [O("blue", 5), O("pink", 8)]
		}
	},
	{
		id: 32,
		diff: [
			2,
			2,
			3
		],
		text: "games.deepsea.tasks.t32",
		slots: [{
			kind: "card",
			card: O("pink", 9)
		}, {
			kind: "card",
			card: O("yellow", 8)
		}],
		kind: {
			k: "winCards",
			cards: [O("pink", 9), O("yellow", 8)]
		}
	},
	{
		id: 33,
		diff: [
			2,
			2,
			2
		],
		text: "games.deepsea.tasks.t33",
		slots: [{
			kind: "card",
			card: O("pink", 1)
		}, {
			kind: "card",
			card: O("green", 7)
		}],
		kind: {
			k: "winCards",
			cards: [O("pink", 1), O("green", 7)]
		}
	},
	{
		id: 34,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t34",
		slots: [{
			kind: "card",
			card: O("yellow", 9)
		}, {
			kind: "card",
			card: O("blue", 7)
		}],
		kind: {
			k: "winCards",
			cards: [O("yellow", 9), O("blue", 7)]
		}
	},
	{
		id: 35,
		diff: [
			3,
			4,
			4
		],
		text: "games.deepsea.tasks.t35",
		slots: [
			{
				kind: "card",
				card: O("green", 3)
			},
			{
				kind: "card",
				card: O("yellow", 4)
			},
			{
				kind: "card",
				card: O("yellow", 5)
			}
		],
		kind: {
			k: "winCards",
			cards: [
				O("green", 3),
				O("yellow", 4),
				O("yellow", 5)
			]
		}
	},
	{
		id: 36,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t36",
		slots: [{
			kind: "card",
			card: O("green", 2)
		}],
		kind: {
			k: "winCardInLast",
			card: O("green", 2)
		}
	},
	{
		id: 37,
		diff: [
			4,
			4,
			4
		],
		text: "games.deepsea.tasks.t37",
		slots: [{
			kind: "suit",
			s: "pink"
		}, {
			kind: "suit",
			s: "green"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["pink", 1], ["green", 1]],
			mode: "exactly"
		}
	},
	{
		id: 38,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t38",
		slots: [{
			kind: "suit",
			s: "yellow"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["yellow", 7]],
			mode: "atLeast"
		}
	},
	{
		id: 39,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t39",
		slots: [{
			kind: "suit",
			s: "pink"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["pink", 5]],
			mode: "atLeast"
		}
	},
	{
		id: 40,
		diff: [
			3,
			4,
			4
		],
		text: "games.deepsea.tasks.t40",
		slots: [{
			kind: "suit",
			s: "green"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["green", 2]],
			mode: "exactly"
		}
	},
	{
		id: 41,
		diff: [
			3,
			4,
			4
		],
		text: "games.deepsea.tasks.t41",
		slots: [{
			kind: "suit",
			s: "blue"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["blue", 2]],
			mode: "exactly"
		}
	},
	{
		id: 42,
		diff: [
			3,
			3,
			4
		],
		text: "games.deepsea.tasks.t42",
		slots: [{
			kind: "suit",
			s: "pink"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["pink", 1]],
			mode: "exactly"
		}
	},
	{
		id: 43,
		diff: [
			2,
			2,
			2
		],
		text: "games.deepsea.tasks.t43",
		slots: [{
			kind: "suit",
			s: "pink"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["pink", 0]],
			mode: "exactly"
		}
	},
	{
		id: 44,
		diff: [
			2,
			3,
			4
		],
		text: "games.deepsea.tasks.t44",
		slots: [],
		kind: { k: "oneOfEachSuit" }
	},
	{
		id: 45,
		diff: [
			3,
			4,
			5
		],
		text: "games.deepsea.tasks.t45",
		slots: [],
		kind: { k: "allOfOneSuit" }
	},
	{
		id: 46,
		diff: [
			2,
			5,
			6
		],
		text: "games.deepsea.tasks.t46",
		slots: [],
		kind: {
			k: "trickParity",
			parity: "even"
		}
	},
	{
		id: 47,
		diff: [
			2,
			4,
			5
		],
		text: "games.deepsea.tasks.t47",
		slots: [],
		kind: {
			k: "trickParity",
			parity: "odd"
		}
	},
	{
		id: 48,
		diff: [
			3,
			3,
			4
		],
		text: "games.deepsea.tasks.t48",
		slots: [{
			kind: "num",
			n: [
				23,
				28,
				31
			]
		}],
		kind: {
			k: "trickTotal",
			cmp: "above",
			n: [
				23,
				28,
				31
			]
		}
	},
	{
		id: 49,
		diff: [
			3,
			3,
			4
		],
		text: "games.deepsea.tasks.t49",
		slots: [{
			kind: "num",
			n: [
				8,
				12,
				16
			]
		}],
		kind: {
			k: "trickTotal",
			cmp: "below",
			n: [
				8,
				12,
				16
			]
		}
	},
	{
		id: 50,
		diff: [
			3,
			3,
			4
		],
		text: "games.deepsea.tasks.t50",
		slots: [],
		kind: {
			k: "trickTotalIn",
			n: [22, 23]
		}
	},
	{
		id: 51,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t51",
		slots: [{ kind: "sub" }],
		kind: {
			k: "exactSubs",
			n: 1
		}
	},
	{
		id: 52,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t52",
		slots: [{
			kind: "sub",
			v: 1
		}],
		kind: {
			k: "winSubOnly",
			v: 1
		}
	},
	{
		id: 53,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t53",
		slots: [{
			kind: "sub",
			v: 2
		}],
		kind: {
			k: "winSubOnly",
			v: 2
		}
	},
	{
		id: 54,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t54",
		slots: [{
			kind: "sub",
			v: 3
		}],
		kind: {
			k: "winSub",
			v: 3
		}
	},
	{
		id: 55,
		diff: [
			3,
			3,
			4
		],
		text: "games.deepsea.tasks.t55",
		slots: [{ kind: "sub" }],
		kind: {
			k: "exactSubs",
			n: 2
		}
	},
	{
		id: 56,
		diff: [
			3,
			4,
			4
		],
		text: "games.deepsea.tasks.t56",
		slots: [{ kind: "sub" }],
		kind: {
			k: "exactSubs",
			n: 3
		}
	},
	{
		id: 57,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t57",
		slots: [{ kind: "sub" }],
		kind: {
			k: "exactSubs",
			n: 0
		}
	},
	{
		id: 58,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t58",
		slots: [{
			kind: "card",
			card: O("pink", 7)
		}, { kind: "sub" }],
		kind: {
			k: "winCardWithSub",
			card: O("pink", 7)
		}
	},
	{
		id: 59,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t59",
		slots: [{
			kind: "card",
			card: O("green", 9)
		}, { kind: "sub" }],
		kind: {
			k: "winCardWithSub",
			card: O("green", 9)
		}
	},
	{
		id: 60,
		diff: [
			4,
			3,
			3
		],
		text: "games.deepsea.tasks.t60",
		slots: [
			{
				kind: "suit",
				s: "pink"
			},
			{
				kind: "suit",
				s: "yellow"
			},
			{
				kind: "suit",
				s: "blue"
			}
		],
		kind: {
			k: "dontOpen",
			suits: [
				"pink",
				"yellow",
				"blue"
			]
		}
	},
	{
		id: 61,
		diff: [
			2,
			1,
			1
		],
		text: "games.deepsea.tasks.t61",
		slots: [{
			kind: "suit",
			s: "pink"
		}, {
			kind: "suit",
			s: "green"
		}],
		kind: {
			k: "dontOpen",
			suits: ["pink", "green"]
		}
	},
	{
		id: 62,
		diff: [
			2,
			2,
			2
		],
		text: "games.deepsea.tasks.t62",
		slots: [{
			kind: "suit",
			s: "green"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["green", 0]],
			mode: "exactly"
		}
	},
	{
		id: 63,
		diff: [
			2,
			2,
			2
		],
		text: "games.deepsea.tasks.t63",
		slots: [{
			kind: "suit",
			s: "yellow"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["yellow", 0]],
			mode: "exactly"
		}
	},
	{
		id: 64,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t64",
		slots: [{
			kind: "suit",
			s: "pink"
		}, {
			kind: "suit",
			s: "blue"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["pink", 0], ["blue", 0]],
			mode: "exactly"
		}
	},
	{
		id: 65,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t65",
		slots: [{
			kind: "suit",
			s: "yellow"
		}, {
			kind: "suit",
			s: "green"
		}],
		kind: {
			k: "winSuitCount",
			counts: [["yellow", 0], ["green", 0]],
			mode: "exactly"
		}
	},
	{
		id: 66,
		diff: [
			3,
			3,
			2
		],
		text: "games.deepsea.tasks.t66",
		slots: [{
			kind: "value",
			v: 8
		}, {
			kind: "value",
			v: 9
		}],
		kind: {
			k: "noValues",
			values: [8, 9]
		}
	},
	{
		id: 67,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t67",
		slots: [{
			kind: "value",
			v: 9
		}],
		kind: {
			k: "noValues",
			values: [9]
		}
	},
	{
		id: 68,
		diff: [
			1,
			2,
			2
		],
		text: "games.deepsea.tasks.t68",
		slots: [{
			kind: "value",
			v: 5
		}],
		kind: {
			k: "noValues",
			values: [5]
		}
	},
	{
		id: 69,
		diff: [
			2,
			2,
			2
		],
		text: "games.deepsea.tasks.t69",
		slots: [{
			kind: "value",
			v: 1
		}],
		kind: {
			k: "noValues",
			values: [1]
		}
	},
	{
		id: 70,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t70",
		slots: [
			{
				kind: "value",
				v: 1
			},
			{
				kind: "value",
				v: 2
			},
			{
				kind: "value",
				v: 3
			}
		],
		kind: {
			k: "noValues",
			values: [
				1,
				2,
				3
			]
		}
	},
	{
		id: 71,
		diff: [
			1,
			2,
			3
		],
		text: "games.deepsea.tasks.t71",
		slots: [],
		kind: {
			k: "dontWinFirstN",
			n: 4
		}
	},
	{
		id: 72,
		diff: [
			1,
			2,
			2
		],
		text: "games.deepsea.tasks.t72",
		slots: [],
		kind: {
			k: "dontWinFirstN",
			n: 3
		}
	},
	{
		id: 73,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t73",
		slots: [],
		kind: {
			k: "dontWinFirstN",
			n: 5
		}
	},
	{
		id: 74,
		diff: [
			4,
			3,
			3
		],
		text: "games.deepsea.tasks.t74",
		slots: [],
		kind: { k: "winNoTricks" }
	},
	{
		id: 75,
		diff: [
			3,
			2,
			2
		],
		text: "games.deepsea.tasks.t75",
		slots: [],
		kind: { k: "noTwoConsecutive" }
	},
	{
		id: 76,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t76",
		slots: [],
		kind: { k: "winLastTrick" }
	},
	{
		id: 77,
		diff: [
			2,
			3,
			4
		],
		text: "games.deepsea.tasks.t77",
		slots: [],
		kind: {
			k: "winFirstN",
			n: 3
		}
	},
	{
		id: 78,
		diff: [
			1,
			1,
			2
		],
		text: "games.deepsea.tasks.t78",
		slots: [],
		kind: {
			k: "winFirstN",
			n: 2
		}
	},
	{
		id: 79,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t79",
		slots: [],
		kind: {
			k: "winFirstN",
			n: 1
		}
	},
	{
		id: 80,
		diff: [
			3,
			4,
			4
		],
		text: "games.deepsea.tasks.t80",
		slots: [],
		kind: { k: "winFirstAndLast" }
	},
	{
		id: 81,
		diff: [
			4,
			4,
			4
		],
		text: "games.deepsea.tasks.t81",
		slots: [],
		kind: {
			k: "winOnly",
			which: "last"
		}
	},
	{
		id: 82,
		diff: [
			4,
			3,
			3
		],
		text: "games.deepsea.tasks.t82",
		slots: [],
		kind: {
			k: "winOnly",
			which: "first"
		}
	},
	{
		id: 83,
		diff: [
			3,
			2,
			2
		],
		text: "games.deepsea.tasks.t83",
		slots: [],
		kind: {
			k: "exactTricks",
			n: 1
		}
	},
	{
		id: 84,
		diff: [
			2,
			2,
			2
		],
		text: "games.deepsea.tasks.t84",
		slots: [],
		kind: {
			k: "exactTricks",
			n: 2
		}
	},
	{
		id: 85,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t85",
		slots: [],
		kind: {
			k: "consecutiveTricks",
			n: 2,
			exact: !1
		}
	},
	{
		id: 86,
		diff: [
			2,
			3,
			4
		],
		text: "games.deepsea.tasks.t86",
		slots: [],
		kind: {
			k: "consecutiveTricks",
			n: 3,
			exact: !1
		}
	},
	{
		id: 87,
		diff: [
			2,
			3,
			5
		],
		text: "games.deepsea.tasks.t87",
		slots: [],
		kind: {
			k: "exactTricks",
			n: 4
		}
	},
	{
		id: 88,
		diff: [
			3,
			3,
			4
		],
		text: "games.deepsea.tasks.t88",
		slots: [],
		kind: {
			k: "consecutiveTricks",
			n: 3,
			exact: !0
		}
	},
	{
		id: 89,
		diff: [
			3,
			3,
			3
		],
		text: "games.deepsea.tasks.t89",
		slots: [],
		kind: {
			k: "consecutiveTricks",
			n: 2,
			exact: !0
		}
	},
	{
		id: 90,
		diff: [
			3,
			2,
			2
		],
		text: "games.deepsea.tasks.t90",
		slots: [],
		kind: {
			k: "predictTricks",
			hidden: !1
		}
	},
	{
		id: 91,
		diff: [
			4,
			3,
			3
		],
		text: "games.deepsea.tasks.t91",
		slots: [],
		kind: {
			k: "predictTricks",
			hidden: !0
		}
	},
	{
		id: 92,
		diff: [
			4,
			4,
			4
		],
		text: "games.deepsea.tasks.t92",
		slots: [{
			kind: "suit",
			s: "pink"
		}, {
			kind: "suit",
			s: "yellow"
		}],
		kind: {
			k: "equalSuitsOverall",
			a: "pink",
			b: "yellow"
		}
	},
	{
		id: 93,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t93",
		slots: [{
			kind: "suit",
			s: "green"
		}, {
			kind: "suit",
			s: "yellow"
		}],
		kind: {
			k: "equalSuitsInTrick",
			a: "green",
			b: "yellow"
		}
	},
	{
		id: 94,
		diff: [
			2,
			3,
			3
		],
		text: "games.deepsea.tasks.t94",
		slots: [{
			kind: "suit",
			s: "pink"
		}, {
			kind: "suit",
			s: "blue"
		}],
		kind: {
			k: "equalSuitsInTrick",
			a: "pink",
			b: "blue"
		}
	},
	{
		id: 95,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t95",
		slots: [{
			kind: "suit",
			s: "yellow"
		}, {
			kind: "suit",
			s: "blue"
		}],
		kind: {
			k: "moreSuitThan",
			a: "yellow",
			b: "blue"
		}
	},
	{
		id: 96,
		diff: [
			1,
			1,
			1
		],
		text: "games.deepsea.tasks.t96",
		slots: [{
			kind: "suit",
			s: "pink"
		}, {
			kind: "suit",
			s: "green"
		}],
		kind: {
			k: "moreSuitThan",
			a: "pink",
			b: "green"
		}
	}
];
function k(e) {
	return re[e - 1];
}
var A = (e) => e.s === "sub", j = (e, t) => e.s === t.s && e.v === t.v, M = [
	"pink",
	"blue",
	"green",
	"yellow"
];
function N(e, t, n) {
	let { me: r, tricks: i, totalTricks: a, finished: o } = n, s = i.flatMap((e, t) => e.winner === r ? [t] : []), c = s.map((e) => i[e]), l = c.flatMap((e) => e.plays.map((e) => e.card)), u = l.filter((e) => !A(e)), d = l.filter(A), f = s.length, p = a - i.length, m = i.filter((e) => e.winner !== r).flatMap((e) => e.plays.map((e) => e.card)), h = n.players.filter((e) => e !== r).map((e) => i.filter((t) => t.winner === e).length), g = (e) => e.plays.every((e) => !A(e.card)), _ = (e) => e.plays.reduce((e, t) => e + (A(t.card) ? 0 : t.card.v), 0), v = e.kind;
	switch (v.k) {
		case "cmpAll": {
			if (v.cmp === "more") {
				let e = Math.max(0, ...h);
				return f > e + p ? "done" : o ? f > e ? "done" : "failed" : f + p <= e ? "failed" : "pending";
			}
			let e = Math.min(...h);
			return o ? f < e ? "done" : "failed" : f > e + p ? "failed" : "pending";
		}
		case "moreCombined": {
			let e = h.reduce((e, t) => e + t, 0);
			return f > e + p ? "done" : o ? f > e ? "done" : "failed" : f + p <= e ? "failed" : "pending";
		}
		case "cmpCaptain": {
			let e = i.filter((e) => e.winner === n.captain).length;
			return v.cmp === "more" ? f > e + p ? "done" : o ? f > e ? "done" : "failed" : f + p <= e ? "failed" : "pending" : v.cmp === "fewer" ? o ? f < e ? "done" : "failed" : f > e + p ? "failed" : "pending" : o ? f === e ? "done" : "failed" : f > e + p || e > f + p ? "failed" : "pending";
		}
		case "trickAllCmp": return c.some((e) => g(e) && e.plays.every((e) => v.cmp === "below" ? e.card.v < v.n : e.card.v > v.n)) ? "done" : o ? "failed" : "pending";
		case "winTrickWith": return c.some((e) => e.plays.find((e) => e.rid === r)?.card.v === v.v) ? "done" : o ? "failed" : "pending";
		case "winCardWith": return c.some((e) => {
			let t = e.plays.find((e) => e.rid === r)?.card;
			if (!t || t.v !== v.use) return !1;
			let n = e.plays.filter((e) => e.card.v === v.win && !A(e.card)).length;
			return v.win === v.use ? n >= 2 : n >= 1;
		}) ? "done" : o ? "failed" : "pending";
		case "winCards": return v.cards.every((e) => l.some((t) => j(t, e))) ? "done" : v.cards.some((e) => m.some((t) => j(t, e))) || o ? "failed" : "pending";
		case "winValue": {
			let e = u.filter((e) => e.v === v.v).length, t = 4 - n.played.filter((e) => !A(e) && e.v === v.v).length;
			return v.mode === "atLeast" ? e >= v.count ? "done" : e + t < v.count || o ? "failed" : "pending" : e > v.count || e + t < v.count ? "failed" : e === v.count && t === 0 ? "done" : o ? e === v.count ? "done" : "failed" : "pending";
		}
		case "winSuitCount": {
			let e = !0, t = !1;
			for (let [r, i] of v.counts) {
				let a = u.filter((e) => e.s === r).length, o = 9 - n.played.filter((e) => e.s === r).length;
				v.mode === "exactly" ? ((a > i || a + o < i) && (t = !0), (a !== i || o !== 0) && (e = !1)) : (a + o < i && (t = !0), a < i && (e = !1));
			}
			return t ? "failed" : e ? "done" : o ? "failed" : "pending";
		}
		case "winCardInLast": {
			let e = i[a - 1];
			return e ? e.winner === r && e.plays.some((e) => j(e.card, v.card)) ? "done" : "failed" : m.some((e) => j(e, v.card)) || l.some((e) => j(e, v.card)) ? "failed" : "pending";
		}
		case "oneOfEachSuit":
			if (M.every((e) => u.some((t) => t.s === e))) return "done";
			for (let e of M) {
				let t = n.played.filter((t) => t.s === e).length;
				if (!u.some((t) => t.s === e) && t >= 9) return "failed";
			}
			return o ? "failed" : "pending";
		case "allOfOneSuit":
			for (let e of M) if (u.filter((t) => t.s === e).length === 9) return "done";
			return M.every((e) => m.some((t) => t.s === e)) || o ? "failed" : "pending";
		case "trickParity": return c.some((e) => g(e) && e.plays.every((e) => v.parity === "even" ? e.card.v % 2 == 0 : e.card.v % 2 == 1)) ? "done" : o ? "failed" : "pending";
		case "trickTotal": {
			let e = v.n[n.players.length - 3];
			return c.some((t) => g(t) && (v.cmp === "above" ? _(t) > e : _(t) < e)) ? "done" : o ? "failed" : "pending";
		}
		case "trickTotalIn": return c.some((e) => g(e) && v.n.includes(_(e))) ? "done" : o ? "failed" : "pending";
		case "exactSubs": {
			let e = d.length, t = 4 - n.played.filter(A).length;
			return e > v.n || e + t < v.n ? "failed" : e === v.n && t === 0 ? "done" : o ? e === v.n ? "done" : "failed" : "pending";
		}
		case "winSubOnly": {
			let e = {
				s: "sub",
				v: v.v
			};
			return d.some((e) => e.v !== v.v) || m.some((t) => j(t, e)) ? "failed" : d.some((t) => j(t, e)) ? [
				1,
				2,
				3,
				4
			].filter((e) => e !== v.v).every((e) => m.some((t) => A(t) && t.v === e)) || o ? "done" : "pending" : o ? "failed" : "pending";
		}
		case "winSub": {
			let e = {
				s: "sub",
				v: v.v
			};
			return d.some((t) => j(t, e)) ? "done" : m.some((t) => j(t, e)) || o ? "failed" : "pending";
		}
		case "winCardWithSub": return c.some((e) => {
			let t = e.plays.find((e) => e.rid === r)?.card;
			return t !== void 0 && A(t) && e.plays.some((e) => e.rid !== r && j(e.card, v.card));
		}) ? "done" : m.some((e) => j(e, v.card)) || o ? "failed" : "pending";
		case "dontOpen": return i.some((e) => e.plays[0]?.rid === r && v.suits.includes(e.plays[0].card.s)) || n.openLead !== null && n.openLead.rid === r && v.suits.includes(n.openLead.card.s) ? "failed" : o ? "done" : "pending";
		case "noValues": return u.some((e) => v.values.includes(e.v)) ? "failed" : o ? "done" : "pending";
		case "dontWinFirstN": return s.some((e) => e < v.n) ? "failed" : i.length >= v.n || o ? "done" : "pending";
		case "winNoTricks": return f > 0 ? "failed" : o ? "done" : "pending";
		case "noTwoConsecutive":
			for (let e = 1; e < i.length; e += 1) if (i[e].winner === r && i[e - 1].winner === r) return "failed";
			return o ? "done" : "pending";
		case "winFirstN":
			for (let e = 0; e < v.n && e < i.length; e += 1) if (i[e].winner !== r) return "failed";
			return i.length >= v.n ? "done" : "pending";
		case "winLastTrick": return o ? i[a - 1]?.winner === r ? "done" : "failed" : "pending";
		case "winFirstAndLast": return i.length >= 1 && i[0].winner !== r ? "failed" : o ? i[a - 1]?.winner === r ? "done" : "failed" : "pending";
		case "winOnly": {
			let e = v.which === "first" ? 0 : a - 1;
			return s.some((t) => t !== e) || i.length > e && i[e].winner !== r ? "failed" : o ? s.length === 1 && s[0] === e ? "done" : "failed" : "pending";
		}
		case "exactTricks": return f > v.n ? "failed" : o ? f === v.n ? "done" : "failed" : "pending";
		case "consecutiveTricks": {
			let e = 0, t = 0;
			for (let n of i) e = n.winner === r ? e + 1 : 0, t = Math.max(t, e);
			return v.exact ? f > v.n ? "failed" : o ? f === v.n && t === v.n ? "done" : "failed" : "pending" : t >= v.n ? "done" : o ? "failed" : "pending";
		}
		case "predictTricks": {
			let e = t ?? -1;
			return e < 0 ? "pending" : f > e ? "failed" : o ? f === e ? "done" : "failed" : "pending";
		}
		case "equalSuitsOverall": {
			let e = u.filter((e) => e.s === v.a).length, t = u.filter((e) => e.s === v.b).length, r = 9 - n.played.filter((e) => e.s === v.a).length;
			return e > t + (9 - n.played.filter((e) => e.s === v.b).length) || t > e + r ? "failed" : o ? e === t && e > 0 ? "done" : "failed" : "pending";
		}
		case "equalSuitsInTrick": return c.some((e) => {
			let t = e.plays.filter((e) => e.card.s === v.a).length;
			return t === e.plays.filter((e) => e.card.s === v.b).length && t > 0;
		}) ? "done" : o ? "failed" : "pending";
		case "moreSuitThan": {
			let e = u.filter((e) => e.s === v.a).length, t = u.filter((e) => e.s === v.b).length;
			return e > t + (9 - n.played.filter((e) => e.s === v.b).length) ? "done" : o ? e > t ? "done" : "failed" : "pending";
		}
	}
}
function P(e) {
	switch (e.kind.k) {
		case "cmpAll": return e.kind.cmp === "more";
		case "moreCombined":
		case "winCards":
		case "winCardInLast":
		case "oneOfEachSuit":
		case "allOfOneSuit":
		case "trickAllCmp":
		case "winTrickWith":
		case "winCardWith":
		case "trickParity":
		case "trickTotal":
		case "trickTotalIn":
		case "winCardWithSub":
		case "winFirstN":
		case "winLastTrick":
		case "winFirstAndLast":
		case "winOnly":
		case "equalSuitsOverall":
		case "equalSuitsInTrick":
		case "moreSuitThan": return !0;
		case "winValue": return e.kind.count > 0;
		case "winSuitCount": return e.kind.counts.some(([, e]) => e > 0);
		case "exactSubs": return e.kind.n > 0;
		case "winSubOnly":
		case "winSub": return !0;
		case "exactTricks": return e.kind.n > 0;
		case "consecutiveTricks": return !0;
		case "cmpCaptain": return e.kind.cmp === "more";
		default: return !1;
	}
}
function F(e) {
	let t = e.kind;
	return t.k === "winNoTricks" ? 0 : t.k === "winOnly" ? 1 : t.k === "exactTricks" || t.k === "consecutiveTricks" && t.exact ? t.n : null;
}
function I(e) {
	let t = e.kind;
	return t.k === "winFirstN" || t.k === "consecutiveTricks" ? t.n : t.k === "winFirstAndLast" ? 2 : null;
}
function ie(e) {
	let t = e.kind;
	return t.k === "exactSubs" ? t.n : t.k === "winSubOnly" ? 1 : null;
}
function L(e) {
	let t = e.kind;
	return t.k === "winSubOnly" || t.k === "winSub" || t.k === "winCardWithSub" ? 1 : null;
}
function R(e) {
	let t = e.kind;
	return t.k === "winSuitCount" && t.mode === "exactly" ? t.counts.filter(([, e]) => e === 0).map(([e]) => e) : [];
}
function z(e) {
	let t = e.kind;
	switch (t.k) {
		case "winCards": return t.cards.filter((e) => e.s !== "sub").map((e) => e.s);
		case "winSuitCount": return t.counts.filter(([, e]) => e > 0).map(([e]) => e);
		case "winCardInLast": return t.card.s === "sub" ? [] : [t.card.s];
		case "oneOfEachSuit": return [...M];
		case "equalSuitsOverall":
		case "equalSuitsInTrick": return [t.a, t.b];
		case "moreSuitThan": return [t.a];
		case "winCardWithSub": return t.card.s === "sub" ? [] : [t.card.s];
		default: return [];
	}
}
function B(e) {
	return e.kind.k === "noValues" ? [...e.kind.values] : [];
}
function V(e) {
	let t = e.kind;
	switch (t.k) {
		case "winCards": return t.cards.filter((e) => e.s !== "sub").map((e) => e.v);
		case "winValue": return t.count > 0 ? [t.v] : [];
		case "winTrickWith": return [t.v];
		case "winCardWith": return [t.win, t.use];
		case "winCardInLast": return t.card.s === "sub" ? [] : [t.card.v];
		case "winCardWithSub": return t.card.s === "sub" ? [] : [t.card.v];
		default: return [];
	}
}
function H(e) {
	let t = e.kind;
	return t.k === "winFirstN" || t.k === "winFirstAndLast" || t.k === "winOnly" && t.which === "first";
}
function ae(e, t) {
	if (e.kind.k === "winNoTricks" && P(t) || t.kind.k === "winNoTricks" && P(e)) return !0;
	let [n, r] = [F(e), F(t)], [i, a] = [I(e), I(t)];
	if (n !== null && r !== null && n !== r || n !== null && a !== null && a > n || r !== null && i !== null && i > r || e.kind.k === "dontWinFirstN" && H(t) || t.kind.k === "dontWinFirstN" && H(e) || e.kind.k === "winOnly" && t.kind.k === "winOnly" && e.kind.which !== t.kind.which) return !0;
	let [o, s] = [ie(e), ie(t)], [c, l] = [L(e), L(t)];
	return !!(o !== null && s !== null && o !== s || o !== null && l !== null && l > o || s !== null && c !== null && c > s || R(e).some((e) => z(t).includes(e)) || R(t).some((t) => z(e).includes(t)) || B(e).some((e) => V(t).includes(e)) || B(t).some((t) => V(e).includes(t)));
}
function oe(e, t, n) {
	let r = e.map(k), i = r.map((e) => t.filter((t) => e.kind.k !== "cmpCaptain" || t !== n));
	if (i.some((e) => e.length === 0)) return !1;
	let a = e.length >= t.length, o = r.map((e, t) => t).sort((e, t) => i[e].length - i[t].length), s = Array(r.length).fill(null), c = /* @__PURE__ */ new Map(), l = (e, t) => {
		for (let n = 0; n < r.length; n += 1) if (s[n] === t && ae(r[e], r[n])) return !1;
		return !0;
	}, u = (e) => {
		if (e === o.length) return !a || t.every((e) => (c.get(e) ?? 0) > 0);
		let n = o[e];
		for (let t of i[n]) if (l(n, t)) {
			if (s[n] = t, c.set(t, (c.get(t) ?? 0) + 1), u(e + 1)) return !0;
			s[n] = null, c.set(t, (c.get(t) ?? 1) - 1);
		}
		return !1;
	};
	return u(0);
}
function se(e, t) {
	let n = (t) => e.includes(t);
	for (let e of Object.values(t)) {
		let t = new Set(e.filter(A).map((e) => e.v));
		if (t.size === 4 && (n(51) || n(56)) || n(55) && t.has(2) && t.has(3) && t.has(4) || n(52) && (t.has(1) && t.has(4) || t.has(1) && t.has(2) && t.has(3)) || n(53) && (t.has(2) && t.has(4) || t.has(1) && t.has(2) && t.has(3))) return !0;
	}
	return !1;
}
//#endregion
//#region src/games/deepsea/meta.ts
var U = {
	id: "deepsea",
	tier: "beta",
	mechanics: ["trick-taking"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.deepsea.name",
	descKey: "games.deepsea.desc",
	rulesKey: "games.deepsea.rules",
	icon: "🌊",
	iconImg: "games/deepsea.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/deepsea/en.pdf" },
	precacheAssets: [
		"art-pink.webp",
		"art-blue.webp",
		"art-green.webp",
		"art-yellow.webp",
		"art-sub.webp"
	],
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#0369a1",
	releasedAt: "2026-09-14",
	search: {
		py: "shen hai ren wu",
		init: "shrw"
	},
	hotseat: "cover"
}, ce = [
	"pink",
	"blue",
	"green",
	"yellow"
];
function le() {
	let e = [];
	for (let t of ce) for (let n = 1; n <= 9; n += 1) e.push({
		s: t,
		v: n
	});
	for (let t = 1; t <= 4; t += 1) e.push({
		s: "sub",
		v: t
	});
	return e;
}
function ue(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function de(e, t) {
	let n = e.players.length - 3;
	for (let r = 0; r < 200; r += 1) {
		let r = ue(e, Array.from({ length: 96 }, (e, t) => t + 1)), i = [], a = 0;
		for (let e of r) {
			let r = k(e).diff[n];
			if (!(a + r > t) && (i.push(e), a += r, a === t)) break;
		}
		if (a === t && oe(i, e.players, e.captain)) return i;
	}
	return [54];
}
function W(e) {
	let t = [];
	return e.players.forEach((n, r) => {
		t.push({
			kind: "deal",
			rid: n,
			data: { count: e.hands[n].length },
			for: [n],
			secret: { cards: e.hands[n] },
			...r > 0 ? { with: !0 } : {}
		});
	}), t;
}
function fe(e, t) {
	let n = Math.floor(40 / e.players.length);
	e.totalTricks = n;
	for (let r = 0; r < 50; r += 1) {
		let r = ue(e, le());
		e.hands = {}, e.players.forEach((t, i) => {
			e.hands[t] = r.slice(i * n, (i + 1) * n);
		}), e.captain = e.players.find((t) => e.hands[t].some((e) => e.s === "sub" && e.v === 4)) ?? e.players[0];
		let i = t ?? de(e, e.difficulty);
		if ((!t || oe(t, e.players, e.captain)) && !se(i, e.hands)) {
			e.lastTaskIds = i, e.tasks = [], e.pool = [...i];
			break;
		}
	}
	e.tricks = [], e.trick = {
		leader: e.captain,
		plays: []
	}, e.turn = e.captain, e.pickerIdx = e.players.indexOf(e.captain), e.passStreak = 0, e.commUsed = Object.fromEntries(e.players.map((e) => [e, !1])), e.comm = Object.fromEntries(e.players.map((e) => [e, null])), e.lastTrick = null, e.failedTask = null, e.phase = "pick";
}
function pe(e) {
	let t = (e) => e.s === "sub" ? 4 : ce.indexOf(e.s);
	return [...e].sort((e, n) => t(e) - t(n) || e.v - n.v);
}
function me(e) {
	let t = e[0].card.s, n = e.filter((e) => e.card.s === "sub");
	return n.length > 0 ? n.reduce((e, t) => t.card.v > e.card.v ? t : e).rid : e.filter((e) => e.card.s === t).reduce((e, t) => t.card.v > e.card.v ? t : e).rid;
}
function he(e, t) {
	return {
		me: t,
		players: e.players,
		captain: e.captain,
		totalTricks: e.totalTricks,
		finished: e.tricks.length >= e.totalTricks,
		tricks: e.tricks,
		played: [...e.tricks.flatMap((e) => e.plays.map((e) => e.card)), ...e.trick.plays.map((e) => e.card)],
		openLead: e.trick.plays.length > 0 ? e.trick.plays[0] : null
	};
}
function ge(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.tasks) t.set(n.id, N(k(n.id), n.prediction, he(e, n.owner)));
	return t;
}
var G = (e) => ({ code: e }), _e = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: U,
	schemas: {
		action: w,
		publicView: ne,
		privateView: D,
		config: T
	},
	setup(e, t, n) {
		let r = {
			phase: "pick",
			seed: n,
			rngCursor: 0,
			players: [...t],
			difficulty: e.difficulty,
			attempts: 1,
			captain: t[0],
			totalTricks: 0,
			hands: {},
			tricks: [],
			trick: {
				leader: t[0],
				plays: []
			},
			turn: t[0],
			tasks: [],
			pool: [],
			pickerIdx: 0,
			passStreak: 0,
			commUsed: {},
			comm: {},
			lastTrick: null,
			failedTask: null,
			lastTaskIds: []
		};
		return fe(r, null), {
			state: r,
			fx: W(r)
		};
	},
	reduce(e, t, { by: n }) {
		let r = structuredClone(e);
		switch (t.type) {
			case "pick": {
				if (r.phase !== "pick") return G("games.deepsea.errPhase");
				if (r.players[r.pickerIdx] !== n) return G("games.deepsea.errTurn");
				let e = k(t.taskId);
				if (!r.pool.includes(t.taskId)) return G("games.deepsea.errTask");
				if (e.kind.k === "cmpCaptain" && n === r.captain && r.pool.some((e) => k(e).kind.k !== "cmpCaptain")) return G("games.deepsea.errTaskCaptain");
				let i = e.kind.k === "predictTricks";
				if (i && t.prediction === void 0 || !i && t.prediction !== void 0 || t.prediction !== void 0 && t.prediction > r.totalTricks) return G("games.deepsea.errPrediction");
				r.pool.splice(r.pool.indexOf(t.taskId), 1), r.tasks.push({
					id: t.taskId,
					owner: n,
					prediction: t.prediction ?? null
				}), r.passStreak = 0, r.pickerIdx = (r.pickerIdx + 1) % r.players.length;
				let a = [{
					kind: "taskPick",
					rid: n,
					data: { taskId: t.taskId }
				}];
				return r.pool.length === 0 && (r.phase = "play", r.turn = r.captain, r.trick = {
					leader: r.captain,
					plays: []
				}), {
					state: r,
					fx: a
				};
			}
			case "pass": return r.phase === "pick" ? r.players[r.pickerIdx] === n ? r.pool.length < r.players.length && r.passStreak < r.players.length ? (r.passStreak += 1, r.pickerIdx = (r.pickerIdx + 1) % r.players.length, { state: r }) : G("games.deepsea.errPass") : G("games.deepsea.errTurn") : G("games.deepsea.errPhase");
			case "play": {
				if (r.phase !== "play") return G("games.deepsea.errPhase");
				if (r.turn !== n) return G("games.deepsea.errTurn");
				let i = r.hands[n], a = i.findIndex((e) => e.s === t.card.s && e.v === t.card.v);
				if (a < 0) return G("games.deepsea.errCard");
				if (r.trick.plays.length > 0) {
					let e = r.trick.plays[0].card.s;
					if (t.card.s !== e && i.some((t) => t.s === e)) return G("games.deepsea.errFollow");
				}
				i.splice(a, 1), r.trick.plays.push({
					rid: n,
					card: t.card
				});
				let o = r.comm[n];
				o && o.card.s === t.card.s && o.card.v === t.card.v && (r.comm[n] = null);
				let s = [{
					kind: "play",
					rid: n,
					data: {
						card: t.card,
						index: r.trick.plays.length - 1
					}
				}];
				if (r.trick.plays.length < r.players.length) r.turn = r.players[(r.players.indexOf(n) + 1) % r.players.length];
				else {
					let e = me(r.trick.plays), t = {
						plays: [...r.trick.plays],
						winner: e
					};
					r.tricks.push(t), r.lastTrick = t, s.push({
						kind: "gather",
						rid: e,
						data: { count: r.players.length }
					}), r.trick = {
						leader: e,
						plays: []
					}, r.turn = e;
				}
				let c = new Set(e.tasks.filter((t) => ve(e, t) === "done").map((e) => e.id)), l = ge(r), u = r.tasks.find((e) => l.get(e.id) === "failed");
				if (u) r.phase = "lost", r.failedTask = {
					id: u.id,
					owner: u.owner
				};
				else if (r.tasks.length > 0 && r.tasks.every((e) => l.get(e.id) === "done")) r.phase = "won";
				else for (let e of r.tasks) l.get(e.id) === "done" && !c.has(e.id) && s.push({
					kind: "taskDone",
					rid: e.owner,
					data: { taskId: e.id }
				});
				return {
					state: r,
					fx: s
				};
			}
			case "comm": {
				if (r.phase !== "play") return G("games.deepsea.errPhase");
				if (r.trick.plays.length > 0) return G("games.deepsea.errCommMidTrick");
				if (r.commUsed[n]) return G("games.deepsea.errCommUsed");
				if (t.card.s === "sub") return G("games.deepsea.errCommSub");
				let e = r.hands[n];
				if (!e.some((e) => e.s === t.card.s && e.v === t.card.v)) return G("games.deepsea.errCard");
				let i = e.filter((e) => e.s === t.card.s);
				return (t.pos === "middle" ? i.length === 1 : t.pos === "top" ? i.every((e) => e.v <= t.card.v) : i.every((e) => e.v >= t.card.v)) ? (r.commUsed[n] = !0, r.comm[n] = {
					card: t.card,
					pos: t.pos
				}, {
					state: r,
					fx: [{
						kind: "comm",
						rid: n,
						data: {
							card: t.card,
							pos: t.pos
						}
					}]
				}) : G("games.deepsea.errCommPos");
			}
			case "retry": return r.phase === "lost" ? (r.attempts += 1, fe(r, t.redraw ? null : r.lastTaskIds), {
				state: r,
				fx: W(r)
			}) : G("games.deepsea.errPhase");
			case "next": return r.phase === "won" ? (r.difficulty = Math.min(10, r.difficulty + 1), r.attempts = 1, fe(r, null), {
				state: r,
				fx: W(r)
			}) : G("games.deepsea.errPhase");
		}
	},
	viewFor(e, t) {
		let n = ge(e), r = e.hands[t] ?? [], i = e.phase === "play" && e.turn === t && e.trick.plays.length > 0 ? e.trick.plays[0].card.s : null, a = i !== null && r.some((e) => e.s === i) ? i : null;
		return {
			public: {
				phase: e.phase,
				difficulty: e.difficulty,
				attempts: e.attempts,
				captain: e.captain,
				totalTricks: e.totalTricks,
				pool: e.phase === "pick" ? [...e.pool] : [],
				picker: e.phase === "pick" ? e.players[e.pickerIdx] : null,
				canPass: e.phase === "pick" && e.pool.length < e.players.length && e.passStreak < e.players.length,
				players: e.players.map((t) => ({
					rid: t,
					handCount: e.hands[t]?.length ?? 0,
					tricksWon: e.tricks.filter((e) => e.winner === t).length,
					captured: e.tricks.filter((e) => e.winner === t).flatMap((e) => e.plays.map((e) => e.card)),
					commUsed: e.commUsed[t] ?? !1,
					comm: e.comm[t] ?? null
				})),
				trick: {
					leader: e.trick.leader,
					plays: e.trick.plays.map((e) => ({
						rid: e.rid,
						card: e.card
					}))
				},
				lastTrick: e.lastTrick ? {
					plays: e.lastTrick.plays.map((e) => ({
						rid: e.rid,
						card: e.card
					})),
					winner: e.lastTrick.winner
				} : null,
				tasks: e.tasks.map((r) => {
					let i = k(r.id), a = i.kind.k === "predictTricks" && i.kind.hidden;
					return {
						id: r.id,
						owner: r.owner,
						status: e.phase === "pick" ? "pending" : n.get(r.id) ?? "pending",
						prediction: a && r.owner !== t ? null : r.prediction
					};
				}),
				failedTask: e.failedTask
			},
			private: {
				hand: pe(r),
				mustFollow: a,
				canComm: e.phase === "play" && e.trick.plays.length === 0 && !(e.commUsed[t] ?? !0)
			}
		};
	},
	status(e) {
		return { phase: e.phase };
	}
};
function ve(e, t) {
	return N(k(t.id), t.prediction, he(e, t.owner));
}
var ye = {
	pink: {
		chip: "bg-pink-500 text-white",
		num: "text-pink-600",
		glyph: "●"
	},
	blue: {
		chip: "bg-blue-500 text-white",
		num: "text-blue-600",
		glyph: "◆"
	},
	green: {
		chip: "bg-green-500 text-white",
		num: "text-green-600",
		glyph: "■"
	},
	yellow: {
		chip: "bg-amber-400 text-ink",
		num: "text-amber-500",
		glyph: "▲"
	}
};
function be(e) {
	return `games.deepsea.suit.${e}`;
}
var K = (e) => `${e.s}-${e.v}`, xe = {
	pink: "●",
	blue: "◆",
	green: "■",
	yellow: "▲",
	sub: "S"
};
function q({ card: e, size: t, dimmed: n, dimensions: r }) {
	let i = o()(be(e.s), { n: e.v });
	return /* @__PURE__ */ g("span", {
		className: "ds-card",
		"data-size": t,
		"data-suit": e.s,
		"data-dimmed": n || void 0,
		"aria-label": i,
		style: r ? {
			"--ds-face-w": `${r.w}px`,
			"--ds-face-h": `${r.h}px`
		} : void 0,
		children: [
			/* @__PURE__ */ h("img", {
				className: "ds-card__art",
				src: `./games/deepsea/art-${e.s}.webp`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ g("span", {
				className: "ds-card__corner",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ h("span", {
					className: "ds-card__number",
					children: e.v
				}), /* @__PURE__ */ h("span", {
					className: "ds-card__glyph",
					children: xe[e.s]
				})]
			}),
			/* @__PURE__ */ h("span", {
				className: "ds-card__stripe",
				"aria-hidden": !0
			})
		]
	});
}
function Se({ accent: e, dimensions: t }) {
	return /* @__PURE__ */ g("span", {
		className: "ds-card-back",
		style: {
			backgroundColor: e,
			width: t?.w,
			height: t?.h
		},
		"aria-hidden": !0,
		children: [/* @__PURE__ */ h("span", {
			className: "ds-card-back__ring",
			style: t ? {
				width: t.w * 31 / 44,
				height: t.h * 42 / 64
			} : void 0
		}), /* @__PURE__ */ h("span", {
			className: "ds-card-back__mark",
			style: t ? { fontSize: t.w * 23 / 44 } : void 0,
			children: "◈"
		})]
	});
}
//#endregion
//#region src/games/deepsea/captured-list.tsx
var Ce = {
	pink: 0,
	blue: 1,
	green: 2,
	yellow: 3,
	sub: 4
}, we = 28, Te = 13;
function Ee({ pub: e, members: t, myRid: n, turn: r }) {
	let i = o(), s = a((e) => e.locale), c = (e) => t.find((t) => t.rid === e), u = (e) => {
		let t = c(e);
		return t ? l[t.colorIndex % l.length].hex : void 0;
	}, d = (e) => {
		let t = c(e);
		return t ? m(t, s) : e;
	}, f = e.players.reduce((e, t) => e + t.captured.length, 0);
	return /* @__PURE__ */ g("section", {
		className: "ds-captures",
		"aria-label": i("games.deepsea.capturedHeading"),
		children: [/* @__PURE__ */ g("div", {
			className: "ds-section-heading",
			children: [/* @__PURE__ */ h("span", { children: i("games.deepsea.capturedHeading") }), /* @__PURE__ */ h("span", {
				className: "ds-section-heading__count",
				children: i("games.deepsea.capturedTotal", { n: f })
			})]
		}), /* @__PURE__ */ h("div", {
			className: "ds-captures__scroller",
			children: e.players.map((t) => {
				let a = c(t.rid), o = [...t.captured].sort((e, t) => Ce[e.s] - Ce[t.s] || e.v - t.v);
				return /* @__PURE__ */ g("div", {
					className: "ds-capture-row",
					children: [
						/* @__PURE__ */ g("div", {
							className: "ds-capture-row__seat",
							children: [a && /* @__PURE__ */ h(p, {
								m: a,
								myRid: n,
								action: e.phase === "pick" && t.rid === e.picker || e.phase === "play" && t.rid === r ? "pending" : null,
								anchorName: "seat:" + t.rid,
								box: "size-8 ds-capture-avatar",
								img: "size-6 ds-capture-image"
							}), /* @__PURE__ */ g("span", {
								className: "ds-capture-row__identity",
								children: [/* @__PURE__ */ g("span", {
									className: "ds-capture-row__name",
									style: { color: u(t.rid) },
									children: [
										d(t.rid),
										" ",
										t.rid === e.captain && /* @__PURE__ */ h("span", {
											"aria-label": i("games.deepsea.captainAria"),
											children: "🤿"
										})
									]
								}), /* @__PURE__ */ h("span", {
									className: "ds-capture-row__tricks",
									"aria-label": i("games.deepsea.tricksAria", { n: t.tricksWon }),
									children: i("games.deepsea.tricksShort", { n: t.tricksWon })
								})]
							})]
						}),
						t.comm && /* @__PURE__ */ g("span", {
							className: "ds-capture-row__comm",
							"aria-label": i("games.deepsea.commButton"),
							children: [
								/* @__PURE__ */ h("span", {
									"aria-hidden": !0,
									children: "📡"
								}),
								/* @__PURE__ */ h(q, {
									card: t.comm.card,
									size: "mini"
								}),
								/* @__PURE__ */ h("span", { children: i(t.comm.pos === "top" ? "games.deepsea.commTop" : t.comm.pos === "middle" ? "games.deepsea.commMiddle" : "games.deepsea.commBottom") })
							]
						}),
						/* @__PURE__ */ h("div", {
							className: "ds-capture-row__pile-scroll",
							children: o.length ? /* @__PURE__ */ h("div", {
								className: "ds-capture-pile",
								style: { width: `calc(var(--ds-capture-w, ${we}px) + ${o.length - 1} * var(--ds-capture-step, ${Te}px))` },
								children: o.map((e, t) => /* @__PURE__ */ h("span", {
									className: "ds-capture-pile__card",
									style: {
										left: `calc(${t} * var(--ds-capture-step, ${Te}px))`,
										zIndex: t + 1
									},
									children: /* @__PURE__ */ h(q, {
										card: e,
										size: "capture"
									})
								}, K(e)))
							}) : /* @__PURE__ */ h("span", {
								className: "ds-capture-row__empty",
								children: i("games.deepsea.noCaptured")
							})
						}),
						/* @__PURE__ */ h("span", {
							className: "ds-capture-row__count",
							children: i("games.deepsea.capturedCount", { n: o.length })
						})
					]
				}, t.rid);
			})
		})]
	});
}
//#endregion
//#region src/games/deepsea/task-text.tsx
function De({ slot: e, playerCount: t }) {
	switch (e.kind) {
		case "card": return /* @__PURE__ */ h(q, {
			card: e.card,
			size: "mini"
		});
		case "value": return /* @__PURE__ */ h("span", {
			className: "ds-task-slot-value inline-flex h-6 min-w-6 items-center justify-center gap-0.5 rounded-md border-2 border-ink bg-surface px-0.5 font-display text-xs font-extrabold tabular-nums",
			children: e.v
		});
		case "suit": {
			let t = ye[e.s];
			return /* @__PURE__ */ h("span", {
				"aria-hidden": !0,
				className: `ds-task-slot-suit inline-flex size-5 items-center justify-center rounded-full border border-ink text-[10px] leading-none ${t.chip}`,
				children: t.glyph
			});
		}
		case "sub": return /* @__PURE__ */ g("span", {
			className: "ds-task-slot-sub inline-flex h-6 min-w-6 items-center justify-center rounded-md border-2 border-ink bg-slate-700 px-0.5 text-xs font-extrabold text-white tabular-nums",
			children: ["🤿", e.v ?? ""]
		});
		case "num": {
			let n = e.n[Math.min(Math.max(t, 3), 5) - 3];
			return /* @__PURE__ */ h("span", {
				className: "font-mono font-extrabold tabular-nums",
				children: n
			});
		}
	}
}
function Oe({ taskId: e, playerCount: t, className: r }) {
	let i = o(), a = k(e), s = i(a.text).split(/\{\{(\d+)\}\}/);
	return /* @__PURE__ */ h("span", {
		className: r,
		children: s.map((e, r) => r % 2 == 0 ? /* @__PURE__ */ h(n, { children: e }, r) : /* @__PURE__ */ h("span", {
			className: "mx-0.5 inline-flex align-middle",
			children: /* @__PURE__ */ h(De, {
				slot: a.slots[Number(e)],
				playerCount: t
			})
		}, r))
	});
}
//#endregion
//#region src/games/deepsea/result-screen.tsx
function ke({ pub: e, members: t, myRid: n, send: r }) {
	let u = o(), { ref: f } = i("trick"), { ref: p } = i("result-trick"), { ref: _ } = i("result-trick-card-metric"), { ref: v } = i("result-trick-step-metric"), { ref: y } = i("result-trick-columns-metric"), b = a((e) => e.locale), x = e.phase === "won", S = e.tasks.filter((e) => e.status === "done").length, C = e.players.reduce((e, t) => e + t.tricksWon, 0), w = e.players.length, T = (e) => t.find((t) => t.rid === e), E = (e) => {
		let t = T(e);
		return t ? m(t, b) : e;
	}, ee = (e) => {
		let t = T(e);
		return t ? l[t.colorIndex % l.length].hex : void 0;
	};
	return /* @__PURE__ */ g(d, {
		adaptive: !0,
		className: "ds-result-screen",
		scroll: !1,
		children: [/* @__PURE__ */ g("div", {
			className: "ds-result",
			"data-outcome": x ? "won" : "lost",
			"data-tasks": e.tasks.length,
			style: { "--ds-player-count": w },
			children: [
				/* @__PURE__ */ g("div", {
					className: "ds-result__hero",
					children: [/* @__PURE__ */ g("div", {
						ref: f,
						className: "ds-result__sonar",
						"aria-hidden": !0,
						children: [
							/* @__PURE__ */ h("span", { className: "ds-result__sonar-ring" }),
							/* @__PURE__ */ h("span", {
								className: "ds-result__submarine",
								children: /* @__PURE__ */ h(q, {
									card: {
										s: "sub",
										v: 4
									},
									size: "table"
								})
							}),
							/* @__PURE__ */ h("span", { className: "ds-result__bubble ds-result__bubble--one" }),
							/* @__PURE__ */ h("span", { className: "ds-result__bubble ds-result__bubble--two" }),
							/* @__PURE__ */ h("span", { className: "ds-result__bubble ds-result__bubble--three" })
						]
					}), /* @__PURE__ */ g("div", {
						className: "ds-result__hero-copy",
						children: [
							/* @__PURE__ */ g("span", {
								className: "ds-result__kicker",
								children: [
									u("games.deepsea.diffChip", { n: e.difficulty }),
									" · ",
									u("games.deepsea.attemptSub", { n: e.attempts })
								]
							}),
							/* @__PURE__ */ h("h1", { children: u(x ? "games.deepsea.resultWonTitle" : "games.deepsea.resultLostTitle") }),
							/* @__PURE__ */ h("p", { children: u(x ? "games.deepsea.resultWonSub" : "games.deepsea.resultLostSub") })
						]
					})]
				}),
				/* @__PURE__ */ g("div", {
					className: "ds-result__metrics",
					"aria-label": u("games.deepsea.resultSummary"),
					children: [/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ g("strong", { children: [
						S,
						"/",
						e.tasks.length
					] }), u("games.deepsea.resultTasks")] }), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ g("strong", { children: [
						C,
						"/",
						e.totalTricks
					] }), u("games.deepsea.resultTricks")] })]
				}),
				e.phase === "lost" && e.failedTask && /* @__PURE__ */ g("div", {
					className: "ds-result__cause",
					children: [/* @__PURE__ */ h(c, {
						size: 18,
						strokeWidth: 3,
						"aria-hidden": !0
					}), /* @__PURE__ */ g("span", { children: [
						/* @__PURE__ */ h("b", { children: u("games.deepsea.failedBy", { name: E(e.failedTask.owner) }) }),
						" ",
						/* @__PURE__ */ h(Oe, {
							taskId: e.failedTask.id,
							playerCount: w
						})
					] })]
				}),
				/* @__PURE__ */ g("div", {
					className: "ds-result__details",
					children: [/* @__PURE__ */ g("section", {
						className: "ds-result__tasks",
						"aria-label": u("games.deepsea.tasksHeading"),
						children: [/* @__PURE__ */ g("div", {
							className: "ds-section-heading",
							children: [/* @__PURE__ */ h("span", { children: u("games.deepsea.tasksHeading") }), /* @__PURE__ */ g("span", {
								className: "ds-section-heading__count",
								children: [
									S,
									"/",
									e.tasks.length
								]
							})]
						}), /* @__PURE__ */ h("div", {
							className: "ds-result__task-scroll",
							children: e.tasks.map((e) => /* @__PURE__ */ g("div", {
								className: "ds-result__task",
								"data-status": e.status,
								children: [
									/* @__PURE__ */ h("span", {
										className: "ds-result__task-number",
										children: u("games.deepsea.taskNumber", { n: e.id })
									}),
									/* @__PURE__ */ h("span", {
										className: "ds-result__task-text",
										children: /* @__PURE__ */ h(Oe, {
											taskId: e.id,
											playerCount: w
										})
									}),
									/* @__PURE__ */ h("span", {
										className: "ds-result__task-owner",
										style: { color: ee(e.owner) },
										children: E(e.owner)
									}),
									/* @__PURE__ */ h("span", {
										className: "ds-result__task-state",
										"aria-label": u(e.status === "done" ? "games.deepsea.taskDone" : e.status === "failed" ? "games.deepsea.taskFailed" : "games.deepsea.taskPending"),
										children: e.status === "done" ? /* @__PURE__ */ h(s, {
											size: 15,
											strokeWidth: 3
										}) : e.status === "failed" ? /* @__PURE__ */ h(c, {
											size: 15,
											strokeWidth: 3
										}) : "·"
									})
								]
							}, e.id))
						})]
					}), /* @__PURE__ */ h(Ee, {
						pub: e,
						members: t,
						myRid: n,
						turn: null
					})]
				}),
				/* @__PURE__ */ g("div", {
					className: "ds-result__actions",
					children: [x ? /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base ds-result__primary",
						style: { background: U.accent },
						onClick: () => r({ type: "next" }),
						children: e.difficulty < 10 ? u("games.deepsea.nextDiff", { n: e.difficulty + 1 }) : u("games.deepsea.resultAgain")
					}) : /* @__PURE__ */ g("div", {
						className: "ds-result__retry",
						children: [/* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-base ds-result__primary",
							style: { background: U.accent },
							onClick: () => r({
								type: "retry",
								redraw: !1
							}),
							children: u("games.deepsea.retrySame")
						}), /* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-quiet ds-result__secondary",
							onClick: () => r({
								type: "retry",
								redraw: !0
							}),
							children: u("games.deepsea.retryRedraw")
						})]
					}), /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet ds-result__exit",
						onClick: () => history.back(),
						children: u("games.deepsea.resultExit")
					})]
				})
			]
		}), /* @__PURE__ */ h("div", {
			className: "ds-result__trick-proxy",
			"aria-hidden": !0,
			children: /* @__PURE__ */ h(d, {
				adaptive: !0,
				className: "ds-screen",
				scroll: !1,
				banner: /* @__PURE__ */ h("div", { className: "ds-result__last-banner" }),
				actionsHeight: "ds-actions-height",
				children: /* @__PURE__ */ h("div", {
					className: "ds-board frame",
					"data-players": w,
					style: { "--ds-player-count": w },
					children: /* @__PURE__ */ h("div", {
						className: "ds-board__content",
						children: /* @__PURE__ */ g("section", {
							ref: p,
							className: "ds-trick",
							children: [
								/* @__PURE__ */ h("span", {
									ref: _,
									className: "ds-trick__metric"
								}),
								/* @__PURE__ */ h("span", {
									ref: v,
									className: "ds-trick__step-metric"
								}),
								/* @__PURE__ */ h("span", {
									ref: y,
									className: "ds-trick__columns-metric"
								})
							]
						})
					})
				})
			})
		})]
	});
}
//#endregion
//#region src/games/deepsea/view-player.tsx
function Ae(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ h(Me, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var je = [
	"top",
	"middle",
	"bottom"
];
function Me({ pub: e, priv: t, members: n, myRid: p, send: _ }) {
	let v = o(), y = a((e) => e.locale), b = (e) => n.find((t) => t.rid === e), x = (e) => {
		let t = b(e);
		return t ? m(t, y) : e;
	}, S = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? l[t.colorIndex % l.length].hex : void 0;
	}, { ref: C } = i("table"), { ref: w } = i("trick"), { ref: T } = i("trick-card-metric"), { ref: E } = i("trick-step-metric"), { ref: ee } = i("trick-columns-metric"), te = e.players.map((e) => e.rid), ne = e.phase === "play" ? e.trick.plays.length === 0 ? e.trick.leader : te[(te.indexOf(e.trick.plays[e.trick.plays.length - 1].rid) + 1) % te.length] : null, D = ne === p, O = e.phase === "pick" && e.picker === p, re = e.players.reduce((e, t) => e + t.tricksWon, 0), A = e.players.length, j = t?.hand ?? [], [M, N] = r(null), [P, F] = r(null), [I, ie] = r(0), [L, R] = r(null), [z, B] = r(null), [V, H] = r(!1), ae = `${e.phase}|${e.difficulty}|${e.attempts}|${ne}|${j.length}|${e.trick.plays.length}`, [oe, se] = r(ae);
	oe !== ae && (se(ae), N(null), F(null), ie(0), R(null), B(null), H(!1));
	let ce = (e) => V ? e.s !== "sub" : !(!D || t?.mustFollow && e.s !== t.mustFollow), le = (e) => {
		if (V) {
			if (e.s === "sub") return;
			R(e);
			return;
		}
		D && (t?.mustFollow && e.s !== t.mustFollow || N(M && K(M) === K(e) ? null : e));
	};
	if (e.phase === "won" || e.phase === "lost") return /* @__PURE__ */ h(ke, {
		pub: e,
		members: n,
		myRid: p,
		send: _
	});
	let ue, de;
	e.phase === "pick" ? (ue = O ? "accent" : "info", de = O ? v("games.deepsea.pickPrompt") : v("games.deepsea.pickWaiting", { name: x(e.picker ?? "") })) : (ue = D ? "accent" : "info", de = D ? v("games.deepsea.turnYou") : v("games.deepsea.turnWait", { name: x(ne ?? "") }));
	let W = e.trick.plays;
	return /* @__PURE__ */ h(d, {
		adaptive: !0,
		className: "ds-screen",
		banner: /* @__PURE__ */ h(f, {
			tone: ue,
			text: de,
			chip: v("games.deepsea.diffChip", { n: e.difficulty }),
			sub: e.attempts > 1 ? v("games.deepsea.attemptSub", { n: e.attempts }) : void 0,
			accent: U.accent
		}),
		actionsHeight: "ds-actions-height",
		actions: /* @__PURE__ */ g("div", {
			className: "ds-hand",
			style: { "--ds-hand-count": Math.max(1, j.length) },
			children: [/* @__PURE__ */ g("div", {
				className: "ds-hand__heading",
				children: [/* @__PURE__ */ h("span", { children: v("games.deepsea.handCount", { n: j.length }) }), /* @__PURE__ */ h("span", { children: v("games.deepsea.handScroll") })]
			}), /* @__PURE__ */ h("div", {
				className: "ds-hand__scroller",
				children: /* @__PURE__ */ h("div", {
					className: "ds-hand__cards",
					children: j.map((e, n) => /* @__PURE__ */ h("button", {
						type: "button",
						disabled: !ce(e),
						onClick: () => le(e),
						className: "ds-hand__button " + (n > 0 ? "ds-hand__button--overlap" : ""),
						children: /* @__PURE__ */ h(Pe, {
							card: e,
							raised: M !== null && K(M) === K(e),
							dimmed: D && t?.mustFollow !== null && e.s !== t?.mustFollow || V && e.s === "sub"
						})
					}, K(e)))
				})
			})]
		}),
		overlay: /* @__PURE__ */ g("div", {
			className: "ds-overlay",
			children: [
				O && P === null && e.canPass && /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-quiet ds-overlay__small",
					onClick: () => _({ type: "pass" }),
					children: v("games.deepsea.pass")
				}),
				O && P !== null && /* @__PURE__ */ g("div", {
					className: "ds-overlay__panel",
					children: [k(P).kind.k === "predictTricks" ? /* @__PURE__ */ g("div", {
						className: "ds-predict",
						children: [
							/* @__PURE__ */ h("span", { children: v("games.deepsea.predictLabel") }),
							/* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": v("games.deepsea.predictMinus"),
								className: "btn-quiet min-h-11 min-w-11 text-lg",
								onClick: () => ie(Math.max(0, I - 1)),
								children: "−"
							}),
							/* @__PURE__ */ h("span", {
								className: "ds-predict__number",
								children: I
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": v("games.deepsea.predictPlus"),
								className: "btn-quiet min-h-11 min-w-11 text-lg",
								onClick: () => ie(Math.min(e.totalTricks, I + 1)),
								children: "+"
							})
						]
					}) : /* @__PURE__ */ h("div", {
						className: "ds-overlay__task",
						children: /* @__PURE__ */ h(Oe, {
							taskId: P,
							playerCount: A
						})
					}), /* @__PURE__ */ g("div", {
						className: "ds-overlay__buttons",
						children: [/* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-quiet min-h-11 px-3 text-sm",
							onClick: () => F(null),
							children: v("games.deepsea.cancel")
						}), /* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-base min-h-11 px-4 text-sm text-white",
							style: { background: U.accent },
							onClick: () => {
								let e = k(P).kind.k === "predictTricks";
								_({
									type: "pick",
									taskId: P,
									...e ? { prediction: I } : {}
								}), F(null);
							},
							children: v("games.deepsea.claim")
						})]
					})]
				}),
				e.phase === "play" && t?.canComm && !V && !M && /* @__PURE__ */ g("button", {
					type: "button",
					className: "btn-quiet ds-overlay__small",
					onClick: () => {
						N(null), H(!0);
					},
					children: ["📡 ", v("games.deepsea.commButton")]
				}),
				V && /* @__PURE__ */ g("div", {
					className: "ds-overlay__panel",
					children: [/* @__PURE__ */ g("div", {
						className: "ds-comm",
						children: [L ? /* @__PURE__ */ h(q, {
							card: L,
							size: "mini"
						}) : /* @__PURE__ */ h("span", { children: v("games.deepsea.commPickCard") }), L && je.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-quiet min-h-11 px-2 text-xs font-bold " + (z === e ? "ds-comm__selected" : ""),
							onClick: () => B(e),
							children: v(e === "top" ? "games.deepsea.commTop" : e === "middle" ? "games.deepsea.commMiddle" : "games.deepsea.commBottom")
						}, e))]
					}), /* @__PURE__ */ g("div", {
						className: "ds-overlay__buttons",
						children: [/* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-quiet min-h-11 px-3 text-sm",
							onClick: () => {
								H(!1), R(null), B(null);
							},
							children: v("games.deepsea.cancel")
						}), /* @__PURE__ */ h("button", {
							type: "button",
							disabled: !L || !z,
							className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
							style: { background: U.accent },
							onClick: () => {
								L && z && (_({
									type: "comm",
									card: L,
									pos: z
								}), H(!1), R(null), B(null));
							},
							children: v("games.deepsea.commSend")
						})]
					})]
				}),
				M && !V && /* @__PURE__ */ g("div", {
					className: "ds-overlay__panel ds-play-confirm",
					children: [/* @__PURE__ */ h(q, {
						card: M,
						size: "table"
					}), /* @__PURE__ */ g("div", {
						className: "ds-overlay__buttons",
						children: [/* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-quiet min-h-11 px-3 text-sm",
							onClick: () => N(null),
							children: v("games.deepsea.cancel")
						}), /* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-base min-h-11 px-4 text-sm text-white",
							style: { background: U.accent },
							onClick: () => {
								_({
									type: "play",
									card: M
								}), N(null);
							},
							children: v("games.deepsea.playCard")
						})]
					})]
				})
			]
		}),
		scroll: !1,
		children: /* @__PURE__ */ g("div", {
			ref: C,
			className: "ds-board frame",
			"data-players": A,
			style: { "--ds-player-count": A },
			children: [/* @__PURE__ */ h(u, {
				kind: "sheen",
				base: "#0b4054",
				className: "absolute inset-0"
			}), /* @__PURE__ */ g("div", {
				className: "ds-board__content",
				children: [
					/* @__PURE__ */ g("section", {
						className: "ds-tasks",
						"aria-label": v("games.deepsea.tasksHeading"),
						children: [/* @__PURE__ */ g("div", {
							className: "ds-section-heading",
							children: [/* @__PURE__ */ h("span", { children: v("games.deepsea.tasksHeading") }), /* @__PURE__ */ h("span", {
								className: "ds-section-heading__count",
								children: e.phase === "pick" ? e.pool.length : e.tasks.length
							})]
						}), /* @__PURE__ */ h("div", {
							className: "ds-tasks__scroller",
							children: e.phase === "pick" ? /* @__PURE__ */ h("div", {
								className: "ds-task-list",
								children: e.pool.map((t) => {
									let n = k(t), r = n.kind.k === "cmpCaptain" && p === e.captain, i = O && !r, a = P === t;
									return /* @__PURE__ */ g("button", {
										type: "button",
										disabled: !i,
										onClick: () => F(a ? null : t),
										className: "ds-task-card ds-task-card--pick " + (a ? "ds-task-card--selected" : ""),
										children: [
											/* @__PURE__ */ g("span", {
												className: "ds-task-card__header",
												children: [/* @__PURE__ */ h("span", { children: v("games.deepsea.taskNumber", { n: t }) }), /* @__PURE__ */ h("span", {
													className: "ds-task-card__points",
													children: n.diff[A - 3]
												})]
											}),
											/* @__PURE__ */ g("span", {
												className: "ds-task-card__body",
												children: [/* @__PURE__ */ h("span", {
													className: "ds-task-card__flag",
													"aria-hidden": !0
												}), /* @__PURE__ */ h(Oe, {
													taskId: t,
													playerCount: A,
													className: "ds-task-card__copy"
												})]
											}),
											/* @__PURE__ */ g("span", {
												className: "ds-task-card__footer",
												children: [/* @__PURE__ */ h("span", {
													className: "ds-task-card__owner",
													children: v(r && O ? "games.deepsea.captainBlocked" : "games.deepsea.unclaimed")
												}), a && /* @__PURE__ */ h("span", {
													className: "ds-task-card__state",
													children: v("games.deepsea.taskSelected")
												})]
											})
										]
									}, t);
								})
							}) : /* @__PURE__ */ h("div", {
								className: "ds-task-list",
								children: e.tasks.map((e) => {
									let t = k(e.id);
									return /* @__PURE__ */ g("div", {
										className: "ds-task-card ds-task-card--" + e.status,
										children: [
											/* @__PURE__ */ g("span", {
												className: "ds-task-card__header",
												children: [/* @__PURE__ */ h("span", { children: v("games.deepsea.taskNumber", { n: e.id }) }), /* @__PURE__ */ h("span", {
													className: "ds-task-card__points",
													children: t.diff[A - 3]
												})]
											}),
											/* @__PURE__ */ g("span", {
												className: "ds-task-card__body",
												children: [/* @__PURE__ */ h("span", {
													className: "ds-task-card__flag",
													"aria-hidden": !0
												}), /* @__PURE__ */ g("span", {
													className: "ds-task-card__copy",
													children: [/* @__PURE__ */ h(Oe, {
														taskId: e.id,
														playerCount: A
													}), e.prediction !== null && /* @__PURE__ */ h("span", {
														className: "ds-task-card__prediction",
														children: v("games.deepsea.prediction", { n: e.prediction })
													})]
												})]
											}),
											/* @__PURE__ */ g("span", {
												className: "ds-task-card__footer",
												children: [/* @__PURE__ */ h("span", {
													className: "ds-task-card__owner",
													style: {
														color: S(e.owner),
														borderColor: S(e.owner)
													},
													children: x(e.owner)
												}), /* @__PURE__ */ g("span", {
													className: "ds-task-card__state",
													children: [e.status === "done" ? /* @__PURE__ */ h(s, {
														size: 13,
														strokeWidth: 3,
														"aria-hidden": !0
													}) : e.status === "failed" ? /* @__PURE__ */ h(c, {
														size: 13,
														strokeWidth: 3,
														"aria-hidden": !0
													}) : null, v(e.status === "done" ? "games.deepsea.taskDone" : e.status === "failed" ? "games.deepsea.taskFailed" : "games.deepsea.taskPending")]
												})]
											})
										]
									}, e.id);
								})
							})
						})]
					}),
					/* @__PURE__ */ g("section", {
						ref: w,
						className: "ds-trick",
						"aria-label": v("games.deepsea.trickChip", {
							n: Math.min(re + 1, e.totalTricks),
							total: e.totalTricks
						}),
						children: [
							/* @__PURE__ */ h("span", {
								ref: T,
								className: "ds-trick__metric",
								"aria-hidden": !0
							}),
							/* @__PURE__ */ h("span", {
								ref: E,
								className: "ds-trick__step-metric",
								"aria-hidden": !0
							}),
							/* @__PURE__ */ h("span", {
								ref: ee,
								className: "ds-trick__columns-metric",
								"aria-hidden": !0
							}),
							/* @__PURE__ */ h("div", {
								className: "ds-trick__ring",
								"aria-hidden": !0
							}),
							/* @__PURE__ */ g("div", {
								className: "ds-trick__content",
								children: [
									/* @__PURE__ */ h("div", {
										className: "ds-trick__heading",
										children: v("games.deepsea.trickChip", {
											n: Math.min(re + 1, e.totalTricks),
											total: e.totalTricks
										})
									}),
									W.length > 0 ? /* @__PURE__ */ h("div", {
										className: "ds-trick__cards",
										children: W.map((e, t) => /* @__PURE__ */ g("span", {
											className: "ds-trick__play",
											children: [/* @__PURE__ */ h(Ne, {
												index: t,
												card: e.card
											}), /* @__PURE__ */ h("span", {
												style: { color: S(e.rid) },
												children: x(e.rid)
											})]
										}, e.rid))
									}) : /* @__PURE__ */ h("div", {
										className: "ds-trick__empty",
										children: /* @__PURE__ */ h("span", { children: e.phase === "play" ? v("games.deepsea.trickLead", { name: x(e.trick.leader) }) : v("games.deepsea.playSpot") })
									}),
									e.phase === "play" && e.lastTrick && W.length === 0 && /* @__PURE__ */ g("div", {
										className: "ds-trick__last",
										children: [/* @__PURE__ */ h("span", { children: v("games.deepsea.lastTrick", { name: x(e.lastTrick.winner) }) }), e.lastTrick.plays.map((e, t) => /* @__PURE__ */ h(q, {
											card: e.card,
											size: "mini"
										}, e.rid + t))]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ h(Ee, {
						pub: e,
						members: n,
						myRid: p,
						turn: ne
					})
				]
			})]
		})
	});
}
function Ne({ index: e, card: t }) {
	let { ref: n, hidden: r } = i(`tcard:${e}`);
	return /* @__PURE__ */ h("span", {
		ref: n,
		className: "inline-flex",
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ h(q, {
			card: t,
			size: "table"
		})
	});
}
function Pe({ card: e, raised: t, dimmed: n }) {
	let { ref: r, hidden: a } = i(`hand:${K(e)}`);
	return /* @__PURE__ */ h("span", {
		ref: r,
		className: `inline-flex ${t ? "-translate-y-2" : ""}`,
		style: { visibility: a ? "hidden" : void 0 },
		children: /* @__PURE__ */ h(q, {
			card: e,
			size: "hand",
			dimmed: n
		})
	});
}
//#endregion
//#region src/games/deepsea/ismcts.ts
var J = (e) => `${e.s}:${e.v}`, Fe = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
function Ie(e) {
	let t = [...e];
	for (let e = t.length - 1; e > 0; --e) {
		let n = Math.floor(Fe() * (e + 1));
		[t[e], t[n]] = [t[n], t[e]];
	}
	return t;
}
var Le = (e) => e.s === "sub";
function Re(e) {
	let t = e[0].card.s, n = e.filter((e) => e.card.s === "sub");
	return n.length > 0 ? n.reduce((e, t) => t.card.v > e.card.v ? t : e).rid : e.filter((e) => e.card.s === t).reduce((e, t) => t.card.v > e.card.v ? t : e).rid;
}
function ze(e, t) {
	if (t.length === 0) return !0;
	let n = t[0].card.s, r = Math.max(0, ...t.filter((e) => e.card.s === "sub").map((e) => e.card.v));
	return r > 0 ? e.s === "sub" && e.v > r : e.s === "sub" || e.s === n && t.filter((e) => e.card.s === n).every((t) => t.card.v < e.v);
}
function Be(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = n.plays[0]?.card.s;
		if (e) for (let r of n.plays) r.card.s !== e && (t.has(r.rid) || t.set(r.rid, /* @__PURE__ */ new Set()), t.get(r.rid).add(e));
	}
	return t;
}
function Ve(e, t, n, r) {
	let i = /* @__PURE__ */ new Set();
	for (let e of t) for (let t of e.plays) i.add(J(t.card));
	for (let t of e.trick.plays) i.add(J(t.card));
	for (let e of r) i.add(J(e));
	let a = [];
	for (let e of [
		"pink",
		"blue",
		"green",
		"yellow"
	]) for (let t = 1; t <= 9; t += 1) a.push({
		s: e,
		v: t
	});
	for (let e = 1; e <= 4; e += 1) a.push({
		s: "sub",
		v: e
	});
	let o = a.filter((e) => !i.has(J(e))), s = e.players.filter((e) => e.rid !== n), c = Be(t), l = /* @__PURE__ */ new Map();
	for (let e of s) e.comm && !i.has(J(e.comm.card)) && l.set(e.rid, e.comm.card);
	for (let e = 0; e < 60; e += 1) {
		let e = {};
		for (let t of s) e[t.rid] = l.has(t.rid) ? [l.get(t.rid)] : [];
		let t = new Set([...l.values()].map(J)), i = Ie(o.filter((e) => !t.has(J(e)))), a = 0;
		for (let t of s) {
			let n = t.handCount - e[t.rid].length;
			e[t.rid].push(...i.slice(a, a + n)), a += n;
		}
		let u = !0;
		for (let t of s) {
			let n = e[t.rid], r = c.get(t.rid);
			if (r && n.some((e) => r.has(e.s))) {
				u = !1;
				break;
			}
			if (t.comm && l.has(t.rid)) {
				let e = t.comm, r = n.filter((t) => t.s === e.card.s);
				if (e.pos === "middle" && r.length !== 1 && (u = !1), e.pos === "top" && r.some((t) => t.v > e.card.v) && (u = !1), e.pos === "bottom" && r.some((t) => t.v < e.card.v) && (u = !1), !u) break;
			}
		}
		if (u) return e[n] = [...r], e;
	}
	return null;
}
function He(e, t, n) {
	let r = !0;
	for (let i of e.tasks) {
		let a = {
			me: i.owner,
			players: e.players.map((e) => e.rid),
			captain: e.captain,
			totalTricks: e.totalTricks,
			finished: t.length >= e.totalTricks,
			tricks: t,
			played: [...t.flatMap((e) => e.plays.map((e) => e.card)), ...n.map((e) => e.card)],
			openLead: n.length > 0 ? n[0] : null
		}, o = N(k(i.id), i.prediction, a);
		if (o === "failed") return "lost";
		o !== "done" && (r = !1);
	}
	return r ? "won" : "ongoing";
}
function Ue(e, t, n) {
	let r = 0, i = t.filter((e) => e.winner === n).length, a = e.totalTricks - t.length;
	for (let o of e.tasks) {
		if (o.owner !== n) continue;
		let e = k(o.id).kind;
		if (e.k === "exactTricks" || e.k === "predictTricks") {
			let t = e.k === "exactTricks" ? e.n : o.prediction ?? -1;
			if (t < 0) continue;
			let n = t - i;
			n > 0 ? r += n >= a ? 3 : 1 : n === 0 && (r -= 2);
		} else e.k === "winNoTricks" || e.k === "dontWinFirstN" && t.length < e.n ? r -= 5 : (e.k === "winCards" || e.k === "winSub" || e.k === "winSubOnly") && (r += 1);
	}
	return r;
}
var We = (e, t) => {
	if (e.s === "sub") return 100 + e.v;
	let n = t[0]?.card.s;
	return n && e.s === n ? 10 + e.v : e.v / 10;
};
function Ge(e, t, n) {
	let r = e;
	for (let e of t) r += `|${e.rid}:${e.card.s}${e.card.v}`;
	r += "#";
	for (let e of Object.keys(n).sort()) r += `${e}[${n[e].map(J).sort().join(",")}]`;
	return r;
}
function Ke(e, t, n, r, i, a, o) {
	if (a.nodes += 1, a.nodes > a.limit || !(a.nodes & 63) && Date.now() > a.deadline) return null;
	let s = e.players.map((e) => e.rid);
	if (n.length === s.length) {
		let i = Re(n), s = [...t, {
			winner: i,
			plays: n
		}], c = He(e, s, []);
		return c === "lost" ? !1 : c === "won" ? !0 : s.length >= e.totalTricks ? !1 : Ke(e, s, [], r, i, a, o);
	}
	let c = Ge(i, n, r), l = o.get(c);
	if (l !== void 0) return l;
	let u = r[i], d = n.length > 0 ? n[0].card.s : null, f = [...d && u.some((e) => e.s === d) ? u.filter((e) => e.s === d) : u].sort((e, t) => We(e, n) - We(t, n)), p = !1;
	for (let l of f) {
		let d = [...n, {
			rid: i,
			card: l
		}];
		if (He(e, t, d) === "lost") continue;
		let f = {
			...r,
			[i]: u.filter((e) => e !== l)
		}, m = s[(s.indexOf(i) + 1) % s.length], h = Ke(e, t, d, f, m, a, o);
		if (h === !0) return o.set(c, !0), !0;
		h === null && (p = !0);
	}
	return p ? null : (o.set(c, !1), !1);
}
function Y(e, t, n, r, i, a) {
	let o = [...n, ...a], s = r !== null, c = s ? [...t, {
		winner: r,
		plays: o
	}] : t, l = [...c.flatMap((e) => e.plays.map((e) => e.card)), ...s ? [] : o.map((e) => e.card)], u = {
		me: i,
		players: e.players.map((e) => e.rid),
		captain: e.captain,
		totalTricks: e.totalTricks,
		finished: c.length >= e.totalTricks,
		tricks: c,
		played: l,
		openLead: s ? null : o[0] ?? null
	};
	for (let t of e.tasks) if (t.owner === i && t.status === "pending" && N(k(t.id), t.prediction, u) === "failed") return !0;
	return !1;
}
function qe(e, t, n, r, i) {
	let a = t[i];
	if (a.length === 0) return a[0];
	let o = r.length > 0 ? r[0].card.s : null, s = o && a.some((e) => e.s === o) ? a.filter((e) => e.s === o) : a, c = (e) => e.reduce((e, t) => We(e, r) < We(t, r) ? e : t);
	if (s.length <= 1) return s[0];
	if (r.length === 0) {
		let t = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
		for (let n of e.tasks) {
			if (n.owner !== i) continue;
			let e = k(n.id).kind;
			if (e.k === "dontOpen") for (let n of e.suits) t.add(n);
			if (e.k === "winCards") for (let t of e.cards) r.add(J(t));
			e.k === "winCardInLast" && r.add(J(e.card));
		}
		let a = s.filter((e) => !t.has(e.s) && !r.has(J(e)));
		a.length === 0 && (a = s.filter((e) => !t.has(e.s))), a.length === 0 && (a = s);
		let o = Be(n);
		for (let t of e.tasks) {
			if (t.owner === i || t.status !== "pending") continue;
			let n = k(t.id).kind, r = n.k === "winCards" ? n.cards : n.k === "winCardWithSub" ? [n.card] : [];
			for (let n of r) {
				if (n.s === "sub") continue;
				let r = a.find((e) => e.s === n.s && e.v === n.v);
				if (!r) continue;
				let i = e.players.find((e) => e.rid === t.owner)?.comm;
				if (i && i.card.s === n.s && (i.pos === "top" || i.pos === "middle") && i.card.v > n.v || o.get(t.owner)?.has(n.s) || n.v <= 3) return r;
				let s = a.filter((e) => e.s === n.s && e.v !== n.v);
				return s.length > 0 && s.length < a.length ? s.reduce((e, t) => t.v < e.v ? t : e) : r;
			}
		}
		let l = a.filter((e) => !Le(e));
		return c(l.length > 0 ? l : a);
	}
	let l = Ue(e, n, i), u = Re(r), d = s.filter((e) => ze(e, r)), f = s.filter((e) => !ze(e, r)), p = e.players.filter((e) => e.rid !== i).map((e) => e.rid), m = d.filter((t) => {
		let a = [{
			rid: i,
			card: t
		}];
		return Y(e, n, r, i, i, a) || Y(e, n, r, null, i, a) ? !1 : !p.some((t) => Y(e, n, r, i, t, a) && !Y(e, n, r, i, t, []));
	}), h = f.filter((t) => {
		let a = [{
			rid: i,
			card: t
		}];
		return !p.some((t) => Y(e, n, r, u, t, a) && !Y(e, n, r, u, t, []));
	}), g = m.length > 0 ? m : d, _ = h.length > 0 ? h : f;
	return l > 0 && g.length > 0 ? c(g) : l < 0 && _.length > 0 || _.length > 0 ? c(_) : c(g);
}
var Je = 1e5;
function Ye(e, t, n) {
	let r = [...t.flatMap((e) => e.plays.map((e) => e.card)), ...n.map((e) => e.card)], i = 0, a = 0;
	for (let o of e.tasks) {
		let s = {
			me: o.owner,
			players: e.players.map((e) => e.rid),
			captain: e.captain,
			totalTricks: e.totalTricks,
			finished: !1,
			tricks: t,
			played: r,
			openLead: n.length > 0 ? n[0] : null
		}, c = N(k(o.id), o.prediction, s);
		c === "done" ? i += 1 : c === "pending" && (a += 1);
	}
	return i * 1e3 + t.length * 5 - a;
}
function Xe(e, t, n, r, i) {
	let a = {};
	for (let t of e.players) a[t.rid] = n[t.rid].filter((e) => t.rid !== r || J(e) !== J(i));
	let o = t, s = [...e.trick.plays.map((e) => ({
		rid: e.rid,
		card: e.card
	})), {
		rid: r,
		card: i
	}], c = e.players.map((e) => e.rid), l = c[(c.indexOf(r) + 1) % c.length], u = He(e, o, s);
	if (u === "lost") return Ye(e, o, s);
	if (u === "won") return Je;
	for (let t = 0; t < 200; t += 1) {
		if (s.length === c.length) {
			let t = Re(s);
			if (o = [...o, {
				winner: t,
				plays: s
			}], s = [], l = t, u = He(e, o, s), u === "lost") return Ye(e, o, s);
			if (u === "won") return Je;
			if (o.length >= e.totalTricks) return Ye(e, o, s);
			continue;
		}
		let t = qe(e, a, o, s, l), n = a[l], r = n.findIndex((e) => J(e) === J(t));
		if (r < 0) return 0;
		if (n.splice(r, 1), s = [...s, {
			rid: l,
			card: t
		}], l = c[(c.indexOf(l) + 1) % c.length], u = He(e, o, s), u === "lost") return Ye(e, o, s);
		if (u === "won") return Je;
	}
	return 0;
}
function Ze(e, t, n, r, i, a) {
	let o = e.trick.plays.length > 0 ? e.trick.plays[0].card.s : null, s = o && r.some((e) => e.s === o) ? r.filter((e) => e.s === o) : r;
	if (a && a.length > 0) {
		let e = new Set(a.map(J)), t = s.filter((t) => e.has(J(t)));
		t.length > 0 && (s = t);
	}
	if (s.length <= 1) return s[0] ?? null;
	let c = Date.now(), l = e.players.map((e) => e.rid), u = l[(l.indexOf(n) + 1) % l.length], d = null;
	{
		let a = c + Math.floor(i * .7), o = /* @__PURE__ */ new Map();
		for (let e of s) o.set(J(e), {
			card: e,
			yes: 0,
			no: 0,
			unknown: 0
		});
		let l = 0;
		for (; Date.now() < a;) {
			let i = Ve(e, t, n, r);
			if (!i) break;
			l += 1;
			for (let r of s) {
				let s = o.get(J(r)), c = {};
				for (let t of e.players) c[t.rid] = i[t.rid].filter((e) => t.rid !== n || J(e) !== J(r));
				let l = Ke(e, t, [...e.trick.plays.map((e) => ({
					rid: e.rid,
					card: e.card
				})), {
					rid: n,
					card: r
				}], c, u, {
					nodes: 0,
					limit: 4e3,
					deadline: a
				}, /* @__PURE__ */ new Map());
				l === !0 ? s.yes += 1 : l === !1 ? s.no += 1 : s.unknown += 1;
			}
			if (l >= 24) break;
		}
		let f = [...o.values()].filter((e) => e.yes + e.no > 0);
		if (f.length > 0) {
			f.sort((e, t) => e.no - t.no || t.yes - e.yes);
			let e = f[0], t = f.filter((t) => t.no === e.no && t.yes === e.yes);
			if (t.length === 1) return t[0].card;
			d = t.map((e) => e.card);
		}
	}
	let f = d ?? s;
	if (f.length <= 1) return f[0] ?? null;
	let p = /* @__PURE__ */ new Map();
	for (let e of f) p.set(J(e), {
		card: e,
		score: 0,
		n: 0
	});
	let m = 0;
	for (; Date.now() - c < i;) {
		let i = Ve(e, t, n, r);
		if (!i) break;
		m += 1;
		for (let r of f) {
			let a = p.get(J(r));
			a.n += 1, a.score += Xe(e, t, i, n, r);
		}
	}
	if (m === 0) return d === null ? null : d[0];
	let h = null, g = -Infinity;
	for (let e of p.values()) {
		let t = e.n > 0 ? e.score / e.n : 0;
		t > g && (g = t, h = e.card);
	}
	return h;
}
//#endregion
//#region src/games/deepsea/bot.ts
var Qe = [
	"pink",
	"blue",
	"green",
	"yellow"
], X = (e) => e.s === "sub";
function $e(e) {
	if (e.phase !== "play") return null;
	if (e.trick.plays.length === 0) return e.trick.leader;
	let t = e.players.map((e) => e.rid), n = e.trick.plays[e.trick.plays.length - 1].rid;
	return t[(t.indexOf(n) + 1) % t.length];
}
function et(e) {
	return e.players.reduce((e, t) => e + t.tricksWon, 0);
}
function tt(e, t) {
	return e.players.find((e) => e.rid === t)?.tricksWon ?? 0;
}
function nt(e) {
	let t = e[0].card.s, n = e.filter((e) => e.card.s === "sub");
	return n.length > 0 ? n.reduce((e, t) => t.card.v > e.card.v ? t : e).rid : e.filter((e) => e.card.s === t).reduce((e, t) => t.card.v > e.card.v ? t : e).rid;
}
function rt(e, t) {
	if (e.s === "sub") return 100 + e.v;
	let n = t[0]?.card.s;
	return n && e.s === n ? 10 + e.v : e.v / 10;
}
function it(e, t) {
	if (t.length === 0) return !0;
	let n = t[0].card.s, r = Math.max(0, ...t.filter((e) => e.card.s === "sub").map((e) => e.card.v));
	return r > 0 ? e.s === "sub" && e.v > r : e.s === "sub" || e.s === n && t.filter((e) => e.card.s === n).every((t) => t.card.v < e.v);
}
var at = (e, t) => e.reduce((e, n) => t(n) > t(e) ? n : e), ot = (e) => `${e.difficulty}:${e.attempts}`;
function st(e, t) {
	if (e.phase === "pick") return [];
	let n = t, r = n?.key === ot(e) ? [...n.tricks] : [], i = et(e);
	return e.lastTrick && r.length < i && r.push({
		winner: e.lastTrick.winner,
		plays: e.lastTrick.plays.map((e) => ({
			rid: e.rid,
			card: e.card
		}))
	}), r;
}
function ct(e, t, n, r) {
	let i = {
		me: n,
		players: e.players.map((e) => e.rid),
		captain: e.captain,
		totalTricks: e.totalTricks,
		finished: t.length >= e.totalTricks,
		tricks: t,
		played: t.flatMap((e) => e.plays.map((e) => e.card)),
		openLead: r
	}, a = /* @__PURE__ */ new Map();
	for (let t of e.tasks) t.owner === n && t.status === "pending" && a.set(t.id, N(k(t.id), t.prediction, i));
	return a;
}
function Z(e, t, n, r, i) {
	let a = {
		winner: n,
		plays: [...e.trick.plays, ...i]
	};
	return ct(e, [...t, a], r, null);
}
var Q = (e) => [...e.values()].includes("failed"), lt = (e) => [...e.values()].filter((e) => e === "done").length;
function ut(e, t, n) {
	let r = 0, i = e.totalTricks - et(e), a = tt(e, n);
	for (let o of e.tasks) {
		if (o.owner !== n || o.status !== "pending") continue;
		let e = k(o.id).kind;
		switch (e.k) {
			case "exactTricks":
			case "predictTricks": {
				let t = e.k === "exactTricks" ? e.n : o.prediction ?? -1;
				if (t < 0) break;
				let n = t - a;
				n > 0 ? r += n >= i ? 3 : 1 : n === 0 && (r -= 2);
				break;
			}
			case "consecutiveTricks":
				if (e.exact) {
					let t = e.n - a;
					t > 0 && (r += t >= i ? 3 : 1);
				} else t.length > 0 && t[t.length - 1].winner === n && (r += 1);
				break;
			case "cmpAll":
				r += e.cmp === "more" ? 1 : -1;
				break;
			case "moreCombined":
				r += 1;
				break;
			case "cmpCaptain":
				r += e.cmp === "more" ? 1 : e.cmp === "fewer" ? -1 : 0;
				break;
			case "winFirstN":
				t.length < e.n && (r += 3);
				break;
			case "winFirstAndLast":
				(t.length === 0 || i <= 2) && (r += 3);
				break;
			case "winOnly":
				e.which === "first" && t.length === 0 && (r += 3), e.which === "last" && i <= 2 && (r += 3);
				break;
			case "winLastTrick":
			case "winCardInLast": i <= 2 && (r += 3);
		}
	}
	return r;
}
function dt(e, t, n) {
	let r = nt(e.trick.plays), i = !1, a = !1;
	for (let o of e.players) {
		if (o.rid === n) continue;
		let s = o.rid, c = Z(e, t, s, s, []);
		Q(c) ? r === s && (a = !0) : lt(c) > 0 && (i = !0), Q(Z(e, t, n, s, [])) && (i = !0);
	}
	return {
		defer: i,
		rescue: a
	};
}
function ft(e, t, n) {
	return e.tasks.some((e) => {
		if (e.owner !== t || e.status !== "pending") return !1;
		let r = k(e.id).kind;
		switch (r.k) {
			case "winCards": return r.cards.some((e) => e.s === n.s && e.v === n.v);
			case "winSub":
			case "winSubOnly": return n.s === "sub" && n.v === r.v;
			case "winValue": return n.s !== "sub" && n.v === r.v;
			case "winSuitCount": return n.s !== "sub" && r.counts.some(([e, t]) => e === n.s && t > 0);
			case "winCardInLast":
			case "winCardWithSub": return r.card.s === n.s && r.card.v === n.v;
			default: return !1;
		}
	});
}
function pt(e, t, n) {
	return e.tasks.some((e) => {
		if (e.owner !== n || e.status !== "pending") return !1;
		let r = k(e.id).kind;
		return r.k === "winNoTricks" || r.k === "dontWinFirstN" && t.length < r.n;
	});
}
function mt(e, t, n) {
	let r = new Set(e.trick.plays.map((e) => e.rid));
	return e.players.some((i) => i.rid !== n && !r.has(i.rid) && pt(e, t, i.rid));
}
function ht(e, t, n, r, i) {
	let a = new Set(e.trick.plays.map((e) => e.rid)), o = 0;
	for (let s of e.players) if (!(s.rid === n || a.has(s.rid))) {
		if (i) {
			let a = i[s.rid] ?? [], c = e.trick.plays[0]?.card.s ?? null, l = c && a.some((e) => e.s === c) ? a.filter((e) => e.s === c) : a;
			l.length > 0 && l.every((t) => it(t, [...e.trick.plays, {
				rid: n,
				card: r
			}])) && Q(Z(e, t, s.rid, s.rid, [{
				rid: n,
				card: r
			}])) && (o += 1e3);
		}
		for (let t of e.tasks) {
			if (t.owner !== s.rid || t.status !== "pending") continue;
			let e = k(t.id).kind;
			e.k === "noValues" && r.s !== "sub" && e.values.includes(r.v) && (o += 15), e.k === "winSuitCount" && e.mode === "exactly" && e.counts.some(([e, t]) => t === 0 && e === r.s) && (o += 15), e.k === "winSubOnly" && r.s === "sub" && r.v !== e.v && (o += 15), e.k === "exactSubs" && r.s === "sub" && (o += 8);
		}
	}
	return o;
}
function gt(e, t, n) {
	let r = t.filter((e) => e.winner === n).flatMap((e) => e.plays.map((e) => e.card)), i = e.trick.plays.map((e) => e.card), a = 0;
	for (let t of e.tasks) {
		if (t.owner !== n || t.status !== "pending") continue;
		let e = k(t.id).kind;
		if (e.k === "winCards" && i.some((t) => e.cards.some((e) => e.s === t.s && e.v === t.v && !r.some((t) => t.s === e.s && t.v === e.v))) && (a += 30), (e.k === "winSub" || e.k === "winSubOnly") && i.some((t) => t.s === "sub" && t.v === e.v) && (a += 30), e.k === "winValue" && e.mode === "atLeast" && r.filter((t) => t.s !== "sub" && t.v === e.v).length < e.count && i.some((t) => t.s !== "sub" && t.v === e.v) && (a += 25), e.k === "winSuitCount" && e.mode === "atLeast") for (let [t, n] of e.counts) n > 0 && r.filter((e) => e.s === t).length < n && i.some((e) => e.s === t) && (a += 25);
	}
	return a;
}
function _t(e, t, n, r) {
	let i = {
		winner: n,
		plays: [{
			rid: n,
			card: r
		}]
	};
	return Q(ct(e, [...t, i], n, null));
}
function vt(e, t, n) {
	let r = 0;
	for (let i of e.tasks) {
		if (i.owner !== t || i.status !== "pending") continue;
		let e = k(i.id).kind;
		e.k === "winTrickWith" && n.v === e.v && (r += 8), e.k === "winCardWith" && n.v === e.use && (r += 8), (e.k === "winLastTrick" || e.k === "winFirstAndLast" || e.k === "winOnly" && e.which === "last") && (X(n) ? r += 6 : n.v >= 8 && (r += 3)), e.k === "winCardInLast" && e.card.s === n.s && e.card.v === n.v && (r += 50), e.k === "winCards" && e.cards.some((e) => e.s === n.s && e.v < n.v) && (r += 8);
	}
	return r;
}
function yt(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = n.filter(X).length;
	if (i > 0) for (let i of e.tasks) {
		if (i.owner !== t || i.status !== "pending") continue;
		let e = k(i.id).kind, a = e.k === "winCards" ? e.cards : e.k === "winCardWithSub" || e.k === "winCardInLast" ? [e.card] : [];
		for (let e of a) {
			if (e.s === "sub" || n.some((t) => t.s === e.s && t.v === e.v)) continue;
			let t = n.filter((t) => t.s === e.s);
			t.length > 0 && t.every((e) => e.v < 7) && r.add(e.s);
		}
	}
	return {
		subs: i,
		weakSuits: r
	};
}
function bt(e, t, n) {
	let r = [...e.trick.plays, ...n], i = [...t.flatMap((e) => e.plays.map((e) => e.card)), ...r.map((e) => e.card)];
	for (let n of e.tasks) {
		if (n.status !== "pending") continue;
		let a = {
			me: n.owner,
			players: e.players.map((e) => e.rid),
			captain: e.captain,
			totalTricks: e.totalTricks,
			finished: !1,
			tricks: t,
			played: i,
			openLead: r.length > 0 ? r[0] : null
		};
		if (N(k(n.id), n.prediction, a) === "failed") return !0;
	}
	return !1;
}
function xt(e, t, n, r) {
	let i = e.trick.plays, a = e.players.filter((e) => e.rid !== n).map((e) => e.rid), o = [];
	for (let s of r) {
		let r = [{
			rid: n,
			card: s
		}];
		if (bt(e, t, r)) continue;
		if (i.length === 0) {
			Ct(e, t, n, s) || o.push(s);
			continue;
		}
		let c = nt(i);
		if (it(s, i)) {
			if (Q(Z(e, t, n, n, r)) || a.some((i) => Q(Z(e, t, n, i, r)) && !Q(Z(e, t, n, i, [])))) continue;
		} else if (Q(Z(e, t, c, n, r))) continue;
		o.push(s);
	}
	return o;
}
function St(e, t, n, r, i, a, o) {
	let s = e.trick.plays, c = nt(s), l = r.map((r) => ({
		c: r,
		wins: it(r, s),
		momentFail: bt(e, t, [{
			rid: n,
			card: r
		}]),
		winFail: Q(Z(e, t, n, n, [{
			rid: n,
			card: r
		}])),
		winDone: lt(Z(e, t, n, n, [{
			rid: n,
			card: r
		}])),
		loseFail: Q(Z(e, t, c, n, [{
			rid: n,
			card: r
		}]))
	})), u = l.filter((e) => !e.momentFail), d = u.length > 0 ? u : l, f = d.filter((e) => !e.wins && !e.loseFail), p = d.filter((e) => e.wins && !e.winFail);
	if (i) {
		let r = f.length > 0 ? f : p.length > 0 ? p : l, i = r.filter((r) => _t(e, t, n, r.c)), a = i.length > 0 ? i : r;
		return a[s.length % a.length].c;
	}
	let { defer: m, rescue: h } = dt(e, t, n), g = ut(e, t, n), _ = gt(e, t, n), v = e.players.filter((e) => e.rid !== n).map((e) => e.rid), y = p.filter((r) => !v.some((i) => Q(Z(e, t, n, i, [{
		rid: n,
		card: r.c
	}])) && !Q(Z(e, t, n, i, [])))), b = y.length > 0 ? y : p, x = f.length === 0, S = mt(e, t, n) && g >= 0;
	if ((x || h || (g > 0 || _ > 0 || S) && !m) && b.length > 0) return at(b, (e) => e.winDone * 100 + _ * 3 - rt(e.c, s)).c;
	if (x && b.length === 0) return at(l, (e) => -rt(e.c, s)).c;
	let C = e.players.filter((e) => e.rid !== n).map((e) => e.rid), w = new Map(C.map((n) => [n, Z(e, t, c, n, [])]));
	return at(f.length > 0 ? f : p, (r) => {
		let i = -vt(e, n, r.c);
		if (_t(e, t, n, r.c) && (i += 30 + r.c.v), c !== n) {
			for (let a of C) {
				let o = w.get(a), s = Z(e, t, c, a, [{
					rid: n,
					card: r.c
				}]);
				for (let [e, t] of s) t === "failed" && o.get(e) !== "failed" && (i -= 1e3), t === "done" && o.get(e) !== "done" && (i += 50);
			}
			ft(e, c, r.c) && (i += 10);
		}
		return i -= ht(e, t, n, r.c, o), !X(r.c) && a.subs > 0 && a.weakSuits.has(r.c.s) && (i += 12), i += g < 0 || S ? r.c.v : -r.c.v, X(r.c) && (i -= 5), i;
	}).c;
}
function Ct(e, t, n, r) {
	return Q(ct(e, t, n, {
		rid: n,
		card: r
	}));
}
function wt(e, t, n, r) {
	for (let i of e.tasks) {
		if (i.owner !== t || i.status !== "pending") continue;
		let e = k(i.id).kind, a = e.k === "winCards" ? e.cards : e.k === "winSub" || e.k === "winSubOnly" ? [{
			s: "sub",
			v: e.v
		}] : e.k === "winCardWithSub" ? [e.card] : [];
		for (let e of a) {
			if (r.some((t) => t.s === e.s && t.v === e.v)) continue;
			let t = n.filter((t) => t.s === e.s), i = t.length > 0 ? t.reduce((e, t) => t.v > e.v ? t : e) : null;
			if (i && i.v >= 8) return i;
		}
	}
	return null;
}
function Tt(e, t, n) {
	return e.some((e) => e.plays[0]?.card.s === n && e.plays.some((e) => e.rid === t && e.card.s !== n));
}
function Et(e, t, n, r, i, a) {
	for (let o of e.players) if (o.rid !== n) for (let s of e.tasks) {
		if (s.owner !== o.rid || s.status !== "pending") continue;
		let c = k(s.id).kind, l = c.k === "winCards" ? c.cards : c.k === "winCardWithSub" ? [c.card] : [];
		for (let s of l) {
			if (s.s === "sub") continue;
			let c = i.find((e) => e.s === s.s && e.v === s.v), l = r.filter((e) => e.s === s.s);
			if (l.length === 0) continue;
			let u = e.players.find((e) => e.rid === o.rid)?.comm, d = u && u.card.s === s.s && (u.pos === "top" || u.pos === "middle") && u.card.v > s.v;
			if (c && r.includes(c)) {
				if (a) {
					let t = a[o.rid] ?? [], r = Math.max(0, ...t.filter((e) => e.s === s.s).map((e) => e.v)), i = r > s.v || !t.some((e) => e.s === s.s) && t.some(X), l = e.players.some((e) => {
						if (e.rid === n || e.rid === o.rid) return !1;
						let t = a[e.rid] ?? [], i = t.filter((e) => e.s === s.s);
						return i.length > 0 ? Math.max(...i.map((e) => e.v)) > r : t.some(X);
					});
					if (i && !l) return c;
				}
				if (d || Tt(t, o.rid, s.s) || s.v <= 3) return c;
				let r = l.filter((e) => e.s !== s.s || e.v !== s.v);
				return r.length > 0 ? r.reduce((e, t) => t.v < e.v ? t : e) : c;
			}
			return l.reduce((e, t) => t.v < e.v ? t : e);
		}
	}
	return null;
}
function Dt(e) {
	let t = e.filter(X);
	return t.length > 0 ? t.reduce((e, t) => t.v > e.v ? t : e) : e.reduce((e, t) => t.v > e.v ? t : e);
}
function Ot(e) {
	let t = e.filter((e) => !X(e));
	if (t.length === 0) return e.reduce((e, t) => t.v < e.v ? t : e);
	let n = t[0].s;
	for (let e of Qe) t.filter((t) => t.s === e).length > t.filter((e) => e.s === n).length && (n = e);
	return t.filter((e) => e.s === n).reduce((e, t) => t.v < e.v ? t : e);
}
function kt(e, t) {
	let n = [];
	for (let r of e.tasks) {
		if (r.owner !== t || r.status !== "pending") continue;
		let e = k(r.id).kind;
		e.k === "winCards" && n.push(...e.cards), e.k === "winCardInLast" && n.push(e.card);
	}
	return n;
}
function At(e, t, n, r, i, a) {
	let o = r.filter((r) => !Ct(e, t, n, r) && !bt(e, t, [{
		rid: n,
		card: r
	}]));
	o.length === 0 && (o = r.filter((r) => !Ct(e, t, n, r))), o.length === 0 && (o = r);
	let s = kt(e, n), c = t.flatMap((e) => e.plays.map((e) => e.card)), l = (e, t) => c.some((n) => n.s === e && n.v === t) || r.some((n) => n.s === e && n.v === t), u = (e) => e.s !== "sub" && [
		9,
		8,
		7,
		6,
		5,
		4,
		3,
		2,
		1
	].every((t) => t <= e.v || l(e.s, t)), d = (e) => s.some((t) => t.s === e.s && t.v === e.v), f = [
		1,
		2,
		3,
		4
	].every((e) => l("sub", e));
	if (!i) {
		let t = e.tasks.filter((e) => e.owner === n && e.status === "pending" && k(e.id).kind.k === "winCards").flatMap((e) => k(e.id).kind.cards), i = o.find((e) => t.some((t) => t.s === e.s && t.v === e.v) && u(e) && f);
		if (i) return i;
		if (a) for (let i of t) {
			if (i.s === "sub" || r.some((e) => e.s === i.s && e.v === i.v)) continue;
			let t = e.players.find((e) => e.rid !== n && (a[e.rid] ?? []).some((e) => e.s === i.s && e.v === i.v));
			if (!t || (a[t.rid] ?? []).filter((e) => e.s === i.s).length !== 1) continue;
			let s = o.filter((e) => e.s === i.s), c = s.length > 0 ? s.reduce((e, t) => t.v > e.v ? t : e) : null;
			if (!(!c || c.v <= i.v) && e.players.every((e) => {
				if (e.rid === n || e.rid === t.rid) return !0;
				let r = a[e.rid] ?? [], o = r.filter((e) => e.s === i.s);
				return o.length > 0 ? Math.max(...o.map((e) => e.v)) < c.v : !r.some(X);
			})) return c;
		}
	}
	let p = o.filter((e) => !d(e) || u(e)), m = p.length > 0 ? p : o, h = m.filter((r) => ht(e, t, n, r, a) === 0);
	h.length > 0 && (m = h);
	let g = /* @__PURE__ */ new Set();
	for (let r of e.players) if (r.comm && r.rid !== n) for (let i of e.tasks) {
		if (i.status !== "pending" || i.owner === n || i.owner === r.rid) continue;
		let e = k(i.id).kind, a = e.k === "winCards" ? e.cards : e.k === "winCardWithSub" ? [e.card] : [];
		for (let e of a) e.s === r.comm.card.s && e.v === r.comm.card.v && !Tt(t, i.owner, e.s) && g.add(e.s);
	}
	let _ = m.filter((e) => !g.has(e.s));
	if (_.length > 0 && (m = _), i) return m.reduce((e, t) => rt(e, []) < rt(t, []) ? e : t);
	let v = ut(e, t, n);
	if (e.players.some((r) => r.rid !== n && pt(e, t, r.rid)) && !pt(e, t, n)) return Dt(m);
	if (v < 3 && t.length < 3 && e.tasks.some((e) => {
		if (e.owner === n || e.status !== "pending") return !1;
		let r = k(e.id).kind;
		return r.k === "winFirstN" && t.length < r.n || r.k === "winFirstAndLast" && t.length === 0 || r.k === "winOnly" && r.which === "first" && t.length === 0;
	})) {
		let e = m.filter((e) => !X(e));
		return (e.length > 0 ? e : m).reduce((e, t) => t.v < e.v ? t : e);
	}
	if (v < 3) {
		let i = o.filter((r) => ht(e, t, n, r, a) === 0), s = Et(e, t, n, i.length > 0 ? i : o, r, a);
		if (s) return s;
	}
	return wt(e, n, m, r) || (v >= 3 ? Dt(m) : Ot(m));
}
function jt(e, t) {
	let n = t.filter((t) => t.s === e.s);
	return n.length === 1 ? "middle" : n.every((t) => t.v <= e.v) ? "top" : n.every((t) => t.v >= e.v) ? "bottom" : null;
}
function Mt(e, t, n) {
	for (let r of [!0, !1]) for (let i of e.tasks) {
		if (i.owner === t !== r || i.status !== "pending") continue;
		let e = k(i.id).kind, a = e.k === "winCards" ? e.cards : e.k === "winCardWithSub" || e.k === "winCardInLast" ? [e.card] : [];
		for (let e of a) {
			if (e.s === "sub") continue;
			let t = n.find((t) => t.s === e.s && t.v === e.v);
			if (!t) continue;
			let r = jt(t, n);
			if (r) return {
				card: t,
				pos: r
			};
		}
	}
	for (let e of Qe) {
		let t = n.filter((t) => t.s === e);
		if (t.length === 1) return {
			card: t[0],
			pos: "middle"
		};
	}
	for (let e of Qe) {
		let t = n.filter((t) => t.s === e), r = t.reduce((e, t) => Math.max(e, t.v), 0);
		if (r >= 8) return {
			card: t.find((e) => e.v === r),
			pos: "top"
		};
	}
	return null;
}
function Nt(e) {
	let t = 0;
	for (let n of e) n.s === "sub" || n.v === 9 ? t += 1 : n.v === 8 && (t += .5);
	return t;
}
function Pt(e, t) {
	let n = e.kind, r = (e, n) => t.some((t) => t.s === e && t.v === n), i = Nt(t);
	switch (n.k) {
		case "winCards": {
			let e = 0, i = t.some((e) => e.s === "sub");
			for (let a of n.cards) r(a.s, a.v) ? e += a.s === "sub" || a.v >= 7 ? 2 : -1 : e += a.s !== "sub" && t.some((e) => e.s === a.s && e.v >= 8) || i ? 2 : -2;
			return e;
		}
		case "winValue": return t.filter((e) => e.s !== "sub" && e.v === n.v).length * 2;
		case "winSub": return r("sub", n.v) ? 3 : -2;
		case "winSubOnly": return (r("sub", n.v) ? 2 : -2) + (t.every((e) => e.s !== "sub" || e.v === n.v) ? 2 : 0);
		case "exactSubs": return t.filter((e) => e.s === "sub").length === n.n ? 3 : -1;
		case "winCardWithSub": return (t.some((e) => e.s === "sub") ? 1 : -1) + (r(n.card.s, n.card.v) ? 1 : -1);
		case "winNoTricks":
		case "dontWinFirstN": return Math.max(0, 4 - i);
		case "noValues": return t.some((e) => e.s !== "sub" && n.values.includes(e.v)) ? -3 : 3 - t.filter((e) => e.s === "sub").length * 2;
		case "winSuitCount": {
			let e = 1;
			for (let [r, i] of n.counts) {
				let n = t.filter((e) => e.s === r).length;
				e += i === 0 ? n === 0 ? 2 : -3 : Math.min(n, i);
			}
			return e;
		}
		case "dontOpen": return n.suits.every((e) => t.some((t) => t.s === e)) ? 0 : 3;
		case "winTrickWith": return t.some((e) => e.v === n.v) ? 2 : -1;
		case "winCardWith": {
			let e = t.filter((e) => e.s !== "sub" && e.v === n.use).length, r = t.filter((e) => e.s !== "sub" && e.v === n.win).length;
			return e > 0 && (n.win === n.use ? r >= 2 : r > 0) ? 3 : 0;
		}
		case "trickAllCmp": return t.filter((e) => e.s !== "sub" && (n.cmp === "below" ? e.v < n.n : e.v > n.n)).length >= 3 ? 2 : 0;
		case "trickParity": return t.filter((e) => e.s !== "sub" && (n.parity === "even" ? e.v % 2 == 0 : e.v % 2 == 1)).length >= 3 ? 2 : 0;
		case "oneOfEachSuit": return Qe.filter((e) => t.some((t) => t.s === e && t.v >= 5)).length >= 3 ? 2 : 0;
		case "allOfOneSuit": return Math.max(0, ...Qe.map((e) => t.filter((t) => t.s === e).length)) >= 5 ? 2 : 0;
		case "cmpAll": return n.cmp === "more" ? i >= 3 ? 2 : 0 : Math.max(0, 4 - i);
		case "moreCombined": return i >= 4 ? 2 : 0;
		case "cmpCaptain": return n.cmp === "same" ? 1 : n.cmp === "more" ? i >= 3 ? 2 : 0 : Math.max(0, 4 - i);
		case "consecutiveTricks":
		case "winFirstN": return i >= n.n ? 2 : 0;
		case "winLastTrick":
		case "winFirstAndLast":
		case "winOnly": return t.some((e) => e.s === "sub") ? 2 : 0;
		case "winCardInLast": return r(n.card.s, n.card.v) ? 3 : -1;
		case "exactTricks": return 2 - Math.abs(i - n.n);
		case "predictTricks": return 1;
		default: return 1;
	}
}
function Ft(e, t) {
	return Math.min(t, Math.round(Nt(e)));
}
var It = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = t.rid, a = r.hand, o = r.allHands, s = t.difficulty === "weak", c = st(n, t.memory), l = {
		key: ot(n),
		tricks: c
	};
	if (n.phase === "pick") {
		if (n.picker !== i || n.pool.length === 0) return null;
		let e = (e) => k(e).kind.k !== "cmpCaptain" || i !== n.captain;
		if (s) {
			let t = n.pool.filter(e);
			if (t.length === 0) return n.canPass ? {
				action: { type: "pass" },
				memory: l
			} : null;
			let r = t[a.length % t.length];
			return {
				action: k(r).kind.k === "predictTricks" ? {
					type: "pick",
					taskId: r,
					prediction: Ft(a, n.totalTricks)
				} : {
					type: "pick",
					taskId: r
				},
				memory: l
			};
		}
		let t = n.tasks.filter((e) => e.owner === i).map((e) => k(e.id)), r = n.pool.filter((n) => e(n) && t.every((e) => !ae(e, k(n))));
		if (r.length === 0) {
			if (n.canPass) return {
				action: { type: "pass" },
				memory: l
			};
			r = n.pool.filter(e), r.length === 0 && (r = n.pool);
		}
		let c = r.map((e) => ({
			id: e,
			s: Pt(k(e), a)
		})).reduce((e, t) => t.s > e.s ? t : e);
		return o && n.canPass && n.players.some((e) => e.rid !== i && Pt(k(c.id), o[e.rid] ?? []) >= c.s + 2) || c.s < 1 && n.canPass ? {
			action: { type: "pass" },
			memory: l
		} : {
			action: k(c.id).kind.k === "predictTricks" ? {
				type: "pick",
				taskId: c.id,
				prediction: Ft(a, n.totalTricks)
			} : {
				type: "pick",
				taskId: c.id
			},
			memory: l
		};
	}
	if (n.phase !== "play") return null;
	if (r.canComm && !s && n.trick.plays.length === 0) {
		let e = Mt(n, i, a);
		if (e) return {
			action: {
				type: "comm",
				card: e.card,
				pos: e.pos
			},
			memory: l
		};
	}
	if ($e(n) !== i) return null;
	let u = r.mustFollow ? a.filter((e) => e.s === r.mustFollow) : a;
	if (u.length === 0) return null;
	if (!s) {
		let e = n.totalTricks - c.length, t = Ze(n, c, i, a, e <= 2 ? 1500 : e <= 4 ? 900 : 500, xt(n, c, i, u));
		if (t) return {
			action: {
				type: "play",
				card: t
			},
			memory: l
		};
	}
	return {
		action: {
			type: "play",
			card: n.trick.plays.length === 0 ? At(n, c, i, u, s, o) : St(n, c, i, u, s, yt(n, i, a), o)
		},
		memory: l
	};
};
//#endregion
//#region src/games/deepsea/fx.tsx
function $(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Lt(e) {
	if (typeof e != "object" || !e) return null;
	let t = e;
	return typeof t.s == "string" && typeof t.v == "number" ? t : null;
}
function Rt(e) {
	if (!Array.isArray(e)) return null;
	let t = e.map(Lt);
	return t.every((e) => e !== null) ? t : null;
}
function zt(e) {
	let t = e.anchor("result-trick"), n = e.anchor("result-trick-card-metric"), r = e.anchor("result-trick-step-metric"), i = e.anchor("result-trick-columns-metric");
	return t && t.w > 0 && t.h > 0 && n && n.w > 0 && n.h > 0 && r && r.w > 0 && r.h > 0 && i && i.w > 0 ? t : null;
}
function Bt(e) {
	return zt(e) ?? e.anchor("trick");
}
function Vt(e, t, n, r) {
	let i = zt(e) !== null, a = e.anchor(i ? "result-trick-card-metric" : "trick-card-metric"), o = e.anchor(i ? "result-trick-step-metric" : "trick-step-metric"), s = e.anchor(i ? "result-trick-columns-metric" : "trick-columns-metric");
	if (a && o && s && a.w > 0 && a.h > 0 && o.w > 0 && o.h > 0 && s.w > 0) {
		let e = Math.max(1, Math.round(s.w)), t = Math.ceil(r / e), i = Math.floor(n / e), c = Math.min(e, r - i * e);
		return {
			x: a.x - (c - 1) * o.w / 2 + n % e * o.w,
			y: a.y - (t - 1) * o.h / 2 + i * o.h,
			w: a.w,
			h: a.h
		};
	}
	let c = r * 44 + (r - 1) * 8;
	return {
		x: t.x + (t.w - c) / 2 + n * 52,
		y: t.y + (t.h - 64) / 2,
		w: 44,
		h: 64
	};
}
var Ht = {
	deal(e, t) {
		let n = e.secret, r = n ? Rt(n.cards) : null, i = t.anchor("table");
		if (r) {
			if (!i) return null;
			let e = [], n = [];
			for (let [a, o] of r.entries()) {
				let r = t.anchor(`hand:${K(o)}`);
				if (!r) continue;
				let s = {
					x: i.x + (i.w - r.w) / 2,
					y: i.y + (i.h - r.h) / 2,
					w: r.w,
					h: r.h
				};
				n.push(`hand:${K(o)}`), e.push(/* @__PURE__ */ h(v, {
					from: s,
					to: r,
					ms: 320,
					delay: a * 45,
					children: /* @__PURE__ */ h(q, {
						card: o,
						size: "hand",
						dimensions: r
					})
				}, K(o)));
			}
			return e.length ? {
				ms: 320 + e.length * 45,
				node: e,
				hide: n
			} : null;
		}
		let a = $(t, e.rid);
		if (!i || !a) return null;
		let o = t.anchor("trick-card-metric"), s = o && o.w > 0 ? o.w : 44, c = o && o.h > 0 ? o.h : 64, l = {
			x: i.x + (i.w - s) / 2,
			y: i.y + (i.h - c) / 2,
			w: s,
			h: c
		}, u = e.data?.count, d = typeof u == "number" ? u : 10;
		return {
			ms: 320 + d * 45,
			node: Array.from({ length: d }, (e, t) => /* @__PURE__ */ h(v, {
				from: l,
				to: a,
				ms: 320,
				delay: t * 45,
				children: /* @__PURE__ */ h(Se, {
					accent: U.accent,
					dimensions: l
				})
			}, t))
		};
	},
	play(e, t) {
		let n = Lt(e.data?.card), r = e.data?.index, i = $(t, e.rid);
		if (!n || !i || typeof r != "number") return null;
		let a = Bt(t), o = t.anchor(`tcard:${r}`) ?? (a ? Vt(t, a, r, r + 1) : null);
		return o ? {
			ms: 400,
			node: /* @__PURE__ */ h(v, {
				from: i,
				to: o,
				ms: 380,
				children: /* @__PURE__ */ h(q, {
					card: n,
					size: "table",
					dimensions: o
				})
			}),
			hide: [`tcard:${r}`]
		} : null;
	},
	gather(e, t) {
		let n = $(t, e.rid), r = Bt(t);
		if (!n || !r) return null;
		let i = e.data?.count, a = typeof i == "number" ? i : 4;
		return {
			ms: 500,
			node: Array.from({ length: a }, (e, i) => {
				let o = Vt(t, r, i, a);
				return /* @__PURE__ */ h(v, {
					from: o,
					to: n,
					ms: 420,
					delay: i * 50,
					children: /* @__PURE__ */ h(Se, {
						accent: U.accent,
						dimensions: o
					})
				}, i);
			})
		};
	},
	taskDone(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 1e3,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: 900,
				delay: 80,
				children: "✓"
			})
		} : null;
	},
	taskPick(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 500
			})
		} : null;
	},
	comm(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 600
			})
		} : null;
	}
};
//#endregion
//#region src/games/deepsea/options.tsx
function Ut({ value: e, onChange: t }) {
	let n = o(), r = T.safeParse(e), i = r.success ? r.data : T.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ h(x, {
			title: n("games.deepsea.optDifficulty"),
			columns: 3,
			children: Array.from({ length: 10 }, (e, t) => t + 1).map((e) => /* @__PURE__ */ h(b, {
				name: "deepsea-difficulty",
				value: String(e),
				checked: i.difficulty === e,
				label: e,
				accent: U.accent,
				onChange: () => t({ difficulty: e })
			}, e))
		}), /* @__PURE__ */ h("p", {
			className: "text-xs text-ink/70",
			children: n("games.deepsea.optDifficultyHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/deepsea/entry.tsx
var Wt = {
	definition: _e,
	View: Ae,
	bot: It,
	fx: Ht,
	Options: Ut,
	locales: {
		zh: {
			name: "深海任务",
			desc: "协力吃墩:各自领任务,沉默配合完成全船目标",
			rules: "目标:全队合作,每人认领自己的任务卡并在牌墩进行过程中完成它;任何一张任务失败,全船失败。\n牌:\n· 四种花色各 1~9,另有潜艇(将牌)1~4。\n· 必须跟花色;潜艇大于所有花色牌,潜艇之间数字大者胜。\n准备:\n· 持有潜艇 4 的人是船长:率先认领任务，并领出第一墩。\n· 按任务卡背面的点数抽取任务，直到达到本关要求的总点数，再从船长开始依次认领。需要与船长比较赢墩数的任务，船长不能认领。\n声呐沟通:\n· 每两墩之间,每人可用一次声呐:亮出一张花色牌,并标注「最高 / 唯一 / 最低」,表明它在你手中该花色里的地位。\n· 打出该牌后,展示撤下。\n电子版公开信息:\n· 每人已吃的牌全程展示,按花色与点数排序;未出的手牌仍保密。\n胜负:\n· 全员任务完成即过关,可挑战下一难度(任务点数加 1)。\n· 失败可带同一批任务重试,或换一批重抽。",
			optDifficulty: "起始难度(任务点数)",
			optDifficultyHint: "点数越高抽到的任务越多越难;过关后自动 +1",
			pickPrompt: "轮到你认领任务",
			pickWaiting: "等 {{name}} 认领任务…",
			turnYou: "轮到你出牌",
			turnWait: "等 {{name}} 出牌…",
			won: "全船任务完成!",
			lost: "任务失败,本波结束",
			diffChip: "难度 {{n}}",
			attemptSub: "第 {{n}} 次尝试",
			captainAria: "船长",
			tricksAria: "已赢 {{n}} 墩",
			tricksShort: "{{n}} 墩",
			tasksAria: "任务 {{n}}/{{total}}",
			captainBlocked: "船长不能领",
			pass: "跳过(下一轮必须认领)",
			trickLead: "等 {{name}} 开墩",
			trickChip: "第 {{n}}/{{total}} 墩",
			lastTrick: "上一墩 {{name}} 赢:",
			prediction: "预测 {{n}}",
			failedBy: "{{name}} 的任务失败:",
			retrySame: "重试(同任务)",
			retryRedraw: "重试(换任务)",
			nextDiff: "下一难度 {{n}}",
			resultWonTitle: "任务完成",
			resultLostTitle: "任务失败",
			resultWonSub: "全员目标达成，潜艇继续下潜。",
			resultLostSub: "本次潜航结束，调整任务后再出发。",
			resultSummary: "本次潜航统计",
			resultTasks: "完成任务",
			resultTricks: "已打墩数",
			resultAgain: "再挑战难度 10",
			resultExit: "退出对局",
			predictLabel: "预测墩数",
			predictMinus: "减一",
			predictPlus: "加一",
			cancel: "取消",
			claim: "认领",
			commButton: "声呐沟通",
			commPickCard: "选一张花色牌亮出",
			commTop: "最高",
			commMiddle: "唯一",
			commBottom: "最低",
			commSend: "亮出",
			playCard: "出牌",
			tasksHeading: "本次任务",
			capturedHeading: "玩家与吃牌",
			capturedTotal: "共 {{n}} 张",
			capturedCount: "{{n}} 张",
			noCaptured: "尚无吃牌",
			unclaimed: "尚未认领",
			taskPending: "待完成",
			taskDone: "任务完成",
			taskFailed: "任务失败",
			taskSelected: "已选中",
			taskNumber: "MISSION / {{n}}",
			handCount: "我的手牌 · {{n}}",
			handScroll: "左右滑动查看更多",
			playSpot: "待出牌",
			taskClose: "收起任务",
			suit: {
				pink: "粉色 {{n}}",
				blue: "蓝色 {{n}}",
				green: "绿色 {{n}}",
				yellow: "黄色 {{n}}",
				sub: "潜艇 {{n}}"
			},
			errPhase: "现在不能这么做",
			errTurn: "还没轮到你",
			errTask: "这张任务不在池子里",
			errTaskCaptain: "船长不能认领与船长比较的任务",
			errPrediction: "预测类任务要填墩数,其余任务不带预测",
			errPass: "任务不少于人数,不能跳过",
			errCard: "手里没有这张牌",
			errFollow: "必须跟花色",
			errCommMidTrick: "墩进行中不能沟通",
			errCommUsed: "本波你已经沟通过了",
			errCommSub: "潜艇不能用于声呐沟通",
			errCommPos: "标位与你手中该花色的牌不符",
			tasks: {
				t1: "我赢的墩比任何人都多",
				t2: "我赢的墩比其他所有人加起来还多",
				t3: "我赢的墩比任何人都少",
				t4: "我赢的墩比船长多",
				t5: "我赢的墩比船长少",
				t6: "我赢的墩和船长一样多",
				t7: "赢下一墩,墩内所有牌小于 7,且无潜艇",
				t8: "赢下一墩,墩内所有牌大于 5,且无潜艇",
				t9: "用一张 {{0}} 赢下一墩",
				t10: "用一张 {{0}} 赢下一墩",
				t11: "用一张 {{0}} 赢下一墩",
				t12: "用 {{1}} 赢下一墩,墩内有 {{0}}",
				t13: "用 {{1}} 赢下一墩,墩内有 {{0}}",
				t14: "用 {{0}} 赢下一墩,墩内还有另一张 {{0}}",
				t15: "用一张 {{0}} 赢下一墩",
				t16: "吃到 {{0}}",
				t17: "吃到 {{0}}",
				t18: "吃到 {{0}}",
				t19: "吃到 {{0}}",
				t20: "吃到全部四张 {{0}}",
				t21: "吃到至少三张 {{0}}",
				t22: "吃到至少三张 {{0}}",
				t23: "吃到至少两张 {{0}}",
				t24: "吃到全部四张 {{0}}",
				t25: "吃到恰好三张 {{0}}",
				t26: "吃到恰好两张 {{0}}",
				t27: "吃到 {{0}}{{1}}{{2}}",
				t28: "吃到 {{0}} 和 {{1}}",
				t29: "吃到 {{0}} 和 {{1}}",
				t30: "吃到 {{0}} 和 {{1}}",
				t31: "吃到 {{0}} 和 {{1}}",
				t32: "吃到 {{0}} 和 {{1}}",
				t33: "吃到 {{0}} 和 {{1}}",
				t34: "吃到 {{0}} 和 {{1}}",
				t35: "吃到 {{0}}{{1}}{{2}}",
				t36: "在最后一墩吃到 {{0}}",
				t37: "吃到的 {{0}} 和 {{1}} 各恰好一张",
				t38: "吃到至少七张 {{0}}",
				t39: "吃到至少五张 {{0}}",
				t40: "吃到恰好两张 {{0}}",
				t41: "吃到恰好两张 {{0}}",
				t42: "吃到恰好一张 {{0}}",
				t43: "不吃任何 {{0}}",
				t44: "每种花色都至少吃到一张",
				t45: "吃齐某一种花色的全部九张",
				t46: "赢下一墩,墩内全是偶数,且无潜艇",
				t47: "赢下一墩,墩内全是奇数,且无潜艇",
				t48: "赢下一墩,墩内牌面总和大于 {{0}},且无潜艇",
				t49: "赢下一墩,墩内牌面总和小于 {{0}},且无潜艇",
				t50: "赢下一墩,墩内牌面总和为 22 或 23,且无潜艇",
				t51: "恰好吃到一张 {{0}}",
				t52: "吃到 {{0}},且不吃到其他潜艇",
				t53: "吃到 {{0}},且不吃到其他潜艇",
				t54: "吃到 {{0}}",
				t55: "恰好吃到两张 {{0}}",
				t56: "恰好吃到三张 {{0}}",
				t57: "不吃任何 {{0}}",
				t58: "用 {{1}} 赢墩并吃到 {{0}}",
				t59: "用 {{1}} 赢墩并吃到 {{0}}",
				t60: "不用 {{0}}{{1}}{{2}} 开墩",
				t61: "不用 {{0}}{{1}} 开墩",
				t62: "不吃任何 {{0}}",
				t63: "不吃任何 {{0}}",
				t64: "不吃任何 {{0}} 和 {{1}}",
				t65: "不吃任何 {{0}} 和 {{1}}",
				t66: "不吃任何 {{0}} 和 {{1}}",
				t67: "不吃任何 {{0}}",
				t68: "不吃任何 {{0}}",
				t69: "不吃任何 {{0}}",
				t70: "不吃任何 {{0}}{{1}}{{2}}",
				t71: "不赢前四墩中的任何一墩",
				t72: "不赢前三墩中的任何一墩",
				t73: "不赢前五墩中的任何一墩",
				t74: "我一墩也不赢",
				t75: "不连续赢两墩",
				t76: "赢下最后一墩",
				t77: "赢下前三墩",
				t78: "赢下前两墩",
				t79: "赢下第一墩",
				t80: "赢下第一墩和最后一墩",
				t81: "只赢最后一墩,其余一墩不赢",
				t82: "只赢第一墩,其余一墩不赢",
				t83: "恰好赢一墩",
				t84: "恰好赢两墩",
				t85: "连续赢两墩",
				t86: "连续赢三墩",
				t87: "恰好赢四墩",
				t88: "恰好赢三墩,且是连续三墩",
				t89: "恰好赢两墩,且是连续两墩",
				t90: "公开预测我赢的墩数,不多不少",
				t91: "暗自预测我赢的墩数,不多不少",
				t92: "吃到的 {{0}} 和 {{1}} 一样多(不为零)",
				t93: "赢下一墩,墩内 {{0}} 和 {{1}} 一样多(不为零)",
				t94: "赢下一墩,墩内 {{0}} 和 {{1}} 一样多(不为零)",
				t95: "吃到的 {{0}} 比 {{1}} 多",
				t96: "吃到的 {{0}} 比 {{1}} 多"
			}
		},
		en: {
			name: "The Crew: Deep Sea",
			desc: "Co-op trick-taking: claim tasks and fulfil them together in silence",
			rules: "Goal: cooperate — everyone claims task cards and fulfils them during tricks; a single failed task sinks the whole crew.\nCards:\n· Four suits of 1–9, plus submarines (trump) 1–4.\n· You must follow suit; submarines outrank every suited card, and among submarines the higher number wins.\nSetup:\n· The holder of submarine 4 is the captain: claims a task first and leads the first trick.\n· Tasks are dealt until their point values reach the mission total, then claimed in order starting from the captain; the captain cannot take a task that compares against the captain.\nRadio (sonar):\n· Once between tricks, each player may radio: reveal a suit card and tag it “highest / only / lowest” for that suit in your hand.\n· The reveal clears once that card is played.\nDigital edition:\n· Everyone’s captured cards stay visible, sorted by suit and number; unplayed hands remain secret.\nResult:\n· When all tasks are completed, the mission succeeds and you may attempt the next difficulty (task points increase by 1).\n· On failure, retry with the same tasks or redraw a new set.",
			optDifficulty: "Starting difficulty (task points)",
			optDifficultyHint: "More points = more and harder tasks; +1 after each win",
			pickPrompt: "Your turn to claim a task",
			pickWaiting: "Waiting for {{name}} to claim…",
			turnYou: "Your turn to play",
			turnWait: "Waiting for {{name}}…",
			won: "All tasks complete!",
			lost: "A task failed — attempt over",
			diffChip: "Level {{n}}",
			attemptSub: "Attempt {{n}}",
			captainAria: "Captain",
			tricksAria: "{{n}} tricks won",
			tricksShort: "{{n}} tricks",
			tasksAria: "Tasks {{n}}/{{total}}",
			captainBlocked: "Not for captain",
			pass: "Pass (must claim next round)",
			trickLead: "Waiting for {{name}} to lead",
			trickChip: "Trick {{n}}/{{total}}",
			lastTrick: "Last trick: {{name}} won",
			prediction: "Bid {{n}}",
			failedBy: "{{name}}'s task failed:",
			retrySame: "Retry (same tasks)",
			retryRedraw: "Retry (new tasks)",
			nextDiff: "Next level {{n}}",
			resultWonTitle: "Mission complete",
			resultLostTitle: "Mission failed",
			resultWonSub: "Every objective is complete. The crew dives on.",
			resultLostSub: "This dive is over. Regroup for another attempt.",
			resultSummary: "Dive summary",
			resultTasks: "Tasks complete",
			resultTricks: "Tricks played",
			resultAgain: "Play level 10 again",
			resultExit: "Leave game",
			predictLabel: "Predicted tricks",
			predictMinus: "Minus one",
			predictPlus: "Plus one",
			cancel: "Cancel",
			claim: "Claim",
			commButton: "Radio sonar",
			commPickCard: "Pick a suit card to reveal",
			commTop: "Highest",
			commMiddle: "Only",
			commBottom: "Lowest",
			commSend: "Reveal",
			playCard: "Play",
			tasksHeading: "Mission tasks",
			capturedHeading: "Crew & captures",
			capturedTotal: "{{n}} cards total",
			capturedCount: "{{n}} cards",
			noCaptured: "No captured cards",
			unclaimed: "Unclaimed",
			taskPending: "Pending",
			taskDone: "Complete",
			taskFailed: "Failed",
			taskSelected: "Selected",
			taskNumber: "MISSION / {{n}}",
			handCount: "Your hand · {{n}}",
			handScroll: "Swipe for more",
			playSpot: "Awaiting card",
			taskClose: "Close task",
			suit: {
				pink: "pink {{n}}",
				blue: "blue {{n}}",
				green: "green {{n}}",
				yellow: "yellow {{n}}",
				sub: "submarine {{n}}"
			},
			errPhase: "Not right now",
			errTurn: "Not your turn",
			errTask: "That task is not in the pool",
			errTaskCaptain: "The captain cannot claim captain-comparison tasks",
			errPrediction: "Prediction tasks need a trick count; others must not have one",
			errPass: "Cannot pass while tasks outnumber players",
			errCard: "That card is not in your hand",
			errFollow: "You must follow suit",
			errCommMidTrick: "No radio mid-trick",
			errCommUsed: "You already used your radio this attempt",
			errCommSub: "Submarines cannot be revealed",
			errCommPos: "Token position does not match your hand",
			tasks: {
				t1: "I win more tricks than anyone else",
				t2: "I win more tricks than all others combined",
				t3: "I win fewer tricks than anyone else",
				t4: "I win more tricks than the captain",
				t5: "I win fewer tricks than the captain",
				t6: "I win as many tricks as the captain",
				t7: "Win a trick with all cards below 7, no subs",
				t8: "Win a trick with all cards above 5, no subs",
				t9: "Win a trick with a {{0}}",
				t10: "Win a trick with a {{0}}",
				t11: "Win a trick with a {{0}}",
				t12: "Win a trick with {{1}} containing {{0}}",
				t13: "Win a trick with {{1}} containing {{0}}",
				t14: "Win a trick with {{0}} containing another {{0}}",
				t15: "Win a trick with a {{0}}",
				t16: "Win {{0}}",
				t17: "Win {{0}}",
				t18: "Win {{0}}",
				t19: "Win {{0}}",
				t20: "Win all four {{0}}s",
				t21: "Win at least three {{0}}s",
				t22: "Win at least three {{0}}s",
				t23: "Win at least two {{0}}s",
				t24: "Win all four {{0}}s",
				t25: "Win exactly three {{0}}s",
				t26: "Win exactly two {{0}}s",
				t27: "Win {{0}} {{1}} {{2}}",
				t28: "Win {{0}} and {{1}}",
				t29: "Win {{0}} and {{1}}",
				t30: "Win {{0}} and {{1}}",
				t31: "Win {{0}} and {{1}}",
				t32: "Win {{0}} and {{1}}",
				t33: "Win {{0}} and {{1}}",
				t34: "Win {{0}} and {{1}}",
				t35: "Win {{0}} {{1}} {{2}}",
				t36: "Win {{0}} in the last trick",
				t37: "Win exactly one {{0}} and one {{1}}",
				t38: "Win at least seven {{0}}",
				t39: "Win at least five {{0}}",
				t40: "Win exactly two {{0}}",
				t41: "Win exactly two {{0}}",
				t42: "Win exactly one {{0}}",
				t43: "Win no {{0}}",
				t44: "Win at least one card of each suit",
				t45: "Win all nine cards of one suit",
				t46: "Win a trick with only even cards, no subs",
				t47: "Win a trick with only odd cards, no subs",
				t48: "Win a trick with card total over {{0}}, no subs",
				t49: "Win a trick with card total under {{0}}, no subs",
				t50: "Win a trick with card total 22 or 23, no subs",
				t51: "Win exactly one {{0}}",
				t52: "Win {{0}} and no other sub",
				t53: "Win {{0}} and no other sub",
				t54: "Win {{0}}",
				t55: "Win exactly two {{0}}",
				t56: "Win exactly three {{0}}",
				t57: "Win no {{0}}",
				t58: "Win {{0}} by playing a {{1}}",
				t59: "Win {{0}} by playing a {{1}}",
				t60: "Never open a trick with {{0}} {{1}} {{2}}",
				t61: "Never open a trick with {{0}} {{1}}",
				t62: "Win no {{0}}",
				t63: "Win no {{0}}",
				t64: "Win no {{0}} or {{1}}",
				t65: "Win no {{0}} or {{1}}",
				t66: "Win no {{0}} or {{1}}",
				t67: "Win no {{0}}",
				t68: "Win no {{0}}",
				t69: "Win no {{0}}",
				t70: "Win no {{0}} {{1}} {{2}}",
				t71: "Win none of the first four tricks",
				t72: "Win none of the first three tricks",
				t73: "Win none of the first five tricks",
				t74: "I win no tricks at all",
				t75: "Never win two tricks in a row",
				t76: "Win the last trick",
				t77: "Win the first three tricks",
				t78: "Win the first two tricks",
				t79: "Win the first trick",
				t80: "Win the first and the last trick",
				t81: "Win only the last trick, no other",
				t82: "Win only the first trick, no other",
				t83: "Win exactly one trick",
				t84: "Win exactly two tricks",
				t85: "Win two tricks in a row",
				t86: "Win three tricks in a row",
				t87: "Win exactly four tricks",
				t88: "Win exactly three tricks, all in a row",
				t89: "Win exactly two tricks, in a row",
				t90: "Openly predict my exact trick count",
				t91: "Secretly predict my exact trick count",
				t92: "Win equal {{0}} and {{1}} (not zero)",
				t93: "Win a trick with equal {{0}} and {{1}} (not zero)",
				t94: "Win a trick with equal {{0}} and {{1}} (not zero)",
				t95: "Win more {{0}} than {{1}}",
				t96: "Win more {{0}} than {{1}}"
			}
		}
	}
};
//#endregion
export { Wt as default };
