import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { cellsOf as t } from "@bgparty/sdk/polyomino";
import { z as n } from "zod";
import { useId as r, useMemo as i, useRef as a, useState as o } from "react";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconMirror as d, IconRotate as f } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as p } from "@bgparty/sdk/player-colors";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as ee } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as te, seatName as h } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { botAvatarOf as y } from "@bgparty/sdk/lobby";
import { botPersonality as b } from "@bgparty/sdk/bot-personality";
import { Floater as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
//#region src/games/patchwork/meta.ts
var C = {
	id: "patchwork",
	tier: "released",
	mechanics: ["drafting", "tile-placement"],
	interactionTags: [],
	nameKey: "games.patchwork.name",
	descKey: "games.patchwork.desc",
	rulesKey: "games.patchwork.rules",
	icon: "🧵",
	iconImg: "games/patchwork.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/patchwork/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#0d9488",
	releasedAt: "2026-09-15",
	search: {
		py: "pin bu yi shu",
		init: "pbys"
	},
	hotseat: "cover"
}, w = [
	{
		shape: [[1, 1]],
		cost: 2,
		time: 1,
		income: 0,
		color: "#e11d48"
	},
	{
		shape: [[
			1,
			1,
			1
		]],
		cost: 2,
		time: 2,
		income: 0,
		color: "#ea580c"
	},
	{
		shape: [[
			1,
			1,
			1,
			1
		]],
		cost: 3,
		time: 3,
		income: 1,
		color: "#d97706"
	},
	{
		shape: [[
			1,
			1,
			1,
			1,
			1
		]],
		cost: 7,
		time: 1,
		income: 1,
		color: "#65a30d"
	},
	{
		shape: [[1, 1], [1, 1]],
		cost: 6,
		time: 5,
		income: 2,
		color: "#059669"
	},
	{
		shape: [[
			1,
			1,
			0
		], [
			1,
			1,
			1
		]],
		cost: 2,
		time: 2,
		income: 0,
		color: "#0d9488"
	},
	{
		shape: [[
			1,
			1,
			0,
			0
		], [
			1,
			1,
			1,
			1
		]],
		cost: 10,
		time: 5,
		income: 3,
		color: "#0891b2"
	},
	{
		shape: [[
			0,
			1,
			1,
			0
		], [
			1,
			1,
			1,
			1
		]],
		cost: 7,
		time: 4,
		income: 2,
		color: "#2563eb"
	},
	{
		shape: [[
			1,
			1,
			1,
			0
		], [
			0,
			1,
			1,
			1
		]],
		cost: 4,
		time: 2,
		income: 0,
		color: "#4f46e5"
	},
	{
		shape: [
			[
				0,
				1,
				1
			],
			[
				0,
				1,
				1
			],
			[
				1,
				1,
				0
			]
		],
		cost: 8,
		time: 6,
		income: 3,
		color: "#7c3aed"
	},
	{
		shape: [[
			1,
			0,
			1
		], [
			1,
			1,
			1
		]],
		cost: 1,
		time: 2,
		income: 0,
		color: "#a21caf"
	},
	{
		shape: [[
			1,
			0,
			0,
			1
		], [
			1,
			1,
			1,
			1
		]],
		cost: 1,
		time: 5,
		income: 1,
		color: "#db2777"
	},
	{
		shape: [
			[
				1,
				0,
				1
			],
			[
				1,
				1,
				1
			],
			[
				0,
				1,
				0
			]
		],
		cost: 3,
		time: 6,
		income: 2,
		color: "#b45309"
	},
	{
		shape: [[
			1,
			1,
			1
		], [
			0,
			1,
			0
		]],
		cost: 2,
		time: 2,
		income: 0,
		color: "#3f6212"
	},
	{
		shape: [
			[
				1,
				1,
				1
			],
			[
				0,
				1,
				0
			],
			[
				0,
				1,
				0
			]
		],
		cost: 5,
		time: 5,
		income: 2,
		color: "#0f766e"
	},
	{
		shape: [
			[
				1,
				1,
				1
			],
			[
				0,
				1,
				0
			],
			[
				0,
				1,
				0
			],
			[
				0,
				1,
				0
			]
		],
		cost: 7,
		time: 2,
		income: 2,
		color: "#1d4ed8"
	},
	{
		shape: [
			[
				0,
				1,
				0
			],
			[
				1,
				1,
				1
			],
			[
				0,
				1,
				0
			],
			[
				0,
				1,
				0
			]
		],
		cost: 0,
		time: 3,
		income: 1,
		color: "#9333ea"
	},
	{
		shape: [
			[1, 0],
			[1, 0],
			[1, 1]
		],
		cost: 4,
		time: 2,
		income: 1,
		color: "#be185d"
	},
	{
		shape: [
			[1, 0],
			[1, 0],
			[1, 1]
		],
		cost: 4,
		time: 6,
		income: 2,
		color: "#9a3412"
	},
	{
		shape: [
			[1, 0],
			[1, 0],
			[1, 0],
			[1, 1]
		],
		cost: 10,
		time: 3,
		income: 2,
		color: "#15803d"
	},
	{
		shape: [
			[1, 0],
			[1, 0],
			[1, 1],
			[1, 0]
		],
		cost: 3,
		time: 4,
		income: 1,
		color: "#0369a1"
	},
	{
		shape: [
			[
				0,
				1,
				0
			],
			[
				1,
				1,
				1
			],
			[
				0,
				1,
				0
			]
		],
		cost: 5,
		time: 4,
		income: 2,
		color: "#6d28d9"
	},
	{
		shape: [
			[
				0,
				1,
				0
			],
			[
				0,
				1,
				0
			],
			[
				1,
				1,
				1
			],
			[
				0,
				1,
				0
			],
			[
				0,
				1,
				0
			]
		],
		cost: 1,
		time: 4,
		income: 1,
		color: "#c026d3"
	},
	{
		shape: [
			[
				0,
				1,
				1,
				0
			],
			[
				1,
				1,
				1,
				1
			],
			[
				0,
				1,
				1,
				0
			]
		],
		cost: 5,
		time: 3,
		income: 1,
		color: "#eab308"
	},
	{
		shape: [
			[
				1,
				0,
				1
			],
			[
				1,
				1,
				1
			],
			[
				1,
				0,
				1
			]
		],
		cost: 2,
		time: 3,
		income: 0,
		color: "#84cc16"
	},
	{
		shape: [[0, 1], [1, 1]],
		cost: 3,
		time: 1,
		income: 0,
		color: "#14b8a6"
	},
	{
		shape: [[0, 1], [1, 1]],
		cost: 1,
		time: 3,
		income: 0,
		color: "#f97316"
	},
	{
		shape: [
			[0, 1],
			[1, 1],
			[1, 0]
		],
		cost: 3,
		time: 2,
		income: 1,
		color: "#8b5cf6"
	},
	{
		shape: [
			[0, 1],
			[1, 1],
			[1, 0]
		],
		cost: 7,
		time: 6,
		income: 3,
		color: "#ec4899"
	},
	{
		shape: [
			[0, 1],
			[0, 1],
			[1, 1],
			[1, 0]
		],
		cost: 2,
		time: 3,
		income: 1,
		color: "#78716c"
	},
	{
		shape: [
			[
				0,
				0,
				0,
				1
			],
			[
				1,
				1,
				1,
				1
			],
			[
				1,
				0,
				0,
				0
			]
		],
		cost: 1,
		time: 2,
		income: 0,
		color: "#dc2626"
	},
	{
		shape: [
			[
				0,
				0,
				1,
				0
			],
			[
				1,
				1,
				1,
				1
			],
			[
				0,
				1,
				0,
				0
			]
		],
		cost: 2,
		time: 1,
		income: 0,
		color: "#0284c7"
	},
	{
		shape: [
			[
				0,
				0,
				1
			],
			[
				0,
				1,
				1
			],
			[
				1,
				1,
				0
			]
		],
		cost: 10,
		time: 4,
		income: 3,
		color: "#16a34a"
	}
], T = [
	5,
	11,
	17,
	23,
	29,
	35,
	41,
	47,
	53
], E = [
	20,
	26,
	32,
	44,
	50
], D = n.int().min(0).max(8), O = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("buy"),
		choice: n.int().min(0).max(2),
		x: D,
		y: D,
		rot: n.int().min(0).max(3),
		flip: n.boolean()
	}),
	n.object({
		type: n.literal("placeLeather"),
		x: D,
		y: D
	}),
	n.object({ type: n.literal("advance") })
]), k = n.string(), A = n.object({
	pid: n.int().min(-1),
	x: D,
	y: D,
	rot: n.int().min(0).max(3),
	flip: n.boolean()
}), j = n.object({
	rid: k,
	buttons: n.number(),
	bonus7: n.number(),
	empty: n.int().nonnegative(),
	total: n.number()
}), M = n.object({
	phase: n.enum(["play", "done"]),
	ring: n.array(n.int().min(0)),
	neutral: n.int().min(0),
	players: n.array(n.object({
		rid: k,
		pos: n.int().min(0),
		buttons: n.number(),
		income: n.int().nonnegative(),
		board: n.array(A)
	})),
	turn: k,
	onTop: k,
	pendingLeather: k.nullable(),
	leatherLeft: n.int().min(0),
	special7: k.nullable(),
	finishedOrder: n.array(k),
	final: n.array(j).optional()
}), N = n.object({});
//#endregion
//#region src/games/patchwork/rules.ts
function P(e) {
	let n = Array(81).fill(-1);
	return e.forEach((e, r) => {
		let i = e.pid < 0 ? [[0, 0]] : t(w[e.pid].shape, e.rot, e.flip);
		for (let [t, a] of i) n[(e.y + a) * 9 + (e.x + t)] = r;
	}), n;
}
function F(e, t, n, r) {
	for (let [i, a] of t) {
		let t = n + i, o = r + a;
		if (t < 0 || t >= 9 || o < 0 || o >= 9 || e[o * 9 + t] !== -1) return !1;
	}
	return !0;
}
function I(e) {
	for (let t = 0; t <= 2; t++) for (let n = 0; n <= 2; n++) {
		let r = !0;
		for (let i = t; i < t + 7 && r; i++) for (let t = n; t < n + 7; t++) if (e[i * 9 + t] === -1) {
			r = !1;
			break;
		}
		if (r) return !0;
	}
	return !1;
}
function re(e) {
	return e.reduce((e, t) => e + (t.pid >= 0 ? w[t.pid].income : 0), 0);
}
function L(e) {
	return P(e).filter((e) => e === -1).length;
}
function R(t, n, r) {
	let i = Array.from({ length: w.length }, (e, t) => t), a = 0;
	for (let t = i.length - 1; t > 0; --t) {
		let n = e(r, a, t + 1);
		a += 1, [i[t], i[n]] = [i[n], i[t]];
	}
	let o = (i.indexOf(0) + 1) % i.length, s = n[e(r, a, 2)], c = n.find((e) => e !== s);
	return { state: {
		players: n,
		ring: i,
		neutral: o,
		pos: {
			[s]: 0,
			[c]: 0
		},
		onTop: s,
		buttons: {
			[s]: 5,
			[c]: 5
		},
		boards: {
			[s]: [],
			[c]: []
		},
		turn: s,
		pendingLeather: null,
		leatherIndex: 0,
		special7: null,
		finishedOrder: [],
		phase: "play"
	} };
}
function z(e, t, n) {
	let r = e.pos[t], i = Math.min(r + n, 53), a = 0, o = re(e.boards[t]);
	for (let e of T) e > r && e <= i && (a += o);
	e.buttons[t] += a, e.pos[t] = i, e.onTop = t;
	let s = !1;
	return e.leatherIndex < E.length && r < E[e.leatherIndex] && i >= E[e.leatherIndex] && (e.leatherIndex += 1, L(e.boards[t]) > 0 && (e.pendingLeather = t, s = !0)), i === 53 && !e.finishedOrder.includes(t) && e.finishedOrder.push(t), {
		incomeGain: a,
		leather: s
	};
}
function B(e) {
	if (e.pendingLeather) return;
	let [t, n] = e.players;
	if (e.pos[t] === 53 && e.pos[n] === 53) {
		e.phase = "done";
		return;
	}
	e.turn = e.pos[t] < e.pos[n] ? t : e.pos[n] < e.pos[t] ? n : e.onTop;
}
function ie(e, n, r) {
	if (e.phase !== "play") return { code: "games.patchwork.errNotYourTurn" };
	if (e.pendingLeather) {
		if (n.type !== "placeLeather" || r.by !== e.pendingLeather) return { code: "games.patchwork.errNotYourTurn" };
		let t = structuredClone(e);
		return P(t.boards[r.by])[n.y * 9 + n.x] === -1 ? (t.boards[r.by].push({
			pid: -1,
			x: n.x,
			y: n.y,
			rot: 0,
			flip: !1
		}), t.pendingLeather = null, !t.special7 && I(P(t.boards[r.by])) && (t.special7 = r.by), B(t), {
			state: t,
			fx: [{
				kind: "place",
				rid: r.by,
				data: {
					pid: -1,
					x: n.x,
					y: n.y
				}
			}]
		}) : { code: "games.patchwork.errBadPlacement" };
	}
	if (r.by !== e.turn) return { code: "games.patchwork.errNotYourTurn" };
	if (n.type === "advance") {
		let t = e.players.find((e) => e !== r.by), n = Math.min(e.pos[t] + 1, 53) - e.pos[r.by];
		if (n <= 0) return { code: "games.patchwork.errNotYourTurn" };
		let i = structuredClone(e);
		i.buttons[r.by] += n;
		let { incomeGain: a, leather: o } = z(i, r.by, n);
		B(i);
		let s = [{
			kind: "advance",
			rid: r.by,
			data: {
				spaces: n,
				buttons: n + a
			}
		}];
		return o && s.push({
			kind: "leather",
			rid: r.by,
			with: !0
		}), {
			state: i,
			fx: s
		};
	}
	if (n.type === "placeLeather") return { code: "games.patchwork.errNotYourTurn" };
	let i = Math.min(3, e.ring.length);
	if (n.choice >= i) return { code: "games.patchwork.errBadChoice" };
	let a = (e.neutral + n.choice) % e.ring.length, o = e.ring[a], s = w[o];
	if (e.buttons[r.by] < s.cost) return { code: "games.patchwork.errNoButtons" };
	let c = t(s.shape, n.rot, n.flip);
	if (!F(P(e.boards[r.by]), c, n.x, n.y)) return { code: "games.patchwork.errBadPlacement" };
	let l = structuredClone(e);
	l.buttons[r.by] -= s.cost, l.ring.splice(a, 1), l.neutral = l.ring.length > 0 ? a % l.ring.length : 0, l.boards[r.by].push({
		pid: o,
		x: n.x,
		y: n.y,
		rot: n.rot,
		flip: n.flip
	});
	let u = !l.special7 && I(P(l.boards[r.by]));
	u && (l.special7 = r.by);
	let { incomeGain: d, leather: f } = z(l, r.by, s.time);
	B(l);
	let p = [{
		kind: "place",
		rid: r.by,
		data: {
			pid: o,
			choice: n.choice,
			x: n.x,
			y: n.y,
			rot: n.rot,
			flip: n.flip
		}
	}];
	return d > 0 && p.push({
		kind: "income",
		rid: r.by,
		data: { n: d },
		with: !0
	}), f && p.push({
		kind: "leather",
		rid: r.by,
		with: !0
	}), u && p.push({
		kind: "bonus7",
		rid: r.by,
		with: !0
	}), {
		state: l,
		fx: p
	};
}
function V(e) {
	let t = {
		phase: e.phase,
		ring: e.ring,
		neutral: e.neutral,
		players: e.players.map((t) => ({
			rid: t,
			pos: e.pos[t],
			buttons: e.buttons[t],
			income: re(e.boards[t]),
			board: e.boards[t]
		})),
		turn: e.turn,
		onTop: e.onTop,
		pendingLeather: e.pendingLeather,
		leatherLeft: E.length - e.leatherIndex,
		special7: e.special7,
		finishedOrder: e.finishedOrder
	};
	return e.phase === "done" && (t.final = e.players.map((t) => {
		let n = L(e.boards[t]), r = e.special7 === t ? 7 : 0;
		return {
			rid: t,
			buttons: e.buttons[t],
			bonus7: r,
			empty: n,
			total: e.buttons[t] + r - 2 * n
		};
	})), {
		public: t,
		private: {}
	};
}
function H(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => e.buttons[t] + (e.special7 === t ? 7 : 0) - 2 * L(e.boards[t]), n = [...e.players].sort((n, r) => {
		let i = t(r) - t(n);
		return i === 0 ? e.finishedOrder.indexOf(n) - e.finishedOrder.indexOf(r) : i;
	}), r = {};
	for (let n of e.players) r[n] = t(n);
	return {
		phase: "done",
		winner: [n[0]],
		ranking: n,
		scores: r
	};
}
var ae = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: C,
	schemas: {
		action: O,
		publicView: M,
		privateView: N
	},
	setup: R,
	reduce: ie,
	viewFor: V,
	status: H
}, oe = "var(--color-pw-leather)";
function U({ cx: e, cy: t, r: n, fill: r = "var(--color-pw-gold)" }) {
	return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("circle", {
		cx: e,
		cy: t,
		r: n,
		fill: r,
		stroke: "var(--color-ink)",
		strokeWidth: n * .21
	}), [
		[-.28, -.28],
		[.28, -.28],
		[-.28, .28],
		[.28, .28]
	].map(([r, i], a) => /* @__PURE__ */ _("circle", {
		cx: e + r * n,
		cy: t + i * n,
		r: n * .12,
		fill: "var(--color-surface)"
	}, a))] });
}
function W(e, n, r) {
	let i = e < 0 ? [[0, 0]] : t(w[e].shape, n, r);
	return {
		cells: i,
		w: Math.max(...i.map((e) => e[0])) + 1,
		h: Math.max(...i.map((e) => e[1])) + 1
	};
}
function G({ pid: e, rot: t = 0, flip: n = !1, cell: i = 100, ghost: a = !1, invalid: o = !1 }) {
	let s = `pwfabric${r().replaceAll(":", "")}`, c = `pwinvalid${r().replaceAll(":", "")}`, { cells: l } = W(e, t, n), u = e < 0 ? oe : w[e].color, d = e < 0 ? 0 : w[e].income, f = i * .015, p = e < 0 ? 3 : e % 4, m = i * .32;
	return /* @__PURE__ */ v("g", {
		opacity: a ? .74 : 1,
		children: [
			/* @__PURE__ */ v("defs", { children: [/* @__PURE__ */ v("pattern", {
				id: s,
				width: m,
				height: m,
				patternUnits: "userSpaceOnUse",
				children: [
					p === 0 && /* @__PURE__ */ _("path", {
						d: `M0 0H${m}M0 ${m / 2}H${m}M0 0V${m}M${m / 2} 0V${m}`,
						stroke: "white",
						strokeWidth: i * .024,
						opacity: .36
					}),
					p === 1 && /* @__PURE__ */ _("path", {
						d: `M${m * .25} 0V${m}M${m * .75} 0V${m}`,
						stroke: "white",
						strokeWidth: i * .075,
						opacity: .27
					}),
					p === 2 && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("circle", {
						cx: m * .25,
						cy: m * .25,
						r: i * .045,
						fill: "white",
						opacity: .48
					}), /* @__PURE__ */ _("circle", {
						cx: m * .75,
						cy: m * .75,
						r: i * .045,
						fill: "white",
						opacity: .48
					})] }),
					p === 3 && /* @__PURE__ */ _("path", {
						d: `M0 ${m * .2}L${m * .25} ${m * .65}L${m * .5} ${m * .2}L${m * .75} ${m * .65}L${m} ${m * .2}`,
						fill: "none",
						stroke: "white",
						strokeWidth: i * .027,
						opacity: .38
					})
				]
			}), o && /* @__PURE__ */ _("pattern", {
				id: c,
				width: i * .2,
				height: i * .2,
				patternUnits: "userSpaceOnUse",
				patternTransform: "rotate(35)",
				children: /* @__PURE__ */ _("path", {
					d: `M${i * .1} 0V${i * .2}`,
					stroke: "var(--color-danger-ink)",
					strokeWidth: i * .065,
					opacity: .65
				})
			})] }),
			l.map(([e, t], n) => /* @__PURE__ */ v("g", { children: [
				/* @__PURE__ */ _("rect", {
					x: e * i + f,
					y: t * i + f,
					width: i - f * 2,
					height: i - f * 2,
					rx: i * .07,
					fill: u,
					className: "stroke-ink",
					strokeWidth: i * .045,
					strokeDasharray: a ? `${i * .12} ${i * .05}` : void 0
				}),
				/* @__PURE__ */ _("rect", {
					x: e * i + f * 2,
					y: t * i + f * 2,
					width: i - f * 4,
					height: i - f * 4,
					rx: i * .04,
					fill: `url(#${s})`
				}),
				o && /* @__PURE__ */ _("rect", {
					x: e * i + f * 2,
					y: t * i + f * 2,
					width: i - f * 4,
					height: i - f * 4,
					fill: `url(#${c})`
				}),
				/* @__PURE__ */ _("rect", {
					x: e * i + i * .14,
					y: t * i + i * .14,
					width: i * .72,
					height: i * .72,
					rx: i * .035,
					fill: "none",
					stroke: "var(--color-surface)",
					opacity: .74,
					strokeWidth: i * .022,
					strokeDasharray: `${i * .075} ${i * .055}`
				})
			] }, n)),
			d > 0 && Array.from({ length: d }, (e, t) => /* @__PURE__ */ _(U, {
				cx: l[0][0] * i + i * (.5 + (t - (d - 1) / 2) * .26),
				cy: l[0][1] * i + i * .5,
				r: i * .09
			}, t)),
			o && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("circle", {
				cx: l[0][0] * i + i * .5,
				cy: l[0][1] * i + i * .5,
				r: i * .21,
				fill: "var(--color-danger-soft)",
				stroke: "var(--color-danger-ink)",
				strokeWidth: i * .04
			}), /* @__PURE__ */ _("path", {
				d: `M${l[0][0] * i + i * .39} ${l[0][1] * i + i * .39}l${i * .22} ${i * .22}m0 -${i * .22}l-${i * .22} ${i * .22}`,
				stroke: "var(--color-danger-ink)",
				strokeWidth: i * .05,
				strokeLinecap: "round"
			})] })
		]
	});
}
//#endregion
//#region src/games/patchwork/view-player.tsx
var K = 100;
function q(e, t) {
	let n = [];
	for (let r = 0; r < 9; r++) for (let i = 0; i < 9; i++) F(e, t, i, r) && n.push({
		x: i,
		y: r
	});
	return n;
}
function se(e, n) {
	for (let r of [!1, !0]) for (let i = 0; i < 4; i++) if (q(n, t(w[e].shape, i, r)).length > 0) return !0;
	return !1;
}
function ce(e) {
	return e.reduce((e, t) => {
		if (!e) return t;
		let n = (e) => Math.abs(e.x - 3) + Math.abs(e.y - 3);
		return n(t) < n(e) ? t : e;
	}, null);
}
function le(e) {
	let { w: t, h: n } = W(e, 0, !1);
	return +(t > n + 1);
}
function J(e) {
	let t = e.public;
	return /* @__PURE__ */ _(ue, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ue({ pub: e, members: n, myRid: r, send: a }) {
	let c = u(), y = l((e) => e.locale), b = e.players.find((e) => e.rid === r), x = e.players.find((e) => e.rid !== r), [S, ne] = o(r), [T, E] = o(null), [D, O] = o(null), [k, A] = o(null), j = e.phase === "play" && e.turn === r && !e.pendingLeather, M = e.phase === "play" && e.pendingLeather === r, N = (j || M) && S === r && !!b, [I, re] = o(""), L = `${e.turn}:${e.pendingLeather ?? ""}:${S}:${e.ring.length}:${e.players.map((e) => e.board.length).join(",")}`;
	I !== L && (re(L), E(null), O(null), A(null));
	let R = i(() => {
		let t = Math.min(3, e.ring.length);
		return Array.from({ length: t }, (t, n) => e.ring[(e.neutral + n) % e.ring.length]);
	}, [e.ring, e.neutral]), z = e.players.find((e) => e.rid === S), B = i(() => z ? P(z.board) : [], [z]), ie = i(() => b ? P(b.board) : [], [b]), V = T && T.choice < R.length ? R[T.choice] : null, H = V !== null && T ? t(w[V].shape, T.rot, T.flip) : null, ae = N && j && H ? q(B, H) : [], oe = N && M ? B.flatMap((e, t) => e === -1 ? [{
		x: t % 9,
		y: Math.floor(t / 9)
	}] : []) : [], U = !!(N && j && H && D && F(B, H, D.x, D.y)), G = !!(N && M && k && B[k.y * 9 + k.x] === -1), K = b && x ? Math.min(x.pos + 1, 53) - b.pos : 0, J = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? h(t, y) : e;
	}, ue = (e) => p[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % p.length].hex, Y = (e, t, n) => {
		if (!(!N || e < 0 || t < 0 || e >= 9 || t >= 9)) {
			if (M) {
				B[t * 9 + e] === -1 && A({
					x: e,
					y: t
				});
				return;
			}
			if (j && T && V !== null) {
				if (n) {
					let { w: n, h: r } = W(V, T.rot, T.flip);
					O({
						x: Math.max(0, Math.min(8, e - Math.floor(n / 2))),
						y: Math.max(0, Math.min(8, t - r))
					});
				} else O({
					x: e,
					y: t
				});
			}
		}
	}, pe = (e, n) => {
		if (T?.choice === e) {
			E(null), O(null);
			return;
		}
		let r = {
			choice: e,
			rot: le(n),
			flip: !1
		}, i = ce(q(B, t(w[n].shape, r.rot, r.flip)));
		E(r), O(i);
	}, X = (e) => {
		if (!T || V === null) return;
		let n = e === "rotate" ? {
			...T,
			rot: (T.rot + 1) % 4
		} : {
			...T,
			flip: !T.flip
		}, r = t(w[V].shape, n.rot, n.flip), i = D && F(B, r, D.x, D.y) ? D : ce(q(B, r));
		E(n), O(i);
	}, Z = "info", Q;
	M ? (Z = "accent", Q = c("games.patchwork.stageLeather")) : e.pendingLeather ? Q = c("games.patchwork.waitLeather", { name: J(e.pendingLeather) }) : j ? (Z = "accent", Q = c("games.patchwork.stageYourTurn")) : Q = c("games.patchwork.waitTurn", { name: J(e.turn) });
	let he = z ? z.board.reduce((e, n) => e + (n.pid < 0 ? 1 : t(w[n.pid].shape, n.rot, n.flip).length), 0) : 0, ge = S === r ? c("games.patchwork.myQuilt") : c("games.patchwork.otherQuilt", { name: J(S) }), _e = e.special7 === S ? c("games.patchwork.bonusWon") : e.special7 ? c("games.patchwork.bonusTaken") : c("games.patchwork.bonusOpen"), $ = M ? c("games.patchwork.leatherHint") : T && V !== null ? U && b ? c("games.patchwork.placePreview", {
		buttons: b.buttons,
		after: b.buttons - w[V].cost,
		from: b.pos,
		to: Math.min(53, b.pos + w[V].time)
	}) : c("games.patchwork.chooseTarget") : c(j ? "games.patchwork.chooseOrAdvance" : "games.patchwork.watchHint");
	return /* @__PURE__ */ _("div", {
		className: "pw-screen",
		children: /* @__PURE__ */ _(m, {
			adaptive: !0,
			className: "pw-adaptive",
			scroll: !1,
			actionsHeight: "pw-actions-height",
			banner: /* @__PURE__ */ v("div", {
				className: "pw-banner",
				children: [/* @__PURE__ */ _("div", {
					className: "pw-phase",
					children: /* @__PURE__ */ _(ee, {
						tone: Z,
						text: c("games.patchwork.name"),
						sub: Q,
						chip: c("games.patchwork.leftShort", { n: e.ring.length }),
						accent: C.accent
					})
				}), /* @__PURE__ */ _("div", {
					className: "pw-players",
					children: /* @__PURE__ */ _(te, {
						members: n.filter((t) => e.players.some((e) => e.rid === t.rid)),
						myRid: r,
						variant: "plate",
						anchorOf: (e) => `seat:${e}`,
						action: (t) => e.phase === "play" && (t === e.turn || t === e.pendingLeather) ? "pending" : null,
						onPick: ne,
						picked: (e) => S === e,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ v(g, { children: [
								/* @__PURE__ */ v("span", {
									className: "pw-player-stat",
									"aria-label": c("games.patchwork.buttonsAria", { n: n.buttons }),
									children: ["🔘 ", /* @__PURE__ */ _(s, {
										value: n.buttons,
										className: "font-mono tabular-nums"
									})]
								}),
								/* @__PURE__ */ v("span", {
									className: "pw-player-stat pw-player-stat--income",
									"aria-label": c("games.patchwork.incomeAria", { n: n.income }),
									children: ["🧵 +", n.income]
								}),
								/* @__PURE__ */ v("span", {
									className: "pw-player-stat font-mono tabular-nums",
									"aria-label": c("games.patchwork.positionAria", { n: n.pos }),
									children: [
										n.pos,
										"/",
										53
									]
								})
							] }) : null;
						}
					})
				})]
			}),
			actions: /* @__PURE__ */ v("div", {
				className: "pw-actions",
				children: [/* @__PURE__ */ _("p", { children: $ }), /* @__PURE__ */ _("div", {
					className: "pw-action-row",
					children: M ? /* @__PURE__ */ _("button", {
						type: "button",
						disabled: !G,
						onClick: () => {
							a({
								type: "placeLeather",
								x: k.x,
								y: k.y
							}), A(null);
						},
						className: "btn-base flex-1 text-white",
						style: { background: C.accent },
						children: c("games.patchwork.leatherConfirm")
					}) : T ? /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ v("button", {
							type: "button",
							className: "pw-action-icon",
							"aria-label": c("games.patchwork.rotate"),
							onClick: () => X("rotate"),
							children: [/* @__PURE__ */ _(f, {
								size: 22,
								"aria-hidden": !0
							}), /* @__PURE__ */ _("span", { children: c("games.patchwork.rotate") })]
						}),
						/* @__PURE__ */ v("button", {
							type: "button",
							className: "pw-action-icon",
							"aria-label": c("games.patchwork.flip"),
							onClick: () => X("flip"),
							children: [/* @__PURE__ */ _(d, {
								size: 22,
								"aria-hidden": !0
							}), /* @__PURE__ */ _("span", { children: c("games.patchwork.flip") })]
						}),
						/* @__PURE__ */ _("button", {
							type: "button",
							disabled: !U,
							onClick: () => {
								a({
									type: "buy",
									choice: T.choice,
									x: D.x,
									y: D.y,
									rot: T.rot,
									flip: T.flip
								}), E(null), O(null);
							},
							className: "btn-base flex-1 text-white",
							style: { background: C.accent },
							children: c("games.patchwork.buyConfirm")
						})
					] }) : j ? /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => a({ type: "advance" }),
						className: "btn-quiet flex-1",
						children: c("games.patchwork.advance", { n: K })
					}) : /* @__PURE__ */ _("span", { className: "flex-1" })
				})]
			}),
			children: /* @__PURE__ */ _("div", {
				className: "pw-table-scroll",
				children: /* @__PURE__ */ v("div", {
					className: "pw-table",
					children: [
						/* @__PURE__ */ _(fe, {
							board: z?.board ?? [],
							label: ge,
							count: he,
							bonus: _e,
							awarded: e.special7 === S,
							ghost: N && j && V !== null && T && D ? {
								pid: V,
								x: D.x,
								y: D.y,
								rot: T.rot,
								flip: T.flip,
								valid: U
							} : null,
							leatherGhost: N && M ? k : null,
							targets: M ? oe : ae,
							leatherTargets: M,
							onTap: N ? (e, t) => Y(e, t, !1) : void 0,
							onDrag: N ? (e, t) => Y(e, t, !0) : void 0,
							viewRid: S
						}),
						/* @__PURE__ */ _(me, {
							pub: e,
							myRid: r,
							colorOf: ue
						}),
						/* @__PURE__ */ v("section", {
							className: "pw-market",
							"aria-label": c("games.patchwork.marketTitle"),
							children: [/* @__PURE__ */ v("div", {
								className: "pw-market-head",
								children: [/* @__PURE__ */ _("strong", { children: c("games.patchwork.marketTitle") }), /* @__PURE__ */ _("span", { children: c(T ? "games.patchwork.marketSelected" : "games.patchwork.marketHint") })]
							}), /* @__PURE__ */ v("div", {
								className: "pw-piece-row",
								style: { "--pw-piece-count": Math.max(1, R.length) },
								children: [R.map((e, t) => {
									let n = w[e], i = (b?.buttons ?? 0) >= n.cost, a = se(e, ie), o = T?.choice === t;
									return /* @__PURE__ */ v("button", {
										type: "button",
										className: "pw-piece-card",
										"data-selected": o,
										"data-unaffordable": !i,
										"data-no-fit": !a,
										"aria-label": c("games.patchwork.pieceAria", {
											n: t + 1,
											cost: n.cost,
											time: n.time,
											income: n.income
										}),
										disabled: !j || S !== r || !i || !a,
										onClick: () => pe(t, e),
										children: [
											/* @__PURE__ */ _("span", {
												className: "pw-piece-number",
												children: String(t + 1).padStart(2, "0")
											}),
											t === 0 && /* @__PURE__ */ _("span", {
												className: "pw-neutral-pin",
												"aria-label": c("games.patchwork.neutralPin"),
												children: "✦"
											}),
											o && /* @__PURE__ */ _("span", {
												className: "pw-piece-ribbon",
												children: c("games.patchwork.selected")
											}),
											!i && /* @__PURE__ */ _("span", {
												className: "pw-piece-unavailable",
												children: c("games.patchwork.cannotAfford")
											}),
											i && !a && /* @__PURE__ */ _("span", {
												className: "pw-piece-unavailable",
												children: c("games.patchwork.noRoom")
											}),
											/* @__PURE__ */ _("span", {
												className: "pw-piece-preview",
												children: /* @__PURE__ */ _(de, { pid: e })
											}),
											/* @__PURE__ */ v("span", {
												className: "pw-piece-costs",
												children: [
													/* @__PURE__ */ v("span", { children: ["🔘", n.cost] }),
													/* @__PURE__ */ v("span", { children: ["◷", n.time] }),
													/* @__PURE__ */ v("span", { children: ["🟡+", n.income] })
												]
											})
										]
									}, e);
								}), R.length === 0 && /* @__PURE__ */ _("p", {
									className: "self-center text-xs font-bold",
									children: c("games.patchwork.noPieces")
								})]
							})]
						})
					]
				})
			})
		})
	});
}
function de({ pid: e }) {
	let t = le(e), { w: n, h: r } = W(e, t, !1), i = Math.min(18, 76 / n, 54 / r);
	return /* @__PURE__ */ _("svg", {
		viewBox: `0 0 ${n * i} ${r * i}`,
		style: {
			"--pw-preview-width": `${n * i}px`,
			"--pw-preview-height": `${r * i}px`,
			"--pw-preview-ratio": n / r
		},
		"aria-hidden": !0,
		children: /* @__PURE__ */ _(G, {
			pid: e,
			rot: t,
			cell: i
		})
	});
}
function Y({ board: e, ghost: t, leatherGhost: n, targets: i = [], leatherTargets: a = !1 }) {
	let o = `pwquilt${r().replaceAll(":", "")}`, s = new Set([...i].sort((e, n) => {
		let r = (e) => Math.abs(e.x - (t?.x ?? 3)) + Math.abs(e.y - (t?.y ?? 3));
		return r(e) - r(n);
	}).slice(0, 6).map((e) => `${e.x}-${e.y}`));
	return /* @__PURE__ */ v(g, { children: [
		/* @__PURE__ */ _("defs", { children: /* @__PURE__ */ _("pattern", {
			id: o,
			width: "24",
			height: "24",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ _("path", {
				d: "M0 0H24M0 12H24M0 0V24M12 0V24",
				fill: "none",
				stroke: "var(--color-pw-binding-light)",
				strokeWidth: "1.1",
				opacity: ".22"
			})
		}) }),
		Array.from({ length: 81 }, (e, t) => {
			let n = t % 9, r = Math.floor(t / 9);
			return /* @__PURE__ */ v("g", { children: [/* @__PURE__ */ _("rect", {
				x: n * K,
				y: r * K,
				width: K,
				height: K,
				fill: (n + r) % 2 ? "var(--color-pw-quilt-b)" : "var(--color-pw-quilt-a)",
				stroke: "var(--color-pw-binding-light)",
				strokeWidth: 2
			}), /* @__PURE__ */ _("rect", {
				x: n * K,
				y: r * K,
				width: K,
				height: K,
				fill: `url(#${o})`
			})] }, t);
		}),
		i.map(({ x: e, y: t }) => a ? /* @__PURE__ */ _("g", {
			pointerEvents: "none",
			children: /* @__PURE__ */ _("rect", {
				x: e * K + 12,
				y: t * K + 12,
				width: 76,
				height: 76,
				rx: 8,
				fill: "var(--color-pw-accent-soft)",
				opacity: .55,
				stroke: "var(--color-pw-accent-dark)",
				strokeWidth: 4,
				strokeDasharray: "9 7"
			})
		}, `${e}-${t}`) : s.has(`${e}-${t}`) ? /* @__PURE__ */ v("g", {
			pointerEvents: "none",
			children: [/* @__PURE__ */ _("circle", {
				cx: e * K + K / 2,
				cy: t * K + K / 2,
				r: 23,
				fill: "var(--color-pw-cream)",
				opacity: .82,
				stroke: "var(--color-pw-accent-dark)",
				strokeWidth: 5,
				strokeDasharray: "8 7"
			}), /* @__PURE__ */ _("path", {
				d: `M${e * K + 38} ${t * K + 50}h24M${e * K + 50} ${t * K + 38}v24`,
				stroke: "var(--color-pw-accent-dark)",
				strokeWidth: 5,
				strokeLinecap: "round"
			})]
		}, `${e}-${t}`) : /* @__PURE__ */ _("circle", {
			cx: e * K + K / 2,
			cy: t * K + K / 2,
			r: 12,
			fill: "var(--color-pw-accent-soft)",
			opacity: .34,
			pointerEvents: "none"
		}, `${e}-${t}`)),
		e.map((e, t) => /* @__PURE__ */ _("g", {
			transform: `translate(${e.x * K}, ${e.y * K})`,
			children: /* @__PURE__ */ _(G, {
				pid: e.pid,
				rot: e.rot,
				flip: e.flip,
				cell: K
			})
		}, t)),
		t && /* @__PURE__ */ _("g", {
			transform: `translate(${t.x * K}, ${t.y * K})`,
			children: /* @__PURE__ */ _(G, {
				pid: t.pid,
				rot: t.rot,
				flip: t.flip,
				cell: K,
				ghost: !0,
				invalid: !t.valid
			})
		}),
		n && /* @__PURE__ */ _("g", {
			transform: `translate(${n.x * K}, ${n.y * K})`,
			children: /* @__PURE__ */ _(G, {
				pid: -1,
				cell: K,
				ghost: !0
			})
		})
	] });
}
function fe({ board: e, label: t, count: n, bonus: r, awarded: i, ghost: o, leatherGhost: s, targets: l, leatherTargets: d, onTap: f, onDrag: p, viewRid: m }) {
	let ee = u(), { ref: te } = c(`board:${m}`), h = a(null), g = a(null), y = (e) => {
		let t = h.current;
		if (!t) return null;
		let n = t.getBoundingClientRect(), r = Math.floor((e.clientX - n.left) / n.width * 9), i = Math.floor((e.clientY - n.top) / n.height * 9);
		return r >= 0 && r < 9 && i >= 0 && i < 9 ? {
			x: r,
			y: i
		} : null;
	};
	return /* @__PURE__ */ v("section", {
		className: "pw-quilt-panel",
		"aria-label": t,
		children: [/* @__PURE__ */ v("header", {
			className: "pw-quilt-head",
			children: [
				/* @__PURE__ */ _("strong", { children: t }),
				/* @__PURE__ */ _("span", {
					className: "pw-quilt-count",
					children: ee("games.patchwork.filledCount", { n })
				}),
				/* @__PURE__ */ _("span", {
					className: "pw-bonus",
					"data-awarded": i,
					children: r
				})
			]
		}), /* @__PURE__ */ _("div", {
			className: "pw-quilt-stage",
			children: /* @__PURE__ */ _("div", {
				className: "pw-quilt-canvas",
				"data-interactive": !!f,
				children: /* @__PURE__ */ _("div", {
					ref: te,
					className: "pw-quilt-art",
					children: /* @__PURE__ */ _("svg", {
						ref: h,
						viewBox: `0 0 ${9 * K} ${9 * K}`,
						"aria-label": ee("games.patchwork.quiltAria", { n }),
						onPointerDown: f ? (e) => {
							e.currentTarget.setPointerCapture(e.pointerId), g.current = {
								x: e.clientX,
								y: e.clientY,
								moved: !1
							};
						} : void 0,
						onPointerMove: p ? (e) => {
							if (g.current && (Math.abs(e.clientX - g.current.x) + Math.abs(e.clientY - g.current.y) > 7 && (g.current.moved = !0), g.current.moved)) {
								let t = y(e);
								t && p(t.x, t.y);
							}
						} : void 0,
						onPointerUp: f ? (e) => {
							let t = g.current?.moved;
							if (g.current = null, !t) {
								let t = y(e);
								t && f(t.x, t.y);
							}
						} : void 0,
						onPointerCancel: f ? () => {
							g.current = null;
						} : void 0,
						children: /* @__PURE__ */ _(Y, {
							board: e,
							ghost: o,
							leatherGhost: s,
							targets: l,
							leatherTargets: d
						})
					})
				})
			})
		})]
	});
}
function pe({ rid: e, pos: t, color: n, overlap: r, top: i }) {
	let { ref: a } = c(`time:${e}`);
	return /* @__PURE__ */ _("span", {
		ref: a,
		className: "pw-time-token",
		"data-overlap": r,
		"data-top": i,
		style: {
			left: `${t / 53 * 100}%`,
			background: n
		}
	});
}
function me({ pub: e, myRid: t, colorOf: n }) {
	let r = u(), i = e.players.find((e) => e.rid === t)?.pos ?? 0, a = e.players.find((e) => e.rid !== t)?.pos ?? 0, o = e.players.find((t) => t.rid === (e.pendingLeather ?? e.turn))?.pos ?? i, s = Math.max(0, Math.min(45, o - 2)), c = e.players.length === 2 && e.players[0].pos === e.players[1].pos, l = E.length - e.leatherLeft;
	return /* @__PURE__ */ v("section", {
		className: "pw-time",
		"aria-label": r("games.patchwork.timeRuler"),
		children: [
			/* @__PURE__ */ v("div", {
				className: "pw-time-head",
				children: [/* @__PURE__ */ _("strong", { children: r("games.patchwork.timeRuler") }), /* @__PURE__ */ _("span", { children: r("games.patchwork.positions", {
					me: i,
					other: a
				}) })]
			}),
			/* @__PURE__ */ v("div", {
				className: "pw-time-overview",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ _("span", {
					className: "pw-time-progress",
					style: { width: `${Math.min(i, a) / 53 * 100}%` }
				}), e.players.map((t) => /* @__PURE__ */ _(pe, {
					rid: t.rid,
					pos: t.pos,
					color: n(t.rid),
					overlap: c,
					top: t.rid === e.onTop
				}, t.rid))]
			}),
			/* @__PURE__ */ _("div", {
				className: "pw-time-ticks",
				children: Array.from({ length: 9 }, (i, a) => {
					let o = s + a, c = T.includes(o) ? "income" : E.includes(o) ? "leather" : void 0, u = E.indexOf(o), d = u >= 0 && u < l;
					return /* @__PURE__ */ v("div", {
						className: "pw-time-tick",
						"data-event": c,
						"data-used": d,
						"aria-label": r(c === "income" ? "games.patchwork.incomeSpace" : c === "leather" ? "games.patchwork.leatherSpace" : "games.patchwork.positionAria", { n: o }),
						children: [
							/* @__PURE__ */ _("span", {
								className: "pw-time-number",
								children: o
							}),
							c === "income" && /* @__PURE__ */ _("span", {
								className: "pw-time-event pw-time-event--button",
								"aria-hidden": !0
							}),
							c === "leather" && !d && /* @__PURE__ */ _("span", {
								className: "pw-time-event pw-time-event--leather",
								"aria-hidden": !0
							}),
							e.players.filter((e) => e.pos === o).map((e, i) => /* @__PURE__ */ _("span", {
								className: "pw-time-piece",
								style: {
									background: n(e.rid),
									right: `calc(2px + ${i} * var(--pw-time-marker-step, 7px))`
								},
								"aria-label": e.rid === t ? r("games.patchwork.meShort") : r("games.patchwork.otherShort"),
								children: e.rid === t ? r("games.patchwork.meShort") : r("games.patchwork.otherShort")
							}, e.rid))
						]
					}, o);
				})
			})
		]
	});
}
//#endregion
//#region src/games/patchwork/bot.ts
function X() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Z(e) {
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i of [!1, !0]) for (let a = 0; a < 4; a++) {
		let o = t(w[e].shape, a, i), s = o.map((e) => e.join(",")).join("|");
		n.has(s) || (n.add(s), r.push({
			cells: o,
			rot: a,
			flip: i
		}));
	}
	return r;
}
function Q(e, t, n, r) {
	let i = 0;
	for (let [a, o] of t) for (let [t, s] of [
		[1, 0],
		[-1, 0],
		[0, 1],
		[0, -1]
	]) {
		let c = n + a + t, l = r + o + s;
		c < 0 || c >= 9 || l < 0 || l >= 9 ? i += .5 : e[l * 9 + c] !== -1 && (i += 1);
	}
	return i;
}
var he = (e, t) => {
	let n = e.public;
	if (n.phase !== "play") return null;
	let r = n.players.find((e) => e.rid === t.rid), i = n.players.find((e) => e.rid !== t.rid);
	if (!r || !i) return null;
	let a = b(y(t.rid)), o = t.difficulty === "weak", s = P(r.board);
	if (n.pendingLeather === t.rid) {
		let e = null;
		for (let t = 0; t < 9; t++) for (let n = 0; n < 9; n++) {
			if (s[t * 9 + n] !== -1) continue;
			let r = Q(s, [[0, 0]], n, t);
			(!e || r > e.n) && (e = {
				x: n,
				y: t,
				n: r
			});
		}
		return e ? { action: {
			type: "placeLeather",
			x: e.x,
			y: e.y
		} } : null;
	}
	if (n.turn !== t.rid) return null;
	let c = T.filter((e) => e > r.pos).length, l = () => (X() - .5) * a.noise * 2, u = null, d = Math.min(3, n.ring.length);
	for (let e = 0; e < d; e++) {
		let t = n.ring[(n.neutral + e) % n.ring.length], i = w[t];
		if (i.cost > r.buttons) continue;
		let a = i.shape.flat().filter(Boolean).length * 2 + i.income * c - i.cost - i.time * .8;
		for (let n of Z(t)) for (let t = 0; t < 9; t++) for (let r = 0; r < 9; r++) {
			if (!F(s, n.cells, r, t)) continue;
			let i = o ? X() * 10 : a + Q(s, n.cells, r, t) * .3 + l();
			(!u || i > u.score) && (u = {
				action: {
					type: "buy",
					choice: e,
					x: r,
					y: t,
					rot: n.rot,
					flip: n.flip
				},
				score: i
			});
		}
	}
	let f = Math.min(i.pos + 1, 53), p = f - r.pos;
	for (let e of T) e > r.pos && e <= f && (p += r.income);
	return !u || !o && u.score < p * 1 ? { action: { type: "advance" } } : { action: u.action };
}, ge = (e, t, n) => {
	if (e.type === "placeLeather") return n("games.patchwork.leatherConfirm");
	if (e.type === "advance") return n("games.patchwork.hintAdvance");
	let r = w[t.public.ring[(t.public.neutral + e.choice) % t.public.ring.length]];
	return n("games.patchwork.hintBuy", {
		cost: r.cost,
		time: r.time
	});
};
//#endregion
//#region src/games/patchwork/fx.tsx
function _e(e, t, n, r, i) {
	let a = Math.min(e.w, e.h), o = e.x + (e.w - a) / 2, s = e.y + (e.h - a) / 2, c = a / 9;
	return {
		x: o + t * c,
		y: s + n * c,
		w: r * c,
		h: i * c
	};
}
function $(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
var ve = {
	place(e, t) {
		let n = e.data;
		if (typeof n?.pid != "number" || typeof n.x != "number" || typeof n.y != "number") return null;
		let r = e.rid ? t.anchor(`board:${e.rid}`) : null;
		if (!r) return null;
		let { w: i, h: a } = W(n.pid, typeof n.rot == "number" ? n.rot : 0, n.flip === !0);
		return {
			ms: 500,
			node: /* @__PURE__ */ _(S, {
				at: _e(r, n.x, n.y, i, a),
				ms: 500
			})
		};
	},
	income(e, t) {
		let n = e.data, r = $(t, e.rid);
		return typeof n?.n != "number" || !r ? null : {
			ms: 800,
			node: /* @__PURE__ */ _(x, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ v("span", { children: [
					"+",
					n.n,
					" 🔘"
				] })
			})
		};
	},
	advance(e, t) {
		let n = e.data, r = $(t, e.rid);
		return typeof n?.buttons != "number" || !r ? null : {
			ms: 800,
			node: /* @__PURE__ */ _(x, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ v("span", { children: [
					"+",
					n.buttons,
					" 🔘"
				] })
			})
		};
	},
	leather(e, t) {
		let n = (e.rid ? t.anchor(`time:${e.rid}`) : null) ?? $(t, e.rid);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ _(x, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ _("span", { children: "🟫" })
			})
		} : null;
	},
	bonus7(e, t) {
		let n = $(t, e.rid);
		return n ? {
			ms: 1100,
			node: /* @__PURE__ */ _(x, {
				at: n,
				ms: 1100,
				children: /* @__PURE__ */ _("span", { children: "⭐ +7" })
			})
		} : null;
	}
};
//#endregion
//#region src/games/patchwork/game-over.tsx
function ye({ final: e, pub: t, won: n, place: r, name: i }) {
	let a = u(), o = t.players.find((t) => t.rid === e.rid)?.board ?? [], s = [
		{
			label: a("games.patchwork.scoreButtons"),
			value: e.buttons
		},
		{
			label: a("games.patchwork.scoreBonus7"),
			value: e.bonus7
		},
		{
			label: a("games.patchwork.scoreEmpty", { n: e.empty }),
			value: -2 * e.empty
		}
	];
	return /* @__PURE__ */ v("section", {
		className: "pw-over-card",
		"data-won": n,
		children: [
			/* @__PURE__ */ v("header", {
				className: "pw-over-player",
				children: [
					/* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						className: `pw-over-trophy ${n ? "" : "invisible"}`,
						children: "🏆"
					}),
					/* @__PURE__ */ v("span", {
						className: "pw-over-name",
						children: [
							r,
							". ",
							i
						]
					}),
					/* @__PURE__ */ _("span", {
						className: "pw-over-total font-mono tabular-nums",
						children: e.total
					})
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "pw-over-quilt",
				children: /* @__PURE__ */ _("svg", {
					viewBox: "0 0 900 900",
					"aria-hidden": !0,
					children: /* @__PURE__ */ _(Y, { board: o })
				})
			}),
			/* @__PURE__ */ _("ul", {
				className: "pw-over-scores",
				children: s.map((e, t) => /* @__PURE__ */ v("li", {
					className: e.value === 0 ? "opacity-60" : void 0,
					children: [/* @__PURE__ */ _("span", { children: e.label }), /* @__PURE__ */ _("span", {
						className: "font-mono tabular-nums",
						children: e.value > 0 ? `+${e.value}` : e.value
					})]
				}, t))
			})
		]
	});
}
function be({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = u(), o = l((e) => e.locale), s = t, c = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? h(t, o) : e;
	}, d = r ?? i;
	return /* @__PURE__ */ v("div", {
		className: "pw-over",
		children: [e.winner.length > 0 && /* @__PURE__ */ _(ne, {}), /* @__PURE__ */ v("div", {
			className: "pw-over-layout",
			children: [
				/* @__PURE__ */ v("h1", {
					className: "pw-over-title font-display",
					children: [/* @__PURE__ */ _("span", {
						"aria-hidden": !0,
						children: C.icon
					}), a("session.result.title")]
				}),
				/* @__PURE__ */ _("div", {
					className: "pw-over-players",
					children: e.ranking.map((t, n) => {
						let r = s.final?.find((e) => e.rid === t);
						return r ? /* @__PURE__ */ _(ye, {
							final: r,
							pub: s,
							won: e.winner.includes(t),
							place: n + 1,
							name: c(t)
						}, t) : null;
					})
				}),
				d ? /* @__PURE__ */ v("div", {
					className: "pw-over-controls safe-b",
					children: [r && /* @__PURE__ */ _("button", {
						className: "btn-base pw-over-again",
						onClick: r,
						children: a("session.result.playAgain")
					}), i && /* @__PURE__ */ _("button", {
						className: "btn-base pw-over-back",
						onClick: i,
						children: a("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ _("p", {
					className: "pw-over-wait safe-b",
					children: a("session.result.waitHost")
				})
			]
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/patchwork/entry.tsx
var xe = {
	definition: ae,
	View: J,
	bot: he,
	describe: ge,
	fx: ve,
	OverView: be,
	locales: {
		zh: {
			name: "拼布艺术",
			desc: "双人对决:买补丁、缝被子,纽扣省着花",
			rules: "目标:双方各自缝制一床 9 格见方的被子;终局得分 = 剩余纽扣 − 每个空格扣 2 分,分高者胜。\n回合:\n· 时间轨上落后的一方行动(可能连续行动);同格时后到的一方先动。\n行动(二选一):\n· 买补丁:从中立标记起顺时针的前 3 块中选 1 块,支付纽扣并缝到被子上。\n· 补丁可旋转、翻面,不可重叠;放下后时间标记前进补丁标注的格数。\n· 前进:跳到对手的前一格,每前进 1 格获得 1 枚纽扣。\n时间轨:\n· 经过纽扣格:按被子上印的纽扣总数领取纽扣。\n· 经过皮革格:获得单格皮革补丁并立即补上(共 5 块,先到先得)。\n· 首个拼出完整 7 格见方区域的玩家获得 7 分奖励牌。\n结束:\n· 双方都抵达终点后结算;平分则先抵达者胜。",
			leftShort: "剩 {{n}} 块",
			stageYourTurn: "轮到你：买补丁或推进时间",
			stageLeather: "把皮革补丁缝到被面上",
			waitTurn: "等 {{name}} 行动…",
			waitLeather: "等 {{name}} 补皮革…",
			watchHint: "等待对手，先看看两床被面",
			buttonsAria: "{{n}} 枚纽扣",
			incomeAria: "每次领薪 +{{n}} 枚纽扣",
			pieceAria: "第 {{n}} 块补丁，花 {{cost}} 纽扣，耗 {{time}} 时间，收入 +{{income}}",
			myQuilt: "我的被面",
			otherQuilt: "{{name}} 的被面",
			filledCount: "已缝 {{n}} / 81 格",
			quiltAria: "九乘九被面，已缝 {{n}} 格",
			bonusOpen: "☆ 7×7 奖励",
			bonusWon: "★ 已获 +7",
			bonusTaken: "☆ 奖励已领",
			positionAria: "时间第 {{n}} 格",
			timeRuler: "时间布尺",
			positions: "我 {{me}} / 对手 {{other}}",
			incomeSpace: "时间第 {{n}} 格：纽扣收入",
			leatherSpace: "时间第 {{n}} 格：皮革补丁",
			meShort: "我",
			otherShort: "对",
			marketTitle: "补丁托盘",
			marketHint: "中立针起，顺时针选 1 块",
			marketSelected: "已选补丁，可旋转或翻面",
			neutralPin: "中立标记",
			selected: "已选中",
			cannotAfford: "纽扣不足",
			noRoom: "无处可缝",
			leatherHint: "点按被面的空格，补上皮革",
			chooseTarget: "点按或拖动到可缝位置",
			chooseOrAdvance: "选择补丁缝上，或跳到对手前一格",
			placePreview: "纽扣 {{buttons}} → {{after}} · 时间 {{from}} → {{to}}",
			noPieces: "补丁已拿完",
			rotate: "旋转",
			flip: "翻面",
			buyConfirm: "把补丁缝上",
			leatherConfirm: "补上皮革",
			advance: "推进时间 · 获得 {{n}} 枚纽扣",
			errNotYourTurn: "还没轮到你",
			errNoButtons: "纽扣不够",
			errBadPlacement: "这里缝不下这块补丁",
			scoreButtons: "剩余纽扣",
			scoreBonus7: "7×7 奖励牌",
			scoreEmpty: "空格 ×{{n}}",
			errBadChoice: "只能选中立标记前的 3 块",
			hintBuy: "买下这块补丁({{cost}} 纽扣 · {{time}} 时间)缝到被子上",
			hintAdvance: "跳到对手前一格,顺路领纽扣"
		},
		en: {
			name: "Patchwork",
			desc: "A two-player duel: buy patches, sew your quilt, spend buttons wisely",
			rules: "Goal: each player sews a 9×9 quilt. Final score = buttons left − 2 per empty space; highest wins.\nTurns:\n· The player behind on the time track acts (possibly several turns in a row); on the same space, the last to arrive goes first.\nActions — pick one:\n· Buy a patch: choose 1 of the 3 patches clockwise from the neutral token, pay buttons, and sew it onto your quilt.\n· Patches may be rotated and flipped but not overlapped; after placing, advance your time token by the patch's time cost.\n· Advance: jump to the space right in front of your opponent and gain 1 button per space moved.\nTime track:\n· Passing a button space: collect income equal to the buttons printed on your quilt.\n· Passing a leather space: take the single-cell leather patch and place it immediately (5 total, first come).\n· The first player to complete a solid 7×7 area gets the 7-point bonus tile.\nEnd:\n· Once both reach the final space, scores are settled; a tie goes to the player who arrived first.",
			leftShort: "{{n}} left",
			stageYourTurn: "Your turn: buy a patch or advance time",
			stageLeather: "Sew the leather patch onto your quilt",
			waitTurn: "Waiting for {{name}}…",
			waitLeather: "Waiting for {{name}} to place leather…",
			watchHint: "Waiting for your rival. Browse both quilts.",
			buttonsAria: "{{n}} buttons",
			incomeAria: "+{{n}} buttons per payday",
			pieceAria: "Patch {{n}}: {{cost}} buttons, {{time}} time, +{{income}} income",
			myQuilt: "My quilt",
			otherQuilt: "{{name}}'s quilt",
			filledCount: "{{n}} / 81 sewn",
			quiltAria: "Nine by nine quilt, {{n}} spaces filled",
			bonusOpen: "☆ 7×7 bonus",
			bonusWon: "★ Won +7",
			bonusTaken: "☆ Bonus taken",
			positionAria: "Time space {{n}}",
			timeRuler: "Time ruler",
			positions: "Me {{me}} / rival {{other}}",
			incomeSpace: "Time space {{n}}: button income",
			leatherSpace: "Time space {{n}}: leather patch",
			meShort: "M",
			otherShort: "R",
			marketTitle: "Patch tray",
			marketHint: "Choose 1 of 3 from the neutral pin",
			marketSelected: "Patch selected: rotate or flip",
			neutralPin: "Neutral marker",
			selected: "Selected",
			cannotAfford: "Not enough",
			noRoom: "No space",
			leatherHint: "Tap an empty quilt space for leather",
			chooseTarget: "Tap or drag to a valid space",
			chooseOrAdvance: "Choose a patch or advance past your rival",
			placePreview: "Buttons {{buttons}} → {{after}} · time {{from}} → {{to}}",
			noPieces: "No patches left",
			rotate: "Rotate",
			flip: "Flip",
			buyConfirm: "Sew on patch",
			leatherConfirm: "Place leather",
			advance: "Advance time · gain {{n}} 🔘",
			errNotYourTurn: "Not your turn",
			errNoButtons: "Not enough buttons",
			errBadPlacement: "This patch doesn't fit here",
			scoreButtons: "Buttons left",
			scoreBonus7: "7×7 bonus tile",
			scoreEmpty: "Empty spaces ×{{n}}",
			errBadChoice: "Only the 3 patches ahead of the neutral token",
			hintBuy: "Buy this patch ({{cost}} buttons · {{time}} time) and sew it on",
			hintAdvance: "Hop past your opponent and collect buttons"
		}
	}
};
//#endregion
export { xe as default };
