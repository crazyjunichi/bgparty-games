import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { botAvatarOf as a } from "@bgparty/sdk/lobby";
import { AVATARS as o } from "@bgparty/sdk/avatars";
import { BottomSheet as s } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as l, useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { IconCheck as f, IconEffect as p, IconFlood as m, IconListen as ee, IconMove as h, IconShoot as g, IconTrap as _ } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as v } from "@bgparty/sdk/player-colors";
import { Texture as te } from "@bgparty/sdk/texture";
import { GameScreen as ne } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as re, rich as y } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as ie } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as ae } from "@bgparty/sdk/ui/player-strip";
import { Fragment as b, jsx as x, jsxs as S } from "react/jsx-runtime";
import { FlySprite as C, PulseBox as w } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as oe } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/revolvernoir/meta.ts
var se = {
	id: "revolvernoir",
	tier: "beta",
	mechanics: ["deduction", "action-points"],
	interactionTags: [],
	nameKey: "games.revolvernoir.name",
	descKey: "games.revolvernoir.desc",
	rulesKey: "games.revolvernoir.rules",
	icon: "🕵️",
	iconImg: "games/revolvernoir.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/revolvernoir/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#334155",
	releasedAt: "2026-10-01",
	search: {
		py: "hei se zuo lun",
		init: "hszl"
	},
	hotseat: "cover"
}, T = [
	"bedroom",
	"hall",
	"library",
	"balcony",
	"kitchen",
	"dining",
	"foyer",
	"basement"
], E = [
	"bedroom",
	"hall",
	"library",
	"balcony"
], D = {
	basement: [
		"foyer",
		"dining",
		"library"
	],
	bedroom: ["hall", "kitchen"],
	dining: [
		"foyer",
		"kitchen",
		"basement"
	],
	foyer: [
		"balcony",
		"basement",
		"kitchen",
		"dining"
	],
	hall: [
		"balcony",
		"bedroom",
		"library"
	],
	kitchen: [
		"bedroom",
		"dining",
		"foyer"
	],
	library: ["hall", "basement"],
	balcony: ["hall", "foyer"]
}, O = {
	basement: [
		"basement",
		"foyer",
		"dining"
	],
	bedroom: [
		"bedroom",
		"hall",
		"balcony"
	],
	dining: [
		"dining",
		"foyer",
		"kitchen"
	],
	foyer: [
		"foyer",
		"dining",
		"kitchen"
	],
	hall: [
		"hall",
		"balcony",
		"bedroom",
		"library"
	],
	kitchen: [
		"kitchen",
		"dining",
		"foyer"
	],
	library: [
		"library",
		"hall",
		"balcony"
	],
	balcony: [
		"balcony",
		"hall",
		"foyer",
		"kitchen",
		"dining"
	]
}, ce = {
	foyer: {
		id: "echoes",
		ap: 0
	},
	bedroom: {
		id: "flood",
		ap: 1
	},
	library: {
		id: "trapdoor",
		ap: 1
	},
	basement: {
		id: "controlpanel",
		ap: 1
	},
	balcony: {
		id: "jump",
		ap: 0
	}
}, k = {
	bedroom: {
		x: 48,
		y: 46,
		w: 408,
		h: 370
	},
	hall: {
		x: 455,
		y: 46,
		w: 173,
		h: 370
	},
	library: {
		x: 630,
		y: 46,
		w: 387,
		h: 370
	},
	balcony: {
		x: 320,
		y: 418,
		w: 430,
		h: 210
	},
	kitchen: {
		x: 43,
		y: 440,
		w: 455,
		h: 452
	},
	foyer: {
		x: 510,
		y: 628,
		w: 507,
		h: 598
	},
	dining: {
		x: 43,
		y: 902,
		w: 455,
		h: 324
	},
	basement: {
		x: 43,
		y: 1235,
		w: 975,
		h: 240
	}
}, A = t.enum(T), j = t.string(), le = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pickStart"),
		room: A
	}),
	t.object({
		type: t.literal("move"),
		room: A
	}),
	t.object({
		type: t.literal("shoot"),
		room: A
	}),
	t.object({ type: t.literal("listen") }),
	t.object({
		type: t.literal("answer"),
		room: A
	}),
	t.object({
		type: t.literal("setTrap"),
		replace: A.optional()
	}),
	t.object({
		type: t.literal("detonate"),
		room: A
	}),
	t.object({
		type: t.literal("effect"),
		room: A.optional()
	}),
	t.object({
		type: t.literal("forcedMove"),
		room: A
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), M = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("listen"),
		by: j,
		who: j
	}),
	t.object({
		kind: t.literal("forcedMove"),
		who: j
	}),
	t.object({
		kind: t.literal("evac"),
		who: j
	})
]), N = t.discriminatedUnion("k", [
	t.object({ k: t.literal("start") }),
	t.object({
		k: t.literal("move"),
		by: j
	}),
	t.object({
		k: t.literal("shoot"),
		by: j,
		from: A,
		target: A,
		hit: t.boolean(),
		turnNo: t.int().min(1).optional()
	}),
	t.object({
		k: t.literal("listen"),
		by: j
	}),
	t.object({
		k: t.literal("answer"),
		by: j,
		room: A,
		turnNo: t.int().min(1).optional()
	}),
	t.object({
		k: t.literal("setTrap"),
		by: j
	}),
	t.object({
		k: t.literal("detonate"),
		by: j,
		room: A,
		hit: t.boolean(),
		auto: t.boolean().optional()
	}),
	t.object({
		k: t.literal("effect"),
		by: j,
		room: A
	}),
	t.object({
		k: t.literal("reveal"),
		by: j,
		room: A
	}),
	t.object({
		k: t.literal("jump"),
		by: j
	})
]), P = t.object({
	phase: t.enum([
		"pick",
		"play",
		"over"
	]),
	players: t.array(t.object({
		rid: j,
		hits: t.int().min(0).max(2),
		ready: t.boolean()
	})),
	turn: j.nullable(),
	turnNo: t.int().min(0),
	ap: t.int().min(0).max(3),
	flooded: t.boolean(),
	startPending: t.boolean(),
	pending: M.nullable(),
	winner: j.nullable(),
	log: t.array(N)
}), ue = t.object({
	pos: A.nullable(),
	traps: t.array(t.object({
		room: A,
		auto: t.boolean()
	}))
}), F = 1200, de = 2, I = (e) => ({ code: e }), L = (e, t) => e.players[0] === t ? e.players[1] : e.players[0], R = (e) => e.turnNo ?? +!!e.turn, fe = (e, t) => e.pos[t] === "kitchen" ? 3 : 2;
function z(e, t) {
	return e.hits[t] += 1, e.hits[t] >= de && (e.phase = "over", e.winner = L(e, t), e.pending = null, e.startQueue = [], !0);
}
function pe(e, t) {
	let n = R(e) + 1;
	e.turn = t, e.turnNo = n, e.floodedBy === t && (e.floodedBy = null), e.ap = fe(e, t), e.startQueue = e.traps[t].filter((e) => e.auto).map((e) => e.room), e.beatMs = F;
}
function B(t, n, r) {
	return {
		state: {
			players: [n[0], n[1]],
			phase: "pick",
			pos: {
				[n[0]]: null,
				[n[1]]: null
			},
			hits: {
				[n[0]]: 0,
				[n[1]]: 0
			},
			traps: {
				[n[0]]: [],
				[n[1]]: []
			},
			floodedBy: null,
			turn: null,
			turnNo: 0,
			ap: 0,
			pending: null,
			startQueue: [],
			winner: null,
			log: [],
			beatMs: 0,
			first: n[e(r, 0, n.length)]
		},
		fx: []
	};
}
function V(e, t, n) {
	let r = e.pos[t];
	return !r || !D[r].includes(n) ? "games.revolvernoir.errBadRoom" : n === "basement" && e.floodedBy !== null ? "games.revolvernoir.errFlooded" : null;
}
function H(e, t, n, r) {
	e.traps[t] = e.traps[t].filter((e) => e.room !== n);
	let i = L(e, t), a = e.pos[i] === n;
	return a && z(e, i), e.log.push({
		k: "detonate",
		by: t,
		room: n,
		hit: a,
		...r ? { auto: !0 } : {}
	}), {
		kind: "detonate",
		rid: t,
		data: {
			room: n,
			hit: a,
			...r ? { auto: !0 } : {}
		}
	};
}
function me(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "play" || e.startQueue.length === 0 || !e.turn) return {
			state: e,
			fx: []
		};
		let t = e.turn, n = structuredClone(e), r = n.startQueue[0];
		n.startQueue = n.startQueue.slice(1);
		let i = H(n, t, r, !0);
		return n.beatMs = F, {
			state: n,
			fx: [i]
		};
	}
	if (t.type === "pickStart") {
		if (e.phase !== "pick" || e.pos[n.by] !== null) return I("games.revolvernoir.errNotYourTurn");
		let r = structuredClone(e);
		return r.pos[n.by] = t.room, r.players.every((e) => r.pos[e] !== null) ? (r.phase = "play", r.log.push({ k: "start" }), pe(r, r.first), {
			state: r,
			fx: [{ kind: "start" }]
		}) : {
			state: r,
			fx: []
		};
	}
	if (e.phase !== "play" || !e.turn) return I("games.revolvernoir.errNotYourTurn");
	if (e.pending) {
		let r = e.pending;
		if (r.kind === "listen") {
			if (t.type !== "answer" || n.by !== r.who) return I("games.revolvernoir.errNotYourTurn");
			let i = V(e, n.by, t.room);
			if (i) return I(i);
			let a = structuredClone(e);
			return a.pending = null, a.log.push({
				k: "answer",
				by: n.by,
				room: t.room,
				turnNo: R(a)
			}), {
				state: a,
				fx: [{
					kind: "answer",
					rid: n.by,
					data: { room: t.room }
				}]
			};
		}
		if (t.type !== "forcedMove" || n.by !== r.who) return I("games.revolvernoir.errNotYourTurn");
		let i = V(e, n.by, t.room);
		if (i) return I(i);
		let a = structuredClone(e), o = a.pos[n.by];
		return a.pos[n.by] = t.room, a.pending = null, a.log.push({
			k: "move",
			by: n.by
		}), {
			state: a,
			fx: [{
				kind: "move",
				for: [n.by],
				secret: {
					from: o,
					to: t.room
				}
			}]
		};
	}
	if (e.startQueue.length > 0) return I("games.revolvernoir.errPending");
	if (n.by !== e.turn) return I("games.revolvernoir.errNotYourTurn");
	let r = n.by, i = L(e, r), a = e.pos[r];
	if (!a) return I("games.revolvernoir.errNotYourTurn");
	switch (t.type) {
		case "move": {
			if (e.ap < 1) return I("games.revolvernoir.errNoAp");
			let n = V(e, r, t.room);
			if (n) return I(n);
			let i = structuredClone(e);
			return i.pos[r] = t.room, --i.ap, i.log.push({
				k: "move",
				by: r
			}), {
				state: i,
				fx: [{
					kind: "move",
					for: [r],
					secret: {
						from: a,
						to: t.room
					}
				}]
			};
		}
		case "shoot": {
			if (e.ap < 2) return I("games.revolvernoir.errNoAp");
			if (!O[a].includes(t.room)) return I("games.revolvernoir.errBadRoom");
			let n = structuredClone(e);
			n.ap -= 2;
			let o = n.pos[i] === t.room;
			n.log.push({
				k: "shoot",
				by: r,
				from: a,
				target: t.room,
				hit: o,
				turnNo: R(n)
			});
			let s = [{
				kind: "shoot",
				rid: r,
				data: {
					from: a,
					target: t.room,
					hit: o
				}
			}];
			return o && z(n, i) || (n.pending = {
				kind: "forcedMove",
				who: r
			}), {
				state: n,
				fx: s
			};
		}
		case "listen": {
			if (e.ap < 1) return I("games.revolvernoir.errNoAp");
			let t = structuredClone(e);
			return --t.ap, t.pending = {
				kind: "listen",
				by: r,
				who: i
			}, t.log.push({
				k: "listen",
				by: r
			}), {
				state: t,
				fx: [{
					kind: "listen",
					rid: r
				}]
			};
		}
		case "setTrap": {
			if (e.ap < 1) return I("games.revolvernoir.errNoAp");
			let n = e.traps[r];
			if (n.some((e) => e.room === a)) return I("games.revolvernoir.errBadRoom");
			if (n.length >= 2 && (!t.replace || !n.some((e) => e.room === t.replace))) return I("games.revolvernoir.errNoTrap");
			let i = structuredClone(e);
			return t.replace && (i.traps[r] = i.traps[r].filter((e) => e.room !== t.replace)), i.traps[r].push({
				room: a,
				auto: !1
			}), --i.ap, i.log.push({
				k: "setTrap",
				by: r
			}), {
				state: i,
				fx: [{
					kind: "setTrap",
					for: [r],
					secret: { room: a }
				}]
			};
		}
		case "detonate": {
			if (e.ap < 1) return I("games.revolvernoir.errNoAp");
			if (!e.traps[r].some((e) => e.room === t.room)) return I("games.revolvernoir.errNoTrap");
			let n = structuredClone(e);
			return {
				state: n,
				fx: [H(n, r, t.room, !1)]
			};
		}
		case "effect": {
			let n = ce[a];
			if (!n) return I("games.revolvernoir.errNoEffect");
			if (e.ap < n.ap) return I("games.revolvernoir.errNoAp");
			let o = structuredClone(e);
			o.ap -= n.ap, o.log.push({
				k: "effect",
				by: r,
				room: a
			});
			let s = [], c = (e, t) => ({
				kind: "effect",
				rid: r,
				data: {
					room: a,
					effect: n.id,
					...e
				},
				...t
			});
			switch (n.id) {
				case "echoes": {
					let e = o.pos[i];
					e && E.includes(e) && (o.log.push({
						k: "reveal",
						by: i,
						room: e
					}), s.push({
						kind: "reveal",
						rid: i,
						data: { room: e }
					})), o.pending = {
						kind: "listen",
						by: r,
						who: i
					}, s.push(c({}));
					break;
				}
				case "flood": {
					o.floodedBy = r;
					let e = o.pos[i] === "basement";
					e && !z(o, i) && (o.pending = {
						kind: "evac",
						who: i
					}), s.push(c({ hit: e }));
					break;
				}
				case "trapdoor": {
					let e = o.pos[i] === "kitchen", t = !1;
					e && (o.pos[i] = "basement", o.floodedBy !== null && (t = !0, z(o, i) || (o.pending = {
						kind: "evac",
						who: i
					}))), s.push(c({}, {
						for: [i],
						secret: {
							dumped: e,
							hit: t
						}
					}));
					break;
				}
				case "controlpanel": {
					let e = t.room;
					if (!e || e === "basement") return I("games.revolvernoir.errBadRoom");
					if (o.traps[r].length >= 2) return I("games.revolvernoir.errNoTrap");
					if (o.traps[r].some((t) => t.room === e)) return I("games.revolvernoir.errBadRoom");
					o.traps[r].push({
						room: e,
						auto: !0
					}), s.push(c({}, {
						for: [r],
						secret: { trap: e }
					}));
					break;
				}
				case "jump": o.pos[r] = "kitchen", o.log.push({
					k: "jump",
					by: r
				}), s.push(c({}));
			}
			return {
				state: o,
				fx: s
			};
		}
		case "endTurn": {
			let t = structuredClone(e);
			return pe(t, i), {
				state: t,
				fx: [{
					kind: "turn",
					rid: i
				}]
			};
		}
		default: return I("games.revolvernoir.errNotYourTurn");
	}
}
function he(e, t) {
	return {
		public: {
			phase: e.phase,
			players: e.players.map((t) => ({
				rid: t,
				hits: e.hits[t],
				ready: e.pos[t] !== null
			})),
			turn: e.turn,
			turnNo: R(e),
			ap: e.ap,
			flooded: e.floodedBy !== null,
			startPending: e.startQueue.length > 0,
			pending: e.pending,
			winner: e.winner,
			log: e.log
		},
		private: {
			pos: e.pos[t] ?? null,
			traps: e.traps[t] ?? []
		}
	};
}
function U(e) {
	return e.phase !== "over" || !e.winner ? { phase: e.phase } : {
		phase: "over",
		winner: [e.winner],
		ranking: [e.winner, L(e, e.winner)]
	};
}
function W(e) {
	return e.phase === "play" && e.startQueue.length > 0 ? e.beatMs : null;
}
var ge = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: se,
	schemas: {
		action: le,
		publicView: P,
		privateView: ue
	},
	setup: B,
	reduce: me,
	viewFor: he,
	status: U,
	nextTickIn: W
}, _e = (e) => Array.from({ length: 24 }, (t, n) => {
	let r = n * Math.PI / 12 - Math.PI / 2, i = n % 2 == 0 ? e : e * .62;
	return `${Math.cos(r) * i},${Math.sin(r) * i}`;
}).join(" "), G = (e, t, n) => {
	let r = {
		x: e.x - Math.cos(t) * n * .34,
		y: e.y - Math.sin(t) * n * .34
	}, i = n * .15;
	return [
		`${e.x},${e.y}`,
		`${r.x - Math.sin(t) * i},${r.y + Math.cos(t) * i}`,
		`${r.x + Math.sin(t) * i},${r.y - Math.cos(t) * i}`
	].join(" ");
};
function ve({ from: e, target: t, size: n, variant: r, hit: i, sourceLabel: a, targetLabel: o }) {
	let s = Math.hypot(t.x - e.x, t.y - e.y) < 1, c = s ? {
		x: e.x - n * .95,
		y: e.y + n * .55
	} : e, l = s ? {
		x: t.x + n * .95,
		y: t.y + n * .55
	} : t, u = Math.atan2(l.y - c.y, l.x - c.x), d = {
		x: Math.cos(u),
		y: Math.sin(u)
	}, f = {
		x: c.x + d.x * n * .52,
		y: c.y + d.y * n * .52
	}, p = {
		x: l.x - d.x * n * .57,
		y: l.y - d.y * n * .57
	}, m = {
		x: (f.x + p.x) / 2,
		y: s ? Math.max(f.y, p.y) + n * .75 : Math.min(f.y, p.y) - n * .88
	}, ee = s ? `M ${f.x} ${f.y} Q ${m.x} ${m.y} ${p.x} ${p.y}` : `M ${f.x} ${f.y} L ${p.x} ${p.y}`, h = s ? Math.atan2(p.y - m.y, p.x - m.x) : u;
	return /* @__PURE__ */ S("g", {
		className: `rn-shot-route rn-shot-route-${r}`,
		children: [
			/* @__PURE__ */ x("path", {
				className: "rn-shot-line rn-shot-line-outline",
				d: ee,
				fill: "none",
				stroke: "var(--color-ink)",
				strokeWidth: n * .15,
				strokeLinecap: "round",
				strokeDasharray: r === "clue" ? `${n * .2} ${n * .14}` : void 0,
				pathLength: r === "fx" ? 1 : void 0
			}),
			/* @__PURE__ */ x("path", {
				className: "rn-shot-line rn-shot-line-core",
				d: ee,
				fill: "none",
				stroke: "var(--color-danger-ink)",
				strokeWidth: n * .075,
				strokeLinecap: "round",
				strokeDasharray: r === "clue" ? `${n * .2} ${n * .14}` : void 0,
				pathLength: r === "fx" ? 1 : void 0
			}),
			/* @__PURE__ */ x("polygon", {
				className: "rn-shot-tip",
				points: G(p, h, n),
				fill: "var(--color-danger-ink)",
				stroke: "var(--color-ink)",
				strokeWidth: n * .055,
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ S("g", {
				className: "rn-shot-burst",
				transform: `translate(${c.x} ${c.y})`,
				children: [/* @__PURE__ */ x("polygon", {
					points: _e(n * .47),
					fill: "var(--color-danger-soft)",
					stroke: "var(--color-ink)",
					strokeWidth: n * .06,
					strokeLinejoin: "round"
				}), /* @__PURE__ */ x("circle", {
					r: n * .15,
					fill: "var(--color-danger)"
				})]
			}),
			/* @__PURE__ */ S("g", {
				className: "rn-shot-target",
				transform: `translate(${l.x} ${l.y})`,
				children: [
					/* @__PURE__ */ x("circle", {
						r: n * .45,
						fill: "var(--color-surface)",
						stroke: "var(--color-ink)",
						strokeWidth: n * .06
					}),
					/* @__PURE__ */ x("circle", {
						r: n * .32,
						fill: "none",
						stroke: "var(--color-danger-ink)",
						strokeWidth: n * .065
					}),
					/* @__PURE__ */ x("circle", {
						r: n * .14,
						fill: i ? "var(--color-danger)" : "var(--color-surface)",
						stroke: "var(--color-danger-ink)",
						strokeWidth: n * .055
					})
				]
			}),
			/* @__PURE__ */ x("text", {
				className: "rn-shot-label rn-shot-source-label",
				x: c.x,
				y: s ? c.y + n * .91 : c.y - n * .7,
				textAnchor: "middle",
				fontSize: r === "clue" ? 30 : n * .31,
				children: a
			}),
			/* @__PURE__ */ x("text", {
				className: "rn-shot-label rn-shot-target-label",
				x: s ? l.x + n * .15 : l.x,
				y: s ? l.y - n * .65 : l.y + n * .92,
				textAnchor: "middle",
				fontSize: r === "clue" ? 28 : n * .29,
				children: o
			})
		]
	});
}
function ye({ at: e, size: t, variant: n, label: r }) {
	return /* @__PURE__ */ S("g", {
		className: `rn-sound-marker rn-sound-marker-${n}`,
		transform: `translate(${e.x} ${e.y})`,
		children: [
			/* @__PURE__ */ x("circle", {
				className: "rn-sound-outer",
				r: t * .5,
				fill: "var(--color-info-soft)",
				fillOpacity: "0.35",
				stroke: "var(--color-info-ink)",
				strokeWidth: t * .045
			}),
			/* @__PURE__ */ x("circle", {
				className: "rn-sound-inner",
				r: t * .32,
				fill: "none",
				stroke: "var(--color-info)",
				strokeWidth: t * .06
			}),
			/* @__PURE__ */ x("circle", {
				r: t * .12,
				fill: "var(--color-info)"
			}),
			/* @__PURE__ */ x("text", {
				className: "rn-shot-label rn-sound-label",
				x: "0",
				y: -t * .67,
				textAnchor: "middle",
				fontSize: n === "clue" ? 30 : t * .27,
				children: r
			})
		]
	});
}
//#endregion
//#region src/games/revolvernoir/view-player.tsx
function be(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ x(Ce, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var K = {
	basement: "games.revolvernoir.rooms.basement",
	bedroom: "games.revolvernoir.rooms.bedroom",
	dining: "games.revolvernoir.rooms.dining",
	foyer: "games.revolvernoir.rooms.foyer",
	hall: "games.revolvernoir.rooms.hall",
	kitchen: "games.revolvernoir.rooms.kitchen",
	library: "games.revolvernoir.rooms.library",
	balcony: "games.revolvernoir.rooms.balcony"
}, xe = {
	echoes: "games.revolvernoir.effects.echoes",
	flood: "games.revolvernoir.effects.flood",
	trapdoor: "games.revolvernoir.effects.trapdoor",
	controlpanel: "games.revolvernoir.effects.controlpanel",
	jump: "games.revolvernoir.effects.jump"
}, q = {
	echoes: "games.revolvernoir.effectDesc.echoes",
	flood: "games.revolvernoir.effectDesc.flood",
	trapdoor: "games.revolvernoir.effectDesc.trapdoor",
	controlpanel: "games.revolvernoir.effectDesc.controlpanel",
	jump: "games.revolvernoir.effectDesc.jump"
}, Se = {
	echoes: "games.revolvernoir.effectButton.echoes",
	flood: "games.revolvernoir.effectButton.flood",
	trapdoor: "games.revolvernoir.effectButton.trapdoor",
	controlpanel: "games.revolvernoir.effectButton.controlpanel",
	jump: "games.revolvernoir.effectButton.jump"
};
function Ce({ pub: e, priv: t, members: o, myRid: s, send: c }) {
	let m = d(), te = u((e) => e.locale), b = (e) => {
		let t = o.find((t) => t.rid === e);
		return t ? a(t.rid) === null ? t.name : l(te, t.avatar) : e;
	}, C = (e) => m(K[e]), w = (e) => m(xe[e]), oe = o.find((e) => e.rid === s), E = v[(oe?.colorIndex ?? 0) % v.length], k = t?.pos ?? null, A = t?.traps ?? [], j = e.pending !== null && e.pending.who === s, le = e.phase === "play" && e.turn === s && !e.pending && !e.startPending, M = k ? ce[k] : void 0, [N, P] = i(null), [ue, F] = i(null), [de, I] = i(0), L = r(e.log.length), R = r(null);
	n(() => {
		let t = L.current;
		L.current = e.log.length, e.log.slice(t).some((e) => e.k === "move" && e.by !== s) && (R.current !== null && window.clearTimeout(R.current), I((e) => e + 1), R.current = window.setTimeout(() => I(0), 850));
	}, [e.log, s]), n(() => () => {
		R.current !== null && window.clearTimeout(R.current);
	}, []);
	let fe = `${e.phase}|${e.turn}|${e.pending?.kind ?? ""}|${e.pending?.who ?? ""}`, [z, pe] = i(fe);
	z !== fe && (pe(fe), P(null));
	let B = (e) => {
		c(e), P(null);
	}, V = (t) => D[t].filter((t) => !(t === "basement" && e.flooded)), H = null;
	e.phase === "pick" && k === null ? H = [...T] : j && (e.pending?.kind === "forcedMove" || e.pending?.kind === "evac") && k ? H = V(k) : le && N && k && (N === "move" ? H = V(k) : N === "shoot" ? H = [...O[k]] : N === "detonate" || N === "replaceTrap" ? H = A.map((e) => e.room) : N === "panel" && (H = T.filter((e) => e !== "basement" && !A.some((t) => t.room === e))));
	let me = e.phase === "pick" ? "start" : N === "shoot" ? "shoot" : N === "detonate" || N === "replaceTrap" || N === "panel" ? "trap" : "move", he = (t) => {
		if (H?.includes(t)) {
			e.phase === "pick" ? B({
				type: "pickStart",
				room: t
			}) : e.pending?.kind === "forcedMove" || e.pending?.kind === "evac" ? B({
				type: "forcedMove",
				room: t
			}) : N === "move" ? B({
				type: "move",
				room: t
			}) : N === "shoot" ? B({
				type: "shoot",
				room: t
			}) : N === "detonate" ? B({
				type: "detonate",
				room: t
			}) : N === "replaceTrap" ? B({
				type: "setTrap",
				replace: t
			}) : N === "panel" && B({
				type: "effect",
				room: t
			});
			return;
		}
		N || F(t);
	}, U = "info", W, ge;
	e.phase === "pick" ? k === null ? (U = "accent", W = m("games.revolvernoir.pickStart")) : W = m("games.revolvernoir.waitingPick") : e.startPending ? (U = "warn", W = m("games.revolvernoir.startPendingShort")) : e.pending ? e.pending.kind === "listen" ? (U = e.pending.who === s ? "accent" : "info", W = e.pending.who === s ? m("games.revolvernoir.listenAnswerShort") : m("games.revolvernoir.waitingListenShort")) : (U = j ? "accent" : "info", W = m(j ? e.pending.kind === "evac" ? "games.revolvernoir.evacShort" : "games.revolvernoir.forcedMoveShort" : "games.revolvernoir.waitingForcedMove")) : le ? (U = "accent", W = m("games.revolvernoir.yourTurn")) : W = m("games.revolvernoir.opponentTurn"), e.flooded && (ge = m("games.revolvernoir.floodedBanner"));
	let _e = (e) => {
		let t = o.find((t) => t.rid === e), n = v[(t?.colorIndex ?? 0) % v.length].hex;
		return /* @__PURE__ */ x("span", {
			className: "font-extrabold",
			style: { color: n },
			children: b(e)
		});
	}, G = (e) => /* @__PURE__ */ x("span", {
		className: "rounded-sm bg-ink/10 px-0.5 font-bold",
		children: C(e)
	}), ve = (e) => /* @__PURE__ */ x("span", {
		className: "font-bold",
		style: { color: se.accent },
		children: w(e)
	}), ye = (e) => {
		let t = "by" in e ? _e(e.by) : null;
		switch (e.k) {
			case "start": return m("games.revolvernoir.logStart");
			case "move": return y(m, "games.revolvernoir.logMove", [["name", t]]);
			case "shoot": return y(m, e.hit ? "games.revolvernoir.logShootHit" : "games.revolvernoir.logShootMiss", [
				["name", t],
				["from", G(e.from)],
				["target", G(e.target)]
			]);
			case "listen": return y(m, "games.revolvernoir.logListen", [["name", t]]);
			case "answer": return y(m, "games.revolvernoir.logAnswer", [["name", t], ["room", G(e.room)]]);
			case "setTrap": return y(m, "games.revolvernoir.logSetTrap", [["name", t]]);
			case "detonate": {
				let n = e.auto ? e.hit ? "games.revolvernoir.logDetonateAutoHit" : "games.revolvernoir.logDetonateAutoMiss" : e.hit ? "games.revolvernoir.logDetonateHit" : "games.revolvernoir.logDetonateMiss";
				return y(m, n, [["name", t], ["room", G(e.room)]]);
			}
			case "effect": {
				let n = ce[e.room];
				return y(m, "games.revolvernoir.logEffect", [
					["name", t],
					["room", G(e.room)],
					["effect", n ? ve(n.id) : ""]
				]);
			}
			case "reveal": return y(m, "games.revolvernoir.logReveal", [["name", t], ["room", G(e.room)]]);
			case "jump": return y(m, "games.revolvernoir.logJump", [["name", t]]);
		}
	}, be = null;
	if (e.pending?.kind === "listen" && e.pending.who === s && k) be = /* @__PURE__ */ S("div", {
		className: "rn-overlay rn-overlay-answer pointer-events-auto flex flex-col items-center gap-1.5 pb-2",
		children: [/* @__PURE__ */ x("span", {
			className: "plate mx-2 max-w-full px-3 py-1.5 text-center text-xs font-bold",
			children: m("games.revolvernoir.listenAnswerPrompt")
		}), /* @__PURE__ */ x("div", {
			className: "flex flex-wrap justify-center gap-1.5 px-2",
			children: V(k).map((e) => /* @__PURE__ */ x("button", {
				type: "button",
				onClick: () => B({
					type: "answer",
					room: e
				}),
				className: "btn-base min-h-11 bg-surface px-3 text-sm",
				children: C(e)
			}, e))
		})]
	});
	else {
		let t = j && e.pending?.kind !== "listen" ? m(e.pending?.kind === "evac" ? "games.revolvernoir.evacPrompt" : "games.revolvernoir.forcedMovePrompt") : N === "move" ? m("games.revolvernoir.chooseMoveTarget") : N === "shoot" ? m("games.revolvernoir.chooseShootTarget") : N === "detonate" ? m("games.revolvernoir.chooseDetonateTarget") : N === "panel" ? m("games.revolvernoir.chooseTrapTarget") : N === "replaceTrap" ? m("games.revolvernoir.chooseReplaceTrap") : null;
		t && (be = /* @__PURE__ */ x("div", {
			className: "rn-overlay flex justify-center pb-2",
			children: /* @__PURE__ */ x("span", {
				className: "plate px-3 py-1.5 text-xs font-bold",
				children: t
			})
		}));
	}
	let q = e.ap, Ce = k !== null && A.some((e) => e.room === k), Y = le && k !== null, we = /* @__PURE__ */ S("div", {
		className: "rn-actions frame flex h-full flex-col justify-center gap-1.5 p-0.5",
		children: [/* @__PURE__ */ S("div", {
			className: "grid grid-cols-4 gap-1.5",
			children: [
				/* @__PURE__ */ x(J, {
					icon: /* @__PURE__ */ x(h, {
						size: 17,
						"aria-hidden": !0
					}),
					label: m("games.revolvernoir.actMove"),
					cost: 1,
					active: N === "move",
					disabled: !Y || q < 1,
					onClick: () => P(N === "move" ? null : "move")
				}),
				/* @__PURE__ */ x(J, {
					icon: /* @__PURE__ */ x(g, {
						size: 17,
						"aria-hidden": !0
					}),
					label: m("games.revolvernoir.actShoot"),
					cost: 2,
					active: N === "shoot",
					danger: !0,
					disabled: !Y || q < 2,
					onClick: () => P(N === "shoot" ? null : "shoot")
				}),
				/* @__PURE__ */ x(J, {
					icon: /* @__PURE__ */ x(ee, {
						size: 17,
						"aria-hidden": !0
					}),
					label: m("games.revolvernoir.actListen"),
					cost: 1,
					disabled: !Y || q < 1,
					onClick: () => B({ type: "listen" })
				}),
				/* @__PURE__ */ x(J, {
					icon: /* @__PURE__ */ x(p, {
						size: 17,
						"aria-hidden": !0
					}),
					label: m(M ? Se[M.id] : "games.revolvernoir.actEffect"),
					fullLabel: M ? w(M.id) : void 0,
					cost: M?.ap,
					active: N === "panel",
					disabled: !Y || !M || q < M.ap,
					onClick: () => M?.id === "controlpanel" ? P(N === "panel" ? null : "panel") : B({ type: "effect" })
				})
			]
		}), /* @__PURE__ */ S("div", {
			className: "grid grid-cols-3 gap-1.5",
			children: [
				/* @__PURE__ */ x(J, {
					icon: /* @__PURE__ */ x(_, {
						size: 17,
						"aria-hidden": !0
					}),
					label: m("games.revolvernoir.actSetTrap"),
					cost: 1,
					active: N === "replaceTrap",
					disabled: !Y || q < 1 || Ce,
					onClick: () => A.length >= 2 ? P(N === "replaceTrap" ? null : "replaceTrap") : B({ type: "setTrap" })
				}),
				/* @__PURE__ */ x(J, {
					icon: /* @__PURE__ */ x(_, {
						size: 17,
						"aria-hidden": !0
					}),
					label: m("games.revolvernoir.actDetonate"),
					cost: 1,
					active: N === "detonate",
					danger: !0,
					disabled: !Y || q < 1 || A.length === 0,
					onClick: () => P(N === "detonate" ? null : "detonate")
				}),
				/* @__PURE__ */ x(J, {
					icon: /* @__PURE__ */ x(f, {
						size: 17,
						"aria-hidden": !0
					}),
					label: m("games.revolvernoir.actEndTurn"),
					disabled: !Y,
					onClick: () => B({ type: "endTurn" })
				})
			]
		})]
	});
	return /* @__PURE__ */ S(ne, {
		adaptive: !0,
		className: "rn-layout",
		banner: /* @__PURE__ */ S("div", {
			className: "rn-banner flex flex-col gap-2 wide:flex-row wide:items-center",
			children: [
				/* @__PURE__ */ x("div", {
					className: "rn-banner-phase mr-11 wide:mr-0 wide:min-w-0 wide:flex-[3]",
					children: /* @__PURE__ */ x(ie, {
						tone: U,
						text: W,
						sub: ge,
						chip: e.phase === "play" ? m("games.revolvernoir.apChip", { n: q }) : void 0,
						accent: se.accent
					})
				}),
				/* @__PURE__ */ x("div", {
					className: "rn-banner-players wide:flex-none",
					children: /* @__PURE__ */ x(ae, {
						adaptive: !0,
						members: o.filter((t) => e.players.some((e) => e.rid === t.rid)),
						myRid: s,
						variant: "mini",
						anchorOf: (e) => `seat:${e}`,
						action: (t) => e.phase === "play" && (e.turn === t || e.pending?.who === t) ? "pending" : null,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ S("span", {
								className: "rn-hits text-[10px] leading-4",
								"aria-label": m("games.revolvernoir.hitsChip", { n: n.hits }),
								children: ["💥".repeat(n.hits), "❤️".repeat(2 - n.hits)]
							}) : null;
						}
					})
				}),
				/* @__PURE__ */ x("div", {
					className: "rn-banner-log wide:min-w-0 wide:flex-[2] wide:pr-11",
					children: /* @__PURE__ */ x(re, {
						log: e.log,
						line: ye
					})
				})
			]
		}),
		actions: we,
		actionsHeight: "h-[118px] short:h-[112px]",
		overlay: be,
		scroll: !1,
		children: [/* @__PURE__ */ x(De, {
			pub: e,
			myPos: k,
			myTraps: A,
			myAvatar: oe?.avatar ?? 0,
			myName: b(s),
			myColor: E.hex,
			myColorName: m(E.nameKey),
			targets: H,
			targetKind: me,
			roomName: C,
			onRoomTap: he,
			opponentMoveCue: de
		}), /* @__PURE__ */ x(ke, {
			room: ue,
			onClose: () => F(null)
		})]
	});
}
function J({ icon: e, label: t, fullLabel: n, cost: r, active: i, danger: a, disabled: o, onClick: s }) {
	return /* @__PURE__ */ S("button", {
		type: "button",
		disabled: o,
		"aria-pressed": i,
		onClick: s,
		title: n ?? t,
		className: `btn-base rn-act flex min-h-12 flex-col items-center justify-center gap-0 px-1 leading-4 disabled:opacity-50 ${i ? a ? "danger-stripes text-white" : "bg-info-soft text-info-ink ring-2 ring-info-ink" : "bg-surface"}`,
		children: [/* @__PURE__ */ S("span", {
			className: "rn-act-label flex max-w-full items-center gap-1 font-display text-[13px] font-extrabold",
			children: [e, /* @__PURE__ */ x("span", {
				className: "truncate",
				children: t
			})]
		}), r !== void 0 && /* @__PURE__ */ S("span", {
			className: `rn-act-cost font-mono text-xs font-bold tabular-nums ${i && a ? "text-white" : "text-ink-soft"}`,
			children: [r, " AP"]
		})]
	});
}
var Y = 1060, we = 1484, Te = "./games/revolvernoir/board.webp", Ee = {
	start: "games.revolvernoir.targetStart",
	move: "games.revolvernoir.targetMove",
	shoot: "games.revolvernoir.targetShoot",
	trap: "games.revolvernoir.targetTrap"
};
function De({ pub: e, myPos: t, myTraps: n, myAvatar: r, myName: i, myColor: a, myColorName: o, targets: s, targetKind: l, roomName: u, onRoomTap: f, opponentMoveCue: p }) {
	let m = d(), { ref: ee } = c("rn-board-viewport"), { ref: h } = c("rn-pawn-size"), g = null, _ = null;
	for (let t = e.log.length - 1; t >= 0 && (!g || !_); --t) {
		let n = e.log[t];
		n.k === "shoot" && !g && (g = n), n.k === "answer" && !_ && (_ = n);
	}
	g && (g.turnNo === void 0 || e.turnNo > g.turnNo + 1) && (g = null), _ && (_.turnNo === void 0 || e.turnNo > _.turnNo + 1) && (_ = null);
	let v = (e) => {
		let t = k[e];
		return {
			x: t.x + t.w / 2,
			y: t.y + t.h * .54
		};
	};
	return /* @__PURE__ */ S("div", {
		ref: ee,
		className: "rn-board-viewport frame relative h-full min-h-0",
		children: [/* @__PURE__ */ x(te, {
			kind: "sheen",
			base: "var(--color-paper)",
			className: "pointer-events-none absolute inset-0"
		}), /* @__PURE__ */ x("div", {
			className: "rn-board-stage",
			children: /* @__PURE__ */ S("div", {
				className: "rn-board",
				children: [
					/* @__PURE__ */ x("span", {
						ref: h,
						className: "rn-pawn-size",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ x("img", {
						src: Te,
						alt: "",
						draggable: !1,
						className: "pointer-events-none absolute inset-0 size-full"
					}),
					T.map((c) => /* @__PURE__ */ x(Oe, {
						room: c,
						name: u(c),
						isTarget: s?.includes(c) ?? !1,
						targetKind: l,
						me: t === c,
						traps: n.filter((e) => e.room === c),
						flooded: c === "basement" && e.flooded,
						myAvatar: r,
						myName: i,
						myColor: a,
						myColorName: o,
						onTap: () => f(c)
					}, c)),
					(g || _) && /* @__PURE__ */ S("svg", {
						className: "rn-clue-layer",
						viewBox: `0 0 ${Y} ${we}`,
						"aria-hidden": !0,
						children: [g && /* @__PURE__ */ x(ve, {
							from: v(g.from),
							target: v(g.target),
							size: 64,
							variant: "clue",
							hit: g.hit,
							sourceLabel: m("games.revolvernoir.shotPrevious"),
							targetLabel: m("games.revolvernoir.shotTarget")
						}), _ && /* @__PURE__ */ x(ye, {
							at: v(_.room),
							size: 76,
							variant: "clue",
							label: m("games.revolvernoir.answerClue")
						})]
					}),
					p > 0 && /* @__PURE__ */ x("span", {
						className: "rn-opponent-footsteps",
						children: m("games.revolvernoir.opponentFootsteps")
					}, p)
				]
			})
		})]
	});
}
function Oe({ room: e, name: t, isTarget: n, targetKind: r, me: i, traps: a, flooded: s, myAvatar: l, myName: u, myColor: p, myColorName: ee, onTap: v }) {
	let te = d(), ne = k[e], { ref: re } = c(`room:${e}`), y = n ? te(Ee[r], { room: t }) : i ? te("games.revolvernoir.myRoom", { room: t }) : t;
	return /* @__PURE__ */ S("button", {
		ref: re,
		type: "button",
		"aria-label": y,
		onClick: v,
		"data-target": n ? r : void 0,
		"data-me": i || void 0,
		className: "rn-room",
		style: {
			left: `${ne.x / Y * 100}%`,
			top: `${ne.y / we * 100}%`,
			width: `${ne.w / Y * 100}%`,
			height: `${ne.h / we * 100}%`,
			clipPath: e === "kitchen" ? "polygon(0 0, 61% 0, 61% 42%, 100% 42%, 100% 100%, 0 100%)" : void 0
		},
		children: [
			/* @__PURE__ */ x("span", {
				className: "rn-room-name",
				children: t
			}),
			s && /* @__PURE__ */ x("span", {
				className: "rn-flood",
				"aria-hidden": !0,
				children: /* @__PURE__ */ x(m, { size: 22 })
			}),
			n && /* @__PURE__ */ x("span", {
				className: "rn-target-mark",
				"aria-hidden": !0,
				children: r === "shoot" ? /* @__PURE__ */ x(g, { size: 21 }) : r === "trap" ? /* @__PURE__ */ x(_, { size: 20 }) : x(r === "start" ? f : h, { size: 21 })
			}),
			i && /* @__PURE__ */ S("span", {
				className: "rn-pawn",
				title: u,
				"aria-hidden": !0,
				children: [/* @__PURE__ */ x("img", {
					src: o[l % o.length],
					alt: "",
					draggable: !1,
					style: { backgroundColor: p }
				}), /* @__PURE__ */ x("span", { children: ee })]
			}),
			a.length > 0 && /* @__PURE__ */ x("span", {
				className: "rn-traps",
				"aria-hidden": !0,
				children: a.map((e, t) => /* @__PURE__ */ S("span", {
					className: e.auto ? "rn-trap rn-trap-auto" : "rn-trap",
					children: [/* @__PURE__ */ x(_, { size: 13 }), e.auto && /* @__PURE__ */ x("small", { children: te("games.revolvernoir.trapAutoTag") })]
				}, t))
			})
		]
	});
}
function ke({ room: e, onClose: t }) {
	let n = d(), r = e ?? "foyer", i = ce[r], a = r === "basement" ? n("games.revolvernoir.floorB1") : E.includes(r) ? n("games.revolvernoir.floor2") : n("games.revolvernoir.floor1");
	return /* @__PURE__ */ x(s, {
		open: e !== null,
		onClose: t,
		label: n(K[r]),
		children: /* @__PURE__ */ S("div", {
			className: "rn-reference",
			children: [
				/* @__PURE__ */ S("div", {
					className: "rn-reference-heading",
					children: [/* @__PURE__ */ x("strong", { children: n(K[r]) }), /* @__PURE__ */ x("span", { children: a })]
				}),
				/* @__PURE__ */ S("div", {
					className: "rn-reference-row",
					children: [/* @__PURE__ */ x(h, {
						size: 22,
						"aria-hidden": !0
					}), /* @__PURE__ */ S("div", { children: [/* @__PURE__ */ x("strong", { children: n("games.revolvernoir.helpMove") }), /* @__PURE__ */ x("p", { children: D[r].map((e) => n(K[e])).join(" · ") })] })]
				}),
				/* @__PURE__ */ S("div", {
					className: "rn-reference-row",
					children: [/* @__PURE__ */ x(g, {
						size: 22,
						"aria-hidden": !0
					}), /* @__PURE__ */ S("div", { children: [/* @__PURE__ */ x("strong", { children: n("games.revolvernoir.helpShoot") }), /* @__PURE__ */ x("p", { children: O[r].map((e) => n(K[e])).join(" · ") })] })]
				}),
				/* @__PURE__ */ S("div", {
					className: "rn-reference-row",
					children: [/* @__PURE__ */ x(p, {
						size: 22,
						"aria-hidden": !0
					}), /* @__PURE__ */ S("div", { children: [/* @__PURE__ */ x("strong", { children: n("games.revolvernoir.helpEffect") }), /* @__PURE__ */ x("p", { children: i ? `${n(xe[i.id])} · ${i.ap} AP — ${n(q[i.id])}` : n("games.revolvernoir.helpNoEffect") })] })]
				})
			]
		})
	});
}
//#endregion
//#region src/games/revolvernoir/bot.ts
function Ae(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function je(e, t, n) {
	let r = new Set(T), i = (e) => {
		let t = /* @__PURE__ */ new Set();
		for (let n of e) for (let e of D[n]) t.add(e);
		return t;
	};
	for (let a of e) a.k === "shoot" ? a.by === n ? r = i([a.from]) : a.hit ? r = /* @__PURE__ */ new Set([a.target]) : r.delete(a.target) : a.k === "move" && a.by === n ? r = i(r) : a.k === "answer" && a.by === n ? r = new Set([...r].filter((e) => D[e].includes(a.room))) : a.k === "effect" && a.by === n ? r = /* @__PURE__ */ new Set([a.room]) : a.k === "jump" && a.by === n ? r = /* @__PURE__ */ new Set(["kitchen"]) : (a.k === "reveal" && a.by === n || a.k === "detonate" && a.by === t && a.hit) && (r = /* @__PURE__ */ new Set([a.room]));
	return r.size === 0 && (r = new Set(T)), r;
}
function Me(e, t, n) {
	let r = e.filter((e) => !(e === "basement" && n)), i = r.length ? r : [...e], a = i[0], o = -1;
	for (let e of i) {
		let n = O[e].filter((e) => t.has(e)).length;
		n > o && (a = e, o = n);
	}
	return a;
}
var Ne = (e, t) => {
	let n = e.public, r = e.private, i = t.rid, a = n.players.find((e) => e.rid !== i)?.rid;
	if (!r || !a) return null;
	let o = r.pos;
	if (n.phase === "pick") return o === null ? { action: {
		type: "pickStart",
		room: t.difficulty === "weak" ? Ae(T) : "foyer"
	} } : null;
	if (n.phase !== "play" || !o) return null;
	if (n.pending) {
		let e = n.pending;
		if (e.who !== i) return null;
		if (e.kind === "listen") {
			let e = D[o], t = e[0], n = -1;
			for (let r of e) {
				let e = T.filter((e) => D[e].includes(r)).length;
				e > n && (t = r, n = e);
			}
			return { action: {
				type: "answer",
				room: t
			} };
		}
		let r = D[o].filter((e) => !(e === "basement" && n.flooded));
		return { action: {
			type: "forcedMove",
			room: t.difficulty === "weak" ? Ae(r) : Me(r, je(n.log, i, a), n.flooded)
		} };
	}
	if (n.turn !== i || n.startPending) return null;
	let s = n.ap;
	if (t.difficulty === "weak") {
		if (s >= 2 && crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 4 == 0) return { action: {
			type: "shoot",
			room: Ae(O[o])
		} };
		if (s >= 1) {
			let e = D[o].filter((e) => !(e === "basement" && n.flooded));
			if (e.length) return { action: {
				type: "move",
				room: Ae(e)
			} };
		}
		return { action: { type: "endTurn" } };
	}
	let c = je(n.log, i, a), l = t.memory ?? {}, u = (e, t = {}) => ({
		action: e,
		memory: {
			...l,
			...t
		}
	}), d = r.traps.find((e) => c.has(e.room) && c.size <= 2);
	if (d && s >= 1) return u({
		type: "detonate",
		room: d.room
	});
	if (s >= 2 && c.size <= 4) {
		let e = O[o].find((e) => c.has(e));
		if (e) return u({
			type: "shoot",
			room: e
		});
	}
	let f = [...c].sort().join(",");
	if (o === "foyer" && [...c].some((e) => E.includes(e)) && l.echoBelief !== f) return u({ type: "effect" }, { echoBelief: f });
	if (o === "bedroom" && s >= 1 && c.has("basement") || o === "library" && s >= 1 && c.has("kitchen")) return u({ type: "effect" });
	if (s >= 3 && c.size >= 4 && l.prevBelief !== c.size) return u({ type: "listen" }, { prevBelief: c.size });
	if (s >= 1) {
		let e = O[o].filter((e) => c.has(e)).length, t = D[o].filter((e) => !(e === "basement" && n.flooded) && e !== l.lastPos), r = D[o].filter((e) => !(e === "basement" && n.flooded)), i = t.length ? t : r;
		if (i.length) {
			let t = Me(i, c, n.flooded);
			if (O[t].filter((e) => c.has(e)).length > e || s >= 3 && t !== o) return u({
				type: "move",
				room: t
			}, { lastPos: o });
		}
	}
	return s >= 1 && r.traps.length < 2 && !r.traps.some((e) => e.room === o) && c.size >= 3 ? u({ type: "setTrap" }) : u({ type: "endTurn" }, { lastPos: void 0 });
};
//#endregion
//#region src/games/revolvernoir/fx.tsx
function Pe({ rid: e, ctx: t, size: n }) {
	let r = e ? t.member(e) : void 0, i = v[(r?.colorIndex ?? 0) % v.length].hex;
	return /* @__PURE__ */ x("img", {
		src: o[(r?.avatar ?? 0) % o.length],
		alt: "",
		draggable: !1,
		className: "rounded-full border-2 border-ink object-contain",
		style: {
			background: i,
			width: n,
			height: n
		}
	});
}
var X = (e, t) => e.anchor(`room:${t}`), Fe = (e) => (e.anchor("rn-pawn-size")?.w ?? 32) / 32, Ie = (e) => {
	let t = e.anchor("rn-pawn-size")?.w ?? 32;
	return t > 32 ? t : 28;
}, Z = (e, t) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + e.h * .54 - t / 2,
	w: t,
	h: t
}), Q = (e) => ({
	x: e.x + e.w / 2,
	y: e.y + e.h * .54
});
function $(e, t) {
	let n = e.anchor("rn-board-viewport");
	return n ? /* @__PURE__ */ x("div", {
		className: "rn-map-fx absolute overflow-hidden",
		style: {
			left: n.x,
			top: n.y,
			width: n.w,
			height: n.h
		},
		children: /* @__PURE__ */ x("div", {
			className: "absolute",
			style: {
				left: -n.x,
				top: -n.y,
				width: n.w,
				height: n.h
			},
			children: t
		})
	}) : t;
}
function Le({ from: e, to: t, hit: n, size: r }) {
	let i = d(), a = Q(e), o = Q(t), s = r * 2.5, c = Math.min(a.x, o.x) - s, l = Math.min(a.y, o.y) - s, u = Math.max(a.x, o.x) - Math.min(a.x, o.x) + s * 2, f = Math.max(a.y, o.y) - Math.min(a.y, o.y) + s * 2;
	return /* @__PURE__ */ x("svg", {
		className: "rn-shot-fx absolute overflow-visible",
		style: {
			left: c,
			top: l,
			width: u,
			height: f
		},
		viewBox: `0 0 ${u} ${f}`,
		"aria-hidden": !0,
		children: /* @__PURE__ */ x(ve, {
			from: {
				x: a.x - c,
				y: a.y - l
			},
			target: {
				x: o.x - c,
				y: o.y - l
			},
			size: r,
			variant: "fx",
			hit: n,
			sourceLabel: i("games.revolvernoir.shotFired"),
			targetLabel: i("games.revolvernoir.shotTarget")
		})
	});
}
function Re({ room: e, size: t }) {
	let n = d(), r = Q(e);
	return /* @__PURE__ */ x("svg", {
		className: "rn-sound-fx absolute overflow-visible",
		style: {
			left: r.x - t,
			top: r.y - t,
			width: t * 2,
			height: t * 2
		},
		viewBox: `0 0 ${t * 2} ${t * 2}`,
		"aria-hidden": !0,
		children: /* @__PURE__ */ x(ye, {
			at: {
				x: t,
				y: t
			},
			size: t,
			variant: "fx",
			label: n("games.revolvernoir.answerClue")
		})
	});
}
var ze = {
	start() {
		return {
			ms: 500,
			node: null
		};
	},
	move(e, t) {
		let n = e.secret;
		if (!n?.from || !n.to) return null;
		let r = X(t, n.from), i = X(t, n.to);
		if (!r || !i) return null;
		let a = Ie(t), o = 44 * Fe(t);
		return {
			ms: 420,
			node: $(t, /* @__PURE__ */ S(b, { children: [
				/* @__PURE__ */ x("span", {
					className: "rn-move-takeoff absolute",
					style: {
						left: Q(r).x - o / 2,
						top: Q(r).y - o / 2,
						width: o,
						height: o
					}
				}),
				/* @__PURE__ */ x(C, {
					from: Z(r, a),
					to: Z(i, a),
					ms: 380,
					children: /* @__PURE__ */ x(Pe, {
						rid: t.myRid,
						ctx: t,
						size: a
					})
				}),
				/* @__PURE__ */ x("span", {
					className: "rn-move-landing absolute",
					style: {
						left: Q(i).x - o / 2,
						top: Q(i).y - o / 2,
						width: o,
						height: o,
						fontSize: 15 * Fe(t)
					},
					children: "••"
				})
			] }))
		};
	},
	shoot(e, t) {
		let n = e.data;
		if (!n?.from || !n.target) return null;
		let r = X(t, n.from), i = X(t, n.target);
		if (!r || !i) return null;
		let a = n.hit === !0;
		return {
			ms: a ? 1050 : 850,
			node: $(t, /* @__PURE__ */ x(Le, {
				from: r,
				to: i,
				hit: a,
				size: 40 * Fe(t)
			}))
		};
	},
	listen(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ x(w, {
				at: n,
				ms: 500
			})
		} : null;
	},
	answer(e, t) {
		let n = e.data?.room, r = n ? X(t, n) : null;
		return r ? {
			ms: 800,
			node: $(t, /* @__PURE__ */ x(Re, {
				room: r,
				size: 62 * Fe(t)
			}))
		} : null;
	},
	setTrap(e, t) {
		let n = e.secret, r = n?.room ? X(t, n.room) : null;
		return r ? {
			ms: 600,
			node: $(t, /* @__PURE__ */ x(w, {
				at: r,
				ms: 600
			}))
		} : null;
	},
	detonate(e, t) {
		let n = e.data, r = n?.room ? X(t, n.room) : null;
		return r ? {
			ms: n?.auto ? F : 900,
			node: $(t, /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x(w, {
				at: r,
				ms: 700
			}), /* @__PURE__ */ x(w, {
				at: r,
				ms: 700,
				delay: 220
			})] }))
		} : null;
	},
	effect(e, t) {
		let n = e.data;
		if (!n?.room) return null;
		let r = X(t, n.room);
		if (!r) return null;
		let i = e.secret, a = Ie(t), o = [/* @__PURE__ */ x(w, {
			at: r,
			ms: 700
		}, "p")];
		if (n.effect === "jump") {
			let n = X(t, "kitchen");
			n && o.push(/* @__PURE__ */ x(C, {
				from: Z(r, a),
				to: Z(n, a),
				ms: 380,
				children: /* @__PURE__ */ x(Pe, {
					rid: e.rid,
					ctx: t,
					size: a
				})
			}, "j"));
		}
		if (n.effect === "trapdoor" && i?.dumped) {
			let e = X(t, "basement");
			e && o.push(/* @__PURE__ */ x(C, {
				from: Z(X(t, "kitchen") ?? r, a),
				to: Z(e, a),
				ms: 420,
				children: /* @__PURE__ */ x(Pe, {
					rid: t.myRid,
					ctx: t,
					size: a
				})
			}, "d"));
		}
		return {
			ms: 800,
			node: $(t, o)
		};
	},
	reveal(e, t) {
		let n = e.data?.room, r = n ? X(t, n) : null;
		return r ? {
			ms: 900,
			node: $(t, /* @__PURE__ */ S(b, { children: [/* @__PURE__ */ x(w, {
				at: r,
				ms: 600
			}), /* @__PURE__ */ x(w, {
				at: r,
				ms: 600,
				delay: 300
			})] }))
		} : null;
	},
	turn(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 400,
			node: /* @__PURE__ */ x(w, {
				at: n,
				ms: 400
			})
		} : null;
	}
};
//#endregion
//#region src/games/revolvernoir/game-over.tsx
function Be(e) {
	return /* @__PURE__ */ x("div", {
		className: "rn-over",
		children: /* @__PURE__ */ x(oe, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: se.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/revolvernoir/entry.tsx
var Ve = {
	definition: ge,
	View: be,
	bot: Ne,
	fx: ze,
	OverView: Be,
	locales: {
		zh: {
			name: "黑色左轮",
			desc: "藏进大宅,听音辨位,先中两枪者出局",
			rules: "目标:率先命中对手两枪的人获胜。\n准备:\n· 两人各自秘密挑选一个房间作为起始位置。\n· 八间房的移动路线、射击范围与房间效果各不相同。点击房间可以查看对应说明。\n流程:轮流行动,每回合默认 2 点行动力。\n· 从厨房开始回合的人有 3 点行动力。\n· 移动（1 点行动力）：进入一间相邻房间，目的地对对手保密。\n· 射击（2 点行动力）：向射程内的一间房间开枪。射击会暴露你的位置，之后必须免费移动一步。\n· 听音（1 点行动力）：对手须公开一间其当前可以移动到的房间。\n· 设置陷阱（1 点行动力）：在当前房间布置陷阱，最多同时持有两枚陷阱。可以花费 1 点行动力，引爆已经布置的陷阱，炸伤引爆时位于该房间中的人。\n房间效果：发动房间效果会暴露你的位置。\n· 门厅回声：免费执行听音，并要求位于二楼的对手报告确切位置。\n· 卧室放水：淹没地下室，使其中的人受到伤害并离开；直到你的下个回合，地下室均无法进入。\n· 书房暗门：将厨房中的人移入地下室。\n· 地下室控制面板：在任意其他房间布置自动陷阱，在你的下回合开始时自动引爆。\n· 阳台：可以免费翻越栏杆，直接进入厨房。\n结束:\n· 任意一方累计中枪两次,另一方立即获胜。",
			rooms: {
				basement: "地下室",
				bedroom: "卧室",
				dining: "餐厅",
				foyer: "门厅",
				hall: "走廊",
				kitchen: "厨房",
				library: "书房",
				balcony: "阳台"
			},
			effects: {
				echoes: "回声",
				flood: "开闸放水",
				trapdoor: "暗门开关",
				controlpanel: "控制面板",
				jump: "翻越栏杆"
			},
			effectDesc: {
				echoes: "免费听音一次;对手在二楼则须报出确切位置",
				flood: "淹没地下室:其中的人受伤并须立刻离开,直到你的下个回合无法进入",
				trapdoor: "厨房里的人立刻被倒进地下室",
				controlpanel: "在任意其他房间布置自动陷阱,你的下回合开始时自动引爆",
				jump: "免费直接进入厨房"
			},
			effectButton: {
				echoes: "回声",
				flood: "放水",
				trapdoor: "暗门",
				controlpanel: "面板",
				jump: "翻栏"
			},
			floor2: "二楼",
			floor1: "一楼",
			floorB1: "地下室",
			pickStart: "选择你的起始房间",
			waitingPick: "已就位,等对手选择起始房间…",
			yourTurn: "你的回合",
			opponentTurn: "对手行动中…",
			apChip: "{{n}} 行动力",
			actMove: "移动",
			actShoot: "射击",
			actListen: "听音",
			actSetTrap: "设陷阱",
			actDetonate: "引爆",
			actEffect: "房间效果",
			actEndTurn: "结束回合",
			chooseMoveTarget: "点选要移动到的房间",
			chooseShootTarget: "点选要射击的房间(开枪会暴露你的位置)",
			chooseDetonateTarget: "点选要引爆的陷阱",
			chooseTrapTarget: "点选自动陷阱的目标房间",
			chooseReplaceTrap: "陷阱已满两枚:先点选要撤掉的一枚",
			targetStart: "选择{{room}}作为起点",
			targetMove: "移动到{{room}}",
			targetShoot: "射击{{room}}",
			targetTrap: "操作{{room}}的陷阱",
			myRoom: "你位于{{room}}",
			forcedMovePrompt: "开枪暴露了你的位置:免费移动一步",
			forcedMoveShort: "开枪后移动一步",
			evacPrompt: "你必须立刻离开:点选要移动到的房间",
			evacShort: "立即离开房间",
			listenAnswerPrompt: "对手正在听音:公开一间你可以移动到的房间",
			listenAnswerShort: "对手正在听音",
			waitingListenAnswer: "等待对手回答听音…",
			waitingListenShort: "等待听音回答…",
			waitingForcedMove: "等待对手移动…",
			floodedBanner: "地下室水淹中",
			startPending: "回合开始,自动陷阱引爆中…",
			startPendingShort: "自动陷阱引爆中…",
			trapAutoTag: "自动",
			hitsChip: "中枪 {{n}}/2",
			helpMove: "移动可达",
			helpShoot: "射击范围",
			helpEffect: "房间效果",
			helpNoEffect: "无",
			logStart: "双方就位,对决开始",
			logMove: "{{name}} 悄悄移动了",
			logShootHit: "{{name}} 从{{from}}向{{target}}开枪——命中!",
			logShootMiss: "{{name}} 从{{from}}向{{target}}开枪——落空",
			logListen: "{{name}} 驻足听音",
			logAnswer: "{{name}} 公开可移动到{{room}}",
			shotPrevious: "上一枪",
			shotFired: "开枪时",
			shotTarget: "目标",
			answerClue: "可移动到",
			opponentFootsteps: "咚 · 咚  对手移动了",
			logSetTrap: "{{name}} 设下了陷阱",
			logDetonateHit: "{{name}} 引爆{{room}}的陷阱——命中!",
			logDetonateMiss: "{{name}} 引爆{{room}}的陷阱——无人中招",
			logDetonateAutoHit: "{{name}} 的自动陷阱在{{room}}引爆——命中!",
			logDetonateAutoMiss: "{{name}} 的自动陷阱在{{room}}引爆——无人中招",
			logEffect: "{{name}} 在{{room}}发动了「{{effect}}」",
			logReveal: "{{name}} 暴露了自己的位置:{{room}}",
			logJump: "{{name}} 翻越栏杆跳进了厨房",
			errNotYourTurn: "现在轮不到你",
			errPending: "先完成当前必须做的动作",
			errBadRoom: "这个房间不能选",
			errNoAp: "行动力不足",
			errNoEffect: "这个房间没有可以发动的效果",
			errNoTrap: "没有可以这样操作的陷阱",
			errFlooded: "地下室正被水淹,进不去"
		},
		en: {
			name: "Revolver Noir",
			desc: "Hide in the mansion, listen, deduce — two hits and you are out",
			rules: "Goal: the first to land two hits on the opponent wins.\nSetup:\n· Each player secretly picks a room as their starting position.\n· The eight rooms differ in move links, shooting range and effects.\nTurns: take turns with 2 action points per turn.\n· Starting your turn in the Kitchen grants 3 action points.\n· Move (1 point): enter an adjacent room; the destination stays secret.\n· Shoot (2 action points): Fire at a room in range. Shooting reveals your position, then you must move one step for free.\n· Listen (1 action point): Your opponent must name one room they can currently move to.\n· Set a trap (1 action point): Arm a trap in your current room. You may have at most two armed traps. Spend 1 action point to detonate an armed trap, hurting whoever is in that room at the time.\nRoom effects:\nUsing a room effect reveals your position.\n· Foyer: Listen for free. An opponent upstairs must also name their exact room.\n· Bedroom: Flood the Basement, hurting and expelling anyone inside. The Basement remains sealed until your next turn.\n· Library: Move anyone in the Kitchen into the Basement.\n· Basement: Arm an automatic trap in any other room. It detonates for free at the start of your next turn.\n· Balcony: Vault the railing to enter the Kitchen for free.\nEnd:\n· As soon as a player has been hit twice, the other player wins.",
			rooms: {
				basement: "Basement",
				bedroom: "Bedroom",
				dining: "Dining Room",
				foyer: "Foyer",
				hall: "Hall",
				kitchen: "Kitchen",
				library: "Library",
				balcony: "Balcony"
			},
			effects: {
				echoes: "Echoes",
				flood: "Flood Lever",
				trapdoor: "Trap Door",
				controlpanel: "Control Panel",
				jump: "Vault the Railing"
			},
			effectDesc: {
				echoes: "A free Listen; an opponent upstairs must name their exact room",
				flood: "Flood the Basement: anyone inside is hurt and must leave; sealed until your next turn",
				trapdoor: "Whoever is in the Kitchen is dumped into the Basement",
				controlpanel: "Arm an auto-trap in any other room; it detonates at the start of your next turn",
				jump: "Enter the Kitchen directly for free"
			},
			effectButton: {
				echoes: "Echo",
				flood: "Flood",
				trapdoor: "Trapdoor",
				controlpanel: "Panel",
				jump: "Vault"
			},
			floor2: "Upstairs",
			floor1: "Ground floor",
			floorB1: "Basement",
			pickStart: "Pick your starting room",
			waitingPick: "In position, waiting for your opponent…",
			yourTurn: "Your turn",
			opponentTurn: "Opponent is acting…",
			apChip: "{{n}} AP",
			actMove: "Move",
			actShoot: "Shoot",
			actListen: "Listen",
			actSetTrap: "Arm trap",
			actDetonate: "Detonate",
			actEffect: "Effect",
			actEndTurn: "End turn",
			chooseMoveTarget: "Tap a room to move into",
			chooseShootTarget: "Tap a room to shoot (shooting reveals your position)",
			chooseDetonateTarget: "Tap a trap to detonate",
			chooseTrapTarget: "Tap the target room for the auto-trap",
			chooseReplaceTrap: "Two traps armed already: tap one to disarm first",
			targetStart: "Start in {{room}}",
			targetMove: "Move to {{room}}",
			targetShoot: "Shoot {{room}}",
			targetTrap: "Trap action in {{room}}",
			myRoom: "You are in {{room}}",
			forcedMovePrompt: "Your shot gave you away: move one step for free",
			forcedMoveShort: "Move after shooting",
			evacPrompt: "You must leave at once: tap a room to move into",
			evacShort: "Leave this room now",
			listenAnswerPrompt: "The opponent is listening: name one room you can move to",
			listenAnswerShort: "Opponent is listening",
			waitingListenAnswer: "Waiting for the opponent to answer…",
			waitingListenShort: "Waiting for an answer…",
			waitingForcedMove: "Waiting for the opponent to move…",
			floodedBanner: "Basement flooded",
			startPending: "Turn begins — auto-traps going off…",
			startPendingShort: "Auto-traps going off…",
			trapAutoTag: "auto",
			hitsChip: "Hits {{n}}/2",
			helpMove: "Can move to",
			helpShoot: "Can shoot",
			helpEffect: "Room effect",
			helpNoEffect: "None",
			logStart: "Both in position — the duel begins",
			logMove: "{{name}} moved quietly",
			logShootHit: "{{name}} fired from {{from}} at {{target}} — hit!",
			logShootMiss: "{{name}} fired from {{from}} at {{target}} — missed",
			logListen: "{{name}} stopped to listen",
			logAnswer: "{{name}} named {{room}} as a room they can move to",
			shotPrevious: "LAST SHOT",
			shotFired: "FIRED FROM",
			shotTarget: "TARGET",
			answerClue: "CAN MOVE TO",
			opponentFootsteps: "THUD · THUD  Opponent moved",
			logSetTrap: "{{name}} armed a trap",
			logDetonateHit: "{{name}} detonated the trap in {{room}} — hit!",
			logDetonateMiss: "{{name}} detonated the trap in {{room}} — nobody there",
			logDetonateAutoHit: "{{name}}'s auto-trap in {{room}} went off — hit!",
			logDetonateAutoMiss: "{{name}}'s auto-trap in {{room}} went off — nobody there",
			logEffect: "{{name}} triggered {{effect}} in {{room}}",
			logReveal: "{{name}} gave away their position: {{room}}",
			logJump: "{{name}} vaulted the railing into the Kitchen",
			errNotYourTurn: "Not your turn right now",
			errPending: "Finish the required action first",
			errBadRoom: "That room is not a legal choice",
			errNoAp: "Not enough action points",
			errNoEffect: "This room has no effect to trigger",
			errNoTrap: "No trap can be used that way",
			errFlooded: "The Basement is flooded — no entry"
		}
	}
};
//#endregion
export { Ve as default };
