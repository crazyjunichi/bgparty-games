import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { isBotRid as t } from "@bgparty/sdk/lobby";
import { z as n } from "zod";
import { useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { SheetFxProbe as u, SheetView as d } from "@bgparty/sdk/sheet-view";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { useFxAnchor as _ } from "@bgparty/sdk/fx/anchors";
import { playSettle as v, playTurn as y, useSoundEdge as b } from "@bgparty/sdk/sfx";
import { Floater as x, FlySprite as S, PulseBox as ee } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as C } from "@bgparty/sdk/ui/game-over-screen";
var w = /* @__PURE__ */ "#602b0e.#6a270f.#752114.#841d18.#931d1e.#9e1b1f.#af1d23.#c52126.#e01d26.#ed1b23.#ec1d22.#ee1b25.#ec1b2c.#ee193b.#ec1845.#e91654.#e51464.#e11074.#d70e82.#d3148c.#c72791.#bb2c90.#b33294.#a83492.#9e3893.#923895.#8b3d97.#823c96.#7c3d98.#73409a.#864b1f.#93441f.#9b3e20.#ab3f24.#b93725.#c52c27.#d62826.#e41f24.#ed2225.#ee2729.#ee2832.#ed253a.#ee1f41.#ed1f4c.#ed1b5e.#ed156e.#ed0f7b.#ea0b8d.#db2a92.#cc3894.#be3e98.#b33d97.#a83c97.#9d3e96.#953d96.#8c3c96.#833e96.#7c3e98.#723c96.#683b95.#a46129.#ab5a26.#ba5927.#c24d27.#cd4726.#d63f27.#e13826.#e92f25.#ee352c.#ee3c40.#ee3e4c.#ed3b50.#ee3a5d.#ee3167.#ed3077.#ee2a87.#eb3095.#da4298.#ca489b.#bb4b9d.#b4489b.#a54798.#9d4498.#944396.#8b4298.#833d96.#783c96.#723c96.#653996.#5a3090.#c98129.#d78128.#dd7626.#e87723.#e66925.#ea5d24.#f15f2b.#ef5433.#ef4e3d.#ef5550.#f05c64.#f05d6a.#ef5771.#ef537d.#ee4e8b.#f04e9c.#de55a0.#cd56a1.#bd5ea5.#b558a2.#a553a1.#9a4e9d.#944b9e.#8d499d.#814399.#7a4097.#6e3d99.#663694.#583392.#472e89.#e59b22.#f0981e.#f6921b.#f58c1d.#f58525.#f4782e.#f4773d.#f36d45.#f27052.#f17766.#f27574.#f27681.#f17789.#f17093.#ef68a3.#e66fab.#d370ac.#c770ae.#ba70ae.#ac66a9.#9e5ea6.#9259a4.#8c53a3.#84509f.#7a479d.#6e449b.#613e97.#583293.#482e8e.#322b84.#fdb315.#fbb023.#faaa2c.#fbaa39.#faa640.#f9a34b.#f69655.#f68e5e.#f38863.#f48872.#f58e83.#f38e8f.#f48e98.#f48ca3.#f286b4.#e08cbb.#d18bbc.#c58cbe.#b982b9.#a97ab6.#9b74b2.#9066aa.#855da7.#7a59a5.#7151a1.#63499d.#59419a.#4b3292.#382f8f.#2c2878.#fcc112.#fcc029.#fcb62c.#fdb33b.#fcb95e.#f9aa56.#faa964.#f9a16d.#f7a278.#f79f84.#f69d93.#f69c99.#f59da6.#f69aaa.#f39cc1.#e0a5ca.#cfa6cc.#cdacd2.#b798c7.#a78bc1.#9a82bc.#8976b5.#7f6eb1.#7264ad.#675ca8.#5954a4.#4f4aa0.#44409a.#303694.#2b2f85.#fbd016.#fdcd29.#fec72e.#fdc740.#fdc64b.#fcbf57.#fbbb5f.#fbb86b.#fbb279.#faaf82.#f9ae8e.#f8b29d.#f4b6ad.#f3b5b4.#ebb5c8.#d7b6d5.#cdb7d9.#ccbcdc.#b4a8d2.#a79fce.#9793c9.#8287c2.#747dbc.#6a74b6.#5b6ab1.#5160ad.#4759a6.#3d4fa0.#2f449c.#243996.#fbe117.#fcdb26.#fcd932.#fbd843.#fbdd4b.#fdd858.#fcdb60.#fad66b.#f4db7c.#f0df91.#ebdc9d.#e7e1b3.#e1dfc2.#dce0cb.#d1dfd2.#c6dde2.#c1d8f1.#bfd8ef.#a6c8e8.#99b8e0.#8aa9da.#7aa1d6.#7092cb.#6585c2.#5678bb.#4c6bb5.#4261ad.#3b5aa8.#324fa0.#27459c.#f9eb23.#f9ea29.#f9eb36.#f9ed44.#f8f04c.#f8f15b.#f7f06a.#eeee81.#e7eb8b.#dde89d.#d7e7ac.#d3e8bf.#d0e8cb.#cde8d3.#c7e5d6.#bbe5e3.#b3e2f2.#b2e2f5.#9edbf5.#86d5f7.#7dc6ee.#71b5e3.#64a8dc.#5c96d0.#518ac9.#4a7cbf.#3f6db6.#3665af.#355baa.#2e50a3.#f6ef3b.#f6ee3f.#f4ed47.#f3ef4d.#f0ec5a.#eceb68.#e6e879.#dee783.#d6e385.#c7df8d.#bedd96.#b5daa2.#b3daae.#b0d9b6.#acdac1.#aedcd6.#aadcde.#a8dde2.#98d8e6.#88d6ee.#72d1f5.#63cbf4.#5fbbea.#5aaadd.#539dd3.#4789c9.#3d7dc0.#3b6fb7.#3663af.#335caa.#f0eb21.#f0eb2d.#ebe932.#e9e738.#e5e543.#dce352.#d0df5f.#bfd966.#b1d66c.#a7d376.#9fcf7d.#98cf88.#91cd98.#8ccc9b.#8ecea6.#8dceb2.#8ed0c0.#8bd0c5.#84cecb.#7acdd2.#68cad9.#55c8df.#3ac6ef.#38b9ec.#3ba9e1.#3a99d4.#4088c8.#3779bc.#3b6eb8.#3365b0.#e0e220.#dae027.#d5e12f.#cede38.#c8db42.#b9d545.#aed14c.#9fcc50.#8fc957.#84c65e.#79c368.#71c271.#70c17a.#6cc182.#6ec28a.#70c393.#70c49d.#73c6a6.#75c7ab.#6bc6b3.#5fc6ba.#53c4c5.#47c2ce.#30c1da.#1bb9e3.#20a9e1.#289bd7.#368ccb.#317ec0.#2b72b7.#c1d72d.#bdd530.#b4d332.#abce39.#a0cb38.#93c93d.#81c240.#78c142.#6dbb44.#5db445.#54b24b.#4db154.#46b758.#49b769.#4fbb72.#56bd7b.#58bd7c.#5bbf87.#5fbf8b.#60bf91.#5bbf9e.#4fc1ab.#46bfb3.#35bfc3.#27becc.#16b9d8.#0eaede.#16a5dc.#2394d2.#2883c5.#9dc439.#9ac33c.#94c13c.#88be41.#7dbb42.#6cb341.#63b044.#54a845.#4ea646.#409e45.#349c47.#30a248.#2aa94a.#2ab04a.#31b453.#37b55d.#42b764.#46b86e.#48b972.#51bb76.#52bd85.#49bc90.#44bd9e.#38bea9.#2ebcb6.#28bfc6.#1abcd3.#0eb2d3.#0ea8d9.#179eda.#7ba440.#75a93f.#6fa643.#64a243.#59a445.#4c9e45.#429745.#399544.#299043.#1e8842.#198b43.#149044.#149a46.#17a049.#1baa4a.#1fb14b.#2bb34c.#33b454.#3ab55d.#3eb764.#3fb870.#39b97b.#32b989.#2bb995.#21baa1.#19bbab.#18bcbc.#13bcc6.#10b7d6.#0eb1e2".split(".");
function T(e) {
	let t = Math.floor(e / 30), n = e % 30;
	return `${String.fromCharCode(65 + t)}${n + 1}`;
}
//#endregion
//#region src/games/huesandcues/meta.ts
var E = {
	id: "huesandcues",
	tier: "released",
	mechanics: ["word-association"],
	interactionTags: [],
	nameKey: "games.huesandcues.name",
	descKey: "games.huesandcues.desc",
	rulesKey: "games.huesandcues.rules",
	icon: "🎨",
	iconImg: "games/huesandcues.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/0611/3958/3198/files/Hue_and_Cues_Rules.pdf?v=1650995573" },
	minPlayers: 3,
	maxPlayers: 10,
	bestPlayers: [6, 8],
	accent: "#d946ef",
	releasedAt: "2026-10-01",
	search: {
		py: "qiao yan hui se",
		init: "qyhs"
	},
	hotseat: "cover"
}, D = n.string(), O = n.int().min(0).max(479), k = n.string().trim().min(1).max(16), A = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("pick"),
		cell: O
	}),
	n.object({
		type: n.literal("clue"),
		text: k
	}),
	n.object({ type: n.literal("skipClue2") }),
	n.object({
		type: n.literal("place"),
		cell: O
	}),
	n.object({ type: n.literal("next") })
]), j = n.enum([
	"pick",
	"clue1",
	"place1",
	"clue2",
	"place2",
	"score",
	"done"
]), M = n.object({
	giver: D,
	clue1: n.string(),
	clue2: n.string().nullable(),
	target: O,
	giverScore: n.int().nonnegative(),
	guessers: n.array(n.object({
		rid: D,
		cells: n.array(O),
		points: n.array(n.int().min(0).max(3)),
		total: n.int().nonnegative()
	}))
}), N = n.object({
	phase: j,
	players: n.array(D),
	giver: D,
	round: n.object({
		idx: n.int().nonnegative(),
		total: n.int().nonnegative()
	}),
	clue1: n.string().nullable(),
	clue2: n.string().nullable(),
	placements: n.record(D, n.array(O)),
	placeTurn: D.nullable(),
	scores: n.record(D, n.int().nonnegative()),
	target: O.nullable(),
	rounds: n.array(M)
}), P = n.object({
	card: n.array(O).nullable(),
	target: O.nullable()
}), F = new Set((/* @__PURE__ */ "红.橙.黄.绿.青.蓝.紫.粉.白.黑.灰.棕.红色.橙色.黄色.绿色.青色.蓝色.紫色.粉色.白色.黑色.灰色.棕色.red.orange.yellow.green.cyan.blue.purple.pink.white.black.grey.gray.brown".split(".")).map((e) => e.toLowerCase()));
function I(e, t, n) {
	let r = e.trim(), i = r.split(/\s+/);
	return !t && (i.length > 1 || r.length > 8) ? { code: "games.huesandcues.errClueOneWord" } : t && i.length > 2 ? { code: "games.huesandcues.errClueTwoWords" } : F.has(r.toLowerCase()) ? { code: "games.huesandcues.errClueColor" } : n.some((e) => e.toLowerCase() === r.toLowerCase()) ? { code: "games.huesandcues.errClueUsed" } : null;
}
function L(t, n) {
	let r = [
		[0, 7],
		[8, 14],
		[15, 22],
		[23, 29]
	], i = [];
	for (let [a, o] of r) {
		let r = a + e(t, n, o - a + 1);
		n += 1;
		let s = e(t, n, 16);
		n += 1, i.push(s * 30 + r);
	}
	return {
		card: i,
		cursor: n
	};
}
function R(e, t, n) {
	let r = e.players.indexOf(t), i = [];
	for (let t = 1; t < e.players.length; t += 1) i.push(e.players[(r + t) % e.players.length]);
	return n ? i.reverse() : i;
}
function z(e, t) {
	let n = Math.floor(e / 30), r = e % 30, i = Math.floor(t / 30), a = t % 30, o = Math.abs(n - i), s = Math.abs(r - a);
	return o === 0 && s === 0 ? 3 : o <= 1 && s <= 1 ? 2 : +(o <= 2 && s <= 2);
}
function B(e) {
	let t = e.cueOrder[e.cueIdx], n = e.target, r = e.players.length === 3 ? 2 : 1, i = 0, a = [];
	for (let r of e.players) {
		if (r === t) continue;
		let o = e.placements[r] ?? [], s = o.map((e) => z(n, e));
		i += s.filter((e) => e >= 2).length;
		let c = s.reduce((e, t) => e + t, 0);
		e.scores[r] += c, a.push({
			rid: r,
			cells: o,
			points: s,
			total: c
		});
	}
	let o = Math.min(9, i * r);
	return e.scores[t] += o, {
		giver: t,
		clue1: e.clue1,
		clue2: e.clue2,
		target: n,
		giverScore: o,
		guessers: a
	};
}
function V(e) {
	let { card: t, cursor: n } = L(e.seed, e.rngCursor);
	e.rngCursor = n, e.card = t, e.target = null, e.clue1 = null, e.clue2 = null, e.placements = {}, e.placeOrder = [], e.placeIdx = 0, e.phase = "pick";
}
function H(n, r, i) {
	let a = r.filter((e) => !t(e)), o = a.length > 0 ? a : r, s = r.length <= 6 ? 2 : 1, c = 0, l = [];
	for (let t = 0; t < s; t += 1) {
		let t = [...o];
		for (let n = t.length - 1; n > 0; --n) {
			let r = e(i, c, n + 1);
			c += 1, [t[n], t[r]] = [t[r], t[n]];
		}
		l.push(...t);
	}
	let u = {
		players: r,
		seed: i,
		rngCursor: c,
		phase: "pick",
		cueOrder: l,
		cueIdx: 0,
		card: [],
		target: null,
		clue1: null,
		clue2: null,
		usedClues: [],
		placements: {},
		placeOrder: [],
		placeIdx: 0,
		scores: Object.fromEntries(r.map((e) => [e, 0])),
		rounds: []
	};
	return V(u), { state: u };
}
function U(e, t, n) {
	let r = e.cueOrder[e.cueIdx];
	if (t.type === "pick") {
		if (e.phase !== "pick" || n.by !== r) return { code: "games.huesandcues.errNotGiver" };
		if (!e.card.includes(t.cell)) return { code: "games.huesandcues.errNotOnCard" };
		let i = structuredClone(e);
		return i.target = t.cell, i.phase = "clue1", { state: i };
	}
	if (t.type === "clue") {
		if (e.phase !== "clue1" && e.phase !== "clue2" || n.by !== r) return { code: "games.huesandcues.errNotGiver" };
		let i = e.phase === "clue2", a = I(t.text, i, e.usedClues);
		if (a) return a;
		let o = structuredClone(e), s = t.text.trim();
		return i ? (o.clue2 = s, o.placeOrder = R(o, r, !0), o.placeIdx = 0, o.phase = "place2") : (o.clue1 = s, o.placeOrder = R(o, r, !1), o.placeIdx = 0, o.phase = "place1"), o.usedClues = [...o.usedClues, s], { state: o };
	}
	if (t.type === "skipClue2") {
		if (e.phase !== "clue2" || n.by !== r) return { code: "games.huesandcues.errNotGiver" };
		let t = structuredClone(e), i = B(t);
		return t.rounds = [...t.rounds, i], t.phase = "score", {
			state: t,
			fx: W(i)
		};
	}
	if (t.type === "place") {
		if (e.phase !== "place1" && e.phase !== "place2") return { code: "games.huesandcues.errNotPlacing" };
		let r = e.placeOrder[e.placeIdx];
		if (n.by !== r) return { code: "games.huesandcues.errNotYourPlace" };
		if (new Set(Object.values(e.placements).flat()).has(t.cell)) return { code: "games.huesandcues.errCellTaken" };
		let i = structuredClone(e), a = i.placements[n.by] ?? [];
		i.placements[n.by] = [...a, t.cell], i.placeIdx += 1;
		let o = [{
			kind: "place",
			rid: n.by,
			data: { cell: t.cell }
		}];
		if (i.placeIdx >= i.placeOrder.length) {
			if (i.phase === "place1") i.phase = "clue2";
			else {
				let e = B(i);
				i.rounds = [...i.rounds, e], i.phase = "score", o.push(...W(e));
			}
		}
		return {
			state: i,
			fx: o
		};
	}
	if (e.phase !== "score") return { code: "games.huesandcues.errNotScoring" };
	if (n.by !== r && n.by !== e.players[0]) return { code: "games.huesandcues.errNotGiver" };
	let i = structuredClone(e);
	return i.cueIdx + 1 >= i.cueOrder.length ? i.phase = "done" : (i.cueIdx += 1, V(i)), { state: i };
}
function W(e) {
	let t = [{
		kind: "reveal",
		data: { target: e.target }
	}];
	for (let n of e.guessers) n.total > 0 && t.push({
		kind: "score",
		rid: n.rid,
		data: { total: n.total },
		with: !0
	});
	return e.giverScore > 0 && t.push({
		kind: "score",
		rid: e.giver,
		data: { total: e.giverScore },
		with: !0
	}), t;
}
function te(e, t) {
	let n = e.cueOrder[e.cueIdx] ?? e.players[0], r = e.phase === "score" || e.phase === "done";
	return {
		public: {
			phase: e.phase,
			players: e.players,
			giver: n,
			round: {
				idx: e.cueIdx + 1,
				total: e.cueOrder.length
			},
			clue1: e.clue1,
			clue2: e.clue2,
			placements: e.placements,
			placeTurn: e.phase === "place1" || e.phase === "place2" ? e.placeOrder[e.placeIdx] : null,
			scores: e.scores,
			target: r ? e.target : null,
			rounds: e.rounds
		},
		private: t === n ? {
			card: e.card,
			target: e.target
		} : void 0
	};
}
function ne(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: e.scores
	};
}
var G = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: A,
		publicView: N,
		privateView: P
	},
	setup: H,
	reduce: U,
	viewFor: te,
	status: ne
};
function K(e) {
	return e === "portrait" ? {
		w: 1694,
		h: 3122
	} : {
		w: 3122,
		h: 1694
	};
}
function q(e, t) {
	let n = Math.floor(e / 30), r = e % 30;
	return {
		x: 56 + (t === "portrait" ? n : r) * 102,
		y: 56 + (t === "portrait" ? r : n) * 102,
		w: 96,
		h: 96
	};
}
function J({ cell: e, layout: t, color: n, initial: r, ghost: i }) {
	let a = q(e, t), o = a.x + a.w / 2, s = a.y + a.h / 2;
	return /* @__PURE__ */ g("g", {
		opacity: i ? .62 : 1,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ h("circle", {
				cx: o,
				cy: s + 4,
				r: 41.28,
				fill: "#0a0b0d"
			}),
			/* @__PURE__ */ h("circle", {
				cx: o,
				cy: s,
				r: 39.36,
				fill: n,
				stroke: "#f3f0e9",
				strokeWidth: 5.28
			}),
			/* @__PURE__ */ h("text", {
				x: o,
				y: s,
				textAnchor: "middle",
				dominantBaseline: "central",
				fontSize: 37.44,
				fontWeight: 800,
				fill: "#f3f0e9",
				children: r
			})
		]
	});
}
function Y({ target: e, layout: t }) {
	let n = q(e, t), r = n.x + n.w / 2, i = n.y + n.h / 2;
	return /* @__PURE__ */ g("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ h("rect", {
				x: r - 252,
				y: i - 252,
				width: 504,
				height: 504,
				fill: "none",
				stroke: "#f3f0e9",
				strokeWidth: 4,
				strokeDasharray: "14 14",
				opacity: .9
			}),
			/* @__PURE__ */ h("rect", {
				x: r - 150,
				y: i - 150,
				width: 300,
				height: 300,
				fill: "none",
				stroke: "#f3f0e9",
				strokeWidth: 8
			}),
			/* @__PURE__ */ h("rect", {
				x: n.x - 4,
				y: n.y - 4,
				width: 104,
				height: 104,
				fill: "none",
				stroke: "#f3f0e9",
				strokeWidth: 10
			})
		]
	});
}
function X({ cell: e, layout: t, points: n }) {
	let r = q(e, t), i = r.x + r.w - 14, a = r.y + 14;
	return /* @__PURE__ */ g("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ h("circle", {
			cx: i,
			cy: a,
			r: 20,
			fill: n > 0 ? "#f3f0e9" : "#575b60",
			stroke: "#0a0b0d",
			strokeWidth: 3
		}), /* @__PURE__ */ h("text", {
			x: i,
			y: a + 1,
			textAnchor: "middle",
			dominantBaseline: "central",
			fontSize: 24,
			fontWeight: 800,
			fill: n > 0 ? "#121417" : "#f3f0e9",
			children: n > 0 ? `+${n}` : "0"
		})]
	});
}
function re({ placements: e, members: t, selected: n, selectedColor: r, selectedInitial: i, target: a, round: o, layout: c }) {
	let d = K(c), f = (e) => t.find((t) => t.rid === e), m = s((e) => e.locale), _ = (e) => {
		let t = f(e);
		return t ? l[t.colorIndex % l.length].hex : "#57534e";
	}, v = (e) => {
		let t = f(e);
		return t ? p(t, m).charAt(0) : "?";
	}, y = (e, t) => {
		if (!o) return 0;
		let n = o.guessers.find((t) => t.rid === e);
		if (!n) return 0;
		let r = n.cells.indexOf(t);
		return r >= 0 ? n.points[r] : 0;
	};
	return /* @__PURE__ */ g("g", { children: [
		/* @__PURE__ */ h("rect", {
			x: 0,
			y: 0,
			width: d.w,
			height: d.h,
			fill: "#0a0b0d"
		}),
		Array.from({ length: 16 }, (e, t) => Array.from({ length: 30 }, (e, n) => {
			let r = q(t * 30 + n, c);
			return /* @__PURE__ */ h("rect", {
				x: r.x,
				y: r.y,
				width: r.w,
				height: r.h,
				fill: w[t * 30 + n]
			}, t * 30 + n);
		})),
		Array.from({ length: c === "portrait" ? 16 : 30 }, (e, t) => /* @__PURE__ */ h("text", {
			x: 56 + t * 102 + 48,
			y: 50,
			textAnchor: "middle",
			fontSize: 30,
			fontWeight: 700,
			fill: "#a9aaab",
			children: c === "portrait" ? String.fromCharCode(65 + t) : t + 1
		}, `x${t}`)),
		Array.from({ length: c === "portrait" ? 30 : 16 }, (e, t) => /* @__PURE__ */ h("text", {
			x: 42,
			y: 56 + t * 102 + 48,
			textAnchor: "end",
			dominantBaseline: "central",
			fontSize: 30,
			fontWeight: 700,
			fill: "#a9aaab",
			children: c === "portrait" ? t + 1 : String.fromCharCode(65 + t)
		}, `y${t}`)),
		a !== null && /* @__PURE__ */ h(Y, {
			target: a,
			layout: c
		}),
		e.map((e) => /* @__PURE__ */ h(J, {
			cell: e.cell,
			layout: c,
			color: _(e.rid),
			initial: v(e.rid)
		}, `${e.rid}:${e.cell}`)),
		o && e.map((e) => /* @__PURE__ */ h(X, {
			cell: e.cell,
			layout: c,
			points: y(e.rid, e.cell)
		}, `s${e.rid}:${e.cell}`)),
		n !== null && /* @__PURE__ */ g("g", {
			pointerEvents: "none",
			children: [(() => {
				let e = q(n, c);
				return /* @__PURE__ */ h("rect", {
					x: e.x - 4,
					y: e.y - 4,
					width: e.w + 8,
					height: e.h + 8,
					fill: "none",
					stroke: "#f3f0e9",
					strokeWidth: 7
				});
			})(), /* @__PURE__ */ h(J, {
				cell: n,
				layout: c,
				color: r,
				initial: i,
				ghost: !0
			})]
		}),
		e.map((e) => /* @__PURE__ */ h(u, {
			name: `cell:${e.cell}`,
			r: q(e.cell, c)
		}, `fp${e.rid}:${e.cell}`)),
		a !== null && /* @__PURE__ */ h(u, {
			name: `cell:${a}`,
			r: q(a, c)
		})
	] });
}
//#endregion
//#region src/games/huesandcues/chrome.tsx
function Z({ member: e, myRid: t, score: n, action: r }) {
	let { ref: i } = _(`seat:${e.rid}`), a = s((e) => e.locale), o = c(), u = p(e, a), d = l[e.colorIndex % l.length].hex;
	return /* @__PURE__ */ g("li", {
		className: `hc-seat ${e.online ? "" : "hc-seat-offline"}`,
		"aria-label": `${u}: ${n}`,
		children: [/* @__PURE__ */ g("div", {
			className: "hc-seat-name",
			children: [/* @__PURE__ */ h("span", {
				ref: i,
				className: "hc-seat-color",
				style: { backgroundColor: d },
				"aria-hidden": !0
			}), /* @__PURE__ */ h("span", {
				className: "hc-seat-label",
				children: u
			})]
		}), /* @__PURE__ */ g("span", {
			className: "hc-seat-score font-mono tabular-nums",
			children: [
				String(n).padStart(2, "0"),
				e.rid === t && /* @__PURE__ */ h("small", {
					className: "hc-seat-you",
					children: o("lobby.you")
				}),
				r === "pending" && /* @__PURE__ */ h("small", {
					className: "hc-seat-action",
					"aria-label": o("lobby.thinking"),
					children: "…"
				}),
				r === "done" && /* @__PURE__ */ h("small", {
					className: "hc-seat-action",
					"aria-label": o("lobby.done"),
					children: "✓"
				}),
				!e.online && /* @__PURE__ */ h("small", {
					className: "hc-seat-action",
					children: o("lobby.offline")
				})
			]
		})]
	});
}
function ie({ members: e, myRid: t, scores: n, round: r, kicker: i, title: a, needsAction: o, actionOf: s }) {
	return b(o, y), /* @__PURE__ */ g("div", {
		className: "hc-chrome",
		role: "status",
		children: [/* @__PURE__ */ g("div", {
			className: "hc-head",
			children: [/* @__PURE__ */ g("div", {
				className: "hc-head-left",
				children: [/* @__PURE__ */ h("span", {
					className: "hc-kicker",
					children: i
				}), /* @__PURE__ */ h("strong", {
					className: "hc-title",
					title: a,
					children: a
				})]
			}), /* @__PURE__ */ g("span", {
				className: "hc-round font-mono tabular-nums",
				children: [
					String(r.idx).padStart(2, "0"),
					" / ",
					String(r.total).padStart(2, "0")
				]
			})]
		}), /* @__PURE__ */ h("ul", {
			className: "hc-seats",
			children: e.map((e) => /* @__PURE__ */ h(Z, {
				member: e,
				myRid: t,
				score: n[e.rid] ?? 0,
				action: s(e.rid)
			}, e.rid))
		})]
	});
}
//#endregion
//#region src/games/huesandcues/view-player.tsx
function Q(e) {
	let t = e.public, n = e.private, { members: u, myRid: _, send: v } = e, y = c(), b = s((e) => e.locale), x = a(null), [S, ee] = o("");
	r(() => {
		let e = x.current;
		if (!e) return;
		let t = () => {
			let t = `${e.clientWidth}x${e.clientHeight}`;
			ee((e) => e === t ? e : t);
		}, n = new ResizeObserver(t);
		return n.observe(e), t(), () => n.disconnect();
	}, []);
	let [C, E] = o(() => window.matchMedia("(orientation: landscape)").matches ? "wide" : "portrait");
	r(() => {
		let e = window.matchMedia("(orientation: landscape)"), t = () => E(e.matches ? "wide" : "portrait");
		return e.addEventListener("change", t), document.body.classList.add("hc-body"), () => {
			e.removeEventListener("change", t), document.body.classList.remove("hc-body");
		};
	}, []);
	let D = t.giver === _, O = t.placeTurn === _, k = t.players[0] === _, [A, j] = o(null), [M, N] = o(null), [P, F] = o(""), I = `${t.round.idx}:${t.phase}`, [L, R] = o(I);
	L !== I && (R(I), j(null), N(null), F(""));
	let z = (e) => {
		let t = u.find((t) => t.rid === e);
		return t ? p(t, b) : "?";
	}, B = i(() => {
		let e = u.find((e) => e.rid === _);
		return e ? l[e.colorIndex % l.length].hex : "#57534e";
	}, [u, _]), V = i(() => Object.entries(t.placements).flatMap(([e, t]) => t.map((t) => ({
		rid: e,
		cell: t
	}))), [t.placements]), H = i(() => new Set(V.map((e) => e.cell)), [V]), U = i(() => {
		if (!O) return;
		let e = [];
		for (let t = 0; t < 480; t += 1) {
			if (H.has(t)) continue;
			let n = q(t, C);
			e.push({
				key: String(t),
				rect: {
					x: n.x + 14,
					y: n.y + 14,
					w: n.w - 28,
					h: n.h - 28
				}
			});
		}
		return e;
	}, [
		O,
		H,
		C
	]), W = t.phase === "score" || t.phase === "done" ? t.rounds[t.rounds.length - 1] ?? null : null, te = t.round.idx >= t.round.total, ne = [t.clue1, t.clue2].filter(Boolean).join(" · "), G = y("games.huesandcues.waitKicker"), J = y("games.huesandcues.waitShort"), Y = !1;
	t.phase === "pick" ? (G = y(D ? "games.huesandcues.giverKicker" : "games.huesandcues.waitKicker"), J = D ? y("games.huesandcues.pickShort") : z(t.giver), Y = D) : t.phase === "clue1" || t.phase === "clue2" ? (G = y(D ? "games.huesandcues.giverKicker" : "games.huesandcues.waitKicker"), J = D ? y("games.huesandcues.clueShort") : z(t.giver), Y = D) : t.phase === "place1" || t.phase === "place2" ? (G = y(O ? "games.huesandcues.yourTurnShort" : "games.huesandcues.clueKicker"), J = ne || y("games.huesandcues.placeShort"), Y = O) : t.phase === "score" && (G = y("games.huesandcues.scoreTitle"), J = t.target === null ? y("games.huesandcues.scoreTitle") : T(t.target), Y = D || k);
	let X = (e) => {
		if (t.phase !== "place1" && t.phase !== "place2" || e === t.giver) return null;
		let n = t.placements[e]?.length ?? 0, r = t.phase === "place1" ? 1 : 2;
		return e === t.placeTurn ? "pending" : n >= r ? "done" : null;
	}, Z;
	if (t.phase === "pick" && D) Z = /* @__PURE__ */ h("button", {
		type: "button",
		className: "hc-main hc-main-wide",
		disabled: M === null,
		onClick: () => M !== null && v({
			type: "pick",
			cell: M
		}),
		children: M === null ? y("games.huesandcues.pickShort") : y("games.huesandcues.confirmPick", { coord: T(M) })
	});
	else if ((t.phase === "clue1" || t.phase === "clue2") && D) {
		let e = t.phase === "clue2", r = e ? 16 : 8;
		Z = /* @__PURE__ */ g("div", {
			className: "hc-clue-actions",
			children: [/* @__PURE__ */ g("form", {
				className: "hc-clue-form",
				onSubmit: (e) => {
					e.preventDefault();
					let t = P.trim();
					t && v({
						type: "clue",
						text: t
					});
				},
				children: [
					n?.target != null && /* @__PURE__ */ h("span", {
						className: "hc-target-swatch",
						style: { background: w[n.target] },
						title: `${y("games.huesandcues.yourTarget")} ${T(n.target)}`,
						children: /* @__PURE__ */ h("span", { children: T(n.target) })
					}),
					/* @__PURE__ */ h("input", {
						className: "hc-clue-input",
						value: P,
						maxLength: r,
						placeholder: y(e ? "games.huesandcues.clue2Placeholder" : "games.huesandcues.clue1Placeholder"),
						"aria-label": y(e ? "games.huesandcues.clue2Title" : "games.huesandcues.clue1Title"),
						onChange: (e) => F(e.target.value),
						enterKeyHint: "send"
					}),
					/* @__PURE__ */ h("button", {
						type: "submit",
						className: "hc-main hc-clue-submit",
						disabled: !P.trim(),
						children: y("games.huesandcues.submitShort")
					})
				]
			}), e && /* @__PURE__ */ h("button", {
				type: "button",
				className: "hc-skip",
				onClick: () => v({ type: "skipClue2" }),
				children: y("games.huesandcues.skipClue2")
			})]
		});
	} else Z = O ? A === null ? /* @__PURE__ */ g("div", {
		className: "hc-action-idle",
		children: [/* @__PURE__ */ h("span", { children: y("games.huesandcues.boardShort") }), /* @__PURE__ */ h("span", { children: y("games.huesandcues.placeShort") })]
	}) : /* @__PURE__ */ g("div", {
		className: "hc-action-row",
		children: [
			/* @__PURE__ */ h("span", {
				className: "hc-specimen",
				style: { background: w[A] }
			}),
			/* @__PURE__ */ h("span", {
				className: "hc-coordinate font-mono tabular-nums",
				children: T(A)
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				className: "hc-main",
				onClick: () => v({
					type: "place",
					cell: A
				}),
				children: y("games.huesandcues.placeConfirm", { coord: T(A) })
			})
		]
	}) : t.phase === "score" && (D || k) ? /* @__PURE__ */ h("button", {
		type: "button",
		className: "hc-main hc-main-wide",
		onClick: () => v({ type: "next" }),
		children: y(te ? "games.huesandcues.showResult" : "games.huesandcues.nextRound")
	}) : /* @__PURE__ */ h("div", {
		className: "hc-action-idle",
		children: y("games.huesandcues.waitShort")
	});
	let Q = K(C), $ = /* @__PURE__ */ h(d, {
		sheetW: Q.w,
		sheetH: Q.h,
		eligible: U,
		highlight: "off",
		onTapEligible: (e) => j(Number(e)),
		fitKey: `round:${t.round.idx}:${C}:${S}`,
		children: /* @__PURE__ */ h(re, {
			placements: V,
			members: u,
			layout: C,
			selected: O ? A : null,
			selectedColor: B,
			selectedInitial: z(_).charAt(0),
			target: t.target,
			round: W
		})
	}), ae = t.phase === "pick" && D && n?.card ? /* @__PURE__ */ h("div", {
		className: "hc-pick-wrap",
		children: /* @__PURE__ */ g("div", {
			className: "hc-pick-card",
			children: [/* @__PURE__ */ h("div", {
				className: "hc-pick-grid",
				children: n.card.map((e) => {
					let t = M === e;
					return /* @__PURE__ */ g("button", {
						type: "button",
						className: `hc-pick-cell ${t ? "hc-pick-cell-active" : ""}`,
						style: { background: w[e] },
						onClick: () => N(e),
						"aria-label": T(e),
						"aria-pressed": t,
						children: [/* @__PURE__ */ h("span", {
							className: "hc-pick-coord font-mono",
							children: T(e)
						}), t && /* @__PURE__ */ h("span", {
							className: "hc-pick-check",
							"aria-hidden": !0,
							children: "✓"
						})]
					}, e);
				})
			}), /* @__PURE__ */ g("div", {
				className: "hc-pick-meta",
				children: [M !== null && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", {
					className: "hc-pick-swatch",
					style: { background: w[M] }
				}), /* @__PURE__ */ h("span", {
					className: "hc-pick-selected font-mono",
					children: T(M)
				})] }), /* @__PURE__ */ h("span", {
					className: "hc-private",
					children: y("games.huesandcues.privateShort")
				})]
			})]
		})
	}) : /* @__PURE__ */ h("div", {
		className: "hc-board",
		children: $
	});
	return /* @__PURE__ */ h("div", {
		className: "hc-game",
		children: /* @__PURE__ */ h(f, {
			adaptive: !0,
			className: "hc-layout",
			banner: /* @__PURE__ */ h(ie, {
				members: u,
				myRid: _,
				scores: t.scores,
				round: t.round,
				kicker: G,
				title: J,
				needsAction: Y,
				actionOf: X
			}),
			scroll: !1,
			actionsHeight: "hc-actions",
			actions: Z,
			children: /* @__PURE__ */ h("div", {
				ref: x,
				className: "hc-center",
				children: ae
			})
		})
	});
}
//#endregion
//#region src/games/huesandcues/bot.ts
var $ = (e) => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
function ae(e) {
	return new Set(Object.values(e.placements).flat());
}
function oe(e) {
	for (;;) {
		let t = $(480);
		if (!e.has(t)) return t;
	}
}
function se(e, t) {
	let n = e[$(e.length)], r = Math.floor(n / 30), i = n % 30, a = [];
	for (let e = -1; e <= 1; e += 1) for (let n = -1; n <= 1; n += 1) {
		if (e === 0 && n === 0) continue;
		let o = r + e, s = i + n;
		if (o < 0 || o >= 16 || s < 0 || s >= 30) continue;
		let c = o * 30 + s;
		t.has(c) || a.push(c);
	}
	return a.length > 0 ? a[$(a.length)] : null;
}
var ce = (e, t) => {
	let n = e.public;
	if (n.phase !== "place1" && n.phase !== "place2" || n.placeTurn !== t.rid) return null;
	let r = ae(n), i = [...r];
	if (n.phase === "place2" && i.length > 0 && $(2) === 0) {
		let e = se(i, r);
		if (e !== null) return { action: {
			type: "place",
			cell: e
		} };
	}
	return { action: {
		type: "place",
		cell: oe(r)
	} };
};
//#endregion
//#region src/games/huesandcues/fx.tsx
function le(e, t) {
	let n = e.member(t);
	return n ? l[n.colorIndex % l.length].hex : "#57534e";
}
function ue({ color: e }) {
	return /* @__PURE__ */ h("span", {
		className: "block h-full w-full rounded-full border-4",
		style: {
			background: e,
			borderColor: "#fffdf6"
		}
	});
}
var de = {
	place(e, t) {
		let n = e.data;
		if (typeof n?.cell != "number") return null;
		let r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = t.anchor(`cell:${n.cell}`);
		return !r || !i ? null : {
			ms: 420,
			node: /* @__PURE__ */ h(S, {
				from: r,
				to: i,
				ms: 380,
				children: /* @__PURE__ */ h(ue, { color: e.rid ? le(t, e.rid) : "#57534e" })
			})
		};
	},
	reveal(e, t) {
		let n = e.data, r = typeof n?.target == "number" ? t.anchor(`cell:${n.target}`) : null;
		return r ? (v(), {
			ms: 1e3,
			node: /* @__PURE__ */ h(ee, {
				at: r,
				ms: 1e3
			})
		}) : null;
	},
	score(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.total != "number" ? null : {
			ms: 800,
			node: /* @__PURE__ */ h(x, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ g("span", {
					className: "font-mono font-extrabold tabular-nums",
					children: ["+", n.total]
				})
			})
		};
	}
};
//#endregion
//#region src/games/huesandcues/game-over.tsx
function fe(e) {
	return /* @__PURE__ */ h("div", {
		className: "hc-game-over",
		children: /* @__PURE__ */ h(C, {
			...e,
			accent: E.accent
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/huesandcues/entry.tsx
var pe = {
	definition: G,
	View: Q,
	bot: ce,
	fx: de,
	OverView: fe,
	locales: {
		zh: {
			name: "巧言绘色",
			desc: "用一两个词描述颜色,让大家在 480 色版图上找到它",
			rules: "目标:轮流当出题者,用词语描述版图上的目标颜色,让其他人凭线索在版图上放标记猜位置,猜得越准得分越高。\n流程:\n· 出题者抽取一张颜色卡,从卡上四个颜色中秘密选定一个目标颜色。\n· 出题者给出一个词语的线索;其余玩家从出题者左手边开始,轮流把一枚标记放到版图的任意空格。\n· 出题者再给出两个词语的线索;玩家按相反顺序轮流放置第二枚标记。\n· 出题者也可以放弃第二条线索并立即结算,此时玩家不再放置第二枚标记。\n线索限制:\n· 线索不能是「红色」「蓝色」等基础颜色名;「薰衣草」「落日」这类描述可以使用。\n· 线索不能提及版图坐标,不能重复本局已经使用过的线索。\n结算:\n· 正中目标格的标记获得 3 分。\n· 与目标格相邻一圈内的标记获得 2 分,再外一圈的标记获得 1 分。\n· 出题者按计分框内的标记数量得分,每枚 1 分。\n· 三人局每枚改为 2 分;出题者单轮最多获得 9 分。\n结束:\n· 三至六人局每人当两次出题者,七人及以上每人当一次。\n· 总分最高者获胜,平分则共享胜利。",
			roundShort: "第 {{n}}/{{total}} 轮",
			clueKicker: "线索",
			giverKicker: "出题者",
			waitKicker: "等待",
			yourTurnShort: "轮到你",
			waitShort: "稍候",
			pickShort: "选目标",
			clueShort: "给线索",
			placeShort: "选择一格",
			boardShort: "色盘",
			submitShort: "发布",
			privateShort: "仅自己可见",
			confirmPick: "选定 {{coord}}",
			youAreGiver: "你是本轮出题者",
			pickTitle: "选择目标颜色",
			pickHint: "点选卡上的一个颜色作为目标,其他玩家看不到这张卡",
			waitPick: "等待 {{name}} 选择目标颜色…",
			clue1Title: "给出一个词的线索",
			clue2Title: "给出两个词的线索",
			clue1Placeholder: "一个词,如「落日」",
			clue2Placeholder: "两个词,如「落日 余晖」",
			submitClue: "公布线索",
			skipClue2: "放弃线索,立即结算",
			waitClue: "等待 {{name}} 给线索…",
			clueLabel: "线索",
			yourTarget: "你的目标",
			placeTitle: "轮到你放置标记",
			placeHint: "点选版图上的一个空格,放大可点得更准",
			waitPlace: "等待 {{name}} 放置标记…",
			placeConfirm: "放在 {{coord}}",
			placeCancel: "重选",
			scoreTitle: "本轮结算",
			scoreExact: "正中 +3",
			scoreFrame: "框内 +2",
			scoreNear: "相邻 +1",
			giverGain: "出题者 +{{n}}",
			nextRound: "下一轮",
			showResult: "查看结果",
			waitNext: "等待出题者开始下一轮…",
			errNotGiver: "现在不是你在出题",
			errNotOnCard: "只能从卡上四个颜色中选",
			errNotPlacing: "现在不是放置阶段",
			errNotYourPlace: "还没轮到你放置",
			errCellTaken: "这个格子已有标记",
			errNotScoring: "现在不能推进",
			errClueOneWord: "第一条线索只能是一个词,不超过 8 个字",
			errClueTwoWords: "第二条线索最多两个词",
			errClueColor: "线索不能是基础颜色名,换个说法吧",
			errClueUsed: "这个线索本局已经用过了"
		},
		en: {
			name: "Hues and Cues",
			desc: "Describe a color with one or two words and guide everyone to it on a 480-color board",
			rules: "Goal: Take turns as the cue giver. Describe a secret target color with words so the other players place their pieces on the right spot of the board.\nPlay:\n· The cue giver draws a color card and secretly chooses one of its four colors as the target.\n· The cue giver gives a one-word clue; starting from their left, the other players take turns placing one piece on any empty square.\n· The cue giver then gives a two-word clue; players place their second piece in reverse order.\n· The cue giver may instead skip the second clue and score immediately; no second pieces are placed.\nClue limits:\n· A clue cannot be a basic color name like red or blue; descriptions like lavender or sunset are fine.\n· A clue cannot mention board coordinates or repeat a clue already used this game.\nScoring:\n· A piece on the target square scores 3 points.\n· One square away scores 2 points; two squares away scores 1.\n· The cue giver scores 1 point per piece inside the scoring frame.\n· In a 3-player game each piece scores 2; the cue giver can score at most 9 points per round.\nEnd:\n· With 3-6 players everyone gives cues twice; with 7 or more, once.\n· The highest total score wins; tied players share the victory.",
			roundShort: "Round {{n}}/{{total}}",
			clueKicker: "CLUE",
			giverKicker: "CUE GIVER",
			waitKicker: "WAITING",
			yourTurnShort: "YOUR TURN",
			waitShort: "Waiting",
			pickShort: "Pick target",
			clueShort: "Give clue",
			placeShort: "Choose a square",
			boardShort: "BOARD",
			submitShort: "Send",
			privateShort: "PRIVATE",
			confirmPick: "Select {{coord}}",
			youAreGiver: "You are the cue giver",
			pickTitle: "Choose the target color",
			pickHint: "Tap one of the four colors on your card; the other players cannot see it",
			waitPick: "Waiting for {{name}} to pick a target…",
			clue1Title: "Give a one-word clue",
			clue2Title: "Give a two-word clue",
			clue1Placeholder: "One word, e.g. sunset",
			clue2Placeholder: "Two words, e.g. sunset glow",
			submitClue: "Reveal clue",
			skipClue2: "Skip clue and score now",
			waitClue: "Waiting for {{name}} to give a clue…",
			clueLabel: "Clue",
			yourTarget: "Your target",
			placeTitle: "Place your piece",
			placeHint: "Tap an empty square on the board; zoom in for precision",
			waitPlace: "Waiting for {{name}} to place a piece…",
			placeConfirm: "Place at {{coord}}",
			placeCancel: "Reselect",
			scoreTitle: "Round scoring",
			scoreExact: "Exact +3",
			scoreFrame: "In frame +2",
			scoreNear: "Adjacent +1",
			giverGain: "Cue giver +{{n}}",
			nextRound: "Next round",
			showResult: "Show results",
			waitNext: "Waiting for the cue giver to start the next round…",
			errNotGiver: "You are not the cue giver now",
			errNotOnCard: "Choose one of the four colors on your card",
			errNotPlacing: "Not the placing phase now",
			errNotYourPlace: "Not your turn to place",
			errCellTaken: "That square already has a piece",
			errNotScoring: "Cannot advance now",
			errClueOneWord: "The first clue must be a single word, up to 8 characters",
			errClueTwoWords: "The second clue is at most two words",
			errClueColor: "A clue cannot be a basic color name; try another phrasing",
			errClueUsed: "That clue was already used this game"
		}
	}
};
//#endregion
export { pe as default };
