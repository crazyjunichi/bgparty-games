import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useId as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconExpand as d, IconMirror as f, IconRotate as p, IconZoomIn as m, IconZoomOut as h } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as g } from "@bgparty/sdk/player-colors";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { botAvatarOf as x } from "@bgparty/sdk/lobby";
import { botPersonality as S } from "@bgparty/sdk/bot-personality";
import { Floater as C, FlySprite as w, PulseBox as T } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as E } from "@bgparty/sdk/confirm-button";
import { OptionSection as te, OptionSwitch as D } from "@bgparty/sdk/ui/game-options";
//#region src/games/barenpark/data.ts
var O = {
	"grizzly-2239d0": {
		id: "grizzly-2239d0",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[1, 2],
			[2, 2]
		],
		value: 7,
		art: "grizzly-2239d0.svg"
	},
	"grizzly-0ffeec": {
		id: "grizzly-0ffeec",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[3, 0],
			[0, 1],
			[1, 1],
			[3, 1]
		],
		value: 7,
		art: "grizzly-0ffeec.svg"
	},
	"grizzly-5dc482": {
		id: "grizzly-5dc482",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[1, 2]
		],
		value: 7,
		art: "grizzly-5dc482.svg"
	},
	"grizzly-baae8f": {
		id: "grizzly-baae8f",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1],
			[2, 1],
			[0, 2],
			[1, 2]
		],
		value: 8,
		art: "grizzly-baae8f.svg"
	},
	"grizzly-f9b58d": {
		id: "grizzly-f9b58d",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[2, 0],
			[0, 1],
			[2, 1],
			[0, 2],
			[1, 2],
			[2, 2]
		],
		value: 8,
		art: "grizzly-f9b58d.svg"
	},
	"grizzly-4da943": {
		id: "grizzly-4da943",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[2, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[0, 2],
			[2, 2]
		],
		value: 8,
		art: "grizzly-4da943.svg"
	},
	"grizzly-ed177f": {
		id: "grizzly-ed177f",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[3, 0],
			[0, 1],
			[3, 1],
			[0, 2]
		],
		value: 9,
		art: "grizzly-ed177f.svg"
	},
	"grizzly-cc59e0": {
		id: "grizzly-cc59e0",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[2, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[1, 2],
			[1, 3]
		],
		value: 9,
		art: "grizzly-cc59e0.svg"
	},
	"grizzly-c9f5fb": {
		id: "grizzly-c9f5fb",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[2, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[2, 2],
			[2, 3]
		],
		value: 9,
		art: "grizzly-c9f5fb.svg"
	},
	"grizzly-1744b3": {
		id: "grizzly-1744b3",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[0, 0],
			[0, 1],
			[1, 1],
			[1, 2],
			[2, 2],
			[2, 3],
			[3, 3]
		],
		value: 10,
		art: "grizzly-1744b3.svg"
	},
	"grizzly-8f572c": {
		id: "grizzly-8f572c",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[1, 0],
			[1, 1],
			[1, 2],
			[0, 3],
			[1, 3],
			[2, 3],
			[3, 3]
		],
		value: 10,
		art: "grizzly-8f572c.svg"
	},
	"grizzly-ef25f3": {
		id: "grizzly-ef25f3",
		kind: "grizzly",
		species: "grizzly",
		cells: [
			[1, 0],
			[0, 1],
			[1, 1],
			[1, 2],
			[2, 2],
			[3, 2],
			[2, 3]
		],
		value: 10,
		art: "grizzly-ef25f3.svg"
	},
	toilet: {
		id: "toilet",
		kind: "green",
		species: "",
		cells: [[0, 0]],
		value: 0,
		art: "toilet.svg"
	},
	playground: {
		id: "playground",
		kind: "green",
		species: "",
		cells: [[0, 0], [1, 0]],
		value: 0,
		art: "playground.svg"
	},
	river: {
		id: "river",
		kind: "green",
		species: "",
		cells: [
			[0, 0],
			[0, 1],
			[1, 1]
		],
		value: 0,
		art: "river.svg"
	},
	"food-street": {
		id: "food-street",
		kind: "green",
		species: "",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0]
		],
		value: 0,
		art: "food-street.svg"
	},
	"house-gobi-1": {
		id: "house-gobi-1",
		kind: "house",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		value: 1,
		art: "house-gobi-1.svg"
	},
	"house-gobi-2": {
		id: "house-gobi-2",
		kind: "house",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		value: 2,
		art: "house-gobi-2.svg"
	},
	"house-gobi-3": {
		id: "house-gobi-3",
		kind: "house",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		value: 3,
		art: "house-gobi-3.svg"
	},
	"house-gobi-4": {
		id: "house-gobi-4",
		kind: "house",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		value: 4,
		art: "house-gobi-4.svg"
	},
	"house-gobi-5": {
		id: "house-gobi-5",
		kind: "house",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		value: 5,
		art: "house-gobi-5.svg"
	},
	"house-gobi-6": {
		id: "house-gobi-6",
		kind: "house",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		value: 6,
		art: "house-gobi-6.svg"
	},
	"house-gobi-7": {
		id: "house-gobi-7",
		kind: "house",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		value: 7,
		art: "house-gobi-7.svg"
	},
	"house-gobi-8": {
		id: "house-gobi-8",
		kind: "house",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[0, 1],
			[1, 1]
		],
		value: 8,
		art: "house-gobi-8.svg"
	},
	"house-koala-1": {
		id: "house-koala-1",
		kind: "house",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1]
		],
		value: 1,
		art: "house-koala-1.svg"
	},
	"house-koala-2": {
		id: "house-koala-2",
		kind: "house",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1]
		],
		value: 2,
		art: "house-koala-2.svg"
	},
	"house-koala-3": {
		id: "house-koala-3",
		kind: "house",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1]
		],
		value: 3,
		art: "house-koala-3.svg"
	},
	"house-koala-4": {
		id: "house-koala-4",
		kind: "house",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1]
		],
		value: 4,
		art: "house-koala-4.svg"
	},
	"house-koala-5": {
		id: "house-koala-5",
		kind: "house",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1]
		],
		value: 5,
		art: "house-koala-5.svg"
	},
	"house-koala-6": {
		id: "house-koala-6",
		kind: "house",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1]
		],
		value: 6,
		art: "house-koala-6.svg"
	},
	"house-koala-7": {
		id: "house-koala-7",
		kind: "house",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1]
		],
		value: 7,
		art: "house-koala-7.svg"
	},
	"house-koala-8": {
		id: "house-koala-8",
		kind: "house",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1]
		],
		value: 8,
		art: "house-koala-8.svg"
	},
	"house-polar-1": {
		id: "house-polar-1",
		kind: "house",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1]
		],
		value: 1,
		art: "house-polar-1.svg"
	},
	"house-polar-2": {
		id: "house-polar-2",
		kind: "house",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1]
		],
		value: 2,
		art: "house-polar-2.svg"
	},
	"house-polar-3": {
		id: "house-polar-3",
		kind: "house",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1]
		],
		value: 3,
		art: "house-polar-3.svg"
	},
	"house-polar-4": {
		id: "house-polar-4",
		kind: "house",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1]
		],
		value: 4,
		art: "house-polar-4.svg"
	},
	"house-polar-5": {
		id: "house-polar-5",
		kind: "house",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1]
		],
		value: 5,
		art: "house-polar-5.svg"
	},
	"house-polar-6": {
		id: "house-polar-6",
		kind: "house",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1]
		],
		value: 6,
		art: "house-polar-6.svg"
	},
	"house-polar-7": {
		id: "house-polar-7",
		kind: "house",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1]
		],
		value: 7,
		art: "house-polar-7.svg"
	},
	"house-polar-8": {
		id: "house-polar-8",
		kind: "house",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1]
		],
		value: 8,
		art: "house-polar-8.svg"
	},
	"house-panda-1": {
		id: "house-panda-1",
		kind: "house",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		],
		value: 1,
		art: "house-panda-1.svg"
	},
	"house-panda-2": {
		id: "house-panda-2",
		kind: "house",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		],
		value: 2,
		art: "house-panda-2.svg"
	},
	"house-panda-3": {
		id: "house-panda-3",
		kind: "house",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		],
		value: 3,
		art: "house-panda-3.svg"
	},
	"house-panda-4": {
		id: "house-panda-4",
		kind: "house",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		],
		value: 4,
		art: "house-panda-4.svg"
	},
	"house-panda-5": {
		id: "house-panda-5",
		kind: "house",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		],
		value: 5,
		art: "house-panda-5.svg"
	},
	"house-panda-6": {
		id: "house-panda-6",
		kind: "house",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		],
		value: 6,
		art: "house-panda-6.svg"
	},
	"house-panda-7": {
		id: "house-panda-7",
		kind: "house",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		],
		value: 7,
		art: "house-panda-7.svg"
	},
	"house-panda-8": {
		id: "house-panda-8",
		kind: "house",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1]
		],
		value: 8,
		art: "house-panda-8.svg"
	},
	"enclosure-gobi-6": {
		id: "enclosure-gobi-6",
		kind: "enclosure",
		species: "gobi",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1],
			[2, 1]
		],
		value: 6,
		art: "enclosure-gobi-6.svg"
	},
	"enclosure-gobi-7": {
		id: "enclosure-gobi-7",
		kind: "enclosure",
		species: "gobi",
		cells: [
			[1, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[2, 2]
		],
		value: 7,
		art: "enclosure-gobi-7.svg"
	},
	"enclosure-gobi-8": {
		id: "enclosure-gobi-8",
		kind: "enclosure",
		species: "gobi",
		cells: [
			[0, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[2, 2]
		],
		value: 8,
		art: "enclosure-gobi-8.svg"
	},
	"enclosure-koala-6": {
		id: "enclosure-koala-6",
		kind: "enclosure",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[3, 0],
			[0, 1]
		],
		value: 6,
		art: "enclosure-koala-6.svg"
	},
	"enclosure-koala-7": {
		id: "enclosure-koala-7",
		kind: "enclosure",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1],
			[0, 2]
		],
		value: 7,
		art: "enclosure-koala-7.svg"
	},
	"enclosure-koala-8": {
		id: "enclosure-koala-8",
		kind: "enclosure",
		species: "koala",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1],
			[2, 1]
		],
		value: 8,
		art: "enclosure-koala-8.svg"
	},
	"enclosure-polar-6": {
		id: "enclosure-polar-6",
		kind: "enclosure",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[3, 0],
			[4, 0]
		],
		value: 6,
		art: "enclosure-polar-6.svg"
	},
	"enclosure-polar-7": {
		id: "enclosure-polar-7",
		kind: "enclosure",
		species: "polar",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[1, 1],
			[1, 2]
		],
		value: 7,
		art: "enclosure-polar-7.svg"
	},
	"enclosure-polar-8": {
		id: "enclosure-polar-8",
		kind: "enclosure",
		species: "polar",
		cells: [
			[1, 0],
			[0, 1],
			[1, 1],
			[2, 1],
			[1, 2]
		],
		value: 8,
		art: "enclosure-polar-8.svg"
	},
	"enclosure-panda-6": {
		id: "enclosure-panda-6",
		kind: "enclosure",
		species: "panda",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[3, 0],
			[1, 1]
		],
		value: 6,
		art: "enclosure-panda-6.svg"
	},
	"enclosure-panda-7": {
		id: "enclosure-panda-7",
		kind: "enclosure",
		species: "panda",
		cells: [
			[0, 0],
			[1, 0],
			[2, 0],
			[2, 1],
			[3, 1]
		],
		value: 7,
		art: "enclosure-panda-7.svg"
	},
	"enclosure-panda-8": {
		id: "enclosure-panda-8",
		kind: "enclosure",
		species: "panda",
		cells: [
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1],
			[0, 2]
		],
		value: 8,
		art: "enclosure-panda-8.svg"
	}
}, k = {
	park0: ".w.cb.c....w.e.p",
	park1: "c..w..e.b....cpw",
	park2: "pb.ew.....w.c..c",
	park3: "w.e....cpb..w..c",
	park4: ".c.w..b.c..wp.e.",
	park5: "..cpb..w.e..c..w",
	park6: "e..b..c..c..wpw.",
	park7: ".wpcw.....e.c..b",
	park8: ".c.ww.bp...ce...",
	park9: ".e.b..w..w.pc..c",
	park10: "cp.w.b..w....c.e",
	park11: "w..cpe.....wc.b.",
	entrance0: "..w.c..w.bp.w..c",
	entrance1: "c..w.pw.w..b..c.",
	entrance2: "b.c..wp...w.c..w",
	entrance3: "w..c.w..bpw..c..",
	exit0: ".c..w.p..w..c...",
	exit1: "...c..w...p.w..c",
	exit2: "w....c...pc....w",
	exit3: ".c..wp...w.....c"
}, A = [
	"toilet",
	"playground",
	"food-street",
	"river"
], ne = [
	"polar",
	"gobi",
	"koala",
	"panda"
], j = [
	[1, 0],
	[-1, 0],
	[0, 1],
	[0, -1]
], re = {
	id: "barenpark",
	tier: "alpha",
	mechanics: [
		"tile-placement",
		"drafting",
		"set-collection",
		"race"
	],
	interactionTags: [],
	nameKey: "games.barenpark.name",
	descKey: "games.barenpark.desc",
	rulesKey: "games.barenpark.rules",
	icon: "🐻",
	iconImg: "games/barenpark.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [
		2,
		3,
		4
	],
	accent: "#527b40",
	releasedAt: "2026-10-31T14:28:00+08:00",
	search: {
		py: "xiong xiong gong yuan",
		init: "xxgy"
	},
	hotseat: "open",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/753718226903451388/0FC3F8AEF130F15A7D67B9382371404E8AC0B424/" }
}, ie = t.object({
	achievements: t.boolean().default(!1),
	newAchievements: t.boolean().default(!1),
	grizzlies: t.boolean().default(!1),
	monorails: t.boolean().default(!1),
	pitVariant: t.boolean().default(!1)
}).default({
	achievements: !1,
	newAchievements: !1,
	grizzlies: !1,
	monorails: !1,
	pitVariant: !1
}), M = t.int().min(-32).max(32), ae = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		tile: t.string(),
		x: M,
		y: M,
		rotation: t.int().min(0).max(3),
		flipped: t.boolean()
	}),
	t.object({
		type: t.literal("take"),
		icon: t.enum([
			"w",
			"c",
			"e"
		]),
		tile: t.string()
	}),
	t.object({
		type: t.literal("expand"),
		source: t.int().min(0).max(5),
		x: M,
		y: M
	}),
	t.object({
		type: t.literal("exchange"),
		green: t.string(),
		house: t.string(),
		grizzly: t.string()
	}),
	t.object({
		type: t.literal("tower"),
		x: M,
		y: M,
		connect: t.int().min(-1).max(100)
	}),
	t.object({ type: t.literal("skipTower") }),
	t.object({
		type: t.literal("pass"),
		tile: t.string()
	}),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), N = t.object({
	id: t.string(),
	def: t.string(),
	value: t.int().nonnegative()
}), P = N.extend({
	x: M,
	y: M,
	rotation: t.int().min(0).max(3),
	flipped: t.boolean()
}), oe = t.object({
	id: t.string(),
	x: M,
	y: M,
	statue: t.int().nonnegative(),
	pitCovered: t.boolean()
}), se = t.object({
	x: M,
	y: M
}), ce = t.object({
	a: t.int().nonnegative(),
	b: t.int().nonnegative(),
	value: t.int().positive()
}), le = t.object({
	rid: t.string(),
	boards: t.array(oe),
	supply: t.array(N),
	placed: t.array(P),
	towers: t.array(se),
	cars: t.array(ce),
	achievements: t.record(t.string(), t.number()),
	score: t.object({
		houses: t.number(),
		enclosures: t.number(),
		grizzlies: t.number(),
		statues: t.number(),
		achievements: t.number(),
		cars: t.number(),
		total: t.number(),
		reserve: t.number()
	})
}), ue = t.object({
	config: ie,
	players: t.array(le),
	active: t.string(),
	phase: t.enum([
		"place",
		"tower",
		"rewards",
		"statues",
		"achievements",
		"end",
		"done"
	]),
	turn: t.int().positive(),
	supply: t.array(N),
	statues: t.array(t.number()),
	stacks: t.array(t.object({
		top: t.string().nullable(),
		count: t.number()
	})),
	exits: t.array(t.string()),
	goals: t.array(t.object({
		id: t.string(),
		values: t.array(t.number())
	})),
	pending: t.string(),
	last: P.nullable(),
	exchanged: t.boolean(),
	finalLeft: t.number().nullable(),
	towerCount: t.number(),
	carValues: t.array(t.number()),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		value: t.string()
	}))
}), de = t.object({}), fe = [
	"polar",
	"gobi",
	"koala",
	"panda",
	"green",
	"food",
	"river",
	"enclosures",
	"houses",
	"twice",
	"freeze",
	"planning",
	"toilets",
	"connections",
	"corners",
	"playgrounds"
], F = (e, t) => `${e},${t}`;
function I([e, t], n, r) {
	r && (e = -e);
	for (let r = 0; r < n; r++) [e, t] = [-t, e];
	return [e, t];
}
function L(e, t = 0, n = !1) {
	let r = O[e].cells.map((e) => I(e, t, n)), i = Math.min(...r.map(([e]) => e)), a = Math.min(...r.map(([, e]) => e));
	return r.map(([e, t]) => [e - i, t - a]);
}
var R = (e) => L(e.def, e.rotation, e.flipped).map(([t, n]) => [t + e.x, n + e.y]);
function z(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.boards) for (let e = 0; e < 16; e++) t.set(F(n.x * 4 + e % 4, n.y * 4 + Math.floor(e / 4)), k[n.id][e]);
	return t;
}
function B(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.placed) for (let [e, r] of R(n)) t.set(F(e, r), n);
	return t;
}
function pe(e, t, n, r, i, a, o = !1, s = z(e), c = B(e)) {
	if (!O[t]) return !1;
	let l = !e.placed.length;
	for (let [u, d] of L(t, i, a)) {
		let t = n + u, i = r + d, a = F(t, i), f = s.get(a);
		if (!f || c.has(a) || f === "p" && (!o || e.boards.some((e) => e.statue > 0 && t >= e.x * 4 && t < e.x * 4 + 4 && i >= e.y * 4 && i < e.y * 4 + 4))) return !1;
		j.some(([e, n]) => c.has(F(t + e, i + n))) && (l = !0);
	}
	return l;
}
function me(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r of [!1, !0]) for (let i = 0; i < 4; i++) {
		let a = L(e, i, r), o = a.map((e) => e.join(",")).sort().join(";");
		t.has(o) || (t.add(o), n.push({
			rotation: i,
			flipped: r,
			cells: a
		}));
	}
	return n;
}
function V(e, t, n = !1) {
	let r = z(e), i = B(e), a = [];
	for (let o of me(t.def)) {
		let s = /* @__PURE__ */ new Set();
		for (let [e, t] of r) {
			if (i.has(e) || t === "p" && !n) continue;
			let [r, a] = e.split(",").map(Number);
			for (let [e, t] of o.cells) s.add(F(r - e, a - t));
		}
		for (let c of s) {
			let [s, l] = c.split(",").map(Number);
			pe(e, t.def, s, l, o.rotation, o.flipped, n, r, i) && a.push({
				type: "place",
				tile: t.id,
				x: s,
				y: l,
				rotation: o.rotation,
				flipped: o.flipped
			});
		}
	}
	return a;
}
function he(e, t = !1) {
	let n = /* @__PURE__ */ new Map();
	for (let r of e.boards) for (let [i, a] of j) {
		let o = r.x + i, s = r.y + a;
		s > 0 || e.boards.some((e) => e.x === o && e.y === s) || t && e.boards.some((e) => e.x === o && e.y === s - 1) || n.set(F(o, s), [o, s]);
	}
	return [...n.values()];
}
function ge(e, t) {
	return e.supply.filter((n) => {
		let r = O[n.def];
		return r.kind === "green" || t !== "w" && r.kind === "house" && !e.supply.some((e) => O[e.def].kind === "house" && O[e.def].species === r.species && e.value > n.value) || t === "e" && r.kind === "enclosure";
	});
}
function _e(e, t, n, r) {
	if (!t || !n || O[t.def].kind !== "green") return [];
	let i = [];
	for (let [n, a] of R(t)) {
		if (!e.towers.length) {
			i.push({
				type: "tower",
				x: n,
				y: a,
				connect: -1
			});
			continue;
		}
		r.length && e.towers.forEach((t, r) => {
			if (!(n === t.x && Math.abs(a - t.y) === 3 || a === t.y && Math.abs(n - t.x) === 3)) return;
			let o = e.cars.filter((e) => e.a === r || e.b === r);
			if (!(o.length >= 2)) {
				if (o.length) {
					let i = o[0], s = e.towers[i.a === r ? i.b : i.a];
					if ((s.x - t.x) * (n - t.x) + (s.y - t.y) * (a - t.y) !== 0) return;
				}
				i.push({
					type: "tower",
					x: n,
					y: a,
					connect: r
				});
			}
		});
	}
	return i;
}
function ve(e, t) {
	let n = B(e);
	return [...k[t.id]].every((e, r) => e === "p" || n.has(F(t.x * 4 + r % 4, t.y * 4 + Math.floor(r / 4))));
}
function ye(e) {
	let t = (t) => e.placed.filter((e) => O[e.def].kind === t).reduce((e, t) => e + t.value, 0), n = t("house"), r = t("enclosure"), i = t("grizzly"), a = e.boards.reduce((e, t) => e + t.statue, 0), o = Object.values(e.achievements).reduce((e, t) => e + t, 0), s = e.cars.reduce((e, t) => e + t.value, 0);
	e.score = {
		houses: n,
		enclosures: r,
		grizzlies: i,
		statues: a,
		achievements: o,
		cars: s,
		total: n + r + i + a + o + s,
		reserve: e.supply.reduce((e, t) => e + t.value, 0)
	};
}
function be(e) {
	let t = e.map((e) => new Set(R(e).map(([e, t]) => F(e, t)))), n = /* @__PURE__ */ new Set(), r = 0;
	for (let i = 0; i < e.length; i++) {
		if (n.has(i)) continue;
		let a = [i];
		n.add(i);
		for (let r = 0; r < a.length; r++) for (let i = 0; i < e.length; i++) !n.has(i) && R(e[a[r]]).some(([e, n]) => j.some(([r, a]) => t[i].has(F(e + r, n + a)))) && (n.add(i), a.push(i));
		r = Math.max(r, a.length);
	}
	return r;
}
function xe(e) {
	let t = O[e.def].cells.map((t) => I(t, e.rotation, e.flipped)), n = Math.min(...t.map(([e]) => e)), r = Math.min(...t.map(([, e]) => e));
	return [[[0, 0], [0, -1]], [[1, 1], [1, 0]]].map(([t, i]) => {
		let [a, o] = I(t, e.rotation, e.flipped), s = I(i, e.rotation, e.flipped);
		return {
			x: e.x + a - n,
			y: e.y + o - r,
			dir: s
		};
	});
}
function Se(e, t, n) {
	let r = t.placed, i = r.map((e) => O[e.def]), a = B(t);
	if (ne.includes(e)) return i.filter((t) => t.species === e).length >= 3;
	if (e === "green") return be(r.filter((e) => O[e.def].kind === "green")) >= 6;
	if (e === "enclosures") return be(r.filter((e) => O[e.def].kind === "enclosure")) >= 3;
	if (e === "houses") return ne.every((e) => i.some((t) => t.kind === "house" && t.species === e));
	if (e === "twice") return n.turnStatues >= 2;
	if (e === "freeze") return !!n.last && O[n.last.def].kind === "enclosure" && !n.covered;
	if (e === "planning") return n.turnEnclosures >= 2;
	if (e === "toilets") {
		let e = r.filter((e) => e.def === "toilet");
		return e.some((t) => e.some((e) => Math.abs(t.x - e.x) + Math.abs(t.y - e.y) >= 12));
	}
	if (e === "food") {
		let e = r.filter((e) => e.def === "food-street");
		return e.some((t) => {
			let n = R(t), r = n.every(([, e]) => e === n[0][1]), i = +!!r, a = +!r, o = Math.min(...n.map(([e]) => e)), s = Math.min(...n.map(([, e]) => e));
			return [1, 2].every((n) => e.some((e) => e.id !== t.id && R(e).every(([e, t]) => r ? t === s : e === o) && Math.min(...R(e).map(([e, t]) => r ? e : t)) === (r ? o : s) + n * 3)) && !!(i || a);
		});
	}
	if (e === "river") {
		let e = r.filter((e) => e.def === "river").map(xe);
		return e.map((t, n) => e.flatMap((e, r) => n !== r && t.some((t) => e.some((e) => t.x + t.dir[0] === e.x && t.y + t.dir[1] === e.y && t.dir[0] === -e.dir[0] && t.dir[1] === -e.dir[1])) ? [r] : [])).some((e) => e.length >= 2);
	}
	if (e === "connections") {
		let e = /* @__PURE__ */ new Set();
		for (let t of r.filter((e) => e.def === "food-street")) {
			let n = [...new Set(R(t).map(([e, t]) => F(Math.floor(e / 4), Math.floor(t / 4))))].sort();
			n.length === 2 && e.add(n.join("|"));
		}
		return e.size >= 3;
	}
	return e === "corners" ? t.boards.filter((e) => r.some((t) => t.def === "river" && [
		[
			0,
			0,
			1,
			1
		],
		[
			3,
			0,
			-1,
			1
		],
		[
			0,
			3,
			1,
			-1
		],
		[
			3,
			3,
			-1,
			-1
		]
	].some(([n, r, i, a]) => {
		let o = new Set(R(t).map(([e, t]) => F(e, t))), s = e.x * 4 + n, c = e.y * 4 + r;
		return [
			[s, c],
			[s + i, c],
			[s, c + a]
		].every(([e, t]) => o.has(F(e, t)));
	}))).length >= 3 : e === "playgrounds" && t.boards.filter((e) => {
		let t = k[e.id].indexOf("p"), n = e.x * 4 + t % 4, r = e.y * 4 + Math.floor(t / 4);
		return e.statue > 0 && j.some(([e, t]) => a.get(F(n + e, r + t))?.def === "playground");
	}).length >= 3;
}
function H(t, n, r) {
	let i = ie.parse(t), a = 0;
	function o(t) {
		let n = [...t];
		for (let t = n.length - 1; t > 0; t--) {
			let i = e(r, a++, t + 1);
			[n[t], n[i]] = [n[i], n[t]];
		}
		return n;
	}
	let s = n.length, c = [], l = i.grizzlies || i.monorails || i.newAchievements;
	for (let e of A) for (let t = 0; t < (e === "toilet" ? l ? 16 : 10 : e === "playground" ? 10 : s * 4); t++) c.push({
		id: `${e}:${t}`,
		def: e,
		value: 0
	});
	let u = s === 2 ? i.grizzlies ? [
		2,
		4,
		6,
		8
	] : [
		2,
		4,
		6
	] : s === 3 ? Array.from({ length: i.grizzlies ? 6 : 5 }, (e, t) => t + 2) : Array.from({ length: i.grizzlies ? 8 : 7 }, (e, t) => t + 1);
	for (let e of Object.values(O)) (e.kind === "house" && u.includes(e.value) || e.kind === "enclosure" || e.kind === "grizzly" && i.grizzlies) && c.push({
		id: e.id,
		def: e.id,
		value: e.value
	});
	let d = o([
		0,
		1,
		2,
		3
	]), f = o(n), p = o(Array.from({ length: 12 }, (e, t) => `park${t}`)), m = f.map((e, t) => {
		let n = t === 0 ? "toilet" : t === s - 1 && s > 2 ? "food-street" : "playground", r = c.findIndex((e) => e.def === n);
		return {
			rid: e,
			boards: [{
				id: `entrance${d[t]}`,
				x: 0,
				y: 0,
				statue: 0,
				pitCovered: !1
			}],
			supply: [c.splice(r, 1)[0]],
			placed: [],
			towers: [],
			cars: [],
			achievements: {},
			score: {
				houses: 0,
				enclosures: 0,
				grizzlies: 0,
				statues: 0,
				achievements: 0,
				cars: 0,
				total: 0,
				reserve: 0
			}
		};
	}), h = s === 2 ? Array.from({ length: i.grizzlies ? 10 : 8 }, (e, t) => (t + 1) * 2) : s === 3 ? Array.from({ length: i.grizzlies ? 15 : 12 }, (e, t) => t + 3) : Array.from({ length: i.grizzlies ? 20 : 16 }, (e, t) => t + 1), g = i.achievements ? o(fe.slice(0, i.newAchievements ? 16 : 10)).slice(0, 3).map((e) => ({
		id: e,
		values: (["river", "twice"].includes(e) ? [
			10,
			7,
			4
		] : [
			"green",
			"food",
			"enclosures",
			"connections",
			"corners",
			"playgrounds"
		].includes(e) ? [
			9,
			6,
			3
		] : [
			8,
			5,
			2
		]).slice(0, s === 2 ? 2 : 3)
	})) : [];
	return { state: {
		config: i,
		players: m,
		active: f[0],
		phase: "place",
		turn: 1,
		supply: c,
		statues: h.reverse(),
		stacks: [p.slice(0, 6), p.slice(6)],
		exits: i.grizzlies ? [
			0,
			1,
			2,
			3
		].map((e) => `exit${e}`) : [],
		goals: g,
		pending: "",
		last: null,
		exchanged: !1,
		finalLeft: null,
		towerCount: i.monorails ? s * 7 : 0,
		carValues: i.monorails ? [
			10,
			8,
			6,
			5,
			4,
			3
		].flatMap((e) => Array(s).fill(e)) : [],
		log: [],
		removed: [],
		turnStatues: 0,
		turnEnclosures: 0,
		covered: ""
	} };
}
function U(e, t) {
	e.pending = [...e.pending].filter((n) => n === "b" ? t.boards.length < (e.config.grizzlies ? 5 : 4) && he(t, t.boards.length === 4).length && (t.boards.length === 4 ? e.exits.length : e.stacks.some((e) => e.length)) : ge(e, n).length).join(""), e.phase = e.pending ? "rewards" : "statues";
}
function Ce(e, t) {
	return t.config.grizzlies && (e.supply.some((e) => O[e.def].kind === "green") || t.supply.some((e) => O[e.def].kind === "green")) && e.supply.some((e) => O[e.def].kind === "house") && t.supply.some((t) => O[t.def].kind === "grizzly" && V(e, t).length);
}
function W(e, t) {
	if (e.finalLeft === null && t.boards.length === (e.config.grizzlies ? 5 : 4) && t.boards.every((e) => ve(t, e)) ? e.finalLeft = e.players.length - 1 : e.finalLeft !== null && e.finalLeft--, e.finalLeft === 0 || e.finalLeft === null && e.players.every((t) => !t.supply.some((e) => V(t, e).length) && !e.supply.some((e) => O[e.def].kind === "green" && V(t, e).length) && !Ce(t, e))) {
		e.phase = "done";
		return;
	}
	let n = e.players.findIndex((t) => t.rid === e.active);
	e.active = e.players[(n + 1) % e.players.length].rid, e.phase = "place", e.turn++, e.pending = "", e.last = null, e.exchanged = !1, e.turnStatues = 0, e.turnEnclosures = 0, e.covered = "";
}
function we(e, t, n) {
	let r = () => ({ code: "games.barenpark.errAction" });
	if (e.phase === "done") return r();
	if (t.type === "tick") {
		if (n.by !== "$engine" || !["statues", "achievements"].includes(e.phase)) return r();
		let t = structuredClone(e), i = t.players.find((e) => e.rid === t.active), a = [];
		if (t.phase === "statues") {
			let e = i.boards.find((e) => !e.statue && !e.pitCovered && ve(i, e));
			e ? (e.statue = t.statues.shift() ?? 0, t.turnStatues++, a.push({
				kind: "statue",
				rid: i.rid,
				data: {
					board: e.id,
					value: e.statue
				}
			}), t.log.push({
				rid: i.rid,
				kind: "statue",
				value: String(e.statue)
			})) : t.phase = "achievements";
		} else {
			let e = t.goals.find((e) => e.values.length && i.achievements[e.id] === void 0 && Se(e.id, i, t));
			if (e) {
				let n = e.values.shift();
				i.achievements[e.id] = n, a.push({
					kind: "achievement",
					rid: i.rid,
					data: {
						goal: e.id,
						value: n
					}
				}), t.log.push({
					rid: i.rid,
					kind: "achievement",
					value: e.id
				});
			} else t.phase = "end";
		}
		return ye(i), {
			state: t,
			fx: a
		};
	}
	if (n.by !== e.active) return { code: "games.barenpark.errTurn" };
	let i = structuredClone(e), a = i.players.find((e) => e.rid === n.by), o = [], s = i.config.pitVariant && i.finalLeft !== null;
	if (t.type === "exchange") {
		if (!i.config.grizzlies || i.exchanged || !["place", "end"].includes(i.phase)) return r();
		let e = a.supply.find((e) => e.id === t.green), n = a.supply.find((e) => e.id === t.house), s = i.supply.find((e) => e.id === t.grizzly);
		if (!e || !n || !s || O[e.def].kind !== "green" || O[n.def].kind !== "house" || O[s.def].kind !== "grizzly") return r();
		a.supply = a.supply.filter((t) => t.id !== e.id && t.id !== n.id), i.removed.push(e, n), a.supply.push(s), i.supply = i.supply.filter((e) => e.id !== s.id), i.exchanged = !0, o.push({
			kind: "exchange",
			rid: a.rid,
			data: {
				def: s.def,
				tile: s.id,
				given: [e.def, n.def]
			}
		});
	} else if (t.type === "place") {
		let e = a.supply.find((e) => e.id === t.tile);
		if (i.phase !== "place" || !e || !pe(a, e.def, t.x, t.y, t.rotation, t.flipped, s)) return { code: "games.barenpark.errPlacement" };
		let n = {
			...e,
			x: t.x,
			y: t.y,
			rotation: t.rotation,
			flipped: t.flipped
		}, r = z(a);
		i.last = n, i.covered = R(n).map(([e, t]) => r.get(F(e, t))).filter((e) => "wceb".includes(e)).join(""), i.pending = i.covered;
		for (let e of a.boards) {
			let t = k[e.id].indexOf("p");
			R(n).some(([n, r]) => n === e.x * 4 + t % 4 && r === e.y * 4 + Math.floor(t / 4)) && (e.pitCovered = !0);
		}
		a.supply = a.supply.filter((t) => t.id !== e.id), a.placed.push(n), o.push({
			kind: "place",
			rid: a.rid,
			data: {
				def: e.def,
				tile: e.id,
				x: t.x,
				y: t.y,
				rotation: t.rotation,
				flipped: t.flipped
			}
		}), i.log.push({
			rid: a.rid,
			kind: "place",
			value: e.def
		}), U(i, a), i.config.monorails && _e(a, i.last, i.towerCount, i.carValues).length && (i.phase = "tower");
	} else if (t.type === "take") {
		if (i.phase !== "rewards" || !i.pending.includes(t.icon)) return r();
		let e = ge(i, t.icon).find((e) => e.id === t.tile);
		if (!e) return r();
		i.supply = i.supply.filter((t) => t.id !== e.id), a.supply.push(e), i.pending = i.pending.replace(t.icon, ""), O[e.def].kind === "enclosure" && i.turnEnclosures++, o.push({
			kind: "take",
			rid: a.rid,
			data: {
				def: e.def,
				tile: e.id
			}
		}), U(i, a);
	} else if (t.type === "expand") {
		let e = a.boards.length === 4;
		if (i.phase !== "rewards" || !i.pending.includes("b") || !he(a, e).some(([e, n]) => e === t.x && n === t.y)) return r();
		let n = e ? i.exits[t.source - 2] : i.stacks[t.source]?.[0];
		if (!n || e && !i.config.grizzlies || a.boards.length >= (i.config.grizzlies ? 5 : 4)) return r();
		e ? i.exits.splice(t.source - 2, 1) : i.stacks[t.source].shift(), a.boards.push({
			id: n,
			x: t.x,
			y: t.y,
			statue: 0,
			pitCovered: !1
		}), i.pending = i.pending.replace("b", ""), U(i, a), o.push({
			kind: "expand",
			rid: a.rid,
			data: {
				board: n,
				source: t.source
			}
		});
	} else if (t.type === "tower" || t.type === "skipTower") {
		if (i.phase !== "tower") return r();
		if (t.type === "tower") {
			if (!_e(a, i.last, i.towerCount, i.carValues).some((e) => e.x === t.x && e.y === t.y && e.connect === t.connect)) return r();
			let e = a.towers.length;
			a.towers.push({
				x: t.x,
				y: t.y
			}), i.towerCount--;
			let n = 0;
			t.connect >= 0 && (n = i.carValues.shift(), a.cars.push({
				a: t.connect,
				b: e,
				value: n
			})), o.push({
				kind: "tower",
				rid: a.rid,
				data: {
					value: n,
					tower: e,
					car: n ? a.cars.length - 1 : -1,
					connect: t.connect
				}
			});
		}
		U(i, a);
	} else if (t.type === "pass") {
		if (i.phase !== "place" || a.supply.some((e) => V(a, e, s).length)) return { code: "games.barenpark.errPass" };
		let e = i.supply.find((e) => e.id === t.tile && O[e.def].kind === "green");
		if (!e && (t.tile || i.supply.some((e) => O[e.def].kind === "green"))) return r();
		e && (a.supply.push(e), i.supply = i.supply.filter((t) => t.id !== e.id), o.push({
			kind: "take",
			rid: a.rid,
			data: {
				def: e.def,
				tile: e.id
			}
		})), i.phase = "end", i.log.push({
			rid: a.rid,
			kind: "pass",
			value: ""
		});
	} else if (t.type === "finish") {
		if (i.phase !== "end") return r();
		W(i, a);
	} else return r();
	return ye(a), i.log = i.log.slice(-12), {
		state: i,
		fx: o
	};
}
var Te = {
	meta: re,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ae,
		config: ie,
		publicView: ue,
		privateView: de
	},
	setup: H,
	reduce: we,
	viewFor: (e) => ({
		public: {
			config: e.config,
			players: e.players,
			active: e.active,
			phase: e.phase,
			turn: e.turn,
			supply: e.supply,
			statues: e.statues,
			stacks: e.stacks.map((e) => ({
				top: e[0] ?? null,
				count: e.length
			})),
			exits: e.exits,
			goals: e.goals,
			pending: e.pending,
			last: e.last,
			exchanged: e.exchanged,
			finalLeft: e.finalLeft,
			towerCount: e.towerCount,
			carValues: e.carValues,
			log: e.log
		},
		private: {}
	}),
	status: (e) => {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((e, t) => t.score.total - e.score.total || t.score.reserve - e.score.reserve), n = t[0];
		return {
			phase: "done",
			ranking: t.map((e) => e.rid),
			winner: t.filter((e) => e.score.total === n.score.total && e.score.reserve === n.score.reserve).map((e) => e.rid),
			scores: Object.fromEntries(e.players.map((e) => [e.rid, e.score.total]))
		};
	},
	nextTickIn: (e) => ["statues", "achievements"].includes(e.phase) ? 420 : null
}, Ee = {
	green: "games.barenpark.green",
	house: "games.barenpark.house",
	enclosure: "games.barenpark.enclosure",
	grizzly: "games.barenpark.grizzly"
}, De = {
	polar: "games.barenpark.polar",
	gobi: "games.barenpark.gobi",
	koala: "games.barenpark.koala",
	panda: "games.barenpark.panda"
}, Oe = {
	toilet: "games.barenpark.toilet",
	playground: "games.barenpark.playground",
	"food-street": "games.barenpark.food",
	river: "games.barenpark.river"
}, ke = {
	w: "games.barenpark.wheelbarrow",
	c: "games.barenpark.cement",
	e: "games.barenpark.excavator",
	b: "games.barenpark.crew",
	p: "games.barenpark.pit"
}, Ae = {
	polar: "games.barenpark.goalPolar",
	gobi: "games.barenpark.goalGobi",
	koala: "games.barenpark.goalKoala",
	panda: "games.barenpark.goalPanda",
	green: "games.barenpark.goalGreen",
	food: "games.barenpark.goalFood",
	river: "games.barenpark.goalRiver",
	enclosures: "games.barenpark.goalEnclosures",
	houses: "games.barenpark.goalHouses",
	twice: "games.barenpark.goalTwice",
	freeze: "games.barenpark.goalFreeze",
	planning: "games.barenpark.goalPlanning",
	toilets: "games.barenpark.goalToilets",
	connections: "games.barenpark.goalConnections",
	corners: "games.barenpark.goalCorners",
	playgrounds: "games.barenpark.goalPlaygrounds"
}, je = {
	polar: "games.barenpark.rulePolar",
	gobi: "games.barenpark.ruleGobi",
	koala: "games.barenpark.ruleKoala",
	panda: "games.barenpark.rulePanda",
	green: "games.barenpark.ruleGreen",
	food: "games.barenpark.ruleFood",
	river: "games.barenpark.ruleRiver",
	enclosures: "games.barenpark.ruleEnclosures",
	houses: "games.barenpark.ruleHouses",
	twice: "games.barenpark.ruleTwice",
	freeze: "games.barenpark.ruleFreeze",
	planning: "games.barenpark.rulePlanning",
	toilets: "games.barenpark.ruleToilets",
	connections: "games.barenpark.ruleConnections",
	corners: "games.barenpark.ruleCorners",
	playgrounds: "games.barenpark.rulePlaygrounds"
};
function G(e) {
	return Oe[e] ?? Ee[O[e].kind];
}
//#endregion
//#region src/games/barenpark/pieces.tsx
var K = (e) => `games/barenpark/${e}`;
function q({ def: e, rotation: t = 0, flipped: n = !1, ghost: i = !1 }) {
	let a = r().replaceAll(":", ""), o = u(), s = O[e], c = L(e, t, n), l = Math.max(...c.map(([e]) => e)) + 1, d = Math.max(...c.map(([, e]) => e)) + 1, f = Math.max(...s.cells.map(([e]) => e)) + 1, p = Math.max(...s.cells.map(([, e]) => e)) + 1, [m, h] = I([1, 0], t, n), [g, _] = I([0, 1], t, n), ee = s.cells.map((e) => I(e, t, n)), v = Math.min(...ee.map(([e]) => e)), x = Math.min(...ee.map(([, e]) => e)), S = -v + .5 - (m + g) / 2, C = -x + .5 - (h + _) / 2;
	return /* @__PURE__ */ b("svg", {
		className: "bp-piece",
		viewBox: `0 0 ${l * 100} ${d * 100}`,
		role: "img",
		"aria-label": o(G(e)),
		children: [/* @__PURE__ */ y("defs", { children: /* @__PURE__ */ y("clipPath", {
			id: a,
			children: s.cells.map(([e, t]) => /* @__PURE__ */ y("rect", {
				x: e * 100,
				y: t * 100,
				width: 100,
				height: 100
			}, `${e},${t}`))
		}) }), /* @__PURE__ */ y("g", {
			opacity: i ? .75 : 1,
			transform: `matrix(${m} ${h} ${g} ${_} ${S * 100} ${C * 100})`,
			children: /* @__PURE__ */ y("image", {
				href: K(s.art),
				width: f * 100,
				height: p * 100,
				clipPath: `url(#${a})`
			})
		})]
	});
}
function Me({ x: e, y: t, w: n = 100, h: r = 100 }) {
	return /* @__PURE__ */ b("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ y("rect", {
			x: e + 4,
			y: t + 4,
			width: n - 8,
			height: r - 8,
			rx: 6,
			fill: "#e7f5e9",
			fillOpacity: .32,
			stroke: "#fff",
			strokeWidth: 7
		}), /* @__PURE__ */ y("rect", {
			className: "bp-march",
			x: e + 4,
			y: t + 4,
			width: n - 8,
			height: r - 8,
			rx: 6,
			fill: "none",
			stroke: "#2d7654",
			strokeWidth: 4,
			strokeDasharray: "11 8",
			children: /* @__PURE__ */ y("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-38",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})]
	});
}
//#endregion
//#region src/games/barenpark/board.tsx
function Ne() {
	let e = u();
	return /* @__PURE__ */ b("div", {
		className: "bp-brand",
		children: [/* @__PURE__ */ y("strong", { children: e("games.barenpark.name") }), /* @__PURE__ */ y("span", { children: "B Ä R E N P A R K" })]
	});
}
function Pe({ x: e, y: t, flip: n = !1 }) {
	return /* @__PURE__ */ b("g", {
		transform: `translate(${e} ${t}) scale(${n ? -1 : 1} 1)`,
		pointerEvents: "none",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ y("path", {
			d: "M-29 11l-9-10 5-13 12-3 1-13 15-4 11 7 14-2 8 9 10 2 3 13-7 9-3 12-18 1-12 5-14-7Z",
			fill: "#3f5836",
			stroke: "#3b5135",
			strokeWidth: .8
		}), [
			[
				-23,
				-6,
				-40
			],
			[
				-12,
				-17,
				25
			],
			[
				2,
				-19,
				65
			],
			[
				18,
				-9,
				12
			],
			[
				26,
				4,
				60
			],
			[
				13,
				13,
				-25
			],
			[
				-3,
				13,
				40
			],
			[
				-19,
				8,
				10
			],
			[
				-6,
				-2,
				45
			],
			[
				10,
				1,
				-40
			]
		].map(([e, t, n], r) => /* @__PURE__ */ b("g", {
			transform: `translate(${e} ${t}) rotate(${n})`,
			children: [/* @__PURE__ */ y("path", {
				d: "M-10 1Q-11-10 0-13Q12-9 11 0Q4 9-10 1Z",
				fill: [
					"#6d8448",
					"#8a9b54",
					"#5b773e"
				][r % 3]
			}), /* @__PURE__ */ y("path", {
				d: "M-6 1l14-6m-8 2 1-5m-4 7-1-5",
				stroke: "#a2ad69",
				strokeWidth: .7,
				fill: "none"
			})]
		}, r))]
	});
}
function Fe({ tile: e }) {
	let { ref: t, hidden: n } = c(`placed:${e.id}`), r = L(e.def, e.rotation, e.flipped), i = (Math.max(...r.map(([e]) => e)) + 1) * 100, a = (Math.max(...r.map(([, e]) => e)) + 1) * 100;
	return /* @__PURE__ */ y("foreignObject", {
		x: e.x * 100,
		y: e.y * 100,
		width: i,
		height: a,
		children: /* @__PURE__ */ y("div", {
			ref: t,
			style: {
				width: "100%",
				height: "100%",
				visibility: n ? "hidden" : void 0
			},
			children: /* @__PURE__ */ y(q, {
				def: e.def,
				rotation: e.rotation,
				flipped: e.flipped
			})
		})
	});
}
function Ie({ board: e, rid: t }) {
	let n = u(), { ref: r, hidden: i } = c(`area:${t}:${e.id}`);
	return /* @__PURE__ */ b("g", {
		transform: `translate(${e.x * 400} ${e.y * 400})`,
		children: [
			/* @__PURE__ */ y("foreignObject", {
				width: 400,
				height: 400,
				children: /* @__PURE__ */ y("div", {
					ref: r,
					style: {
						width: "100%",
						height: "100%",
						visibility: i ? "hidden" : void 0
					},
					children: /* @__PURE__ */ y(Be, {
						id: e.id,
						full: !0
					})
				})
			}),
			e.id.startsWith("entrance") && /* @__PURE__ */ b("g", {
				pointerEvents: "none",
				children: [
					/* @__PURE__ */ y("path", {
						d: "M140 440v48h120v-48",
						fill: "#c5b492",
						stroke: "#a99670",
						strokeWidth: 2
					}),
					/* @__PURE__ */ y("rect", {
						x: 17,
						y: 411,
						width: 366,
						height: 39,
						rx: 2,
						fill: "#80512d"
					}),
					/* @__PURE__ */ y("rect", {
						x: 10,
						y: 404,
						width: 380,
						height: 39,
						rx: 2,
						fill: "#e9b342",
						stroke: "#703c2b",
						strokeWidth: 2
					}),
					/* @__PURE__ */ y("path", {
						d: "M17 408h366",
						stroke: "#ffdf86",
						strokeWidth: 2
					}),
					/* @__PURE__ */ y("image", {
						href: K("statue-16.svg"),
						x: 27,
						y: 409,
						width: 29,
						height: 29
					}),
					/* @__PURE__ */ y("image", {
						href: K("statue-14.svg"),
						x: 344,
						y: 409,
						width: 29,
						height: 29
					}),
					/* @__PURE__ */ y("text", {
						x: 200,
						y: 432,
						textAnchor: "middle",
						fill: "#703c2b",
						fontSize: 26,
						fontWeight: 900,
						children: n("games.barenpark.name")
					}),
					Array.from({ length: 10 }, (e, t) => /* @__PURE__ */ y("rect", {
						x: 29 + t * 34,
						y: 448,
						width: 25,
						height: 8,
						fill: t % 2 ? "#698c9b" : "#c2cfcc",
						stroke: "#697b76"
					}, t))
				]
			}),
			e.id.startsWith("exit") && /* @__PURE__ */ y("path", {
				d: "M175 0v-13h50V0",
				fill: "#e8dfcb",
				stroke: "#5e654b",
				strokeWidth: 5
			})
		]
	});
}
function Le({ board: e, rid: t }) {
	let n = k[e.id].indexOf("p"), { ref: r, hidden: i } = c(`statue:${t}:${e.id}`);
	return /* @__PURE__ */ y("foreignObject", {
		x: (e.x * 4 + n % 4) * 100 + 3,
		y: (e.y * 4 + Math.floor(n / 4)) * 100 + 3,
		width: 94,
		height: 94,
		children: /* @__PURE__ */ y("div", {
			ref: r,
			style: {
				width: "100%",
				height: "100%",
				visibility: i ? "hidden" : void 0
			},
			children: /* @__PURE__ */ y("img", {
				src: K(`statue-${e.statue}.svg`),
				alt: "",
				style: {
					width: "100%",
					height: "100%"
				}
			})
		})
	});
}
function J({ player: e, index: t }) {
	let n = e.cars[t], r = e.towers[n.a], i = e.towers[n.b], a = r.y === i.y, { ref: o, hidden: s } = c(`car:${e.rid}:${t}`);
	return /* @__PURE__ */ y("g", {
		transform: `translate(${(r.x + i.x + 1) * 50} ${(r.y + i.y + 1) * 50}) rotate(${a ? 0 : 90})`,
		children: /* @__PURE__ */ y("foreignObject", {
			x: -151,
			y: -26,
			width: 302,
			height: 52,
			children: /* @__PURE__ */ y("div", {
				ref: o,
				style: {
					width: "100%",
					height: "100%",
					visibility: s ? "hidden" : void 0
				},
				children: /* @__PURE__ */ b("svg", {
					viewBox: "0 0 302 52",
					width: "100%",
					height: "100%",
					children: [/* @__PURE__ */ y("rect", {
						x: 0,
						y: 9,
						width: 302,
						height: 34,
						rx: 8,
						fill: "#615853",
						stroke: "#e4dfd2",
						strokeWidth: 4
					}), /* @__PURE__ */ y("image", {
						href: K(`car-${n.value}.svg`),
						x: 19,
						width: 264,
						height: 52
					})]
				})
			})
		})
	});
}
function Re({ player: e, index: t }) {
	let n = e.towers[t], { ref: r } = c(`tower:${e.rid}:${t}`);
	return /* @__PURE__ */ y("foreignObject", {
		x: n.x * 100,
		y: n.y * 100,
		width: 100,
		height: 100,
		children: /* @__PURE__ */ y("div", {
			ref: r,
			style: {
				width: "100%",
				height: "100%"
			},
			children: /* @__PURE__ */ b("svg", {
				viewBox: "-50 -50 100 100",
				children: [
					/* @__PURE__ */ y("ellipse", {
						cy: 7,
						rx: 20,
						ry: 13,
						fill: "#3e4a3b",
						opacity: .4
					}),
					/* @__PURE__ */ y("path", {
						d: "M-13 7l5-38h16l5 38Z",
						fill: "#a5b6a2",
						stroke: "#384a40",
						strokeWidth: 4
					}),
					/* @__PURE__ */ y("path", {
						d: "M-20-31H20",
						stroke: "#384a40",
						strokeWidth: 9
					})
				]
			})
		})
	});
}
function ze({ player: e, targets: t = [], expansion: n = [], towers: i = [], ghost: a, onTarget: o, onExpansion: c, onTower: l }) {
	let d = u(), f = r().replaceAll(":", ""), [p, m] = s(null), h = i.filter((e, t) => i.findIndex((t) => e.x === t.x && e.y === t.y) === t), g = p ? i.filter((e) => e.x === p[0] && e.y === p[1]) : [], _ = [...e.boards.map((e) => e.x * 4), ...n.map(([e]) => e * 4)], ee = [...e.boards.map((e) => e.y * 4), ...n.map(([, e]) => e * 4)], v = Math.min(..._), x = Math.min(...ee), S = Math.max(..._) - v + 4, C = Math.max(...ee) - x + 4, w = (t, n) => e.boards.some((e) => e.x === t && e.y === n);
	return /* @__PURE__ */ b("svg", {
		className: "bp-board",
		viewBox: `${v * 100 - 42} ${x * 100 - 42} ${S * 100 + 84} ${C * 100 + 140}`,
		"aria-label": d("games.barenpark.entrance"),
		children: [
			/* @__PURE__ */ y("defs", { children: /* @__PURE__ */ b("pattern", {
				id: f,
				width: 100,
				height: 100,
				patternUnits: "userSpaceOnUse",
				children: [
					/* @__PURE__ */ y("rect", {
						width: 100,
						height: 100,
						fill: "#e9d4a0"
					}),
					/* @__PURE__ */ y("path", {
						d: "M0 0H100V100",
						fill: "none",
						stroke: "#b9a16d",
						strokeWidth: 2
					}),
					/* @__PURE__ */ y("path", {
						d: "M14 24h4m41 47h5M75 18h3M26 84h6",
						stroke: "#ceb580",
						strokeWidth: 2
					})
				]
			}) }),
			e.boards.map((e) => /* @__PURE__ */ b("g", {
				transform: `translate(${e.x * 400} ${e.y * 400})`,
				pointerEvents: "none",
				children: [
					!w(e.x, e.y - 1) && /* @__PURE__ */ y("path", {
						d: "M-10-7H410",
						stroke: "#ede2b8",
						strokeWidth: 11
					}),
					!w(e.x - 1, e.y) && /* @__PURE__ */ y("path", {
						d: "M-7-10V410",
						stroke: "#b5b47e",
						strokeWidth: 11
					}),
					!w(e.x + 1, e.y) && /* @__PURE__ */ y("path", {
						d: "M407-10V410",
						stroke: "#9d9c70",
						strokeWidth: 11
					}),
					!w(e.x, e.y + 1) && /* @__PURE__ */ y("path", {
						d: "M-10 407H410",
						stroke: "#9d9c70",
						strokeWidth: 13
					})
				]
			}, e.id)),
			e.boards.map((t) => /* @__PURE__ */ y(Ie, {
				board: t,
				rid: e.rid
			}, t.id)),
			e.placed.map((e) => /* @__PURE__ */ y(Fe, { tile: e }, e.id)),
			e.boards.filter((e) => e.statue > 0).map((t) => /* @__PURE__ */ y(Le, {
				board: t,
				rid: e.rid
			}, t.id)),
			e.cars.map((t, n) => /* @__PURE__ */ y(J, {
				player: e,
				index: n
			}, n)),
			e.towers.map((t, n) => /* @__PURE__ */ y(Re, {
				player: e,
				index: n
			}, n)),
			e.boards.map((e) => /* @__PURE__ */ b("g", { children: [
				!w(e.x - 1, e.y) && !w(e.x, e.y - 1) && /* @__PURE__ */ y(Pe, {
					x: e.x * 400 - 12,
					y: e.y * 400
				}),
				!w(e.x + 1, e.y) && !w(e.x, e.y - 1) && /* @__PURE__ */ y(Pe, {
					x: e.x * 400 + 412,
					y: e.y * 400,
					flip: !0
				}),
				!w(e.x - 1, e.y) && !w(e.x, e.y + 1) && /* @__PURE__ */ y(Pe, {
					x: e.x * 400 - 12,
					y: e.y * 400 + 405
				}),
				!w(e.x + 1, e.y) && !w(e.x, e.y + 1) && /* @__PURE__ */ y(Pe, {
					x: e.x * 400 + 412,
					y: e.y * 400 + 405,
					flip: !0
				})
			] }, e.id)),
			a && (() => {
				let e = L(a.def, a.rotation, a.flipped), t = (Math.max(...e.map(([e]) => e)) + 1) * 100, n = (Math.max(...e.map(([, e]) => e)) + 1) * 100;
				return /* @__PURE__ */ b("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ y("svg", {
						x: a.x * 100,
						y: a.y * 100,
						width: t,
						height: n,
						viewBox: `0 0 ${t} ${n}`,
						children: /* @__PURE__ */ y(q, {
							def: a.def,
							rotation: a.rotation,
							flipped: a.flipped,
							ghost: !0
						})
					}), e.map(([e, t]) => /* @__PURE__ */ y(Me, {
						x: (a.x + e) * 100,
						y: (a.y + t) * 100
					}, `${e},${t}`))]
				});
			})(),
			t.map(([e, t]) => /* @__PURE__ */ b("g", {
				role: "button",
				tabIndex: 0,
				"aria-label": d("games.barenpark.placeAt", {
					x: e + 1,
					y: t + 1
				}),
				onClick: () => o?.(e, t),
				onKeyDown: (n) => {
					(n.key === "Enter" || n.key === " ") && (n.preventDefault(), o?.(e, t));
				},
				children: [/* @__PURE__ */ y(Me, {
					x: e * 100,
					y: t * 100
				}), /* @__PURE__ */ y("rect", {
					x: e * 100,
					y: t * 100,
					width: 100,
					height: 100,
					fill: "transparent"
				})]
			}, `${e},${t}`)),
			n.map(([e, t]) => /* @__PURE__ */ b("g", {
				role: "button",
				tabIndex: 0,
				"aria-label": d("games.barenpark.expandAt"),
				onClick: () => c?.(e, t),
				onKeyDown: (n) => {
					(n.key === "Enter" || n.key === " ") && (n.preventDefault(), c?.(e, t));
				},
				children: [
					/* @__PURE__ */ y(Me, {
						x: e * 400,
						y: t * 400,
						w: 400,
						h: 400
					}),
					/* @__PURE__ */ y("text", {
						x: e * 400 + 200,
						y: t * 400 + 220,
						textAnchor: "middle",
						fontSize: 96,
						fill: "#527b40",
						children: "＋"
					}),
					/* @__PURE__ */ y("rect", {
						x: e * 400,
						y: t * 400,
						width: 400,
						height: 400,
						fill: "transparent"
					})
				]
			}, `${e},${t}`)),
			h.map((e, t) => {
				let n = () => {
					i.filter((t) => e.x === t.x && e.y === t.y).length === 1 ? l?.(e) : m([e.x, e.y]);
				};
				return /* @__PURE__ */ b("g", {
					role: "button",
					tabIndex: 0,
					"aria-label": d("games.barenpark.towerAt"),
					onClick: n,
					onKeyDown: (e) => {
						(e.key === "Enter" || e.key === " ") && (e.preventDefault(), n());
					},
					children: [
						/* @__PURE__ */ y(Me, {
							x: e.x * 100,
							y: e.y * 100
						}),
						/* @__PURE__ */ y("circle", {
							cx: e.x * 100 + 50,
							cy: e.y * 100 + 50,
							r: 15,
							fill: "#fbf7da",
							stroke: "#3f6145",
							strokeWidth: 4
						}),
						/* @__PURE__ */ y("rect", {
							x: e.x * 100,
							y: e.y * 100,
							width: 100,
							height: 100,
							fill: "transparent"
						})
					]
				}, t);
			}),
			g.map((t) => {
				let n = e.towers[t.connect];
				return n && /* @__PURE__ */ b("g", {
					role: "button",
					tabIndex: 0,
					"aria-label": d("games.barenpark.connectTower", { n: t.connect + 1 }),
					onClick: () => {
						l?.(t), m(null);
					},
					onKeyDown: (e) => {
						(e.key === "Enter" || e.key === " ") && (e.preventDefault(), l?.(t), m(null));
					},
					children: [
						/* @__PURE__ */ y("path", {
							d: `M${t.x * 100 + 50} ${t.y * 100 + 50}L${n.x * 100 + 50} ${n.y * 100 + 50}`,
							fill: "none",
							stroke: "#fff5c4",
							strokeWidth: 12,
							pointerEvents: "none"
						}),
						/* @__PURE__ */ y(Me, {
							x: n.x * 100,
							y: n.y * 100
						}),
						/* @__PURE__ */ y("text", {
							x: n.x * 100 + 50,
							y: n.y * 100 + 58,
							fontSize: 30,
							textAnchor: "middle",
							fill: "#2d7654",
							children: t.connect + 1
						}),
						/* @__PURE__ */ y("rect", {
							x: n.x * 100,
							y: n.y * 100,
							width: 100,
							height: 100,
							fill: "transparent"
						})
					]
				}, t.connect);
			})
		]
	});
}
function Be({ id: e, full: t = !1 }) {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 400 400",
		className: t ? "bp-area-art" : "bp-area-preview",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ y("rect", {
			width: 400,
			height: 400,
			rx: 1,
			fill: "#e4cc93",
			stroke: "#a28b5f",
			strokeWidth: 3
		}), [...k[e]].map((e, t) => /* @__PURE__ */ b("g", { children: [
			/* @__PURE__ */ y("path", {
				d: `M${t % 4 * 100} ${Math.floor(t / 4) * 100}h100v100`,
				fill: "none",
				stroke: "#c1a56d",
				strokeWidth: 1.5
			}),
			/* @__PURE__ */ y("path", {
				d: `M${t % 4 * 100 + 14} ${Math.floor(t / 4) * 100 + 22}l17-1m30 53 12 1`,
				stroke: "#c4aa76",
				strokeWidth: 1,
				opacity: .65
			}),
			e !== "." && /* @__PURE__ */ y("image", {
				href: K(`icon-${e}.svg`),
				x: t % 4 * 100 + 12,
				y: Math.floor(t / 4) * 100 + 12,
				width: 76,
				height: 76
			})
		] }, t))]
	});
}
//#endregion
//#region src/games/barenpark/use-park-gestures.ts
function Ve(e, t, r) {
	let a = o(null), s = n((e) => (a.current = e, r?.(e)), [r]), c = o(/* @__PURE__ */ new Map()), l = o(!1), u = o(0), d = o(null);
	i(() => {
		let t = d.current;
		t && (t.el.scrollLeft = t.x * e - t.screenX, t.el.scrollTop = t.y * e - t.screenY, d.current = null);
	}, [e]);
	let f = (n) => {
		let r = Math.max(1, Math.min(12, e * n)), i = a.current;
		if (r !== e) {
			if (i) {
				let t = i.clientWidth / 2, n = i.clientHeight / 2;
				d.current = {
					el: i,
					x: (i.scrollLeft + t) / e,
					y: (i.scrollTop + n) / e,
					screenX: t,
					screenY: n
				};
			}
			t(r);
		}
	}, p = (e) => {
		e.pointerType === "touch" && (c.current.size || (l.current = !1, u.current = 0), c.current.set(e.pointerId, [e.clientX, e.clientY]));
	}, m = (n) => {
		let r = c.current.get(n.pointerId);
		if (!r) return;
		let i = [...c.current.values()];
		if (c.current.set(n.pointerId, [n.clientX, n.clientY]), u.current += Math.hypot(n.clientX - r[0], n.clientY - r[1]), (u.current > 7 || c.current.size > 1) && (l.current = !0, n.currentTarget.setPointerCapture(n.pointerId), n.preventDefault()), l.current) {
			if (c.current.size === 1) n.currentTarget.scrollLeft -= n.clientX - r[0], n.currentTarget.scrollTop -= n.clientY - r[1];
			else {
				let r = [...c.current.values()], a = (e) => Math.hypot(e[0][0] - e[1][0], e[0][1] - e[1][1]), o = a(i);
				if (!o) return;
				let s = n.currentTarget.getBoundingClientRect(), l = (r[0][0] + r[1][0]) / 2 - s.left, u = (r[0][1] + r[1][1]) / 2 - s.top, f = (i[0][0] + i[1][0]) / 2 - s.left, p = (i[0][1] + i[1][1]) / 2 - s.top, m = Math.max(1, Math.min(12, e * a(r) / o)), h = {
					el: n.currentTarget,
					x: (n.currentTarget.scrollLeft + f) / e,
					y: (n.currentTarget.scrollTop + p) / e,
					screenX: l,
					screenY: u
				};
				m === e ? (h.el.scrollLeft = h.x * e - l, h.el.scrollTop = h.y * e - u) : (d.current = h, t(m));
			}
		}
	}, h = (e) => {
		c.current.delete(e.pointerId), e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
	};
	return {
		ref: s,
		zoomIn: () => f(1.5),
		zoomOut: () => f(1 / 1.5),
		onPointerDown: p,
		onPointerMove: m,
		onPointerUp: h,
		onPointerCancel: h,
		onClickCapture: (e) => {
			l.current &&= (e.preventDefault(), e.stopPropagation(), !1);
		}
	};
}
//#endregion
//#region src/games/barenpark/view-player.tsx
function He({ tile: e, selected: t, disabled: n, onClick: r, count: i, labelled: a = !0 }) {
	let o = u(), { ref: s, hidden: l } = c(`tile:${e.id}`), d = O[e.def], f = `${d.species && d.kind !== "grizzly" ? o(De[d.species]) + " · " : ""}${o(G(e.def))}${e.value ? " · " + o("games.barenpark.score", { n: e.value }) : ""}`;
	return /* @__PURE__ */ b("button", {
		className: `bp-tile${t ? " bp-selected" : ""}`,
		title: f,
		"aria-label": f,
		"aria-pressed": t,
		disabled: n,
		onClick: r,
		children: [/* @__PURE__ */ y("div", {
			ref: s,
			className: "bp-tile-art",
			style: { visibility: l ? "hidden" : void 0 },
			children: /* @__PURE__ */ y(q, { def: e.def })
		}), /* @__PURE__ */ b("span", {
			className: "bp-tile-label",
			children: [a && o(d.species && d.kind !== "grizzly" ? De[d.species] : G(e.def)), i !== void 0 && d.kind === "green" && /* @__PURE__ */ b("b", { children: ["×", i] })]
		})]
	});
}
var Ue = (e) => e.filter((t, n) => e.findIndex((e) => e.def === t.def) === n).map((t) => ({
	tile: t,
	count: e.filter((e) => e.def === t.def).length
}));
function We({ rid: e, children: t }) {
	let { ref: n } = c(`seat:${e}`);
	return /* @__PURE__ */ y("div", {
		ref: n,
		className: "bp-seat-slot",
		children: t
	});
}
function Ge({ kind: e, children: t }) {
	let { ref: n } = c(`market:${e}`);
	return /* @__PURE__ */ y("section", {
		ref: n,
		className: `bp-supply-section bp-market-${e}`,
		children: t
	});
}
function Ke({ value: e, first: t }) {
	let n = u(), { ref: r } = c(t ? "statue-source" : null);
	return /* @__PURE__ */ y("img", {
		ref: r,
		src: K(`statue-${e}.svg`),
		alt: n("games.barenpark.score", { n: e })
	});
}
function qe({ id: e, source: t, count: n, selected: r, disabled: i, onClick: a }) {
	let o = u(), { ref: s } = c(`deck:${t}`);
	return /* @__PURE__ */ b("button", {
		ref: s,
		className: `bp-area-choice${r ? " bp-selected" : ""}`,
		disabled: i,
		onClick: a,
		"aria-label": t < 2 ? o("games.barenpark.stack", {
			n: t + 1,
			count: n
		}) : o("games.barenpark.exit"),
		children: [/* @__PURE__ */ y(Be, { id: e }), /* @__PURE__ */ y("span", { children: t < 2 ? o("games.barenpark.remaining", { n }) : o("games.barenpark.exit") })]
	});
}
function Je(e) {
	return /* @__PURE__ */ y(Y, {
		...e,
		pub: e.public
	});
}
function Y({ pub: e, members: t, myRid: n, send: r }) {
	let i = u(), o = l((e) => e.locale), [d, x] = s(n), [S, C] = s(null), [w, T] = s(0), [E, te] = s(!1), [D, k] = s(null), [A, ne] = s(""), [j, re] = s(0), [ie, M] = s(!1), [ae, N] = s(1), [P, oe] = s(!1), [se, ce] = s(""), [le, ue] = s(""), [de, fe] = s(""), [I, R] = s(null), [B, me] = s(!1), [ve, ye] = s(""), [be, xe] = s(n);
	be !== n && (xe(n), x(n), C(null), k(null), N(1));
	let Se = `${e.active}:${e.turn}:${e.phase}:${e.pending}:${e.exchanged}:${e.players.map((e) => e.placed.length + ":" + e.supply.length).join("|")}`;
	ve !== Se && (ye(Se), C(null), k(null), T(0), te(!1), oe(!1), ce(""), ue(""), fe(""), M(e.active === n && e.phase === "rewards"));
	let H = e.players.find((e) => e.rid === n), U = e.players.find((e) => e.rid === d) ?? e.players[0], Ce = e.active === n, W = Ce && U.rid === n, { ref: we } = c(`hand:${U.rid}`), { ref: Te } = c(`park:${U.rid}`), { ref: Oe } = c("supply"), { ref: Me } = c("supply-toggle"), { zoomIn: Pe, zoomOut: Fe, ...Ie } = Ve(ae, N, Te), Le = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? ee(n, o) : e;
	}, J = H?.supply.find((e) => e.id === S), Re = e.config.pitVariant && e.finalLeft !== null, Be = a(() => !!H?.supply.some((e) => V(H, e, Re).length), [H, Re]), Je = W && e.phase === "place" && !Be, Y = A && e.pending.includes(A) ? A : e.pending[0] ?? "", Ye = W && e.phase === "rewards" && Y !== "b", X = W && e.phase === "rewards" && Y === "b", Xe = ie, Ze = e.supply.filter((e) => O[e.def].kind !== "grizzly"), Qe = Ue(ge({ supply: Ze }, "e")), $e = new Set((Je ? Ze.filter((e) => O[e.def].kind === "green") : Ye ? ge(e, Y) : []).map((e) => e.def)), Z = a(() => {
		if (!W || e.phase !== "place" || !J || P) return [];
		let t = /* @__PURE__ */ new Set(), n = [], r = L(J.def, w, E), i = z(U);
		for (let e of i.keys()) {
			let [i, a] = e.split(",").map(Number);
			for (let [e, o] of r) {
				let r = i - e, s = a - o, c = F(r, s);
				t.has(c) || (t.add(c), pe(U, J.def, r, s, w, E, Re) && n.push([r, s]));
			}
		}
		return n;
	}, [
		W,
		e.phase,
		J,
		w,
		E,
		U,
		Re,
		P
	]), Q = J && D && Z.some(([e, t]) => e === D[0] && t === D[1]) ? {
		...J,
		x: D[0],
		y: D[1],
		rotation: w,
		flipped: E
	} : null, $ = W && e.phase === "tower" ? _e(U, e.last, e.towerCount, e.carValues) : [], et = W && e.config.grizzlies && !e.exchanged && ["place", "end"].includes(e.phase) && !!H?.supply.some((e) => O[e.def].kind === "green") && !!H?.supply.some((e) => O[e.def].kind === "house") && e.supply.some((e) => O[e.def].kind === "grizzly"), tt = e.phase === "place" ? "games.barenpark.placePrompt" : e.phase === "rewards" ? "games.barenpark.rewardsPrompt" : e.phase === "tower" ? "games.barenpark.towerPrompt" : e.phase === "end" ? "games.barenpark.endPrompt" : "games.barenpark.settling", nt = Ce ? P ? i("games.barenpark.exchangePrompt") : Je ? i("games.barenpark.pass") : J && e.phase === "place" ? i("games.barenpark.placing", { tile: `${O[J.def].species && O[J.def].kind !== "grizzly" ? i(De[O[J.def].species]) + " " : ""}${i(G(J.def))}` }) : i(tt) : i("games.barenpark.waiting", { name: Le(e.active) }), rt = /* @__PURE__ */ b("header", {
		className: "bp-header",
		children: [
			/* @__PURE__ */ y(Ne, {}),
			/* @__PURE__ */ y("div", {
				className: "bp-turn",
				children: i(e.finalLeft === null ? "games.barenpark.turn" : "games.barenpark.finalRound", { n: e.turn })
			}),
			/* @__PURE__ */ y("nav", {
				className: "bp-players",
				children: e.players.map((n) => {
					let r = t.find((e) => e.rid === n.rid);
					return /* @__PURE__ */ y(We, {
						rid: n.rid,
						children: /* @__PURE__ */ b("button", {
							className: `bp-player${U.rid === n.rid ? " bp-inspecting" : ""}${e.active === n.rid ? " bp-active" : ""}`,
							style: { borderInlineStartColor: g[r?.colorIndex ?? 0]?.hex },
							"aria-pressed": U.rid === n.rid,
							onClick: () => {
								x(n.rid), C(null), k(null), N(1);
							},
							children: [
								/* @__PURE__ */ y("span", { children: Le(n.rid) }),
								/* @__PURE__ */ y("strong", {
									"aria-label": i("games.barenpark.score", { n: n.score.total }),
									children: n.score.total
								}),
								/* @__PURE__ */ y("small", { children: i("games.barenpark.boards", { n: n.boards.length }) })
							]
						})
					}, n.rid);
				})
			})
		]
	}), it = e.goals.map((e) => /* @__PURE__ */ b("button", {
		className: "bp-goal",
		"aria-expanded": I === e.id,
		onClick: () => R(I === e.id ? null : e.id),
		children: [
			/* @__PURE__ */ y("div", {
				className: "bp-goal-art",
				children: /* @__PURE__ */ y(q, { def: e.id === "polar" ? "house-polar-6" : e.id === "gobi" ? "house-gobi-7" : e.id === "koala" ? "enclosure-koala-8" : e.id === "panda" ? "house-panda-6" : ["food", "connections"].includes(e.id) ? "food-street" : ["river", "corners"].includes(e.id) ? "river" : [
					"enclosures",
					"freeze",
					"planning"
				].includes(e.id) ? "enclosure-koala-8" : e.id === "houses" ? "house-gobi-7" : e.id === "toilets" ? "toilet" : "playground" })
			}),
			/* @__PURE__ */ y("span", { children: i(Ae[e.id]) }),
			/* @__PURE__ */ y("b", { children: e.values.join(" / ") || "—" }),
			I === e.id && /* @__PURE__ */ y("small", { children: i(je[e.id]) })
		]
	}, e.id)), at = /* @__PURE__ */ b("div", {
		className: "bp-actions",
		children: [/* @__PURE__ */ y("span", {
			className: "bp-action-prompt",
			role: "status",
			children: nt
		}), /* @__PURE__ */ b("div", {
			className: "bp-action-buttons",
			children: [/* @__PURE__ */ y("button", {
				ref: Me,
				className: "bp-button bp-supply-toggle",
				onClick: () => {
					M(!Xe), !Xe && Ce && x(n);
				},
				children: i(Xe ? "games.barenpark.hideSupply" : "games.barenpark.showSupply")
			}), P ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("button", {
				className: "bp-button",
				onClick: () => oe(!1),
				children: i("games.barenpark.cancel")
			}), /* @__PURE__ */ y("button", {
				className: "bp-button bp-primary",
				disabled: !se || !le || !de,
				onClick: () => r({
					type: "exchange",
					green: se,
					house: le,
					grizzly: de
				}),
				children: i("games.barenpark.exchangeConfirm")
			})] }) : /* @__PURE__ */ b(v, { children: [
				et && /* @__PURE__ */ y("button", {
					className: "bp-button",
					onClick: () => {
						oe(!0), M(!0), C(null), k(null), x(n);
					},
					children: i("games.barenpark.exchange")
				}),
				W && e.phase === "place" && J && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("button", {
					className: "bp-button",
					onClick: () => {
						C(null), k(null);
					},
					children: i("games.barenpark.cancel")
				}), /* @__PURE__ */ y("button", {
					className: "bp-button bp-primary",
					disabled: !Q,
					onClick: () => {
						Q && r({
							type: "place",
							tile: Q.id,
							x: Q.x,
							y: Q.y,
							rotation: w,
							flipped: E
						});
					},
					children: i("games.barenpark.confirm")
				})] }),
				W && e.phase === "tower" && /* @__PURE__ */ y("button", {
					className: "bp-button",
					onClick: () => r({ type: "skipTower" }),
					children: i("games.barenpark.skip")
				}),
				W && e.phase === "end" && /* @__PURE__ */ y("button", {
					className: "bp-button bp-primary",
					onClick: () => r({ type: "finish" }),
					children: i("games.barenpark.finish")
				}),
				Je && !Qe.some(({ tile: e }) => O[e.def].kind === "green") && /* @__PURE__ */ y("button", {
					className: "bp-button",
					onClick: () => r({
						type: "pass",
						tile: ""
					}),
					children: i("games.barenpark.passEmpty")
				})
			] })]
		})]
	});
	return /* @__PURE__ */ y(_, {
		adaptive: !0,
		className: "bp-root",
		scroll: !1,
		banner: rt,
		actionsHeight: "bp-action-slot",
		actions: at,
		children: /* @__PURE__ */ b("div", {
			className: "bp-table",
			children: [/* @__PURE__ */ b("div", {
				className: `bp-park-column${e.goals.length ? " bp-has-goals" : ""}`,
				children: [
					/* @__PURE__ */ b("div", {
						className: "bp-park-caption",
						children: [/* @__PURE__ */ y("strong", { children: i("games.barenpark.yourPark", { name: Le(U.rid) }) }), /* @__PURE__ */ b("div", { children: [
							!!e.goals.length && /* @__PURE__ */ y("button", {
								className: "bp-button bp-goal-toggle",
								"aria-expanded": B,
								onClick: () => me(!B),
								children: i("games.barenpark.achievements")
							}),
							/* @__PURE__ */ y("button", {
								className: "bp-tool",
								"aria-label": i("games.barenpark.zoomOut"),
								onClick: Fe,
								children: /* @__PURE__ */ y(h, { size: 18 })
							}),
							/* @__PURE__ */ y("button", {
								className: "bp-tool",
								"aria-label": i("games.barenpark.zoomIn"),
								onClick: Pe,
								children: /* @__PURE__ */ y(m, { size: 18 })
							})
						] })]
					}),
					/* @__PURE__ */ b("div", {
						className: `bp-park-stage${J && W && e.phase === "place" && !P ? " bp-transforming" : ""}`,
						children: [
							/* @__PURE__ */ y("div", {
								className: `bp-goal-rail${B ? " bp-goals-open" : ""}`,
								children: it
							}),
							/* @__PURE__ */ y("div", {
								...Ie,
								className: "bp-park-scroll",
								children: /* @__PURE__ */ y("div", {
									className: "bp-park-canvas",
									style: {
										width: `${ae * 100}%`,
										height: `${ae * 100}%`
									},
									children: /* @__PURE__ */ y(ze, {
										player: U,
										targets: Z,
										ghost: Q,
										expansion: X ? he(U, U.boards.length === 4) : [],
										towers: $,
										onTarget: (e, t) => k([e, t]),
										onExpansion: (e, t) => r({
											type: "expand",
											source: U.boards.length === 4 ? Math.max(2, j) : Math.min(1, j),
											x: e,
											y: t
										}),
										onTower: (e) => r(e)
									})
								})
							}),
							J && W && e.phase === "place" && !P && /* @__PURE__ */ b("div", {
								className: "bp-map-tools",
								children: [/* @__PURE__ */ y("div", {
									className: "bp-transform-preview",
									children: /* @__PURE__ */ y(q, {
										def: J.def,
										rotation: w,
										flipped: E
									})
								}), /* @__PURE__ */ b("div", {
									className: "bp-transform",
									children: [/* @__PURE__ */ y("button", {
										className: "bp-tool",
										"aria-label": i("games.barenpark.rotate"),
										onClick: () => {
											T((w + 1) % 4), k(null);
										},
										children: /* @__PURE__ */ y(p, { size: 22 })
									}), /* @__PURE__ */ y("button", {
										className: "bp-tool",
										"aria-label": i("games.barenpark.flip"),
										onClick: () => {
											te(!E), k(null);
										},
										children: /* @__PURE__ */ y(f, { size: 22 })
									})]
								})]
							})
						]
					}),
					/* @__PURE__ */ b("div", {
						className: "bp-inventory",
						children: [/* @__PURE__ */ y("span", {
							className: "bp-section-title",
							children: i("games.barenpark.inventory")
						}), /* @__PURE__ */ y("div", {
							ref: we,
							className: "bp-inventory-scroll",
							children: U.supply.length ? U.supply.map((t) => /* @__PURE__ */ y("div", {
								className: "bp-inventory-item",
								children: /* @__PURE__ */ y(He, {
									tile: t,
									selected: P ? se === t.id || le === t.id : S === t.id,
									disabled: !W || (P ? !["green", "house"].includes(O[t.def].kind) : e.phase !== "place"),
									onClick: () => {
										P ? O[t.def].kind === "green" ? ce(t.id) : ue(t.id) : (C(t.id), k(null), T(0), te(!1));
									}
								})
							}, t.id)) : /* @__PURE__ */ y("span", {
								className: "bp-empty",
								children: i("games.barenpark.noTiles")
							})
						})]
					})
				]
			}), /* @__PURE__ */ b("aside", {
				ref: Oe,
				className: `bp-supply${Xe ? " bp-open" : ""}`,
				"aria-label": i("games.barenpark.supply"),
				children: [
					/* @__PURE__ */ b("div", {
						className: "bp-section-title",
						children: [i("games.barenpark.supply"), /* @__PURE__ */ y("button", {
							className: "bp-close-drawer bp-tool",
							onClick: () => M(!1),
							"aria-label": i("games.barenpark.hideSupply"),
							children: "×"
						})]
					}),
					Ce && e.phase === "rewards" && /* @__PURE__ */ y("div", {
						className: "bp-rewards",
						children: [...new Set(e.pending)].map((t) => /* @__PURE__ */ b("button", {
							className: `bp-symbol${Y === t ? " bp-selected" : ""}`,
							onClick: () => {
								ne(t), x(n);
							},
							"aria-label": i(ke[t]),
							"aria-pressed": Y === t,
							children: [/* @__PURE__ */ y("img", {
								src: K(`icon-${t}.svg`),
								alt: ""
							}), /* @__PURE__ */ b("b", { children: ["×", [...e.pending].filter((e) => e === t).length] })]
						}, t))
					}),
					X && /* @__PURE__ */ y("p", {
						className: "bp-small-prompt",
						children: i("games.barenpark.chooseBoard")
					}),
					P ? /* @__PURE__ */ y("div", {
						className: "bp-tile-grid",
						children: e.supply.filter((e) => O[e.def].kind === "grizzly").map((e) => /* @__PURE__ */ y(He, {
							tile: e,
							selected: de === e.id,
							onClick: () => fe(e.id)
						}, e.id))
					}) : /* @__PURE__ */ y(v, { children: [
						"green",
						"house",
						"enclosure"
					].map((e) => /* @__PURE__ */ b(Ge, {
						kind: e,
						children: [/* @__PURE__ */ b("h3", { children: [/* @__PURE__ */ y("img", {
							src: K(`icon-${e === "green" ? "w" : e === "house" ? "c" : "e"}.svg`),
							alt: ""
						}), i(Ee[e])] }), /* @__PURE__ */ y("div", {
							className: `bp-tile-grid${e === "enclosure" ? " bp-enclosure-grid" : ""}`,
							children: (e === "enclosure" ? [
								"koala",
								"polar",
								"panda",
								"gobi"
							] : [""]).map((t) => {
								let a = Qe.filter(({ tile: n }) => O[n.def].kind === e && (!t || O[n.def].species === t)).map(({ tile: t, count: i }) => /* @__PURE__ */ y(He, {
									tile: t,
									count: i,
									labelled: e !== "enclosure",
									disabled: !$e.has(t.def),
									onClick: () => {
										x(n), r(Je ? {
											type: "pass",
											tile: t.id
										} : {
											type: "take",
											icon: Y,
											tile: t.id
										});
									}
								}, t.id));
								return t ? /* @__PURE__ */ b("div", {
									className: "bp-species-stack",
									children: [/* @__PURE__ */ y("span", { children: i(De[t]) }), a]
								}, t) : a;
							})
						})]
					}, e)) }),
					!P && /* @__PURE__ */ b("section", {
						className: "bp-supply-section bp-board-source-zone",
						children: [/* @__PURE__ */ y("h3", { children: i("games.barenpark.parkSupply") }), /* @__PURE__ */ y("div", {
							className: "bp-board-sources",
							children: (e.players.find((t) => t.rid === e.active)?.boards.length === 4 && e.config.grizzlies ? e.exits.map((e, t) => ({
								id: e,
								source: t + 2,
								count: 1
							})) : e.stacks.flatMap((e, t) => e.top ? [{
								id: e.top,
								source: t,
								count: e.count
							}] : [])).map((e) => /* @__PURE__ */ y(qe, {
								id: e.id,
								source: e.source,
								count: e.count,
								selected: X && (j === e.source || U.boards.length === 4 && j < 2 && e.source === 2),
								disabled: !X,
								onClick: () => {
									re(e.source), M(!1);
								}
							}, e.id))
						})]
					}),
					/* @__PURE__ */ b("div", {
						className: "bp-statues",
						children: [
							/* @__PURE__ */ y("span", { children: i("games.barenpark.statueSupply") }),
							e.statues.slice(0, 8).map((e, t) => /* @__PURE__ */ y(Ke, {
								value: e,
								first: t === 0
							}, e)),
							/* @__PURE__ */ y("small", { children: i("games.barenpark.remaining", { n: e.statues.length }) })
						]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/games/barenpark/bot.ts
var Ye = {
	area: 1.7,
	symbol: 2.5,
	finish: 18,
	snug: .18,
	holes: 4,
	value: .8,
	fit: 5
};
function X(e, t, n) {
	return V(e, t, n).length > 0;
}
function Xe(e = {}) {
	let t = {
		...Ye,
		...e
	};
	return (e, n) => {
		let r = e.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i || r.active !== n.rid || ![
			"place",
			"tower",
			"rewards",
			"end"
		].includes(r.phase)) return null;
		let a = n.difficulty === "weak", o = r.config.pitVariant && r.finalLeft !== null, s = S(x(n.rid));
		if (r.phase === "end") return { action: { type: "finish" } };
		if (r.phase === "tower") return { action: [..._e(i, r.last, r.towerCount, r.carValues)].sort((e, t) => {
			let n = (e) => j.filter(([t, n]) => z(i).has(F(e.x + t * 3, e.y + n * 3))).length;
			return n(t) - n(e);
		})[0] ?? { type: "skipTower" } };
		if (r.phase === "rewards") {
			if (r.pending.includes("b")) {
				let e = i.boards.length === 4, t = e ? r.exits.map((e, t) => ({
					top: e,
					source: t + 2
				})) : r.stacks.flatMap((e, t) => e.top ? [{
					top: e.top,
					source: t
				}] : []), n = null;
				for (let r of t) for (let [t, a] of he(i, e)) {
					let e = i.boards.filter((e) => Math.abs(t - e.x) + Math.abs(a - e.y) === 1).length * 3 - Math.abs(t) * .15 + [...k[r.top]].filter((e) => e === "e").length;
					(!n || e > n.value) && (n = {
						action: {
							type: "expand",
							source: r.source,
							x: t,
							y: a
						},
						value: e
					});
				}
				if (n) return { action: n.action };
			}
			let e = [...r.pending].filter((e) => e !== "b").sort()[0], n = ge(r, e).filter((e, t, n) => n.findIndex((t) => t.def === e.def) === t), s = null, c = -Infinity;
			for (let e of n) {
				let n = O[e.def], r = X(i, e, o), l = i.supply.filter((e) => e.def === "toilet").length, u = a ? n.cells.length + e.value * .1 : n.cells.length * .9 + e.value * t.value + (r ? t.fit : -t.fit * 2) + +(n.kind === "enclosure") + (e.def === "toilet" && l < 2 ? 4 : 0) - i.supply.filter((t) => t.def === e.def).length * 1.2;
				u > c && (s = e, c = u);
			}
			return s ? { action: {
				type: "take",
				icon: e,
				tile: s.id
			} } : null;
		}
		if (r.config.grizzlies && !r.exchanged) {
			let e = i.supply.filter((e) => O[e.def].kind === "green").sort((e, t) => O[e.def].cells.length - O[t.def].cells.length)[0], t = i.supply.filter((e) => O[e.def].kind === "house").sort((e, t) => e.value - t.value)[0], n = r.supply.filter((e) => O[e.def].kind === "grizzly" && X(i, e, o)).sort((e, t) => t.value - e.value)[0];
			if (e && t && n && (i.supply.length > 4 || !X(i, t, o)) && t.value < n.value - 2) return { action: {
				type: "exchange",
				green: e.id,
				house: t.id,
				grizzly: n.id
			} };
		}
		let c = z(i), l = B(i), u = null;
		for (let e of i.supply) for (let n of V(i, e, o)) {
			let o = R({
				...e,
				x: n.x,
				y: n.y,
				rotation: n.rotation,
				flipped: n.flipped
			}), d = new Set(o.map(([e, t]) => F(e, t))), f = O[e.def].cells.length * t.area + e.value * t.value * (.8 + s.greed * .4);
			if (a) f = o.length + e.value * .15;
			else {
				for (let [e, n] of o) {
					let a = c.get(F(e, n));
					a && "wce".includes(a) && (f += t.symbol * (a === "e" ? 1.5 : a === "c" ? 1.2 : 1)), a === "b" && i.boards.length < (r.config.grizzlies ? 5 : 4) && (f += t.symbol * (i.boards.length < 2 ? 3 : 1.5));
					for (let [r, i] of j) (!c.has(F(e + r, n + i)) || l.has(F(e + r, n + i))) && (f += t.snug);
				}
				for (let e of i.boards) if (!ve(i, e)) {
					let n = [...k[e.id]].flatMap((t, n) => t !== "p" && !l.has(F(e.x * 4 + n % 4, e.y * 4 + Math.floor(n / 4))) ? [F(e.x * 4 + n % 4, e.y * 4 + Math.floor(n / 4))] : []);
					n.every((e) => d.has(e)) ? f += t.finish + (r.statues[0] ?? 0) * .3 : f += n.filter((e) => d.has(e)).length / n.length * 2;
				}
				let e = new Set(o.flatMap(([e, t]) => j.map(([n, r]) => F(e + n, t + r))));
				for (let n of e) if (c.get(n) !== "p" && c.has(n) && !l.has(n) && !d.has(n)) {
					let [e, r] = n.split(",").map(Number);
					j.every(([t, n]) => !c.has(F(e + t, r + n)) || c.get(F(e + t, r + n)) === "p" || l.has(F(e + t, r + n)) || d.has(F(e + t, r + n))) && (f -= t.holes);
				}
			}
			(!u || f > u.value) && (u = {
				action: n,
				value: f
			});
		}
		return u ? { action: u.action } : { action: {
			type: "pass",
			tile: r.supply.filter((e) => O[e.def].kind === "green").sort((e, t) => Number(X(i, t, o)) - Number(X(i, e, o)) || O[e.def].cells.length - O[t.def].cells.length)[0]?.id ?? ""
		} };
	};
}
var Ze = Xe(), Qe = (e, t, n) => {
	if (e.type === "place") {
		let r = t.public.players.flatMap((e) => e.supply).find((t) => t.id === e.tile);
		return n("games.barenpark.hintPlace", { tile: r ? n(G(r.def)) : "" });
	}
	if (e.type === "take") {
		let r = t.public.supply.find((t) => t.id === e.tile);
		return n("games.barenpark.hintTake", { tile: r ? n(G(r.def)) : "" });
	}
	return e.type === "expand" ? n("games.barenpark.hintExpand") : e.type === "tower" ? n("games.barenpark.hintTower") : e.type === "exchange" ? n("games.barenpark.hintExchange") : e.type === "pass" ? n("games.barenpark.hintPass") : e.type === "skipTower" ? n("games.barenpark.hintSkip") : n("games.barenpark.hintFinish");
};
//#endregion
//#region src/games/barenpark/fx.tsx
function $e(e, t = 0, n = !1) {
	let r = L(e, t, n);
	return {
		w: Math.max(...r.map(([e]) => e)) + 1,
		h: Math.max(...r.map(([, e]) => e)) + 1
	};
}
function Z(e, t, n) {
	let r = Math.min(e.w / t, e.h / n);
	return {
		x: e.x + (e.w - t * r) / 2,
		y: e.y + (e.h - n * r) / 2,
		w: t * r,
		h: n * r
	};
}
function Q(e, t, n) {
	let r = Math.min(110, e.w), i = Math.min(80, e.h);
	return Z({
		x: e.x + (e.w - r) / 2,
		y: e.y + (e.h - i) / 2,
		w: r,
		h: i
	}, t, n);
}
function $(e, ...t) {
	for (let n of t) {
		let t = e.anchor(n);
		if (t && t.w > 0 && t.h > 0) return t;
	}
	return null;
}
function et(e, ...t) {
	return $(e, ...t, "supply", "supply-toggle");
}
function tt(e, t, n) {
	let r = $(e, `tile:${t}`), i = $(e, `hand:${n}`);
	return r && i && r.x >= i.x && r.x + r.w <= i.x + i.w && r.y >= i.y && r.y + r.h <= i.y + i.h ? r : $(e, `seat:${n}`);
}
var nt = {
	place(e, t) {
		let n = e.data, r = $(t, `placed:${n.tile}`), i = e.rid ? $(t, `hand:${e.rid}`, `seat:${e.rid}`) : null;
		if (!r) return null;
		if (!i || t.queued > 0) return {
			ms: 420,
			node: /* @__PURE__ */ y(T, {
				at: r,
				ms: 420
			})
		};
		let a = $e(n.def, n.rotation, n.flipped), o = Q(i, a.w, a.h), s = Z(r, a.w, a.h);
		return {
			ms: 420,
			hide: [`placed:${n.tile}`],
			node: /* @__PURE__ */ y(w, {
				from: o,
				to: s,
				ms: 420,
				children: /* @__PURE__ */ y("div", {
					style: {
						width: o.w,
						height: o.h
					},
					children: /* @__PURE__ */ y(q, {
						def: n.def,
						rotation: n.rotation,
						flipped: n.flipped
					})
				})
			})
		};
	},
	take(e, t) {
		let n = e.data, r = tt(t, n.tile, e.rid), i = et(t, `market:${O[n.def].kind}`);
		if (!r || !i) return null;
		if (t.queued) return {
			ms: 420,
			node: /* @__PURE__ */ y(T, {
				at: r,
				ms: 420
			})
		};
		let a = $e(n.def), o = Q(i, a.w, a.h), s = Z(r, a.w, a.h);
		return {
			ms: 420,
			hide: [`tile:${n.tile}`],
			node: /* @__PURE__ */ y(w, {
				from: o,
				to: s,
				ms: 420,
				children: /* @__PURE__ */ y("div", {
					style: {
						width: o.w,
						height: o.h
					},
					children: /* @__PURE__ */ y(q, { def: n.def })
				})
			})
		};
	},
	exchange(e, t) {
		let n = e.data, r = tt(t, n.tile, e.rid), i = et(t, "market:grizzly"), a = $(t, `hand:${e.rid}`, `seat:${e.rid}`);
		if (!r || !i || !a) return null;
		if (t.queued) return {
			ms: 420,
			node: /* @__PURE__ */ y(T, {
				at: r,
				ms: 420
			})
		};
		let o = $e(n.def), s = Q(i, o.w, o.h), c = Z(r, o.w, o.h);
		return {
			ms: 420,
			hide: [`tile:${n.tile}`],
			node: /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y(w, {
				from: s,
				to: c,
				ms: 420,
				children: /* @__PURE__ */ y("div", {
					style: {
						width: s.w,
						height: s.h
					},
					children: /* @__PURE__ */ y(q, { def: n.def })
				})
			}), n.given.map((e, t) => {
				let n = $e(e), r = Q({
					...a,
					x: a.x + a.w * t / 2,
					w: a.w / 2
				}, n.w, n.h), o = Q(i, n.w, n.h);
				return /* @__PURE__ */ y(w, {
					from: r,
					to: o,
					ms: 420,
					children: /* @__PURE__ */ y("div", {
						style: {
							width: r.w,
							height: r.h
						},
						children: /* @__PURE__ */ y(q, { def: e })
					})
				}, e);
			})] })
		};
	},
	expand(e, t) {
		let n = e.data, r = `area:${e.rid}:${n.board}`, i = $(t, r), a = et(t, `deck:${n.source}`);
		if (!i || !a) return null;
		if (t.queued) return {
			ms: 420,
			node: /* @__PURE__ */ y(T, {
				at: i,
				ms: 420
			})
		};
		let o = Q(a, 1, 1), s = Z(i, 1, 1);
		return {
			ms: 420,
			hide: [r],
			node: /* @__PURE__ */ y(w, {
				from: o,
				to: s,
				ms: 420,
				children: /* @__PURE__ */ y("div", {
					style: {
						width: o.w,
						height: o.h
					},
					children: /* @__PURE__ */ y(Be, {
						id: n.board,
						full: !0
					})
				})
			})
		};
	},
	statue(e, t) {
		let n = e.data, r = `statue:${e.rid}:${n.board}`, i = $(t, r), a = et(t, "statue-source");
		if (!i || !a) return null;
		if (t.queued) return {
			ms: 420,
			node: /* @__PURE__ */ y(T, {
				at: i,
				ms: 420
			})
		};
		let o = Q(a, 1, 1), s = Z(i, 1, 1);
		return {
			ms: 420,
			hide: [r],
			node: /* @__PURE__ */ y(w, {
				from: o,
				to: s,
				ms: 420,
				children: /* @__PURE__ */ y("img", {
					src: K(`statue-${n.value}.svg`),
					alt: "",
					style: {
						width: o.w,
						height: o.h
					}
				})
			})
		};
	},
	achievement(e, t) {
		let n = e.data, r = $(t, `seat:${e.rid}`);
		return r ? {
			ms: 420,
			node: /* @__PURE__ */ y(C, {
				at: {
					...r,
					y: r.y + r.h
				},
				ms: 420,
				children: /* @__PURE__ */ b("span", { children: ["🏅 +", n.value] })
			})
		} : null;
	},
	tower(e, t) {
		let n = e.data, r = $(t, `tower:${e.rid}:${n.tower}`), i = $(t, `tower:${e.rid}:${n.connect}`);
		if (!r) return null;
		if (!i || n.car < 0 || t.queued) return {
			ms: 420,
			node: /* @__PURE__ */ y(T, {
				at: r,
				ms: 420
			})
		};
		let a = i.x + i.w / 2, o = i.y + i.h / 2, s = r.x + r.w / 2, c = r.y + r.h / 2, l = Math.hypot(a - s, o - c), u = Math.atan2(c - o, s - a) * 180 / Math.PI, d = (a + s) / 2, f = (o + c) / 2;
		return {
			ms: 420,
			hide: [`car:${e.rid}:${n.car}`],
			node: /* @__PURE__ */ b("svg", {
				className: "absolute inset-0",
				width: "100%",
				height: "100%",
				children: [/* @__PURE__ */ y("path", {
					d: `M${a} ${o}L${s} ${c}`,
					stroke: "#615853",
					strokeWidth: Math.max(5, l / 12),
					strokeLinecap: "round",
					strokeDasharray: l,
					strokeDashoffset: l,
					children: /* @__PURE__ */ y("animate", {
						attributeName: "stroke-dashoffset",
						from: l,
						to: 0,
						dur: `${420 / 1e3}s`,
						fill: "freeze"
					})
				}), /* @__PURE__ */ y("image", {
					href: K(`car-${n.value}.svg`),
					x: d - l * .44,
					y: f - l * .077,
					width: l * .88,
					height: l * .154,
					transform: `rotate(${u} ${d} ${f})`,
					opacity: 0,
					children: /* @__PURE__ */ y("animate", {
						attributeName: "opacity",
						values: "0;0;1",
						keyTimes: "0;.35;1",
						dur: `${420 / 1e3}s`,
						fill: "freeze"
					})
				})]
			})
		};
	}
};
//#endregion
//#region src/games/barenpark/game-over.tsx
function rt({ result: e, public: t, members: n, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o }) {
	let c = t, f = u(), p = l((e) => e.locale), [g, _] = s(!0), [v, x] = s(r), [S, C] = s(1), { zoomIn: w, zoomOut: T, ...te } = Ve(S, C), D = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ee(t, p) : e;
	}, O = e.ranking.map((e) => c.players.find((t) => t.rid === e)), k = [
		["houses", "games.barenpark.housesScore"],
		["enclosures", "games.barenpark.enclosuresScore"],
		...c.config.grizzlies ? [["grizzlies", "games.barenpark.grizzliesScore"]] : [],
		["statues", "games.barenpark.statuesScore"],
		...c.config.achievements ? [["achievements", "games.barenpark.achievementsScore"]] : [],
		...c.config.monorails ? [["cars", "games.barenpark.carsScore"]] : [],
		["reserve", "games.barenpark.reserve"]
	], A = c.players.find((e) => e.rid === v) ?? O[0];
	return /* @__PURE__ */ b("div", {
		className: "bp-over",
		children: [
			/* @__PURE__ */ b("header", {
				className: "bp-over-title",
				children: [/* @__PURE__ */ y(Ne, {}), /* @__PURE__ */ y("span", { children: f("games.barenpark.results") })]
			}),
			/* @__PURE__ */ b("div", {
				className: "bp-over-stage",
				children: [/* @__PURE__ */ b("div", {
					className: "bp-over-review",
					inert: g,
					"aria-hidden": g,
					style: { visibility: g ? "hidden" : void 0 },
					children: [
						/* @__PURE__ */ y("nav", {
							className: "bp-over-tabs",
							children: O.map((e) => /* @__PURE__ */ y("button", {
								className: `bp-button${v === e.rid ? " bp-primary" : ""}`,
								onClick: () => x(e.rid),
								children: D(e.rid)
							}, e.rid))
						}),
						/* @__PURE__ */ b("div", {
							className: "bp-park-caption",
							children: [/* @__PURE__ */ y("strong", { children: f("games.barenpark.yourPark", { name: D(A.rid) }) }), /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("button", {
								className: "bp-tool",
								"aria-label": f("games.barenpark.zoomOut"),
								onClick: T,
								children: /* @__PURE__ */ y(h, { size: 18 })
							}), /* @__PURE__ */ y("button", {
								className: "bp-tool",
								"aria-label": f("games.barenpark.zoomIn"),
								onClick: w,
								children: /* @__PURE__ */ y(m, { size: 18 })
							})] })]
						}),
						/* @__PURE__ */ y("div", {
							...te,
							className: "bp-over-park",
							children: /* @__PURE__ */ y("div", {
								className: "bp-park-canvas",
								style: {
									width: `${S * 100}%`,
									height: `${S * 100}%`
								},
								children: /* @__PURE__ */ y(ze, { player: A })
							})
						})
					]
				}), /* @__PURE__ */ b("div", {
					className: "bp-ending-layout",
					inert: !g,
					"aria-hidden": !g,
					style: { visibility: g ? void 0 : "hidden" },
					children: [/* @__PURE__ */ b("aside", {
						className: "bp-final-park",
						children: [
							/* @__PURE__ */ y("strong", { children: f("games.barenpark.yourPark", { name: D(A.rid) }) }),
							/* @__PURE__ */ y("div", { children: /* @__PURE__ */ y(ze, { player: A }) }),
							/* @__PURE__ */ y("button", {
								className: "bp-button",
								onClick: () => _(!1),
								children: f("games.barenpark.viewPark")
							})
						]
					}), /* @__PURE__ */ b("section", {
						className: "bp-results",
						children: [
							/* @__PURE__ */ b("header", {
								className: "bp-result-hero",
								children: [
									/* @__PURE__ */ y("img", {
										src: K("statue-16.svg"),
										alt: ""
									}),
									/* @__PURE__ */ y("h1", { children: f(e.winner.length === 1 ? "games.barenpark.winner" : "games.barenpark.tied", { name: e.winner.map(D).join("、") }) }),
									/* @__PURE__ */ y("button", {
										className: "bp-tool",
										"aria-label": f("games.barenpark.hideResults"),
										onClick: () => _(!1),
										children: /* @__PURE__ */ y(d, { size: 20 })
									})
								]
							}),
							/* @__PURE__ */ b("table", { children: [/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
								scope: "col",
								children: f("games.barenpark.total")
							}), O.map((t, n) => /* @__PURE__ */ y("th", {
								scope: "col",
								children: /* @__PURE__ */ b("div", {
									className: `bp-rank${e.winner.includes(t.rid) ? " bp-winner" : ""}`,
									children: [
										/* @__PURE__ */ y("span", { children: D(t.rid) }),
										/* @__PURE__ */ y("strong", { children: t.score.total }),
										/* @__PURE__ */ y("small", { children: e.winner.includes(t.rid) ? 1 : n + 1 }),
										e.autopilot?.[t.rid] !== void 0 && /* @__PURE__ */ y("small", { children: f("games.barenpark.autopilot", { n: Math.round(e.autopilot[t.rid] * 100) }) })
									]
								})
							}, t.rid))] }) }), /* @__PURE__ */ y("tbody", { children: k.map(([e, t]) => /* @__PURE__ */ b("tr", {
								className: e === "reserve" ? "bp-reserve-row" : void 0,
								children: [/* @__PURE__ */ y("th", {
									scope: "row",
									children: f(t)
								}), O.map((t) => /* @__PURE__ */ y("td", { children: t.score[e] }, t.rid))]
							}, e)) })] }),
							/* @__PURE__ */ y("p", {
								className: "bp-reserve-note",
								children: f("games.barenpark.reserveNote")
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ b("footer", {
				className: "bp-over-controls",
				children: [
					!g && /* @__PURE__ */ y("button", {
						className: "bp-button",
						onClick: () => _(!0),
						children: f("games.barenpark.showResults")
					}),
					a && /* @__PURE__ */ y(E, {
						className: "bp-button bp-primary",
						label: f("games.barenpark.again"),
						confirmLabel: f("games.barenpark.confirmAgain"),
						onConfirm: a
					}),
					o && /* @__PURE__ */ y(E, {
						className: "bp-button",
						label: f("games.barenpark.lobby"),
						confirmLabel: f("games.barenpark.confirmLobby"),
						onConfirm: o
					}),
					!a && !o && /* @__PURE__ */ y("span", { children: f("games.barenpark.waitHost") }),
					a && i !== void 0 && i > 0 && /* @__PURE__ */ y("small", { children: f("games.barenpark.hints", { n: i }) })
				]
			})
		]
	});
}
//#endregion
//#region src/games/barenpark/options.tsx
function it({ value: e, onChange: t }) {
	let n = u(), r = ie.parse(e ?? void 0), i = [
		[
			"achievements",
			"games.barenpark.achievements",
			"games.barenpark.achievementsHint"
		],
		[
			"newAchievements",
			"games.barenpark.newAchievements",
			"games.barenpark.newAchievementsHint"
		],
		[
			"grizzlies",
			"games.barenpark.grizzlies",
			"games.barenpark.grizzliesHint"
		],
		[
			"monorails",
			"games.barenpark.monorails",
			"games.barenpark.monorailsHint"
		],
		[
			"pitVariant",
			"games.barenpark.pitVariant",
			"games.barenpark.pitVariantHint"
		]
	], a = (e) => t({
		...r,
		[e]: !r[e],
		...e === "newAchievements" && !r.newAchievements ? { achievements: !0 } : {}
	});
	return /* @__PURE__ */ y(te, {
		title: n("games.barenpark.options"),
		children: i.map(([e, t, i]) => /* @__PURE__ */ y(D, {
			checked: r[e],
			label: n(t),
			hint: n(i),
			accent: re.accent,
			onChange: () => a(e)
		}, e))
	});
}
//#endregion
//#region src/games/barenpark/guide.tsx
function at() {
	let e = u();
	return /* @__PURE__ */ y("div", {
		className: "grid grid-cols-2 gap-3",
		children: Object.entries(ke).map(([t, n]) => /* @__PURE__ */ b("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ y("img", {
				src: K(`icon-${t}.svg`),
				alt: "",
				className: "size-12"
			}), /* @__PURE__ */ y("strong", {
				className: "text-sm",
				children: e(n)
			})]
		}, t))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/barenpark/entry.tsx
var ot = {
	definition: Te,
	View: Je,
	bot: Ze,
	describe: Qe,
	fx: nt,
	OverView: rt,
	Options: it,
	Guide: at,
	locales: {
		zh: {
			name: "熊熊公園",
			desc: "拼接熊类栖地与绿地，争夺雕像，建设得分最高的熊公园。",
			rules: "目标：建设得分最高的熊公园。每人从一张入口园区与一块绿地开始。每张园区有4行4列格子，并留有一个深坑。\n回合流程：\n· 从个人库存放置一块拼板。可旋转、翻转或跨越园区边界，不能出界、重叠或覆盖深坑。除第一块外，新拼板必须与已放置拼板正交相邻。\n以任意顺序结算刚覆盖的图标，每个图标领取一次对应奖励：\n· 独轮车：领取任意一块绿地。\n· 搅拌车：领取任意一叠顶端的动物馆，或一块绿地。\n· 挖掘机：领取任意一块围场、任意一叠顶端的动物馆，或一块绿地。\n· 施工队：拿取两叠园区中任意一叠的顶牌，立即扩建。\n· 每张刚铺满的园区（深坑除外）获得供应中分值最高的熊雕像，放在深坑内。同时完成多张园区时，每张各得一个。\n· 若启用成就，领取所有本回合达成的成就的最高分牌。每人每种最多一张。最后结束回合。\n扩建与供应：\n新园区必须整边贴合已有园区、图标保持朝向，不能低于入口所在的一排。基础游戏最多4张园区。达到上限时施工队不再提供奖励。园区堆只公开顶牌。动物馆各类最高值在顶；围场全部可选。\n开局绿地按照行动顺序发放：\n· 2人时为厕所、游乐场。\n· 3人时为厕所、游乐场、餐饮街。\n· 4人时为厕所、游乐场、游乐场、餐饮街。\n绿地供应包括10块厕所、10块游乐场，以及按每位玩家各4块准备的河流和餐饮街。\n动物馆和雕像的供应分值根据人数调整：\n· 两人对局：动物馆的分值为2、4、6分；雕像使用2至16分的偶数分值。\n· 三人对局：动物馆的分值为2至6分；雕像的分值为3至14分。\n· 四人对局：动物馆的分值为1至7分；雕像的分值为1至16分。\n每种熊各有3块不同形状的五格围场，分值分别为6、7、8分。\n无法放置：\n只有个人库存没有任何可合法放置的拼板时，才必须跳过放置，并免费领取一块绿地。新领绿地只能下回合放置。库存数量没有上限。\n终局与计分：\n首位完成4张园区的玩家触发终局，其他人各进行最后一个回合。只计算公园内动物馆、围场、雕像和成就的分值。平分时比较库存拼板分值，仍平分则共同获胜。\n成就（可选，默认关闭）：\n随机选择3种成就，每叠最高分先领取；下列每组分值均按领取顺序由高到低列出。2人移除各叠最低分牌。\n· 北极熊、戈壁熊、考拉、熊猫：放置该类熊的3块拼板时，达成该目标；奖励分值依次为8、5、2分。\n· 动物馆：放置四种形状的动物馆各一块时，达成该目标；奖励分值依次为8、5、2分。\n· 绿地：将6块绿地正交连接成一片时，达成该目标；奖励分值依次为9、6、3分。\n· 围场：将3块围场正交连接成一片时，达成该目标；奖励分值依次为9、6、3分。\n· 长餐饮街：将3块餐饮街沿同一直线首尾相接时，达成该目标；奖励分值依次为9、6、3分。\n· 长河流：将3块河流的水道端点连续接通时，达成该目标；奖励分值依次为10、7、4分。\n· 双喜临门：在同一回合获得至少2个雕像时，达成该目标；奖励分值依次为10、7、4分。\n灰熊模块（默认关闭）：\n公园扩大为5张园区。获取第5张时，从可见出口园区中选择，不能改拿普通园区，出口不能直接位于任何园区的下面。每回合开始或结束时，可进行一次交换：从库存永久移出一块绿地和一块动物馆，换取一块七格灰熊栖地。回合开始换来的灰熊可立即放置。灰熊共12块，分值7至10，每值3种不同形状。动物馆增加一层：2人增加8分；3人增加7分；4人增加8分。雕像的分值供应根据人数调整：\n· 2人时，使用2至20分的偶数分值雕像。\n· 3人时，雕像分值延伸至17分。\n· 4人时，使用1至20分的雕像。\n首位完成5张园区触发终局；无人能再推进时提前结束。\n单轨模块（默认关闭）：\n每放置一块绿地，可以立即在这块绿地的一格上放一座塔；放弃后不能补放。第一座塔的位置可以自由选择；此后的塔必须连接现有线路的端点，两塔同一行或列、坐标相距3格，中间正好2格。中间可跨空地或深坑。新塔必须立即连接供应中分值最高的列车；每名玩家各有10、8、6、5、4、3分的列车各一辆。每塔最多连接两车，且必须转90度；只能一条线路，不能闭环，每回合最多一塔一车。塔不计分，列车计分。两模块可组合，按灰熊模块终局。\n新成就（可选，默认关闭）：\n与基础成就混合随机选3种，不要求启用灰熊或单轨。\n· 停工：放置围场且未覆盖任何图标时，达成该目标；奖励分值依次为8、5、2分。\n· 围场规划：在同一回合实际领取至少2块围场时，达成该目标；奖励分值依次为8、5、2分。\n· 遥远厕所：两块厕所之间的最短正交路径包含至少11个中间格时，达成该目标；奖励分值依次为8、5、2分。\n· 餐饮街连接：餐饮街跨越至少3对不同相邻园区的公共边时，达成该目标；奖励分值依次为9、6、3分。\n· 角落河流：至少3张园区各有一块河流同时覆盖角格及其相邻两格时，达成该目标；奖励分值依次为9、6、3分。\n· 雕像游乐场：至少3个雕像分别与游乐场正交相邻时，达成该目标；奖励分值依次为9、6、3分。\n启用任一扩展内容时，额外加入6块厕所，合计16块。\n深坑变体（可选，默认关闭）：\n终局触发后，其他玩家在自己的最后回合可以覆盖未放雕像的深坑；该园区完成后不再获得雕像。",
			options: "游戏选项",
			achievements: "成就",
			achievementsHint: "随机选择三种竞速成就。",
			newAchievements: "新成就",
			newAchievementsHint: "加入 Bad News Bears 的六种成就及额外厕所。",
			grizzlies: "灰熊",
			grizzliesHint: "七格栖地、库存交换与第五张出口园区。",
			monorails: "单轨",
			monorailsHint: "在绿地上建塔，以转弯线路连接列车。",
			pitVariant: "深坑变体",
			pitVariantHint: "最后回合可以覆盖深坑，但放弃该园区雕像。",
			placing: "放置{{tile}}",
			viewPark: "查看最终公园",
			reserveNote: "库存分值仅用于平分判定",
			placePrompt: "选择库存拼板，再选择公园中的位置",
			rewardsPrompt: "选择一个已覆盖图标，再领取奖励",
			towerPrompt: "在刚放置的绿地上建塔，或跳过",
			settling: "园区结算中",
			endPrompt: "本回合完成",
			waiting: "等待{{name}}行动",
			finalRound: "最后一轮",
			turn: "第 {{n}} 回合",
			supply: "公共供应",
			inventory: "个人库存",
			yourPark: "{{name}}的公园",
			score: "{{n}} 分",
			boards: "{{n}} 张园区",
			statueSupply: "雕像",
			parkSupply: "园区",
			stack: "第 {{n}} 叠 · 剩余 {{count}} 张",
			exit: "出口园区",
			entrance: "熊公园",
			chooseBoard: "选择新园区，再选择扩建位置",
			green: "绿地",
			house: "动物馆",
			enclosure: "围场",
			grizzly: "灰熊栖地",
			toilet: "厕所",
			playground: "游乐场",
			food: "餐饮街",
			river: "河流",
			polar: "北极熊",
			gobi: "戈壁熊",
			koala: "考拉",
			panda: "熊猫",
			wheelbarrow: "独轮车",
			cement: "搅拌车",
			excavator: "挖掘机",
			crew: "施工队",
			pit: "深坑",
			confirm: "确认放置",
			cancel: "取消",
			rotate: "旋转拼板",
			flip: "翻转拼板",
			finish: "结束回合",
			skip: "跳过建塔",
			pass: "无法放置，选择免费绿地",
			passEmpty: "跳过放置",
			exchange: "交换灰熊",
			exchangePrompt: "从库存选择一块绿地、一块动物馆，再选择灰熊",
			exchangeConfirm: "确认交换",
			noTiles: "没有待建拼板",
			showSupply: "查看供应",
			hideSupply: "收起供应",
			zoomIn: "放大公园",
			zoomOut: "缩小公园",
			placeAt: "放置在第 {{x}} 列、第 {{y}} 行",
			expandAt: "在这里扩建园区",
			towerAt: "在这里建塔",
			connectTower: "连接第 {{n}} 座塔",
			remaining: "剩余 {{n}}",
			goalPolar: "北极熊",
			goalGobi: "戈壁熊",
			goalKoala: "考拉",
			goalPanda: "熊猫",
			goalGreen: "绿地相连",
			goalFood: "长餐饮街",
			goalRiver: "长河流",
			goalEnclosures: "围场相连",
			goalHouses: "动物馆",
			goalTwice: "双喜临门",
			goalFreeze: "停工",
			goalPlanning: "围场规划",
			goalToilets: "遥远厕所",
			goalConnections: "餐饮街连接",
			goalCorners: "角落河流",
			goalPlaygrounds: "雕像游乐场",
			rulePolar: "公园内有3块北极熊拼板。",
			ruleGobi: "公园内有3块戈壁熊拼板。",
			ruleKoala: "公园内有3块考拉拼板。",
			rulePanda: "公园内有3块熊猫拼板。",
			ruleGreen: "6块绿地正交连成一片。",
			ruleFood: "3块餐饮街沿同一直线首尾相接。",
			ruleRiver: "3块河流的水道端点连续接通。",
			ruleEnclosures: "3块围场正交连成一片。",
			ruleHouses: "四种动物馆各至少1块。",
			ruleTwice: "同回合获得至少2个雕像。",
			ruleFreeze: "本回合放置围场未覆盖任何图标。",
			rulePlanning: "同回合实际领取至少2块围场。",
			ruleToilets: "两厕所之间至少有11个中间格。",
			ruleConnections: "餐饮街跨越3对不同相邻园区的公共边。",
			ruleCorners: "3张园区的角格及相邻两格被同一河流覆盖。",
			rulePlaygrounds: "至少3个雕像正交相邻游乐场。",
			results: "熊公园导览",
			winner: "{{name}}获胜",
			tied: "共同获胜：{{name}}",
			total: "总分",
			housesScore: "动物馆",
			enclosuresScore: "围场",
			grizzliesScore: "灰熊",
			statuesScore: "雕像",
			achievementsScore: "成就",
			carsScore: "单轨列车",
			reserve: "库存分值（平分判定）",
			hideResults: "收起计分簿",
			showResults: "展开计分簿",
			again: "再来一局",
			lobby: "返回大厅",
			waitHost: "等待主机开始下一局",
			confirmAgain: "确定开始新的一局吗？",
			confirmLobby: "确定返回大厅吗？",
			autopilot: "托管 {{n}}%",
			hints: "本局求助 {{n}} 次",
			hintPlace: "放置{{tile}}，覆盖图标并推进园区建设。",
			hintTake: "领取{{tile}}。",
			hintExpand: "扩建一张园区。",
			hintTower: "在绿地上建塔。",
			hintExchange: "交换一块灰熊栖地。",
			hintFinish: "结束当前回合。",
			hintPass: "无法放置，领取一块绿地。",
			hintSkip: "放弃本次建塔。",
			errAction: "这个选择当前不可用。",
			errTurn: "现在轮不到你行动。",
			errPlacement: "拼板不能放在这里，请选择合法位置。",
			errPass: "库存仍有可放置的拼板，不能跳过。"
		},
		en: {
			name: "Bärenpark",
			desc: "Fit bear habitats and green areas into your park, race for statues, and score the most points.",
			rules: "Goal: build the highest-scoring bear park. Each player starts with an entrance area and one green tile. Every area has four rows and four columns, including a pit.\nOn your turn:\n· Place one tile from your personal supply. Rotate or flip it freely. It may cross area boundaries, but cannot overlap tiles, leave the park, or cover a pit. Except for your first tile, it must touch a previously placed tile orthogonally.\nResolve all newly covered symbols in any order, gaining one matching reward per symbol:\n· Wheelbarrow: take any green area.\n· Cement truck: take a top animal house or any green area.\n· Excavator: take any enclosure, a top animal house, or any green area.\n· Construction crew: take the top park area from either stack and immediately add it to your park.\n· Each newly completed area (all spaces except its pit covered) receives the highest remaining bear statue on its pit. Completing several areas grants one statue for each.\n· With achievements enabled, claim the highest tile for each achievement met this turn. Each player may claim each type once. End your turn.\nExpansion and supply:\nNew areas must share a complete edge with an existing area, remain upright, and cannot be below the entrance row. The base-game limit is four areas. Construction crews have no effect at the limit. Only the tops of park stacks are visible. Animal houses are taken highest value first; all enclosures are available.\nStarting green tiles are dealt in turn order:\n· 2 players: Toilet, Playground.\n· 3 players: Toilet, Playground, Food Street.\n· 4 players: Toilet, Playground, Playground, Food Street.\nSupply: 10 Toilets, 10 Playgrounds, and four Rivers and Food Streets per player.\nAnimal-house and statue values depend on the player count:\n· With two players, animal houses are worth 2, 4 and 6 points, and statues use even values from 2 to 16 points.\n· With three players, animal houses are worth 2–6 points, and statues are worth 3–14 points.\n· With four players, animal houses are worth 1–7 points, and statues are worth 1–16 points.\nEach bear species has three different five-space enclosures worth 6, 7 and 8 points respectively.\nPassing:\nYou must pass only when no tile in your supply can legally fit. Take one free green area and end your placement; you may place it next turn. Personal supply is unlimited.\nGame end and scoring:\nThe first player to complete four areas triggers the end. Every other player takes one final turn. Score placed animal houses, enclosures, statues and achievements. Ties are broken by total points on unplaced supply tiles, then shared.\nAchievements (optional, off by default):\nChoose three types at random. Take the highest remaining value first. The values below are listed in claim order, from highest to lowest; remove the lowest tile in each stack for two players.\n· Polar/Gobi/Koala/Panda: place three tiles of that species to qualify. The rewards are 8, 5 and 2 points in claim order.\n· Animal Houses: place one animal house of each shape to qualify. The rewards are 8, 5 and 2 points in claim order.\n· Green Areas: connect six green tiles orthogonally to qualify. The rewards are 9, 6 and 3 points in claim order.\n· Enclosures: connect three enclosures orthogonally to qualify. The rewards are 9, 6 and 3 points in claim order.\n· Long Food Street: join three Food Streets in one straight line to qualify. The rewards are 9, 6 and 3 points in claim order.\n· Long River: join three rivers at their watercourse ends to qualify. The rewards are 10, 7 and 4 points in claim order.\n· Twice Is Nice: gain at least two statues in one turn to qualify. The rewards are 10, 7 and 4 points in claim order.\nGrizzlies module (off by default):\nBuild five areas. Your fifth must be one of the visible exit areas, never a normal area. It cannot be directly below any other area. Once per turn, before or after placing/passing, permanently discard one green area and one animal house from your personal supply to gain an available seven-space grizzly habitat. A habitat gained at the start may be placed immediately. There are twelve habitats: three different shapes at each value 7–10. Add value-8 houses for 2/4 players, value-7 houses for 3. Statues extend to even values 2–20 for 2 players, 3–17 for 3, and 1–20 for 4. Complete five areas to trigger the end. End early if nobody can make progress.\nMonorails module (off by default):\nImmediately after placing a green area, you may put a tower on one of its spaces; you cannot add one later. The first tower is unrestricted. Every later tower must extend an end of your single line, horizontally or vertically exactly three spaces from the old tower (two spaces in between). Empty spaces and pits may lie underneath. Immediately connect the highest-value remaining car. Each player has one car worth each of 10, 8, 6, 5, 4 and 3 points. At most two cars may meet at a tower, always making a 90° turn. No separate lines, intersections or loops; at most one tower and car per turn. Towers score nothing; cars score their value. Combine both modules using the Grizzlies ending.\nNew achievements (optional, off by default):\nMix the six new types with the base types and select three. Neither module is required.\n· Construction Freeze: place an enclosure covering no symbols to qualify. The rewards are 8, 5 and 2 points in claim order.\n· Enclosure Planning: actually gain at least two enclosures in one turn to qualify. The rewards are 8, 5 and 2 points in claim order.\n· Toilets Apart: have two toilets with at least eleven intervening spaces along the shortest orthogonal path to qualify. The rewards are 8, 5 and 2 points in claim order.\n· Food Street Connections: have Food Streets cross three different pairs of adjacent areas to qualify. The rewards are 9, 6 and 3 points in claim order.\n· Rivers in Corners: have three areas each with a river covering a corner and its two neighboring spaces to qualify. The rewards are 9, 6 and 3 points in claim order.\n· Playgrounds with Statues: have three statues each orthogonally touching a playground to qualify. The rewards are 9, 6 and 3 points in claim order.\nAny expansion content adds six Toilets, bringing the total to sixteen.\nPit variant (optional, off by default):\nAfter the end is triggered, each other player may cover unoccupied pits on their final turn. An area whose pit is covered receives no statue.",
			options: "Game options",
			achievements: "Achievements",
			achievementsHint: "Race for three random achievements.",
			newAchievements: "New achievements",
			newAchievementsHint: "Add six Bad News Bears achievements and extra Toilets.",
			grizzlies: "Grizzlies",
			grizzliesHint: "Seven-space habitats, supply exchanges and a fifth exit area.",
			monorails: "Monorails",
			monorailsHint: "Build towers on green areas and connect a turning rail line.",
			pitVariant: "Pit variant",
			pitVariantHint: "Cover pits on your final turn, giving up their statues.",
			placing: "Place {{tile}}",
			viewPark: "View final park",
			reserveNote: "Supply points break ties only",
			placePrompt: "Choose a supply tile, then a position in your park",
			rewardsPrompt: "Choose a covered symbol, then take its reward",
			towerPrompt: "Build on the new green area, or skip",
			settling: "Scoring the park",
			endPrompt: "Turn complete",
			waiting: "Waiting for {{name}}",
			finalRound: "Final round",
			turn: "Turn {{n}}",
			supply: "General supply",
			inventory: "Your supply",
			yourPark: "{{name}}’s park",
			score: "{{n}} pts",
			boards: "{{n}} areas",
			statueSupply: "Statues",
			parkSupply: "Park areas",
			stack: "Stack {{n}} · {{count}} left",
			exit: "Exit area",
			entrance: "Bear park",
			chooseBoard: "Choose an area, then an expansion position",
			green: "Green area",
			house: "Animal house",
			enclosure: "Enclosure",
			grizzly: "Grizzly habitat",
			toilet: "Toilet",
			playground: "Playground",
			food: "Food Street",
			river: "River",
			polar: "Polar bears",
			gobi: "Gobi bears",
			koala: "Koalas",
			panda: "Pandas",
			wheelbarrow: "Wheelbarrow",
			cement: "Cement truck",
			excavator: "Excavator",
			crew: "Construction crew",
			pit: "Pit",
			confirm: "Place tile",
			cancel: "Cancel",
			rotate: "Rotate tile",
			flip: "Flip tile",
			finish: "End turn",
			skip: "Skip tower",
			pass: "No tile fits. Choose a free green area",
			passEmpty: "Pass",
			exchange: "Exchange for grizzly",
			exchangePrompt: "Select a green area and animal house from your supply, then a grizzly",
			exchangeConfirm: "Confirm exchange",
			noTiles: "No unplaced tiles",
			showSupply: "Show supply",
			hideSupply: "Close supply",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			placeAt: "Place at column {{x}}, row {{y}}",
			expandAt: "Expand here",
			towerAt: "Build tower here",
			connectTower: "Connect tower {{n}}",
			remaining: "{{n}} left",
			goalPolar: "Polar Bears",
			goalGobi: "Gobi Bears",
			goalKoala: "Koalas",
			goalPanda: "Pandas",
			goalGreen: "Green Areas",
			goalFood: "Long Food Street",
			goalRiver: "Long River",
			goalEnclosures: "Enclosures",
			goalHouses: "Animal Houses",
			goalTwice: "Twice Is Nice",
			goalFreeze: "Construction Freeze",
			goalPlanning: "Enclosure Planning",
			goalToilets: "Toilets Apart",
			goalConnections: "Food Street Connections",
			goalCorners: "Rivers in Corners",
			goalPlaygrounds: "Playgrounds with Statues",
			rulePolar: "Place three polar bear tiles.",
			ruleGobi: "Place three Gobi bear tiles.",
			ruleKoala: "Place three koala tiles.",
			rulePanda: "Place three panda tiles.",
			ruleGreen: "Connect six green tiles orthogonally.",
			ruleFood: "Join three Food Streets in one straight line.",
			ruleRiver: "Join three rivers at their watercourse ends.",
			ruleEnclosures: "Connect three enclosures orthogonally.",
			ruleHouses: "Place at least one of each animal house shape.",
			ruleTwice: "Gain two statues in one turn.",
			ruleFreeze: "Place an enclosure covering no symbols this turn.",
			rulePlanning: "Actually gain two enclosures in one turn.",
			ruleToilets: "Two toilets have eleven intervening spaces.",
			ruleConnections: "Food Streets cross three different pairs of areas.",
			ruleCorners: "Rivers cover a corner and its two neighbors in three areas.",
			rulePlaygrounds: "Three statues touch playgrounds orthogonally.",
			results: "Bear park tour",
			winner: "{{name}} wins",
			tied: "Shared victory: {{name}}",
			total: "Total",
			housesScore: "Animal houses",
			enclosuresScore: "Enclosures",
			grizzliesScore: "Grizzlies",
			statuesScore: "Statues",
			achievementsScore: "Achievements",
			carsScore: "Monorail cars",
			reserve: "Supply points (tiebreaker)",
			hideResults: "Hide scores",
			showResults: "Show scores",
			again: "Play again",
			lobby: "Back to lobby",
			waitHost: "Waiting for the host",
			confirmAgain: "Start a new game?",
			confirmLobby: "Return to the lobby?",
			autopilot: "Autopilot {{n}}%",
			hints: "{{n}} hints used",
			hintPlace: "Place {{tile}} to cover symbols and complete areas.",
			hintTake: "Take {{tile}}.",
			hintExpand: "Add a park area.",
			hintTower: "Build a tower on the green area.",
			hintExchange: "Exchange for a grizzly habitat.",
			hintFinish: "End this turn.",
			hintPass: "No tile fits; take a green area.",
			hintSkip: "Skip this tower.",
			errAction: "That choice is unavailable.",
			errTurn: "It is not your turn.",
			errPlacement: "That tile cannot go here. Choose a legal position.",
			errPass: "A tile in your supply still fits. You cannot pass."
		}
	}
};
//#endregion
export { ot as default };
