import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useT as s } from "@bgparty/sdk/i18n";
import { SheetFxProbe as c, SheetView as l } from "@bgparty/sdk/sheet-view";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { IconClose as d, IconRecenter as f } from "@bgparty/sdk/icons";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/catandice/data.ts
var x = {
	road: [
		1,
		1,
		0,
		0,
		0,
		0
	],
	knight: [
		0,
		0,
		1,
		1,
		1,
		0
	],
	settlement: [
		1,
		1,
		1,
		1,
		0,
		0
	],
	city: [
		0,
		0,
		0,
		2,
		3,
		0
	]
}, S = {
	start: [-1, -2],
	a: [-.5, -1],
	b: [-1, 0],
	left: [-2, 0],
	c: [-.5, 1],
	d: [-1, 2],
	leftBottom: [-2, 2],
	e: [-.5, 3],
	f: [.5, 3],
	g: [1, 2],
	h: [2, 2],
	i: [2.5, 1],
	j: [2, 0],
	k: [2.5, -1],
	o: [.5, 1],
	l: [1, 0],
	m: [.5, -1],
	n: [1, -2],
	q: [2, -2],
	p: [.5, -3],
	top: [-.5, -3]
}, C = ([e, t]) => [450 + e * 145, 425 + t * 115], w = [
	["start", "a"],
	["a", "b"],
	["b", "left"],
	["b", "c"],
	["c", "d"],
	["d", "leftBottom"],
	["d", "e"],
	["e", "f"],
	["f", "g"],
	["g", "h"],
	["h", "i"],
	["i", "j"],
	["j", "k"]
], T = (e) => e === 1 ? [
	...w,
	["g", "o"],
	["o", "l"],
	["l", "m"],
	["m", "n"]
] : [
	...w,
	["j", "l"],
	["k", "q"],
	["q", "n"],
	["n", "p"],
	["p", "top"]
], E = [
	{
		at: [-1.5, -1],
		resource: 4,
		color: "#7c8580"
	},
	{
		at: [-1.5, 1],
		resource: 3,
		color: "#e3b02f"
	},
	{
		at: [0, 2],
		resource: 2,
		color: "#9bc350"
	},
	{
		at: [1.5, 1],
		resource: 1,
		color: "#3f7340"
	},
	{
		at: [1.5, -1],
		resource: 0,
		color: "#bd6333"
	},
	{
		at: [0, -2],
		resource: -1,
		color: "#dab76e"
	}
], D = [
	4,
	3,
	2,
	1,
	0,
	-1,
	-1
], O = (e) => C(e === 6 ? [0, 0] : E[e].at), k = (e) => {
	let [t, n] = O(e);
	return [t, n + 40];
};
function A(e) {
	let t = T(e).map((t, n) => {
		let r = C(S[t[0]]), i = C(S[t[1]]);
		return {
			id: `r${n}`,
			kind: "road",
			at: [(r[0] + i[0]) / 2, (r[1] + i[1]) / 2],
			value: +(e === 1 && n > 0),
			edge: t
		};
	}), n = e === 1 ? [
		"a",
		"c",
		"e",
		"g",
		"l",
		"n"
	] : [
		"a",
		"c",
		"e",
		"i",
		"k",
		"n",
		"top"
	], r = e === 1 ? [
		"left",
		"leftBottom",
		"i",
		"k"
	] : [
		"left",
		"leftBottom",
		"g",
		"l"
	], i = [
		...t,
		...n.map((t, n) => ({
			id: `s${n}`,
			kind: "settlement",
			vertex: t,
			at: C(S[t]),
			value: e === 1 ? [
				3,
				4,
				5,
				7,
				9,
				11
			][n] : 1
		})),
		...r.map((t, n) => ({
			id: `c${n}`,
			kind: "city",
			vertex: t,
			at: C(S[t]),
			value: e === 1 ? [
				7,
				12,
				20,
				30
			][n] : 2
		}))
	], a = 0;
	for (let t = 0; t < (e === 1 ? 6 : 7); t++) {
		let n = O(t), r = e === 2 && t >= 5 ? 2 : 1;
		for (let o = 0; o < r; o++) i.push({
			id: `k${a++}`,
			kind: "knight",
			group: t,
			at: [n[0] + (r === 2 ? (o * 2 - 1) * 24 : 0), n[1] - 30],
			value: e === 1 ? a : 0
		});
	}
	return i;
}
var j = {
	1: A(1),
	2: A(2)
}, M = (e) => ({
	x: e.at[0] - (e.kind === "road" ? 26 : 29),
	y: e.at[1] - 30,
	w: e.kind === "road" ? 52 : 58,
	h: 60
}), N = {
	id: "catandice",
	tier: "alpha",
	nameKey: "games.catandice.name",
	descKey: "games.catandice.desc",
	rulesKey: "games.catandice.rules",
	icon: "🎲",
	iconImg: "games/catandice.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [
		2,
		3,
		4
	],
	playerRange: (e) => ({
		min: e?.island === 2 ? 2 : 1,
		max: 4
	}),
	accent: "#468c2d",
	releasedAt: "2026-11-01T00:53:28+08:00",
	search: {
		py: "ka tan dao tou zi ban",
		init: "ktdtzb"
	},
	hotseat: "open",
	mechanics: [
		"roll-and-write",
		"dice-rolling",
		"route-building"
	],
	interactionTags: [],
	rulesUrl: { en: "https://www.catan.com/sites/default/files/2021-07/catan_dice_game_rules_170522s.pdf" }
}, P = t.object({ island: t.union([t.literal(1), t.literal(2)]).default(1) }).prefault({ island: 1 }), F = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("hold"),
		die: t.int().min(0).max(5)
	}),
	t.object({ type: t.literal("stop") }),
	t.object({
		type: t.literal("build"),
		site: t.string().regex(/^[rsck]\d{1,2}$/)
	}),
	t.object({
		type: t.literal("trade"),
		die: t.int().min(0).max(5),
		other: t.int().min(0).max(5),
		face: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("joker"),
		group: t.int().min(0).max(6),
		die: t.int().min(0).max(5),
		face: t.int().min(0).max(5)
	}),
	t.object({ type: t.literal("end") })
]), ee = t.object({
	built: t.array(t.string()),
	used: t.array(t.int()),
	turns: t.array(t.int()),
	roundPoints: t.int().nonnegative(),
	roundBuilt: t.int().nonnegative()
}), I = t.object({
	island: t.union([t.literal(1), t.literal(2)]),
	phase: t.enum([
		"roll",
		"build",
		"done"
	]),
	players: t.array(t.string()).min(1).max(4),
	turn: t.string(),
	turnNumber: t.int().min(0),
	dice: t.array(t.int().min(0).max(5).nullable()).max(6),
	held: t.array(t.boolean()).max(6),
	rolls: t.int().min(0).max(3),
	sheets: t.record(t.string(), ee),
	scores: t.record(t.string(), t.int()),
	longest: t.string().nullable(),
	army: t.string().nullable(),
	legal: t.array(t.string()),
	reachable: t.array(t.string()),
	jokers: t.array(t.int()),
	revision: t.int().nonnegative()
}), L = t.object({});
//#endregion
//#region src/games/catandice/rules.ts
function R(e, t) {
	let n = j[t], r = new Set(e.built), i = n.filter((e) => e.kind === "road" && r.has(e.id));
	return n.filter((e) => r.has(e.id) ? !1 : e.kind === "road" ? i.some((t) => t.edge.some((t) => e.edge.includes(t))) : e.kind === "knight" ? t === 2 || n.filter((t) => t.kind === "knight" && t.value < e.value).every((e) => r.has(e.id)) : i.some((t) => t.edge.includes(e.vertex)) && (t === 2 || n.filter((t) => t.kind === e.kind && t.value < e.value).every((e) => r.has(e.id))));
}
var z = (e) => Array.from({ length: 6 }, (t, n) => e.filter((e) => e === n).length), B = (e, t) => x[t.kind].every((t, n) => z(e)[n] >= t);
function V(e, t) {
	return Array.from({ length: t === 1 ? 6 : 7 }, (e, t) => t).filter((n) => !e.used.includes(n) && j[t].filter((e) => e.kind === "knight" && e.group === n).every((t) => e.built.includes(t.id)));
}
function H(e, t) {
	let n = j[t].filter((t) => t.kind === "road" && e.built.includes(t.id));
	function r(e, t) {
		let i = 0;
		for (let a of n) if (!t.has(a.id) && a.edge.includes(e)) {
			let n = new Set(t);
			n.add(a.id), i = Math.max(i, 1 + r(a.edge.find((t) => t !== e), n));
		}
		return i;
	}
	return Math.max(0, ...n.flatMap((e) => e.edge).map((e) => r(e, /* @__PURE__ */ new Set())));
}
function U(e, t) {
	let n = e.sheets[t];
	return e.island === 1 ? n.turns.reduce((e, t) => e + t, 0) + n.roundPoints : j[2].filter((e) => n.built.includes(e.id)).reduce((e, t) => e + t.value, 0) + (e.longest === t ? 2 : 0) + (e.army === t ? 2 : 0);
}
function te(e) {
	if (e.island === 1) return;
	let t = e.players[e.turnIndex], n = e.sheets[t], r = H(n, 2);
	r >= 5 && (e.longest === null || r > H(e.sheets[e.longest], 2)) && (e.longest = t);
	let i = (t) => e.sheets[t].built.filter((e) => e.startsWith("k")).length;
	i(t) >= 3 && (e.army === null || i(t) > i(e.army)) && (e.army = t), U(e, t) >= 10 && (e.phase = "done");
}
var ne = {
	meta: N,
	saveCompatibility: { version: "1" },
	schemas: {
		action: F,
		config: P,
		publicView: I,
		privateView: L
	},
	setup(e, t, n) {
		return { state: {
			island: P.parse(e).island,
			players: [...t],
			turnIndex: 0,
			turnNumber: 0,
			phase: "roll",
			dice: [],
			held: [],
			rolls: 0,
			sheets: Object.fromEntries(t.map((e) => [e, {
				built: ["r0"],
				used: [],
				turns: [],
				roundPoints: 0,
				roundBuilt: 0
			}])),
			longest: null,
			army: null,
			seed: n,
			cursor: 0,
			revision: 0
		} };
	},
	reduce(t, n, r) {
		let i = t.players[t.turnIndex];
		if (t.phase === "done" || r.by !== i) return { code: "games.catandice.errTurn" };
		let a = structuredClone(t), o = a.sheets[i];
		if (a.revision++, n.type === "roll") {
			if (a.phase !== "roll" || a.rolls >= 3 || a.held.length > 0 && a.held.every(Boolean)) return { code: "games.catandice.errRoll" };
			let t = a.island === 2 ? Math.min(6, 3 + a.turnNumber) : 6, n = [];
			return a.dice = Array.from({ length: t }, (t, r) => a.held[r] ? a.dice[r] : (n.push(r), e(a.seed, a.cursor++, 6))), a.held = Array.from({ length: t }, (e, t) => a.held[t] ?? !1), a.rolls++, a.rolls === 3 && (a.phase = "build"), {
				state: a,
				fx: [{
					kind: "roll",
					rid: i,
					data: {
						dice: a.dice,
						rolled: n
					}
				}]
			};
		}
		if (n.type === "hold") return a.phase !== "roll" || a.rolls === 0 || n.die >= a.dice.length ? { code: "games.catandice.errRoll" } : (a.held[n.die] = !a.held[n.die], { state: a });
		if (n.type === "stop") return a.phase !== "roll" || a.rolls === 0 ? { code: "games.catandice.errRoll" } : (a.phase = "build", { state: a });
		if (a.phase !== "build") return { code: "games.catandice.errPhase" };
		if (n.type === "build") {
			let e = R(o, a.island).find((e) => e.id === n.site);
			if (!e) return { code: "games.catandice.errTarget" };
			if (!B(a.dice, e)) return { code: "games.catandice.errCost" };
			let t = [];
			for (let n = 0; n < 6; n++) for (let r = 0; r < x[e.kind][n]; r++) {
				let e = a.dice.indexOf(n);
				a.dice[e] = null, t.push(e);
			}
			return o.built.push(e.id), o.roundPoints += e.value, o.roundBuilt++, te(a), {
				state: a,
				fx: [{
					kind: "mark",
					rid: i,
					data: {
						site: e.id,
						value: e.value,
						spent: t
					}
				}]
			};
		}
		if (n.type === "trade") return n.die === n.other || a.dice[n.die] !== 5 || a.dice[n.other] !== 5 ? { code: "games.catandice.errCost" } : (a.dice[n.die] = n.face, a.dice[n.other] = null, {
			state: a,
			fx: [{
				kind: "convert",
				rid: i,
				data: {
					die: n.die,
					face: n.face,
					group: -1
				}
			}]
		});
		if (n.type === "joker") return !V(o, a.island).includes(n.group) || a.dice[n.die] == null || D[n.group] >= 0 && n.face !== D[n.group] ? { code: "games.catandice.errJoker" } : (o.used.push(n.group), a.dice[n.die] = n.face, {
			state: a,
			fx: [{
				kind: "convert",
				rid: i,
				data: {
					die: n.die,
					face: n.face,
					group: n.group
				}
			}]
		});
		o.turns.push(a.island === 1 && o.roundBuilt === 0 ? -2 : o.roundPoints);
		let s = o.turns.at(-1);
		return o.roundPoints = 0, o.roundBuilt = 0, a.island === 1 && a.players.every((e) => a.sheets[e].turns.length === 15) ? a.phase = "done" : (a.turnIndex = (a.turnIndex + 1) % a.players.length, a.turnNumber++, a.phase = "roll", a.dice = [], a.held = [], a.rolls = 0), {
			state: a,
			fx: [{
				kind: "record",
				rid: i,
				data: {
					index: o.turns.length - 1,
					points: s
				}
			}]
		};
	},
	viewFor(e) {
		let t = e.sheets[e.players[e.turnIndex]], n = R(t, e.island);
		return {
			public: {
				island: e.island,
				players: e.players,
				turn: e.players[e.turnIndex],
				turnNumber: e.turnNumber,
				phase: e.phase,
				dice: e.dice,
				held: e.held,
				rolls: e.rolls,
				sheets: e.sheets,
				longest: e.longest,
				army: e.army,
				revision: e.revision,
				scores: Object.fromEntries(e.players.map((t) => [t, U(e, t)])),
				reachable: e.phase === "done" ? [] : n.map((e) => e.id),
				legal: e.phase === "build" ? n.filter((t) => B(e.dice, t)).map((e) => e.id) : [],
				jokers: e.phase === "build" ? V(t, e.island) : []
			},
			private: {}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((t) => [t, U(e, t)])), n = [...e.players].sort((e, n) => t[n] - t[e]);
		return {
			phase: "done",
			ranking: n,
			scores: t,
			winner: n.filter((e) => t[e] === t[n[0]])
		};
	}
}, re = [
	{
		name: "brick",
		w: 78,
		h: 61,
		color: "#d74720",
		d: "M54,48L55,47L56,48L55,49ZM47,42L48,41L53,41L54,42L56,42L57,43L57,44L56,45L55,44L50,44L49,43L48,44L47,43ZM10,39L11,38L12,39L11,40ZM23,38L25,36L26,37L31,37L33,39L32,40L27,40L26,39L24,39ZM42,35L43,34L44,34L45,35L44,36L43,36ZM10,35L11,34L12,35L11,36ZM47,34L48,33L49,34L48,35ZM7,34L8,33L9,34L8,35ZM52,32L53,31L54,32L53,33ZM41,32L42,31L43,32L43,33L42,34L41,33ZM34,29L35,28L38,28L39,29L45,29L46,30L46,31L45,32L43,32L42,31L38,31L37,30L36,31L35,31L34,30ZM15,27L16,26L21,26L22,27L21,28L16,28ZM13,26L14,25L15,26L14,27ZM30,23L31,22L32,23L31,24ZM66,21L67,22L67,41L66,42L64,42L61,40L61,38L62,37L62,34L63,33L63,30L64,29L64,26L65,25L65,22ZM22,18L24,16L25,17L31,17L33,19L32,20L26,20L25,19L23,19ZM59,13L60,14L60,17L59,18L59,20L58,21L58,23L56,26L56,28L55,29L51,29L49,27L53,22L53,21L54,20L54,19L56,17L56,16ZM51,8L43,16L41,16L40,15L40,14L41,13L42,13L45,10L46,10L49,7L50,7ZM50,7L51,6L52,7L51,8ZM2,33L2,34L3,35L3,39L5,41L7,41L8,42L12,42L13,43L17,43L18,44L22,44L23,45L27,45L28,46L32,46L33,47L37,47L38,48L42,48L43,49L46,49L47,50L51,50L52,51L56,51L57,52L61,52L62,53L66,53L67,54L70,54L70,53L71,52L71,46L72,45L72,38L71,37L72,36L72,35L71,34L71,20L70,19L68,19L67,18L64,18L63,17L63,14L64,13L63,12L58,12L56,10L56,6L55,5L41,5L40,6L39,6L38,7L37,7L36,8L35,8L32,10L30,10L29,11L28,11L27,12L26,12L25,13L22,14L20,16L20,19L19,20L18,20L17,21L14,22L11,25L11,26L9,28L8,28L7,29L6,29L4,31L3,31L3,32Z"
	},
	{
		name: "lumber",
		w: 81,
		h: 58,
		color: "#8c4027",
		d: "M24,43L24,44L25,45L26,48L29,49L30,48L27,48L25,46ZM28,39L27,40L27,44L28,45L29,45L30,44L30,40L29,39ZM15,37L16,36L17,37L16,38ZM10,37L9,38L9,39L10,40L11,40L12,39L12,38L11,37ZM31,36L28,35L27,36L26,36L26,38L28,36L29,36L30,37L31,37ZM23,35L24,35L27,32L30,32L31,33L32,33L31,32L26,32L25,33L24,33L23,34ZM6,32L7,33L8,33L10,31L11,31L12,32L15,32L16,33L16,36L15,37L14,36L13,36L12,35L12,34L10,34L9,35L10,34L11,34L14,37L14,38L16,38L17,39L17,40L16,41L15,41L14,40L14,42L15,43L15,44L14,45L11,45L9,42L9,43L10,44L9,45L8,45L6,43L6,42L7,41L7,40L7,41L6,42L5,41L5,33ZM26,29L30,29L31,30L32,30L37,35L37,36L38,37L38,40L39,41L39,43L38,44L38,47L37,48L37,49L33,53L32,53L31,52L35,48L35,46L36,45L36,39L35,38L35,37L35,39L36,40L36,44L35,45L35,48L32,51L30,51L29,52L28,52L27,51L23,51L22,50L22,49L23,48L22,49L20,47L20,46L19,45L19,38L20,37L20,35L21,34L21,33ZM17,23L18,22L19,23L19,24L18,25L17,24ZM19,19L20,20L20,22L19,23L18,22L18,20ZM9,13L10,13L12,15L14,15L15,16L12,19L13,20L15,20L15,18L14,17L15,16L16,16L17,17L17,18L18,19L18,21L17,22L17,25L16,26L15,26L13,24L13,23L12,23L10,21L10,20L10,21L13,24L12,25L10,25L9,24L9,23L8,22L8,17L9,16L8,15L8,14ZM11,14L13,12L15,12L16,13L18,13L20,15L20,17L19,18L18,17L17,17L15,15L12,15ZM15,12L16,11L17,12L16,13ZM13,11L14,10L15,11L14,12ZM75,17L74,16L74,15L73,15L72,14L67,14L66,13L66,11L64,8L36,8L35,9L12,9L9,11L9,12L7,14L7,15L6,16L6,23L8,26L8,28L5,30L5,31L3,34L3,42L4,43L4,44L6,46L6,47L7,47L8,48L13,48L16,46L18,46L19,47L19,48L21,50L21,51L23,53L24,53L27,55L32,55L33,54L34,54L36,52L37,52L41,48L42,48L47,43L48,43L53,38L54,38L59,33L60,33L64,29L65,29L69,25L70,25L75,20Z"
	},
	{
		name: "wool",
		w: 78,
		h: 66,
		color: "#888a79",
		d: "M59,46L60,45L61,46L60,47ZM29,44L30,44L31,45L31,47L30,48L29,48L27,46ZM60,27L59,27L58,28L58,31L59,31L60,30ZM21,27L22,26L23,26L24,27L23,28L22,28ZM53,17L54,17L56,19L56,20L59,22L59,24L59,22L57,20L57,19L55,17ZM43,16L46,16L46,15L44,15ZM30,14L33,17L34,17L37,19L37,17L38,16L39,17L40,17L41,16L39,16L38,15L31,15ZM13,5L18,5L19,6L20,5L21,6L21,10L22,11L22,13L21,14L21,15L19,18L18,18L16,16L13,17L11,14L11,11L12,10L13,10L11,7ZM7,4L7,7L9,9L9,10L8,11L8,15L6,18L6,26L5,27L5,32L7,35L7,37L8,38L8,40L9,40L11,42L13,42L14,43L17,43L18,44L18,46L19,47L19,54L18,55L18,57L17,58L17,60L21,60L21,59L23,56L22,56L22,57L21,58L20,58L19,57L19,55L20,54L20,52L21,51L22,51L22,45L23,44L24,44L27,47L27,50L28,51L28,56L27,57L27,61L30,61L32,58L32,56L32,57L30,59L29,58L29,54L28,53L28,51L29,50L30,50L30,49L31,48L39,48L40,47L43,47L46,45L48,45L51,48L51,49L53,52L53,59L55,59L58,56L58,53L57,52L57,50L56,49L56,47L57,46L59,48L59,50L60,51L60,54L61,55L61,56L60,57L60,60L62,60L64,58L65,55L64,54L64,57L63,58L61,56L61,54L60,53L60,50L61,49L62,49L62,46L61,45L61,41L60,41L59,40L61,38L62,38L61,37L61,36L59,36L57,38L56,37L56,35L55,34L55,32L54,32L54,33L52,36L51,35L50,35L47,37L43,37L42,38L39,36L39,33L38,32L35,34L35,37L33,39L32,38L31,38L28,35L29,34L26,31L26,28L25,28L23,26L24,25L24,24L22,24L20,21L20,19L23,16L23,12L24,11L25,11L26,12L25,11L25,10L27,8L27,7L26,6L22,6L20,4L18,4L17,3L16,3L15,4L13,4L12,5L10,5L9,4Z"
	},
	{
		name: "grain",
		w: 74,
		h: 83,
		color: "#e59c13",
		d: "M27,38L28,37L29,38L29,39L28,40L27,39ZM26,36L27,35L28,36L27,37ZM48,35L49,34L50,35L49,36ZM24,26L25,25L26,25L30,29L29,30L28,30ZM42,22L43,23L43,25L41,27L40,26L40,25ZM19,22L20,21L21,21L23,23L23,24L22,25ZM17,5L17,6L16,7L18,9L18,10L20,12L20,13L27,20L27,21L28,22L27,23L26,23L21,18L20,18L19,17L16,17L16,18L17,19L18,19L20,21L19,22L17,22L16,21L15,21L14,22L8,22L7,23L6,23L6,24L15,24L16,25L17,25L19,27L20,27L23,30L24,30L27,33L27,35L26,36L23,33L22,33L19,31L15,31L14,30L11,30L10,31L4,31L3,32L3,33L4,34L12,34L13,33L15,33L16,32L19,31L20,32L21,32L26,37L26,38L27,39L27,44L28,45L28,47L27,48L27,52L28,53L28,56L27,57L27,65L26,66L26,70L25,71L25,73L24,74L24,75L26,77L28,77L29,78L32,78L34,80L37,80L40,78L43,78L44,77L46,77L47,76L47,74L46,73L46,70L45,69L45,67L44,66L44,64L43,63L43,59L42,58L42,51L43,50L42,47L43,46L43,44L44,43L45,40L49,36L51,36L52,37L53,37L56,39L58,39L61,41L64,41L64,39L62,37L60,37L59,36L57,36L56,35L50,35L49,34L54,30L55,30L56,29L57,29L60,27L62,27L63,28L64,27L66,27L67,26L70,26L72,24L71,23L69,23L66,25L64,25L63,26L61,26L60,25L62,23L62,22L60,22L57,25L56,25L53,28L52,28L52,29L46,35L45,34L46,31L48,29L48,28L49,27L50,27L54,23L54,22L56,20L56,19L58,16L57,15L56,16L55,16L55,17L51,21L51,22L50,23L49,26L47,28L46,28L45,27L45,25L46,24L46,23L47,22L48,19L51,16L52,16L53,15L53,13L55,11L55,10L56,9L56,7L55,6L54,6L52,8L52,9L50,12L50,16L48,18L47,17L47,15L46,15L45,16L44,15L44,13L43,13L42,14L42,17L41,18L41,22L40,23L40,25L39,26L37,24L37,23L39,20L39,11L38,10L38,9L37,9L37,10L36,11L36,24L37,25L37,26L36,27L35,27L34,26L34,23L33,22L33,20L32,19L32,18L31,17L30,14L28,12L27,12L27,13L28,14L28,16L29,17L29,18L31,21L31,23L33,26L33,28L32,29L30,27L30,26L28,23L28,21L27,20L27,19L25,17L25,15L24,14L23,11L21,9L21,8L19,6L18,6Z"
	},
	{
		name: "ore",
		w: 77,
		h: 62,
		color: "#24251f",
		d: "M25,50L26,49L27,50L26,51ZM31,33L32,32L33,32L34,33L35,33L36,34L39,35L41,37L44,38L46,40L46,42L45,43L42,43L41,42L41,44L40,45L39,44L39,42L36,39L35,39L34,38L34,37L31,34ZM23,33L24,32L25,33L24,34ZM48,27L49,28L49,30L46,33L45,33L43,30L45,28ZM65,25L65,23L66,22L68,22L69,23L66,26ZM10,23L10,21L14,17L15,17L16,18L16,19L19,18L22,21L20,23L17,23L15,25L12,25ZM59,14L61,12L64,12L65,13L68,13L71,15L71,16L72,17L72,19L71,20L68,20L67,19L66,20L65,20L63,18L63,17L60,16L59,15ZM71,14L70,13L66,13L65,12L62,11L61,12L59,12L58,13L57,13L54,16L52,16L51,15L51,14L52,13L53,13L56,10L56,8L55,8L54,7L51,6L52,7L54,7L55,8L55,9L52,12L51,12L50,11L49,12L48,11L45,14L44,13L44,12L43,13L42,13L38,17L37,16L36,17L36,18L39,21L39,20L41,18L43,18L44,17L56,17L57,18L59,18L60,19L60,20L57,23L56,23L54,25L53,25L52,26L50,26L49,27L47,27L46,26L44,26L43,27L42,27L38,23L36,23L35,24L34,24L33,23L33,22L28,18L32,14L34,14L35,13L34,13L33,12L32,13L29,13L28,12L27,12L26,11L26,10L28,7L29,8L37,8L38,9L39,9L40,8L43,8L44,7L47,7L48,6L49,6L47,6L46,7L41,7L40,8L34,8L33,7L26,7L25,8L22,9L17,13L16,13L5,24L5,25L4,26L4,28L3,29L3,38L4,39L4,40L6,42L7,42L8,43L8,48L10,50L10,51L13,54L20,54L21,53L26,53L27,52L29,52L30,51L32,51L33,50L36,52L39,52L40,51L42,51L45,49L45,48L46,47L47,44L55,36L57,36L58,35L59,35L61,33L63,33L64,32L65,32L67,30L68,30L68,29L70,27L70,24L71,23L71,22L73,19L73,18L72,17Z"
	}
], ie = "-145,0 -72.5,-115 72.5,-115 145,0 72.5,115 -72.5,115";
function W({ x: e, y: t, size: n = 1, light: r = !1 }) {
	return /* @__PURE__ */ g("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ h("ellipse", {
				cy: "27",
				rx: "23",
				ry: "7",
				fill: "#183f33",
				opacity: ".22"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-3,2H3V28H-3Z",
				fill: "#75513a"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0,-49L18,-20H11L26,3H16L30,23H-30L-16,3H-26L-11,-20H-18Z",
				fill: r ? "#477e48" : "#24573d"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0,-49V23H-30L-16,3H-26L-11,-20H-18Z",
				fill: r ? "#6a9651" : "#3f7948"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0,-42L-11,-23M0,-14L-18,4M0,9L-20,21",
				fill: "none",
				stroke: r ? "#8eaf66" : "#5a8d50",
				strokeWidth: "2",
				strokeLinecap: "round"
			})
		]
	});
}
function G({ x: e, y: t, size: n = 1, flip: r = !1 }) {
	return /* @__PURE__ */ g("g", {
		transform: `translate(${e} ${t}) scale(${r ? -n : n} ${n})`,
		children: [
			/* @__PURE__ */ h("ellipse", {
				cy: "17",
				rx: "23",
				ry: "6",
				fill: "#477336",
				opacity: ".26"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-13,4L-14,19M4,5L5,20M-7,5L-6,17M12,5L13,17",
				fill: "none",
				stroke: "#514c38",
				strokeWidth: "4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-21,-2Q-25,-11 -16,-13Q-17,-21 -7,-20Q-2,-27 5,-20Q15,-23 19,-15Q27,-12 21,-4Q23,8 13,10Q7,16 0,11Q-10,16 -15,9Q-25,8 -21,-2Z",
				fill: "#fff7df",
				stroke: "#d6d7b7",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-15,6Q-2,11 16,3Q12,12 5,11Q-5,16 -15,9Z",
				fill: "#e1e1c3"
			}),
			/* @__PURE__ */ h("path", {
				d: "M15,-16Q24,-20 25,-10L24,2Q20,9 15,3L12,-8Z",
				fill: "#655e48"
			}),
			/* @__PURE__ */ h("path", {
				d: "M15,-12L9,-16M24,-12L29,-16",
				stroke: "#655e48",
				strokeWidth: "4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "22",
				cy: "-8",
				r: "1.4",
				fill: "#fff9df"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-22,-5L-27,-9",
				stroke: "#f7f0d7",
				strokeWidth: "4",
				strokeLinecap: "round"
			})
		]
	});
}
function K({ x: e, y: t, lean: n = 0 }) {
	return /* @__PURE__ */ g("g", {
		transform: `translate(${e} ${t}) rotate(${n})`,
		stroke: "#845c23",
		strokeWidth: "1.4",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M0,29V-27",
				fill: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0,-12Q-13,-13 -9,-24Q0,-22 0,-12M0,-1Q-14,-3 -10,-14Q0,-12 0,-1M0,10Q-14,8 -10,-3Q0,-1 0,10",
				fill: "#f7d56b"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0,-17Q11,-19 8,-29Q0,-27 0,-17M0,-6Q13,-8 9,-19Q0,-16 0,-6M0,5Q14,3 10,-8Q0,-6 0,5",
				fill: "#ffe592"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0,-28V-36M-9,-24L-14,-31M8,-29L13,-36",
				fill: "none",
				stroke: "#d7ac4a"
			})
		]
	});
}
function ae({ resource: e }) {
	let t = n(), r = e === 4 ? ["#bec9c1", "#7a8b80"] : e === 3 ? ["#dca23c", "#b67a24"] : e === 2 ? ["#c2d87a", "#85ad48"] : e === 1 ? ["#96b16a", "#467345"] : e === 0 ? ["#dcaa71", "#b96438"] : ["#f5e7bd", "#e3cc96"];
	return /* @__PURE__ */ g("g", { children: [
		/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("linearGradient", {
			id: t,
			x1: "0",
			y1: "0",
			x2: ".3",
			y2: "1",
			children: [/* @__PURE__ */ h("stop", { stopColor: r[0] }), /* @__PURE__ */ h("stop", {
				offset: "1",
				stopColor: r[1]
			})]
		}) }),
		/* @__PURE__ */ h("rect", {
			x: "-145",
			y: "-115",
			width: "290",
			height: "230",
			fill: `url(#${t})`
		}),
		e === 4 ? /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M-166,26L-112,-51L-77,-25L-20,-102L21,-43L70,-90L162,37V118H-166Z",
				fill: "#6f8179"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-166,49L-87,-64L-39,-10L12,-87L83,19L113,-18L166,52V118H-166Z",
				fill: "#88958b"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-87,-64L-95,-12L-125,25L-113,44L-149,76L-166,49Z",
				fill: "#b4bcae"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-87,-64L-39,-10L-56,-17L-59,11L-80,-6L-96,10L-95,-12Z",
				fill: "#536d66"
			}),
			/* @__PURE__ */ h("path", {
				d: "M12,-87L-2,-22L-27,10L-8,42L-46,82H-75L-52,34L-39,-10Z",
				fill: "#c1c8b6"
			}),
			/* @__PURE__ */ h("path", {
				d: "M12,-87L83,19L53,5L38,-27L25,-15L17,-40L-2,-22Z",
				fill: "#596f68"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-87,-64L-106,-37L-94,-40L-86,-32L-78,-44L-66,-40Z",
				fill: "#e6e6cf"
			}),
			/* @__PURE__ */ h("path", {
				d: "M12,-87L-6,-58L7,-62L16,-49L22,-61L35,-53Z",
				fill: "#ecebd3"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-153,88Q-82,43 -16,73T151,63L170,120H-170Z",
				fill: "#728772"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-124,78L-105,52L-75,57L-62,86L-95,98Z",
				fill: "#a5b19e"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-105,52L-102,76L-62,86L-75,57Z",
				fill: "#4e6960"
			}),
			/* @__PURE__ */ h("path", {
				d: "M64,53L89,36L111,51L114,78L81,86L58,72Z",
				fill: "#b6bca9"
			}),
			/* @__PURE__ */ h("path", {
				d: "M89,36L88,63L114,78L111,51Z",
				fill: "#546e66"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-126,104Q-54,84 -21,92M47,98L80,94M94,13L110,27",
				fill: "none",
				stroke: "#c6c9a7",
				strokeWidth: "2",
				strokeLinecap: "round"
			})
		] }) : e === 1 ? /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M-160,-5Q-89,-62 -18,-35T158,-57V120H-160Z",
				fill: "#688e50"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-158,69Q-95,21 -15,46T161,15V120H-158Z",
				fill: "#527f45"
			}),
			/* @__PURE__ */ h("path", {
				d: "M26,-115Q53,-82 37,-45T42,13Q62,48 34,115H2Q28,58 13,25T17,-42Q33,-82 9,-115Z",
				fill: "#a0ad69",
				opacity: ".65"
			}),
			/* @__PURE__ */ h(W, {
				x: -78,
				y: -64,
				size: .86
			}),
			/* @__PURE__ */ h(W, {
				x: -31,
				y: -87,
				size: .68,
				light: !0
			}),
			/* @__PURE__ */ h(W, {
				x: 47,
				y: -81,
				size: .76
			}),
			/* @__PURE__ */ h(W, {
				x: 95,
				y: -40,
				size: .92,
				light: !0
			}),
			/* @__PURE__ */ h(W, {
				x: -104,
				y: -6,
				size: 1.08,
				light: !0
			}),
			/* @__PURE__ */ h(W, {
				x: -63,
				y: 29,
				size: 1.18
			}),
			/* @__PURE__ */ h(W, {
				x: 88,
				y: 25,
				size: 1.1
			}),
			/* @__PURE__ */ h(W, {
				x: -105,
				y: 75,
				size: .85
			}),
			/* @__PURE__ */ h(W, {
				x: -48,
				y: 86,
				size: .9,
				light: !0
			}),
			/* @__PURE__ */ h(W, {
				x: 52,
				y: 87,
				size: 1.15,
				light: !0
			}),
			/* @__PURE__ */ h(W, {
				x: 109,
				y: 91,
				size: 1
			}),
			/* @__PURE__ */ h("path", {
				d: "M-19,94L-12,82M-17,94L-23,85M22,-75L27,-83",
				stroke: "#bcc47d",
				strokeWidth: "2",
				fill: "none",
				strokeLinecap: "round"
			})
		] }) : e === 3 ? /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M-166,-64L-27,-99L53,-39L-163,32Z",
				fill: "#e4b74c"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-166,43L62,-29L166,22L-75,118H-166Z",
				fill: "#ce922e"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-51,118L166,34V118Z",
				fill: "#b47b26"
			}),
			/* @__PURE__ */ g("g", {
				fill: "none",
				stroke: "#9b6823",
				strokeWidth: "2.5",
				children: [
					/* @__PURE__ */ h("path", { d: "M-145,-40L-30,-75M-151,-26L-19,-65M-151,-11L-7,-56M-150,4L6,-46" }),
					/* @__PURE__ */ h("path", { d: "M-149,60L61,-6M-139,75L78,5M-126,90L95,16M-112,105L113,27" }),
					/* @__PURE__ */ h("path", { d: "M-16,117L143,58M25,118L151,73M66,117L151,88" })
				]
			}),
			/* @__PURE__ */ h("path", {
				d: "M-163,37L61,-35L166,17M-63,118L166,29",
				fill: "none",
				stroke: "#f7d77a",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ h(K, {
				x: -96,
				y: 3,
				lean: -16
			}),
			/* @__PURE__ */ h(K, {
				x: -78,
				y: 9,
				lean: 8
			}),
			/* @__PURE__ */ h(K, {
				x: -89,
				y: -5
			}),
			/* @__PURE__ */ h(K, {
				x: 81,
				y: 58,
				lean: -9
			}),
			/* @__PURE__ */ h(K, {
				x: 100,
				y: 64,
				lean: 13
			}),
			/* @__PURE__ */ h(K, {
				x: 93,
				y: 51
			}),
			/* @__PURE__ */ h("path", {
				d: "M-98,37L-66,33M78,91L111,86",
				stroke: "#815b29",
				strokeWidth: "4",
				strokeLinecap: "round"
			})
		] }) : e === 2 ? /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M-163,-28Q-94,-79 -12,-46T160,-57V119H-163Z",
				fill: "#9abb5c"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-160,12Q-83,-34 -3,-4T163,-8V120H-160Z",
				fill: "#b4cf6c"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-164,69Q-90,16 -8,48T166,26V120H-164Z",
				fill: "#7da348"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-139,91Q-53,46 26,78T145,65",
				fill: "none",
				stroke: "#a4c365",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ h(G, {
				x: -80,
				y: -3,
				size: .93
			}),
			/* @__PURE__ */ h(G, {
				x: 80,
				y: 66,
				size: .85,
				flip: !0
			}),
			/* @__PURE__ */ h(G, {
				x: 38,
				y: -80,
				size: .65
			}),
			/* @__PURE__ */ h("g", {
				stroke: "#5f883d",
				strokeWidth: "2",
				fill: "none",
				strokeLinecap: "round",
				children: /* @__PURE__ */ h("path", { d: "M-103,66L-108,56M-103,66L-98,53M-59,86L-61,78M-59,86L-53,77M102,-37L98,-47M102,-37L108,-46M-40,-80L-43,-88M-40,-80L-35,-86" })
			}),
			/* @__PURE__ */ g("g", {
				fill: "#f5e4a0",
				children: [
					/* @__PURE__ */ h("circle", {
						cx: "-111",
						cy: "49",
						r: "2"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "-93",
						cy: "79",
						r: "2"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "108",
						cy: "-51",
						r: "2.5"
					})
				]
			})
		] }) : e === 0 ? /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M-165,9Q-100,-88 -35,-50Q-9,-34 16,-52Q83,-108 165,-6V120H-165Z",
				fill: "#c27b49"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-163,41Q-104,-38 -48,-15T44,-28Q102,-64 166,17V120H-163Z",
				fill: "#e0a368"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-168,80Q-95,-6 -27,28T66,14Q116,-3 167,45V120H-168Z",
				fill: "#b9643d"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-151,98Q-86,38 -26,63T75,52Q118,41 161,76V120H-151Z",
				fill: "#cc8752"
			}),
			/* @__PURE__ */ g("g", {
				fill: "none",
				strokeLinecap: "round",
				children: [/* @__PURE__ */ h("path", {
					d: "M-124,-8Q-93,-48 -59,-37M49,-52Q79,-76 109,-43M-126,46Q-88,8 -57,16M49,32Q97,11 128,41M-102,93Q-64,65 -37,75",
					stroke: "#efbb7e",
					strokeWidth: "3"
				}), /* @__PURE__ */ h("path", {
					d: "M-106,-12L-87,-26M72,-45L90,-41M-118,54L-94,36M87,48L107,50M-86,97L-70,88",
					stroke: "#9c5639",
					strokeWidth: "2"
				})]
			}),
			/* @__PURE__ */ h("path", {
				d: "M-98,65L-85,51L-67,54L-61,68L-78,76Z",
				fill: "#e7b27b"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-85,51L-82,65L-61,68L-67,54Z",
				fill: "#975039"
			}),
			/* @__PURE__ */ h("path", {
				d: "M71,-7L83,-18L96,-10L99,4L80,10Z",
				fill: "#f0c08b"
			}),
			/* @__PURE__ */ h("path", {
				d: "M83,-18L85,-2L99,4L96,-10Z",
				fill: "#b46b44"
			})
		] }) : /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M-166,-30Q-85,-77 -6,-39T164,-57V120H-166Z",
				fill: "#e4cea0"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-163,16Q-91,-30 -13,7T164,-8V120H-163Z",
				fill: "#f6e7bc"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-166,64Q-80,7 5,51T163,28V120H-166Z",
				fill: "#d8bb85"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-163,103Q-85,54 -5,88T166,72V120H-163Z",
				fill: "#ecd6a5"
			}),
			/* @__PURE__ */ g("g", {
				fill: "none",
				strokeLinecap: "round",
				children: [/* @__PURE__ */ h("path", {
					d: "M-125,-39Q-86,-57 -48,-47M52,-32Q94,-24 129,-41M-128,11Q-91,-6 -59,5M57,27Q96,34 127,19M-114,70Q-80,50 -46,58M56,92Q93,92 122,77",
					stroke: "#fff1cc",
					strokeWidth: "3"
				}), /* @__PURE__ */ h("path", {
					d: "M-108,86Q-79,69 -53,77M72,-61L95,-58M88,49L109,43",
					stroke: "#c3a471",
					strokeWidth: "2"
				})]
			}),
			/* @__PURE__ */ h("path", {
				d: "M-95,-3L-99,-14M-95,-3L-89,-16M-95,-3L-83,-7M91,72L88,62M91,72L98,64",
				stroke: "#9a8c4e",
				strokeWidth: "2",
				strokeLinecap: "round"
			})
		] })
	] });
}
//#endregion
//#region src/games/catandice/art.tsx
function q({ face: e, size: t = 28 }) {
	let n = re[e];
	return /* @__PURE__ */ h("svg", {
		viewBox: n ? `0 0 ${n.w} ${n.h}` : "0 0 80 80",
		width: t,
		height: t,
		"aria-hidden": "true",
		children: n ? /* @__PURE__ */ h("path", {
			d: n.d,
			fill: n.color,
			fillRule: "evenodd"
		}) : /* @__PURE__ */ g("g", {
			fill: "#e3ad22",
			stroke: "#865811",
			strokeWidth: "3",
			children: [
				/* @__PURE__ */ h("circle", {
					cx: "40",
					cy: "40",
					r: "31"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "40",
					cy: "40",
					r: "23",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", { d: "M35 24H46M33 31H44M39 24V56" })
			]
		})
	});
}
function J({ face: e, size: t = "100%" }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 80 84",
		width: t,
		height: t,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("rect", {
				x: "3",
				y: "6",
				width: "74",
				height: "75",
				rx: "12",
				fill: "#c6b794"
			}),
			/* @__PURE__ */ h("rect", {
				x: "3",
				y: "2",
				width: "74",
				height: "75",
				rx: "12",
				fill: e === null ? "#1c5871" : "#fff9e9",
				stroke: e === null ? "#39859c" : "#c5b796",
				strokeWidth: "2"
			}),
			e !== null && /* @__PURE__ */ h("svg", {
				x: "13",
				y: "13",
				width: "54",
				height: "54",
				children: /* @__PURE__ */ h(q, {
					face: e,
					size: "100%"
				})
			})
		]
	});
}
function oe({ island: e }) {
	let t = n(), r = e === 2 ? [...E, {
		at: [0, 0],
		resource: -1,
		color: "#dab76e"
	}] : E;
	return /* @__PURE__ */ g("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ h("clipPath", {
				id: t,
				children: /* @__PURE__ */ h("polygon", { points: ie })
			}) }),
			/* @__PURE__ */ h("rect", {
				width: "900",
				height: "850",
				fill: "#168db8"
			}),
			r.map((e, n) => {
				let [r, i] = O(n);
				return /* @__PURE__ */ g("g", {
					transform: `translate(${r} ${i})`,
					children: [/* @__PURE__ */ h("polygon", {
						points: "-149,0 -74.5,-119 74.5,-119 149,0 74.5,119 -74.5,119",
						fill: "#f3d18b"
					}), /* @__PURE__ */ h("g", {
						clipPath: `url(#${t})`,
						children: /* @__PURE__ */ h(ae, { resource: e.resource })
					})]
				}, n);
			})
		]
	});
}
var Y = {
	road: "M-29,-10H29V10H-29Z",
	knight: "M-15,19Q-21,-3 -9,-10A14,14 0 1,1 9,-10Q21,-3 15,19Z",
	settlement: "M-22,24V-8H-28L0,-33L28,-8H22V24Z",
	city: "M-29,24V-5H-6V-15L9,-31L30,-10H22V24Z"
};
function se(e) {
	if (!e.edge) return 0;
	let [t, n] = e.edge.map((e) => C(S[e]));
	return Math.atan2(n[1] - t[1], n[0] - t[0]) * 180 / Math.PI;
}
function ce({ site: e, built: t, eligible: n, selected: r, island: i, anchorName: a }) {
	let { hidden: s } = o(a ?? null), c = se(e);
	return /* @__PURE__ */ g("g", {
		transform: `rotate(${c})`,
		children: [
			/* @__PURE__ */ h("path", {
				d: Y[e.kind],
				fill: e.id === "r0" ? "#793484" : i === 2 && e.id === "r6" ? "#b3b6ad" : "#fff9df",
				stroke: "#29392f",
				strokeWidth: "3",
				strokeLinejoin: "round"
			}),
			(i === 1 || e.kind === "settlement" || e.kind === "city") && e.id !== "r0" && /* @__PURE__ */ h("text", {
				y: e.kind === "road" ? 6 : 14,
				textAnchor: "middle",
				className: "cd-site-value",
				fontSize: e.kind === "road" ? 18 : 23,
				fill: "#24382f",
				children: e.value
			}),
			t && /* @__PURE__ */ h("path", {
				d: "M-17,-17L17,17M15,-18L-16,17",
				visibility: s ? "hidden" : void 0,
				fill: "none",
				stroke: e.id === "r0" ? "#fff9df" : "#194f79",
				strokeWidth: "6",
				strokeLinecap: "round"
			}),
			(n || r) && /* @__PURE__ */ h("path", {
				d: Y[e.kind],
				fill: r ? "#fff09b55" : "none",
				stroke: r ? "#ffdb51" : "#ffffff",
				strokeWidth: "5",
				strokeLinejoin: "round",
				strokeDasharray: "9 6",
				children: /* @__PURE__ */ h("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-30",
					dur: "0.7s",
					repeatCount: "indefinite"
				})
			})
		]
	});
}
//#endregion
//#region src/games/catandice/labels.ts
var X = [
	"games.catandice.resources.brick",
	"games.catandice.resources.lumber",
	"games.catandice.resources.wool",
	"games.catandice.resources.grain",
	"games.catandice.resources.ore",
	"games.catandice.resources.gold"
], Z = {
	road: "games.catandice.kinds.road",
	settlement: "games.catandice.kinds.settlement",
	city: "games.catandice.kinds.city",
	knight: "games.catandice.kinds.knight"
};
//#endregion
//#region src/games/catandice/view-player.tsx
function le(e) {
	return /* @__PURE__ */ h(Q, {
		...e,
		public: e.public
	});
}
function Q(e) {
	let t = s(), n = e.public, [r, i] = a(n.turn), o = n.sheets[r] ? r : n.turn, [c, l] = a(n.turnNumber), [_, v] = a(null), [y, b] = a(null), [x, S] = a(!1), [C, w] = a(!1), [T, E] = a(0), [O, k] = a(n.revision);
	(c !== n.turnNumber || r !== o) && (l(n.turnNumber), i(n.turn), v(null), b(null)), O !== n.revision && (k(n.revision), v(null), b(null));
	let A = n.sheets[o], M = n.phase !== "done" && n.turn === e.myRid && o === n.turn, N = (t) => e.send(t), P = (t) => e.members.find((e) => e.rid === t)?.name ?? t, F = j[n.island].find((e) => e.id === _), ee = M && !y ? n.phase === "roll" && n.rolls > 0 ? j[n.island].filter((e) => n.reachable.includes(e.id) && B(n.dice, e)).map((e) => e.id) : n.legal : [], I = (e) => {
		M && n.phase === "build" && (e.startsWith("j:") ? (v(null), b({
			kind: "joker",
			group: Number(e.slice(2)),
			die: null
		})) : (b(null), v(e)));
	}, L = n.island === 2 ? Math.min(6, 3 + n.turnNumber) : 6, R = n.dice.length ? n.dice : Array.from({ length: L }, () => null), z = (e) => {
		if (n.phase === "roll") {
			N({
				type: "hold",
				die: e
			});
			return;
		}
		if (y && n.dice[e] != null) {
			let t = D[y.group];
			y.kind === "joker" && t >= 0 ? N({
				type: "joker",
				group: y.group,
				die: e,
				face: t
			}) : b({
				...y,
				die: e
			});
		}
	}, V = n.dice.flatMap((e, t) => e === 5 ? [t] : []);
	return /* @__PURE__ */ g(p, {
		adaptive: !0,
		scroll: !1,
		className: `cd-game${n.island === 2 ? " cd-island-two" : ""}`,
		banner: /* @__PURE__ */ g("header", {
			className: "cd-header",
			children: [/* @__PURE__ */ g("div", {
				className: "cd-mode",
				children: [/* @__PURE__ */ h("strong", { children: t("games.catandice.name") }), /* @__PURE__ */ h("span", { children: t(n.island === 1 ? "games.catandice.islandOne" : "games.catandice.islandTwo") })]
			}), /* @__PURE__ */ h("nav", {
				className: "cd-players",
				"aria-label": t("games.catandice.viewMap"),
				children: n.players.map((t) => /* @__PURE__ */ g("button", {
					type: "button",
					onClick: () => {
						i(t), v(null), b(null);
					},
					className: `cd-player${o === t ? " cd-viewed" : ""}`,
					"aria-pressed": o === t,
					children: [
						/* @__PURE__ */ h("span", {
							className: "cd-player-dot",
							style: { background: u[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % u.length].hex }
						}),
						/* @__PURE__ */ g("span", {
							className: "cd-player-name",
							title: P(t),
							children: [P(t), t === n.turn && /* @__PURE__ */ h("span", {
								"aria-hidden": "true",
								children: " ◂"
							})]
						}),
						/* @__PURE__ */ h("b", { children: n.scores[t] })
					]
				}, t))
			})]
		}),
		children: [
			/* @__PURE__ */ g("div", {
				className: "cd-layout",
				children: [/* @__PURE__ */ g("section", {
					className: "cd-map-area",
					"aria-label": t("games.catandice.mapOf", { name: P(o) }),
					children: [
						/* @__PURE__ */ h(fe, {
							island: n.island,
							sheet: A,
							rid: o,
							highlighted: ee,
							eligible: M && !y ? n.legal : [],
							jokers: M && !y ? n.jokers : [],
							selected: _,
							onChoose: I,
							fitKey: `${o}:${T}`
						}),
						F && M && /* @__PURE__ */ h(de, {
							site: F,
							onCancel: () => v(null),
							onBuild: () => N({
								type: "build",
								site: F.id
							})
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "cd-fit",
							"aria-label": t("games.catandice.resetMap"),
							onClick: () => E(T + 1),
							children: /* @__PURE__ */ h(f, { size: 20 })
						})
					]
				}), /* @__PURE__ */ g("aside", {
					className: "cd-tools",
					children: [
						/* @__PURE__ */ g("div", {
							className: "cd-turn",
							children: [/* @__PURE__ */ h("span", { children: t(n.island === 1 ? "games.catandice.round" : "games.catandice.race", { n: Math.min(15, n.sheets[n.turn].turns.length + 1) }) }), /* @__PURE__ */ h("span", { children: n.phase === "roll" ? t("games.catandice.rolling", { n: n.rolls }) : t("games.catandice.current", { n: n.sheets[n.turn].roundPoints }) })]
						}),
						/* @__PURE__ */ h("div", {
							className: "cd-tray",
							children: R.map((e, t) => /* @__PURE__ */ h(ue, {
								face: e,
								index: t,
								rid: n.turn,
								unrolled: n.rolls === 0,
								held: n.phase === "roll" && (n.held[t] ?? !1),
								chosen: y?.die === t,
								enabled: M && e !== null && (n.phase === "roll" && n.rolls > 0 || n.phase === "build" && !!y && y.kind !== "trade"),
								onClick: () => z(t)
							}, t))
						}),
						/* @__PURE__ */ h("div", {
							className: "cd-decision",
							"aria-live": "polite",
							children: y ? /* @__PURE__ */ g("div", {
								className: "cd-convert",
								children: [/* @__PURE__ */ g("div", {
									className: "cd-convert-title",
									children: [/* @__PURE__ */ h("span", { children: t(y.die === null ? "games.catandice.selectDie" : "games.catandice.chooseResource") }), /* @__PURE__ */ h("button", {
										className: "cd-icon-button",
										onClick: () => b(null),
										"aria-label": t("games.catandice.cancel"),
										children: /* @__PURE__ */ h(d, { size: 18 })
									})]
								}), y.die !== null && /* @__PURE__ */ h("div", {
									className: "cd-resource-choices",
									children: Array.from({ length: y.kind === "trade" ? 5 : 6 }, (e, n) => /* @__PURE__ */ h("button", {
										type: "button",
										className: "cd-resource-choice",
										"aria-label": t(X[n]),
										onClick: () => {
											y.kind === "trade" ? N({
												type: "trade",
												die: y.die,
												other: V.find((e) => e !== y.die),
												face: n
											}) : N({
												type: "joker",
												group: y.group,
												die: y.die,
												face: n
											});
										},
										children: /* @__PURE__ */ h(q, {
											face: n,
											size: "100%"
										})
									}, n))
								})]
							}) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("p", { children: n.phase === "done" ? t("games.catandice.result") : M ? t(n.phase === "roll" ? "games.catandice.holdPrompt" : "games.catandice.buildPrompt") : t("games.catandice.waiting", { name: P(n.turn) }) }), M && n.phase === "build" && V.length >= 2 && /* @__PURE__ */ g("button", {
								type: "button",
								className: "cd-trade",
								onClick: () => {
									v(null), b({
										kind: "trade",
										group: -1,
										die: V[0]
									});
								},
								children: [
									/* @__PURE__ */ h(q, {
										face: 5,
										size: 24
									}),
									/* @__PURE__ */ h(q, {
										face: 5,
										size: 24
									}),
									/* @__PURE__ */ h("span", { children: t("games.catandice.trade") })
								]
							})] })
						}),
						/* @__PURE__ */ h("div", {
							className: "cd-costs-desktop",
							children: /* @__PURE__ */ h(me, {})
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "cd-costs-toggle",
							onClick: () => S(!0),
							children: t("games.catandice.costs")
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							className: "cd-score-toggle",
							onClick: () => w(!0),
							children: t(n.island === 1 ? "games.catandice.scoreTrack" : "games.catandice.awards")
						}),
						/* @__PURE__ */ h(he, {
							island: n.island,
							sheet: A,
							rid: o,
							pub: n,
							name: P
						}),
						/* @__PURE__ */ h("div", {
							className: "cd-actions",
							children: M && n.phase === "roll" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
								type: "button",
								className: "cd-primary",
								disabled: n.rolls > 0 && n.held.every(Boolean),
								onClick: () => N({ type: "roll" }),
								children: t(n.rolls === 0 ? "games.catandice.roll" : "games.catandice.reroll")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								disabled: n.rolls === 0,
								onClick: () => N({ type: "stop" }),
								children: t("games.catandice.stop")
							})] }) : M && n.phase === "build" ? /* @__PURE__ */ h("button", {
								type: "button",
								className: "cd-primary",
								onClick: () => N({ type: "end" }),
								children: t("games.catandice.end")
							}) : /* @__PURE__ */ h("span", { children: n.phase === "done" ? t("games.catandice.result") : t("games.catandice.waiting", { name: P(n.turn) }) })
						})
					]
				})]
			}),
			x && /* @__PURE__ */ h("div", {
				className: "cd-dialog-backdrop",
				children: /* @__PURE__ */ g("div", {
					className: "cd-cost-dialog",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.catandice.costs"),
					children: [/* @__PURE__ */ h(me, {}), /* @__PURE__ */ h("button", {
						className: "cd-primary",
						onClick: () => S(!1),
						children: t("games.catandice.close")
					})]
				})
			}),
			C && /* @__PURE__ */ h("div", {
				className: "cd-dialog-backdrop",
				children: /* @__PURE__ */ g("div", {
					className: "cd-cost-dialog",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.catandice.scoreTrack"),
					children: [/* @__PURE__ */ h(he, {
						island: n.island,
						sheet: A,
						rid: o,
						pub: n,
						name: P
					}), /* @__PURE__ */ h("button", {
						className: "cd-primary",
						onClick: () => w(!1),
						children: t("games.catandice.close")
					})]
				})
			})
		]
	});
}
function ue({ face: e, index: t, rid: n, unrolled: r, held: i, chosen: a, enabled: c, onClick: l }) {
	let u = s(), { ref: d, hidden: f } = o(`die:${n}:${t}`);
	return /* @__PURE__ */ h("button", {
		ref: d,
		type: "button",
		className: `cd-die${i ? " cd-held" : ""}${a ? " cd-chosen" : ""}`,
		style: { visibility: f ? "hidden" : void 0 },
		disabled: !c,
		"aria-pressed": i || a,
		"aria-label": u("games.catandice.diceAria", {
			n: t + 1,
			resource: u(r ? "games.catandice.unrolledDie" : e === null ? "games.catandice.spentDie" : X[e])
		}) + (i ? ` · ${u("games.catandice.heldDie")}` : ""),
		onClick: l,
		children: /* @__PURE__ */ h(J, { face: e })
	});
}
function de({ site: e, onBuild: t, onCancel: n }) {
	let r = s();
	return /* @__PURE__ */ g("div", {
		className: "cd-preview",
		children: [
			/* @__PURE__ */ g("strong", { children: [
				r(Z[e.kind]),
				" · ",
				e.value
			] }),
			/* @__PURE__ */ h(pe, { kind: e.kind }),
			/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("button", {
				type: "button",
				className: "cd-primary",
				onClick: t,
				children: r("games.catandice.build")
			}), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: n,
				children: r("games.catandice.cancel")
			})] })
		]
	});
}
function fe({ island: e, sheet: t, rid: n, eligible: r, highlighted: i = r, jokers: a, selected: o, onChoose: u, fitKey: d, children: f }) {
	let p = s(), m = [...j[e].filter((e) => r.includes(e.id)).map((e) => ({
		key: e.id,
		rect: M(e)
	})), ...a.map((e) => {
		let [t, n] = k(e);
		return {
			key: `j:${e}`,
			rect: {
				x: t - 23,
				y: n - 23,
				w: 46,
				h: 46
			}
		};
	})];
	return /* @__PURE__ */ g(l, {
		sheetW: 900,
		sheetH: 850,
		eligible: m,
		onTapEligible: u,
		readOnly: !m.length,
		fitKey: d,
		clampToSheet: !0,
		highlight: "off",
		children: [
			/* @__PURE__ */ h(oe, { island: e }),
			Array.from({ length: e === 1 ? 6 : 7 }, (e, n) => {
				let [r, i] = k(n), o = D[n], s = t.used.includes(n), c = a.includes(n);
				return /* @__PURE__ */ g("g", {
					transform: `translate(${r} ${i})`,
					role: c ? "button" : void 0,
					tabIndex: c ? 0 : void 0,
					"aria-label": c ? p("games.catandice.jokerAria", { resource: p(o >= 0 ? X[o] : "games.catandice.anyResource") }) : void 0,
					onKeyDown: (e) => {
						c && (e.key === "Enter" || e.key === " ") && (e.preventDefault(), u(`j:${n}`));
					},
					children: [
						/* @__PURE__ */ h("circle", {
							r: "30",
							fill: s ? "#d6ceaa" : "#fff1bd",
							stroke: "#7d704a",
							strokeWidth: "2"
						}),
						o >= 0 ? /* @__PURE__ */ h("svg", {
							x: "-23",
							y: "-23",
							width: "46",
							height: "46",
							children: /* @__PURE__ */ h(q, {
								face: o,
								size: "100%"
							})
						}) : /* @__PURE__ */ h("text", {
							y: "14",
							textAnchor: "middle",
							fontSize: "43",
							fontWeight: "bold",
							fill: "#273a30",
							children: "?"
						}),
						s && /* @__PURE__ */ h("path", {
							d: "M-24,22L24,-22",
							stroke: "#194f79",
							strokeWidth: "6"
						}),
						c && /* @__PURE__ */ h("circle", {
							r: "33",
							fill: "none",
							stroke: "#fff",
							strokeWidth: "4",
							strokeDasharray: "9 6",
							children: /* @__PURE__ */ h("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: "-30",
								dur: ".7s",
								repeatCount: "indefinite"
							})
						})
					]
				}, n);
			}),
			j[e].map((a) => /* @__PURE__ */ h("g", {
				transform: `translate(${a.at[0]} ${a.at[1]})`,
				tabIndex: r.includes(a.id) ? 0 : void 0,
				role: r.includes(a.id) ? "button" : void 0,
				"aria-label": p("games.catandice.siteAria", {
					kind: p(Z[a.kind]),
					n: a.value
				}),
				onKeyDown: (e) => {
					r.includes(a.id) && (e.key === "Enter" || e.key === " ") && (e.preventDefault(), u(a.id));
				},
				children: /* @__PURE__ */ h(ce, {
					site: a,
					built: t.built.includes(a.id),
					eligible: i.includes(a.id),
					selected: o === a.id,
					island: e,
					anchorName: `site:${n}:${a.id}`
				})
			}, a.id)),
			j[e].map((e) => /* @__PURE__ */ h(c, {
				name: `site:${n}:${e.id}`,
				r: M(e)
			}, e.id)),
			f
		]
	});
}
function pe({ kind: e }) {
	return /* @__PURE__ */ h("span", {
		className: "cd-cost-icons",
		children: x[e].flatMap((e, t) => Array.from({ length: e }, (e, n) => /* @__PURE__ */ h(q, {
			face: t,
			size: "100%"
		}, `${t}:${n}`)))
	});
}
function me() {
	let e = s();
	return /* @__PURE__ */ g("div", {
		className: "cd-cost-table",
		children: [/* @__PURE__ */ h("h3", { children: e("games.catandice.costs") }), [
			"road",
			"knight",
			"settlement",
			"city"
		].map((t) => /* @__PURE__ */ g("div", {
			className: "cd-cost-row",
			children: [
				/* @__PURE__ */ h("svg", {
					viewBox: "-35 -40 70 75",
					"aria-hidden": "true",
					children: /* @__PURE__ */ h("path", {
						d: Y[t],
						fill: "#fff9df",
						stroke: "#29392f",
						strokeWidth: "4"
					})
				}),
				/* @__PURE__ */ h("span", { children: e(Z[t]) }),
				/* @__PURE__ */ h(pe, { kind: t })
			]
		}, t))]
	});
}
function he({ island: e, sheet: t, rid: n, pub: r, name: i }) {
	let a = s();
	return e === 1 ? /* @__PURE__ */ g("section", {
		className: "cd-score-paper",
		"aria-label": a("games.catandice.scoreTrack"),
		children: [/* @__PURE__ */ h("h3", { children: a("games.catandice.scoreTrack") }), /* @__PURE__ */ h("div", {
			className: "cd-turn-boxes",
			children: Array.from({ length: 15 }, (e, r) => /* @__PURE__ */ h(ge, {
				rid: n,
				index: r,
				current: r === t.turns.length,
				value: t.turns[r] ?? (r === t.turns.length && t.roundBuilt ? t.roundPoints : "")
			}, r))
		})]
	}) : /* @__PURE__ */ h("section", {
		className: "cd-awards",
		children: ["longest", "army"].map((e) => /* @__PURE__ */ g("div", { children: [
			/* @__PURE__ */ h("b", { children: a(e === "longest" ? "games.catandice.longest" : "games.catandice.army") }),
			/* @__PURE__ */ h("span", { children: r[e] ? a("games.catandice.award", { name: i(r[e]) }) : a("games.catandice.unclaimed") }),
			/* @__PURE__ */ h("small", { children: a(e === "longest" ? "games.catandice.roads" : "games.catandice.knights", { n: e === "longest" ? H(t, 2) : t.built.filter((e) => e.startsWith("k")).length }) })
		] }, e))
	});
}
function ge({ rid: e, index: t, current: n, value: r }) {
	let { ref: i } = o(`turn:${e}:${t}`);
	return /* @__PURE__ */ g("span", {
		ref: i,
		className: n ? "cd-current-box" : "",
		children: [/* @__PURE__ */ h("small", { children: t + 1 }), /* @__PURE__ */ h("b", { children: r })]
	});
}
//#endregion
//#region src/games/catandice/bot.ts
var _e = Object.freeze({
	road: 2.8,
	knight: 2,
	settlement: 1.4,
	city: 1.2,
	missing: 2.1,
	gold: .8
});
function ve(e, t, n) {
	let r = t.island === 1 ? e.value : e.kind === "road" ? .4 : e.kind === "knight" ? .8 : e.value * 4, i = t.island === 1 ? Math.max(0, 14 - t.sheets[t.turn].turns.length) / 14 : 1;
	return r + n[e.kind] * i;
}
function ye(e, t) {
	let n = [...e], r = t.map(() => !1);
	t.forEach((e, t) => {
		e !== null && n[e] > 0 && (r[t] = !0, n[e]--);
	});
	let i = n.reduce((e, t) => e + t, 0), a = t.flatMap((e, t) => e === 5 ? [t] : []).slice(0, i * 2);
	for (let e of a.slice(0, a.length - a.length % 2)) r[e] = !0;
	return r;
}
function be(e, t) {
	let n = x[t.kind], r = /* @__PURE__ */ new Set();
	function i(e, a, o) {
		if (B(e, t)) return o;
		let s = `${z(e)}:${a}`;
		if (r.has(s)) return null;
		r.add(s);
		let c = z(e), l = n.flatMap((e, t) => e > c[t] ? [t] : []);
		for (let t of l) {
			let r = e.flatMap((e, t) => e === 5 ? [t] : []);
			if (r.length >= 2) {
				let n = [...e];
				n[r[0]] = t, n[r[1]] = null;
				let s = i(n, a, [...o, {
					type: "trade",
					die: r[0],
					other: r[1],
					face: t
				}]);
				if (s) return s;
			}
			for (let r of a) if (D[r] < 0 || D[r] === t) {
				let s = e.findIndex((e) => e !== null && c[e] > n[e]);
				if (s < 0) continue;
				let l = [...e];
				l[s] = t;
				let u = i(l, a.filter((e) => e !== r), [...o, {
					type: "joker",
					group: r,
					die: s,
					face: t
				}]);
				if (u) return u;
			}
		}
		return null;
	}
	return i(e.dice, e.jokers, []);
}
function xe(e = {}) {
	let t = {
		..._e,
		...e
	};
	return (e, n) => {
		let r = e.public;
		if (r.turn !== n.rid || r.phase === "done") return null;
		if (r.rolls === 0) return { action: { type: "roll" } };
		let i = R(r.sheets[n.rid], r.island);
		if (r.phase === "roll") {
			if (!i.length) return { action: { type: "stop" } };
			let e = z(r.dice), a = (n) => {
				let i = x[n.kind], a = i.reduce((t, n, r) => t + Math.max(0, n - e[r]), 0);
				return ve(n, r, t) - t.missing * Math.max(0, a - Math.floor(e[5] / 2) * t.gold) - i.reduce((e, t) => e + t, 0) * .18;
			}, o = [...i].sort((e, t) => a(t) - a(e))[0];
			if (B(r.dice, o) || n.difficulty === "weak" && r.rolls === 2) return { action: { type: "stop" } };
			let s = ye(x[o.kind], r.dice), c = s.findIndex((e, t) => e !== r.held[t]);
			return c >= 0 ? { action: {
				type: "hold",
				die: c
			} } : { action: { type: s.every(Boolean) ? "stop" : "roll" } };
		}
		let a = i.flatMap((e) => {
			let n = be(r, e);
			return n ? [{
				site: e,
				plan: n,
				value: ve(e, r, t) - n.length * .15
			}] : [];
		});
		a.sort((e, t) => n.difficulty === "weak" ? e.site.value - t.site.value : t.value - e.value);
		let o = a[0];
		return { action: o ? o.plan[0] ?? {
			type: "build",
			site: o.site.id
		} : { type: "end" } };
	};
}
var Se = xe(), Ce = (e, t, n) => {
	if (e.type === "roll") return n("games.catandice.hintRoll");
	if (e.type === "hold") return n("games.catandice.hintHold", { n: e.die + 1 });
	if (e.type === "stop") return n("games.catandice.hintStop");
	if (e.type === "build") {
		let r = j[t.public.island].find((t) => t.id === e.site);
		return n("games.catandice.hintBuild", {
			kind: n(Z[r.kind]),
			n: r.value
		});
	}
	return e.type === "trade" ? n("games.catandice.hintTrade", { resource: n(X[e.face]) }) : e.type === "joker" ? n("games.catandice.hintJoker", {
		n: e.die + 1,
		resource: n(X[e.face])
	}) : n("games.catandice.hintEnd");
};
//#endregion
//#region src/games/catandice/fx.tsx
function $({ at: e, face: t, ms: n }) {
	let a = i(null);
	return r(() => {
		let e = a.current?.animate([
			{
				transform: "translateY(-30px) rotate(-95deg) scale(.7)",
				opacity: 0
			},
			{
				transform: "translateY(6px) rotate(8deg) scale(1.05)",
				opacity: 1,
				offset: .55
			},
			{
				transform: "translateY(0) rotate(0) scale(1)",
				opacity: 1
			}
		], {
			duration: n,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [n]), /* @__PURE__ */ h("div", {
		ref: a,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ h(J, { face: t })
	});
}
function we({ at: e }) {
	let t = i(null);
	return r(() => {
		let e = t.current?.animate([{ strokeDashoffset: 100 }, { strokeDashoffset: 0 }], {
			duration: 496,
			fill: "both"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ h("svg", {
		viewBox: "0 0 60 60",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ h("path", {
			ref: t,
			d: "M12,12L48,48M48,12L12,48",
			pathLength: "100",
			strokeDasharray: "100",
			fill: "none",
			stroke: "#194f79",
			strokeWidth: "6",
			strokeLinecap: "round"
		})
	});
}
var Te = {
	roll(e, t) {
		let n = e.data, r = [], i = [];
		for (let a of n.rolled) {
			let o = `die:${e.rid}:${a}`, s = t.anchor(o);
			s && (r.push(o), i.push(/* @__PURE__ */ h($, {
				at: s,
				face: n.dice[a],
				ms: t.queued ? 250 : 680
			}, a)));
		}
		return i.length ? {
			ms: t.queued ? 250 : 680,
			hide: t.queued ? void 0 : r,
			node: i
		} : null;
	},
	mark(e, t) {
		let n = e.data, r = t.anchor(`site:${e.rid}:${n.site}`);
		return r ? {
			ms: 620,
			hide: t.queued ? void 0 : [`site:${e.rid}:${n.site}`],
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(we, { at: r }), n.value > 0 && /* @__PURE__ */ h(_, {
				at: r,
				ms: 620,
				children: /* @__PURE__ */ g("span", {
					style: {
						color: "#fff5d4",
						background: "#194f79",
						padding: "2px 6px",
						borderRadius: 4
					},
					children: ["+", n.value]
				})
			})] })
		} : null;
	},
	convert(e, t) {
		let n = e.data, r = `die:${e.rid}:${n.die}`, i = t.anchor(r);
		return i ? {
			ms: 480,
			hide: t.queued ? void 0 : [r],
			node: /* @__PURE__ */ h($, {
				at: i,
				face: n.face,
				ms: 480
			})
		} : null;
	},
	record(e, t) {
		let n = e.data, r = t.anchor(`turn:${e.rid}:${n.index}`);
		return r ? {
			ms: 500,
			node: /* @__PURE__ */ h(v, {
				at: r,
				ms: 500
			})
		} : null;
	}
};
//#endregion
//#region src/games/catandice/game-over.tsx
function Ee(e) {
	let t = s(), n = e.public, [r, i] = a(!0), [o, c] = a(!1), l = (t) => e.members.find((e) => e.rid === t)?.name ?? t;
	return /* @__PURE__ */ g("div", {
		className: `cd-game cd-over${n.island === 2 ? " cd-island-two" : ""}`,
		children: [
			/* @__PURE__ */ h(Q, {
				public: n,
				members: e.members,
				myRid: e.myRid,
				send: () => void 0
			}),
			!r && /* @__PURE__ */ h("button", {
				type: "button",
				className: "cd-primary cd-restore-result",
				onClick: () => i(!0),
				children: t("games.catandice.resumeResult")
			}),
			r && /* @__PURE__ */ h("div", {
				className: "cd-over-overlay",
				children: /* @__PURE__ */ g("section", {
					className: "cd-over-paper",
					"aria-label": t("games.catandice.result"),
					children: [
						/* @__PURE__ */ h("h1", { children: t("games.catandice.result") }),
						e.hintCount !== void 0 && /* @__PURE__ */ h("p", { children: t("session.hint.usedCount", { n: e.hintCount }) }),
						/* @__PURE__ */ h("ol", {
							className: "cd-over-ranks",
							children: e.result.ranking.map((r, i) => {
								let a = n.sheets[r];
								return /* @__PURE__ */ g("li", { children: [
									/* @__PURE__ */ g("div", {
										className: "cd-rank-heading",
										children: [
											/* @__PURE__ */ h("span", { children: e.result.winner.includes(r) ? "♛" : i + 1 }),
											/* @__PURE__ */ g("b", { children: [l(r), r === e.myRid ? ` · ${t("lobby.you")}` : ""] }),
											/* @__PURE__ */ h("strong", { children: t("games.catandice.points", { n: n.scores[r] }) })
										]
									}),
									/* @__PURE__ */ g("div", {
										className: "cd-breakdown",
										children: [[
											"road",
											"knight",
											"settlement",
											"city"
										].map((e) => /* @__PURE__ */ g("span", { children: [
											/* @__PURE__ */ h("svg", {
												viewBox: "-35 -40 70 75",
												"aria-hidden": "true",
												children: /* @__PURE__ */ h("path", {
													d: Y[e],
													fill: "#fff9df",
													stroke: "#29392f",
													strokeWidth: "4"
												})
											}),
											/* @__PURE__ */ h("span", { children: t(Z[e]) }),
											/* @__PURE__ */ h("b", { children: j[n.island].filter((t) => t.kind === e && a.built.includes(t.id)).reduce((e, t) => e + t.value, 0) })
										] }, e)), n.island === 1 ? /* @__PURE__ */ g("span", { children: [
											t("games.catandice.failed"),
											" ",
											/* @__PURE__ */ h("b", { children: a.turns.filter((e) => e === -2).length * -2 })
										] }) : /* @__PURE__ */ g(m, { children: [n.longest === r && /* @__PURE__ */ g("span", { children: [
											t("games.catandice.longest"),
											" ",
											/* @__PURE__ */ h("b", { children: "2" })
										] }), n.army === r && /* @__PURE__ */ g("span", { children: [
											t("games.catandice.army"),
											" ",
											/* @__PURE__ */ h("b", { children: "2" })
										] })] })]
									}),
									(e.result.autopilot?.[r] ?? 0) > 0 && /* @__PURE__ */ h("p", {
										className: "cd-breakdown",
										children: t("session.autopilot.share", { n: Math.round(e.result.autopilot[r] * 100) })
									})
								] }, r);
							})
						}),
						/* @__PURE__ */ g("div", {
							className: "cd-over-actions",
							children: [
								/* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => i(!1),
									children: t("games.catandice.viewMap")
								}),
								e.onPlayAgain && /* @__PURE__ */ h("button", {
									type: "button",
									className: "cd-primary",
									onClick: e.onPlayAgain,
									children: t("session.result.playAgain")
								}),
								e.onBackToLobby && /* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => c(!0),
									children: t("session.result.backToLobby")
								})
							]
						}),
						!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ h("p", { children: t("session.result.waitHost") })
					]
				})
			}),
			o && /* @__PURE__ */ h("div", {
				className: "cd-confirm",
				children: /* @__PURE__ */ g("div", {
					role: "alertdialog",
					"aria-modal": "true",
					"aria-label": t("games.catandice.leaveTitle"),
					children: [
						/* @__PURE__ */ h("h2", { children: t("games.catandice.leaveTitle") }),
						/* @__PURE__ */ h("p", { children: t("games.catandice.leaveBody") }),
						/* @__PURE__ */ g("div", {
							className: "cd-over-actions",
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => c(!1),
								children: t("games.catandice.cancel")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								className: "cd-primary",
								onClick: e.onBackToLobby,
								children: t("session.result.backToLobby")
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/catandice/options.tsx
function De({ value: e, onChange: t }) {
	let n = s(), r = P.safeParse(e), i = r.success ? r.data : P.parse(void 0);
	return /* @__PURE__ */ h(b, {
		title: n("games.catandice.optIsland"),
		children: [1, 2].map((e) => /* @__PURE__ */ h(y, {
			name: "catandice-island",
			value: String(e),
			checked: i.island === e,
			label: n(e === 1 ? "games.catandice.islandOne" : "games.catandice.islandTwo"),
			hint: n(e === 1 ? "games.catandice.optOne" : "games.catandice.optTwo"),
			accent: N.accent,
			onChange: () => t({ island: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/catandice/entry.tsx
var Oe = {
	definition: ne,
	View: le,
	bot: Se,
	describe: Ce,
	fx: Te,
	OverView: Ee,
	Options: De,
	locales: {
		zh: {
			name: "卡坦岛：骰子版",
			desc: "掷出资源，在自己的卡坦岛图上修路、建造村庄与城市。两张岛图带来十五回合计分与十分竞速。",
			islandOne: "岛屿一",
			islandTwo: "岛屿二",
			optIsland: "岛图",
			optOne: "1–4 人，各进行 15 回合，比较总分。",
			optTwo: "2–4 人，最先达到 10 分者获胜。",
			resources: {
				brick: "砖",
				lumber: "木材",
				wool: "羊毛",
				grain: "谷物",
				ore: "矿石",
				gold: "金"
			},
			kinds: {
				road: "道路",
				settlement: "村庄",
				city: "城市",
				knight: "骑士"
			},
			round: "第 {{n}} / 15 回合",
			race: "目标 10 分",
			rolling: "已掷 {{n}} / 3 次",
			roll: "掷骰",
			reroll: "再次掷骰",
			stop: "开始建造",
			end: "结束回合",
			waiting: "等待{{name}}行动",
			buildPrompt: "选择要建造的位置",
			holdPrompt: "点击骰子保留或取消保留",
			current: "本轮 {{n}} 分",
			diceAria: "第 {{n}} 颗骰子：{{resource}}",
			spentDie: "已使用",
			unrolledDie: "尚未掷骰",
			heldDie: "已保留",
			selectDie: "选择一颗未使用的骰子",
			siteAria: "{{kind}}，{{n}} 分",
			build: "建造",
			cancel: "取消",
			costs: "建造费用",
			close: "关闭",
			scoreTrack: "回合记分",
			trade: "两金换一资源",
			joker: "使用资源百搭",
			jokerAria: "{{resource}}百搭",
			anyResource: "任意资源",
			chooseResource: "选择要换成的资源",
			longest: "最长道路",
			army: "最大骑士团",
			awards: "特殊分数",
			award: "{{name}} · 2 分",
			unclaimed: "尚未获得",
			roads: "{{n}} 段道路",
			knights: "{{n}} 名骑士",
			viewMap: "查看岛图",
			mapOf: "{{name}}的岛图",
			resetMap: "回全景",
			result: "本局成绩",
			resumeResult: "查看成绩",
			failed: "未建造回合",
			points: "{{n}} 分",
			leaveTitle: "返回大厅？",
			leaveBody: "本局已结束，返回大厅后将离开成绩与岛图回看。",
			errTurn: "现在不是你的回合。",
			errRoll: "现在不能掷骰或调整保留。",
			errPhase: "请先完成掷骰。",
			errTarget: "此处尚不能建造。",
			errCost: "可用资源不足。",
			errJoker: "此资源百搭尚不能使用。",
			hintRoll: "重新掷出未保留的骰子。",
			hintHold: "调整第 {{n}} 颗骰子的保留状态。",
			hintStop: "停止掷骰，开始建造。",
			hintBuild: "建造{{kind}}，获得 {{n}} 分。",
			hintTrade: "用两金换取{{resource}}。",
			hintJoker: "使用百搭，将第 {{n}} 颗骰子换成{{resource}}。",
			hintEnd: "结束本回合。",
			rules: "目标：\n岛屿一供 1–4 人游玩，每人进行 15 回合，总分最高者获胜，同分者共享胜利。岛屿二供 2–4 人游玩，最先达到 10 分者立即获胜。\n准备：\n每人持有独立岛图，紫色起始道路已经建成。岛屿一每回合使用六颗骰子。岛屿二的首个回合使用三颗骰子，之后每个连续回合增加一颗，达到六颗后保持六颗。\n回合流程：\n每回合最多掷骰三次。每次掷骰后，可保留任意骰子；此前保留的骰子也可取消保留后重掷。至少掷一次后可开始建造，进入建造后不能再掷骰。资源用完或决定停止时结束回合，未使用的资源不保留到下一回合。\n· 建造1段道路需要1份砖块和1份木材。\n· 招募1名骑士需要1份羊毛、1份谷物和1份矿石。\n· 建造1座村庄需要1份砖块、1份木材、1份羊毛和1份谷物。\n· 建造1座城市需要2份谷物和3份矿石。\n可在同回合建造多次。道路必须连接已建道路，村庄与城市必须与已建道路相邻。未建造的村庄或城市不会阻断修路。骑士不需要道路连接。岛屿一的村庄、城市、骑士分别按印刷点值从低到高建造；岛屿二可以任意顺序建造。\n金与资源百搭：\n完成掷骰后，可将两颗金骰换成一颗任意非金资源骰，另一颗金骰视为已使用。只剩一颗金骰时不能交易；资源足够时可多次交易。\n建造骑士后，其下方的资源百搭每局可以使用一次：选择一颗未使用的骰子，将其转为百搭所示资源。沙漠的问号可转为任意资源，包括金。岛屿一的第六名骑士解锁问号百搭；岛屿二每个沙漠必须建造两名骑士才解锁对应问号百搭。可在建造骑士的同回合使用百搭，同回合也可使用多个百搭。\n计分与结束：\n岛屿一：本回合新建建筑的印刷点值相加，记入一个回合格。\n· 每建造1段道路，获得1分。\n· 依次招募的6名骑士，分别获得1、2、3、4、5、6分。\n· 依次建造的6座村庄，分别获得3、4、5、7、9、11分。\n· 城市依次获得7、12、20、30分。\n本回合没有建造任何建筑时，记为−2分。每人完成15回合后比较总分。\n岛屿二：村庄每座 1 分，城市每座 2 分，道路与骑士本身不计分。\n· 第一位拥有至少五段连续道路的玩家获得最长道路及 2 分，免费起始路计入长度，分支不能相加；他人的连续道路严格更长时转移奖励。\n· 第一位建成至少三名骑士的玩家获得最大骑士团及 2 分，他人的骑士数量严格更多时转移奖励；使用百搭不减少骑士数量。\n平手时奖励保留在原持有者处。任何玩家达到 10 分时立即结束。"
		},
		en: {
			name: "Catan Dice Game",
			desc: "Roll resources and build roads, settlements and cities on your own Catan island. Play for fifteen turns or race to ten points.",
			islandOne: "Island One",
			islandTwo: "Island Two",
			optIsland: "Island",
			optOne: "1–4 players. Score the most points over 15 turns.",
			optTwo: "2–4 players. First to 10 points wins.",
			resources: {
				brick: "Brick",
				lumber: "Lumber",
				wool: "Wool",
				grain: "Grain",
				ore: "Ore",
				gold: "Gold"
			},
			kinds: {
				road: "Road",
				settlement: "Settlement",
				city: "City",
				knight: "Knight"
			},
			round: "Turn {{n}} / 15",
			race: "Goal: 10 points",
			rolling: "Roll {{n}} / 3",
			roll: "Roll dice",
			reroll: "Roll again",
			stop: "Start building",
			end: "End turn",
			waiting: "Waiting for {{name}}",
			buildPrompt: "Choose a building site",
			holdPrompt: "Click dice to keep or release them",
			current: "{{n}} points this turn",
			diceAria: "Die {{n}}: {{resource}}",
			spentDie: "Spent",
			unrolledDie: "Not rolled yet",
			heldDie: "Kept",
			selectDie: "Choose an unspent die",
			siteAria: "{{kind}}, {{n}} points",
			build: "Build",
			cancel: "Cancel",
			costs: "Building costs",
			close: "Close",
			scoreTrack: "Turn scores",
			trade: "Trade two gold",
			joker: "Use resource joker",
			jokerAria: "{{resource}} joker",
			anyResource: "Any resource",
			chooseResource: "Choose the new resource",
			longest: "Longest Road",
			army: "Largest Army",
			awards: "Special points",
			award: "{{name}} · 2 points",
			unclaimed: "Unclaimed",
			roads: "{{n}} roads",
			knights: "{{n}} knights",
			viewMap: "View island",
			mapOf: "{{name}}’s island",
			resetMap: "Fit island",
			result: "Final scores",
			resumeResult: "Show results",
			failed: "Turns without building",
			points: "{{n}} points",
			leaveTitle: "Return to lobby?",
			leaveBody: "This game is over. Returning to the lobby closes the scores and island review.",
			errTurn: "It is not your turn.",
			errRoll: "You cannot roll or change kept dice now.",
			errPhase: "Finish rolling first.",
			errTarget: "You cannot build here yet.",
			errCost: "Not enough available resources.",
			errJoker: "This resource joker is not available.",
			hintRoll: "Reroll the dice you have not kept.",
			hintHold: "Change whether die {{n}} is kept.",
			hintStop: "Stop rolling and start building.",
			hintBuild: "Build a {{kind}} for {{n}} points.",
			hintTrade: "Trade two gold for {{resource}}.",
			hintJoker: "Use a joker to turn die {{n}} into {{resource}}.",
			hintEnd: "End this turn.",
			rules: "Goal:\nIsland One is for 1–4 players. Each player takes 15 turns; the highest total wins, with tied players sharing victory. Island Two is for 2–4 players; the first player to reach 10 points wins immediately.\nPreparation:\nEach player has a separate island sheet. The purple starting road is already built. Island One uses six dice every turn. In Island Two the first turn uses three dice, then each consecutive turn adds one die until six dice are used for every turn.\nTaking a turn:\nRoll up to three times. After each roll, keep any dice you want. Previously kept dice can be released and rolled again. After at least one roll you may start building; you cannot roll again after doing so. End your turn when you finish building. Unspent resources are lost.\n· Building a road costs 1 brick and 1 lumber.\n· Building a knight costs 1 wool, 1 grain and 1 ore.\n· Building a settlement costs 1 brick, 1 lumber, 1 wool and 1 grain.\n· Building a city costs 2 grain and 3 ore.\nYou may build several times in one turn. Roads must connect to built roads; settlements and cities must be adjacent to a built road. Unbuilt settlements and cities do not block road construction. Knights do not need a road connection. In Island One, build each type of settlement, city and knight in ascending printed point order. In Island Two they may be built in any order.\nGold and resource jokers:\nAfter rolling, trade two gold dice for one die showing any non-gold resource; the other gold die is spent. One gold cannot be traded alone. You may make multiple trades if you have enough gold.\nAfter building a knight, its resource joker can be used once per game: choose an unspent die and turn it to the shown resource. A desert question mark allows any resource, including gold. Island One unlocks this joker with the sixth knight. Each desert in Island Two needs both of its knights before its question-mark joker is unlocked. You may use a joker on the turn you build its knight, and use several jokers in one turn.\nScoring and game end:\nIsland One: add the printed points of everything built this turn and record the total in one turn box.\n· Roads are worth 1 point each.\n· Knights are worth 1, 2, 3, 4, 5 and 6 points in building order.\n· Settlements are worth 3, 4, 5, 7, 9 and 11 points in building order.\n· Cities are worth 7, 12, 20 and 30 points in building order.\nA turn in which you build nothing scores −2 points. Compare totals after everyone finishes 15 turns.\nIsland Two: settlements are worth 1 point and cities 2. Roads and knights score no basic points.\n· The first player with at least five connected roads gains Longest Road and 2 points. Include the free starting road; do not add branches together. A strictly longer road takes the award.\n· The first player with at least three knights gains Largest Army and 2 points; a strictly larger army takes it. Using jokers does not reduce the army size.\nTies leave awards with their current holders. The game ends immediately when a player reaches 10 points."
		}
	}
};
//#endregion
export { Oe as default };
