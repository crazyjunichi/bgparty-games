import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useT as c } from "@bgparty/sdk/i18n";
import { IconLog as l } from "@bgparty/sdk/icons";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as v } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
var x = {
	castle: {
		id: "castle",
		nameKey: "games.toybattle.board.castle",
		nodes: [
			{
				id: "hqT",
				x: 50,
				y: 8,
				kind: "hq",
				side: 0
			},
			{
				id: "hqB",
				x: 50,
				y: 90,
				kind: "hq",
				side: 1
			},
			{
				id: "TL",
				x: 17,
				y: 10,
				kind: "base"
			},
			{
				id: "TR",
				x: 84,
				y: 10,
				kind: "base"
			},
			{
				id: "UL",
				x: 38,
				y: 27,
				kind: "base"
			},
			{
				id: "UR",
				x: 63,
				y: 27,
				kind: "base"
			},
			{
				id: "CL",
				x: 20,
				y: 49,
				kind: "base"
			},
			{
				id: "CC",
				x: 50,
				y: 49,
				kind: "base"
			},
			{
				id: "CR",
				x: 80,
				y: 49,
				kind: "base"
			},
			{
				id: "DL",
				x: 38,
				y: 75,
				kind: "base"
			},
			{
				id: "DR",
				x: 64,
				y: 75,
				kind: "base"
			},
			{
				id: "BL",
				x: 17,
				y: 89,
				kind: "base"
			},
			{
				id: "BR",
				x: 85,
				y: 89,
				kind: "base"
			},
			{
				id: "LT",
				x: 12,
				y: 37,
				kind: "special"
			},
			{
				id: "RT",
				x: 86,
				y: 37,
				kind: "special"
			},
			{
				id: "LB",
				x: 13,
				y: 67,
				kind: "special"
			},
			{
				id: "RB",
				x: 85,
				y: 67,
				kind: "special"
			}
		],
		edges: [
			["hqT", "TL"],
			["hqT", "TR"],
			["TL", "UL"],
			["TR", "UR"],
			["UL", "LT"],
			["UL", "CL"],
			["UL", "CC"],
			["UR", "RT"],
			["UR", "CC"],
			["UR", "CR"],
			["LT", "CL"],
			["RT", "CR"],
			["CL", "CC"],
			["CC", "CR"],
			["CL", "LB"],
			["CL", "DL"],
			["CC", "DL"],
			["CC", "DR"],
			["CR", "RB"],
			["CR", "DR"],
			["LB", "DL"],
			["RB", "DR"],
			["DL", "BL"],
			["DR", "BR"],
			["BL", "hqB"],
			["BR", "hqB"]
		],
		regions: [
			{
				around: [
					"TL",
					"TR",
					"UL",
					"UR",
					"CC"
				],
				medals: 3
			},
			{
				around: [
					"BL",
					"BR",
					"DL",
					"DR",
					"CC"
				],
				medals: 3
			},
			{
				around: [
					"UL",
					"LT",
					"CL"
				],
				medals: 1
			},
			{
				around: [
					"UR",
					"RT",
					"CR"
				],
				medals: 1
			},
			{
				around: [
					"DL",
					"LB",
					"CL"
				],
				medals: 1
			},
			{
				around: [
					"DR",
					"RB",
					"CR"
				],
				medals: 1
			},
			{
				around: [
					"UL",
					"CL",
					"CC"
				],
				medals: 1
			},
			{
				around: [
					"DL",
					"CL",
					"CC"
				],
				medals: 1
			},
			{
				around: [
					"UR",
					"CC",
					"CR"
				],
				medals: 1
			},
			{
				around: [
					"DR",
					"CC",
					"CR"
				],
				medals: 1
			}
		],
		objectives: [4, 7],
		specialIcon: "🗼"
	},
	clouds: {
		id: "clouds",
		nameKey: "games.toybattle.board.clouds",
		nodes: [
			{
				id: "hqT",
				x: 49.9,
				y: 8.2,
				kind: "hq",
				side: 0
			},
			{
				id: "hqB",
				x: 49.9,
				y: 95.5,
				kind: "hq",
				side: 1
			},
			{
				id: "L1",
				x: 9.7,
				y: 15,
				kind: "base"
			},
			{
				id: "L2",
				x: 10.4,
				y: 33.4,
				kind: "base"
			},
			{
				id: "L3",
				x: 9.7,
				y: 48.9,
				kind: "base"
			},
			{
				id: "L4",
				x: 11.3,
				y: 67.9,
				kind: "base"
			},
			{
				id: "L5",
				x: 11.3,
				y: 85.8,
				kind: "base"
			},
			{
				id: "R1",
				x: 89.4,
				y: 15,
				kind: "base"
			},
			{
				id: "R2",
				x: 88.5,
				y: 33.4,
				kind: "base"
			},
			{
				id: "R3",
				x: 87.8,
				y: 48.9,
				kind: "base"
			},
			{
				id: "R4",
				x: 87.8,
				y: 67.9,
				kind: "base"
			},
			{
				id: "R5",
				x: 87.8,
				y: 85.8,
				kind: "base"
			},
			{
				id: "C1",
				x: 49.9,
				y: 23.3,
				kind: "special"
			},
			{
				id: "C2",
				x: 49.9,
				y: 41.2,
				kind: "special"
			},
			{
				id: "C3",
				x: 49.9,
				y: 58.2,
				kind: "special"
			},
			{
				id: "C4",
				x: 49.9,
				y: 76.2,
				kind: "special"
			}
		],
		edges: [
			["hqT", "L1"],
			["hqT", "R1"],
			["hqB", "L5"],
			["hqB", "R5"],
			["L1", "L2"],
			["L2", "L3"],
			["L3", "L4"],
			["L4", "L5"],
			["R1", "R2"],
			["R2", "R3"],
			["R3", "R4"],
			["R4", "R5"],
			["C1", "C2"],
			["C2", "C3"],
			["C3", "C4"],
			["C1", "L1"],
			["C1", "L2"],
			["C1", "R1"],
			["C1", "R2"],
			["C2", "L2"],
			["C2", "L3"],
			["C2", "R2"],
			["C2", "R3"],
			["C3", "L3"],
			["C3", "L4"],
			["C3", "R3"],
			["C3", "R4"],
			["C4", "L4"],
			["C4", "L5"],
			["C4", "R4"],
			["C4", "R5"]
		],
		regions: [
			{
				around: [
					"L1",
					"R1",
					"C1"
				],
				medals: 1
			},
			{
				around: [
					"L5",
					"R5",
					"C4"
				],
				medals: 1
			},
			{
				around: [
					"L1",
					"C1",
					"L2"
				],
				medals: 1
			},
			{
				around: [
					"L2",
					"C2",
					"L3"
				],
				medals: 1
			},
			{
				around: [
					"L3",
					"C3",
					"L4"
				],
				medals: 1
			},
			{
				around: [
					"L4",
					"C4",
					"L5"
				],
				medals: 1
			},
			{
				around: [
					"R1",
					"C1",
					"R2"
				],
				medals: 1
			},
			{
				around: [
					"R2",
					"C2",
					"R3"
				],
				medals: 1
			},
			{
				around: [
					"R3",
					"C3",
					"R4"
				],
				medals: 1
			},
			{
				around: [
					"R4",
					"C4",
					"R5"
				],
				medals: 1
			},
			{
				around: [
					"C1",
					"L2",
					"C2"
				],
				medals: 1
			},
			{
				around: [
					"C2",
					"L3",
					"C3"
				],
				medals: 1
			},
			{
				around: [
					"C3",
					"L4",
					"C4"
				],
				medals: 1
			},
			{
				around: [
					"C1",
					"R2",
					"C2"
				],
				medals: 1
			},
			{
				around: [
					"C2",
					"R3",
					"C3"
				],
				medals: 1
			},
			{
				around: [
					"C3",
					"R4",
					"C4"
				],
				medals: 1
			}
		],
		objectives: [8, 8],
		specialIcon: "☁️"
	},
	volcano: {
		id: "volcano",
		nameKey: "games.toybattle.board.volcano",
		nodes: [
			{
				id: "hqT",
				x: 85.4,
				y: 9.2,
				kind: "hq",
				side: 0
			},
			{
				id: "hqB",
				x: 8.1,
				y: 91.2,
				kind: "hq",
				side: 1
			},
			{
				id: "A",
				x: 15.3,
				y: 8.7,
				kind: "base"
			},
			{
				id: "B",
				x: 51.6,
				y: 9.2,
				kind: "base"
			},
			{
				id: "C",
				x: 50,
				y: 29.1,
				kind: "base"
			},
			{
				id: "D",
				x: 82.2,
				y: 29.1,
				kind: "base"
			},
			{
				id: "E",
				x: 9.7,
				y: 48.9,
				kind: "base"
			},
			{
				id: "F",
				x: 48.3,
				y: 48.9,
				kind: "base"
			},
			{
				id: "G",
				x: 81.4,
				y: 48.9,
				kind: "base"
			},
			{
				id: "H",
				x: 14.5,
				y: 69.9,
				kind: "base"
			},
			{
				id: "I",
				x: 47.5,
				y: 68.4,
				kind: "base"
			},
			{
				id: "K",
				x: 46.7,
				y: 93.2,
				kind: "base"
			},
			{
				id: "L",
				x: 83.9,
				y: 91.7,
				kind: "base"
			},
			{
				id: "S1",
				x: 12.1,
				y: 26.2,
				kind: "special"
			},
			{
				id: "S2",
				x: 87.1,
				y: 66.9,
				kind: "special"
			}
		],
		edges: [
			["hqT", "B"],
			["hqT", "D"],
			["A", "B"],
			["A", "S1"],
			["S1", "C"],
			["S1", "E"],
			["B", "C"],
			["B", "D"],
			["C", "F"],
			["D", "G"],
			["E", "F"],
			["F", "G"],
			["E", "H"],
			["F", "I"],
			["G", "S2"],
			["S2", "I"],
			["S2", "L"],
			["H", "I"],
			["H", "K"],
			["H", "hqB"],
			["I", "K"],
			["hqB", "K"],
			["K", "L"]
		],
		regions: [
			{
				around: [
					"A",
					"B",
					"C",
					"S1"
				],
				medals: 2
			},
			{
				around: [
					"S1",
					"C",
					"F",
					"E"
				],
				medals: 2
			},
			{
				around: [
					"B",
					"D",
					"G",
					"F",
					"C"
				],
				medals: 3
			},
			{
				around: [
					"E",
					"F",
					"I",
					"H"
				],
				medals: 3
			},
			{
				around: [
					"F",
					"G",
					"S2",
					"I"
				],
				medals: 2
			},
			{
				around: [
					"I",
					"S2",
					"L",
					"K"
				],
				medals: 2
			}
		],
		objectives: [4, 7],
		specialIcon: "🌋"
	},
	cemetery: {
		id: "cemetery",
		nameKey: "games.toybattle.board.cemetery",
		nodes: [
			{
				id: "HQr",
				x: 84,
				y: 6.5,
				kind: "hq",
				side: 0
			},
			{
				id: "HQb",
				x: 18,
				y: 89.5,
				kind: "hq",
				side: 1
			},
			{
				id: "P1",
				x: 13.2,
				y: 23.3,
				kind: "special"
			},
			{
				id: "P2",
				x: 86.5,
				y: 26,
				kind: "special"
			},
			{
				id: "P3",
				x: 12.5,
				y: 76.5,
				kind: "special"
			},
			{
				id: "P4",
				x: 85,
				y: 77,
				kind: "special"
			},
			{
				id: "T1",
				x: 38.5,
				y: 6.7,
				kind: "base"
			},
			{
				id: "T2",
				x: 42.5,
				y: 6.7,
				kind: "base"
			},
			{
				id: "T3",
				x: 51,
				y: 6.5,
				kind: "base"
			},
			{
				id: "T4",
				x: 60.2,
				y: 6.5,
				kind: "base"
			},
			{
				id: "T5",
				x: 69.5,
				y: 6.5,
				kind: "base"
			},
			{
				id: "B1",
				x: 30.5,
				y: 93.5,
				kind: "base"
			},
			{
				id: "BB2",
				x: 39.8,
				y: 93.5,
				kind: "base"
			},
			{
				id: "B3",
				x: 49,
				y: 93.5,
				kind: "base"
			},
			{
				id: "B4",
				x: 57.5,
				y: 93.3,
				kind: "base"
			},
			{
				id: "B5",
				x: 61.5,
				y: 93.3,
				kind: "base"
			},
			{
				id: "A",
				x: 13,
				y: 16.8,
				kind: "base"
			},
			{
				id: "B",
				x: 27.2,
				y: 17.2,
				kind: "base"
			},
			{
				id: "C",
				x: 49.5,
				y: 15.5,
				kind: "base"
			},
			{
				id: "D",
				x: 58.5,
				y: 15.3,
				kind: "base"
			},
			{
				id: "E",
				x: 67.5,
				y: 14.5,
				kind: "base"
			},
			{
				id: "PD",
				x: 80.1,
				y: 20.4,
				kind: "base"
			},
			{
				id: "F",
				x: 37.8,
				y: 20,
				kind: "base"
			},
			{
				id: "G",
				x: 38.3,
				y: 26,
				kind: "base"
			},
			{
				id: "NB1",
				x: 60.5,
				y: 21.7,
				kind: "base"
			},
			{
				id: "NB2",
				x: 66.5,
				y: 20.9,
				kind: "base"
			},
			{
				id: "NB3p",
				x: 73.2,
				y: 21.2,
				kind: "base"
			},
			{
				id: "GB2",
				x: 64.5,
				y: 27.3,
				kind: "base"
			},
			{
				id: "X",
				x: 33.3,
				y: 72.5,
				kind: "base"
			},
			{
				id: "SB1",
				x: 26.5,
				y: 79,
				kind: "base"
			},
			{
				id: "SB2",
				x: 33,
				y: 79.3,
				kind: "base"
			},
			{
				id: "SB3",
				x: 39,
				y: 77.5,
				kind: "base"
			},
			{
				id: "NB4",
				x: 19,
				y: 80.3,
				kind: "base"
			},
			{
				id: "K1",
				x: 46,
				y: 32.6,
				kind: "base"
			},
			{
				id: "K2",
				x: 54.5,
				y: 31.5,
				kind: "base"
			},
			{
				id: "KP",
				x: 55.5,
				y: 39.2,
				kind: "base"
			},
			{
				id: "SP",
				x: 44.5,
				y: 40,
				kind: "base"
			},
			{
				id: "M",
				x: 32.7,
				y: 42.3,
				kind: "base"
			},
			{
				id: "M2",
				x: 67.3,
				y: 56.8,
				kind: "base"
			},
			{
				id: "O",
				x: 24,
				y: 50,
				kind: "base"
			},
			{
				id: "Q",
				x: 73.8,
				y: 50,
				kind: "base"
			},
			{
				id: "N",
				x: 73,
				y: 44,
				kind: "base"
			},
			{
				id: "NB",
				x: 26.3,
				y: 56,
				kind: "base"
			},
			{
				id: "CR",
				x: 44.3,
				y: 60,
				kind: "base"
			},
			{
				id: "NB2b",
				x: 55.5,
				y: 59.6,
				kind: "base"
			},
			{
				id: "H",
				x: 12.7,
				y: 31.3,
				kind: "base"
			},
			{
				id: "I",
				x: 19,
				y: 36,
				kind: "base"
			},
			{
				id: "J",
				x: 14.4,
				y: 40.4,
				kind: "base"
			},
			{
				id: "S",
				x: 17.3,
				y: 61.7,
				kind: "base"
			},
			{
				id: "W",
				x: 13.5,
				y: 70,
				kind: "base"
			},
			{
				id: "PD2",
				x: 81,
				y: 30,
				kind: "base"
			},
			{
				id: "TP",
				x: 78,
				y: 39,
				kind: "base"
			},
			{
				id: "V",
				x: 79,
				y: 63.5,
				kind: "base"
			},
			{
				id: "NB3",
				x: 85,
				y: 68.5,
				kind: "base"
			},
			{
				id: "U",
				x: 85,
				y: 59.5,
				kind: "base"
			},
			{
				id: "LP",
				x: 44,
				y: 68.3,
				kind: "base"
			},
			{
				id: "LP2",
				x: 50.7,
				y: 66.9,
				kind: "base"
			},
			{
				id: "RP",
				x: 61,
				y: 73.5,
				kind: "base"
			},
			{
				id: "RP2",
				x: 60.5,
				y: 79.3,
				kind: "base"
			},
			{
				id: "B2",
				x: 74,
				y: 82.5,
				kind: "base"
			},
			{
				id: "NB6",
				x: 85,
				y: 82.7,
				kind: "base"
			},
			{
				id: "D2",
				x: 29.9,
				y: 87.7,
				kind: "base"
			},
			{
				id: "E2",
				x: 40,
				y: 87.8,
				kind: "base"
			},
			{
				id: "F2",
				x: 49,
				y: 88.2,
				kind: "base"
			},
			{
				id: "J1",
				x: 32,
				y: 10.3,
				kind: "path"
			},
			{
				id: "J2",
				x: 32,
				y: 36.3,
				kind: "path"
			},
			{
				id: "J3",
				x: 65,
				y: 35.5,
				kind: "path"
			},
			{
				id: "J6",
				x: 32,
				y: 64,
				kind: "path"
			},
			{
				id: "J7",
				x: 68,
				y: 63,
				kind: "path"
			},
			{
				id: "J9",
				x: 68,
				y: 89.6,
				kind: "path"
			},
			{
				id: "J10",
				x: 52,
				y: 24,
				kind: "path"
			},
			{
				id: "J11",
				x: 47,
				y: 77,
				kind: "path"
			},
			{
				id: "JC",
				x: 50,
				y: 50,
				kind: "path"
			},
			{
				id: "JP2",
				x: 38.5,
				y: 36.5,
				kind: "path"
			},
			{
				id: "JP1",
				x: 61.5,
				y: 63,
				kind: "path"
			}
		],
		edges: [
			["J1", "T1"],
			["T1", "T2"],
			["T2", "C"],
			["C", "T3"],
			["T3", "D"],
			["D", "T4"],
			["T4", "E"],
			["E", "T5"],
			["T5", "HQr"],
			["F", "C"],
			["C", "D"],
			["D", "E"],
			["E", "PD"],
			["PD", "P2"],
			["J10", "NB1"],
			["NB1", "GB2"],
			["GB2", "NB2"],
			["NB2", "NB3p"],
			["NB3p", "P2"],
			["J1", "F"],
			["F", "G"],
			["G", "J2"],
			["F", "J10"],
			["P1", "H"],
			["H", "I"],
			["I", "J"],
			["J", "O"],
			["O", "NB"],
			["NB", "S"],
			["S", "W"],
			["W", "P3"],
			["P1", "A"],
			["P1", "B"],
			["B", "J1"],
			["O", "M"],
			["M", "J2"],
			["J2", "JP2"],
			["JP2", "K1"],
			["K1", "K2"],
			["K2", "KP"],
			["KP", "J3"],
			["JC", "SP"],
			["SP", "JP2"],
			["JC", "J3"],
			["JC", "NB2b"],
			["NB2b", "JP1"],
			["JC", "J6"],
			["J6", "CR"],
			["CR", "LP"],
			["LP", "LP2"],
			["LP2", "JP1"],
			["JP1", "J7"],
			["J7", "RP"],
			["RP", "RP2"],
			["RP2", "J9"],
			["J6", "X"],
			["P3", "SB1"],
			["SB1", "SB2"],
			["SB2", "X"],
			["X", "SB3"],
			["SB3", "J11"],
			["RP2", "J11"],
			["RP2", "F2"],
			["F2", "E2"],
			["E2", "D2"],
			["D2", "NB4"],
			["NB4", "P3"],
			["HQb", "B1"],
			["B1", "D2"],
			["D2", "BB2"],
			["BB2", "E2"],
			["E2", "B3"],
			["B3", "F2"],
			["F2", "B4"],
			["B4", "B5"],
			["B5", "J9"],
			["J3", "GB2"],
			["P2", "PD2"],
			["PD2", "TP"],
			["TP", "N"],
			["N", "Q"],
			["Q", "U"],
			["U", "V"],
			["V", "NB3"],
			["NB3", "P4"],
			["P4", "NB6"],
			["P4", "B2"],
			["B2", "J9"],
			["Q", "M2"],
			["M2", "J7"]
		],
		regions: [
			{
				around: [
					"F",
					"B",
					"P1",
					"H",
					"I",
					"J",
					"O",
					"M",
					"G"
				],
				medals: 1
			},
			{
				around: [
					"NB1",
					"F",
					"G",
					"K1",
					"K2",
					"KP",
					"GB2"
				],
				medals: 2
			},
			{
				around: [
					"K1",
					"SP",
					"KP",
					"K2"
				],
				medals: 1
			},
			{
				around: [
					"O",
					"NB",
					"S",
					"W",
					"P3",
					"SB1",
					"SB2",
					"X",
					"SP",
					"M"
				],
				medals: 3
			},
			{
				around: [
					"NB2b",
					"CR",
					"LP",
					"LP2"
				],
				medals: 1
			},
			{
				around: [
					"CR",
					"X",
					"SB3",
					"RP2",
					"RP",
					"LP2",
					"LP"
				],
				medals: 2
			},
			{
				around: [
					"NB2",
					"GB2",
					"NB2b",
					"M2",
					"Q",
					"N",
					"TP",
					"PD2",
					"P2",
					"NB3p"
				],
				medals: 3
			},
			{
				around: [
					"RP",
					"RP2",
					"B2",
					"P4",
					"NB3",
					"V",
					"U",
					"Q",
					"M2"
				],
				medals: 1
			}
		],
		objectives: [4, 7],
		specialIcon: "🎃"
	},
	caribbean: {
		id: "caribbean",
		nameKey: "games.toybattle.board.caribbean",
		nodes: [
			{
				id: "HQr",
				x: 50,
				y: 10,
				kind: "hq",
				side: 0
			},
			{
				id: "HQb1",
				x: 17,
				y: 92,
				kind: "hq",
				side: 1
			},
			{
				id: "HQb2",
				x: 85,
				y: 92,
				kind: "hq",
				side: 1
			},
			{
				id: "I1",
				x: 17,
				y: 13.5,
				kind: "base"
			},
			{
				id: "I2",
				x: 17,
				y: 33,
				kind: "base"
			},
			{
				id: "I3",
				x: 50,
				y: 30,
				kind: "base"
			},
			{
				id: "I4",
				x: 74.5,
				y: 21,
				kind: "base"
			},
			{
				id: "I5",
				x: 85,
				y: 45,
				kind: "base"
			},
			{
				id: "I6",
				x: 17,
				y: 57,
				kind: "base"
			},
			{
				id: "I7",
				x: 50,
				y: 56.5,
				kind: "base"
			},
			{
				id: "I8",
				x: 85,
				y: 70,
				kind: "base"
			},
			{
				id: "I9",
				x: 17,
				y: 76.5,
				kind: "base"
			},
			{
				id: "I10",
				x: 42,
				y: 77,
				kind: "base"
			},
			{
				id: "I11",
				x: 48,
				y: 91,
				kind: "base"
			},
			{
				id: "I12",
				x: 64,
				y: 82,
				kind: "base"
			}
		],
		edges: [
			["HQr", "I1"],
			["HQr", "I3"],
			["I1", "I2"],
			["I2", "I3"],
			["I2", "I6"],
			["I3", "I4"],
			["I3", "I7"],
			["I4", "I5"],
			["I4", "I12"],
			["I5", "I8"],
			["I6", "I7"],
			["I6", "I10"],
			["I7", "I12"],
			["I8", "I12"],
			["I8", "HQb2"],
			["I9", "I10"],
			["I9", "HQb1"],
			["I10", "I11"],
			["I11", "I12"],
			["I11", "HQb1"]
		],
		regions: [
			{
				around: [
					"I1",
					"I2",
					"I3"
				],
				medals: 1
			},
			{
				around: [
					"I2",
					"I3",
					"I6",
					"I7"
				],
				medals: 2
			},
			{
				around: [
					"I3",
					"I4",
					"I7",
					"I12"
				],
				medals: 2
			},
			{
				around: [
					"I4",
					"I5",
					"I8",
					"I12"
				],
				medals: 2
			},
			{
				around: [
					"I6",
					"I7",
					"I10",
					"I11",
					"I12"
				],
				medals: 3
			},
			{
				around: [
					"I9",
					"I10",
					"I11"
				],
				medals: 1
			}
		],
		objectives: [5, 5]
	},
	battlefield: {
		id: "battlefield",
		nameKey: "games.toybattle.board.battlefield",
		nodes: [
			{
				id: "HQr",
				x: 50,
				y: 10,
				kind: "hq",
				side: 0
			},
			{
				id: "HQb",
				x: 50,
				y: 90,
				kind: "hq",
				side: 1
			},
			{
				id: "TL",
				x: 22,
				y: 9.8,
				kind: "base"
			},
			{
				id: "TR",
				x: 79,
				y: 9.8,
				kind: "base"
			},
			{
				id: "UL",
				x: 21.5,
				y: 27.5,
				kind: "base"
			},
			{
				id: "UR",
				x: 79,
				y: 27.5,
				kind: "base"
			},
			{
				id: "ML",
				x: 37,
				y: 51,
				kind: "base"
			},
			{
				id: "MR",
				x: 63,
				y: 51,
				kind: "base"
			},
			{
				id: "LL",
				x: 21.5,
				y: 72.5,
				kind: "base"
			},
			{
				id: "LR",
				x: 79,
				y: 72.5,
				kind: "base"
			},
			{
				id: "BL",
				x: 22,
				y: 89.5,
				kind: "base"
			},
			{
				id: "BR",
				x: 79,
				y: 89.5,
				kind: "base"
			},
			{
				id: "CT",
				x: 50,
				y: 27,
				kind: "special"
			},
			{
				id: "CB",
				x: 50,
				y: 73.5,
				kind: "special"
			},
			{
				id: "LT",
				x: 11,
				y: 52.5,
				kind: "special"
			},
			{
				id: "RT",
				x: 89,
				y: 52.5,
				kind: "special"
			}
		],
		edges: [
			["HQr", "TL"],
			["HQr", "TR"],
			["TL", "UL"],
			["TR", "UR"],
			["UL", "CT"],
			["CT", "UR"],
			["UL", "LT"],
			["LT", "LL"],
			["UR", "RT"],
			["RT", "LR"],
			["CT", "ML"],
			["CT", "MR"],
			["UL", "ML"],
			["UR", "MR"],
			["ML", "LL"],
			["MR", "LR"],
			["ML", "CB"],
			["MR", "CB"],
			["LL", "CB"],
			["CB", "LR"],
			["LL", "BL"],
			["LR", "BR"],
			["BL", "HQb"],
			["BR", "HQb"]
		],
		regions: [
			{
				around: [
					"TL",
					"TR",
					"UR",
					"CT",
					"UL"
				],
				medals: 3
			},
			{
				around: [
					"UL",
					"CT",
					"ML"
				],
				medals: 1
			},
			{
				around: [
					"CT",
					"UR",
					"MR"
				],
				medals: 1
			},
			{
				around: [
					"UL",
					"ML",
					"LL",
					"LT"
				],
				medals: 2
			},
			{
				around: [
					"CT",
					"ML",
					"CB",
					"MR"
				],
				medals: 2
			},
			{
				around: [
					"UR",
					"RT",
					"LR",
					"MR"
				],
				medals: 2
			},
			{
				around: [
					"ML",
					"LL",
					"CB"
				],
				medals: 1
			},
			{
				around: [
					"MR",
					"CB",
					"LR"
				],
				medals: 1
			},
			{
				around: [
					"LL",
					"CB",
					"LR",
					"BR",
					"BL"
				],
				medals: 3
			}
		],
		objectives: [8, 8],
		specialIcon: "🎯"
	},
	pool: {
		id: "pool",
		nameKey: "games.toybattle.board.pool",
		nodes: [
			{
				id: "HQrL",
				x: 14,
				y: 12,
				kind: "hq",
				side: 0,
				limits: [5, 6]
			},
			{
				id: "HQrR",
				x: 86,
				y: 12,
				kind: "hq",
				side: 0
			},
			{
				id: "HQbL",
				x: 13,
				y: 89,
				kind: "hq",
				side: 1
			},
			{
				id: "HQbR",
				x: 88,
				y: 87,
				kind: "hq",
				side: 1,
				limits: [5, 6]
			},
			{
				id: "T1",
				x: 50,
				y: 12.5,
				kind: "base"
			},
			{
				id: "L1",
				x: 16,
				y: 27,
				kind: "base"
			},
			{
				id: "M1",
				x: 50,
				y: 29,
				kind: "base"
			},
			{
				id: "R1",
				x: 83,
				y: 42,
				kind: "base"
			},
			{
				id: "L2",
				x: 17,
				y: 58,
				kind: "base"
			},
			{
				id: "C",
				x: 50,
				y: 71.5,
				kind: "base"
			},
			{
				id: "R2",
				x: 84,
				y: 73,
				kind: "base"
			},
			{
				id: "B1",
				x: 50,
				y: 89,
				kind: "base"
			},
			{
				id: "F1",
				x: 83,
				y: 26,
				kind: "special",
				limits: [1, 2]
			},
			{
				id: "F2",
				x: 16,
				y: 44,
				kind: "special",
				limits: [
					3,
					4,
					5
				]
			},
			{
				id: "F3",
				x: 50,
				y: 51,
				kind: "special",
				limits: [5, 6]
			},
			{
				id: "F4",
				x: 84,
				y: 57,
				kind: "special",
				limits: [
					3,
					4,
					5
				]
			},
			{
				id: "F5",
				x: 17,
				y: 74,
				kind: "special",
				limits: [1, 2]
			}
		],
		edges: [
			["HQrL", "M1"],
			["T1", "HQrR"],
			["T1", "M1"],
			["L1", "M1"],
			["M1", "F1"],
			["HQrR", "F1"],
			["L1", "F2"],
			["F1", "R1"],
			["L1", "F3"],
			["M1", "F3"],
			["F2", "L2"],
			["F3", "R1"],
			["F3", "L2"],
			["F3", "C"],
			["F3", "R2"],
			["R1", "F4"],
			["F4", "R2"],
			["L2", "F5"],
			["F5", "B1"],
			["C", "B1"],
			["C", "R2"],
			["R2", "B1"],
			["F5", "HQbL"],
			["R2", "HQbR"],
			["HQbL", "B1"],
			["B1", "HQbR"]
		],
		regions: [
			{
				around: [
					"T1",
					"F1",
					"M1"
				],
				medals: 1
			},
			{
				around: [
					"L1",
					"M1",
					"F3"
				],
				medals: 1
			},
			{
				around: [
					"M1",
					"F1",
					"R1",
					"F3"
				],
				medals: 2
			},
			{
				around: [
					"L1",
					"F2",
					"L2",
					"F3"
				],
				medals: 2
			},
			{
				around: [
					"F3",
					"R1",
					"F4",
					"R2"
				],
				medals: 2
			},
			{
				around: [
					"L2",
					"F3",
					"C",
					"B1",
					"F5"
				],
				medals: 2
			},
			{
				around: [
					"F3",
					"C",
					"R2"
				],
				medals: 1
			},
			{
				around: ["F5", "B1"],
				medals: 1
			}
		],
		objectives: [9, 6],
		specialIcon: "🛟"
	},
	metalx: {
		id: "metalx",
		nameKey: "games.toybattle.board.metalx",
		nodes: [
			{
				id: "HQr",
				x: 86,
				y: 9,
				kind: "hq",
				side: 0
			},
			{
				id: "HQb",
				x: 10,
				y: 91,
				kind: "hq",
				side: 1
			},
			{
				id: "TL",
				x: 11,
				y: 6.5,
				kind: "base"
			},
			{
				id: "T2",
				x: 56,
				y: 17,
				kind: "base"
			},
			{
				id: "UL",
				x: 12,
				y: 29,
				kind: "base"
			},
			{
				id: "UR",
				x: 88,
				y: 29,
				kind: "base"
			},
			{
				id: "UC",
				x: 50,
				y: 34,
				kind: "base"
			},
			{
				id: "BC",
				x: 50,
				y: 64,
				kind: "base"
			},
			{
				id: "ML",
				x: 10,
				y: 69,
				kind: "base"
			},
			{
				id: "MR",
				x: 88,
				y: 69,
				kind: "base"
			},
			{
				id: "BD",
				x: 44,
				y: 83,
				kind: "base"
			},
			{
				id: "BR",
				x: 88,
				y: 90,
				kind: "base"
			},
			{
				id: "E1",
				x: 24,
				y: 49,
				kind: "special"
			},
			{
				id: "E2",
				x: 50,
				y: 49,
				kind: "special"
			},
			{
				id: "E3",
				x: 74,
				y: 49,
				kind: "special"
			}
		],
		edges: [
			["TL", "HQr"],
			["TL", "UL"],
			["TL", "UC"],
			["HQr", "T2"],
			["T2", "UC"],
			["HQr", "UR"],
			["UL", "UC"],
			["UC", "UR"],
			["UC", "E2"],
			["E1", "E2"],
			["E2", "E3"],
			["UL", "E1"],
			["UR", "E3"],
			["E1", "BC"],
			["E3", "BC"],
			["E2", "BC"],
			["BC", "ML"],
			["BC", "MR"],
			["BC", "BD"],
			["ML", "BD"],
			["MR", "BD"],
			["BD", "HQb"],
			["HQb", "BR"],
			["MR", "BR"],
			["E1", "ML"],
			["E3", "MR"]
		],
		regions: [
			{
				around: [
					"TL",
					"T2",
					"UC"
				],
				medals: 1
			},
			{
				around: [
					"TL",
					"UL",
					"UC"
				],
				medals: 1
			},
			{
				around: [
					"T2",
					"UC",
					"UR"
				],
				medals: 1
			},
			{
				around: [
					"UL",
					"UC",
					"E2",
					"E1"
				],
				medals: 2
			},
			{
				around: [
					"UC",
					"UR",
					"E3",
					"E2"
				],
				medals: 2
			},
			{
				around: [
					"E1",
					"E2",
					"BC"
				],
				medals: 1
			},
			{
				around: [
					"E2",
					"E3",
					"BC"
				],
				medals: 1
			},
			{
				around: [
					"E1",
					"BC",
					"ML"
				],
				medals: 1
			},
			{
				around: [
					"E3",
					"MR",
					"BC"
				],
				medals: 1
			},
			{
				around: [
					"ML",
					"BD",
					"BC"
				],
				medals: 1
			},
			{
				around: [
					"MR",
					"BC",
					"BD"
				],
				medals: 1
			},
			{
				around: [
					"BD",
					"BR",
					"MR"
				],
				medals: 1
			}
		],
		objectives: [4, 7],
		specialIcon: "⚡"
	}
}, S = Object.keys(x), C = {
	castle: "games.toybattle.baseFx.castle",
	clouds: "games.toybattle.baseFx.clouds",
	volcano: "games.toybattle.baseFx.volcano",
	cemetery: "games.toybattle.baseFx.cemetery",
	battlefield: "games.toybattle.baseFx.battlefield",
	pool: "games.toybattle.baseFx.pool",
	metalx: "games.toybattle.baseFx.metalx"
}, w = {
	id: "toybattle",
	tier: "beta",
	mechanics: ["area-control", "route-building"],
	interactionTags: [],
	nameKey: "games.toybattle.name",
	descKey: "games.toybattle.desc",
	rulesKey: "games.toybattle.rules",
	icon: "🧸",
	iconImg: "games/toybattle.webp",
	rulesUrl: {
		zh: "https://rules.bgparty.uuppi.com/toybattle/zh.pdf",
		en: "https://rules.bgparty.uuppi.com/toybattle/en.pdf"
	},
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#e63946",
	releasedAt: "2026-09-16",
	search: {
		py: "wan ju da zuo zhan",
		init: "wjdzz"
	},
	hotseat: "cover"
}, T = {
	skully: 1,
	capn: 2,
	jumbo: 3,
	hook: 4,
	xb42: 5,
	star: 6,
	roxy: 7
}, E = Object.keys({
	skully: "💀",
	capn: "🏴‍☠️",
	jumbo: "🐘",
	hook: "🪝",
	xb42: "✈️",
	star: "⭐",
	roxy: "🤖",
	kwak: "🦆"
}), D = {
	skully: "games.toybattle.troop.skully",
	capn: "games.toybattle.troop.capn",
	jumbo: "games.toybattle.troop.jumbo",
	hook: "games.toybattle.troop.hook",
	xb42: "games.toybattle.troop.xb42",
	star: "games.toybattle.troop.star",
	roxy: "games.toybattle.troop.roxy",
	kwak: "games.toybattle.troop.kwak"
}, ee = {
	skully: "games.toybattle.troopInfo.skully",
	capn: "games.toybattle.troopInfo.capn",
	jumbo: "games.toybattle.troopInfo.jumbo",
	hook: "games.toybattle.troopInfo.hook",
	xb42: "games.toybattle.troopInfo.xb42",
	star: "games.toybattle.troopInfo.star",
	roxy: "games.toybattle.troopInfo.roxy",
	kwak: "games.toybattle.troopInfo.kwak"
}, O = t.enum([
	"skully",
	"capn",
	"jumbo",
	"hook",
	"xb42",
	"star",
	"roxy",
	"kwak"
]), k = t.enum([
	"castle",
	"clouds",
	"volcano",
	"cemetery",
	"caribbean",
	"battlefield",
	"pool",
	"metalx"
]), A = t.union([t.literal(0), t.literal(1)]), j = t.object({
	o: A,
	k: O
}), M = t.discriminatedUnion("type", [
	t.object({ type: t.literal("draw") }),
	t.object({
		type: t.literal("place"),
		slot: t.int().min(0).max(7),
		target: t.string().min(1)
	}),
	t.object({
		type: t.literal("effect"),
		node: t.string().min(1).optional(),
		dest: t.string().min(1).optional(),
		card: t.int().min(0).optional(),
		skip: t.literal(!0).optional()
	})
]), N = t.object({
	board: t.union([k, t.literal("random")]).catch("random"),
	sideAssign: t.enum([
		"random",
		"hostRed",
		"hostBlue"
	]).catch("random")
}).default({
	board: "random",
	sideAssign: "random"
}), te = t.object({
	kind: t.enum([
		"capn",
		"jumbo",
		"castle",
		"volcano",
		"cemetery",
		"battlefield"
	]),
	side: A,
	at: t.string()
}), ne = t.object({
	kind: t.enum([
		"draw",
		"place",
		"capn",
		"jumbo",
		"recall",
		"move",
		"revive",
		"lock",
		"xb42",
		"region",
		"hqWin"
	]),
	side: A,
	troop: O.optional(),
	troop2: O.optional(),
	vs: A.optional(),
	n: t.int().optional()
}), P = t.object({
	board: k,
	seats: t.tuple([t.string(), t.string()]),
	objectives: t.tuple([t.int(), t.int()]),
	turn: A,
	slots: t.record(t.string(), t.array(j)),
	medals: t.tuple([t.int().nonnegative(), t.int().nonnegative()]),
	claimed: t.array(t.int().nonnegative()),
	reserves: t.tuple([t.int().nonnegative(), t.int().nonnegative()]),
	discards: t.tuple([t.array(O), t.array(O)]),
	racks: t.tuple([t.object({
		count: t.int().min(0).max(8),
		lockedIdx: t.array(t.int().min(0).max(7))
	}), t.object({
		count: t.int().min(0).max(8),
		lockedIdx: t.array(t.int().min(0).max(7))
	})]),
	pending: te.nullable(),
	winner: A.nullable(),
	endReason: t.enum([
		"hq",
		"medals",
		"stuck"
	]).nullable(),
	endedBy: A.nullable(),
	log: t.array(ne)
}), re = t.object({ rack: t.array(t.object({
	k: O,
	locked: t.boolean()
})) }), ie = [3, 4], F = {
	castle: "castle",
	clouds: "clouds",
	volcano: "volcano",
	cemetery: "cemetery",
	battlefield: "battlefield"
}, I = (e) => ({ code: e }), L = (e, t) => {
	e.log = [...e.log.slice(-49), t];
}, R = (e) => x[e.board], z = (e, t) => e.nodes.find((e) => e.id === t), B = /* @__PURE__ */ new WeakMap();
function V(e) {
	let t = B.get(e);
	if (!t) {
		t = new Map(e.nodes.map((e) => [e.id, []]));
		for (let [n, r] of e.edges) t.get(n).push(r), t.get(r).push(n);
		B.set(e, t);
	}
	return t;
}
var H = (e, t) => e.slots[t]?.[e.slots[t].length - 1], ae = (e, t) => {
	let n = e.players.indexOf(t);
	return n < 0 ? -1 : e.sides[n];
}, U = (e, t) => e.players[e.sides.indexOf(t)];
function W(e, t, n, r) {
	let i = V(t), a = /* @__PURE__ */ new Set([r]), o = [r];
	for (; o.length;) {
		let r = o.shift(), s = z(t, r);
		if (s.kind === "hq" && s.side === n) return !0;
		for (let s of i.get(r) ?? []) {
			if (a.has(s)) continue;
			let r = z(t, s);
			(r.kind === "path" || r.kind === "hq" && r.side === n || H(e, s)?.o === n) && (a.add(s), o.push(s));
		}
	}
	return !1;
}
function oe(e, t, n, r, i) {
	let a = z(t, i);
	if (!a || a.kind === "path") return I("games.toybattle.errBadTarget");
	if (a.limits && r !== "kwak" && !a.limits.includes(T[r])) return I("games.toybattle.errLimit");
	let o = e.slots[i];
	if (a.kind === "hq") return a.side === n ? I("games.toybattle.errBadTarget") : W(e, t, n, i) ? null : I("games.toybattle.errNotConnected");
	let s = o?.[o.length - 1];
	return s && s.o !== n && r !== "kwak" && s.k !== "kwak" && T[r] <= T[s.k] ? I("games.toybattle.errWeak") : r !== "hook" && !W(e, t, n, i) ? I("games.toybattle.errNotConnected") : null;
}
var G = (e, t) => 8 - e.racks[t].length;
function K(e, t, n) {
	let r = Math.min(n, e.reserves[t].length, G(e, t));
	for (let n = 0; n < r; n += 1) e.racks[t].push({
		k: e.reserves[t].pop(),
		locked: !1
	});
	return r;
}
function se(e, t, n) {
	let r = [];
	return t.regions.forEach((t, i) => {
		e.claimed.includes(i) || t.around.every((t) => H(e, t)?.o === n) && (e.claimed.push(i), e.medals[n] += t.medals, L(e, {
			kind: "region",
			side: n,
			n: t.medals
		}), r.push({
			kind: "region",
			rid: U(e, n),
			data: {
				region: i,
				medals: t.medals,
				total: e.medals[n]
			}
		}));
	}), e.medals[n] >= t.objectives[n] && (e.winner = n, e.endReason = "medals", e.endedBy = n, e.pending = null, e.baseFxQueue = []), r;
}
function ce(t, n, r, i, a) {
	let o = z(n, a);
	if (t.board === "metalx" && o.kind === "special") return [];
	let s = 1 - r, c = U(t, r);
	switch (i) {
		case "skully": {
			let e = K(t, r, 2);
			return e > 0 && L(t, {
				kind: "draw",
				side: r,
				n: e
			}), e > 0 ? [{
				kind: "draw",
				rid: c,
				data: { count: e }
			}] : [];
		}
		case "star": {
			let e = K(t, r, 1);
			return e > 0 && L(t, {
				kind: "draw",
				side: r,
				n: e
			}), e > 0 ? [{
				kind: "draw",
				rid: c,
				data: { count: e }
			}] : [];
		}
		case "capn": return t.racks[r].some((e) => !e.locked) && (t.pending = {
			kind: "capn",
			side: r,
			at: a
		}, L(t, {
			kind: "capn",
			side: r
		})), [];
		case "jumbo": return (V(n).get(a) ?? []).some((e) => H(t, e)?.o === s) && (t.pending = {
			kind: "jumbo",
			side: r,
			at: a
		}), [];
		case "xb42": {
			let n = t.racks[s];
			if (n.length === 0) return [];
			let i = e(t.seed, t.rngCursor, n.length);
			t.rngCursor += 1;
			let [a] = n.splice(i, 1);
			return t.discards[s].push(a.k), L(t, {
				kind: "xb42",
				side: r,
				troop: a.k,
				vs: s
			}), [{
				kind: "xb42",
				rid: c,
				data: {
					slot: i,
					troop: a.k,
					victim: U(t, s)
				}
			}];
		}
		default: return [];
	}
}
function le(e, t, n, r) {
	let i = F[e.board];
	if (!i) return;
	let a = 1 - r;
	switch (i) {
		case "clouds": {
			let t = K(e, r, 1);
			t > 0 && L(e, {
				kind: "draw",
				side: r,
				n: t
			});
			return;
		}
		case "castle":
			G(e, r) > 0 && Object.keys(e.slots).some((t) => t !== n && H(e, t)?.o === r) && (e.pending = {
				kind: "castle",
				side: r,
				at: n
			});
			return;
		case "volcano":
			(V(t).get(n) ?? []).some((t) => H(e, t)?.o === a) && (e.pending = {
				kind: "volcano",
				side: r,
				at: n
			});
			return;
		case "cemetery":
			e.discards[r].length > 0 && G(e, r) > 0 && (e.pending = {
				kind: "cemetery",
				side: r,
				at: n
			});
			return;
		case "battlefield":
			e.racks[a].length > 0 && (e.pending = {
				kind: "battlefield",
				side: r,
				at: n
			});
			return;
	}
}
function ue(e, t, n) {
	for (; !e.pending && e.winner === null;) {
		let r = e.baseFxQueue.shift();
		if (r === void 0) {
			n.push(...se(e, t, e.turn)), e.winner === null && de(e);
			return;
		}
		le(e, t, r.at, r.side);
	}
}
function de(e) {
	let t = R(e);
	for (let t of e.racks[e.turn]) t.locked = !1;
	let n = 1 - e.turn;
	e.turn = n;
	let r = e.reserves[n].length > 0 && G(e, n) > 0, i = e.racks[n].some((r, i) => !r.locked && t.nodes.some((r) => r.kind !== "path" && oe(e, t, n, e.racks[n][i].k, r.id) === null));
	if (!r && !i) {
		let t = 1 - n;
		e.endReason = "stuck", e.endedBy = n, e.winner = e.medals[n] === e.medals[t] ? t : e.medals[n] > e.medals[t] ? n : t;
	}
}
function fe(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function pe(t, n, r) {
	let i = {
		seed: r,
		rngCursor: 0
	}, a = t.board === "random" ? Object.keys(x)[e(r, i.rngCursor++, 8)] : t.board, o = t.sideAssign === "hostRed" ? 0 : t.sideAssign === "hostBlue" ? 1 : e(r, i.rngCursor++, 2), s = e(r, i.rngCursor++, 2), c = [...Object.keys(T), "kwak"].flatMap((e) => [
		e,
		e,
		e
	]), l = [fe(i, c), fe(i, c)], u = [[], []];
	for (let e of [0, 1]) {
		l[e].splice(0, 4);
		let t = ie[e === s ? 0 : 1];
		for (let n = 0; n < t; n += 1) u[e].push({
			k: l[e].pop(),
			locked: !1
		});
	}
	let d = {
		seed: r,
		rngCursor: i.rngCursor,
		players: [n[0], n[1]],
		sides: [o, 1 - o],
		board: a,
		starter: s,
		turn: s,
		reserves: l,
		racks: u,
		discards: [[], []],
		slots: {},
		medals: [0, 0],
		claimed: [],
		pending: null,
		baseFxQueue: [],
		log: [],
		winner: null,
		endReason: null,
		endedBy: null
	};
	return {
		state: d,
		fx: [0, 1].map((e) => ({
			kind: "deal",
			rid: U(d, e),
			data: { count: u[e].length },
			for: [U(d, e)],
			secret: { rack: u[e].map((e) => e.k) },
			...e > 0 ? { with: !0 } : {}
		}))
	};
}
function me(e, t, n) {
	let r = R(e), i = ae(e, n.by);
	if (i < 0) return I("games.toybattle.errNotYourTurn");
	if (e.winner !== null) return I("games.toybattle.errGameOver");
	if (t.type === "draw") {
		if (e.pending || i !== e.turn) return I("games.toybattle.errNotYourTurn");
		let t = Math.min(2, e.reserves[i].length, G(e, i));
		if (t === 0) return I("games.toybattle.errNoDraw");
		let a = structuredClone(e), o = K(a, i, t);
		L(a, {
			kind: "draw",
			side: i,
			n: o
		});
		let s = [{
			kind: "draw",
			rid: n.by,
			data: { count: o },
			for: [n.by],
			secret: { rack: a.racks[i].map((e) => e.k) }
		}];
		return ue(a, r, s), {
			state: a,
			fx: s
		};
	}
	if (t.type === "place") {
		if (i !== e.turn) return I("games.toybattle.errNotYourTurn");
		if (e.pending && (e.pending.kind !== "capn" || e.pending.side !== i)) return I("games.toybattle.errPending");
		let a = e.racks[i][t.slot];
		if (!a) return I("games.toybattle.errBadSlot");
		if (a.locked) return I("games.toybattle.errLocked");
		let o = oe(e, r, i, a.k, t.target);
		if (o) return o;
		let s = structuredClone(e);
		s.pending = null, s.racks[i].splice(t.slot, 1);
		let c = s.slots[t.target] ?? [], l = c.length > 0 && c[c.length - 1].o !== i ? c[c.length - 1] : null;
		c.push({
			o: i,
			k: a.k
		}), s.slots[t.target] = c, L(s, {
			kind: "place",
			side: i,
			troop: a.k,
			...l ? { troop2: l.k } : {}
		});
		let u = [{
			kind: "place",
			rid: n.by,
			data: {
				target: t.target,
				troop: a.k,
				covered: l?.k ?? null
			}
		}], d = z(r, t.target);
		return d.kind === "hq" ? (s.winner = i, s.endReason = "hq", s.endedBy = i, s.baseFxQueue = [], L(s, {
			kind: "hqWin",
			side: i
		}), u.push({
			kind: "hqWin",
			rid: n.by,
			data: { target: t.target }
		}), {
			state: s,
			fx: u
		}) : (u.push(...ce(s, r, i, a.k, t.target)), u.push(...se(s, r, i)), s.winner === null && (d.kind === "special" && F[s.board] && s.baseFxQueue.push({
			at: t.target,
			side: i
		}), ue(s, r, u)), {
			state: s,
			fx: u
		});
	}
	let a = e.pending;
	if (!a || a.side !== i) return I("games.toybattle.errPending");
	if (i !== e.turn) return I("games.toybattle.errNotYourTurn");
	let o = structuredClone(e), s = [], c = 1 - i;
	if (t.skip) return o.pending = null, ue(o, r, s), {
		state: o,
		fx: s
	};
	if (a.kind === "capn") return I("games.toybattle.errPending");
	switch (a.kind) {
		case "jumbo": {
			let e = t.node;
			if (!e || !(V(r).get(a.at) ?? []).includes(e)) return I("games.toybattle.errBadTarget");
			let l = o.slots[e], u = l?.[l.length - 1];
			if (!u || u.o !== c) return I("games.toybattle.errBadTarget");
			l.pop(), l.length === 0 && delete o.slots[e], o.discards[c].push(u.k), L(o, {
				kind: "jumbo",
				side: i,
				troop: u.k,
				vs: c
			}), s.push({
				kind: "discard",
				rid: n.by,
				data: {
					target: e,
					troop: u.k
				}
			});
			break;
		}
		case "castle": {
			let e = t.node;
			if (!e || e === a.at) return I("games.toybattle.errBadTarget");
			let r = o.slots[e], c = r?.[r.length - 1];
			if (!c || c.o !== i) return I("games.toybattle.errBadTarget");
			if (G(o, i) <= 0) return I("games.toybattle.errRackFull");
			r.pop(), r.length === 0 && delete o.slots[e], o.racks[i].push({
				k: c.k,
				locked: !1
			}), L(o, {
				kind: "recall",
				side: i,
				troop: c.k
			}), s.push({
				kind: "recall",
				rid: n.by,
				data: {
					target: e,
					troop: c.k
				}
			});
			break;
		}
		case "volcano": {
			let e = t.node, l = t.dest;
			if (!e || !l || !(V(r).get(a.at) ?? []).includes(e) || !(V(r).get(e) ?? []).includes(l)) return I("games.toybattle.errBadTarget");
			let u = z(r, l);
			if (!u || u.kind === "hq" || u.kind === "path") return I("games.toybattle.errBadTarget");
			let d = o.slots[e], f = d?.[d.length - 1];
			if (!f || f.o !== c) return I("games.toybattle.errBadTarget");
			let p = H(o, l);
			if (p && p.o !== c) return I("games.toybattle.errBadTarget");
			d.pop(), d.length === 0 && delete o.slots[e], (o.slots[l] ??= []).push(f), L(o, {
				kind: "move",
				side: i,
				troop: f.k,
				vs: c
			}), s.push({
				kind: "move",
				rid: n.by,
				data: {
					from: e,
					to: l,
					troop: f.k
				}
			});
			break;
		}
		case "cemetery": {
			let e = t.card;
			if (e === void 0 || e < 0 || e >= o.discards[i].length) return I("games.toybattle.errBadChoice");
			if (G(o, i) <= 0) return I("games.toybattle.errRackFull");
			let [r] = o.discards[i].splice(e, 1);
			o.racks[i].push({
				k: r,
				locked: !1
			}), L(o, {
				kind: "revive",
				side: i,
				troop: r
			}), s.push({
				kind: "revive",
				rid: n.by,
				data: { troop: r }
			});
			break;
		}
		case "battlefield": {
			let e = t.card, r = o.racks[c];
			if (e === void 0 || e < 0 || e >= r.length || r[e].locked) return I("games.toybattle.errBadChoice");
			r[e].locked = !0, L(o, {
				kind: "lock",
				side: i,
				vs: c
			}), s.push({
				kind: "lock",
				rid: n.by,
				data: {
					slot: e,
					victim: U(o, c)
				}
			});
			break;
		}
		default: return I("games.toybattle.errPending");
	}
	return o.pending = null, s.push(...se(o, r, i)), o.winner === null && ue(o, r, s), {
		state: o,
		fx: s
	};
}
function he(e, t) {
	let n = ae(e, t), r = R(e);
	return {
		public: {
			board: e.board,
			seats: [U(e, 0), U(e, 1)],
			objectives: r.objectives,
			turn: e.turn,
			slots: e.slots,
			medals: e.medals,
			claimed: e.claimed,
			reserves: [e.reserves[0].length, e.reserves[1].length],
			discards: e.discards,
			racks: [0, 1].map((t) => ({
				count: e.racks[t].length,
				lockedIdx: e.racks[t].flatMap((e, t) => e.locked ? [t] : [])
			})),
			pending: e.pending,
			winner: e.winner,
			endReason: e.endReason,
			endedBy: e.endedBy,
			log: e.log
		},
		private: { rack: n === -1 ? [] : e.racks[n].map((e) => ({
			k: e.k,
			locked: e.locked
		})) }
	};
}
function ge(e) {
	if (e.winner === null) return { phase: "play" };
	let t = U(e, e.winner), n = U(e, 1 - e.winner);
	return {
		phase: "done",
		winner: [t],
		ranking: [t, n],
		scores: {
			[t]: e.medals[e.winner],
			[n]: e.medals[1 - e.winner]
		}
	};
}
var _e = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: M,
		publicView: P,
		privateView: re,
		config: N
	},
	setup: pe,
	reduce: me,
	viewFor: he,
	status: ge
}, ve = ["#e63946", "#3a86ff"], ye = "./games/toybattle/troops.webp", q = 256, be = {
	skully: [0, 0],
	capn: [1, 0],
	jumbo: [2, 0],
	hook: [3, 0],
	xb42: [0, 1],
	star: [1, 1],
	roxy: [2, 1],
	kwak: [3, 1]
};
function xe({ kind: e, className: t = "" }) {
	let [n, r] = be[e];
	return /* @__PURE__ */ p("span", {
		"aria-hidden": "true",
		className: `toy-troop-art ${t}`,
		style: {
			backgroundImage: `url(${ye})`,
			backgroundPosition: `${n * 100 / 3}% ${r * 100}%`
		}
	});
}
function Se({ kind: e, x: t, y: n, size: r }) {
	let [i, a] = be[e];
	return /* @__PURE__ */ p("svg", {
		x: t,
		y: n,
		width: r,
		height: r,
		viewBox: `0 0 ${q} ${q}`,
		overflow: "hidden",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("image", {
			href: ye,
			x: -i * q,
			y: -a * q,
			width: q * 4,
			height: q * 2
		})
	});
}
//#endregion
//#region src/games/toybattle/board-view.tsx
var J = 150, Ce = {
	x: 50,
	y: 75,
	zoom: 1
}, we = {
	castle: {
		edge: "#775936",
		fill: "#edc67a",
		base: "#e9dfc5"
	},
	clouds: {
		edge: "#9576a8",
		fill: "#fff2f8",
		base: "#ffefab"
	},
	volcano: {
		edge: "#754b34",
		fill: "#dba56f",
		base: "#ae6b4f"
	},
	cemetery: {
		edge: "#416071",
		fill: "#9bb2b4",
		base: "#afc3c7"
	},
	caribbean: {
		edge: "#6e4a32",
		fill: "#b87943",
		base: "#93d8a5"
	},
	battlefield: {
		edge: "#6e5336",
		fill: "#bd8a54",
		base: "#d2b38a"
	},
	pool: {
		edge: "#368ab5",
		fill: "#f0fbff",
		base: "#f6fbf7"
	},
	metalx: {
		edge: "#324366",
		fill: "#80bdd5",
		base: "#b8dce6"
	}
};
function Te(e, t) {
	return t ? {
		x: 50,
		y: 126,
		zoom: 3.2
	} : e === "cemetery" ? {
		x: 30,
		y: 115,
		zoom: 2.2
	} : Ce;
}
function Ee(e) {
	let t = Math.max(1, Math.min(4.5, e.zoom));
	return {
		x: Math.max(-6, Math.min(106, e.x)),
		y: Math.max(-8, Math.min(158, e.y)),
		zoom: t
	};
}
function De(e) {
	return [e.x, e.y * J / 100];
}
function Oe({ b: e, pub: t, mySide: r, highlights: o, volcSrc: s, onTap: l }) {
	let u = c(), d = r === 0, f = i(null), h = i(null), g = i(/* @__PURE__ */ new Map()), _ = i(!1), v = i(0), y = i(null), b = i(Te(e.id, !1)), x = i(null), [S, C] = a(() => Te(e.id, !1)), [w, T] = a(!1), [E, D] = a({
		width: 330,
		height: 500
	}), ee = E.width / E.height > 1.1, O = (e) => {
		let t = Ee(e);
		b.current = t, C(t);
	};
	n(() => {
		let t = f.current;
		if (!t) return;
		let n = new ResizeObserver(([t]) => {
			let { width: n, height: r } = t.contentRect;
			D({
				width: n,
				height: r
			});
			let i = `${e.id}:${n / Math.max(1, r) > 1.1 ? "wide" : "tall"}`;
			x.current !== i && (x.current = i, O(Te(e.id, i.endsWith("wide"))));
		});
		return n.observe(t), () => n.disconnect();
	}, [e.id]);
	let k = E.width / Math.max(1, E.height), A = Math.max(J, 100 / k), j = A * k, M = j / S.zoom, N = A / S.zoom, te = S.x - M / 2, ne = S.y - N / 2, P = (e) => O({
		...b.current,
		zoom: b.current.zoom * e
	}), re = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), y.current = null, g.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY,
			startX: e.clientX,
			startY: e.clientY
		}), g.current.size === 1 && (_.current = !1), g.current.size === 2) {
			let [e, t] = [...g.current.values()];
			v.current = Math.hypot(e.x - t.x, e.y - t.y), _.current = !0;
		}
	}, ie = (e) => {
		let t = g.current.get(e.pointerId);
		if (t) {
			if (g.current.size === 1) {
				let n = e.pointerType === "touch" ? 18 : 8;
				Math.hypot(e.clientX - t.startX, e.clientY - t.startY) >= n && (_.current = !0);
				let r = e.clientX - t.x, i = e.clientY - t.y;
				if (_.current) {
					let e = b.current;
					O({
						...e,
						x: e.x - r * (j / e.zoom) / Math.max(1, E.width),
						y: e.y - i * (A / e.zoom) / Math.max(1, E.height)
					});
				}
			} else if (g.current.size === 2) {
				g.current.set(e.pointerId, {
					...t,
					x: e.clientX,
					y: e.clientY
				});
				let [n, r] = [...g.current.values()], i = Math.hypot(n.x - r.x, n.y - r.y);
				v.current > 0 && i > 0 && P(i / v.current), v.current = i, _.current = !0;
			}
			g.current.set(e.pointerId, {
				...t,
				x: e.clientX,
				y: e.clientY
			});
		}
	}, F = (e) => {
		let t = g.current.get(e.pointerId), n = e.pointerType === "touch" ? 18 : 8, r = !!t && g.current.size === 1 && !_.current && Math.hypot(e.clientX - t.startX, e.clientY - t.startY) < n && e.type === "pointerup";
		g.current.delete(e.pointerId), g.current.size < 2 && (v.current = 0), r && t && (y.current = {
			x: t.startX,
			y: t.startY
		});
	}, I = () => {
		let t = y.current;
		if (y.current = null, !t) return;
		let n = h.current?.getBoundingClientRect();
		if (!n) return;
		let r = b.current, i = j / r.zoom, a = A / r.zoom, s = r.x - i / 2 + (t.x - n.left) / n.width * i, c = r.y - a / 2 + (t.y - n.top) / n.height * a;
		d && (s = 100 - s, c = J - c);
		let u = n.width / i, f = e.id === "cemetery", p = 4 / u, m = null, g = Infinity;
		for (let t of e.nodes) {
			if (!o.has(t.id)) continue;
			let [e, n] = De(t), r = (t.kind === "hq" ? 5.7 : f ? 2.55 : 4.15) + 1.7, i = f ? 3 : 3.6, a = (c - n) * (d ? -1 : 1);
			if (Math.abs(s - e) <= (f ? 3.4 : 4) + p && a >= r - p && a <= r + i + p) {
				let n = Math.hypot(s - e, a - r - i / 2);
				n < g && (m = t.id, g = n);
			}
		}
		if (m) {
			l(m);
			return;
		}
		let _ = null, v = Infinity;
		for (let t of e.nodes) {
			let [e, n] = De(t), r = Math.hypot(e - s, n - c) * u, i = t.kind === "hq" ? 5.7 : f ? 2.55 : 4.15;
			r < (o.has(t.id) ? Math.max(24, (i + 2.1) * u + 3) : Math.max(24, 4.5 * u)) && r < v && (_ = t.id, v = r);
		}
		_ && l(_);
	}, L = (e) => {
		e.preventDefault(), P(e.deltaY < 0 ? 1.14 : 1 / 1.14);
	}, R = new Map(e.nodes.map((e) => [e.id, De(e)])), z = we[e.id], B = e.id === "cemetery";
	return /* @__PURE__ */ m("div", {
		className: "toy-board-shell frame",
		"aria-label": u(e.nameKey),
		children: [/* @__PURE__ */ p("div", {
			ref: f,
			className: "toy-board-viewport",
			onPointerDown: re,
			onPointerMove: ie,
			onPointerUp: F,
			onPointerCancel: F,
			onClick: I,
			onWheel: L,
			children: /* @__PURE__ */ p("svg", {
				ref: h,
				viewBox: `${te} ${ne} ${M} ${N}`,
				className: "toy-board-svg",
				role: "img",
				"aria-label": u(e.nameKey),
				children: /* @__PURE__ */ m("g", {
					transform: d ? `rotate(180 50 ${J / 2})` : void 0,
					children: [
						/* @__PURE__ */ p("rect", {
							width: 100,
							height: J,
							fill: z.base
						}),
						/* @__PURE__ */ p("image", {
							href: `./games/toybattle/board-${e.id}.webp`,
							width: 100,
							height: J,
							preserveAspectRatio: "none"
						}),
						e.edges.map(([e, t]) => {
							let n = R.get(e), r = R.get(t);
							return /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("line", {
								x1: n[0],
								y1: n[1],
								x2: r[0],
								y2: r[1],
								stroke: z.edge,
								strokeWidth: B ? 1.8 : 3.3,
								strokeLinecap: "round",
								opacity: .86
							}), /* @__PURE__ */ p("line", {
								x1: n[0],
								y1: n[1],
								x2: r[0],
								y2: r[1],
								stroke: z.fill,
								strokeWidth: B ? 1.1 : 2.4,
								strokeLinecap: "round",
								opacity: .94
							})] }, `${e}-${t}`);
						}),
						e.regions.map((e, n) => {
							let r = e.around.reduce((e, t) => e + R.get(t)[0], 0) / e.around.length, i = e.around.reduce((e, t) => e + R.get(t)[1], 0) / e.around.length, a = t.claimed.includes(n);
							return /* @__PURE__ */ m("g", {
								transform: d ? `rotate(180 ${r} ${i})` : void 0,
								pointerEvents: "none",
								children: [
									/* @__PURE__ */ p("circle", {
										cx: r,
										cy: i + .45,
										r: B ? 2.35 : 2.85,
										fill: "var(--color-ink)",
										opacity: .45
									}),
									/* @__PURE__ */ p("circle", {
										cx: r,
										cy: i,
										r: B ? 2.35 : 2.85,
										fill: a ? "var(--color-surface)" : "#d8952f",
										stroke: "var(--color-ink)",
										strokeWidth: .5,
										opacity: a ? .72 : 1
									}),
									!a && /* @__PURE__ */ p("circle", {
										cx: r,
										cy: i,
										r: B ? 1.78 : 2.15,
										fill: "#f8c448",
										stroke: "#fff3b0",
										strokeWidth: .28
									}),
									/* @__PURE__ */ p("text", {
										x: r,
										y: i + (B ? .68 : .85),
										textAnchor: "middle",
										fontSize: B ? 2.1 : 2.5,
										fontWeight: 800,
										fill: "var(--color-ink)",
										children: a ? "✓" : e.medals
									})
								]
							}, n);
						}),
						e.nodes.map((n) => /* @__PURE__ */ p(ke, {
							node: n,
							stack: t.slots[n.id],
							palette: z,
							dense: B,
							flip: d,
							castleTower: e.id === "castle" && n.kind === "special",
							specialIcon: e.specialIcon,
							highlighted: o.get(n.id),
							picked: s === n.id,
							pendingSource: t.pending?.at === n.id,
							onTap: () => l(n.id)
						}, n.id))
					]
				})
			})
		}), /* @__PURE__ */ m("div", {
			className: "toy-board-tools",
			children: [/* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => T((e) => !e),
				"aria-label": u("games.toybattle.boardTools"),
				"aria-expanded": w,
				className: "toy-board-tool toy-board-tool--trigger",
				children: "⌖"
			}), w && /* @__PURE__ */ m("div", {
				className: "toy-board-tools__panel",
				children: [
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => P(1.5),
						"aria-label": u("games.toybattle.zoomIn"),
						className: "toy-board-tool",
						children: "+"
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => P(1 / 1.5),
						"aria-label": u("games.toybattle.zoomOut"),
						className: "toy-board-tool",
						children: "−"
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => O(Te(e.id, ee)),
						"aria-label": u("games.toybattle.zoomReset"),
						className: "toy-board-tool",
						children: "⌂"
					})
				]
			})]
		})]
	});
}
function ke({ node: e, stack: t, palette: n, dense: r, flip: i, castleTower: a, specialIcon: o, highlighted: l, picked: u, pendingSource: d, onTap: h }) {
	let g = c(), { ref: _ } = s(`base:${e.id}`), [v, y] = De(e), b = t?.[t.length - 1], x = e.kind === "hq" ? 5.7 : r ? 2.55 : 4.15, S = e.side === void 0 ? void 0 : ve[e.side], C = i ? `rotate(180 ${v} ${y})` : void 0;
	return /* @__PURE__ */ p("g", {
		ref: _,
		role: "button",
		tabIndex: 0,
		"aria-label": e.id,
		onKeyDown: (e) => {
			(e.key === "Enter" || e.key === " ") && (e.preventDefault(), h());
		},
		children: e.kind === "path" ? /* @__PURE__ */ p("circle", {
			cx: v,
			cy: y,
			r: r ? 1.5 : 2,
			fill: n.fill,
			stroke: n.edge,
			strokeWidth: .6
		}) : /* @__PURE__ */ m(f, { children: [
			e.kind === "hq" ? /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("circle", {
					cx: v,
					cy: y + .65,
					r: x + .35,
					fill: "var(--color-ink)",
					opacity: .45
				}),
				/* @__PURE__ */ p("circle", {
					cx: v,
					cy: y,
					r: x + .35,
					fill: S,
					stroke: "var(--color-ink)",
					strokeWidth: .7
				}),
				/* @__PURE__ */ p("circle", {
					cx: v,
					cy: y,
					r: x - .35,
					fill: "none",
					stroke: "var(--color-surface)",
					strokeWidth: .85
				})
			] }) : a && !b ? /* @__PURE__ */ m("g", {
				transform: C,
				children: [
					/* @__PURE__ */ p("path", {
						d: `M ${v - x} ${y - x * .35} L ${v} ${y - x * 1.28} L ${v + x} ${y - x * .35} Z`,
						fill: "#bb6235",
						stroke: "var(--color-ink)",
						strokeWidth: .55
					}),
					/* @__PURE__ */ p("rect", {
						x: v - x,
						y: y - x * .35,
						width: x * 2,
						height: x * 1.55,
						rx: .75,
						fill: "#a9824d",
						stroke: "var(--color-ink)",
						strokeWidth: .65
					}),
					/* @__PURE__ */ p("rect", {
						x: v - 1.6,
						y: y - .25,
						width: 3.2,
						height: 3.2,
						rx: .2,
						fill: "#543a29"
					}),
					/* @__PURE__ */ p("text", {
						x: v,
						y: y + 2.2,
						textAnchor: "middle",
						fontSize: 2.45,
						fontWeight: 800,
						fill: "#f8c448",
						children: "★"
					})
				]
			}) : /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("rect", {
					x: v - x,
					y: y - x + .55,
					width: x * 2,
					height: x * 2,
					rx: 1.1,
					fill: "var(--color-ink)",
					opacity: .45
				}),
				/* @__PURE__ */ p("rect", {
					x: v - x,
					y: y - x,
					width: x * 2,
					height: x * 2,
					rx: 1.1,
					fill: n.base,
					stroke: "var(--color-ink)",
					strokeWidth: r ? .55 : .7
				}),
				/* @__PURE__ */ p("path", {
					d: `M ${v - x + .6} ${y} H ${v + x - .6} M ${v} ${y - x + .6} V ${y + x - .6}`,
					stroke: n.edge,
					strokeWidth: .32,
					opacity: .6
				})
			] }),
			e.kind === "special" && !b && !a && /* @__PURE__ */ m("g", {
				transform: C,
				children: [/* @__PURE__ */ p("circle", {
					cx: v,
					cy: y,
					r: x * .72,
					fill: "#d89045",
					stroke: "var(--color-ink)",
					strokeWidth: .35
				}), /* @__PURE__ */ p("text", {
					x: v,
					y: y + x * .26,
					textAnchor: "middle",
					fontSize: x * 1.03,
					children: o ?? "★"
				})]
			}),
			e.kind === "hq" && !b && /* @__PURE__ */ p("g", {
				transform: C,
				children: /* @__PURE__ */ p("text", {
					x: v,
					y: y + 1.4,
					textAnchor: "middle",
					fontSize: 3.7,
					fontWeight: 800,
					fill: "var(--color-surface)",
					children: g(e.side === 0 ? "games.toybattle.redSide" : "games.toybattle.blueSide")
				})
			}),
			b && /* @__PURE__ */ m("g", {
				transform: C,
				children: [
					/* @__PURE__ */ p("circle", {
						cx: v,
						cy: y,
						r: x + .25,
						fill: ve[b.o],
						stroke: "var(--color-ink)",
						strokeWidth: .7
					}),
					/* @__PURE__ */ p(Se, {
						kind: b.k,
						x: v - x + .3,
						y: y - x + .3,
						size: x * 2 - .6
					}),
					/* @__PURE__ */ p("circle", {
						cx: v + x * .7,
						cy: y + x * .7,
						r: r ? 1.35 : 1.65,
						fill: "var(--color-surface)",
						stroke: "var(--color-ink)",
						strokeWidth: .45
					}),
					/* @__PURE__ */ p("text", {
						x: v + x * .7,
						y: y + x * .7 + .53,
						textAnchor: "middle",
						fontSize: r ? 1.55 : 1.85,
						fontWeight: 800,
						fill: "var(--color-ink)",
						children: t.length > 1 ? t.length : b.k === "kwak" ? "★" : T[b.k]
					})
				]
			}),
			e.limits && /* @__PURE__ */ m("g", {
				transform: C,
				children: [/* @__PURE__ */ p("rect", {
					x: v - 3.4,
					y: y + x + .45,
					width: 6.8,
					height: 2.7,
					rx: .65,
					fill: "var(--color-surface)",
					stroke: "var(--color-ink)",
					strokeWidth: .3
				}), /* @__PURE__ */ p("text", {
					x: v,
					y: y + x + 2.35,
					textAnchor: "middle",
					fontSize: 1.85,
					fontWeight: 800,
					fill: "var(--color-ink)",
					children: e.limits.join("·")
				})]
			}),
			l && /* @__PURE__ */ m("g", {
				transform: C,
				pointerEvents: "none",
				children: [
					/* @__PURE__ */ p("circle", {
						cx: v,
						cy: y,
						r: x + 1.9,
						fill: "none",
						stroke: l === "place" ? "var(--color-ink)" : "#f5a04b",
						strokeWidth: 1.1
					}),
					l === "place" && /* @__PURE__ */ p("circle", {
						className: "toy-marching-ants",
						cx: v,
						cy: y,
						r: x + 1.9,
						fill: "none",
						stroke: "var(--color-surface)",
						strokeWidth: .65,
						strokeDasharray: "1.2 1.1"
					}),
					/* @__PURE__ */ p("circle", {
						cx: v,
						cy: y,
						r: x + .95,
						fill: "none",
						stroke: "var(--color-surface)",
						strokeWidth: .55
					}),
					/* @__PURE__ */ p("rect", {
						x: v - (r ? 3.4 : 4),
						y: y + x + 1.7,
						width: r ? 6.8 : 8,
						height: r ? 3 : 3.6,
						rx: .85,
						fill: "var(--color-surface)",
						stroke: l === "place" ? "#758b2c" : "#f5a04b",
						strokeWidth: .4
					}),
					/* @__PURE__ */ p("text", {
						x: v,
						y: y + x + (r ? 3.8 : 4.35),
						textAnchor: "middle",
						fontSize: r ? 1.95 : 2.45,
						fontWeight: 800,
						fill: "var(--color-ink)",
						children: g(l === "place" ? "games.toybattle.canPlace" : "games.toybattle.fxTarget")
					})
				]
			}),
			(u || d) && /* @__PURE__ */ p("circle", {
				cx: v,
				cy: y,
				r: x + 2.7,
				fill: "none",
				stroke: "#f5a04b",
				strokeWidth: .8,
				strokeDasharray: d ? "1.1 0.8" : void 0,
				pointerEvents: "none"
			})
		] })
	});
}
//#endregion
//#region src/games/toybattle/view-player.tsx
var Ae = {
	capn: "games.toybattle.pending.capn",
	jumbo: "games.toybattle.pending.jumbo",
	castle: "games.toybattle.pending.castle",
	volcano: "games.toybattle.pending.volcano",
	cemetery: "games.toybattle.pending.cemetery",
	battlefield: "games.toybattle.pending.battlefield"
}, je = {
	draw: "games.toybattle.log.draw",
	place: "games.toybattle.log.place",
	capn: "games.toybattle.log.capn",
	jumbo: "games.toybattle.log.jumbo",
	recall: "games.toybattle.log.recall",
	move: "games.toybattle.log.move",
	revive: "games.toybattle.log.revive",
	lock: "games.toybattle.log.lock",
	xb42: "games.toybattle.log.xb42",
	region: "games.toybattle.log.region",
	hqWin: "games.toybattle.log.hqWin"
};
function Me(e, t, n) {
	let r = { name: n(t.side) };
	return t.troop && (r.troop = e(D[t.troop])), t.troop2 && (r.troop2 = e(D[t.troop2])), t.vs !== void 0 && (r.name2 = n(t.vs)), t.n !== void 0 && (r.n = t.n), e(t.kind === "place" && t.troop2 ? "games.toybattle.log.placeCover" : je[t.kind], r);
}
function Ne(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Fe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var Pe = [];
function Fe({ pub: e, priv: t, members: n, myRid: i, send: o }) {
	let s = c(), l = x[e.board], h = +(e.seats.indexOf(i) === 1), g = 1 - h, _ = e.seats[g], v = n.find((e) => e.rid === _)?.name ?? _, y = n.find((e) => e.rid === i)?.name ?? i, b = e.turn === h && e.winner === null, S = e.pending && e.pending.side === h ? e.pending : null, [C, T] = a(null), [E, O] = a(null), [k, A] = a(null), [j, M] = a(!1), [N, te] = a(null), [ne, P] = a(!1), re = (t) => n.find((n) => n.rid === e.seats[t])?.name ?? "", ie = e.log[e.log.length - 1], F = ie ? Me(s, ie, re) : null, I = t?.rack ?? Pe, L = C === null ? null : I[C]?.k ?? null, R = L ?? k, { mode: z, highlights: B } = r(() => {
		let t = S && ["jumbo", "castle"].includes(S.kind) ? { kind: "fx-node" } : S?.kind === "volcano" ? E ? {
			kind: "fx-dest",
			src: E
		} : { kind: "fx-node" } : C !== null && b ? {
			kind: "place",
			slot: C
		} : null, n = /* @__PURE__ */ new Map();
		if (t?.kind === "place" && L) for (let t of l.nodes) t.kind !== "path" && oe({ slots: e.slots }, l, h, L, t.id) === null && n.set(t.id, "place");
		else if (t?.kind === "fx-node" && S) {
			let t = V(l);
			if (S.kind === "jumbo" || S.kind === "volcano") for (let r of t.get(S.at) ?? []) {
				let t = e.slots[r]?.[e.slots[r].length - 1];
				t && t.o === g && n.set(r, "fx");
			}
			else if (S.kind === "castle") for (let [t, r] of Object.entries(e.slots)) t !== S.at && r[r.length - 1].o === h && n.set(t, "fx");
		} else if (t?.kind === "fx-dest" && S?.kind === "volcano") for (let r of V(l).get(t.src) ?? []) {
			let t = l.nodes.find((e) => e.id === r);
			if (!t || t.kind === "hq" || t.kind === "path") continue;
			let i = e.slots[r]?.[e.slots[r].length - 1];
			(!i || i.o === g) && n.set(r, "fx");
		}
		return {
			mode: t,
			highlights: n
		};
	}, [
		S,
		E,
		C,
		L,
		b,
		l,
		e.slots,
		h,
		g
	]), H = (e) => {
		te(e), M(!0);
	}, ae = (e) => {
		z && B.has(e) && (z.kind === "place" ? (o({
			type: "place",
			slot: z.slot,
			target: e
		}), T(null), A(null)) : z.kind === "fx-node" ? S?.kind === "volcano" ? O(e) : o({
			type: "effect",
			node: e
		}) : (o({
			type: "effect",
			node: z.src,
			dest: e
		}), O(null)), M(!1));
	}, U = !N || !z || !B.has(N) ? null : {
		label: z.kind === "place" ? s("games.toybattle.sheet.actPlace", { name: L ? s(D[L]) : "" }) : z.kind === "fx-dest" ? s("games.toybattle.sheet.actVolcDest") : S?.kind === "jumbo" ? s("games.toybattle.sheet.actJumbo") : S?.kind === "castle" ? s("games.toybattle.sheet.actCastle") : s("games.toybattle.sheet.actVolcSrc"),
		run: () => ae(N)
	}, W, G, K;
	return e.winner === null ? S ? (W = "warn", G = S.kind === "volcano" && E ? s("games.toybattle.pending.volcanoDest") : s(Ae[S.kind]), K = s("games.toybattle.pendingMay")) : b ? (W = "accent", G = s(L ? "games.toybattle.promptPlace" : "games.toybattle.promptTurn")) : (W = "info", G = s("games.toybattle.waitTurn", { name: n.find((t) => t.rid === e.seats[e.turn])?.name ?? "" })) : (W = "done", G = s("games.toybattle.ended")), /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("div", {
			className: "toy-battle-screen",
			style: { "--toy-accent": w.accent },
			children: /* @__PURE__ */ p(u, {
				adaptive: !0,
				className: "toy-layout",
				scroll: !1,
				banner: /* @__PURE__ */ m("div", {
					className: "toy-header",
					children: [/* @__PURE__ */ p("div", {
						className: "toy-phase",
						children: /* @__PURE__ */ p(d, {
							tone: W,
							text: G,
							sub: K,
							chip: s(l.nameKey),
							accent: w.accent
						})
					}), /* @__PURE__ */ p(Ie, {
						rid: _,
						side: g,
						label: v,
						relation: "opponent",
						medals: e.medals[g],
						objective: e.objectives[g],
						reserves: e.reserves[g],
						onOpenLog: () => P(!0),
						logText: F ?? s("games.toybattle.logEmpty")
					})]
				}),
				actionsHeight: "toy-actions-slot h-[172px] short:h-[94px]",
				actions: /* @__PURE__ */ m("div", {
					className: "toy-actions",
					children: [/* @__PURE__ */ p(Ie, {
						rid: i,
						side: h,
						label: y,
						relation: "you",
						medals: e.medals[h],
						objective: e.objectives[h],
						reserves: e.reserves[h]
					}), /* @__PURE__ */ m("div", {
						className: "toy-actions__rack",
						children: [/* @__PURE__ */ m("div", {
							className: "toy-actions__rack-title",
							children: [/* @__PURE__ */ m("strong", { children: [
								s("games.toybattle.rackTitle"),
								" ",
								/* @__PURE__ */ m("span", { children: [
									I.length,
									"/",
									8
								] })
							] }), R && /* @__PURE__ */ p("span", {
								className: "toy-actions__rack-hint",
								title: s(ee[R]),
								children: s(ee[R])
							})]
						}), /* @__PURE__ */ m("div", {
							className: "toy-actions__rack-row",
							children: [/* @__PURE__ */ p("div", {
								className: "toy-actions__cards",
								children: /* @__PURE__ */ m("div", {
									className: "toy-actions__cards-inner",
									children: [I.map((e, t) => {
										let n = b && !e.locked && (!S || S.kind === "capn");
										return /* @__PURE__ */ p(Be, {
											kind: e.k,
											locked: e.locked,
											selected: C === t,
											inactive: !n,
											onClick: () => {
												n ? (T(C === t ? null : t), A(null)) : A(k === e.k ? null : e.k);
											}
										}, t);
									}), I.length === 0 && /* @__PURE__ */ p("span", {
										className: "px-2 py-3 text-xs font-bold opacity-60",
										children: s("games.toybattle.rackEmpty")
									})]
								})
							}), /* @__PURE__ */ p(Ve, {
								disabled: !b || !!S || e.reserves[h] === 0 || I.length >= 8,
								count: Math.min(2, e.reserves[h], 8 - I.length),
								onClick: () => {
									o({ type: "draw" }), T(null), A(null);
								}
							})]
						})]
					})]
				}),
				overlay: /* @__PURE__ */ p(f, { children: S && /* @__PURE__ */ p("div", {
					className: "toy-pending",
					children: /* @__PURE__ */ p(ze, {
						pending: S,
						pub: e,
						mySide: h,
						oppSide: g,
						volcSrc: E,
						onPick: (e) => o({
							type: "effect",
							card: e
						}),
						onSkip: () => {
							o({
								type: "effect",
								skip: !0
							}), O(null);
						},
						onCancelVolc: () => O(null)
					})
				}) }),
				children: /* @__PURE__ */ p(Oe, {
					b: l,
					pub: e,
					mySide: h,
					highlights: B,
					volcSrc: E,
					onTap: H
				})
			})
		}),
		/* @__PURE__ */ p(Le, {
			open: ne,
			log: e.log,
			nameOf: re,
			onClose: () => P(!1)
		}),
		/* @__PURE__ */ p(Re, {
			open: j,
			nodeId: N,
			b: l,
			pub: e,
			members: n,
			action: U,
			onClose: () => M(!1)
		})
	] });
}
function Ie({ rid: e, side: t, label: n, relation: r, medals: i, objective: a, reserves: o, onOpenLog: u, logText: d }) {
	let f = c(), { ref: h } = s(`seat:${e}`);
	return /* @__PURE__ */ m("div", {
		ref: h,
		className: "toy-seat",
		children: [
			/* @__PURE__ */ p("span", {
				className: "toy-seat__flag",
				style: { background: ve[t] },
				children: f(t === 0 ? "games.toybattle.redSide" : "games.toybattle.blueSide")
			}),
			/* @__PURE__ */ m("span", {
				className: "toy-seat__name",
				children: [
					f(r === "you" ? "games.toybattle.youLabel" : "games.toybattle.opponentLabel"),
					" · ",
					n
				]
			}),
			/* @__PURE__ */ m("span", {
				className: "toy-seat__stats",
				children: [
					f("games.toybattle.medalShort"),
					" ",
					i,
					"/",
					a,
					" \xA0 ",
					f("games.toybattle.reserveShort"),
					" ",
					o
				]
			}),
			u && /* @__PURE__ */ p("button", {
				type: "button",
				onClick: u,
				"aria-label": f("games.toybattle.logAria"),
				title: d,
				className: "toy-seat__log",
				children: /* @__PURE__ */ p(l, { className: "size-4" })
			})
		]
	});
}
function Le({ open: e, log: t, nameOf: n, onClose: r }) {
	let i = c();
	return /* @__PURE__ */ m(o, {
		open: e,
		onClose: r,
		label: i("games.toybattle.logAria"),
		children: [/* @__PURE__ */ p("p", {
			className: "font-display text-lg font-extrabold",
			children: i("games.toybattle.logAria")
		}), t.length === 0 ? /* @__PURE__ */ p("p", {
			className: "text-xs font-bold opacity-60",
			children: i("games.toybattle.logEmpty")
		}) : /* @__PURE__ */ p("ul", {
			className: "flex flex-col gap-1",
			children: [...t].reverse().map((e, r) => /* @__PURE__ */ m("li", {
				className: "flex items-center gap-2 text-sm font-bold",
				children: [/* @__PURE__ */ p("span", {
					className: "size-3 flex-none rounded-full border-2 border-ink",
					style: { background: ve[e.side] }
				}), /* @__PURE__ */ p("span", {
					className: "min-w-0",
					children: Me(i, e, n)
				})]
			}, t.length - 1 - r))
		})]
	});
}
function Re({ open: e, nodeId: t, b: n, pub: r, members: i, action: a, onClose: s }) {
	let l = c(), u = t ? n.nodes.find((e) => e.id === t) : void 0, d = (e) => i.find((t) => t.rid === r.seats[e])?.name ?? "", f = (t ? r.slots[t] : void 0) ?? [], h = u?.kind === "special" ? C[n.id] : void 0, g = u ? u.kind === "hq" ? `🏰 ${l("games.toybattle.sheet.hqTitle", { name: d(u.side ?? 0) })}` : u.kind === "special" ? `${n.specialIcon ?? "✨"} ${l(n.nameKey)}` : u.kind === "path" ? l("games.toybattle.sheet.path") : l("games.toybattle.sheet.base") : "", _ = u ? u.kind === "hq" ? l("games.toybattle.sheet.hqDesc") : u.kind === "path" ? l("games.toybattle.sheet.pathDesc") : h ? l(h) : null : null;
	return /* @__PURE__ */ m(o, {
		open: e,
		onClose: s,
		label: g,
		children: [
			/* @__PURE__ */ p("p", {
				className: "font-display text-lg font-extrabold",
				children: g
			}),
			u?.kind === "special" && /* @__PURE__ */ p("p", {
				className: "section-label",
				children: l("games.toybattle.sheet.special")
			}),
			_ && /* @__PURE__ */ p("p", {
				className: "text-sm leading-relaxed",
				children: _
			}),
			u?.limits && /* @__PURE__ */ p("p", {
				className: "text-sm font-bold",
				children: l("games.toybattle.sheet.limits", { list: u.limits.join("·") })
			}),
			u && u.kind !== "path" && (f.length > 0 ? /* @__PURE__ */ p("ul", {
				className: "flex flex-col gap-1",
				children: [...f].reverse().map((e, t) => /* @__PURE__ */ m("li", {
					className: "flex items-center gap-2 text-sm font-bold",
					children: [
						/* @__PURE__ */ p("span", {
							className: "size-3 flex-none rounded-full border-2 border-ink",
							style: { background: ve[e.o] }
						}),
						/* @__PURE__ */ p("span", {
							className: "min-w-0 truncate",
							children: d(e.o)
						}),
						/* @__PURE__ */ p(xe, {
							kind: e.k,
							className: "size-8 flex-none"
						}),
						/* @__PURE__ */ p("span", { children: l(D[e.k]) }),
						/* @__PURE__ */ p("span", {
							className: "ml-auto flex-none text-xs opacity-60",
							children: l(t === 0 ? "games.toybattle.sheet.occTop" : "games.toybattle.sheet.occCovered")
						})
					]
				}, t))
			}) : /* @__PURE__ */ p("p", {
				className: "text-xs font-bold opacity-60",
				children: l("games.toybattle.sheet.occEmpty")
			})),
			a && /* @__PURE__ */ p("button", {
				type: "button",
				onClick: a.run,
				className: "btn-base min-h-12 w-full text-sm font-extrabold text-white",
				style: { background: w.accent },
				children: a.label
			})
		]
	});
}
function ze({ pending: e, pub: t, mySide: n, oppSide: r, volcSrc: i, onPick: a, onSkip: o, onCancelVolc: s }) {
	let l = c(), u = e.kind === "cemetery" || e.kind === "battlefield" || e.kind === "volcano" && !!i;
	return /* @__PURE__ */ m("div", {
		className: "frame flex min-h-11 items-center gap-2 px-2 py-1",
		children: [/* @__PURE__ */ p("div", {
			className: "min-w-0 flex-1 overflow-x-auto",
			children: /* @__PURE__ */ m("div", {
				className: "flex w-max items-center gap-1.5",
				children: [
					!u && /* @__PURE__ */ p("span", {
						className: "px-1 text-xs font-bold leading-tight",
						children: l(Ae[e.kind])
					}),
					e.kind === "cemetery" && t.discards[n].map((e, t) => /* @__PURE__ */ p(Be, {
						kind: e,
						small: !0,
						onClick: () => a(t)
					}, t)),
					e.kind === "battlefield" && Array.from({ length: t.racks[r].count }, (e, n) => {
						let i = t.racks[r].lockedIdx.includes(n);
						return /* @__PURE__ */ p("button", {
							type: "button",
							disabled: i,
							onClick: () => a(n),
							"aria-label": l("games.toybattle.lockSlotAria", { n: n + 1 }),
							className: "grid h-12 w-11 flex-none place-items-center rounded-md border-2 border-ink bg-ink/70 text-base shadow-[2px_2px_0_var(--color-ink)] disabled:opacity-35",
							children: i ? "🔒" : "❔"
						}, n);
					}),
					e.kind === "volcano" && i && /* @__PURE__ */ p("button", {
						type: "button",
						onClick: s,
						className: "btn-quiet min-h-11 px-3 text-xs font-bold",
						children: l("games.toybattle.volcanoReselect")
					})
				]
			})
		}), /* @__PURE__ */ p("button", {
			type: "button",
			onClick: o,
			className: "btn-quiet min-h-11 flex-none px-3 text-sm font-bold",
			children: l("games.toybattle.skipEffect")
		})]
	});
}
function Be({ kind: e, locked: t, selected: n, disabled: r, inactive: i, small: a, onClick: o }) {
	let s = c();
	return /* @__PURE__ */ m("button", {
		type: "button",
		disabled: r,
		"aria-disabled": i || void 0,
		"aria-label": s(D[e]),
		onClick: o,
		className: "toy-card disabled:opacity-45",
		"data-small": a || void 0,
		"data-selected": n || void 0,
		"data-inactive": i || void 0,
		children: [
			/* @__PURE__ */ p("span", {
				className: "toy-card__name",
				children: s(D[e])
			}),
			/* @__PURE__ */ p(xe, {
				kind: e,
				className: "toy-card__art"
			}),
			/* @__PURE__ */ p("span", {
				className: "toy-card__power",
				children: e === "kwak" ? "★" : T[e]
			}),
			t && /* @__PURE__ */ p("span", {
				"aria-hidden": !0,
				className: "toy-card__lock",
				children: s("games.toybattle.lockedMark")
			})
		]
	});
}
function Ve({ disabled: e, count: t, onClick: n }) {
	let r = c(), { ref: i } = s("rack");
	return /* @__PURE__ */ p("button", {
		ref: i,
		type: "button",
		disabled: e || t === 0,
		onClick: n,
		className: "btn-base toy-draw flex-none text-white",
		style: { background: w.accent },
		children: r("games.toybattle.draw", { n: t })
	});
}
//#endregion
//#region src/games/toybattle/bot.ts
function Y(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function He() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
var X = (e, t) => e[t]?.[e[t].length - 1], Z = (e) => e === "kwak" ? 3.5 : T[e], Ue = (e) => {
	if (e === "kwak") return 9;
	let t = e === "skully" || e === "capn" ? 2 : +(e === "star" || e === "jumbo" || e === "xb42");
	return T[e] + t;
}, We = /* @__PURE__ */ new Set([
	"castle",
	"clouds",
	"volcano",
	"cemetery",
	"battlefield"
]), Ge = /* @__PURE__ */ new WeakMap();
function Ke(e, t) {
	let n = V(e), r = /* @__PURE__ */ new Map(), i = [...t];
	for (let e of t) r.set(e, 0);
	for (; i.length;) {
		let e = i.shift();
		for (let t of n.get(e) ?? []) r.has(t) || (r.set(t, r.get(e) + 1), i.push(t));
	}
	return r;
}
function qe(e) {
	let t = Ge.get(e);
	if (!t) {
		let n = V(e), r = [[], []];
		for (let t of e.nodes) t.kind === "hq" && r[t.side ?? 0].push(t.id);
		let i = r.map((e) => new Set(e.flatMap((e) => n.get(e) ?? []))), a = /* @__PURE__ */ new Map();
		e.regions.forEach((e, t) => {
			for (let n of e.around) {
				let e = a.get(n) ?? [];
				e.push(t), a.set(n, e);
			}
		}), t = {
			hq: r,
			hqAdj: i,
			distHQ: [Ke(e, r[0]), Ke(e, r[1])],
			nodeRegions: a,
			deg: new Map(e.nodes.map((e) => [e.id, n.get(e.id)?.length ?? 0]))
		}, Ge.set(e, t);
	}
	return t;
}
function Je(e, t, n, r) {
	let i = V(t), a = new Set(r), o = [...r];
	for (; o.length;) {
		let r = o.shift();
		for (let s of i.get(r) ?? []) {
			if (a.has(s)) continue;
			let r = t.nodes.find((e) => e.id === s);
			(r.kind === "path" || r.kind === "hq" && r.side === n || X(e, s)?.o === n) && (a.add(s), o.push(s));
		}
	}
	return a;
}
var Ye = (e, t, n, r, i) => n.hq[r].some((n) => Je(e, t, r, [i]).has(n));
function Xe(e, t, n, r) {
	let i = 0;
	for (let a of t.regions[n].around) X(e, a)?.o !== r && (i += 1);
	return i;
}
var Ze = {
	coverBase: 55,
	coverPow: 10,
	excessPen: 3,
	regionCompleteBase: 150,
	regionCompleteMedal: 200,
	region1Base: 10,
	region1Medal: 25,
	region2Base: 10,
	region2Medal: 6,
	block1Base: 60,
	block1Medal: 150,
	block2Medal: 25,
	doorCover1: 120,
	doorCover2: 160,
	depthW: 2,
	doorOff: 60,
	threatBase: 40,
	threatPow: 55,
	threatNoBackup: 60,
	engineSkully: 6,
	engineStar: 7,
	specialBase: 14,
	degW: 1.5,
	costW: 1,
	drawThresh: 45,
	drawRack: 4,
	drawRand: .35,
	lastCardThresh: 150,
	capnSkip: 15
};
function Qe(e) {
	return function(t, n, r) {
		let i = x[t.board], a = 1 - r, o = qe(i), s = o.hq[r].some((e) => Ye(t.slots, i, o, a, e)), c = Je(t.slots, i, r, o.hq[a]), l = Je(t.slots, i, r, o.hq[r]), u = o.hq[a].some((e) => l.has(e)), d = Math.max(1, ...i.nodes.map((e) => o.distHQ[a].get(e.id) ?? 0)), f = [];
		return n.rack.forEach((p, m) => {
			if (!p.locked) for (let h of i.nodes) {
				if (h.kind === "path" || oe({ slots: t.slots }, i, r, p.k, h.id) !== null) continue;
				if (h.kind === "hq") {
					f.push({
						slot: m,
						target: h.id,
						score: 1e6
					});
					continue;
				}
				let g = {
					...t.slots,
					[h.id]: [...t.slots[h.id] ?? [], {
						o: r,
						k: p.k
					}]
				}, _ = X(t.slots, h.id), v = o.distHQ[r].get(h.id) ?? d, y = o.distHQ[a].get(h.id) ?? d, b = 0;
				if (_ && _.o === a) {
					let t = p.k === "kwak" ? Math.max(0, 5 - Z(_.k)) : Math.max(0, Z(p.k) - Z(_.k));
					b += e.coverBase + Z(_.k) * e.coverPow - (v <= 2 ? 0 : t * e.excessPen);
				}
				for (let n of o.nodeRegions.get(h.id) ?? []) {
					if (t.claimed.includes(n)) continue;
					let o = i.regions[n], s = Xe(g, i, n, r);
					if (s === 0) {
						b += t.medals[r] + o.medals >= t.objectives[r] ? 1e6 : e.regionCompleteBase + o.medals * e.regionCompleteMedal;
						continue;
					}
					s === 1 ? b += e.region1Base + o.medals * e.region1Medal : s === 2 && (b += e.region2Base + o.medals * e.region2Medal);
					let c = Xe(t.slots, i, n, a);
					c === 1 ? b += t.medals[a] + o.medals >= t.objectives[a] ? 3e4 : e.block1Medal * o.medals + e.block1Base : c === 2 && (b += e.block2Medal * o.medals);
				}
				if (v === 1 ? _?.o === a && (b += e.doorCover1) : v === 2 && _?.o === a && (b += e.doorCover2), b += (d - y) * e.depthW, y === 1 && (b += e.doorOff), !u) {
					let t = V(i).get(h.id) ?? [], r = t.some((e) => c.has(e)), a = t.some((e) => l.has(e));
					r && a && (b += n.rack.some((e, t) => t !== m && !e.locked) ? e.threatBase + e.threatPow * Z(p.k) : e.threatNoBackup);
				}
				s && !o.hq[r].some((e) => Ye(g, i, o, a, e)) && (b += 1e5), v > 2 && t.reserves[r] > 0 && (p.k === "skully" || p.k === "star") && (b += p.k === "skully" ? e.engineSkully : e.engineStar), h.kind === "special" && We.has(t.board) && (b += e.specialBase), b += (o.deg.get(h.id) ?? 0) * e.degW, b -= Ue(p.k) * e.costW, f.push({
					slot: m,
					target: h.id,
					score: b
				});
			}
		}), f;
	};
}
var $e = (e) => e.reduce((e, t) => t.score > e.score ? t : e);
function et(e) {
	let t = Qe(e);
	return (n, r) => {
		let i = n.public, a = n.private, o = i.seats.indexOf(r.rid);
		if (o < 0 || !a || i.winner !== null || i.turn !== o) return null;
		let s = r.difficulty === "weak", c = x[i.board], l = 1 - o, u = qe(c), d = i.pending;
		if (d && d.side === o) switch (d.kind) {
			case "capn": {
				let n = t(i, a, o);
				if (n.length === 0) return { action: {
					type: "effect",
					skip: !0
				} };
				let r = $e(n);
				if (!s && r.score < e.capnSkip) return { action: {
					type: "effect",
					skip: !0
				} };
				let c = s ? Y(n) : r;
				return { action: {
					type: "place",
					slot: c.slot,
					target: c.target
				} };
			}
			case "jumbo": {
				let e = (V(c).get(d.at) ?? []).filter((e) => X(i.slots, e)?.o === l);
				if (e.length === 0) return { action: {
					type: "effect",
					skip: !0
				} };
				if (s) return { action: {
					type: "effect",
					node: Y(e)
				} };
				let t = (e) => {
					let t = i.slots[e], n = t[t.length - 1], r = 10 + Z(n.k) * 6;
					t.length > 1 && (r += 35);
					for (let t of u.nodeRegions.get(e) ?? []) !i.claimed.includes(t) && Xe(i.slots, c, t, l) === 1 && (r += 50 * c.regions[t].medals);
					return u.hqAdj[o].has(e) && (r += 80), r;
				};
				return { action: {
					type: "effect",
					node: e.reduce((e, n) => t(n) > t(e) ? n : e)
				} };
			}
			case "castle": {
				if (s) return { action: {
					type: "effect",
					skip: !0
				} };
				let e = {
					skully: 16,
					capn: 16,
					star: 10,
					xb42: 9,
					jumbo: 9,
					kwak: 7,
					roxy: 6,
					hook: 3
				}, t = null, n = 8;
				for (let r of Object.keys(i.slots)) {
					if (r === d.at) continue;
					let s = i.slots[r], l = s[s.length - 1];
					if (l.o !== o) continue;
					let f = e[l.k] + (a.rack.length <= 3 ? 6 : 0);
					s.length > 1 && (f -= 12);
					for (let e of u.nodeRegions.get(r) ?? []) {
						if (i.claimed.includes(e)) continue;
						let t = Xe(i.slots, c, e, o);
						if (t === 1) {
							f -= 80;
							break;
						}
						t === 2 && (f -= 20);
					}
					f > n && (n = f, t = r);
				}
				return t ? { action: {
					type: "effect",
					node: t
				} } : { action: {
					type: "effect",
					skip: !0
				} };
			}
			case "volcano": {
				let e = (V(c).get(d.at) ?? []).filter((e) => X(i.slots, e)?.o === l);
				if (e.length === 0) return { action: {
					type: "effect",
					skip: !0
				} };
				let t = (e) => (V(c).get(e) ?? []).filter((e) => {
					let t = c.nodes.find((t) => t.id === e);
					if (!t || t.kind === "hq" || t.kind === "path") return !1;
					let n = X(i.slots, e);
					return !n || n.o === l;
				});
				if (s) {
					let n = Y(e), r = t(n);
					return r.length ? { action: {
						type: "effect",
						node: n,
						dest: Y(r)
					} } : { action: {
						type: "effect",
						skip: !0
					} };
				}
				let n = null, r = 5;
				for (let a of e) {
					let e = i.slots[a], s = e[e.length - 1], d = 8 + Z(s.k) * 4;
					e.length > 1 && (d += 30);
					for (let e of u.nodeRegions.get(a) ?? []) !i.claimed.includes(e) && Xe(i.slots, c, e, l) === 1 && (d += 40 * c.regions[e].medals);
					u.hqAdj[o].has(a) && (d += 60);
					for (let e of t(a)) {
						let t = X(i.slots, e), s = d;
						if (t) s += Z(t.k) * 3;
						else {
							for (let t of u.nodeRegions.get(e) ?? []) i.claimed.includes(t) || c.regions[t].around.every((t) => t === e || X(i.slots, t)?.o === l) && (s -= 150 * c.regions[t].medals + 60);
							s += (u.distHQ[o].get(e) ?? 0) * 1 - (u.deg.get(e) ?? 0) * 1.5;
						}
						s > r && (r = s, n = {
							src: a,
							dest: e
						});
					}
				}
				return n ? { action: {
					type: "effect",
					node: n.src,
					dest: n.dest
				} } : { action: {
					type: "effect",
					skip: !0
				} };
			}
			case "cemetery": {
				let e = i.discards[o];
				if (e.length === 0) return { action: {
					type: "effect",
					skip: !0
				} };
				if (s) return { action: {
					type: "effect",
					card: Math.floor(He() * e.length)
				} };
				let t = {
					skully: 8,
					capn: 8,
					star: 5,
					jumbo: 4,
					xb42: 4,
					kwak: 6,
					roxy: 0,
					hook: 1
				}, n = 0;
				return e.forEach((r, i) => {
					Z(r) * 2 + t[r] > Z(e[n]) * 2 + t[e[n]] && (n = i);
				}), { action: {
					type: "effect",
					card: n
				} };
			}
			case "battlefield": {
				let e = i.racks[l].count, t = Array.from({ length: e }, (e, t) => t).filter((e) => !i.racks[l].lockedIdx.includes(e));
				return t.length === 0 ? { action: {
					type: "effect",
					skip: !0
				} } : { action: {
					type: "effect",
					card: Y(t)
				} };
			}
		}
		let f = t(i, a, o), p = i.reserves[o] > 0 && a.rack.length < 8;
		if (f.length === 0) return p ? { action: { type: "draw" } } : null;
		let m = $e(f);
		if (p && !s && (m.score < e.drawThresh && (a.rack.length <= e.drawRack || He() < e.drawRand) || a.rack.length === 1 && m.score < e.lastCardThresh) || p && s && m.score < e.drawThresh && He() < .5) return { action: { type: "draw" } };
		let h = s ? Y(f) : m;
		return { action: {
			type: "place",
			slot: h.slot,
			target: h.target
		} };
	};
}
var tt = et(Ze), Q = {
	skully: "games.toybattle.troop.skully",
	capn: "games.toybattle.troop.capn",
	jumbo: "games.toybattle.troop.jumbo",
	hook: "games.toybattle.troop.hook",
	xb42: "games.toybattle.troop.xb42",
	star: "games.toybattle.troop.star",
	roxy: "games.toybattle.troop.roxy",
	kwak: "games.toybattle.troop.kwak"
}, nt = (e, t, n) => {
	let r = t.public, i = (e) => {
		let t = r.slots[e];
		return t && t.length > 0 ? t[t.length - 1] : void 0;
	};
	switch (e.type) {
		case "draw": return n("games.toybattle.hintDraw");
		case "place": {
			let a = t.private?.rack[e.slot]?.k;
			if (!a) return "";
			let o = i(e.target);
			return o && o.o !== r.turn ? n("games.toybattle.hintPlaceCover", {
				troop: n(Q[a]),
				troop2: n(Q[o.k])
			}) : n("games.toybattle.hintPlace", { troop: n(Q[a]) });
		}
		case "effect": {
			if (e.skip) return n("games.toybattle.skipEffect");
			let t = r.pending;
			if (!t) return "";
			switch (t.kind) {
				case "jumbo": {
					let t = e.node ? i(e.node) : void 0;
					return t ? n("games.toybattle.hintJumbo", { troop: n(Q[t.k]) }) : "";
				}
				case "castle": {
					let t = e.node ? i(e.node) : void 0;
					return t ? n("games.toybattle.hintCastle", { troop: n(Q[t.k]) }) : "";
				}
				case "volcano": {
					let t = e.node ? i(e.node) : void 0;
					return t ? n("games.toybattle.hintVolcano", { troop: n(Q[t.k]) }) : "";
				}
				case "cemetery": {
					let i = e.card === void 0 ? void 0 : r.discards[t.side][e.card];
					return i ? n("games.toybattle.hintCemetery", { troop: n(Q[i]) }) : "";
				}
				case "battlefield": return e.card === void 0 ? "" : n("games.toybattle.lockSlotAria", { n: e.card + 1 });
				case "capn": return "";
			}
		}
	}
}, $ = (e, t) => t && t !== e.myRid ? `seat:${t}` : "rack";
function rt({ k: e, size: t = 36 }) {
	let n = E.find((t) => t === e);
	return /* @__PURE__ */ p("span", {
		"aria-hidden": !0,
		className: "grid flex-none place-items-center overflow-hidden rounded-full border-2 border-ink bg-surface",
		style: {
			width: t,
			height: t
		},
		children: n ? /* @__PURE__ */ p(xe, {
			kind: n,
			className: "size-full"
		}) : "？"
	});
}
var it = {
	place(e, t) {
		let n = e.data, r = typeof n?.target == "string" ? t.anchor(`base:${n.target}`) : null, i = t.anchor($(t, e.rid));
		return !r || !i || typeof n?.troop != "string" ? null : {
			ms: 380,
			node: /* @__PURE__ */ p(g, {
				from: i,
				to: r,
				ms: 360,
				children: /* @__PURE__ */ p(rt, {
					k: n.troop,
					size: Math.max(28, Math.min(144, Math.min(r.w, r.h) * .72))
				})
			})
		};
	},
	draw(e, t) {
		let n = t.anchor($(t, e.rid));
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 580
			})
		} : null;
	},
	region(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return r ? {
			ms: 1100,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 1e3,
				children: /* @__PURE__ */ m("span", {
					className: "font-display text-xl font-extrabold",
					style: { fontSize: Math.max(20, Math.min(36, r.h * .4)) },
					children: ["🏅+", typeof n?.medals == "number" ? n.medals : ""]
				})
			})
		} : null;
	},
	hqWin(e, t) {
		let n = e.data, r = typeof n?.target == "string" ? t.anchor(`base:${n.target}`) : null;
		return r ? {
			ms: 1200,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 1150
			})
		} : null;
	},
	discard(e, t) {
		let n = e.data, r = typeof n?.target == "string" ? t.anchor(`base:${n.target}`) : null;
		return r ? {
			ms: 900,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 850,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "text-xl",
					children: "💥"
				})
			})
		} : null;
	},
	recall(e, t) {
		let n = e.data, r = typeof n?.target == "string" ? t.anchor(`base:${n.target}`) : null, i = t.anchor($(t, e.rid));
		return !r || !i || typeof n?.troop != "string" ? null : {
			ms: 380,
			node: /* @__PURE__ */ p(g, {
				from: r,
				to: i,
				ms: 360,
				children: /* @__PURE__ */ p(rt, {
					k: n.troop,
					size: Math.max(28, Math.min(144, Math.min(r.w, r.h) * .72))
				})
			})
		};
	},
	move(e, t) {
		let n = e.data, r = typeof n?.from == "string" ? t.anchor(`base:${n.from}`) : null, i = typeof n?.to == "string" ? t.anchor(`base:${n.to}`) : null;
		return !r || !i || typeof n?.troop != "string" ? null : {
			ms: 380,
			node: /* @__PURE__ */ p(g, {
				from: r,
				to: i,
				ms: 360,
				children: /* @__PURE__ */ p(rt, {
					k: n.troop,
					size: Math.max(28, Math.min(144, Math.min(i.w, i.h) * .72))
				})
			})
		};
	},
	xb42(e, t) {
		let n = e.data;
		if (typeof n?.troop != "string") return null;
		let r = t.anchor($(t, typeof n.victim == "string" ? n.victim : e.rid));
		return r ? {
			ms: 800,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: 760,
				children: /* @__PURE__ */ m("span", {
					"aria-hidden": !0,
					className: "flex items-center gap-1 rounded-lg border-2 border-ink bg-surface p-1 shadow-[2px_2px_0_var(--color-ink)]",
					children: ["✈️", /* @__PURE__ */ p(rt, { k: n.troop })]
				})
			})
		} : null;
	},
	revive(e, t) {
		let n = t.anchor($(t, e.rid));
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 680
			})
		} : null;
	},
	lock(e, t) {
		let n = e.data, r = t.anchor($(t, typeof n?.victim == "string" ? n.victim : e.rid));
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 680
			})
		} : null;
	}
};
//#endregion
//#region src/games/toybattle/game-over.tsx
function at({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ p("div", {
		className: "toy-over",
		children: /* @__PURE__ */ p(v, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: w.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/toybattle/options.tsx
var ot = {
	random: "games.toybattle.side.random",
	hostRed: "games.toybattle.side.hostRed",
	hostBlue: "games.toybattle.side.hostBlue"
};
function st({ value: e, onChange: t }) {
	let n = c(), r = N.safeParse(e), i = r.success ? r.data : N.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ p("p", {
				className: "section-label",
				children: n("games.toybattle.optBoard")
			}),
			/* @__PURE__ */ p("div", {
				className: "grid grid-cols-3 gap-2",
				children: ["random", ...S].map((e) => {
					let r = i.board === e;
					return /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => t({
							...i,
							board: e
						}),
						className: "card relative flex min-h-11 cursor-pointer flex-col items-center gap-1 p-2 text-center text-sm font-bold",
						style: r ? {
							borderColor: w.accent,
							boxShadow: `4px 4px 0 ${w.accent}`
						} : void 0,
						children: [
							e === "random" ? /* @__PURE__ */ p("span", {
								"aria-hidden": !0,
								className: "grid h-14 w-10 place-items-center rounded-md border-2 border-ink bg-pop text-2xl",
								children: "🎲"
							}) : /* @__PURE__ */ p("img", {
								src: `./games/toybattle/board-${e}.webp`,
								alt: "",
								className: "h-14 w-10 rounded-md border-2 border-ink object-cover"
							}),
							r && /* @__PURE__ */ p("i", {
								"aria-hidden": !0,
								className: "absolute right-1 top-1 grid size-5 place-items-center rounded-full border-2 border-ink bg-surface",
								children: /* @__PURE__ */ p("span", { className: "size-2 rounded-full bg-ink" })
							}),
							/* @__PURE__ */ p("span", { children: n(e === "random" ? "games.toybattle.board.random" : x[e].nameKey) })
						]
					}, e);
				})
			}),
			/* @__PURE__ */ p(b, {
				title: n("games.toybattle.optSide"),
				columns: 3,
				children: [
					"random",
					"hostRed",
					"hostBlue"
				].map((e) => /* @__PURE__ */ p(y, {
					name: "toybattle-side",
					value: e,
					checked: i.sideAssign === e,
					label: n(ot[e]),
					accent: w.accent,
					onChange: () => t({
						...i,
						sideAssign: e
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region src/games/toybattle/guide.tsx
function ct() {
	let e = c();
	return /* @__PURE__ */ m("div", {
		className: "flex w-full flex-col gap-3",
		children: [/* @__PURE__ */ m("section", {
			className: "flex w-full flex-col gap-1.5",
			children: [/* @__PURE__ */ p("p", {
				className: "section-label",
				children: e("games.toybattle.guideTroops")
			}), /* @__PURE__ */ p("ul", {
				className: "flex w-full flex-col gap-2",
				children: E.map((t) => /* @__PURE__ */ m("li", {
					className: "frame flex items-center gap-3 p-2",
					children: [/* @__PURE__ */ m("span", {
						className: "relative grid h-12 w-9 flex-none place-items-center overflow-hidden rounded-md border-2 border-ink bg-surface",
						children: [/* @__PURE__ */ p(xe, {
							kind: t,
							className: "size-full"
						}), /* @__PURE__ */ p("span", {
							className: "absolute right-0.5 bottom-0 rounded bg-ink px-0.5 font-mono text-[9px] leading-3 font-bold text-white tabular-nums",
							children: t === "kwak" ? "★" : T[t]
						})]
					}), /* @__PURE__ */ m("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ p("p", {
							className: "text-sm font-extrabold",
							children: e(D[t])
						}), /* @__PURE__ */ p("p", {
							className: "text-xs leading-5 font-bold opacity-70",
							children: e(ee[t])
						})]
					})]
				}, t))
			})]
		}), /* @__PURE__ */ m("section", {
			className: "flex w-full flex-col gap-1.5",
			children: [/* @__PURE__ */ p("p", {
				className: "section-label",
				children: e("games.toybattle.guideBases")
			}), /* @__PURE__ */ p("ul", {
				className: "flex w-full flex-col gap-2",
				children: Object.keys(C).map((t) => /* @__PURE__ */ m("li", {
					className: "frame flex items-center gap-3 p-2",
					children: [/* @__PURE__ */ m("span", {
						"aria-hidden": !0,
						className: "relative grid h-12 w-9 flex-none place-items-center overflow-hidden rounded-md border-2 border-ink bg-surface text-lg",
						children: [/* @__PURE__ */ p("img", {
							src: `./games/toybattle/board-${t}.webp`,
							alt: "",
							className: "absolute inset-0 size-full object-cover"
						}), /* @__PURE__ */ p("span", {
							className: "relative rounded bg-surface/85 px-0.5",
							children: x[t].specialIcon ?? "✨"
						})]
					}), /* @__PURE__ */ m("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ p("p", {
							className: "text-sm font-extrabold",
							children: e(x[t].nameKey)
						}), /* @__PURE__ */ p("p", {
							className: "text-xs leading-5 font-bold opacity-70",
							children: e(C[t])
						})]
					})]
				}, t))
			})]
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/toybattle/entry.tsx
var lt = {
	definition: _e,
	View: Ne,
	bot: tt,
	describe: nt,
	fx: it,
	OverView: at,
	Options: st,
	Guide: ct,
	locales: {
		zh: {
			name: "玩具大作战",
			desc: "双人玩具军对战:连通补给线铺兵压阵,抢区域奖牌或直捣对方总部",
			rules: "目标:占领对方任意一座总部立即获胜;或先拿到自己一端徽章所示数量的奖牌。\n每回合二选一:\n· 抽 2 张部队牌放到架上(架上限 8 张;只剩 1 张/1 格时抽 1 张)。\n· 从架上放置 1 支部队到版图,并结算其效果。\n放置规则:\n· 放置点必须经由己方占领的基地一路连通回己方总部(铁钩手无视连通,但攻入对方总部时仍需连通)。\n· 可放空地或己方基地;压到敌方基地上须战力严格更大,被压的留在下面。\n· 夸克鸭是百搭:可压任何部队,也可被任何部队压。\n区域奖牌:\n· 围成一个区域的所有基地都被你占领,立刻拿走区域中央的全部奖牌;拿过的区域不再产牌,之后失去基地也不退回。\n特殊基地(占领时触发,均可选择不用):\n· 城堡原野:收回己方 1 支其他部队回架。云端之城:抽 1 张牌。\n· 火山岛:把相邻 1 支敌兵移到它的相邻基地。墓园迷踪:从己方弃牌堆捞 1 张回架。\n· 玩具沙场:扣置对方架上 1 张牌,对方下个回合不能打出它。泳池派对:限指定战力进驻。\n· 金属 X:上面的部队效果不发动。\n山穷水尽:\n· 一方轮到时既不能抽也不能放,对局结束:奖牌多者胜;平则该方判负。",
			board: {
				random: "随机版图",
				castle: "城堡原野",
				clouds: "云端之城",
				volcano: "火山岛",
				cemetery: "墓园迷踪",
				caribbean: "加勒比海",
				battlefield: "玩具沙场",
				pool: "泳池派对",
				metalx: "金属 X"
			},
			optBoard: "版图",
			optSide: "选边",
			redSide: "红",
			blueSide: "蓝",
			medalShort: "奖牌",
			reserveShort: "后备",
			rackTitle: "部队架",
			opponentLabel: "对手",
			youLabel: "你",
			lockedMark: "锁",
			boardTools: "版图缩放",
			zoomIn: "放大版图",
			zoomOut: "缩小版图",
			zoomReset: "回到版图初始视角",
			canPlace: "可放",
			fxTarget: "目标",
			guideTroops: "部队图鉴",
			guideBases: "特殊基地图例",
			baseFx: {
				castle: "占领时:可收回己方 1 支其他部队回架",
				clouds: "占领时:抽 1 张牌",
				volcano: "占领时:可把相邻 1 支敌兵移到它的相邻基地",
				cemetery: "占领时:可从己方弃牌堆捞 1 张回架",
				battlefield: "占领时:可扣置对方架上 1 张牌,其下回合不能打出",
				pool: "只许标注战力的部队进驻",
				metalx: "进驻的部队效果不发动"
			},
			side: {
				random: "随机",
				hostRed: "主机执红",
				hostBlue: "主机执蓝"
			},
			promptTurn: "你的回合 · 抽牌或出兵",
			promptPlace: "你的回合 · 放置部队",
			waitTurn: "等 {{name}} 行动…",
			ended: "对局结束",
			pendingMay: "效果可选,可跳过",
			pending: {
				capn: "船长:可再放置 1 支部队",
				jumbo: "大象:点选相邻的敌方部队弃掉",
				castle: "城堡:点选收回己方 1 支其他部队",
				volcano: "火山:先点选要移走的相邻敌兵",
				volcanoDest: "火山:再点选它落脚的相邻基地",
				cemetery: "墓园:从弃牌堆选 1 张回架",
				battlefield: "狙击:点选扣置对方架上 1 张牌"
			},
			skipEffect: "跳过",
			volcanoReselect: "重选目标",
			logAria: "对局日志",
			logEmpty: "还没有记录",
			log: {
				draw: "{{name}} 抽了 {{n}} 张",
				place: "{{name}} 放置 {{troop}}",
				placeCover: "{{name}} 放置 {{troop}},压住 {{troop2}}",
				capn: "{{name}} 的船长效果:再放置 1 支",
				jumbo: "{{name}} 弃掉 {{name2}} 的 {{troop}}",
				recall: "{{name}} 收回 {{troop}}",
				move: "{{name}} 移走 {{name2}} 的 {{troop}}",
				revive: "{{name}} 捞回 {{troop}}",
				lock: "{{name}} 扣置 {{name2}} 架上 1 张牌",
				xb42: "{{name}} 的轰炸机盲弃 {{name2}} 的 {{troop}}",
				region: "{{name}} 控下一区,拿 {{n}} 枚奖牌",
				hqWin: "{{name}} 攻入大本营!"
			},
			sheet: {
				base: "基地",
				special: "特殊基地",
				path: "枢纽",
				hqTitle: "{{name}} 的大本营",
				hqDesc: "攻入这里的一方立即获胜",
				pathDesc: "连通透明,不可放置部队",
				limits: "只许战力 {{list}} 进驻",
				occEmpty: "无人占领",
				occTop: "占领中",
				occCovered: "被压",
				actPlace: "放置{{name}}到这",
				actJumbo: "弃掉它",
				actCastle: "收回它",
				actVolcSrc: "移动它",
				actVolcDest: "移到这里"
			},
			rackEmpty: "架上空空如也",
			draw: "抽 {{n}} 张",
			lockSlotAria: "扣置对方第 {{n}} 张",
			troop: {
				skully: "骷髅兵",
				capn: "船长",
				jumbo: "大象",
				hook: "铁钩手",
				xb42: "轰炸机",
				star: "星星",
				roxy: "洛克西",
				kwak: "夸克鸭"
			},
			troopInfo: {
				skully: "战力 1。放置时抽 2 张牌。",
				capn: "战力 2。放置后可立即再放置 1 支部队。",
				jumbo: "战力 3。放置时可弃掉相邻的 1 支敌方部队。",
				hook: "战力 4。放置无需连通己方总部(攻入敌总部仍须连通)。",
				xb42: "战力 5。放置时随机弃掉对方架上 1 张牌。",
				star: "战力 6。放置时抽 1 张牌。",
				roxy: "战力 7。无特殊效果,全凭蛮力。",
				kwak: "百搭,无战力。可压任何部队,也可被任何部队压。"
			},
			errNotYourTurn: "还没轮到你",
			errGameOver: "对局已结束",
			errNoDraw: "无牌可抽(后备空或架已满)",
			errPending: "需先结算当前效果",
			errBadSlot: "这张牌现在不能出",
			errLocked: "这张牌被扣置了",
			errBadTarget: "不能放到这里",
			errLimit: "这个基地只接受指定战力",
			errWeak: "战力不够,压不住对方",
			errNotConnected: "放置点未连通你的总部",
			errRackFull: "架已满,收不回来了",
			errBadChoice: "无效的选择",
			hintDraw: "抽牌",
			hintPlace: "放置 {{troop}}",
			hintPlaceCover: "放置 {{troop}},压住 {{troop2}}",
			hintJumbo: "弃掉敌方的 {{troop}}",
			hintCastle: "收回 {{troop}}",
			hintVolcano: "移走敌方的 {{troop}}",
			hintCemetery: "捞回 {{troop}}"
		},
		en: {
			name: "Toy Battle",
			desc: "Two-player toy army clash: keep your supply line, claim region medals, or storm the enemy HQ",
			rules: "Goal: capture any enemy HQ to win instantly, or be the first to collect the number of medals shown on your own badge.\nOn your turn, choose one:\n· Draw 2 troop cards onto your rack (max 8; draw 1 if only 1 card or 1 slot remains).\n· Place 1 troop from your rack onto the board and resolve its effect.\nPlacement rules:\n· The target must connect back to your HQ through a chain of bases you occupy (Hook ignores this, but storming an enemy HQ still requires connection).\n· Empty bases or your own bases are always fine; covering an enemy base requires strictly higher power (the covered troop stays underneath).\n· Kwak is wild: it can cover anything, and anything can cover it.\nRegion medals:\n· Occupy every base around a region to take all medals at its center at once; claimed regions never produce again, and losing bases later costs nothing.\nSpecial bases (trigger when occupied; all optional):\n· Castle Field: return 1 of your other troops to your rack. City of Clouds: draw 1 card.\n· Volcano Island: move an adjacent enemy troop to one of its adjacent bases. Creepy Cemetery: recover 1 card from your discard pile.\n· Battlefield: lock 1 card on the enemy rack; they cannot play it next turn. Pool Party: only the listed powers may enter.\n· Metal-X: troop effects do not trigger here.\nStalemate:\n· If a player can neither draw nor place on their turn, the game ends: more medals wins; on a tie, that player loses.",
			board: {
				random: "Random board",
				castle: "Castle Field",
				clouds: "City of Clouds",
				volcano: "Volcano Island",
				cemetery: "Creepy Cemetery",
				caribbean: "Caribbean",
				battlefield: "Battlefield",
				pool: "Pool Party",
				metalx: "Metal-X"
			},
			optBoard: "Board",
			optSide: "Sides",
			redSide: "R",
			blueSide: "B",
			medalShort: "Medals",
			reserveShort: "Deck",
			rackTitle: "Troop rack",
			opponentLabel: "Rival",
			youLabel: "You",
			lockedMark: "LOCK",
			boardTools: "Board zoom",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			zoomReset: "Reset board view",
			canPlace: "PLAY",
			fxTarget: "AIM",
			guideTroops: "Troop gallery",
			guideBases: "Special base legend",
			baseFx: {
				castle: "When occupied: you may recall 1 of your other troops to your rack",
				clouds: "When occupied: draw 1 card",
				volcano: "When occupied: you may move an adjacent enemy troop to one of its adjacent bases",
				cemetery: "When occupied: you may recover 1 card from your discard pile",
				battlefield: "When occupied: you may lock 1 card on the enemy rack for their next turn",
				pool: "Only troops of the listed powers may enter",
				metalx: "Troop effects do not trigger here"
			},
			side: {
				random: "Random",
				hostRed: "Host plays red",
				hostBlue: "Host plays blue"
			},
			promptTurn: "Your turn · Draw or deploy",
			promptPlace: "Your turn · Deploy a troop",
			waitTurn: "Waiting for {{name}}…",
			ended: "Game over",
			pendingMay: "Optional effect — you may skip",
			pending: {
				capn: "Cap'N: you may place 1 more troop",
				jumbo: "Jumbo: tap an adjacent enemy troop to discard it",
				castle: "Castle: tap one of your other troops to recall it",
				volcano: "Volcano: tap an adjacent enemy troop to move",
				volcanoDest: "Volcano: tap an adjacent base for it to land on",
				cemetery: "Cemetery: pick 1 card from your discards",
				battlefield: "Snipers: tap 1 card on the enemy rack to lock it"
			},
			skipEffect: "Skip",
			volcanoReselect: "Reselect",
			logAria: "Game log",
			logEmpty: "No events yet",
			log: {
				draw: "{{name}} drew {{n}}",
				place: "{{name}} placed {{troop}}",
				placeCover: "{{name}} placed {{troop}} over {{troop2}}",
				capn: "{{name}}'s Cap'N: place 1 more troop",
				jumbo: "{{name}} discarded {{name2}}'s {{troop}}",
				recall: "{{name}} recalled {{troop}}",
				move: "{{name}} moved {{name2}}'s {{troop}} away",
				revive: "{{name}} recovered {{troop}}",
				lock: "{{name}} locked 1 card on {{name2}}'s rack",
				xb42: "{{name}}'s bomber hit {{name2}}'s {{troop}}",
				region: "{{name}} claimed a region: {{n}} medals",
				hqWin: "{{name}} stormed the HQ!"
			},
			sheet: {
				base: "Base",
				special: "Special base",
				path: "Junction",
				hqTitle: "{{name}}'s HQ",
				hqDesc: "Whoever storms this HQ wins instantly",
				pathDesc: "Pass-through link; troops cannot be placed here",
				limits: "Only power {{list}} may enter",
				occEmpty: "Unoccupied",
				occTop: "On top",
				occCovered: "Covered",
				actPlace: "Place {{name}} here",
				actJumbo: "Discard it",
				actCastle: "Recall it",
				actVolcSrc: "Move it",
				actVolcDest: "Move it here"
			},
			rackEmpty: "Rack is empty",
			draw: "Draw {{n}}",
			lockSlotAria: "Lock enemy card #{{n}}",
			troop: {
				skully: "Skully",
				capn: "Cap'N",
				jumbo: "Jumbo",
				hook: "Hook",
				xb42: "XB-42",
				star: "Star",
				roxy: "Roxy",
				kwak: "Kwak"
			},
			troopInfo: {
				skully: "Power 1. Draw 2 cards when placed.",
				capn: "Power 2. You may place 1 more troop right away.",
				jumbo: "Power 3. You may discard 1 adjacent enemy troop.",
				hook: "Power 4. Needs no connection to your HQ (still required to storm the enemy HQ).",
				xb42: "Power 5. Randomly discards 1 card from the enemy rack.",
				star: "Power 6. Draw 1 card when placed.",
				roxy: "Power 7. No special effect — just the strongest.",
				kwak: "Wild, no power. Covers any troop and is covered by any."
			},
			errNotYourTurn: "Not your turn",
			errGameOver: "The game is over",
			errNoDraw: "Nothing to draw (deck empty or rack full)",
			errPending: "Resolve the current effect first",
			errBadSlot: "That card cannot be played now",
			errLocked: "That card is locked",
			errBadTarget: "Cannot place there",
			errLimit: "This base only accepts the listed powers",
			errWeak: "Not enough power to cover that troop",
			errNotConnected: "Target is not connected to your HQ",
			errRackFull: "Rack is full — cannot recall",
			errBadChoice: "Invalid choice",
			hintDraw: "Draw cards",
			hintPlace: "Place {{troop}}",
			hintPlaceCover: "Place {{troop}}, covering {{troop2}}",
			hintJumbo: "Discard the enemy {{troop}}",
			hintCastle: "Recall {{troop}}",
			hintVolcano: "Move the enemy {{troop}} away",
			hintCemetery: "Retrieve {{troop}}"
		}
	}
};
//#endregion
export { lt as default };
