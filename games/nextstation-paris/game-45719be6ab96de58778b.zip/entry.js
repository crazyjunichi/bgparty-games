import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useState as r } from "react";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { SheetView as o } from "@bgparty/sdk/sheet-view";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { seatName as c } from "@bgparty/sdk/ui/player-strip";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { OptionSwitch as f } from "@bgparty/sdk/ui/game-options";
//#region src/games/nextstation-paris/data.ts
var ee = "paris", p = "nextstation-paris", m = [
	"#ef692f",
	"#26984f",
	"#8846a4",
	"#04a5d2"
], h = [
	{
		x: 0,
		y: 0,
		shape: "square",
		district: 9,
		monument: !1,
		central: !1
	},
	{
		x: 1,
		y: 0,
		shape: "circle",
		district: 0,
		monument: !1,
		central: !1
	},
	{
		x: 3,
		y: 0,
		shape: "triangle",
		district: 0,
		monument: !1,
		central: !1
	},
	{
		x: 6,
		y: 0,
		shape: "square",
		district: 1,
		monument: !1,
		central: !1
	},
	{
		x: 7,
		y: 0,
		shape: "triangle",
		district: 1,
		monument: !1,
		central: !1
	},
	{
		x: 9,
		y: 0,
		shape: "circle",
		district: 10,
		monument: !1,
		central: !1
	},
	{
		x: 0,
		y: 1,
		shape: "wild",
		district: 0,
		monument: !0,
		central: !1
	},
	{
		x: 1,
		y: 1,
		shape: "square",
		district: 0,
		monument: !1,
		central: !1
	},
	{
		x: 4,
		y: 1,
		shape: "pentagon",
		district: 0,
		monument: !1,
		central: !1
	},
	{
		x: 5,
		y: 1,
		shape: "circle",
		district: 1,
		monument: !1,
		central: !1
	},
	{
		x: 8,
		y: 1,
		shape: "wild",
		district: 1,
		monument: !0,
		central: !1
	},
	{
		x: 9,
		y: 1,
		shape: "pentagon",
		district: 1,
		monument: !1,
		central: !1
	},
	{
		x: 1,
		y: 2,
		shape: "triangle",
		district: 2,
		monument: !1,
		central: !1
	},
	{
		x: 3,
		y: 2,
		shape: "circle",
		district: 2,
		monument: !1,
		central: !1
	},
	{
		x: 5,
		y: 2,
		shape: "square",
		district: 3,
		monument: !1,
		central: !1
	},
	{
		x: 8,
		y: 2,
		shape: "pentagon",
		district: 3,
		monument: !1,
		central: !1
	},
	{
		x: 1,
		y: 3,
		shape: "wild",
		district: 2,
		monument: !0,
		central: !1
	},
	{
		x: 2,
		y: 3,
		shape: "pentagon",
		district: 2,
		monument: !1,
		central: !1
	},
	{
		x: 3,
		y: 3,
		shape: "square",
		district: 2,
		monument: !1,
		central: !1
	},
	{
		x: 4,
		y: 3,
		shape: "circle",
		district: 2,
		monument: !1,
		central: !1
	},
	{
		x: 6,
		y: 3,
		shape: "triangle",
		district: 3,
		monument: !1,
		central: !1
	},
	{
		x: 7,
		y: 3,
		shape: "pentagon",
		district: 3,
		monument: !1,
		central: !1
	},
	{
		x: 9,
		y: 3,
		shape: "square",
		district: 3,
		monument: !1,
		central: !1
	},
	{
		x: 0,
		y: 4,
		shape: "triangle",
		district: 2,
		monument: !1,
		central: !1
	},
	{
		x: 6,
		y: 4,
		shape: "circle",
		district: 3,
		monument: !1,
		central: !1
	},
	{
		x: 9,
		y: 4,
		shape: "wild",
		district: 3,
		monument: !0,
		central: !1
	},
	{
		x: 0,
		y: 5,
		shape: "wild",
		district: 4,
		monument: !0,
		central: !1
	},
	{
		x: 3,
		y: 5,
		shape: "square",
		district: 4,
		monument: !1,
		central: !1
	},
	{
		x: 7,
		y: 5,
		shape: "pentagon",
		district: 5,
		monument: !1,
		central: !1
	},
	{
		x: 9,
		y: 5,
		shape: "square",
		district: 5,
		monument: !1,
		central: !1
	},
	{
		x: 1,
		y: 6,
		shape: "circle",
		district: 4,
		monument: !1,
		central: !1
	},
	{
		x: 2,
		y: 6,
		shape: "triangle",
		district: 4,
		monument: !1,
		central: !1
	},
	{
		x: 4,
		y: 6,
		shape: "triangle",
		district: 4,
		monument: !1,
		central: !1
	},
	{
		x: 5,
		y: 6,
		shape: "wild",
		district: 5,
		monument: !0,
		central: !1
	},
	{
		x: 6,
		y: 6,
		shape: "triangle",
		district: 5,
		monument: !1,
		central: !1
	},
	{
		x: 2,
		y: 7,
		shape: "pentagon",
		district: 4,
		monument: !1,
		central: !1
	},
	{
		x: 4,
		y: 7,
		shape: "pentagon",
		district: 4,
		monument: !1,
		central: !1
	},
	{
		x: 5,
		y: 7,
		shape: "circle",
		district: 5,
		monument: !1,
		central: !1
	},
	{
		x: 7,
		y: 7,
		shape: "square",
		district: 5,
		monument: !1,
		central: !1
	},
	{
		x: 8,
		y: 7,
		shape: "circle",
		district: 5,
		monument: !1,
		central: !1
	},
	{
		x: 0,
		y: 8,
		shape: "square",
		district: 6,
		monument: !1,
		central: !1
	},
	{
		x: 1,
		y: 8,
		shape: "triangle",
		district: 6,
		monument: !1,
		central: !1
	},
	{
		x: 3,
		y: 8,
		shape: "pentagon",
		district: 6,
		monument: !1,
		central: !1
	},
	{
		x: 4,
		y: 8,
		shape: "circle",
		district: 6,
		monument: !1,
		central: !1
	},
	{
		x: 8,
		y: 8,
		shape: "pentagon",
		district: 7,
		monument: !1,
		central: !1
	},
	{
		x: 9,
		y: 8,
		shape: "circle",
		district: 7,
		monument: !1,
		central: !1
	},
	{
		x: 0,
		y: 9,
		shape: "pentagon",
		district: 11,
		monument: !1,
		central: !1
	},
	{
		x: 2,
		y: 9,
		shape: "wild",
		district: 6,
		monument: !0,
		central: !1
	},
	{
		x: 5,
		y: 9,
		shape: "triangle",
		district: 7,
		monument: !1,
		central: !1
	},
	{
		x: 6,
		y: 9,
		shape: "wild",
		district: 7,
		monument: !0,
		central: !1
	},
	{
		x: 7,
		y: 9,
		shape: "square",
		district: 7,
		monument: !1,
		central: !1
	},
	{
		x: 9,
		y: 9,
		shape: "triangle",
		district: 12,
		monument: !1,
		central: !1
	},
	{
		x: 4.5,
		y: 4.5,
		shape: "wild",
		district: 8,
		monument: !1,
		central: !0
	}
], g = [
	21,
	31,
	38,
	13
], _ = [
	[3, 1],
	[6.5, .5],
	[1.5, 3.5],
	[8, 3],
	[7, 6],
	[2.5, 6.5],
	[2, 8],
	[6.5, 8.5]
], v = [], y = (e) => [h[e].x, h[e].y], b = (e, t) => Math.abs(e[0] - t[0]) + Math.abs(e[1] - t[1]) < 1e-7, x = (e, t, n) => (t[0] - e[0]) * (n[1] - e[1]) - (t[1] - e[1]) * (n[0] - e[0]);
function S(e, t, n) {
	return Math.abs(x(t, n, e)) < 1e-7 && e[0] >= Math.min(t[0], n[0]) - 1e-7 && e[0] <= Math.max(t[0], n[0]) + 1e-7 && e[1] >= Math.min(t[1], n[1]) - 1e-7 && e[1] <= Math.max(t[1], n[1]) + 1e-7;
}
function C(e, t, n, r) {
	let i = (t[0] - e[0]) * (r[1] - n[1]) - (t[1] - e[1]) * (r[0] - n[0]);
	if (Math.abs(i) < 1e-7) {
		if (Math.abs(x(e, t, n)) > 1e-7) return null;
		let i = [
			e,
			t,
			n,
			r
		].filter((i) => S(i, e, t) && S(i, n, r));
		return i.length ? i.every((e) => b(e, i[0])) ? i[0] : "overlap" : null;
	}
	let a = ((n[0] - e[0]) * (r[1] - n[1]) - (n[1] - e[1]) * (r[0] - n[0])) / i, o = ((n[0] - e[0]) * (t[1] - e[1]) - (n[1] - e[1]) * (t[0] - e[0])) / i;
	return a >= -1e-7 && a <= 1 + 1e-7 && o >= -1e-7 && o <= 1 + 1e-7 ? [e[0] + a * (t[0] - e[0]), e[1] + a * (t[1] - e[1])] : null;
}
function te() {
	let e = h.flatMap((e, t) => e.central ? [
		[4, 4],
		[5, 4],
		[4, 5],
		[5, 5]
	].map((e) => ({
		id: t,
		p: e
	})) : [{
		id: t,
		p: y(t)
	}]), t = [];
	for (let n = 0; n < e.length; n++) for (let r = n + 1; r < e.length; r++) {
		let i = e[n], a = e[r], o = a.p[0] - i.p[0], s = a.p[1] - i.p[1];
		i.id === a.id || o !== 0 && s !== 0 && Math.abs(o) !== Math.abs(s) || e.some((e, t) => t !== n && t !== r && S(e.p, i.p, a.p)) || t.push({
			a: i.id,
			b: a.id,
			path: [i.p, a.p],
			green: !1
		});
	}
	return t;
}
var w = te(), T = (e, t) => e.a === t ? e.b : e.a;
function ne(e, t) {
	return e.order[t];
}
function E(e, t) {
	return e.lines[ne(e, t)];
}
function D(e) {
	return {
		order: e,
		lines: Array.from({ length: 4 }, () => ({
			stations: [],
			edges: [],
			doubled: [],
			extraDistricts: []
		})),
		jobs: [],
		stamps: []
	};
}
function O(e, t) {
	e.lines[e.order[t]].stations = [g[e.order[t]]];
}
function k(e) {
	return h.map((t, n) => e.lines.filter((e) => e.edges.length > 0 && e.stations.includes(n)).length + +!!v.includes(n));
}
function A(e) {
	let t = {};
	for (let n of e.edges.length ? e.stations : []) t[h[n].district] = (t[h[n].district] ?? 0) + 1 + +!!e.doubled.includes(n);
	let n = Object.keys(t).length + e.extraDistricts.length, r = Math.max(0, ...Object.values(t)), i = (e.edges.length ? e.stations : []).filter((e) => h[e].monument).length;
	return {
		areas: n,
		most: r,
		monuments: i,
		score: n * r + i * 2
	};
}
function j(e) {
	return _.map((t) => e.lines.flatMap((e) => e.edges).filter((e) => w[e].path.some((e, n, r) => n > 0 && S(t, r[n - 1], e))).length);
}
function M(e, t) {
	let n = new Set(e.lines.flatMap((e) => e.edges.length ? e.stations : [])), r = k(e);
	return new Set([...n].map((e) => h[e].district)), [
		r.filter((e) => e >= 3).length >= 3,
		e.lines.some((e) => new Set(e.stations.map((e) => h[e].district)).size >= 7),
		[...n].filter((e) => h[e].monument).length >= 6,
		j(e).filter((e) => e === 2).length >= 2,
		Array.from({ length: 8 }, (e, t) => h.every((e, r) => e.district !== t || n.has(r))).some(Boolean)
	][t];
}
function N(e, t, n, r) {
	let i = e.lines.map(A), a = k(e).reduce((e, t) => e + ([
		0,
		0,
		2,
		5,
		9
	][t] ?? 0), 0), o = j(e).reduce((e, t) => e + (t === 2 ? 6 : t === 1 ? 2 : 0), 0), s = e.stamps.reduce((e, t) => e + (t >= 9 ? 10 : 5), 0), c = t.filter((t) => M(e, t)).length * 10, l = r ? 10 * (Number(n.objectives) + Number(n.advanced)) : 0;
	return {
		lines: i,
		interchanges: a,
		crossings: o,
		stamps: s,
		penalty: 0,
		goals: c,
		handicap: l,
		total: i.reduce((e, t) => e + t.score, 0) + a + o + s + c - 0 - l
	};
}
function P(e) {
	return e.revealed.at(-1)?.split(":")[1] ?? "wild";
}
function F(e, t) {
	return t.jobs[0]?.kind === "base" && e.special?.shape === P(e);
}
function I(e, t) {
	let n = [e.a, e.b].filter((e) => e === t.a || e === t.b);
	for (let r = 1; r < e.path.length; r++) for (let i = 1; i < t.path.length; i++) {
		let a = C(e.path[r - 1], e.path[r], t.path[i - 1], t.path[i]);
		if (a && (a === "overlap" || !n.some((e) => h[e].central && a[0] >= 4 && a[0] <= 5 && a[1] >= 4 && a[1] <= 5 || b(a, y(e))) && !_.some((e) => b(e, a)))) return !0;
	}
	return !1;
}
function L(e, t, n = !1) {
	let r = t.jobs[0];
	if (!r || r.kind === "double" || r.kind === "district" || e.phase !== "play") return [];
	let i = E(t, e.round), a = P(e), o = n && F(e, t) ? e.special?.power : null, s = r.kind !== "base" || a === "wild" || o === "wild", c = r.kind === "switch" || r.kind === "base" && (e.switched || o === "switch"), l = r.from === void 0 ? c ? i.stations : i.stations.filter((e) => i.edges.filter((t) => w[t].a === e || w[t].b === e).length <= 1) : [r.from], u = t.lines.flatMap((e) => e.edges);
	return w.flatMap((e, t) => {
		let n = l.includes(e.a) ? e.a : l.includes(e.b) ? e.b : -1;
		if (n < 0) return [];
		let o = T(e, n), c = h[o];
		if (i.stations.includes(o) || !s && c.shape !== a && c.shape !== "wild") return [];
		if (r.kind === "extension") {
			if (e.path.length !== 2 || e.green) return [];
			let t = y(n), i = y(o);
			if (Math.sign(i[0] - t[0]) !== r.dx || Math.sign(i[1] - t[1]) !== r.dy) return [];
		}
		return u.filter((t) => {
			let n = w[t];
			return n.a === e.a && n.b === e.b || n.a === e.b && n.b === e.a;
		}).length + Number(e.green) > 0 || u.some((n) => n !== t && I(e, w[n])) ? [] : [t];
	});
}
//#endregion
//#region src/games/nextstation-paris/meta.ts
var R = {
	id: "nextstation-paris",
	tier: "alpha",
	releasedAt: "2026-11-04T00:50:00+08:00",
	nameKey: "games.nextstation-paris.name",
	descKey: "games.nextstation-paris.desc",
	rulesKey: "games.nextstation-paris.rules",
	icon: "🚇",
	iconImg: "games/nextstation-paris.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [
		1,
		2,
		3,
		4
	],
	hotseat: "open",
	accent: "#04a5d2",
	mechanics: ["roll-and-write", "route-building"],
	interactionTags: [],
	rulesUrl: { en: "https://blueorangegames.eu/wp-content/uploads/2024/03/NextStationParis-Rules-EN.pdf" },
	search: {
		py: "xia yi zhan ba li",
		init: "xyzbl"
	}
}, z = t.object({
	objectives: t.boolean().default(!1),
	advanced: t.boolean().default(!1)
}).prefault({}), B = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draw"),
		edge: t.int().min(0).max(500),
		boost: t.boolean().optional()
	}),
	t.object({
		type: t.literal("double"),
		station: t.int().min(0).max(60)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("activate") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), V = t.object({
	kind: t.enum([
		"base",
		"free",
		"switch",
		"tour",
		"extension",
		"double",
		"district"
	]),
	from: t.number().optional(),
	dx: t.number().optional(),
	dy: t.number().optional()
}), H = t.object({
	stations: t.array(t.number()),
	edges: t.array(t.number()),
	doubled: t.array(t.number()),
	extraDistricts: t.array(t.number())
}), re = t.object({
	lines: t.array(H).length(4),
	order: t.array(t.number()).length(4),
	jobs: t.array(V),
	stamps: t.array(t.number())
}), ie = t.object({
	players: t.array(t.string()),
	round: t.number(),
	phase: t.enum([
		"play",
		"turn-end",
		"round-score",
		"done"
	]),
	revealed: t.array(t.string()),
	metro: t.number(),
	switched: t.boolean(),
	boards: t.record(t.string(), re),
	objectives: t.array(t.number()),
	gates: t.array(t.string()),
	special: t.object({
		shape: t.string(),
		power: t.string()
	}).nullable(),
	config: z,
	scores: t.record(t.string(), t.number()),
	serial: t.number()
}), U = t.object({}), ae = 1500, W = [
	"square",
	"triangle",
	"circle",
	"pentagon"
], G = [
	...W.map((e) => "metro:" + e),
	"metro:wild",
	...W.map((e) => "street:" + e),
	"street:wild",
	"street:switch"
];
function K(e) {
	for (e.switched = !1;;) {
		let t = e.decks[e.round][++e.index];
		if (e.revealed.push(t), t.startsWith("metro:") && e.metro++, t.endsWith(":switch")) {
			e.switched = !0;
			continue;
		}
		break;
	}
	e.phase = "play", e.serial++;
	for (let t of e.players) e.boards[t].jobs = [{ kind: "base" }];
}
var q = {
	meta: R,
	saveCompatibility: { version: "1" },
	schemas: {
		action: B,
		config: z,
		publicView: ie,
		privateView: U
	},
	setup(t, n, r) {
		let i = 0;
		function a(t) {
			for (let n = t.length - 1; n > 0; n--) {
				let a = e(r, i++, n + 1);
				[t[n], t[a]] = [t[a], t[n]];
			}
			return t;
		}
		let o = Array.from({ length: 4 }, () => a([...G])), s = a([
			0,
			1,
			2,
			3
		]), c = a([...W]), l = a([
			"switch",
			"wild",
			"extension",
			"double"
		]), u = c.map((e, t) => ({
			shape: e,
			power: l[t]
		})), d = Object.fromEntries(n.map((e, t) => {
			let r = n.length === 2 ? t * 2 : t;
			return [e, D(Array.from({ length: 4 }, (e, t) => s[(t + r) % 4]))];
		})), f = {
			players: n,
			round: 0,
			phase: "play",
			decks: o,
			index: -1,
			revealed: [],
			metro: 0,
			switched: !1,
			boards: d,
			config: t,
			objectives: t.objectives ? a([
				0,
				1,
				2,
				3,
				4
			]).slice(0, 2) : [],
			gates: t.advanced ? a([
				"switch",
				"free",
				"district",
				"double"
			]) : [],
			special: (t.advanced, null),
			specials: u,
			scores: {},
			serial: 0
		};
		for (let e of Object.values(d)) O(e, 0);
		return K(f), { state: f };
	},
	reduce(e, t, n) {
		let r = (e) => ({ code: `games.${p}.${e}` });
		if (t.type === "tick") {
			if (n.by !== "$engine" || e.phase !== "turn-end" && e.phase !== "round-score") return r("errWait");
			let t = structuredClone(e);
			if (t.phase === "turn-end") t.metro >= 5 ? t.phase = "round-score" : K(t);
			else if (t.round === 3) t.phase = "done";
			else {
				t.round++, t.index = -1, t.metro = 0, t.revealed = [], t.special = (t.config.advanced, null);
				for (let e of Object.values(t.boards)) O(e, t.round);
				K(t);
			}
			return { state: t };
		}
		if (e.phase !== "play") return r("errWait");
		let i = e.boards[n.by];
		if (!i?.jobs.length) return r("errWait");
		let a = structuredClone(e), o = a.boards[n.by], s = E(o, a.round), c = o.jobs[0];
		if (t.type === "draw") {
			if (!L(e, i, t.boost).includes(t.edge)) return r("errMove");
			let n = w[t.edge], l = s.stations.includes(n.a) ? n.a : n.b, u = T(n, l), d = t.boost && F(a, o) ? a.special?.power : null;
			o.jobs.shift(), s.edges.push(t.edge), s.stations.push(u), d === "double" && s.doubled.push(u), c.kind === "base" && P(a) === "wild" && h[u].monument && o.jobs.unshift({
				kind: "tour",
				from: u
			}), d === "extension" && n.path.length === 2 && !n.green && o.jobs.unshift({
				kind: "extension",
				from: u,
				dx: Math.sign(h[u].x - h[l].x),
				dy: Math.sign(h[u].y - h[l].y)
			});
			let f = h[u].district;
			if (a.config.advanced && f >= 9) {
				let e = a.gates[f - 9];
				e === "district" && o.jobs.push({
					kind: "district",
					from: f
				}), e === "switch" && o.jobs.push({ kind: "switch" }), e === "free" && o.jobs.push({ kind: "free" }, { kind: "free" }), e === "double" && o.jobs.push({ kind: "double" });
			}
		} else if (t.type === "activate") {
			if (c.kind !== "district" || c.from === void 0) return r("errMove");
			s.extraDistricts.push(c.from), o.jobs.shift();
		} else if (t.type === "double") {
			let e = h[t.station];
			if (c.kind !== "double" || !e || !s.stations.includes(t.station) || e.monument || e.central || e.shape === "wild" || g.includes(t.station) || s.doubled.includes(t.station)) return r("errMove");
			s.doubled.includes(t.station) || s.doubled.push(t.station), o.jobs.shift();
		} else o.jobs.shift();
		return a.players.every((e) => !a.boards[e].jobs.length) && (a.phase = "turn-end"), { state: a };
	},
	nextTickIn(e) {
		return e.phase === "turn-end" ? 650 : e.phase === "round-score" ? ae : null;
	},
	viewFor(e) {
		return {
			public: {
				players: e.players,
				round: e.round,
				phase: e.phase,
				revealed: e.revealed,
				metro: e.metro,
				switched: e.switched,
				boards: e.boards,
				objectives: e.objectives,
				gates: e.gates,
				special: e.special,
				config: e.config,
				scores: Object.fromEntries(e.players.map((t) => [t, N(e.boards[t], e.objectives, e.config, e.players.length === 1).total])),
				serial: e.serial
			},
			private: {}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Object.fromEntries(e.players.map((t) => [t, N(e.boards[t], e.objectives, e.config, e.players.length === 1).total])), n = Object.fromEntries(e.players.map((t) => [t, Math.max(...e.boards[t].lines.map((e) => A(e).score))])), r = [...e.players].sort((e, r) => t[r] - t[e] || n[r] - n[e]);
		return {
			phase: "done",
			ranking: r,
			scores: t,
			winner: r.filter((e) => t[e] === t[r[0]] && n[e] === n[r[0]])
		};
	}
};
//#endregion
//#region src/games/nextstation-paris/view-player.tsx
function J() {
	let e = a();
	return (t, n) => e(`games.nextstation-paris.${t}`, n);
}
var Y = [
	"color0",
	"color1",
	"color2",
	"color3"
], oe = {
	square: "shapeSquare",
	triangle: "shapeTriangle",
	circle: "shapeCircle",
	pentagon: "shapePentagon",
	wild: "shapeWild"
}, se = {
	switch: "powerSwitch",
	free: "powerFree",
	district: "district",
	double: "powerDouble",
	wild: "powerWild",
	extension: "powerExtension"
}, X = (e) => `${50 + e[0] * 100},${50 + e[1] * 100}`, Z = (e, t = !1) => "M" + (t ? [...w[e].path].reverse() : w[e].path).map(X).join("L");
function Q({ shape: e, size: t = 26 }) {
	return /* @__PURE__ */ u("svg", {
		width: t,
		height: t,
		viewBox: "-16 -16 32 32",
		"aria-hidden": "true",
		fill: "currentColor",
		children: e === "monument" ? /* @__PURE__ */ d("g", {
			fill: "#22265e",
			children: [
				/* @__PURE__ */ u("path", { d: "M0 -16 5 -11 11 -11 11 -5 16 0 11 5 11 11 5 11 0 16 -5 11 -11 11 -11 5 -16 0 -11 -5 -11 -11 -5 -11Z" }),
				/* @__PURE__ */ u("circle", {
					r: "11",
					fill: "#fffdf3"
				}),
				/* @__PURE__ */ u("path", { d: "M-3 -4V-7Q-3 -10 0 -10T3 -7V-4H7Q10 -4 10 0T7 4H3V7Q3 10 0 10T-3 7V4H-7Q-10 4 -10 0T-7 -4Z" }),
				/* @__PURE__ */ u("circle", {
					r: "2.7",
					fill: "#fffdf3"
				})
			]
		}) : /* @__PURE__ */ u("g", {
			fill: "none",
			stroke: "currentColor",
			strokeWidth: e === "wild" ? 1.5 : 2.5,
			strokeLinejoin: "round",
			children: e === "square" ? /* @__PURE__ */ u("rect", {
				x: "-9",
				y: "-9",
				width: "18",
				height: "18"
			}) : e === "triangle" ? /* @__PURE__ */ u("path", { d: "M0 -11 11 9 -11 9Z" }) : e === "circle" ? /* @__PURE__ */ u("circle", { r: "10" }) : e === "pentagon" ? /* @__PURE__ */ u("path", { d: "M0 -11 11 -4 7 10 -7 10 -11 -4Z" }) : /* @__PURE__ */ d(l, { children: [
				/* @__PURE__ */ u("circle", {
					cx: "-8",
					cy: "-8",
					r: "7.3"
				}),
				/* @__PURE__ */ u("circle", {
					cx: "8",
					cy: "-8",
					r: "7.3"
				}),
				/* @__PURE__ */ u("circle", {
					cx: "-8",
					cy: "8",
					r: "7.3"
				}),
				/* @__PURE__ */ u("circle", {
					cx: "8",
					cy: "8",
					r: "7.3"
				}),
				/* @__PURE__ */ u("rect", {
					x: "-11.5",
					y: "-11.5",
					width: "7",
					height: "7"
				}),
				/* @__PURE__ */ u("path", { d: "M8 -12 12 -5 4 -5ZM-8 4 -3.8 7 -5.4 12 -10.6 12 -12.2 7Z" }),
				/* @__PURE__ */ u("circle", {
					cx: "8",
					cy: "8",
					r: "3.8"
				})
			] })
		})
	});
}
function ce() {
	return /* @__PURE__ */ d("svg", {
		width: "66",
		height: "28",
		viewBox: "0 0 82 32",
		"aria-hidden": "true",
		fill: "currentColor",
		children: [
			/* @__PURE__ */ u("text", {
				x: "0",
				y: "24",
				fontSize: "26",
				children: "/"
			}),
			/* @__PURE__ */ u("g", {
				transform: "translate(14 2)",
				children: /* @__PURE__ */ u(Q, {
					shape: "monument",
					size: 28
				})
			}),
			/* @__PURE__ */ u("text", {
				x: "43",
				y: "24",
				fontSize: "23",
				children: "+"
			}),
			/* @__PURE__ */ u("g", {
				transform: "translate(55 2)",
				children: /* @__PURE__ */ u(Q, {
					shape: "wild",
					size: 28
				})
			})
		]
	});
}
function le() {
	return /* @__PURE__ */ u("svg", {
		viewBox: "0 0 140 62",
		width: "100",
		height: "44",
		"aria-hidden": "true",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "3",
		children: /* @__PURE__ */ d(l, { children: [
			/* @__PURE__ */ u("path", { d: "M28 4 15 55M28 4 42 55M19 38H37M15 48H41M8 56H49M21 28H34M24 18H32M23 55Q28 42 34 55" }),
			/* @__PURE__ */ u("rect", {
				x: "66",
				y: "20",
				width: "62",
				height: "26",
				rx: "13"
			}),
			/* @__PURE__ */ u("path", { d: "M78 34V27L85 35 92 27V40M104 27V40M108 27H117M112 27V40M74 46V59M122 46V59" })
		] })
	});
}
function ue({ board: e, selected: t, eligible: r, previews: i = [] }) {
	let a = J(), o = n().replaceAll(":", "");
	return /* @__PURE__ */ d("g", {
		className: "nsc-map-art",
		children: [
			/* @__PURE__ */ u("rect", {
				width: "1000",
				height: "1000",
				rx: "22",
				fill: "#fff9df"
			}),
			/* @__PURE__ */ d("g", {
				fill: "none",
				children: [/* @__PURE__ */ u("path", {
					d: "M-30 360C130 330 100 700 400 730S620 360 1030 370",
					stroke: "#78cddd",
					strokeWidth: "22",
					opacity: ".35"
				}), /* @__PURE__ */ u("g", {
					stroke: "#e7be33",
					strokeWidth: "6",
					children: /* @__PURE__ */ u("path", { d: "M0 200H1000M0 500H1000M0 800H1000M500 0V1000M0 100H100V0M900 0V100H1000M0 900H100V1000M900 1000V900H1000" })
				})]
			}),
			/* @__PURE__ */ u("g", {
				fill: "none",
				stroke: "#a5a5a0",
				strokeWidth: "2.4",
				strokeDasharray: "5 9",
				opacity: ".62",
				children: w.filter((e) => !e.green).map((e, t) => /* @__PURE__ */ u("path", { d: "M" + e.path.map(X).join("L") }, t))
			}),
			!1,
			_.map((e, t) => /* @__PURE__ */ d("g", {
				transform: `translate(${X(e).replace(",", " ")})`,
				children: [
					/* @__PURE__ */ u("circle", {
						r: "20",
						fill: "#fff9df"
					}),
					/* @__PURE__ */ u("path", {
						d: "M-17 -12 17 12M-17 12 17 -12",
						fill: "none",
						stroke: "#293c54",
						strokeWidth: "5"
					}),
					/* @__PURE__ */ u("path", {
						d: "M-14 -17 20 7M-20 -7 14 17",
						stroke: "#fff9df",
						strokeWidth: "3"
					})
				]
			}, t)),
			e.lines.map((t, n) => t.edges.map((r, i) => {
				let a = e.lines.some((e, t) => t < n && e.edges.includes(r)) || w[r].green, s = o + "-" + n + "-" + r, c = Z(r, w[r].a === t.stations[i + 1]);
				return /* @__PURE__ */ d("g", { children: [
					/* @__PURE__ */ u("defs", { children: /* @__PURE__ */ u("mask", {
						id: s,
						maskUnits: "userSpaceOnUse",
						x: "0",
						y: "0",
						width: "1000",
						height: "1000",
						children: /* @__PURE__ */ u("path", {
							className: "nsc-line-reveal",
							style: { animationDuration: "650ms" },
							d: c,
							pathLength: "1",
							fill: "none",
							stroke: "white",
							strokeWidth: "22",
							strokeDasharray: "1",
							strokeDashoffset: "0",
							strokeLinecap: "round"
						})
					}) }),
					!a && /* @__PURE__ */ u("path", {
						d: Z(r),
						fill: "none",
						stroke: "#fffdf0",
						strokeWidth: "16",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ u("path", {
						className: "nsc-drawn",
						mask: `url(#${s})`,
						d: c,
						pathLength: "1",
						fill: "none",
						stroke: m[n],
						strokeWidth: a ? 7 : 10,
						strokeDasharray: a ? "0.025 0.012" : void 0,
						strokeLinecap: "round",
						strokeLinejoin: "round"
					})
				] }, `${n}-${r}`);
			})),
			i.map((e, t) => /* @__PURE__ */ d("g", { children: [/* @__PURE__ */ u("path", {
				d: Z(e),
				stroke: "#162c42",
				strokeWidth: "6",
				strokeDasharray: "12 9",
				fill: "none",
				children: /* @__PURE__ */ u("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-21",
					dur: ".7s",
					repeatCount: "indefinite"
				})
			}), /* @__PURE__ */ u("text", {
				x: 50 + w[e].path[0][0] * 100 + 24,
				y: 50 + w[e].path[0][1] * 100 - 24,
				fontSize: "24",
				fill: "#172d41",
				children: t + 1
			})] }, e)),
			h.map((n, i) => {
				let o = 50 + n.x * 100, s = 50 + n.y * 100, c = g.indexOf(i), l = r.includes(i), f = t === i;
				return /* @__PURE__ */ d("g", {
					transform: `translate(${o} ${s})`,
					children: [
						/* @__PURE__ */ u("title", { children: n.central ? a("center") : a("station", { n: i + 1 }) }),
						n.central ? /* @__PURE__ */ u("circle", {
							r: "65",
							fill: "#fdfbf0",
							stroke: "#22265e",
							strokeWidth: "5"
						}) : n.monument ? /* @__PURE__ */ u("g", {
							transform: "translate(-28 -28)",
							color: "#22265e",
							children: /* @__PURE__ */ u(Q, {
								shape: "monument",
								size: 56
							})
						}) : /* @__PURE__ */ u("circle", {
							r: "22",
							fill: c >= 0 ? m[c] : "#fffdf3",
							stroke: v.includes(i) ? "#4c9b43" : "#26394e",
							strokeWidth: "3"
						}),
						n.central ? /* @__PURE__ */ d("g", {
							fill: "#25394e",
							children: [
								/* @__PURE__ */ u("path", { d: "M-29 -42 -16 -18 -42 -18ZM29 -42 42 -33 37 -18 21 -18 16 -33Z" }),
								/* @__PURE__ */ u("circle", {
									cx: "-29",
									cy: "29",
									r: "12"
								}),
								/* @__PURE__ */ u("rect", {
									x: "17",
									y: "17",
									width: "23",
									height: "23"
								})
							]
						}) : n.monument ? null : /* @__PURE__ */ u("g", {
							transform: "translate(-14 -14)",
							color: c >= 0 ? "#fff" : "#24374b",
							children: /* @__PURE__ */ u(Q, {
								shape: n.shape,
								size: 28
							})
						}),
						c >= 0 && /* @__PURE__ */ u("text", {
							x: "26",
							y: "-22",
							fontSize: "25",
							fontWeight: "900",
							fill: m[c],
							stroke: "#fffdf3",
							strokeWidth: "5",
							paintOrder: "stroke",
							children: c + 1
						}),
						e.lines.some((e) => e.doubled.includes(i)) && /* @__PURE__ */ u("text", {
							x: "18",
							y: "35",
							fontSize: "24",
							fontWeight: "900",
							fill: "#25394e",
							stroke: "#fff",
							strokeWidth: "4",
							paintOrder: "stroke",
							children: "×2"
						}),
						(l || f) && /* @__PURE__ */ d("g", {
							fill: "none",
							children: [/* @__PURE__ */ u("circle", {
								r: n.central ? 76 : 37,
								stroke: "#fff",
								strokeWidth: "9"
							}), /* @__PURE__ */ u("circle", {
								r: n.central ? 76 : 37,
								stroke: f ? "#e95a37" : "#17384c",
								strokeWidth: "5",
								strokeDasharray: "9 7",
								children: /* @__PURE__ */ u("animate", {
									attributeName: "stroke-dashoffset",
									from: "0",
									to: "-16",
									dur: ".7s",
									repeatCount: "indefinite"
								})
							})]
						})
					]
				}, i);
			})
		]
	});
}
function de({ pub: e, rid: t, includeGoals: n = !0 }) {
	let r = J(), i = e.boards[t], a = N(i, e.objectives, e.config, e.players.length === 1), o = [
		"interchanges",
		"crossings",
		...e.objectives.length ? ["goals"] : [],
		...a.handicap ? ["handicap"] : []
	];
	return /* @__PURE__ */ d("div", {
		className: "nsc-detail-body",
		children: [
			/* @__PURE__ */ u("div", {
				className: "nsc-line-ledger",
				children: a.lines.map((e, t) => /* @__PURE__ */ d("div", {
					style: { "--line": m[t] },
					children: [
						/* @__PURE__ */ d("strong", { children: [
							t + 1,
							" · ",
							r(Y[t])
						] }),
						/* @__PURE__ */ d("span", { children: [
							e.areas,
							" × ",
							e.most,
							` + ${e.monuments} × 2`
						] }),
						/* @__PURE__ */ u("b", { children: e.score })
					]
				}, t))
			}),
			/* @__PURE__ */ d("dl", {
				className: "nsc-breakdown",
				children: [o.map((e) => /* @__PURE__ */ d("div", { children: [/* @__PURE__ */ u("dt", { children: r(e) }), /* @__PURE__ */ d("dd", { children: [e === "penalty" || e === "handicap" ? "−" : "", a[e]] })] }, e)), /* @__PURE__ */ d("div", { children: [/* @__PURE__ */ u("dt", { children: r("score") }), /* @__PURE__ */ u("dd", { children: a.total })] })]
			}),
			n && e.objectives.map((e) => /* @__PURE__ */ d("p", {
				className: "nsc-goal",
				children: [
					/* @__PURE__ */ u("b", { children: M(i, e) ? "✓" : "○" }),
					r(`goal${e}`),
					/* @__PURE__ */ u("span", { children: "10" })
				]
			}, e))
		]
	});
}
function fe({ public: e, members: t, myRid: n, send: a }) {
	let f = e, p = J(), _ = i((e) => e.locale), [v, y] = r(n), [b, x] = r(null), [S, C] = r(!1), [te, ne] = r(0), D = f.boards[v] ? v : f.players[0], O = f.boards[D], k = E(O, f.round), A = O.jobs[0], j = D === n && f.phase === "play" && !!A, I = JSON.stringify(A), R = b?.serial === f.serial && b.job === I ? b : null, z = R?.boost ?? !1, B = R?.start ?? null, V = R?.target ?? null, H = j ? L(f, O, z) : [], re = [...new Set(H.map((e) => k.stations.includes(w[e].a) ? w[e].a : w[e].b))], ie = B === null ? [] : [...new Set(H.filter((e) => w[e].a === B || w[e].b === B).map((e) => T(w[e], B)))], U = V === null ? [] : H.filter((e) => w[e].a === B && w[e].b === V || w[e].b === B && w[e].a === V), ae = j && A?.kind === "double" ? k.stations.filter((e) => !g.includes(e) && !h[e].monument && !h[e].central && !k.doubled.includes(e)) : [], W = j ? A.kind === "double" ? ae : B === null ? re : ie : [], G = (e) => {
		if (!j) return;
		if (A.kind === "double") {
			a({
				type: "double",
				station: e
			}), x(null);
			return;
		}
		if (B === null) {
			x({
				serial: f.serial,
				job: I,
				start: e,
				target: null,
				boost: z
			});
			return;
		}
		let t = H.filter((t) => w[t].a === B && w[t].b === e || w[t].b === B && w[t].a === e);
		t.length === 1 ? (a({
			type: "draw",
			edge: t[0],
			boost: z
		}), x(null)) : t.length > 1 && x({
			serial: f.serial,
			job: I,
			start: B,
			target: e,
			boost: z
		});
	}, K = P(f), q = O.order[f.round], X = j ? A.kind === "double" ? p("double") : A.kind === "district" ? p("district") : V === null ? A.kind === "tour" ? p("tour") : A.kind === "extension" ? p("extension") : A.kind === "free" ? p("free") : A.kind === "switch" || f.switched ? p("switch") : p(B === null ? "draw" : "target") : p("chooseEntrance") : f.phase === "round-score" ? p("scoring") : f.phase === "done" ? p("over") : p("waiting"), Z = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? c(n, _) : e;
	}, fe = /* @__PURE__ */ d("div", {
		className: "nsc-card",
		"data-metro": f.revealed.at(-1)?.startsWith("metro:"),
		children: [
			/* @__PURE__ */ u("div", { children: f.revealed.at(-1)?.startsWith("metro:") ? p("underground") : p("street") }),
			/* @__PURE__ */ u(Q, {
				shape: K,
				size: 74
			}),
			/* @__PURE__ */ d("strong", { children: [p(K === "wild" ? "cardWild" : oe[K]), K === "wild" && /* @__PURE__ */ u("span", {
				className: "nsc-rail",
				children: /* @__PURE__ */ u(ce, {})
			})] }),
			/* @__PURE__ */ u("span", { children: f.metro === 5 ? p("last") : p("metro", { n: f.metro }) })
		]
	}, f.serial), $ = /* @__PURE__ */ d(l, { children: [
		f.special && /* @__PURE__ */ d("div", {
			className: "nsc-module",
			children: [/* @__PURE__ */ u("b", { children: p("special") }), /* @__PURE__ */ d("span", { children: [/* @__PURE__ */ u(Q, { shape: f.special.shape }), p(se[f.special.power])] })]
		}),
		!!f.gates.length && /* @__PURE__ */ d("div", {
			className: "nsc-module",
			children: [/* @__PURE__ */ u("b", { children: p("gates") }), /* @__PURE__ */ u("div", {
				className: "nsc-gates",
				children: f.gates.map((e, t) => /* @__PURE__ */ d("span", { children: [
					[
						"↖",
						"↗",
						"↙",
						"↘"
					][t],
					" ",
					p(se[e])
				] }, t))
			})]
		}),
		f.objectives.map((e) => /* @__PURE__ */ d("div", {
			className: "nsc-goal",
			children: [/* @__PURE__ */ u("b", { children: M(O, e) ? "✓" : "○" }), p(`goal${e}`)]
		}, e))
	] });
	return /* @__PURE__ */ d(s, {
		adaptive: !0,
		scroll: !1,
		className: `nsc nsc-${ee}`,
		banner: /* @__PURE__ */ d("header", {
			className: "nsc-header",
			children: [/* @__PURE__ */ d("div", {
				className: "nsc-brand",
				children: [/* @__PURE__ */ u(le, {}), /* @__PURE__ */ d("div", { children: [/* @__PURE__ */ u("h1", { children: p("name") }), /* @__PURE__ */ d("p", { children: [
					p("round", { n: f.round + 1 }),
					" · ",
					/* @__PURE__ */ d("span", {
						style: { color: m[q] },
						children: [
							q + 1,
							" ",
							p(Y[q])
						]
					})
				] })] })]
			}), /* @__PURE__ */ d("div", {
				className: "nsc-total",
				children: [/* @__PURE__ */ u("span", { children: p("score") }), /* @__PURE__ */ u("b", { children: f.scores[D] ?? 0 })]
			})]
		}),
		actionsHeight: "nsc-actions-height",
		actions: /* @__PURE__ */ d("div", {
			className: "nsc-actions",
			children: [
				/* @__PURE__ */ d("div", {
					className: "nsc-mobile-card",
					children: [
						/* @__PURE__ */ u(Q, { shape: K }),
						K === "wild" && /* @__PURE__ */ u(ce, {}),
						/* @__PURE__ */ u("span", { children: p(K === "wild" ? "cardWild" : oe[K]) }),
						/* @__PURE__ */ u("small", { children: p("metro", { n: f.metro }) })
					]
				}),
				/* @__PURE__ */ u("div", {
					className: "nsc-prompt",
					"aria-live": "polite",
					children: X
				}),
				/* @__PURE__ */ d("div", {
					className: "nsc-action-row",
					children: [
						j && F(f, O) && /* @__PURE__ */ d("label", {
							className: "nsc-boost",
							children: [/* @__PURE__ */ u("input", {
								type: "checkbox",
								checked: z,
								onChange: (e) => x({
									serial: f.serial,
									job: I,
									start: null,
									target: null,
									boost: e.target.checked
								})
							}), p("boost")]
						}),
						j && A.kind === "district" && /* @__PURE__ */ u("button", {
							onClick: () => a({ type: "activate" }),
							children: p("activate")
						}),
						j && V !== null ? U.map((e, t) => /* @__PURE__ */ u("button", {
							onClick: () => {
								a({
									type: "draw",
									edge: e,
									boost: z
								}), x(null);
							},
							children: p("entrance", { n: t + 1 })
						}, e)) : j && W.length > 0 && /* @__PURE__ */ d("select", {
							"aria-label": X,
							value: "",
							onChange: (e) => G(Number(e.target.value)),
							children: [/* @__PURE__ */ u("option", {
								value: "",
								children: A.kind === "double" ? p("double") : p(B === null ? "draw" : "target")
							}), W.map((e) => /* @__PURE__ */ u("option", {
								value: e,
								children: h[e].central ? p("center") : p("station", { n: e + 1 })
							}, e))]
						}),
						j && B !== null && /* @__PURE__ */ u("button", {
							className: "nsc-quiet",
							onClick: () => x(null),
							children: p("cancel")
						}),
						/* @__PURE__ */ u("button", {
							className: "nsc-pass",
							disabled: !j,
							onClick: () => {
								a({ type: "pass" }), x(null);
							},
							children: p("pass")
						})
					]
				})
			]
		}),
		children: [/* @__PURE__ */ d("div", {
			className: "nsc-workspace",
			children: [/* @__PURE__ */ d("section", {
				className: "nsc-map-panel",
				children: [
					/* @__PURE__ */ d("div", {
						className: "nsc-map-tools",
						children: [
							/* @__PURE__ */ u("select", {
								"aria-label": p("network"),
								value: D,
								onChange: (e) => {
									y(e.target.value), x(null);
								},
								children: f.players.map((e) => /* @__PURE__ */ u("option", {
									value: e,
									children: Z(e)
								}, e))
							}),
							/* @__PURE__ */ u("button", {
								onClick: () => ne((e) => e + 1),
								children: p("fullMap")
							}),
							/* @__PURE__ */ u("button", {
								onClick: () => C(!0),
								children: p("details")
							})
						]
					}),
					/* @__PURE__ */ u("div", {
						className: "nsc-map",
						children: /* @__PURE__ */ u(o, {
							sheetW: 1e3,
							sheetH: 1e3,
							fitKey: `${D}:${te}`,
							clampToSheet: !0,
							highlight: "off",
							readOnly: !j,
							eligible: W.map((e) => ({
								key: String(e),
								rect: {
									x: 50 + h[e].x * 100 - (h[e].central ? 65 : 42),
									y: 50 + h[e].y * 100 - (h[e].central ? 65 : 42),
									w: h[e].central ? 130 : 84,
									h: h[e].central ? 130 : 84
								}
							})),
							onTapEligible: (e) => G(Number(e)),
							children: /* @__PURE__ */ u(ue, {
								board: O,
								selected: B,
								eligible: W,
								previews: U
							})
						})
					}),
					/* @__PURE__ */ u("div", {
						className: "nsc-mini-lines",
						children: O.order.map((e, t) => /* @__PURE__ */ d("div", {
							"data-current": t === f.round,
							style: { "--line": m[e] },
							children: [
								/* @__PURE__ */ u("span", { children: t + 1 }),
								/* @__PURE__ */ d("b", { children: [
									e + 1,
									" ",
									p(Y[e])
								] }),
								/* @__PURE__ */ u("strong", { children: N(O, [], f.config, !1).lines[e].score })
							]
						}, t))
					}),
					/* @__PURE__ */ u("div", {
						className: "nsc-mobile-modules",
						children: $
					})
				]
			}), /* @__PURE__ */ d("aside", {
				className: "nsc-sidebar",
				children: [
					fe,
					/* @__PURE__ */ u(de, {
						pub: f,
						rid: D,
						includeGoals: !1
					}),
					$
				]
			})]
		}), S && /* @__PURE__ */ u("div", {
			className: "nsc-modal",
			role: "dialog",
			"aria-label": p("details"),
			onKeyDown: (e) => {
				e.key === "Escape" && C(!1);
			},
			children: /* @__PURE__ */ d("section", { children: [/* @__PURE__ */ d("header", { children: [/* @__PURE__ */ u("h2", { children: p("playerBoard", { name: Z(D) }) }), /* @__PURE__ */ u("button", {
				autoFocus: !0,
				onClick: () => C(!1),
				children: p("close")
			})] }), /* @__PURE__ */ d("div", {
				className: "nsc-modal-scroll",
				children: [/* @__PURE__ */ u(de, {
					pub: f,
					rid: D,
					includeGoals: !1
				}), $]
			})] })
		})]
	});
}
//#endregion
//#region src/games/nextstation-paris/bot.ts
function $(e, t, n = 0) {
	let r = e.boards[t];
	if (e.phase !== "play" || !r?.jobs.length) return null;
	let i = r.jobs[0], a = E(r, e.round);
	if (i.kind === "district") return { type: "activate" };
	if (i.kind === "double") {
		let t = a.stations.filter((e) => !g.includes(e) && !h[e].central && !h[e].monument && !a.doubled.includes(e)), n = { type: "pass" }, i = -Infinity;
		for (let a of t) {
			let t = structuredClone(r);
			E(t, e.round).doubled.push(a);
			let o = N(t, e.objectives, e.config, e.players.length === 1).total;
			o > i && (n = {
				type: "double",
				station: a
			}, i = o);
		}
		return n;
	}
	let o = [!1, ...F(e, r) ? [!0] : []].flatMap((t) => L(e, r, t).map((e) => ({
		edge: e,
		boost: t
	}))), s = { type: "pass" }, c = -Infinity;
	for (let t of o) {
		let i = structuredClone(r), a = E(i, e.round), o = T(w[t.edge], a.stations.includes(w[t.edge].a) ? w[t.edge].a : w[t.edge].b);
		a.edges.push(t.edge), a.stations.push(o), t.boost && e.special?.power === "double" && a.doubled.push(o);
		let l = N(i, e.objectives, e.config, e.players.length === 1).total, u = w.filter((e) => (e.a === o || e.b === o) && !a.stations.includes(T(e, o))).length;
		if (l += u * .15, h[o].district >= 9 && e.config.advanced && (l += e.gates[h[o].district - 9] === "free" ? 3 : 1.5), h[o].monument && e.revealed.at(-1)?.endsWith(":wild") && (l += 2), t.boost && e.special?.power === "extension" && (l += 1), n) {
			let t = 0;
			for (let n of [
				"square",
				"triangle",
				"circle",
				"pentagon"
			]) {
				let r = L({
					...e,
					revealed: [...e.revealed, "street:" + n],
					switched: !1
				}, i);
				t += r.length ? Math.max(...r.map((t) => {
					let n = structuredClone(i), r = E(n, e.round);
					return r.stations.push(T(w[t], r.stations.includes(w[t].a) ? w[t].a : w[t].b)), r.edges.push(t), N(n, e.objectives, e.config, e.players.length === 1).total - l;
				})) : 0;
			}
			l += n * t / 4;
		}
		l > c && (c = l, s = {
			type: "draw",
			...t
		});
	}
	return s;
}
var pe = (e, t) => {
	let n = e.public, r = n.boards[t.rid];
	if (n.phase !== "play" || !r?.jobs.length) return null;
	if (t.difficulty === "weak" && !["double", "district"].includes(r.jobs[0].kind)) {
		let e = L(n, r);
		return { action: e.length ? {
			type: "draw",
			edge: e[Math.floor(Math.random() * e.length)]
		} : { type: "pass" } };
	}
	let i = $(n, t.rid, .6);
	return i ? { action: i } : null;
}, me = (e, t, n) => n(e.type === "pass" ? "games.nextstation-paris.hintPass" : "games.nextstation-paris.hintDraw");
//#endregion
//#region src/games/nextstation-paris/game-over.tsx
function he(e) {
	let t = J(), n = a(), o = i((e) => e.locale), s = e.public, [f, p] = r(!0), [m, h] = r(null), g = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? c(n, o) : t;
	};
	return /* @__PURE__ */ d("div", {
		className: `nsc-end nsc-${ee}`,
		children: [
			/* @__PURE__ */ u("div", {
				className: "nsc-end-board",
				inert: f,
				children: /* @__PURE__ */ u(fe, {
					public: e.public,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ u("div", {
				className: "nsc-end-overlay",
				hidden: !f,
				children: /* @__PURE__ */ d("section", {
					className: "nsc-end-panel",
					role: "dialog",
					"aria-label": t("over"),
					onKeyDown: (e) => {
						e.key === "Escape" && (p(!1), h(null));
					},
					children: [
						/* @__PURE__ */ d("header", {
							className: "nsc-end-heading",
							children: [/* @__PURE__ */ d("div", { children: [/* @__PURE__ */ u("h1", { children: t("name") }), /* @__PURE__ */ u("p", { children: t("over") })] }), /* @__PURE__ */ u("button", {
								onClick: () => {
									p(!1), h(null);
								},
								children: t("network")
							})]
						}),
						/* @__PURE__ */ d("div", {
							className: "nsc-end-body",
							inert: !!m,
							children: [e.result.ranking.map((r, i) => {
								let a = e.result.winner.includes(r);
								return /* @__PURE__ */ d("article", {
									className: "nsc-result-player",
									"data-winner": a,
									children: [
										/* @__PURE__ */ d("h2", { children: [/* @__PURE__ */ d("span", { children: [
											a ? "♛" : i + 1,
											" ",
											g(r),
											r === e.myRid ? " · " + n("lobby.you") : ""
										] }), /* @__PURE__ */ u("b", { children: e.result.scores?.[r] ?? s.scores[r] })] }),
										a && /* @__PURE__ */ u("p", { children: t(e.result.winner.length > 1 ? "tied" : "winner") }),
										!!e.result.autopilot?.[r] && /* @__PURE__ */ u("p", { children: n("session.autopilot.share", { n: Math.round(e.result.autopilot[r] * 100) }) }),
										/* @__PURE__ */ u(de, {
											pub: s,
											rid: r
										})
									]
								}, r);
							}), e.hintCount !== void 0 && /* @__PURE__ */ u("p", { children: n("session.hint.usedCount", { n: e.hintCount }) })]
						}),
						/* @__PURE__ */ u("footer", {
							className: "nsc-end-actions",
							children: m ? /* @__PURE__ */ d("div", {
								className: "nsc-confirm",
								children: [/* @__PURE__ */ u("button", {
									autoFocus: !0,
									onClick: () => {
										let t = m === "again" ? e.onPlayAgain : e.onBackToLobby;
										h(null), t?.();
									},
									children: t(m === "again" ? "confirmAgain" : "confirmLobby")
								}), /* @__PURE__ */ u("button", {
									onClick: () => h(null),
									children: t("cancel")
								})]
							}) : /* @__PURE__ */ d(l, { children: [
								e.onPlayAgain && /* @__PURE__ */ u("button", {
									className: "nsc-primary",
									onClick: () => h("again"),
									children: t("again")
								}),
								e.onBackToLobby && /* @__PURE__ */ u("button", {
									onClick: () => h("lobby"),
									children: t("lobby")
								}),
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ u("span", { children: t("waitHost") })
							] })
						})
					]
				})
			}),
			/* @__PURE__ */ u("button", {
				hidden: f,
				className: "nsc-end-restore",
				onClick: () => p(!0),
				children: t("results")
			})
		]
	});
}
//#endregion
//#region src/games/nextstation-paris/options.tsx
function ge({ value: e, onChange: t }) {
	let n = z.safeParse(e), r = n.success ? n.data : z.parse(void 0), i = J();
	return /* @__PURE__ */ d("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ u(f, {
			checked: r.objectives,
			label: i("objectivesOption"),
			hint: i("objectivesHint"),
			accent: R.accent,
			onChange: () => t({
				...r,
				objectives: !r.objectives
			})
		}), /* @__PURE__ */ u(f, {
			checked: r.advanced,
			label: i("advancedOption"),
			hint: i("advancedHint"),
			accent: R.accent,
			onChange: () => t({
				...r,
				advanced: !r.advanced
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/nextstation-paris/entry.tsx
var _e = {
	definition: q,
	View: fe,
	bot: pe,
	describe: me,
	OverView: he,
	Options: ge,
	locales: {
		zh: {
			name: "下一站：巴黎",
			desc: "连接巴黎名胜，巧用中央站台与高架桥",
			round: "第 {{n}} / 4 轮",
			metro: "地铁牌 {{n}} / 5",
			street: "街道",
			underground: "地铁",
			draw: "选择线路起点",
			target: "选择要连接的车站",
			double: "选择计为两站的普通站",
			waiting: "等待其他玩家",
			scoring: "线路结算",
			over: "规划完成",
			cancel: "取消选择",
			boost: "使用本轮能力",
			tour: "导览：从刚到达的名胜继续连接",
			free: "额外连接任意车站",
			switch: "道岔：可从线路任一站出发",
			extension: "沿刚才的方向继续连接",
			cardWild: "自由入站／导览",
			score: "总分",
			line: "线路",
			areas: "区数",
			most: "单区最多站",
			monuments: "名胜",
			crossings: "高架桥",
			interchanges: "换乘",
			stamps: "旅客印章",
			penalty: "未连接环站",
			goals: "共同目标",
			handicap: "单人模块扣分",
			details: "查看计分与目标",
			close: "关闭",
			objectivesOption: "共同目标",
			objectivesHint: "随机公开两个目标，完成每个目标获得 10 分。",
			advancedOption: "城市大门",
			advancedHint: "四个角落车站各有一项即时奖励。",
			gates: "城市大门",
			special: "特殊站点",
			district: "区域计为两区",
			powerDouble: "车站计为两站",
			powerWild: "百搭与双轨",
			powerExtension: "直线延伸",
			powerSwitch: "道岔",
			powerFree: "自由连接两次",
			network: "查看线路图",
			results: "查看结算",
			again: "再来一局",
			lobby: "返回大厅",
			confirm: "确认",
			waitHost: "等待主机开启下一局",
			hintDraw: "沿虚线从当前线路连接目标车站。",
			hintPass: "跳过当前连接机会。",
			errWait: "请等待当前步骤结束。",
			errMove: "这条线路不符合当前连接条件。",
			playerBoard: "{{name}}的线路图",
			station: "车站 {{n}}",
			color0: "橙线",
			color1: "绿线",
			color2: "紫线",
			color3: "蓝线",
			shapeSquare: "方形",
			shapeTriangle: "三角形",
			shapeCircle: "圆形",
			shapePentagon: "五边形",
			shapeWild: "任意符号",
			last: "本轮最后一张",
			completed: "已完成",
			pending: "未完成",
			noMoves: "没有合法线路，可跳过",
			goal0: "至少三个换乘站各连接三条线路",
			goal1: "一条线路经过至少七区",
			goal2: "连接至少六处不同名胜",
			goal3: "至少两座高架桥双向通行",
			goal4: "连接一个主要区内的全部车站",
			pass: "跳过",
			rules: "目标：规划四条不同颜色的地铁线，争取最高总分。\n流程：\n· 共四轮，每轮使用一支新颜色的铅笔，从同色始发站开始。每位玩家的颜色顺序显示在线路计分栏。\n· 每轮将 11 张站点牌洗混，逐张公开。所有玩家各自画一段或跳过；第五张地铁牌处理完后结束本轮。街道牌有 6 张，地铁牌有 5 张。\n· 沿灰色虚线水平、垂直或斜向直线，连接到与牌面符号相同的下一站。首段从始发站出发，后续可从线路任一端延伸。\n· 不能越过车站、返回同线已有车站形成环路，或在没有许可的位置与线路交叉。\n· 中央站台的四个入口属于同一站，也是独立一区。每条线只能进入一次，可从任一相连虚线离开。八处名胜和中央站台接受任意符号。\n· 八座高架桥允许两段线路按桥面方向交叉，颜色可以相同。桥不是车站，也不形成换乘；其他位置禁止交叉。任意两站之间最多一段。\n· 自由入站／导览牌：可以连接任意一站；若先到达名胜，还可从该名胜再连接任意一站。\n· 道岔牌：立即再翻开一张站牌。绘制该张站牌的线段时，可以从当前线路的任一站出发，形成支线。\n计分：\n· 每条线获得「经过区数 × 单一区内最多站数」，再加每处名胜 2 分。\n· 高架桥仅有一个方向被使用时，获得 2 分；两个方向都被使用时，获得 6 分。\n· 两条、三条或四条线路经过的换乘站，分别获得 2 分、5 分或 9 分。中央站台也可作为换乘站。\n高级模块（默认关闭）：\n共同目标：从五个目标中随机公开两个，每完成一个目标获得 10 分。\n· 建造三个三线换乘站。\n· 用同一条线路经过七个区域。城市大门提供的额外区域数不计入此目标。\n· 连接六处不同的名胜。\n· 双向使用两座桥。\n· 连接某个主要区域的全部车站。\n城市大门：四个角落车站随机配对以下四种能力，每次到达时均可立即使用：\n· 使用道岔与自由入站。\n· 使用两次自由入站。\n· 本轮将该区域计为两个区域。\n· 选择一个普通车站，本轮将其计为两个车站。\n额外绘制的线段仍须遵守基本限制。连锁触发时，先完成前一个奖励。普通车站不包括始发站、中央站台及名胜。各项奖励均可选择使用或跳过。\n胜负与单人：\n· 总分最高者获胜；同分比较单线最高分，仍同分则共享胜利。单人以刷新个人总分为目标，每启用一个高级模块，终局额外扣 10 分。",
			entrance: "入口 {{n}}",
			chooseEntrance: "选择中央站台入口",
			activate: "使用奖励",
			center: "中央站台",
			loop: "绿色环线",
			fullMap: "全景",
			winner: "获胜",
			tied: "并列获胜",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			districtNumber: "第 {{n}} 区"
		},
		en: {
			name: "Next Station: Paris",
			desc: "Link Parisian monuments through the central platform and overhead crossings.",
			round: "Round {{n}} / 4",
			metro: "Metro cards {{n}} / 5",
			street: "Street",
			underground: "Metro",
			draw: "Choose a starting station",
			target: "Choose the next station",
			double: "Choose an ordinary station to count twice",
			waiting: "Waiting for other players",
			scoring: "Line scoring",
			over: "Network complete",
			cancel: "Cancel selection",
			boost: "Use this round’s power",
			tour: "Guided tour: continue from this monument",
			free: "Connect to any station again",
			switch: "Switch: start from any station on this line",
			extension: "Continue in the same direction",
			cardWild: "Free entry / Guided tour",
			score: "Total",
			line: "Line",
			areas: "Districts",
			most: "Most stations",
			monuments: "Monuments",
			crossings: "Overhead crossings",
			interchanges: "Interchanges",
			stamps: "Tourist stamps",
			penalty: "Unconnected loop stations",
			goals: "Shared objectives",
			handicap: "Solo module deduction",
			details: "Scores and objectives",
			close: "Close",
			objectivesOption: "Shared objectives",
			objectivesHint: "Reveal two random objectives; each completed objective scores 10 points.",
			advancedOption: "City gates",
			advancedHint: "Each corner station grants an optional immediate bonus.",
			gates: "City gates",
			special: "Special stations",
			district: "Count this district twice",
			powerDouble: "Count one station twice",
			powerWild: "Joker and double track",
			powerExtension: "Straight extension",
			powerSwitch: "Railway switch",
			powerFree: "Two free connections",
			network: "Review network",
			results: "Show results",
			again: "Play again",
			lobby: "Back to lobby",
			confirm: "Confirm",
			waitHost: "Waiting for the host to start another game",
			hintDraw: "Follow a dotted link from your line to the target station.",
			hintPass: "Skip this connection opportunity.",
			errWait: "Wait for the current step to finish.",
			errMove: "This section does not meet the current construction rules.",
			playerBoard: "{{name}}’s network",
			station: "Station {{n}}",
			color0: "Orange line",
			color1: "Green line",
			color2: "Purple line",
			color3: "Blue line",
			shapeSquare: "Square",
			shapeTriangle: "Triangle",
			shapeCircle: "Circle",
			shapePentagon: "Pentagon",
			shapeWild: "Any symbol",
			last: "Last card of this round",
			completed: "Completed",
			pending: "Not completed",
			noMoves: "No legal section; you may pass",
			goal0: "At least three interchanges with three lines each",
			goal1: "One line visits at least seven districts",
			goal2: "Connect at least six different monuments",
			goal3: "Use at least two overhead crossings in both directions",
			goal4: "Connect every station in one main district",
			pass: "Pass",
			rules: "Goal: Build four subway lines in different colours and maximise your total score.\nPlay:\n· Four rounds, one new pencil colour each round. Begin at its matching departure station. Each player’s colour order appears in the line ledger.\n· Shuffle all 11 station cards each round and reveal them one at a time. Everyone draws one section or passes. Resolve the fifth Metro card, then end the round. There are six Street cards and five Metro cards.\n· Follow a dotted horizontal, vertical or diagonal straight link to the next station matching the revealed symbol. Start the first section at the departure station; extend later sections from either end.\n· Never skip over a station, revisit a station on the same line to form a loop, or cross another section without permission.\n· The central platform’s four entrances are one station and one separate district. Each line may visit it once and leave by any connected dotted link. All eight monuments and the platform accept any symbol.\n· Eight overhead crossings let two sections cross in their printed directions, even in the same colour. They are not stations or interchanges. No other crossing is allowed, and only one section may join a pair of stations.\n· Free Entry / Guided Tour: connect to any station. If you first reach a monument, you may draw another section from it to any station.\n· Switch: immediately reveal another station card. That card’s section may start at any station on the current line, forming a branch.\nScoring:\n· Each line scores districts visited × most stations in one district, plus two points per monument.\n· An overhead crossing used in one direction scores 2 points; using both directions scores 6 points.\n· An interchange with two, three or four lines scores 2, 5 or 9 points respectively. The platform can be an interchange.\nAdvanced modules (off by default):\nShared Objectives: reveal two of five objectives. Each achieved objective scores 10 points.\n· Build three three-line interchanges.\n· Visit seven districts with one line. A district doubled by a City Gate still counts once for this objective.\n· Connect six different monuments.\n· Use two crossings in both directions.\n· Connect every station in one main district.\nCity Gates: randomly pair the four corner stations with these powers. You may activate the assigned power immediately upon each arrival:\n· Use Switch and Free Entry.\n· Use Free Entry twice.\n· Count this district twice for the current round.\n· Choose one ordinary station to count twice for the current round.\nAdditional sections obey normal restrictions. Finish one bonus before resolving a chained bonus. Ordinary stations exclude departures, the platform and monuments. All bonuses may be used or passed.\nWinning and solo play:\n· Highest total wins. Break ties by the highest individual line score, then share victory. In solo play, pursue your highest score and deduct ten points for each enabled advanced module.",
			entrance: "Entrance {{n}}",
			chooseEntrance: "Choose a platform entrance",
			activate: "Use bonus",
			center: "Central platform",
			loop: "Green loop",
			fullMap: "Fit map",
			winner: "Winner",
			tied: "Shared victory",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm back to lobby",
			districtNumber: "District {{n}}"
		}
	}
};
//#endregion
export { _e as default };
