import { randomIntAt as e } from "@bgparty/sdk/core";
import { z as t } from "zod";
import { useEffect as n, useId as r, useMemo as i, useRef as a, useState as o } from "react";
import { PhaseBanner as s } from "@bgparty/sdk/ui";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { useGameT as l, useI18nSettings as u } from "@bgparty/sdk/i18n";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchor as f } from "@bgparty/sdk/fx/anchors";
import { useWakeLock as p } from "@bgparty/sdk/use-wake-lock";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { usePrefersReducedMotion as _ } from "@bgparty/sdk/fx/use-reduced-motion";
import { BottomSheet as v } from "@bgparty/sdk/bottom-sheet";
import { Floater as y } from "@bgparty/sdk/fx/primitives";
import { readGameStorage as b, writeGameStorage as ee } from "@bgparty/sdk/storage";
import { OptionCheckbox as x, OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/cascadiaalpinelakes/data.ts
var w = [
	"cougar",
	"eagle",
	"goat",
	"marmot",
	"pika"
], T = [
	"forest",
	"meadow",
	"glacier"
], E = [
	[{
		habitat: "forest",
		animals: ["pika"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["cougar", "marmot"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["goat"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["cougar", "marmot"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: [
			"eagle",
			"goat",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["eagle", "goat"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["marmot", "pika"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["eagle", "pika"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: ["cougar", "goat"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["marmot", "pika"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["cougar", "goat"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["eagle"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["marmot", "pika"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["goat", "marmot"],
		lake: !1
	}, {
		habitat: "forest",
		animals: [
			"cougar",
			"eagle",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["eagle"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["marmot", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["marmot"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["eagle", "goat"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["goat", "pika"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["cougar", "marmot"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: [
			"eagle",
			"goat",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["cougar", "eagle"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["marmot", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: ["marmot"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["cougar"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["eagle", "pika"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["cougar", "marmot"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["goat", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: [
			"cougar",
			"eagle",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["goat", "pika"],
		lake: !1
	}, {
		habitat: "forest",
		animals: [
			"cougar",
			"eagle",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["goat"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["eagle", "pika"],
		lake: !1
	}, {
		habitat: "forest",
		animals: [
			"cougar",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: [
			"eagle",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["cougar", "goat"],
		lake: !1
	}, {
		habitat: "forest",
		animals: [
			"eagle",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: [
			"eagle",
			"goat",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: ["goat", "marmot"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["marmot"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["goat", "pika"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["cougar"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["eagle", "marmot"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: [
			"goat",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["goat", "pika"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: [
			"cougar",
			"eagle",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["eagle", "pika"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: ["marmot"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: ["marmot", "pika"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["cougar", "goat"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: [
			"eagle",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["marmot"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["goat", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["cougar"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["eagle", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["cougar", "pika"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: [
			"eagle",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["goat"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["cougar", "marmot"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["goat", "pika"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["eagle"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["marmot", "pika"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: ["cougar"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["goat"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["marmot"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["eagle", "goat"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: ["eagle", "goat"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["eagle"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["goat", "marmot"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["eagle", "marmot"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"goat",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: [
			"cougar",
			"eagle",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: ["cougar"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: ["pika"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["cougar", "eagle"],
		lake: !1
	}, {
		habitat: "forest",
		animals: [
			"goat",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: ["cougar", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["goat", "pika"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"eagle",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["pika"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["cougar", "goat"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["eagle", "marmot"],
		lake: !1
	}, {
		habitat: "forest",
		animals: [
			"cougar",
			"goat",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["eagle", "pika"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: [
			"cougar",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["marmot", "pika"],
		lake: !1
	}, {
		habitat: "forest",
		animals: [
			"cougar",
			"eagle",
			"goat"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: ["goat", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"eagle",
			"goat"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["eagle", "goat"],
		lake: !1
	}, {
		habitat: "forest",
		animals: [
			"cougar",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["goat", "marmot"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"eagle",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["goat"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"eagle",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["eagle", "marmot"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: [
			"cougar",
			"goat",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: ["marmot", "pika"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: [
			"cougar",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["cougar", "goat"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: [
			"eagle",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: ["cougar", "goat"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: [
			"eagle",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "glacier",
		animals: [
			"cougar",
			"goat",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: [
			"eagle",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["pika"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: ["goat", "marmot"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["eagle"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["marmot", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["eagle", "marmot"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: [
			"cougar",
			"goat",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["pika"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["cougar", "marmot"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: ["goat", "marmot"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["goat"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["cougar", "eagle"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: [],
		lake: !0
	}, {
		habitat: "forest",
		animals: ["cougar", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: ["eagle", "pika"],
		lake: !1
	}],
	[{
		habitat: "glacier",
		animals: ["cougar"],
		lake: !1
	}, {
		habitat: "forest",
		animals: ["goat", "pika"],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["pika"],
		lake: !1
	}, {
		habitat: "glacier",
		animals: ["cougar", "goat"],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: [
			"eagle",
			"goat",
			"marmot"
		],
		lake: !1
	}],
	[{
		habitat: "meadow",
		animals: ["cougar", "eagle"],
		lake: !1
	}, {
		habitat: "meadow",
		animals: [
			"goat",
			"marmot",
			"pika"
		],
		lake: !1
	}],
	[{
		habitat: "forest",
		animals: [],
		lake: !0
	}, {
		habitat: "meadow",
		animals: ["eagle"],
		lake: !1
	}]
], D = [
	[
		"M:c",
		"M:ep",
		"F:gm",
		"G:emp"
	],
	[
		"M:e",
		"M:mp",
		"G:cg",
		"F:gmp"
	],
	[
		"F:g",
		"F:ce",
		"G:mp",
		"M:cep"
	],
	[
		"F:m",
		"F:cg",
		"M:ep",
		"G:ceg"
	]
], te = (e) => {
	let [t, n] = e.split(":"), r = {
		F: "forest",
		M: "meadow",
		G: "glacier"
	}, i = {
		c: "cougar",
		e: "eagle",
		g: "goat",
		m: "marmot",
		p: "pika"
	};
	return {
		habitat: r[t],
		animals: [...n].map((e) => i[e]),
		lake: !1
	};
}, O = [
	[1, 0],
	[0, 1],
	[-1, 1],
	[-1, 0],
	[0, -1],
	[1, -1]
], k = (e, t) => `${e},${t}`, A = (e) => k(e.q, e.r), j = (e, t) => M(e, t) === 1, M = (e, t) => (Math.abs(e.q - t.q) + Math.abs(e.r - t.r) + Math.abs(e.q + e.r - t.q - t.r)) / 2, N = (e) => O.map(([t, n]) => k(e.q + t, e.r + n)), P = (e) => new Map(e.map((e) => [A(e), e])), F = (e, t) => [e * 75, (t + e / 2) * 86.6025403784];
function I(e, t = () => !0) {
	let n = new Set(e), r = [];
	for (; n.size;) {
		let e = n.values().next().value, i = [e];
		n.delete(e);
		for (let e = 0; e < i.length; e++) for (let r of n) j(i[e], r) && t(i[e], r) && (n.delete(r), i.push(r));
		r.push(i);
	}
	return r;
}
var L = (e) => I(e, (e, t) => e.habitat === t.habitat);
function R(e) {
	let t = [];
	for (let n = 0; n < 2; n++) {
		let r = e.map(([e, t]) => [n ? t : e, n ? e : t]);
		for (let e = 0; e < 6; e++) t.push(r), r = r.map(([e, t]) => [-t, e + t]);
	}
	return t;
}
var ne = [
	[0, 0],
	[1, 0],
	[0, 1]
], re = [
	[0, 0],
	[1, 0],
	[0, 1],
	[1, 1]
], ie = [
	[0, 0],
	[1, 0],
	[1, 1]
];
function z(e, t, n = !1) {
	let r = P(e), i = /* @__PURE__ */ new Set(), a = [];
	for (let o of R(t)) for (let s of e) for (let [e, c] of n ? o : [[0, 0]]) {
		let l = o.flatMap(([t, n]) => {
			let i = r.get(k(s.q + t - e, s.r + n - c));
			return i ? [i] : [];
		});
		if (!n && l.length !== t.length || l.length === 0) continue;
		let u = l.map(A).sort().join(";");
		i.has(u) || (i.add(u), a.push(l));
	}
	return a;
}
function B(e, t) {
	let n = P(e), r = [];
	for (let i of e) for (let [e, a] of O) {
		let o = Array.from({ length: t }, (t, r) => n.get(k(i.q + r * e, i.r + r * a)));
		o.every((e) => e !== void 0) && r.push(o);
	}
	return r;
}
function V(e, t) {
	let n = new Map(e.map((e, t) => [A(e), t])), r = e.map(() => []), i = /* @__PURE__ */ new Map();
	for (let e of t) {
		let t = e.cells.reduce((e, t) => e | 1n << BigInt(n.get(A(t))), 0n);
		i.set(t, Math.max(e.points, i.get(t) ?? 0));
	}
	for (let [t, n] of i) for (let i = 0; i < e.length; i++) t & 1n << BigInt(i) && r[i].push({
		mask: t,
		points: n
	});
	let a = /* @__PURE__ */ new Map(), o = (e) => {
		if (!e) return 0;
		let t = a.get(e);
		if (t !== void 0) return t;
		let n = 0;
		for (; !(e & 1n << BigInt(n));) n++;
		let i = o(e & ~(1n << BigInt(n)));
		for (let t of r[n]) (t.mask & e) === t.mask && (i = Math.max(i, t.points + o(e ^ t.mask)));
		return a.set(e, i), i;
	};
	return o((1n << BigInt(e.length)) - 1n);
}
//#endregion
//#region src/games/cascadiaalpinelakes/meta.ts
var ae = {
	id: "cascadiaalpinelakes",
	tier: "alpha",
	sdkApi: 2,
	mechanics: [
		"drafting",
		"tile-placement",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.cascadiaalpinelakes.name",
	descKey: "games.cascadiaalpinelakes.desc",
	rulesKey: "games.cascadiaalpinelakes.rules",
	icon: "🏔️",
	iconImg: "games/cascadiaalpinelakes.webp",
	rulesUrl: { en: "https://www.alderac.com/wp-content/uploads/2026/07/Cascadia_Alpine_Lakes_Rulebook_LoRes.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#32736b",
	releasedAt: "2026-10-30T13:08:56+08:00",
	search: {
		py: "ka si ka di ya zhi lv gao shan hu bo",
		init: "kskdyzlgshb"
	},
	hotseat: "open",
	botDelayMs: 600
}, H = t.enum([
	"cougar",
	"eagle",
	"goat",
	"marmot",
	"pika"
]), oe = t.enum([
	"forest",
	"meadow",
	"glacier"
]), U = t.enum([
	"A",
	"B",
	"C",
	"D",
	"E",
	"F"
]), W = t.object({
	cards: t.enum([
		"A",
		"random",
		"custom",
		"family",
		"intermediate"
	]).default("A"),
	forest: U.default("A"),
	meadow: U.default("A"),
	glacier: U.default("A"),
	wildlife: t.int().min(0).max(12).default(0),
	habitat: t.int().min(0).max(12).default(0),
	spatial: t.int().min(0).max(12).default(0),
	environment: t.int().min(0).max(3).default(0),
	pristinePeaks: t.boolean().default(!1),
	lake: t.enum([
		"standard",
		"cascading",
		"wildlands"
	]).default("standard"),
	highestBonus: t.boolean().default(!0),
	challenge: t.enum([
		"none",
		"scenario",
		"normal",
		"modifier"
	]).default("none"),
	scenario: t.int().min(1).max(20).default(1),
	modification: t.int().min(1).max(5).default(1)
}).prefault({}), G = t.int().min(-60).max(60), se = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pick"),
		tile: t.int().min(0).max(3),
		token: t.int().min(0).max(3)
	}),
	t.object({ type: t.literal("wipe3") }),
	t.object({
		type: t.literal("wipe"),
		indices: t.array(t.int().min(0).max(3)).min(1).max(4)
	}),
	t.object({
		type: t.literal("placeTile"),
		q: G,
		r: G,
		dir: t.int().min(0).max(5),
		scaffold: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("placeToken"),
		q: G,
		r: G
	}),
	t.object({ type: t.literal("skipToken") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), K = t.object({
	q: G,
	r: G,
	habitat: oe,
	animals: t.array(H),
	lake: t.boolean(),
	level: t.int().min(1).max(30),
	animal: H.nullable(),
	serial: t.int().min(0)
}), ce = t.object({
	cougar: t.number(),
	eagle: t.number(),
	goat: t.number(),
	marmot: t.number(),
	pika: t.number()
}), le = t.object({
	forest: t.number(),
	meadow: t.number(),
	glacier: t.number()
}), ue = t.object({
	rid: t.string(),
	habitats: le,
	lakes: t.number(),
	elevation: ce,
	bonus: ce,
	nature: t.number(),
	environment: t.array(t.number()),
	total: t.number(),
	chosen: t.object({
		forest: U,
		meadow: U,
		glacier: U
	}),
	awards: t.array(t.int()),
	scenarioMedal: t.int().min(0).max(3),
	goals: t.array(t.boolean())
}), q = t.object({
	phase: t.enum([
		"draft",
		"place",
		"resolve",
		"done"
	]),
	config: W,
	cards: t.object({
		forest: t.array(U),
		meadow: t.array(U),
		glacier: t.array(U)
	}),
	environment: t.array(t.object({
		type: t.enum([
			"habitat",
			"wildlife",
			"spatial"
		]),
		card: t.int().min(1).max(12)
	})),
	players: t.array(t.object({
		rid: t.string(),
		board: t.array(K),
		nature: t.int().min(0),
		turns: t.int().min(0).max(20)
	})),
	turn: t.int().min(0).max(3),
	round: t.int().min(1).max(20),
	tilesLeft: t.int().min(0),
	display: t.array(t.object({
		tile: t.int().min(1).max(84).nullable(),
		token: H.nullable()
	})).min(3).max(4),
	picked: t.object({
		tile: t.int().min(1).max(84),
		token: H,
		tileIndex: t.int(),
		tokenIndex: t.int(),
		tilePending: t.boolean(),
		tokenPending: t.boolean(),
		matchExempt: t.boolean().default(!1)
	}).nullable(),
	wipe3Used: t.boolean(),
	serial: t.int().min(0),
	final: t.array(ue),
	log: t.array(t.object({
		n: t.int(),
		rid: t.string(),
		kind: t.enum([
			"pick",
			"tile",
			"animal",
			"discard",
			"wipe",
			"nature"
		]),
		tile: t.int().optional(),
		animal: H.optional(),
		level: t.int().optional(),
		amount: t.int().optional()
	}))
}), de = t.object({}), J = {
	forestA: [
		2,
		4,
		7,
		11,
		17
	],
	forestB: [
		5,
		12,
		20
	],
	forestC: [
		2,
		5,
		9,
		13
	],
	forestD: [
		2,
		5,
		9,
		14,
		19
	],
	forestE: [
		5,
		11,
		18,
		25,
		33,
		42
	],
	forestF: [
		10,
		22,
		34
	],
	meadowA: [
		2,
		5,
		8,
		12,
		17,
		22
	],
	meadowB: [
		2,
		5,
		9,
		14,
		19
	],
	meadowC: [
		2,
		5,
		9
	],
	meadowD: [
		2,
		6,
		11,
		17
	],
	meadowE: [
		2,
		5,
		8,
		12,
		17
	],
	meadowF: [
		6,
		7,
		8
	],
	glacierA: [
		5,
		11,
		18,
		25,
		33
	],
	glacierB: [
		9,
		19,
		30,
		42
	],
	glacierC: [
		2,
		5,
		8,
		11,
		15,
		19,
		23,
		28,
		33
	],
	glacierD: [
		5,
		12,
		20,
		29,
		38
	],
	glacierE: [
		2,
		5,
		9,
		13,
		18
	],
	glacierF: [
		3,
		6,
		10,
		14,
		18,
		22,
		27
	]
}, Y = (e, t) => e <= 0 ? 0 : t[Math.min(e, t.length) - 1], X = (e) => new Set(e).size, fe = (e) => Object.fromEntries(w.map((t) => [t, e.filter((e) => e.animal === t).length])), Z = (e) => e.reduce((e, t) => e + t, 0), pe = (e) => e.filter((e) => e.animal !== null), me = (e) => I(pe(e), (e, t) => e.animal === t.animal);
function he(e, t) {
	let n = w.map((t) => [...new Set(e.filter((e) => e.animal === t).map((e) => e.level))]), r = /* @__PURE__ */ new Map(), i = (e) => {
		if (e === w.length) return 0;
		let a = i(e + 1);
		for (let o of n[e]) (r.get(o) ?? 0) < t && (r.set(o, (r.get(o) ?? 0) + 1), a = Math.max(a, 1 + i(e + 1)), r.set(o, r.get(o) - 1));
		return a;
	};
	return i(0);
}
function ge(e) {
	let t = w.flatMap((e, t) => w.slice(t + 1).map((t) => [e, t])), n = /* @__PURE__ */ new Set([0]);
	for (let r of e) {
		let e = t.flatMap(([e, t], n) => r.some((n) => n.animal === e && r.some((e) => e.animal === t && j(n, e))) ? [1 << n] : []), i = new Set(n);
		for (let t of n) for (let n of e) t & n || i.add(t | n);
		n = i;
	}
	return Math.max(0, ...[...n].map((e) => e.toString(2).replaceAll("0", "").length));
}
function _e(e, t, n, r) {
	let i = e.filter((e) => e.habitat === t), a = L(i), o = pe(i);
	if (r === "family" || r === "intermediate") return Z(me(i).map((e) => r === "family" ? Y(e.length, [
		2,
		5,
		9
	]) : e.length < 2 ? 0 : Y(e.length - 1, [
		5,
		8,
		12
	])));
	if (t === "forest") return n === "E" ? Y(ge(a), J.forestE) : n === "F" ? Y(a.filter((e) => he(e, 1) >= 3).length, J.forestF) : Z(a.map((e) => n === "B" ? Y(Object.values(fe(e)).filter((e) => e >= 2).length, J.forestB) : n === "C" ? Y(Math.max(0, ...z(e, re, !0).map((e) => X(e.flatMap((e) => e.animal ? [e.animal] : [])))), J.forestC) : n === "D" ? Y(he(e, 2), J.forestD) : Y(X(e.flatMap((e) => e.animal ? [e.animal] : [])), J.forestA)));
	if (t === "glacier") {
		if (n === "E") return Z(a.map((e) => Y(Math.max(...Object.values(fe(e))), J.glacierE)));
		let e = a.filter((e) => n === "B" ? X(e.flatMap((e) => e.animal ? [e.animal] : [])) >= 3 : n === "C" ? e.some((e) => e.animal) : n === "F" ? e.some((e) => e.animal && e.level >= 2) : e.some((t) => t.animal && e.some((e) => t !== e && t.animal === e.animal && j(t, e) && (n !== "D" || t.level !== e.level)))).length;
		return Y(e, n === "B" ? J.glacierB : n === "C" ? J.glacierC : n === "D" ? J.glacierD : n === "F" ? J.glacierF : J.glacierA);
	}
	let s = me(i);
	return n === "B" ? V(o, s.flatMap((e) => Array.from({ length: Math.min(5, e.length) }, (e, t) => t + 1).flatMap((t) => B(e, t).map((e) => ({
		cells: e,
		points: Y(t, J.meadowB)
	}))))) : n === "C" ? V(o, s.flatMap((e) => z(e, ne, !0).map((e) => ({
		cells: e,
		points: Y(e.length, J.meadowC)
	})))) : n === "D" ? Z(s.map((e) => X(e.map((e) => e.level)) === e.length ? Y(e.length, J.meadowD) : 0)) : n === "E" ? Z(s.map((e) => Y(e.length, J.meadowE))) + X(s.map((e) => e.length)) : Z(n === "F" ? I(o, (e, t) => e.animal === t.animal && e.level === t.level).filter((e) => e.length >= 2).map((e) => Y(e[0].level, J.meadowF)) : s.map((e) => Y(e.length, J.meadowA)));
}
function ve(e, t) {
	let n = e.filter((e) => e.lake), r = P(e);
	return t === "wildlands" ? 0 : Z(t === "standard" ? n.map((e) => e.level * (N(e).every((e) => r.has(e)) ? 2 : 1)) : I(n).map((e) => {
		let t = Math.max(...e.map((e) => e.level));
		return e.some((n) => n.level !== t && !e.some((e) => j(n, e) && e.level === n.level + 1)) ? 0 : Y(X(e.map((e) => e.level)), [
			1,
			4,
			9,
			15
		]);
	}));
}
function ye(e, t) {
	return e.map((n) => {
		let r = e.filter((e) => e > n).length, i = e.filter((e) => e === n).length;
		return Math.floor(Z(t.slice(r, r + i)) / i);
	});
}
function be(e, t) {
	let n = e.map(() => Object.fromEntries(w.map((e) => [e, 0])));
	if (!t) return n;
	for (let t of w) {
		let r = e.map((e) => e.board.filter((e) => e.animal === t).map((e) => e.level).sort((e, t) => t - e));
		if (e.length === 1) {
			n[0][t] = r[0].some((e) => e >= 4) || r[0].filter((e) => e >= 3).length >= 2 ? 2 : 0;
			continue;
		}
		let i = (e, t) => {
			for (let n = 0; n < Math.max(e.length, t.length); n++) if ((e[n] ?? 0) !== (t[n] ?? 0)) return (e[n] ?? 0) - (t[n] ?? 0);
			return 0;
		};
		r.forEach((a, o) => {
			if (!a.length) return;
			let s = r.filter((e) => i(e, a) > 0).length, c = r.filter((e) => i(e, a) === 0).length;
			e.length === 2 ? n[o][t] = s === 0 ? c === 1 ? 2 : 1 : 0 : n[o][t] = s === 0 ? c === 1 ? 3 : c === 2 ? 2 : 1 : +(s === 1 && c === 1);
		});
	}
	return n;
}
function xe(e, t, n, r = [e], i = 0) {
	let a = L(e), o = pe(e), s = P(e), c = Object.values(fe(e));
	if (t === "wildlife") return n === 1 ? Math.max(...c) : n === 2 ? o.filter((e) => N(e).every((e) => s.has(e))).length : n === 3 ? c.filter((e) => e <= 3).length * 3 : n === 4 ? c.filter((e) => e === 4).length * 2 : n === 5 ? c.filter((e) => e === 5).length * 3 : n === 6 ? w.filter((e) => X(o.filter((t) => t.animal === e).map((e) => e.level)) >= 3).length * 2 : n === 7 ? V(o, B(o, 5).filter((e) => X(e.map((e) => e.animal)) === 5).map((e) => ({
		cells: e,
		points: 3
	}))) : n === 8 ? [...c].sort((e, t) => t - e)[2] * 2 : n === 9 ? V(o, B(o, 3).filter((e) => e.every((t, n) => t.animal === e[0].animal && t.level === n + 1)).map((e) => ({
		cells: e,
		points: 3
	}))) : n === 10 ? Math.min(...c) * 3 : n === 11 ? c.filter((e) => e >= 7).length * 4 : Z(w.map((e) => {
		let t = r.map((t) => fe(t)[e]), n = Math.max(...t);
		return n > 0 && t[i] === n ? t.filter((e) => e === n).length > 1 ? 1 : 3 : 0;
	}));
	if (t === "habitat") return n === 1 ? Math.floor(a.length / 2) : n === 2 ? a.filter((e) => e.length >= 3).length : n === 3 ? Math.min(...T.map((t) => e.filter((e) => e.habitat === t).length)) : n === 4 || n === 11 ? V(e, B(e, 3).filter((e) => n === 4 ? e.every((t, n) => t.habitat === e[0].habitat && t.level === n + 1) : X(e.map((e) => e.habitat)) === 3 && X(e.map((e) => e.level)) === 3).map((e) => ({
		cells: e,
		points: 3
	}))) : n === 5 ? a.filter((e) => B(e, 3).length > 0).length * 2 : n === 6 ? a.filter((e) => z(e, ne).length > 0).length * 2 : n === 7 ? Z(T.map((t) => Math.max(0, ...e.filter((e) => e.habitat === t).map((e) => e.level)))) : n === 8 ? T.filter((e) => X(o.filter((t) => t.habitat === e).map((e) => e.animal)) >= 4).length * 3 : n === 9 ? w.filter((e) => T.every((t) => o.some((n) => n.animal === e && n.habitat === t))).length * 2 : n === 10 ? T.filter((t) => e.some((e) => e.habitat === t && e.level >= 4)).length * 3 : ye(r.map((e) => L(e).length), [
		8,
		4,
		2,
		0
	])[i];
	if (n === 1) return V(o, o.flatMap((e, t) => o.slice(t + 1).filter((t) => j(e, t) && e.animal === t.animal && e.habitat !== t.habitat).map((t) => ({
		cells: [e, t],
		points: 1
	}))));
	if (n === 2) return e.filter((e) => e.lake && N(e).every((e) => s.get(e)?.animal)).length * 2;
	if (n === 3) return a.filter((e) => e.some((e) => e.level >= 3)).length * 2;
	if (n === 4) return V(o, w.flatMap((e) => z(o.filter((t) => t.animal === e), ie).map((e) => ({
		cells: e,
		points: 2
	}))));
	if (n === 5) return e.filter((e) => e.level >= 3 && N(e).some((e) => !s.has(e))).length;
	if (n === 6) {
		let t = e.filter((e) => !e.animal && !e.lake).length;
		return t === 0 ? 5 : t === 1 ? 3 : t === 2 ? 1 : t < 5 ? -1 : -3;
	}
	if (n === 7) return me(e).filter((e) => X(e.map((e) => e.habitat)) === 3).length * 3;
	if (n === 8) return Math.max(0, ...I(e.filter((e) => e.level === 2)).map((e) => e.length));
	if (n === 9) return e.filter((e) => N(e).some((t) => s.has(t) && e.level - s.get(t).level >= 2)).length;
	if (n === 10) return e.filter((e) => N(e).every((t) => (s.get(t)?.level ?? 0) > e.level)).length * 3;
	if (n === 11) return me(e).filter((e) => e.length >= 3 && e.every((e) => N(e).some((e) => s.get(e)?.lake))).length * 3;
	let l = Math.max(...e.map((e) => e.level)), u = e.filter((e) => e.level === l);
	return Math.max(0, ...u.flatMap((e) => u.map((t) => M(e, t) - 1)));
}
function Se(e) {
	let t = be(e.players, e.config.highestBonus), n = e.players.map((e) => e.board);
	return e.players.map((r, i) => {
		let a = Object.fromEntries(T.map((t) => [t, [...e.cards[t]].sort((n, i) => _e(r.board, t, i, e.config.cards) - _e(r.board, t, n, e.config.cards))[0]])), o = Object.fromEntries(T.map((t) => [t, _e(r.board, t, a[t], e.config.cards)])), s = Object.fromEntries(w.map((t) => [t, Z(r.board.filter((e) => e.animal === t && e.level >= 3).map((t) => e.config.challenge === "modifier" && e.config.modification === 4 && t.level >= 4 ? 4 : 2))])), c = e.environment.map((e) => xe(r.board, e.type, e.card, n, i)), l = ve(r.board, e.config.lake);
		return {
			rid: r.rid,
			habitats: o,
			lakes: l,
			elevation: s,
			bonus: t[i],
			nature: r.nature,
			environment: c,
			total: Z(Object.values(o)) + l + Z(Object.values(s)) + Z(Object.values(t[i])) + r.nature + Z(c),
			chosen: a,
			awards: [],
			scenarioMedal: 0,
			goals: []
		};
	});
}
//#endregion
//#region src/games/cascadiaalpinelakes/challenges.ts
var Q = [
	[
		"AAA",
		0,
		0,
		0,
		70,
		80,
		90
	],
	[
		"BBB",
		0,
		0,
		0,
		70,
		80,
		90
	],
	[
		"CCC",
		0,
		0,
		0,
		70,
		80,
		90
	],
	[
		"BDA",
		0,
		0,
		0,
		70,
		80,
		90
	],
	[
		"DAB",
		0,
		0,
		0,
		70,
		80,
		90
	],
	[
		"ABD",
		1,
		0,
		0,
		75,
		85,
		95
	],
	[
		"DCC",
		0,
		1,
		0,
		75,
		85,
		95
	],
	[
		"ADD",
		0,
		0,
		3,
		80,
		87,
		95
	],
	[
		"CCB",
		2,
		2,
		0,
		80,
		87,
		95
	],
	[
		"CDA",
		0,
		3,
		2,
		80,
		90,
		95
	],
	[
		"DBD",
		3,
		0,
		1,
		80,
		90,
		95
	],
	[
		"BAC",
		1,
		2,
		2,
		80,
		90,
		100
	],
	[
		"CBD",
		4,
		6,
		5,
		80,
		90,
		100
	],
	[
		"DCB",
		9,
		8,
		6,
		90,
		95,
		100
	],
	[
		"AAC",
		8,
		4,
		4,
		90,
		95,
		100
	],
	[
		"BDA",
		5,
		5,
		1,
		90,
		95,
		100
	],
	[
		"DBC",
		3,
		3,
		9,
		90,
		95,
		100
	],
	[
		"CDB",
		6,
		1,
		7,
		90,
		95,
		100
	],
	[
		"BCD",
		2,
		7,
		3,
		90,
		95,
		100
	],
	[
		"DDD",
		7,
		9,
		8,
		95,
		100,
		105
	]
];
function Ce(e, t) {
	return t.map((n, r) => {
		let i = e.players[r].board, a = w.map((e) => i.filter((t) => t.animal === e).length), o = n.environment.reduce((e, t) => e + t, 0), s = T.map((e) => n.habitats[e]), c = Math.max(...i.map((e) => e.level)), l = Object.values(n.elevation).reduce((e, t) => e + t, 0) + Object.values(n.bonus).reduce((e, t) => e + t, 0), u = (e, t) => !i.some((n) => n.animal === e && i.some((e) => (t === "lake" ? e.lake : e.animal === t) && j(n, e))), d = [
			...[
				80,
				85,
				90,
				95,
				100,
				105,
				110
			].map((e) => n.total >= e),
			n.nature === 0,
			...[
				"pika",
				"goat",
				"cougar",
				"marmot",
				"eagle"
			].map((e) => !i.some((t) => t.animal === e)),
			Math.max(...a) >= 8,
			Math.max(...a) >= 10,
			Object.values(n.bonus).filter((e) => e >= (t.length <= 2 ? 2 : 3)).length >= 3,
			...s.map((e) => e >= 20),
			...s.map((e) => e >= 30),
			Math.max(...s) >= 35,
			o >= 10,
			o >= 15,
			o >= 20,
			n.nature >= 5,
			n.nature >= 10,
			t.length > 1 && t.every((e) => e === n || n.total - e.total >= 10),
			t.length > 1 && t.every((e) => e === n || n.total - e.total >= 15),
			c >= 4,
			c >= 5,
			n.lakes >= 15,
			n.lakes >= 20,
			w.every((e) => i.some((t) => t.animal === e && t.level >= 3))
		], f = [], p = e.config.scenario;
		return p === 8 && (f = [c >= 4]), p === 9 && (f = [a.every((e) => e >= 3)]), p === 10 && (f = [n.lakes >= 10]), p === 11 && (f = [n.habitats.forest >= 20]), p === 12 && (f = [o >= 10]), p === 13 && (f = [n.nature >= 5]), p === 14 && (f = [s.reduce((e, t) => e + t, 0) >= 55]), p === 15 && (f = [l >= 15]), p === 16 && (f = [a.filter((e) => e > 0).length === 4]), p === 17 && (f = [c >= 5]), p === 18 && (f = [n.environment.every((e) => e >= 5), u("pika", "eagle")]), p === 19 && (f = [s.every((e) => e >= 18), u("marmot", "lake")]), p === 20 && (f = [o >= 15, u("cougar", "goat")]), {
			...n,
			awards: d.flatMap((e, t) => e ? [t + 1] : []),
			goals: f,
			scenarioMedal: e.config.challenge === "scenario" && f.every(Boolean) ? Q[p - 1].slice(4).filter((e) => typeof e == "number" && n.total >= e).length : 0
		};
	});
}
var we = (t, n) => e(t.seed, t.cursor++, n), Te = (e, t) => {
	let n = [...e];
	for (let e = n.length - 1; e > 0; e--) {
		let r = we(t, e + 1);
		[n[e], n[r]] = [n[r], n[e]];
	}
	return n;
}, Ee = (e) => e.bag.splice(we(e, e.bag.length), 1)[0], $ = (e, t) => e.challenge === "modifier" && e.modification === t;
function De(e, t, n) {
	let r = Math.min(n, e.natureSupply);
	return e.natureSupply -= r, e.players[t].nature += r, r;
}
function Oe(e, t, n = {}) {
	e.log.push({
		n: e.serial++,
		rid: e.players[e.turn].rid,
		kind: t,
		...n
	}), e.log = e.log.slice(-100);
}
function ke(e, t) {
	let n = [], r = (t) => {
		for (let r of t) e.display[r].token && n.push(e.display[r].token), e.display[r].token = null;
		for (let r of t) e.bag.length || e.bag.push(...n.splice(0)), e.display[r].token = Ee(e);
	};
	t.length && r(t);
	let i = 0;
	for (; e.display.length === 4 && e.display.every((t) => t.token === e.display[0].token) && (/* @__PURE__ */ new Set([
		...e.bag,
		...n,
		...e.display.map((e) => e.token)
	])).size > 1 && i++ < 30;) r([
		0,
		1,
		2,
		3
	]);
	e.bag.push(...n);
}
function Ae(e, t, n, r, i, a, o, s = !1) {
	let c = E[t - 1], [l, u] = O[i], d = [[n, r], [n + l, r + u]], f = P(e), p = d.map(([e, t]) => f.get(k(e, t))), m = p.map((e) => e?.level ?? 0), h = Math.abs(m[0] - m[1]);
	if (h && !(s && $(a, 5) && o > 0 && h === 1) || s && !h) return null;
	let g = Math.max(...m) + 1, _ = new Set(d.map(([e, t]) => k(e, t))), v = d.flatMap(([e, t]) => N({
		q: e,
		r: t
	})).filter((e) => !_.has(e)).map((e) => f.get(e));
	return g === 1 && !v.some(Boolean) || g > 1 && !v.some((e) => (e?.level ?? 0) >= g - 1) || p.some((e, t) => e?.animal && !(c[t].animals.includes(e.animal) || c[t].lake && a.lake === "wildlands")) || $(a, 1) && v.some((e) => e && e.level >= g) && !d.some(([e, t], n) => N({
		q: e,
		r: t
	}).some((e) => {
		let t = f.get(e);
		return !_.has(e) && t && t.level >= g && t.habitat === c[n].habitat;
	})) ? null : {
		q: n,
		r,
		dir: i,
		scaffold: s,
		level: g
	};
}
function je(e, t, n, r) {
	let i = e.flatMap((e) => [A(e), ...N(e)]), a = new Set(i.flatMap((e) => {
		let [t, n] = e.split(",").map(Number);
		return [e, ...N({
			q: t,
			r: n
		})];
	})), o = [];
	for (let i of a) {
		let [a, s] = i.split(",").map(Number);
		for (let i = 0; i < 6; i++) for (let c of $(n, 5) && r > 0 ? [!1, !0] : [!1]) {
			let l = Ae(e, t, a, s, i, n, r, c);
			l && o.push(l);
		}
	}
	return o;
}
var Me = (e, t, n) => e.filter((e) => !e.animal && (e.animals.includes(t) || e.lake && n.lake === "wildlands")), Ne = (e, t, n, r) => !$(n, 1) || je(e, t, n, r).length > 0, Pe = (e, t, n, r, i) => Me(e, t, n).filter((a) => !i || !$(n, 1) || Ne(e.map((e) => e === a ? {
	...e,
	animal: t
} : e), i, n, r));
function Fe(e) {
	if (!$(e.config, 1)) return e.config;
	let t = e.players[e.turn];
	return (e.picked ? e.picked.matchExempt : e.display.every((n) => !n.tile || !Ne(t.board, n.tile, e.config, t.nature))) ? {
		...e.config,
		challenge: "none"
	} : e.config;
}
function Ie(e, t, n, r) {
	let i = P(e), [a, o] = O[n.dir], s = 0, c = E[t - 1].map((e, t) => {
		let c = n.q + t * a, l = n.r + t * o, u = i.get(k(c, l))?.animal ?? null;
		return u && e.animals.length === 1 && s++, {
			...e,
			q: c,
			r: l,
			level: n.level,
			animal: u,
			serial: r
		};
	}), l = new Set(c.map(A));
	return {
		board: [...e.filter((e) => !l.has(A(e))), ...c],
		nature: s
	};
}
function Le(e, t, n) {
	let r = W.parse(e), i = {
		seed: n,
		cursor: 0
	}, a = we(i, t.length);
	if (!r.pristinePeaks) {
		r.lake = "standard";
		for (let e of T) (r[e] === "E" || r[e] === "F") && (r[e] = "A");
		for (let e of [
			"habitat",
			"wildlife",
			"spatial"
		]) r[e] > 9 && (r[e] = 0);
	}
	let o = Te([
		0,
		1,
		2,
		3
	], i), s = [
		[0, 0],
		[0, 1],
		[1, 0],
		[1, 1]
	], c = Object.fromEntries(T.map((e) => {
		let t = Te(r.pristinePeaks ? [
			"A",
			"B",
			"C",
			"D",
			"E",
			"F"
		] : [
			"A",
			"B",
			"C",
			"D"
		], i);
		return [e, $(r, 3) ? t.slice(0, 2) : [r.cards === "random" ? t[0] : r.cards === "custom" ? r[e] : "A"]];
	})), l = [], u = [
		"wildlife",
		"habitat",
		"spatial"
	], d = Te([...u], i).slice(0, r.environment);
	for (let e of u) {
		let t = r[e] || (d.includes(e) ? we(i, r.pristinePeaks ? 12 : 9) + 1 : 0);
		t && l.push({
			type: e,
			card: t
		});
	}
	if (r.challenge === "scenario") {
		let e = Q[r.scenario - 1];
		r.cards = "custom", r.highestBonus = !0, r.lake = "standard", T.forEach((t, n) => {
			c[t] = [e[0][n]];
		}), l = u.flatMap((t, n) => e[n + 1] ? [{
			type: t,
			card: Number(e[n + 1])
		}] : []);
	}
	let f = $(r, 2) ? 3 : 4, p = (t.length === 1 ? 42 : 20 * t.length + 3) - (4 - f), m = Te(Array.from({ length: 84 }, (e, t) => t + 1), i).slice(0, p), h = {
		phase: "draft",
		config: r,
		cards: c,
		environment: l,
		players: t.map((e, t) => ({
			rid: e,
			board: D[o[t]].map((e, t) => ({
				...te(e),
				q: s[t][0],
				r: s[t][1],
				level: 1,
				animal: null,
				serial: 0
			})),
			nature: 0,
			turns: 0
		})),
		turn: a,
		picked: null,
		wipe3Used: !1,
		display: [],
		final: [],
		log: [],
		serial: 1,
		seed: n,
		cursor: i.cursor,
		deck: m,
		bag: w.flatMap((e) => Array.from({ length: 18 }, () => e)),
		natureSupply: 34
	};
	return h.display = Array.from({ length: f }, () => ({
		tile: h.deck.shift(),
		token: Ee(h)
	})), ke(h, []), {
		state: h,
		fx: []
	};
}
function Re(e) {
	let t = e.players[e.turn];
	t.turns++;
	let n = e.picked;
	if (e.players.every((e) => e.turns === 20)) {
		e.final = Ce(e, Se(e)), e.phase = "done";
		return;
	}
	if (e.players.length === 1) {
		let t = e.display.flatMap((e) => e.tile === null ? [] : [e.tile]), n = e.display.flatMap((e) => e.token === null ? [] : [e.token]);
		t.pop(), n.pop(), e.display = [
			{
				tile: e.deck.shift(),
				token: Ee(e)
			},
			{
				tile: e.deck.shift(),
				token: Ee(e)
			},
			...t.map((e, t) => ({
				tile: e,
				token: n[t]
			}))
		];
	} else e.display[n.tileIndex].tile = e.deck.shift(), e.display[n.tokenIndex].token = Ee(e);
	e.turn = (e.turn + 1) % e.players.length, e.picked = null, e.wipe3Used = !1, e.phase = "draft", ke(e, []);
}
function ze(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "resolve") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return Re(t), {
			state: t,
			fx: []
		};
	}
	if (e.phase === "done" || e.phase === "resolve" || e.players[e.turn].rid !== n.by) return { code: "games.cascadiaalpinelakes.errTurn" };
	let r = structuredClone(e), i = r.players[r.turn];
	if (t.type === "pick") {
		if (r.phase !== "draft" || !r.display[t.tile]?.tile || !r.display[t.token]?.token) return { code: "games.cascadiaalpinelakes.errPick" };
		if (t.tile !== t.token) {
			if (!i.nature) return { code: "games.cascadiaalpinelakes.errNature" };
			i.nature--, r.natureSupply++;
		}
		let e = Fe(r);
		return Ne(i.board, r.display[t.tile].tile, e, i.nature) ? (r.picked = {
			tile: r.display[t.tile].tile,
			token: r.display[t.token].token,
			tileIndex: t.tile,
			tokenIndex: t.token,
			tilePending: !0,
			tokenPending: !0,
			matchExempt: e !== r.config
		}, r.display[t.tile].tile = null, r.display[t.token].token = null, r.phase = "place", Oe(r, "pick", {
			tile: r.picked.tile,
			animal: r.picked.token
		}), {
			state: r,
			fx: [{
				kind: "draft",
				rid: n.by,
				data: {
					tile: r.picked.tile,
					animal: r.picked.token
				}
			}]
		}) : { code: "games.cascadiaalpinelakes.errTile" };
	}
	if (t.type === "wipe3" || t.type === "wipe") {
		if (r.phase !== "draft") return { code: "games.cascadiaalpinelakes.errPick" };
		let e;
		if (t.type === "wipe3") {
			let t = w.find((e) => r.display.filter((t) => t.token === e).length === 3);
			if (!t || r.wipe3Used) return { code: "games.cascadiaalpinelakes.errWipe" };
			e = r.display.flatMap((e, n) => e.token === t ? [n] : []), r.wipe3Used = !0;
		} else {
			if (e = [...new Set(t.indices)], !i.nature) return { code: "games.cascadiaalpinelakes.errNature" };
			if (e.some((e) => !r.display[e])) return { code: "games.cascadiaalpinelakes.errWipe" };
			i.nature--, r.natureSupply++;
		}
		return ke(r, e), Oe(r, "wipe", { amount: e.length }), {
			state: r,
			fx: [{
				kind: "wipe",
				rid: n.by,
				data: {}
			}]
		};
	}
	if (r.phase !== "place" || !r.picked) return { code: "games.cascadiaalpinelakes.errPick" };
	let a = [];
	if (t.type === "placeTile") {
		if (!r.picked.tilePending) return { code: "games.cascadiaalpinelakes.errTile" };
		let e = Ae(i.board, r.picked.tile, t.q, t.r, t.dir, Fe(r), i.nature, t.scaffold);
		if (!e) return { code: "games.cascadiaalpinelakes.errTile" };
		e.scaffold && (i.nature--, r.natureSupply++);
		let o = Ie(i.board, r.picked.tile, e, r.serial);
		i.board = o.board;
		let s = De(r, r.turn, o.nature);
		r.picked.tilePending = !1, Oe(r, "tile", { level: e.level }), s && Oe(r, "nature", { amount: s }), a = [{
			kind: "tile",
			rid: n.by,
			data: {
				q: e.q,
				r: e.r,
				dir: e.dir,
				level: e.level,
				nature: s
			}
		}];
	} else if (t.type === "placeToken") {
		let e = Pe(i.board, r.picked.token, Fe(r), i.nature, r.picked.tilePending ? r.picked.tile : void 0).find((e) => e.q === t.q && e.r === t.r);
		if (!r.picked.tokenPending || !e) return { code: "games.cascadiaalpinelakes.errToken" };
		e.animal = r.picked.token, e.serial = r.serial;
		let o = De(r, r.turn, +(e.animals.length === 1));
		r.picked.tokenPending = !1, Oe(r, "animal", {
			animal: r.picked.token,
			level: e.level
		}), o && Oe(r, "nature", { amount: o }), a = [{
			kind: "animal",
			rid: n.by,
			data: {
				q: e.q,
				r: e.r,
				animal: e.animal,
				nature: o
			}
		}];
	} else if (t.type === "skipToken") {
		if (!r.picked.tokenPending) return { code: "games.cascadiaalpinelakes.errToken" };
		r.bag.push(r.picked.token), r.picked.tokenPending = !1, Oe(r, "discard", { animal: r.picked.token });
	}
	return !r.picked.tilePending && !r.picked.tokenPending && (r.phase = "resolve"), {
		state: r,
		fx: a
	};
}
function Be(e) {
	let { seed: t, cursor: n, deck: r, bag: i, natureSupply: a, ...o } = e;
	return {
		public: {
			...o,
			tilesLeft: r.length,
			round: Math.min(20, e.players[e.turn].turns + 1)
		},
		private: {}
	};
}
function Ve(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.final].sort((e, t) => t.total - e.total || t.nature - e.nature), n = t[0];
	return {
		phase: "done",
		winner: t.filter((e) => e.total === n.total && e.nature === n.nature).map((e) => e.rid),
		ranking: t.map((e) => e.rid),
		scores: Object.fromEntries(t.map((e) => [e.rid, e.total]))
	};
}
var He = {
	meta: ae,
	saveCompatibility: { version: "1" },
	schemas: {
		action: se,
		config: W,
		publicView: q,
		privateView: de
	},
	setup: Le,
	reduce: ze,
	viewFor: Be,
	status: Ve,
	nextTickIn: (e) => e.phase === "resolve" ? 420 : null
}, Ue = "50,0 25,43.3 -25,43.3 -50,0 -25,-43.3 25,-43.3", We = {
	cougar: "#8d2676",
	eagle: "#07648e",
	goat: "#a6a8a7",
	marmot: "#be4e2c",
	pika: "#eabd25"
}, Ge = {
	forest: "#285b49",
	meadow: "#adc16b",
	glacier: "#b4cbd2"
};
function Ke({ animal: e }) {
	return e === "eagle" ? /* @__PURE__ */ g("g", {
		stroke: "#f2e7ce",
		strokeWidth: "2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				fill: "#423a36",
				d: "M-12 8C-19 1-24-17-30-26C-33-31-37-35-40-32C-42-27-42-22-40-18Q-43-17-39-11Q-41-9-36-5L-26 8C-19 18-2 25 22 27Q27 27 32 22L13 14C20 6 27-3 31-10Q35-17 37-24Q40-32 40-39Q38-41 35-36Q34-40 31-33Q30-37 27-29Q26-32 23-24L9-15C1-9-4-1-8 5Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#e8e5d9",
				d: "M-22 7C-23 1-28 0-31 3Q-34 5-37 11Q-32 14-27 14L-23 17-21 15-18 18-16 15-12 17Q-14 12-22 7Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#d9c8a7",
				d: "M13 15 20 17 32 21 25 27 11 23Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#d3a13f",
				strokeWidth: "1",
				d: "M-32 6-40 9-41 13-33 12Z"
			}),
			/* @__PURE__ */ h("path", {
				stroke: "#7e7162",
				strokeWidth: "1.3",
				fill: "none",
				d: "M-36-25Q-31-10-20 4M-37-17Q-31-4-22 8M12-6Q23-19 34-31M9 0Q20-11 32-23M6 5Q18-2 28-13M-11 12Q-3 17 9 19m8 1 8 3"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#554a40",
				stroke: "none",
				d: "M-13 8Q-7-7 10-16Q9-9 4-2L-1 8Q-5 14-13 8Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "none",
				stroke: "#9b8b72",
				strokeWidth: ".8",
				d: "M-10 7Q-4-2 5-9M-6 11Q1 2 9-4m-7 19 7 3m1 1 8 2"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "-29",
				cy: "5",
				r: "1.1",
				fill: "#161b1c",
				stroke: "none"
			})
		]
	}) : e === "goat" ? /* @__PURE__ */ g("g", {
		stroke: "#faf5e8",
		strokeWidth: "2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				fill: "#9c9f98",
				d: "M-19-2Q-25 9-21 22L-19 32Q-17 36-13 32L-15 17-10 7M0 0Q-2 15 5 28L9 31Q13 31 11 27L6 13 7-3Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#c5c4bb",
				d: "M-27-18C-24-27-14-28-6-26Q3-33 10-30L16-22Q20-18 23-15Q24-10 20-8L15-8 10-13Q8-4 6 4L3 12Q0 19 3 29Q5 34 1 34L-4 32Q-8 25-9 18L-12 7Q-16 15-17 20L-15 30Q-14 34-18 34L-22 32Q-25 25-24 15Q-30 6-31-5Q-31-12-27-18Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#e0dfd3",
				d: "M-27-18Q-24-27-13-27L-8-29Q-4-35 6-35Q13-34 16-24Q17-18 12-13L7-10 4-1 2-4-1 8-4 4-6-2-8-8-11 1-13-4-16-11-19-2-22-7-24-5Q-28-10-27-18Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#4a4c49",
				d: "M6-31C8-38 5-42 2-45Q10-44 12-37L13-31M12-32C14-39 11-43 9-46Q17-44 18-36L17-29"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#d1d1c4",
				d: "M4-29Q-3-38-7-34Q-7-30 3-26Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#666b65",
				stroke: "none",
				d: "M17-17Q21-17 23-14L20-9 16-12ZM-21 29l6 1 1 3-6 1M0 30l5 1v3l-6 1M8 28l4 1v3H8"
			}),
			/* @__PURE__ */ h("path", {
				fill: "none",
				stroke: "#92948b",
				strokeWidth: ".85",
				d: "M-24-17q-2 7 3 14m3-18q-3 8 2 13m4-15q-1 8 2 12m-6 5 2 7m-12-6q-1 5 2 8m25-31q-3-4-7-3M7-16l-2 5m-8 20 1 11"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "13",
				cy: "-23",
				r: "1.4",
				fill: "#272e29",
				stroke: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "m11-25 4 1",
				stroke: "#7b7d70",
				strokeWidth: ".8"
			})
		]
	}) : e === "cougar" ? /* @__PURE__ */ g("g", {
		stroke: "#f7ecd3",
		strokeWidth: "2.2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				fill: "#8d6b3f",
				d: "M-30 5C-35 8-35 18-42 17C-46 16-43 9-47 9C-52 10-48 22-43 23C-33 27-28 18-23 12Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#80603c",
				d: "M-13 4Q-14 12-9 18L-2 23Q2 25 7 24L7 21 1 19-3 12 2 5M14 1Q13 10 19 18L23 22 30 22 29 18 25 16 23 5Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#a4824e",
				d: "M-30-2C-29-12-20-18-7-16Q7-14 17-18Q22-22 27-19Q25-24 29-24Q32-25 34-21Q38-22 41-20Q43-18 40-14Q41-11 36-10L31-7Q29-2 27 3Q25 9 26 13L31 21Q36 20 36 24Q33 27 27 25Q22 23 20 17L16 8Q8 12-4 7Q-9 6-13 8L-20 11Q-23 17-22 20L-17 22Q-15 26-20 26L-26 24Q-30 23-29 18L-28 10-33 10Q-34 5-30-2Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#bd9c64",
				stroke: "none",
				d: "M-25-7C-17-15-7-13 7-11Q15-11 22-16L24-7Q18-2 11 2Q2 5-8 1Q-18-1-27 8Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#d3bd8a",
				stroke: "none",
				d: "M25-9Q29-15 34-13L39-15Q40-10 33-7L28 0 25 0ZM-19 12q-3 7-1 9l4 3-6-1-3-4M21 12q1 7 6 11l6 1-6-1-4-5"
			}),
			/* @__PURE__ */ h("path", {
				stroke: "#695032",
				fill: "none",
				strokeWidth: "1",
				d: "M-16-3q-4 5-3 11M15-6q-1 7 2 12m11-27q-1 3 2 4m-5 13q-2 5-1 10m9-13q3 2 6 1"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#5d4934",
				stroke: "none",
				d: "M28-20q1-3 3 0l-1 2Z"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "35",
				cy: "-16",
				r: "1",
				fill: "#27241e",
				stroke: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "m39-14 3-1-1 3",
				fill: "#3a3026",
				stroke: "none"
			})
		]
	}) : e === "marmot" ? /* @__PURE__ */ g("g", {
		stroke: "#f6ecd9",
		strokeWidth: "2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				fill: "#867c66",
				d: "M4 26C14 28 25 24 32 17 36 12 40 10 41 14 38 28 24 35 8 33L-5 31Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#9a917b",
				d: "M-16-26C-20-31-24-32-23-36Q-24-39-19-39Q-13-39-9-35Q-6-38-3-34C4-33 7-25 8-18L14 7C17 23 11 31 2 32Q-7 34-13 30L-18 28Q-24 30-25 26Q-23 23-17 23C-21 10-23-1-19-12L-20-22Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#b0a38b",
				stroke: "none",
				d: "M-6-31C3-27 3-15 7-3L10 14C10 24 5 28-2 28Q-14 25-15 11Q-17 1-13-2Q-18-20-6-31Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#7b705b",
				strokeWidth: "1",
				d: "M-5-13C0-11-2-3-8 2L-14 6-17 3-11-1Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "none",
				stroke: "#c7baa0",
				strokeWidth: ".9",
				d: "m-17 0 1 5m1 2 1 6m9-5 1 7m1 2 1 6M-11-28l-5 6m18 5 2 8m-16 8 1 5m3-25 1 5m8 24 11-4m-5 6 10-5"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#7b7465",
				stroke: "none",
				d: "M-8-33q2-4 5 0l-2 2Z"
			}),
			/* @__PURE__ */ h("path", {
				d: "m-21 26 3 1m-1-3 3 1m9 7 1-3m3 4 1-3",
				stroke: "#5b574c",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#655d4e",
				stroke: "none",
				d: "m-24-36 6-1-2 4M-13 29l12 2-1 3-11-1"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "-11",
				cy: "-31",
				r: "1.5",
				fill: "#2c2b26",
				stroke: "none"
			})
		]
	}) : /* @__PURE__ */ g("g", {
		stroke: "#fbefce",
		strokeWidth: "2.2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				fill: "#888982",
				d: "M-30 15C-35 0-26-17-13-22Q-10-24-7-25Q-7-32-1-31Q3-32 5-27C15-30 28-25 31-14Q33-7 29-2L24 3Q24 11 20 18Q20 23 14 24L-11 26C-20 25-26 23-30 15Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#b3b0a1",
				stroke: "none",
				d: "M-25 9C-25-3-18-17-6-18Q1-19 4-20Q14-27 24-18Q30-12 26-6Q24-3 19-1Q16 3 17 9Q18 17 9 21Q0 23-8 22C-17 21-22 19-25 9Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#777c78",
				strokeWidth: "1",
				d: "M3-16C-4-18-6-25-2-28 5-33 13-27 13-22L10-16Z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#575f60",
				stroke: "none",
				d: "M3-20C0-22 0-26 4-27 9-27 10-23 8-21Z"
			}),
			/* @__PURE__ */ h("path", {
				stroke: "#d9cbb1",
				fill: "none",
				strokeWidth: "1.1",
				d: "m-23 1 5 3m-1-13 5 2m0 24 4 3m-4-29 5 2m4 3 5 1m-27 4 4 2"
			}),
			/* @__PURE__ */ h("path", {
				d: "M18 3q-5 3-4 10l-2 5q2 3 6 1m-25 3q3-3 7-1",
				fill: "none",
				stroke: "#74786f",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "23",
				cy: "-17",
				r: "1.8",
				fill: "#272e2c",
				stroke: "none"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#5e605a",
				stroke: "none",
				d: "m29-10 3 2-3 2"
			}),
			/* @__PURE__ */ h("path", {
				stroke: "#faf2d9",
				strokeWidth: "1",
				d: "m29-3 8 5m-10-3 4 7"
			})
		]
	});
}
function qe({ animal: e, size: t = 40, className: n = "" }) {
	let i = r().replaceAll(":", "");
	return /* @__PURE__ */ g("svg", {
		viewBox: "-52 -52 104 104",
		width: t,
		height: t,
		className: n,
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("radialGradient", {
				id: i,
				children: [
					/* @__PURE__ */ h("stop", {
						stopColor: "#fff",
						stopOpacity: ".18"
					}),
					/* @__PURE__ */ h("stop", {
						offset: ".9",
						stopColor: "#000",
						stopOpacity: "0"
					}),
					/* @__PURE__ */ h("stop", {
						offset: "1",
						stopColor: "#000",
						stopOpacity: ".18"
					})
				]
			}) }),
			/* @__PURE__ */ h("circle", {
				cy: "2",
				r: "49",
				fill: "#715333"
			}),
			/* @__PURE__ */ h("circle", {
				r: "48",
				fill: We[e],
				stroke: "#ead3a6",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ h("circle", {
				r: "47",
				fill: `url(#${i})`
			}),
			/* @__PURE__ */ h("g", {
				transform: "scale(.91)",
				children: /* @__PURE__ */ h(Ke, { animal: e })
			})
		]
	});
}
function Je() {
	return /* @__PURE__ */ h("path", {
		fill: "#fff",
		d: "M0-16C2-18 3-14 3-11Q6-14 7-11L7-7Q7-4 9-2L7 1 9 3 8 5Q12 4 11 8L9 10 10 12 6 15 3 16 0 19Q-1 20-3 17L-7 15-10 12-11 9-13 7Q-15 5-12 4L-10 3-12 1Q-14-1-12-3L-9-1-8-3Q-11-4-11-7L-8-8Q-10-11-8-12L-5-9-5-14-3-13Q-2-17 0-16Z"
	});
}
function Ye({ size: e = 24 }) {
	return /* @__PURE__ */ g("svg", {
		width: e,
		height: e,
		viewBox: "-20 -20 40 40",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ h("circle", {
			r: "19",
			fill: "#8da467"
		}), /* @__PURE__ */ h("g", {
			transform: "translate(1 -1) scale(.82)",
			children: /* @__PURE__ */ h(Je, {})
		})]
	});
}
function Xe({ x: e, y: t, s: n = 1 }) {
	return /* @__PURE__ */ g("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ h("path", {
				d: "m-1 4-.5 11 3-.5L1 3Z",
				fill: "#967b54"
			}),
			/* @__PURE__ */ h("path", {
				d: "m0 7 .3 7",
				stroke: "#c0a075",
				strokeWidth: ".6"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0-16Q-1-11-4-8L-2-8Q-4-3-7-1L-4-1Q-6 3-10 6L-7 6-11 10Q-5 12 0 10Q5 12 11 10L7 6 9 6Q6 2 4-2L7-1Q3-6 3-8L5-7Q2-11 0-16Z",
				fill: "#173f38"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0-16Q2-9 4-8L2-8Q4-3 6-2L3-3Q5 3 8 5L5 4Q7 8 10 10L3 9 0 10Z",
				fill: "#4d8060"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0-11q-2 4-4 5m4-1q-2 6-6 8m6-3q-2 6-8 9M1-7l2 3M1-1q1 4 4 6m-4 0 4 4",
				stroke: "#87a27a",
				strokeWidth: ".65",
				fill: "none"
			})
		]
	});
}
function Ze({ habitat: e, lake: t = !1 }) {
	return /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h("polygon", {
			points: Ue,
			fill: Ge[e]
		}),
		e === "forest" ? /* @__PURE__ */ h(m, { children: [
			[
				-30,
				-21,
				.9
			],
			[
				-10,
				-26,
				.8
			],
			[
				13,
				-26,
				1
			],
			[
				32,
				-12,
				.85
			],
			[
				-32,
				7,
				1.1
			],
			[
				-10,
				-2,
				1.2
			],
			[
				13,
				2,
				1
			],
			[
				31,
				17,
				.9
			],
			[
				-17,
				25,
				.7
			],
			[
				4,
				27,
				1
			]
		].map(([e, t, n], r) => /* @__PURE__ */ h(Xe, {
			x: e,
			y: t,
			s: n
		}, r)) }) : e === "meadow" ? /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "M-50 7Q-20-8 8 7T50-1L25 44H-25Z",
				fill: "#96af55"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-42-12Q-10-32 24-19L39-5Q5-21-33 0Z",
				fill: "#c6cf7d"
			}),
			Array.from({ length: 23 }, (e, t) => {
				let n = t * 31 % 73 - 37, r = t * 19 % 64 - 32;
				return /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
					d: `m${n} ${r} 2-5m-2 5-3-3`,
					stroke: "#6b9452",
					strokeWidth: ".9"
				}), t % 3 == 0 && /* @__PURE__ */ h("circle", {
					cx: n + 2,
					cy: r - 5,
					r: "1.2",
					fill: t % 2 ? "#e9dd93" : "#c69eaf"
				})] }, t);
			})
		] }) : /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				d: "m-48 1 19-16 12-23 18 24 15-20 14 25 19 13-24 35-50 3Z",
				fill: "#dae5df"
			}),
			/* @__PURE__ */ h("path", {
				d: "m-17-38 5 24L1-14-5-2l23 15L7 39l18 2 24-35-19-13-14-27L8-9Z",
				fill: "#91b3c2"
			}),
			/* @__PURE__ */ h("path", {
				d: "m-17-38-1 17-11 6 7 7-15 16 18 5L-8 1 6-5-2-14Z",
				fill: "#f4f3df"
			}),
			/* @__PURE__ */ h("path", {
				d: "m-41 15 23 4 8 19m-6-19 18-7 14 5m-14-5 3-11m20 33-5-9 12-14",
				stroke: "#7193a3",
				strokeWidth: "1.3",
				fill: "none"
			})
		] }),
		t && /* @__PURE__ */ g("g", { children: [
			/* @__PURE__ */ h("path", {
				d: "M-30-15Q-20-29-4-26L10-23 22-25Q36-14 29-2L33 10Q17 28-3 25L-21 28Q-35 15-29 6L-34-4Z",
				fill: "#e0e6be"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-26-13Q-18-24-4-22L10-18 21-21Q30-14 25-2L28 9Q16 22-3 21L-18 23Q-30 14-25 5L-29-4Z",
				fill: "#4cabc0"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-21-10Q-7-21 8-13L20-15 18-1 24 8Q9 19-8 17L-20 15-17 1Z",
				fill: "#287c9b"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-20-9q12-7 21-4m-13 27q15 4 26-5",
				stroke: "#b3e0d3",
				strokeWidth: "1.3",
				fill: "none"
			})
		] }),
		/* @__PURE__ */ h("polygon", {
			points: Ue,
			fill: "none",
			stroke: "#e4d7a9",
			strokeWidth: "1.8"
		})
	] });
}
function Qe({ half: e, level: t = 1, occupied: n, showLevel: i = !0 }) {
	let a = r().replaceAll(":", ""), o = Math.min(25, 3 + (t - 1) * 4);
	return /* @__PURE__ */ g("g", { children: [
		/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ h("clipPath", {
			id: a,
			children: /* @__PURE__ */ h("polygon", { points: Ue })
		}) }),
		/* @__PURE__ */ h("polygon", {
			points: `-50,0 -25,43.3 25,43.3 50,0 50,${o} 25,${43.3 + o} -25,${43.3 + o} -50,${o}`,
			fill: "#706952",
			stroke: "#504e3d",
			strokeWidth: "1"
		}),
		Array.from({ length: t - 1 }, (e, t) => /* @__PURE__ */ h("path", {
			d: `M-49 ${4 + t * 4} -25 ${47 + t * 4} 25 ${47 + t * 4} 49 ${4 + t * 4}`,
			fill: "none",
			stroke: "#a79a73",
			strokeWidth: ".8"
		}, t)),
		/* @__PURE__ */ h("g", {
			clipPath: `url(#${a})`,
			children: /* @__PURE__ */ h(Ze, {
				habitat: e.habitat,
				lake: e.lake
			})
		}),
		n ? /* @__PURE__ */ h("foreignObject", {
			x: "-24",
			y: "-28",
			width: "48",
			height: "48",
			children: /* @__PURE__ */ h(qe, {
				animal: n,
				size: 48
			})
		}) : e.animals.map((t, n) => {
			let r = (n - (e.animals.length - 1) / 2) * 24;
			return /* @__PURE__ */ h("foreignObject", {
				x: r - 15,
				y: "-18",
				width: "30",
				height: "30",
				children: /* @__PURE__ */ h(qe, {
					animal: t,
					size: 30
				})
			}, t);
		}),
		e.animals.length === 1 && !n && /* @__PURE__ */ h("g", {
			transform: "translate(-14 18) scale(.5)",
			children: /* @__PURE__ */ h(Je, {})
		}),
		i && /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("rect", {
			x: "8",
			y: "23",
			width: "18",
			height: "16",
			rx: "5",
			fill: "#faf2d8",
			stroke: "#7b775d",
			strokeWidth: ".8"
		}), /* @__PURE__ */ h("text", {
			x: "17",
			y: "35",
			textAnchor: "middle",
			fill: "#334639",
			fontSize: "13",
			fontWeight: "800",
			children: t
		})] })
	] });
}
function $e({ tile: e }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "-54 -47 108 185",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ h(Qe, {
			half: e[0],
			showLevel: !1
		}), /* @__PURE__ */ h("g", {
			transform: "translate(0 86.6)",
			children: /* @__PURE__ */ h(Qe, {
				half: e[1],
				showLevel: !1
			})
		})]
	});
}
var et = (e) => ({
	habitat: e.habitat,
	animals: e.animals,
	lake: e.lake
});
//#endregion
//#region src/games/cascadiaalpinelakes/board.tsx
function tt({ selected: e = !1, reduced: t }) {
	return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("polygon", {
		points: Ue,
		className: "al-ant-dark"
	}), /* @__PURE__ */ h("polygon", {
		points: Ue,
		className: "al-ant",
		style: { fill: e ? "#fff5b6aa" : "#f7ffda33" },
		children: !t && /* @__PURE__ */ h("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-20",
			dur: "1.1s",
			repeatCount: "indefinite"
		})
	})] });
}
function nt({ board: e, placements: t = [], tokenTargets: n = [], preview: r, tile: i, onTile: s, onToken: c, selectedToken: u, mini: d = !1 }) {
	let f = l("cascadiaalpinelakes"), p = _(), [m, v] = o(1), [y, b] = o([0, 0]), ee = a(null), x = a(null), S = e.map((e) => F(e.q, e.r)), C = S.map((e) => e[0]), w = S.map((e) => e[1]), T = d ? 60 : 225, D = Math.min(...C) - T, te = Math.min(...w) - T, k = Math.max(250, Math.max(...C) - D + T), j = Math.max(250, Math.max(...w) - te + T), M = k / m, N = j / m, P = D + (k - M) / 2 + y[0], I = te + (j - N) / 2 + y[1], L = (e, t) => {
		(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t());
	}, R = () => !x.current?.moved, ne = new Map(t.map((e) => [`${e.q},${e.r}`, e]));
	return /* @__PURE__ */ g("div", {
		className: "al-landscape",
		children: [!d && /* @__PURE__ */ g("div", {
			className: "al-board-tools",
			children: [
				/* @__PURE__ */ h("button", {
					className: "al-tool",
					onClick: () => {
						v(1), b([0, 0]);
					},
					children: f("fit")
				}),
				/* @__PURE__ */ h("button", {
					className: "al-tool",
					"aria-label": f("zoomIn"),
					onClick: () => v((e) => Math.min(3, e * 1.3)),
					children: "＋"
				}),
				/* @__PURE__ */ h("button", {
					className: "al-tool",
					"aria-label": f("zoomOut"),
					onClick: () => v((e) => Math.max(.6, e / 1.3)),
					children: "−"
				})
			]
		}), /* @__PURE__ */ g("svg", {
			ref: ee,
			className: "al-board",
			viewBox: `${P} ${I} ${M} ${N}`,
			role: "group",
			"aria-label": f("board"),
			onPointerDown: (e) => {
				d || (x.current = {
					x: e.clientX,
					y: e.clientY,
					pan: y,
					moved: !1
				});
			},
			onPointerMove: (e) => {
				let t = x.current;
				if (!t || d) return;
				let n = e.clientX - t.x, r = e.clientY - t.y;
				if (Math.abs(n) + Math.abs(r) > 8 && (t.moved = !0), t.moved) {
					let e = ee.current.getBoundingClientRect(), i = Math.max(M / e.width, N / e.height);
					b([t.pan[0] - n * i, t.pan[1] - r * i]);
				}
			},
			onPointerUp: () => {
				if (x.current?.moved) {
					let e = x.current;
					window.setTimeout(() => {
						x.current === e && (x.current = null);
					}, 0);
				} else x.current = null;
			},
			onPointerLeave: () => {
				x.current = null;
			},
			children: [
				[...e].sort((e, t) => F(e.q, e.r)[1] - F(t.q, t.r)[1]).map((e) => {
					let [t, r] = F(e.q, e.r), i = n.some((t) => A(t) === A(e));
					return /* @__PURE__ */ g("g", {
						transform: `translate(${t} ${r - (e.level - 1) * 4})`,
						children: [/* @__PURE__ */ h("g", {
							className: e.serial ? "al-cell-appear" : "",
							children: /* @__PURE__ */ h(Qe, {
								half: et(e),
								level: e.level,
								occupied: e.animal
							})
						}, `${A(e)}:${e.serial}`), i && /* @__PURE__ */ g("g", {
							role: "button",
							tabIndex: 0,
							"aria-label": f("placeAt", {
								q: e.q,
								r: e.r
							}),
							onClick: () => {
								R() && c?.(e);
							},
							onKeyDown: (t) => L(t, () => c?.(e)),
							children: [/* @__PURE__ */ g("title", { children: [
								f(e.habitat),
								" · ",
								f("level", { n: e.level })
							] }), /* @__PURE__ */ h(tt, {
								reduced: p,
								selected: u && A(e) === A(u)
							})]
						})]
					}, A(e));
				}),
				[...ne.values()].map((e) => {
					let [t, n] = F(e.q, e.r);
					return /* @__PURE__ */ g("g", {
						transform: `translate(${t} ${n - (e.level - 1) * 4})`,
						role: "button",
						tabIndex: 0,
						"aria-label": f("placeAt", {
							q: e.q,
							r: e.r
						}),
						onClick: () => {
							R() && s?.(e);
						},
						onKeyDown: (t) => L(t, () => s?.(e)),
						children: [/* @__PURE__ */ h("title", { children: f("level", { n: e.level }) }), /* @__PURE__ */ h(tt, {
							reduced: p,
							selected: r?.q === e.q && r?.r === e.r
						})]
					}, `${e.q},${e.r}`);
				}),
				r && i && /* @__PURE__ */ h("g", {
					opacity: ".78",
					pointerEvents: "none",
					children: E[i - 1].map((e, t) => {
						let [n, i] = O[r.dir], [a, o] = F(r.q + n * t, r.r + i * t);
						return /* @__PURE__ */ h("g", {
							transform: `translate(${a} ${o - (r.level - 1) * 4})`,
							children: /* @__PURE__ */ h(Qe, {
								half: e,
								level: r.level
							})
						}, t);
					})
				})
			]
		})]
	});
}
//#endregion
//#region src/games/cascadiaalpinelakes/cards.tsx
var rt = (e) => e > 9 ? `P${e - 9}` : String(e);
function it({ habitat: e, letter: t, mode: n, onClick: r }) {
	let i = l("cascadiaalpinelakes"), a = n === "family" ? "familyText" : n === "intermediate" ? "intermediateText" : `${e}${t}`;
	return /* @__PURE__ */ g("button", {
		type: "button",
		className: "al-score-card",
		onClick: r,
		children: [
			/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("span", { children: i(e) }), /* @__PURE__ */ h("span", { children: n === "family" ? i("optFamily") : n === "intermediate" ? i("optIntermediate") : t })] }),
			/* @__PURE__ */ h("div", {
				className: "al-card-illustration",
				children: /* @__PURE__ */ g("svg", {
					viewBox: "-85 -40 170 80",
					"aria-hidden": !0,
					children: [/* @__PURE__ */ h("g", {
						transform: "translate(-30 2) scale(.8)",
						children: /* @__PURE__ */ h(Ze, { habitat: e })
					}), /* @__PURE__ */ h("g", {
						transform: "translate(33 -3) scale(.8)",
						children: /* @__PURE__ */ h(Ze, { habitat: e })
					})]
				})
			}),
			/* @__PURE__ */ h("p", { children: i(a) })
		]
	});
}
function at({ pub: e, open: t, onClose: n }) {
	let r = l("cascadiaalpinelakes");
	return /* @__PURE__ */ h("div", {
		className: "al-overlay",
		children: /* @__PURE__ */ h(v, {
			open: t,
			onClose: n,
			label: r("details"),
			title: r("cards"),
			children: /* @__PURE__ */ g("div", {
				className: "al-sheet",
				children: [
					e.config.challenge === "scenario" && /* @__PURE__ */ g("section", { children: [
						/* @__PURE__ */ h("h3", { children: r("scenario", { n: e.config.scenario }) }),
						/* @__PURE__ */ h("p", { children: r("scoreTarget", {
							a: Q[e.config.scenario - 1][4],
							b: Q[e.config.scenario - 1][5],
							c: Q[e.config.scenario - 1][6]
						}) }),
						e.config.scenario >= 8 && /* @__PURE__ */ h("p", { children: r(`goal${e.config.scenario}`) })
					] }),
					e.config.challenge === "modifier" && /* @__PURE__ */ g("section", { children: [/* @__PURE__ */ h("h3", { children: r(`mod${e.config.modification}`) }), /* @__PURE__ */ h("p", { children: r("modifierTarget") })] }),
					/* @__PURE__ */ h("div", {
						className: "al-detail-grid",
						children: T.flatMap((t) => e.cards[t].map((n) => /* @__PURE__ */ h(it, {
							habitat: t,
							letter: n,
							mode: e.config.cards
						}, t + n)))
					}),
					/* @__PURE__ */ h("h3", { children: r(e.config.lake) }),
					/* @__PURE__ */ h("p", { children: e.config.lake === "standard" ? r("standardText") : e.config.lake === "cascading" ? r("cascadingText") : r("wildlandsText") }),
					/* @__PURE__ */ h("h3", { children: r("elevation") }),
					/* @__PURE__ */ h("p", { children: r("elevationText") }),
					e.config.highestBonus && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("h3", { children: r("bonus") }), /* @__PURE__ */ h("p", { children: r("bonusText") })] }),
					e.environment.map((e) => /* @__PURE__ */ g("section", { children: [/* @__PURE__ */ g("h3", { children: [
						r(e.type),
						" ",
						rt(e.card)
					] }), /* @__PURE__ */ h("p", { children: r(`${e.type}${e.card}`) })] }, e.type))
				]
			})
		})
	});
}
//#endregion
//#region src/games/cascadiaalpinelakes/view-player.tsx
function ot(e) {
	let t = e.public;
	return p(), /* @__PURE__ */ h(st, {
		...e,
		pub: t
	}, `${t.turn}:${t.players[t.turn].turns}:${t.picked?.tile ?? "draft"}`);
}
function st({ pub: e, members: t, myRid: n, send: r }) {
	let a = l("cascadiaalpinelakes"), p = u((e) => e.locale), _ = e.players[e.turn], v = e.players.find((e) => e.rid === n), y = _.rid === n, [b, ee] = o(v?.rid ?? _.rid), [x, S] = o(!1), [C, w] = o("tile"), [D, te] = o(0), [k, j] = o(0), [M, N] = o(!1), [P, F] = o(!1), [I, L] = o([]), [R, ne] = o(0), [re, ie] = o(!1), [z, B] = o(), [V, ae] = o(), [H, oe] = o(!1), U = e.players.find((e) => e.rid === b) ?? _, W = e.picked, G = y && b === n && e.phase !== "resolve" && e.phase !== "done", se = i(() => Fe(e), [e]), K = W && !W.tilePending ? "token" : W && !W.tokenPending ? "tile" : C, ce = i(() => W?.tilePending && G && K === "tile" ? je(U.board, W.tile, se, U.nature).filter((e) => e.dir === R && e.scaffold === re) : [], [
		W,
		G,
		K,
		U.board,
		U.nature,
		se,
		R,
		re
	]), le = W?.tokenPending && G && K === "token" ? Pe(U.board, W.token, se, U.nature, W.tilePending ? W.tile : void 0) : [], ue = e.phase !== "draft" || !v || !e.display[D].tile || Ne(v.board, e.display[D].tile, se, v.nature - Number(D !== k)), q = z && ce.find((e) => e.q === z.q && e.r === z.r), de = V && le.find((e) => A(e) === A(V)), J = (e) => {
		B(void 0), ae(void 0), oe(!1), r(e);
	}, Y = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? d(n, p) : e;
	}, X = e.phase === "done" ? a("reviewing") : y ? e.phase === "draft" ? a("draft") : e.phase === "resolve" ? a("resolve") : a(K === "tile" ? "selectTile" : "selectToken") : a("waiting", { name: Y(_.rid) }), fe = (e) => {
		let t = (R + e) % 6;
		ne(t), B((e) => e ? {
			...e,
			dir: t
		} : void 0);
	}, Z = f(`al-nature:${n}`), pe = /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
		className: "al-header",
		children: [
			/* @__PURE__ */ h("div", {
				className: "al-seats",
				children: e.players.map((e) => /* @__PURE__ */ g("button", {
					className: "al-seat",
					"aria-pressed": b === e.rid,
					"data-turn": _.rid === e.rid,
					onClick: () => ee(e.rid),
					children: [/* @__PURE__ */ h("strong", { children: Y(e.rid) }), /* @__PURE__ */ g("span", {
						className: "al-nature",
						ref: e.rid === n ? Z.ref : void 0,
						children: [/* @__PURE__ */ h(Ye, {}), e.nature]
					})]
				}, e.rid))
			}),
			/* @__PURE__ */ h("span", {
				className: "al-round",
				children: a("round", { n: e.round })
			}),
			/* @__PURE__ */ h("button", {
				className: "al-tool",
				onClick: () => S(!0),
				children: a("cards")
			})
		]
	}), /* @__PURE__ */ h("div", {
		className: "al-banner",
		children: /* @__PURE__ */ h(s, {
			tone: y && e.phase !== "resolve" ? "accent" : "info",
			text: X,
			accent: "#315e4c"
		})
	})] }), me = e.phase === "draft" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("div", {
		className: "al-control-row",
		children: P ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
			className: "al-btn",
			onClick: () => {
				F(!1), L([]);
			},
			children: a("cancel")
		}), /* @__PURE__ */ h("button", {
			className: "al-btn al-btn-primary",
			disabled: !G || !I.length || !v?.nature,
			onClick: () => {
				J({
					type: "wipe",
					indices: I
				}), F(!1), L([]);
			},
			children: a("wipe")
		})] }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
			className: "al-btn",
			"aria-pressed": M,
			disabled: !G || !v?.nature,
			onClick: () => {
				N((e) => !e), j(D);
			},
			children: a("mix")
		}), /* @__PURE__ */ h("button", {
			className: "al-btn al-btn-primary",
			disabled: !G || !ue,
			onClick: () => J({
				type: "pick",
				tile: D,
				token: k
			}),
			children: a("pick")
		})] })
	}), !P && /* @__PURE__ */ g("div", {
		className: "al-control-row",
		children: [/* @__PURE__ */ h("button", {
			className: "al-btn",
			disabled: !G || !v?.nature,
			onClick: () => F(!0),
			children: a("wipeMode")
		}), /* @__PURE__ */ h("button", {
			className: "al-btn",
			disabled: !G || e.wipe3Used || !e.display.some((t) => e.display.filter((e) => e.token === t.token).length === 3),
			onClick: () => J({ type: "wipe3" }),
			children: a("wipe3")
		})]
	})] }) : W && e.phase === "place" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
		className: "al-control-row",
		children: [W.tilePending && /* @__PURE__ */ h("button", {
			className: "al-btn",
			"aria-pressed": K === "tile",
			onClick: () => {
				w("tile"), oe(!1);
			},
			disabled: !G,
			children: a("placeTile")
		}), W.tokenPending && /* @__PURE__ */ h("button", {
			className: "al-btn",
			"aria-pressed": K === "token",
			onClick: () => w("token"),
			disabled: !G,
			children: a("placeToken")
		})]
	}), K === "tile" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
		className: "al-control-row",
		children: [
			/* @__PURE__ */ h("button", {
				className: "al-btn",
				disabled: !G,
				onClick: () => fe(1),
				children: a("rotate")
			}),
			/* @__PURE__ */ h("button", {
				className: "al-btn",
				disabled: !G,
				onClick: () => {
					let [e, t] = O[R], n = (R + 3) % 6;
					ne(n), B((r) => r ? {
						...r,
						q: r.q + e,
						r: r.r + t,
						dir: n
					} : void 0);
				},
				children: a("flip")
			}),
			/* @__PURE__ */ h("button", {
				className: "al-btn al-btn-primary",
				disabled: !G || !q,
				onClick: () => q && J({
					type: "placeTile",
					...q
				}),
				children: a("placeTile")
			})
		]
	}), e.config.challenge === "modifier" && e.config.modification === 5 && /* @__PURE__ */ g("label", {
		className: "al-help",
		children: [
			/* @__PURE__ */ h("input", {
				type: "checkbox",
				checked: re,
				disabled: !G || !v?.nature,
				onChange: (e) => {
					ie(e.target.checked), B(void 0);
				}
			}),
			" ",
			a("scaffold")
		]
	})] }) : /* @__PURE__ */ g("div", {
		className: "al-control-row",
		children: [/* @__PURE__ */ h("button", {
			className: "al-btn",
			disabled: !G,
			onClick: () => H ? J({ type: "skipToken" }) : oe(!0),
			children: a(H ? "confirmSkip" : "skipToken")
		}), /* @__PURE__ */ h("button", {
			className: "al-btn al-btn-primary",
			disabled: !G || !de,
			onClick: () => de && J({
				type: "placeToken",
				q: de.q,
				r: de.r
			}),
			children: a("placeToken")
		})]
	})] }) : /* @__PURE__ */ h("p", {
		className: "al-help",
		children: a("resolve")
	}), he = W && e.phase === "place" ? /* @__PURE__ */ g("div", {
		className: "al-selection",
		role: "group",
		"aria-label": a("place"),
		children: [/* @__PURE__ */ g("div", {
			className: "al-selected-piece",
			children: [/* @__PURE__ */ h("span", {
				className: "al-selected-label",
				children: a("selectedTile")
			}), /* @__PURE__ */ h("div", {
				className: "al-selected-art al-selected-tile",
				children: /* @__PURE__ */ h($e, { tile: E[W.tile - 1] })
			})]
		}), /* @__PURE__ */ g("div", {
			className: "al-selected-piece",
			children: [/* @__PURE__ */ h("span", {
				className: "al-selected-label",
				children: a("selectedToken")
			}), /* @__PURE__ */ g("div", {
				className: "al-selected-art",
				children: [/* @__PURE__ */ h(qe, {
					animal: W.token,
					size: 72
				}), /* @__PURE__ */ h("strong", { children: a(W.token) })]
			})]
		})]
	}) : null, ge = /* @__PURE__ */ g("div", {
		className: "al-dock",
		children: [he ?? /* @__PURE__ */ h("div", {
			className: "al-market",
			children: e.display.map((t, n) => /* @__PURE__ */ g("div", {
				className: "al-pair",
				children: [
					/* @__PURE__ */ h("span", {
						className: "al-pair-no",
						children: n + 1
					}),
					/* @__PURE__ */ h("button", {
						className: "al-tile-pick",
						"aria-label": `${a("tile")} ${n + 1}`,
						"aria-pressed": e.phase === "draft" && !P && n === D,
						disabled: !G || e.phase !== "draft" || P,
						onClick: () => {
							te(n), M || j(n);
						},
						children: t.tile ? /* @__PURE__ */ h($e, { tile: E[t.tile - 1] }) : /* @__PURE__ */ h("span", {
							className: "al-slot-empty",
							children: "—"
						})
					}),
					/* @__PURE__ */ h("button", {
						className: "al-animal-pick",
						"aria-label": `${a("token")} ${n + 1}${t.token ? ` ${a(t.token)}` : ""}`,
						"aria-pressed": e.phase === "draft" && (P ? I.includes(n) : n === k),
						disabled: !G || e.phase !== "draft",
						onClick: () => {
							P ? L((e) => e.includes(n) ? e.filter((e) => e !== n) : [...e, n]) : (j(n), M || te(n));
						},
						children: t.token ? /* @__PURE__ */ h(qe, {
							animal: t.token,
							size: 48
						}) : /* @__PURE__ */ h("span", {
							className: "al-slot-empty",
							children: "—"
						})
					})
				]
			}, n))
		}), /* @__PURE__ */ h("div", {
			className: "al-controls",
			children: me
		})]
	});
	return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(c, {
		adaptive: !0,
		className: `alpine${p === "en" ? " alpine-en" : ""}`,
		scroll: !1,
		banner: pe,
		actionsHeight: e.phase === "done" ? void 0 : "al-dock-height",
		actions: ge,
		children: /* @__PURE__ */ g("div", {
			className: "al-layout",
			children: [/* @__PURE__ */ g("div", {
				className: "al-board-region",
				children: [/* @__PURE__ */ h(nt, {
					board: U.board,
					placements: ce,
					tokenTargets: le,
					tile: W?.tile,
					preview: q,
					selectedToken: de,
					onTile: B,
					onToken: (e) => {
						ae(e), oe(!1);
					}
				}, b), q ? /* @__PURE__ */ h("div", {
					className: "al-phase",
					children: a("preview", { level: q.level })
				}) : W && G && K === "token" && !le.length ? /* @__PURE__ */ h("div", {
					className: "al-phase",
					children: a("noToken")
				}) : G && !ue ? /* @__PURE__ */ h("div", {
					className: "al-phase",
					children: a("noTile")
				}) : G && se !== e.config ? /* @__PURE__ */ h("div", {
					className: "al-phase",
					children: a("matchExempt")
				}) : null]
			}), /* @__PURE__ */ g("aside", {
				className: "al-card-rail",
				children: [T.flatMap((t) => e.cards[t].map((n) => /* @__PURE__ */ h(it, {
					habitat: t,
					letter: n,
					mode: e.config.cards,
					onClick: () => S(!0)
				}, t + n))), e.environment.length > 0 && /* @__PURE__ */ g("button", {
					className: "al-card-more",
					onClick: () => S(!0),
					children: [
						a("environment"),
						" · ",
						e.environment.length
					]
				})]
			})]
		})
	}), /* @__PURE__ */ h(at, {
		pub: e,
		open: x,
		onClose: () => S(!1)
	})] });
}
//#endregion
//#region src/games/cascadiaalpinelakes/bot.ts
var ct = {
	exactScore: .7,
	elevation: .9,
	room: .15,
	nature: 1.2,
	search: 1
}, lt = (e) => {
	let t = Math.floor(4294967296 / e.length) * e.length, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return e[n % e.length];
};
function ut(e, t, n, r) {
	let i = P(e), a = e.reduce((e, t) => e + (t.animal ? Math.max(0, t.level - 1) * r.elevation : (t.level - 1) * .2), 0), o = e.filter((e) => !e.animal && !e.lake).length * r.room, s = e.reduce((t, n) => t + (n.animal ? e.filter((e) => e.animal === n.animal && j(e, n)).length * .45 : 0), 0), c = ve(e, t.lake), l = e.filter((e) => e.animal && e.level >= 3).length * 2, u = r.exactScore ? T.reduce((r, i) => r + Math.max(...n[i].map((n) => _e(e, i, n, t.cards))), 0) : 0, d = e.filter((e) => e.level >= 2 && N(e).some((t) => (i.get(t)?.level ?? 0) === e.level - 1)).length * .25;
	return a + o + s + c + l + u * r.exactScore + d;
}
function dt(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t);
	return je(i.board, n, Fe(e), i.nature).map((t) => {
		let a = Ie(i.board, n, t, e.serial);
		return {
			placement: t,
			value: ut(a.board, e.config, e.cards, r) + (a.nature - Number(t.scaffold)) * r.nature
		};
	}).sort((e, t) => t.value - e.value);
}
function ft(e = ct) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i || r.players[r.turn].rid !== n.rid || r.phase === "resolve" || r.phase === "done") return null;
		if (r.phase === "draft") {
			if (n.difficulty === "weak") {
				let e = r.display.flatMap((e, t) => e.tile && Ne(i.board, e.tile, Fe(r), i.nature) ? [t] : []);
				if (!e.length) return null;
				let t = lt(e);
				return { action: {
					type: "pick",
					tile: t,
					token: t
				} };
			}
			let t = {
				type: "pick",
				tile: 0,
				token: 0
			}, a = -Infinity;
			for (let o = 0; o < r.display.length; o++) {
				let s = r.display[o].tile, c = dt(r, n.rid, s, e).slice(0, e.search);
				for (let n = 0; n < r.display.length; n++) {
					if (o !== n && !i.nature) continue;
					let l = r.display[n].token, u = Math.max(...c.map((t) => {
						let a = Ie(i.board, s, t.placement, r.serial).board, c = Me(a, l, r.config), u = Math.max(0, ...c.map((t) => (t.level - 1) * e.elevation + (t.level >= 3 ? 2 : 0) + (t.animals.length === 1 ? e.nature : 0) + a.filter((e) => e.animal === l && j(e, t)).length * .9));
						return t.value + u + (c.length ? 1 : -2) - (o === n ? 0 : e.nature + .8);
					}));
					u > a && (a = u, t = {
						type: "pick",
						tile: o,
						token: n
					});
				}
			}
			return Number.isFinite(a) ? { action: t } : null;
		}
		let a = r.picked;
		if (a.tilePending) {
			let t = n.difficulty === "weak" ? je(i.board, a.tile, Fe(r), i.nature) : dt(r, n.rid, a.tile, e).map((e) => e.placement);
			return { action: {
				type: "placeTile",
				...n.difficulty === "weak" ? lt(t) : t[0]
			} };
		}
		if (a.tokenPending) {
			let t = Me(i.board, a.token, r.config);
			if (!t.length) return { action: { type: "skipToken" } };
			let o = n.difficulty === "weak" ? lt(t) : t.map((t) => ({
				c: t,
				value: ut(i.board.map((e) => e === t ? {
					...e,
					animal: a.token
				} : e), r.config, r.cards, e) + (t.animals.length === 1 ? e.nature : 0)
			})).sort((e, t) => t.value - e.value)[0].c;
			return { action: {
				type: "placeToken",
				q: o.q,
				r: o.r
			} };
		}
		return null;
	};
}
var pt = ft(), mt = (e, t, n) => e.type === "pick" ? n("games.cascadiaalpinelakes.hintPick", {
	tile: e.tile + 1,
	token: e.token + 1
}) : e.type === "placeTile" ? n("games.cascadiaalpinelakes.hintTile", {
	q: e.q,
	r: e.r,
	dir: e.dir + 1
}) : e.type === "placeToken" ? n("games.cascadiaalpinelakes.hintToken", {
	q: e.q,
	r: e.r
}) : n("games.cascadiaalpinelakes.skipToken"), ht = (e, t) => {
	let n = e.data?.nature, r = t.anchor(`al-nature:${e.rid}`);
	if (!n || !r) return null;
	let i = t.queued ? 160 : 360;
	return {
		ms: i,
		node: /* @__PURE__ */ h(y, {
			at: r,
			ms: i,
			children: /* @__PURE__ */ g("span", {
				className: "flex items-center gap-1 rounded bg-[#f4eedb] px-2 text-[#315e4c]",
				children: [
					"+",
					n,
					/* @__PURE__ */ h(Ye, { size: 21 })
				]
			})
		})
	};
}, gt = {
	tile: ht,
	animal: ht
}, _t = t.object({
	version: t.literal(1).default(1),
	normal: t.array(t.int().min(1).max(35)),
	scenarios: t.record(t.string(), t.int().min(1).max(3)),
	modifiers: t.array(t.int().min(1).max(5)),
	matches: t.record(t.string(), t.int().min(1).max(35))
}), vt = () => ({
	version: 1,
	normal: [],
	scenarios: {},
	modifiers: [],
	matches: {}
}), yt = (e) => {
	try {
		let t = _t.safeParse(JSON.parse(e ?? ""));
		return t.success ? t.data : vt();
	} catch {
		return vt();
	}
}, bt = (e, t) => {
	let n = JSON.stringify([
		e.config,
		e.players,
		t
	]), r = 2166136261;
	for (let e = 0; e < n.length; e++) r = Math.imul(r ^ n.charCodeAt(e), 16777619);
	return (r >>> 0).toString(36);
};
function xt({ pub: e, rid: t, score: r, open: i, onClose: a }) {
	let s = l("cascadiaalpinelakes"), [c, u] = o(vt), [d, f] = o(0), [p, _] = o("loading");
	n(() => {
		let e = !0;
		return b().then((t) => {
			e && (u(yt(t.values.hiking)), _("ready"));
		}).catch(() => {
			e && _("error");
		}), () => {
			e = !1;
		};
	}, []);
	let y = bt(e, t), x = e.config, S = x.challenge === "normal", C = x.challenge === "scenario", w = x.challenge === "modifier", T = r?.awards.filter((e) => !c.normal.includes(e)) ?? [], E = S ? !!c.matches[y] : C ? (c.scenarios[String(x.scenario)] ?? 0) >= (r?.scenarioMedal || 4) : w ? c.modifiers.includes(x.modification) : !1, D = !!r && (S ? d > 0 && T.includes(d) && !E : C ? r.scenarioMedal > 0 && !E : w ? !E : !1), te = async () => {
		if (D && p !== "saving") {
			_("saving");
			try {
				for (let e = 0; e < 5; e++) {
					let e = await b(), t = yt(e.values.hiking);
					if (u(structuredClone(t)), S && !t.matches[y]) {
						if (t.normal.includes(d)) throw Error("already earned");
						t.normal.push(d), t.matches[y] = d;
					}
					C && (t.scenarios[String(x.scenario)] = Math.max(t.scenarios[String(x.scenario)] ?? 0, r.scenarioMedal)), w && !t.modifiers.includes(x.modification) && t.modifiers.push(x.modification);
					let n = await ee({
						revision: e.revision,
						values: {
							...e.values,
							hiking: JSON.stringify(t)
						}
					});
					if (n.status === "saved") {
						u(yt(n.snapshot.values.hiking)), _("saved");
						return;
					}
				}
				throw Error("conflict");
			} catch {
				_("error");
			}
		}
	}, O = c.normal.length + Object.keys(c.scenarios).length + c.modifiers.length;
	return /* @__PURE__ */ h("div", {
		className: "al-overlay",
		children: /* @__PURE__ */ h(v, {
			open: i,
			onClose: a,
			label: s("achievements"),
			title: s("achievements"),
			footer: /* @__PURE__ */ h("button", {
				className: "al-btn al-btn-primary w-full",
				disabled: !D || p === "saving" || p === "loading",
				onClick: () => void te(),
				children: s(p === "saving" ? "saving" : p === "error" ? "retry" : p === "saved" || E ? "saved" : "save")
			}),
			children: /* @__PURE__ */ g("div", {
				className: "al-sheet",
				children: [
					/* @__PURE__ */ h("h3", { children: s("progress", { n: O }) }),
					/* @__PURE__ */ h("p", { children: s("localProgress") }),
					/* @__PURE__ */ h("div", {
						className: "al-progress-grid",
						children: Array.from({ length: 60 }, (e, t) => {
							let n = t < 20 ? !!c.scenarios[String(t + 1)] : t < 55 ? c.normal.includes(t - 19) : c.modifiers.includes(t - 54);
							return /* @__PURE__ */ h("span", {
								className: "al-progress-step",
								"data-complete": n,
								title: t < 20 ? s("scenario", { n: t + 1 }) : s(t < 55 ? `a${t - 19}` : `mod${t - 54}`),
								children: t + 1
							}, t);
						})
					}),
					S && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("h3", { children: s(T.length ? "eligible" : "noAward") }), /* @__PURE__ */ h("div", {
						className: "al-award-list",
						children: T.map((e) => /* @__PURE__ */ g("label", {
							className: "al-check",
							children: [
								/* @__PURE__ */ h("input", {
									type: "radio",
									name: "al-award",
									value: e,
									checked: d === e,
									disabled: E,
									onChange: () => f(e)
								}),
								e,
								". ",
								s(`a${e}`)
							]
						}, e))
					})] }),
					C && /* @__PURE__ */ g("p", { children: [
						s("scenario", { n: x.scenario }),
						" · ",
						s(`medal${r?.scenarioMedal ?? 0}`)
					] }),
					w && /* @__PURE__ */ g("p", { children: [
						s(`mod${x.modification}`),
						" · ",
						s("modifierTarget")
					] }),
					p === "error" && /* @__PURE__ */ h("p", {
						className: "al-status",
						role: "status",
						children: s("retry")
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/cascadiaalpinelakes/game-over.tsx
function St(e) {
	let t = e.public, n = l("cascadiaalpinelakes"), r = u((e) => e.locale), [i, a] = o(!1), [s, c] = o(!1), [f, p] = o(!1), m = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? d(n, r) : t;
	}, _ = t.final.find((t) => t.rid === e.myRid), v = t.players.length === 1;
	return /* @__PURE__ */ g("div", {
		className: "alpine al-ending",
		children: [/* @__PURE__ */ g("div", {
			className: "al-review",
			hidden: !i,
			children: [/* @__PURE__ */ h("div", {
				className: "al-review-view",
				children: /* @__PURE__ */ h(ot, {
					public: t,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}), /* @__PURE__ */ h("div", {
				className: "al-review-footer",
				children: /* @__PURE__ */ h("button", {
					className: "al-btn al-btn-primary",
					onClick: () => a(!1),
					children: n("scores")
				})
			})]
		}), /* @__PURE__ */ g("div", {
			className: "al-result",
			hidden: i,
			children: [
				/* @__PURE__ */ g("header", {
					className: "al-result-title",
					children: [/* @__PURE__ */ g("div", { children: [
						/* @__PURE__ */ h("h1", { children: n("result") }),
						/* @__PURE__ */ h("p", { children: v ? n("soloResult", { n: t.final[0].total }) : e.result.winner.length > 1 ? n("sharedWinner") : n("winner", { name: m(e.result.winner[0]) }) }),
						e.hintCount !== void 0 && /* @__PURE__ */ h("p", { children: n("hintsUsed", { n: e.hintCount }) })
					] }), /* @__PURE__ */ h("button", {
						className: "al-btn",
						onClick: () => c(!0),
						children: n("cards")
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "al-result-body",
					children: e.result.ranking.map((r) => {
						let i = t.players.find((e) => e.rid === r), a = t.final.find((e) => e.rid === r), o = (e, t, n = !1) => /* @__PURE__ */ g("div", {
							className: `al-score-row${n ? " al-score-sub" : ""}`,
							children: [/* @__PURE__ */ h("span", { children: e }), /* @__PURE__ */ h("b", { children: t })]
						}, e);
						return /* @__PURE__ */ g("article", {
							className: "al-score-sheet",
							children: [/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ g("h2", { children: [e.result.winner.includes(r) && !v ? "✦ " : "", m(r)] }), /* @__PURE__ */ h("b", { children: a.total })] }), /* @__PURE__ */ g("div", {
								className: "al-score-content",
								children: [/* @__PURE__ */ h("div", {
									className: "al-result-mini",
									children: /* @__PURE__ */ h(nt, {
										board: i.board,
										mini: !0
									})
								}), /* @__PURE__ */ g("div", {
									className: "al-score-breakdown",
									children: [
										T.map((e) => o(`${n(e)} ${t.config.cards === "family" || t.config.cards === "intermediate" ? "" : a.chosen[e]}`, a.habitats[e])),
										o(n("lakes"), a.lakes),
										/* @__PURE__ */ g("details", { children: [/* @__PURE__ */ g("summary", {
											className: "al-score-row",
											children: [/* @__PURE__ */ h("span", { children: n("elevation") }), /* @__PURE__ */ h("b", { children: Object.values(a.elevation).reduce((e, t) => e + t, 0) })]
										}), w.map((e) => /* @__PURE__ */ g("div", {
											className: "al-score-row al-score-sub",
											children: [/* @__PURE__ */ g("span", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ h(qe, {
													animal: e,
													size: 23
												}), n(e)]
											}), /* @__PURE__ */ h("b", { children: a.elevation[e] })]
										}, e))] }),
										/* @__PURE__ */ g("details", { children: [/* @__PURE__ */ g("summary", {
											className: "al-score-row",
											children: [/* @__PURE__ */ h("span", { children: n("bonus") }), /* @__PURE__ */ h("b", { children: Object.values(a.bonus).reduce((e, t) => e + t, 0) })]
										}), w.map((e) => o(n(e), a.bonus[e], !0))] }),
										o(n("nature"), a.nature),
										t.environment.map((e, t) => o(`${n(e.type)} ${rt(e.card)}`, a.environment[t])),
										t.config.challenge === "scenario" && /* @__PURE__ */ g("div", {
											className: "al-status",
											children: [
												/* @__PURE__ */ g("b", { children: [
													n("scenario", { n: t.config.scenario }),
													" · ",
													n(`medal${a.scenarioMedal}`)
												] }),
												/* @__PURE__ */ h("p", { children: n("scoreTarget", {
													a: Q[t.config.scenario - 1][4],
													b: Q[t.config.scenario - 1][5],
													c: Q[t.config.scenario - 1][6]
												}) }),
												t.config.scenario >= 8 && /* @__PURE__ */ g("p", { children: [
													a.goals.every(Boolean) ? "✓" : "○",
													" ",
													n(`goal${t.config.scenario}`)
												] })
											]
										})
									]
								})]
							})]
						}, r);
					})
				}),
				/* @__PURE__ */ g("footer", {
					className: "al-result-footer",
					children: [
						/* @__PURE__ */ h("button", {
							className: "al-btn",
							onClick: () => a(!0),
							children: n("board")
						}),
						_ && t.config.challenge !== "none" && /* @__PURE__ */ h("button", {
							className: "al-btn",
							onClick: () => p(!0),
							children: n("achievements")
						}),
						e.onPlayAgain && /* @__PURE__ */ h("button", {
							className: "al-btn al-btn-primary",
							onClick: e.onPlayAgain,
							children: n("playAgain")
						}),
						e.onBackToLobby && /* @__PURE__ */ h("button", {
							className: "al-btn",
							onClick: e.onBackToLobby,
							children: n("lobby")
						}),
						!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ h("p", { children: n("waitHost") })
					]
				}),
				/* @__PURE__ */ h(at, {
					pub: t,
					open: s,
					onClose: () => c(!1)
				}),
				/* @__PURE__ */ h(xt, {
					pub: t,
					rid: e.myRid,
					score: _,
					open: f,
					onClose: () => p(!1)
				})
			]
		})]
	});
}
//#endregion
//#region src/games/cascadiaalpinelakes/options.tsx
function Ct({ value: e, onChange: t }) {
	let n = l("cascadiaalpinelakes"), r = W.safeParse(e), i = r.success ? r.data : W.parse({}), a = (e) => t({
		...i,
		...e
	});
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ h(C, {
				title: n("optCards"),
				children: [
					"A",
					"random",
					"custom",
					"family",
					"intermediate"
				].map((e, t) => /* @__PURE__ */ h(S, {
					name: "alpine-cards",
					value: e,
					checked: i.cards === e,
					label: n([
						"optA",
						"optRandom",
						"optCustom",
						"optFamily",
						"optIntermediate"
					][t]),
					onChange: () => a({ cards: e })
				}, e))
			}),
			i.cards === "custom" && /* @__PURE__ */ h("div", {
				className: "grid grid-cols-3 gap-2",
				children: T.map((e) => /* @__PURE__ */ g("label", { children: [n(e), /* @__PURE__ */ h("select", {
					className: "w-full rounded border p-2",
					value: i[e],
					onChange: (t) => a({ [e]: t.target.value }),
					children: (i.pristinePeaks ? [
						"A",
						"B",
						"C",
						"D",
						"E",
						"F"
					] : [
						"A",
						"B",
						"C",
						"D"
					]).map((e) => /* @__PURE__ */ h("option", { children: e }, e))
				})] }, e))
			}),
			/* @__PURE__ */ g(C, {
				title: n("optEnvironment"),
				children: [[
					"wildlife",
					"habitat",
					"spatial"
				].map((e) => /* @__PURE__ */ g("label", { children: [n(e), /* @__PURE__ */ g("select", {
					className: "block w-full rounded border p-2",
					value: i[e],
					onChange: (t) => a({ [e]: Number(t.target.value) }),
					children: [/* @__PURE__ */ h("option", {
						value: 0,
						children: n("none")
					}), Array.from({ length: i.pristinePeaks ? 12 : 9 }, (e, t) => /* @__PURE__ */ h("option", {
						value: t + 1,
						children: t >= 9 ? `P${t - 8}` : t + 1
					}, t))]
				})] }, e)), /* @__PURE__ */ g("label", { children: [n("randomCount"), /* @__PURE__ */ h("select", {
					className: "block w-full rounded border p-2",
					value: i.environment,
					onChange: (e) => a({ environment: Number(e.target.value) }),
					children: [
						0,
						1,
						2,
						3
					].map((e) => /* @__PURE__ */ h("option", { children: e }, e))
				})] })]
			}),
			/* @__PURE__ */ h("p", {
				className: "text-xs opacity-70",
				children: n("optEnvironmentHint")
			}),
			/* @__PURE__ */ g(C, {
				title: n("optPeaks"),
				children: [
					/* @__PURE__ */ h(x, {
						name: "alpine-peaks",
						value: "peaks",
						checked: i.pristinePeaks,
						label: n("optPeaks"),
						onChange: () => a({ pristinePeaks: !i.pristinePeaks })
					}),
					/* @__PURE__ */ h(x, {
						name: "alpine-highest",
						value: "highest",
						checked: i.highestBonus,
						label: n("optHighest"),
						onChange: () => a({ highestBonus: !i.highestBonus })
					}),
					i.pristinePeaks && [
						"standard",
						"cascading",
						"wildlands"
					].map((e) => /* @__PURE__ */ h(S, {
						name: "alpine-lake",
						value: e,
						checked: i.lake === e,
						label: n(e),
						onChange: () => a({ lake: e })
					}, e))
				]
			}),
			/* @__PURE__ */ h(C, {
				title: n("optChallenge"),
				children: [
					"none",
					"scenario",
					"normal",
					"modifier"
				].map((e) => /* @__PURE__ */ h(S, {
					name: "alpine-challenge",
					value: e,
					checked: i.challenge === e,
					label: e === "scenario" ? n("scenario", { n: "" }) : e === "modifier" ? n("modifier", { n: "" }) : n(e),
					onChange: () => a({ challenge: e })
				}, e))
			}),
			i.challenge === "scenario" && /* @__PURE__ */ g("label", { children: [
				n("scenario", { n: "" }),
				/* @__PURE__ */ h("select", {
					className: "ml-3 rounded border p-2",
					value: i.scenario,
					onChange: (e) => a({ scenario: Number(e.target.value) }),
					children: Array.from({ length: 20 }, (e, t) => /* @__PURE__ */ h("option", { children: t + 1 }, t))
				}),
				/* @__PURE__ */ h("p", {
					className: "mt-2 text-xs opacity-70",
					children: n("optChallengeHint")
				})
			] }),
			i.challenge === "modifier" && /* @__PURE__ */ h(C, {
				title: n("modifier", { n: "" }),
				children: [
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ h(S, {
					name: "alpine-mod",
					value: String(e),
					checked: i.modification === e,
					label: n(`mod${e}`),
					onChange: () => a({ modification: e })
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/cascadiaalpinelakes/entry.tsx
var wt = {
	definition: He,
	View: ot,
	bot: pt,
	describe: mt,
	fx: gt,
	OverView: St,
	Options: Ct,
	locales: {
		zh: {
			selectedTile: "已选板块",
			selectedToken: "已选动物",
			reviewing: "栖息地回看",
			standardText: "每格湖泊获得等于高度的分数；六边都被地形包围时翻倍。",
			cascadingText: "每群相连湖泊按不同高度数1/2/3/4及以上获得1/4/9/15分。除最高格外，每格必须邻接高一级湖泊。",
			wildlandsText: "湖泊不再计分，但能放置和承托任意动物。",
			elevationText: "每只三级及以上动物获得2分；启用直上云霄修改时，四级及以上动物改为获得4分。",
			bonusText: "逐物种比较动物从高到低的高度，逐只比较至分出高低。两人局第一2分，平手各1分；三四人局第一3分、第二1分，两人并列第一各2分，三人以上并列第一各1分，并列第二0分。无人拥有的物种不计。单人每物种有一只四级及以上动物，或两只三级及以上动物时获得2分。",
			a1: "总分至少80分",
			a2: "总分至少85分",
			a3: "总分至少90分",
			a4: "总分至少95分",
			a5: "总分至少100分",
			a6: "总分至少105分",
			a7: "总分至少110分",
			a8: "结束时没有自然标记",
			a9: "没有鼠兔",
			a10: "没有雪羊",
			a11: "没有美洲狮",
			a12: "没有旱獭",
			a13: "没有白头海雕",
			a14: "一种动物至少8只",
			a15: "一种动物至少10只",
			a16: "至少三种动物独得最高动物奖励",
			a17: "森林至少20分",
			a18: "草甸至少20分",
			a19: "冰川至少20分",
			a20: "森林至少30分",
			a21: "草甸至少30分",
			a22: "冰川至少30分",
			a23: "任一地形至少35分",
			a24: "环境卡合计至少10分",
			a25: "环境卡合计至少15分",
			a26: "环境卡合计至少20分",
			a27: "结束时至少5个自然标记",
			a28: "结束时至少10个自然标记",
			a29: "领先所有对手至少10分",
			a30: "领先所有对手至少15分",
			a31: "地形达到四级",
			a32: "地形达到五级",
			a33: "湖泊至少15分",
			a34: "湖泊至少20分",
			a35: "五种动物各有一只位于三级及以上",
			goal8: "地形达到四级",
			goal9: "每种动物至少三只",
			goal10: "湖泊至少10分",
			goal11: "森林至少20分",
			goal12: "环境卡合计至少10分",
			goal13: "至少5个自然标记",
			goal14: "三种地形合计至少55分",
			goal15: "动物高度与最高奖励合计至少15分",
			goal16: "恰好拥有四种动物",
			goal17: "地形达到五级",
			goal18: "每张环境卡至少5分；鼠兔不邻接白头海雕",
			goal19: "每种地形至少18分；旱獭不邻接湖泊",
			goal20: "环境卡合计至少15分；美洲狮不邻接雪羊",
			scoreTarget: "铜 / 银 / 金：{{a}} / {{b}} / {{c}} 分",
			modifierTarget: "完成使用本规则修改的对局后可记录。",
			localProgress: "进度保存在当前设备。",
			hintsUsed: "本局求助 {{n}} 次",
			name: "卡斯卡迪亚之旅：高山湖泊",
			desc: "叠起高山地形，让五种野生动物栖居湖泊之间。",
			rules: "目标：每人完成20回合后，总分最高者获胜；平分时剩余自然标记较多者获胜，仍相同则并列。\n准备：每人获得一块四格起始板块。供应区展示四组双六角地形板块与动物。三种地形各使用一张计分卡；进阶模式可增加动物、地形、空间三类环境计分卡，每类至多一张。\n回合：\n· 选取一组地形板块与动物。可以先放动物，也可以先放板块，二者都完成后结束回合。\n· 板块可以旋转，放在地面时至少一条边与原有地形相邻；叠放时下方两格必须等高，新板块还必须至少邻接一格高度只比它低一级或更高的地形。\n· 覆盖已有动物时，新格必须允许该动物；动物升到新高度，不能移动或移除。\n· 动物放在印有对应动物且尚无动物的格子。也可以将本回合选取的动物放回袋中。基本湖泊不能放动物。\n· 将动物放到只有一种动物图案的关键栖息地，获得一个自然标记。叠放使已有动物升到关键栖息地时也获得标记；同一回合可能多次获得。\n· 花一个自然标记可任意搭配一块板块与一只动物，或更换供应区任意数量动物；可以多次支付进行更换。标记回到公共供应，数量有限。\n· 四只动物相同时自动更换；恰好三只相同时，每回合可免费更换这三只一次。更换过程中先将旧动物放在一旁，全部更换结束后才放回袋中。\n· 多人局补充原空位，不移动其他供应。单人局取走后，再分别丢弃最远端剩余的一块板块和一只动物，将余下两项向远端滑动，在近端补两项；丢弃物移出游戏。\n计分：\n· 同类地形沿边相连形成地形走廊，相邻关系不受高度影响。根据三张地形卡分别计分，卡片详情列出准确要求与分值。\n· 基本湖泊每格获得等于高度的分数；六边均被地形包围则翻倍。\n· 每只位于三级或更高处的动物获得2分。每种动物另比较各玩家从高到低排列的高度；逐只比较至分出高低。两人局领先者2分，平手各1分；三四人局第一3分、第二1分，两人并列第一各2分、三四人并列第一各1分，并列第二0分。没有该动物者不获奖励。单人局每种动物在四级有至少一只，或三级有至少两只时获得2分奖励。\n· 剩余每个自然标记1分，加上已选环境卡得分。家庭卡与中级卡按同地形中相连的同种动物群计分，可选择关闭最高动物奖励。\n挑战：情景使用指定计分卡与额外目标，达到门槛并满足目标获得铜、银或金牌。普通成就每局只能记录一项尚未完成的成就。完成使用规则修改的对局后可记录该项。进度保存在当前设备的本游戏记录中。\nPristine Peaks（默认关闭）：增加每地形E、F卡及每类环境P1至P3。可改用阶叠湖泊或荒野湖泊。阶叠湖泊按相连湖泊涵盖的高度数获得1/4/9/15分；除最高处外，每格必须邻接高一级湖泊。荒野湖泊不计湖泊分，但允许任意动物。\n五种规则修改：①新板块至少有一格与同高度或更高的外侧同类地形相邻；叠放后若无此高度的邻格则不限制地形；补充裁定：若整组供给都无法合法放置，本回合豁免地形匹配，其余放置规则照常适用；②供应区仅三组；③每地形展示两张卡，终局各选得分较高的一张；④四级及以上动物改为获得4分；⑤每回合可花一个自然标记支撑板块较低的一半，允许下方相差一级。",
			forest: "森林",
			meadow: "草甸",
			glacier: "冰川",
			cougar: "美洲狮",
			eagle: "白头海雕",
			goat: "雪羊",
			marmot: "旱獭",
			pika: "鼠兔",
			nature: "自然标记",
			lakes: "湖泊",
			elevation: "高处动物",
			bonus: "最高动物奖励",
			environment: "环境计分",
			total: "总分",
			draft: "选取地形与动物",
			place: "放置地形与动物",
			resolve: "回合结束",
			waiting: "等待 {{name}}",
			round: "{{n}} / 20",
			pick: "选取",
			mix: "自由搭配 · 1 自然标记",
			wipe: "更换所选动物 · 1 自然标记",
			wipeMode: "更换动物",
			wipe3: "免费更换三只相同动物",
			cancel: "取消",
			rotate: "旋转",
			flip: "调换两端",
			placeTile: "放置板块",
			placeToken: "放置动物",
			skipToken: "放回动物",
			confirmSkip: "确认放回",
			tile: "地形板块",
			token: "野生动物",
			supply: "供应区",
			cards: "计分卡",
			details: "计分详情",
			close: "关闭",
			board: "查看栖息地",
			scores: "查看得分",
			fit: "全景",
			zoomIn: "放大",
			zoomOut: "缩小",
			selectTile: "选择板块落点",
			selectToken: "选择动物落点",
			level: "{{n}} 级",
			cell: "{{habitat}}，{{level}}级，{{animal}}",
			empty: "空置",
			lakeCell: "湖泊",
			placeAt: "在 {{q}}，{{r}} 放置",
			preview: "{{level}} 级 · 确认放置",
			scaffold: "使用自然支撑 · 1 自然标记",
			noToken: "没有可放置此动物的空格",
			result: "高山之旅",
			winner: "{{name}} 获胜",
			sharedWinner: "并列获胜",
			soloResult: "{{n}} 分",
			playAgain: "再来一局",
			lobby: "返回大厅",
			waitHost: "等待主机安排下一局",
			achievements: "徒步成就",
			progress: "已完成 {{n}} / 60",
			eligible: "本局可记录一项成就",
			save: "记录成就",
			saved: "已保存",
			saving: "保存中",
			retry: "保存失败，点击重试",
			noAward: "本局没有新的成就",
			scenario: "情景 {{n}}",
			medal0: "未达成",
			medal1: "铜牌",
			medal2: "银牌",
			medal3: "金牌",
			objectives: "额外目标",
			modifier: "规则修改 {{n}}",
			normal: "普通成就",
			none: "不启用",
			optCards: "地形计分卡",
			optA: "入门 A 卡",
			optRandom: "随机计分卡",
			optCustom: "指定计分卡",
			optFamily: "家庭卡",
			optIntermediate: "中级卡",
			optEnvironment: "环境计分卡",
			optEnvironmentHint: "指定卡优先；其他已选类别随机抽取。P1至P3对应10至12。",
			wildlife: "动物",
			habitat: "地形",
			spatial: "空间",
			randomCount: "随机类别数",
			optPeaks: "Pristine Peaks 扩展",
			standard: "基本湖泊",
			cascading: "阶叠湖泊",
			wildlands: "荒野湖泊",
			optHighest: "最高动物奖励",
			optChallenge: "挑战",
			optChallengeHint: "情景会覆盖地形与环境卡配置，并使用基本湖泊及最高动物奖励。",
			matchExempt: "本回合豁免地形匹配。",
			noTile: "此板块没有合法落点，请选择其他板块。",
			mod1: "地形匹配",
			mod2: "供应短缺",
			mod3: "双重计分",
			mod4: "直上云霄",
			mod5: "自然支撑",
			errTurn: "当前不能行动。",
			errPick: "请重新选择可用的一组板块与动物。",
			errNature: "自然标记不足。",
			errWipe: "当前不能这样更换动物。",
			errTile: "此处不能放置这块板块。",
			errToken: "此处不能放置这只动物。",
			hintPick: "选取第 {{tile}} 块板块和第 {{token}} 只动物。",
			hintTile: "在坐标 {{q}}，{{r}} 放置板块，朝向 {{dir}}。",
			hintToken: "将动物放到坐标 {{q}}，{{r}}。",
			familyText: "每个同地形内相连的同种动物群，1/2/3只及以上获得2/5/9分。",
			intermediateText: "每个同地形内相连的同种动物群，1/2/3/4只及以上获得0/5/8/12分。",
			forestA: "每条森林走廊有1/2/3/4/5种动物，获得2/4/7/11/17分。",
			forestB: "每条森林走廊有1/2/3种及以上动物各至少两只，获得5/12/20分；每个物种只计一对。",
			forestC: "每条森林走廊中，取一个菱形四格或其部分，含1/2/3/4种动物获得2/5/9/13分。每走廊只取一个形状。",
			forestD: "每条森林走廊有1/2/3/4/5种动物，获得2/5/9/14/19分；所计动物中每一级最多两只。",
			forestE: "不同森林走廊内取不同的相邻异种动物配对；每走廊最多一对，每种配对最多一次。1/2/3/4/5/6对及以上获得5/11/18/25/33/42分。",
			forestF: "含至少三种动物且能选出三个不同高度的森林走廊有1/2/3条及以上，获得10/22/34分。",
			meadowA: "每群相连的同种动物有1/2/3/4/5/6只及以上，获得2/5/8/12/17/22分。",
			meadowB: "每条同种动物直线有1/2/3/4/5只及以上，获得2/5/9/14/19分。同种直线可相接，每只动物只能计入一条。",
			meadowC: "将同种动物分成三角三格或其部分，1/2/3只获得2/5/9分，每只动物只能使用一次。",
			meadowD: "每群相连的同种动物必须全部处在不同高度。1/2/3/4只及以上获得2/6/11/17分；出现重复高度的整群不得分。",
			meadowE: "每群相连的同种动物有1/2/3/4/5只及以上，获得2/5/8/12/17分；再按不同群大小的种类数各加1分。",
			meadowF: "每群同种、同高度且至少两只的相连动物，位于1/2/3级及以上分别获得6/7/8分。",
			glacierA: "含相邻同种动物一对的冰川走廊有1/2/3/4/5条及以上，获得5/11/18/25/33分。",
			glacierB: "含至少三种动物的冰川走廊有1/2/3/4条及以上，获得9/19/30/42分。",
			glacierC: "至少有一只动物的冰川走廊有1至9条及以上，获得2/5/8/11/15/19/23/28/33分。",
			glacierD: "含相邻、同种且不同高度动物一对的冰川走廊有1/2/3/4/5条及以上，获得5/12/20/29/38分。",
			glacierE: "每条冰川走廊中，数量最多的动物有1/2/3/4/5只及以上，获得2/5/9/13/18分。",
			glacierF: "至少有一只动物位于二级及以上的冰川走廊有1至7条及以上，获得3/6/10/14/18/22/27分。",
			wildlife1: "数量最多的一个物种，每只动物1分。",
			wildlife2: "每只六边均被地形包围的动物1分。",
			wildlife3: "每个数量不超过三只的物种3分，包括没有动物的物种。",
			wildlife4: "每个恰好四只动物的物种2分。",
			wildlife5: "每个恰好五只动物的物种3分。",
			wildlife6: "每个分布在至少三种不同高度的物种2分。",
			wildlife7: "每条五只动物、五个物种齐全的直线3分；动物不得重复使用。",
			wildlife8: "选择数量最多的三个物种，每凑齐一套这三个物种的动物获得2分。",
			wildlife9: "每条同种动物按一级、二级、三级依次排列的三格直线3分；动物不得重复使用。",
			wildlife10: "数量最少的一个物种，每只动物3分；包括零只。",
			wildlife11: "每个至少七只动物的物种4分。",
			wildlife12: "每个物种数量最多的玩家3分，并列最多各1分；无人拥有的物种不计。",
			habitat1: "每两条地形走廊1分，向下取整。",
			habitat2: "每条至少三格的地形走廊1分。",
			habitat3: "数量最少的地形类型，每格1分。",
			habitat4: "每条同地形按一级、二级、三级依次排列的三格直线3分；格子不得重复使用。",
			habitat5: "每条包含三格直线的地形走廊2分，每走廊只计一次。",
			habitat6: "每条包含三格三角形的地形走廊2分，每走廊只计一次。",
			habitat7: "三种地形各取最高一格，获得高度之和的分数。",
			habitat8: "每种至少有四个动物物种的地形3分。",
			habitat9: "每个在三种地形都有分布的动物物种2分。",
			habitat10: "每种达到四级及以上的地形3分。",
			habitat11: "每条三种不同地形、三个不同高度的三格直线3分；格子不得重复使用。",
			habitat12: "按地形走廊总数排名，第一至第四获得8/4/2/0分；平手均分所占名次的分数，向下取整。",
			spatial1: "每对相邻、同种但处于不同地形的动物1分；动物不得重复使用。",
			spatial2: "每格六边都被动物包围的湖泊2分。",
			spatial3: "每条含三级及以上格子的地形走廊2分。",
			spatial4: "每组三只同种动物组成的折线2分；形状可以旋转或镜像，动物不得重复使用。",
			spatial5: "每格位于外沿、三级及以上的地形1分。",
			spatial6: "除湖泊外没有/1/2/3至4/5格及以上空格，获得5/3/1/−1/−3分。",
			spatial7: "每群相连同种动物跨越三种地形获得3分。",
			spatial8: "最大一群相连的二级地形，每格1分。",
			spatial9: "每格至少比一个相邻地形高两级的地形1分。",
			spatial10: "每格六边都被更高地形包围的地形3分。",
			spatial11: "每群至少三只相连同种动物，且每只都邻接湖泊，获得3分。",
			spatial12: "取最高级的两格之间最远的六角距离，中间每格距离1分；中间可以没有地形。"
		},
		en: {
			selectedTile: "Drafted tile",
			selectedToken: "Drafted wildlife",
			reviewing: "Habitat review",
			standardText: "Each lake scores its elevation, doubled when surrounded by tiles on all six sides.",
			cascadingText: "Each connected lake group scores 1/4/9/15 for 1/2/3/4+ distinct levels. Each non-highest lake must touch a lake exactly one level higher.",
			wildlandsText: "Lakes score no lake points, but accept and support any wildlife.",
			elevationText: "Each animal at level 3+ scores 2. With Reach for the Sky, animals at level 4+ score 4 instead.",
			bonusText: "Compare each species’ descending list of elevations until ties break. Two players: first 2, tied first 1 each. Three or four: first 3, second 1; two tied first 2 each, three or more tied first 1 each, tied second 0. Absent species score zero. Solo: 2 per species with one animal at level 4+ or two at level 3+.",
			a1: "Score at least 80",
			a2: "Score at least 85",
			a3: "Score at least 90",
			a4: "Score at least 95",
			a5: "Score at least 100",
			a6: "Score at least 105",
			a7: "Score at least 110",
			a8: "Finish without Nature Tokens",
			a9: "Have no Pikas",
			a10: "Have no Mountain Goats",
			a11: "Have no Cougars",
			a12: "Have no Marmots",
			a13: "Have no Bald Eagles",
			a14: "Have at least 8 of one species",
			a15: "Have at least 10 of one species",
			a16: "Win at least three highest-wildlife bonuses outright",
			a17: "Score at least 20 from forests",
			a18: "Score at least 20 from meadows",
			a19: "Score at least 20 from glaciers",
			a20: "Score at least 30 from forests",
			a21: "Score at least 30 from meadows",
			a22: "Score at least 30 from glaciers",
			a23: "Score at least 35 from one habitat",
			a24: "Score at least 10 from Environment Cards",
			a25: "Score at least 15 from Environment Cards",
			a26: "Score at least 20 from Environment Cards",
			a27: "Finish with at least 5 Nature Tokens",
			a28: "Finish with at least 10 Nature Tokens",
			a29: "Beat every opponent by at least 10",
			a30: "Beat every opponent by at least 15",
			a31: "Reach level 4",
			a32: "Reach level 5",
			a33: "Score at least 15 from lakes",
			a34: "Score at least 20 from lakes",
			a35: "Have all five species at level 3+",
			goal8: "Reach level 4",
			goal9: "Have at least three of each species",
			goal10: "Score at least 10 from lakes",
			goal11: "Score at least 20 from forests",
			goal12: "Score at least 10 from Environment Cards",
			goal13: "Have at least 5 Nature Tokens",
			goal14: "Score at least 55 from habitats",
			goal15: "Score at least 15 from wildlife elevation and bonuses",
			goal16: "Have exactly four species",
			goal17: "Reach level 5",
			goal18: "Score at least 5 from each Environment Card; no Pika adjacent to an Eagle",
			goal19: "Score at least 18 from each habitat; no Marmot adjacent to a lake",
			goal20: "Score at least 15 from Environment Cards; no Cougar adjacent to a Mountain Goat",
			scoreTarget: "Bronze / Silver / Gold: {{a}} / {{b}} / {{c}} points",
			modifierTarget: "Complete a game with this Rules Modification to record it.",
			localProgress: "Progress is saved on this device.",
			hintsUsed: "Hints used: {{n}}",
			name: "Cascadia: Alpine Lakes",
			desc: "Layer alpine habitats and settle five wildlife species around mountain lakes.",
			rules: "Goal: After 20 turns each, the highest total wins. Ties go to the most unused Nature Tokens, then are shared.\nSetup: Each player starts with a four-hex starter. Display four pairs of double-hex Habitat Tiles and Wildlife Tokens. Use one scoring card per habitat. Advanced games may add up to one Environment Card from each of Wildlife, Habitat and Spatial.\nTurn:\n· Draft a tile and a token. Place them in either order. Finish both before the next turn.\n· Rotate the tile freely. At ground level it must share an edge with your environment. To stack it, both hexagons below must be at the same level. The new tile must also have at least one outside neighbor no more than one level below it.\n· Covered wildlife rises onto the new tile, which must permit that species. Placed wildlife cannot otherwise move or be removed.\n· Place the token on an empty hexagon showing its species, or return the drafted token to the bag. Standard lakes cannot hold wildlife.\n· Placing wildlife on a single-species Keystone hexagon earns a Nature Token. Raising existing wildlife onto a Keystone also earns one. Multiple tokens may be earned in one turn, subject to the finite supply.\n· Spend one Nature Token to draft any tile with any token, or to replace any number of displayed tokens. Replacements may be purchased repeatedly. Spent Nature Tokens return to the supply.\n· Four identical displayed tokens are automatically replaced. Three identical tokens may be replaced for free once per turn. Set replaced tokens aside until all replacements are resolved, then return them to the bag.\n· In multiplayer, refill the original empty slots without sliding the display. In solo play, after drafting, separately discard the remaining tile and token furthest from the stacks, slide the other two away from the stacks, then refill two slots at the near end. Discarded pieces leave the game.\nScoring:\n· Edge-connected hexagons of the same habitat form a corridor, regardless of elevation. Score each habitat using its card; exact requirements and values are available in Card Details.\n· Each standard lake scores its elevation, doubled if all six sides are surrounded by tiles.\n· Each animal at level 3+ scores 2 points. Compare each species’ descending list of animal elevations, continuing until ties break. In two-player games the leader scores 2, or tied leaders 1 each. With three or four players, first scores 3 and second 1; two tied for first score 2 each, three or four tied for first score 1 each; tied second scores 0. Players without the species receive no bonus. Solo: 2 per species with one animal at level 4+ or two at level 3+.\n· Each unused Nature Token scores 1, plus selected Environment Cards. Family and Intermediate cards score connected same-species groups within one habitat. Highest-wildlife bonuses may be disabled for these variants.\nChallenges: Scenarios set the scoring cards and extra goals. Meet every goal and the score threshold for bronze, silver or gold. Choose at most one new Normal Achievement per game. Complete a game with a Rules Modification to record it. Progress is saved for this game on the current device.\nPristine Peaks (off by default): Adds habitat E/F and environment P1–P3 cards. Cascading Lakes score connected lake groups at 1/4/9/15 points for 1/2/3/4+ distinct levels; each non-highest lake must touch a lake exactly one level higher. Wild Lands lakes score no lake points but accept any wildlife.\nRules Modifications: 1. Each new tile must match at least one outside habitat edge at the same or a higher level. A layered tile with no neighbor at that height may use any habitat. Additional ruling: if no supplied tile can be placed legally, habitat matching is waived for that turn; all other placement rules still apply. 2. Display only three pairs. 3. Use two cards per habitat and score the better one at game end. 4. Animals at level 4+ score 4 instead of 2. 5. Once per turn, spend a Nature Token to support the lower half of a tile when the hexagons below differ by one level.",
			forest: "Forest",
			meadow: "Meadow",
			glacier: "Glacier",
			cougar: "Cougar",
			eagle: "Bald Eagle",
			goat: "Mountain Goat",
			marmot: "Marmot",
			pika: "Pika",
			nature: "Nature Tokens",
			lakes: "Lakes",
			elevation: "Elevated wildlife",
			bonus: "Highest wildlife",
			environment: "Environment",
			total: "Total",
			draft: "Draft habitat and wildlife",
			place: "Place habitat and wildlife",
			resolve: "Turn complete",
			waiting: "Waiting for {{name}}",
			round: "{{n}} / 20",
			pick: "Draft",
			mix: "Mix pairs · 1 Nature Token",
			wipe: "Replace selected wildlife · 1 Nature Token",
			wipeMode: "Replace wildlife",
			wipe3: "Replace three matching wildlife for free",
			cancel: "Cancel",
			rotate: "Rotate",
			flip: "Swap ends",
			placeTile: "Place tile",
			placeToken: "Place wildlife",
			skipToken: "Return wildlife",
			confirmSkip: "Confirm return",
			tile: "Habitat Tile",
			token: "Wildlife",
			supply: "Supply",
			cards: "Scoring cards",
			details: "Scoring details",
			close: "Close",
			board: "View habitats",
			scores: "View scores",
			fit: "Fit",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			selectTile: "Choose a tile location",
			selectToken: "Choose a wildlife location",
			level: "Level {{n}}",
			cell: "{{habitat}}, level {{level}}, {{animal}}",
			empty: "Empty",
			lakeCell: "Lake",
			placeAt: "Place at {{q}}, {{r}}",
			preview: "Level {{level}} · Confirm placement",
			scaffold: "Natural support · 1 Nature Token",
			noToken: "No empty hexagon accepts this wildlife",
			result: "Alpine journey",
			winner: "{{name}} wins",
			sharedWinner: "Shared victory",
			soloResult: "{{n}} points",
			playAgain: "Play again",
			lobby: "Back to lobby",
			waitHost: "Waiting for the host",
			achievements: "Hiking achievements",
			progress: "{{n}} / 60 completed",
			eligible: "Record one achievement this game",
			save: "Record achievement",
			saved: "Saved",
			saving: "Saving",
			retry: "Save failed. Retry",
			noAward: "No new achievement this game",
			scenario: "Scenario {{n}}",
			medal0: "Not completed",
			medal1: "Bronze",
			medal2: "Silver",
			medal3: "Gold",
			objectives: "Extra goals",
			modifier: "Rules Modification {{n}}",
			normal: "Normal Achievements",
			none: "Off",
			optCards: "Habitat scoring",
			optA: "Introductory A cards",
			optRandom: "Random cards",
			optCustom: "Choose cards",
			optFamily: "Family card",
			optIntermediate: "Intermediate card",
			optEnvironment: "Environment cards",
			optEnvironmentHint: "Chosen cards take priority; other selected categories are random. P1–P3 are numbered 10–12.",
			wildlife: "Wildlife",
			habitat: "Habitat",
			spatial: "Spatial",
			randomCount: "Random categories",
			optPeaks: "Pristine Peaks expansion",
			standard: "Standard Lakes",
			cascading: "Cascading Lakes",
			wildlands: "Wild Lands",
			optHighest: "Highest-wildlife bonuses",
			optChallenge: "Challenges",
			optChallengeHint: "Scenarios override habitat and environment cards, using Standard Lakes and highest-wildlife bonuses.",
			matchExempt: "Habitat matching is waived this turn.",
			noTile: "This tile has no legal placement. Choose another tile.",
			mod1: "Domino Domains",
			mod2: "Short Supply",
			mod3: "Habitats Aplenty",
			mod4: "Reach for the Sky",
			mod5: "Natural Support",
			errTurn: "You cannot act right now.",
			errPick: "Choose an available tile and wildlife token.",
			errNature: "Not enough Nature Tokens.",
			errWipe: "You cannot replace those wildlife tokens now.",
			errTile: "That tile cannot be placed here.",
			errToken: "That wildlife cannot be placed here.",
			hintPick: "Draft tile {{tile}} and wildlife {{token}}.",
			hintTile: "Place the tile at {{q}}, {{r}}, orientation {{dir}}.",
			hintToken: "Place wildlife at {{q}}, {{r}}.",
			familyText: "Each connected same-species group in one habitat scores 2/5/9 for 1/2/3+ animals.",
			intermediateText: "Each connected same-species group in one habitat scores 0/5/8/12 for 1/2/3/4+ animals.",
			forestA: "Each forest corridor scores 2/4/7/11/17 for 1/2/3/4/5 wildlife species.",
			forestB: "Each forest corridor scores 5/12/20 for 1/2/3+ species with at least two animals each. Count each species only once.",
			forestC: "In each forest corridor, choose one four-hex diamond or part of it. Score 2/5/9/13 for 1/2/3/4 species in that shape.",
			forestD: "Each forest corridor scores 2/5/9/14/19 for 1/2/3/4/5 species, with at most two counted animals at any one level.",
			forestE: "Choose different adjacent pairs of different species in separate forest corridors. At most one pair per corridor, each species pairing once. Score 5/11/18/25/33/42 for 1/2/3/4/5/6+ pairs.",
			forestF: "Score 10/22/34 for 1/2/3+ forest corridors with at least three species that can be selected at three different levels.",
			meadowA: "Each connected same-species group scores 2/5/8/12/17/22 for 1/2/3/4/5/6+ animals.",
			meadowB: "Each same-species straight line scores 2/5/9/14/19 for 1/2/3/4/5+ animals. Lines may touch, but each animal counts once.",
			meadowC: "Divide same-species animals into triads or partial triads. Score 2/5/9 for 1/2/3 animals; each animal counts once.",
			meadowD: "Every animal in a connected same-species group must be at a different level. Score 2/6/11/17 for 1/2/3/4+ animals. A group with a repeated level scores zero.",
			meadowE: "Each connected same-species group scores 2/5/8/12/17 for 1/2/3/4/5+ animals. Add 1 per distinct group size.",
			meadowF: "Each connected group of at least two animals of the same species at the same level scores 6/7/8 at level 1/2/3+.",
			glacierA: "Score 5/11/18/25/33 for 1/2/3/4/5+ glacier corridors containing an adjacent same-species pair.",
			glacierB: "Score 9/19/30/42 for 1/2/3/4+ glacier corridors containing at least three species.",
			glacierC: "Score 2/5/8/11/15/19/23/28/33 for 1–9+ glacier corridors with at least one animal.",
			glacierD: "Score 5/12/20/29/38 for 1/2/3/4/5+ glacier corridors with an adjacent same-species pair at different levels.",
			glacierE: "Each glacier corridor scores 2/5/9/13/18 for 1/2/3/4/5+ animals of its most numerous species.",
			glacierF: "Score 3/6/10/14/18/22/27 for 1–7+ glacier corridors with an animal at level 2+.",
			wildlife1: "1 per animal of your most numerous species.",
			wildlife2: "1 per animal surrounded on all six sides by tiles.",
			wildlife3: "3 per species with three or fewer animals, including absent species.",
			wildlife4: "2 per species with exactly four animals.",
			wildlife5: "3 per species with exactly five animals.",
			wildlife6: "2 per species present at three or more distinct levels.",
			wildlife7: "3 per five-animal straight line with all five species. No animal reuse.",
			wildlife8: "Choose your three most numerous species. Score 2 per complete set of those three species.",
			wildlife9: "3 per same-species straight line at levels 1, 2, 3 in order. No animal reuse.",
			wildlife10: "3 per animal of your least numerous species, including zero.",
			wildlife11: "4 per species with at least seven animals.",
			wildlife12: "3 per species for the player with the most animals; tied leaders score 1 each. Absent species score zero.",
			habitat1: "1 per two habitat corridors, rounded down.",
			habitat2: "1 per corridor with at least three hexagons.",
			habitat3: "1 per hexagon of your least numerous habitat.",
			habitat4: "3 per same-habitat straight line at levels 1, 2, 3 in order. No hexagon reuse.",
			habitat5: "2 per corridor containing a straight line of three, once per corridor.",
			habitat6: "2 per corridor containing a three-hex triad, once per corridor.",
			habitat7: "Sum the highest level reached by each of the three habitats.",
			habitat8: "3 per habitat with at least four species.",
			habitat9: "2 per species present in all three habitats.",
			habitat10: "3 per habitat reaching level 4+.",
			habitat11: "3 per three-hex straight line with three habitats at three distinct levels. No hexagon reuse.",
			habitat12: "Rank total corridor counts for 8/4/2/0 points. Ties share the points of the occupied ranks, rounded down.",
			spatial1: "1 per adjacent same-species pair on different habitats. No animal reuse.",
			spatial2: "2 per lake surrounded on all six sides by animals.",
			spatial3: "2 per corridor with a hexagon at level 3+.",
			spatial4: "2 per three-animal same-species bent line, rotated or mirrored. No animal reuse.",
			spatial5: "1 per outside-edge hexagon at level 3+.",
			spatial6: "Score 5/3/1/−1/−3 for 0/1/2/3–4/5+ empty non-lake hexagons.",
			spatial7: "3 per connected same-species group spanning all three habitats.",
			spatial8: "1 per hexagon in your largest connected level-2 group.",
			spatial9: "1 per hexagon at least two levels above an adjacent tile.",
			spatial10: "3 per hexagon surrounded on all six sides by higher tiles.",
			spatial11: "3 per connected group of at least three same-species animals, each adjacent to a lake.",
			spatial12: "Score the greatest hex distance between two highest-level hexagons, minus one. Intervening spaces may be empty."
		}
	}
};
//#endregion
export { wt as default };
