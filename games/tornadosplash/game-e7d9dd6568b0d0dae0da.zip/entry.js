import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useT as o } from "@bgparty/sdk/i18n";
import { IconEye as s, IconMirror as c } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { SheetView as u } from "@bgparty/sdk/sheet-view";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { useFrame as g, useThree as _ } from "@react-three/fiber";
import * as v from "three";
import { usePrefersReducedMotion as y } from "@bgparty/sdk/fx/use-reduced-motion";
import { ResilientCanvas as b } from "@bgparty/sdk/three/resilient-canvas";
import { GameOverScreen as x } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as S, OptionSection as C, OptionSwitch as w } from "@bgparty/sdk/ui/game-options";
//#region src/games/tornadosplash/boats.ts
function T(e, t, n, r, i) {
	return [
		...Array(e).fill("A"),
		...Array(t).fill("B"),
		...Array(n).fill("C"),
		...Array(r).fill("D"),
		...Array(i).fill("E")
	];
}
var E = [
	{
		id: "ika",
		weight: 1,
		speed: 4,
		turn: 2,
		deck: T(6, 6, 4, 3, 1)
	},
	{
		id: "flyfin",
		weight: 2,
		speed: 2,
		turn: 5,
		deck: T(3, 3, 6, 5, 3)
	},
	{
		id: "shark",
		weight: 3,
		speed: 5,
		turn: 1,
		deck: T(7, 7, 4, 2, 0)
	},
	{
		id: "harisen",
		weight: 4,
		speed: 4,
		turn: 3,
		deck: T(6, 5, 4, 3, 2)
	},
	{
		id: "ashika",
		weight: 5,
		speed: 3,
		turn: 4,
		deck: T(4, 4, 5, 4, 3)
	},
	{
		id: "kame",
		weight: 6,
		speed: 3,
		turn: 4,
		deck: T(4, 5, 5, 4, 2)
	}
], D = T(15, 15, 15, 10, 5), O = {
	A: {
		angle: 15,
		cells: 1,
		cellT: [.35]
	},
	B: {
		angle: 15,
		cells: 1,
		cellT: [.9]
	},
	C: {
		angle: 30,
		cells: 1,
		cellT: [.3]
	},
	D: {
		angle: 45,
		cells: 2,
		cellT: [.35, .8]
	},
	E: {
		angle: 60,
		cells: 3,
		cellT: [
			.25,
			.55,
			.85
		]
	}
};
function ee(e) {
	return e.m * O[e.t].angle * Math.PI / 180 / 100;
}
function k(e, t) {
	let n = ee(e);
	return Math.abs(n) < 1e-9 ? {
		x: e.x + t * Math.cos(e.h),
		y: e.y + t * Math.sin(e.h),
		h: e.h
	} : {
		x: e.x + (Math.sin(e.h + n * t) - Math.sin(e.h)) / n,
		y: e.y - (Math.cos(e.h + n * t) - Math.cos(e.h)) / n,
		h: e.h + n * t
	};
}
var A = (e) => k(e, 100), te = (e, t) => k(e, O[e.t].cellT[t] * 100);
function j(e, t = 8) {
	let n = [];
	for (let r = 0; r <= t; r += 1) {
		let i = k(e, 100 * r / t);
		n.push({
			x: i.x,
			y: i.y
		});
	}
	return n;
}
var ne = {
	short: .85,
	medium: 1,
	long: 1.25
}, re = {
	oval: {
		buoys: [{
			x: -520,
			y: 0
		}, {
			x: 520,
			y: 0
		}],
		halfWidth: 170,
		startNear: {
			x: 0,
			y: 300
		}
	},
	tri: {
		buoys: [
			{
				x: 0,
				y: -430
			},
			{
				x: 580,
				y: 340
			},
			{
				x: -580,
				y: 340
			}
		],
		halfWidth: 160,
		startNear: {
			x: 0,
			y: 340
		}
	},
	diamond: {
		buoys: [
			{
				x: 0,
				y: -440
			},
			{
				x: 540,
				y: 0
			},
			{
				x: 0,
				y: 440
			},
			{
				x: -540,
				y: 0
			}
		],
		halfWidth: 150,
		startNear: {
			x: 270,
			y: 220
		}
	}
};
function ie(e, t) {
	let n = e;
	for (let e = 0; e < t; e += 1) {
		let e = [];
		for (let t = 0; t < n.length; t += 1) {
			let r = n[t], i = n[(t + 1) % n.length];
			e.push({
				x: r.x * .75 + i.x * .25,
				y: r.y * .75 + i.y * .25
			}), e.push({
				x: r.x * .25 + i.x * .75,
				y: r.y * .25 + i.y * .75
			});
		}
		n = e;
	}
	return n;
}
function ae(e, t) {
	let n = [], r = 0;
	for (let t = 0; t < e.length; t += 1) {
		let i = e[t], a = e[(t + 1) % e.length], o = Math.hypot(a.x - i.x, a.y - i.y);
		n.push(o), r += o;
	}
	let i = [], a = [], o = 0, s = 0;
	for (let c = 0; c < t; c += 1) {
		let l = r * c / t;
		for (; s + n[o] < l;) s += n[o], o = (o + 1) % e.length;
		let u = e[o], d = e[(o + 1) % e.length], f = n[o] < 1e-9 ? 0 : (l - s) / n[o];
		i.push({
			x: u.x + (d.x - u.x) * f,
			y: u.y + (d.y - u.y) * f
		}), a.push(l);
	}
	return {
		pts: i,
		cum: a,
		len: r
	};
}
var oe = /* @__PURE__ */ new Map();
function se(e, t = "medium") {
	let n = `${e}:${t}`, r = oe.get(n);
	if (r) return r;
	let i = re[e], a = ne[t], o = i.buoys.map((e) => ({
		x: e.x * a,
		y: e.y * a
	})), s = {
		x: i.startNear.x * a,
		y: i.startNear.y * a
	}, c = o;
	if (o.length === 2) {
		let [e, t] = o, n = 300 * a;
		c = [
			{
				x: e.x,
				y: e.y - n
			},
			{
				x: t.x,
				y: t.y - n
			},
			{
				x: t.x,
				y: t.y + n
			},
			{
				x: e.x,
				y: e.y + n
			}
		];
	}
	let l = ie(c, 4), u = 0;
	for (let e = 0; e < l.length; e += 1) {
		let t = l[e], n = l[(e + 1) % l.length];
		u += t.x * n.y - n.x * t.y;
	}
	u > 0 && (l = [...l].reverse());
	let { pts: d, cum: f, len: p } = ae(l, 720), m = 0, h = Infinity;
	for (let e = 0; e < d.length; e += 1) {
		let t = Math.hypot(d[e].x - s.x, d[e].y - s.y);
		t < h && (h = t, m = e);
	}
	let g = Infinity, _ = Infinity, v = -Infinity, y = -Infinity;
	for (let e of d) g = Math.min(g, e.x), v = Math.max(v, e.x), _ = Math.min(_, e.y), y = Math.max(y, e.y);
	let b = i.halfWidth + 80, x = {
		id: e,
		pts: d,
		cum: f,
		len: p,
		halfWidth: i.halfWidth,
		startS: f[m],
		buoys: o,
		bbox: {
			x: g - b,
			y: _ - b,
			w: v - g + 2 * b,
			h: y - _ + 2 * b
		}
	};
	return oe.set(n, x), x;
}
function ce(e, t) {
	let n = e.pts.length, r = e.pts[(t - 1 + n) % n], i = e.pts[(t + 1) % n], a = Math.hypot(i.x - r.x, i.y - r.y) || 1;
	return {
		tx: (i.x - r.x) / a,
		ty: (i.y - r.y) / a
	};
}
function M(e, t, n, r) {
	let i = e.pts.length, a = e.len / i, o = (Math.round(r / a) % i + i) % i, s = Math.ceil(i / 2), c = 0, l = Infinity;
	for (let r = -s; r <= s; r += 1) {
		let a = ((o + r) % i + i) % i, s = Math.hypot(e.pts[a].x - t, e.pts[a].y - n);
		s < l && (l = s, c = a);
	}
	let u = e.pts[c], { tx: d, ty: f } = ce(e, c), p = (t - u.x) * d + (n - u.y) * f, m = e.cum[c] + p;
	for (; m - r > e.len / 2;) m -= e.len;
	for (; r - m > e.len / 2;) m += e.len;
	let h = (t - u.x) * f - (n - u.y) * d;
	return {
		s: m,
		lat: h
	};
}
function N(e, t) {
	let n = e.pts.length, r = e.len / n, i = (Math.round(t / r) % n + n) % n, a = e.pts[i], { tx: o, ty: s } = ce(e, i);
	return {
		x: a.x,
		y: a.y,
		h: Math.atan2(s, o)
	};
}
function le(e) {
	return e === "retail" ? 35 : 340;
}
function ue(e, t, n) {
	let r = N(e, e.startS - t);
	return {
		x: r.x + Math.sin(r.h) * n,
		y: r.y - Math.cos(r.h) * n,
		h: r.h
	};
}
function P(e, t, n) {
	return t.card < 0 || t.card >= e.length ? n : t.i < 0 ? {
		x: e[t.card].x,
		y: e[t.card].y,
		h: e[t.card].h
	} : te(e[t.card], t.i);
}
function de(e, t) {
	for (let n of j(e)) for (let e of t) if (Math.hypot(n.x - e.x, n.y - e.y) < e.r + 35 / 2) return !0;
	return !1;
}
var fe = [
	0,
	4,
	-4,
	8,
	-8,
	12,
	-12
];
function pe(e, t, n, r) {
	for (let i of fe) {
		let a = {
			t,
			m: n,
			x: e.x,
			y: e.y,
			h: e.h + i * Math.PI / 180
		};
		if (!de(a, r)) return a;
	}
	return null;
}
function me(e, t) {
	let n = /* @__PURE__ */ new Set();
	return t.length === 0 || e.forEach((e, r) => {
		O[e.t].cellT.forEach((i, a) => {
			let o = te(e, a);
			for (let e of t) if (Math.hypot(e.x - o.x, e.y - o.y) < 35 / 2) {
				n.add(`${r}:${a}`);
				break;
			}
		});
	}), n;
}
function F(e, t, n, r) {
	let { card: i, i: a } = t, o = n, s = () => {
		if (i < 0) return i = 0, a = 0, !0;
		let t = O[e[i].t].cells;
		return a + 1 < t ? (a += 1, !0) : i + 1 >= e.length ? !1 : (i += 1, a = 0, !0);
	};
	for (; o > 0 && s();) r.has(`${i}:${a}`) || --o;
	return {
		card: i,
		i: a
	};
}
function I(e, t, n) {
	let r = Math.min(52, 1.5 * e.halfWidth / Math.max(n, 1));
	return (n - 1) / 2 * r - t * r;
}
//#endregion
//#region src/games/tornadosplash/meta.ts
var L = {
	id: "tornadosplash",
	tier: "beta",
	mechanics: ["race", "tile-placement"],
	interactionTags: [],
	nameKey: "games.tornadosplash.name",
	descKey: "games.tornadosplash.desc",
	rulesKey: "games.tornadosplash.rules",
	icon: "🚤",
	iconImg: "games/tornadosplash.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/tornadosplash/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [4, 5],
	playerRange: (e) => e?.mode === "ts2" ? {
		min: 2,
		max: 6
	} : {
		min: 2,
		max: 5
	},
	accent: "#0891b2",
	releasedAt: "2026-10-12",
	search: {
		py: "xuan feng sai ting",
		init: "xfst"
	},
	hotseat: "cover"
}, R = t.enum([
	"A",
	"B",
	"C",
	"D",
	"E"
]), z = t.union([t.literal(1), t.literal(-1)]), B = t.string(), he = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("selectBoat"),
		boat: t.int().min(0).max(5)
	}),
	t.object({ type: t.literal("ackBidResult") }),
	t.object({
		type: t.literal("bid"),
		discard: t.array(R).max(5)
	}),
	t.object({
		type: t.literal("move"),
		cards: t.array(t.object({
			t: R,
			m: z
		})).max(4),
		boost: t.boolean().optional()
	}),
	t.object({ type: t.literal("rest") }),
	t.object({ type: t.literal("relief") })
]), V = t.object({
	mode: t.enum(["retail", "ts2"]).default("retail"),
	track: t.enum([
		"oval",
		"tri",
		"diamond"
	]).default("oval"),
	courseLength: t.enum([
		"short",
		"medium",
		"long"
	]).default("medium"),
	grandPrix: t.boolean().default(!1)
}).default({
	mode: "retail",
	track: "oval",
	courseLength: "medium",
	grandPrix: !1
}), ge = t.object({
	x: t.number(),
	y: t.number(),
	h: t.number()
}), _e = t.object({
	t: R,
	m: z,
	x: t.number(),
	y: t.number(),
	h: t.number()
}), ve = t.object({
	mode: t.enum(["retail", "ts2"]),
	track: t.enum([
		"oval",
		"tri",
		"diamond"
	]),
	courseLength: t.enum([
		"short",
		"medium",
		"long"
	]),
	phase: t.enum([
		"choose",
		"standby",
		"start",
		"race",
		"done"
	]),
	race: t.int().min(1),
	racesTotal: t.int().min(1),
	turn: B.nullable(),
	order: t.array(B),
	players: t.array(t.object({
		rid: B,
		boat: t.int(),
		lane: t.int(),
		trail: t.array(_e),
		cell: t.object({
			card: t.int(),
			i: t.int()
		}),
		ghost: ge,
		progress: t.number(),
		lat: t.number(),
		lapTarget: t.number(),
		out: t.boolean(),
		finished: t.int(),
		boostUsed: t.boolean(),
		handCount: t.int().nonnegative(),
		deckCount: t.int().nonnegative()
	})),
	standby: t.object({
		declarer: B,
		bids: t.record(B, t.int().nonnegative())
	}).nullable(),
	laneResult: t.object({
		race: t.int().min(1),
		bids: t.record(B, t.int().nonnegative()),
		seen: t.array(B)
	}).nullable(),
	relieved: t.boolean(),
	deckCount: t.int().nonnegative(),
	points: t.record(B, t.int())
}), ye = t.object({ hand: t.array(R) }), H = 6, be = 4, xe = 6, Se = 5, U = (e) => ({ code: e });
function W(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; --t) {
		let a = e(n, r, t + 1);
		r += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return [i, r];
}
function G(e, t) {
	return e.ps.find((e) => e.rid === t);
}
function Ce(e) {
	return se(e.trackId, e.courseLength);
}
function K(e) {
	return P(e.trail, e.cell, e.ghost);
}
function q(e) {
	return e.trail.length > 0 ? A(e.trail[e.trail.length - 1]) : e.ghost;
}
function J(e, t) {
	let n = Ce(e);
	return [...e.ps.filter((e) => e.rid !== t.rid && !e.out).map((e) => ({
		...K(e),
		r: 24
	})), ...n.buoys.map((e) => ({
		...e,
		r: 26
	}))];
}
function Y(e, t) {
	return e.ps.filter((e) => e.rid !== t.rid).flatMap((e) => e.trail.flatMap((e) => j(e)));
}
function X(e) {
	return e.reduce((e, t) => e + O[t].cells, 0);
}
function Z(e) {
	return [...e.ps.filter((e) => !e.finished && !e.out)].sort((t, n) => n.progress === t.progress ? e.mode === "retail" ? E[t.boat].weight - E[n.boat].weight : n.lat - t.lat || t.lane - n.lane : n.progress - t.progress);
}
function we(e) {
	return [...e.ps].sort((e, t) => (e.out ? 1e3 - e.outSeq : e.finished > 0 ? e.finished : 500 - e.progress / 1e6) - (t.out ? 1e3 - t.outSeq : t.finished > 0 ? t.finished : 500 - t.progress / 1e6));
}
function Te(e, t) {
	let n = [];
	for (let r of e.ps) {
		if (t && r.rid !== t) continue;
		let e = Math.max(0, Math.min(r.cell.card, r.trail.length));
		e <= 0 || (n.push(...r.trail.splice(0, e).map((e) => e.t)), r.cell = {
			card: r.cell.card - e,
			i: r.cell.i
		});
	}
	return n;
}
function Ee(e, t) {
	let n = Math.min(3, H - t.hand.length);
	for (; n > 0;) {
		if (e.deck.length === 0) {
			let [t, n] = W(Te(e), e.seed, e.rngCursor);
			if (e.rngCursor = n, e.deck = t, e.deck.length === 0) return;
		}
		t.hand.push(e.deck.shift()), --n;
	}
}
function De(e) {
	let t = Z(e);
	t.forEach((e, n) => {
		let r = n === 0 ? be : n === t.length - 1 ? xe : Se;
		for (; e.hand.length < r;) {
			if (e.deck.length === 0) {
				if (e.cell.card < 1) return;
				let [t] = e.trail.splice(0, 1);
				e.cell = {
					card: e.cell.card - 1,
					i: e.cell.i
				}, e.deck.push(t.t);
			}
			e.hand.push(e.deck.shift());
		}
	});
}
function Oe(e) {
	let t = Ce(e), n = e.ps.length, r = le(e.mode);
	for (let i of e.ps) {
		i.ghost = ue(t, r, I(t, i.lane, n));
		let e = M(t, i.ghost.x, i.ghost.y, t.startS - r);
		i.progress = e.s, i.lat = e.lat, i.lapTarget = t.startS + t.len;
	}
}
function ke(e) {
	let t = e.mode === "ts2" && e.race === 2;
	for (let t of e.ps) t.trail = [], t.cell = {
		card: -1,
		i: -1
	}, t.out = !1, t.outSeq = 0, t.finished = 0, t.hand = [];
	e.finishCounter = 0, e.outCounter = 0, e.anyMoved = !0, e.relieved = !1, e.turnIdx = 0, e.laneResult = null;
	let n = e.rngCursor;
	if (e.mode === "ts2") {
		let r;
		[r, n] = W(D, e.seed, n);
		for (let t of e.ps) t.hand = r.splice(0, H);
		e.deck = r, t && we(e).forEach((e, t) => {
			e.lane = t;
		}), Oe(e), e.standby = {
			order: [...e.ps].sort((e, t) => t.lane - e.lane).map((e) => e.rid),
			idx: 0,
			bids: {}
		}, e.phase = "standby", e.order = [];
	} else {
		for (let t of e.ps) {
			let r;
			[r, n] = W(E[t.boat].deck, e.seed, n), t.hand = r.splice(0, H), t.deck = r;
		}
		e.deck = [], Oe(e), e.standby = null, e.phase = "race", e.order = Z(e).map((e) => e.rid), De(e);
	}
	e.rngCursor = n;
}
function Ae(e) {
	for (let t of Z(e)) t.finished = ++e.finishCounter;
	if (e.mode === "retail") {
		let t = we(e).filter((e) => !e.out), n = t.length < e.ps.length;
		if (t.forEach((r, i) => {
			let a = n ? [
				5,
				3,
				2
			][i] ?? 0 : i === t.length - 1 ? 0 : [
				5,
				3,
				2
			][i] ?? 0;
			e.points[r.rid] = (e.points[r.rid] ?? 0) + a;
		}), e.grandPrix && e.race < e.racesTotal) {
			e.race += 1, ke(e);
			return;
		}
		e.phase = "done";
		return;
	}
	if (e.race === 1) {
		e.race = 2, ke(e);
		return;
	}
	e.phase = "done";
}
function je(e) {
	for (e.turnIdx += 1, e.relieved = !1; e.turnIdx < e.order.length;) {
		let t = G(e, e.order[e.turnIdx]);
		if (t && !t.finished && !t.out) break;
		e.turnIdx += 1;
	}
	if (e.turnIdx < e.order.length) return;
	if (e.phase === "start") {
		e.phase = "race", e.order = Z(e).map((e) => e.rid), e.turnIdx = 0, e.anyMoved = !0;
		return;
	}
	let t = Z(e);
	if (t.length <= 1 || !e.anyMoved) {
		Ae(e);
		return;
	}
	e.anyMoved = !1, e.turnIdx = 0, e.mode === "retail" ? (e.order = t.map((e) => e.rid), De(e)) : e.order = t.map((e) => e.rid);
}
function Me(e, t, n, r) {
	let i = [...t.hand], a = J(e, t), o = (e, t, s) => {
		if (t === n) return !0;
		if (t > n || s >= 3) return !1;
		let c = /* @__PURE__ */ new Set();
		for (let n = 0; n < i.length; n += 1) {
			let l = i[n];
			if (!(r && l !== "A" && l !== "B") && !c.has(l)) {
				c.add(l);
				for (let r of [1, -1]) {
					let c = pe(e, l, r, a);
					if (!c) continue;
					i.splice(n, 1);
					let u = o(A(c), t + O[l].cells, s + 1);
					if (i.splice(n, 0, l), u) return !0;
				}
			}
		}
		return !1;
	};
	return o(q(t), 0, 0);
}
function Ne(t, n, r) {
	let i = t.mode, a = {
		mode: i,
		trackId: t.track,
		courseLength: t.courseLength,
		players: n,
		ps: n.map((e, t) => ({
			rid: e,
			boat: i === "retail" ? -1 : t % E.length,
			lane: t,
			trail: [],
			cell: {
				card: -1,
				i: -1
			},
			ghost: {
				x: 0,
				y: 0,
				h: 0
			},
			progress: 0,
			lat: 0,
			lapTarget: 0,
			hand: [],
			deck: [],
			boostUsed: !1,
			out: !1,
			outSeq: 0,
			finished: 0
		})),
		deck: [],
		phase: i === "retail" ? "choose" : "standby",
		race: 1,
		racesTotal: i === "retail" && t.grandPrix ? 3 : i === "ts2" ? 2 : 1,
		grandPrix: i === "retail" && t.grandPrix,
		points: {},
		order: i === "retail" ? [...n] : [],
		turnIdx: 0,
		standby: null,
		laneResult: null,
		relieved: !1,
		finishCounter: 0,
		outCounter: 0,
		anyMoved: !0,
		seed: r,
		rngCursor: 0
	}, o = 0;
	if (i === "ts2") {
		let t = n.map((e, t) => t);
		for (let n = t.length - 1; n > 0; --n) {
			let i = e(r, o, n + 1);
			o += 1, [t[n], t[i]] = [t[i], t[n]];
		}
		a.ps.forEach((e, n) => {
			e.lane = t[n];
		});
	}
	return a.rngCursor = o, i === "ts2" && ke(a), { state: a };
}
function Pe(e, t, n, r) {
	let i = e.phase === "start", a = X(n.map((e) => e.t)), o = [...t.hand];
	for (let e of n) {
		let t = o.indexOf(e.t);
		if (t < 0) return U("games.tornadosplash.err.cardsNotInHand");
		o.splice(t, 1);
	}
	if (r && (e.mode !== "retail" || t.boostUsed)) return U("games.tornadosplash.err.boostUsed");
	let s = r ? 4 : 3;
	if (n.length === 0) {
		if (e.mode === "ts2" && Me(e, t, 3, i)) return U("games.tornadosplash.err.noRest");
	} else {
		if (i) {
			if (n.some((e) => e.t !== "A" && e.t !== "B")) return U("games.tornadosplash.err.straightOnly");
			if (a !== 3) return U("games.tornadosplash.err.mustThree");
		} else if (e.mode === "ts2") {
			if (a !== 3) return U("games.tornadosplash.err.mustThree");
		} else if (a > s) return U("games.tornadosplash.err.tooMany");
		let o = q(t), c = J(e, t), l = [];
		for (let e of n) {
			let t = pe(o, e.t, e.m, c);
			if (!t) return U("games.tornadosplash.err.blocked");
			l.push(t), o = A(t);
		}
		t.trail.push(...l);
		for (let e of n) t.hand.splice(t.hand.indexOf(e.t), 1);
		t.cell = F(t.trail, t.cell, a, me(t.trail, Y(e, t)));
		let u = Ce(e), d = K(t), f = M(u, d.x, d.y, t.progress);
		if (t.progress = f.s, t.lat = f.lat, r && (t.boostUsed = !0), a > 0 && (e.anyMoved = !0), !t.finished && t.progress >= t.lapTarget && (t.finished = ++e.finishCounter, e.mode === "ts2" && e.race === 2)) return e.phase = "done", null;
		e.mode === "retail" && Math.abs(t.lat) > u.halfWidth && !t.out && (t.out = !0, t.outSeq = ++e.outCounter);
	}
	return e.mode === "ts2" && Ee(e, t), je(e), null;
}
function Fe(e, t, n) {
	if (e.phase === "done") return U("games.tornadosplash.err.badPhase");
	if (t.type === "selectBoat") return e.mode !== "retail" || e.phase !== "choose" ? U("games.tornadosplash.err.badPhase") : e.order[e.turnIdx] === n.by ? e.ps.some((e) => e.boat === t.boat) ? U("games.tornadosplash.err.boatTaken") : (G(e, n.by).boat = t.boat, e.turnIdx += 1, e.turnIdx === e.ps.length && ([...e.ps].sort((e, t) => E[t.boat].weight - E[e.boat].weight).forEach((e, t) => {
		e.lane = t;
	}), ke(e)), { state: e }) : U("games.tornadosplash.err.notTurn");
	if (t.type === "ackBidResult") return e.mode !== "ts2" || !e.laneResult || !e.players.includes(n.by) ? U("games.tornadosplash.err.badPhase") : (e.laneResult.seen.includes(n.by) || e.laneResult.seen.push(n.by), { state: e });
	if (t.type === "bid") {
		if (e.phase !== "standby" || !e.standby) return U("games.tornadosplash.err.badPhase");
		let r = e.standby;
		if (r.order[r.idx] !== n.by) return U("games.tornadosplash.err.notTurn");
		let i = G(e, n.by), a = [...i.hand];
		for (let e of t.discard) {
			let t = a.indexOf(e);
			if (t < 0) return U("games.tornadosplash.err.cardsNotInHand");
			a.splice(t, 1);
		}
		if (X(a) < 3) return U("games.tornadosplash.err.bidCells");
		for (let e of t.discard) i.hand.splice(i.hand.indexOf(e), 1);
		return e.deck.push(...t.discard), r.bids[n.by] = t.discard.length, r.idx += 1, r.idx >= r.order.length && ([...e.ps].sort((e, t) => (r.bids[t.rid] ?? 0) - (r.bids[e.rid] ?? 0) || e.lane - t.lane).forEach((e, t) => {
			e.lane = t;
		}), Oe(e), e.laneResult = {
			race: e.race,
			bids: { ...r.bids },
			seen: []
		}, e.standby = null, e.phase = "start", e.order = [...e.ps].sort((e, t) => e.lane - t.lane).map((e) => e.rid), e.turnIdx = 0), { state: e };
	}
	if (e.phase !== "race" && e.phase !== "start") return U("games.tornadosplash.err.badPhase");
	if (e.order[e.turnIdx] !== n.by) return U("games.tornadosplash.err.notTurn");
	let r = G(e, n.by);
	if (r.finished || r.out) return U("games.tornadosplash.err.badPhase");
	if (t.type === "relief") {
		if (e.mode !== "ts2" || e.relieved) return U("games.tornadosplash.err.badPhase");
		if (r.hand.filter((e) => e === "E").length < 2) return U("games.tornadosplash.err.reliefNoE");
		if (e.deck.length === 0) {
			let [t, n] = W(Te(e), e.seed, e.rngCursor);
			if (e.rngCursor = n, e.deck = t, e.deck.length === 0) return U("games.tornadosplash.err.deckEmpty");
		}
		return r.hand.splice(r.hand.indexOf("E"), 1), r.hand.splice(r.hand.indexOf("E"), 1), e.deck.push("E", "E"), r.hand.push(e.deck.shift()), e.relieved = !0, { state: e };
	}
	return t.type === "rest" ? Pe(e, r, [], !1) ?? { state: e } : Pe(e, r, t.cards, t.boost ?? !1) ?? { state: e };
}
function Ie(e, t) {
	return {
		public: {
			mode: e.mode,
			track: e.trackId,
			courseLength: e.courseLength,
			phase: e.phase,
			race: e.race,
			racesTotal: e.racesTotal,
			turn: e.phase === "standby" ? e.standby?.order[e.standby.idx] ?? null : e.order[e.turnIdx] ?? null,
			order: e.order,
			players: e.ps.map((e) => ({
				rid: e.rid,
				boat: e.boat,
				lane: e.lane,
				trail: e.trail,
				cell: e.cell,
				ghost: e.ghost,
				progress: e.progress,
				lat: e.lat,
				lapTarget: e.lapTarget,
				out: e.out,
				finished: e.finished,
				boostUsed: e.boostUsed,
				handCount: e.hand.length,
				deckCount: e.deck.length
			})),
			standby: e.standby ? {
				declarer: e.standby.order[e.standby.idx] ?? "",
				bids: e.standby.bids
			} : null,
			laneResult: e.laneResult,
			relieved: e.relieved,
			deckCount: e.deck.length,
			points: e.points
		},
		private: { hand: G(e, t)?.hand ?? [] }
	};
}
function Le(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = we(e);
	if (e.mode === "retail" && e.grandPrix) {
		let n = [...e.ps].sort((n, r) => (e.points[r.rid] ?? 0) - (e.points[n.rid] ?? 0) || t.indexOf(n) - t.indexOf(r)), r = e.points[n[0].rid] ?? 0, i = n.filter((t) => (e.points[t.rid] ?? 0) === r).map((e) => e.rid), a = {};
		for (let t of e.ps) a[t.rid] = e.points[t.rid] ?? 0;
		return {
			phase: "done",
			winner: i,
			ranking: n.map((e) => e.rid),
			scores: a
		};
	}
	let n = t.map((e) => e.rid);
	return {
		phase: "done",
		winner: n.slice(0, 1),
		ranking: n
	};
}
var Re = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: he,
		publicView: ve,
		privateView: ye,
		config: V
	},
	setup: (e, t, n) => Ne(V.parse(e), t, n),
	reduce: Fe,
	viewFor: Ie,
	status: Le
}, ze = [
	"M3 59 31 38 97 35 125 42 139 56 114 68 29 66Z M105 39 107 22 129 21 132 43Z M119 62 140 62 135 73 120 70Z",
	"M6 58 Q38 48 131 54 L119 65 Q47 72 6 58Z M30 53 53 29 102 48Z M107 50 121 18 132 53Z",
	"M3 59 26 35 116 37 134 54 110 67 30 64Z M62 38 78 5 91 38Z M122 51 145 35 137 56 145 71 119 62Z",
	"M74 31 C110 31 140 41 140 53 C140 66 111 75 74 75 C37 75 8 66 8 53 C8 41 38 31 74 31Z M37 35 43 23 50 34Z M66 31 73 16 80 31Z M99 34 108 23 111 39Z",
	"M7 59 Q18 41 38 38 L102 37 Q127 41 139 59 Q80 75 7 59Z M49 38 Q54 11 75 16 Q90 20 91 40Z M23 63 48 68 21 75Z M108 66 137 73 123 60Z",
	"M5 59 Q22 43 50 43 H109 Q132 44 143 59 Q82 78 5 59Z M30 48 Q39 12 74 15 Q109 12 124 49Z M18 64 Q73 78 134 64 L128 72 Q72 82 22 72Z"
], Be = [
	"M13 57 43 43 64 42 M119 62 132 62",
	"M27 57 60 45 109 56 M42 50 59 37 85 48",
	"M7 57 34 43 57 42 M26 60 39 56 51 61 62 56 73 61",
	"M46 65 Q75 72 103 65 M22 47 13 44 M126 47 136 44",
	"M17 58 Q63 49 126 59 M26 67 Q38 72 50 67 M104 67 Q118 71 131 65",
	"M50 34 75 24 100 34 M41 43 75 31 112 43 M20 69 Q75 80 132 69"
];
function Ve({ boat: e, color: t, className: n }) {
	return /* @__PURE__ */ h("svg", {
		className: n,
		viewBox: "0 0 150 82",
		role: "img",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M18 74 Q75 80 137 73",
				fill: "none",
				stroke: "#d6ffff",
				strokeWidth: "5",
				opacity: ".72"
			}),
			/* @__PURE__ */ m("path", {
				d: ze[e] ?? ze[0],
				fill: t,
				stroke: "#114356",
				strokeWidth: "3",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("path", {
				d: Be[e] ?? Be[0],
				fill: "none",
				stroke: "#ffe2c6",
				strokeWidth: "3",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "75",
				cy: "49",
				rx: "16",
				ry: "7",
				fill: "#153f52",
				stroke: "#c8f6f0",
				strokeWidth: "2"
			})
		]
	});
}
//#endregion
//#region src/games/tornadosplash/scene3d.tsx
var Q = .066, He = 60, Ue = "#07869b", We = .34, Ge = .12, Ke = .045;
function qe(e, t) {
	return Math.atan2(Math.sin(t - e), Math.cos(t - e));
}
function Je(e, t, n) {
	return {
		x: e.x + (t.x - e.x) * n,
		y: e.y + (t.y - e.y) * n,
		h: e.h + qe(e.h, t.h) * n
	};
}
function Ye(e, t, n) {
	let r = [];
	n.forEach((e, t) => {
		for (let n = t === 0 ? 0 : 1; n <= 20; n += 1) r.push(k(e, 100 * n / 20));
	});
	let i = (e, t) => Math.hypot(t.x - e.x, t.y - e.y) + 12 * Math.abs(qe(e.h, t.h)), a = (e) => r.reduce((t, n, a) => i(e, n) < i(e, r[t]) ? a : t, 0);
	if (r.length > 1) {
		let n = a(e), i = a(t);
		if (i > n && Math.hypot(r[n].x - e.x, r[n].y - e.y) < 52.5 && Math.hypot(r[i].x - t.x, r[i].y - t.y) < 52.5) return [
			e,
			...r.slice(n + 1, i),
			t
		];
	}
	let o = Math.hypot(t.x - e.x, t.y - e.y), s = Math.min(o * .34, 100), c = {
		x: e.x + Math.cos(e.h) * s,
		y: e.y + Math.sin(e.h) * s
	}, l = {
		x: t.x - Math.cos(t.h) * s,
		y: t.y - Math.sin(t.h) * s
	}, u = [e];
	for (let n = 1; n < 16; n += 1) {
		let r = n / 16, i = 1 - r, a = i ** 3 * e.x + 3 * i ** 2 * r * c.x + 3 * i * r ** 2 * l.x + r ** 3 * t.x, o = i ** 3 * e.y + 3 * i ** 2 * r * c.y + 3 * i * r ** 2 * l.y + r ** 3 * t.y, s = 3 * i ** 2 * (c.x - e.x) + 6 * i * r * (l.x - c.x) + 3 * r ** 2 * (t.x - l.x), d = 3 * i ** 2 * (c.y - e.y) + 6 * i * r * (l.y - c.y) + 3 * r ** 2 * (t.y - l.y);
		u.push({
			x: a,
			y: o,
			h: Math.atan2(d, s)
		});
	}
	return u.push(t), u;
}
function Xe(e) {
	let t = [0];
	for (let n = 1; n < e.length; n += 1) t.push(t[n - 1] + Math.hypot(e[n].x - e[n - 1].x, e[n].y - e[n - 1].y));
	return {
		lengths: t,
		total: t[t.length - 1]
	};
}
function Ze(e, t) {
	let n = e.total * t, r = e.lengths.findIndex((e) => e >= n);
	if (r <= 0) return e.route[0];
	let i = r - 1, a = e.lengths[r] - e.lengths[i];
	return Je(e.route[i], e.route[r], a > 0 ? (n - e.lengths[i]) / a : 1);
}
function Qe() {
	try {
		let e = document.createElement("canvas");
		return !!(e.getContext("webgl2") ?? e.getContext("webgl"));
	} catch {
		return !1;
	}
}
function $(e, t, n) {
	let r = .42 * Math.sin(t * .38 + n * .62 + .32 * Math.sin(e * .17)), i = .29 * Math.sin(e * .42 - t * .23 + n * .53), a = .16 * Math.sin(t * .83 + e * .31 - n * .88), o = .09 * Math.sin(e * 1.36 - t * .93 + n * 1.12), s = .3 * Math.sin(t * .12 - e * .08 + n * .24);
	return r + i + a + o + s;
}
var $e = "\n  uniform float uTime;\n  varying float vHeight;\n  varying vec3 vNormal;\n  varying vec3 vWorld;\n  float wave(vec2 p, float t) {\n    float a = .42 * sin(p.y * .38 + t * .62 + .32 * sin(p.x * .17));\n    float b = .29 * sin(p.x * .42 - p.y * .23 + t * .53);\n    float c = .16 * sin(p.y * .83 + p.x * .31 - t * .88);\n    float d = .09 * sin(p.x * 1.36 - p.y * .93 + t * 1.12);\n    float swell = .30 * sin(p.y * .12 - p.x * .08 + t * .24);\n    return a + b + c + d + swell;\n  }\n  void main() {\n    vec2 p = position.xz;\n    float h = wave(p, uTime);\n    float e = .14;\n    float dx = wave(p + vec2(e, 0.), uTime) - wave(p - vec2(e, 0.), uTime);\n    float dz = wave(p + vec2(0., e), uTime) - wave(p - vec2(0., e), uTime);\n    vNormal = normalize(vec3(-dx, 2. * e, -dz));\n    vHeight = h;\n    vec4 world = modelMatrix * vec4(position.x, h, position.z, 1.);\n    vWorld = world.xyz;\n    gl_Position = projectionMatrix * viewMatrix * world;\n  }\n", et = "\n  varying float vHeight;\n  varying vec3 vNormal;\n  varying vec3 vWorld;\n  void main() {\n    vec3 n = normalize(vNormal);\n    vec3 viewDir = normalize(cameraPosition - vWorld);\n    vec3 lightDir = normalize(vec3(-.36, .8, -.48));\n    float lit = .56 + .44 * max(dot(n, lightDir), 0.);\n    float fresnel = pow(1. - max(dot(n, viewDir), 0.), 3.);\n    vec3 deep = vec3(.001, .12, .22);\n    vec3 bright = vec3(.008, .35, .44);\n    vec3 color = mix(deep, bright, clamp(.18 + vHeight * .10 + lit * .54, 0., 1.));\n    color = mix(color, vec3(.035, .46, .50), fresnel * .28);\n    float softCrest = smoothstep(.52, 1.10, vHeight) * (1. - n.y);\n    color = mix(color, vec3(.11, .52, .55), softCrest * .18);\n    float distanceFog = smoothstep(43., 78., -vWorld.z);\n    color = mix(color, vec3(.23, .57, .64), distanceFog * .65);\n    gl_FragColor = vec4(color, 1.);\n    #include <tonemapping_fragment>\n    #include <colorspace_fragment>\n  }\n";
function tt() {
	let e = /* @__PURE__ */ new Float32Array(75063), t = [];
	for (let t = 0; t <= 190; t += 1) for (let n = 0; n <= 130; n += 1) {
		let r = (t * 131 + n) * 3, i = 2 * n / 130 - 1, a = 2 * t / 190 - 1;
		e[r] = 35 * i + 65 * i * i * i, e[r + 1] = 0, e[r + 2] = -20 + 52.5 * a + 42.5 * a * a * a;
	}
	for (let e = 0; e < 190; e += 1) for (let n = 0; n < 130; n += 1) {
		let r = e * 131 + n, i = r + 1, a = r + 130 + 1, o = a + 1;
		t.push(r, a, i, i, a, o);
	}
	let n = new v.BufferGeometry();
	return n.setAttribute("position", new v.BufferAttribute(e, 3)), n.setIndex(t), n;
}
function nt({ reducedMotion: e }) {
	let t = r(() => tt(), []), a = i(null);
	return g(({ clock: t }) => {
		a.current && (a.current.uniforms.uTime.value = e ? 0 : t.getElapsedTime());
	}), n(() => () => t.dispose(), [t]), /* @__PURE__ */ m("mesh", {
		geometry: t,
		frustumCulled: !1,
		children: /* @__PURE__ */ m("shaderMaterial", {
			ref: a,
			uniforms: { uTime: { value: 0 } },
			vertexShader: $e,
			fragmentShader: et,
			side: v.DoubleSide
		})
	});
}
function rt({ active: e, mode: t, pub: r, preview: i, resetToken: a }) {
	let o = _((e) => e.invalidate);
	return n(() => {
		o();
	}, [
		o,
		t,
		r,
		i,
		a
	]), n(() => {
		if (!e) return;
		let t = 0, n = 0, r = (e) => {
			document.visibilityState === "visible" && e - n >= 50 && (o(), n = e), t = requestAnimationFrame(r);
		};
		return t = requestAnimationFrame(r), () => cancelAnimationFrame(t);
	}, [e, o]), null;
}
function it({ pub: e, motions: t, reducedMotion: r }) {
	let a = _((e) => e.invalidate), o = i(`${e.track}:${e.courseLength}:${e.race}`), s = i(e.phase);
	return n(() => {
		let n = `${e.track}:${e.courseLength}:${e.race}`, i = n !== o.current || s.current === "standby" && e.phase === "start";
		o.current = n, s.current = e.phase;
		let c = /* @__PURE__ */ new Set();
		for (let n of e.players) {
			c.add(n.rid);
			let e = P(n.trail, n.cell, n.ghost), a = t.current.get(n.rid);
			if (!a || i || r) {
				t.current.set(n.rid, {
					current: e,
					target: e,
					route: [e],
					lengths: [0],
					total: 0,
					elapsed: 0,
					duration: 0,
					active: !1,
					energy: 0,
					bank: 0,
					out: n.out,
					targetOut: n.out,
					boostUsed: n.boostUsed,
					boosted: !1
				});
				continue;
			}
			if (Math.hypot(e.x - a.target.x, e.y - a.target.y) > .1 || Math.abs(qe(a.target.h, e.h)) > .005) {
				let t = Ye(a.current, e, n.trail), { lengths: r, total: i } = Xe(t);
				a.target = e, a.route = t, a.lengths = r, a.total = i, a.elapsed = 0, a.duration = Math.min(1.3, Math.max(.5, i / 340 + .28)), a.active = !0, a.targetOut = n.out, a.boosted = n.boostUsed && !a.boostUsed;
			} else a.active || (a.out = n.out, a.targetOut = n.out);
			a.boostUsed = n.boostUsed;
		}
		for (let e of t.current.keys()) c.has(e) || t.current.delete(e);
		a();
	}, [
		e.players,
		e.track,
		e.courseLength,
		e.race,
		e.phase,
		t,
		r,
		a
	]), g((e, n) => {
		let r = !1;
		for (let e of t.current.values()) {
			if (!e.active) continue;
			e.elapsed += Math.min(n, .08);
			let t = Math.min(1, e.elapsed / e.duration), i = t * t * (3 - 2 * t), a = e.current.h;
			e.current = Ze(e, i), e.energy = Math.sin(Math.PI * t) * (e.boosted ? 1.3 : 1);
			let o = qe(a, e.current.h) / Math.max(n, .016);
			e.bank += (Math.max(-.28, Math.min(.28, o * .2)) - e.bank) * .25, t >= 1 ? (e.current = e.target, e.active = !1, e.energy = 0, e.bank = 0, e.out = e.targetOut) : r = !0;
		}
		r && a();
	}, -1), null;
}
function at({ mode: e, pose: t, focusRid: n, motions: r, track: a, orbit: o, reducedMotion: s }) {
	let c = _((e) => e.size), l = i(new v.Vector3()), u = i(!1);
	return g(({ camera: i }, d) => {
		let f = new v.Vector3(), p = new v.Vector3();
		if (e === "follow") {
			let e = r.current.get(n), i = e?.current ?? t, a = i.x * Q, c = i.y * Q, l = Math.cos(i.h), u = Math.sin(i.h), d = i.h + Math.PI + o.current.azimuth, m = Math.max(.2, Math.min(1.35, .58 + o.current.elevation)), h = (18 - (s ? 0 : (e?.energy ?? 0) * .9)) * o.current.zoom;
			p.set(a + l * 6, .8, c + u * 6), f.set(p.x + Math.cos(d) * h * Math.cos(m), p.y + h * Math.sin(m), p.z + Math.sin(d) * h * Math.cos(m));
		} else {
			let e = (a.bbox.x + a.bbox.w / 2) * Q, t = (a.bbox.y + a.bbox.h / 2) * Q, n = Math.max(.45, c.width / Math.max(1, c.height)), r = Math.max(a.bbox.h * Q + 5, (a.bbox.w * Q + 5) / n), i = Math.max(18, r / (2 * Math.tan(He * Math.PI / 360)) * 1.05) * o.current.zoom, s = Math.PI / 2 + o.current.azimuth, l = Math.max(.2, Math.min(1.35, 1.15 + o.current.elevation));
			p.set(e, .2, t), f.set(e + Math.cos(s) * i * Math.cos(l), p.y + i * Math.sin(l), t + Math.sin(s) * i * Math.cos(l));
		}
		if (!u.current || s) i.position.copy(f), l.current.copy(p), u.current = !0;
		else {
			let e = 1 - Math.exp(-d * 5.5);
			i.position.lerp(f, e), l.current.lerp(p, e);
		}
		i.lookAt(l.current);
	}), null;
}
function ot(e) {
	let t = new Float32Array(e.length * 3);
	e.forEach((e, n) => {
		t[n * 3] = e.x, t[n * 3 + 2] = e.z;
	});
	let n = new v.BufferGeometry();
	return n.setAttribute("position", new v.BufferAttribute(t, 3)), n;
}
function st(e, t, n) {
	let r = [], i = [], a = [], o = [], s = e.length;
	for (let o = 0; o < s; o += 1) {
		let c = e[n ? (o - 1 + s) % s : Math.max(0, o - 1)], l = e[n ? (o + 1) % s : Math.min(s - 1, o + 1)], u = Math.hypot(l.x - c.x, l.z - c.z) || 1, d = -(l.z - c.z) / u, f = (l.x - c.x) / u, p = {
			x: e[o].x + d * t,
			z: e[o].z + f * t
		}, m = {
			x: e[o].x - d * t,
			z: e[o].z - f * t
		};
		r.push(p), i.push(m), a.push(p, m);
	}
	for (let e = 0; e < (n ? s : s - 1); e += 1) {
		let t = (e + 1) % s;
		o.push(e * 2, t * 2, e * 2 + 1, e * 2 + 1, t * 2, t * 2 + 1);
	}
	let c = ot(a);
	c.setIndex(o);
	let l = (e) => {
		let t = ot(e.flatMap((e) => [e, e]));
		return t.setIndex(o), t;
	};
	return {
		surface: c,
		left: ot(r),
		right: ot(i),
		center: ot(e),
		leftWall: l(r),
		rightWall: l(i),
		surfaceXZ: a,
		leftXZ: r,
		rightXZ: i,
		centerXZ: e
	};
}
function ct(e, t, n, r, i) {
	let a = e.getAttribute("position");
	for (let e = 0; e < t.length; e += 1) a.setY(e, (i ?? $(t[e].x, t[e].z, n)) + r);
	a.needsUpdate = !0;
}
function lt(e, t, n, r, i) {
	let a = e.getAttribute("position");
	for (let e = 0; e < t.length; e += 1) {
		let o = (i ?? $(t[e].x, t[e].z, n)) + r;
		a.setY(e * 2, o), a.setY(e * 2 + 1, o - .055);
	}
	a.needsUpdate = !0;
}
function ut({ points: e, halfWidth: t, closed: a = !1, color: o, lineColor: s, edgeColor: c, markerColor: l, opacity: u, markers: d = [], reducedMotion: f, boundary: _ = !1, fixedHeight: y, layer: b = 0, overlay: x = !1 }) {
	let S = r(() => st(e, t, a), [
		e,
		t,
		a
	]), C = i([]);
	g(({ clock: e }) => {
		let t = f ? 0 : e.getElapsedTime(), n = _ ? .07 : x ? .05 : Ge + b * Ke;
		ct(S.surface, S.surfaceXZ, t, n, y), ct(S.left, S.leftXZ, t, n + .015, y), ct(S.right, S.rightXZ, t, n + .015, y), ct(S.center, S.centerXZ, t, n + .02, y), _ || (lt(S.leftWall, S.leftXZ, t, n, y), lt(S.rightWall, S.rightXZ, t, n, y)), d.forEach((e, r) => {
			let i = C.current[r];
			i && (i.position.y = (y ?? $(e.x, e.z, t)) + n + (e.covered ? .035 : .09));
		});
	}), n(() => () => {
		S.surface.dispose(), S.left.dispose(), S.right.dispose(), S.center.dispose(), S.leftWall.dispose(), S.rightWall.dispose();
	}, [S]);
	let w = a ? "lineLoop" : "line";
	return /* @__PURE__ */ h("group", {
		renderOrder: x ? 3 : _ ? .5 : 1 + b / 100,
		children: [
			/* @__PURE__ */ m("mesh", {
				geometry: S.surface,
				frustumCulled: !1,
				children: /* @__PURE__ */ m("meshBasicMaterial", {
					color: o,
					transparent: u < 1,
					opacity: u,
					depthTest: !x,
					depthWrite: !x && !_,
					side: v.DoubleSide
				})
			}),
			/* @__PURE__ */ m(w, {
				geometry: S.center,
				frustumCulled: !1,
				children: /* @__PURE__ */ m("lineBasicMaterial", {
					color: s,
					transparent: !0,
					opacity: _ ? .12 : x ? .7 : .22,
					depthTest: !x,
					depthWrite: !1
				})
			}),
			/* @__PURE__ */ m(w, {
				geometry: S.left,
				frustumCulled: !1,
				children: /* @__PURE__ */ m("lineBasicMaterial", {
					color: c ?? s,
					transparent: !0,
					opacity: _ ? .28 : x ? .75 : .94,
					depthTest: !x,
					depthWrite: !1,
					toneMapped: !1
				})
			}),
			/* @__PURE__ */ m(w, {
				geometry: S.right,
				frustumCulled: !1,
				children: /* @__PURE__ */ m("lineBasicMaterial", {
					color: c ?? s,
					transparent: !0,
					opacity: _ ? .28 : x ? .75 : .94,
					depthTest: !x,
					depthWrite: !1,
					toneMapped: !1
				})
			}),
			!_ && !x && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("mesh", {
				geometry: S.leftWall,
				frustumCulled: !1,
				children: /* @__PURE__ */ m("meshBasicMaterial", {
					color: c ?? o,
					transparent: !0,
					opacity: .32,
					depthWrite: !1,
					side: v.DoubleSide
				})
			}), /* @__PURE__ */ m("mesh", {
				geometry: S.rightWall,
				frustumCulled: !1,
				children: /* @__PURE__ */ m("meshBasicMaterial", {
					color: c ?? o,
					transparent: !0,
					opacity: .32,
					depthWrite: !1,
					side: v.DoubleSide
				})
			})] }),
			d.map((e, t) => /* @__PURE__ */ h("group", {
				ref: (e) => {
					C.current[t] = e;
				},
				position: [
					e.x,
					.16,
					e.z
				],
				children: [/* @__PURE__ */ h("mesh", { children: [/* @__PURE__ */ m("cylinderGeometry", { args: [
					.2,
					.2,
					.04,
					12
				] }), /* @__PURE__ */ m("meshBasicMaterial", {
					color: e.covered ? "#52636a" : l ?? "#b7eeeb",
					depthTest: !x,
					depthWrite: !1,
					toneMapped: !1
				})] }), /* @__PURE__ */ h("mesh", {
					position: [
						0,
						.03,
						0
					],
					children: [/* @__PURE__ */ m("cylinderGeometry", { args: [
						.105,
						.105,
						.015,
						12
					] }), /* @__PURE__ */ m("meshBasicMaterial", {
						color: e.covered ? "#9aa7aa" : "#fff0a6",
						depthTest: !x,
						depthWrite: !1
					})]
				})]
			}, t))
		]
	});
}
function dt({ card: e, color: t, preview: n, reducedMotion: i, layer: a = 0, covered: o, cardIndex: s = 0 }) {
	let c = r(() => j(e, 16).map((e) => ({
		x: e.x * Q,
		z: e.y * Q
	})), [e]), l = r(() => O[e.t].cellT.map((t, n) => {
		let r = te(e, n);
		return {
			x: r.x * Q,
			z: r.y * Q,
			covered: o?.has(`${s}:${n}`)
		};
	}), [
		e,
		o,
		s
	]), u = r(() => n ? "#53d5d9" : new v.Color("#16869a").lerp(new v.Color(t), .52).getStyle(), [t, n]), d = n ? "#287f89" : t;
	return /* @__PURE__ */ m(ut, {
		points: c,
		halfWidth: 35 * Q / 2,
		color: u,
		lineColor: "#f4ffff",
		edgeColor: d,
		markerColor: n ? "#287f89" : t,
		opacity: n ? .58 : .42,
		markers: l,
		reducedMotion: i,
		fixedHeight: n ? We : void 0,
		layer: a,
		overlay: n
	});
}
function ft({ track: e, reducedMotion: t }) {
	let n = r(() => e.pts.map((e) => ({
		x: e.x * Q,
		z: e.y * Q
	})), [e]);
	return /* @__PURE__ */ m(ut, {
		points: n,
		halfWidth: e.halfWidth * Q,
		closed: !0,
		color: Ue,
		lineColor: "#9ce3e5",
		opacity: .11,
		boundary: !0,
		reducedMotion: t
	});
}
function pt() {
	let e = document.createElement("canvas");
	e.width = 512, e.height = 256;
	let t = e.getContext("2d");
	for (let [e, n, r] of [
		[
			145,
			151,
			78
		],
		[
			225,
			110,
			100
		],
		[
			325,
			136,
			83
		],
		[
			389,
			162,
			55
		]
	]) {
		let i = t.createRadialGradient(e, n, 0, e, n, r);
		i.addColorStop(0, "rgba(255,255,247,.82)"), i.addColorStop(.55, "rgba(255,255,249,.58)"), i.addColorStop(1, "rgba(255,255,255,0)"), t.fillStyle = i, t.fillRect(e - r, n - r, r * 2, r * 2);
	}
	return new v.CanvasTexture(e);
}
function mt() {
	let e = r(() => pt(), []);
	return n(() => () => e.dispose(), [e]), /* @__PURE__ */ m("group", { children: [
		[
			0,
			15,
			-85,
			19
		],
		[
			-45,
			13,
			-72,
			14
		],
		[
			47,
			16,
			-78,
			18
		],
		[
			-78,
			15,
			-15,
			19
		],
		[
			78,
			14,
			12,
			18
		],
		[
			-32,
			14,
			69,
			17
		],
		[
			34,
			15,
			72,
			18
		]
	].map(([t, n, r, i], a) => /* @__PURE__ */ m("sprite", {
		position: [
			t,
			n,
			r
		],
		scale: [
			i,
			i * .52,
			1
		],
		children: /* @__PURE__ */ m("spriteMaterial", {
			map: e,
			transparent: !0,
			depthWrite: !1,
			opacity: .76
		})
	}, a)) });
}
function ht() {
	let e = document.createElement("canvas");
	e.width = 512, e.height = 80;
	let t = e.getContext("2d");
	for (let e = 0; e < 2; e += 1) for (let n = 0; n < 16; n += 1) t.fillStyle = (e + n) % 2 ? "#0a3442" : "#f6ffff", t.fillRect(n * 32, e * 40, 32, 40);
	return new v.CanvasTexture(e);
}
function gt({ track: e, reducedMotion: t }) {
	let a = i(null), o = r(() => N(e, e.startS), [e]), s = r(() => ht(), []), c = e.halfWidth * 2 * Q;
	return n(() => () => s.dispose(), [s]), g(({ clock: e }) => {
		a.current && (a.current.position.y = $(o.x * Q, o.y * Q, t ? 0 : e.getElapsedTime()) + .05);
	}), /* @__PURE__ */ h("group", {
		ref: a,
		position: [
			o.x * Q,
			0,
			o.y * Q
		],
		rotation: [
			0,
			-o.h - Math.PI / 2,
			0
		],
		children: [[-c / 2, c / 2].map((e) => /* @__PURE__ */ h("mesh", {
			position: [
				e,
				1.65,
				0
			],
			children: [/* @__PURE__ */ m("cylinderGeometry", { args: [
				.08,
				.1,
				3.3,
				8
			] }), /* @__PURE__ */ m("meshStandardMaterial", {
				color: "#f0ffff",
				roughness: .55
			})]
		}, e)), /* @__PURE__ */ h("mesh", {
			position: [
				0,
				3.12,
				0
			],
			children: [/* @__PURE__ */ m("planeGeometry", { args: [c + .2, .72] }), /* @__PURE__ */ m("meshBasicMaterial", {
				map: s,
				side: v.DoubleSide
			})]
		})]
	});
}
function _t({ track: e, mode: t, reducedMotion: n }) {
	let a = i(null), o = r(() => N(e, e.startS - le(t)), [e, t]), s = e.halfWidth * 2 * Q;
	return g(({ clock: e }) => {
		a.current && (a.current.position.y = $(o.x * Q, o.y * Q, n ? 0 : e.getElapsedTime()) + .08);
	}), /* @__PURE__ */ h("group", {
		ref: a,
		position: [
			o.x * Q,
			0,
			o.y * Q
		],
		rotation: [
			0,
			-o.h - Math.PI / 2,
			0
		],
		children: [/* @__PURE__ */ h("mesh", {
			position: [
				0,
				.04,
				0
			],
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			children: [/* @__PURE__ */ m("planeGeometry", { args: [s, .14] }), /* @__PURE__ */ m("meshBasicMaterial", {
				color: "#b7f8fc",
				transparent: !0,
				opacity: .82,
				depthWrite: !1,
				side: v.DoubleSide
			})]
		}), [-s / 2, s / 2].map((e) => /* @__PURE__ */ h("mesh", {
			position: [
				e,
				.58,
				0
			],
			children: [/* @__PURE__ */ m("cylinderGeometry", { args: [
				.075,
				.12,
				1.12,
				8
			] }), /* @__PURE__ */ m("meshStandardMaterial", {
				color: "#b7f8fc",
				roughness: .58
			})]
		}, e))]
	});
}
function vt({ x: e, z: t, reducedMotion: n }) {
	let r = i(null);
	return g(({ clock: i }) => {
		r.current && (r.current.position.y = $(e, t, n ? 0 : i.getElapsedTime()));
	}), /* @__PURE__ */ h("group", {
		ref: r,
		position: [
			e,
			0,
			t
		],
		children: [
			/* @__PURE__ */ h("mesh", {
				position: [
					0,
					.04,
					0
				],
				children: [/* @__PURE__ */ m("cylinderGeometry", { args: [
					.42,
					.46,
					.3,
					12
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: "#f1ffff",
					roughness: .6
				})]
			}),
			/* @__PURE__ */ h("mesh", {
				position: [
					0,
					.32,
					0
				],
				children: [/* @__PURE__ */ m("cylinderGeometry", { args: [
					.25,
					.34,
					.34,
					12
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: "#ff8847",
					roughness: .58
				})]
			}),
			/* @__PURE__ */ h("mesh", {
				position: [
					0,
					.77,
					0
				],
				children: [/* @__PURE__ */ m("cylinderGeometry", { args: [
					.045,
					.045,
					.65,
					8
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: "#526f79",
					metalness: .5,
					roughness: .42
				})]
			}),
			/* @__PURE__ */ h("mesh", {
				position: [
					.18,
					1.06,
					0
				],
				rotation: [
					0,
					0,
					-Math.PI / 2
				],
				children: [/* @__PURE__ */ m("coneGeometry", { args: [
					.22,
					.4,
					3
				] }), /* @__PURE__ */ m("meshStandardMaterial", { color: "#ff9944" })]
			})
		]
	});
}
function yt() {
	let e = new v.Shape();
	e.moveTo(0, -2.75), e.bezierCurveTo(.54, -2.52, .75, -1.7, .79, -.35), e.lineTo(.64, 1.78), e.quadraticCurveTo(.62, 2.21, .38, 2.24), e.lineTo(-.38, 2.24), e.quadraticCurveTo(-.62, 2.21, -.64, 1.78), e.lineTo(-.79, -.35), e.bezierCurveTo(-.75, -1.7, -.54, -2.52, 0, -2.75);
	let t = new v.ExtrudeGeometry(e, {
		depth: .43,
		bevelEnabled: !0,
		bevelThickness: .07,
		bevelSize: .07,
		bevelSegments: 1,
		steps: 1,
		curveSegments: 7
	});
	return t.rotateX(Math.PI / 2), t.translate(0, .38, 0), t.computeVertexNormals(), t;
}
var bt = yt();
function xt(e) {
	let t = document.createElement("canvas");
	t.height = 128;
	let n = t.getContext("2d");
	return n.font = "bold 54px Microsoft YaHei, system-ui, sans-serif", t.width = Math.min(512, Math.max(156, Math.ceil(n.measureText(e).width + 72))), n = t.getContext("2d"), n.fillStyle = "rgba(2,49,66,.78)", n.beginPath(), n.roundRect(4, 4, t.width - 8, 120, 34), n.fill(), n.strokeStyle = "#d5ffff", n.lineWidth = 8, n.stroke(), n.font = "bold 54px Microsoft YaHei, system-ui, sans-serif", n.textAlign = "center", n.textBaseline = "middle", n.fillStyle = "#f3ffff", n.fillText(e, t.width / 2, 65, t.width - 52), new v.CanvasTexture(t);
}
function St({ boat: e, color: t }) {
	return /* @__PURE__ */ h("group", {
		scale: .4,
		children: [
			/* @__PURE__ */ m("mesh", {
				geometry: bt,
				scale: e === 1 ? [
					.9,
					.9,
					1.12
				] : e === 2 ? [
					.83,
					.85,
					1.22
				] : e === 3 ? [
					1.23,
					1.05,
					.83
				] : e === 4 ? [
					.95,
					.9,
					1.08
				] : e === 5 ? [
					1.2,
					.88,
					.93
				] : [
					1,
					1,
					1
				],
				children: /* @__PURE__ */ m("meshStandardMaterial", {
					color: t,
					metalness: .18,
					roughness: .42,
					flatShading: !0
				})
			}),
			/* @__PURE__ */ h("mesh", {
				position: [
					0,
					.55,
					-.45
				],
				scale: [
					.43,
					.24,
					.84
				],
				children: [/* @__PURE__ */ m("sphereGeometry", { args: [
					1,
					12,
					8
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: "#0b394d",
					metalness: .35,
					roughness: .35
				})]
			}),
			e === 0 && /* @__PURE__ */ h(p, { children: [[-1, 1].map((e) => /* @__PURE__ */ h("group", { children: [/* @__PURE__ */ h("mesh", {
				position: [
					e * 1.03,
					.04,
					.35
				],
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ m("capsuleGeometry", { args: [
					.22,
					1.4,
					3,
					7
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: t,
					metalness: .25,
					roughness: .38
				})]
			}), /* @__PURE__ */ h("mesh", {
				position: [
					e * 1.03,
					.02,
					1.8
				],
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ m("cylinderGeometry", { args: [
					.2,
					.3,
					.43,
					10
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: "#183f52",
					metalness: .5,
					roughness: .34
				})]
			})] }, e)), /* @__PURE__ */ h("mesh", {
				position: [
					0,
					.75,
					1.25
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ m("coneGeometry", { args: [
					.44,
					.92,
					3
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: t,
					side: v.DoubleSide
				})]
			})] }),
			e === 1 && /* @__PURE__ */ h(p, { children: [[-1, 1].map((e) => /* @__PURE__ */ h("group", { children: [/* @__PURE__ */ h("mesh", {
				position: [
					e * 1.1,
					.2,
					-.35
				],
				rotation: [
					0,
					e * -.22,
					e * -.3
				],
				children: [/* @__PURE__ */ m("boxGeometry", { args: [
					1.65,
					.12,
					1.9
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: t,
					flatShading: !0
				})]
			}), /* @__PURE__ */ h("mesh", {
				position: [
					e * 1.78,
					.3,
					-.5
				],
				rotation: [
					0,
					0,
					e * -.25
				],
				children: [/* @__PURE__ */ m("coneGeometry", { args: [
					.38,
					.95,
					3
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: "#e4f4e8",
					flatShading: !0
				})]
			})] }, e)), /* @__PURE__ */ h("mesh", {
				position: [
					0,
					.88,
					1.25
				],
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: [/* @__PURE__ */ m("coneGeometry", { args: [
					.43,
					1.2,
					3
				] }), /* @__PURE__ */ m("meshStandardMaterial", {
					color: t,
					flatShading: !0
				})]
			})] }),
			e === 2 && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ h("mesh", {
					position: [
						0,
						1.04,
						.4
					],
					rotation: [
						Math.PI / 2,
						0,
						0
					],
					children: [/* @__PURE__ */ m("coneGeometry", { args: [
						.6,
						1.95,
						3
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: t,
						flatShading: !0,
						side: v.DoubleSide
					})]
				}),
				[-1, 1].map((e) => /* @__PURE__ */ h("mesh", {
					position: [
						e * .92,
						.24,
						1.15
					],
					rotation: [
						0,
						e * .38,
						0
					],
					children: [/* @__PURE__ */ m("coneGeometry", { args: [
						.42,
						1.1,
						3
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: "#d8f2eb",
						flatShading: !0
					})]
				}, e)),
				/* @__PURE__ */ h("mesh", {
					position: [
						0,
						.15,
						-2.48
					],
					rotation: [
						Math.PI / 2,
						0,
						0
					],
					children: [/* @__PURE__ */ m("coneGeometry", { args: [
						.32,
						1.1,
						5
					] }), /* @__PURE__ */ m("meshStandardMaterial", { color: "#e8ffff" })]
				})
			] }),
			e === 3 && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ h("mesh", {
					position: [
						0,
						.48,
						-.15
					],
					scale: [
						1.27,
						.66,
						1.48
					],
					children: [/* @__PURE__ */ m("sphereGeometry", { args: [
						1,
						10,
						7
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: t,
						flatShading: !0
					})]
				}),
				[-1, 1].map((e) => /* @__PURE__ */ h("group", { children: [/* @__PURE__ */ h("mesh", {
					position: [
						e * .83,
						1.04,
						-.45
					],
					rotation: [
						0,
						0,
						e * -.24
					],
					children: [/* @__PURE__ */ m("coneGeometry", { args: [
						.25,
						.7,
						5
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: "#d7eef1",
						flatShading: !0
					})]
				}), /* @__PURE__ */ h("mesh", {
					position: [
						e * 1.25,
						.12,
						.25
					],
					rotation: [
						0,
						0,
						e * Math.PI / 2
					],
					children: [/* @__PURE__ */ m("coneGeometry", { args: [
						.25,
						.9,
						5
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: "#d7eef1",
						flatShading: !0
					})]
				})] }, e)),
				/* @__PURE__ */ h("mesh", {
					position: [
						0,
						1.14,
						.26
					],
					children: [/* @__PURE__ */ m("coneGeometry", { args: [
						.28,
						.72,
						5
					] }), /* @__PURE__ */ m("meshStandardMaterial", { color: "#d7eef1" })]
				})
			] }),
			e === 4 && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ h("mesh", {
					position: [
						0,
						.74,
						-.1
					],
					scale: [
						.78,
						.47,
						1.27
					],
					children: [/* @__PURE__ */ m("sphereGeometry", { args: [
						1,
						14,
						9
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: t,
						flatShading: !0
					})]
				}),
				/* @__PURE__ */ h("mesh", {
					position: [
						0,
						.93,
						-.93
					],
					scale: [
						.57,
						.53,
						.62
					],
					children: [/* @__PURE__ */ m("sphereGeometry", { args: [
						1,
						12,
						8
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: "#e7f4eb",
						flatShading: !0
					})]
				}),
				[-1, 1].map((e) => /* @__PURE__ */ h("mesh", {
					position: [
						e * 1.12,
						.18,
						.25
					],
					rotation: [
						0,
						e * .46,
						e * -.2
					],
					children: [/* @__PURE__ */ m("boxGeometry", { args: [
						1.2,
						.12,
						1.05
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: t,
						flatShading: !0
					})]
				}, e))
			] }),
			e === 5 && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ h("mesh", {
					position: [
						0,
						.5,
						-.12
					],
					scale: [
						1.05,
						.62,
						1.4
					],
					children: [/* @__PURE__ */ m("sphereGeometry", { args: [
						1,
						10,
						7
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: t,
						flatShading: !0
					})]
				}),
				/* @__PURE__ */ h("mesh", {
					position: [
						0,
						.24,
						-.1
					],
					rotation: [
						Math.PI / 2,
						0,
						0
					],
					scale: [
						1,
						1.34,
						1
					],
					children: [/* @__PURE__ */ m("torusGeometry", { args: [
						1.28,
						.15,
						7,
						22
					] }), /* @__PURE__ */ m("meshStandardMaterial", {
						color: "#d6f1ec",
						metalness: .35,
						roughness: .42
					})]
				}),
				[-1, 1].map((e) => /* @__PURE__ */ h("mesh", {
					position: [
						e * 1.36,
						.16,
						.55
					],
					rotation: [
						0,
						0,
						e * .18
					],
					children: [/* @__PURE__ */ m("capsuleGeometry", { args: [
						.22,
						1.1,
						3,
						7
					] }), /* @__PURE__ */ m("meshStandardMaterial", { color: "#e7f7f0" })]
				}, e))
			] }),
			e !== 5 && [-1, 1].map((e) => /* @__PURE__ */ h("mesh", {
				position: [
					e * .57,
					.42,
					-.18
				],
				children: [/* @__PURE__ */ m("boxGeometry", { args: [
					.055,
					.035,
					2.25
				] }), /* @__PURE__ */ m("meshStandardMaterial", { color: "#f3ffff" })]
			}, `rail:${e}`))
		]
	});
}
function Ct({ rid: e, boat: t, color: a, name: o, fallbackPose: s, motions: c, reducedMotion: l, out: u }) {
	let d = i(null), f = r(() => xt(o), [o]);
	return n(() => () => f.dispose(), [f]), n(() => {
		d.current?.traverse((e) => {
			e.renderOrder = 5;
		});
	}, []), g(({ clock: t }) => {
		if (!d.current) return;
		let n = c.current.get(e), r = n?.current ?? s, i = r.x * Q, a = r.y * Q, o = l ? 0 : t.getElapsedTime(), f = $(i + .8, a, o) - $(i - .8, a, o), p = $(i, a + .8, o) - $(i, a - .8, o);
		d.current.position.set(i, $(i, a, o) + .27, a), d.current.rotation.set(.13 * p - (n?.energy ?? 0) * .055, -r.h - Math.PI / 2, -.12 * f + (n?.bank ?? 0)), d.current.visible = !(n?.out ?? u);
	}), /* @__PURE__ */ h("group", {
		ref: d,
		position: [
			s.x * Q,
			.27,
			s.y * Q
		],
		visible: !u,
		renderOrder: 5,
		children: [/* @__PURE__ */ m(St, {
			boat: t,
			color: a
		}), /* @__PURE__ */ m("sprite", {
			position: [
				0,
				1.42,
				0
			],
			scale: [
				f.image.width / 128 * .65,
				.65,
				1
			],
			children: /* @__PURE__ */ m("spriteMaterial", {
				map: f,
				transparent: !0,
				depthWrite: !1
			})
		})]
	});
}
function wt() {
	let e = document.createElement("canvas");
	e.width = 64, e.height = 64;
	let t = e.getContext("2d"), n = t.createRadialGradient(32, 32, 1, 32, 32, 31);
	return n.addColorStop(0, "rgba(255,255,255,.9)"), n.addColorStop(.45, "rgba(225,255,252,.58)"), n.addColorStop(1, "rgba(225,255,252,0)"), t.fillStyle = n, t.fillRect(0, 0, 64, 64), new v.CanvasTexture(e);
}
function Tt({ rid: e, fallbackPose: t, motions: a, texture: o, reducedMotion: s, out: c }) {
	let l = r(() => {
		let e = new v.BufferGeometry();
		return e.setAttribute("position", new v.BufferAttribute(/* @__PURE__ */ new Float32Array(270), 3)), e;
	}, []);
	n(() => () => l.dispose(), [l]);
	let u = i(null), d = i(null);
	return g(({ clock: n }) => {
		let r = a.current.get(e), i = r?.current ?? t, o = i.x * Q, f = i.y * Q, p = Math.cos(i.h), m = Math.sin(i.h), h = r?.energy ?? 0, g = s ? 0 : n.getElapsedTime(), _ = l.getAttribute("position");
		for (let e = 0; e < 90; e += 1) {
			let t = e % 2 ? 1 : -1, n = (Math.floor(e / 2) / 45 + g * .17) % 1, r = .65 + n * (7.8 + h * 3.2), i = t * (.1 + n * (.94 + h * .35)) + .08 * Math.sin(e * 12.9), a = o - p * r - m * i, s = f - m * r + p * i;
			_.setXYZ(e, a, $(a, s, g) + .07, s);
		}
		_.needsUpdate = !0, u.current && (u.current.opacity = .43 + h * .24, u.current.size = .25 + h * .11), d.current && (d.current.visible = !(r?.out ?? c));
	}), /* @__PURE__ */ m("points", {
		ref: d,
		geometry: l,
		frustumCulled: !1,
		visible: !c,
		children: /* @__PURE__ */ m("pointsMaterial", {
			ref: u,
			map: o,
			color: "#a7e5e2",
			size: .25,
			transparent: !0,
			opacity: .43,
			depthWrite: !1
		})
	});
}
function Et({ rid: e, fallbackPose: t, motions: a, texture: o, reducedMotion: s, out: c }) {
	let l = r(() => {
		let e = new v.BufferGeometry();
		return e.setAttribute("position", new v.BufferAttribute(/* @__PURE__ */ new Float32Array(144), 3)), e;
	}, []), u = i(null), d = i(null);
	return n(() => () => l.dispose(), [l]), g(({ clock: n }) => {
		let r = a.current.get(e), i = s ? 0 : r?.energy ?? 0;
		if (!d.current || !u.current || (d.current.visible = i > .05 && !(r?.out ?? c), i <= .05)) return;
		let o = r?.current ?? t, f = o.x * Q, p = o.y * Q, m = Math.cos(o.h), h = Math.sin(o.h), g = n.getElapsedTime(), _ = l.getAttribute("position");
		for (let e = 0; e < 48; e += 1) {
			let t = e % 2 ? 1 : -1, n = (e * .618 + g * 2.1) % 1, r = .85 - n * 1.3, a = t * (.36 + n * (1.1 + i * .25)), o = f + m * r - h * a, s = p + h * r + m * a;
			_.setXYZ(e, o, $(o, s, g) + .13 + Math.sin(n * Math.PI) * (.25 + i * .36), s);
		}
		_.needsUpdate = !0, u.current.opacity = Math.min(.9, .38 + i * .4), u.current.size = .16 + i * .12;
	}), /* @__PURE__ */ m("points", {
		ref: d,
		geometry: l,
		frustumCulled: !1,
		visible: !1,
		children: /* @__PURE__ */ m("pointsMaterial", {
			ref: u,
			map: o,
			color: "#f4ffff",
			size: .2,
			transparent: !0,
			opacity: .7,
			depthWrite: !1
		})
	});
}
function Dt({ pub: e, preview: t, myRid: a, members: o, mode: s, resetToken: c }) {
	let u = y(), d = i({
		azimuth: 0,
		elevation: 0,
		zoom: 1
	}), f = i(/* @__PURE__ */ new Map()), g = i(null), _ = i(() => {}), x = i(/* @__PURE__ */ new Map());
	n(() => {
		d.current.azimuth = 0, d.current.elevation = 0, d.current.zoom = 1, f.current.clear(), g.current = null, _.current();
	}, [c]);
	let S = r(() => se(e.track, e.courseLength), [e.track, e.courseLength]), C = e.phase === "choose", w = C ? null : e.players.find((e) => e.rid === a) ?? e.players[0], T = w ? P(w.trail, w.cell, w.ghost) : N(S, S.startS), E = r(() => {
		let t = /* @__PURE__ */ new Map();
		for (let n of e.players) {
			let r = e.players.filter((e) => e.rid !== n.rid).flatMap((e) => e.trail.flatMap((e) => j(e)));
			t.set(n.rid, me(n.trail, r));
		}
		return t;
	}, [e.players]), D = r(() => wt(), []);
	n(() => () => D.dispose(), [D]);
	let O = (e) => {
		let t = o.find((t) => t.rid === e);
		return l[(t?.colorIndex ?? 0) % l.length].hex;
	};
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h(b, {
		className: "ts-canvas",
		gl: {
			antialias: !0,
			powerPreference: "low-power"
		},
		dpr: [1, 2],
		frameloop: "demand",
		camera: {
			fov: He,
			near: .1,
			far: 300
		},
		onCreated: ({ gl: e, invalidate: t }) => {
			_.current = t, e.outputColorSpace = v.SRGBColorSpace, e.toneMapping = v.ACESFilmicToneMapping, e.toneMappingExposure = .92;
		},
		children: [
			/* @__PURE__ */ m("color", {
				attach: "background",
				args: ["#75cbe3"]
			}),
			/* @__PURE__ */ m("hemisphereLight", { args: [
				"#d6ffff",
				"#075976",
				2.5
			] }),
			/* @__PURE__ */ m("directionalLight", {
				color: "#fff0d2",
				intensity: 2.3,
				position: [
					-12,
					20,
					-25
				]
			}),
			/* @__PURE__ */ m(rt, {
				active: !u,
				mode: s,
				pub: e,
				preview: t,
				resetToken: c
			}),
			/* @__PURE__ */ m(it, {
				pub: e,
				motions: x,
				reducedMotion: u
			}),
			/* @__PURE__ */ m(at, {
				mode: s,
				pose: T,
				focusRid: w?.rid ?? "",
				motions: x,
				track: S,
				orbit: d,
				reducedMotion: u
			}),
			/* @__PURE__ */ m(nt, { reducedMotion: u }),
			/* @__PURE__ */ m(mt, {}),
			!C && /* @__PURE__ */ m(ft, {
				track: S,
				reducedMotion: u
			}),
			!C && /* @__PURE__ */ m(gt, {
				track: S,
				reducedMotion: u
			}),
			!C && /* @__PURE__ */ m(_t, {
				track: S,
				mode: e.mode,
				reducedMotion: u
			}),
			!C && S.buoys.map((e, t) => /* @__PURE__ */ m(vt, {
				x: e.x * Q,
				z: e.y * Q,
				reducedMotion: u
			}, t)),
			e.players.flatMap((e, t) => e.trail.map((n, r) => /* @__PURE__ */ m(dt, {
				card: n,
				cardIndex: r,
				color: O(e.rid),
				preview: !1,
				reducedMotion: u,
				layer: t + r * .01,
				covered: E.get(e.rid)
			}, `${e.rid}:${r}`))),
			t.map((e, t) => /* @__PURE__ */ m(dt, {
				card: e,
				color: "#47e5e8",
				preview: !0,
				reducedMotion: u
			}, `preview:${t}`)),
			!C && e.players.filter((e) => e.boat >= 0).map((e) => {
				let t = P(e.trail, e.cell, e.ghost), n = o.find((t) => t.rid === e.rid);
				return /* @__PURE__ */ h("group", { children: [
					/* @__PURE__ */ m(Tt, {
						rid: e.rid,
						fallbackPose: t,
						motions: x,
						texture: D,
						reducedMotion: u,
						out: e.out
					}),
					/* @__PURE__ */ m(Et, {
						rid: e.rid,
						fallbackPose: t,
						motions: x,
						texture: D,
						reducedMotion: u,
						out: e.out
					}),
					/* @__PURE__ */ m(Ct, {
						rid: e.rid,
						boat: e.boat,
						fallbackPose: t,
						motions: x,
						color: O(e.rid),
						name: n?.name ?? e.rid,
						reducedMotion: u,
						out: e.out
					})
				] }, e.rid);
			})
		]
	}), /* @__PURE__ */ m("div", {
		className: "ts-orbit-drag",
		onPointerDown: (e) => {
			if (f.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), f.current.size === 2) {
				let [e, t] = [...f.current.values()];
				g.current = Math.hypot(e.x - t.x, e.y - t.y);
			}
			e.currentTarget.setPointerCapture(e.pointerId);
		},
		onPointerMove: (e) => {
			let t = f.current.get(e.pointerId);
			if (!t) return;
			let n = e.clientX - t.x, r = e.clientY - t.y;
			if (f.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), f.current.size >= 2) {
				let [e, t] = [...f.current.values()], n = Math.hypot(e.x - t.x, e.y - t.y);
				g.current && n > 0 && (d.current.zoom = Math.max(.55, Math.min(2.5, d.current.zoom * g.current / n))), g.current = n;
			} else {
				let e = s === "follow" ? .58 : 1.15;
				d.current.azimuth = (d.current.azimuth + n * .008) % (Math.PI * 2), d.current.elevation = Math.max(.2, Math.min(1.35, e + d.current.elevation + r * .006)) - e;
			}
			_.current();
		},
		onPointerUp: (e) => {
			f.current.delete(e.pointerId), g.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
		},
		onPointerCancel: (e) => {
			f.current.delete(e.pointerId), g.current = null;
		},
		onLostPointerCapture: (e) => {
			f.current.delete(e.pointerId), g.current = null;
		},
		onWheel: (e) => {
			e.preventDefault(), d.current.zoom = Math.max(.55, Math.min(2.5, d.current.zoom * Math.exp(e.deltaY * .001))), _.current();
		}
	})] });
}
//#endregion
//#region src/games/tornadosplash/choose-view.tsx
var Ot = [
	"games.tornadosplash.boat.ika",
	"games.tornadosplash.boat.flyfin",
	"games.tornadosplash.boat.shark",
	"games.tornadosplash.boat.harisen",
	"games.tornadosplash.boat.ashika",
	"games.tornadosplash.boat.kame"
];
function kt({ public: e, members: t, myRid: n, send: r }) {
	let i = e, s = o(), [c, u] = a(0), [p] = a(Qe), g = i.players.find((e) => e.rid === n), _ = i.turn === n, v = (e) => i.players.find((t) => t.boat === e), y = (e) => t.find((t) => t.rid === e), b = (e) => y(e)?.name ?? e, x = (e) => l[(y(e)?.colorIndex ?? 0) % l.length].hex, S = E.findIndex((e, t) => !v(t)), C = g && g.boat >= 0 ? g.boat : v(c) ? S : c, w = E[C], T = s(Ot[C]), D = b(i.turn ?? "");
	return /* @__PURE__ */ m("div", {
		className: "ts-game ts-choose-game",
		children: /* @__PURE__ */ m(d, {
			adaptive: !0,
			className: "tsp-screen tsp-choose-screen",
			scroll: !1,
			actionsHeight: "h-48",
			banner: /* @__PURE__ */ m("div", {
				className: "ts-banner",
				children: /* @__PURE__ */ m(f, {
					tone: _ ? "accent" : "info",
					text: s(_ ? "games.tornadosplash.ui.yourChoose" : "games.tornadosplash.ui.waitChoose", { name: D }),
					sub: s("games.tornadosplash.ui.chooseHint"),
					chip: s("games.tornadosplash.opt.modeRetail"),
					accent: L.accent
				})
			}),
			actions: /* @__PURE__ */ h("div", {
				className: "ts-choose-actions",
				children: [
					/* @__PURE__ */ h("div", {
						className: "ts-choose-picked",
						children: [/* @__PURE__ */ m(Ve, {
							boat: C,
							color: x(n)
						}), /* @__PURE__ */ m("span", { children: T })]
					}),
					/* @__PURE__ */ h("div", {
						className: "ts-choose-stats",
						children: [
							/* @__PURE__ */ h("span", { children: [
								s("games.tornadosplash.ui.boatSpeed"),
								" ",
								/* @__PURE__ */ h("b", { children: [w.speed, " / 5"] })
							] }),
							/* @__PURE__ */ h("span", { children: [
								s("games.tornadosplash.ui.boatTurn"),
								" ",
								/* @__PURE__ */ h("b", { children: [w.turn, " / 5"] })
							] }),
							/* @__PURE__ */ m("span", { children: s("games.tornadosplash.ui.boatDeck") })
						]
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "ts-choose-confirm",
						disabled: !_ || g?.boat !== -1,
						onClick: () => r({
							type: "selectBoat",
							boat: C
						}),
						children: g && g.boat >= 0 ? s("games.tornadosplash.ui.selectedBoat") : s("games.tornadosplash.ui.chooseBoat")
					})
				]
			}),
			children: /* @__PURE__ */ h("div", {
				className: "ts-scene ts-choose-scene",
				children: [
					p && /* @__PURE__ */ m(Dt, {
						pub: i,
						preview: [],
						myRid: n,
						members: t,
						mode: "follow",
						resetToken: 0
					}),
					/* @__PURE__ */ m("div", {
						className: "ts-choose-hero",
						children: /* @__PURE__ */ m(Ve, {
							boat: C,
							color: x(n)
						})
					}),
					/* @__PURE__ */ h("div", {
						className: "ts-choose-hero-name",
						children: [
							b(n),
							" · ",
							T
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "ts-choose-panel",
						children: [/* @__PURE__ */ h("div", {
							className: "ts-choose-heading",
							children: [/* @__PURE__ */ m("h2", { children: s("games.tornadosplash.phase.choose") }), /* @__PURE__ */ m("span", { children: s("games.tornadosplash.ui.chooseHint") })]
						}), /* @__PURE__ */ m("div", {
							className: "ts-choose-options",
							children: E.map((e, t) => {
								let r = v(t);
								return /* @__PURE__ */ h("button", {
									type: "button",
									className: "ts-choose-option",
									"data-selected": t === C,
									"data-taken": !!r,
									disabled: !_ || !!r,
									"aria-pressed": t === C,
									"aria-label": `${s(Ot[t])}${r ? ` · ${s("games.tornadosplash.ui.boatTaken", { name: b(r.rid) })}` : ""}`,
									onClick: () => u(t),
									children: [
										/* @__PURE__ */ m(Ve, {
											boat: t,
											color: x(r ? r.rid : n)
										}),
										/* @__PURE__ */ m("span", { children: s(Ot[t]) }),
										r && /* @__PURE__ */ m("small", { children: s("games.tornadosplash.ui.boatTaken", { name: b(r.rid) }) })
									]
								}, e.id);
							})
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/tornadosplash/trail-card.tsx
function At({ type: e, mirror: t = 1 }) {
	let n = O[e], r = n.angle * Math.PI / 180, i = (e) => {
		let n = 36 * (1 - Math.cos(r * e));
		return [21 + (t === 1 ? n : -n), 62 - 54 * Math.sin(r * e) / Math.sin(r)];
	}, a = Array.from({ length: 17 }, (e, t) => {
		let [n, r] = i(t / 16);
		return `${t === 0 ? "M" : "L"}${n.toFixed(1)} ${r.toFixed(1)}`;
	}).join(" "), [o, s] = i(0);
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 42 68",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ m("path", {
				d: a,
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3.5",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("circle", {
				cx: o,
				cy: s,
				r: "2",
				fill: "currentColor"
			}),
			n.cellT.map((e, t) => {
				let [n, r] = i(e);
				return /* @__PURE__ */ m("circle", {
					cx: n,
					cy: r,
					r: "3.5",
					fill: "#ffd15a",
					stroke: "#153b49",
					strokeWidth: "1.2"
				}, t);
			})
		]
	});
}
//#endregion
//#region src/games/tornadosplash/view-player.tsx
function jt(e) {
	return e.reduce((e, t) => e + O[t.t].cells, 0);
}
function Mt(e, t, n) {
	let r = [], i = e;
	for (let e of t) {
		let t = pe(i, e.t, e.m, n);
		if (!t) break;
		r.push(t), i = A(t);
	}
	return r;
}
function Nt(e) {
	return j(e).map((e) => `${e.x},${e.y}`).join(" ");
}
function Pt({ public: e, private: t, members: n, myRid: i, send: g }) {
	let _ = e, v = t ?? { hand: [] }, y = o(), b = se(_.track, _.courseLength), x = _.players.find((e) => e.rid === i), S = _.turn === i, C = _.phase === "start", w = _.mode === "ts2", [T, E] = a([]), [D, ee] = a(!1), [k, ne] = a([]), [re, ie] = a("follow"), [ae, oe] = a(0), [ce, M] = a(null), [ue] = a(Qe), de = `${_.phase}:${_.race}:${_.turn}:${x?.trail.length ?? 0}:${x?.handCount ?? 0}`, [fe, pe] = a(de);
	fe !== de && (pe(de), E([]), ee(!1), ne([]), M(null));
	let F = (e) => {
		let t = n.find((t) => t.rid === e);
		return l[(t?.colorIndex ?? 0) % l.length].hex;
	}, I = (e) => n.find((t) => t.rid === e)?.name ?? e, R = D ? 4 : 3, z = jt(T), B = _.phase === "race" || _.phase === "start", he = r(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of v.hand) e.set(t, (e.get(t) ?? 0) + 1);
		return [
			"A",
			"B",
			"C",
			"D",
			"E"
		].filter((t) => (e.get(t) ?? 0) > 0).map((t) => ({
			t,
			count: e.get(t) ?? 0,
			used: T.filter((e) => e.t === t).length
		}));
	}, [v.hand, T]), V = x ? x.trail.length > 0 ? A(x.trail[x.trail.length - 1]) : x.ghost : null, ge = r(() => [..._.players.filter((e) => e.rid !== i && !e.out).map((e) => ({
		...P(e.trail, e.cell, e.ghost),
		r: 24
	})), ...b.buoys.map((e) => ({
		...e,
		r: 26
	}))], [
		_.players,
		i,
		b
	]), _e = V && T.length > 0 ? Mt(V, T, ge) : [], ve = T.length > 0 && _e.length < T.length, ye = r(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of _.players) {
			let n = _.players.filter((e) => e.rid !== t.rid).flatMap((e) => e.trail.flatMap((e) => j(e)));
			e.set(t.rid, me(t.trail, n));
		}
		return e;
	}, [_.players]), H = S && B && x != null && !x.out && !x.finished, be = (e) => {
		if (!H || C && e !== "A" && e !== "B") return !1;
		let t = he.find((t) => t.t === e);
		if (!t || t.used >= t.count) return !1;
		let n = w || C ? 3 : R;
		return z + O[e].cells <= n;
	}, xe = H && T.length > 0 && !ve && (w || C ? z === 3 : z >= 1 && z <= R), Se = r(() => [..._.players].sort((e, t) => (e.out ? 1e3 : e.finished > 0 ? e.finished : 500 - e.progress / 1e6) - (t.out ? 1e3 : t.finished > 0 ? t.finished : 500 - t.progress / 1e6)), [_.players]), { tone: U, text: W, sub: G } = _.phase === "done" ? {
		tone: "done",
		text: y("games.tornadosplash.phase.done")
	} : _.phase === "standby" ? {
		tone: S ? "accent" : "info",
		text: S ? y("games.tornadosplash.ui.yourBid") : y("games.tornadosplash.ui.waitBid", { name: I(_.standby?.declarer ?? "") }),
		sub: y("games.tornadosplash.ui.bidHint")
	} : {
		tone: S ? "accent" : "info",
		text: S ? y(C ? "games.tornadosplash.ui.yourStart" : "games.tornadosplash.ui.yourMove") : y("games.tornadosplash.ui.waitMove", { name: I(_.turn ?? "") })
	}, Ce = w ? _.race === 1 ? y("games.tornadosplash.race.qualifier") : y("games.tornadosplash.race.final") : _.racesTotal > 1 ? y("games.tornadosplash.race.grandPrix", { n: _.race }) : y("games.tornadosplash.race.single"), K = b.pts.map((e) => `${e.x},${e.y}`).join(" "), q = N(b, b.startS), J = Math.cos(q.h + Math.PI / 2), Y = Math.sin(q.h + Math.PI / 2), X = N(b, b.startS - le(_.mode)), Z = Math.cos(X.h + Math.PI / 2), we = Math.sin(X.h + Math.PI / 2), Te = /* @__PURE__ */ h("g", {
		transform: `translate(${-b.bbox.x} ${-b.bbox.y})`,
		children: [
			/* @__PURE__ */ m("polygon", {
				points: K,
				fill: "none",
				stroke: "#155e75",
				strokeWidth: b.halfWidth * 2,
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("polygon", {
				points: K,
				fill: "none",
				stroke: "#0e7490",
				strokeWidth: b.halfWidth * 2 - 26,
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ m("polygon", {
				points: K,
				fill: "none",
				stroke: "#67e8f9",
				strokeOpacity: .25,
				strokeWidth: 10,
				strokeDasharray: "40 60"
			}),
			/* @__PURE__ */ m("line", {
				x1: X.x - Z * b.halfWidth,
				y1: X.y - we * b.halfWidth,
				x2: X.x + Z * b.halfWidth,
				y2: X.y + we * b.halfWidth,
				stroke: "#b7f8fc",
				strokeWidth: 8,
				strokeDasharray: "24 15"
			}),
			/* @__PURE__ */ m("line", {
				x1: q.x - J * b.halfWidth,
				y1: q.y - Y * b.halfWidth,
				x2: q.x + J * b.halfWidth,
				y2: q.y + Y * b.halfWidth,
				stroke: "#ffffff",
				strokeWidth: 10
			}),
			/* @__PURE__ */ m("line", {
				x1: q.x - J * b.halfWidth,
				y1: q.y - Y * b.halfWidth,
				x2: q.x + J * b.halfWidth,
				y2: q.y + Y * b.halfWidth,
				stroke: "#1c1917",
				strokeWidth: 10,
				strokeDasharray: "16 16"
			}),
			b.buoys.map((e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
				cx: e.x,
				cy: e.y,
				r: 26,
				fill: "#f97316",
				stroke: "#ffffff",
				strokeWidth: 7
			}), /* @__PURE__ */ m("circle", {
				cx: e.x,
				cy: e.y,
				r: 26 * .45,
				fill: "#ffffff"
			})] }, t)),
			_.players.map((e) => /* @__PURE__ */ m("g", {
				opacity: e.out ? .25 : 1,
				children: e.trail.map((t, n) => /* @__PURE__ */ h("g", { children: [
					/* @__PURE__ */ m("polyline", {
						points: Nt(t),
						fill: "none",
						stroke: "#123e4d",
						strokeOpacity: .62,
						strokeWidth: 46,
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					/* @__PURE__ */ m("polyline", {
						points: Nt(t),
						fill: "none",
						stroke: F(e.rid),
						strokeOpacity: .95,
						strokeWidth: 41,
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					/* @__PURE__ */ m("polyline", {
						points: Nt(t),
						fill: "none",
						stroke: F(e.rid),
						strokeOpacity: .38,
						strokeWidth: 35,
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					O[t.t].cellT.map((r, i) => {
						let a = te(t, i), o = ye.get(e.rid)?.has(`${n}:${i}`) ?? !1;
						return /* @__PURE__ */ m("circle", {
							cx: a.x,
							cy: a.y,
							r: 5,
							fill: o ? "#78716c" : "#ffffff",
							stroke: o ? "#52636a" : F(e.rid),
							strokeWidth: 3
						}, i);
					})
				] }, n))
			}, e.rid)),
			_e.map((e, t) => /* @__PURE__ */ m("polyline", {
				points: Nt(e),
				fill: "none",
				stroke: "#ffffff",
				strokeOpacity: .85,
				strokeWidth: 35,
				strokeDasharray: "18 12",
				strokeLinecap: "round"
			}, t)),
			_.players.map((e) => {
				let t = P(e.trail, e.cell, e.ghost), n = t.h * 180 / Math.PI, r = F(e.rid);
				return /* @__PURE__ */ h("g", {
					transform: `translate(${t.x} ${t.y}) rotate(${n})`,
					opacity: e.out ? .3 : 1,
					children: [/* @__PURE__ */ m("path", {
						d: "M 30 0 L -18 -16 L -10 0 L -18 16 Z",
						fill: r,
						stroke: "#1c1917",
						strokeWidth: 3,
						strokeLinejoin: "round"
					}), /* @__PURE__ */ m("circle", {
						cx: 6,
						cy: 0,
						r: 7,
						fill: "#ffffff",
						stroke: "#1c1917",
						strokeWidth: 2.5
					})]
				}, e.rid);
			}),
			_.players.map((e) => {
				let t = P(e.trail, e.cell, e.ghost);
				return /* @__PURE__ */ m("text", {
					x: t.x,
					y: t.y + 46,
					textAnchor: "middle",
					fontSize: 26,
					fontWeight: 800,
					fill: F(e.rid),
					stroke: "#ffffff",
					strokeWidth: 6,
					paintOrder: "stroke",
					pointerEvents: "none",
					children: I(e.rid)
				}, e.rid);
			})
		]
	}), Ee = _.phase === "standby" && S, De = v.hand.reduce((e, t, n) => e + (k.includes(n) ? 0 : O[t].cells), 0), Oe = H && w && !_.relieved && v.hand.filter((e) => e === "E").length >= 2, ke = w && _.laneResult?.race === _.race && !_.laneResult.seen.includes(i), Ae = /* @__PURE__ */ h("div", {
		className: "ts-actions",
		children: [
			/* @__PURE__ */ h("div", {
				className: "tsp-hand-head",
				children: [/* @__PURE__ */ m("span", { children: y("games.tornadosplash.ui.hand") }), /* @__PURE__ */ m("small", { children: w ? y("games.tornadosplash.ui.deck", { n: _.deckCount }) : y("games.tornadosplash.ui.deck", { n: x?.deckCount ?? 0 }) })]
			}),
			/* @__PURE__ */ h("div", {
				className: "tsp-hand",
				children: [_.phase === "standby" ? v.hand.map((e, t) => {
					let n = k.includes(t);
					return /* @__PURE__ */ m("button", {
						type: "button",
						className: "tsp-hand-card",
						"aria-pressed": n,
						"aria-label": `${e} · ${y("games.tornadosplash.ui.cells", { n: O[e].cells })}`,
						disabled: !Ee,
						onClick: () => ne(n ? k.filter((e) => e !== t) : k.length < 5 ? [...k, t] : k),
						children: /* @__PURE__ */ m(At, { type: e })
					}, t);
				}) : v.hand.map((e, t) => {
					let n = v.hand.slice(0, t + 1).filter((t) => t === e).length, r = T.filter((t) => t.t === e).length;
					return /* @__PURE__ */ m("button", {
						type: "button",
						className: "tsp-hand-card",
						disabled: !be(e) || n <= r,
						"aria-label": `${e} · ${y("games.tornadosplash.ui.cells", { n: O[e].cells })}`,
						onClick: () => {
							E([...T, {
								t: e,
								m: 1
							}]), M(null);
						},
						children: /* @__PURE__ */ m(At, { type: e })
					}, t);
				}), Oe && /* @__PURE__ */ m("button", {
					type: "button",
					className: "ts-relief",
					onClick: () => g({ type: "relief" }),
					children: y("games.tornadosplash.ui.relief")
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "ts-buttons",
				children: _.phase === "standby" ? /* @__PURE__ */ m("button", {
					type: "button",
					className: "ts-confirm",
					disabled: !Ee || De < 3,
					onClick: () => {
						g({
							type: "bid",
							discard: k.map((e) => v.hand[e])
						}), ne([]);
					},
					children: y("games.tornadosplash.ui.bid", { n: k.length })
				}) : /* @__PURE__ */ h(p, { children: [
					!w && !C && x != null && /* @__PURE__ */ m("button", {
						type: "button",
						className: "ts-boost",
						"aria-pressed": D,
						"aria-label": y(x.boostUsed ? "games.tornadosplash.ui.boostUsed" : "games.tornadosplash.ui.boost"),
						disabled: !H || x.boostUsed,
						onClick: () => {
							ee(!D), E([]), M(null);
						},
						children: y(x.boostUsed ? "games.tornadosplash.ui.boostUsed" : "games.tornadosplash.ui.boostShort")
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "ts-rest",
						disabled: !H,
						onClick: () => {
							E([]), ee(!1), M(null), g({ type: "rest" });
						},
						children: y("games.tornadosplash.ui.restCompact")
					}),
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "ts-confirm",
						disabled: !xe,
						onClick: () => {
							g({
								type: "move",
								cards: T,
								...D ? { boost: !0 } : {}
							}), E([]), ee(!1), M(null);
						},
						children: [
							y(D ? "games.tornadosplash.ui.confirmBoost" : "games.tornadosplash.ui.confirm"),
							" · ",
							y("games.tornadosplash.ui.cells", { n: z })
						]
					})
				] })
			})
		]
	});
	return /* @__PURE__ */ h("div", {
		className: "ts-game",
		children: [/* @__PURE__ */ m(d, {
			adaptive: !0,
			className: "tsp-screen tsp-race-screen",
			scroll: !1,
			actionsHeight: "h-48",
			actions: Ae,
			banner: /* @__PURE__ */ m("div", {
				className: "ts-banner",
				children: /* @__PURE__ */ m(f, {
					tone: U,
					text: W,
					sub: G,
					chip: Ce,
					accent: L.accent
				})
			}),
			children: /* @__PURE__ */ h("div", {
				className: "ts-scene",
				children: [
					ue ? /* @__PURE__ */ m(Dt, {
						pub: _,
						preview: _e,
						myRid: i,
						members: n,
						mode: re,
						resetToken: ae
					}) : /* @__PURE__ */ m(u, {
						sheetW: b.bbox.w,
						sheetH: b.bbox.h,
						fitKey: `${_.track}:${_.race}`,
						readOnly: !0,
						children: Te
					}),
					ue && /* @__PURE__ */ m("button", {
						type: "button",
						className: "ts-camera-button",
						"aria-label": y(re === "follow" ? "games.tornadosplash.ui.switchToOverview" : "games.tornadosplash.ui.switchToFollow"),
						title: y(re === "follow" ? "games.tornadosplash.ui.switchToOverview" : "games.tornadosplash.ui.switchToFollow"),
						onClick: () => {
							ie(re === "follow" ? "overview" : "follow"), oe((e) => e + 1);
						},
						children: /* @__PURE__ */ m(s, {
							size: 24,
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ m("ol", {
						className: "ts-ranking",
						children: Se.map((e, t) => /* @__PURE__ */ h("li", {
							className: e.rid === i ? "ts-ranking-self" : "",
							children: [
								/* @__PURE__ */ m("span", {
									className: "ts-ranking-place",
									children: t + 1
								}),
								/* @__PURE__ */ m("span", {
									className: "ts-ranking-color",
									style: { backgroundColor: F(e.rid) }
								}),
								/* @__PURE__ */ m("span", {
									className: "ts-ranking-name",
									children: I(e.rid)
								})
							]
						}, e.rid))
					}),
					B && T.length > 0 && /* @__PURE__ */ m("div", {
						className: "ts-plan",
						children: /* @__PURE__ */ m("div", {
							className: "ts-plan-list",
							children: T.map((e, t) => /* @__PURE__ */ h("div", {
								className: "ts-plan-slot",
								children: [ce === t && /* @__PURE__ */ h("div", {
									className: "ts-plan-quick",
									children: [/* @__PURE__ */ m("button", {
										type: "button",
										"aria-label": y("games.tornadosplash.ui.mirror"),
										title: y("games.tornadosplash.ui.mirror"),
										onClick: () => E(T.map((e, n) => n === t ? {
											...e,
											m: e.m === 1 ? -1 : 1
										} : e)),
										children: /* @__PURE__ */ m(c, {
											size: 25,
											"aria-hidden": !0
										})
									}), /* @__PURE__ */ m("button", {
										type: "button",
										"aria-label": y("games.tornadosplash.ui.removeSegment"),
										title: y("games.tornadosplash.ui.removeSegment"),
										onClick: () => {
											E(T.filter((e, n) => n !== t)), M(null);
										},
										children: "×"
									})]
								}), /* @__PURE__ */ h("button", {
									type: "button",
									className: "ts-plan-item",
									"aria-pressed": ce === t,
									"aria-label": `${t + 1} · ${e.t} · ${y(e.m === 1 ? "games.tornadosplash.ui.left" : "games.tornadosplash.ui.right")}`,
									onClick: () => M(ce === t ? null : t),
									children: [
										/* @__PURE__ */ m("span", {
											className: "ts-card-number",
											children: t + 1
										}),
										/* @__PURE__ */ m("span", {
											className: "ts-card-type",
											children: e.t
										}),
										/* @__PURE__ */ m(At, {
											type: e.t,
											mirror: e.m
										})
									]
								})]
							}, t))
						})
					}),
					ve && /* @__PURE__ */ m("div", {
						className: "ts-plan-warning",
						children: y("games.tornadosplash.ui.blockedPreview")
					})
				]
			})
		}), ke && _.laneResult && /* @__PURE__ */ m("div", {
			className: "ts-lane-wash",
			children: /* @__PURE__ */ h("div", {
				className: "ts-lane-dialog",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "ts-lane-title",
				children: [
					/* @__PURE__ */ m("div", {
						className: "ts-lane-eyebrow",
						children: "STARTING LANES"
					}),
					/* @__PURE__ */ m("h2", {
						id: "ts-lane-title",
						children: y("games.tornadosplash.ui.laneResultTitle")
					}),
					/* @__PURE__ */ m("p", { children: y("games.tornadosplash.ui.laneResultHint") }),
					/* @__PURE__ */ m("ol", {
						className: "ts-lane-list",
						children: [..._.players].sort((e, t) => e.lane - t.lane).map((e) => /* @__PURE__ */ h("li", { children: [
							/* @__PURE__ */ m("span", {
								className: "ts-lane-number",
								children: e.lane + 1
							}),
							/* @__PURE__ */ h("span", {
								className: "ts-lane-player",
								children: [/* @__PURE__ */ m("i", { style: { backgroundColor: F(e.rid) } }), I(e.rid)]
							}),
							/* @__PURE__ */ m("span", {
								className: "ts-lane-bid",
								children: y("games.tornadosplash.ui.bidCount", { n: _.laneResult.bids[e.rid] ?? 0 })
							})
						] }, e.rid))
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "ts-lane-start",
						onClick: () => g({ type: "ackBidResult" }),
						children: y("games.tornadosplash.ui.startDepart")
					}),
					/* @__PURE__ */ m("small", { children: y("games.tornadosplash.ui.laneResultReady") })
				]
			})
		})]
	});
}
function Ft(e) {
	return e.public.phase === "choose" ? /* @__PURE__ */ m(kt, { ...e }) : /* @__PURE__ */ m(Pt, { ...e });
}
//#endregion
//#region src/games/tornadosplash/bot.ts
function It(e, t) {
	let n = se(e.track, e.courseLength), r = e.players.find((e) => e.rid === t);
	return {
		track: n,
		meP: r,
		attach: r.trail.length > 0 ? A(r.trail[r.trail.length - 1]) : r.ghost,
		obs: [...e.players.filter((e) => e.rid !== t && !e.out).map((e) => ({
			...P(e.trail, e.cell, e.ghost),
			r: 24
		})), ...n.buoys.map((e) => ({
			...e,
			r: 26
		}))]
	};
}
function Lt(e, t, n) {
	let r = e, i = [];
	for (let e of t) {
		let t = pe(r, e.t, e.m, n);
		if (!t) return null;
		i.push(t), r = A(t);
	}
	return {
		exit: r,
		placed: i
	};
}
function Rt(e, t, n, r, i) {
	let { track: a, meP: o, attach: s, obs: c } = It(e, t), l = [], u = Array(n.length).fill(!1), d = [], f = (e, t) => {
		let n = M(a, e.x, e.y, o.progress + t * 90), r = N(a, n.s), i = Math.cos(e.h - r.h), s = Math.abs(n.lat) - (a.halfWidth - 40), c = s > 0 ? (s / 40) ** 2 * 3 : 0;
		return i * 2 - c + t * .1 - d.length * .05;
	}, p = (e) => {
		if (e > 0 && (!i || e === r)) {
			let t = Lt(s, d, c);
			t && l.push({
				cards: [...d],
				score: f(t.exit, e),
				dist: e
			});
		}
		if (d.length >= 3 || e >= r) return;
		let t = /* @__PURE__ */ new Set();
		for (let i = 0; i < n.length; i += 1) {
			if (u[i]) continue;
			let a = n[i];
			if (t.has(a)) continue;
			t.add(a);
			let o = e + O[a].cells;
			if (!(o > r)) for (let e of [1, -1]) u[i] = !0, d.push({
				t: a,
				m: e
			}), p(o), d.pop(), u[i] = !1;
		}
	};
	return p(0), l;
}
var zt = (e, t) => {
	let { public: n, private: r } = e, i = r?.hand ?? [], a = t.rid, o = t.difficulty === "weak";
	if (n.phase === "choose") {
		if (n.turn !== a) return null;
		let e = new Set(n.players.map((e) => e.boat)), t = E.map((e, t) => t).filter((t) => !e.has(t));
		return { action: {
			type: "selectBoat",
			boat: o ? t[0] : t.reduce((e, t) => E[t].speed + E[t].turn > E[e].speed + E[e].turn ? t : e)
		} };
	}
	if (n.phase === "standby") {
		if (n.standby?.declarer !== a) return null;
		let e = i.reduce((e, t) => e + O[t].cells, 0), t = (n.players.find((e) => e.rid === a)?.lane ?? 0) >= Math.ceil(n.players.length / 2);
		if (o || !t) return { action: {
			type: "bid",
			discard: []
		} };
		let r = [
			"E",
			"D",
			"C"
		].find((t) => i.includes(t) && e - O[t].cells >= 3);
		return { action: {
			type: "bid",
			discard: r ? [r] : []
		} };
	}
	if (n.phase !== "race" && n.phase !== "start" || n.turn !== a) return null;
	let s = n.players.find((e) => e.rid === a);
	if (!s || s.finished || s.out) return null;
	let c = n.phase === "start", l = n.mode === "ts2", u = Rt(n, a, c ? i.filter((e) => e === "A" || e === "B") : i, 3, l);
	if (n.mode === "ts2" && u.length === 0 && !n.relieved && i.filter((e) => e === "E").length >= 2 && n.deckCount > 0) return { action: { type: "relief" } };
	if (u.length === 0) return { action: { type: "rest" } };
	let d = !1;
	if (n.mode === "retail" && !s.boostUsed && !c) {
		let e = Rt(n, a, i, 4, !1).filter((e) => e.dist === 4), t = Math.max(...u.map((e) => e.score)), r = e.length > 0 ? Math.max(...e.map((e) => e.score)) : -Infinity, o = Math.max(...n.players.filter((e) => !e.out && !e.finished).map((e) => e.progress));
		r > -Infinity && r >= t - .15 && s.progress < o - 50 && (u = e, d = !0);
	}
	return { action: {
		type: "move",
		cards: (o ? u[Math.floor(Math.random() * u.length)] : u.reduce((e, t) => t.score > e.score ? t : e)).cards,
		...d ? { boost: !0 } : {}
	} };
};
//#endregion
//#region src/games/tornadosplash/game-over.tsx
function Bt(e) {
	return /* @__PURE__ */ m("div", {
		className: "tsp-over",
		children: /* @__PURE__ */ m(x, {
			...e,
			accent: L.accent
		})
	});
}
//#endregion
//#region src/games/tornadosplash/options.tsx
function Vt({ value: e, onChange: t }) {
	let n = o(), r = V.safeParse(e), i = r.success ? r.data : V.parse(void 0);
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ h(C, {
				title: n("games.tornadosplash.opt.mode"),
				children: [/* @__PURE__ */ m(S, {
					name: "tornadosplash-mode",
					value: "retail",
					checked: i.mode === "retail",
					label: n("games.tornadosplash.opt.modeRetail"),
					accent: L.accent,
					onChange: () => t({
						...i,
						mode: "retail"
					})
				}), /* @__PURE__ */ m(S, {
					name: "tornadosplash-mode",
					value: "ts2",
					checked: i.mode === "ts2",
					label: n("games.tornadosplash.opt.modeTs2"),
					accent: L.accent,
					onChange: () => t({
						...i,
						mode: "ts2"
					})
				})]
			}),
			/* @__PURE__ */ m(C, {
				title: n("games.tornadosplash.opt.track"),
				columns: 3,
				children: [
					"oval",
					"tri",
					"diamond"
				].map((e) => /* @__PURE__ */ m(S, {
					name: "tornadosplash-track",
					value: e,
					checked: i.track === e,
					label: n(e === "oval" ? "games.tornadosplash.opt.trackOval" : e === "tri" ? "games.tornadosplash.opt.trackTri" : "games.tornadosplash.opt.trackDiamond"),
					accent: L.accent,
					onChange: () => t({
						...i,
						track: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(C, {
				title: n("games.tornadosplash.opt.courseLength"),
				columns: 3,
				children: [
					"short",
					"medium",
					"long"
				].map((e) => /* @__PURE__ */ m(S, {
					name: "tornadosplash-course-length",
					value: e,
					checked: i.courseLength === e,
					label: n(e === "short" ? "games.tornadosplash.opt.courseShort" : e === "medium" ? "games.tornadosplash.opt.courseMedium" : "games.tornadosplash.opt.courseLong"),
					accent: L.accent,
					onChange: () => t({
						...i,
						courseLength: e
					})
				}, e))
			}),
			i.mode === "retail" && /* @__PURE__ */ m(w, {
				checked: i.grandPrix,
				label: n("games.tornadosplash.opt.grandPrix"),
				accent: L.accent,
				onChange: () => t({
					...i,
					grandPrix: !i.grandPrix
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tornadosplash/entry.tsx
var Ht = {
	definition: Re,
	View: Ft,
	bot: zt,
	OverView: Bt,
	Options: Vt,
	locales: {
		zh: {
			name: "旋风赛艇",
			desc: "把走行卡铺成航迹,恰好三格地冲向终点",
			rules: "目标:驾驶赛艇绕浮标逆时针跑完一圈,最先冲过终点线。\n流程:\n· 零售版赛前依次选择未被选的赛艇,各艇有不同牌组与艇重。\n· 每回合把走行卡接到自己航迹末端,然后赛艇恰好前进 3 格。\n· 卡的格数即步数:A/B/C 为 1 格,D 为 2 格,E 为 3 格;所放卡的总格数必须等于前进格数。\n· 卡可压在其他卡上;会碰到其他赛艇或浮标的放法会自动微调避让,避不开则该放法不可行。\n· 其他赛艇的卡盖住你的航迹格点时,该格视为不存在,前进时自动跳过。\n· A/B 卡可左右微调 15 度,C/D/E 卡转弯 30/45/60 度,可镜像换向。\n零售版规则:\n· 每轮按名次补牌:第一名补到 4 张,中间名次补到 5 张,最后一名补到 6 张。\n· 每局游戏可使用一次加速:当回合最多前进 4 格。\n· 可主动只前进 0 至 2 格等待;驶出水路边界立即淘汰。\n· 大奖赛模式进行 3 场比赛,按名次获得 5、3、2 分,最后一名不得分,被淘汰者并列最后一名;总分最高者获胜。\nTS2 同人版规则:\n· 开局待机行动:从外道起依次从手牌弃 0 至 5 张,弃牌多者换到内道,须至少保留 3 格。\n· 出发阶段只能使用 A/B 直线卡,恰好前进 3 格;之后行动至多补 3 张,手牌上限 6 张。\n· 手牌有两张 E 时,每回合可弃置 2 张 E 并从牌山抽 1 张。\n· 预选赛结束后按名次重排车道进行优胜战,优胜战的冠军即游戏冠军。",
			boat: {
				ika: "雷霆乌贼",
				flyfin: "裂浪飞鳍",
				shark: "狂鲨利刃",
				harisen: "铁甲河豚",
				ashika: "海狮狂飙",
				kame: "玄甲海龟"
			},
			opt: {
				mode: "规则版本",
				modeRetail: "零售版(2-5 人)",
				modeTs2: "TS2 同人版(2-6 人)",
				track: "赛道",
				trackOval: "椭圆环道",
				trackTri: "三角环道",
				trackDiamond: "菱形环道",
				courseLength: "赛程长度",
				courseShort: "短",
				courseMedium: "中",
				courseLong: "长",
				grandPrix: "大奖赛(3 场积分)"
			},
			phase: {
				choose: "选择赛艇",
				standby: "待机行动",
				start: "出发",
				race: "比赛",
				done: "结束"
			},
			race: {
				qualifier: "预选赛",
				final: "优胜战",
				grandPrix: "第 {{n}} 场 / 共 3 场",
				single: "单场"
			},
			ui: {
				yourChoose: "轮到你选择赛艇",
				waitChoose: "等待 {{name}} 选择赛艇",
				chooseHint: "每人一艘，不重复",
				chooseBoat: "确认选择赛艇",
				selectedBoat: "已选择赛艇，等待其他玩家",
				boatTaken: "{{name}} 已选",
				boatSpeed: "速度",
				boatTurn: "过弯",
				boatDeck: "专属走行卡 20 张",
				laneResultTitle: "竞道结果",
				laneResultHint: "从 1 号内道到外道 · 平手按原顺序",
				laneResultReady: "各艇已就位，准备出发",
				startDepart: "开始出发",
				switchToFollow: "切换到跟拍视角",
				switchToOverview: "切换到全景视角",
				yourMove: "轮到你了:铺卡前进",
				yourStart: "出发:只能用直线卡,恰好 3 格",
				waitMove: "等待 {{name}} 行动",
				yourBid: "待机行动:宣言弃牌抢内道",
				waitBid: "等待 {{name}} 宣言弃牌",
				confirm: "确认放置",
				confirmBoost: "确认加速",
				rest: "本回合休息",
				restCompact: "本回合休息",
				relief: "弃两张 E 换一张",
				boost: "加速(4 格)",
				boostShort: "加速",
				camera: "视角",
				follow: "跟拍",
				overview: "全景",
				rank: "第 {{n}} / {{total}} 名",
				left: "左转",
				right: "右转",
				removeSegment: "撤销该段",
				bid: "宣言弃 {{n}} 张",
				bidHint: "弃 0 至 5 张,多者进内道;至少保留 3 格",
				undo: "撤销一张",
				clear: "清空",
				planCells: "已铺 {{n}} 格",
				needThree: "需要恰好 3 格",
				blockedPreview: "前方放不下:会碰到赛艇或浮标",
				mirror: "换向",
				hand: "手牌",
				deck: "牌山 {{n}}",
				handCount: "手牌 {{n}}",
				finishedRank: "第 {{n}} 名",
				out: "已淘汰",
				boostUsed: "加速已用",
				cells: "{{n}} 格",
				points: "{{n}} 分",
				lane: "{{n}} 号道",
				bidCount: "弃 {{n}} 张"
			},
			err: {
				notTurn: "还没轮到你",
				badPhase: "当前阶段不能这样操作",
				cardsNotInHand: "手牌里没有这些卡",
				mustThree: "必须恰好铺出 3 格",
				tooMany: "铺太多了:本回合最多 3 格(加速 4 格)",
				straightOnly: "出发阶段只能使用直线卡",
				blocked: "这里会碰到其他赛艇或浮标",
				boostUsed: "本局游戏的加速已经用过了",
				noRest: "还有合法走法,不能休息",
				reliefNoE: "需要手牌里有两张 E",
				deckEmpty: "牌山已经空了",
				bidCells: "至少要保留能走 3 格的手牌",
				boatTaken: "这艘赛艇已经被选走"
			}
		},
		en: {
			name: "Tornado Splash",
			desc: "Lay cards into a wake and sprint to the finish, exactly three cells at a time",
			rules: "Goal: Race counterclockwise around the buoys and be the first to cross the finish line.\nPlay:\n· Before a retail race, players each choose one unclaimed boat. Boats have different decks and weights.\n· Each turn, append movement cards to the end of your wake, then advance your boat exactly 3 cells.\n· A card's cells are its steps: A/B/C give 1, D gives 2, E gives 3; the cards you play must total exactly the distance moved.\n· Cards may overlap other cards; a placement that would hit another boat or buoy is automatically nudged aside, and only fails if no nudge fits.\n· If another boat's card covers a cell on your wake, that cell does not exist and is skipped when advancing.\n· A/B curve 15 degrees either way; C/D/E curve 30/45/60 degrees and can be mirrored.\nRetail rules:\n· Each round, refill by rank: 1st place to 4 cards, middle ranks to 5, last place to 6.\n· Once per game, boost: move up to 4 cells that turn.\n· You may voluntarily move only 0-2 cells to wait; leaving the waterway eliminates you.\n· Grand Prix mode: 3 races, ranks score 5/3/2 points, last place and eliminated boats score nothing; highest total wins.\nTS2 edition rules:\n· Opening standby: from the outside lane in, discard 0-5 cards from hand; the biggest discarder takes the inside lane. Keep at least 3 cells.\n· At the start, play only straight A/B cards and advance exactly 3 cells; afterwards draw up to 3 cards, hand limit 6.\n· With two E cards in hand, once per turn you may discard both to draw 1.\n· After the qualifying race, lanes reset by rank for the final; the final's winner wins the game.",
			boat: {
				ika: "Thunder Squid",
				flyfin: "Wavebreaker Fin",
				shark: "Razor Shark",
				harisen: "Iron Puffer",
				ashika: "Storm Seal",
				kame: "Armored Turtle"
			},
			opt: {
				mode: "Ruleset",
				modeRetail: "Retail (2-5 players)",
				modeTs2: "TS2 edition (2-6 players)",
				track: "Track",
				trackOval: "Oval circuit",
				trackTri: "Triangle circuit",
				trackDiamond: "Diamond circuit",
				courseLength: "Course length",
				courseShort: "Short",
				courseMedium: "Medium",
				courseLong: "Long",
				grandPrix: "Grand Prix (3 races)"
			},
			phase: {
				choose: "Choose your boat",
				standby: "Standby",
				start: "Start",
				race: "Race",
				done: "Done"
			},
			race: {
				qualifier: "Qualifier",
				final: "Final",
				grandPrix: "Race {{n}} of 3",
				single: "Single race"
			},
			ui: {
				yourChoose: "Choose your racing boat",
				waitChoose: "Waiting for {{name}} to choose a boat",
				chooseHint: "One unique boat per player",
				chooseBoat: "Confirm boat",
				selectedBoat: "Boat selected. Waiting for other players",
				boatTaken: "Chosen by {{name}}",
				boatSpeed: "Speed",
				boatTurn: "Turning",
				boatDeck: "20 unique movement cards",
				laneResultTitle: "Starting lanes",
				laneResultHint: "Lane 1 is inside · Ties keep their order",
				laneResultReady: "All boats are in position",
				startDepart: "Start racing",
				switchToFollow: "Switch to follow camera",
				switchToOverview: "Switch to overview camera",
				yourMove: "Your turn: lay cards and advance",
				yourStart: "Start: straight cards only, exactly 3 cells",
				waitMove: "Waiting for {{name}}",
				yourBid: "Standby: declare discards for the inside lane",
				waitBid: "Waiting for {{name}} to declare",
				confirm: "Confirm",
				confirmBoost: "Boost move",
				rest: "Rest this turn",
				restCompact: "Rest turn",
				relief: "Discard two E to draw one",
				boost: "Boost (4 cells)",
				boostShort: "Boost",
				camera: "Camera",
				follow: "Follow",
				overview: "Overview",
				rank: "Rank {{n}} / {{total}}",
				left: "Turn left",
				right: "Turn right",
				removeSegment: "Remove segment",
				bid: "Bid {{n}} discards",
				bidHint: "Discard 0-5; most discards takes the inside lane. Keep at least 3 cells",
				undo: "Undo one",
				clear: "Clear",
				planCells: "{{n}} cells laid",
				needThree: "Exactly 3 cells required",
				blockedPreview: "No room ahead: would hit a boat or buoy",
				mirror: "Mirror",
				hand: "Hand",
				deck: "Deck {{n}}",
				handCount: "Hand {{n}}",
				finishedRank: "Finished #{{n}}",
				out: "Eliminated",
				boostUsed: "Boost used",
				cells: "{{n}} cells",
				points: "{{n}} pts",
				lane: "Lane {{n}}",
				bidCount: "Bid {{n}}"
			},
			err: {
				notTurn: "Not your turn yet",
				badPhase: "Cannot do that in this phase",
				cardsNotInHand: "Those cards are not in your hand",
				mustThree: "You must lay out exactly 3 cells",
				tooMany: "Too many cells: at most 3 this turn (4 with boost)",
				straightOnly: "Only straight cards may be played at the start",
				blocked: "That would hit another boat or a buoy",
				boostUsed: "Boost already used this game",
				noRest: "A legal move exists; you cannot rest",
				reliefNoE: "You need two E cards in hand",
				deckEmpty: "The deck is empty",
				bidCells: "You must keep at least 3 cells in hand",
				boatTaken: "This boat has already been chosen"
			}
		}
	}
};
//#endregion
export { Ht as default };
