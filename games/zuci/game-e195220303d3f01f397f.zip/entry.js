import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { Texture as o } from "@bgparty/sdk/texture";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as c } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as l } from "@bgparty/sdk/ui/player-strip";
import { jsx as u, jsxs as d } from "react/jsx-runtime";
import { GameOverScreen as f } from "@bgparty/sdk/ui/game-over-screen";
//#endregion
//#region src/games/zuci/cards.ts
var p = [
	[
		"女",
		"儿",
		"孩",
		"子"
	],
	[
		"看",
		"见",
		"来",
		"到"
	],
	[
		"真",
		"正",
		"的",
		"确"
	],
	[
		"真",
		"实",
		"正",
		"在"
	],
	[
		"大",
		"人",
		"学",
		"生"
	],
	[
		"意",
		"见",
		"外",
		"面"
	],
	[
		"之",
		"后",
		"前",
		"面"
	],
	[
		"以",
		"前",
		"后",
		"面"
	],
	[
		"手",
		"里",
		"上",
		"面"
	],
	[
		"地",
		"方",
		"上",
		"面"
	],
	[
		"美",
		"好",
		"女",
		"人"
	],
	[
		"难",
		"以",
		"过",
		"来"
	],
	[
		"女",
		"人",
		"生",
		"物"
	],
	[
		"去",
		"世",
		"年",
		"纪"
	],
	[
		"实",
		"现",
		"在",
		"场"
	],
	[
		"大",
		"学",
		"约",
		"会"
	],
	[
		"放",
		"心",
		"手",
		"里"
	],
	[
		"退",
		"后",
		"出",
		"来"
	],
	[
		"当",
		"作",
		"成",
		"为"
	],
	[
		"提",
		"醒",
		"出",
		"来"
	],
	[
		"男",
		"人",
		"生",
		"物"
	],
	[
		"作",
		"家",
		"证",
		"人"
	],
	[
		"提",
		"醒",
		"到",
		"来"
	],
	[
		"想",
		"到",
		"起",
		"来"
	],
	[
		"当",
		"中",
		"时",
		"间"
	],
	[
		"头",
		"儿",
		"脑",
		"子"
	],
	[
		"反",
		"对",
		"应",
		"付"
	],
	[
		"动",
		"物",
		"作",
		"品"
	],
	[
		"地",
		"下",
		"方",
		"面"
	],
	[
		"地",
		"下",
		"上",
		"去"
	],
	[
		"发",
		"出",
		"表",
		"现"
	],
	[
		"发",
		"展",
		"表",
		"示"
	],
	[
		"发",
		"出",
		"展",
		"现"
	],
	[
		"楼",
		"上",
		"下",
		"去"
	],
	[
		"楼",
		"上",
		"下",
		"次"
	],
	[
		"罪",
		"名",
		"犯",
		"人"
	],
	[
		"大",
		"人",
		"哥",
		"们"
	],
	[
		"手",
		"上",
		"中",
		"尉"
	],
	[
		"放",
		"心",
		"手",
		"中"
	],
	[
		"天",
		"空",
		"生",
		"气"
	],
	[
		"相",
		"信",
		"关",
		"心"
	],
	[
		"交",
		"谈",
		"通",
		"话"
	],
	[
		"以",
		"下",
		"后",
		"来"
	],
	[
		"相",
		"信",
		"当",
		"心"
	],
	[
		"相",
		"关",
		"当",
		"心"
	],
	[
		"明",
		"早",
		"晚",
		"上"
	],
	[
		"明",
		"早",
		"晚",
		"餐"
	],
	[
		"做",
		"到",
		"好",
		"处"
	],
	[
		"做",
		"好",
		"出",
		"事"
	],
	[
		"晚",
		"会",
		"点",
		"儿"
	],
	[
		"之",
		"下",
		"外",
		"面"
	],
	[
		"大",
		"家",
		"夫",
		"人"
	],
	[
		"全",
		"部",
		"球",
		"队"
	],
	[
		"大",
		"事",
		"会",
		"儿"
	],
	[
		"心",
		"情",
		"灵",
		"感"
	],
	[
		"老",
		"大",
		"头",
		"脑"
	],
	[
		"假",
		"装",
		"设",
		"备"
	],
	[
		"行",
		"动",
		"事",
		"物"
	],
	[
		"老",
		"大",
		"人",
		"家"
	],
	[
		"老",
		"人",
		"天",
		"生"
	],
	[
		"分",
		"手",
		"开",
		"枪"
	],
	[
		"工",
		"作",
		"人",
		"家"
	],
	[
		"调",
		"查",
		"整",
		"理"
	],
	[
		"好",
		"受",
		"看",
		"到"
	],
	[
		"相",
		"同",
		"爱",
		"情"
	],
	[
		"地",
		"盘",
		"点",
		"子"
	],
	[
		"以",
		"上",
		"下",
		"午"
	],
	[
		"收",
		"看",
		"回",
		"来"
	],
	[
		"收",
		"看",
		"回",
		"到"
	],
	[
		"做",
		"出",
		"法",
		"庭"
	],
	[
		"怪",
		"物",
		"人",
		"质"
	],
	[
		"手",
		"表",
		"指",
		"示"
	],
	[
		"热",
		"情",
		"爱",
		"人"
	],
	[
		"小",
		"事",
		"孩",
		"儿"
	],
	[
		"小",
		"事",
		"心",
		"情"
	],
	[
		"全",
		"体",
		"国",
		"会"
	],
	[
		"法",
		"医",
		"律",
		"师"
	],
	[
		"路",
		"过",
		"上",
		"来"
	],
	[
		"工",
		"具",
		"人",
		"体"
	],
	[
		"专",
		"心",
		"家",
		"里"
	],
	[
		"地",
		"盘",
		"位",
		"子"
	],
	[
		"地",
		"点",
		"位",
		"子"
	],
	[
		"军",
		"队",
		"人",
		"员"
	],
	[
		"卡",
		"车",
		"片",
		"子"
	],
	[
		"退",
		"后",
		"出",
		"门"
	],
	[
		"作",
		"出",
		"战",
		"场"
	],
	[
		"遭",
		"遇",
		"受",
		"到"
	],
	[
		"生",
		"气",
		"意",
		"味"
	],
	[
		"对",
		"手",
		"方",
		"法"
	],
	[
		"爱",
		"好",
		"情",
		"人"
	],
	[
		"小",
		"孩",
		"屋",
		"子"
	],
	[
		"全",
		"家",
		"部",
		"长"
	],
	[
		"认",
		"罪",
		"出",
		"名"
	],
	[
		"公",
		"车",
		"路",
		"上"
	],
	[
		"昨",
		"天",
		"晚",
		"上"
	],
	[
		"回",
		"报",
		"复",
		"仇"
	],
	[
		"白",
		"天",
		"人",
		"才"
	],
	[
		"逃",
		"走",
		"离",
		"开"
	],
	[
		"假",
		"装",
		"设",
		"置"
	],
	[
		"当",
		"时",
		"年",
		"代"
	],
	[
		"出",
		"局",
		"场",
		"面"
	],
	[
		"机",
		"会",
		"场",
		"面"
	],
	[
		"回",
		"报",
		"答",
		"应"
	],
	[
		"时",
		"期",
		"空",
		"间"
	],
	[
		"制",
		"服",
		"作",
		"用"
	],
	[
		"放",
		"学",
		"开",
		"会"
	],
	[
		"回",
		"见",
		"来",
		"到"
	],
	[
		"全",
		"家",
		"面",
		"具"
	],
	[
		"服",
		"从",
		"用",
		"来"
	],
	[
		"超",
		"人",
		"市",
		"民"
	],
	[
		"美",
		"女",
		"金",
		"子"
	],
	[
		"双",
		"方",
		"手",
		"法"
	],
	[
		"小",
		"说",
		"声",
		"明"
	],
	[
		"解",
		"开",
		"释",
		"放"
	],
	[
		"下",
		"降",
		"来",
		"临"
	],
	[
		"好",
		"笑",
		"听",
		"话"
	],
	[
		"好",
		"听",
		"看",
		"见"
	],
	[
		"完",
		"毕",
		"事",
		"业"
	],
	[
		"共",
		"事",
		"同",
		"情"
	],
	[
		"有",
		"名",
		"意",
		"义"
	]
], m = {
	id: "zuci",
	tier: "released",
	mechanics: ["word-association"],
	interactionTags: [],
	nameKey: "games.zuci.name",
	descKey: "games.zuci.desc",
	rulesKey: "games.zuci.rules",
	icon: "✍️",
	iconImg: "games/zuci.webp",
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [],
	accent: "#0f766e",
	releasedAt: "2026-09-14",
	search: {
		py: "zu ci cheng yu",
		init: "zccy"
	},
	hotseat: "cover"
}, h = t.string().regex(/^\p{Script=Han}$/u), g = t.int().min(0).max(3), _ = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("hint"),
		char: h,
		target: g
	}),
	t.object({
		type: t.literal("answer"),
		char: h
	}),
	t.object({ type: t.literal("pass") }),
	t.object({ type: t.literal("endGuessing") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), v = t.string(), y = t.object({
	char: h,
	target: g
}), b = t.object({
	rid: v,
	char: h,
	gain: t.int().nonnegative()
}), x = t.object({
	phase: t.enum([
		"hint",
		"guess",
		"reveal",
		"roundEnd",
		"done"
	]),
	round: t.int().min(0),
	totalRounds: t.int().min(1),
	players: t.array(v),
	hintGiver: v,
	grid: t.tuple([
		h.nullable(),
		h.nullable(),
		h.nullable(),
		h.nullable()
	]),
	hints: t.array(y),
	hintsLeft: t.int().nonnegative(),
	scores: t.record(v, t.int().nonnegative()),
	submitted: t.array(v),
	firstAnswerRid: v.nullable(),
	guessStarted: t.boolean(),
	reveal: t.array(b).nullable(),
	roundBonus: t.int().nonnegative().nullable()
}), S = t.object({
	cardChars: t.tuple([
		h,
		h,
		h,
		h
	]).nullable(),
	myAnswer: h.nullable(),
	myPassed: t.boolean()
}), C = 3500, w = 4500, T = (e) => e.players[Math.min(e.round, e.players.length - 1)], E = (e) => p[e.deck[Math.min(e.round, e.deck.length - 1)]], D = (e) => e.players.length - 1, O = (e) => Object.keys(e.answers).length + e.passed.length, k = (e) => e.guessed.filter((e) => !e).length;
function A(t, n, r) {
	let i = Array.from({ length: p.length }, (e, t) => t), a = 0;
	for (let t = i.length - 1; t > 0; --t) {
		let n = e(r, a, t + 1);
		a += 1, [i[t], i[n]] = [i[n], i[t]];
	}
	let o = {};
	for (let e of n) o[e] = 0;
	return { state: {
		players: n,
		round: 0,
		deck: i,
		guessed: [
			!1,
			!1,
			!1,
			!1
		],
		hints: [],
		answers: {},
		passed: [],
		firstAnswerRid: null,
		guessStartedAt: null,
		reveal: null,
		roundBonus: null,
		scores: o,
		phase: "hint"
	} };
}
function j(e) {
	let t = E(e), n = /* @__PURE__ */ new Map(), r = [];
	for (let [i, a] of Object.entries(e.answers)) {
		let o = e.guessed.some((e, n) => !e && t[n] === a) ? t.findIndex((t, n) => !e.guessed[n] && t === a) : -1, s = 0;
		o >= 0 && (s = 1, i === e.firstAnswerRid && (s += 1), n.has(o) || n.set(o, []), n.get(o).push(i)), r.push({
			rid: i,
			char: a,
			gain: s
		});
	}
	for (let e of n.values()) if (e.length === 1) {
		let t = r.find((t) => t.rid === e[0]);
		t && (t.gain += 1);
	}
	for (let [t] of n) e.guessed[t] = !0;
	for (let t of r) e.scores[t.rid] += t.gain;
	e.reveal = r, e.phase = "reveal";
}
function M(e) {
	if (k(e) > 0 && e.hints.length < 16) {
		e.phase = "hint";
		return;
	}
	let t = k(e) === 0 ? 1 + (16 - e.hints.length) : 0;
	e.scores[T(e)] += t, e.roundBonus = t, e.phase = "roundEnd";
}
function N(e) {
	if (e.round += 1, e.round >= e.players.length) {
		e.phase = "done";
		return;
	}
	e.guessed = [
		!1,
		!1,
		!1,
		!1
	], e.hints = [], e.answers = {}, e.passed = [], e.firstAnswerRid = null, e.guessStartedAt = null, e.reveal = null, e.roundBonus = null, e.phase = "hint";
}
function P(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "guess") {
			if (Object.keys(e.answers).length > 0 && e.guessStartedAt === null) {
				let n = structuredClone(e);
				return n.guessStartedAt = t.now, {
					state: n,
					fx: []
				};
			}
			if (e.guessStartedAt !== null && t.now - e.guessStartedAt >= 6e4) {
				let t = structuredClone(e);
				return j(t), {
					state: t,
					fx: []
				};
			}
			return {
				state: e,
				fx: []
			};
		}
		if (e.phase === "reveal") {
			let t = structuredClone(e);
			return M(t), {
				state: t,
				fx: []
			};
		}
		if (e.phase === "roundEnd") {
			let t = structuredClone(e);
			return N(t), {
				state: t,
				fx: []
			};
		}
		return {
			state: e,
			fx: []
		};
	}
	if (t.type === "hint") {
		if (e.phase !== "hint" || n.by !== T(e)) return { code: "games.zuci.errNotHintGiver" };
		if (E(e).includes(t.char)) return { code: "games.zuci.errCharOnCard" };
		if (e.hints.some((e) => e.char === t.char)) return { code: "games.zuci.errCharUsed" };
		if (e.guessed[t.target]) return { code: "games.zuci.errTargetGuessed" };
		let r = e.hints[e.hints.length - 1];
		if (r && r.target === t.target && k(e) > 1) return { code: "games.zuci.errSameTarget" };
		let i = structuredClone(e);
		return i.hints.push({
			char: t.char,
			target: t.target
		}), i.answers = {}, i.passed = [], i.firstAnswerRid = null, i.guessStartedAt = null, i.reveal = null, i.phase = "guess", {
			state: i,
			fx: []
		};
	}
	if (t.type === "answer" || t.type === "pass") {
		if (e.phase !== "guess") return { code: "games.zuci.errNotGuessing" };
		if (n.by === T(e)) return { code: "games.zuci.errNotGuesser" };
		if (n.by in e.answers || e.passed.includes(n.by)) return { code: "games.zuci.errAlreadyAnswered" };
		let r = structuredClone(e);
		return t.type === "answer" ? (r.answers[n.by] = t.char, r.firstAnswerRid === null && (r.firstAnswerRid = n.by)) : r.passed.push(n.by), O(r) === D(r) && j(r), {
			state: r,
			fx: []
		};
	}
	if (e.phase !== "guess" || n.by !== T(e)) return { code: "games.zuci.errNotHintGiver" };
	let r = structuredClone(e);
	return j(r), {
		state: r,
		fx: []
	};
}
function F(e, t) {
	let n = E(e), r = e.phase === "roundEnd" || e.phase === "done";
	return {
		public: {
			phase: e.phase,
			round: e.round,
			totalRounds: e.players.length,
			players: [...e.players],
			hintGiver: T(e),
			grid: n.map((t, n) => r || e.guessed[n] ? t : null),
			hints: e.hints,
			hintsLeft: 16 - e.hints.length,
			scores: e.scores,
			submitted: [...Object.keys(e.answers), ...e.passed],
			firstAnswerRid: e.firstAnswerRid,
			guessStarted: Object.keys(e.answers).length > 0,
			reveal: e.reveal,
			roundBonus: e.roundBonus
		},
		private: {
			cardChars: t === T(e) ? [...n] : null,
			myAnswer: e.answers[t] ?? null,
			myPassed: e.passed.includes(t)
		}
	};
}
function I(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.scores[t] === n),
		ranking: t,
		scores: { ...e.scores }
	};
}
function L(e, t) {
	return e.phase === "guess" && Object.keys(e.answers).length > 0 ? e.guessStartedAt === null ? 0 : e.guessStartedAt + 6e4 - t : e.phase === "reveal" ? C : e.phase === "roundEnd" ? w : null;
}
var R = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: m,
	schemas: {
		action: _,
		publicView: x,
		privateView: S
	},
	setup: A,
	reduce: P,
	viewFor: F,
	status: I,
	nextTickIn: L
}, z = [
	"①",
	"②",
	"③",
	"④"
], B = /^\p{Script=Han}$/u, V = [
	{
		corner: "row-start-1 col-start-1",
		edge: "row-start-1 col-start-2",
		side: "row-start-2 col-start-1"
	},
	{
		corner: "row-start-1 col-start-4",
		edge: "row-start-1 col-start-3",
		side: "row-start-2 col-start-4"
	},
	{
		corner: "row-start-4 col-start-1",
		edge: "row-start-4 col-start-2",
		side: "row-start-3 col-start-1"
	},
	{
		corner: "row-start-4 col-start-4",
		edge: "row-start-4 col-start-3",
		side: "row-start-3 col-start-4"
	}
], H = [
	"row-start-2 col-start-2",
	"row-start-2 col-start-3",
	"row-start-3 col-start-2",
	"row-start-3 col-start-3"
];
function U(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ u(W, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function W({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let o = a(), f = (e) => n.find((t) => t.rid === e)?.name ?? e, p = e.hintGiver === r, h = e.players.map((e) => n.find((t) => t.rid === e)).filter((e) => e !== void 0), g = (t?.myAnswer ?? null) !== null || (t?.myPassed ?? !1), _, v;
	return e.phase === "hint" ? (_ = p ? "accent" : "info", v = p ? o("games.zuci.hintPrompt") : o("games.zuci.hintWaiting", { name: f(e.hintGiver) })) : e.phase === "guess" ? p ? (_ = "info", v = o("games.zuci.hintWatch")) : g ? (_ = "info", v = t?.myPassed ? o("games.zuci.guessPassed") : o("games.zuci.guessSubmitted")) : (_ = "accent", v = o("games.zuci.guessPrompt")) : e.phase === "reveal" ? (_ = "done", v = o("games.zuci.revealTitle")) : (_ = "done", v = o("games.zuci.roundEndTitle")), /* @__PURE__ */ u(s, {
		adaptive: !0,
		scroll: !1,
		className: "zuci-screen",
		banner: /* @__PURE__ */ u(c, {
			tone: _,
			text: v,
			chip: o("games.zuci.roundShort", {
				n: e.round + 1,
				total: e.totalRounds
			}),
			accent: m.accent
		}),
		children: /* @__PURE__ */ d("div", {
			className: "zuci-layout",
			children: [/* @__PURE__ */ u(G, {
				pub: e,
				priv: t,
				nameOf: f
			}), /* @__PURE__ */ d("div", {
				className: "zuci-sidebar",
				children: [/* @__PURE__ */ u("div", {
					className: "zuci-players",
					children: /* @__PURE__ */ u(l, {
						variant: "plate",
						members: h,
						myRid: r,
						status: (t) => /* @__PURE__ */ d("span", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ u("span", {
								className: "zuci-score rounded-md border-2 border-ink bg-surface px-1 font-mono text-xs leading-4 font-bold tabular-nums",
								children: o("games.zuci.scoreChip", { n: e.scores[t] ?? 0 })
							}), t === e.firstAnswerRid && (e.phase === "guess" || e.phase === "reveal") && /* @__PURE__ */ u("span", {
								role: "img",
								"aria-label": o("games.zuci.hourglassAria"),
								children: "⏳"
							})]
						}),
						action: (t) => e.phase !== "guess" || t === e.hintGiver ? null : e.submitted.includes(t) ? "done" : "pending"
					})
				}), /* @__PURE__ */ u("div", {
					className: "zuci-actions",
					children: /* @__PURE__ */ u(q, {
						pub: e,
						isHintGiver: p,
						mySubmitted: g,
						send: i
					}, `${e.round}:${e.hints.length}:${e.phase}`)
				})]
			})]
		})
	});
}
function G({ pub: e, priv: t, nameOf: r }) {
	let i = a(), s = e.phase === "reveal" || e.phase === "roundEnd";
	return /* @__PURE__ */ d("div", {
		className: "zuci-board frame relative min-h-0 overflow-hidden",
		children: [
			/* @__PURE__ */ u(o, {
				kind: "sheen",
				base: "#e9f3f1",
				className: "absolute inset-0 size-full"
			}),
			/* @__PURE__ */ u("span", {
				className: "zuci-hints-left rounded-md border-2 border-ink bg-surface px-1.5 py-0.5 font-mono text-xs font-bold tabular-nums opacity-80",
				children: i("games.zuci.hintsLeft", { n: e.hintsLeft })
			}),
			/* @__PURE__ */ u("div", {
				className: "zuci-board-scroll",
				children: /* @__PURE__ */ d("div", {
					className: "zuci-table relative grid flex-none items-center justify-items-center",
					children: [e.grid.map((t, r) => {
						let i = e.hints.map((e, t) => ({
							char: e.char,
							target: e.target,
							j: t
						})).filter((e) => e.target === r), a = [
							i.filter((e, t) => t % 3 == 0),
							i.filter((e, t) => t % 3 == 1),
							i.filter((e, t) => t % 3 == 2)
						], o = V[r], s = t === null ? "" : "opacity-40";
						return /* @__PURE__ */ d(n, { children: [
							/* @__PURE__ */ u("div", {
								className: `${o.edge} zuci-hints-edge flex flex-wrap items-center justify-center ${s}`,
								children: a[0].map((e) => /* @__PURE__ */ u(K, { char: e.char }, e.j))
							}),
							/* @__PURE__ */ u("div", {
								className: `${o.side} zuci-hints-side flex flex-col flex-wrap items-center justify-center ${s}`,
								children: a[1].map((e) => /* @__PURE__ */ u(K, { char: e.char }, e.j))
							}),
							/* @__PURE__ */ u("div", {
								className: `${o.corner} zuci-hints-corner flex flex-wrap items-center justify-center ${s}`,
								children: a[2].map((e) => /* @__PURE__ */ u(K, { char: e.char }, e.j))
							})
						] }, r);
					}), e.grid.map((e, n) => {
						let r = e === null && t?.cardChars ? t.cardChars[n] : null;
						return /* @__PURE__ */ d("div", {
							className: `${H[n]} zuci-cell relative grid place-items-center rounded-md border-2 border-ink bg-surface`,
							children: [e === null ? r === null ? /* @__PURE__ */ u("span", {
								className: "zuci-slot font-display leading-none font-extrabold opacity-30",
								children: z[n]
							}) : /* @__PURE__ */ u("span", {
								className: "zuci-character font-display leading-none font-extrabold opacity-35",
								children: r
							}) : /* @__PURE__ */ u("span", {
								className: "zuci-character font-display leading-none font-extrabold",
								children: e
							}), e === null && r !== null && /* @__PURE__ */ u("span", {
								className: "zuci-slot-label absolute top-0.5 left-1 text-xs font-extrabold opacity-60",
								children: z[n]
							})]
						}, n);
					})]
				})
			}),
			/* @__PURE__ */ u("div", {
				className: "zuci-reveal",
				children: s && e.reveal && /* @__PURE__ */ d("div", {
					className: "flex flex-wrap items-center justify-center gap-1.5",
					children: [e.reveal.length === 0 || e.reveal.every((e) => e.gain === 0) ? /* @__PURE__ */ u("span", {
						className: "text-sm font-bold opacity-70",
						children: i("games.zuci.noHits")
					}) : e.reveal.filter((e) => e.gain > 0).map((e) => /* @__PURE__ */ d("span", {
						className: "rounded-lg border-2 border-ink bg-done-soft px-1.5 py-0.5 text-sm font-extrabold text-done-ink",
						children: [
							r(e.rid),
							"「",
							e.char,
							"」+",
							e.gain
						]
					}, e.rid)), e.phase === "roundEnd" && e.roundBonus !== null && /* @__PURE__ */ u("span", {
						className: "rounded-lg border-2 border-ink px-1.5 py-0.5 text-sm font-extrabold text-white",
						style: { background: m.accent },
						children: i("games.zuci.roundBonus", { n: e.roundBonus })
					})]
				})
			})
		]
	});
}
function K({ char: e }) {
	return /* @__PURE__ */ u("span", {
		className: "zuci-hint rounded-lg border-2 border-ink bg-surface font-extrabold shadow-[1px_1px_0_var(--color-ink)]",
		children: e
	});
}
function q({ pub: e, isHintGiver: t, mySubmitted: n, send: r }) {
	let o = a(), [s, c] = i(""), [l, f] = i(null), [p, h] = i("");
	if (e.phase === "hint" && t) {
		let t = e.hints[e.hints.length - 1], n = e.grid.filter((e) => e === null).length, i = (r) => e.grid[r] !== null || t !== void 0 && t.target === r && n > 1, a = s.trim();
		return /* @__PURE__ */ d("form", {
			className: "zuci-hint-form flex flex-none flex-col gap-2",
			onSubmit: (e) => {
				e.preventDefault(), B.test(a) && l !== null && !i(l) && r({
					type: "hint",
					char: a,
					target: l
				});
			},
			children: [/* @__PURE__ */ d("div", {
				className: "zuci-hint-fields",
				children: [/* @__PURE__ */ u("input", {
					value: s,
					onChange: (e) => c(e.target.value),
					maxLength: 2,
					placeholder: o("games.zuci.hintPlaceholder"),
					"aria-label": o("games.zuci.hintPlaceholder"),
					className: "min-h-12 min-w-0 flex-1 rounded-xl border-2 border-ink bg-surface px-3 text-center font-display text-xl font-extrabold"
				}), [
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ u("button", {
					type: "button",
					"aria-label": o("games.zuci.targetAria", { n: e + 1 }),
					onClick: () => f(e),
					disabled: i(e),
					className: `zuci-target min-h-12 flex-none cursor-pointer rounded-xl border-3 border-ink text-lg font-extrabold shadow-[2px_2px_0_var(--color-ink)] disabled:opacity-35 ${l === e ? "text-white" : "bg-surface"}`,
					"aria-pressed": l === e,
					style: l === e ? { background: m.accent } : void 0,
					children: z[e]
				}, e))]
			}), /* @__PURE__ */ u("button", {
				type: "submit",
				className: "btn-base min-h-12 w-full cursor-pointer text-white disabled:opacity-40",
				style: { background: m.accent },
				disabled: !B.test(a) || l === null || i(l),
				children: o("games.zuci.submitHint")
			})]
		});
	}
	if (e.phase === "guess" && !t && !n) {
		let t = p.trim();
		return /* @__PURE__ */ d("form", {
			className: "zuci-answer-form",
			onSubmit: (e) => {
				e.preventDefault(), B.test(t) && r({
					type: "answer",
					char: t
				});
			},
			children: [
				e.guessStarted && /* @__PURE__ */ u(J, { limitSec: 60 }, `${e.round}:${e.hints.length}`),
				/* @__PURE__ */ u("input", {
					value: p,
					onChange: (e) => h(e.target.value),
					maxLength: 2,
					placeholder: o("games.zuci.answerPlaceholder"),
					"aria-label": o("games.zuci.answerPlaceholder"),
					className: "min-h-12 min-w-0 flex-1 rounded-xl border-2 border-ink bg-surface px-3 text-center font-display text-xl font-extrabold"
				}),
				/* @__PURE__ */ u("button", {
					type: "button",
					className: "btn-quiet min-h-12 flex-none cursor-pointer px-4",
					onClick: () => r({ type: "pass" }),
					children: o("games.zuci.pass")
				}),
				/* @__PURE__ */ u("button", {
					type: "submit",
					className: "btn-base min-h-12 flex-none cursor-pointer px-6 text-white disabled:opacity-40",
					style: { background: m.accent },
					disabled: !B.test(t),
					children: o("games.zuci.submitAnswer")
				})
			]
		});
	}
	return e.phase === "guess" && t ? /* @__PURE__ */ d("div", {
		className: "zuci-end-guessing flex flex-none items-center gap-2",
		children: [e.guessStarted && /* @__PURE__ */ u(J, { limitSec: 60 }, `${e.round}:${e.hints.length}`), /* @__PURE__ */ u("button", {
			type: "button",
			className: "btn-quiet min-h-12 flex-1 cursor-pointer",
			onClick: () => r({ type: "endGuessing" }),
			children: o("games.zuci.endGuessing")
		})]
	}) : null;
}
function J({ limitSec: e }) {
	let [t, n] = i(e);
	return r(() => {
		let e = window.setInterval(() => n((e) => Math.max(0, e - 1)), 1e3);
		return () => window.clearInterval(e);
	}, []), /* @__PURE__ */ d("span", {
		className: `zuci-countdown flex h-12 flex-none items-center rounded-xl border-2 border-ink px-2 font-mono text-sm font-extrabold tabular-nums ${t <= 10 ? "bg-warn-soft text-warn-ink" : "bg-surface"}`,
		children: ["⏱", t]
	});
}
//#endregion
//#region src/games/zuci/bot.ts
function Y(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var X = "天地玄黄宇宙洪荒日月星辰风雨雷电山水火木金土人海心手口目耳舌春秋冬夏东西南北", Z = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "hint" && n.hintGiver === t.rid && r?.cardChars) {
		let e = [];
		for (let t = 0; t < 4; t += 1) n.grid[t] === null && e.push(t);
		if (e.length === 0) return null;
		let t = n.hints[n.hints.length - 1], i = e.length > 1 ? e.filter((e) => e !== t?.target) : e, a = new Set(n.hints.map((e) => e.char)), o = [...X].filter((e) => !a.has(e) && !r.cardChars.includes(e));
		return o.length === 0 ? null : { action: {
			type: "hint",
			char: Y(o),
			target: Y(i)
		} };
	}
	return n.phase === "guess" && n.hintGiver !== t.rid && r && r.myAnswer === null && !r.myPassed ? t.difficulty === "weak" ? { action: { type: "pass" } } : { action: {
		type: "answer",
		char: Y(n.hints).char
	} } : null;
}, Q = (e, t, n) => e.type === "hint" ? n("games.zuci.hintGive", {
	char: e.char,
	n: e.target + 1
}) : e.type === "answer" ? n("games.zuci.hintAnswer", { char: e.char }) : e.type === "pass" ? n("games.zuci.pass") : "", $ = {
	needsAction: (e, t) => {
		let n = e.public;
		return n.phase === "hint" ? n.hintGiver === t.rid : n.phase === "guess" && n.hintGiver !== t.rid && !n.submitted.includes(t.rid);
	},
	describeView(e, t) {
		let n = e.public, r = e.private, i = [
			`第 ${n.round + 1}/${n.totalRounds} 轮,提示者是${n.hintGiver === t.rid ? "你" : n.hintGiver}。规则:卡上有 4 个互异的汉字(编号 0-3),提示者每棒给出「一个汉字 + 目标编号」,该字必须能与目标位的字组成常见二字词(提示字本身不能在卡上);猜测者各自密写一个认为是目标位的字。计分:答中未猜出的字 +1;首个作答者(沙漏持有者)答中再 +1;某字唯一被你猜对再 +1。四字全猜出则提示者得 1+剩余提示板数;16 个提示板用完还没猜完提示者得 0 分。`,
			`格面(?=未猜出): ${n.grid.map((e, t) => `${t}:${e ?? "?"}`).join(" ")}`,
			`已给提示: ${n.hints.map((e) => `「${e.char}」→${e.target}号位`).join(" ") || "(尚无)"};剩余提示板 ${n.hintsLeft}`,
			`比分: ${Object.entries(n.scores).map(([e, n]) => `${e === t.rid ? "你" : e}=${n}`).join(", ")}`
		];
		if (n.phase === "hint" && n.hintGiver === t.rid && r?.cardChars) {
			i.push(`本轮全卡(只有你能看): ${r.cardChars.map((e, t) => `${t}:${e}`).join(" ")}`);
			let e = n.grid.map((e, t) => e === null ? t : -1).filter((e) => e >= 0);
			i.push(`轮到你出提示:输出 hint{char: 提示汉字, target: 目标编号}。可选目标: ${e.join("/")};提示字不能是卡上的字、不能重复用过的提示字;不能连续两棒给同一编号(只剩 1 字未猜时除外)。给出容易组词联想、又不至于太直白被多人抢唯一猜对的提示。`);
		} else if (n.phase === "guess" && n.hintGiver !== t.rid && !n.submitted.includes(t.rid)) {
			let e = n.hints[n.hints.length - 1]?.target;
			e != null && i.push(`当前提示指向 ${e} 号位。`), i.push("轮到你作答:输出 answer{char: 你猜的汉字} 或 pass(跳过本棒)。首答会触发 60 秒沙漏且答中有加成;没把握就 pass。");
		}
		return i.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: {
				type: { const: "hint" },
				char: {
					type: "string",
					description: "提示汉字,恰好一个字"
				},
				target: {
					type: "integer",
					minimum: 0,
					maximum: 3
				}
			},
			required: [
				"type",
				"char",
				"target"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "answer" },
				char: {
					type: "string",
					description: "你猜的汉字,恰好一个字"
				}
			},
			required: ["type", "char"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "pass" } },
			required: ["type"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = _.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick" || i.type === "endGuessing") return null;
		let a = t.public;
		if (i.type === "hint") {
			if (a.phase !== "hint" || a.hintGiver !== n.rid) return null;
			let e = t.private?.cardChars;
			if (!e || e.includes(i.char) || a.hints.some((e) => e.char === i.char) || a.grid[i.target] !== null) return null;
			let r = a.hints[a.hints.length - 1], o = a.grid.filter((e) => e === null).length;
			return r && r.target === i.target && o > 1 ? null : i;
		}
		return a.phase !== "guess" || a.hintGiver === n.rid || a.submitted.includes(n.rid) ? null : i;
	}
};
//#endregion
//#region src/games/zuci/game-over.tsx
function ee({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ u("div", {
		className: "zuci-over",
		children: /* @__PURE__ */ u(f, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: m.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/zuci/guide.tsx
var te = [
	"①",
	"②",
	"③",
	"④"
];
function ne() {
	let e = a();
	return /* @__PURE__ */ d("section", {
		className: "flex w-full flex-col gap-1.5",
		children: [/* @__PURE__ */ u("p", {
			className: "section-label",
			children: e("games.zuci.guideTitle")
		}), /* @__PURE__ */ d("div", {
			className: "frame flex items-center gap-4 p-3",
			children: [/* @__PURE__ */ u("div", {
				className: "grid flex-none grid-cols-2 gap-1.5",
				children: te.map((e) => /* @__PURE__ */ u("span", {
					className: "grid size-10 place-items-center rounded-lg border-2 border-ink bg-surface font-display text-lg font-extrabold",
					children: e
				}, e))
			}), /* @__PURE__ */ d("div", {
				className: "min-w-0 flex-1 text-xs leading-5 font-bold opacity-70",
				children: [/* @__PURE__ */ u("p", { children: e("games.zuci.guideRows") }), /* @__PURE__ */ u("p", { children: e("games.zuci.guideCols") })]
			})]
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/zuci/entry.tsx
var re = {
	definition: R,
	View: U,
	bot: Z,
	describe: Q,
	llm: $,
	OverView: ee,
	Guide: ne,
	locales: {
		zh: {
			name: "组词成语",
			desc: "一个字作提示,抢答猜透四字格",
			rules: "目标:每人轮流当一次提示者,总分最高者获胜(并列共同胜利)。\n词卡:\n· 词卡是 2 行 2 列的四字格,上下两行、左右两列各组成一个二字词(见下图)。\n· 词卡内容只有提示者看得到。\n流程:\n· 提示者每次写一个提示字,并指定它和几号位的字组词,不公开前后顺序。\n· 提示字不能是卡上的字,也不能连续两次指定同一号位。\n· 其余玩家各自密写一个字作答;首答触发 60 秒倒计时,其余人须在时限内交卷。\n作答计分:\n· 猜中未揭示的字,记 1 分。\n· 第一个作答的人持有沙漏,猜中再记 1 分。\n· 某个字只有你一人猜中,再记 1 分。\n轮末:\n· 四字全部猜出:提示者记 1 分,每剩余一个提示板再记 1 分(共 16 个)。\n· 提示板用完仍未猜完,提示者本轮不得分。",
			guideTitle: "词卡结构",
			guideRows: "横行成词:①② 与 ③④",
			guideCols: "竖列成词:①③ 与 ②④",
			roundShort: "{{n}}/{{total}}",
			hintPrompt: "轮到你出提示:写一个字,选它要和几号位组词",
			hintWaiting: "等 {{name}} 出提示…",
			hintWatch: "等大家作答…",
			guessPrompt: "写一个可能命中的字",
			guessSubmitted: "已交卷,等其他人…",
			guessPassed: "已跳过,等其他人…",
			revealTitle: "揭晓!",
			roundEndTitle: "本轮结束",
			noHits: "本棒无人猜中",
			hintsLeft: "提示板 ×{{n}}",
			roundBonus: "提示者 +{{n}}",
			hourglassAria: "沙漏持有者",
			scoreChip: "{{n}} 分",
			hintPlaceholder: "提示字",
			answerPlaceholder: "一个汉字",
			submitHint: "出提示",
			submitAnswer: "提交",
			pass: "跳过",
			endGuessing: "结束猜测",
			targetAria: "与 {{n}} 号位组词",
			errNotHintGiver: "现在轮不到你出提示",
			errCharOnCard: "提示字不能是卡上的字",
			errCharUsed: "这个字已经提示过了",
			errSameTarget: "不能连续提示同一个号位",
			errTargetGuessed: "这个号位已经被猜出来了",
			errNotGuesser: "提示者不参与猜测",
			errNotGuessing: "现在不是猜测时间",
			errAlreadyAnswered: "你已经交卷了",
			hintGive: "写「{{char}}」提示 {{n}} 号位",
			hintAnswer: "作答「{{char}}」"
		},
		en: {
			name: "Word Grid",
			desc: "Hint one character, crack the 2×2 word grid",
			rules: "Goal: everyone takes a turn as the clue-giver; the highest total wins (ties share the win).\nThe word card:\n· A 2-by-2 grid of four characters; both rows and both columns form two-character words (see below).\n· Only the clue-giver can see the card.\nPlay:\n· The clue-giver writes one hint character and names which slot it pairs with, without revealing the character order.\n· The hint cannot be a character on the card, and the same slot cannot be named twice in a row.\n· Everyone else secretly writes one character; the first answer starts a 60-second countdown for the rest.\nScoring an answer:\n· Guessing an unrevealed character scores 1 point.\n· The first to answer holds the timer and scores 1 more point if correct.\n· Being the only one to guess a character scores 1 more point.\nRound end:\n· When all four characters are revealed, the clue-giver scores 1 point plus 1 more per unused hint tile (16 in total).\n· If the tiles run out first, the clue-giver scores nothing that round.",
			guideTitle: "Card layout",
			guideRows: "Rows make words: ①② and ③④",
			guideCols: "Columns make words: ①③ and ②④",
			roundShort: "{{n}}/{{total}}",
			hintPrompt: "Your clue: write a character, pick the slot it pairs with",
			hintWaiting: "Waiting for {{name}} to give a hint…",
			hintWatch: "Waiting for answers…",
			guessPrompt: "Write a character that might hit",
			guessSubmitted: "Answered, waiting for others…",
			guessPassed: "Passed, waiting for others…",
			revealTitle: "Reveal!",
			roundEndTitle: "Round over",
			noHits: "No hits this turn",
			hintsLeft: "Hint tiles ×{{n}}",
			roundBonus: "Clue-giver +{{n}}",
			hourglassAria: "Timer holder",
			scoreChip: "{{n}} pts",
			hintPlaceholder: "Hint character",
			answerPlaceholder: "One character",
			submitHint: "Give hint",
			submitAnswer: "Submit",
			pass: "Pass",
			endGuessing: "End guessing",
			targetAria: "Pair with slot {{n}}",
			errNotHintGiver: "You're not giving hints right now",
			errCharOnCard: "The hint cannot be a character on the card",
			errCharUsed: "That character was already used as a hint",
			errSameTarget: "Can't hint the same slot twice in a row",
			errTargetGuessed: "That slot is already revealed",
			errNotGuesser: "The clue-giver does not guess",
			errNotGuessing: "Not the guessing phase",
			errAlreadyAnswered: "You already answered",
			hintGive: "Hint \"{{char}}\" for slot {{n}}",
			hintAnswer: "Answer \"{{char}}\""
		}
	}
};
//#endregion
export { re as default };
