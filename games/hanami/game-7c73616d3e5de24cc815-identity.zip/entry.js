import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { PLAYER_COLORS as n } from "@bgparty/sdk/player-colors";
import { AVATARS as r } from "@bgparty/sdk/avatars";
import { useCallback as i, useMemo as a, useRef as o, useState as s } from "react";
import { useT as c } from "@bgparty/sdk/i18n";
import { SheetFxProbe as l, SheetView as u } from "@bgparty/sdk/sheet-view";
import { useFxAnchor as ee, useFxAnchorsMaybe as d } from "@bgparty/sdk/fx/anchors";
import { GameScreen as te } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { FlySprite as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { OptionCheckbox as _, OptionRadio as ne, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/hanami/board-data.ts
var y = {
	tokyo: [
		{
			id: "16",
			x: 168.42,
			y: 300.82,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"28",
				"29",
				"174",
				"175"
			]
		},
		{
			id: "23",
			x: 213.2,
			y: 33.38,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: ["24", "36"]
		},
		{
			id: "24",
			x: 213.42,
			y: 81.54,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"23",
				"25",
				"35",
				"36"
			]
		},
		{
			id: "25",
			x: 212.96,
			y: 130.44,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"24",
				"26",
				"34",
				"35"
			]
		},
		{
			id: "26",
			x: 212.38,
			y: 178.18,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"25",
				"33",
				"34"
			]
		},
		{
			id: "28",
			x: 212.68,
			y: 276.44,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"16",
				"29",
				"31",
				"32"
			]
		},
		{
			id: "29",
			x: 213.2,
			y: 325.8,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"16",
				"28",
				"30",
				"31",
				"175",
				"176"
			]
		},
		{
			id: "30",
			x: 255.6,
			y: 350.52,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"29",
				"31",
				"42",
				"43",
				"176",
				"177"
			]
		},
		{
			id: "31",
			x: 256.9,
			y: 300.96,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"28",
				"29",
				"30",
				"32",
				"41",
				"42"
			]
		},
		{
			id: "32",
			x: 256.18,
			y: 251.44,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"28",
				"31",
				"33",
				"40",
				"41"
			]
		},
		{
			id: "33",
			x: 256.64,
			y: 202.52,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"26",
				"32",
				"34",
				"39",
				"40"
			]
		},
		{
			id: "34",
			x: 256.42,
			y: 155,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"25",
				"26",
				"33",
				"35",
				"38",
				"39"
			]
		},
		{
			id: "35",
			x: 256.14,
			y: 106.42,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"24",
				"25",
				"34",
				"36",
				"37",
				"38"
			]
		},
		{
			id: "36",
			x: 255.9,
			y: 57.98,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"23",
				"24",
				"35",
				"37"
			]
		},
		{
			id: "37",
			x: 298.74,
			y: 82.24,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"35",
				"36",
				"38",
				"49",
				"50"
			]
		},
		{
			id: "38",
			x: 298.98,
			y: 130.38,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"34",
				"35",
				"37",
				"39",
				"48",
				"49"
			]
		},
		{
			id: "39",
			x: 299.7,
			y: 178.54,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"33",
				"34",
				"38",
				"40",
				"47",
				"48"
			]
		},
		{
			id: "40",
			x: 299.86,
			y: 227.36,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"32",
				"33",
				"39",
				"41",
				"46",
				"47"
			]
		},
		{
			id: "41",
			x: 299.26,
			y: 276.38,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"31",
				"32",
				"40",
				"42",
				"45",
				"46"
			]
		},
		{
			id: "42",
			x: 299.16,
			y: 325.82,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"30",
				"31",
				"41",
				"43",
				"44",
				"45"
			]
		},
		{
			id: "43",
			x: 300.04,
			y: 374.2,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"30",
				"42",
				"44",
				"177"
			]
		},
		{
			id: "44",
			x: 342.94,
			y: 349.98,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"42",
				"43",
				"45",
				"56"
			]
		},
		{
			id: "45",
			x: 342.64,
			y: 301.38,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"41",
				"42",
				"44",
				"46",
				"55",
				"56"
			]
		},
		{
			id: "46",
			x: 342.4,
			y: 252.08,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"40",
				"41",
				"45",
				"47",
				"54",
				"55"
			]
		},
		{
			id: "47",
			x: 342.54,
			y: 202.58,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"39",
				"40",
				"46",
				"48",
				"53",
				"54"
			]
		},
		{
			id: "48",
			x: 342.22,
			y: 154.34,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"38",
				"39",
				"47",
				"49",
				"52",
				"53"
			]
		},
		{
			id: "49",
			x: 341.62,
			y: 105.94,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"37",
				"38",
				"48",
				"50",
				"51",
				"52"
			]
		},
		{
			id: "50",
			x: 341.42,
			y: 57.84,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"37",
				"49",
				"51"
			]
		},
		{
			id: "51",
			x: 384.26,
			y: 82.9,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"49",
				"50",
				"52",
				"62"
			]
		},
		{
			id: "52",
			x: 384.58,
			y: 130.7,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"48",
				"49",
				"51",
				"53",
				"61",
				"62"
			]
		},
		{
			id: "53",
			x: 384.8,
			y: 179.58,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"47",
				"48",
				"52",
				"54",
				"60",
				"61"
			]
		},
		{
			id: "54",
			x: 385.3,
			y: 227.92,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"46",
				"47",
				"53",
				"55",
				"59",
				"60"
			]
		},
		{
			id: "55",
			x: 384.3,
			y: 276.68,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"45",
				"46",
				"54",
				"56",
				"58",
				"59"
			]
		},
		{
			id: "56",
			x: 385.16,
			y: 325.8,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"44",
				"45",
				"55",
				"57",
				"58"
			]
		},
		{
			id: "57",
			x: 427.14,
			y: 350.46,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"56",
				"58",
				"67",
				"68"
			]
		},
		{
			id: "58",
			x: 427.04,
			y: 301.46,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"55",
				"56",
				"57",
				"59",
				"66",
				"67"
			]
		},
		{
			id: "59",
			x: 427.4,
			y: 252.36,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"54",
				"55",
				"58",
				"60",
				"65",
				"66"
			]
		},
		{
			id: "60",
			x: 427.04,
			y: 204,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"53",
				"54",
				"59",
				"61",
				"64",
				"65"
			]
		},
		{
			id: "61",
			x: 427.1,
			y: 155.28,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"52",
				"53",
				"60",
				"62",
				"63",
				"64"
			]
		},
		{
			id: "62",
			x: 427.48,
			y: 107,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"51",
				"52",
				"61",
				"63",
				"178"
			]
		},
		{
			id: "63",
			x: 469.22,
			y: 131.32,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"61",
				"62",
				"64",
				"73",
				"178",
				"179"
			]
		},
		{
			id: "64",
			x: 469.2,
			y: 180.14,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"60",
				"61",
				"63",
				"65",
				"72",
				"73"
			]
		},
		{
			id: "65",
			x: 469.4,
			y: 228.32,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"59",
				"60",
				"64",
				"66",
				"71",
				"72"
			]
		},
		{
			id: "66",
			x: 469.54,
			y: 277.32,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"58",
				"59",
				"65",
				"67",
				"70",
				"71"
			]
		},
		{
			id: "67",
			x: 469.96,
			y: 325.66,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"57",
				"58",
				"66",
				"68",
				"69",
				"70"
			]
		},
		{
			id: "68",
			x: 470.52,
			y: 374.68,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"57",
				"67",
				"69"
			]
		},
		{
			id: "69",
			x: 512.18,
			y: 350.1,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"67",
				"68",
				"70",
				"77",
				"78"
			]
		},
		{
			id: "70",
			x: 512.24,
			y: 300.84,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"66",
				"67",
				"69",
				"71",
				"76",
				"77"
			]
		},
		{
			id: "71",
			x: 511.68,
			y: 252.64,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"65",
				"66",
				"70",
				"72",
				"75",
				"76"
			]
		},
		{
			id: "72",
			x: 512.14,
			y: 204.5,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"64",
				"65",
				"71",
				"73",
				"74",
				"75"
			]
		},
		{
			id: "73",
			x: 511.76,
			y: 155.72,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"63",
				"64",
				"72",
				"74",
				"179",
				"180"
			]
		},
		{
			id: "74",
			x: 554.2,
			y: 179.98,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"72",
				"73",
				"75",
				"83",
				"180",
				"181"
			]
		},
		{
			id: "75",
			x: 554.38,
			y: 229.12,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"71",
				"72",
				"74",
				"76",
				"82",
				"83"
			]
		},
		{
			id: "76",
			x: 554.48,
			y: 276.9,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"70",
				"71",
				"75",
				"77",
				"81",
				"82"
			]
		},
		{
			id: "77",
			x: 554.86,
			y: 325.58,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"69",
				"70",
				"76",
				"78",
				"80",
				"81"
			]
		},
		{
			id: "78",
			x: 554.84,
			y: 374.7,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"69",
				"77",
				"79",
				"80"
			]
		},
		{
			id: "79",
			x: 597.44,
			y: 398.34,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"78",
				"80",
				"88",
				"89"
			]
		},
		{
			id: "80",
			x: 597.02,
			y: 350.02,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"77",
				"78",
				"79",
				"81",
				"86",
				"88"
			]
		},
		{
			id: "81",
			x: 597.44,
			y: 301.16,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"76",
				"77",
				"80",
				"82",
				"86",
				"87"
			]
		},
		{
			id: "82",
			x: 596.76,
			y: 252.3,
			terrain: "park",
			minPlayers: 2,
			capacity: 3,
			neighbors: [
				"75",
				"76",
				"81",
				"83",
				"85",
				"87"
			]
		},
		{
			id: "83",
			x: 596.52,
			y: 204.16,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"74",
				"75",
				"82",
				"84",
				"85",
				"181"
			]
		},
		{
			id: "84",
			x: 638.66,
			y: 179.22,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"83",
				"85",
				"97",
				"181",
				"186",
				"190"
			]
		},
		{
			id: "85",
			x: 639,
			y: 228.12,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"82",
				"83",
				"84",
				"87",
				"96",
				"97"
			]
		},
		{
			id: "86",
			x: 639.22,
			y: 325.26,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"80",
				"81",
				"87",
				"88",
				"94",
				"95"
			]
		},
		{
			id: "87",
			x: 639.22,
			y: 276.4,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"81",
				"82",
				"85",
				"86",
				"95",
				"96"
			]
		},
		{
			id: "88",
			x: 639.34,
			y: 374,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"79",
				"80",
				"86",
				"89",
				"93",
				"94"
			]
		},
		{
			id: "89",
			x: 639.24,
			y: 423.06,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"79",
				"88",
				"93"
			]
		},
		{
			id: "93",
			x: 681.4,
			y: 398.28,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"88",
				"89",
				"94",
				"101",
				"102"
			]
		},
		{
			id: "94",
			x: 681.28,
			y: 349.92,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"86",
				"88",
				"93",
				"95",
				"100",
				"101"
			]
		},
		{
			id: "95",
			x: 681.34,
			y: 301.16,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"86",
				"87",
				"94",
				"96",
				"99",
				"100"
			]
		},
		{
			id: "96",
			x: 681.14,
			y: 252.22,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"85",
				"87",
				"95",
				"97",
				"98",
				"99"
			]
		},
		{
			id: "97",
			x: 680.94,
			y: 203.62,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"84",
				"85",
				"96",
				"98",
				"190",
				"191"
			]
		},
		{
			id: "98",
			x: 723.34,
			y: 227.96,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"96",
				"97",
				"99",
				"148",
				"191",
				"195"
			]
		},
		{
			id: "99",
			x: 723.76,
			y: 276.66,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"95",
				"96",
				"98",
				"100",
				"148",
				"149"
			]
		},
		{
			id: "100",
			x: 723.38,
			y: 325.1,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"94",
				"95",
				"99",
				"101",
				"149",
				"150"
			]
		},
		{
			id: "101",
			x: 723.74,
			y: 373.98,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"93",
				"94",
				"100",
				"102",
				"105",
				"150"
			]
		},
		{
			id: "102",
			x: 724.28,
			y: 423.1,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"93",
				"101",
				"104",
				"105"
			]
		},
		{
			id: "104",
			x: 767.2,
			y: 447.68,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"102",
				"105",
				"106"
			]
		},
		{
			id: "105",
			x: 766.5,
			y: 398.52,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"101",
				"102",
				"104",
				"106",
				"124",
				"150"
			]
		},
		{
			id: "106",
			x: 808.82,
			y: 423.12,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"104",
				"105",
				"107",
				"124"
			]
		},
		{
			id: "107",
			x: 851.22,
			y: 398.64,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"106",
				"108",
				"124",
				"125",
				"204"
			]
		},
		{
			id: "108",
			x: 894.18,
			y: 374.8,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"107",
				"109",
				"125",
				"126",
				"203",
				"204"
			]
		},
		{
			id: "109",
			x: 936,
			y: 350.08,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"108",
				"110",
				"126",
				"127",
				"202",
				"203"
			]
		},
		{
			id: "110",
			x: 978.38,
			y: 325.8,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"109",
				"111",
				"127",
				"128",
				"201",
				"202"
			]
		},
		{
			id: "111",
			x: 1021.26,
			y: 301.66,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"110",
				"112",
				"128",
				"129",
				"200",
				"201"
			]
		},
		{
			id: "112",
			x: 1064.44,
			y: 277.58,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"111",
				"113",
				"129",
				"130",
				"199",
				"200"
			]
		},
		{
			id: "113",
			x: 1107.14,
			y: 253.1,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"112",
				"117",
				"130",
				"131",
				"199"
			]
		},
		{
			id: "117",
			x: 1151.62,
			y: 276.48,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: ["113", "199"]
		},
		{
			id: "124",
			x: 808.44,
			y: 373.62,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"105",
				"106",
				"107",
				"125",
				"150",
				"151"
			]
		},
		{
			id: "125",
			x: 850.84,
			y: 349.72,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"107",
				"108",
				"124",
				"126",
				"151",
				"154"
			]
		},
		{
			id: "126",
			x: 893.4,
			y: 326,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"108",
				"109",
				"125",
				"127",
				"154",
				"155"
			]
		},
		{
			id: "127",
			x: 936.12,
			y: 301.42,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"109",
				"110",
				"126",
				"128",
				"155",
				"158"
			]
		},
		{
			id: "128",
			x: 978.38,
			y: 276.62,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"110",
				"111",
				"127",
				"129",
				"158",
				"159"
			]
		},
		{
			id: "129",
			x: 1021.54,
			y: 253.06,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"111",
				"112",
				"128",
				"130",
				"159",
				"163"
			]
		},
		{
			id: "130",
			x: 1064.44,
			y: 228.9,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"112",
				"113",
				"129",
				"131",
				"163",
				"164"
			]
		},
		{
			id: "131",
			x: 1107.86,
			y: 203.94,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"113",
				"130",
				"132",
				"164",
				"169"
			]
		},
		{
			id: "132",
			x: 1151.26,
			y: 179.12,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"131",
				"133",
				"169",
				"170"
			]
		},
		{
			id: "133",
			x: 1194.68,
			y: 155.04,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"132",
				"170",
				"173"
			]
		},
		{
			id: "138",
			x: 1150.58,
			y: 32.8,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"139",
				"171",
				"172"
			]
		},
		{
			id: "139",
			x: 1107.82,
			y: 57.46,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"138",
				"140",
				"167",
				"168",
				"171"
			]
		},
		{
			id: "140",
			x: 1064.16,
			y: 32.62,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"139",
				"141",
				"167"
			]
		},
		{
			id: "141",
			x: 1020.78,
			y: 57.12,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"140",
				"142",
				"165",
				"167"
			]
		},
		{
			id: "142",
			x: 977.84,
			y: 81.34,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"141",
				"143",
				"161",
				"165"
			]
		},
		{
			id: "143",
			x: 935.28,
			y: 106.12,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"142",
				"144",
				"161"
			]
		},
		{
			id: "144",
			x: 935.6,
			y: 154.92,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"143",
				"145",
				"157",
				"160",
				"161"
			]
		},
		{
			id: "145",
			x: 893.04,
			y: 179.28,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"144",
				"146",
				"156",
				"157",
				"198"
			]
		},
		{
			id: "146",
			x: 850.94,
			y: 203.92,
			terrain: "park",
			minPlayers: 2,
			capacity: 2,
			neighbors: [
				"145",
				"147",
				"153",
				"156",
				"196",
				"198"
			]
		},
		{
			id: "147",
			x: 808.72,
			y: 228.32,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"146",
				"148",
				"152",
				"153",
				"195",
				"196"
			]
		},
		{
			id: "148",
			x: 766.22,
			y: 252.36,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"98",
				"99",
				"147",
				"149",
				"152",
				"195"
			]
		},
		{
			id: "149",
			x: 766.14,
			y: 300.64,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"99",
				"100",
				"148",
				"150",
				"151",
				"152"
			]
		},
		{
			id: "150",
			x: 766.44,
			y: 349.44,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"100",
				"101",
				"105",
				"124",
				"149",
				"151"
			]
		},
		{
			id: "151",
			x: 808.28,
			y: 325.28,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"124",
				"125",
				"149",
				"150",
				"152",
				"154"
			]
		},
		{
			id: "152",
			x: 808.22,
			y: 276.68,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"147",
				"148",
				"149",
				"151",
				"153",
				"154"
			]
		},
		{
			id: "153",
			x: 850.68,
			y: 252.98,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"146",
				"147",
				"152",
				"154",
				"155",
				"156"
			]
		},
		{
			id: "154",
			x: 850.84,
			y: 301.58,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"125",
				"126",
				"151",
				"152",
				"153",
				"155"
			]
		},
		{
			id: "155",
			x: 893.04,
			y: 277.34,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"126",
				"127",
				"153",
				"154",
				"156",
				"158"
			]
		},
		{
			id: "156",
			x: 893.34,
			y: 228.34,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"145",
				"146",
				"153",
				"155",
				"157",
				"158"
			]
		},
		{
			id: "157",
			x: 935.68,
			y: 203.06,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"144",
				"145",
				"156",
				"158",
				"159",
				"160"
			]
		},
		{
			id: "158",
			x: 935.9,
			y: 253,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"127",
				"128",
				"155",
				"156",
				"157",
				"159"
			]
		},
		{
			id: "159",
			x: 978.32,
			y: 228.18,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"128",
				"129",
				"157",
				"158",
				"160",
				"163"
			]
		},
		{
			id: "160",
			x: 978.66,
			y: 179.7,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"144",
				"157",
				"159",
				"161",
				"162",
				"163"
			]
		},
		{
			id: "161",
			x: 978.5,
			y: 130.64,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"142",
				"143",
				"144",
				"160",
				"162",
				"165"
			]
		},
		{
			id: "162",
			x: 1020.64,
			y: 155.28,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"160",
				"161",
				"163",
				"164",
				"165",
				"166"
			]
		},
		{
			id: "163",
			x: 1021.66,
			y: 204.62,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"129",
				"130",
				"159",
				"160",
				"162",
				"164"
			]
		},
		{
			id: "164",
			x: 1064.24,
			y: 179.68,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"130",
				"131",
				"162",
				"163",
				"166",
				"169"
			]
		},
		{
			id: "165",
			x: 1021.64,
			y: 105.82,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"141",
				"142",
				"161",
				"162",
				"166",
				"167"
			]
		},
		{
			id: "166",
			x: 1064.36,
			y: 130.8,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"162",
				"164",
				"165",
				"167",
				"168",
				"169"
			]
		},
		{
			id: "167",
			x: 1064.2,
			y: 81.84,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"139",
				"140",
				"141",
				"165",
				"166",
				"168"
			]
		},
		{
			id: "168",
			x: 1107.08,
			y: 105.66,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"139",
				"166",
				"167",
				"169",
				"170",
				"171"
			]
		},
		{
			id: "169",
			x: 1107.58,
			y: 155.12,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"131",
				"132",
				"164",
				"166",
				"168",
				"170"
			]
		},
		{
			id: "170",
			x: 1150.8,
			y: 131.3,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"132",
				"133",
				"168",
				"169",
				"171",
				"173"
			]
		},
		{
			id: "171",
			x: 1152.58,
			y: 81.66,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"138",
				"139",
				"168",
				"170",
				"172",
				"173"
			]
		},
		{
			id: "172",
			x: 1194.68,
			y: 57.52,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"138",
				"171",
				"173"
			]
		},
		{
			id: "173",
			x: 1194.52,
			y: 106.98,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"133",
				"170",
				"171",
				"172"
			]
		},
		{
			id: "174",
			x: 124.26,
			y: 326.94,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: ["16", "175"]
		},
		{
			id: "175",
			x: 169.64,
			y: 351.4,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"16",
				"29",
				"174",
				"176"
			]
		},
		{
			id: "176",
			x: 211.72,
			y: 375.82,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"29",
				"30",
				"175",
				"177"
			]
		},
		{
			id: "177",
			x: 255.72,
			y: 400.96,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"30",
				"43",
				"176"
			]
		},
		{
			id: "178",
			x: 469.02,
			y: 83.66,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"62",
				"63",
				"179",
				"185"
			]
		},
		{
			id: "179",
			x: 510.56,
			y: 107.56,
			terrain: "park",
			minPlayers: 2,
			capacity: 2,
			neighbors: [
				"63",
				"73",
				"178",
				"180",
				"184",
				"185"
			]
		},
		{
			id: "180",
			x: 553.08,
			y: 131.7,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"73",
				"74",
				"179",
				"181",
				"182",
				"184"
			]
		},
		{
			id: "181",
			x: 596.3,
			y: 156.04,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"74",
				"83",
				"84",
				"180",
				"182",
				"186"
			]
		},
		{
			id: "182",
			x: 595.44,
			y: 108.02,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"180",
				"181",
				"183",
				"184",
				"186",
				"187"
			]
		},
		{
			id: "183",
			x: 594.78,
			y: 60.7,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"182",
				"184",
				"187"
			]
		},
		{
			id: "184",
			x: 552.52,
			y: 83.48,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"179",
				"180",
				"182",
				"183",
				"185"
			]
		},
		{
			id: "185",
			x: 509.86,
			y: 60.22,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"178",
				"179",
				"184"
			]
		},
		{
			id: "186",
			x: 637.84,
			y: 132.14,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"84",
				"181",
				"182",
				"187",
				"189",
				"190"
			]
		},
		{
			id: "187",
			x: 637.2,
			y: 84.12,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"182",
				"183",
				"186",
				"188",
				"189"
			]
		},
		{
			id: "188",
			x: 679.14,
			y: 58.96,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"187",
				"189",
				"193"
			]
		},
		{
			id: "189",
			x: 679.6,
			y: 106.92,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"186",
				"187",
				"188",
				"190",
				"192",
				"193"
			]
		},
		{
			id: "190",
			x: 680.26,
			y: 155.16,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"84",
				"97",
				"186",
				"189",
				"191",
				"192"
			]
		},
		{
			id: "191",
			x: 722.58,
			y: 178.84,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"97",
				"98",
				"190",
				"192",
				"194",
				"195"
			]
		},
		{
			id: "192",
			x: 721.52,
			y: 132,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"189",
				"190",
				"191",
				"193",
				"194"
			]
		},
		{
			id: "193",
			x: 722.02,
			y: 83.72,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"188",
				"189",
				"192"
			]
		},
		{
			id: "194",
			x: 764.62,
			y: 155.38,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"191",
				"192",
				"195",
				"196",
				"197"
			]
		},
		{
			id: "195",
			x: 764.66,
			y: 203.8,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"98",
				"147",
				"148",
				"191",
				"194",
				"196"
			]
		},
		{
			id: "196",
			x: 807.58,
			y: 181.48,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"146",
				"147",
				"194",
				"195",
				"197",
				"198"
			]
		},
		{
			id: "197",
			x: 807.84,
			y: 130.5,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"194",
				"196",
				"198"
			]
		},
		{
			id: "198",
			x: 850,
			y: 156.16,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"145",
				"146",
				"196",
				"197"
			]
		},
		{
			id: "199",
			x: 1107.6,
			y: 301.68,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"112",
				"113",
				"117",
				"200",
				"209"
			]
		},
		{
			id: "200",
			x: 1063.58,
			y: 326.1,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"111",
				"112",
				"199",
				"201",
				"208",
				"209"
			]
		},
		{
			id: "201",
			x: 1020.78,
			y: 349.9,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"110",
				"111",
				"200",
				"202",
				"206",
				"208"
			]
		},
		{
			id: "202",
			x: 978.1,
			y: 374.28,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"109",
				"110",
				"201",
				"203",
				"206",
				"207"
			]
		},
		{
			id: "203",
			x: 935.1,
			y: 398.12,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"108",
				"109",
				"202",
				"204",
				"205",
				"207"
			]
		},
		{
			id: "204",
			x: 893.42,
			y: 423.2,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"107",
				"108",
				"203",
				"205"
			]
		},
		{
			id: "205",
			x: 935.28,
			y: 447.32,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"203",
				"204",
				"207"
			]
		},
		{
			id: "206",
			x: 1021.36,
			y: 398.7,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"201",
				"202",
				"207",
				"208"
			]
		},
		{
			id: "207",
			x: 978.5,
			y: 423.3,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"202",
				"203",
				"205",
				"206"
			]
		},
		{
			id: "208",
			x: 1064,
			y: 374.32,
			terrain: "park",
			minPlayers: 4,
			capacity: 2,
			neighbors: [
				"200",
				"201",
				"206",
				"209"
			]
		},
		{
			id: "209",
			x: 1106.8,
			y: 349.9,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"199",
				"200",
				"208"
			]
		}
	],
	nihon: [
		{
			id: "0",
			x: 37.82,
			y: 80.64,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"1",
				"7",
				"8"
			]
		},
		{
			id: "1",
			x: 37.82,
			y: 129.4,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"0",
				"2",
				"6",
				"7"
			]
		},
		{
			id: "2",
			x: 37.28,
			y: 178.24,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"1",
				"3",
				"5",
				"6"
			]
		},
		{
			id: "3",
			x: 37.6,
			y: 226.68,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"2",
				"4",
				"5"
			]
		},
		{
			id: "4",
			x: 82.04,
			y: 251.54,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"3",
				"5",
				"15"
			]
		},
		{
			id: "5",
			x: 81.72,
			y: 202.76,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"2",
				"3",
				"4",
				"6",
				"14",
				"15"
			]
		},
		{
			id: "6",
			x: 82.06,
			y: 154.22,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"1",
				"2",
				"5",
				"7",
				"13",
				"14"
			]
		},
		{
			id: "7",
			x: 82.9,
			y: 105.84,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"0",
				"1",
				"6",
				"8",
				"12",
				"13"
			]
		},
		{
			id: "8",
			x: 81.44,
			y: 57.42,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"0",
				"7",
				"9",
				"11",
				"12"
			]
		},
		{
			id: "9",
			x: 81.64,
			y: 8.18,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"8",
				"10",
				"11"
			]
		},
		{
			id: "10",
			x: 125.66,
			y: -15.88,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"9",
				"11",
				"22"
			]
		},
		{
			id: "11",
			x: 125.64,
			y: 32.94,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"8",
				"9",
				"10",
				"12",
				"21",
				"22"
			]
		},
		{
			id: "12",
			x: 126.2,
			y: 80.94,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"7",
				"8",
				"11",
				"13",
				"20",
				"21"
			]
		},
		{
			id: "13",
			x: 126.2,
			y: 129.86,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"6",
				"7",
				"12",
				"14",
				"19",
				"20"
			]
		},
		{
			id: "14",
			x: 127,
			y: 178.76,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"5",
				"6",
				"13",
				"15",
				"18",
				"19"
			]
		},
		{
			id: "15",
			x: 126.56,
			y: 227.4,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"4",
				"5",
				"14",
				"17",
				"18"
			]
		},
		{
			id: "16",
			x: 168.42,
			y: 300.82,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"17",
				"28",
				"29"
			]
		},
		{
			id: "17",
			x: 169,
			y: 251.22,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"15",
				"16",
				"18",
				"27",
				"28"
			]
		},
		{
			id: "18",
			x: 169.52,
			y: 202.64,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"14",
				"15",
				"17",
				"19",
				"26",
				"27"
			]
		},
		{
			id: "19",
			x: 169.56,
			y: 154.4,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"13",
				"14",
				"18",
				"20",
				"25",
				"26"
			]
		},
		{
			id: "20",
			x: 169.96,
			y: 105.5,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"12",
				"13",
				"19",
				"21",
				"24",
				"25"
			]
		},
		{
			id: "21",
			x: 169.58,
			y: 56.74,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"11",
				"12",
				"20",
				"22",
				"23",
				"24"
			]
		},
		{
			id: "22",
			x: 169.54,
			y: 9.26,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"10",
				"11",
				"21",
				"23"
			]
		},
		{
			id: "23",
			x: 213.2,
			y: 33.38,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"21",
				"22",
				"24",
				"36"
			]
		},
		{
			id: "24",
			x: 213.42,
			y: 81.54,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"20",
				"21",
				"23",
				"25",
				"35",
				"36"
			]
		},
		{
			id: "25",
			x: 212.96,
			y: 130.44,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"19",
				"20",
				"24",
				"26",
				"34",
				"35"
			]
		},
		{
			id: "26",
			x: 212.38,
			y: 178.18,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"18",
				"19",
				"25",
				"27",
				"33",
				"34"
			]
		},
		{
			id: "27",
			x: 212.68,
			y: 227.16,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"17",
				"18",
				"26",
				"28",
				"32",
				"33"
			]
		},
		{
			id: "28",
			x: 212.68,
			y: 276.44,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"16",
				"17",
				"27",
				"29",
				"31",
				"32"
			]
		},
		{
			id: "29",
			x: 213.2,
			y: 325.8,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"16",
				"28",
				"30",
				"31"
			]
		},
		{
			id: "30",
			x: 255.6,
			y: 350.52,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"29",
				"31",
				"42",
				"43"
			]
		},
		{
			id: "31",
			x: 256.9,
			y: 300.96,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"28",
				"29",
				"30",
				"32",
				"41",
				"42"
			]
		},
		{
			id: "32",
			x: 256.18,
			y: 251.44,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"27",
				"28",
				"31",
				"33",
				"40",
				"41"
			]
		},
		{
			id: "33",
			x: 256.64,
			y: 202.52,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"26",
				"27",
				"32",
				"34",
				"39",
				"40"
			]
		},
		{
			id: "34",
			x: 256.42,
			y: 155,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"25",
				"26",
				"33",
				"35",
				"38",
				"39"
			]
		},
		{
			id: "35",
			x: 256.14,
			y: 106.42,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"24",
				"25",
				"34",
				"36",
				"37",
				"38"
			]
		},
		{
			id: "36",
			x: 255.9,
			y: 57.98,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"23",
				"24",
				"35",
				"37"
			]
		},
		{
			id: "37",
			x: 298.74,
			y: 82.24,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"35",
				"36",
				"38",
				"49",
				"50"
			]
		},
		{
			id: "38",
			x: 298.98,
			y: 130.38,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"34",
				"35",
				"37",
				"39",
				"48",
				"49"
			]
		},
		{
			id: "39",
			x: 299.7,
			y: 178.54,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"33",
				"34",
				"38",
				"40",
				"47",
				"48"
			]
		},
		{
			id: "40",
			x: 299.86,
			y: 227.36,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"32",
				"33",
				"39",
				"41",
				"46",
				"47"
			]
		},
		{
			id: "41",
			x: 299.26,
			y: 276.38,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"31",
				"32",
				"40",
				"42",
				"45",
				"46"
			]
		},
		{
			id: "42",
			x: 299.16,
			y: 325.82,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"30",
				"31",
				"41",
				"43",
				"44",
				"45"
			]
		},
		{
			id: "43",
			x: 300.04,
			y: 374.2,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"30",
				"42",
				"44"
			]
		},
		{
			id: "44",
			x: 342.94,
			y: 349.98,
			terrain: "water",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"42",
				"43",
				"45",
				"56"
			]
		},
		{
			id: "45",
			x: 342.64,
			y: 301.38,
			terrain: "land",
			minPlayers: 3,
			capacity: 0,
			neighbors: [
				"41",
				"42",
				"44",
				"46",
				"55",
				"56"
			]
		},
		{
			id: "46",
			x: 342.4,
			y: 252.08,
			terrain: "park",
			minPlayers: 3,
			capacity: 1,
			neighbors: [
				"40",
				"41",
				"45",
				"47",
				"54",
				"55"
			]
		},
		{
			id: "47",
			x: 342.54,
			y: 202.58,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"39",
				"40",
				"46",
				"48",
				"53",
				"54"
			]
		},
		{
			id: "48",
			x: 342.22,
			y: 154.34,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"38",
				"39",
				"47",
				"49",
				"52",
				"53"
			]
		},
		{
			id: "49",
			x: 341.62,
			y: 105.94,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"37",
				"38",
				"48",
				"50",
				"51",
				"52"
			]
		},
		{
			id: "50",
			x: 341.42,
			y: 57.84,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"37",
				"49",
				"51"
			]
		},
		{
			id: "51",
			x: 384.26,
			y: 82.9,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"49",
				"50",
				"52",
				"62"
			]
		},
		{
			id: "52",
			x: 384.58,
			y: 130.7,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"48",
				"49",
				"51",
				"53",
				"61",
				"62"
			]
		},
		{
			id: "53",
			x: 384.8,
			y: 179.58,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"47",
				"48",
				"52",
				"54",
				"60",
				"61"
			]
		},
		{
			id: "54",
			x: 385.3,
			y: 227.92,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"46",
				"47",
				"53",
				"55",
				"59",
				"60"
			]
		},
		{
			id: "55",
			x: 384.3,
			y: 276.68,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"45",
				"46",
				"54",
				"56",
				"58",
				"59"
			]
		},
		{
			id: "56",
			x: 385.16,
			y: 325.8,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"44",
				"45",
				"55",
				"57",
				"58"
			]
		},
		{
			id: "57",
			x: 427.14,
			y: 350.46,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"56",
				"58",
				"67",
				"68"
			]
		},
		{
			id: "58",
			x: 427.04,
			y: 301.46,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"55",
				"56",
				"57",
				"59",
				"66",
				"67"
			]
		},
		{
			id: "59",
			x: 427.4,
			y: 252.36,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"54",
				"55",
				"58",
				"60",
				"65",
				"66"
			]
		},
		{
			id: "60",
			x: 427.04,
			y: 204,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"53",
				"54",
				"59",
				"61",
				"64",
				"65"
			]
		},
		{
			id: "61",
			x: 427.1,
			y: 155.28,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"52",
				"53",
				"60",
				"62",
				"63",
				"64"
			]
		},
		{
			id: "62",
			x: 427.48,
			y: 107,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"51",
				"52",
				"61",
				"63"
			]
		},
		{
			id: "63",
			x: 469.22,
			y: 131.32,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"61",
				"62",
				"64",
				"73"
			]
		},
		{
			id: "64",
			x: 469.2,
			y: 180.14,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"60",
				"61",
				"63",
				"65",
				"72",
				"73"
			]
		},
		{
			id: "65",
			x: 469.4,
			y: 228.32,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"59",
				"60",
				"64",
				"66",
				"71",
				"72"
			]
		},
		{
			id: "66",
			x: 469.54,
			y: 277.32,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"58",
				"59",
				"65",
				"67",
				"70",
				"71"
			]
		},
		{
			id: "67",
			x: 469.96,
			y: 325.66,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"57",
				"58",
				"66",
				"68",
				"69",
				"70"
			]
		},
		{
			id: "68",
			x: 470.52,
			y: 374.68,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"57",
				"67",
				"69"
			]
		},
		{
			id: "69",
			x: 512.18,
			y: 350.1,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"67",
				"68",
				"70",
				"77",
				"78"
			]
		},
		{
			id: "70",
			x: 512.24,
			y: 300.84,
			terrain: "park",
			minPlayers: 2,
			capacity: 2,
			neighbors: [
				"66",
				"67",
				"69",
				"71",
				"76",
				"77"
			]
		},
		{
			id: "71",
			x: 511.68,
			y: 252.64,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"65",
				"66",
				"70",
				"72",
				"75",
				"76"
			]
		},
		{
			id: "72",
			x: 512.14,
			y: 204.5,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"64",
				"65",
				"71",
				"73",
				"74",
				"75"
			]
		},
		{
			id: "73",
			x: 511.76,
			y: 155.72,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"63",
				"64",
				"72",
				"74"
			]
		},
		{
			id: "74",
			x: 554.2,
			y: 179.98,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"72",
				"73",
				"75",
				"83"
			]
		},
		{
			id: "75",
			x: 554.38,
			y: 229.12,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"71",
				"72",
				"74",
				"76",
				"82",
				"83"
			]
		},
		{
			id: "76",
			x: 554.48,
			y: 276.9,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"70",
				"71",
				"75",
				"77",
				"81",
				"82"
			]
		},
		{
			id: "77",
			x: 554.86,
			y: 325.58,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"69",
				"70",
				"76",
				"78",
				"80",
				"81"
			]
		},
		{
			id: "78",
			x: 554.84,
			y: 374.7,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"69",
				"77",
				"79",
				"80"
			]
		},
		{
			id: "79",
			x: 597.44,
			y: 398.34,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"78",
				"80",
				"88",
				"89"
			]
		},
		{
			id: "80",
			x: 597.02,
			y: 350.02,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"77",
				"78",
				"79",
				"81",
				"86",
				"88"
			]
		},
		{
			id: "81",
			x: 597.44,
			y: 301.16,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"76",
				"77",
				"80",
				"82",
				"86",
				"87"
			]
		},
		{
			id: "82",
			x: 596.76,
			y: 252.3,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"75",
				"76",
				"81",
				"83",
				"85",
				"87"
			]
		},
		{
			id: "83",
			x: 596.52,
			y: 204.16,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"74",
				"75",
				"82",
				"84",
				"85"
			]
		},
		{
			id: "84",
			x: 638.66,
			y: 179.22,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"83",
				"85",
				"97"
			]
		},
		{
			id: "85",
			x: 639,
			y: 228.12,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"82",
				"83",
				"84",
				"87",
				"96",
				"97"
			]
		},
		{
			id: "86",
			x: 639.22,
			y: 325.26,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"80",
				"81",
				"87",
				"88",
				"94",
				"95"
			]
		},
		{
			id: "87",
			x: 639.22,
			y: 276.4,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"81",
				"82",
				"85",
				"86",
				"95",
				"96"
			]
		},
		{
			id: "88",
			x: 639.34,
			y: 374,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"79",
				"80",
				"86",
				"89",
				"93",
				"94"
			]
		},
		{
			id: "89",
			x: 639.24,
			y: 423.06,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"79",
				"88",
				"90",
				"92",
				"93"
			]
		},
		{
			id: "90",
			x: 638.7,
			y: 471.86,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"89",
				"91",
				"92"
			]
		},
		{
			id: "91",
			x: 682.26,
			y: 496.42,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"90",
				"92",
				"103"
			]
		},
		{
			id: "92",
			x: 681.72,
			y: 447.18,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"89",
				"90",
				"91",
				"93",
				"102",
				"103"
			]
		},
		{
			id: "93",
			x: 681.4,
			y: 398.28,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"88",
				"89",
				"92",
				"94",
				"101",
				"102"
			]
		},
		{
			id: "94",
			x: 681.28,
			y: 349.92,
			terrain: "park",
			minPlayers: 2,
			capacity: 3,
			neighbors: [
				"86",
				"88",
				"93",
				"95",
				"100",
				"101"
			]
		},
		{
			id: "95",
			x: 681.34,
			y: 301.16,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"86",
				"87",
				"94",
				"96",
				"99",
				"100"
			]
		},
		{
			id: "96",
			x: 681.14,
			y: 252.22,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"85",
				"87",
				"95",
				"97",
				"98",
				"99"
			]
		},
		{
			id: "97",
			x: 680.94,
			y: 203.62,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"84",
				"85",
				"96",
				"98"
			]
		},
		{
			id: "98",
			x: 723.34,
			y: 227.96,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"96",
				"97",
				"99",
				"148"
			]
		},
		{
			id: "99",
			x: 723.76,
			y: 276.66,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"95",
				"96",
				"98",
				"100",
				"148",
				"149"
			]
		},
		{
			id: "100",
			x: 723.38,
			y: 325.1,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"94",
				"95",
				"99",
				"101",
				"149",
				"150"
			]
		},
		{
			id: "101",
			x: 723.74,
			y: 373.98,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"93",
				"94",
				"100",
				"102",
				"105",
				"150"
			]
		},
		{
			id: "102",
			x: 724.28,
			y: 423.1,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"92",
				"93",
				"101",
				"103",
				"104",
				"105"
			]
		},
		{
			id: "103",
			x: 725,
			y: 472.44,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"91",
				"92",
				"102",
				"104"
			]
		},
		{
			id: "104",
			x: 767.2,
			y: 447.68,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"102",
				"103",
				"105",
				"106"
			]
		},
		{
			id: "105",
			x: 766.5,
			y: 398.52,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"101",
				"102",
				"104",
				"106",
				"124",
				"150"
			]
		},
		{
			id: "106",
			x: 808.82,
			y: 423.12,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"104",
				"105",
				"107",
				"124"
			]
		},
		{
			id: "107",
			x: 851.22,
			y: 398.64,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"106",
				"108",
				"124",
				"125"
			]
		},
		{
			id: "108",
			x: 894.18,
			y: 374.8,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"107",
				"109",
				"125",
				"126"
			]
		},
		{
			id: "109",
			x: 936,
			y: 350.08,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"108",
				"110",
				"126",
				"127"
			]
		},
		{
			id: "110",
			x: 978.38,
			y: 325.8,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"109",
				"111",
				"127",
				"128"
			]
		},
		{
			id: "111",
			x: 1021.26,
			y: 301.66,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"110",
				"112",
				"128",
				"129"
			]
		},
		{
			id: "112",
			x: 1064.44,
			y: 277.58,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"111",
				"113",
				"129",
				"130"
			]
		},
		{
			id: "113",
			x: 1107.14,
			y: 253.1,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"112",
				"114",
				"117",
				"130",
				"131"
			]
		},
		{
			id: "114",
			x: 1150.8,
			y: 228.62,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"113",
				"115",
				"117",
				"118",
				"131",
				"132"
			]
		},
		{
			id: "115",
			x: 1195.36,
			y: 202.74,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"114",
				"116",
				"118",
				"119",
				"132",
				"133"
			]
		},
		{
			id: "116",
			x: 1239.14,
			y: 179.96,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"115",
				"119",
				"120",
				"133",
				"134"
			]
		},
		{
			id: "117",
			x: 1151.62,
			y: 276.48,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"113",
				"114",
				"118",
				"123"
			]
		},
		{
			id: "118",
			x: 1194.58,
			y: 252.86,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"114",
				"115",
				"117",
				"119",
				"122",
				"123"
			]
		},
		{
			id: "119",
			x: 1238.7,
			y: 228.08,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"115",
				"116",
				"118",
				"120",
				"121",
				"122"
			]
		},
		{
			id: "120",
			x: 1282.66,
			y: 203.66,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"116",
				"119",
				"121"
			]
		},
		{
			id: "121",
			x: 1282.14,
			y: 252.16,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"119",
				"120",
				"122"
			]
		},
		{
			id: "122",
			x: 1238.36,
			y: 276.92,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"118",
				"119",
				"121",
				"123"
			]
		},
		{
			id: "123",
			x: 1194.36,
			y: 300.72,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"117",
				"118",
				"122"
			]
		},
		{
			id: "124",
			x: 808.44,
			y: 373.62,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"105",
				"106",
				"107",
				"125",
				"150",
				"151"
			]
		},
		{
			id: "125",
			x: 850.84,
			y: 349.72,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"107",
				"108",
				"124",
				"126",
				"151",
				"154"
			]
		},
		{
			id: "126",
			x: 893.4,
			y: 326,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"108",
				"109",
				"125",
				"127",
				"154",
				"155"
			]
		},
		{
			id: "127",
			x: 936.12,
			y: 301.42,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"109",
				"110",
				"126",
				"128",
				"155",
				"158"
			]
		},
		{
			id: "128",
			x: 978.38,
			y: 276.62,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"110",
				"111",
				"127",
				"129",
				"158",
				"159"
			]
		},
		{
			id: "129",
			x: 1021.54,
			y: 253.06,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"111",
				"112",
				"128",
				"130",
				"159",
				"163"
			]
		},
		{
			id: "130",
			x: 1064.44,
			y: 228.9,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"112",
				"113",
				"129",
				"131",
				"163",
				"164"
			]
		},
		{
			id: "131",
			x: 1107.86,
			y: 203.94,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"113",
				"114",
				"130",
				"132",
				"164",
				"169"
			]
		},
		{
			id: "132",
			x: 1151.26,
			y: 179.12,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"114",
				"115",
				"131",
				"133",
				"169",
				"170"
			]
		},
		{
			id: "133",
			x: 1194.68,
			y: 155.04,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"115",
				"116",
				"132",
				"134",
				"170",
				"173"
			]
		},
		{
			id: "134",
			x: 1238.62,
			y: 130.46,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"116",
				"133",
				"135",
				"173"
			]
		},
		{
			id: "135",
			x: 1239.36,
			y: 81.84,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"134",
				"136",
				"172",
				"173"
			]
		},
		{
			id: "136",
			x: 1238.74,
			y: 32.84,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"135",
				"137",
				"172"
			]
		},
		{
			id: "137",
			x: 1194.4,
			y: 8.84,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"136",
				"138",
				"172"
			]
		},
		{
			id: "138",
			x: 1150.58,
			y: 32.8,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"137",
				"139",
				"171",
				"172"
			]
		},
		{
			id: "139",
			x: 1107.82,
			y: 57.46,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"138",
				"140",
				"167",
				"168",
				"171"
			]
		},
		{
			id: "140",
			x: 1064.16,
			y: 32.62,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"139",
				"141",
				"167"
			]
		},
		{
			id: "141",
			x: 1020.78,
			y: 57.12,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"140",
				"142",
				"165",
				"167"
			]
		},
		{
			id: "142",
			x: 977.84,
			y: 81.34,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"141",
				"143",
				"161",
				"165"
			]
		},
		{
			id: "143",
			x: 935.28,
			y: 106.12,
			terrain: "water",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"142",
				"144",
				"161"
			]
		},
		{
			id: "144",
			x: 935.6,
			y: 154.92,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"143",
				"145",
				"157",
				"160",
				"161"
			]
		},
		{
			id: "145",
			x: 893.04,
			y: 179.28,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"144",
				"146",
				"156",
				"157"
			]
		},
		{
			id: "146",
			x: 850.94,
			y: 203.92,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"145",
				"147",
				"153",
				"156"
			]
		},
		{
			id: "147",
			x: 808.72,
			y: 228.32,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"146",
				"148",
				"152",
				"153"
			]
		},
		{
			id: "148",
			x: 766.22,
			y: 252.36,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"98",
				"99",
				"147",
				"149",
				"152"
			]
		},
		{
			id: "149",
			x: 766.14,
			y: 300.64,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"99",
				"100",
				"148",
				"150",
				"151",
				"152"
			]
		},
		{
			id: "150",
			x: 766.44,
			y: 349.44,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"100",
				"101",
				"105",
				"124",
				"149",
				"151"
			]
		},
		{
			id: "151",
			x: 808.28,
			y: 325.28,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"124",
				"125",
				"149",
				"150",
				"152",
				"154"
			]
		},
		{
			id: "152",
			x: 808.22,
			y: 276.68,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"147",
				"148",
				"149",
				"151",
				"153",
				"154"
			]
		},
		{
			id: "153",
			x: 850.68,
			y: 252.98,
			terrain: "park",
			minPlayers: 2,
			capacity: 2,
			neighbors: [
				"146",
				"147",
				"152",
				"154",
				"155",
				"156"
			]
		},
		{
			id: "154",
			x: 850.84,
			y: 301.58,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"125",
				"126",
				"151",
				"152",
				"153",
				"155"
			]
		},
		{
			id: "155",
			x: 893.04,
			y: 277.34,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"126",
				"127",
				"153",
				"154",
				"156",
				"158"
			]
		},
		{
			id: "156",
			x: 893.34,
			y: 228.34,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"145",
				"146",
				"153",
				"155",
				"157",
				"158"
			]
		},
		{
			id: "157",
			x: 935.68,
			y: 203.06,
			terrain: "park",
			minPlayers: 2,
			capacity: 1,
			neighbors: [
				"144",
				"145",
				"156",
				"158",
				"159",
				"160"
			]
		},
		{
			id: "158",
			x: 935.9,
			y: 253,
			terrain: "land",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"127",
				"128",
				"155",
				"156",
				"157",
				"159"
			]
		},
		{
			id: "159",
			x: 978.32,
			y: 228.18,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"128",
				"129",
				"157",
				"158",
				"160",
				"163"
			]
		},
		{
			id: "160",
			x: 978.66,
			y: 179.7,
			terrain: "water",
			minPlayers: 2,
			capacity: 0,
			neighbors: [
				"144",
				"157",
				"159",
				"161",
				"162",
				"163"
			]
		},
		{
			id: "161",
			x: 978.5,
			y: 130.64,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"142",
				"143",
				"144",
				"160",
				"162",
				"165"
			]
		},
		{
			id: "162",
			x: 1020.64,
			y: 155.28,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"160",
				"161",
				"163",
				"164",
				"165",
				"166"
			]
		},
		{
			id: "163",
			x: 1021.66,
			y: 204.62,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"129",
				"130",
				"159",
				"160",
				"162",
				"164"
			]
		},
		{
			id: "164",
			x: 1064.24,
			y: 179.68,
			terrain: "park",
			minPlayers: 4,
			capacity: 2,
			neighbors: [
				"130",
				"131",
				"162",
				"163",
				"166",
				"169"
			]
		},
		{
			id: "165",
			x: 1021.64,
			y: 105.82,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"141",
				"142",
				"161",
				"162",
				"166",
				"167"
			]
		},
		{
			id: "166",
			x: 1064.36,
			y: 130.8,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"162",
				"164",
				"165",
				"167",
				"168",
				"169"
			]
		},
		{
			id: "167",
			x: 1064.2,
			y: 81.84,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"139",
				"140",
				"141",
				"165",
				"166",
				"168"
			]
		},
		{
			id: "168",
			x: 1107.08,
			y: 105.66,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"139",
				"166",
				"167",
				"169",
				"170",
				"171"
			]
		},
		{
			id: "169",
			x: 1107.58,
			y: 155.12,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"131",
				"132",
				"164",
				"166",
				"168",
				"170"
			]
		},
		{
			id: "170",
			x: 1150.8,
			y: 131.3,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"132",
				"133",
				"168",
				"169",
				"171",
				"173"
			]
		},
		{
			id: "171",
			x: 1152.58,
			y: 81.66,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"138",
				"139",
				"168",
				"170",
				"172",
				"173"
			]
		},
		{
			id: "172",
			x: 1194.68,
			y: 57.52,
			terrain: "park",
			minPlayers: 4,
			capacity: 1,
			neighbors: [
				"135",
				"136",
				"137",
				"138",
				"171",
				"173"
			]
		},
		{
			id: "173",
			x: 1194.52,
			y: 106.98,
			terrain: "land",
			minPlayers: 4,
			capacity: 0,
			neighbors: [
				"133",
				"134",
				"135",
				"170",
				"171",
				"172"
			]
		}
	]
}, b = [
	"sakura",
	"chochin",
	"onigiri"
], x = [
	"fruit",
	"rain",
	"bicycle",
	"dango",
	"tea",
	"akkorokamui",
	"taiyaki",
	"takoyaki"
], S = {
	sakura: "games.hanami.sakura",
	chochin: "games.hanami.chochin",
	onigiri: "games.hanami.onigiri"
}, re = {
	torii: "games.hanami.torii",
	fruit: "games.hanami.fruit",
	rain: "games.hanami.rain",
	bicycle: "games.hanami.bicycle",
	dango: "games.hanami.dango",
	tea: "games.hanami.tea",
	akkorokamui: "games.hanami.akkorokamui",
	taiyaki: "games.hanami.taiyaki",
	takoyaki: "games.hanami.takoyaki"
}, ie = {
	torii: "games.hanami.toriiText",
	fruit: "games.hanami.toriiText",
	rain: "games.hanami.rainText",
	bicycle: "games.hanami.bicycleText",
	dango: "games.hanami.dangoText",
	tea: "games.hanami.teaText",
	akkorokamui: "games.hanami.akkorokamuiText",
	taiyaki: "games.hanami.taiyakiText",
	takoyaki: "games.hanami.takoyakiText"
}, C = [
	{
		kind: "move",
		strength: 0,
		fast: !1
	},
	{
		kind: "copy",
		strength: 0,
		fast: !1
	},
	...["sakura", "chochin"].flatMap((e) => [
		2,
		3,
		4
	].map((t) => ({
		kind: e,
		strength: t,
		fast: !1
	}))),
	...[
		1,
		1,
		2
	].map((e) => ({
		kind: "wild",
		strength: e,
		fast: !0,
		boat: !0
	})),
	...[
		2,
		3,
		4
	].map((e) => ({
		kind: "onigiri",
		strength: e,
		fast: !1
	})),
	{
		kind: "wild",
		strength: 1,
		fast: !0,
		action: "draw"
	},
	...[
		1,
		1,
		1,
		2,
		2,
		3
	].map((e) => ({
		kind: "wild",
		strength: e,
		fast: !1
	})),
	{
		kind: "wild",
		strength: 3,
		fast: !0,
		action: "cover"
	}
], ae = [
	1,
	14,
	21
], oe = {
	sakura: S.sakura,
	chochin: S.chochin,
	onigiri: S.onigiri,
	wild: "games.hanami.cat",
	move: "games.hanami.move",
	copy: "games.hanami.copy",
	boat: "games.hanami.boat",
	draw: "games.hanami.draw",
	cover: "games.hanami.cover"
};
function w(e) {
	let t = C[e];
	return oe[t.action ?? (t.boat ? "boat" : t.kind)];
}
var se = [
	"#dd614e",
	"#4289ba",
	"#43a48b",
	"#d3a72d"
], T = {
	id: "hanami",
	tier: "alpha",
	mechanics: [
		"tile-placement",
		"area-control",
		"hand-management"
	],
	interactionTags: [],
	nameKey: "games.hanami.name",
	descKey: "games.hanami.desc",
	rulesKey: "games.hanami.rules",
	icon: "🌸",
	iconImg: "games/hanami.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#b43a71",
	releasedAt: "2026-11-06T17:57:52+08:00",
	search: {
		py: "hua jian",
		init: "hj"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/17811121980414399326/7F876EE7EECD2C2A0513DAAD2E0B8D95F4B6F1F4/" }
}, E = t.enum([
	"sakura",
	"chochin",
	"onigiri"
]), D = t.enum([
	"torii",
	"fruit",
	"rain",
	"bicycle",
	"dango",
	"tea",
	"akkorokamui",
	"taiyaki",
	"takoyaki"
]), O = t.int().min(0).max(21), k = t.object({
	map: t.enum(["nihon", "tokyo"]).default("nihon"),
	specialTiles: t.boolean().default(!1),
	specialAbilities: t.boolean().default(!1),
	startStrong: t.boolean().default(!1),
	tokenDraft: t.boolean().default(!1)
}).default({
	map: "nihon",
	specialTiles: !1,
	specialAbilities: !1,
	startStrong: !1,
	tokenDraft: !1
}), A = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		tile: O,
		at: t.string(),
		from: t.string().optional(),
		dir: t.string().optional()
	}),
	t.object({
		type: t.literal("ability"),
		a: t.string().optional(),
		b: t.string().optional(),
		tile: O.optional(),
		dir: t.string().optional(),
		token: E.optional(),
		otherToken: E.optional()
	}),
	t.object({
		type: t.literal("prepare"),
		ability: D,
		hand: t.array(O).max(5)
	}),
	t.object({
		type: t.literal("draft"),
		at: t.string(),
		token: E
	}),
	t.object({ type: t.literal("end") }),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), j = t.object({
	owner: t.string(),
	tile: O,
	down: t.boolean(),
	dir: t.string().nullable(),
	facing: t.number().nullable().optional()
}), M = t.object({
	sakura: t.int().nonnegative(),
	chochin: t.int().nonnegative(),
	onigiri: t.int().nonnegative()
}), ce = t.object({
	config: k,
	phase: t.enum([
		"draft",
		"prepare",
		"play",
		"resolve",
		"done"
	]),
	turn: t.string(),
	round: t.int(),
	players: t.array(t.object({
		rid: t.string(),
		deck: t.int().nonnegative(),
		hand: t.int().nonnegative(),
		ready: t.boolean(),
		ability: D.nullable(),
		used: t.boolean(),
		captures: M.nullable()
	})),
	board: t.record(t.string(), j),
	parks: t.record(t.string(), t.array(E)),
	ties: t.array(E),
	supply: M,
	normalPlaced: t.boolean(),
	placed: t.int().nonnegative(),
	last: t.object({
		park: t.string(),
		token: E,
		winner: t.string().nullable(),
		strengths: t.record(t.string(), t.number())
	}).nullable()
}), N = t.object({
	hand: t.array(O),
	pool: t.array(O),
	choices: t.array(D),
	captures: M
}), P = {
	place: 420,
	capture: 950,
	ability: 700
}, F = () => ({
	sakura: 0,
	chochin: 0,
	onigiri: 0
});
function I(e, t) {
	return y[e.map].filter((e) => e.minPlayers <= t);
}
function le(e, t, n = []) {
	let r = e[t];
	if (!r || r.down || n.includes(t)) return {
		kind: "wild",
		strength: 0
	};
	let i = C[r.tile];
	return i.kind === "copy" ? r.dir ? le(e, r.dir, [...n, t]) : {
		kind: "wild",
		strength: 0
	} : i;
}
function L(e, t, n, r) {
	let i = e[n];
	if (C[i.tile].kind === "copy") {
		let e = t.find((e) => e.id === n), a = t.find((e) => e.id === i.dir), o = t.find((e) => e.id === r), s = i.facing ?? (a ? Math.atan2(a.y - e.y, a.x - e.x) : 0);
		i.facing = s, i.dir = t.find((e) => o.neighbors.includes(e.id) && Math.hypot(e.x - o.x - 49 * Math.cos(s), e.y - o.y - 49 * Math.sin(s)) < 5)?.id ?? null;
	}
	e[r] = i, delete e[n];
}
function ue(e, t, n) {
	let r = Object.fromEntries(e.players.map((e) => [e.rid, 0]));
	for (let i of t.neighbors) {
		let t = e.board[i];
		if (!t) continue;
		let a = le(e.board, i);
		(a.kind === "wild" || a.kind === n) && (r[t.owner] += a.strength);
	}
	return r;
}
function R(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function z(e) {
	e.phase = e.ready.length === e.players.length ? "play" : "prepare", e.turn = 0;
}
function B(e, t, n) {
	let r = {
		config: k.parse(e),
		players: t,
		phase: "play",
		turn: 0,
		round: 1,
		seed: n,
		cursor: 0,
		hands: {},
		decks: {},
		choices: {},
		abilities: {},
		ready: [],
		used: [],
		board: {},
		parks: {},
		ties: [],
		captures: {},
		supply: F(),
		normalPlaced: !1,
		placed: 0,
		queue: [],
		last: null,
		passed: 0
	}, i = R(r, [...x]);
	for (let e of t) r.decks[e] = R(r, C.map((e, t) => t).filter((e) => r.config.specialTiles || !ae.includes(e))), r.hands[e] = r.config.startStrong ? [] : r.decks[e].splice(0, 5), r.choices[e] = r.config.specialAbilities ? i.splice(0, 2) : ["torii"], r.abilities[e] = r.choices[e][0], r.captures[e] = F(), !r.config.startStrong && !r.config.specialAbilities && r.ready.push(e);
	let a = I(r.config, t.length).filter((e) => e.terrain === "park"), o = a.find((e) => e.capacity === 3), s = t.length === 2 ? 7 : t.length === 3 ? 10 : 13;
	r.supply = {
		sakura: s - 1,
		chochin: s - 1,
		onigiri: s - 1
	}, r.parks[o.id] = [...b];
	for (let e of a) r.parks[e.id] ??= [];
	if (r.config.tokenDraft) r.phase = "draft";
	else {
		for (let e of a.filter((e) => e.capacity === 2)) {
			let t = R(r, [...b]);
			r.parks[e.id] = t.slice(0, 2);
			for (let t of r.parks[e.id]) r.supply[t]--;
		}
		let e = R(r, b.flatMap((e) => Array(r.supply[e]).fill(e)));
		for (let t of a.filter((e) => e.capacity === 1)) r.parks[t.id] = [e.pop()];
		r.supply = F(), z(r);
	}
	return { state: r };
}
function V(e, t) {
	return {
		public: {
			config: e.config,
			phase: e.phase,
			turn: e.players[e.turn],
			round: e.round,
			players: e.players.map((t) => ({
				rid: t,
				deck: e.decks[t].length,
				hand: e.hands[t].length,
				ready: e.ready.includes(t),
				ability: e.ready.includes(t) ? e.abilities[t] : null,
				used: e.used.includes(t),
				captures: e.phase === "done" ? e.captures[t] : null
			})),
			board: e.board,
			parks: e.parks,
			ties: e.ties,
			supply: e.supply,
			normalPlaced: e.normalPlaced,
			placed: e.placed,
			last: e.last
		},
		private: {
			hand: e.hands[t] ?? [],
			pool: e.phase === "prepare" && e.config.startStrong && !e.ready.includes(t) ? e.decks[t] ?? [] : [],
			choices: e.phase === "prepare" && !e.ready.includes(t) ? e.choices[t] ?? [] : [],
			captures: e.captures[t] ?? F()
		}
	};
}
function H(e, t, n, r) {
	let i = I(e.config, e.players.length), a = [];
	for (let o of t) {
		let t = C[o];
		if ((r !== "dango" || [1, 2].includes(t.strength)) && (r || !e.normalPlaced || t.fast)) for (let s of i) {
			let c = e.board[s.id];
			if (t.action === "cover") {
				if (!c || c.owner !== n || r === "taiyaki" && s.terrain !== "water") continue;
			} else if (c || s.terrain === "park" || (r === "taiyaki" || t.boat ? s.terrain !== "water" : s.terrain !== "land")) continue;
			if (t.kind === "move") {
				if (r === "taiyaki") continue;
				for (let [t, r] of Object.entries(e.board)) r.owner === n && !C[r.tile].fast && i.find((e) => e.id === t)?.terrain === "land" && a.push({
					type: "place",
					tile: o,
					at: s.id,
					from: t
				});
			} else if (t.kind === "copy") for (let e of s.neighbors) a.push({
				type: "place",
				tile: o,
				at: s.id,
				dir: e
			});
			else a.push({
				type: "place",
				tile: o,
				at: s.id
			});
		}
	}
	return a;
}
function de(e, t, n, r = !0) {
	let i = e.players.find((e) => e.rid === n);
	if (!i || e.phase === "done" || e.phase === "resolve" || e.phase === "prepare" || e.turn !== n) return [];
	let a = I(e.config, e.players.length);
	if (e.phase === "draft") {
		let t = a.filter((t) => t.terrain === "park" && e.parks[t.id].length < t.capacity), n = Math.max(...t.map((e) => e.capacity));
		return t.filter((e) => e.capacity === n).flatMap((t) => b.filter((n) => e.supply[n] > 0 && !e.parks[t.id].includes(n)).map((e) => ({
			type: "draft",
			at: t.id,
			token: e
		})));
	}
	let o = H(e, t.hand, n);
	if (e.placed > 0 && o.push({ type: "end" }), r && !i.used && e.placed === 0) {
		let r = Object.entries(e.board);
		switch (i.ability) {
			case "torii":
			case "fruit": {
				let t = Object.entries(e.parks).flatMap(([e, t]) => t.map((t) => ({
					a: e,
					token: t
				})));
				for (let n = 0; n < t.length; n++) for (let r = n + 1; r < t.length; r++) {
					let i = t[n], a = t[r];
					i.a !== a.a && i.token !== a.token && !e.parks[i.a].includes(a.token) && !e.parks[a.a].includes(i.token) && (o.push({
						type: "ability",
						a: i.a,
						token: i.token,
						b: a.a,
						otherToken: a.token
					}), o.push({
						type: "ability",
						a: a.a,
						token: a.token,
						b: i.a,
						otherToken: i.token
					}));
				}
				break;
			}
			case "rain":
			case "akkorokamui":
				for (let [e, t] of r) {
					let n = C[t.tile];
					!t.down && (i.ability === "rain" ? b.includes(n.kind) && [1, 2].includes(n.strength) : n.boat) && o.push({
						type: "ability",
						a: e
					});
				}
				break;
			case "bicycle":
				for (let [t] of r) if (a.find((e) => e.id === t).terrain === "land") for (let n of a.filter((n) => n.terrain === "land" && !e.board[n.id] && n.neighbors.includes(t))) o.push({
					type: "ability",
					a: t,
					b: n.id
				});
				break;
			case "tea":
				for (let [e, t] of r) if (t.owner === n && b.includes(C[t.tile].kind)) for (let [n, i] of r) e !== n && C[t.tile].kind === C[i.tile].kind && o.push({
					type: "ability",
					a: e,
					b: n
				});
				break;
			case "dango":
			case "taiyaki":
				for (let r of H(e, t.hand, n, i.ability)) r.type === "place" && o.push({
					type: "ability",
					tile: r.tile,
					a: r.at,
					b: r.from,
					dir: r.dir
				});
				break;
			case "takoyaki": for (let n of b) if (t.captures[n] > 0) for (let t of b) n !== t && e.ties.includes(t) && o.push({
				type: "ability",
				token: n,
				otherToken: t
			});
		}
	}
	return !o.some((e) => e.type === "place") && e.placed === 0 && o.push({ type: "pass" }), o;
}
function U(e, t, n, r, i, a) {
	if (e.hands[t].splice(e.hands[t].indexOf(n), 1), i) L(e.board, I(e.config, e.players.length), i, r), e.board[i] = {
		owner: t,
		tile: n,
		down: !1,
		dir: null
	};
	else {
		let i = I(e.config, e.players.length), o = i.find((e) => e.id === r), s = i.find((e) => e.id === a);
		e.board[r] = {
			owner: t,
			tile: n,
			down: !1,
			dir: a ?? null,
			...s ? { facing: Math.atan2(s.y - o.y, s.x - o.x) } : {}
		};
	}
	C[n].action === "draw" && e.decks[t].length && e.hands[t].push(e.decks[t].shift());
}
function W(e) {
	return e.ties.length >= 4 || b.some((t) => !Object.values(e.parks).some((e) => e.includes(t)));
}
function fe(e, t, n, r, i) {
	return {
		kind: "place",
		rid: t,
		data: {
			at: i ?? r,
			tile: n,
			player: e.players.indexOf(t),
			...i ? { moved: {
				from: i,
				at: r,
				piece: e.board[i],
				player: e.players.indexOf(e.board[i].owner)
			} } : {}
		}
	};
}
function pe(e) {
	if (W(e) || e.passed >= e.players.length) {
		e.phase = "done";
		return;
	}
	let t = e.players[e.turn];
	for (; e.hands[t].length < 5 && e.decks[t].length;) e.hands[t].push(e.decks[t].shift());
	e.turn = (e.turn + 1) % e.players.length, e.round++, e.phase = "play", e.normalPlaced = !1, e.placed = 0;
}
function G(e) {
	let t = e.queue[0];
	if (!t) return pe(e), null;
	let n = e.parks[t].shift(), r = I(e.config, e.players.length).find((e) => e.id === t), i = ue(V(e, "").public, r, n), a = Math.max(...Object.values(i)), o = e.players.filter((e) => i[e] === a), s = a > 0 && o.length === 1 ? o[0] : null;
	return s ? e.captures[s][n]++ : e.ties.push(n), e.last = {
		park: t,
		token: n,
		winner: s,
		strengths: i
	}, e.parks[t].length || e.queue.shift(), {
		kind: "capture",
		rid: s ?? void 0,
		data: e.last
	};
}
function K(e, t, { by: n }) {
	if (t.type === "tick") {
		if (e.phase !== "resolve") return { state: e };
		let t = structuredClone(e), n = G(t);
		return {
			state: t,
			fx: n ? [n] : []
		};
	}
	let { public: r, private: i } = V(e, n);
	if (t.type === "prepare") {
		if (e.phase !== "prepare" || !e.players.includes(n) || e.ready.includes(n) || !e.choices[n].includes(t.ability)) return { code: "games.hanami.errTurn" };
		if (e.config.startStrong && (t.hand.length !== 5 || new Set(t.hand).size !== 5 || t.hand.some((t) => !e.decks[n].includes(t))) || !e.config.startStrong && t.hand.length) return { code: "games.hanami.errSelection" };
		let r = structuredClone(e);
		return r.abilities[n] = t.ability, r.ready.push(n), r.config.startStrong && (r.hands[n] = t.hand, r.decks[n] = R(r, r.decks[n].filter((e) => !t.hand.includes(e)))), r.ready.length === r.players.length && (r.phase = "play"), { state: r };
	}
	if (!de(r, i, n).some((e) => e.type === t.type && Object.entries(t).every(([t, n]) => e[t] === n) && Object.entries(e).every(([e, n]) => t[e] === n))) return { code: "games.hanami.errSelection" };
	let a = structuredClone(e);
	if (t.type === "draft") return a.parks[t.at].push(t.token), a.supply[t.token]--, a.turn = (a.turn + 1) % a.players.length, b.every((e) => a.supply[e] === 0) && z(a), {
		state: a,
		fx: [{
			kind: "place",
			rid: n,
			data: { at: t.at }
		}]
	};
	if (t.type === "place") return U(a, n, t.tile, t.at, t.from, t.dir), a.placed++, a.passed = 0, C[t.tile].fast || (a.normalPlaced = !0), {
		state: a,
		fx: [fe(e, n, t.tile, t.at, t.from)]
	};
	if (t.type === "ability") {
		let r = a.abilities[n], i = t.a, o = t.b;
		(r === "torii" || r === "fruit") && (a.parks[i][a.parks[i].indexOf(t.token)] = t.otherToken, a.parks[o][a.parks[o].indexOf(t.otherToken)] = t.token), (r === "rain" || r === "akkorokamui") && (a.board[i].down = !0), r === "bicycle" && L(a.board, I(a.config, a.players.length), i, o), r === "tea" && ([a.board[i], a.board[o]] = [a.board[o], a.board[i]]), (r === "dango" || r === "taiyaki") && U(a, n, t.tile, i, t.b, t.dir), r === "takoyaki" && (a.captures[n][t.token]--, a.captures[n][t.otherToken]++, a.ties[a.ties.indexOf(t.otherToken)] = t.token), a.used.push(n);
		let s = r === "bicycle" || r === "tea" ? [{
			from: i,
			at: o,
			piece: e.board[i],
			player: a.players.indexOf(e.board[i].owner)
		}, ...r === "tea" ? [{
			from: o,
			at: i,
			piece: e.board[o],
			player: a.players.indexOf(e.board[o].owner)
		}] : []] : [];
		return {
			state: a,
			fx: r === "dango" || r === "taiyaki" ? [fe(e, n, t.tile, i, t.b)] : [{
				kind: "ability",
				rid: n,
				data: {
					at: i,
					to: o,
					ability: r,
					moves: s
				}
			}]
		};
	}
	return t.type === "pass" ? a.passed++ : a.passed = 0, a.queue = I(a.config, a.players.length).filter((e) => e.terrain === "park" && a.parks[e.id].length && e.neighbors.filter((e) => I(a.config, a.players.length).find((t) => t.id === e)?.terrain === "land").every((e) => a.board[e])).map((e) => e.id), a.phase = "resolve", { state: a };
}
function me(e, t) {
	let n = Object.fromEntries(e.map((e) => [e, []]));
	for (let r of b) {
		let i = Math.max(...e.map((e) => t[e][r])), a = e.filter((e) => t[e][r] === i);
		a.length === 1 && n[a[0]].push(r);
	}
	let r = (e) => b.reduce((n, r) => n + t[e][r], 0), i = (e) => b.filter((t) => !n[e].includes(t)).reduce((n, r) => n + t[e][r], 0), a = (e, t) => n[t].length - n[e].length || (n[e].length === 1 ? i(t) - i(e) : 0) || r(t) - r(e), o = [...e].sort(a);
	return {
		medals: n,
		ranking: o,
		winner: o.filter((e) => a(e, o[0]) === 0),
		scores: Object.fromEntries(e.map((e) => [e, n[e].length]))
	};
}
var he = {
	meta: T,
	saveCompatibility: { version: "1" },
	schemas: {
		action: A,
		config: k,
		publicView: ce,
		privateView: N
	},
	setup: B,
	reduce: K,
	viewFor: V,
	status: (e) => e.phase === "done" ? {
		phase: "done",
		...me(e.players, e.captures)
	} : { phase: e.phase },
	nextTickIn: (e) => e.phase === "resolve" ? P.capture : null
};
//#endregion
//#region src/games/hanami/icons.tsx
function q({ kind: e, size: t = 28 }) {
	return /* @__PURE__ */ m("svg", {
		width: t,
		height: t,
		viewBox: "0 0 60 60",
		"aria-hidden": "true",
		children: [
			e === "sakura" && /* @__PURE__ */ m("g", {
				fill: "#fff4ed",
				stroke: "#d56d93",
				strokeWidth: "1.4",
				children: [[
					0,
					72,
					144,
					216,
					288
				].map((e) => /* @__PURE__ */ p("path", {
					transform: `rotate(${e} 30 30)`,
					d: "M30 31C12 25 16 8 25 10L30 15L35 10C45 12 47 25 30 31Z"
				}, e)), /* @__PURE__ */ p("circle", {
					cx: "30",
					cy: "30",
					r: "5",
					fill: "#e5a733"
				})]
			}),
			e === "chochin" && /* @__PURE__ */ m("g", { children: [
				/* @__PURE__ */ p("path", {
					d: "M20 7H40V13H20Z M20 48H40V54H20Z",
					fill: "#67445f"
				}),
				/* @__PURE__ */ p("rect", {
					x: "12",
					y: "12",
					width: "36",
					height: "38",
					rx: "12",
					fill: "#ff5c52",
					stroke: "#fff1dd",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ p("path", {
					d: "M17 21H43M16 40H44M25 15V47M35 15V47",
					stroke: "#fff0db",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ p("path", {
					d: "M25 27H36V34H25Z",
					fill: "#fff1dd"
				})
			] }),
			e === "onigiri" && /* @__PURE__ */ m("g", { children: [
				/* @__PURE__ */ p("path", {
					d: "M7 43Q3 49 14 51H47Q56 49 51 40L36 12Q30 2 24 13Z",
					fill: "#fff5df",
					stroke: "#c8b59e",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ p("path", {
					d: "M23 32H38V51H23Z",
					fill: "#333c40"
				}),
				/* @__PURE__ */ p("path", {
					d: "M19 29L21 31M34 22L36 24M40 33L42 35M28 17L29 19",
					stroke: "#a98766"
				})
			] }),
			e === "wild" && /* @__PURE__ */ m("g", {
				fill: "#ffdf87",
				stroke: "#b47346",
				strokeWidth: "1.5",
				children: [
					/* @__PURE__ */ p("path", { d: "M17 31Q10 18 17 7L26 14H36L44 7Q51 22 44 31L47 48Q30 58 13 48Z" }),
					/* @__PURE__ */ p("path", {
						d: "M19 23H24M36 23H41M27 30Q30 34 34 30",
						fill: "none",
						stroke: "#705459",
						strokeWidth: "2.5"
					}),
					/* @__PURE__ */ p("circle", {
						cx: "30",
						cy: "43",
						r: "9",
						fill: "#e8b53a"
					}),
					/* @__PURE__ */ p("path", { d: "M10 40V23Q4 14 4 26V40Z" })
				]
			}),
			e === "boat" && /* @__PURE__ */ m("g", { children: [
				/* @__PURE__ */ p("path", {
					d: "M5 39H55L45 52H16Z",
					fill: "#d89748",
					stroke: "#fff0d5",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ p("path", {
					d: "M14 36V16H46V36M10 15Q30 3 50 15Z",
					fill: "#f1cc83",
					stroke: "#705970",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ p("path", {
					d: "M16 42H46",
					stroke: "#934e53",
					strokeWidth: "3"
				})
			] }),
			e === "move" && /* @__PURE__ */ p("path", {
				d: "M4 29L25 23L29 5L34 5L34 23L55 30L55 35L34 32L34 47L40 52V56L30 52L20 56V52L26 47V32L4 35Z",
				fill: "#f9eeda",
				stroke: "#8e7099",
				strokeWidth: "2"
			}),
			e === "copy" && /* @__PURE__ */ m("g", { children: [
				/* @__PURE__ */ p("rect", {
					x: "15",
					y: "5",
					width: "31",
					height: "50",
					rx: "4",
					fill: "#dc755f",
					stroke: "#fbeedb",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ p("rect", {
					x: "20",
					y: "11",
					width: "17",
					height: "23",
					fill: "#6fc4c3"
				}),
				/* @__PURE__ */ p("path", {
					d: "M21 40H39V48H21Z",
					fill: "#54465b"
				}),
				/* @__PURE__ */ p("path", {
					d: "M48 18L58 28L48 38",
					fill: "none",
					stroke: "#fff6dc",
					strokeWidth: "3"
				})
			] }),
			e === "torii" && /* @__PURE__ */ m("g", {
				fill: "#ed6554",
				children: [/* @__PURE__ */ p("path", { d: "M10 21H17V55H10Z M43 21H50V55H43Z M7 19H53V25H7Z M5 9Q30 17 55 9V15Q30 23 5 15Z" }), /* @__PURE__ */ p("path", {
					d: "M3 5Q30 12 57 5L54 11Q30 19 6 11Z",
					fill: "#614963"
				})]
			})
		]
	});
}
function ge({ id: e, down: t = !1, direction: n }) {
	let r = C[e];
	return /* @__PURE__ */ p("span", {
		className: "hanami-tile-face",
		"data-down": t || void 0,
		children: t ? /* @__PURE__ */ p(q, {
			kind: "torii",
			size: 28
		}) : /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p(q, {
				kind: r.boat ? "boat" : r.kind,
				size: 36
			}),
			/* @__PURE__ */ p("b", { children: r.strength > 0 ? r.strength : r.kind === "copy" ? n ?? "↗" : "↔" }),
			r.fast && /* @__PURE__ */ p("small", { children: "➟" }),
			r.action && /* @__PURE__ */ p("i", { children: r.action === "draw" ? "＋" : "▣" })
		] })
	});
}
function _e({ id: e, down: t, direction: n }) {
	let r = C[e];
	return /* @__PURE__ */ m("g", {
		className: "hanami-board-face",
		pointerEvents: "none",
		children: [/* @__PURE__ */ p("g", {
			transform: "translate(8 0)",
			children: /* @__PURE__ */ p(q, {
				kind: t ? "torii" : r.boat ? "boat" : r.kind,
				size: 28
			})
		}), !t && /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p("text", {
				x: "22",
				y: "43",
				textAnchor: "middle",
				fontSize: "15",
				fontWeight: "900",
				fill: "#fff7de",
				children: r.strength > 0 ? r.strength : r.kind === "copy" ? n ?? "↗" : "↔"
			}),
			r.fast && /* @__PURE__ */ p("text", {
				x: "1",
				y: "9",
				fontSize: "12",
				fill: "#fff6da",
				children: "➟"
			}),
			r.action && /* @__PURE__ */ p("text", {
				x: "40",
				y: "40",
				textAnchor: "end",
				fontSize: "11",
				fill: "#fff5cb",
				children: r.action === "draw" ? "＋" : "▣"
			})
		] })]
	});
}
var ve = (e) => ({ "--hanami-player": e });
//#endregion
//#region src/games/hanami/view-player.tsx
function J(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Y, {
		...e,
		pub: t,
		priv: n
	});
}
var ye = {
	tile: null,
	abilityMode: !1,
	first: null,
	preview: null,
	choices: [],
	startHand: [],
	startAbility: null
};
function Y({ pub: e, priv: t, myRid: i, members: d, send: h }) {
	let g = c(), _ = (e) => d.find((t) => t.rid === e)?.name ?? e, ne = (e) => n[(d.find((t) => t.rid === e)?.colorIndex ?? 0) % n.length].hex, v = a(() => I(e.config, e.players.length), [e.config, e.players.length]), y = a(() => t ? de(e, t, i) : [], [
		e,
		t,
		i
	]), x = `${i}:${e.phase}:${e.round}:${e.placed}:${e.players.find((e) => e.rid === i)?.used}`, [ae, oe] = s({
		...ye,
		scope: x
	}), [T, E] = s(0);
	ae.scope !== x && oe({
		...ye,
		scope: x
	});
	let { tile: D, abilityMode: O, first: k, preview: A, choices: j, startHand: M, startAbility: ce } = ae.scope === x ? ae : ye, N = `${i}:${e.config.map}:${e.players.map((e) => e.rid).join(":")}`, [P, F] = s({
		scope: N,
		cell: null
	});
	P.scope !== N && F({
		scope: N,
		cell: null
	});
	let L = P.scope === N ? P.cell : null, R = (e) => F({
		scope: N,
		cell: e
	}), z = (e) => oe((t) => ({
		...t.scope === x ? t : ye,
		...e,
		scope: x
	})), B = (e) => z({ tile: e }), V = (e) => z({ abilityMode: e }), H = (e) => z({ first: e }), U = (e) => z({ preview: e }), W = (e) => z({ choices: e }), fe = (e) => z({ startHand: e }), pe = (e) => z({ startAbility: e }), G = e.players.find((e) => e.rid === i), K = e.turn === i && e.phase !== "resolve", { ref: me } = ee("hand"), he = o(null), _e = ne(i), J = G?.ability ?? "torii", Y = () => {
		H(null), U(null), W([]), R(null);
	}, Se = () => {
		A && (h(A), Y(), B(null), V(!1));
	}, X = y.filter((e) => O ? e.type === "ability" && (e.tile === void 0 || e.tile === D) : e.type === "place" && e.tile === D || e.type === "draft"), Z = O ? [
		"torii",
		"fruit",
		"bicycle",
		"tea"
	].includes(J) || D !== null && C[D].kind === "copy" : D !== null && ["move", "copy"].includes(C[D].kind), Ce = !O && D !== null && C[D].kind === "move" ? "from" : O ? "a" : "at", we = D !== null && C[D].kind === "copy" ? "dir" : O ? "b" : "at", Q = (e, t) => e[t];
	k && Z && (X = X.filter((e) => Q(e, Ce) === k));
	let Te = k && Z ? we : Ce, Ee = new Set(X.map((e) => Q(e, Te)).filter((e) => !!e)), De = (e) => {
		if (Ee.has(e)) {
			if (Z && !k) {
				H(e), R(null);
				return;
			}
			let t = X.filter((t) => Q(t, Te) === e);
			t.length === 1 ? U(t[0]) : W(t), R(null);
		} else R(e), W([]);
	}, Oe = Math.min(...v.map((e) => e.x)) - 38, ke = Math.min(...v.map((e) => e.y)) - 38, Ae = Math.max(...v.map((e) => e.x)) - Oe + 38, je = Math.max(...v.map((e) => e.y)) - ke + 38, $ = v.find((e) => e.id === L), Me = A && (A.type === "place" || A.type === "draft" ? A.at : A.type === "ability" ? A.a : void 0), Ne = e.phase === "resolve" ? g("games.hanami.resolving") : e.phase === "prepare" ? g("games.hanami.preparePrompt") : K ? e.phase === "draft" ? g("games.hanami.draftPrompt") : O ? g(ie[J]) : k ? g(D !== null && C[D].kind === "copy" ? "games.hanami.copyPrompt" : "games.hanami.destinationPrompt") : D === 0 ? g("games.hanami.movePrompt") : D === null ? e.placed > 0 ? g(y.some((e) => e.type === "place") ? "games.hanami.continuePrompt" : "games.hanami.endPrompt") : g("games.hanami.turnPrompt") : g("games.hanami.placePrompt") : g("games.hanami.waiting", { name: _(e.turn) }), Pe = (e) => e.type === "draft" ? g(S[e.token]) : e.type === "ability" && e.token ? `${g(S[e.token])} ↔ ${g(S[e.otherToken])}` : g("games.hanami.confirm"), Fe = (t) => {
		let n = e.board[t];
		return g(n.down ? "games.hanami.flippedTile" : "games.hanami.placedTile", {
			name: _(n.owner),
			tile: g(w(n.tile)),
			n: le(e.board, t).strength
		});
	};
	return /* @__PURE__ */ p("div", {
		className: "hanami-screen",
		style: ve(_e),
		"data-map": e.config.map,
		children: /* @__PURE__ */ p(te, {
			adaptive: !0,
			scroll: !1,
			className: "hanami-layout",
			actionsHeight: "hanami-actions-height",
			banner: /* @__PURE__ */ m("header", {
				className: "hanami-header",
				children: [
					/* @__PURE__ */ m("div", {
						className: "hanami-heading",
						children: [
							/* @__PURE__ */ p(q, {
								kind: "sakura",
								size: 26
							}),
							/* @__PURE__ */ p("strong", { children: g("games.hanami.name") }),
							/* @__PURE__ */ p("span", { children: g(e.config.map === "nihon" ? "games.hanami.nihon" : "games.hanami.tokyo") }),
							/* @__PURE__ */ p("small", { children: g("games.hanami.turnNumber", { n: e.round }) })
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "hanami-players",
						children: e.players.map((t) => /* @__PURE__ */ m("div", {
							className: "hanami-player",
							"data-active": t.rid === e.turn || void 0,
							style: ve(ne(t.rid)),
							children: [
								/* @__PURE__ */ p("i", { children: /* @__PURE__ */ p("img", {
									src: r[(d.find((e) => e.rid === t.rid)?.avatar ?? 0) % r.length],
									alt: "",
									draggable: !1,
									style: {
										width: "1.75em",
										height: "1.75em",
										maxWidth: "100%",
										maxHeight: "100%",
										display: "block",
										objectFit: "contain",
										pointerEvents: "none",
										borderRadius: "inherit"
									}
								}) }),
								/* @__PURE__ */ m("span", { children: [_(t.rid), t.rid === i && /* @__PURE__ */ m("small", { children: [" · ", g("games.hanami.you")] })] }),
								/* @__PURE__ */ p("small", { children: g("games.hanami.deckCount", { n: t.deck }) }),
								/* @__PURE__ */ p("b", {
									title: t.ability ? g(re[t.ability]) : void 0,
									children: t.used ? "○" : "●"
								}),
								/* @__PURE__ */ p(be, { rid: t.rid })
							]
						}, t.rid))
					}),
					/* @__PURE__ */ p("div", {
						className: "hanami-prompt",
						role: "status",
						children: Ne
					})
				]
			}),
			actions: /* @__PURE__ */ p("div", {
				className: "hanami-controls",
				children: e.phase === "prepare" && !G?.ready ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
					className: "hanami-prep-abilities",
					children: t?.choices.map((e) => /* @__PURE__ */ m("button", {
						className: "hanami-ability-choice",
						"data-selected": (ce ?? t.choices[0]) === e,
						onClick: () => pe(e),
						children: [/* @__PURE__ */ p("b", { children: g(re[e]) }), /* @__PURE__ */ p("small", { children: g(ie[e]) })]
					}, e))
				}), /* @__PURE__ */ p("button", {
					className: "hanami-primary",
					disabled: e.config.startStrong && M.length !== 5,
					onClick: () => h({
						type: "prepare",
						ability: ce ?? t?.choices[0],
						hand: M
					}),
					children: e.config.startStrong ? g("games.hanami.ready", { n: M.length }) : g("games.hanami.readyPlain")
				})] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
					className: "hanami-hand",
					ref: me,
					children: (t?.hand ?? []).map((t) => /* @__PURE__ */ m("button", {
						className: "hanami-hand-tile",
						style: ve(_e),
						"data-selected": D === t || void 0,
						disabled: !K || e.phase !== "play" || !O && !y.some((e) => e.type === "place" && e.tile === t),
						onClick: () => {
							Y(), B(D === t ? null : t);
						},
						"aria-label": g("games.hanami.selectTile", {
							tile: g(w(t)),
							n: C[t].strength
						}),
						children: [/* @__PURE__ */ p(ge, { id: t }), /* @__PURE__ */ p("span", { children: g(w(t)) })]
					}, t))
				}), /* @__PURE__ */ m("div", {
					className: "hanami-action-row",
					children: [
						G?.ability && /* @__PURE__ */ m("button", {
							className: "hanami-ability-button",
							disabled: !K || e.phase !== "play" || G.used || e.placed > 0 || !y.some((e) => e.type === "ability"),
							"data-selected": O,
							onClick: () => {
								Y(), B(null), V(!O);
							},
							title: g(ie[J]),
							children: [/* @__PURE__ */ p(q, {
								kind: "torii",
								size: 23
							}), /* @__PURE__ */ m("span", { children: [g(re[J]), G.used && ` · ${g("games.hanami.used")}`] })]
						}),
						/* @__PURE__ */ p("div", {
							className: "hanami-private",
							children: b.map((e) => /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p(q, {
								kind: e,
								size: 21
							}), /* @__PURE__ */ p("b", { children: t?.captures[e] ?? "—" })] }, e))
						}),
						/* @__PURE__ */ p("button", {
							className: "hanami-primary",
							disabled: !y.some((e) => e.type === "end" || e.type === "pass"),
							onClick: () => h(y.some((e) => e.type === "end") ? { type: "end" } : { type: "pass" }),
							children: g(y.some((e) => e.type === "pass") ? "games.hanami.pass" : "games.hanami.endTurn")
						})
					]
				})] })
			}),
			children: /* @__PURE__ */ m("div", {
				className: "hanami-board-wrap",
				onPointerDownCapture: (e) => {
					he.current = e.target.closest("[data-cell]")?.getAttribute("data-cell") ?? null;
				},
				children: [
					/* @__PURE__ */ m(u, {
						sheetW: Ae,
						sheetH: je,
						fitKey: `${e.config.map}:${e.players.length}:${T}`,
						clampToSheet: !0,
						highlight: "off",
						eligible: [{
							key: "map",
							rect: {
								x: 0,
								y: 0,
								w: Ae,
								h: je
							}
						}],
						onTapEligible: () => {
							he.current && De(he.current);
						},
						children: [
							/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ m("linearGradient", {
								id: "hanami-sea",
								x2: "0.4",
								y2: "1",
								children: [/* @__PURE__ */ p("stop", { stopColor: "#7051ad" }), /* @__PURE__ */ p("stop", {
									offset: "1",
									stopColor: "#527bae"
								})]
							}) }),
							/* @__PURE__ */ p("rect", {
								width: Ae,
								height: je,
								rx: "22",
								fill: "url(#hanami-sea)"
							}),
							v.map((t) => {
								let n = t.x - Oe, i = t.y - ke, a = e.board[t.id], o = e.parks[t.id] ?? [], s = Ee.has(t.id), c = Me === t.id || k === t.id, u = a ? ne(a.owner) : void 0;
								return /* @__PURE__ */ m("g", {
									className: "hanami-cell",
									"data-cell": t.id,
									"data-target": s || void 0,
									children: [
										/* @__PURE__ */ p("polygon", {
											points: Array.from({ length: 6 }, (e, t) => `${n + 27.4 * Math.cos(t * Math.PI / 3)},${i + 27.4 * Math.sin(t * Math.PI / 3)}`).join(" "),
											fill: a ? u : t.terrain === "water" ? "#8aaec05c" : t.terrain === "park" ? e.config.map === "nihon" ? "#ffe3e4" : "#f3e6f2" : e.config.map === "nihon" ? "#f8bfd5" : "#d9bbdf",
											stroke: c ? "#fff6b0" : s ? "#fff6da" : t.terrain === "water" ? "#a5b7d048" : "#d295bc",
											strokeWidth: c ? 4 : s ? 2.8 : 1,
											strokeDasharray: s ? "5 4" : void 0,
											children: s && /* @__PURE__ */ p("animate", {
												attributeName: "stroke-dashoffset",
												from: "0",
												to: "-18",
												dur: ".8s",
												repeatCount: "indefinite"
											})
										}),
										a ? /* @__PURE__ */ m(f, { children: [
											/* @__PURE__ */ p(xe, {
												cell: t.id,
												x: n - 22,
												y: i - 23,
												id: a.tile,
												down: a.down,
												direction: a.dir ? "➤" : void 0,
												label: Fe(t.id)
											}),
											C[a.tile].kind === "copy" && a.dir && (() => {
												let e = v.find((e) => e.id === a.dir);
												return e ? /* @__PURE__ */ p("path", {
													d: `M${n} ${i}L${n + (e.x - t.x) * .43} ${i + (e.y - t.y) * .43}`,
													stroke: "#fff4c5",
													strokeWidth: "3"
												}) : null;
											})(),
											/* @__PURE__ */ p("image", {
												href: r[(d.find((e) => e.rid === a.owner)?.avatar ?? 0) % r.length],
												x: n - 22,
												y: i - 25,
												width: "18",
												height: "18",
												preserveAspectRatio: "xMidYMid meet",
												pointerEvents: "none"
											})
										] }) : t.terrain === "park" ? /* @__PURE__ */ p(f, { children: o.length ? o.map((e, t) => /* @__PURE__ */ p("g", {
											transform: `translate(${n - 13 + (t - (o.length - 1) / 2) * 14} ${i - 13 + t % 2 * 5})`,
											children: /* @__PURE__ */ p(q, {
												kind: e,
												size: 26
											})
										}, e)) : /* @__PURE__ */ p("circle", {
											cx: n,
											cy: i,
											r: "5",
											fill: "#bc8eab",
											opacity: ".4"
										}) }) : t.terrain === "water" ? /* @__PURE__ */ p("text", {
											x: n,
											y: i + 5,
											textAnchor: "middle",
											fontSize: "16",
											fill: "#e3def380",
											children: "≋"
										}) : null,
										s && !a && /* @__PURE__ */ p("circle", {
											cx: n,
											cy: i,
											r: "3.2",
											fill: "#fff9df"
										}),
										/* @__PURE__ */ p(l, {
											name: `cell:${t.id}`,
											r: {
												x: n - 24,
												y: i - 24,
												w: 48,
												h: 48
											}
										})
									]
								}, t.id);
							})
						]
					}),
					/* @__PURE__ */ p("button", {
						className: "hanami-fit",
						onClick: () => E(T + 1),
						children: g("games.hanami.fit")
					}),
					/* @__PURE__ */ m("div", {
						className: "hanami-ties",
						"aria-label": g("games.hanami.ties"),
						children: [
							/* @__PURE__ */ p("span", { children: g("games.hanami.ties") }),
							e.ties.map((e, t) => /* @__PURE__ */ p(q, {
								kind: e,
								size: 21
							}, t)),
							Array.from({ length: Math.max(0, 4 - e.ties.length) }, (e, t) => /* @__PURE__ */ p("i", {}, t))
						]
					}),
					e.phase === "prepare" && e.config.startStrong && !G?.ready && /* @__PURE__ */ p("div", {
						className: "hanami-pool",
						children: t?.pool.map((e) => /* @__PURE__ */ m("button", {
							"data-selected": M.includes(e),
							"aria-label": g("games.hanami.selectTile", {
								tile: g(w(e)),
								n: C[e].strength
							}),
							onClick: () => fe(M.includes(e) ? M.filter((t) => t !== e) : M.length < 5 ? [...M, e] : M),
							children: [/* @__PURE__ */ p(ge, { id: e }), /* @__PURE__ */ p("small", { children: g(w(e)) })]
						}, e))
					}),
					$ && /* @__PURE__ */ m("div", {
						className: "hanami-inspector",
						children: [
							/* @__PURE__ */ p("button", {
								className: "hanami-close",
								onClick: () => R(null),
								"aria-label": g("games.hanami.close"),
								children: "×"
							}),
							/* @__PURE__ */ m("b", { children: [
								g($.terrain === "park" ? "games.hanami.park" : $.terrain === "water" ? "games.hanami.water" : "games.hanami.land"),
								" · ",
								$.id
							] }),
							$.terrain === "park" ? (e.parks[$.id] ?? []).map((t) => /* @__PURE__ */ m("div", {
								className: "hanami-strengths",
								children: [/* @__PURE__ */ p(q, {
									kind: t,
									size: 25
								}), e.players.map((n, r) => /* @__PURE__ */ m("span", {
									style: { color: se[r] },
									children: [
										_(n.rid),
										" ",
										/* @__PURE__ */ p("b", { children: ue(e, $, t)[n.rid] })
									]
								}, n.rid))]
							}, t)) : e.board[$.id] ? /* @__PURE__ */ p("p", { children: Fe($.id) }) : null
						]
					}),
					(A || j.length > 0 || k || O && J === "takoyaki") && /* @__PURE__ */ m("div", {
						className: "hanami-confirm",
						children: [j.length > 0 ? j.map((e, t) => /* @__PURE__ */ p("button", {
							onClick: () => {
								U(e), W([]);
							},
							children: Pe(e)
						}, t)) : A ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { children: A.type === "place" ? g(w(A.tile)) : A.type === "draft" ? g(S[A.token]) : g(re[J]) }), /* @__PURE__ */ p("button", {
							className: "hanami-primary",
							onClick: Se,
							children: g("games.hanami.confirm")
						})] }) : J === "takoyaki" && O ? y.filter((e) => e.type === "ability").map((e, t) => /* @__PURE__ */ p("button", {
							onClick: () => U(e),
							children: Pe(e)
						}, t)) : /* @__PURE__ */ p("span", { children: g(D !== null && C[D].kind === "copy" ? "games.hanami.copyPrompt" : "games.hanami.destinationPrompt") }), /* @__PURE__ */ p("button", {
							onClick: Y,
							children: g("games.hanami.cancel")
						})]
					}),
					e.phase === "resolve" && e.last && /* @__PURE__ */ m("div", {
						className: "hanami-capture",
						children: [/* @__PURE__ */ p(q, {
							kind: e.last.token,
							size: 38
						}), /* @__PURE__ */ p("strong", { children: e.last.winner ? g("games.hanami.receives", { name: _(e.last.winner) }) : g("games.hanami.tieCapture") })]
					}, `${e.last.park}:${e.last.token}`)
				]
			})
		})
	});
}
function be({ rid: e }) {
	let { ref: t } = ee(`seat:${e}`);
	return /* @__PURE__ */ p("span", {
		ref: t,
		className: "hanami-seat-anchor"
	});
}
function xe({ cell: e, x: t, y: n, id: r, down: a, direction: o, label: s }) {
	let c = d(), l = i((t) => {
		c?.registerProbe(`tile:${e}`, t ? () => {
			let e = t.getBoundingClientRect();
			return {
				x: e.left,
				y: e.top,
				w: e.width,
				h: e.height
			};
		} : null);
	}, [c, e]), { hidden: u } = ee(`tile:${e}`);
	return /* @__PURE__ */ m("g", {
		ref: l,
		transform: `translate(${t} ${n})`,
		visibility: u ? "hidden" : void 0,
		role: "img",
		"aria-label": s,
		children: [
			/* @__PURE__ */ p("title", { children: s }),
			/* @__PURE__ */ p(_e, {
				id: r,
				down: a,
				direction: o
			}),
			/* @__PURE__ */ p("rect", {
				width: "44",
				height: "47",
				fill: "none",
				pointerEvents: "none"
			})
		]
	});
}
//#endregion
//#region src/games/hanami/bot.ts
var Se = {
	pressure: 1,
	margin: 2,
	close: 3,
	abilityCost: .7,
	tileCost: .05
};
function X(e, t, n) {
	let r = structuredClone(e);
	if (t.type === "place" && (t.from ? (L(r.board, I(r.config, r.players.length), t.from, t.at), r.board[t.from] = {
		owner: n,
		tile: t.tile,
		down: !1,
		dir: null
	}) : r.board[t.at] = {
		owner: n,
		tile: t.tile,
		down: !1,
		dir: t.dir ?? null
	}), t.type === "ability") {
		let e = r.players.find((e) => e.rid === n).ability, i = t.a, a = t.b;
		if ((e === "torii" || e === "fruit") && (r.parks[i][r.parks[i].indexOf(t.token)] = t.otherToken, r.parks[a][r.parks[a].indexOf(t.otherToken)] = t.token), (e === "rain" || e === "akkorokamui") && (r.board[i].down = !0), e === "tea" && ([r.board[i], r.board[a]] = [r.board[a], r.board[i]]), e === "bicycle" && L(r.board, I(r.config, r.players.length), i, a), e === "dango" || e === "taiyaki") return X(r, {
			type: "place",
			tile: t.tile,
			at: i,
			from: t.b,
			dir: t.dir
		}, n);
	}
	return r;
}
function Z(e, t, n) {
	let r = I(e.config, e.players.length), i = new Map(r.map((e) => [e.id, e])), a = 0;
	for (let o of r) {
		let r = e.parks[o.id];
		if (!r?.length) continue;
		let s = o.neighbors.filter((t) => i.get(t)?.terrain === "land" && !e.board[t]).length;
		for (let i of r) {
			let r = ue(e, o, i), c = r[t], l = c - Math.max(0, ...e.players.filter((e) => e.rid !== t).map((e) => r[e.rid]));
			a += n.pressure * c / (s + 2), a += n.margin * Math.tanh(l / 3) / (s + 1), s === 0 && (a += n.close * Math.sign(l));
		}
	}
	return a;
}
function Ce(e = Se) {
	return ({ public: t, private: n }, r) => {
		if (!n || !t.players.some((e) => e.rid === r.rid)) return null;
		if (t.phase === "prepare") {
			if (t.players.find((e) => e.rid === r.rid).ready) return null;
			let e = [...n.pool].sort((e, t) => (C[t].kind === "wild" ? 2 : 0) + C[t].strength - ((C[e].kind === "wild" ? 2 : 0) + C[e].strength)).slice(0, 5);
			return { action: {
				type: "prepare",
				ability: n.choices[0],
				hand: e
			} };
		}
		let i = de(t, n, r.rid, r.difficulty !== "weak");
		if (!i.length) return null;
		if (t.phase === "draft") return { action: i[(t.round + Object.values(t.parks).flat().length * 7) % i.length] };
		let a = Z(t, r.rid, e), o = i[0], s = -Infinity;
		for (let n of i) {
			let i = n.type === "end" || n.type === "pass" ? 0 : Z(X(t, n, r.rid), r.rid, e) - a;
			n.type === "ability" && (i -= e.abilityCost), n.type === "place" && (i += .15 - C[n.tile].strength * e.tileCost), r.difficulty === "weak" && (i = n.type === "place" ? I(t.config, t.players.length).filter((e) => e.neighbors.includes(n.at)).reduce((e, n) => e + (t.parks[n.id]?.length ?? 0), 0) * C[n.tile].strength : -1, t.placed > 0 && n.type === "end" && (i = 100)), i > s && (s = i, o = n);
		}
		return { action: o };
	};
}
var we = Ce();
//#endregion
//#region src/games/hanami/fx.tsx
function Q({ id: e, down: t, direction: i, member: a }) {
	return /* @__PURE__ */ m("div", {
		className: "hanami-flying-tile",
		style: {
			position: "relative",
			background: n[(a?.colorIndex ?? 0) % n.length].hex
		},
		children: [/* @__PURE__ */ p(ge, {
			id: e,
			down: t,
			direction: i
		}), /* @__PURE__ */ p("img", {
			src: r[(a?.avatar ?? 0) % r.length],
			alt: "",
			style: {
				position: "absolute",
				left: "4%",
				top: 0,
				width: "38%",
				height: "38%",
				objectFit: "contain",
				pointerEvents: "none"
			}
		})]
	});
}
var Te = {
	place(e, t) {
		let n = e.data, r = t.anchor(`cell:${n.at}`), i = t.anchor("hand");
		if (!r) return null;
		let a = n.moved && t.anchor(`cell:${n.moved.from}`), o = n.moved && t.anchor(`cell:${n.moved.at}`);
		return n.tile !== void 0 && i ? {
			ms: P.place,
			hide: [`tile:${n.at}`, ...n.moved ? [`tile:${n.moved.at}`] : []],
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(h, {
				from: {
					x: i.x + i.w / 2 - r.w / 2,
					y: i.y,
					w: r.w,
					h: r.h
				},
				to: r,
				ms: P.place,
				children: /* @__PURE__ */ p(Q, {
					id: n.tile,
					member: t.member(e.rid ?? "")
				})
			}), n.moved && a && o && /* @__PURE__ */ p(h, {
				from: a,
				to: o,
				ms: P.place,
				children: /* @__PURE__ */ p(Q, {
					id: n.moved.piece.tile,
					down: n.moved.piece.down,
					direction: n.moved.piece.dir ? "➤" : void 0,
					member: t.member(n.moved.piece.owner)
				})
			})] })
		} : {
			ms: P.place,
			node: /* @__PURE__ */ p(g, {
				at: r,
				ms: P.place
			})
		};
	},
	capture(e, t) {
		let n = e.data, r = t.anchor(`cell:${n.park}`), i = n.winner ? t.anchor(`seat:${n.winner}`) : null;
		return r ? {
			ms: P.capture,
			node: /* @__PURE__ */ m(f, { children: [i && /* @__PURE__ */ p(h, {
				from: r,
				to: {
					x: i.x + i.w / 2 - 15,
					y: i.y,
					w: 30,
					h: 30
				},
				ms: P.capture - 150,
				children: /* @__PURE__ */ p(q, {
					kind: n.token,
					size: 36
				})
			}), /* @__PURE__ */ p(g, {
				at: r,
				ms: P.capture
			})] })
		} : null;
	},
	ability(e, t) {
		let n = e.data, r = t.anchor(`cell:${n.at}`) ?? t.anchor(`seat:${e.rid}`);
		return n.moves?.length ? {
			ms: P.ability,
			hide: n.moves.map((e) => `tile:${e.at}`),
			node: /* @__PURE__ */ p(f, { children: n.moves.map((e) => {
				let n = t.anchor(`cell:${e.from}`), r = t.anchor(`cell:${e.at}`);
				return n && r ? /* @__PURE__ */ p(h, {
					from: n,
					to: r,
					ms: P.ability,
					children: /* @__PURE__ */ p(Q, {
						id: e.piece.tile,
						down: e.piece.down,
						direction: e.piece.dir ? "➤" : void 0,
						member: t.member(e.piece.owner)
					})
				}, e.from) : null;
			}) })
		} : r ? {
			ms: P.ability,
			node: /* @__PURE__ */ p(g, {
				at: r,
				ms: P.ability
			})
		} : null;
	}
};
//#endregion
//#region src/games/hanami/game-over.tsx
function Ee({ public: e, result: t, members: n, onPlayAgain: r, onBackToLobby: i, hintCount: a }) {
	let o = c(), s = e, l = (e) => n.find((t) => t.rid === e)?.name ?? e, u = me(s.players.map((e) => e.rid), Object.fromEntries(s.players.map((e) => [e.rid, e.captures])));
	return /* @__PURE__ */ m("div", {
		className: "hanami-ending",
		children: [
			/* @__PURE__ */ p(q, {
				kind: "sakura",
				size: 80
			}),
			/* @__PURE__ */ p("h1", { children: o("games.hanami.festivalEnds") }),
			/* @__PURE__ */ p("p", { children: o("games.hanami.winners", { names: t.winner.map(l).join(" · ") }) }),
			/* @__PURE__ */ m("table", {
				className: "hanami-results",
				children: [/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [
					/* @__PURE__ */ p("th", { children: o("games.hanami.player") }),
					b.map((e) => /* @__PURE__ */ p("th", { children: /* @__PURE__ */ p(q, {
						kind: e,
						size: 34
					}) }, e)),
					/* @__PURE__ */ p("th", { children: o("games.hanami.medals") })
				] }) }), /* @__PURE__ */ p("tbody", { children: t.ranking.map((e) => /* @__PURE__ */ m("tr", {
					"data-winner": t.winner.includes(e),
					children: [
						/* @__PURE__ */ p("td", { children: /* @__PURE__ */ p("strong", { children: l(e) }) }),
						b.map((t) => /* @__PURE__ */ m("td", { children: [s.players.find((t) => t.rid === e).captures[t], u.medals[e].includes(t) && /* @__PURE__ */ p("span", {
							title: o("games.hanami.medals"),
							children: " ✦"
						})] }, t)),
						/* @__PURE__ */ p("td", { children: /* @__PURE__ */ p("b", { children: u.medals[e].length }) })
					]
				}, e)) })]
			}),
			/* @__PURE__ */ p("p", { children: o("games.hanami.scoringHelp") }),
			a !== void 0 && /* @__PURE__ */ p("p", { children: o("session.hint.usedCount", { n: a }) }),
			/* @__PURE__ */ m("div", {
				className: "hanami-result-controls",
				children: [
					r && /* @__PURE__ */ p("button", {
						onClick: r,
						children: o("session.result.playAgain")
					}),
					i && /* @__PURE__ */ p("button", {
						onClick: i,
						children: o("session.result.backToLobby")
					}),
					!r && !i && /* @__PURE__ */ p("p", { children: o("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/hanami/options.tsx
function De({ value: e, onChange: t }) {
	let n = c(), r = k.safeParse(e), i = r.success ? r.data : k.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ p(v, {
			title: n("games.hanami.map"),
			children: ["nihon", "tokyo"].map((e) => /* @__PURE__ */ p(ne, {
				name: "hanami-map",
				value: e,
				checked: i.map === e,
				label: n(e === "nihon" ? "games.hanami.nihon" : "games.hanami.tokyo"),
				accent: T.accent,
				onChange: () => t({
					...i,
					map: e
				})
			}, e))
		}), /* @__PURE__ */ m(v, {
			title: n("games.hanami.variants"),
			children: [
				/* @__PURE__ */ p(_, {
					name: "hanami-variants",
					value: "enabled",
					checked: i.specialTiles,
					label: n("games.hanami.specialTiles"),
					accent: T.accent,
					onChange: () => t({
						...i,
						specialTiles: !i.specialTiles
					})
				}),
				/* @__PURE__ */ p(_, {
					name: "hanami-variants",
					value: "enabled",
					checked: i.specialAbilities,
					label: n("games.hanami.specialAbilities"),
					accent: T.accent,
					onChange: () => t({
						...i,
						specialAbilities: !i.specialAbilities
					})
				}),
				/* @__PURE__ */ p(_, {
					name: "hanami-variants",
					value: "enabled",
					checked: i.startStrong,
					label: n("games.hanami.startStrong"),
					accent: T.accent,
					onChange: () => t({
						...i,
						startStrong: !i.startStrong
					})
				}),
				/* @__PURE__ */ p(_, {
					name: "hanami-variants",
					value: "enabled",
					checked: i.tokenDraft,
					label: n("games.hanami.tokenDraft"),
					accent: T.accent,
					onChange: () => t({
						...i,
						tokenDraft: !i.tokenDraft
					})
				})
			]
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/hanami/entry.tsx
var Oe = {
	definition: he,
	View: J,
	bot: we,
	fx: Te,
	OverView: Ee,
	Options: De,
	locales: {
		zh: {
			name: "花见",
			desc: "在樱花盛开的群岛上铺设野餐板块，争夺庆典的三种荣誉。",
			rules: "目标：\n争夺樱花、灯笼和饭团庆典标记，取得最多类别的胜利标记。\n准备：选择日本或东京地图，按人数开放中央、左侧、右侧区域。每类庆典标记的数量按人数确定：两人游戏使用 7 枚，三人游戏使用 10 枚，四人游戏使用 13 枚。三树公园放三类各一枚，双树公园放两类不同标记，其余公园放一枚。每人使用相同的 19 枚板块，随机抽取 5 枚，手牌和获得的庆典标记保密。\n回合：在放置任何板块前，可以使用自己的能力一次，全局限一次。随后放置一枚普通板块，可以在它前后放置任意数量带快速符号的板块，也可以只放快速板块。至少放置一枚后，点击“结束回合”。全部放置完成后统一结算公园，再从自己的牌堆补至 5 枚。\n放置：基础类别板块、招财猫与行动板块放在空陆地格；船只能放在浅水格。公园始终不能放玩家板块。樱花、灯笼、饭团各有强度 2、3、4 的板块；招财猫有三枚强度 1、两枚强度 2、一枚强度 3，都是百搭；三艘船的强度为 1、1、2，均为快速百搭。\n飞机：消耗本回合的普通板块机会，将自己一枚已放置的非快速陆地板块移到任意空陆地格，飞机留在原格，飞机强度为 0。\n领取：公园相邻陆地全部被占据时，分别计算每种庆典标记的影响力。相邻的同类别板块与百搭板块贡献强度，唯一最高者获得标记，最高平局则标记进入公共平局区。船也贡献影响力，但水格不必填满。\n结束：任意一类庆典标记全部离开公园，或公共平局区至少有 4 枚时，完成当前回合的全部结算后结束。如果所有玩家连续一轮均无合法放置，也结束。\n计分：每类庆典标记数量唯一最多者获得对应的一枚胜利标记，最高数量平局则该类无人获得。胜利标记最多者获胜。如果各得一枚的玩家并列，先比较其未获得胜利标记的类别总数，再比较全部庆典标记总数，若仍然相同，则共享胜利。如果无人获得胜利标记，比较全部庆典标记总数。\n可选特殊板块：\n· 抽取：属于快速百搭板块，强度为 1。放置后，立即抽取一枚板块。\n·  覆盖为快速百搭强度 3，盖在自己任意已放板块上，取代原效果。\n·  复制为普通板块，箭头指定相邻板块，实时复制类型与强度，不复制快速或行动效果。复制链最终没有有效来源时强度为 0。移动后的复制板块保留朝向。\n可选能力：特殊能力模式每人从两张不同能力中选一张，效果见卡面。\n· 鸟居与水果三明治可交换不同公园的任意两枚庆典标记，但同一公园内不能出现同类别的庆典标记。\n·  雨天翻背一枚强度 1 或 2 的基础类别板块。\n·  自行车将任意陆地板块移至相邻空陆地。\n·  团子将自己一枚强度 1 或 2 的手牌按快速规则放置。\n·  绿茶交换自己一枚基础类别板块和版图任意同类别板块。\n·  巨章鱼翻背一艘船。\n·  鲷鱼烧将自己一枚手牌放在水格并视为快速，飞机仍需合法陆地移动，故不可使用。\n·  章鱼烧交换自己一枚已获标记与平局区一枚标记。\n· 翻背板块保留占位，强度为 0。\n进阶开局：精选起手允许秘密选择 5 枚起手。庆典轮放保留中央三枚后，由玩家轮流选择标记放入公园，先填双树公园，再填单树公园，同园不同类。可选内容默认关闭。",
			sakura: "樱花",
			chochin: "灯笼",
			onigiri: "饭团",
			cat: "招财猫",
			boat: "船",
			move: "飞机",
			copy: "复制",
			draw: "抽取",
			cover: "覆盖",
			torii: "鸟居",
			fruit: "水果三明治",
			rain: "雨天",
			bicycle: "自行车",
			dango: "团子",
			tea: "绿茶",
			akkorokamui: "巨章鱼",
			taiyaki: "鲷鱼烧",
			takoyaki: "章鱼烧",
			toriiText: "交换不同公园的两枚庆典标记。同一公园不能出现同类标记。",
			rainText: "翻背任意一枚强度 1 或 2 的基础类别板块，使其强度变为 0。",
			bicycleText: "将任意陆地板块移动到相邻的空陆地格。",
			dangoText: "将自己一枚强度 1 或 2 的手牌按快速板块规则放置。",
			teaText: "将自己一枚基础类别板块与版图任意同类别板块交换位置。",
			akkorokamuiText: "翻背任意一艘船，使其强度变为 0。",
			taiyakiText: "将自己一枚手牌放到空水格，视为快速板块。",
			takoyakiText: "将自己一枚已获得的庆典标记与平局区的一枚交换。",
			map: "地图",
			nihon: "日本",
			tokyo: "东京",
			variants: "可选内容",
			specialTiles: "特殊板块",
			specialAbilities: "特殊能力",
			startStrong: "精选起手",
			tokenDraft: "庆典轮放",
			continuePrompt: "可以继续放置快速板块，或结束回合。",
			endPrompt: "放置已完成，请结束回合。",
			turnNumber: "回合 {{n}}",
			you: "你",
			deckCount: "牌堆 {{n}}",
			resolving: "正在分配庆典标记…",
			waiting: "等待 {{name}} 行动",
			preparePrompt: "选择能力；开启精选起手时，另选 5 枚起手板块。",
			draftPrompt: "选择公园和庆典标记，先填双树公园。",
			placePrompt: "点击高亮格预览，再确认放置。",
			turnPrompt: "选择手牌；能力只能在放置前使用。",
			movePrompt: "选择自己一枚已放置的非快速板块。",
			destinationPrompt: "选择目标格。",
			copyPrompt: "点击相邻格，确定复制板块的箭头朝向。",
			readyPlain: "完成选择",
			placedTile: "{{name}} · {{tile}}，强度 {{n}}",
			flippedTile: "{{name}} · 已翻背的板块",
			ready: "完成选择（{{n}}／5）",
			selectTile: "选择{{tile}}，强度 {{n}}",
			endTurn: "结束回合",
			pass: "无板块可放，跳过",
			useAbility: "使用能力",
			used: "已使用",
			fit: "全景",
			ties: "平局区",
			close: "关闭",
			park: "公园",
			water: "水格",
			land: "陆地",
			confirm: "确认",
			cancel: "取消选择",
			receives: "{{name}} 获得标记",
			tieCapture: "标记进入平局区",
			hintPlace: "将{{tile}}放到 {{at}} 号格。",
			festivalEnds: "花见落幕",
			winners: "{{names}} 获胜",
			player: "玩家",
			medals: "胜利标记",
			scoringHelp: "✦ 表示该类别数量唯一最多。各得一枚时，先比较未获胜类别总数，再比较全部标记总数。",
			errTurn: "当前不能执行此行动。",
			errSelection: "选择不合法，请重新选择板块或目标。"
		},
		en: {
			name: "Hanami",
			desc: "Lay picnic tiles across blossoming islands and compete for three celebration honors.",
			rules: "Goal: collect Sakura, Chochin and Onigiri celebrations to earn the most category Victory Points.\nSetup: choose Nihon or Tokyo. Use the central region for 2 players, add the left regions for 3, and all regions for 4. For each celebration type, use 7 tokens with two players, 10 with three, or 13 with four. The three-tree park holds one of each type, two-tree parks hold two different types, and single-tree parks hold one token. Each player has the same 19 tiles and draws 5. Hands and collected tokens stay hidden.\nTurn: before placing any tiles, you may use your once-per-game ability. Then place one regular tile, with any number of Fast tiles before or after it. You may play only Fast tiles instead. After placing at least one tile, press End turn. Resolve all surrounded parks, then refill your hand to 5 from your personal deck.\nPlacement: category, Cat and action tiles go on empty land. Boats go only on shallow-water spaces. Player tiles never occupy parks. Sakura, Chochin and Onigiri each have strength 2, 3 and 4 tiles. Cats are Wild: three strength 1, two strength 2 and one strength 3. Boats are Fast and Wild with strengths 1, 1 and 2.\nAirplane: as your regular tile, move one of your previously placed non-Fast land tiles to any empty land space, leaving the zero-strength Airplane in its former space.\nClaiming: a park is surrounded when all adjacent land spaces are occupied. For each token separately, sum adjacent matching-category and Wild strength. The unique highest player claims it; a tie for highest sends it to the Ties area. Boats contribute strength, but water spaces do not need to be occupied.\nEnd: finish the current turn and all its claims when any token type has disappeared from all parks, or the Ties area contains at least 4 tokens. If every player consecutively has no legal placement for a full round, the game also ends.\nScoring: the unique highest collector of each type earns its one Victory Point. A tied category awards none. Most Victory Points wins. Among players tied with one Victory Point each, compare tokens of their non-winning categories, then total tokens; a remaining tie is shared. If nobody earns a Victory Point, compare total tokens.\nOptional special tiles:\n· Draw is a strength-1 Fast Wild tile. Immediately draw one tile after placing it.\n· Cover is a strength-3 Fast Wild tile placed on any of your placed tiles, replacing its effect.\n· Copy is regular: its arrow points at an adjacent space and continuously copies that tile’s type and strength, but not its Fast status or action. A copy chain with no originating tile has strength zero. A moved Copy preserves its orientation.\nOptional abilities: choose one of two unique cards.\n· Torii and Fruit Sandwich swap any two tokens in different parks without creating duplicate types in a park.\n· Rainy Day flips a strength-1 or strength-2 category tile to zero.\n· Bicycle moves any land tile to an adjacent empty land space.\n· Dango plays one of your strength-1 or strength-2 hand tiles as Fast.\n· Green Tea swaps your category tile with any same-category tile on the board.\n· Akkorokamui flips any Boat to zero.\n· Taiyaki plays one of your hand tiles on empty water as Fast; an Airplane still requires a land move and cannot use this effect.\n· Takoyaki swaps one collected token with one in the Ties area.\n· Flipped tiles still occupy their spaces.\nAdvanced setup: Start Strong privately chooses 5 starting tiles. Token Draft fixes the central three tokens, then players alternate placing tokens, filling two-tree parks before single-tree parks, with no duplicate type in a park. All optional modules default off.",
			sakura: "Sakura",
			chochin: "Chochin",
			onigiri: "Onigiri",
			cat: "Cat",
			boat: "Boat",
			move: "Airplane",
			copy: "Copy",
			draw: "Draw",
			cover: "Cover",
			torii: "Torii",
			fruit: "Fruit Sandwich",
			rain: "Rainy Day",
			bicycle: "Bicycle",
			dango: "Dango",
			tea: "Green Tea",
			akkorokamui: "Akkorokamui",
			taiyaki: "Taiyaki",
			takoyaki: "Takoyaki",
			toriiText: "Swap two celebration tokens in different parks, without creating duplicate types in a park.",
			rainText: "Flip any strength-1 or strength-2 category tile facedown. Its strength becomes zero.",
			bicycleText: "Move any land tile to an adjacent empty land space.",
			dangoText: "Play one of your strength-1 or strength-2 hand tiles as Fast.",
			teaText: "Swap your category tile with any tile of that same category on the board.",
			akkorokamuiText: "Flip any Boat facedown. Its strength becomes zero.",
			taiyakiText: "Play one of your hand tiles on empty water, treating it as Fast.",
			takoyakiText: "Swap one of your collected celebration tokens with a token in the Ties area.",
			map: "Map",
			nihon: "Nihon",
			tokyo: "Tokyo",
			variants: "Optional modules",
			specialTiles: "Special tiles",
			specialAbilities: "Special abilities",
			startStrong: "Start Strong",
			tokenDraft: "Token Draft",
			continuePrompt: "Play more Fast tiles, or end your turn.",
			endPrompt: "Placement complete. End your turn.",
			turnNumber: "Turn {{n}}",
			you: "you",
			deckCount: "Deck {{n}}",
			resolving: "Awarding celebration tokens…",
			waiting: "Waiting for {{name}}",
			preparePrompt: "Choose an ability; with Start Strong enabled, also choose 5 starting tiles.",
			draftPrompt: "Choose a park and token. Fill two-tree parks first.",
			placePrompt: "Tap a highlighted space to preview, then confirm.",
			turnPrompt: "Choose a tile. Use your ability before placing tiles.",
			movePrompt: "Choose one of your placed non-Fast tiles.",
			destinationPrompt: "Choose the destination space.",
			copyPrompt: "Tap an adjacent space to set the Copy arrow.",
			readyPlain: "Ready",
			placedTile: "{{name}} · {{tile}}, strength {{n}}",
			flippedTile: "{{name}} · Flipped tile",
			ready: "Ready ({{n}}/5)",
			selectTile: "Select {{tile}}, strength {{n}}",
			endTurn: "End turn",
			pass: "No tile can be placed: pass",
			useAbility: "Use ability",
			used: "used",
			fit: "Fit map",
			ties: "Ties",
			close: "Close",
			park: "Park",
			water: "Water",
			land: "Land",
			confirm: "Confirm",
			cancel: "Clear selection",
			receives: "{{name}} claims the token",
			tieCapture: "Token goes to Ties",
			hintPlace: "Place {{tile}} on space {{at}}.",
			festivalEnds: "Blossoms at dusk",
			winners: "{{names}} wins",
			player: "Player",
			medals: "Victory Points",
			scoringHelp: "✦ marks the unique category leader. Tied players with one Victory Point compare non-winning category totals, then all tokens.",
			errTurn: "This action is not available now.",
			errSelection: "Invalid selection. Choose a legal tile and target."
		}
	}
};
//#endregion
export { Oe as default };
