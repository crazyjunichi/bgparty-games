import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { IconBack as m, IconBot as h, IconExpand as g, IconLog as _ } from "@bgparty/sdk/icons";
import { seatName as v } from "@bgparty/sdk/ui/player-strip";
import { Confetti as y } from "@bgparty/sdk/ui/confetti";
//#region src/games/onward/data/cards.ts
var b = [
	{
		id: "A00",
		hero: "h00",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "炎之烙印",
		text: "对1个◎周围的敌方英雄或界外魔造成3点DMG与燃烧。若如此做,本回合内该敌人下次进入一个区域时,将秋元传送至那个区域。"
	},
	{
		id: "A01",
		hero: "h00",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["t"],
		name: "嗜血火焰",
		text: "仅能在您的购买阶段施放。秋元本轮+3先攻值且+1力量。下一次小兵阶段推迟至本轮结束时再进行。"
	},
	{
		id: "A02",
		hero: "h00",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "烈火焚身",
		text: "额外花费:1点HP。秋元本回合的下次攻击力量+5且附带燃烧。"
	},
	{
		id: "A03",
		hero: "h00",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["r", "u"],
		name: "火之誓言",
		text: "附着于1个周围的敌方英雄。攻击被附着的英雄时,秋元的攻击力量翻倍。"
	},
	{
		id: "A04",
		hero: "h00",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "A05",
		hero: "h00",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "灼热俯冲",
		text: "移动至1个◎相邻区域。若如此做,可以对该区域的1个英雄或界外魔造成2点DMG与燃烧。"
	},
	{
		id: "A06",
		hero: "h01",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "窒息火花",
		text: "燃烧2格内的一个敌方英雄,并将本卡牌附着于他,直至美雪或该英雄被击败。若被附着的英雄因为燃烧失去1点HP,失去2点HP作为代替。"
	},
	{
		id: "A07",
		hero: "h01",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "致残射线",
		text: "从缴械、沉默、眩晕、燃烧中选择两个不同的状态。对1个2格内的英雄施加你选择的状态。"
	},
	{
		id: "A08",
		hero: "h01",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "汲取之触",
		text: "附着于1个◎3格内的友方英雄,直至其被击败。当被附着的英雄受到1点或更多DMG时,治疗其2点HP。"
	},
	{
		id: "A09",
		hero: "h01",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["r", "u"],
		name: "灵魂引导",
		text: "本回合,若1个◎3格内的界外魔或友方英雄将被击败,将其HP设置为5作为代替。"
	},
	{
		id: "A10",
		hero: "h01",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "A11",
		hero: "h01",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "精神疗愈",
		text: "为1个◎2格内的单位治疗3HP。若目标有状态,你可以将该状态转移至美雪周围的◎另一个英雄上。"
	},
	{
		id: "A12",
		hero: "h02",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "灼热推击",
		text: "驱逐并燃烧1个◎周围区域中的1个◎敌方英雄。若成功将其驱逐,北斋移动至目标区域。"
	},
	{
		id: "A13",
		hero: "h02",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "地狱嘲讽",
		text: "附着于北斋直至其被击败。其+1护甲并获得“反击:燃烧”。当对手使用法术或能力选择目标时,必须选择北斋(若可行)。"
	},
	{
		id: "A14",
		hero: "h02",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "炎爆",
		text: "额外花费:选择X为1、2或3。对北斋造成X点DMG。对1个◎周围区域中的X个◎敌人造成1点DMG并眩晕。"
	},
	{
		id: "A15",
		hero: "h02",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["u"],
		name: "超新星燃爆",
		text: "对1个◎周围区域中的每一个敌人造成3穿透DMG与燃烧。"
	},
	{
		id: "A16",
		hero: "h02",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "A17",
		hero: "h02",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "硫磺护盾",
		text: "1个◎周围的单位本回合+3护甲并获得“反击:燃烧”。"
	},
	{
		id: "A18",
		hero: "h03",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "给我过来",
		text: "吸引并眩晕1个◎周围的敌方英雄。"
	},
	{
		id: "A19",
		hero: "h03",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "幽灵诡步",
		text: "夜牙获得2点MP。本回合,夜牙可以使用移动行动,且她获得坚韧,【卡面原文至此,疑似CN排版截断,待对照英文版】"
	},
	{
		id: "A20",
		hero: "h03",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "火镰横扫",
		text: "对同区域的2个敌人造成2点DMG与燃烧。若在你施放该法术时,同区域内有4个或更多敌人,改为对同区域的3个敌人生效。"
	},
	{
		id: "A21",
		hero: "h03",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["r", "u"],
		name: "众生俯首",
		text: "传送至1个◎2格内的区域。若如此做,对该区域至多3个敌人造成1点穿透DMG与冰冻。"
	},
	{
		id: "A22",
		hero: "h03",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "A23",
		hero: "h03",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "未知恐惧",
		text: "下一次1个◎周围区域中敌方小兵推进时,那些小兵失去总计3点兵力。(最小为0点)。"
	},
	{
		id: "A24",
		hero: "h04",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "炙热镖",
		text: "对1个◎周围的敌方英雄造成3点穿透DMG与燃烧。"
	},
	{
		id: "A25",
		hero: "h04",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "火球术",
		text: "额外花费:1点AP。对1个◎周围区域中至多5个◎敌人造成1点穿透DMG与燃烧。"
	},
	{
		id: "A26",
		hero: "h04",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "燃流星",
		text: "选择1个◎2格内的区域。对该区域周围的每个敌方英雄造成1点穿透DMG与燃烧。"
	},
	{
		id: "A27",
		hero: "h04",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["r", "u"],
		name: "正念心",
		text: "抽4张牌,并将你的2张手牌放回牌库顶。对至多2个◎周围的敌人造成1点穿透DMG与燃烧。"
	},
	{
		id: "A28",
		hero: "h04",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "A29",
		hero: "h04",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "火焰鞭",
		text: "对1个◎周围区域中的至多2个◎非野怪敌人造成1点穿透DMG与燃烧。"
	},
	{
		id: "A30",
		hero: "h05",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "空降支援",
		text: "额外花费:1点MP与1点HP。传送至1个◎任意区域。若如此做,你可以对该区域的1个敌人造成1点穿透DMG,然后,你失去所有MP和AP。"
	},
	{
		id: "A31",
		hero: "h05",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["t"],
		name: "假钞制造",
		text: "仅能在您的购买阶段施放。免费购买一件价格不超过12金币的物品,坂越将其装备,忽略同种颜色只能有一件物品的限制。"
	},
	{
		id: "A32",
		hero: "h05",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "回旋手里剑",
		text: "额外花费:1点AP与1点MP。攻击至多3个◎周围的敌人。"
	},
	{
		id: "A33",
		hero: "h05",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["t", "u"],
		name: "手里剑风暴",
		text: "仅能在您的购买阶段施放。坂越获得3点AP。本轮,坂越可以执行攻击行动,但只能指定英雄和/或界外魔为目标。"
	},
	{
		id: "A34",
		hero: "h05",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "A35",
		hero: "h05",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "疾速射击",
		text: "攻击1个◎坂越所在区域的敌人。"
	},
	{
		id: "A36",
		hero: "h06",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["t"],
		name: "万石集结",
		text: "仅能在您的购买阶段施放。本轮结束时,多米斯所在区域的小兵立即进行一次推进。"
	},
	{
		id: "A37",
		hero: "h06",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: [],
		name: "冲霄撼地",
		text: "额外花费:对1个周围的友方小兵造成3点DMG。传送至任意1个◎交战区域。若如此做,对该区域的至多2个◎敌人造成1点DMG与缴械。"
	},
	{
		id: "A38",
		hero: "h06",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "蚀心化岩",
		text: "附着于多米斯直至其被击败。当一个周围的敌方小兵被击败时,为多米斯治疗2点HP。"
	},
	{
		id: "A39",
		hero: "h06",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["t", "u"],
		name: "轰隆!",
		text: "仅能在您的购买阶段施放。本轮结束时,对3格内的1个水晶或防御塔造成4点DMG,无视其坚韧与反击能力。"
	},
	{
		id: "A40",
		hero: "h06",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "A41",
		hero: "h06",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "散砾召阵",
		text: "额外花费:1点HP。在1个◎周围的交战区域放置1个友方小兵。"
	},
	{
		id: "A42",
		hero: "h07",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["t"],
		name: "烬灭突袭",
		text: "仅能在库玛雅位于一个没有敌方英雄的野区时施放。移动至1个◎相邻的兵线区域。若你如此做,以+2的力量攻击该区域的敌方英雄。"
	},
	{
		id: "A43",
		hero: "h07",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "怒火燃爆",
		text: "本回合,库玛雅+2护甲。对同区域内至多2个◎敌方英雄造成2点穿透DMG与燃烧。"
	},
	{
		id: "A44",
		hero: "h07",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "烟幕随身",
		text: "附着于库玛雅直至其被击败。库玛雅所在区域之外的敌人不能指定该区域内单位、以及该区域本身为目标。"
	},
	{
		id: "A45",
		hero: "h07",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["r", "u"],
		name: "神烬印记",
		text: "移动至1个◎相邻区域。若如此做,你可以对该区域的1个敌人造成5点穿透DMG并沉默。"
	},
	{
		id: "A46",
		hero: "h07",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "A47",
		hero: "h07",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "神龛惩戒",
		text: "本回合,库玛雅+2护甲。然后,以+2的力量攻击所在区域的1个◎界外魔或野怪。"
	},
	{
		id: "B00",
		hero: "h08",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "摇篮曲",
		text: "对歌姬治疗3点HP并缴械1个◎周围区域中的至多1个敌方英雄。"
	},
	{
		id: "B01",
		hero: "h08",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "深情凝视",
		text: "阻止2格内1个◎敌方英雄本回合下一次施法行动的结算。"
	},
	{
		id: "B02",
		hero: "h08",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["t"],
		name: "冻结之音",
		text: "仅能在您的购买阶段施放。将本卡牌附着于歌姬直至本轮结束。阻止周围的所有小兵进行推进。"
	},
	{
		id: "B03",
		hero: "h08",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["r", "u"],
		name: "人鱼之歌",
		text: "无视野区指定目标的限制,沉默1个◎2格内的敌方英雄。该英雄失去1点MP、1点AP,且本回合不能宣告施法行动。"
	},
	{
		id: "B04",
		hero: "h08",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "B05",
		hero: "h08",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "浪花朵朵",
		text: "额外花费:1点AP。若歌姬位于一个交战区域,在该区域放置2个友方小兵。"
	},
	{
		id: "B06",
		hero: "h09",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "凋零馈赠",
		text: "附着于芙蕾赫尔直至其被击败。若她将对一个单位治疗,她可以造成同等DMG作为代替。"
	},
	{
		id: "B07",
		hero: "h09",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "生命汲取",
		text: "对1个◎周围的敌方英雄或小兵造成2点DMG与冰冻。若造成伤害,对另一个◎周围的单位治疗2点HP。"
	},
	{
		id: "B08",
		hero: "h09",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "和风星涌",
		text: "选择“友方”或“敌方”。对周围每个所选类型的英雄治疗2点HP。"
	},
	{
		id: "B09",
		hero: "h09",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["r", "u"],
		name: "寒极春回",
		text: "对1个◎任意单位治疗3点HP,并移除其所有状态。若其为友方单位,额外对其治疗5点HP。"
	},
	{
		id: "B10",
		hero: "h09",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "B11",
		hero: "h09",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "滋养愈合",
		text: "对1个◎2格内的单位治疗3点HP。"
	},
	{
		id: "B12",
		hero: "h10",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["t"],
		name: "静待时机",
		text: "仅能在您的购买阶段施放。对希拉维治疗3点HP。本轮她+3先攻。下一次小兵阶段推迟至本轮结束时再进行。"
	},
	{
		id: "B13",
		hero: "h10",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: [],
		name: "猫猫突袭",
		text: "传送至1个◎正好距离2格的区域。若如此做,沉默1个该区域的英雄并阻止其本回合下一次施法行动。"
	},
	{
		id: "B14",
		hero: "h10",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "豹豹猫猫",
		text: "附着于希拉维直至其被击败。她+1护甲并获得「反击:缴械」。"
	},
	{
		id: "B15",
		hero: "h10",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["u"],
		name: "捕食者之舞",
		text: "额外花费:1点AP。移动至1个◎2格内的区域。若如此做,攻击该区域的每一个敌方英雄和每一个敌方小兵。"
	},
	{
		id: "B16",
		hero: "h10",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "B17",
		hero: "h10",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "寒意俯冲",
		text: "移动至1个◎相邻区域。若如此做,你可以对该区域的1个敌方英雄或界外魔造成2点DMG与冰冻。"
	},
	{
		id: "B18",
		hero: "h11",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "坚冰冲锋",
		text: "驱逐并冰冻1个◎周围区域中的1个◎敌方英雄。若成功将其驱逐,移动至目标区域。"
	},
	{
		id: "B19",
		hero: "h11",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "钢铁之躯",
		text: "附着于布莱尔瓦直至其被击败。布莱尔瓦+1护甲。若周围的英雄将受到伤害,布莱尔瓦可以代替其承受任意数量的伤害。(布莱尔瓦与该友方英雄各自使用自己的护甲值。)"
	},
	{
		id: "B20",
		hero: "h11",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "甩尾重击",
		text: "对1个◎周围区域中至多X个◎敌人造成2点DMG与沉默。X为布莱尔瓦的护甲值。"
	},
	{
		id: "B21",
		hero: "h11",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["r", "u"],
		name: "尖刺鳞甲",
		text: "本回合,1个◎周围单位+4护甲并获得「反击:X点DMG」,X为其护甲值。"
	},
	{
		id: "B22",
		hero: "h11",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "B23",
		hero: "h11",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "霜冻护盾",
		text: "本回合,1个◎周围的单位+3护甲并获得「反击:冰冻」。"
	},
	{
		id: "B24",
		hero: "h12",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "缴械飞刺",
		text: "额外花费:弃置1张手牌。对至多2个周围敌人造成2点穿透DMG与缴械。"
	},
	{
		id: "B25",
		hero: "h12",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "冰墙术",
		text: "额外花费:弃置1张手牌。对1个◎周围区域中所有敌方英雄造成4点穿透DMG与冰冻。本回合内,下次其中的任意一个英雄将要离开本区域时,将其阻止。"
	},
	{
		id: "B26",
		hero: "h12",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "暴风雪",
		text: "额外花费:弃置1张手牌。对1个◎周围区域中至多5个◎敌人造成1点穿透伤害与冰冻。【TODO:卡面以逗号结尾,疑似截断,待英文核对】"
	},
	{
		id: "B27",
		hero: "h12",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["u"],
		name: "碎晶骤雨",
		text: "额外花费:弃置1张手牌。传送至1个◎任意其他区域。若如此做,对该区域的每个敌人造成2点穿透DMG与冰冻。"
	},
	{
		id: "B28",
		hero: "h12",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "B29",
		hero: "h12",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "冰矢连射",
		text: "对1个◎周围区域中的至多2个◎非野怪敌人造成1点穿透DMG与冰冻。"
	},
	{
		id: "B30",
		hero: "h13",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: [],
		name: "野性擒抱",
		text: "对1个周围的英雄造成3点DMG与吸引。若造成了1点或更多DMG,对古尔布贾恩治疗3点HP。"
	},
	{
		id: "B31",
		hero: "h13",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "铁腕锁喉",
		text: "对1个◎周围的敌方英雄造成3点DMG、缴械与吸引。本轮,目标与古尔布贾恩都无法宣告施法行动。"
	},
	{
		id: "B32",
		hero: "h13",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "战斗状态",
		text: "附着于古尔布贾恩直至其被击败。古尔布贾恩+1护甲、阻止◎周围敌方英雄法术或能力中附带的「移动」「传送」和「驱逐」效果。"
	},
	{
		id: "B33",
		hero: "h13",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["u"],
		name: "狂野乱斗",
		text: "为古尔布贾恩治疗4点HP。吸引并冰冻2格内的至多2个敌方英雄。"
	},
	{
		id: "B34",
		hero: "h13",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "B35",
		hero: "h13",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "无畏领军",
		text: "附着于古尔布贾恩直至本轮结束。古尔布贾恩+2兵力、【TODO:卡面以顿号结尾,疑似截断,待英文核对】"
	},
	{
		id: "B36",
		hero: "h14",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["t"],
		name: "狩猎突袭",
		text: "仅能在赫拉尔位于一个没有敌方英雄的野区时施放。传送至另1个◎没有敌方英雄的野区,然后,攻击1个◎周围且位于兵线上的敌方英雄,【TODO:卡面截断】"
	},
	{
		id: "B37",
		hero: "h14",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "汲取养分",
		text: "对赫拉尔治疗3点HP,对至多1个◎周围敌方英雄造成2点DMG与眩晕。"
	},
	{
		id: "B38",
		hero: "h14",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "凶猛鹿角",
		text: "附着于赫拉尔直至其被击败。当赫拉尔进入一个区域时,他可以对该区域中的1个◎野怪或界外魔造成2点DMG。(每个赫拉尔的回合限一次。)"
	},
	{
		id: "B39",
		hero: "h14",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["t", "u"],
		name: "驰骋荒野",
		text: "仅能在您的购买阶段施放。本轮赫拉尔跳过后,立即对1个同区域的敌人造成X点DMG。X为本回合赫拉尔消耗的MP点数量。本次DMG无视坚韧能力。"
	},
	{
		id: "B40",
		hero: "h14",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "B41",
		hero: "h14",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "钢桩铁枝",
		text: "本回合,赫拉尔+2护甲。对至多1个◎周围的野怪或界外魔造成3点DMG。"
	},
	{
		id: "B42",
		hero: "h15",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "百步穿杨",
		text: "额外花费:1点MP。选择1个◎非周围的区域。对该区域的1个◎敌方英雄或小兵造成1点DMG与冰冻。"
	},
	{
		id: "B43",
		hero: "h15",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "防护形态",
		text: "附着于沃希尔德直至其宣告一次攻击或施法行动。她在任何英雄的回合内都获得坚韧特性。"
	},
	{
		id: "B44",
		hero: "h15",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: [],
		name: "箭雨",
		text: "额外花费:1点AP。攻击◎每一个周围的敌方英雄。"
	},
	{
		id: "B45",
		hero: "h15",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["u"],
		name: "白鼬之眼",
		text: "额外花费:全部剩余AP。在1个◎任意区域中选择1个敌方英雄并攻击该英雄,施放本法术每花费1点AP,本次攻击+3力量。"
	},
	{
		id: "B46",
		hero: "h15",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "B47",
		hero: "h15",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "精确射击",
		text: "攻击1个◎距离为2的敌人。"
	},
	{
		id: "C00",
		hero: "h16",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "毒针",
		text: "附着于2格内1个敌方英雄直至其下次疲劳或被治疗。被附着的英雄每完成一个行动的结算,就对其造成1点穿透DMG。"
	},
	{
		id: "C01",
		hero: "h16",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: [],
		name: "伏击",
		text: "额外花费:2点MP。无视野区指定目标的限制,攻击两次1个◎相邻的敌方英雄。"
	},
	{
		id: "C02",
		hero: "h16",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "地刺",
		text: "选择任意1个◎野区。对该区域的1个敌人造成1点DMG和眩晕。"
	},
	{
		id: "C03",
		hero: "h16",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["u"],
		name: "剧毒",
		text: "无视野区指定目标的限制,对1个◎周围的敌方英雄造成8点穿透DMG。"
	},
	{
		id: "C04",
		hero: "h16",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "C05",
		hero: "h16",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "游击",
		text: "无视野区指定目标的限制,攻击1个◎位于周围野区中的敌人。"
	},
	{
		id: "C06",
		hero: "h17",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "持盾冲击",
		text: "驱逐并缴械1个◎周围区域中的1个◎敌方英雄。若成功将其驱逐,移动至目标区域。"
	},
	{
		id: "C07",
		hero: "h17",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "血肉成石",
		text: "附着于科特里克直至其被击败。他+2护甲,且每回合开始时失去1点AP。当对手为其攻击或法术指定一个目标时,必须选择科特里克为目标(若可行)。"
	},
	{
		id: "C08",
		hero: "h17",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "苦痛图腾",
		text: "对至多2个◎同区域的敌人造成2点DMG与缴械。若施放本法术时该区域有3个或更多友方小兵,改为指定3个目标。"
	},
	{
		id: "C09",
		hero: "h17",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["u"],
		name: "我的王国!",
		text: "本回合结束后,立即推进科特里克所在区域的兵线,本次推进友方英雄+2兵力。"
	},
	{
		id: "C10",
		hero: "h17",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "C11",
		hero: "h17",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "骨质盾甲",
		text: "1个◎周围的单位本回合+3护甲,并获得「反击:缴械」。"
	},
	{
		id: "C12",
		hero: "h18",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: [],
		name: "隧道围杀",
		text: "将1个◎周围的友方英雄传送至1个◎没有敌方英雄的野区。本回合,该英雄+1力量。"
	},
	{
		id: "C13",
		hero: "h18",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "就地反击",
		text: "本回合,伊萨托斯克+2护甲。对至多1个◎同区域的敌方英雄造成2点DMG。"
	},
	{
		id: "C14",
		hero: "h18",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "四通八达",
		text: "附着于伊萨托斯克直至其被击败。野区阶段结束时,伊萨托斯克可以对1个◎2格内的野怪或界外魔造成1点DMG。"
	},
	{
		id: "C15",
		hero: "h18",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["t", "u"],
		name: "天痕猎手",
		text: "仅能在您的购买阶段施放。本回合伊萨托斯克+X力量且+X护甲。X为其计划卡上的MP点数。本轮,伊萨托斯克的攻击只能指定界外魔为目标,且无视其坚韧能力。"
	},
	{
		id: "C16",
		hero: "h18",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "C17",
		hero: "h18",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "破土而出",
		text: "若伊萨托斯克不为目标,移动至1个◎相邻且存在界外魔或野怪的区域。若如此做,对该野怪或界外魔造成2点穿透DMG,且无视其坚韧及反击能力。"
	},
	{
		id: "C18",
		hero: "h19",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: [],
		name: "裂地禁咒",
		text: "额外花费:2点MP。对1个◎周围区域内至多5个◎敌人造成1点穿透DMG与缴械。"
	},
	{
		id: "C19",
		hero: "h19",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "虚空图腾",
		text: "从你的弃牌堆选择1张非终极技能的卡牌。若可行,由内拉克伦如同在你手牌中一般将其施放。"
	},
	{
		id: "C20",
		hero: "h19",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "咒面飞针",
		text: "选择燃烧、冰冻、眩晕、沉默其中之一。对1个◎周围敌人造成2点穿透DMG以及你选择的状态。"
	},
	{
		id: "C21",
		hero: "h19",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["u"],
		name: "穿心祭礼",
		text: "对1个◎周围的界外魔造成8点DMG,忽视其坚韧与反击能力。"
	},
	{
		id: "C22",
		hero: "h19",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "C23",
		hero: "h19",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "深渊魔矢",
		text: "对1个◎周围区域内至多2个◎非野怪敌人造成1点穿透DMG与缴械。"
	},
	{
		id: "C24",
		hero: "h21",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "咣!",
		text: "本回合,扎克尔+2护甲。对至多1个◎周围敌方英雄造成3点DMG。"
	},
	{
		id: "C25",
		hero: "h21",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "咚咚!",
		text: "本回合,当扎克尔将一个单位传送至一个区域时,他可以对该区域中至多2个◎敌人造成2点DMG并缴械。"
	},
	{
		id: "C26",
		hero: "h21",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "嗖!",
		text: "冰冻1个周围的英雄并将该英雄传送至一个与其相邻的区域。本回合,该英雄不能宣告施法行动。"
	},
	{
		id: "C27",
		hero: "h21",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["r", "u"],
		name: "砰!",
		text: "攻击1个◎同区域的敌人,本次攻击扎克尔+2力量。若本次攻击命中一个英雄,可以将其传送至除扎克尔方水晶外的任意一个区域。"
	},
	{
		id: "C28",
		hero: "h21",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "C29",
		hero: "h21",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "临场指挥",
		text: "附着于扎克尔直至本回合结束。周围的友方小兵+3护甲。"
	},
	{
		id: "C30",
		hero: "h22",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "引魂之链",
		text: "吸引并缴械1个◎2格内的友方英雄。"
	},
	{
		id: "C31",
		hero: "h22",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "锁魂勾魄",
		text: "吸引并缴械1个◎2格内的敌方英雄。该英雄本回合不能宣告施法行动。"
	},
	{
		id: "C32",
		hero: "h22",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "仰天大笑",
		text: "为寇海治疗4点HP。本回合,寇海+1护甲,且对手在攻击时必须指定寇海为目标(若可行)。"
	},
	{
		id: "C33",
		hero: "h22",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["u"],
		name: "魔王降临",
		text: "额外花费:1点HP。传送至1个◎有防御塔或水晶的其他区域。若你如此做,对该区域至多6个敌人造成1点DMG与眩晕。"
	},
	{
		id: "C34",
		hero: "h22",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "C35",
		hero: "h22",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "锁魂勾魄",
		text: "吸引并缴械1个◎2格内的敌方英雄。该英雄本回合不能宣告施法行动。"
	},
	{
		id: "C36",
		hero: "h23",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "淤泥沼泽",
		text: "眩晕并吸引每个周围的敌方英雄,并对他们造成1点DMG。本回合,阻止他们法术的「移动」「传送」和「驱逐」效果。"
	},
	{
		id: "C37",
		hero: "h23",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["t"],
		name: "万树有灵",
		text: "仅能在您的购买阶段且南塔卡位于野区时施放。传送至1个◎没有敌方英雄的野区。本轮,南塔卡+2先攻。下一次小兵阶段推迟至本轮结束时再进行。"
	},
	{
		id: "C38",
		hero: "h23",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "秽土转生",
		text: "额外花费:1点MP。若南塔卡位于一个交战区域,在该区域放置1个友方小兵。本回合,所有区域都视为野区。"
	},
	{
		id: "C39",
		hero: "h23",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["u"],
		name: "君令臣服",
		text: "在1个◎周围的交战区域放置2个友方小兵。本回合,所有区域都视为野区。"
	},
	{
		id: "C40",
		hero: "h23",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "C41",
		hero: "h23",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "凋零牵引",
		text: "无视野区指定目标的限制,缴械并吸引1个◎相邻的敌方英雄,同时对其造成2点DMG。"
	},
	{
		id: "C42",
		hero: "h20",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "血祭回生",
		text: "额外花费:对1个2格内的友方英雄造成2点穿透伤害。为1个◎周围单位治疗6点HP,并移除其1个状态。你不能指定额外花费中造成伤害的单位为目标。"
	},
	{
		id: "C43",
		hero: "h20",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "骨质盾甲",
		text: "1个◎周围的单位本回合+3护甲,并获得「反击:缴械」。"
	},
	{
		id: "C44",
		hero: "h20",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "刻痕诅咒",
		text: "附着于1个周围敌方英雄,直至特拉卡里或该英雄被击败。缴械被附着的英雄。该缴械状态被移除时,再次缴械该英雄。"
	},
	{
		id: "C45",
		hero: "h20",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["u"],
		name: "故土归约",
		text: "选择其一:-将1个待复活英雄改为战备。-将1个疲劳英雄改为战备,该英雄必须今天曾被击败。-移除1个兵线上的界外魔指示物。"
	},
	{
		id: "C46",
		hero: "h20",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "C47",
		hero: "h20",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "疗愈仪式",
		text: "为1个◎相邻单位治疗3点HP,并移除其1个状态。若特拉卡里在一个争夺区域,该英雄本回合+1护甲。"
	},
	{
		id: "D00",
		hero: "h24",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "濯光结界",
		text: "你可以移除2格内1个◎单位上的1个状态。阻止其本回合下一次失去HP。"
	},
	{
		id: "D01",
		hero: "h24",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "寒炽天罚",
		text: "冰冻并燃烧1个2格内的英雄。本回合,该英雄不能宣告施法行动。"
	},
	{
		id: "D02",
		hero: "h24",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "灵澈之息",
		text: "将1个◎3格内的其他友方英雄移动至1个◎与其相邻的区域。"
	},
	{
		id: "D03",
		hero: "h24",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["u"],
		name: "圣疗",
		text: "为1个◎3格内的友方英雄治疗8点HP、移除其所有状态。该英雄立即升级。"
	},
	{
		id: "D04",
		hero: "h24",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "D05",
		hero: "h24",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "辉煌照耀",
		text: "为至多2个◎周围单位治疗2点HP并分别移除每个目标的所有状态。本回合,所有HP不为初始值的目标+1护甲。"
	},
	{
		id: "D06",
		hero: "h25",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "御风而行",
		text: "将2格内1个◎其他友方英雄移动至多2次。本轮,该英雄+1兵力。"
	},
	{
		id: "D07",
		hero: "h25",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "破界风压",
		text: "驱逐并冰冻◎所有同区域的其他英雄。"
	},
	{
		id: "D08",
		hero: "h25",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["t"],
		name: "风眼静域",
		text: "仅能在您的购买阶段施放。将本卡牌附着于艾克里特直至本轮结束。本轮,阻止所有不在艾克里特周围的小兵推进。"
	},
	{
		id: "D09",
		hero: "h25",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["u"],
		name: "狂岚碎空",
		text: "驱逐至多4个周围敌人,同时对他们造成2点DMG与沉默。"
	},
	{
		id: "D10",
		hero: "h25",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "D11",
		hero: "h25",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "兵随风至",
		text: "额外花费:1点MP。在1个◎周围的交战区域放置1个友方小兵。"
	},
	{
		id: "D12",
		hero: "h26",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["t"],
		name: "日渐精进",
		text: "仅能在您的购买阶段施放。本轮,哈布拉特+X先攻值且+X点力量。X为当前的天数。选择任意1个敌方英雄,哈布拉特本轮只能攻击该英雄。"
	},
	{
		id: "D13",
		hero: "h26",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: [],
		name: "磅礴刀锋",
		text: "选择1个◎周围的敌人。本回合哈布拉特下一次攻击无视「弱小敌人」规则,且会对选择的敌人造成溢出的DMG。溢出的DMG指的是击败目标后多出的DMG。"
	},
	{
		id: "D14",
		hero: "h26",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "索魂之息",
		text: "附着于1个周围的敌方英雄,直至该英雄或哈布拉特被击败。被附着的英雄始终视为在哈布拉特的攻击射程内(野区指定目标的限制仍会生效)。"
	},
	{
		id: "D15",
		hero: "h26",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["t", "u"],
		name: "刃光掣影",
		text: "仅能在您的购买阶段施放。本轮,哈布拉特计划卡上的AP点翻倍。"
	},
	{
		id: "D16",
		hero: "h26",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "D17",
		hero: "h26",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "光辉冲击",
		text: "移动至1个◎相邻区域。若如此做,你可以对该区域中的1个敌方英雄或界外魔造成2点DMG与沉默。"
	},
	{
		id: "D18",
		hero: "h27",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "扇舞惊鸿",
		text: "额外花费:1点MP。对至多3个◎周围的敌人造成1点DMG与冰冻。"
	},
	{
		id: "D19",
		hero: "h27",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "魅力绽放",
		text: "本回合,肯努伊+3护甲。沉默或眩晕至多1个◎周围的敌方英雄。"
	},
	{
		id: "D20",
		hero: "h27",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["t"],
		name: "风姿绰绰",
		text: "仅能在您的购买阶段施放。附着于肯努伊直至本轮结束。3格内的敌方英雄除非剩余0点MP、或在科努伊周围,否则不能攻击。若那些英雄宣告一个移动行动,他们必须靠近肯努伊。(本效果不适用于法术效果提供的移动,例如「闪现」)。"
	},
	{
		id: "D21",
		hero: "h27",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["t", "u"],
		name: "回响之舞",
		text: "仅能在您的购买阶段施放。本轮,肯努伊+2先攻。可以传送至1个◎任意其他区域。若如此做,对1个该区域的敌方英雄造成2点DMG与缴械。"
	},
	{
		id: "D22",
		hero: "h27",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "D23",
		hero: "h27",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "错误引导",
		text: "附着于肯努伊直至本轮结束。阻止周围敌人的反击能力。"
	},
	{
		id: "D24",
		hero: "h29",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "帝敕咒",
		text: "仅能在您的购买阶段引导。本卡牌上每有2个充能,选择一项执行,可多次选择同一项:-抽1张牌。-驱逐1个◎周围的英雄。-本轮,塞瑟鲁+1兵力。"
	},
	{
		id: "D25",
		hero: "h29",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "钻心咒",
		text: "仅能在您的购买阶段引导。对1个◎周围区域中至多X个◎敌人造成1点穿透DMG与眩晕,X为本卡牌上的充能数量。"
	},
	{
		id: "D26",
		hero: "h29",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "闪雷咒",
		text: "仅能在您的购买阶段引导。对1个◎周围敌方英雄造成X点穿透DMG与沉默,X为本卡牌上的充能数量。"
	},
	{
		id: "D27",
		hero: "h29",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["r", "u"],
		name: "绝语终章",
		text: "将1个◎已引导法术上的充能翻倍。然后,施放该法术,且无需弃置该卡牌和其上的充能。"
	},
	{
		id: "D28",
		hero: "h29",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "D29",
		hero: "h29",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "破天惊雷",
		text: "对1个◎周围区域中至多2个◎非野怪敌人造成1点穿透DMG与沉默。"
	},
	{
		id: "D30",
		hero: "h30",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["t"],
		name: "回流",
		text: "仅能在沙法帝位于一个没有敌方英雄的野区时施放。额外花费:弃置3张手牌。沙法帝重置为战备状况。"
	},
	{
		id: "D31",
		hero: "h30",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["r"],
		name: "解质",
		text: "本回合,沙法帝拥有坚韧效果。对同区域至多1个◎敌方英雄造成1点穿透DMG与沉默。"
	},
	{
		id: "D32",
		hero: "h30",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: ["r"],
		name: "影猎",
		text: "附着于沙法帝直至其被击败。当沙法西击败一个野怪时,赚取3金币。【TODO:「沙法西」疑为卡面笔误,待英文核对】"
	},
	{
		id: "D33",
		hero: "h30",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["t", "u"],
		name: "折跃",
		text: "仅能在您的购买阶段施放。传送至任意1个◎交战区域。若如此做,对该区域的至多2个敌人造成2点DMG与沉默。"
	},
	{
		id: "D34",
		hero: "h30",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "D35",
		hero: "h30",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "时滞",
		text: "选择任意1个野怪或界外魔。本回合,当其下次即将受到DMG时,阻止所有DMG。"
	},
	{
		id: "D36",
		hero: "h28",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: ["t"],
		name: "暴风集结",
		text: "仅能在科派克斯的回合开始时施放。额外花费:所有AP和所有MP。抽4张牌。"
	},
	{
		id: "D37",
		hero: "h28",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "雷霆震击",
		text: "选择不在周围的1个◎的兵线区域。对该区域的1个◎敌方英雄造成1点穿透DMG与沉默。"
	},
	{
		id: "D38",
		hero: "h28",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "连锁电击",
		text: "额外花费:弃置1张手牌。科派克斯本回合下次攻击可以额外指定她所在区域的至多3个敌人作为目标。"
	},
	{
		id: "D39",
		hero: "h28",
		mp: 1,
		ap: 3,
		atk: "4",
		flags: ["r", "u"],
		name: "风暴之王",
		text: "额外花费:击败1个周围的友方小兵。将4点穿透DMG分配给至多4个任意位置的敌人。(可不在同一区域)。"
	},
	{
		id: "D40",
		hero: "h28",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻的区域。"
	},
	{
		id: "D41",
		hero: "h28",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: [],
		name: "轰天雷击",
		text: "攻击1个◎周围且在兵线上的敌人。"
	},
	{
		id: "D42",
		hero: "h31",
		mp: 4,
		ap: 1,
		atk: "2",
		flags: ["r"],
		name: "裁决冲击",
		text: "驱逐并沉默1个◎周围区域的1个◎敌方英雄。若成功将其驱逐,移动至目标区域。"
	},
	{
		id: "D43",
		hero: "h31",
		mp: 3,
		ap: 1,
		atk: "3",
		flags: [],
		name: "圣盾辉环",
		text: "对至多2个◎同区域的敌人造成1点DMG与燃烧。若你在施放本牌时,该区域存在5个或更多敌方小兵,则改为指定3个敌人为目标。"
	},
	{
		id: "D44",
		hero: "h31",
		mp: 2,
		ap: 2,
		atk: "1+",
		flags: [],
		name: "替身之影",
		text: "附着于2格内1个◎友方英雄,直至夏德鲁斯被击败。若被附着的英雄将要受到DMG,夏德鲁斯必须代替其受到该DMG。(夏德鲁斯与该英雄各自使用自己的护甲值。)"
	},
	{
		id: "D45",
		hero: "h31",
		mp: 3,
		ap: 2,
		atk: "4",
		flags: ["r", "u"],
		name: "神圣之域",
		text: "将夏德鲁斯以及1个◎周围区域的所有小兵传送至那条兵线的「M」出生点。然后,将该兵线上友方被摧毁的防御塔全部重建。"
	},
	{
		id: "D46",
		hero: "h31",
		mp: 1,
		ap: 2,
		atk: "2",
		flags: ["r"],
		name: "闪现",
		text: "移动至1个◎相邻区域。"
	},
	{
		id: "D47",
		hero: "h31",
		mp: 0,
		ap: 3,
		atk: "2",
		flags: ["r"],
		name: "虚无之盾",
		text: "本回合,1个◎周围单位+3护甲并获得「反击:沉默」。"
	}
], x = Object.fromEntries(b.map((e) => [e.id, e])), ee = {
	id: "onward",
	tier: "beta",
	mechanics: ["hand-management", "action-points"],
	interactionTags: ["team-based"],
	nameKey: "games.onward.name",
	descKey: "games.onward.desc",
	rulesKey: "games.onward.rules",
	icon: "⚔️",
	iconImg: "games/onward.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/onward/en.pdf" },
	precacheAssets: ["board.webp"],
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#19bda9",
	releasedAt: "2026-10-07",
	search: {
		py: "wang zhe bing xian",
		init: "wzbx"
	},
	hotseat: "cover"
}, te = [
	{
		id: "i00",
		name: "狂热药剂",
		color: "red",
		cost: 3,
		n: 2,
		text: "+1力量。"
	},
	{
		id: "i01",
		name: "宽刃剑",
		color: "red",
		cost: 9,
		n: 2,
		text: "+2力量。"
	},
	{
		id: "i02",
		name: "地行者之吻",
		color: "red",
		cost: 6,
		n: 2,
		text: "行动:对1个◎周围的敌方英雄或小兵造成1点穿透DMG,每回合限一次。"
	},
	{
		id: "i03",
		name: "战争霜锤",
		color: "red",
		cost: 10,
		n: 1,
		text: "+2力量。攻击附带冰冻。"
	},
	{
		id: "i04",
		name: "虚空法杖",
		color: "red",
		cost: 11,
		n: 1,
		text: "+2力量。攻击造成穿透DMG。"
	},
	{
		id: "i05",
		name: "巨熊战斧",
		color: "red",
		cost: 7,
		n: 1,
		text: "首张攻击卡总是视为有+。"
	},
	{
		id: "i06",
		name: "欺诈手套",
		color: "red",
		cost: 9,
		n: 1,
		text: "攻击可以指定1个◎额外敌人作为目标,该敌人必须是英雄。"
	},
	{
		id: "i07",
		name: "退潮之书",
		color: "red",
		cost: 5,
		n: 1,
		text: "当本英雄宣告一次攻击时,查看并重新排序您牌库顶的2张卡牌。"
	},
	{
		id: "i08",
		name: "棱透之镜",
		color: "red",
		cost: 6,
		n: 1,
		text: "行动:花费1点MP,获得1点AP。每回合限一次。"
	},
	{
		id: "i09",
		name: "灌木护甲",
		color: "blue",
		cost: 6,
		n: 2,
		text: "+1护甲。"
	},
	{
		id: "i10",
		name: "治疗药剂",
		color: "blue",
		cost: 4,
		n: 2,
		text: "行动:弃置本卡牌,为本英雄治疗4点HP并移除一个状态。"
	},
	{
		id: "i11",
		name: "回城卷轴",
		color: "blue",
		cost: 3,
		n: 2,
		text: "在你的购买阶段弃置本卡牌:本轮结束时,本英雄传送至友方水晶区域并回复8点HP。"
	},
	{
		id: "i12",
		name: "焕新之符",
		color: "blue",
		cost: 5,
		n: 1,
		text: "+1针对攻击的护甲。阻止以本英雄为目标的攻击卡上的+。"
	},
	{
		id: "i13",
		name: "图腾护盾",
		color: "blue",
		cost: 7,
		n: 1,
		text: "+2针对攻击的护甲。"
	},
	{
		id: "i14",
		name: "佐纳人偶",
		color: "blue",
		cost: 8,
		n: 1,
		text: "反击:2点DMG。(仅针对英雄。)"
	},
	{
		id: "i15",
		name: "月壳铠甲",
		color: "blue",
		cost: 12,
		n: 1,
		text: "在所有英雄的回合内+2护甲。"
	},
	{
		id: "i16",
		name: "蛹蜕头盔",
		color: "blue",
		cost: 7,
		n: 1,
		text: "若本英雄将要失去3点或更多HP,则只会失去2点HP。"
	},
	{
		id: "i17",
		name: "魂之盒",
		color: "blue",
		cost: 6,
		n: 1,
		text: "若本英雄将要被击败,将其HP设置为3并弃置本卡牌。"
	},
	{
		id: "i18",
		name: "速度药剂",
		color: "yellow",
		cost: 3,
		n: 2,
		text: "+1先攻。购买时,获得优先权。"
	},
	{
		id: "i19",
		name: "闪光之靴",
		color: "yellow",
		cost: 8,
		n: 2,
		text: "+1点MP。(本英雄计划时。)"
	},
	{
		id: "i20",
		name: "雷霆长刀",
		color: "yellow",
		cost: 6,
		n: 2,
		text: "攻击射程为“周围”,且攻击附带眩晕。"
	},
	{
		id: "i21",
		name: "连发弩机",
		color: "yellow",
		cost: 5,
		n: 1,
		text: "每回合的首次攻击可以指定3格内的目标。"
	},
	{
		id: "i22",
		name: "风之斗篷",
		color: "yellow",
		cost: 11,
		n: 1,
		text: "+2点MP。(本英雄回合开始时。)"
	},
	{
		id: "i23",
		name: "闪亮面具",
		color: "yellow",
		cost: 6,
		n: 1,
		text: "+2先攻。购买时,获得优先权。"
	},
	{
		id: "i24",
		name: "努普提恩星盘",
		color: "yellow",
		cost: 9,
		n: 1,
		text: "+3先攻。购买时,获得优先权。"
	},
	{
		id: "i25",
		name: "成长守卫",
		color: "yellow",
		cost: 7,
		n: 1,
		text: "购买时,失去优先权。计划阶段,对手的计划卡需面朝上打出。当本英雄失去HP时,弃置本卡牌。"
	},
	{
		id: "i26",
		name: "日落守卫",
		color: "yellow",
		cost: 9,
		n: 1,
		text: "购买时,失去优先权。计划阶段,对手的计划卡需面朝上打出。当本英雄回合开始时或被击败时,弃置本卡牌。"
	},
	{
		id: "i27",
		name: "狩猎号角",
		color: "green",
		cost: 4,
		n: 2,
		text: "若本英雄在水晶的2格内,+1兵力。"
	},
	{
		id: "i28",
		name: "绽放之旗",
		color: "green",
		cost: 8,
		n: 2,
		text: "每个周围存在友方小兵的交战区域+1兵力。"
	},
	{
		id: "i29",
		name: "惩罚之刃",
		color: "green",
		cost: 5,
		n: 2,
		text: "每回合一次,攻击可以指定1个◎额外的敌人为目标,该目标必须是小兵。"
	},
	{
		id: "i30",
		name: "利刃之靴",
		color: "green",
		cost: 5,
		n: 1,
		text: "进入一个区域时,对该区域的1个◎敌方小兵造成1点DMG。"
	},
	{
		id: "i31",
		name: "爬行者之弦",
		color: "green",
		cost: 6,
		n: 1,
		text: "攻击可以驱逐并冰冻目标。"
	},
	{
		id: "i32",
		name: "卡姆努权杖",
		color: "green",
		cost: 9,
		n: 1,
		text: "周围的敌方小兵开始花费兵力时,他们失去2兵力。"
	},
	{
		id: "i33",
		name: "兵势药剂",
		color: "green",
		cost: 9,
		n: 1,
		text: "行动:在周围1个◎交战区域放置1个友方小兵。每回合限一次。"
	},
	{
		id: "i34",
		name: "毁灭者",
		color: "green",
		cost: 9,
		n: 1,
		text: "攻击可以指定1个◎额外敌人作为目标,该敌人必须是小兵或防御塔。"
	},
	{
		id: "i35",
		name: "鳞鼓",
		color: "green",
		cost: 11,
		n: 1,
		text: "若本英雄HP≥5,+2兵力。"
	}
], S = Object.fromEntries(te.map((e) => [e.id, e])), C = (e, t, n, r, i) => ({
	id: e,
	kind: t,
	x: n,
	y: r,
	adj: i
}), w = [
	C("NL", "nexus", 14, 86, [
		"A1",
		"C1",
		"B1",
		"JML"
	]),
	C("NS", "nexus", 86, 14, [
		"A5",
		"C5",
		"B5",
		"JMR"
	]),
	C("A1", "lane", 12, 66, [
		"NL",
		"A2",
		"JML"
	]),
	C("A2", "lane", 10, 40, [
		"A1",
		"M1",
		"JTL"
	]),
	C("M1", "lane", 22, 14, [
		"A2",
		"A4",
		"JTL",
		"JTC"
	]),
	C("A4", "lane", 52, 8, [
		"M1",
		"A5",
		"JTC"
	]),
	C("A5", "lane", 80, 10, [
		"A4",
		"NS",
		"JMR"
	]),
	C("C1", "lane", 30, 70, [
		"NL",
		"C2",
		"JML"
	]),
	C("C2", "lane", 40, 60, [
		"C1",
		"M2",
		"JML",
		"JBL",
		"R1"
	]),
	C("M2", "lane", 50, 50, ["C2", "C4"]),
	C("C4", "lane", 60, 40, [
		"M2",
		"C5",
		"JTC",
		"JBR",
		"R2"
	]),
	C("C5", "lane", 70, 30, [
		"C4",
		"NS",
		"JMR"
	]),
	C("B1", "lane", 20, 90, ["NL", "B2"]),
	C("B2", "lane", 48, 92, [
		"B1",
		"M3",
		"JBL"
	]),
	C("M3", "lane", 78, 86, [
		"B2",
		"B4",
		"JBL",
		"JBR"
	]),
	C("B4", "lane", 90, 60, [
		"M3",
		"B5",
		"JBR"
	]),
	C("B5", "lane", 88, 34, [
		"B4",
		"NS",
		"JMR"
	]),
	C("JTL", "jungle", 22, 26, [
		"A2",
		"M1",
		"JTC",
		"JML",
		"R1"
	]),
	C("JTC", "jungle", 42, 30, [
		"M1",
		"A4",
		"JTL",
		"R1",
		"C4"
	]),
	C("JML", "jungle", 18, 52, [
		"A1",
		"C1",
		"C2",
		"NL",
		"R1"
	]),
	C("JBR", "jungle", 78, 74, [
		"B4",
		"M3",
		"JBL",
		"JMR",
		"R2"
	]),
	C("JMR", "jungle", 82, 48, [
		"A5",
		"C5",
		"C4",
		"NS",
		"R2"
	]),
	C("JBL", "jungle", 58, 70, [
		"M3",
		"B2",
		"JBR",
		"R2",
		"C2"
	]),
	C("R1", "river", 30, 38, [
		"JTL",
		"JTC",
		"JML",
		"C2"
	]),
	C("R2", "river", 70, 62, [
		"JBR",
		"JBL",
		"JMR",
		"C4"
	])
], T = Object.fromEntries(w.map((e) => [e.id, e])), E = [
	[
		"NL",
		"A1",
		"A2",
		"M1",
		"A4",
		"A5",
		"NS"
	],
	[
		"NL",
		"C1",
		"C2",
		"M2",
		"C4",
		"C5",
		"NS"
	],
	[
		"NL",
		"B1",
		"B2",
		"M3",
		"B4",
		"B5",
		"NS"
	]
], ne = [
	"M1",
	"M2",
	"M3"
], re = {
	JTL: 4,
	JTC: 6,
	JML: 5,
	JMR: 5,
	JBL: 6,
	JBR: 4
}, ie = (e, t) => e < t ? `${e}|${t}` : `${t}|${e}`, ae = E.flatMap((e, t) => e.slice(0, -1).map((n, r) => ({
	edge: ie(n, e[r + 1]),
	team: r < 3 ? 0 : 1,
	lane: t
})));
function oe(e, t, n, r) {
	if (!T[e]?.adj.includes(t)) return !1;
	let i = n[ie(e, t)];
	return i === void 0 || i === r;
}
function D(e, t, n, r) {
	if (e === t) return 0;
	let i = /* @__PURE__ */ new Set([e]), a = [e], o = 0;
	for (; a.length > 0 && o < 12;) {
		o += 1;
		let e = [];
		for (let s of a) for (let a of T[s].adj) if (!i.has(a) && oe(s, a, n, r)) {
			if (a === t) return o;
			i.add(a), e.push(a);
		}
		a = e;
	}
	return Infinity;
}
//#endregion
//#region src/games/onward/data/heroes.ts
var se = [
	{
		id: "h00",
		pos: "r0c0",
		name: "秋元",
		title: "炽焰杀手",
		cls: "刺客",
		color: "red",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "不灭之刃",
			text: "当秋元处于燃烧状态时,他的力量+3。行动:秋元获得燃烧。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "永恒之焰",
				text: "当秋元处于燃烧状态时,他的力量+5。行动:秋元获得燃烧。"
			}
		}
	},
	{
		id: "h01",
		pos: "r0c1",
		name: "美雪",
		title: "灵媚狐仙",
		cls: "控制",
		color: "blue",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "灵觉唤醒",
			text: "周围的敌方英雄施放法术时,必须承受2点DMG与燃烧作为额外花费。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "灵觉链接",
				text: "周围的敌方英雄施放法术时,必须承受4点DMG与燃烧作为额外花费。"
			}
		}
	},
	{
		id: "h02",
		pos: "r1c0",
		name: "北斋",
		title: "炎盔斗士",
		cls: "坦克",
		color: "blue",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "易燃之躯",
			text: "北斋+1护甲。敌方小兵必须优先攻袭北斋(若可行)。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "魔火之躯",
				text: "北斋+3护甲。敌方小兵必须优先攻袭北斋(若可行)。"
			}
		}
	},
	{
		id: "h03",
		pos: "r1c1",
		name: "夜牙",
		title: "复仇死神",
		cls: "战士",
		color: "yellow",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "复仇先驱",
			text: "当夜牙在自己的回合中进入一个区域时,他可以驱逐1个◎该区域的敌方英雄。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "厄运使者",
				text: "当夜牙在自己的回合中进入一个区域时,他可以驱逐至多2个◎该区域的敌方英雄。"
			}
		}
	},
	{
		id: "h04",
		pos: "r0c2",
		name: "木知惠",
		title: "烈焰行者",
		cls: "法师",
		color: "green",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "希望之火",
			text: "当木知惠造成DMG时,每对一个单位造成伤害,为自己治疗1点HP。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "焕新之火",
				text: "当木知惠造成DMG时,每对一个单位造成伤害,为自己治疗2点HP。"
			}
		}
	},
	{
		id: "h05",
		pos: "r0c3",
		name: "坂越",
		title: "炎之忍者",
		cls: "射手",
		color: "red",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "隐匿藏踪",
			text: "当坂越失去1点或更多HP时,他可以移动至1个◎相邻区域。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "且战且退",
				text: "当坂越造成1点或更多DMG、或是失去1点或更多HP时,他都可以移动至1个◎相邻区域。"
			}
		}
	},
	{
		id: "h06",
		pos: "r1c2",
		name: "多米斯",
		title: "岩灵军团",
		cls: "推线",
		color: "green",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "碎岩游勇",
			text: "每有4点HP,多米斯就+1兵力。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "峦潮之军",
				text: "每有2点HP,多米斯就+1兵力。"
			}
		}
	},
	{
		id: "h07",
		pos: "r1c3",
		name: "库玛雅",
		title: "余烬影刃",
		cls: "打野",
		color: "yellow",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "灰烬少女",
			text: "当敌方英雄离开库玛雅的所在区域时,库玛雅可以对该英雄造成2点DMG与燃烧。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "余烬少女",
				text: "当敌方英雄离开库玛雅的所在区域时,库玛雅可以对该英雄造成2点DMG与燃烧。库玛雅针对非燃烧状态的敌人+3护甲。"
			}
		}
	},
	{
		id: "h08",
		pos: "r2c0",
		name: "歌妲",
		title: "深海人鱼",
		cls: "推线",
		color: "green",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "潮汐之声",
			text: "当歌妲击败一个敌方小兵时,她可以失去1点HP来在1个◎周围的交战区域放置1个友方小兵。(每个歌妲的回合限一次。)"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "深海回响",
				text: "当歌妲击败一个敌方小兵时,她可以失去1点HP来在1个◎周围的交战区域放置2个友方小兵。(每个歌妲的回合限一次。)"
			}
		}
	},
	{
		id: "h09",
		pos: "r2c1",
		name: "芙蕾赫尔",
		title: "万生之主",
		cls: "控制",
		color: "blue",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "生灵女王",
			text: "行动:对1个◎周围的英雄治疗3点HP。(每个芙蕾赫尔的回合限一次。)"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "万物之主",
				text: "行动:对1个◎2格内的英雄治疗4点HP。(每个芙蕾赫尔的回合限一次。)"
			}
		}
	},
	{
		id: "h10",
		pos: "r2c2",
		name: "希拉维",
		title: "狂野猫女",
		cls: "刺客",
		color: "red",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "狂躁野猫",
			text: "HP≥7时,希拉维+3力量。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "狂莽猎手",
				text: "HP≥5时,希拉维+4力量。"
			}
		}
	},
	{
		id: "h11",
		pos: "r2c3",
		name: "布莱尔瓦",
		title: "冰霜护卫",
		cls: "坦克",
		color: "blue",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "坚毅守护",
			text: "周围的友方英雄+1护甲。(包括布莱尔瓦自身。)"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "无畏守护",
				text: "周围的友方英雄+2护甲。(包括布莱尔瓦自身。)"
			}
		}
	},
	{
		id: "h12",
		pos: "r2c2b",
		name: "科乔夫",
		title: "冰咒术士",
		cls: "法师",
		color: "green",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "能量聚集",
			text: "行动:花费1点MP来抽1张卡牌。(每个科乔夫的回合限一次。)"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "灵能窥探",
				text: "行动:花费1点MP来抽2张卡牌。(每个科乔夫的回合限一次。)"
			}
		}
	},
	{
		id: "h13",
		pos: "r1c4",
		name: "古尔布贾恩",
		title: "战意狂熊",
		cls: "战士",
		color: "yellow",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "残暴斗士",
			text: "古尔布贾恩的攻击可以额外指定1个非小兵的敌人为目标。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "狂怒斗士",
				text: "古尔布贾恩的攻击可以指定周围的敌人为目标,且可以额外指定1个敌人为目标。"
			}
		}
	},
	{
		id: "h14",
		pos: "r2c4",
		name: "赫拉尔",
		title: "丛林疾影",
		cls: "打野",
		color: "yellow",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "林间穿梭",
			text: "赫拉尔无视野区指定目标的限制。行动:若赫拉尔位于野区,传送至1个◎2格内的野区。(每个赫拉尔的回合限一次。)"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "丛林猎手",
				text: "赫拉尔无视野区指定目标的限制。行动:若赫拉尔位于野区,传送至1个◎另一个野区。本回合,他针对兵线上的敌方英雄+2力量。(每个赫拉尔的回合限一次。)"
			}
		}
	},
	{
		id: "h15",
		pos: "r1c5",
		name: "沃希尔德",
		title: "寒冰游侠",
		cls: "射手",
		color: "red",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "冰弓射击",
			text: "沃希尔德的攻击可以指定相邻区域的敌人、或正好距离为2的敌人为目标。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "冰霜之箭",
				text: "沃希尔德的攻击可以指定2格内的敌人为目标。她的攻击附带冰冻。"
			}
		}
	},
	{
		id: "h16",
		pos: "r3c0",
		name: "阿其拉",
		title: "毒蜘蛛",
		cls: "射手",
		color: "red",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "毒雾笼罩",
			text: "在任何英雄的回合中,当1个◎周围敌方英雄失去HP时,该英雄额外失去1点HP。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "致命毒雾",
				text: "在任何英雄的回合中,当1个周围的敌方英雄失去HP时,该英雄额外失去2点HP。"
			}
		}
	},
	{
		id: "h17",
		pos: "r3c1",
		name: "科特里克",
		title: "千军统帅",
		cls: "坦克",
		color: "blue",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "索特兰庇护",
			text: "周围的友方小兵+2针对法术、攻击与能力的护甲。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "托洛特之佑",
				text: "科特里克与其周围的友方小兵+2针对法术、攻击与能力的护甲。"
			}
		}
	},
	{
		id: "h18",
		pos: "r3c2",
		name: "伊萨托斯克",
		title: "遁地猎手",
		cls: "打野",
		color: "yellow",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "地下之民",
			text: "行动:将1个◎相邻的友方英雄传送至1个◎与伊萨托斯克相邻的区域。(每个伊萨托斯克的回合限一次。)"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "阴界霸主",
				text: "行动:将1个◎相邻的友方英雄传送至1个◎与伊萨托斯克相邻的区域。(每个伊萨托斯克的回合限两次。)"
			}
		}
	},
	{
		id: "h19",
		pos: "r3c3",
		name: "内拉克伦",
		title: "万相咒师",
		cls: "法师",
		color: "green",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "诡咒密语",
			text: "内拉克伦可以施放你手中的任意法术。若其如此做,将那些法术牌上的英雄名替换成「内拉克伦」。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "万相祈术",
				text: "内拉克伦可以施放你手中的任意法术。若其如此做,将那些法术牌上的英雄名替换成“内拉克伦”。内拉克伦还可以复制所有友方英雄面板的能力,将其上的英雄名替换成“内拉克伦”。"
			}
		}
	},
	{
		id: "h20",
		pos: "r2c4b",
		name: "特拉卡里",
		title: "冥渊祭司",
		cls: "控制",
		color: "blue",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "舍身御卒",
			text: "若周围的友方小兵将要被击败,特拉卡里可以失去1点HP作为替代。(每回合最多一次。)"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "免死之祀",
				text: "若周围的友方小兵将要被击败,特拉卡里可以阻止这次击败。(每回合最多一次。)"
			}
		}
	},
	{
		id: "h21",
		pos: "r2c5",
		name: "扎克尔",
		title: "野蛮力士",
		cls: "战士",
		color: "yellow",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "力大无穷",
			text: "扎克尔的攻击可以将目标英雄传送至1个◎扎克尔2格内的区域。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "残暴重击",
				text: "扎克尔的攻击附带缴械,且可以将目标英雄传送至1个◎扎克尔3格内的区域。"
			}
		}
	},
	{
		id: "h22",
		pos: "r3c4",
		name: "寇海",
		title: "锁链魔王",
		cls: "推线",
		color: "green",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "梦魇钩锁",
			text: "行动:吸引并眩晕1个◎2格内的敌方英雄。(每个寇海的回合限一次。)"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "湮灭之链",
				text: "行动:吸引并眩晕1个◎3格内的敌方英雄。(每个寇海的回合限两次。)"
			}
		}
	},
	{
		id: "h23",
		pos: "r3c5",
		name: "南塔卡",
		title: "不死树妖",
		cls: "刺客",
		color: "red",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "送葬根须",
			text: "南塔卡位于野区或河道时,周围每有一个友方小兵她+1力量。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "致死缠绕",
				text: "南塔卡位于野区或河道时,周围每有一个友方小兵她+2力量。"
			}
		}
	},
	{
		id: "h24",
		pos: "r4c0",
		name: "阿胡媞",
		title: "圣光主宰",
		cls: "控制",
		color: "blue",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "寂静法界",
			text: "当一个敌方英雄进入周围区域时,将其沉默并冰冻。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "圣辉光环",
				text: "当一个敌方英雄进入周围区域时,将其沉默并冰冻。当一个友方英雄进入周围区域时,为其治疗1点HP。"
			}
		}
	},
	{
		id: "h25",
		pos: "r4c1",
		name: "艾克里特",
		title: "风啸飒影",
		cls: "推线",
		color: "green",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "风聚云集",
			text: "阻止任何英雄进入艾克里特所在区域。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "风从云顺",
				text: "敌人不能指定艾克里特所在区域、以及其中的任何单位为目标,除了艾克里特本身。当一个英雄进入艾克里特所在区域时,将其驱逐。"
			}
		}
	},
	{
		id: "h26",
		pos: "r4c2",
		name: "哈布拉特",
		title: "盲眼双刀",
		cls: "刺客",
		color: "red",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "夺命刽子手",
			text: "哈布拉特+X力量。X=其计划卡上的AP点数。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "首席行刑官",
				text: "哈布拉特+X力量。X=其计划卡上的MP点数与AP点数之和。"
			}
		}
	},
	{
		id: "h27",
		pos: "r4c3",
		name: "肯努伊",
		title: "绝韵舞姬",
		cls: "战士",
		color: "yellow",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "星涟舞曲",
			text: "肯努伊位于兵线上时,其获得针对攻击的坚韧(包括来自反击的攻击)。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "幻彩舞曲",
				text: "肯努伊位于兵线上时,其获得针对攻击的坚韧(包括来自反击的攻击)。当对手为一个法术或攻击指定目标时,其必须指定肯努伊为目标(若可行)。"
			}
		}
	},
	{
		id: "h28",
		pos: "r3c4",
		name: "科派克斯",
		title: "雷霆使者",
		cls: "射手",
		color: "red",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "雷电女王",
			text: "在每张友方英雄法术卡的结尾增加以下效果:“科派克斯对至多1个◎其周围的敌方英雄造成1点DMG”。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "风暴女王",
				text: "在每张友方英雄法术卡的结尾增加以下效果:“科派克斯对至多1个◎其周围的敌方英雄造成1点DMG”。"
			}
		}
	},
	{
		id: "h29",
		pos: "r3c5",
		name: "塞瑟鲁",
		title: "御心天尊",
		cls: "法师",
		color: "green",
		rng: "ranged",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "天痕御法",
			text: "若要引导一个法术,将该法术面朝上放置在版图旁。每个计划阶段开始时,在每个已引导的法术上添加1个金币指示物作为“充能”。塞瑟鲁可以施放已引导的法术,若要如此做,弃置该法术以及其上的全部充能。当塞瑟鲁被击败时,弃置所有充能。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "苍穹至尊",
				text: "若要引导一个法术,将该法术面朝上放置在版图旁。每个计划阶段开始时,在每个已引导的法术上添加2个金币指示物作为“充能”。塞瑟鲁可以施放已引导的法术,若要如此做,弃置该法术以及其上的全部充能。当塞瑟鲁被击败时,弃置所有充能。行动:引导弃牌堆中1个塞瑟鲁的法术。(每个塞瑟鲁的回合限一次。)"
			}
		}
	},
	{
		id: "h30",
		pos: "r4c4",
		name: "沙法帝",
		title: "时阙孤爵",
		cls: "打野",
		color: "yellow",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "虚空之影",
			text: "沙法帝+3先攻。周围敌人-1先攻。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "时光如梭",
				text: "沙法帝+5先攻。周围敌人-2先攻。"
			}
		}
	},
	{
		id: "h31",
		pos: "r4c5",
		name: "夏德鲁斯",
		title: "百炼天罡",
		cls: "坦克",
		color: "blue",
		rng: "melee",
		plan: {
			mp: 2,
			ap: 1
		},
		ability: {
			name: "最终防线",
			text: "夏德鲁斯+3护甲且-2力量。"
		},
		up: {
			plan: {
				mp: 3,
				ap: 1
			},
			ability: {
				name: "永恒堡垒",
				text: "夏德鲁斯+3护甲。"
			}
		}
	}
], ce = Object.fromEntries(se.map((e) => [e.id, e])), O = (e) => +(e === 0), k = (e, t) => e.teams[t], le = (e, t) => ce[e.heroes[t].def], ue = (e, t) => e.heroes[t].out ? null : e.heroes[t].zone;
function A(e, t) {
	let n = [];
	for (let [r, i] of Object.entries(e.heroes)) !i.out && i.zone === t && n.push({
		k: "hero",
		id: r
	});
	let r = e.minions[t];
	r && (r[0] > 0 && n.push({
		k: "minion",
		zone: t,
		team: 0
	}), r[1] > 0 && n.push({
		k: "minion",
		zone: t,
		team: 1
	}));
	for (let [r, i] of Object.entries(e.towers)) {
		let [e, i] = r.split("|");
		(e === t || i === t) && n.push({
			k: "tower",
			edge: r
		});
	}
	let i = e.jungles[t];
	return i && i.stack.length > 0 && n.push({
		k: "monster",
		zone: t
	}), e.outsider.zone === t && n.push({ k: "outsider" }), T[t]?.kind === "nexus" && n.push({
		k: "nexus",
		team: t === "NL" ? 0 : 1
	}), n;
}
function j(e, t) {
	switch (t.k) {
		case "hero": return e.heroes[t.id].team;
		case "minion": return t.team;
		case "tower": return e.towers[t.edge] ?? null;
		case "nexus": return t.team;
		case "monster": return null;
		case "outsider": return e.outsider.tamed ? e.outsider.team ?? null : null;
	}
}
function de(e, t) {
	switch (t.k) {
		case "hero": return ue(e, t.id);
		case "minion": return t.zone;
		case "tower": return null;
		case "monster": return t.zone;
		case "nexus": return t.team === 0 ? "NL" : "NS";
		case "outsider": return e.outsider.zone;
	}
}
function fe(e, t, n) {
	return T[t].adj.filter((r) => oe(t, r, e.towers, n));
}
function M(e, t, n) {
	return [t, ...fe(e, t, n)];
}
function pe(e, t) {
	return e.hands[t].filter((t) => x[e.cardInsts[t].card].flags.includes("r"));
}
function me(e, t) {
	let n = e.heroes[t], r = le(e, t);
	return n.leveled ? r.up.plan : r.plan;
}
function he(e, t) {
	e.pending ? e.deferred.push(t) : e.pending = t;
}
function N(e, t) {
	if (t.src === "spell" && t.on) {
		let n = e.heroes[t.on];
		if (n && !n.out && n.statuses.includes("silence")) return !1;
	}
	return !0;
}
function P(e, t) {
	let n = e.heroes[t];
	return !!n && !n.out && !n.statuses.includes("silence");
}
//#endregion
//#region src/games/onward/rules/aura.ts
var F = (e, t) => e.heroes[t].leveled, I = (e, t, n) => (e.equipped[t] ?? []).some((t) => e.itemInsts[t].item === n);
function ge(e, t) {
	return e.effects.some((t) => t.key === "allJungle" && N(e, t)) ? "jungle" : T[t]?.kind ?? "lane";
}
function _e(e, t, n, r) {
	let i = 0;
	if (t.k === "outsider" && e.outsider.tamed && (i += 5), t.k === "hero") {
		let a = e.heroes[t.id];
		for (let r of e.effects) {
			if (!N(e, r) || r.on !== t.id) continue;
			let a = r.args ?? {};
			typeof a.armor == "number" && (i += a.armor), typeof a.armorVsAttack == "number" && n === "attack" && (i += a.armorVsAttack);
		}
		P(e, t.id) && (a.def === "h02" && (i += F(e, t.id) ? 3 : 1), a.def === "h31" && (i += 3));
		for (let [n, r] of Object.entries(e.heroes)) r.def === "h11" && !r.out && r.team === a.team && P(e, n) && r.zone && t.id !== n && a.zone && M(e, r.zone, r.team).includes(a.zone) && (i += F(e, n) ? 2 : 1);
		a.def === "h17" && F(e, t.id) && P(e, t.id) && n !== "effect" && (i += 2), a.def === "h07" && F(e, t.id) && P(e, t.id) && (r?.k === "hero" && e.heroes[r.id].statuses.includes("burn") || (i += 3)), I(e, t.id, "i09") && (i += 1), I(e, t.id, "i15") && (i += 2), I(e, t.id, "i12") && n === "attack" && (i += 1), I(e, t.id, "i13") && n === "attack" && (i += 2);
	}
	if (t.k === "minion") {
		let r = t.zone;
		for (let [a, o] of Object.entries(e.heroes)) o.def === "h17" && !o.out && o.team === t.team && P(e, a) && o.zone && M(e, o.zone, o.team).includes(r) && n !== "effect" && (i += 2);
		for (let n of e.effects) {
			if (!N(e, n) || n.key !== "minionArmor" || n.team !== t.team) continue;
			let a = e.heroes[n.by];
			a && !a.out && a.zone && M(e, a.zone, a.team).includes(r) && (i += Number(n.args?.armor ?? 0));
		}
	}
	return i;
}
function ve(e, t) {
	let n = e.heroes[t], r = 0;
	for (let n of e.effects) N(e, n) && n.on === t && typeof n.args?.str == "number" && (r += n.args.str);
	if (P(e, t)) {
		let i = n.def;
		if (i === "h00" && n.statuses.includes("burn") && (r += F(e, t) ? 5 : 3), i === "h10" && (!F(e, t) && n.hp >= 7 && (r += 3), F(e, t) && n.hp >= 5 && (r += 4)), i === "h23" && n.zone && (ge(e, n.zone) === "jungle" || ge(e, n.zone) === "river")) {
			let i = 0;
			for (let t of M(e, n.zone, n.team)) i += e.minions[t]?.[n.team] ?? 0;
			r += i * (F(e, t) ? 2 : 1);
		}
		if (i === "h26" && n.planCard !== null) {
			let i = e.cardInsts[n.planCard], a = i ? ye(e, i.card) : null;
			a && (r += F(e, t) ? a.mp + a.ap : a.ap);
		}
		i === "h31" && !F(e, t) && (r -= 2);
	}
	return I(e, t, "i00") && (r += 1), I(e, t, "i01") && (r += 2), I(e, t, "i03") && (r += 2), I(e, t, "i04") && (r += 2), r;
}
function ye(e, t) {
	let n = x[t];
	return n ? {
		mp: n.mp,
		ap: n.ap
	} : null;
}
function be(e, t, n) {
	if (t.k === "nexus") return !0;
	if (t.k === "outsider") return e.outsider.toughThisTurn;
	if (t.k === "hero") {
		for (let n of e.effects) if (N(e, n) && n.on === t.id && n.args?.tough === !0) return !0;
		let r = e.heroes[t.id];
		if (r.def === "h27" && P(e, t.id) && n === "attack" && r.zone && ge(e, r.zone) === "lane") return !0;
	}
	return !1;
}
function xe(e, t) {
	let n = e.heroes[t], r = 0;
	for (let n of e.effects) N(e, n) && n.on === t && typeof n.args?.init == "number" && (r += n.args.init);
	n.def === "h30" && P(e, t) && (r += F(e, t) ? 5 : 3);
	for (let [i, a] of Object.entries(e.heroes)) a.def === "h30" && !a.out && i !== t && P(e, i) && a.team !== n.team && a.zone && n.zone && M(e, a.zone, a.team).includes(n.zone) && (r -= F(e, i) ? 2 : 1);
	return I(e, t, "i18") && (r += 1), I(e, t, "i23") && (r += 2), I(e, t, "i24") && (r += 3), n.statuses.includes("stun") && (r -= 2), r;
}
function Se(e, t) {
	let n = e.heroes[t], r = 0;
	for (let n of e.effects) N(e, n) && n.on === t && typeof n.args?.momentum == "number" && (r += n.args.momentum);
	if (P(e, t) && n.def === "h06" && (r += Math.floor(n.hp / (F(e, t) ? 2 : 4))), I(e, t, "i27") && n.zone) {
		let t = n.team === 0 ? "NL" : "NS";
		D(n.zone, t, e.towers, n.team) <= 2 && (r += 1);
	}
	return I(e, t, "i35") && n.hp >= 5 && (r += 2), r;
}
function Ce(e, t) {
	let n = e.heroes[t], r = le(e, t), i = n.leveled, a = P(e, t), o = (r.rng, "base");
	a && n.def === "h13" && i && (o = "nearby"), a && n.def === "h15" && (o = i ? "within2" : "adjOrDist2"), I(e, t, "i20") && (o = "nearby");
	let s = r.rng === "melee", c = (e, n, r, i) => {
		let a = fe(e, n, i);
		for (let n of e.effects) if (n.key === "D14" && N(e, n)) {
			let i = n.on;
			if ((i ? e.heroes[i]?.zone : null) === r && n.by === t) return !0;
		}
		return o === "nearby" ? r === n || a.includes(r) : o === "adjOrDist2" ? a.includes(r) || D(n, r, e.towers, i) === 2 : o === "within2" ? D(n, r, e.towers, i) <= 2 : s ? r === n : a.includes(r);
	}, l = e.turn?.hero === t && !e.turn.usedActions.includes("attacked"), u = I(e, t, "i21") && l ? (e, t, n, r) => c(e, t, n, r) || D(t, n, e.towers, r) <= 3 : c, d = [];
	a && n.def === "h13" && d.push({
		n: 1,
		what: i ? "sameZoneAny" : "nonMinion"
	}), I(e, t, "i06") && d.push({
		n: 1,
		what: "hero"
	}), I(e, t, "i29") && e.turn && !e.turn.usedActions.includes("i29") && d.push({
		n: 1,
		what: "minion"
	}), I(e, t, "i34") && d.push({
		n: 1,
		what: "minionOrTower"
	});
	for (let n of e.effects) n.key === "D38" && n.on === t && N(e, n) && d.push({
		n: 3,
		what: "sameZoneAny"
	});
	let f = {};
	return a && n.def === "h15" && i && (f.freeze = !0), I(e, t, "i03") && (f.freeze = !0), I(e, t, "i20") && (f.stun = !0), I(e, t, "i31") && (f.expel = !0, f.freeze = !0), a && n.def === "h21" && (f.teleportWithin = i ? 3 : 2, i && (f.disarm = !0)), {
		canHit: u,
		extraTargets: d,
		riders: f,
		piercing: I(e, t, "i04") || void 0
	};
}
function we(e, t, n, r) {
	let i = r.filter((e) => e.k === "hero").map((e) => e.id), a = (r, a) => {
		if (!i.includes(r)) return !1;
		let o = e.heroes[r];
		return o.out || o.team === t ? !1 : a.includes(n);
	};
	for (let t of e.effects) {
		if (!N(e, t) || !t.on) continue;
		let n = t.args?.taunt;
		if (n !== "attack" && n !== "spell" && n !== "both") continue;
		let r = n === "both" ? ["attack", "spell"] : [n];
		if (a(t.on, [...r])) return t.on;
	}
	for (let [t, n] of Object.entries(e.heroes)) if (n.def === "h27" && n.leveled && P(e, t) && a(t, ["attack", "spell"])) return t;
	return null;
}
function Te(e, t, n) {
	for (let [r, i] of Object.entries(e.heroes)) if (!(i.def !== "h25" || i.out || i.leveled || r === t) && P(e, r) && i.zone === n) return !1;
	return !0;
}
function Ee(e, t, n, r) {
	for (let [i, a] of Object.entries(e.heroes)) if (a.def === "h25" && !a.out && a.leveled && P(e, i) && a.zone === t && a.team !== n && r !== i) return !0;
	for (let r of e.effects) {
		if (r.key !== "A44" || !N(e, r)) continue;
		let i = e.heroes[r.on ?? ""];
		if (i && !i.out && i.zone === t && i.team !== n) return !0;
	}
	return !1;
}
//#endregion
//#region src/games/onward/rules/events.ts
var L = {}, R = {}, De = {};
function z(e, t) {
	let n = [], r = e.turn ? e.heroes[e.turn.hero].team : null, i = [...e.effects].sort((t, n) => {
		let i = t.team ?? (t.on ? e.heroes[t.on]?.team : void 0) ?? e.heroes[t.by]?.team ?? 0, a = n.team ?? (n.on ? e.heroes[n.on]?.team : void 0) ?? e.heroes[n.by]?.team ?? 0;
		return r === null || i === a ? t.id - n.id : i === r ? -1 : 1;
	});
	n.push(...i);
	for (let r of n) {
		let n = L[r.key];
		n?.onEvent && N(e, r) && (r.on && e.heroes[r.on]?.out || n.onEvent(e, r, t));
	}
	for (let [n, r] of Object.entries(e.heroes)) {
		let i = R[r.def];
		i && P(e, n) && i(e, n, t);
	}
	for (let [n, r] of Object.entries(e.equipped)) if (!e.heroes[n]?.out) for (let i of r) {
		let r = De[e.itemInsts[i].item];
		r && r(e, n, t);
	}
}
function Oe(e, t) {
	return e.onceMarks[t] !== e.round && (e.onceMarks[t] = e.round, !0);
}
var ke = { fn: null };
//#endregion
//#region src/games/onward/rules/combat.ts
function Ae(e, t) {
	switch (t.k) {
		case "hero": return e.heroes[t.id].hp;
		case "minion": return 1;
		case "tower": return 1;
		case "monster": return 1;
		case "nexus": return e.nexusHp[t.team];
		case "outsider": return e.outsider.hp;
	}
}
function je(e, t) {
	switch (t.k) {
		case "hero": return e.heroes[t.id].out;
		case "minion": return (e.minions[t.zone]?.[t.team] ?? 0) <= 0;
		case "tower": return e.towers[t.edge] === void 0;
		case "monster": return (e.jungles[t.zone]?.stack.length ?? 0) <= 0;
		case "nexus": return e.nexusHp[t.team] <= 0;
		case "outsider": return e.outsider.zone === null || e.outsider.tamed;
	}
}
function B(e, t, n, r, i) {
	if (r <= 0 || je(e, n)) return {
		dealt: 0,
		defeated: !1
	};
	if (n.k === "hero" && t && (t.k !== "hero" || t.id !== n.id)) {
		let a = Me(e, n.id);
		if (a && !je(e, {
			k: "hero",
			id: a
		})) return B(e, t, {
			k: "hero",
			id: a
		}, r, i);
	}
	let a = n.k === "hero" ? n.id : n.k === "monster" ? `m:${n.zone}` : n.k === "outsider" ? "outsider" : null;
	if (a) {
		let r = e.effects.findIndex((e) => e.args?.preventNextDmg === !0 && e.on === a);
		if (r >= 0) return e.effects.splice(r, 1), t && !i.isRetaliate && Pe(e, n, t), {
			dealt: 0,
			defeated: !1
		};
	}
	let o = r;
	if (i.piercing || (o = Math.max(0, o - _e(e, n, i.via, t))), !i.ignoreTough && be(e, n, i.via) && o >= 2 && (o = 1), n.k === "hero" && o >= 3 && (e.equipped[n.id] ?? []).some((t) => e.itemInsts[t].item === "i16") && (o = 2), o <= 0) return t && !i.isRetaliate && Pe(e, n, t), {
		dealt: 0,
		defeated: !1
	};
	Ne(e, n, o), z(e, {
		k: "dmg",
		source: t,
		target: n,
		dealt: o,
		via: i.via
	});
	let s = n.k === "minion" || n.k === "tower" || n.k === "monster" || Ae(e, n) <= 0;
	return s && n.k === "minion" && ke.fn?.(e, n.zone, n.team) && (e.minions[n.zone][n.team] += 1, s = !1), s && Ie(e, n, t), t && !i.isRetaliate && Pe(e, n, t), {
		dealt: o,
		defeated: s
	};
}
function Me(e, t) {
	for (let n of e.effects) {
		if (n.key === "B19" && n.on === t) {
			let t = e.heroes[n.by];
			if (t && !t.out) return n.by;
		}
		if (n.key === "D44" && n.on === t) {
			let t = e.heroes[n.by];
			if (t && !t.out) return n.by;
		}
	}
	return null;
}
function Ne(e, t, n) {
	switch (t.k) {
		case "hero":
			e.heroes[t.id].hp = Math.max(0, e.heroes[t.id].hp - n);
			break;
		case "minion":
			e.minions[t.zone][t.team] = Math.max(0, e.minions[t.zone][t.team] - 1);
			break;
		case "nexus":
			e.nexusHp[t.team] = Math.max(0, e.nexusHp[t.team] - n);
			break;
		case "outsider": e.outsider.hp = Math.max(0, e.outsider.hp - n);
	}
}
function Pe(e, t, n) {
	let r = null;
	if (t.k === "tower") r = e.towers[t.edge] ?? null;
	else if (t.k === "nexus") r = t.team;
	else if (t.k === "outsider") {
		if (e.outsider.tamed || e.outsider.zone === null) return;
	} else if (t.k === "hero") {
		if (!(e.effects.some((e) => e.on === t.id && (e.args?.retaliate !== void 0 || e.args?.retaliateStatus !== void 0)) || (e.equipped[t.id] ?? []).some((t) => e.itemInsts[t].item === "i14"))) return;
		r = e.heroes[t.id].team;
	} else return;
	if (n.k === "hero") {
		let t = e.heroes[n.id];
		if (t.zone && e.effects.some((n) => {
			if (n.key !== "D23") return !1;
			let r = e.heroes[n.by];
			return r && !r.out && r.zone && r.team !== t.team && Fe(r.zone, t.zone, e, r.team);
		})) return;
	}
	e.retaliateQueue.push({
		defender: t,
		defenderTeam: r,
		attacker: n
	});
}
function Fe(e, t, n, r) {
	return e === t || fe(n, e, r).includes(t);
}
function Ie(e, t, n) {
	if (t.k === "hero" || t.k === "outsider") for (let n of [...e.effects]) {
		if (n.key !== "A09") continue;
		let r = e.heroes[n.by];
		if (!r || r.out || t.k === "hero" && e.heroes[t.id].team !== r.team) continue;
		let i = t.k === "hero" ? e.heroes[t.id].zone : e.outsider.zone;
		if (i && r.zone && D(r.zone, i, e.towers, r.team) <= 3) {
			t.k === "hero" ? e.heroes[t.id].hp = 5 : e.outsider.hp = 5;
			return;
		}
	}
	if (t.k === "hero") {
		let n = e.equipped[t.id] ?? [], r = n.find((t) => e.itemInsts[t].item === "i17");
		if (r !== void 0) {
			e.heroes[t.id].hp = 3, e.equipped[t.id] = n.filter((e) => e !== r);
			let i = [
				"red",
				"yellow",
				"blue",
				"green"
			].indexOf("blue") * 2 + 1;
			e.market[i].unshift(r);
			return;
		}
	}
	switch (t.k) {
		case "hero": {
			let r = e.heroes[t.id];
			if (r.out = !0, r.zone = null, r.statuses = [], r.cond = r.cond === "ready" ? "exhausted" : "respawning", e.defeatedToday.includes(t.id) || e.defeatedToday.push(t.id), Le(e, t.id), r.def === "h29") for (let t of Object.keys(e.channeled)) e.discards[r.owner].push(Number(t)), delete e.channeled[Number(t)];
			let i = n?.k === "hero" ? n.id : null, a = n ? j(e, n) ?? O(r.team) : O(r.team);
			i && !e.heroes[i].leveled && e.heroes[i].team !== r.team ? ze(e, i) : a !== r.team && he(e, {
				k: "choose",
				seat: Be(e, a),
				chooseKind: "levelUp",
				args: { team: a }
			});
			break;
		}
		case "minion": break;
		case "tower":
			delete e.towers[t.edge];
			break;
		case "monster": {
			let r = e.jungles[t.zone].stack.pop() ?? 0, i = n ? j(e, n) ?? e.priority : e.priority;
			e.gold[i] += r;
			break;
		}
		case "outsider":
			if (--e.outsider.lives, e.outsider.lives <= 0) {
				e.outsider.tamed = !0;
				let t = n ? j(e, n) ?? e.priority : e.priority;
				e.outsider.team = t, e.log.push({
					kind: "outsiderTamed",
					args: { team: t }
				});
			} else {
				e.outsider.hp = 5, e.outsider.toughThisTurn = !0;
				let t = n ? j(e, n) ?? 0 : 0;
				he(e, {
					k: "choose",
					seat: Be(e, t),
					chooseKind: "outsiderToken",
					args: { team: t }
				});
			}
			break;
		case "nexus": e.phase = { k: "over" };
	}
	z(e, {
		k: "defeat",
		unit: t,
		killer: n
	});
}
function Le(e, t) {
	for (let n of [...e.effects]) {
		if (!n.cardInst || n.by !== t && n.on !== t) continue;
		let r = e.heroes[n.by]?.owner;
		r && e.discards[r].push(n.cardInst), e.effects = e.effects.filter((e) => e.id !== n.id);
	}
}
function Re(e, t) {
	let n = e.effects.find((e) => e.id === t);
	if (n) {
		if (n.cardInst !== void 0) {
			let t = e.heroes[n.by]?.owner;
			t && e.discards[t].push(n.cardInst);
		}
		e.effects = e.effects.filter((e) => e.id !== t);
	}
}
function ze(e, t) {
	let n = e.heroes[t];
	n.leveled = !0, n.hp = Math.min(9, n.hp + 2);
}
function Be(e, t) {
	return e.players.find((n) => e.teams[n] === t) ?? e.players[0];
}
function Ve(e, t, n) {
	let r = 0, i = [], a = n !== void 0 && (e.equipped[n] ?? []).some((t) => e.itemInsts[t].item === "i05");
	for (;;) {
		He(e, t);
		let n = e.decks[t].pop();
		if (n === void 0) break;
		i.push(n), e.discards[t].push(n);
		let o = x[e.cardInsts[n].card], s = parseInt(o.atk, 10);
		if (r += s, !(o.atk.includes("+") || a && i.length === 1)) break;
	}
	return {
		strength: r,
		cards: i
	};
}
function He(e, t) {
	if (e.decks[t].length > 0) return;
	let n = e.discards[t];
	e.discards[t] = [];
	for (let t = n.length - 1; t > 0; --t) {
		let r = Ue(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	e.decks[t] = n;
}
function Ue(t, n) {
	let r = e(t.seed, t.rngCursor, n);
	return t.rngCursor += 1, r;
}
function We(e, t) {
	return e.players.find((n) => e.teams[n] === t) ?? e.players[0];
}
//#endregion
//#region src/games/onward/rules/game.ts
function Ge(t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let e of se) {
		let t = r.get(e.color) ?? [];
		t.push(e.id), r.set(e.color, t);
	}
	let i = [], a = [];
	for (let o of [
		"red",
		"blue",
		"green",
		"yellow"
	]) {
		let s = [...r.get(o) ?? []], c = e(t, n.c, s.length);
		n.c += 1, i.push(s.splice(c, 1)[0]);
		let l = e(t, n.c, s.length);
		n.c += 1, a.push(s.splice(l, 1)[0]);
	}
	return [i, a];
}
function Ke(t, n, r) {
	let i = { c: 0 }, a = [...n];
	for (let t = a.length - 1; t > 0; --t) {
		let n = e(r, i.c, t + 1);
		i.c += 1, [a[t], a[n]] = [a[n], a[t]];
	}
	let o = {};
	n.length === 3 ? (o[a[0]] = 0, o[a[1]] = 1, o[a[2]] = 1) : a.forEach((e, t) => {
		o[e] = t < n.length / 2 ? 0 : 1;
	});
	let [s, c] = Ge(r, i), l = {}, u = {}, d = [...s.map((e) => ({
		def: e,
		team: 0
	})), ...c.map((e) => ({
		def: e,
		team: 1
	}))], f = {
		0: n.filter((e) => o[e] === 0),
		1: n.filter((e) => o[e] === 1)
	};
	d.forEach(({ def: e, team: t }, n) => {
		let r = `H${n}`, i = f[t][n % 4 % f[t].length];
		l[r] = {
			def: e,
			team: t,
			owner: i,
			hp: 9,
			cond: "ready",
			out: !1,
			leveled: !1,
			zone: t === 0 ? "NL" : "NS",
			statuses: [],
			planCard: null
		}, (u[i] ??= []).push(r);
	});
	let p = {}, m = {}, h = {}, g = {}, _ = 0;
	for (let t of n) {
		let a = [], s = [];
		for (let e of u[t]) {
			let t = l[e].def;
			for (let e of b.filter((e) => e.hero === t)) g[_] = { card: e.id }, e.flags.includes("u") ? s.push(_) : a.push(_), _ += 1;
		}
		for (let t = a.length - 1; t > 0; --t) {
			let n = e(r, i.c, t + 1);
			i.c += 1, [a[t], a[n]] = [a[n], a[t]];
		}
		p[t] = a, m[t] = s, h[t] = [];
		let c = n.length === 3 && f[o[t]].length === 1 ? 4 : 2;
		for (let e = 0; e < c; e += 1) {
			let e = p[t].pop();
			e !== void 0 && h[t].push(e);
		}
	}
	let v = {}, y = Array.from({ length: 8 }, () => []), x = 0, ee = [
		"red",
		"yellow",
		"blue",
		"green"
	];
	for (let e of te) {
		let t = ee.indexOf(e.color) * 2 + (e.n > 1 ? 0 : 1);
		for (let n = 0; n < e.n; n += 1) v[x] = { item: e.id }, y[t].push(x), x += 1;
	}
	for (let t of y) for (let n = t.length - 1; n > 0; --n) {
		let a = e(r, i.c, n + 1);
		i.c += 1, [t[n], t[a]] = [t[a], t[n]];
	}
	let S = {};
	for (let e of ae) S[e.edge] = e.team;
	let C = {};
	for (let [e, t] of Object.entries(re)) C[e] = { stack: [
		t,
		t,
		t
	] };
	return { state: {
		players: n,
		teams: o,
		controls: u,
		heroes: l,
		decks: p,
		discards: m,
		hands: h,
		cardInsts: g,
		market: y,
		itemInsts: v,
		equipped: {},
		towers: S,
		minions: {},
		jungles: C,
		outsider: {
			zone: null,
			lives: 4,
			hp: 5,
			tamed: !1,
			laneTokens: [],
			toughThisTurn: !1
		},
		nexusHp: [9, 9],
		gold: [0, 0],
		day: 1,
		priority: 0,
		round: 1,
		phase: {
			k: "plan",
			queue: [0, 1]
		},
		turn: null,
		pending: null,
		planned: [],
		effects: [],
		nextEffectId: 1,
		retaliateQueue: [],
		resolving: [],
		deferred: [],
		channeled: {},
		defeatedToday: [],
		onceMarks: {},
		pendingAfter: null,
		seed: r,
		rngCursor: i.c,
		beatMs: 0,
		log: []
	} };
}
function qe(e) {
	let t = e.phase;
	switch (t.k) {
		case "shop":
			t.queue.length > 1 ? e.phase = {
				k: "shop",
				queue: t.queue.slice(1)
			} : Je(e);
			break;
		case "plan":
			t.queue.length > 1 ? e.phase = {
				k: "plan",
				queue: t.queue.slice(1)
			} : Xe(e);
			break;
		case "turn": break;
		case "minions":
			if (e.pendingAfter) {
				let t = e.pendingAfter.fast;
				e.pendingAfter = null, Qe(e, t);
			} else t.roundEnd ? ut(e) : (e.phase = { k: "jungle" }, at(e), ot(e));
			break;
		case "jungle":
			ot(e);
			break;
		case "onward": ut(e);
	}
}
function Je(e) {
	let t = Object.values(e.heroes).find((e) => e.def === "h29");
	if (t && !t.out) {
		let n = t.leveled ? 2 : 1;
		for (let t of Object.keys(e.channeled)) e.channeled[Number(t)] += n;
	}
	e.phase = {
		k: "plan",
		queue: Ye(e)
	}, e.phase.k === "plan" && e.phase.queue.length === 0 && Xe(e);
}
function Ye(e) {
	let t = (t) => Object.values(e.heroes).some((e) => e.team === t && e.cond === "ready"), n = [];
	return t(e.priority) && n.push(e.priority), t(O(e.priority)) && n.push(O(e.priority)), n;
}
function Xe(e) {
	let t = e.planned;
	if (t.length === 0) {
		e.phase = { k: "onward" }, lt(e);
		return;
	}
	if (t.length === 1) {
		Ze(e, t[0].hero, !0);
		return;
	}
	let n = (t) => {
		let n = e.heroes[t], r = n.planCard === null ? null : e.cardInsts[n.planCard];
		return (r ? b.find((e) => e.id === r.card).mp : 0) + xe(e, t);
	}, [r, i] = t, a = n(r.hero), o = n(i.hero), s = r, c = i;
	o > a ? (s = i, c = r) : a === o && (s = r.team === e.priority ? r : i, c = s === r ? i : r, e.priority = O(e.priority)), e.planned = [s, c], Ze(e, s.hero, !0);
}
function Ze(e, t, n) {
	e.turn = {
		hero: t,
		mp: 0,
		ap: 0,
		usedActions: [],
		fast: n,
		fresh: !0,
		spentMp: 0
	}, e.phase = { k: "turn" }, z(e, {
		k: "turnStart",
		hero: t
	});
}
function Qe(e, t) {
	if (t) {
		if ($e(e)) {
			e.phase = { k: "jungle" }, at(e), ot(e);
			return;
		}
		e.phase = {
			k: "minions",
			order: [],
			idx: -1
		}, et(e);
		return;
	}
	st(e);
}
function $e(e) {
	return e.effects.some((t) => t.key === "delayMinions" && N(e, t));
}
function et(e) {
	if (e.phase.k !== "minions") return;
	let t = (e.phase.roundEnd ?? [
		0,
		1,
		2
	]).filter((t) => !e.phase.order.includes(t));
	if (t.length === 0) {
		qe(e);
		return;
	}
	if (t.length === 1) {
		e.phase.order.push(t[0]), tt(e, t[0]);
		return;
	}
	e.pending = {
		k: "choose",
		seat: Be(e, e.priority),
		chooseKind: "laneOrder",
		args: { lanes: t.join(",") }
	};
}
function tt(e, t) {
	let n = E[t].find((t) => (e.minions[t]?.[0] ?? 0) > 0 || (e.minions[t]?.[1] ?? 0) > 0);
	if (n && nt(e, n)) {
		e.log.push({
			kind: "pushBlocked",
			args: { lane: t }
		}), it(e, t);
		return;
	}
	if (n) {
		let r = (r) => {
			let i = e.minions[n]?.[r] ?? 0;
			for (let [t, a] of Object.entries(e.heroes)) !a.out && a.zone === n && a.team === r && (i += 1 + Se(e, t));
			for (let n of e.effects) n.key === "outsiderMark" && n.team === r && n.args?.lane === t && (i += 2);
			return Object.entries(e.heroes).some(([t, n]) => !n.out && n.team === r && (e.equipped[t] ?? []).some((t) => e.itemInsts[t].item === "i28")) && (e.minions[n]?.[r] ?? 0) > 0 && (i += 1), i;
		}, i = r(0) - r(1);
		if (i !== 0) {
			let r = i > 0 ? 0 : 1, a = Math.abs(i);
			Object.entries(e.heroes).some(([t, i]) => !i.out && i.team !== r && i.zone && (e.equipped[t] ?? []).some((t) => e.itemInsts[t].item === "i32") && M(e, i.zone, i.team).includes(n)) && (a = Math.max(0, a - 2));
			let o = e.effects.findIndex((e) => e.key === "A23" && e.args?.zone === n && e.team !== r);
			if (o >= 0 && (a = Math.max(0, a - 3), e.effects.splice(o, 1)), a > 0) {
				e.pending = {
					k: "minionPush",
					lane: t,
					momentum: a,
					team: r
				};
				return;
			}
		}
	}
	rt(e, t, n ?? null), it(e, t);
}
function nt(e, t) {
	for (let n of e.effects) if (N(e, n)) {
		if (n.key === "B02") {
			let r = e.heroes[n.on ?? ""];
			if (r && !r.out && r.zone && M(e, r.zone, r.team).includes(t)) return !0;
		}
		if (n.key === "D08") {
			let r = e.heroes[n.on ?? ""];
			if (r && !r.out && r.zone && !M(e, r.zone, r.team).includes(t)) return !0;
		}
	}
	return !1;
}
function rt(e, t, n) {
	let r = n ?? E[t][3], i = e.minions[r] ?? [0, 0];
	e.minions[r] = [i[0] + 1, i[1] + 1];
}
function it(e, t) {
	if (e.phase.k !== "minions") return;
	let n = e.phase.order;
	n.includes(t) || n.push(t), et(e);
}
function at(e) {
	for (let [t, n] of Object.entries(e.jungles)) {
		if (n.stack.length === 0) continue;
		let r = Object.values(e.heroes).filter((e) => !e.out && e.zone === t);
		if (r.length === 0) continue;
		let i = r.filter((e) => e.team === 0).length, a = r.filter((e) => e.team === 1).length;
		if (i === a) continue;
		let o = i > a ? 0 : 1, s = n.stack.pop() ?? 0;
		e.gold[o] += s, e.log.push({
			kind: "jungle",
			args: {
				zone: t,
				team: o,
				gold: s
			}
		});
	}
}
function ot(e) {
	let t = e.planned[1];
	if (t && e.turn?.fast) {
		Ze(e, t.hero, !1);
		return;
	}
	st(e);
}
function st(e) {
	z(e, { k: "roundEnd" });
	let t = $e(e), n = e.effects.filter((t) => t.key === "pushAtRoundEnd" && N(e, t)).map((e) => ct(String(e.args?.zone ?? ""))).filter((e) => e !== null);
	if (t || n.length > 0) {
		e.phase = {
			k: "minions",
			order: [],
			idx: -1,
			roundEnd: t ? [
				0,
				1,
				2
			] : [...new Set(n)]
		}, et(e);
		return;
	}
	if (!Object.values(e.heroes).some((e) => e.cond === "ready")) {
		e.phase = { k: "onward" }, lt(e);
		return;
	}
	ut(e);
}
function ct(e) {
	for (let t = 0; t < 3; t += 1) if (E[t].includes(e)) return t;
	return null;
}
function lt(e) {
	for (let t of Object.values(e.heroes)) t.cond === "respawning" ? t.cond = "exhausted" : t.cond === "exhausted" && (t.cond = "ready");
	if (e.defeatedToday = [], e.day === 1 && e.outsider.zone === null && !e.outsider.tamed && (e.outsider.zone = "R1", e.outsider.lives = 4, e.outsider.hp = 5, e.log.push({ kind: "outsiderEnter" })), e.day += 1, e.day > 5) {
		e.phase = { k: "over" };
		return;
	}
	ut(e);
}
function ut(e) {
	e.round += 1, e.planned = [], e.turn = null, e.effects = e.effects.filter((e) => e.expires !== "roundEnd"), e.phase = {
		k: "shop",
		queue: [e.priority, O(e.priority)]
	};
}
//#endregion
//#region src/games/onward/rules/spells.ts
var dt = class {
	s;
	caster;
	targets;
	cardInst;
	charges;
	constructor(e, t, n, r, i = 0) {
		this.s = e, this.caster = t, this.targets = n, this.cardInst = r, this.charges = i;
	}
	flags = /* @__PURE__ */ new Map();
	get hero() {
		return this.s.heroes[this.caster];
	}
	get team() {
		return this.s.heroes[this.caster].team;
	}
	zone() {
		return this.hero.out ? null : this.hero.zone;
	}
	dmg(e, t, n = {}) {
		if (e.k === "zone") return !1;
		let r = B(this.s, {
			k: "hero",
			id: this.caster
		}, e, t, {
			piercing: n.piercing,
			ignoreTough: n.ignoreTough,
			via: "spell"
		});
		return r.dealt > 0 || r.defeated;
	}
	freeAttack(e) {
		return ft(this.s, this.caster, e);
	}
	heal(e, t) {
		let n = this.s.heroes[e];
		n.hp = Math.min(9, n.hp + t);
	}
	healUnit(e, t) {
		e.k === "hero" && this.heal(e.id, t), e.k === "outsider" && (this.s.outsider.hp = Math.min(5, this.s.outsider.hp + t));
	}
	place(e, t) {
		return V(this.s, e, t, { spellEffect: !0 });
	}
	status(e, t) {
		let n = this.s.heroes[e];
		n.statuses.includes(t) || n.statuses.push(t);
	}
	cleanse(e, t) {
		let n = this.s.heroes[e];
		n.statuses = t ? [] : n.statuses.slice(1);
	}
	buff(e, t, n, r = "buff") {
		this.s.effects.push({
			id: this.s.nextEffectId++,
			key: r,
			by: this.caster,
			on: e,
			args: t,
			expires: n,
			src: "spell"
		});
	}
	addEffect(e) {
		this.s.effects.push({
			id: this.s.nextEffectId++,
			by: e.by ?? this.caster,
			src: "spell",
			...e
		});
	}
	draw(e, t) {
		for (let n = 0; n < t; n += 1) {
			He(this.s, e);
			let t = this.s.decks[e].pop();
			if (t === void 0) break;
			this.s.hands[e].push(t);
		}
	}
	gold(e, t) {
		this.s.gold[e] += t;
	}
	discardRandom(e, t) {
		for (let n = 0; n < t; n += 1) {
			let t = this.s.hands[e];
			if (t.length === 0) break;
			let n = Ue(this.s, t.length), [r] = t.splice(n, 1);
			this.s.discards[e].push(r);
		}
	}
	placeMinion(e, t, n = 1) {
		let r = this.s.minions[e] ?? [0, 0];
		r[t] += n, this.s.minions[e] = r;
	}
	get turn() {
		return this.s.turn;
	}
};
function V(e, t, n, r = {}) {
	let i = e.heroes[t], a = i.zone;
	if (a === n || !Te(e, t, n)) return !1;
	if (a) {
		let n = e.effects.findIndex((e) => e.key === "B25" && e.on === t && e.args?.zone === a);
		if (n >= 0) return e.effects.splice(n, 1), !1;
	}
	if (r.spellEffect) {
		if (e.effects.some((n) => n.key === "C36" && n.on === t && N(e, n))) return !1;
		for (let t of e.effects) {
			if (t.key !== "B32" || !N(e, t)) continue;
			let n = e.heroes[t.on ?? ""];
			if (n && !n.out && n.zone && a && n.team !== i.team && M(e, n.zone, n.team).includes(a)) return !1;
		}
	}
	return a && z(e, {
		k: "leave",
		hero: t,
		zone: a
	}), i.zone = n, i.out = !1, z(e, {
		k: "enter",
		hero: t,
		zone: n
	}), !0;
}
function ft(e, t, n) {
	return e.heroes[t].out ? [] : pt(e, t, [n], "spell");
}
function pt(e, t, n, r, i) {
	let a = e.heroes[t];
	if (a.out) return [];
	let o = Ce(e, t), s = n.filter((n, r) => {
		if (je(e, n)) return !1;
		let i = n.k === "tower" ? n.edge.split("|") : de(e, n) ? [de(e, n)] : [];
		if (!i.some((t) => o.canHit(e, a.zone, t, a.team))) return !1;
		for (let r of i) {
			if (ge(e, r) !== "jungle" || a.def === "h14" && P(e, t)) continue;
			let i = j(e, n);
			if ((i === null || i !== a.team) && !Object.values(e.heroes).some((e) => !e.out && e.zone === r && e.team === a.team)) return !1;
		}
		return !0;
	});
	if (s.length === 0) return [];
	let c = a.owner, l, u = a.statuses.includes("disarm"), d = e.effects.find((e) => e.key === "D13" && e.on === t);
	if (!d && s.every((n) => 2 >= Ae(e, n) + _e(e, n, r === "attack" ? "attack" : "spell", {
		k: "hero",
		id: t
	}))) l = 2;
	else if (u) l = 1;
	else {
		let n = Ve(e, c, t);
		if (l = n.strength, n.cards.length > 1 && s.some((t) => t.k === "hero" && (e.equipped[t.id] ?? []).some((t) => e.itemInsts[t].item === "i12"))) {
			let t = x[e.cardInsts[n.cards[0]].card];
			l = parseInt(t.atk, 10);
		}
	}
	u ? l = Math.min(l, 1) : l += ve(e, t);
	let f = e.effects.find((n) => n.on === t && typeof n.args?.nextAttackStr == "number" && N(e, n));
	f && (l += Number(f.args?.nextAttackStr ?? 0), e.effects = e.effects.filter((e) => e.id !== f.id)), l = Math.max(0, l);
	let p = e.effects.some((n) => n.on === t && n.args?.ignoreTough === 1 && N(e, n)), m = [];
	for (let n of s) {
		let s = l;
		n.k === "hero" && e.effects.some((r) => r.key === "A03" && r.on === n.id && r.by === t && N(e, r)) && (s *= 2);
		let c = B(e, {
			k: "hero",
			id: t
		}, n, s, {
			via: r,
			piercing: o.piercing,
			ignoreTough: p
		});
		if ((c.dealt > 0 || c.defeated) && m.push(n), (c.dealt > 0 || c.defeated) && n.k === "hero" && !e.heroes[n.id].out) {
			let t = e.heroes[n.id], r = (e) => {
				t.statuses.includes(e) || t.statuses.push(e);
			};
			if (o.riders.freeze && r("freeze"), o.riders.stun && r("stun"), o.riders.disarm && r("disarm"), f && r("burn"), o.riders.expel) {
				let t = mt(e, n.id);
				t && V(e, n.id, t);
			}
		}
		(c.dealt > 0 || c.defeated) && n.k === "hero" && o.riders.teleportWithin && i && D(a.zone, i, e.towers, a.team) <= o.riders.teleportWithin && V(e, n.id, i);
	}
	if (d) {
		e.effects = e.effects.filter((e) => e.id !== d.id);
		let n = d.args?.overflowHero;
		if (typeof n == "string" && !e.heroes[n]?.out) {
			let i = s[0];
			i && Ae(e, i) + l, B(e, {
				k: "hero",
				id: t
			}, {
				k: "hero",
				id: n
			}, l, { via: r });
		}
	}
	return z(e, {
		k: "attackResolved",
		hero: t,
		targets: m
	}), m;
}
function mt(e, t) {
	let n = e.heroes[t];
	if (!n.zone) return null;
	let r = n.team === 0 ? "NL" : "NS", i = T[n.zone].adj, a = null, o = Infinity;
	for (let e of i) {
		let t = D(e, r, {}, n.team);
		t < o && (o = t, a = e);
	}
	return a;
}
function ht(e, t, n, r, i = {}) {
	let a = gt(e, t, n);
	if (!a) return;
	let { heroId: o, card: s } = a, c = e.effects.findIndex((e) => e.on === o && e.args?.counterNextSpell === !0), l = c >= 0;
	l && e.effects.splice(c, 1);
	let u = e.channeled[n] !== void 0, d = u ? e.channeled[n] : 0, f = i.keepChannel ?? !1;
	if (!l) {
		let t = yt[s.id];
		if (t) {
			let i = new dt(e, o, r, n, d);
			t.run(i), i.flags.get("keepChannel") && (f = !0);
			for (let [t, n] of Object.entries(e.heroes)) {
				if (n.def !== "h28" || n.out || n.team !== e.heroes[o].team || !P(e, t)) continue;
				let r = n.zone;
				if (!r) continue;
				let i = M(e, r, n.team), a = Object.entries(e.heroes).find(([, e]) => !e.out && e.team !== n.team && e.zone && i.includes(e.zone));
				a && B(e, {
					k: "hero",
					id: t
				}, {
					k: "hero",
					id: a[0]
				}, 1, { via: "ability" });
			}
		}
	}
	let p = e.effects.some((e) => e.cardInst === n);
	if (u) f || (delete e.channeled[n], e.discards[t].push(n));
	else if (p) {
		let r = e.hands[t], i = r.indexOf(n);
		i >= 0 && r.splice(i, 1);
	} else {
		let r = e.hands[t], i = r.indexOf(n);
		i >= 0 && r.splice(i, 1), e.discards[t].push(n);
	}
	let m = e.heroes[o];
	!m.out && m.statuses.includes("burn") && B(e, null, {
		k: "hero",
		id: o
	}, 1, {
		piercing: !0,
		via: "effect"
	}), z(e, {
		k: "castResolved",
		hero: o,
		card: s.id,
		by: t
	});
}
function gt(e, t, n) {
	let r = x[e.cardInsts[n].card];
	if (!r) return null;
	let i = k(e, t), a = Object.keys(e.heroes).find((t) => e.heroes[t].def === r.hero && e.heroes[t].team === i && !e.heroes[t].out);
	if (a) return {
		heroId: a,
		card: r
	};
	let o = Object.keys(e.heroes).find((t) => e.heroes[t].def === "h19" && e.heroes[t].team === i && P(e, t));
	return o ? {
		heroId: o,
		card: r
	} : null;
}
function _t(e, t, n, r) {
	let i = e.heroes[t];
	if (i.out || !i.zone) return [];
	let a = i.zone;
	if (n.from === "target0" && r.length > 0) {
		let t = r[0], n = t.k === "zone" ? t.zone : de(e, t);
		n && (a = n);
	}
	let o = n.range, s = fe(e, a, i.team), c = (t) => o === "any" ? !0 : o === "same" ? t === a : o === "adjacent" ? s.includes(t) : o === "nearby" ? t === a || s.includes(t) : o === "notNearby" ? t !== a && !s.includes(t) : o === "dist2" ? D(a, t, e.towers, i.team) === 2 : D(a, t, e.towers, i.team) <= o, l = (t) => {
		switch (n.note) {
			case "contested": {
				let n = e.minions[t];
				return !!n && (n[0] > 0 || n[1] > 0);
			}
			case "jungle": return T[t]?.kind === "jungle";
			case "jungleNoEnemy": return T[t]?.kind === "jungle" && !Object.values(e.heroes).some((e) => !e.out && e.team !== i.team && e.zone === t);
			case "hasMonsterOrOutsider": return A(e, t).some((t) => t.k === "monster" || t.k === "outsider" && !e.outsider.tamed);
			case "hasTowerOrNexus": return t === "NL" || t === "NS" || Object.keys(e.towers).some((e) => e.split("|").includes(t));
			case "lane": return T[t]?.kind === "lane";
			default: return !0;
		}
	}, u = [];
	if (n.what === "zone") {
		for (let t of Object.keys(T)) c(t) && l(t) && (Ee(e, t, i.team) || u.push({
			k: "zone",
			zone: t
		}));
		return u;
	}
	for (let r of Object.keys(T)) if (c(r) && l(r)) {
		for (let a of A(e, r)) if (vt(e, t, a, n.what)) {
			if (Ee(e, r, i.team, a.k === "hero" ? a.id : void 0) || n.sight !== "ignore" && T[r]?.kind === "jungle" && j(e, a) !== i.team && !Object.values(e.heroes).some((e) => !e.out && e.zone === r && e.team === i.team)) continue;
			u.push(a);
		}
	}
	return u;
}
function vt(e, t, n, r) {
	let i = e.heroes[t].team, a = j(e, n);
	switch (r) {
		case "enemyHero": return n.k === "hero" && a === O(i);
		case "friendlyHero": return n.k === "hero" && a === i;
		case "otherFriendlyHero": return n.k === "hero" && a === i && n.id !== t;
		case "anyHero": return n.k === "hero";
		case "enemyUnit": return a === O(i) || n.k === "monster" || n.k === "outsider" && !e.outsider.tamed;
		case "enemyHeroOrOutsider": return n.k === "hero" && a === O(i) || n.k === "outsider" && !e.outsider.tamed;
		case "enemyHeroOrMinion": return n.k === "hero" && a === O(i) || n.k === "minion" && a === O(i);
		case "minion": return n.k === "minion" && a === O(i);
		case "anyMinion": return n.k === "minion";
		case "monster": return n.k === "monster";
		case "monsterOrOutsider": return n.k === "monster" || n.k === "outsider" && !e.outsider.tamed;
		case "outsider": return n.k === "outsider" && !e.outsider.tamed;
		case "tower": return n.k === "tower" && a === O(i);
		case "nexus": return n.k === "nexus" && a === O(i);
		case "unit": return !0;
		default: return !1;
	}
}
var yt = {};
//#endregion
//#region src/games/onward/rules/items.ts
function bt(e) {
	let t = S[e];
	return [
		"red",
		"yellow",
		"blue",
		"green"
	].indexOf(t.color) * 2 + (t.n > 1 ? 0 : 1);
}
var xt = {
	i02: [{
		key: "i02.sting",
		targets: [{
			what: "enemyHeroOrMinion",
			range: "nearby"
		}],
		run: (e) => {
			let t = e.targets[0];
			t && t.k !== "zone" && e.dmg(t, 1, { piercing: !0 });
		}
	}],
	i08: [{
		key: "i08.convert",
		targets: [],
		condition: (e) => (e.turn?.mp ?? 0) >= 1,
		run: (e) => {
			--e.s.turn.mp, e.s.turn.spentMp += 1, e.s.turn.ap += 1;
		}
	}],
	i10: [{
		key: "i10.heal",
		targets: [],
		run: (e) => {
			let t = e.s, n = t.equipped[e.caster] ?? [], r = n.find((e) => t.itemInsts[e].item === "i10");
			r !== void 0 && (t.equipped[e.caster] = n.filter((e) => e !== r), t.market[bt("i10")].unshift(r)), e.heal(e.caster, 4), e.cleanse(e.caster, !1);
		}
	}],
	i33: [{
		key: "i33.plant",
		targets: [{
			what: "zone",
			range: "nearby",
			note: "contested"
		}],
		run: (e) => {
			let t = e.targets[0];
			if (t?.k !== "zone") return;
			let n = e.s.minions[t.zone];
			!n || n[0] <= 0 && n[1] <= 0 || e.placeMinion(t.zone, e.team, 1);
		}
	}]
};
function St(e, t, n) {
	let r = e.heroes[t].team;
	(n === "i18" || n === "i23" || n === "i24") && (e.priority = r), (n === "i25" || n === "i26") && (e.priority = O(r));
}
function Ct(e, t, n) {
	n === "i11" && e.phase.k === "shop" && e.effects.push({
		id: e.nextEffectId++,
		key: "i11",
		by: t,
		on: t,
		args: {},
		expires: "roundEnd",
		src: "item"
	});
}
function wt(e, t) {
	let n = 0, r = e.equipped[t] ?? [];
	return r.some((t) => e.itemInsts[t].item === "i19") && (n += 1), r.some((t) => e.itemInsts[t].item === "i22") && (n += 2), {
		mp: n,
		ap: 0
	};
}
function Tt(e, t, n) {
	let r = e.equipped[t] ?? [], i = r.find((t) => e.itemInsts[t].item === n);
	i !== void 0 && (e.equipped[t] = r.filter((e) => e !== i), e.market[bt(n)].unshift(i));
}
L.i11 = { onEvent: (e, t, n) => {
	if (n.k !== "roundEnd") return;
	let r = e.heroes[t.on ?? ""];
	if (!r || r.out) {
		Re(e, t.id);
		return;
	}
	V(e, t.on ?? t.by, r.team === 0 ? "NL" : "NS"), r.hp = Math.min(9, r.hp + 8), Re(e, t.id);
} }, De.i30 = (e, t, n) => {
	if (n.k !== "enter" || n.hero !== t) return;
	let r = A(e, n.zone).find((n) => n.k === "minion" && j(e, n) === O(e.heroes[t].team));
	r && B(e, {
		k: "hero",
		id: t
	}, r, 1, { via: "effect" });
}, De.i25 = (e, t, n) => {
	n.k === "dmg" && n.target.k === "hero" && n.target.id === t && Tt(e, t, "i25");
}, De.i26 = (e, t, n) => {
	n.k === "turnStart" && n.hero === t && Tt(e, t, "i26"), n.k === "defeat" && n.unit.k === "hero" && n.unit.id === t && Tt(e, t, "i26");
};
//#endregion
//#region src/games/onward/rules/abilities.ts
var Et = {
	h00: [{
		key: "h00.burn",
		targets: [],
		run: (e) => e.status(e.caster, "burn")
	}],
	h09: [{
		key: "h09.heal",
		targets: [{
			what: "anyHero",
			range: "nearby"
		}],
		condition: (e, t) => !e.heroes[t].leveled,
		run: (e) => {
			let t = e.targets[0];
			t?.k === "hero" && e.heal(t.id, 3);
		}
	}, {
		key: "h09.healUp",
		targets: [{
			what: "anyHero",
			range: 2
		}],
		condition: (e, t) => e.heroes[t].leveled,
		run: (e) => {
			let t = e.targets[0];
			t?.k === "hero" && e.heal(t.id, 4);
		}
	}],
	h12: [{
		key: "h12.draw",
		targets: [],
		condition: (e, t) => (e.turn?.mp ?? 0) >= 1 && !e.heroes[t].leveled,
		run: (e) => {
			--e.s.turn.mp, e.s.turn.spentMp += 1, e.draw(e.hero.owner, 1);
		}
	}, {
		key: "h12.drawUp",
		targets: [],
		condition: (e, t) => (e.turn?.mp ?? 0) >= 1 && e.heroes[t].leveled,
		run: (e) => {
			--e.s.turn.mp, e.s.turn.spentMp += 1, e.draw(e.hero.owner, 2);
		}
	}],
	h14: [{
		key: "h14.hop",
		targets: [{
			what: "zone",
			range: 2
		}],
		condition: (e, t) => !e.heroes[t].leveled && ge(e, e.heroes[t].zone ?? "") === "jungle",
		run: (e) => {
			let t = e.targets[0];
			t?.k === "zone" && ge(e.s, t.zone) === "jungle" && e.place(e.caster, t.zone);
		}
	}, {
		key: "h14.hopUp",
		targets: [{
			what: "zone",
			range: "any"
		}],
		condition: (e, t) => e.heroes[t].leveled && ge(e, e.heroes[t].zone ?? "") === "jungle",
		run: (e) => {
			let t = e.targets[0];
			t?.k === "zone" && t.zone !== e.zone() && ge(e.s, t.zone) === "jungle" && e.place(e.caster, t.zone) && e.buff(e.caster, { str: 2 }, "turnEnd", "h14up");
		}
	}],
	h18: [{
		key: "h18.dig",
		targets: [{
			what: "friendlyHero",
			range: "adjacent"
		}, {
			what: "zone",
			range: "adjacent"
		}],
		condition: (e, t) => !e.heroes[t].leveled,
		run: (e) => {
			let [t, n] = e.targets;
			t?.k === "hero" && n?.k === "zone" && e.place(t.id, n.zone);
		}
	}, {
		key: "h18.digUp",
		targets: [{
			what: "friendlyHero",
			range: "adjacent"
		}, {
			what: "zone",
			range: "adjacent"
		}],
		perTurn: 2,
		condition: (e, t) => e.heroes[t].leveled,
		run: (e) => {
			let [t, n] = e.targets;
			t?.k === "hero" && n?.k === "zone" && e.place(t.id, n.zone);
		}
	}],
	h22: [{
		key: "h22.hook",
		targets: [{
			what: "enemyHero",
			range: 2
		}],
		condition: (e, t) => !e.heroes[t].leveled,
		run: (e) => Dt(e)
	}, {
		key: "h22.hookUp",
		targets: [{
			what: "enemyHero",
			range: 3
		}],
		perTurn: 2,
		condition: (e, t) => e.heroes[t].leveled,
		run: (e) => Dt(e)
	}],
	h29: [{
		key: "h29.rechannel",
		targets: [],
		condition: (e, t) => {
			if (!e.heroes[t].leveled) return !1;
			let n = e.heroes[t].owner;
			return e.discards[n].some((t) => {
				let n = e.cardInsts[t].card;
				return n.startsWith("D2") || n === "D24" || n === "D25" || n === "D26" || n === "D27" || n === "D28" || n === "D29";
			});
		},
		run: (e) => {
			let t = e.hero.owner, n = e.s.discards[t].findIndex((t) => {
				let n = e.s.cardInsts[t].card;
				return [
					"D24",
					"D25",
					"D26",
					"D27",
					"D28",
					"D29"
				].includes(n);
			});
			if (n < 0) return;
			let [r] = e.s.discards[t].splice(n, 1);
			e.s.channeled[r] = 0;
		}
	}]
};
function Dt(e) {
	let t = e.targets[0];
	if (t?.k !== "hero") return;
	let n = e.s, r = n.heroes[t.id], i = e.zone();
	if (!i || !r.zone) return;
	let a = null, o = Infinity;
	for (let e of T[r.zone].adj) {
		let t = D(e, i, n.towers, r.team);
		t < o && (o = t, a = e);
	}
	a && V(n, t.id, a), e.status(t.id, "stun");
}
R.h01 = (e, t, n) => {
	if (n.k !== "castDeclared") return;
	let r = e.heroes[t], i = e.heroes[n.hero];
	if (!r.zone || !i || i.out || i.team === r.team || !M(e, r.zone, r.team).includes(ue(e, n.hero) ?? "")) return;
	let a = r.leveled ? 4 : 2;
	B(e, {
		k: "hero",
		id: t
	}, {
		k: "hero",
		id: n.hero
	}, a, { via: "ability" }), i.statuses.includes("burn") || i.statuses.push("burn");
}, R.h03 = (e, t, n) => {
	if (n.k !== "enter" || n.hero !== t || e.turn?.hero !== t) return;
	let r = e.heroes[t];
	if (!r.zone) return;
	let i = r.leveled ? 2 : 1, a = A(e, r.zone).filter((t) => t.k === "hero" && j(e, t) === O(r.team));
	for (let t of a.slice(0, i)) {
		if (t.k !== "hero") continue;
		let n = mt(e, t.id);
		n && V(e, t.id, n);
	}
}, R.h04 = (e, t, n) => {
	if (n.k !== "dmg" || n.source?.k !== "hero" || n.source.id !== t) return;
	let r = e.heroes[t];
	r.hp = Math.min(9, r.hp + (r.leveled ? 2 : 1));
}, R.h07 = (e, t, n) => {
	if (n.k !== "leave") return;
	let r = e.heroes[t];
	if (!r.zone || n.zone !== r.zone) return;
	let i = e.heroes[n.hero];
	i && i.team !== r.team && !i.out && (B(e, {
		k: "hero",
		id: t
	}, {
		k: "hero",
		id: n.hero
	}, 2, { via: "ability" }), i.statuses.includes("burn") || i.statuses.push("burn"));
}, R.h08 = (e, t, n) => {
	if (n.k !== "defeat" || n.unit.k !== "minion") return;
	let r = e.heroes[t];
	if (n.unit.team === r.team || n.killer?.k !== "hero" || n.killer.id !== t || !Oe(e, `h08:${t}`) || r.hp <= 1) return;
	--r.hp;
	let i = (r.zone ? M(e, r.zone, r.team) : []).find((t) => (e.minions[t]?.[0] ?? 0) > 0 || (e.minions[t]?.[1] ?? 0) > 0);
	if (!i) return;
	let a = e.minions[i] ?? [0, 0];
	a[r.team] += r.leveled ? 2 : 1, e.minions[i] = a;
}, R.h24 = (e, t, n) => {
	if (n.k !== "enter") return;
	let r = e.heroes[t];
	if (!r.zone || n.hero === t || !M(e, r.zone, r.team).includes(n.zone)) return;
	let i = e.heroes[n.hero];
	i && !i.out && (i.team === r.team ? r.leveled && (i.hp = Math.min(9, i.hp + 1)) : (i.statuses.includes("silence") || i.statuses.push("silence"), i.statuses.includes("freeze") || i.statuses.push("freeze")));
}, R.h25 = (e, t, n) => {
	if (n.k !== "enter" || n.hero === t) return;
	let r = e.heroes[t];
	if (!r.leveled || !r.zone || n.zone !== r.zone) return;
	let i = mt(e, n.hero);
	i && V(e, n.hero, i);
};
function Ot(e, t, n) {
	for (let [r, i] of Object.entries(e.heroes)) if (i.def === "h20" && !i.out && i.team === n && P(e, r) && i.zone && M(e, i.zone, i.team).includes(t) && Oe(e, `h20:${r}`)) {
		if (!i.leveled) {
			if (i.hp <= 1) continue;
			--i.hp;
		}
		return !0;
	}
	return !1;
}
ke.fn = Ot;
//#endregion
//#region src/games/onward/rules/actions.ts
var H = (e) => ({ code: e });
function kt(e, t, n) {
	if (e.phase.k === "over") return H("games.onward.errOver");
	let r;
	switch (n.type) {
		case "plan":
			r = jt(e, t, n.hero, n.card);
			break;
		case "choosePlan":
			r = Mt(e, t, n.use);
			break;
		case "move":
			r = Pt(e, t, n.zone);
			break;
		case "attack":
			r = Ft(e, t, n.targets, n.riderZone);
			break;
		case "cast":
			r = zt(e, t, n.card, n.targets);
			break;
		case "channel":
			r = Ht(e, t, n.card);
			break;
		case "heroAction":
			r = Ut(e, t, n.key, n.targets);
			break;
		case "pass":
			r = Wt(e, t);
			break;
		case "react":
			r = Gt(e, t, n.card, n.targets);
			break;
		case "passReact":
			r = Kt(e, t);
			break;
		case "buy":
			r = en(e, t, n.item, n.hero);
			break;
		case "discardItem":
			r = tn(e, t, n.item);
			break;
		case "shopDone":
			r = nn(e, t);
			break;
		case "choose":
			r = rn(e, t, n);
			break;
		case "minionAct":
			r = an(e, t, n);
			break;
		case "discard":
			r = sn(e, t, n.cards);
			break;
		case "tick": r = null;
	}
	return r || (At(e), null);
}
function At(e) {
	if (e.pending || e.phase.k === "over") return;
	let t = e.deferred.shift();
	t && (e.pending = t);
}
function jt(e, t, n, r) {
	if (e.phase.k !== "plan") return H("games.onward.errPhase");
	let i = k(e, t);
	if (e.phase.queue[0] !== i) return H("games.onward.errNotYourPhase");
	let a = e.heroes[n];
	if (!a || a.team !== i || a.cond !== "ready") return H("games.onward.errHeroNotReady");
	if (!e.controls[t]?.includes(n)) return H("games.onward.errNotYours");
	for (let n = 0; n < 2; n += 1) {
		He(e, t);
		let n = e.decks[t].pop();
		n !== void 0 && e.hands[t].push(n);
	}
	let o = r;
	if (o === void 0 && (o = e.hands[t][e.hands[t].length - 1], o === void 0)) return H("games.onward.errNotInHand");
	let s = e.hands[t].indexOf(o);
	return s < 0 ? H("games.onward.errNotInHand") : (e.hands[t].splice(s, 1), a.planCard = o, e.planned.push({
		team: i,
		hero: n
	}), e.log.push({
		kind: "plan",
		hero: n,
		seat: t
	}), qe(e), null);
}
function Mt(e, t, n) {
	let r = e.turn;
	if (!r || e.phase.k !== "turn") return H("games.onward.errPhase");
	let i = e.heroes[r.hero];
	if (i.owner !== t) return H("games.onward.errNotYours");
	if (r.usedActions.includes("planChosen")) return H("games.onward.errPhase");
	let a, o;
	if (n === "normal") {
		if (i.planCard === null) return H("games.onward.errNoPlan");
		let n = x[e.cardInsts[i.planCard].card];
		a = n.mp, o = n.ap, e.discards[t].push(i.planCard), i.planCard = null;
	} else {
		let n = me(e, r.hero);
		a = n.mp, o = n.ap, i.planCard !== null && (e.hands[t].push(i.planCard), i.planCard = null);
	}
	for (let t of e.effects) N(e, t) && (t.key === "D15" && t.on === r.hero && (o *= 2), t.key === "C07" && t.on === r.hero && (o = Math.max(0, o - 1)), t.on === r.hero && typeof t.args?.grantMp == "number" && (a += t.args.grantMp), t.on === r.hero && typeof t.args?.grantAp == "number" && (o += t.args.grantAp));
	let s = wt(e, r.hero);
	return a += s.mp, o += s.ap, r.mp = a, r.ap = o, a > 0 && e.effects.some((t) => t.key === "C15" && t.on === r.hero && N(e, t)) && e.effects.push({
		id: e.nextEffectId++,
		key: "C15x",
		by: r.hero,
		on: r.hero,
		args: {
			str: a,
			armor: a
		},
		expires: "roundEnd",
		src: "spell"
	}), r.usedActions.push("planChosen"), i.out && i.cond === "ready" && (i.hp = 9, V(e, r.hero, i.team === 0 ? "NL" : "NS")), e.log.push({
		kind: "choosePlan",
		hero: r.hero,
		args: {
			mp: a,
			ap: o,
			fallback: +(n === "fallback")
		}
	}), null;
}
function Nt(e, t) {
	let n = e.turn;
	if (!n || e.phase.k !== "turn") return H("games.onward.errPhase");
	if (e.pending) return H("games.onward.errPending");
	let r = e.heroes[n.hero];
	return r.owner === t ? n.usedActions.includes("planChosen") ? r.out || !r.zone ? H("games.onward.errHeroOut") : null : H("games.onward.errNoPlan") : H("games.onward.errNotYours");
}
function Pt(e, t, n) {
	let r = Nt(e, t);
	if (r) return r;
	let i = e.turn, a = e.heroes[i.hero], o = a.statuses.includes("freeze") ? 2 : 1;
	if (i.mp < o) return H("games.onward.errNoMp");
	if (!fe(e, a.zone, a.team).includes(n)) return H("games.onward.errNotAdjacent");
	if (!Te(e, i.hero, n)) return H("games.onward.errCantEnter");
	Ee(e, n, a.team);
	for (let t of e.effects) {
		if (t.key !== "D20" || !N(e, t)) continue;
		let r = e.heroes[t.on ?? ""];
		if (r && !r.out && r.zone && r.team !== a.team && !(D(a.zone, r.zone, e.towers, a.team) > 3) && D(n, r.zone, e.towers, a.team) >= D(a.zone, r.zone, e.towers, a.team)) return H("games.onward.errMustApproach");
	}
	return i.mp -= o, i.spentMp += o, i.fresh = !1, e.log.push({
		kind: "move",
		hero: i.hero,
		args: { zone: n }
	}), qt(e, {
		by: t,
		action: {
			k: "move",
			zone: n
		}
	}), null;
}
function Ft(e, t, n, r) {
	let i = Nt(e, t);
	if (i) return i;
	let a = e.turn, o = e.heroes[a.hero];
	if (a.ap < 1) return H("games.onward.errNoAp");
	let s = Ce(e, a.hero), c = n[0];
	if (!c) return H("games.onward.errNoTarget");
	if (!It(e, a.hero, c, s.canHit)) return H("games.onward.errBadTarget");
	let l = Lt(e, a.hero, s.canHit), u = we(e, o.team, "attack", l);
	if (u && (c.k !== "hero" || c.id !== u)) return H("games.onward.errTaunt");
	for (let t of e.effects) {
		if (t.key !== "D20" || !N(e, t)) continue;
		let n = e.heroes[t.on ?? ""];
		if (!n || n.out || !n.zone || n.team === o.team) continue;
		let r = D(o.zone, n.zone, e.towers, o.team);
		if (r <= 3 && r > 1 && a.mp > 0) return H("games.onward.errD20block");
	}
	let d = n.slice(1), f = [...s.extraTargets];
	for (let t of d) {
		if (!It(e, a.hero, t, s.canHit)) return H("games.onward.errBadTarget");
		let n = f.findIndex((n) => n.n > 0 && Rt(e, a.hero, t, n.what));
		if (n < 0) return H("games.onward.errBadTarget");
		f[n] = {
			...f[n],
			n: f[n].n - 1
		};
	}
	return r && !s.riders.teleportWithin ? H("games.onward.errBadTarget") : (--a.ap, a.fresh = !1, a.usedActions.includes("attacked") || a.usedActions.push("attacked"), z(e, {
		k: "attackDeclared",
		hero: a.hero
	}), e.log.push({
		kind: "attack",
		hero: a.hero
	}), qt(e, {
		by: t,
		action: {
			k: "attack",
			targets: n,
			riderZone: r
		}
	}), null);
}
function It(e, t, n, r) {
	let i = e.heroes[t];
	if (i.out || !i.zone || je(e, n)) return !1;
	let a = j(e, n);
	if (a === i.team || n.k === "minion" && a !== null && a !== O(i.team)) return !1;
	let o = n.k === "tower" ? n.edge.split("|") : de(e, n) ? [de(e, n)] : [];
	if (!o.some((t) => r(e, i.zone, t, i.team))) return !1;
	for (let r of e.effects) if (r.on === t && N(e, r) && (r.args?.onlyHeroOutsider === 1 && n.k !== "hero" && n.k !== "outsider" || r.args?.onlyOutsider === 1 && n.k !== "outsider" || typeof r.args?.onlyTarget == "string" && r.args.onlyTarget !== "" && (n.k !== "hero" || n.id !== r.args.onlyTarget))) return !1;
	for (let r of o) {
		if (Ee(e, r, i.team, n.k === "hero" ? n.id : void 0)) return !1;
		if (T[r]?.kind === "jungle" && a !== i.team) {
			if (i.def === "h14" && P(e, t)) continue;
			if (!Object.values(e.heroes).some((e) => !e.out && e.zone === r && e.team === i.team)) return !1;
		}
	}
	return !0;
}
function Lt(e, t, n) {
	let r = [];
	for (let i of Object.keys(T)) for (let a of A(e, i)) (a.k !== "nexus" || a.team !== e.heroes[t].team) && It(e, t, a, n) && r.push(a);
	return r;
}
function Rt(e, t, n, r) {
	let i = e.heroes[t].team;
	switch (r) {
		case "nonMinion": return n.k !== "minion";
		case "hero": return n.k === "hero";
		case "minion": return n.k === "minion" && n.team === O(i);
		case "minionOrTower": return n.k === "minion" && n.team === O(i) || n.k === "tower" && j(e, n) === O(i);
		case "sameZoneAny": {
			let r = e.heroes[t].zone, i = de(e, n);
			return r !== null && i === r;
		}
		default: return !1;
	}
}
function zt(e, t, n, r) {
	if (e.pending) return H("games.onward.errPending");
	let i = e.channeled[n] !== void 0, a = e.hands[t]?.includes(n);
	if (!i && !a) return H("games.onward.errNotInHand");
	let o = x[e.cardInsts[n].card];
	if (!o) return H("games.onward.errNotInHand");
	if (!i && (o.id === "D24" || o.id === "D25" || o.id === "D26")) return H("games.onward.errNotChannelable");
	let s = yt[o.id];
	if (!s) return H("games.onward.errNoSpell");
	let c = s.timing ?? "turn";
	if (c === "shop") {
		if (e.phase.k !== "shop" || e.phase.queue[0] !== k(e, t)) return H("games.onward.errPhase");
	} else {
		let n = Nt(e, t);
		if (n) return n;
		if (c === "turnStart" && !e.turn.fresh) return H("games.onward.errNotFresh");
	}
	let l = gt(e, t, n);
	if (!l) return H("games.onward.errNoCaster");
	let { heroId: u } = l;
	if (e.effects.some((t) => t.on === u && t.args?.noCast === !0 && N(e, t))) return H("games.onward.errNoCast");
	if (s.condition && !s.condition(e, u)) return H("games.onward.errCondition");
	let d = Bt(e, u, s, r);
	if (d) return d;
	if (e.turn) {
		let t = r.filter((e) => e.k !== "zone").filter((t) => t.k === "hero" && j(e, t) === O(e.heroes[u].team));
		if (t.length > 0) {
			let n = s.targets, r = [];
			for (let t of n) for (let n of _t(e, u, t, [])) n.k !== "zone" && r.push(n);
			let i = we(e, e.heroes[u].team, "spell", r);
			if (i && !t.some((e) => e.k === "hero" && e.id === i)) return H("games.onward.errTaunt");
		}
	}
	if (s.payCost && !s.payCost(e, u, t, r, n)) return H("games.onward.errCost");
	e.turn && (e.turn.fresh = !1), z(e, {
		k: "castDeclared",
		hero: u,
		by: t
	}), e.log.push({
		kind: "cast",
		hero: u,
		seat: t,
		args: { card: o.id }
	});
	let f = {
		by: t,
		action: {
			k: "cast",
			cardInst: n,
			targets: r
		}
	};
	return e.phase.k === "shop" ? Jt(e, [f]) : qt(e, f), null;
}
function Bt(e, t, n, r) {
	let i = n.targets, a = i.filter((e) => !e.optional).length;
	if (r.length < a || r.length > i.length) return H("games.onward.errBadTarget");
	for (let n = 0; n < r.length; n += 1) if (!_t(e, t, i[n], r.slice(0, n)).some((e) => Vt(e, r[n])) || !i[n].allowRepeat && r.slice(0, n).some((e) => Vt(e, r[n]))) return H("games.onward.errBadTarget");
	return null;
}
function Vt(e, t) {
	if (e.k !== t.k) return !1;
	switch (e.k) {
		case "hero": return e.id === t.id;
		case "minion": {
			let n = t;
			return e.zone === n.zone && e.team === n.team;
		}
		case "tower": return e.edge === t.edge;
		case "monster": return e.zone === t.zone;
		case "nexus": return e.team === t.team;
		case "outsider": return !0;
		case "zone": return e.zone === t.zone;
	}
}
function Ht(e, t, n) {
	if (e.phase.k !== "shop" || e.phase.queue[0] !== k(e, t)) return H("games.onward.errPhase");
	let r = e.hands[t].indexOf(n);
	return r < 0 ? H("games.onward.errNotInHand") : x[e.cardInsts[n].card].hero === "h29" ? (e.hands[t].splice(r, 1), e.channeled[n] = 0, e.log.push({
		kind: "channel",
		seat: t,
		args: { card: x[e.cardInsts[n].card].id }
	}), null) : H("games.onward.errNotChannelable");
}
function Ut(e, t, n, r) {
	let i = Nt(e, t);
	if (i) return i;
	let a = e.turn, o = e.heroes[a.hero], s = P(e, a.hero) ? Et[o.def]?.find((e) => e.key === n) : void 0;
	if (!s && o.def === "h19" && o.leveled && P(e, a.hero)) for (let [t, r] of Object.entries(e.heroes)) {
		if (r.team !== o.team || t === a.hero || r.out) continue;
		let e = Et[r.def]?.find((e) => e.key === n);
		if (e) {
			s = e;
			break;
		}
	}
	if (!s) for (let t of e.equipped[a.hero] ?? []) {
		let r = xt[e.itemInsts[t].item]?.find((e) => e.key === n);
		if (r) {
			s = r;
			break;
		}
	}
	if (!s) return H("games.onward.errNoAction");
	let c = s.perTurn ?? 1;
	return a.usedActions.filter((e) => e === n).length >= c ? H("games.onward.errUsedAction") : a.ap < 1 ? H("games.onward.errNoAp") : s.condition && !s.condition(e, a.hero) ? H("games.onward.errCondition") : Bt(e, a.hero, s, r) || (--a.ap, a.fresh = !1, a.usedActions.push(n), e.log.push({
		kind: "heroAction",
		hero: a.hero,
		args: { key: n }
	}), qt(e, {
		by: t,
		action: {
			k: "heroAction",
			actionKey: n,
			targets: r
		}
	}), null);
}
function Wt(e, t) {
	if (e.phase.k === "plan") {
		let n = k(e, t);
		return e.phase.queue[0] === n ? e.players.some((t) => e.teams[t] === n && e.hands[t].length + e.decks[t].length + e.discards[t].length > 0 && (e.controls[t] ?? []).some((t) => e.heroes[t]?.cond === "ready")) ? H("games.onward.errPhase") : (qe(e), null) : H("games.onward.errNotYourPhase");
	}
	if (e.phase.k !== "turn" || !e.turn) return H("games.onward.errPhase");
	if (e.pending) return H("games.onward.errPending");
	let n = e.turn;
	return e.heroes[n.hero].owner === t ? n.usedActions.includes("planChosen") ? (Qt(e), null) : H("games.onward.errNoPlan") : H("games.onward.errNotYours");
}
function Gt(e, t, n, r) {
	let i = e.pending;
	if (!i || i.k !== "react") return H("games.onward.errPhase");
	let a = k(e, t);
	if (i.awaiting !== a) return H("games.onward.errNotYourPhase");
	if (!e.hands[t].includes(n)) return H("games.onward.errNotInHand");
	let o = x[e.cardInsts[n].card];
	if (!o.flags.includes("r")) return H("games.onward.errNotReactive");
	let s = yt[o.id];
	if (!s) return H("games.onward.errNoSpell");
	let c = gt(e, t, n);
	return c ? s.condition && !s.condition(e, c.heroId) ? H("games.onward.errCondition") : Bt(e, c.heroId, s, r) || (s.payCost && !s.payCost(e, c.heroId, t, r, n) ? H("games.onward.errCost") : (z(e, {
		k: "castDeclared",
		hero: c.heroId,
		by: t
	}), e.log.push({
		kind: "cast",
		hero: c.heroId,
		seat: t,
		args: {
			card: o.id,
			react: 1
		}
	}), i.chain.push({
		by: t,
		action: {
			k: "cast",
			cardInst: n,
			targets: r
		}
	}), i.awaiting = O(a), i.passed = [], null)) : H("games.onward.errNoCaster");
}
function Kt(e, t) {
	let n = e.pending;
	if (!n || n.k !== "react") return H("games.onward.errPhase");
	let r = k(e, t);
	if (n.awaiting !== r) return H("games.onward.errNotYourPhase");
	n.passed.includes(t) || n.passed.push(t);
	let i = (t) => e.players.filter((n) => e.teams[n] === t).every((e) => n.passed.includes(e));
	if (i(0) && i(1)) {
		let t = n.chain;
		return e.pending = null, Jt(e, t), null;
	}
	return i(r) && (n.awaiting = O(r)), null;
}
function qt(e, t) {
	let n = e.turn, r = O(n ? e.heroes[n.hero].team : k(e, t.by));
	e.players.some((t) => e.teams[t] === r && pe(e, t).length > 0) ? e.pending = {
		k: "react",
		chain: [t],
		awaiting: r,
		passed: []
	} : Jt(e, [t]);
}
function Jt(e, t) {
	let n = [...t];
	for (; n.length > 0;) {
		if (Yt(e, n.pop()), e.phase.k === "over") {
			e.resolving = [], e.retaliateQueue = [], Xt(e);
			return;
		}
		if (e.pending) {
			e.resolving = n;
			return;
		}
	}
	e.resolving = [], Xt(e), !(e.pending || e.phase.k === "over") && Zt(e);
}
function Yt(e, t) {
	let n = e.turn?.hero;
	switch (t.action.k) {
		case "move":
			n && V(e, n, t.action.zone);
			break;
		case "attack": {
			if (!n || e.heroes[n].out) break;
			pt(e, n, t.action.targets, "attack", t.action.riderZone);
			let r = e.heroes[n];
			!r.out && r.statuses.includes("burn") && B(e, null, {
				k: "hero",
				id: n
			}, 1, {
				piercing: !0,
				via: "effect"
			});
			break;
		}
		case "cast":
			ht(e, t.by, t.action.cardInst, t.action.targets);
			break;
		case "heroAction": {
			if (!n || e.heroes[n].out) break;
			let r = e.heroes[n], i = t.action, a = Et[r.def]?.find((e) => e.key === i.actionKey);
			if (!a && r.def === "h19" && r.leveled) for (let [t, o] of Object.entries(e.heroes)) {
				if (o.team !== r.team || t === n || o.out) continue;
				let e = Et[o.def]?.find((e) => e.key === i.actionKey);
				if (e) {
					a = e;
					break;
				}
			}
			if (a ??= (e.equipped[n] ?? []).flatMap((t) => xt[e.itemInsts[t].item] ?? []).find((e) => e.key === i.actionKey), a) {
				let t = new dt(e, n, i.targets, -1);
				a.run(t);
			}
			break;
		}
	}
}
function Xt(e) {
	let t = e.retaliateQueue;
	e.retaliateQueue = [];
	for (let n of t) {
		if (e.phase.k === "over") return;
		if (n.attacker.k === "minion") {
			let t = e.minions[n.attacker.zone];
			t && t[n.attacker.team] > 0 && (--t[n.attacker.team], z(e, {
				k: "defeat",
				unit: n.attacker,
				killer: n.defender
			}));
			continue;
		}
		if (!je(e, n.attacker)) {
			if (n.defender.k === "outsider") {
				if (e.outsider.tamed || e.outsider.zone === null) continue;
				B(e, { k: "outsider" }, n.attacker, 2, {
					piercing: !0,
					via: "effect",
					isRetaliate: !0
				});
				continue;
			}
			if (n.defender.k === "tower" || n.defender.k === "nexus") {
				if (n.defenderTeam === null) continue;
				let t = Ve(e, We(e, n.defenderTeam));
				t.strength > 0 && B(e, n.defender, n.attacker, t.strength, {
					via: "attack",
					isRetaliate: !0
				});
				continue;
			}
			if (n.defender.k === "hero") {
				let t = n.defender.id;
				if (e.heroes[t].out) continue;
				let r = e.effects.find((n) => n.on === t && n.args?.retaliateStatus !== void 0 && N(e, n));
				if (r && n.attacker.k === "hero" && !e.heroes[n.attacker.id].out) {
					let t = String(r.args?.retaliateStatus), i = e.heroes[n.attacker.id];
					i.statuses.includes(t) || i.statuses.push(t);
					continue;
				}
				let i = 0;
				for (let n of e.effects) {
					if (n.on !== t || !N(e, n)) continue;
					let r = n.args?.retaliate;
					typeof r == "number" ? i += r : r === "armor" && (i += 0), typeof n.args?.retaliateNum == "number" && (i += n.args.retaliateNum);
				}
				n.attacker.k === "hero" && (e.equipped[t] ?? []).some((t) => e.itemInsts[t].item === "i14") && (i += 2), i > 0 && B(e, n.defender, n.attacker, i, {
					via: "effect",
					isRetaliate: !0
				});
			}
		}
	}
}
function Zt(e) {
	let t = e.turn;
	t && e.heroes[t.hero].out && Qt(e);
}
function Qt(e) {
	let t = e.turn;
	if (!t) return;
	let n = e.heroes[t.hero], r = t.fast, i = e.effects.find((t) => t.key === "B39" && N(e, t));
	if (i && n.zone) {
		let r = Object.entries(e.heroes).find(([, e]) => !e.out && e.team !== n.team && e.zone === n.zone);
		r && t.spentMp > 0 && B(e, {
			k: "hero",
			id: t.hero
		}, {
			k: "hero",
			id: r[0]
		}, t.spentMp, {
			ignoreTough: !0,
			via: "spell"
		}), Re(e, i.id);
	}
	z(e, {
		k: "turnEnd",
		hero: t.hero
	}), n.cond === "ready" && (n.cond = "exhausted"), n.statuses = [];
	for (let t of [...e.effects]) t.expires === "turnEnd" && Re(e, t.id);
	Xt(e);
	let a = n.owner;
	if (e.turn = null, e.phase.k === "over") return;
	let o = e.hands[a].length - 7;
	if (o > 0) {
		e.pending = {
			k: "choose",
			seat: a,
			chooseKind: "handLimit",
			args: {
				count: o,
				fast: +!!r
			}
		};
		return;
	}
	$t(e, r);
}
function $t(e, t) {
	let n = e.effects.find((t) => t.key === "C09" && N(e, t));
	if (n) {
		let r = e.heroes[n.on ?? ""], i = r && !r.out && r.zone ? ct(r.zone) : null;
		if (Re(e, n.id), i !== null) {
			e.pendingAfter = { fast: t }, e.phase = {
				k: "minions",
				order: [],
				idx: -1,
				roundEnd: [i]
			}, et(e);
			return;
		}
	}
	Qe(e, t);
}
function en(e, t, n, r) {
	if (e.phase.k !== "shop") return H("games.onward.errPhase");
	let i = k(e, t);
	if (e.phase.queue[0] !== i) return H("games.onward.errNotYourPhase");
	let a = e.heroes[r];
	if (!a || a.team !== i) return H("games.onward.errNotYours");
	let o = e.market.findIndex((e) => e[e.length - 1] === n);
	if (o < 0) return H("games.onward.errNotOnTop");
	let s = S[e.itemInsts[n].item], c = e.effects.findIndex((e) => e.key === "A31" && e.team === i), l = c >= 0 && s.cost <= 12;
	return l && a.def !== "h05" ? H("games.onward.errBadTarget") : (c >= 0 && e.effects.splice(c, 1), !l && e.onceMarks[`buy:${i}:${s.color}`] === e.round ? H("games.onward.errColorBought") : !l && e.gold[i] < s.cost ? H("games.onward.errNoGold") : (e.market[o].pop(), l || (e.gold[i] -= s.cost), e.onceMarks[`buy:${i}:${s.color}`] = e.round, (e.equipped[r] ??= []).push(n), e.log.push({
		kind: "buy",
		hero: r,
		args: {
			item: s.id,
			free: +!!l
		}
	}), St(e, r, s.id), null));
}
function tn(e, t, n) {
	let r = Object.keys(e.equipped).find((t) => e.equipped[t].includes(n));
	if (!r) return H("games.onward.errNoItem");
	let i = e.heroes[r];
	if (e.phase.k === "shop") {
		if (e.phase.queue[0] !== k(e, t) || i.team !== k(e, t)) return H("games.onward.errNotYourPhase");
	} else if (e.phase.k === "turn" && e.turn) {
		if (e.turn.hero !== r) return H("games.onward.errNotYours");
	} else return H("games.onward.errPhase");
	e.equipped[r] = e.equipped[r].filter((e) => e !== n);
	let a = e.itemInsts[n].item;
	return e.market[bt(a)].unshift(n), e.log.push({
		kind: "discardItem",
		hero: r,
		args: { item: a }
	}), Ct(e, r, a), null;
}
function nn(e, t) {
	return e.phase.k === "shop" ? e.phase.queue[0] === k(e, t) ? (qe(e), null) : H("games.onward.errNotYourPhase") : H("games.onward.errPhase");
}
function rn(e, t, n) {
	let r = e.pending;
	if (!r || r.k !== "choose" || r.seat !== t) return H("games.onward.errPhase");
	switch (r.chooseKind) {
		case "levelUp": {
			if (!n.hero) return H("games.onward.errNeedHero");
			let t = e.heroes[n.hero];
			if (!t || t.team !== r.args?.team || t.leveled) return H("games.onward.errBadTarget");
			e.pending = null, ze(e, n.hero), e.log.push({
				kind: "levelUp",
				hero: n.hero
			});
			break;
		}
		case "outsiderToken": {
			if (n.lane === void 0) return H("games.onward.errNeedLane");
			let t = r.args?.team;
			e.pending = null, e.outsider.laneTokens.push(n.lane), e.effects.push({
				id: e.nextEffectId++,
				key: "outsiderMark",
				by: "$neutral",
				team: t,
				args: { lane: n.lane },
				expires: "never",
				src: "neutral"
			}), e.log.push({
				kind: "outsiderToken",
				args: {
					lane: n.lane,
					team: t
				}
			});
			break;
		}
		case "laneOrder":
			if (n.lane === void 0) return H("games.onward.errNeedLane");
			if (!String(r.args?.lanes ?? "").split(",").map(Number).includes(n.lane)) return H("games.onward.errBadTarget");
			e.pending = null, e.phase.k === "minions" && (e.phase.order.push(n.lane), tt(e, n.lane));
			break;
		case "spellChoice": {
			let t = yt[String(r.args?.card ?? "")];
			if (!t?.onChoose) return H("games.onward.errPhase");
			let i = String(r.args?.caster ?? "");
			e.pending = null;
			let a = t.onChoose(e, i, n, r.args ?? {});
			if (a) return a;
			break;
		}
		case "handLimit": return H("games.onward.errUseDiscard");
		default: return H("games.onward.errPhase");
	}
	if (!e.pending && e.resolving.length > 0) {
		let t = e.resolving;
		e.resolving = [], Jt(e, t);
	}
	return null;
}
function an(e, t, n) {
	let r = e.pending;
	if (!r || r.k !== "minionPush") return H("games.onward.errPhase");
	if (k(e, t) !== r.team) return H("games.onward.errNotYourPhase");
	let i = E[r.lane], a = i.find((t) => (e.minions[t]?.[0] ?? 0) > 0 || (e.minions[t]?.[1] ?? 0) > 0);
	if (!a) return on(e, r.lane, null), null;
	if ((e.minions[a]?.[r.team] ?? 0) <= 0) return on(e, r.lane, a), null;
	let o = O(r.team), s = {
		k: "minion",
		zone: a,
		team: r.team
	}, c = A(e, a).filter((t) => t.k === "hero" && j(e, t) === o || t.k === "minion" && t.team === o || t.k === "tower" && e.towers[t.edge] === o), l = c.find((t) => t.k === "hero" && e.heroes[t.id].def === "h02" && P(e, t.id)), u = r.team === 0 ? "NS" : "NL", d = T[a].adj.includes(u);
	if (n.act === "assault") {
		if (c.length === 0) return H("games.onward.errMustPriority");
		let t = n.target;
		if (!t || !c.some((e) => Vt(e, t))) return H("games.onward.errBadTarget");
		if (l && !Vt(t, l)) return H("games.onward.errTaunt");
		let i = Math.min(r.momentum, Ae(e, t));
		if (i <= 0) return H("games.onward.errBadTarget");
		B(e, s, t, i, { via: "attack" }), r.momentum -= i;
	} else if (n.act === "siege") {
		if (c.length > 0) return H("games.onward.errMustPriority");
		if (!d) return H("games.onward.errBadTarget");
		let t = r.momentum;
		B(e, s, {
			k: "nexus",
			team: o
		}, t, {
			via: "attack",
			ignoreTough: !0
		}), r.momentum = 0;
	} else {
		if (c.length > 0 || d) return H("games.onward.errMustPriority");
		if (r.momentum < 1) return H("games.onward.errBadTarget");
		let t = i.indexOf(a), n = r.team === 0 ? i[t + 1] : i[t - 1];
		if (n && T[n].kind === "lane") {
			let t = e.minions[a], i = e.minions[n] ?? [0, 0];
			i[r.team] += t[r.team], t[r.team] = 0, e.minions[n] = i, e.log.push({
				kind: "minionAdvance",
				args: {
					lane: r.lane,
					from: a,
					to: n,
					team: r.team
				}
			});
		}
		--r.momentum;
	}
	return Xt(e), e.phase.k === "over" || ((e.minions[a]?.[r.team] ?? 0) <= 0 || r.momentum <= 0) && on(e, r.lane, a), null;
}
function on(e, t, n) {
	e.pending = null, rt(e, t, n), it(e, t);
}
function sn(e, t, n) {
	let r = e.pending;
	if (!r || r.k !== "choose" || r.chooseKind !== "handLimit" || r.seat !== t) return H("games.onward.errPhase");
	let i = Number(r.args?.count ?? 0);
	if (n.length !== i) return H("games.onward.errDiscardCount");
	for (let r of n) if (!e.hands[t].includes(r)) return H("games.onward.errNotInHand");
	for (let r of n) e.hands[t].splice(e.hands[t].indexOf(r), 1), e.discards[t].push(r);
	return e.pending = null, $t(e, Number(r.args?.fast) === 1), null;
}
//#endregion
//#region src/games/onward/rules/hint.ts
function cn(e, t) {
	let n = { what: "none" };
	if (e.phase.k === "over") return n;
	let r = k(e, t), i = e.pending;
	if (i) {
		if (i.k === "react") return i.awaiting !== r || i.passed.includes(t) ? n : {
			what: "react",
			reactable: pe(e, t).flatMap((n) => {
				let r = x[e.cardInsts[n].card].id, i = yt[r];
				if (!i) return [];
				let a = gt(e, t, n);
				if (!a || i.condition && !i.condition(e, a.heroId) || !dn(e, r, a.heroId)) return [];
				let o = pn(e, a.heroId, i.targets);
				return un(e, i, a.heroId, t, n, o) ? [{
					inst: n,
					targetsSpec: ln(r),
					options: o
				}] : [];
			}),
			canPass: !0
		};
		if (i.k === "choose") {
			if (i.seat !== t) return n;
			if (i.chooseKind === "handLimit") return {
				what: "discard",
				mustDiscard: Number(i.args?.count ?? 0)
			};
			if (i.chooseKind === "laneOrder") return {
				what: "choose",
				chooseLanes: String(i.args?.lanes ?? "").split(",").filter(Boolean).map(Number)
			};
			if (i.chooseKind === "levelUp") {
				let t = i.args?.team;
				return {
					what: "choose",
					chooseHeroes: Object.keys(e.heroes).filter((n) => e.heroes[n].team === t && !e.heroes[n].leveled)
				};
			}
			if (i.chooseKind === "outsiderToken") return {
				what: "choose",
				chooseLanes: [
					0,
					1,
					2
				]
			};
			if (i.chooseKind === "spellChoice") {
				let n = String(i.args?.card ?? "");
				return n === "C19" ? {
					what: "choose",
					args: { mode: "discardPick" },
					chooseCards: e.discards[t].filter((t) => !x[e.cardInsts[t].card].flags.includes("u")).map((t) => ({
						inst: t,
						card: e.cardInsts[t].card
					}))
				} : n === "D27" ? {
					what: "choose",
					args: { mode: "channelDouble" },
					chooseCards: Object.keys(e.channeled).map(Number).map((t) => ({
						inst: t,
						card: e.cardInsts[t].card
					}))
				} : {
					what: "choose",
					args: {
						mode: "option",
						card: n,
						...n === "C45" ? { validOptions: fn(e, String(i.args?.caster ?? "")) } : {}
					}
				};
			}
			return { what: "choose" };
		}
		if (i.k === "minionPush") {
			if (i.team !== r) return n;
			let t = E[i.lane].find((t) => (e.minions[t]?.[0] ?? 0) > 0 || (e.minions[t]?.[1] ?? 0) > 0);
			if (!t) return n;
			let a = O(i.team), o = A(e, t).filter((t) => t.k === "hero" && j(e, t) === a || t.k === "minion" && t.team === a || t.k === "tower" && e.towers[t.edge] === a), s = o.find((t) => t.k === "hero" && e.heroes[t.id].def === "h02" && P(e, t.id)), c = i.team === 0 ? "NS" : "NL", l = o.length === 0 && T[t].adj.includes(c), u = o.length === 0 && !l && i.momentum >= 1;
			return {
				what: "minionAct",
				minionActs: {
					assaultTargets: s ? [s] : o,
					canSiege: l,
					canAdvance: u,
					momentum: i.momentum
				}
			};
		}
		return n;
	}
	if (e.phase.k === "shop") {
		if (e.phase.queue[0] !== r) return n;
		let i = e.effects.some((e) => e.key === "A31" && e.team === r), a = [];
		return e.market.forEach((t, n) => {
			let o = t[t.length - 1];
			if (o === void 0) return;
			let s = S[e.itemInsts[o].item], c = e.onceMarks[`buy:${r}:${s.color}`] === e.round;
			(i ? s.cost <= 12 : !c && e.gold[r] >= s.cost) && a.push(o);
		}), {
			what: "shop",
			canBuy: a,
			channelable: (e.controls[t] ?? []).some((t) => e.heroes[t].def === "h29" && !e.heroes[t].out) ? e.hands[t].filter((t) => x[e.cardInsts[t].card].hero === "h29") : [],
			castable: e.hands[t].flatMap((n) => {
				let r = x[e.cardInsts[n].card].id, i = yt[r];
				if (i?.timing !== "shop") return [];
				let a = gt(e, t, n);
				if (!a || i.condition && !i.condition(e, a.heroId) || !dn(e, r, a.heroId)) return [];
				let o = pn(e, a.heroId, i.targets);
				return un(e, i, a.heroId, t, n, o) ? [{
					inst: n,
					targetsSpec: ln(r),
					options: o
				}] : [];
			}),
			canPass: !0
		};
	}
	if (e.phase.k === "plan") {
		if (e.phase.queue[0] !== r) return n;
		let i = (t) => e.hands[t].length + e.decks[t].length + e.discards[t].length > 0;
		return {
			what: "plan",
			planHeroes: (e.controls[t] ?? []).filter((n) => e.heroes[n].cond === "ready" && i(t)),
			canPass: !e.players.some((t) => e.teams[t] === r && i(t) && (e.controls[t] ?? []).some((t) => e.heroes[t]?.cond === "ready"))
		};
	}
	if (e.phase.k === "turn" && e.turn) {
		let r = e.turn, i = e.heroes[r.hero];
		if (i.owner !== t) return n;
		if (!r.usedActions.includes("planChosen")) {
			let t = me(e, r.hero);
			return {
				what: "choosePlan",
				args: {
					fallbackMp: t.mp,
					fallbackAp: t.ap
				}
			};
		}
		if (i.out || !i.zone) return {
			what: "turn",
			canPass: !0
		};
		let a = i.statuses.includes("freeze") ? 2 : 1, o = r.mp >= a ? fe(e, i.zone, i.team).filter((t) => Te(e, r.hero, t)) : [], s = [];
		if (r.ap >= 1) {
			let t = Ce(e, r.hero);
			s = Lt(e, r.hero, t.canHit);
			let n = we(e, i.team, "attack", s);
			n && (s = s.filter((e) => e.k === "hero" && e.id === n));
		}
		let c = e.effects.some((t) => t.on === r.hero && t.args?.noCast === !0 && N(e, t)), l = [];
		if (!c) {
			for (let n of e.hands[t]) {
				let i = x[e.cardInsts[n].card];
				if (i.id === "D24" || i.id === "D25" || i.id === "D26") continue;
				let a = yt[i.id];
				if (!a || (a.timing ?? "turn") === "shop" || a.timing === "turnStart" && !r.fresh) continue;
				let o = gt(e, t, n);
				if (!o || a.condition && !a.condition(e, o.heroId) || !dn(e, i.id, o.heroId)) continue;
				let s = pn(e, o.heroId, a.targets);
				un(e, a, o.heroId, t, n, s) && l.push({
					inst: n,
					targetsSpec: ln(i.id),
					options: s
				});
			}
			for (let [n] of Object.entries(e.channeled)) {
				let i = Number(n), a = x[e.cardInsts[i].card], o = yt[a.id];
				if (!o || o.condition && !o.condition(e, r.hero) || !dn(e, a.id, r.hero)) continue;
				let s = pn(e, r.hero, o.targets);
				un(e, o, r.hero, t, i, s) && l.push({
					inst: i,
					targetsSpec: ln(a.id),
					options: s
				});
			}
		}
		let u = [];
		if (r.ap >= 1) {
			let t = (t) => {
				for (let n of t ?? []) r.usedActions.filter((e) => e === n.key).length >= (n.perTurn ?? 1) || (!n.condition || n.condition(e, r.hero)) && u.push({
					key: n.key,
					label: n.key,
					targetsSpec: n.targets.map((e) => ({
						what: e.what,
						range: e.range,
						...e.optional ? { optional: !0 } : {}
					})),
					options: pn(e, r.hero, n.targets)
				});
			};
			P(e, r.hero) && t(Et[i.def]);
			for (let n of e.equipped[r.hero] ?? []) t(xt[e.itemInsts[n].item]);
		}
		return {
			what: "turn",
			moveZones: o,
			attackTargets: s,
			castable: l,
			heroActions: u,
			canPass: !0
		};
	}
	return n;
}
function ln(e) {
	return (yt[e]?.targets ?? []).map((e) => ({
		what: e.what,
		range: e.range,
		...e.optional ? { optional: !0 } : {}
	}));
}
function un(e, t, n, r, i, a) {
	if (!t.payCost) return !0;
	let o = structuredClone(e), s = a.map((e) => e[0]).filter((e) => !!e);
	try {
		return t.payCost(o, n, r, s, i);
	} catch {
		return !1;
	}
}
function dn(e, t, n) {
	return t !== "C45" || fn(e, n).length > 0;
}
function fn(e, t) {
	let n = e.heroes[t]?.team;
	if (n === void 0) return [];
	let r = [];
	return Object.values(e.heroes).some((e) => e.team === n && e.cond === "respawning") && r.push(0), Object.keys(e.heroes).some((t) => e.heroes[t].team === n && e.heroes[t].cond === "exhausted" && e.defeatedToday.includes(t)) && r.push(1), e.outsider.laneTokens.length > 0 && r.push(2), r;
}
function pn(e, t, n) {
	let r = [];
	return n.forEach((n) => {
		if (n.from === "target0" && r[0]) {
			let i = /* @__PURE__ */ new Map();
			for (let a of r[0]) for (let r of _t(e, t, n, [a])) i.set(JSON.stringify(r), r);
			r.push([...i.values()]);
		} else r.push(_t(e, t, n, []));
	}), r;
}
//#endregion
//#region src/games/onward/rules/spells-book.ts
var U = (e, t) => {
	yt[e] = t;
}, mn = (e) => ({ code: e }), hn = {
	what: "zone",
	range: "adjacent"
}, W = (e, t = !1, n = {}) => ({
	what: "enemyUnit",
	range: e,
	optional: t,
	...n
}), G = (e, t = !1, n = {}) => ({
	what: "enemyHero",
	range: e,
	optional: t,
	...n
});
function K(e, t = 0) {
	let n = e.targets[t];
	return n?.k === "zone" && e.place(e.caster, n.zone);
}
function gn(e, t, n) {
	let r = A(e, t).find((t) => t.k === "hero" && j(e, t) === O(n));
	return r?.k === "hero" ? r.id : void 0;
}
function q(e, t, n) {
	return A(e, t).filter((t) => {
		if (t.k === "monster" || t.k === "outsider") return !0;
		let r = j(e, t);
		return r !== null && r === O(n);
	});
}
function _n(e, t) {
	let n = e.s, r = n.heroes[t], i = e.zone();
	if (!i || !r.zone) return;
	let a = null, o = Infinity;
	for (let e of T[r.zone].adj) {
		let t = D(e, i, n.towers, r.team);
		t < o && (o = t, a = e);
	}
	a && V(n, t, a, { spellEffect: !0 });
}
function vn(e, t) {
	let n = mt(e.s, t);
	return n ? V(e.s, t, n, { spellEffect: !0 }) : !1;
}
function J(e, t, n = "attach") {
	e.addEffect({
		key: x[e.s.cardInsts[e.cardInst]?.card]?.id ?? "buff",
		on: e.caster,
		args: t,
		expires: n,
		cardInst: n === "attach" ? e.cardInst : void 0
	});
}
function yn(e, t, n, r) {
	e.addEffect({
		key: r ?? x[e.s.cardInsts[e.cardInst].card].id,
		on: t,
		args: n,
		expires: "attach",
		cardInst: e.cardInst
	});
}
function Y(e, t, n) {
	e.addEffect({
		key: n ?? x[e.s.cardInsts[e.cardInst].card].id,
		on: e.caster,
		args: t,
		expires: "turnEnd"
	});
}
function X(e, t, n) {
	e.addEffect({
		key: n ?? x[e.s.cardInsts[e.cardInst].card].id,
		on: e.caster,
		args: t,
		expires: "roundEnd"
	});
}
function bn(e, t, n, r) {
	let i = e.hands[t].filter((e) => e !== r);
	if (i.length < n) return !1;
	for (let r = 0; r < n; r += 1) e.hands[t].splice(e.hands[t].indexOf(i[r]), 1), e.discards[t].push(i[r]);
	return !0;
}
function xn(e, t, n) {
	let r = e.heroes[t];
	return r.hp <= n ? !1 : (r.hp -= n, !0);
}
function Z(e, t, n) {
	let r = e.turn;
	return !r || r.mp < t || r.ap < n ? !1 : (r.mp -= t, r.ap -= n, r.spentMp += t, !0);
}
U("A00", {
	targets: [G("nearby")],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k !== "hero") return;
		let n = e.dmg(t, 3);
		e.status(t.id, "burn"), n && e.addEffect({
			key: "A00",
			on: e.caster,
			args: { watch: t.id },
			expires: "turnEnd"
		});
	}
}), L.A00 = { onEvent: (e, t, n) => {
	if (n.k !== "enter" || n.hero !== t.args?.watch) return;
	let r = e.heroes[t.on ?? ""];
	r && !r.out && V(e, t.on ?? "", n.zone), Re(e, t.id);
} }, U("A01", {
	targets: [],
	timing: "shop",
	run: (e) => {
		X(e, {
			init: 3,
			str: 1
		}), e.addEffect({
			key: "delayMinions",
			team: e.team,
			args: {},
			expires: "roundEnd"
		});
	}
}), U("A02", {
	targets: [],
	payCost: (e, t) => xn(e, t, 1),
	run: (e) => Y(e, {
		nextAttackStr: 5,
		nextAttackBurn: 1
	})
}), U("A03", {
	targets: [G("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && yn(e, t.id, {});
	}
});
var Sn = (e) => U(e, {
	targets: [hn],
	run: (e) => {
		K(e);
	}
});
for (let e of /* @__PURE__ */ "A04.A10.A16.A22.A28.A34.A40.A46.B04.B10.B16.B22.B28.B34.B40.B46.C04.C10.C16.C22.C28.C34.C40.C46.D04.D10.D16.D22.D28.D34.D40.D46".split(".")) Sn(e);
var Cn = (e, t) => U(e, {
	targets: [hn],
	run: (e) => {
		if (!K(e)) return;
		let n = e.zone();
		if (!n) return;
		let r = gn(e.s, n, e.team);
		r ? (e.dmg({
			k: "hero",
			id: r
		}, 2), e.status(r, t)) : e.s.outsider.zone === n && !e.s.outsider.tamed && e.dmg({ k: "outsider" }, 2);
	}
});
Cn("A05", "burn"), Cn("B17", "freeze"), Cn("D17", "silence"), U("A06", {
	targets: [G(2)],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.status(t.id, "burn"), yn(e, t.id, {}));
	}
}), L.A06 = { onEvent: (e, t, n) => {
	n.k === "dmg" && n.target.k === "hero" && n.target.id === t.on && n.source === null && n.via === "effect" && B(e, null, n.target, 1, {
		piercing: !0,
		via: "effect"
	});
} }, U("A07", {
	targets: [{
		what: "anyHero",
		range: 2
	}],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.status(t.id, "disarm"), e.status(t.id, "silence"));
	}
}), U("A08", {
	targets: [{
		what: "friendlyHero",
		range: 3
	}],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && yn(e, t.id, {});
	}
}), L.A08 = { onEvent: (e, t, n) => {
	if (n.k !== "dmg" || n.target.k !== "hero" || n.target.id !== t.on) return;
	let r = e.heroes[t.on ?? ""];
	r && !r.out && (r.hp = Math.min(9, r.hp + 2));
} }, U("A09", {
	targets: [],
	run: (e) => e.addEffect({
		key: "A09",
		on: e.caster,
		args: {},
		expires: "turnEnd"
	})
}), U("A11", {
	targets: [{
		what: "unit",
		range: 2
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && e.healUnit(t, 3);
	}
});
var wn = (e, t) => U(e, {
	targets: [G("nearby")],
	run: (e) => {
		let n = e.targets[0];
		if (n?.k !== "hero") return;
		let r = e.s.heroes[n.id].zone;
		e.status(n.id, t), vn(e, n.id) && r && e.place(e.caster, r);
	}
});
wn("A12", "burn"), wn("B18", "freeze"), wn("C06", "disarm"), wn("D42", "silence"), U("A13", {
	targets: [],
	run: (e) => J(e, {
		armor: 1,
		retaliateStatus: "burn",
		taunt: "spell"
	})
}), U("A14", {
	targets: [
		W("nearby"),
		W("nearby", !0),
		W("nearby", !0)
	],
	payCost: (e, t, n, r) => (B(e, null, {
		k: "hero",
		id: t
	}, Math.max(1, r.length), { via: "effect" }), !e.heroes[t].out),
	run: (e) => {
		for (let t of e.targets) t.k !== "zone" && (e.dmg(t, 1), t.k === "hero" && e.status(t.id, "stun"));
	}
}), U("A15", {
	targets: [],
	run: (e) => {
		let t = e.zone();
		if (t) for (let n of q(e.s, t, e.team)) e.dmg(n, 3, { piercing: !0 }), n.k === "hero" && e.status(n.id, "burn");
	}
}), U("A17", {
	targets: [{
		what: "unit",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (t.k === "hero" ? e.buff(t.id, {
			armor: 3,
			retaliateStatus: "burn"
		}, "turnEnd", "A17") : t.k === "minion" && e.addEffect({
			key: "minionArmor",
			team: t.team,
			args: { armor: 3 },
			expires: "turnEnd"
		}));
	}
}), U("A18", {
	targets: [G("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (_n(e, t.id), e.status(t.id, "stun"));
	}
}), U("A19", {
	targets: [],
	run: (e) => {
		e.s.turn && (e.s.turn.mp += 2), Y(e, { tough: !0 });
	}
}), U("A20", {
	targets: [
		W("same"),
		W("same", !0),
		W("same", !0)
	],
	run: (e) => {
		let t = e.zone();
		if (!t) return;
		let n = q(e.s, t, e.team).length >= 4 ? 3 : 2;
		for (let t of e.targets.slice(0, n)) t.k !== "zone" && (e.dmg(t, 2), t.k === "hero" && e.status(t.id, "burn"));
	}
}), U("A21", {
	targets: [
		{
			what: "zone",
			range: 2
		},
		W("same", !0, { from: "target0" }),
		W("same", !0, { from: "target0" }),
		W("same", !0, { from: "target0" })
	],
	run: (e) => {
		if (K(e)) for (let t of e.targets.slice(1)) t.k !== "zone" && (e.dmg(t, 1, { piercing: !0 }), t.k === "hero" && e.status(t.id, "freeze"));
	}
}), U("A23", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "zone" && e.addEffect({
			key: "A23",
			team: e.team,
			args: { zone: t.zone },
			expires: "roundEnd"
		});
	}
}), U("A24", {
	targets: [G("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.dmg(t, 3, { piercing: !0 }), e.status(t.id, "burn"));
	}
}), U("A25", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	payCost: (e) => Z(e, 0, 1),
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of q(e.s, t.zone, e.team).slice(0, 5)) e.dmg(n, 1, { piercing: !0 }), n.k === "hero" && e.status(n.id, "burn");
	}
}), U("A26", {
	targets: [{
		what: "zone",
		range: 2
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of [t.zone, ...T[t.zone].adj]) for (let t of A(e.s, n)) t.k === "hero" && j(e.s, t) === O(e.team) && (e.dmg(t, 1, { piercing: !0 }), e.status(t.id, "burn"));
	}
}), U("A27", {
	targets: [W("nearby", !0), W("nearby", !0)],
	run: (e) => {
		let t = e.hero.owner;
		e.draw(t, 4);
		for (let n = 0; n < 2; n += 1) {
			let n = e.s.hands[t].pop();
			if (n === void 0) break;
			e.s.decks[t].push(n);
		}
		for (let t of e.targets) t.k !== "zone" && (e.dmg(t, 1, { piercing: !0 }), t.k === "hero" && e.status(t.id, "burn"));
	}
}), U("A29", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of q(e.s, t.zone, e.team).filter((e) => e.k !== "monster").slice(0, 2)) e.dmg(n, 1, { piercing: !0 }), n.k === "hero" && e.status(n.id, "burn");
	}
}), U("A30", {
	targets: [{
		what: "zone",
		range: "any"
	}],
	payCost: (e, t) => Z(e, 1, 0) && xn(e, t, 1),
	run: (e) => {
		if (!K(e)) return;
		let t = e.zone();
		if (t) {
			let n = gn(e.s, t, e.team);
			n && e.dmg({
				k: "hero",
				id: n
			}, 1, { piercing: !0 });
		}
		e.s.turn && (e.s.turn.mp = 0, e.s.turn.ap = 0);
	}
}), U("A31", {
	targets: [],
	timing: "shop",
	run: (e) => e.addEffect({
		key: "A31",
		team: e.team,
		args: {},
		expires: "roundEnd"
	})
}), U("A32", {
	targets: [
		W("nearby"),
		W("nearby", !0),
		W("nearby", !0)
	],
	payCost: (e) => Z(e, 1, 1),
	run: (e) => {
		for (let t of e.targets) t.k !== "zone" && e.freeAttack(t);
	}
}), U("A33", {
	targets: [],
	timing: "shop",
	run: (e) => X(e, {
		grantAp: 3,
		onlyHeroOutsider: 1
	})
}), U("A35", {
	targets: [W("same")],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && e.freeAttack(t);
	}
}), U("A36", {
	targets: [],
	timing: "shop",
	run: (e) => {
		let t = e.zone();
		t && e.addEffect({
			key: "pushAtRoundEnd",
			args: { zone: t },
			expires: "roundEnd"
		});
	}
}), U("A37", {
	targets: [
		{
			what: "zone",
			range: "any",
			note: "contested"
		},
		W("same", !0, { from: "target0" }),
		W("same", !0, { from: "target0" })
	],
	payCost: (e, t) => {
		let n = e.heroes[t];
		if (!n.zone) return !1;
		for (let r of M(e, n.zone, n.team)) {
			let i = e.minions[r];
			if (i && i[n.team] > 0) return B(e, {
				k: "hero",
				id: t
			}, {
				k: "minion",
				zone: r,
				team: n.team
			}, 3, { via: "effect" }), !0;
		}
		return !1;
	},
	run: (e) => {
		if (K(e)) for (let t of e.targets.slice(1)) t.k !== "zone" && (e.dmg(t, 1), t.k === "hero" && e.status(t.id, "disarm"));
	}
}), U("A38", {
	targets: [],
	run: (e) => J(e, {})
}), L.A38 = { onEvent: (e, t, n) => {
	if (n.k !== "defeat" || n.unit.k !== "minion") return;
	let r = e.heroes[t.on ?? ""];
	r && !r.out && r.zone && n.unit.team !== r.team && M(e, r.zone, r.team).includes(n.unit.zone) && (r.hp = Math.min(9, r.hp + 2));
} }, U("A39", {
	targets: [],
	timing: "shop",
	run: (e) => e.addEffect({
		key: "A39",
		on: e.caster,
		args: {},
		expires: "roundEnd"
	})
}), L.A39 = { onEvent: (e, t, n) => {
	if (n.k !== "roundEnd") return;
	let r = e.heroes[t.on ?? ""];
	if (!r || r.out || !r.zone) {
		Re(e, t.id);
		return;
	}
	let i = null;
	for (let [t, n] of Object.entries(e.towers)) {
		if (n === r.team) continue;
		let [a, o] = t.split("|");
		if (D(r.zone, a, e.towers, r.team) <= 3 || D(r.zone, o, e.towers, r.team) <= 3) {
			i = {
				k: "tower",
				edge: t
			};
			break;
		}
	}
	if (!i) {
		let t = r.team === 0 ? "NS" : "NL";
		D(r.zone, t, e.towers, r.team) <= 3 && (i = {
			k: "nexus",
			team: O(r.team)
		});
	}
	i && B(e, {
		k: "hero",
		id: t.on ?? ""
	}, i, 4, {
		ignoreTough: !0,
		via: "spell",
		isRetaliate: !0
	}), Re(e, t.id);
} }, U("A41", {
	targets: [{
		what: "zone",
		range: "nearby",
		note: "contested"
	}],
	payCost: (e, t) => xn(e, t, 1),
	run: (e) => {
		let t = e.targets[0];
		t?.k === "zone" && e.placeMinion(t.zone, e.team, 1);
	}
}), U("A42", {
	targets: [{
		what: "zone",
		range: "adjacent",
		note: "lane"
	}, G("same", !0, { from: "target0" })],
	condition: (e, t) => {
		let n = e.heroes[t];
		return !n.zone || T[n.zone]?.kind !== "jungle" ? !1 : !Object.values(e.heroes).some((e) => !e.out && e.team !== n.team && e.zone === n.zone);
	},
	run: (e) => {
		if (!K(e)) return;
		let t = e.targets[1];
		t?.k === "hero" && (e.buff(e.caster, { str: 2 }, "turnEnd", "A42"), e.freeAttack(t));
	}
}), U("A43", {
	targets: [G("same", !0), G("same", !0)],
	run: (e) => {
		Y(e, { armor: 2 });
		for (let t of e.targets) t?.k === "hero" && (e.dmg(t, 2, { piercing: !0 }), e.status(t.id, "burn"));
	}
}), U("A44", {
	targets: [],
	run: (e) => J(e, {})
}), U("A45", {
	targets: [hn],
	run: (e) => {
		if (!K(e)) return;
		let t = e.zone();
		if (!t) return;
		let n = gn(e.s, t, e.team);
		n && (e.dmg({
			k: "hero",
			id: n
		}, 5, { piercing: !0 }), e.status(n, "silence"));
	}
}), U("A47", {
	targets: [{
		what: "monsterOrOutsider",
		range: "same"
	}],
	run: (e) => {
		Y(e, { armor: 2 });
		let t = e.targets[0];
		t && t.k !== "zone" && (e.buff(e.caster, { str: 2 }, "turnEnd", "A47"), e.freeAttack(t));
	}
}), U("B00", {
	targets: [G("nearby", !0)],
	run: (e) => {
		e.heal(e.caster, 3);
		let t = e.targets[0];
		t?.k === "hero" && e.status(t.id, "disarm");
	}
}), U("B01", {
	targets: [G(2)],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && e.buff(t.id, { counterNextSpell: !0 }, "turnEnd", "B01");
	}
}), U("B02", {
	targets: [],
	timing: "shop",
	run: (e) => J(e, {}, "roundEnd")
}), U("B03", {
	targets: [G(2, !1, { sight: "ignore" })],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.status(t.id, "silence"), e.s.heroes[t.id], e.s.turn?.hero === t.id && (e.s.turn.mp = Math.max(0, e.s.turn.mp - 1), e.s.turn.ap = Math.max(0, e.s.turn.ap - 1)), e.buff(t.id, { noCast: !0 }, "roundEnd", "B03"));
	}
}), U("B05", {
	targets: [],
	payCost: (e) => Z(e, 0, 1),
	run: (e) => {
		let t = e.zone();
		if (!t) return;
		let n = e.s.minions[t];
		n && (n[0] > 0 || n[1] > 0) && e.placeMinion(t, e.team, 2);
	}
}), U("B06", {
	targets: [],
	run: (e) => J(e, {})
}), U("B07", {
	targets: [{
		what: "enemyHeroOrMinion",
		range: "nearby"
	}, {
		what: "unit",
		range: "nearby",
		optional: !0
	}],
	run: (e) => {
		let [t, n] = e.targets;
		if (!t || t.k === "zone") return;
		let r = e.dmg(t, 2);
		t.k === "hero" && e.status(t.id, "freeze"), r && n && n.k !== "zone" && e.healUnit(n, 2);
	}
}), U("B08", {
	targets: [],
	run: (e) => {
		let t = e.zone();
		if (t) for (let n of M(e.s, t, e.team)) for (let t of A(e.s, n)) t.k === "hero" && j(e.s, t) === e.team && e.heal(t.id, 2);
	}
}), U("B09", {
	targets: [{
		what: "unit",
		range: "any"
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (e.healUnit(t, 3), t.k === "hero" && (e.cleanse(t.id, !0), e.s.heroes[t.id].team === e.team && e.heal(t.id, 5)));
	}
}), U("B11", {
	targets: [{
		what: "unit",
		range: 2
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && e.healUnit(t, 3);
	}
}), U("B12", {
	targets: [],
	timing: "shop",
	run: (e) => {
		e.heal(e.caster, 3), X(e, { init: 3 }), e.addEffect({
			key: "delayMinions",
			team: e.team,
			args: {},
			expires: "roundEnd"
		});
	}
}), U("B13", {
	targets: [{
		what: "zone",
		range: "dist2"
	}, G("same", !0, { from: "target0" })],
	run: (e) => {
		if (!K(e)) return;
		let t = e.targets[1];
		t?.k === "hero" && (e.status(t.id, "silence"), e.buff(t.id, { counterNextSpell: !0 }, "turnEnd", "B13"));
	}
}), U("B14", {
	targets: [],
	run: (e) => J(e, {
		armor: 1,
		retaliateStatus: "disarm"
	})
}), U("B15", {
	targets: [{
		what: "zone",
		range: 2
	}],
	payCost: (e) => Z(e, 0, 1),
	run: (e) => {
		if (!K(e)) return;
		let t = e.zone();
		if (t) for (let n of q(e.s, t, e.team)) (n.k === "hero" || n.k === "minion") && e.freeAttack(n);
	}
}), U("B20", {
	targets: [
		{
			what: "zone",
			range: "nearby"
		},
		W("same", !0, { from: "target0" }),
		W("same", !0, { from: "target0" }),
		W("same", !0, { from: "target0" }),
		W("same", !0, { from: "target0" })
	],
	run: (e) => {
		let t = _e(e.s, {
			k: "hero",
			id: e.caster
		}, "spell", null);
		for (let n of e.targets.slice(1, 1 + t)) n.k !== "zone" && (e.dmg(n, 2), n.k === "hero" && e.status(n.id, "silence"));
	}
}), U("B21", {
	targets: [{
		what: "unit",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (t.k === "hero" ? e.buff(t.id, {
			armor: 4,
			retaliateArmor: 1
		}, "turnEnd", "B21") : t.k === "minion" && e.addEffect({
			key: "minionArmor",
			team: t.team,
			args: { armor: 4 },
			expires: "turnEnd"
		}));
	}
}), U("B23", {
	targets: [{
		what: "unit",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (t.k === "hero" ? e.buff(t.id, {
			armor: 3,
			retaliateStatus: "freeze"
		}, "turnEnd", "B23") : t.k === "minion" && e.addEffect({
			key: "minionArmor",
			team: t.team,
			args: { armor: 3 },
			expires: "turnEnd"
		}));
	}
}), U("B24", {
	targets: [W("nearby", !0), W("nearby", !0)],
	payCost: (e, t, n, r, i) => bn(e, n, 1, i),
	run: (e) => {
		for (let t of e.targets) t.k !== "zone" && (e.dmg(t, 2, { piercing: !0 }), t.k === "hero" && e.status(t.id, "disarm"));
	}
}), U("B25", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	payCost: (e, t, n, r, i) => bn(e, n, 1, i),
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of A(e.s, t.zone)) n.k === "hero" && j(e.s, n) === O(e.team) && (e.dmg(n, 4, { piercing: !0 }), e.status(n.id, "freeze"), e.addEffect({
			key: "B25",
			on: n.id,
			args: { zone: t.zone },
			expires: "turnEnd"
		}));
	}
}), U("B26", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	payCost: (e, t, n, r, i) => bn(e, n, 1, i),
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of q(e.s, t.zone, e.team).slice(0, 5)) e.dmg(n, 1, { piercing: !0 }), n.k === "hero" && e.status(n.id, "freeze");
	}
}), U("B27", {
	targets: [{
		what: "zone",
		range: "any"
	}],
	payCost: (e, t, n, r, i) => bn(e, n, 1, i),
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone" && t.zone !== e.zone() && K(e)) for (let n of q(e.s, t.zone, e.team)) e.dmg(n, 2, { piercing: !0 }), n.k === "hero" && e.status(n.id, "freeze");
	}
}), U("B29", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of q(e.s, t.zone, e.team).filter((e) => e.k !== "monster").slice(0, 2)) e.dmg(n, 1, { piercing: !0 }), n.k === "hero" && e.status(n.id, "freeze");
	}
}), U("B30", {
	targets: [{
		what: "anyHero",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k !== "hero") return;
		let n = e.dmg(t, 3);
		_n(e, t.id), n && e.heal(e.caster, 3);
	}
}), U("B31", {
	targets: [G("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.dmg(t, 3), e.status(t.id, "disarm"), _n(e, t.id), e.buff(t.id, { noCast: !0 }, "roundEnd", "B31"), X(e, { noCast: !0 }, "B31"));
	}
}), U("B32", {
	targets: [],
	run: (e) => J(e, { armor: 1 })
}), U("B33", {
	targets: [G(2, !0), G(2, !0)],
	run: (e) => {
		e.heal(e.caster, 4);
		for (let t of e.targets) t?.k === "hero" && (_n(e, t.id), e.status(t.id, "freeze"));
	}
}), U("B35", {
	targets: [],
	run: (e) => X(e, { momentum: 2 })
}), U("B36", {
	targets: [{
		what: "zone",
		range: "any",
		note: "jungleNoEnemy"
	}, G("nearby", !0, {
		from: "target0",
		note: "lane"
	})],
	condition: (e, t) => {
		let n = e.heroes[t];
		return !n.zone || T[n.zone]?.kind !== "jungle" ? !1 : !Object.values(e.heroes).some((e) => !e.out && e.team !== n.team && e.zone === n.zone);
	},
	run: (e) => {
		if (!K(e)) return;
		let t = e.targets[1];
		t?.k === "hero" && e.freeAttack(t);
	}
}), U("B37", {
	targets: [G("nearby", !0)],
	run: (e) => {
		e.heal(e.caster, 3);
		let t = e.targets[0];
		t?.k === "hero" && (e.dmg(t, 2), e.status(t.id, "stun"));
	}
}), U("B38", {
	targets: [],
	run: (e) => J(e, {})
}), L.B38 = { onEvent: (e, t, n) => {
	if (n.k !== "enter" || n.hero !== t.on || e.turn?.hero !== t.on || !Oe(e, `B38:${t.on}`)) return;
	let r = A(e, n.zone).find((t) => t.k === "monster" || t.k === "outsider" && !e.outsider.tamed);
	r && B(e, {
		k: "hero",
		id: t.on ?? ""
	}, r, 2, { via: "spell" });
} }, U("B39", {
	targets: [],
	timing: "shop",
	run: (e) => X(e, {}, "B39")
}), U("B41", {
	targets: [{
		what: "monsterOrOutsider",
		range: "nearby",
		optional: !0
	}],
	run: (e) => {
		Y(e, { armor: 2 });
		let t = e.targets[0];
		t && t.k !== "zone" && e.dmg(t, 3);
	}
}), U("B42", {
	targets: [{
		what: "zone",
		range: "notNearby"
	}, {
		what: "enemyHeroOrMinion",
		range: "same",
		from: "target0"
	}],
	payCost: (e) => Z(e, 1, 0),
	run: (e) => {
		let t = e.targets[1];
		t && t.k !== "zone" && (e.dmg(t, 1), t.k === "hero" && e.status(t.id, "freeze"));
	}
}), U("B43", {
	targets: [],
	run: (e) => J(e, { tough: !0 })
}), L.B43 = { onEvent: (e, t, n) => {
	(n.k === "attackDeclared" || n.k === "castDeclared") && n.hero === t.on && Re(e, t.id);
} }, U("B44", {
	targets: [
		G("nearby", !0),
		G("nearby", !0),
		G("nearby", !0),
		G("nearby", !0)
	],
	payCost: (e) => Z(e, 0, 1),
	run: (e) => {
		for (let t of e.targets) t?.k === "hero" && e.freeAttack(t);
	}
}), U("B45", {
	targets: [G("any")],
	payCost: (e, t) => {
		let n = e.turn?.ap ?? 0;
		return e.turn ? (e.turn.ap = 0, e.effects.push({
			id: e.nextEffectId++,
			key: "B45",
			by: t,
			on: t,
			args: { str: 3 * n },
			expires: "turnEnd",
			src: "spell"
		}), !0) : !1;
	},
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && e.freeAttack(t);
	}
}), U("B47", {
	targets: [W("dist2")],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && e.freeAttack(t);
	}
}), U("C00", {
	targets: [G(2)],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && yn(e, t.id, {});
	}
}), L.C00 = { onEvent: (e, t, n) => {
	n.k === "attackResolved" && n.hero === t.on && B(e, {
		k: "hero",
		id: t.by
	}, {
		k: "hero",
		id: t.on ?? ""
	}, 1, {
		piercing: !0,
		via: "spell"
	}), n.k === "castResolved" && n.hero === t.on && B(e, {
		k: "hero",
		id: t.by
	}, {
		k: "hero",
		id: t.on ?? ""
	}, 1, {
		piercing: !0,
		via: "spell"
	}), n.k === "turnEnd" && n.hero === t.on && Re(e, t.id);
} }, U("C01", {
	targets: [G("adjacent", !1, { sight: "ignore" })],
	payCost: (e) => Z(e, 2, 0),
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.freeAttack(t), e.s.heroes[t.id].out || e.freeAttack(t));
	}
}), U("C02", {
	targets: [{
		what: "zone",
		range: "any",
		note: "jungle"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k !== "zone") return;
		let n = q(e.s, t.zone, e.team)[0];
		n && (e.dmg(n, 1), n.k === "hero" && e.status(n.id, "stun"));
	}
}), U("C03", {
	targets: [G("nearby", !1, { sight: "ignore" })],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && e.dmg(t, 8, { piercing: !0 });
	}
}), U("C05", {
	targets: [W("nearby", !1, {
		note: "jungle",
		sight: "ignore"
	})],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && e.freeAttack(t);
	}
}), U("C07", {
	targets: [],
	run: (e) => J(e, {
		armor: 2,
		taunt: "both"
	})
}), U("C08", {
	targets: [
		W("same"),
		W("same", !0),
		W("same", !0)
	],
	run: (e) => {
		let t = e.zone();
		if (!t) return;
		let n = (e.s.minions[t]?.[e.team] ?? 0) >= 3 ? 3 : 2;
		for (let t of e.targets.slice(0, n)) t.k !== "zone" && (e.dmg(t, 2), t.k === "hero" && e.status(t.id, "disarm"));
	}
}), U("C09", {
	targets: [],
	run: (e) => X(e, { momentum: 2 }, "C09")
}), U("C11", {
	targets: [{
		what: "unit",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (t.k === "hero" ? e.buff(t.id, {
			armor: 3,
			retaliateStatus: "disarm"
		}, "turnEnd", "C11") : t.k === "minion" && e.addEffect({
			key: "minionArmor",
			team: t.team,
			args: { armor: 3 },
			expires: "turnEnd"
		}));
	}
}), U("C12", {
	targets: [{
		what: "friendlyHero",
		range: "nearby"
	}, {
		what: "zone",
		range: "any",
		note: "jungleNoEnemy"
	}],
	run: (e) => {
		let [t, n] = e.targets;
		t?.k === "hero" && n?.k === "zone" && e.place(t.id, n.zone) && e.buff(t.id, { str: 1 }, "turnEnd", "C12");
	}
}), U("C13", {
	targets: [G("same", !0)],
	run: (e) => {
		Y(e, { armor: 2 });
		let t = e.targets[0];
		t?.k === "hero" && e.dmg(t, 2);
	}
}), U("C14", {
	targets: [],
	run: (e) => J(e, {})
}), L.C14 = { onEvent: (e, t, n) => {
	if (n.k !== "jungleEnd") return;
	let r = e.heroes[t.on ?? ""];
	if (r && !r.out && r.zone) for (let n of Object.keys(T)) {
		if (D(r.zone, n, e.towers, r.team) > 2) continue;
		let i = A(e, n).find((t) => t.k === "monster" || t.k === "outsider" && !e.outsider.tamed);
		if (i) {
			B(e, {
				k: "hero",
				id: t.on ?? ""
			}, i, 1, { via: "spell" });
			return;
		}
	}
} }, U("C15", {
	targets: [],
	timing: "shop",
	run: (e) => X(e, {
		planStrArmor: 1,
		onlyOutsider: 1,
		ignoreTough: 1
	}, "C15")
}), U("C17", {
	targets: [{
		what: "zone",
		range: "adjacent",
		note: "hasMonsterOrOutsider"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k !== "zone" || !K(e)) return;
		let n = A(e.s, t.zone).find((t) => t.k === "monster" || t.k === "outsider" && !e.s.outsider.tamed);
		n && B(e.s, {
			k: "hero",
			id: e.caster
		}, n, 2, {
			piercing: !0,
			ignoreTough: !0,
			via: "spell",
			isRetaliate: !0
		});
	}
}), U("C18", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	payCost: (e) => Z(e, 2, 0),
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of q(e.s, t.zone, e.team).slice(0, 5)) e.dmg(n, 1, { piercing: !0 }), n.k === "hero" && e.status(n.id, "disarm");
	}
}), U("C19", {
	targets: [],
	run: (e) => {
		let t = e.hero.owner;
		e.s.discards[t].some((t) => !x[e.s.cardInsts[t].card].flags.includes("u")) && (e.s.pending = {
			k: "choose",
			seat: t,
			chooseKind: "spellChoice",
			args: {
				card: "C19",
				caster: e.caster,
				mode: "discardPick"
			}
		});
	},
	onChoose: (e, t, n) => {
		let r = e.heroes[t]?.owner;
		if (!r || n.card === void 0) return mn("games.onward.errNeedCard");
		let i = e.discards[r].indexOf(n.card);
		return i < 0 ? mn("games.onward.errNotInHand") : x[e.cardInsts[n.card].card].flags.includes("u") ? mn("games.onward.errBadTarget") : (e.discards[r].splice(i, 1), e.hands[r].push(n.card), null);
	}
}), U("C20", {
	targets: [W("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (e.dmg(t, 2, { piercing: !0 }), t.k === "hero" && e.status(t.id, "burn"));
	}
}), U("C21", {
	targets: [{
		what: "outsider",
		range: "nearby"
	}],
	run: (e) => {
		B(e.s, {
			k: "hero",
			id: e.caster
		}, { k: "outsider" }, 8, {
			ignoreTough: !0,
			via: "spell",
			isRetaliate: !0
		});
	}
}), U("C23", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of q(e.s, t.zone, e.team).filter((e) => e.k !== "monster").slice(0, 2)) e.dmg(n, 1, { piercing: !0 }), n.k === "hero" && e.status(n.id, "disarm");
	}
}), U("C24", {
	targets: [G("nearby", !0)],
	run: (e) => {
		Y(e, { armor: 2 });
		let t = e.targets[0];
		t?.k === "hero" && e.dmg(t, 3);
	}
}), U("C25", {
	targets: [],
	run: (e) => Y(e, {}, "C25")
}), L.C25 = { onEvent: (e, t, n) => {
	if (n.k !== "enter") return;
	let r = e.heroes[t.on ?? ""];
	if (!r || r.out || e.turn?.hero !== t.on) return;
	let i = e.heroes[n.hero];
	if (i && i.team !== r.team) {
		for (let i of q(e, n.zone, r.team).slice(0, 2)) B(e, {
			k: "hero",
			id: t.on ?? ""
		}, i, 2, { via: "spell" }), i.k === "hero" && !e.heroes[i.id].statuses.includes("disarm") && e.heroes[i.id].statuses.push("disarm");
		Re(e, t.id);
	}
} }, U("C26", {
	targets: [G("nearby"), {
		what: "zone",
		range: "adjacent",
		from: "target0"
	}],
	run: (e) => {
		let [t, n] = e.targets;
		t?.k === "hero" && (e.status(t.id, "freeze"), n?.k === "zone" && V(e.s, t.id, n.zone, { spellEffect: !0 }), e.buff(t.id, { noCast: !0 }, "turnEnd", "C26"));
	}
}), U("C27", {
	targets: [W("same"), {
		what: "zone",
		range: "any",
		optional: !0
	}],
	run: (e) => {
		let [t, n] = e.targets;
		if (t && t.k !== "zone" && (e.buff(e.caster, { str: 2 }, "turnEnd", "C27"), e.freeAttack(t).length > 0 && t.k === "hero" && n?.k === "zone")) {
			let r = e.team === 0 ? "NL" : "NS";
			n.zone !== r && V(e.s, t.id, n.zone, { spellEffect: !0 });
		}
	}
}), U("C29", {
	targets: [],
	run: (e) => e.addEffect({
		key: "minionArmor",
		by: e.caster,
		team: e.team,
		args: { armor: 3 },
		expires: "turnEnd",
		cardInst: e.cardInst
	})
}), U("C30", {
	targets: [{
		what: "friendlyHero",
		range: 2
	}],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (_n(e, t.id), e.status(t.id, "disarm"));
	}
});
var Tn = (e) => U(e, {
	targets: [G(2)],
	run: (t) => {
		let n = t.targets[0];
		n?.k === "hero" && (_n(t, n.id), t.status(n.id, "disarm"), t.buff(n.id, { noCast: !0 }, "turnEnd", e));
	}
});
Tn("C31"), Tn("C35"), U("C32", {
	targets: [],
	run: (e) => {
		e.heal(e.caster, 4), Y(e, {
			armor: 1,
			taunt: "attack"
		});
	}
}), U("C33", {
	targets: [{
		what: "zone",
		range: "any",
		note: "hasTowerOrNexus"
	}],
	payCost: (e, t) => xn(e, t, 1),
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone" && t.zone !== e.zone() && K(e)) for (let n of q(e.s, t.zone, e.team).slice(0, 6)) e.dmg(n, 1), n.k === "hero" && e.status(n.id, "stun");
	}
}), U("C36", {
	targets: [],
	run: (e) => {
		let t = e.zone();
		if (t) for (let n of M(e.s, t, e.team)) for (let t of A(e.s, n)) t.k === "hero" && j(e.s, t) === O(e.team) && (e.status(t.id, "stun"), e.dmg(t, 1), _n(e, t.id), e.buff(t.id, { blockSpellMove: 1 }, "turnEnd", "C36"));
	}
}), U("C37", {
	targets: [{
		what: "zone",
		range: "any",
		note: "jungleNoEnemy"
	}],
	timing: "shop",
	condition: (e, t) => T[e.heroes[t].zone ?? ""]?.kind === "jungle",
	run: (e) => {
		K(e), X(e, { init: 2 }), e.addEffect({
			key: "delayMinions",
			team: e.team,
			args: {},
			expires: "roundEnd"
		});
	}
}), U("C38", {
	targets: [],
	payCost: (e) => Z(e, 1, 0),
	run: (e) => {
		let t = e.zone();
		if (t) {
			let n = e.s.minions[t];
			n && (n[0] > 0 || n[1] > 0) && e.placeMinion(t, e.team, 1);
		}
		e.addEffect({
			key: "allJungle",
			args: {},
			expires: "turnEnd"
		});
	}
}), U("C39", {
	targets: [{
		what: "zone",
		range: "nearby",
		note: "contested"
	}],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "zone" && e.placeMinion(t.zone, e.team, 2), e.addEffect({
			key: "allJungle",
			args: {},
			expires: "turnEnd"
		});
	}
}), U("C41", {
	targets: [G("adjacent", !1, { sight: "ignore" })],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.status(t.id, "disarm"), e.dmg(t, 2), _n(e, t.id));
	}
}), U("C42", {
	targets: [{
		what: "unit",
		range: "nearby"
	}, {
		what: "friendlyHero",
		range: 2
	}],
	payCost: (e, t, n, r) => {
		let i = r[1];
		if (i?.k !== "hero") return !1;
		let a = r[0];
		return a?.k === "hero" && a.id === i.id ? !1 : (B(e, {
			k: "hero",
			id: t
		}, i, 2, {
			piercing: !0,
			via: "effect"
		}), !0);
	},
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (e.healUnit(t, 6), t.k === "hero" && e.cleanse(t.id, !1));
	}
}), U("C43", {
	targets: [{
		what: "unit",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (t.k === "hero" ? e.buff(t.id, {
			armor: 3,
			retaliateStatus: "disarm"
		}, "turnEnd", "C43") : t.k === "minion" && e.addEffect({
			key: "minionArmor",
			team: t.team,
			args: { armor: 3 },
			expires: "turnEnd"
		}));
	}
}), U("C44", {
	targets: [G("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.status(t.id, "disarm"), yn(e, t.id, {}));
	}
}), L.C44 = { onEvent: (e, t, n) => {
	if (n.k !== "turnEnd" || n.hero !== t.on) return;
	let r = e.heroes[t.on ?? ""];
	r && !r.out && !r.statuses.includes("disarm") && r.statuses.push("disarm");
} }, U("C45", {
	targets: [],
	run: (e) => {
		e.s.pending = {
			k: "choose",
			seat: e.hero.owner,
			chooseKind: "spellChoice",
			args: {
				card: "C45",
				caster: e.caster,
				mode: "option"
			}
		};
	},
	onChoose: (e, t, n) => {
		let r = e.heroes[t]?.team;
		if (r === void 0) return mn("games.onward.errPhase");
		if (n.option === 0) {
			let t = Object.values(e.heroes).find((e) => e.team === r && e.cond === "respawning");
			return t ? (t.cond = "ready", null) : mn("games.onward.errNoValidOption");
		}
		if (n.option === 1) {
			let t = Object.keys(e.heroes).find((t) => e.heroes[t].team === r && e.heroes[t].cond === "exhausted" && e.defeatedToday.includes(t));
			return t ? (e.heroes[t].cond = "ready", null) : mn("games.onward.errNoValidOption");
		}
		if (n.option === 2) {
			let t = e.outsider.laneTokens.pop();
			if (t === void 0) return mn("games.onward.errNoValidOption");
			let n = e.effects.findIndex((e) => e.key === "outsiderMark" && e.args?.lane === t);
			return n >= 0 && e.effects.splice(n, 1), null;
		}
		return mn("games.onward.errNoValidOption");
	}
}), U("C47", {
	targets: [{
		what: "unit",
		range: "adjacent"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t && t.k !== "zone" && (e.healUnit(t, 3), t.k === "hero")) {
			e.cleanse(t.id, !1);
			let n = e.zone();
			n && (e.s.minions[n]?.[0] ?? 0) > 0 && (e.s.minions[n]?.[1] ?? 0) > 0 && e.buff(t.id, { armor: 1 }, "turnEnd", "C47");
		}
	}
}), U("D00", {
	targets: [{
		what: "unit",
		range: 2
	}],
	run: (e) => {
		let t = e.targets[0];
		if (!t || t.k === "zone") return;
		t.k === "hero" && e.cleanse(t.id, !1);
		let n = t.k === "hero" ? t.id : t.k === "monster" ? `m:${t.zone}` : t.k === "outsider" ? "outsider" : null;
		n && e.addEffect({
			key: "D00",
			on: n,
			args: { preventNextDmg: !0 },
			expires: "turnEnd"
		});
	}
}), U("D01", {
	targets: [{
		what: "anyHero",
		range: 2
	}],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.status(t.id, "freeze"), e.status(t.id, "burn"), e.buff(t.id, { noCast: !0 }, "turnEnd", "D01"));
	}
}), U("D02", {
	targets: [{
		what: "otherFriendlyHero",
		range: 3
	}, {
		what: "zone",
		range: "adjacent",
		from: "target0"
	}],
	run: (e) => {
		let [t, n] = e.targets;
		t?.k === "hero" && n?.k === "zone" && V(e.s, t.id, n.zone, { spellEffect: !0 });
	}
}), U("D03", {
	targets: [{
		what: "friendlyHero",
		range: 3
	}],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.heal(t.id, 8), e.cleanse(t.id, !0), ze(e.s, t.id));
	}
}), U("D05", {
	targets: [{
		what: "unit",
		range: "nearby"
	}, {
		what: "unit",
		range: "nearby",
		optional: !0
	}],
	run: (e) => {
		for (let t of e.targets) {
			if (!t || t.k === "zone") continue;
			let n = t.k === "hero" && e.s.heroes[t.id].hp < 9 || t.k === "outsider" && e.s.outsider.hp < 5;
			e.healUnit(t, 2), t.k === "hero" && e.cleanse(t.id, !0), n && t.k === "hero" && e.buff(t.id, { armor: 1 }, "turnEnd", "D05");
		}
	}
}), U("D06", {
	targets: [
		{
			what: "otherFriendlyHero",
			range: 2
		},
		{
			what: "zone",
			range: "adjacent",
			from: "target0"
		},
		{
			what: "zone",
			range: "adjacent",
			from: "target0",
			optional: !0
		}
	],
	run: (e) => {
		let [t, n, r] = e.targets;
		t?.k === "hero" && (n?.k === "zone" && V(e.s, t.id, n.zone, { spellEffect: !0 }), r?.k === "zone" && V(e.s, t.id, r.zone, { spellEffect: !0 }), e.buff(t.id, { momentum: 1 }, "roundEnd", "D06"));
	}
}), U("D07", {
	targets: [],
	run: (e) => {
		let t = e.zone();
		if (t) for (let n of A(e.s, t)) n.k === "hero" && n.id !== e.caster && (e.status(n.id, "freeze"), vn(e, n.id));
	}
}), U("D08", {
	targets: [],
	timing: "shop",
	run: (e) => J(e, {}, "roundEnd")
}), U("D09", {
	targets: [
		W("nearby", !0),
		W("nearby", !0),
		W("nearby", !0),
		W("nearby", !0)
	],
	run: (e) => {
		for (let t of e.targets) t.k !== "zone" && (e.dmg(t, 2), t.k === "hero" && !e.s.heroes[t.id].out && (e.status(t.id, "silence"), vn(e, t.id)));
	}
}), U("D11", {
	targets: [{
		what: "zone",
		range: "nearby",
		note: "contested"
	}],
	payCost: (e) => Z(e, 1, 0),
	run: (e) => {
		let t = e.targets[0];
		t?.k === "zone" && e.placeMinion(t.zone, e.team, 1);
	}
}), U("D12", {
	targets: [G("any")],
	timing: "shop",
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && X(e, {
			init: e.s.day,
			str: e.s.day,
			onlyTarget: t.id
		}, "D12");
	}
}), U("D13", {
	targets: [W("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && Y(e, { overflowHero: t.k === "hero" ? t.id : "" }, "D13");
	}
}), U("D14", {
	targets: [G("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && yn(e, t.id, {});
	}
}), U("D15", {
	targets: [],
	timing: "shop",
	run: (e) => X(e, {}, "D15")
}), U("D18", {
	targets: [
		W("nearby", !0),
		W("nearby", !0),
		W("nearby", !0)
	],
	payCost: (e) => Z(e, 1, 0),
	run: (e) => {
		for (let t of e.targets) t.k !== "zone" && (e.dmg(t, 1), t.k === "hero" && e.status(t.id, "freeze"));
	}
}), U("D19", {
	targets: [G("nearby", !0)],
	run: (e) => {
		Y(e, { armor: 3 });
		let t = e.targets[0];
		t?.k === "hero" && e.status(t.id, "silence");
	}
}), U("D20", {
	targets: [],
	timing: "shop",
	run: (e) => J(e, {}, "roundEnd")
}), U("D21", {
	targets: [{
		what: "zone",
		range: "any",
		optional: !0
	}],
	timing: "shop",
	run: (e) => {
		X(e, { init: 2 });
		let t = e.targets[0];
		if (t?.k !== "zone" || t.zone === e.zone() || !K(e)) return;
		let n = gn(e.s, t.zone, e.team);
		n && (e.dmg({
			k: "hero",
			id: n
		}, 2), e.status(n, "disarm"));
	}
}), U("D23", {
	targets: [],
	run: (e) => J(e, {}, "roundEnd")
}), U("D24", {
	targets: [],
	run: (e) => {
		let t = Math.floor(e.charges / 2);
		t > 0 && e.draw(e.hero.owner, t);
	}
}), U("D25", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of q(e.s, t.zone, e.team).slice(0, e.charges)) e.dmg(n, 1, { piercing: !0 }), n.k === "hero" && e.status(n.id, "stun");
	}
}), U("D26", {
	targets: [G("nearby")],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && (e.dmg(t, e.charges, { piercing: !0 }), e.status(t.id, "silence"));
	}
}), U("D27", {
	targets: [],
	run: (e) => {
		let t = e.hero.owner;
		Object.keys(e.s.channeled).map(Number).filter((e) => !0).length > 0 && (e.s.pending = {
			k: "choose",
			seat: t,
			chooseKind: "spellChoice",
			args: {
				card: "D27",
				caster: e.caster,
				mode: "channelDouble"
			}
		});
	},
	onChoose: (e, t, n) => {
		let r = e.heroes[t]?.owner;
		return !r || n.card === void 0 || e.channeled[n.card] === void 0 ? mn("games.onward.errNeedCard") : (e.channeled[n.card] *= 2, ht(e, r, n.card, [], { keepChannel: !0 }), null);
	}
}), U("D29", {
	targets: [{
		what: "zone",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone") for (let n of q(e.s, t.zone, e.team).filter((e) => e.k !== "monster").slice(0, 2)) e.dmg(n, 1, { piercing: !0 }), n.k === "hero" && e.status(n.id, "silence");
	}
}), U("D30", {
	targets: [],
	condition: (e, t) => {
		let n = e.heroes[t];
		return !n.zone || T[n.zone]?.kind !== "jungle" ? !1 : !Object.values(e.heroes).some((e) => !e.out && e.team !== n.team && e.zone === n.zone);
	},
	payCost: (e, t, n) => bn(e, n, 3),
	run: (e) => {
		e.hero.cond = "ready";
	}
}), U("D31", {
	targets: [G("same", !0)],
	run: (e) => {
		Y(e, { tough: !0 });
		let t = e.targets[0];
		t?.k === "hero" && (e.dmg(t, 1, { piercing: !0 }), e.status(t.id, "silence"));
	}
}), U("D32", {
	targets: [],
	run: (e) => J(e, {})
}), L.D32 = { onEvent: (e, t, n) => {
	if (n.k !== "defeat" || n.unit.k !== "monster" || n.killer?.k !== "hero" || n.killer.id !== t.on) return;
	let r = e.heroes[t.on ?? ""];
	r && (e.gold[r.team] += 3);
} }, U("D33", {
	targets: [{
		what: "zone",
		range: "any",
		note: "contested"
	}],
	timing: "shop",
	run: (e) => {
		let t = e.targets[0];
		if (t?.k === "zone" && K(e)) for (let n of q(e.s, t.zone, e.team).slice(0, 2)) e.dmg(n, 2), n.k === "hero" && e.status(n.id, "silence");
	}
}), U("D35", {
	targets: [{
		what: "monsterOrOutsider",
		range: "any"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (!t || t.k === "zone") return;
		let n = t.k === "monster" ? `m:${t.zone}` : "outsider";
		e.addEffect({
			key: "D35",
			on: n,
			args: { preventNextDmg: !0 },
			expires: "turnEnd"
		});
	}
}), U("D36", {
	targets: [],
	timing: "turnStart",
	payCost: (e) => {
		let t = e.turn;
		return t ? (t.spentMp += t.mp, t.mp = 0, t.ap = 0, !0) : !1;
	},
	run: (e) => e.draw(e.hero.owner, 4)
}), U("D37", {
	targets: [{
		what: "zone",
		range: "notNearby",
		note: "lane"
	}, G("same", !0, { from: "target0" })],
	run: (e) => {
		let t = e.targets[1];
		t?.k === "hero" && (e.dmg(t, 1, { piercing: !0 }), e.status(t.id, "silence"));
	}
}), U("D38", {
	targets: [],
	payCost: (e, t, n, r, i) => bn(e, n, 1, i),
	run: (e) => Y(e, {}, "D38")
}), U("D39", {
	targets: [
		W("any", !1, { allowRepeat: !0 }),
		W("any", !0, { allowRepeat: !0 }),
		W("any", !0, { allowRepeat: !0 }),
		W("any", !0, { allowRepeat: !0 })
	],
	payCost: (e, t) => {
		let n = e.heroes[t];
		if (!n.zone) return !1;
		for (let r of M(e, n.zone, n.team)) {
			let i = e.minions[r];
			if (i && i[n.team] > 0) return B(e, {
				k: "hero",
				id: t
			}, {
				k: "minion",
				zone: r,
				team: n.team
			}, 1, {
				piercing: !0,
				via: "effect"
			}), !0;
		}
		return !1;
	},
	run: (e) => {
		for (let t of e.targets) t.k !== "zone" && e.dmg(t, 1, { piercing: !0 });
	}
}), U("D41", {
	targets: [W("nearby", !1, { note: "lane" })],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && e.freeAttack(t);
	}
}), U("D43", {
	targets: [
		W("same"),
		W("same", !0),
		W("same", !0)
	],
	run: (e) => {
		let t = e.zone();
		if (!t) return;
		let n = (e.s.minions[t]?.[O(e.team)] ?? 0) >= 5 ? 3 : 2;
		for (let t of e.targets.slice(0, n)) t.k !== "zone" && (e.dmg(t, 1), t.k === "hero" && e.status(t.id, "burn"));
	}
}), U("D44", {
	targets: [{
		what: "friendlyHero",
		range: 2
	}],
	run: (e) => {
		let t = e.targets[0];
		t?.k === "hero" && yn(e, t.id, {});
	}
}), U("D45", {
	targets: [{
		what: "zone",
		range: "nearby",
		note: "lane"
	}],
	run: (e) => {
		let t = e.targets[0];
		if (t?.k !== "zone") return;
		let n = E.find((e) => e.includes(t.zone));
		if (!n) return;
		let r = ne[E.indexOf(n)], i = e.s.minions[t.zone];
		if (i) {
			let t = e.s.minions[r] ?? [0, 0];
			t[0] += i[0], t[1] += i[1], e.s.minions[r] = t, i[0] = 0, i[1] = 0;
		}
		V(e.s, e.caster, r);
		for (let t of ae) t.lane === E.indexOf(n) && t.team === e.team && e.s.towers[t.edge] === void 0 && (e.s.towers[t.edge] = e.team);
	}
}), U("D47", {
	targets: [{
		what: "unit",
		range: "nearby"
	}],
	run: (e) => {
		let t = e.targets[0];
		t && t.k !== "zone" && (t.k === "hero" ? e.buff(t.id, {
			armor: 3,
			retaliateStatus: "silence"
		}, "turnEnd", "D47") : t.k === "minion" && e.addEffect({
			key: "minionArmor",
			team: t.team,
			args: { armor: 3 },
			expires: "turnEnd"
		}));
	}
});
//#endregion
//#region src/games/onward/schema.ts
var En = t.string(), Dn = t.string(), Q = t.int().nonnegative(), On = t.int().nonnegative(), kn = t.union([t.literal(0), t.literal(1)]), An = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("hero"),
		id: En
	}),
	t.object({
		k: t.literal("minion"),
		zone: Dn,
		team: kn
	}),
	t.object({
		k: t.literal("tower"),
		edge: t.string()
	}),
	t.object({
		k: t.literal("monster"),
		zone: Dn
	}),
	t.object({
		k: t.literal("nexus"),
		team: kn
	}),
	t.object({ k: t.literal("outsider") })
]), jn = t.union([An, t.object({
	k: t.literal("zone"),
	zone: Dn
})]), Mn = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("plan"),
		hero: En,
		card: Q.optional()
	}),
	t.object({
		type: t.literal("choosePlan"),
		use: t.enum(["normal", "fallback"])
	}),
	t.object({
		type: t.literal("move"),
		zone: Dn
	}),
	t.object({
		type: t.literal("attack"),
		targets: t.array(An).min(1),
		riderZone: Dn.optional()
	}),
	t.object({
		type: t.literal("cast"),
		card: Q,
		targets: t.array(jn)
	}),
	t.object({
		type: t.literal("channel"),
		card: Q
	}),
	t.object({
		type: t.literal("heroAction"),
		key: t.string(),
		targets: t.array(jn)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("react"),
		card: Q,
		targets: t.array(jn)
	}),
	t.object({ type: t.literal("passReact") }),
	t.object({
		type: t.literal("buy"),
		item: On,
		hero: En
	}),
	t.object({
		type: t.literal("discardItem"),
		item: On
	}),
	t.object({ type: t.literal("shopDone") }),
	t.object({
		type: t.literal("choose"),
		hero: En.optional(),
		lane: t.int().min(0).max(2).optional(),
		card: Q.optional(),
		option: t.int().min(0).max(2).optional()
	}),
	t.object({
		type: t.literal("minionAct"),
		act: t.enum([
			"assault",
			"siege",
			"advance"
		]),
		target: An.optional(),
		amount: t.int().positive().optional()
	}),
	t.object({
		type: t.literal("discard"),
		cards: t.array(Q).min(1)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), Nn = t.object({
	id: En,
	def: t.string(),
	team: kn,
	owner: t.string(),
	hp: t.int(),
	cond: t.enum([
		"ready",
		"exhausted",
		"respawning"
	]),
	out: t.boolean(),
	leveled: t.boolean(),
	zone: Dn.nullable(),
	statuses: t.array(t.string()),
	hasPlan: t.boolean(),
	planRevealed: t.object({
		mp: t.int(),
		ap: t.int(),
		name: t.string()
	}).nullable(),
	items: t.array(t.object({
		inst: On,
		item: t.string()
	})),
	attached: t.array(t.object({
		inst: Q,
		card: t.string()
	}))
}), Pn = t.object({
	k: t.string(),
	awaiting: kn.optional(),
	passed: t.array(t.string()).optional(),
	chainLen: t.int().optional(),
	desc: t.record(t.string(), t.unknown()).optional(),
	seat: t.string().optional(),
	chooseKind: t.string().optional(),
	args: t.record(t.string(), t.unknown()).optional()
}), Fn = t.object({
	hero: En,
	mp: t.int(),
	ap: t.int(),
	fast: t.boolean(),
	planned: t.boolean(),
	usedActions: t.array(t.string())
}), In = t.object({
	players: t.array(t.string()),
	teams: t.record(t.string(), kn),
	controls: t.record(t.string(), t.array(En)),
	heroes: t.array(Nn),
	towers: t.record(t.string(), kn),
	minions: t.record(t.string(), t.tuple([t.int(), t.int()])),
	jungles: t.record(t.string(), t.object({
		count: t.int(),
		topGold: t.int().nullable()
	})),
	outsider: t.object({
		zone: Dn.nullable(),
		lives: t.int(),
		hp: t.int(),
		tamed: t.boolean(),
		team: kn.nullable(),
		laneTokens: t.array(t.int())
	}),
	nexusHp: t.tuple([t.int(), t.int()]),
	gold: t.tuple([t.int(), t.int()]),
	market: t.array(t.object({
		item: t.string().nullable(),
		count: t.int(),
		top: On.nullable()
	})),
	day: t.int(),
	round: t.int(),
	priority: kn,
	phase: t.string(),
	phaseDetail: t.record(t.string(), t.unknown()).nullable(),
	turn: Fn.nullable(),
	pending: Pn.nullable(),
	planned: t.array(t.object({
		team: kn,
		hero: En
	})),
	deckCounts: t.record(t.string(), t.int()),
	discardCounts: t.record(t.string(), t.int()),
	log: t.array(t.object({
		kind: t.string(),
		hero: t.string().optional(),
		seat: t.string().optional(),
		text: t.string().optional(),
		args: t.record(t.string(), t.unknown()).optional()
	}))
}), Ln = t.array(t.object({
	what: t.string(),
	range: t.union([t.string(), t.number()]),
	optional: t.boolean().optional()
})), Rn = t.object({
	what: t.enum([
		"shop",
		"plan",
		"choosePlan",
		"turn",
		"react",
		"choose",
		"minionAct",
		"discard",
		"none"
	]),
	planHeroes: t.array(En).optional(),
	canBuy: t.array(On).optional(),
	moveZones: t.array(Dn).optional(),
	attackTargets: t.array(An).optional(),
	castable: t.array(t.object({
		inst: Q,
		targetsSpec: Ln,
		options: t.array(t.array(jn))
	})).optional(),
	heroActions: t.array(t.object({
		key: t.string(),
		label: t.string(),
		targetsSpec: Ln,
		options: t.array(t.array(jn))
	})).optional(),
	canPass: t.boolean().optional(),
	reactable: t.array(t.object({
		inst: Q,
		targetsSpec: Ln,
		options: t.array(t.array(jn))
	})).optional(),
	channelable: t.array(Q).optional(),
	chooseLanes: t.array(t.int()).optional(),
	chooseHeroes: t.array(En).optional(),
	minionActs: t.object({
		assaultTargets: t.array(An),
		canSiege: t.boolean(),
		canAdvance: t.boolean(),
		momentum: t.int()
	}).optional(),
	mustDiscard: t.int().optional(),
	chooseCards: t.array(t.object({
		inst: Q,
		card: t.string()
	})).optional(),
	args: t.record(t.string(), t.unknown()).optional()
}), zn = t.object({
	hand: t.array(t.object({
		inst: Q,
		card: t.string()
	})),
	channeled: t.array(t.object({
		inst: Q,
		card: t.string(),
		charges: t.int()
	})),
	myPlanCard: t.object({
		inst: Q,
		card: t.string()
	}).nullable(),
	act: Rn
});
//#endregion
//#region src/games/onward/rules.ts
function Bn(e, t, n) {
	let { state: r } = Ke(e, t, n);
	return {
		state: r,
		fx: []
	};
}
function Vn(e, t, n) {
	if (t.type === "tick") return {
		state: e,
		fx: []
	};
	let r = structuredClone(e);
	return kt(r, n.by, t) || (At(r), {
		state: r,
		fx: []
	});
}
function Hn(e, t) {
	let n = e.phase.k !== "shop" && e.phase.k !== "plan", r = {
		players: e.players,
		teams: e.teams,
		controls: e.controls,
		heroes: Object.entries(e.heroes).map(([t, r]) => {
			let i = r.planCard === null ? null : x[e.cardInsts[r.planCard].card];
			return {
				id: t,
				def: r.def,
				team: r.team,
				owner: r.owner,
				hp: r.hp,
				cond: r.cond,
				out: r.out,
				leveled: r.leveled,
				zone: r.zone,
				statuses: [...r.statuses],
				hasPlan: r.planCard !== null,
				planRevealed: n && i ? {
					mp: i.mp,
					ap: i.ap,
					name: i.id
				} : null,
				items: (e.equipped[t] ?? []).map((t) => ({
					inst: t,
					item: e.itemInsts[t].item
				})),
				attached: e.effects.filter((e) => e.on === t && e.cardInst !== void 0).map((t) => ({
					inst: t.cardInst,
					card: e.cardInsts[t.cardInst].card
				}))
			};
		}),
		towers: e.towers,
		minions: e.minions,
		jungles: Object.fromEntries(Object.entries(e.jungles).map(([e, t]) => [e, {
			count: t.stack.length,
			topGold: t.stack[t.stack.length - 1] ?? null
		}])),
		outsider: {
			zone: e.outsider.zone,
			lives: e.outsider.lives,
			hp: e.outsider.hp,
			tamed: e.outsider.tamed,
			team: e.outsider.tamed ? e.outsider.team ?? null : null,
			laneTokens: [...e.outsider.laneTokens]
		},
		nexusHp: [...e.nexusHp],
		gold: [...e.gold],
		market: e.market.map((t) => ({
			item: t.length > 0 ? e.itemInsts[t[t.length - 1]].item : null,
			count: t.length,
			top: t.length > 0 ? t[t.length - 1] : null
		})),
		day: e.day,
		round: e.round,
		priority: e.priority,
		phase: e.phase.k,
		phaseDetail: "queue" in e.phase ? { queue: e.phase.queue } : null,
		turn: e.turn ? {
			hero: e.turn.hero,
			mp: e.turn.mp,
			ap: e.turn.ap,
			fast: e.turn.fast,
			planned: e.turn.usedActions.includes("planChosen"),
			usedActions: [...e.turn.usedActions]
		} : null,
		pending: e.pending ? {
			k: e.pending.k,
			...e.pending.k === "react" ? {
				awaiting: e.pending.awaiting,
				passed: [...e.pending.passed],
				chainLen: e.pending.chain.length
			} : {},
			...e.pending.k === "choose" ? {
				seat: e.pending.seat,
				chooseKind: e.pending.chooseKind,
				args: e.pending.args
			} : {},
			...e.pending.k === "minionPush" ? { args: {
				lane: e.pending.lane,
				momentum: e.pending.momentum,
				team: e.pending.team
			} } : {}
		} : null,
		planned: [...e.planned],
		deckCounts: Object.fromEntries(e.players.map((t) => [t, e.decks[t].length])),
		discardCounts: Object.fromEntries(e.players.map((t) => [t, e.discards[t].length])),
		log: e.log.slice(-60)
	}, i = (e.controls[t] ?? []).find((t) => e.heroes[t].planCard !== null);
	return {
		public: r,
		private: {
			hand: (e.hands[t] ?? []).map((t) => ({
				inst: t,
				card: e.cardInsts[t].card
			})),
			channeled: Object.entries(e.channeled).map(([t, n]) => ({
				inst: Number(t),
				card: e.cardInsts[Number(t)].card,
				charges: n
			})),
			myPlanCard: i ? {
				inst: e.heroes[i].planCard,
				card: e.cardInsts[e.heroes[i].planCard].card
			} : null,
			act: cn(e, t)
		}
	};
}
function Un(e) {
	if (e.phase.k !== "over") return { phase: e.phase.k };
	let t;
	t = e.nexusHp[0] <= 0 && e.nexusHp[1] > 0 ? 1 : e.nexusHp[1] <= 0 && e.nexusHp[0] > 0 ? 0 : e.nexusHp[0] === e.nexusHp[1] ? e.priority : e.nexusHp[0] > e.nexusHp[1] ? 0 : 1;
	let n = O(t), r = e.players.filter((n) => e.teams[n] === t);
	return {
		phase: "over",
		winner: r,
		ranking: [...r, ...e.players.filter((t) => e.teams[t] === n)],
		scores: Object.fromEntries(e.players.map((t) => [t, e.nexusHp[e.teams[t]]]))
	};
}
var Wn = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ee,
	schemas: {
		action: Mn,
		publicView: In,
		privateView: zn
	},
	setup: Bn,
	reduce: Vn,
	viewFor: Hn,
	status: Un
}, Gn = {
	burn: "games.onward.stBurn",
	disarm: "games.onward.stDisarm",
	freeze: "games.onward.stFreeze",
	silence: "games.onward.stSilence",
	stun: "games.onward.stStun"
}, Kn = {
	red: "flame",
	blue: "shield",
	green: "flag",
	yellow: "move"
};
function $({ kind: e, className: t = "" }) {
	let n;
	switch (e) {
		case "sun":
			n = /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", { d: "M16 5 21 16 16 27 11 16Z" }),
				/* @__PURE__ */ f("path", {
					d: "M16 11 18.5 16 16 21 13.5 16Z",
					className: "onw-sigil-cut"
				}),
				/* @__PURE__ */ f("path", {
					d: "M16 1v3M16 28v3M1 16h3M28 16h3M5 5l3 3M24 24l3 3M27 5l-3 3M8 24l-3 3",
					fill: "none",
					strokeWidth: "2"
				})
			] });
			break;
		case "moon":
			n = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M20 3a13 13 0 1 0 9 21 12 12 0 0 1-9-21Z" }), /* @__PURE__ */ f("path", { d: "m24 19 1.4 3.5L29 24l-3.6 1.5L24 29l-1.4-3.5L19 24l3.6-1.5Z" })] });
			break;
		case "flame":
			n = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M13 30C5 25 5 18 10 11c0 5 3 6 3 6C12 10 18 8 20 2c1 6 6 10 6 17 0 7-5 11-13 11Z" }), /* @__PURE__ */ f("path", {
				d: "M15 29c-4-3-3-7 2-12 0 4 4 5 4 8 0 2-2 4-6 4Z",
				className: "onw-sigil-cut"
			})] });
			break;
		case "shield":
			n = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", { d: "M16 2 28 7v9c0 7-4 11-12 15C8 27 4 23 4 16V7Z" }), /* @__PURE__ */ f("path", {
				d: "M16 7v19",
				fill: "none",
				strokeWidth: "2.5",
				className: "onw-sigil-cut-stroke"
			})] });
			break;
		case "flag":
			n = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
				d: "M7 2v28M9 4l17 5-7 6 7 5-17-5",
				fill: "none",
				strokeWidth: "3",
				strokeLinejoin: "round"
			}), /* @__PURE__ */ f("path", { d: "M9 4v11l17 5-7-5 7-6Z" })] });
			break;
		case "move":
			n = /* @__PURE__ */ f(d, { children: /* @__PURE__ */ f("path", {
				d: "M5 27 25 7M18 5h9v9",
				fill: "none",
				strokeWidth: "4",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}) });
			break;
		case "blade":
			n = /* @__PURE__ */ f(d, { children: /* @__PURE__ */ f("path", {
				d: "M4 28 26 5l1-3-4 1L3 25l4 4 4-4M3 19l10 10",
				fill: "none",
				strokeWidth: "3",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}) });
			break;
		case "bolt":
			n = /* @__PURE__ */ f("path", { d: "M18 1 5 18h9l-2 13 15-19h-9Z" });
			break;
		case "coin": n = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("circle", {
			cx: "16",
			cy: "16",
			r: "13",
			fill: "none",
			strokeWidth: "3"
		}), /* @__PURE__ */ f("path", { d: "m16 5 6 11-6 11-6-11Z" })] });
	}
	return /* @__PURE__ */ f("svg", {
		className: `onw-sigil ${t}`,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		fill: "currentColor",
		stroke: "currentColor",
		children: n
	});
}
function qn({ pub: e }) {
	let t = c();
	return /* @__PURE__ */ p("div", {
		className: "onw-hud",
		children: [
			/* @__PURE__ */ p("div", {
				className: "onw-hud-side onw-team-sun",
				children: [/* @__PURE__ */ f("span", {
					className: "onw-crystal",
					children: /* @__PURE__ */ f($, { kind: "sun" })
				}), /* @__PURE__ */ p("span", {
					className: "onw-hud-team",
					children: [
						/* @__PURE__ */ f("strong", { children: t("games.onward.teamLight") }),
						/* @__PURE__ */ p("span", { children: [
							t("games.onward.nexus"),
							" ",
							/* @__PURE__ */ p("b", {
								className: "font-mono tabular-nums",
								children: [e.nexusHp[0], " / 9"]
							})
						] }),
						/* @__PURE__ */ f("span", {
							className: "onw-hp-pips",
							"aria-hidden": "true",
							children: Array.from({ length: 9 }, (t, n) => /* @__PURE__ */ f("i", { className: n < e.nexusHp[0] ? "is-full" : "" }, n))
						})
					]
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "onw-day-gem",
				children: [/* @__PURE__ */ f("strong", { children: t("games.onward.day", { n: e.day }) }), /* @__PURE__ */ f("small", { children: t("games.onward.round", { n: e.round }) })]
			}),
			/* @__PURE__ */ p("div", {
				className: "onw-hud-side onw-team-moon",
				children: [/* @__PURE__ */ p("span", {
					className: "onw-hud-team",
					children: [
						/* @__PURE__ */ f("strong", { children: t("games.onward.teamShadow") }),
						/* @__PURE__ */ p("span", { children: [
							t("games.onward.nexus"),
							" ",
							/* @__PURE__ */ p("b", {
								className: "font-mono tabular-nums",
								children: [e.nexusHp[1], " / 9"]
							})
						] }),
						/* @__PURE__ */ f("span", {
							className: "onw-hp-pips",
							"aria-hidden": "true",
							children: Array.from({ length: 9 }, (t, n) => /* @__PURE__ */ f("i", { className: n < e.nexusHp[1] ? "is-full" : "" }, n))
						})
					]
				}), /* @__PURE__ */ f("span", {
					className: "onw-crystal",
					children: /* @__PURE__ */ f($, { kind: "moon" })
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: `onw-priority ${e.priority === 0 ? "onw-team-sun" : "onw-team-moon"}`,
				children: [
					/* @__PURE__ */ f("i", {}),
					t("games.onward.priority"),
					" · ",
					t(e.priority === 0 ? "games.onward.teamLight" : "games.onward.teamShadow")
				]
			})
		]
	});
}
function Jn({ hero: e }) {
	let t = c();
	if (!e) return /* @__PURE__ */ f("div", { className: "onw-hero-dock is-empty" });
	let n = ce[e.def], r = e.leveled ? n?.up.ability : n?.ability, i = e.items[0] ? S[e.items[0].item] : void 0, a = t(e.cond === "ready" ? "games.onward.condReady" : e.cond === "exhausted" ? "games.onward.condExhausted" : "games.onward.condRespawning");
	return /* @__PURE__ */ p("div", {
		className: `onw-hero-dock onw-team-${e.team === 0 ? "sun" : "moon"} ${e.out ? "is-out" : ""}`,
		children: [
			/* @__PURE__ */ f("span", {
				className: "onw-hero-crest",
				children: /* @__PURE__ */ f($, { kind: Kn[n?.color ?? "red"] })
			}),
			/* @__PURE__ */ p("div", {
				className: "onw-hero-body",
				children: [
					/* @__PURE__ */ p("div", {
						className: "onw-hero-head",
						children: [/* @__PURE__ */ f("strong", { children: n?.name ?? e.def }), /* @__PURE__ */ p("span", { children: [
							n?.title ?? "",
							" · ",
							n?.cls ?? ""
						] })]
					}),
					/* @__PURE__ */ f("div", {
						className: "onw-hero-hp",
						"aria-label": `${e.hp} / 9 HP`,
						children: Array.from({ length: 9 }, (t, n) => /* @__PURE__ */ f("i", { className: n < e.hp ? "is-full" : "" }, n))
					}),
					/* @__PURE__ */ p("div", {
						className: "onw-hero-facts",
						children: [/* @__PURE__ */ p("b", { children: [
							t("games.onward.hp"),
							" ",
							e.hp,
							" / 9"
						] }), /* @__PURE__ */ p("span", { children: [a, n?.rng === "melee" ? ` · ${t("games.onward.melee")}` : ` · ${t("games.onward.ranged")}`] })]
					}),
					/* @__PURE__ */ p("div", {
						className: "onw-hero-ability",
						children: [
							/* @__PURE__ */ f($, { kind: Kn[n?.color ?? "red"] }),
							/* @__PURE__ */ f("span", { children: r?.name ?? "" }),
							e.leveled && /* @__PURE__ */ f("b", { children: t("games.onward.leveled") })
						]
					})
				]
			}),
			/* @__PURE__ */ p("div", {
				className: "onw-hero-equipment",
				title: e.items.map((e) => S[e.item]?.name ?? e.item).join(" · "),
				children: [/* @__PURE__ */ f($, { kind: i ? Kn[i.color] : "shield" }), /* @__PURE__ */ f("small", { children: i ? `${i.name}${e.items.length > 1 ? ` +${e.items.length - 1}` : ""}` : t("games.onward.equipment") })]
			}),
			e.statuses.length > 0 && /* @__PURE__ */ f("div", {
				className: "onw-hero-statuses",
				children: e.statuses.map((e) => /* @__PURE__ */ f("span", { children: t(Gn[e] ?? "games.onward.chooseOption") }, e))
			})
		]
	});
}
function Yn({ heroes: e, selected: t, prompt: n, onPick: r }) {
	let i = c();
	return /* @__PURE__ */ p("div", {
		className: "onw-hero-roster",
		children: [/* @__PURE__ */ p("div", {
			className: "onw-roster-head",
			children: [/* @__PURE__ */ f("strong", { children: i(n ? "games.onward.planPickHero" : "games.onward.condReady") }), /* @__PURE__ */ p("span", { children: [
				e.filter((e) => e.cond === "ready").length,
				" · ",
				i("games.onward.condReady")
			] })]
		}), /* @__PURE__ */ f("div", {
			className: `onw-roster-list onw-roster-count-${Math.min(4, e.length)}`,
			children: e.map((e) => {
				let n = ce[e.def];
				return /* @__PURE__ */ p("button", {
					type: "button",
					className: `onw-roster-hero onw-color-${n?.color ?? "red"} ${e.cond === "ready" ? "" : "is-tired"} ${t === e.id ? "is-selected" : ""}`,
					onClick: () => r(e.id),
					"aria-pressed": t === e.id,
					children: [
						/* @__PURE__ */ f("span", {
							className: "onw-roster-gem",
							children: /* @__PURE__ */ f($, { kind: Kn[n?.color ?? "red"] })
						}),
						/* @__PURE__ */ f("strong", { children: n?.name ?? e.def }),
						/* @__PURE__ */ p("small", { children: [
							i("games.onward.hp"),
							" ",
							e.hp
						] })
					]
				}, e.id);
			})
		})]
	});
}
function Xn({ className: e = "" }) {
	return /* @__PURE__ */ p("svg", {
		className: `onw-card-frame ${e}`,
		viewBox: "0 0 104 109",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("path", {
				d: "M2 2H94l8 8v89l-8 8H10l-8-8V10Z",
				className: "onw-card-frame-base"
			}),
			/* @__PURE__ */ f("path", {
				d: "M6 8h84l6 6v81l-6 6H14l-6-6V14Z",
				className: "onw-card-frame-line"
			}),
			/* @__PURE__ */ f("path", {
				d: "M2 19V9l8-7h16M102 19V9l-8-7H78M2 90v9l8 8h16M102 90v9l-8 8H78",
				className: "onw-card-frame-corners"
			})
		]
	});
}
function Zn() {
	let e = c();
	return /* @__PURE__ */ p("div", {
		className: "onw-card-back",
		children: [
			/* @__PURE__ */ f(Xn, {}),
			/* @__PURE__ */ f("span", {
				className: "onw-card-back-gem",
				children: /* @__PURE__ */ f($, { kind: "moon" })
			}),
			/* @__PURE__ */ f("span", { children: e("games.onward.spellDeck") })
		]
	});
}
function Qn({ cardId: e, selected: t = !1, hot: n = !1, channeled: r = !1, charges: i, onClick: a }) {
	let o = c(), s = x[e], l = ce[s?.hero ?? ""]?.color ?? "red";
	return /* @__PURE__ */ p("button", {
		type: "button",
		className: `onw-card onw-color-${l} ${t ? "is-active" : ""} ${n ? "is-hot" : ""} ${r ? "is-channeled" : ""}`,
		onClick: a,
		"aria-pressed": t,
		children: [
			/* @__PURE__ */ f(Xn, {}),
			/* @__PURE__ */ p("span", {
				className: "onw-card-top",
				children: [/* @__PURE__ */ f("strong", { children: s?.name ?? e }), /* @__PURE__ */ f("b", {
					className: "onw-card-cost font-mono tabular-nums",
					children: s?.mp ?? 0
				})]
			}),
			/* @__PURE__ */ p("span", {
				className: "onw-card-art",
				children: [/* @__PURE__ */ f("svg", {
					viewBox: "0 0 84 52",
					preserveAspectRatio: "none",
					"aria-hidden": "true",
					children: /* @__PURE__ */ f("path", { d: "M3 5h78M3 14h78M3 23h78M3 32h78M3 41h78M14 1 3 15m36-14L3 47m70-46L37 51m44-36L67 51" })
				}), /* @__PURE__ */ f("span", {
					className: "onw-card-diamond",
					children: /* @__PURE__ */ f($, { kind: Kn[l] })
				})]
			}),
			/* @__PURE__ */ p("span", {
				className: "onw-card-bottom",
				children: [
					/* @__PURE__ */ p("span", {
						className: "font-mono tabular-nums",
						children: [s?.mp ?? 0, " MP"]
					}),
					/* @__PURE__ */ p("span", {
						className: "font-mono tabular-nums",
						children: [s?.ap ?? 0, " AP"]
					}),
					/* @__PURE__ */ f("b", {
						className: "font-mono tabular-nums",
						children: s?.atk ?? "–"
					})
				]
			}),
			(s?.flags.length || r) && /* @__PURE__ */ p("span", {
				className: "onw-card-flags",
				children: [
					s?.flags.includes("r") && "⚡",
					s?.flags.includes("t") && "⌛",
					s?.flags.includes("u") && "★",
					r && ` ${o("games.onward.charges", { n: i ?? 0 })}`
				]
			})
		]
	});
}
var $n = [
	{
		key: "games.onward.marketDamage",
		color: "red",
		slots: [0, 1]
	},
	{
		key: "games.onward.marketDefense",
		color: "blue",
		slots: [4, 5]
	},
	{
		key: "games.onward.marketSpeed",
		color: "yellow",
		slots: [2, 3]
	},
	{
		key: "games.onward.marketMinions",
		color: "green",
		slots: [6, 7]
	}
], er = {
	NL: [18, 81],
	NS: [84, 13],
	JTL: [17, 18],
	JTC: [45, 21],
	JML: [20, 53],
	JMR: [74, 38],
	JBL: [53, 70],
	JBR: [83, 79],
	R1: [28, 34],
	R2: [69, 56]
}, tr = (e) => er[e] ?? [T[e].x, T[e].y];
function nr({ pub: e, act: t, myTeam: n, inspectItem: r, onPick: i }) {
	let a = c(), o = new Set(t.canBuy ?? []);
	return /* @__PURE__ */ p("div", {
		className: "onw-market",
		children: [/* @__PURE__ */ p("div", {
			className: "onw-market-header",
			children: [/* @__PURE__ */ f("strong", { children: a("games.onward.market") }), /* @__PURE__ */ p("span", { children: [
				/* @__PURE__ */ f($, { kind: "coin" }),
				" ",
				a("games.onward.gold"),
				" ",
				/* @__PURE__ */ f("b", {
					className: "font-mono tabular-nums",
					children: e.gold[n]
				})
			] })]
		}), /* @__PURE__ */ f("div", {
			className: "onw-market-shelves",
			children: $n.map((n) => /* @__PURE__ */ p("section", {
				className: `onw-market-group onw-color-${n.color}`,
				children: [/* @__PURE__ */ f("h3", { children: a(n.key) }), /* @__PURE__ */ f("div", {
					className: "onw-market-pair",
					children: n.slots.map((s) => {
						let c = e.market[s];
						if (!c?.item || c.top === null) return /* @__PURE__ */ p("div", {
							className: "onw-market-slot is-empty",
							children: [/* @__PURE__ */ f($, { kind: Kn[n.color] }), /* @__PURE__ */ f("span", { children: a("games.onward.emptyStack") })]
						}, s);
						let l = S[c.item], u = t.what === "shop" && o.has(c.top);
						return /* @__PURE__ */ p("button", {
							type: "button",
							className: `onw-market-slot ${r === c.top ? "is-active" : ""} ${u ? "is-buyable" : "is-locked"}`,
							onClick: () => i(c.top, u),
							"aria-pressed": r === c.top,
							children: [
								/* @__PURE__ */ p("svg", {
									className: "onw-market-slot-frame",
									viewBox: "0 0 172 68",
									preserveAspectRatio: "none",
									"aria-hidden": "true",
									children: [
										/* @__PURE__ */ f("path", { d: "M2 2h158l10 10v44l-10 10H12L2 56Z" }),
										/* @__PURE__ */ f("path", { d: "M7 7h150l8 8v38l-8 8H15l-8-8Z" }),
										/* @__PURE__ */ f("path", { d: "M8 4h22M142 4h20M8 64h22M142 64h20" })
									]
								}),
								/* @__PURE__ */ f("span", {
									className: "onw-market-glyph",
									children: /* @__PURE__ */ f($, { kind: Kn[n.color] })
								}),
								/* @__PURE__ */ f("strong", { children: l?.name ?? c.item }),
								/* @__PURE__ */ f("small", { children: a("games.onward.remaining", { n: c.count }) }),
								/* @__PURE__ */ f("b", {
									className: "onw-market-cost font-mono tabular-nums",
									children: l?.cost ?? 0
								})
							]
						}, s);
					})
				})]
			}, n.key))
		})]
	});
}
function rr({ pub: e, heroName: t, planHero: n, inspectHero: r, moveCand: i, zoneCand: a, candKeys: s, attackKeys: l, assaultKeys: u, chooseHeroKeys: d, planKeys: m, onZoneClick: h, onUnitClick: g }) {
	let _ = c(), [v, y] = o(1), b = /* @__PURE__ */ new Map();
	for (let t of e.heroes) {
		if (t.out || !t.zone) continue;
		let e = b.get(t.zone) ?? [];
		e.push(t), b.set(t.zone, e);
	}
	let x = (e) => s.has(e) || l.has(e) || u.has(e);
	return /* @__PURE__ */ p("div", {
		className: "onw-map-view",
		children: [/* @__PURE__ */ f("div", {
			className: "onw-map-viewport",
			children: /* @__PURE__ */ p("div", {
				className: "onw-map-canvas",
				style: { "--onw-zoom": v },
				children: [
					/* @__PURE__ */ f("img", {
						src: "./games/onward/board.webp",
						alt: "",
						draggable: !1
					}),
					/* @__PURE__ */ p("svg", {
						className: "onw-map-frame",
						viewBox: "0 0 100 100",
						preserveAspectRatio: "none",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ f("path", { d: "M1 15V2h14M85 2h13v13M1 85v13h14M85 98h13V85" }), /* @__PURE__ */ f("path", { d: "M3 10V4h7M90 4h6v6M3 90v6h7M90 96h6v-6" })]
					}),
					/* @__PURE__ */ f("span", {
						className: "onw-map-title",
						children: _("games.onward.name")
					}),
					/* @__PURE__ */ p("svg", {
						viewBox: "0 0 100 100",
						className: "onw-board",
						role: "group",
						"aria-label": _("games.onward.name"),
						children: [
							ae.filter((t) => e.towers[t.edge] !== void 0).map((t) => {
								let [n, r] = t.edge.split("|"), [i, a] = tr(n), [o, s] = tr(r), c = (i + o) / 2, l = (a + s) / 2, u = `t:${t.edge}`, d = e.towers[t.edge];
								return /* @__PURE__ */ p("g", {
									className: `onw-board-tower onw-team-${d === 0 ? "sun" : "moon"} ${x(u) ? "is-target" : ""}`,
									onClick: x(u) ? () => g({
										k: "tower",
										edge: t.edge
									}) : void 0,
									children: [
										/* @__PURE__ */ f("path", { d: `M${c} ${l - 2.1}l1.5 2.1L${c} ${l + 2.1}l-1.5-2.1Z` }),
										/* @__PURE__ */ f("path", {
											d: `M${c - 1.2} ${l}h2.4`,
											className: "onw-piece-cut"
										}),
										x(u) && /* @__PURE__ */ f("circle", {
											cx: c,
											cy: l,
											r: "6",
											className: "onw-hit"
										})
									]
								}, t.edge);
							}),
							w.filter((e) => e.kind === "nexus").map((e) => {
								let t = e.id === "NL" ? 0 : 1, [n, r] = tr(e.id);
								return /* @__PURE__ */ p("g", {
									className: `onw-board-nexus onw-team-${t === 0 ? "sun" : "moon"} ${x(`n:${t}`) ? "is-target" : ""}`,
									onClick: x(`n:${t}`) ? () => g({
										k: "nexus",
										team: t
									}) : void 0,
									children: [
										/* @__PURE__ */ f("circle", {
											cx: n,
											cy: r,
											r: "5.2"
										}),
										/* @__PURE__ */ f("path", { d: `M${n} ${r - 3.6}l2.3 3.6-2.3 3.6-2.3-3.6Z` }),
										x(`n:${t}`) && /* @__PURE__ */ f("circle", {
											cx: n,
											cy: r,
											r: "6",
											className: "onw-hit"
										})
									]
								}, e.id);
							}),
							w.map((i) => {
								let [a, o] = tr(i.id), s = e.jungles[i.id], c = e.minions[i.id];
								return /* @__PURE__ */ p("g", { children: [
									i.kind === "jungle" && /* @__PURE__ */ p("g", {
										className: `onw-jungle-marker ${s?.count ? "" : "is-empty"} ${x(`mo:${i.id}`) ? "is-target" : ""}`,
										onClick: x(`mo:${i.id}`) ? () => g({
											k: "monster",
											zone: i.id
										}) : void 0,
										children: [
											/* @__PURE__ */ f("circle", {
												cx: a,
												cy: o,
												r: "2.5"
											}),
											/* @__PURE__ */ f("text", {
												x: a,
												y: o + .9,
												children: s?.count ? s.topGold ?? s.count : "·"
											}),
											x(`mo:${i.id}`) && /* @__PURE__ */ f("circle", {
												cx: a,
												cy: o,
												r: "6",
												className: "onw-hit"
											})
										]
									}),
									c && [0, 1].map((e) => c[e] > 0 && /* @__PURE__ */ p("g", {
										className: `onw-board-minion onw-team-${e === 0 ? "sun" : "moon"} ${x(`m:${i.id}:${e}`) ? "is-target" : ""}`,
										onClick: x(`m:${i.id}:${e}`) ? () => g({
											k: "minion",
											zone: i.id,
											team: e
										}) : void 0,
										children: [
											/* @__PURE__ */ f("circle", {
												cx: a + (e === 0 ? -3 : 3),
												cy: o + 3.4,
												r: "2.7"
											}),
											/* @__PURE__ */ f("text", {
												x: a + (e === 0 ? -3 : 3),
												y: o + 4.3,
												children: c[e]
											}),
											x(`m:${i.id}:${e}`) && /* @__PURE__ */ f("circle", {
												cx: a + (e === 0 ? -3 : 3),
												cy: o + 3.4,
												r: "6",
												className: "onw-hit"
											})
										]
									}, e)),
									e.outsider.zone === i.id && /* @__PURE__ */ p("g", {
										className: `onw-board-outsider ${x("o") ? "is-target" : ""}`,
										onClick: x("o") ? () => g({ k: "outsider" }) : void 0,
										children: [
											/* @__PURE__ */ f("path", { d: `M${a} ${o - 8}l3 3-3 3-3-3Z` }),
											/* @__PURE__ */ f("text", {
												x: a,
												y: o - 4.2,
												children: e.outsider.tamed ? "★" : e.outsider.hp
											}),
											x("o") && /* @__PURE__ */ f("circle", {
												cx: a,
												cy: o - 5,
												r: "6",
												className: "onw-hit"
											})
										]
									}),
									(b.get(i.id) ?? []).map((i, s) => {
										let c = [
											[-3.5, -1.6],
											[3.5, -1.6],
											[-3.5, 4.5],
											[3.5, 4.5],
											[0, 1.5]
										], [l, u] = c[s % c.length], h = a + l, _ = o + u, v = i.id === (n ?? r ?? e.turn?.hero), y = x(`h:${i.id}`) || d.has(`h:${i.id}`) || m.has(`h:${i.id}`);
										return /* @__PURE__ */ p("g", {
											className: `onw-board-hero onw-team-${i.team === 0 ? "sun" : "moon"} ${v ? "is-selected" : ""} ${y ? "is-target" : ""} ${i.cond === "ready" ? "" : "is-tired"}`,
											onClick: () => g({
												k: "hero",
												id: i.id
											}),
											children: [
												/* @__PURE__ */ f("title", { children: t(i.id) }),
												/* @__PURE__ */ f("circle", {
													cx: h,
													cy: _,
													r: "3.7"
												}),
												/* @__PURE__ */ f("circle", {
													cx: h,
													cy: _,
													r: "2.6",
													className: "onw-hero-core"
												}),
												/* @__PURE__ */ f("text", {
													x: h,
													y: _ + .9,
													children: ce[i.def]?.name?.slice(0, 1) ?? "?"
												}),
												i.leveled && /* @__PURE__ */ f("path", {
													d: `M${h - 2} ${_ - 4.5}l2-1.5 2 1.5`,
													className: "onw-leveled-mark"
												}),
												i.statuses.length > 0 && /* @__PURE__ */ f("circle", {
													cx: h + 3.2,
													cy: _ - 3.3,
													r: "1",
													className: "onw-status-mark"
												}),
												v && /* @__PURE__ */ f("circle", {
													cx: h,
													cy: _,
													r: "4.9",
													className: "onw-selected-ring"
												}),
												/* @__PURE__ */ f("circle", {
													cx: h,
													cy: _,
													r: "5.9",
													className: "onw-hit"
												})
											]
										}, i.id);
									})
								] }, i.id);
							}),
							w.filter((e) => i.has(e.id) || a.has(e.id)).map((e) => {
								let [t, n] = tr(e.id);
								return /* @__PURE__ */ p("g", {
									className: "onw-zone-target",
									onClick: () => h(e.id),
									children: [
										/* @__PURE__ */ f("circle", {
											cx: t,
											cy: n,
											r: "5.9",
											className: "onw-target-disc"
										}),
										/* @__PURE__ */ f("path", {
											d: `M${t - 1.8} ${n + 1.8}l3.6-3.6m-2.2 0h2.2v2.2`,
											className: "onw-target-arrow"
										}),
										/* @__PURE__ */ f("circle", {
											cx: t,
											cy: n,
											r: "6",
											className: "onw-hit"
										})
									]
								}, `target-${e.id}`);
							})
						]
					})
				]
			})
		}), /* @__PURE__ */ p("div", {
			className: "onw-map-controls",
			children: [
				/* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => y((e) => Math.max(1, e - .5)),
					disabled: v === 1,
					"aria-label": _("games.onward.zoomOut"),
					children: "−"
				}),
				/* @__PURE__ */ p("span", {
					className: "font-mono tabular-nums",
					children: [Math.round(v * 100), "%"]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => y((e) => Math.min(2, e + .5)),
					disabled: v === 2,
					"aria-label": _("games.onward.zoomIn"),
					children: "+"
				})
			]
		})]
	});
}
//#endregion
//#region src/games/onward/view-player.tsx
var ir = {
	"h00.burn": "games.onward.haH00Burn",
	"h09.heal": "games.onward.haH09Heal",
	"h09.healUp": "games.onward.haH09HealUp",
	"h12.draw": "games.onward.haH12Draw",
	"h12.drawUp": "games.onward.haH12DrawUp",
	"h14.hop": "games.onward.haH14Hop",
	"h14.hopUp": "games.onward.haH14HopUp",
	"h18.dig": "games.onward.haH18Dig",
	"h18.digUp": "games.onward.haH18DigUp",
	"h22.hook": "games.onward.haH22Hook",
	"h22.hookUp": "games.onward.haH22HookUp",
	"h29.rechannel": "games.onward.haH29Rechannel",
	"i02.sting": "games.onward.haI02Sting",
	"i08.convert": "games.onward.haI08Convert",
	"i10.heal": "games.onward.haI10Heal",
	"i33.plant": "games.onward.haI33Plant"
}, ar = (e) => {
	switch (e.k) {
		case "hero": return `h:${e.id}`;
		case "minion": return `m:${e.zone}:${e.team}`;
		case "tower": return `t:${e.edge}`;
		case "monster": return `mo:${e.zone}`;
		case "nexus": return `n:${e.team}`;
		case "outsider": return "o";
		case "zone": return `z:${e.zone}`;
	}
};
function or(e) {
	return /* @__PURE__ */ f(sr, {
		pub: e.public,
		priv: e.private,
		myRid: e.myRid,
		send: e.send
	});
}
function sr({ pub: e, priv: t, myRid: n, send: r }) {
	let i = c(), a = e.phase === "over" ? { what: "none" } : t?.act ?? { what: "none" }, s = e.controls[n] ?? [], [m, h] = o(null), [g, _] = o(null), [v, y] = o(null), [b, ee] = o(null), [te, C] = o(null), [w, T] = o(null), [E, ne] = o(null), [re, ie] = o([]), ae = `${a.what}|${e.phase}|${e.turn?.hero ?? ""}|${e.round}`, [oe, D] = o(ae);
	oe !== ae && (D(ae), h(null), _(null), y(null), ee(null), C(null), T(null), ne(null), ie([]));
	let se = (t) => {
		let n = e.heroes.find((e) => e.id === t);
		return n ? ce[n.def]?.name ?? n.def : t;
	}, O = g ? Math.min(g.picked.length, Math.max(0, g.options.length - 1)) : 0, k = g && g.options.length > 0 ? g.options[O] ?? [] : [], le = new Set((g?.picked ?? []).map(ar)), ue = new Set(k.filter((e) => !le.has(ar(e))).map(ar)), A = new Set([...ue].filter((e) => e.startsWith("z:")).map((e) => e.slice(2))), j = new Set(m === "move" ? a.moveZones ?? [] : []), de = new Set((m === "attack" ? a.attackTargets ?? [] : []).map(ar)), fe = new Set(a.what === "minionAct" ? (a.minionActs?.assaultTargets ?? []).map(ar) : []), M = new Set(a.what === "choose" ? (a.chooseHeroes ?? []).map((e) => `h:${e}`) : []), pe = new Set(a.what === "plan" ? (a.planHeroes ?? []).map((e) => `h:${e}`) : []), me = (e, t) => {
		e.kind === "cast" ? r({
			type: "cast",
			card: e.inst,
			targets: t
		}) : e.kind === "react" ? r({
			type: "react",
			card: e.inst,
			targets: t
		}) : r({
			type: "heroAction",
			key: e.key,
			targets: t
		}), _(null);
	}, he = (e, t) => {
		if (t.targetsSpec.length === 0) {
			me({
				kind: e,
				inst: t.inst,
				key: t.key,
				spec: [],
				options: [],
				picked: []
			}, []);
			return;
		}
		h(null), _({
			kind: e,
			inst: t.inst,
			key: t.key,
			spec: t.targetsSpec,
			options: t.options,
			picked: []
		});
	}, N = (e) => {
		if (!g) return;
		let t = [...g.picked, e];
		t.length >= g.spec.length ? me(g, t) : _({
			...g,
			picked: t
		});
	}, P = g !== null && g.spec.slice(g.picked.length).every((e) => e.optional), F = (e) => {
		if (m === "move" && j.has(e)) {
			r({
				type: "move",
				zone: e
			}), h(null);
			return;
		}
		g && A.has(e) && N({
			k: "zone",
			zone: e
		});
	}, I = (e) => {
		let t = ar(e);
		if (a.what === "plan" && e.k === "hero" && pe.has(t)) {
			y(v === e.id ? null : e.id), T(e.id);
			return;
		}
		if (a.what === "choose" && M.has(t)) {
			r({
				type: "choose",
				hero: e.id
			});
			return;
		}
		if (fe.has(t)) {
			r({
				type: "minionAct",
				act: "assault",
				target: e
			});
			return;
		}
		if (m === "attack" && de.has(t)) {
			r({
				type: "attack",
				targets: [e]
			}), h(null);
			return;
		}
		g && ue.has(t) ? N(e) : e.k === "hero" && T(e.id);
	}, ge = (e) => {
		switch (e.k) {
			case "hero": return se(e.id);
			case "minion": return `${i("games.onward.minions")}·${e.zone}`;
			case "tower": return i("games.onward.tower");
			case "monster": return e.zone;
			case "nexus": return i("games.onward.nexus");
			case "outsider": return i("games.onward.outsider");
		}
	}, _e = new Set((a.castable ?? []).map((e) => e.inst)), ve = new Set((a.reactable ?? []).map((e) => e.inst)), ye = new Set(a.channelable ?? []), be = (e, t) => a.what === "plan" ? v !== null : a.what === "turn" || a.what === "shop" ? _e.has(e) || ye.has(e) : a.what === "react" ? ve.has(e) : a.what === "discard", xe = (e, t) => {
		if (a.what === "plan") {
			v && (r({
				type: "plan",
				hero: v,
				card: e
			}), y(null));
			return;
		}
		if (a.what === "turn" || a.what === "shop") {
			let t = (a.castable ?? []).find((t) => t.inst === e);
			t ? he("cast", t) : a.what === "shop" && ye.has(e) && r({
				type: "channel",
				card: e
			});
			return;
		}
		if (a.what === "react") {
			let t = (a.reactable ?? []).find((t) => t.inst === e);
			t && he("react", t);
			return;
		}
		a.what === "discard" && ie((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
	}, Se = a.what !== "none", Ce = (() => {
		switch (a.what) {
			case "plan": return i("games.onward.planTitle");
			case "choosePlan": return i("games.onward.choosePlanTitle");
			case "turn": return i("games.onward.yourTurn");
			case "react": return i("games.onward.reactTitle");
			case "shop": return i("games.onward.market");
			case "minionAct": return i("games.onward.minionTitle", { n: a.minionActs?.momentum ?? 0 });
			case "discard": return i("games.onward.handLimitTitle", { n: a.mustDiscard ?? 0 });
			case "choose": return a.chooseHeroes ? i("games.onward.levelUpTitle") : a.chooseLanes ? i(e.pending?.chooseKind === "outsiderToken" ? "games.onward.outsiderTokenTitle" : "games.onward.chooseLane") : a.chooseCards ? i("games.onward.chooseCard") : i("games.onward.chooseOption");
			default: return i("games.onward.waiting");
		}
	})(), we = w ?? v ?? e.turn?.hero, Te = we ? e.heroes.find((e) => e.id === we) : void 0, Ee = e.heroes.filter((e) => s.includes(e.id)), L = e.teams[n] ?? 0, R = E ? x[E.card] : void 0, De = ce[R?.hero ?? ""]?.color ?? "red", z = De === "red" ? "flame" : De === "blue" ? "shield" : De === "green" ? "flag" : "move", Oe = E ? E.channeled ? _e.has(E.inst) : be(E.inst, E.card) : !1, ke = e.market.find((e) => e.top === te), Ae = ke?.item ? S[ke.item] : void 0, je = m === "move" ? i("games.onward.pickMoveZone") : m === "attack" ? i("games.onward.pickAttackTarget") : g ? i("games.onward.pickCastTargets", {
		n: g.picked.length,
		total: g.spec.length
	}) : Ce, B = /* @__PURE__ */ p("div", {
		className: `onw-actions onw-act-${a.what}`,
		children: [
			/* @__PURE__ */ p("div", {
				className: "onw-actions-meta",
				children: [/* @__PURE__ */ f("strong", { children: je }), /* @__PURE__ */ f("span", {
					className: "font-mono tabular-nums",
					children: e.turn?.planned ? `${e.turn.mp} MP  ·  ${e.turn.ap} AP` : e.phase === "shop" ? `${i("games.onward.gold")} ${e.gold[L]}` : ""
				})]
			}),
			/* @__PURE__ */ f("div", {
				className: "onw-command-row",
				children: /* @__PURE__ */ f(cr, {
					act: a,
					t: i,
					tsel: g,
					boardMode: m,
					tselConfirmable: P,
					targetChoices: k.filter((e) => !le.has(ar(e))),
					planHero: v,
					heroName: se,
					refLabel: ge,
					handEmpty: (t?.hand.length ?? 0) === 0,
					equipItem: b,
					myHeroes: s,
					onMove: () => {
						_(null), h(m === "move" ? null : "move");
					},
					onAttack: () => {
						_(null), h(m === "attack" ? null : "attack");
					},
					onCancel: () => {
						h(null), _(null);
					},
					onConfirmTsel: () => g && me(g, g.picked),
					onTargetChoice: N,
					onZoneChoice: F,
					onAttackChoice: (e) => {
						r({
							type: "attack",
							targets: [e]
						}), h(null);
					},
					onPlanHero: (e) => {
						y(v === e ? null : e), T(e);
					},
					onHeroAction: (e) => he("heroAction", e),
					onEquipHero: (e) => {
						b !== null && (r({
							type: "buy",
							item: b,
							hero: e
						}), ee(null), C(null));
					},
					discardSel: re,
					onConfirmDiscard: () => {
						r({
							type: "discard",
							cards: re
						}), ie([]);
					},
					send: r
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "onw-hand-caption",
				children: [/* @__PURE__ */ p("span", { children: [
					i("games.onward.hand"),
					" ",
					t?.hand.length ?? 0
				] }), /* @__PURE__ */ f("i", {})]
			}),
			/* @__PURE__ */ p("div", {
				className: "onw-hand-strip",
				children: [
					t?.channeled.map((e) => /* @__PURE__ */ f(Qn, {
						cardId: e.card,
						channeled: !0,
						charges: e.charges,
						hot: _e.has(e.inst),
						selected: E?.inst === e.inst,
						onClick: () => ne({
							...e,
							channeled: !0
						})
					}, `ch-${e.inst}`)),
					t?.hand.map((e) => /* @__PURE__ */ f(Qn, {
						cardId: e.card,
						hot: be(e.inst, e.card),
						selected: E?.inst === e.inst || re.includes(e.inst),
						onClick: () => ne(e)
					}, e.inst)),
					/* @__PURE__ */ f(Zn, {})
				]
			})
		]
	});
	return /* @__PURE__ */ f("div", {
		className: "onw-shell",
		children: /* @__PURE__ */ f(l, {
			adaptive: !0,
			className: "onw-adaptive",
			scroll: !1,
			banner: /* @__PURE__ */ p("div", {
				className: "onw-banner",
				children: [/* @__PURE__ */ f(qn, { pub: e }), /* @__PURE__ */ f("div", {
					className: "onw-phase",
					children: /* @__PURE__ */ f(u, {
						tone: Se ? "accent" : "info",
						accent: "#152248",
						text: Ce
					})
				})]
			}),
			overlay: E ? /* @__PURE__ */ p("div", {
				className: "onw-detail-overlay pointer-events-auto",
				children: [
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "onw-detail-close",
						onClick: () => ne(null),
						"aria-label": i("games.onward.btnCancel"),
						children: "×"
					}),
					/* @__PURE__ */ p("div", {
						className: `onw-detail-head onw-color-${De}`,
						children: [/* @__PURE__ */ f($, { kind: z }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("strong", { children: R?.name ?? E.card }), /* @__PURE__ */ f("span", { children: R ? `${R.mp} MP  ·  ${R.ap} AP  ·  ${R.atk}` : "" })] })]
					}),
					/* @__PURE__ */ f("p", { children: R?.text ?? "" }),
					Oe && /* @__PURE__ */ f("button", {
						type: "button",
						className: "onw-detail-action",
						onClick: () => {
							if (E.channeled) {
								let e = (a.castable ?? []).find((e) => e.inst === E.inst);
								e && he("cast", e);
							} else xe(E.inst, E.card);
							ne(null);
						},
						children: a.what === "plan" ? i("games.onward.planPickCard") : a.what === "discard" ? i("games.onward.selectCard") : a.what === "shop" && ye.has(E.inst) ? i("games.onward.channel") : i("games.onward.btnCast")
					})
				]
			}) : Ae ? /* @__PURE__ */ p("div", {
				className: "onw-detail-overlay onw-item-detail pointer-events-auto",
				children: [
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "onw-detail-close",
						onClick: () => {
							C(null), ee(null);
						},
						"aria-label": i("games.onward.btnCancel"),
						children: "×"
					}),
					/* @__PURE__ */ p("div", {
						className: "onw-detail-head",
						children: [/* @__PURE__ */ f($, { kind: "coin" }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("strong", { children: Ae.name }), /* @__PURE__ */ p("span", { children: [
							i("games.onward.gold"),
							" ",
							Ae.cost,
							" · ",
							i("games.onward.remaining", { n: ke?.count ?? 0 })
						] })] })]
					}),
					/* @__PURE__ */ f("p", { children: Ae.text }),
					b !== null && /* @__PURE__ */ p("b", { children: [i("games.onward.equipTo"), " ↓"] })
				]
			}) : void 0,
			children: /* @__PURE__ */ p("div", {
				className: "onw-workspace",
				"data-shop": e.phase === "shop",
				children: [/* @__PURE__ */ f("div", {
					className: "onw-main",
					children: e.phase === "shop" ? /* @__PURE__ */ f(nr, {
						pub: e,
						act: a,
						myTeam: L,
						inspectItem: te,
						onPick: (e, t) => {
							C(e), ee(t ? e : null);
						}
					}) : /* @__PURE__ */ f(rr, {
						pub: e,
						heroName: se,
						planHero: v,
						inspectHero: w,
						moveCand: j,
						zoneCand: A,
						candKeys: ue,
						attackKeys: de,
						assaultKeys: fe,
						chooseHeroKeys: M,
						planKeys: pe,
						onZoneClick: F,
						onUnitClick: I
					})
				}), /* @__PURE__ */ p("div", {
					className: "onw-console",
					children: [e.phase !== "shop" && /* @__PURE__ */ f(d, { children: Te ? /* @__PURE__ */ f(Jn, { hero: Te }) : /* @__PURE__ */ f(Yn, {
						heroes: Ee,
						selected: v,
						prompt: a.what === "plan",
						onPick: (e) => I({
							k: "hero",
							id: e
						})
					}) }), B]
				})]
			})
		})
	});
}
function cr({ act: e, t, tsel: n, boardMode: r, tselConfirmable: i, targetChoices: a, planHero: o, heroName: s, refLabel: c, handEmpty: l, equipItem: u, myHeroes: m, discardSel: h, onMove: g, onAttack: _, onCancel: v, onConfirmTsel: y, onTargetChoice: b, onZoneChoice: ee, onAttackChoice: te, onHeroAction: S, onPlanHero: C, onEquipHero: w, onConfirmDiscard: T, send: E }) {
	if (n) return /* @__PURE__ */ p(d, { children: [
		a.map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			className: "onw-btn onw-btn-primary",
			onClick: () => b(e),
			children: e.k === "zone" ? e.zone : c(e)
		}, ar(e))),
		i && /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn onw-btn-primary",
			onClick: y,
			children: t("games.onward.btnCast")
		}),
		/* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-quiet onw-btn",
			onClick: v,
			children: t("games.onward.btnCancel")
		})
	] });
	if (r) return /* @__PURE__ */ p(d, { children: [r === "move" ? (e.moveZones ?? []).map((e) => /* @__PURE__ */ f("button", {
		type: "button",
		className: "onw-btn onw-btn-primary",
		onClick: () => ee(e),
		children: e
	}, e)) : (e.attackTargets ?? []).map((e) => /* @__PURE__ */ f("button", {
		type: "button",
		className: "onw-btn onw-btn-primary",
		onClick: () => te(e),
		children: c(e)
	}, ar(e))), /* @__PURE__ */ f("button", {
		type: "button",
		className: "btn-quiet onw-btn",
		onClick: v,
		children: t("games.onward.btnCancel")
	})] });
	switch (e.what) {
		case "plan": return /* @__PURE__ */ p(d, { children: [
			(e.planHeroes ?? []).map((e) => /* @__PURE__ */ f("button", {
				type: "button",
				className: `btn-base onw-btn ${o === e ? "onw-btn-primary" : ""}`,
				"aria-pressed": o === e,
				onClick: () => C(e),
				children: s(e)
			}, e)),
			o && l && /* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-base onw-btn onw-btn-primary",
				onClick: () => E({
					type: "plan",
					hero: o
				}),
				children: t("games.onward.planAutoCard")
			}),
			e.canPass && /* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-quiet onw-btn",
				onClick: () => E({ type: "pass" }),
				children: t("games.onward.planSkip")
			})
		] });
		case "choosePlan": return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn onw-btn-primary",
			onClick: () => E({
				type: "choosePlan",
				use: "normal"
			}),
			children: t("games.onward.usePlan")
		}), /* @__PURE__ */ p("button", {
			type: "button",
			className: "btn-quiet onw-btn",
			onClick: () => E({
				type: "choosePlan",
				use: "fallback"
			}),
			children: [
				t("games.onward.useFallback"),
				"(",
				t("games.onward.mp", { n: Number(e.args?.fallbackMp ?? 0) }),
				"/",
				t("games.onward.ap", { n: Number(e.args?.fallbackAp ?? 0) }),
				")"
			]
		})] });
		case "turn": return /* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-base onw-btn onw-btn-primary",
				disabled: (e.moveZones ?? []).length === 0,
				onClick: g,
				children: [/* @__PURE__ */ f($, { kind: "move" }), t("games.onward.btnMove")]
			}),
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-base onw-btn",
				disabled: (e.attackTargets ?? []).length === 0,
				onClick: _,
				children: t("games.onward.btnAttack")
			}),
			(e.heroActions ?? []).map((e) => /* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-base onw-btn",
				onClick: () => S(e),
				children: t(ir[e.label] ?? "games.onward.chooseOption")
			}, e.key)),
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "btn-quiet onw-btn",
				onClick: () => E({ type: "pass" }),
				children: t("games.onward.btnPass")
			})
		] });
		case "react": return /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn onw-btn-primary",
			onClick: () => E({ type: "passReact" }),
			children: t("games.onward.passReact")
		});
		case "shop": return u === null ? /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn onw-btn-primary",
			onClick: () => E({ type: "shopDone" }),
			children: t("games.onward.shopDone")
		}) : /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
			className: "onw-hint-text",
			children: t("games.onward.equipTo")
		}), m.map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn",
			onClick: () => w(e),
			children: s(e)
		}, e))] });
		case "minionAct": {
			let n = e.minionActs;
			return n ? /* @__PURE__ */ p(d, { children: [
				n.assaultTargets.map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base onw-btn onw-btn-primary",
					onClick: () => E({
						type: "minionAct",
						act: "assault",
						target: e
					}),
					children: [
						t("games.onward.assault"),
						"·",
						c(e)
					]
				}, ar(e))),
				n.canSiege && /* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-base onw-btn onw-btn-primary",
					onClick: () => E({
						type: "minionAct",
						act: "siege"
					}),
					children: t("games.onward.siege")
				}),
				n.canAdvance && /* @__PURE__ */ f("button", {
					type: "button",
					className: "btn-base onw-btn",
					onClick: () => E({
						type: "minionAct",
						act: "advance"
					}),
					children: t("games.onward.advance")
				})
			] }) : null;
		}
		case "choose": return e.chooseHeroes ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
			className: "onw-hint-text",
			children: t("games.onward.chooseHero")
		}), e.chooseHeroes.map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn onw-btn-primary",
			onClick: () => E({
				type: "choose",
				hero: e
			}),
			children: s(e)
		}, e))] }) : e.chooseLanes ? e.chooseLanes.map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn onw-btn-primary",
			onClick: () => E({
				type: "choose",
				lane: e
			}),
			children: t("games.onward.laneN", { n: e + 1 })
		}, e)) : e.chooseCards ? e.chooseCards.map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn",
			onClick: () => E({
				type: "choose",
				card: e.inst
			}),
			children: x[e.card]?.name ?? e.card
		}, e.inst)) : (Array.isArray(e.args?.validOptions) ? e.args.validOptions.map(Number) : [
			0,
			1,
			2
		]).map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn",
			onClick: () => E({
				type: "choose",
				option: e
			}),
			children: t(e === 0 ? "games.onward.c45Opt0" : e === 1 ? "games.onward.c45Opt1" : "games.onward.c45Opt2")
		}, e));
		case "discard": return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("span", {
			className: "onw-hint-text",
			children: t("games.onward.handLimitTitle", { n: e.mustDiscard ?? 0 })
		}), /* @__PURE__ */ f("button", {
			type: "button",
			className: "btn-base onw-btn onw-btn-primary",
			disabled: h.length !== (e.mustDiscard ?? 0),
			onClick: T,
			children: t("games.onward.handLimitConfirm", {
				n: h.length,
				total: e.mustDiscard ?? 0
			})
		})] });
		default: return null;
	}
}
//#endregion
//#region src/games/onward/bot.ts
function lr(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var ur = (e, t) => {
	let { public: n, private: r } = e;
	if (!r) return null;
	let i = r.act, a = (e) => ({ action: e });
	switch (i.what) {
		case "plan": {
			let e = i.planHeroes?.[0];
			if (!e) return i.canPass ? a({ type: "pass" }) : null;
			let t = r.hand[0];
			return a(t ? {
				type: "plan",
				hero: e,
				card: t.inst
			} : {
				type: "plan",
				hero: e
			});
		}
		case "choosePlan": return a({
			type: "choosePlan",
			use: r.myPlanCard ? "normal" : "fallback"
		});
		case "turn":
			for (let e of i.castable ?? []) if (e.targetsSpec.every((e) => e.optional)) return a({
				type: "cast",
				card: e.inst,
				targets: []
			});
			return (i.attackTargets ?? []).length > 0 ? a({
				type: "attack",
				targets: [lr(i.attackTargets)]
			}) : (i.moveZones ?? []).length > 0 && crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 10 < 7 ? a({
				type: "move",
				zone: lr(i.moveZones)
			}) : a({ type: "pass" });
		case "react": return a({ type: "passReact" });
		case "shop": {
			let e = i.canBuy ?? [];
			if (e.length > 0) {
				let r = n.heroes.filter((e) => e.owner === t.rid && !e.out);
				if (r.length > 0) return a({
					type: "buy",
					item: lr(e),
					hero: lr(r).id
				});
			}
			return a({ type: "shopDone" });
		}
		case "choose": {
			if (i.chooseLanes) return a({
				type: "choose",
				lane: lr(i.chooseLanes)
			});
			if (i.chooseHeroes) return a({
				type: "choose",
				hero: i.chooseHeroes[0]
			});
			let e = i.args?.mode;
			if (e === "discardPick" || e === "channelDouble") {
				let e = i.chooseCards?.[0];
				if (e !== void 0) return a({
					type: "choose",
					card: e.inst
				});
			}
			if (e === "option") {
				let e = i.args?.validOptions;
				return a({
					type: "choose",
					option: Array.isArray(e) ? Number(e[0]) : 0
				});
			}
			return a({
				type: "choose",
				option: 0
			});
		}
		case "minionAct": {
			let e = i.minionActs;
			return e ? e.assaultTargets.length > 0 ? a({
				type: "minionAct",
				act: "assault",
				target: lr(e.assaultTargets)
			}) : e.canSiege ? a({
				type: "minionAct",
				act: "siege"
			}) : e.canAdvance ? a({
				type: "minionAct",
				act: "advance"
			}) : null : null;
		}
		case "discard": {
			let e = i.mustDiscard ?? 0;
			return a({
				type: "discard",
				cards: r.hand.slice(0, e).map((e) => e.inst)
			});
		}
		default: return null;
	}
};
//#endregion
//#region src/games/onward/endgame-review.tsx
function dr({ board: e, renderResult: t, ...n }) {
	let s = c(), [l, u] = o(!0), [d, h] = o(null), v = a(null), y = a(null), b = a(null);
	r(() => {
		if (!d) return;
		b.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => h(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let x = (e) => {
		h(null), u(e), requestAnimationFrame(() => (e ? v : y).current?.focus({ preventScroll: !0 }));
	}, te = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => h({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => h({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => h({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), S = {
		...n,
		...te
	};
	return /* @__PURE__ */ p("div", {
		className: "onward-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ f("div", {
				className: "onward-endgame-board",
				inert: l,
				children: e
			}),
			/* @__PURE__ */ f("div", {
				className: "onward-endgame-overlay",
				hidden: !l,
				children: /* @__PURE__ */ p("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "onward-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ p("header", {
							className: "onward-endgame-heading",
							children: [/* @__PURE__ */ p("div", {
								className: "onward-endgame-brand",
								children: [/* @__PURE__ */ f("span", {
									"aria-hidden": "true",
									children: ee.icon
								}), s(ee.nameKey)]
							}), /* @__PURE__ */ f("button", {
								type: "button",
								ref: v,
								className: "btn-quiet",
								"aria-label": s("games.onward.reviewHide"),
								title: s("games.onward.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ f(g, { size: 19 })
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "onward-endgame-result",
							inert: d !== null,
							children: t(S)
						}),
						d && /* @__PURE__ */ p("div", {
							className: "onward-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || h(null);
							},
							children: [/* @__PURE__ */ f("button", {
								type: "button",
								ref: b,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									h(null), e();
								},
								children: s(d.label === "again" ? "games.onward.reviewConfirmAgain" : "games.onward.reviewConfirmLobby")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									h(null), v.current?.focus({ preventScroll: !0 });
								},
								children: s("games.onward.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "onward-endgame-toolbar",
				hidden: l,
				children: /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base",
					ref: y,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ f(_, { size: 18 }),
						s("games.onward.reviewShow"),
						/* @__PURE__ */ f(m, { size: 18 })
					]
				})
			})
		]
	});
}
function fr({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: u, renderRowExtra: m, summary: _, navigation: b, content: x, afterRanking: te, scoreUnit: S, rankOf: C }) {
	let w = c(), T = s((e) => e.locale), [E, ne] = o({}), re = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? v(n, T) : e;
	}, ie = (t, n) => C?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), ae = e.ranking.some((t) => e.scores?.[t] !== void 0), oe = (t, n) => /* @__PURE__ */ p("div", {
		className: "onward-score-identity",
		children: [
			/* @__PURE__ */ p("span", {
				className: "onward-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ f("span", {
					"aria-label": w("games.onward.reviewWinner"),
					children: "♛ "
				}), ae && ie(t, n)]
			}),
			/* @__PURE__ */ p("span", {
				className: "onward-score-name",
				children: [re(t), t === r && /* @__PURE__ */ f("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ p("small", {
				className: "onward-score-autopilot",
				children: [
					/* @__PURE__ */ f(h, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), D = (t) => e.ranking.map((n) => /* @__PURE__ */ f("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ p("div", {
		className: "onward-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ f(y, {}),
			b,
			/* @__PURE__ */ p("div", {
				className: "onward-score-body",
				children: [
					_ && /* @__PURE__ */ f("div", {
						className: "onward-score-summary",
						children: _
					}),
					i !== void 0 && /* @__PURE__ */ f("p", {
						className: "onward-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					x ?? (u?.length ? /* @__PURE__ */ f("div", {
						className: "onward-score-table-scroll",
						children: /* @__PURE__ */ p("table", {
							className: "onward-score-table",
							"aria-label": w(ee.nameKey),
							children: [
								/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { scope: "col" }), /* @__PURE__ */ f(d, { children: e.ranking.map((t, n) => /* @__PURE__ */ f("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: oe(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ f("tbody", { children: u.map((e, t) => /* @__PURE__ */ p(n, { children: [/* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ p("button", {
										type: "button",
										"aria-expanded": !!E[t],
										onClick: () => ne((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ f(g, { size: 15 }), e.label]
									}) : e.label
								}), D(e)] }), E[t] && e.details?.map((e, t) => /* @__PURE__ */ p("tr", {
									className: "onward-score-sub",
									children: [/* @__PURE__ */ f("th", {
										scope: "row",
										children: e.label
									}), D(e)]
								}, t))] }, t)) }),
								ae && /* @__PURE__ */ f("tfoot", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: w("games.onward.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ f("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ f("ol", {
						className: "onward-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ p("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ p("div", {
								className: "onward-score-rankline",
								children: [oe(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ p("strong", {
									className: "onward-score-points",
									children: [e.scores[t], S && /* @__PURE__ */ f("small", { children: S })]
								})]
							}), m?.(t)]
						}, t))
					})),
					te,
					!!u?.length && m && /* @__PURE__ */ f("div", {
						className: "onward-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: re(e) }), m(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ p("footer", {
				className: "onward-score-actions",
				children: [
					l && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ f("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/onward/game-over.tsx
function pr(e) {
	return /* @__PURE__ */ f(fr, {
		...e,
		accent: ee.accent
	});
}
function mr(e) {
	return /* @__PURE__ */ f(dr, {
		...e,
		board: /* @__PURE__ */ f(or, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ f(pr, { ...e })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/onward/entry.tsx
var hr = {
	definition: Wn,
	View: or,
	bot: ur,
	OverView: mr,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "王者兵线",
			desc: "MOBA 式兵线对战:派英雄推三条兵线,摧毁敌方水晶",
			rules: "目标:摧毁敌方水晶获胜;第 5 天结束时水晶耐久更高的一方获胜,平局时持有优先权的一方获胜。\n设置:\n· 每队从四种颜色中各随机获得一名英雄\n· 2 人对战各控制两名英雄;3 人时单人一方控制全部四名英雄并以 4 张手牌开局;4 人时 2 对 2\n一轮的流程:\n· 购买阶段:花金币买物品,每种颜色每轮限买一件\n· 计划阶段:抽 2 张牌,选一名战备英雄并从手牌暗置一张法术卡作为其计划卡\n· 先手英雄回合 → 小兵阶段 → 野区阶段 → 后手英雄回合\n· 全部英雄都疲劳后进入整备:疲劳恢复为战备,天数加一\n英雄回合:\n· 揭示计划卡获得移动点与行动点;也可以改用备用计划,保留计划卡但按面板数值行动\n· 移动花 1 点移动点走到相邻区域\n· 攻击花 1 点行动点,揭示牌库顶卡牌,力量等于点数与加号连锁\n· 施放法术不花点数,但部分卡牌只能在回合开始时使用\n· 敌方手牌有闪电卡时可以响应,全部跳过后逆序结算\n小兵阶段:兵力多的一队必须花掉差值\n· 优先攻袭交战区的敌人,至多花费目标耐久的兵力造成等量伤害\n· 无处可打且相邻敌方水晶时围攻水晶,否则花 1 点兵力全体推进一格\n· 防御塔与水晶会反击消灭推进的小兵\n野区阶段:每个野区里英雄较多的一队击败栈顶野怪获得金币。\n英雄耐久归零被击败,隔天复活;击败敌方英雄的队伍让一名英雄升级,获得强化面板。\n摧毁全部三座防御塔后,伤害才能打进水晶。",
			phShop: "购买阶段",
			phPlan: "计划阶段",
			phTurn: "行动回合",
			phMinions: "小兵阶段",
			phJungle: "野区阶段",
			phOnward: "整备阶段",
			phOver: "对局结束",
			day: "第 {{n}} 天",
			round: "第 {{n}} 轮",
			teamLight: "光明",
			teamShadow: "暗影",
			priority: "优先权",
			nexus: "水晶",
			gold: "金币",
			hp: "生命",
			melee: "近战",
			ranged: "远程",
			equipment: "装备",
			waiting: "等待其他玩家",
			planTitle: "选择一名战备英雄并暗置一张其法术卡",
			planPickHero: "先选择英雄",
			planPickCard: "选择计划卡",
			planAutoCard: "以抽到的牌为计划卡",
			planSkip: "跳过计划",
			choosePlanTitle: "选择计划方式",
			usePlan: "常规计划 · 弃牌",
			useFallback: "备用计划 · 留牌",
			yourTurn: "你的英雄回合",
			mp: "移动点 {{n}}",
			ap: "行动点 {{n}}",
			btnMove: "移动",
			btnAttack: "攻击",
			btnPass: "结束回合",
			btnCancel: "取消",
			btnCast: "施放",
			pickMoveZone: "选择要移动到的区域",
			pickAttackTarget: "选择攻击目标",
			pickCastTargets: "选择目标({{n}}/{{total}})",
			market: "市场",
			marketDamage: "伤害",
			marketDefense: "防御",
			marketSpeed: "速度",
			marketMinions: "兵线",
			emptyStack: "售罄",
			remaining: "余 {{n}} 张",
			spellDeck: "法术牌堆",
			selectCard: "选择此牌",
			zoomIn: "放大版图",
			zoomOut: "缩小版图",
			buy: "购买",
			equipTo: "装备给",
			shopDone: "完成购买",
			channel: "引导",
			channeled: "引导中的法术",
			charges: "充能 {{n}}",
			reactTitle: "响应窗口:打出闪电法术或跳过",
			passReact: "跳过响应",
			minionTitle: "小兵推进(剩余兵力 {{n}})",
			assault: "攻袭",
			siege: "围攻水晶",
			advance: "全体前进",
			chooseLane: "选择推进顺序",
			laneN: "{{n}} 号线",
			chooseHero: "选择英雄",
			chooseCard: "选择卡牌",
			chooseOption: "选择一项效果",
			levelUpTitle: "选择一名英雄升级",
			outsiderTokenTitle: "选择一条兵线放置界外魔标记",
			c45Opt0: "将一名待复活英雄改为战备",
			c45Opt1: "将一名今天曾被击败的疲劳英雄改为战备",
			c45Opt2: "移除一个兵线上的界外魔标记",
			handLimitTitle: "弃掉 {{n}} 张手牌",
			handLimitConfirm: "弃牌({{n}}/{{total}})",
			haH00Burn: "秋元:点燃(1 行动点)",
			haH09Heal: "歌姬:治疗 3(周围)",
			haH09HealUp: "歌姬:治疗 4(2 格)",
			haH12Draw: "布莱尔瓦:抽 1 张牌",
			haH12DrawUp: "布莱尔瓦:花 1 移动点抽 2 张牌",
			haH14Hop: "赫拉尔:野区内跳 2 格",
			haH14HopUp: "赫拉尔:跳至任意野区",
			haH18Dig: "多米斯:传送(相邻)",
			haH18DigUp: "多米斯:传送友方英雄(限两次)",
			haH22Hook: "伊萨托斯克:钩锁(2 格)",
			haH22HookUp: "伊萨托斯克:钩锁(3 格,限两次)",
			haH29Rechannel: "塞瑟鲁:重新引导弃牌堆法术",
			haI02Sting: "毒刺:1 点穿透伤害",
			haI08Convert: "转换器:1 移动点换 1 行动点",
			haI10Heal: "治疗药剂:弃置并治疗 4",
			haI33Plant: "绽放之旗:放置 1 个小兵",
			stBurn: "燃烧",
			stDisarm: "缴械",
			stFreeze: "冰冻",
			stSilence: "沉默",
			stStun: "眩晕",
			condReady: "战备",
			condExhausted: "疲劳",
			condRespawning: "待复活",
			leveled: "已升级",
			out: "离场",
			outsider: "界外魔",
			outsiderLives: "命数 {{n}}",
			outsiderTamed: "已驯服",
			tower: "防御塔",
			minions: "小兵",
			jungleGold: "野怪 {{n}} 金币",
			deckCount: "牌库 {{n}}",
			discardCount: "弃牌 {{n}}",
			hand: "手牌",
			attached: "附着",
			winnerLight: "光明队获胜",
			winnerShadow: "暗影队获胜",
			draw2: "抽 2 张牌并完成计划",
			errOver: "对局已经结束",
			errPhase: "当前阶段不能这么做",
			errNotYourPhase: "还没轮到你的队伍",
			errHeroNotReady: "该英雄不在战备状态",
			errNotYours: "这不是你控制的英雄",
			errNotInHand: "这张牌不在你的手里",
			errWrongHero: "计划卡必须属于所选英雄",
			errNoPlan: "还没有选择计划方式",
			errNoMp: "移动点不足",
			errNoAp: "行动点不足",
			errNotAdjacent: "只能移动到相邻区域",
			errCantEnter: "无法进入该区域",
			errMustApproach: "风姿绰绰:必须向肯努伊靠近",
			errD20block: "肯努伊在附近时,有剩余移动点就不能攻击",
			errNoTarget: "需要指定目标",
			errBadTarget: "目标不合法",
			errTaunt: "必须先攻击带嘲讽的单位",
			errPending: "有等待处理的响应",
			errNoSpell: "这张卡还不能施放",
			errNoCaster: "对应英雄不在场上",
			errNoCast: "该英雄本回合不能施放法术",
			errCondition: "不满足施放条件",
			errCost: "付不起额外花费",
			errNotFresh: "只能在回合开始时施放",
			errUsedAction: "这个行动本回合已经用过",
			errNoAction: "没有可用的行动",
			errNotChannelable: "这张卡只能引导后施放",
			errNotReactive: "这不是响应法术",
			errNeedHero: "需要选择英雄",
			errNeedLane: "需要选择兵线",
			errUseDiscard: "请用弃牌操作完成",
			errMustPriority: "必须按优先级花费兵力:能攻袭就必须攻袭",
			errDiscardCount: "弃牌数量不对",
			errNoItem: "没有这件物品",
			errNotOnTop: "只能购买堆顶的物品",
			errColorBought: "本轮已经买过这个颜色的物品",
			errNoGold: "金币不足",
			errHeroOut: "英雄不在场上",
			errNoValidOption: "没有可选项",
			errNeedCard: "需要选择卡牌"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Onward",
			desc: "MOBA-style lane battler: push three lanes with heroes and destroy the enemy nexus",
			rules: "Goal: destroy the enemy nexus to win. When day 5 ends, the team with more nexus HP wins; on a tie, the team holding priority wins.\nSetup:\n· Each team gets one random hero of each of the four colors\n· 2 players: each controls two heroes; 3 players: the solo side controls all four and starts with 4 cards; 4 players: 2 vs 2\nA round:\n· Shop phase: spend gold on items, at most one per color per round\n· Plan phase: draw 2 cards, pick a ready hero and set any spell card from your hand face down as its plan card\n· First hero turn → minion phase → jungle phase → second hero turn\n· When every hero is exhausted, Onward refreshes them and the day advances\nHero turn:\n· Reveal the plan card to gain its MP and AP, or use the fallback plan to keep the card and act with the panel values\n· Moving to an adjacent zone costs 1 MP\n· Attacking costs 1 AP and reveals the top cards of your deck, chaining plus signs for strength\n· Casting spells is free, though some cards can only be cast at turn start\n· Enemies holding lightning cards may respond; once everyone passes, the chain resolves in reverse order\nMinion phase: the team with more momentum must spend the difference\n· Assault enemies in the contested zone first, spending up to the target HP to deal that much damage\n· Siege the enemy nexus when adjacent and nothing can be assaulted, otherwise spend 1 momentum to advance all your minions one zone\n· Towers and the nexus retaliate by killing advancing minions\nJungle phase: in each jungle the team with more heroes defeats the top monster and takes its gold.\nA hero reduced to zero HP is defeated and respawns the next day; the team that defeated an enemy hero levels up one of their heroes.\nThe nexus can only be damaged after all three of its towers are destroyed.",
			phShop: "Shop phase",
			phPlan: "Plan phase",
			phTurn: "Hero turn",
			phMinions: "Minion phase",
			phJungle: "Jungle phase",
			phOnward: "Onward phase",
			phOver: "Game over",
			day: "Day {{n}}",
			round: "Round {{n}}",
			teamLight: "Light",
			teamShadow: "Shadow",
			priority: "Priority",
			nexus: "Nexus",
			gold: "Gold",
			hp: "HP",
			melee: "Melee",
			ranged: "Ranged",
			equipment: "Equipment",
			waiting: "Waiting for other players",
			planTitle: "Pick a ready hero and set one of their spell cards face down",
			planPickHero: "Pick a hero first",
			planPickCard: "Pick the plan card",
			planAutoCard: "Plan with the drawn card",
			planSkip: "Skip planning",
			choosePlanTitle: "Choose a plan",
			usePlan: "Normal · discard",
			useFallback: "Fallback · keep",
			yourTurn: "Your hero turn",
			mp: "MP {{n}}",
			ap: "AP {{n}}",
			btnMove: "Move",
			btnAttack: "Attack",
			btnPass: "End turn",
			btnCancel: "Cancel",
			btnCast: "Cast",
			pickMoveZone: "Pick a zone to move to",
			pickAttackTarget: "Pick an attack target",
			pickCastTargets: "Pick targets ({{n}}/{{total}})",
			market: "Market",
			marketDamage: "Damage",
			marketDefense: "Defense",
			marketSpeed: "Speed",
			marketMinions: "Minions",
			emptyStack: "Sold out",
			remaining: "{{n}} left",
			spellDeck: "Spell deck",
			selectCard: "Select card",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			buy: "Buy",
			equipTo: "Equip to",
			shopDone: "Done shopping",
			channel: "Channel",
			channeled: "Channeled spells",
			charges: "Charges {{n}}",
			reactTitle: "Response window: play a lightning spell or pass",
			passReact: "Pass",
			minionTitle: "Minion push (momentum {{n}} left)",
			assault: "Assault",
			siege: "Siege nexus",
			advance: "Advance all",
			chooseLane: "Choose push order",
			laneN: "Lane {{n}}",
			chooseHero: "Choose a hero",
			chooseCard: "Choose a card",
			chooseOption: "Choose an effect",
			levelUpTitle: "Choose a hero to level up",
			outsiderTokenTitle: "Choose a lane for the outsider token",
			c45Opt0: "Ready a respawning hero",
			c45Opt1: "Ready an exhausted hero defeated today",
			c45Opt2: "Remove an outsider token from a lane",
			handLimitTitle: "Discard {{n}} cards",
			handLimitConfirm: "Discard ({{n}}/{{total}})",
			haH00Burn: "Akimoto: ignite (1 AP)",
			haH09Heal: "Diva: heal 3 (nearby)",
			haH09HealUp: "Diva: heal 4 (2 zones)",
			haH12Draw: "Blairwa: draw 1 card",
			haH12DrawUp: "Blairwa: spend 1 MP to draw 2",
			haH14Hop: "Herald: hop 2 zones in jungle",
			haH14HopUp: "Herald: hop to any jungle",
			haH18Dig: "Domis: teleport (adjacent)",
			haH18DigUp: "Domis: teleport a friendly hero (twice)",
			haH22Hook: "Isatosk: hook (2 zones)",
			haH22HookUp: "Isatosk: hook (3 zones, twice)",
			haH29Rechannel: "Sethru: rechannel from discard",
			haI02Sting: "Sting: 1 piercing damage",
			haI08Convert: "Converter: 1 MP into 1 AP",
			haI10Heal: "Potion: discard to heal 4",
			haI33Plant: "Banner: place 1 minion",
			stBurn: "Burn",
			stDisarm: "Disarm",
			stFreeze: "Freeze",
			stSilence: "Silence",
			stStun: "Stun",
			condReady: "Ready",
			condExhausted: "Exhausted",
			condRespawning: "Respawning",
			leveled: "Leveled",
			out: "Out",
			outsider: "Outsider",
			outsiderLives: "Lives {{n}}",
			outsiderTamed: "Tamed",
			tower: "Tower",
			minions: "Minions",
			jungleGold: "Monster: {{n}} gold",
			deckCount: "Deck {{n}}",
			discardCount: "Discard {{n}}",
			hand: "Hand",
			attached: "Attached",
			winnerLight: "Light team wins",
			winnerShadow: "Shadow team wins",
			draw2: "Draw 2 cards and finish planning",
			errOver: "The game is over",
			errPhase: "Not allowed in this phase",
			errNotYourPhase: "Not your team's turn",
			errHeroNotReady: "That hero is not ready",
			errNotYours: "You do not control that hero",
			errNotInHand: "That card is not in your hand",
			errWrongHero: "The plan card must belong to the chosen hero",
			errNoPlan: "Choose a plan first",
			errNoMp: "Not enough MP",
			errNoAp: "Not enough AP",
			errNotAdjacent: "You can only move to an adjacent zone",
			errCantEnter: "Cannot enter that zone",
			errMustApproach: "Graceful Poise: you must move closer to Kenui",
			errD20block: "You cannot attack near Kenui while you have MP left",
			errNoTarget: "A target is required",
			errBadTarget: "Illegal target",
			errTaunt: "You must attack a unit with taunt first",
			errPending: "A response is still pending",
			errNoSpell: "That card cannot be cast",
			errNoCaster: "Its hero is not in play",
			errNoCast: "That hero cannot cast spells this turn",
			errCondition: "Casting condition not met",
			errCost: "Cannot pay the extra cost",
			errNotFresh: "Can only be cast at turn start",
			errUsedAction: "That action was already used this turn",
			errNoAction: "No such action available",
			errNotChannelable: "This card can only be cast from channeling",
			errNotReactive: "Not a response spell",
			errNeedHero: "Choose a hero",
			errNeedLane: "Choose a lane",
			errUseDiscard: "Use the discard action instead",
			errMustPriority: "Momentum must be spent in priority order: assault whenever possible",
			errDiscardCount: "Wrong number of discards",
			errNoItem: "No such item",
			errNotOnTop: "Only the top item of a stack can be bought",
			errColorBought: "Already bought that color this round",
			errNoGold: "Not enough gold",
			errHeroOut: "Hero is out of play",
			errNoValidOption: "No valid option",
			errNeedCard: "Choose a card"
		}
	}
};
//#endregion
export { hr as default };
