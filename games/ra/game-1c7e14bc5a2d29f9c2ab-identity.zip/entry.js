import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { IconClose as o, IconLog as s } from "@bgparty/sdk/icons";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as ee, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/ra/data.ts
var y = [
	"art",
	"religion",
	"writing",
	"agriculture",
	"astronomy"
], b = [
	"step-pyramid",
	"temple",
	"shrine",
	"mortuary",
	"statues",
	"obelisk",
	"pyramid",
	"sphinx"
], x = [
	"war",
	"funeral",
	"drought",
	"earthquake"
], S = [];
function C(e, t, n = "") {
	for (let r = 0; r < t; r++) S.push({
		id: `${e}:${n}:${r}`,
		kind: e,
		sub: n,
		art: n ? `${e}-${n}` : e
	});
}
C("ra", 30), C("pharaoh", 25), C("nile", 25), C("flood", 12), C("god", 8), C("gold", 5), y.forEach((e) => C("civ", 5, e)), b.forEach((e) => C("mon", 5, e)), x.forEach((e) => C("dis", e === "war" ? 4 : 2, e)), C("trader", 20);
var w = Object.fromEntries(S.map((e) => [e.id, e])), T = S.filter((e) => e.kind !== "trader").map((e) => e.id), E = S.filter((e) => e.kind === "trader").map((e) => e.id), D = {
	2: [[
		9,
		6,
		5,
		2
	], [
		8,
		7,
		4,
		3
	]],
	3: [
		[
			13,
			8,
			5,
			2
		],
		[
			12,
			9,
			6,
			3
		],
		[
			11,
			10,
			7,
			4
		]
	],
	4: [
		[
			13,
			6,
			2
		],
		[
			12,
			7,
			3
		],
		[
			11,
			8,
			4
		],
		[
			10,
			9,
			5
		]
	],
	5: [
		[
			16,
			7,
			2
		],
		[
			15,
			8,
			3
		],
		[
			14,
			9,
			4
		],
		[
			13,
			10,
			5
		],
		[
			12,
			11,
			6
		]
	]
}, te = {
	2: 6,
	3: 8,
	4: 9,
	5: 10
}, O = (e) => [
	"mon",
	"pharaoh",
	"nile"
].includes(w[e].kind), k = [
	"pharaoh",
	"nile",
	"flood",
	...y.map((e) => `civ-${e}`),
	...b.map((e) => `mon-${e}`),
	"god",
	"gold",
	"trader"
], A = {
	id: "ra",
	tier: "alpha",
	mechanics: [
		"auction",
		"set-collection",
		"push-your-luck"
	],
	interactionTags: [],
	nameKey: "games.ra.name",
	descKey: "games.ra.desc",
	rulesKey: "games.ra.rules",
	icon: "☀️",
	iconImg: "games/ra.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/2428089923931595212/549E4D12C018EC45AD157C4176C33C3E202212E5/" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [
		3,
		4,
		5
	],
	accent: "#c24131",
	releasedAt: "2026-11-01T13:36:00+08:00",
	search: {
		py: "tai yang shen ra",
		init: "tys ra"
	},
	hotseat: "cover"
}, j = t.object({ traders: t.boolean().default(!1) }).default({ traders: !1 }), ne = t.discriminatedUnion("type", [
	t.object({ type: t.literal("draw") }),
	t.object({ type: t.literal("invoke") }),
	t.object({
		type: t.literal("bid"),
		sun: t.int().min(1).max(16)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("god"),
		tiles: t.array(t.string()).min(1).max(8)
	}),
	t.object({
		type: t.literal("discard"),
		tile: t.string()
	}),
	t.object({ type: t.literal("continue") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), M = t.object({
	pharaoh: t.int(),
	river: t.int(),
	civilization: t.int(),
	gold: t.int(),
	gods: t.int(),
	traders: t.int(),
	monuments: t.int(),
	suns: t.int(),
	adjustment: t.int(),
	total: t.int()
}), re = t.object({
	rid: t.string(),
	suns: t.array(t.object({
		value: t.int(),
		used: t.boolean()
	})),
	tiles: t.array(t.string()),
	goods: t.int().nonnegative(),
	score: t.int().nonnegative().nullable(),
	history: t.array(M).nullable()
}), ie = t.object({
	caller: t.string(),
	reason: t.enum([
		"drawn",
		"invoked",
		"full"
	]),
	order: t.array(t.string()),
	index: t.int().nonnegative(),
	bids: t.array(t.object({
		rid: t.string(),
		sun: t.int().nullable()
	})),
	high: t.int(),
	winner: t.string().nullable()
}), ae = t.object({
	phase: t.enum([
		"play",
		"auction",
		"settle",
		"disaster",
		"scoring",
		"epoch",
		"done"
	]),
	epoch: t.int().min(1).max(3),
	players: t.array(re),
	turn: t.string(),
	market: t.array(t.string()),
	centerSun: t.int(),
	raCount: t.int(),
	raLimit: t.int(),
	bagCount: t.int(),
	traders: t.boolean(),
	auction: ie.nullable(),
	disaster: t.object({
		rid: t.string(),
		kind: t.enum([
			"war",
			"funeral",
			"drought",
			"earthquake"
		]),
		remaining: t.int()
	}).nullable(),
	last: t.object({
		kind: t.string(),
		rid: t.string(),
		tiles: t.array(t.string()),
		sun: t.int().optional(),
		departed: t.array(t.object({
			rid: t.string(),
			tile: t.string()
		})).optional()
	}).nullable(),
	scoringRid: t.string().nullable(),
	log: t.array(t.object({
		kind: t.string(),
		rid: t.string(),
		n: t.int().optional(),
		tile: t.string().optional()
	}))
}), oe = t.object({
	score: t.int(),
	history: t.array(M)
}), N = {
	draw: 520,
	ra: 850,
	bid: 420,
	award: 950,
	discard: 550,
	score: 1050
};
function se() {
	return {
		pharaoh: 0,
		river: 0,
		civilization: 0,
		gold: 0,
		gods: 0,
		traders: 0,
		monuments: 0,
		suns: 0,
		adjustment: 0,
		total: 0
	};
}
function P(e, t, n) {
	return e.tiles.filter((e) => w[e].kind === t && (n === void 0 || w[e].sub === n)).length;
}
function ce(e) {
	let t = {};
	for (let n of e) w[n].kind === "mon" && (t[w[n].sub] = (t[w[n].sub] ?? 0) + 1);
	let n = Object.keys(t).length;
	return (n === 8 ? 15 : n === 7 ? 10 : n) + Object.values(t).reduce((e, t) => e + (t >= 3 ? (t - 2) * 5 : 0), 0);
}
function le(e, t) {
	let n = e.map((e) => P(e, "pharaoh")), r = e.map((e) => e.suns.reduce((e, t) => e + t.value, 0)), i = Math.max(...n), a = Math.min(...n), o = Math.max(...r), s = Math.min(...r);
	return Object.fromEntries(e.map((e, c) => {
		let l = se(), u = P(e, "flood"), d = new Set(e.tiles.filter((e) => w[e].kind === "civ").map((e) => w[e].sub)).size;
		return l.pharaoh = i === a ? 0 : n[c] === i ? 5 : n[c] === a ? -2 : 0, l.river = u ? u + P(e, "nile") : 0, l.civilization = d === 0 ? -5 : d >= 3 ? (d - 2) * 5 : 0, l.gold = P(e, "gold") * 3, l.gods = P(e, "god") * 2, l.traders = P(e, "trader") + e.goods, t === 3 && (l.monuments = ce(e.tiles), l.suns = o === s ? 0 : r[c] === o ? 5 : r[c] === s ? -5 : 0), l.total = Object.values(l).reduce((e, t) => e + t, 0), l.adjustment = Math.max(0, -e.score - l.total), l.total += l.adjustment, [e.rid, l];
	}));
}
function ue(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; n--) {
			let a = e(r, i++, n + 1);
			[t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = a([...T, ...t.traders ? E : []]), s = a(D[n.length].map((e) => [...e])), c = n.map((e, t) => ({
		rid: e,
		suns: s[t].map((e) => ({
			value: e,
			used: !1
		})),
		tiles: [],
		goods: 0,
		score: 10,
		history: []
	}));
	return {
		state: {
			phase: "play",
			epoch: 1,
			players: c,
			turn: [...c].sort((e, t) => Math.max(...t.suns.map((e) => e.value)) - Math.max(...e.suns.map((e) => e.value)))[0].rid,
			market: [],
			centerSun: 1,
			raCount: 0,
			raLimit: te[n.length],
			bag: o,
			traders: t.traders,
			auction: null,
			disasters: [],
			disasterRid: "",
			resume: "",
			pending: null,
			beatMs: 0,
			godQueue: [],
			last: null,
			scoreIndex: 0,
			scoreSnapshot: {},
			log: [],
			rngCursor: i
		},
		fx: []
	};
}
var F = (e) => e.suns.some((e) => !e.used);
function I(e, t) {
	return e.players.find((e) => e.rid === t);
}
function L(e, t) {
	e.log.push(t);
}
function R(e, t, n) {
	e.phase = "settle", e.pending = t, e.beatMs = n;
}
function z(e) {
	if (e.auction = null, e.last = null, !e.players.some(F) || !e.bag.length) {
		fe(e);
		return;
	}
	let t = e.players.findIndex((t) => t.rid === e.resume);
	for (let n = 1; n <= e.players.length; n++) {
		let r = e.players[(t + n) % e.players.length];
		if (F(r)) {
			e.turn = r.rid, e.phase = "play", e.pending = null;
			return;
		}
	}
}
function de(e) {
	let t = e.players.findIndex((t) => t.rid === e.resume), n = Array.from({ length: e.players.length }, (n, r) => e.players[(t + r + 1) % e.players.length]).filter(F).map((e) => e.rid);
	e.auction = {
		caller: e.resume,
		reason: e.last?.kind === "ra" ? "drawn" : e.market.length === 8 ? "full" : "invoked",
		order: n,
		index: 0,
		bids: [],
		high: 0,
		winner: null
	}, e.turn = n[0], e.phase = "auction", e.pending = null;
}
function fe(e) {
	e.phase = "scoring", e.pending = null, e.auction = null, e.scoreIndex = 0, e.beatMs = N.score, e.scoreSnapshot = le(e.players, e.epoch);
}
function pe(e, t, n) {
	let r = I(e, t), i = n.filter((e) => w[e].kind === "trader").length;
	if (i) for (let n of e.players) n.rid !== t && (n.goods += i * P(n, "trader"));
	let a = n.filter((e) => w[e].kind === "dis");
	r.tiles.push(...n.filter((e) => w[e].kind !== "dis")), e.disasters = a.map((e) => ({
		kind: w[e].sub,
		remaining: 2
	})), e.disasterRid = t;
}
function B(e, t) {
	let n = t === "war" ? ["civ"] : t === "funeral" ? ["pharaoh"] : t === "earthquake" ? ["mon"] : e.some((e) => w[e].kind === "flood") ? ["flood"] : ["nile"];
	return e.filter((e) => n.includes(w[e].kind));
}
function me(e) {
	for (; e.disasters.length;) {
		let t = e.disasters[0];
		if (t.remaining > 0 && B(I(e, e.disasterRid).tiles, t.kind).length) {
			e.phase = "disaster", e.turn = e.disasterRid, e.pending = null;
			return;
		}
		e.disasters.shift();
	}
	e.godQueue.length ? R(e, "god", N.discard) : z(e);
}
function he(e) {
	let t = structuredClone(e), n = [];
	if (t.phase === "scoring") {
		if (t.scoreIndex < t.players.length) {
			let e = t.players[t.scoreIndex++], r = t.scoreSnapshot[e.rid];
			e.score += r.total, e.history.push(r), n.push({
				kind: "epochScore",
				rid: e.rid,
				data: { epoch: t.epoch }
			});
		} else t.phase = t.epoch === 3 ? "done" : "epoch", t.last = null;
		return {
			state: t,
			fx: n
		};
	}
	if (t.phase !== "settle") return {
		state: e,
		fx: n
	};
	let r = t.pending;
	if (r === "turn" && z(t), r === "auction" && de(t), r === "score" && fe(t), r === "disasters" && me(t), r === "god") {
		let e = t.godQueue.shift(), r = t.market.indexOf(e);
		t.market.splice(r, 1), pe(t, t.resume, [e]), t.last = {
			kind: "god",
			rid: t.resume,
			tiles: [e]
		}, R(t, "disasters", N.award), n.push({
			kind: "god",
			rid: t.resume,
			data: {
				tile: e,
				index: r
			}
		});
	}
	if (r === "award") {
		let e = t.auction;
		if (e.winner) {
			let r = I(t, e.winner), i = r.suns.findIndex((t) => t.value === e.high), a = r.suns[i], o = t.centerSun, s = [...t.market];
			a.value = o, a.used = !0, t.centerSun = e.high, pe(t, e.winner, s), t.market = [], t.last = {
				kind: "award",
				rid: e.winner,
				tiles: s,
				sun: o
			}, L(t, {
				kind: "award",
				rid: e.winner,
				n: s.length
			}), n.push({
				kind: "award",
				rid: e.winner,
				data: {
					tiles: s,
					sun: o,
					paid: e.high,
					paidSlot: i,
					receivedSlot: r.suns.findIndex((e) => e.value === o)
				}
			}), R(t, "disasters", N.award);
		} else {
			if (e.reason === "full") return n.push({
				kind: "clear",
				data: { tiles: [...t.market] }
			}), t.market = [], R(t, "turn", N.discard), {
				state: t,
				fx: n
			};
			z(t);
		}
	}
	return {
		state: t,
		fx: n
	};
}
function ge(e, t, n) {
	if (t.type === "tick") return he(e);
	let r = e.players.find((e) => e.rid === n.by);
	if (!r) return { code: "games.ra.errTurn" };
	if (t.type === "continue" && e.phase === "epoch") {
		let t = structuredClone(e), n = t.players.flatMap((e) => e.tiles.filter((e) => !O(e)).map((t) => ({
			rid: e.rid,
			tile: t
		}))), r = [...t.market];
		t.epoch++, t.raCount = 0, t.market = [], t.auction = null, t.last = {
			kind: "newEpoch",
			rid: "",
			tiles: [],
			departed: n
		}, t.pending = null;
		for (let e of t.players) e.tiles = e.tiles.filter(O), e.goods = 0, e.suns.forEach((e) => {
			e.used = !1;
		});
		return t.turn = [...t.players].sort((e, t) => Math.max(...t.suns.map((e) => e.value)) - Math.max(...e.suns.map((e) => e.value)))[0].rid, R(t, "turn", N.award), t.resume = t.players[(t.players.findIndex((e) => e.rid === t.turn) + t.players.length - 1) % t.players.length].rid, {
			state: t,
			fx: [{
				kind: "newEpoch",
				data: {
					epoch: t.epoch,
					discarded: n,
					market: r
				}
			}]
		};
	}
	if (n.by !== e.turn) return { code: "games.ra.errTurn" };
	if (e.phase === "play") {
		if (!F(r)) return { code: "games.ra.errTurn" };
		if (t.type === "draw") {
			if (e.market.length >= 8 || !e.bag.length) return { code: "games.ra.errDraw" };
			let t = structuredClone(e), r = t.bag.pop(), i = w[r].kind === "ra";
			return t.resume = n.by, t.last = {
				kind: i ? "ra" : "draw",
				rid: n.by,
				tiles: [r]
			}, L(t, {
				kind: i ? "ra" : "draw",
				rid: n.by,
				tile: r
			}), i ? (t.raCount++, R(t, t.raCount >= t.raLimit ? "score" : "auction", N.ra)) : (t.market.push(r), R(t, "turn", N.draw)), {
				state: t,
				fx: [{
					kind: i ? "ra" : "draw",
					rid: n.by,
					data: {
						tile: r,
						index: t.market.length - 1
					}
				}]
			};
		}
		if (t.type === "invoke") {
			let t = structuredClone(e);
			return t.resume = n.by, t.last = {
				kind: "invoke",
				rid: n.by,
				tiles: []
			}, de(t), L(t, {
				kind: "invoke",
				rid: n.by
			}), {
				state: t,
				fx: [{
					kind: "invoke",
					rid: n.by
				}]
			};
		}
		if (t.type === "god") {
			let i = new Set(t.tiles);
			if (i.size !== t.tiles.length || i.size > P(r, "god") || !i.size || t.tiles.some((t) => !e.market.includes(t) || w[t].kind === "god")) return { code: "games.ra.errGod" };
			let a = structuredClone(e), o = I(a, n.by), s = o.tiles.filter((e) => w[e].kind === "god").slice(0, i.size);
			return o.tiles = o.tiles.filter((e) => !s.includes(e)), a.resume = n.by, a.godQueue = [...t.tiles], a.last = {
				kind: "godSpend",
				rid: n.by,
				tiles: s
			}, R(a, "god", N.discard), L(a, {
				kind: "god",
				rid: n.by,
				n: i.size
			}), {
				state: a,
				fx: [{
					kind: "godSpend",
					rid: n.by,
					data: { tiles: s }
				}]
			};
		}
	}
	if (e.phase === "auction" && (t.type === "bid" || t.type === "pass")) {
		let i = e.auction;
		if (t.type === "bid" && (!r.suns.some((e) => e.value === t.sun && !e.used) || t.sun <= i.high)) return { code: "games.ra.errBid" };
		if (t.type === "pass" && i.caller === n.by && i.reason === "invoked" && !i.winner) return { code: "games.ra.errMustBid" };
		let a = structuredClone(e), o = a.auction;
		return o.bids.push({
			rid: n.by,
			sun: t.type === "bid" ? t.sun : null
		}), o.index++, t.type === "bid" && (o.high = t.sun, o.winner = n.by), o.index === o.order.length ? R(a, "award", N.bid) : a.turn = o.order[o.index], L(a, {
			kind: t.type,
			rid: n.by,
			...t.type === "bid" ? { n: t.sun } : {}
		}), {
			state: a,
			fx: [{
				kind: "bid",
				rid: n.by,
				data: { sun: t.type === "bid" ? t.sun : 0 }
			}]
		};
	}
	if (e.phase === "disaster" && t.type === "discard") {
		let i = e.disasters[0];
		if (!i || !B(r.tiles, i.kind).includes(t.tile)) return { code: "games.ra.errDiscard" };
		let a = structuredClone(e);
		return I(a, n.by).tiles = I(a, n.by).tiles.filter((e) => e !== t.tile), a.disasters[0].remaining--, a.last = {
			kind: "discard",
			rid: n.by,
			tiles: [t.tile]
		}, R(a, "disasters", N.discard), L(a, {
			kind: "discard",
			rid: n.by,
			tile: t.tile
		}), {
			state: a,
			fx: [{
				kind: "discard",
				rid: n.by,
				data: { tile: t.tile }
			}]
		};
	}
	return { code: "games.ra.errTurn" };
}
function _e(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return {
		public: {
			phase: e.phase,
			epoch: e.epoch,
			players: e.players.map((t) => ({
				rid: t.rid,
				suns: t.suns,
				tiles: t.tiles,
				goods: t.goods,
				score: e.phase === "done" ? t.score : null,
				history: e.phase === "done" ? t.history : null
			})),
			turn: e.turn,
			market: e.market,
			centerSun: e.centerSun,
			raCount: e.raCount,
			raLimit: e.raLimit,
			bagCount: e.bag.length,
			traders: e.traders,
			auction: e.auction,
			disaster: e.phase === "disaster" ? {
				rid: e.disasterRid,
				...e.disasters[0]
			} : null,
			last: e.last,
			scoringRid: e.phase === "scoring" && e.scoreIndex > 0 ? e.players[e.scoreIndex - 1].rid : null,
			log: e.log.slice(-60)
		},
		private: {
			score: n?.score ?? 0,
			history: n?.history ?? []
		}
	};
}
function ve(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((e, t) => t.score - e.score || Math.max(...t.suns.map((e) => e.value)) - Math.max(...e.suns.map((e) => e.value))).map((e) => e.rid);
	return {
		phase: "done",
		winner: [t[0]],
		ranking: t,
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.score]))
	};
}
var ye = {
	meta: A,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ne,
		publicView: ae,
		privateView: oe,
		config: j
	},
	setup: ue,
	reduce: ge,
	viewFor: _e,
	status: ve,
	nextTickIn: (e) => e.phase === "settle" || e.phase === "scoring" ? e.beatMs : null
}, V = {
	ra: "games.ra.tile.ra",
	pharaoh: "games.ra.tile.pharaoh",
	nile: "games.ra.tile.nile",
	flood: "games.ra.tile.flood",
	god: "games.ra.tile.god",
	gold: "games.ra.tile.gold",
	trader: "games.ra.tile.trader",
	civ: "games.ra.tile.civ",
	mon: "games.ra.tile.mon",
	dis: "games.ra.tile.dis",
	art: "games.ra.tile.art",
	religion: "games.ra.tile.religion",
	writing: "games.ra.tile.writing",
	agriculture: "games.ra.tile.agriculture",
	astronomy: "games.ra.tile.astronomy",
	"step-pyramid": "games.ra.tile.stepPyramid",
	temple: "games.ra.tile.temple",
	shrine: "games.ra.tile.shrine",
	mortuary: "games.ra.tile.mortuary",
	statues: "games.ra.tile.statues",
	obelisk: "games.ra.tile.obelisk",
	pyramid: "games.ra.tile.pyramid",
	sphinx: "games.ra.tile.sphinx",
	war: "games.ra.tile.war",
	funeral: "games.ra.tile.funeral",
	drought: "games.ra.tile.drought",
	earthquake: "games.ra.tile.earthquake"
};
function H(e) {
	let t = w[e];
	return V[t.sub || t.kind];
}
function U({ id: e, art: t, label: n = !0 }) {
	let r = a(), i = e ? w[e] : void 0;
	return /* @__PURE__ */ p("img", {
		className: "ra-tile-face",
		src: `games/ra/${t ?? i?.art}.svg`,
		alt: n && e ? r(H(e)) : "",
		draggable: !1
	});
}
function W({ value: e, used: t = !1 }) {
	let n = a();
	return /* @__PURE__ */ m("span", {
		className: "ra-sun-face",
		"data-used": t,
		children: [/* @__PURE__ */ p("img", {
			src: `games/ra/sun-${e}.svg`,
			alt: n(t ? "games.ra.usedSun" : "games.ra.sun", { n: e }),
			draggable: !1
		}), t && /* @__PURE__ */ p("span", {
			className: "ra-sun-slash",
			"aria-hidden": !0
		})]
	});
}
function G() {
	return /* @__PURE__ */ p("svg", {
		className: "ra-target-line",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ p("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "9",
			fill: "none",
			stroke: "#fff3af",
			strokeWidth: "2",
			strokeDasharray: "7 5",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ p("animate", {
				attributeName: "stroke-dashoffset",
				from: "24",
				to: "0",
				dur: ".9s",
				repeatCount: "indefinite"
			})
		})
	});
}
function be() {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 100 100",
		className: "ra-bag-art",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ p("path", {
				d: "M31 13Q50 21 69 13L64 31Q89 51 86 78Q82 94 50 94Q18 94 14 78Q11 51 36 31Z",
				fill: "#34556c",
				stroke: "#e8d89b",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ p("path", {
				d: "M33 30Q50 36 67 30M27 68Q50 83 73 68",
				fill: "none",
				stroke: "#e8d89b",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ p("path", {
				d: "M50 40L62 57 50 74 38 57Z",
				fill: "#e1a841"
			}),
			/* @__PURE__ */ p("path", {
				d: "M35 16L41 29M50 19V30M65 16L59 29",
				stroke: "#263e47",
				strokeWidth: "2"
			})
		]
	});
}
//#endregion
//#region src/games/ra/score-table.tsx
var xe = {
	pharaoh: "games.ra.tile.pharaoh",
	river: "games.ra.tile.nile",
	civilization: "games.ra.tile.civ",
	gold: "games.ra.tile.gold",
	gods: "games.ra.tile.god",
	traders: "games.ra.tile.trader",
	monuments: "games.ra.tile.mon",
	suns: "games.ra.suns",
	adjustment: "games.ra.adjustment",
	total: "games.ra.total"
};
function Se({ players: e, nameOf: t }) {
	let n = a(), [r, o] = i(null);
	return /* @__PURE__ */ p("div", {
		className: "ra-score-details",
		children: /* @__PURE__ */ p("div", {
			className: "ra-score-scroll",
			children: /* @__PURE__ */ m("table", {
				className: "ra-score-table",
				children: [/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {}), /* @__PURE__ */ p(f, { children: e.map((e) => /* @__PURE__ */ p("th", {
					scope: "col",
					children: t(e.rid)
				}, e.rid)) })] }) }), /* @__PURE__ */ m("tbody", { children: [
					/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
						scope: "row",
						children: n("games.ra.initial")
					}), e.map((e) => /* @__PURE__ */ p("td", { children: "10" }, e.rid))] }),
					[
						0,
						1,
						2
					].map((t) => /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
						scope: "row",
						children: /* @__PURE__ */ m("button", {
							type: "button",
							"aria-expanded": r === t,
							onClick: () => o(r === t ? null : t),
							children: [n("games.ra.epoch", { n: t + 1 }), /* @__PURE__ */ p("span", {
								"aria-hidden": !0,
								children: r === t ? " −" : " +"
							})]
						})
					}), e.map((e) => /* @__PURE__ */ p("td", { children: e.history?.[t]?.total ?? "—" }, e.rid))] }, t)),
					r !== null && /* @__PURE__ */ p("tr", { children: /* @__PURE__ */ p("td", {
						colSpan: e.length + 1,
						className: "ra-score-nested",
						children: /* @__PURE__ */ m("table", {
							className: "ra-score-table",
							children: [/* @__PURE__ */ p("caption", { children: n("games.ra.epochDetail", { n: r + 1 }) }), /* @__PURE__ */ p("tbody", { children: Object.keys(xe).filter((t) => t !== "total" && (r === 2 || t !== "suns" && t !== "monuments") && e.some((e) => (e.history?.[r]?.[t] ?? 0) !== 0)).map((t) => /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
								scope: "row",
								children: n(xe[t])
							}), e.map((e) => /* @__PURE__ */ p("td", { children: e.history?.[r]?.[t] ?? "—" }, e.rid))] }, t)) })]
						})
					}) }),
					/* @__PURE__ */ m("tr", {
						className: "ra-score-total",
						children: [/* @__PURE__ */ p("th", {
							scope: "row",
							children: n("games.ra.total")
						}), e.map((e) => /* @__PURE__ */ p("td", { children: e.score ?? "—" }, e.rid))]
					}),
					/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
						scope: "row",
						children: n("games.ra.sunTotal")
					}), e.map((e) => /* @__PURE__ */ p("td", { children: e.suns.reduce((e, t) => e + t.value, 0) }, e.rid))] })
				] })]
			})
		})
	});
}
//#endregion
//#region src/games/ra/dialog.tsx
function Ce({ open: e = !0, className: t, label: i, onClose: a, children: o }) {
	let s = r(null);
	return n(() => {
		let t = s.current;
		t && (e && !t.open && t.showModal(), !e && t.open && t.close());
	}, [e]), /* @__PURE__ */ p("dialog", {
		ref: s,
		className: t,
		"aria-label": i,
		onCancel: (e) => {
			e.preventDefault(), a();
		},
		children: o
	});
}
//#endregion
//#region src/games/ra/player-panel.tsx
var K = {
	ra: "games.ra.tileRule.ra",
	pharaoh: "games.ra.tileRule.pharaoh",
	nile: "games.ra.tileRule.river",
	flood: "games.ra.tileRule.river",
	civ: "games.ra.tileRule.civilization",
	mon: "games.ra.tileRule.monuments",
	gold: "games.ra.tileRule.gold",
	god: "games.ra.tileRule.gods",
	trader: "games.ra.tileRule.traders",
	dis: "games.ra.tileRule.disaster"
};
function we({ id: e }) {
	let t = a(), n = w[e];
	return /* @__PURE__ */ m("div", {
		className: "ra-tile-scoring",
		children: [/* @__PURE__ */ p("p", { children: t(K[n.kind]) }), !["ra", "dis"].includes(n.kind) && /* @__PURE__ */ p("p", {
			className: "ra-panel-note",
			children: t(O(e) ? "games.ra.keepTile" : "games.ra.clearTile")
		})]
	});
}
function Te({ pub: e, owner: t, privateView: n }) {
	let r = a(), i = (e) => t.tiles.filter((t) => w[t].kind === e).length, o = (e) => new Set(t.tiles.filter((t) => w[t].kind === e).map((e) => w[e].sub)).size, s = n && ![
		"scoring",
		"epoch",
		"done"
	].includes(e.phase) ? le(e.players.map((e) => ({
		...e,
		score: e.rid === t.rid ? n.score : 0
	})), e.epoch)[t.rid] : null, c = [
		{
			key: "pharaoh",
			art: "pharaoh",
			label: V.pharaoh,
			amount: r("games.ra.tileAmount", { n: i("pharaoh") }),
			rule: K.pharaoh
		},
		{
			key: "river",
			art: "nile",
			label: "games.ra.river",
			amount: r("games.ra.riverAmount", {
				nile: i("nile"),
				flood: i("flood")
			}),
			rule: K.nile
		},
		{
			key: "civilization",
			art: "civ-art",
			label: V.civ,
			amount: r("games.ra.typeAmount", {
				n: i("civ"),
				types: o("civ")
			}),
			rule: K.civ
		},
		{
			key: "monuments",
			art: "mon-pyramid",
			label: V.mon,
			amount: r("games.ra.typeAmount", {
				n: i("mon"),
				types: o("mon")
			}),
			rule: K.mon,
			finalOnly: !0
		},
		{
			key: "gold",
			art: "gold",
			label: V.gold,
			amount: r("games.ra.tileAmount", { n: i("gold") }),
			rule: K.gold
		},
		{
			key: "gods",
			art: "god",
			label: V.god,
			amount: r("games.ra.tileAmount", { n: i("god") }),
			rule: K.god
		},
		...e.traders ? [{
			key: "traders",
			art: "trader",
			label: V.trader,
			amount: r("games.ra.traderAmount", {
				n: i("trader"),
				goods: t.goods
			}),
			rule: K.trader
		}] : [],
		{
			key: "suns",
			label: "games.ra.suns",
			amount: r("games.ra.sunAmount", {
				available: t.suns.filter((e) => !e.used).length,
				n: t.suns.length,
				total: t.suns.reduce((e, t) => e + t.value, 0)
			}),
			rule: "games.ra.tileRule.suns",
			finalOnly: !0
		}
	];
	return /* @__PURE__ */ m("div", {
		className: "ra-player-panel",
		children: [
			n && /* @__PURE__ */ m("div", {
				className: "ra-panel-summary",
				children: [/* @__PURE__ */ p("span", { children: r("games.ra.score", { n: n.score }) }), s && /* @__PURE__ */ p("strong", { children: r("games.ra.epochEstimate", {
					n: e.epoch,
					score: Ee(s.total)
				}) })]
			}),
			s && /* @__PURE__ */ p("p", {
				className: "ra-panel-note",
				children: r("games.ra.estimateNote")
			}),
			/* @__PURE__ */ p("div", {
				className: "ra-panel-rows",
				children: c.map((n) => /* @__PURE__ */ m("section", {
					className: "ra-panel-row",
					children: [n.art && /* @__PURE__ */ p("div", {
						className: "ra-panel-art",
						children: /* @__PURE__ */ p(U, {
							art: n.art,
							label: !1
						})
					}), /* @__PURE__ */ m("div", {
						className: "ra-panel-row-content",
						children: [
							/* @__PURE__ */ m("div", {
								className: "ra-panel-row-title",
								children: [/* @__PURE__ */ p("h3", { children: r(n.label) }), s && /* @__PURE__ */ p("strong", { children: n.finalOnly && e.epoch < 3 ? r("games.ra.finalOnly") : r("games.ra.pointChange", { n: Ee(s[n.key]) }) })]
							}),
							/* @__PURE__ */ p("p", {
								className: "ra-panel-amount",
								children: n.amount
							}),
							(n.key === "civilization" || n.key === "monuments") && /* @__PURE__ */ p("p", {
								className: "ra-panel-types",
								children: [...new Set(t.tiles.filter((e) => w[e].kind === (n.key === "civilization" ? "civ" : "mon")).map((e) => w[e].art))].map((e) => {
									let n = t.tiles.filter((t) => w[t].art === e);
									return /* @__PURE__ */ m("span", { children: [
										r(H(n[0])),
										" × ",
										n.length
									] }, e);
								})
							}),
							/* @__PURE__ */ p("p", {
								className: "ra-panel-rule",
								children: r(n.rule)
							})
						]
					})]
				}, n.key))
			}),
			s && s.adjustment > 0 && /* @__PURE__ */ p("p", { children: r("games.ra.floorEstimate", { n: s.adjustment }) })
		]
	});
}
function Ee(e) {
	return e > 0 ? `+${e}` : String(e);
}
//#endregion
//#region src/games/ra/view-player.tsx
function De(e) {
	let t = e.public, n = e.private, r = a(), [u, h] = i(e.myRid), [g, _] = i(!1), [ee, v] = i([]), [y, b] = i(null), x = t.turn === e.myRid, S = t.phase === "play" && x, C = t.players.find((t) => t.rid === e.myRid), T = C?.tiles.filter((e) => w[e].kind === "god").length ?? 0, E = S && g && T > 0, D = E ? ee.filter((e) => t.market.includes(e)) : [], te = t.phase === "disaster" && x || t.phase === "settle" && t.last?.kind === "discard" && t.last.rid === e.myRid ? e.myRid : u, O = t.players.find((e) => e.rid === te) ?? t.players[0], k = (t) => e.members.find((e) => e.rid === t)?.name ?? t, A = (t) => {
		e.send(t), _(!1), v([]);
	}, j = t.phase === "auction" && x && !(t.auction?.reason === "invoked" && t.auction.caller === e.myRid && !t.auction.winner), ne = t.phase === "done" ? "" : E ? r("games.ra.godPrompt") : t.phase === "disaster" && t.disaster ? x ? r("games.ra.disasterPrompt", {
		kind: r(V[t.disaster.kind]),
		n: t.disaster.remaining
	}) : r("games.ra.waitingDisaster", {
		name: k(t.turn),
		kind: r(V[t.disaster.kind])
	}) : t.phase === "auction" ? r(x ? "games.ra.yourBid" : "games.ra.bidding", { name: k(t.turn) }) : t.phase === "play" ? r(x ? "games.ra.yourTurn" : "games.ra.turn", { name: k(t.turn) }) : t.phase === "scoring" ? r("games.ra.scoring") : t.phase === "epoch" ? r("games.ra.epochEnd", { n: t.epoch }) : r("games.ra.settling"), { ref: M } = c("ra-track"), { ref: re, hidden: ie } = c("center"), { ref: ae } = c("bag"), { ref: oe } = c("discard"), N = y && y !== "log" && y !== "score" && y !== "panel" ? y : null, se = N ? r(H(N)) : y === "panel" ? r("games.ra.playerPanelTitle", { name: k(O.rid) }) : r(y === "log" ? "games.ra.log" : "games.ra.scoreDetail"), P = {
		draw: "games.ra.logDraw",
		ra: "games.ra.logRa",
		invoke: "games.ra.logInvoke",
		bid: "games.ra.logBid",
		pass: "games.ra.logPass",
		award: "games.ra.logAward",
		god: "games.ra.logGod",
		discard: "games.ra.logDiscard"
	}, ce = (e, t) => t === 1 && e === "award" ? "games.ra.logAwardOne" : t === 1 && e === "god" ? "games.ra.logGodOne" : P[e] ?? "games.ra.logInvoke";
	return /* @__PURE__ */ m("div", {
		className: "ra-screen",
		children: [/* @__PURE__ */ p("div", {
			className: "ra-screen-inner",
			inert: y !== null,
			children: /* @__PURE__ */ p(d, {
				adaptive: !0,
				scroll: !1,
				banner: /* @__PURE__ */ m("div", {
					className: "ra-header",
					children: [
						/* @__PURE__ */ m("div", {
							className: "ra-epoch",
							children: [/* @__PURE__ */ p("b", {
								className: "ra-brand",
								"aria-hidden": !0,
								children: "RA"
							}), /* @__PURE__ */ p("span", { children: r("games.ra.epoch", { n: t.epoch }) })]
						}),
						/* @__PURE__ */ p("div", {
							className: "ra-voyage",
							"aria-label": `${t.raCount} / ${t.raLimit}`,
							children: Array.from({ length: t.raLimit + 1 }, (e, n) => /* @__PURE__ */ p("span", {
								className: "ra-step",
								ref: n === t.raCount ? M : void 0,
								"data-reached": n <= t.raCount,
								children: n === t.raCount ? /* @__PURE__ */ p("img", {
									src: "games/ra/sunboat.svg",
									alt: "",
									draggable: !1
								}) : n
							}, n))
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "ra-icon-button",
							"aria-label": r("games.ra.log"),
							onClick: () => b("log"),
							children: /* @__PURE__ */ p(s, { size: 21 })
						})
					]
				}),
				actionsHeight: "ra-seats-height",
				actions: /* @__PURE__ */ p("div", {
					className: "ra-seats",
					children: t.players.map((n) => /* @__PURE__ */ p(Oe, {
						p: n,
						members: e.members,
						name: k(n.rid),
						inspected: O.rid === n.rid,
						turn: t.turn === n.rid && (t.phase === "auction" || t.phase === "play" || t.phase === "disaster"),
						bidding: t.phase === "auction" && x && n.rid === e.myRid,
						high: t.auction?.high ?? 0,
						bid: t.auction?.bids.find((e) => e.rid === n.rid)?.sun,
						onInspect: () => h(n.rid),
						send: A
					}, n.rid))
				}),
				children: /* @__PURE__ */ m("div", {
					className: "ra-stage",
					children: [/* @__PURE__ */ m("section", {
						className: "ra-auction-area",
						children: [
							/* @__PURE__ */ m("div", {
								className: "ra-phase",
								children: [/* @__PURE__ */ p("strong", { children: ne }), /* @__PURE__ */ p("span", { children: t.auction && r("games.ra.high", { n: t.auction.high }) })]
							}),
							/* @__PURE__ */ p("div", {
								className: "ra-market",
								children: Array.from({ length: 8 }, (e, n) => /* @__PURE__ */ p(Ae, {
									index: n,
									id: t.market[n],
									selected: D.indexOf(t.market[n]),
									legal: E && !!t.market[n] && w[t.market[n]].kind !== "god" && (D.includes(t.market[n]) || D.length < T),
									onClick: () => {
										let e = t.market[n];
										if (E) {
											if (w[e].kind === "god" || !D.includes(e) && D.length >= T) return;
											v(D.includes(e) ? D.filter((t) => t !== e) : [...D, e]);
										} else e && b(e);
									}
								}, n))
							}),
							/* @__PURE__ */ m("div", {
								className: "ra-tools",
								children: [
									/* @__PURE__ */ m("button", {
										ref: ae,
										type: "button",
										className: "ra-bag",
										disabled: !S || E || t.market.length === 8,
										onClick: () => A({ type: "draw" }),
										"aria-label": r("games.ra.draw"),
										title: r(t.bagCount === 1 ? "games.ra.bagOne" : "games.ra.bag", { n: t.bagCount }),
										children: [/* @__PURE__ */ p(be, {}), /* @__PURE__ */ p("span", { children: r("games.ra.draw") })]
									}),
									/* @__PURE__ */ m("span", {
										className: "ra-center",
										children: [/* @__PURE__ */ p("span", {
											ref: re,
											className: "ra-center-sun",
											style: { visibility: ie ? "hidden" : void 0 },
											children: /* @__PURE__ */ p(W, { value: t.centerSun })
										}), /* @__PURE__ */ p("small", { children: r("games.ra.center") })]
									}),
									/* @__PURE__ */ p("div", {
										className: "ra-actions",
										children: E ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
											type: "button",
											className: "ra-button ra-button-gold",
											disabled: !D.length,
											onClick: () => A({
												type: "god",
												tiles: D
											}),
											children: r(D.length === 1 ? "games.ra.godConfirmOne" : "games.ra.godConfirm", { n: D.length })
										}), /* @__PURE__ */ p("button", {
											type: "button",
											className: "ra-button",
											onClick: () => {
												_(!1), v([]);
											},
											children: r("games.ra.cancel")
										})] }) : t.phase === "epoch" ? /* @__PURE__ */ p("button", {
											type: "button",
											className: "ra-button ra-button-gold",
											onClick: () => A({ type: "continue" }),
											children: r("games.ra.nextEpoch")
										}) : t.phase === "auction" ? /* @__PURE__ */ p("button", {
											type: "button",
											className: "ra-button",
											disabled: !j,
											onClick: () => A({ type: "pass" }),
											children: r("games.ra.pass")
										}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
											type: "button",
											className: "ra-button ra-button-red",
											disabled: !S,
											onClick: () => A({ type: "invoke" }),
											children: r("games.ra.invoke")
										}), /* @__PURE__ */ p("button", {
											type: "button",
											className: "ra-button",
											disabled: !S || !T || !t.market.some((e) => w[e].kind !== "god"),
											onClick: () => {
												_(!0), v([]);
											},
											children: r("games.ra.useGod")
										})] })
									}),
									/* @__PURE__ */ p("span", {
										className: "ra-discard",
										ref: oe,
										"aria-hidden": !0
									})
								]
							})
						]
					}), /* @__PURE__ */ m("section", {
						className: "ra-collection",
						children: [/* @__PURE__ */ m("div", {
							className: "ra-collection-heading",
							children: [/* @__PURE__ */ p("h2", { children: r("games.ra.collection", { name: k(O.rid) }) }), /* @__PURE__ */ m("div", {
								className: "ra-collection-buttons",
								children: [/* @__PURE__ */ p("button", {
									type: "button",
									className: "ra-score-button",
									onClick: () => b("panel"),
									children: r("games.ra.playerPanel")
								}), n && O.rid === e.myRid && /* @__PURE__ */ m("button", {
									type: "button",
									className: "ra-score-button",
									onClick: () => b("score"),
									children: [/* @__PURE__ */ p(l, { value: n.score }), r("games.ra.scoreDetail")]
								})]
							})]
						}), /* @__PURE__ */ p(je, {
							pub: t,
							owner: O,
							myRid: e.myRid,
							send: A,
							inspect: (e) => b(e)
						})]
					})]
				})
			})
		}), y && /* @__PURE__ */ p("div", {
			className: "ra-modal-shade",
			onClick: (e) => {
				e.target === e.currentTarget && b(null);
			},
			children: /* @__PURE__ */ m(Ce, {
				className: "ra-modal",
				label: se,
				onClose: () => b(null),
				children: [/* @__PURE__ */ m("div", {
					className: "ra-modal-heading",
					children: [/* @__PURE__ */ p("h2", { children: se }), /* @__PURE__ */ p("button", {
						type: "button",
						className: "ra-icon-button",
						"aria-label": r("games.ra.close"),
						onClick: () => b(null),
						children: /* @__PURE__ */ p(o, { size: 22 })
					})]
				}), /* @__PURE__ */ p("div", {
					className: "ra-modal-content",
					children: N ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(U, { id: N }), /* @__PURE__ */ p(we, { id: N })] }) : y === "panel" ? /* @__PURE__ */ p(Te, {
						pub: t,
						owner: O,
						privateView: O.rid === e.myRid ? n : void 0
					}) : y === "log" ? /* @__PURE__ */ p("ol", {
						className: "ra-log",
						children: t.log.map((e, t) => /* @__PURE__ */ p("li", { children: r(ce(e.kind, e.n), {
							name: k(e.rid),
							n: e.n ?? 0,
							tile: e.tile ? r(H(e.tile)) : ""
						}) }, t))
					}) : n && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("p", { children: r("games.ra.score", { n: n.score }) }), /* @__PURE__ */ p(Se, {
						players: [{
							...C,
							score: n.score,
							history: n.history
						}],
						nameOf: k
					})] })
				})]
			})
		})]
	});
}
function Oe({ p: e, name: t, members: n, inspected: r, turn: i, bidding: o, high: s, bid: l, onInspect: d, send: f }) {
	let h = a(), g = n.find((t) => t.rid === e.rid), { ref: _ } = c(`seat:${e.rid}`);
	return /* @__PURE__ */ m("div", {
		ref: _,
		className: "ra-seat",
		"data-turn": i,
		"data-inspected": r,
		style: { "--ra-player": u[(g?.colorIndex ?? 0) % u.length].hex },
		children: [/* @__PURE__ */ m("button", {
			type: "button",
			className: "ra-seat-name",
			"aria-label": h("games.ra.inspect", { name: t }),
			"aria-pressed": r,
			onClick: d,
			children: [
				/* @__PURE__ */ p("span", { className: "ra-player-dot" }),
				t,
				l !== void 0 && /* @__PURE__ */ p("small", { children: l === null ? h("games.ra.pass") : l })
			]
		}), /* @__PURE__ */ p("div", {
			className: "ra-seat-suns",
			children: e.suns.map((t, n) => /* @__PURE__ */ p(ke, {
				rid: e.rid,
				index: n,
				value: t.value,
				used: t.used,
				legal: o && !t.used && t.value > s,
				onClick: () => f({
					type: "bid",
					sun: t.value
				})
			}, n))
		})]
	});
}
function ke({ rid: e, index: t, value: n, used: r, legal: i, onClick: o }) {
	let s = a(), { ref: l, hidden: u } = c(`sun-slot:${e}:${t}`);
	return /* @__PURE__ */ m("button", {
		ref: l,
		type: "button",
		className: "ra-sun-button",
		disabled: !i,
		"aria-label": s(i ? "games.ra.bidAria" : r ? "games.ra.usedSun" : "games.ra.sun", { n }),
		onClick: o,
		style: { visibility: u ? "hidden" : void 0 },
		children: [/* @__PURE__ */ p(W, {
			value: n,
			used: r
		}), i && /* @__PURE__ */ p(G, {})]
	});
}
function Ae({ index: e, id: t, selected: n, legal: r, onClick: i }) {
	let o = a(), { ref: s, hidden: l } = c(`market:${e}`);
	return /* @__PURE__ */ m("button", {
		ref: s,
		type: "button",
		className: "ra-market-slot",
		"aria-label": t ? o("games.ra.selectTile", { name: o(H(t)) }) : o("games.ra.slot", { n: e + 1 }),
		"aria-pressed": n >= 0,
		disabled: !t,
		onClick: i,
		"data-selected": n >= 0,
		children: [
			t && /* @__PURE__ */ p("span", {
				className: "ra-market-face",
				style: { visibility: l ? "hidden" : void 0 },
				children: /* @__PURE__ */ p(U, { id: t })
			}),
			r && /* @__PURE__ */ p(G, {}),
			n >= 0 && /* @__PURE__ */ p("span", {
				className: "ra-order",
				"aria-label": o("games.ra.selectedOrder", { n: n + 1 }),
				children: n + 1
			})
		]
	});
}
function je({ pub: e, owner: t, myRid: n, send: r, inspect: i }) {
	let o = a(), s = /* @__PURE__ */ new Map();
	t.tiles.forEach((e) => {
		let t = w[e].art;
		s.set(t, [...s.get(t) ?? [], e]);
	});
	let c = e.phase === "settle" && e.last?.kind === "newEpoch" ? e.last.departed?.filter((e) => e.rid === t.rid).map((e) => e.tile) ?? [] : e.phase === "settle" && e.last?.rid === t.rid && ["discard", "godSpend"].includes(e.last.kind) ? e.last.tiles : [];
	for (let e of c) s.has(w[e].art) || s.set(w[e].art, []);
	let l = e.phase === "disaster" && e.disaster?.rid === n && t.rid === n ? B(t.tiles, e.disaster.kind) : [];
	return /* @__PURE__ */ m("div", {
		className: "ra-collection-scroll",
		children: [
			!t.tiles.length && !c.length && /* @__PURE__ */ p("p", {
				className: "ra-empty",
				children: o("games.ra.noTiles")
			}),
			/* @__PURE__ */ p("div", {
				className: "ra-collection-grid",
				children: [...s].sort(([e], [t]) => k.indexOf(e) - k.indexOf(t)).map(([e, n]) => /* @__PURE__ */ p(Me, {
					art: e,
					ids: n,
					rid: t.rid,
					departed: c.find((t) => w[t].art === e),
					legal: n.filter((e) => l.includes(e)),
					onClick: () => {
						let e = n.find((e) => l.includes(e));
						e ? r({
							type: "discard",
							tile: e
						}) : n[0] && i(n[0]);
					}
				}, e))
			}),
			e.traders && /* @__PURE__ */ p("p", {
				className: "ra-goods",
				children: o("games.ra.goods", { n: t.goods })
			})
		]
	});
}
function Me({ art: e, ids: t, rid: n, departed: r, legal: i, onClick: o }) {
	let s = a(), { ref: l } = c(`group:${n}:${e}`), u = t[0] ?? r;
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: "ra-collection-group",
		disabled: !t.length,
		onClick: o,
		"aria-label": i.length ? s("games.ra.discardTile", { name: s(H(u)) }) : s(t.length === 1 ? "games.ra.tileCountOne" : "games.ra.tileCount", {
			name: s(H(u)),
			n: t.length
		}),
		children: [
			/* @__PURE__ */ p("span", {
				ref: l,
				className: "ra-tile-stack",
				children: t.map((e, t) => /* @__PURE__ */ p(Ne, {
					id: e,
					depth: Math.min(t, 3)
				}, e))
			}),
			i.length > 0 && /* @__PURE__ */ p(G, {}),
			t.length > 0 && /* @__PURE__ */ p("span", {
				className: "ra-stack-count",
				children: t.length
			}),
			t.length > 0 && /* @__PURE__ */ p("span", {
				className: "ra-collection-label",
				children: s(H(u))
			})
		]
	});
}
function Ne({ id: e, depth: t }) {
	let { ref: n, hidden: r } = c(`tile:${e}`);
	return /* @__PURE__ */ p("span", {
		ref: n,
		className: "ra-stacked-tile",
		style: {
			transform: `translate(${t * 1.5}px,${-t * 1.5}px)`,
			visibility: r ? "hidden" : void 0
		},
		children: /* @__PURE__ */ p(U, {
			id: e,
			label: !1
		})
	});
}
//#endregion
//#region src/games/ra/bot.ts
var Pe = {
	sunCost: .38,
	reserve: 2.4,
	urgency: .7,
	future: .65,
	trader: 1.8
};
function q(e) {
	let t = 4294967296 - 4294967296 % e.length, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return e[n[0] % e.length];
}
function J(e, t, n, r) {
	let i = (e) => n.filter((t) => w[t].kind === e).length, a = i("pharaoh"), o = e.players.filter((e) => e.rid !== t).map((e) => e.tiles.filter((e) => w[e].kind === "pharaoh").length), s = new Set(n.filter((e) => w[e].kind === "civ").map((e) => w[e].sub)).size, c = 3 - e.epoch, l = i("flood") ? i("nile") + i("flood") : i("nile") * .25;
	return (o.every((e) => e === a) ? 0 : a >= Math.max(...o) ? 5 : a <= Math.min(...o) ? -2 : 0) + a * .45 + c * r.future * a * .8 + l + c * r.future * i("nile") * .55 + [
		-5,
		0,
		1.2,
		5,
		10,
		15
	][s] + i("gold") * 3 + i("god") * 2 + ce(n) * (e.epoch === 3 ? 1 : r.future) + n.filter((e) => w[e].kind === "mon").length * c * .3 + i("trader") * (1 + r.trader * Math.max(0, 1 - e.raCount / e.raLimit));
}
function Fe(e, t, n, r, i) {
	return [...r].sort((r, a) => J(e, t, n.filter((e) => e !== a), i) - J(e, t, n.filter((e) => e !== r), i) || r.localeCompare(a))[0];
}
function Y(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t).tiles, a = [...i, ...n.filter((e) => w[e].kind !== "dis")];
	for (let i of n.filter((e) => w[e].kind === "dis")) for (let n = 0; n < 2; n++) {
		let n = B(a, w[i].sub);
		if (!n.length) break;
		let o = Fe(e, t, a, n, r);
		a = a.filter((e) => e !== o);
	}
	return J(e, t, a, r) - J(e, t, i, r);
}
function Ie(e = Pe) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i || [
			"settle",
			"scoring",
			"done"
		].includes(r.phase)) return null;
		if (r.phase === "epoch") return { action: { type: "continue" } };
		if (r.turn !== n.rid) return null;
		if (r.phase === "disaster" && r.disaster) {
			let t = B(i.tiles, r.disaster.kind);
			return t.length ? { action: {
				type: "discard",
				tile: n.difficulty === "weak" ? q(t) : Fe(r, n.rid, i.tiles, t, e)
			} } : null;
		}
		let a = i.suns.filter((e) => !e.used).map((e) => e.value).sort((e, t) => e - t);
		if (r.phase === "auction" && r.auction) {
			let t = r.auction, i = a.filter((e) => e > t.high), o = t.caller === n.rid && t.reason === "invoked" && !t.winner;
			if (!i.length) return { action: { type: "pass" } };
			if (n.difficulty === "weak") return { action: q([...i.map((e) => ({
				type: "bid",
				sun: e
			})), ...o ? [] : [{ type: "pass" }]]) };
			let s = r.raCount / r.raLimit, c = r.players.reduce((e, t) => e + t.suns.filter((e) => !e.used).length, 0), l = Math.min(1, s + a.length / Math.max(1, c) * .3), u = (e.reserve + e.sunCost * i[0]) * (1 - e.urgency * l);
			return { action: Y(r, n.rid, r.market, e) + (r.centerSun - i[0]) * (r.epoch === 3 ? .12 : .18) >= u || o ? {
				type: "bid",
				sun: i[0]
			} : { type: "pass" } };
		}
		if (r.phase !== "play") return null;
		let o = i.tiles.filter((e) => w[e].kind === "god"), s = r.market.filter((e) => w[e].kind !== "god");
		if (n.difficulty === "weak") {
			let e = [{ type: "invoke" }];
			return r.market.length < 8 && e.push({ type: "draw" }), o.length && s.length && e.push({
				type: "god",
				tiles: [q(s)]
			}), { action: q(e) };
		}
		if (o.length && s.length) {
			let t = [...s].sort((t, i) => Y(r, n.rid, [i], e) - Y(r, n.rid, [t], e))[0];
			if (Y(r, n.rid, [t], e) > 2.7) return { action: {
				type: "god",
				tiles: [t]
			} };
		}
		let c = Y(r, n.rid, r.market, e), l = r.raCount >= r.raLimit - 2 && c > 1.5;
		return { action: r.market.length >= 8 || r.market.length >= 3 && c >= e.reserve + a[0] * e.sunCost || l && r.market.length > 0 ? { type: "invoke" } : { type: "draw" } };
	};
}
var Le = Ie(), Re = (e, t, n) => e.type === "bid" ? n("games.ra.bidAria", { n: e.sun }) : e.type === "discard" ? n("games.ra.discardTile", { name: n(H(e.tile)) }) : e.type === "god" ? n("games.ra.godConfirm", { n: e.tiles.length }) : n(e.type === "draw" ? "games.ra.draw" : e.type === "invoke" ? "games.ra.invoke" : e.type === "pass" ? "games.ra.pass" : "games.ra.nextEpoch");
//#endregion
//#region src/games/ra/fx.tsx
function X(e, t) {
	return /* @__PURE__ */ p("span", {
		style: {
			display: "block",
			width: t.w,
			height: t.h
		},
		children: /* @__PURE__ */ p(U, {
			id: e,
			label: !1
		})
	});
}
function ze(e, t, n = !1) {
	return /* @__PURE__ */ p("span", {
		style: {
			display: "block",
			width: t.w,
			height: t.h
		},
		children: /* @__PURE__ */ p(W, {
			value: e,
			used: n
		})
	});
}
function Z(e, t, n = Infinity) {
	let r = Math.min(e.w, e.h * t, n), i = r / t;
	return {
		x: e.x + (e.w - r) / 2,
		y: e.y + (e.h - i) / 2,
		w: r,
		h: i
	};
}
var Q = (e) => w[e].kind === "trader" ? 275 / 312 : 427 / 480;
function Be(e, t, n) {
	let r = Z(e.anchor("market:0") ?? t, Q(n), 170);
	return {
		...r,
		x: t.x + (t.w - r.w) / 2,
		y: t.y + (t.h - r.h) / 2
	};
}
function Ve(e, t, n) {
	let r = e.anchor(`tile:${t}`);
	if (r) return Z(r, Q(t));
	let i = w[t].kind === "dis" ? e.anchor("discard") : e.anchor(`seat:${n}`);
	return i ? Z(i, Q(t), 76) : null;
}
function He(e, t, n) {
	let r = e.anchor(`group:${n}:${w[t].art}`), i = e.anchor(`seat:${n}`);
	return r ? Z(r, Q(t)) : i ? Z(i, Q(t), 76) : null;
}
function $(e, t, n) {
	let r = e.anchor("discard");
	if (!r) return null;
	let i = [];
	return t.forEach(({ id: e, from: t }, a) => {
		if (t) {
			let o = Z(t, Q(e));
			i.push(/* @__PURE__ */ p(g, {
				from: o,
				to: Z(r, Q(e)),
				ms: n - 100,
				delay: Math.min(a * 20, 100),
				children: X(e, o)
			}, e));
		}
	}), i.length ? {
		ms: n,
		node: i
	} : null;
}
var Ue = {
	draw(e, t) {
		let n = e.data, r = t.anchor("bag"), i = t.anchor(`market:${n.index}`);
		if (!r || !i) return null;
		let a = Be(t, r, n.tile);
		return {
			ms: N.draw,
			hide: [`market:${n.index}`],
			node: /* @__PURE__ */ p(g, {
				from: a,
				to: Z(i, Q(n.tile)),
				ms: N.draw - 70,
				children: X(n.tile, a)
			})
		};
	},
	ra(e, t) {
		let n = e.data, r = t.anchor("bag"), i = t.anchor("ra-track");
		if (!r || !i) return null;
		let a = Be(t, r, n.tile), o = Z(i, Q(n.tile));
		return {
			ms: N.ra,
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(g, {
				from: a,
				to: o,
				ms: N.ra - 220,
				children: X(n.tile, a)
			}), /* @__PURE__ */ p(_, {
				at: i,
				ms: N.ra
			})] })
		};
	},
	invoke(e, t) {
		let n = t.anchor("ra-track");
		return n ? {
			ms: 350,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 350
			})
		} : null;
	},
	bid(e, t) {
		let n = e.data, r = t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: N.bid,
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(_, {
				at: r,
				ms: N.bid
			}), n.sun > 0 && /* @__PURE__ */ p(h, {
				at: r,
				ms: N.bid,
				children: /* @__PURE__ */ p("span", {
					className: "ra-fx-number",
					children: n.sun
				})
			})] })
		} : null;
	},
	award(e, t) {
		let n = e.data, r = e.rid, i = [], a = [];
		n.tiles.forEach((e, n) => {
			let o = t.anchor(`market:${n}`), s = Ve(t, e, r);
			if (!o || !s) return;
			let c = Z(o, Q(e));
			i.push(/* @__PURE__ */ p(g, {
				from: c,
				to: s,
				ms: N.award - 190,
				delay: n * 16,
				children: X(e, c)
			}, e)), t.anchor(`tile:${e}`) && a.push(`tile:${e}`);
		});
		let o = t.anchor("center"), s = t.anchor(`sun-slot:${r}:${n.paidSlot}`), c = t.anchor(`sun-slot:${r}:${n.receivedSlot}`);
		if (o && s && c) {
			let e = Z(s, 480 / 343), t = Z(o, 480 / 343), l = Z(c, 480 / 343);
			i.push(/* @__PURE__ */ p(g, {
				from: e,
				to: t,
				ms: N.award - 160,
				children: ze(n.paid, e)
			}, "paid"), /* @__PURE__ */ p(g, {
				from: t,
				to: l,
				ms: N.award - 160,
				children: ze(n.sun, t, !0)
			}, "received")), a.push("center", `sun-slot:${r}:${n.receivedSlot}`);
		}
		return {
			ms: N.award,
			node: i,
			hide: a
		};
	},
	god(e, t) {
		let n = e.data, r = t.anchor(`market:${n.index}`), i = Ve(t, n.tile, e.rid);
		if (!r || !i) return null;
		let a = Z(r, Q(n.tile));
		return {
			ms: N.award,
			hide: t.anchor(`tile:${n.tile}`) ? [`tile:${n.tile}`] : [],
			node: /* @__PURE__ */ p(g, {
				from: a,
				to: i,
				ms: N.award - 180,
				children: X(n.tile, a)
			})
		};
	},
	godSpend(e, t) {
		let n = e.data;
		return $(t, n.tiles.map((n) => ({
			id: n,
			from: He(t, n, e.rid)
		})), N.discard);
	},
	discard(e, t) {
		let n = e.data;
		return $(t, [{
			id: n.tile,
			from: He(t, n.tile, e.rid)
		}], N.discard);
	},
	clear(e, t) {
		let n = e.data;
		return $(t, n.tiles.map((e, n) => ({
			id: e,
			from: t.anchor(`market:${n}`)
		})), N.discard);
	},
	epochScore(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: N.score,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: N.score
			})
		} : null;
	},
	newEpoch(e, t) {
		let n = e.data;
		return $(t, [...n.discarded.map((e) => ({
			id: e.tile,
			from: He(t, e.tile, e.rid)
		})), ...n.market.map((e, n) => ({
			id: e,
			from: t.anchor(`market:${n}`)
		}))], N.award) ?? {
			ms: N.award,
			node: null
		};
	}
};
//#endregion
//#region src/games/ra/game-over.tsx
function We(e) {
	let t = a(), n = e.public, [r, s] = i(!0), [c, l] = i(null), u = (t) => e.members.find((e) => e.rid === t)?.name ?? t, d = e.result.winner.map(u).join(" / ");
	return /* @__PURE__ */ m("div", {
		className: "ra-result-root",
		children: [
			/* @__PURE__ */ p("div", {
				className: "ra-result-board",
				inert: r,
				children: /* @__PURE__ */ p(De, {
					public: n,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => void 0
				})
			}),
			!r && /* @__PURE__ */ p("button", {
				type: "button",
				className: "ra-button ra-result-restore",
				onClick: () => s(!0),
				children: t("games.ra.restoreResult")
			}),
			/* @__PURE__ */ p("div", {
				className: "ra-result-shade",
				hidden: !r,
				children: /* @__PURE__ */ m(Ce, {
					open: r,
					className: "ra-result",
					label: t("games.ra.final"),
					onClose: () => s(!1),
					children: [
						/* @__PURE__ */ m("header", {
							className: "ra-result-heading",
							children: [
								/* @__PURE__ */ p("span", {
									className: "ra-brand",
									"aria-hidden": !0,
									children: "RA"
								}),
								/* @__PURE__ */ p("h1", { children: t("games.ra.final") }),
								/* @__PURE__ */ p("button", {
									type: "button",
									className: "ra-icon-button",
									"aria-label": t("games.ra.returnView"),
									onClick: () => s(!1),
									children: /* @__PURE__ */ p(o, { size: 23 })
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "ra-result-content",
							children: [
								/* @__PURE__ */ p("h2", { children: t("games.ra.winner", { name: d }) }),
								e.hintCount !== void 0 && /* @__PURE__ */ p("p", { children: t("session.hint.usedCount", { n: e.hintCount }) }),
								/* @__PURE__ */ p("ol", {
									className: "ra-result-ranks",
									children: e.result.ranking.map((n, r) => /* @__PURE__ */ m("li", {
										"data-winner": e.result.winner.includes(n),
										children: [
											/* @__PURE__ */ p("span", { children: r + 1 }),
											/* @__PURE__ */ p("strong", { children: u(n) }),
											/* @__PURE__ */ p("b", { children: e.result.scores?.[n] }),
											(e.result.autopilot?.[n] ?? 0) > 0 && /* @__PURE__ */ p("small", { children: t("session.autopilot.share", { n: Math.round(e.result.autopilot[n] * 100) }) })
										]
									}, n))
								}),
								/* @__PURE__ */ p(Se, {
									players: e.result.ranking.map((e) => n.players.find((t) => t.rid === e)),
									nameOf: u
								})
							]
						}),
						/* @__PURE__ */ p("footer", {
							className: "ra-result-footer",
							children: c ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("p", { children: t(c === "again" ? "games.ra.confirmAgain" : "games.ra.confirmLobby") }), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("button", {
								type: "button",
								className: "ra-button",
								onClick: () => l(null),
								children: t("games.ra.cancel")
							}), /* @__PURE__ */ p("button", {
								type: "button",
								className: "ra-button ra-button-red",
								onClick: () => {
									c === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.();
								},
								children: t("games.ra.confirm")
							})] })] }) : /* @__PURE__ */ m(f, { children: [
								/* @__PURE__ */ p("button", {
									type: "button",
									className: "ra-button",
									onClick: () => s(!1),
									children: t("games.ra.returnView")
								}),
								e.onPlayAgain && /* @__PURE__ */ p("button", {
									type: "button",
									className: "ra-button ra-button-gold",
									onClick: () => l("again"),
									children: t("session.result.playAgain")
								}),
								e.onBackToLobby && /* @__PURE__ */ p("button", {
									type: "button",
									className: "ra-button",
									onClick: () => l("lobby"),
									children: t("session.result.backToLobby")
								}),
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ p("p", { children: t("session.result.waitHost") })
							] })
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/ra/options.tsx
function Ge({ value: e, onChange: t }) {
	let n = a(), r = j.safeParse(e), i = r.success ? r.data : j.parse(void 0);
	return /* @__PURE__ */ p(v, {
		title: n("games.ra.optTraders"),
		columns: 2,
		children: [!1, !0].map((e) => /* @__PURE__ */ p(ee, {
			name: "ra-traders",
			value: String(e),
			checked: i.traders === e,
			label: n(e ? "games.ra.tradersOn" : "games.ra.tradersOff"),
			accent: A.accent,
			onChange: () => t({ traders: e })
		}, String(e)))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/ra/entry.tsx
var Ke = {
	definition: ye,
	View: De,
	bot: Le,
	describe: Re,
	fx: Ue,
	OverView: We,
	Options: Ge,
	locales: {
		zh: {
			name: "太陽神",
			desc: "呼唤 Ra，以太阳竞拍文明、法老与纪念物，历经三个时代建立王朝。",
			rules: "目标：\n游戏进行三个时代，最终总分最高的玩家获胜。总分平手时，持有单个最高太阳的玩家获胜。\n准备：\n每位玩家获得 10 分及一组太阳。每个时代由持有最高太阳的玩家先行动，然后顺时针轮流行动。所有分数在终局前仅本人可见，板块与太阳始终公开。\n行动：\n仅持有正面太阳的玩家可以行动。每回合选择以下一项：\n· 抽取板块：拍卖列未满 8 枚时，从袋中抽一枚。普通板块进入拍卖列；Ra 板块弃置并使太阳船前进一步，触发拍卖。太阳船到达终点时，直接结束时代，不进行拍卖。\n· 呼唤 Ra：主动发起拍卖，不推进太阳船。\n· 使用神板块：弃置自己的一枚或多枚神板块，按所选顺序逐枚获得拍卖列中等量的非神板块。取得灾难时立即处理，再继续取得下一枚。\n拍卖：\n从发起者下家开始，依顺时针顺序各竞价一次，发起者最后。选择一个正面太阳，数值必须高于当前最高价，或放弃竞价。仅最高出价者支付太阳，其他人的太阳仍可使用。胜者获得整列板块，并用所付太阳交换中央太阳，将获得的太阳背面朝上放置。\n抽到 Ra 引发的拍卖允许全员放弃，板块保留。主动呼唤且拍卖列未满时，若其他人全部放弃，发起者必须竞价；拍卖列已满时允许全员放弃，并清空拍卖列。拍卖后从发起者下家继续行动，跳过没有正面太阳的玩家。\n灾难：\n取得灾难后，每枚灾难要求弃置两枚对应板块；不足两枚则全部弃置。战争对应文明，葬礼对应法老，地震对应纪念物。干旱先弃置洪水，不足时再弃置尼罗河。拍卖获得的所有板块先归入收藏，再处理灾难。\n时代结束与计分：\n全员太阳均背面朝上，或太阳船达到终点时，进行时代计分。太阳船终点按 2／3／4／5 人分别为 6／8／9／10 步。时代计分后的累计分数最低为 0。\n· 法老：最多者获得 5 分，最少者失去 2 分，并列者均计分；所有人数量相同时不计分。\n· 河流：每枚洪水获得 1 分。至少有一枚洪水时，每枚尼罗河额外获得 1 分。\n· 文明：没有文明失去 5 分；拥有 3／4／5 种文明分别获得 5／10／15 分；1 或 2 种不计分。\n· 黄金：每枚获得3分。\n· 未使用的神板块：每枚获得2分。\n· 纪念物仅第三时代计分：不同类型不超过 6 种时每种 1 分，7／8 种分别为 10／15 分。同类的 3／4／5 枚额外获得 5／10／15 分。两种方式同时计分。\n· 太阳仅第三时代计分：各人全部太阳数值之和，最高者获得 5 分，最低者失去 5 分，并列者均计分；所有人总值相同时不计分。\n前两个时代结束后，保留法老、尼罗河与纪念物；弃置其他板块及拍卖列剩余板块。中央太阳保留，所有玩家的太阳翻回正面，太阳船回到起点，开始下个时代。\n商人扩展（可选）：\n加入 20 枚商人板块。每当一名玩家获得一枚商人，其他玩家各按自己已有的商人数获得等量货物，取得商人的玩家不因此获得货物。时代计分时，每枚商人和每份货物各获得 1 分，随后全部弃置。",
			epoch: "第 {{n}} 时代",
			epochEnd: "第 {{n}} 时代结束",
			nextEpoch: "开始下个时代",
			turn: "{{name}}的回合",
			yourTurn: "请选择一项行动",
			bidding: "{{name}}正在竞价",
			yourBid: "选择太阳竞价",
			settling: "正在结算",
			scoring: "正在进行时代计分",
			final: "王朝终章",
			winner: "{{name}}获胜",
			draw: "抽取板块",
			invoke: "呼唤 Ra",
			pass: "放弃竞价",
			useGod: "使用神板块",
			godConfirm: "使用 {{n}} 枚神",
			cancel: "取消",
			godPrompt: "按获得顺序选择非神板块",
			disasterPrompt: "弃置{{kind}}对应的板块（还剩 {{n}} 枚）",
			waitingDisaster: "{{name}}正在处理{{kind}}",
			high: "最高出价 {{n}}",
			center: "中央太阳",
			collection: "{{name}}的收藏",
			noTiles: "尚无板块",
			bag: "袋中剩余 {{n}} 枚",
			score: "得分 {{n}}",
			goods: "货物 {{n}}",
			godConfirmOne: "使用 {{n}} 枚神",
			bagOne: "袋中剩余 {{n}} 枚",
			tileCountOne: "{{name}}，{{n}} 枚",
			logAwardOne: "{{name}}获得 {{n}} 枚板块",
			logGodOne: "{{name}}使用 {{n}} 枚神",
			tileCount: "{{name}}，{{n}} 枚",
			tile: {
				ra: "Ra",
				pharaoh: "法老",
				nile: "尼罗河",
				flood: "洪水",
				god: "神",
				gold: "黄金",
				trader: "商人",
				art: "艺术",
				religion: "宗教",
				writing: "文字",
				agriculture: "农业",
				astronomy: "天文",
				stepPyramid: "阶梯金字塔",
				temple: "神庙",
				shrine: "圣祠",
				mortuary: "祭庙",
				statues: "雕像",
				obelisk: "方尖碑",
				pyramid: "金字塔",
				sphinx: "狮身人面像",
				war: "战争",
				funeral: "葬礼",
				drought: "干旱",
				earthquake: "地震",
				civ: "文明",
				mon: "纪念物",
				dis: "灾难"
			},
			bidAria: "使用数值 {{n}} 的太阳竞价",
			usedSun: "数值 {{n}} 的太阳，已使用",
			sun: "数值 {{n}} 的太阳",
			slot: "拍卖列第 {{n}} 格",
			selectTile: "选择{{name}}",
			discardTile: "弃置{{name}}",
			inspect: "查看{{name}}的收藏",
			selectedOrder: "第 {{n}} 枚",
			optTraders: "商人扩展",
			tradersOn: "加入商人",
			tradersOff: "基础版",
			scoreDetail: "计分明细",
			epochDetail: "第 {{n}} 时代明细",
			initial: "初始得分",
			total: "总分",
			suns: "太阳",
			sunTotal: "太阳总值",
			adjustment: "最低零分调整",
			playerPanel: "个人面板",
			playerPanelTitle: "{{name}}的个人面板",
			river: "河流",
			tileAmount: "{{n}} 枚",
			typeAmount: "{{n}} 枚 · {{types}} 种",
			riverAmount: "尼罗河 {{nile}} 枚 · 洪水 {{flood}} 枚",
			traderAmount: "商人 {{n}} 枚 · 货物 {{goods}} 份",
			sunAmount: "可用 {{available}} / {{n}} 枚 · 总值 {{total}}",
			epochEstimate: "第 {{n}} 时代预计 {{score}} 分",
			pointChange: "{{n}} 分",
			finalOnly: "第三时代计分",
			estimateNote: "按当前收藏与太阳估算，时代结束时重新结算；此处未计入累计得分。",
			floorEstimate: "累计得分最低为 0，本次预计调整 +{{n}} 分。",
			keepTile: "时代结束后保留。",
			clearTile: "时代计分后弃置。",
			tileRule: {
				pharaoh: "每个时代：法老最多者 +5 分，最少者 −2 分，并列者均计分；所有人数量相同时不计分。",
				river: "每个时代：每枚洪水 1 分；至少有一枚洪水时，每枚尼罗河再得 1 分。没有洪水时，尼罗河不计分。",
				civilization: "每个时代：没有文明 −5 分；1 或 2 种为 0 分；3／4／5 种分别为 5／10／15 分。同种重复板块不增加种类。",
				monuments: "仅第三时代：1 至 6 种每种 1 分，7／8 种为 10／15 分；同类 3／4／5 枚额外得 5／10／15 分，两种计分相加。",
				gold: "每个时代：每枚黄金 3 分。",
				gods: "每个时代：每枚未使用的神 2 分；使用后弃置，不再计分。",
				traders: "每个时代：每枚商人和每份货物各 1 分，计分后均弃置。其他玩家获得商人时，你按自己已有的商人数获得货物。",
				suns: "仅第三时代：全部太阳（含已使用）的总值最高者 +5 分，最低者 −5 分，并列者均计分；所有人总值相同时不计分。",
				disaster: "每枚灾难弃置两枚对应板块，不足则全部弃置：战争对应文明，葬礼对应法老，地震对应纪念物；干旱先弃洪水，再弃尼罗河。灾难本身不计分。",
				ra: "推进太阳船并触发拍卖；到达终点时直接结束时代，不进行拍卖。Ra 板块不计分。"
			},
			returnView: "回看收藏",
			restoreResult: "查看结算",
			close: "收起",
			confirmAgain: "确定开始新一局？",
			confirmLobby: "确定返回大厅？",
			confirm: "确定",
			log: "对局记录",
			logDraw: "{{name}}抽到{{tile}}",
			logRa: "{{name}}抽到 Ra",
			logInvoke: "{{name}}呼唤 Ra",
			logBid: "{{name}}出价 {{n}}",
			logPass: "{{name}}放弃竞价",
			logAward: "{{name}}获得 {{n}} 枚板块",
			logGod: "{{name}}使用 {{n}} 枚神",
			logDiscard: "{{name}}弃置{{tile}}",
			errTurn: "当前不能执行此行动。",
			errDraw: "拍卖列已满，不能抽取板块。",
			errGod: "请选择可获得的非神板块，数量不能超过持有的神。",
			errBid: "请选择高于当前最高价的可用太阳。",
			errMustBid: "其他玩家均已放弃，本次必须竞价。",
			errDiscard: "请选择本次灾难对应的板块。"
		},
		en: {
			name: "Ra",
			desc: "Invoke Ra and bid with your suns to build a dynasty over three epochs.",
			rules: "Goal:\nPlay three epochs. The player with the highest final score wins. Ties are broken by the highest single sun disk held by a tied player.\nSetup:\nEach player starts with 10 points and a group of suns. The owner of the highest sun takes the first turn of each epoch, then play continues clockwise. Scores remain private until the game ends. Tiles and suns are public.\nActions:\nOnly players with a faceup sun may act. On your turn, choose one action:\n· Draw a tile: if the auction track has fewer than 8 tiles, draw from the bag. Ordinary tiles enter the track. A Ra tile is discarded and advances the Sun Boat one step, triggering an auction. Reaching the final step ends the epoch immediately, without an auction.\n· Invoke Ra: begin an auction without moving the Sun Boat.\n· Spend God tiles: discard one or more Gods to take that many non-God tiles from the track, in your chosen order. Resolve each Disaster immediately before taking the next tile.\nAuctions:\nBeginning with the player to the caller's left, each player bids or passes once; the caller goes last. A bid uses one faceup sun with a value higher than the current bid. Only the winner pays a sun; losing bids remain available. The winner takes the entire auction track, swaps their winning sun for the central sun, and places the received sun facedown.\nWhen a Ra tile triggers an auction, everyone may pass and the track stays. When Ra is invoked with fewer than 8 tiles, the caller must bid if everyone else passes. With a full track, everyone may pass and all tiles on the track are discarded. Play resumes clockwise from the caller, skipping players without faceup suns.\nDisasters:\nFor each Disaster acquired, discard two matching tiles, or all matching tiles if you have fewer than two. War affects Civilizations, Funeral affects Pharaohs, and Earthquake affects Monuments. Drought removes Floods first, then Nile tiles. All tiles won at auction enter your collection before Disasters are resolved.\nEpochs and scoring:\nAn epoch ends when all suns are facedown or the Sun Boat reaches its final step. With 2/3/4/5 players, the track has 6/8/9/10 steps. Cumulative scores cannot fall below zero after scoring an epoch.\n· Pharaohs: most gains 5 points; fewest loses 2. Tied players gain or lose the full amount. If everyone is tied, no one scores.\n· River: each Flood scores 1 point. With at least one Flood, each Nile also scores 1 point.\n· Civilizations: no types loses 5 points; 3/4/5 different types scores 5/10/15. One or two types scores nothing.\n· Gold tiles: Score 3 points for each tile.\n· Unspent God tiles: Score 2 points for each tile.\n· Monuments score only in epoch III. Up to 6 different types score 1 per type; 7/8 types score 10/15. Groups of 3/4/5 identical Monuments add 5/10/15. Both methods apply together.\n· Suns score only in epoch III. Add all your sun values: highest total gains 5, lowest loses 5. Tied players gain or lose the full amount. If everyone is tied, no one scores.\nAfter epochs I and II, keep Pharaohs, Nile tiles and Monuments. Discard other tiles and the auction track. Leave the central sun, turn all players' suns faceup, reset the Sun Boat and begin the next epoch.\nTraders expansion (optional):\nAdd 20 Trader tiles. Whenever a player takes a Trader, every other player gains goods equal to their own number of Traders. The player taking the Trader gains no goods from it. Each Trader and each good scores 1 point at the end of the epoch, then all are discarded.",
			epoch: "Epoch {{n}}",
			epochEnd: "Epoch {{n}} complete",
			nextEpoch: "Next epoch",
			turn: "{{name}}'s turn",
			yourTurn: "Choose an action",
			bidding: "{{name}} is bidding",
			yourBid: "Choose a sun to bid",
			settling: "Resolving",
			scoring: "Scoring the epoch",
			final: "The dynasty concludes",
			winner: "{{name}} wins",
			draw: "Draw a tile",
			invoke: "Invoke Ra",
			pass: "Pass",
			useGod: "Spend Gods",
			godConfirm: "Spend {{n}} Gods",
			cancel: "Cancel",
			godPrompt: "Select non-God tiles in the order to take them",
			disasterPrompt: "Discard tiles for {{kind}} ({{n}} left)",
			waitingDisaster: "{{name}} is resolving {{kind}}",
			high: "Highest bid {{n}}",
			center: "Central sun",
			collection: "{{name}}'s collection",
			noTiles: "No tiles yet",
			bag: "{{n}} tiles in bag",
			score: "Score {{n}}",
			goods: "Goods {{n}}",
			tileCount: "{{name}}, {{n}} tiles",
			godConfirmOne: "Spend {{n}} God",
			bagOne: "{{n}} tile in bag",
			tileCountOne: "{{name}}, {{n}} tile",
			logAwardOne: "{{name}} gained {{n}} tile",
			logGodOne: "{{name}} spent {{n}} God",
			tile: {
				ra: "Ra",
				pharaoh: "Pharaoh",
				nile: "Nile",
				flood: "Flood",
				god: "God",
				gold: "Gold",
				trader: "Trader",
				art: "Art",
				religion: "Religion",
				writing: "Writing",
				agriculture: "Agriculture",
				astronomy: "Astronomy",
				stepPyramid: "Step Pyramid",
				temple: "Temple",
				shrine: "Shrine",
				mortuary: "Mortuary",
				statues: "Statues",
				obelisk: "Obelisk",
				pyramid: "Pyramid",
				sphinx: "Sphinx",
				war: "War",
				funeral: "Funeral",
				drought: "Drought",
				earthquake: "Earthquake",
				civ: "Civilization",
				mon: "Monument",
				dis: "Disaster"
			},
			bidAria: "Bid with your {{n}} sun",
			usedSun: "{{n}} sun, used",
			sun: "{{n}} sun",
			slot: "Auction space {{n}}",
			selectTile: "Select {{name}}",
			discardTile: "Discard {{name}}",
			inspect: "Inspect {{name}}'s collection",
			selectedOrder: "Tile {{n}}",
			optTraders: "Traders expansion",
			tradersOn: "Include Traders",
			tradersOff: "Base game",
			scoreDetail: "Score details",
			epochDetail: "Epoch {{n}} details",
			initial: "Starting score",
			total: "Total",
			suns: "Suns",
			sunTotal: "Sun total",
			adjustment: "Zero-floor adjustment",
			returnView: "View collection",
			restoreResult: "Show results",
			close: "Collapse",
			confirmAgain: "Start a new game?",
			confirmLobby: "Return to the lobby?",
			confirm: "Confirm",
			playerPanel: "Player board",
			playerPanelTitle: "{{name}}'s player board",
			river: "River",
			tileAmount: "{{n}}",
			typeAmount: "Tiles: {{n}} · Types: {{types}}",
			riverAmount: "Nile {{nile}} · Floods {{flood}}",
			traderAmount: "Traders {{n}} · Goods {{goods}}",
			sunAmount: "{{available}} / {{n}} available · Total {{total}}",
			epochEstimate: "Epoch {{n}} estimate: {{score}} pts",
			pointChange: "{{n}} pts",
			finalOnly: "Scores in epoch III",
			estimateNote: "Based on the current tiles and suns; recalculated at epoch end. Not yet added to your score.",
			floorEstimate: "Scores cannot fall below zero: estimated adjustment +{{n}} pts.",
			keepTile: "Kept after each epoch.",
			clearTile: "Discarded after scoring the epoch.",
			tileRule: {
				pharaoh: "Every epoch: most Pharaohs gains 5 points; fewest loses 2. Tied players score in full. If everyone is tied, no one scores.",
				river: "Every epoch: 1 point per Flood. With at least one Flood, add 1 per Nile. Without a Flood, Nile tiles score nothing.",
				civilization: "Every epoch: no types loses 5 points; 1 or 2 types scores 0; 3/4/5 types scores 5/10/15. Duplicate tiles do not add types.",
				monuments: "Epoch III only: 1–6 types score 1 per type; 7/8 types score 10/15. Groups of 3/4/5 identical tiles add 5/10/15. Add both scores.",
				gold: "Every epoch: 3 points per Gold.",
				gods: "Every epoch: 2 points per unspent God. Spent Gods are discarded and do not score.",
				traders: "Every epoch: 1 point per Trader and per good, then discard both. When another player takes a Trader, gain goods equal to your own Traders.",
				suns: "Epoch III only: total all suns, including used ones. Highest total gains 5 points; lowest loses 5. Ties score in full. If everyone is tied, no one scores.",
				disaster: "Discard two matching tiles per Disaster, or all if fewer: War affects Civilizations, Funeral Pharaohs, Earthquake Monuments. Drought removes Floods before Nile tiles. Disasters do not score.",
				ra: "Advance the Sun Boat and trigger an auction. The final step ends the epoch without an auction. Ra tiles do not score."
			},
			log: "Game log",
			logDraw: "{{name}} drew {{tile}}",
			logRa: "{{name}} drew Ra",
			logInvoke: "{{name}} invoked Ra",
			logBid: "{{name}} bid {{n}}",
			logPass: "{{name}} passed",
			logAward: "{{name}} gained {{n}} tiles",
			logGod: "{{name}} spent {{n}} Gods",
			logDiscard: "{{name}} discarded {{tile}}",
			errTurn: "That action is not available now.",
			errDraw: "The auction track is full.",
			errGod: "Choose non-God tiles, up to the number of Gods you own.",
			errBid: "Choose an available sun higher than the current bid.",
			errMustBid: "Everyone else passed. You must bid.",
			errDiscard: "Choose a tile affected by this Disaster."
		}
	}
};
//#endregion
export { Ke as default };
