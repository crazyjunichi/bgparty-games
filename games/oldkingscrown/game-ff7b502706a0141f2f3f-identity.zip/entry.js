import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { gameAssetUrl as o } from "@bgparty/sdk/assets";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { OptionCheckbox as v, OptionRadio as ee, OptionSection as te, OptionSwitch as ne } from "@bgparty/sdk/ui/game-options";
//#region src/games/oldkingscrown/data.ts
var y = [
	"nobility",
	"clans",
	"uprising",
	"gathering"
], b = [
	"opulence",
	"mystery",
	"force"
], x = [
	{
		id: 174e3,
		faction: "nobility",
		strength: 0,
		archetype: "ruse",
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["ambush_or_retreat"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174000",
		effectKey: "games.oldkingscrown.cards.e174000"
	},
	{
		id: 174001,
		faction: "nobility",
		strength: 0,
		archetype: "trader",
		votes: 2,
		lore: 2,
		traits: [],
		commands: ["rally2"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174001",
		effectKey: "games.oldkingscrown.cards.e174001"
	},
	{
		id: 174002,
		faction: "nobility",
		strength: 1,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174002",
		effectKey: "games.oldkingscrown.cards.e174002"
	},
	{
		id: 174003,
		faction: "nobility",
		strength: 2,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174003",
		effectKey: "games.oldkingscrown.cards.e174003"
	},
	{
		id: 174004,
		faction: "nobility",
		strength: 3,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174004",
		effectKey: "games.oldkingscrown.cards.e174004"
	},
	{
		id: 174005,
		faction: "nobility",
		strength: 4,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174005",
		effectKey: "games.oldkingscrown.cards.e174005"
	},
	{
		id: 174006,
		faction: "nobility",
		strength: 5,
		archetype: "agent",
		votes: 2,
		lore: 1,
		traits: [],
		commands: ["deadly"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174006",
		effectKey: "games.oldkingscrown.cards.e174006"
	},
	{
		id: 174007,
		faction: "nobility",
		strength: 5,
		archetype: "cavalry",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: ["flank"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174007",
		effectKey: "games.oldkingscrown.cards.e174007"
	},
	{
		id: 174008,
		faction: "nobility",
		strength: 5,
		archetype: "warMachine",
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["deploy1_autumn"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174008",
		effectKey: "games.oldkingscrown.cards.e174008"
	},
	{
		id: 174009,
		faction: "nobility",
		strength: 6,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174009",
		effectKey: "games.oldkingscrown.cards.e174009"
	},
	{
		id: 174010,
		faction: "nobility",
		strength: 7,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174010",
		effectKey: "games.oldkingscrown.cards.e174010"
	},
	{
		id: 174011,
		faction: "nobility",
		strength: 8,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174011",
		effectKey: "games.oldkingscrown.cards.e174011"
	},
	{
		id: 174012,
		faction: "nobility",
		strength: 9,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174012",
		effectKey: "games.oldkingscrown.cards.e174012"
	},
	{
		id: 174013,
		faction: "nobility",
		strength: 10,
		archetype: "heir",
		votes: 1,
		lore: 1,
		traits: ["pathfinder", "resilient"],
		commands: ["rallySelf"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174013",
		effectKey: "games.oldkingscrown.cards.e174013"
	},
	{
		id: 174400,
		faction: "clans",
		strength: 0,
		archetype: "ruse",
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["ambush_or_retreat"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174400",
		effectKey: "games.oldkingscrown.cards.e174400"
	},
	{
		id: 174401,
		faction: "clans",
		strength: 0,
		archetype: "trader",
		votes: 2,
		lore: 2,
		traits: [],
		commands: ["rally2"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174401",
		effectKey: "games.oldkingscrown.cards.e174401"
	},
	{
		id: 174402,
		faction: "clans",
		strength: 1,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174402",
		effectKey: "games.oldkingscrown.cards.e174402"
	},
	{
		id: 174403,
		faction: "clans",
		strength: 2,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174403",
		effectKey: "games.oldkingscrown.cards.e174403"
	},
	{
		id: 174404,
		faction: "clans",
		strength: 3,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174404",
		effectKey: "games.oldkingscrown.cards.e174404"
	},
	{
		id: 174405,
		faction: "clans",
		strength: 4,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174405",
		effectKey: "games.oldkingscrown.cards.e174405"
	},
	{
		id: 174406,
		faction: "clans",
		strength: 5,
		archetype: "agent",
		votes: 2,
		lore: 1,
		traits: [],
		commands: ["deadly"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174406",
		effectKey: "games.oldkingscrown.cards.e174406"
	},
	{
		id: 174407,
		faction: "clans",
		strength: 5,
		archetype: "cavalry",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: ["flank"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174407",
		effectKey: "games.oldkingscrown.cards.e174407"
	},
	{
		id: 174408,
		faction: "clans",
		strength: 5,
		archetype: "warMachine",
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["deploy1_autumn"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174408",
		effectKey: "games.oldkingscrown.cards.e174408"
	},
	{
		id: 174409,
		faction: "clans",
		strength: 6,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174409",
		effectKey: "games.oldkingscrown.cards.e174409"
	},
	{
		id: 174410,
		faction: "clans",
		strength: 7,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174410",
		effectKey: "games.oldkingscrown.cards.e174410"
	},
	{
		id: 174411,
		faction: "clans",
		strength: 8,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174411",
		effectKey: "games.oldkingscrown.cards.e174411"
	},
	{
		id: 174412,
		faction: "clans",
		strength: 9,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174412",
		effectKey: "games.oldkingscrown.cards.e174412"
	},
	{
		id: 174413,
		faction: "clans",
		strength: 10,
		archetype: "heir",
		votes: 1,
		lore: 1,
		traits: ["pathfinder", "resilient"],
		commands: ["rallySelf"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174413",
		effectKey: "games.oldkingscrown.cards.e174413"
	},
	{
		id: 174300,
		faction: "uprising",
		strength: 0,
		archetype: "ruse",
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["ambush_or_retreat"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174300",
		effectKey: "games.oldkingscrown.cards.e174300"
	},
	{
		id: 174301,
		faction: "uprising",
		strength: 0,
		archetype: "trader",
		votes: 2,
		lore: 2,
		traits: [],
		commands: ["rally2"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174301",
		effectKey: "games.oldkingscrown.cards.e174301"
	},
	{
		id: 174302,
		faction: "uprising",
		strength: 1,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174302",
		effectKey: "games.oldkingscrown.cards.e174302"
	},
	{
		id: 174303,
		faction: "uprising",
		strength: 2,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174303",
		effectKey: "games.oldkingscrown.cards.e174303"
	},
	{
		id: 174304,
		faction: "uprising",
		strength: 3,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174304",
		effectKey: "games.oldkingscrown.cards.e174304"
	},
	{
		id: 174305,
		faction: "uprising",
		strength: 4,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174305",
		effectKey: "games.oldkingscrown.cards.e174305"
	},
	{
		id: 174306,
		faction: "uprising",
		strength: 5,
		archetype: "agent",
		votes: 2,
		lore: 1,
		traits: [],
		commands: ["deadly"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174306",
		effectKey: "games.oldkingscrown.cards.e174306"
	},
	{
		id: 174307,
		faction: "uprising",
		strength: 5,
		archetype: "cavalry",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: ["flank"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174307",
		effectKey: "games.oldkingscrown.cards.e174307"
	},
	{
		id: 174308,
		faction: "uprising",
		strength: 5,
		archetype: "warMachine",
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["deploy1_autumn"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174308",
		effectKey: "games.oldkingscrown.cards.e174308"
	},
	{
		id: 174309,
		faction: "uprising",
		strength: 6,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174309",
		effectKey: "games.oldkingscrown.cards.e174309"
	},
	{
		id: 174310,
		faction: "uprising",
		strength: 7,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174310",
		effectKey: "games.oldkingscrown.cards.e174310"
	},
	{
		id: 174311,
		faction: "uprising",
		strength: 8,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174311",
		effectKey: "games.oldkingscrown.cards.e174311"
	},
	{
		id: 174312,
		faction: "uprising",
		strength: 9,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174312",
		effectKey: "games.oldkingscrown.cards.e174312"
	},
	{
		id: 174313,
		faction: "uprising",
		strength: 10,
		archetype: "heir",
		votes: 1,
		lore: 1,
		traits: ["pathfinder", "resilient"],
		commands: ["rallySelf"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174313",
		effectKey: "games.oldkingscrown.cards.e174313"
	},
	{
		id: 177400,
		faction: "gathering",
		strength: 0,
		archetype: "ruse",
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["ambush_or_retreat"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177400",
		effectKey: "games.oldkingscrown.cards.e177400"
	},
	{
		id: 177401,
		faction: "gathering",
		strength: 0,
		archetype: "trader",
		votes: 2,
		lore: 2,
		traits: [],
		commands: ["rally2"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177401",
		effectKey: "games.oldkingscrown.cards.e177401"
	},
	{
		id: 177402,
		faction: "gathering",
		strength: 1,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177402",
		effectKey: "games.oldkingscrown.cards.e177402"
	},
	{
		id: 177403,
		faction: "gathering",
		strength: 2,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177403",
		effectKey: "games.oldkingscrown.cards.e177403"
	},
	{
		id: 177404,
		faction: "gathering",
		strength: 3,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177404",
		effectKey: "games.oldkingscrown.cards.e177404"
	},
	{
		id: 177405,
		faction: "gathering",
		strength: 4,
		archetype: "follower",
		votes: 0,
		lore: 1,
		traits: ["invulnerable"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177405",
		effectKey: "games.oldkingscrown.cards.e177405"
	},
	{
		id: 177406,
		faction: "gathering",
		strength: 5,
		archetype: "agent",
		votes: 2,
		lore: 1,
		traits: [],
		commands: ["deadly"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177406",
		effectKey: "games.oldkingscrown.cards.e177406"
	},
	{
		id: 177407,
		faction: "gathering",
		strength: 5,
		archetype: "cavalry",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: ["flank"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177407",
		effectKey: "games.oldkingscrown.cards.e177407"
	},
	{
		id: 177408,
		faction: "gathering",
		strength: 5,
		archetype: "warMachine",
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["deploy1_autumn"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177408",
		effectKey: "games.oldkingscrown.cards.e177408"
	},
	{
		id: 177409,
		faction: "gathering",
		strength: 6,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177409",
		effectKey: "games.oldkingscrown.cards.e177409"
	},
	{
		id: 177410,
		faction: "gathering",
		strength: 7,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177410",
		effectKey: "games.oldkingscrown.cards.e177410"
	},
	{
		id: 177411,
		faction: "gathering",
		strength: 8,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177411",
		effectKey: "games.oldkingscrown.cards.e177411"
	},
	{
		id: 177412,
		faction: "gathering",
		strength: 9,
		archetype: "captain",
		votes: 1,
		lore: 1,
		traits: ["pathfinder"],
		commands: [],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177412",
		effectKey: "games.oldkingscrown.cards.e177412"
	},
	{
		id: 177413,
		faction: "gathering",
		strength: 10,
		archetype: "heir",
		votes: 1,
		lore: 1,
		traits: ["pathfinder", "resilient"],
		commands: ["rallySelf"],
		basic: !0,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177413",
		effectKey: "games.oldkingscrown.cards.e177413"
	},
	{
		id: 174014,
		faction: "nobility",
		strength: 11,
		archetype: "champion",
		cost: 2,
		votes: 2,
		lore: 0,
		traits: ["resilient"],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174014",
		effectKey: "games.oldkingscrown.cards.e174014"
	},
	{
		id: 174015,
		faction: "nobility",
		strength: 5,
		archetype: "trader",
		cost: 3,
		votes: 2,
		lore: 0,
		traits: ["invulnerable"],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174015",
		effectKey: "games.oldkingscrown.cards.e174015"
	},
	{
		id: 174016,
		faction: "nobility",
		strength: 10,
		archetype: "heir",
		cost: 4,
		votes: 1,
		lore: 1,
		traits: ["pathfinder", "resilient"],
		commands: ["rallySelf"],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174016",
		effectKey: "games.oldkingscrown.cards.e174016"
	},
	{
		id: 174017,
		faction: "nobility",
		strength: 3,
		archetype: "warMachine",
		cost: 2,
		votes: 0,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["deploy1_autumn"],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174017",
		effectKey: "games.oldkingscrown.cards.e174017"
	},
	{
		id: 174414,
		faction: "clans",
		strength: 11,
		archetype: "champion",
		cost: 2,
		votes: 0,
		lore: 2,
		traits: ["pathfinder", "resilient"],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174414",
		effectKey: "games.oldkingscrown.cards.e174414"
	},
	{
		id: 174415,
		faction: "clans",
		strength: 3,
		archetype: "cavalry",
		cost: 3,
		votes: 0,
		lore: 0,
		traits: [],
		commands: ["flank", "deadly"],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174415",
		effectKey: "games.oldkingscrown.cards.e174415"
	},
	{
		id: 174416,
		faction: "clans",
		strength: 11,
		archetype: "cavalry",
		cost: 5,
		votes: 0,
		lore: 2,
		traits: ["invulnerable", "pathfinder"],
		commands: ["flank"],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174416",
		effectKey: "games.oldkingscrown.cards.e174416"
	},
	{
		id: 174314,
		faction: "uprising",
		strength: 11,
		archetype: "champion",
		cost: 2,
		votes: 2,
		lore: 2,
		traits: [],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174314",
		effectKey: "games.oldkingscrown.cards.e174314"
	},
	{
		id: 174315,
		faction: "uprising",
		strength: 5,
		archetype: "agent",
		cost: 3,
		votes: 0,
		lore: 0,
		traits: ["resilient"],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174315",
		effectKey: "games.oldkingscrown.cards.e174315"
	},
	{
		id: 174316,
		faction: "uprising",
		strength: 5,
		archetype: "agent",
		cost: 5,
		votes: 0,
		lore: 0,
		traits: ["resilient"],
		commands: ["ambush"],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n174316",
		effectKey: "games.oldkingscrown.cards.e174316"
	},
	{
		id: 177414,
		faction: "gathering",
		strength: 11,
		archetype: "champion",
		cost: 2,
		votes: 1,
		lore: 2,
		traits: ["resilient"],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177414",
		effectKey: "games.oldkingscrown.cards.e177414"
	},
	{
		id: 177415,
		faction: "gathering",
		strength: 5,
		archetype: "captain",
		cost: 2,
		votes: 1,
		lore: 0,
		traits: ["invulnerable"],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177415",
		effectKey: "games.oldkingscrown.cards.e177415"
	},
	{
		id: 177416,
		faction: "gathering",
		strength: 5,
		archetype: "cavalry",
		cost: 3,
		votes: 0,
		lore: 0,
		traits: ["resilient"],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177416",
		effectKey: "games.oldkingscrown.cards.e177416"
	},
	{
		id: 177417,
		faction: "gathering",
		strength: 3,
		archetype: "agent",
		cost: 4,
		votes: 0,
		lore: 0,
		traits: ["resilient"],
		commands: [],
		basic: !1,
		kind: "faction",
		nameKey: "games.oldkingscrown.cards.n177417",
		effectKey: "games.oldkingscrown.cards.e177417"
	},
	{
		id: 176700,
		faction: "nobility",
		cost: 3,
		kind: "hq",
		nameKey: "games.oldkingscrown.cards.n176700",
		effectKey: "games.oldkingscrown.cards.e176700"
	},
	{
		id: 177e3,
		faction: "clans",
		cost: 2,
		kind: "hq",
		nameKey: "games.oldkingscrown.cards.n177000",
		effectKey: "games.oldkingscrown.cards.e177000"
	},
	{
		id: 177100,
		faction: "clans",
		cost: 2,
		kind: "hq",
		nameKey: "games.oldkingscrown.cards.n177100",
		effectKey: "games.oldkingscrown.cards.e177100"
	},
	{
		id: 176800,
		faction: "uprising",
		cost: 2,
		kind: "hq",
		nameKey: "games.oldkingscrown.cards.n176800",
		effectKey: "games.oldkingscrown.cards.e176800"
	},
	{
		id: 176900,
		faction: "uprising",
		cost: 2,
		kind: "hq",
		nameKey: "games.oldkingscrown.cards.n176900",
		effectKey: "games.oldkingscrown.cards.e176900"
	},
	{
		id: 177200,
		faction: "gathering",
		cost: 2,
		kind: "hq",
		nameKey: "games.oldkingscrown.cards.n177200",
		effectKey: "games.oldkingscrown.cards.e177200"
	},
	{
		id: 175e3,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175000",
		effectKey: "games.oldkingscrown.cards.e175000"
	},
	{
		id: 175001,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175001",
		effectKey: "games.oldkingscrown.cards.e175001"
	},
	{
		id: 175002,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175002",
		effectKey: "games.oldkingscrown.cards.e175002"
	},
	{
		id: 175003,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175003",
		effectKey: "games.oldkingscrown.cards.e175003"
	},
	{
		id: 175004,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175004",
		effectKey: "games.oldkingscrown.cards.e175004"
	},
	{
		id: 175005,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175005",
		effectKey: "games.oldkingscrown.cards.e175005"
	},
	{
		id: 175006,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175006",
		effectKey: "games.oldkingscrown.cards.e175006"
	},
	{
		id: 175007,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175007",
		effectKey: "games.oldkingscrown.cards.e175007"
	},
	{
		id: 175008,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175008",
		effectKey: "games.oldkingscrown.cards.e175008"
	},
	{
		id: 175009,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175009",
		effectKey: "games.oldkingscrown.cards.e175009"
	},
	{
		id: 175010,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175010",
		effectKey: "games.oldkingscrown.cards.e175010"
	},
	{
		id: 175011,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175011",
		effectKey: "games.oldkingscrown.cards.e175011"
	},
	{
		id: 175012,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175012",
		effectKey: "games.oldkingscrown.cards.e175012"
	},
	{
		id: 175013,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175013",
		effectKey: "games.oldkingscrown.cards.e175013"
	},
	{
		id: 175014,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175014",
		effectKey: "games.oldkingscrown.cards.e175014"
	},
	{
		id: 175015,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175015",
		effectKey: "games.oldkingscrown.cards.e175015"
	},
	{
		id: 175016,
		suit: "opulence",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175016",
		effectKey: "games.oldkingscrown.cards.e175016"
	},
	{
		id: 175017,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175017",
		effectKey: "games.oldkingscrown.cards.e175017"
	},
	{
		id: 175018,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175018",
		effectKey: "games.oldkingscrown.cards.e175018"
	},
	{
		id: 175019,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175019",
		effectKey: "games.oldkingscrown.cards.e175019"
	},
	{
		id: 175020,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175020",
		effectKey: "games.oldkingscrown.cards.e175020"
	},
	{
		id: 175021,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175021",
		effectKey: "games.oldkingscrown.cards.e175021"
	},
	{
		id: 175022,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175022",
		effectKey: "games.oldkingscrown.cards.e175022"
	},
	{
		id: 175023,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175023",
		effectKey: "games.oldkingscrown.cards.e175023"
	},
	{
		id: 175024,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175024",
		effectKey: "games.oldkingscrown.cards.e175024"
	},
	{
		id: 175025,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175025",
		effectKey: "games.oldkingscrown.cards.e175025"
	},
	{
		id: 175026,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175026",
		effectKey: "games.oldkingscrown.cards.e175026"
	},
	{
		id: 175027,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175027",
		effectKey: "games.oldkingscrown.cards.e175027"
	},
	{
		id: 175028,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175028",
		effectKey: "games.oldkingscrown.cards.e175028"
	},
	{
		id: 175029,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175029",
		effectKey: "games.oldkingscrown.cards.e175029"
	},
	{
		id: 175030,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175030",
		effectKey: "games.oldkingscrown.cards.e175030"
	},
	{
		id: 175031,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175031",
		effectKey: "games.oldkingscrown.cards.e175031"
	},
	{
		id: 175032,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175032",
		effectKey: "games.oldkingscrown.cards.e175032"
	},
	{
		id: 175033,
		suit: "mystery",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175033",
		effectKey: "games.oldkingscrown.cards.e175033"
	},
	{
		id: 175034,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175034",
		effectKey: "games.oldkingscrown.cards.e175034"
	},
	{
		id: 175035,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175035",
		effectKey: "games.oldkingscrown.cards.e175035"
	},
	{
		id: 175036,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175036",
		effectKey: "games.oldkingscrown.cards.e175036"
	},
	{
		id: 175037,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175037",
		effectKey: "games.oldkingscrown.cards.e175037"
	},
	{
		id: 175038,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175038",
		effectKey: "games.oldkingscrown.cards.e175038"
	},
	{
		id: 175039,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175039",
		effectKey: "games.oldkingscrown.cards.e175039"
	},
	{
		id: 175040,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175040",
		effectKey: "games.oldkingscrown.cards.e175040"
	},
	{
		id: 175041,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175041",
		effectKey: "games.oldkingscrown.cards.e175041"
	},
	{
		id: 175042,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175042",
		effectKey: "games.oldkingscrown.cards.e175042"
	},
	{
		id: 175043,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175043",
		effectKey: "games.oldkingscrown.cards.e175043"
	},
	{
		id: 175044,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175044",
		effectKey: "games.oldkingscrown.cards.e175044"
	},
	{
		id: 175045,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175045",
		effectKey: "games.oldkingscrown.cards.e175045"
	},
	{
		id: 175046,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175046",
		effectKey: "games.oldkingscrown.cards.e175046"
	},
	{
		id: 175047,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175047",
		effectKey: "games.oldkingscrown.cards.e175047"
	},
	{
		id: 175048,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175048",
		effectKey: "games.oldkingscrown.cards.e175048"
	},
	{
		id: 175049,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175049",
		effectKey: "games.oldkingscrown.cards.e175049"
	},
	{
		id: 175050,
		suit: "force",
		kind: "kingdom",
		nameKey: "games.oldkingscrown.cards.n175050",
		effectKey: "games.oldkingscrown.cards.e175050"
	},
	{
		id: 175700,
		suit: "opulence",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175700",
		effectKey: "games.oldkingscrown.cards.e175700"
	},
	{
		id: 175701,
		suit: "opulence",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175701",
		effectKey: "games.oldkingscrown.cards.e175701"
	},
	{
		id: 175702,
		suit: "opulence",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175702",
		effectKey: "games.oldkingscrown.cards.e175702"
	},
	{
		id: 175703,
		suit: "opulence",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175703",
		effectKey: "games.oldkingscrown.cards.e175703"
	},
	{
		id: 175704,
		suit: "opulence",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175704",
		effectKey: "games.oldkingscrown.cards.e175704"
	},
	{
		id: 175705,
		suit: "mystery",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175705",
		effectKey: "games.oldkingscrown.cards.e175705"
	},
	{
		id: 175706,
		suit: "mystery",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175706",
		effectKey: "games.oldkingscrown.cards.e175706"
	},
	{
		id: 175707,
		suit: "mystery",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175707",
		effectKey: "games.oldkingscrown.cards.e175707"
	},
	{
		id: 175708,
		suit: "mystery",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175708",
		effectKey: "games.oldkingscrown.cards.e175708"
	},
	{
		id: 175709,
		suit: "mystery",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175709",
		effectKey: "games.oldkingscrown.cards.e175709"
	},
	{
		id: 175710,
		suit: "force",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175710",
		effectKey: "games.oldkingscrown.cards.e175710"
	},
	{
		id: 175711,
		suit: "force",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175711",
		effectKey: "games.oldkingscrown.cards.e175711"
	},
	{
		id: 175712,
		suit: "force",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175712",
		effectKey: "games.oldkingscrown.cards.e175712"
	},
	{
		id: 175713,
		suit: "force",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175713",
		effectKey: "games.oldkingscrown.cards.e175713"
	},
	{
		id: 175714,
		suit: "force",
		kind: "wild",
		nameKey: "games.oldkingscrown.cards.n175714",
		effectKey: "games.oldkingscrown.cards.e175714"
	},
	{
		id: 170700,
		faction: "clans",
		timing: "spring",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n170700",
		effectKey: "games.oldkingscrown.cards.e170700"
	},
	{
		id: 170800,
		faction: "clans",
		timing: "autumn",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n170800",
		effectKey: "games.oldkingscrown.cards.e170800"
	},
	{
		id: 170900,
		faction: "clans",
		timing: "autumn",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n170900",
		effectKey: "games.oldkingscrown.cards.e170900"
	},
	{
		id: 171e3,
		faction: "clans",
		timing: "day",
		markers: 3,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n171000",
		effectKey: "games.oldkingscrown.cards.e171000"
	},
	{
		id: 171400,
		faction: "gathering",
		timing: "day",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n171400",
		effectKey: "games.oldkingscrown.cards.e171400"
	},
	{
		id: 171500,
		faction: "gathering",
		timing: "day",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n171500",
		effectKey: "games.oldkingscrown.cards.e171500"
	},
	{
		id: 171600,
		faction: "gathering",
		timing: "spring",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n171600",
		effectKey: "games.oldkingscrown.cards.e171600"
	},
	{
		id: 171700,
		faction: "gathering",
		timing: "autumn",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n171700",
		effectKey: "games.oldkingscrown.cards.e171700"
	},
	{
		id: 172e3,
		faction: "uprising",
		timing: "spring",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n172000",
		effectKey: "games.oldkingscrown.cards.e172000"
	},
	{
		id: 172100,
		faction: "uprising",
		timing: "spring",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n172100",
		effectKey: "games.oldkingscrown.cards.e172100"
	},
	{
		id: 172200,
		faction: "uprising",
		timing: "spring",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n172200",
		effectKey: "games.oldkingscrown.cards.e172200"
	},
	{
		id: 172300,
		faction: "uprising",
		timing: "day",
		markers: 3,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n172300",
		effectKey: "games.oldkingscrown.cards.e172300"
	},
	{
		id: 172500,
		faction: "nobility",
		timing: "spring",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n172500",
		effectKey: "games.oldkingscrown.cards.e172500"
	},
	{
		id: 172600,
		faction: "nobility",
		timing: "bidReveal",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n172600",
		effectKey: "games.oldkingscrown.cards.e172600"
	},
	{
		id: 172700,
		faction: "nobility",
		timing: "autumn",
		markers: 0,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n172700",
		effectKey: "games.oldkingscrown.cards.e172700"
	},
	{
		id: 172800,
		faction: "nobility",
		timing: "spring",
		markers: 2,
		kind: "tactic",
		nameKey: "games.oldkingscrown.cards.n172800",
		effectKey: "games.oldkingscrown.cards.e172800"
	},
	{
		id: 175100,
		strength: 11,
		archetype: "champion",
		votes: 2,
		lore: 0,
		traits: ["resilient"],
		commands: [],
		kind: "aeronaut",
		nameKey: "games.oldkingscrown.cards.n175100",
		effectKey: "games.oldkingscrown.cards.e175100"
	},
	{
		id: 175101,
		strength: 5,
		archetype: "agent",
		votes: 0,
		lore: 2,
		traits: [],
		commands: ["retreat"],
		kind: "aeronaut",
		nameKey: "games.oldkingscrown.cards.n175101",
		effectKey: "games.oldkingscrown.cards.e175101"
	},
	{
		id: 175102,
		strength: 1,
		archetype: "ruse",
		votes: 2,
		lore: 0,
		traits: ["invulnerable"],
		commands: ["rallyAny2"],
		kind: "aeronaut",
		nameKey: "games.oldkingscrown.cards.n175102",
		effectKey: "games.oldkingscrown.cards.e175102"
	},
	{
		id: 175103,
		strength: 5,
		archetype: "cavalry",
		votes: 0,
		lore: 2,
		traits: ["invulnerable"],
		commands: ["flank", "deploy1_autumn"],
		kind: "aeronaut",
		nameKey: "games.oldkingscrown.cards.n175103",
		effectKey: "games.oldkingscrown.cards.e175103"
	},
	{
		id: 175200,
		faction: "nobility",
		strength: 13,
		archetype: "creature",
		votes: 0,
		lore: 0,
		traits: [],
		commands: [],
		kind: "creature",
		nameKey: "games.oldkingscrown.cards.n175200",
		effectKey: "games.oldkingscrown.cards.e175200"
	},
	{
		id: 175300,
		faction: "uprising",
		strength: 13,
		archetype: "creature",
		votes: 0,
		lore: 0,
		traits: [],
		commands: [],
		kind: "creature",
		nameKey: "games.oldkingscrown.cards.n175300",
		effectKey: "games.oldkingscrown.cards.e175300"
	},
	{
		id: 175400,
		faction: "clans",
		strength: 13,
		archetype: "creature",
		votes: 0,
		lore: 0,
		traits: [],
		commands: [],
		kind: "creature",
		nameKey: "games.oldkingscrown.cards.n175400",
		effectKey: "games.oldkingscrown.cards.e175400"
	},
	{
		id: 175500,
		faction: "gathering",
		strength: 13,
		archetype: "creature",
		votes: 0,
		lore: 0,
		traits: [],
		commands: [],
		kind: "creature",
		nameKey: "games.oldkingscrown.cards.n175500",
		effectKey: "games.oldkingscrown.cards.e175500"
	},
	{
		id: 177700,
		strength: 3,
		archetype: "follower",
		traits: ["invulnerable"],
		advanced: !1,
		count: 1,
		tier: "bronze",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177700",
		effectKey: "games.oldkingscrown.cards.e177700"
	},
	{
		id: 177701,
		strength: 3,
		archetype: "follower",
		traits: ["invulnerable"],
		advanced: !1,
		count: 1,
		tier: "bronze",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177701",
		effectKey: "games.oldkingscrown.cards.e177701"
	},
	{
		id: 177702,
		strength: 3,
		archetype: "follower",
		traits: ["invulnerable"],
		advanced: !1,
		count: 1,
		tier: "bronze",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177702",
		effectKey: "games.oldkingscrown.cards.e177702"
	},
	{
		id: 177703,
		strength: 5,
		archetype: "warMachine",
		traits: ["invulnerable"],
		advanced: !1,
		count: 1,
		tier: "bronze",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177703",
		effectKey: "games.oldkingscrown.cards.e177703"
	},
	{
		id: 177704,
		strength: 1,
		archetype: "ruse",
		traits: ["invulnerable"],
		advanced: !1,
		count: 1,
		tier: "bronze",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177704",
		effectKey: "games.oldkingscrown.cards.e177704"
	},
	{
		id: 177705,
		strength: 8,
		archetype: "captain",
		traits: [],
		advanced: !1,
		count: 1,
		tier: "silver",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177705",
		effectKey: "games.oldkingscrown.cards.e177705"
	},
	{
		id: 177706,
		strength: 8,
		archetype: "captain",
		traits: [],
		advanced: !1,
		count: 1,
		tier: "silver",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177706",
		effectKey: "games.oldkingscrown.cards.e177706"
	},
	{
		id: 177707,
		strength: 5,
		archetype: "warMachine",
		traits: ["invulnerable"],
		advanced: !1,
		count: 1,
		tier: "silver",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177707",
		effectKey: "games.oldkingscrown.cards.e177707"
	},
	{
		id: 177708,
		strength: 5,
		archetype: "agent",
		traits: [],
		advanced: !1,
		count: 1,
		tier: "silver",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177708",
		effectKey: "games.oldkingscrown.cards.e177708"
	},
	{
		id: 177709,
		strength: 10,
		archetype: "heir",
		traits: ["resilient"],
		advanced: !1,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177709",
		effectKey: "games.oldkingscrown.cards.e177709"
	},
	{
		id: 177710,
		strength: 3,
		archetype: "ruse",
		traits: ["invulnerable"],
		advanced: !1,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177710",
		effectKey: "games.oldkingscrown.cards.e177710"
	},
	{
		id: 177711,
		strength: 5,
		archetype: "agent",
		traits: [],
		advanced: !1,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177711",
		effectKey: "games.oldkingscrown.cards.e177711"
	},
	{
		id: 177712,
		strength: 11,
		archetype: "heir",
		traits: ["invulnerable"],
		advanced: !0,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177712",
		effectKey: "games.oldkingscrown.cards.e177712"
	},
	{
		id: 177713,
		strength: 11,
		archetype: "heir",
		traits: ["invulnerable"],
		advanced: !0,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177713",
		effectKey: "games.oldkingscrown.cards.e177713"
	},
	{
		id: 177714,
		strength: 13,
		archetype: "champion",
		traits: ["resilient"],
		advanced: !0,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177714",
		effectKey: "games.oldkingscrown.cards.e177714"
	},
	{
		id: 177715,
		strength: 13,
		archetype: "champion",
		traits: ["resilient"],
		advanced: !0,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177715",
		effectKey: "games.oldkingscrown.cards.e177715"
	},
	{
		id: 177716,
		strength: 6,
		archetype: "agent",
		traits: ["resilient"],
		advanced: !0,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177716",
		effectKey: "games.oldkingscrown.cards.e177716"
	},
	{
		id: 177717,
		strength: 6,
		archetype: "agent",
		traits: ["resilient"],
		advanced: !0,
		count: 1,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n177717",
		effectKey: "games.oldkingscrown.cards.e177717"
	},
	{
		id: 178100,
		strength: 6,
		archetype: "ruse",
		traits: ["invulnerable"],
		advanced: !0,
		count: 2,
		tier: "gold",
		kind: "simulacrum",
		nameKey: "games.oldkingscrown.cards.n178100",
		effectKey: "games.oldkingscrown.cards.e178100"
	}
], S = Object.fromEntries(x.map((e) => [e.id, e])), re = [
	{
		id: 177900,
		regions: [
			1,
			2,
			0
		],
		suits: [
			"force",
			"opulence",
			"mystery"
		],
		direction: "left",
		steal: !1,
		backRegion: 1
	},
	{
		id: 177901,
		regions: [
			1,
			2,
			0
		],
		suits: [
			"force",
			"opulence",
			"mystery"
		],
		direction: "right",
		steal: !0,
		backRegion: 1
	},
	{
		id: 177902,
		regions: [
			1,
			0,
			2
		],
		suits: [
			"force",
			"mystery",
			"opulence"
		],
		direction: "left",
		steal: !0,
		backRegion: 1
	},
	{
		id: 177903,
		regions: [
			1,
			0,
			2
		],
		suits: [
			"force",
			"mystery",
			"opulence"
		],
		direction: "right",
		steal: !1,
		backRegion: 1
	},
	{
		id: 177904,
		regions: [
			2,
			1,
			0
		],
		suits: [
			"opulence",
			"force",
			"mystery"
		],
		direction: "left",
		steal: !0,
		backRegion: 2
	},
	{
		id: 177905,
		regions: [
			2,
			1,
			0
		],
		suits: [
			"opulence",
			"force",
			"mystery"
		],
		direction: "right",
		steal: !1,
		backRegion: 2
	},
	{
		id: 177906,
		regions: [
			2,
			0,
			1
		],
		suits: [
			"opulence",
			"mystery",
			"force"
		],
		direction: "left",
		steal: !1,
		backRegion: 2
	},
	{
		id: 177907,
		regions: [
			2,
			0,
			1
		],
		suits: [
			"opulence",
			"mystery",
			"force"
		],
		direction: "right",
		steal: !0,
		backRegion: 2
	},
	{
		id: 177908,
		regions: [
			0,
			2,
			1
		],
		suits: [
			"mystery",
			"opulence",
			"force"
		],
		direction: "left",
		steal: !1,
		backRegion: 0
	},
	{
		id: 177909,
		regions: [
			0,
			2,
			1
		],
		suits: [
			"mystery",
			"opulence",
			"force"
		],
		direction: "right",
		steal: !0,
		backRegion: 0
	},
	{
		id: 177910,
		regions: [
			0,
			1,
			2
		],
		suits: [
			"mystery",
			"force",
			"opulence"
		],
		direction: "left",
		steal: !0,
		backRegion: 0
	},
	{
		id: 177911,
		regions: [
			0,
			1,
			2
		],
		suits: [
			"mystery",
			"force",
			"opulence"
		],
		direction: "right",
		steal: !1,
		backRegion: 0
	}
], C = (e, t, n) => e.sim.enabled && e.config.forge.some((e) => e.id === t && e.side === n), ie = (e, t) => e.config.forge.find((e) => e.id === t)?.value ?? 1, ae = (e, t) => e.sim.enabled && t !== null && e.sim.fog[t].length > 0, w = (e, t, n = e.region) => e.sim.threats.includes(t) && ae(e, n), oe = (e, t) => Math.max(1, t + (C(e, 5, "a") ? -1 : +!!C(e, 5, "b"))), se = (e, t) => w(e, 21, Math.floor(t / 2)) && e.sim.ambition !== null && t % 2 === Number(re[e.sim.ambition].direction === "right"), ce = (e, t) => t === "$simulacrum" ? C(e, 17, "b") ? 2 : 1 : C(e, 17, "a") ? 2 : 1;
function le(e) {
	(C(e, 9, "a") || C(e, 9, "b")) && (e.order = e.order.filter((e) => e !== "$simulacrum"), C(e, 9, "a") ? e.order.unshift("$simulacrum") : e.order.push("$simulacrum"));
}
var ue = [
	[-4, 2],
	[-4, 4],
	[-3, 3],
	["-X", "X"],
	[-3, 3],
	[-2, 2],
	[-4, 5],
	[-2, 4],
	[-3, 3],
	[-2, 3],
	[-2, 3],
	[-3, 3],
	[-1, 1],
	[-3, 2],
	[-1, 1],
	["-X", "2X"],
	[-3, 3],
	[-2, 2],
	[-3, 3],
	[-2, 2],
	[-3, 1],
	[-2, 3],
	[-3, 2],
	[-1, 2],
	[-3, 2],
	[-3, 3],
	[-1, 1],
	[-2, 3],
	[-4, 2],
	[-1, 1]
], de = [
	2,
	2,
	2,
	3,
	3,
	3,
	2,
	3,
	2,
	2,
	2,
	3,
	2,
	1,
	1,
	2,
	1,
	2,
	2,
	2,
	3,
	3,
	2,
	2
], T = "$simulacrum", E = {
	move: 520,
	reveal: 650,
	outcome: 1e3,
	season: 450
}, D = (e, t = "", n = {}) => ({
	kind: e,
	actor: t,
	...n
}), O = (e, t) => e.players.find((e) => e.rid === t), k = (e, t) => e.cards.find((e) => e.uid === t), A = (e, t, n) => e.cards.filter((e) => e.owner === t && e.zone === n).sort((e, t) => e.position - t.position), j = (e, t, n) => e.cards.filter((e) => e.zone === "active" && e.faceUp && (!t || e.owner === t) && (n === void 0 || e.region === n)), M = (e, t, n) => !(t === "$simulacrum" && ["kingdom", "wild"].includes(S[n].kind)) && e.cards.some((e) => e.owner === t && e.def === n && [
	"occupying",
	"supply",
	"active"
].includes(e.zone)), fe = (t, n) => e(t.seed, t.cursor++, n);
function pe(e, t) {
	for (let n of Object.keys(e.known)) e.known[n] = e.known[n].filter((e) => !t.includes(e));
}
function N(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; --t) {
		let r = fe(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function P(e, t, n, r) {
	let i = `c${fe(e, 2147483647).toString(36)}`;
	for (; e.cards.some((e) => e.uid === i);) i = `c${fe(e, 2147483647).toString(36)}`;
	let a = {
		uid: i,
		def: t,
		owner: n,
		zone: r,
		position: ++e.serial,
		region: null,
		location: null,
		suit: null,
		parent: null,
		faceUp: ![
			"hand",
			"deck",
			"bid"
		].includes(r),
		influence: 0,
		boons: [],
		strengthBonus: 0,
		guardStrength: 0,
		gainedTraits: [],
		gainedCommands: [],
		gainedRules: [],
		clashGrants: [],
		copy: null,
		fought: []
	};
	return e.cards.push(a), a;
}
function F(e, t, n, r = {}) {
	e.push({
		kind: t,
		rid: n,
		data: r,
		...e.length ? { with: !0 } : {}
	});
}
var me = (e, t) => t >= 0 ? `supporter:${e}:${t}` : `${t === -1 ? "supporterSupply" : t === -2 ? "supporterLost" : "supporterBurned"}:${e}`;
function I(e, t, n, r, i, a) {
	if (!i || n === r) return;
	let o = O(e, t), s = (e, t) => {
		e >= 0 ? o.supporters[e] += t : e === -1 ? o.supporterSupply += t : e === -2 ? o.supporterLost += t : o.supporterBurned += t;
	};
	s(n, -i), s(r, i), F(a, "supporter", t, {
		from: me(t, n),
		to: me(t, r),
		n: i,
		faction: o.faction
	}), e.beat = E.move;
}
function he(e, t, n, r, i) {
	let a = O(e, t), o = a.heralds[n];
	a.heralds[n] = r, o !== r && (F(i, "herald", t, {
		from: o === null ? `seat:${t}` : `location:${o}`,
		to: r === null ? `seat:${t}` : `herald:${t}:${n}`,
		faction: a.faction
	}), e.beat = E.move);
}
function L(e, t, n, r, i, a) {
	if (!i) return;
	let o = O(e, t), s = n === "marker" ? o.markers : o.councilMarkers;
	s[r] += i;
	let c = n === "marker" ? `marker:${t}:${r}` : `councilMarker:${t}:${r}`;
	F(a, n, t, {
		from: i > 0 ? `seat:${t}` : c,
		to: i > 0 ? c : `seat:${t}`,
		n: Math.abs(i),
		faction: o.faction
	}), e.beat = E.move;
}
function R(e, t, n, r, i = {}) {
	n === "hand" && (i.owner ?? t.owner) === "$simulacrum" && (n = "deck"), n === "hand" && t.zone !== "hand" && A(e, i.owner ?? t.owner, "hand").length >= O(e, i.owner ?? t.owner).handSize && (n = "deck");
	let a = ge(t), o = !t.faceUp || t.zone === "hand" || t.zone === "deck", s = t.zone;
	s === "active" && t.region === e.region && e.phase === "summer" && e.clashPlayers.includes(t.owner) && t.fought.push(`${e.year}:${e.region}:${e.clash}`), t.zone === "active" && n !== "active" && (t.influence = 0, e.modules.boonDiscard.push(...t.boons), t.boons = []), t.zone = n, t.position = i.bottom ? ++e.serial : -++e.serial, t.region = i.region ?? null, t.location = i.location ?? null, t.suit = i.suit ?? null, t.parent = i.parent ?? null, t.faceUp = i.faceUp ?? ![
		"deck",
		"hand",
		"bid"
	].includes(n), i.owner && (t.owner = i.owner);
	let c = [
		"deck",
		"hand",
		"bid"
	].includes(n) || !t.faceUp;
	c && pe(e, [t.uid]);
	let l = c ? ["hand", "deck"].includes(n) ? `${n}:${t.owner}` : `hidden:${t.owner}:${t.zone}:${t.region ?? ""}:${t.position}` : t.uid;
	r.push({
		kind: "move",
		rid: t.owner,
		data: {
			from: a,
			to: ge(t),
			...c && o ? {} : { def: t.def },
			uid: l,
			back: S[t.def].faction ?? S[t.def].kind,
			faceDown: c
		},
		...c ? {
			for: [t.owner],
			secret: {
				def: t.def,
				uid: t.uid
			}
		} : {},
		...r.length ? { with: !0 } : {}
	}), e.beat = E.move, s === "council" && n !== "council" && (M(e, t.owner, 175017) || M(e, t.owner, 177100)) && n !== "hand" && e.queue.unshift(D("recoverCouncil", t.owner, { card: t.uid }));
}
var ge = (e) => e.zone === "active" ? `region:${e.region}` : e.zone === "council" ? `council:${e.suit}` : `${e.zone}:${e.owner}`;
function z(e, t) {
	let n = S[t.copy ?? t.def], r = S[t.def], i = [...n.traits ?? []], a = [...n.commands ?? [], ...n.kind === "simulacrum" && n.archetype === "agent" ? ["deadly"] : []], o = (r.strength ?? 0) + t.strengthBonus, s = n.votes ?? 0, c = n.lore ?? 0, l = t.zone === "active" && t.region === e.region && G(e).some((e) => e.owner !== t.owner && e.def === 174316) && n.archetype !== "heir", u = !ve(e, t), d = l ? void 0 : n.archetype, f = [...d ? [d] : [], ...t.owner === "$simulacrum" && t.zone === "active" && w(e, 24, t.region) ? ["follower"] : []];
	u && (i = [], a = [], s = 0, c = 0), t.owner !== "$simulacrum" && t.zone === "active" && w(e, 16, t.region) && (i = i.filter((e) => !["invulnerable", "resilient"].includes(e))), i.push(...t.gainedTraits), a.push(...t.gainedCommands);
	for (let n of t.clashGrants.filter((t) => t.year === e.year && t.region === e.region && t.clash === e.clash)) [
		"invulnerable",
		"pathfinder",
		"resilient"
	].includes(n.key) ? i.push(n.key) : a.push(n.key);
	return M(e, t.owner, 177e3) && i.push("resilient"), M(e, t.owner, 175e3) && i.push("pathfinder"), M(e, t.owner, 176700) && !n.votes && [
		"faction",
		"aeronaut",
		"simulacrum"
	].includes(n.kind) && (s += 1), M(e, t.owner, 175002) && f.includes("follower") && (s += e.order[0] === t.owner ? 1 : 2), M(e, t.owner, 175007) && n.lore === 1 && (c += 1), f.includes("heir") && (M(e, t.owner, 175034) && a.push("deadly", "retreat"), M(e, t.owner, 175038) && a.push("flank"), M(e, t.owner, 175040) && a.push("deploy1_autumn"), O(e, t.owner).flags.includes("streets") && a.push("deadly")), M(e, t.owner, 177100) && f.includes("captain") && a.push("flank"), M(e, t.owner, 175035) && (f.includes("follower") || f.includes("cavalry")) && a.push("deploy1_autumn"), M(e, t.owner, 175036) && a.includes("deploy1_autumn") && a.push("deploy1_spring"), e.players.some((e) => e.flags.includes("arrows")) && (i = i.filter((e) => e !== "invulnerable")), t.boons.includes(18) && (o += 5), t.boons.includes(13) && (o += 10), t.boons.includes(7) && i.push("invulnerable"), t.boons.includes(8) && a.push("ambush"), t.boons.includes(9) && a.push("deadly"), t.boons.includes(12) && a.push("flank"), t.boons.includes(5) && a.push("rally2"), f.includes("heir") && O(e, t.owner).flags.includes("regalGuard") && i.push("invulnerable"), f.includes("heir") && (C(e, 18, t.owner === "$simulacrum" ? "b" : "a") && i.push("invulnerable"), C(e, 19, t.owner === "$simulacrum" ? "b" : "a") && a.push("deadly"), t.owner === "$simulacrum" && (C(e, 18, "b") || C(e, 19, "b")) && a.push("rallySelf")), t.owner === "$simulacrum" && (C(e, 22, "a") && (i = i.filter((e) => e !== "resilient")), t.zone === "active" && w(e, 1, t.region) && a.push("deadly"), t.zone === "active" && w(e, 2, t.region) && i.push("invulnerable"), C(e, 22, "b") && a.includes("deadly") && i.push("invulnerable")), e.players.some((e) => e.flags.includes("arrows")) && (i = i.filter((e) => e !== "invulnerable")), t.zone === "active" && t.region === e.region && G(e).some((e) => e.owner !== t.owner && e.boons.includes(16)) && (a = []), {
		strength: o,
		votes: s,
		lore: c,
		traits: [...new Set(i)],
		commands: [...new Set(a)],
		archetype: d,
		archetypes: [...new Set(f)],
		suit: n.suit
	};
}
var _e = (e, t, n) => z(e, t).archetypes.includes(n);
function ve(e, t) {
	if (t.owner === "$simulacrum" && ["kingdom", "wild"].includes(S[t.def].kind)) return !1;
	if (t.zone !== "active") return !0;
	let n = (t, n) => t !== n && !e.agreements.some((e) => e.alliance && e.status === "active" && [e.a, e.b].includes(t) && [e.a, e.b].includes(n)), r = e.cards.some((e) => e.def === 175048 && e.zone === "supply" && e.region === t.region && n(e.owner, t.owner)), i = t.region === e.region && G(e).some((e) => e.def === 174316 && n(e.owner, t.owner)) && S[t.copy ?? t.def].archetype !== "heir";
	return !r && !i;
}
var ye = (e, t) => [.../* @__PURE__ */ new Set([...ve(e, t) ? [t.copy ?? t.def] : [], ...t.gainedRules])], be = (e, t, n) => ye(e, t).includes(n);
function B(e, t, n, r, i = {}) {
	let a = i.min ?? 1;
	if (!r.length || i.max === 0 || r.length < a) {
		e.queue.unshift(...i.after ?? []);
		return;
	}
	let o = t === "$simulacrum" ? e.order.filter((t) => e.humans.includes(t)).at(-1) : t;
	e.prompts.push({
		id: e.serial++,
		actor: o,
		...t === "$simulacrum" ? { subject: T } : {},
		kind: n,
		options: r,
		min: a,
		max: i.max ?? 1,
		after: [],
		...i
	});
}
var V = (e, t, n, r = {}) => ({
	id: e,
	label: t,
	tasks: n,
	...r
});
function H(e, t, n, r, i, a) {
	e.log.push({
		key: t,
		...n ? { actor: n } : {},
		...r ? { card: r } : {},
		...i === void 0 ? {} : { n: i },
		...a ? { target: a } : {}
	});
}
function xe(e, t, n, r) {
	let i = O(e, t), a = i.handSize;
	i.handSize = Math.max(3, Math.min(8, i.handSize + n)), F(r, "handSize", t, { n: i.handSize - a }), A(e, t, "hand").length > i.handSize && e.queue.unshift(D("discardHand", t, { mode: "limit" }));
}
function U(e, t, n, r, i) {
	let a = O(e, t), o = n === "influence" && e.players.some((e) => e.flags.includes("abundance")) ? r * 2 : r;
	a[n] = Math.max(0, a[n] + o), F(i, n, t, { n: o }), r > 0 && n === "lore" && e.queue.unshift(D(t === "$simulacrum" ? "simSpend" : "buySite", t));
}
function Se(e, t, n, r, i = !1) {
	if (t === "$simulacrum") {
		Ce(e, n).forEach((t) => R(e, t, "hand", r));
		return;
	}
	let a = O(e, t), o = i ? Math.max(0, a.handSize - A(e, t, "hand").length) : n;
	for (let n = 0; n < o; n += 1) {
		let n = A(e, t, "deck");
		if (n.length) {
			R(e, n[0], "hand", r);
			continue;
		}
		let i = N(e, A(e, t, "discard"));
		if (pe(e, i.map((e) => e.uid)), i.forEach((t) => {
			t.zone = "deck", t.position = ++e.serial, t.faceUp = !1;
		}), M(e, t, 175003)) {
			let n = e.cards.find((e) => e.owner === t && e.def === 175003 && e.zone === "supply");
			n.zone = "burned", e.kingdomDiscard.push(n.def);
		} else t !== "$simulacrum" && xe(e, t, -1, r);
		o = Math.max(0, a.handSize - A(e, t, "hand").length);
		for (let n of A(e, t, "deck").slice(0, o)) R(e, n, "hand", r);
		H(e, "attrition", t);
		break;
	}
}
function Ce(e, t) {
	let n = [];
	for (let r = 0; r < t; r += 1) {
		if (!A(e, "$simulacrum", "deck").length) {
			let t = N(e, A(e, T, "discard"));
			pe(e, t.map((e) => e.uid)), t.forEach((t) => {
				t.zone = "deck", t.faceUp = !1, t.position = ++e.serial;
			});
			let n = C(e, 11, "a") ? "gold" : C(e, 11, "b") ? t.some((e) => S[e.def].tier === "bronze") ? "bronze" : "silver" : null;
			if (n) {
				let r = N(e, t.filter((e) => S[e.def].tier === n))[0];
				r && (r.zone = "lost");
			}
		}
		let t = A(e, T, "deck")[0];
		if (!t) break;
		t.zone = "supply", n.push(t);
	}
	return n;
}
function W(e, t, n) {
	return A(e, t, "council").filter((e) => e.suit === n).reduce((t, n) => t + z(e, n).votes, 0) + (t === "$simulacrum" || M(e, t, 176900) || A(e, t, "council").some((e) => e.def === 177415) ? O(e, t).councilMarkers[n] : 0);
}
function we(e, t, n) {
	let r = O(e, t);
	return !r.used.includes(n) && (r.used.push(n), !0);
}
var Te = (e, t) => t.fought.some((n) => n.startsWith(`${e.year}:${t.region}:`) && Number(n.split(":")[2]) < e.clash), G = (e, t) => j(e, t, e.region ?? void 0).filter((t) => e.clashPlayers.includes(t.owner) && !Te(e, t));
function Ee(e, t, n) {
	let r = ge(t);
	e.cards.filter((e) => e.parent === t.uid).forEach((t) => R(e, t, "hand", n)), t.def === 175016 && t.owner !== "$simulacrum" && xe(e, t.owner, -1, n), t.zone = "burned", e.kingdomDiscard.push(t.def), F(n, "move", t.owner, {
		from: r,
		to: "kingdomDiscard",
		def: t.def
	}), e.beat = E.move;
}
//#endregion
//#region src/games/oldkingscrown/negotiation.ts
var De = (e, t) => O(e, t).tradeCards - e.agreements.filter((e) => e.binding && e.status === "active" && [e.a, e.b].includes(t)).length;
function Oe(e, t) {
	let n = O(e, t), r = [];
	for (let i of [
		"influence",
		"lore",
		"supporters",
		"tradeCards"
	]) {
		let a = i === "supporters" ? n.supporterSupply : i === "tradeCards" ? De(e, t) : n[i];
		for (let e = 1; e <= a; e += 1) r.push({
			kind: i,
			n: e
		});
	}
	for (let n of e.cards.filter((e) => e.owner === t && (["hand", "site"].includes(e.zone) || ["kingdom", "wild"].includes(S[e.def].kind) && ["supply", "occupying"].includes(e.zone)))) r.push({
		kind: n.zone === "hand" ? "hand" : n.zone === "site" ? "site" : "kingdom",
		uid: n.uid,
		n: 1
	});
	return n.tactics.forEach((e) => r.push({
		kind: "tactic",
		index: e.def,
		n: 1
	})), n.boons.forEach((e) => r.push({
		kind: "boon",
		index: e,
		n: 1
	})), n.markers.forEach((e, t) => {
		for (let n = 1; n <= e; n += 1) r.push({
			kind: "mapMarker",
			index: t,
			n
		});
	}), n.councilMarkers.forEach((e, t) => {
		for (let n = 1; n <= e; n += 1) r.push({
			kind: "councilMarker",
			index: t,
			n
		});
	}), e.favour.owner === t && r.push({
		kind: "favour",
		n: 1
	}), r;
}
var ke = (e) => `${e.kind}:${e.uid ?? e.index ?? ""}`;
function Ae(e, t) {
	let n = [];
	for (let r of t) {
		let t = n.filter((t) => t.some((t) => e.agreements.some((e) => e.alliance && e.status === "active" && [e.a, e.b].includes(r) && [e.a, e.b].includes(t))));
		if (!t.length) n.push([r]);
		else {
			let e = [r, ...t.flat()];
			for (let e of t) n.splice(n.indexOf(e), 1);
			n.push(e);
		}
	}
	return n;
}
function je(e, t, n) {
	let r = t.actor;
	switch (t.kind) {
		case "negotiationStart":
			if (!e.config.negotiating || e.humans.length < 3) return !0;
			for (let t of e.agreements) t.alliance && t.status === "active" && (t.status = "expired");
			return e.step = "negotiation", e.queue.unshift(...e.order.filter((t) => e.humans.includes(t)).map((e) => D("negotiate", e))), !0;
		case "negotiate": {
			let t = [];
			for (let n of e.humans.filter((e) => e !== r)) t.push(V(`barter:${n}`, "proposeBarter", [D("tradeBegin", r, { target: n })], { player: n })), t.push(V(`promise:${n}`, "proposeAgreement", [D("agreementCompose", r, { target: n })], { player: n })), De(e, r) > 0 && De(e, n) > 0 && t.push(V(`alliance:${n}`, "proposeAlliance", [D("agreementPropose", r, {
				target: n,
				mode: "alliance"
			}), D("negotiate", r)], { player: n }));
			return t.push(V("done", "finishNegotiation", [])), B(e, r, "negotiate", t), !0;
		}
		case "tradeBegin": return e.trade = {
			a: r,
			b: t.target,
			give: [],
			take: [],
			stage: "offer"
		}, e.queue.unshift(D("tradeCompose", r)), !0;
		case "tradeCompose": {
			let t = e.trade, n = r === t.a ? t.give : t.take, i = Oe(e, r).filter((e) => !n.some((t) => ke(t) === ke(e))).map((t, n) => V(`item:${n}`, `trade:${t.kind}`, [D("tradeAdd", r, {
				key: t.kind,
				n: t.n,
				card: t.uid,
				source: t.index
			}), D("tradeCompose", r)], {
				...t.uid ? {
					card: t.uid,
					def: k(e, t.uid).def
				} : {},
				n: t.n,
				...t.index === void 0 ? {} : { suit: t.index }
			}));
			return n.length && i.push(V("clear", "clearOffer", [D("tradeClear", r), D("tradeCompose", r)])), i.push(V("review", r === t.a ? "requestCounteroffer" : "submitCounteroffer", [D("tradeNext", r)]), V("cancel", "cancelBarter", [D("tradeCancel", t.a)])), B(e, r, "tradeCompose", i), !0;
		}
		case "tradeAdd": {
			let n = e.trade;
			return (r === n.a ? n.give : n.take).push({
				kind: t.key,
				n: t.n,
				...t.card ? { uid: t.card } : {},
				...t.source === void 0 ? {} : { index: t.source }
			}), !0;
		}
		case "tradeClear": return r === e.trade.a ? e.trade.give = [] : e.trade.take = [], !0;
		case "tradeNext": {
			let t = e.trade;
			return r === t.a && t.stage === "offer" ? (t.stage = "counter", B(e, t.b, "barterInvitation", [V("counter", "makeCounteroffer", [D("tradeCompose", t.b)]), V("decline", "decline", [D("tradeCancel", t.a)])])) : (t.stage = "review", B(e, t.a, "barterReview", [V("accept", "acceptBarter", [D("tradeCommit", t.a)]), V("decline", "decline", [D("tradeCancel", t.a)])])), !0;
		}
		case "tradeCancel": return e.trade = null, e.queue.unshift(D("negotiate", r)), !0;
		case "tradeCommit": {
			let t = e.trade, n = (t, n) => {
				let r = Oe(e, t);
				return n.every((e) => r.some((t) => ke(e) === ke(t) && e.n === t.n));
			}, i = (t, n, r) => {
				let i = A(e, t, "hand").length - n.filter((e) => e.kind === "hand").length + r.filter((e) => e.kind === "hand").length + n.filter((e) => e.kind === "kingdom").reduce((t, n) => t + e.cards.filter((e) => e.parent === n.uid).length, 0);
				return r.filter((t) => t.kind === "kingdom" && k(e, t.uid).zone === "occupying").length <= Math.min(O(e, t).handSize, i);
			};
			if (!n(t.a, t.give) || !n(t.b, t.take) || !i(t.a, t.give, t.take) || !i(t.b, t.take, t.give)) return e.trade = null, e.queue.unshift(D("negotiate", r)), !0;
			let a = [];
			for (let [n, r, i] of [[
				t.a,
				t.b,
				t.give
			], [
				t.b,
				t.a,
				t.take
			]]) for (let t of i) {
				if (t.kind === "hand") {
					let n = k(e, t.uid);
					n.zone = "supply", n.faceUp = !1;
				}
				a.push(D("tradeTransfer", n, {
					target: r,
					key: t.kind,
					n: t.n,
					card: t.uid,
					source: t.index
				}));
			}
			let o = [...t.give.some((e) => e.kind === "lore") ? [D("buySite", t.b)] : [], ...t.take.some((e) => e.kind === "lore") ? [D("buySite", t.a)] : []];
			return e.trade = null, e.queue.unshift(...a, ...o, D("negotiate", r)), H(e, "barter", t.a, void 0, void 0, t.b), !0;
		}
		case "tradeTransfer": {
			let i = O(e, r), a = O(e, t.target), o = t.n;
			if ((t.key === "influence" || t.key === "lore") && (i[t.key] -= o, a[t.key] += o), t.key === "supporters" && (i.supporterSupply -= o, a.supporterSupply += o), t.key === "tradeCards" && (i.tradeCards -= o, a.tradeCards += o), t.key === "hand" && R(e, k(e, t.card), "hand", n, { owner: a.rid }), t.key === "site" && (k(e, t.card).owner = a.rid), t.key === "kingdom") {
				let r = k(e, t.card), o = r.zone === "occupying";
				e.cards.filter((e) => e.parent === r.uid).forEach((t) => R(e, t, "hand", n)), r.def === 175016 && xe(e, i.rid, -1, n), r.owner = a.rid, o && (r.zone = "supply", r.location = null), o && e.queue.unshift(D("barterGuard", a.rid, { card: r.uid }));
			}
			if (t.key === "tactic") {
				let e = i.tactics.find((e) => e.def === t.source);
				i.tactics = i.tactics.filter((t) => t !== e), a.tactics.push(e);
			}
			return t.key === "boon" && (i.boons.splice(i.boons.indexOf(t.source), 1), a.boons.push(t.source)), t.key === "mapMarker" && (i.markers[t.source] -= o, a.markers[t.source] += o), t.key === "councilMarker" && (i.councilMarkers[t.source] -= o, a.councilMarkers[t.source] += o), t.key === "favour" && (e.favour = {
				owner: a.rid,
				uses: 3
			}), F(n, "barter", r, {
				target: a.rid,
				resource: t.key,
				n: o
			}), !0;
		}
		case "barterGuard": {
			let n = k(e, t.card);
			return B(e, r, "occupy", A(e, r, "hand").map((e) => V(e.uid, "card", [D("acquireKingdom", r, {
				target: n.uid,
				card: e.uid,
				def: n.def,
				mode: "barter"
			})], {
				card: e.uid,
				def: e.def
			}))), !0;
		}
		case "agreementCompose": {
			let n = [V("nonbinding", "nonbindingAgreement", [D("agreementPropose", r, {
				target: t.target,
				mode: "nonbinding"
			}), D("negotiate", r)])];
			return De(e, r) > 0 && De(e, t.target) > 0 && n.push(V("binding", "bindingAgreement", [D("agreementPropose", r, {
				target: t.target,
				mode: "binding"
			}), D("negotiate", r)])), B(e, r, "agreementCompose", n, { allowText: !0 }), !0;
		}
		case "agreementPropose": {
			let n = e.serial++, i = {
				id: n,
				a: r,
				b: t.target,
				text: t.text ?? "",
				binding: t.mode !== "nonbinding",
				alliance: t.mode === "alliance",
				status: "proposed"
			};
			return e.agreements.push(i), B(e, i.b, "agreementAccept", [V("accept", "acceptAgreement", [D("agreementAccept", r, { n })]), V("decline", "decline", [D("agreementSet", r, {
				n,
				key: "declined"
			})])]), !0;
		}
		case "agreementAccept": {
			let n = e.agreements.find((e) => e.id === t.n);
			return n.status = n.binding && (De(e, n.a) <= 0 || De(e, n.b) <= 0) ? "declined" : "active", !0;
		}
		case "agreementSet": return e.agreements.find((e) => e.id === t.n).status = t.key, !0;
		case "agreementResolve": {
			let n = e.agreements.find((e) => e.id === t.n);
			return B(e, n.a === r ? n.b : n.a, "agreementResolve", [V("accept", t.mode === "fulfilled" ? "confirmFulfilled" : "confirmCancellation", [D("agreementSet", r, {
				n: n.id,
				key: t.mode
			})]), V("decline", "decline", [])]), !0;
		}
		case "agreementBreach": {
			let n = e.agreements.find((e) => e.id === t.n), r = t.target, i = n.a === r ? n.b : n.a, a = e.humans.filter((e) => e !== n.a && e !== n.b);
			return e.queue.unshift(D("agreementArbitrate", i, {
				n: n.id,
				target: r,
				ids: a.length ? a : [i],
				step: 0
			})), !0;
		}
		case "agreementArbitrate": {
			let n = t.step ?? 0;
			return n >= t.ids.length ? (e.queue.unshift(D("outrage", r, {
				n: t.n,
				target: t.target
			})), !0) : (B(e, t.ids[n], "arbitrateAgreement", [V("breach", "confirmBreach", [{
				...t,
				step: n + 1
			}]), V("deny", "denyBreach", [])]), !0);
		}
		case "allianceWinner": {
			let n = `allianceWinner:${++e.serial}`;
			for (let r of t.ids) B(e, r, "allianceWinner", [...t.ids.map((e) => V(e, "player", [D("allianceVote", r, {
				target: e,
				key: n
			})], { player: e })), V("none", "noWinner", [D("allianceVote", r, {
				target: "",
				key: n
			})])]);
			return e.queue.unshift(D("allianceResolve", "", {
				ids: t.ids,
				key: n
			})), !0;
		}
		case "allianceVote": return O(e, r).flags.push(`${t.key}:${t.target}`), !0;
		case "allianceResolve": {
			let n = t.ids.map((n) => O(e, n).flags.find((e) => e.startsWith(`${t.key}:`))?.slice(t.key.length + 1)), r = n[0];
			return r && n.every((e) => e === r) ? e.queue.unshift(D("winAbilities", r), D("clashResolved", r), D("simClashResult", r), D("boonClashEnd"), D("rewardChoice", r)) : e.queue.unshift(D("clashResolved"), D("simClashResult"), D("boonClashEnd")), !0;
		}
		case "outrage": {
			let n = e.agreements.find((e) => e.id === t.n);
			return n.binding && n.status === "active" && (--O(e, t.target).tradeCards, O(e, r).tradeCards += 1, n.status = "broken", H(e, "outrage", t.target, void 0, void 0, r)), !0;
		}
		default: return !1;
	}
}
//#endregion
//#region src/games/oldkingscrown/flow.ts
var Me = [
	[
		0,
		1,
		2
	],
	[
		0,
		2,
		1
	],
	[
		1,
		0,
		2
	],
	[
		1,
		2,
		0
	],
	[
		2,
		0,
		1
	],
	[
		2,
		1,
		0
	]
], Ne = (e, t, n) => V(t, "card", n, {
	card: t,
	def: k(e, t).def
});
function Pe(e, t = []) {
	for (; e.road.length < 4 && e.kingdomDeck.length;) {
		let n = e.kingdomDeck.shift();
		e.road.unshift(n), F(t, "move", "", {
			from: "kingdomDeck",
			to: `card:def:${n}`,
			uid: `def:${n}`,
			def: n
		}), e.beat = E.move;
	}
}
function Fe(e, t) {
	return [...e.road.map((e, t) => ({
		def: e,
		n: t
	})), ...M(e, t, 175033) ? e.kingdomDeck.slice(0, 2).map((e, t) => ({
		def: e,
		n: t,
		key: "eye"
	})) : []];
}
function Ie(e, t) {
	if (e.players.some((e) => e.rid !== t && e.flags.includes("royalSeal"))) return 0;
	let n = A(e, t, "bid")[0];
	return n ? (S[n.def].strength ?? 0) + (M(e, t, 175004) ? 5 : 0) : t === "$simulacrum" ? Math.max(1, (O(e, t).bidToken ?? 0) + (C(e, 30, "a") ? -3 : C(e, 30, "b") ? 3 : 0)) : 0;
}
function Le(e, t, n, r) {
	let i = O(e, t), a = [], o = (e) => i.used.includes(e), s = D("actionStep", t, { mode: n }), c = (e, t, n, r = {}) => V(e, t, [n, s], r);
	if (n === "spring" && !o("supporters") && i.supporterSupply > 0 && a.push(c("supporters", "supporters", D("placeSupporters", t, {
		n: i.supporterSupply,
		mode: "start"
	}))), n === "autumn") {
		if (C(e, 16, "a")) for (let e of i.tactics.filter((e) => e.exhausted)) a.push(c(`forgeRefresh:${e.def}`, "refreshTactic", D("forgeRefresh", t, { def: e.def }), { def: e.def }));
		!o("govern") && A(e, t, "hand").some((t) => z(e, t).votes > 0) && a.push(c("govern", "govern", D("governChoose", t, { mode: "autumn" }))), !o("journey") && A(e, t, "hand").some((t) => z(e, t).lore > 0) && a.push(c("journey", "journey", D("journeyChoose", t, { mode: "autumn" }))), !o("secrets") && W(e, t, 1) > 0 && a.push(c("secrets", "secrets", D("secrets", t, {
			n: W(e, t, 1),
			mode: "start"
		}))), !o("oaths") && W(e, t, 2) > 0 && i.supporterLost + i.supporters.reduce((e, t) => e + t, 0) > 0 && a.push(c("oaths", "oaths", D("oaths", t, { mode: "start" })));
	}
	let l = n === "day" ? G(e, t).filter((t) => e.dayNew === null || e.dayNew.includes(t.uid)) : [...j(e, t), ...A(e, t, "hand")];
	for (let r of l) {
		let s = z(e, r);
		for (let l of s.commands) (l === "deadly" ? "night" : [
			"flank",
			"ambush",
			"ambush_or_retreat",
			"retreat"
		].includes(l) ? "day" : l.endsWith("_spring") ? "spring" : "autumn") !== n || o(`${l}:${r.uid}:${n === "day" ? `${e.region}:${e.clash}` : n}`) || n !== "day" && l.startsWith("deploy") && r.zone !== "hand" || (n === "day" || l.startsWith("deploy") || r.zone === "active") && ((l === "ambush" || l === "ambush_or_retreat") && !w(e, 19) && A(e, t, "hand").length && a.push(c(`ambush:${r.uid}`, "ambush", D("command", t, {
			card: r.uid,
			mode: l,
			key: "ambush"
		}), {
			card: r.uid,
			def: r.def
		})), (l === "retreat" || l === "ambush_or_retreat") && !w(e, 7) && !i.flags.includes(`noRetreat:${r.uid}`) && a.push(c(`retreat:${r.uid}`, "retreat", D("command", t, {
			card: r.uid,
			mode: l,
			key: "retreat"
		}), {
			card: r.uid,
			def: r.def
		})), l === "flank" && !w(e, 19) && e.regionOrder.slice(e.regionOrder.indexOf(e.region) + 1).length && a.push(c(`flank:${r.uid}`, "flank", D("command", t, {
			card: r.uid,
			mode: l,
			key: "flank"
		}), {
			card: r.uid,
			def: r.def
		})), l.startsWith("deploy") && a.push(c(`deploy:${r.uid}`, "deploy", D("command", t, {
			card: r.uid,
			mode: l,
			key: "deploy"
		}), {
			card: r.uid,
			def: r.def
		})), l.startsWith("rally") && !w(e, 7, r.region) && !i.flags.includes(`noRally:${r.uid}`) && a.push(c(`rally:${r.uid}`, "rally", D("command", t, {
			card: r.uid,
			mode: l,
			key: "rally"
		}), {
			card: r.uid,
			def: r.def
		})));
	}
	return a.push(...r), a.push(V("pass", "pass", [])), a;
}
function Re(e, t, n) {
	let r = t.actor;
	switch (t.kind) {
		case "begin":
			if (e.phase = "setup", e.step = "setup", e.config.advancedSetup) {
				for (let t of e.players.filter((e) => e.rid !== T)) t.setupKingdom = e.kingdomDeck.splice(0, 5), B(e, t.rid, "mulligan", [V("keep", "keep", []), V("redraw", "mulligan", [D("mulligan", t.rid)])]);
				e.queue.unshift(D("advancedPick"), D("advancedReveal"), D("startSpring"));
			} else e.queue.unshift(D("startSpring"));
			return !0;
		case "mulligan": {
			let t = A(e, r, "hand").filter((e) => S[e.def].archetype !== "heir");
			for (let e of t) e.zone = "deck", e.faceUp = !1;
			return N(e, A(e, r, "deck")).forEach((e, t) => {
				e.position = t;
			}), Se(e, r, 0, n, !0), !0;
		}
		case "advancedPick":
			for (let t of e.players.filter((e) => e.rid !== T)) B(e, t.rid, "startingKingdom", t.setupKingdom.flatMap((n) => A(e, t.rid, "hand").map((e) => V(`${n}:${e.uid}`, "startingKingdomGuard", [D("startingCommit", t.rid, {
				def: n,
				card: e.uid
			})], {
				def: n,
				card: e.uid
			}))));
			return !0;
		case "startingCommit": {
			let n = O(e, r);
			return e.kingdomDeck.push(...n.setupKingdom.filter((e) => e !== t.def)), n.setupKingdom = [], e.queue.unshift(D("acquireKingdom", r, {
				def: t.def,
				card: t.card,
				mode: "setup"
			})), !0;
		}
		case "startingGuard": {
			let n = O(e, r);
			return B(e, r, "occupy", A(e, r, "hand").map((n) => Ne(e, n.uid, [D("acquireKingdom", r, {
				def: t.def,
				card: n.uid,
				mode: "setup"
			})]))), e.kingdomDeck.push(...n.setupKingdom.filter((e) => e !== t.def)), n.setupKingdom = [], !0;
		}
		case "advancedReveal": return e.kingdomDeck = N(e, e.kingdomDeck), e.queue.unshift(...e.order.map((e) => D("draw", e, { mode: "size" }))), !0;
		case "startYear": return e.phase = "year", e.step = "draw", e.queue.unshift(...e.order.map((e) => D(e === "$simulacrum" ? "simDrawYear" : "draw", e, { mode: "size" })), D("orderYear"), D("startSpring")), F(n, "season", "", {
			phase: "year",
			year: e.year
		}), e.beat = E.season, !0;
		case "orderYear": {
			let t = [...e.order];
			return e.order.sort((n, r) => O(e, r).influence - O(e, n).influence || t.indexOf(r) - t.indexOf(n)), le(e), e.queue.unshift(D("yearAbilities")), !0;
		}
		case "startSpring": return e.phase = "spring", e.step = "bid", e.roadTaken = !1, e.regionOrder = [], e.region = null, e.clash = 0, e.dayNew = null, e.clashPlayers = [...e.order], e.queue.unshift(D("simStartYear"), D("allyBid", "", { step: 0 }), D("placeBids"), D("bidRevealTactics"), D("revealBids")), F(n, "season", "", {
			phase: "spring",
			year: e.year
		}), e.beat = E.season, !0;
		case "placeBids":
			for (let t of e.players.filter((t) => t.rid !== "$simulacrum" && !A(e, t.rid, "bid").length)) B(e, t.rid, "bid", A(e, t.rid, "hand").filter((e) => S[e.def].faction === t.faction).map((n) => Ne(e, n.uid, [D("move", t.rid, {
				card: n.uid,
				zone: "bid"
			})])));
			return !0;
		case "revealBids": {
			e.step = "resolveBid";
			for (let t of e.cards.filter((e) => e.zone === "bid")) t.faceUp = !0, F(n, "reveal", t.owner, {
				uid: t.uid,
				def: t.def
			});
			for (let t of e.players) t.bid = Ie(e, t.rid);
			let t = [...e.order].sort((t, n) => (O(e, n).bid ?? 0) - (O(e, t).bid ?? 0) || e.order.indexOf(t) - e.order.indexOf(n));
			if (t[0] !== "$simulacrum" && C(e, 27, "a")) for (let t of e.humans) U(e, t, "influence", 1, n);
			return t[0] === "$simulacrum" && C(e, 27, "b") && U(e, T, "influence", 1, n), M(e, t[0], 175004) && U(e, t[0], "influence", 1, n), e.queue.unshift(...t.map((e) => D(e === "$simulacrum" ? "simResolveBid" : "resolveBid", e)), D("roadSpring"), D("negotiationStart"), ...e.order.map((e) => D("placeHerald", e, { step: 0 })), D("allyDeploy", "", { step: 0 }), D("placeCards"), ...e.order.map((e) => D("actionStep", e, { mode: "spring" })), D("clashOrder")), e.beat = E.reveal, !0;
		}
		case "resolveBid": {
			let t = A(e, r, "bid")[0];
			if (!t) return !0;
			let n = Fe(e, r).map(({ def: e, n, key: i }) => V(`${i ?? "road"}:${n}`, "acquire", [D("acquireKingdom", r, {
				def: e,
				card: t.uid,
				n,
				key: i
			})], { def: e }));
			if (!M(e, r, 175004)) for (let i of e.cards.filter((e) => e.owner !== r && e.zone === "occupying" && e.location !== null && e.location < 100 && ["kingdom", "wild"].includes(S[e.def].kind))) {
				let a = e.cards.find((e) => e.parent === i.uid), o = S[t.def].archetype === "champion" && !S[t.def].basic ? 0 : (a ? S[a.def].strength ?? 0 : i.owner === "$simulacrum" ? Math.max(1, i.guardStrength + (C(e, 30, "a") ? -3 : C(e, 30, "b") ? 3 : 0)) : 0) + (M(e, i.owner, 175004) ? 5 : 0);
				(O(e, r).bid ?? 0) + (M(e, r, 175008) ? 3 : 0) > o && n.push(V(`steal:${i.uid}`, "steal", [D("acquireKingdom", r, {
					card: t.uid,
					target: i.uid,
					def: i.def,
					mode: "steal"
				})], {
					def: i.def,
					player: i.owner
				}));
			}
			return n.push(V("return", "returnBid", [D("move", r, {
				card: t.uid,
				zone: "hand"
			})], { def: t.def })), B(e, r, "resolveBid", n), !0;
		}
		case "acquireKingdom": {
			let i = t.def, a = t.key === "eye" || t.n === void 0 ? "kingdomDeck" : `roadSlot:${t.n}`;
			t.n !== void 0 && ((t.key === "eye" ? e.kingdomDeck : e.road).splice(t.n, 1), e.roadTaken = !0);
			let o = t.target ? k(e, t.target) : P(e, i, r, "supply");
			if (t.mode === "steal") {
				let t = o.owner;
				t === "$simulacrum" && (e.sim.bidDiscard.push(o.guardStrength), o.guardStrength = 0);
				for (let t of e.cards.filter((e) => e.parent === o.uid)) R(e, t, "hand", n);
				i === 175016 && t !== "$simulacrum" && xe(e, t, -1, n);
				for (let a of e.players) M(e, a.rid, 175008) && U(e, a.rid === t && i === 175008 ? r : a.rid, "influence", 1, n);
				R(e, o, "supply", n, { owner: r });
			} else F(n, "move", r, {
				from: a,
				to: `supply:${r}`,
				def: i,
				uid: o.uid
			}), e.beat = E.move;
			if ([
				175003,
				175006,
				175009,
				175010,
				175033,
				175042,
				175048,
				175701,
				175702,
				175704,
				175705,
				175713
			].includes(i)) e.queue.unshift(D("kingdomAcquisition", r, {
				def: i,
				card: o.uid,
				target: t.card
			}));
			else if (t.location !== void 0) {
				let n = A(e, r, "occupying").find((e) => !e.parent && e.location === t.location);
				e.queue.unshift(...n ? [D("discardKingdom", r, { card: n.uid })] : [], D("occupy", r, {
					card: o.uid,
					target: t.card,
					location: t.location
				}));
			} else {
				let n = M(e, r, 175705) ? Math.max(2, A(e, r, "occupying").length + 1) : M(e, r, 176800) ? 3 : 2, i = A(e, r, "occupying").filter((e) => !e.parent && e.location !== null && e.location < 100 && (S[e.def].kind === "kingdom" || S[e.def].kind === "wild"));
				B(e, r, "occupySlot", [...Array.from({ length: n }, (e, t) => t).filter((e) => !i.some((t) => t.location === e)).map((e) => V(`empty:${e}`, "emptySlot", [D("occupy", r, {
					card: o.uid,
					target: t.card,
					location: e
				})], { n: e + 1 })), ...i.map((e) => V(e.uid, "replaceKingdom", [D("discardKingdom", r, { card: e.uid }), D("occupy", r, {
					card: o.uid,
					target: t.card,
					location: e.location
				})], { def: e.def }))]);
			}
			return H(e, t.mode === "steal" ? "stoleKingdom" : "acquiredKingdom", r, i), !0;
		}
		case "occupy": {
			let i = k(e, t.card);
			if (R(e, i, "occupying", n, { location: t.location }), t.target) {
				let a = t.location >= 2 && t.location < 100 && M(e, r, 175705);
				R(e, k(e, t.target), a ? "discard" : "occupying", n, a ? {} : { parent: i.uid });
			}
			return i.def === 175016 && xe(e, r, 1, n), e.queue.unshift(D("afterAcquireKingdom", r, { card: i.uid })), !0;
		}
		case "roadSpring": {
			let t = e.roadTaken ? 1 : 2;
			for (let r of e.road.splice(-t, t)) e.kingdomDiscard.push(r), F(n, "move", "", {
				from: "road",
				to: "kingdomDiscard",
				def: r
			});
			return Pe(e, n), e.beat = E.move, !0;
		}
		case "placeHerald": {
			if (e.step = "herald", r === "$simulacrum") return e.queue.unshift(D("simHerald", r)), !0;
			let n = O(e, r), i = t.step ?? 0;
			return i >= n.heralds.length || B(e, r, i ? "creatureHerald" : "herald", Array.from({ length: 6 }, (e, t) => t).filter((e) => !n.heralds.includes(e)).map((e) => V(String(e), "location", [D("herald", r, {
				location: e,
				step: i
			}), D("placeHerald", r, { step: i + 1 })], { location: e }))), !0;
		}
		case "herald": {
			let i = O(e, r), a = t.step ?? 0;
			return i.heralds.some((e, n) => n !== a && e === t.location) || he(e, r, a, t.location, n), !0;
		}
		case "placeCards":
			if (e.step = "deploy", t.mode !== "normal") {
				let t = e.order.filter((t) => t !== "$simulacrum" && A(e, t, "hand").length + e.cards.filter((e) => e.owner === t && e.zone === "active" && !e.faceUp).length < 3);
				return e.queue.unshift(...t.map((e) => D("placeShortCards", e)), D("placeCards", "", { mode: "normal" })), !0;
			}
			for (let t of e.order) {
				if (t === "$simulacrum") {
					e.queue.unshift(D("simPlaceCards", t));
					continue;
				}
				let n = e.cards.filter((e) => e.owner === t && e.zone === "active" && !e.faceUp).map((e) => e.region), r = [
					0,
					1,
					2
				].filter((e) => !n.includes(e)), i = A(e, t, "hand").filter((n) => S[n.def].faction === O(e, t).faction);
				r.length && i.length && B(e, t, "placeCard", i.flatMap((e) => r.map((n) => V(`${e.uid}:${n}`, "placeCard", [D("move", t, {
					card: e.uid,
					zone: "active",
					region: n,
					mode: "hidden"
				})], {
					card: e.uid,
					def: e.def,
					region: n
				}))));
			}
			return e.prompts.length && e.queue.unshift(D("placeCards", "", { mode: "normal" })), !0;
		case "placeShortCards": {
			let t = e.cards.filter((e) => e.owner === r && e.zone === "active" && !e.faceUp).map((e) => e.region), n = [
				0,
				1,
				2
			].filter((e) => !t.includes(e)), i = A(e, r, "hand").filter((t) => S[t.def].faction === O(e, r).faction);
			return B(e, r, "placeCard", i.flatMap((e) => n.map((t) => V(`${e.uid}:${t}`, "placeCard", [D("move", r, {
				card: e.uid,
				zone: "active",
				region: t,
				mode: "hidden"
			})], {
				card: e.uid,
				def: e.def,
				region: t
			}))), { after: n.length > 1 && i.length > 1 ? [D("placeShortCards", r)] : [] }), !0;
		}
		case "placeOneCard": {
			let n = e.cards.filter((e) => e.owner === r && e.zone === "active" && !e.faceUp).map((e) => e.region), i = [
				0,
				1,
				2
			].filter((e) => !n.includes(e)), a = A(e, r, "hand").filter((n) => t.mode === "ally" || S[n.def].faction === O(e, r).faction);
			return !i.length || !a.length || B(e, r, "placeCard", a.flatMap((e) => i.map((n) => V(`${e.uid}:${n}`, "placeCard", [D("move", r, {
				card: e.uid,
				zone: "active",
				region: n,
				mode: "hidden"
			}), D("placeOneCard", r, { n: (t.n ?? 3) - 1 })], {
				card: e.uid,
				def: e.def,
				region: n
			})))), !0;
		}
		case "placeSupporters": {
			let n = O(e, r);
			return t.mode === "start" && we(e, r, "supporters"), n.supporterSupply <= 0 || (t.n ?? 0) <= 0 || B(e, r, "placeSupporters", [
				0,
				1,
				2
			].map((e) => V(String(e), "supporterRegion", [D("supporterMove", r, {
				region: e,
				n: 1,
				mode: "place"
			}), D("placeSupporters", r, { n: (t.n ?? 1) - 1 })], { region: e })), { min: 0 }), !0;
		}
		case "supporterMove": {
			let i = t.n ?? 1;
			return I(e, r, t.mode === "place" ? -1 : t.mode === "recallLost" ? -2 : t.region, t.mode === "place" ? t.region : -1, i, n), e.beat = E.move, !0;
		}
		case "clashOrder": {
			e.phase = "summer", e.step = "clashOrder";
			let t = e.players.find((e) => e.flags.includes("storms"))?.rid ?? e.order.at(-1);
			return t === "$simulacrum" ? e.queue.unshift(D("simClashOrder", t)) : B(e, t, "clashOrder", Me.map((e, n) => V(String(n), "regionOrder", [D("setClashOrder", t, { nums: e })], { n }))), !0;
		}
		case "setClashOrder": return e.regionOrder = t.nums, e.queue.unshift(D("startRegion", "", { step: 0 })), !0;
		case "startRegion": {
			let n = t.step ?? 0;
			if (n >= 3) return e.queue.unshift(D("startAutumn")), !0;
			e.region = e.regionOrder[n], e.clash = 1, e.clashPlayers = [...e.order], e.dayNew = null;
			for (let t of e.order) e.foughtSupporters[t] ??= [
				0,
				0,
				0
			], e.foughtSupporters[t][e.region] = 0;
			return e.queue.unshift(D("revealClash"), D("night"), D("outcome"), D("afterRegion"), D("startRegion", "", { step: n + 1 })), !0;
		}
		case "revealClash": {
			e.step = "reveal";
			let r = e.cards.filter((t) => t.zone === "active" && t.region === e.region && !t.faceUp);
			for (let t of r) t.faceUp = !0, F(n, "reveal", t.owner, {
				uid: t.uid,
				def: t.def,
				region: e.region
			});
			return e.dayNew = t.mode === "ambush" ? r.map((e) => e.uid) : null, e.queue.unshift(D("beforeDay"), ...e.order.filter((t) => e.clashPlayers.includes(t)).map((e) => D("actionStep", e, { mode: "day" })), D("ambushReveal")), e.beat = E.reveal, !0;
		}
		case "ambushReveal": return e.cards.some((t) => t.zone === "active" && t.region === e.region && !t.faceUp) && e.queue.unshift(D("revealClash", "", { mode: "ambush" })), !0;
		case "night": return e.step = "night", e.queue.unshift(D("nightEffects")), !0;
		case "outcome": {
			e.step = "outcome";
			let t = G(e), r = Object.fromEntries(e.clashPlayers.map((n) => {
				let r = O(e, n), i = t.filter((e) => e.owner === n).reduce((t, n) => t + z(e, n).strength, 0);
				return i += Math.max(0, r.supporters[e.region] - (e.foughtSupporters[n]?.[e.region] ?? 0)) * (r.flags.includes("stones") ? 2 : ce(e, n)), n === "$simulacrum" && (i += (w(e, 5) ? 3 : 0) + (w(e, 10) ? 5 : 0)), i += Number(r.flags.find((t) => t.startsWith(`strength:${e.region}:${e.clash}:`))?.split(":")[3] ?? 0), e.clash === 1 && e.modules.airOwner === n && e.modules.airRegion === e.region && (i += 3), e.cards.some((t) => t.def === 175042 && t.zone === "supply" && t.region === e.region && t.owner !== n) && (i = Math.ceil(i / 2)), e.clash === 1 && M(e, n, 175710) && r.heralds.some((t) => t !== null && Math.floor(t / 2) === e.region) && (i += 5), [n, i];
			}));
			e.strengths = r;
			let i = t.some((t) => be(e, t, 177417)), a = Ae(e, e.clashPlayers).map((e) => ({
				ids: e,
				strength: e.reduce((e, t) => e + r[t], 0)
			})), o = a.map((e) => e.strength).filter((e) => !i || e > 0), s = i && o.length ? Math.min(...o) : Math.max(...o), c = a.filter((e) => e.strength === s).flatMap((e) => e.ids);
			if (c.includes("$simulacrum") && c.length > 1 && (C(e, 15, "a") && (c = c.filter((e) => e !== T)), C(e, 15, "b") && (c = [T])), e.clash === 1 && c.length === 1 && c[0] !== "$simulacrum" && w(e, 18) && (c = [.../* @__PURE__ */ new Set([...c, T])]), H(e, c.length === 1 ? "clashWon" : "clashTied", c.length === 1 ? c[0] : void 0, void 0, s), F(n, "outcome", c.length === 1 ? c[0] : "", {
				strength: s,
				region: e.region
			}), e.beat = E.outcome, c.length === 1) e.queue.unshift(D("winAbilities", c[0]), D("clashResolved", c[0]), D("simClashResult", c[0]), D("boonClashEnd"), D("rewardChoice", c[0]));
			else if (Ae(e, c).length === 1) e.queue.unshift(D("allianceWinner", "", { ids: c }));
			else {
				for (let n of t) n.fought.push(`${e.year}:${e.region}:${e.clash}`);
				for (let t of e.clashPlayers) e.foughtSupporters[t][e.region] = O(e, t).supporters[e.region];
				e.clashPlayers = c, e.queue.unshift(D("boonClashEnd", "", { ids: t.map((e) => e.uid) }), ...e.order.filter((e) => c.includes(e)).map((e) => D("tieCard", e)), D("tieContinue"));
			}
			return !0;
		}
		case "tieCard": return r === "$simulacrum" ? (e.queue.unshift(D("simTie", r)), !0) : (B(e, r, "tieCard", A(e, r, "hand").map((t) => Ne(e, t.uid, [D("move", r, {
			card: t.uid,
			zone: "active",
			region: e.region,
			mode: "hidden"
		})])), { min: 0 }), !0);
		case "tieContinue": return e.cards.some((t) => t.zone === "active" && t.region === e.region && !t.faceUp) ? (e.clash += 1, e.queue.unshift(D("revealClash"), D("night"), D("outcome"))) : e.queue.unshift(D("clashResolved"), D("simClashResult"), D("boonClashEnd")), !0;
		case "rewardChoice": return e.step = "reward", r === "$simulacrum" ? (e.queue.unshift(D("simReward", r)), !0) : (B(e, r, "reward", [e.region * 2, e.region * 2 + 1].map((e) => V(String(e), "location", [D("heraldReward", r, { location: e }), D("locationReward", r, { location: e })], { location: e }))), !0);
		case "heraldReward": {
			let i = O(e, r), a = i.heralds.filter((e) => e === t.location).length;
			if (!a || e.players.some((e) => e.flags.includes("abundance"))) return !0;
			U(e, r, "influence", a, n);
			for (let i of e.players.filter((e) => e.rid !== r)) {
				let o = Math.min(i.influence, i.heralds.filter((e) => e === t.location).length * a);
				o && (i.influence -= o, U(e, r, "influence", o, n));
			}
			let o = A(e, r, "council").filter((e) => e.suit === 0).map((t) => Ne(e, t.uid, [D("relicRemove", r, { card: t.uid })]));
			return i.councilMarkers[0] && o.push(V("markers", "markers", [D("relicRemove", r, { n: i.councilMarkers[0] })], { n: i.councilMarkers[0] })), B(e, r, "relics", o, {
				min: 0,
				max: o.length
			}), !0;
		}
		case "relicRemove":
			if (t.card) {
				let i = k(e, t.card), a = z(e, i).votes;
				R(e, i, "discard", n), U(e, r, "influence", a, n);
			} else L(e, r, "councilMarker", 0, -t.n, n), U(e, r, "influence", t.n, n);
			return !0;
		case "startAutumn": return e.phase = "autumn", e.step = "autumn", e.region = null, e.queue.unshift(...e.order.map((e) => D("actionStep", e, { mode: "autumn" })), D("winter")), F(n, "season", "", { phase: "autumn" }), !0;
		case "winter": return e.phase = "winter", e.step = "winter", e.queue.unshift(D("winterEffects"), D("cleanup"), D("advanceYear")), !0;
		case "cleanup":
			for (let t of e.players) t.heralds.forEach((r, i) => he(e, t.rid, i, null, n)), t.rid !== "$simulacrum" && !t.flags.includes("stones") && t.supporters.forEach((r, i) => I(e, t.rid, i, -2, r, n)), t.used = [], t.flags = [], t.bid = null;
			for (let t of j(e)) t.influence ? (--t.influence, F(n, "cardInfluence", t.owner, {
				uid: t.uid,
				n: -1
			})) : R(e, t, "discard", n);
			for (let t of e.cards) t.strengthBonus = 0, t.gainedTraits = [], t.gainedCommands = [], t.gainedRules = [], t.clashGrants = [], t.copy = null, e.modules.boonDiscard.push(...t.boons), t.boons = [], t.fought = [];
			return e.queue.unshift(D("simCleanup"), D("moduleCleanup")), !0;
		case "advanceYear": return e.year >= e.config.years ? e.queue.unshift(D("finish")) : (e.year += 1, e.queue.unshift(D("startYear"))), !0;
		case "finish": {
			for (let t of e.players) t.rid !== "$simulacrum" && !A(e, t.rid, "site").length && (t.influence += Math.floor(t.lore / 2)), M(e, t.rid, 175700) && (t.influence += 3), e.config.negotiating && (t.influence += [
				-6,
				-3,
				0,
				3,
				6
			][Math.min(4, t.tradeCards)]);
			let t = [...e.order].sort((t, n) => O(e, n).influence - O(e, t).influence || (t === "$simulacrum" || n === "$simulacrum" ? C(e, 15, "a") ? Number(t === "$simulacrum") - Number(n === "$simulacrum") : C(e, 15, "b") ? Number(n === "$simulacrum") - Number(t === "$simulacrum") : 0 : 0) || Number(M(e, n, 175700)) - Number(M(e, t, 175700)) || Number(e.favour.owner === n) - Number(e.favour.owner === t) || e.order.indexOf(t) - e.order.indexOf(n));
			return e.scores = Object.fromEntries(e.players.map((e) => [e.rid, e.influence])), e.winner = e.config.simulacrum === "cooperative" ? e.humans.every((t) => O(e, t).influence > O(e, "$simulacrum").influence) ? [...e.humans] : [T] : [t[0]], e.done = !0, e.phase = "done", e.step = "done", e.queue = [], e.prompts = [], !0;
		}
		case "move": return R(e, k(e, t.card), t.zone, n, {
			region: t.region,
			suit: t.suit,
			faceUp: t.mode !== "hidden" && ![
				"hand",
				"deck",
				"bid"
			].includes(t.zone),
			bottom: t.mode === "bottom"
		}), !0;
		case "draw": return Se(e, r, t.n ?? 0, n, t.mode === "size"), !0;
		case "gain": return U(e, r, t.mode === "lore" ? "lore" : "influence", t.n ?? 0, n), !0;
		case "discardKingdom": return Ee(e, k(e, t.card), n), !0;
		case "recoverCouncil": return B(e, r, "recoverCouncil", [V("yes", "returnHand", [D("move", r, {
			card: t.card,
			zone: "hand"
		})])], { min: 0 }), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/oldkingscrown/actions.ts
var ze = (e, t) => V(e.uid, "card", t, {
	card: e.uid,
	def: e.def
}), Be = (e) => e.regionOrder.slice(e.regionOrder.indexOf(e.region) + 1), Ve = (e, t, n) => e.phase === "summer" && e.clash === 1 && e.region === n && e.players.some((e) => e.rid !== t && e.flags.includes(`martial:${n}`)), He = (e, t, n) => t !== n && !e.agreements.some((e) => e.alliance && e.status === "active" && [e.a, e.b].includes(t) && [e.a, e.b].includes(n));
function K(e, t, n, r, i, a = 1, o = 0, s = []) {
	B(e, t, n, r.map((e) => ze(e, i(e))), {
		min: o,
		max: Math.min(a, r.length),
		after: s
	});
}
function Ue(e, t, n, r = []) {
	let i = t.actor;
	switch (t.kind) {
		case "actionStep": return e.step = t.mode, t.mode === "day" && e.cards.some((t) => t.def === 175046 && t.zone === "supply" && t.region === e.region) ? !0 : i === "$simulacrum" ? (e.queue.unshift(...t.mode === "day" ? [D("simBeforeDay", T)] : [], D("simAction", i, { mode: t.mode })), !0) : (B(e, i, t.mode, Le(e, i, t.mode, r)), !0);
		case "command": {
			let n = k(e, t.card);
			if (!we(e, i, `${t.mode}:${n.uid}:${e.step === "day" ? `${e.region}:${e.clash}` : e.step}`)) return !0;
			if (t.key === "ambush") {
				let t = O(e, i).flags.includes(`discardAmbush:${n.uid}`);
				Ve(e, i, e.region) || K(e, i, "ambush", A(e, i, t ? "discard" : "hand"), (t) => [D("move", i, {
					card: t.uid,
					zone: "active",
					region: e.region,
					mode: "hidden"
				})], 1, 1);
			}
			return t.key === "retreat" && !O(e, i).flags.includes(`noRetreat:${n.uid}`) && K(e, i, "retreatCards", G(e, i), (e) => [D("retreatCard", i, { card: e.uid })], 80, 0, [D("retreatPieces", i)]), t.key === "flank" && B(e, i, "flank", Be(e).filter((t) => !Ve(e, i, t)).map((e) => V(String(e), "region", [D("flank", i, {
				card: n.uid,
				region: e
			})], { region: e }))), t.key === "deploy" && B(e, i, "deploy", [
				0,
				1,
				2
			].map((e) => V(String(e), "region", [D("deploy", i, {
				card: n.uid,
				region: e,
				n: Number(t.mode.match(/deploy(\d+)/)?.[1] ?? 1)
			})], { region: e }))), t.key === "rally" && !O(e, i).flags.includes(`noRally:${n.uid}`) && K(e, i, "rally", (t.mode === "rallySelf" ? [n] : j(e, i)).filter((t) => !w(e, 7, t.region)), (e) => [D("move", i, {
				card: e.uid,
				zone: "hand"
			})], Number(t.mode.match(/rally(\d+)/)?.[1] ?? 1)), !0;
		}
		case "deploy": {
			let r = k(e, t.card);
			return R(e, r, "active", n, { region: t.region }), r.influence = t.n ?? 1, !0;
		}
		case "flank": {
			let r = k(e, t.card), a = r.region;
			return R(e, r, "active", n, { region: t.region }), [174415, 175103].includes(r.def) && e.queue.unshift(D("flankSupporters", i, {
				region: a,
				location: t.region
			})), r.def === 175103 && K(e, i, "flankCards", j(e, i, a), (e) => [D("move", i, {
				card: e.uid,
				zone: "active",
				region: t.region
			})], 80), !0;
		}
		case "flankSupporters": {
			let n = O(e, i).supporters[t.region];
			return B(e, i, "flankSupporters", Array.from({ length: n + 1 }, (e, n) => V(String(n), "count", [D("transferSupporters", i, {
				region: t.region,
				location: t.location,
				n
			})], { n }))), !0;
		}
		case "transferSupporters": return I(e, i, t.region, t.location, t.n, n), !0;
		case "retreatCard": {
			let r = k(e, t.card), a = O(e, i).flags.includes(`smuggler:${r.uid}`);
			return R(e, r, "hand", n), a && B(e, i, "journey", [V("yes", "journey", [D("journey", i, { card: r.uid })], { def: r.def })], { min: 0 }), !0;
		}
		case "retreatPieces": {
			let t = O(e, i), n = t.heralds.flatMap((t, n) => t !== null && Math.floor(t / 2) === e.region ? [V(`h:${n}`, "returnHerald", [D("heraldReturn", i, { n })], { location: t })] : []);
			return t.supporters[e.region] && n.push(V("supporters", "supporters", [D("chooseRecall", i, {
				region: e.region,
				n: t.supporters[e.region],
				mode: "supply"
			})])), B(e, i, "retreatPieces", n, {
				min: 0,
				max: n.length
			}), !0;
		}
		case "heraldReturn": return he(e, i, t.n, null, n), !0;
		case "chooseRecall": return B(e, i, "supporterCount", Array.from({ length: (t.n ?? 0) + 1 }, (e, n) => V(String(n), "count", [D("transferSupporters", i, {
			region: t.region,
			location: t.mode === "lost" ? -2 : -1,
			n
		})], { n }))), !0;
		case "governChoose": return K(e, i, "govern", (t.ids ? t.ids.map((t) => k(e, t)) : t.mode === "autumn" ? A(e, i, "hand") : [...A(e, i, "hand"), ...j(e, i)]).filter((t) => z(e, t).votes > 0), (e) => [D("governCouncil", i, {
			card: e.uid,
			mode: t.mode,
			nums: t.nums
		})], 1, +(t.mode === "autumn")), !0;
		case "governCouncil": return B(e, i, "council", [
			0,
			1,
			2
		].filter((e) => !t.nums?.includes(e)).map((e) => V(String(e), "council", [D("govern", i, {
			card: t.card,
			suit: e,
			mode: t.mode
		})], { suit: e }))), !0;
		case "govern": {
			let r = k(e, t.card);
			if (t.mode === "autumn" && we(e, i, "govern"), t.mode === "castle") for (let i of e.cards.filter((e) => e.zone === "council" && e.suit === t.suit && e.uid !== r.uid)) R(e, i, "discard", n);
			if (t.mode === "castle") for (let r of e.players) L(e, r.rid, "councilMarker", t.suit, -r.councilMarkers[t.suit], n);
			return R(e, r, "council", n, { suit: t.suit }), H(e, "govern", i, r.def), !0;
		}
		case "journeyChoose": return K(e, i, "journey", (t.ids ? t.ids.map((t) => k(e, t)) : t.mode === "autumn" && !M(e, i, 175e3) ? A(e, i, "hand") : [...A(e, i, "hand"), ...j(e, i)]).filter((t) => z(e, t).lore > 0), (e) => [D("journey", i, {
			card: e.uid,
			mode: t.mode
		})], 1, +(t.mode === "autumn")), !0;
		case "journey": {
			let n = k(e, t.card), r = z(e, n), a = r.traits.includes("pathfinder");
			t.mode === "autumn" && we(e, i, "journey");
			let o = D("journeyMove", i, {
				card: n.uid,
				n: r.lore,
				mode: a ? "discard" : "lost"
			});
			return M(e, i, 175017) ? B(e, i, "journeyDestination", [V("normal", a ? "discard" : "lost", [o]), V("bottom", "deckBottom", [{
				...o,
				mode: "bottom"
			}])]) : e.queue.unshift(o), a && M(e, i, 175011) && e.queue.unshift(D("gain", i, { n: 1 }), D("gain", i, {
				n: 1,
				mode: "lore"
			})), !0;
		}
		case "journeyMove": return R(e, k(e, t.card), t.mode === "bottom" ? "deck" : t.mode === "discard" ? "discard" : "lost", n, { bottom: t.mode === "bottom" }), U(e, i, "lore", t.n, n), !0;
		case "buySite": {
			let t = O(e, i);
			return K(e, i, "buySite", (M(e, i, 175708) ? e.cards.filter((e) => e.zone === "site") : A(e, i, "site")).filter((n) => n.owner !== "$simulacrum" && oe(e, S[n.def].cost ?? 0) <= t.lore), (e) => [D("acquireSite", i, { card: e.uid }), D("buySite", i)], 1), !0;
		}
		case "acquireSite": {
			let r = k(e, t.card), a = S[r.def];
			return t.mode !== "free" && (O(e, i).lore -= oe(e, a.cost ?? 0)), R(e, r, a.kind === "hq" ? "supply" : "hand", n, { owner: i }), e.queue.unshift(D("siteAcquisition", i, {
				card: r.uid,
				def: r.def
			})), H(e, "acquiredSite", i, r.def), !0;
		}
		case "secrets": {
			let n = O(e, i);
			return t.mode === "start" && we(e, i, "secrets"), t.n ? (B(e, i, "secretLocation", Array.from({ length: 6 }, (e, r) => V(String(r), "location", [D("secretPlace", i, { location: r }), D("secrets", i, { n: t.n - 1 })], {
				location: r,
				n: n.markers[r]
			}))), !0) : (e.queue.unshift(D("secretsRewards", i)), !0);
		}
		case "secretPlace": return L(e, i, "marker", t.location, 1, n), !0;
		case "secretsRewards": {
			let t = O(e, i).markers.flatMap((e, t) => e >= 4 ? [t] : []);
			return t.length && B(e, i, "secretReward", t.map((e) => V(String(e), "location", [
				D("secretRemove", i, { location: e }),
				D("locationReward", i, {
					location: e,
					mode: "secrets"
				}),
				D("secretsRewards", i)
			], { location: e }))), !0;
		}
		case "secretRemove": return L(e, i, "marker", t.location, -O(e, i).markers[t.location], n), !0;
		case "oaths": {
			let n = O(e, i);
			if (t.mode === "start") {
				we(e, i, "oaths");
				let t = W(e, i, 2), n = t > 0 && e.players.every((n) => n.rid === i || W(e, n.rid, 2) < t);
				return e.queue.unshift(D("oaths", i, { n: t + Number(n) })), !0;
			}
			if (!t.n) return !0;
			let r = [];
			return n.supporterLost && r.push(V("lost", "lostSupporter", [D("supporterMove", i, {
				mode: "recallLost",
				n: 1
			}), D("oaths", i, { n: t.n - 1 })])), n.supporters.forEach((e, n) => {
				e && r.push(V(String(n), "supporterRegion", [D("supporterMove", i, {
					mode: "recallMap",
					region: n,
					n: 1
				}), D("oaths", i, { n: t.n - 1 })], { region: n }));
			}), B(e, i, "oaths", r, { min: 0 }), !0;
		}
		case "locationReward": {
			let r = t.location, a = e.modules.locations[r];
			if (i !== "$simulacrum" && se(e, r)) return !0;
			if (i !== "$simulacrum" && C(e, 12, "b") && e.sim.towers.includes(r)) return e.sim.towers.splice(e.sim.towers.indexOf(r), 1), !0;
			if (e.phase === "summer" && e.cards.some((e) => e.def === 175713 && e.zone === "supply" && e.region === Math.floor(r / 2))) return !0;
			if (t.mode !== "printed") return e.queue.unshift(D("locationVisit", i, {
				location: r,
				mode: t.mode
			})), !0;
			t.key !== "secrets" && U(e, i, "influence", a === 3 ? 2 : 1, n), t.key !== "secrets" && e.modules.locationInfluence[r] && (U(e, i, "influence", e.modules.locationInfluence[r], n), e.modules.locationInfluence[r] = 0);
			for (let t of e.cards.filter((e) => e.def === 175010 && e.zone === "supply" && e.location === r)) U(e, t.owner, "influence", 1, n);
			for (let t of e.cards.filter((e) => e.def === 175702 && e.zone === "supply" && e.location === r)) U(e, i, "influence", t.owner === i ? 2 : 1, n), t.owner === i && !e.modules.travelled.includes(t.uid) && (e.modules.travelled.push(t.uid), t.location = (Math.floor(r / 2) + 1) % 3 * 2 + 1 - r % 2);
			if (a === 0 && e.queue.unshift(D("governChoose", i, { mode: "castle" })), a === 1 && e.queue.unshift(D("journeyChoose", i, { mode: "wilderness" })), a === 2 && B(e, i, "claimFavour", [V("yes", "claimFavour", [D("claimFavour", i)])], { min: 0 }), a === 4 && K(e, i, "shrine", [...A(e, i, "hand"), ...j(e, i)], (e) => [D("move", i, {
				card: e.uid,
				zone: "deck",
				mode: "bottom"
			})], 3), a === 5) {
				let t = N(e, A(e, i, "discard"));
				t.forEach((t) => {
					t.position = ++e.serial;
				}), B(e, i, "necropolisCount", Array.from({ length: Math.min(3, t.length) + 1 }, (e, n) => V(String(n), "count", t.slice(0, n).map((e) => D("move", i, {
					card: e.uid,
					zone: "hand"
				})), { n })), { after: [D("discardHand", i, { mode: "optional" })] });
			}
			return H(e, "locationReward", i, void 0, a), !0;
		}
		case "claimFavour": return e.favour = {
			owner: i,
			uses: 3
		}, F(n, "favour", i), !0;
		case "discardHand": {
			if (i === "$simulacrum") return Ce(e, t.n ?? 1).forEach((t) => R(e, t, "discard", n)), !0;
			let r = A(e, i, "hand"), a = t.mode === "limit" ? Math.max(0, r.length - O(e, i).handSize) : t.n ?? r.length;
			return K(e, i, "discardHand", r, (e) => [D("move", i, {
				card: e.uid,
				zone: "discard"
			})], Math.min(a, r.length), t.mode === "optional" ? 0 : Math.min(a, r.length)), !0;
		}
		case "flag": return t.target ? O(e, t.target).flags.push(t.key) : O(e, i).flags.push(t.key), !0;
		case "grant": {
			let n = k(e, t.card);
			return t.mode === "clash" ? n.clashGrants.push({
				key: t.key,
				year: e.year,
				region: e.region,
				clash: e.clash
			}) : [
				"invulnerable",
				"pathfinder",
				"resilient"
			].includes(t.key) ? n.gainedTraits.push(t.key) : n.gainedCommands.push(t.key), t.n && (n.strengthBonus += t.n), !0;
		}
		case "cardInfluence": return k(e, t.card).influence += t.n, F(n, "cardInfluence", i, {
			uid: t.card,
			n: t.n
		}), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/oldkingscrown/combat.ts
function We(e, t, n) {
	let r = t.actor;
	switch (t.kind) {
		case "nightEffects": {
			if (e.cards.some((t) => t.def === 175046 && t.zone === "supply" && t.region === e.region)) return !0;
			let t = G(e), n = /* @__PURE__ */ new Map(), r = [], i = (t, r) => {
				z(e, t).traits.includes("invulnerable") || n.set(t.uid, [.../* @__PURE__ */ new Set([...n.get(t.uid) ?? [], r.uid])]);
			};
			for (let n of t) {
				let r = z(e, n), a = t.filter((t) => He(e, n.owner, t.owner)), o = ye(e, n);
				r.commands.includes("deadly") && a.forEach((e) => i(e, n)), o.some((e) => (S[e].basic || S[e].kind === "simulacrum" && !S[e].advanced) && S[e].archetype === "agent") && a.some((t) => _e(e, t, "follower")) && i(n, n), o.includes(174315) && a.filter((t) => _e(e, t, "heir") || _e(e, t, "trader")).forEach((e) => i(e, n)), o.includes(174316) && a.some((t) => _e(e, t, "heir")) && i(n, n), M(e, n.owner, 175034) && r.archetype === "heir" && a.some((t) => _e(e, t, "follower")) && i(n, n);
			}
			for (let t of e.players) {
				let i = [...n.keys()].filter((n) => k(e, n).owner === t.rid);
				if (!i.length) continue;
				let a = i.map((r) => {
					let i = k(e, r), a = `night:${e.year}:${e.region}:${e.clash}`, o = n.get(r).map((t) => k(e, t)).filter((e) => e.owner !== i.owner).map((t) => D("killReward", t.owner, {
						key: `${a}:${t.uid}`,
						nums: ye(e, t),
						n: Number(_e(e, t, "heir"))
					}));
					return D("eliminate", t.rid, {
						card: r,
						ids: n.get(r),
						key: a,
						mode: z(e, i).traits.includes("resilient") ? "resilient" : "normal",
						then: o
					});
				}), o = e.cards.find((e) => e.owner === t.rid && e.def === 175100 && ["active", "council"].includes(e.zone));
				r.push(o ? D("protectBatch", t.rid, {
					card: o.uid,
					ids: i,
					then: a
				}) : D("batch", t.rid, { then: a }));
			}
			return r.push(D("nightAfter", "", { ids: t.map((e) => e.uid) })), e.queue.unshift(...r), !0;
		}
		case "protectBatch": return B(e, r, "protectBatch", [V("protect", "sacrificePeregrine", [D("move", r, {
			card: t.card,
			zone: "discard"
		})], {
			card: t.card,
			def: 175100
		}), V("allow", "allowElimination", t.then)]), !0;
		case "batch": return e.queue.unshift(...t.then ?? []), !0;
		case "eliminate": {
			let r = k(e, t.card);
			if (r.zone !== "active") return !0;
			e.queue.unshift(...t.then ?? []);
			let i = S[r.def].archetype === "heir", a = e.cards.find((e) => e.owner === r.owner && e.def === 175040 && e.zone === "occupying");
			i && a ? (R(e, r, "hand", n), Ee(e, a, n)) : (R(e, r, (t.mode ? t.mode === "resilient" : z(e, r).traits.includes("resilient")) ? "discard" : "lost", n), M(e, r.owner, 175032) && B(e, r.owner, "recoverEliminated", [V("recover", "returnHand", [D("move", r.owner, {
				card: r.uid,
				zone: "hand"
			})], { def: r.def })], { min: 0 }));
			let o = `forgeEvent:${t.key ?? ++e.serial}`;
			if (!e.players[0].used.includes(o)) {
				e.players[0].used.push(o), e.sim.enabled && e.queue.unshift(D("forgeElimination"));
				for (let t of e.players.filter((t) => M(e, t.rid, 175711))) U(e, t.rid, "influence", 1, n), U(e, t.rid, "lore", 1, n);
			}
			return F(n, "eliminate", r.owner, {
				def: r.def,
				uid: r.uid
			}), H(e, "eliminated", r.owner, r.def), !0;
		}
		case "killReward": {
			let i = O(e, r);
			return i.used.includes(t.key) ? !0 : (i.used.push(t.key), i.flags.includes("streets") && (U(e, r, "influence", 1, n), U(e, r, "lore", 1, n)), M(e, r, 175034) && t.n && U(e, r, "influence", 1, n), t.nums?.includes(174315) && e.queue.unshift(D("chooseResource", r)), !0);
		}
		case "chooseResource": return B(e, r, "chooseResource", [V("influence", "influence", [D("gain", r, { n: 1 })]), V("lore", "lore", [D("gain", r, {
			n: 1,
			mode: "lore"
		})])]), !0;
		case "nightAfter": return e.queue.unshift(D("simNightAfter"), D("boonNightAfter")), !0;
		case "beforeDay": return e.queue.unshift(D("moduleBeforeDay")), !0;
		case "winAbilities": {
			let t = G(e, r);
			t.some((t) => be(e, t, 174416)) && U(e, r, "influence", 1, n), M(e, r, 175016) && t.some((t) => z(e, t).archetype === "heir") && U(e, r, "influence", 1, n);
			let i = t.find((e) => S[e.def].kind === "creature"), a = O(e, r).heralds[1];
			return i && a != null && Math.floor(a / 2) === e.region && (U(e, r, "influence", 1, n), U(e, r, "lore", 1, n)), e.queue.unshift(D("boonWin", r)), !0;
		}
		case "clashResolved":
			for (let t of e.players.filter((e) => e.flags.includes("storms"))) {
				let r = t.supporters[e.region], i = j(e, t.rid, e.region).length;
				r > 0 && e.players.every((n) => n.rid === t.rid || n.supporters[e.region] < r) && U(e, t.rid, "influence", 1, n), i > 0 && e.players.every((n) => n.rid === t.rid || j(e, n.rid, e.region).length < i) && U(e, t.rid, "lore", 1, n);
			}
			if (e.config.creatures) for (let t of e.humans.filter((e) => e !== r)) {
				let r = O(e, t).heralds[1];
				if (r == null || Math.floor(r / 2) !== e.region) continue;
				let i = A(e, t, "supply").find((e) => S[e.def].kind === "creature");
				i && R(e, i, "hand", n);
			}
			return !0;
		case "siteAcquisition": {
			let n = k(e, t.card);
			return n.def === 174016 && e.queue.unshift(D("queenGovern", r, {
				n: 3,
				nums: []
			})), n.def === 177200 && (n.influence = 3), !0;
		}
		case "queenGovern": return t.n && K(e, r, "queenGovern", [...A(e, r, "discard"), ...A(e, r, "lost")].filter((t) => z(e, t).votes > 0), (e) => [D("queenCouncil", r, {
			card: e.uid,
			n: t.n,
			nums: t.nums
		})]), !0;
		case "queenCouncil": return B(e, r, "council", [
			0,
			1,
			2
		].filter((e) => !t.nums.includes(e)).map((e) => V(String(e), "council", [D("govern", r, {
			card: t.card,
			suit: e
		}), D("queenGovern", r, {
			n: t.n - 1,
			nums: [...t.nums, e]
		})], { suit: e }))), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/oldkingscrown/effects.ts
var Ge = {
	175001: "spring",
	175005: "spring",
	175012: "spring",
	175013: "spring",
	175015: "autumn",
	175018: "spring",
	175019: "spring autumn",
	175020: "day",
	175021: "day",
	175022: "spring",
	175023: "autumn",
	175024: "spring",
	175025: "spring",
	175028: "day",
	175029: "spring",
	175030: "autumn",
	175031: "autumn",
	175035: "autumn",
	175036: "autumn",
	175037: "spring",
	175039: "day",
	175041: "autumn",
	175043: "day",
	175044: "day",
	175045: "day",
	175046: "spring",
	175047: "autumn",
	175049: "day",
	175050: "day",
	176700: "autumn",
	177e3: "spring",
	177100: "day",
	176800: "autumn",
	177200: "day",
	174015: "autumn",
	174017: "autumn",
	177415: "autumn",
	177416: "day",
	175101: "day",
	175102: "autumn"
};
function Ke(e, t, n) {
	let r = O(e, t), i = [], a = D("actionStep", t, { mode: n }), o = (e, t, n, r = {}) => i.push(V(e, t, [...n, a], r));
	for (let i of e.cards.filter((e) => e.owner === t && [
		"occupying",
		"supply",
		"active",
		"council"
	].includes(e.zone))) for (let a of ye(e, i)) Ge[a]?.split(" ").includes(n) && !r.used.includes(`effect:${a}:${n}`) && (i.zone !== "active" || n !== "day" || G(e, t).includes(i) && (e.dayNew === null || e.dayNew.includes(i.uid))) && (n !== "day" || e.dayNew === null || i.zone === "active") && ([174015, 177415].includes(a) && i.zone !== "council" || o(`effect:${i.uid}:${a}`, "activate", [D("effect", t, {
		card: i.uid,
		def: a,
		mode: n
	})], {
		card: i.uid,
		def: a
	}));
	for (let i of r.tactics) !i.exhausted && S[i.def].timing === n && (n !== "day" || e.dayNew === null) && o(`tactic:${i.def}`, "activateTactic", [D("tactic", t, {
		def: i.def,
		mode: n
	})], {
		def: i.def,
		n: i.markers
	});
	let s = (e) => e === "clans" ? "day" : e === "gathering" ? "autumn" : "spring";
	if (n !== "day" || e.dayNew === null) {
		let i = e.favour.owner === t, a = M(e, t, 175014);
		if (s(r.faction) === n && (i || a) && !r.used.includes("favour") && o("favour", "favour", [D("favour", t, {
			mode: r.faction,
			key: "favour"
		})]), i && a && r.used.includes("favour") && !r.used.includes("favourExtra") && s(r.faction) === n && o("favourExtra", "favour", [D("favour", t, {
			mode: r.faction,
			key: "favourExtra"
		})]), M(e, t, 175027) && !r.used.includes("prototype")) for (let r of e.players.filter((e) => e.rid !== t && e.faction !== "simulacrum" && s(e.faction) === n)) o(`prototype:${r.rid}`, "opponentFavour", [D("favour", t, {
			mode: r.faction,
			key: "prototype"
		})], { player: r.rid });
	}
	return i;
}
var qe = (e, t, n, r = !1) => {
	let i = k(e, t);
	r && e.cards.filter((e) => e.parent === t).forEach((t) => R(e, t, "discard", n)), Ee(e, i, n);
}, Je = (e, t, n, r) => B(e, t, "region", [
	0,
	1,
	2
].map((e) => V(String(e), "region", [{
	...n,
	region: e,
	kind: r,
	actor: t
}], { region: e })));
function Ye(e, t, n) {
	let r = t.actor, i = r ? O(e, r) : void 0;
	switch (t.kind) {
		case "effect": {
			if (!we(e, r, `effect:${t.def}:${t.mode}`)) return !0;
			let a = k(e, t.card), o = t.def;
			switch (o) {
				case 175001: {
					let t = [
						0,
						1,
						2
					].filter((t) => A(e, r, "council").some((e) => e.suit === t));
					t.length && U(e, r, "influence", 1, n), t.length === 3 && B(e, r, "monument", [V("discard", "discardForInfluence", [D("discardKingdom", r, { card: a.uid }), D("gain", r, { n: 2 })])], { min: 0 });
					break;
				}
				case 175005:
					B(e, r, "burnTactic", i.tactics.map((e) => V(String(e.def), "burnTactic", [D("burnTactic", r, { def: e.def })], { def: e.def })));
					break;
				case 175012:
					U(e, r, i.lore ? "lore" : "influence", 1, n);
					break;
				case 175013:
					K(e, r, "returnHand", A(e, r, "discard"), (e) => [D("move", r, {
						card: e.uid,
						zone: "hand"
					})], 1, 1);
					break;
				case 175015:
					K(e, r, "estate", A(e, r, "council"), (e) => [
						D("move", r, {
							card: e.uid,
							zone: "discard"
						}),
						D("handSize", r, { n: 1 }),
						D("discardKingdom", r, { card: a.uid })
					], 1, 1);
					break;
				case 175018:
					B(e, r, "rumoursPlayers", e.players.map((e) => V(e.rid, "player", [D("handToBottom", e.rid)], { player: e.rid })), {
						min: 0,
						max: e.players.length
					});
					break;
				case 175019:
					K(e, r, "swapHand", A(e, r, "hand"), (e) => [D("swapTarget", r, {
						card: e.uid,
						mode: "councilOccupying"
					})], 1, 1);
					break;
				case 175020: {
					let t = A(e, r, "hand");
					e.players.forEach((n) => {
						e.known[n.rid] = [.../* @__PURE__ */ new Set([...e.known[n.rid] ?? [], ...t.map((e) => e.uid)])];
					});
					for (let i of G(e).filter((n) => He(e, r, n.owner) && t.some((e) => S[e.def].strength === S[n.def].strength || S[e.def].archetype === S[n.def].archetype))) R(e, i, "hand", n);
					qe(e, a.uid, n);
					break;
				}
				case 175021:
					B(e, r, "lantern", [...Be(e), -1].map((t) => V(String(t), t < 0 ? "supply" : "region", [D("flankSupporters", r, {
						region: e.region,
						location: t
					})], { region: t })));
					break;
				case 175022:
					Je(e, r, t, "innkeeper");
					break;
				case 175023:
					K(e, r, "diary", j(e, r), (e) => [
						D("governCouncil", r, { card: e.uid }),
						D("diaryDiscard", r, { card: e.uid }),
						D("discardKingdom", r, { card: a.uid })
					], 1, 1);
					break;
				case 175024:
					K(e, r, "swapHand", A(e, r, "hand"), (e) => [D("swapTarget", r, {
						card: e.uid,
						mode: "lost"
					})], 1, 1);
					break;
				case 175025:
					qe(e, a.uid, n), e.queue.unshift(D("roadAcquire", r, { n: 2 }), D("roadRefill"));
					break;
				case 175028:
					K(e, r, "mirror", G(e, r), (e) => [D("copyLost", r, { card: e.uid })], 1, 1);
					break;
				case 175029:
					B(e, r, "sirenLocation", Array.from({ length: 6 }, (e, t) => V(String(t), "location", [D("sirenHeralds", r, { location: t }), D("discardKingdom", r, { card: a.uid })], { location: t })));
					break;
				case 175030:
					K(e, r, "blueHour", A(e, r, "lost"), (e) => [D("deckEnd", r, { card: e.uid })], 80, 0, [D("discardKingdom", r, { card: a.uid })]);
					break;
				case 175031:
					K(e, r, "returnHand", j(e, r), (e) => [D("move", r, {
						card: e.uid,
						zone: "hand"
					})], 1, 1);
					break;
				case 175035:
					K(e, r, "returnFollower", A(e, r, "discard").filter((e) => S[e.def].archetype === "follower"), (e) => [D("move", r, {
						card: e.uid,
						zone: "hand"
					})], 1, 1);
					break;
				case 175036:
					K(e, r, "engineers", j(e, r).filter((t) => z(e, t).commands.some((e) => e.startsWith("deploy"))), (e) => [D("cardInfluence", r, {
						card: e.uid,
						n: 1
					})], 1, 1);
					break;
				case 175037:
					qe(e, a.uid, n);
					for (let t of e.players.filter((e) => e.faction !== "simulacrum")) K(e, t.rid, "tourney", A(e, t.rid, "hand"), (e) => [D("move", t.rid, {
						card: e.uid,
						zone: "bid"
					})], 1, 1);
					e.sim.enabled && Ce(e, 1).forEach((t) => R(e, t, "bid", n)), e.queue.unshift(D("tourneyResolve"));
					break;
				case 175039:
					K(e, r, "hiddenLanes", G(e, r), (e) => [D("swapTarget", r, {
						card: e.uid,
						mode: "councilOccupying"
					})], 1, 1);
					break;
				case 175041:
					e.queue.unshift(D("recallSupporters", r, { n: 2 }));
					break;
				case 175043:
					K(e, r, "grantRetreat", G(e, r), (e) => [D("grant", r, {
						card: e.uid,
						key: "retreat",
						mode: "clash"
					}), D("flag", r, { key: `smuggler:${e.uid}` })], 1, 1);
					break;
				case 175044:
				case 175049:
				case 175050:
					K(e, r, "grantAbility", G(e, r), (e) => [D("grant", r, {
						card: e.uid,
						key: o === 175044 ? "ambush" : o === 175049 ? "deadly" : "invulnerable",
						mode: "clash"
					})], 1, 1), o !== 175044 && qe(e, a.uid, n, o === 175049);
					break;
				case 175045:
					i.flags.push(`strength:${e.region}:${e.clash}:5`), qe(e, a.uid, n, !0);
					break;
				case 175046:
					Je(e, r, t, "sundial");
					break;
				case 175047:
					B(e, r, "refreshTactic", i.tactics.filter((e) => e.exhausted).map((e) => V(String(e.def), "refreshTactic", [D("refreshTactic", r, { def: e.def }), D("consume", r, {
						card: a.uid,
						n: 1
					})], { def: e.def })));
					break;
				case 176700: {
					let t = A(e, r, "discard").filter((e) => S[e.def].archetype === "trader");
					B(e, r, "royalBank", [V("influence", "influence", [D("gain", r, { n: 1 })]), ...t.map((e) => ze(e, [D("move", r, {
						card: e.uid,
						zone: "hand"
					})]))], {
						min: 1,
						max: e.order[0] === r ? 1 : 2
					});
					break;
				}
				case 177e3:
					e.queue.unshift(D("harbour", r, { n: Math.min(2, i.supporterLost) }));
					break;
				case 177100:
					K(e, r, "embassy", j(e, r).filter((t) => z(e, t).commands.includes("flank")), (e) => [D("governCouncil", r, { card: e.uid })], 80);
					break;
				case 176800:
					K(e, r, "moonshine", A(e, r, "hand").filter((e) => ["captain", "trader"].includes(S[e.def].archetype ?? "")), (e) => [D("moonshineRoad", r, { card: e.uid })], 1, 1);
					break;
				case 177200:
					a.influence > 0 && K(e, r, "door", G(e, r), (e) => [
						D("cardInfluence", r, {
							card: a.uid,
							n: -1
						}),
						D("grant", r, {
							card: e.uid,
							key: "ambush"
						}),
						D("doorDiscard", r, {
							card: e.uid,
							target: a.uid
						})
					], 1, 1);
					break;
				case 174015:
					e.queue.unshift(D("governCouncil", r, { card: a.uid }));
					break;
				case 174017:
					i.supporters[a.region] >= 2 && (a.influence += 1, F(n, "cardInfluence", r, {
						uid: a.uid,
						n: 1
					}));
					break;
				case 177415:
					B(e, r, "councilMarker", [
						0,
						1,
						2
					].map((e) => V(String(e), "council", [D("councilMarker", r, {
						suit: e,
						n: 1
					})], { suit: e })));
					break;
				case 177416:
					K(e, r, "tooth", A(e, r, "lost"), (e) => [D("tooth", r, {
						card: a.uid,
						target: e.uid
					})], 1, 1);
					break;
				case 175101: {
					let t = j(e, r).filter((t) => t.region !== e.region);
					B(e, r, "waxwing", [V("deadly", "gainDeadly", [D("grant", r, {
						card: a.uid,
						key: "deadly"
					}), D("flag", r, { key: `noRetreat:${a.uid}` })]), ...t.map((e) => ze(e, [D("move", r, {
						card: e.uid,
						zone: "discard"
					}), D("flag", r, { key: `noRetreat:${a.uid}` })]))], {
						min: 1,
						max: 2
					});
					break;
				}
				case 175102: K(e, r, "medic", A(e, r, "discard"), (e) => [D("move", r, {
					card: e.uid,
					zone: "deck",
					mode: "bottom"
				})], 3, 1, [D("flag", r, { key: `noRally:${a.uid}` })]);
			}
			return H(e, "activated", r, o), !0;
		}
		case "consume": return qe(e, t.card, n, !!t.n), !0;
		case "handSize": return xe(e, r, t.n, n), e.queue.unshift(D("discardHand", r, { mode: "limit" })), !0;
		case "burnTactic": {
			let a = i.tactics.find((e) => e.def === t.def);
			return i.tactics = i.tactics.filter((e) => e !== a), U(e, r, "lore", a.exhausted ? 1 : 3, n), !0;
		}
		case "refreshTactic": {
			let a = i.tactics.find((e) => e.def === t.def);
			return a.exhausted = !1, a.markers = S[a.def].markers ?? 0, F(n, "tactic", r, {
				def: a.def,
				exhausted: !1
			}), e.beat = E.reveal, !0;
		}
		case "swapTarget": return K(e, r, "swapTarget", (t.mode === "lost" ? A(e, r, "lost") : e.cards.filter((e) => e.owner === r && (e.zone === "council" || e.zone === "occupying" && e.parent))).filter((e) => e.uid !== t.card), (e) => [D("swapCards", r, {
			card: t.card,
			target: e.uid
		})], 1, 1), !0;
		case "swapCards": {
			let i = k(e, t.card), a = k(e, t.target);
			if (i.region !== null && Ve(e, r, i.region) || a.region !== null && Ve(e, r, a.region)) return !0;
			let o = {
				zone: i.zone,
				region: i.region,
				location: i.location,
				suit: i.suit,
				parent: i.parent,
				faceUp: i.faceUp,
				influence: i.influence
			}, s = {
				zone: a.zone,
				region: a.region,
				location: a.location,
				suit: a.suit,
				parent: a.parent,
				faceUp: a.faceUp,
				influence: a.influence
			};
			return R(e, i, s.zone, n, s), R(e, a, o.zone, n, o), i.influence = s.zone === "active" ? s.influence : 0, a.influence = o.zone === "active" ? o.influence : 0, (i.region === e.region || a.region === e.region) && (e.dayNew = e.dayNew === null ? null : [
				...e.dayNew,
				i.uid,
				a.uid
			]), !0;
		}
		case "handToBottom": {
			if (r === "$simulacrum") {
				let t = A(e, T, "deck")[0];
				return t && R(e, t, "deck", n, { bottom: !0 }), !0;
			}
			let t = A(e, r, "hand");
			return K(e, r, "handOrder", t, (e) => [D("move", r, {
				card: e.uid,
				zone: "deck",
				mode: "bottom"
			})], t.length, t.length, [D("draw", r, { n: t.length })]), !0;
		}
		case "innkeeper": {
			let n = e.cards.filter((e) => e.zone === "active" && !e.faceUp && e.region === t.region);
			return e.known[r] = [.../* @__PURE__ */ new Set([...e.known[r] ?? [], ...n.map((e) => e.uid)])], e.queue.unshift(D("swapHidden", r, { target: r })), !0;
		}
		case "swapHidden": return K(e, r, "swapHidden", e.cards.filter((e) => e.owner === t.target && e.zone === "active" && !e.faceUp), (e) => [D("swapHiddenOther", r, {
			card: e.uid,
			target: t.target
		})]), !0;
		case "swapHiddenOther": return K(e, r, "swapHidden", e.cards.filter((e) => e.owner === t.target && e.zone === "active" && !e.faceUp && e.uid !== t.card), (e) => [D("swapCards", r, {
			card: t.card,
			target: e.uid
		})], 1, 1), !0;
		case "diaryDiscard": {
			let n = k(e, t.card).suit;
			return K(e, r, "discardCouncil", e.cards.filter((e) => e.zone === "council" && e.suit === n), (e) => [D("move", r, {
				card: e.uid,
				zone: "discard"
			})], 80), !0;
		}
		case "copyLost": return K(e, r, "copyLost", e.cards.filter((e) => e.zone === "lost"), (e) => [D("copy", r, {
			card: t.card,
			def: e.def
		})], 1, 1), !0;
		case "copy": return k(e, t.card).copy = t.def, !0;
		case "sirenHeralds": {
			let n = t.step ?? 0;
			if (n >= e.order.length) return !0;
			let i = O(e, e.order[n]), a = D("sirenHeralds", r, {
				location: t.location,
				step: n + 1
			});
			return B(e, r, "sirenHeralds", i.heralds.flatMap((e, n) => e === null || i.heralds.some((e, r) => r !== n && e === t.location) ? [] : [V(`${i.rid}:${n}`, "playerHerald", [D("herald", i.rid, {
				location: t.location,
				step: n
			})], {
				player: i.rid,
				location: e
			})]), {
				min: 0,
				after: [a]
			}), !0;
		}
		case "deckEnd": return B(e, r, "deckEnd", [V("top", "deckTop", [D("move", r, {
			card: t.card,
			zone: "deck"
		})]), V("bottom", "deckBottom", [D("move", r, {
			card: t.card,
			zone: "deck",
			mode: "bottom"
		})])]), !0;
		case "sundial": {
			let r = k(e, t.card);
			return e.cards.filter((e) => e.parent === r.uid).forEach((t) => R(e, t, "discard", n)), R(e, r, "supply", n, { region: t.region }), !0;
		}
		case "recallSupporters": return e.queue.unshift(D("oaths", r, { n: t.n })), !0;
		case "harbour": return t.n && B(e, r, "harbour", [
			0,
			1,
			2
		].map((e) => V(String(e), "region", [D("harbourPlace", r, { region: e }), D("harbour", r, { n: t.n - 1 })], { region: e })), { min: 0 }), !0;
		case "harbourPlace": return I(e, r, -2, t.region, 1, n), !0;
		case "moonshineRoad": return B(e, r, "moonshineRoad", Fe(e, r).map(({ def: e, n, key: i }) => V(`${i ?? "road"}:${n}`, "acquire", [D("moonshineAcquire", r, {
			card: t.card,
			def: e,
			n,
			key: i
		})], { def: e }))), !0;
		case "moonshineAcquire": return e.queue.unshift(D("acquireKingdom", r, {
			card: t.card,
			def: t.def,
			n: t.n,
			key: t.key,
			location: 2
		}), D("roadRefill")), !0;
		case "doorDiscard": return k(e, t.target).influence > 0 && B(e, r, "doorDiscard", [V("yes", "ambushDiscard", [D("cardInfluence", r, {
			card: t.target,
			n: -1
		}), D("flag", r, { key: `discardAmbush:${t.card}` })])], { min: 0 }), !0;
		case "councilMarker": return L(e, r, "councilMarker", t.suit, t.n, n), !0;
		case "tooth": {
			let r = k(e, t.card), a = k(e, t.target), o = S[a.def];
			return r.strengthBonus += o.strength ?? 0, r.gainedTraits.push(...o.traits ?? []), r.gainedCommands.push(...o.commands ?? []), i.flags.push(`tooth:${r.uid}:${a.def}`), r.gainedRules.push(a.def), R(e, a, "burned", n), !0;
		}
		case "tourneyResolve": {
			let t = e.cards.filter((e) => e.zone === "bid"), r = (e) => t.filter((t) => S[t.def].strength === e).length, i = t.filter((e) => r(S[e.def].strength ?? 0) === 1).sort((e, t) => (S[t.def].strength ?? 0) - (S[e.def].strength ?? 0));
			for (let i of t) R(e, i, r(S[i.def].strength ?? 0) > 1 ? "discard" : "hand", n);
			return i[0] && e.queue.unshift(D("anyLocation", i[0].owner)), !0;
		}
		case "anyLocation": return B(e, r, "location", Array.from({ length: 6 }, (e, t) => V(String(t), "location", [D("locationReward", r, { location: t })], { location: t }))), !0;
		case "roadAcquire": return !t.n || !A(e, r, "hand").length || B(e, r, "roadAcquire", Fe(e, r).map(({ def: e, n, key: i }) => V(`${i ?? "road"}:${n}`, "acquire", [D("roadGuard", r, {
			def: e,
			n,
			key: i
		}), D("roadAcquire", r, { n: t.n - 1 })], { def: e })), { min: 0 }), !0;
		case "roadGuard": return K(e, r, "occupy", A(e, r, "hand"), (e) => [D("acquireKingdom", r, {
			def: t.def,
			card: e.uid,
			n: t.n,
			key: t.key
		})], 1, 1), !0;
		case "roadRefill": return Pe(e, n), !0;
		case "yearAbilities": {
			let t = e.players.find((t) => M(e, t.rid, 175026));
			return t && e.queue.unshift(D("orderChoose", t.rid, { ids: [] })), !0;
		}
		case "orderChoose": return t.ids.length === e.order.length ? (e.order = t.ids, le(e), !0) : (B(e, r, "orderPlayer", e.players.filter((e) => !t.ids.includes(e.rid)).map((e) => V(e.rid, "player", [D("orderChoose", r, { ids: [...t.ids, e.rid] })], { player: e.rid }))), !0);
		case "kingdomAcquisition": {
			let i = k(e, t.card);
			if (t.target && R(e, k(e, t.target), "discard", n), [
				175009,
				175042,
				175048
			].includes(i.def)) Je(e, r, t, "placeMapKingdom");
			else if (i.def === 175010) B(e, r, "location", Array.from({ length: 6 }, (e, t) => V(String(t), "location", [D("placeMapKingdom", r, {
				card: i.uid,
				location: t
			})], { location: t })));
			else if (i.def === 175006) {
				let t = A(e, r, "site"), a = Math.min(...t.map((e) => S[e.def].cost ?? 0));
				K(e, r, "beacon", t.filter((e) => S[e.def].cost === a), (e) => [D("acquireSite", r, {
					card: e.uid,
					mode: "free"
				})], 1, +!!t.length), qe(e, i.uid, n);
			} else i.def === 175033 ? i.zone = "supply" : S[i.def].kind === "wild" && e.queue.unshift(D("wildAcquisition", r, {
				card: i.uid,
				def: i.def
			}));
			return e.queue.unshift(D("afterAcquireKingdom", r, { card: i.uid })), !0;
		}
		case "placeMapKingdom": return R(e, k(e, t.card), "supply", n, {
			region: t.region,
			location: t.location
		}), !0;
		case "afterAcquireKingdom": {
			let a = k(e, t.card), o = b.indexOf(S[a.def].suit);
			return M(e, r, 176900) && o >= 0 && i.councilMarkers[o] < 2 && L(e, r, "councilMarker", o, 1, n), !0;
		}
		case "winterEffects":
			for (let t of e.cards.filter((e) => e.zone === "supply" && [
				175042,
				175046,
				175048
			].includes(e.def))) Ee(e, t, n);
			return e.queue.unshift(D("wildWinter")), !0;
		case "favour": return we(e, r, t.key), e.favour.owner === r && t.key !== "prototype" && (--e.favour.uses, e.favour.uses || (e.favour.owner = null)), t.mode === "nobility" && B(e, r, "regalGuard", [V("influence", "influence", [D("gain", r, { n: 1 })]), V("protect", "protectHeirs", [D("flag", r, { key: "regalGuard" })])]), t.mode === "uprising" && Je(e, r, t, "spyNetwork"), t.mode === "clans" && e.region !== null && e.queue.unshift(D("clansFavour", r, { n: 2 })), t.mode === "gathering" && K(e, r, "heraldMoon", j(e, r).filter((e) => i.heralds.some((t) => t !== null && Math.floor(t / 2) === e.region)), (e) => [D("move", r, {
			card: e.uid,
			zone: "hand"
		})], 1, 1), !0;
		case "spyNetwork": return e.known[r] = [.../* @__PURE__ */ new Set([...e.known[r] ?? [], ...e.cards.filter((e) => e.zone === "active" && !e.faceUp && e.region === t.region).map((e) => e.uid)])], K(e, r, "spySwap", e.cards.filter((e) => e.owner === r && e.zone === "active" && !e.faceUp), (e) => [D("spySwap", r, { card: e.uid })]), !0;
		case "spySwap": return K(e, r, "spySwap", [...A(e, r, "hand"), ...A(e, r, "occupying").filter((e) => e.parent)], (e) => [D("swapCards", r, {
			card: t.card,
			target: e.uid
		})], 1, 1), !0;
		case "clansFavour": return B(e, r, "herald", i.heralds.flatMap((t, n) => [e.region * 2, e.region * 2 + 1].filter((e) => !i.heralds.includes(e)).map((e) => V(`${n}:${e}`, "location", [D("herald", r, {
			location: e,
			step: n
		})], { location: e }))), {
			min: 0,
			after: [D("clansSupporters", r, { n: 2 })]
		}), !0;
		case "clansSupporters": return t.n && B(e, r, "clansSupporters", i.supporters.flatMap((n, i) => n && i !== e.region ? [V(String(i), "region", [D("transferSupporters", r, {
			region: i,
			location: e.region,
			n: 1
		}), D("clansSupporters", r, { n: t.n - 1 })], { region: i })] : []), { min: 0 }), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/oldkingscrown/meta.ts
var Xe = {
	id: "oldkingscrown",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"area-control",
		"auction",
		"deck-bag-building"
	],
	interactionTags: [],
	nameKey: "games.oldkingscrown.name",
	descKey: "games.oldkingscrown.desc",
	rulesKey: "games.oldkingscrown.rules",
	icon: "👑",
	iconImg: "games/oldkingscrown.webp",
	rulesUrl: { en: "https://www.dropbox.com/scl/fo/st2zoegtbn2iso1q2fjwe/AJyt43N_u95DpfZZ34fjvyg/The%20Old%20King%27s%20Crown/English/The%20Old%20King%27s%20Crown%20Rulebook.pdf?rlkey=v5gar5zid7u27s2xoba85uyl0&dl=1" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	playerRange: (e) => {
		let t = e && typeof e == "object" ? e : {};
		return {
			min: t.negotiating ? 3 : t.simulacrum === "off" ? 2 : 1,
			max: t.simulacrum === "competitive" || t.simulacrum === "cooperative" ? 3 : 4
		};
	},
	accent: "#b09a5a",
	releasedAt: "2026-11-04T20:35:00+08:00",
	search: {
		py: "xianwangzhiguan",
		init: "xwzg"
	},
	hotseat: "cover",
	botDelayMs: 650
}, Ze = t.object({
	years: t.union([
		t.literal(4),
		t.literal(5),
		t.literal(6)
	]).default(5),
	advancedSetup: t.boolean().default(!1),
	factions: t.array(t.enum([
		"random",
		"nobility",
		"clans",
		"uprising",
		"gathering"
	])).max(4).default([]),
	simulacrum: t.enum([
		"auto",
		"off",
		"competitive",
		"cooperative"
	]).default("auto"),
	forge: t.array(t.object({
		id: t.int().min(1).max(30),
		side: t.enum(["a", "b"]),
		value: t.int().min(0).max(20).default(1)
	})).max(30).refine((e) => new Set(e.map((e) => e.id)).size === e.length && e.every((e) => e.id !== 16 || e.side !== "b" || e.value <= 4)).default([]),
	threats: t.array(t.int().min(1).max(24)).max(24).refine((e) => new Set(e).size === e.length).default([]),
	simAdvanced: t.array(t.int().min(0).max(7)).max(8).refine((e) => new Set(e).size === e.length).default([]),
	aeronauts: t.boolean().default(!1),
	creatures: t.boolean().default(!1),
	negotiating: t.boolean().default(!1),
	nightMap: t.boolean().default(!1),
	town: t.boolean().default(!1),
	tower: t.boolean().default(!1),
	wild: t.array(t.int().min(0).max(14)).max(15).refine((e) => new Set(e).size === e.length).default([])
}).default({
	years: 5,
	advancedSetup: !1,
	factions: [],
	simulacrum: "auto",
	forge: [],
	threats: [],
	simAdvanced: [],
	aeronauts: !1,
	creatures: !1,
	negotiating: !1,
	nightMap: !1,
	town: !1,
	tower: !1,
	wild: []
}), Qe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		prompt: t.int().nonnegative(),
		options: t.array(t.string().max(100)).max(80),
		text: t.string().max(1e3).optional()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	}),
	t.object({
		type: t.literal("agreementRequest"),
		id: t.int().nonnegative(),
		mode: t.enum([
			"fulfilled",
			"cancelled",
			"breach"
		]),
		target: t.string().optional()
	}),
	t.object({
		type: t.literal("promise"),
		target: t.string(),
		text: t.string().trim().min(1).max(1e3)
	}),
	t.object({
		type: t.literal("allianceHand"),
		target: t.string(),
		show: t.boolean()
	})
]), $e = t.object({
	uid: t.string(),
	def: t.int().nullable(),
	owner: t.string(),
	zone: t.string(),
	region: t.int().nullable(),
	location: t.int().nullable(),
	suit: t.int().nullable(),
	parent: t.string().nullable(),
	influence: t.int().nonnegative(),
	faceUp: t.boolean(),
	votes: t.int().nonnegative(),
	lore: t.int().nonnegative(),
	strength: t.int(),
	traits: t.array(t.string()),
	commands: t.array(t.string()),
	archetypes: t.array(t.string()),
	copy: t.int().nullable(),
	gainedRules: t.array(t.int()),
	tier: t.string().nullable(),
	back: t.string(),
	guardStrength: t.int(),
	boons: t.array(t.int().nullable()),
	fought: t.boolean()
}), et = t.object({
	id: t.string(),
	label: t.string(),
	card: t.string().optional(),
	def: t.int().optional(),
	region: t.int().optional(),
	location: t.int().optional(),
	suit: t.int().optional(),
	player: t.string().optional(),
	n: t.number().optional(),
	weight: t.number().optional()
}), tt = t.object({
	id: t.int(),
	actor: t.string(),
	subject: t.string().optional(),
	kind: t.string(),
	source: t.int().optional(),
	min: t.int(),
	max: t.int(),
	options: t.array(et),
	allowText: t.boolean().optional()
}), nt = t.object({
	year: t.int(),
	years: t.int(),
	phase: t.string(),
	step: t.string(),
	order: t.array(t.string()),
	regionOrder: t.array(t.int()),
	region: t.int().nullable(),
	clash: t.int(),
	players: t.array(t.object({
		rid: t.string(),
		faction: t.string(),
		influence: t.int(),
		lore: t.int(),
		handSize: t.int(),
		handCount: t.int(),
		deckCount: t.int(),
		supporterSupply: t.int(),
		supporterLost: t.int(),
		supporterBurned: t.int(),
		supporters: t.array(t.int()),
		heralds: t.array(t.int().nullable()),
		markers: t.array(t.int()),
		pending: t.boolean(),
		bidStrength: t.int().nullable(),
		councilMarkers: t.array(t.int()),
		councilVotes: t.array(t.int()),
		score: t.int(),
		tradeCards: t.int(),
		boons: t.int(),
		tactics: t.array(t.object({
			def: t.int(),
			exhausted: t.boolean(),
			markers: t.int(),
			controllers: t.array(t.string())
		}))
	})),
	cards: t.array($e),
	road: t.array(t.int()),
	kingdomCount: t.int(),
	kingdomDiscard: t.array(t.int()),
	favour: t.object({
		owner: t.string().nullable(),
		uses: t.int()
	}),
	strengths: t.record(t.string(), t.int()),
	config: Ze,
	waiting: t.array(t.object({
		actor: t.string(),
		kind: t.string()
	})),
	modules: t.object({
		locations: t.array(t.int()),
		air: t.int().nullable(),
		airOwner: t.string().nullable(),
		airRegion: t.int().nullable(),
		airCards: t.array(t.int()),
		tower: t.int().nullable(),
		town: t.int().nullable(),
		towerBoons: t.array(t.int().nullable()),
		boonBag: t.int(),
		boonDiscard: t.array(t.int()),
		townInfluence: t.int(),
		locationInfluence: t.array(t.int())
	}),
	sim: t.object({
		enabled: t.boolean(),
		heat: t.int(),
		ambition: t.int().nullable(),
		scheme: t.int().nullable(),
		ambitionBack: t.int().nullable(),
		schemeBack: t.int().nullable(),
		deckTier: t.string().nullable(),
		threats: t.array(t.int()),
		fog: t.array(t.array(t.int().nullable())),
		towers: t.array(t.int()),
		caches: t.int()
	}),
	agreements: t.array(t.object({
		id: t.int(),
		a: t.string(),
		b: t.string(),
		text: t.string(),
		binding: t.boolean(),
		alliance: t.boolean(),
		status: t.string()
	})),
	log: t.array(t.object({
		key: t.string(),
		actor: t.string().optional(),
		card: t.int().optional(),
		n: t.int().optional(),
		target: t.string().optional()
	})),
	done: t.boolean(),
	winner: t.array(t.string()),
	scores: t.record(t.string(), t.int())
}), rt = t.object({
	kind: t.string(),
	n: t.int(),
	uid: t.string().optional(),
	def: t.int().optional(),
	index: t.int().optional(),
	target: t.string().optional()
}), it = t.object({
	hand: t.array($e),
	prompts: t.array(tt),
	known: t.array($e),
	boons: t.array(t.int()),
	alliedHands: t.array(t.object({
		rid: t.string(),
		cards: t.array($e)
	})),
	sharingWith: t.array(t.string()),
	trade: t.object({
		a: t.string(),
		b: t.string(),
		give: t.array(rt),
		take: t.array(rt),
		stage: t.string()
	}).nullable()
});
//#endregion
//#region src/games/oldkingscrown/tactics.ts
function at(e, t, n) {
	let r = t.actor;
	switch (t.kind) {
		case "bidRevealTactics":
			e.cards.filter((e) => e.zone === "bid").forEach((e) => {
				e.faceUp = !0;
			});
			for (let t of e.players) t.tactics.find((e) => e.def === 172600 && !e.exhausted) && B(e, t.rid, "royalSeal", [V("activate", "activateTactic", [D("tactic", t.rid, { def: 172600 })], { def: 172600 })], { min: 0 });
			return !0;
		case "tactic": {
			let i = O(e, r), a = i.tactics.find((e) => e.def === t.def);
			if (!a || a.exhausted) return !0;
			switch (a.markers > 0 ? (--a.markers, a.markers || (a.exhausted = !0)) : a.exhausted = !0, F(n, "tactic", r, {
				def: a.def,
				exhausted: a.exhausted
			}), e.beat = E.reveal, a.def) {
				case 170700:
					i.flags.push("storms");
					break;
				case 170800:
					K(e, r, "saltToughness", [...j(e, r), ...A(e, r, "discard")], (e) => [D("move", r, {
						card: e.uid,
						zone: "hand"
					})], Math.max(0, i.handSize - A(e, r, "hand").length));
					break;
				case 170900:
					K(e, r, "riverRunners", e.cards.filter((t) => He(e, r, t.owner) && t.zone === "occupying" && !t.parent && t.location !== null && t.location < 100), (e) => [D("stealGuard", r, {
						target: e.uid,
						def: e.def
					})], 1, 1);
					break;
				case 171e3:
					K(e, r, "seaLanes", G(e, r).filter((t) => [
						"heir",
						"captain",
						"warMachine"
					].includes(z(e, t).archetype ?? "")), (e) => [D("grant", r, {
						card: e.uid,
						key: "flank"
					})], 1, 1);
					break;
				case 171400:
					if (i.supporters[e.region] < 2) break;
					K(e, r, "schoolStars", A(e, r, "lost"), (t) => [D("transferSupporters", r, {
						region: e.region,
						location: -2,
						n: 2
					}), D("move", r, {
						card: t.uid,
						zone: "active",
						region: e.region
					})], 1, 1);
					break;
				case 171500:
					K(e, r, "beyondLights", j(e, r), (e) => [D("activeSwapOther", r, { card: e.uid })], 1, 1);
					break;
				case 171600:
					B(e, r, "foragers", N(e, e.kingdomDiscard).slice(0, 5).map((e) => V(String(e), "acquire", [D("foragerGuard", r, { def: e })], { def: e })), { min: 0 });
					break;
				case 171700:
					K(e, r, "ritualSacrifice", [...j(e, r), ...A(e, r, "discard")], (e) => [D("move", r, {
						card: e.uid,
						zone: "lost"
					}), D("gain", r, {
						mode: "lore",
						n: 1
					})], 3, 0, [D("sacrificeRecover", r)]);
					break;
				case 172e3:
					i.flags.push("streets");
					break;
				case 172100:
					B(e, r, "falseOrders", e.players.filter((t) => He(e, r, t.rid)).map((e) => V(e.rid, "player", [D("swapHidden", r, { target: e.rid })], { player: e.rid })), {
						min: 0,
						max: e.players.length - 1
					});
					break;
				case 172200: {
					let t = A(e, r, "occupying").filter((e) => !e.parent).length;
					for (let n of e.players.filter((t) => He(e, r, t.rid))) e.queue.unshift(D("discardHand", n.rid, { n: t }));
					break;
				}
				case 172300:
					K(e, r, "safehouses", G(e, r), (e) => [D("grant", r, {
						card: e.uid,
						key: "retreat",
						mode: "clash"
					})], 1, 1);
					break;
				case 172500:
					i.flags.push("stones");
					break;
				case 172600:
					i.flags.push("royalSeal");
					break;
				case 172700:
					B(e, r, "witchTrial", [
						0,
						1,
						2
					].map((e) => V(String(e), "council", [D("witchTrial", r, { suit: e })], { suit: e })));
					break;
				case 172800: B(e, r, "martialLaw", [...new Set(j(e, r).filter((t) => z(e, t).archetype === "warMachine").map((e) => e.region))].map((e) => V(String(e), "region", [D("flag", r, { key: `martial:${e}` })], { region: e })));
			}
			return !0;
		}
		case "stealGuard": return K(e, r, "occupy", A(e, r, "hand"), (e) => [D("acquireKingdom", r, {
			card: e.uid,
			def: t.def,
			target: t.target,
			mode: "steal"
		})], 1, 1), !0;
		case "activeSwapOther": return K(e, r, "beyondLights", j(e, r).filter((e) => e.uid !== t.card), (e) => [D("swapCards", r, {
			card: t.card,
			target: e.uid
		})], 1, 1), !0;
		case "foragerGuard": return K(e, r, "occupy", A(e, r, "hand"), (e) => [D("foragerAcquire", r, {
			card: e.uid,
			def: t.def
		})], 1, 1), !0;
		case "foragerAcquire": return e.kingdomDiscard.splice(e.kingdomDiscard.indexOf(t.def), 1), e.queue.unshift(D("acquireKingdom", r, {
			card: t.card,
			def: t.def
		})), !0;
		case "sacrificeRecover": return K(e, r, "returnHand", A(e, r, "discard"), (e) => [D("move", r, {
			card: e.uid,
			zone: "hand"
		})]), !0;
		case "witchTrial":
			for (let i of e.cards.filter((n) => He(e, r, n.owner) && n.zone === "council" && n.suit === t.suit)) R(e, i, "discard", n);
			for (let i of e.players.filter((t) => He(e, r, t.rid))) L(e, i.rid, "councilMarker", t.suit, -i.councilMarkers[t.suit], n);
			return K(e, r, "witchOwn", A(e, r, "council"), (e) => [D("move", r, {
				card: e.uid,
				zone: "deck"
			}), D("gain", r, {
				mode: "lore",
				n: 1
			})], 80), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/oldkingscrown/wild.ts
var ot = (e) => (Math.floor(e / 2) + 1) % 3 * 2 + (1 - e % 2);
function st(e, t, n, r, i, a, o = !0) {
	t.push({
		kind: "boon",
		rid: n,
		data: {
			from: i,
			to: a,
			...o ? {} : { n: r }
		},
		...o ? {
			for: [n],
			secret: { n: r }
		} : {},
		...t.length ? { with: !0 } : {}
	}), e.beat = E.move;
}
function ct(e) {
	for (let t = 0; t < 6; t += 1) (e.modules.towerBoons[t] === -1 || e.modules.towerBoons[t] === void 0) && (e.modules.towerBag.length || (e.modules.towerBag = N(e, e.modules.boonDiscard), e.modules.boonDiscard = []), e.modules.towerBoons[t] = e.modules.towerBag.shift() ?? -1);
}
function lt(e, t, n) {
	let r = O(e, t), i = [], a = D("actionStep", t, { mode: n }), o = (e, t, n, r = {}) => i.push(V(e, t, [...n, a], r));
	n === "spring" && !r.used.includes("boons") && r.boons.length && o("boons", "placeBoons", [D("boonAttach", t)]), n === "spring" && e.modules.airOwner === t && e.modules.airRegion === null && o("airSupporter", "placeAirship", [D("airPlace", t)]);
	for (let i of e.cards.filter((e) => e.owner === t && ["occupying", "supply"].includes(e.zone))) n !== ([
		175706,
		175707,
		175712
	].includes(i.def) ? "spring" : [
		175709,
		175713,
		175714
	].includes(i.def) ? "autumn" : "") || r.used.includes(`wild:${i.def}`) || o(`wild:${i.uid}`, "activate", [D("wildAction", t, {
		card: i.uid,
		def: i.def
	})], {
		card: i.uid,
		def: i.def
	});
	if (n === "autumn") for (let n of e.cards.filter((e) => e.def === 175009 && e.zone === "supply" && e.owner === t)) r.used.includes("midnightCourt") || o(`midnight:${n.uid}`, "govern", [D("flagUsed", t, { key: "midnightCourt" }), D("governChoose", t, { ids: j(e, t, n.region).map((e) => e.uid) })], { def: n.def });
	for (let i of n === "day" ? G(e, t) : j(e, t)) if (n !== "day" || e.dayNew === null || e.dayNew.includes(i.uid)) for (let e of i.boons) !r.used.includes(`boon:${i.uid}:${e}`) && (n === "day" && [
		0,
		15,
		17
	].includes(e) || n === "autumn" && [2, 14].includes(e)) && o(`boon:${i.uid}:${e}`, "activateBoon", [D("boonAction", t, {
		card: i.uid,
		n: e
	})], {
		card: i.uid,
		def: i.def,
		n: e
	});
	return i;
}
function ut(e, t, n) {
	let r = t.actor, i = r ? O(e, r) : void 0, a = e.modules;
	switch (t.kind) {
		case "moduleSetup": {
			e.config.nightMap && (a.locations = N(e, a.locations));
			let t = N(e, [
				0,
				1,
				2,
				3,
				4,
				5
			]);
			if (e.config.aeronauts && (a.air = t.shift(), a.airCards = N(e, x.filter((e) => e.kind === "aeronaut").map((e) => e.id)).slice(0, 3)), e.config.town && (a.town = t.shift()), e.config.tower && (a.tower = t.shift(), a.towerBag = N(e, Array.from({ length: 20 }, (e, t) => t)), ct(e)), e.config.creatures) for (let t of e.players.filter((e) => e.faction !== "simulacrum")) t.heralds.push(null), P(e, x.find((e) => e.kind === "creature" && e.faction === t.faction).id, t.rid, "supply");
			return !0;
		}
		case "locationVisit": {
			let n = t.location, i = D("locationReward", r, {
				location: n,
				mode: "printed",
				key: t.mode
			});
			if (a.tower === n) return e.queue.unshift(D("towerVisit", r, { location: n })), !0;
			let o = [V("location", "locationReward", [i], { location: n })];
			return a.air === n && !a.airOwner && o.push(V("aeronauts", "visitAeronauts", [D("airVisit", r)])), a.town === n && o.push(V("town", "visitTown", [D("townVisit", r)])), o.length === 1 ? e.queue.unshift(i) : B(e, r, "visit", o), !0;
		}
		case "airPlace": return B(e, r, "airPlace", [
			0,
			1,
			2
		].map((e) => V(String(e), "region", [D("airMove", r, { region: e })], { region: e }))), !0;
		case "airMove": {
			let i = a.airRegion === null ? `seat:${r}` : `region:${a.airRegion}`;
			return a.airRegion = t.region, F(n, "airship", r, {
				from: i,
				to: "airship"
			}), e.beat = E.move, !0;
		}
		case "airVisit": return e.queue.unshift(D("chooseResource", r), D("airAcquire", r)), !0;
		case "airAcquire":
			if (a.airCards.length) B(e, r, "aeronaut", a.airCards.map((e) => V(String(e), "card", [D("airCard", r, { def: e })], { def: e })));
			else {
				let t = `location:${a.air}`;
				a.airOwner = r, a.air = null, a.airRegion = null, F(n, "airship", r, {
					from: t,
					to: "airship"
				}), e.beat = E.move, B(e, r, "refreshTactic", i.tactics.filter((e) => e.exhausted).map((e) => V(String(e.def), "refreshTactic", [D("refreshTactic", r, { def: e.def })], { def: e.def })), { min: 0 });
			}
			return !0;
		case "airCard": return a.airCards.splice(a.airCards.indexOf(t.def), 1), R(e, P(e, t.def, r, "supply"), "hand", n), !0;
		case "towerVisit": {
			let t = a.towerBoons[0];
			return t >= 0 && (i.boons.push(t), a.towerBoons[0] = -1, st(e, n, r, t, "tower", `seat:${r}`)), B(e, r, "towerAscend", [V("ascend", "exploreLabyrinth", [D("towerLabyrinth", r)]), V("leave", "leaveTower", [D("towerFinish", r)])]), !0;
		}
		case "towerLabyrinth": return B(e, r, "towerLabyrinth", [1, 2].filter((e) => a.towerBoons[e] >= 0).map((e) => V(String(e), "boon", [D("towerLabyrinthTake", r, { n: e })], { n: a.towerBoons[e] })), { after: [D("towerPinnacleChoice", r)] }), !0;
		case "towerLabyrinthTake": {
			let o = t.n, s = o === 1 ? 2 : 1;
			return i.boons.push(a.towerBoons[o]), a.towerBoons[o] = -1, st(e, n, r, i.boons.at(-1), "tower", `seat:${r}`), a.towerBoons[s] >= 0 && B(e, r, "giveBoon", e.players.filter((e) => e.rid !== r && e.faction !== "simulacrum").map((e) => V(e.rid, "player", [D("towerGiveBoon", r, {
				target: e.rid,
				n: s
			})], { player: e.rid }))), !0;
		}
		case "towerGiveBoon": return st(e, n, t.target, a.towerBoons[t.n], "tower", `seat:${t.target}`), O(e, t.target).boons.push(a.towerBoons[t.n]), a.towerBoons[t.n] = -1, !0;
		case "towerPinnacleChoice": {
			let t = [V("leave", "leaveTower", [D("towerFinish", r)])];
			return i.lore && t.unshift(V("ascend", "explorePinnacle", [D("towerPinnacle", r)])), B(e, r, "towerPinnacleChoice", t), !0;
		}
		case "towerPinnacle":
			--i.lore;
			for (let t of [
				3,
				4,
				5
			]) a.towerBoons[t] >= 0 && (st(e, n, r, a.towerBoons[t], "tower", `seat:${r}`), i.boons.push(a.towerBoons[t]), a.towerBoons[t] = -1);
			return B(e, r, "discardBoons", i.boons.map((e) => V(String(e), "boon", [D("boonDiscard", r, { n: e })], { n: e })), {
				min: Math.min(2, i.boons.length),
				max: Math.min(2, i.boons.length),
				after: [D("towerFinish", r)]
			}), !0;
		case "boonDiscard": return i.boons.splice(i.boons.indexOf(t.n), 1), a.boonDiscard.push(t.n), st(e, n, r, t.n, `seat:${r}`, "tower", !1), !0;
		case "towerFinish": return ct(e), B(e, r, "towerMove", Array.from({ length: 6 }, (e, t) => t).filter((e) => Math.floor(e / 2) !== Math.floor(a.tower / 2)).map((e) => V(String(e), "location", [D("towerMove", r, { location: e })], { location: e }))), !0;
		case "towerMove": {
			let i = `location:${a.tower}`;
			return a.tower = t.location, F(n, "tower", r, {
				from: i,
				to: "tower"
			}), e.beat = E.move, !0;
		}
		case "townVisit": return U(e, r, "influence", a.townInfluence, n), a.townInfluence = 0, a.travelled.push("townVisited"), B(e, r, "townAcquire", Fe(e, r).map(({ def: e, n: t, key: n }) => V(`${n ?? "road"}:${t}`, "acquire", [D("townAcquire", r, {
			def: e,
			n: t,
			key: n
		})], { def: e }))), !0;
		case "townAcquire":
			if ((t.key === "eye" ? e.kingdomDeck : e.road).splice(t.n, 1), Pe(e, n), [
				175003,
				175006,
				175009,
				175010,
				175033,
				175042,
				175048,
				175701,
				175702,
				175704,
				175705,
				175713
			].includes(t.def)) e.queue.unshift(D("acquireKingdom", r, { def: t.def }));
			else {
				let n = e.cards.filter((e) => e.zone === "occupying" && e.location !== null && e.location >= 100), i = P(e, t.def, r, "supply");
				n.length >= 2 ? B(e, r, "townReplace", n.map((e) => V(e.uid, "replaceKingdom", [D("discardKingdom", e.owner, { card: e.uid }), D("occupy", r, {
					card: i.uid,
					location: e.location
				})], { def: e.def }))) : e.queue.unshift(D("occupy", r, {
					card: i.uid,
					location: n.some((e) => e.location === 100) ? 101 : 100
				}));
			}
			return !0;
		case "moduleBeforeDay":
			for (let t of G(e)) if (t.boons.includes(1) && !O(e, t.owner).used.includes(`boonReveal:${t.uid}:1`)) {
				O(e, t.owner).used.push(`boonReveal:${t.uid}:1`);
				for (let t of e.players) I(e, t.rid, e.region, -2, t.supporters[e.region], n);
			}
			return !0;
		case "boonAttach": {
			if (i.used.includes("boons") || i.used.push("boons"), !i.boons.length) return !0;
			let t = e.cards.filter((e) => e.owner === r && e.zone === "active" && !e.faceUp && e.boons.length < 2);
			return B(e, r, "placeBoons", i.boons.flatMap((e) => t.map((t) => V(`${e}:${t.uid}`, "boonCard", [D("boonPlace", r, {
				card: t.uid,
				n: e
			}), D("boonAttach", r)], {
				card: t.uid,
				def: t.def,
				n: e
			}))), { min: 0 }), !0;
		}
		case "boonPlace": return i.boons.splice(i.boons.indexOf(t.n), 1), k(e, t.card).boons.push(t.n), st(e, n, r, t.n, `seat:${r}`, `region:${k(e, t.card).region}`), !0;
		case "boonAction": {
			i.used.push(`boon:${t.card}:${t.n}`);
			let a = k(e, t.card);
			if ((t.n === 0 || t.n === 17) && K(e, r, "boonSwap", A(e, r, t.n === 0 ? "hand" : "lost"), (e) => [D("swapCards", r, {
				card: a.uid,
				target: e.uid
			})], 1, 1), t.n === 2 && (a.influence += 1, F(n, "cardInfluence", r, {
				uid: a.uid,
				n: 1
			})), t.n === 14 && B(e, r, "boonGovernJourney", [V("govern", "govern", [D("governCouncil", r, { card: a.uid })]), V("journey", "journey", [D("journey", r, { card: a.uid })])]), t.n === 15) for (let t of G(e).filter((e) => (S[e.def].strength ?? 0) <= 3)) R(e, t, "discard", n);
			return !0;
		}
		case "boonWin":
			for (let t of G(e, r)) for (let i of t.boons) i === 3 && e.queue.unshift(D("handSize", r, { n: 1 })), i === 4 && e.queue.unshift(D("rewardLocationOnly", r)), i === 6 && (U(e, r, "influence", 2, n), U(e, r, "lore", 2, n), e.queue.unshift(D("move", r, {
				card: t.uid,
				zone: "burned"
			}))), i === 10 && e.queue.unshift(D("secrets", r, { n: W(e, r, 1) }), D("oaths", r, { n: W(e, r, 2) + Number(e.players.every((t) => t.rid === r || W(e, t.rid, 2) < W(e, r, 2))) })), i === 11 && B(e, r, "boonTower", [V("yes", "visitTower", [D("towerVisit", r)])], { min: 0 }), i === 19 && (U(e, r, "influence", 1, n), U(e, r, "lore", 1, n));
			return !0;
		case "rewardLocationOnly": return B(e, r, "location", [e.region * 2, e.region * 2 + 1].map((e) => V(String(e), "location", [D("locationReward", r, { location: e })], { location: e }))), !0;
		case "boonNightAfter": return !0;
		case "boonClashEnd":
			for (let r of t.ids ? t.ids.map((t) => k(e, t)).filter((e) => e.zone === "active") : G(e)) (r.boons.includes(9) || r.boons.includes(13)) && R(e, r, "burned", n);
			return !0;
		case "afterRegion": return !0;
		case "wildAction":
			if (i.used.push(`wild:${t.def}`), t.def === 175706 && (i.flags.push("abundance"), Ee(e, k(e, t.card), n)), t.def === 175707 && e.queue.unshift(D("rearrangeCouncils", r)), t.def === 175709 && K(e, r, "laboratory", e.cards.filter((e) => e.zone === "lost"), (e) => [D("takeAlly", r, { card: e.uid })], 1, 1), t.def === 175712 && i.flags.push("arrows"), t.def === 175713) {
				let n = k(e, t.card).region;
				B(e, r, "location", [n * 2, n * 2 + 1].map((e) => V(String(e), "location", [D("locationReward", r, { location: e })], { location: e })));
			}
			return t.def === 175714 && B(e, r, "auctionTactic", e.players.filter((e) => e.rid !== r).flatMap((e) => e.tactics.filter((e) => e.exhausted).map((t) => V(`${e.rid}:${t.def}`, "tactic", [D("auctionTactic", r, {
				target: e.rid,
				def: t.def
			})], {
				player: e.rid,
				def: t.def
			})))), !0;
		case "takeAlly": return R(e, k(e, t.card), "hand", n, { owner: r }), !0;
		case "auctionTactic": {
			if (!i.influence || !i.lore) return !0;
			let r = O(e, t.target), a = r.tactics.find((e) => e.def === t.def);
			return --i.influence, --i.lore, U(e, r.rid, "influence", 1, n), U(e, r.rid, "lore", 1, n), r.tactics = r.tactics.filter((e) => e !== a), i.tactics.push(a), a.exhausted = !1, a.markers = S[a.def].markers ?? 0, !0;
		}
		case "rearrangeCouncils": {
			let t = e.cards.filter((e) => e.zone === "council").map((e) => ze(e, [D("rearrangeCard", r, { card: e.uid }), D("rearrangeCouncils", r)]));
			for (let n of e.players) n.councilMarkers.forEach((e, i) => {
				e && t.push(V(`${n.rid}:${i}`, "councilMarker", [D("rearrangeMarker", r, {
					target: n.rid,
					suit: i
				}), D("rearrangeCouncils", r)], {
					player: n.rid,
					suit: i,
					n: e
				}));
			});
			return B(e, r, "rearrangeCouncils", t, { min: 0 }), !0;
		}
		case "rearrangeCard": return B(e, r, "council", [
			0,
			1,
			2
		].filter((n) => n !== k(e, t.card).suit).map((n) => V(String(n), "council", [D("move", k(e, t.card).owner, {
			card: t.card,
			zone: "council",
			suit: n
		})], { suit: n }))), !0;
		case "rearrangeMarker": return B(e, r, "council", [
			0,
			1,
			2
		].filter((e) => e !== t.suit).map((e) => V(String(e), "council", [D("markerTransfer", t.target, {
			suit: t.suit,
			n: e
		})], { suit: e }))), !0;
		case "markerTransfer": return L(e, r, "councilMarker", t.suit, -1, n), L(e, r, "councilMarker", t.n, 1, n), !0;
		case "wildAcquisition": {
			let i = k(e, t.card);
			return t.def === 175701 && (e.queue.unshift(D("handSize", r, { n: 2 })), Ee(e, i, n)), t.def === 175704 && (U(e, r, "influence", 7 - e.year, n), Ee(e, i, n)), t.def === 175702 && B(e, r, "location", Array.from({ length: 6 }, (e, t) => V(String(t), "location", [D("placeMapKingdom", r, {
				card: i.uid,
				location: t
			})], { location: t }))), t.def === 175713 && B(e, r, "region", [
				0,
				1,
				2
			].map((e) => V(String(e), "region", [D("placeMapKingdom", r, {
				card: i.uid,
				region: e
			})], { region: e }))), !0;
		}
		case "wildWinter":
			for (let t of e.cards.filter((e) => e.owner !== "$simulacrum" && ["occupying", "supply"].includes(e.zone))) {
				if (t.def === 175703) {
					let r = A(e, t.owner, "lost");
					r.forEach((t) => R(e, t, "burned", n)), U(e, t.owner, "lore", 2, n), r.length || Ee(e, t, n);
				}
				if (t.def === 175710) {
					let n = O(e, t.owner);
					n.supporterBurned += n.supporters.reduce((e, t) => e + t, 0), n.supporters = [
						0,
						0,
						0
					];
				}
				t.def === 175713 && Ee(e, t, n);
			}
			return a.town !== null && (a.townInfluence += a.travelled.includes("townVisited") ? 1 : 2, a.locationInfluence[a.town] += 1, a.town = ot(a.town)), a.air !== null && !a.airOwner && (a.air = ot(a.air)), a.airOwner && (a.airRegion = null), !0;
		case "moduleCleanup":
			a.travelled = [];
			for (let t of e.cards.filter((e) => S[e.def].kind === "creature" && ![
				"hand",
				"supply",
				"burned"
			].includes(e.zone))) R(e, t, "supply", n);
			return !0;
		case "flagUsed": return i.used.push(t.key), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/oldkingscrown/scheme-data.ts
var dt = [
	{
		id: 177912,
		regions: [
			0,
			1,
			2
		],
		supporters: "cycle",
		backRegion: 0
	},
	{
		id: 177913,
		regions: [
			0,
			1,
			2
		],
		supporters: "first",
		backRegion: 0
	},
	{
		id: 177914,
		regions: [
			0,
			2,
			1
		],
		supporters: "cycle",
		backRegion: 0
	},
	{
		id: 177915,
		regions: [
			0,
			2,
			1
		],
		supporters: "first",
		backRegion: 2
	},
	{
		id: 177916,
		regions: [
			1,
			0,
			2
		],
		supporters: "cycle",
		backRegion: 1
	},
	{
		id: 177917,
		regions: [
			1,
			0,
			2
		],
		supporters: "first",
		backRegion: 0
	},
	{
		id: 177918,
		regions: [
			1,
			2,
			0
		],
		supporters: "cycle",
		backRegion: 1
	},
	{
		id: 177919,
		regions: [
			1,
			2,
			0
		],
		supporters: "first",
		backRegion: 1
	},
	{
		id: 177920,
		regions: [
			2,
			0,
			1
		],
		supporters: "cycle",
		backRegion: 2
	},
	{
		id: 177921,
		regions: [
			2,
			0,
			1
		],
		supporters: "first",
		backRegion: 2
	},
	{
		id: 177922,
		regions: [
			2,
			1,
			0
		],
		supporters: "cycle",
		backRegion: 2
	},
	{
		id: 177923,
		regions: [
			2,
			1,
			0
		],
		supporters: "first",
		backRegion: 1
	}
], q = (e) => re[e.sim.ambition ?? e.sim.ambitionDeck[0]], ft = (e) => dt[e.sim.scheme ?? e.sim.schemeDeck[0]], pt = (e) => e.order.filter((t) => e.humans.includes(t)).at(-1), mt = (e) => ({
	bronze: 1,
	silver: 2,
	gold: 3
})[S[e.def].tier ?? "bronze"];
function ht(e) {
	let t = e.sim.threatDeck.shift();
	t !== void 0 && (e.sim.threats.push(t), H(e, "revealedThreat", T, void 0, t), t === 22 && ht(e));
}
function gt(e) {
	return e.sim.bidStack.length || (e.sim.bidStack = N(e, e.sim.bidDiscard), e.sim.bidDiscard = []), e.sim.bidStack.shift() ?? 0;
}
function _t(e) {
	e.sim.ambition === null && (e.sim.ambition = C(e, 13, "b") ? e.sim.ambitionDeck.pop() : e.sim.ambitionDeck.shift(), C(e, 14, "a") && vt(e));
}
function vt(e) {
	e.sim.scheme === null && (e.sim.scheme = C(e, 14, "b") ? e.sim.schemeDeck.pop() : e.sim.schemeDeck.shift());
}
function yt(e, t, n, r) {
	let i = A(e, T, "occupying").filter((e) => !e.parent), a = q(e).direction === "left" ? 0 : 1, o = i.length === 1 ? 1 - i[0].location : a, s = i.find((e) => e.location === o);
	s && (e.sim.bidDiscard.push(s.guardStrength), Ee(e, s, n));
	let c = r ?? P(e, t, "$simulacrum", "supply");
	if (r) {
		let t = c.owner;
		for (let t of e.cards.filter((e) => e.parent === c.uid)) R(e, t, "hand", n);
		c.def === 175016 && e.queue.unshift(D("handSize", t, { n: -1 }));
	}
	R(e, c, "occupying", n, {
		location: o,
		owner: T
	}), c.guardStrength = O(e, "$simulacrum").bidToken ?? 0;
}
function bt(e, t, n) {
	if (!e.sim.enabled || !t.kind.startsWith("sim")) return !1;
	let r = O(e, T), i = t.actor;
	switch (t.kind) {
		case "simSetup": {
			e.sim.ambitionDeck = N(e, re.map((e, t) => t)), e.sim.schemeDeck = N(e, dt.map((e, t) => t)), e.sim.threatDeck = N(e, e.config.threats.length ? e.config.threats : N(e, Array.from({ length: 24 }, (e, t) => t + 1)).slice(0, 6)), e.sim.bidStack = N(e, [
				2,
				5,
				6,
				7,
				8,
				9,
				10,
				12
			]), e.sim.orderToken = gt(e);
			let t = x.filter((e) => e.kind === "simulacrum" && e.advanced).flatMap((e) => Array.from({ length: e.count ?? 1 }, () => e)), i = e.config.simAdvanced.length ? e.config.simAdvanced.map((e) => t[e]) : N(e, t).slice(0, C(e, 29, "a") ? 1 : C(e, 29, "b") ? 5 : 3);
			N(e, i).forEach((t, n) => {
				let r = P(e, t.id, T, "site");
				r.faceUp = !1, r.position = n;
			});
			let a = N(e, x.filter((e) => e.kind === "simulacrum" && !e.advanced));
			for (; a[0].tier !== "bronze";) a.push(a.shift());
			a.forEach((t, n) => {
				let r = P(e, t.id, T, "deck");
				r.position = n;
			}), r.supporterSupply = C(e, 1, "a") ? 1 : C(e, 1, "b") ? 5 : 3, r.supporterLost = 10 - r.supporterSupply;
			for (let t of e.humans) (C(e, 3, "a") || C(e, 3, "b")) && (O(e, t).handSize = C(e, 3, "a") ? 7 : 5), C(e, 4, "a") && (O(e, t).influence += ie(e, 4)), C(e, 16, "b") && N(e, O(e, t).tactics).slice(0, ie(e, 16)).forEach((e) => {
				e.exhausted = !0;
			}), O(e, t).handSize > 6 && St(e, t, n), O(e, t).handSize < 6 && e.queue.unshift(D("discardHand", t, { mode: "limit" }));
			if (C(e, 4, "b") && (r.influence += 2 * ie(e, 4)), C(e, 10, "a")) {
				let t = A(e, T, "deck")[0];
				t.zone = "site", t.position = -++e.serial;
			}
			if (C(e, 10, "b")) {
				let t = A(e, T, "site")[0];
				t.zone = "deck", t.position = -++e.serial;
			}
			(C(e, 12, "a") || C(e, 12, "b")) && (e.sim.towers = N(e, [
				0,
				1,
				2,
				3,
				4,
				5
			]).slice(0, 3));
			for (let t of e.config.forge) {
				let n = ue[t.id - 1][t.side === "a" ? 0 : 1];
				e.sim.heat += typeof n == "number" ? n : n === "-X" ? -t.value : n === "2X" ? 2 * t.value : t.value;
			}
			return e.sim.heat += Math.min(4, e.sim.threatDeck.length - 6), e.config.simAdvanced.length && !e.config.forge.some((e) => e.id === 29) && (e.sim.heat += i.length < 3 ? -2 * (3 - i.length) : Math.min(2, i.length - 3)), ht(e), C(e, 8, "b") && ht(e), e.config.advancedSetup && (r.bidToken = gt(e), yt(e, e.kingdomDeck.pop(), n)), !0;
		}
		case "simDrawYear": return ht(e), C(e, 8, "b") && ht(e), e.favour.owner === "$simulacrum" && ht(e), !0;
		case "simStartYear": return r.bidToken = gt(e), C(e, 13, "a") && _t(e), !0;
		case "simResolveBid": {
			_t(e);
			let t = q(e), i = r.bid ?? 0;
			e.queue.unshift(D("simKingdomBonus", T));
			let a = C(e, 25, "a") || !t.steal && !C(e, 25, "b") ? [] : e.cards.filter((t) => t.owner !== "$simulacrum" && t.zone === "occupying" && !t.parent && t.location !== null && t.location < 100 && i > (e.cards.find((e) => e.parent === t.uid) ? S[e.cards.find((e) => e.parent === t.uid).def].strength ?? 0 : 0) + (M(e, t.owner, 175004) ? 5 : 0));
			if (a.sort((n, r) => t.suits.indexOf(S[n.def].suit) - t.suits.indexOf(S[r.def].suit) || e.order.indexOf(n.owner) - e.order.indexOf(r.owner) || (t.direction === "left" ? n.location - r.location : r.location - n.location)), a.length) yt(e, a[0].def, n, a[0]);
			else {
				let i = e.road.map((e, t) => ({
					def: e,
					i: t
				})).sort((e, n) => t.suits.indexOf(S[e.def].suit) - t.suits.indexOf(S[n.def].suit) || (t.direction === "left" ? e.i - n.i : n.i - e.i));
				i.length ? (e.road.splice(i[0].i, 1), e.roadTaken = !0, yt(e, i[0].def, n)) : e.sim.bidDiscard.push(r.bidToken);
			}
			return !0;
		}
		case "simHerald": {
			let t = q(e).regions[0] * 2 + Number(q(e).direction === "right");
			return C(e, 21, "a") ? B(e, pt(e), "simHerald", Array.from({ length: 6 }, (e, t) => V(String(t), "location", [D("herald", T, { location: t })], { location: t }))) : he(e, T, 0, t, n), !0;
		}
		case "simPlaceCards": return r.used.includes("simPlaced") ? !0 : (r.used.push("simPlaced"), Ce(e, 3).sort((e, t) => mt(t) - mt(e)).forEach((t, r) => R(e, t, "active", n, {
			region: q(e).regions[r],
			faceUp: !1
		})), !0);
		case "simKingdomBonus": {
			let t = C(e, 7, "a") ? 0 : C(e, 7, "b") ? 2 : 1;
			for (let i = 0; i < t; i += 1) for (let t of A(e, T, "occupying").filter((e) => !e.parent)) S[t.def].suit === "opulence" && U(e, T, "influence", 1, n), S[t.def].suit === "mystery" && (L(e, T, "councilMarker", b.indexOf(q(e).suits[0]), 1, n), U(e, T, "lore", 1, n)), S[t.def].suit === "force" && r.supporterLost && I(e, T, -2, -1, 1, n);
			return !0;
		}
		case "simAction": {
			if (t.mode === "spring") {
				if (r.used.includes("simSpring")) return !0;
				r.used.push("simSpring"), vt(e);
				let t = ft(e), i = Math.max(1, Math.min(3, (de[e.sim.threats[0] - 1] ?? 1) + (C(e, 2, "a") ? -1 : +!!C(e, 2, "b"))));
				for (let n of t.regions.slice(0, i)) xt(e, n);
				let a = r.supporterSupply;
				for (let r = 0; r < a; r += 1) {
					let i = t.regions[t.supporters === "first" ? 0 : r % 3];
					I(e, T, -1, i, 1, n);
				}
				return C(e, 21, "b") && he(e, T, 0, t.regions[0] * 2 + Number(q(e).direction === "right"), n), !0;
			}
			if (t.mode === "autumn" && !r.used.includes("simAutumn")) return r.used.push("simAutumn"), e.queue.unshift(D("simThreatAutumn", T), D("simAction", T, { mode: "autumn" })), !0;
			let i = (t.mode === "day" ? G(e, T).filter((t) => e.dayNew === null || e.dayNew.includes(t.uid)) : j(e, T)).filter((t) => ve(e, t)).flatMap((n) => {
				let i = `simAction:${t.mode}:${e.region}:${e.clash}:${n.uid}`;
				return r.used.includes(i) ? [] : t.mode === "day" && [177704, 177710].includes(n.def) ? [{
					c: n,
					key: i,
					kind: "simAmbush"
				}] : t.mode === "autumn" && [177703, 177707].includes(n.def) && j(e, "$simulacrum", n.region).length === 1 ? [{
					c: n,
					key: i,
					kind: "simArmature"
				}] : t.mode === "autumn" && z(e, n).commands.includes("rallySelf") && !(w(e, 3, n.region) && n.influence) ? [{
					c: n,
					key: i,
					kind: "simRally"
				}] : [];
			});
			t.mode === "day" && w(e, 6) && G(e, "$simulacrum").length && G(e, "$simulacrum").every((e) => S[e.def].tier !== "gold") && !r.used.includes(`pall:${e.region}:${e.clash}`) && i.push({
				c: G(e, T)[0],
				key: `pall:${e.region}:${e.clash}`,
				kind: "simPall"
			});
			let a = t.mode === "day" ? [[9, "simFrontlines"], [20, "simPickedOff"]] : t.mode === "autumn" ? [[11, "simWhispers"], [15, "simPitchBlack"]] : [];
			for (let [n, o] of a) {
				let a = `threatAction:${n}:${t.mode === "day" ? `${e.region}:${e.clash}` : "autumn"}`;
				(t.mode === "day" ? w(e, n) : e.sim.threats.includes(n)) && !r.used.includes(a) && i.push({
					c: {
						uid: "",
						def: 0
					},
					key: a,
					kind: o
				});
			}
			return i.length ? B(e, pt(e), "simActionOrder", i.map(({ c: e, key: n, kind: r }) => V(n, r, [
				D("simUse", T, { key: n }),
				D(r, T, { card: e.uid }),
				D("simAction", T, { mode: t.mode })
			], { ...e.uid ? {
				card: e.uid,
				def: e.def
			} : {} }))) : t.mode === "autumn" && e.queue.unshift(D("simGovern", T)), !0;
		}
		case "simGovern": return L(e, T, "councilMarker", b.indexOf(q(e).suits[0]), C(e, 20, "a") ? 0 : C(e, 20, "b") ? 2 : 1, n), e.queue.unshift(D("simCouncils", T), D("simJourney", T)), !0;
		case "simJourney": return C(e, 26, "a") || U(e, T, "lore", C(e, 26, "b") ? 2 : 1, n), !0;
		case "simUse": return r.used.push(t.key), !0;
		case "simAmbush": {
			if (Ve(e, "$simulacrum", e.region)) return !0;
			let t = Ce(e, 2), r = [...t].sort((e, t) => mt(t) - mt(e))[0];
			for (let i of t) R(e, i, i === r ? "active" : "discard", n, {
				region: i === r ? e.region : null,
				faceUp: i !== r
			});
			return !0;
		}
		case "simPall": {
			let t = Ce(e, 1)[0];
			return t && !Ve(e, "$simulacrum", e.region) && (R(e, t, "active", n, { region: e.region }), e.dayNew?.push(t.uid)), !0;
		}
		case "simRally": return R(e, k(e, t.card), "deck", n), !0;
		case "simArmature": {
			let r = k(e, t.card);
			return R(e, r, "active", n, { region: q(e).regions[0] }), r.influence += 1, !0;
		}
		case "simCouncils": {
			let t = r.councilMarkers[1];
			for (let i = 0; i < t; i += 1) {
				let t = r.markers.findIndex((e) => e > 0 && e < 4);
				L(e, T, "marker", t >= 0 ? t : r.heralds[0] ?? q(e).regions[0] * 2, 1, n);
			}
			r.markers.forEach((t, r) => {
				t >= 4 && (L(e, T, "marker", r, -4, n), e.queue.unshift(D("simLocation", T, { location: r })));
			});
			let i = r.councilMarkers[2], a = i + Number(i > 0 && e.humans.every((t) => W(e, t, 2) < i));
			for (let t = 0; t < a; t += 1) if (r.supporterLost) I(e, T, -2, -1, 1, n);
			else {
				let t = r.supporters.findIndex((e) => e > 0);
				t >= 0 && I(e, T, t, -1, 1, n);
			}
			return !0;
		}
		case "simBeforeDay":
			for (let t of G(e, T).filter((t) => t.def === 178100 && ve(e, t))) {
				let n = `monolith:${e.region}:${e.clash}:${t.uid}`;
				r.used.includes(n) || (r.used.push(n), ht(e), e.sim.fog[e.region].length || xt(e, e.region));
			}
			return e.queue.unshift(D("simThreatDay", T)), !0;
		case "simTie": {
			let t = Ce(e, 1)[0];
			return t && R(e, t, "active", n, {
				region: e.region,
				faceUp: !1
			}), !0;
		}
		case "simClashOrder": return e.queue.unshift(D("setClashOrder", T, { nums: [...ft(e).regions] })), !0;
		case "simReward": {
			let t = e.region * 2 + Number(q(e).direction === "right");
			if (!C(e, 23, "a") && r.heralds.includes(t)) {
				let i = (C(e, 23, "b") ? 2 : 1) * (w(e, 12) ? 2 : 1);
				U(e, T, "influence", i * (1 + r.councilMarkers[0]), n), r.councilMarkers[0] && L(e, T, "councilMarker", 0, -1, n);
				for (let r of e.humans) {
					let a = O(e, r), o = Math.min(a.influence, a.heralds.filter((e) => e === t).length * i);
					a.influence -= o, U(e, T, "influence", o, n);
				}
			}
			return e.queue.unshift(D("simLocation", T, { location: t })), !0;
		}
		case "simLocation": {
			let r = e.modules.locations[t.location];
			if (C(e, 12, "a") && e.sim.towers.includes(t.location)) return e.sim.towers.splice(e.sim.towers.indexOf(t.location), 1), !0;
			if (U(e, T, "influence", r === 3 ? 2 : 1, n), r === 0) {
				let t = q(e).suits.map((e) => b.indexOf(e)), r = (t) => e.humans.reduce((n, r) => n + W(e, r, t), 0), i = [...t].sort((e, t) => r(t) - r(e))[0];
				e.cards.filter((e) => e.zone === "council" && e.suit === i).forEach((t) => R(e, t, "discard", n)), e.players.forEach((t) => L(e, t.rid, "councilMarker", i, -t.councilMarkers[i], n)), L(e, T, "councilMarker", i, 2, n);
			}
			if (r === 1 && U(e, T, "lore", 2, n), r === 2 && (C(e, 8, "a") || e.favour.owner === "$simulacrum" ? U(e, T, "influence", 1, n) : e.favour = {
				owner: T,
				uses: 3
			}), r === 4) for (let t of e.humans) e.queue.unshift(D("simShrineDiscard", t, { n: 2 }));
			return r === 5 && (A(e, T, "deck").slice(0, 3).forEach((t) => R(e, t, "discard", n)), N(e, A(e, T, "discard")).filter((e) => S[e.def].tier === "gold").forEach((t) => R(e, t, "deck", n))), !0;
		}
		case "simShrineDiscard": {
			if (!t.n) return !0;
			let r = A(e, i, "deck")[0], a = A(e, i, "hand").map((e) => V(e.uid, "discardHand", [D("move", i, {
				card: e.uid,
				zone: "discard"
			}), D("simShrineDiscard", i, { n: t.n - 1 })], {
				card: e.uid,
				def: e.def
			}));
			return r && a.push(V("deck", "discardDeckTop", [D("move", i, {
				card: r.uid,
				zone: "discard"
			}), D("simShrineDiscard", i, { n: t.n - 1 })])), a.length ? B(e, i, "simShrineDiscard", a) : (xe(e, i, -1, n), e.queue.unshift(D("draw", i, { mode: "size" }))), !0;
		}
		case "simSpend": {
			let t = C(e, 6, "a") ? 4 : C(e, 6, "b") ? 2 : 3;
			return r.lore >= t && A(e, "$simulacrum", "site").length && (r.lore -= t, R(e, A(e, T, "site")[0], "deck", n), e.queue.unshift(D("simSpend", T))), !0;
		}
		case "simCleanup": {
			if (!A(e, "$simulacrum", "site").length) {
				let t = C(e, 24, "a") ? 3 : C(e, 24, "b") ? 1 : 2, i = Math.floor(r.lore / t);
				r.lore -= i * t, U(e, T, "influence", i, n);
			}
			let t = C(e, 1, "a") ? 1 : C(e, 1, "b") ? 5 : 3;
			r.supporters.forEach((r, i) => {
				let a = Math.min(t, r);
				I(e, T, i, -1, a, n), I(e, T, i, -2, r - a, n), t -= a;
			});
			let i = [...e.sim.threats, ...e.sim.fog.flatMap((e) => e.filter((e) => e !== null))];
			return e.sim.threatDeck.push(...N(e, i)), e.sim.threats = [], e.sim.fog = [
				[],
				[],
				[]
			], e.sim.ambition !== null && (C(e, 13, "b") ? e.sim.ambitionDeck.unshift(e.sim.ambition) : e.sim.ambitionDeck.push(e.sim.ambition)), e.sim.scheme !== null && (C(e, 14, "b") ? e.sim.schemeDeck.unshift(e.sim.scheme) : e.sim.schemeDeck.push(e.sim.scheme)), e.sim.ambition = null, e.sim.scheme = null, !0;
		}
		default: return !1;
	}
}
function xt(e, t) {
	let n = e.sim.threatDeck.shift();
	n !== void 0 && (e.sim.fog[t].length ? e.sim.threatDeck.push(n) : e.sim.fog[t].push(n));
}
function St(e, t, n) {
	let r = A(e, t, "deck")[0];
	r && R(e, r, "hand", n);
}
//#endregion
//#region src/games/oldkingscrown/threats.ts
function Ct(e, t, n) {
	if (!e.sim.enabled) return !1;
	let r = t.actor;
	switch (t.kind) {
		case "simThreatDay": return !0;
		case "simThreatAutumn":
			if (e.sim.threats.includes(3)) for (let t = 0; t < 3; t += 1) {
				if (!w(e, 3, t)) continue;
				let n = j(e, T, t), r = Math.max(...n.map((t) => z(e, t).strength)), i = n.filter((t) => z(e, t).strength === r);
				i.length && B(e, pt(e), "simThreatInfluence", i.map((e) => V(e.uid, "cardInfluence", [D("cardInfluence", T, {
					card: e.uid,
					n: 1
				})], {
					card: e.uid,
					def: e.def
				})));
			}
			return e.sim.threats.includes(14) && [
				0,
				1,
				2
			].some((t) => w(e, 14, t) && j(e, "$simulacrum", t).length) && U(e, T, "lore", 3, n), !0;
		case "simFrontlines": return e.queue.unshift(...e.humans.map((t) => D("simFrontlinesDiscard", t, { n: G(e, T).length }))), !0;
		case "simFrontlinesDiscard": {
			if (!t.n) return !0;
			let n = A(e, r, "hand");
			return n.length ? K(e, r, "discardHand", n, (e) => [D("move", r, {
				card: e.uid,
				zone: "discard"
			}), D("simFrontlinesDiscard", r, { n: t.n - 1 })], 1, 1) : K(e, r, "discardActive", G(e, r), (e) => [D("move", r, {
				card: e.uid,
				zone: "discard"
			}), D("simFrontlinesDiscard", r, { n: t.n - 1 })], 1, 1), !0;
		}
		case "simPickedOff": return G(e).filter((t) => t.owner !== "$simulacrum" && z(e, t).strength <= 4).forEach((t) => R(e, t, "lost", n)), !0;
		case "simWhispers":
		case "simPitchBlack": return e.queue.unshift(...e.order.filter((t) => e.humans.includes(t)).flatMap((n) => [
			0,
			1,
			2
		].filter((r) => w(e, t.kind === "simWhispers" ? 11 : 15, r) && (t.kind === "simWhispers" || j(e, n, r).length)).map((e) => D("simAutumnLoss", n, {
			region: e,
			mode: t.kind
		})))), !0;
		case "simAutumnLoss": {
			let i = j(e, r, t.region).map((e) => V(e.uid, "moveLost", [D("move", r, {
				card: e.uid,
				zone: "lost"
			})], {
				card: e.uid,
				def: e.def
			}));
			if (t.mode === "simWhispers") for (let t of A(e, r, "council")) i.push(V(t.uid, "discardCouncil", [D("move", r, {
				card: t.uid,
				zone: "discard"
			})], {
				card: t.uid,
				def: t.def
			}));
			return !i.length && t.mode === "simWhispers" ? U(e, T, "influence", 2, n) : B(e, r, "simAutumnLoss", i), !0;
		}
		case "simNightAfter": {
			if (!w(e, 23)) return !0;
			let t = G(e), r = Math.max(0, ...t.filter((e) => e.owner !== T).map((t) => z(e, t).strength)), i = t.filter((t) => t.owner === "$simulacrum" && z(e, t).strength > r).length;
			for (let t of e.order.filter((t) => e.humans.includes(t))) {
				let r = O(e, t), a = Math.min(r.influence, i);
				r.influence -= a, U(e, T, "influence", a, n);
			}
			return !0;
		}
		case "simClashResult": {
			let t = r === T, i = e.humans.includes(r);
			if (w(e, 4)) {
				let r = b.indexOf(q(e).suits[0]);
				t ? U(e, T, "influence", O(e, T).councilMarkers[r], n) : i && L(e, T, "councilMarker", r, 1, n);
			}
			if (t) w(e, 8) && U(e, T, "influence", 1, n), w(e, 17) && (U(e, T, "influence", 3, n), U(e, T, "lore", 3, n)), w(e, 24) && U(e, T, "influence", 1, n);
			else if (i && w(e, 13)) for (let t of e.humans) {
				let r = N(e, A(e, t, "site"))[0];
				r && R(e, r, "burned", n), A(e, t, "site").length || U(e, t, "lore", -O(e, t).lore, n);
			}
			return !0;
		}
		case "forgeElimination":
			if (C(e, 28, "a")) for (let t of e.humans) {
				let n = O(e, t), r = [V("influence", "influence", [D("gain", t, { n: 1 })]), V("lore", "lore", [D("gain", t, {
					n: 1,
					mode: "lore"
				})])];
				(n.supporterLost || n.supporters.some((e) => e > 0)) && r.push(V("supporter", "recallSupporter", [D("oaths", t, { n: 1 })])), B(e, t, "forgeElimination", r);
			}
			if (C(e, 28, "b")) {
				let t = q(e).suits[0];
				U(e, T, t === "mystery" ? "lore" : "influence", 1, n), t === "force" && U(e, T, "lore", 1, n);
			}
			return !0;
		case "forgeRefresh": {
			let n = O(e, r).tactics.find((e) => e.def === t.def);
			return n.exhausted = !1, n.markers = S[n.def].markers ?? 0, e.sim.caches += 2, !0;
		}
		case "simThreatReturn": return R(e, k(e, t.card), "deck", n), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/oldkingscrown/rules.ts
function wt(e, t) {
	return {
		rid: e,
		faction: t,
		influence: 0,
		lore: 0,
		handSize: 6,
		supporters: [
			0,
			0,
			0
		],
		supporterSupply: 5,
		supporterLost: 0,
		supporterBurned: 0,
		heralds: [null],
		markers: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		councilMarkers: [
			0,
			0,
			0
		],
		tactics: [],
		used: [],
		flags: [],
		boons: [],
		tradeCards: 2,
		bid: null,
		bidToken: null,
		siteCards: [],
		setupKingdom: []
	};
}
function Tt(e, t, n) {
	let r = Ze.parse(e), i = r.simulacrum === "auto" ? t.length === 1 : r.simulacrum !== "off";
	if (!t.length || t.length > 4 || new Set(t).size !== t.length || t.includes("$simulacrum") || i && t.length > 3 || t.length === 1 && !i) throw Error("Invalid Old King’s Crown player configuration");
	if (r.negotiating && t.length < 3) throw Error("Negotiating Table requires at least three human players");
	let a = {
		config: r,
		humans: [...t],
		players: [],
		cards: [],
		seed: n,
		cursor: 0,
		serial: 0,
		year: 1,
		phase: "setup",
		step: "setup",
		order: [],
		regionOrder: [],
		region: null,
		clash: 0,
		clashPlayers: [],
		dayNew: null,
		foughtSupporters: {},
		queue: [D("begin")],
		prompts: [],
		selections: [],
		beat: 0,
		road: [],
		kingdomDeck: [],
		kingdomDiscard: [],
		roadTaken: !1,
		favour: {
			owner: null,
			uses: 0
		},
		strengths: {},
		modules: {
			locations: [
				0,
				1,
				2,
				3,
				4,
				5
			],
			air: null,
			airOwner: null,
			airRegion: null,
			tower: null,
			town: null,
			airCards: [],
			towerBag: [],
			towerBoons: [],
			boonDiscard: [],
			townCards: [],
			townInfluence: 0,
			locationInfluence: [
				0,
				0,
				0,
				0,
				0,
				0
			],
			travelled: []
		},
		sim: {
			enabled: i,
			heat: 0,
			ambitionDeck: [],
			schemeDeck: [],
			threatDeck: [],
			bidStack: [],
			bidDiscard: [],
			orderToken: 0,
			ambition: null,
			scheme: null,
			threats: [],
			fog: [
				[],
				[],
				[]
			],
			revealedFog: [
				[],
				[],
				[]
			],
			towers: [],
			caches: 0
		},
		agreements: [],
		trade: null,
		known: {},
		log: [],
		done: !1,
		winner: [],
		scores: {}
	}, o = [...y];
	if (t.forEach((e, t) => {
		let n = r.factions[t], i = n && n !== "random" && o.includes(n) ? n : o[fe(a, o.length)];
		o.splice(o.indexOf(i), 1);
		let s = wt(e, i);
		a.players.push(s);
		let c = x.filter((e) => e.kind === "faction" && e.faction === i && e.basic);
		N(a, c.filter((e) => e.archetype !== "heir")).forEach((t, n) => {
			let r = P(a, t.id, e, "deck");
			r.position = n;
		}), P(a, c.find((e) => e.archetype === "heir").id, e, "hand"), x.filter((e) => e.faction === i && (e.kind === "faction" && !e.basic || e.kind === "hq")).forEach((t) => P(a, t.id, e, "site")), s.tactics = x.filter((e) => e.kind === "tactic" && e.faction === i).map((e) => ({
			def: e.id,
			exhausted: !1,
			markers: e.markers ?? 0,
			controllers: []
		})), Se(a, e, 0, [], !0);
	}), i) {
		let e = wt(T, "simulacrum");
		e.supporterSupply = 3, e.supporterLost = 7, e.heralds = [null], a.players.push(e), a.queue.unshift(D("simSetup", T));
	}
	a.order = i ? [T, ...N(a, t)] : N(a, t), le(a);
	let s = r.wild.map((e) => x.filter((e) => e.kind === "wild")[e].id);
	return a.kingdomDeck = N(a, [...s, ...N(a, x.filter((e) => e.kind === "kingdom").map((e) => e.id)).slice(0, 30 - s.length)]), Pe(a), a.queue.unshift(D("moduleSetup")), {
		state: a,
		fx: []
	};
}
function Et(e, t) {
	if (t.kind.startsWith("sim") && !e.sim.enabled) return !0;
	if (t.kind === "allyBid" || t.kind === "allyDeploy") {
		let n = t.step ?? 0;
		if (n >= e.order.length) return !0;
		let r = e.order[n], i = A(e, r, "hand").filter((t) => S[t.def].faction !== O(e, r).faction), a = D(t.kind, "", { step: n + 1 });
		return r === "$simulacrum" || !i.length ? (e.queue.unshift(a), !0) : (t.kind === "allyBid" ? B(e, r, "allyBid", i.map((e) => V(e.uid, "bid", [D("move", r, {
			card: e.uid,
			zone: "bid"
		})], {
			def: e.def,
			card: e.uid
		})), {
			min: 0,
			after: [a]
		}) : B(e, r, "allyDeploy", [...i.flatMap((t) => [
			0,
			1,
			2
		].filter((t) => !e.cards.some((e) => e.owner === r && e.zone === "active" && !e.faceUp && e.region === t)).map((e) => V(`${t.uid}:${e}`, "placeCard", [D("move", r, {
			card: t.uid,
			zone: "active",
			region: e,
			mode: "hidden"
		}), D("allyDeploy", "", { step: n })], {
			card: t.uid,
			def: t.def,
			region: e
		}))), V("pass", "pass", [a])]), !0);
	}
	return !1;
}
function Dt(e, t, n) {
	if (!(Ue(e, t, n, t.kind === "actionStep" && t.actor !== "$simulacrum" ? [...Ke(e, t.actor, t.mode), ...lt(e, t.actor, t.mode)] : []) || Re(e, t, n) || Ye(e, t, n) || at(e, t, n) || We(e, t, n) || ut(e, t, n) || je(e, t, n) || bt(e, t, n) || Ct(e, t, n) || Et(e, t))) throw Error(`Unimplemented Old King's Crown rule task: ${t.kind}`);
}
function Ot(e, t, n) {
	let r = { code: "games.oldkingscrown.errors.invalid" };
	if (e.done) return r;
	if (t.type === "allianceHand") {
		if (!e.agreements.some((e) => e.status === "active" && e.alliance && [e.a, e.b].includes(n.by) && [e.a, e.b].includes(t.target)) || t.target === n.by) return r;
		let i = structuredClone(e), a = O(i, n.by), o = `showHand:${t.target}`;
		return a.flags = a.flags.filter((e) => e !== o), t.show && a.flags.push(o), {
			state: i,
			fx: []
		};
	}
	if (t.type === "agreementRequest" || t.type === "promise") {
		if (!e.config.negotiating || !e.humans.includes(n.by)) return r;
		let i = structuredClone(e);
		if (t.type === "promise") {
			if (t.target === n.by || !i.humans.includes(t.target)) return r;
			i.queue.unshift(D("agreementPropose", n.by, {
				target: t.target,
				mode: "nonbinding",
				text: t.text
			}));
		} else {
			let e = i.agreements.find((e) => e.id === t.id && e.status === "active" && [e.a, e.b].includes(n.by));
			if (!e || i.queue.some((t) => t.n === e.id && ["agreementResolve", "agreementBreach"].includes(t.kind)) || t.mode === "breach" && (!t.target || ![e.a, e.b].includes(t.target) || !e.binding)) return r;
			i.queue.unshift(D(t.mode === "breach" ? "agreementBreach" : "agreementResolve", n.by, {
				n: e.id,
				mode: t.mode,
				target: t.target
			}));
		}
		return {
			state: i,
			fx: []
		};
	}
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.prompts.length || !e.queue.length) return r;
		let t = structuredClone(e), i = [];
		return t.beat = 0, Dt(t, t.queue.shift(), i), {
			state: t,
			fx: i
		};
	}
	let i = e.prompts.find((e) => e.id === t.prompt && e.actor === n.by);
	if (!i || t.options.length < i.min || t.options.length > i.max || new Set(t.options).size !== t.options.length || t.options.some((e) => !i.options.some((t) => t.id === e)) || t.text && !i.allowText) return r;
	let a = structuredClone(e), o = a.prompts.find((e) => e.id === i.id), s = t.options.flatMap((e) => o.options.find((t) => t.id === e).tasks);
	return t.text && s.forEach((e) => {
		e.kind === "agreementPropose" && (e.text = t.text);
	}), a.selections.push({
		prompt: i.id,
		tasks: [...s, ...o.after]
	}), a.prompts = a.prompts.filter((e) => e.id !== i.id), a.prompts.length || (a.queue.unshift(...a.selections.sort((e, t) => e.prompt - t.prompt).flatMap((e) => e.tasks)), a.selections = []), a.beat = 0, {
		state: a,
		fx: []
	};
}
function kt(e, t, n, r = !1) {
	let i = !t.faceUp && t.owner !== n && !(e.known[n] ?? []).includes(t.uid), a = !r && !i || t.faceUp, o = a ? z(e, t) : {
		strength: 0,
		votes: 0,
		lore: 0,
		traits: [],
		commands: [],
		archetypes: []
	};
	return {
		uid: i ? `hidden:${t.owner}:${t.zone}:${t.region ?? ""}:${t.position}` : t.uid,
		def: a ? t.def : null,
		owner: t.owner,
		zone: t.zone,
		region: t.region,
		location: t.location,
		suit: t.suit,
		parent: t.parent,
		influence: t.influence,
		faceUp: t.faceUp,
		strength: o.strength,
		votes: o.votes,
		lore: o.lore,
		traits: o.traits,
		commands: o.commands,
		archetypes: o.archetypes,
		copy: a ? t.copy : null,
		gainedRules: a ? t.gainedRules : [],
		tier: S[t.def].tier ?? null,
		back: S[t.def].faction ?? S[t.def].kind,
		guardStrength: t.guardStrength,
		fought: Te(e, t),
		boons: t.boons.map((e) => t.owner === n || t.faceUp ? e : null)
	};
}
function At(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.agreements.filter((e) => e.alliance && e.status === "active" && [e.a, e.b].includes(t)).map((e) => e.a === t ? e.b : e.a), i = e.sim.ambition ?? (e.config.forge.some((e) => e.id === 13 && e.side === "b") ? e.sim.ambitionDeck.at(-1) : e.sim.ambitionDeck[0]), a = e.sim.scheme ?? (e.config.forge.some((e) => e.id === 14 && e.side === "b") ? e.sim.schemeDeck.at(-1) : e.sim.schemeDeck[0]), o = e.trade && [e.trade.a, e.trade.b].includes(t) ? {
		...e.trade,
		give: e.trade.give.map((t) => ({
			...t,
			...t.uid ? { def: e.cards.find((e) => e.uid === t.uid).def } : {}
		})),
		take: e.trade.take.map((t) => ({
			...t,
			...t.uid ? { def: e.cards.find((e) => e.uid === t.uid).def } : {}
		}))
	} : null;
	return {
		public: {
			year: e.year,
			years: e.config.years,
			phase: e.phase,
			step: e.step,
			order: e.order,
			regionOrder: e.regionOrder,
			region: e.region,
			clash: e.clash,
			players: e.players.map((t) => ({
				rid: t.rid,
				faction: t.faction,
				influence: t.influence,
				lore: t.lore,
				handSize: t.handSize,
				handCount: A(e, t.rid, "hand").length,
				deckCount: A(e, t.rid, "deck").length,
				supporterSupply: t.supporterSupply,
				supporterLost: t.supporterLost,
				supporterBurned: t.supporterBurned,
				supporters: t.supporters,
				heralds: t.heralds,
				markers: t.markers,
				pending: e.prompts.some((e) => e.actor === t.rid),
				bidStrength: t.bid,
				councilMarkers: t.councilMarkers,
				councilVotes: [
					0,
					1,
					2
				].map((n) => W(e, t.rid, n)),
				score: e.scores[t.rid] ?? t.influence,
				tradeCards: t.tradeCards,
				boons: t.boons.length,
				tactics: t.tactics
			})),
			cards: e.cards.filter((e) => !["hand", "deck"].includes(e.zone)).map((n) => kt(e, n, t)),
			road: e.road,
			kingdomCount: e.kingdomDeck.length,
			kingdomDiscard: e.kingdomDiscard,
			favour: e.favour,
			strengths: e.strengths,
			config: e.config,
			waiting: e.prompts.map((e) => ({
				actor: e.actor,
				kind: e.kind
			})),
			modules: {
				locations: e.modules.locations,
				air: e.modules.air,
				airOwner: e.modules.airOwner,
				airRegion: e.modules.airRegion,
				airCards: e.modules.airCards,
				tower: e.modules.tower,
				town: e.modules.town,
				towerBoons: e.modules.towerBoons.map((e) => e < 0 ? -1 : null),
				boonBag: e.modules.towerBag.length,
				boonDiscard: e.modules.boonDiscard,
				townInfluence: e.modules.townInfluence,
				locationInfluence: e.modules.locationInfluence
			},
			sim: {
				enabled: e.sim.enabled,
				heat: e.sim.heat,
				ambition: e.sim.ambition,
				scheme: e.sim.scheme,
				ambitionBack: i === void 0 ? null : re[i].backRegion,
				schemeBack: a === void 0 ? null : dt[a].backRegion,
				deckTier: A(e, "$simulacrum", "deck")[0] ? S[A(e, "$simulacrum", "deck")[0].def].tier ?? null : null,
				threats: e.sim.threats,
				fog: e.sim.fog.map((e) => e.map(() => null)),
				towers: e.sim.towers,
				caches: e.sim.caches
			},
			agreements: e.agreements,
			log: e.log,
			done: e.done,
			winner: e.winner,
			scores: e.scores
		},
		private: {
			hand: A(e, t, "hand").map((n) => kt(e, n, t)),
			prompts: e.prompts.filter((e) => e.actor === t).map((e) => tt.parse(e)),
			known: e.cards.filter((n) => (e.known[t] ?? []).includes(n.uid) && n.zone !== "deck").map((n) => kt(e, n, t)),
			boons: n?.boons ?? [],
			alliedHands: r.filter((n) => O(e, n).flags.includes(`showHand:${t}`)).map((t) => ({
				rid: t,
				cards: A(e, t, "hand").map((n) => kt(e, n, t))
			})),
			sharingWith: r.filter((e) => n?.flags.includes(`showHand:${e}`)),
			trade: o
		}
	};
}
function jt(e) {
	if (!e.done) return { phase: e.phase };
	let t = [...e.humans].sort((t, n) => (e.scores[n] ?? 0) - (e.scores[t] ?? 0) || e.order.indexOf(t) - e.order.indexOf(n));
	return {
		phase: "done",
		winner: e.winner.filter((t) => e.humans.includes(t)),
		ranking: t,
		scores: Object.fromEntries(e.humans.map((t) => [t, e.scores[t]]))
	};
}
var Mt = {
	meta: Xe,
	saveCompatibility: { version: "1" },
	schemas: {
		action: Qe,
		config: Ze,
		publicView: nt,
		privateView: it
	},
	setup: Tt,
	reduce: Ot,
	viewFor: At,
	status: jt,
	nextTickIn: (e) => e.done || e.prompts.length || !e.queue.length ? null : e.beat
}, Nt = {
	clashWon: "games.oldkingscrown.ui.clashWon",
	clashTied: "games.oldkingscrown.ui.clashTied",
	creatureHerald: "games.oldkingscrown.ui.creatureHerald",
	fought: "games.oldkingscrown.ui.fought",
	confirmFulfilled: "games.oldkingscrown.ui.confirmFulfilled",
	confirmCancellation: "games.oldkingscrown.ui.confirmCancellation",
	broken: "games.oldkingscrown.ui.broken",
	supporter: "games.oldkingscrown.ui.supporter",
	resolved: "games.oldkingscrown.ui.resolved",
	setup: "games.oldkingscrown.ui.setup",
	year: "games.oldkingscrown.ui.year",
	spring: "games.oldkingscrown.ui.spring",
	summer: "games.oldkingscrown.ui.summer",
	autumn: "games.oldkingscrown.ui.autumn",
	winter: "games.oldkingscrown.ui.winter",
	done: "games.oldkingscrown.ui.done",
	draw: "games.oldkingscrown.ui.draw",
	bid: "games.oldkingscrown.ui.bid",
	resolveBid: "games.oldkingscrown.ui.resolveBid",
	herald: "games.oldkingscrown.ui.herald",
	deploy: "games.oldkingscrown.ui.deploy",
	negotiation: "games.oldkingscrown.ui.negotiation",
	clashOrder: "games.oldkingscrown.ui.clashOrder",
	reveal: "games.oldkingscrown.ui.reveal",
	day: "games.oldkingscrown.ui.day",
	night: "games.oldkingscrown.ui.night",
	outcome: "games.oldkingscrown.ui.outcome",
	reward: "games.oldkingscrown.ui.reward",
	autumnAction: "games.oldkingscrown.ui.autumnAction",
	choose: "games.oldkingscrown.ui.choose",
	card: "games.oldkingscrown.ui.card",
	placeCard: "games.oldkingscrown.ui.placeCard",
	supporterRegion: "games.oldkingscrown.ui.supporterRegion",
	supporters: "games.oldkingscrown.ui.supporters",
	pass: "games.oldkingscrown.ui.pass",
	skip: "games.oldkingscrown.ui.skip",
	confirm: "games.oldkingscrown.ui.confirm",
	selection: "games.oldkingscrown.ui.selection",
	selectionHint: "games.oldkingscrown.ui.selectionHint",
	waiting: "games.oldkingscrown.ui.waiting",
	resolving: "games.oldkingscrown.ui.resolving",
	hand: "games.oldkingscrown.ui.hand",
	deck: "games.oldkingscrown.ui.deck",
	discard: "games.oldkingscrown.ui.discard",
	lost: "games.oldkingscrown.ui.lost",
	burned: "games.oldkingscrown.ui.burned",
	supply: "games.oldkingscrown.ui.supply",
	active: "games.oldkingscrown.ui.active",
	occupying: "games.oldkingscrown.ui.occupying",
	site: "games.oldkingscrown.ui.site",
	council: "games.oldkingscrown.ui.council",
	councils: "games.oldkingscrown.ui.councils",
	road: "games.oldkingscrown.ui.road",
	map: "games.oldkingscrown.ui.map",
	players: "games.oldkingscrown.ui.players",
	details: "games.oldkingscrown.ui.details",
	inspect: "games.oldkingscrown.ui.inspect",
	close: "games.oldkingscrown.ui.close",
	back: "games.oldkingscrown.ui.back",
	empty: "games.oldkingscrown.ui.empty",
	round: "games.oldkingscrown.ui.round",
	influence: "games.oldkingscrown.ui.influence",
	lore: "games.oldkingscrown.ui.lore",
	strength: "games.oldkingscrown.ui.strength",
	votes: "games.oldkingscrown.ui.votes",
	cost: "games.oldkingscrown.ui.cost",
	handSize: "games.oldkingscrown.ui.handSize",
	supporterSupply: "games.oldkingscrown.ui.supporterSupply",
	supporterLost: "games.oldkingscrown.ui.supporterLost",
	favour: "games.oldkingscrown.ui.favour",
	nobility: "games.oldkingscrown.ui.nobility",
	clans: "games.oldkingscrown.ui.clans",
	uprising: "games.oldkingscrown.ui.uprising",
	gathering: "games.oldkingscrown.ui.gathering",
	simulacrum: "games.oldkingscrown.ui.simulacrum",
	opulence: "games.oldkingscrown.ui.opulence",
	mystery: "games.oldkingscrown.ui.mystery",
	force: "games.oldkingscrown.ui.force",
	region0: "games.oldkingscrown.ui.region0",
	region1: "games.oldkingscrown.ui.region1",
	region2: "games.oldkingscrown.ui.region2",
	location0: "games.oldkingscrown.ui.location0",
	location1: "games.oldkingscrown.ui.location1",
	location2: "games.oldkingscrown.ui.location2",
	location3: "games.oldkingscrown.ui.location3",
	location4: "games.oldkingscrown.ui.location4",
	location5: "games.oldkingscrown.ui.location5",
	reward0: "games.oldkingscrown.ui.reward0",
	reward1: "games.oldkingscrown.ui.reward1",
	reward2: "games.oldkingscrown.ui.reward2",
	reward3: "games.oldkingscrown.ui.reward3",
	reward4: "games.oldkingscrown.ui.reward4",
	reward5: "games.oldkingscrown.ui.reward5",
	agent: "games.oldkingscrown.ui.agent",
	captain: "games.oldkingscrown.ui.captain",
	cavalry: "games.oldkingscrown.ui.cavalry",
	champion: "games.oldkingscrown.ui.champion",
	follower: "games.oldkingscrown.ui.follower",
	heir: "games.oldkingscrown.ui.heir",
	ruse: "games.oldkingscrown.ui.ruse",
	trader: "games.oldkingscrown.ui.trader",
	warMachine: "games.oldkingscrown.ui.warMachine",
	creature: "games.oldkingscrown.ui.creature",
	invulnerable: "games.oldkingscrown.ui.invulnerable",
	pathfinder: "games.oldkingscrown.ui.pathfinder",
	resilient: "games.oldkingscrown.ui.resilient",
	deadly: "games.oldkingscrown.ui.deadly",
	flank: "games.oldkingscrown.ui.flank",
	ambush: "games.oldkingscrown.ui.ambush",
	retreat: "games.oldkingscrown.ui.retreat",
	ambush_or_retreat: "games.oldkingscrown.ui.ambush_or_retreat",
	rally2: "games.oldkingscrown.ui.rally2",
	rallySelf: "games.oldkingscrown.ui.rallySelf",
	deploy1_autumn: "games.oldkingscrown.ui.deploy1_autumn",
	deploy1_spring: "games.oldkingscrown.ui.deploy1_spring",
	bronze: "games.oldkingscrown.ui.bronze",
	silver: "games.oldkingscrown.ui.silver",
	gold: "games.oldkingscrown.ui.gold",
	hidden: "games.oldkingscrown.ui.hidden",
	kingdom: "games.oldkingscrown.ui.kingdom",
	wild: "games.oldkingscrown.ui.wild",
	hq: "games.oldkingscrown.ui.hq",
	tactic: "games.oldkingscrown.ui.tactic",
	aeronaut: "games.oldkingscrown.ui.aeronaut",
	boon: "games.oldkingscrown.ui.boon",
	forging: "games.oldkingscrown.ui.forging",
	heat: "games.oldkingscrown.ui.heat",
	threats: "games.oldkingscrown.ui.threats",
	fog: "games.oldkingscrown.ui.fog",
	ambition: "games.oldkingscrown.ui.ambition",
	scheme: "games.oldkingscrown.ui.scheme",
	deckTier: "games.oldkingscrown.ui.deckTier",
	intentBack: "games.oldkingscrown.ui.intentBack",
	modules: "games.oldkingscrown.ui.modules",
	airship: "games.oldkingscrown.ui.airship",
	town: "games.oldkingscrown.ui.town",
	tower: "games.oldkingscrown.ui.tower",
	log: "games.oldkingscrown.ui.log",
	agreements: "games.oldkingscrown.ui.agreements",
	alliedHands: "games.oldkingscrown.ui.alliedHands",
	shareHand: "games.oldkingscrown.ui.shareHand",
	hideHand: "games.oldkingscrown.ui.hideHand",
	agreementText: "games.oldkingscrown.ui.agreementText",
	agreementHint: "games.oldkingscrown.ui.agreementHint",
	fulfilled: "games.oldkingscrown.ui.fulfilled",
	cancelled: "games.oldkingscrown.ui.cancelled",
	breach: "games.oldkingscrown.ui.breach",
	promise: "games.oldkingscrown.ui.promise",
	tradeOffer: "games.oldkingscrown.ui.tradeOffer",
	tradeCounter: "games.oldkingscrown.ui.tradeCounter",
	tradeCards: "games.oldkingscrown.ui.tradeCards",
	mapMarker: "games.oldkingscrown.ui.mapMarker",
	councilMarker: "games.oldkingscrown.ui.councilMarker",
	yearOption: "games.oldkingscrown.ui.yearOption",
	years4: "games.oldkingscrown.ui.years4",
	years5: "games.oldkingscrown.ui.years5",
	years6: "games.oldkingscrown.ui.years6",
	advancedSetup: "games.oldkingscrown.ui.advancedSetup",
	advancedHint: "games.oldkingscrown.ui.advancedHint",
	factionOption: "games.oldkingscrown.ui.factionOption",
	random: "games.oldkingscrown.ui.random",
	seat: "games.oldkingscrown.ui.seat",
	simMode: "games.oldkingscrown.ui.simMode",
	auto: "games.oldkingscrown.ui.auto",
	off: "games.oldkingscrown.ui.off",
	competitive: "games.oldkingscrown.ui.competitive",
	cooperative: "games.oldkingscrown.ui.cooperative",
	simHint: "games.oldkingscrown.ui.simHint",
	forgeOption: "games.oldkingscrown.ui.forgeOption",
	forgeValue: "games.oldkingscrown.ui.forgeValue",
	none: "games.oldkingscrown.ui.none",
	threatOption: "games.oldkingscrown.ui.threatOption",
	advancedSimOption: "games.oldkingscrown.ui.advancedSimOption",
	aeronauts: "games.oldkingscrown.ui.aeronauts",
	creatures: "games.oldkingscrown.ui.creatures",
	negotiating: "games.oldkingscrown.ui.negotiating",
	nightMap: "games.oldkingscrown.ui.nightMap",
	wildCards: "games.oldkingscrown.ui.wildCards",
	enabled: "games.oldkingscrown.ui.enabled",
	resultTitle: "games.oldkingscrown.ui.resultTitle",
	resultWin: "games.oldkingscrown.ui.resultWin",
	resultCoopWin: "games.oldkingscrown.ui.resultCoopWin",
	resultCoopLoss: "games.oldkingscrown.ui.resultCoopLoss",
	resultTotal: "games.oldkingscrown.ui.resultTotal",
	resultTiebreak: "games.oldkingscrown.ui.resultTiebreak",
	reviewBoard: "games.oldkingscrown.ui.reviewBoard",
	showResult: "games.oldkingscrown.ui.showResult",
	exitConfirm: "games.oldkingscrown.ui.exitConfirm",
	hintCount: "games.oldkingscrown.ui.hintCount",
	autopilot: "games.oldkingscrown.ui.autopilot",
	exhausted: "games.oldkingscrown.ui.exhausted",
	ready: "games.oldkingscrown.ui.ready",
	uses: "games.oldkingscrown.ui.uses",
	guards: "games.oldkingscrown.ui.guards",
	copied: "games.oldkingscrown.ui.copied",
	gained: "games.oldkingscrown.ui.gained",
	influenceOnCard: "games.oldkingscrown.ui.influenceOnCard",
	keep: "games.oldkingscrown.ui.keep",
	mulligan: "games.oldkingscrown.ui.mulligan",
	acquire: "games.oldkingscrown.ui.acquire",
	steal: "games.oldkingscrown.ui.steal",
	returnBid: "games.oldkingscrown.ui.returnBid",
	startingKingdomGuard: "games.oldkingscrown.ui.startingKingdomGuard",
	emptySlot: "games.oldkingscrown.ui.emptySlot",
	replaceKingdom: "games.oldkingscrown.ui.replaceKingdom",
	govern: "games.oldkingscrown.ui.govern",
	journey: "games.oldkingscrown.ui.journey",
	secrets: "games.oldkingscrown.ui.secrets",
	oaths: "games.oldkingscrown.ui.oaths",
	region: "games.oldkingscrown.ui.region",
	location: "games.oldkingscrown.ui.location",
	player: "games.oldkingscrown.ui.player",
	count: "games.oldkingscrown.ui.count",
	regionOrder: "games.oldkingscrown.ui.regionOrder",
	claimFavour: "games.oldkingscrown.ui.claimFavour",
	returnHand: "games.oldkingscrown.ui.returnHand",
	moveLost: "games.oldkingscrown.ui.moveLost",
	deckTop: "games.oldkingscrown.ui.deckTop",
	deckBottom: "games.oldkingscrown.ui.deckBottom",
	markers: "games.oldkingscrown.ui.markers",
	discardCouncil: "games.oldkingscrown.ui.discardCouncil",
	discardHand: "games.oldkingscrown.ui.discardHand",
	discardDeckTop: "games.oldkingscrown.ui.discardDeckTop",
	discardForInfluence: "games.oldkingscrown.ui.discardForInfluence",
	activateTactic: "games.oldkingscrown.ui.activateTactic",
	refreshTactic: "games.oldkingscrown.ui.refreshTactic",
	burnTactic: "games.oldkingscrown.ui.burnTactic",
	cardInfluence: "games.oldkingscrown.ui.cardInfluence",
	boonCard: "games.oldkingscrown.ui.boonCard",
	allowElimination: "games.oldkingscrown.ui.allowElimination",
	ambushDiscard: "games.oldkingscrown.ui.ambushDiscard",
	lostSupporter: "games.oldkingscrown.ui.lostSupporter",
	recallSupporter: "games.oldkingscrown.ui.recallSupporter",
	returnHerald: "games.oldkingscrown.ui.returnHerald",
	playerHerald: "games.oldkingscrown.ui.playerHerald",
	locationReward: "games.oldkingscrown.ui.locationReward",
	protectHeirs: "games.oldkingscrown.ui.protectHeirs",
	gainDeadly: "games.oldkingscrown.ui.gainDeadly",
	sacrificePeregrine: "games.oldkingscrown.ui.sacrificePeregrine",
	proposeBarter: "games.oldkingscrown.ui.proposeBarter",
	proposeAgreement: "games.oldkingscrown.ui.proposeAgreement",
	proposeAlliance: "games.oldkingscrown.ui.proposeAlliance",
	finishNegotiation: "games.oldkingscrown.ui.finishNegotiation",
	requestCounteroffer: "games.oldkingscrown.ui.requestCounteroffer",
	submitCounteroffer: "games.oldkingscrown.ui.submitCounteroffer",
	clearOffer: "games.oldkingscrown.ui.clearOffer",
	cancelBarter: "games.oldkingscrown.ui.cancelBarter",
	acceptBarter: "games.oldkingscrown.ui.acceptBarter",
	makeCounteroffer: "games.oldkingscrown.ui.makeCounteroffer",
	decline: "games.oldkingscrown.ui.decline",
	nonbindingAgreement: "games.oldkingscrown.ui.nonbindingAgreement",
	bindingAgreement: "games.oldkingscrown.ui.bindingAgreement",
	acceptAgreement: "games.oldkingscrown.ui.acceptAgreement",
	confirmBreach: "games.oldkingscrown.ui.confirmBreach",
	denyBreach: "games.oldkingscrown.ui.denyBreach",
	noWinner: "games.oldkingscrown.ui.noWinner",
	visitAeronauts: "games.oldkingscrown.ui.visitAeronauts",
	visitTown: "games.oldkingscrown.ui.visitTown",
	visitTower: "games.oldkingscrown.ui.visitTower",
	exploreLabyrinth: "games.oldkingscrown.ui.exploreLabyrinth",
	explorePinnacle: "games.oldkingscrown.ui.explorePinnacle",
	leaveTower: "games.oldkingscrown.ui.leaveTower",
	protectBatch: "games.oldkingscrown.ui.protectBatch",
	recoverCouncil: "games.oldkingscrown.ui.recoverCouncil",
	recoverEliminated: "games.oldkingscrown.ui.recoverEliminated",
	buySite: "games.oldkingscrown.ui.buySite",
	occupy: "games.oldkingscrown.ui.occupy",
	occupySlot: "games.oldkingscrown.ui.occupySlot",
	placeSupporters: "games.oldkingscrown.ui.placeSupporters",
	allyBid: "games.oldkingscrown.ui.allyBid",
	allyDeploy: "games.oldkingscrown.ui.allyDeploy",
	startingKingdom: "games.oldkingscrown.ui.startingKingdom",
	tieCard: "games.oldkingscrown.ui.tieCard",
	orderPlayer: "games.oldkingscrown.ui.orderPlayer",
	chooseResource: "games.oldkingscrown.ui.chooseResource",
	clansSupporters: "games.oldkingscrown.ui.clansSupporters",
	deckEnd: "games.oldkingscrown.ui.deckEnd",
	discardBoons: "games.oldkingscrown.ui.discardBoons",
	doorDiscard: "games.oldkingscrown.ui.doorDiscard",
	falseOrders: "games.oldkingscrown.ui.falseOrders",
	flankSupporters: "games.oldkingscrown.ui.flankSupporters",
	foragers: "games.oldkingscrown.ui.foragers",
	forgeElimination: "games.oldkingscrown.ui.forgeElimination",
	giveBoon: "games.oldkingscrown.ui.giveBoon",
	harbour: "games.oldkingscrown.ui.harbour",
	journeyDestination: "games.oldkingscrown.ui.journeyDestination",
	lantern: "games.oldkingscrown.ui.lantern",
	martialLaw: "games.oldkingscrown.ui.martialLaw",
	monument: "games.oldkingscrown.ui.monument",
	moonshineRoad: "games.oldkingscrown.ui.moonshineRoad",
	necropolisCount: "games.oldkingscrown.ui.necropolisCount",
	negotiate: "games.oldkingscrown.ui.negotiate",
	placeBoons: "games.oldkingscrown.ui.placeBoons",
	rearrangeCouncils: "games.oldkingscrown.ui.rearrangeCouncils",
	regalGuard: "games.oldkingscrown.ui.regalGuard",
	relics: "games.oldkingscrown.ui.relics",
	roadAcquire: "games.oldkingscrown.ui.roadAcquire",
	royalBank: "games.oldkingscrown.ui.royalBank",
	royalSeal: "games.oldkingscrown.ui.royalSeal",
	rumoursPlayers: "games.oldkingscrown.ui.rumoursPlayers",
	secretLocation: "games.oldkingscrown.ui.secretLocation",
	secretReward: "games.oldkingscrown.ui.secretReward",
	simActionOrder: "games.oldkingscrown.ui.simActionOrder",
	simAutumnLoss: "games.oldkingscrown.ui.simAutumnLoss",
	simHerald: "games.oldkingscrown.ui.simHerald",
	simShrineDiscard: "games.oldkingscrown.ui.simShrineDiscard",
	simThreatInfluence: "games.oldkingscrown.ui.simThreatInfluence",
	sirenHeralds: "games.oldkingscrown.ui.sirenHeralds",
	sirenLocation: "games.oldkingscrown.ui.sirenLocation",
	supporterCount: "games.oldkingscrown.ui.supporterCount",
	towerAscend: "games.oldkingscrown.ui.towerAscend",
	towerLabyrinth: "games.oldkingscrown.ui.towerLabyrinth",
	towerMove: "games.oldkingscrown.ui.towerMove",
	towerPinnacleChoice: "games.oldkingscrown.ui.towerPinnacleChoice",
	townAcquire: "games.oldkingscrown.ui.townAcquire",
	townReplace: "games.oldkingscrown.ui.townReplace",
	waxwing: "games.oldkingscrown.ui.waxwing",
	witchTrial: "games.oldkingscrown.ui.witchTrial",
	airPlace: "games.oldkingscrown.ui.airPlace",
	agreementAccept: "games.oldkingscrown.ui.agreementAccept",
	agreementCompose: "games.oldkingscrown.ui.agreementCompose",
	agreementResolve: "games.oldkingscrown.ui.agreementResolve",
	allianceWinner: "games.oldkingscrown.ui.allianceWinner",
	arbitrateAgreement: "games.oldkingscrown.ui.arbitrateAgreement",
	auctionTactic: "games.oldkingscrown.ui.auctionTactic",
	barterInvitation: "games.oldkingscrown.ui.barterInvitation",
	barterReview: "games.oldkingscrown.ui.barterReview",
	boonGovernJourney: "games.oldkingscrown.ui.boonGovernJourney",
	boonTower: "games.oldkingscrown.ui.boonTower",
	tradeCompose: "games.oldkingscrown.ui.tradeCompose",
	acquiredSite: "games.oldkingscrown.ui.acquiredSite",
	activated: "games.oldkingscrown.ui.activated",
	attrition: "games.oldkingscrown.ui.attrition",
	barter: "games.oldkingscrown.ui.barter",
	eliminated: "games.oldkingscrown.ui.eliminated",
	outrage: "games.oldkingscrown.ui.outrage",
	revealedThreat: "games.oldkingscrown.ui.revealedThreat",
	acquiredKingdom: "games.oldkingscrown.ui.acquiredKingdom",
	stoleKingdom: "games.oldkingscrown.ui.stoleKingdom",
	wonClash: "games.oldkingscrown.ui.wonClash",
	wonCouncil: "games.oldkingscrown.ui.wonCouncil",
	"trade:influence": "games.oldkingscrown.ui.trade_influence",
	"trade:lore": "games.oldkingscrown.ui.trade_lore",
	"trade:supporters": "games.oldkingscrown.ui.trade_supporters",
	"trade:tradeCards": "games.oldkingscrown.ui.trade_tradeCards",
	"trade:hand": "games.oldkingscrown.ui.trade_hand",
	"trade:site": "games.oldkingscrown.ui.trade_site",
	"trade:kingdom": "games.oldkingscrown.ui.trade_kingdom",
	"trade:tactic": "games.oldkingscrown.ui.trade_tactic",
	"trade:boon": "games.oldkingscrown.ui.trade_boon",
	"trade:mapMarker": "games.oldkingscrown.ui.trade_mapMarker",
	"trade:councilMarker": "games.oldkingscrown.ui.trade_councilMarker",
	"trade:favour": "games.oldkingscrown.ui.trade_favour",
	nobilityFavour: "games.oldkingscrown.ui.nobilityFavour",
	clansFavour: "games.oldkingscrown.ui.clansFavour",
	uprisingFavour: "games.oldkingscrown.ui.uprisingFavour",
	gatheringFavour: "games.oldkingscrown.ui.gatheringFavour",
	activate: "games.oldkingscrown.ui.activate",
	activateBoon: "games.oldkingscrown.ui.activateBoon",
	beacon: "games.oldkingscrown.ui.beacon",
	beyondLights: "games.oldkingscrown.ui.beyondLights",
	blueHour: "games.oldkingscrown.ui.blueHour",
	boonSwap: "games.oldkingscrown.ui.boonSwap",
	copyLost: "games.oldkingscrown.ui.copyLost",
	diary: "games.oldkingscrown.ui.diary",
	discardActive: "games.oldkingscrown.ui.discardActive",
	door: "games.oldkingscrown.ui.door",
	embassy: "games.oldkingscrown.ui.embassy",
	engineers: "games.oldkingscrown.ui.engineers",
	estate: "games.oldkingscrown.ui.estate",
	flankCards: "games.oldkingscrown.ui.flankCards",
	grantAbility: "games.oldkingscrown.ui.grantAbility",
	grantRetreat: "games.oldkingscrown.ui.grantRetreat",
	handOrder: "games.oldkingscrown.ui.handOrder",
	heraldMoon: "games.oldkingscrown.ui.heraldMoon",
	hiddenLanes: "games.oldkingscrown.ui.hiddenLanes",
	laboratory: "games.oldkingscrown.ui.laboratory",
	medic: "games.oldkingscrown.ui.medic",
	mirror: "games.oldkingscrown.ui.mirror",
	moonshine: "games.oldkingscrown.ui.moonshine",
	opponentFavour: "games.oldkingscrown.ui.opponentFavour",
	placeAirship: "games.oldkingscrown.ui.placeAirship",
	queenGovern: "games.oldkingscrown.ui.queenGovern",
	rally: "games.oldkingscrown.ui.rally",
	retreatCards: "games.oldkingscrown.ui.retreatCards",
	retreatPieces: "games.oldkingscrown.ui.retreatPieces",
	returnFollower: "games.oldkingscrown.ui.returnFollower",
	ritualSacrifice: "games.oldkingscrown.ui.ritualSacrifice",
	riverRunners: "games.oldkingscrown.ui.riverRunners",
	safehouses: "games.oldkingscrown.ui.safehouses",
	saltToughness: "games.oldkingscrown.ui.saltToughness",
	schoolStars: "games.oldkingscrown.ui.schoolStars",
	seaLanes: "games.oldkingscrown.ui.seaLanes",
	shrine: "games.oldkingscrown.ui.shrine",
	spySwap: "games.oldkingscrown.ui.spySwap",
	swapHand: "games.oldkingscrown.ui.swapHand",
	swapHidden: "games.oldkingscrown.ui.swapHidden",
	swapTarget: "games.oldkingscrown.ui.swapTarget",
	tooth: "games.oldkingscrown.ui.tooth",
	tourney: "games.oldkingscrown.ui.tourney",
	witchOwn: "games.oldkingscrown.ui.witchOwn",
	visit: "games.oldkingscrown.ui.visit",
	proposed: "games.oldkingscrown.ui.proposed",
	expired: "games.oldkingscrown.ui.expired",
	declined: "games.oldkingscrown.ui.declined",
	reference: "games.oldkingscrown.ui.reference",
	boons: "games.oldkingscrown.ui.boons",
	abilities: "games.oldkingscrown.ui.abilities",
	left: "games.oldkingscrown.ui.left",
	right: "games.oldkingscrown.ui.right",
	stealIntent: "games.oldkingscrown.ui.stealIntent",
	acquireIntent: "games.oldkingscrown.ui.acquireIntent",
	cycle: "games.oldkingscrown.ui.cycle",
	first: "games.oldkingscrown.ui.first",
	simAmbush: "games.oldkingscrown.ui.simAmbush",
	simArmature: "games.oldkingscrown.ui.simArmature",
	simRally: "games.oldkingscrown.ui.simRally",
	simPall: "games.oldkingscrown.ui.simPall",
	simFrontlines: "games.oldkingscrown.ui.simFrontlines",
	simPickedOff: "games.oldkingscrown.ui.simPickedOff",
	simWhispers: "games.oldkingscrown.ui.simWhispers",
	simPitchBlack: "games.oldkingscrown.ui.simPitchBlack",
	cancel: "games.oldkingscrown.ui.cancel",
	resultTie: "games.oldkingscrown.ui.resultTie",
	resultSimWin: "games.oldkingscrown.ui.resultSimWin",
	resultCoopHint: "games.oldkingscrown.ui.resultCoopHint",
	resultWaiting: "games.oldkingscrown.ui.resultWaiting",
	playAgain: "games.oldkingscrown.ui.playAgain",
	backToLobby: "games.oldkingscrown.ui.backToLobby",
	playAgainConfirm: "games.oldkingscrown.ui.playAgainConfirm",
	confirmExit: "games.oldkingscrown.ui.confirmExit",
	finalYear: "games.oldkingscrown.ui.finalYear",
	score: "games.oldkingscrown.ui.score",
	pendingSubject: "games.oldkingscrown.ui.pendingSubject",
	boonOnCard: "games.oldkingscrown.ui.boonOnCard",
	favourOwner: "games.oldkingscrown.ui.favourOwner",
	noneOwner: "games.oldkingscrown.ui.noneOwner",
	mapMarkers: "games.oldkingscrown.ui.mapMarkers",
	supporterLostCount: "games.oldkingscrown.ui.supporterLostCount",
	orderTrack: "games.oldkingscrown.ui.orderTrack",
	bidCards: "games.oldkingscrown.ui.bidCards",
	forgeHeat: "games.oldkingscrown.ui.forgeHeat",
	seasonSetup: "games.oldkingscrown.ui.seasonSetup",
	seasonYear: "games.oldkingscrown.ui.seasonYear",
	seasonSpring: "games.oldkingscrown.ui.seasonSpring",
	seasonSummer: "games.oldkingscrown.ui.seasonSummer",
	seasonAutumn: "games.oldkingscrown.ui.seasonAutumn",
	seasonWinter: "games.oldkingscrown.ui.seasonWinter",
	currentChoice: "games.oldkingscrown.ui.currentChoice"
}, J = (e) => Nt[e] ?? "games.oldkingscrown.ui.choose", Pt = {
	nobility: "#1a4f9b",
	clans: "#017f7c",
	uprising: "#830c20",
	gathering: "#6e1977",
	simulacrum: "#657b7c",
	kingdom: "#234347",
	wild: "#234347",
	tactic: "#34445b",
	hq: "#234347",
	aeronaut: "#52675c",
	creature: "#52675c"
}, Ft = (e) => o(`games/oldkingscrown/live/card-${e}.svg`);
function Y({ kind: e, faction: t = "simulacrum", n }) {
	let r = c(), i = [
		"supporter",
		"herald",
		"creature"
	].includes(e) && t !== "simulacrum" ? `${e}-${t}` : [
		"tower",
		"town",
		"airship"
	].includes(e) ? e : null;
	return /* @__PURE__ */ m("span", {
		className: `okc-piece okc-piece--${e}`,
		style: { "--okc-faction": Pt[t] },
		title: r(J(e === "supporter" ? "supporters" : e)),
		children: [i ? /* @__PURE__ */ p("img", {
			src: o(`games/oldkingscrown/live/piece-${i}.svg`),
			alt: r(J(e === "supporter" ? "supporters" : e))
		}) : /* @__PURE__ */ p(X, { name: e === "councilMarker" && t === "simulacrum" ? "influence" : t }), n !== void 0 && /* @__PURE__ */ p("b", { children: n })]
	});
}
function X({ name: e, value: t }) {
	let n = c(), r = [
		"influence",
		"lore",
		"votes",
		"heir",
		"opulence",
		"mystery",
		"force",
		"ruse",
		"captain",
		"agent",
		"follower",
		"nobility",
		"clans",
		"gathering",
		"uprising",
		"trader",
		"warMachine",
		"cavalry",
		"invulnerable",
		"resilient",
		"pathfinder",
		"champion",
		"herald",
		"hq",
		"simulacrum"
	].includes(e);
	return /* @__PURE__ */ m("span", {
		className: "okc-symbol",
		title: n(J(e)),
		children: [r ? /* @__PURE__ */ p("img", {
			src: o(`games/oldkingscrown/live/icon-${e}.svg`),
			alt: n(J(e))
		}) : /* @__PURE__ */ p("small", { children: n(J(e)) }), t !== void 0 && /* @__PURE__ */ p("b", { children: t })]
	});
}
function It({ def: e, card: t, compact: n = !1, back: r = !1, backFaction: i }) {
	let a = c(), o = e ?? t?.def, s = o == null ? void 0 : S[o], l = !s || r, u = l ? i ?? t?.back ?? "kingdom" : s.faction ?? s.kind;
	return /* @__PURE__ */ p("span", {
		className: `okc-card${n ? " okc-card--compact" : ""}${l ? " okc-card--back" : ""}`,
		style: { "--okc-faction": Pt[u] ?? Pt.kingdom },
		children: l ? /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p("span", {
				className: "okc-card-back-crest",
				children: /* @__PURE__ */ p(X, { name: [
					"nobility",
					"clans",
					"uprising",
					"gathering",
					"simulacrum"
				].includes(u) ? u : "influence" })
			}),
			/* @__PURE__ */ p("strong", { children: a(J(i ?? t?.back ?? "hidden")) }),
			t?.tier && /* @__PURE__ */ p("small", { children: a(J(t.tier)) })
		] }) : /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ m("span", {
				className: "okc-card-image",
				children: [
					/* @__PURE__ */ p("img", {
						src: Ft(s.id),
						alt: "",
						loading: "lazy"
					}),
					s.strength !== void 0 && /* @__PURE__ */ m("span", {
						className: "okc-card-flag",
						children: [/* @__PURE__ */ p("b", { children: t?.strength ?? s.strength }), s.archetype && /* @__PURE__ */ p(X, { name: s.archetype })]
					}),
					s.cost !== void 0 && /* @__PURE__ */ p("span", {
						className: "okc-card-cost",
						children: /* @__PURE__ */ p(X, {
							name: "lore",
							value: s.cost
						})
					})
				]
			}),
			/* @__PURE__ */ m("span", {
				className: "okc-card-stats",
				children: [
					(s.votes !== void 0 || s.lore !== void 0) && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(X, {
						name: "votes",
						value: t?.votes ?? s.votes ?? 0
					}), /* @__PURE__ */ p(X, {
						name: "lore",
						value: t?.lore ?? s.lore ?? 0
					})] }),
					(t?.traits ?? s.traits ?? []).map((e) => /* @__PURE__ */ p(X, { name: e }, e)),
					s.suit && /* @__PURE__ */ p(X, { name: s.suit })
				]
			}),
			/* @__PURE__ */ p("strong", {
				className: "okc-card-name",
				children: a(s.nameKey)
			}),
			t?.fought && /* @__PURE__ */ p("small", {
				className: "okc-card-spent",
				children: a("games.oldkingscrown.ui.fought")
			}),
			!!t?.boons.length && /* @__PURE__ */ m("small", {
				className: "okc-card-spent",
				children: [
					a(J("boons")),
					" · ",
					t.boons.length
				]
			}),
			!n && /* @__PURE__ */ p("span", {
				className: "okc-card-commands",
				children: (t?.commands ?? s.commands ?? []).map((e) => /* @__PURE__ */ p("span", { children: a(J(e)) }, e))
			}),
			t && t.influence > 0 && /* @__PURE__ */ p("span", {
				className: "okc-card-coins",
				children: /* @__PURE__ */ p(X, {
					name: "influence",
					value: t.influence
				})
			})
		] })
	});
}
//#endregion
//#region src/games/oldkingscrown/reference-data.ts
var Z = {
	forge1a: {
		nameKey: "games.oldkingscrown.reference.nforge1a",
		effectKey: "games.oldkingscrown.reference.eforge1a"
	},
	forge1b: {
		nameKey: "games.oldkingscrown.reference.nforge1b",
		effectKey: "games.oldkingscrown.reference.eforge1b"
	},
	forge2a: {
		nameKey: "games.oldkingscrown.reference.nforge2a",
		effectKey: "games.oldkingscrown.reference.eforge2a"
	},
	forge2b: {
		nameKey: "games.oldkingscrown.reference.nforge2b",
		effectKey: "games.oldkingscrown.reference.eforge2b"
	},
	forge3a: {
		nameKey: "games.oldkingscrown.reference.nforge3a",
		effectKey: "games.oldkingscrown.reference.eforge3a"
	},
	forge3b: {
		nameKey: "games.oldkingscrown.reference.nforge3b",
		effectKey: "games.oldkingscrown.reference.eforge3b"
	},
	forge4a: {
		nameKey: "games.oldkingscrown.reference.nforge4a",
		effectKey: "games.oldkingscrown.reference.eforge4a"
	},
	forge4b: {
		nameKey: "games.oldkingscrown.reference.nforge4b",
		effectKey: "games.oldkingscrown.reference.eforge4b"
	},
	forge5a: {
		nameKey: "games.oldkingscrown.reference.nforge5a",
		effectKey: "games.oldkingscrown.reference.eforge5a"
	},
	forge5b: {
		nameKey: "games.oldkingscrown.reference.nforge5b",
		effectKey: "games.oldkingscrown.reference.eforge5b"
	},
	forge6a: {
		nameKey: "games.oldkingscrown.reference.nforge6a",
		effectKey: "games.oldkingscrown.reference.eforge6a"
	},
	forge6b: {
		nameKey: "games.oldkingscrown.reference.nforge6b",
		effectKey: "games.oldkingscrown.reference.eforge6b"
	},
	forge7a: {
		nameKey: "games.oldkingscrown.reference.nforge7a",
		effectKey: "games.oldkingscrown.reference.eforge7a"
	},
	forge7b: {
		nameKey: "games.oldkingscrown.reference.nforge7b",
		effectKey: "games.oldkingscrown.reference.eforge7b"
	},
	forge8a: {
		nameKey: "games.oldkingscrown.reference.nforge8a",
		effectKey: "games.oldkingscrown.reference.eforge8a"
	},
	forge8b: {
		nameKey: "games.oldkingscrown.reference.nforge8b",
		effectKey: "games.oldkingscrown.reference.eforge8b"
	},
	forge9a: {
		nameKey: "games.oldkingscrown.reference.nforge9a",
		effectKey: "games.oldkingscrown.reference.eforge9a"
	},
	forge9b: {
		nameKey: "games.oldkingscrown.reference.nforge9b",
		effectKey: "games.oldkingscrown.reference.eforge9b"
	},
	forge10a: {
		nameKey: "games.oldkingscrown.reference.nforge10a",
		effectKey: "games.oldkingscrown.reference.eforge10a"
	},
	forge10b: {
		nameKey: "games.oldkingscrown.reference.nforge10b",
		effectKey: "games.oldkingscrown.reference.eforge10b"
	},
	forge11a: {
		nameKey: "games.oldkingscrown.reference.nforge11a",
		effectKey: "games.oldkingscrown.reference.eforge11a"
	},
	forge11b: {
		nameKey: "games.oldkingscrown.reference.nforge11b",
		effectKey: "games.oldkingscrown.reference.eforge11b"
	},
	forge12a: {
		nameKey: "games.oldkingscrown.reference.nforge12a",
		effectKey: "games.oldkingscrown.reference.eforge12a"
	},
	forge12b: {
		nameKey: "games.oldkingscrown.reference.nforge12b",
		effectKey: "games.oldkingscrown.reference.eforge12b"
	},
	forge13a: {
		nameKey: "games.oldkingscrown.reference.nforge13a",
		effectKey: "games.oldkingscrown.reference.eforge13a"
	},
	forge13b: {
		nameKey: "games.oldkingscrown.reference.nforge13b",
		effectKey: "games.oldkingscrown.reference.eforge13b"
	},
	forge14a: {
		nameKey: "games.oldkingscrown.reference.nforge14a",
		effectKey: "games.oldkingscrown.reference.eforge14a"
	},
	forge14b: {
		nameKey: "games.oldkingscrown.reference.nforge14b",
		effectKey: "games.oldkingscrown.reference.eforge14b"
	},
	forge15a: {
		nameKey: "games.oldkingscrown.reference.nforge15a",
		effectKey: "games.oldkingscrown.reference.eforge15a"
	},
	forge15b: {
		nameKey: "games.oldkingscrown.reference.nforge15b",
		effectKey: "games.oldkingscrown.reference.eforge15b"
	},
	forge16a: {
		nameKey: "games.oldkingscrown.reference.nforge16a",
		effectKey: "games.oldkingscrown.reference.eforge16a"
	},
	forge16b: {
		nameKey: "games.oldkingscrown.reference.nforge16b",
		effectKey: "games.oldkingscrown.reference.eforge16b"
	},
	forge17a: {
		nameKey: "games.oldkingscrown.reference.nforge17a",
		effectKey: "games.oldkingscrown.reference.eforge17a"
	},
	forge17b: {
		nameKey: "games.oldkingscrown.reference.nforge17b",
		effectKey: "games.oldkingscrown.reference.eforge17b"
	},
	forge18a: {
		nameKey: "games.oldkingscrown.reference.nforge18a",
		effectKey: "games.oldkingscrown.reference.eforge18a"
	},
	forge18b: {
		nameKey: "games.oldkingscrown.reference.nforge18b",
		effectKey: "games.oldkingscrown.reference.eforge18b"
	},
	forge19a: {
		nameKey: "games.oldkingscrown.reference.nforge19a",
		effectKey: "games.oldkingscrown.reference.eforge19a"
	},
	forge19b: {
		nameKey: "games.oldkingscrown.reference.nforge19b",
		effectKey: "games.oldkingscrown.reference.eforge19b"
	},
	forge20a: {
		nameKey: "games.oldkingscrown.reference.nforge20a",
		effectKey: "games.oldkingscrown.reference.eforge20a"
	},
	forge20b: {
		nameKey: "games.oldkingscrown.reference.nforge20b",
		effectKey: "games.oldkingscrown.reference.eforge20b"
	},
	forge21a: {
		nameKey: "games.oldkingscrown.reference.nforge21a",
		effectKey: "games.oldkingscrown.reference.eforge21a"
	},
	forge21b: {
		nameKey: "games.oldkingscrown.reference.nforge21b",
		effectKey: "games.oldkingscrown.reference.eforge21b"
	},
	forge22a: {
		nameKey: "games.oldkingscrown.reference.nforge22a",
		effectKey: "games.oldkingscrown.reference.eforge22a"
	},
	forge22b: {
		nameKey: "games.oldkingscrown.reference.nforge22b",
		effectKey: "games.oldkingscrown.reference.eforge22b"
	},
	forge23a: {
		nameKey: "games.oldkingscrown.reference.nforge23a",
		effectKey: "games.oldkingscrown.reference.eforge23a"
	},
	forge23b: {
		nameKey: "games.oldkingscrown.reference.nforge23b",
		effectKey: "games.oldkingscrown.reference.eforge23b"
	},
	forge24a: {
		nameKey: "games.oldkingscrown.reference.nforge24a",
		effectKey: "games.oldkingscrown.reference.eforge24a"
	},
	forge24b: {
		nameKey: "games.oldkingscrown.reference.nforge24b",
		effectKey: "games.oldkingscrown.reference.eforge24b"
	},
	forge25a: {
		nameKey: "games.oldkingscrown.reference.nforge25a",
		effectKey: "games.oldkingscrown.reference.eforge25a"
	},
	forge25b: {
		nameKey: "games.oldkingscrown.reference.nforge25b",
		effectKey: "games.oldkingscrown.reference.eforge25b"
	},
	forge26a: {
		nameKey: "games.oldkingscrown.reference.nforge26a",
		effectKey: "games.oldkingscrown.reference.eforge26a"
	},
	forge26b: {
		nameKey: "games.oldkingscrown.reference.nforge26b",
		effectKey: "games.oldkingscrown.reference.eforge26b"
	},
	forge27a: {
		nameKey: "games.oldkingscrown.reference.nforge27a",
		effectKey: "games.oldkingscrown.reference.eforge27a"
	},
	forge27b: {
		nameKey: "games.oldkingscrown.reference.nforge27b",
		effectKey: "games.oldkingscrown.reference.eforge27b"
	},
	forge28a: {
		nameKey: "games.oldkingscrown.reference.nforge28a",
		effectKey: "games.oldkingscrown.reference.eforge28a"
	},
	forge28b: {
		nameKey: "games.oldkingscrown.reference.nforge28b",
		effectKey: "games.oldkingscrown.reference.eforge28b"
	},
	forge29a: {
		nameKey: "games.oldkingscrown.reference.nforge29a",
		effectKey: "games.oldkingscrown.reference.eforge29a"
	},
	forge29b: {
		nameKey: "games.oldkingscrown.reference.nforge29b",
		effectKey: "games.oldkingscrown.reference.eforge29b"
	},
	forge30a: {
		nameKey: "games.oldkingscrown.reference.nforge30a",
		effectKey: "games.oldkingscrown.reference.eforge30a"
	},
	forge30b: {
		nameKey: "games.oldkingscrown.reference.nforge30b",
		effectKey: "games.oldkingscrown.reference.eforge30b"
	},
	threat1: {
		nameKey: "games.oldkingscrown.reference.nthreat1",
		effectKey: "games.oldkingscrown.reference.ethreat1"
	},
	threat2: {
		nameKey: "games.oldkingscrown.reference.nthreat2",
		effectKey: "games.oldkingscrown.reference.ethreat2"
	},
	threat3: {
		nameKey: "games.oldkingscrown.reference.nthreat3",
		effectKey: "games.oldkingscrown.reference.ethreat3"
	},
	threat4: {
		nameKey: "games.oldkingscrown.reference.nthreat4",
		effectKey: "games.oldkingscrown.reference.ethreat4"
	},
	threat5: {
		nameKey: "games.oldkingscrown.reference.nthreat5",
		effectKey: "games.oldkingscrown.reference.ethreat5"
	},
	threat6: {
		nameKey: "games.oldkingscrown.reference.nthreat6",
		effectKey: "games.oldkingscrown.reference.ethreat6"
	},
	threat7: {
		nameKey: "games.oldkingscrown.reference.nthreat7",
		effectKey: "games.oldkingscrown.reference.ethreat7"
	},
	threat8: {
		nameKey: "games.oldkingscrown.reference.nthreat8",
		effectKey: "games.oldkingscrown.reference.ethreat8"
	},
	threat9: {
		nameKey: "games.oldkingscrown.reference.nthreat9",
		effectKey: "games.oldkingscrown.reference.ethreat9"
	},
	threat10: {
		nameKey: "games.oldkingscrown.reference.nthreat10",
		effectKey: "games.oldkingscrown.reference.ethreat10"
	},
	threat11: {
		nameKey: "games.oldkingscrown.reference.nthreat11",
		effectKey: "games.oldkingscrown.reference.ethreat11"
	},
	threat12: {
		nameKey: "games.oldkingscrown.reference.nthreat12",
		effectKey: "games.oldkingscrown.reference.ethreat12"
	},
	threat13: {
		nameKey: "games.oldkingscrown.reference.nthreat13",
		effectKey: "games.oldkingscrown.reference.ethreat13"
	},
	threat14: {
		nameKey: "games.oldkingscrown.reference.nthreat14",
		effectKey: "games.oldkingscrown.reference.ethreat14"
	},
	threat15: {
		nameKey: "games.oldkingscrown.reference.nthreat15",
		effectKey: "games.oldkingscrown.reference.ethreat15"
	},
	threat16: {
		nameKey: "games.oldkingscrown.reference.nthreat16",
		effectKey: "games.oldkingscrown.reference.ethreat16"
	},
	threat17: {
		nameKey: "games.oldkingscrown.reference.nthreat17",
		effectKey: "games.oldkingscrown.reference.ethreat17"
	},
	threat18: {
		nameKey: "games.oldkingscrown.reference.nthreat18",
		effectKey: "games.oldkingscrown.reference.ethreat18"
	},
	threat19: {
		nameKey: "games.oldkingscrown.reference.nthreat19",
		effectKey: "games.oldkingscrown.reference.ethreat19"
	},
	threat20: {
		nameKey: "games.oldkingscrown.reference.nthreat20",
		effectKey: "games.oldkingscrown.reference.ethreat20"
	},
	threat21: {
		nameKey: "games.oldkingscrown.reference.nthreat21",
		effectKey: "games.oldkingscrown.reference.ethreat21"
	},
	threat22: {
		nameKey: "games.oldkingscrown.reference.nthreat22",
		effectKey: "games.oldkingscrown.reference.ethreat22"
	},
	threat23: {
		nameKey: "games.oldkingscrown.reference.nthreat23",
		effectKey: "games.oldkingscrown.reference.ethreat23"
	},
	threat24: {
		nameKey: "games.oldkingscrown.reference.nthreat24",
		effectKey: "games.oldkingscrown.reference.ethreat24"
	},
	boon0: {
		nameKey: "games.oldkingscrown.reference.nboon0",
		effectKey: "games.oldkingscrown.reference.eboon0"
	},
	boon1: {
		nameKey: "games.oldkingscrown.reference.nboon1",
		effectKey: "games.oldkingscrown.reference.eboon1"
	},
	boon2: {
		nameKey: "games.oldkingscrown.reference.nboon2",
		effectKey: "games.oldkingscrown.reference.eboon2"
	},
	boon3: {
		nameKey: "games.oldkingscrown.reference.nboon3",
		effectKey: "games.oldkingscrown.reference.eboon3"
	},
	boon4: {
		nameKey: "games.oldkingscrown.reference.nboon4",
		effectKey: "games.oldkingscrown.reference.eboon4"
	},
	boon5: {
		nameKey: "games.oldkingscrown.reference.nboon5",
		effectKey: "games.oldkingscrown.reference.eboon5"
	},
	boon6: {
		nameKey: "games.oldkingscrown.reference.nboon6",
		effectKey: "games.oldkingscrown.reference.eboon6"
	},
	boon7: {
		nameKey: "games.oldkingscrown.reference.nboon7",
		effectKey: "games.oldkingscrown.reference.eboon7"
	},
	boon8: {
		nameKey: "games.oldkingscrown.reference.nboon8",
		effectKey: "games.oldkingscrown.reference.eboon8"
	},
	boon9: {
		nameKey: "games.oldkingscrown.reference.nboon9",
		effectKey: "games.oldkingscrown.reference.eboon9"
	},
	boon10: {
		nameKey: "games.oldkingscrown.reference.nboon10",
		effectKey: "games.oldkingscrown.reference.eboon10"
	},
	boon11: {
		nameKey: "games.oldkingscrown.reference.nboon11",
		effectKey: "games.oldkingscrown.reference.eboon11"
	},
	boon12: {
		nameKey: "games.oldkingscrown.reference.nboon12",
		effectKey: "games.oldkingscrown.reference.eboon12"
	},
	boon13: {
		nameKey: "games.oldkingscrown.reference.nboon13",
		effectKey: "games.oldkingscrown.reference.eboon13"
	},
	boon14: {
		nameKey: "games.oldkingscrown.reference.nboon14",
		effectKey: "games.oldkingscrown.reference.eboon14"
	},
	boon15: {
		nameKey: "games.oldkingscrown.reference.nboon15",
		effectKey: "games.oldkingscrown.reference.eboon15"
	},
	boon16: {
		nameKey: "games.oldkingscrown.reference.nboon16",
		effectKey: "games.oldkingscrown.reference.eboon16"
	},
	boon17: {
		nameKey: "games.oldkingscrown.reference.nboon17",
		effectKey: "games.oldkingscrown.reference.eboon17"
	},
	boon18: {
		nameKey: "games.oldkingscrown.reference.nboon18",
		effectKey: "games.oldkingscrown.reference.eboon18"
	},
	boon19: {
		nameKey: "games.oldkingscrown.reference.nboon19",
		effectKey: "games.oldkingscrown.reference.eboon19"
	}
};
//#endregion
//#region src/games/oldkingscrown/guide.tsx
function Lt() {
	let e = c(), [t, n] = a("faction"), [r, i] = a(""), o = [
		"faction",
		"kingdom",
		"wild",
		"hq",
		"tactic",
		"aeronaut",
		"creature",
		"simulacrum",
		"boon",
		"forge",
		"threats"
	], s = {
		faction: e("games.oldkingscrown.ui.factionOption"),
		forge: e("games.oldkingscrown.ui.forgeOption")
	}, l = (e) => e.toLocaleLowerCase().includes(r.trim().toLocaleLowerCase());
	return /* @__PURE__ */ m("div", {
		className: "okc-reference",
		style: {
			display: "grid",
			gap: 14,
			lineHeight: 1.7
		},
		children: [/* @__PURE__ */ p("div", {
			style: {
				display: "flex",
				gap: 6,
				flexWrap: "wrap"
			},
			children: o.map((r) => /* @__PURE__ */ p("button", {
				type: "button",
				"aria-pressed": t === r,
				onClick: () => n(r),
				style: {
					border: "1px solid currentColor",
					borderRadius: 4,
					padding: "5px 9px",
					opacity: t === r ? 1 : .65
				},
				children: s[r] ?? e(J(r))
			}, r))
		}), /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("input", {
			"aria-label": e("games.oldkingscrown.ui.inspect"),
			placeholder: e("games.oldkingscrown.ui.inspect"),
			value: r,
			onChange: (e) => i(e.target.value),
			style: {
				background: "transparent",
				border: "1px solid currentColor",
				borderRadius: 3,
				padding: 9,
				width: "100%"
			}
		}), [
			"boon",
			"forge",
			"threats"
		].includes(t) ? Object.entries(Z).filter(([n, r]) => n.startsWith(t === "threats" ? "threat" : t) && l(`${e(r.nameKey)} ${e(r.effectKey)}`)).map(([t, n]) => /* @__PURE__ */ m("article", {
			style: {
				borderBottom: "1px solid #8b826b",
				paddingBottom: 12
			},
			children: [/* @__PURE__ */ p("strong", { children: e(n.nameKey) }), /* @__PURE__ */ p("p", { children: e(n.effectKey) })]
		}, t)) : x.filter((n) => n.kind === t && l(`${e(n.nameKey)} ${e(n.effectKey)}`)).map((t) => /* @__PURE__ */ m("article", {
			style: {
				borderBottom: "1px solid #8b826b",
				paddingBottom: 12
			},
			children: [
				/* @__PURE__ */ p("strong", { children: e(t.nameKey) }),
				/* @__PURE__ */ m("span", {
					style: {
						display: "flex",
						gap: 12,
						flexWrap: "wrap",
						margin: "5px 0"
					},
					children: [
						t.strength !== void 0 && /* @__PURE__ */ m("span", { children: [
							e(J("strength")),
							" ",
							t.strength
						] }),
						t.archetype && /* @__PURE__ */ p(X, { name: t.archetype }),
						t.cost !== void 0 && /* @__PURE__ */ m("span", { children: [
							e(J("cost")),
							" ",
							t.cost
						] }),
						t.votes !== void 0 && /* @__PURE__ */ p(X, {
							name: "votes",
							value: t.votes
						}),
						t.lore !== void 0 && /* @__PURE__ */ p(X, {
							name: "lore",
							value: t.lore
						}),
						t.traits?.map((t) => /* @__PURE__ */ p("span", { children: e(J(t)) }, t))
					]
				}),
				/* @__PURE__ */ p("p", { children: e(t.effectKey) }),
				t.commands?.map((t) => /* @__PURE__ */ p("p", { children: e(J(t)) }, t))
			]
		}, t.id))] })]
	});
}
//#endregion
//#region src/games/oldkingscrown/view-player.tsx
function Rt({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = l(e);
	return /* @__PURE__ */ p("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function Q({ name: e, children: t }) {
	let { ref: n, hidden: r } = l(e);
	return /* @__PURE__ */ p("span", {
		ref: n,
		className: "okc-piece-anchor",
		style: { visibility: r ? "hidden" : void 0 },
		children: t
	});
}
function zt({ children: e, label: t, close: r, className: a = "okc-tools" }) {
	let o = i(null), s = i(r);
	return n(() => {
		s.current = r;
	}, [r]), n(() => {
		let e = document.activeElement, t = () => [...o.current?.querySelectorAll("button:not(:disabled), input:not(:disabled), textarea, select, a[href], [tabindex=\"0\"]") ?? []];
		t()[0]?.focus();
		let n = (e) => {
			if (e.key === "Escape" && (e.preventDefault(), s.current()), e.key === "Tab") {
				let n = t(), r = n[0], i = n.at(-1);
				e.shiftKey && document.activeElement === r ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), r?.focus());
			}
		};
		return document.addEventListener("keydown", n), () => {
			document.removeEventListener("keydown", n), e?.focus();
		};
	}, []), /* @__PURE__ */ p("div", {
		className: "okc-modal-shade",
		onClick: r,
		children: /* @__PURE__ */ p("section", {
			ref: o,
			className: a,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": t,
			onClick: (e) => e.stopPropagation(),
			children: e
		})
	});
}
var Bt = [
	"region0",
	"region1",
	"region2"
], Vt = [
	"location0",
	"location1",
	"location2",
	"location3",
	"location4",
	"location5"
], Ht = [
	"reward0",
	"reward1",
	"reward2",
	"reward3",
	"reward4",
	"reward5"
], Ut = [
	"opulence",
	"mystery",
	"force"
];
function Wt(e) {
	let t = e.public, n = e.private, r = !e.readOnly && !t.done ? n?.prompts[0] : void 0;
	return /* @__PURE__ */ p(Gt, {
		...e,
		pub: t,
		priv: n,
		prompt: r
	}, e.myRid);
}
function Gt({ pub: e, priv: t, prompt: n, myRid: r, members: i, send: l, readOnly: h }) {
	let g = c(), _ = s((e) => e.locale), [v, ee] = a([]), [te, ne] = a(""), [y, b] = a(null), [x, C] = a(null), [ie, ae] = a("occupying"), [w, oe] = a(r), [se, ce] = a(n?.id);
	se !== n?.id && (ce(n?.id), ee([]), ne(""), C(null));
	let [le, ue] = a(null), de = e.players.find((e) => e.rid === r), T = (e) => e === "$simulacrum" ? g("games.oldkingscrown.ui.simulacrum") : i.find((t) => t.rid === e) ? d(i.find((t) => t.rid === e), _) : e, E = (e) => {
		n && !h && ee((t) => t.includes(e) ? t.filter((t) => t !== e) : n.max === 1 ? [e] : t.length < n.max ? [...t, e] : t);
	}, D = [
		...e.cards,
		...t?.hand ?? [],
		...t?.known ?? []
	], O = (e) => n?.options.filter((t) => "uid" in e && t.card === e.uid || !t.card && t.def === e.def) ?? [], k = (e, t, n) => {
		let i = n ?? O(e), a = i.length === 1 ? i[0] : void 0, o = "uid" in e ? e.uid : `def:${e.def}`, s = i.some((e) => v.includes(e.id)), c = "uid" in e ? e : void 0;
		return /* @__PURE__ */ m(Rt, {
			name: `card:${o}`,
			className: "okc-card-object",
			children: [/* @__PURE__ */ m("button", {
				type: "button",
				className: `okc-card-button${i.length ? " okc-legal" : ""}${s ? " okc-selected" : ""}`,
				"aria-pressed": s,
				onClick: () => a ? E(a.id) : i.length > 1 ? C(o) : e.def !== null && b({
					def: e.def,
					card: c
				}),
				children: [
					/* @__PURE__ */ p(It, {
						def: e.def,
						card: c,
						compact: !0
					}),
					c?.owner && c.owner !== r && /* @__PURE__ */ p("small", {
						className: "okc-card-owner",
						children: T(c.owner)
					}),
					s && /* @__PURE__ */ p("span", {
						className: "okc-selection-order",
						children: v.indexOf(i.find((e) => v.includes(e.id)).id) + 1
					})
				]
			}), e.def !== null && /* @__PURE__ */ p("button", {
				type: "button",
				className: "okc-inspect",
				"aria-label": `${g("games.oldkingscrown.ui.inspect")} · ${g(S[e.def].nameKey)}`,
				onClick: () => b({
					def: e.def,
					card: c
				}),
				children: "＋"
			})]
		}, t ?? o);
	}, A = (e, t) => (!e.card && !e.def || t === "region" && e.label === "placeCard" && e.card === x) && !e.label.startsWith("trade:") && e.label !== "regionOrder" && e[t] !== void 0 && e[t] >= 0 && e[t] < (t === "location" ? 6 : 3), j = (e, t) => n?.options.filter((n) => A(n, e) && n[e] === t) ?? [], M = [
		...e.cards.filter((e) => [
			"active",
			"council",
			"bid"
		].includes(e.zone) || e.zone === "supply" && (e.region !== null || e.location !== null) || e.owner === w && e.zone === ie && (ie !== "supply" || e.region === null && e.location === null)),
		...t?.hand ?? [],
		...t?.known.filter((t) => !e.cards.some((e) => e.uid === t.uid)) ?? []
	], fe = (t) => !!(t.card && M.some((e) => e.uid === t.card) || t.def && !t.card && (e.road.includes(t.def) || M.some((e) => e.def === t.def)) || [
		"region",
		"location",
		"suit"
	].some((e) => A(t, e))), pe = n?.options.filter((e) => !fe(e)) ?? [], N = x ? n?.options.filter((e) => e.card === x || x === `def:${e.def}` || A(e, "region") && x === `region:${e.region}` || A(e, "location") && x === `location:${e.location}` || A(e, "suit") && x === `council:${e.suit}`) ?? [] : [], P = x ? N.filter((e) => !A(e, "region")) : pe, F = (t, n) => t === "tactic" ? g(S[n].nameKey) : t === "boon" ? g(Z[`boon${n}`].nameKey) : t === "mapMarker" ? g(J(Vt[e.modules.locations[n]])) : t === "councilMarker" ? g(J(Ut[n])) : "", me = (t) => [
		g(J(t.label), { n: t.n ?? "" }),
		t.def ? g(S[t.def].nameKey) : "",
		t.card && t.def !== D.find((e) => e.uid === t.card)?.def && D.find((e) => e.uid === t.card)?.def ? g(S[D.find((e) => e.uid === t.card).def].nameKey) : "",
		t.player ? T(t.player) : "",
		t.region !== void 0 && t.region >= 0 ? g(J(Bt[t.region])) : "",
		t.location === void 0 ? "" : g(J(Vt[e.modules.locations[t.location] ?? t.location])),
		t.suit === void 0 ? "" : t.label.startsWith("trade:") ? F(t.label.slice(6), t.suit) : t.suit < 3 ? g(J(Ut[t.suit])) : "",
		t.label === "regionOrder" ? [
			[
				0,
				1,
				2
			],
			[
				0,
				2,
				1
			],
			[
				1,
				0,
				2
			],
			[
				1,
				2,
				0
			],
			[
				2,
				0,
				1
			],
			[
				2,
				1,
				0
			]
		][t.n ?? 0].map((e) => g(J(Bt[e]))).join(" → ") : t.label === "boon" && t.n !== void 0 ? g(Z[`boon${t.n}`].nameKey) : t.n !== void 0 && !["emptySlot"].includes(t.label) ? String(t.n) : ""
	].filter(Boolean).join(" · "), I = (e, t) => e.length === 1 ? E(e[0].id) : C(t), he = (e) => ({ "--okc-faction": Pt[e] ?? "#61717d" }), L = w === r && ie === "hand" ? t?.hand ?? [] : e.cards.filter((e) => e.owner === w && e.zone === ie && (ie !== "supply" || e.region === null && e.location === null));
	return /* @__PURE__ */ m(u, {
		adaptive: !0,
		className: "okc-screen",
		scroll: !1,
		actionsHeight: "okc-actions-slot",
		banner: /* @__PURE__ */ m("header", {
			className: "okc-banner",
			children: [/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: g("games.oldkingscrown.name") }), /* @__PURE__ */ m("span", { children: [
				g("games.oldkingscrown.ui.round", {
					n: e.year,
					total: e.years
				}),
				" · ",
				g(J(e.phase))
			] })] }), /* @__PURE__ */ m("div", {
				className: "okc-banner-step",
				children: [
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => ue("reference"),
						children: g(J("reference"))
					}),
					!h && /* @__PURE__ */ p("span", { children: g(J(n?.kind ?? e.step)) }),
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => ue(le === "log" ? null : "log"),
						children: g("games.oldkingscrown.ui.log")
					}),
					e.config.negotiating && /* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => ue(le === "agreements" ? null : "agreements"),
						children: g("games.oldkingscrown.ui.agreements")
					})
				]
			})]
		}),
		actions: /* @__PURE__ */ m("div", {
			className: "okc-actions",
			children: [/* @__PURE__ */ p("div", { children: n ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("strong", { children: g(J(n.kind)) }), /* @__PURE__ */ m("small", { children: [
				g("games.oldkingscrown.ui.selectionHint", {
					min: n.min,
					max: n.max
				}),
				" · ",
				v.length
			] })] }) : /* @__PURE__ */ p("strong", { children: g(J(h || e.done ? "done" : e.waiting.length ? "waiting" : "resolving")) }) }), n && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: "okc-confirm",
				disabled: v.length < n.min || v.length > n.max,
				onClick: () => l({
					type: "choose",
					prompt: n.id,
					options: v,
					...te.trim() ? { text: te.trim() } : {}
				}),
				children: g("games.oldkingscrown.ui.confirm")
			}), n.min === 0 && /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => l({
					type: "choose",
					prompt: n.id,
					options: []
				}),
				children: g("games.oldkingscrown.ui.skip")
			})] })]
		}),
		children: [
			/* @__PURE__ */ m("div", {
				className: "okc-play-area",
				children: [/* @__PURE__ */ m("div", {
					className: "okc-main-scroll",
					children: [/* @__PURE__ */ p("aside", {
						className: "okc-player-strip",
						children: e.order.map((t) => {
							let n = e.players.find((e) => e.rid === t);
							return /* @__PURE__ */ m(Rt, {
								name: `seat:${t}`,
								children: [/* @__PURE__ */ m("button", {
									type: "button",
									className: `okc-player${t === w ? " okc-player--selected" : ""}`,
									style: he(n.faction),
									onClick: () => oe(t),
									children: [
										/* @__PURE__ */ m("span", {
											className: "okc-player-name",
											children: [
												/* @__PURE__ */ p("i", {}),
												T(t),
												n.pending && /* @__PURE__ */ p("span", {
													className: "okc-pending",
													"aria-label": g("games.oldkingscrown.ui.waiting")
												})
											]
										}),
										/* @__PURE__ */ p("small", { children: g(J(n.faction)) }),
										/* @__PURE__ */ m("span", {
											className: "okc-resources",
											children: [
												/* @__PURE__ */ p(X, {
													name: "influence",
													value: n.influence
												}),
												/* @__PURE__ */ p(X, {
													name: "lore",
													value: n.lore
												}),
												/* @__PURE__ */ m("span", {
													title: g("games.oldkingscrown.ui.handSize"),
													children: [
														n.handCount,
														"／",
														n.handSize
													]
												})
											]
										}),
										/* @__PURE__ */ p("span", {
											className: "okc-player-piles",
											children: n.bidStrength !== null && /* @__PURE__ */ m(f, { children: [
												g("games.oldkingscrown.ui.strength"),
												" ",
												n.bidStrength
											] })
										})
									]
								}), /* @__PURE__ */ m("div", {
									className: "okc-seat-pieces",
									children: [
										/* @__PURE__ */ p(Q, {
											name: `supporterSupply:${t}`,
											children: /* @__PURE__ */ p(Y, {
												kind: "supporter",
												faction: n.faction,
												n: n.supporterSupply
											})
										}),
										/* @__PURE__ */ m(Q, {
											name: `supporterLost:${t}`,
											children: [
												g(J("lost")),
												" ",
												n.supporterLost
											]
										}),
										e.modules.airOwner === t && e.modules.airRegion === null && /* @__PURE__ */ p(Q, {
											name: "airship",
											children: /* @__PURE__ */ p(Y, { kind: "airship" })
										}),
										["deck", "discard"].map((r) => /* @__PURE__ */ p(Q, {
											name: `${r}:${t}`,
											children: /* @__PURE__ */ m("span", {
												className: "okc-pile-label",
												children: [
													g(J(r)),
													" ",
													r === "deck" ? n.deckCount : e.cards.filter((e) => e.owner === t && e.zone === r).length
												]
											})
										}, r))
									]
								})]
							}, t);
						})
					}), /* @__PURE__ */ m("div", {
						className: "okc-table",
						children: [
							/* @__PURE__ */ m(Rt, {
								name: "road",
								className: "okc-road",
								children: [/* @__PURE__ */ m("h2", { children: [
									g("games.oldkingscrown.ui.road"),
									" ",
									/* @__PURE__ */ p(Q, {
										name: "kingdomDeck",
										children: /* @__PURE__ */ p(X, {
											name: "kingdom",
											value: e.kingdomCount
										})
									}),
									/* @__PURE__ */ m(Q, {
										name: "kingdomDiscard",
										children: [
											g(J("discard")),
											" ",
											e.kingdomDiscard.length
										]
									}),
									/* @__PURE__ */ m("span", {
										className: "okc-favour-status",
										children: [g(J("favourOwner"), { name: e.favour.owner ? T(e.favour.owner) : g(J("noneOwner")) }), e.favour.owner && ` · ${e.favour.uses}`]
									})
								] }), /* @__PURE__ */ m("div", {
									className: "okc-card-row",
									children: [e.road.map((e, t) => /* @__PURE__ */ p(Rt, {
										name: `roadSlot:${t}`,
										className: "okc-road-slot",
										children: k({ def: e })
									}, t)), e.cards.some((e) => e.zone === "bid") && /* @__PURE__ */ m(Rt, {
										name: "bids",
										className: "okc-bids",
										children: [/* @__PURE__ */ p("h2", { children: g(J("bid")) }), /* @__PURE__ */ p("div", {
											className: "okc-card-row",
											children: e.cards.filter((e) => e.zone === "bid").map((e) => k(e))
										})]
									})]
								})]
							}),
							/* @__PURE__ */ p("div", {
								className: "okc-map",
								children: [
									0,
									1,
									2
								].map((t) => {
									let n = j("region", t), r = e.region === t;
									return /* @__PURE__ */ m(Rt, {
										name: `region:${t}`,
										className: `okc-region${r ? " okc-region--current" : ""}`,
										children: [
											/* @__PURE__ */ m("div", {
												className: "okc-region-scene",
												style: { backgroundImage: `url("${o(`games/oldkingscrown/live/region-${t}.svg`)}")` },
												children: [/* @__PURE__ */ p("h2", { children: /* @__PURE__ */ m("button", {
													type: "button",
													className: n.length ? "okc-legal" : "",
													onClick: () => n.length && I(n, `region:${t}`),
													disabled: !n.length,
													children: [g(J(Bt[t])), e.regionOrder.includes(t) && /* @__PURE__ */ p("span", {
														className: "okc-region-order",
														children: e.regionOrder.indexOf(t) + 1
													})]
												}) }), /* @__PURE__ */ p("div", {
													className: "okc-locations",
													children: [t * 2, t * 2 + 1].map((t) => {
														let n = e.modules.locations[t], r = j("location", t);
														return /* @__PURE__ */ m(Rt, {
															name: `location:${t}`,
															children: [/* @__PURE__ */ m("button", {
																type: "button",
																className: `okc-location${r.length ? " okc-legal" : ""}${r.some((e) => v.includes(e.id)) ? " okc-selected" : ""}`,
																onClick: () => r.length && I(r, `location:${t}`),
																title: g(J(Ht[n])),
																disabled: !r.length,
																children: [
																	/* @__PURE__ */ p("b", { children: g(J(Vt[n])) }),
																	/* @__PURE__ */ p("span", { children: g(J(Ht[n])) }),
																	/* @__PURE__ */ m("span", {
																		className: "okc-heralds",
																		children: [
																			e.players.flatMap((e) => e.heralds.flatMap((n, r) => n === t ? [/* @__PURE__ */ m(Q, {
																				name: `herald:${e.rid}:${r}`,
																				children: [/* @__PURE__ */ p(Y, {
																					kind: "herald",
																					faction: e.faction
																				}), /* @__PURE__ */ p("small", { children: T(e.rid) })]
																			}, `${e.rid}:${r}`)] : [])),
																			e.modules.air === t && /* @__PURE__ */ p(Q, {
																				name: "airship",
																				children: /* @__PURE__ */ p(Y, { kind: "airship" })
																			}),
																			e.modules.tower === t && /* @__PURE__ */ p(Q, {
																				name: "tower",
																				children: /* @__PURE__ */ p(Y, { kind: "tower" })
																			}),
																			e.modules.town === t && /* @__PURE__ */ p(Y, { kind: "town" })
																		]
																	})
																]
															}), /* @__PURE__ */ m("div", {
																className: "okc-location-markers",
																children: [
																	e.players.map((e) => /* @__PURE__ */ p(Q, {
																		name: `marker:${e.rid}:${t}`,
																		children: e.markers[t] > 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Y, {
																			kind: "marker",
																			faction: e.faction,
																			n: e.markers[t]
																		}), /* @__PURE__ */ p("small", { children: T(e.rid) })] })
																	}, e.rid)),
																	e.modules.locationInfluence[t] > 0 && /* @__PURE__ */ p(X, {
																		name: "influence",
																		value: e.modules.locationInfluence[t]
																	}),
																	e.cards.filter((e) => e.zone === "supply" && e.location === t).map((e) => k(e))
																]
															})]
														}, t);
													})
												})]
											}),
											/* @__PURE__ */ m("div", {
												className: "okc-supporters",
												children: [e.modules.airRegion === t && /* @__PURE__ */ p(Q, {
													name: "airship",
													children: /* @__PURE__ */ p(Y, { kind: "airship" })
												}), e.players.map((n) => /* @__PURE__ */ m("span", {
													style: he(n.faction),
													children: [
														/* @__PURE__ */ p(Q, {
															name: `supporter:${n.rid}:${t}`,
															children: /* @__PURE__ */ p(Y, {
																kind: "supporter",
																faction: n.faction,
																n: n.supporters[t]
															})
														}),
														T(n.rid),
														r && e.strengths[n.rid] !== void 0 && /* @__PURE__ */ m(f, { children: [" · ", /* @__PURE__ */ p(X, {
															name: "strength",
															value: e.strengths[n.rid]
														})] })
													]
												}, n.rid))]
											}),
											/* @__PURE__ */ p("div", {
												className: "okc-card-row okc-region-cards",
												children: e.cards.filter((e) => (e.zone === "active" || e.zone === "supply") && e.region === t).map((e) => k(e))
											}),
											e.sim.enabled && !!e.sim.fog[t].length && /* @__PURE__ */ m("span", {
												className: "okc-fog",
												children: [
													g("games.oldkingscrown.ui.fog"),
													" ",
													e.sim.fog[t].length
												]
											})
										]
									}, t);
								})
							}),
							/* @__PURE__ */ p("div", {
								className: "okc-councils",
								children: [
									0,
									1,
									2
								].map((t) => {
									let n = j("suit", t);
									return /* @__PURE__ */ m(Rt, {
										name: `council:${t}`,
										className: "okc-council",
										children: [
											/* @__PURE__ */ p("h2", { children: /* @__PURE__ */ m("button", {
												type: "button",
												className: n.length ? "okc-legal" : "",
												disabled: !n.length,
												onClick: () => I(n, `council:${t}`),
												children: [/* @__PURE__ */ p(X, { name: Ut[t] }), g(J(Ut[t]))]
											}) }),
											/* @__PURE__ */ p("div", {
												className: "okc-card-row",
												children: e.cards.filter((e) => e.zone === "council" && e.suit === t).map((e) => k(e))
											}),
											/* @__PURE__ */ p("div", {
												className: "okc-council-votes",
												children: e.players.map((e) => /* @__PURE__ */ m("span", {
													style: he(e.faction),
													children: [
														/* @__PURE__ */ p(Q, {
															name: `councilMarker:${e.rid}:${t}`,
															children: /* @__PURE__ */ p(Y, {
																kind: "councilMarker",
																faction: e.faction,
																n: e.councilMarkers[t]
															})
														}),
														T(e.rid),
														" ",
														/* @__PURE__ */ p(X, {
															name: "votes",
															value: e.councilVotes[t]
														})
													]
												}, e.rid))
											})
										]
									}, t);
								})
							}),
							/* @__PURE__ */ m("section", {
								className: "okc-personal",
								children: [
									/* @__PURE__ */ m("div", {
										className: "okc-zone-tabs",
										children: [/* @__PURE__ */ p("strong", { children: T(w) }), [
											"occupying",
											"supply",
											"site",
											"discard",
											"lost",
											"burned"
										].map((e) => /* @__PURE__ */ p("button", {
											type: "button",
											"aria-pressed": ie === e,
											onClick: () => ae(e),
											children: g(J(e))
										}, e))]
									}),
									/* @__PURE__ */ m("div", {
										className: "okc-card-row",
										children: [L.map((e) => k(e)), L.length === 0 && /* @__PURE__ */ p("span", {
											className: "okc-empty",
											children: g("games.oldkingscrown.ui.empty")
										})]
									}),
									/* @__PURE__ */ p("div", {
										className: "okc-tactics",
										children: e.players.find((e) => e.rid === w)?.tactics.map((e) => {
											let t = n?.options.filter((t) => t.def === e.def) ?? [];
											return /* @__PURE__ */ m("button", {
												type: "button",
												className: t.length ? "okc-legal" : "",
												onClick: () => t.length === 1 ? E(t[0].id) : b({ def: e.def }),
												children: [/* @__PURE__ */ p("strong", { children: g(S[e.def].nameKey) }), /* @__PURE__ */ m("small", { children: [g(J(e.exhausted ? "exhausted" : "ready")), e.markers > 0 && /* @__PURE__ */ m(f, { children: [" · ", g("games.oldkingscrown.ui.uses", { n: e.markers })] })] })]
											}, e.def);
										})
									})
								]
							}),
							t && t.known.filter((t) => !e.cards.some((e) => e.uid === t.uid)).length > 0 && /* @__PURE__ */ p("div", {
								className: "okc-card-row",
								children: t.known.filter((t) => !e.cards.some((e) => e.uid === t.uid)).map((e) => k(e))
							}),
							!!t?.alliedHands.length && /* @__PURE__ */ m("section", {
								className: "okc-allied",
								children: [/* @__PURE__ */ p("h2", { children: g("games.oldkingscrown.ui.alliedHands") }), t.alliedHands.map((e) => /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("h3", { children: T(e.rid) }), /* @__PURE__ */ p("div", {
									className: "okc-card-row",
									children: e.cards.map((e) => k(e, `ally:${e.uid}`, []))
								})] }, e.rid))]
							}),
							e.sim.enabled && /* @__PURE__ */ m("section", {
								className: "okc-sim",
								children: [
									/* @__PURE__ */ m("h2", { children: [
										g(J("simulacrum")),
										" · ",
										g(J("heat")),
										" ",
										e.sim.heat
									] }),
									/* @__PURE__ */ m("div", {
										className: "okc-sim-intents",
										children: [
											/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: g(J("ambition")) }), e.sim.ambition === null ? /* @__PURE__ */ m("span", { children: [
												g(J("intentBack")),
												" · ",
												e.sim.ambitionBack === null ? "—" : g(J(Bt[e.sim.ambitionBack]))
											] }) : /* @__PURE__ */ m(f, { children: [
												/* @__PURE__ */ p("span", { children: re[e.sim.ambition].regions.map((e) => g(J(Bt[e]))).join(" → ") }),
												/* @__PURE__ */ p("span", { children: re[e.sim.ambition].suits.map((e) => g(J(e))).join(" → ") }),
												/* @__PURE__ */ m("span", { children: [
													g(J(re[e.sim.ambition].direction)),
													" · ",
													g(J(re[e.sim.ambition].steal ? "stealIntent" : "acquireIntent"))
												] })
											] })] }),
											/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: g(J("scheme")) }), e.sim.scheme === null ? /* @__PURE__ */ m("span", { children: [
												g(J("intentBack")),
												" · ",
												e.sim.schemeBack === null ? "—" : g(J(Bt[e.sim.schemeBack]))
											] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { children: dt[e.sim.scheme].regions.map((e) => g(J(Bt[e]))).join(" → ") }), /* @__PURE__ */ p("span", { children: g(J(dt[e.sim.scheme].supporters)) })] })] }),
											/* @__PURE__ */ m("span", { children: [
												g(J("deckTier")),
												" · ",
												e.sim.deckTier ? g(J(e.sim.deckTier)) : "—"
											] })
										]
									}),
									/* @__PURE__ */ m("div", {
										className: "okc-reference-effects",
										children: [e.sim.threats.map((e) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ p("summary", { children: g(Z[`threat${e}`].nameKey) }), /* @__PURE__ */ p("p", { children: g(Z[`threat${e}`].effectKey) })] }, e)), e.config.forge.map((e) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", { children: [g(Z[`forge${e.id}${e.side}`].nameKey), [4, 16].includes(e.id) && ` · X = ${e.value}`] }), /* @__PURE__ */ p("p", { children: g(Z[`forge${e.id}${e.side}`].effectKey) })] }, e.id))]
									})
								]
							}),
							!!t?.boons.length && /* @__PURE__ */ m("section", {
								className: "okc-reference-effects",
								children: [/* @__PURE__ */ p("h2", { children: g(J("boons")) }), t.boons.map((e, t) => /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ p("summary", { children: g(Z[`boon${e}`].nameKey) }), /* @__PURE__ */ p("p", { children: g(Z[`boon${e}`].effectKey) })] }, t))]
							}),
							t?.trade && /* @__PURE__ */ m("section", {
								className: "okc-trade",
								children: [/* @__PURE__ */ p("h2", { children: g(J("barterReview")) }), [[t.trade.a, t.trade.give], [t.trade.b, t.trade.take]].map(([e, t]) => /* @__PURE__ */ m("article", { children: [/* @__PURE__ */ p("h3", { children: T(String(e)) }), /* @__PURE__ */ p("ul", { children: t.map((e, t) => /* @__PURE__ */ m("li", { children: [
									g(J(`trade:${e.kind}`)),
									" · ",
									e.n,
									e.def && ` · ${g(S[e.def].nameKey)}`,
									e.index !== void 0 && ` · ${F(e.kind, e.index)}`
								] }, t)) })] }, String(e)))]
							})
						]
					})]
				}), /* @__PURE__ */ m("div", {
					className: "okc-dock",
					children: [/* @__PURE__ */ m(Rt, {
						name: `hand:${r}`,
						className: "okc-hand",
						children: [/* @__PURE__ */ m("h2", { children: [
							g("games.oldkingscrown.ui.hand"),
							" ",
							/* @__PURE__ */ m("small", { children: [
								t?.hand.length ?? 0,
								"／",
								de?.handSize ?? 0
							] })
						] }), /* @__PURE__ */ p("div", {
							className: "okc-card-row",
							children: t?.hand.map((e) => k(e))
						})]
					}), n && (P.length > 0 || n.allowText || x || n.source || n.subject) && /* @__PURE__ */ m("section", {
						className: "okc-decision",
						children: [
							/* @__PURE__ */ m("h2", { children: [g(J(n.kind)), x && /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => C(null),
								children: g("games.oldkingscrown.ui.back")
							})] }),
							n.subject && /* @__PURE__ */ p("p", { children: g(J("pendingSubject"), { name: T(n.subject) }) }),
							n.source && /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => b({ def: n.source }),
								children: g(S[n.source].nameKey)
							}),
							n.allowText && /* @__PURE__ */ m("label", { children: [g("games.oldkingscrown.ui.agreementText"), /* @__PURE__ */ p("textarea", {
								maxLength: 1e3,
								value: te,
								onChange: (e) => ne(e.target.value),
								placeholder: g("games.oldkingscrown.ui.agreementHint")
							})] }),
							/* @__PURE__ */ p("div", {
								className: "okc-choice-list",
								children: P.map((e) => /* @__PURE__ */ m("button", {
									type: "button",
									"aria-pressed": v.includes(e.id),
									className: `okc-choice okc-legal${v.includes(e.id) ? " okc-selected" : ""}`,
									onClick: () => E(e.id),
									children: [
										e.def && /* @__PURE__ */ p(It, {
											def: e.def,
											compact: !0
										}),
										/* @__PURE__ */ p("span", { children: me(e) }),
										v.includes(e.id) && /* @__PURE__ */ p("b", { children: v.indexOf(e.id) + 1 })
									]
								}, e.id))
							})
						]
					})]
				})]
			}),
			y && /* @__PURE__ */ m(zt, {
				className: "okc-detail",
				label: g(J("details")),
				close: () => b(null),
				children: [
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "okc-modal-close",
						onClick: () => b(null),
						children: g("games.oldkingscrown.ui.close")
					}),
					/* @__PURE__ */ p(It, {
						def: y.def,
						card: y.card
					}),
					/* @__PURE__ */ m("div", { children: [
						/* @__PURE__ */ p("h2", { children: g(S[y.def].nameKey) }),
						/* @__PURE__ */ p("p", { children: g(S[y.def].effectKey) }),
						y.card?.boons.map((e, t) => e !== null && Z[`boon${e}`] ? /* @__PURE__ */ m("p", { children: [
							g(J("boonOnCard")),
							" · ",
							g(Z[`boon${e}`].nameKey),
							/* @__PURE__ */ p("br", {}),
							g(Z[`boon${e}`].effectKey)
						] }, `boon${t}`) : null),
						y.card?.copy && /* @__PURE__ */ m("p", { children: [
							g("games.oldkingscrown.ui.copied"),
							" · ",
							g(S[y.card.copy].nameKey),
							/* @__PURE__ */ p("br", {}),
							g(S[y.card.copy].effectKey)
						] }),
						y.card?.gainedRules.map((e) => /* @__PURE__ */ m("p", { children: [
							g("games.oldkingscrown.ui.gained"),
							" · ",
							g(S[e].nameKey),
							/* @__PURE__ */ p("br", {}),
							g(S[e].effectKey)
						] }, e)),
						(y.card?.commands ?? S[y.def].commands ?? []).map((e) => /* @__PURE__ */ p("p", { children: g(J(e)) }, e))
					] })
				]
			}),
			le && /* @__PURE__ */ m(zt, {
				label: g(J(le)),
				close: () => ue(null),
				children: [
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "okc-modal-close",
						onClick: () => ue(null),
						children: g("games.oldkingscrown.ui.close")
					}),
					/* @__PURE__ */ p("h2", { children: g(J(le)) }),
					le === "reference" ? /* @__PURE__ */ p(Lt, {}) : le === "log" ? /* @__PURE__ */ p("ol", { children: e.log.map((e, t) => /* @__PURE__ */ m("li", { children: [
						e.actor && T(e.actor),
						" · ",
						g(J(e.key)),
						e.card && S[e.card] ? ` · ${g(S[e.card].nameKey)}` : "",
						e.n === void 0 ? "" : ` · ${e.n}`,
						e.target ? ` · ${T(e.target)}` : ""
					] }, t)) }) : /* @__PURE__ */ p("div", {
						className: "okc-agreements",
						children: e.agreements.map((n) => /* @__PURE__ */ m("article", { children: [
							/* @__PURE__ */ m("strong", { children: [
								T(n.a),
								" ↔ ",
								T(n.b)
							] }),
							/* @__PURE__ */ p("p", { children: n.text }),
							/* @__PURE__ */ p("small", { children: n.status === "active" ? g("games.oldkingscrown.ui.agreementActive") : g(J(n.status)) }),
							n.status === "active" && [n.a, n.b].includes(r) && !h && !e.done && /* @__PURE__ */ m("div", { children: [
								n.alliance && /* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => l({
										type: "allianceHand",
										target: n.a === r ? n.b : n.a,
										show: !t?.sharingWith.includes(n.a === r ? n.b : n.a)
									}),
									children: g(J(t?.sharingWith.includes(n.a === r ? n.b : n.a) ? "hideHand" : "shareHand"))
								}),
								["fulfilled", "cancelled"].map((e) => /* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => l({
										type: "agreementRequest",
										id: n.id,
										mode: e
									}),
									children: g(J(e))
								}, e)),
								n.binding && /* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => l({
										type: "agreementRequest",
										id: n.id,
										mode: "breach",
										target: n.a === r ? n.b : n.a
									}),
									children: g("games.oldkingscrown.ui.breach")
								})
							] })
						] }, n.id))
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/oldkingscrown/bot.ts
var Kt = {
	strength: .9,
	influence: 1.5,
	lore: 3.6,
	council: 4.2,
	economy: .6,
	reserve: .175,
	kingdom: 1.75,
	risk: .35
};
function qt(e) {
	let t = 4294967296 - 4294967296 % e.length, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return e[n % e.length];
}
var Jt = /* @__PURE__ */ new Set([
	175e3,
	175004,
	175007,
	175011,
	175013,
	175014,
	175016,
	175017,
	175024,
	175026,
	175032,
	175035,
	175036,
	175038,
	175041,
	175705,
	175708
]);
function Yt(e, t, n) {
	let r = t === void 0 ? void 0 : S[t];
	return (e?.strength ?? r?.strength ?? 0) * n.strength + (e?.votes ?? r?.votes ?? 0) * n.council + (e?.lore ?? r?.lore ?? 0) * n.lore + (e?.traits ?? r?.traits ?? []).length * .8 + (e?.commands ?? r?.commands ?? []).length * .8;
}
function Xt(e, t, n, r, i, a = Kt) {
	let o = e.players.find((e) => e.rid === n), s = [
		...t.hand,
		...t.known,
		...e.cards
	], c = i.card ? s.find((e) => e.uid === i.card) : void 0, l = S[i.def ?? c?.def ?? -1], u = Yt(c, l?.id, a), d = e.year / e.years;
	if (r.kind === "rearrangeCouncils") return -1;
	let f = i.region ?? e.region ?? 0, p = e.cards.filter((e) => e.owner === n && e.zone === "active" && e.region === f && !e.fought), m = e.players.filter((e) => e.rid !== n), h = Math.max(0, ...m.map((t) => e.cards.filter((e) => e.owner === t.rid && e.zone === "active" && e.region === f && e.faceUp && !e.fought).reduce((e, t) => e + t.strength, e.clash > 1 ? 0 : t.supporters[f]))), g = p.reduce((e, t) => e + t.strength, e.clash > 1 ? 0 : o.supporters[f]);
	if (r.kind === "tieCard" && c?.fought) return -100;
	let _ = (t, n) => e.players.find((e) => e.rid === n).councilVotes[t], v = (t) => {
		let r = o.heralds.some((e) => e !== null && Math.floor(e / 2) === t);
		return Number(r) * 3 + +!!o.supporters[t] - e.cards.filter((e) => e.zone === "active" && e.owner === n && e.region === t).length;
	};
	if ([
		"bid",
		"allyBid",
		"tourney"
	].includes(r.kind)) return (l?.strength ?? 0) * 1.4 - u * .3 + Number(l?.archetype === "ruse") * -3;
	if ([
		"placeCard",
		"tieCard",
		"allyDeploy",
		"deploy",
		"ambush"
	].includes(r.kind)) {
		let e = c?.strength ?? l?.strength ?? 0;
		return e * (.55 + v(f) * .08) + (h >= g && h < g + e ? a.influence : 0) + Number(l?.traits?.includes("invulnerable")) + Number(l?.archetype === "agent") * (h > 0 ? 1 : -1) - (c?.votes ?? 0) * d * .15;
	}
	if ([
		"resolveBid",
		"roadAcquire",
		"moonshineRoad",
		"townAcquire",
		"relics",
		"startingKingdom"
	].includes(r.kind)) return i.label === "returnBid" ? t.hand.length < 3 ? 3 : 0 : a.kingdom + (Jt.has(l?.id ?? -1) ? a.economy * (2 - d) : 0) + Number(i.label === "steal") * 2 + u * .08 - Number(i.label === "startingKingdomGuard") * Yt(c, c?.def ?? void 0, a) * .15;
	if (["occupy", "startingGuard"].includes(r.kind)) return 8 - u * .55 + (l?.strength ?? 0) * .15;
	if (r.kind === "occupySlot") return i.label === "emptySlot" ? 20 : Jt.has(i.def ?? -1) ? -2 : 1;
	if (["buySite", "beacon"].includes(r.kind)) return a.economy * (2.3 - d) + u - (l?.cost ?? 0) * .3 + Number(l?.kind === "hq") * a.economy;
	if ([
		"discardHand",
		"discardCouncil",
		"burn",
		"burnCard",
		"agentTarget",
		"eliminate",
		"protectBatch",
		"witchTrial",
		"martialLaw"
	].includes(r.kind)) return c?.owner === n || r.kind.startsWith("discard") ? 15 - u : u;
	if ([
		"govern",
		"governChoose",
		"boonGovernJourney"
	].includes(r.kind) && l) return (c?.votes ?? l.votes ?? 0) * a.council * (1.3 + d) - (c?.strength ?? l.strength ?? 0) * a.reserve * .3;
	if (["journey", "journeyChoose"].includes(r.kind) && l) return (c?.lore ?? l.lore ?? 0) * a.lore + Number(c?.traits.includes("pathfinder") ?? l.traits?.includes("pathfinder")) * 2 - u * .2;
	if (r.kind === "council") {
		let e = i.suit ?? 0, t = _(e, n), r = Math.max(0, ...m.map((t) => _(e, t.rid)));
		return (e === 0 ? a.influence : e === 1 ? a.economy : 1.2) + (t <= r && t + (c?.votes ?? 1) > r ? 3 : 0) - t * .25;
	}
	if ([
		"placeSupporters",
		"clansSupporters",
		"harbour",
		"region"
	].includes(r.kind)) return 2 + v(f) + Number(h >= g && h < g + 1) * 2;
	if ([
		"herald",
		"sirenLocation",
		"location",
		"reward",
		"secretLocation",
		"secretReward",
		"visit"
	].includes(r.kind)) {
		let t = i.location ?? 0, n = e.modules.locations[t], r = [
			a.influence + a.council * 2,
			a.influence + a.lore * 2,
			a.influence + 1,
			a.influence * 2,
			a.influence + a.economy,
			a.influence + a.economy * 2
		], s = Math.floor(t / 2);
		return r[n] + (n === 3 && d > .7 ? 3 : 0) + v(s) + (n === 5 && o.handCount >= o.handSize ? -3 : 0);
	}
	return r.kind === "negotiate" ? i.label === "finishNegotiation" ? 10 : -1 : r.kind === "barterInvitation" || r.kind === "barterReview" ? i.label === "decline" ? 10 : -1 : r.kind === "tradeCompose" ? i.id === "cancel" ? 10 : -1 : r.kind === "mulligan" ? i.id === "keep" ? t.hand.reduce((e, t) => e + t.strength, 0) >= 19 ? 2 : -2 : 0 : [
		"rally",
		"rallyChoose",
		"recoverCouncil",
		"recoverEliminated",
		"returnHand",
		"boatmanLost",
		"lanternHand"
	].includes(r.kind) && l ? u + 3 : r.kind === "retreatPieces" ? i.label === "card" ? 10 - u : 5 : i.label === "pass" || i.label === "decline" ? -1 : i.label === "allowElimination" ? -2 : i.label === "influence" || i.label === "discardForInfluence" ? a.influence * (i.n ?? 1) : i.label === "lore" ? a.lore * (i.n ?? 1) * (d > .8 ? .5 : 1) : i.label === "journey" || i.label === "govern" ? 5 : i.label === "secrets" || i.label === "oaths" || i.label === "supporters" ? 4 : i.label === "retreat" || i.label === "flank" ? g > h ? -.4 : 2 : i.label === "ambush" ? g <= h ? 3 : -.5 : i.label === "activateTactic" ? e.phase === "summer" && g <= h ? 1 : -.2 : i.label === "count" || i.label === "supporterCount" ? i.n ?? 0 : i.label === "region" ? v(f) : i.label === "favour" ? 2 : 1 + (i.weight ?? 0) + (c && c.owner !== n ? u * .2 : 0);
}
function Zt(e, t, n, r = Kt) {
	let i = t.prompts[0];
	if (!i || e.done) return null;
	let a = i.options.map((a, o) => ({
		o: a,
		i: o,
		score: Xt(e, t, n, i, a, r)
	})).sort((e, t) => t.score - e.score || e.i - t.i), o = Math.min(i.min, a.length), s = a.filter((e, t) => t < o || t < i.max && e.score > 0);
	return {
		type: "choose",
		prompt: i.id,
		options: s.slice(0, i.max).map((e) => e.o.id)
	};
}
var Qt = (e, t) => {
	let n = e.private, r = n?.prompts[0];
	if (!r || !n || e.public.done) return null;
	if (t.difficulty === "weak") {
		let e = [...r.options], t = [], n = r.min === 0 ? qt([0, 1]) : r.min;
		for (; t.length < Math.min(r.max, n, r.options.length);) {
			let n = qt(e);
			t.push(n.id), e.splice(e.indexOf(n), 1);
		}
		return { action: {
			type: "choose",
			prompt: r.id,
			options: t
		} };
	}
	let i = Zt(e.public, n, t.rid);
	return i ? { action: i } : null;
}, $t = (e, t, n) => {
	if (e.type !== "choose") return "";
	let r = t.private?.prompts.find((t) => t.id === e.prompt);
	return e.options.map((e) => {
		let t = r?.options.find((t) => t.id === e);
		return t ? [
			n(J(t.label)),
			t.def ? n(S[t.def].nameKey) : "",
			t.n === void 0 ? "" : String(t.n)
		].filter(Boolean).join(" · ") : "";
	}).join("；") || n("games.oldkingscrown.ui.skip");
}, en = (e) => e.data ?? {};
function $(e, t, n) {
	return e.anchor(t) ?? (n ? e.anchor(`seat:${n}`) : null);
}
function tn(e, t = 92) {
	return {
		x: e.x + e.w / 2 - t / 2,
		y: e.y + e.h / 2 - t * .75,
		w: t,
		h: t * 1.5
	};
}
function nn({ def: e, box: t, ms: n }) {
	let a = i(null);
	return r(() => {
		let e = a.current?.animate([{ transform: "rotateY(-90deg)" }, { transform: "rotateY(0deg)" }], {
			duration: n,
			easing: "cubic-bezier(.2,.65,.25,1)",
			fill: "both"
		});
		return () => e?.cancel();
	}, [n]), /* @__PURE__ */ p("div", {
		ref: a,
		className: "okc-fx-card",
		style: {
			position: "absolute",
			left: t.x,
			top: t.y,
			width: t.w,
			height: t.h
		},
		children: /* @__PURE__ */ p(It, {
			def: e,
			compact: !0
		})
	});
}
function rn({ value: e, n: t, name: n }) {
	let r = c();
	return /* @__PURE__ */ m("span", {
		className: "okc-fx-caption",
		children: [
			n && /* @__PURE__ */ m("span", { children: [n, " · "] }),
			r(J(e)),
			t !== void 0 && ` ${t > 0 ? "+" : ""}${t}`
		]
	});
}
function an({ n: e }) {
	let t = c();
	return /* @__PURE__ */ p("span", {
		className: "okc-fx-caption",
		children: t(e === void 0 ? J("boon") : Z[`boon${e}`].nameKey)
	});
}
var on = (e, t) => {
	let n = en(e), r = $(t, typeof n.uid == "string" ? `card:${n.uid}` : `seat:${e.rid}`, e.rid);
	if (!r) return null;
	let i = Math.min(E.move, t.queued ? 240 : 500);
	return {
		ms: i,
		node: /* @__PURE__ */ p(h, {
			at: r,
			ms: i,
			children: /* @__PURE__ */ p("span", {
				className: "okc-fx-caption",
				children: /* @__PURE__ */ p(X, {
					name: e.kind === "cardInfluence" ? "influence" : e.kind,
					value: typeof n.n == "number" ? `${n.n > 0 ? "+" : ""}${n.n}` : void 0
				})
			})
		})
	};
}, sn = (e, t) => {
	let n = en(e), r = Number(n.location), i = Number(n.region), a = typeof n.from == "string" ? n.from : e.kind === "supporter" && (n.to !== void 0 || n.mode === "recallMap") ? `region:${i}` : `seat:${e.rid}`, o = typeof n.to == "string" ? n.to : e.kind === "supporter" ? typeof n.to == "number" ? n.to >= 0 ? `region:${n.to}` : `seat:${e.rid}` : n.mode === "recallMap" || n.mode === "recallLost" ? `seat:${e.rid}` : `region:${i}` : e.kind === "councilMarker" ? `council:${n.suit}` : e.kind === "airship" ? `region:${i}` : r >= 0 ? `location:${r}` : `seat:${e.rid}`, s = $(t, a, e.rid), c = $(t, o, e.rid);
	if (!s || !c) return null;
	let l = tn(s, 34), u = tn(c, 34), d = t.queued ? 240 : E.move;
	return {
		ms: d,
		node: /* @__PURE__ */ p(g, {
			from: l,
			to: u,
			ms: d,
			children: /* @__PURE__ */ p(Y, {
				kind: e.kind,
				faction: typeof n.faction == "string" ? n.faction : void 0,
				n: typeof n.n == "number" ? n.n : void 0
			})
		})
	};
}, cn = {
	move(e, t) {
		let n = en(e), r = e.rid, i = r === t.myRid, a = e.secret, o = i && a?.uid ? a.uid : n.uid, s = $(t, String(n.from), String(n.from).split(":").at(-1)), c = typeof o == "string" && t.anchor(`card:${o}`) ? `card:${o}` : String(n.to), l = $(t, c, r);
		if (!s || !l) return null;
		let u = i && a?.def !== void 0 ? a.def : typeof n.def == "number" ? n.def : void 0, d = c.startsWith("card:"), f = d ? l : tn(l), m = tn(s, f.w), h = t.queued ? 240 : E.move, _ = n.faceDown !== !0 || i;
		return {
			ms: h,
			node: /* @__PURE__ */ p(g, {
				from: m,
				to: f,
				ms: h,
				children: /* @__PURE__ */ p("div", {
					className: "okc-fx-card",
					style: {
						width: m.w,
						height: m.h
					},
					children: /* @__PURE__ */ p(It, {
						def: _ ? u : null,
						compact: !0,
						back: !_ || u === void 0,
						backFaction: typeof n.back == "string" ? n.back : void 0
					})
				})
			}),
			hide: !t.queued && d ? [c] : []
		};
	},
	reveal(e, t) {
		let n = en(e), r = `card:${n.uid}`, i = t.anchor(r);
		if (!i || typeof n.def != "number") return null;
		let a = t.queued ? 250 : E.reveal;
		return {
			ms: a,
			node: /* @__PURE__ */ p(nn, {
				def: n.def,
				box: i,
				ms: a
			}),
			hide: t.queued ? [] : [r]
		};
	},
	revealBids(e, t) {
		let n = t.anchor("bids") ?? $(t, "road", e.rid);
		return n ? {
			ms: E.reveal,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: E.reveal
			})
		} : null;
	},
	influence: on,
	lore: on,
	handSize: on,
	cardInfluence: on,
	boon(e, t) {
		let n = en(e), r = e.secret, i = $(t, String(n.from), e.rid), a = $(t, String(n.to), e.rid), o = e.rid === t.myRid ? r?.n ?? (typeof n.n == "number" ? n.n : void 0) : typeof n.n == "number" ? n.n : void 0;
		return i && a ? {
			ms: E.move,
			node: /* @__PURE__ */ p(g, {
				from: tn(i, 60),
				to: tn(a, 60),
				ms: E.move,
				children: /* @__PURE__ */ p(an, { n: o })
			})
		} : null;
	},
	tactic(e, t) {
		let n = en(e), r = $(t, `tactic:${n.def}`, e.rid);
		return r ? {
			ms: E.reveal,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: E.reveal,
				children: /* @__PURE__ */ p(rn, { value: n.exhausted ? "exhausted" : "ready" })
			})
		} : null;
	},
	supporter: sn,
	herald: sn,
	marker: sn,
	councilMarker: sn,
	airship: sn,
	tower: sn,
	favour(e, t) {
		let n = $(t, `seat:${e.rid}`);
		return n ? {
			ms: E.move,
			node: /* @__PURE__ */ p(h, {
				at: n,
				ms: E.move,
				children: /* @__PURE__ */ p(rn, { value: "favour" })
			})
		} : null;
	},
	road(e, t) {
		let n = t.anchor("road");
		return n ? {
			ms: E.move,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: E.move
			})
		} : null;
	},
	kingdomDiscard(e, t) {
		let n = en(e), r = $(t, `occupying:${e.rid}`, e.rid), i = t.anchor("road");
		return r && i && typeof n.def == "number" ? {
			ms: E.move,
			node: /* @__PURE__ */ p(g, {
				from: tn(r),
				to: tn(i),
				ms: E.move,
				children: /* @__PURE__ */ p("div", {
					className: "okc-fx-card",
					style: { width: 92 },
					children: /* @__PURE__ */ p(It, {
						def: n.def,
						compact: !0
					})
				})
			})
		} : null;
	},
	outcome(e, t) {
		let n = en(e), r = t.anchor(`region:${n.region}`);
		return r ? {
			ms: E.outcome,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: E.outcome,
				children: /* @__PURE__ */ p(rn, {
					value: "outcome",
					n: typeof n.strength == "number" ? n.strength : void 0,
					name: t.member(e.rid ?? "")?.name
				})
			})
		} : null;
	},
	season(e, t) {
		let n = en(e), r = t.anchor("road");
		return r ? {
			ms: E.season,
			node: /* @__PURE__ */ p(h, {
				at: r,
				ms: E.season,
				children: /* @__PURE__ */ p(rn, { value: String(n.phase) })
			})
		} : null;
	},
	barter(e, t) {
		let n = en(e), r = $(t, `seat:${e.rid}`), i = $(t, `seat:${n.target}`);
		return r && i ? {
			ms: E.move,
			node: /* @__PURE__ */ p(g, {
				from: tn(r, 40),
				to: tn(i, 40),
				ms: E.move,
				children: /* @__PURE__ */ p(rn, {
					value: String(n.resource),
					n: typeof n.n == "number" ? n.n : void 0
				})
			})
		} : null;
	},
	eliminate: () => null
};
//#endregion
//#region src/games/oldkingscrown/game-over.tsx
function ln({ public: e, private: t, result: n, members: r, myRid: i, hintCount: l, onPlayAgain: u, onBackToLobby: h }) {
	let g = e, _ = c(), v = s((e) => e.locale), [ee, te] = a(!0), [ne, y] = a(null), b = (e) => e === "$simulacrum" ? _(J("simulacrum")) : r.some((t) => t.rid === e) ? d(r.find((t) => t.rid === e), v) : e, x = g.config.simulacrum === "cooperative", S = g.winner.includes("$simulacrum"), re = x ? _(J(S ? "resultCoopLoss" : "resultCoopWin")) : S ? _(J("resultSimWin")) : _("games.oldkingscrown.ui.resultWin", { name: g.winner.map(b).join("、") }), C = g.order.map((e) => g.players.find((t) => t.rid === e));
	return /* @__PURE__ */ m("div", {
		className: "okc-over",
		children: [
			/* @__PURE__ */ p("div", {
				inert: ee,
				style: { height: "100%" },
				children: /* @__PURE__ */ p(Wt, {
					public: g,
					private: t,
					members: r,
					myRid: i,
					send: () => void 0,
					readOnly: !0
				})
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: "okc-result-restore",
				onClick: () => te(!0),
				children: _(J("showResult"))
			}),
			ee && /* @__PURE__ */ p("div", {
				className: "okc-over-shade",
				children: /* @__PURE__ */ m("section", {
					className: "okc-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": _(J("resultTitle")),
					children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							className: "okc-modal-close",
							onClick: () => {
								te(!1), y(null);
							},
							children: _(J("reviewBoard"))
						}),
						/* @__PURE__ */ m("div", {
							className: "okc-result-body",
							children: [
								/* @__PURE__ */ p("img", {
									className: "okc-result-crown",
									src: o("games/oldkingscrown/live/icon-heir.svg"),
									alt: ""
								}),
								/* @__PURE__ */ p("h1", { children: _(J("resultTitle")) }),
								/* @__PURE__ */ p("p", {
									className: "okc-result-lead",
									children: re
								}),
								/* @__PURE__ */ m("table", { children: [/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: _(J("finalYear"), { n: g.year }) }), C.map((e) => /* @__PURE__ */ m("th", {
									className: g.winner.includes(e.rid) ? "okc-winner" : "",
									children: [
										b(e.rid),
										/* @__PURE__ */ p("br", {}),
										/* @__PURE__ */ p("small", { children: _(J(e.faction)) })
									]
								}, e.rid))] }) }), /* @__PURE__ */ m("tbody", { children: [
									/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("td", { children: _(J("resultTotal")) }), C.map((e) => /* @__PURE__ */ p("td", {
										className: g.winner.includes(e.rid) ? "okc-winner" : "",
										children: g.scores[e.rid]
									}, e.rid))] }),
									/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("td", { children: _(J("favour")) }), C.map((e) => /* @__PURE__ */ p("td", { children: g.favour.owner === e.rid ? /* @__PURE__ */ p(X, { name: "herald" }) : "—" }, e.rid))] }),
									/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("td", { children: _(J("orderTrack")) }), C.map((e, t) => /* @__PURE__ */ p("td", { children: t + 1 }, e.rid))] })
								] })] }),
								l !== void 0 && /* @__PURE__ */ p("p", {
									className: "okc-result-lead",
									children: _("games.oldkingscrown.ui.hintCount", { n: l })
								}),
								C.filter((e) => (n.autopilot?.[e.rid] ?? 0) > 0).map((e) => /* @__PURE__ */ m("p", { children: [
									b(e.rid),
									" · ",
									_("session.autopilot.share", { n: Math.round(n.autopilot[e.rid] * 100) })
								] }, e.rid))
							]
						}),
						/* @__PURE__ */ p("div", {
							className: "okc-result-actions",
							children: ne ? /* @__PURE__ */ m(f, { children: [
								/* @__PURE__ */ p("p", { children: _(J(ne === "again" ? "playAgainConfirm" : "exitConfirm")) }),
								/* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => ne === "again" ? u?.() : h?.(),
									children: _(J("confirm"))
								}),
								/* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => y(null),
									children: _(J("cancel"))
								})
							] }) : u || h ? /* @__PURE__ */ m(f, { children: [u && /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => y("again"),
								children: _(J("playAgain"))
							}), h && /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => y("exit"),
								children: _(J("backToLobby"))
							})] }) : /* @__PURE__ */ p("p", { children: _(J("resultWaiting")) })
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/oldkingscrown/options.tsx
function un({ value: e, onChange: t }) {
	let n = c(), r = Ze.safeParse(e), i = r.success ? r.data : Ze.parse(void 0), a = (e) => t({
		...i,
		...e
	}), o = (e, t) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t], s = x.filter((e) => e.kind === "wild");
	return /* @__PURE__ */ m("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ p(te, {
				title: n(J("yearOption")),
				columns: 3,
				children: [
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ p(ee, {
					name: "okc-years",
					value: String(e),
					checked: i.years === e,
					label: n(J(`years${e}`)),
					onChange: () => a({ years: e })
				}, e))
			}),
			/* @__PURE__ */ p(ne, {
				label: n(J("advancedSetup")),
				hint: n(J("advancedHint")),
				checked: i.advancedSetup,
				onChange: () => a({ advancedSetup: !i.advancedSetup })
			}),
			/* @__PURE__ */ p(te, {
				title: n(J("factionOption")),
				children: [
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ m("label", {
					className: "grid gap-1 text-sm",
					children: [/* @__PURE__ */ p("span", { children: n(J("seat"), { n: e + 1 }) }), /* @__PURE__ */ p("select", {
						className: "w-full rounded border-2 border-ink/30 bg-surface p-2",
						value: i.factions[e] ?? "random",
						onChange: (t) => {
							let n = [...i.factions];
							for (; n.length < 4;) n.push("random");
							n[e] = t.target.value, a({ factions: n });
						},
						children: ["random", ...y].map((e) => /* @__PURE__ */ p("option", {
							value: e,
							children: n(J(e))
						}, e))
					})]
				}, e))
			}),
			/* @__PURE__ */ p(te, {
				title: n(J("simMode")),
				children: [
					"auto",
					"off",
					"competitive",
					"cooperative"
				].map((e) => /* @__PURE__ */ p(ee, {
					name: "okc-sim",
					value: e,
					checked: i.simulacrum === e,
					label: n(J(e)),
					onChange: () => a({
						simulacrum: e,
						...e === "cooperative" ? { negotiating: !1 } : {}
					})
				}, e))
			}),
			/* @__PURE__ */ p("p", {
				className: "text-xs text-ink/65",
				children: n(J("simHint"))
			}),
			i.simulacrum !== "off" && /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", {
					className: "cursor-pointer font-bold",
					children: [
						n(J("forgeOption")),
						" · ",
						i.forge.length
					]
				}), /* @__PURE__ */ p("div", {
					className: "mt-3 space-y-3",
					children: Array.from({ length: 30 }, (e, t) => t + 1).map((e) => {
						let t = i.forge.find((t) => t.id === e), r = (n) => a({ forge: [...i.forge.filter((t) => t.id !== e), {
							id: e,
							side: n,
							value: e === 16 && n === "b" ? Math.min(t?.value ?? 1, 4) : t?.value ?? 1
						}] });
						return /* @__PURE__ */ m("fieldset", {
							className: "rounded border border-ink/25 p-2",
							children: [
								/* @__PURE__ */ m("legend", {
									className: "px-1 font-mono text-xs",
									children: ["F", e]
								}),
								/* @__PURE__ */ p("div", {
									className: "grid grid-cols-2 gap-2",
									children: ["a", "b"].map((i) => {
										let a = Z[`forge${e}${i}`];
										return /* @__PURE__ */ p(ee, {
											name: `okc-forge-${e}`,
											value: i,
											checked: t?.side === i,
											label: `${i.toUpperCase()} · ${n(a.nameKey)}`,
											hint: n(a.effectKey),
											onChange: () => r(i)
										}, i);
									})
								}),
								/* @__PURE__ */ m("div", {
									className: "mt-2 flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ p("button", {
										type: "button",
										className: "rounded border border-ink/30 px-3 py-1 text-xs",
										disabled: !t,
										onClick: () => a({ forge: i.forge.filter((t) => t.id !== e) }),
										children: n(J("none"))
									}), t && [4, 16].includes(e) && /* @__PURE__ */ m("label", {
										className: "text-sm",
										children: ["X ", /* @__PURE__ */ p("input", {
											className: "w-16 rounded border border-ink/30 bg-surface p-1",
											type: "number",
											min: 0,
											max: e === 16 && t.side === "b" ? 4 : 20,
											value: t.value,
											onChange: (n) => {
												let r = Number(n.target.value);
												Number.isInteger(r) && r >= 0 && r <= (e === 16 && t.side === "b" ? 4 : 20) && a({ forge: i.forge.map((t) => t.id === e ? {
													...t,
													value: r
												} : t) });
											}
										})]
									})]
								})
							]
						}, e);
					})
				})] }),
				/* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", {
					className: "cursor-pointer font-bold",
					children: [
						n(J("threatOption")),
						" · ",
						i.threats.length
					]
				}), /* @__PURE__ */ p("div", {
					className: "mt-3 grid grid-cols-1 gap-2",
					children: Array.from({ length: 24 }, (e, t) => t + 1).map((e) => {
						let t = Z[`threat${e}`];
						return /* @__PURE__ */ p(v, {
							name: "okc-threat",
							value: String(e),
							checked: i.threats.includes(e),
							label: `${e} · ${n(t.nameKey)}`,
							hint: n(t.effectKey),
							onChange: () => a({ threats: o(i.threats, e) })
						}, e);
					})
				})] }),
				/* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", {
					className: "cursor-pointer font-bold",
					children: [
						n(J("advancedSimOption")),
						" · ",
						i.simAdvanced.length
					]
				}), /* @__PURE__ */ p("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: x.filter((e) => e.kind === "simulacrum" && e.advanced).flatMap((e) => Array.from({ length: e.count ?? 1 }, () => e)).map((e, t) => /* @__PURE__ */ p(v, {
						name: "okc-sim-advanced",
						value: String(t),
						checked: i.simAdvanced.includes(t),
						label: n(e.nameKey),
						hint: n(e.effectKey),
						onChange: () => a({ simAdvanced: o(i.simAdvanced, t) })
					}, t))
				})] })
			] }),
			/* @__PURE__ */ p(te, {
				title: n(J("modules")),
				children: [
					"aeronauts",
					"creatures",
					"negotiating",
					"nightMap",
					"town",
					"tower"
				].map((e) => /* @__PURE__ */ p(v, {
					name: "okc-modules",
					value: e,
					checked: i[e],
					disabled: e === "negotiating" && i.simulacrum === "cooperative",
					label: n(J(e)),
					onChange: () => a({ [e]: !i[e] })
				}, e))
			}),
			/* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", {
				className: "cursor-pointer font-bold",
				children: [
					n(J("wildCards")),
					" · ",
					i.wild.length
				]
			}), /* @__PURE__ */ p("div", {
				className: "mt-3 grid grid-cols-1 gap-2",
				children: s.map((e, t) => /* @__PURE__ */ p(v, {
					name: "okc-wild",
					value: String(t),
					checked: i.wild.includes(t),
					label: n(e.nameKey),
					hint: n(e.effectKey),
					onChange: () => a({ wild: o(i.wild, t) })
				}, e.id))
			})] })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/oldkingscrown/entry.tsx
var dn = {
	definition: Mt,
	View: Wt,
	bot: Qt,
	describe: $t,
	fx: cn,
	OverView: ln,
	Options: un,
	Guide: Lt,
	locales: {
		zh: {
			cards: {
				n174000: "诡计！",
				n174001: "黎明商人公会",
				n174002: "城墙守望者",
				n174003: "狩猎队",
				n174004: "什一税",
				n174005: "城门守卫",
				n174006: "药瓶教派",
				n174007: "牧场骑士",
				n174008: "悲厄",
				n174009: "档案总管",
				n174010: "伯爵",
				n174011: "执政官",
				n174012: "军械总管",
				n174013: "晨昏之子提图斯",
				n174400: "诡计！",
				n174401: "司库",
				n174402: "雪花莲斥候",
				n174403: "鱼篓搬运者",
				n174404: "群峰女祭司",
				n174405: "破浪者",
				n174406: "匿形之刃",
				n174407: "奔岸雪橇",
				n174408: "波上殿堂",
				n174409: "草原伯劳",
				n174410: "烙印先知",
				n174411: "勒忒",
				n174412: "戈尔",
				n174413: "统一者萨迦",
				n174300: "诡计！",
				n174301: "销赃人",
				n174302: "秘密邮政",
				n174303: "非正规军",
				n174304: "叫卖者",
				n174305: "哨兵",
				n174306: "夜间狂欢",
				n174307: "扑翼机俱乐部",
				n174308: "实验学院",
				n174309: "图书管理员",
				n174310: "大力士",
				n174311: "乌贼男爵",
				n174312: "咒月船长",
				n174313: "秘密结社",
				n177400: "诡计！",
				n177401: "夜鹰",
				n177402: "偶像",
				n177403: "林间言者",
				n177404: "流浪的失落者",
				n177405: "月刺者",
				n177406: "梦之教团",
				n177407: "奔行者",
				n177408: "燃烧之林",
				n177409: "猫头鹰",
				n177410: "山羊",
				n177411: "狐狸",
				n177412: "雄鹿",
				n177413: "无面者佩特里科",
				n174014: "总督",
				n174015: "高等法庭",
				n174016: "昔日女王",
				n174017: "镀金之墙",
				n174414: "说书人",
				n174415: "劫掠与焚毁",
				n174416: "北天骑手",
				n174314: "首席煽动者",
				n174315: "火药阴谋",
				n174316: "游击战士",
				n177414: "制面者",
				n177415: "传言者",
				n177416: "牙齿仪式",
				n177417: "眼睛仪式",
				n176700: "皇家银行",
				n177000: "新港湾",
				n177100: "流动使馆",
				n176800: "月光湾",
				n176900: "辛迪加",
				n177200: "夜之门",
				n175000: "冒险队",
				n175001: "纪念碑建造者",
				n175002: "锡制王冠",
				n175003: "神秘资助者",
				n175004: "白色瞭望塔",
				n175005: "遗忘的宫殿",
				n175006: "信标",
				n175007: "无尽图书馆",
				n175008: "胆壮的匪徒",
				n175009: "午夜宫廷",
				n175010: "商人公会",
				n175011: "闪耀洞穴",
				n175012: "偏远山屋",
				n175013: "伪造的王室赦令",
				n175014: "华丽卫队",
				n175015: "废弃庄园",
				n175016: "老国王的印玺",
				n175017: "飞艇码头",
				n175018: "暗中流言",
				n175019: "发条信使",
				n175020: "真名之书",
				n175021: "老国王的灯笼",
				n175022: "旅店老板",
				n175023: "宫廷日记",
				n175024: "摆渡人",
				n175025: "年迈女巫",
				n175026: "宣传顾问",
				n175027: "原型拟像",
				n175028: "变形者之镜",
				n175029: "海妖之池",
				n175030: "蓝调时刻之钟",
				n175031: "出土铁齿轮",
				n175032: "老国王的头盔",
				n175033: "老国王之眼",
				n175034: "刺客公会",
				n175035: "乡间预备军",
				n175036: "工程师工坊",
				n175037: "大比武",
				n175038: "巨翼",
				n175039: "隐秘小径",
				n175040: "攻城指挥官",
				n175041: "集结旗帜",
				n175042: "废墟要塞",
				n175043: "走私者隘口",
				n175044: "绝唱号角",
				n175045: "沉睡之剑",
				n175046: "破裂日晷",
				n175047: "奇异戒指",
				n175048: "毒师舞会",
				n175049: "老国王的长矛",
				n175050: "老国王的盾牌",
				n175700: "寻回的昔日王冠",
				n175701: "最后的礼物",
				n175702: "黄金商队",
				n175703: "可怕的交易",
				n175704: "太阳宝库",
				n175705: "天空之岛",
				n175706: "异常丰饶",
				n175707: "宫廷异客",
				n175708: "约束之石",
				n175709: "实验室",
				n175710: "巨龙",
				n175711: "嗜血之匣",
				n175712: "明亮真确之箭",
				n175713: "突如其来的日食",
				n175714: "天鹅绒拍卖厅",
				n170700: "风暴学派",
				n170800: "盐之坚韧",
				n170900: "河流奔行者",
				n171000: "海上航路",
				n171400: "星辰学派",
				n171500: "远方灯火之外",
				n171600: "月下采集者",
				n171700: "仪式献祭",
				n172000: "街巷学派",
				n172100: "虚假命令",
				n172200: "夜袭",
				n172300: "安全屋",
				n172500: "岩石学派",
				n172600: "皇家印章",
				n172700: "巫术审判",
				n172800: "戒严",
				n175100: "队长游隼",
				n175101: "狙击手太平鸟",
				n175102: "医师云雀",
				n175103: "工程师白嘴鸦",
				n175200: "渡鸦",
				n175300: "引擎",
				n175400: "巨熊",
				n175500: "飞蛾",
				n177700: "雕刻物",
				n177701: "雕刻物",
				n177702: "雕刻物",
				n177703: "骨架",
				n177704: "诡计！",
				n177705: "雕塑",
				n177706: "雕塑",
				n177707: "骨架",
				n177708: "小偶",
				n177709: "缪斯",
				n177710: "诡计！",
				n177711: "小偶",
				n177712: "神像",
				n177713: "神像",
				n177714: "塑像",
				n177715: "塑像",
				n177716: "傀儡",
				n177717: "傀儡",
				n178100: "巨石碑",
				e174000: "",
				e174001: "",
				e174002: "",
				e174003: "",
				e174004: "",
				e174005: "",
				e174006: "夜间：若当前交锋中有对手的追随者，消灭本牌。",
				e174007: "",
				e174008: "",
				e174009: "",
				e174010: "",
				e174011: "",
				e174012: "",
				e174013: "",
				e174400: "",
				e174401: "",
				e174402: "",
				e174403: "",
				e174404: "",
				e174405: "",
				e174406: "夜间：若当前交锋中有对手的追随者，消灭本牌。",
				e174407: "",
				e174408: "",
				e174409: "",
				e174410: "",
				e174411: "",
				e174412: "",
				e174413: "",
				e174300: "",
				e174301: "",
				e174302: "",
				e174303: "",
				e174304: "",
				e174305: "",
				e174306: "夜间：若当前交锋中有对手的追随者，消灭本牌。",
				e174307: "",
				e174308: "",
				e174309: "",
				e174310: "",
				e174311: "",
				e174312: "",
				e174313: "",
				e177400: "",
				e177401: "",
				e177402: "",
				e177403: "",
				e177404: "",
				e177405: "",
				e177406: "夜间：若当前交锋中有对手的追随者，消灭本牌。",
				e177407: "",
				e177408: "",
				e177409: "",
				e177410: "",
				e177411: "",
				e177412: "",
				e177413: "",
				e174014: "用本牌夺取王国牌时，将占据牌的兵力视为 0。",
				e174015: "秋季：若本牌位于议会，将它移至另一个议会。",
				e174016: "取得本牌时：使用失落堆和／或弃牌堆中至多三张自己的牌执行统治。每张牌必须进入不同的议会。",
				e174017: "秋季：若本牌所在地域有至少两个自己的支持者，在本牌上放置 1 影响力。",
				e174414: "用本牌夺取王国牌时，将占据牌的兵力视为 0。",
				e174415: "本牌执行侧翼机动时，可将任意数量的自己的支持者从原地域移至目的地域。",
				e174416: "赢得本牌所在地域的交锋时，在领取奖励前获得 1 影响力。",
				e174314: "用本牌夺取王国牌时，将占据牌的兵力视为 0。",
				e174315: "夜间：消灭当前交锋中对手的所有继承者和商人。若因此消灭了至少一张牌，选择获得 1 影响力或 1 学识。",
				e174316: "参与当前交锋时，将本地域对手非继承者的派系牌上除兵力外的所有印刷信息视为空白。夜间：若交锋中有对手的继承者，消灭本牌。",
				e177414: "用本牌夺取王国牌时，将占据牌的兵力视为 0。",
				e177415: "秋季：若本牌位于议会，在任意议会放置一个阵营标记。本牌位于议会时，你在议会中的每个阵营标记提供 1 票。本牌离开议会时，可将它移至失落堆。",
				e177416: "白昼：焚烧自己失落堆中的一张牌。本牌在本年结束前获得被焚烧牌印刷的兵力、特性、指令和规则文字。",
				e177417: "参与当前交锋时，兵力总值大于 0 且最低的玩家赢得当前交锋，取代通常的最高兵力获胜规则。",
				e176700: "自己未印刷票数的派系牌获得 1 票。秋季：选择将弃牌堆中的一张商人移至手牌，或获得 1 影响力。若行动顺序不是第一，可两项都执行。",
				e177000: "自己所有没有坚韧的牌获得坚韧。春季：将至多两个失落支持者移至一个地域。",
				e177100: "自己的队长获得白昼侧翼机动。自己的牌离开议会时，可将其移至手牌。白昼：可将任意数量具有侧翼机动的自己的地域牌移入议会。",
				e176800: "额外提供一个王国牌栏位。秋季：选择大道上的一张正面王国牌，用手牌中的队长或商人占据；只能放入本栏位。",
				e176900: "每次取得王国牌时，在其对应议会放置一个阵营标记，每个议会至多两个。每个标记提供 1 票。移除议会卡牌的能力也可移除这些标记。",
				e177200: "取得时放置三个阵营标记。白昼：移除一个标记，使当前交锋中的一张地域牌获得伏击，持续至本年结束。可再移除一个标记，使该次伏击从弃牌堆出牌，取代手牌。",
				e175000: "自己的所有卡牌获得寻路者。自己的地域牌也可视为手牌用于旅程。",
				e175001: "春季：若自己在任意议会有牌，获得 1 影响力。若三个议会中都有自己的牌，可弃置本牌，额外获得 2 影响力。",
				e175002: "行动顺序第一时，自己的追随者获得 1 票；否则获得 2 票。",
				e175003: "取得时弃置竞价牌，将本牌放入储备区。发生损耗时，改为弃置本牌，不降低手牌上限。",
				e175004: "自己的竞价牌和占据牌的兵力增加 5。第一个结算竞价时，获得 1 影响力。你不能夺取王国牌。",
				e175005: "春季：焚烧自己的一个战术，获得 1 学识。若该战术尚未耗尽，额外获得 2 学识。",
				e175006: "取得时弃置竞价牌。取得自己势力之所中费用最低的一张牌，费用相同时自行选择。然后弃置本牌。",
				e175007: "自己印刷学识恰为 1 的派系牌额外获得 1 学识。",
				e175008: "尝试夺取王国牌时，夺取牌的兵力增加 3。每当王国牌被夺取，获得 1 影响力。若对手夺取的是本牌，则改由该对手获得这 1 影响力。",
				e175009: "取得时弃置竞价牌，将本牌放在一个地域。秋季：使用该地域中自己的一张地域牌执行统治。",
				e175010: "取得时弃置竞价牌，将本牌放在一个地点。任何玩家领取该地点奖励时，本牌拥有者获得 1 影响力。",
				e175011: "使用寻路者执行旅程时，获得 1 影响力，并额外获得 1 学识。",
				e175012: "春季：若储备区没有学识，获得 1 影响力；否则获得 1 学识。",
				e175013: "春季：将自己弃牌堆中的任意一张牌移至手牌。",
				e175014: "即使未持有王国恩惠，也可发动自己的派系恩惠。持有王国恩惠时，可分两次行动发动两次。",
				e175015: "秋季：弃置自己议会中的一张牌，使手牌上限增加 1。然后弃置本牌。",
				e175016: "取得时手牌上限增加 1；本牌不再被占据时，手牌上限减少 1。在自己的继承者参与的地域赢得交锋时，获得 1 影响力。",
				e175017: "自己的牌离开议会时，可将它移至手牌。执行旅程时，可将出牌移至牌库底。",
				e175018: "春季：选择任意数量的玩家。各玩家将全部手牌按任意顺序放至牌库底，再抽取等量卡牌。",
				e175019: "春季：将一张手牌与自己议会中或占据王国牌的一张牌交换。秋季：再次执行此春季行动。",
				e175020: "白昼：展示全部手牌。将当前交锋中，印刷兵力和／或兵种与所展示卡牌相同的所有对手卡牌返回各自手牌。然后弃置本牌。",
				e175021: "白昼：将当前地域任意数量的自己的支持者移至另一个尚未结算的地域，或移回储备区。",
				e175022: "春季：查看一个地域的所有暗牌。可交换自己部署在任意地域旁的两张暗牌。",
				e175023: "秋季：将自己的一张地域牌移入一个议会，再弃置该议会中任意数量的卡牌。然后弃置本牌。",
				e175024: "春季：将一张手牌与自己失落堆中的一张牌交换。",
				e175025: "春季：焚烧本牌。然后从大道取得至多两张王国牌，并用手牌占据它们。",
				e175026: "每年开始时，决定行动顺序轨上每个标记的位置。",
				e175027: "每年一次，在对手派系恩惠对应的步骤发动该恩惠。若对手持有王国恩惠，不转动其王国恩惠。",
				e175028: "白昼：选择自己参与当前交锋的一张地域牌。它在本年结束前复制任意失落堆中的一张牌，但保留原兵力。",
				e175029: "春季：选择一个地点，将任意数量的传令官移至该处。然后弃置本牌。",
				e175030: "秋季：将自己失落堆中的全部卡牌按任意顺序放至牌库顶或牌库底。然后弃置本牌。",
				e175031: "秋季：将自己的一张地域牌移至手牌。",
				e175032: "自己的牌被消灭时，可将它移至手牌。",
				e175033: "取得时弃置竞价牌，将本牌放入储备区。从大道取得卡牌时，可查看王国牌库顶的两张暗牌，将它们视为大道上的正面牌。",
				e175034: "自己的继承者获得夜间致命和白昼撤退。继承者消灭卡牌时，获得 1 影响力。夜间：若当前交锋中对手的追随者与自己的继承者同时在场，消灭自己的继承者。",
				e175035: "自己的追随者和骑兵获得秋季部署 1。秋季：将弃牌堆中的一张追随者移至手牌。",
				e175036: "具有秋季部署 1 的卡牌获得春季部署 1。秋季：在自己一张具有部署指令的地域牌上放置 1 影响力。",
				e175037: "春季：所有玩家同时打出一张手牌。弃置兵力相同的牌，其余牌中兵力最高者获胜；未弃置的牌返回手牌。胜者领取任意地点奖励。然后弃置本牌。",
				e175038: "自己的继承者获得白昼侧翼机动。",
				e175039: "白昼：将自己参与当前交锋的一张地域牌，与自己议会中或占据王国牌的一张牌交换。",
				e175040: "自己的继承者获得秋季部署 1。自己的继承者被消灭时，将它移至手牌，并弃置本牌。",
				e175041: "秋季：将地图上和／或失落堆中至多两个自己的支持者移至玩家版图。",
				e175042: "取得时弃置竞价牌，将本牌放在一个地域。对手在该地域的总兵力减半，向上取整。冬季：弃置本牌。",
				e175043: "白昼：使自己当前交锋中的一张牌获得撤退，持续至本次交锋结束。它撤退时，可使用该牌执行旅程。",
				e175044: "白昼：使自己当前交锋中的一张地域牌获得伏击，持续至本次交锋结束。",
				e175045: "白昼：当前交锋兵力增加 5。弃置本牌及其占据牌。",
				e175046: "春季：将本牌放在一个地域，并弃置占据牌。该地域的所有交锋跳过白昼与夜间步骤。冬季：弃置本牌。",
				e175047: "秋季：恢复一个已耗尽的战术，并执行其准备指示。弃置本牌及其占据牌。",
				e175048: "取得时弃置竞价牌，将本牌放在一个地域。对手卡牌上除兵力和兵种外的印刷信息视为空白。冬季：弃置本牌。",
				e175049: "白昼：使自己当前交锋中的一张地域牌获得致命，持续至本次交锋结束。弃置本牌及其占据牌。",
				e175050: "白昼：使自己当前交锋中的一张地域牌获得无懈可击，持续至本次交锋结束。弃置本牌。",
				e175700: "终局计分前获得 3 影响力。若影响力并列最高，直接获胜，不再比较学识。",
				e175701: "取得时焚烧竞价牌。手牌上限增加 2。然后弃置本牌。",
				e175702: "取得时弃置竞价牌，将本牌放在一个地点。自己领取该地点奖励时，获得 2 影响力，然后移动本牌。对手领取该地点奖励时，获得 1 影响力。",
				e175703: "冬季：焚烧自己失落堆中的全部卡牌，获得 2 学识。若没有焚烧卡牌，改为弃置本牌。",
				e175704: "取得时焚烧竞价牌。获得等于 7 减去当前年数的影响力。然后弃置本牌。",
				e175705: "取得时弃置竞价牌，将本牌放入储备区。储备区提供不限数量的王国牌栏位；使用这些栏位时，弃置用于占据的竞价牌，王国牌视为由兵力 0 的牌占据。",
				e175706: "春季：本年所有玩家均不能领取传令官奖励，其他影响力收益翻倍。然后弃置本牌。",
				e175707: "春季：可将任意议会中任意数量的卡牌、标记或指示物移至任意其他议会。",
				e175708: "可以支付学识取得对手势力之所中的牌；取得的牌在余下整局中视为自己的盟友。",
				e175709: "秋季：将任意失落堆中的一张牌移至手牌。本局余下时间视为自己的牌。",
				e175710: "传令官每年在其所在地域的第一次交锋提供 5 兵力。冬季：焚烧自己地图上的所有支持者。",
				e175711: "每次交锋中有至少一张牌被消灭时，获得 1 影响力和 1 学识。",
				e175712: "春季：本年所有印刷和获得的无懈可击特性均视为空白。",
				e175713: "取得时弃置竞价牌，将本牌放在一个地域。该地域所有地点奖励在夏季结束前视为空白。秋季：领取该地域的一个地点奖励。冬季：弃置本牌。",
				e175714: "秋季：给予一名对手 1 影响力和 1 学识。将对方一个已耗尽的战术移至自己的储备区，恢复该战术并执行准备指示。你获得其控制权。",
				e170700: "本年由你放置交锋标记。每个地域结算后、领取奖励前，若自己的支持者数量最多，获得 1 影响力；若自己的地域牌数量最多，获得 1 学识。",
				e170800: "将任意数量的自己的地域牌和／或弃牌堆中的派系牌移至手牌，不超过手牌上限。",
				e170900: "将对手一张被占据的王国牌移至自己的玩家版图，并用一张手牌占据。",
				e171000: "移除一个标记，使当前地域自己的一张继承者、队长或战争机器获得白昼侧翼机动，持续至本年结束。没有剩余标记时，耗尽本战术。",
				e171400: "将当前地域两个自己的支持者移至失落堆。若如此做，将自己失落堆中的一张牌移至当前地域。",
				e171500: "交换自己的两张地域牌的位置。",
				e171600: "将王国弃牌堆洗混，秘密查看其中随机五张牌。用一张手牌取得其中一张，其余返回王国弃牌堆。",
				e171700: "将自己的地域牌和／或弃牌堆中至多三张牌移至失落堆，每张获得 1 学识。然后可将弃牌堆中的一张牌移至手牌。",
				e172000: "自己的继承者在本年获得夜间致命。本年每当自己的牌消灭至少一张牌时，获得 1 影响力和 1 学识。",
				e172100: "选择一名对手，交换其部署在地域旁的两张暗面派系牌。可对任意数量的其他对手重复执行。",
				e172200: "自己每占据一张王国牌，每名对手便弃置一张手牌。",
				e172300: "移除一个标记，使自己当前交锋中的一张地域牌获得白昼撤退，持续至本次交锋结束。没有剩余标记时，耗尽本战术。",
				e172500: "本年自己的每个支持者额外提供 1 兵力。冬季：地图上的自己的支持者留在原地域，不移至失落堆。",
				e172600: "所有竞价牌揭示后，立即将本年所有对手的竞价总兵力设为 0。",
				e172700: "选择一个议会，弃置其中所有对手的牌。将自己任意数量的议会牌按任意顺序移至牌库顶，每张获得 1 学识。",
				e172800: "移除一个标记，选择有自己的地域战争机器的一个地域。本年该地域第一次交锋期间，对手不能向其中交换、加入或移动派系牌。没有剩余标记时，耗尽本战术。",
				e175100: "本牌位于议会或地域时，自己的至少一张牌将被消灭时，可改为弃置本牌。",
				e175101: "白昼，本牌参与当前交锋时：本年获得夜间致命，和／或将另一地域的一张地域牌移至其拥有者的弃牌堆。若执行了任意一项，本年不能撤退。",
				e175102: "秋季：将自己弃牌堆中至多三张牌移至牌库底。若如此做，本年不能将本牌召回手牌。",
				e175103: "本牌执行侧翼机动时，可将任意数量的自己的支持者和／或地域牌从原地域移至目的地域。",
				e175200: "若赢得本牌及其对应棋件所在地域的交锋，在领取奖励前获得 1 影响力和 1 学识。冬季：除非位于手牌、储备区或已经焚烧，否则将本牌返回储备区。",
				e175300: "若赢得本牌及其对应棋件所在地域的交锋，在领取奖励前获得 1 影响力和 1 学识。冬季：除非位于手牌、储备区或已经焚烧，否则将本牌返回储备区。",
				e175400: "若赢得本牌及其对应棋件所在地域的交锋，在领取奖励前获得 1 影响力和 1 学识。冬季：除非位于手牌、储备区或已经焚烧，否则将本牌返回储备区。",
				e175500: "若赢得本牌及其对应棋件所在地域的交锋，在领取奖励前获得 1 影响力和 1 学识。冬季：除非位于手牌、储备区或已经焚烧，否则将本牌返回储备区。",
				e177700: "",
				e177701: "",
				e177702: "",
				e177703: "秋季：若本牌是所在地域唯一的拟像地域牌，将它移至当前野心最高优先地域，并在本牌上放置 1 影响力。",
				e177704: "白昼：抽取拟像牌库顶两张牌，将等级较高的一张暗面加入当前交锋，弃置另一张。",
				e177705: "",
				e177706: "",
				e177707: "秋季：若本牌是所在地域唯一的拟像地域牌，将它移至当前野心最高优先地域，并在本牌上放置 1 影响力。",
				e177708: "",
				e177709: "",
				e177710: "白昼：抽取拟像牌库顶两张牌，将等级较高的一张暗面加入当前交锋，弃置另一张。",
				e177711: "",
				e177712: "",
				e177713: "",
				e177714: "",
				e177715: "",
				e177716: "",
				e177717: "",
				e178100: "白昼步骤开始前：揭示一个新威胁。若当前地域没有迷雾，在该地域放置迷雾。"
			},
			name: "先王之冠",
			desc: "王国权力争夺与暗牌交锋。",
			rules: "目标：\n在最后一年结束时，储备区影响力最多者获胜。平局先比较王国恩惠的持有者，再比较行动顺序；寻回的昔日王冠和指定锻造规则可改变平局判定。影响力留在卡牌上时用于维持驻场，不计入储备区总分。势力之所已经清空的玩家，终局每剩余 2 学识额外获得 1 影响力。\n\n岁首与竞价：\n按当前影响力从高至低调整行动顺序，同分者反转原有次序。所有玩家同时抽至手牌上限，再各暗出一张竞价牌。揭示后按竞价总兵力从高至低逐一结算，同值按行动顺序。每次选择从大道取得一张王国牌、夺取对手的王国牌，或将竞价牌返回手牌。夺取要求竞价兵力严格高于占据牌；原占据牌回到原主手牌。取得的王国牌由竞价牌占据；栏位已满时选择替换。所有竞价结算后，大道最右侧弃一张；本轮没有取走大道卡牌则弃两张，随后补齐四张。\n\n部署与春季：\n按顺序将传令官放在六个地点之一。所有玩家各向三个地域暗置一张手牌；手牌不足时按规则选择放置。随后按行动顺序发动可用的春季行动与指令。行动通常每名玩家每年一次，可按任意顺序发动并选择结束。\n\n夏季交锋：\n行动顺序最后一位决定三个地域的结算顺序。每个地域依次揭示暗牌、执行白昼行动、同时触发夜间效果，再比较兵力。总兵力为本次参战地域牌、尚未参战的支持者及其他有效加成之和。最高者赢得交锋。平局玩家可暗加一张手牌并开始新的交锋；全部跳过则无人领取奖励。已参加该地域较早交锋的卡牌和支持者不再贡献兵力。新加入的暗牌会在本轮白昼行动结束后揭示，并有自己的白昼行动机会。\n\n获胜奖励：\n胜者选择当前地域的一个地点。若自己的传令官在该地点，获得 1 影响力，并从每名同处该地的对手各夺取 1 影响力。然后领取地点奖励：\n· 城堡获得 1 影响力并可统治。\n·  荒野获得 1 影响力并可旅程。\n·  丰收田野获得 1 影响力并取得王国恩惠。\n·  战场获得 2 影响力。\n·  神殿获得 1 影响力，并可将至多三张自己的手牌或地域牌移至牌库底。\n·  亡者之城获得 1 影响力，将弃牌堆洗混后抽取至多三张，再可弃置任意手牌。\n\n秋季：\n每名玩家按行动顺序，可用一张至少有 1 票的手牌执行统治，将其放入一个议会；可用一张至少有 1 学识的手牌执行旅程，获得牌上的学识并将牌移至失落堆。还可发动秋季行动与指令。新获得学识时，可花费储备区学识取得势力之所中的高级派系牌或总部牌；前者进入手牌，总部进入储备区并持续生效。\n\n三个议会：\n\n· 遗物议会：领取传令官奖励时，可弃置自己的议会牌，每张获得等于该牌票数的影响力。\n· 秘密议会：秋季按自己的总票数在地点放置阵营标记，四个标记可换取该地点奖励。\n· 誓约议会：秋季按票数召回地图或失落堆的支持者；票数严格最多时额外召回一个。\n移出议会的牌通常进入弃牌堆。\n\n冬季与损耗：\n结算冬季效果，收回传令官，地图支持者进入失落堆。没有影响力的地域牌进入弃牌堆；有影响力的牌移除 1 影响力并留在地域。推进年份。尝试从空牌库抽牌时发生损耗：洗混弃牌堆形成新牌库，手牌上限减少 1，并抽至新的手牌上限。\n\n特性：\n\n· 无懈可击：不会被致命或其他消灭能力消灭。\n· 寻路者：执行旅程时进入弃牌堆，取代失落堆。\n· 坚韧：被消灭时进入弃牌堆，取代失落堆。\n\n指令：\n\n· 伏击：当前交锋中，从手牌暗加一张派系牌。\n· 撤退：将当前地域任意数量的自己的地域牌返回手牌，并可收回传令官和支持者。\n· 侧翼机动：将本牌移至尚未结算的地域。\n伏击、撤退和侧翼机动，每张牌每次交锋各可使用一次。\n· 致命在夜间消灭当前交锋所有对手地域牌，同时效果仍按同时结算。\n· 召回在指定步骤将本牌或指示数量的地域牌返回手牌。\n· 部署从手牌正面放入地域，并按指令数值放置影响力。\n\n王国恩惠与战术：\n取得王国恩惠时恢复为三次。发动一次相应派系恩惠后减少一次，用尽返回丰收田野。战术只在牌上指定时机使用，按卡面耗尽或消耗有限标记。卡牌详情显示当前特性、指令、复制能力和恩赐；规则参考可查全部牌面文字。\n\n拟像：\n单人默认启用，也可与至多三名玩家竞争或合作。拟像依据野心与谋略的优先序行动；其牌库顶等级与两套意图背面线索公开，暗牌正面不公开。威胁通常只在有迷雾的地域生效；当前威胁、锻造及热度在局内可查。锻造 A／B 调整具体规则与热度，选定后全局适用。合作模式所有玩家均须超过拟像的最终影响力。其余拟像专属地点、议会、竞价与清理按官方单人规则自动结算。\n\n荒野王国：\n七模块均可独立选择，默认关闭：\n· 飞行家随飞艇移动并取得四张独特盟友牌。\n·  传奇生物把对应卡牌与棋件联系起来。\n·  谈判桌允许资源交换、口头／有约束力协议和联盟，至少三名玩家。\n·  夜色地图改变六地点的排列。\n·  旅行城镇随拜访而移动并提供牌与影响力。\n·  低语之塔提供攀登、迷宫、塔顶及恩赐。\n·  十五张荒野王国牌按所选集合混入王国牌库。\n· 自由协议由参与者确认履行或提出违约，并按规则由其他玩家裁决；未来承诺不会自动转移资源。联盟共享手牌须由本人主动开启。",
			errors: { invalid: "当前无法执行此操作。" },
			ui: {
				setup: "准备",
				year: "岁首",
				spring: "春季",
				summer: "夏季",
				autumn: "秋季",
				winter: "冬季",
				done: "终局",
				draw: "补充手牌",
				bid: "选择竞价牌",
				resolveBid: "处理竞价",
				herald: "放置传令官",
				deploy: "部署",
				negotiation: "谈判",
				clashOrder: "决定地域交锋顺序",
				reveal: "揭示暗牌",
				day: "白昼行动",
				night: "夜间效果",
				outcome: "交锋结果",
				reward: "领取奖励",
				autumnAction: "秋季行动",
				choose: "请选择",
				card: "选择卡牌",
				placeCard: "部署卡牌",
				supporterRegion: "选择支持者的地域",
				supporters: "放置支持者",
				pass: "结束行动",
				skip: "跳过",
				confirm: "确认选择",
				selection: "已选 {{n}}／{{max}}",
				selectionHint: "选择 {{min}} 至 {{max}} 项",
				waiting: "等待其他玩家",
				resolving: "正在结算",
				hand: "手牌",
				deck: "牌库",
				discard: "弃牌堆",
				lost: "失落堆",
				burned: "已焚烧",
				supply: "储备区",
				active: "地域卡牌",
				occupying: "占据的王国牌",
				site: "势力之所",
				council: "选择议会",
				councils: "议会",
				road: "大道",
				map: "王国地图",
				players: "玩家",
				details: "卡牌详情",
				inspect: "查看详情",
				close: "关闭",
				back: "返回",
				empty: "暂无卡牌",
				round: "第 {{n}}／{{total}} 年",
				influence: "影响力",
				lore: "学识",
				strength: "兵力",
				votes: "票数",
				cost: "学识费用",
				handSize: "手牌上限",
				supporterSupply: "储备支持者",
				supporterLost: "失落支持者",
				favour: "王国恩惠",
				nobility: "贵族",
				clans: "氏族",
				uprising: "起义军",
				gathering: "集会",
				simulacrum: "拟像",
				opulence: "遗物议会",
				mystery: "秘密议会",
				force: "誓约议会",
				region0: "高地",
				region1: "中地",
				region2: "低地",
				location0: "城堡",
				location1: "荒野",
				location2: "丰收田野",
				location3: "战场",
				location4: "神殿",
				location5: "亡者之城",
				reward0: "获得 1 影响力，然后统治",
				reward1: "获得 1 影响力，然后旅程",
				reward2: "获得 1 影响力并取得王国恩惠",
				reward3: "获得 2 影响力",
				reward4: "获得 1 影响力，并可将至多三张手牌或地域牌移至牌库底",
				reward5: "获得 1 影响力，重洗弃牌堆并抽取至多三张牌，然后可弃置手牌",
				agent: "密探",
				captain: "队长",
				cavalry: "骑兵",
				champion: "勇士",
				follower: "追随者",
				heir: "继承者",
				ruse: "诡计",
				trader: "商人",
				warMachine: "战争机器",
				creature: "传奇生物",
				invulnerable: "无懈可击",
				pathfinder: "寻路者",
				resilient: "坚韧",
				deadly: "致命",
				flank: "侧翼机动",
				ambush: "伏击",
				retreat: "撤退",
				ambush_or_retreat: "伏击或撤退",
				rally2: "召回任意两张牌",
				rallySelf: "召回本牌",
				deploy1_autumn: "秋季：部署 1 张牌",
				deploy1_spring: "春季：部署 1 张牌",
				bronze: "铜级",
				silver: "银级",
				gold: "金级",
				hidden: "暗牌",
				kingdom: "王国牌",
				wild: "荒野王国牌",
				hq: "总部",
				tactic: "战术",
				aeronaut: "飞行家",
				boon: "恩赐",
				forging: "锻造难度",
				heat: "热度",
				threats: "威胁",
				fog: "迷雾",
				ambition: "野心",
				scheme: "谋略",
				deckTier: "牌库顶等级",
				intentBack: "背面地域线索",
				modules: "荒野王国模块",
				airship: "飞艇",
				town: "旅行城镇",
				tower: "低语之塔",
				log: "对局记录",
				agreements: "协议与联盟",
				alliedHands: "盟友共享的手牌",
				shareHand: "向盟友展示手牌",
				hideHand: "停止展示手牌",
				agreementText: "协议内容",
				agreementHint: "输入双方约定的内容",
				fulfilled: "协议已履行",
				cancelled: "取消协议",
				breach: "指出违约",
				promise: "提出口头协议",
				tradeOffer: "提出的报价",
				tradeCounter: "对方的报价",
				tradeCards: "交易协议牌",
				mapMarker: "地图阵营标记",
				councilMarker: "议会阵营标记",
				yearOption: "游戏长度",
				years4: "短局：4 年",
				years5: "标准：5 年",
				years6: "长局：6 年",
				advancedSetup: "进阶开局",
				advancedHint: "起始手牌可重抽，并从五张王国牌中选择一张",
				factionOption: "玩家派系",
				random: "随机派系",
				seat: "座位 {{n}}",
				simMode: "拟像模式",
				auto: "单人时自动启用",
				off: "关闭",
				competitive: "竞争模式",
				cooperative: "合作模式",
				simHint: "启用拟像时支持 1–3 名玩家；谈判桌至少需要 3 名玩家",
				forgeOption: "锻造卡",
				forgeValue: "数值",
				none: "不启用",
				threatOption: "指定威胁牌",
				advancedSimOption: "高级拟像牌",
				aeronauts: "飞行家",
				creatures: "传奇生物",
				negotiating: "谈判桌",
				nightMap: "夜色地图",
				wildCards: "荒野王国牌",
				enabled: "已启用",
				resultTitle: "王冠的归属",
				resultWin: "{{name}} 赢得王冠",
				resultCoopWin: "联盟击败了拟像",
				resultCoopLoss: "拟像夺得王冠",
				resultTotal: "最终影响力",
				resultTiebreak: "王国恩惠／行动顺序",
				reviewBoard: "回看王国",
				showResult: "查看终局",
				exitConfirm: "确定离开本局吗？",
				hintCount: "本局求助 {{n}} 次",
				autopilot: "托管占比",
				exhausted: "已耗尽",
				ready: "可使用",
				uses: "剩余 {{n}} 次",
				guards: "占据牌",
				copied: "复制的能力",
				gained: "获得的能力",
				influenceOnCard: "牌上影响力",
				keep: "保留手牌",
				mulligan: "重抽手牌",
				acquire: "取得王国牌",
				steal: "夺取王国牌",
				returnBid: "竞价牌返回手牌",
				startingKingdomGuard: "选择王国牌及其占据牌",
				emptySlot: "放入空位 {{n}}",
				replaceKingdom: "替换王国牌",
				govern: "统治",
				journey: "旅程",
				secrets: "秘密议会行动",
				oaths: "誓约议会行动",
				region: "选择地域",
				location: "选择地点",
				player: "选择玩家",
				count: "数量",
				regionOrder: "地域顺序",
				claimFavour: "取得王国恩惠",
				returnHand: "返回手牌",
				moveLost: "移至失落堆",
				deckTop: "放至牌库顶",
				deckBottom: "放至牌库底",
				markers: "阵营标记",
				discardCouncil: "弃置议会牌",
				discardHand: "弃置手牌",
				discardDeckTop: "弃置牌库顶牌",
				discardForInfluence: "弃牌以获得影响力",
				activateTactic: "使用战术",
				refreshTactic: "恢复战术",
				burnTactic: "焚烧战术",
				cardInfluence: "牌上影响力",
				boonCard: "将恩赐放至卡牌",
				allowElimination: "接受消灭结果",
				ambushDiscard: "从弃牌堆伏击",
				lostSupporter: "召回失落支持者",
				recallSupporter: "召回支持者",
				returnHerald: "收回传令官",
				playerHerald: "选择玩家的传令官",
				locationReward: "领取地点奖励",
				protectHeirs: "保护继承者",
				gainDeadly: "获得致命",
				sacrificePeregrine: "弃置游隼以保护卡牌",
				proposeBarter: "提议交换",
				proposeAgreement: "拟定协议",
				proposeAlliance: "提议联盟",
				finishNegotiation: "结束谈判",
				requestCounteroffer: "邀请对方报价",
				submitCounteroffer: "提交还价",
				clearOffer: "清空报价",
				cancelBarter: "取消交换",
				acceptBarter: "接受交换",
				makeCounteroffer: "提出还价",
				decline: "拒绝",
				nonbindingAgreement: "口头协议",
				bindingAgreement: "有约束力的协议",
				acceptAgreement: "接受协议",
				confirmBreach: "确认违约",
				denyBreach: "不认定违约",
				noWinner: "不推举获胜者",
				visitAeronauts: "拜访飞行家",
				visitTown: "拜访旅行城镇",
				visitTower: "拜访低语之塔",
				exploreLabyrinth: "探索迷宫",
				explorePinnacle: "探索塔顶",
				leaveTower: "离开高塔",
				protectBatch: "选择如何避免消灭",
				recoverCouncil: "取回离开议会的卡牌",
				recoverEliminated: "取回被消灭的卡牌",
				buySite: "购买势力之所牌",
				occupy: "选择占据牌",
				occupySlot: "选择王国牌栏位",
				placeSupporters: "放置支持者",
				allyBid: "盟友牌竞价",
				allyDeploy: "部署盟友牌",
				startingKingdom: "选择起始王国牌",
				tieCard: "追加交锋牌",
				orderPlayer: "安排玩家次序",
				chooseResource: "选择资源",
				clansSupporters: "移动氏族支持者",
				deckEnd: "选择牌库位置",
				discardBoons: "弃置恩赐",
				doorDiscard: "选择伏击来源",
				falseOrders: "交换对手暗牌",
				flankSupporters: "随侧翼行动移动支持者",
				foragers: "选择采集者行动",
				forgeElimination: "拟像消灭目标",
				giveBoon: "给予恩赐",
				harbour: "召回港湾支持者",
				journeyDestination: "选择旅程目的地",
				lantern: "移动灯笼照耀的支持者",
				martialLaw: "选择戒严目标",
				monument: "纪念碑建造者",
				moonshineRoad: "从大道取得王国牌",
				necropolisCount: "选择取回的卡牌数量",
				negotiate: "谈判",
				placeBoons: "放置恩赐",
				rearrangeCouncils: "调整议会中的物件",
				regalGuard: "选择皇家护卫行动",
				relics: "搜寻王国遗物",
				roadAcquire: "从大道取得卡牌",
				royalBank: "选择皇家银行收益",
				royalSeal: "决定是否使用皇家印玺",
				rumoursPlayers: "选择重整手牌的玩家",
				secretLocation: "放置秘密议会标记",
				secretReward: "领取秘密议会奖励",
				simActionOrder: "选择拟像行动的处理顺序",
				simAutumnLoss: "支付秋季损失",
				simHerald: "移动拟像传令官",
				simShrineDiscard: "选择要弃置的卡牌",
				simThreatInfluence: "处理威胁的影响力损失",
				sirenHeralds: "移动传令官至海妖之池",
				sirenLocation: "选择海妖之池地点",
				supporterCount: "选择支持者数量",
				towerAscend: "攀登低语之塔",
				towerLabyrinth: "探索迷宫",
				towerMove: "移动低语之塔",
				towerPinnacleChoice: "选择塔顶奖励",
				townAcquire: "取得旅行城镇卡牌",
				townReplace: "替换城镇卡牌",
				waxwing: "太平鸟行动",
				witchTrial: "巫术审判",
				airPlace: "移动飞艇",
				agreementAccept: "审阅协议",
				agreementCompose: "拟定协议内容",
				agreementResolve: "确认协议结果",
				allianceWinner: "推举联盟获胜者",
				arbitrateAgreement: "裁决协议违约",
				auctionTactic: "选择拍卖的战术",
				barterInvitation: "回应交换邀请",
				barterReview: "审阅交换内容",
				boonGovernJourney: "选择恩赐行动",
				boonTower: "选择高塔恩赐",
				tradeCompose: "拟定交换报价",
				acquiredSite: "取得了势力之所牌",
				activated: "使用了能力",
				attrition: "发生损耗",
				barter: "完成了交换",
				eliminated: "卡牌被消灭",
				outrage: "违约引发众怒",
				revealedThreat: "揭示了威胁",
				acquiredKingdom: "取得了王国牌",
				stoleKingdom: "夺取了王国牌",
				wonClash: "赢得交锋",
				wonCouncil: "赢得议会",
				trade_influence: "获得影响力",
				trade_lore: "获得学识",
				trade_supporters: "放置支持者",
				trade_tradeCards: "交易协议牌",
				trade_hand: "手牌",
				trade_site: "势力之所",
				trade_kingdom: "王国牌",
				trade_tactic: "战术",
				trade_boon: "恩赐",
				trade_mapMarker: "地图阵营标记",
				trade_councilMarker: "议会阵营标记",
				trade_favour: "王国恩惠",
				nobilityFavour: "贵族恩惠",
				clansFavour: "氏族恩惠",
				uprisingFavour: "起义军恩惠",
				gatheringFavour: "集会恩惠",
				activate: "发动能力",
				activateBoon: "使用恩赐",
				beacon: "选择信标提供的势力之所",
				beyondLights: "选择远方灯火行动",
				blueHour: "安排失落牌的顺序",
				boonSwap: "交换恩赐卡牌",
				copyLost: "复制失落牌",
				diary: "宫廷日记行动",
				discardActive: "弃置地域中的牌",
				door: "使用夜之门",
				embassy: "使用流动使馆",
				engineers: "使用工程师工坊",
				estate: "使用废弃庄园",
				flankCards: "随侧翼行动移动卡牌",
				grantAbility: "赋予卡牌能力",
				grantRetreat: "赋予撤退能力",
				handOrder: "安排卡牌顺序",
				heraldMoon: "月之传令官",
				hiddenLanes: "使用隐秘小径",
				laboratory: "使用实验室",
				medic: "使用战地救护",
				mirror: "使用变形者之镜",
				moonshine: "使用月光湾",
				opponentFavour: "使用对手派系恩惠",
				placeAirship: "选择飞艇位置",
				queenGovern: "使用昔日女王的统治能力",
				rally: "召回卡牌",
				retreatCards: "撤退卡牌",
				retreatPieces: "选择撤退的物件",
				returnFollower: "取回追随者",
				ritualSacrifice: "焚烧祭礼卡牌",
				riverRunners: "使用河流奔行者",
				safehouses: "使用安全屋",
				saltToughness: "使用盐之坚韧",
				schoolStars: "使用星辰学院",
				seaLanes: "使用海上航路",
				shrine: "将卡牌移至牌库底",
				spySwap: "交换窥视到的暗牌",
				swapHand: "选择要交换的手牌",
				swapHidden: "交换暗牌位置",
				swapTarget: "选择交换目标",
				tooth: "使用牙齿仪式",
				tourney: "选择比武大会出牌",
				witchOwn: "选择自己的审判牌",
				visit: "拜访",
				proposed: "等待接受",
				expired: "已到期",
				declined: "已拒绝",
				reference: "规则参考",
				boons: "恩赐",
				abilities: "特性与指令",
				left: "左侧",
				right: "右侧",
				stealIntent: "优先夺取王国牌",
				acquireIntent: "优先从大道取得王国牌",
				cycle: "依次循环放置支持者",
				first: "支持者集中于首个地域",
				simAmbush: "拟像伏击",
				simArmature: "拟像骨架行动",
				simRally: "拟像召回",
				simPall: "迷雾中现身",
				simFrontlines: "战线消散",
				simPickedOff: "逐个击破",
				simWhispers: "宫廷低语",
				simPitchBlack: "漆黑之夜",
				cancel: "取消",
				resultTie: "共同获得王冠",
				resultSimWin: "拟像赢得王冠",
				resultCoopHint: "合作模式以联盟的真实胜负结算",
				resultWaiting: "等待主机选择下一步",
				playAgain: "再来一局",
				backToLobby: "返回大厅",
				playAgainConfirm: "确定开始新的一局吗？",
				confirmExit: "确定离开",
				finalYear: "王国历 {{n}} 年",
				score: "最终影响力",
				pendingSubject: "{{name}} 的选择",
				boonOnCard: "附着的恩赐",
				favourOwner: "王国恩惠：{{name}}",
				noneOwner: "无人持有",
				mapMarkers: "地点标记",
				supporterLostCount: "失落 {{n}}",
				orderTrack: "行动顺序",
				bidCards: "竞价牌",
				forgeHeat: "热度调整",
				seasonSetup: "准备阶段",
				seasonYear: "岁首",
				seasonSpring: "春季",
				seasonSummer: "夏季",
				seasonAutumn: "秋季",
				seasonWinter: "冬季",
				currentChoice: "当前选择",
				agreementActive: "协议生效中",
				clashWon: "赢得交锋",
				clashTied: "交锋平局",
				creatureHerald: "放置传奇生物传令官",
				fought: "已参加先前交锋",
				confirmFulfilled: "确认协议已履行",
				confirmCancellation: "确认解除协议",
				broken: "已违约",
				supporter: "支持者",
				resolved: "已结算"
			},
			reference: {
				nforge1a: "前卫",
				eforge1a: "准备：拟像储备区有 1 个支持者；冬季清理时从地图取回 1 个，取代通常的 3 个。",
				nforge1b: "无情不息",
				eforge1b: "准备：拟像储备区有 5 个支持者；冬季清理时从地图取回至多 5 个，取代通常的 3 个。",
				nforge2a: "晴空",
				eforge2a: "拟像根据主要威胁放置迷雾时，少放一个，最少一个。",
				nforge2b: "阴郁天日",
				eforge2b: "拟像根据主要威胁放置迷雾时，多放一个，最多三个。",
				nforge3a: "繁荣",
				eforge3a: "玩家的起始手牌上限为 7。",
				nforge3b: "饥荒",
				eforge3b: "玩家的起始手牌上限为 5。",
				nforge4a: "团结",
				eforge4a: "准备：每名玩家获得 X 影响力。热度减少 X。",
				nforge4b: "分裂",
				eforge4b: "准备：拟像获得 2X 影响力。热度增加 X。",
				nforge5a: "畅通之路",
				eforge5a: "玩家势力之所的牌少花费 1 学识，最低费用为 1。",
				nforge5b: "监视之路",
				eforge5b: "玩家势力之所的牌多花费 1 学识。",
				nforge6a: "迟来援军",
				eforge6a: "拟像花费 4 学识取得一张势力之所牌，取代通常的 3 学识。",
				nforge6b: "提前援军",
				eforge6b: "拟像花费 2 学识取得一张势力之所牌，取代通常的 3 学识。",
				nforge7a: "王国长存",
				eforge7a: "拟像不获得所占据王国牌的派别奖励。",
				nforge7b: "王国动摇",
				eforge7b: "拟像所占据王国牌的派别奖励触发两次。",
				nforge8a: "人民反抗",
				eforge8a: "拟像将取得王国恩惠时，不移动王国恩惠，改为获得 1 影响力。",
				nforge8b: "倒戈",
				eforge8b: "准备及每次岁首时，拟像揭示两张威胁牌，取代通常的一张。",
				nforge9a: "反复无常",
				eforge9a: "拟像始终位于行动顺序的第一位。",
				nforge9b: "冷酷",
				eforge9b: "拟像始终位于行动顺序的最后一位。",
				nforge10a: "流放",
				eforge10a: "拟像准备结束时，将其牌库顶牌放至势力之所顶端。",
				nforge10b: "增援",
				eforge10b: "拟像准备结束时，将其势力之所顶牌放至牌库顶。",
				nforge11a: "吞噬强者",
				eforge11a: "拟像牌库耗尽、重洗弃牌堆时，将其中随机一张金级牌移至失落堆。",
				nforge11b: "吞噬弱者",
				eforge11b: "拟像牌库耗尽、重洗弃牌堆时，将其中随机一张铜级牌移至失落堆；若没有铜级牌，改为银级。",
				nforge12a: "哨塔",
				eforge12a: "准备：在三个不同的随机地点各放一个塔。拟像领取有塔地点的奖励时，改为移除该塔。",
				nforge12b: "奇异高塔",
				eforge12b: "准备：在三个不同的随机地点各放一个塔。玩家领取有塔地点的奖励时，改为移除该塔。",
				nforge13a: "洞察意图",
				eforge13a: "每年放置竞价牌前，揭示当前野心。",
				nforge13b: "隐藏意图",
				eforge13b: "从野心牌库底抽牌；弃置的野心牌放至牌库顶。",
				nforge14a: "公开行动",
				eforge14a: "揭示本年野心牌时，同时揭示谋略牌。",
				nforge14b: "秘密行动",
				eforge14b: "从谋略牌库底抽牌；弃置的谋略牌放至牌库顶。",
				nforge15a: "士气高昂",
				eforge15a: "交锋平局时视为玩家获胜。终局影响力平局时，在其他平局判定前由玩家获胜。",
				nforge15b: "士气低落",
				eforge15b: "交锋平局时视为拟像获胜。终局影响力平局时，在其他平局判定前由拟像获胜。",
				nforge16a: "隐秘储藏",
				eforge16a: "玩家可恢复一个耗尽的战术，并在此牌放置 2 影响力。终局将此牌影响力数值加入热度。",
				nforge16b: "破坏！",
				eforge16b: "准备：随机耗尽 X 个战术，每个使热度增加 2。X 为 0 至 4。",
				nforge17a: "老兵",
				eforge17a: "玩家每个支持者提供 2 兵力，取代通常的 1。",
				nforge17b: "强化",
				eforge17b: "拟像每个支持者提供 2 兵力，取代通常的 1。",
				nforge18a: "幸运眷顾我们",
				eforge18a: "玩家的继承者获得无懈可击。",
				nforge18b: "幸运眷顾它",
				eforge18b: "拟像的继承者获得无懈可击及秋季召回本牌。",
				nforge19a: "拟像之灾",
				eforge19a: "玩家的继承者获得夜间致命。",
				nforge19b: "拟像之刃",
				eforge19b: "拟像的继承者获得夜间致命及秋季召回本牌。",
				nforge20a: "寂然无声",
				eforge20a: "拟像不在秋季执行统治。",
				nforge20b: "万千声音",
				eforge20b: "拟像秋季执行两次统治，取代通常的一次。",
				nforge21a: "顺风",
				eforge21a: "拟像放置传令官时，玩家可选择其地点。",
				nforge21b: "深重迷雾",
				eforge21b: "揭示谋略时，将拟像传令官移至谋略最高优先地域，左右地点由当前野心箭头决定。",
				nforge22a: "如雾消散",
				eforge22a: "所有拟像牌失去坚韧。",
				nforge22b: "如雾游移",
				eforge22b: "具有致命的拟像牌获得无懈可击。",
				nforge23a: "存在微弱",
				eforge23a: "拟像不获得任何传令官奖励。",
				nforge23b: "威慑四方",
				eforge23b: "拟像所有传令官奖励的影响力翻倍，包括从玩家传令官夺取的影响力和遗物议会奖励。",
				nforge24a: "资源衰减",
				eforge24a: "拟像势力之所为空时，每 3 学识转化为 1 影响力，取代通常的 2 学识。",
				nforge24b: "资源充盈",
				eforge24b: "拟像势力之所为空时，每 1 学识转化为 1 影响力，取代通常的 2 学识。",
				nforge25a: "隐居",
				eforge25a: "拟像从不尝试夺取玩家的王国牌。",
				nforge25b: "侵入",
				eforge25b: "拟像结算竞价时，始终优先尝试夺取玩家的王国牌。",
				nforge26a: "永远迷失",
				eforge26a: "拟像不在秋季执行旅程。",
				nforge26b: "永远探寻",
				eforge26b: "拟像秋季执行两次旅程，取代通常的一次。",
				nforge27a: "隐秘珍宝",
				eforge27a: "玩家第一个结算竞价时，获得 1 影响力。",
				nforge27b: "劫掠宝库",
				eforge27b: "拟像第一个结算竞价时，获得 1 影响力。",
				nforge28a: "同情与牺牲",
				eforge28a: "每次消灭至少一张牌时，玩家选择获得 1 影响力、获得 1 学识，或将地图／失落堆中一个自己的支持者返回玩家版图。",
				nforge28b: "嗜血",
				eforge28b: "每次消灭至少一张牌时，拟像按当前野心派别获得奖励：遗物为 1 影响力；秘密为 1 学识；誓约为各 1。",
				nforge29a: "无防备",
				eforge29a: "准备：拟像势力之所只有一张高级派系牌，取代通常的三张。",
				nforge29b: "严阵以待",
				eforge29b: "准备：拟像势力之所有五张高级派系牌，取代通常的三张。",
				nforge30a: "疲惫旅人",
				eforge30a: "拟像竞价标记的兵力减少 3，最低为 1。",
				nforge30b: "强行军",
				eforge30b: "拟像竞价标记的兵力增加 3。",
				nthreat1: "利刃出鞘",
				ethreat1: "迷雾地域中的所有拟像地域牌获得夜间致命。",
				nthreat2: "雾中披风",
				ethreat2: "迷雾地域中的所有拟像地域牌获得无懈可击。",
				nthreat3: "烟雾堡垒",
				ethreat3: "拟像召回前，在每个迷雾地域兵力最高的拟像牌上放置 1 影响力。本年不召回牌上有影响力的牌。",
				nthreat4: "海妖之歌",
				ethreat4: "迷雾地域交锋结算后、领取奖励前：拟像落败则在野心对应议会放置 1 影响力；拟像获胜则获得该议会上全部影响力的等量影响力。",
				nthreat5: "庞然身影",
				ethreat5: "拟像在每个迷雾地域增加 3 兵力。",
				nthreat6: "雾中现身",
				ethreat6: "当前地域拟像地域牌只有铜级和／或银级时，抽取拟像牌库顶牌并加入当前地域。",
				nthreat7: "迷失雾中",
				ethreat7: "玩家不能在迷雾地域发动召回或撤退指令。",
				nthreat8: "计划成形",
				ethreat8: "拟像赢得迷雾地域的交锋时，获得 1 影响力。",
				nthreat9: "战线消散",
				ethreat9: "迷雾地域每有一张拟像地域牌，玩家弃置一张手牌；每缺一张手牌，改为弃置当前地域的一张自己的牌。",
				nthreat10: "高耸轮廓",
				ethreat10: "拟像在每个迷雾地域增加 5 兵力。",
				nthreat11: "宫廷低语",
				ethreat11: "每个迷雾地域中，玩家选择将一张自己的地域牌移至失落堆，或弃置一张议会牌。两项均不能执行时，拟像获得 2 影响力。",
				nthreat12: "人心动摇",
				ethreat12: "拟像在迷雾地域的传令官奖励影响力翻倍，包括遗物议会奖励。",
				nthreat13: "火葬之景",
				ethreat13: "拟像在迷雾地域落败后、领取奖励前，玩家随机焚烧一张势力之所牌；若已没有牌，将储备区全部学识移至公共储备。",
				nthreat14: "信号烽火",
				ethreat14: "拟像召回前，若任意迷雾地域有至少一张拟像地域牌，拟像获得 3 学识。",
				nthreat15: "漆黑之夜",
				ethreat15: "每个有玩家地域牌的迷雾地域中，玩家将一张自己的牌移至失落堆。",
				nthreat16: "全线溃败",
				ethreat16: "迷雾地域中的玩家卡牌将印刷的无懈可击和坚韧视为空白。",
				nthreat17: "宏伟事业",
				ethreat17: "拟像每赢得一次迷雾地域的交锋，获得 3 影响力和 3 学识。",
				nthreat18: "时间诡行",
				ethreat18: "每个迷雾地域中，若第一次交锋本将由玩家获胜，改为平局并开始新的交锋。",
				nthreat19: "雾墙",
				ethreat19: "玩家不能在迷雾地域发动伏击或侧翼机动。",
				nthreat20: "逐个击破",
				ethreat20: "迷雾地域当前交锋中，兵力不超过 4 的玩家地域牌移至失落堆。",
				nthreat21: "地标消失",
				ethreat21: "玩家不能领取迷雾地域中当前野心箭头所指一侧的地点奖励。",
				nthreat22: "滚滚海雾",
				ethreat22: "揭示本威胁后，立即再揭示一个威胁。",
				nthreat23: "力量展示",
				ethreat23: "迷雾地域所有夜间效果结算后，拟像每有一张牌的兵力高于本次交锋兵力最高的玩家牌，便夺取 1 影响力。",
				nthreat24: "我们众多",
				ethreat24: "迷雾地域的所有拟像牌获得追随者兵种。拟像赢得迷雾地域交锋时，获得 1 影响力。",
				nboon0: "白昼交换",
				eboon0: "白昼：将本牌与一张自己的手牌交换。",
				nboon1: "揭示驱散",
				eboon1: "揭示时：将本地域所有支持者移至失落堆。",
				nboon2: "秋季影响力",
				eboon2: "秋季：在本牌上放置 1 影响力。",
				nboon3: "胜利扩充",
				eboon3: "赢得交锋：手牌上限增加 1。",
				nboon4: "胜利奖励",
				eboon4: "赢得交锋：领取本地域的一个地点奖励。",
				nboon5: "双重召回",
				eboon5: "秋季：召回任意两张牌。",
				nboon6: "胜利献祭",
				eboon6: "赢得交锋：获得 2 影响力和 2 学识，然后焚烧本牌。",
				nboon7: "无懈可击",
				eboon7: "本牌获得无懈可击。",
				nboon8: "伏击",
				eboon8: "本牌获得白昼伏击。",
				nboon9: "致命代价",
				eboon9: "本牌获得夜间致命。交锋后：焚烧本牌。",
				nboon10: "胜利议会",
				eboon10: "赢得交锋：发动秘密议会和誓约议会。",
				nboon11: "胜利攀登",
				eboon11: "赢得交锋：可拜访低语之塔。",
				nboon12: "侧翼机动",
				eboon12: "本牌获得白昼侧翼机动。",
				nboon13: "十点兵力",
				eboon13: "本牌兵力增加 10。交锋后：焚烧本牌。",
				nboon14: "秋季远行",
				eboon14: "秋季：使用本牌执行旅程或统治。",
				nboon15: "弱者退场",
				eboon15: "白昼：弃置当前交锋中兵力不超过 3 的所有卡牌。",
				nboon16: "封锁指令",
				eboon16: "本次交锋期间，对手不能发动或触发指令。",
				nboon17: "失落交换",
				eboon17: "白昼：将本牌与自己失落堆中的一张牌交换。",
				nboon18: "五点兵力",
				eboon18: "本牌兵力增加 5。",
				nboon19: "胜利收获",
				eboon19: "赢得交锋：获得 1 影响力和 1 学识。"
			}
		},
		en: {
			cards: {
				n174000: "Ruse!",
				n174001: "Guild of Dawn Traders",
				n174002: "Watchers at the Walls",
				n174003: "Hunting Parties",
				n174004: "The Tithe",
				n174005: "Keepers of the Gates",
				n174006: "Vial Sect",
				n174007: "Knights of the Pasture",
				n174008: "Woe",
				n174009: "Master of Records",
				n174010: "The Count",
				n174011: "The Magistrate",
				n174012: "Master of Arms",
				n174013: "Titus of Dawns & Dusks",
				n174400: "Ruse!",
				n174401: "Purser",
				n174402: "Snowdrop Scouts",
				n174403: "Creel Haulers",
				n174404: "Priestesses of the Peaks",
				n174405: "Sea Breakers",
				n174406: "Nixing Knife",
				n174407: "Shore Runner Sleds",
				n174408: "Hall Upon the Waves",
				n174409: "Shrike of the Steppes",
				n174410: "The Branded Seer",
				n174411: "Lethe",
				n174412: "Gall",
				n174413: "Saga the Unifier",
				n174300: "Ruse!",
				n174301: "The Fence",
				n174302: "Secret Postal Service",
				n174303: "The Irregulars",
				n174304: "Hawkers",
				n174305: "The Pickets",
				n174306: "Night Carnival",
				n174307: "Ornithopter Club",
				n174308: "Experimental Academies",
				n174309: "The Librarian",
				n174310: "The Deadlifter",
				n174311: "Baron Cuttlefish",
				n174312: "Captain Mooncurser",
				n174313: "The Secret Society",
				n177400: "Ruse!",
				n177401: "The Nightjar",
				n177402: "Effigies",
				n177403: "Speakers of the Wood",
				n177404: "The Wandering Lost",
				n177405: "The Moon-Stung",
				n177406: "Cult of Dreams",
				n177407: "The Loping",
				n177408: "The Burning Wood",
				n177409: "The Owl",
				n177410: "The Goat",
				n177411: "The Fox",
				n177412: "The Stag",
				n177413: "Petrichor the Unmasked",
				n174014: "The Viceroy",
				n174015: "The High Court",
				n174016: "The Queen, Long Ago",
				n174017: "Gilded Wall",
				n174414: "The Storyteller",
				n174415: "Raid & Raze",
				n174416: "Riders of the North Sky",
				n174314: "Arch Agitant",
				n174315: "Black Powder Plot",
				n174316: "Guerrilla Fighters",
				n177414: "The Mask Maker",
				n177415: "Bringer of the Word",
				n177416: "Ritual of the Tooth",
				n177417: "Ritual of the Eye",
				n176700: "Royal Bank",
				n177000: "New Havens Harbour",
				n177100: "Wandering Embassy",
				n176800: "Moonshine Cove",
				n176900: "The Syndicate",
				n177200: "The Door in the Night",
				n175000: "Adventuring Party",
				n175001: "Monument Builders",
				n175002: "Tin Crowns",
				n175003: "Mysterious Benefactor",
				n175004: "White Watchtowers",
				n175005: "Forgotten Palace",
				n175006: "The Beacon",
				n175007: "Endless Library",
				n175008: "Emboldened Brigands",
				n175009: "Midnight Court",
				n175010: "Merchants’ Guild",
				n175011: "Glittering Caves",
				n175012: "Remote Bothies",
				n175013: "Forged Royal Pardons",
				n175014: "Splendid Guard",
				n175015: "Abandoned Estate",
				n175016: "Old King’s Signet",
				n175017: "Airship Docks",
				n175018: "Rumours in the Dark",
				n175019: "Clockwork Messengers",
				n175020: "Book of True Names",
				n175021: "Old King’s Lantern",
				n175022: "The Innkeeper",
				n175023: "Courtier’s Diary",
				n175024: "The Boatman",
				n175025: "Old Enchantress",
				n175026: "Propaganda Advisor",
				n175027: "Prototype Simulacrum",
				n175028: "Shapeshifter’s Mirror",
				n175029: "The Siren’s Pool",
				n175030: "Blue Hour Bell",
				n175031: "Unearthed Iron Gear",
				n175032: "Old King’s Helm",
				n175033: "Old King’s Eye",
				n175034: "Assassins’ Guild",
				n175035: "Countryside Reservists",
				n175036: "Engineers’ Workshop",
				n175037: "Grand Tourney",
				n175038: "The Great Wing",
				n175039: "Hidden Lanes",
				n175040: "Siege Commander",
				n175041: "Mustering Banner",
				n175042: "Ruined Citadel",
				n175043: "Smuggler’s Pass",
				n175044: "Swansong Horn",
				n175045: "The Sword That Slept",
				n175046: "Cracked Sundial",
				n175047: "Curious Ring",
				n175048: "Poisoner’s Ball",
				n175049: "Old King’s Spear",
				n175050: "Old King’s Shield",
				n175700: "The Once Crown, Found",
				n175701: "A Last Gift",
				n175702: "The Golden Caravan",
				n175703: "A Dread Deal",
				n175704: "The Sun Vault",
				n175705: "Islands in the Sky",
				n175706: "Unnatural Abundance",
				n175707: "Odd Arrivals at Court",
				n175708: "Binding Stone",
				n175709: "The Laboratory",
				n175710: "The Wyrm",
				n175711: "Blood Seeking Box",
				n175712: "Arrows, Bright & True",
				n175713: "Sudden Eclipse",
				n175714: "Velvet Auction Room",
				n170700: "School of the Storms",
				n170800: "Salt Toughness",
				n170900: "River Runners",
				n171000: "Sea Lanes",
				n171400: "School of the Stars",
				n171500: "Out Beyond the Lights",
				n171600: "Moonlit Foragers",
				n171700: "Ritual Sacrifice",
				n172000: "School of the Streets",
				n172100: "False Orders",
				n172200: "Night Raids",
				n172300: "Safehouses",
				n172500: "School of the Stones",
				n172600: "Royal Seal",
				n172700: "Witch Trial",
				n172800: "Martial Law",
				n175100: "Peregrine the Captain",
				n175101: "Waxwing the Sniper",
				n175102: "Lark the Medic",
				n175103: "Rook the Engineer",
				n175200: "The Raven",
				n175300: "The Engine",
				n175400: "The Bear",
				n175500: "The Moth",
				n177700: "Carvings",
				n177701: "Carvings",
				n177702: "Carvings",
				n177703: "Armatures",
				n177704: "Ruse!",
				n177705: "Sculptures",
				n177706: "Sculptures",
				n177707: "Armatures",
				n177708: "Poppet",
				n177709: "Muse",
				n177710: "Ruse!",
				n177711: "Poppet",
				n177712: "Idol",
				n177713: "Idol",
				n177714: "Statue",
				n177715: "Statue",
				n177716: "Puppet",
				n177717: "Puppet",
				n178100: "Monolith",
				e174000: "",
				e174001: "",
				e174002: "",
				e174003: "",
				e174004: "",
				e174005: "",
				e174006: "Night: If an opponent Follower is Active in the current Clash, Eliminate this card.",
				e174007: "",
				e174008: "",
				e174009: "",
				e174010: "",
				e174011: "",
				e174012: "",
				e174013: "",
				e174400: "",
				e174401: "",
				e174402: "",
				e174403: "",
				e174404: "",
				e174405: "",
				e174406: "Night: If an opponent Follower is Active in the current Clash, Eliminate this card.",
				e174407: "",
				e174408: "",
				e174409: "",
				e174410: "",
				e174411: "",
				e174412: "",
				e174413: "",
				e174300: "",
				e174301: "",
				e174302: "",
				e174303: "",
				e174304: "",
				e174305: "",
				e174306: "Night: If an opponent Follower is Active in the current Clash, Eliminate this card.",
				e174307: "",
				e174308: "",
				e174309: "",
				e174310: "",
				e174311: "",
				e174312: "",
				e174313: "",
				e177400: "",
				e177401: "",
				e177402: "",
				e177403: "",
				e177404: "",
				e177405: "",
				e177406: "Night: If an opponent Follower is Active in the current Clash, Eliminate this card.",
				e177407: "",
				e177408: "",
				e177409: "",
				e177410: "",
				e177411: "",
				e177412: "",
				e177413: "",
				e174014: "When used to steal a Kingdom Card, treat the Occupying card as Strength 0.",
				e174015: "Autumn: If in a Council, move this card to another Council.",
				e174016: "When you acquire this card, Govern with up to three of your cards from the Lost Pile and/or Discard Pile. Put each card into a different Council.",
				e174017: "Autumn: If you have two or more Supporters in this card’s Region, place 1 Influence on this card.",
				e174414: "When used to steal a Kingdom Card, treat the Occupying card as Strength 0.",
				e174415: "When this card Flanks, you may move any number of your Supporters from its old Region to its new Region.",
				e174416: "When you win a Clash in a Region where this card is Active, before claiming any rewards, gain 1 Influence.",
				e174314: "When used to steal a Kingdom Card, treat the Occupying card as Strength 0.",
				e174315: "Night: Eliminate all opponent Heir / Trader cards in current Clash. If at least one was Eliminated this way, choose gain 1 Influence or gain 1 Lore.",
				e174316: "While Active in a Clash, treat all printed information except Strength on opponents’ non-Heir Faction Cards in the Region as blank. Night: If an opponent’s Heir is Active in the Clash, Eliminate this card.",
				e177414: "When used to steal a Kingdom Card, treat the Occupying card as Strength 0.",
				e177415: "Autumn: If in a Council, place a Faction Marker on any Council. While in a Council, each marker on a Council contributes 1 vote to you. When removed from a Council, you may move this card to the Lost Pile.",
				e177416: "Day: Burn one of your cards in the Lost Pile. This card adds the Burned card’s printed Strength, Traits, Commands and rules text to its own until end of Round.",
				e177417: "While Active in current Clash, player with lowest total Strength above 0 wins the current Clash instead of highest.",
				e176700: "Your Faction Cards with no printed votes gain 1 vote. Autumn: Choose either to move a Trader from your Discard Pile to your Hand or to gain 1 Influence. If you are not first on the Order Track, you may do both.",
				e177000: "All your cards without Resilient gain Resilient. Spring: Move up to two Supporters from Lost Pile to a Region.",
				e177100: "Your Captains gain Day Flank. Whenever any of your cards are removed from a Council, you may move them to Hand. Day: Move any number of your Active cards with Flank into a Council.",
				e176800: "This card provides one additional Kingdom Occupying slot. Autumn: Choose a face-up Kingdom Card on the Great Road and acquire it with a Captain or Trader from your Hand. The acquired card may occupy only this slot.",
				e176900: "Whenever acquiring a Kingdom Card, place a Faction Marker on the matching Suit Council (max two per Council). Each gives 1 vote. Abilities removing cards from Councils may remove markers.",
				e177200: "When you acquire this card, place three Faction Markers on it. Day: Remove a marker from this card to grant an Active card in the current Clash Ambush until the end of the Round. You may remove another marker to allow that Ambush to use a card from the Discard Pile instead of the Hand.",
				e175000: "All your cards gain Pathfinder. Active cards also count as in Hand for Journeying.",
				e175001: "Spring: Gain 1 Influence if you have a card in any Council. If you have a card in each Council, may discard this card for additional 2 Influence.",
				e175002: "Your Followers gain 1 vote if first on Order Track, otherwise gain 2 votes.",
				e175003: "When you acquire this card, discard your Bidding card and place this card in your Supply. When you suffer Attrition, discard this card instead of reducing your Hand Size.",
				e175004: "Your Bidding and Occupying cards gain 5 Strength. When you are first to resolve your Bid, gain 1 Influence. You may not steal Kingdom Cards.",
				e175005: "Spring: Burn one of your Tactics to gain 1 Lore. If Unexhausted, gain additional 2 Lore.",
				e175006: "When you acquire this card, discard your Bidding card. Acquire a card with the lowest cost from your Site of Power; choose among tied cards. Then discard this card.",
				e175007: "Faction Cards with exactly 1 printed Lore gain 1 Lore.",
				e175008: "When attempting to steal a Kingdom Card, add 3 Strength to your stealing card. Whenever a Kingdom Card is stolen, gain 1 Influence. If an opponent steals this card, that opponent gains the 1 Influence instead.",
				e175009: "When you acquire this card, discard your Bidding card and place this card on a Region. Autumn: Govern with one of your Active cards in that Region.",
				e175010: "When you acquire this card, discard your Bidding card and place this card on a Location. Whenever any player claims that Location’s Reward, this card’s owner gains 1 Influence.",
				e175011: "Whenever Journeying with Pathfinder, gain 1 Influence and 1 additional Lore.",
				e175012: "Spring: If no Lore in Supply gain 1 Influence, otherwise gain 1 Lore.",
				e175013: "Spring: Move any card from your Discard Pile to Hand.",
				e175014: "You may activate your Favour even when you do not hold it. When you hold it, you may activate it twice, using a separate Action for each activation.",
				e175015: "Autumn: Discard one of your Council cards to increase Hand Size by one. Discard this.",
				e175016: "When you acquire this card, increase your Hand Size by 1. When this card is no longer Occupied, reduce your Hand Size by 1. Whenever you win a Clash in a Region where your Heir is Active, gain 1 Influence.",
				e175017: "Whenever one of your cards is removed from a Council, you may move it to your Hand. Whenever you Journey, you may move the cards used for that Journey to the bottom of your Deck.",
				e175018: "Spring: Choose any players. Each moves all Hand cards to bottom of Deck in any order, then draws same count.",
				e175019: "Spring: Swap a card in your Hand with one of your cards in a Council or one of your cards Occupying a Kingdom Card. Autumn: Repeat this Spring Action.",
				e175020: "Day: Reveal Hand; return all opponents’ current-Clash cards matching revealed printed Strength and/or Archetype to owners’ Hands. Discard this.",
				e175021: "Day: Move any number of your Supporters in current Region to another unresolved Region or Supply.",
				e175022: "Spring: Look at all face-down cards in a Region. May swap two of your face-down cards next to any Regions.",
				e175023: "Autumn: Move your Active card into a Council. Discard any number of cards in that Council. Discard this.",
				e175024: "Spring: Swap Hand card with your Lost Pile card.",
				e175025: "Spring: Burn this. Acquire up to two Great Road cards, Occupy with Hand cards.",
				e175026: "At Start of Year choose position of each marker on Order Track.",
				e175027: "Once per Round, you may activate an opponent’s Favour during its Step. If that opponent holds the Favour, do not rotate it.",
				e175028: "Day: Choose your current-Clash Active card. It copies any Lost Pile card for rest of Round except Strength remains unchanged.",
				e175029: "Spring: Choose Location. Move any number of Heralds there. Discard this.",
				e175030: "Autumn: Move all your Lost Pile cards to top or bottom of Deck in any order. Discard this.",
				e175031: "Autumn: Move your Active card to Hand.",
				e175032: "Whenever one of your cards is Eliminated, you may move it to your Hand.",
				e175033: "When you acquire this card, discard your Bidding card and place this card in your Supply. When acquiring a card from the Great Road, you may look at the top two face-down cards of the Kingdom Deck and treat them as face-up cards on the Great Road.",
				e175034: "Your Heirs gain Night Deadly and Day Retreat. When your Heir Eliminates cards gain 1 Influence. Night: If opponent Follower Active in Clash with your Heir, Eliminate your Heir.",
				e175035: "Followers / Cavalry gain Autumn Deploy(1). Autumn: Move a Follower from your Discard Pile to Hand.",
				e175036: "Cards with Autumn Deploy(1) gain Spring Deploy(1). Autumn: Place 1 Influence on your Active card with Deploy.",
				e175037: "Spring: All simultaneously play a Hand card. Discard matching Strengths; remaining highest Strength is winner; return un-discarded cards to owners’ Hands. Winner claims any Location Reward. Discard this.",
				e175038: "Your Heirs gain Day Flank.",
				e175039: "Day: Swap one of your Active cards in the current Clash with one of your cards in a Council or one of your cards Occupying a Kingdom Card.",
				e175040: "Your Heirs gain Autumn Deploy(1). If your Heir Eliminated, move it to Hand and discard this.",
				e175041: "Autumn: Move up to two Supporters from Map/Lost Pile to Player Board.",
				e175042: "When you acquire this card, discard your Bidding card and place this card on a Region. Halve opponents’ total Strength in that Region, rounding up. Winter: Discard this card.",
				e175043: "Day: Grant one of your Active cards in the current Clash Retreat until the end of the Clash. When that card Retreats, you may Journey with it.",
				e175044: "Day: Grant your current-Clash Active card Ambush until Clash end.",
				e175045: "Day: Gain 5 Strength in the current Clash. Discard this card and the card Occupying it.",
				e175046: "Spring: Place this card on a Region and discard the card Occupying it. Skip the Day and Night Steps of all Clashes in that Region. Winter: Discard this card.",
				e175047: "Autumn: Unexhaust a Tactic, follow Setup instructions. Discard this and its Occupying card.",
				e175048: "When you acquire this card, discard your Bidding card and place this card on a Region. Treat the printed information on opponents’ cards in that Region as blank, except for Strength and Archetype. Winter: Discard this card.",
				e175049: "Day: Grant your current-Clash Active card Deadly until Clash end. Discard this and its Occupying card.",
				e175050: "Day: Grant your current-Clash Active card Invulnerable until Clash end. Discard this.",
				e175700: "Before final scoring, gain 3 Influence. If your Influence is tied for the highest total, you win without applying a tiebreaker.",
				e175701: "When you acquire this card, Burn your Bidding card. Increase your Hand Size by 2, then discard this card.",
				e175702: "When you acquire this card, discard your Bidding card and place this card on a Location. Whenever you claim that Location’s Reward, gain 2 Influence, then Travel this card. Opponents who claim that Location’s Reward gain 1 Influence.",
				e175703: "Winter: Burn all your Lost Pile cards. Gain 2 Lore. If no card Burned, discard this instead.",
				e175704: "Acquisition: Burn Bid. Gain 7 Influence minus current Round number. Discard this.",
				e175705: "When you acquire this card, discard your Bidding card and place this card in your Supply. Your Supply provides unlimited Kingdom Occupying slots. When Occupying a Kingdom Card in one of these slots, discard the Bidding card that would Occupy it instead. Treat each Kingdom Card in these slots as Occupied by a card with Strength 0.",
				e175706: "Spring: For the rest of the Round, no player may claim Herald Rewards. Double all other Influence gains during that period. Then discard this card.",
				e175707: "Spring: Rearrange any number of cards, markers or tokens in any Councils to any other Councils.",
				e175708: "You may spend Lore to acquire cards from opponents’ Sites of Power. Treat the acquired cards as your Allies for the rest of the game.",
				e175709: "Autumn: Move any Lost Pile card to Hand. Treat it as yours for rest of game.",
				e175710: "Herald adds +5 Strength to first Clash per Round in its Region. Winter: Burn all your Map Supporters.",
				e175711: "Whenever one or more cards are Eliminated in a Clash, gain 1 Influence and 1 Lore.",
				e175712: "Spring: Treat all printed and gained Invulnerable abilities as blank for the rest of the Round.",
				e175713: "When you acquire this card, discard your Bidding card and place this card on a Region. Treat all Location Rewards in that Region as blank until the end of Summer. Autumn: Claim one Location Reward in that Region. Winter: Discard this card.",
				e175714: "Autumn: Give opponent 1 Influence and 1 Lore. Take an Exhausted Tactic from them into Supply, unexhaust and follow Setup. You control it.",
				e170700: "You place the Clash Markers this Round. When a Region resolves before rewards, gain 1 Influence if you have the most Supporters there and 1 Lore if you have the most Active cards there.",
				e170800: "Move any number of your Active and/or Discard Faction Cards to Hand, up to Hand Size.",
				e170900: "Move an opponent’s Occupied Kingdom Card to your Player Board and Occupy it with a card from Hand.",
				e171000: "Remove a marker: Your Active Heir, Captain, or War Machine in the current Region gains Day Flank for the rest of the Round. Exhaust this Tactic when no markers remain on it.",
				e171400: "Move two of your Supporters from current Region to Lost Pile. If you do, move one of your Lost Pile cards to current Region.",
				e171500: "Swap the position of two of your Active cards.",
				e171600: "Shuffle Kingdom Discard face-down; privately look at five random cards. Acquire one with a Hand card and return the rest to Kingdom Discard.",
				e171700: "Move up to three of your Active cards and/or cards in your Discard Pile to the Lost Pile; gain 1 Lore per card. Then you may move a card from your Discard Pile to your Hand.",
				e172000: "Your Heirs gain Night Deadly this Round. For the rest of the Round, whenever any of your cards Eliminate one or more cards, gain 1 Influence and 1 Lore.",
				e172100: "Choose an opponent and swap two of their face-down Faction Cards next to Regions. You may repeat this effect for any number of other opponents.",
				e172200: "Each opponent discards one Hand card for each Kingdom Card you Occupy.",
				e172300: "Remove a marker: Your Active card in the current Clash gains Day Retreat until the Clash ends. Exhaust this Tactic when no markers remain on it.",
				e172500: "This Round each of your Supporters contributes +1 additional Strength. In Winter your Map Supporters remain on their Regions instead of going to Lost Pile.",
				e172600: "After all Bidding cards are revealed, immediately set all opponents’ total Bidding Strength to 0 for this Round.",
				e172700: "Choose a Council and discard all opponents’ cards there. Move any number of your Council cards to top of Deck in any order; gain 1 Lore per card moved.",
				e172800: "Remove a marker: Choose a Region with one of your Active War Machines. Opponents cannot swap, add, or move Faction Cards into that Region during its first Clash this Round. Exhaust this Tactic when no markers remain on it.",
				e175100: "While this card is in a Council or Active in a Region, whenever one or more of your cards would be Eliminated, you may discard this card instead.",
				e175101: "Day, while this card is Active in the current Clash: This card gains Night Deadly until the end of the Round, and/or you may move one Active card in another Region to its owner’s Discard Pile. If you use either effect, this card cannot Retreat this Round.",
				e175102: "Autumn: Move up to three cards from your Discard Pile to the bottom of your Deck. If you do so, you cannot Rally this card to your Hand this Round.",
				e175103: "When this card Flanks, you may move any number of your Supporters and/or Active cards from its origin Region to its destination Region.",
				e175200: "If you win a Clash in a Region containing this card and its matching piece, gain 1 Influence and 1 Lore before claiming rewards. Winter: Return this card to your Supply unless it is in your Hand, in your Supply, or Burned.",
				e175300: "If you win a Clash in a Region containing this card and its matching piece, gain 1 Influence and 1 Lore before claiming rewards. Winter: Return this card to your Supply unless it is in your Hand, in your Supply, or Burned.",
				e175400: "If you win a Clash in a Region containing this card and its matching piece, gain 1 Influence and 1 Lore before claiming rewards. Winter: Return this card to your Supply unless it is in your Hand, in your Supply, or Burned.",
				e175500: "If you win a Clash in a Region containing this card and its matching piece, gain 1 Influence and 1 Lore before claiming rewards. Winter: Return this card to your Supply unless it is in your Hand, in your Supply, or Burned.",
				e177700: "",
				e177701: "",
				e177702: "",
				e177703: "Autumn: If this is the only Active Simulacrum card in its Region, move it to the highest-priority Ambition Region and place 1 Influence on it.",
				e177704: "Day: Draw two Simulacrum cards. Add the higher-tier card face down to the current Clash and discard the other.",
				e177705: "",
				e177706: "",
				e177707: "Autumn: If this is the only Active Simulacrum card in its Region, move it to the highest-priority Ambition Region and place 1 Influence on it.",
				e177708: "",
				e177709: "",
				e177710: "Day: Draw two Simulacrum cards. Add the higher-tier card face down to the current Clash and discard the other.",
				e177711: "",
				e177712: "",
				e177713: "",
				e177714: "",
				e177715: "",
				e177716: "",
				e177717: "",
				e178100: "Before the Day step: Reveal a new Threat. If the current Region has no Fog, place Fog there."
			},
			name: "The Old King’s Crown",
			desc: "Hidden-card clashes, shifting Councils and a struggle for the kingdom.",
			rules: "OBJECTIVE:\nFinish the final year with the most Influence in Supply. Break ties by the Kingdom’s Favour, then the Order Track; the Once Crown and chosen Forge rules may override this. Influence on cards sustains them and is not Supply Influence. If your Site of Power is empty at game end, gain 1 Influence per 2 remaining Lore.\n\nSTART OF YEAR:\nReorder from highest to lowest Influence, reversing previous order for ties. Draw up to Hand Size simultaneously, then bid one face-down Hand card. Reveal and resolve Bids from highest Strength, breaking ties by turn order. Acquire a Great Road card, steal an opponent’s Kingdom Card with strictly higher Strength than its Occupying card, or return your Bid to Hand. Your Bid Occupies the acquired card. Replace an existing Kingdom slot if necessary. After all Bids, discard the rightmost Road card, or two if no Road card was taken, then refill to four.\n\nPLACEMENT & SPRING:\nIn turn order place your Herald on a Location. Simultaneously place one face-down Hand card next to each Region. Resolve optional Spring Actions and Commands in turn order. Actions are normally once per player per year and may be used in any sequence before passing.\n\nSUMMER CLASHES:\nThe last player on the Order Track chooses Region order. Reveal the Region’s cards, take Day Actions, resolve simultaneous Night Effects, then total Strength. Count participating cards, Supporters that have not fought in an earlier Clash in this Region this year, and applicable bonuses. Highest Strength wins. Tied players may add a face-down Hand card for a new Clash; if all pass, nobody claims rewards. Earlier participants provide no Strength in the new Clash. Cards added face down during Day are later revealed and receive their own Day Actions.\n\nREWARDS:\nChoose a Location in the resolved Region. If your Herald is there, gain 1 Influence and steal 1 Influence from each opponent whose Herald is there. Then claim that Location’s reward:\n· Castle gives 1 Influence and allows an optional Govern action.\n· Wilderness gives 1 Influence and allows an optional Journey action.\n· Harvest Field gives 1 Influence and the Kingdom’s Favour.\n· Battlefield gives 2 Influence.\n· Shrine gives 1 Influence and allows you to move up to three Hand or Active cards to the bottom of your Deck.\n· Necropolis gives 1 Influence. Shuffle your Discard and draw up to three cards from it, then optionally discard Hand cards.\n\nAUTUMN:\nIn turn order, you may Govern once with a Hand card bearing Votes, placing it in a Council, and Journey once with a Hand card bearing Lore, gaining its Lore and moving it to Lost. Use optional Autumn Actions and Commands. Whenever Lore is gained, spend Supply Lore to acquire Advanced Faction Cards to Hand or HQ Cards to Supply from your Site of Power.\n\nCOUNCILS:\n\n· Relics: When claiming Herald Rewards, discard your Council cards for Influence equal to their Votes.\n· Secrets: In Autumn, place Faction Markers on Locations equal to Votes; four markers claim a Location Reward.\n· Oaths: Return map/Lost Supporters equal to Votes, plus one if you strictly lead that Council.\nCards leaving a Council normally go to Discard.\n\nWINTER & ATTRITION:\nResolve Winter Effects. Return Heralds and move map Supporters to Lost. Active cards without Influence go to Discard; cards with Influence remove one and remain Active. Advance the year. Attempting to draw from an empty Deck causes Attrition: shuffle Discard into Deck, reduce Hand Size by one, and draw up to the new Hand Size.\n\nTRAITS:\n\n· Invulnerable prevents Elimination.\n· Pathfinder sends Journeying cards to Discard instead of Lost.\n· Resilient sends Eliminated cards to Discard instead of Lost.\n\nCOMMANDS:\n\n· Ambush adds a face-down Hand Faction Card to the current Clash.\n· Retreat returns any of your current-Region Active cards to Hand and may return your Herald and Supporters to your Board.\n· Flank moves its card to an unresolved Region.\nAmbush, Retreat and Flank may each be used once per card per Clash.\n· Night Deadly Eliminates opposing participants; simultaneous Effects still resolve simultaneously.\n· Rally returns its stated Active cards to Hand.\n· Deploy plays its card face up from Hand and places its printed amount of Influence on it.\n\nFAVOUR & TACTICS:\nGaining the Kingdom’s Favour restores three uses. Spend a use when activating your Faction’s Favour; return it to Harvest Field after the last use. Tactics use their printed timings, Exhaustion and finite markers. Inspect cards for current Traits, Commands, copies and Boons; the Reference contains every card’s rules text.\n\nSIMULACRUM:\nAutomatic for solo play, or choose competitive/cooperative play with up to three humans. It follows Ambition and Scheme priorities. Top Deck tier and intent-back clues are public; hidden faces remain private. Threats normally apply in Regions with Fog. Inspect current Threats, Forge rules and Heat. Forge A/B sides modify rules and Heat throughout the game. In cooperative mode every human must exceed its final Influence. Its special rewards, Councils, Bids and cleanup follow the official solo rules automatically.\n\nWILD KINGDOM:\nSeven optional modules default off:\n· Aeronauts includes the Airship and four Allies.\n· Legendary Creatures adds matching pieces.\n· The Negotiating Table allows resource Barters, Agreements and Alliances, with at least three human players.\n· The Night Map changes the Location arrangement.\n· The Travelling Town adds its moving town.\n· The Whispering Tower adds the Tower and Boons.\n· Wild Kingdom Cards adds a chosen set of fifteen cards.\nFree-form Agreements require participant confirmation or rules-based arbitration by other players; future promises do not transfer resources automatically. Sharing an allied Hand requires its owner to enable it.",
			errors: { invalid: "当前无法执行此操作。" },
			ui: {
				setup: "Setup",
				year: "New year",
				spring: "Spring",
				summer: "Summer",
				autumn: "Autumn",
				winter: "Winter",
				done: "Game over",
				draw: "Draw cards",
				bid: "Choose a bidding card",
				resolveBid: "Resolve your bid",
				herald: "Place a Herald",
				deploy: "Deploy",
				negotiation: "Negotiation",
				clashOrder: "Choose the Clash order",
				reveal: "Reveal cards",
				day: "Day actions",
				night: "Night effects",
				outcome: "Clash outcome",
				reward: "Claim a reward",
				autumnAction: "Autumn actions",
				choose: "Choose",
				card: "Choose a card",
				placeCard: "Deploy a card",
				supporterRegion: "Choose a Supporter Region",
				supporters: "Place Supporters",
				pass: "Finish actions",
				skip: "Skip",
				confirm: "Confirm selection",
				selection: "Selected {{n}} / {{max}}",
				selectionHint: "Choose {{min}}–{{max}} options",
				waiting: "Waiting for other players",
				resolving: "Resolving",
				hand: "Hand",
				deck: "Deck",
				discard: "Discard Pile",
				lost: "Lost Pile",
				burned: "Burned",
				supply: "Supply",
				active: "Region cards",
				occupying: "Occupied Kingdom Cards",
				site: "Site of Power",
				council: "Choose a Council",
				councils: "Councils",
				road: "The Great Road",
				map: "Kingdom Map",
				players: "Players",
				details: "Card details",
				inspect: "Inspect",
				close: "Close",
				back: "Back",
				empty: "No cards",
				round: "Year {{n}} / {{total}}",
				influence: "Influence",
				lore: "Lore",
				strength: "Strength",
				votes: "Votes",
				cost: "Lore cost",
				handSize: "Hand Size",
				supporterSupply: "Supply Supporters",
				supporterLost: "Lost Supporters",
				favour: "Kingdom’s Favour",
				nobility: "The Nobility",
				clans: "The Clans",
				uprising: "The Uprising",
				gathering: "The Gathering",
				simulacrum: "The Simulacrum",
				opulence: "Council of Relics",
				mystery: "Council of Secrets",
				force: "Council of Oaths",
				region0: "Highlands",
				region1: "Midlands",
				region2: "Lowlands",
				location0: "Castle",
				location1: "Wilderness",
				location2: "Harvest Field",
				location3: "Battlefield",
				location4: "Shrine",
				location5: "Necropolis",
				reward0: "Gain 1 Influence, then Govern",
				reward1: "Gain 1 Influence, then Journey",
				reward2: "Gain 1 Influence and the Kingdom’s Favour",
				reward3: "Gain 2 Influence",
				reward4: "Gain 1 Influence; move up to three Hand or Active cards to the bottom of Deck",
				reward5: "Gain 1 Influence; shuffle your Discard Pile, draw up to three cards from it, then optionally discard Hand cards",
				agent: "Agent",
				captain: "Captain",
				cavalry: "Cavalry",
				champion: "Champion",
				follower: "Follower",
				heir: "Heir",
				ruse: "Ruse",
				trader: "Trader",
				warMachine: "War Machine",
				creature: "Legendary Creature",
				invulnerable: "Invulnerable",
				pathfinder: "Pathfinder",
				resilient: "Resilient",
				deadly: "Deadly",
				flank: "Flank",
				ambush: "Ambush",
				retreat: "Retreat",
				ambush_or_retreat: "Ambush or Retreat",
				rally2: "Rally any two cards",
				rallySelf: "Rally this card",
				deploy1_autumn: "Autumn: Deploy 1",
				deploy1_spring: "Spring: Deploy 1",
				bronze: "Bronze",
				silver: "Silver",
				gold: "Gold",
				hidden: "Face-down card",
				kingdom: "Kingdom Card",
				wild: "Wild Kingdom Card",
				hq: "Headquarters",
				tactic: "Tactic",
				aeronaut: "Aeronaut",
				boon: "Boon",
				forging: "Forge difficulty",
				heat: "Heat",
				threats: "Threats",
				fog: "Fog",
				ambition: "Ambition",
				scheme: "Scheme",
				deckTier: "Top deck tier",
				intentBack: "Region hint on back",
				modules: "Wild Kingdom Modules",
				airship: "Airship",
				town: "Travelling Town",
				tower: "Whispering Tower",
				log: "Game log",
				agreements: "Agreements and Alliances",
				alliedHands: "Shared allied hands",
				shareHand: "Share your hand with ally",
				hideHand: "Stop sharing your hand",
				agreementText: "Agreement text",
				agreementHint: "Enter the agreed terms",
				fulfilled: "Agreement fulfilled",
				cancelled: "Cancel agreement",
				breach: "Report a breach",
				promise: "Propose a non-binding agreement",
				tradeOffer: "Offered items",
				tradeCounter: "Counteroffer",
				tradeCards: "Trade Agreement Cards",
				mapMarker: "Map Faction Marker",
				councilMarker: "Council Faction Marker",
				yearOption: "Game length",
				years4: "Short: 4 years",
				years5: "Standard: 5 years",
				years6: "Extended: 6 years",
				advancedSetup: "Advanced Setup",
				advancedHint: "Mulligan and choose one of five starting Kingdom Cards",
				factionOption: "Player factions",
				random: "Random faction",
				seat: "Seat {{n}}",
				simMode: "Simulacrum mode",
				auto: "Automatic in solo play",
				off: "Off",
				competitive: "Competitive",
				cooperative: "Cooperative",
				simHint: "Simulacrum supports 1–3 players; Negotiating Table requires at least 3",
				forgeOption: "Forge cards",
				forgeValue: "Value",
				none: "Disabled",
				threatOption: "Selected Threats",
				advancedSimOption: "Advanced Simulacrum cards",
				aeronauts: "Aeronauts",
				creatures: "Legendary Creatures",
				negotiating: "Negotiating Table",
				nightMap: "Night Map",
				wildCards: "Wild Kingdom Cards",
				enabled: "Enabled",
				resultTitle: "The Crown is claimed",
				resultWin: "{{name}} claims the Crown",
				resultCoopWin: "The alliance defeats the Simulacrum",
				resultCoopLoss: "The Simulacrum claims the Crown",
				resultTotal: "Final Influence",
				resultTiebreak: "Kingdom’s Favour / Order Track",
				reviewBoard: "Review the kingdom",
				showResult: "Show results",
				exitConfirm: "Leave this game?",
				hintCount: "Hints used: {{n}}",
				autopilot: "Autopilot share",
				exhausted: "Exhausted",
				ready: "Available",
				uses: "{{n}} uses left",
				guards: "Occupying card",
				copied: "Copied abilities",
				gained: "Gained abilities",
				influenceOnCard: "Influence on card",
				keep: "Keep hand",
				mulligan: "Mulligan",
				acquire: "Acquire a Kingdom Card",
				steal: "Steal a Kingdom Card",
				returnBid: "Return your bidding card to Hand",
				startingKingdomGuard: "Choose a Kingdom Card and its Occupying card",
				emptySlot: "Use empty slot {{n}}",
				replaceKingdom: "Replace a Kingdom Card",
				govern: "Govern",
				journey: "Journey",
				secrets: "Council of Secrets action",
				oaths: "Council of Oaths action",
				region: "Choose a Region",
				location: "Choose a Location",
				player: "Choose a player",
				count: "Quantity",
				regionOrder: "Region order",
				claimFavour: "Claim the Kingdom’s Favour",
				returnHand: "Return to Hand",
				moveLost: "Move to the Lost Pile",
				deckTop: "Place on top of Deck",
				deckBottom: "Place on bottom of Deck",
				markers: "Faction Markers",
				discardCouncil: "Discard a Council card",
				discardHand: "Discard a Hand card",
				discardDeckTop: "Discard the top Deck card",
				discardForInfluence: "Discard to gain Influence",
				activateTactic: "Activate a Tactic",
				refreshTactic: "Unexhaust a Tactic",
				burnTactic: "Burn a Tactic",
				cardInfluence: "Influence on card",
				boonCard: "Place a Boon on a card",
				allowElimination: "Allow elimination",
				ambushDiscard: "Ambush from Discard Pile",
				lostSupporter: "Recall a Lost Supporter",
				recallSupporter: "Recall a Supporter",
				returnHerald: "Return a Herald",
				playerHerald: "Choose a player’s Herald",
				locationReward: "Claim a Location Reward",
				protectHeirs: "Protect Heirs",
				gainDeadly: "Gain Deadly",
				sacrificePeregrine: "Discard the Peregrine to protect cards",
				proposeBarter: "Propose a Barter",
				proposeAgreement: "Propose an Agreement",
				proposeAlliance: "Propose an Alliance",
				finishNegotiation: "Finish negotiation",
				requestCounteroffer: "Request a counteroffer",
				submitCounteroffer: "Submit counteroffer",
				clearOffer: "Clear offer",
				cancelBarter: "Cancel Barter",
				acceptBarter: "Accept Barter",
				makeCounteroffer: "Make a counteroffer",
				decline: "Decline",
				nonbindingAgreement: "Non-binding Agreement",
				bindingAgreement: "Binding Agreement",
				acceptAgreement: "Accept Agreement",
				confirmBreach: "Confirm breach",
				denyBreach: "Deny breach",
				noWinner: "Choose no winner",
				visitAeronauts: "Visit the Aeronauts",
				visitTown: "Visit the Travelling Town",
				visitTower: "Visit the Whispering Tower",
				exploreLabyrinth: "Explore the Labyrinth",
				explorePinnacle: "Explore the Pinnacle",
				leaveTower: "Leave the Tower",
				protectBatch: "Choose whether to prevent elimination",
				recoverCouncil: "Recover a card removed from a Council",
				recoverEliminated: "Recover an Eliminated card",
				buySite: "Acquire a Site of Power card",
				occupy: "Choose an Occupying card",
				occupySlot: "Choose a Kingdom slot",
				placeSupporters: "Place Supporters",
				allyBid: "Bid with an Allied card",
				allyDeploy: "Deploy an Allied card",
				startingKingdom: "Choose a starting Kingdom Card",
				tieCard: "Add a card to the tied Clash",
				orderPlayer: "Place a player on the Order Track",
				chooseResource: "Choose a resource",
				clansSupporters: "Move Clan Supporters",
				deckEnd: "Choose a Deck end",
				discardBoons: "Discard Boons",
				doorDiscard: "Choose the Ambush source",
				falseOrders: "Swap opposing face-down cards",
				flankSupporters: "Move Supporters with the Flank",
				foragers: "Choose a Forager action",
				forgeElimination: "Choose a Simulacrum elimination",
				giveBoon: "Give a Boon",
				harbour: "Return Harbour Supporters",
				journeyDestination: "Choose the Journey destination",
				lantern: "Move Supporters with the Lantern",
				martialLaw: "Choose a Martial Law target",
				monument: "Monument Builders",
				moonshineRoad: "Acquire a Great Road card",
				necropolisCount: "Choose how many cards to recover",
				negotiate: "Negotiate",
				placeBoons: "Place Boons",
				rearrangeCouncils: "Rearrange the Councils",
				regalGuard: "Choose a Regal Guard action",
				relics: "Search for Kingdom relics",
				roadAcquire: "Acquire a card from the Great Road",
				royalBank: "Choose a Royal Bank benefit",
				royalSeal: "Choose whether to use the Royal Seal",
				rumoursPlayers: "Choose players to redraw",
				secretLocation: "Place a Secrets marker",
				secretReward: "Claim a Secrets reward",
				simActionOrder: "Choose Simulacrum action order",
				simAutumnLoss: "Pay the Autumn loss",
				simHerald: "Move a Simulacrum Herald",
				simShrineDiscard: "Choose cards to discard",
				simThreatInfluence: "Resolve Threat Influence loss",
				sirenHeralds: "Move Heralds to the Siren’s Pool",
				sirenLocation: "Choose the Siren’s Pool Location",
				supporterCount: "Choose a Supporter count",
				towerAscend: "Ascend the Whispering Tower",
				towerLabyrinth: "Explore the Labyrinth",
				towerMove: "Move the Whispering Tower",
				towerPinnacleChoice: "Choose a Pinnacle reward",
				townAcquire: "Acquire a Travelling Town card",
				townReplace: "Replace a Town card",
				waxwing: "Waxwing action",
				witchTrial: "Witch Trial",
				airPlace: "Move the Airship",
				agreementAccept: "Review Agreement",
				agreementCompose: "Compose Agreement",
				agreementResolve: "Confirm Agreement outcome",
				allianceWinner: "Choose the Alliance winner",
				arbitrateAgreement: "Arbitrate Agreement breach",
				auctionTactic: "Choose an auctioned Tactic",
				barterInvitation: "Respond to a Barter invitation",
				barterReview: "Review Barter",
				boonGovernJourney: "Choose a Boon action",
				boonTower: "Choose a Tower Boon",
				tradeCompose: "Compose Barter offer",
				acquiredSite: "Acquired a Site of Power card",
				activated: "Activated an ability",
				attrition: "Suffered Attrition",
				barter: "Completed a Barter",
				eliminated: "Card Eliminated",
				outrage: "Outrage at a breach",
				revealedThreat: "Revealed a Threat",
				acquiredKingdom: "Acquired a Kingdom Card",
				stoleKingdom: "Stole a Kingdom Card",
				wonClash: "Won a Clash",
				wonCouncil: "Won a Council",
				trade_influence: "Gain Influence",
				trade_lore: "Gain Lore",
				trade_supporters: "Place Supporters",
				trade_tradeCards: "Trade Agreement Cards",
				trade_hand: "Hand",
				trade_site: "Site of Power",
				trade_kingdom: "Kingdom Card",
				trade_tactic: "Tactic",
				trade_boon: "Boon",
				trade_mapMarker: "Map Faction Marker",
				trade_councilMarker: "Council Faction Marker",
				trade_favour: "Kingdom’s Favour",
				nobilityFavour: "The Nobility Favour",
				clansFavour: "The Clans Favour",
				uprisingFavour: "The Uprising Favour",
				gatheringFavour: "The Gathering Favour",
				activate: "Activate ability",
				activateBoon: "Activate Boon",
				beacon: "Choose a Site card from the Beacon",
				beyondLights: "Beyond the Lights action",
				blueHour: "Order your Lost cards",
				boonSwap: "Swap cards with a Boon",
				copyLost: "Copy a Lost card",
				diary: "Courtier’s Diary action",
				discardActive: "Discard an Active card",
				door: "Use the Door in the Night",
				embassy: "Use the Wandering Embassy",
				engineers: "Use the Engineers’ Workshop",
				estate: "Use the Abandoned Estate",
				flankCards: "Move cards with a Flank",
				grantAbility: "Grant a card an ability",
				grantRetreat: "Grant Retreat",
				handOrder: "Order the cards",
				heraldMoon: "Herald of the Moon",
				hiddenLanes: "Use Hidden Lanes",
				laboratory: "Use the Laboratory",
				medic: "Use the Field Medic",
				mirror: "Use the Shapeshifter’s Mirror",
				moonshine: "Use Moonshine Cove",
				opponentFavour: "Use an opponent’s Favour",
				placeAirship: "Choose the Airship position",
				queenGovern: "Govern with the Queen, Long Ago",
				rally: "Rally cards",
				retreatCards: "Retreat cards",
				retreatPieces: "Choose pieces to Retreat",
				returnFollower: "Recover a Follower",
				ritualSacrifice: "Burn a ritual card",
				riverRunners: "Use River Runners",
				safehouses: "Use Safehouses",
				saltToughness: "Use Salt Toughness",
				schoolStars: "Use the School of Stars",
				seaLanes: "Use Sea Lanes",
				shrine: "Move cards to the bottom of Deck",
				spySwap: "Swap inspected face-down cards",
				swapHand: "Choose a Hand card to swap",
				swapHidden: "Swap face-down positions",
				swapTarget: "Choose a swap target",
				tooth: "Use the Ritual of the Tooth",
				tourney: "Choose a Grand Tourney card",
				witchOwn: "Choose your own Trial card",
				visit: "Visit",
				proposed: "Awaiting acceptance",
				expired: "Expired",
				declined: "Declined",
				reference: "Reference",
				boons: "Boons",
				abilities: "Traits and Commands",
				left: "Left",
				right: "Right",
				stealIntent: "Prioritize stealing Kingdom Cards",
				acquireIntent: "Prioritize the Great Road",
				cycle: "Place Supporters cyclically",
				first: "Place all Supporters in the first Region",
				simAmbush: "Simulacrum Ambush",
				simArmature: "Simulacrum Armature action",
				simRally: "Simulacrum Rally",
				simPall: "Out of the Pall",
				simFrontlines: "Fading Frontlines",
				simPickedOff: "Picked Off",
				simWhispers: "Whispers at Court",
				simPitchBlack: "Pitch Black Night",
				cancel: "Cancel",
				resultTie: "The Crown is shared",
				resultSimWin: "The Simulacrum claims the Crown",
				resultCoopHint: "The alliance shares the cooperative result",
				resultWaiting: "Waiting for the host",
				playAgain: "Play again",
				backToLobby: "Back to lobby",
				playAgainConfirm: "Start a new game?",
				confirmExit: "Leave game",
				finalYear: "Year {{n}} of the kingdom",
				score: "Final Influence",
				pendingSubject: "Choice for {{name}}",
				boonOnCard: "Attached Boons",
				favourOwner: "Kingdom’s Favour: {{name}}",
				noneOwner: "Unclaimed",
				mapMarkers: "Location markers",
				supporterLostCount: "Lost {{n}}",
				orderTrack: "Order Track",
				bidCards: "Bidding cards",
				forgeHeat: "Heat adjustment",
				seasonSetup: "Setup",
				seasonYear: "Start of Year",
				seasonSpring: "Spring",
				seasonSummer: "Summer",
				seasonAutumn: "Autumn",
				seasonWinter: "Winter",
				currentChoice: "Current choice",
				agreementActive: "Agreement active",
				clashWon: "Won the Clash",
				clashTied: "Clash tied",
				creatureHerald: "Place the Legendary Creature Herald",
				fought: "Took part in an earlier Clash",
				confirmFulfilled: "Confirm the agreement was fulfilled",
				confirmCancellation: "Confirm cancellation",
				broken: "Breached",
				supporter: "Supporter",
				resolved: "Resolved"
			},
			reference: {
				nforge1a: "Vanguard",
				eforge1a: "Setup: The Simulacrum starts with 1 Supporter in Supply. Winter: Return up to 1 map Supporter to Supply instead of 3.",
				nforge1b: "Relentless",
				eforge1b: "Setup: The Simulacrum starts with 5 Supporters in Supply. Winter: Return up to 5 map Supporters to Supply instead of 3.",
				nforge2a: "Clear Skies",
				eforge2a: "When the Principal Threat places Fog, place one fewer, to a minimum of one.",
				nforge2b: "Grey Days",
				eforge2b: "When the Principal Threat places Fog, place one more, to a maximum of three.",
				nforge3a: "Prosperity",
				eforge3a: "Human players start with Hand Size 7.",
				nforge3b: "Famine",
				eforge3b: "Human players start with Hand Size 5.",
				nforge4a: "Unified",
				eforge4a: "Setup: Each human gains X Influence. Reduce Heat by X.",
				nforge4b: "Divided",
				eforge4b: "Setup: The Simulacrum gains 2X Influence. Increase Heat by X.",
				nforge5a: "The Road Is Clear",
				eforge5a: "Human Site of Power cards cost 1 less Lore, to a minimum of 1.",
				nforge5b: "The Road Is Watched",
				eforge5b: "Human Site of Power cards cost 1 more Lore.",
				nforge6a: "Late Reinforcements",
				eforge6a: "The Simulacrum spends 4 Lore per Site of Power card instead of 3.",
				nforge6b: "Early Reinforcements",
				eforge6b: "The Simulacrum spends 2 Lore per Site of Power card instead of 3.",
				nforge7a: "The Kingdom Endures",
				eforge7a: "The Simulacrum gains no bonuses from its Occupied Kingdom Cards.",
				nforge7b: "The Kingdom Falters",
				eforge7b: "The Simulacrum triggers its Occupied Kingdom Card bonuses twice.",
				nforge8a: "The People Resist",
				eforge8a: "When the Simulacrum would gain the Kingdom’s Favour, leave it in place and gain 1 Influence instead.",
				nforge8b: "Turncoats",
				eforge8b: "During Setup and each Start of Year, reveal two Threats instead of one.",
				nforge9a: "Erratic",
				eforge9a: "The Simulacrum is always first on the Order Track.",
				nforge9b: "Ruthless",
				eforge9b: "The Simulacrum is always last on the Order Track.",
				nforge10a: "Exiled",
				eforge10a: "At the end of Simulacrum Setup, move its top Deck card to the top of its Site of Power.",
				nforge10b: "Bolstered",
				eforge10b: "At the end of Simulacrum Setup, move its top Site of Power card to the top of its Deck.",
				nforge11a: "Eat the Strong",
				eforge11a: "When the Simulacrum reshuffles its empty Deck, move a random Gold card from it to the Lost Pile.",
				nforge11b: "Eat the Weak",
				eforge11b: "When the Simulacrum reshuffles its empty Deck, move a random Bronze card to the Lost Pile, or a Silver card if there are no Bronze cards.",
				nforge12a: "Sentry Towers",
				eforge12a: "Setup: Place a tower on three different random Locations. When the Simulacrum claims a Location Reward there, remove the tower instead.",
				nforge12b: "Strange Towers",
				eforge12b: "Setup: Place a tower on three different random Locations. When a human claims a Location Reward there, remove the tower instead.",
				nforge13a: "Intentions Gleaned",
				eforge13a: "Reveal the current Ambition before placing Bids.",
				nforge13b: "Intentions Masked",
				eforge13b: "Draw Ambitions from the bottom of their Deck. Discarded Ambitions go on top.",
				nforge14a: "It Moves in the Open",
				eforge14a: "Reveal the Scheme when revealing the current Ambition.",
				nforge14b: "It Moves Unseen",
				eforge14b: "Draw Schemes from the bottom of their Deck. Discarded Schemes go on top.",
				nforge15a: "High Morale",
				eforge15a: "Clash ties count as human wins. Tied final Influence is a human victory before other tiebreakers.",
				nforge15b: "Low Morale",
				eforge15b: "Clash ties count as Simulacrum wins. Tied final Influence is a Simulacrum victory before other tiebreakers.",
				nforge16a: "Hidden Caches",
				eforge16a: "A human may refresh an Exhausted Tactic and place 2 Influence here. At game end, add the Influence here to Heat.",
				nforge16b: "Sabotage!",
				eforge16b: "Setup: Randomly Exhaust X Tactics. Add 2 Heat per Tactic, with X from 0 to 4.",
				nforge17a: "Veterans",
				eforge17a: "Each human Supporter contributes 2 Strength instead of 1.",
				nforge17b: "Augmented",
				eforge17b: "Each Simulacrum Supporter contributes 2 Strength instead of 1.",
				nforge18a: "Luck Is on Our Side",
				eforge18a: "Human Heirs gain Invulnerable.",
				nforge18b: "Luck Is on Its Side",
				eforge18b: "Simulacrum Heirs gain Invulnerable and Autumn Rally (self).",
				nforge19a: "Simulacrum’s Bane",
				eforge19a: "Human Heirs gain Night Deadly.",
				nforge19b: "Simulacrum’s Blade",
				eforge19b: "Simulacrum Heirs gain Night Deadly and Autumn Rally (self).",
				nforge20a: "Has No Voice",
				eforge20a: "The Simulacrum does not Govern in Autumn.",
				nforge20b: "Speaks with Many Voices",
				eforge20b: "The Simulacrum Governs twice in Autumn instead of once.",
				nforge21a: "Fair Winds",
				eforge21a: "Human players may choose the Location when the Simulacrum places its Herald.",
				nforge21b: "The Deep Fog",
				eforge21b: "When revealing the Scheme, move the Simulacrum Herald to its highest-priority Region, using the Ambition arrow for the Location.",
				nforge22a: "They Fade Like Mist",
				eforge22a: "All Simulacrum cards lose Resilient.",
				nforge22b: "They Move Like Mist",
				eforge22b: "Simulacrum cards with Deadly gain Invulnerable.",
				nforge23a: "Feeble Presence",
				eforge23a: "The Simulacrum gains no Herald Rewards.",
				nforge23b: "Intimidating Presence",
				eforge23b: "Double Simulacrum Influence from all Herald Rewards, including theft from human Heralds and Council of Relics bonuses.",
				nforge24a: "Waning Resources",
				eforge24a: "When its Site of Power is empty, the Simulacrum converts 3 Lore into 1 Influence instead of 2.",
				nforge24b: "Overflowing Resources",
				eforge24b: "When its Site of Power is empty, the Simulacrum converts 1 Lore into 1 Influence instead of 2.",
				nforge25a: "Reclusive",
				eforge25a: "The Simulacrum never attempts to steal human Kingdom Cards.",
				nforge25b: "Invasive",
				eforge25b: "The Simulacrum always prioritizes stealing human Kingdom Cards when resolving its Bid.",
				nforge26a: "Always Lost",
				eforge26a: "The Simulacrum does not Journey in Autumn.",
				nforge26b: "Always Searching",
				eforge26b: "The Simulacrum Journeys twice in Autumn instead of once.",
				nforge27a: "Hidden Trinkets",
				eforge27a: "A human resolving their Bid first gains 1 Influence.",
				nforge27b: "Plundered Vaults",
				eforge27b: "The Simulacrum gains 1 Influence if it resolves its Bid first.",
				nforge28a: "Sympathy & Sacrifice",
				eforge28a: "Whenever one or more cards are Eliminated, humans choose 1 Influence, 1 Lore, or return one of their map/Lost Supporters to their Player Board.",
				nforge28b: "Bloodthirsty",
				eforge28b: "Whenever one or more cards are Eliminated, the Simulacrum gains by its Ambition Suit: Relics, 1 Influence; Secrets, 1 Lore; Oaths, both.",
				nforge29a: "Unfortified",
				eforge29a: "Setup: The Simulacrum starts with one Advanced Faction Card on its Site of Power instead of three.",
				nforge29b: "Fortified",
				eforge29b: "Setup: The Simulacrum starts with five Advanced Faction Cards on its Site of Power instead of three.",
				nforge30a: "Weary Traveller",
				eforge30a: "Simulacrum Bidding Tokens have 3 less Strength, to a minimum of 1.",
				nforge30b: "Forced March",
				eforge30b: "Simulacrum Bidding Tokens have 3 more Strength.",
				nthreat1: "Knives Drawn",
				ethreat1: "All Active Simulacrum cards in Fog Regions gain Night Deadly.",
				nthreat2: "Cloaked in Mist",
				ethreat2: "All Active Simulacrum cards in Fog Regions gain Invulnerable.",
				nthreat3: "Strongholds of Smoke",
				ethreat3: "Before Rally, place 1 Influence on the highest-Strength Simulacrum card in each Fog Region. It will not Rally cards with Influence this year.",
				nthreat4: "Siren Songs",
				ethreat4: "After a Fog Region Clash, before rewards: If it lost, place 1 Influence on the Ambition Council; if it won, gain Influence equal to that Council’s Influence.",
				nthreat5: "Larger Than Life",
				ethreat5: "The Simulacrum gains 3 Strength in each Fog Region.",
				nthreat6: "Out of the Pall",
				ethreat6: "If its Active cards in the current Fog Region are only Bronze and/or Silver, draw the top Simulacrum Deck card and make it Active there.",
				nthreat7: "Lost in the Fog",
				ethreat7: "Humans cannot activate Rally or Retreat Commands in Fog Regions.",
				nthreat8: "Plans Set in Motion",
				ethreat8: "The Simulacrum gains 1 Influence when it wins a Clash in a Fog Region.",
				nthreat9: "Fading Frontlines",
				ethreat9: "For each Active Simulacrum card in the Fog Region, humans discard a Hand card; for each they cannot discard, discard one of their current-Region cards instead.",
				nthreat10: "Towering Silhouette",
				ethreat10: "The Simulacrum gains 5 Strength in each Fog Region.",
				nthreat11: "Whispers at Court",
				ethreat11: "In each Fog Region, humans move an Active card there to Lost or discard a Council card. If neither is possible, the Simulacrum gains 2 Influence.",
				nthreat12: "Hearts & Minds Falter",
				ethreat12: "Double Simulacrum Herald Reward Influence in Fog Regions, including Council of Relics bonuses.",
				nthreat13: "Sightings of Pyres",
				ethreat13: "After it loses a Fog Region Clash, before rewards, humans Burn a random Site card. With no Site cards, return all Supply Lore to the Reserve.",
				nthreat14: "Signal Fires",
				ethreat14: "Before Rally, the Simulacrum gains 3 Lore if any Fog Region has at least one Active Simulacrum card.",
				nthreat15: "Pitch Black Night",
				ethreat15: "Humans move one of their Active cards from each occupied Fog Region to the Lost Pile.",
				nthreat16: "Overrun",
				ethreat16: "Human cards in Fog Regions treat printed Invulnerable and Resilient as blank.",
				nthreat17: "Their Great Work",
				ethreat17: "Each time it wins a Fog Region Clash, the Simulacrum gains 3 Influence and 3 Lore.",
				nthreat18: "Time Moves Strangely",
				ethreat18: "In each Fog Region, if the first Clash would be a human win, treat it as tied and start a new Clash.",
				nthreat19: "Fog Walls",
				ethreat19: "Humans cannot activate Ambush or Flank Commands in Fog Regions.",
				nthreat20: "Picked Off",
				ethreat20: "Human cards with Strength 4 or less in the current Fog Region Clash move to the Lost Pile.",
				nthreat21: "Vanishing Landmarks",
				ethreat21: "Humans cannot claim Fog Region Location Rewards on the side indicated by the current Ambition arrow.",
				nthreat22: "Rolling Harr",
				ethreat22: "Immediately after revealing this Threat, reveal another Threat.",
				nthreat23: "Show of Strength",
				ethreat23: "After Night effects in a Fog Region, the Simulacrum steals 1 Influence for each of its Active cards stronger than the strongest human card in the Clash.",
				nthreat24: "We Are Many",
				ethreat24: "All Simulacrum cards in Fog Regions gain the Follower Archetype. It gains 1 Influence on winning a Fog Region Clash.",
				nboon0: "Day Swap",
				eboon0: "Day: Swap this card with a card in your Hand.",
				nboon1: "Revealed Rout",
				eboon1: "When revealed: Move all Supporters in the Region to the Lost Pile.",
				nboon2: "Autumn Influence",
				eboon2: "Autumn: Place 1 Influence on this card.",
				nboon3: "Winning Hand",
				eboon3: "On winning the Clash: Increase Hand Size by 1.",
				nboon4: "Winning Reward",
				eboon4: "On winning the Clash: Claim a Location Reward in this Region.",
				nboon5: "Rally Two",
				eboon5: "Autumn: Rally any two cards.",
				nboon6: "Winning Sacrifice",
				eboon6: "On winning the Clash: Gain 2 Influence and 2 Lore, then Burn this card.",
				nboon7: "Invulnerable",
				eboon7: "This card gains Invulnerable.",
				nboon8: "Ambush",
				eboon8: "This card gains Day Ambush.",
				nboon9: "Deadly Price",
				eboon9: "This card gains Night Deadly. After the Clash, Burn this card.",
				nboon10: "Winning Councils",
				eboon10: "On winning the Clash: Activate the Councils of Secrets and Oaths.",
				nboon11: "Winning Ascent",
				eboon11: "On winning the Clash: You may visit the Whispering Tower.",
				nboon12: "Flank",
				eboon12: "This card gains Day Flank.",
				nboon13: "Ten Strength",
				eboon13: "This card gains 10 Strength. After the Clash, Burn this card.",
				nboon14: "Autumn Service",
				eboon14: "Autumn: Journey or Govern with this card.",
				nboon15: "Dismiss the Weak",
				eboon15: "Day: Discard all cards with Strength 3 or less in this Clash.",
				nboon16: "Command Lock",
				eboon16: "During this Clash, opponents cannot activate or trigger Commands.",
				nboon17: "Lost Swap",
				eboon17: "Day: Swap this card with one of your Lost Pile cards.",
				nboon18: "Five Strength",
				eboon18: "This card gains 5 Strength.",
				nboon19: "Winning Gains",
				eboon19: "On winning the Clash: Gain 1 Influence and 1 Lore."
			}
		}
	}
};
//#endregion
export { dn as default };
