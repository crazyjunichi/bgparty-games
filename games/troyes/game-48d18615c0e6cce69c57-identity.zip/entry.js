import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { Texture as d } from "@bgparty/sdk/texture";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { seatName as te } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { Floater as g, FlySprite as _, PulseBox as ne } from "@bgparty/sdk/fx/primitives";
import { IconBot as v, IconExpand as re } from "@bgparty/sdk/icons";
import { Confetti as ie } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as y } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as b, OptionSection as x, OptionSwitch as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/troyes/data.ts
var C = [
	"w",
	"r",
	"y"
], w = "artisan y 1 5 4 2,1 immediate base\nmerchant y 1 4 2 2,1 immediate base\nmiller y 1 5 4 2,1 immediate base\ninnkeeper y 2 5 1 3,2 immediate base\nblacksmith y 2 5 3 3,2 delayed base\nmilitiaman y 2 6 3 3,2 delayed base\njourneyman y 3 5 4 2,1 immediate base\ngoldsmith y 3 8 4 3,2 immediate base\nsculptor y 3 15 3 6,5 immediate base\ntithe w 1 6 4 3,2 delayed base\nmonk w 1 6 3 3,2 delayed base\npriest w 1 6 3 3,2 delayed base\napprenticeship w 2 6 3 3,2 delayed base\nconfession w 2 7 5 3,2 delayed base\ntemplar w 2 7 5 3,2 delayed base\npilgrimage w 3 0 7 1,1 immediate base\nprocession w 3 5 4 3,2 immediate base\nglassblower w 3 7 5 3,2 immediate base\narcher r 1 6 2 3,2 immediate base\nchivalry r 1 6 4 2,1 immediate base\ndiplomat r 1 6 3 2,1 immediate base\nhunting r 2 5 3 3,1 immediate base\nmercenary r 2 2 2 1 immediate base\ntaxCollector r 2 6 5 2,1 immediate base\ncaptain r 3 7 4 3,2 immediate base\njoust r 3 5 3 3,2 immediate base\ntroubadour r 3 7 3 3,2 immediate base\nbaker y 1 5 3 2,1 immediate bonus\nprior w 2 8 3 4,3 delayed bonus\nbanquet r 3 7 4 3,2 immediate bonus\nlumberjack y 1 2 2 1 mixed ladies\nclogMaker y 1 3 2 1 immediate ladies\nweaver y 1 4 2 2,1 immediate ladies\nlandlady y 2 5 4 2,1 immediate ladies\ndistiller y 2 4 2 2,1 delayed ladies\nviticulturist y 2 5 3 3,2 delayed ladies\nbanker y 3 6 5 2,1 immediate ladies\nbreeder y 3 5 2 3,2 mixed ladies\nmasterTradesman y 3 8 4 3,2 immediate ladies\naugustine w 1 5 3 2,1 delayed ladies\nbishop w 1 5 3 2,1 immediate ladies\nchiefTemplar w 1 -5 3 4,2 delayed ladies\nherbalist w 2 8 6 2,1 delayed ladies\nmasterBuilder w 2 5 4 2,1 immediate ladies\npreacher w 2 3 4 1 delayed ladies\nscribe w 3 6 5 2,1 immediate ladies\nhermit w 3 5 5 2 end ladies\nnun w 3 8 4 4,2 immediate ladies\nransom r 1 2 2 1 immediate ladies\ncatapult r 1 6 3 2,1 mixed ladies\nscout r 1 3 8 2,1 immediate ladies\nsquire r 2 7 2 2,1 mixed ladies\nexecutioner r 2 5 3 2,1 immediate ladies\nrecruiter r 2 -3 3 2,1 delayed ladies\nmarriage r 3 6 6 3,2 immediate ladies\nfort r 3 6 0 1,1 end ladies\nprincess r 3 8 4 3,3 end ladies".split("\n").map((e) => {
	let [t, n, r, i, a, o, s, c] = e.split(" ");
	return {
		id: t,
		color: n,
		level: +r,
		cost: Math.abs(+i),
		influence: +i < 0,
		divisor: +a,
		slots: o.split(",").map(Number),
		timing: s,
		scope: c
	};
}), T = (e) => w.find((t) => t.id === e), E = "marauding any 3 4 2,1 1 - none base\ndrought y 4 3 3,1 0 - drought base\nsupport y 3 4 3,1 0 - support base\ncivilWar y 4 4 3,2 0 - civilWar base\nwayfarers y 3 4 3,1 0 - wayfarers base\ntheologicalConflict w 4 3 3,1 0 - theologicalConflict base\nheresy w 3 5 3,2 0 - heresy base\ntravelingBuilders w 4 4 3,2 0 - travelingBuilders base\ninterruptedWork w 4 4 3,1 0 - interruptedWork base\nbrigands1 r 3 4 3,1 1 y none base\nbrigands2 r 3 4 3,1 1 y none base\nbrigands3 r 3 4 3,1 1 y none base\nskirmishes1 r 3 3 2,1 1 w none base\nskirmishes2 r 3 3 2,1 1 w none base\nwar r 2 7 2,1 2 w none base\nnormansAttack r 5 4 4,2 2 w none base\nsuccession r 4 5 4,2 0 y succession base\nresistance r 6 4 3,2 0 y resistance bonus\nwolves y 5 2 2,1 1 - none ladies\nharshWinter y 5 1 2,1 0 - harshWinter ladies\nchiefOutlaw r 16 1 6,0 0 w chiefOutlaw ladies\nuprising r 4 6 5,2 0 y uprising ladies\neventMonk w 5 4 4,2 0 - eventMonk ladies\npossession w 5 4 3,2 0 - possession ladies".split("\n").map((e) => {
	let [t, n, r, i, a, o, s, c, l] = e.split(" ");
	return {
		id: t,
		color: n,
		divisor: +r,
		flags: +i,
		prizes: a.split(",").map(Number),
		black: +o,
		...s === "-" ? {} : { call: s },
		effect: c,
		scope: l
	};
}), D = (e) => E.find((t) => t.id === e), ae = [
	"chretien",
	"urbain",
	"thibaut",
	"hugues",
	"florentin",
	"henry",
	"jeanne",
	"isabeau",
	"marie"
], O = [
	[
		"saleInfluence",
		"placementInfluence",
		"sharedActivity",
		"agriculture"
	],
	[
		"exchange",
		"protect",
		"purchasedFlip",
		"copyCube"
	],
	[
		"dieY",
		"dieW",
		"dieR",
		"dieP"
	],
	[
		"cubeBonus",
		"arrivalCubes",
		"cubeMajority",
		"arrivalRace"
	]
], oe = [
	5,
	10,
	15,
	20
];
//#endregion
//#region src/games/troyes/moves.ts
function k(e, t, n = e.draft) {
	let r = n.dice.map((t) => e.dice.find((e) => e.id === t)).filter((e) => !!e);
	if (!r.length || r.length !== n.dice.length || r.some((e) => e.color === "p" && e.owner !== t)) return null;
	let i = n.modifier, a = i === "augustine" || i === "recruiter";
	if (r.length + Number(a) > 3 || a && r.length < 1) return null;
	let o = r.map((e) => ({
		color: e.color === "p" ? n.color : e.color,
		value: n.flip === e.id ? 7 - e.value : e.value
	})), s = (e) => o.every((t) => t.color === e);
	if (i === "distiller") {
		let e = n.param;
		if (!r[e] || r[e].owner !== t) return null;
		o[e].value = 7 - o[e].value;
	}
	if ([
		"monk",
		"templar",
		"herbalist",
		"prior"
	].includes(i ?? "")) {
		if (r.length !== 1 || !s("w")) return null;
		let e = i === "monk" ? "y" : i === "prior" ? "w" : "r", t = i === "monk" || i === "herbalist" ? 3 : 2;
		o = Array.from({ length: t }, () => ({
			color: e,
			value: o[0].value
		}));
	}
	if (i === "militiaman") {
		if (!s("y")) return null;
		o = o.map((e) => ({
			...e,
			color: "r"
		}));
	}
	if (i === "priest") {
		if (!s("y")) return null;
		o.forEach((e) => {
			e.value += 3;
		});
	}
	if (i === "blacksmith") {
		if (!s("r")) return null;
		o[0].value += 5;
	}
	if (i === "apprenticeship" && o.forEach((e) => {
		e.value = 5;
	}), i === "confession" && o.forEach((e) => {
		e.value += 2;
	}), i === "preacher") {
		if (!o[n.param]) return null;
		let e = o[n.param].value;
		o.forEach((t) => {
			t.value = e;
		});
	}
	a && o.push({
		color: i === "augustine" ? "y" : "r",
		value: 6
	});
	let c = o.every((e) => e.color === o[0].color) ? o[0].color : null;
	if (i === "tithe" && c !== "y" || i === "chiefTemplar" && c !== "r") return null;
	let l = /* @__PURE__ */ new Set(), u = [];
	return r.forEach((o, s) => {
		if (o.owner === t) return;
		let c = (r.length + Number(a)) * 2;
		i === "viticulturist" && n.param === s && (c = 0), (i === "tithe" || i === "chiefTemplar") && !l.has(o.owner) && (c = i === "tithe" ? 0 : 2, l.add(o.owner)), i === "tithe" && e.solo && o.owner === "$roy" && (c = 0), u.push({
			owner: o.owner,
			amount: c
		});
	}), i === "viticulturist" && (!r[n.param] || r[n.param].owner === t) ? null : {
		dice: r,
		effective: o,
		total: o.reduce((e, t) => e + t.value, 0),
		cost: u.reduce((e, t) => e + t.amount, 0),
		payments: u,
		modifier: i,
		same: c
	};
}
var A = (e) => e.dice.length === 1 && e.effective.length === 1 && !!e.same && e.effective[0].value <= 6 && !["priest", "blacksmith"].includes(e.modifier ?? "") && (e.same === "r" || !["confession", "apprenticeship"].includes(e.modifier ?? "")), j = (e) => e.same === "w" && !["confession", "apprenticeship"].includes(e.modifier ?? "") && e.effective.every((e) => e.value <= 6);
function M(e, t) {
	let n = T(t);
	if (n.id === "pilgrimage") {
		if (!e.same && e.modifier && !["confession", "apprenticeship"].includes(e.modifier)) return 0;
	} else if (e.same !== n.color) return 0;
	return n.id === "fort" ? e.effective.length : Math.floor(e.total / n.divisor);
}
//#endregion
//#region src/games/troyes/model.ts
var N = "$neutral", P = "$roy", F = () => ({
	dice: [],
	black: [0],
	modifier: null,
	param: 0,
	color: "y",
	outdoor: [],
	flip: null
}), I = (e, t) => e.players.find((e) => e.rid === t), L = (e, t = "", n = {}) => ({
	...n,
	op: e,
	rid: t
}), R = (e, ...t) => ({
	option: {
		id: "",
		...e
	},
	jobs: t
}), z = (e, ...t) => {
	e.agenda.unshift(...t);
};
function B(e, t, n, r) {
	r.length && (e.serial++, e.decision = {
		rid: t,
		kind: n,
		offers: r.map((t, n) => ({
			...t,
			option: {
				...t.option,
				id: `${e.serial}:${n}`
			}
		}))
	});
}
var V = (t) => e(t.seed, t.cursor++, 6) + 1;
function H(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function U(e, t, n, r = {}) {
	e.log.push({
		kind: t,
		rid: n,
		...r
	});
}
function W(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t);
	!i || t === "$roy" && n !== "vp" || (i[n] = Math.max(0, n === "influence" ? Math.min(20, i[n] + r) : i[n] + r));
}
var G = (e, t) => e.filter((e) => e === t).length;
function se(e, t, n, r = V(e)) {
	e.dice.push({
		id: `d${++e.diceSerial}`,
		owner: t,
		color: n,
		value: r
	});
}
function ce(e, t) {
	let n = e.players.map((e) => e.rid);
	return n[(n.indexOf(t) + e.turnDirection + n.length) % n.length];
}
function K(e, t) {
	let n = I(e, t), r = [];
	n.supply && r.push("supply"), !n.supply && n.total < (t === "$roy" ? 24 : 12) && (n.influence >= 2 || t === "$roy") && r.push("recruit");
	for (let n of [
		"r",
		"w",
		"y"
	]) e.buildings[n].forEach((e, i) => {
		e === t && r.push(`b:${n}:${i}`);
	}), e.expelled[n].forEach((e, i) => {
		e === t && r.push(`e:${n}:${i}`);
	});
	return e.activities.forEach((e, n) => e.merchants.forEach((e, i) => {
		e.owner === t && r.push(`a:${n}:${i}`);
	})), r;
}
function le(e, t, n) {
	let r = I(e, t);
	if (n === "supply") {
		r.supply--;
		return;
	}
	if (n === "recruit") {
		r.total++, W(e, t, "influence", -2);
		return;
	}
	let [i, a, o] = n.split(":"), s = +o;
	i === "b" && (e.buildings[a][s] = null), i === "e" && e.expelled[a].splice(s, 1), i === "a" && e.activities[+a].merchants.splice(s, 1);
}
function ue(e, t, n, r) {
	let i = [...e.buildings[t]];
	if (r?.startsWith(`b:${t}:`) && (i[+r.split(":")[2]] = null), t === "r") return i[n - 1];
	let a = t === "w" ? 3 : 2, o = t === "w" ? n <= 3 ? 0 : 1 : (n - 1) % 3, s = i.slice(o * a, (o + 1) * a);
	return s.includes(null) ? null : s.at(-1);
}
function de(e, t, n, r) {
	let i = ue(e, t, n, r), a = [...e.expelled[t]];
	return r?.startsWith(`e:${t}:`) && a.splice(+r.split(":")[2], 1), !i || !a.includes(i);
}
function fe(e, t, n, r) {
	let i = e.buildings[n], a;
	if (n === "r") a = i[r - 1], i[r - 1] = t;
	else {
		let e = n === "w" ? 3 : 2, o = (n === "w" ? r <= 3 ? 0 : 1 : (r - 1) % 3) * e, s = i.slice(o, o + e), c = s.indexOf(null), l = c < 0 ? e - 1 : c;
		a = c < 0 ? s.at(-1) : null;
		for (let e = l; e > 0; e--) i[o + e] = i[o + e - 1];
		i[o] = t;
	}
	a && e.expelled[n].push(a), U(e, "place", t, {
		target: `building:${n}`,
		value: r
	});
}
//#endregion
//#region src/games/troyes/event-rules.ts
function pe(e, t, n, r = !1) {
	let i = e.cathedral[n];
	i.length >= (r ? 4 : 3) || (i.push(t), e.actionPlacedCube = !0, W(e, t, "vp", 1), W(e, t, "influence", n < 3 ? 1 : 2), U(e, "cathedral", t, { value: n + 1 }));
}
function q(e, t, n, r) {
	let i = e.events.find((e) => e.uid === n);
	return i ? Array.from({ length: Math.min(r, D(i.id).flags - i.cubes.length) }, () => L("eventCube", t, { target: n })) : [];
}
function me(e, t) {
	let n = e.events.find((e) => e.uid === t);
	if (!n) return;
	let r = D(n.id), i = [...new Set(n.cubes)].sort((e, t) => G(n.cubes, t) - G(n.cubes, e)), a = i.filter((e) => G(n.cubes, e) === G(n.cubes, i[0]));
	if (a.length > 1) a.forEach((t) => W(e, t, "vp", Math.floor((r.prizes[0] + r.prizes[1]) / a.length)));
	else if (i.length === 1) W(e, a[0], "vp", r.prizes[0] + r.prizes[1]);
	else {
		W(e, a[0], "vp", r.prizes[0]);
		let t = i.filter((e) => G(n.cubes, e) === G(n.cubes, i[1]));
		t.forEach((n) => W(e, n, "vp", Math.floor(r.prizes[1] / t.length)));
	}
	let o = n.cubes.find((e) => a.includes(e));
	if (U(e, "resolved", o, { card: n.id }), n.id === "marauding") n.cubes = [];
	else {
		let t = e.players.find((e) => e.rid === o);
		t && t.captured.push(n.id), n.captives.forEach((t) => {
			let n = e.players.find((e) => e.rid === t);
			n && n.supply++;
		}), e.events.splice(e.events.indexOf(n), 1);
	}
}
function he(e) {
	return (e.config.ladiesEvents ? 10 : 8) - C.reduce((t, n) => t + G(e.buildings[n], N) + G(e.expelled[n], N), 0) - e.activities.reduce((e, t) => e + t.merchants.filter((e) => e.owner === N).length, 0);
}
function ge(e, t) {
	let n = `event${++e.serial}`;
	e.events.push({
		uid: n,
		id: t,
		cubes: [],
		captives: []
	}), U(e, "event", "", { card: t });
	let r = D(t), i = [];
	r.call && e.decks[r.call].length && i.push(L("drawEvent", "", { card: e.decks[r.call].shift() })), t === "resistance" && e.unusedRed.length && i.push(L("drawEvent", "", { card: e.unusedRed.shift() })), t === "possession" && i.push(...e.players.filter((e) => e.rid !== P).map((e) => L("possess", e.rid, { target: n }))), z(e, ...i);
}
function _e(e, t, n) {
	return e.outdoors.find((e) => e.id === "protect")?.cubes.includes(t.rid) ? (B(e, t.rid, "protect", [R({
		kind: "protect",
		card: "protect"
	}, L("spendOutdoor", t.rid, { card: "protect" })), R({
		kind: "acceptEvent",
		card: t.card
	}, n)]), !0) : !1;
}
function ve(e, t) {
	let n = t.rid, r = e.players.find((e) => e.rid === n);
	switch (t.op) {
		case "drawEvent": return ge(e, t.card), !0;
		case "eventCube": {
			let r = e.events.find((e) => e.uid === t.target);
			return !r || r.cubes.length >= D(r.id).flags || (r.cubes.push(n), e.actionPlacedCube = !0, W(e, n, "influence", 1), U(e, "eventCube", n, { card: r.id }), r.cubes.length === D(r.id).flags && z(e, L("resolveEvent", n, { target: r.uid })), r.captives.length && B(e, e.actionActor || e.first, "releaseCitizen", r.captives.map((e, t) => R({
				kind: "releaseCitizen",
				target: e,
				n: t
			}, L("releaseCitizen", n, {
				target: r.uid,
				n: t
			})))), !0);
		}
		case "resolveEvent": return me(e, t.target), !0;
		case "releaseCitizen": {
			let n = e.events.find((e) => e.uid === t.target);
			if (n && n.captives[t.n] !== void 0) {
				let r = n.captives.splice(t.n, 1)[0];
				I(e, r).supply++;
			}
			return !0;
		}
		case "cathedralCube": return pe(e, n, t.value, t.flag), !0;
		case "eventEffect": {
			let n = e.events.find((e) => e.uid === t.target);
			if (!n) return !0;
			let r = D(n.id), i = r.effect;
			if (e.blackCount += r.black, U(e, "eventEffect", "", { card: n.id }), [
				"drought",
				"civilWar",
				"heresy",
				"harshWinter"
			].includes(i) && z(e, ...e.players.filter((e) => e.rid !== P).map((e) => L("eventLoss", e.rid, { card: i }))), i === "travelingBuilders") {
				let t = Math.min(...e.cathedral.map((e) => e.length)), n = e.cathedral.findIndex((e) => e.length === t);
				t < 3 && (e.cathedral[n].push(e.solo ? P : N), e.solo && W(e, P, "vp", 1));
			}
			if (i === "interruptedWork") {
				let n = e.cathedral.map((e) => e.length), r = Math.max(...n), i = n.lastIndexOf(r);
				if (r) {
					let n = e.cathedral[i].at(-1), r = L("removeCathedral", n, { value: i });
					_e(e, {
						...t,
						rid: n
					}, r) || z(e, r);
				}
			}
			if ([
				"wayfarers",
				"theologicalConflict",
				"succession"
			].includes(i) && (e.solo ? I(e, "$roy").supply > 0 : he(e) > 0)) {
				let t = i === "wayfarers" ? "y" : i === "theologicalConflict" ? "w" : "r", n = V(e);
				de(e, t, n) && (e.solo && I(e, P).supply--, fe(e, e.solo ? P : N, t, n));
			}
			if (i === "support") {
				let t = e.events.slice(0, e.events.indexOf(n)).filter((e) => e.id !== "chiefOutlaw");
				t.length <= 2 ? z(e, ...t.flatMap((t) => q(e, e.solo ? P : N, t.uid, 1))) : z(e, L("supportMenu", e.first, {
					ids: t.map((e) => e.uid),
					n: 2
				}));
			}
			if (i === "resistance" && e.events.forEach((e) => {
				e.cubes.pop();
			}), i === "uprising") {
				let t = V(e), n = t <= 2 ? "w" : t <= 4 ? "r" : "y", r = e.expelled[n].shift(), i = r ?? (e.solo ? I(e, "$roy").supply > 0 ? "$roy" : null : he(e) > 0 ? "$neutral" : null);
				!r && i === "$roy" && I(e, P).supply--;
				let a = H(e, [...e.buildings[n].filter((e) => e !== null), ...i ? [i] : []]);
				e.buildings[n] = Array.from({ length: 6 }, (e, t) => a[t] ?? null), a[6] && e.expelled[n].push(a[6]);
			}
			if (i === "eventMonk" && (e.solo ? I(e, "$roy").supply > 0 : he(e) > 0)) {
				let t = V(e), n = t <= 2 ? "w" : t <= 4 ? "r" : "y", r = e.activities.filter((e) => e.revealed && T(e.id).color === n).flatMap((e) => T(e.id).slots.map((t, n) => ({
					a: e,
					vp: t,
					slot: n
				})).filter((t) => !e.merchants.some((e) => e.slot === t.slot))).sort((e, t) => t.vp - e.vp || T(e.a.id).level - T(t.a.id).level);
				r.length && (e.solo && I(e, P).supply--, r[0].a.merchants.push({
					owner: e.solo ? P : N,
					slot: r[0].slot
				}));
			}
			return !0;
		}
		case "eventLoss": {
			if (!(t.card === "drought" ? G(e.buildings.y, n) : t.card === "civilWar" || t.card === "heresy" || 1)) return !0;
			let r = L("applyEventLoss", n, t);
			return _e(e, t, r) || z(e, r), !0;
		}
		case "applyEventLoss":
			if (!r) return !0;
			if (t.card === "harshWinter") {
				let t = e.activities.filter((e) => e.cubes.includes(n)).map((e) => R({
					kind: "loseCube",
					card: e.id
				}, L("loseActivityCube", n, { card: e.id })));
				t.push(...e.outdoors.filter((e) => e.cubes.includes(n)).map((e) => R({
					kind: "loseCube",
					card: e.id
				}, L("spendOutdoor", n, { card: e.id })))), B(e, n, "loseCube", t);
			} else {
				let i = t.card === "drought" ? G(e.buildings.y, n) : t.card === "civilWar" ? 3 : 2, a = t.card === "heresy" ? "influence" : "money";
				r[a] < i && W(e, n, "vp", -2), W(e, n, a, -i);
			}
			return !0;
		case "removeCathedral": return e.cathedral[t.value].pop(), !0;
		case "loseActivityCube": {
			let r = e.activities.find((e) => e.id === t.card);
			return r.cubes.splice(r.cubes.indexOf(n), 1), !0;
		}
		case "possess": {
			let r = K(e, n);
			return B(e, n, "citizen", r.map((e) => R({
				kind: "source",
				ref: e
			}, L("possessCitizen", n, {
				ref: e,
				target: t.target
			})))), r.length || W(e, n, "vp", -2), !0;
		}
		case "possessCitizen": return le(e, n, t.ref), e.events.find((e) => e.uid === t.target).captives.push(n), !0;
		case "supportMenu": {
			let r = t.ids.filter((t) => e.events.some((e) => e.uid === t));
			return !t.n || !r.length || B(e, n, "support", r.map((i) => R({
				kind: "eventTarget",
				target: i
			}, ...q(e, e.solo ? P : N, i, 1), L("supportMenu", n, {
				ids: r.filter((e) => e !== i),
				n: t.n - 1
			})))), !0;
		}
		default: return !1;
	}
}
//#endregion
//#region src/games/troyes/activity-rules.ts
var J = () => R({ kind: "stop" });
function ye(e, t, n, r) {
	return e === "artisan" ? n >= 1 : e === "troubadour" ? n >= 3 : e === "diplomat" ? n >= 1 : e === "innkeeper" || e === "scout" ? t >= 1 : e === "journeyman" || e === "ransom" ? t >= 3 : e === "marriage" ? t >= 7 : e !== "breeder" || t >= 3 || r > 0;
}
function Y(e, t, n, r = []) {
	return e.events.filter((e) => e.id !== "chiefOutlaw" && !r.includes(e.uid)).map((r) => R({
		kind: "eventTarget",
		card: r.id,
		target: r.uid,
		n
	}, ...q(e, t, r.uid, n)));
}
function X(e, t, n, r = !1) {
	let i = t.n > 1 ? [L("activityEffect", t.rid, {
		...t,
		n: t.n - 1,
		flag: !1
	})] : [];
	B(e, t.rid, "effect", [...n.map((e) => ({
		...e,
		jobs: [...e.jobs, ...i]
	})), ...r && !t.flag ? [J()] : []]);
}
function be(e, t, n, r) {
	z(e, ...Array.from({ length: r }, () => L("activityCube", n, { card: t })));
}
function xe(e, t, n, r, i, a) {
	let o = e.players.find((e) => e.rid === t.rid), s = Math.min(t.n, Math.floor(o[n] / r));
	B(e, t.rid, "amount", [...Array.from({ length: s }, (e, o) => R({
		kind: "convert",
		card: t.card,
		n: o + 1
	}, L("gain", t.rid, {
		ref: n,
		n: -(o + 1) * r
	}), L("gain", t.rid, {
		ref: i,
		n: (o + 1) * a
	}))), ...t.flag ? [] : [J()]]);
}
function Se(e, t) {
	let n = t.rid, r = e.players.find((e) => e.rid === n), i = t.card;
	switch (t.op) {
		case "activate": {
			let r = T(i), a = e.activities.find((e) => e.id === i);
			e.actionCard = i, U(e, "activity", n, {
				card: i,
				n: t.n
			});
			let o = [], s = e.outdoors.find((e) => e.id === "sharedActivity");
			return s && a.merchants.filter((e) => e.owner !== n && s.cubes.includes(e.owner)).forEach((e) => o.push(L("reaction", e.owner, {
				card: "sharedActivity",
				n: 4,
				ref: "money"
			}))), r.timing === "delayed" || r.timing === "end" && i !== "fort" ? be(e, i, n, t.n) : r.timing === "mixed" ? z(e, L("mixedMenu", n, t)) : i === "fort" ? z(e, ...e.actionDice.map((e) => L("fortCube", n, {
				card: i,
				n: e.value <= 3 ? 1 : 2
			}))) : z(e, L("activityEffect", n, t)), z(e, ...o), !0;
		}
		case "activityCube": return e.activities.find((e) => e.id === i).cubes.push(n), U(e, "stored", n, { card: i }), !0;
		case "fortCube": return e.activities.find((e) => e.id === i).cubes.push(n), W(e, n, "vp", t.n), W(e, n, "influence", t.n), U(e, "stored", n, {
			card: i,
			n: t.n
		}), !0;
		case "mixedMenu": {
			let a = G(e.activities.find((e) => e.id === i).cubes, n), o = Math.min(t.n, a), s = i === "breeder" ? Math.min(t.n, Math.floor(r.money / 3)) : t.n, c = [];
			for (let e = 1; e <= s; e++) c.push(R({
				kind: "store",
				card: i,
				n: e
			}, ...i === "breeder" ? [L("gain", n, {
				ref: "money",
				n: -3 * e
			})] : [], ...Array.from({ length: e }, () => L("activityCube", n, { card: i }))));
			for (let e = 1; e <= o; e++) c.push(R({
				kind: "useStored",
				card: i,
				n: e
			}, L("useMixed", n, {
				card: i,
				n: e
			})));
			return B(e, n, "mixed", [...c, ...t.flag ? [] : [J()]]), !0;
		}
		case "useMixed": {
			let r = e.activities.find((e) => e.id === i);
			for (let e = 0; e < t.n; e++) r.cubes.splice(r.cubes.indexOf(n), 1);
			return i === "catapult" ? z(e, L("activityEffect", n, {
				card: i,
				n: t.n
			})) : W(e, n, i === "lumberjack" ? "money" : i === "squire" ? "influence" : "vp", t.n * (i === "lumberjack" ? 4 : i === "squire" ? 5 : 2)), !0;
		}
		case "activityEffect": {
			let a = t.n, o = e.dice.filter((e) => e.owner === n), s = e.activities.reduce((e, t) => e + t.merchants.filter((e) => e.owner === n).length, 0), c = e.events.filter((e) => e.cubes.includes(n)).length;
			switch (i) {
				case "merchant":
					W(e, n, "money", a * 2);
					break;
				case "miller":
					X(e, t, ["r", "w"].map((t) => R({
						kind: "miller",
						color: t,
						n: G(e.buildings[t], n) * 2
					}, L("gain", n, {
						ref: "money",
						n: G(e.buildings[t], n) * 2
					}))));
					break;
				case "artisan":
					xe(e, t, "influence", 1, "money", 6);
					break;
				case "innkeeper": {
					let o = Math.min(a, r.money);
					B(e, n, "amount", Array.from({ length: o }, (e, t) => R({
						kind: "convert",
						card: i,
						n: t + 1
					}, L("gain", n, {
						ref: "money",
						n: -(t + 1)
					}), L("gain", n, {
						ref: "influence",
						n: t + 1
					}))).concat(t.flag ? [] : [J()]));
					break;
				}
				case "journeyman":
					xe(e, t, "money", 3, "vp", 2);
					break;
				case "goldsmith":
					W(e, n, "money", a * 2), W(e, n, "vp", a);
					break;
				case "sculptor":
					W(e, n, "vp", a);
					break;
				case "pilgrimage":
					W(e, n, "vp", a * 2);
					break;
				case "procession": {
					let t = Math.max(...[...e.players.map((e) => e.rid), N].map((t) => e.dice.filter((e) => e.owner === t).length));
					t > 0 && e.players.filter((n) => e.dice.filter((e) => e.owner === n.rid).length === t).forEach((t) => W(e, t.rid, "vp", 2 * a));
					break;
				}
				case "glassblower":
					W(e, n, "vp", a * Math.floor(e.cathedral.reduce((e, t) => e + G(t, n), 0) / 2));
					break;
				case "archer": {
					let r = V(e);
					U(e, "archer", n, { value: r }), r >= 3 ? X(e, t, Y(e, n, 1)) : a > 1 && z(e, L("activityEffect", n, {
						card: i,
						n: a - 1
					}));
					break;
				}
				case "chivalry": {
					let t = o.filter((e) => e.color === "r").length * a;
					t && z(e, L("placeActivityEvents", n, {
						card: i,
						n: t
					}));
					break;
				}
				case "diplomat": {
					let o = Math.min(a, r.influence);
					B(e, n, "amount", [...Array.from({ length: o }, (e, t) => R({
						kind: "convert",
						card: i,
						n: t + 1
					}, L("gain", n, {
						ref: "influence",
						n: -(t + 1)
					}), L("placeActivityEvents", n, {
						card: i,
						n: t + 1
					}))), ...t.flag ? [] : [J()]]);
					break;
				}
				case "hunting":
					W(e, n, "influence", a * 3);
					break;
				case "mercenary":
					W(e, n, "money", a * 3);
					break;
				case "taxCollector":
					for (let t of [...new Set(e.buildings.y.filter((e) => !!e))]) {
						if (t === n) continue;
						let r = e.players.find((e) => e.rid === t), i = G(e.buildings.y, t) * a * (e.solo && t === "$roy" ? 2 : 1), o = r && t !== "$roy" ? Math.min(r.money, i) : i;
						W(e, t, "money", -o), W(e, n, "money", o);
					}
					break;
				case "captain":
					W(e, n, "vp", a * c);
					break;
				case "joust": {
					let t = (t) => e.dice.filter((e) => e.owner === t && e.color === "r").reduce((e, t) => e + t.value, 0), r = Math.max(...[...e.players.map((e) => e.rid), N].map(t));
					t(n) >= r && e.players.filter((e) => t(e.rid) === r).forEach((t) => W(e, t.rid, "vp", a * 2));
					break;
				}
				case "troubadour":
					xe(e, t, "influence", 3, "vp", 2);
					break;
				case "baker":
					W(e, n, "money", a * e.dice.filter((e) => e.color === "y").length);
					break;
				case "banquet":
					W(e, n, "vp", a * Math.max(0, ...[...e.players.map((e) => e.rid).filter((t) => !e.solo || t !== "$roy"), "$neutral"].map((t) => e.dice.filter((e) => e.owner === t && e.color === "r").length)));
					break;
				case "clogMaker":
					W(e, n, "money", a * G(e.buildings.y, n));
					break;
				case "weaver":
					W(e, n, "money", a * s);
					break;
				case "landlady":
					X(e, t, [R({
						kind: "gainInfluence",
						n: 4
					}, L("gain", n, {
						ref: "influence",
						n: 4
					})), R({
						kind: "gainVp",
						n: 1
					}, L("gain", n, {
						ref: "vp",
						n: 1
					}))]);
					break;
				case "banker":
					r.money > 30 && W(e, n, "vp", a * 3);
					break;
				case "masterTradesman":
					W(e, n, "vp", a * Math.floor(s / 2));
					break;
				case "bishop":
					W(e, n, "money", a * e.cathedral.reduce((e, t) => e + G(t, n), 0));
					break;
				case "masterBuilder":
					X(e, t, e.cathedral.map((e, t) => ({
						col: e,
						value: t
					})).filter((e) => e.col.length < 4).map(({ value: e }) => R({
						kind: "cathedralTarget",
						value: e + 1
					}, L("cathedralCube", n, {
						value: e,
						flag: !0
					}))));
					break;
				case "scribe":
					W(e, n, "vp", a * r.captured.length);
					break;
				case "nun":
					W(e, n, "vp", a * o.filter((e) => e.color === "w").length);
					break;
				case "ransom":
					X(e, t, r.money >= 3 ? Y(e, n, 1).map((e) => ({
						...e,
						jobs: [L("gain", n, {
							ref: "money",
							n: -3
						}), ...e.jobs]
					})) : [], !0);
					break;
				case "catapult":
					X(e, t, Y(e, n, 2));
					break;
				case "scout":
					z(e, L("scoutMenu", n, {
						n: a,
						ids: [],
						flag: t.flag
					}));
					break;
				case "executioner": {
					let r = e.players.filter((e) => e.rid !== n), i = Math.max(...r.map((e) => e.influence));
					X(e, t, r.filter((e) => e.influence === i).map((e) => R({
						kind: "takeInfluence",
						target: e.rid,
						n: Math.min(1, i) + 1
					}, L("gain", e.rid, {
						ref: "influence",
						n: -1
					}), L("gain", n, {
						ref: "influence",
						n: Math.min(1, i) + 1
					}))));
					break;
				}
				case "marriage": xe(e, t, "money", 7, "vp", 4);
			}
			return !0;
		}
		case "placeActivityEvents": return t.n <= 0 || B(e, n, "eventTarget", Y(e, n, 1).map((e) => ({
			...e,
			jobs: [...e.jobs, L("placeActivityEvents", n, {
				...t,
				n: t.n - 1
			})]
		}))), !0;
		case "scoutMenu": {
			if (t.n <= 0 || !r.money) return !0;
			let i = L("scoutMenu", n, {
				n: t.n - 1,
				ids: []
			});
			return B(e, n, "eventTarget", [...Y(e, n, 1, t.ids).map((e) => ({
				...e,
				jobs: [
					L("gain", n, {
						ref: "money",
						n: -1
					}),
					...e.jobs,
					L("scoutMenu", n, {
						n: t.n,
						ids: [...t.ids, e.option.target],
						flag: !1
					})
				]
			})), ...t.flag ? [] : [R({ kind: "nextActivation" }, i)]]), !0;
		}
		default: return !1;
	}
}
//#endregion
//#region src/games/troyes/action-rules.ts
var Ce = (e, t) => L(e.phase === "defend" ? "defendMenu" : "actionMenu", t);
function we(e, t) {
	return [L("spendDice", t)];
}
function Te(e, t) {
	let n = I(e, t), r = e.dice.filter((e) => e.owner === t), i = Ce(e, t), a = [];
	if (n.influence >= 1 && a.push(...r.map((e) => R({
		kind: "reroll",
		ref: e.id
	}, L("reroll", t, { ref: e.id }), i))), n.influence >= 4) {
		let n = e.draft.dice.filter((e) => r.some((t) => t.id === e));
		n.length > 0 && n.length <= 3 && a.push(R({
			kind: "flip",
			n: n.length
		}, L("flip", t, { ids: n }), i)), n.length || a.push(...r.map((e) => R({
			kind: "flip",
			ref: e.id,
			n: 1
		}, L("flip", t, { ids: [e.id] }), i)));
	}
	return n.influence >= 2 && n.total < 12 && a.push(R({ kind: "recruit" }, L("recruit", t), i)), a;
}
function Ee(e, t) {
	let n = I(e, t), r = L("actionMenu", t), i = e.draft, a = [];
	a.push(R({ kind: "pass" }, L("pass", t), L("advance", t))), a.push(...Te(e, t));
	for (let n of e.dice.filter((e) => e.color !== "p" || e.owner === t)) (i.dice.includes(n.id) || i.dice.length < (["augustine", "recruiter"].includes(i.modifier ?? "") ? 2 : 3)) && a.push(R({
		kind: "die",
		ref: n.id
	}, L("selectDie", t, { ref: n.id }), r));
	(i.dice.length || i.modifier || i.outdoor.length) && a.push(R({ kind: "clear" }, L("clearDraft", t), r)), i.dice.some((t) => e.dice.find((e) => e.id === t)?.color === "p") && a.push(...C.filter((e) => e !== i.color).map((e) => R({
		kind: "color",
		color: e
	}, L("draftColor", t, { color: e }), r)));
	for (let n of e.activities.filter((e) => e.revealed && T(e.id).timing === "delayed" && e.cubes.includes(t))) {
		let e = [
			"distiller",
			"viticulturist",
			"preacher"
		].includes(n.id) ? Math.max(1, i.dice.length) : 1;
		for (let i = 0; i < e; i++) a.push(R({
			kind: "modifier",
			card: n.id,
			n: i
		}, L("selectModifier", t, {
			card: n.id,
			n: i
		}), r));
	}
	for (let o of e.outdoors.filter((e) => e.cubes.includes(t))) {
		if ([
			"placementInfluence",
			"agriculture",
			"cubeBonus",
			"copyCube"
		].includes(o.id) && a.push(R({
			kind: "outdoorModifier",
			card: o.id
		}, L("selectOutdoor", t, { card: o.id }), r)), o.id.startsWith("die")) {
			let i = o.id.slice(3).toLowerCase(), s = e.dice.filter((e) => e.color === i).length;
			(i === "p" ? !e.dice.some((e) => e.owner === t && e.color === "p") && n.money >= 2 : s < 6) && a.push(R({
				kind: "addDie",
				card: o.id
			}, L("spendOutdoor", t, { card: o.id }), L("outdoorDie", t, { ref: i }), r));
		}
		o.id === "exchange" && e.dice.some((e) => e.owner === t && e.color !== "p") && e.dice.some((e) => e.owner !== t && e.color !== "p") && a.push(R({
			kind: "exchange",
			card: o.id
		}, L("exchangeStart", t))), o.id === "purchasedFlip" && a.push(...i.dice.filter((n) => e.dice.find((e) => e.id === n)?.owner !== t).map((e) => R({
			kind: "purchasedFlip",
			ref: e,
			card: o.id
		}, L("setPurchasedFlip", t, { ref: e }), r)));
	}
	let o = k(e, t);
	if (!o || o.cost > n.money) return a;
	let s = L("actionDone", t);
	if (o.same === "y" && o.total >= 2 && a.push(R({
		kind: "agriculture",
		n: Math.floor(o.total / 2),
		value: o.cost
	}, ...we(e, t), L("agriculture", t, { n: Math.floor(o.total / 2) }), s)), j(o)) {
		let n = e.cathedral.map((e) => e.length);
		o.effective.every((e) => {
			let t = e.value - 1;
			return n[t] >= 3 ? !1 : (n[t]++, !0);
		}) && a.push(R({
			kind: "cathedral",
			n: o.effective.length,
			value: o.cost
		}, ...we(e, t), ...o.effective.map((e) => L("cathedralCube", t, { value: e.value - 1 })), s));
	}
	if (A(o)) {
		let n = o.same, r = o.effective[0].value;
		K(e, t).filter((t) => de(e, n, r, t)).length && a.push(R({
			kind: "building",
			color: n,
			n: r,
			value: o.cost
		}, L("hireBuildingMenu", t, {
			color: n,
			value: r
		})));
	}
	for (let r of e.activities.filter((e) => e.revealed)) {
		let i = T(r.id), c = M(o, r.id);
		if (!c) continue;
		let l = r.merchants.some((e) => e.owner === t), u = l ? 0 : i.cost;
		!l && (!K(e, t).length || (i.influence ? n.influence < u : n.money - o.cost < u)) || (l || K(e, t).some((e) => ye(r.id, n.money - o.cost - (i.influence ? 0 : u), n.influence - (i.influence ? u : 0) - (e === "recruit" ? 2 : 0), r.cubes.filter((e) => e === t).length))) && (l ? a.push(R({
			kind: "activity",
			card: r.id,
			n: c,
			value: o.cost
		}, ...we(e, t), L("activate", t, {
			card: r.id,
			n: c
		}), s)) : a.push(R({
			kind: "activity",
			card: r.id,
			n: c,
			value: o.cost + (i.influence ? 0 : u)
		}, L("hireActivityMenu", t, {
			card: r.id,
			n: c
		}))));
	}
	for (let n of e.events) {
		let r = D(n.id);
		if (r.color !== "any" && o.same !== r.color || r.color === "any" && !o.same) continue;
		let i = Math.min(Math.floor(o.total / r.divisor), r.flags - n.cubes.length);
		i > 0 && a.push(R({
			kind: "combat",
			card: n.id,
			target: n.uid,
			n: i,
			value: o.cost
		}, ...we(e, t), ...q(e, t, n.uid, i), s));
	}
	if (e.config.ramparts && !i.modifier && o.dice.length === 1) for (let r = 0; r <= Math.min(6 - o.dice[0].value, n.money - o.cost); r++) a.push(R({
		kind: "ramparts",
		n: o.dice[0].value + r,
		value: o.cost + r
	}, ...we(e, t), L("rampartsStart", t, {
		n: o.dice[0].value + r,
		value: r,
		ref: o.dice[0].color
	}), s));
	return a;
}
function De(e, t) {
	let n = t.rid, r = e.players.find((e) => e.rid === n);
	switch (t.op) {
		case "actionMenu": return e.phase = "action", e.active = n, B(e, n, "action", Ee(e, n)), !0;
		case "selectDie": {
			let n = e.draft.dice.indexOf(t.ref);
			return n >= 0 ? e.draft.dice.splice(n, 1) : e.draft.dice.push(t.ref), !0;
		}
		case "clearDraft": return e.draft = F(), !0;
		case "draftColor": return e.draft.color = t.color, !0;
		case "selectModifier": return e.draft.modifier = e.draft.modifier === t.card && e.draft.param === t.n ? null : t.card, e.draft.param = t.n, !0;
		case "selectOutdoor": {
			let n = e.draft.outdoor.indexOf(t.card);
			return n >= 0 ? e.draft.outdoor.splice(n, 1) : e.draft.outdoor.push(t.card), !0;
		}
		case "setPurchasedFlip": return e.draft.flip = e.draft.flip === t.ref ? null : t.ref, !0;
		case "reroll": return W(e, n, "influence", -1), z(e, L("rollDie", n, { ref: t.ref })), !0;
		case "flip": return W(e, n, "influence", -4), e.dice.filter((e) => t.ids.includes(e.id)).forEach((e) => {
			e.value = 7 - e.value;
		}), U(e, "flip", n, { n: t.ids.length }), !0;
		case "recruit": return W(e, n, "influence", -2), r.supply++, r.total++, U(e, "recruit", n), !0;
		case "spendDice": {
			let t = k(e, n);
			if (e.actionActor = n, e.actionCard = null, e.actionDice = t.effective, e.actionPlacedCube = !1, t.payments.forEach((t) => {
				W(e, n, "money", -t.amount), W(e, t.owner, "money", t.amount);
			}), e.draft.modifier) {
				let t = e.activities.find((t) => t.id === e.draft.modifier);
				t.cubes.splice(t.cubes.indexOf(n), 1);
			}
			e.draft.flip && z(e, L("spendOutdoor", n, { card: "purchasedFlip" }));
			let r = [...new Set(t.payments.map((e) => e.owner))], i = e.outdoors.find((e) => e.id === "saleInfluence");
			if (i) for (let t of r.filter((e) => i.cubes.includes(e))) z(e, L("reaction", t, {
				card: i.id,
				n: 4,
				ref: "influence"
			}));
			return e.dice = e.dice.filter((t) => !e.draft.dice.includes(t.id)), U(e, "dice", n, {
				n: t.dice.length,
				value: t.cost
			}), !0;
		}
		case "agriculture": return W(e, n, "money", t.n), U(e, "agriculture", n, { n: t.n }), e.draft.outdoor.includes("agriculture") && z(e, L("spendOutdoor", n, { card: "agriculture" }), L("gain", n, {
			n: 5,
			ref: "money"
		})), !0;
		case "hireBuildingMenu": return B(e, n, "citizen", K(e, n).filter((n) => de(e, t.color, t.value, n)).map((e) => R({
			kind: "source",
			ref: e
		}, L("spendDice", n), L("placeBuilding", n, {
			...t,
			ref: e
		}), L("actionDone", n)))), !0;
		case "placeBuilding": return le(e, n, t.ref), fe(e, n, t.color, t.value), e.draft.outdoor.includes("placementInfluence") && z(e, L("spendOutdoor", n, { card: "placementInfluence" }), L("gain", n, {
			ref: "influence",
			n: 4
		})), !0;
		case "hireActivityMenu": {
			let i = T(t.card), a = r.influence - (i.influence ? i.cost : 0), o = r.money - k(e, n).cost - (i.influence ? 0 : i.cost), s = e.activities.find((e) => e.id === t.card).cubes.filter((e) => e === n).length;
			return B(e, n, "citizen", K(e, n).filter((e) => (e !== "recruit" || a >= 2) && ye(i.id, o, a - (e === "recruit" ? 2 : 0), s)).map((e) => R({
				kind: "source",
				ref: e
			}, L("spendDice", n), L("hireActivity", n, {
				card: t.card,
				ref: e
			}), L("activate", n, {
				card: t.card,
				n: t.n,
				flag: !0
			}), L("actionDone", n)))), !0;
		}
		case "hireActivity": {
			let r = e.activities.find((e) => e.id === t.card), i = T(r.id);
			le(e, n, t.ref), W(e, n, i.influence ? "influence" : "money", -i.cost);
			let a = i.slots.findIndex((e, t) => !r.merchants.some((e) => e.slot === t));
			return r.merchants.push({
				owner: n,
				slot: a
			}), U(e, "merchant", n, { card: r.id }), !0;
		}
		case "removeCitizen": return le(e, n, t.ref), !0;
		case "pass": return r.passed = !0, r.passMoney = 2, e.draft = F(), U(e, "pass", n), !0;
		case "actionDone": return z(e, ...e.draft.outdoor.includes("copyCube") && e.actionCard && ["delayed", "mixed"].includes(T(e.actionCard).timing) ? [L("copyCubeMenu", n)] : [], L("cubeBonus", n), L("finishAction", n)), !0;
		case "finishAction": return e.draft = F(), e.actionCard = null, z(e, L("advance", n)), !0;
		case "advance": {
			if (!e.dice.length || e.players.every((e) => e.passed)) return z(e, L("roundEnd")), !0;
			let t = ce(e, n), r = I(e, t);
			return r.passed ? (r.passMoney++, z(e, L("advance", t))) : (e.draft = F(), z(e, L(e.solo && t === "$roy" ? "royAction" : "actionMenu", t))), !0;
		}
		case "gain": return W(e, n, t.ref, t.n), !0;
		case "cubeBonus": return e.actionPlacedCube && e.draft.outdoor.includes("cubeBonus") && z(e, L("spendOutdoor", n, { card: "cubeBonus" }), L("gain", n, {
			ref: "vp",
			n: 2
		})), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/troyes/outdoor-rules.ts
function Oe(e, t) {
	let n = t.rid, r = e.players.find((e) => e.rid === n), i = t.card;
	switch (t.op) {
		case "spendOutdoor": {
			let t = e.outdoors.find((e) => e.id === i), r = t.cubes.indexOf(n);
			return r >= 0 && t.cubes.splice(r, 1), U(e, "outdoorUse", n, { card: i }), !0;
		}
		case "reaction": return B(e, n, "reaction", [R({
			kind: "outdoorUse",
			card: i,
			n: t.n
		}, L("spendOutdoor", n, { card: i }), L("gain", n, {
			ref: t.ref,
			n: t.n
		})), R({ kind: "stop" })]), !0;
		case "outdoorDie": return t.ref === "p" && W(e, n, "money", -2), se(e, n, t.ref), U(e, "outdoorDie", n, { target: t.ref }), !0;
		case "rampartsStart": return W(e, n, "money", -t.value), e.rampartUsed = [], e.rampartColor = t.ref, z(e, L("rampartsMenu", n, { n: t.n })), !0;
		case "rampartsMenu": {
			if (!t.n) return !0;
			let i = [], a = L("rampartsMenu", n, { n: t.n - 1 });
			return r.guard < 20 && i.push(R({
				kind: "guardMove",
				n: r.guard + 1,
				value: t.n
			}, L("guardMove", n), a)), e.outdoors.forEach((o, s) => {
				r.guard < oe[s] || e.rampartUsed.includes(o.id) || o.id === "arrivalRace" || (o.id.startsWith("die") ? o.id.slice(3).toLowerCase() : null) !== e.rampartColor && i.push(R({
					kind: "outdoorCube",
					card: o.id,
					n: t.n
				}, L("outdoorCube", n, { card: o.id }), a));
			}), B(e, n, "ramparts", [...i, R({ kind: "stop" })]), !0;
		}
		case "guardMove": {
			r.guard++, U(e, "guardMove", n, { n: r.guard });
			let t = oe.indexOf(r.guard);
			if (t >= 0) {
				let r = e.outdoors[t];
				r.arrivals.push(n), r.id === "arrivalRace" && W(e, n, "vp", [
					6,
					4,
					2,
					1
				][r.arrivals.length - 1] ?? 0), r.id === "arrivalCubes" && W(e, n, "vp", 3);
			}
			return !0;
		}
		case "outdoorCube": return e.outdoors.find((e) => e.id === i).cubes.push(n), e.rampartUsed.push(i), U(e, "outdoorCube", n, { card: i }), !0;
		case "copyCubeMenu": return B(e, n, "copyCube", [...e.activities.filter((e) => e.revealed && [
			"mixed",
			"delayed",
			"end"
		].includes(T(e.id).timing) && (e.id !== "breeder" || r.money >= 3)).map((e) => R({
			kind: "copyCube",
			card: e.id
		}, L("spendOutdoor", n, { card: "copyCube" }), ...e.id === "breeder" ? [L("gain", n, {
			ref: "money",
			n: -3
		})] : [], L("activityCube", n, { card: e.id }))), R({ kind: "stop" })]), !0;
		case "exchangeStart": return z(e, L("spendOutdoor", n, { card: "exchange" }), L("exchangeMenu", n, { ids: [] })), !0;
		case "exchangeMenu": {
			let r = [...new Set(e.dice.filter((e) => e.owner !== n && e.color !== "p" && !t.ids.includes(e.owner)).map((e) => e.owner))], i = e.dice.filter((e) => e.owner === n && e.color !== "p");
			return B(e, n, "exchange", [...r.flatMap((r) => i.flatMap((i) => e.dice.filter((e) => e.owner === r && e.color !== "p").map((e) => R({
				kind: "exchangeDice",
				ref: i.id,
				target: e.id
			}, L("exchangeDice", n, {
				ref: i.id,
				target: e.id
			}), L("exchangeMenu", n, { ids: [...t.ids, r] }))))), R({ kind: "stop" }, L("clearDraft", n), L("actionMenu", n))]), !0;
		}
		case "exchangeDice": {
			let r = e.dice.find((e) => e.id === t.ref), i = e.dice.find((e) => e.id === t.target);
			return r.owner = i.owner, i.owner = n, U(e, "exchange", n), !0;
		}
		default: return !1;
	}
}
//#endregion
//#region src/games/troyes/scoring.ts
function ke(e, t, n) {
	let r = I(e, t), i = G(Object.values(e.buildings).flat(), t), a = e.activities.reduce((e, n) => e + n.merchants.filter((e) => e.owner === t).length, 0), o = e.cathedral.reduce((e, n) => e + G(n, t), 0), s = 0, c = [
		2,
		4,
		6
	];
	if (n === "chretien" && (s = i, c = e.players.length === 2 ? [
		4,
		6,
		8
	] : [
		3,
		5,
		7
	]), n === "urbain" && (s = o, c = e.players.length === 2 ? [
		4,
		6,
		8
	] : [
		3,
		5,
		7
	]), n === "thibaut" && (s = t === "$roy" ? 0 : r.money, c = [
		6,
		12,
		18
	]), n === "hugues" && (s = t === "$roy" ? 0 : r.influence, c = [
		5,
		10,
		15
	]), n === "florentin" && (s = a), n === "henry" && (s = r.captured.length, c = [
		1,
		3,
		5
	]), [
		"jeanne",
		"isabeau",
		"marie"
	].includes(n)) {
		let r = n === "jeanne" ? "y" : n === "isabeau" ? "r" : "w";
		s = G(e.buildings[r], t) + e.activities.filter((e) => T(e.id).color === r).reduce((e, n) => e + n.merchants.filter((e) => e.owner === t).length, 0);
	}
	return s >= c[2] ? 6 : s >= c[1] ? 3 : +(s >= c[0]);
}
function Ae(e, t) {
	let n = I(e, t), r = e.solo ? e.charactersDeck : [...e.players.flatMap((e) => e.characters), ...e.publicCharacters], i = e.activities.reduce((e, n) => e + n.merchants.filter((e) => e.owner === t).reduce((e, t) => e + (T(n.id).slots[t.slot] ?? 0), 0), 0), a = e.events.filter((e) => e.cubes.includes(t)).length, o = e.activities.some((e) => e.revealed && e.id === "masterBuilder") ? 4 : 3, s = -2 * Array.from({ length: o }, (e, t) => t).filter((n) => !e.cathedral.some((e) => e[n] === t)).length, c = r.reduce((n, r) => n + ke(e, t, r), 0), l = 0, u = 0;
	for (let n of e.activities) {
		let r = G(n.cubes, t), i = Math.max(0, ...e.players.map((e) => G(n.cubes, e.rid))), a = e.players.filter((e) => G(n.cubes, e.rid) === i).length;
		n.id === "hermit" && (l += r * (9 - n.cubes.length)), ["fort", "princess"].includes(n.id) && r > 0 && r === i && (l += Math.floor((n.id === "fort" ? 3 : 6) / a));
	}
	for (let n of e.outdoors) if (n.id === "arrivalCubes" && (u += G(n.cubes, t)), n.id === "cubeMajority" && n.cubes.includes(t)) {
		let r = e.players.map((e) => ({
			rid: e.rid,
			n: G(n.cubes, e.rid)
		})).filter((e) => e.n > 0).sort((e, t) => t.n - e.n), i = G(n.cubes, t), a = r.filter((e) => e.n > i).length, o = r.filter((e) => e.n === i).length;
		u += Math.floor([
			8,
			4,
			2,
			0
		].slice(a, a + o).reduce((e, t) => e + t, 0) / o);
	}
	return {
		rid: t,
		points: n.vp,
		merchants: i,
		events: a,
		cathedral: s,
		characters: c,
		activities: l,
		outdoors: u,
		total: n.vp + i + a + s + c + l + u
	};
}
//#endregion
//#region src/games/troyes/solo-rules.ts
var je = {
	r: [
		5,
		4,
		3,
		2,
		1,
		0
	],
	y: [
		0,
		2,
		4,
		1,
		3,
		5
	],
	w: [
		3,
		0,
		4,
		1,
		5,
		2
	]
}, Me = (e, t) => e.dice.filter((e) => e.owner === t).sort((e, t) => t.value - e.value || [
	"r",
	"y",
	"w",
	"p"
].indexOf(e.color) - [
	"r",
	"y",
	"w",
	"p"
].indexOf(t.color));
function Z(e, t) {
	let n = Me(e, P).slice(0, t).map((e) => e.id);
	e.dice = e.dice.filter((e) => !n.includes(e.id));
}
function Ne(e, t) {
	if (t.op === "roySetup") {
		let t = C.flatMap((t) => [0, 1].map(() => ({
			color: t,
			value: V(e)
		}))).sort((e, t) => t.value - e.value || [
			"r",
			"y",
			"w"
		].indexOf(e.color) - [
			"r",
			"y",
			"w"
		].indexOf(t.color));
		for (let n = 0; n < 3; n++) {
			let n = t.find((t) => e.buildings[t.color].includes(null))?.color ?? C.find((t) => e.buildings[t].includes(null));
			if (!n) break;
			let r = t.findIndex((e) => e.color === n);
			r >= 0 && t.splice(r, 1);
			let i = je[n].find((t) => e.buildings[n][t] === null);
			e.buildings[n][i] = P, I(e, P).supply--;
		}
		return !0;
	}
	if (t.op !== "royAction") return !1;
	let n = Me(e, P), r = e.players.find((e) => e.rid !== P);
	if (e.active = P, e.actionActor = P, !n.length) return I(e, P).passed = !0, z(e, L("advance", P)), !0;
	let i = V(e) + V(e);
	if (U(e, "royAction", P, { value: i }), [
		2,
		3,
		11,
		12
	].includes(i)) {
		let t = i === 2 || i === 12 ? 6 : 4, n = t === 6 ? 2 : 1, a = Me(e, r.rid)[0];
		a ? (e.dice = e.dice.filter((e) => e.id !== a.id), W(e, r.rid, "money", t), Z(e, n)) : Z(e, n + 1), W(e, P, "vp", 2);
	}
	if ([4, 10].includes(i)) {
		let t = n[0].color;
		Z(e, 1);
		let i = Array.from({ length: 6 }, (e, t) => t + 1).filter((n) => de(e, t, n));
		i.sort((n, i) => {
			let a = (n) => ue(e, t, n);
			return Number(a(i) === r.rid) - Number(a(n) === r.rid) || je[t].indexOf(n - 1) - je[t].indexOf(i - 1);
		}), i.length && I(e, "$roy").supply && (I(e, P).supply--, fe(e, P, t, i[0]));
	}
	if ([5, 9].includes(i)) {
		let t = q(e, P, e.events.at(-1).uid, 20);
		Z(e, t.length), z(e, ...t);
	}
	if (i === 6) {
		Z(e, 1);
		let t = e.activities.filter((e) => e.revealed && !e.merchants.some((e) => e.owner === "$roy")).flatMap((e) => T(e.id).slots.map((t, n) => ({
			a: e,
			vp: t,
			slot: n
		})).filter((t) => !e.merchants.some((e) => e.slot === t.slot))).sort((e, t) => t.vp - e.vp || T(e.a.id).cost - T(t.a.id).cost || [
			"r",
			"y",
			"w"
		].indexOf(T(e.a.id).color) - [
			"r",
			"y",
			"w"
		].indexOf(T(t.a.id).color));
		t.length && I(e, "$roy").supply && (t[0].a.merchants.push({
			owner: P,
			slot: t[0].slot
		}), I(e, P).supply--);
	}
	if (i === 7) {
		Z(e, 2);
		let t = !1;
		for (let n = 0; n < 2; n++) {
			let n = e.cathedral.map((e) => e.length), r = Math.min(...n), i = n.lastIndexOf(r);
			r < 3 && (e.cathedral[i].push(P), t = !0, W(e, P, "vp", 1));
		}
		t || W(e, P, "vp", 2);
	}
	if (i === 8) {
		let t = e.charactersDeck.shift();
		if (t) {
			for (let n of e.players) W(e, n.rid, "vp", ke(e, n.rid, t));
			e.publicCharacters.push(t), U(e, "royCharacter", P, { card: t });
		} else W(e, P, "vp", 1);
	}
	return e.agenda.push(L("advance", P)), !0;
}
//#endregion
//#region src/games/troyes/effects.ts
function Pe(e, t, n) {
	let [r, i, a] = (n ?? "").split(":");
	return r === "b" ? `cell:${i}:${a}` : r === "a" ? `card:${e.activities[+i].id}` : r === "e" ? `expelled:${i}` : `seat:${t}`;
}
function Fe(e, t, n) {
	let r = n.rid, i = [], a = (e, t, n, a = {}) => i.push({
		kind: "troyesMove",
		rid: r,
		data: {
			from: e,
			to: t,
			piece: n,
			...a
		},
		...i.length ? { with: !0 } : {}
	});
	if ([
		"workforce",
		"rollDie",
		"flip",
		"outdoorDie",
		"blackRoll"
	].includes(n.op)) {
		for (let r of t.dice.filter((t) => n.op === "workforce" || !e.dice.some((e) => e.id === t.id && e.value === t.value))) i.push({
			kind: "troyesRoll",
			rid: r.owner,
			data: {
				target: `die:${r.id}`,
				color: r.color,
				value: r.value
			},
			...i.length ? { with: !0 } : {}
		});
		n.op === "blackRoll" && t.black.forEach((e, t) => i.push({
			kind: "troyesRoll",
			data: {
				target: `black:${t}`,
				color: "black",
				value: e
			},
			...i.length ? { with: !0 } : {}
		}));
	}
	if (n.op === "spendDice") {
		let n = t.agenda.find((e) => [
			"activate",
			"placeBuilding",
			"cathedralCube",
			"eventCube",
			"agriculture",
			"rampartsStart"
		].includes(e.op)), i = n?.op === "activate" ? `card:${n.card}` : n?.op === "placeBuilding" ? `building:${n.color}` : n?.op === "cathedralCube" ? `cathedral:${n.value + 1}` : n?.op === "eventCube" ? `event:${n.target}` : n?.op === "rampartsStart" ? "ramparts" : `seat:${r}`;
		for (let t of e.dice.filter((t) => e.draft.dice.includes(t.id))) a(`district:${t.owner}`, i, "die", {
			color: t.color,
			value: t.value
		});
	}
	if (n.op === "initialCitizen" && a(`seat:${r}`, `cell:${n.color}:${n.n}`, "citizen", { hide: `cell:${n.color}:${n.n}` }), n.op === "placeBuilding") {
		let i = t.buildings[n.color].findIndex((t, i) => t === r && e.buildings[n.color][i] !== t);
		i >= 0 && a(Pe(e, r, n.ref), `cell:${n.color}:${i}`, "citizen", { hide: `cell:${n.color}:${i}` });
	}
	if (n.op === "hireActivity") {
		let i = `merchant:${n.card}:${t.activities.find((e) => e.id === n.card).merchants.length - 1}`;
		a(Pe(e, r, n.ref), i, "citizen", { hide: i });
	}
	if (n.op === "cathedralCube" && t.cathedral[n.value].length > e.cathedral[n.value].length) {
		let t = `cube:cathedral:${n.value}:${e.cathedral[n.value].length}:0`;
		a(`seat:${r}`, t, "cube", { hide: t });
	}
	if ([
		"activityCube",
		"fortCube",
		"outdoorCube"
	].includes(n.op)) {
		let e = n.op === "outdoorCube" ? t.outdoors.find((e) => e.id === n.card).cubes : t.activities.find((e) => e.id === n.card).cubes, i = `cube:${n.op === "outdoorCube" ? "outdoor" : "activity"}:${n.card}:${e.length - 1}`;
		a(`seat:${r}`, i, "cube", { hide: i });
	}
	if (n.op === "eventCube" && t.events.find((e) => e.uid === n.target)?.cubes.length !== e.events.find((e) => e.uid === n.target)?.cubes.length) {
		let e = `cube:event:${n.target}:${t.events.find((e) => e.uid === n.target).cubes.length - 1}:0`;
		a(`seat:${r}`, e, "cube", { hide: e });
	}
	if (n.op === "resolveEvent") {
		let r = e.events.find((e) => e.uid === n.target), i = t.log.at(-1)?.rid;
		r && i && a("event-area", `seat:${i}`, "card");
	}
	if (n.op === "guardMove") {
		let n = t.players.find((e) => e.rid === r).guard, i = `guard-piece:${n}:${t.players.filter((e) => e.guard === n).findIndex((e) => e.rid === r)}`;
		a(`guard:${e.players.find((e) => e.rid === r).guard}`, i, "citizen", { hide: i });
	}
	if (n.op === "exchangeDice") {
		let t = e.dice.find((e) => e.id === n.ref), r = e.dice.find((e) => e.id === n.target);
		a(`district:${t.owner}`, `district:${r.owner}`, "die", {
			color: t.color,
			value: t.value
		}), a(`district:${r.owner}`, `district:${t.owner}`, "die", {
			color: r.color,
			value: r.value
		});
	}
	for (let n of [
		"r",
		"w",
		"y"
	]) if (t.expelled[n].length > e.expelled[n].length) for (let r of t.expelled[n].slice(e.expelled[n].length)) a(`building:${n}`, `expelled:${n}`, "citizen", { owner: r });
	return i;
}
//#endregion
//#region src/games/troyes/meta.ts
var Ie = {
	id: "troyes",
	tier: "alpha",
	mechanics: [
		"dice-rolling",
		"drafting",
		"worker-placement",
		"engine-building"
	],
	interactionTags: ["hidden-roles"],
	nameKey: "games.troyes.name",
	descKey: "games.troyes.desc",
	rulesKey: "games.troyes.rules",
	icon: "🏰",
	iconImg: "games/troyes.webp",
	accent: "#8a3433",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	hotseat: "cover",
	releasedAt: "2026-10-31T12:47:00+08:00",
	search: {
		py: "te lu wa",
		init: "tlw"
	},
	rulesUrl: { en: "https://pearlgames.be/wp-content/uploads/2017/08/TROYES_RULES_ENG_04_04_17LD.pdf" }
}, Le = t.object({
	bonus: t.boolean().default(!1),
	ladiesCharacters: t.boolean().default(!1),
	publicCharacter: t.boolean().default(!1),
	activities: t.enum([
		"base",
		"ladies",
		"mixed"
	]).default("base"),
	ladiesEvents: t.boolean().default(!1),
	family: t.boolean().default(!1),
	ramparts: t.boolean().default(!1),
	tournament: t.boolean().default(!1)
}).prefault({}), Re = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(120)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), ze = t.enum([
	"r",
	"w",
	"y"
]), Be = t.object({
	id: t.string(),
	owner: t.string(),
	color: t.enum([
		"r",
		"w",
		"y",
		"p"
	]),
	value: t.int().min(1).max(6)
}), Ve = t.object({
	id: t.string(),
	kind: t.string(),
	card: t.string().optional(),
	ref: t.string().optional(),
	color: ze.optional(),
	n: t.int().optional(),
	value: t.int().optional(),
	target: t.string().optional()
}), He = t.object({
	id: t.string(),
	revealed: t.boolean(),
	merchants: t.array(t.object({
		owner: t.string(),
		slot: t.int()
	})),
	cubes: t.array(t.string())
}), Ue = t.object({
	uid: t.string(),
	id: t.string(),
	cubes: t.array(t.string()),
	captives: t.array(t.string())
}), We = t.object({
	rid: t.string(),
	money: t.int().nonnegative(),
	influence: t.int().min(0).max(20),
	supply: t.int().nonnegative(),
	total: t.int().nonnegative(),
	passed: t.boolean(),
	passMoney: t.int().nonnegative(),
	guard: t.int().min(0).max(20),
	captured: t.array(t.string()),
	vp: t.int().nullable(),
	characters: t.array(t.string())
}), Ge = t.object({
	dice: t.array(t.string()),
	black: t.array(t.int()),
	modifier: t.string().nullable(),
	param: t.int(),
	color: ze,
	outdoor: t.array(t.string()),
	flip: t.string().nullable()
}), Ke = t.object({
	kind: t.string(),
	rid: t.string(),
	card: t.string().optional(),
	target: t.string().optional(),
	n: t.int().optional(),
	value: t.int().optional()
}), qe = t.object({
	rid: t.string(),
	points: t.int(),
	merchants: t.int(),
	events: t.int(),
	cathedral: t.int(),
	characters: t.int(),
	activities: t.int(),
	outdoors: t.int(),
	total: t.int()
}), Je = t.object({
	config: Le,
	solo: t.boolean(),
	round: t.int(),
	rounds: t.int(),
	phase: t.enum([
		"setup",
		"income",
		"reveal",
		"events",
		"defend",
		"action",
		"roundEnd",
		"score",
		"done"
	]),
	first: t.string(),
	active: t.string(),
	players: t.array(We),
	buildings: t.object({
		r: t.array(t.string().nullable()),
		w: t.array(t.string().nullable()),
		y: t.array(t.string().nullable())
	}),
	expelled: t.object({
		r: t.array(t.string()),
		w: t.array(t.string()),
		y: t.array(t.string())
	}),
	cathedral: t.array(t.array(t.string())),
	activities: t.array(He),
	events: t.array(Ue),
	dice: t.array(Be),
	black: t.array(t.int()),
	draft: Ge,
	outdoors: t.array(t.object({
		id: t.string(),
		cubes: t.array(t.string()),
		arrivals: t.array(t.string())
	})),
	publicCharacters: t.array(t.string()),
	pending: t.object({
		rid: t.string(),
		kind: t.string()
	}).nullable(),
	log: t.array(Ke),
	final: t.array(qe)
}), Ye = t.object({
	vp: t.int(),
	characters: t.array(t.string()),
	choices: t.array(Ve)
});
//#endregion
//#region src/games/troyes/rules.ts
function Xe(e, t, n) {
	let r = Le.parse(e), i = t.length === 1;
	i && Object.assign(r, {
		ladiesCharacters: !1,
		publicCharacter: !1,
		activities: "base",
		ladiesEvents: !1,
		family: !1,
		ramparts: !1,
		tournament: !1
	});
	let a = {
		config: r,
		solo: i,
		round: 1,
		rounds: i ? 4 : t.length + 2,
		phase: "setup",
		first: t[0],
		active: t[0],
		players: [],
		buildings: {
			r: [
				,
				,
				,
				,
				,
				,
			].fill(null),
			w: [
				,
				,
				,
				,
				,
				,
			].fill(null),
			y: [
				,
				,
				,
				,
				,
				,
			].fill(null)
		},
		expelled: {
			r: [],
			w: [],
			y: []
		},
		cathedral: Array.from({ length: 6 }, () => []),
		activities: [],
		events: [{
			uid: "marauding",
			id: "marauding",
			cubes: [],
			captives: []
		}],
		dice: [],
		black: [],
		draft: F(),
		outdoors: [],
		publicCharacters: [],
		log: [],
		final: [],
		agenda: [],
		decision: null,
		seed: n,
		cursor: 0,
		serial: 0,
		diceSerial: 0,
		beat: 0,
		setupOrder: [],
		decks: {
			r: [],
			w: [],
			y: []
		},
		unusedRed: [],
		charactersDeck: [],
		eventCursor: 0,
		blackCount: 0,
		turnDirection: 1,
		rampartUsed: [],
		rampartColor: "",
		actionActor: "",
		actionCard: null,
		actionDice: [],
		currentEffect: null,
		actionPlacedCube: !1
	}, o = H(a, ae.slice(0, r.ladiesCharacters ? 9 : 6));
	for (let e of [...t, ...i ? [P] : []]) a.players.push({
		rid: e,
		money: e === "$roy" ? 0 : 5,
		influence: e === "$roy" ? 0 : 4,
		vp: 0,
		supply: e === "$roy" ? 24 : i || t.length === 2 ? 6 : t.length === 3 ? 5 : 4,
		total: e === "$roy" ? 24 : i || t.length === 2 ? 6 : t.length === 3 ? 5 : 4,
		passed: !1,
		passMoney: 0,
		guard: 0,
		captured: [],
		characters: i ? [] : o.splice(0, t.length === 2 ? 2 : 1)
	});
	i ? a.charactersDeck = o : r.publicCharacter && (a.publicCharacters = o.splice(0, 1));
	for (let e of C) for (let t of [
		1,
		2,
		3
	]) {
		let n = w.filter((n) => n.color === e && n.level === t && (n.scope === "base" ? r.activities !== "ladies" : n.scope === "ladies" ? r.activities !== "base" : r.bonus));
		a.activities.push({
			id: H(a, n)[0].id,
			revealed: !1,
			merchants: [],
			cubes: []
		});
	}
	for (let e of C) a.decks[e] = H(a, E.filter((t) => t.color === e && (t.scope === "base" || t.scope === "bonus" && r.bonus || t.scope === "ladies" && r.ladiesEvents)).map((e) => e.id));
	a.unusedRed = a.decks.r.slice(a.rounds), a.decks.r = a.decks.r.slice(0, a.rounds), r.ramparts && (a.outdoors = O.map((e) => ({
		id: H(a, e)[0],
		cubes: [],
		arrivals: []
	})));
	let s = i || t.length === 2 ? 6 : t.length === 3 ? 5 : 4;
	if (!i && t.length === 2 && C.forEach((e) => {
		a.buildings[e][0] = N, a.buildings[e][5] = N;
	}), i) {
		for (let e = 0; e < 3; e++) a.agenda.push(L("roySetup"), L("setupMenu", t[0]), L("setupMenu", t[0]));
		a.agenda.push(L("roySetup"), L("setupEnd"));
	} else {
		for (let e = 0; e < s; e++) a.setupOrder.push(...e % 2 == 0 ? t : [...t].reverse());
		a.agenda = [L("setupNext")];
	}
	return {
		state: a,
		fx: []
	};
}
function Ze(e, t) {
	if (e.phase = "defend", e.active = t, !e.black.length) {
		e.draft = F(), z(e, L(e.solo && e.first === "$roy" ? "royAction" : "actionMenu", e.first));
		return;
	}
	if (e.solo && t === "$roy") {
		let n = e.dice.filter((e) => e.owner === P).sort((e, t) => t.value - e.value || [
			"r",
			"y",
			"w"
		].indexOf(e.color) - [
			"r",
			"y",
			"w"
		].indexOf(t.color))[0];
		n && (e.dice = e.dice.filter((e) => e.id !== n.id)), e.black.shift(), z(e, L("defendNext", t));
		return;
	}
	let n = e.dice.filter((e) => e.owner === t), r = (e) => n.filter((t) => e.includes(t.id)).reduce((e, t) => e + t.value * (t.color === "r" || t.color === "p" ? 2 : 1), 0), i = Te(e, t);
	n.forEach((e) => i.push(R({
		kind: "die",
		ref: e.id
	}, L("selectDie", t, { ref: e.id }), L("defendMenu", t)))), e.black.forEach((e, n) => {
		n && i.push(R({
			kind: "black",
			n,
			value: e
		}, L("selectBlack", t, { n }), L("defendMenu", t)));
	});
	let a = e.draft.black.reduce((t, n) => t + (e.black[n] ?? 0), 0);
	r(e.draft.dice) >= a && i.push(R({
		kind: "defend",
		n: e.draft.black.length,
		value: a
	}, L("defend", t), L("defendNext", t))), r(n.map((e) => e.id)) < e.black[0] && i.push(R({ kind: "loseDefense" }, L("loseDefense", t), L("defendNext", t))), e.outdoors.find((e) => e.id === "protect")?.cubes.includes(t) && i.push(R({
		kind: "protect",
		card: "protect"
	}, L("spendOutdoor", t, { card: "protect" }), L("protectBlack", t), L("defendNext", t))), e.draft.dice.length && i.push(R({ kind: "clear" }, L("clearDraft", t), L("defendMenu", t))), B(e, t, "defend", i);
}
function Qe(e, t) {
	let n = t.rid, r = e.players.find((e) => e.rid === n);
	switch (t.op) {
		case "setupNext": {
			let t = e.setupOrder.shift();
			return t ? z(e, L("setupMenu", t), L("setupNext")) : z(e, L("setupEnd")), !0;
		}
		case "setupMenu": return e.phase = "setup", e.active = n, B(e, n, "setup", C.flatMap((t) => e.buildings[t].flatMap((e, r) => e === null ? [R({
			kind: "setup",
			color: t,
			n: r
		}, L("initialCitizen", n, {
			color: t,
			n: r
		}))] : []))), !0;
		case "initialCitizen": return e.buildings[t.color][t.n] = n, r.supply--, U(e, "initialCitizen", n, {
			target: `building:${t.color}`,
			value: t.n
		}), !0;
		case "setupEnd": return e.solo || C.forEach((t) => {
			e.buildings[t] = e.buildings[t].map((e) => e ?? "$neutral");
		}), z(e, L("roundStart")), !0;
		case "roundStart": return e.phase = "reveal", z(e, ...e.activities.filter((t) => T(t.id).level === e.round).map((e) => L("reveal", "", { card: e.id })), ...e.players.map((e) => L("income", e.rid)), L("workforce"), L("drawEvent", "", { card: e.decks.r.shift() }), L("eventQueue")), !0;
		case "reveal": return e.activities.find((e) => e.id === t.card).revealed = !0, U(e, "reveal", "", { card: t.card }), !0;
		case "income":
			if (e.phase = "income", n !== "$roy") {
				W(e, n, "money", 10);
				let t = G(e.buildings.w, n) + G(e.buildings.r, n) * 2;
				r.money < t && W(e, n, "vp", -2), W(e, n, "money", -t), U(e, "income", n, {
					n: 10,
					value: t
				});
			}
			return !0;
		case "workforce": return e.dice = [], C.forEach((t) => e.buildings[t].forEach((n) => {
			n && se(e, n, t);
		})), e.config.family && e.players.forEach((t) => se(e, t.rid, "p")), U(e, "workforce", "", { n: e.dice.length }), !0;
		case "eventQueue": return e.phase = "events", e.blackCount = 0, z(e, ...e.events.map((e) => L("eventEffect", "", { target: e.uid })), L("blackRoll")), !0;
		case "blackRoll": {
			let t = e.events.some((e) => e.id === "chiefOutlaw") ? 3 : 0;
			return e.black = Array.from({ length: e.blackCount }, () => Math.min(6, V(e) + t)).sort((e, t) => t - e), e.draft = F(), U(e, "blackRoll", "", { n: e.black.length }), z(e, L("defendMenu", e.first)), !0;
		}
		case "defendMenu": return Ze(e, n), !0;
		case "selectBlack": {
			let n = e.draft.black.indexOf(t.n);
			return n >= 0 ? e.draft.black.splice(n, 1) : e.draft.black.push(t.n), !0;
		}
		case "defend": return e.dice = e.dice.filter((t) => !e.draft.dice.includes(t.id)), e.black = e.black.filter((t, n) => !e.draft.black.includes(n)), W(e, n, "influence", e.draft.black.length), U(e, "defend", n, { n: e.draft.black.length }), !0;
		case "loseDefense": return e.black.shift(), W(e, n, "vp", -2), U(e, "loseDefense", n), !0;
		case "protectBlack": return e.black.shift(), W(e, n, "influence", 1), U(e, "defend", n, { n: 1 }), !0;
		case "defendNext": return e.draft = F(), z(e, L("defendMenu", ce(e, n))), !0;
		case "rollDie": {
			let r = e.dice.find((e) => e.id === t.ref);
			return r.value = V(e), U(e, "reroll", n, { value: r.value }), !0;
		}
		case "placeCitizen": return fe(e, n, t.color, t.value), !0;
		case "roundEnd": return e.phase = "roundEnd", e.dice = [], e.players.forEach((t) => {
			W(e, t.rid, "money", t.passMoney), t.passed = !1, t.passMoney = 0;
		}), C.forEach((t) => {
			e.expelled[t].forEach((t) => {
				let n = e.players.find((e) => e.rid === t);
				n && n.supply++;
			}), e.expelled[t] = [];
		}), U(e, "roundEnd", "", { n: e.round }), e.round === e.rounds ? (e.phase = "score", z(e, ...e.players.map((e) => L("score", e.rid)), L("finish"))) : (e.config.tournament && e.players.length >= 3 && e.round === e.rounds - 1 && (e.turnDirection = -1), e.first = ce(e, e.first), e.round++, z(e, L("roundStart"))), !0;
		case "score": return e.final.push(Ae(e, n)), U(e, "score", n), !0;
		case "finish": return e.phase = "done", e.decision = null, e.agenda = [], !0;
		default: return !1;
	}
}
function $e(e, t, n) {
	if (e.phase === "done") return { code: "games.troyes.errFinished" };
	if (t.type === "choose" && e.decision?.rid !== n.by) return { code: "games.troyes.errTurn" };
	if (t.type === "choose" && !e.decision?.offers.some((e) => e.option.id === t.id)) return { code: "games.troyes.errChoice" };
	if (t.type === "tick" && (n.by !== "$engine" || e.decision || !e.agenda.length)) return {
		state: e,
		fx: []
	};
	let r = structuredClone(e), i = [];
	if (t.type === "choose") {
		let e = r.decision.offers.find((e) => e.option.id === t.id);
		r.decision = null, z(r, ...e.jobs);
	} else {
		let t = r.agenda.shift();
		if (!(Qe(r, t) || De(r, t) || Se(r, t) || ve(r, t) || Oe(r, t) || Ne(r, t))) throw Error(`Unknown Troyes operation ${t.op}`);
		i.push(...Fe(e, r, t));
	}
	!r.decision && !r.agenda.length && r.phase === "action" && B(r, r.active, "action", Ee(r, r.active));
	let a = r.log.length > e.log.length ? r.log.at(-1) : null;
	a && !i.length && i.push({
		kind: "troyesAction",
		rid: a.rid,
		data: a
	});
	for (let t of r.players) {
		let n = I(e, t.rid), r = t.money - n.money, a = t.influence - n.influence;
		(r || a) && i.push({
			kind: "troyesResources",
			rid: t.rid,
			data: {
				money: r,
				influence: a
			},
			...i.length ? { with: !0 } : {}
		});
	}
	return r.beat = i.length ? 400 : 0, {
		state: r,
		fx: i
	};
}
function et(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.phase === "done";
	return {
		public: {
			config: e.config,
			solo: e.solo,
			round: e.round,
			rounds: e.rounds,
			phase: e.phase,
			first: e.first,
			active: e.active,
			players: e.players.map((e) => ({
				...e,
				vp: r ? e.vp : null,
				characters: r ? e.characters : []
			})),
			buildings: e.buildings,
			expelled: e.expelled,
			cathedral: e.cathedral,
			activities: e.activities.map((e) => e.revealed ? e : {
				...e,
				id: `back:${T(e.id).color}:${T(e.id).level}`
			}),
			events: e.events,
			dice: e.dice,
			black: e.black,
			draft: e.draft,
			outdoors: e.outdoors,
			publicCharacters: e.publicCharacters,
			pending: e.decision ? {
				rid: e.decision.rid,
				kind: e.decision.kind
			} : null,
			log: e.log,
			final: e.final
		},
		private: {
			vp: n?.vp ?? 0,
			characters: n?.characters ?? [],
			choices: e.decision?.rid === t ? e.decision.offers.map((e) => e.option) : []
		}
	};
}
function tt(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.final].sort((e, t) => t.total - e.total).map((e) => e.rid), n = e.final.find((e) => e.rid === t[0]).total, r = t.filter((t) => e.final.find((e) => e.rid === t).total === n);
	return {
		phase: "done",
		ranking: e.solo ? t.filter((e) => e !== P) : t,
		winner: e.solo ? r.filter((e) => e !== P) : r,
		scores: Object.fromEntries(e.final.filter((t) => !e.solo || t.rid !== "$roy").map((t) => [t.rid, e.solo ? t.total - e.final.find((e) => e.rid === P).total : t.total]))
	};
}
var nt = {
	meta: Ie,
	schemas: {
		action: Re,
		publicView: Je,
		privateView: Ye,
		config: Le
	},
	saveCompatibility: { version: "1" },
	setup: Xe,
	reduce: $e,
	viewFor: et,
	status: tt,
	nextTickIn: (e) => e.phase !== "done" && !e.decision && e.agenda.length ? e.beat : null
}, rt = {
	r: "#b95340",
	w: "#eee5cf",
	y: "#d3ac3c",
	p: "#7b527b",
	black: "#302b28"
}, it = [
	[32, 32],
	[16, 16],
	[48, 48],
	[48, 16],
	[16, 48],
	[16, 32],
	[48, 32]
], at = [
	[0],
	[1, 2],
	[
		0,
		1,
		2
	],
	[
		1,
		2,
		3,
		4
	],
	[
		0,
		1,
		2,
		3,
		4
	],
	[
		1,
		2,
		3,
		4,
		5,
		6
	]
];
function ot({ color: e, value: t }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 64 68",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ m("rect", {
				x: "3",
				y: "7",
				width: "58",
				height: "58",
				rx: "11",
				fill: "#382b21",
				opacity: ".3"
			}),
			/* @__PURE__ */ m("rect", {
				x: "3",
				y: "3",
				width: "58",
				height: "58",
				rx: "11",
				fill: rt[e],
				stroke: "#49372a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ m("path", {
				d: "M12 9H51",
				stroke: "#fff",
				opacity: ".35",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			(at[t - 1] ?? []).map((t) => /* @__PURE__ */ m("circle", {
				cx: it[t][0],
				cy: it[t][1],
				r: "5",
				fill: e === "r" || e === "black" || e === "p" ? "#fff0cc" : "#43372c"
			}, t))
		]
	});
}
function Q({ color: e }) {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 40 46",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("path", {
			d: "M13 5Q20-1 27 5L27 14L37 22L32 28L27 25L31 42H23L20 33L17 42H9L13 25L8 28L3 22L13 14Z",
			fill: e,
			stroke: "#49372a",
			strokeWidth: "2.5",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ m("path", {
			d: "M16 7Q20 4 24 7M15 19L10 22",
			fill: "none",
			stroke: "#fff",
			opacity: ".45",
			strokeWidth: "2"
		})]
	});
}
function st({ color: e }) {
	let t = e === "cathedral", n = t ? "#baa68a" : rt[e];
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 300 120",
		"aria-hidden": !0,
		className: "troyes-architecture",
		children: /* @__PURE__ */ h("g", {
			fill: n,
			stroke: "#66513c",
			strokeWidth: "2",
			children: [
				/* @__PURE__ */ m("path", { d: "M18 112V43H282V112Z" }),
				/* @__PURE__ */ m("path", {
					d: "M12 44L52 13H248L288 44Z",
					fill: t ? "#716b63" : e === "r" ? "#8e4439" : "#9f8461"
				}),
				/* @__PURE__ */ m("path", { d: "M128 110V25L150 2L172 25V110Z" }),
				/* @__PURE__ */ m("path", {
					d: "M121 26L150 0L179 26Z",
					fill: "#64594e"
				}),
				[
					40,
					75,
					207,
					242
				].map((e) => /* @__PURE__ */ m("path", {
					d: `M${e} 91V62Q${e + 8} 44 ${e + 16} 62V91Z`,
					fill: "#6b6b61"
				}, e)),
				/* @__PURE__ */ m("path", {
					d: "M138 112V76Q150 52 162 76V112Z",
					fill: "#66513e"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "150",
					cy: "37",
					r: "8",
					fill: "#ece0bc"
				}),
				/* @__PURE__ */ m("path", {
					d: "M150 31V37L154 40",
					fill: "none"
				}),
				/* @__PURE__ */ m("path", {
					d: "M22 102H278M22 54H124M176 54H278",
					opacity: ".4"
				})
			]
		})
	});
}
function ct() {
	return /* @__PURE__ */ m("svg", {
		className: "troyes-target",
		"aria-hidden": !0,
		children: /* @__PURE__ */ m("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "9"
		})
	});
}
//#endregion
//#region src/games/troyes/locales/content.ts
var lt = [
	[
		"artisan",
		"工匠",
		"Artisan",
		"每次支付1点影响力，获得6第纳尔。",
		"Spend 1 Influence to gain 6 deniers per activation."
	],
	[
		"merchant",
		"商贩",
		"Merchant",
		"每次获得2第纳尔。",
		"Gain 2 deniers per activation."
	],
	[
		"miller",
		"磨坊主",
		"Miller",
		"每次选择伯爵宫或主教府，按其中每名己方市民获得2第纳尔，不计被逐市民。",
		"Choose the Palace or Bishopric each activation. Gain 2 deniers per citizen you have there, excluding expelled citizens."
	],
	[
		"innkeeper",
		"旅店老板",
		"Innkeeper",
		"每次可支付1第纳尔，获得1点影响力。",
		"Pay 1 denier to gain 1 Influence per activation."
	],
	[
		"blacksmith",
		"铁匠",
		"Blacksmith",
		"储存方块。以后弃1方块，使一组红骰总值增加5；不能用于伯爵宫。",
		"Store cubes. Discard one later to add 5 to a red group; it cannot place a citizen on the Palace."
	],
	[
		"militiaman",
		"民兵",
		"Militiaman",
		"储存方块。以后弃1方块，将1至3颗黄骰作为同值红骰使用，该行动只用黄骰。",
		"Store cubes. Discard one later to use 1–3 yellow dice as red dice of the same values; use only yellow dice."
	],
	[
		"journeyman",
		"熟练工",
		"Journeyman",
		"每次可支付3第纳尔，获得2分。",
		"Pay 3 deniers to gain 2 VP per activation."
	],
	[
		"goldsmith",
		"金匠",
		"Goldsmith",
		"每次获得1分和2第纳尔。",
		"Gain 1 VP and 2 deniers per activation."
	],
	[
		"sculptor",
		"雕刻家",
		"Sculptor",
		"每次获得1分。",
		"Gain 1 VP per activation."
	],
	[
		"tithe",
		"什一税",
		"Tithe",
		"储存方块。以后弃1方块组黄骰时，可从每个其他城区各取1颗免费黄骰，包括中立城区。",
		"Store cubes. Discard one later to take up to one yellow die free from each other district, including the neutral district."
	],
	[
		"monk",
		"修士",
		"Monk",
		"储存方块。以后弃1方块，将单颗白骰作为3颗同值黄骰，不能加骰；外购仍只支付2第纳尔。",
		"Store cubes. Discard one later to use a single white die as three equal yellow dice, with no additional dice. A purchased die costs 2 deniers."
	],
	[
		"priest",
		"教士",
		"Priest",
		"储存方块。以后弃1方块，使组内每颗黄骰增加3，允许超过6；不能用于市政厅。",
		"Store cubes. Discard one later to add 3 to each yellow die, exceeding 6 if needed; the group cannot place a citizen on City Hall."
	],
	[
		"apprenticeship",
		"学徒制",
		"Apprenticeship",
		"储存方块。以后弃1方块，将组内每颗骰子改为5，可用于混色组；不能用于主教府、市政厅或教堂，单颗红骰仍可用于伯爵宫。",
		"Store cubes. Discard one later to set each die to 5, including mixed groups. It cannot be used for the Bishopric, City Hall or Cathedral; a single red die can still be used for the Palace."
	],
	[
		"confession",
		"告解",
		"Confession",
		"储存方块。以后弃1方块，使组内每颗骰子增加2，可超过6；不能用于主教府、市政厅或教堂，点数不超过6的单颗红骰仍可用于伯爵宫。",
		"Store cubes. Discard one later to add 2 to each die, possibly exceeding 6. It cannot be used for the Bishopric, City Hall or Cathedral; a single red die valued at most 6 can still be used for the Palace."
	],
	[
		"templar",
		"圣殿骑士",
		"Templar",
		"储存方块。以后弃1方块，将单颗白骰作为2颗同值红骰，不能加骰；外购仍只支付2第纳尔。",
		"Store cubes. Discard one later to use one white die as two equal red dice, with no additional dice. A purchased die costs 2 deniers."
	],
	[
		"pilgrimage",
		"朝圣",
		"Pilgrimage",
		"每次获得2分，可使用混色骰组；混色时只能用学徒制或告解改骰。",
		"Gain 2 VP per activation. Mixed colors are allowed; only Apprenticeship or Confession can modify a mixed group."
	],
	[
		"procession",
		"游行",
		"Procession",
		"每次由城区剩余骰子最多者获得2分，至少有1颗；并列者均获得2分，包含紫骰。",
		"Each activation awards 2 VP to every district tied for most remaining dice, provided it has at least one. Purple dice count."
	],
	[
		"glassblower",
		"玻璃工",
		"Glassblower",
		"每次按教堂中每2个己方方块获得1分。",
		"Gain 1 VP per two of your Cathedral cubes per activation."
	],
	[
		"archer",
		"弓箭手",
		"Archer",
		"每次掷骰，结果至少3时，在一张事件牌上放1方块并获得1点影响力，不能修改此掷骰。",
		"Roll a die per activation. On 3 or more, place one event cube and gain 1 Influence. This roll cannot be modified."
	],
	[
		"chivalry",
		"骑士精神",
		"Chivalry",
		"每次按己方城区剩余每颗红骰，在事件牌上放1方块，每个方块获得1点影响力。",
		"For each red die remaining in your district, place one event cube per activation and gain 1 Influence per cube."
	],
	[
		"diplomat",
		"外交官",
		"Diplomat",
		"先支付最多等于激活次数的影响力，再为每点在事件牌上放1方块；每个方块获得1点影响力。",
		"Pay up to the activation count in Influence before placing cubes. Place one event cube and gain 1 Influence for each point paid."
	],
	[
		"hunting",
		"狩猎",
		"Hunting",
		"每次获得3点影响力。",
		"Gain 3 Influence per activation."
	],
	[
		"mercenary",
		"雇佣兵",
		"Mercenary",
		"每次获得3第纳尔。",
		"Gain 3 deniers per activation."
	],
	[
		"taxCollector",
		"收税官",
		"Tax Collector",
		"每次由各对手按市政厅每名市民支付你1第纳尔，不足则付尽；中立市民由银行支付。",
		"Each opponent pays 1 denier per City Hall citizen per activation, as much as possible. The bank pays for neutral citizens."
	],
	[
		"captain",
		"队长",
		"Captain",
		"每次按有己方方块的每张未解决事件牌获得1分，包括劫掠。",
		"Gain 1 VP per event bearing your cubes, including Marauding, per activation."
	],
	[
		"joust",
		"马上比武",
		"Joust",
		"每次激活时，剩余红骰总值最高的玩家均获得2分；若多人并列，所有并列玩家均得分。",
		"Each activation grants 2 VP to every player whose remaining red dice total is highest. All tied players score."
	],
	[
		"troubadour",
		"吟游诗人",
		"Troubadour",
		"每次可支付3点影响力，获得2分。",
		"Spend 3 Influence to gain 2 VP per activation."
	],
	[
		"baker",
		"面包师",
		"Baker",
		"每次按所有城区剩余的每颗黄骰获得1第纳尔。",
		"Gain 1 denier per yellow die remaining in all districts per activation."
	],
	[
		"prior",
		"修道院长",
		"Prior",
		"储存方块。以后弃1方块，将单颗白骰作为2颗同值白骰，不能加骰；外购仍支付2第纳尔。",
		"Store cubes. Discard one later to use one white die as two equal white dice, with no additional dice. A purchased die costs 2 deniers."
	],
	[
		"banquet",
		"宴会",
		"Banquet",
		"每次按红骰最多的城区中每颗红骰获得1分，包括中立城区；单人局不计国王城区。",
		"Gain 1 VP per red die in the district with most red dice, including neutral. In solo play exclude le Roy."
	],
	[
		"lumberjack",
		"伐木工",
		"Lumberjack",
		"混合效果：每次放1方块，或弃1个已有方块获得4第纳尔；同一行动不能兼做两者。",
		"Mixed: store one cube or discard an existing cube for 4 deniers per activation. Storing and spending require separate actions."
	],
	[
		"clogMaker",
		"木鞋匠",
		"Clog Maker",
		"每次按市政厅每名己方市民获得1第纳尔，不计被逐市民。",
		"Gain 1 denier per own City Hall citizen per activation, excluding expelled citizens."
	],
	[
		"weaver",
		"织工",
		"Weaver",
		"每次按活动牌上每名己方商人获得1第纳尔，包括本牌。",
		"Gain 1 denier per own tradesman on Activity cards, including this card, per activation."
	],
	[
		"landlady",
		"女店主",
		"Landlady",
		"每次选择获得4点影响力或1分。",
		"Choose 4 Influence or 1 VP each activation."
	],
	[
		"distiller",
		"蒸馏师",
		"Distiller",
		"储存方块。以后弃1方块，在行动中翻转组内1颗自己的骰子。",
		"Store cubes. Discard one later to turn over one of your dice used in the action."
	],
	[
		"viticulturist",
		"葡萄种植者",
		"Viticulturist",
		"储存方块。以后弃1方块，免费取1颗其他城区骰子立即行动，该骰仍计入骰组大小；不能取紫骰。",
		"Store cubes. Discard one later to take one foreign die free and use it immediately. It counts toward group size. Purple dice cannot be taken."
	],
	[
		"banker",
		"银行家",
		"Banker",
		"若拥有超过30第纳尔，每次获得3分，无须支付金钱。",
		"If you have more than 30 deniers, gain 3 VP per activation without spending money."
	],
	[
		"breeder",
		"畜牧者",
		"Breeder",
		"混合效果：每次支付3第纳尔放1方块，或弃1个已有方块获得2分；两者须分行动完成。",
		"Mixed: pay 3 deniers to store one cube, or discard an existing cube for 2 VP, per activation. Use separate actions."
	],
	[
		"masterTradesman",
		"商会大师",
		"Master Tradesman",
		"每次按活动牌上每2名己方商人获得1分，包括本牌。",
		"Gain 1 VP per two own tradesmen on Activity cards, including this card, per activation."
	],
	[
		"augustine",
		"奥古斯丁会士",
		"Augustine",
		"储存方块。以后弃1方块作为己方一颗6点黄骰，须与1至2颗其他骰子组成骰组。",
		"Store cubes. Discard one later as an own yellow 6, grouped with one or two additional dice."
	],
	[
		"bishop",
		"主教",
		"Bishop",
		"每次按教堂中每个己方方块获得1第纳尔。",
		"Gain 1 denier per own Cathedral cube per activation."
	],
	[
		"chiefTemplar",
		"圣殿骑士长",
		"Chief Templar",
		"雇用花费5点影响力。储存方块，以后弃1方块，可从每个其他城区各以2第纳尔购买1颗红骰。",
		"Hiring costs 5 Influence. Store cubes; discard one later to buy up to one red die per other district for 2 deniers each."
	],
	[
		"herbalist",
		"草药师",
		"Herbalist",
		"储存方块。以后弃1方块，将单颗白骰作为3颗同值红骰，不能加骰；外购仍支付2第纳尔。",
		"Store cubes. Discard one later to use one white die as three equal red dice, with no additional dice. A purchased die costs 2 deniers."
	],
	[
		"masterBuilder",
		"建筑大师",
		"Master Builder",
		"每次在任选教堂列的最低空层放1方块，可建第四层。此牌在局时，终局未参与第四层者扣2分。",
		"Place one cube on the lowest empty level of any Cathedral column per activation, including a fourth level. With this card in play, missing level four costs 2 VP at game end."
	],
	[
		"preacher",
		"布道者",
		"Preacher",
		"储存方块。以后弃1方块，选组内1颗骰子，将全组点数改为该骰点数。",
		"Store cubes. Discard one later to set every die in the group to the value of one chosen die."
	],
	[
		"scribe",
		"抄写员",
		"Scribe",
		"每次按已收取的每张事件牌获得1分。",
		"Gain 1 VP per event card you have collected per activation."
	],
	[
		"hermit",
		"隐士",
		"Hermit",
		"储存方块。终局时，每个己方方块获得“9减去本牌全部方块数”分，允许为负。",
		"Store cubes. At game end, each own cube scores 9 minus the total number of cubes on this card, possibly negative."
	],
	[
		"nun",
		"修女",
		"Nun",
		"每次按己方城区剩余的每颗白骰获得1分。",
		"Gain 1 VP per white die remaining in your district per activation."
	],
	[
		"ransom",
		"赎金",
		"Ransom",
		"每次可支付3第纳尔，在一张事件牌上放1方块并获得1点影响力。",
		"Pay 3 deniers per activation to place one event cube and gain 1 Influence."
	],
	[
		"catapult",
		"投石机",
		"Catapult",
		"混合效果：每次放1方块，或弃1个已有方块，在同一张事件牌上放2方块；须分行动装填和发射。",
		"Mixed: store one cube or discard an existing cube to place two cubes on one event per activation. Loading and firing require separate actions."
	],
	[
		"scout",
		"斥候",
		"Scout",
		"每次可向每张事件各支付1第纳尔，放1方块并获得1点影响力。",
		"Each activation, you may pay 1 denier per event to place one cube there and gain 1 Influence."
	],
	[
		"squire",
		"侍从",
		"Squire",
		"混合效果：每次放1方块，或弃1个已有方块获得5点影响力，须分行动完成。",
		"Mixed: store one cube or discard an existing cube for 5 Influence per activation, in separate actions."
	],
	[
		"executioner",
		"刽子手",
		"Executioner",
		"每次获得1点影响力，并从影响力最多的对手处拿取1点；并列时选择一人。",
		"Gain 1 Influence and take 1 from an opponent with most Influence per activation; choose among ties."
	],
	[
		"recruiter",
		"招募官",
		"Recruiter",
		"雇用花费3点影响力。储存方块，以后弃1方块作为己方一颗6点红骰，须与1至2颗其他骰子成组。",
		"Hiring costs 3 Influence. Store cubes; discard one later as an own red 6, grouped with one or two additional dice."
	],
	[
		"marriage",
		"联姻",
		"Marriage",
		"每次可支付7第纳尔，获得4分。",
		"Pay 7 deniers to gain 4 VP per activation."
	],
	[
		"fort",
		"要塞",
		"Fort",
		"组内每颗骰子放1方块：1至3点获得1分和1影响，4至6点获得2分和2影响。终局方块最多者均分3分。",
		"Store one cube per die: values 1–3 earn 1 VP and 1 Influence; 4–6 earn 2 of each. The most cubes share 3 VP at game end."
	],
	[
		"princess",
		"公主",
		"Princess",
		"储存方块。终局方块最多者均分6分，向下取整。",
		"Store cubes. At game end, players with most cubes share 6 VP, rounded down."
	],
	[
		"marauding",
		"劫掠",
		"Marauding",
		"每轮增加1颗黑骰。解决后清空方块，此事件仍留在队列中。",
		"Add one black die each round. When countered, clear its cubes; this event stays in play."
	],
	[
		"drought",
		"干旱",
		"Drought",
		"每人按市政厅每名市民支付1第纳尔。",
		"Each player pays 1 denier per City Hall citizen."
	],
	[
		"support",
		"支援",
		"Support",
		"在左侧两张事件上各放1中立方块，不足两张则全放。",
		"Place one neutral cube on each of two events to the left, or all if fewer than two."
	],
	[
		"civilWar",
		"内战",
		"Civil War",
		"每人失去3第纳尔。",
		"Each player loses 3 deniers."
	],
	[
		"wayfarers",
		"旅人",
		"Wayfarers",
		"掷骰，将1中立市民放入市政厅对应行。",
		"Roll a die and insert one neutral citizen into the matching City Hall row."
	],
	[
		"theologicalConflict",
		"神学冲突",
		"Theological Conflict",
		"掷骰，将1中立市民放入主教府对应行。",
		"Roll a die and insert one neutral citizen into the matching Bishopric row."
	],
	[
		"heresy",
		"异端",
		"Heresy",
		"每人失去2点影响力。",
		"Each player loses 2 Influence."
	],
	[
		"travelingBuilders",
		"巡回建筑工",
		"Traveling Builders",
		"在教堂最低空层的最小点数格放1中立方块。",
		"Place one neutral cube in the lowest-valued space of the lowest available Cathedral level."
	],
	[
		"interruptedWork",
		"工程中断",
		"Interrupted Work",
		"移去教堂最高层中点数最大的一个方块。",
		"Remove the highest-valued cube from the highest occupied Cathedral level."
	],
	[
		"brigands1",
		"强盗",
		"Brigands",
		"每轮增加1颗黑骰。",
		"Add one black die each round."
	],
	[
		"brigands2",
		"强盗",
		"Brigands",
		"每轮增加1颗黑骰。",
		"Add one black die each round."
	],
	[
		"brigands3",
		"强盗",
		"Brigands",
		"每轮增加1颗黑骰。",
		"Add one black die each round."
	],
	[
		"skirmishes1",
		"小规模冲突",
		"Skirmishes",
		"每轮增加1颗黑骰。",
		"Add one black die each round."
	],
	[
		"skirmishes2",
		"小规模冲突",
		"Skirmishes",
		"每轮增加1颗黑骰。",
		"Add one black die each round."
	],
	[
		"war",
		"战争",
		"War",
		"每轮增加2颗黑骰。",
		"Add two black dice each round."
	],
	[
		"normansAttack",
		"诺曼人来袭",
		"Normans Attack",
		"每轮增加2颗黑骰。",
		"Add two black dice each round."
	],
	[
		"succession",
		"继承权冲突",
		"Conflict of Succession",
		"掷骰，将1中立市民放入伯爵宫对应格。",
		"Roll a die and place one neutral citizen on the matching Palace space."
	],
	[
		"resistance",
		"抵抗",
		"Resistance",
		"出现时额外抽一张未用红事件及其指定事件；每轮移去各事件最后放置的方块。",
		"On arrival, draw an unused red event and its called event. Each round, remove the most recent cube from every event."
	],
	[
		"wolves",
		"狼群",
		"Wolves",
		"每轮增加1颗黑骰。",
		"Add one black die each round."
	],
	[
		"harshWinter",
		"严冬",
		"Harsh Winter",
		"每人从自己的活动牌或城外活动上移去1个方块，没有则不移。",
		"Each player removes one own cube from an Activity card or outdoor activity, if any."
	],
	[
		"chiefOutlaw",
		"匪首",
		"Chief Outlaw",
		"黑骰掷出后各增加3，最高为6；不能通过活动牌或支援在此放方块。",
		"Add 3 to every rolled black die, capped at 6. Activity cards and Support cannot place cubes here."
	],
	[
		"uprising",
		"暴动",
		"Uprising",
		"掷骰选择主教府、伯爵宫或市政厅，将其中市民与1中立市民随机重新放置，多余者被逐。",
		"Roll to choose a building. Shuffle its citizens with one neutral citizen, replace six, and expel the seventh."
	],
	[
		"eventMonk",
		"僧侣干预",
		"Monk",
		"掷骰选择活动颜色，在该色最高分的空商人位放1中立市民，并列时选较低级牌。",
		"Roll for an Activity color. Place a neutral tradesman in its highest-value empty space; break ties toward lower levels."
	],
	[
		"possession",
		"占有",
		"Possession",
		"出现时每人将1市民放在此牌；每放1方块可归还其中1市民给其所有者。",
		"On arrival each player places one citizen here. Each cube placed returns one chosen captive to its owner."
	]
], ut = [
	[
		"saleInfluence",
		"交易声望",
		"Trading reputation",
		"对手购买你的骰子时，可弃1方块获得4影响，每行动限一次。",
		"When an opponent buys your dice, discard one cube for 4 Influence, once per action."
	],
	[
		"placementInfluence",
		"市民声望",
		"Civic reputation",
		"放置建筑市民时，可弃1方块获得4影响。",
		"When placing a building citizen, discard one cube for 4 Influence."
	],
	[
		"sharedActivity",
		"行会收益",
		"Guild income",
		"对手激活你有商人的活动时，可弃1方块获得4第纳尔。",
		"When an opponent activates an activity with your tradesman, discard one cube for 4 deniers."
	],
	[
		"agriculture",
		"丰收",
		"Harvest",
		"农业行动可弃1方块额外获得5第纳尔。",
		"Discard one cube during agriculture for 5 extra deniers."
	],
	[
		"exchange",
		"交换劳力",
		"Workforce exchange",
		"弃1方块，可与每个其他城区各交换1颗骰子，不改点数，不交换紫骰。",
		"Discard one cube to exchange one die with each other district, without changing values. Purple dice cannot be exchanged."
	],
	[
		"protect",
		"庇护",
		"Protection",
		"弃1方块抵消1颗最高黑骰并获得1影响，或避免一次金钱、影响、方块损失。",
		"Discard one cube to counter the highest black die and gain 1 Influence, or avoid one money, Influence or cube loss."
	],
	[
		"purchasedFlip",
		"雇工调度",
		"Hired workforce",
		"弃1方块，翻转本次刚购买并立即使用的1颗骰子。",
		"Discard one cube to turn over one die just purchased for the current action."
	],
	[
		"copyCube",
		"技艺传承",
		"Shared expertise",
		"激活延迟或混合活动时，可弃1方块，在任选延迟、混合或终局活动上放1方块，无须商人；畜牧者仍支付3钱。",
		"When activating a delayed or mixed activity, discard one cube to store a cube on any delayed, mixed or end-game card, without a tradesman. Breeder still costs 3 deniers."
	],
	[
		"dieY",
		"民事劳力",
		"Civil workforce",
		"行动前弃1方块，从供给掷1颗黄骰放入己方城区。不能用黄骰在此存方块。",
		"Before acting, discard one cube to roll a supply yellow die into your district. Yellow dice cannot store cubes here."
	],
	[
		"dieW",
		"宗教劳力",
		"Religious workforce",
		"行动前弃1方块，从供给掷1颗白骰放入己方城区。不能用白骰在此存方块。",
		"Before acting, discard one cube to roll a supply white die into your district. White dice cannot store cubes here."
	],
	[
		"dieR",
		"军事劳力",
		"Military workforce",
		"行动前弃1方块，从供给掷1颗红骰放入己方城区。不能用红骰在此存方块。",
		"Before acting, discard one cube to roll a supply red die into your district. Red dice cannot store cubes here."
	],
	[
		"dieP",
		"家族劳力",
		"Family workforce",
		"行动前弃1方块并支付2第纳尔，掷1颗紫骰放入己方城区，最多1颗。不能用紫骰在此存方块。",
		"Before acting, discard one cube and pay 2 deniers to roll a purple die into your district, at most one. Purple dice cannot store cubes here."
	],
	[
		"cubeBonus",
		"建城功勋",
		"City honors",
		"向教堂或事件放至少1方块时，可弃1方块额外获得2分。",
		"When placing at least one Cathedral or event cube, discard one cube for 2 extra VP."
	],
	[
		"arrivalCubes",
		"凯旋门",
		"Triumphal gate",
		"抵达获得3分。终局每个己方方块获得1分。",
		"Arriving earns 3 VP. Each own cube scores 1 VP at game end."
	],
	[
		"cubeMajority",
		"城墙盛典",
		"Rampart celebration",
		"终局方块数量前三名获得8、4、2分，并列者均分所占名次分数，向下取整。",
		"At game end the three highest cube counts score 8, 4 and 2 VP. Ties share the occupied ranks, rounded down."
	],
	[
		"arrivalRace",
		"荣耀归城",
		"Glorious return",
		"按抵达顺序获得6、4、2、1分，不能放方块。",
		"Arrival order scores 6, 4, 2 and 1 VP. Cubes cannot be placed here."
	]
], dt = [
	[
		"chretien",
		"克雷蒂安·德·特鲁瓦",
		"Chrétien de Troyes",
		"建筑市民达到3、5、7名时获得1、3、6分；两人局为4、6、8名。",
		"Building citizens: 3/5/7 earn 1/3/6 VP; with two players use 4/6/8."
	],
	[
		"urbain",
		"乌尔班四世",
		"Urbain IV",
		"教堂方块达到3、5、7个时获得1、3、6分；两人局为4、6、8个。",
		"Cathedral cubes: 3/5/7 earn 1/3/6 VP; with two players use 4/6/8."
	],
	[
		"thibaut",
		"蒂博二世",
		"Thibaut II",
		"金钱达到6、12、18第纳尔时获得1、3、6分。",
		"6/12/18 deniers earn 1/3/6 VP."
	],
	[
		"hugues",
		"于格·德·帕英",
		"Hugues de Payns",
		"影响力达到5、10、15点时获得1、3、6分。",
		"5/10/15 Influence earn 1/3/6 VP."
	],
	[
		"florentin",
		"佛罗伦萨人",
		"Le Florentin",
		"活动商人达到2、4、6名时获得1、3、6分。",
		"2/4/6 tradesmen earn 1/3/6 VP."
	],
	[
		"henry",
		"亨利一世",
		"Henry I",
		"收取事件达到1、3、5张时获得1、3、6分。",
		"1/3/5 collected events earn 1/3/6 VP."
	],
	[
		"jeanne",
		"香槟的让娜",
		"Jeanne de Champagne",
		"黄活动商人与市政厅市民合计达到2、4、6名时获得1、3、6分。",
		"2/4/6 combined yellow tradesmen and City Hall citizens earn 1/3/6 VP."
	],
	[
		"isabeau",
		"巴伐利亚的伊莎博",
		"Isabeau de Bavière",
		"红活动商人与伯爵宫市民合计达到2、4、6名时获得1、3、6分。",
		"2/4/6 combined red tradesmen and Palace citizens earn 1/3/6 VP."
	],
	[
		"marie",
		"香槟的玛丽",
		"Marie de Champagne",
		"白活动商人与主教府市民合计达到2、4、6名时获得1、3、6分。",
		"2/4/6 combined white tradesmen and Bishopric citizens earn 1/3/6 VP."
	]
], ft = [
	...lt,
	...ut,
	...dt
], pt = Object.fromEntries(ft.map(([e, t]) => [e, t])), mt = Object.fromEntries(ft.map(([e, , t]) => [e, t])), ht = Object.fromEntries(ft.map(([e, , , t]) => [e, t])), gt = Object.fromEntries(ft.map(([e, , , , t]) => [e, t])), _t = {
	name: "特鲁瓦",
	desc: "调度三大阶层的骰子劳力，建设教堂、经营行会，并抵御中世纪城邦的危机。",
	rules: "目标：\n以最高总分获胜。金钱、影响力和市民公开，分数与秘密人物只供本人查看。每张在局人物的终局条件对所有玩家生效。\n准备：\n基础版 2、3、4 人游戏分别进行 4、5、6 轮。每人获得 5 第纳尔和 4 点影响力；初始市民数量在 2、3、4 人游戏中分别为 6、5、4 名。交替按顺时针和逆时针顺序，将市民放入建筑的空格。2 人游戏先在每座建筑的首格和末格放置中立市民；其他人数下，由中立市民填满剩余位置。2 人游戏中每人获得 2 张人物牌，其他人数下每人获得 1 张。\n流程：\n前三轮各揭示每色一张新活动。每轮获得10第纳尔，然后为主教府每名市民支付1第纳尔、伯爵宫每名支付2第纳尔；无法付清时，支付全部现有资金，并扣除2分。每名建筑市民提供一颗对应颜色骰子。新红事件及其指定事件进入队列，全部事件从左到右生效；无法完全承担损失时尽力承担并扣2分。\n黑骰防御：\n从起始玩家开始，轮流抵御点数最高的黑骰，也可同时选择其他黑骰。使用自己城区任意数量、任意颜色骰子，总值须达到所选黑骰之和，红骰及紫骰双倍计算。每抵御1颗获得1点影响力。若己方全部骰子仍无法抵御最高黑骰，弃去该黑骰、扣2分，不损失己方骰子。不能购骰或使用活动牌的延迟方块防御。\n行动：\n轮到你时，选择1至3颗同色骰子，再点击目标物件。自己的骰子免费；外购每颗的费用按整组1、2、3颗分别为2、4、6第纳尔，向所有者支付，中立城区支付给银行。紫骰只可本人使用，使用时选择红、白、黄任一颜色。\n· 活动牌：没有己方商人时先支付雇用费，从库存、建筑、被逐区或其他活动移入一名市民，并至少激活一次。每人每牌最多一商人；印刷槽满后可放图上但不计槽位分。激活次数为骰值总和除以牌上除数，向下取整。延迟牌储存方块，以后每个行动最多弃用一个普通延迟方块；混合牌须分行动储存和使用方块，使用次数仍受本次激活次数限制。\n· 教堂：每颗白骰在对应点数的最低空层放一方块，通常最多三层。每方块获得1分；1至3列获得1点影响力，4至6列获得2点影响力。\n· 事件：用牌示颜色及除数换取旗位方块，每方块获得1点影响力。满旗时按最多、次多方块颁奖；并列第一均分两档，只有一位参与者独得两档，并列第二均分第二档，均向下取整。中立方块参与比较。最多者收取牌，并列时先放方块者收取；劫掠只清空方块而不移走。\n· 建筑：只用一颗骰子，红骰进入伯爵宫的对应格；白、黄骰进入主教府、市政厅对应行并向右推移。已有该色市民被逐时，不能再从同一建筑逐出同色市民。个人库存为空可花2点影响力招募，个人市民最多12名。\n· 农业：使用黄骰，获得骰值总和的一半第纳尔，向下取整。\n· 退出：本轮不再行动，先预留2第纳尔，此后每次轮到自己时再预留1第纳尔，并在本轮结束时领取这些资金。所有人退出或所有城区骰子用尽时结束本轮，收回被逐市民，将起始玩家标记交给左侧玩家。\n影响力：\n在防御或行动前，可支付1点影响力重掷自己一颗骰子，支付2点影响力招募一名市民，或支付4点影响力翻转自己1至3颗骰子。相对面之和为7。影响力上限20；重掷和翻转不能针对他人骰子。\n结束：\n累加已获分数、每张仍有己方方块的事件1分、活动商人槽位分和所有在局人物分；教堂每层没有己方方块扣2分。扩展活动和城外板块另按牌面结算。总分最高者获胜，并列共同获胜。\n可选内容：\n2011奖励牌默认关闭。《特鲁瓦的女士》适用于2至4人，各模块默认关闭，可以选择新人物、基础／扩展／混合活动、混合新事件、家长紫骰及城墙。\n城墙模块：\n· 城墙守卫从0格出发，到达5、10、15、20格时，分别解锁对应的城外活动。\n· 选择一颗未被延迟牌修改的骰子，获得与其点数相同的行动点。可以每支付1枚第纳尔增加1点行动点，最多增加至6点。\n· 每点行动点可以使守卫前进一格，或在一块已解锁的城外板块上放置一个方块。同一次行动中，每块板块最多放置一个方块。\n· 城外方块可以与普通延迟方块同时使用，但每种城外效果在同一次行动中最多使用一次。反应效果可以在对手回合和事件阶段使用。\n· 守卫抵达20格后停止前进，但以后仍可以使用骰子，在已解锁的板块上放置方块。\n单人：\n国王的挑战使用基础版及可选奖励牌，共进行四轮。\n· 准备：国王拥有12名市民，你拥有6名市民。先放置3名国王市民，再放置2名玩家市民，反复交替；国王按官方优先位置自动放置。\n· 国王规则：国王不使用金钱或影响力，不受负面事件影响，并与你交替担任首位玩家。\n· 防御：国王使用点数最高的一颗骰子，抵御点数最高的黑骰。\n· 行动：掷两颗黑骰，按官方行动表购买骰子获得分数、放置市民或商人、解决最右侧事件、建造教堂，或提前结算人物。骰子不足时，仍尽可能执行。\n· 购买骰子：你购买国王的骰子时向银行支付；国王购买你的骰子时，向你支付4枚或6枚第纳尔。\n· 结束：你的终局总分减去国王的终局总分，即为本次挑战的成绩。",
	cardNames: pt,
	cardTexts: ht,
	money: "第纳尔",
	influence: "影响力",
	vp: "分数",
	citizens: "市民",
	merchants: "商人",
	neutral: "中立城区",
	roy: "国王",
	bishopric: "主教府",
	palace: "伯爵宫",
	cityHall: "市政厅",
	cathedral: "教堂",
	agriculture: "农业",
	ramparts: "城墙",
	events: "事件队列",
	district: "城区",
	round: "第{n}／{total}轮",
	choose: "选择行动",
	wait: "等待{name}行动",
	setup: "将市民放入一个空格",
	defend: "选择己方骰子抵御最高黑骰",
	action: "选择骰子，再选择目标",
	citizen: "选择移入的市民",
	effect: "选择活动效果",
	amount: "选择激活次数",
	mixed: "选择储存或使用方块",
	eventTarget: "选择事件牌",
	releaseCitizen: "选择归还的市民",
	protect: "是否使用庇护",
	reaction: "是否使用城外效果",
	loseCube: "选择移去的方块",
	copyCube: "选择储存方块的活动",
	exchange: "选择交换的两颗骰子",
	phase: {
		setup: "初始布置",
		income: "收入与工资",
		reveal: "揭示活动",
		events: "事件生效",
		defend: "黑骰防御",
		action: "城市行动",
		roundEnd: "轮末整理",
		score: "终局计分",
		done: "对局结束"
	},
	op: {
		die: "选择骰子",
		black: "选择黑骰",
		clear: "清空选择",
		pass: "本轮退出",
		reroll: "重掷",
		flip: "翻转",
		recruit: "招募市民",
		color: "视为此颜色",
		modifier: "使用延迟方块",
		outdoorModifier: "使用城外方块",
		addDie: "掷出新骰子",
		exchange: "交换骰子",
		purchasedFlip: "翻转购入骰子",
		agriculture: "进行农业",
		cathedral: "建设教堂",
		building: "放置市民",
		activity: "激活活动",
		combat: "应对事件",
		ramparts: "巡逻城墙",
		source: "移入市民",
		defend: "抵御黑骰",
		loseDefense: "承受袭击",
		protect: "使用庇护",
		acceptEvent: "承担损失",
		releaseCitizen: "归还市民",
		eventTarget: "放置方块",
		stop: "结束此效果",
		store: "储存方块",
		useStored: "使用已有方块",
		convert: "进行转换",
		cathedralTarget: "建造此列",
		gainInfluence: "获得影响力",
		gainVp: "获得分数",
		miller: "选择建筑",
		takeInfluence: "拿取影响力",
		nextActivation: "下一次激活",
		guardMove: "前进一格",
		outdoorCube: "放置城外方块",
		copyCube: "储存方块",
		exchangeDice: "交换这两颗骰子",
		outdoorUse: "使用城外效果",
		loseCube: "移去方块",
		setup: "放置市民"
	},
	details: "查看详情",
	close: "关闭",
	confirm: "确认",
	totalCost: "费用：{n}第纳尔",
	activations: "激活{n}次",
	supply: "个人库存",
	hire: "雇用费",
	divisor: "激活除数",
	stored: "储存方块",
	empty: "空位",
	expelled: "被逐市民",
	hidden: "秘密人物",
	ownPoints: "已获{n}分",
	selected: "已选{n}颗 · 总值{value}",
	noneSelected: "尚未选择骰子",
	log: "对局记录",
	first: "首家",
	returned: "已退出",
	readBoard: "回看终局",
	scoreboard: "计分明细",
	finalTotal: "总分",
	points: "已获分数",
	characters: "人物",
	activities: "活动方块",
	outdoors: "城外活动",
	cathedralPenalty: "教堂缺层",
	eventPresence: "未解决事件",
	merchantPoints: "商人槽位",
	challenge: "挑战成绩：{n}",
	playAgain: "再来一局",
	back: "返回大厅",
	waitingHost: "等待主机开始下一局",
	logActions: {
		outdoorUse: "使用城外活动",
		outdoorDie: "掷出新骰子",
		outdoorCube: "放置城外方块",
		guardMove: "巡逻城墙",
		exchange: "交换骰子",
		initialCitizen: "放置初始市民",
		reveal: "揭示活动",
		income: "领取收入并支付工资",
		workforce: "掷出劳力骰子",
		event: "出现事件",
		eventEffect: "事件生效",
		blackRoll: "掷出黑骰",
		defend: "抵御黑骰",
		loseDefense: "承受袭击",
		reroll: "重掷骰子",
		flip: "翻转骰子",
		recruit: "招募市民",
		dice: "使用骰子并支付购骰费",
		agriculture: "进行农业",
		place: "放置市民",
		merchant: "雇用商人",
		activity: "激活活动",
		stored: "储存方块",
		cathedral: "建设教堂",
		eventCube: "放置事件方块",
		resolved: "解决事件",
		roundEnd: "本轮结束",
		score: "结算终局分数",
		royAction: "国王行动",
		royCharacter: "提前结算人物",
		archer: "弓箭手掷骰",
		outdoor: "使用城外活动",
		guard: "巡逻城墙"
	},
	support: "选择放置中立方块的事件",
	logLine: "{name} · {action}",
	logNumber: "{text} · {n}",
	hint: "建议：{action}",
	errTurn: "现在未轮到你。",
	errChoice: "该选择已不可用，请重新选择。",
	errFinished: "对局已经结束。",
	options: {
		bonus: "2011奖励牌",
		ladiesCharacters: "女士人物",
		publicCharacter: "公开额外人物",
		activities: "活动牌组",
		base: "基础版",
		ladies: "女士扩展",
		mixed: "混合",
		ladiesEvents: "混合女士事件",
		family: "家长紫骰",
		ramparts: "城墙与城外活动",
		tournament: "末轮逆时针",
		soloNote: "单人局使用官方国王的挑战规则，仅适用基础版及2011奖励牌。女士模块用于2至4人。"
	}
}, vt = {
	name: "Troyes",
	desc: "Command the dice of three estates, build the Cathedral, lead the guilds, and withstand the crises of a medieval city.",
	rules: "Goal:\nScore the most VP. Money, Influence and citizens are public; VP and secret characters are private. Every character in play scores all players.\nSetup:\nTwo, three and four players play four, five and six rounds. Each starts with 5 deniers, 4 Influence and six, five or four citizens respectively. Place citizens on empty building spaces in alternating clockwise and counterclockwise order. In two-player games place neutral citizens in the first and last spaces of each building first; otherwise fill remaining spaces with neutral citizens afterwards. Deal two characters each with two players, otherwise one.\nRound:\nReveal one activity of each color in each of the first three rounds. Receive 10 deniers, then pay 1 per Bishopric citizen and 2 per Palace citizen. If unable, pay what you can and lose 2 VP. Each building citizen provides a die of that color. Add a red event and its called event, then resolve all events left to right. If unable to meet an event loss in full, resolve as much as possible and lose 2 VP.\nBlack dice:\nStarting with the start player, counter the highest black die, optionally with additional black dice. Use any number of your own dice, with mixed colors allowed; their total must cover the selected black dice. Red and purple dice count double. Gain 1 Influence per black die countered. If all your dice cannot cover the highest black die, discard that black die, lose 2 VP and retain your dice. You cannot buy dice or use delayed Activity cubes for defense.\nActions:\nSelect one to three dice of one color, then choose a target object. Own dice are free. A foreign die costs 2, 4 or 6 deniers when the entire group contains one, two or three dice respectively. Pay its owner, or the bank for neutral dice. Purple dice are private and take a chosen color when used.\n· Activity: hire a tradesman if needed by paying the card cost and moving a citizen from supply, a building, expelled area or another activity. You must activate at least once. Only one tradesman per player per card; overflow spaces score no VP. Activations equal the group total divided by the card divisor, rounded down. Delayed cards store cubes; at most one ordinary delayed cube modifies an action. Mixed cards require separate actions to store and spend cubes, and spending still requires sufficient activations.\n· Cathedral: each white die places one cube in the lowest available level of its numbered column, normally up to three levels. Each cube earns 1 VP and 1 Influence in columns 1–3 or 2 Influence in columns 4–6.\n· Events: use the printed color and divisor to place banner cubes, gaining 1 Influence each. When full, most and second-most cubes earn the printed prizes. First-place ties share both prizes; a sole contributor takes both; second-place ties share second prize, rounded down. Neutral cubes count. The majority collects the card, ties going to the earliest cube. Marauding only clears its cubes and remains in play.\n· Buildings: use exactly one die. Red places a citizen on the matching Palace space; white and yellow insert into the matching Bishopric or City Hall row and push right. A color already expelled from a building cannot be expelled there again that round. With an empty personal supply, recruit for 2 Influence, to a maximum of 12 citizens.\n· Agriculture: yellow dice earn half their total value in deniers, rounded down.\n· Pass: take no more actions that round. Set aside 2 deniers, adding 1 each time your turn returns. Collect at round end. The round ends when everyone passes or all districts run out of dice. Return expelled citizens and pass the start-player card left.\nInfluence:\nBefore defending or acting, spend 1 Influence to reroll one own die, 2 to recruit a citizen, or 4 to turn over one to three own dice. Opposite faces total 7. Influence is capped at 20. Other players’ dice cannot be rerolled or turned over this way.\nScoring:\nAdd earned VP, 1 VP per unresolved event bearing your cubes, tradesman-space VP and all characters in play. Lose 2 VP per Cathedral level with no own cube. Score expansion cards and outdoor activities as printed. Highest total wins; ties are shared.\nOptional content:\nThe 2011 bonus cards are off by default. The Ladies of Troyes supports two to four players. Its optional modules are new characters, base/expansion/mixed activities, mixed new events, purple family dice and ramparts.\nRamparts:\n· The guard starts at space 0. Reaching spaces 5, 10, 15 and 20 unlocks the corresponding outdoor activities.\n· Choose a die not modified by delayed cards and gain action points equal to its value. Pay 1 denier for each extra point, up to a total of 6 points.\n· Spend each point to move one space or place one cube on an unlocked tile. Place at most one cube per tile during an action.\n· Outdoor cubes may be combined with an ordinary delayed cube. Use each outdoor effect at most once per action. Reactions may be used during opponents’ turns and events.\n· The guard stops at space 20. Later dice may still place cubes on unlocked outdoor tiles.\nSolo:\nThe King’s Challenge uses the base game and optional bonus cards over four rounds.\n· Setup: Le Roy starts with twelve citizens and you start with six. Repeatedly place three royal citizens, then two of yours. Le Roy uses the official placement priorities.\n· Royal rules: Le Roy has no money or Influence, ignores negative events and alternates with you as the start player.\n· Defense: Le Roy uses his highest die to counter the highest black die.\n· Actions: Roll two black dice and use the official table to buy dice for VP, place citizens or tradesmen, counter the rightmost event, build the Cathedral or score a character early. Execute the action as far as possible if there are insufficient dice.\n· Buying dice: Pay the bank when buying royal dice. Le Roy pays you 4 or 6 deniers when buying your dice.\n· End: Your challenge score is your final total minus Le Roy’s final total.",
	cardNames: mt,
	cardTexts: gt,
	money: "Deniers",
	influence: "Influence",
	vp: "VP",
	citizens: "Citizens",
	merchants: "Tradesmen",
	neutral: "Neutral district",
	roy: "Le Roy",
	bishopric: "Bishopric",
	palace: "Palace",
	cityHall: "City Hall",
	cathedral: "Cathedral",
	agriculture: "Agriculture",
	ramparts: "Ramparts",
	events: "Event queue",
	district: "District",
	round: "Round {n}/{total}",
	choose: "Choose an action",
	wait: "Waiting for {name}",
	setup: "Place a citizen on an empty space",
	defend: "Select own dice to counter the highest black die",
	action: "Select dice, then a target",
	citizen: "Choose a citizen to move",
	effect: "Choose an activity effect",
	amount: "Choose activations",
	mixed: "Store or spend cubes",
	eventTarget: "Choose an event",
	releaseCitizen: "Choose a captive to return",
	protect: "Use protection?",
	reaction: "Use the outdoor effect?",
	loseCube: "Choose a cube to remove",
	copyCube: "Choose an activity to store a cube",
	exchange: "Choose the dice to exchange",
	phase: {
		setup: "Initial placement",
		income: "Income and salaries",
		reveal: "Reveal activities",
		events: "Resolve events",
		defend: "Black dice",
		action: "City actions",
		roundEnd: "Round end",
		score: "Final scoring",
		done: "Game over"
	},
	op: {
		die: "Select die",
		black: "Select black die",
		clear: "Clear selection",
		pass: "Pass this round",
		reroll: "Reroll",
		flip: "Turn over",
		recruit: "Recruit a citizen",
		color: "Use this color",
		modifier: "Use delayed cube",
		outdoorModifier: "Use outdoor cube",
		addDie: "Roll a new die",
		exchange: "Exchange dice",
		purchasedFlip: "Turn over purchased die",
		agriculture: "Use agriculture",
		cathedral: "Construct Cathedral",
		building: "Place citizen",
		activity: "Activate activity",
		combat: "Combat event",
		ramparts: "Patrol ramparts",
		source: "Move citizen",
		defend: "Counter black dice",
		loseDefense: "Suffer attack",
		protect: "Use protection",
		acceptEvent: "Accept loss",
		releaseCitizen: "Return citizen",
		eventTarget: "Place cube",
		stop: "End this effect",
		store: "Store cubes",
		useStored: "Spend stored cubes",
		convert: "Convert",
		cathedralTarget: "Build this column",
		gainInfluence: "Gain Influence",
		gainVp: "Gain VP",
		miller: "Choose building",
		takeInfluence: "Take Influence",
		nextActivation: "Next activation",
		guardMove: "Move one space",
		outdoorCube: "Store outdoor cube",
		copyCube: "Store cube",
		exchangeDice: "Exchange these dice",
		outdoorUse: "Use outdoor effect",
		loseCube: "Remove cube",
		setup: "Place citizen"
	},
	details: "Details",
	close: "Close",
	confirm: "Confirm",
	totalCost: "Cost: {n} deniers",
	activations: "{n} activations",
	supply: "Personal supply",
	hire: "Hiring cost",
	divisor: "Activation divisor",
	stored: "Stored cubes",
	empty: "Empty space",
	expelled: "Expelled citizens",
	hidden: "Secret characters",
	ownPoints: "{n} VP earned",
	selected: "{n} dice · total {value}",
	noneSelected: "No dice selected",
	log: "Game log",
	first: "Start player",
	returned: "Passed",
	readBoard: "View final city",
	scoreboard: "Score breakdown",
	finalTotal: "Total",
	points: "Earned VP",
	characters: "Characters",
	activities: "Activity cubes",
	outdoors: "Outdoor activities",
	cathedralPenalty: "Missing Cathedral levels",
	eventPresence: "Unresolved events",
	merchantPoints: "Tradesman spaces",
	challenge: "Challenge score: {n}",
	playAgain: "Play again",
	back: "Back to lobby",
	waitingHost: "Waiting for the host",
	logActions: {
		outdoorUse: "Use outdoor activity",
		outdoorDie: "Roll a new die",
		outdoorCube: "Place outdoor cube",
		guardMove: "Patrol ramparts",
		exchange: "Exchange dice",
		initialCitizen: "Place initial citizen",
		reveal: "Reveal activity",
		income: "Receive income and pay salaries",
		workforce: "Roll workforce dice",
		event: "Draw event",
		eventEffect: "Resolve event effect",
		blackRoll: "Roll black dice",
		defend: "Counter black dice",
		loseDefense: "Suffer attack",
		reroll: "Reroll die",
		flip: "Turn over dice",
		recruit: "Recruit citizen",
		dice: "Spend dice and pay purchases",
		agriculture: "Use agriculture",
		place: "Place citizen",
		merchant: "Hire tradesman",
		activity: "Activate activity",
		stored: "Store cube",
		cathedral: "Build Cathedral",
		eventCube: "Place event cube",
		resolved: "Resolve event",
		roundEnd: "End round",
		score: "Score final points",
		royAction: "Le Roy acts",
		royCharacter: "Score character early",
		archer: "Roll for Archer",
		outdoor: "Use outdoor activity",
		guard: "Patrol ramparts"
	},
	support: "Choose events for neutral cubes",
	logLine: "{name} · {action}",
	logNumber: "{text} · {n}",
	hint: "Suggested: {action}",
	errTurn: "It is not your turn.",
	errChoice: "That choice is no longer available.",
	errFinished: "The game has ended.",
	options: {
		bonus: "2011 bonus cards",
		ladiesCharacters: "Ladies characters",
		publicCharacter: "Extra public character",
		activities: "Activity deck",
		base: "Base game",
		ladies: "Ladies expansion",
		mixed: "Mixed",
		ladiesEvents: "Mix in Ladies events",
		family: "Head of the family",
		ramparts: "Ramparts and outdoor activities",
		tournament: "Counterclockwise final round",
		soloNote: "Solo uses the official King’s Challenge with the base game and optional 2011 bonus cards. Ladies modules support two to four players."
	}
};
//#endregion
//#region src/games/troyes/view-player.tsx
function $({ name: e, className: t = "", children: n, style: r }) {
	let { ref: i, hidden: a } = s(e);
	return /* @__PURE__ */ m("div", {
		ref: i,
		className: t,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: n
	});
}
function yt({ name: e, children: t }) {
	let { ref: n, hidden: r } = s(e);
	return /* @__PURE__ */ m("span", {
		ref: n,
		style: {
			display: "inline-flex",
			visibility: r ? "hidden" : void 0
		},
		children: t
	});
}
var bt = (e, t) => e.replace(/\{(\w+)\}/g, (e, n) => String(t[n] ?? ""));
function xt(e) {
	let t = e.public, n = e.private ?? {
		vp: 0,
		characters: [],
		choices: []
	}, r = c((e) => e.locale), i = r === "en" ? vt : _t, [s, l] = a(null), [g, _] = a(null), [ne, v] = a(!1), [re, ie] = a(!1), y = t.phase === "done", b = y ? [] : n.choices, x = t.pending?.rid === e.myRid && !y, S = (t) => t === "$neutral" ? i.neutral : t === "$roy" ? i.roy : (() => {
		let n = e.members.find((e) => e.rid === t);
		return n ? te(n, r) : t;
	})(), w = (t) => t === "$neutral" ? "#82796d" : t === "$roy" ? "#292a29" : u[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % u.length].hex, E = (e) => i.cardNames[e] ?? e, ae = (e) => e === "w" ? i.bishopric : e === "r" ? i.palace : i.cityHall, O = (e) => {
		let n = i.op[e.kind] ?? i.choose, r = e.ref ? t.dice.find((t) => t.id === e.ref) : void 0;
		return [
			n,
			r ? `${ae(r.color === "p" ? t.draft.color : r.color)} ${r.value}` : e.card ? E(e.card) : e.color ? ae(e.color) : e.kind === "source" ? e.ref === "supply" ? i.supply : e.ref === "recruit" ? i.op.recruit : i.citizens : e.target && t.players.some((t) => t.rid === e.target) ? S(e.target) : "",
			e.n === void 0 ? "" : String(e.n),
			e.value === void 0 ? "" : `(${e.value})`
		].filter(Boolean).join(" · ");
	}, A = (t, n = i.choose) => {
		t.length === 1 ? (e.send({
			type: "choose",
			id: t[0].id
		}), _(null)) : t.length && _({
			title: n,
			options: t
		});
	}, j = (e, t, n = "") => /* @__PURE__ */ h("button", {
		type: "button",
		className: `troyes-object ${n}`,
		disabled: !e.length,
		onClick: () => A(e),
		children: [t, e.length > 0 && /* @__PURE__ */ m(ct, {})]
	}), M = (e, t = !0, n) => /* @__PURE__ */ m("span", {
		className: "troyes-tokens",
		children: e.map((e, r) => {
			let i = /* @__PURE__ */ m("span", {
				title: S(e),
				"aria-label": S(e),
				className: t ? "troyes-cube" : "troyes-citizen",
				style: { "--owner": w(e) },
				children: t ? null : /* @__PURE__ */ m(Q, { color: w(e) })
			});
			return n ? /* @__PURE__ */ m(yt, {
				name: `${n}:${r}`,
				children: i
			}, r) : /* @__PURE__ */ m("span", { children: i }, r);
		})
	}), N = (e) => b.filter((t) => t.kind === "source" && t.ref === e), P = (e) => b.filter((t) => t.card === e && [
		"activity",
		"modifier",
		"store",
		"useStored",
		"copyCube",
		"loseCube"
	].includes(t.kind)), F = k(t, e.myRid), I = t.draft.dice.length ? bt(i.selected, {
		n: t.draft.dice.length,
		value: F?.total ?? t.dice.filter((e) => t.draft.dice.includes(e.id)).reduce((e, t) => e + t.value, 0)
	}) : i.noneSelected, L = [
		"clear",
		"pass",
		"reroll",
		"flip",
		"recruit",
		"color",
		"defend",
		"loseDefense",
		"protect",
		"acceptEvent",
		"stop",
		"convert",
		"gainInfluence",
		"gainVp",
		"takeInfluence",
		"nextActivation",
		"outdoorUse"
	], R = b.filter((e) => L.includes(e.kind)), z = y ? i.phase.done : x ? i[t.pending.kind] || i.choose : t.pending ? bt(i.wait, { name: S(t.pending.rid) }) : i.phase[t.phase], B = /* @__PURE__ */ h("div", {
		className: "troyes-actionbar",
		children: [/* @__PURE__ */ h("span", {
			className: "troyes-selection",
			children: [y ? i.readBoard : I, F && /* @__PURE__ */ m("small", { children: bt(i.totalCost, { n: F.cost }) })]
		}), /* @__PURE__ */ h("div", {
			className: "troyes-shortcuts",
			children: [
				b.filter((e) => [
					"agriculture",
					"defend",
					"loseDefense",
					"clear"
				].includes(e.kind)).map((e) => /* @__PURE__ */ h("button", {
					onClick: () => A([e]),
					children: [i.op[e.kind], e.kind === "agriculture" ? ` +${e.n}` : ""]
				}, e.id)),
				x && /* @__PURE__ */ m("button", {
					onClick: () => v(!0),
					children: i.choose
				}),
				/* @__PURE__ */ h("button", {
					onClick: () => {
						l(n.characters[0] ?? t.publicCharacters[0] ?? null);
					},
					disabled: !n.characters.length && !t.publicCharacters.length,
					children: [i.characters, y ? "" : ` · ${n.vp}★`]
				}),
				/* @__PURE__ */ m("button", {
					onClick: () => ie(!0),
					children: i.log
				})
			]
		})]
	}), V = s ? b.filter((e) => e.card === s) : [];
	return /* @__PURE__ */ h("div", {
		className: "troyes-root",
		children: [
			/* @__PURE__ */ m(d, {
				kind: "sheen",
				base: "#c3b08a",
				className: "absolute inset-0"
			}),
			/* @__PURE__ */ m(ee, {
				adaptive: !0,
				className: "troyes-screen",
				actionsHeight: "troyes-action-height",
				actions: B,
				banner: /* @__PURE__ */ h("div", {
					className: "troyes-top",
					children: [/* @__PURE__ */ m(f, {
						tone: x ? "accent" : "info",
						accent: Ie.accent,
						text: z,
						chip: bt(i.round, {
							n: t.round,
							total: t.rounds
						})
					}), /* @__PURE__ */ m("div", {
						className: "troyes-players",
						children: t.players.map((n) => /* @__PURE__ */ h($, {
							name: `seat:${n.rid}`,
							className: `troyes-player ${t.active === n.rid && !y ? "active" : ""}`,
							style: { "--owner": w(n.rid) },
							children: [
								/* @__PURE__ */ h("b", { children: [S(n.rid), n.rid === t.first && !y ? " ♛" : ""] }),
								/* @__PURE__ */ h("span", {
									title: i.money,
									children: ["◉ ", n.money]
								}),
								/* @__PURE__ */ h("span", {
									title: i.influence,
									children: ["⚜ ", n.influence]
								}),
								/* @__PURE__ */ h("button", {
									title: i.supply,
									disabled: n.rid !== e.myRid || !N("supply").length,
									onClick: () => A(N("supply")),
									children: [
										/* @__PURE__ */ m(Q, { color: w(n.rid) }),
										" ",
										n.supply
									]
								}),
								n.passed && !y && /* @__PURE__ */ m("small", { children: i.returned })
							]
						}, n.rid))
					})]
				}),
				children: /* @__PURE__ */ h("div", {
					className: "troyes-board",
					children: [
						/* @__PURE__ */ h("section", {
							className: "troyes-city",
							children: [
								/* @__PURE__ */ m("div", {
									className: "troyes-buildings",
									children: C.map((e) => /* @__PURE__ */ h($, {
										name: `building:${e}`,
										className: `troyes-building estate-${e}`,
										children: [
											/* @__PURE__ */ m(st, { color: e }),
											/* @__PURE__ */ m("h2", { children: ae(e) }),
											/* @__PURE__ */ m("div", {
												className: `troyes-cells cells-${e}`,
												children: t.buildings[e].map((t, n) => {
													let r = [
														...b.filter((t) => t.kind === "setup" && t.color === e && t.n === n),
														...N(`b:${e}:${n}`),
														...b.filter((t) => t.kind === "building" && t.color === e && (e === "r" ? t.n === n + 1 : e === "w" ? Math.floor(n / 3) === (t.n <= 3 ? 0 : 1) : Math.floor(n / 2) === (t.n - 1) % 3))
													];
													return /* @__PURE__ */ m($, {
														name: `cell:${e}:${n}`,
														className: "troyes-cell",
														children: j(r, /* @__PURE__ */ h(p, { children: [t ? /* @__PURE__ */ m(Q, { color: w(t) }) : /* @__PURE__ */ m("span", { children: e === "r" ? n + 1 : e === "w" ? n < 3 ? "1–3" : "4–6" : [
															"1/4",
															"2/5",
															"3/6"
														][Math.floor(n / 2)] }), /* @__PURE__ */ m("span", {
															className: "sr-only",
															children: t ? S(t) : i.empty
														})] }))
													}, n);
												})
											}),
											/* @__PURE__ */ m($, {
												name: `expelled:${e}`,
												className: "troyes-expelled",
												children: t.expelled[e].map((t, n) => /* @__PURE__ */ m("span", { children: j(N(`e:${e}:${n}`), /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Q, { color: w(t) }), /* @__PURE__ */ h("span", {
													className: "sr-only",
													children: [
														i.expelled,
														" ",
														S(t)
													]
												})] })) }, n))
											})
										]
									}, e))
								}),
								/* @__PURE__ */ h($, {
									name: "cathedral",
									className: "troyes-cathedral",
									children: [
										/* @__PURE__ */ m(st, { color: "cathedral" }),
										/* @__PURE__ */ m("h2", { children: i.cathedral }),
										/* @__PURE__ */ m("div", {
											className: "troyes-cathedral-columns",
											children: t.cathedral.map((e, n) => /* @__PURE__ */ m($, {
												name: `cathedral:${n + 1}`,
												className: "troyes-cathedral-column",
												children: j(b.filter((e) => e.kind === "cathedralTarget" ? e.value === n + 1 : e.kind === "cathedral" && F?.effective.some((e) => e.value === n + 1)), /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("b", { children: n + 1 }), Array.from({ length: Math.max(3, ...t.cathedral.map((e) => e.length)) }, (t, r) => /* @__PURE__ */ m("span", {
													className: "troyes-stone",
													children: e[r] ? M([e[r]], !0, `cube:cathedral:${n}:${r}`) : /* @__PURE__ */ m("i", {})
												}, r))] }))
											}, n))
										})
									]
								}),
								/* @__PURE__ */ m("div", {
									className: "troyes-districts",
									children: [...t.players.map((e) => e.rid), ...t.dice.some((e) => e.owner === "$neutral") ? ["$neutral"] : []].map((e) => /* @__PURE__ */ h($, {
										name: `district:${e}`,
										className: "troyes-district",
										style: { "--owner": w(e) },
										children: [/* @__PURE__ */ m("h3", { children: S(e) }), /* @__PURE__ */ m("div", {
											className: "troyes-dice",
											children: t.dice.filter((t) => t.owner === e).map((n) => /* @__PURE__ */ m($, {
												name: `die:${n.id}`,
												className: `troyes-die ${t.draft.dice.includes(n.id) ? "selected" : ""}`,
												children: j(b.filter((e) => e.kind === "die" && e.ref === n.id), /* @__PURE__ */ h(p, { children: [
													/* @__PURE__ */ m(ot, {
														color: n.color,
														value: n.value
													}),
													/* @__PURE__ */ h("span", {
														className: "sr-only",
														children: [
															S(e),
															" ",
															ae(n.color === "p" ? t.draft.color : n.color),
															" ",
															n.value
														]
													}),
													t.draft.dice.includes(n.id) && /* @__PURE__ */ m("b", {
														className: "troyes-selected-mark",
														children: "✓"
													})
												] }))
											}, n.id))
										})]
									}, e))
								}),
								/* @__PURE__ */ m($, {
									name: "black",
									className: "troyes-black",
									children: t.black.map((e, n) => /* @__PURE__ */ m($, {
										name: `black:${n}`,
										className: `troyes-die ${t.draft.black.includes(n) && t.phase === "defend" ? "selected" : ""}`,
										children: j(b.filter((e) => e.kind === "black" && e.n === n), /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(ot, {
											color: "black",
											value: e
										}), /* @__PURE__ */ h("span", {
											className: "sr-only",
											children: [
												i.op.black,
												" ",
												e
											]
										})] }))
									}, n))
								})
							]
						}),
						/* @__PURE__ */ m("section", {
							className: "troyes-guilds",
							children: C.map((e) => /* @__PURE__ */ m("div", {
								className: `troyes-guild estate-${e}`,
								children: t.activities.map((e, t) => ({
									a: e,
									index: t
								})).filter(({ a: t }) => t.revealed ? T(t.id).color === e : t.id.split(":")[1] === e).map(({ a: e, index: t }) => {
									let n = e.revealed ? T(e.id) : null;
									return /* @__PURE__ */ h($, {
										name: `card:${e.id}`,
										className: `troyes-activity ${n ? "" : "card-back"}`,
										children: [/* @__PURE__ */ h("button", {
											className: "troyes-card-main",
											disabled: !P(e.id).length,
											onClick: () => A(P(e.id), E(e.id)),
											children: [n ? /* @__PURE__ */ h(p, { children: [
												/* @__PURE__ */ m("h3", { children: E(e.id) }),
												/* @__PURE__ */ m("img", {
													src: `games/troyes/art/${e.id}.svg`,
													alt: "",
													draggable: !1
												}),
												/* @__PURE__ */ h("div", {
													className: "troyes-card-cost",
													children: [
														/* @__PURE__ */ h("span", {
															title: i.hire,
															children: [
																n.influence ? "⚜" : "◉",
																" ",
																n.cost
															]
														}),
														/* @__PURE__ */ h("b", {
															title: i.divisor,
															children: ["÷ ", n.divisor || "—"]
														}),
														/* @__PURE__ */ m("span", { children: n.timing === "delayed" ? "⌛" : n.timing === "end" ? "★" : n.timing === "mixed" ? "⇄" : "↯" })
													]
												})
											] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", {
												className: "troyes-back-seal",
												children: "⚜"
											}), /* @__PURE__ */ m("b", { children: [
												"I",
												"II",
												"III"
											][e.id.split(":")[2] - 1] })] }), P(e.id).length > 0 && /* @__PURE__ */ m(ct, {})]
										}), n && /* @__PURE__ */ h(p, { children: [
											/* @__PURE__ */ m("button", {
												className: "troyes-info",
												"aria-label": `${i.details} ${E(e.id)}`,
												onClick: () => l(e.id),
												children: "ⓘ"
											}),
											/* @__PURE__ */ h("div", {
												className: "troyes-merchants",
												children: [e.merchants.map((r, i) => /* @__PURE__ */ m(yt, {
													name: `merchant:${e.id}:${i}`,
													children: /* @__PURE__ */ h("button", {
														title: S(r.owner),
														disabled: !N(`a:${t}:${i}`).length,
														onClick: () => A(N(`a:${t}:${i}`)),
														children: [/* @__PURE__ */ m(Q, { color: w(r.owner) }), /* @__PURE__ */ h("small", { children: [n.slots[r.slot] ?? 0, "★"] })]
													})
												}, i)), !e.merchants.length && /* @__PURE__ */ h("span", { children: [n.slots.join(" / "), " ★"] })]
											}),
											M(e.cubes, !0, `cube:activity:${e.id}`)
										] })]
									}, t);
								})
							}, e))
						}),
						t.config.ramparts && /* @__PURE__ */ h($, {
							name: "ramparts",
							className: "troyes-ramparts",
							children: [
								/* @__PURE__ */ m("h2", { children: i.ramparts }),
								/* @__PURE__ */ m("div", {
									className: "troyes-wall",
									children: Array.from({ length: 21 }, (e, n) => /* @__PURE__ */ h($, {
										name: `guard:${n}`,
										className: oe.includes(n) ? "gate" : "",
										children: [n, M(t.players.filter((e) => e.guard === n).map((e) => e.rid), !1, `guard-piece:${n}`)]
									}, n))
								}),
								/* @__PURE__ */ m("div", {
									className: "troyes-outdoors",
									children: t.outdoors.map((e, t) => /* @__PURE__ */ h($, {
										name: `card:${e.id}`,
										className: "troyes-outdoor",
										children: [j(b.filter((t) => t.card === e.id && !["reaction", "outdoorUse"].includes(t.kind)), /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("b", { children: [
											oe[t],
											" · ",
											E(e.id)
										] }), M(e.cubes, !0, `cube:outdoor:${e.id}`)] })), /* @__PURE__ */ m("button", {
											className: "troyes-info",
											"aria-label": `${i.details} ${E(e.id)}`,
											onClick: () => l(e.id),
											children: "ⓘ"
										})]
									}, e.id))
								}),
								b.some((e) => ["guardMove", "ramparts"].includes(e.kind)) && /* @__PURE__ */ m("div", {
									className: "troyes-local-options",
									children: b.filter((e) => ["guardMove", "ramparts"].includes(e.kind)).map((e) => /* @__PURE__ */ m("button", {
										onClick: () => A([e]),
										children: O(e)
									}, e.id))
								})
							]
						}),
						/* @__PURE__ */ h("section", {
							className: "troyes-event-area",
							children: [/* @__PURE__ */ m("h2", { children: i.events }), /* @__PURE__ */ m($, {
								name: "event-area",
								className: "troyes-events",
								children: t.events.map((e) => {
									let t = D(e.id), n = b.filter((t) => ["combat", "eventTarget"].includes(t.kind) && t.target === e.uid);
									return /* @__PURE__ */ h($, {
										name: `event:${e.uid}`,
										className: `troyes-event estate-${t.color}`,
										children: [
											j(n, /* @__PURE__ */ h(p, { children: [
												/* @__PURE__ */ m("h3", { children: E(e.id) }),
												/* @__PURE__ */ h("span", {
													className: "troyes-event-effects",
													children: [
														t.black ? /* @__PURE__ */ h("span", { children: ["⬛ +", t.black] }) : null,
														/* @__PURE__ */ h("b", { children: ["÷ ", t.divisor] }),
														/* @__PURE__ */ h("span", { children: ["★ ", t.prizes.join(" / ")] })
													]
												}),
												/* @__PURE__ */ m("div", {
													className: "troyes-flags",
													children: Array.from({ length: t.flags }, (t, n) => /* @__PURE__ */ m("span", { children: e.cubes[n] ? M([e.cubes[n]], !0, `cube:event:${e.uid}:${n}`) : /* @__PURE__ */ m("i", {}) }, n))
												})
											] })),
											/* @__PURE__ */ m("button", {
												className: "troyes-info",
												"aria-label": `${i.details} ${E(e.id)}`,
												onClick: () => l(e.id),
												children: "ⓘ"
											}),
											e.captives.length > 0 && /* @__PURE__ */ m("div", {
												className: "troyes-captives",
												children: e.captives.map((e, t) => /* @__PURE__ */ m("button", {
													title: S(e),
													disabled: !b.some((e) => e.kind === "releaseCitizen" && e.n === t),
													onClick: () => A(b.filter((e) => e.kind === "releaseCitizen" && e.n === t)),
													children: /* @__PURE__ */ m(Q, { color: w(e) })
												}, t))
											})
										]
									}, e.uid);
								})
							})]
						}),
						(n.characters.length > 0 || t.publicCharacters.length > 0) && /* @__PURE__ */ m("div", {
							className: "troyes-characters",
							children: [...n.characters, ...t.publicCharacters].map((e) => /* @__PURE__ */ h("button", {
								onClick: () => l(e),
								children: ["⚜ ", E(e)]
							}, e))
						})
					]
				})
			}),
			/* @__PURE__ */ m(o, {
				open: s !== null,
				label: i.details,
				title: s ? E(s) : i.details,
				onClose: () => l(null),
				children: /* @__PURE__ */ h("div", {
					className: "troyes-detail",
					children: [
						s && t.activities.some((e) => e.id === s && e.revealed) && /* @__PURE__ */ m("img", {
							src: `games/troyes/art/${s}.svg`,
							alt: ""
						}),
						/* @__PURE__ */ m("p", { children: s ? i.cardTexts[s] : "" }),
						V.map((e) => /* @__PURE__ */ m("button", {
							className: "btn-base",
							onClick: () => {
								A([e]), l(null);
							},
							children: O(e)
						}, e.id)),
						[...n.characters, ...t.publicCharacters].filter((e) => e !== s).map((e) => /* @__PURE__ */ m("button", {
							className: "btn-quiet",
							onClick: () => l(e),
							children: E(e)
						}, e))
					]
				})
			}),
			/* @__PURE__ */ m(o, {
				open: g !== null,
				label: i.choose,
				title: g?.title,
				onClose: () => _(null),
				children: /* @__PURE__ */ m("div", {
					className: "troyes-option-list",
					children: g?.options.filter((e) => b.some((t) => t.id === e.id)).map((e) => /* @__PURE__ */ m("button", {
						className: "btn-base",
						onClick: () => A([e]),
						children: O(e)
					}, e.id))
				})
			}),
			/* @__PURE__ */ m(o, {
				open: ne,
				label: i.choose,
				title: i.choose,
				onClose: () => v(!1),
				children: /* @__PURE__ */ h("div", {
					className: "troyes-option-list",
					children: [R.map((e) => /* @__PURE__ */ m("button", {
						className: "btn-base",
						onClick: () => {
							A([e]), v(!1);
						},
						children: O(e)
					}, e.id)), b.filter((e) => e.kind === "source" && ["supply", "recruit"].includes(e.ref) || [
						"exchangeDice",
						"miller",
						"takeInfluence"
					].includes(e.kind)).map((e) => /* @__PURE__ */ m("button", {
						className: "btn-base",
						onClick: () => {
							A([e]), v(!1);
						},
						children: O(e)
					}, e.id))]
				})
			}),
			/* @__PURE__ */ m(o, {
				open: re,
				label: i.log,
				title: i.log,
				onClose: () => ie(!1),
				children: /* @__PURE__ */ m("ol", {
					className: "troyes-history",
					children: t.log.map((e, t) => /* @__PURE__ */ h("li", { children: [
						e.rid ? S(e.rid) : "",
						" · ",
						i.logActions[e.kind] ?? i.op[e.kind] ?? i.choose,
						e.card ? ` · ${E(e.card)}` : "",
						e.n === void 0 ? "" : ` · ${e.n}`,
						e.value === void 0 ? "" : ` (${e.value})`
					] }, t))
				})
			})
		]
	});
}
var St = {
	future: .7,
	money: .35,
	influence: .3,
	hire: .5,
	cathedral: .8,
	event: .65
};
function Ct(e, t, n) {
	return {
		...e,
		players: e.players.map((e) => ({
			...e,
			vp: e.rid === n ? t.vp : 0
		})),
		agenda: [],
		decision: null,
		seed: 0,
		cursor: 0,
		serial: 0,
		diceSerial: 0,
		beat: 0,
		setupOrder: [],
		decks: {
			r: [],
			w: [],
			y: []
		},
		unusedRed: [],
		charactersDeck: [],
		eventCursor: 0,
		blackCount: 0,
		turnDirection: 1,
		rampartUsed: [],
		rampartColor: "",
		actionActor: n,
		actionCard: null,
		actionDice: [],
		currentEffect: null,
		actionPlacedCube: !1
	};
}
function wt(e, t, n, r, i) {
	let a = e.players.find((e) => e.rid === t), o = e.dice.filter((e) => e.owner === t), s = e.activities.reduce((e, n) => e + n.merchants.filter((e) => e.owner === t).length, 0), c = e.cathedral.flat().filter((e) => e === t).length, l = e.rounds - e.round, u = {
		artisan: Math.min(r, a.influence) * (6 * i.money - i.influence),
		merchant: r * 2 * i.money,
		miller: r * Math.max(...["r", "w"].map((n) => e.buildings[n].filter((e) => e === t).length)) * 2 * i.money,
		innkeeper: Math.min(r, a.money) * Math.max(0, i.influence - i.money),
		journeyman: Math.min(r, Math.floor(a.money / 3)) * (2 - 3 * i.money),
		goldsmith: r * (1 + 2 * i.money),
		sculptor: r,
		pilgrimage: r * 2,
		glassblower: r * Math.floor(c / 2),
		procession: o.length ? r : 0,
		archer: r * .66 * (i.influence + i.event),
		chivalry: r * o.filter((e) => e.color === "r").length * (i.influence + i.event),
		diplomat: Math.min(r, a.influence) * i.event,
		hunting: Math.min(r * 3, 20 - a.influence) * i.influence,
		mercenary: r * 3 * i.money,
		taxCollector: r * e.buildings.y.filter((e) => e !== t).length * i.money,
		captain: r * e.events.filter((e) => e.cubes.includes(t)).length,
		joust: r * (o.filter((e) => e.color === "r").length ? 1.5 : 0),
		troubadour: Math.min(r, Math.floor(a.influence / 3)) * (2 - 3 * i.influence),
		baker: r * e.dice.filter((e) => e.color === "y").length * i.money,
		banquet: r * Math.max(0, ...e.players.map((t) => e.dice.filter((e) => e.owner === t.rid && e.color === "r").length)),
		clogMaker: r * e.buildings.y.filter((e) => e === t).length * i.money,
		weaver: r * (s + 1) * i.money,
		landlady: r * Math.max(1, Math.min(4, 20 - a.influence) * i.influence),
		banker: a.money > 30 ? r * 3 : 0,
		masterTradesman: r * Math.floor((s + 1) / 2),
		bishop: r * c * i.money,
		masterBuilder: r * (1 + 1.5 * i.influence + i.cathedral),
		scribe: r * a.captured.length,
		nun: r * o.filter((e) => e.color === "w").length,
		ransom: Math.min(r, Math.floor(a.money / 3)) * Math.max(0, 1 + i.influence - 3 * i.money),
		catapult: r * 1.4,
		scout: Math.min(a.money, e.events.length * r) * Math.max(0, i.influence + i.event - i.money),
		executioner: r * 2 * i.influence,
		marriage: Math.min(r, Math.floor(a.money / 7)) * Math.max(0, 4 - 7 * i.money),
		fort: r * (1.5 + 1.5 * i.influence),
		princess: r * .8,
		hermit: r * Math.max(0, 9 - e.activities.find((e) => e.id === n).cubes.length - r)
	}, d = e.activities.find((e) => e.id === n).cubes.filter((e) => e === t).length;
	return [
		"lumberjack",
		"squire",
		"breeder",
		"catapult"
	].includes(n) && d ? Math.min(d, r) * (n === "lumberjack" ? 4 * i.money : n === "squire" ? 5 * i.influence : n === "breeder" ? 2 : 2 * (i.event + i.influence)) : T(n).timing === "delayed" || T(n).timing === "mixed" ? Math.min(r, 2 + l) * i.future * (l ? 1.2 : .55) : u[n] ?? r * .6;
}
function Tt(e, t, n, r, i = St) {
	let a = e.players.find((e) => e.rid === n), o = e.rounds - e.round, s = (r.value ?? 0) * i.money;
	switch (r.kind) {
		case "agriculture": return (r.n ?? 0) * i.money - s;
		case "cathedral": {
			let t = k(e, n), a = e.cathedral.map((e) => e.length), o = /* @__PURE__ */ new Set();
			return t.effective.forEach((e) => {
				o.add(a[e.value - 1]), a[e.value - 1]++;
			}), (r.n ?? 0) * (1 + 1.5 * i.influence) + [...o].filter((t) => !e.cathedral.some((e) => e[t] === n)).length * 2 * i.cathedral - s;
		}
		case "combat":
		case "eventTarget": {
			let t = e.events.find((e) => e.uid === r.target), a = t && D(t.id);
			if (!t || !a) return 0;
			let o = Math.min(r.n ?? 1, a.flags - t.cubes.length), c = t.cubes.filter((e) => e === n).length, l = Math.max(0, ...e.players.filter((e) => e.rid !== n).map((e) => t.cubes.filter((t) => t === e.rid).length), t.cubes.filter((e) => e === N).length);
			return o * (i.influence + i.event) + (c + o >= l ? o + t.cubes.length === a.flags ? a.prizes[0] : a.prizes[0] * .3 : 0) + (c ? 0 : .5) - s;
		}
		case "building": return o * (1.5 + (r.color === "y" ? 0 : r.color === "w" ? -1 : -2) * i.money) * i.future + (o ? 1 : -2) - s;
		case "activity": {
			let t = e.activities.find((e) => e.id === r.card), a = T(r.card), c = t.merchants.some((e) => e.owner === n), l = a.slots.findIndex((e, n) => !t.merchants.some((e) => e.slot === n));
			return wt(e, n, r.card, r.n, i) - s + (c ? 0 : (a.slots[l] ?? 0) * i.hire + o * .3) - (!c && a.influence ? a.cost * i.influence : 0);
		}
		case "ramparts": return Math.min(r.n, 20 - a.guard) * i.future * .75 - s;
		case "source":
			if (r.ref === "supply") return 10;
			if (r.ref === "recruit") return 6;
			if (r.ref?.startsWith("e:")) return 9;
			if (r.ref?.startsWith("b:")) return 3 - o * .4;
			if (r.ref?.startsWith("a:")) {
				let t = e.activities[+r.ref.split(":")[1]], n = t.merchants[+r.ref.split(":")[2]];
				return -(T(t.id).slots[n.slot] ?? 0) - o;
			}
			return 0;
		case "setup": return r.color === "y" ? 2.1 : r.color === "r" ? 1.9 : 2;
		case "store": return (r.n ?? 1) * i.future * (o ? 1 : .1);
		case "useStored": return (r.n ?? 1) * 2;
		case "convert": return (r.n ?? 1) * .6;
		case "cathedralTarget": return 2 + (e.cathedral.some((t) => t[e.cathedral[r.value - 1].length] === n) ? 0 : 2) + r.value * .02;
		case "gainInfluence": return Math.min(r.n, 20 - a.influence) * i.influence;
		case "gainVp": return r.n;
		case "miller": return (r.n ?? 0) * i.money;
		case "takeInfluence": return (r.n ?? 0) * i.influence;
		case "outdoorUse":
		case "protect": return 3;
		case "guardMove": return a.guard < 20 ? (o + 1) * .3 : 0;
		case "outdoorCube": return r.card === "arrivalCubes" ? 1 : r.card === "cubeMajority" ? 2 : 1.5;
		case "copyCube": return r.card === "hermit" ? 2 : 1;
		case "stop":
		case "acceptEvent": return -1;
		case "releaseCitizen": return r.target === n ? 3 : 0;
		case "loseCube": return -1;
		default: return 0;
	}
}
var Et = /* @__PURE__ */ new Set([
	"activity",
	"agriculture",
	"cathedral",
	"combat",
	"building",
	"ramparts"
]);
function Dt(e, t, n) {
	let r = e.public, i = Ct(r, e.private, t), a = r.dice.filter((e) => e.color !== "p" || e.owner === t), o = [], s = [null, ...r.activities.filter((e) => e.revealed && T(e.id).timing === "delayed" && e.cubes.includes(t)).map((e) => e.id)], c = [];
	a.forEach((e, t) => {
		c.push([e.id]), a.slice(t + 1).forEach((n, r) => {
			c.push([e.id, n.id]), a.slice(t + r + 2).forEach((t) => c.push([
				e.id,
				n.id,
				t.id
			]));
		});
	});
	for (let a of c) for (let c of s) for (let s of a.some((e) => r.dice.find((t) => t.id === e)?.color === "p") ? C : ["y"]) {
		let l = [
			"preacher",
			"distiller",
			"viticulturist"
		].includes(c ?? "") ? a.length : 1;
		for (let u = 0; u < l; u++) {
			let l = {
				...F(),
				dice: a,
				modifier: c,
				param: u,
				color: s
			}, d = k(r, t, l);
			if (!(!d || d.cost > r.players.find((e) => e.rid === t).money)) {
				i.draft = l;
				for (let { option: a } of Ee(i, t).filter((e) => Et.has(e.option.kind))) {
					let i = Tt({
						...r,
						draft: l
					}, e.private, t, a, n) - d.dice.filter((e) => e.owner === t).reduce((e, t) => e + t.value * .045, 0) - (c ? .3 : 0);
					o.push({
						plan: {
							draft: l,
							kind: a.kind,
							card: a.card,
							target: a.target,
							n: a.n,
							value: a.value
						},
						score: i
					});
				}
			}
		}
	}
	return o.sort((e, t) => t.score - e.score);
}
function Ot(e, t, n) {
	let r = e.dice.filter((e) => e.owner === n), i = t.find((e) => e.kind === "protect");
	if (i) return i;
	let a = Infinity, o = [];
	for (let t = 1; t < 2 ** r.length; t++) {
		let n = r.reduce((e, n, r) => e + (t & 2 ** r ? n.value * (n.color === "r" || n.color === "p" ? 2 : 1) : 0), 0), i = r.reduce((e, n, r) => e + (t & 2 ** r ? 1 + n.value / 15 : 0), 0);
		n >= e.black[0] && i < a && (a = i, o = r.filter((e, n) => t & 2 ** n).map((e) => e.id));
	}
	return o.length ? t.find((t) => t.kind === "die" && o.includes(t.ref) !== e.draft.dice.includes(t.ref)) ?? t.find((e) => e.kind === "defend") : t.find((e) => e.kind === "loseDefense");
}
function kt(e = St) {
	return (t, n) => {
		let r = t.public, i = t.private, a = i?.choices ?? [];
		if (!i || r.pending?.rid !== n.rid || !a.length) return null;
		let o, s = null;
		if (r.pending.kind === "defend") o = Ot(r, a, n.rid);
		else if (r.pending.kind === "action") {
			let i = `${r.round}:${r.dice.map((e) => `${e.id},${e.value},${e.owner}`).join(";")}:${r.players.map((e) => `${e.money},${e.influence}`).join(";")}`, c = n.memory, l = c?.fingerprint === i ? c.plan : void 0;
			if (!l) {
				let r = Dt(t, n.rid, e);
				l = (n.difficulty === "weak" ? r[Math.floor(crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32 * Math.min(15, r.length))] : r[0])?.plan;
			}
			s = {
				fingerprint: i,
				plan: l
			}, l && (o = a.find((e) => e.kind === "die" && l.draft.dice.includes(e.ref) !== r.draft.dice.includes(e.ref)), !o && (r.draft.modifier !== l.draft.modifier || r.draft.param !== l.draft.param) && (o = l.draft.modifier ? a.find((e) => e.kind === "modifier" && e.card === l.draft.modifier && e.n === l.draft.param) : a.find((e) => e.kind === "clear")), !o && r.draft.color !== l.draft.color && r.draft.dice.some((e) => r.dice.find((t) => t.id === e)?.color === "p") && (o = a.find((e) => e.kind === "color" && e.color === l.draft.color)), o ||= a.find((e) => Et.has(e.kind) && e.kind === l.kind && e.card === l.card && e.target === l.target && e.n === l.n && e.value === l.value)), o ??= a.find((e) => e.kind === "pass");
		} else o = [...a].sort((t, a) => Tt(r, i, n.rid, a, e) - Tt(r, i, n.rid, t, e))[0];
		return o ? {
			action: {
				type: "choose",
				id: o.id
			},
			memory: s
		} : null;
	};
}
var At = kt(), jt = (e, t, n) => {
	let r = e.type === "choose" ? t.private?.choices.find((t) => t.id === e.id) : null;
	return n("games.troyes.hint", { action: r?.card ? n(`games.troyes.cardNames.${r.card}`) : n("games.troyes.choose") });
};
//#endregion
//#region src/games/troyes/fx.tsx
function Mt({ at: e, children: t, reveal: n = !1 }) {
	let a = i(null);
	return r(() => {
		let e = a.current?.animate(n ? [{
			transform: "perspective(700px) rotateY(-90deg)",
			opacity: .4
		}, {
			transform: "perspective(700px) rotateY(0deg)",
			opacity: 1
		}] : [
			{
				transform: "rotate(-65deg) scale(.65)",
				opacity: .3
			},
			{
				transform: "rotate(22deg) scale(1.08)",
				opacity: 1,
				offset: .6
			},
			{
				transform: "rotate(0deg) scale(1)",
				opacity: 1
			}
		], {
			duration: 400,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [n]), /* @__PURE__ */ m("div", {
		ref: a,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: t
	});
}
function Nt({ id: e }) {
	let t = l();
	return /* @__PURE__ */ h("div", {
		style: {
			height: "100%",
			padding: 10,
			border: "2px solid #786345",
			borderRadius: 13,
			background: "#e8d5a9",
			color: "#443526",
			display: "grid",
			alignContent: "center",
			gap: 8
		},
		children: [/* @__PURE__ */ m("b", { children: t(`games.troyes.cardNames.${e}`) }), /* @__PURE__ */ m("img", {
			src: `games/troyes/art/${e}.svg`,
			alt: "",
			style: {
				width: "100%",
				maxHeight: "75%",
				objectFit: "contain"
			}
		})]
	});
}
var Pt = {
	troyesRoll(e, t) {
		let n = e.data, r = t.anchor(n.target);
		return r ? {
			ms: 400,
			hide: t.queued ? [] : [n.target],
			node: /* @__PURE__ */ m(Mt, {
				at: r,
				children: /* @__PURE__ */ m(ot, {
					color: n.color,
					value: n.value
				})
			})
		} : null;
	},
	troyesMove(e, t) {
		let n = e.data, r = t.anchor(n.from), i = t.anchor(n.to);
		if (!r || !i) return null;
		let a = n.owner ?? e.rid, o = a === "$neutral" ? "#82796d" : a === "$roy" ? "#292a29" : u[(t.member(a ?? "")?.colorIndex ?? 0) % u.length].hex, s = n.piece === "cube" ? 17 : n.piece === "card" ? 46 : 34, c = (e) => ({
			x: e.x + (e.w - s) / 2,
			y: e.y + (e.h - s) / 2,
			w: s,
			h: s
		});
		return {
			ms: 400,
			hide: t.queued || !n.hide ? [] : [n.hide],
			node: /* @__PURE__ */ m(_, {
				from: c(r),
				to: c(i),
				ms: 400,
				children: /* @__PURE__ */ m("span", {
					style: {
						width: s,
						height: s,
						display: "block"
					},
					children: n.piece === "die" ? /* @__PURE__ */ m(ot, {
						color: n.color,
						value: n.value
					}) : n.piece === "citizen" ? /* @__PURE__ */ m(Q, { color: o }) : n.piece === "card" ? /* @__PURE__ */ m("span", {
						style: {
							display: "grid",
							placeItems: "center",
							height: "100%",
							background: "#e6d3a9",
							border: "2px solid #61492f",
							borderRadius: 5,
							color: "#61492f",
							fontSize: 27
						},
						children: "⚜"
					}) : /* @__PURE__ */ m("span", { style: {
						display: "block",
						width: s,
						height: s,
						background: o,
						border: "1px solid #433122",
						boxShadow: "inset 3px 3px #fff5"
					} })
				})
			})
		};
	},
	troyesAction(e, t) {
		let n = e.data, r = n.kind === "cathedral" ? `cathedral:${n.value}` : n.card ? `card:${n.card}` : n.target ?? (e.rid ? `seat:${e.rid}` : "black"), i = t.anchor(r) ?? t.anchor("black");
		return i ? n.kind === "reveal" && n.card ? {
			ms: 400,
			hide: t.queued ? [] : [r],
			node: /* @__PURE__ */ m(Mt, {
				at: i,
				reveal: !0,
				children: /* @__PURE__ */ m(Nt, { id: n.card })
			})
		} : {
			ms: 400,
			node: /* @__PURE__ */ m(ne, {
				at: i,
				ms: 400
			})
		} : null;
	},
	troyesResources(e, t) {
		let n = e.data, r = t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 400,
			node: /* @__PURE__ */ m(g, {
				at: r,
				ms: 400,
				children: /* @__PURE__ */ h("b", {
					style: {
						color: "#443526",
						background: "#fff1cb",
						padding: "4px 8px",
						border: "1px solid #735438",
						borderRadius: 8,
						whiteSpace: "nowrap"
					},
					children: [n.money ? `${n.money > 0 ? "+" : ""}${n.money} ◉ ` : "", n.influence ? `${n.influence > 0 ? "+" : ""}${n.influence} ⚜` : ""]
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/troyes/game-over.tsx
function Ft(e) {
	let t = Je.safeParse(e.public);
	return !t.success || t.data.phase !== "done" ? /* @__PURE__ */ m(y, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: Ie.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby
	}) : /* @__PURE__ */ m(It, {
		...e,
		pub: t.data
	});
}
function It({ pub: e, ...t }) {
	let r = c((e) => e.locale), o = l(), s = r === "en" ? vt : _t, [d, ee] = a(!0), [f, p] = a(null), g = i(null), _ = i(null), ne = i(null);
	n(() => {
		if (!f) return;
		let e = setTimeout(() => p(null), 5e3);
		return () => clearTimeout(e);
	}, [f]), n(() => {
		_.current?.focus({ preventScroll: !0 });
	}, []);
	let y = (e) => {
		ee(e), p(null), requestAnimationFrame(() => (e ? _ : ne).current?.focus({ preventScroll: !0 }));
	}, b = (e) => {
		let n = t.members.find((t) => t.rid === e);
		return e === "$roy" ? s.roy : n ? te(n, r) : e;
	}, x = e.solo ? e.final.map((e) => e.rid) : t.result.ranking, S = [
		{
			key: "points",
			label: s.points
		},
		{
			key: "merchants",
			label: s.merchantPoints
		},
		{
			key: "events",
			label: s.eventPresence
		},
		{
			key: "cathedral",
			label: s.cathedralPenalty
		},
		{
			key: "characters",
			label: s.characters
		},
		{
			key: "activities",
			label: s.activities
		},
		{
			key: "outdoors",
			label: s.outdoors
		}
	], C = (e) => {
		f === e ? (p(null), (e === "again" ? t.onPlayAgain : t.onBackToLobby)?.()) : p(e);
	};
	return /* @__PURE__ */ h("div", {
		className: "troyes-endgame",
		children: [
			/* @__PURE__ */ m(ie, {}),
			/* @__PURE__ */ m("div", {
				className: "troyes-final-board",
				inert: d,
				children: /* @__PURE__ */ m(xt, {
					public: e,
					private: t.private,
					members: t.members,
					myRid: t.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "troyes-result-overlay",
				hidden: !d,
				children: /* @__PURE__ */ h("section", {
					ref: g,
					role: "dialog",
					"aria-modal": "true",
					"aria-label": o("session.result.title"),
					className: "troyes-result-panel",
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), y(!1)), e.key === "Tab") {
							let t = g.current?.querySelectorAll("button:not(:disabled)");
							if (!t?.length) return;
							let n = t[0], r = t[t.length - 1];
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus());
						}
					},
					children: [
						/* @__PURE__ */ h("header", {
							className: "troyes-result-heading",
							children: [/* @__PURE__ */ h("div", { children: [
								/* @__PURE__ */ m("span", {
									className: "troyes-result-seal",
									children: "⚜"
								}),
								/* @__PURE__ */ m("h1", { children: s.name }),
								/* @__PURE__ */ m("p", { children: o("session.result.title") })
							] }), /* @__PURE__ */ m("button", {
								ref: _,
								"aria-label": s.readBoard,
								title: s.readBoard,
								onClick: () => y(!1),
								children: /* @__PURE__ */ m(re, { size: 23 })
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "troyes-result-body",
							children: [
								/* @__PURE__ */ h("div", {
									className: "troyes-result-outcome",
									children: [e.solo ? bt(s.challenge, { n: t.result.scores?.[t.myRid] ?? 0 }) : t.result.winner.map(b).join(" · "), !e.solo && t.result.winner.length > 0 && /* @__PURE__ */ m("span", {
										"aria-hidden": !0,
										children: " 👑"
									})]
								}),
								t.hintCount !== void 0 && /* @__PURE__ */ m("p", {
									className: "troyes-result-hints",
									children: o("session.hint.usedCount", { n: t.hintCount })
								}),
								/* @__PURE__ */ m("div", {
									className: "troyes-score-scroll",
									children: /* @__PURE__ */ h("table", {
										className: "troyes-score-table",
										children: [
											/* @__PURE__ */ m("caption", {
												className: "sr-only",
												children: s.scoreboard
											}),
											/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { children: s.scoreboard }), x.map((e) => /* @__PURE__ */ h("th", {
												style: { "--owner": e === "$roy" ? "#34312e" : u[(t.members.find((t) => t.rid === e)?.colorIndex ?? 0) % u.length].hex },
												"data-winner": t.result.winner.includes(e),
												children: [
													/* @__PURE__ */ m("span", { children: b(e) }),
													e === t.myRid && /* @__PURE__ */ m("small", { children: o("lobby.you") }),
													(t.result.autopilot?.[e] ?? 0) > 0 && /* @__PURE__ */ h("small", { children: [/* @__PURE__ */ m(v, { size: 12 }), o("session.autopilot.share", { n: Math.round(t.result.autopilot[e] * 100) })] })
												]
											}, e))] }) }),
											/* @__PURE__ */ m("tbody", { children: S.filter((t) => !["activities", "outdoors"].includes(t.key) || e.final.some((e) => e[t.key] !== 0)).map((t) => /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { children: t.label }), x.map((n) => /* @__PURE__ */ m("td", { children: e.final.find((e) => e.rid === n)?.[t.key] ?? "—" }, n))] }, t.key)) }),
											/* @__PURE__ */ m("tfoot", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { children: s.finalTotal }), x.map((n) => /* @__PURE__ */ m("td", {
												"data-winner": t.result.winner.includes(n),
												children: e.final.find((e) => e.rid === n)?.total ?? "—"
											}, n))] }) })
										]
									})
								})
							]
						}),
						/* @__PURE__ */ h("footer", {
							className: "troyes-result-actions",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || p(null);
							},
							children: [
								t.onBackToLobby && /* @__PURE__ */ m("button", {
									className: f === "lobby" ? "btn-base danger-stripes text-white" : "btn-quiet",
									onClick: () => C("lobby"),
									children: f === "lobby" ? `${s.confirm} · ${s.back}` : s.back
								}),
								t.onPlayAgain && /* @__PURE__ */ m("button", {
									className: f === "again" ? "btn-base danger-stripes text-white" : "btn-base",
									onClick: () => C("again"),
									children: f === "again" ? `${s.confirm} · ${s.playAgain}` : s.playAgain
								}),
								!t.onPlayAgain && !t.onBackToLobby && /* @__PURE__ */ m("p", { children: s.waitingHost })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "troyes-review-toolbar",
				hidden: d,
				children: /* @__PURE__ */ m("button", {
					ref: ne,
					className: "btn-base",
					onClick: () => y(!0),
					children: s.scoreboard
				})
			})
		]
	});
}
//#endregion
//#region src/games/troyes/options.tsx
function Lt({ value: e, onChange: t }) {
	let n = c((e) => e.locale) === "en" ? vt : _t, r = Le.safeParse(e), i = r.success ? r.data : Le.parse(void 0);
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ m("p", {
				className: "text-sm",
				children: n.options.soloNote
			}),
			/* @__PURE__ */ m(x, {
				title: n.options.activities,
				columns: 3,
				children: [
					"base",
					"ladies",
					"mixed"
				].map((e) => /* @__PURE__ */ m(b, {
					name: "troyes-activities",
					value: e,
					checked: i.activities === e,
					label: n.options[e],
					accent: Ie.accent,
					onChange: () => t({
						...i,
						activities: e
					})
				}, e))
			}),
			[
				"bonus",
				"ladiesCharacters",
				"publicCharacter",
				"ladiesEvents",
				"family",
				"ramparts",
				"tournament"
			].map((e) => /* @__PURE__ */ m(S, {
				checked: i[e],
				label: n.options[e],
				accent: Ie.accent,
				onChange: () => t({
					...i,
					[e]: !i[e]
				})
			}, e))
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/troyes/entry.tsx
var Rt = {
	definition: nt,
	View: xt,
	bot: At,
	describe: jt,
	fx: Pt,
	OverView: Ft,
	Options: Lt,
	locales: {
		zh: _t,
		en: vt
	}
};
//#endregion
export { Rt as default };
