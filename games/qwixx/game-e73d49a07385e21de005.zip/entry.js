import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d, seatName as f } from "@bgparty/sdk/ui/player-strip";
import { gridCell as p } from "@bgparty/sdk/sheet-geometry";
import { SheetMark as m } from "@bgparty/sdk/sheet-mark";
import { SheetView as h } from "@bgparty/sdk/sheet-view";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { AVATARS as y } from "@bgparty/sdk/avatars";
import { IconBot as b } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as x } from "@bgparty/sdk/player-colors";
import { Confetti as S } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as C } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/qwixx/meta.ts
var w = {
	id: "qwixx",
	tier: "released",
	mechanics: ["roll-and-write", "dice-rolling"],
	interactionTags: [],
	nameKey: "games.qwixx.name",
	descKey: "games.qwixx.desc",
	rulesKey: "games.qwixx.rules",
	icon: "🎲",
	iconImg: "games/qwixx.webp",
	rulesUrl: { en: "https://gamewright.com/gamewright/pdfs/Rules/QwixxTM-RULES.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#dc2626",
	releasedAt: "2026-09-16",
	search: {
		py: "kuai ke si",
		init: "kks"
	},
	hotseat: "cover"
}, T = t.enum([
	"red",
	"yellow",
	"green",
	"blue"
]), E = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("mark"),
		source: t.enum(["white", "color"]),
		row: T,
		whiteIdx: t.union([t.literal(0), t.literal(1)]).optional()
	}),
	t.object({
		type: t.literal("pass"),
		stage: t.enum(["white", "color"])
	})
]), D = t.object({
	marks: t.record(T, t.array(t.boolean()).length(11)),
	locks: t.array(T),
	penalties: t.int().min(0).max(4)
}), O = t.object({
	players: t.array(t.string()).min(2).max(5),
	active: t.string(),
	phase: t.enum([
		"roll",
		"white",
		"color",
		"done"
	]),
	white: t.tuple([t.int().min(0).max(6), t.int().min(0).max(6)]),
	colored: t.partialRecord(T, t.int().min(1).max(6)),
	lockedRows: t.array(T),
	sheets: t.record(t.string(), D),
	whiteDone: t.array(t.string()),
	activeWhiteMarked: t.boolean()
}), k = t.object({}), A = [
	"red",
	"yellow",
	"green",
	"blue"
], j = [
	0,
	1,
	3,
	6,
	10,
	15,
	21,
	28,
	36,
	45,
	55,
	66,
	78
];
function M() {
	return {
		marks: {
			red: Array(11).fill(!1),
			yellow: Array(11).fill(!1),
			green: Array(11).fill(!1),
			blue: Array(11).fill(!1)
		},
		locks: [],
		penalties: 0
	};
}
function ee(e, t) {
	return e === "red" || e === "yellow" ? t + 2 : 12 - t;
}
function N(e, t) {
	return e === "red" || e === "yellow" ? t - 2 : 12 - t;
}
function P(e, t) {
	return e.marks[t].filter(Boolean).length;
}
function te(e, t, n, r) {
	if (t.includes(n)) return !1;
	let i = e.marks[n];
	if (r < 0 || r >= 11 || i[r]) return !1;
	for (let e = r + 1; e < 11; e++) if (i[e]) return !1;
	return !(r === 10 && P(e, n) < 5);
}
function F(e, t, n, r) {
	return te(e, t, n, N(n, r));
}
function I(e, t) {
	return j[P(e, t) + +!!e.locks.includes(t)];
}
function L(e) {
	return A.reduce((t, n) => t + I(e, n), 0) - 5 * e.penalties;
}
//#endregion
//#region src/games/qwixx/rules.ts
var R = {
	over: "games.qwixx.errOver",
	notYourTurn: "games.qwixx.errNotYourTurn",
	badCell: "games.qwixx.errBadCell",
	badStage: "games.qwixx.errBadStage",
	alreadyDone: "games.qwixx.errAlreadyDone"
};
function ne(t, n, r) {
	let i = {};
	for (let e of n) i[e] = M();
	return {
		state: {
			players: n,
			activeIdx: e(r, 0, n.length),
			phase: "roll",
			white: [0, 0],
			colored: {},
			lockedRows: [],
			sheets: i,
			whiteDone: [],
			activeWhiteMarked: !1,
			seed: r,
			rngCursor: 1
		},
		fx: []
	};
}
function z(e) {
	return e.players[e.activeIdx];
}
function re(e, t) {
	let n = e.white[0] + e.white[1];
	return A.some((r) => F(e.sheets[t], e.lockedRows, r, n));
}
function B(e, t, n, r) {
	let i = e.sheets[t], a = N(n, r);
	i.marks[n][a] = !0, a === 10 && (i.locks.push(n), e.lockedRows.push(n));
}
function V(e) {
	return e.lockedRows.length >= 2 || e.players.some((t) => e.sheets[t].penalties >= 4) ? (e.phase = "done", !0) : !1;
}
function H(e) {
	return e.players.every((t) => e.whiteDone.includes(t) || !re(e, t));
}
function U(e) {
	e.activeIdx = (e.activeIdx + 1) % e.players.length, e.phase = "roll", e.white = [0, 0], e.colored = {}, e.whiteDone = [], e.activeWhiteMarked = !1;
}
function ie(t, n, r) {
	if (t.phase === "done") return { code: R.over };
	if (n.type === "roll") {
		if (t.phase !== "roll" || r.by !== z(t)) return { code: R.notYourTurn };
		let n = structuredClone(t);
		n.white = [e(n.seed, n.rngCursor, 6) + 1, e(n.seed, n.rngCursor + 1, 6) + 1], n.rngCursor += 2;
		let i = {};
		for (let t of A) n.lockedRows.includes(t) || (i[t] = e(n.seed, n.rngCursor, 6) + 1, n.rngCursor += 1);
		return n.colored = i, n.phase = H(n) ? "color" : "white", {
			state: n,
			fx: []
		};
	}
	if (n.type === "mark") {
		let e = structuredClone(t);
		if (n.source === "white") {
			if (e.phase !== "white") return { code: R.badStage };
			if (e.whiteDone.includes(r.by)) return { code: R.alreadyDone };
			let t = e.white[0] + e.white[1];
			return F(e.sheets[r.by], e.lockedRows, n.row, t) ? (B(e, r.by, n.row, t), e.whiteDone.push(r.by), r.by === z(e) && (e.activeWhiteMarked = !0), !V(e) && H(e) && (e.phase = "color"), {
				state: e,
				fx: []
			}) : { code: R.badCell };
		}
		if (e.phase !== "color" || r.by !== z(e)) return { code: R.notYourTurn };
		let i = e.colored[n.row];
		if (i === void 0) return { code: R.badCell };
		let a = e.white[n.whiteIdx ?? 0];
		return F(e.sheets[r.by], e.lockedRows, n.row, a + i) ? (B(e, r.by, n.row, a + i), V(e) || U(e), {
			state: e,
			fx: []
		}) : { code: R.badCell };
	}
	if (n.type === "pass") {
		let e = structuredClone(t);
		return n.stage === "white" ? e.phase === "white" ? e.whiteDone.includes(r.by) ? { code: R.alreadyDone } : (e.whiteDone.push(r.by), H(e) && (e.phase = "color"), {
			state: e,
			fx: []
		}) : { code: R.badStage } : e.phase !== "color" || r.by !== z(e) ? { code: R.notYourTurn } : (e.activeWhiteMarked || (e.sheets[r.by].penalties += 1), V(e) || U(e), {
			state: e,
			fx: []
		});
	}
	return { code: R.notYourTurn };
}
function ae(e) {
	return {
		public: {
			players: e.players,
			active: z(e),
			phase: e.phase,
			white: [...e.white],
			colored: { ...e.colored },
			lockedRows: [...e.lockedRows],
			sheets: e.sheets,
			whiteDone: [...e.whiteDone],
			activeWhiteMarked: e.activeWhiteMarked
		},
		private: {}
	};
}
function oe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = L(e.sheets[n]);
	let n = [...e.players].sort((n, r) => t[r] - t[n] || e.players.indexOf(n) - e.players.indexOf(r));
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === t[n[0]]),
		ranking: n,
		scores: t
	};
}
var se = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: E,
		publicView: O,
		privateView: k
	},
	setup: ne,
	reduce: ie,
	viewFor: ae,
	status: oe
}, W = 1386, G = {
	red: {
		x: 63,
		y: 28,
		w: 106,
		h: 102,
		pitch: 109,
		count: 11
	},
	yellow: {
		x: 63,
		y: 171,
		w: 106,
		h: 102,
		pitch: 109,
		count: 11
	},
	green: {
		x: 63,
		y: 315,
		w: 106,
		h: 102,
		pitch: 109,
		count: 11
	},
	blue: {
		x: 63,
		y: 459,
		w: 106,
		h: 102,
		pitch: 109,
		count: 11
	}
}, ce = {
	red: {
		cx: 1307,
		cy: 79,
		r: 42
	},
	yellow: {
		cx: 1307,
		cy: 221,
		r: 42
	},
	green: {
		cx: 1307,
		cy: 366,
		r: 42
	},
	blue: {
		cx: 1307,
		cy: 510,
		r: 42
	}
}, le = {
	x: 1136,
	y: 644,
	w: 53,
	h: 58,
	pitch: 62.4,
	count: 4
};
//#endregion
//#region src/games/qwixx/sheet-view.tsx
function K({ x: e, y: t, w: n, h: r }) {
	return /* @__PURE__ */ _(m, {
		mark: "x",
		rect: {
			x: e,
			y: t,
			w: n,
			h: r
		},
		strokeWidth: 10,
		inset: .18
	});
}
function ue({ row: e }) {
	let t = G[e], n = t.x - 20, r = t.y - 16, i = W - t.x * 2 + 40, a = t.h + 32;
	return /* @__PURE__ */ v("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ _("rect", {
			x: n,
			y: r,
			width: i,
			height: a,
			rx: 18,
			fill: "var(--color-surface)",
			fillOpacity: .45
		}), /* @__PURE__ */ _("rect", {
			x: n,
			y: r,
			width: i,
			height: a,
			rx: 18,
			fill: "url(#qwixx-lock-hatch)"
		})]
	});
}
function q({ sheet: e, lockedRows: t, eligible: n, onTapCell: r, readOnly: a, fitKey: o }) {
	let s = i(() => n?.map((e) => ({
		key: `${e.row}:${e.cell}`,
		rect: p(G[e.row], e.cell)
	})), [n]), c = i(() => new Map(n?.map((e) => [`${e.row}:${e.cell}`, e])), [n]);
	return /* @__PURE__ */ v(h, {
		image: "games/qwixx/sheet.webp",
		sheetW: W,
		sheetH: 722,
		eligible: s,
		onTapEligible: r ? (e) => {
			let t = c.get(e);
			t && r(t);
		} : void 0,
		readOnly: a,
		fitKey: o,
		children: [
			/* @__PURE__ */ _("defs", { children: /* @__PURE__ */ _("pattern", {
				id: "qwixx-lock-hatch",
				width: 28,
				height: 28,
				patternUnits: "userSpaceOnUse",
				patternTransform: "rotate(45)",
				children: /* @__PURE__ */ _("line", {
					x1: 0,
					y1: 0,
					x2: 0,
					y2: 28,
					stroke: "var(--color-ink)",
					strokeWidth: 6,
					strokeOpacity: .18
				})
			}) }),
			t.map((e) => /* @__PURE__ */ _(ue, { row: e }, `lk${e}`)),
			A.map((t) => e.marks[t].map((e, n) => e ? /* @__PURE__ */ _(K, { ...p(G[t], n) }, `${t}${n}`) : null)),
			e.locks.map((e) => {
				let t = ce[e];
				return /* @__PURE__ */ _(K, {
					x: t.cx - t.r,
					y: t.cy - t.r,
					w: t.r * 2,
					h: t.r * 2
				}, `lock${e}`);
			}),
			Array.from({ length: e.penalties }, (e, t) => /* @__PURE__ */ _(K, { ...p(le, t) }, `pen${t}`))
		]
	});
}
//#endregion
//#region src/games/qwixx/view-player.tsx
var de = {
	red: "#ef2b2f",
	yellow: "#f7e600",
	green: "#00a651",
	blue: "#2e3192"
}, fe = {
	red: "games.qwixx.dieAria.red",
	yellow: "games.qwixx.dieAria.yellow",
	green: "games.qwixx.dieAria.green",
	blue: "games.qwixx.dieAria.blue"
}, pe = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function J({ color: e, value: t, label: n }) {
	let r = e === "white" ? "#ffffff" : de[e], i = e === "white" || e === "yellow" ? "var(--color-ink)" : "#ffffff", a = e === "yellow";
	return /* @__PURE__ */ v("svg", {
		viewBox: "0 0 48 48",
		role: "img",
		"aria-label": n,
		className: "qx-die shrink-0",
		children: [/* @__PURE__ */ _("rect", {
			x: 2,
			y: 2,
			width: 44,
			height: 44,
			rx: 10,
			fill: r,
			stroke: "var(--color-ink)",
			strokeWidth: 2.5
		}), t > 0 && pe[t].map(([e, t], n) => /* @__PURE__ */ _("circle", {
			cx: e * 48,
			cy: t * 48,
			r: 4.6,
			fill: i,
			stroke: a ? void 0 : "none"
		}, n))]
	});
}
function me(e) {
	let t = e.public;
	return /* @__PURE__ */ _(he, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function he({ pub: e, members: t, myRid: r, send: s }) {
	let f = c(), [p, m] = o(r), h = a(null), [y, b] = o("");
	n(() => {
		let e = h.current;
		if (!e) return;
		let t = !0, n = new ResizeObserver(() => {
			if (!t) return;
			let { width: n, height: r } = e.getBoundingClientRect();
			if (n <= 0 || r <= 0) return;
			let i = `${n}x${r}`;
			b((e) => e === i ? e : i);
		});
		return n.observe(e), () => {
			t = !1, n.disconnect();
		};
	}, []);
	let x = e.sheets[r], S = e.sheets[p] ?? x, C = e.active === r, T = (e) => t.find((t) => t.rid === e)?.name ?? e, E = e.white[0] + e.white[1], D = i(() => {
		if (!x) return [];
		if (e.phase === "white" && !e.whiteDone.includes(r)) return A.filter((t) => F(x, e.lockedRows, t, E)).map((e) => ({
			row: e,
			cell: N(e, E)
		}));
		if (e.phase === "color" && C) {
			let t = [], n = /* @__PURE__ */ new Set();
			for (let r of A) {
				let i = e.colored[r];
				if (i !== void 0) for (let a of [0, 1]) {
					let o = e.white[a] + i, s = `${r}:${o}`;
					n.has(s) || F(x, e.lockedRows, r, o) && (n.add(s), t.push({
						row: r,
						cell: N(r, o)
					}));
				}
			}
			return t;
		}
		return [];
	}, [
		x,
		e,
		r,
		C,
		E
	]), O = p === r && D.length > 0, k = (t) => {
		if (!O) return;
		if (e.phase === "white") {
			s({
				type: "mark",
				source: "white",
				row: t.row
			});
			return;
		}
		let n = ee(t.row, t.cell), r = e.colored[t.row];
		if (r === void 0) return;
		let i = e.white[0] + r === n ? 0 : 1;
		s({
			type: "mark",
			source: "color",
			row: t.row,
			whiteIdx: i
		});
	}, j = e.whiteDone.includes(r), M = e.phase === "white" && !j ? D.length : 0, P = e.phase === "roll" ? C ? {
		tone: "accent",
		text: f("games.qwixx.rollPrompt")
	} : {
		tone: "info",
		text: f("games.qwixx.waitingRoll", { name: T(e.active) })
	} : e.phase === "white" ? j ? {
		tone: "info",
		text: f("games.qwixx.waitingWhite")
	} : M > 0 ? {
		tone: "accent",
		text: f("games.qwixx.whitePrompt", { n: E })
	} : {
		tone: "info",
		text: f("games.qwixx.whiteNoSpot", { n: E })
	} : C ? {
		tone: "accent",
		text: f("games.qwixx.colorPrompt")
	} : {
		tone: "info",
		text: f("games.qwixx.waitingColor", { name: T(e.active) })
	};
	return /* @__PURE__ */ _("div", {
		className: "qx-view",
		children: /* @__PURE__ */ _(l, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ _(u, {
				tone: P.tone,
				text: P.text,
				accent: w.accent,
				chip: `${e.lockedRows.length}/2 🔒`
			}),
			actionsHeight: "qx-action-height",
			actions: /* @__PURE__ */ v("div", {
				className: "qx-stage",
				children: [
					e.phase === "roll" && C && /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => s({ type: "roll" }),
						className: "btn-base min-h-12 w-full text-base font-black text-white",
						style: { background: w.accent },
						children: f("games.qwixx.roll")
					}),
					e.phase === "white" && !j && M > 0 && /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => s({
							type: "pass",
							stage: "white"
						}),
						className: "btn-quiet min-h-11 w-full text-sm font-bold",
						children: f("games.qwixx.skipWhite")
					}),
					e.phase === "color" && C && /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => s({
							type: "pass",
							stage: "color"
						}),
						className: e.activeWhiteMarked ? "btn-quiet min-h-11 w-full text-sm font-bold" : "btn-base min-h-12 w-full text-base font-black text-white bg-rose-500",
						children: e.activeWhiteMarked ? f("games.qwixx.endTurn") : f("games.qwixx.passPenalty")
					})
				]
			}),
			children: /* @__PURE__ */ v("div", {
				className: "qx-table",
				children: [
					/* @__PURE__ */ _("div", {
						className: "qx-players",
						children: /* @__PURE__ */ _(d, {
							members: t.filter((t) => e.players.includes(t.rid)),
							myRid: r,
							variant: "plate",
							status: (t) => {
								let n = e.sheets[t];
								return n ? /* @__PURE__ */ v("span", {
									className: "flex items-center gap-1.5 font-mono tabular-nums",
									children: [/* @__PURE__ */ _("span", {
										className: "qx-total text-base font-black",
										children: L(n)
									}), n.penalties > 0 && /* @__PURE__ */ v("span", {
										className: "qx-penalty text-xs font-bold text-rose-600",
										"aria-label": f("games.qwixx.penaltyAria", { n: n.penalties }),
										children: ["✕", n.penalties]
									})]
								}) : null;
							},
							action: (t) => e.phase === "white" ? e.whiteDone.includes(t) ? "done" : "pending" : null,
							onPick: (e) => m(e),
							picked: (e) => e === p
						})
					}),
					/* @__PURE__ */ _("div", {
						ref: h,
						className: "frame qx-sheet",
						children: /* @__PURE__ */ _(q, {
							sheet: S,
							lockedRows: e.lockedRows,
							eligible: O ? D : void 0,
							onTapCell: k,
							readOnly: !O,
							fitKey: `${p}:${y}`
						})
					}),
					/* @__PURE__ */ _("div", {
						className: "qx-dice",
						children: (e.phase === "white" || e.phase === "color") && /* @__PURE__ */ v(g, { children: [
							/* @__PURE__ */ _(J, {
								color: "white",
								value: e.white[0],
								label: f("games.qwixx.whiteDieAria", { n: e.white[0] })
							}),
							/* @__PURE__ */ _(J, {
								color: "white",
								value: e.white[1],
								label: f("games.qwixx.whiteDieAria", { n: e.white[1] })
							}),
							/* @__PURE__ */ _("span", {
								className: "mx-1 h-8 w-px bg-ink/20",
								"aria-hidden": !0
							}),
							A.filter((t) => e.colored[t] !== void 0).map((t) => /* @__PURE__ */ _(J, {
								color: t,
								value: e.colored[t] ?? 0,
								label: f(fe[t], { n: e.colored[t] ?? 0 })
							}, t))
						] })
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/qwixx/bot.ts
function Y(e, t, n, r) {
	if (!F(e, t, n, r)) return null;
	let i = N(n, r), a = e.marks[n], o = 0;
	for (let e = 0; e < i; e++) a[e] || (o += 1);
	let s = I(e, n), c = i === 10 && P(e, n) >= 5;
	return {
		row: n,
		cell: i,
		gain: j[P(e, n) + 1 + (c && !e.locks.includes(n) ? 1 : 0)] - s,
		skips: o
	};
}
function X(e, t) {
	if (e.length === 0) return null;
	let n = e.filter((e) => t === "weak" ? e.skips <= 1 : e.skips <= 3 || e.gain * 2 > e.skips);
	return n.length === 0 ? null : (n.sort((e, t) => t.gain - 1.5 * t.skips - (e.gain - 1.5 * e.skips)), n[0]);
}
var ge = (e, t) => {
	let n = e.public, r = n.sheets[t.rid];
	if (!r) return null;
	if (n.phase === "roll") return n.active === t.rid ? { action: { type: "roll" } } : null;
	if (n.phase === "white") {
		if (n.whiteDone.includes(t.rid)) return null;
		let e = n.white[0] + n.white[1], i = X(A.map((t) => Y(r, n.lockedRows, t, e)).filter((e) => e !== null), t.difficulty);
		return { action: i ? {
			type: "mark",
			source: "white",
			row: i.row
		} : {
			type: "pass",
			stage: "white"
		} };
	}
	if (n.phase === "color" && n.active === t.rid) {
		let e = [];
		for (let t of A) {
			let i = n.colored[t];
			if (i !== void 0) for (let a of [0, 1]) {
				let o = Y(r, n.lockedRows, t, n.white[a] + i);
				o && e.push({
					...o,
					whiteIdx: a
				});
			}
		}
		let i = X(e, t.difficulty);
		return { action: i ? {
			type: "mark",
			source: "color",
			row: i.row,
			whiteIdx: i.whiteIdx
		} : {
			type: "pass",
			stage: "color"
		} };
	}
	return null;
}, Z = {
	red: "红",
	yellow: "黄",
	green: "绿",
	blue: "蓝"
}, Q = (e, t) => e === "red" || e === "yellow" ? t + 2 : 12 - t, _e = (e, t) => T.options.map((n) => {
	let r = e.marks[n].map((e, t) => e ? `[${Q(n, t)}]` : `${Q(n, t)}`).join(" "), i = e.locks.includes(n) ? " 已锁" : t.includes(n) ? " 已被别人锁" : "";
	return `  ${n}(${Z[n]}): ${r}${i}([] = 已划)`;
}).join("\n");
function ve(e, t, n, r) {
	if (t.includes(n)) return !1;
	let i = n === "red" || n === "yellow" ? r - 2 : 12 - r;
	return i < 0 || i > 10 || e.marks[n][i] ? !1 : e.marks[n].every((e, t) => t <= i || !e);
}
var ye = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "roll" ? n.active === t.rid : n.phase === "white" ? !n.whiteDone.includes(t.rid) : n.phase === "color" && n.active === t.rid;
	},
	describeView(e, t) {
		let n = e.public, r = ["目标:划格子攒分,行锁得越早越好;4 次罚分或锁满 2 行游戏结束。行用英文枚举值(red/yellow/green/blue)输出。"];
		r.push(`当前掷骰者: ${n.active === t.rid ? "你" : n.active};白骰: ${n.white.join(" + ")}`);
		let i = Object.entries(n.colored).map(([e, t]) => `${e}(${Z[e]})骰=${t}`);
		i.length && r.push(`色骰: ${i.join(", ")}`), r.push(`已锁的行(对所有人封闭): ${n.lockedRows.map((e) => Z[e]).join("、") || "(无)"}`);
		for (let e of n.players) {
			let i = n.sheets[e];
			r.push(`${e === t.rid ? "你的表" : `${e} 的表`}(罚分 ${i.penalties}/4):`, _e(i, n.lockedRows));
		}
		let [a, o] = n.white;
		if (n.phase === "roll" && n.active === t.rid) r.push("轮到你掷骰,输出 roll 行动。");
		else if (n.phase === "white" && !n.whiteDone.includes(t.rid)) r.push(`白骰阶段:白骰和 = ${a + o}。你可以在任何一行划掉这个数字(mark,source=white),或跳过(pass,stage=white)。`);
		else if (n.phase === "color" && n.active === t.rid) {
			let e = Object.entries(n.colored).flatMap(([e, t]) => [`${Z[e]}行可划 ${a + t}(白骰${a}+${Z[e]}骰${t})`, `${Z[e]}行可划 ${o + t}(白骰${o}+${Z[e]}骰${t})`]);
			r.push(`色骰阶段(仅掷骰者):选一颗白骰+一颗色骰配对划格: ${e.join(";") || "(无可配骰)"}。输出 mark(source=color, whiteIdx=0 或 1)或 pass(stage=color)。${n.activeWhiteMarked ? "" : "注意:你白骰阶段没划,这里再不划就要吃罚分。"}`);
		}
		return r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: { type: { const: "roll" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "mark" },
				source: { enum: ["white", "color"] },
				row: { enum: [
					"red",
					"yellow",
					"green",
					"blue"
				] },
				whiteIdx: {
					type: "integer",
					enum: [0, 1],
					description: "source=color 时用哪颗白骰(两白同点可省略)"
				}
			},
			required: [
				"type",
				"source",
				"row"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "pass" },
				stage: { enum: ["white", "color"] }
			},
			required: ["type", "stage"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = E.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public, o = a.sheets[n.rid];
		if (!o) return null;
		if (i.type === "roll") return a.phase === "roll" && a.active === n.rid ? i : null;
		if (i.type === "pass") return i.stage === "white" ? a.phase === "white" && !a.whiteDone.includes(n.rid) ? i : null : a.phase === "color" && a.active === n.rid ? i : null;
		let [s, c] = a.white;
		if (i.source === "white") return a.phase !== "white" || a.whiteDone.includes(n.rid) ? null : ve(o, a.lockedRows, i.row, s + c) ? i : null;
		if (a.phase !== "color" || a.active !== n.rid) return null;
		let l = a.colored[i.row];
		if (l == null) return null;
		let u = i.whiteIdx ?? (s === c ? 0 : null);
		if (u == null) return null;
		let d = (u === 0 ? s : c) + l;
		return ve(o, a.lockedRows, i.row, d) ? i : null;
	}
};
//#endregion
//#region src/games/qwixx/game-over-row.tsx
function $({ public: e, rid: t }) {
	let n = e, r = n.sheets[t];
	return r ? /* @__PURE__ */ _("div", {
		className: "frame pointer-events-none mt-1.5 overflow-hidden",
		"aria-hidden": !0,
		children: /* @__PURE__ */ _("div", {
			style: { aspectRatio: `${W} / 722` },
			children: /* @__PURE__ */ _(q, {
				sheet: r,
				lockedRows: n.lockedRows,
				readOnly: !0,
				fitKey: `over-${t}`
			})
		})
	}) : null;
}
//#endregion
//#region src/games/qwixx/game-over.tsx
function be() {
	let e = a(null), [t, r] = o("");
	return n(() => {
		let t = e.current;
		if (!t) return;
		let n = !0, i = new ResizeObserver(([e]) => {
			let t = Math.round(e.contentRect.width), i = Math.round(e.contentRect.height);
			if (!t || !i) return;
			let a = t + "x" + i;
			queueMicrotask(() => {
				n && r((e) => e === a ? e : a);
			});
		});
		return i.observe(t), () => {
			n = !1, i.disconnect();
		};
	}, []), [e, t];
}
function xe(e) {
	let t = O.safeParse(e.public);
	return !t.success || t.data.phase !== "done" || !e.result.ranking.length || e.result.ranking.some((e) => !t.data.sheets[e]) ? /* @__PURE__ */ _(C, {
		result: e.result,
		members: e.members,
		myRid: e.myRid,
		accent: w.accent,
		onPlayAgain: e.onPlayAgain,
		onBackToLobby: e.onBackToLobby,
		renderRowExtra: t.success ? (n) => /* @__PURE__ */ _($, {
			public: t.data,
			rid: n,
			myRid: e.myRid
		}) : void 0
	}) : /* @__PURE__ */ _(Se, {
		...e,
		pub: t.data
	});
}
function Se({ pub: e, result: t, members: n, myRid: i, onPlayAgain: a, onBackToLobby: u }) {
	let d = c(), p = s((e) => e.locale), [m, h] = o(i), g = t.ranking.includes(m) ? m : t.ranking.includes(i) ? i : t.ranking[0], C = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? f(t, p) : e;
	}, [T, E] = be(), D = r();
	return /* @__PURE__ */ v("div", {
		className: "qx-over",
		children: [t.winner.length > 0 && /* @__PURE__ */ _(S, {}), /* @__PURE__ */ _(l, {
			adaptive: !0,
			scroll: !1,
			className: "qx-over-screen",
			actionsHeight: "qx-over-action-height",
			banner: /* @__PURE__ */ _("header", {
				className: "qx-over-heading",
				children: /* @__PURE__ */ _("h1", { children: d("session.result.title") })
			}),
			actions: a || u ? /* @__PURE__ */ v("div", {
				className: "qx-over-actions",
				children: [a && /* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-base text-white",
					style: { background: w.accent },
					onClick: a,
					children: d("session.result.playAgain")
				}), u && /* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-quiet",
					onClick: u,
					children: d("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ _("p", {
				className: "qx-over-wait",
				children: d("session.result.waitHost")
			}),
			children: /* @__PURE__ */ v("div", {
				className: "qx-over-main",
				children: [/* @__PURE__ */ _("ol", {
					className: "qx-over-ranking",
					"aria-label": d("games.qwixx.overRanking"),
					children: t.ranking.map((r, a) => {
						let o = n.find((e) => e.rid === r), s = t.winner.includes(r), c = t.autopilot?.[r];
						return /* @__PURE__ */ v("li", {
							"data-winner": s,
							"data-selected": r === g,
							children: [/* @__PURE__ */ v("div", {
								className: "qx-over-person",
								children: [
									/* @__PURE__ */ _("span", {
										className: "qx-over-rank",
										children: a + 1
									}),
									/* @__PURE__ */ v("span", {
										className: "qx-over-avatar",
										style: { backgroundColor: x[(o?.colorIndex ?? 0) % x.length].hex },
										children: [o && /* @__PURE__ */ _("img", {
											src: y[o.avatar % y.length],
											alt: "",
											draggable: !1
										}), s && /* @__PURE__ */ _("b", {
											"aria-hidden": !0,
											children: "👑"
										})]
									}),
									/* @__PURE__ */ v("span", {
										className: "qx-over-name",
										children: [/* @__PURE__ */ _("strong", {
											title: C(r),
											children: C(r)
										}), /* @__PURE__ */ v("span", { children: [r === i && /* @__PURE__ */ _("small", { children: d("lobby.you") }), c !== void 0 && c > 0 && /* @__PURE__ */ v("small", {
											className: "qx-over-autopilot",
											children: [/* @__PURE__ */ _(b, { size: 14 }), d("session.autopilot.share", { n: Math.round(c * 100) })]
										})] })]
									}),
									t.scores?.[r] !== void 0 && /* @__PURE__ */ _("b", {
										className: "qx-over-score",
										"aria-label": d("games.qwixx.overScore", { n: t.scores[r] }),
										children: t.scores[r]
									}),
									/* @__PURE__ */ _("button", {
										type: "button",
										className: "qx-over-select",
										"aria-label": d("games.qwixx.overSelect", { name: C(r) }),
										"aria-pressed": r === g,
										"aria-controls": D,
										onClick: () => h(r)
									})
								]
							}), /* @__PURE__ */ _("div", {
								className: "qx-over-thumbnail",
								children: /* @__PURE__ */ _($, {
									public: e,
									rid: r,
									myRid: i
								})
							})]
						}, r);
					})
				}), g && /* @__PURE__ */ v("section", {
					id: D,
					className: "qx-over-detail",
					"aria-label": d("games.qwixx.overSheet", { name: C(g) }),
					children: [/* @__PURE__ */ _("h2", {
						title: d("games.qwixx.overSheet", { name: C(g) }),
						children: d("games.qwixx.overSheet", { name: C(g) })
					}), /* @__PURE__ */ _("div", {
						ref: T,
						className: "qx-over-paper frame",
						children: /* @__PURE__ */ _("div", { children: /* @__PURE__ */ _(q, {
							sheet: e.sheets[g],
							lockedRows: e.lockedRows,
							readOnly: !0,
							fitKey: g + ":over:" + E
						}) })
					})]
				})]
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/qwixx/entry.tsx
var Ce = {
	definition: se,
	View: me,
	bot: ge,
	llm: ye,
	OverView: xe,
	RowView: $,
	locales: {
		zh: {
			name: "快可思",
			desc: "六骰齐掷全员抢画,四行数字越锁越快",
			rules: "目标:在四行数字上尽量多地画记,终局总分最高者获胜。\n流程:\n· 主动玩家掷 6 颗骰:2 颗白骰 + 红黄绿蓝各 1 颗;已锁行的色骰移出游戏。\n· 白骰阶段:所有人可自行把两颗白骰的点数和画进任一行;只能画在该行已画格的右侧,跳过的格子之后不能再画。\n· 色骰阶段:仅主动玩家可再画一记——任选一颗白骰与一颗色骰求和,画进该色对应的行。\n· 主动玩家整回合一记未画,记 1 格罚分(终局每格扣 5 分)。\n锁行:\n· 某行画满至少 5 格后,画记该行最右端数字(12 或 2)可同时画下锁格,该行对所有玩家关闭。\n结束:\n· 任一玩家画满 4 格罚分,或第 2 行被锁(累计两行关闭),对局立即结束。\n结算:\n· 每行按画记数查表得分(1 记 1 分,12 记 78 分;锁格也算 1 记),减去罚分;总分最高者胜,平分共同获胜。",
			overRanking: "本局名次",
			overSheet: "{{name}}的计分表",
			overSelect: "查看{{name}}的计分表",
			overScore: "得分 {{n}}",
			roll: "掷骰",
			rollPrompt: "轮到你:掷骰",
			waitingRoll: "等 {{name}} 掷骰…",
			whitePrompt: "白骰合计 {{n}}:点表上高亮格画记,或跳过",
			whiteNoSpot: "白骰合计 {{n}}:你无处可画,自动跳过",
			waitingWhite: "等其他人画记…",
			colorPrompt: "色骰阶段:点高亮格画记,或收回合",
			waitingColor: "等 {{name}} 画记…",
			skipWhite: "跳过(不画记)",
			endTurn: "收回合",
			passPenalty: "不画记,记 1 次罚分(−5)",
			penaltyAria: "罚分 {{n}} 格",
			whiteDieAria: "白骰 {{n}} 点",
			dieAria: {
				red: "红骰 {{n}} 点",
				yellow: "黄骰 {{n}} 点",
				green: "绿骰 {{n}} 点",
				blue: "蓝骰 {{n}} 点"
			},
			errOver: "本局已结束",
			errNotYourTurn: "现在轮不到你",
			errBadCell: "这格不能画",
			errBadStage: "现在不是这个阶段",
			errAlreadyDone: "这一阶段你已行动过"
		},
		en: {
			name: "Qwixx",
			desc: "Everyone plays on every roll — cross off numbers across four rows before they lock away",
			rules: "Goal: Mark as many numbers as you can in four rows; highest total wins.\nPlay:\n· The active player rolls 6 dice: 2 white plus one each of red, yellow, green, blue; dice of locked rows leave the game.\n· White phase: everyone may cross the sum of the two white dice in any one row; you may only mark to the right of your existing marks, and skipped cells are gone for good.\n· Color phase: only the active player may mark once more — add one white die to one colored die and mark that sum in the matching row.\n· If the active player marks nothing all turn, they take a penalty box (−5 each).\nLocking:\n· With at least 5 marks in a row, marking its rightmost number (12 or 2) also crosses the lock, closing that row for everyone.\nEnd:\n· The game ends immediately when anyone takes a 4th penalty or a 2nd row is locked.\nScoring:\n· Each row scores by its mark count (1 mark = 1 pt, 12 marks = 78; the lock counts as a mark), minus penalties; highest total wins, ties share the win.",
			overRanking: "Final ranking",
			overSheet: "{{name}}’s score sheet",
			overSelect: "View {{name}}’s score sheet",
			overScore: "Score {{n}}",
			roll: "Roll",
			rollPrompt: "Your turn: roll the dice",
			waitingRoll: "Waiting for {{name}} to roll…",
			whitePrompt: "White dice sum {{n}}: tap a highlighted cell to mark, or skip",
			whiteNoSpot: "White dice sum {{n}}: nowhere to mark — auto-skipped",
			waitingWhite: "Waiting for others to mark…",
			colorPrompt: "Color phase: tap a highlighted cell, or end your turn",
			waitingColor: "Waiting for {{name}} to mark…",
			skipWhite: "Skip (no mark)",
			endTurn: "End turn",
			passPenalty: "No mark — take a penalty (−5)",
			penaltyAria: "{{n}} penalties",
			whiteDieAria: "White die {{n}}",
			dieAria: {
				red: "Red die {{n}}",
				yellow: "Yellow die {{n}}",
				green: "Green die {{n}}",
				blue: "Blue die {{n}}"
			},
			errOver: "This game is over",
			errNotYourTurn: "Not your turn",
			errBadCell: "Cannot mark this cell",
			errBadStage: "Not in this phase",
			errAlreadyDone: "You already acted this phase"
		}
	}
};
//#endregion
export { Ce as default };
