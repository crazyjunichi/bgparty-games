import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { createPortal as o } from "react-dom";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconClose as l, IconHistory as u, IconRotate as d } from "@bgparty/sdk/icons";
import { useWakeLock as f } from "@bgparty/sdk/use-wake-lock";
import { useFxAnchor as p, useFxAnchorsMaybe as ee } from "@bgparty/sdk/fx/anchors";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { Floater as te, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/eternaldecks/card-data.ts
var x = {
	11200: {
		id: "11200",
		kind: "skull",
		colors: ["red"],
		value: 0,
		source: "gk1"
	},
	11201: {
		id: "11201",
		kind: "skull",
		colors: ["blue"],
		value: 0,
		source: "gk1"
	},
	11202: {
		id: "11202",
		kind: "skull",
		colors: ["green"],
		value: 0,
		source: "gk1"
	},
	11203: {
		id: "11203",
		kind: "skull",
		colors: ["yellow"],
		value: 0,
		source: "gk1"
	},
	11204: {
		id: "11204",
		kind: "ability",
		colors: [],
		value: 0,
		source: "gk1",
		effect: "jewel2"
	},
	11205: {
		id: "11205",
		kind: "ability",
		colors: [],
		value: 0,
		source: "gk1",
		effect: "shuffle"
	},
	11206: {
		id: "11206",
		kind: "ability",
		colors: [],
		value: 0,
		source: "gk1",
		effect: "observe"
	},
	11207: {
		id: "11207",
		kind: "ability",
		colors: [],
		value: 0,
		source: "gk1",
		effect: "observe"
	},
	11100: {
		id: "11100",
		kind: "number",
		colors: ["blue"],
		value: 1,
		source: "random"
	},
	11101: {
		id: "11101",
		kind: "number",
		colors: ["blue"],
		value: 2,
		source: "random"
	},
	11102: {
		id: "11102",
		kind: "number",
		colors: ["blue"],
		value: 3,
		source: "random"
	},
	11103: {
		id: "11103",
		kind: "number",
		colors: ["blue"],
		value: 4,
		source: "random"
	},
	11104: {
		id: "11104",
		kind: "number",
		colors: ["blue"],
		value: 5,
		source: "random"
	},
	11105: {
		id: "11105",
		kind: "number",
		colors: ["blue"],
		value: 6,
		source: "random"
	},
	11106: {
		id: "11106",
		kind: "number",
		colors: ["blue"],
		value: 7,
		source: "random"
	},
	11107: {
		id: "11107",
		kind: "number",
		colors: ["blue"],
		value: 8,
		source: "random"
	},
	11108: {
		id: "11108",
		kind: "number",
		colors: ["blue"],
		value: 9,
		source: "random"
	},
	11109: {
		id: "11109",
		kind: "wild",
		colors: [],
		value: 0,
		source: "random"
	},
	11110: {
		id: "11110",
		kind: "number",
		colors: ["green"],
		value: 1,
		source: "random"
	},
	11111: {
		id: "11111",
		kind: "number",
		colors: ["green"],
		value: 2,
		source: "random"
	},
	11112: {
		id: "11112",
		kind: "number",
		colors: ["green"],
		value: 3,
		source: "random"
	},
	11113: {
		id: "11113",
		kind: "number",
		colors: ["green"],
		value: 4,
		source: "random"
	},
	11114: {
		id: "11114",
		kind: "number",
		colors: ["green"],
		value: 5,
		source: "random"
	},
	11115: {
		id: "11115",
		kind: "number",
		colors: ["green"],
		value: 6,
		source: "random"
	},
	11116: {
		id: "11116",
		kind: "number",
		colors: ["green"],
		value: 7,
		source: "random"
	},
	11117: {
		id: "11117",
		kind: "number",
		colors: ["green"],
		value: 8,
		source: "random"
	},
	11118: {
		id: "11118",
		kind: "number",
		colors: ["green"],
		value: 9,
		source: "random"
	},
	11119: {
		id: "11119",
		kind: "wild",
		colors: [],
		value: 0,
		source: "random"
	},
	11120: {
		id: "11120",
		kind: "number",
		colors: ["red"],
		value: 1,
		source: "random"
	},
	11121: {
		id: "11121",
		kind: "number",
		colors: ["red"],
		value: 2,
		source: "random"
	},
	11122: {
		id: "11122",
		kind: "number",
		colors: ["red"],
		value: 3,
		source: "random"
	},
	11123: {
		id: "11123",
		kind: "number",
		colors: ["red"],
		value: 4,
		source: "random"
	},
	11124: {
		id: "11124",
		kind: "number",
		colors: ["red"],
		value: 5,
		source: "random"
	},
	11125: {
		id: "11125",
		kind: "number",
		colors: ["red"],
		value: 6,
		source: "random"
	},
	11126: {
		id: "11126",
		kind: "number",
		colors: ["red"],
		value: 7,
		source: "random"
	},
	11127: {
		id: "11127",
		kind: "number",
		colors: ["red"],
		value: 8,
		source: "random"
	},
	11128: {
		id: "11128",
		kind: "number",
		colors: ["red"],
		value: 9,
		source: "random"
	},
	11129: {
		id: "11129",
		kind: "wild",
		colors: [],
		value: 0,
		source: "random"
	},
	11130: {
		id: "11130",
		kind: "number",
		colors: ["yellow"],
		value: 1,
		source: "random"
	},
	11131: {
		id: "11131",
		kind: "number",
		colors: ["yellow"],
		value: 2,
		source: "random"
	},
	11132: {
		id: "11132",
		kind: "number",
		colors: ["yellow"],
		value: 3,
		source: "random"
	},
	11133: {
		id: "11133",
		kind: "number",
		colors: ["yellow"],
		value: 4,
		source: "random"
	},
	11134: {
		id: "11134",
		kind: "number",
		colors: ["yellow"],
		value: 5,
		source: "random"
	},
	11135: {
		id: "11135",
		kind: "number",
		colors: ["yellow"],
		value: 6,
		source: "random"
	},
	11136: {
		id: "11136",
		kind: "number",
		colors: ["yellow"],
		value: 7,
		source: "random"
	},
	11137: {
		id: "11137",
		kind: "number",
		colors: ["yellow"],
		value: 8,
		source: "random"
	},
	11138: {
		id: "11138",
		kind: "number",
		colors: ["yellow"],
		value: 9,
		source: "random"
	},
	11139: {
		id: "11139",
		kind: "wild",
		colors: [],
		value: 0,
		source: "random"
	},
	25260: {
		id: "25260",
		kind: "number",
		colors: ["purple"],
		value: 1,
		source: "skeleton"
	},
	25261: {
		id: "25261",
		kind: "number",
		colors: ["yellow"],
		value: 3,
		source: "skeleton"
	},
	25262: {
		id: "25262",
		kind: "number",
		colors: ["yellow"],
		value: 4,
		source: "skeleton"
	},
	25263: {
		id: "25263",
		kind: "number",
		colors: ["purple"],
		value: 4,
		source: "skeleton"
	},
	25264: {
		id: "25264",
		kind: "number",
		colors: ["purple"],
		value: 7,
		source: "skeleton"
	},
	25265: {
		id: "25265",
		kind: "number",
		colors: ["yellow"],
		value: 9,
		source: "skeleton"
	},
	25266: {
		id: "25266",
		kind: "wild",
		colors: [],
		value: 0,
		source: "skeleton"
	},
	25267: {
		id: "25267",
		kind: "ability",
		colors: [],
		value: 0,
		source: "skeleton",
		effect: "skeleton"
	},
	11008: {
		id: "11008",
		kind: "skull",
		colors: ["red"],
		value: 0,
		source: "gk2"
	},
	11009: {
		id: "11009",
		kind: "skull",
		colors: ["blue"],
		value: 0,
		source: "gk2"
	},
	11010: {
		id: "11010",
		kind: "skull",
		colors: ["green"],
		value: 0,
		source: "gk2"
	},
	11011: {
		id: "11011",
		kind: "skull",
		colors: ["yellow"],
		value: 0,
		source: "gk2"
	},
	11012: {
		id: "11012",
		kind: "skull",
		colors: ["purple"],
		value: 0,
		source: "gk2"
	},
	11013: {
		id: "11013",
		kind: "skull",
		colors: ["purple"],
		value: 0,
		source: "gk2"
	},
	11014: {
		id: "11014",
		kind: "ability",
		colors: [],
		value: 0,
		source: "gk2",
		effect: "jewel3"
	},
	11015: {
		id: "11015",
		kind: "ability",
		colors: [],
		value: 0,
		source: "gk2",
		effect: "shuffle"
	},
	24940: {
		id: "24940",
		kind: "number",
		colors: ["blue"],
		value: 1,
		source: "mermaid"
	},
	24941: {
		id: "24941",
		kind: "number",
		colors: ["green"],
		value: 2,
		source: "mermaid"
	},
	24942: {
		id: "24942",
		kind: "number",
		colors: ["blue"],
		value: 5,
		source: "mermaid"
	},
	24943: {
		id: "24943",
		kind: "number",
		colors: ["red"],
		value: 5,
		source: "mermaid"
	},
	24944: {
		id: "24944",
		kind: "number",
		colors: ["blue"],
		value: 6,
		source: "mermaid"
	},
	24945: {
		id: "24945",
		kind: "number",
		colors: ["blue"],
		value: 7,
		source: "mermaid"
	},
	24946: {
		id: "24946",
		kind: "number",
		colors: ["blue"],
		value: 7,
		source: "mermaid"
	},
	24947: {
		id: "24947",
		kind: "ability",
		colors: [],
		value: 0,
		source: "mermaid",
		effect: "mermaid"
	},
	25950: {
		id: "25950",
		kind: "number",
		colors: ["green"],
		value: 3,
		source: "phoenix"
	},
	25951: {
		id: "25951",
		kind: "number",
		colors: ["red"],
		value: 6,
		source: "phoenix"
	},
	25952: {
		id: "25952",
		kind: "number",
		colors: ["yellow"],
		value: 6,
		source: "phoenix"
	},
	25953: {
		id: "25953",
		kind: "number",
		colors: ["red"],
		value: 7,
		source: "phoenix"
	},
	25954: {
		id: "25954",
		kind: "number",
		colors: ["red"],
		value: 8,
		source: "phoenix"
	},
	25955: {
		id: "25955",
		kind: "number",
		colors: ["red"],
		value: 8,
		source: "phoenix"
	},
	25956: {
		id: "25956",
		kind: "number",
		colors: ["red"],
		value: 9,
		source: "phoenix"
	},
	25957: {
		id: "25957",
		kind: "ability",
		colors: [],
		value: 0,
		source: "phoenix",
		effect: "phoenix"
	},
	26120: {
		id: "26120",
		kind: "number",
		colors: ["red", "green"],
		value: 1,
		source: "mummy"
	},
	26121: {
		id: "26121",
		kind: "number",
		colors: ["blue"],
		value: 1,
		source: "mummy"
	},
	26122: {
		id: "26122",
		kind: "number",
		colors: ["red", "green"],
		value: 3,
		source: "mummy"
	},
	26123: {
		id: "26123",
		kind: "number",
		colors: ["blue"],
		value: 5,
		source: "mummy"
	},
	26124: {
		id: "26124",
		kind: "number",
		colors: ["red", "green"],
		value: 6,
		source: "mummy"
	},
	26125: {
		id: "26125",
		kind: "number",
		colors: ["red", "green"],
		value: 7,
		source: "mummy"
	},
	26126: {
		id: "26126",
		kind: "number",
		colors: ["red", "green"],
		value: 8,
		source: "mummy"
	},
	26127: {
		id: "26127",
		kind: "ability",
		colors: [],
		value: 0,
		source: "mummy",
		effect: "mummy"
	},
	25300: {
		id: "25300",
		kind: "number",
		colors: ["blue"],
		value: 2,
		source: "witch"
	},
	25301: {
		id: "25301",
		kind: "number",
		colors: ["purple"],
		value: 3,
		source: "witch"
	},
	25302: {
		id: "25302",
		kind: "number",
		colors: ["blue"],
		value: 4,
		source: "witch"
	},
	25303: {
		id: "25303",
		kind: "number",
		colors: ["purple"],
		value: 5,
		source: "witch"
	},
	25304: {
		id: "25304",
		kind: "number",
		colors: ["purple"],
		value: 6,
		source: "witch"
	},
	25305: {
		id: "25305",
		kind: "number",
		colors: ["blue"],
		value: 7,
		source: "witch"
	},
	25306: {
		id: "25306",
		kind: "number",
		colors: ["purple"],
		value: 8,
		source: "witch"
	},
	25307: {
		id: "25307",
		kind: "ability",
		colors: [],
		value: 0,
		source: "witch",
		effect: "witch"
	},
	1015: {
		id: "1015",
		kind: "number",
		colors: ["green"],
		value: 1,
		source: "greenstart"
	},
	1016: {
		id: "1016",
		kind: "number",
		colors: ["green"],
		value: 2,
		source: "greenstart"
	},
	1017: {
		id: "1017",
		kind: "number",
		colors: ["green"],
		value: 3,
		source: "greenstart"
	},
	1018: {
		id: "1018",
		kind: "number",
		colors: ["green"],
		value: 4,
		source: "greenstart"
	},
	1019: {
		id: "1019",
		kind: "number",
		colors: ["green"],
		value: 5,
		source: "greenstart"
	},
	25630: {
		id: "25630",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 1,
		source: "medusa"
	},
	25631: {
		id: "25631",
		kind: "number",
		colors: ["green"],
		value: 2,
		source: "medusa"
	},
	25632: {
		id: "25632",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 3,
		source: "medusa"
	},
	25633: {
		id: "25633",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 4,
		source: "medusa"
	},
	25634: {
		id: "25634",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 6,
		source: "medusa"
	},
	25635: {
		id: "25635",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 8,
		source: "medusa"
	},
	25636: {
		id: "25636",
		kind: "number",
		colors: ["green"],
		value: 8,
		source: "medusa"
	},
	25637: {
		id: "25637",
		kind: "ability",
		colors: [],
		value: 0,
		source: "medusa",
		effect: "medusa"
	},
	1e3: {
		id: "1000",
		kind: "number",
		colors: ["purple"],
		value: 1,
		source: "gkp"
	},
	1001: {
		id: "1001",
		kind: "number",
		colors: ["purple"],
		value: 2,
		source: "gkp"
	},
	1002: {
		id: "1002",
		kind: "number",
		colors: ["purple"],
		value: 3,
		source: "gkp"
	},
	1003: {
		id: "1003",
		kind: "number",
		colors: ["purple"],
		value: 4,
		source: "gkp"
	},
	1004: {
		id: "1004",
		kind: "number",
		colors: ["purple"],
		value: 5,
		source: "gkp"
	},
	25410: {
		id: "25410",
		kind: "number",
		colors: ["yellow"],
		value: 1,
		source: "king"
	},
	25411: {
		id: "25411",
		kind: "number",
		colors: ["red"],
		value: 3,
		source: "king"
	},
	25412: {
		id: "25412",
		kind: "number",
		colors: ["green"],
		value: 4,
		source: "king"
	},
	25413: {
		id: "25413",
		kind: "number",
		colors: ["yellow"],
		value: 5,
		source: "king"
	},
	25414: {
		id: "25414",
		kind: "number",
		colors: ["yellow"],
		value: 8,
		source: "king"
	},
	25415: {
		id: "25415",
		kind: "number",
		colors: ["yellow"],
		value: 9,
		source: "king"
	},
	25416: {
		id: "25416",
		kind: "number",
		colors: ["yellow"],
		value: 9,
		source: "king"
	},
	25417: {
		id: "25417",
		kind: "ability",
		colors: [],
		value: 0,
		source: "king",
		effect: "king"
	},
	25020: {
		id: "25020",
		kind: "number",
		colors: ["red"],
		value: 1,
		source: "minotaur"
	},
	25021: {
		id: "25021",
		kind: "number",
		colors: ["red", "green"],
		value: 2,
		source: "minotaur"
	},
	25022: {
		id: "25022",
		kind: "number",
		colors: ["red"],
		value: 4,
		source: "minotaur"
	},
	25023: {
		id: "25023",
		kind: "number",
		colors: ["red", "green"],
		value: 4,
		source: "minotaur"
	},
	25024: {
		id: "25024",
		kind: "number",
		colors: ["red", "green"],
		value: 5,
		source: "minotaur"
	},
	25025: {
		id: "25025",
		kind: "number",
		colors: ["red"],
		value: 9,
		source: "minotaur"
	},
	25026: {
		id: "25026",
		kind: "number",
		colors: ["red", "green"],
		value: 9,
		source: "minotaur"
	},
	25027: {
		id: "25027",
		kind: "ability",
		colors: [],
		value: 0,
		source: "minotaur",
		effect: "minotaur"
	},
	24640: {
		id: "24640",
		kind: "skull",
		colors: ["blue"],
		value: 0,
		source: "barong"
	},
	24641: {
		id: "24641",
		kind: "skull",
		colors: ["blue"],
		value: 0,
		source: "barong"
	},
	24642: {
		id: "24642",
		kind: "skull",
		colors: ["blue"],
		value: 0,
		source: "barong"
	},
	24643: {
		id: "24643",
		kind: "number",
		colors: ["blue"],
		value: 2,
		source: "barong"
	},
	24644: {
		id: "24644",
		kind: "number",
		colors: ["green"],
		value: 2,
		source: "barong"
	},
	24645: {
		id: "24645",
		kind: "number",
		colors: ["green"],
		value: 3,
		source: "barong"
	},
	24646: {
		id: "24646",
		kind: "number",
		colors: ["yellow"],
		value: 8,
		source: "barong"
	},
	24647: {
		id: "24647",
		kind: "number",
		colors: ["yellow"],
		value: 9,
		source: "barong"
	},
	25730: {
		id: "25730",
		kind: "number",
		colors: ["red"],
		value: 1,
		source: "vampire"
	},
	25731: {
		id: "25731",
		kind: "number",
		colors: ["blue"],
		value: 3,
		source: "vampire"
	},
	25732: {
		id: "25732",
		kind: "number",
		colors: ["green"],
		value: 3,
		source: "vampire"
	},
	25733: {
		id: "25733",
		kind: "number",
		colors: ["yellow"],
		value: 3,
		source: "vampire"
	},
	25734: {
		id: "25734",
		kind: "number",
		colors: ["red"],
		value: 5,
		source: "vampire"
	},
	25735: {
		id: "25735",
		kind: "number",
		colors: ["red"],
		value: 8,
		source: "vampire"
	},
	25736: {
		id: "25736",
		kind: "wild",
		colors: [],
		value: 0,
		source: "vampire"
	},
	25737: {
		id: "25737",
		kind: "wild",
		colors: [],
		value: 0,
		source: "vampire"
	},
	1010: {
		id: "1010",
		kind: "number",
		colors: ["yellow"],
		value: 1,
		source: "yellowstart"
	},
	1011: {
		id: "1011",
		kind: "number",
		colors: ["yellow"],
		value: 2,
		source: "yellowstart"
	},
	1012: {
		id: "1012",
		kind: "number",
		colors: ["yellow"],
		value: 3,
		source: "yellowstart"
	},
	1013: {
		id: "1013",
		kind: "number",
		colors: ["yellow"],
		value: 4,
		source: "yellowstart"
	},
	1014: {
		id: "1014",
		kind: "number",
		colors: ["yellow"],
		value: 5,
		source: "yellowstart"
	},
	23100: {
		id: "23100",
		kind: "number",
		colors: ["purple"],
		value: 9,
		source: "purple"
	},
	23101: {
		id: "23101",
		kind: "number",
		colors: ["purple"],
		value: 1,
		source: "purple"
	},
	23102: {
		id: "23102",
		kind: "number",
		colors: ["purple"],
		value: 2,
		source: "purple"
	},
	23103: {
		id: "23103",
		kind: "number",
		colors: ["purple"],
		value: 3,
		source: "purple"
	},
	23104: {
		id: "23104",
		kind: "number",
		colors: ["purple"],
		value: 5,
		source: "purple"
	},
	23105: {
		id: "23105",
		kind: "number",
		colors: ["purple"],
		value: 6,
		source: "purple"
	},
	23106: {
		id: "23106",
		kind: "number",
		colors: ["purple"],
		value: 4,
		source: "purple"
	},
	23107: {
		id: "23107",
		kind: "number",
		colors: ["purple"],
		value: 7,
		source: "purple"
	},
	23108: {
		id: "23108",
		kind: "number",
		colors: ["purple"],
		value: 8,
		source: "purple"
	},
	1005: {
		id: "1005",
		kind: "number",
		colors: ["red"],
		value: 1,
		source: "redstart"
	},
	1006: {
		id: "1006",
		kind: "number",
		colors: ["red"],
		value: 2,
		source: "redstart"
	},
	1007: {
		id: "1007",
		kind: "number",
		colors: ["red"],
		value: 3,
		source: "redstart"
	},
	1008: {
		id: "1008",
		kind: "number",
		colors: ["red"],
		value: 4,
		source: "redstart"
	},
	1009: {
		id: "1009",
		kind: "number",
		colors: ["red"],
		value: 5,
		source: "redstart"
	},
	25500: {
		id: "25500",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 2,
		source: "kraken"
	},
	25501: {
		id: "25501",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 4,
		source: "kraken"
	},
	25502: {
		id: "25502",
		kind: "number",
		colors: ["yellow"],
		value: 5,
		source: "kraken"
	},
	25503: {
		id: "25503",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 5,
		source: "kraken"
	},
	25504: {
		id: "25504",
		kind: "number",
		colors: ["yellow"],
		value: 7,
		source: "kraken"
	},
	25505: {
		id: "25505",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 7,
		source: "kraken"
	},
	25506: {
		id: "25506",
		kind: "number",
		colors: ["blue", "yellow"],
		value: 9,
		source: "kraken"
	},
	25507: {
		id: "25507",
		kind: "ability",
		colors: [],
		value: 0,
		source: "kraken",
		effect: "kraken"
	},
	24710: {
		id: "24710",
		kind: "skull",
		colors: ["red"],
		value: 0,
		source: "pegasus"
	},
	24711: {
		id: "24711",
		kind: "skull",
		colors: ["red"],
		value: 0,
		source: "pegasus"
	},
	24712: {
		id: "24712",
		kind: "skull",
		colors: ["red"],
		value: 0,
		source: "pegasus"
	},
	24713: {
		id: "24713",
		kind: "number",
		colors: ["red"],
		value: 1,
		source: "pegasus"
	},
	24714: {
		id: "24714",
		kind: "number",
		colors: ["blue"],
		value: 3,
		source: "pegasus"
	},
	24715: {
		id: "24715",
		kind: "number",
		colors: ["blue"],
		value: 6,
		source: "pegasus"
	},
	24716: {
		id: "24716",
		kind: "number",
		colors: ["green"],
		value: 6,
		source: "pegasus"
	},
	24717: {
		id: "24717",
		kind: "number",
		colors: ["green"],
		value: 9,
		source: "pegasus"
	},
	1020: {
		id: "1020",
		kind: "number",
		colors: ["blue"],
		value: 1,
		source: "bluestart"
	},
	1021: {
		id: "1021",
		kind: "number",
		colors: ["blue"],
		value: 2,
		source: "bluestart"
	},
	1022: {
		id: "1022",
		kind: "number",
		colors: ["blue"],
		value: 3,
		source: "bluestart"
	},
	1023: {
		id: "1023",
		kind: "number",
		colors: ["blue"],
		value: 4,
		source: "bluestart"
	},
	1024: {
		id: "1024",
		kind: "number",
		colors: ["blue"],
		value: 5,
		source: "bluestart"
	},
	25150: {
		id: "25150",
		kind: "skull",
		colors: ["green"],
		value: 0,
		source: "jinn"
	},
	25151: {
		id: "25151",
		kind: "skull",
		colors: ["green"],
		value: 0,
		source: "jinn"
	},
	25152: {
		id: "25152",
		kind: "skull",
		colors: ["green"],
		value: 0,
		source: "jinn"
	},
	25153: {
		id: "25153",
		kind: "number",
		colors: ["green"],
		value: 4,
		source: "jinn"
	},
	25154: {
		id: "25154",
		kind: "number",
		colors: ["red"],
		value: 4,
		source: "jinn"
	},
	25155: {
		id: "25155",
		kind: "number",
		colors: ["red"],
		value: 5,
		source: "jinn"
	},
	25156: {
		id: "25156",
		kind: "number",
		colors: ["yellow"],
		value: 6,
		source: "jinn"
	},
	25157: {
		id: "25157",
		kind: "number",
		colors: ["yellow"],
		value: 7,
		source: "jinn"
	},
	25808: {
		id: "25808",
		kind: "number",
		colors: ["green"],
		value: 1,
		source: "fairy"
	},
	25809: {
		id: "25809",
		kind: "number",
		colors: ["green"],
		value: 1,
		source: "fairy"
	},
	25818: {
		id: "25818",
		kind: "number",
		colors: ["blue"],
		value: 2,
		source: "fairy"
	},
	25819: {
		id: "25819",
		kind: "number",
		colors: ["yellow"],
		value: 3,
		source: "fairy"
	},
	25828: {
		id: "25828",
		kind: "number",
		colors: ["green"],
		value: 6,
		source: "fairy"
	},
	25829: {
		id: "25829",
		kind: "number",
		colors: ["green"],
		value: 7,
		source: "fairy"
	},
	25838: {
		id: "25838",
		kind: "number",
		colors: ["green"],
		value: 8,
		source: "fairy"
	},
	25839: {
		id: "25839",
		kind: "ability",
		colors: [],
		value: 0,
		source: "fairy",
		effect: "fairy"
	},
	24808: {
		id: "24808",
		kind: "number",
		colors: ["green"],
		value: 2,
		source: "ghost"
	},
	24809: {
		id: "24809",
		kind: "number",
		colors: ["purple"],
		value: 2,
		source: "ghost"
	},
	24818: {
		id: "24818",
		kind: "number",
		colors: ["purple"],
		value: 3,
		source: "ghost"
	},
	24819: {
		id: "24819",
		kind: "number",
		colors: ["green"],
		value: 6,
		source: "ghost"
	},
	24828: {
		id: "24828",
		kind: "number",
		colors: ["green"],
		value: 8,
		source: "ghost"
	},
	24829: {
		id: "24829",
		kind: "number",
		colors: ["purple"],
		value: 9,
		source: "ghost"
	},
	24838: {
		id: "24838",
		kind: "wild",
		colors: [],
		value: 0,
		source: "ghost"
	},
	24839: {
		id: "24839",
		kind: "ability",
		colors: [],
		value: 0,
		source: "ghost",
		effect: "ghost"
	},
	26060: {
		id: "26060",
		kind: "skull",
		colors: ["yellow"],
		value: 0,
		source: "kyubi"
	},
	26061: {
		id: "26061",
		kind: "skull",
		colors: ["yellow"],
		value: 0,
		source: "kyubi"
	},
	26062: {
		id: "26062",
		kind: "skull",
		colors: ["yellow"],
		value: 0,
		source: "kyubi"
	},
	26063: {
		id: "26063",
		kind: "number",
		colors: ["yellow"],
		value: 3,
		source: "kyubi"
	},
	26064: {
		id: "26064",
		kind: "number",
		colors: ["blue"],
		value: 3,
		source: "kyubi"
	},
	26065: {
		id: "26065",
		kind: "number",
		colors: ["blue"],
		value: 5,
		source: "kyubi"
	},
	26066: {
		id: "26066",
		kind: "number",
		colors: ["red"],
		value: 6,
		source: "kyubi"
	},
	26067: {
		id: "26067",
		kind: "number",
		colors: ["red"],
		value: 9,
		source: "kyubi"
	},
	river0: {
		id: "river0",
		kind: "wild",
		colors: [],
		value: 0,
		source: "river"
	},
	river1: {
		id: "river1",
		kind: "wild",
		colors: [],
		value: 0,
		source: "river"
	},
	river2: {
		id: "river2",
		kind: "wild",
		colors: [],
		value: 0,
		source: "river"
	},
	river3: {
		id: "river3",
		kind: "wild",
		colors: [],
		value: 0,
		source: "river"
	},
	white0: {
		id: "white0",
		kind: "skull",
		colors: ["white"],
		value: 0,
		source: "white"
	},
	white1: {
		id: "white1",
		kind: "skull",
		colors: ["white"],
		value: 0,
		source: "white"
	},
	white2: {
		id: "white2",
		kind: "skull",
		colors: ["white"],
		value: 0,
		source: "white"
	},
	white3: {
		id: "white3",
		kind: "skull",
		colors: ["white"],
		value: 0,
		source: "white"
	},
	permanent: {
		id: "permanent",
		kind: "wild",
		colors: [],
		value: 0,
		source: "bonus"
	},
	camp: {
		id: "camp",
		kind: "camp",
		colors: [],
		value: 0,
		source: "bonus"
	},
	heartBonus: {
		id: "heartBonus",
		kind: "ability",
		colors: [],
		value: 0,
		source: "bonus",
		effect: "recoverAll"
	},
	cat: {
		id: "cat",
		kind: "ability",
		colors: [],
		value: 0,
		source: "bonus",
		effect: "witch"
	}
}, S = {
	gk1: [
		"11200",
		"11201",
		"11202",
		"11203",
		"11204",
		"11205",
		"11206",
		"11207"
	],
	random: /* @__PURE__ */ "11100.11101.11102.11103.11104.11105.11106.11107.11108.11109.11110.11111.11112.11113.11114.11115.11116.11117.11118.11119.11120.11121.11122.11123.11124.11125.11126.11127.11128.11129.11130.11131.11132.11133.11134.11135.11136.11137.11138.11139".split("."),
	skeleton: [
		"25260",
		"25261",
		"25262",
		"25263",
		"25264",
		"25265",
		"25266",
		"25267"
	],
	gk2: [
		"11008",
		"11009",
		"11010",
		"11011",
		"11012",
		"11013",
		"11014",
		"11015"
	],
	mermaid: [
		"24940",
		"24941",
		"24942",
		"24943",
		"24944",
		"24945",
		"24946",
		"24947"
	],
	phoenix: [
		"25950",
		"25951",
		"25952",
		"25953",
		"25954",
		"25955",
		"25956",
		"25957"
	],
	mummy: [
		"26120",
		"26121",
		"26122",
		"26123",
		"26124",
		"26125",
		"26126",
		"26127"
	],
	witch: [
		"25300",
		"25301",
		"25302",
		"25303",
		"25304",
		"25305",
		"25306",
		"25307"
	],
	greenstart: [
		"1015",
		"1016",
		"1017",
		"1018",
		"1019"
	],
	medusa: [
		"25630",
		"25631",
		"25632",
		"25633",
		"25634",
		"25635",
		"25636",
		"25637"
	],
	gkp: [
		"1000",
		"1001",
		"1002",
		"1003",
		"1004"
	],
	king: [
		"25410",
		"25411",
		"25412",
		"25413",
		"25414",
		"25415",
		"25416",
		"25417"
	],
	minotaur: [
		"25020",
		"25021",
		"25022",
		"25023",
		"25024",
		"25025",
		"25026",
		"25027"
	],
	barong: [
		"24640",
		"24641",
		"24642",
		"24643",
		"24644",
		"24645",
		"24646",
		"24647"
	],
	vampire: [
		"25730",
		"25731",
		"25732",
		"25733",
		"25734",
		"25735",
		"25736",
		"25737"
	],
	yellowstart: [
		"1010",
		"1011",
		"1012",
		"1013",
		"1014"
	],
	purple: [
		"23100",
		"23101",
		"23102",
		"23103",
		"23104",
		"23105",
		"23106",
		"23107",
		"23108"
	],
	redstart: [
		"1005",
		"1006",
		"1007",
		"1008",
		"1009"
	],
	kraken: [
		"25500",
		"25501",
		"25502",
		"25503",
		"25504",
		"25505",
		"25506",
		"25507"
	],
	pegasus: [
		"24710",
		"24711",
		"24712",
		"24713",
		"24714",
		"24715",
		"24716",
		"24717"
	],
	bluestart: [
		"1020",
		"1021",
		"1022",
		"1023",
		"1024"
	],
	jinn: [
		"25150",
		"25151",
		"25152",
		"25153",
		"25154",
		"25155",
		"25156",
		"25157"
	],
	fairy: [
		"25808",
		"25809",
		"25818",
		"25819",
		"25828",
		"25829",
		"25838",
		"25839"
	],
	ghost: [
		"24808",
		"24809",
		"24818",
		"24819",
		"24828",
		"24829",
		"24838",
		"24839"
	],
	kyubi: [
		"26060",
		"26061",
		"26062",
		"26063",
		"26064",
		"26065",
		"26066",
		"26067"
	]
}, C = [
	"red",
	"blue",
	"green",
	"yellow"
], w = {
	A: [
		"phoenix",
		"mermaid",
		"king",
		"fairy"
	],
	B: [
		"ghost",
		"skeleton",
		"witch",
		"vampire"
	],
	C: [
		"medusa",
		"minotaur",
		"kraken",
		"mummy"
	],
	D: [
		"pegasus",
		"barong",
		"jinn",
		"kyubi"
	],
	E: [
		"kappa",
		"cyclops",
		"yeti",
		"golem"
	]
}, ne = {
	red: "pegasus",
	blue: "barong",
	green: "jinn",
	yellow: "kyubi"
}, T = [
	"forest",
	"lake",
	"grassland",
	"riverside"
], re = [
	"cave",
	...T,
	"valley",
	"desert",
	"swamp"
], ie = [
	"castle",
	"lostForest",
	"fog",
	"festival"
], E = [
	"any2",
	"any3",
	"color3",
	"different3",
	"edge",
	"number2",
	"number3",
	"159"
], D = [
	"edge",
	"number2",
	"color3",
	"different3",
	"number3",
	"159"
], O = [
	"different3",
	"number3",
	"159",
	"riverColors",
	"riverFive",
	"riverRB",
	"riverGY"
], k = {
	phoenix: [1],
	mermaid: [4],
	king: [6],
	fairy: [9],
	ghost: [5, 7],
	skeleton: [2, 8]
}, A = {
	vampire: ["purple"],
	medusa: ["red"],
	minotaur: ["blue"],
	kraken: ["green"],
	mummy: ["yellow"]
}, ae = (e) => x[e], j = (e) => ae(e).kind === "wild", M = (e) => j(e) ? [...C, "purple"] : ae(e).colors, oe = (e) => Object.keys(w).find((t) => w[t].includes(e)) ?? "B", se = [
	{
		id: "star0",
		kind: "star"
	},
	{
		id: "star1",
		kind: "star"
	},
	{
		id: "jewel0",
		kind: "jewel"
	},
	{
		id: "jewel1",
		kind: "jewel"
	},
	{
		id: "lateJewel",
		kind: "lateJewel"
	},
	{
		id: "column",
		kind: "column"
	},
	{
		id: "rareHand",
		kind: "rareHand"
	},
	{
		id: "rarePair",
		kind: "rarePair"
	}
], N = (e, t) => ({
	level: e,
	width: Math.max(...t.map((e) => e.length)),
	height: t.length,
	cells: t.flatMap((e, t) => [...e].flatMap((e, n) => e === "." ? [] : [{
		row: t,
		column: n,
		color: {
			R: "red",
			B: "blue",
			G: "green",
			Y: "yellow",
			P: "purple"
		}[e]
	}]))
}), ce = [
	...[
		"R",
		"B",
		"G",
		"Y"
	].map((e) => N(1, [
		e,
		e,
		e
	])),
	N(2, ["G.", "PR"]),
	N(2, ["Y.", "PB"]),
	N(2, ["R.", "PG"]),
	N(2, ["B.", "PY"]),
	N(3, ["RG", "GR"]),
	N(3, ["BR", "RB"]),
	N(3, ["YB", "BY"]),
	N(3, ["GY", "YG"]),
	N(4, [
		"B.P",
		".G.",
		"P.Y"
	]),
	N(4, [
		"PRP",
		"..R",
		"..P"
	]),
	N(4, [
		".YG",
		"B.B",
		"RY."
	]),
	N(4, [
		"Y.B",
		"GPG",
		".R."
	])
], P = [
	{
		id: "draw2",
		seat: 0,
		cost: 1,
		parent: ""
	},
	{
		id: "drawRandom",
		seat: 0,
		cost: 2,
		parent: "draw2"
	},
	{
		id: "give",
		seat: 0,
		cost: 1,
		parent: ""
	},
	{
		id: "ignore",
		seat: 0,
		cost: 1,
		parent: ""
	},
	{
		id: "storeOther",
		seat: 0,
		cost: 1,
		parent: ""
	},
	{
		id: "draw2",
		seat: 1,
		cost: 1,
		parent: ""
	},
	{
		id: "giveAll",
		seat: 1,
		cost: 1,
		parent: ""
	},
	{
		id: "ignore",
		seat: 1,
		cost: 1,
		parent: ""
	},
	{
		id: "river",
		seat: 1,
		cost: 2,
		parent: "ignore"
	},
	{
		id: "giveDisc",
		seat: 1,
		cost: 2,
		parent: ""
	},
	{
		id: "drawRandom",
		seat: 2,
		cost: 1,
		parent: ""
	},
	{
		id: "give",
		seat: 2,
		cost: 2,
		parent: ""
	},
	{
		id: "remove",
		seat: 2,
		cost: 1,
		parent: ""
	},
	{
		id: "wild",
		seat: 2,
		cost: 2,
		parent: ""
	}
], le = [
	[
		"redColor",
		"redNumber",
		"fourJewels"
	],
	[
		"greenGive",
		"blueCards",
		"blueDisc"
	],
	[
		"yellowIgnore",
		"refill4",
		"chooseEternals"
	]
];
//#endregion
//#region src/games/eternaldecks/campaign.ts
function F() {
	return {
		chapter: 0,
		failures: [
			0,
			0,
			0,
			0,
			0
		],
		scores: [],
		points: 0,
		upgrades: [
			[],
			[],
			[]
		],
		modifications: [
			[],
			[],
			[]
		],
		stored: [
			[],
			[],
			[]
		],
		storedThisStage: [
			!1,
			!1,
			!1
		],
		storeActions: [
			!1,
			!1,
			!1
		],
		jewels: [
			!1,
			!1,
			!1
		],
		catUsed: !1,
		catFound: !1,
		chapterWon: !1,
		stagePointsUnspent: 0
	};
}
function ue(e, t, n, r) {
	let i = e.campaign;
	return !i || i.storeActions[t] || i.storedThisStage[r] || !["number", "wild"].includes(x[n].kind) || r !== t && !(t === 0 && i.upgrades[0].includes("storeOther")) ? !1 : j(n) || i.stored[r].every((e) => j(e.card) || x[e.card].value === x[n].value);
}
function de(e) {
	let t = e.campaign;
	if (!t || ![
		"act",
		"after",
		"chapter"
	].includes(e.phase)) return [];
	let n = [];
	for (let e of P) t.points >= e.cost && !t.upgrades[e.seat].includes(e.id) && (!e.parent || t.upgrades[e.seat].includes(e.parent)) && n.push({
		type: "buy",
		seat: e.seat,
		upgrade: e.id
	});
	return t.modifications.forEach((e, r) => {
		let i = t.stored[r].filter((e) => e.chapter < 2).length;
		e.length < Math.min(2, i) && le[r].forEach((t, i) => {
			e.includes(i) || n.push({
				type: "modify",
				seat: r,
				modification: i
			});
		});
	}), n;
}
function fe(e, t) {
	let n = e.campaign;
	if (t.type === "modify") n.modifications[t.seat].push(t.modification);
	else {
		let e = P.find((e) => e.seat === t.seat && e.id === t.upgrade);
		n.points -= e.cost, n.stagePointsUnspent = Math.max(0, n.stagePointsUnspent - e.cost), n.upgrades[t.seat].push(t.upgrade);
	}
}
function pe(e) {
	let t = e.seats.flatMap((e) => e.hand).concat(e.river).filter(j).length;
	return Math.max(0, Math.min(4, e.stars.length) + Math.min(2, e.hearts) + Math.min(2, t) - e.campaign.failures[e.campaign.chapter]);
}
function me(e) {
	let t = e.stored.flatMap((e) => e.map((e) => j(e.card) && e.chapter === 2 ? 5 : j(e.card) && e.chapter === 3 ? 4 : 2)).reduce((e, t) => e + t, 0);
	return e.scores.reduce((e, t) => e + t, 0) + t + Math.min(15, e.points);
}
function he(e, t) {
	let n = e.campaign;
	t ? (n.scores[n.chapter] = pe(e), n.chapterWon = !0) : (n.failures[n.chapter] += 1, n.points -= n.stagePointsUnspent, n.stagePointsUnspent = 0, n.chapterWon = !1, n.failures[n.chapter] >= 2 && (n.scores[n.chapter] = 0)), e.phase = n.chapter === 4 && (t || n.failures[4] >= 2) ? t ? "won" : "lost" : "chapter";
}
//#endregion
//#region src/games/eternaldecks/placements.ts
function ge(e, t) {
	return [
		...e.revived,
		...e.holding ? [e.holding] : [],
		...e.seats[t].personal
	].filter((t) => e.eternals[t]?.jewel === null);
}
function I(e, t, n) {
	return e.seats[t].power === n || ge(e, t).includes(n);
}
function L(e) {
	return 7 - e.eternals.length;
}
function _e(e) {
	return e.cards.some((e) => x[e.card].kind === "camp") ? "camp" : e.fields[0];
}
function ve(e) {
	return !e.closed && e.cards.length === L(e) && e.cards.every((e) => x[e.card].kind !== "skull");
}
var R = (e) => e.wild || j(e.card) || x[e.card].kind === "camp" || x[e.card].effect === "minotaur";
function ye(e, t) {
	if (R(e)) return null;
	let n = x[e.card].colors;
	return n.length === 0 ? null : n.length === 1 ? n[0] : n[+(t === "left" === e.flip)];
}
function be(e, t, n) {
	return !!(e.campaign?.modifications[t].includes(0) && t === 2 && x[n].colors.length === 1 && x[n].colors[0] === "yellow");
}
function xe(e, t, n, r) {
	if (r || be(e, t, n)) return !0;
	let i = x[n];
	return ge(e, t).every((e) => i.kind === "wild" ? e !== "witch" : !(k[e]?.includes(i.value) || A[e]?.some((e) => i.colors.includes(e))));
}
function Se(e, t, n, r) {
	let i = _e(e);
	if (i === "castle" || i === "lostForest") return C.some((e) => t.every((t) => R(t) || M(t.card).some((t) => t === e || t === "purple")));
	if ((i === "lake" || i === "swamp") && !C.some((e, n) => t.every((e, t) => R(e) || M(e.card).some((e) => e === "purple" || e === C[(n + t) % 4])))) return !1;
	for (let i = 1; i < t.length; i += 1) {
		if (i !== r && i !== r + 1) continue;
		let a = ye(t[i - 1], "right");
		if (a === null || a === "white" || a !== ye(t[i], "left")) continue;
		let o = e.cards[i - 1], s = e.cards[i];
		if (!(o && s && ye(o, "right") === a && ye(s, "left") === a) && (!n || i >= 2 && ye(t[i - 2], "right") === a && ye(t[i - 1], "left") === a)) return !1;
	}
	return !0;
}
function Ce(e, t, n, r) {
	let i = _e(e), a = t.length;
	for (; a && x[t[a - 1].card].kind === "skull";) --a;
	let o = t.slice(0, a);
	for (let t = 1; t < o.length; t += 1) {
		if (t !== r && t !== r + 1) continue;
		let a = o[t - 1], s = o[t];
		if (R(a) || R(s) || x[a.card].kind === "skull" || x[s.card].kind === "skull") continue;
		let c = x[a.card].value, l = x[s.card].value, u = i === "labyrinth" && L(e) % 2 == 0 && t === L(e) / 2;
		if (c === l && i !== "fog" && !u && (!n || t >= 2 && !R(o[t - 2]) && x[o[t - 2].card].value === l)) return !1;
	}
	if (i === "labyrinth") return o.every((t, n) => {
		let r = o[L(e) - 1 - n];
		return !r || R(t) || R(r) || x[t.card].kind === "skull" || x[r.card].kind === "skull" || x[t.card].value === x[r.card].value;
	});
	let s = (e) => i === "grassland" ? [
		1,
		2,
		3,
		4,
		8,
		9
	].includes(e) : i === "riverside" ? e % 2 == 1 : i === "valley" ? e % 2 == 0 : i !== "swamp" || e <= 5, c = [];
	for (let [e, t] of o.entries()) {
		let n = x[t.card], r = R(t) || n.kind === "skull", a = r ? [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9
		] : [n.value], o = [];
		for (let t of a) if (r || s(t)) {
			if (e === 0) {
				o.push({
					n: t,
					terminal: !r && (i === "mountain" && t === 9 || i === "cave" && t === 1)
				});
				continue;
			}
			for (let e of c) {
				let n = !0;
				if ((i === "mountain" || i === "castle") && (n = t > e.n || i === "mountain" && r && e.terminal), i === "cave" && (n = t < e.n || r && e.terminal), i === "forest" && (n = Math.abs(t - e.n) !== 1), i === "lostForest" && (n = Math.abs(t - e.n) > 2), i === "desert" && (n = Math.abs(t - e.n) === 1), i === "fog" && (n = t === e.n), n) {
					o.push({
						n: t,
						terminal: e.terminal || !r && (i === "mountain" && t === 9 || i === "cave" && t === 1)
					});
					break;
				}
			}
		}
		if (c = o, !c.length) return !1;
	}
	return !0;
}
function we(e, t) {
	if (t.row < 0) return e.river.length;
	let n = e.rows[t.row], r = x[t.card];
	if (r.kind === "skull") return r.colors.includes("white") ? t.column ?? -1 : n.cards.length;
	let i = n.cards.findIndex((e) => x[e.card].kind === "skull");
	return i < 0 ? n.cards.length : i;
}
function Te(e, t, n, r = !1, i = !1) {
	let a = x[n.card];
	if (!a) return !1;
	if (n.row === -1) return a.kind !== "camp" && (a.kind !== "skull" || e.permanent && !a.colors.includes("white"));
	let o = e.rows[n.row];
	if (!o || o.closed || a.kind === "ability" && !i || !xe(e, t, n.card, r) && !i) return !1;
	let s = we(e, n), c = o.cards[s];
	if (a.kind === "skull" && a.colors.includes("white")) return !(!c || x[c.card].kind !== "skull" || x[c.card].colors.includes("white"));
	if (s >= L(o) || c && a.kind !== "skull" && !i && !j(n.card) && !x[c.card].colors.includes("white") && !a.colors.some((e) => x[c.card].colors.includes(e))) return !1;
	let l = {
		card: n.card,
		flip: n.flip,
		under: c ? [...c.under, c.card] : [],
		wild: i
	}, u = [...o.cards];
	u[s] = l;
	let d = {
		...o,
		cards: u
	};
	return Se(o, u, I(e, t, "barong"), s) ? a.kind === "skull" || i || j(n.card) ? !0 : Ce(d, u, I(e, t, "kyubi"), s) : !1;
}
function Ee(e, t, n = !1) {
	if (t.row === -1) {
		e.river.push(t.card);
		return;
	}
	let r = e.rows[t.row], i = we(e, t), a = r.cards[i];
	r.cards[i] = {
		card: t.card,
		flip: t.flip,
		under: a ? [...a.under, a.card] : [],
		wild: n
	};
}
function De(e, t, n = e.seats[t].hand, r = !1, i = !1) {
	return n.flatMap((n) => {
		if (x[n].kind === "ability" && !i) return [{
			card: n,
			row: -1,
			flip: !1
		}];
		let a = [];
		for (let o of [
			-1,
			0,
			1,
			2
		]) for (let s of x[n].colors.length === 2 ? [!1, !0] : [!1]) {
			let c = x[n].colors.includes("white") && o >= 0 ? e.rows[o].cards.flatMap((e, t) => x[e.card].kind === "skull" ? [t] : []) : [void 0];
			for (let l of c) {
				let c = {
					card: n,
					row: o,
					flip: s,
					...l === void 0 ? {} : { column: l }
				};
				Te(e, t, c, r, i) && a.push(c);
			}
		}
		return a;
	});
}
function z(e, t) {
	return t === 0 ? [[]] : e.flatMap((n, r) => e.length - r < t ? [] : z(e.slice(r + 1), t - 1).map((e) => [n, ...e]));
}
function Oe(e, t, n = !1) {
	return t.length === 0 || e.some((r, i) => (j(r) || n && x[r].kind === "skull" || x[r].kind === "number") && M(r).includes(t[0]) && Oe(e.filter((e, t) => t !== i), t.slice(1), n));
}
function ke(e, t, n, r = 0) {
	let i = t.map((e) => x[e]), a = t.length;
	if (e === "any2" || e === "any3") return a === (e === "any2" ? 2 : 3) && i.every((e) => e.kind !== "skull" && e.kind !== "camp");
	if (e === "holding" && a === 2) return i.every((e) => e.kind !== "skull" && e.kind !== "camp");
	let o = e.startsWith("river");
	if (i.some((e) => o ? e.kind === "camp" : !["number", "wild"].includes(e.kind))) return !1;
	let s = n?.campaign?.modifications[r] ?? [], c = (e) => r === 0 && x[e].colors.length === 1 && x[e].colors[0] === "red", l = (e) => j(e) || s.includes(1) && c(e) ? [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9
	] : [x[e].value], u = (e) => s.includes(0) && c(e) ? [...C, "purple"] : M(e);
	if (!o && n?.campaign && r === 0 && s.includes(2) && a === 4 && n.seats[r].hand.length === 4 && n.recipes.includes(e)) return !0;
	if (e === "edge") return a === 1 && l(t[0]).some((e) => e === 1 || e === 9);
	if (e === "holding") return a === 1 && l(t[0]).includes(4) || a === 2;
	if (e === "number2" || e === "number3") return a === (e === "number2" ? 2 : 3) && [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9
	].some((e) => t.every((t) => l(t).includes(e)));
	if (e === "color3") return a === 3 && [...C, "purple"].some((e) => t.every((t) => u(t).includes(e)));
	if (e === "different3") {
		let e = (n, r) => n === a || u(t[n]).some((t) => !r.includes(t) && e(n + 1, [...r, t]));
		return a === 3 && e(0, []);
	}
	return e === "159" ? a === 3 && t.some((e, n) => l(e).includes(1) && t.some((e, r) => r !== n && l(e).includes(5) && t.some((e, t) => t !== n && t !== r && l(e).includes(9)))) : e === "riverColors" || e === "riverFive" ? a === 5 && Oe(t, e === "riverColors" ? C : [...C, "purple"], !0) : e === "riverRB" || e === "riverGY" ? a === 5 && t.some((n, r) => j(n) && t.some((n, i) => r !== i && (x[n].kind === "skull" || j(n)) && Oe(t.filter((e, t) => t !== r && t !== i), e === "riverRB" ? ["red", "blue"] : ["green", "yellow"], !0))) : !1;
}
//#endregion
//#region src/games/eternaldecks/stages.ts
var B = (e) => e.stage[0], Ae = (e) => e.stage.endsWith("+"), V = (e) => e.players.length === 1;
function H(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function je(e, t, n) {
	let r = e.seats[t].deck.splice(0, n);
	return e.seats[t].hand.push(...r), r;
}
function Me(e) {
	return [.../* @__PURE__ */ new Set([...e.colors, ...C])].slice(0, 4);
}
function Ne(e, t) {
	return {
		fields: e,
		lap: 0,
		cards: [],
		eternals: t,
		closed: !1
	};
}
function Pe(e) {
	let t = B(e), n = e.campaign, r = V(e), i = r ? 3 : e.players.length, a = Ae(e) || t === "F" ? "beginner" : e.config.difficulty, o = Me(e.config);
	n && (o = [
		"red",
		"green",
		"yellow",
		"blue"
	]);
	let s = new Set(n?.stored.flatMap((e) => e.map((e) => e.card)) ?? []);
	e.seats = Array.from({ length: i }, (n, a) => ({
		owner: e.players[r ? 0 : a],
		color: o[a],
		secondary: i === 2 ? o[a + 2] : null,
		deck: [],
		hand: [],
		tasks: [],
		extraTask: !1,
		discs: r && t === "F" ? 1 : 2,
		markers: ["", ""],
		personal: [],
		power: t === "F" ? ne[o[a]] : null,
		fixedRefill: !1
	})), Object.assign(e, {
		phase: r && t === "F" ? "arrange" : "act",
		turn: n ? 0 : r ? e.config.primary : 0,
		order: r && !n && t !== "F" ? [
			e.config.primary,
			(e.config.primary + 1) % 3,
			(e.config.primary + 2) % 3
		] : Array.from({ length: i }, (e, t) => t),
		rows: [],
		eternals: {},
		revived: [],
		holding: null,
		hearts: 3,
		river: [],
		recipes: [],
		stars: [],
		keys: [],
		taskProgress: [
			0,
			0,
			0,
			0
		],
		aAbilities: [],
		enemyUp: null,
		enemyTurns: 0,
		hp: 20,
		purple: [...S.purple],
		white: [
			"white0",
			"white1",
			"white2",
			"white3"
		],
		puzzles: [],
		puzzleLevel: 0,
		dragon: !1,
		permanent: !1,
		discs: [],
		gkDisc: null,
		keyBonuses: [
			"permanent",
			"heartBonus",
			"camp",
			"river3"
		],
		taskDeck: [],
		discard: [],
		choice: null,
		loss: null,
		queue: [],
		revealedHands: !1,
		changed: [],
		lastDice: null
	}), e.recipes = t === "F" ? [...O] : i === 3 ? [...D] : [...E], e.riverRewards = a === "pro" ? S.purple.filter((e) => [
		1,
		5,
		9
	].includes(x[e].value)) : [
		"river0",
		"river1",
		"river2"
	], e.stage === "A+" && (e.riverRewards = [], e.discard.push("river0")), e.purple = e.purple.filter((t) => !e.riverRewards.includes(t)), e.randomDeck = H(e, S.random.filter((t) => !s.has(t) && (a !== "pro" && e.stage !== "E+" || x[t].kind !== "wild")));
	let c = (t, r = 3) => {
		let i = w[t].filter((e) => !(n && e === "witch"));
		return i = H(e, i), e.stage === "A+" && t === "C" && (i = ["medusa", ...i.filter((e) => e !== "medusa")]), i.slice(0, r);
	}, l = (t) => {
		if (e.eternals[t]) return;
		let n = {
			id: t,
			deck: t === "cat" ? [] : w.E.includes(t) ? e.randomDeck.splice(0, 8) : H(e, (S[t] ?? []).filter((e) => !s.has(e))),
			jewel: null,
			owner: null
		};
		e.eternals[t] = n;
	}, u = t === "A" ? [
		"A",
		"B",
		"C"
	] : t === "B" ? [
		"B",
		"C",
		"A"
	] : t === "C" ? [
		"C",
		"A",
		"B"
	] : t === "D" ? [
		"D",
		"B",
		"C"
	] : [
		"E",
		"B",
		"C"
	];
	a === "pro" && t !== "F" && (u = t === "A" ? [
		"A",
		"C",
		"E"
	] : t === "B" ? [
		"B",
		"A",
		"E"
	] : t === "C" ? [
		"C",
		"D",
		"E"
	] : t === "D" ? [
		"D",
		"C",
		"E"
	] : [
		"E",
		"B",
		"D"
	]), a === "expert" && t === "C" && (u = [
		"C",
		"A",
		n ? "B" : "E"
	]);
	let d = [
		[t === "B" ? "castle" : t === "C" ? "labyrinth" : "mountain"],
		[t === "C" ? "camp" : "cave"],
		["camp"]
	];
	if (t === "B" && (d[0] = H(e, ie)), a === "standard") {
		if (t === "C") {
			let t = H(e, [...re.filter((e) => e !== "swamp"), "mountain"]);
			d[1] = t.slice(0, 4), d[2] = t.slice(4, 8);
		} else d[2] = H(e, T);
	}
	if (a === "expert" || a === "pro") {
		let n = H(e, t === "C" ? [...re, "mountain"] : re);
		d[1] = n.slice(0, 4), d[2] = n.slice(4, 8);
	}
	if (t === "C" && a === "beginner" && (d[2] = H(e, [
		"mountain",
		"cave",
		"forest",
		"lake"
	])), t === "F") {
		let t = H(e, [...re, "labyrinth"]), n = c("A"), r = c("B"), i = c("C");
		e.rows = [
			Ne(["mountain"], [
				n[0],
				r[0],
				i[0]
			]),
			Ne(t.slice(0, 4), [
				n[1],
				r[1],
				i[1]
			]),
			Ne([...t.slice(4, 8), ...H(e, ie)], [
				n[2],
				r[2],
				i[2]
			])
		];
	} else e.rows = u.map((r, i) => Ne(d[i], t === "B" && i === 0 ? n ? [
		"ghost",
		"skeleton",
		"vampire",
		"cat"
	] : H(e, w.B) : c(r)));
	e.rows.forEach((e) => e.eternals.forEach(l)), !r && (t === "D" || t === "E") && (e.turn = e.seats.reduce((t, n, r) => C.indexOf(n.color) < C.indexOf(e.seats[t].color) ? r : t, 0)), t === "C" && (e.puzzles = [
		0,
		1,
		2,
		3
	].map((t) => H(e, [
		0,
		1,
		2,
		3
	]).slice(0, 2).map((e) => t * 4 + e))), e.enemyDeck = t === "D" || e.stage === "B+" ? [...H(e, i === 3 ? S.gk1 : S.gk1.filter((e) => x[e].effect !== "observe")), ...H(e, S.gk2)] : [], t === "F" && (e.enemyDeck = [...S.gk2]);
	for (let [a, o] of e.seats.entries()) o.deck = H(e, (S[t === "F" ? o.power : `${o.color}start`] ?? []).filter((e) => !s.has(e))), i === 2 && t !== "F" && o.deck.push(...H(e, S[`${o.secondary}start`].filter((e) => !s.has(e))).slice(0, 2)), n?.modifications[a].includes(1) && a === 1 && o.deck.push(...H(e, S.bluestart.filter((e) => !s.has(e))).slice(0, 2)), n?.modifications[a].includes(2) && a === 1 && (o.discs += 1), je(e, a, o.power === "jinn" ? 4 : r && !n && t !== "F" && a !== e.config.primary ? 2 : 3);
	if (t === "E") {
		let t = H(e, [
			6,
			7,
			8,
			9
		]), r = H(e, se.filter((t) => e.stage !== "E+" || !["lateJewel", "rareHand"].includes(t.kind)));
		e.seats.forEach((e, i) => {
			e.tasks = [
				...n ? [] : [{
					id: `starting${i}`,
					kind: "starting",
					color: e.color
				}],
				{
					id: `number${t[i]}`,
					kind: "number",
					value: t[i]
				},
				r.shift()
			];
		}), i < 4 && (e.taskDeck = r);
	}
	if (!n && t !== "F" && (e.randomDeck = []), n && (n.storedThisStage = n.stored.map((e) => e.some((e) => e.chapter === n.chapter)), n.storeActions = [
		0,
		1,
		2
	].map((e) => n.stored.some((t) => t.some((t) => t.chapter === n.chapter && t.actor === e))), n.jewels = n.storedThisStage.map((e) => n.chapter === 4 && e), n.chapterWon = !1, n.stagePointsUnspent = 0, n.modifications[2].includes(2))) {
		let t = e.rows.map((e, t) => ({
			kind: "choice",
			choice: {
				kind: "eternal",
				seat: 2,
				options: w[u[t]].filter((e) => e !== "witch").map((e) => ({
					id: e,
					eternal: e
				})),
				remaining: 1,
				context: String(t)
			}
		})).filter((e) => e.choice.options.length > 3);
		t.length && (e.queue.push(...t), e.phase = "resolve");
	}
}
//#endregion
//#region src/games/eternaldecks/actions.ts
function Fe(e, t) {
	if (t === "holding") return e.holding && e.eternals[e.holding]?.jewel === null && e.holding !== "cat" ? [e.holding] : [];
	let n = [...e.revived, ...e.seats.flatMap((e) => e.personal)].filter((t) => e.eternals[t]?.jewel === null), r = e.campaign;
	return r?.chapter === 4 && r.catUsed && r.jewels.every((e) => !e) && r.storedThisStage.every(Boolean) && e.recipes.length === 1 && e.revived.length === 9 && e.revived.every((t) => e.eternals[t]?.jewel) && n.push("cat"), n;
}
function Ie(e, t) {
	let n = e.seats[t], r = e.campaign;
	if (!V(e) || n.discs < 1 || !["act", "after"].includes(e.phase) || B(e) === "E" && e.stars.length === 0) return [];
	if (!r) return n.deck.length > 0 ? ["draw"] : [];
	if (t !== e.turn) return [];
	let i = r.upgrades[t], a = [];
	return (t === 0 && (n.deck.length || i.includes("drawRandom") && e.randomDeck.length) || t === 1 && i.includes("draw2") && n.deck.length || t === 2 && i.includes("drawRandom") && e.randomDeck.length) && a.push("draw"), (t === 1 || i.includes("give")) && n.hand.length && e.seats.length > 1 && a.push("give"), (t === 2 || i.includes("ignore")) && De(e, t, n.hand, !0).some((e) => e.row >= 0) && a.push("ignore"), t === 1 && i.includes("river") && e.river.some((e) => e !== "permanent") && a.push("river"), t === 1 && i.includes("giveDisc") && n.discs >= 2 && a.push("giveDisc"), t === 2 && i.includes("remove") && e.rows.some((e) => e.cards.length) && a.push("remove"), t === 2 && i.includes("wild") && n.discs >= 2 && De(e, t, n.hand, !0, !0).some((e) => e.row >= 0) && a.push("wild"), t === 2 && r.modifications[2].includes(1) && n.discs >= 2 && !n.fixedRefill && a.push("refill4"), a;
}
function Le(e, t) {
	if (!e.players.includes(t)) return [];
	if (e.choice) return e.seats[e.choice.seat].owner === t ? e.choice.options.map((e) => ({
		type: "choose",
		option: e.id
	})) : [];
	if (e.phase === "arrange") return e.players[0] === t ? [
		[
			0,
			1,
			2
		],
		[
			0,
			2,
			1
		],
		[
			1,
			0,
			2
		],
		[
			1,
			2,
			0
		],
		[
			2,
			0,
			1
		],
		[
			2,
			1,
			0
		]
	].map((e) => ({
		type: "arrange",
		order: e
	})) : [];
	let n = e.seats.map((e, n) => e.owner === t ? n : -1).filter((e) => e >= 0), r = e.campaign && e.players[0] === t ? de(e) : [];
	if (e.phase === "chapter") return r.push({ type: "nextChapter" }), r;
	if (!["act", "after"].includes(e.phase)) return [];
	for (let t of n) for (let n of Ie(e, t)) r.push({
		type: "disc",
		seat: t,
		ability: n
	});
	if (!n.includes(e.turn)) return r;
	let i = e.seats[e.turn], a = e.turn;
	if (e.phase === "after") return r.push({ type: "endTurn" }), r;
	let o = e.rows.some((e) => !e.closed && _e(e) === "festival"), s = o || I(e, a, "pegasus"), c = o && Ae(e) && B(e) === "B";
	for (let t of De(e, a)) {
		if (c || r.push({
			type: "play",
			moves: [t]
		}), !s) continue;
		let n = {
			...e,
			rows: e.rows.map((e) => ({
				...e,
				cards: [...e.cards]
			})),
			river: [...e.river]
		};
		if (Ee(n, t), !(t.row === -1 && n.river.length >= 5)) for (let e of De(n, a, i.hand.filter((e) => e !== t.card))) r.push({
			type: "play",
			moves: [t, e]
		});
	}
	let l = [...e.recipes.filter((e) => !e.startsWith("river")), ...e.holding && e.holding !== "cat" ? ["holding"] : []];
	for (let t of l) {
		let n = t === "edge" ? [1] : ["any2", "number2"].includes(t) ? [2] : t === "holding" ? [1, 2] : [3];
		e.campaign?.modifications[0].includes(2) && a === 0 && i.hand.length === 4 && n.push(4);
		for (let o of n) for (let n of z(i.hand, o)) if (ke(t, n, e, a)) for (let i of Fe(e, t)) r.push({
			type: "jewel",
			cards: n,
			eternal: i,
			recipe: t
		});
	}
	for (let t of i.hand) {
		let n = x[t];
		if (n.kind === "ability" && (n.effect !== "minotaur" || e.rows.some((e) => e.cards.some((e) => x[e.card].kind !== "camp"))) && r.push({
			type: "ability",
			card: t
		}), e.campaign) for (let n = 0; n < 3; n += 1) ue(e, a, t, n) && r.push({
			type: "store",
			card: t,
			target: n
		});
		let i = e.campaign?.modifications[a].includes(0) && a === 1 && n.colors.length === 1 && n.colors[0] === "green" && [
			1,
			5,
			9
		].includes(n.value);
		if (e.hearts > 0 || i) for (let n = 0; n < e.seats.length; n += 1) a !== n && r.push({
			type: "give",
			cards: [t],
			target: n
		});
	}
	let u = e.campaign;
	if (u && u.chapter >= 2 && u.catFound && !u.catUsed) for (let t of Fe(e)) r.push({
		type: "jewel",
		recipe: "cat",
		cards: [],
		eternal: t
	});
	if (u?.jewels[a]) for (let t of Fe(e)) r.push({
		type: "jewel",
		recipe: [
			"golem0",
			"golem1",
			"golem2"
		][a],
		cards: [],
		eternal: t
	});
	return r;
}
function Re(e, t) {
	return e.seats[t].fixedRefill || I(e, t, "jinn") ? 4 : V(e) && !e.campaign && B(e) !== "F" && t !== e.config.primary ? 2 : 3;
}
function ze(e, t, n, r, i) {
	return V(e) || !["act", "after"].includes(e.phase) || e.seats[n]?.owner !== t || B(e) === "E" && (e.stars.length === 0 || Ae(e) && r === 1) ? !1 : i === "" || /^row:[0-2]:[0-6]$/.test(i) || i === "river" ? !0 : e.stage === "E+" ? !1 : i === "heart" || i === "discard" ? !0 : i.startsWith("eternal:") ? [...e.revived, ...e.holding ? [e.holding] : []].includes(i.slice(8)) : i.startsWith("recipe:") && e.recipes.includes(i.slice(7));
}
function Be(e, t) {
	let n = (e) => typeof e != "object" || !e ? JSON.stringify(e) : Array.isArray(e) ? `[${e.map(n).join(",")}]` : `{${Object.entries(e).sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => `${e}:${n(t)}`).join(",")}}`;
	return n(e) === n(t);
}
//#endregion
//#region src/games/eternaldecks/schema.ts
var Ve = t.enum([
	"red",
	"blue",
	"green",
	"yellow",
	"purple",
	"white"
]), He = t.enum([
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"A+",
	"B+",
	"C+",
	"D+",
	"E+"
]), Ue = t.enum([
	"camp",
	"mountain",
	"cave",
	"forest",
	"lake",
	"grassland",
	"riverside",
	"valley",
	"desert",
	"swamp",
	"labyrinth",
	"castle",
	"lostForest",
	"fog",
	"festival"
]), We = t.enum([
	"phoenix",
	"mermaid",
	"king",
	"fairy",
	"ghost",
	"skeleton",
	"witch",
	"vampire",
	"medusa",
	"minotaur",
	"kraken",
	"mummy",
	"pegasus",
	"barong",
	"jinn",
	"kyubi",
	"kappa",
	"cyclops",
	"yeti",
	"golem",
	"cat"
]), Ge = t.enum([
	"any2",
	"any3",
	"color3",
	"different3",
	"edge",
	"number2",
	"number3",
	"159",
	"holding",
	"riverColors",
	"riverFive",
	"riverRB",
	"riverGY",
	"cat",
	"golem0",
	"golem1",
	"golem2"
]);
t.object({
	id: t.string(),
	kind: t.enum([
		"number",
		"wild",
		"skull",
		"ability",
		"camp"
	]),
	colors: t.array(Ve),
	value: t.int().min(0).max(9),
	source: t.string(),
	effect: t.string().optional()
});
var Ke = t.object({
	card: t.string(),
	flip: t.boolean(),
	under: t.array(t.string()),
	wild: t.boolean()
}), qe = t.object({
	card: t.string(),
	row: t.int().min(-1).max(2),
	column: t.int().min(0).max(6).optional(),
	flip: t.boolean().default(!1)
}), Je = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		moves: t.array(qe).min(1).max(2)
	}),
	t.object({
		type: t.literal("jewel"),
		recipe: Ge,
		cards: t.array(t.string()).max(4),
		eternal: t.string()
	}),
	t.object({
		type: t.literal("ability"),
		card: t.string()
	}),
	t.object({
		type: t.literal("give"),
		cards: t.array(t.string()).min(1),
		target: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("store"),
		card: t.string(),
		target: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("disc"),
		seat: t.int().min(0).max(3),
		ability: t.string()
	}),
	t.object({
		type: t.literal("marker"),
		seat: t.int().min(0).max(3),
		index: t.int().min(0).max(1),
		target: t.string().max(60)
	}),
	t.object({
		type: t.literal("buy"),
		seat: t.int().min(0).max(2),
		upgrade: t.string()
	}),
	t.object({
		type: t.literal("modify"),
		seat: t.int().min(0).max(2),
		modification: t.int().min(0).max(2)
	}),
	t.object({
		type: t.literal("arrange"),
		order: t.array(t.int().min(0).max(2)).length(3)
	}),
	t.object({
		type: t.literal("choose"),
		option: t.string()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({ type: t.literal("nextChapter") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), Ye = t.object({
	stage: He.catch("A"),
	difficulty: t.enum([
		"beginner",
		"standard",
		"expert",
		"pro"
	]).catch("beginner"),
	mode: t.enum(["stage", "story"]).catch("stage"),
	primary: t.int().min(0).max(2).catch(0),
	colors: t.array(t.enum([
		"red",
		"blue",
		"green",
		"yellow"
	])).min(2).max(4).catch([
		"red",
		"blue",
		"green",
		"yellow"
	])
}).default({
	stage: "A",
	difficulty: "beginner",
	mode: "stage",
	primary: 0,
	colors: [
		"red",
		"blue",
		"green",
		"yellow"
	]
}), Xe = t.object({
	id: t.string(),
	kind: t.enum([
		"starting",
		"number",
		"star",
		"jewel",
		"lateJewel",
		"column",
		"rareHand",
		"rarePair"
	]),
	value: t.int().optional(),
	color: Ve.optional()
}), Ze = t.object({
	id: We,
	jewel: Ge.nullable(),
	owner: t.int().nullable(),
	deckCount: t.int().nonnegative()
}), Qe = t.object({
	id: t.string(),
	card: t.string().optional(),
	eternal: We.optional(),
	row: t.int().optional(),
	column: t.int().optional(),
	color: Ve.optional(),
	recipe: Ge.optional(),
	seat: t.int().optional(),
	value: t.string().optional()
}), $e = t.object({
	kind: t.enum([
		"revive",
		"camp",
		"purple",
		"white",
		"gatekeeper",
		"jewel",
		"recover",
		"minotaur",
		"riverTake",
		"draw",
		"riverRecipe",
		"riverSpecial",
		"discColor",
		"keyBonus",
		"storyDraw",
		"storyGive",
		"storyRemove",
		"storyWild",
		"task",
		"eternal"
	]),
	seat: t.int(),
	options: t.array(Qe),
	remaining: t.int().default(1),
	context: t.string().default("")
}), et = t.object({
	chapter: t.int().min(0).max(4),
	failures: t.array(t.int()),
	scores: t.array(t.number()),
	points: t.int().nonnegative(),
	upgrades: t.array(t.array(t.string())),
	modifications: t.array(t.array(t.int())),
	stored: t.array(t.array(t.object({
		card: t.string(),
		chapter: t.int(),
		actor: t.int()
	}))),
	storedThisStage: t.array(t.boolean()),
	storeActions: t.array(t.boolean()),
	jewels: t.array(t.boolean()),
	catUsed: t.boolean(),
	catFound: t.boolean(),
	stagePointsUnspent: t.int(),
	chapterWon: t.boolean()
}), tt = t.object({
	kind: t.enum([
		"play",
		"revive",
		"jewel",
		"star",
		"key",
		"damage",
		"enemy",
		"give",
		"draw",
		"curse",
		"ability",
		"store",
		"disc",
		"task",
		"retry",
		"chapter"
	]),
	seat: t.int(),
	card: t.string().optional(),
	value: t.string().optional(),
	amount: t.number().optional()
}), nt = t.object({
	phase: t.enum([
		"arrange",
		"act",
		"resolve",
		"choice",
		"after",
		"chapter",
		"won",
		"lost"
	]),
	stage: He,
	difficulty: t.enum([
		"beginner",
		"standard",
		"expert",
		"pro"
	]),
	solo: t.boolean(),
	turn: t.int(),
	order: t.array(t.int()),
	seats: t.array(t.object({
		owner: t.string(),
		color: Ve,
		secondary: Ve.nullable(),
		handCount: t.int(),
		deckCount: t.int(),
		openHand: t.array(t.string()).nullable(),
		openTasks: t.array(Xe),
		taskCount: t.int(),
		discs: t.int(),
		markers: t.array(t.string()),
		personal: t.array(We),
		power: We.nullable()
	})),
	rows: t.array(t.object({
		field: Ue,
		capacity: t.int(),
		closed: t.boolean(),
		lap: t.int(),
		cards: t.array(Ke),
		eternals: t.array(We)
	})),
	eternals: t.array(Ze),
	revived: t.array(We),
	holding: We.nullable(),
	hearts: t.int().min(0).max(3),
	river: t.array(t.string()),
	riverRewards: t.array(t.string()),
	recipes: t.array(Ge),
	stars: t.array(t.string()),
	keys: t.array(t.string()),
	taskProgress: t.array(t.int()),
	aAbilities: t.array(t.string()),
	enemyCount: t.int(),
	enemyUp: t.string().nullable(),
	hp: t.int(),
	purple: t.array(t.string()),
	white: t.array(t.string()),
	puzzles: t.array(t.int()),
	puzzleLevel: t.int(),
	dragon: t.boolean(),
	permanent: t.boolean(),
	discs: t.array(Ve),
	gkDisc: Ve.nullable(),
	keyBonuses: t.array(t.string()),
	discard: t.array(t.string()),
	choice: $e.nullable(),
	campaign: et.nullable(),
	loss: t.enum([
		"river",
		"enemy",
		"blocked",
		"earlyStar",
		"startingTask"
	]).nullable(),
	log: t.array(tt)
}), rt = t.object({
	seats: t.array(t.object({
		seat: t.int(),
		hand: t.array(t.string()),
		tasks: t.array(Xe)
	})),
	actions: t.array(Je)
}), it = {
	id: "eternaldecks",
	tier: "beta",
	mechanics: [
		"hand-management",
		"deck-bag-building",
		"tile-placement"
	],
	interactionTags: ["cooperative"],
	nameKey: "games.eternaldecks.name",
	descKey: "games.eternaldecks.desc",
	rulesKey: "games.eternaldecks.rules",
	icon: "♾️",
	iconImg: "games/eternaldecks.webp",
	minPlayers: 1,
	maxPlayers: 4,
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/eternaldecks/en.pdf" },
	bestPlayers: [4],
	playerRange: (e) => e?.mode === "story" ? {
		min: 1,
		max: 1
	} : {
		min: 1,
		max: 4
	},
	accent: "#254b3e",
	releasedAt: "2026-10-17T23:15:00+08:00",
	search: {
		py: "yong heng pai",
		init: "yhp"
	},
	hotseat: "cover"
}, U = (e, ...t) => {
	e.queue.unshift(...t);
}, W = (e, t, n, r, i = "", a = 1) => {
	r.length && (e.choice = {
		kind: t,
		seat: n,
		options: r,
		context: i,
		remaining: a
	}, e.phase = "choice");
}, at = (e, t, n, r = "", i = 1) => ({
	kind: "choice",
	choice: {
		kind: e,
		seat: t,
		options: n,
		context: r,
		remaining: i
	}
}), ot = (e, t, n) => {
	e.seats[t].hand = e.seats[t].hand.filter((e) => !n.includes(e));
}, st = (e, t) => e.order[(e.order.indexOf(t) + 1) % e.order.length], ct = (e) => Fe(e).map((e) => e), lt = (e, t) => t.flatMap((t) => Fe(e, t).map((e) => ({
	id: `${t}:${e}`,
	recipe: t,
	eternal: e
})));
function ut(e, t) {
	let n = /* @__PURE__ */ new Set([...e.stars, ...e.queue.flatMap((e) => e.kind === "star" ? [e.source] : [])]), r = [];
	e.stage !== "A+" && (e.revived.length >= 3 && e.revived.slice(0, 3).every((t) => e.eternals[t]?.jewel) && r.push("first3"), e.revived.length >= 6 && e.revived.slice(3, 6).every((t) => e.eternals[t]?.jewel) && r.push("next3")), e.revived.length >= 9 && r.push("revived9"), B(e) === "A" && e.aAbilities.length >= 3 && r.push("abilities"), B(e) === "F" && e.stars.length >= 4 && !e.keys.includes("stars") && G(e, t, "stars"), U(e, ...r.filter((e) => !n.has(e)).map((e) => ({
		kind: "star",
		seat: t,
		source: e
	})));
}
function G(e, t, n) {
	e.keys.includes(n) || (e.keys.push(n), e.log.push({
		kind: "key",
		seat: t,
		value: n
	}), B(e) === "F" && e.keys.length < 4 && U(e, at("keyBonus", t, e.keyBonuses.map((e) => ({
		id: e,
		value: e
	})))));
}
function dt(e, t, n, r) {
	let i = e.eternals[r];
	i && (i.jewel = n), e.recipes.includes(n) && (e.recipes = e.recipes.filter((e) => e !== n)), n === "cat" && (e.campaign.catUsed = !0), n.startsWith("golem") && (e.campaign.jewels[Number(n.slice(-1))] = !1), e.log.push({
		kind: "jewel",
		seat: t,
		value: `${n}:${r}`
	}), gt(e, {
		kind: "jewel",
		seat: t,
		recipe: n,
		eternal: r
	}), n === "159" && B(e) !== "F" && U(e, {
		kind: "star",
		seat: t,
		source: "159"
	}), B(e) === "F" && [
		"different3",
		"number3",
		"159"
	].every((t) => !e.recipes.includes(t)) && G(e, t, "jewels"), ut(e, t);
}
function ft(e, t) {
	return e.seats[t].hand.some((n) => x[n].kind === "number" && x[n].value <= 5 && x[n].colors.includes(e.seats[t].color));
}
function pt(e, t) {
	return [...C, "purple"].some((n) => e.rows.every((e) => {
		let r = e.cards[t];
		return r && x[r.card].kind !== "skull" && (R(r) || M(r.card).includes(n));
	}));
}
function mt(e, t, n, r) {
	if (t.kind === "starting") return r.kind === "star" && [3, 4].includes(r.star) && ft(e, n);
	if (t.kind === "rareHand") return r.kind === "star" && [2, 4].includes(r.star) && e.seats[n].hand.some((e) => x[e].kind === "wild");
	let i = e.stage === "E+" ? e.order[(e.order.indexOf(n) + e.order.length - 1) % e.order.length] : n;
	return r.seat === i ? t.kind === "number" ? r.kind === "play" && r.row >= 0 && e.stars.length < 3 && x[r.card].kind === "number" && x[r.card].value === t.value : t.kind === "star" ? r.kind === "star" : t.kind === "jewel" ? r.kind === "jewel" && [
		"color3",
		"different3",
		"number3"
	].includes(r.recipe) : t.kind === "lateJewel" ? r.kind === "jewel" && e.revived.indexOf(r.eternal) >= 6 && e.revived.indexOf(r.eternal) <= 8 : t.kind === "column" ? r.kind === "play" && r.row >= 0 && pt(e, r.column) : t.kind === "rarePair" && r.kind === "play" && r.row >= 0 && x[r.card].kind === "wild" && r.column > 0 && x[e.rows[r.row].cards[r.column - 1].card].kind === "wild" : !1;
}
function ht(e, t) {
	let n = C.indexOf(e.seats[t].color);
	if (e.taskProgress[n] >= 2) {
		let r = C.filter((t) => !e.seats.some((e) => e.color === t) && e.taskProgress[C.indexOf(t)] < 2);
		if (r.length > 1) {
			U(e, at("discColor", t, r.map((e) => ({
				id: e,
				color: e
			})), "taskKey"));
			return;
		}
		if (!r.length) return;
		n = C.indexOf(r[0]);
	}
	e.taskProgress[n] += 1, e.taskProgress[n] === 2 && G(e, t, C[n]);
}
function gt(e, t) {
	if (B(e) === "E") {
		for (let [n, r] of e.seats.entries()) {
			let i = r.tasks.filter((r) => (e.stage !== "E+" || r.kind !== "starting") && mt(e, r, n, t));
			for (let t of i) {
				r.tasks = r.tasks.filter((e) => e.id !== t.id), ht(e, n), e.log.push({
					kind: "task",
					seat: n,
					value: t.id
				});
				let i = e.taskProgress[C.indexOf(r.color)] >= 2;
				(e.seats.length === 2 || e.seats.length === 3 && i && !r.extraTask) && (r.extraTask = !0, e.taskDeck.length && (V(e) && e.stars.length >= 2 ? U(e, at("task", n, e.taskDeck.map((e) => ({
					id: e.id,
					value: e.id
				})))) : r.tasks.push(e.taskDeck.shift()))), e.seats.length === 4 && i && (r.tasks = r.tasks.filter((t) => e.stage === "E+" && t.kind === "starting"));
			}
		}
		if (e.seats.length === 3) {
			let t = C.find((t) => !e.seats.some((e) => e.color === t));
			if (e.taskProgress[C.indexOf(t)] >= 2) for (let t of e.seats) e.taskProgress[C.indexOf(t.color)] >= 2 && (t.tasks = t.tasks.filter((t) => e.stage === "E+" && t.kind === "starting"));
		}
	}
}
function _t(e, t) {
	let n = ce[t], r = [];
	for (let t = 0; t <= 3 - n.height; t += 1) for (let i = 0; i <= 7 - n.width; i += 1) n.cells.every((n) => {
		let r = e.rows[t + n.row].cards[i + n.column];
		return !r || x[r.card].kind === "skull" ? !1 : R(r) ? e.stage !== "C+" : M(r.card).includes(n.color);
	}) && r.push({
		row: t,
		column: i,
		changed: n.cells.some((n) => e.changed.some((e) => e.row === t + n.row && e.column === i + n.column))
	});
	return r;
}
function vt(e, t) {
	if (B(e) !== "C" || e.puzzleLevel >= 4) {
		e.changed = [];
		return;
	}
	let [n, r] = e.puzzles[e.puzzleLevel].map((t) => _t(e, t));
	(e.stage === "C+" ? n.some((e) => r.some((t) => e.column <= t.column && (e.changed || t.changed))) : [...n, ...r].some((e) => e.changed)) && (G(e, t, `puzzle${e.puzzleLevel}`), e.puzzleLevel += 1), e.changed = [];
}
function yt(e, t, n) {
	if (B(e) !== "D" || n === 0 || e.keys.length >= 4) return;
	let r = e.stage === "D+" ? [
		10,
		5,
		0,
		0
	][e.keys.length] : [
		15,
		10,
		5,
		0
	][e.keys.length], i = e.hp - n;
	if (e.log.push({
		kind: "damage",
		seat: t,
		amount: n
	}), i > r) {
		e.hp = i;
		return;
	}
	if (e.stage === "D+") {
		let n = C[e.keys.length], a = e.seats[t];
		if (a.color !== n && a.secondary !== n && e.seats.some((e) => e.color === n || e.secondary === n) || e.keys.length === 3 && i !== 0) {
			e.hp = r + 1;
			return;
		}
		i < r && e.discard.push(...a.deck.splice(0, r - i));
		let o = e.queue.findIndex((e) => e.kind !== "play" && e.kind !== "damage");
		e.queue.splice(o < 0 ? e.queue.length : o, 0, {
			kind: "counter",
			seat: t
		});
	}
	G(e, t, `damage${e.keys.length}`), e.hp = 20;
}
function bt(e, t = -1) {
	let n = e.rows.flatMap((e, n) => n === t ? [] : e.cards.map((e, t) => ({
		row: n,
		column: t
	}))).sort((e, t) => t.column - e.column || e.row - t.row).slice(0, 2);
	n.forEach(({ row: t, column: n }) => {
		let r = e.rows[t].cards[n];
		e.discard.push(...r.under, r.card);
	});
	for (let [t, r] of e.rows.entries()) r.cards = r.cards.filter((e, r) => !n.some((e) => e.row === t && e.column === r));
}
function xt(e, t, n) {
	if (t === "yeti" && e.seats.forEach((t) => e.discard.push(...t.deck.splice(0, 1))), t === "kappa" && e.discard.push(...e.riverRewards.splice(0, 1)), t === "cyclops" && bt(e, n), t === "golem") {
		let n = e.revived.find((t) => e.eternals[t]?.jewel);
		n && (e.eternals[t].jewel = e.eternals[n].jewel, e.eternals[n].jewel = null, gt(e, {
			kind: "jewel",
			seat: e.turn,
			recipe: e.eternals[t].jewel,
			eternal: t
		}));
	}
}
function St(e, t) {
	let n = e.rows[t];
	e.discard.push(...n.cards.flatMap((e) => [...e.under, e.card])), n.cards = [], n.lap += 1, n.fields.length > 1 && n.fields.shift();
}
function Ct(e, t, n, r, i) {
	let a = e.rows[n], o = e.eternals[r];
	if (a.eternals = a.eternals.filter((e) => e !== r), e.seats[t].deck.push(...o.deck), o.deck = [], B(e) === "B" && n === 0) e.holding && e.holding !== "cat" && (e.eternals[e.holding].jewel = null, e.revived.push(e.holding)), e.holding = r, G(e, t, r), r === "cat" && (e.campaign.catFound = !0);
	else if (i) {
		let n = e.seats[t];
		o.owner = t, n.personal.push(r);
		let i = n.personal.length === 1 ? n.color : n.secondary;
		e.discs.includes(i) || e.discs.push(i), e.gkDisc && C.every((t) => e.discs.includes(t)) && G(e, t, "discs");
	} else e.revived.push(r);
	St(e, n), e.log.push({
		kind: "revive",
		seat: t,
		value: r
	}), w.E.includes(r) && U(e, {
		kind: "curse",
		seat: t,
		eternal: r,
		row: n
	}), ut(e, t);
}
function wt(e, t, n) {
	let r = e.rows[n];
	if (ve(r)) {
		if (r.eternals.length) {
			W(e, "revive", t, r.eternals.filter((e) => e !== "cat" || r.eternals.length === 1).flatMap((r) => {
				let i = {
					id: `${r}:public`,
					eternal: r,
					row: n
				}, a = e.seats[t], o = e.seats.length === 2 ? 2 : 1;
				return B(e) === "F" && a.personal.length < o ? [i, {
					id: `${r}:personal`,
					eternal: r,
					row: n,
					seat: t
				}] : [i];
			}));
			return;
		}
		r.closed = !0, n === 0 && B(e) !== "B" && W(e, "camp", t, e.rows.flatMap((e, t) => t !== n && !e.closed && (e.cards.length < L(e) || e.cards.some((e) => x[e.card].kind === "skull")) ? [{
			id: String(t),
			row: t
		}] : [])), n === 1 && (e.hearts = 3), n === 2 && (B(e) === "F" && e.dragon, U(e, {
			kind: "star",
			seat: t,
			source: "bottom"
		}));
	}
}
function Tt(e, t, n = e.stars.length, r = !1) {
	let i = B(e);
	if ((i === "B" || i === "C") && W(e, "purple", t, e.purple.map((e) => ({
		id: e,
		card: e
	}))), i === "D") {
		let n = e.white.shift();
		n && e.seats[t].hand.push(n);
	}
	i === "E" && (e.stage === "E+" ? [2, 3].includes(n) ? e.hearts = 3 : n >= 4 && Et(e) : n >= 3 && Et(e)), i === "F" && W(e, "gatekeeper", t, e.enemyDeck.map((e) => ({
		id: e,
		card: e
	})), r ? "dragon" : "bonus");
}
function Et(e) {
	V(e) ? e.seats.forEach((t, n) => je(e, n, 1)) : e.revealedHands = !0;
}
function Dt(e, t) {
	let n = H(e, e.seats.flatMap((e) => e.hand));
	e.seats.forEach((e) => {
		e.hand = [];
	});
	let r = t;
	n.forEach((t) => {
		e.seats[r].hand.push(t), r = st(e, r);
	});
}
function Ot(e, t, n) {
	if ([
		"phoenix",
		"mermaid",
		"king",
		"fairy"
	].includes(n) && (B(e) === "A" ? (e.aAbilities.push(n), ut(e, t)) : e.stage === "E+" ? e.hearts = Math.min(3, e.hearts + 1) : B(e) === "E" ? Et(e) : U(e, {
		kind: "starBonus",
		seat: t
	})), n === "skeleton" && (e.hearts = Math.min(3, e.hearts + 1)), n === "recoverAll" && (e.hearts = 3), n === "ghost" && Et(e), n === "witch" && W(e, "jewel", t, lt(e, e.recipes.filter((e) => e !== "159"))), n === "medusa" && W(e, "recover", t, e.discard.filter((t) => x[t].kind === "wild" || e.config.difficulty === "pro" && x[t].colors.includes("purple")).map((e) => ({
		id: e,
		card: e
	}))), n === "minotaur" && W(e, "minotaur", t, e.rows.flatMap((e, t) => e.cards.flatMap((e, n) => x[e.card].kind === "camp" ? [] : [{
		id: `${t}:${n}`,
		row: t,
		column: n,
		card: e.card
	}]))), n === "kraken" && W(e, "riverTake", t, e.river.filter((e) => e !== "permanent").map((e) => ({
		id: e,
		card: e
	})), "", 2), n === "mummy" && W(e, "draw", t, e.seats.flatMap((e, t) => e.deck.length ? [{
		id: String(t),
		seat: t
	}] : []), "", 3), n === "shuffle" && Dt(e, B(e) === "F" ? st(e, t) : e.order[0]), n === "jewel2" || n === "jewel3") {
		let r = n === "jewel2" ? "number2" : "number3";
		if (e.recipes.includes(r)) {
			let n = ct(e);
			B(e) === "F" ? W(e, "jewel", t, lt(e, [r])) : n.length && U(e, {
				kind: "jewel",
				seat: t,
				recipe: r,
				eternal: n[0]
			});
		}
	}
}
function kt(e, t) {
	let n = [];
	return !e.keys.includes("river") && z(t, 5).some((e) => e.every((e) => j(e) || [5, 7].includes(x[e].value))) && n.push("riverKey"), !e.stars.includes("river") && z(t, 5).some((e) => z(e, 2).some((t) => t.every((e) => j(e) || x[e].value === 3 && x[e].colors.includes("green")) && e.filter((e) => !t.includes(e)).every((e) => j(e) || x[e].value === 8))) && n.push("riverStar"), !e.gkDisc && z(t, 5).some((e) => e.some((t, n) => j(t) && e.some((t, r) => r !== n && (j(t) || x[t].kind === "skull" && x[t].colors.includes("purple")) && z(e.filter((e, t) => t !== n && t !== r), 2).some((e) => e.every((e) => j(e) || x[e].kind === "number" && x[e].colors.includes("purple")))))) && n.push("riverDisc"), n;
}
function At(e, t, n = !1) {
	if (!(e.river.length < 5)) {
		if (B(e) === "F" && !n) {
			let n = e.recipes.filter((t) => t.startsWith("river") && Fe(e, t).length && z(e.river, 5).some((e) => ke(t, e))), r = kt(e, e.river);
			if (r.includes("riverKey") && G(e, t, "river"), r.includes("riverStar") && !e.queue.some((e) => e.kind === "star" && e.source === "river") && U(e, {
				kind: "star",
				seat: t,
				source: "river"
			}), r.includes("riverDisc")) {
				W(e, "discColor", t, C.map((e) => ({
					id: e,
					color: e
				}))), U(e, {
					kind: "river",
					seat: t
				});
				return;
			}
			let i = n.map((e) => ({
				id: e,
				recipe: e
			}));
			if (i.length) {
				W(e, "riverRecipe", t, [...i, {
					id: "skip",
					value: "skip"
				}]);
				return;
			}
		}
		U(e, {
			kind: "riverClear",
			seat: t
		});
	}
}
function jt(e) {
	if (e.loss === "earlyStar" || e.loss === "startingTask") return !1;
	let t = B(e) === "A" ? e.stars.length >= 4 : e.keys.length >= 4;
	return e.campaign ? !t || e.recipes.length ? !1 : e.campaign.chapter !== 4 || e.campaign.catUsed && e.campaign.storedThisStage.every(Boolean) && e.campaign.jewels.every((e) => !e) && e.revived.length === 9 && e.revived.every((t) => e.eternals[t]?.jewel) : t && (e.stage !== "E+" || e.stars.length >= 4);
}
function Mt(e) {
	let t = jt(e);
	return !t && !e.loss ? !1 : (e.campaign ? he(e, t) : e.phase = t ? "won" : "lost", e.queue = [], e.choice = null, !0);
}
function Nt(e) {
	e.phase === "act" && (Le(e, e.seats[e.turn].owner).some((t) => t.type !== "disc" || t.seat === e.turn) || (e.loss = "blocked", Mt(e)));
}
function Pt(t, n) {
	let r = n.kind === "choice" ? n.choice.seat : n.seat, i = "ed-stage", a;
	switch (n.kind) {
		case "choice": return W(t, n.choice.kind, r, n.choice.options, n.choice.context, n.choice.remaining), [];
		case "play": {
			let e = n.move, o = we(t, e), s = t.rows[e.row]?.cards[o];
			e.row >= 0 && s && x[s.card].kind === "skull" && x[e.card].kind === "number" && !n.wild && U(t, {
				kind: "damage",
				seat: r,
				value: x[e.card].value
			}), ot(t, r, [e.card]), Ee(t, e, n.wild), e.row >= 0 && (t.changed.push({
				row: e.row,
				column: o
			}), gt(t, {
				kind: "play",
				seat: r,
				card: e.card,
				row: e.row,
				column: o
			})), t.log.push({
				kind: "play",
				seat: r,
				card: e.card,
				value: `${e.row}:${o}`
			}), i = e.row < 0 ? "ed-river" : `ed-row:${e.row}`, a = e.card;
			break;
		}
		case "damage":
			yt(t, r, n.value);
			break;
		case "counter": {
			let n = e(t.seed, t.cursor++, 4) + 1;
			if (t.lastDice = n, n === 1 && xt(t, "yeti", -1), n === 2 && xt(t, "cyclops", -1), n === 3 && xt(t, "kappa", -1), n === 4) {
				let e = t.revived.find((e) => t.eternals[e]?.jewel);
				e && (t.eternals[e].jewel = null);
			}
			t.log.push({
				kind: "curse",
				seat: r,
				value: `counter${n}`
			});
			break;
		}
		case "puzzle":
			vt(t, r);
			break;
		case "rows":
			wt(t, r, n.row), i = `ed-row:${n.row}`;
			break;
		case "curse":
			xt(t, n.eternal, n.row), t.log.push({
				kind: "curse",
				seat: r,
				value: n.eternal
			}), ut(t, r);
			break;
		case "river":
			At(t, r, n.recipesDone), i = "ed-river";
			break;
		case "riverClear": {
			let e = t.riverRewards.shift();
			e ? t.seats[r].hand.push(e) : t.dragon || (t.loss = "river"), t.discard.push(...t.river.filter((e) => e !== "permanent")), t.river = t.permanent ? ["permanent"] : [], i = "ed-river";
			break;
		}
		case "jewel":
			dt(t, r, n.recipe, n.eternal);
			break;
		case "star":
			if (t.stars.includes(n.source)) break;
			t.stars.push(n.source), t.log.push({
				kind: "star",
				seat: r,
				value: n.source
			}), t.campaign && (t.campaign.points += 1, t.campaign.stagePointsUnspent += 1), U(t, {
				kind: "starBonus",
				seat: r,
				star: t.stars.length,
				keysReady: t.keys.length >= 4,
				dragon: B(t) === "F" && n.source === "bottom" && !t.dragon
			}), ut(t, r);
			break;
		case "starBonus":
			Tt(t, r, n.star, n.dragon), n.star !== void 0 && (gt(t, {
				kind: "star",
				seat: r,
				star: n.star
			}), t.stage === "E+" && n.star === 4 && (n.keysReady ? t.seats.every((e, n) => ft(t, n)) || (t.loss = "startingTask") : t.loss = "earlyStar"));
			break;
		case "ability":
			Ot(t, r, n.effect);
			break;
		case "draw": {
			let e = je(t, r, n.count);
			return t.log.push({
				kind: "draw",
				seat: r,
				amount: e.length
			}), e.length ? [{
				kind: "edDraw",
				rid: t.seats[r].owner,
				data: {
					seat: r,
					count: e.length
				},
				for: V(t) || t.revealedHands ? t.players : [t.seats[r].owner],
				secret: { cards: e }
			}] : [];
		}
		case "resume": return t.phase = n.phase, Nt(t), [];
		case "refill":
			if (t.campaign && t.phase !== "after") return t.phase = "after", t.queue = [], [];
			U(t, {
				kind: "draw",
				seat: r,
				count: Math.max(0, Re(t, r) - t.seats[r].hand.length)
			}, {
				kind: "end",
				seat: r
			});
			break;
		case "end":
			if (Mt(t)) return [];
			if (t.revealedHands = !1, t.turn = st(t, r), t.changed = [], B(t) === "D" || t.stage === "B+") {
				t.enemyTurns += 1;
				let e = t.seats.length === 2 ? 4 : t.seats.length;
				if (t.enemyTurns % e === 0 && t.keys.length < 4) {
					U(t, {
						kind: "enemy",
						seat: t.turn
					});
					break;
				}
			}
			return t.phase = "act", Nt(t), [];
		case "enemy": {
			let e = t.enemyDeck.shift();
			if (t.enemyUp = e ?? null, !e) return t.loss = "enemy", Mt(t), [];
			let n = x[e];
			if (n.kind === "skull") {
				let n = De(t, r, [e]).find((e) => e.row >= 0);
				n ? Ee(t, n) : t.discard.push(e);
			} else t.discard.push(e), U(t, {
				kind: "ability",
				seat: r,
				effect: n.effect
			});
			t.log.push({
				kind: "enemy",
				seat: -1,
				card: e
			});
			break;
		}
	}
	return [{
		kind: "edChange",
		data: {
			anchor: i,
			...a ? { card: a } : {}
		}
	}];
}
function Ft(e, t) {
	e.queue.push({
		kind: "puzzle",
		seat: t
	}, ...[
		0,
		1,
		2
	].map((e) => ({
		kind: "rows",
		seat: t,
		row: e
	})), {
		kind: "river",
		seat: t
	}, {
		kind: "refill",
		seat: t
	}), e.phase = "resolve";
}
function It(e, t) {
	let n = t.remaining - 1;
	if (n < 1) return;
	let r = e.seats[t.seat], i = t.kind === "draw" ? e.seats.flatMap((e, t) => e.deck.length ? [{
		id: String(t),
		seat: t
	}] : []) : t.kind === "riverTake" ? e.river.filter((e) => e !== "permanent").map((e) => ({
		id: e,
		card: e
	})) : t.kind === "storyDraw" ? [...r.deck.length && t.seat !== 2 ? [{
		id: "own",
		value: "own"
	}] : [], ...e.randomDeck.length && (t.seat === 2 || t.seat === 0 && e.campaign.upgrades[0].includes("drawRandom")) ? [{
		id: "random",
		value: "random"
	}] : []] : [];
	i.length && U(e, at(t.kind, t.seat, i, t.context, n));
}
function Lt(e, t, n) {
	let r = t.seat, i = e.seats[r];
	switch (t.kind) {
		case "revive":
			Ct(e, r, n.row, n.eternal, n.seat !== void 0);
			break;
		case "camp": {
			let t = e.rows[n.row], i = t.cards.findIndex((e) => x[e.card].kind === "skull"), a = i < 0 ? void 0 : t.cards[i], o = {
				card: "camp",
				flip: !1,
				under: a ? [...a.under, a.card] : [],
				wild: !1
			};
			i < 0 && t.cards.length < L(t) ? t.cards.push(o) : i >= 0 && (t.cards[i] = o), e.changed.push({
				row: n.row,
				column: i < 0 ? t.cards.length - 1 : i
			}), U(e, {
				kind: "puzzle",
				seat: r
			}, {
				kind: "rows",
				seat: r,
				row: n.row
			});
			break;
		}
		case "purple":
			i.hand.push(n.card), e.purple = e.purple.filter((e) => e !== n.card);
			break;
		case "white": break;
		case "gatekeeper":
			if (e.enemyDeck = e.enemyDeck.filter((e) => e !== n.card), t.context === "dragon") {
				let t = e.rows[2], r = t.cards.flatMap((t) => (e.discard.push(...t.under), t.card === "camp" ? (e.discard.push("camp"), []) : [t.card]));
				i.deck.push(...H(e, [...r, n.card])), e.dragon = !0, t.cards = [], t.eternals = [...w.E], t.closed = !1, t.lap = 0, t.fields.shift(), t.eternals.forEach((t) => {
					e.eternals[t] = {
						id: t,
						deck: e.randomDeck.splice(0, 8),
						jewel: null,
						owner: null
					};
				});
			} else i.hand.push(n.card);
			break;
		case "jewel":
			dt(e, r, n.recipe, n.eternal);
			break;
		case "recover":
			e.discard = e.discard.filter((e) => e !== n.card), e.riverRewards.unshift(n.card);
			break;
		case "minotaur": {
			let r = e.rows[n.row], a = r.cards[n.column], o = t.context;
			i.hand.push(a.card), r.cards[n.column] = {
				...a,
				card: o,
				flip: !1,
				wild: !0
			}, e.changed.push({
				row: n.row,
				column: n.column
			}), e.discard = e.discard.filter((e) => e !== o);
			break;
		}
		case "riverTake":
			i.hand.push(n.card), e.river = e.river.filter((e) => e !== n.card), It(e, t);
			break;
		case "draw": {
			let r = e.seats[n.seat].deck.splice(0, 1);
			i.hand.push(...r), It(e, t);
			break;
		}
		case "riverRecipe":
			n.recipe && W(e, "jewel", r, lt(e, [n.recipe])), n.value === "riverKey" && G(e, r, "river"), n.value === "riverStar" && U(e, {
				kind: "star",
				seat: r,
				source: "river"
			}), n.value === "riverDisc" && W(e, "discColor", r, C.map((e) => ({
				id: e,
				color: e
			}))), U(e, {
				kind: "river",
				seat: r,
				recipesDone: !0
			});
			break;
		case "riverSpecial": break;
		case "discColor":
			if (t.context === "taskKey") {
				let t = C.indexOf(n.color);
				e.taskProgress[t] += 1, e.taskProgress[t] >= 2 && G(e, r, n.color);
			} else e.gkDisc = n.color, e.discs.includes(n.color) || e.discs.push(n.color), C.every((t) => e.discs.includes(t)) && G(e, r, "discs");
			break;
		case "keyBonus":
			e.keyBonuses = e.keyBonuses.filter((e) => e !== n.id), n.id === "permanent" && (e.permanent = !0, e.river.unshift("permanent")), n.id === "heartBonus" && i.hand.push("heartBonus"), n.id === "river3" && e.riverRewards.push("river3"), n.id === "camp" && W(e, "camp", r, e.rows.flatMap((e, t) => e.closed ? [] : [{
				id: String(t),
				row: t
			}]));
			break;
		case "storyDraw": {
			let r = n.id === "own" ? i.deck.shift() : e.randomDeck.shift();
			r && i.hand.push(r), It(e, t);
			break;
		}
		case "storyGive":
			if (t.context === "giveDisc") e.seats[n.seat].discs += 1;
			else {
				let [t, ...i] = n.id.split(":");
				ot(e, r, i), e.seats[Number(t)].hand.push(...i);
			}
			break;
		case "storyRemove": {
			let t = e.rows[n.row].cards.pop();
			e.discard.push(...t.under, t.card);
			break;
		}
		case "storyWild": {
			let [i, a, o, s] = n.id.split(":");
			U(e, {
				kind: "play",
				seat: r,
				move: {
					card: i,
					row: Number(a),
					...o === "" ? {} : { column: Number(o) },
					flip: s === "1"
				},
				ignore: !0,
				wild: t.context === "wild"
			}, {
				kind: "puzzle",
				seat: r
			}, ...[
				0,
				1,
				2
			].map((e) => ({
				kind: "rows",
				seat: r,
				row: e
			})));
			break;
		}
		case "task": {
			let t = e.taskDeck.find((e) => e.id === n.id);
			i.tasks.push(t), e.taskDeck = e.taskDeck.filter((e) => e.id !== n.id);
			break;
		}
		case "eternal": {
			let r = e.rows[Number(t.context)], i = oe(n.eternal), a = w[i].filter((t) => t !== n.eternal && !(e.campaign && t === "witch")), o = r.eternals.filter((e) => !a.includes(e)), s = new Set(e.campaign.stored.flatMap((e) => e.map((e) => e.card)));
			a.forEach((t) => {
				if (!e.eternals[t]) {
					let n = o.shift();
					e.eternals[t] = {
						id: t,
						deck: i === "E" && n ? e.eternals[n].deck : H(e, (S[t] ?? []).filter((e) => !s.has(e))),
						jewel: null,
						owner: null
					}, n && delete e.eternals[n];
				}
			}), r.eternals = a;
			break;
		}
	}
}
function Rt(e, t, n) {
	let r = e.seats[t], i = e.campaign;
	if (r.discs -= [
		"wild",
		"giveDisc",
		"refill4"
	].includes(n) ? 2 : 1, e.log.push({
		kind: "disc",
		seat: t,
		value: n
	}), !i) {
		U(e, {
			kind: "draw",
			seat: t,
			count: B(e) === "F" ? 2 : 1
		});
		return;
	}
	if (n === "draw" && W(e, "storyDraw", t, [...r.deck.length && t !== 2 ? [{
		id: "own",
		value: "own"
	}] : [], ...e.randomDeck.length && (t === 2 || t === 0 && i.upgrades[0].includes("drawRandom")) ? [{
		id: "random",
		value: "random"
	}] : []], "", i.upgrades[t].includes("draw2") ? 2 : 1), n === "give") {
		let n = t === 1 && i.upgrades[t].includes("giveAll") ? r.hand.flatMap((e, t) => z(r.hand, t + 1)) : r.hand.map((e) => [e]);
		W(e, "storyGive", t, e.seats.flatMap((e, r) => r === t ? [] : n.map((e) => ({
			id: `${r}:${e.join(":")}`,
			seat: r,
			card: e[0],
			value: e.join(",")
		}))));
	}
	if ((n === "ignore" || n === "wild") && W(e, "storyWild", t, De(e, t, r.hand, !0, n === "wild").filter((e) => e.row >= 0).map((e) => ({
		id: `${e.card}:${e.row}:${e.column ?? ""}:${+!!e.flip}`,
		card: e.card,
		row: e.row,
		column: e.column
	})), n), n === "river" && W(e, "riverTake", t, e.river.filter((e) => e !== "permanent").map((e) => ({
		id: e,
		card: e
	}))), n === "giveDisc" && W(e, "storyGive", t, e.seats.flatMap((e, n) => n === t ? [] : [{
		id: String(n),
		seat: n
	}]), "giveDisc"), n === "remove") {
		let n = Math.max(...e.rows.map((e) => e.cards.length));
		W(e, "storyRemove", t, e.rows.flatMap((e, t) => e.cards.length === n && n > 0 ? [{
			id: String(t),
			row: t,
			card: e.cards[n - 1].card
		}] : []));
	}
	n === "refill4" && (r.fixedRefill = !0);
}
function zt(e, t, n) {
	let r = Ye.parse(e), i = {
		config: r,
		players: [...t],
		seed: n,
		cursor: 0,
		campaign: r.mode === "story" && t.length === 1 ? F() : null,
		stage: r.mode === "story" && t.length === 1 ? "A" : r.stage,
		log: []
	};
	return Pe(i), Nt(i), {
		state: i,
		fx: []
	};
}
function Bt(e, t, n) {
	if (!Je.safeParse(t).success) return { code: "games.eternaldecks.errAction" };
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.phase !== "resolve" || e.choice) return { code: "games.eternaldecks.errAction" };
		let t = structuredClone(e), r = t.queue.shift(), i = r ? Pt(t, r) : [];
		return !t.choice && t.phase === "resolve" && t.queue.length === 0 && (t.phase = "act", Nt(t)), {
			state: t,
			fx: i
		};
	}
	if (t.type === "marker") {
		if (!ze(e, n.by, t.seat, t.index, t.target)) return { code: "games.eternaldecks.errAction" };
		let r = structuredClone(e);
		return r.seats[t.seat].markers[t.index] = t.target, { state: r };
	}
	if (!Le(e, n.by).some((e) => Be(e, t))) return { code: "games.eternaldecks.errAction" };
	let r = structuredClone(e), i = r.turn, a = r.seats[i];
	switch (t.type) {
		case "play":
			r.changed = [], r.queue = t.moves.map((e) => ({
				kind: "play",
				seat: i,
				move: e
			})), Ft(r, i);
			break;
		case "jewel":
			ot(r, i, t.cards), r.river.push(...t.cards), r.queue = [{
				kind: "jewel",
				seat: i,
				recipe: t.recipe,
				eternal: t.eternal
			}], Ft(r, i);
			break;
		case "ability":
			ot(r, i, [t.card]), r.discard.push(t.card), r.log.push({
				kind: "ability",
				seat: i,
				card: t.card,
				value: x[t.card].effect
			}), r.queue = [{
				kind: "ability",
				seat: i,
				effect: x[t.card].effect
			}], Ft(r, i), x[t.card].effect === "minotaur" && (r.queue[0] = at("minotaur", i, r.rows.flatMap((e, t) => e.cards.flatMap((e, n) => x[e.card].kind === "camp" ? [] : [{
				id: `${t}:${n}`,
				row: t,
				column: n,
				card: e.card
			}])), t.card));
			break;
		case "give": {
			let e = x[t.cards[0]];
			r.campaign?.modifications[i].includes(0) && i === 1 && e.colors.length === 1 && e.colors[0] === "green" && [
				1,
				5,
				9
			].includes(e.value) || --r.hearts, ot(r, i, t.cards), r.seats[t.target].hand.push(...t.cards), r.log.push({
				kind: "give",
				seat: i,
				amount: t.cards.length,
				value: String(t.target)
			}), Ft(r, i);
			break;
		}
		case "store": {
			ot(r, i, [t.card]);
			let e = r.campaign;
			e.stored[t.target].push({
				card: t.card,
				chapter: e.chapter,
				actor: i
			}), e.storedThisStage[t.target] = !0, e.storeActions[i] = !0, e.chapter === 4 && (e.jewels[t.target] = !0), r.log.push({
				kind: "store",
				seat: i,
				card: t.card,
				value: String(t.target)
			}), Ft(r, i);
			break;
		}
		case "disc": {
			let e = r.phase;
			Rt(r, t.seat, t.ability), r.queue.push({
				kind: "resume",
				seat: t.seat,
				phase: e
			}), r.choice || (r.phase = "resolve");
			break;
		}
		case "choose": {
			let e = r.choice, n = e.options.find((e) => e.id === t.option);
			r.choice = null, r.phase = "resolve", Lt(r, e, n);
			break;
		}
		case "buy":
		case "modify":
			fe(r, t), Nt(r);
			break;
		case "arrange":
			r.order = t.order, r.turn = t.order[0], r.phase = "act", Nt(r);
			break;
		case "endTurn":
			r.phase = "resolve", r.queue = [{
				kind: "draw",
				seat: i,
				count: Math.max(0, Re(r, i) - a.hand.length)
			}, {
				kind: "end",
				seat: i
			}];
			break;
		case "nextChapter": {
			let e = r.campaign;
			(e.chapterWon || e.failures[e.chapter] >= 2) && (e.chapter += 1), r.stage = [
				"A",
				"B",
				"C",
				"D",
				"E"
			][e.chapter], Pe(r), Nt(r);
			break;
		}
	}
	return { state: r };
}
function Vt(e, t) {
	let n = [
		"won",
		"lost",
		"chapter"
	].includes(e.phase), r = {
		phase: e.phase,
		stage: e.stage,
		difficulty: Ae(e) || B(e) === "F" ? "beginner" : e.config.difficulty,
		solo: V(e),
		turn: e.turn,
		order: e.order,
		seats: e.seats.map((t) => ({
			owner: t.owner,
			color: t.color,
			secondary: t.secondary,
			handCount: t.hand.length,
			deckCount: t.deck.length,
			openHand: V(e) || e.revealedHands || n ? [...t.hand] : null,
			openTasks: t.tasks.filter((t) => V(e) || n || (e.stage === "E+" ? t.kind === "starting" : e.stars.length >= 2)),
			taskCount: t.tasks.length,
			discs: t.discs,
			markers: [...t.markers],
			personal: [...t.personal],
			power: t.power
		})),
		rows: e.rows.map((e) => ({
			field: _e(e),
			capacity: L(e),
			closed: e.closed,
			lap: e.lap,
			cards: e.cards.map((e) => ({
				...e,
				under: [...e.under]
			})),
			eternals: [...e.eternals]
		})),
		eternals: Object.values(e.eternals).filter((e) => e !== void 0).map((e) => ({
			id: e.id,
			jewel: e.jewel,
			owner: e.owner,
			deckCount: e.deck.length
		})),
		revived: [...e.revived],
		holding: e.holding,
		hearts: e.hearts,
		river: [...e.river],
		riverRewards: [...e.riverRewards],
		recipes: [...e.recipes],
		stars: [...e.stars],
		keys: [...e.keys],
		taskProgress: [...e.taskProgress],
		aAbilities: [...e.aAbilities],
		enemyCount: e.enemyDeck.length,
		enemyUp: e.enemyUp,
		hp: e.hp,
		purple: [...e.purple],
		white: [...e.white],
		puzzles: [...e.puzzles[e.puzzleLevel] ?? []],
		puzzleLevel: e.puzzleLevel,
		dragon: e.dragon,
		permanent: e.permanent,
		discs: [...e.discs],
		gkDisc: e.gkDisc,
		keyBonuses: [...e.keyBonuses],
		discard: [...e.discard],
		choice: e.choice ? structuredClone(e.choice) : null,
		campaign: e.campaign ? structuredClone(e.campaign) : null,
		loss: e.loss,
		log: e.log.map((e) => ({ ...e }))
	};
	B(e) === "F" && (r.purple = [...e.enemyDeck]);
	let i = e.seats.flatMap((e, n) => e.owner === t ? [{
		seat: n,
		hand: [...e.hand],
		tasks: structuredClone(e.tasks)
	}] : []);
	return {
		public: r,
		...i.length ? { private: {
			seats: i,
			actions: Le(e, t)
		} } : {}
	};
}
function Ht(e) {
	return e.phase !== "won" && e.phase !== "lost" ? { phase: e.phase } : {
		phase: e.phase,
		winner: e.phase === "won" ? [...e.players] : [],
		ranking: [...e.players],
		scores: Object.fromEntries(e.players.map((t) => [t, e.campaign ? me(e.campaign) : e.keys.length + e.stars.length]))
	};
}
var Ut = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: it,
	schemas: {
		action: Je,
		publicView: nt,
		privateView: rt,
		config: Ye
	},
	setup: zt,
	reduce: Bt,
	viewFor: Vt,
	status: Ht,
	nextTickIn: (e) => e.phase === "resolve" && !e.choice ? 420 : null
}, Wt = {
	table: {
		viewBox: "0 0 1024 1536",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1536\" rx=\"0\" fill=\"#142e2a\" /><rect x=\"20\" y=\"20\" width=\"984\" height=\"1496\" rx=\"0\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"3\" opacity=\".65\"/><rect x=\"30\" y=\"30\" width=\"964\" height=\"1476\" rx=\"0\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"1\" opacity=\".5\"/><path d=\"M49 40L54.85 49L49 58L43.15 49Z\" fill=\"#baa36e\" /><path d=\"M49 1478L54.85 1487L49 1496L43.15 1487Z\" fill=\"#baa36e\" /><path d=\"M84 40L89.85 49L84 58L78.15 49Z\" fill=\"#baa36e\" /><path d=\"M84 1478L89.85 1487L84 1496L78.15 1487Z\" fill=\"#baa36e\" /><path d=\"M119 40L124.85 49L119 58L113.15 49Z\" fill=\"#baa36e\" /><path d=\"M119 1478L124.85 1487L119 1496L113.15 1487Z\" fill=\"#baa36e\" /><path d=\"M154 40L159.85 49L154 58L148.15 49Z\" fill=\"#baa36e\" /><path d=\"M154 1478L159.85 1487L154 1496L148.15 1487Z\" fill=\"#baa36e\" /><path d=\"M189 40L194.85 49L189 58L183.15 49Z\" fill=\"#baa36e\" /><path d=\"M189 1478L194.85 1487L189 1496L183.15 1487Z\" fill=\"#baa36e\" /><path d=\"M224 40L229.85 49L224 58L218.15 49Z\" fill=\"#baa36e\" /><path d=\"M224 1478L229.85 1487L224 1496L218.15 1487Z\" fill=\"#baa36e\" /><path d=\"M259 40L264.85 49L259 58L253.15 49Z\" fill=\"#baa36e\" /><path d=\"M259 1478L264.85 1487L259 1496L253.15 1487Z\" fill=\"#baa36e\" /><path d=\"M294 40L299.85 49L294 58L288.15 49Z\" fill=\"#baa36e\" /><path d=\"M294 1478L299.85 1487L294 1496L288.15 1487Z\" fill=\"#baa36e\" /><path d=\"M329 40L334.85 49L329 58L323.15 49Z\" fill=\"#baa36e\" /><path d=\"M329 1478L334.85 1487L329 1496L323.15 1487Z\" fill=\"#baa36e\" /><path d=\"M364 40L369.85 49L364 58L358.15 49Z\" fill=\"#baa36e\" /><path d=\"M364 1478L369.85 1487L364 1496L358.15 1487Z\" fill=\"#baa36e\" /><path d=\"M399 40L404.85 49L399 58L393.15 49Z\" fill=\"#baa36e\" /><path d=\"M399 1478L404.85 1487L399 1496L393.15 1487Z\" fill=\"#baa36e\" /><path d=\"M434 40L439.85 49L434 58L428.15 49Z\" fill=\"#baa36e\" /><path d=\"M434 1478L439.85 1487L434 1496L428.15 1487Z\" fill=\"#baa36e\" /><path d=\"M469 40L474.85 49L469 58L463.15 49Z\" fill=\"#baa36e\" /><path d=\"M469 1478L474.85 1487L469 1496L463.15 1487Z\" fill=\"#baa36e\" /><path d=\"M504 40L509.85 49L504 58L498.15 49Z\" fill=\"#baa36e\" /><path d=\"M504 1478L509.85 1487L504 1496L498.15 1487Z\" fill=\"#baa36e\" /><path d=\"M539 40L544.85 49L539 58L533.15 49Z\" fill=\"#baa36e\" /><path d=\"M539 1478L544.85 1487L539 1496L533.15 1487Z\" fill=\"#baa36e\" /><path d=\"M574 40L579.85 49L574 58L568.15 49Z\" fill=\"#baa36e\" /><path d=\"M574 1478L579.85 1487L574 1496L568.15 1487Z\" fill=\"#baa36e\" /><path d=\"M609 40L614.85 49L609 58L603.15 49Z\" fill=\"#baa36e\" /><path d=\"M609 1478L614.85 1487L609 1496L603.15 1487Z\" fill=\"#baa36e\" /><path d=\"M644 40L649.85 49L644 58L638.15 49Z\" fill=\"#baa36e\" /><path d=\"M644 1478L649.85 1487L644 1496L638.15 1487Z\" fill=\"#baa36e\" /><path d=\"M679 40L684.85 49L679 58L673.15 49Z\" fill=\"#baa36e\" /><path d=\"M679 1478L684.85 1487L679 1496L673.15 1487Z\" fill=\"#baa36e\" /><path d=\"M714 40L719.85 49L714 58L708.15 49Z\" fill=\"#baa36e\" /><path d=\"M714 1478L719.85 1487L714 1496L708.15 1487Z\" fill=\"#baa36e\" /><path d=\"M749 40L754.85 49L749 58L743.15 49Z\" fill=\"#baa36e\" /><path d=\"M749 1478L754.85 1487L749 1496L743.15 1487Z\" fill=\"#baa36e\" /><path d=\"M784 40L789.85 49L784 58L778.15 49Z\" fill=\"#baa36e\" /><path d=\"M784 1478L789.85 1487L784 1496L778.15 1487Z\" fill=\"#baa36e\" /><path d=\"M819 40L824.85 49L819 58L813.15 49Z\" fill=\"#baa36e\" /><path d=\"M819 1478L824.85 1487L819 1496L813.15 1487Z\" fill=\"#baa36e\" /><path d=\"M854 40L859.85 49L854 58L848.15 49Z\" fill=\"#baa36e\" /><path d=\"M854 1478L859.85 1487L854 1496L848.15 1487Z\" fill=\"#baa36e\" /><path d=\"M889 40L894.85 49L889 58L883.15 49Z\" fill=\"#baa36e\" /><path d=\"M889 1478L894.85 1487L889 1496L883.15 1487Z\" fill=\"#baa36e\" /><path d=\"M924 40L929.85 49L924 58L918.15 49Z\" fill=\"#baa36e\" /><path d=\"M924 1478L929.85 1487L924 1496L918.15 1487Z\" fill=\"#baa36e\" /><path d=\"M959 40L964.85 49L959 58L953.15 49Z\" fill=\"#baa36e\" /><path d=\"M959 1478L964.85 1487L959 1496L953.15 1487Z\" fill=\"#baa36e\" /><path d=\"M994 40L999.85 49L994 58L988.15 49Z\" fill=\"#baa36e\" /><path d=\"M994 1478L999.85 1487L994 1496L988.15 1487Z\" fill=\"#baa36e\" /><path d=\"M49 75L54.85 84L49 93L43.15 84Z\" fill=\"#baa36e\" /><path d=\"M975 75L980.85 84L975 93L969.15 84Z\" fill=\"#baa36e\" /><path d=\"M49 110L54.85 119L49 128L43.15 119Z\" fill=\"#baa36e\" /><path d=\"M975 110L980.85 119L975 128L969.15 119Z\" fill=\"#baa36e\" /><path d=\"M49 145L54.85 154L49 163L43.15 154Z\" fill=\"#baa36e\" /><path d=\"M975 145L980.85 154L975 163L969.15 154Z\" fill=\"#baa36e\" /><path d=\"M49 180L54.85 189L49 198L43.15 189Z\" fill=\"#baa36e\" /><path d=\"M975 180L980.85 189L975 198L969.15 189Z\" fill=\"#baa36e\" /><path d=\"M49 215L54.85 224L49 233L43.15 224Z\" fill=\"#baa36e\" /><path d=\"M975 215L980.85 224L975 233L969.15 224Z\" fill=\"#baa36e\" /><path d=\"M49 250L54.85 259L49 268L43.15 259Z\" fill=\"#baa36e\" /><path d=\"M975 250L980.85 259L975 268L969.15 259Z\" fill=\"#baa36e\" /><path d=\"M49 285L54.85 294L49 303L43.15 294Z\" fill=\"#baa36e\" /><path d=\"M975 285L980.85 294L975 303L969.15 294Z\" fill=\"#baa36e\" /><path d=\"M49 320L54.85 329L49 338L43.15 329Z\" fill=\"#baa36e\" /><path d=\"M975 320L980.85 329L975 338L969.15 329Z\" fill=\"#baa36e\" /><path d=\"M49 355L54.85 364L49 373L43.15 364Z\" fill=\"#baa36e\" /><path d=\"M975 355L980.85 364L975 373L969.15 364Z\" fill=\"#baa36e\" /><path d=\"M49 390L54.85 399L49 408L43.15 399Z\" fill=\"#baa36e\" /><path d=\"M975 390L980.85 399L975 408L969.15 399Z\" fill=\"#baa36e\" /><path d=\"M49 425L54.85 434L49 443L43.15 434Z\" fill=\"#baa36e\" /><path d=\"M975 425L980.85 434L975 443L969.15 434Z\" fill=\"#baa36e\" /><path d=\"M49 460L54.85 469L49 478L43.15 469Z\" fill=\"#baa36e\" /><path d=\"M975 460L980.85 469L975 478L969.15 469Z\" fill=\"#baa36e\" /><path d=\"M49 495L54.85 504L49 513L43.15 504Z\" fill=\"#baa36e\" /><path d=\"M975 495L980.85 504L975 513L969.15 504Z\" fill=\"#baa36e\" /><path d=\"M49 530L54.85 539L49 548L43.15 539Z\" fill=\"#baa36e\" /><path d=\"M975 530L980.85 539L975 548L969.15 539Z\" fill=\"#baa36e\" /><path d=\"M49 565L54.85 574L49 583L43.15 574Z\" fill=\"#baa36e\" /><path d=\"M975 565L980.85 574L975 583L969.15 574Z\" fill=\"#baa36e\" /><path d=\"M49 600L54.85 609L49 618L43.15 609Z\" fill=\"#baa36e\" /><path d=\"M975 600L980.85 609L975 618L969.15 609Z\" fill=\"#baa36e\" /><path d=\"M49 635L54.85 644L49 653L43.15 644Z\" fill=\"#baa36e\" /><path d=\"M975 635L980.85 644L975 653L969.15 644Z\" fill=\"#baa36e\" /><path d=\"M49 670L54.85 679L49 688L43.15 679Z\" fill=\"#baa36e\" /><path d=\"M975 670L980.85 679L975 688L969.15 679Z\" fill=\"#baa36e\" /><path d=\"M49 705L54.85 714L49 723L43.15 714Z\" fill=\"#baa36e\" /><path d=\"M975 705L980.85 714L975 723L969.15 714Z\" fill=\"#baa36e\" /><path d=\"M49 740L54.85 749L49 758L43.15 749Z\" fill=\"#baa36e\" /><path d=\"M975 740L980.85 749L975 758L969.15 749Z\" fill=\"#baa36e\" /><path d=\"M49 775L54.85 784L49 793L43.15 784Z\" fill=\"#baa36e\" /><path d=\"M975 775L980.85 784L975 793L969.15 784Z\" fill=\"#baa36e\" /><path d=\"M49 810L54.85 819L49 828L43.15 819Z\" fill=\"#baa36e\" /><path d=\"M975 810L980.85 819L975 828L969.15 819Z\" fill=\"#baa36e\" /><path d=\"M49 845L54.85 854L49 863L43.15 854Z\" fill=\"#baa36e\" /><path d=\"M975 845L980.85 854L975 863L969.15 854Z\" fill=\"#baa36e\" /><path d=\"M49 880L54.85 889L49 898L43.15 889Z\" fill=\"#baa36e\" /><path d=\"M975 880L980.85 889L975 898L969.15 889Z\" fill=\"#baa36e\" /><path d=\"M49 915L54.85 924L49 933L43.15 924Z\" fill=\"#baa36e\" /><path d=\"M975 915L980.85 924L975 933L969.15 924Z\" fill=\"#baa36e\" /><path d=\"M49 950L54.85 959L49 968L43.15 959Z\" fill=\"#baa36e\" /><path d=\"M975 950L980.85 959L975 968L969.15 959Z\" fill=\"#baa36e\" /><path d=\"M49 985L54.85 994L49 1003L43.15 994Z\" fill=\"#baa36e\" /><path d=\"M975 985L980.85 994L975 1003L969.15 994Z\" fill=\"#baa36e\" /><path d=\"M49 1020L54.85 1029L49 1038L43.15 1029Z\" fill=\"#baa36e\" /><path d=\"M975 1020L980.85 1029L975 1038L969.15 1029Z\" fill=\"#baa36e\" /><path d=\"M49 1055L54.85 1064L49 1073L43.15 1064Z\" fill=\"#baa36e\" /><path d=\"M975 1055L980.85 1064L975 1073L969.15 1064Z\" fill=\"#baa36e\" /><path d=\"M49 1090L54.85 1099L49 1108L43.15 1099Z\" fill=\"#baa36e\" /><path d=\"M975 1090L980.85 1099L975 1108L969.15 1099Z\" fill=\"#baa36e\" /><path d=\"M49 1125L54.85 1134L49 1143L43.15 1134Z\" fill=\"#baa36e\" /><path d=\"M975 1125L980.85 1134L975 1143L969.15 1134Z\" fill=\"#baa36e\" /><path d=\"M49 1160L54.85 1169L49 1178L43.15 1169Z\" fill=\"#baa36e\" /><path d=\"M975 1160L980.85 1169L975 1178L969.15 1169Z\" fill=\"#baa36e\" /><path d=\"M49 1195L54.85 1204L49 1213L43.15 1204Z\" fill=\"#baa36e\" /><path d=\"M975 1195L980.85 1204L975 1213L969.15 1204Z\" fill=\"#baa36e\" /><path d=\"M49 1230L54.85 1239L49 1248L43.15 1239Z\" fill=\"#baa36e\" /><path d=\"M975 1230L980.85 1239L975 1248L969.15 1239Z\" fill=\"#baa36e\" /><path d=\"M49 1265L54.85 1274L49 1283L43.15 1274Z\" fill=\"#baa36e\" /><path d=\"M975 1265L980.85 1274L975 1283L969.15 1274Z\" fill=\"#baa36e\" /><path d=\"M49 1300L54.85 1309L49 1318L43.15 1309Z\" fill=\"#baa36e\" /><path d=\"M975 1300L980.85 1309L975 1318L969.15 1309Z\" fill=\"#baa36e\" /><path d=\"M49 1335L54.85 1344L49 1353L43.15 1344Z\" fill=\"#baa36e\" /><path d=\"M975 1335L980.85 1344L975 1353L969.15 1344Z\" fill=\"#baa36e\" /><path d=\"M49 1370L54.85 1379L49 1388L43.15 1379Z\" fill=\"#baa36e\" /><path d=\"M975 1370L980.85 1379L975 1388L969.15 1379Z\" fill=\"#baa36e\" /><path d=\"M49 1405L54.85 1414L49 1423L43.15 1414Z\" fill=\"#baa36e\" /><path d=\"M975 1405L980.85 1414L975 1423L969.15 1414Z\" fill=\"#baa36e\" /><path d=\"M49 1440L54.85 1449L49 1458L43.15 1449Z\" fill=\"#baa36e\" /><path d=\"M975 1440L980.85 1449L975 1458L969.15 1449Z\" fill=\"#baa36e\" /><path d=\"M90 1010C300 950 650 1120 936 1015\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1042C300 982 650 1152 936 1047\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1074C300 1014 650 1184 936 1079\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1106C300 1046 650 1216 936 1111\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1138C300 1078 650 1248 936 1143\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1170C300 1110 650 1280 936 1175\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1202C300 1142 650 1312 936 1207\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1234C300 1174 650 1344 936 1239\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1266C300 1206 650 1376 936 1271\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><path d=\"M90 1298C300 1238 650 1408 936 1303\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" opacity=\".05\"/><circle cx=\"76\" cy=\"78\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"147\" cy=\"187\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"218\" cy=\"296\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"289\" cy=\"405\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"360\" cy=\"514\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"431\" cy=\"623\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"502\" cy=\"732\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"573\" cy=\"841\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"644\" cy=\"950\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"715\" cy=\"1059\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"786\" cy=\"1168\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"857\" cy=\"1277\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"928\" cy=\"1386\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"129\" cy=\"125\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"200\" cy=\"234\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"271\" cy=\"343\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"342\" cy=\"452\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"413\" cy=\"561\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"484\" cy=\"670\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"555\" cy=\"779\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"626\" cy=\"888\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"697\" cy=\"997\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"768\" cy=\"1106\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"839\" cy=\"1215\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"910\" cy=\"1324\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"111\" cy=\"1433\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"182\" cy=\"172\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"253\" cy=\"281\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"324\" cy=\"390\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"395\" cy=\"499\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"466\" cy=\"608\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"537\" cy=\"717\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"608\" cy=\"826\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"679\" cy=\"935\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"750\" cy=\"1044\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"821\" cy=\"1153\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"892\" cy=\"1262\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"93\" cy=\"1371\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"164\" cy=\"110\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"235\" cy=\"219\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"306\" cy=\"328\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"377\" cy=\"437\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"448\" cy=\"546\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"519\" cy=\"655\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"590\" cy=\"764\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"661\" cy=\"873\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"732\" cy=\"982\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"803\" cy=\"1091\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"874\" cy=\"1200\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"945\" cy=\"1309\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"146\" cy=\"1418\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"217\" cy=\"157\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"288\" cy=\"266\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"359\" cy=\"375\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"430\" cy=\"484\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"501\" cy=\"593\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"572\" cy=\"702\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"643\" cy=\"811\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"714\" cy=\"920\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"785\" cy=\"1029\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"856\" cy=\"1138\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"927\" cy=\"1247\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"128\" cy=\"1356\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"199\" cy=\"95\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"270\" cy=\"204\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"341\" cy=\"313\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"412\" cy=\"422\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"483\" cy=\"531\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"554\" cy=\"640\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"625\" cy=\"749\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"696\" cy=\"858\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"767\" cy=\"967\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"838\" cy=\"1076\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"909\" cy=\"1185\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"110\" cy=\"1294\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"181\" cy=\"1403\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"252\" cy=\"142\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"323\" cy=\"251\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"394\" cy=\"360\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"465\" cy=\"469\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"536\" cy=\"578\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"607\" cy=\"687\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"678\" cy=\"796\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"749\" cy=\"905\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"820\" cy=\"1014\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"891\" cy=\"1123\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"92\" cy=\"1232\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"163\" cy=\"1341\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"234\" cy=\"80\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"305\" cy=\"189\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"376\" cy=\"298\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"447\" cy=\"407\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"518\" cy=\"516\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"589\" cy=\"625\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"660\" cy=\"734\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"731\" cy=\"843\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"802\" cy=\"952\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"873\" cy=\"1061\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"944\" cy=\"1170\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"145\" cy=\"1279\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"216\" cy=\"1388\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"287\" cy=\"127\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"358\" cy=\"236\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"429\" cy=\"345\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"500\" cy=\"454\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"571\" cy=\"563\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"642\" cy=\"672\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"713\" cy=\"781\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"784\" cy=\"890\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"855\" cy=\"999\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"926\" cy=\"1108\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"127\" cy=\"1217\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"198\" cy=\"1326\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"269\" cy=\"1435\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"340\" cy=\"174\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"411\" cy=\"283\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"482\" cy=\"392\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"553\" cy=\"501\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"624\" cy=\"610\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"695\" cy=\"719\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"766\" cy=\"828\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"837\" cy=\"937\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"908\" cy=\"1046\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"109\" cy=\"1155\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"180\" cy=\"1264\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"251\" cy=\"1373\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"322\" cy=\"112\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"393\" cy=\"221\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"464\" cy=\"330\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"535\" cy=\"439\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"606\" cy=\"548\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"677\" cy=\"657\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"748\" cy=\"766\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"819\" cy=\"875\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"890\" cy=\"984\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"91\" cy=\"1093\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"162\" cy=\"1202\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"233\" cy=\"1311\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"304\" cy=\"1420\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"375\" cy=\"159\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"446\" cy=\"268\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"517\" cy=\"377\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"588\" cy=\"486\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"659\" cy=\"595\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"730\" cy=\"704\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"801\" cy=\"813\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"872\" cy=\"922\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"943\" cy=\"1031\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"144\" cy=\"1140\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"215\" cy=\"1249\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"286\" cy=\"1358\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"357\" cy=\"97\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"428\" cy=\"206\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"499\" cy=\"315\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"570\" cy=\"424\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"641\" cy=\"533\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"712\" cy=\"642\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"783\" cy=\"751\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"854\" cy=\"860\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"925\" cy=\"969\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"126\" cy=\"1078\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"197\" cy=\"1187\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"268\" cy=\"1296\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"339\" cy=\"1405\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"410\" cy=\"144\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"481\" cy=\"253\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"552\" cy=\"362\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"623\" cy=\"471\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"694\" cy=\"580\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"765\" cy=\"689\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"836\" cy=\"798\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"907\" cy=\"907\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"108\" cy=\"1016\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"179\" cy=\"1125\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"250\" cy=\"1234\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"321\" cy=\"1343\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"392\" cy=\"82\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"463\" cy=\"191\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"534\" cy=\"300\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/><circle cx=\"605\" cy=\"409\" r=\"0.8\" fill=\"#f1e5c9\" opacity=\".06\"/>"
	},
	phoenix: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#d1c5db\" /><g transform=\"translate(0,0) scale(1,1)\"><path d=\"M489 473C383 454 325 399 288 307C263 236 228 177 148 132C170 249 184 290 225 348C143 328 95 290 64 237C75 361 138 453 230 478C146 489 101 476 70 448C114 555 201 593 296 568C232 625 193 640 135 635C240 711 352 674 422 592Z\" fill=\"#19211f\" /><path d=\"M429 501C333 456 277 388 238 288\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"13\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M407 545C298 536 223 512 175 476\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M280 404L290.4 420L280 436L269.6 420Z\" fill=\"#f1e5c9\" /><path d=\"M344 481L352.45 494L344 507L335.55 494Z\" fill=\"#f1e5c9\" /></g><g transform=\"translate(1024,0) scale(-1,1)\"><path d=\"M489 473C383 454 325 399 288 307C263 236 228 177 148 132C170 249 184 290 225 348C143 328 95 290 64 237C75 361 138 453 230 478C146 489 101 476 70 448C114 555 201 593 296 568C232 625 193 640 135 635C240 711 352 674 422 592Z\" fill=\"#19211f\" /><path d=\"M429 501C333 456 277 388 238 288\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"13\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M407 545C298 536 223 512 175 476\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M280 404L290.4 420L280 436L269.6 420Z\" fill=\"#f1e5c9\" /><path d=\"M344 481L352.45 494L344 507L335.55 494Z\" fill=\"#f1e5c9\" /></g><path d=\"M471 516L434 661C443 736 497 782 499 867C462 839 426 832 400 832C464 886 472 932 501 971L540 971C531 887 591 855 610 789C539 810 551 744 586 681L558 508Z\" fill=\"#19211f\" /><path d=\"M455 540L462 398C414 331 436 260 493 238L513 168L544 247C591 264 610 307 584 356L631 378L573 394L567 536Z\" fill=\"#19211f\" /><path d=\"M519 293L545 306L520 326L503 307Z\" fill=\"#f1e5c9\" /><path d=\"M514 443L543.9 489L514 535L484.1 489Z\" fill=\"#f1e5c9\" /><path d=\"M482 601L513 624L543 601M486 653L513 676L539 653\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"12\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M465 715L436 762L469 752L488 772L492 731ZM553 716L550 754L572 745L593 758L584 727Z\" fill=\"#19211f\" />"
	},
	medusa: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#d1c5db\" /><path d=\"M357 467C192 469 173 345 260 295C326 257 300 187 240 176\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"72\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M203 162L270 142L282 189L227 212Z\" fill=\"#19211f\" /><circle cx=\"242\" cy=\"178\" r=\"6\" fill=\"#f1e5c9\" /><path d=\"M423 366C298 253 362 127 433 145C485 160 451 234 413 245\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"72\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M391 229L445 216L459 254L405 275Z\" fill=\"#19211f\" /><circle cx=\"427\" cy=\"245\" r=\"6\" fill=\"#f1e5c9\" /><path d=\"M510 340C469 215 553 120 608 176C649 219 612 269 573 265\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"72\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M552 246L607 241L619 282L565 288Z\" fill=\"#19211f\" /><circle cx=\"588\" cy=\"261\" r=\"6\" fill=\"#f1e5c9\" /><path d=\"M617 391C746 323 697 233 769 219C821 209 862 251 838 295\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"72\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M806 280L862 282L871 321L816 323Z\" fill=\"#19211f\" /><circle cx=\"842\" cy=\"301\" r=\"6\" fill=\"#f1e5c9\" /><path d=\"M663 484C812 442 874 516 817 587C781 631 731 630 713 680\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"72\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M689 660L738 651L758 691L708 714Z\" fill=\"#19211f\" /><circle cx=\"729\" cy=\"682\" r=\"6\" fill=\"#f1e5c9\" /><path d=\"M349 419Q508 318 667 419L663 572C656 672 605 727 578 778L666 870L615 928L510 863L409 928L354 870L440 778C404 721 351 665 349 572Z\" fill=\"#19211f\" /><path d=\"M404 454Q508 376 612 454L598 581Q513 702 424 581Z\" fill=\"#f1e5c9\" /><path d=\"M424 487L481 475L465 513ZM544 476L599 487L559 513Z\" fill=\"#19211f\" /><path d=\"M507 514V556L527 563M469 600Q510 618 550 597\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M511 665L531.8 697L511 729L490.2 697Z\" fill=\"#f1e5c9\" /><path d=\"M511 754L525.3 776L511 798L496.7 776Z\" fill=\"#f1e5c9\" /><path d=\"M426 714L390 765M595 714L633 765\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><circle cx=\"511\" cy=\"425\" r=\"15\" fill=\"#baa36e\" />"
	},
	minotaur: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#d1c5db\" /><path d=\"M352 381L269 353L165 191L177 112L222 188L342 237L427 218H585L678 237L795 190L842 111L853 192L749 353L666 381L637 475L707 532L741 727L666 759L621 656L613 811L662 921H543L521 749H496L476 921H357L407 811L399 656L354 758L281 727L315 532L384 475Z\" fill=\"#19211f\" /><path d=\"M384 282L449 306L507 289L570 306L635 281L607 420L508 461L411 420Z\" fill=\"#f1e5c9\" /><path d=\"M407 318L470 336L454 355ZM548 337L611 319L566 355Z\" fill=\"#19211f\" /><path d=\"M449 382L568 382L548 425L468 425Z\" fill=\"#19211f\" /><path d=\"M482 399V410M531 399V410\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M425 503H592L619 612L508 667L399 612Z\" fill=\"#baa36e\" /><path d=\"M452 527H568L580 599L509 634L439 598Z\" fill=\"#19211f\" /><path d=\"M510 542L532.75 577L510 612L487.25 577Z\" fill=\"#f1e5c9\" /><path d=\"M342 565L363 652M677 566L655 651\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"13\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M734 428V906\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"23\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M735 449L866 486L802 569L735 549Z\" fill=\"#f1e5c9\" />"
	},
	gatekeeper: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#f1e5c9\" /><path d=\"M391 190L432 128H598L640 190L741 220L812 359L851 603L787 696L688 674L665 802L724 929H559L522 791H500L462 929H298L357 800L335 674L235 696L171 603L210 359L282 220Z\" fill=\"#19211f\" /><path d=\"M424 180H599L628 351L518 420L400 351Z\" fill=\"#baa36e\" /><path d=\"M444 203H578L598 333L517 385L429 334Z\" fill=\"#142e2a\" /><rect x=\"449\" y=\"257\" width=\"43\" height=\"19\" rx=\"2\" fill=\"#f1e5c9\" /><rect x=\"539\" y=\"257\" width=\"38\" height=\"19\" rx=\"2\" fill=\"#f1e5c9\" /><path d=\"M516 301L530.95 324L516 347L501.05 324Z\" fill=\"#f1e5c9\" /><path d=\"M268 273L365 242L395 394L257 422ZM659 244L759 273L769 422L631 393Z\" fill=\"#254b3e\" /><path d=\"M279 305L336 287M293 342L345 327M688 289L745 308M677 328L730 346\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M381 450L514 423L647 450L630 708L515 758L398 706Z\" fill=\"#254b3e\" /><circle cx=\"514\" cy=\"549\" r=\"65\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"14\"/><circle cx=\"514\" cy=\"549\" r=\"39\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"7\"/><path d=\"M514 527L528.95 550L514 573L499.05 550Z\" fill=\"#baa36e\" /><path d=\"M429 669H599M460 692H570\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M227 479L309 459L348 585L282 637L221 603ZM719 459L800 479L806 603L745 637L680 585Z\" fill=\"#254b3e\" /><path d=\"M268 503L298 573M755 503L725 573\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M381 792L388.8 804L381 816L373.2 804Z\" fill=\"#baa36e\" /><path d=\"M469 792L476.8 804L469 816L461.2 804Z\" fill=\"#baa36e\" /><path d=\"M557 792L564.8 804L557 816L549.2 804Z\" fill=\"#baa36e\" /><path d=\"M645 792L652.8 804L645 816L637.2 804Z\" fill=\"#baa36e\" />"
	},
	dragon: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#d1c5db\" /><path d=\"M290 484C239 405 283 327 353 291L410 203L411 288L467 245L448 333L394 398C374 449 440 467 508 472C692 476 816 561 801 714C787 863 613 929 474 874C398 846 349 784 384 725C408 683 469 674 515 706C458 709 449 749 485 777C558 835 699 780 705 696C711 606 604 584 487 588C374 593 316 550 290 484Z\" fill=\"#19211f\" /><path d=\"M464 479L524 202L620 289L692 146L725 319L859 248L832 439L933 438L811 624L706 539Z\" fill=\"#19211f\" /><path d=\"M527 462L558 286L605 385L672 245L679 413L790 337L765 474L860 481L787 553Z\" fill=\"#254b3e\" /><path d=\"M581 471L555 347M657 490L669 326M726 512L780 420\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M345 361L265 325L190 345L171 388L230 420L290 416L316 449L366 413Z\" fill=\"#19211f\" /><path d=\"M194 370L254 353L246 381Z\" fill=\"#f1e5c9\" /><path d=\"M284 342L315 358L288 373Z\" fill=\"#f1e5c9\" /><path d=\"M188 402L257 395\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M486 566L473 653L391 687L416 712L466 691L491 718L506 673L549 584ZM650 579L704 652L764 646L770 678L722 685L701 718L682 683L604 606Z\" fill=\"#19211f\" /><path d=\"M484 517L493.1 531L484 545L474.9 531Z\" fill=\"#f1e5c9\" /><path d=\"M522 525.6296596948756L531.1 539.6296596948756L522 553.6296596948756L512.9 539.6296596948756Z\" fill=\"#f1e5c9\" /><path d=\"M560 532.1464777265421L569.1 546.1464777265421L560 560.1464777265421L550.9 546.1464777265421Z\" fill=\"#f1e5c9\" /><path d=\"M598 534.954909758873L607.1 548.954909758873L598 562.954909758873L588.9 548.954909758873Z\" fill=\"#f1e5c9\" /><path d=\"M636 533.3673536828622L645.1 547.3673536828622L636 561.3673536828622L626.9 547.3673536828622Z\" fill=\"#f1e5c9\" /><path d=\"M674 527.7724985938712L683.1 541.7724985938712L674 555.7724985938712L664.9 541.7724985938712Z\" fill=\"#f1e5c9\" /><path d=\"M731 715Q673 865 509 817\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />"
	},
	alpha: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#f1e5c9\" /><path d=\"M344 396L264 427L192 676L243 734L324 690L353 562L357 804L298 894L334 938H466L488 808H546L568 938H700L736 894L676 804L680 562L709 690L790 734L841 676L768 427L687 396L659 208L587 150H437L367 208Z\" fill=\"#b86159\" stroke=\"#19211f\" stroke-width=\"19\" stroke-linejoin=\"round\"/><path d=\"M377 412H651L627 730L513 786L397 730Z\" fill=\"#b86159\" stroke=\"#19211f\" stroke-width=\"15\"/><circle cx=\"438\" cy=\"304\" r=\"27\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"19\"/><circle cx=\"587\" cy=\"304\" r=\"27\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"19\"/><path d=\"M512 516L554.25 581L512 646L469.75 581Z\" fill=\"#19211f\" /><path d=\"M512 551L531.5 581L512 611L492.5 581Z\" fill=\"#f1e5c9\" /><path d=\"M475 213L521 183M505 232L552 200\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"12\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M252 582L286 469M743 581L710 468\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"13\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />"
	},
	beta: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#f1e5c9\" /><path d=\"M412 379L351 421L205 363L176 435L337 542L367 793L333 938H463L497 783H530L562 938H692L660 793L685 542L842 431L813 359L674 421L611 379L626 232Q618 114 513 115Q404 114 397 232Z\" fill=\"#668870\" stroke=\"#19211f\" stroke-width=\"18\" stroke-linejoin=\"round\"/><rect x=\"443\" y=\"251\" width=\"38\" height=\"38\" rx=\"5\" fill=\"#f1e5c9\" /><rect x=\"548\" y=\"251\" width=\"38\" height=\"38\" rx=\"5\" fill=\"#f1e5c9\" /><circle cx=\"514\" cy=\"520\" r=\"62\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"15\"/><circle cx=\"514\" cy=\"520\" r=\"28\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"12\"/><path d=\"M513 620V719M513 669L475 641M513 698L548 671\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"12\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M513 175L526 195L513 215L500 195Z\" fill=\"#f1e5c9\" /><path d=\"M232 405L319 469M792 402L706 469\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"11\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />"
	},
	gamma: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#f1e5c9\" /><path d=\"M419 365Q409 240 512 189Q614 240 604 365L692 382Q785 412 802 549L835 707L766 748L690 649L690 814L749 920H563L548 842H475L459 920H275L334 814L335 649L258 748L189 707L222 549Q239 412 331 382Z\" fill=\"#c6a254\" stroke=\"#19211f\" stroke-width=\"19\" stroke-linejoin=\"round\"/><path d=\"M443 312Q468 274 496 307L485 336L458 337ZM532 307Q563 275 586 313L571 337H543Z\" fill=\"#f1e5c9\" /><path d=\"M504 517C579 474 643 551 607 623C572 690 465 668 451 607C436 549 514 525 542 567C566 605 522 630 503 596\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"20\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M373 437L350 530M652 438L677 531\" fill=\"none\" stroke=\"#19211f\" stroke-width=\"13\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M515 385L533.85 414L515 443L496.15 414Z\" fill=\"#f1e5c9\" />"
	},
	cat: {
		viewBox: "0 0 1024 1024",
		body: "<rect x=\"0\" y=\"0\" width=\"1024\" height=\"1024\" rx=\"0\" fill=\"#f1e5c9\" /><path d=\"M371 466L348 224L443 306L581 301L692 220L658 473C741 535 747 701 692 798C749 839 830 808 840 754C850 703 788 683 779 723C776 741 794 752 804 739C818 788 754 807 724 763C675 700 752 621 825 669C939 744 854 924 715 894L620 874Q512 935 407 876C278 882 223 820 261 737C291 672 370 695 360 744C347 714 312 736 324 773C338 812 391 798 401 764C356 674 300 573 371 466Z\" fill=\"#19211f\" /><path d=\"M393 349L424 380L397 406ZM616 379L648 345L641 405Z\" fill=\"#baa36e\" /><path d=\"M398 441L482 423L461 466ZM543 424L624 443L562 466Z\" fill=\"#f1e5c9\" /><path d=\"M490 482L532 482L512 504Z\" fill=\"#baa36e\" /><path d=\"M512 501V523M512 523L483 534M512 523L541 534M351 492L455 511M341 526L453 532M570 510L676 489M571 533L684 524\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"8\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M512 558L532.15 589L512 620L491.85 589Z\" fill=\"#baa36e\" /><path d=\"M466 687L456 812M556 686L569 812\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />"
	},
	landscapes: {
		viewBox: "0 0 1024 1024",
		body: "<g transform=\"translate(0,0)\"><rect x=\"0\" y=\"0\" width=\"512\" height=\"512\" rx=\"0\" fill=\"#f1e5c9\" /><circle cx=\"402\" cy=\"83\" r=\"34\" fill=\"#baa36e\" /><path d=\"M0 363L115 151L168 226L288 51L408 264L459 211L512 347V512H0Z\" fill=\"#142e2a\" /><path d=\"M117 154L166 228L139 219L124 239L109 202ZM287 51L342 150L307 128L289 150L270 130L240 137Z\" fill=\"#baa36e\" /><path d=\"M0 402L151 303L255 397L354 259L512 387V512H0Z\" fill=\"#254b3e\" /><path d=\"M279 232L241 305L312 348L219 422L267 512H344L275 423L351 347L273 302Z\" fill=\"#f1e5c9\" /></g><g transform=\"translate(512,0)\"><rect x=\"0\" y=\"0\" width=\"512\" height=\"512\" rx=\"0\" fill=\"#142e2a\" /><path d=\"M0 0H512V512H435L424 274L352 158L247 116L142 204L85 331L78 512H0Z\" fill=\"#19211f\" /><path d=\"M0 0H512V96L449 139L403 66L332 108L249 51L184 94L117 68L53 153L0 110Z\" fill=\"#254b3e\" /><path d=\"M52 61L77 195L105 90L126 170L153 73M327 73L347 207L376 86L401 191L426 59\" fill=\"#baa36e\" /><path d=\"M238 324L293 367L215 411L298 512H369L278 413L339 368L272 318Z\" fill=\"#f1e5c9\" /><path d=\"M0 512L42 397L105 425L136 391L191 512ZM371 512L423 391L464 419L499 376L512 512Z\" fill=\"#254b3e\" /></g><g transform=\"translate(0,512)\"><rect x=\"0\" y=\"0\" width=\"512\" height=\"512\" rx=\"0\" fill=\"#f1e5c9\" /><circle cx=\"397\" cy=\"92\" r=\"31\" fill=\"#baa36e\" /><path d=\"M0 301L134 202L248 290L344 193L512 291V512H0Z\" fill=\"#254b3e\" /><g transform=\"translate(94,185) scale(1)\"><path d=\"M-9 70H9V220H-9Z\" fill=\"#19211f\" /><path d=\"M0-55L-66 29H-40L-85 89H-42L-98 148H98L43 89H85L40 29H66Z\" fill=\"#142e2a\" /><path d=\"M-9 180L-43 151M9 141L37 114\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(255,120) scale(1.3)\"><path d=\"M-9 70H9V220H-9Z\" fill=\"#19211f\" /><path d=\"M0-55L-66 29H-40L-85 89H-42L-98 148H98L43 89H85L40 29H66Z\" fill=\"#142e2a\" /><path d=\"M-9 180L-43 151M9 141L37 114\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><g transform=\"translate(408,201) scale(0.9)\"><path d=\"M-9 70H9V220H-9Z\" fill=\"#19211f\" /><path d=\"M0-55L-66 29H-40L-85 89H-42L-98 148H98L43 89H85L40 29H66Z\" fill=\"#142e2a\" /><path d=\"M-9 180L-43 151M9 141L37 114\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /></g><path d=\"M0 429Q124 347 253 435Q380 361 512 421V512H0Z\" fill=\"#142e2a\" /></g><g transform=\"translate(512,512)\"><rect x=\"0\" y=\"0\" width=\"512\" height=\"512\" rx=\"0\" fill=\"#f1e5c9\" /><circle cx=\"411\" cy=\"96\" r=\"34\" fill=\"#baa36e\" /><path d=\"M0 280L81 165L163 234L247 183L340 267L424 198L512 264V512H0Z\" fill=\"#254b3e\" /><rect x=\"0\" y=\"297\" width=\"512\" height=\"215\" rx=\"0\" fill=\"#142e2a\" /><ellipse cx=\"140\" cy=\"359\" rx=\"52\" ry=\"8.32\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"5\"/><ellipse cx=\"333\" cy=\"428\" rx=\"79\" ry=\"12.64\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"5\"/><ellipse cx=\"242\" cy=\"321\" rx=\"25\" ry=\"4\" fill=\"none\" stroke=\"#f1e5c9\" stroke-width=\"5\"/><path d=\"M51 465L78 337M451 512L420 341\" fill=\"none\" stroke=\"#baa36e\" stroke-width=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" /><path d=\"M75 365Q32 304 20 340Q23 376 75 392ZM421 376Q464 301 476 338Q471 375 421 398Z\" fill=\"#baa36e\" /></g>"
	},
	mermaid: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M18 48Q3 17 29 12Q48 5 57 23L68 19L62 31L76 49L60 52Q83 80 51 89L20 95L35 74L24 68L28 59ZM42 19L33 22L39 25ZM38 39L25 29L21 48L38 54ZM46 66Q70 83 37 87L54 76Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	king: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M24 16L32 29L48 11L64 29L75 16L70 39H29ZM33 42H67L74 87L61 92L49 80L38 92L25 87ZM39 49L35 57L44 54ZM58 49L53 54L63 57ZM42 64L50 71L58 64L61 75L50 82L39 75Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	fairy: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M47 35Q19 3 10 23Q3 43 37 51Q2 54 12 72Q23 90 46 58L39 94H62L55 58Q81 92 91 70Q99 51 64 49Q99 40 89 20Q78 2 54 35L59 27L54 16H46L41 27ZM49 44L51 44L58 61H42Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	ghost: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M17 86L22 33Q22 9 51 9Q79 9 79 36L86 87L71 75L58 91L45 77L32 90ZM37 36Q29 40 37 47Q45 43 37 36ZM62 36Q55 43 63 47Q71 40 62 36ZM42 61L52 68L62 61L55 76H47Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	skeleton: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M23 35Q19 9 50 9Q81 9 77 36L70 50H61V60H40V50H29ZM35 29L29 37L42 39L44 28ZM59 28L59 39L73 37L66 29ZM48 43L44 49H56L52 43ZM25 58L41 67L25 75L21 69L17 78L25 85L50 73L75 86L84 79L80 69L75 75L58 67L77 59L70 52L50 61L30 51Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	witch: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M12 42L36 30L46 3L62 28L89 41L65 47L70 61L57 67L72 89H25L40 66L30 59L35 47ZM41 49L41 55H46V49ZM56 49V55H61V49ZM19 57L26 59L16 84L8 88L7 77ZM80 56L84 57L80 91L70 91L77 69Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	vampire: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M13 8L38 24H62L87 8L72 56L89 87L60 81L50 94L40 81L11 87L28 56ZM35 29L41 51L50 58L59 51L65 29L52 34L50 31L47 34ZM39 39L45 40V45H39ZM55 40L61 39V45H55ZM43 49L46 56L48 49ZM52 49L55 56L57 49Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	kraken: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M32 40Q19 7 50 7Q81 7 67 40L77 48Q94 47 87 30Q104 56 83 63L67 56Q77 83 89 65Q99 96 73 89L57 65L55 83Q73 104 88 92Q69 109 50 95Q31 109 12 92Q27 103 45 83L43 65L27 89Q1 96 11 65Q23 83 33 56L17 63Q-4 56 13 30Q6 47 23 48ZM36 26L44 29L39 36ZM56 29L64 26L61 36Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	mummy: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M30 15L43 8L65 13L72 28L66 48L76 88L63 94L50 82L36 94L23 89L34 49L25 32ZM31 21L64 17L68 23L34 28ZM34 32L64 28L65 35L40 39ZM39 45L62 39L64 45L37 51ZM34 62L67 54L69 61L32 71ZM31 80L68 72L71 79L30 88Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	pegasus: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M49 39Q16 22 6 6Q6 43 33 54L17 69L24 74L39 63L37 89H47L51 67H62L73 91H85L70 63L85 54L89 33L76 13L65 15L63 30L51 34ZM73 22L77 23L75 27ZM45 40L24 29L29 42L12 31L27 50ZM55 52L73 43L72 53Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	barong: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M23 27L10 15L14 42L5 53L19 59L15 84L35 79L50 95L65 79L85 84L80 59L95 53L87 42L90 15L77 27L65 16L50 9L35 16ZM28 40L38 36L43 47L29 49ZM58 47L63 36L73 40L72 49ZM36 59H64L69 69L50 80L31 69ZM40 62V69H46V62ZM54 62V69H60V62Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	jinn: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M32 16Q51 1 68 17L65 28L74 43L64 56L79 69Q77 91 44 95Q62 81 43 77Q17 71 21 51L35 38L33 28ZM39 23L44 27L41 31ZM57 27L62 23L60 31ZM38 48L31 58L39 61L47 50ZM61 48L53 50L61 61L69 58ZM44 66L61 68L58 73L45 71Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	kyubi: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M36 48Q6 24 9 5Q34 14 42 42Q29 10 46 1Q59 18 51 39Q68 8 89 5Q92 24 62 48Q96 26 98 46Q90 64 69 59Q94 67 85 86L65 73L60 90H41L35 73L15 86Q6 67 31 59Q10 64 2 46Q4 26 36 48ZM37 47L45 57H56L64 47L62 67L50 81L38 67ZM43 64L47 68L46 62ZM54 62L53 68L57 64Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	kappa: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M30 23L26 17L43 21L50 8L57 21L75 17L70 23L82 33L74 53L90 76L78 83L63 68L62 88H38L37 68L22 83L10 76L26 53L18 33ZM29 31L39 35L42 44L31 42ZM60 35L71 31L69 42L58 44ZM36 48L50 41L64 48L50 56ZM36 64L50 58L64 64L60 78H40Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	cyclops: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M18 21L31 31Q50 12 69 31L82 21L77 46L89 69L77 83L65 73L65 93H54L50 79L46 93H35L35 73L23 83L11 69L23 46ZM35 40Q50 26 65 40Q61 57 50 60Q39 57 35 40ZM44 41L50 49L56 41L50 35ZM40 67H60L58 73H42Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	yeti: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M29 12L42 18L50 8L59 18L72 12L75 30L88 51L83 59L96 74L83 87L68 74L65 94H51L50 81L49 94H35L32 74L17 87L4 74L17 59L12 51L25 30ZM33 33L44 39L40 47L30 40ZM57 39L67 33L70 40L60 47ZM35 56L50 62L65 56L62 72L50 77L38 72Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	},
	egg: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M50 7C33 7 17 46 17 65C17 85 31 96 50 96S83 85 83 65C83 46 67 7 50 7ZM50 16L59 37L50 49L41 37ZM26 55L40 61L33 78L22 66ZM74 55L78 66L67 78L60 61ZM41 77L50 67L59 77L50 89Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/><path d=\"M35 48L45 55L42 64L54 58L65 67\" fill=\"none\" stroke=\"#bda46c\" stroke-width=\"3\"/>"
	},
	golem: {
		viewBox: "0 0 100 100",
		body: "<path d=\"M22 21L39 17L49 5L63 16L78 20L74 40L91 48L95 73L81 82L67 66L67 90H55L50 77L45 90H33L33 66L19 82L5 73L9 48L26 40ZM32 29L41 31V38H32ZM59 31L68 29V38H59ZM36 50L50 42L64 50L60 67L50 73L40 67ZM45 51V62H55V51Z\" fill=\"#19211f\" fill-rule=\"evenodd\"/>"
	}
}, K = {
	red: "games.eternaldecks.red",
	blue: "games.eternaldecks.blue",
	green: "games.eternaldecks.green",
	yellow: "games.eternaldecks.yellow",
	purple: "games.eternaldecks.purple",
	white: "games.eternaldecks.white"
}, q = {
	phoenix: "games.eternaldecks.creatures.phoenix",
	mermaid: "games.eternaldecks.creatures.mermaid",
	king: "games.eternaldecks.creatures.king",
	fairy: "games.eternaldecks.creatures.fairy",
	ghost: "games.eternaldecks.creatures.ghost",
	skeleton: "games.eternaldecks.creatures.skeleton",
	witch: "games.eternaldecks.creatures.witch",
	vampire: "games.eternaldecks.creatures.vampire",
	medusa: "games.eternaldecks.creatures.medusa",
	minotaur: "games.eternaldecks.creatures.minotaur",
	kraken: "games.eternaldecks.creatures.kraken",
	mummy: "games.eternaldecks.creatures.mummy",
	pegasus: "games.eternaldecks.creatures.pegasus",
	barong: "games.eternaldecks.creatures.barong",
	jinn: "games.eternaldecks.creatures.jinn",
	kyubi: "games.eternaldecks.creatures.kyubi",
	kappa: "games.eternaldecks.creatures.kappa",
	cyclops: "games.eternaldecks.creatures.cyclops",
	yeti: "games.eternaldecks.creatures.yeti",
	golem: "games.eternaldecks.creatures.golem",
	cat: "games.eternaldecks.creatures.cat"
}, Gt = {
	camp: "games.eternaldecks.fields.camp",
	mountain: "games.eternaldecks.fields.mountain",
	cave: "games.eternaldecks.fields.cave",
	forest: "games.eternaldecks.fields.forest",
	lake: "games.eternaldecks.fields.lake",
	grassland: "games.eternaldecks.fields.grassland",
	riverside: "games.eternaldecks.fields.riverside",
	valley: "games.eternaldecks.fields.valley",
	desert: "games.eternaldecks.fields.desert",
	swamp: "games.eternaldecks.fields.swamp",
	labyrinth: "games.eternaldecks.fields.labyrinth",
	castle: "games.eternaldecks.fields.castle",
	lostForest: "games.eternaldecks.fields.lostForest",
	fog: "games.eternaldecks.fields.fog",
	festival: "games.eternaldecks.fields.festival"
}, Kt = {
	camp: "games.eternaldecks.fieldRules.camp",
	mountain: "games.eternaldecks.fieldRules.mountain",
	cave: "games.eternaldecks.fieldRules.cave",
	forest: "games.eternaldecks.fieldRules.forest",
	lake: "games.eternaldecks.fieldRules.lake",
	grassland: "games.eternaldecks.fieldRules.grassland",
	riverside: "games.eternaldecks.fieldRules.riverside",
	valley: "games.eternaldecks.fieldRules.valley",
	desert: "games.eternaldecks.fieldRules.desert",
	swamp: "games.eternaldecks.fieldRules.swamp",
	labyrinth: "games.eternaldecks.fieldRules.labyrinth",
	castle: "games.eternaldecks.fieldRules.castle",
	lostForest: "games.eternaldecks.fieldRules.lostForest",
	fog: "games.eternaldecks.fieldRules.fog",
	festival: "games.eternaldecks.fieldRules.festival"
}, qt = {
	any2: "games.eternaldecks.recipes.any2",
	any3: "games.eternaldecks.recipes.any3",
	color3: "games.eternaldecks.recipes.color3",
	different3: "games.eternaldecks.recipes.different3",
	edge: "games.eternaldecks.recipes.edge",
	number2: "games.eternaldecks.recipes.number2",
	number3: "games.eternaldecks.recipes.number3",
	159: "games.eternaldecks.recipes.159",
	holding: "games.eternaldecks.recipes.holding",
	riverColors: "games.eternaldecks.recipes.riverColors",
	riverFive: "games.eternaldecks.recipes.riverFive",
	riverRB: "games.eternaldecks.recipes.riverRB",
	riverGY: "games.eternaldecks.recipes.riverGY",
	cat: "games.eternaldecks.recipes.cat",
	golem0: "games.eternaldecks.recipes.golem0",
	golem1: "games.eternaldecks.recipes.golem1",
	golem2: "games.eternaldecks.recipes.golem2"
}, Jt = {
	phoenix: "games.eternaldecks.curses.phoenix",
	mermaid: "games.eternaldecks.curses.mermaid",
	king: "games.eternaldecks.curses.king",
	fairy: "games.eternaldecks.curses.fairy",
	ghost: "games.eternaldecks.curses.ghost",
	skeleton: "games.eternaldecks.curses.skeleton",
	witch: "games.eternaldecks.curses.witch",
	vampire: "games.eternaldecks.curses.vampire",
	medusa: "games.eternaldecks.curses.medusa",
	minotaur: "games.eternaldecks.curses.minotaur",
	kraken: "games.eternaldecks.curses.kraken",
	mummy: "games.eternaldecks.curses.mummy",
	pegasus: "games.eternaldecks.curses.pegasus",
	barong: "games.eternaldecks.curses.barong",
	jinn: "games.eternaldecks.curses.jinn",
	kyubi: "games.eternaldecks.curses.kyubi",
	kappa: "games.eternaldecks.curses.kappa",
	cyclops: "games.eternaldecks.curses.cyclops",
	yeti: "games.eternaldecks.curses.yeti",
	golem: "games.eternaldecks.curses.golem",
	cat: "games.eternaldecks.curses.cat"
}, Yt = {
	phoenix: "games.eternaldecks.abilities.phoenix",
	mermaid: "games.eternaldecks.abilities.mermaid",
	king: "games.eternaldecks.abilities.king",
	fairy: "games.eternaldecks.abilities.fairy",
	ghost: "games.eternaldecks.abilities.ghost",
	skeleton: "games.eternaldecks.abilities.skeleton",
	witch: "games.eternaldecks.abilities.witch",
	vampire: "games.eternaldecks.abilities.vampire",
	medusa: "games.eternaldecks.abilities.medusa",
	minotaur: "games.eternaldecks.abilities.minotaur",
	kraken: "games.eternaldecks.abilities.kraken",
	mummy: "games.eternaldecks.abilities.mummy",
	pegasus: "games.eternaldecks.abilities.pegasus",
	barong: "games.eternaldecks.abilities.barong",
	jinn: "games.eternaldecks.abilities.jinn",
	kyubi: "games.eternaldecks.abilities.kyubi",
	kappa: "games.eternaldecks.abilities.kappa",
	cyclops: "games.eternaldecks.abilities.cyclops",
	yeti: "games.eternaldecks.abilities.yeti",
	golem: "games.eternaldecks.abilities.golem",
	cat: "games.eternaldecks.abilities.cat"
}, Xt = {
	draw2: "games.eternaldecks.upgrades.draw2",
	drawRandom: "games.eternaldecks.upgrades.drawRandom",
	give: "games.eternaldecks.upgrades.give",
	ignore: "games.eternaldecks.upgrades.ignore",
	storeOther: "games.eternaldecks.upgrades.storeOther",
	giveAll: "games.eternaldecks.upgrades.giveAll",
	river: "games.eternaldecks.upgrades.river",
	giveDisc: "games.eternaldecks.upgrades.giveDisc",
	remove: "games.eternaldecks.upgrades.remove",
	wild: "games.eternaldecks.upgrades.wild",
	redColor: "games.eternaldecks.upgrades.redColor",
	redNumber: "games.eternaldecks.upgrades.redNumber",
	fourJewels: "games.eternaldecks.upgrades.fourJewels",
	greenGive: "games.eternaldecks.upgrades.greenGive",
	blueCards: "games.eternaldecks.upgrades.blueCards",
	blueDisc: "games.eternaldecks.upgrades.blueDisc",
	yellowIgnore: "games.eternaldecks.upgrades.yellowIgnore",
	refill4: "games.eternaldecks.upgrades.refill4",
	chooseEternals: "games.eternaldecks.upgrades.chooseEternals"
}, Zt = {
	revive: "games.eternaldecks.choices.revive",
	camp: "games.eternaldecks.choices.camp",
	purple: "games.eternaldecks.choices.purple",
	white: "games.eternaldecks.choices.white",
	gatekeeper: "games.eternaldecks.choices.gatekeeper",
	jewel: "games.eternaldecks.choices.jewel",
	recover: "games.eternaldecks.choices.recover",
	minotaur: "games.eternaldecks.choices.minotaur",
	riverTake: "games.eternaldecks.choices.riverTake",
	draw: "games.eternaldecks.choices.draw",
	riverRecipe: "games.eternaldecks.choices.riverRecipe",
	riverSpecial: "games.eternaldecks.choices.riverSpecial",
	discColor: "games.eternaldecks.choices.discColor",
	keyBonus: "games.eternaldecks.choices.keyBonus",
	storyDraw: "games.eternaldecks.choices.storyDraw",
	storyGive: "games.eternaldecks.choices.storyGive",
	storyRemove: "games.eternaldecks.choices.storyRemove",
	storyWild: "games.eternaldecks.choices.storyWild",
	task: "games.eternaldecks.choices.task",
	eternal: "games.eternaldecks.choices.eternal"
}, Qt = {
	river: "games.eternaldecks.losses.river",
	enemy: "games.eternaldecks.losses.enemy",
	blocked: "games.eternaldecks.losses.blocked",
	earlyStar: "games.eternaldecks.losses.earlyStar",
	startingTask: "games.eternaldecks.losses.startingTask"
}, $t = {
	starting: "games.eternaldecks.taskRules.starting",
	number: "games.eternaldecks.taskRules.number",
	star: "games.eternaldecks.taskRules.star",
	jewel: "games.eternaldecks.taskRules.jewel",
	lateJewel: "games.eternaldecks.taskRules.lateJewel",
	column: "games.eternaldecks.taskRules.column",
	rareHand: "games.eternaldecks.taskRules.rareHand",
	rarePair: "games.eternaldecks.taskRules.rarePair"
}, en = {
	A: "games.eternaldecks.goals.A",
	B: "games.eternaldecks.goals.B",
	C: "games.eternaldecks.goals.C",
	D: "games.eternaldecks.goals.D",
	E: "games.eternaldecks.goals.E",
	F: "games.eternaldecks.goals.F",
	"A+": "games.eternaldecks.goals.A+",
	"B+": "games.eternaldecks.goals.B+",
	"C+": "games.eternaldecks.goals.C+",
	"D+": "games.eternaldecks.goals.D+",
	"E+": "games.eternaldecks.goals.E+"
}, J = {
	red: "#b44b49",
	blue: "#487c9b",
	green: "#668870",
	yellow: "#cfaa54",
	purple: "#8c72ac",
	white: "#f1e5c9"
};
function Y({ id: e, className: t = "" }) {
	let n = Wt[e];
	return n ? /* @__PURE__ */ g("svg", {
		"aria-hidden": "true",
		className: `ed-art ${t}`,
		viewBox: n.viewBox,
		dangerouslySetInnerHTML: { __html: n.body }
	}) : null;
}
function X({ selected: e = !1 }) {
	return /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("svg", {
		"aria-hidden": "true",
		className: `ed-ant ${e ? "ed-ant-selected" : ""}`,
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ g("rect", {
			x: "1",
			y: "1",
			width: "calc(100% - 2px)",
			height: "calc(100% - 2px)",
			rx: "5",
			vectorEffect: "non-scaling-stroke"
		})
	}), e && /* @__PURE__ */ g("span", {
		className: "ed-selection-check",
		"aria-hidden": "true",
		children: "✓"
	})] });
}
function tn({ filled: e = !1 }) {
	return /* @__PURE__ */ _("svg", {
		"aria-hidden": "true",
		className: `ed-gem-token ${e ? "ed-token-filled" : ""}`,
		viewBox: "0 0 20 20",
		children: [/* @__PURE__ */ g("path", { d: "M2 6L6 2H14L18 6L10 18Z" }), /* @__PURE__ */ g("path", { d: "M2 6H18M6 2L10 18L14 2" })]
	});
}
function nn({ filled: e = !1 }) {
	return /* @__PURE__ */ g("svg", {
		"aria-hidden": "true",
		className: `ed-star-token ${e ? "ed-token-filled" : ""}`,
		viewBox: "0 0 28 28",
		children: /* @__PURE__ */ g("path", { d: "M14 2L17.5 10.3L26.5 11L19.5 17L21.7 26L14 21L6.3 26L8.5 17L1.5 11L10.5 10.3Z" })
	});
}
function rn({ filled: e = !0 }) {
	return /* @__PURE__ */ g("svg", {
		"aria-hidden": "true",
		className: `ed-heart-token ${e ? "ed-token-filled" : ""}`,
		viewBox: "0 0 24 24",
		children: /* @__PURE__ */ g("path", { d: "M12 21C-4 11 2-3 12 5C22-3 28 11 12 21Z" })
	});
}
function an({ count: e }) {
	return /* @__PURE__ */ _("span", {
		className: "ed-deck-token",
		children: [/* @__PURE__ */ _("svg", {
			"aria-hidden": "true",
			viewBox: "0 0 22 26",
			children: [/* @__PURE__ */ g("rect", {
				x: "5",
				y: "5",
				width: "15",
				height: "20",
				rx: "1",
				fill: "#29483d",
				stroke: "#baa36e"
			}), /* @__PURE__ */ g("rect", {
				x: "1",
				y: "1",
				width: "15",
				height: "20",
				rx: "1",
				fill: "#29483d",
				stroke: "#f1e5c9"
			})]
		}), /* @__PURE__ */ g("b", { children: e })]
	});
}
function on() {
	return /* @__PURE__ */ _("svg", {
		"aria-hidden": "true",
		className: "ed-key-token",
		viewBox: "0 0 20 20",
		children: [/* @__PURE__ */ g("circle", {
			cx: "6",
			cy: "6",
			r: "4"
		}), /* @__PURE__ */ g("path", { d: "M9 9L18 18M13 13L16 10M16 16L19 13" })]
	});
}
function Z({ id: e, flip: t = !1, back: n = !1, compact: i = !1, className: a = "" }) {
	let o = r().replace(/:/g, ""), s = e ? x[e] : void 0, c = s?.colors.length ? t ? [...s.colors].reverse() : s.colors : [], l = "#19211f", u = "#f1e5c9", d = c[0] === "yellow" || c[0] === "white" ? l : u, f = s?.kind === "ability" ? Wt[s.effect ?? ""] ?? (s.source.startsWith("gk") ? Wt.gatekeeper : void 0) : void 0, p = i ? 76 : 102;
	return /* @__PURE__ */ _("svg", {
		"aria-hidden": "true",
		className: `ed-card-face ${a}`,
		viewBox: `0 0 72 ${p}`,
		preserveAspectRatio: "none",
		children: [
			/* @__PURE__ */ _("defs", { children: [/* @__PURE__ */ g("clipPath", {
				id: o,
				children: /* @__PURE__ */ g("rect", {
					x: "1",
					y: "1",
					width: "70",
					height: p - 2,
					rx: "5"
				})
			}), c.map((e, t) => /* @__PURE__ */ g("pattern", {
				id: `${o}-pattern-${t}`,
				width: "18",
				height: "18",
				patternUnits: "userSpaceOnUse",
				children: /* @__PURE__ */ g("g", {
					fill: "none",
					stroke: e === "yellow" ? l : u,
					strokeWidth: "1.2",
					children: e === "red" ? /* @__PURE__ */ g("path", { d: "M-4 4L4-4M0 18L18 0M14 22L22 14" }) : e === "blue" ? /* @__PURE__ */ g("path", { d: "M-4 9Q.5 2 5 9T14 9T23 9" }) : e === "green" ? /* @__PURE__ */ g("path", { d: "M9 0L18 9L9 18L0 9Z" }) : e === "yellow" ? /* @__PURE__ */ g("circle", {
						cx: "9",
						cy: "9",
						r: "5"
					}) : /* @__PURE__ */ g("path", { d: "M4 4H14V14H4Z" })
				})
			}, t))] }),
			/* @__PURE__ */ _("g", {
				clipPath: `url(#${o})`,
				children: [
					/* @__PURE__ */ g("rect", {
						width: "72",
						height: p,
						fill: n ? "#254b3e" : c.length ? J[c[0]] : u
					}),
					c.length === 2 && /* @__PURE__ */ g("path", {
						d: `M72 0V${p}H0Z`,
						fill: J[c[1]]
					}),
					!n && c.length > 0 && /* @__PURE__ */ g("g", {
						opacity: ".2",
						children: c.length === 2 ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("path", {
							d: `M0 0H72L0 ${p}Z`,
							fill: `url(#${o}-pattern-0)`
						}), /* @__PURE__ */ g("path", {
							d: `M72 0V${p}H0Z`,
							fill: `url(#${o}-pattern-1)`
						})] }) : /* @__PURE__ */ g("rect", {
							width: "72",
							height: p,
							fill: `url(#${o}-pattern-0)`
						})
					}),
					/* @__PURE__ */ g("rect", {
						x: "4",
						y: "4",
						width: "64",
						height: p - 8,
						rx: "3",
						fill: "none",
						stroke: d,
						opacity: ".3"
					}),
					n ? /* @__PURE__ */ _("g", {
						stroke: u,
						fill: "none",
						opacity: ".75",
						children: [
							/* @__PURE__ */ g("path", { d: "M36 22L58 51L36 80L14 51Z" }),
							/* @__PURE__ */ g("circle", {
								cx: "36",
								cy: "51",
								r: "14"
							}),
							/* @__PURE__ */ g("path", { d: "M36 37L48 58H24Z" })
						]
					}) : s?.kind === "number" ? /* @__PURE__ */ _(h, { children: [
						/* @__PURE__ */ g("text", {
							x: "36",
							y: p * .66,
							fill: d,
							fontSize: i ? 43 : 46,
							fontFamily: "Bahnschrift,Arial,sans-serif",
							textAnchor: "middle",
							fontWeight: "bold",
							children: s.value
						}),
						/* @__PURE__ */ g("text", {
							x: "6",
							y: "16",
							fill: d,
							fontSize: "14",
							fontFamily: "Bahnschrift,Arial,sans-serif",
							children: s.value
						}),
						/* @__PURE__ */ g("text", {
							x: "66",
							y: p - 7,
							fill: c.length === 1 ? d : c[1] === "yellow" || c[1] === "white" ? l : u,
							fontSize: "14",
							fontFamily: "Bahnschrift,Arial,sans-serif",
							textAnchor: "end",
							children: s.value
						})
					] }) : s?.kind === "skull" ? /* @__PURE__ */ _("g", {
						fill: d,
						transform: i ? "translate(0 -1) scale(1 .76)" : void 0,
						children: [/* @__PURE__ */ g("path", {
							d: "M19 43Q14 23 36 23Q58 23 53 43L47 53V63H25V53ZM24 36V43H31V36ZM41 36V43H48V36ZM36 46L32 52H40Z",
							fillRule: "evenodd"
						}), /* @__PURE__ */ g("path", {
							d: "M20 70L49 81M23 81L52 70",
							stroke: d,
							strokeWidth: "4"
						})]
					}) : s?.kind === "camp" ? /* @__PURE__ */ g("path", {
						transform: i ? "scale(1 .76)" : void 0,
						d: "M36 25L59 76H13Z M36 45L27 76H45Z",
						fill: l,
						fillRule: "evenodd"
					}) : f ? /* @__PURE__ */ g("svg", {
						x: "7",
						y: i ? 6 : 15,
						width: "58",
						height: i ? 62 : 73,
						viewBox: f.viewBox,
						dangerouslySetInnerHTML: { __html: f.body }
					}) : s?.kind === "ability" ? /* @__PURE__ */ _("g", {
						fill: l,
						transform: i ? "scale(1 .76)" : void 0,
						children: [/* @__PURE__ */ g("path", { d: "M18 32L29 40L36 27L43 40L54 32L50 58L36 74L22 58Z" }), /* @__PURE__ */ g("path", {
							d: "M26 49L31 54M46 49L41 54",
							stroke: u,
							strokeWidth: "3"
						})]
					}) : /* @__PURE__ */ _("g", {
						fill: l,
						transform: i ? "scale(1 .76)" : void 0,
						children: [/* @__PURE__ */ g("path", { d: "M36 27L59 44L36 77L13 44Z" }), /* @__PURE__ */ g("path", {
							d: "M13 44H59M25 28L36 77L47 28",
							stroke: u,
							fill: "none",
							strokeWidth: "1.5"
						})]
					})
				]
			}),
			/* @__PURE__ */ g("rect", {
				x: "1",
				y: "1",
				width: "70",
				height: p - 2,
				rx: "5",
				fill: "none",
				stroke: l,
				strokeWidth: "1.5"
			})
		]
	});
}
function sn() {
	let e = c();
	return (t) => {
		let n = x[t];
		return n.kind === "number" ? e("games.eternaldecks.cardName", {
			color: n.colors.map((t) => e(K[t])).join("/"),
			n: n.value
		}) : n.kind === "skull" ? `${n.colors.map((t) => e(K[t])).join("/")} · ${e("games.eternaldecks.skull")}` : n.kind === "ability" ? `${n.effect && n.effect in q ? e(q[n.effect]) : e("games.eternaldecks.heartBonus")} · ${e("games.eternaldecks.abilityCard")}` : e(n.kind === "camp" ? "games.eternaldecks.campCard" : "games.eternaldecks.rare");
	};
}
function Q({ id: e, jewel: t = !1, sleeping: n = !1, small: r = !1 }) {
	let i = c(), a = Object.keys(w).find((t) => w[t].includes(e)) ?? "";
	return /* @__PURE__ */ _("div", {
		className: `ed-eternal ${r ? "ed-eternal-small" : ""} ${n ? "ed-sleeping" : ""}`,
		children: [n ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("svg", {
			className: "ed-sleep-seal",
			"aria-hidden": "true",
			viewBox: "0 0 40 40",
			children: [
				/* @__PURE__ */ g("circle", {
					cx: "20",
					cy: "20",
					r: "17"
				}),
				/* @__PURE__ */ g("circle", {
					cx: "20",
					cy: "20",
					r: "12"
				}),
				/* @__PURE__ */ g("path", { d: "M12 17L16 12H24L28 17L20 28ZM12 17H28M16 12L20 28L24 12" })
			]
		}), /* @__PURE__ */ g("b", {
			className: "ed-sleep-code",
			children: a ? `${a}-${w[a].indexOf(e) + 1}` : "♥"
		})] }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Y, { id: e }), /* @__PURE__ */ g("span", {
			className: "ed-eternal-name",
			children: i(q[e])
		})] }), t && /* @__PURE__ */ g("span", {
			className: "ed-eternal-seal ed-jewel",
			children: /* @__PURE__ */ g(tn, { filled: !0 })
		})]
	});
}
function cn({ id: e, excludedCards: t = [] }) {
	let n = c(), r = sn(), i = (S[e] ?? []).filter((e) => !t.includes(e)), a = w.E.includes(e);
	return /* @__PURE__ */ _(h, { children: [
		/* @__PURE__ */ g(Q, { id: e }),
		/* @__PURE__ */ g("p", { children: n(Jt[e]) }),
		/* @__PURE__ */ g("p", { children: n(Yt[e]) }),
		e !== "cat" && /* @__PURE__ */ _("section", {
			className: "ed-deck-contents",
			children: [/* @__PURE__ */ _("h3", { children: [n("games.eternaldecks.deckContents"), !a && /* @__PURE__ */ g("span", { children: n("games.eternaldecks.cardCount", { n: i.length }) })] }), a ? /* @__PURE__ */ g("p", { children: n("games.eternaldecks.randomDeckContents") }) : /* @__PURE__ */ g("ul", { children: i.map((e) => /* @__PURE__ */ _("li", { children: [/* @__PURE__ */ g(Z, { id: e }), /* @__PURE__ */ g("span", { children: r(e) })] }, e)) })]
		})
	] });
}
function ln({ id: e, selected: t, available: n, flip: r = !1, onClick: i }) {
	let a = sn();
	return /* @__PURE__ */ _("button", {
		className: `ed-hand-card ${t ? "ed-chosen" : ""}`,
		"aria-label": a(e),
		"aria-pressed": t ?? !1,
		onClick: i,
		children: [
			/* @__PURE__ */ g(Z, {
				id: e,
				flip: r,
				compact: !0,
				className: "ed-face-compact"
			}),
			/* @__PURE__ */ g(Z, {
				id: e,
				flip: r,
				className: "ed-face-tall"
			}),
			(t || n) && /* @__PURE__ */ g(X, { selected: t })
		]
	});
}
//#endregion
//#region src/games/eternaldecks/board.tsx
function un({ pub: e, target: t }) {
	let n = c();
	return /* @__PURE__ */ g("span", {
		className: "ed-markers",
		children: e.seats.flatMap((e) => e.markers.flatMap((r, i) => r === t ? [/* @__PURE__ */ g("span", {
			style: { background: J[e.color] },
			title: n(K[e.color]),
			children: e.color[0].toUpperCase()
		}, `${e.owner}:${e.color}:${i}`)] : []))
	});
}
function dn(e, t) {
	if (t.row < 0) return e.river.length;
	let n = e.rows[t.row], r = x[t.card];
	if (r.kind === "skull") return r.colors.includes("white") ? t.column ?? -1 : n.cards.length;
	let i = n.cards.findIndex((e) => x[e.card].kind === "skull");
	return i < 0 ? n.cards.length : i;
}
function fn({ pub: e, index: t, candidates: n, chosen: r, onTarget: i, onField: a, onCard: o, onEternal: l, marker: u }) {
	let d = c(), f = e.rows[t], ee = sn(), m = s((e) => e.locale === "en"), te = {
		mountain: "↑",
		cave: "↓",
		forest: "≠",
		lake: "↻",
		camp: "✦",
		labyrinth: "↔",
		castle: "♜",
		festival: "2"
	}[f.field] ?? "◇", { ref: v, hidden: y } = p(`ed-row:${t}`);
	return /* @__PURE__ */ _("div", {
		className: `ed-row ${f.closed ? "ed-row-closed" : ""}`,
		ref: v,
		style: { visibility: y ? "hidden" : void 0 },
		children: [/* @__PURE__ */ _("div", {
			className: "ed-field-wrap",
			children: [/* @__PURE__ */ _("button", {
				className: "ed-field",
				onClick: () => a(t),
				"aria-label": `${d(Gt[f.field])} · ${d("games.eternaldecks.lap", { n: f.lap + 1 })}`,
				children: [
					/* @__PURE__ */ g("div", {
						className: `ed-landscape ed-landscape-${f.field}`,
						children: /* @__PURE__ */ g(Y, { id: "landscapes" })
					}),
					/* @__PURE__ */ g("b", { children: m ? f.closed ? "◆" : `${f.lap + 1}/4` : d(Gt[f.field]) }),
					/* @__PURE__ */ g("span", {
						className: "ed-field-rule",
						children: te
					})
				]
			}), /* @__PURE__ */ g("span", {
				className: `ed-lap ${m ? "ed-field-name" : ""}`,
				children: m ? d(Gt[f.field]) : f.closed ? "◆" : `${f.lap + 1}/4`
			})]
		}), /* @__PURE__ */ g("div", {
			className: "ed-row-slots",
			children: Array.from({ length: 7 }, (a, s) => {
				let c = f.cards[s], p = f.eternals[s - f.capacity], m = n.find((n) => n.row === t && dn(e, n) === s), te = !!m && r?.row === t && dn(e, r) === s, v = e.seats.flatMap((e) => e.markers.filter((e) => e === `row:${t}:${s}`).map(() => e.color));
				return /* @__PURE__ */ _("button", {
					className: `ed-slot ${c || p ? "ed-slot-occupied" : ""} ${m ? "ed-slot-available" : ""} ${te ? "ed-slot-chosen" : ""}`,
					onClick: () => u ? u(`row:${t}:${s}`) : m ? i(m) : p ? l(p) : c ? o(c.card) : void 0,
					disabled: !u && !m && !p && !c,
					"aria-label": m ? d("games.eternaldecks.playTo", { field: d(Gt[f.field]) }) : p ? d(q[p]) : c ? ee(c.card) : `${d("games.eternaldecks.empty")} ${s + 1}`,
					children: [
						c ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Z, {
							id: c.card,
							flip: c.flip
						}), c.under.length > 0 && /* @__PURE__ */ g("span", {
							className: "ed-under",
							children: "☠"
						})] }) : p ? /* @__PURE__ */ g(Q, {
							id: p,
							sleeping: !0,
							small: !0
						}) : /* @__PURE__ */ g("span", {
							className: "ed-slot-glyph",
							children: m ? "+" : /* @__PURE__ */ g(tn, {})
						}),
						(m && !f.closed || u) && /* @__PURE__ */ g(X, { selected: te }),
						/* @__PURE__ */ g("span", {
							className: "ed-markers",
							children: v.map((e, t) => /* @__PURE__ */ g("span", {
								style: { background: J[e] },
								title: d(K[e]),
								children: e[0].toUpperCase()
							}, t))
						})
					]
				}, s);
			})
		})]
	});
}
function pn({ pub: e, onEternal: t, onChoose: n, targets: r = [] }) {
	let i = c(), a = [
		...e.revived,
		...e.holding ? [e.holding] : [],
		...e.seats[e.turn].personal
	].filter((t) => !e.eternals.find((e) => e.id === t)?.jewel), o = [...new Set(a.flatMap((e) => k[e] ?? []))].sort((e, t) => e - t), s = [...new Set(a.flatMap((e) => A[e] ?? []))];
	return /* @__PURE__ */ _("section", {
		className: "ed-revival",
		children: [/* @__PURE__ */ _("div", {
			className: "ed-revival-group",
			children: [/* @__PURE__ */ g("div", {
				className: "ed-zone-label",
				children: i("games.eternaldecks.revival")
			}), /* @__PURE__ */ _("div", {
				className: "ed-revived-cards",
				children: [
					e.revived.map((a, o) => /* @__PURE__ */ _("button", {
						className: `ed-revived-card ${o % 3 == 2 ? "ed-group-end" : ""}`,
						onClick: () => r.includes(a) ? n?.(a) : t(a),
						"aria-label": i(q[a]),
						children: [
							/* @__PURE__ */ g(Q, {
								id: a,
								jewel: !!e.eternals.find((e) => e.id === a)?.jewel,
								small: !0
							}),
							/* @__PURE__ */ g(un, {
								pub: e,
								target: `eternal:${a}`
							}),
							r.includes(a) && /* @__PURE__ */ g(X, {})
						]
					}, a)),
					Array.from({ length: Math.max(0, 3 - e.revived.length) }, (e, t) => /* @__PURE__ */ g("span", {
						className: "ed-revival-empty",
						children: /* @__PURE__ */ g(tn, {})
					}, `empty:${t}`)),
					e.holding && /* @__PURE__ */ _("button", {
						className: "ed-holding",
						onClick: () => r.includes(e.holding) ? n?.(e.holding) : t(e.holding),
						"aria-label": i("games.eternaldecks.holding"),
						children: [
							/* @__PURE__ */ g(Q, {
								id: e.holding,
								jewel: !!e.eternals.find((t) => t.id === e.holding)?.jewel,
								small: !0
							}),
							/* @__PURE__ */ g("span", { children: i("games.eternaldecks.holding") }),
							r.includes(e.holding) && /* @__PURE__ */ g(X, {})
						]
					})
				]
			})]
		}), /* @__PURE__ */ _("div", {
			className: "ed-curse-group",
			children: [/* @__PURE__ */ g("div", {
				className: "ed-zone-label",
				children: i("games.eternaldecks.activeCurse")
			}), /* @__PURE__ */ _("div", {
				className: "ed-curses",
				children: [
					o.map((e) => /* @__PURE__ */ _("span", {
						className: "ed-curse-number",
						children: [e, /* @__PURE__ */ g("i", { children: "×" })]
					}, e)),
					s.map((e) => /* @__PURE__ */ g("span", {
						className: "ed-curse-color",
						style: { background: J[e] },
						title: i(K[e]),
						children: /* @__PURE__ */ g("svg", {
							viewBox: "0 0 26 26",
							"aria-hidden": "true",
							children: /* @__PURE__ */ g("path", { d: "M3 23L23 3" })
						})
					}, e)),
					a.includes("witch") && /* @__PURE__ */ _("span", {
						className: "ed-curse-number",
						children: ["◆", /* @__PURE__ */ g("i", { children: "×" })]
					}),
					o.length === 0 && s.length === 0 && !a.includes("witch") && /* @__PURE__ */ g("span", {
						className: "ed-muted",
						children: i("games.eternaldecks.noCurse")
					}),
					a.length === 1 && (o.length > 0 || s.length > 0) && /* @__PURE__ */ g("span", {
						className: "ed-curse-description",
						children: i(Jt[a[0]])
					}),
					a.filter((e) => [
						"pegasus",
						"barong",
						"jinn",
						"kyubi"
					].includes(e)).map((e) => /* @__PURE__ */ g("span", {
						className: "ed-power-chip",
						children: i(q[e])
					}, e))
				]
			})]
		})]
	});
}
function mn({ pub: e, candidates: t, chosen: n, onTarget: r, onCard: i, marker: a }) {
	let o = c(), s = t.find((e) => e.row === -1), l = sn(), { ref: u, hidden: d } = p("ed-river");
	return /* @__PURE__ */ _("section", {
		className: "ed-river",
		ref: u,
		style: { visibility: d ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ g("span", {
				className: "ed-river-label",
				children: o("games.eternaldecks.riverLabel")
			}),
			/* @__PURE__ */ _("div", {
				className: `ed-river-cards ${e.river.length + (s || a ? 1 : 0) > 5 ? "ed-river-scrolling" : ""}`,
				children: [
					e.river.map((e) => /* @__PURE__ */ g("button", {
						className: "ed-river-card",
						onClick: () => i(e),
						"aria-label": l(e),
						children: /* @__PURE__ */ g(Z, { id: e })
					}, e)),
					Array.from({ length: Math.max(0, 5 - e.river.length) }, (e, t) => t === 0 && (s || a) ? /* @__PURE__ */ _("button", {
						className: "ed-river-target",
						onClick: () => a ? a("river") : s ? r(s) : void 0,
						"aria-label": o("games.eternaldecks.playTo", { field: o("games.eternaldecks.river") }),
						children: [/* @__PURE__ */ g("span", { children: "+" }), /* @__PURE__ */ g(X, { selected: n?.row === -1 })]
					}, t) : /* @__PURE__ */ g("span", {
						className: "ed-river-empty",
						children: /* @__PURE__ */ g(tn, {})
					}, t)),
					e.river.length >= 5 && (s || a) && /* @__PURE__ */ _("button", {
						className: "ed-river-target",
						onClick: () => a ? a("river") : s ? r(s) : void 0,
						"aria-label": o("games.eternaldecks.playTo", { field: o("games.eternaldecks.river") }),
						children: [/* @__PURE__ */ g("span", { children: "+" }), /* @__PURE__ */ g(X, {})]
					}),
					/* @__PURE__ */ g(un, {
						pub: e,
						target: "river"
					})
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "ed-river-supply",
				children: [e.dragon ? /* @__PURE__ */ g(Y, { id: "dragon" }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Z, { id: e.riverRewards[0] }), /* @__PURE__ */ g("b", { children: e.riverRewards.length })] }), /* @__PURE__ */ g("span", { children: o(e.dragon ? "games.eternaldecks.dragon" : "games.eternaldecks.riverRewards") })]
			})
		]
	});
}
//#endregion
//#region src/games/eternaldecks/campaign-panel.tsx
function hn({ campaign: e, actions: t, send: n, initialSeat: r = 0 }) {
	let i = c(), o = [
		i("games.eternaldecks.alpha"),
		i("games.eternaldecks.beta"),
		i("games.eternaldecks.gamma")
	], [s, l] = a(r);
	return /* @__PURE__ */ _("div", {
		className: "ed-campaign-panel",
		children: [
			/* @__PURE__ */ _("div", {
				className: "ed-campaign-score",
				children: [/* @__PURE__ */ _("b", { children: [
					i("games.eternaldecks.starPoints"),
					" ✦ ",
					e.points
				] }), /* @__PURE__ */ _("span", { children: [
					i("games.eternaldecks.score"),
					" ",
					me(e)
				] })]
			}),
			/* @__PURE__ */ g("div", {
				className: "ed-chapter-path",
				children: [
					"A",
					"B",
					"C",
					"D",
					"E"
				].map((t, n) => /* @__PURE__ */ _("div", {
					className: n === e.chapter ? "ed-current-chapter" : "",
					children: [
						/* @__PURE__ */ g("b", { children: t }),
						/* @__PURE__ */ g("span", { children: e.scores[n] ?? "—" }),
						/* @__PURE__ */ g("span", { children: e.failures[n] ? `×${e.failures[n]}` : "·" })
					]
				}, t))
			}),
			/* @__PURE__ */ g("div", {
				className: "ed-campaign-golems",
				children: o.map((e, t) => /* @__PURE__ */ _("button", {
					"aria-pressed": s === t,
					onClick: () => l(t),
					children: [/* @__PURE__ */ g(Y, { id: [
						"alpha",
						"beta",
						"gamma"
					][t] }), /* @__PURE__ */ g("span", { children: e })]
				}, t))
			}),
			[s].map((r) => /* @__PURE__ */ _("section", {
				className: "ed-golem-record",
				children: [
					/* @__PURE__ */ _("div", {
						className: "ed-golem-record-head",
						children: [
							/* @__PURE__ */ g(Y, { id: [
								"alpha",
								"beta",
								"gamma"
							][r] }),
							/* @__PURE__ */ g("b", { children: o[r] }),
							/* @__PURE__ */ g("span", { children: i("games.eternaldecks.stored") })
						]
					}),
					/* @__PURE__ */ g("div", {
						className: "ed-stored-cards",
						children: e.stored[r].map((e) => /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g(Z, { id: e.card }), /* @__PURE__ */ g("span", { children: [
							"A",
							"B",
							"C",
							"D",
							"E"
						][e.chapter] })] }, e.card))
					}),
					/* @__PURE__ */ g("div", {
						className: "ed-upgrade-tree",
						children: P.filter((e) => e.seat === r).map((a) => {
							let o = t.find((e) => e.type === "buy" && e.seat === r && e.upgrade === a.id), s = e.upgrades[r].includes(a.id);
							return /* @__PURE__ */ _("button", {
								disabled: !o,
								className: `ed-upgrade ${s ? "ed-upgrade-done" : ""}`,
								onClick: () => o && n(o),
								children: [
									/* @__PURE__ */ g("span", { children: s ? "◆" : "◇".repeat(a.cost) }),
									/* @__PURE__ */ g("span", { children: i(Xt[a.id]) }),
									o && /* @__PURE__ */ g(X, {})
								]
							}, a.id);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "ed-modifications",
						children: le[r].map((a, o) => {
							let s = t.find((e) => e.type === "modify" && e.seat === r && e.modification === o), c = e.modifications[r].includes(o);
							return /* @__PURE__ */ _("button", {
								className: `ed-upgrade ${c ? "ed-upgrade-done" : ""}`,
								disabled: !s,
								onClick: () => s && n(s),
								children: [
									/* @__PURE__ */ g("span", { children: c ? "⬢" : "⬡" }),
									/* @__PURE__ */ g("span", { children: i(Xt[a]) }),
									s && /* @__PURE__ */ g(X, {})
								]
							}, a);
						})
					})
				]
			}, r)),
			/* @__PURE__ */ g("p", { children: i(e.catFound ? e.catUsed ? "games.eternaldecks.catUsed" : "games.eternaldecks.catUnused" : "games.eternaldecks.catNotFound") })
		]
	});
}
//#endregion
//#region src/games/eternaldecks/stage-panel.tsx
function gn({ id: e }) {
	let t = ce[e];
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 66 62",
		className: "ed-puzzle",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ g("rect", {
				x: "1",
				y: "1",
				width: "64",
				height: "60",
				rx: "4",
				fill: "#dccfb2",
				stroke: "#19211f"
			}),
			/* @__PURE__ */ g("text", {
				x: "5",
				y: "11",
				fill: "#19211f",
				fontSize: "8",
				children: "✦".repeat(t.level)
			}),
			t.cells.map((e, t) => /* @__PURE__ */ g("rect", {
				x: 13 + e.column * 14,
				y: 16 + e.row * 14,
				width: "11",
				height: "12",
				rx: "1",
				fill: J[e.color]
			}, t))
		]
	});
}
function _n({ pub: e, onDetails: t }) {
	let n = c(), r = e.stage[0], { ref: i, hidden: a } = p("ed-stage"), o = r === "F" ? O : e.seats.length === 3 ? D : E, s = o.filter((t) => !e.recipes.includes(t)).length;
	return /* @__PURE__ */ _("div", {
		className: `ed-stage-panel ed-stage-${r}`,
		ref: i,
		style: { visibility: a ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ g("button", {
				className: "ed-stage-inspect",
				onClick: t,
				"aria-label": n(en[e.stage])
			}),
			e.campaign ? /* @__PURE__ */ _("div", {
				className: "ed-story-progress",
				children: [/* @__PURE__ */ g("div", {
					className: "ed-story-path",
					children: [
						"A",
						"B",
						"C",
						"D",
						"E"
					].map((t, n) => /* @__PURE__ */ g("span", {
						className: n <= e.campaign.chapter ? "ed-chapter-lit" : "",
						"aria-current": n === e.campaign.chapter ? "step" : void 0,
						children: t
					}, t))
				}), /* @__PURE__ */ _("div", { children: [
					/* @__PURE__ */ _("span", { children: [
						r === "A" ? /* @__PURE__ */ g(nn, { filled: !0 }) : /* @__PURE__ */ g(on, {}),
						" ",
						r === "A" ? e.stars.length : e.keys.length,
						"/4"
					] }),
					/* @__PURE__ */ _("span", { children: [
						/* @__PURE__ */ g(tn, { filled: !0 }),
						" ",
						s,
						"/",
						o.length
					] }),
					/* @__PURE__ */ g("span", { children: n("games.eternaldecks.chapterFailures", { n: e.campaign.failures[e.campaign.chapter] }) })
				] })]
			}) : r === "A" ? /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("span", {
					className: "ed-stage-label",
					children: n("games.eternaldecks.stars")
				}),
				/* @__PURE__ */ _("div", {
					className: "ed-star-orbit",
					children: [Array.from({ length: 4 }, (t, n) => /* @__PURE__ */ g(nn, { filled: n < e.stars.length }, n)), /* @__PURE__ */ _("b", { children: [e.stars.length, "/4"] })]
				}),
				/* @__PURE__ */ g("span", {
					className: "ed-ability-progress",
					children: n("games.eternaldecks.abilityProgress", { n: e.aAbilities.length })
				}),
				/* @__PURE__ */ _("div", {
					className: "ed-jewel-progress",
					children: [/* @__PURE__ */ g("span", { children: n("games.eternaldecks.jewels") }), /* @__PURE__ */ g("div", { children: o.map((t) => /* @__PURE__ */ g(tn, { filled: !e.recipes.includes(t) }, t)) })]
				})
			] }) : r === "C" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
				className: "ed-puzzle-label",
				children: [/* @__PURE__ */ g("span", { children: n("games.eternaldecks.puzzleLevel", { n: Math.min(4, e.puzzleLevel + 1) }) }), /* @__PURE__ */ _("b", { children: [
					/* @__PURE__ */ g(on, {}),
					" ",
					e.keys.length,
					"/4"
				] })]
			}), /* @__PURE__ */ g("div", {
				className: "ed-puzzle-pair",
				children: e.puzzles.map((e) => /* @__PURE__ */ g(gn, { id: e }, e))
			})] }) : r === "D" ? /* @__PURE__ */ _("div", {
				className: "ed-hp",
				children: [/* @__PURE__ */ g(Y, { id: "gatekeeper" }), /* @__PURE__ */ _("div", { children: [
					/* @__PURE__ */ _("div", {
						className: "ed-hp-heading",
						children: [
							/* @__PURE__ */ g("span", { children: n("games.eternaldecks.gatekeeper") }),
							/* @__PURE__ */ g(an, { count: e.enemyCount }),
							/* @__PURE__ */ g("b", { children: e.hp })
						]
					}),
					/* @__PURE__ */ g("div", {
						className: "ed-hp-track",
						children: Array.from({ length: 20 }, (t, n) => /* @__PURE__ */ g("i", { className: n < e.hp ? "ed-hp-filled" : "" }, n))
					}),
					/* @__PURE__ */ _("span", {
						className: "ed-key-caption",
						children: [
							/* @__PURE__ */ g(on, {}),
							" ",
							e.keys.length,
							"/4",
							e.stage === "D+" && /* @__PURE__ */ _("span", {
								style: { color: J[C[Math.min(3, e.keys.length)]] },
								children: [
									n("games.eternaldecks.nextKey"),
									" · ",
									n(K[C[Math.min(3, e.keys.length)]])
								]
							})
						]
					})
				] })]
			}) : r === "E" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
				className: "ed-stage-label",
				children: n("games.eternaldecks.keys")
			}), /* @__PURE__ */ _("div", {
				className: "ed-key-progress",
				children: [C.map((t, n) => /* @__PURE__ */ _("span", {
					style: { color: J[t] },
					children: [/* @__PURE__ */ g(on, {}), /* @__PURE__ */ _("b", { children: [e.taskProgress[n], "/2"] })]
				}, t)), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(nn, { filled: !0 }), /* @__PURE__ */ _("b", { children: [e.stars.length, "/4"] })] })]
			})] }) : r === "F" ? /* @__PURE__ */ g("div", {
				className: "ed-f-goals",
				children: [
					"jewels",
					"river",
					"discs",
					"stars"
				].map((t, r) => /* @__PURE__ */ _("div", {
					className: e.keys.includes(t) ? "ed-done" : "",
					children: [/* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g(on, {}), /* @__PURE__ */ g("b", { children: [
						`${[
							"different3",
							"number3",
							"159"
						].filter((t) => !e.recipes.includes(t)).length}/3`,
						e.keys.includes("river") ? "✓" : "—",
						`${e.discs.length}/4`,
						`${e.stars.length}/4`
					][r] })] }), /* @__PURE__ */ g("span", { children: n([
						"games.eternaldecks.handJewels",
						"games.eternaldecks.riverRecipe",
						"games.eternaldecks.colorDiscs",
						"games.eternaldecks.fourStars"
					][r]) })]
				}, t))
			}) : /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("span", {
					className: "ed-stage-label",
					children: n("games.eternaldecks.keys")
				}),
				/* @__PURE__ */ _("div", {
					className: "ed-key-orbit",
					children: [Array.from({ length: 4 }, (t, n) => /* @__PURE__ */ g("span", {
						className: n < e.keys.length ? "ed-done" : "",
						children: /* @__PURE__ */ g(on, {})
					}, n)), /* @__PURE__ */ _("b", { children: [e.keys.length, "/4"] })]
				}),
				/* @__PURE__ */ _("span", {
					className: "ed-ability-progress",
					children: [
						/* @__PURE__ */ g(nn, { filled: !0 }),
						" ",
						e.stars.length,
						"/4"
					]
				}),
				e.stage === "B+" && /* @__PURE__ */ g("span", {
					className: "ed-enemy-count",
					children: /* @__PURE__ */ g(an, { count: e.enemyCount })
				})
			] }),
			!e.campaign && r !== "F" && /* @__PURE__ */ g("div", {
				className: "ed-stage-hearts",
				"aria-label": `${n("games.eternaldecks.hearts")} ${e.hearts}/3`,
				children: [
					0,
					1,
					2
				].map((t) => /* @__PURE__ */ g(rn, { filled: t < e.hearts }, t))
			})
		]
	});
}
//#endregion
//#region src/games/eternaldecks/view-player.tsx
var vn = [
	"games.eternaldecks.topRow",
	"games.eternaldecks.middleRow",
	"games.eternaldecks.bottomRow"
], yn = {
	pegasus: "games.eternaldecks.powerPegasus",
	barong: "games.eternaldecks.powerBarong",
	jinn: "games.eternaldecks.powerJinn",
	kyubi: "games.eternaldecks.powerKyubi"
}, bn = [
	"games.eternaldecks.alpha",
	"games.eternaldecks.beta",
	"games.eternaldecks.gamma"
], xn = {
	arrange: "games.eternaldecks.arrange",
	act: "games.eternaldecks.act",
	resolve: "games.eternaldecks.resolve",
	choice: "games.eternaldecks.chooseTarget",
	after: "games.eternaldecks.after",
	chapter: "games.eternaldecks.chapter",
	won: "games.eternaldecks.won",
	lost: "games.eternaldecks.lost"
}, Sn = {
	draw: "games.eternaldecks.draw",
	give: "games.eternaldecks.give",
	ignore: "games.eternaldecks.ignore",
	river: "games.eternaldecks.river",
	giveDisc: "games.eternaldecks.giveDisc",
	remove: "games.eternaldecks.remove",
	wild: "games.eternaldecks.wild",
	refill4: "games.eternaldecks.refill4"
}, Cn = {
	own: "games.eternaldecks.own",
	random: "games.eternaldecks.random",
	permanent: "games.eternaldecks.permanent",
	heartBonus: "games.eternaldecks.heartBonus",
	river3: "games.eternaldecks.river3",
	camp: "games.eternaldecks.campCard",
	skip: "games.eternaldecks.skip"
};
function wn(e, t) {
	return e.card === t.card && e.row === t.row && e.flip === t.flip && e.column === t.column;
}
function Tn(e, t) {
	return e.length === t.length && e.every((e) => t.includes(e));
}
function En({ title: e, onClose: t, children: r, paper: a = !1 }) {
	let s = c(), u = i(null);
	return n(() => {
		let e = u.current;
		return e?.showModal(), () => e?.close();
	}, []), o(/* @__PURE__ */ g("dialog", {
		ref: u,
		className: `ed-dialog ${a ? "ed-dialog-paper" : ""}`,
		"aria-label": e,
		onCancel: (e) => {
			e.preventDefault(), t?.();
		},
		onClick: (e) => {
			e.target === e.currentTarget && t?.();
		},
		children: /* @__PURE__ */ _("div", {
			className: "ed-dialog-inner",
			children: [/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("h2", { children: e }), t && /* @__PURE__ */ g("button", {
				className: "ed-icon-button",
				onClick: t,
				"aria-label": s("games.eternaldecks.close"),
				children: /* @__PURE__ */ g(l, { size: 20 })
			})] }), /* @__PURE__ */ g("div", {
				className: "ed-dialog-content",
				children: r
			})]
		})
	}), document.body);
}
function Dn({ task: e }) {
	let t = c();
	return /* @__PURE__ */ _("div", {
		className: "ed-task",
		children: [
			/* @__PURE__ */ g("span", { children: e.kind === "starting" ? "▤" : e.kind === "number" ? e.value : "✦" }),
			/* @__PURE__ */ g("p", { children: t($t[e.kind], { n: e.value ?? 0 }) }),
			e.color && /* @__PURE__ */ g("b", {
				style: { color: J[e.color] },
				children: t(K[e.color])
			})
		]
	});
}
function On(e) {
	f();
	let t = e.public;
	return /* @__PURE__ */ g(kn, {
		...e,
		pub: t,
		priv: e.private
	}, `${t.stage}:${t.turn}:${t.phase}:${t.log.length}`);
}
function kn({ pub: e, priv: t, members: r, myRid: o, send: s }) {
	let f = c(), te = sn(), v = t?.actions ?? [], [y, b] = a("play"), [S, C] = a([]), [w, ne] = a(!1), [T, re] = a([]), [ie, E] = a(null), [D, O] = a(null), [k, A] = a(null), [ae, j] = a(null), [M, oe] = a(0), [N, ce] = a(t?.seats.some((t) => t.seat === e.turn) ? e.turn : t?.seats[0]?.seat ?? 0), P = t?.seats.find((e) => e.seat === N), le = P?.hand ?? e.seats[N]?.openHand ?? [], F = e.seats[e.turn].owner === o && N === e.turn, ue = v.filter((e) => e.type === "give"), de = (t) => !!e.campaign?.modifications[N].includes(0) && N === 1 && x[t].colors.length === 1 && x[t].colors[0] === "green" && [
		1,
		5,
		9
	].includes(x[t].value), fe = S.length === 1 ? Number(!de(S[0])) : Number(!ue.length || !ue.every((e) => de(e.cards[0]))), { ref: pe, hidden: me } = p(`ed-hand:${N}`), he = i(null), ge = ee();
	n(() => {
		if (!ge) return;
		let e = `ed-hand-card:${N}`;
		return ge.registerProbe(e, () => {
			let e = he.current;
			if (!e) return null;
			let t = e.getBoundingClientRect(), n = e.closest(".ed-player-area")?.getBoundingClientRect() ?? t, r = e.querySelectorAll(".ed-hand-card");
			for (let e of r) {
				if (getComputedStyle(e).visibility === "hidden") continue;
				let r = e.getBoundingClientRect();
				if (!(r.right <= Math.max(t.left, n.left, 0) || r.left >= Math.min(t.right, n.right, window.innerWidth) || r.bottom <= Math.max(t.top, n.top, 0) || r.top >= Math.min(t.bottom, n.bottom, window.innerHeight))) return {
					x: r.left,
					y: r.top,
					w: r.width,
					h: r.height
				};
			}
			return null;
		}), () => ge.registerProbe(e, null);
	}, [ge, N]);
	let I = (e) => {
		s(e);
	}, L = (t) => e.solo ? f(bn[t]) : r.find((n) => n.rid === e.seats[t]?.owner)?.name ?? f(K[e.seats[t].color]), _e = () => {
		C([]), ne(!1), re([]), j(null), E(null);
	}, ve = (e) => {
		_e(), b(e);
	}, R = v.filter((e) => e.type === "play" && T.every((t, n) => e.moves[n] && wn(t, e.moves[n]))), ye = R.filter((e) => {
		let t = e.moves[T.length];
		return t && t.card === S[0] && t.flip === w;
	}), be = y === "play" && F ? ye.map((e) => e.moves[T.length]) : [], xe = be.find((e) => ie && wn(e, ie)) ?? be.find((e) => e.row >= 0) ?? be[0], Se = v.filter((e) => e.type === "jewel" && S.every((t) => e.cards.includes(t))), Ce = Se.filter((e) => Tn(e.cards, S)), we = structuredClone(e);
	T.forEach((e) => {
		if (e.row < 0) we.river.push(e.card);
		else {
			let t = we.rows[e.row], n = dn(we, e), r = t.cards[n];
			t.cards[n] = {
				card: e.card,
				flip: e.flip,
				under: r ? [...r.under, r.card] : [],
				wild: !1
			};
		}
	});
	let Te = (e) => {
		E(null);
		let t = [...T, e], n = R.filter((e) => t.every((t, n) => e.moves[n] && wn(e.moves[n], t))), r = n.find((e) => e.moves.length === t.length);
		n.some((e) => e.moves.length > t.length) ? (re(t), C([]), ne(!1)) : r && I(r);
	}, Ee = R.find((e) => e.moves.length === T.length), De = (e) => {
		if (!P || !F) {
			A({ card: e });
			return;
		}
		y === "jewel" ? C(S.includes(e) ? S.filter((t) => t !== e) : [...S, e]) : (C(S[0] === e ? [] : [e]), ne(!1), E(null));
	}, z = v.find((e) => e.type === "ability" && e.card === S[0]), Oe = Ce.filter((e) => !ae || e.recipe === ae).map((e) => e.eternal), ke = (e) => {
		let t = Ce.find((t) => t.eternal === e && (!ae || t.recipe === ae));
		t && I(t);
	}, B = y === "marker" && P ? (e) => I({
		type: "marker",
		seat: N,
		index: M,
		target: e
	}) : void 0, Ae = P?.tasks.length ?? e.seats[N].taskCount, V = e.campaign?.stored.flatMap((e) => e.map((e) => e.card)), H = /* @__PURE__ */ _("button", {
		className: "ed-give-button",
		disabled: !F || !ue.length || T.length > 0,
		"aria-pressed": y === "give",
		"aria-label": f("games.eternaldecks.giveCost", { n: fe }),
		onClick: () => {
			if (y === "give") {
				ve("play");
				return;
			}
			b("give"), j(null), E(null), ne(!1), C(S.length === 1 && ue.some((e) => e.cards.includes(S[0])) ? S : []);
		},
		children: [/* @__PURE__ */ g("span", { children: f("games.eternaldecks.give") }), /* @__PURE__ */ _("span", {
			className: "ed-give-cost",
			children: [/* @__PURE__ */ g(rn, { filled: fe > 0 }), fe]
		})]
	}), je = e.phase === "choice" && e.choice ? f("games.eternaldecks.turnOf", { name: L(e.choice.seat) }) : ["act", "after"].includes(e.phase) ? e.solo ? f("games.eternaldecks.turnOf", { name: L(e.turn) }) : e.seats[e.turn].owner === o ? f("games.eternaldecks.yourTurn") : f("games.eternaldecks.turnOf", { name: L(e.turn) }) : f(xn[e.phase]);
	function Me(e) {
		if (e.eternal) return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g(Q, { id: e.eternal }),
			e.recipe && /* @__PURE__ */ g("span", { children: f(qt[e.recipe]) }),
			e.seat !== void 0 && /* @__PURE__ */ g("span", { children: f("games.eternaldecks.ownerPersonal") })
		] });
		if (e.card) return /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g(Z, { id: e.card }),
			/* @__PURE__ */ g("span", { children: te(e.card) }),
			e.row !== void 0 && /* @__PURE__ */ g("span", { children: f(vn[e.row]) })
		] });
		if (e.recipe) return /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
			className: "ed-big-gem",
			children: "◆"
		}), /* @__PURE__ */ g("span", { children: f(qt[e.recipe]) })] });
		if (e.color) return /* @__PURE__ */ g("span", {
			style: { color: J[e.color] },
			children: f(K[e.color])
		});
		if (e.row !== void 0) return f(vn[e.row]);
		if (e.seat !== void 0) return L(e.seat);
		let t = se.find((t) => t.id === e.value);
		return t ? /* @__PURE__ */ g(Dn, { task: t }) : Cn[e.value ?? e.id] ? f(Cn[e.value ?? e.id]) : f("games.eternaldecks.confirm");
	}
	let Ne = /* @__PURE__ */ _("div", {
		className: "ed-banner",
		children: [/* @__PURE__ */ _("div", {
			className: "ed-turn",
			children: [/* @__PURE__ */ _("div", {
				className: "ed-title",
				children: [/* @__PURE__ */ g("h1", { children: f("games.eternaldecks.name") }), /* @__PURE__ */ _("span", { children: [
					e.stage,
					" · ",
					f(e.campaign ? "games.eternaldecks.story" : `games.eternaldecks.${e.difficulty}`)
				] })]
			}), /* @__PURE__ */ g("span", {
				className: "ed-turn-pill",
				children: je
			})]
		}), /* @__PURE__ */ g("div", {
			className: "ed-seats",
			children: e.seats.map((t, n) => /* @__PURE__ */ _("button", {
				className: `ed-seat ${e.solo ? "ed-seat-solo" : ""} ${n === e.turn ? "ed-seat-turn" : ""} ${n === N ? "ed-seat-view" : ""}`,
				onClick: () => {
					ce(n), _e(), b("play");
				},
				"aria-label": `${L(n)} · ${f("games.eternaldecks.deck")} ${t.deckCount}`,
				children: [
					e.solo ? /* @__PURE__ */ g("span", {
						className: "ed-seat-golem",
						children: /* @__PURE__ */ g(Y, { id: [
							"alpha",
							"beta",
							"gamma"
						][n] })
					}) : /* @__PURE__ */ g("span", {
						className: "ed-seat-avatar",
						style: { background: J[t.color] },
						children: L(n).slice(0, 1)
					}),
					/* @__PURE__ */ g("span", {
						className: "ed-seat-name",
						children: L(n)
					}),
					e.solo ? /* @__PURE__ */ g("span", {
						className: "ed-seat-preview",
						children: t.openHand?.map((e) => /* @__PURE__ */ g(Z, { id: e }, e))
					}) : /* @__PURE__ */ g(an, { count: t.deckCount })
				]
			}, n))
		})]
	}), Pe = /* @__PURE__ */ _("div", {
		className: "ed-player-area",
		children: [
			e.campaign ? /* @__PURE__ */ _("div", {
				className: "ed-hand-info ed-story-hand-info",
				children: [
					/* @__PURE__ */ _("button", {
						className: `ed-cat-status ${e.campaign.catFound ? "" : "ed-cat-unfound"}`,
						onClick: () => O("campaign"),
						children: [/* @__PURE__ */ g(Y, { id: "cat" }), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g("b", { children: f("games.eternaldecks.creatures.cat") }), /* @__PURE__ */ g("small", { children: f(e.campaign.catFound ? e.campaign.catUsed ? "games.eternaldecks.catStateUsed" : "games.eternaldecks.catStateUnused" : "games.eternaldecks.catNotFound") })] })]
					}),
					/* @__PURE__ */ _("button", {
						className: "ed-stored-preview",
						onClick: () => O("campaign"),
						children: [e.campaign.stored[N]?.[0] ? /* @__PURE__ */ g(Z, { id: e.campaign.stored[N][0].card }) : /* @__PURE__ */ g("span", { children: "◇" }), /* @__PURE__ */ g("span", { children: f("games.eternaldecks.stored") })]
					}),
					/* @__PURE__ */ _("button", {
						className: "ed-story-upgrade",
						onClick: () => O("campaign"),
						children: [
							f("games.eternaldecks.upgrade"),
							" ",
							e.campaign.points,
							"★"
						]
					}),
					H,
					/* @__PURE__ */ g("button", {
						className: "ed-icon-button ed-more-button",
						onClick: () => O("more"),
						"aria-label": f("games.eternaldecks.moreActions"),
						children: "⋯"
					})
				]
			}) : /* @__PURE__ */ _("div", {
				className: "ed-hand-info",
				children: [
					e.seats[N].power ? /* @__PURE__ */ _("button", {
						className: "ed-personal-power",
						onClick: () => A({ eternal: e.seats[N].power }),
						children: [/* @__PURE__ */ g(Q, {
							id: e.seats[N].power,
							small: !0
						}), /* @__PURE__ */ _("span", { children: [/* @__PURE__ */ g("b", { children: f(q[e.seats[N].power]) }), /* @__PURE__ */ g("small", { children: f(yn[e.seats[N].power]) })] })]
					}) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("button", {
						className: "ed-personal-button",
						onClick: () => O("personal"),
						"aria-label": f("games.eternaldecks.personal"),
						children: /* @__PURE__ */ g(an, { count: e.seats[N].deckCount })
					}), /* @__PURE__ */ g("strong", { children: e.solo ? `${L(N)} · ${f("games.eternaldecks.hand")}` : f("games.eternaldecks.yourHand") })] }),
					/* @__PURE__ */ _("button", {
						className: "ed-disc-button",
						onClick: () => e.solo ? O("discs") : ve(y === "marker" ? "play" : "marker"),
						disabled: e.stage[0] === "E" && e.stars.length === 0,
						"aria-label": f(e.solo ? "games.eternaldecks.disc" : "games.eternaldecks.marker"),
						children: [/* @__PURE__ */ g("span", { style: { background: J[e.seats[N].color] } }), e.solo ? /* @__PURE__ */ g("b", { children: e.seats[N].discs }) : /* @__PURE__ */ g("span", { style: { background: J[e.seats[N].color] } })]
					}),
					H,
					/* @__PURE__ */ g("button", {
						className: "ed-icon-button ed-more-button",
						onClick: () => O("more"),
						"aria-label": f("games.eternaldecks.moreActions"),
						children: "⋯"
					})
				]
			}),
			/* @__PURE__ */ g("div", {
				className: `ed-hand ${le.length > 4 ? "ed-hand-scroll" : ""}`,
				ref: (e) => {
					pe(e), he.current = e;
				},
				style: { visibility: me ? "hidden" : void 0 },
				children: le.map((e) => {
					let t = y === "jewel" ? Se.some((t) => t.cards.includes(e)) : y === "play" ? R.some((t) => t.moves[T.length]?.card === e) : v.some((t) => y === "store" ? t.type === "store" && t.card === e : y === "give" && t.type === "give" && t.cards.includes(e));
					return /* @__PURE__ */ g(ln, {
						id: e,
						selected: S.includes(e),
						available: F && t && !T.some((t) => t.card === e),
						flip: S.includes(e) && w,
						onClick: () => De(e)
					}, e);
				})
			}),
			(S.length > 0 || T.length > 0 || y !== "play") && /* @__PURE__ */ _("div", {
				className: "ed-hand-tools",
				children: [/* @__PURE__ */ g("button", {
					className: "ed-icon-button",
					onClick: () => ve("play"),
					"aria-label": f("games.eternaldecks.cancel"),
					children: /* @__PURE__ */ g(l, { size: 18 })
				}), y === "play" && S.length === 1 && x[S[0]].colors.length === 2 && /* @__PURE__ */ g("button", {
					className: "ed-icon-button",
					onClick: () => {
						ne(!w), E(null);
					},
					"aria-label": f("games.eternaldecks.flip"),
					children: /* @__PURE__ */ g(d, { size: 18 })
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "ed-command-slot",
				children: y === "play" ? /* @__PURE__ */ _("div", {
					className: "ed-main-actions",
					children: [/* @__PURE__ */ g("button", {
						className: "ed-secondary",
						disabled: !F || !v.some((e) => e.type === "jewel") || T.length > 0,
						onClick: () => {
							S.length && Se.length ? b("jewel") : ve("jewel");
						},
						children: f("games.eternaldecks.jewel")
					}), e.phase === "after" && F ? /* @__PURE__ */ g("button", {
						className: "ed-primary",
						onClick: () => I({ type: "endTurn" }),
						children: f("games.eternaldecks.endTurn")
					}) : z ? /* @__PURE__ */ g("button", {
						className: "ed-primary",
						onClick: () => I(z),
						children: f("games.eternaldecks.ability")
					}) : xe ? /* @__PURE__ */ g("button", {
						className: "ed-primary",
						onClick: () => Te(xe),
						children: f("games.eternaldecks.playTo", { field: f(xe.row < 0 ? "games.eternaldecks.river" : Gt[e.rows[xe.row].field]) })
					}) : Ee && T.length > 0 ? /* @__PURE__ */ g("button", {
						className: "ed-primary",
						onClick: () => I(Ee),
						children: f("games.eternaldecks.confirm")
					}) : /* @__PURE__ */ g("button", {
						className: "ed-primary",
						disabled: !0,
						children: f(F ? T.length ? "games.eternaldecks.secondCard" : "games.eternaldecks.play" : "games.eternaldecks.noAction")
					})]
				}) : /* @__PURE__ */ _("div", {
					className: "ed-inline-options",
					children: [
						y === "jewel" && /* @__PURE__ */ _(h, { children: [[...new Set(Ce.map((e) => e.recipe))].map((e) => /* @__PURE__ */ _("button", {
							className: "ed-primary",
							onClick: () => {
								j(e), O("jewel");
							},
							children: [f(qt[e]), /* @__PURE__ */ g(X, {})]
						}, e)), Ce.length === 0 && /* @__PURE__ */ g("span", { children: f("games.eternaldecks.chooseCards") })] }),
						(y === "give" || y === "store") && /* @__PURE__ */ _(h, { children: [v.filter((e) => y === "give" ? e.type === "give" && e.cards[0] === S[0] : e.type === "store" && e.card === S[0]).map((e, t) => /* @__PURE__ */ g("button", {
							className: "ed-primary",
							onClick: () => I(e),
							children: y === "give" ? f("games.eternaldecks.giveTo", { name: L(e.target) }) : L(e.target)
						}, t)), S.length === 0 && /* @__PURE__ */ g("span", { children: f("games.eternaldecks.chooseHand") })] }),
						y === "marker" && /* @__PURE__ */ _(h, { children: [
							[0, 1].filter((t) => e.stage !== "E+" || t === 0).map((e) => /* @__PURE__ */ _("button", {
								"aria-pressed": M === e,
								className: "ed-icon-button",
								onClick: () => oe(e),
								children: ["● ", e + 1]
							}, e)),
							e.stage !== "E+" && /* @__PURE__ */ g("button", {
								className: "ed-secondary",
								onClick: () => O("marker"),
								children: f("games.eternaldecks.target")
							}),
							/* @__PURE__ */ g("button", {
								className: "ed-secondary",
								onClick: () => B?.(""),
								children: f("games.eternaldecks.clearMarker")
							})
						] })
					]
				})
			})
		]
	});
	return /* @__PURE__ */ _("div", {
		className: "ed-view",
		children: [
			/* @__PURE__ */ g(m, {
				adaptive: !0,
				className: "ed-layout",
				banner: Ne,
				actions: Pe,
				actionsHeight: "ed-actions-slot",
				scroll: !1,
				children: /* @__PURE__ */ _("div", {
					className: "ed-table",
					children: [
						/* @__PURE__ */ g(pn, {
							pub: e,
							onEternal: (e) => A({ eternal: e }),
							onChoose: ke,
							targets: y === "jewel" ? Oe : []
						}),
						/* @__PURE__ */ g(_n, {
							pub: e,
							onDetails: () => O("stage")
						}),
						/* @__PURE__ */ g("div", {
							className: "ed-field-board",
							children: [
								0,
								1,
								2
							].map((e) => /* @__PURE__ */ g(fn, {
								pub: we,
								index: e,
								candidates: be,
								onTarget: E,
								chosen: xe,
								onField: (e) => A({ field: e }),
								onCard: (e) => A({ card: e }),
								onEternal: (e) => A({ eternal: e }),
								marker: B
							}, e))
						}),
						/* @__PURE__ */ g(mn, {
							pub: we,
							candidates: be,
							chosen: xe,
							onTarget: E,
							onCard: (e) => A({ card: e }),
							marker: B
						})
					]
				})
			}),
			e.phase === "arrange" && /* @__PURE__ */ g(En, {
				title: f("games.eternaldecks.arrange"),
				children: /* @__PURE__ */ g("div", {
					className: "ed-choice-grid",
					children: v.filter((e) => e.type === "arrange").map((e) => /* @__PURE__ */ _("button", {
						className: "ed-choice",
						onClick: () => I(e),
						children: [e.order.map(L).join(" → "), /* @__PURE__ */ g(X, {})]
					}, e.order.join(",")))
				})
			}),
			e.choice && e.seats[e.choice.seat].owner === o && /* @__PURE__ */ g(En, {
				title: f(Zt[e.choice.kind]),
				children: /* @__PURE__ */ g("div", {
					className: "ed-choice-grid",
					children: e.choice.options.map((e) => /* @__PURE__ */ _("button", {
						className: "ed-choice",
						onClick: () => I({
							type: "choose",
							option: e.id
						}),
						children: [Me(e), /* @__PURE__ */ g(X, {})]
					}, e.id))
				})
			}),
			e.phase === "chapter" && e.campaign && /* @__PURE__ */ _(En, {
				title: f(e.campaign.chapterWon ? "games.eternaldecks.chapterWon" : "games.eternaldecks.chapterFailed"),
				children: [/* @__PURE__ */ _("div", {
					className: "ed-chapter-result",
					children: [
						/* @__PURE__ */ g(Y, { id: e.campaign.chapterWon ? "cat" : "gamma" }),
						/* @__PURE__ */ g("h3", { children: e.stage }),
						e.loss && /* @__PURE__ */ g("p", { children: f(Qt[e.loss]) }),
						/* @__PURE__ */ _("p", { children: [
							f("games.eternaldecks.score"),
							" ",
							e.campaign.scores[e.campaign.chapter] ?? "—"
						] }),
						/* @__PURE__ */ g("button", {
							className: "ed-primary",
							onClick: () => I({ type: "nextChapter" }),
							children: f(e.campaign.chapterWon || e.campaign.failures[e.campaign.chapter] >= 2 ? "games.eternaldecks.nextChapter" : "games.eternaldecks.retry")
						})
					]
				}), /* @__PURE__ */ g(hn, {
					campaign: e.campaign,
					actions: v,
					send: I,
					initialSeat: N
				})]
			}),
			k && /* @__PURE__ */ g(En, {
				title: k.eternal ? f(q[k.eternal]) : k.card ? te(k.card) : f(Gt[e.rows[k.field].field]),
				onClose: () => A(null),
				children: /* @__PURE__ */ g("div", {
					className: "ed-object-detail",
					children: k.eternal ? /* @__PURE__ */ g(cn, {
						id: k.eternal,
						excludedCards: V
					}) : k.card ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Z, { id: k.card }), x[k.card].effect && x[k.card].effect in q && /* @__PURE__ */ g(cn, {
						id: x[k.card].effect,
						excludedCards: V
					})] }) : /* @__PURE__ */ g("p", { children: f(Kt[e.rows[k.field].field]) })
				})
			}),
			D && /* @__PURE__ */ _(En, {
				paper: D === "campaign",
				title: f({
					tasks: "games.eternaldecks.tasks",
					discs: "games.eternaldecks.disc",
					campaign: "games.eternaldecks.journal",
					history: "games.eternaldecks.history",
					stage: "games.eternaldecks.target",
					jewel: "games.eternaldecks.chooseRecipient",
					personal: "games.eternaldecks.personal",
					marker: "games.eternaldecks.marker",
					more: "games.eternaldecks.moreActions"
				}[D]),
				onClose: () => O(null),
				children: [
					D === "more" && /* @__PURE__ */ _("div", {
						className: "ed-choice-grid",
						children: [
							e.campaign && /* @__PURE__ */ g("button", {
								className: "ed-choice",
								disabled: !F || !v.some((e) => e.type === "store"),
								onClick: () => {
									ve("store"), O(null);
								},
								children: f("games.eternaldecks.store")
							}),
							Ae > 0 && /* @__PURE__ */ _("button", {
								className: "ed-choice",
								onClick: () => O("tasks"),
								children: [
									f("games.eternaldecks.tasks"),
									" ",
									Ae
								]
							}),
							e.campaign && /* @__PURE__ */ _("button", {
								className: "ed-choice",
								onClick: () => O("campaign"),
								children: [
									f("games.eternaldecks.journal"),
									" · ✦ ",
									e.campaign.points
								]
							}),
							/* @__PURE__ */ _("button", {
								className: "ed-choice",
								onClick: () => O("history"),
								children: [/* @__PURE__ */ g(u, { size: 18 }), f("games.eternaldecks.history")]
							})
						]
					}),
					D === "marker" && /* @__PURE__ */ g("div", {
						className: "ed-choice-grid",
						children: [
							{
								id: "heart",
								label: f("games.eternaldecks.hearts")
							},
							{
								id: "discard",
								label: f("games.eternaldecks.discard")
							},
							...[...e.revived, ...e.holding ? [e.holding] : []].map((e) => ({
								id: `eternal:${e}`,
								label: f(q[e])
							})),
							...e.recipes.map((e) => ({
								id: `recipe:${e}`,
								label: f(qt[e])
							}))
						].map((e) => /* @__PURE__ */ _("button", {
							className: "ed-choice",
							onClick: () => B?.(e.id),
							children: [e.label, /* @__PURE__ */ g(X, {})]
						}, e.id))
					}),
					D === "tasks" && /* @__PURE__ */ g(h, { children: (P?.tasks ?? e.seats[N].openTasks).map((e) => /* @__PURE__ */ g(Dn, { task: e }, e.id)) }),
					D === "discs" && /* @__PURE__ */ g("div", {
						className: "ed-choice-grid",
						children: v.filter((e) => e.type === "disc").map((e) => /* @__PURE__ */ _("button", {
							className: "ed-choice",
							onClick: () => I(e),
							children: [
								/* @__PURE__ */ g(Y, { id: [
									"alpha",
									"beta",
									"gamma"
								][e.seat] }),
								/* @__PURE__ */ g("span", { children: L(e.seat) }),
								/* @__PURE__ */ g("b", { children: f(Sn[e.ability]) }),
								/* @__PURE__ */ g(X, {})
							]
						}, `${e.seat}:${e.ability}`))
					}),
					D === "campaign" && e.campaign && /* @__PURE__ */ g(hn, {
						campaign: e.campaign,
						actions: v,
						send: I,
						initialSeat: N
					}),
					D === "stage" && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("p", { children: f(en[e.stage]) }), /* @__PURE__ */ g("div", {
						className: "ed-recipe-list",
						children: e.recipes.map((e) => /* @__PURE__ */ _("span", { children: ["◆ ", f(qt[e])] }, e))
					})] }),
					D === "jewel" && /* @__PURE__ */ g("div", {
						className: "ed-choice-grid",
						children: Ce.filter((e) => e.recipe === ae).map((e) => /* @__PURE__ */ _("button", {
							className: "ed-choice",
							onClick: () => I(e),
							children: [/* @__PURE__ */ g(Q, { id: e.eternal }), /* @__PURE__ */ g(X, {})]
						}, e.eternal))
					}),
					D === "personal" && /* @__PURE__ */ g("div", {
						className: "ed-choice-grid",
						children: [...e.seats[N].power ? [e.seats[N].power] : [], ...e.seats[N].personal].map((t) => /* @__PURE__ */ g("button", {
							className: "ed-choice",
							onClick: () => {
								O(null), A({ eternal: t });
							},
							children: /* @__PURE__ */ g(Q, {
								id: t,
								jewel: !!e.eternals.find((e) => e.id === t)?.jewel
							})
						}, t))
					}),
					D === "history" && /* @__PURE__ */ g("ol", {
						className: "ed-history",
						children: e.log.map((e, t) => /* @__PURE__ */ _("li", { children: [/* @__PURE__ */ g("span", { children: e.seat >= 0 ? L(e.seat) : "◇" }), /* @__PURE__ */ _("span", { children: [
							f({
								play: "games.eternaldecks.play",
								revive: "games.eternaldecks.revival",
								jewel: "games.eternaldecks.jewel",
								star: "games.eternaldecks.stars",
								key: "games.eternaldecks.keys",
								damage: "games.eternaldecks.hp",
								enemy: "games.eternaldecks.enemyDeck",
								give: "games.eternaldecks.give",
								draw: "games.eternaldecks.draw",
								curse: "games.eternaldecks.activeCurse",
								ability: "games.eternaldecks.ability",
								store: "games.eternaldecks.store",
								disc: "games.eternaldecks.disc",
								task: "games.eternaldecks.tasks",
								retry: "games.eternaldecks.retry",
								chapter: "games.eternaldecks.chapter"
							}[e.kind]),
							e.card ? ` · ${te(e.card)}` : e.amount === void 0 ? "" : ` ${e.amount}`,
							e.kind === "revive" && e.value && e.value in q ? ` · ${f(q[e.value])}` : ""
						] })] }, t))
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/eternaldecks/bot.ts
function An(e, t, n) {
	let r = n.seats.find((e) => e.seat === t.turn)?.hand ?? [];
	switch (e.type) {
		case "choose": {
			let n = t.choice?.options.find((t) => t.id === e.option);
			if (!n) return 0;
			if (t.choice?.kind === "revive") {
				let e = n.eternal ? oe(n.eternal) : "";
				return (e === "D" ? 30 : e === "E" ? 8 : 15) + (n.eternal === "witch" ? -5 : 0) + (t.stage === "F" && n.seat !== void 0 ? 12 : 0);
			}
			return t.choice?.kind === "keyBonus" ? e.option === "permanent" ? 40 : e.option === "camp" ? 25 : 10 : t.choice?.kind === "jewel" ? n.recipe === "159" ? 35 : n.recipe === "number3" ? 20 : 10 : n.card ? x[n.card].kind === "wild" ? 30 : x[n.card].kind === "ability" ? 18 : x[n.card].value : e.option === "skip" ? -10 : 1;
		}
		case "play": return e.moves.reduce((e, n) => {
			if (n.row < 0) return e - 8 - (t.river.length >= 4 && t.riverRewards.length === 0 && !t.dragon ? 80 : 0);
			let r = t.rows[n.row], i = r.cards.find((e) => x[e.card].kind === "skull"), a = r.field === "mountain" || r.field === "castle" ? (10 - x[n.card].value) / 2 : r.field === "cave" ? x[n.card].value / 2 : 0;
			return e + 8 + a + r.cards.length * 2 + (i && x[n.card].kind === "number" ? x[n.card].value * 2 : 0) + (r.cards.length >= r.capacity - 1 ? 16 : 0) - (x[n.card].kind === "wild" ? 5 : 0);
		}, 0);
		case "jewel": return 20 - e.cards.length * 2 + (e.recipe === "159" ? 15 : 0) + (t.campaign ? 15 : 0) - (t.river.length + e.cards.length >= 5 && t.riverRewards.length === 0 && !t.dragon ? 80 : 0);
		case "ability": return ["mummy", "medusa"].includes(x[e.card].effect ?? "") ? 30 : x[e.card].effect === "minotaur" ? 12 : 17;
		case "store": return x[e.card].kind === "wild" ? t.campaign?.chapter === 2 ? 27 : 20 : 14;
		case "give": {
			let n = t.order[(t.order.indexOf(t.turn) + 1) % t.order.length], i = t.seats[e.target];
			return i.handCount === 0 && i.deckCount === 0 ? e.target === n ? 70 : 38 : r.length > 2 ? 1 : -8;
		}
		case "disc": return e.ability === "draw" && r.length < 3 ? 28 : e.ability === "ignore" ? 4 : -2;
		case "buy": return e.upgrade === "draw2" ? 14 : e.upgrade === "drawRandom" ? 6 : -3;
		case "modify": return 11;
		case "endTurn": return 0;
		case "nextChapter":
		case "arrange": return 100;
		default: return -100;
	}
}
var jn = (e) => e.private?.actions.length ? { action: e.private.actions.reduce((t, n) => An(n, e.public, e.private) > An(t, e.public, e.private) ? n : t) } : null, Mn = {
	edChange(e, t) {
		let n = e.data, r = n ? t.anchor(n.anchor) : null;
		return r ? {
			ms: 420,
			node: /* @__PURE__ */ g(v, {
				at: r,
				ms: 420
			})
		} : null;
	},
	edDraw(e, t) {
		let n = e.data, r = e.secret, i = n ? t.anchor(`ed-hand:${n.seat}`) ?? t.anchor("ed-stage") : null;
		if (!i) return null;
		let a = n ? t.anchor(`ed-hand-card:${n.seat}`) : null;
		return {
			ms: 420,
			node: /* @__PURE__ */ g(te, {
				at: i,
				ms: 420,
				children: /* @__PURE__ */ g("div", {
					style: {
						width: a?.w ?? 33,
						height: a?.h ?? 47
					},
					children: /* @__PURE__ */ g(Z, {
						id: r?.cards?.[0],
						back: !r?.cards?.length,
						compact: !!a && a.h / a.w < 1.2
					})
				})
			})
		};
	}
};
//#endregion
//#region src/games/eternaldecks/game-over.tsx
function Nn({ public: e, onPlayAgain: t, onBackToLobby: n }) {
	let r = c(), i = e;
	return /* @__PURE__ */ _("div", {
		className: "ed-over",
		children: [/* @__PURE__ */ _("div", {
			className: "ed-over-content",
			children: [/* @__PURE__ */ g(Y, { id: i.phase === "won" ? "dragon" : "cat" }), /* @__PURE__ */ _("div", {
				className: "ed-over-result",
				children: [
					/* @__PURE__ */ g("h1", { children: r(i.phase === "won" ? "games.eternaldecks.won" : "games.eternaldecks.lost") }),
					i.phase !== "won" && i.loss && /* @__PURE__ */ g("p", { children: r(Qt[i.loss]) }),
					i.campaign ? /* @__PURE__ */ g("p", { children: r("games.eternaldecks.finalScore", { n: me(i.campaign) }) }) : /* @__PURE__ */ _("p", { children: [
						i.stage,
						" · ✦ ",
						i.stars.length,
						" · ",
						/* @__PURE__ */ g(on, {}),
						" ",
						i.keys.length
					] })
				]
			})]
		}), /* @__PURE__ */ _("div", {
			className: "ed-over-footer",
			children: [/* @__PURE__ */ _("div", {
				className: "ed-over-actions",
				children: [t && /* @__PURE__ */ g("button", {
					className: "ed-primary",
					onClick: t,
					children: r("games.eternaldecks.playAgain")
				}), n && /* @__PURE__ */ g("button", {
					className: "ed-primary",
					onClick: n,
					children: r("games.eternaldecks.backLobby")
				})]
			}), !t && /* @__PURE__ */ g("p", { children: r("games.eternaldecks.waitHost") })]
		})]
	});
}
//#endregion
//#region src/games/eternaldecks/options.tsx
function Pn({ value: e, onChange: t }) {
	let n = c(), r = Ye.parse(e ?? void 0), i = (e) => t({
		...r,
		...e
	});
	return /* @__PURE__ */ _("div", {
		className: "ed-options",
		children: [
			/* @__PURE__ */ g(b, {
				title: n("games.eternaldecks.mode"),
				children: ["stage", "story"].map((e) => /* @__PURE__ */ g(y, {
					name: "ed-mode",
					value: e,
					checked: r.mode === e,
					label: n(e === "stage" ? "games.eternaldecks.singleStage" : "games.eternaldecks.story"),
					onChange: () => i({ mode: e })
				}, e))
			}),
			r.mode === "stage" && /* @__PURE__ */ g(b, {
				title: n("games.eternaldecks.stage"),
				columns: 3,
				children: He.options.map((e) => /* @__PURE__ */ g(y, {
					name: "ed-stage",
					value: e,
					checked: r.stage === e,
					label: e,
					onChange: () => i({ stage: e })
				}, e))
			}),
			/* @__PURE__ */ g(b, {
				title: n("games.eternaldecks.difficulty"),
				children: [
					"beginner",
					"standard",
					"expert",
					"pro"
				].map((e) => /* @__PURE__ */ g(y, {
					name: "ed-difficulty",
					value: e,
					checked: r.mode === "stage" && (r.stage.endsWith("+") || r.stage === "F") ? e === "beginner" : r.difficulty === e,
					disabled: r.mode === "stage" && (r.stage.endsWith("+") || r.stage === "F"),
					label: n({
						beginner: "games.eternaldecks.beginner",
						standard: "games.eternaldecks.standard",
						expert: "games.eternaldecks.expert",
						pro: "games.eternaldecks.pro"
					}[e]),
					onChange: () => i({ difficulty: e })
				}, e))
			}),
			r.mode === "stage" && /* @__PURE__ */ g(b, {
				title: n("games.eternaldecks.primary"),
				columns: 3,
				children: [
					0,
					1,
					2
				].map((e) => /* @__PURE__ */ g(y, {
					name: "ed-primary",
					value: String(e),
					checked: r.primary === e,
					label: n([
						"games.eternaldecks.alpha",
						"games.eternaldecks.beta",
						"games.eternaldecks.gamma"
					][e]),
					onChange: () => i({ primary: e })
				}, e))
			}),
			r.mode === "stage" && C.map((e, t) => /* @__PURE__ */ g(b, {
				title: `${n("games.eternaldecks.colors")} ${t + 1}`,
				children: C.map((e) => /* @__PURE__ */ g(y, {
					name: `ed-color-${t}`,
					value: e,
					checked: r.colors[t] === e,
					label: n(K[e]),
					onChange: () => {
						let n = [...r.colors], a = n[t], o = n.indexOf(e);
						n[t] = e, o >= 0 && (n[o] = a), i({ colors: n });
					}
				}, e))
			}, t))
		]
	});
}
//#endregion
//#region src/games/eternaldecks/guide-text.tsx
function $({ text: e }) {
	let t = [], n = [], r = () => {
		n.length && (t.push(/* @__PURE__ */ g("ul", {
			style: {
				listStyle: "disc",
				paddingLeft: 20,
				margin: "8px 0"
			},
			children: n.map((e, t) => /* @__PURE__ */ g("li", { children: e }, t))
		}, t.length)), n = []);
	};
	for (let i of e.split("\n")) i.startsWith("· ") ? n.push(i.slice(2)) : (r(), i.trim() && t.push(/* @__PURE__ */ g("p", { children: i }, t.length)));
	return r(), /* @__PURE__ */ g(h, { children: t });
}
//#endregion
//#region src/games/eternaldecks/guide.tsx
function Fn() {
	let e = c();
	return /* @__PURE__ */ _("div", {
		className: "ed-guide",
		children: [
			/* @__PURE__ */ _("section", { children: [/* @__PURE__ */ g("h3", { children: e("games.eternaldecks.rulePlacement") }), /* @__PURE__ */ g($, { text: e("games.eternaldecks.guidePlacement") })] }),
			/* @__PURE__ */ _("section", { children: [/* @__PURE__ */ g("h3", { children: e("games.eternaldecks.ruleFields") }), Ue.options.map((t) => /* @__PURE__ */ _("details", { children: [/* @__PURE__ */ g("summary", { children: e(Gt[t]) }), /* @__PURE__ */ g($, { text: e(Kt[t]) })] }, t))] }),
			/* @__PURE__ */ _("section", { children: [
				/* @__PURE__ */ g("h3", { children: e("games.eternaldecks.ruleRecipes") }),
				/* @__PURE__ */ g("div", {
					className: "ed-guide-grid",
					children: E.map((t) => /* @__PURE__ */ _("p", { children: ["◆ ", e(qt[t])] }, t))
				}),
				/* @__PURE__ */ g($, { text: e("games.eternaldecks.guideJewels") })
			] }),
			/* @__PURE__ */ _("section", { children: [/* @__PURE__ */ g("h3", { children: e("games.eternaldecks.ruleEternals") }), Object.values(w).flat().map((t) => /* @__PURE__ */ _("details", { children: [/* @__PURE__ */ _("summary", { children: [/* @__PURE__ */ g(Y, { id: t }), e(q[t])] }), /* @__PURE__ */ _("div", {
				className: "ed-guide-row",
				children: [/* @__PURE__ */ g(Q, { id: t }), /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g($, { text: e(Jt[t]) }), /* @__PURE__ */ g($, { text: e(Yt[t]) })] })]
			})] }, t))] }),
			/* @__PURE__ */ _("section", { children: [/* @__PURE__ */ g("h3", { children: e("games.eternaldecks.ruleStages") }), He.options.map((t) => /* @__PURE__ */ _("details", { children: [
				/* @__PURE__ */ g("summary", { children: t }),
				/* @__PURE__ */ g($, { text: e(en[t]) }),
				/* @__PURE__ */ g($, { text: e({
					A: "games.eternaldecks.guideA",
					B: "games.eternaldecks.guideB",
					C: "games.eternaldecks.guideC",
					D: "games.eternaldecks.guideD",
					E: "games.eternaldecks.guideE",
					F: "games.eternaldecks.guideF",
					"A+": "games.eternaldecks.guideAplus",
					"B+": "games.eternaldecks.guideBplus",
					"C+": "games.eternaldecks.guideCplus",
					"D+": "games.eternaldecks.guideDplus",
					"E+": "games.eternaldecks.guideEplus"
				}[t]) })
			] }, t))] }),
			/* @__PURE__ */ _("section", { children: [
				/* @__PURE__ */ g("h3", { children: e("games.eternaldecks.ruleSolo") }),
				/* @__PURE__ */ g($, { text: e("games.eternaldecks.guideSolo") }),
				/* @__PURE__ */ g($, { text: e("games.eternaldecks.guideStory") }),
				/* @__PURE__ */ g($, { text: e("games.eternaldecks.guideStoryChanges") }),
				/* @__PURE__ */ g($, { text: e("games.eternaldecks.guideScore") })
			] })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/eternaldecks/entry.tsx
var In = {
	definition: Ut,
	View: On,
	bot: jn,
	fx: Mn,
	OverView: Nn,
	Options: Pn,
	Guide: Fn,
	locales: {
		zh: {
			deckContents: "牌组组成",
			cardCount: "{{n}} 张",
			randomDeckContents: "由随机牌堆中的八张牌组成。",
			giveCost: "赠送手牌，消耗 {{n}} 颗爱心",
			giveTo: "赠送给{{name}}",
			yourHand: "你的手牌",
			playTo: "放入{{field}}",
			moreActions: "更多操作",
			chooseHand: "选择手牌",
			abilityProgress: "能力收集 {{n}}/3",
			jewels: "宝石",
			nextKey: "下一把钥匙",
			colorDiscs: "四色印记",
			fourStars: "四颗星辰",
			chapterFailures: "本章失败 {{n}} 次",
			gatekeeper: "守门人",
			riverRecipe: "河流配方",
			catNotFound: "尚未找到",
			upgrade: "升级",
			powerPegasus: "可连续打出一至两张牌",
			powerBarong: "同色牌可相邻，最多两张",
			powerJinn: "手牌补至四张",
			powerKyubi: "同数字牌可相邻，最多两张",
			catStateUsed: "已使用",
			catStateUnused: "未使用",
			riverLabel: "河流",
			name: "永恒牌",
			desc: "在永恒世界中合作出牌，复苏永恒者并完成试炼。",
			errAction: "当前无法执行此操作，请重新选择。",
			stage: "关卡",
			difficulty: "难度",
			mode: "模式",
			singleStage: "单关挑战",
			story: "单人剧情",
			primary: "主魔像",
			colors: "玩家颜色与顺序",
			beginner: "初学",
			standard: "标准",
			expert: "专家",
			pro: "征服",
			alpha: "阿尔法",
			beta: "贝塔",
			gamma: "伽马",
			red: "红色",
			blue: "蓝色",
			green: "绿色",
			yellow: "黄色",
			purple: "紫色",
			white: "白色",
			act: "选择行动",
			resolve: "结算中",
			after: "结束回合前可使用指示物",
			arrange: "选择行动顺序",
			chapter: "章节结算",
			won: "试炼完成",
			lost: "试炼失败",
			yourTurn: "轮到你行动",
			turnOf: "由 {{name}} 行动",
			hand: "手牌",
			deck: "牌库",
			river: "生命之河",
			discard: "弃牌区",
			revival: "公共复苏区",
			holding: "暂留区",
			personal: "个人复苏区",
			topRow: "上行",
			middleRow: "中行",
			bottomRow: "下行",
			play: "出牌",
			jewel: "制作宝石",
			give: "赠送手牌",
			ability: "使用能力",
			store: "储存手牌",
			disc: "使用指示物",
			marker: "交流指示物",
			tasks: "任务",
			journal: "剧情记录",
			history: "对局记录",
			details: "查看详情",
			close: "关闭",
			cancel: "取消选择",
			confirm: "确认",
			endTurn: "结束回合",
			flip: "翻转朝向",
			firstCard: "选择第一张牌的落点",
			secondCard: "选择第二张牌，或确认出牌",
			chooseTarget: "选择目标",
			chooseRecipe: "选择宝石配方",
			chooseCards: "选择用于制作宝石的手牌",
			chooseRecipient: "选择接受宝石的永恒者",
			chooseTeammate: "选择接收者",
			chooseDisc: "选择指示物能力",
			chooseStored: "选择储存对象",
			noAction: "等待下一步",
			waiting: "等待 {{name}}",
			selected: "已选择",
			available: "可选择",
			locked: "已封行",
			empty: "空位",
			sleeping: "尚未复苏",
			cleared: "已奉献宝石",
			activeCurse: "生效的诅咒",
			noCurse: "当前没有负面诅咒",
			hearts: "爱心",
			stars: "星",
			keys: "钥匙",
			hp: "生命",
			enemyDeck: "守门人牌库",
			riverRewards: "河流奖励",
			lap: "第 {{n}} 轮",
			cardsCount: "{{n}} 张",
			tokensCount: "{{n}} 枚",
			target: "目标",
			bonus: "奖励",
			skip: "不制作宝石",
			ownerPersonal: "为自己复苏",
			publicRevival: "公共复苏",
			permanent: "河流万能牌",
			heartBonus: "恢复爱心能力",
			river3: "增加河流奖励",
			own: "从自己的牌库抽牌",
			random: "从随机牌库抽牌",
			draw: "抽牌",
			giveDisc: "赠送指示物",
			ignore: "无视诅咒出牌",
			remove: "弃置场地最右侧的牌",
			wild: "将手牌当作万能牌出牌",
			refill4: "本关补牌至四张",
			clearMarker: "收回指示物",
			nextChapter: "下一章",
			retry: "重试本章",
			chapterFailed: "本章失败",
			chapterWon: "本章完成",
			forcedNext: "本章两次失败，进入下一章",
			starPoints: "星点",
			buy: "购买升级",
			modify: "解锁改造",
			stored: "储存牌",
			score: "得分",
			finalScore: "最终得分 {{n}} / 100",
			catUnused: "爱猫宝石尚未使用",
			catUsed: "爱猫宝石已使用",
			golemJewel: "魔像宝石",
			playAgain: "再来一局",
			backLobby: "返回大堂",
			waitHost: "等待主机开始下一局",
			ruleFields: "场地放置规则",
			ruleEternals: "永恒者图鉴",
			ruleStages: "各关目标",
			ruleSolo: "单人与剧情",
			ruleRecipes: "宝石配方",
			rulePlacement: "放置与覆盖",
			rare: "万能牌",
			skull: "骷髅牌",
			campCard: "营地奖励牌",
			abilityCard: "能力牌",
			cardName: "{{color}} {{n}}",
			covered: "下方覆盖 {{n}} 张牌",
			puzzle: "拼图",
			puzzleLevel: "拼图 {{n}} / 4",
			dragon: "巨龙",
			egg: "龙蛋",
			discGoal: "四色指示物",
			riverKey: "五张5或7",
			riverStar: "两张绿3与三张8",
			riverDisc: "守门人指示物",
			starGoal: "四颗星",
			handJewels: "三种手牌宝石",
			needTwo: "本次必须连续出两张牌",
			rules: "目标：\n· A关的目标是取得4颗星；B至F关的目标是取得4把钥匙。\n· 单人剧情连续挑战A至E，每关还须制作六种常规宝石。\n准备：\n· 每人的起始牌库包含5张本色初始牌，并从中抽取3张作为起始手牌；两人游戏中，牌库另加入2张副色牌。\n· 三行各有七个位置，永恒者占据右侧位置。\n· 三人使用六种宝石配方，其他人数使用八种。\n流程：\n· 每回合选择出牌、制作宝石，或消耗1颗爱心，将1张手牌赠送给其他玩家。\n· 回合结束从自己的牌库将手牌补至三张。\n· 场地相邻牌不能同色或同数字，还须遵循所在场地与诅咒限制。\n· 双色牌可在出牌前翻转；落桌后按左右相邻边检查颜色。\n· 万能牌可忽略放置限制，女巫的禁用仍然有效。\n· 数字牌须从左向右覆盖骷髅；覆盖牌必须含骷髅颜色。\n· 填满一行且没有未覆盖骷髅时，选择复苏该行一位永恒者。\n· 将其牌组加入本人牌库底，清空该行，并启用其诅咒。\n· 制作宝石可解除诅咒，用过的手牌进入河流。\n· 河流达到五张时获得一张奖励，再清空河流。\n· 第四次填满某一行时，获得该行的奖励，随后封闭该行。\n结算：\n· 无法行动、河流奖励耗尽或守门人牌库耗尽时失败。\n· 同一回合同时达成胜负条件时，胜利优先。\n· 各关目标、场地图鉴与单人差异见下方说明。",
			creatures: {
				phoenix: "凤凰",
				mermaid: "美人鱼",
				king: "国王",
				fairy: "仙子",
				ghost: "幽灵",
				skeleton: "骷髅",
				witch: "女巫",
				vampire: "吸血鬼",
				medusa: "美杜莎",
				minotaur: "牛头人",
				kraken: "海妖",
				mummy: "木乃伊",
				pegasus: "天马",
				barong: "巴隆",
				jinn: "精灵",
				kyubi: "九尾",
				kappa: "河童",
				cyclops: "独眼巨人",
				yeti: "雪人",
				golem: "魔像",
				cat: "爱猫"
			},
			fields: {
				camp: "营地",
				mountain: "山地",
				cave: "洞穴",
				forest: "森林",
				lake: "湖泊",
				grassland: "草原",
				riverside: "河岸",
				valley: "山谷",
				desert: "沙漠",
				swamp: "沼泽",
				labyrinth: "迷宫",
				castle: "城堡",
				lostForest: "迷失森林",
				fog: "浓雾",
				festival: "庆典"
			},
			fieldRules: {
				camp: "在营地放置卡牌时，仅须遵循公共放置规则。",
				mountain: "从左至右，数字必须递增。",
				cave: "从左至右，数字必须递减。",
				forest: "相邻两张牌的数字不能连续。",
				lake: "从左至右，卡牌颜色须按红、蓝、绿、黄的顺序循环；紫色可以替代所需颜色。",
				grassland: "只能放置数字为1、2、3、4、8或9的牌。",
				riverside: "只能放置数字为奇数的牌。",
				valley: "只能放置数字为偶数的牌。",
				desert: "相邻两张牌的数字必须连续；1与9不视为连续。",
				swamp: "只能放置数字为1至5的牌，颜色还须遵循湖泊的循环顺序。",
				labyrinth: "按本轮容量，从左至右排列的数字须构成回文；正中间的两张牌允许数字相同。",
				castle: "从左至右，数字必须递增，并保持同一颜色；紫色可以替代所需颜色。",
				lostForest: "相邻两张牌的数字至少相差3，并须保持同一颜色；紫色可以替代所需颜色。",
				fog: "所有卡牌须保持同一数字，相邻两张牌的颜色仍不能相同。",
				festival: "每回合可向场地或河流连续出一至两张牌。"
			},
			recipes: {
				any2: "任意两张牌",
				any3: "任意三张牌",
				color3: "三张同色牌",
				different3: "三张不同色牌",
				edge: "一张1或9",
				number2: "两张同数字牌",
				number3: "三张同数字牌",
				159: "1、5、9各一张",
				holding: "一张4或任意两张牌",
				riverColors: "红蓝绿黄各一与任意一张",
				riverFive: "五种颜色各一张",
				riverRB: "万能、骷髅、红、蓝与任意一张",
				riverGY: "万能、骷髅、绿、黄与任意一张",
				cat: "爱猫宝石",
				golem0: "阿尔法宝石",
				golem1: "贝塔宝石",
				golem2: "伽马宝石"
			},
			curses: {
				phoenix: "不能向场地放置数字为1的牌。",
				mermaid: "不能向场地放置数字为4的牌。",
				king: "不能向场地放置数字为6的牌。",
				fairy: "不能向场地放置数字为9的牌。",
				ghost: "不能向场地放置数字为5或7的牌。",
				skeleton: "不能向场地放置数字为2或8的牌。",
				witch: "禁止向场地放置万能牌。",
				vampire: "禁止向场地放置紫色牌。",
				medusa: "禁止向场地放置含红色的牌。",
				minotaur: "禁止向场地放置含蓝色的牌。",
				kraken: "禁止向场地放置含绿色的牌。",
				mummy: "禁止向场地放置含黄色的牌。",
				pegasus: "每回合可以向场地或河流连续打出1张或2张牌。",
				barong: "同色牌可以相邻，但连续相邻的同色牌最多为2张。",
				jinn: "回合结束时将手牌补至四张。",
				kyubi: "允许同数字的牌相邻；同数字牌连续相邻最多2张。",
				kappa: "复苏时弃置一张河流奖励。",
				cyclops: "复苏时弃置其他行中最右侧的两张场地牌。",
				yeti: "复苏时，每名玩家各弃置自己牌库顶的1张牌。",
				golem: "复苏时夺取公共复苏区最左侧已奉献的宝石。",
				cat: "在C至E章中，可以免费奉献爱猫宝石，合计只能奉献1次。"
			},
			abilities: {
				phoenix: "· 在A关或A+关，使用第三张A家族能力牌时，获得1颗星。\n· 在E关，本回合公开所有手牌；单人游戏中，改为每个魔像各从自己的牌库抽取1张牌。\n· 在E+关，恢复1颗已消耗的爱心，最多恢复至3颗。\n· 在其他关卡中，取得本关的星奖励。",
				mermaid: "· 在A关或A+关，使用第三张A家族能力牌时，获得1颗星。\n· 在E关，本回合公开所有手牌；单人游戏中，改为每个魔像各从自己的牌库抽取1张牌。\n· 在E+关，恢复1颗已消耗的爱心，最多恢复至3颗。\n· 在其他关卡中，取得本关的星奖励。",
				king: "· 在A关或A+关，使用第三张A家族能力牌时，获得1颗星。\n· 在E关，本回合公开所有手牌；单人游戏中，改为每个魔像各从自己的牌库抽取1张牌。\n· 在E+关，恢复1颗已消耗的爱心，最多恢复至3颗。\n· 在其他关卡中，取得本关的星奖励。",
				fairy: "· 在A关或A+关，使用第三张A家族能力牌时，获得1颗星。\n· 在E关，本回合公开所有手牌；单人游戏中，改为每个魔像各从自己的牌库抽取1张牌。\n· 在E+关，恢复1颗已消耗的爱心，最多恢复至3颗。\n· 在其他关卡中，取得本关的星奖励。",
				ghost: "本回合公开所有玩家的手牌；单人游戏中，改为每个魔像各从自己的牌库抽取1张牌。",
				skeleton: "恢复一颗已消耗的爱心。",
				witch: "免费制作任意一种尚未使用的常规宝石，但数字1、5、9配方除外。",
				vampire: "没有能力牌。",
				medusa: "从弃牌区取出1张万能牌，放回河流奖励区；专业难度下，也可以选择紫色牌。",
				minotaur: "将这张能力牌与场地中任意1张非营地牌交换；这张能力牌作为万能牌留在被交换牌的原位。",
				kraken: "将河流中最多两张牌加入手牌。",
				mummy: "逐张从任意玩家的牌库抽牌，共抽取3张牌；如果所有牌库中的剩余牌不足3张，则抽取全部剩余牌。",
				pegasus: "没有能力牌。",
				barong: "没有能力牌。",
				jinn: "没有能力牌。",
				kyubi: "没有能力牌。",
				kappa: "没有能力牌。",
				cyclops: "没有能力牌。",
				yeti: "没有能力牌。",
				golem: "没有能力牌。",
				cat: "奉献爱猫宝石。"
			},
			upgrades: {
				draw2: "每枚指示物改为抽两张牌",
				drawRandom: "可从随机牌库抽牌",
				give: "赠送一张手牌",
				ignore: "无视诅咒出一张牌",
				storeOther: "可为其他魔像储存手牌",
				giveAll: "一次可赠送任意张手牌",
				river: "将河流一张牌加入手牌",
				giveDisc: "消耗两枚指示物，赠送一枚给其他魔像",
				remove: "弃置场地最右侧的一张牌",
				wild: "消耗两枚指示物，将一张手牌当万能牌出牌",
				redColor: "红色牌制作宝石时可作任意颜色",
				redNumber: "红色牌制作宝石时可作任意数字",
				fourJewels: "手牌正好四张时可全部用于任意常规宝石",
				greenGive: "绿色1、5、9赠牌不消耗爱心",
				blueCards: "准备时增加两张随机蓝色初始牌",
				blueDisc: "每关增加一枚蓝色指示物",
				yellowIgnore: "黄色牌出牌时可无视诅咒",
				refill4: "消耗两枚指示物，本关补牌至四张",
				chooseEternals: "准备时自行选择使用的永恒者"
			},
			choices: {
				revive: "选择复苏的永恒者",
				camp: "选择营地奖励的落点",
				purple: "选择一张紫色牌加入手牌",
				white: "获得白色骷髅牌",
				gatekeeper: "选择一张守门人牌",
				jewel: "选择宝石及接受者",
				recover: "选择放回河流奖励区的牌",
				minotaur: "选择与牛头人能力牌交换的牌",
				riverTake: "选择加入手牌的河流牌",
				draw: "选择从谁的牌库抽牌",
				riverRecipe: "选择制作的河流宝石",
				riverSpecial: "选择河流奖励",
				discColor: "选择颜色",
				keyBonus: "选择钥匙奖励",
				storyDraw: "选择抽牌来源",
				storyGive: "选择赠送对象与手牌",
				storyRemove: "选择弃置的场地牌",
				storyWild: "选择手牌与落点",
				task: "选择一张普通任务",
				eternal: "选择本关不使用的永恒者"
			},
			losses: {
				river: "河流奖励已耗尽。",
				enemy: "守门人牌库已耗尽。",
				blocked: "当前行动者无法完成任何行动。",
				earlyStar: "获得第四颗星前尚未取得全部钥匙。",
				startingTask: "第四颗星到来时，仍有人未达成起始任务。"
			},
			taskRules: {
				starting: "第三或第四颗星到来时，持有本色1至5中的任意一张。",
				number: "第三颗星到来前，向场地打出数字 {{n}}。",
				star: "获得一颗实体星。",
				jewel: "制作同色三张、异色三张或同数字三张宝石。",
				lateJewel: "为公共复苏区第七至第九位永恒者奉献宝石。",
				column: "放下最后一张牌，使三行同一列颜色相同。",
				rareHand: "第二或第四颗星到来时，手中持有万能牌。",
				rarePair: "在场地万能牌的右侧紧邻放置另一张万能牌。"
			},
			goals: {
				A: "获得四颗星。",
				B: "复苏上行全部4位B家族永恒者，取得4把钥匙。",
				C: "依次完成四级拼图。",
				D: "通过覆盖骷髅造成伤害，依次取得四把钥匙。",
				E: "完成任务，使四色钥匙各前进两格。",
				F: "完成全部3种手牌宝石配方，在河流中集齐5张数字为5或7的牌，集齐4种颜色的指示物，并取得4颗实体星。",
				"A+": "取得全部4颗星即可获胜。可以使用美杜莎的能力恢复河流奖励。",
				"B+": "复苏全部4位B家族永恒者；庆典期间，每次出牌行动必须连续打出2张牌。",
				"C+": "每一级的2个拼图必须按图示左右关系同时完成；不能使用万能牌、牛头人能力牌或营地牌替代所需颜色。",
				"D+": "每把钥匙须由对应颜色的玩家造成最后伤害；取得最后一把钥匙时，必须使守门人的生命恰好降至0点。",
				"E+": "在行动顺序中，为下一位玩家完成普通任务。先取得全部4把钥匙，再获得第四颗星，并在此时达成全部起始任务。"
			},
			guidePlacement: "· 放置万能牌时，不须指定其数字或颜色；后续出牌后，场上卡牌仍须存在符合放置规则的解释。山地的9和洞穴的1之后，可以连续放置万能牌。\n· 在湖泊或沼泽中，紫色牌不能与另一张紫色牌相邻。\n· 骷髅牌可以向右连续放置。数字牌须从左至右覆盖骷髅，全部覆盖后，才能继续向右放置数字牌。\n· 白骷髅可以覆盖场上任意已放置的彩色骷髅，之后可由任意颜色的数字牌覆盖。\n· 未被覆盖的骷髅不能触发复苏或第四轮奖励。",
			guideJewels: "· 每种常规宝石只能制作一次。制作时，双色牌须选择一种颜色；万能牌可以替代所需数字和颜色，能力牌只能用于“任意两张牌”或“任意三张牌”配方。\n· 三人游戏移除“任意两张牌”和“任意三张牌”配方。\n· 制作宝石时，选择一位尚未获得奉献的永恒者。用来制作的全部手牌进入河流；河流达到至少5张牌时，只取得一次奖励，然后清空全部河流牌。",
			guideA: "· 公共复苏区前三位永恒者均获得宝石时，获得1颗星。\n· 公共复苏区第四至第六位永恒者均获得宝石时，获得1颗星。\n· 公共复苏区出现第九位永恒者时，获得1颗星。\n· 使用1、5、9配方制作宝石时，获得1颗星。\n· 完成下行的第四轮时，获得1颗星。\n· 使用第三张A家族能力牌时，获得1颗星。上述每个来源只能获得一次星奖励。",
			guideB: "· 上行开始时放置四位B家族永恒者，可用容量从3张牌起算。\n· 最新复苏的B家族永恒者进入暂留区；原暂留区中的B家族永恒者移至公共复苏区，其诅咒重新生效。\n· 暂留区的专用配方为一张数字4，或任意两张牌，可以反复制作。\n· 庆典允许连续出两张牌；两张均放置后，再结算复苏和奖励。河流达到5张牌后，不能继续放置第六张。\n· 取得星奖励时，选择一张剩余的紫色数字牌。",
			guideC: "· 每级随机提供两个候选拼图，完成其中任意一个，即可取得一把钥匙。\n· 拼图须保持图示朝向，不能旋转；刚放置的最后一张牌必须完成拼图，并在复苏之前结算。\n· 用于拼图的双色牌不受左右朝向影响；万能牌、牛头人能力牌和营地牌可以替代所需颜色。\n· 取得星奖励时，选择一张紫色数字牌。",
			guideD: "· 守门人在每个阶段开始时有20点生命。四个阶段须依次造成5、10、15、20点伤害，才能取得对应钥匙；每次取得钥匙后重置生命，忽略溢出伤害。\n· 用数字牌覆盖同色骷髅时，造成等于该数字的伤害；万能牌造成0点伤害。\n· 所有玩家各行动一次后，守门人翻开一张牌；两人游戏中，改为每人各行动两次后翻牌。\n· 取得星奖励时，获得一张白骷髅牌。",
			guideE: "· 完成任务时，使本色钥匙前进一格。本色钥匙已前进两格后，继续推进尚未使用的颜色。\n· 四人游戏中，本色钥匙完成后，弃置该玩家的剩余任务。三人游戏中，本色钥匙完成时，只额外抽取一次任务。两人游戏中，每次完成任务都再抽一张，直到任务牌抽完。\n· 取得第一颗星时，解锁交流盘；取得第二颗星时，公开任务；取得第三至第五颗星时，在当前回合暂时公开所有手牌。\n· 起始任务在取得第三颗或第四颗星时核对；数字任务必须在取得第三颗星之前完成。",
			guideF: "· 每行各放置一位A、B、C家族永恒者。每人以D家族牌组开始游戏，其正面效果仅对本人有效。\n· 每人只能进行一次个人复苏；两人游戏中，每人可以进行两次，须先复苏主色，再复苏副色。\n· 完成三种手牌宝石配方、河流中集齐5张数字5或7、集齐四色指示物，以及取得4颗实体星，分别获得一把钥匙。\n· 每取得一把钥匙时，可以选择奖励；最后一把钥匙不结算此奖励。\n· 河流达到5张牌时，可以制作一种河流宝石；特殊组合还会额外奖励星、钥匙或守门人指示物。\n· 永久河流万能牌可以参与配方。取得它之后，允许向河流放置骷髅牌。\n· 完成下行的第四轮时，复苏巨龙，将场中非营地的顶牌和一张守门人牌洗混，放到本人牌库底。此后，河流奖励耗尽不再导致失败，下行会出现四位E家族永恒者。",
			guideAplus: "· 使用初学场地，并确保本关包含美杜莎。\n· 河流奖励区起始时为空，弃牌区放置一张万能牌。\n· 不放置分别对应两组三位永恒者奉献目标的星。",
			guideBplus: "· 守门人按D关的行动节奏行动，但不能受到伤害。\n· 庆典期间，出牌行动必须连续打出两张牌；制作宝石、使用能力和赠送手牌不受此限制。",
			guideCplus: "· 同一级的两个拼图必须按图示左右关系同时完成，允许中间有间隔，也允许共用卡牌。\n· 万能牌、牛头人能力牌和营地牌不能构成拼图的任何部分。",
			guideDplus: "· 取得四把钥匙所需达到的生命门槛，依次为10、5、0、0点。\n· 必须由下一把钥匙对应颜色的玩家造成最后伤害；其他颜色造成的伤害最多使生命降至门槛上方1点。\n· 超过门槛的每点伤害，使终结者从自己的牌库顶弃置一张牌；牌库不足时，不会改为弃置手牌。最后一把钥匙须精确命中门槛。\n· 每次取得钥匙时，掷四面骰结算反击；根据结果，分别弃置牌库顶牌、两张场地牌、一张河流奖励，或移除一颗已奉献宝石。",
			guideEplus: "· 起始任务公开，其余任务由行动顺序中前一位玩家完成。\n· 每人只有一枚可用的交流盘，且只能放在场地或河流上。\n· 先取得全部四把钥匙，再获得第四颗星；此时，每名玩家手中都须持有一张本色的数字1至5的牌。提前获得第四颗星，或未满足起始任务，均会失败。\n· 取得第二颗或第三颗星时，将爱心恢复至3颗；取得第四颗星时，公开手牌。",
			guideSolo: "· 由一人控制三个魔像，所有手牌公开。\n· 基本模式中，主魔像将手牌补至3张，副魔像补至2张。每枚指示物可以随时使用一次，从所属魔像自己的牌库抽取一张牌。\n· 原本公开手牌的效果，改为每个魔像各从自己的牌库抽取一张牌。\n· F关使用三个D家族永恒者，均将手牌补至3张；精灵改为补至4张。个人复苏使用其中一枚指示物，另一枚可随时使用，以抽取两张牌。",
			guideStory: "· 依阿尔法、贝塔、伽马的顺序控制三个魔像挑战A至E关，均将手牌补至3张。每关额外要求制作并奉献全部六种常规宝石。\n· 剧情指示物只能在所属魔像的回合中、补牌之前使用。黑菱形能力初始已解锁，其他升级须花费星点，并遵循前置条件。\n· 每个魔像每关可以储存一张数字牌或万能牌；历次储存的数字牌须具有相同数字，万能牌不受此数字限制。被储存的实体牌从后续所有牌组中移除。\n· 在A关和B关储存卡牌时，各解锁一次改造，最多解锁两项。",
			guideStoryChanges: "· 剧情模式不使用女巫，B关改用爱猫；须先复苏其他三位B家族永恒者，才能取得爱猫。爱猫宝石在C至E关合计只能奉献一次。\n· D关取得四把钥匙后，守门人停止行动。\n· E关不使用起始任务，每个魔像获得两张任务；储存卡牌时，立即获得一颗魔像宝石。\n· E关还须奉献三颗魔像宝石和爱猫宝石。四颗特殊宝石均已奉献时，可以将最后一颗常规宝石给予爱猫。",
			guideScore: "· 每关根据已取得的星、未使用的爱心，以及手牌和河流中的万能牌计分，分别最多获得4分、2分和2分；五关合计最多40分。\n· 首次失败后可以重试，并扣除1分；第二次失败时，本关记0分，继续下一关。已经购买的升级保留。\n· 每张储存牌获得2分，但C关储存的万能牌获得5分，D关储存的万能牌获得4分。每个魔像的储存牌最多获得15分，三个魔像合计最多45分。\n· 剩余星点最多计15分；总分上限为100分。"
		},
		en: {
			deckContents: "Deck contents",
			cardCount: "{{n}} cards",
			randomDeckContents: "Eight cards from the Random Deck.",
			giveCost: "Give a card, spending {{n}} Heart(s)",
			giveTo: "Give to {{name}}",
			yourHand: "Your hand",
			playTo: "Play to {{field}}",
			moreActions: "More actions",
			chooseHand: "Choose a card",
			abilityProgress: "Ability cards {{n}}/3",
			jewels: "Jewels",
			nextKey: "Next key",
			colorDiscs: "Four colors",
			fourStars: "Four stars",
			chapterFailures: "Chapter failures: {{n}}",
			gatekeeper: "Gatekeeper",
			riverRecipe: "River recipe",
			catNotFound: "Not found yet",
			upgrade: "Upgrade",
			powerPegasus: "Play one or two cards in a row",
			powerBarong: "Up to two cards of the same color may be adjacent",
			powerJinn: "Refill your hand to four cards",
			powerKyubi: "Up to two cards of the same number may be adjacent",
			catStateUsed: "Used",
			catStateUnused: "Unused",
			riverLabel: "River",
			name: "Eternal Decks",
			desc: "Cooperate to revive Eternals and overcome the trials of the Eternal World.",
			errAction: "That action is unavailable. Choose again.",
			stage: "Stage",
			difficulty: "Difficulty",
			mode: "Mode",
			singleStage: "Single stage",
			story: "Solo story",
			primary: "Primary Golem",
			colors: "Player colors and order",
			beginner: "Beginner",
			standard: "Standard",
			expert: "Expert",
			pro: "Pro",
			alpha: "Alpha",
			beta: "Beta",
			gamma: "Gamma",
			red: "Red",
			blue: "Blue",
			green: "Green",
			yellow: "Yellow",
			purple: "Purple",
			white: "White",
			act: "Choose an action",
			resolve: "Resolving",
			after: "You may use discs before ending your turn",
			arrange: "Choose the turn order",
			chapter: "Chapter results",
			won: "Trial complete",
			lost: "Trial failed",
			yourTurn: "Your turn",
			turnOf: "{{name}}’s turn",
			hand: "Hand",
			deck: "Deck",
			river: "River of Life",
			discard: "Discard area",
			revival: "Revival area",
			holding: "Holding area",
			personal: "Personal revival area",
			topRow: "Top row",
			middleRow: "Middle row",
			bottomRow: "Bottom row",
			play: "Play",
			jewel: "Make a jewel",
			give: "Give a card",
			ability: "Use ability",
			store: "Store a card",
			disc: "Use a disc",
			marker: "Communication disc",
			tasks: "Tasks",
			journal: "Story record",
			history: "History",
			details: "Details",
			close: "Close",
			cancel: "Cancel selection",
			confirm: "Confirm",
			endTurn: "End turn",
			flip: "Rotate card",
			firstCard: "Choose where to play the first card",
			secondCard: "Choose a second card, or confirm",
			chooseTarget: "Choose a target",
			chooseRecipe: "Choose a jewel recipe",
			chooseCards: "Choose cards for the jewel",
			chooseRecipient: "Choose an Eternal to receive the jewel",
			chooseTeammate: "Choose a recipient",
			chooseDisc: "Choose a disc ability",
			chooseStored: "Choose a Golem to store the card",
			noAction: "Waiting",
			waiting: "Waiting for {{name}}",
			selected: "Selected",
			available: "Available",
			locked: "Closed",
			empty: "Empty space",
			sleeping: "Dormant",
			cleared: "Jewel offered",
			activeCurse: "Active curses",
			noCurse: "No harmful curses are active",
			hearts: "Hearts",
			stars: "Stars",
			keys: "Keys",
			hp: "HP",
			enemyDeck: "Gatekeeper deck",
			riverRewards: "River bonuses",
			lap: "Lap {{n}}",
			cardsCount: "{{n}} cards",
			tokensCount: "{{n}} discs",
			target: "Target",
			bonus: "Bonus",
			skip: "Skip jewel",
			ownerPersonal: "Revive personally",
			publicRevival: "Revive publicly",
			permanent: "River Rare",
			heartBonus: "Heart recovery ability",
			river3: "Add a River bonus",
			own: "Draw from own deck",
			random: "Draw from Random Deck",
			draw: "Draw",
			giveDisc: "Give a disc",
			ignore: "Play ignoring curses",
			remove: "Discard a card furthest to the right on the Field",
			wild: "Play a card as a Rare",
			refill4: "Refill to four this stage",
			clearMarker: "Recall disc",
			nextChapter: "Next chapter",
			retry: "Retry chapter",
			chapterFailed: "Chapter failed",
			chapterWon: "Chapter complete",
			forcedNext: "Two failures. Continue to the next chapter.",
			starPoints: "Star points",
			buy: "Buy upgrade",
			modify: "Unlock modification",
			stored: "Stored cards",
			score: "Score",
			finalScore: "Final score {{n}} / 100",
			catUnused: "Cat jewel available",
			catUsed: "Cat jewel spent",
			golemJewel: "Golem jewel",
			playAgain: "Play again",
			backLobby: "Back to lobby",
			waitHost: "Waiting for the host",
			ruleFields: "Field placement rules",
			ruleEternals: "Eternals",
			ruleStages: "Stage goals",
			ruleSolo: "Solo and story",
			ruleRecipes: "Jewel recipes",
			rulePlacement: "Placement and covering",
			rare: "Rare",
			skull: "Skull",
			campCard: "Camp bonus card",
			abilityCard: "Ability card",
			cardName: "{{color}} {{n}}",
			covered: "{{n}} cards underneath",
			puzzle: "Puzzle",
			puzzleLevel: "Puzzle {{n}} / 4",
			dragon: "Dragon",
			egg: "Dragon egg",
			discGoal: "Four colored discs",
			riverKey: "Five 5s or 7s",
			riverStar: "Two green 3s and three 8s",
			riverDisc: "Gatekeeper disc",
			starGoal: "Four Stars",
			handJewels: "Three hand jewels",
			needTwo: "Play two cards this turn",
			rules: "Goal:\n· Gain four Stars in A, or four Keys in B–F.\n· Story mode spans A–E and also requires six regular jewels each stage.\nSetup:\n· Each player starts with five cards and a hand of three; two players add two secondary-color cards.\n· Each Field row has seven spaces; dormant Eternals occupy the right spaces.\n· Three players use six jewel recipes; other player counts use eight.\nTurn:\n· Play cards, generate a jewel, or spend a Heart to give one hand card.\n· End your turn by refilling to three from your own deck.\n· Adjacent cards differ in color and number; follow Field rules and active curses.\n· Rotate two-color cards before play; compare the edges that touch.\n· Rares ignore placement rules, except the Witch’s prohibition.\n· Cover Skulls from left to right with cards containing their color.\n· Fill a row with no uncovered Skulls to choose an Eternal to revive.\n· Add its deck to the bottom of yours, clear the row and activate its curse.\n· Generate jewels to remove curses; spent hand cards go to the River.\n· At five River cards, gain one bonus, then clear the River.\n· Complete a row’s fourth lap for its bonus, then close it.\nEnding:\n· Lose if unable to act, or if the River bonus or Gatekeeper supply is exhausted.\n· If victory and defeat occur in one turn, victory takes priority.\n· See below for stage goals, Field rules and solo differences.",
			creatures: {
				phoenix: "Phoenix",
				mermaid: "Mermaid",
				king: "King",
				fairy: "Fairy",
				ghost: "Ghost",
				skeleton: "Skeleton",
				witch: "Witch",
				vampire: "Vampire",
				medusa: "Medusa",
				minotaur: "Minotaur",
				kraken: "Kraken",
				mummy: "Mummy",
				pegasus: "Pegasus",
				barong: "Barong",
				jinn: "Jinn",
				kyubi: "Kyubi",
				kappa: "Kappa",
				cyclops: "Cyclops",
				yeti: "Yeti",
				golem: "Golem",
				cat: "Beloved Cat"
			},
			fields: {
				camp: "Camp",
				mountain: "Mountain",
				cave: "Cave",
				forest: "Forest",
				lake: "Lake",
				grassland: "Grassland",
				riverside: "Riverside",
				valley: "Valley",
				desert: "Desert",
				swamp: "Swamp",
				labyrinth: "Labyrinth",
				castle: "Castle",
				lostForest: "Lost Forest",
				fog: "Fog",
				festival: "Festival"
			},
			fieldRules: {
				camp: "Only common placement rules apply.",
				mountain: "Numbers must increase from left to right.",
				cave: "Numbers must decrease from left to right.",
				forest: "Adjacent numbers cannot be consecutive.",
				lake: "From left to right, card colors must follow the repeating sequence red, blue, green and yellow. Purple may substitute for the required color.",
				grassland: "You may only place cards numbered 1, 2, 3, 4, 8 or 9.",
				riverside: "You may only place cards with odd numbers.",
				valley: "You may only place cards with even numbers.",
				desert: "Adjacent cards must have consecutive numbers. The numbers 1 and 9 are not consecutive.",
				swamp: "You may only place cards numbered 1–5, and their colors must follow the Lake sequence.",
				labyrinth: "The numbers must form a palindrome across this lap’s capacity. The two cards in the middle may have matching numbers.",
				castle: "Numbers must increase from left to right, and the cards must share one color. Purple may substitute for the required color.",
				lostForest: "Adjacent numbers must differ by at least 3, and the cards must share one color. Purple may substitute for the required color.",
				fog: "All cards must share the same number, but adjacent cards must have different colors.",
				festival: "Play one or two cards to the Field and/or River each turn."
			},
			recipes: {
				any2: "Any two cards",
				any3: "Any three cards",
				color3: "Three of one color",
				different3: "Three different colors",
				edge: "One 1 or 9",
				number2: "Two equal numbers",
				number3: "Three equal numbers",
				159: "One each: 1, 5, 9",
				holding: "One 4 or any two cards",
				riverColors: "Red, blue, green, yellow and any card",
				riverFive: "One card of each color",
				riverRB: "Rare, Skull, red, blue and any card",
				riverGY: "Rare, Skull, green, yellow and any card",
				cat: "Cat jewel",
				golem0: "Alpha jewel",
				golem1: "Beta jewel",
				golem2: "Gamma jewel"
			},
			curses: {
				phoenix: "You cannot place cards numbered 1 in the Field.",
				mermaid: "You cannot place cards numbered 4 in the Field.",
				king: "You cannot place cards numbered 6 in the Field.",
				fairy: "You cannot place cards numbered 9 in the Field.",
				ghost: "You cannot place cards numbered 5 or 7 in the Field.",
				skeleton: "You cannot place cards numbered 2 or 8 in the Field.",
				witch: "You cannot place Rare cards in the Field.",
				vampire: "You cannot place purple cards in the Field.",
				medusa: "You cannot place cards containing red in the Field.",
				minotaur: "You cannot place cards containing blue in the Field.",
				kraken: "You cannot place cards containing green in the Field.",
				mummy: "You cannot place cards containing yellow in the Field.",
				pegasus: "Play one or two cards to the Field and/or River each turn.",
				barong: "Up to two cards of the same color may be adjacent.",
				jinn: "Refill your hand to four at the end of your turn.",
				kyubi: "Up to two cards of the same number may be adjacent.",
				kappa: "On revival, discard one River bonus.",
				cyclops: "On revival, discard two rightmost cards from the other Field rows.",
				yeti: "On revival, each player discards their deck’s top card.",
				golem: "On revival, steal the leftmost offered jewel in the Revival area.",
				cat: "Offer the Cat jewel for free once across chapters C–E."
			},
			abilities: {
				phoenix: "· In stage A or A+, gain 1 Star when you use the third A-family Ability card.\n· In stage E, reveal all hands for the current turn. In solo play, each Golem instead draws 1 card from its own deck.\n· In stage E+, recover 1 spent Heart, up to a maximum of 3 Hearts.\n· In other stages, receive the Star bonus for that stage.",
				mermaid: "· In stage A or A+, gain 1 Star when you use the third A-family Ability card.\n· In stage E, reveal all hands for the current turn. In solo play, each Golem instead draws 1 card from its own deck.\n· In stage E+, recover 1 spent Heart, up to a maximum of 3 Hearts.\n· In other stages, receive the Star bonus for that stage.",
				king: "· In stage A or A+, gain 1 Star when you use the third A-family Ability card.\n· In stage E, reveal all hands for the current turn. In solo play, each Golem instead draws 1 card from its own deck.\n· In stage E+, recover 1 spent Heart, up to a maximum of 3 Hearts.\n· In other stages, receive the Star bonus for that stage.",
				fairy: "· In stage A or A+, gain 1 Star when you use the third A-family Ability card.\n· In stage E, reveal all hands for the current turn. In solo play, each Golem instead draws 1 card from its own deck.\n· In stage E+, recover 1 spent Heart, up to a maximum of 3 Hearts.\n· In other stages, receive the Star bonus for that stage.",
				ghost: "Reveal all players’ hands for the current turn. In solo play, each Golem instead draws 1 card from its own deck.",
				skeleton: "Recover one spent Heart.",
				witch: "Generate an unused jewel for free, except 1/5/9.",
				vampire: "This Eternal has no Ability card.",
				medusa: "Return 1 Rare from the discard area to the River bonus area. On Pro difficulty, you may choose a purple card instead.",
				minotaur: "Exchange this Ability card with any non-Camp card in the Field. Leave this Ability card in the chosen space, where it acts as a Rare.",
				kraken: "Add up to two River cards to your hand.",
				mummy: "Draw three cards, one at a time, from any player decks; draw all if fewer remain.",
				pegasus: "This Eternal has no Ability card.",
				barong: "This Eternal has no Ability card.",
				jinn: "This Eternal has no Ability card.",
				kyubi: "This Eternal has no Ability card.",
				kappa: "This Eternal has no Ability card.",
				cyclops: "This Eternal has no Ability card.",
				yeti: "This Eternal has no Ability card.",
				golem: "This Eternal has no Ability card.",
				cat: "Offer the Cat jewel."
			},
			upgrades: {
				draw2: "Draw two cards per disc",
				drawRandom: "May draw from the Random Deck",
				give: "Give one hand card",
				ignore: "Play one card ignoring curses",
				storeOther: "Store a card for another Golem",
				giveAll: "Give any number of hand cards",
				river: "Take one River card",
				giveDisc: "Spend two discs to give another Golem one disc",
				remove: "Discard a card furthest to the right on the Field",
				wild: "Spend two discs to play a hand card as a Rare",
				redColor: "Red cards may be any color for jewels",
				redNumber: "Red cards may be any number for jewels",
				fourJewels: "Spend all four hand cards for any regular jewel",
				greenGive: "Give green 1/5/9 without spending a Heart",
				blueCards: "Start with two random blue Starting cards",
				blueDisc: "Gain one extra blue disc each stage",
				yellowIgnore: "Yellow cards ignore curses",
				refill4: "Spend two discs to refill to four for this stage",
				chooseEternals: "Choose the Eternals during setup"
			},
			choices: {
				revive: "Choose an Eternal to revive",
				camp: "Choose a Field row for the Camp bonus",
				purple: "Choose a purple card for your hand",
				white: "Gain a White Skull",
				gatekeeper: "Choose a Gatekeeper card",
				jewel: "Choose a jewel and recipient",
				recover: "Choose a card to restore as a River bonus",
				minotaur: "Choose a Field card to exchange with Minotaur",
				riverTake: "Choose a River card for your hand",
				draw: "Choose a deck to draw from",
				riverRecipe: "Choose a River jewel",
				riverSpecial: "Choose a River reward",
				discColor: "Choose a color",
				keyBonus: "Choose a Key bonus",
				storyDraw: "Choose a deck to draw from",
				storyGive: "Choose a recipient and cards",
				storyRemove: "Choose a Field card to discard",
				storyWild: "Choose a card and Field row",
				task: "Choose a General Task",
				eternal: "Choose an Eternal to leave out"
			},
			losses: {
				river: "The River bonus supply is empty.",
				enemy: "The Gatekeeper deck is empty.",
				blocked: "The current player cannot take an action.",
				earlyStar: "The fourth Star was gained before all Keys.",
				startingTask: "A Starting Task was incomplete at the fourth Star."
			},
			taskRules: {
				starting: "At the third or fourth Star, hold a 1–5 in your player color.",
				number: "Play {{n}} to the Field before the third Star.",
				star: "Gain a Star token.",
				jewel: "Generate a same-color, different-color or same-number three-card jewel.",
				lateJewel: "Offer a jewel to the 7th–9th Eternal in the Revival area.",
				column: "Play the final card making a column of one color across all three rows.",
				rareHand: "Hold a Rare when the second or fourth Star is gained.",
				rarePair: "Play a Rare directly to the right of another Rare in the Field."
			},
			goals: {
				A: "Gain four Stars.",
				B: "Revive all 4 B-family Eternals in the top row to gain all 4 Keys.",
				C: "Complete all four puzzle levels.",
				D: "Cover Skulls to deal damage and gain all four Keys.",
				E: "Complete tasks to advance all four Keys twice.",
				F: "Complete all 3 hand-jewel recipes, collect 5 River cards numbered 5 or 7, collect discs in all 4 colors, and gain 4 actual Star tokens.",
				"A+": "Gain all 4 Stars to win. You may use Medusa’s ability to restore River bonuses.",
				"B+": "Revive all 4 B-family Eternals. During Festival, every play action must play exactly 2 consecutive cards.",
				"C+": "Complete both puzzles of each level simultaneously in their shown left-to-right relationship. Rares, the Minotaur Ability card and Camp cards cannot substitute for required colors.",
				"D+": "The player matching each Key’s color must deal the final damage. To gain the last Key, reduce the Gatekeeper’s health to exactly 0.",
				"E+": "Complete the next player’s General Tasks in turn order. Gain all 4 Keys before gaining the fourth Star, and complete all Starting Tasks at that point."
			},
			guidePlacement: "· When you place a Rare, do not assign it a fixed number or color. After each later play, the cards must still permit at least one interpretation that follows the placement rules. Any number of Rares may follow a Mountain 9 or a Cave 1.\n· Purple cards cannot be adjacent to other purple cards in a Lake or Swamp.\n· Skulls may extend a row to the right. Number cards must cover the Skulls from left to right; cover all of them before extending the row with more number cards.\n· A White Skull may cover any exposed colored Skull, and may later be covered by a number card of any color.\n· Uncovered Skulls cannot trigger revival or fourth-lap bonuses.",
			guideJewels: "· Each regular jewel may be generated only once. Choose one color for each two-color card; Rares may replace required numbers and colors. Ability cards may only be used for the Any Two or Any Three recipes.\n· With 3 players, omit the Any Two and Any Three recipes.\n· When generating a jewel, choose an Eternal that has not received an offering. All cards spent from your hand enter the River. If the River reaches 5 or more cards, receive one bonus, then clear all River cards.",
			guideA: "· Gain 1 Star when all of the first 3 Eternals in the public Revival area have jewels.\n· Gain 1 Star when all of the fourth through sixth Eternals in the public Revival area have jewels.\n· Gain 1 Star when the ninth Eternal enters the public Revival area.\n· Gain 1 Star when you generate the 1/5/9 jewel.\n· Gain 1 Star when you complete the bottom row’s fourth lap.\n· Gain 1 Star when you use the third A-family Ability card. Each listed source grants its Star only once.",
			guideB: "· The top row begins with 4 B-family Eternals, so its initial capacity is 3 cards.\n· The most recently revived B-family Eternal enters Holding. The previous B-family Eternal moves from Holding to the public Revival area, and its curse becomes active again.\n· Holding has a repeatable recipe requiring one card numbered 4 or any 2 cards.\n· During Festival, you may play 2 consecutive cards. Resolve revivals and bonuses after both cards have been placed. Once the River has 5 cards, you cannot play a sixth card there.\n· When receiving a Star bonus, choose one remaining purple number card.",
			guideC: "· Randomly provide 2 candidate puzzles at each level. Complete either one to gain a Key.\n· Keep the orientation shown on the puzzle. The last card just placed must complete the puzzle, and the puzzle resolves before revival.\n· Two-color cards may use either color regardless of their left-to-right orientation. Rares, the Minotaur Ability card and Camp cards may substitute for required colors.\n· When receiving a Star bonus, choose a purple number card.",
			guideD: "· The Gatekeeper begins each phase with 20 health. The four phases require 5, 10, 15 and 20 damage respectively to gain their Keys. After each Key, reset its health and ignore excess damage.\n· Covering a Skull with a matching-color number card deals damage equal to the number. A Rare deals 0 damage.\n· The Gatekeeper reveals a card after every player has taken one turn. With 2 players, it instead acts after each player has taken two turns.\n· When receiving a Star bonus, gain a White Skull card.",
			guideE: "· Completing a task advances your color’s Key one space. After that Key has advanced twice, advance unused colors instead.\n· With 4 players, discard your remaining tasks after completing your own Key. With 3 players, draw one extra task when completing your own Key. With 2 players, draw another task after every completion until the task deck is empty.\n· The first Star unlocks communication discs. The second Star reveals tasks. The third through fifth Stars reveal all hands for the current turn.\n· Check Starting Tasks at the third or fourth Star. Number tasks must be completed before the third Star.",
			guideF: "· Each row contains one A-family, one B-family and one C-family Eternal. Each player begins with a D-family deck whose positive effect applies only to that player.\n· Each player may perform personal revival once. With 2 players, each may do so twice, using the main color before the secondary color.\n· Completing all 3 hand-jewel recipes, collecting 5 River cards numbered 5 or 7, collecting discs in all 4 colors, and gaining 4 actual Star tokens each grant a Key.\n· Choose a reward whenever you gain a Key, except that the final Key grants no such reward.\n· At 5 River cards, you may generate one River jewel. Special combinations also grant a Star, a Key or a Gatekeeper disc.\n· The permanent River Rare may participate in recipes. After acquiring it, you may play Skulls to the River.\n· The bottom row’s fourth lap revives the Dragon. Shuffle the exposed non-Camp Field cards and one Gatekeeper card together, then place them at the bottom of your deck. The Dragon prevents defeat from exhausting River bonuses and brings 4 E-family Eternals into the bottom row.",
			guideAplus: "· Use Beginner Fields and include Medusa.\n· Start with no River bonuses and with one Rare in the discard area.\n· Omit both Stars awarded for offerings to groups of 3 Eternals.",
			guideBplus: "· The Gatekeeper follows the stage D schedule and cannot take damage.\n· During Festival, a play action must play exactly 2 consecutive cards. Generating jewels, using abilities and giving cards are unaffected.",
			guideCplus: "· Complete both puzzles of a level simultaneously in their shown left-to-right relationship. Gaps and shared cards are allowed.\n· Rares, the Minotaur Ability card and Camp cards cannot form any part of a puzzle.",
			guideDplus: "· The health thresholds for the four Keys are 10, 5, 0 and 0 respectively.\n· The player matching the next Key’s color must deal the final damage. Other colors cannot reduce health below 1 point above the threshold.\n· For each point of damage beyond the threshold, the finisher discards 1 card from the top of their deck. An empty deck does not require discarding hand cards. The final Key requires exact damage.\n· After each Key, roll a four-sided die for the counterattack. Depending on the result, discard deck-top cards, 2 Field cards, a River bonus or an offered jewel.",
			guideEplus: "· Starting Tasks are public. Other tasks are completed by the previous player in turn order.\n· Each player has only one usable communication disc, which may be placed only on the Field or River.\n· Gain all 4 Keys before gaining the fourth Star. At that point, every player must hold a card numbered 1–5 in their own color. Gaining the fourth Star too early or failing a Starting Task causes defeat.\n· The second and third Stars restore Hearts to 3. The fourth Star reveals all hands.",
			guideSolo: "· One player controls 3 Golems, with all hands public.\n· In Basic Mode, refill the Primary Golem’s hand to 3 cards and each Secondary Golem’s hand to 2 cards. Each disc may be used once at any time to draw 1 card from its Golem’s own deck.\n· Effects that would reveal hands instead let each Golem draw 1 card from its own deck.\n· In stage F, use 3 D-family Eternals and refill each hand to 3 cards, or 4 for Jinn. One disc is used for personal revival; the other may be used at any time to draw 2 cards.",
			guideStory: "· Take turns as Alpha, Beta and Gamma while playing stages A–E. Refill every hand to 3 cards. Each stage also requires generating and offering all 6 regular jewels.\n· Story discs may be used only during their own Golem’s turn, before refilling. Black-diamond abilities begin unlocked; other upgrades cost Star points and must follow their prerequisites.\n· Each Golem may store one number card or Rare per stage. Stored number cards must match the number stored previously; Rares do not need to match that number. Remove stored physical cards from all later decks.\n· Storing a card in stage A and in stage B each unlocks one modification, up to 2 modifications in total.",
			guideStoryChanges: "· Do not use the Witch in Story mode. Use the Cat in stage B, and revive the other 3 B-family Eternals before taking it. The Cat jewel may be offered only once across stages C–E.\n· In stage D, the Gatekeeper stops after all 4 Keys have been gained.\n· Stage E has no Starting Tasks and deals 2 tasks to each Golem. Storing a card immediately grants one Golem jewel.\n· Stage E also requires offering the 3 Golem jewels and the Cat jewel. After all 4 special jewels have been offered, the final regular jewel may be offered to the Cat.",
			guideScore: "· Each stage awards up to 4 points for Stars, 2 points for unspent Hearts and 2 points for Rares in hands and the River. The five stages award up to 40 points in total.\n· After the first failure, retry with a 1-point penalty. A second failure scores 0 for that stage and advances to the next stage. Keep purchased upgrades.\n· Each stored card scores 2 points, except that a Rare stored in stage C scores 5 and a Rare stored in stage D scores 4. Stored cards score up to 15 points per Golem, or 45 points in total.\n· Unspent Star points add up to 15 points, making the maximum total score 100."
		}
	}
};
//#endregion
export { In as default };
