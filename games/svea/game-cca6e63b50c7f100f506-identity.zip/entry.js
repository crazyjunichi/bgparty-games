import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useI18nSettings as n, useT as r } from "@bgparty/sdk/i18n";
import { SeatBadgedAvatar as i, seatName as a } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as o } from "@bgparty/sdk/avatars";
import { Fragment as s, useEffect as c, useMemo as l, useRef as u, useState as d } from "react";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { IconBack as g, IconBot as _, IconExpand as v, IconLog as y } from "@bgparty/sdk/icons";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region src/games/svea/cards.ts
var x = (e, t, n, r, i) => ({
	id: e,
	income: t,
	prioUnused: n,
	prioUsed: r,
	kind: i
}), S = {
	"central-station": x("central-station", 5, 15, 6, "special"),
	"city-station-owner": x("city-station-owner", 5, 14.5, 2.5, "passive"),
	"infrastructure-push": x("infrastructure-push", 5, 14, 5, "once"),
	"political-influence": x("political-influence", 10, 13, 2, "assignable"),
	"ferry-contract": x("ferry-contract", 5, 12.5, 8, "assignable"),
	"financial-planning": x("financial-planning", 5, 12, 1, "once"),
	"yellow-offboard": x("yellow-offboard", 5, 11, 4, "assignable"),
	"blue-offboard": x("blue-offboard", 5, 10, 3, "assignable"),
	"new-railroad": x("new-railroad", 5, 9, 7, "special"),
	"tax-haven": x("tax-haven", 5, 8.5, 0, "passive"),
	"raising-funds": x("raising-funds", 0, 8, 0, "once"),
	"delayed-permit": x("delayed-permit", 5, 1, 8, "special")
}, C = Object.keys(S), ee = [
	"karlstad",
	"linkoping",
	"vasteras"
];
function w(e) {
	return Math.floor((e - 1) / 2);
}
var te = [
	10,
	15,
	20
], T = {
	S: {
		id: "S",
		home: "stockholm",
		color: "#1d4ed8"
	},
	O: {
		id: "O",
		home: "orebro",
		color: "#1f2937"
	},
	N: {
		id: "N",
		home: "norrkoping",
		color: "#ca8a04"
	},
	J: {
		id: "J",
		home: "jonkoping",
		color: "#b91c1c"
	},
	G: {
		id: "G",
		home: "goteborg",
		color: "#9ca3af"
	}
}, E = Object.keys(T), ne = [
	"yellow",
	"green",
	"brown",
	"grey",
	"black"
];
function D(e, t) {
	return ne.indexOf(e) >= ne.indexOf(t);
}
var O = {
	T2: {
		id: "T2",
		price: 45,
		count: 4,
		stops: 2,
		phase: "yellow"
	},
	T3: {
		id: "T3",
		price: 75,
		count: 3,
		stops: 3,
		phase: "green"
	},
	T4: {
		id: "T4",
		price: 110,
		count: 2,
		stops: 4,
		rusts: "T2",
		phase: "brown"
	},
	T6: {
		id: "T6",
		price: 145,
		count: 2,
		stops: 6,
		rusts: "T3",
		phase: "grey"
	},
	T6P: {
		id: "T6P",
		price: 190,
		count: 5,
		stops: 6,
		rusts: "T3",
		phase: "black",
		doubleEnd: !0
	}
}, k = [
	"dsc",
	"sr1",
	"or1",
	"or2",
	"sr2",
	"or3",
	"sca",
	"or4",
	"sr3",
	"or5",
	"or6",
	"sr4",
	"or7"
];
function A(e) {
	return e === 2 ? 120 : 80;
}
function j(e) {
	return e === 2 ? 12 : 8;
}
function re(e) {
	return e === 2 ? 3 : 2;
}
function ie(e) {
	return e === 2 ? 3 : 2;
}
var ae = [
	25,
	30,
	35,
	40
], M = [
	0,
	0,
	0,
	10,
	20,
	30
], N = [
	0,
	0,
	0,
	0,
	5,
	10
], P = {
	karlstad: {
		id: "karlstad",
		q: 0,
		r: 0,
		kind: "city"
	},
	orebro: {
		id: "orebro",
		q: 1,
		r: 0,
		kind: "city"
	},
	vasteras: {
		id: "vasteras",
		q: 2,
		r: 0,
		kind: "city"
	},
	goteborg: {
		id: "goteborg",
		q: -1,
		r: 1,
		kind: "city"
	},
	lake: {
		id: "lake",
		q: 0,
		r: 1,
		kind: "water"
	},
	norrkoping: {
		id: "norrkoping",
		q: 1,
		r: 1,
		kind: "city"
	},
	stockholm: {
		id: "stockholm",
		q: 2,
		r: 1,
		kind: "city"
	},
	jonkoping: {
		id: "jonkoping",
		q: -1,
		r: 2,
		kind: "city"
	},
	linkoping: {
		id: "linkoping",
		q: 0,
		r: 2,
		kind: "city"
	},
	bay: {
		id: "bay",
		q: 1,
		r: 2,
		kind: "water"
	},
	paleA: {
		id: "paleA",
		q: 1,
		r: -1,
		kind: "plain"
	},
	paleB: {
		id: "paleB",
		q: 3,
		r: -1,
		kind: "plain"
	}
}, F = Object.keys(P), I = [
	[1, 0],
	[0, 1],
	[-1, 1],
	[-1, 0],
	[0, -1],
	[1, -1]
], oe = (e) => (e + 3) % 6;
function L(e, t, n) {
	let [r, i] = I[n];
	return [e + r, t + i];
}
var R = {
	north: {
		id: "north",
		hex: "orebro",
		edge: 5,
		segments: [
			["yellow", 5],
			["brown", 10],
			["grey", 20]
		],
		contract: "yellow"
	},
	west: {
		id: "west",
		hex: "goteborg",
		edge: 3,
		segments: [
			["yellow", 5],
			["brown", 15],
			["black", 25]
		],
		contract: "yellow"
	},
	east: {
		id: "east",
		hex: "stockholm",
		edge: 0,
		segments: [
			["yellow", 10],
			["brown", 5],
			["black", 15]
		],
		contract: "blue"
	},
	sw: {
		id: "sw",
		hex: "jonkoping",
		edge: 2,
		segments: [
			["yellow", 5],
			["green", 10],
			["grey", 15]
		],
		contract: "blue"
	},
	se: {
		id: "se",
		hex: "bay",
		edge: 1,
		segments: [
			["green", 5],
			["brown", 25],
			["grey", 35]
		]
	}
};
Object.keys(R);
function se(e, t) {
	let n = 0;
	for (let [r, i] of R[e].segments) D(t, r) && (n = i);
	return n;
}
var ce = [
	[["karlstad", 3]],
	[["vasteras", 0]],
	[["goteborg", 2], ["jonkoping", 3]]
], le = /* @__PURE__ */ new Map();
for (let e of Object.values(P)) le.set(`${e.q},${e.r}`, e);
var ue = /* @__PURE__ */ new Set([
	"karlstad:1",
	"lake:4",
	"linkoping:4",
	"lake:1",
	"norrkoping:1",
	"bay:4",
	"stockholm:2",
	"bay:5",
	"linkoping:0",
	"bay:3"
]), de = /* @__PURE__ */ new Map();
for (let e of Object.values(R)) de.set(`${e.hex}:${e.edge}`, e.id);
var fe = /* @__PURE__ */ new Map();
ce.forEach((e, t) => {
	for (let [n, r] of e) fe.set(`${n}:${r}`, t);
});
var pe = /* @__PURE__ */ new Set([
	"paleA:3",
	"paleA:4",
	"paleA:5",
	"paleB:0",
	"paleB:1",
	"paleB:4",
	"paleB:5"
]);
function me(e, t) {
	let n = `${e.id}:${t}`, r = de.get(n);
	if (r) return {
		kind: "offboard",
		offboard: r
	};
	let i = fe.get(n);
	if (i !== void 0) return {
		kind: "stub",
		stub: i
	};
	let [a, o] = L(e.q, e.r, t), s = le.get(`${a},${o}`);
	return s ? e.kind === "water" || s.kind === "water" ? ue.has(n) ? {
		kind: "water",
		hex: s.id
	} : { kind: "blocked" } : {
		kind: "hex",
		hex: s.id
	} : pe.has(n) ? { kind: "exit" } : { kind: "blocked" };
}
var z = F.reduce((e, t) => (e[t] = [
	0,
	1,
	2,
	3,
	4,
	5
].map((e) => me(P[t], e)), e), {}), he = {
	id: "svea",
	tier: "beta",
	mechanics: ["route-building", "stock-holding"],
	interactionTags: [],
	nameKey: "games.svea.name",
	descKey: "games.svea.desc",
	rulesKey: "games.svea.rules",
	icon: "🚂",
	iconImg: "games/svea.webp",
	rulesUrl: {
		zh: "https://rules.bgparty.uuppi.com/svea/zh.pdf",
		en: "https://rules.bgparty.uuppi.com/svea/en.pdf"
	},
	minPlayers: 2,
	maxPlayers: 3,
	bestPlayers: [3],
	accent: "#006aa7",
	releasedAt: "2026-09-21",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, ge = [
	[
		45,
		50,
		55,
		60,
		70,
		80,
		95,
		110,
		130
	],
	[
		40,
		45,
		50,
		55,
		60,
		70,
		80,
		95,
		110
	],
	[
		35,
		40,
		45,
		50,
		55,
		60,
		65,
		75,
		90
	],
	[
		30,
		35,
		40,
		45,
		50,
		55,
		60,
		65
	],
	[
		25,
		30,
		35,
		40,
		45,
		50,
		55
	],
	[
		20,
		25,
		30
	]
], _e = ge.length - 1, ve = [
	{
		row: 4,
		col: 0
	},
	{
		row: 4,
		col: 1
	},
	{
		row: 4,
		col: 2
	},
	{
		row: 4,
		col: 3
	}
];
function ye(e) {
	return ge[e.row][e.col];
}
function be(e) {
	return ye(e) === 130;
}
var xe = (e, t) => Math.min(t, ge[e].length - 1);
function B(e) {
	return e.row === 0 ? e : {
		row: e.row - 1,
		col: xe(e.row - 1, e.col)
	};
}
function V(e) {
	return e.row === _e ? e : {
		row: e.row + 1,
		col: xe(e.row + 1, e.col)
	};
}
function Se(e) {
	return e.col + 1 < ge[e.row].length ? {
		row: e.row,
		col: e.col + 1
	} : B(e);
}
function Ce(e) {
	return e.col > 0 ? {
		row: e.row,
		col: e.col - 1
	} : V(e);
}
function we(e, t) {
	let n = e;
	for (let e = 0; e < t; e++) n = V(n);
	return n;
}
function H(e, t) {
	let n = e;
	for (let e = 0; e < t; e++) n = Se(n);
	return n;
}
//#endregion
//#region src/games/svea/tiles.ts
var U = {
	t7: {
		id: "t7",
		src: "#7",
		color: "yellow",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [3, 4]
	},
	t8: {
		id: "t8",
		src: "#8",
		color: "yellow",
		count: 2,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [3, 5]
	},
	t9: {
		id: "t9",
		src: "#9",
		color: "yellow",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [0, 3]
	},
	y5a: {
		id: "y5a",
		src: "2CDE334D",
		color: "yellow",
		count: 2,
		slots: 1,
		value: 5,
		cost: 5,
		edges: [0, 3]
	},
	y5b: {
		id: "y5b",
		src: "4B667C3F",
		color: "yellow",
		count: 3,
		slots: 1,
		value: 5,
		cost: 5,
		edges: [3, 5]
	},
	y5c: {
		id: "y5c",
		src: "04804D12",
		color: "yellow",
		count: 2,
		slots: 1,
		value: 5,
		cost: 5,
		edges: [3, 4]
	},
	t20: {
		id: "t20",
		src: "#20",
		color: "green",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			0,
			1,
			3,
			4
		],
		segs: [[0, 3], [1, 4]]
	},
	t23: {
		id: "t23",
		src: "#23",
		color: "green",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			0,
			1,
			3
		]
	},
	t24: {
		id: "t24",
		src: "#24",
		color: "green",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			0,
			3,
			5
		]
	},
	t25: {
		id: "t25",
		src: "#25",
		color: "green",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			1,
			3,
			5
		]
	},
	t26: {
		id: "t26",
		src: "#26",
		color: "green",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			0,
			2,
			3
		]
	},
	t27: {
		id: "t27",
		src: "#27",
		color: "green",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			0,
			3,
			4
		]
	},
	t28: {
		id: "t28",
		src: "#28",
		color: "green",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			1,
			2,
			3
		]
	},
	t29: {
		id: "t29",
		src: "#29",
		color: "green",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			3,
			4,
			5
		]
	},
	g10a: {
		id: "g10a",
		src: "8551FFD4",
		color: "green",
		count: 2,
		slots: 2,
		value: 10,
		cost: 5,
		edges: [
			0,
			2,
			3
		]
	},
	g10b: {
		id: "g10b",
		src: "64834CFC",
		color: "green",
		count: 2,
		slots: 2,
		value: 10,
		cost: 5,
		edges: [
			0,
			3,
			4
		]
	},
	g10c: {
		id: "g10c",
		src: "A7AEEABD",
		color: "green",
		count: 1,
		slots: 2,
		value: 10,
		cost: 5,
		edges: [
			1,
			3,
			5
		]
	},
	g10d: {
		id: "g10d",
		src: "B803D38A",
		color: "green",
		count: 2,
		slots: 2,
		value: 10,
		cost: 5,
		edges: [
			3,
			4,
			5
		]
	},
	t40: {
		id: "t40",
		src: "#40",
		color: "brown",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			1,
			3,
			5
		]
	},
	t44: {
		id: "t44",
		src: "#44",
		color: "brown",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			0,
			1,
			3,
			4
		],
		segs: [[0, 3], [1, 4]]
	},
	t47: {
		id: "t47",
		src: "#47",
		color: "brown",
		count: 1,
		slots: 0,
		value: 0,
		cost: 0,
		edges: [
			0,
			1,
			3,
			4
		]
	},
	b15a: {
		id: "b15a",
		src: "A818AA90",
		color: "brown",
		count: 2,
		slots: 2,
		value: 15,
		cost: 5,
		edges: [
			0,
			3,
			4,
			5
		]
	},
	b15b: {
		id: "b15b",
		src: "B8668BE2",
		color: "brown",
		count: 2,
		slots: 2,
		value: 15,
		cost: 5,
		edges: [
			1,
			2,
			4,
			5
		]
	},
	b10a: {
		id: "b10a",
		src: "40DE5011",
		color: "brown",
		count: 2,
		slots: 2,
		value: 10,
		cost: 5,
		edges: [
			0,
			1,
			3,
			5
		]
	},
	x20a: {
		id: "x20a",
		src: "30D346C0",
		color: "grey",
		count: 1,
		slots: 2,
		value: 20,
		cost: 5,
		edges: [
			0,
			3,
			4,
			5
		]
	},
	x20b: {
		id: "x20b",
		src: "C455739C",
		color: "grey",
		count: 3,
		slots: 2,
		value: 20,
		cost: 5,
		edges: [
			0,
			1,
			3,
			5
		]
	},
	k30: {
		id: "k30",
		src: "55297C93",
		color: "black",
		count: 1,
		slots: 3,
		value: 0,
		values: [
			30,
			20,
			10
		],
		cost: 10,
		edges: [
			0,
			1,
			3,
			4
		]
	}
}, Te = Object.keys(U), Ee = {
	yellow: null,
	green: "yellow",
	brown: "green",
	grey: "brown",
	black: null
}, W = (e, t) => (e + 5 + t) % 6;
function De(e) {
	let t = /* @__PURE__ */ new Map();
	return e.segs ? e.segs.forEach((e, n) => e.forEach((e) => t.set(e, n))) : e.edges.forEach((e) => t.set(e, 0)), t;
}
function Oe(e, t) {
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = (e) => (n.has(e.key) || n.set(e.key, e), n.get(e.key));
	for (let t of Object.keys(e)) {
		let n = U[e[t].tile], a = De(n);
		r.set(t, a);
		let o = n.segs ? n.segs.length : 1;
		for (let e = 0; e < o; e++) i({
			key: `${t}:${e}`,
			kind: n.slots > 0 ? "city" : "plain",
			hex: t,
			adj: []
		});
	}
	let a = (e, t, r) => {
		let i = n.get(e), a = n.get(t);
		i.adj.some((e) => e.to === t) || i.adj.push({
			to: t,
			segs: r
		}), a.adj.some((t) => t.to === e) || a.adj.push({
			to: e,
			segs: r
		});
	};
	for (let n of Object.keys(e)) {
		let o = e[n], s = U[o.tile], c = r.get(n);
		for (let l of s.edges) {
			let s = W(l, o.rot), u = `${n}:${c.get(l)}`, d = `${u}:${s}`, f = z[n][s];
			if (f.kind === "hex" || f.kind === "water") {
				let t = e[f.hex];
				if (!t) continue;
				let n = U[t.tile], i = oe(s), o = n.edges.find((e) => W(e, t.rot) === i);
				if (o === void 0) continue;
				let c = `${f.hex}:${r.get(f.hex).get(o)}`;
				a(u, c, [d, `${c}:${i}`]);
			} else if (f.kind === "offboard") {
				let e = `off:${f.offboard}`;
				i({
					key: e,
					kind: "offboard",
					offboard: f.offboard,
					adj: []
				}), a(u, e, [d]);
			} else if (f.kind === "stub") {
				if (!t.nrcBars[f.stub]) continue;
				let e = `stub:${f.stub}`;
				i({
					key: e,
					kind: "stub",
					stub: f.stub,
					adj: []
				}), a(u, e, [d]);
			}
		}
	}
	return n;
}
function G(e, t, n) {
	let r = Oe(e, n), i = /* @__PURE__ */ new Set(), a = [];
	for (let [n, r] of Object.entries(e)) {
		if (!r.stations.some((e) => e.company === t && e.active)) continue;
		let e = U[r.tile].segs ? U[r.tile].segs.length : 1;
		for (let t = 0; t < e; t++) i.add(`${n}:${t}`), a.push(`${n}:${t}`);
	}
	let o = /* @__PURE__ */ new Set();
	for (; a.length > 0;) {
		let n = r.get(a.pop());
		if (n) {
			if (n.hex) {
				o.add(n.hex);
				let r = e[n.hex];
				if (ke(r, U[r.tile].slots, t)) continue;
			}
			for (let e of n.adj) i.has(e.to) || (i.add(e.to), a.push(e.to));
		}
	}
	return o;
}
function ke(e, t, n) {
	let r = e.stations.filter((e) => !e.central && !e.reserved);
	return r.length < t ? !1 : !r.some((e) => e.company === n);
}
function Ae(e, t) {
	return e.stations.some((e) => e.company === t && e.active);
}
function je(e, t, n, r) {
	let i = e[t], a = U[i.tile], o;
	if (a.values) {
		let e = i.stations.findIndex((e) => e.company === n);
		o = e >= 0 ? a.values[e] : 10;
	} else o = a.value;
	let s = r.centralDouble === t ? 2 : 1, c = i.stations.filter((e) => e.active).length, l = o + 5 * c * s;
	return r.cityOwner && r.cityOwner.hex === t && r.cityOwner.company !== n && (l -= 5), l;
}
var Me = {
	yellow: 0,
	green: 0,
	brown: 1,
	grey: 1,
	black: 2
};
function Ne(e, t, n, r) {
	if (e.kind === "city") {
		let i = je(r, e.hex, t, n), a = U[r[e.hex].tile], o = a.values ? i : a.value;
		return {
			kind: "city",
			id: e.hex,
			base: o,
			bonus: i - o,
			total: i
		};
	}
	if (e.kind === "offboard") {
		let r = se(e.offboard, n.devPhase), i = R[e.offboard].contract, a = i && n.contracts[i] === t ? 10 : 0;
		return {
			kind: "offboard",
			id: e.offboard,
			base: r,
			bonus: a,
			total: r + a
		};
	}
	let i = te[Me[n.devPhase]], a = n.nrcCompany === t ? 10 : 0;
	return {
		kind: "stub",
		id: String(e.stub),
		base: i,
		bonus: a,
		total: i + a
	};
}
function Pe(e, t, n, r, i, a) {
	let o = [], s = /* @__PURE__ */ new Set(), c = [...e.values()].filter((e) => e.kind !== "plain"), l = (e, t, n, r) => {
		if (t.length < 2 || !n) return;
		let a = t.reduce((e, t) => e + t.total, 0);
		i && (a += Math.max(t[0].total, t[t.length - 1].total));
		let c = [...r].sort().join("|");
		s.has(c) || (s.add(c), o.push({
			stops: t,
			value: a,
			segs: [...r],
			path: e.map((e) => e.key)
		}));
	}, u = (i, o, s, c, d, f) => {
		l(o, s, c, d);
		for (let p of i.adj) {
			let i = e.get(p.to);
			if (!f.has(i.key)) {
				if (i.kind === "offboard" || i.kind === "stub") {
					if (s.length + 1 > r) continue;
					let e = Ne(i, n, a, t);
					l([...o, i], [...s, e], c, /* @__PURE__ */ new Set([...d, ...p.segs]));
					continue;
				}
				if (i.kind === "city") {
					if (s.length + 1 > r) continue;
					let e = t[i.hex], m = U[e.tile], h = Ne(i, n, a, t), g = c || Ae(e, n), _ = /* @__PURE__ */ new Set([...d, ...p.segs]), v = [...o, i], y = [...s, h];
					if (l(v, y, g, _), ke(e, m.slots, n)) continue;
					f.add(i.key), u(i, v, y, g, _, f), f.delete(i.key);
					continue;
				}
				f.add(i.key), u(i, [...o, i], s, c, /* @__PURE__ */ new Set([...d, ...p.segs]), f), f.delete(i.key);
			}
		}
	};
	for (let e of c) {
		let r = Ne(e, n, a, t), i = e.kind === "city" && Ae(t[e.hex], n);
		u(e, [e], [r], i, /* @__PURE__ */ new Set(), /* @__PURE__ */ new Set([e.key]));
	}
	return o;
}
function K(e) {
	let t = e.map((e, t) => ({
		...e,
		i: t
	})).sort((e, t) => e.cands.length - t.cands.length), n = [null], r = -1, i = /* @__PURE__ */ new Set(), a = Array(e.length).fill(null), o = (e, s) => {
		if (e === t.length) {
			s > r && (r = s, n[0] = [...a]);
			return;
		}
		let c = t[e];
		if (c.cands.length === 0) {
			o(e + 1, s);
			return;
		}
		for (let t of c.cands) t.segs.some((e) => i.has(e)) || (a[c.i] = t, t.segs.forEach((e) => i.add(e)), o(e + 1, s + t.value), t.segs.forEach((e) => i.delete(e)), a[c.i] = null);
	};
	return o(0, 0), n[0];
}
function q(e, t, n, r) {
	let i = n.map((n) => ({
		train: n,
		cands: Pe(Oe(e, r), e, t, O[n].stops, !!O[n].doubleEnd, r)
	})), a = i.filter((e) => e.cands.length === 0), o = i.filter((e) => e.cands.length > 0), s = K(o), c = null;
	if (!s && o.length > 1) {
		for (let e of [...o].sort((e, t) => e.cands.length - t.cands.length)) if (s = K(o.filter((t) => t !== e)), s) {
			c = e;
			break;
		}
	}
	let l = [];
	for (let e of i) {
		if (a.includes(e) || e === c) {
			l.push({
				train: e.train,
				route: null
			});
			continue;
		}
		let t = o.indexOf(e);
		l.push({
			train: e.train,
			route: s ? s[t] : null
		});
	}
	return {
		runs: l,
		total: l.reduce((e, t) => e + (t.route?.value ?? 0), 0)
	};
}
//#endregion
//#region src/games/svea/schema.ts
var J = t.enum([
	"S",
	"O",
	"N",
	"J",
	"G"
]), Y = t.enum([
	"central-station",
	"city-station-owner",
	"infrastructure-push",
	"political-influence",
	"ferry-contract",
	"financial-planning",
	"yellow-offboard",
	"blue-offboard",
	"new-railroad",
	"tax-haven",
	"raising-funds",
	"delayed-permit"
]), X = t.enum([
	"karlstad",
	"orebro",
	"vasteras",
	"goteborg",
	"lake",
	"norrkoping",
	"stockholm",
	"jonkoping",
	"linkoping",
	"bay",
	"paleA",
	"paleB"
]), Fe = t.enum(/* @__PURE__ */ "t7.t8.t9.y5a.y5b.y5c.t20.t23.t24.t25.t26.t27.t28.t29.g10a.g10b.g10c.g10d.t40.t44.t47.b15a.b15b.b10a.x20a.x20b.k30".split(".")), Z = t.enum([
	"T2",
	"T3",
	"T4",
	"T6",
	"T6P"
]), Ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("dscAssign"),
		card: Y,
		company: J
	}),
	t.object({
		type: t.literal("srSell"),
		sales: t.array(t.object({
			company: J,
			count: t.number().int().min(1)
		})).min(1)
	}),
	t.object({
		type: t.literal("srBuy"),
		company: J,
		from: t.enum(["ipo", "market"]),
		par: t.number().int().optional()
	}),
	t.object({ type: t.literal("srPass") }),
	t.object({
		type: t.literal("orSellTreasury"),
		count: t.number().int().min(0)
	}),
	t.object({
		type: t.literal("orBuyTrain"),
		train: Z
	}),
	t.object({ type: t.literal("orExchangeTrain") }),
	t.object({
		type: t.literal("orTradeTrain"),
		from: J,
		train: Z,
		price: t.number().int().min(1)
	}),
	t.object({
		type: t.literal("orTradeRespond"),
		accept: t.boolean()
	}),
	t.object({ type: t.literal("orDoneTrains") }),
	t.object({
		type: t.literal("orLayTile"),
		hex: X,
		tile: Fe,
		rot: t.number().int().min(0).max(5),
		sponsor: t.boolean()
	}),
	t.object({ type: t.literal("orSkipLay") }),
	t.object({
		type: t.literal("orPlaceStation"),
		hex: X,
		sponsor: t.boolean()
	}),
	t.object({ type: t.literal("orSkipStation") }),
	t.object({ type: t.literal("orRunTrains") }),
	t.object({
		type: t.literal("orDividend"),
		mode: t.enum([
			"payout",
			"withhold",
			"split"
		]),
		amount: t.number().int().min(0).optional()
	}),
	t.object({
		type: t.literal("cardAssign"),
		card: Y,
		company: J
	}),
	t.object({
		type: t.literal("cardCentral"),
		hex: X,
		face: t.enum(["white", "black"])
	}),
	t.object({
		type: t.literal("cardPoliBuy"),
		company: J
	}),
	t.object({ type: t.literal("cardPoliSkip") }),
	t.object({
		type: t.literal("scaBid"),
		amount: t.number().int().min(0)
	}),
	t.object({
		type: t.literal("scaSwap"),
		take: Y.nullable()
	})
]), Le = t.object({
	company: J,
	active: t.boolean(),
	central: t.boolean().optional(),
	reserved: t.boolean().optional()
}), Re = t.object({
	tile: Fe,
	rot: t.number().int(),
	stations: t.array(Le)
}), ze = t.object({
	kind: t.enum([
		"city",
		"offboard",
		"stub"
	]),
	id: t.string(),
	base: t.number(),
	bonus: t.number(),
	total: t.number()
}), Be = t.object({
	stops: t.array(ze),
	value: t.number(),
	segs: t.array(t.string()),
	path: t.array(t.string())
}), Ve = t.object({
	runs: t.array(t.object({
		train: Z,
		route: Be.nullable()
	})),
	total: t.number()
}), He = t.object({
	id: J,
	floated: t.boolean(),
	par: t.number().nullable(),
	treasury: t.number(),
	trains: t.array(Z),
	ipoLeft: t.number().int(),
	marketLeft: t.number().int(),
	price: t.number().nullable(),
	pos: t.object({
		row: t.number().int(),
		col: t.number().int()
	}).nullable(),
	homePlaced: t.boolean(),
	extraStationUsed: t.boolean()
}), Ue = t.object({
	round: t.enum([
		"dsc",
		"sr1",
		"or1",
		"or2",
		"sr2",
		"or3",
		"sca",
		"or4",
		"sr3",
		"or5",
		"or6",
		"sr4",
		"or7",
		"done"
	]),
	devPhase: t.enum([
		"yellow",
		"green",
		"brown",
		"grey",
		"black"
	]),
	t6Unlocked: t.boolean(),
	players: t.array(t.object({
		rid: t.string(),
		cash: t.number(),
		shares: t.record(t.string(), t.number()),
		cards: t.array(Y)
	})),
	ceo: t.record(t.string(), t.string().nullable()),
	companies: t.array(He),
	board: t.record(t.string(), Re),
	tilePool: t.record(t.string(), t.number()),
	trainPool: t.array(Z),
	central: t.object({
		holder: t.string().nullable(),
		mode: t.enum(["white", "black"]).nullable(),
		hex: X.nullable()
	}),
	cityOwner: t.object({
		hex: X,
		company: J.nullable()
	}).nullable(),
	nrc: t.object({
		spot: t.number().nullable(),
		bars: t.array(t.boolean()),
		company: J.nullable(),
		stopBonus: t.boolean()
	}),
	cards: t.object({
		used: t.array(Y),
		removed: t.array(Y),
		assigned: t.record(t.string(), J),
		from: t.record(t.string(), t.enum(["dsc", "sca"])),
		locked: J.nullable(),
		raising: t.object({
			company: J,
			amount: t.number()
		}).nullable()
	}),
	dsc: t.object({ queue: t.array(t.object({
		rid: t.string(),
		card: Y
	})) }).nullable(),
	sr: t.object({
		order: t.array(t.string()),
		cur: t.number().int(),
		passRun: t.number().int(),
		soldThisSr: t.record(t.string(), t.array(J)),
		soldThisTurn: t.boolean()
	}).nullable(),
	or: t.object({
		queue: t.array(J),
		cur: t.number().int(),
		step: t.enum([
			"treasury",
			"train",
			"lay",
			"station",
			"run",
			"pay"
		]),
		trade: t.object({
			from: J,
			train: Z,
			price: t.number(),
			by: J
		}).nullable(),
		forced: t.boolean(),
		extraLay: t.boolean(),
		ranCompanies: t.array(J),
		tiredTrains: t.array(Z),
		preBuy: t.array(t.string()),
		lastRun: Ve.nullable(),
		allowedTrains: t.array(Z)
	}).nullable(),
	sca: t.object({
		phase: t.enum(["bid", "settle"]),
		current: Y.nullable(),
		left: t.number().int(),
		bidsIn: t.array(t.string()),
		eligible: t.array(t.string()),
		rebidPool: t.array(t.string()).nullable(),
		wins: t.record(t.string(), t.array(Y)),
		removed: t.array(Y),
		settle: t.array(t.object({
			rid: t.string(),
			card: Y
		}))
	}).nullable(),
	end: t.object({
		triggered: t.boolean(),
		reason: t.enum([
			"price130",
			"bankrupt",
			"complete"
		]).nullable()
	}),
	result: t.object({
		scores: t.record(t.string(), t.number()),
		ranking: t.array(t.string())
	}).nullable()
}), We = t.object({ myBid: t.number().nullable() }), Q = (e) => ({ code: e }), Ge = (e) => k[e.roundIdx] ?? "done";
function Ke(e, t) {
	return e.players.find((e) => e.rid === t);
}
function qe(e, t, n) {
	return e.holdings[t]?.[n] ?? 0;
}
function Je(e, t) {
	return E.reduce((n, r) => n + qe(e, t, r), 0);
}
function $(e, t) {
	let n = e.companies[t].pos;
	return n ? ye(n) : null;
}
function Ye(t, n) {
	let r = e(t.seed, t.rngCursor, n);
	return t.rngCursor += 1, r;
}
function Xe(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = Ye(e, n + 1), i = t[n];
		t[n] = t[r], t[r] = i;
	}
}
function Ze(e, t) {
	for (let n of e.players) if (e.cards.hands[n.rid]?.includes(t)) return n.rid;
	return null;
}
function Qe(e, t) {
	let n = Ze(e, t), r = e.cards.assigned[t];
	return r ? e.ceo[r] ?? n : n;
}
var $e = (e, t) => e.cards.used.includes(t);
function et(e, t) {
	t === "city-station-owner" && !e.cityOwner && (e.cityOwner = {
		hex: ee[Ye(e, ee.length)],
		company: null
	}), t === "new-railroad" && e.nrc.spot === null && (e.nrc.spot = w(Ye(e, 6) + 1));
}
function tt(e, t, n) {
	e.companies[t].pos = n, e.companies[t].seq = ++e.moveSeq, be(n) && (e.end.triggered = !0, e.end.reason = "price130");
}
function nt(e) {
	return E.filter((t) => e.companies[t].floated && e.companies[t].pos).sort((t, n) => {
		let r = e.companies[t], i = e.companies[n], a = ye(i.pos) - ye(r.pos);
		return a === 0 ? i.pos.col === r.pos.col ? r.seq - i.seq : i.pos.col - r.pos.col : a;
	});
}
function rt(e, t) {
	if (e.deferCeo) return;
	let n = e.ceo[t];
	if (!n) return;
	let r = qe(e, n, t);
	for (let i of e.players) if (i.rid !== n && qe(e, i.rid, t) > r) {
		e.ceo[t] = i.rid;
		return;
	}
}
function it(e) {
	for (let t of E) rt(e, t);
}
function at(e) {
	let t = structuredClone(e.board);
	for (let n of E) {
		if (e.companies[n].homePlaced) continue;
		let r = t[T[n].home];
		r && !r.stations.some((e) => e.company === n) && r.stations.unshift({
			company: n,
			active: !1,
			reserved: !0
		});
	}
	return t;
}
function ot(e) {
	return {
		devPhase: e.devPhase,
		centralDouble: e.central.mode === "white" ? e.central.hex : null,
		cityOwner: e.cityOwner?.company && e.companies[e.cityOwner.company].floated ? {
			hex: e.cityOwner.hex,
			company: e.cityOwner.company
		} : null,
		nrcBars: e.nrc.bars,
		nrcCompany: e.nrc.stopBonus ? e.nrc.company : null,
		contracts: {
			yellow: e.cards.assigned["yellow-offboard"] ?? null,
			blue: e.cards.assigned["blue-offboard"] ?? null
		}
	};
}
function st(e, t) {
	return e.cards.assigned["political-influence"] === t && $e(e, "political-influence");
}
function ct(e, t) {
	let n = e.companies[t];
	if (!n.floated || n.homePlaced) return;
	let r = T[t].home, i = e.board[r];
	i && (n.homePlaced = !0, i.stations.unshift({
		company: t,
		active: !0
	}));
}
function lt(e, t, n, r) {
	let i = e.companies[n], a = Ke(e, t);
	i.floated = !0, i.par = r, i.ipoLeft = 4, i.seq = ++e.moveSeq, i.pos = ve[ae.indexOf(r)], e.holdings[t][n] = 1, e.ceo[n] = t, a.cash -= r, i.treasury += r, ct(e, n), e.cards.raising?.company === n && (i.treasury += e.cards.raising.amount, e.cards.raising = null);
}
function ut(e, t) {
	return t === "T2" ? !0 : t === "T3" ? !e.trainPool.includes("T2") : t === "T4" ? !e.trainPool.includes("T3") : e.t6Unlocked;
}
function dt(e) {
	let t = [...new Set(e.trainPool.filter((t) => ut(e, t)))];
	if (t.length === 0) return [];
	if (t.every((e) => e === "T6" || e === "T6P")) return t;
	let n = Math.min(...t.map((e) => O[e].price));
	return t.filter((e) => O[e].price === n);
}
function ft(e) {
	let t = dt(e);
	return t.length === 0 ? null : t.sort((e, t) => O[e].price - O[t].price)[0];
}
function pt(e, t) {
	if (D(e.devPhase, t)) return;
	let n = e.devPhase;
	e.devPhase = t;
	let r = (t) => {
		for (let n of E) e.companies[n].trains = e.companies[n].trains.filter((e) => e !== t);
		e.trainPool = e.trainPool.filter((e) => e !== t);
	};
	!D(n, "brown") && D(t, "brown") && r("T2"), !D(n, "grey") && D(t, "grey") && r("T3");
}
function mt(e, t, n) {
	let r = e.companies[t];
	for (; r.treasury < n && r.ipoLeft > 0;) r.treasury += $(e, t), --r.ipoLeft, r.marketLeft += 1, tt(e, t, we(r.pos, 1));
	if (r.treasury >= n) return !0;
	let i = e.ceo[t], a = Ke(e, i);
	for (e.deferCeo = !0; a.cash + r.treasury < n;) {
		let t = null;
		for (let n of E) {
			let r = qe(e, i, n), a = e.ceo[n] === i ? r - 1 : r, o = $(e, n);
			a > 0 && o !== null && (!t || o > t.price) && (t = {
				c: n,
				price: o
			});
		}
		if (!t) return !1;
		--e.holdings[i][t.c], e.companies[t.c].marketLeft += 1, a.cash += t.price, tt(e, t.c, we(e.companies[t.c].pos, 1));
	}
	let o = n - r.treasury;
	return a.cash -= o, r.treasury += o, !0;
}
function ht(e, t, n) {
	e.companies[t].trains.push(n), pt(e, O[n].phase), !e.t6Unlocked && !e.trainPool.includes("T4") && (e.t6Unlocked = !0), e.deferCeo && (e.deferCeo = !1, it(e));
}
function gt(e) {
	if (e.dsc = null, e.sr = null, e.or = null, e.sca = null, e.end.triggered) {
		_t(e, e.end.reason ?? "complete");
		return;
	}
	e.cards.raising && k.indexOf(Ge(e)) >= k.indexOf(e.cards.raising.until) && (e.cards.raising = null), e.roundIdx += 1;
	let t = Ge(e);
	if (t === "sr2" && (e.cards.locked = null), t === "done") {
		_t(e, "complete");
		return;
	}
	t === "sca" ? Dt(e) : t.startsWith("sr") ? vt(e) : xt(e);
}
function _t(e, t) {
	e.end.triggered = !0, e.end.reason = t, e.dsc = null, e.sr = null, e.or = null, e.sca = null, e.roundIdx = k.length;
	let n = {};
	for (let t of e.players) {
		let r = t.cash;
		for (let n of E) r += qe(e, t.rid, n) * ($(e, n) ?? 0);
		n[t.rid] = r;
	}
	e.result = {
		scores: n,
		ranking: [...e.players].sort((e, t) => n[t.rid] - n[e.rid]).map((e) => e.rid)
	};
}
function vt(e) {
	for (let t of e.players) {
		let n = e.cards.hands[t.rid]?.includes("tax-haven") ?? !1 ? N : M, r = 0;
		for (let i of E) r += n[Math.min(qe(e, t.rid, i), 5)];
		for (; t.cash < r;) {
			let n = null;
			for (let r of E) {
				let i = qe(e, t.rid, r), a = e.ceo[r] === t.rid ? i - 1 : i, o = $(e, r);
				a > 0 && o !== null && (!n || o > n.price) && (n = {
					c: r,
					price: o
				});
			}
			if (!n) break;
			--e.holdings[t.rid][n.c], e.companies[n.c].marketLeft += 1, t.cash += n.price, tt(e, n.c, we(e.companies[n.c].pos, 1));
		}
		t.cash -= r;
	}
	it(e);
	let t = (t) => {
		let n = 0, r = 0;
		for (let i of Object.keys(S)) {
			if (Qe(e, i) !== t) continue;
			let a = S[i], o = $e(e, i) ? a.prioUsed : a.prioUnused;
			n += o, r = Math.max(r, o);
		}
		return {
			sum: n,
			max: r
		};
	};
	e.sr = {
		order: e.players.map((e) => ({
			rid: e.rid,
			...t(e.rid)
		})).sort((e, t) => t.sum - e.sum || t.max - e.max).map((e) => e.rid),
		cur: 0,
		passRun: 0,
		soldThisSr: {},
		soldThisTurn: !1
	};
}
function yt(e) {
	let t = e.sr;
	t.soldThisTurn = !1, t.cur = (t.cur + 1) % t.order.length;
}
function bt(e) {
	for (let t of E) {
		let n = e.companies[t];
		n.floated && n.ipoLeft === 0 && n.marketLeft === 0 && tt(e, t, B(n.pos));
	}
	gt(e);
}
function xt(e) {
	for (let t of E) e.companies[t].ranThisOr = !1;
	let t = e.players.map((e) => e.rid).filter((t) => (e.cards.hands[t] ?? []).includes("political-influence") && !$e(e, "political-influence"));
	e.or = {
		queue: nt(e),
		cur: 0,
		step: "treasury",
		trade: null,
		forced: !1,
		extraLay: !1,
		tiredTrains: [],
		preBuy: t,
		lastRun: null
	}, t.length === 0 && Ct(e);
}
function St(e) {
	for (let t of Object.keys(S)) {
		if ($e(e, t)) continue;
		let n = S[t].income;
		if (n <= 0) continue;
		let r = Qe(e, t), i = r ? Ke(e, r) : void 0;
		i && (i.cash += n);
	}
}
function Ct(e) {
	if (St(e), e.or.queue.length === 0) {
		gt(e);
		return;
	}
	wt(e);
}
function wt(e) {
	let t = e.or;
	t.step = "treasury", t.trade = null, t.forced = !1, t.extraLay = !1, t.tiredTrains = [], t.lastRun = null;
}
function Tt(e) {
	let t = e.or;
	if (t.cur += 1, t.cur >= t.queue.length) {
		gt(e);
		return;
	}
	wt(e);
}
var Et = (e) => e.or.queue[e.or.cur];
function Dt(e) {
	if (e.central.mode === "black" && e.central.hex) {
		let t = e.board[e.central.hex];
		t && (t.stations = t.stations.filter((e) => !e.central));
	}
	e.central = {
		holder: null,
		mode: null,
		hex: null
	}, e.cityOwner && (e.cityOwner.company = null), e.nrc.company = null, e.nrc.stopBonus = !1;
	for (let t of e.players) e.cards.hands[t.rid] = [];
	e.cards.used = [], e.cards.assigned = {}, e.cards.raising = null, e.cards.locked = null;
	let t = Object.keys(S);
	Xe(e, t);
	let n = t.splice(6);
	e.cards.removed = n, e.sca = {
		phase: "bid",
		deck: t,
		cur: 0,
		bids: {},
		baseBids: {},
		eligible: e.players.map((e) => e.rid),
		rebidPool: null,
		wins: Object.fromEntries(e.players.map((e) => [e.rid, []])),
		removed: n,
		settle: []
	}, Ot(e);
}
function Ot(e) {
	let t = e.sca, n = ie(e.players.length);
	if (t.eligible = e.players.map((e) => e.rid).filter((e) => t.wins[e].length < n), t.bids = {}, t.baseBids = {}, t.rebidPool = null, t.eligible.length <= 1) {
		let n = t.eligible[0];
		if (n) for (let r = t.cur; r < t.deck.length; r++) {
			let i = t.deck[r];
			e.cards.hands[n].push(i), e.cards.from[i] = "sca", t.wins[n].push(i), et(e, i);
		}
		t.cur = t.deck.length, Mt(e);
	}
}
var kt = (e, t) => (e.baseBids[t] ?? 0) + (e.bids[t] ?? 0);
function At(e) {
	let t = e.sca, n = t.rebidPool ?? t.eligible, r = t.deck[t.cur], i = -1;
	for (let e of n) i = Math.max(i, kt(t, e));
	let a = n.filter((e) => kt(t, e) === i);
	if (a.length > 1) {
		if (t.rebidPool) e.cards.removed.push(r), t.removed.push(r), jt(e);
		else {
			for (let e of a) t.baseBids[e] = kt(t, e);
			t.bids = {}, t.rebidPool = a;
		}
		return;
	}
	let o = a[0], s = Ke(e, o);
	s.cash -= kt(t, o), e.cards.hands[o].push(r), e.cards.from[r] = "sca", t.wins[o].push(r), et(e, r), jt(e);
}
function jt(e) {
	let t = e.sca;
	if (t.cur += 1, t.cur >= t.deck.length) {
		Mt(e);
		return;
	}
	Ot(e);
}
function Mt(e) {
	let t = e.sca, n = Object.entries(t.wins).find(([, e]) => e.includes("delayed-permit"));
	if (n && e.cards.removed.length > 0) {
		t.phase = "settle", t.settle = [{
			rid: n[0],
			card: "delayed-permit"
		}];
		return;
	}
	gt(e);
}
function Nt(e, t, n) {
	let r = () => ({
		floated: !1,
		par: null,
		treasury: 0,
		trains: [],
		ipoLeft: 5,
		marketLeft: 0,
		pos: null,
		seq: 0,
		homePlaced: !1,
		extraStationUsed: !1,
		ranThisOr: !1
	}), i = {
		seed: n,
		rngCursor: 0,
		roundIdx: 0,
		devPhase: "yellow",
		moveSeq: 0,
		t6Unlocked: !1,
		deferCeo: !1,
		players: t.map((e) => ({
			rid: e,
			cash: A(t.length)
		})),
		holdings: Object.fromEntries(t.map((e) => [e, Object.fromEntries(E.map((e) => [e, 0]))])),
		ceo: Object.fromEntries(E.map((e) => [e, null])),
		companies: {
			S: r(),
			O: r(),
			N: r(),
			J: r(),
			G: r()
		},
		board: {},
		tilePool: Object.fromEntries(Object.values(U).map((e) => [e.id, e.count])),
		trainPool: Object.keys(O).flatMap((e) => Array.from({ length: O[e].count }, () => e)),
		central: {
			holder: null,
			mode: null,
			hex: null
		},
		cityOwner: null,
		nrc: {
			spot: null,
			bars: ce.map(() => !1),
			company: null,
			stopBonus: !1
		},
		cards: {
			hands: Object.fromEntries(t.map((e) => [e, []])),
			used: [],
			removed: [],
			assigned: {},
			from: {},
			locked: null,
			raising: null
		},
		dsc: null,
		sr: null,
		or: null,
		sca: null,
		end: {
			triggered: !1,
			reason: null
		},
		result: null
	}, a = Object.keys(S);
	Xe(i, a);
	let o = re(t.length);
	t.forEach((e, t) => {
		for (let n = 0; n < o; n++) {
			let r = a[t * o + n];
			i.cards.hands[e].push(r), i.cards.from[r] = "dsc", et(i, r);
		}
	});
	let s = t.find((e) => i.cards.hands[e].includes("delayed-permit"));
	return s ? i.dsc = { queue: [{
		rid: s,
		card: "delayed-permit"
	}] } : gt(i), { state: i };
}
function Pt(e, t, n) {
	let r = structuredClone(e), i = Ge(r);
	if (i === "done" || r.result) return Q("games.svea.errBadPhase");
	if (t.type === "dscAssign") {
		if (!r.dsc || r.dsc.queue.length === 0) return Q("games.svea.errBadPhase");
		let e = r.dsc.queue[0];
		return e.rid === n.by ? t.card === e.card ? (r.cards.locked = t.company, r.cards.used.push("delayed-permit"), r.dsc.queue.shift(), r.dsc.queue.length === 0 && gt(r), { state: r }) : Q("games.svea.errBadCard") : Q("games.svea.errNotYourTurn");
	}
	if (t.type === "srSell" || t.type === "srBuy" || t.type === "srPass") {
		let e = r.sr;
		if (!e || !i.startsWith("sr")) return Q("games.svea.errBadPhase");
		let a = e.order[e.cur];
		if (a !== n.by) return Q("games.svea.errNotYourTurn");
		let o = Ke(r, a);
		if (t.type === "srSell") {
			let n = /* @__PURE__ */ new Map();
			for (let e of t.sales) n.set(e.company, (n.get(e.company) ?? 0) + e.count);
			for (let [e, t] of n) {
				let n = r.companies[e], i = $(r, e);
				if (!n.floated || i === null) return Q("games.svea.errNotFloated");
				if (t > qe(r, a, e) - +(r.ceo[e] === a)) return Q("games.svea.errNotSellable");
			}
			for (let [t, i] of n) {
				let n = r.companies[t], s = $(r, t);
				o.cash += s * i, r.holdings[a][t] -= i, n.marketLeft += i, tt(r, t, we(n.pos, i)), e.soldThisSr[a] || (e.soldThisSr[a] = []), e.soldThisSr[a].includes(t) || e.soldThisSr[a].push(t);
			}
			return e.soldThisTurn = !0, e.passRun = 0, it(r), { state: r };
		}
		if (t.type === "srBuy") {
			let n = r.companies[t.company];
			if ((e.soldThisSr[a] ?? []).includes(t.company)) return Q("games.svea.errSoldThisSr");
			if (Je(r, a) + 1 > j(r.players.length)) return Q("games.svea.errCertLimit");
			if (n.floated) {
				let e = $(r, t.company);
				if (o.cash < e) return Q("games.svea.errNotEnoughCash");
				if (t.from === "ipo") {
					if (n.ipoLeft <= 0) return Q("games.svea.errNoShares");
					--n.ipoLeft, o.cash -= e, n.treasury += e;
				} else {
					if (n.marketLeft <= 0) return Q("games.svea.errNoShares");
					--n.marketLeft, o.cash -= e;
				}
				r.holdings[a][t.company] += 1, rt(r, t.company);
			} else {
				if (t.from !== "ipo" || n.ipoLeft !== 5) return Q("games.svea.errNoShares");
				if (i === "sr1" && r.cards.locked === t.company) return Q("games.svea.errLocked");
				if (t.par === void 0 || !ae.includes(t.par)) return Q("games.svea.errBadPar");
				if (o.cash < t.par) return Q("games.svea.errNotEnoughCash");
				lt(r, a, t.company, t.par);
			}
			return e.passRun = 0, yt(r), { state: r };
		}
		return e.passRun = e.soldThisTurn ? 0 : e.passRun + 1, e.passRun >= r.players.length ? (bt(r), { state: r }) : (yt(r), { state: r });
	}
	if (t.type === "scaBid" || t.type === "scaSwap") {
		let e = r.sca;
		if (!e || i !== "sca") return Q("games.svea.errBadPhase");
		if (t.type === "scaBid") {
			if (e.phase !== "bid" || e.cur >= e.deck.length) return Q("games.svea.errBadPhase");
			let i = e.rebidPool ?? e.eligible;
			if (!i.includes(n.by)) return Q("games.svea.errNotBidder");
			if (e.bids[n.by] !== void 0) return Q("games.svea.errBadPhase");
			let a = Ke(r, n.by);
			return (e.baseBids[n.by] ?? 0) + t.amount > a.cash ? Q("games.svea.errBidTooHigh") : (e.bids[n.by] = t.amount, i.every((t) => e.bids[t] !== void 0) && At(r), { state: r });
		}
		if (e.phase !== "settle" || e.settle.length === 0) return Q("games.svea.errBadPhase");
		if (e.settle[0].rid !== n.by) return Q("games.svea.errNotYourTurn");
		if (t.take !== null) {
			if (!r.cards.removed.includes(t.take)) return Q("games.svea.errBadSwap");
			r.cards.removed = r.cards.removed.filter((e) => e !== t.take), e.removed = e.removed.filter((e) => e !== t.take), r.cards.hands[n.by] = r.cards.hands[n.by].filter((e) => e !== "delayed-permit"), r.cards.hands[n.by].push(t.take), r.cards.from[t.take] = "sca", r.cards.removed.push("delayed-permit"), et(r, t.take);
		}
		return e.settle.shift(), e.settle.length === 0 && gt(r), { state: r };
	}
	let a = r.or;
	if (!a || !i.startsWith("or")) return Q("games.svea.errBadPhase");
	if (t.type === "cardPoliBuy" || t.type === "cardPoliSkip") {
		if (a.preBuy.length === 0 || a.preBuy[0] !== n.by) return Q("games.svea.errNotYourTurn");
		if (t.type === "cardPoliBuy") {
			let e = r.companies[t.company], i = $(r, t.company), a = Ke(r, n.by);
			if (!e.floated || i === null || e.marketLeft <= 0) return Q("games.svea.errNoShares");
			if (Je(r, n.by) + 1 > j(r.players.length)) return Q("games.svea.errCertLimit");
			if (a.cash < i) return Q("games.svea.errNotEnoughCash");
			a.cash -= i, --e.marketLeft, r.holdings[n.by][t.company] += 1, r.cards.used.push("political-influence"), rt(r, t.company);
		}
		return a.preBuy.shift(), a.preBuy.length === 0 && Ct(r), { state: r };
	}
	if (a.preBuy.length > 0 || a.cur >= a.queue.length) return Q("games.svea.errBadPhase");
	let o = Et(r), s = r.companies[o];
	if (r.ceo[o] !== n.by) return Q("games.svea.errNotCeo");
	if (t.type === "cardAssign") {
		if (a.trade) return Q("games.svea.errTradePending");
		let e = t.card;
		if (![
			"political-influence",
			"ferry-contract",
			"yellow-offboard",
			"blue-offboard",
			"raising-funds",
			"city-station-owner",
			"new-railroad"
		].includes(e)) return Q("games.svea.errBadCard");
		if (!(r.cards.hands[n.by] ?? []).includes(e) || $e(r, e)) return Q("games.svea.errCardNotUsable");
		if (e === "raising-funds") {
			let n = r.cards.from[e] === "dsc" ? 25 : 40, i = r.cards.from[e] === "dsc" ? "or3" : "or7", a = r.companies[t.company];
			a.floated ? a.treasury += n : r.cards.raising = {
				company: t.company,
				amount: n,
				until: i
			};
		} else if (e === "new-railroad") r.nrc.spot === null && (r.nrc.spot = w(Ye(r, 6) + 1)), r.nrc.bars[r.nrc.spot] || (r.nrc.bars[r.nrc.spot] = !0), r.nrc.company = t.company, r.nrc.stopBonus = r.cards.from[e] === "sca", r.cards.assigned[e] = t.company;
		else if (e === "city-station-owner") {
			if (!r.cityOwner) return Q("games.svea.errBadCard");
			r.cityOwner.company = t.company, r.cards.assigned[e] = t.company;
		} else r.cards.assigned[e] = t.company;
		return r.cards.used.push(e), { state: r };
	}
	if (t.type === "cardCentral") {
		if (a.step !== "station") return Q("games.svea.errBadPhase");
		if (!(r.cards.hands[n.by] ?? []).includes("central-station") || $e(r, "central-station")) return Q("games.svea.errCardNotUsable");
		let e = r.board[t.hex];
		if (!e || U[e.tile].slots === 0) return Q("games.svea.errBadHex");
		if (t.face === "white") r.central = {
			holder: n.by,
			mode: "white",
			hex: t.hex
		};
		else {
			if (e.stations.some((e) => e.company === o)) return Q("games.svea.errHasStation");
			if (It(r, t.hex) >= U[e.tile].slots) return Q("games.svea.errNoSlot");
			e.stations.push({
				company: o,
				active: !0,
				central: !0
			}), r.central = {
				holder: n.by,
				mode: "black",
				hex: t.hex
			};
		}
		return r.cards.used.push("central-station"), { state: r };
	}
	switch (t.type) {
		case "orSellTreasury": return a.step === "treasury" ? t.count > s.ipoLeft ? Q("games.svea.errNoShares") : (t.count > 0 && (s.treasury += $(r, o) * t.count, s.ipoLeft -= t.count, s.marketLeft += t.count, tt(r, o, we(s.pos, t.count))), a.step = "train", a.forced = s.trains.length === 0, { state: r }) : Q("games.svea.errBadPhase");
		case "orBuyTrain": {
			if (a.step !== "train" || a.trade) return Q("games.svea.errBadPhase");
			if (!r.trainPool.includes(t.train) || !dt(r).includes(t.train)) return Q("games.svea.errBadTrain");
			if (s.trains.length >= 3) return Q("games.svea.errTrainLimit");
			let e = O[t.train].price;
			if (s.treasury < e) {
				if (!a.forced) return Q("games.svea.errNotEnoughCash");
				if (!mt(r, o, e)) return _t(r, "bankrupt"), { state: r };
			}
			return s.treasury -= e, r.trainPool.splice(r.trainPool.indexOf(t.train), 1), ht(r, o, t.train), { state: r };
		}
		case "orExchangeTrain": return a.step !== "train" || a.trade ? Q("games.svea.errBadPhase") : !s.trains.includes("T4") || !r.t6Unlocked || !r.trainPool.includes("T6P") ? Q("games.svea.errBadTrain") : s.treasury < 110 ? Q("games.svea.errNotEnoughCash") : (s.treasury -= 110, s.trains.splice(s.trains.indexOf("T4"), 1), r.trainPool.push("T4"), r.trainPool.splice(r.trainPool.indexOf("T6P"), 1), ht(r, o, "T6P"), { state: r });
		case "orTradeTrain": {
			if (a.step !== "train" || a.trade) return Q("games.svea.errBadPhase");
			let e = r.companies[t.from];
			return t.from === o || !e.floated ? Q("games.svea.errNoSuchCompany") : e.trains.includes(t.train) ? t.price < 1 || s.treasury < t.price ? Q("games.svea.errNotEnoughCash") : s.trains.length >= 3 ? Q("games.svea.errTrainLimit") : (a.trade = {
				from: t.from,
				train: t.train,
				price: t.price,
				by: o
			}, { state: r }) : Q("games.svea.errBadTrain");
		}
		case "orDoneTrains": return a.step !== "train" || a.trade ? Q("games.svea.errBadPhase") : s.trains.length === 0 && ft(r) !== null ? Q("games.svea.errMustBuyTrain") : (a.step = "lay", { state: r });
		case "orLayTile": return a.step === "lay" ? a.extraLay && ($e(r, "infrastructure-push") || !(r.cards.hands[n.by] ?? []).includes("infrastructure-push")) ? Q("games.svea.errCardNotUsable") : Lt(r, o, n.by, t.hex, t.tile, t.rot, t.sponsor) || (a.extraLay ? (r.cards.used.push("infrastructure-push"), a.extraLay = !1, a.step = "station") : (r.cards.hands[n.by] ?? []).includes("infrastructure-push") && !$e(r, "infrastructure-push") ? a.extraLay = !0 : a.step = "station", { state: r }) : Q("games.svea.errBadPhase");
		case "orSkipLay": return a.step === "lay" ? (a.extraLay = !1, a.step = "station", { state: r }) : Q("games.svea.errBadPhase");
		case "orPlaceStation": return a.step === "station" ? s.extraStationUsed ? Q("games.svea.errNoExtraStation") : Rt(r, o, n.by, t.hex, t.sponsor) || (s.extraStationUsed = !0, a.step = "run", { state: r }) : Q("games.svea.errBadPhase");
		case "orSkipStation": return a.step === "station" ? (a.step = "run", { state: r }) : Q("games.svea.errBadPhase");
		case "orRunTrains": {
			if (a.step !== "run") return Q("games.svea.errBadPhase");
			let e = [...a.tiredTrains], t = [], n = [];
			for (let r of s.trains) {
				let i = e.indexOf(r);
				i >= 0 ? (e.splice(i, 1), n.push(!0)) : (n.push(!1), t.push(r));
			}
			let i = ot(r), c = q(at(r), o, t, i), l = [], u = 0;
			s.trains.forEach((e, t) => {
				l.push(n[t] ? {
					train: e,
					route: null
				} : c.runs[u++] ?? {
					train: e,
					route: null
				});
			}), a.lastRun = {
				runs: l,
				total: c.total
			};
			let d = i.cityOwner;
			if (d && d.company !== o) {
				let e = l.filter((e) => e.route?.stops.some((e) => e.kind === "city" && e.id === d.hex)).length;
				e > 0 && (r.companies[d.company].treasury += 5 * e);
			}
			return s.ranThisOr = !0, a.step = "pay", { state: r };
		}
		case "orDividend": {
			if (a.step !== "pay" || !a.lastRun) return Q("games.svea.errBadPhase");
			let e = a.lastRun.total, i = $(r, o), c = 0;
			if (t.mode === "split") {
				if (!(r.cards.hands[n.by] ?? []).includes("financial-planning") || $e(r, "financial-planning")) return Q("games.svea.errCardNotUsable");
				let i = t.amount;
				if (i === void 0 || i < 0 || i > e || i % 5 != 0) return Q("games.svea.errBadDividend");
				c = i, r.cards.used.push("financial-planning");
			} else t.mode === "payout" && (c = e);
			if (c > 0) {
				let t = c / 5;
				for (let e of r.players) e.cash += t * qe(r, e.rid, o);
				s.treasury += t * s.ipoLeft, s.treasury += e - c, tt(r, o, H(s.pos, c >= 2 * i ? 2 : 1));
			} else s.treasury += e, tt(r, o, Ce(s.pos));
			return Tt(r), { state: r };
		}
	}
	return Q("games.svea.errBadPhase");
}
function Ft(e, t, n) {
	let r = e.or, i = r.trade;
	if (e.ceo[i.from] !== n) return Q("games.svea.errNotCeo");
	if (t) {
		let t = e.companies[i.by], n = e.companies[i.from];
		t.treasury -= i.price, n.treasury += i.price, n.trains.splice(n.trains.indexOf(i.train), 1), t.trains.push(i.train), n.ranThisOr && r.tiredTrains.push(i.train), e.deferCeo && (e.deferCeo = !1, it(e));
	}
	return r.trade = null, { state: e };
}
function It(e, t) {
	let n = e.board[t];
	if (!n) return 0;
	let r = n.stations.filter((e) => !e.central).length;
	for (let i of E) T[i].home === t && !e.companies[i].homePlaced && !n.stations.some((e) => e.company === i) && (r += 1);
	return r;
}
function Lt(e, t, n, r, i, a, o) {
	let s = U[i], c = P[r], l = e.board[r], u = e.companies[t], d = Ke(e, n);
	if (e.tilePool[i] <= 0) return Q("games.svea.errTileUnavailable");
	if (!D(e.devPhase, s.color)) return Q("games.svea.errBadPhase");
	if (c.kind === "city" && s.slots === 0 || c.kind !== "city" && s.slots > 0) return Q("games.svea.errBadHex");
	if (!l) {
		if (s.color !== "yellow" && s.color !== "black" || s.color === "black" && c.kind !== "city") return Q("games.svea.errBadTile");
	} else if (s.color === "black") {
		if (U[l.tile].slots === 0) return Q("games.svea.errBadTile");
	} else if (Ee[s.color] !== U[l.tile].color) return Q("games.svea.errBadTile");
	let f = s.edges.map((e) => W(e, a));
	for (let e of f) if (z[r][e].kind === "blocked") return Q("games.svea.errBadRot");
	if (l) {
		let t = U[l.tile];
		for (let n of t.edges) {
			let t = W(n, l.rot), i = z[r][t], a = i.kind === "offboard" || i.kind === "stub";
			if (i.kind === "hex" || i.kind === "water") {
				let n = e.board[i.hex];
				if (n) {
					let e = (t + 3) % 6;
					a = U[n.tile].edges.some((t) => W(t, n.rot) === e);
				}
			}
			if (a && !f.includes(t)) return Q("games.svea.errBadRot");
		}
	}
	if (!(G(at(e), t, ot(e)).has(r) || !u.homePlaced && r === T[t].home)) return Q("games.svea.errNotReachable");
	let p = st(e, t), m = s.slots > 0 ? s.color === "black" ? 10 : 5 : 0, h = 0;
	for (let t of f) {
		let n = z[r][t];
		if (n.kind !== "water") continue;
		let i = e.board[n.hex];
		if (!i) continue;
		let a = (t + 3) % 6;
		U[i.tile].edges.some((e) => W(e, i.rot) === a) && (h += 1);
	}
	if (l) for (let t of U[l.tile].edges) {
		let n = W(t, l.rot), i = z[r][n];
		if (i.kind === "water" && f.includes(n)) {
			let t = e.board[i.hex];
			t && U[t.tile].edges.some((e) => W(e, t.rot) === (n + 3) % 6) && --h;
		}
	}
	let g = p ? 0 : m + 5 * h;
	if (o) {
		if (u.treasury >= g) return Q("games.svea.errNotEnoughCash");
		let e = p ? 0 : 2 * m + 5 * h;
		if (d.cash < e) return Q("games.svea.errNotEnoughCash");
		d.cash -= e;
	} else {
		if (u.treasury < g) return Q("games.svea.errNotEnoughCash");
		u.treasury -= g;
	}
	l && (e.tilePool[l.tile] += 1), --e.tilePool[i], e.board[r] = {
		tile: i,
		rot: a,
		stations: l ? l.stations : []
	}, h > 0 && e.cards.assigned["ferry-contract"] === t && $e(e, "ferry-contract") && (u.treasury += 15 * h);
	for (let t of E) ct(e, t);
	return null;
}
function Rt(e, t, n, r, i) {
	let a = e.board[r], o = e.companies[t], s = Ke(e, n);
	if (!a || U[a.tile].slots === 0) return Q("games.svea.errBadHex");
	if (a.stations.some((e) => e.company === t)) return Q("games.svea.errHasStation");
	if (It(e, r) >= U[a.tile].slots) return Q("games.svea.errNoSlot");
	if (!G(at(e), t, ot(e)).has(r)) return Q("games.svea.errNotReachable");
	let c = st(e, t) ? 5 : 10;
	if (i) {
		if (o.treasury >= c) return Q("games.svea.errNotEnoughCash");
		let e = 2 * c;
		if (s.cash < e) return Q("games.svea.errNotEnoughCash");
		s.cash -= e;
	} else {
		if (o.treasury < c) return Q("games.svea.errNotEnoughCash");
		o.treasury -= c;
	}
	return a.stations.push({
		company: t,
		active: !0
	}), null;
}
function zt(e, t, n) {
	if (t.type === "orTradeRespond") {
		let r = structuredClone(e);
		return !r.or?.trade || !Ge(r).startsWith("or") ? Q("games.svea.errBadPhase") : Ft(r, t.accept, n.by);
	}
	return Pt(e, t, n);
}
function Bt(e, t) {
	let n = at(e);
	return {
		public: {
			round: Ge(e),
			devPhase: e.devPhase,
			t6Unlocked: e.t6Unlocked,
			players: e.players.map((t) => ({
				rid: t.rid,
				cash: t.cash,
				shares: Object.fromEntries(E.map((n) => [n, qe(e, t.rid, n)])),
				cards: e.cards.hands[t.rid] ?? []
			})),
			ceo: { ...e.ceo },
			companies: E.map((t) => {
				let n = e.companies[t];
				return {
					id: t,
					floated: n.floated,
					par: n.par,
					treasury: n.treasury,
					trains: [...n.trains],
					ipoLeft: n.ipoLeft,
					marketLeft: n.marketLeft,
					price: $(e, t),
					pos: n.pos ? { ...n.pos } : null,
					homePlaced: n.homePlaced,
					extraStationUsed: n.extraStationUsed
				};
			}),
			board: structuredClone(n),
			tilePool: { ...e.tilePool },
			trainPool: [...e.trainPool],
			central: { ...e.central },
			cityOwner: e.cityOwner ? { ...e.cityOwner } : null,
			nrc: {
				...e.nrc,
				bars: [...e.nrc.bars]
			},
			cards: {
				used: [...e.cards.used],
				removed: [...e.cards.removed],
				assigned: { ...e.cards.assigned },
				from: { ...e.cards.from },
				locked: e.cards.locked,
				raising: e.cards.raising ? {
					company: e.cards.raising.company,
					amount: e.cards.raising.amount
				} : null
			},
			dsc: e.dsc ? { queue: e.dsc.queue.map((e) => ({ ...e })) } : null,
			sr: e.sr ? {
				order: [...e.sr.order],
				cur: e.sr.cur,
				passRun: e.sr.passRun,
				soldThisSr: structuredClone(e.sr.soldThisSr),
				soldThisTurn: e.sr.soldThisTurn
			} : null,
			or: e.or ? {
				queue: [...e.or.queue],
				cur: e.or.cur,
				step: e.or.step,
				trade: e.or.trade ? { ...e.or.trade } : null,
				forced: e.or.forced,
				extraLay: e.or.extraLay,
				ranCompanies: E.filter((t) => e.companies[t].ranThisOr),
				tiredTrains: [...e.or.tiredTrains],
				preBuy: [...e.or.preBuy],
				lastRun: e.or.lastRun ? structuredClone(e.or.lastRun) : null,
				allowedTrains: dt(e)
			} : null,
			sca: e.sca ? {
				phase: e.sca.phase,
				current: e.sca.phase === "bid" && e.sca.cur < e.sca.deck.length ? e.sca.deck[e.sca.cur] : null,
				left: Math.max(0, e.sca.deck.length - e.sca.cur),
				bidsIn: Object.keys(e.sca.bids),
				eligible: [...e.sca.eligible],
				rebidPool: e.sca.rebidPool ? [...e.sca.rebidPool] : null,
				wins: structuredClone(e.sca.wins),
				removed: [...e.sca.removed],
				settle: e.sca.settle.map((e) => ({ ...e }))
			} : null,
			end: { ...e.end },
			result: e.result ? {
				scores: { ...e.result.scores },
				ranking: [...e.result.ranking]
			} : null
		},
		private: { myBid: e.sca && (e.sca.bids[t] !== void 0 || e.sca.baseBids[t] !== void 0) ? kt(e.sca, t) : null }
	};
}
function Vt(e) {
	let t = Ge(e);
	if (!e.result) return { phase: t };
	let n = e.result.scores[e.result.ranking[0]];
	return {
		phase: "done",
		winner: e.result.ranking.filter((t) => e.result.scores[t] === n),
		ranking: e.result.ranking,
		scores: e.result.scores
	};
}
var Ht = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: he,
	schemas: {
		action: Ie,
		publicView: Ue,
		privateView: We
	},
	setup: Nt,
	reduce: zt,
	viewFor: Bt,
	status: Vt
}, Ut = 100, Wt = Ut * Math.sqrt(3) / 2, Gt = Object.fromEntries(Object.values(T).map((e) => [e.home, e.id])), Kt = {
	karlstad: "games.svea.hexKarlstad",
	orebro: "games.svea.hexOrebro",
	vasteras: "games.svea.hexVasteras",
	goteborg: "games.svea.hexGoteborg",
	lake: "games.svea.hexLake",
	norrkoping: "games.svea.hexNorrkoping",
	stockholm: "games.svea.hexStockholm",
	jonkoping: "games.svea.hexJonkoping",
	linkoping: "games.svea.hexLinkoping",
	bay: "games.svea.hexBay",
	paleA: "games.svea.hexPaleA",
	paleB: "games.svea.hexPaleB"
}, qt = (e) => te[Math.min(2, Math.floor(ne.indexOf(e) / 2))], Jt = (e, t) => ({
	x: Ut * Math.sqrt(3) * (e + t / 2),
	y: Ut * 1.5 * t
}), Yt = (e) => {
	let t = e * Math.PI / 3;
	return {
		x: Wt * Math.cos(t),
		y: Wt * Math.sin(t)
	};
};
function Xt() {
	return `M${[
		0,
		1,
		2,
		3,
		4,
		5
	].map((e) => {
		let t = Math.PI / 3 * e - Math.PI / 6;
		return `${(Ut * Math.cos(t)).toFixed(1)},${(Ut * Math.sin(t)).toFixed(1)}`;
	}).join("L")}Z`;
}
var Zt = Xt(), Qt = {
	yellow: "var(--color-svea-yellow-tile)",
	green: "var(--color-svea-green-tile)",
	brown: "var(--color-svea-brown-tile)",
	grey: "var(--color-svea-grey-tile)",
	black: "var(--color-svea-black-tile)"
}, $t = {
	city: "var(--color-svea-paper)",
	water: "var(--color-svea-sea)",
	plain: "#dce2bd"
};
function en(e, t) {
	let n = Yt(e);
	if (t === null) return `M${n.x.toFixed(1)},${n.y.toFixed(1)} L0,0`;
	let r = Yt(t);
	return ((t - e) % 6 + 6) % 6 == 3 ? `M${n.x.toFixed(1)},${n.y.toFixed(1)} L${r.x.toFixed(1)},${r.y.toFixed(1)}` : `M${n.x.toFixed(1)},${n.y.toFixed(1)} Q0,0 ${r.x.toFixed(1)},${r.y.toFixed(1)}`;
}
function tn({ tile: e, placed: t, textColor: n }) {
	let r = U[e], i = t?.rot ?? 0, a = (e) => W(e, i), o = r.segs ? r.segs.map((e) => en(a(e[0]), a(e[1]))) : r.slots === 0 && r.edges.length === 2 ? [en(a(r.edges[0]), a(r.edges[1]))] : r.edges.map((e) => en(a(e), null));
	return /* @__PURE__ */ h("g", { children: [
		/* @__PURE__ */ m("g", {
			stroke: "var(--color-svea-rail)",
			strokeWidth: 13,
			fill: "none",
			strokeLinecap: "square",
			children: o.map((e, t) => /* @__PURE__ */ m("path", { d: e }, t))
		}),
		/* @__PURE__ */ m("g", {
			stroke: "var(--color-svea-rail)",
			strokeWidth: 17,
			strokeDasharray: "3 10",
			fill: "none",
			children: o.map((e, t) => /* @__PURE__ */ m("path", { d: e }, t))
		}),
		/* @__PURE__ */ m("g", {
			stroke: "#f8efd3",
			strokeWidth: 4,
			fill: "none",
			strokeLinecap: "square",
			children: o.map((e, t) => /* @__PURE__ */ m("path", { d: e }, t))
		}),
		r.slots > 0 && /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
			r: 31,
			fill: "#fff3d4",
			stroke: "var(--color-svea-rail)",
			strokeWidth: 4.5
		}), /* @__PURE__ */ m("text", {
			y: 9,
			textAnchor: "middle",
			fontSize: r.slots === 1 ? 28 : 25,
			fontWeight: 800,
			fill: n,
			fontFamily: "Georgia, serif",
			children: r.values ? r.values.join("/") : r.value
		})] }),
		t?.stations.map((e, n) => {
			let i = (n - (Math.max(r.slots, t.stations.length) - 1) / 2) * 28, a = T[e.company].color;
			return /* @__PURE__ */ h("g", {
				transform: `translate(${i},36)`,
				children: [/* @__PURE__ */ m("circle", {
					r: 11,
					fill: e.reserved ? "#fdf6e3" : a,
					stroke: a,
					strokeWidth: 3.5,
					strokeDasharray: e.reserved ? "4 3" : void 0,
					opacity: e.active ? 1 : .75
				}), /* @__PURE__ */ m("text", {
					y: 4,
					textAnchor: "middle",
					fontSize: 12,
					fontWeight: 900,
					fill: e.reserved ? a : "#fff",
					children: e.central ? "★" : e.company
				})]
			}, n);
		})
	] });
}
function nn({ tile: e, rot: t }) {
	let n = U[e].color === "black";
	return /* @__PURE__ */ h("svg", {
		viewBox: "-104 -104 208 208",
		"aria-hidden": "true",
		focusable: "false",
		children: [
			/* @__PURE__ */ m("rect", {
				x: -98,
				y: -98,
				width: 196,
				height: 196,
				rx: 6,
				fill: Qt[U[e].color],
				stroke: "var(--color-svea-rail)",
				strokeWidth: 6
			}),
			/* @__PURE__ */ m("rect", {
				x: -88,
				y: -88,
				width: 176,
				height: 176,
				rx: 3,
				fill: "none",
				stroke: n ? "#a9bfbb" : "#fff3d4",
				strokeWidth: 3
			}),
			/* @__PURE__ */ m(tn, {
				tile: e,
				placed: {
					tile: e,
					rot: t,
					stations: []
				},
				textColor: n ? "#fafaf9" : "var(--color-svea-rail)"
			})
		]
	});
}
function rn(e) {
	if (e.startsWith("off:")) {
		let t = R[e.slice(4)];
		if (!t) return null;
		let n = Jt(P[t.hex].q, P[t.hex].r), r = Yt(t.edge);
		return {
			x: n.x + r.x * 1.75,
			y: n.y + r.y * 1.75
		};
	}
	if (e.startsWith("stub:")) {
		let t = ce[Number(e.slice(5))]?.[0];
		if (!t) return null;
		let n = Jt(P[t[0]].q, P[t[0]].r), r = Yt(t[1]);
		return {
			x: n.x + r.x * 1.5,
			y: n.y + r.y * 1.5
		};
	}
	let t = e.split(":")[0];
	return P[t] ? Jt(P[t].q, P[t].r) : null;
}
function an({ board: e, devPhase: t, nrcBars: n, centralHex: i, cityOwnerHex: a, selectable: o, picked: s, focusHex: l, onPick: f, ghost: g, runResult: _, legalTicket: v }) {
	let y = r(), b = u(null), [x, S] = d({
		width: 390,
		height: 420
	}), [C, ee] = d(1.32), [w, te] = d({
		x: 0,
		y: 0
	}), E = u(null), ne = u(!1);
	c(() => {
		if (!b.current || typeof ResizeObserver > "u") return;
		let e = new ResizeObserver(([e]) => S({
			width: e.contentRect.width,
			height: e.contentRect.height
		}));
		return e.observe(b.current), () => e.disconnect();
	}, []);
	let D = x.width / Math.max(1, x.height), O = Math.min(920, 800 * D), k = Math.max(920, 800 * D), A = C <= 1 ? k : O / C, j = A / D, re = s ?? o?.[0] ?? l, ie = re ? Jt(P[re].q, P[re].r) : null, ae = j * (D > 1.4 ? .04 : .25), M = C <= 1 ? {
		x: 190,
		y: 100
	} : ie ? {
		x: 145 + (ie.x - 173) * .7,
		y: ie.y + ae
	} : {
		x: 160,
		y: ae
	}, N = (e, t, n) => t > n ? (t + n) / 2 : Math.max(t, Math.min(n, e)), I = {
		x: N(M.x + w.x, -270 + A / 2, 650 - A / 2) - A / 2,
		y: N(M.y + w.y, -300 + j / 2, 500 - j / 2) - j / 2,
		width: A,
		height: j
	}, oe = (e) => ({
		x: N(M.x + e.x, -270 + A / 2, 650 - A / 2) - M.x,
		y: N(M.y + e.y, -300 + j / 2, 500 - j / 2) - M.y
	}), L = (e) => {
		ee((t) => Math.max(1, Math.min(2.5, Math.round((t + e) * 10) / 10))), te({
			x: 0,
			y: 0
		});
	}, le = (e) => {
		!E.current && e.isPrimary && (ne.current = !1, E.current = {
			pointerId: e.pointerId,
			startX: e.clientX,
			startY: e.clientY,
			x: e.clientX,
			y: e.clientY,
			active: !1
		});
	}, ue = (e) => {
		let t = E.current;
		if (!t || t.pointerId !== e.pointerId || !t.active && Math.hypot(e.clientX - t.startX, e.clientY - t.startY) < 6) return;
		t.active || (t.active = !0, ne.current = !0, e.currentTarget.setPointerCapture(e.pointerId));
		let n = e.clientX - t.x, r = e.clientY - t.y, i = e.currentTarget.getBoundingClientRect();
		te((e) => oe({
			x: e.x - n * A / i.width,
			y: e.y - r * j / i.height
		})), t.x = e.clientX, t.y = e.clientY;
	}, de = (e) => {
		E.current?.pointerId === e.pointerId && (e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId), E.current = null);
	}, fe = [];
	for (let e of F) {
		let t = Jt(P[e].q, P[e].r);
		z[e].forEach((n, r) => {
			if (n.kind === "water" && e < n.hex) {
				let e = Yt(r);
				fe.push({
					x: t.x + e.x,
					y: t.y + e.y
				});
			}
		});
	}
	return /* @__PURE__ */ h("div", {
		ref: b,
		className: "svea-board-viewport",
		children: [
			/* @__PURE__ */ h("svg", {
				viewBox: `${I.x} ${I.y} ${I.width} ${I.height}`,
				className: "h-full w-full",
				role: "group",
				onPointerDown: le,
				onPointerMove: ue,
				onPointerUp: de,
				onPointerCancel: de,
				style: { touchAction: "none" },
				children: [
					/* @__PURE__ */ h("defs", { children: [/* @__PURE__ */ h("pattern", {
						id: "svea-land",
						width: "48",
						height: "42",
						patternUnits: "userSpaceOnUse",
						children: [
							/* @__PURE__ */ m("rect", {
								width: "48",
								height: "42",
								fill: "var(--color-svea-land)"
							}),
							/* @__PURE__ */ m("path", {
								d: "M-5 30Q14 8 52 17M2 43Q20 25 49 32",
								fill: "none",
								stroke: "#e5e5bf",
								strokeWidth: "2",
								opacity: ".45"
							}),
							/* @__PURE__ */ m("path", {
								d: "M11 28l4-13 4 13m-4-14v17M35 20l3-11 3 11m-3-11v15",
								fill: "none",
								stroke: "#49705b",
								strokeWidth: "1.5",
								opacity: ".38"
							})
						]
					}), /* @__PURE__ */ h("pattern", {
						id: "svea-water",
						width: "52",
						height: "42",
						patternUnits: "userSpaceOnUse",
						children: [/* @__PURE__ */ m("rect", {
							width: "52",
							height: "42",
							fill: "var(--color-svea-sea)"
						}), /* @__PURE__ */ m("path", {
							d: "M-8 12q13-9 26 0t26 0M-8 31q13-9 26 0t26 0",
							fill: "none",
							stroke: "#c7e3df",
							strokeWidth: "2",
							opacity: ".4"
						})]
					})] }),
					/* @__PURE__ */ m("rect", {
						x: -270,
						y: -300,
						width: 920,
						height: 800,
						fill: "url(#svea-land)"
					}),
					/* @__PURE__ */ m("path", {
						d: "M-270 85Q-160 70 -127 190T35 318Q154 336 215 410T650 420V500H-270Z",
						fill: "url(#svea-water)"
					}),
					/* @__PURE__ */ m("path", {
						d: "M-270 85Q-160 70 -127 190T35 318Q154 336 215 410T650 420",
						fill: "none",
						stroke: "#e2e3bd",
						strokeWidth: 8,
						opacity: .7
					}),
					Object.values(R).map((e) => {
						let n = Jt(P[e.hex].q, P[e.hex].r), r = Yt(e.edge), i = n.x + r.x * 1.75, a = n.y + r.y * 1.75, o = se(e.id, t);
						return /* @__PURE__ */ h("g", {
							transform: `translate(${i},${a})`,
							children: [
								/* @__PURE__ */ m("path", {
									d: "M-52-30H52V30H-52Z",
									fill: "var(--color-svea-paper)",
									stroke: "var(--color-svea-rail)",
									strokeWidth: 4
								}),
								/* @__PURE__ */ m("path", {
									d: "M-43-21H43V21H-43Z",
									fill: "none",
									stroke: "var(--color-svea-gold)",
									strokeWidth: 2
								}),
								/* @__PURE__ */ m("text", {
									y: 4,
									textAnchor: "middle",
									fontSize: 28,
									fontWeight: 900,
									fill: "var(--color-svea-rail)",
									fontFamily: "inherit",
									children: o
								}),
								/* @__PURE__ */ m("text", {
									y: 23,
									textAnchor: "middle",
									fontSize: 12,
									fontWeight: 700,
									fill: "var(--color-svea-rail)",
									fontFamily: "inherit",
									children: e.segments.map(([, e]) => e).join("/")
								})
							]
						}, e.id);
					}),
					ce.map((e, r) => e.map(([e, i]) => {
						let a = Jt(P[e].q, P[e].r), o = Yt(i), s = a.x + o.x * 1.5, c = a.y + o.y * 1.5, l = n[r];
						return /* @__PURE__ */ h("g", {
							transform: `translate(${s},${c})`,
							children: [/* @__PURE__ */ m("rect", {
								x: -34,
								y: -20,
								width: 68,
								height: 40,
								rx: 3,
								fill: l ? "var(--color-svea-gold)" : "var(--color-svea-paper)",
								stroke: "var(--color-svea-rail)",
								strokeWidth: 3.5,
								strokeDasharray: l ? void 0 : "5 4"
							}), /* @__PURE__ */ m("text", {
								y: 6,
								textAnchor: "middle",
								fontSize: 20,
								fontWeight: 900,
								fill: "var(--color-svea-rail)",
								fontFamily: "inherit",
								children: l ? qt(t) : "?"
							})]
						}, `${e}:${i}`);
					})),
					F.map((t) => {
						let n = P[t], r = Jt(n.q, n.r), c = e[t], l = g?.hex === t, u = l ? g.tile : c?.tile ?? null, d = u ? {
							tile: u,
							rot: l ? g.rot : c?.rot ?? 0,
							stations: c?.stations ?? []
						} : null, _ = o?.includes(t) ?? !1, v = Gt[t], b = y(Kt[t]);
						return /* @__PURE__ */ h("g", {
							transform: `translate(${r.x},${r.y})`,
							onClick: _ ? () => {
								ne.current || f?.(t);
							} : void 0,
							onKeyDown: _ ? (e) => {
								(e.key === "Enter" || e.key === " ") && (e.preventDefault(), f?.(t));
							} : void 0,
							tabIndex: _ ? 0 : void 0,
							role: _ ? "button" : void 0,
							"aria-label": _ ? y(Kt[t]) : void 0,
							className: _ ? "cursor-pointer" : void 0,
							children: [
								l && /* @__PURE__ */ m("path", {
									d: Zt,
									transform: "translate(0 7)",
									fill: "var(--color-svea-rail)",
									opacity: .28
								}),
								/* @__PURE__ */ m("path", {
									d: Zt,
									fill: u ? Qt[U[u].color] : $t[n.kind],
									fillOpacity: l ? .7 : 1,
									stroke: s === t ? "var(--color-svea-gold)" : _ ? "#236a67" : "var(--color-svea-rail)",
									strokeWidth: s === t ? 8 : _ ? 6 : 4,
									strokeDasharray: _ && s !== t ? "9 7" : void 0
								}),
								u && /* @__PURE__ */ m("path", {
									d: Zt,
									transform: "scale(.9)",
									fill: "none",
									stroke: U[u].color === "black" ? "#a9bfbb" : "#f5edce",
									strokeWidth: 2
								}),
								u && /* @__PURE__ */ m("g", {
									opacity: l ? .72 : 1,
									children: /* @__PURE__ */ m(tn, {
										tile: u,
										placed: d,
										textColor: U[u].color === "black" ? "#fafaf9" : "var(--color-svea-rail)"
									})
								}),
								!u && n.kind === "city" && /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("circle", {
									r: 26,
									fill: "var(--color-svea-paper)",
									stroke: "var(--color-svea-rail)",
									strokeWidth: 3,
									strokeDasharray: "6 5"
								}), v && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("circle", {
									r: 15,
									fill: T[v].color,
									stroke: "var(--color-svea-rail)",
									strokeWidth: 3
								}), /* @__PURE__ */ m("text", {
									y: 5,
									textAnchor: "middle",
									fontSize: 14,
									fontWeight: 900,
									fill: "#fff",
									children: v
								})] })] }),
								_ && s !== t && /* @__PURE__ */ h("g", {
									transform: "translate(-45,-52)",
									children: [/* @__PURE__ */ m("circle", {
										r: 14,
										fill: "#236a67",
										stroke: "var(--color-svea-paper)",
										strokeWidth: 2
									}), /* @__PURE__ */ m("path", {
										d: "M-6 0l4 4 8-9",
										fill: "none",
										stroke: "#fff",
										strokeWidth: 3,
										strokeLinecap: "round"
									})]
								}),
								/* @__PURE__ */ m("rect", {
									x: -70,
									y: 40,
									width: 140,
									height: 30,
									rx: 3,
									fill: "var(--color-svea-paper)",
									stroke: "var(--color-svea-rail)",
									strokeWidth: 2
								}),
								/* @__PURE__ */ m("text", {
									y: 61,
									textAnchor: "middle",
									fontSize: b.length > 9 ? 18 : 22,
									fontWeight: 800,
									fill: "var(--color-svea-rail)",
									fontFamily: "inherit",
									children: b
								}),
								i === t && /* @__PURE__ */ h("g", {
									transform: "translate(0,-38)",
									children: [/* @__PURE__ */ m("circle", {
										r: 13,
										fill: "var(--color-svea-gold)",
										stroke: "var(--color-svea-rail)",
										strokeWidth: 3
									}), /* @__PURE__ */ m("text", {
										y: 5,
										textAnchor: "middle",
										fontSize: 15,
										fontWeight: 900,
										fill: "var(--color-svea-rail)",
										children: "×2"
									})]
								}),
								a === t && /* @__PURE__ */ h("g", {
									transform: "translate(58,-52)",
									children: [/* @__PURE__ */ m("rect", {
										x: -14,
										y: -12,
										width: 28,
										height: 24,
										rx: 3,
										fill: "var(--color-svea-gold)",
										stroke: "var(--color-svea-rail)",
										strokeWidth: 3
									}), /* @__PURE__ */ m("text", {
										y: 5,
										textAnchor: "middle",
										fontSize: 14,
										fontWeight: 900,
										fill: "var(--color-svea-rail)",
										children: "5"
									})]
								})
							]
						}, t);
					}),
					_?.runs.map((e, t) => {
						if (!e.route) return null;
						let n = e.route.path.map(rn).filter((e) => e !== null);
						if (n.length < 2) return null;
						let r = n[Math.floor(n.length / 2)];
						return /* @__PURE__ */ h("g", {
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ m("polyline", {
									points: n.map((e) => `${e.x},${e.y}`).join(" "),
									fill: "none",
									stroke: "var(--color-svea-rail)",
									strokeWidth: 20,
									strokeLinecap: "round",
									strokeLinejoin: "round",
									opacity: .7
								}),
								/* @__PURE__ */ m("polyline", {
									points: n.map((e) => `${e.x},${e.y}`).join(" "),
									fill: "none",
									stroke: "var(--color-svea-gold)",
									strokeWidth: 12,
									strokeLinecap: "round",
									strokeLinejoin: "round",
									strokeDasharray: t % 2 ? "20 9" : void 0
								}),
								/* @__PURE__ */ h("g", {
									transform: `translate(${r.x},${r.y - 43 - t * 22})`,
									children: [/* @__PURE__ */ m("rect", {
										x: -47,
										y: -16,
										width: 94,
										height: 32,
										rx: 3,
										fill: "var(--color-svea-paper)",
										stroke: "var(--color-svea-rail)",
										strokeWidth: 3
									}), /* @__PURE__ */ h("text", {
										y: 7,
										textAnchor: "middle",
										fontSize: 18,
										fontWeight: 900,
										fill: "var(--color-svea-rail)",
										fontFamily: "inherit",
										children: [
											e.train,
											" · ",
											e.route.value
										]
									})]
								})
							]
						}, `${e.train}:${t}`);
					}),
					fe.map((e, t) => /* @__PURE__ */ h("g", {
						transform: `translate(${e.x},${e.y})`,
						children: [/* @__PURE__ */ m("circle", {
							r: 13,
							fill: "var(--color-svea-paper)",
							stroke: "var(--color-svea-blue)",
							strokeWidth: 3.5
						}), /* @__PURE__ */ m("text", {
							y: 5.5,
							textAnchor: "middle",
							fontSize: 15,
							fontWeight: 900,
							fill: "var(--color-svea-blue)",
							fontFamily: "inherit",
							children: "⚓"
						})]
					}, t))
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "svea-map-controls",
				children: [
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => L(-.45),
						disabled: C <= 1,
						"aria-label": y("games.svea.zoomOut"),
						children: "−"
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => {
							ee(1), te({
								x: 0,
								y: 0
							});
						},
						"aria-label": y("games.svea.zoomReset"),
						children: "⌗"
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => L(.45),
						disabled: C >= 2.5,
						"aria-label": y("games.svea.zoomIn"),
						children: "+"
					})
				]
			}),
			v
		]
	});
}
//#endregion
//#region src/games/svea/cards-view.tsx
var on = {
	"central-station": "✦",
	"city-station-owner": "◆",
	"infrastructure-push": "⌁",
	"political-influence": "♜",
	"ferry-contract": "⚓",
	"financial-planning": "₩",
	"yellow-offboard": "↖",
	"blue-offboard": "↗",
	"new-railroad": "╳",
	"tax-haven": "◇",
	"raising-funds": "+",
	"delayed-permit": "◷"
}, sn = {
	"central-station": "svea-ticket--stone",
	"city-station-owner": "svea-ticket--forest",
	"infrastructure-push": "svea-ticket--ink",
	"political-influence": "svea-ticket--violet",
	"ferry-contract": "svea-ticket--blue",
	"financial-planning": "svea-ticket--forest",
	"yellow-offboard": "svea-ticket--gold",
	"blue-offboard": "svea-ticket--blue",
	"new-railroad": "svea-ticket--red",
	"tax-haven": "svea-ticket--copper",
	"raising-funds": "svea-ticket--stone",
	"delayed-permit": "svea-ticket--forest"
};
function cn({ pub: e, focus: t, nameOf: n, cardName: i, cardDesc: a }) {
	let o = r(), s = t ? [t, ...C.filter((e) => e !== t)] : C;
	return /* @__PURE__ */ h("section", {
		className: "svea-cards-board",
		"aria-label": o("games.svea.tabCards"),
		children: [/* @__PURE__ */ h("div", {
			className: "svea-board-heading",
			children: [
				/* @__PURE__ */ m("span", {
					className: "svea-board-heading__seal",
					children: "12"
				}),
				/* @__PURE__ */ m("span", { children: o("games.svea.tabCards") }),
				/* @__PURE__ */ m("span", {
					className: "svea-board-heading__end",
					children: "✦"
				})
			]
		}), /* @__PURE__ */ m("div", {
			className: "svea-cards-grid",
			children: s.map((r) => {
				let s = e.players.find((e) => e.cards.includes(r)), c = e.cards.assigned[r], l = e.cards.used.includes(r), u = e.cards.removed.includes(r), d = r === t;
				return /* @__PURE__ */ h("article", {
					className: `svea-ticket ${sn[r]} ${d ? "svea-ticket--focus" : ""} ${u ? "svea-ticket--removed" : l ? "svea-ticket--used" : ""}`,
					children: [
						/* @__PURE__ */ h("div", {
							className: "svea-ticket__title",
							children: [/* @__PURE__ */ m("span", { children: i(r) }), /* @__PURE__ */ m("span", {
								className: "svea-ticket__mark",
								"aria-hidden": !0,
								children: on[r]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "svea-ticket__body",
							children: [/* @__PURE__ */ m("span", {
								className: "svea-ticket__medallion",
								"aria-hidden": !0,
								children: on[r]
							}), /* @__PURE__ */ m("p", { children: a(r) })]
						}),
						/* @__PURE__ */ h("div", {
							className: "svea-ticket__footer",
							children: [/* @__PURE__ */ m("span", { children: o("games.svea.cardIncomeLabel", { n: S[r].income }) }), /* @__PURE__ */ m("span", { children: o("games.svea.cardPriority", { n: S[r].prioUnused }) })]
						}),
						/* @__PURE__ */ h("div", {
							className: "svea-ticket__ownership",
							children: [u ? o("games.svea.cardRemoved") : l ? o("games.svea.cardUsed") : s ? n(s.rid) : "—", c && /* @__PURE__ */ m("span", {
								className: "svea-company-coin",
								style: { backgroundColor: T[c].color },
								children: c
							})]
						})
					]
				}, r);
			})
		})]
	});
}
//#endregion
//#region src/games/svea/market-view.tsx
function ln({ companies: e }) {
	let t = r(), n = (t, n) => e.filter((e) => e.pos && e.pos.row === t && e.pos.col === n).map((e) => e.id), i = (e, t) => ve.some((n) => n.row === e && n.col === t);
	return /* @__PURE__ */ h("section", {
		className: "svea-market-board",
		"aria-label": t("games.svea.tabMarket"),
		children: [
			/* @__PURE__ */ h("div", {
				className: "svea-board-heading",
				children: [
					/* @__PURE__ */ m("span", {
						className: "svea-board-heading__seal",
						children: "20%"
					}),
					/* @__PURE__ */ m("span", { children: t("games.svea.tabMarket") }),
					/* @__PURE__ */ m("span", {
						className: "svea-board-heading__end",
						children: "130"
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "svea-market-scroll",
				children: /* @__PURE__ */ m("div", {
					className: "svea-market-track",
					children: ge.map((e, t) => /* @__PURE__ */ m("div", {
						className: "svea-market-row",
						children: e.map((e, r) => {
							let a = n(t, r), o = be({
								row: t,
								col: r
							}), s = i(t, r);
							return /* @__PURE__ */ h("div", {
								className: `svea-market-cell ${o ? "svea-market-cell--end" : s ? "svea-market-cell--par" : ""}`,
								children: [
									/* @__PURE__ */ m("span", {
										className: "svea-market-cell__value",
										children: e
									}),
									a.length > 0 && /* @__PURE__ */ m("span", {
										className: "svea-market-cell__tokens",
										children: a.map((e) => /* @__PURE__ */ m("span", {
											className: "svea-market-token",
											style: { backgroundColor: T[e].color },
											title: e,
											children: e
										}, e))
									}),
									o && /* @__PURE__ */ m("span", {
										className: "svea-market-cell__finish",
										"aria-hidden": !0,
										children: "◆"
									})
								]
							}, r);
						})
					}, t))
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "svea-market-legend",
				children: [/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("i", { className: "svea-market-legend__par" }), t("games.svea.par")] }), /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("i", { className: "svea-market-legend__end" }), t("games.svea.endPrice130")] })]
			})
		]
	});
}
//#endregion
//#region src/games/svea/placement-options.ts
function un(e) {
	let t = e.cityOwner?.company ?? null;
	return {
		devPhase: e.devPhase,
		centralDouble: e.central.mode === "white" ? e.central.hex : null,
		cityOwner: t && e.companies.some((e) => e.id === t && e.floated) ? {
			hex: e.cityOwner.hex,
			company: t
		} : null,
		nrcBars: e.nrc.bars,
		nrcCompany: e.nrc.stopBonus ? e.nrc.company : null,
		contracts: {
			yellow: e.cards.assigned["yellow-offboard"] ?? null,
			blue: e.cards.assigned["blue-offboard"] ?? null
		}
	};
}
function dn(e, t) {
	return e.cards.assigned["political-influence"] === t && e.cards.used.includes("political-influence");
}
function fn(e, t, n) {
	let r = z[t][n];
	if (r.kind === "offboard" || r.kind === "stub") return !0;
	if (r.kind !== "hex" && r.kind !== "water") return !1;
	let i = e[r.hex];
	return !!i && U[i.tile].edges.some((e) => W(e, i.rot) === (n + 3) % 6);
}
function pn(e, t) {
	let n = e.board[t];
	if (!n) return 0;
	let r = n.stations.filter((e) => !e.central).length;
	for (let i of E) {
		let a = e.companies.find((e) => e.id === i);
		T[i].home === t && !a?.homePlaced && !n.stations.some((e) => e.company === i) && (r += 1);
	}
	return r;
}
function mn(e, t) {
	let n = U[e];
	return n.segs ? n.segs.map(([e, n]) => [W(e, t), W(n, t)].sort((e, t) => e - t).join("-")).sort().join("/") : n.edges.map((e) => W(e, t)).sort((e, t) => e - t).join("-");
}
function hn(e, t, n) {
	let r = e.board, i = e.companies.find((e) => e.id === t);
	if (!i) return {};
	let a = G(r, t, un(e)), o = dn(e, t), s = {};
	for (let c of F) {
		if (!a.has(c) && (c !== T[t].home || i.homePlaced)) continue;
		let l = r[c];
		for (let t of Te) {
			let a = U[t], u = /* @__PURE__ */ new Set();
			if (!((e.tilePool[t] ?? 0) <= 0 || !D(e.devPhase, a.color)) && P[c].kind === "city" == a.slots > 0) {
				if (!l) {
					if (a.color !== "yellow" && !(a.color === "black" && a.slots > 0)) continue;
				} else if (a.color === "black") {
					if (U[l.tile].slots === 0) continue;
				} else if (Ee[a.color] !== U[l.tile].color) continue;
				for (let e = 0; e < 6; e++) {
					let d = a.edges.map((t) => W(t, e));
					if (d.some((e) => z[c][e].kind === "blocked") || l && U[l.tile].edges.some((e) => {
						let t = W(e, l.rot);
						return fn(r, c, t) && !d.includes(t);
					})) continue;
					let f = d.filter((e) => z[c][e].kind === "water" && fn(r, c, e)).length;
					l && (f -= U[l.tile].edges.filter((e) => {
						let t = W(e, l.rot);
						return d.includes(t) && z[c][t].kind === "water" && fn(r, c, t);
					}).length);
					let p = a.slots > 0 ? a.color === "black" ? 10 : 5 : 0, m = 5 * f, h = o ? 0 : p + m, g = o ? 0 : 2 * p + m;
					if (i.treasury < h && n < g) continue;
					let _ = i.treasury < h, v = mn(t, e);
					u.has(v) || (u.add(v), (s[c] ??= []).push({
						tile: t,
						rot: e,
						sponsor: _,
						cost: _ ? g : h,
						waterLinks: f
					}));
				}
			}
		}
	}
	return s;
}
function gn(e, t, n) {
	let r = e.board, i = e.companies.find((e) => e.id === t);
	if (!i || i.extraStationUsed) return {};
	let a = G(r, t, un(e)), o = dn(e, t) ? 5 : 10, s = {};
	for (let c of a) {
		let a = r[c];
		a && U[a.tile].slots !== 0 && (a.stations.some((e) => e.company === t) || pn(e, c) >= U[a.tile].slots || (i.treasury >= o ? s[c] = {
			sponsor: !1,
			cost: o
		} : n >= o * 2 && (s[c] = {
			sponsor: !0,
			cost: o * 2
		})));
	}
	return s;
}
function _n(e, t, n) {
	let r = e.board;
	return F.filter((i) => {
		let a = r[i];
		return !a || U[a.tile].slots === 0 ? !1 : n === "white" || !a.stations.some((e) => e.company === t) && pn(e, i) < U[a.tile].slots;
	});
}
//#endregion
//#region src/games/svea/view-player.tsx
var vn = {
	S: "games.svea.companyS",
	O: "games.svea.companyO",
	N: "games.svea.companyN",
	J: "games.svea.companyJ",
	G: "games.svea.companyG"
}, yn = {
	"central-station": "games.svea.cardCentralStation",
	"city-station-owner": "games.svea.cardCityStationOwner",
	"infrastructure-push": "games.svea.cardInfrastructurePush",
	"political-influence": "games.svea.cardPoliticalInfluence",
	"ferry-contract": "games.svea.cardFerryContract",
	"financial-planning": "games.svea.cardFinancialPlanning",
	"yellow-offboard": "games.svea.cardYellowOffboard",
	"blue-offboard": "games.svea.cardBlueOffboard",
	"new-railroad": "games.svea.cardNewRailroad",
	"tax-haven": "games.svea.cardTaxHaven",
	"raising-funds": "games.svea.cardRaisingFunds",
	"delayed-permit": "games.svea.cardDelayedPermit"
}, bn = {
	"central-station": "games.svea.cardDescCentralStation",
	"city-station-owner": "games.svea.cardDescCityStationOwner",
	"infrastructure-push": "games.svea.cardDescInfrastructurePush",
	"political-influence": "games.svea.cardDescPoliticalInfluence",
	"ferry-contract": "games.svea.cardDescFerryContract",
	"financial-planning": "games.svea.cardDescFinancialPlanning",
	"yellow-offboard": "games.svea.cardDescYellowOffboard",
	"blue-offboard": "games.svea.cardDescBlueOffboard",
	"new-railroad": "games.svea.cardDescNewRailroad",
	"tax-haven": "games.svea.cardDescTaxHaven",
	"raising-funds": "games.svea.cardDescRaisingFunds",
	"delayed-permit": "games.svea.cardDescDelayedPermit"
}, xn = {
	yellow: "games.svea.devYellow",
	green: "games.svea.devGreen",
	brown: "games.svea.devBrown",
	grey: "games.svea.devGrey",
	black: "games.svea.devBlack"
}, Sn = {
	north: "games.svea.offNorth",
	west: "games.svea.offWest",
	east: "games.svea.offEast",
	sw: "games.svea.offSw",
	se: "games.svea.offSe"
}, Cn = {
	treasury: "games.svea.orStepTreasury",
	train: "games.svea.orStepTrain",
	lay: "games.svea.orStepLay",
	station: "games.svea.orStepStation",
	run: "games.svea.orStepRun",
	pay: "games.svea.orStepPay"
}, wn = {
	karlstad: "games.svea.hexKarlstad",
	orebro: "games.svea.hexOrebro",
	vasteras: "games.svea.hexVasteras",
	goteborg: "games.svea.hexGoteborg",
	lake: "games.svea.hexLake",
	norrkoping: "games.svea.hexNorrkoping",
	stockholm: "games.svea.hexStockholm",
	jonkoping: "games.svea.hexJonkoping",
	linkoping: "games.svea.hexLinkoping",
	bay: "games.svea.hexBay",
	paleA: "games.svea.hexPaleA",
	paleB: "games.svea.hexPaleB"
};
function Tn({ min: e, max: t, step: n = 1, value: r, onChange: i }) {
	return /* @__PURE__ */ h("div", {
		className: "flex items-center gap-2",
		children: [
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "card min-h-11 min-w-11 cursor-pointer text-lg font-extrabold active:translate-y-0.5 disabled:opacity-40",
				disabled: r <= e,
				onClick: () => i(Math.max(e, r - n)),
				"aria-label": "-",
				children: "−"
			}),
			/* @__PURE__ */ m("span", {
				className: "min-w-12 text-center font-mono text-xl font-extrabold tabular-nums",
				children: r
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: "card min-h-11 min-w-11 cursor-pointer text-lg font-extrabold active:translate-y-0.5 disabled:opacity-40",
				disabled: r >= t,
				onClick: () => i(Math.min(t, r + n)),
				"aria-label": "+",
				children: "+"
			})
		]
	});
}
function En({ id: e }) {
	return /* @__PURE__ */ m("span", {
		className: "inline-block size-3.5 rounded-full border-2 border-ink",
		style: { background: T[e].color }
	});
}
function Dn(e) {
	let t = e.public, n = e.private ?? { myBid: null };
	return /* @__PURE__ */ m(On, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function On({ pub: e, priv: t, members: s, myRid: c, send: u }) {
	let g = n((e) => e.locale), _ = r(), v = (e) => u(e), y = (e) => s.find((t) => t.rid === e)?.name ?? e, b = (e) => _(vn[e]), x = (e) => _(yn[e]), C = e.players.find((e) => e.rid === c), ee = !!C, [w, te] = d(null), ne = e.sr ? "market" : e.sca || e.dsc ? "cards" : "board", k = w ?? ne, [A, re] = d({}), [ie, M] = d(null), [N, F] = d(0), [I, oe] = d(null), [L, R] = d(null), [se, ce] = d(null), [le, ue] = d(0), [de, fe] = d(0), [pe, me] = d(null), [z, ge] = d(null), [_e, ve] = d(!1), ye = `${e.round}:${e.sr?.cur ?? ""}:${e.or?.cur ?? ""}:${e.or?.step ?? ""}:${e.sca?.current ?? ""}`, [be, xe] = d(ye);
	be !== ye && (xe(ye), re({}), M(null), F(0), oe(null), R(null), ce(null), ue(0), fe(0), me(null), ge(null), ve(!1), te(null));
	let B = e.or, V = B && B.cur < B.queue.length ? B.queue[B.cur] : null, Se = V ? e.companies.find((e) => e.id === V) : null, Ce = !!V && e.ceo[V] === c && B.preBuy.length === 0, we = !!B && B.preBuy[0] === c, H = B?.trade ?? null, Ee = !!H && e.ceo[H.from] === c, W = e.sr, De = !!W && W.order[W.cur] === c, Oe = e.dsc?.queue[0]?.rid === c, G = e.sca, ke = G ? G.rebidPool ?? G.eligible : [], Ae = !!G && G.phase === "bid" && G.current !== null && ke.includes(c) && !G.bidsIn.includes(c), je = !!G && G.phase === "settle" && G.settle[0]?.rid === c, Me = Ce || we || Ee || De || Oe || Ae || je, Ne = l(() => V && C ? hn(e, V, C.cash) : {}, [
		e,
		V,
		C
	]), Pe = l(() => V && C ? gn(e, V, C.cash) : {}, [
		e,
		V,
		C
	]), K = I?.tile ? (Ne[I.hex] ?? []).find((e) => e.tile === I.tile && e.rot === I.rot) ?? (Ne[I.hex] ?? []).find((e) => e.tile === I.tile) : void 0, q = e.round.toUpperCase(), J = Me ? "accent" : "info", Y = "", X;
	if (e.round === "done") J = "done", Y = _(e.end.reason === "bankrupt" ? "games.svea.endBankrupt" : e.end.reason === "price130" ? "games.svea.endPrice130" : "games.svea.endComplete");
	else if (Oe) Y = _("games.svea.dscPrompt");
	else if (e.round === "dsc") Y = _("games.svea.srWait", { name: y(e.dsc?.queue[0]?.rid ?? "") });
	else if (W) {
		let e = W.order[W.cur];
		Y = De ? _("games.svea.srPrompt") : _("games.svea.srWait", { name: y(e) }), X = _("games.svea.srEndNote");
	} else if (G) G.phase === "settle" ? Y = je ? _("games.svea.scaSwapPrompt") : _("games.svea.srWait", { name: y(G.settle[0]?.rid ?? "") }) : Ae ? (Y = G.rebidPool ? _("games.svea.scaRebid") : _("games.svea.scaPrompt"), X = `${_("games.svea.scaCurrent")}: ${G.current ? x(G.current) : ""} · ${_("games.svea.scaLeft", { n: G.left })}`) : Y = _("games.svea.scaBidDone", { n: t.myBid ?? 0 });
	else if (B) {
		if (we) Y = _("games.svea.poliPrompt");
		else if (B.preBuy.length > 0) Y = _("games.svea.srWait", { name: y(B.preBuy[0]) });
		else if (H && Ee) Y = _("games.svea.tradePrompt", {
			company: b(H.by),
			price: H.price,
			train: H.train
		});
		else if (H) Y = _("games.svea.tradeWait", { name: y(e.ceo[H.from] ?? "") });
		else if (V) {
			let t = _(Cn[B.step]);
			Y = Ce ? `${b(V)} · ${t}` : _("games.svea.srWait", { name: y(e.ceo[V] ?? "") }), X = Ce ? void 0 : `${b(V)} · ${t}`, B.forced && B.step === "train" && Ce && (X = _("games.svea.orForced"));
		}
	}
	let Fe, Z = null, Ie;
	Ce && !H && (B.step === "lay" ? (Fe = Object.keys(Ne), Z = I?.hex ?? null, Ie = (e) => oe((t) => {
		let n = Ne[e] ?? [], r = n.find((e) => e.tile === t?.tile && e.rot === t.rot) ?? n[0];
		return {
			hex: e,
			tile: r?.tile ?? null,
			rot: r?.rot ?? 0,
			sponsor: r?.sponsor ?? !1
		};
	})) : B.step === "station" && (Fe = z && V ? _n(e, V, z) : Object.keys(Pe), Z = z ? null : L?.hex ?? null, Ie = (e) => {
		z ? (v({
			type: "cardCentral",
			hex: e,
			face: z
		}), ge(null)) : R({
			hex: e,
			sponsor: Pe[e]?.sponsor ?? !1
		});
	}));
	let Le = (() => {
		if (!ee || e.round === "done") return null;
		if (Oe) return /* @__PURE__ */ h("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ m("p", {
				className: "text-xs font-bold",
				children: _("games.svea.dscPrompt")
			}), /* @__PURE__ */ m("div", {
				className: "flex flex-wrap gap-2",
				children: E.map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "card flex min-h-11 cursor-pointer items-center gap-1.5 px-3 font-bold active:translate-y-0.5",
					onClick: () => v({
						type: "dscAssign",
						card: "delayed-permit",
						company: e
					}),
					children: [/* @__PURE__ */ m(En, { id: e }), b(e)]
				}, e))
			})]
		});
		if (G && G.phase === "bid" && G.current) return Ae ? /* @__PURE__ */ h("div", {
			className: "flex flex-col items-center gap-2",
			children: [
				/* @__PURE__ */ h("p", {
					className: "text-sm font-extrabold",
					children: [x(G.current), G.rebidPool && /* @__PURE__ */ m("span", {
						className: "ml-2 text-warn-ink",
						children: _("games.svea.scaRebid")
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ m(Tn, {
						min: 0,
						max: C.cash - (t.myBid ?? 0),
						step: 5,
						value: de,
						onChange: fe
					}), /* @__PURE__ */ m("button", {
						type: "button",
						className: "card min-h-12 cursor-pointer px-4 font-extrabold active:translate-y-0.5",
						style: {
							background: he.accent,
							color: "#fff"
						},
						onClick: () => v({
							type: "scaBid",
							amount: de
						}),
						children: _("games.svea.scaBidSubmit")
					})]
				}),
				/* @__PURE__ */ m("p", {
					className: "text-[10px] font-bold opacity-60",
					children: _(bn[G.current])
				})
			]
		}) : /* @__PURE__ */ m("p", {
			className: "py-2 text-center text-xs font-bold",
			children: _("games.svea.scaBidDone", { n: t.myBid ?? 0 })
		});
		if (je) return /* @__PURE__ */ h("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ m("p", {
				className: "text-xs font-bold",
				children: _("games.svea.scaSwapPrompt")
			}), /* @__PURE__ */ h("div", {
				className: "flex flex-wrap gap-2",
				children: [G.removed.map((e) => /* @__PURE__ */ m("button", {
					type: "button",
					className: "card min-h-11 cursor-pointer px-3 text-xs font-bold active:translate-y-0.5",
					onClick: () => v({
						type: "scaSwap",
						take: e
					}),
					children: x(e)
				}, e)), /* @__PURE__ */ m("button", {
					type: "button",
					className: "card min-h-11 cursor-pointer px-3 text-xs font-bold active:translate-y-0.5",
					onClick: () => v({
						type: "scaSwap",
						take: null
					}),
					children: _("games.svea.scaSwapSkip")
				})]
			})]
		});
		if (W && De) {
			let t = new Set(W.soldThisSr[c] ?? []), n = E.filter((t) => {
				let n = e.companies.find((e) => e.id === t), r = C.shares[t] ?? 0;
				return n.floated && r - +(e.ceo[t] === c) > 0;
			}), r = E.reduce((t, n) => t + (A[n] ?? 0) * (e.companies.find((e) => e.id === n).price ?? 0), 0), i = e.players.find((e) => e.rid === c) && E.reduce((e, t) => e + (C.shares[t] ?? 0), 0) >= j(e.players.length);
			return /* @__PURE__ */ h("div", {
				className: "flex flex-col gap-2",
				children: [
					n.length > 0 && /* @__PURE__ */ h("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [n.map((t) => {
							let n = (C.shares[t] ?? 0) - +(e.ceo[t] === c), r = A[t] ?? 0;
							return /* @__PURE__ */ h("span", {
								className: "flex items-center gap-1 rounded-lg border-2 border-ink bg-surface px-1.5 py-0.5",
								children: [
									/* @__PURE__ */ m(En, { id: t }),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "min-h-11 min-w-11 font-extrabold disabled:opacity-30",
										disabled: r <= 0,
										onClick: () => re({
											...A,
											[t]: r - 1
										}),
										"aria-label": "-",
										children: "−"
									}),
									/* @__PURE__ */ m("span", {
										className: "min-w-6 text-center font-mono font-extrabold tabular-nums",
										children: r
									}),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "min-h-11 min-w-11 font-extrabold disabled:opacity-30",
										disabled: r >= n,
										onClick: () => re({
											...A,
											[t]: r + 1
										}),
										"aria-label": "+",
										children: "+"
									})
								]
							}, t);
						}), /* @__PURE__ */ h("button", {
							type: "button",
							className: "card min-h-11 cursor-pointer px-3 font-extrabold active:translate-y-0.5 disabled:opacity-40",
							disabled: r <= 0,
							onClick: () => {
								let e = E.filter((e) => (A[e] ?? 0) > 0).map((e) => ({
									company: e,
									count: A[e]
								}));
								v({
									type: "srSell",
									sales: e
								}), re({});
							},
							children: [
								_("games.svea.srSell"),
								" +",
								r
							]
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [E.map((n) => {
							let r = e.companies.find((e) => e.id === n), a = t.has(n);
							return r.floated ? /* @__PURE__ */ h("span", {
								className: "flex items-center gap-1 rounded-lg border-2 border-ink bg-surface p-0.5",
								children: [
									/* @__PURE__ */ m(En, { id: n }),
									/* @__PURE__ */ h("button", {
										type: "button",
										className: "min-h-11 cursor-pointer rounded-md bg-info-soft px-2 font-mono text-xs font-extrabold tabular-nums active:translate-y-0.5 disabled:opacity-40",
										disabled: a || r.ipoLeft <= 0 || C.cash < (r.price ?? 0) || !!i,
										title: _("games.svea.srFromIpo"),
										onClick: () => v({
											type: "srBuy",
											company: n,
											from: "ipo"
										}),
										children: ["IPO ", r.price]
									}),
									/* @__PURE__ */ h("button", {
										type: "button",
										className: "min-h-11 cursor-pointer rounded-md bg-warn-soft px-2 font-mono text-xs font-extrabold tabular-nums active:translate-y-0.5 disabled:opacity-40",
										disabled: a || r.marketLeft <= 0 || C.cash < (r.price ?? 0) || !!i,
										title: _(a ? "games.svea.srSoldBlocked" : "games.svea.srFromMarket"),
										onClick: () => v({
											type: "srBuy",
											company: n,
											from: "market"
										}),
										children: [
											_("games.svea.market"),
											" ",
											r.price
										]
									})
								]
							}, n) : e.cards.locked === n ? null : /* @__PURE__ */ m("span", {
								className: "flex items-center gap-1",
								children: ie === n ? ae.map((e) => /* @__PURE__ */ m("button", {
									type: "button",
									className: "card min-h-11 min-w-11 cursor-pointer font-mono font-extrabold tabular-nums active:translate-y-0.5 disabled:opacity-40",
									disabled: C.cash < e || !!i,
									onClick: () => v({
										type: "srBuy",
										company: n,
										from: "ipo",
										par: e
									}),
									children: e
								}, e)) : /* @__PURE__ */ h("button", {
									type: "button",
									className: "card flex min-h-11 cursor-pointer items-center gap-1.5 px-3 text-xs font-bold active:translate-y-0.5 disabled:opacity-40",
									disabled: !!i,
									onClick: () => M(n),
									children: [/* @__PURE__ */ m(En, { id: n }), _("games.svea.srFloat")]
								})
							}, n);
						}), /* @__PURE__ */ m("button", {
							type: "button",
							className: "card min-h-12 cursor-pointer px-5 font-extrabold active:translate-y-0.5",
							onClick: () => v({ type: "srPass" }),
							children: _("games.svea.srPass")
						})]
					}),
					ie && /* @__PURE__ */ m("p", {
						className: "text-[10px] font-bold opacity-60",
						children: _("games.svea.srPickPar")
					})
				]
			});
		}
		if (B) {
			if (we) {
				let t = e.companies.filter((e) => e.floated && e.marketLeft > 0);
				return /* @__PURE__ */ h("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ m("p", {
						className: "text-xs font-bold",
						children: _("games.svea.poliPrompt")
					}), /* @__PURE__ */ h("div", {
						className: "flex flex-wrap gap-2",
						children: [t.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "card flex min-h-11 cursor-pointer items-center gap-1.5 px-3 text-xs font-bold active:translate-y-0.5",
							onClick: () => v({
								type: "cardPoliBuy",
								company: e.id
							}),
							children: [/* @__PURE__ */ m(En, { id: e.id }), e.price]
						}, e.id)), /* @__PURE__ */ m("button", {
							type: "button",
							className: "card min-h-11 cursor-pointer px-3 text-xs font-bold active:translate-y-0.5",
							onClick: () => v({ type: "cardPoliSkip" }),
							children: _("games.svea.poliSkip")
						})]
					})]
				});
			}
			if (H && Ee) return /* @__PURE__ */ h("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ m("p", {
						className: "flex-1 text-xs font-bold",
						children: _("games.svea.tradePrompt", {
							company: b(H.by),
							price: H.price,
							train: H.train
						})
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "card min-h-12 cursor-pointer bg-done-soft px-5 font-extrabold active:translate-y-0.5",
						onClick: () => v({
							type: "orTradeRespond",
							accept: !0
						}),
						children: _("games.svea.tradeAccept")
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "card min-h-12 cursor-pointer px-5 font-extrabold active:translate-y-0.5",
						onClick: () => v({
							type: "orTradeRespond",
							accept: !1
						}),
						children: _("games.svea.tradeReject")
					})
				]
			});
			if (!Ce || !V || !Se) return null;
			let t = (() => {
				if (H) return null;
				let t = Object.keys(S).filter((t) => !C.cards.includes(t) || e.cards.used.includes(t) ? !1 : [
					"political-influence",
					"ferry-contract",
					"yellow-offboard",
					"blue-offboard",
					"raising-funds",
					"city-station-owner",
					"new-railroad"
				].includes(t));
				return t.length === 0 ? null : /* @__PURE__ */ m("div", {
					className: "flex flex-wrap items-center gap-1.5",
					children: t.map((e) => pe === e ? /* @__PURE__ */ m("span", {
						className: "flex items-center gap-1",
						children: E.map((t) => /* @__PURE__ */ m("button", {
							type: "button",
							className: "card min-h-11 min-w-11 cursor-pointer px-1 active:translate-y-0.5",
							"aria-label": b(t),
							onClick: () => v({
								type: "cardAssign",
								card: e,
								company: t
							}),
							children: /* @__PURE__ */ m(En, { id: t })
						}, t))
					}, e) : /* @__PURE__ */ h("button", {
						type: "button",
						className: "card min-h-11 cursor-pointer px-2 text-xs font-bold active:translate-y-0.5",
						onClick: () => me(e),
						children: [x(e), " ⚡"]
					}, e))
				});
			})();
			switch (B.step) {
				case "treasury": return /* @__PURE__ */ h("div", {
					className: "flex flex-col gap-2",
					children: [
						t,
						/* @__PURE__ */ h("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ m(Tn, {
								min: 0,
								max: Se.ipoLeft,
								value: N,
								onChange: F
							}), /* @__PURE__ */ m("button", {
								type: "button",
								className: "card min-h-12 cursor-pointer px-4 font-extrabold active:translate-y-0.5",
								onClick: () => v({
									type: "orSellTreasury",
									count: N
								}),
								children: N > 0 ? `${_("games.svea.orSellTreasury")} ×${N}` : _("games.svea.orNoSell")
							})]
						}),
						/* @__PURE__ */ m("p", {
							className: "text-[10px] font-bold opacity-60",
							children: _("games.svea.orSellTreasuryNote")
						})
					]
				});
				case "train": {
					let n = Se.trains.includes("T4") && e.t6Unlocked && e.trainPool.includes("T6P") && Se.treasury >= 110, r = e.companies.filter((e) => e.id !== V && e.floated && e.trains.length > 0);
					return /* @__PURE__ */ h("div", {
						className: "flex flex-col gap-2",
						children: [
							t,
							B.forced && /* @__PURE__ */ m("p", {
								className: "text-[11px] font-bold text-warn-ink",
								children: _("games.svea.orForced")
							}),
							/* @__PURE__ */ h("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									B.allowedTrains.map((e) => /* @__PURE__ */ h("button", {
										type: "button",
										className: "card min-h-11 cursor-pointer px-3 font-mono text-xs font-extrabold tabular-nums active:translate-y-0.5 disabled:opacity-40",
										disabled: Se.trains.length >= 3 || !B.forced && Se.treasury < O[e].price,
										onClick: () => v({
											type: "orBuyTrain",
											train: e
										}),
										children: [
											e,
											" · ",
											O[e].price,
											" · ",
											_("games.svea.orTrainStops", { n: O[e].stops })
										]
									}, e)),
									n && /* @__PURE__ */ m("button", {
										type: "button",
										className: "card min-h-11 cursor-pointer px-3 text-xs font-extrabold active:translate-y-0.5",
										onClick: () => v({ type: "orExchangeTrain" }),
										children: _("games.svea.orExchangeTrain")
									}),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "card min-h-11 cursor-pointer px-3 text-xs font-bold active:translate-y-0.5",
										onClick: () => v({ type: "orDoneTrains" }),
										children: _("games.svea.orDoneTrains")
									})
								]
							}),
							r.length > 0 && /* @__PURE__ */ h("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ h("span", {
										className: "text-[10px] font-bold opacity-60",
										children: [_("games.svea.orTradeTrain"), ":"]
									}),
									r.map((e) => /* @__PURE__ */ m("span", {
										className: "flex items-center gap-1",
										children: e.trains.map((t, n) => /* @__PURE__ */ h("button", {
											type: "button",
											className: "card flex min-h-11 cursor-pointer items-center gap-1 px-2 font-mono text-xs font-bold active:translate-y-0.5",
											onClick: () => ce({
												from: e.id,
												train: t,
												price: 1
											}),
											children: [/* @__PURE__ */ m(En, { id: e.id }), t]
										}, `${t}-${n}`))
									}, e.id)),
									se?.train && /* @__PURE__ */ h("span", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ m(Tn, {
											min: 1,
											max: Se.treasury,
											value: se.price,
											onChange: (e) => ce({
												...se,
												price: e
											})
										}), /* @__PURE__ */ m("button", {
											type: "button",
											className: "card min-h-11 cursor-pointer px-3 text-xs font-extrabold active:translate-y-0.5",
											onClick: () => v({
												type: "orTradeTrain",
												from: se.from,
												train: se.train,
												price: se.price
											}),
											children: _("games.svea.confirm")
										})]
									})
								]
							})
						]
					});
				}
				case "lay": {
					let n = I?.hex ?? Object.keys(Ne)[0], r = n ? Ne[n] ?? [] : [], i = Te.filter((e) => r.some((t) => t.tile === e)), a = !n || P[n].kind === "city", o = Te.find((e) => !i.includes(e) && U[e].slots > 0 === a), s = [...i, ...o ? [o] : []], c = K, l = r.filter((e) => e.tile === c?.tile), u = (t) => (e.tilePool[t] ?? 0) <= 0 ? _("games.svea.lockedPool") : D(e.devPhase, U[t].color) ? _("games.svea.lockedHex") : _("games.svea.lockedPhase");
					return /* @__PURE__ */ h("div", {
						className: "svea-yard",
						children: [
							/* @__PURE__ */ h("div", {
								className: "svea-yard__heading",
								children: [
									/* @__PURE__ */ m("h2", { children: _("games.svea.tileYard") }),
									/* @__PURE__ */ m("span", { children: B.extraLay ? _("games.svea.orExtraLay") : _("games.svea.chooseRotateLay") }),
									t && /* @__PURE__ */ h("button", {
										type: "button",
										className: "svea-yard__card-toggle",
										"aria-pressed": _e,
										onClick: () => ve((e) => !e),
										children: ["✦ ", _("games.svea.tabCards")]
									}),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "svea-yard__skip",
										onClick: () => v({ type: "orSkipLay" }),
										children: _("games.svea.skip")
									})
								]
							}),
							t && _e && /* @__PURE__ */ m("div", {
								className: "svea-yard__card-drawer",
								children: t
							}),
							/* @__PURE__ */ h("div", {
								className: "svea-yard__tiles",
								role: "group",
								"aria-label": _("games.svea.tileYard"),
								children: [s.length === 0 && /* @__PURE__ */ m("p", {
									className: "svea-yard__empty",
									children: _("games.svea.legalNone")
								}), s.map((t) => {
									let i = r.find((e) => e.tile === t), a = I?.tile === t;
									return /* @__PURE__ */ h("button", {
										type: "button",
										className: "svea-yard-tile " + (a ? "svea-yard-tile--picked " : "") + (i ? "" : "svea-yard-tile--locked"),
										"aria-pressed": a,
										disabled: !i || !n,
										title: i ? void 0 : u(t),
										onClick: () => {
											i && n && oe({
												hex: n,
												tile: t,
												rot: i.rot,
												sponsor: i.sponsor
											});
										},
										children: [
											/* @__PURE__ */ m("span", {
												className: "svea-yard-tile__face",
												children: /* @__PURE__ */ m(nn, {
													tile: t,
													rot: a ? c?.rot ?? i?.rot ?? 0 : i?.rot ?? 0
												})
											}),
											/* @__PURE__ */ h("span", {
												className: "svea-yard-tile__caption",
												children: [/* @__PURE__ */ m("b", { children: t.toUpperCase() }), /* @__PURE__ */ m("small", { children: i ? `×${e.tilePool[t] ?? 0}` : u(t) })]
											}),
											!i && /* @__PURE__ */ m("span", {
												className: "svea-yard-tile__lock",
												"aria-hidden": !0,
												children: "⌑"
											})
										]
									}, t);
								})]
							}),
							/* @__PURE__ */ h("div", {
								className: "svea-yard__footer",
								children: [/* @__PURE__ */ h("button", {
									type: "button",
									className: "svea-yard__rotate",
									disabled: !I || !c || l.length < 2,
									onClick: () => {
										if (!I || !c || l.length < 2) return;
										let e = l[(l.findIndex((e) => e.rot === c.rot) + 1) % l.length];
										oe({
											...I,
											rot: e.rot,
											sponsor: e.sponsor
										});
									},
									children: [
										/* @__PURE__ */ m("span", {
											"aria-hidden": !0,
											children: "⟳"
										}),
										_("games.svea.rotate"),
										" ",
										/* @__PURE__ */ m("small", { children: c ? `${c.rot * 60}°` : "—" })
									]
								}), /* @__PURE__ */ h("button", {
									type: "button",
									className: "svea-yard__lay",
									disabled: !I || !c,
									onClick: () => {
										I && c && v({
											type: "orLayTile",
											hex: I.hex,
											tile: c.tile,
											rot: c.rot,
											sponsor: c.sponsor
										});
									},
									children: [
										_("games.svea.layTile"),
										" ",
										/* @__PURE__ */ m("span", {
											className: "svea-yard__cost",
											children: c ? c.cost : "—"
										})
									]
								})]
							})
						]
					});
				}
				case "station": {
					let n = C.cards.includes("central-station") && !e.cards.used.includes("central-station"), r = L ? Pe[L.hex] : null;
					return /* @__PURE__ */ h("div", {
						className: "flex flex-col gap-2",
						children: [
							t,
							/* @__PURE__ */ m("p", {
								className: "text-[11px] font-bold",
								children: _("games.svea.orStationPrompt")
							}),
							L && r && /* @__PURE__ */ h("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ m("span", {
										className: "text-xs font-extrabold",
										children: _(wn[L.hex])
									}),
									/* @__PURE__ */ m("span", {
										className: "svea-cost-token",
										children: _("games.svea.layCost", { n: r.cost })
									}),
									r.sponsor && /* @__PURE__ */ m("span", {
										className: "svea-cost-token",
										children: _("games.svea.sponsor")
									}),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "card min-h-12 cursor-pointer px-4 font-extrabold active:translate-y-0.5",
										style: {
											background: he.accent,
											color: "#fff"
										},
										onClick: () => v({
											type: "orPlaceStation",
											hex: L.hex,
											sponsor: r.sponsor
										}),
										children: _("games.svea.confirm")
									})
								]
							}),
							/* @__PURE__ */ h("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [n && /* @__PURE__ */ h(p, { children: [
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "card svea-face-choice min-h-11 cursor-pointer px-2 text-xs font-bold active:translate-y-0.5",
										"aria-pressed": z === "white",
										onClick: () => {
											ge("white"), R(null), te("board");
										},
										children: _("games.svea.cardWhiteFace")
									}),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "card svea-face-choice min-h-11 cursor-pointer px-2 text-xs font-bold active:translate-y-0.5",
										"aria-pressed": z === "black",
										onClick: () => {
											ge("black"), R(null), te("board");
										},
										children: _("games.svea.cardBlackFace")
									}),
									z && /* @__PURE__ */ m("span", {
										className: "text-[10px] font-bold text-info-ink",
										children: _("games.svea.orStationPrompt")
									})
								] }), /* @__PURE__ */ m("button", {
									type: "button",
									className: "card min-h-11 cursor-pointer px-3 text-xs font-bold active:translate-y-0.5",
									onClick: () => v({ type: "orSkipStation" }),
									children: _("games.svea.skip")
								})]
							})
						]
					});
				}
				case "run": return /* @__PURE__ */ h("div", {
					className: "flex flex-col gap-2",
					children: [
						t,
						B.tiredTrains.length > 0 && /* @__PURE__ */ m("p", {
							className: "text-[10px] font-bold text-warn-ink",
							children: _("games.svea.tiredNote")
						}),
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "card min-h-12 cursor-pointer self-start px-6 font-extrabold active:translate-y-0.5",
							style: {
								background: he.accent,
								color: "#fff"
							},
							onClick: () => v({ type: "orRunTrains" }),
							children: _("games.svea.orRunTrains")
						})
					]
				});
				case "pay": {
					let t = B.lastRun?.total ?? 0, n = Se.price ?? 0, r = C.cards.includes("financial-planning") && !e.cards.used.includes("financial-planning");
					return /* @__PURE__ */ h("div", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ h("p", {
								className: "font-mono text-sm font-extrabold tabular-nums",
								children: [
									_("games.svea.orRunResult"),
									": ",
									t,
									/* @__PURE__ */ m("span", {
										className: "ml-2 text-[10px] font-bold opacity-60",
										children: t >= 2 * n ? _("games.svea.orMoveRight2") : _(t > 0 ? "games.svea.orMoveRight1" : "games.svea.orMoveLeft1")
									})
								]
							}),
							B.lastRun && /* @__PURE__ */ m("p", {
								className: "font-mono text-[10px] font-bold tabular-nums opacity-70",
								children: B.lastRun.runs.map((e) => {
									if (!e.route) return `${e.train}:—`;
									let t = e.route.stops.map((e) => e.kind === "city" ? _(wn[e.id]) : e.kind === "offboard" ? _(Sn[e.id]) : _("games.svea.stub", { n: e.id })).join("→");
									return `${e.train}: ${t} = ${e.route.value}`;
								}).join(" · ")
							}),
							/* @__PURE__ */ h("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "card min-h-12 cursor-pointer bg-done-soft px-4 font-extrabold active:translate-y-0.5",
										onClick: () => v({
											type: "orDividend",
											mode: "payout"
										}),
										children: _("games.svea.orPayout")
									}),
									/* @__PURE__ */ m("button", {
										type: "button",
										className: "card min-h-12 cursor-pointer bg-warn-soft px-4 font-extrabold active:translate-y-0.5",
										onClick: () => v({
											type: "orDividend",
											mode: "withhold"
										}),
										children: _("games.svea.orWithhold")
									}),
									r && /* @__PURE__ */ h("span", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ m(Tn, {
											min: 0,
											max: t,
											step: 5,
											value: le,
											onChange: ue
										}), /* @__PURE__ */ m("button", {
											type: "button",
											className: "card min-h-12 cursor-pointer px-4 font-extrabold active:translate-y-0.5",
											onClick: () => v({
												type: "orDividend",
												mode: "split",
												amount: le
											}),
											children: _("games.svea.orSplit")
										})]
									})
								]
							})
						]
					});
				}
			}
		}
		return null;
	})(), Re = I?.hex ?? L?.hex ?? null, ze = Re ? `${_(wn[Re])} · ${I && e.board[Re] ? _("games.svea.legalUpgrade") : _("games.svea.legalPlace")}` : Fe?.length ? _("games.svea.legalChoose") : _("games.svea.legalNone"), Be = /* @__PURE__ */ h("div", {
		className: "svea-legal-ticket",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ h("div", {
				className: "svea-legal-ticket__top",
				children: [/* @__PURE__ */ m("span", { children: _("games.svea.legal") }), /* @__PURE__ */ m("strong", { children: ze })]
			}),
			/* @__PURE__ */ h("div", {
				className: "svea-legal-ticket__bottom",
				children: [/* @__PURE__ */ m("span", { children: I && K ? `${I.tile?.toUpperCase() ?? ""} · ${_("games.svea.waterLinks", { n: K.waterLinks })}` : L && Pe[L.hex] ? _("games.svea.orStationPrompt") : Fe?.length ? _("games.svea.legalSites", { n: Fe.length }) : Y }), (K || L && Pe[L.hex]) && /* @__PURE__ */ m("b", { children: _("games.svea.layCost", { n: K?.cost ?? Pe[L.hex].cost }) })]
			}),
			K?.sponsor && /* @__PURE__ */ m("small", { children: _("games.svea.sponsor") })
		]
	});
	return /* @__PURE__ */ m("div", {
		className: "svea-game",
		children: /* @__PURE__ */ m(f, {
			adaptive: !0,
			className: "svea-screen",
			scroll: !1,
			banner: /* @__PURE__ */ h("div", {
				className: "svea-header",
				children: [/* @__PURE__ */ h("div", {
					className: "svea-header__top",
					children: [
						/* @__PURE__ */ m("div", {
							className: "svea-brand-mark",
							"aria-hidden": !0,
							children: /* @__PURE__ */ m("span", { children: "18" })
						}),
						/* @__PURE__ */ h("div", {
							className: "svea-header__identity",
							children: [/* @__PURE__ */ m("strong", { children: "SVEA" }), /* @__PURE__ */ m("span", { children: _("games.svea.railwayCompany") })]
						}),
						/* @__PURE__ */ h("div", {
							className: "svea-header__round",
							children: [/* @__PURE__ */ m("small", { children: _("games.svea.round") }), /* @__PURE__ */ m("strong", { children: q })]
						}),
						/* @__PURE__ */ h("div", {
							className: "svea-header__status svea-header__status--" + J,
							role: "status",
							"aria-live": "polite",
							children: [/* @__PURE__ */ m("strong", { children: Y }), /* @__PURE__ */ m("span", { children: X ?? _(xn[e.devPhase]) })]
						})
					]
				}), /* @__PURE__ */ m("ul", {
					className: "svea-player-ledger",
					children: s.map((t) => {
						let n = e.players.find((e) => e.rid === t.rid), r = n ? E.reduce((e, t) => e + (n.shares[t] ?? 0), 0) : 0, o = E.filter((n) => e.ceo[n] === t.rid);
						return /* @__PURE__ */ h("li", {
							className: "svea-player-ledger__seat",
							children: [
								/* @__PURE__ */ m(i, {
									m: t,
									myRid: c,
									action: null,
									anchorName: null,
									box: "size-8 svea-seat-avatar",
									img: "size-7 svea-seat-image"
								}),
								/* @__PURE__ */ h("span", {
									className: "svea-player-ledger__details",
									children: [/* @__PURE__ */ m("strong", { children: a(t, g) }), /* @__PURE__ */ h("small", { children: [
										_("games.svea.cash"),
										" ",
										n?.cash ?? "—",
										" · ",
										_("games.svea.shares"),
										" ",
										r
									] })]
								}),
								o.length > 0 && /* @__PURE__ */ m("span", {
									className: "svea-player-ledger__ceos",
									children: o.map((e) => /* @__PURE__ */ m("span", {
										className: "svea-company-coin",
										style: { backgroundColor: T[e].color },
										title: b(e),
										children: e
									}, e))
								})
							]
						}, t.rid);
					})
				})]
			}),
			actionsHeight: "svea-actions-slot",
			actions: /* @__PURE__ */ m("div", {
				className: "svea-action-tray " + (B?.step === "lay" && Ce ? "svea-action-tray--yard" : ""),
				children: B?.step === "lay" && Ce ? Le : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
					className: "svea-tray-heading",
					children: [/* @__PURE__ */ m("strong", { children: B ? _(Cn[B.step]) : W ? _("games.svea.phaseSr") : G ? _("games.svea.phaseSca") : e.round === "done" ? _("games.svea.phaseDone") : _("games.svea.phaseDsc") }), /* @__PURE__ */ m("span", { children: q })]
				}), /* @__PURE__ */ m("div", {
					className: "svea-tray-content",
					children: Le ?? /* @__PURE__ */ m("p", {
						className: "svea-action-tray__wait",
						children: Y
					})
				})] })
			}),
			children: /* @__PURE__ */ h("div", {
				className: "svea-table",
				children: [/* @__PURE__ */ m("div", {
					className: "svea-surface-dock",
					role: "group",
					"aria-label": _("games.svea.name"),
					children: [
						"board",
						"market",
						"cards"
					].map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: "svea-surface-ticket " + (k === e ? "svea-surface-ticket--active" : ""),
						"aria-pressed": k === e,
						onClick: () => te(e),
						children: [/* @__PURE__ */ m("span", {
							"aria-hidden": !0,
							children: e === "board" ? "⬡" : e === "market" ? "↗" : "✦"
						}), /* @__PURE__ */ m("b", { children: _(e === "board" ? "games.svea.surfaceBoard" : e === "market" ? "games.svea.surfaceMarket" : "games.svea.surfaceCards") })]
					}, e))
				}), /* @__PURE__ */ h("div", {
					className: "svea-table__surface",
					children: [
						k === "board" && /* @__PURE__ */ m(an, {
							board: e.board,
							devPhase: e.devPhase,
							nrcBars: e.nrc.bars,
							centralHex: e.central.mode === "white" ? e.central.hex : null,
							cityOwnerHex: e.cityOwner?.hex ?? null,
							selectable: Fe,
							picked: Z,
							focusHex: V ? T[V].home : null,
							onPick: Ie,
							ghost: I && K ? {
								hex: I.hex,
								tile: K.tile,
								rot: K.rot
							} : null,
							runResult: B?.step === "pay" ? B.lastRun : null,
							legalTicket: Be
						}),
						k === "market" && /* @__PURE__ */ h("div", {
							className: "svea-market-surface",
							children: [/* @__PURE__ */ m(ln, { companies: e.companies }), /* @__PURE__ */ m("div", {
								className: "svea-charters",
								children: e.companies.map((t) => /* @__PURE__ */ h("article", {
									className: "svea-charter",
									children: [
										/* @__PURE__ */ h("div", {
											className: "svea-charter__band",
											style: { backgroundColor: T[t.id].color },
											children: [
												/* @__PURE__ */ m("span", {
													className: "svea-company-coin",
													style: { backgroundColor: T[t.id].color },
													children: t.id
												}),
												/* @__PURE__ */ m("strong", { children: b(t.id) }),
												/* @__PURE__ */ m("b", { children: t.floated ? t.price : "—" })
											]
										}),
										/* @__PURE__ */ h("div", {
											className: "svea-charter__body",
											children: [
												/* @__PURE__ */ m("span", { children: e.ceo[t.id] ? _("games.svea.ceoBadge") + " · " + y(e.ceo[t.id]) : _("games.svea.unfloated") }),
												/* @__PURE__ */ h("span", { children: [
													_("games.svea.treasury"),
													" ",
													/* @__PURE__ */ m("b", { children: t.treasury })
												] }),
												/* @__PURE__ */ h("span", { children: [
													_("games.svea.trainsLabel"),
													" ",
													/* @__PURE__ */ m("b", { children: t.trains.join(" / ") || "—" })
												] }),
												/* @__PURE__ */ h("span", { children: [
													"IPO ",
													/* @__PURE__ */ m("b", { children: t.ipoLeft }),
													" · ",
													_("games.svea.market"),
													" ",
													/* @__PURE__ */ m("b", { children: t.marketLeft })
												] })
											]
										}),
										/* @__PURE__ */ m("div", {
											className: "svea-charter__shares",
											children: e.players.flatMap((e) => Array.from({ length: e.shares[t.id] ?? 0 }, (t, n) => /* @__PURE__ */ m("span", {
												title: y(e.rid),
												children: /* @__PURE__ */ m("img", {
													src: o[(s.find((t) => t.rid === e.rid)?.avatar ?? 0) % o.length],
													alt: "",
													draggable: !1,
													style: {
														width: "1.75em",
														height: "1.75em",
														maxWidth: "100%",
														maxHeight: "100%",
														display: "block",
														objectFit: "contain",
														pointerEvents: "none",
														borderRadius: "inherit"
													}
												})
											}, e.rid + ":" + n)))
										})
									]
								}, t.id))
							})]
						}),
						k === "cards" && /* @__PURE__ */ m(cn, {
							pub: e,
							focus: G?.current,
							nameOf: y,
							cardName: x,
							cardDesc: (e) => _(bn[e])
						})
					]
				})]
			})
		})
	});
}
//#endregion
//#region src/games/svea/bot.ts
var kn = {
	buyMargin: 1.2,
	sellMargin: 1.2,
	estPayout: .55,
	priceGrowth: .12,
	ipoBonus: 10,
	startupW: 1,
	controlBonus: 15,
	secondCoMin: 30,
	maxCeos: 2,
	parPref: 0,
	trainRoi: .5,
	trainKeep: 10,
	treasurySellGap: 0,
	layMinGain: 0,
	layCostW: 1,
	layProb: .9,
	stationMinGain: 0,
	centralMinGain: 5,
	payoutShareMin: 2,
	scaReserve: 30,
	bidValueMul: 1,
	tradeMargin: 5,
	sellTrainMul: .7,
	weakJitter: .6
};
function An() {
	let e = /* @__PURE__ */ new Uint32Array(1);
	return crypto.getRandomValues(e), e[0] / 4294967296;
}
var jn = k.map((e, t) => e.startsWith("or") ? t : -1).filter((e) => e >= 0), Mn = k.map((e, t) => e.startsWith("sr") ? t : -1).filter((e) => e >= 0), Nn = (e) => k.indexOf(e.round), Pn = (e) => jn.filter((t) => t > Nn(e)).length, Fn = (e) => jn.filter((t) => t >= Nn(e)).length, In = (e) => Mn.filter((t) => t > Nn(e)).length;
function Ln(e) {
	let t = e.cityOwner?.company ?? null;
	return {
		devPhase: e.devPhase,
		centralDouble: e.central.mode === "white" ? e.central.hex : null,
		cityOwner: t && (e.companies.find((e) => e.id === t)?.floated ?? !1) ? {
			hex: e.cityOwner.hex,
			company: t
		} : null,
		nrcBars: e.nrc.bars,
		nrcCompany: e.nrc.stopBonus ? e.nrc.company : null,
		contracts: {
			yellow: e.cards.assigned["yellow-offboard"] ?? null,
			blue: e.cards.assigned["blue-offboard"] ?? null
		}
	};
}
var Rn = (e, t) => e.cards.assigned["political-influence"] === t && e.cards.used.includes("political-influence"), zn = (e, t) => t === "T2" && !e.trainPool.includes("T3") || t === "T3" && e.t6Unlocked, Bn = null;
function Vn() {
	if (Bn) return Bn;
	let e = {
		devPhase: "yellow",
		centralDouble: null,
		cityOwner: null,
		nrcBars: [
			!1,
			!1,
			!1
		],
		nrcCompany: null,
		contracts: {
			yellow: null,
			blue: null
		}
	}, t = {};
	for (let n of E) {
		let r = 0, i = T[n].home;
		for (let t of Te) {
			let a = U[t];
			if (a.color === "yellow" && a.slots !== 0) for (let o = 0; o < 6; o++) a.edges.map((e) => W(e, o)).some((e) => z[i][e].kind === "blocked") || (r = Math.max(r, q({ [i]: {
				tile: t,
				rot: o,
				stations: [{
					company: n,
					active: !0
				}]
			} }, n, ["T2"], e).total));
		}
		t[n] = r;
	}
	return Bn = t, t;
}
function Hn(e, t, n, r) {
	let i = e.companies.find((e) => e.id === n).treasury, a = Rn(e, n), o = [];
	for (let n of F) {
		if (!r.has(n)) continue;
		let s = P[n], c = t[n];
		for (let r of Te) {
			let l = U[r];
			if (!((e.tilePool[r] ?? 0) <= 0) && D(e.devPhase, l.color) && (s.kind !== "city" || l.slots !== 0) && !(s.kind !== "city" && l.slots > 0)) {
				if (!c) {
					if (l.color !== "yellow" && (l.color !== "black" || s.kind !== "city")) continue;
				} else if (l.color === "black") {
					if (U[c.tile].slots === 0) continue;
				} else if (Ee[l.color] !== U[c.tile].color) continue;
				for (let e = 0; e < 6; e++) {
					let s = l.edges.map((t) => W(t, e));
					if (s.some((e) => z[n][e].kind === "blocked")) continue;
					if (c) {
						let e = !0;
						for (let r of U[c.tile].edges) {
							let i = W(r, c.rot), a = z[n][i], o = a.kind === "offboard" || a.kind === "stub";
							if (a.kind === "hex" || a.kind === "water") {
								let e = t[a.hex];
								e && (o = U[e.tile].edges.some((t) => W(t, e.rot) === (i + 3) % 6));
							}
							if (o && !s.includes(i)) {
								e = !1;
								break;
							}
						}
						if (!e) continue;
					}
					let u = 0;
					for (let e of s) {
						let r = z[n][e];
						if (r.kind !== "water") continue;
						let i = t[r.hex];
						i && U[i.tile].edges.some((t) => W(t, i.rot) === (e + 3) % 6) && (u += 1);
					}
					if (c) for (let e of U[c.tile].edges) {
						let r = W(e, c.rot), i = z[n][r];
						if (i.kind !== "water" || !s.includes(r)) continue;
						let a = t[i.hex];
						a && U[a.tile].edges.some((e) => W(e, a.rot) === (r + 3) % 6) && --u;
					}
					let d = a ? 0 : (l.slots > 0 ? l.color === "black" ? 10 : 5 : 0) + 5 * u;
					i < d || o.push({
						hex: n,
						tile: r,
						rot: e,
						cost: d
					});
				}
			}
		}
	}
	return o;
}
var Un = {
	"central-station": 12,
	"city-station-owner": 8,
	"infrastructure-push": 10,
	"political-influence": 12,
	"ferry-contract": 10,
	"financial-planning": 8,
	"yellow-offboard": 10,
	"blue-offboard": 10,
	"new-railroad": 8,
	"tax-haven": 12,
	"raising-funds": 40,
	"delayed-permit": 8
};
function Wn(e) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i || r.round === "done") return null;
		let a = n.difficulty === "weak", o = (t) => a ? t * (1 - e.weakJitter / 2 + An() * e.weakJitter) : t, s = r.board, c = Ln(r), l = (e) => r.companies.find((t) => t.id === e), u = E.filter((e) => r.ceo[e] === n.rid), d = i.cards.filter((e) => !r.cards.used.includes(e)), f = E.reduce((e, t) => e + (i.shares[t] ?? 0), 0) >= j(r.players.length), p = /* @__PURE__ */ new Map(), m = (e, t, n, r) => {
			let i = l(e), a = t ?? i.trains;
			if (a.length === 0) return 0;
			let o = n || r ? null : `${e}:${a.join(",")}`;
			if (o && p.has(o)) return p.get(o);
			let u = q(n ?? s, e, a, r ?? c).total;
			return o && p.set(o, u), u;
		}, h = (t, n) => {
			let i = l(t).price;
			if (i === null) return 0;
			let a = Pn(r), o = m(t) / 5, s = e.estPayout * a, c = Math.min(130, i * (1 + e.priceGrowth) ** +s), u = d.includes("tax-haven") ? N : M, f = Math.min(n, 5), p = (u[f] ?? 0) - (f > 0 ? u[f - 1] ?? 0 : 0);
			return c + o * s - p * In(r);
		};
		if (r.round === "dsc") {
			if (r.dsc?.queue[0]?.rid !== n.rid) return null;
			let e = [...E].sort((e, t) => Vn()[t] - Vn()[e]);
			return { action: {
				type: "dscAssign",
				card: "delayed-permit",
				company: e.find((t) => t !== e[0]) ?? "S"
			} };
		}
		if (r.sca) {
			let a = r.sca;
			if (a.phase === "settle") return a.settle[0]?.rid === n.rid ? { action: {
				type: "scaSwap",
				take: [...a.removed].sort((e, t) => S[t].income - S[e].income)[0] ?? null
			} } : null;
			let s = a.rebidPool ?? a.eligible;
			if (!a.current || !s.includes(n.rid) || a.bidsIn.includes(n.rid)) return null;
			let c = S[a.current].income * 4 + Un[a.current], l = Math.max(0, i.cash - e.scaReserve - (t.private?.myBid ?? 0)), u = Math.floor(o(c) * e.bidValueMul) - (t.private?.myBid ?? 0);
			return { action: {
				type: "scaBid",
				amount: Math.max(0, Math.min(l, u))
			} };
		}
		if (r.sr) {
			if (r.sr.order[r.sr.cur] !== n.rid) return null;
			let t = r.sr.soldThisSr[n.rid] ?? [], a = (e) => i.shares[e] ?? 0, s = null;
			for (let t of E) {
				let i = a(t), c = r.ceo[t] === n.rid ? i - 1 : i;
				if (c <= 0) continue;
				let u = l(t);
				if (!u.floated || u.price === null) continue;
				let d = o(h(t, i)) / u.price;
				d < e.sellMargin && (!s || d < s.ratio) && (s = {
					c: t,
					count: c,
					ratio: d
				});
			}
			if (s) return { action: {
				type: "srSell",
				sales: [{
					company: s.c,
					count: s.count
				}]
			} };
			let c = null;
			if (!f) {
				for (let s of E) {
					let u = l(s);
					if (!u.floated || u.price === null || t.includes(s) || i.cash < u.price) continue;
					let d = o(h(s, a(s) + 1)) - u.price * e.buyMargin;
					if (!(d <= 0)) {
						if (u.ipoLeft > 0) {
							let t = u.trains.length < 3 && u.treasury < O.T3.price, i = r.ceo[s] === n.rid && t ? e.ipoBonus : 0;
							(!c || d + i > c.gain) && (c = {
								action: {
									type: "srBuy",
									company: s,
									from: "ipo"
								},
								gain: d + i
							});
						}
						u.marketLeft > 0 && (!c || d > c.gain) && (c = {
							action: {
								type: "srBuy",
								company: s,
								from: "market"
							},
							gain: d
						});
					}
				}
				let s = [...E].sort((e, t) => Vn()[t] - Vn()[e]), d = ae[Math.min(e.parPref, ae.length - 1)];
				for (let t of s) {
					if (l(t).floated || t === r.cards.locked || i.cash < d) continue;
					if (u.length === 0) return { action: {
						type: "srBuy",
						company: t,
						from: "ipo",
						par: d
					} };
					if (u.length >= e.maxCeos) break;
					if (i.cash < d + e.secondCoMin) continue;
					let n = o(Vn()[t]) * e.startupW * (Pn(r) / 7) + e.controlBonus - d;
					n > 0 && (!c || n > c.gain) && (c = {
						action: {
							type: "srBuy",
							company: t,
							from: "ipo",
							par: d
						},
						gain: n
					});
					break;
				}
			}
			return c ? { action: c.action } : { action: { type: "srPass" } };
		}
		if (r.or) {
			let t = r.or;
			if (t.preBuy.length > 0) {
				if (t.preBuy[0] !== n.rid) return null;
				let a = null;
				if (!f) for (let t of E) {
					let s = l(t);
					if (!s.floated || s.marketLeft <= 0 || s.price === null || i.cash < s.price) continue;
					let c = o(h(t, (i.shares[t] ?? 0) + 1)) - s.price * e.buyMargin + (r.ceo[t] === n.rid ? e.ipoBonus : 0);
					c > 0 && (!a || c > a.gain) && (a = {
						c: t,
						gain: c
					});
				}
				return { action: a ? {
					type: "cardPoliBuy",
					company: a.c
				} : { type: "cardPoliSkip" } };
			}
			if (t.trade) {
				if (r.ceo[t.trade.from] !== n.rid) return null;
				let i = t.trade.from;
				if (r.ceo[t.trade.by] === n.rid) return { action: {
					type: "orTradeRespond",
					accept: !0
				} };
				let a = l(i), o = a.trains.filter((e, n) => n !== a.trains.indexOf(t.trade.train)), s = (m(i) - m(i, o)) * Math.max(1, Fn(r));
				return { action: {
					type: "orTradeRespond",
					accept: t.trade.price >= s * e.sellTrainMul
				} };
			}
			let a = t.cur < t.queue.length ? t.queue[t.cur] : null;
			if (!a || r.ceo[a] !== n.rid) return null;
			let p = l(a), g = m(a), _ = Fn(r), v = p.trains.length > 0 && p.trains.every((e) => zn(r, e)), y = r.trainPool.filter((e) => !zn(r, e)), b = y.length > 0 ? Math.min(...y.map((e) => O[e].price)) : 0;
			if (!t.trade) {
				if (d.includes("raising-funds")) return { action: {
					type: "cardAssign",
					card: "raising-funds",
					company: a
				} };
				for (let [e, t] of [["yellow-offboard", ["north", "west"]], ["blue-offboard", ["east", "sw"]]]) if (d.includes(e) && !r.cards.assigned[e] && q(s, a, p.trains, c).runs.some((e) => e.route?.stops.some((e) => e.kind === "offboard" && t.includes(e.id)))) return { action: {
					type: "cardAssign",
					card: e,
					company: a
				} };
				if (d.includes("ferry-contract") && !r.cards.assigned["ferry-contract"] && [
					"karlstad",
					"linkoping",
					"norrkoping",
					"stockholm"
				].includes(T[a].home) && (r.devPhase === "yellow" || r.devPhase === "green")) return { action: {
					type: "cardAssign",
					card: "ferry-contract",
					company: a
				} };
				if (d.includes("new-railroad") && !r.cards.assigned["new-railroad"] && r.nrc.spot !== null && (ce[r.nrc.spot] ?? []).some(([e]) => e === T[a].home)) return { action: {
					type: "cardAssign",
					card: "new-railroad",
					company: a
				} };
			}
			switch (t.step) {
				case "treasury": {
					let n = 0;
					if (p.price !== null && t.allowedTrains.length > 0) {
						let i = t.allowedTrains.filter((e) => !zn(r, e)), o = i.length > 0 ? i : t.allowedTrains, s = null;
						for (let e of o) {
							let t = m(a, [...p.trains, e]) - g;
							(!s || t > s.gain) && (s = {
								t: e,
								gain: t
							});
						}
						let c = p.trains.length === 0 || e.treasurySellGap > 0;
						if (s && c && p.treasury < O[s.t].price) {
							let t = p.trains.length === 0 && !p.homePlaced && !Rn(r, a) ? 5 : 0, i = O[s.t].price + t - p.treasury, o = p.trains.length === 0 ? p.ipoLeft : Math.min(p.ipoLeft, e.treasurySellGap);
							n = Math.min(o, Math.ceil(i / p.price));
						}
					}
					return { action: {
						type: "orSellTreasury",
						count: n
					} };
				}
				case "train": {
					if (p.trains.length < 3) {
						let n = null;
						for (let r of u) {
							if (r === a) continue;
							let i = l(r);
							if (!(i.trains.length < 2) && !t.ranCompanies.includes(r)) for (let t of i.trains) {
								let o = m(a, [...p.trains, t]) - g - (m(r) - m(r, i.trains.filter((e, n) => n !== i.trains.indexOf(t))));
								o > e.tradeMargin && (!n || o > n.net) && (n = {
									from: r,
									t,
									net: o
								});
							}
						}
						if (n) return { action: {
							type: "orTradeTrain",
							from: n.from,
							train: n.t,
							price: 1
						} };
					}
					if (p.trains.includes("T4") && r.t6Unlocked && r.trainPool.includes("T6P") && p.treasury >= 110 && (m(a, [...p.trains.filter((e) => e !== "T4"), "T6P"]) - g) * _ >= 110 * e.trainRoi && p.treasury - 110 >= e.trainKeep) return { action: { type: "orExchangeTrain" } };
					let n = t.allowedTrains.filter((e) => !zn(r, e)), i = n.length > 0 ? n : t.allowedTrains, s = null;
					for (let e of i) {
						let t = m(a, [...p.trains, e]) - g;
						(!s || t > s.gain) && (s = {
							t: e,
							gain: t
						});
					}
					if (s && p.trains.length < 3) {
						if (p.trains.length === 0) return { action: {
							type: "orBuyTrain",
							train: s.t
						} };
						let t = O[s.t].price;
						if (p.treasury >= t && p.treasury - t >= e.trainKeep && o(s.gain) * _ >= t * e.trainRoi) return { action: {
							type: "orBuyTrain",
							train: s.t
						} };
					}
					return { action: { type: "orDoneTrains" } };
				}
				case "lay": {
					if (v && p.treasury < b) return { action: { type: "orSkipLay" } };
					if (!p.homePlaced) {
						let e = null, t = -1, n = T[a].home;
						for (let i of Hn(r, s, a, /* @__PURE__ */ new Set([n]))) {
							let n = {
								...s,
								[i.hex]: {
									tile: i.tile,
									rot: i.rot,
									stations: []
								}
							}, r = p.trains.length > 0 ? q(n, a, p.trains, c).total : U[i.tile].value;
							r > t && (t = r, e = i);
						}
						return { action: e ? {
							type: "orLayTile",
							hex: e.hex,
							tile: e.tile,
							rot: e.rot,
							sponsor: !1
						} : { type: "orSkipLay" } };
					}
					if (An() > e.layProb) return { action: { type: "orSkipLay" } };
					let t = Hn(r, s, a, G(s, a, c)), n = null;
					for (let r of t) {
						let t = s[r.hex], i = {
							...s,
							[r.hex]: {
								tile: r.tile,
								rot: r.rot,
								stations: t ? t.stations : []
							}
						}, l = o(p.trains.length > 0 ? q(i, a, p.trains, c).total - g : U[r.tile].value - (t ? U[t.tile].value : 0)) * _ - r.cost * e.layCostW;
						(!n || l > n.score) && (n = {
							cand: r,
							score: l
						});
					}
					return { action: n && n.score > e.layMinGain ? {
						type: "orLayTile",
						hex: n.cand.hex,
						tile: n.cand.tile,
						rot: n.cand.rot,
						sponsor: !1
					} : { type: "orSkipLay" } };
				}
				case "station": {
					if (d.includes("central-station")) {
						let t = null;
						for (let e of F) {
							let n = s[e];
							if (!n || U[n.tile].slots === 0 || n.stations.some((e) => e.company === a) || n.stations.filter((e) => !e.central).length >= U[n.tile].slots) continue;
							let r = {
								...s,
								[e]: {
									...n,
									stations: [...n.stations, {
										company: a,
										active: !0,
										central: !0
									}]
								}
							}, i = p.trains.length > 0 ? q(r, a, p.trains, c).total - g : 0;
							(!t || i > t.gain) && (t = {
								hex: e,
								gain: i
							});
						}
						let n = null;
						for (let e of F) {
							let t = s[e];
							if (!t || U[t.tile].slots === 0 || !t.stations.some((e) => e.company === a && e.active)) continue;
							let r = p.trains.length > 0 ? q(s, a, p.trains, {
								...c,
								centralDouble: e
							}).total - g : 0;
							(!n || r > n.gain) && (n = {
								hex: e,
								gain: r
							});
						}
						let r = t ? o(t.gain) * _ : -Infinity, i = n ? (o(n.gain) - S["central-station"].income) * _ : -Infinity;
						if (t && r >= i && r > e.centralMinGain) return { action: {
							type: "cardCentral",
							hex: t.hex,
							face: "black"
						} };
						if (n && i > e.centralMinGain) return { action: {
							type: "cardCentral",
							hex: n.hex,
							face: "white"
						} };
					}
					if (p.extraStationUsed) return { action: { type: "orSkipStation" } };
					let t = Rn(r, a) ? 5 : 10;
					if (p.treasury < t || v && p.treasury - t < b) return { action: { type: "orSkipStation" } };
					let n = G(s, a, c), i = null;
					for (let e of F) {
						if (!n.has(e)) continue;
						let r = s[e];
						if (!r || U[r.tile].slots === 0 || r.stations.some((e) => e.company === a) || r.stations.filter((e) => !e.central).length >= U[r.tile].slots) continue;
						let l = {
							...s,
							[e]: {
								...r,
								stations: [...r.stations, {
									company: a,
									active: !0
								}]
							}
						}, u = o(p.trains.length > 0 ? q(l, a, p.trains, c).total - g : U[r.tile].value) * _ - t;
						(!i || u > i.score) && (i = {
							hex: e,
							score: u
						});
					}
					return { action: i && i.score > e.stationMinGain ? {
						type: "orPlaceStation",
						hex: i.hex,
						sponsor: !1
					} : { type: "orSkipStation" } };
				}
				case "run": return { action: { type: "orRunTrains" } };
				case "pay": {
					let n = t.lastRun?.total ?? 0, o = i.shares[a] ?? 0;
					if (Pn(r) === 0) return { action: {
						type: "orDividend",
						mode: "payout"
					} };
					if (v && p.treasury < b) return { action: {
						type: "orDividend",
						mode: "withhold"
					} };
					let s = 0;
					if (p.trains.length < 3 && t.allowedTrains.length > 0) {
						let e = null;
						for (let n of t.allowedTrains) {
							let t = m(a, [...p.trains, n]) - g;
							(!e || t > e.gain) && (e = {
								t: n,
								gain: t
							});
						}
						e && e.gain > 0 && (s = O[e.t].price);
					}
					let c = s - p.treasury;
					if (s > 0 && c > 0 && p.treasury + n >= s) {
						if (d.includes("financial-planning")) {
							let e = Math.floor((n - c) / 5) * 5;
							if (e > 0 && e < n) return { action: {
								type: "orDividend",
								mode: "split",
								amount: e
							} };
						}
						return { action: {
							type: "orDividend",
							mode: "withhold"
						} };
					}
					return { action: {
						type: "orDividend",
						mode: o >= e.payoutShareMin ? "payout" : "withhold"
					} };
				}
			}
		}
		return null;
	};
}
var Gn = Wn(kn), Kn = (e, t, n) => {
	switch (e.type) {
		case "dscAssign": return n("games.svea.hintDscAssign", { company: e.company });
		case "srSell": return n("games.svea.hintSrSell", {
			company: e.sales.map((e) => e.company).join("/"),
			n: e.sales.reduce((e, t) => e + t.count, 0)
		});
		case "srBuy": return e.par ? n("games.svea.hintSrFloat", {
			company: e.company,
			par: e.par
		}) : n(e.from === "ipo" ? "games.svea.hintSrBuyIpo" : "games.svea.hintSrBuyMarket", { company: e.company });
		case "srPass": return n("games.svea.hintSrPass");
		case "orSellTreasury": return n("games.svea.hintOrSellTreasury", { n: e.count });
		case "orBuyTrain": return n("games.svea.hintOrBuyTrain", { train: e.train });
		case "orExchangeTrain": return n("games.svea.hintOrExchange");
		case "orTradeTrain": return n("games.svea.hintOrTrade", {
			from: e.from,
			train: e.train,
			price: e.price
		});
		case "orTradeRespond": return n(e.accept ? "games.svea.hintOrDoneTrains" : "games.svea.hintSrPass");
		case "orDoneTrains": return n("games.svea.hintOrDoneTrains");
		case "orLayTile": return n("games.svea.hintOrLay");
		case "orSkipLay": return n("games.svea.hintOrSkipLay");
		case "orPlaceStation": return n("games.svea.hintOrStation");
		case "orSkipStation": return n("games.svea.hintOrSkipStation");
		case "orRunTrains": return n("games.svea.hintOrRun");
		case "orDividend": return e.mode === "split" ? n("games.svea.hintOrSplit", { amount: e.amount ?? 0 }) : n(e.mode === "payout" ? "games.svea.hintOrPayout" : "games.svea.hintOrWithhold");
		case "cardAssign": return n("games.svea.hintCardAssign", { card: e.card });
		case "cardCentral": return n("games.svea.hintCardCentral", { face: e.face });
		case "cardPoliBuy": return n("games.svea.hintPoliBuy", { company: e.company });
		case "cardPoliSkip": return n("games.svea.hintPoliSkip");
		case "scaBid": return n("games.svea.hintScaBid", { amount: e.amount });
		case "scaSwap": return n("games.svea.hintScaSwap", { card: e.take ?? "-" });
	}
};
//#endregion
//#region src/games/svea/endgame-review.tsx
function qn({ board: e, renderResult: t, ...n }) {
	let i = r(), [a, o] = d(!0), [s, f] = d(null), p = u(null), _ = u(null), b = u(null);
	c(() => {
		if (!s) return;
		b.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [s]);
	let x = (e) => {
		f(null), o(e), requestAnimationFrame(() => (e ? p : _).current?.focus({ preventScroll: !0 }));
	}, S = l(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...S
	};
	return /* @__PURE__ */ h("div", {
		className: "svea-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ m("div", {
				className: "svea-endgame-board",
				inert: a,
				children: e
			}),
			/* @__PURE__ */ m("div", {
				className: "svea-endgame-overlay",
				hidden: !a,
				children: /* @__PURE__ */ h("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "svea-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ h("header", {
							className: "svea-endgame-heading",
							children: [/* @__PURE__ */ h("div", {
								className: "svea-endgame-brand",
								children: [/* @__PURE__ */ m("span", {
									"aria-hidden": "true",
									children: he.icon
								}), i(he.nameKey)]
							}), /* @__PURE__ */ m("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": i("games.svea.reviewHide"),
								title: i("games.svea.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ m(v, { size: 19 })
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "svea-endgame-result",
							inert: s !== null,
							children: t(C)
						}),
						s && /* @__PURE__ */ h("div", {
							className: "svea-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ m("button", {
								type: "button",
								ref: b,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = s.run;
									f(null), e();
								},
								children: i(s.label === "again" ? "games.svea.reviewConfirmAgain" : "games.svea.reviewConfirmLobby")
							}), /* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: i("games.svea.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "svea-endgame-toolbar",
				hidden: a,
				children: /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ m(y, { size: 18 }),
						i("games.svea.reviewShow"),
						/* @__PURE__ */ m(g, { size: 18 })
					]
				})
			})
		]
	});
}
function Jn({ result: e, members: t, myRid: i, hintCount: o, onPlayAgain: c, onBackToLobby: l, rows: u, renderRowExtra: f, summary: g, navigation: y, content: x, afterRanking: S, scoreUnit: C, rankOf: ee }) {
	let w = r(), te = n((e) => e.locale), [T, E] = d({}), ne = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? a(n, te) : e;
	}, D = (t, n) => ee?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), O = e.ranking.some((t) => e.scores?.[t] !== void 0), k = (t, n) => /* @__PURE__ */ h("div", {
		className: "svea-score-identity",
		children: [
			/* @__PURE__ */ h("span", {
				className: "svea-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ m("span", {
					"aria-label": w("games.svea.reviewWinner"),
					children: "♛ "
				}), O && D(t, n)]
			}),
			/* @__PURE__ */ h("span", {
				className: "svea-score-name",
				children: [ne(t), t === i && /* @__PURE__ */ m("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ h("small", {
				className: "svea-score-autopilot",
				children: [
					/* @__PURE__ */ m(_, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), A = (t) => e.ranking.map((n) => /* @__PURE__ */ m("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ h("div", {
		className: "svea-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ m(b, {}),
			y,
			/* @__PURE__ */ h("div", {
				className: "svea-score-body",
				children: [
					g && /* @__PURE__ */ m("div", {
						className: "svea-score-summary",
						children: g
					}),
					o !== void 0 && /* @__PURE__ */ m("p", {
						className: "svea-score-hints",
						children: w("session.hint.usedCount", { n: o })
					}),
					x ?? (u?.length ? /* @__PURE__ */ m("div", {
						className: "svea-score-table-scroll",
						children: /* @__PURE__ */ h("table", {
							className: "svea-score-table",
							"aria-label": w(he.nameKey),
							children: [
								/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { scope: "col" }), /* @__PURE__ */ m(p, { children: e.ranking.map((t, n) => /* @__PURE__ */ m("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: k(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ m("tbody", { children: u.map((e, t) => /* @__PURE__ */ h(s, { children: [/* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ h("button", {
										type: "button",
										"aria-expanded": !!T[t],
										onClick: () => E((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ m(v, { size: 15 }), e.label]
									}) : e.label
								}), A(e)] }), T[t] && e.details?.map((e, t) => /* @__PURE__ */ h("tr", {
									className: "svea-score-sub",
									children: [/* @__PURE__ */ m("th", {
										scope: "row",
										children: e.label
									}), A(e)]
								}, t))] }, t)) }),
								O && /* @__PURE__ */ m("tfoot", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: w("games.svea.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ m("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ m("ol", {
						className: "svea-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ h("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ h("div", {
								className: "svea-score-rankline",
								children: [k(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ h("strong", {
									className: "svea-score-points",
									children: [e.scores[t], C && /* @__PURE__ */ m("small", { children: C })]
								})]
							}), f?.(t)]
						}, t))
					})),
					S,
					!!u?.length && f && /* @__PURE__ */ m("div", {
						className: "svea-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ h("details", { children: [/* @__PURE__ */ m("summary", { children: ne(e) }), f(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ h("footer", {
				className: "svea-score-actions",
				children: [
					l && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: w("session.result.backToLobby")
					}),
					c && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base",
						onClick: c,
						children: w("session.result.playAgain")
					}),
					!c && !l && /* @__PURE__ */ m("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/svea/endgame-scores.tsx
function Yn(e) {
	let t = r(), n = e.public, i = (e) => {
		let t = n.players.find((t) => t.rid === e);
		return t ? [t.cash, n.companies.reduce((e, n) => e + (t.shares[n.id] ?? 0) * (n.price ?? 0), 0)] : [];
	}, a = ["games.svea.scoreCash", "games.svea.scoreShares"].map((e, n) => ({
		label: t(e),
		value: (e) => i(e)[n] ?? "—"
	}));
	return /* @__PURE__ */ m(Jn, {
		...e,
		renderRowExtra: void 0,
		rows: a
	});
}
//#endregion
//#region src/games/svea/game-over.tsx
function Xn(e) {
	return /* @__PURE__ */ m(Yn, { ...e });
}
function Zn(e) {
	return /* @__PURE__ */ m(qn, {
		...e,
		board: /* @__PURE__ */ m(Dn, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ m(Xn, { ...e })
	});
}
//#endregion
//#region src/games/svea/game-over-row.tsx
function Qn({ public: e, rid: t }) {
	let n = r(), i = e, a = i.players.find((e) => e.rid === t);
	if (!a) return null;
	let o = i.companies.reduce((e, t) => e + (a.shares[t.id] ?? 0) * (t.price ?? 0), 0), s = a.cash + o;
	return /* @__PURE__ */ h("div", {
		className: "svea-score-ledger",
		children: [
			/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("small", { children: n("games.svea.scoreCash") }), /* @__PURE__ */ m("b", { children: a.cash })] }),
			/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("small", { children: n("games.svea.scoreShares") }), /* @__PURE__ */ m("b", { children: o })] }),
			/* @__PURE__ */ h("span", {
				className: "svea-score-ledger__total",
				children: [/* @__PURE__ */ m("small", { children: n("games.svea.scoreTotal") }), /* @__PURE__ */ m("b", { children: s })]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/svea/entry.tsx
var $n = {
	definition: Ht,
	View: Dn,
	bot: Gn,
	describe: Kn,
	OverView: Zn,
	RowView: Qn,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "18Svea",
			desc: "瑞典迷你 18XX:炒股、铺轨、跑火车,2-3 人的紧凑经济博弈",
			rules: "目标：\n游戏结束时，总资产最高的玩家获胜。总资产为现金，加上所持各家公司股份按当前股价计算的价值。\n准备：\n· 2人游戏中，每名玩家获得金额为120的初始资金；3人游戏中，每名玩家获得金额为80的初始资金。\n· 将12张策略卡洗混。2人游戏中，每人获得3张；3人游戏中，每人获得2张。\n· “迟延许可”的持有者立即指定并锁定一家公司，该公司在第2个股票轮开始前不能启动。\n回合顺序：\n股票轮简称SR，运营轮简称OR。整局按以下顺序进行：\n· 进行第1个股票轮，再进行第1个和第2个运营轮。\n· 进行第2个股票轮，再进行第3个运营轮。\n· 举行策略卡拍卖，再进行第4个运营轮。\n· 进行第3个股票轮，再进行第5个和第6个运营轮。\n· 进行第4个股票轮，再进行第7个运营轮。\n股票轮：\n· 首先按持股数量缴税。对同一公司持有3股、4股或5股时，分别缴纳金额为10、20或30的税款。\n· 根据策略卡的优先级，确定本轮的玩家行动顺序。\n· 轮到你时，先卖出股票，再决定是否买入。你可以卖出任意数量的股票；每卖出1股，该公司的股价下降1格。CEO股份不能卖出。\n· 然后可以买入1股，也可以放弃买入。从首次公开发行区（IPO）买入时，将资金支付给公司金库；从公开市场买入时，将资金支付给银行。\n· 本轮已经卖出某公司的股票后，不能再买入该公司的股票。所有玩家连续放弃行动后，股票轮结束；股份全部售出的公司，其股价上升1格。\n· 启动新公司时，购买其CEO股份，并从25、30、35、40中选择一个初始股价。持有的股份数量超过现任CEO时，立即接任CEO。\n运营轮：\n先向玩家支付策略卡提供的收入，再让各家公司按股价从高到低的顺序运营。每家公司依次执行以下步骤：\n· 第一步，可以出售库藏股来筹集资金。每股按当前股价出售，所得资金进入公司金库；每出售1股，该公司的股价下降1格。\n· 第二步，购买列车。没有列车的公司必须购买列车。公司金库不足以支付费用时，先出售库藏股筹资，再由CEO以个人资金补足差额；CEO仍无法补足时，公司破产，游戏立即结束。\n· 第三步，铺设或升级一块板块。城市板块的费用为5，黑色板块的费用为10；每跨越一条水域，额外支付金额为5的费用。\n· 第四步，可以支付金额为10的费用，放置一座额外车站。\n· 第五步，让公司的列车按收入最高的合法路线运行，并计算总收入。\n· 第六步，选择向股东分红，或将全部收入留在公司金库。分红时，每股获得总收入的五分之一；首次公开发行区中的股份，其分红进入公司金库。\n· 分红总额达到当前股价的2倍时，股价向右移动2格；未达到时，向右移动1格。将全部收入留在公司金库时，股价向左移动1格。\n列车与阶段：\n· 列车依次解锁：先是T2列车，再是T3列车、T4列车，最后是T6和T6+S列车。每家公司最多拥有3辆列车。\n· 首次购买T4列车时，所有T2列车报废，游戏进入棕色阶段。首次购买T6列车时，所有T3列车报废，游戏进入灰色阶段。\n· T6+S列车运行时，路线中第一个车站和最后一个车站的收入翻倍。购买T6+S列车后，游戏进入黑色阶段。\n· 随着游戏阶段推进，依次解锁黄色、绿色、棕色和灰色板块。黑色板块可以直接铺设。\n· 公司之间可以协商价格出售列车，但成交价格不能低于1。\n策略卡拍卖：\n第3个运营轮结束后，举行策略卡拍卖。\n· 收回全部12张策略卡，公开移除其中6张，再将剩余6张逐张进行秘密竞价拍卖。\n· 出价不能超过自己的现金。最高出价相同时，并列玩家在原出价基础上追加出价，重新竞拍；再次平手时，移除该卡。\n· 2人游戏中，每名玩家最多竞得3张策略卡；3人游戏中，每名玩家最多竞得2张。最后一名仍有资格竞拍的玩家，免费获得所有剩余卡牌。\n终局：\n· 任一公司股价达到130时，在当前轮结束后进行终局结算。\n· 否则，在第7个运营轮结束后进行终局结算。\n· 任一公司破产时，立即进行终局结算。",
			phaseDsc: "发车仪式",
			phaseSr: "股票轮",
			phaseOr: "运营轮",
			phaseSca: "策略卡拍卖",
			phaseDone: "已结束",
			railwayCompany: "瑞典铁路公司",
			round: "回合",
			surfaceBoard: "铁路地图",
			surfaceMarket: "股票市场",
			surfaceCards: "策略票券",
			tileYard: "板块场",
			chooseRotateLay: "选板 / 旋转 / 铺设",
			rotate: "旋转",
			layTile: "铺设板块",
			legal: "合法",
			legalChoose: "选择地图格",
			legalNone: "当前无合法落点",
			legalSites: "{{n}} 处可铺",
			legalUpgrade: "升级",
			legalPlace: "铺设",
			lockedPool: "库存 0",
			lockedPhase: "阶段未到",
			lockedHex: "此格不可铺",
			devPhase: "{{phase}}阶段",
			devYellow: "黄",
			devGreen: "绿",
			devBrown: "棕",
			devGrey: "灰",
			devBlack: "黑",
			companyS: "斯德哥尔摩",
			companyO: "厄勒布鲁",
			companyN: "北雪平",
			companyJ: "延雪平",
			companyG: "哥德堡",
			ceoBadge: "CEO",
			floated: "已上市",
			unfloated: "未上市",
			hexKarlstad: "卡尔斯塔德",
			hexOrebro: "厄勒布鲁",
			hexVasteras: "韦斯特罗斯",
			hexGoteborg: "哥德堡",
			hexLake: "大湖",
			hexNorrkoping: "北雪平",
			hexStockholm: "斯德哥尔摩",
			hexJonkoping: "延雪平",
			hexLinkoping: "林雪平",
			hexBay: "海湾",
			hexPaleA: "北原",
			hexPaleB: "东北原",
			offNorth: "北离岸",
			offWest: "西离岸",
			offEast: "东离岸",
			offSw: "西南离岸",
			offSe: "东南离岸",
			stub: "新铁路 {{n}}",
			cash: "现金",
			treasury: "金库",
			price: "股价",
			par: "起价",
			shares: "持股",
			trainsLabel: "列车",
			ipo: "IPO",
			market: "公开市场",
			income: "收入",
			total: "总计",
			free: "免费",
			tabBoard: "版图",
			tabMarket: "股市",
			tabCards: "策略卡",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			zoomReset: "回到全图",
			confirm: "确认",
			cancel: "取消",
			skip: "跳过",
			cardCentralStation: "中央车站",
			cardCityStationOwner: "城市站主",
			cardInfrastructurePush: "基建推进",
			cardPoliticalInfluence: "政治影响",
			cardFerryContract: "渡口合同",
			cardFinancialPlanning: "财务规划",
			cardYellowOffboard: "黄色离岸合同",
			cardBlueOffboard: "蓝色离岸合同",
			cardNewRailroad: "新铁路连接",
			cardTaxHaven: "避税港",
			cardRaisingFunds: "融资",
			cardDelayedPermit: "迟延许可",
			cardDescCentralStation: "放中央站 token:白面 = 该格站加成翻倍;黑面 = 本公司一个额外站",
			cardDescCityStationOwner: "随机一座城市放置标记;指派给本公司后,其他公司的列车每次停靠该城,须向本公司支付 5",
			cardDescInfrastructurePush: "CEO 回合多铺/升级一块板块",
			cardDescPoliticalInfluence: "① 本公司免板块费与水费,放车站只花 5;或 ② 计算收入前弃掉本卡,从公开市场买 1 股",
			cardDescFerryContract: "本公司每新建一条跨水连接从银行得 15",
			cardDescFinancialPlanning: "分红可自定 0 到总收入间任意 5 的倍数",
			cardDescYellowOffboard: "本公司经北/西离岸的路线 +10",
			cardDescBlueOffboard: "本公司经东/西南离岸的路线 +10",
			cardDescNewRailroad: "放一个离岸收入条;拍卖版另使本公司停靠 +10",
			cardDescTaxHaven: "持股税降为 0/0/0/0/5/10",
			cardDescRaisingFunds: "注资一家公司:发卡版 25、拍卖版 40;已上市立即进金库,未上市则待其上市时兑现,挂起注资分别在 OR3 末/OR7 末作废",
			cardDescDelayedPermit: "发卡版:锁定一家公司到 SR2;拍卖版:可换回一张被移除的卡",
			cardUsed: "已用",
			cardRemoved: "已移除",
			cardIncomeLabel: "+{{n}}/OR",
			cardPriority: "优先级 {{n}}",
			cardUse: "发动",
			cardAssignTo: "指派给…",
			cardWhiteFace: "白面(站加成翻倍)",
			cardBlackFace: "黑面(额外站)",
			dscPrompt: "迟延许可:选择一家 SR2 前不可启动的公司",
			dscLock: "锁定",
			srPrompt: "轮到你:可先卖股,再买 1 股或过",
			srWait: "等待 {{name}} 行动",
			srSell: "卖股",
			srBuy: "买 1 股",
			srPass: "过",
			srFloat: "启动公司(买 CEO 股)",
			srPickPar: "选择起价",
			srFromIpo: "IPO(钱进公司)",
			srFromMarket: "公开市场(钱进银行)",
			srSoldBlocked: "本轮已卖过,不可买回",
			srTaxNote: "本轮已收持股税",
			srEndNote: "全售公司股价 +1",
			orStepTreasury: "库藏股",
			orStepTrain: "买列车",
			orStepLay: "铺板块",
			orStepStation: "放车站",
			orStepRun: "跑火车",
			orStepPay: "分红",
			orSellTreasury: "卖库藏股",
			orSellTreasuryNote: "每股现价进金库,股价每股降 1 格",
			orNoSell: "不卖,继续",
			orBuyTrain: "购买",
			orExchangeTrain: "T4 +110 换 T6+S",
			orTradeTrain: "向其他公司购车",
			orDoneTrains: "完成购车",
			orForced: "公司无列车,必须购买(自动卖库藏股+CEO 补差额,补不起即破产)",
			orTrainStops: "{{n}} 站",
			orTrainPrice: "{{n}}",
			orLayPrompt: "选择格子、板块与朝向",
			layCost: "费用 {{n}}",
			waterLinks: "跨水 {{n}} 条",
			orExtraLay: "基建推进:可再铺一块",
			orStationPrompt: "选择放站的城市(10)",
			orRunTrains: "跑火车(自动最优)",
			orRunResult: "跑车收入",
			orPayout: "分红",
			orWithhold: "留存",
			orSplit: "自定分红",
			orSplitAmount: "分红额(5 的倍数)",
			orMoveRight2: "股价 →→ 2 格",
			orMoveRight1: "股价 → 1 格",
			orMoveLeft1: "股价 ← 1 格",
			sponsor: "私人赞助(双倍价)",
			sponsorNote: "金库不足时 CEO 可私人出资,板块双倍价",
			tradePrompt: "{{company}} 出价 {{price}} 购买你的 {{train}}",
			tradeAccept: "接受",
			tradeReject: "拒绝",
			tradeWait: "等待 {{name}} 回应交易",
			poliPrompt: "政治影响:弃卡从公开市场立即买 1 股?",
			poliSkip: "不用",
			tiredNote: "本 OR 买入的已跑车不可再跑",
			scaPrompt: "暗标出价(现金封顶)",
			scaCurrent: "当前拍品",
			scaLeft: "剩余 {{n}} 张",
			scaBidSubmit: "提交出价",
			scaBidDone: "已出价 {{n}},等待其他玩家",
			scaRebid: "平手!累加你的出价重拍",
			scaWon: "已拍得",
			scaRemovedLabel: "移除公示",
			scaSwapPrompt: "迟延许可:可换回一张被移除的卡",
			scaSwapSkip: "不换",
			scaFreeNote: "你是唯一未满额者,免费拿完剩余卡",
			scoreCash: "现金",
			scoreShares: "股票价值",
			scoreTotal: "总资产",
			endPrice130: "股价抵达 130,本轮结束后结算",
			endBankrupt: "公司破产,立即结算",
			endComplete: "第七运营轮结束",
			errBadPhase: "当前阶段不能这么做",
			errNotYourTurn: "还没轮到你",
			errNotCeo: "只有该公司 CEO 能操作",
			errNoSuchCompany: "没有这家公司",
			errNotFloated: "公司尚未上市",
			errNotSellable: "这些股不能卖(CEO 股不可卖)",
			errSoldThisSr: "本轮卖过该公司,不可买回",
			errCertLimit: "超出持股上限",
			errNoShares: "该来源没有可买的股",
			errLocked: "该公司被迟延许可锁定",
			errBadPar: "起价不合法",
			errNotEnoughCash: "现金不足",
			errNotBidder: "你不能参与本次竞拍",
			errBidTooHigh: "出价超过现金",
			errBadSwap: "不能换这张卡",
			errTradePending: "有交易等待回应",
			errBadCard: "这张卡不能这么用",
			errCardNotUsable: "这张卡现在不可用",
			errBadHex: "这个格子不行",
			errBadTile: "这块板块不符合升级链",
			errBadRot: "该朝向的轨道接不上既有轨道",
			errTileUnavailable: "板块池里没有这块",
			errNotReachable: "从你的车站连通不到这里",
			errNoSlot: "没有空站槽",
			errHasStation: "本公司在此已有车站",
			errNoExtraStation: "本公司的额外车站已用过",
			errBadTrain: "这辆列车现在买不了",
			errTrainLimit: "公司最多 3 辆列车",
			errMustBuyTrain: "公司没有列车,必须先买",
			errBadDividend: "分红额不合法(须为 5 的倍数且不超过总收入)",
			hintDscAssign: "锁定 {{company}}",
			hintSrSell: "卖出 {{company}} ×{{n}}",
			hintSrBuyIpo: "从 IPO 买入 {{company}}",
			hintSrBuyMarket: "从公开市场买入 {{company}}",
			hintSrFloat: "以 {{par}} 启动 {{company}}",
			hintSrPass: "过",
			hintOrSellTreasury: "卖库藏股 ×{{n}}",
			hintOrBuyTrain: "购买 {{train}}",
			hintOrExchange: "T4 换购 T6+S",
			hintOrTrade: "向 {{from}} 购 {{train}}({{price}})",
			hintOrDoneTrains: "完成购车",
			hintOrLay: "铺板块",
			hintOrSkipLay: "跳过铺板块",
			hintOrStation: "放车站",
			hintOrSkipStation: "跳过放站",
			hintOrRun: "跑火车",
			hintOrPayout: "分红",
			hintOrWithhold: "留存",
			hintOrSplit: "分红 {{amount}}",
			hintCardAssign: "发动 {{card}}",
			hintCardCentral: "放中央站({{face}}面)",
			hintPoliBuy: "弃政治影响买 {{company}}",
			hintPoliSkip: "放弃政治影响购买",
			hintScaBid: "暗标 {{amount}}",
			hintScaSwap: "换回 {{card}}"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "18Svea",
			desc: "A micro 18XX in Sweden: stocks, track and trains for 2-3 players",
			rules: "Goal:\nThe player with the highest total assets at the end wins. Add your cash to the value of your shares in each company, using its current share price.\nSetup:\n· Each player receives starting cash of 120 in a 2-player game, or 80 in a 3-player game.\n· Shuffle all 12 strategy cards. Deal 3 to each player in a 2-player game, or 2 to each in a 3-player game.\n· The Delayed Permit holder immediately chooses and locks one company. That company cannot be floated before the second Stock Round begins.\nRound sequence:\nA Stock Round is abbreviated SR, and an Operating Round is abbreviated OR. Play in this order:\n· Play the first Stock Round, followed by the first and second Operating Rounds.\n· Play the second Stock Round, followed by the third Operating Round.\n· Hold the strategy-card auction, followed by the fourth Operating Round.\n· Play the third Stock Round, followed by the fifth and sixth Operating Rounds.\n· Play the fourth Stock Round, followed by the seventh Operating Round.\nStock Rounds:\n· First pay holding tax for each company. Holding 3, 4 or 5 shares in one company requires a payment of 10, 20 or 30 respectively.\n· Determine player order using strategy-card priority.\n· On your turn, sell shares before deciding whether to buy. You may sell any number of shares. Each share sold lowers that company’s share price by 1 space. The CEO share cannot be sold.\n· Then buy 1 share or pass. A purchase from the initial public offering area (IPO) pays the company treasury; a purchase from the public market pays the bank.\n· You cannot buy shares in a company whose shares you sold earlier in the same Stock Round. The round ends when all players pass consecutively. Each fully sold-out company raises its share price by 1 space.\n· To float a company, buy its CEO share and choose a par price of 25, 30, 35 or 40. If you hold more shares than the current CEO, you become the new CEO.\nOperating Rounds:\nFirst pay strategy-card income to players. Then each company operates in descending share-price order, completing these steps:\n· Step 1: You may sell treasury shares to raise funds. Each share sells at the current price and pays the company treasury; each sale lowers its share price by 1 space.\n· Step 2: Buy trains. A company without a train must buy one. If its treasury cannot pay, first sell treasury shares, then have its CEO pay the remaining amount from personal cash. If the CEO cannot cover the difference, the company goes bankrupt and the game ends immediately.\n· Step 3: Lay or upgrade one tile. A city tile costs 5 and a black tile costs 10. Pay an additional 5 for each new water crossing.\n· Step 4: You may pay 10 to place one additional station.\n· Step 5: Run the company’s trains along the legal routes that provide the highest revenue, then calculate their total revenue.\n· Step 6: Pay dividends to shareholders or retain all revenue in the company treasury. Each share receives one fifth of the total revenue when paying dividends. Dividends for IPO shares go to the company treasury.\n· If the total dividend is at least twice the current share price, move the share price 2 spaces to the right; otherwise move it 1 space to the right. Retaining all revenue moves it 1 space to the left.\nTrains and phases:\n· Unlock trains in this order: T2, then T3, then T4, and finally T6 and T6+S. Each company may own at most 3 trains.\n· Buying the first T4 train rusts all T2 trains and begins the brown phase. Buying the first T6 train rusts all T3 trains and begins the grey phase.\n· A T6+S train doubles the revenue of the first and last stations on its route. Buying a T6+S train begins the black phase.\n· Yellow, green, brown and grey tiles become available as the phases advance, in that order. Black tiles may be laid directly.\n· Companies may negotiate train sales between themselves, at a price of at least 1.\nStrategy-card auction:\nHold the auction after the third Operating Round.\n· Collect all 12 strategy cards and publicly remove 6. Auction the remaining 6 one at a time using sealed bids.\n· Your bid cannot exceed your cash. Tied highest bidders add to their previous bids and bid again. Remove the card if the second bidding round is also tied.\n· Each player may win at most 3 strategy cards in a 2-player game, or 2 in a 3-player game. The last player still eligible to bid receives all remaining cards for free.\nGame end:\n· If any company reaches a share price of 130, score the game at the end of the current round.\n· Otherwise, score the game after the seventh Operating Round.\n· If any company goes bankrupt, score the game immediately.",
			phaseDsc: "Deal & Setup",
			phaseSr: "Stock Round",
			phaseOr: "Operating Round",
			phaseSca: "Card Auction",
			phaseDone: "Finished",
			railwayCompany: "Railway Company",
			round: "Round",
			surfaceBoard: "Rail Map",
			surfaceMarket: "Stock Mkt",
			surfaceCards: "Card Deck",
			tileYard: "Tile Yard",
			chooseRotateLay: "Choose / rotate / lay",
			rotate: "Rotate",
			layTile: "Lay Tile",
			legal: "Legal",
			legalChoose: "Choose a hex",
			legalNone: "No legal site now",
			legalSites: "{{n}} legal sites",
			legalUpgrade: "Upgrade",
			legalPlace: "Place",
			lockedPool: "Stock 0",
			lockedPhase: "Later era",
			lockedHex: "Not for hex",
			devPhase: "{{phase}} phase",
			devYellow: "Yellow",
			devGreen: "Green",
			devBrown: "Brown",
			devGrey: "Grey",
			devBlack: "Black",
			companyS: "Stockholm",
			companyO: "Örebro",
			companyN: "Norrköping",
			companyJ: "Jönköping",
			companyG: "Göteborg",
			ceoBadge: "CEO",
			floated: "Floated",
			unfloated: "Not floated",
			hexKarlstad: "Karlstad",
			hexOrebro: "Örebro",
			hexVasteras: "Västerås",
			hexGoteborg: "Göteborg",
			hexLake: "Lake",
			hexNorrkoping: "Norrköping",
			hexStockholm: "Stockholm",
			hexJonkoping: "Jönköping",
			hexLinkoping: "Linköping",
			hexBay: "Bay",
			hexPaleA: "N. Moor",
			hexPaleB: "NE Moor",
			offNorth: "North",
			offWest: "West",
			offEast: "East",
			offSw: "Southwest",
			offSe: "Southeast",
			stub: "NRC {{n}}",
			cash: "Cash",
			treasury: "Treasury",
			price: "Price",
			par: "Par",
			shares: "Shares",
			trainsLabel: "Trains",
			ipo: "IPO",
			market: "Market",
			income: "Income",
			total: "Total",
			free: "Free",
			tabBoard: "Map",
			tabMarket: "Market",
			tabCards: "Cards",
			zoomIn: "Zoom in on map",
			zoomOut: "Zoom out of map",
			zoomReset: "Show full map",
			confirm: "Confirm",
			cancel: "Cancel",
			skip: "Skip",
			cardCentralStation: "Central Station",
			cardCityStationOwner: "City Station Owner",
			cardInfrastructurePush: "Infrastructure Push",
			cardPoliticalInfluence: "Political Influence",
			cardFerryContract: "Ferry Contract",
			cardFinancialPlanning: "Financial Planning",
			cardYellowOffboard: "Yellow Off-board Contract",
			cardBlueOffboard: "Blue Off-board Contract",
			cardNewRailroad: "New Railroad Connection",
			cardTaxHaven: "Tax Haven",
			cardRaisingFunds: "Raising Funds",
			cardDelayedPermit: "Delayed Permit",
			cardDescCentralStation: "Place the Central station token: white = double station bonus on that tile; black = one extra station for your company",
			cardDescCityStationOwner: "A random city gets the marker; once assigned to your company, other companies pay it 5 each time one of their trains stops there",
			cardDescInfrastructurePush: "Lay or upgrade one additional tile on your CEO turn",
			cardDescPoliticalInfluence: "① Your company ignores tile and water costs and places stations for 5; or ② discard before income to buy 1 share from the open market",
			cardDescFerryContract: "Your company gains 15 from the bank per new water connection",
			cardDescFinancialPlanning: "Pay any multiple of 5 between 0 and the total as dividends",
			cardDescYellowOffboard: "+10 for your routes via the north/west off-boards",
			cardDescBlueOffboard: "+10 for your routes via the east/southwest off-boards",
			cardDescNewRailroad: "Place an off-board revenue bar; the auction version also gives your trains +10 when stopping there",
			cardDescTaxHaven: "Holding tax drops to 0/0/0/0/5/10",
			cardDescRaisingFunds: "Inject 25 (dealt version) or 40 (auction version) into a company: paid into the treasury at once if floated, otherwise held until flotation; a held injection lapses at the end of OR3 (dealt) / OR7 (auction)",
			cardDescDelayedPermit: "Dealt version: lock a company until SR2; auction version: swap for a removed card",
			cardUsed: "Used",
			cardRemoved: "Removed",
			cardIncomeLabel: "+{{n}}/OR",
			cardPriority: "Priority {{n}}",
			cardUse: "Use",
			cardAssignTo: "Assign to…",
			cardWhiteFace: "White (double bonus)",
			cardBlackFace: "Black (extra station)",
			dscPrompt: "Delayed Permit: choose a company that cannot be floated before SR2",
			dscLock: "Lock",
			srPrompt: "Sell · buy · pass",
			srWait: "Waiting for {{name}}",
			srSell: "Sell",
			srBuy: "Buy 1 share",
			srPass: "Pass",
			srFloat: "Float (buy CEO share)",
			srPickPar: "Choose par price",
			srFromIpo: "IPO (pays company)",
			srFromMarket: "Market (pays bank)",
			srSoldBlocked: "Sold this round, no buy-back",
			srTaxNote: "Holding tax collected",
			srEndNote: "1 share max · sold-out +1",
			orStepTreasury: "Treasury",
			orStepTrain: "Trains",
			orStepLay: "Track",
			orStepStation: "Station",
			orStepRun: "Run",
			orStepPay: "Dividend",
			orSellTreasury: "Sell treasury shares",
			orSellTreasuryNote: "Each sold at current price into treasury, price drops 1 per share",
			orNoSell: "No sale, continue",
			orBuyTrain: "Buy",
			orExchangeTrain: "T4 +110 → T6+S",
			orTradeTrain: "Buy from a company",
			orDoneTrains: "Done with trains",
			orForced: "No trains: must buy (auto-sells treasury shares, CEO pays the difference — bankruptcy ends the game)",
			orTrainStops: "{{n}} stops",
			orTrainPrice: "{{n}}",
			orLayPrompt: "Pick a hex, tile and rotation",
			layCost: "Cost {{n}}",
			waterLinks: "{{n}} water links",
			orExtraLay: "Infrastructure Push: lay one more tile",
			orStationPrompt: "Pick a city for your station (10)",
			orRunTrains: "Run trains (auto-optimal)",
			orRunResult: "Run revenue",
			orPayout: "Pay out",
			orWithhold: "Withhold",
			orSplit: "Custom split",
			orSplitAmount: "Amount (multiple of 5)",
			orMoveRight2: "Price →→ 2 steps",
			orMoveRight1: "Price → 1 step",
			orMoveLeft1: "Price ← 1 step",
			sponsor: "Sponsor (double price)",
			sponsorNote: "The CEO may pay privately at double tile cost when the treasury is short",
			tradePrompt: "{{company}} offers {{price}} for your {{train}}",
			tradeAccept: "Accept",
			tradeReject: "Reject",
			tradeWait: "Waiting for {{name}} to answer the trade",
			poliPrompt: "Political Influence: discard to buy 1 market share now?",
			poliSkip: "Skip",
			tiredNote: "Trains bought from an already-run company cannot run this OR",
			scaPrompt: "Sealed bid (capped by cash)",
			scaCurrent: "Now auctioning",
			scaLeft: "{{n}} left",
			scaBidSubmit: "Submit bid",
			scaBidDone: "Bid {{n}} placed, waiting for others",
			scaRebid: "Tie! Raise your bid (cumulative)",
			scaWon: "Won",
			scaRemovedLabel: "Removed",
			scaSwapPrompt: "Delayed Permit: you may swap it for a removed card",
			scaSwapSkip: "Keep",
			scaFreeNote: "You are the only bidder below the cap — take the rest free",
			scoreCash: "Cash",
			scoreShares: "Share value",
			scoreTotal: "Total",
			endPrice130: "A share price reached 130 — game ends after this round",
			endBankrupt: "Bankruptcy — game ends immediately",
			endComplete: "OR7 finished",
			errBadPhase: "Not allowed in this phase",
			errNotYourTurn: "Not your turn",
			errNotCeo: "Only the company CEO can do this",
			errNoSuchCompany: "No such company",
			errNotFloated: "Company not floated yet",
			errNotSellable: "Cannot sell these shares (CEO share is not sellable)",
			errSoldThisSr: "Sold this company this round — no buy-back",
			errCertLimit: "Certificate limit reached",
			errNoShares: "No shares available from that source",
			errLocked: "Company locked by Delayed Permit",
			errBadPar: "Invalid par price",
			errNotEnoughCash: "Not enough cash",
			errNotBidder: "You cannot bid on this card",
			errBidTooHigh: "Bid exceeds your cash",
			errBadSwap: "Cannot swap for that card",
			errTradePending: "A trade is waiting for an answer",
			errBadCard: "This card cannot be used that way",
			errCardNotUsable: "This card is not usable now",
			errBadHex: "Invalid hex",
			errBadTile: "Tile does not follow the upgrade chain",
			errBadRot: "Tracks would not connect in this rotation",
			errTileUnavailable: "Tile not available in the pool",
			errNotReachable: "Not reachable from your stations",
			errNoSlot: "No free station slot",
			errHasStation: "Your company already has a station here",
			errNoExtraStation: "Extra station already used",
			errBadTrain: "This train cannot be bought now",
			errTrainLimit: "A company owns at most 3 trains",
			errMustBuyTrain: "No trains — must buy one first",
			errBadDividend: "Invalid amount (multiple of 5, at most the total)",
			hintDscAssign: "Lock {{company}}",
			hintSrSell: "Sell {{company}} ×{{n}}",
			hintSrBuyIpo: "Buy {{company}} from IPO",
			hintSrBuyMarket: "Buy {{company}} from market",
			hintSrFloat: "Float {{company}} at {{par}}",
			hintSrPass: "Pass",
			hintOrSellTreasury: "Sell treasury ×{{n}}",
			hintOrBuyTrain: "Buy {{train}}",
			hintOrExchange: "Exchange T4 for T6+S",
			hintOrTrade: "Buy {{train}} from {{from}} ({{price}})",
			hintOrDoneTrains: "Done with trains",
			hintOrLay: "Lay a tile",
			hintOrSkipLay: "Skip track",
			hintOrStation: "Place a station",
			hintOrSkipStation: "Skip station",
			hintOrRun: "Run trains",
			hintOrPayout: "Pay out",
			hintOrWithhold: "Withhold",
			hintOrSplit: "Pay {{amount}}",
			hintCardAssign: "Use {{card}}",
			hintCardCentral: "Central station ({{face}})",
			hintPoliBuy: "Discard Poli to buy {{company}}",
			hintPoliSkip: "Skip Poli purchase",
			hintScaBid: "Bid {{amount}}",
			hintScaSwap: "Swap for {{card}}"
		}
	}
};
//#endregion
export { $n as default };
