import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useT as o } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { Texture as c } from "@bgparty/sdk/texture";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as ee } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as te } from "@bgparty/sdk/ui/player-strip";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { GameOverScreen as p } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as m, OptionSection as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/amanite/meta.ts
var g = {
	id: "amanite",
	tier: "beta",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.amanite.name",
	descKey: "games.amanite.desc",
	rulesKey: "games.amanite.rules",
	icon: "🍄",
	iconImg: "games/amanite.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/amanite/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#7c3aed",
	releasedAt: "2026-10-06",
	search: {
		py: "e gao jun",
		init: "egj"
	},
	hotseat: "cover"
}, _ = [
	"green",
	"blue",
	"pink",
	"white",
	"red",
	"yellow"
], v = [..._, "pig"], y = [
	"neg1",
	"v1",
	"v2",
	"v3",
	"v8",
	"elixir",
	"v10",
	"v12",
	"antidote",
	"poison"
], b = t.enum(_), x = t.enum(v), S = t.enum(y), C = t.partialRecord(x, t.int().nonnegative()), w = t.object({ attrs: t.enum(["recommended", "random"]).catch("recommended") }).default({ attrs: "recommended" }), T = t.string(), ne = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseSide"),
		side: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("placeMeeple"),
		tile: t.int().min(0).max(4),
		split: C.optional()
	}),
	t.object({
		type: t.literal("choosePile"),
		pile: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("takeTwo"),
		tokens: t.array(x).max(2)
	}),
	t.object({
		type: t.literal("discardPigs"),
		tokens: t.array(b).max(4)
	}),
	t.object({
		type: t.literal("placeNotebook"),
		color: b
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), E = t.tuple([
	b,
	b,
	b
]), D = t.object({
	attrs: t.record(b, S),
	eliminated: t.array(T),
	scores: t.record(T, t.int()),
	breakdown: t.record(T, t.array(t.object({
		kind: t.string(),
		n: t.int()
	})))
}), O = t.object({
	round: t.int().min(1).max(3),
	phase: t.enum([
		"side",
		"place",
		"gather",
		"notebook",
		"done"
	]),
	firstPlayer: T,
	placeRound: t.int().min(0).max(1),
	actor: T.nullable(),
	pendingKind: t.enum([
		"pile",
		"take",
		"pigs"
	]).nullable(),
	pendingCount: t.int().nonnegative(),
	tiles: t.array(t.object({
		tokens: C,
		meeples: t.array(T),
		piles: t.tuple([C, C]).nullable()
	})),
	players: t.array(t.object({
		rid: T,
		ready: t.boolean(),
		collected: C,
		hintCount: t.int().nonnegative(),
		notebooksLeft: t.int().nonnegative()
	})),
	decks: t.record(b, t.int().nonnegative()),
	attrs: t.array(S).length(6),
	spacesUsed: t.record(b, t.int().nonnegative()),
	spacesTotal: t.int().positive(),
	gatherTile: t.int().nonnegative(),
	result: D.nullable()
}), k = t.object({
	myCard: t.object({
		options: t.tuple([E, E]),
		chosen: t.int().min(0).max(1).nullable()
	}),
	hints: t.array(S),
	colorHints: t.array(t.object({
		color: b,
		attr: S
	}))
}), A = [
	4,
	5,
	6
], j = 10, M = 4, N = 6, P = [
	"neg1",
	"v1",
	"v2",
	"v3",
	"antidote",
	"poison"
], F = [
	[[
		"green",
		"pink",
		"white"
	], [
		"blue",
		"yellow",
		"red"
	]],
	[[
		"blue",
		"yellow",
		"red"
	], [
		"green",
		"pink",
		"white"
	]],
	[[
		"green",
		"yellow",
		"red"
	], [
		"blue",
		"pink",
		"white"
	]],
	[[
		"pink",
		"yellow",
		"blue"
	], [
		"green",
		"red",
		"white"
	]]
], I = (e) => Object.values(e).reduce((e, t) => e + t, 0), L = (e) => _.reduce((t, n) => t + (e[n] ?? 0), 0);
function R(e, t) {
	for (let [n, r] of Object.entries(t)) e[n] = (e[n] ?? 0) + (r ?? 0);
}
function z(e) {
	return e.players.map((t, n) => e.players[(e.firstPlayer + n) % e.players.length].rid);
}
var re = (e) => e === 2 ? 1 : 2;
function B(t) {
	let n = I(t.bag);
	if (n === 0) return null;
	let r = e(t.seed, t.rngCursor, n);
	t.rngCursor += 1;
	for (let e of v) {
		let n = t.bag[e] ?? 0;
		if (r < n) return n === 1 ? delete t.bag[e] : t.bag[e] = n - 1, e;
		r -= n;
	}
	return null;
}
function V(e) {
	let t = A[e.round - 1];
	for (let n of e.tiles) for (let r = 0; r < t; r += 1) {
		let t = B(e);
		if (!t) return;
		n.tokens[t] = (n.tokens[t] ?? 0) + 1;
	}
}
function ie(e) {
	return Array.from({ length: e }, () => ({
		tokens: {},
		meeples: [],
		piles: null
	}));
}
function H(t, n, r) {
	let i = 0, a;
	if (t.attrs === "random") {
		let t = y.filter((e) => e !== "poison" && e !== "antidote");
		for (let n = t.length - 1; n > 0; --n) {
			let a = e(r, i, n + 1);
			i += 1, [t[n], t[a]] = [t[a], t[n]];
		}
		a = [
			"poison",
			"antidote",
			...t.slice(0, 4)
		];
	} else a = [...P];
	for (let t = a.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [a[t], a[n]] = [a[n], a[t]];
	}
	let o = Object.fromEntries(_.map((e, t) => [e, a[t]])), s = [
		0,
		1,
		2,
		3
	];
	for (let t = s.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [s[t], s[n]] = [s[n], s[t]];
	}
	let c = { pig: M };
	for (let e of _) c[e] = j;
	return {
		state: {
			seed: r,
			rngCursor: i + 1,
			players: n.map((e, t) => ({
				rid: e,
				startCard: s[t],
				startSide: null,
				collected: {},
				hints: [],
				colorHints: [],
				notebooksLeft: 2
			})),
			firstPlayer: e(r, i, n.length),
			round: 1,
			phase: "side",
			attrOf: o,
			bag: c,
			decks: Object.fromEntries(_.map((e) => [e, N])),
			tiles: ie(n.length + 1),
			placeRound: 0,
			turnIdx: 0,
			gatherTile: 0,
			pending: null,
			pendingPigs: [],
			nbIdx: 0
		},
		fx: []
	};
}
function U(e) {
	if (e.round === 1 && e.players.every((e) => e.hints.length === 0)) for (let t of e.players) for (let n of F[t.startCard][t.startSide ?? 0]) t.hints.push(e.attrOf[n]), --e.decks[n];
	V(e), e.phase = "place", e.placeRound = 0, e.turnIdx = 0, e.pending = null;
}
function W(e) {
	for (;;) {
		if (e.pendingPigs.length > 0) {
			let t = e.pendingPigs[0], n = e.players.find((e) => e.rid === t.rid);
			if (!n || L(n.collected) === 0) {
				e.pendingPigs.shift();
				continue;
			}
			e.pending = { kind: "pigs" };
			return;
		}
		if (e.gatherTile >= e.tiles.length) {
			G(e);
			return;
		}
		let t = e.tiles[e.gatherTile];
		if (t.meeples.length === 0) {
			R(e.bag, t.tokens), t.tokens = {}, e.gatherTile += 1;
			continue;
		}
		if (t.meeples.length === 1) {
			if (I(t.tokens) === 0) {
				e.gatherTile += 1;
				continue;
			}
			e.pending = { kind: "take" };
			return;
		}
		e.pending = { kind: "pile" };
		return;
	}
}
function G(e) {
	if (e.pending = null, e.round >= 3) {
		e.phase = "done";
		return;
	}
	e.phase = "notebook", e.nbIdx = 0;
}
function ae(e) {
	e.round += 1, e.firstPlayer = (e.firstPlayer + 1) % e.players.length, e.tiles = ie(e.tiles.length), V(e), e.phase = "place", e.placeRound = 0, e.turnIdx = 0, e.pending = null;
}
function K(e, t) {
	for (let [n, r] of t) {
		let t = r.pig ?? 0;
		t > 0 && e.pendingPigs.push({
			rid: n,
			n: t
		});
	}
}
function q(e, t, n) {
	if (t.type === "tick") return {
		state: e,
		fx: []
	};
	if (t.type === "chooseSide") {
		if (e.phase !== "side") return { code: "games.amanite.errNotYourTurn" };
		let r = e.players.find((e) => e.rid === n.by);
		if (!r || r.startSide !== null) return { code: "games.amanite.errNotYourTurn" };
		let i = structuredClone(e);
		return i.players.find((e) => e.rid === n.by).startSide = t.side, i.players.every((e) => e.startSide !== null) && U(i), {
			state: i,
			fx: []
		};
	}
	if (t.type === "placeMeeple") {
		if (e.phase !== "place" || z(e)[e.turnIdx] !== n.by) return { code: "games.amanite.errNotYourTurn" };
		let r = e.tiles[t.tile];
		if (!r || r.meeples.includes(n.by) || r.meeples.length >= 2) return { code: "games.amanite.errBadTile" };
		if (r.meeples.length === 1) {
			if (I(r.tokens) < 2) return { code: "games.amanite.errBadTile" };
			let i = t.split;
			if (!i) return { code: "games.amanite.errBadSplit" };
			let a = 0;
			for (let [e, t] of Object.entries(i)) {
				if (t === void 0 || t < 0 || t > (r.tokens[e] ?? 0)) return { code: "games.amanite.errBadSplit" };
				a += t;
			}
			if (a < 1 || I(r.tokens) - a < 1) return { code: "games.amanite.errBadSplit" };
			let o = structuredClone(e), s = o.tiles[t.tile], c = {}, l = {};
			for (let e of v) {
				let t = i[e] ?? 0;
				t > 0 && (c[e] = t);
				let n = (s.tokens[e] ?? 0) - t;
				n > 0 && (l[e] = n);
			}
			return s.piles = [c, l], s.tokens = {}, s.meeples.push(n.by), J(o), {
				state: o,
				fx: []
			};
		}
		if (t.split) return { code: "games.amanite.errBadSplit" };
		let i = structuredClone(e);
		return i.tiles[t.tile].meeples.push(n.by), J(i), {
			state: i,
			fx: []
		};
	}
	if (t.type === "choosePile") {
		if (e.phase !== "gather" || e.pending?.kind !== "pile") return { code: "games.amanite.errNotYourTurn" };
		let r = e.tiles[e.gatherTile], i = r.meeples[0];
		if (i !== n.by || !r.piles) return { code: "games.amanite.errNotYourTurn" };
		let a = structuredClone(e), o = a.tiles[a.gatherTile], s = o.meeples[1], [c, l] = o.piles, ee = t.pile === 0 ? c : l, te = t.pile === 0 ? l : c;
		return R(a.players.find((e) => e.rid === i).collected, ee), R(a.players.find((e) => e.rid === s).collected, te), K(a, [[i, ee], [s, te]]), o.tokens = {}, o.piles = null, a.gatherTile += 1, W(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "takeTwo") {
		if (e.phase !== "gather" || e.pending?.kind !== "take") return { code: "games.amanite.errNotYourTurn" };
		let r = e.tiles[e.gatherTile];
		if (r.meeples[0] !== n.by) return { code: "games.amanite.errNotYourTurn" };
		let i = Math.min(2, I(r.tokens));
		if (t.tokens.length !== i) return { code: "games.amanite.errBadTokens" };
		let a = {};
		for (let e of t.tokens) if (a[e] = (a[e] ?? 0) + 1, a[e] > (r.tokens[e] ?? 0)) return { code: "games.amanite.errBadTokens" };
		let o = structuredClone(e), s = o.tiles[o.gatherTile];
		R(o.players.find((e) => e.rid === n.by).collected, a);
		for (let [e, t] of Object.entries(a)) {
			let n = (s.tokens[e] ?? 0) - (t ?? 0);
			n === 0 ? delete s.tokens[e] : s.tokens[e] = n;
		}
		return R(o.bag, s.tokens), K(o, [[n.by, a]]), s.tokens = {}, o.gatherTile += 1, W(o), {
			state: o,
			fx: []
		};
	}
	if (t.type === "discardPigs") {
		if (e.phase !== "gather" || e.pending?.kind !== "pigs") return { code: "games.amanite.errNotYourTurn" };
		let r = e.pendingPigs[0];
		if (!r || r.rid !== n.by) return { code: "games.amanite.errNotYourTurn" };
		let i = e.players.find((e) => e.rid === n.by), a = Math.min(r.n, L(i.collected));
		if (t.tokens.length !== a) return { code: "games.amanite.errBadTokens" };
		let o = {};
		for (let e of t.tokens) if (o[e] = (o[e] ?? 0) + 1, o[e] > (i.collected[e] ?? 0)) return { code: "games.amanite.errBadTokens" };
		let s = structuredClone(e), c = s.players.find((e) => e.rid === n.by);
		for (let [e, t] of Object.entries(o)) {
			let n = (c.collected[e] ?? 0) - (t ?? 0);
			n === 0 ? delete c.collected[e] : c.collected[e] = n;
		}
		return R(s.bag, o), s.pendingPigs.shift(), W(s), {
			state: s,
			fx: []
		};
	}
	if (t.type === "placeNotebook") {
		if (e.phase !== "notebook" || [...z(e)].reverse()[e.nbIdx] !== n.by) return { code: "games.amanite.errNotYourTurn" };
		if (e.players.find((e) => e.rid === n.by).notebooksLeft <= 0) return { code: "games.amanite.errNoNotebook" };
		let r = re(e.players.length);
		if (e.players.reduce((e, n) => e + n.colorHints.filter((e) => e.color === t.color).length, 0) >= r || e.decks[t.color] <= 0) return { code: "games.amanite.errNoSpace" };
		let i = structuredClone(e), a = i.players.find((e) => e.rid === n.by);
		return --a.notebooksLeft, --i.decks[t.color], a.colorHints.push({
			color: t.color,
			attr: i.attrOf[t.color]
		}), i.nbIdx += 1, i.nbIdx >= i.players.length && ae(i), {
			state: i,
			fx: []
		};
	}
	return { code: "games.amanite.errNotYourTurn" };
}
function J(e) {
	if (e.turnIdx += 1, !(e.turnIdx < e.players.length)) {
		if (e.placeRound === 0) {
			e.placeRound = 1, e.turnIdx = 0;
			return;
		}
		e.phase = "gather", e.gatherTile = 0, e.pending = null, W(e);
	}
}
function oe(e) {
	let t = {};
	for (let n of e.players) {
		let r = Object.fromEntries(y.map((e) => [e, 0]));
		for (let t of _) r[e.attrOf[t]] += n.collected[t] ?? 0;
		t[n.rid] = r;
	}
	let n = e.players.map((e) => e.rid).filter((e) => {
		let n = t[e];
		return n.poison > n.antidote + n.elixir || n.v12 >= 4;
	}), r = new Set(e.players.map((e) => e.rid).filter((e) => !n.includes(e))), i = /* @__PURE__ */ new Map(), a = e.players.map((e) => e.rid).filter((e) => r.has(e) && t[e].v10 > 0);
	if (a.length > 0) {
		let e = Math.max(...a.map((e) => t[e].v10)), n = a.filter((n) => t[n].v10 === e);
		if (n.length > 1) for (let e of n) i.set(e, 7);
		else {
			i.set(n[0], 10);
			let r = a.filter((e) => e !== n[0]);
			if (r.length > 0) {
				let n = Math.max(...r.map((e) => t[e].v10));
				for (let a of r.filter((e) => t[e].v10 === n)) i.set(a, n === e ? 7 : r.filter((e) => t[e].v10 === n).length > 1 ? 2 : 4);
			}
		}
	}
	let o = {}, s = {};
	for (let n of e.players) {
		let e = t[n.rid], r = [], a = (e, t) => {
			t !== 0 && r.push({
				kind: e,
				n: t
			});
		};
		a("neg1", -e.neg1), a("v1", e.v1), a("v2", 2 * e.v2), a("v3", 3 * e.v3), a("v8", e.v8 === 2 ? 8 : 0), a("v12", e.v12 >= 4 ? 0 : [
			-5,
			0,
			3,
			12
		][e.v12]), a("v10", i.get(n.rid) ?? 0), a("pair", 5 * Math.min(e.poison, e.antidote + e.elixir)), a("clash", -3 * Math.min(e.antidote, e.elixir)), a("pig", 3 * (n.collected.pig ?? 0)), o[n.rid] = r.reduce((e, t) => e + t.n, 0), s[n.rid] = r;
	}
	return {
		scores: o,
		eliminated: n,
		breakdown: s
	};
}
function se(e, t) {
	let n = z(e), r = null, i = 0;
	if (e.phase === "place") r = n[e.turnIdx];
	else if (e.phase === "gather" && e.pending) {
		let t = e.tiles[e.gatherTile];
		if (e.pending.kind === "pile") r = t.meeples[0];
		else if (e.pending.kind === "take") r = t.meeples[0], i = Math.min(2, I(t.tokens));
		else {
			let t = e.pendingPigs[0];
			r = t.rid;
			let n = e.players.find((e) => e.rid === t.rid);
			i = Math.min(t.n, L(n.collected));
		}
	} else e.phase === "notebook" && (r = [...n].reverse()[e.nbIdx]);
	let a = re(e.players.length), o = e.phase === "done" ? {
		attrs: e.attrOf,
		...oe(e)
	} : null, s = e.players.find((e) => e.rid === t);
	return {
		public: {
			round: e.round,
			phase: e.phase,
			firstPlayer: e.players[e.firstPlayer].rid,
			placeRound: e.placeRound,
			actor: r,
			pendingKind: e.phase === "gather" ? e.pending?.kind ?? null : null,
			pendingCount: i,
			tiles: e.tiles.map((e) => ({
				tokens: e.tokens,
				meeples: e.meeples,
				piles: e.piles
			})),
			players: e.players.map((t) => ({
				rid: t.rid,
				ready: e.phase !== "side" || t.startSide !== null,
				collected: t.collected,
				hintCount: t.hints.length + t.colorHints.length,
				notebooksLeft: t.notebooksLeft
			})),
			decks: e.decks,
			attrs: y.filter((t) => _.some((n) => e.attrOf[n] === t)),
			spacesUsed: Object.fromEntries(_.map((t) => [t, e.players.reduce((e, n) => e + n.colorHints.filter((e) => e.color === t).length, 0)])),
			spacesTotal: a,
			gatherTile: e.gatherTile,
			result: o
		},
		private: s ? {
			myCard: {
				options: F[s.startCard],
				chosen: s.startSide
			},
			hints: s.hints,
			colorHints: s.colorHints
		} : void 0
	};
}
function ce(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let { scores: t, eliminated: n } = oe(e), r = e.players.map((e) => e.rid).filter((e) => !n.includes(e)), i = (n, r) => {
		let i = e.players.find((e) => e.rid === n), a = e.players.find((e) => e.rid === r);
		return t[r] - t[n] || L(i.collected) - L(a.collected) || e.players.indexOf(i) - e.players.indexOf(a);
	};
	if (r.length === 0) return {
		phase: "done",
		winner: e.players.map((e) => e.rid),
		ranking: [...e.players.map((e) => e.rid)].sort(i),
		scores: t
	};
	let a = [...r].sort(i), o = a[0];
	return {
		phase: "done",
		winner: a.filter((n) => t[n] === t[o] && L(e.players.find((e) => e.rid === n).collected) === L(e.players.find((e) => e.rid === o).collected)),
		ranking: [...a, ...n.sort(i)],
		scores: t
	};
}
var le = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: g,
	schemas: {
		action: ne,
		publicView: O,
		privateView: k,
		config: w
	},
	setup: H,
	reduce: q,
	viewFor: se,
	status: ce
}, ue = {
	green: "#2ab978",
	blue: "#328dca",
	pink: "#f46b9f",
	white: "#e8edf0",
	red: "#e76450",
	yellow: "#f1c84b",
	pig: "#f28a42"
}, de = {
	green: {
		sky: "#bfec7b",
		ground: "#3d8b43"
	},
	blue: {
		sky: "#7caee8",
		ground: "#254b91"
	},
	pink: {
		sky: "#f8a2a9",
		ground: "#a44882"
	},
	white: {
		sky: "#c8e4e8",
		ground: "#55769b"
	},
	red: {
		sky: "#f8ad68",
		ground: "#a64d55"
	},
	yellow: {
		sky: "#fbe486",
		ground: "#aa7c3d"
	}
};
function fe({ color: e }) {
	switch (e) {
		case "green": return /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", {
				d: "M50 50 Q47 37 49 28 L55 28 Q56 40 60 50Z",
				fill: "#fff5d9",
				stroke: "#24215f",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ d("ellipse", {
				cx: "54",
				cy: "27",
				rx: "22",
				ry: "14",
				fill: "#fff9d3",
				stroke: "#24215f",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "45",
				cy: "24",
				r: "3",
				fill: "#24215f"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "61",
				cy: "26",
				r: "2.5",
				fill: "#24215f"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "75",
				cy: "24",
				r: "11",
				fill: "#fffee7",
				stroke: "#24215f",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "21",
				cy: "32",
				r: "9",
				fill: "#68b657",
				stroke: "#24215f",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "18",
				cy: "25",
				r: "2",
				fill: "#24215f"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "26",
				cy: "25",
				r: "2",
				fill: "#24215f"
			})
		] });
		case "blue": return /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", {
				d: "M32 50 L31 24 M49 51 L48 20 M69 51 L68 29 M84 51 L82 22",
				stroke: "#c4eff6",
				strokeWidth: "4",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ d("path", {
				d: "M15 24 Q31 3 47 24 Q31 31 15 24 M32 18 Q49 0 65 19 Q50 30 32 18 M55 30 Q70 12 89 29 Q71 37 55 30 M72 23 Q86 5 104 24 Q88 33 72 23",
				fill: "#d6edf3",
				stroke: "#24215f",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ d("path", {
				d: "M19 23 L42 23 M35 18 L60 20 M62 29 L85 29",
				stroke: "#24215f",
				strokeWidth: "1.2"
			})
		] });
		case "pink": return /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", {
				d: "M25 50 Q31 36 32 20 M54 52 Q53 36 54 14 M79 52 Q77 36 80 25",
				fill: "none",
				stroke: "#fff1d6",
				strokeWidth: "5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ d("path", {
				d: "M15 21 Q31 2 48 22 Q32 29 15 21 M33 16 Q54 -6 74 16 Q54 26 33 16 M64 27 Q80 8 98 27 Q82 33 64 27",
				fill: "#f7dfdd",
				stroke: "#24215f",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ d("path", {
				d: "M24 22 Q31 30 40 22 M47 17 Q54 28 64 17 M72 28 Q81 37 91 27",
				fill: "none",
				stroke: "#24215f",
				strokeWidth: "1.3"
			})
		] });
		case "white": return /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", {
				d: "M36 50 L39 29 M63 52 L64 22",
				stroke: "#f7f4eb",
				strokeWidth: "7",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ d("path", {
				d: "M15 31 Q38 5 60 30 Q39 42 15 31 M44 23 Q64 0 86 24 Q66 36 44 23",
				fill: "#fbf9ef",
				stroke: "#24215f",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "32",
				cy: "24",
				r: "2",
				fill: "#24215f"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "47",
				cy: "28",
				r: "2",
				fill: "#24215f"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "62",
				cy: "18",
				r: "2",
				fill: "#24215f"
			})
		] });
		case "red": return /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", {
				d: "M48 52 Q54 40 57 25",
				fill: "none",
				stroke: "#fff6dc",
				strokeWidth: "8",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ d("path", {
				d: "M19 28 Q38 -2 77 12 Q93 18 93 31 Q56 41 19 28",
				fill: "#ef5e46",
				stroke: "#24215f",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "45",
				cy: "18",
				r: "3",
				fill: "#fff2ca"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "65",
				cy: "23",
				r: "4",
				fill: "#fff2ca"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "79",
				cy: "27",
				r: "2.5",
				fill: "#fff2ca"
			})
		] });
		case "yellow": return /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", {
				d: "M32 51 L32 26 M53 51 L53 18 M74 51 L74 29",
				stroke: "#fff3a8",
				strokeWidth: "7",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ d("path", {
				d: "M26 24 Q33 14 39 24 M47 16 Q54 5 61 16 M69 26 Q76 16 82 26",
				fill: "#f8e86a",
				stroke: "#24215f",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ d("path", {
				d: "M12 52 Q20 42 25 52 M83 52 Q91 37 101 52",
				fill: "none",
				stroke: "#996a46",
				strokeWidth: "3"
			})
		] });
	}
}
function pe({ color: e }) {
	let t = de[e];
	return /* @__PURE__ */ f("svg", {
		viewBox: "0 0 108 60",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": !0,
		className: "am-card-art",
		children: [
			/* @__PURE__ */ d("rect", {
				width: "108",
				height: "60",
				fill: t.sky
			}),
			/* @__PURE__ */ d("path", {
				d: "M0 13 Q19 -2 36 13 Q55 -3 72 12 Q92 -1 108 12 L108 0 L0 0Z",
				fill: t.ground,
				opacity: ".42"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "84",
				cy: "19",
				r: "12",
				fill: "#fff6bd",
				opacity: ".6"
			}),
			/* @__PURE__ */ d("path", {
				d: "M0 55 Q18 42 39 52 Q57 40 77 52 Q94 43 108 54 L108 60 L0 60Z",
				fill: t.ground
			}),
			/* @__PURE__ */ d(fe, { color: e }),
			/* @__PURE__ */ d("path", {
				d: "M0 55 Q14 39 30 53 M78 53 Q94 37 108 52",
				fill: "none",
				stroke: "#24215f",
				strokeWidth: "2",
				opacity: ".45"
			})
		]
	});
}
function me({ index: e }) {
	let t = [
		"#2c8f63",
		"#86c652",
		"#5fac80",
		"#77b357",
		"#439d74"
	][e % 5];
	return /* @__PURE__ */ f("svg", {
		viewBox: "0 0 150 190",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		className: "am-forest-art",
		children: [
			/* @__PURE__ */ d("rect", {
				width: "150",
				height: "190",
				fill: "#178151"
			}),
			/* @__PURE__ */ d("path", {
				d: "M0 8 Q35 -9 55 20 Q80 -7 109 17 Q127 2 150 8 M0 32 Q26 17 45 37 M107 38 Q129 14 150 31",
				fill: "none",
				stroke: "#78c254",
				strokeWidth: "12"
			}),
			/* @__PURE__ */ d("path", {
				d: "M0 78 Q35 57 69 82 Q108 58 150 77 L150 104 Q112 89 73 104 Q31 91 0 107Z",
				fill: "#4da358"
			}),
			/* @__PURE__ */ d("path", {
				d: "M0 100 Q27 83 44 98 M106 96 Q130 79 150 98",
				fill: "none",
				stroke: "#0b6150",
				strokeWidth: "10"
			}),
			/* @__PURE__ */ d("path", {
				d: "M0 179 Q25 150 55 177 Q103 151 150 179",
				fill: "none",
				stroke: "#075a4c",
				strokeWidth: "16"
			}),
			/* @__PURE__ */ d("path", {
				d: "M0 0 Q25 -4 42 22 Q20 24 14 43 Q4 32 0 0 M150 3 Q125 -4 110 27 Q128 27 137 45 Q148 29 150 3",
				fill: t,
				stroke: "#174c61",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ d("path", {
				d: "M0 145 Q16 123 27 151 M121 153 Q138 125 150 145",
				fill: "none",
				stroke: "#b3d377",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ d("circle", {
				cx: 15 + e * 3,
				cy: "134",
				r: "3",
				fill: "#f9a16e"
			}),
			/* @__PURE__ */ d("circle", {
				cx: 137 - e * 4,
				cy: "142",
				r: "3",
				fill: "#e8e47a"
			})
		]
	});
}
function Y({ type: e }) {
	return /* @__PURE__ */ f("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": !0,
		className: "am-token-art",
		children: [
			/* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "16",
				r: "15",
				fill: ue[e],
				stroke: "#24215f",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "16",
				r: "11.5",
				fill: "#17154c"
			}),
			e === "pig" ? /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", {
					d: "M9 12 L7 7 L13 9 Q16 6 20 9 L25 7 L23 12 Q26 16 23 21 Q16 26 9 21 Q6 17 9 12",
					fill: "#ffa464"
				}),
				/* @__PURE__ */ d("ellipse", {
					cx: "16",
					cy: "18",
					rx: "5",
					ry: "3",
					fill: "#f6b58b"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "14",
					cy: "18",
					r: ".8",
					fill: "#24215f"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "18",
					cy: "18",
					r: ".8",
					fill: "#24215f"
				})
			] }) : /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", {
					d: "M9 15 Q10 8 16 8 Q23 9 24 15 Q16 19 9 15 M14 16 L14 23 Q17 25 20 23 L20 16",
					fill: "#fdf7d8",
					stroke: "#fdf7d8",
					strokeWidth: "1"
				}),
				e === "white" && /* @__PURE__ */ d("circle", {
					cx: "16",
					cy: "12",
					r: "1.7",
					fill: "#24215f"
				}),
				e === "red" && /* @__PURE__ */ d("circle", {
					cx: "12",
					cy: "14",
					r: "1.5",
					fill: "#e76450"
				}),
				e === "blue" && /* @__PURE__ */ d("path", {
					d: "M11 14 L21 14",
					stroke: "#328dca",
					strokeWidth: "1.5"
				}),
				e === "pink" && /* @__PURE__ */ d("path", {
					d: "M12 13 Q17 8 22 13",
					fill: "none",
					stroke: "#f46b9f",
					strokeWidth: "1.5"
				}),
				e === "yellow" && /* @__PURE__ */ d("path", {
					d: "M16 8 L16 14",
					stroke: "#f1c84b",
					strokeWidth: "1.5"
				}),
				e === "green" && /* @__PURE__ */ d("path", {
					d: "M11 12 L14 15 L21 10",
					fill: "none",
					stroke: "#2ab978",
					strokeWidth: "1.5"
				})
			] })
		]
	});
}
//#endregion
//#region src/games/amanite/view-player.tsx
var X = {
	green: "games.amanite.colorGreen",
	blue: "games.amanite.colorBlue",
	pink: "games.amanite.colorPink",
	white: "games.amanite.colorWhite",
	red: "games.amanite.colorRed",
	yellow: "games.amanite.colorYellow",
	pig: "games.amanite.colorPig"
}, he = {
	neg1: "games.amanite.attrNeg1",
	v1: "games.amanite.attrV1",
	v2: "games.amanite.attrV2",
	v3: "games.amanite.attrV3",
	v8: "games.amanite.attrV8",
	elixir: "games.amanite.attrElixir",
	v10: "games.amanite.attrV10",
	v12: "games.amanite.attrV12",
	antidote: "games.amanite.attrAntidote",
	poison: "games.amanite.attrPoison"
}, Z = (e) => v.flatMap((t) => Array.from({ length: e[t] ?? 0 }, () => t)), ge = (e) => v.reduce((t, n) => t + (e[n] ?? 0), 0);
function _e(e) {
	return /* @__PURE__ */ d(ve, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ve({ pub: e, priv: t, members: p, myRid: m, send: h }) {
	let g = o(), y = r(null), b = r([]), x = e.actor === m, S = e.players.find((e) => e.rid === m), C = 2 - e.tiles.filter((e) => e.meeples.includes(m)).length, w = (e) => p.find((t) => t.rid === e)?.name ?? e, T = (e) => {
		let t = p.find((t) => t.rid === e);
		return t ? s[t.colorIndex % s.length].hex : s[0].hex;
	}, ne = (e) => {
		let t = p.find((t) => t.rid === e);
		return t ? a[t.avatar % a.length] : void 0;
	}, E = `${e.phase}:${e.actor}:${e.gatherTile}:${e.pendingKind}:${e.pendingCount}:${e.tiles.map((e) => `${e.meeples.join(",")}-${Z(e.tokens).join(",")}`).join("|")}`, [D, O] = i(null), [k, A] = i(null), [j, M] = i(!1), N = D?.key === E ? D : null, P = k?.key === E ? k.tokens : [], F = k?.key === E ? k.indices ?? [] : [], I = e.phase === "gather" && x && e.pendingKind === "pigs", L = e.phase === "gather" && x && e.pendingKind === "take", R = e.phase === "gather" && x && e.pendingKind === "pile", z = (e) => {
		let t = y.current, n = b.current[e];
		t && n && t.scrollTo({
			left: n.offsetLeft - t.offsetLeft - (t.clientWidth - n.clientWidth) / 2,
			behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth"
		});
	};
	n(() => {
		e.phase === "gather" && z(e.gatherTile);
	}, [e.phase, e.gatherTile]);
	let { tone: re, text: B } = (() => {
		if (e.phase === "side") return t?.myCard.chosen == null ? {
			tone: "accent",
			text: g("games.amanite.sidePrompt")
		} : {
			tone: "info",
			text: g("games.amanite.sideWaiting")
		};
		if (e.phase === "place") return x ? {
			tone: "accent",
			text: g(e.placeRound ? "games.amanite.placeSecondPrompt" : "games.amanite.placePrompt")
		} : {
			tone: "info",
			text: g("games.amanite.placeWaiting", { name: w(e.actor ?? "") })
		};
		if (e.phase === "gather") {
			if (!e.pendingKind) return {
				tone: "info",
				text: g("games.amanite.resolving")
			};
			let t = w(e.actor ?? "");
			return e.pendingKind === "pile" ? x ? {
				tone: "accent",
				text: g("games.amanite.choosePilePrompt")
			} : {
				tone: "info",
				text: g("games.amanite.choosePileWaiting", { name: t })
			} : e.pendingKind === "take" ? x ? {
				tone: "accent",
				text: g("games.amanite.takePrompt", { n: e.pendingCount })
			} : {
				tone: "info",
				text: g("games.amanite.takeWaiting", { name: t })
			} : x ? {
				tone: "accent",
				text: g("games.amanite.pigPrompt", { n: e.pendingCount })
			} : {
				tone: "info",
				text: g("games.amanite.pigWaiting", { name: t })
			};
		}
		return e.phase === "notebook" ? x ? {
			tone: "accent",
			text: g("games.amanite.notebookPrompt")
		} : {
			tone: "info",
			text: g("games.amanite.notebookWaiting", { name: w(e.actor ?? "") })
		} : {
			tone: "info",
			text: ""
		};
	})(), V = (t) => {
		if (e.phase !== "place" || !x) return !1;
		let n = e.tiles[t];
		return !!n && !n.meeples.includes(m) && n.meeples.length < 2 && (n.meeples.length === 0 || ge(n.tokens) >= 2);
	}, ie = (t) => {
		V(t) && (e.tiles[t].meeples.length === 0 ? h({
			type: "placeMeeple",
			tile: t
		}) : (O({
			key: E,
			tile: t,
			indices: []
		}), z(t)));
	}, H = {};
	if (N) for (let t of N.indices) {
		let n = Z(e.tiles[N.tile].tokens)[t];
		n && (H[n] = (H[n] ?? 0) + 1);
	}
	let U = N?.indices.length ?? 0, W = N ? ge(e.tiles[N.tile].tokens) : 0, G = !!N && U > 0 && U < W, ae = (e) => {
		if (!N) return;
		let t = N.indices.includes(e) ? N.indices.filter((t) => t !== e) : [...N.indices, e];
		O({
			...N,
			indices: t
		});
	}, K = (t, n) => {
		let r = [...F], i = [...P], a = r.indexOf(n);
		a >= 0 ? (r.splice(a, 1), i.splice(a, 1)) : i.length < e.pendingCount && (r.push(n), i.push(t)), A({
			key: E,
			tokens: i,
			indices: r
		});
	}, q = (t, n) => {
		let r = [...P];
		n < 0 ? r.splice(r.lastIndexOf(t), 1) : r.length < e.pendingCount && r.filter((e) => e === t).length < (S?.collected[t] ?? 0) && r.push(t), A({
			key: E,
			tokens: r
		});
	}, J = S && /* @__PURE__ */ f("div", {
		className: "am-tray",
		children: [
			/* @__PURE__ */ d("span", {
				className: "am-tray-title",
				children: g("games.amanite.collectedLabel")
			}),
			/* @__PURE__ */ f("div", {
				className: "am-collection",
				children: [v.filter((e) => (S.collected[e] ?? 0) > 0).map((e) => /* @__PURE__ */ f("span", {
					className: "am-collection-item",
					title: g(X[e]),
					children: [
						/* @__PURE__ */ d(Y, { type: e }),
						"×",
						S.collected[e]
					]
				}, e)), ge(S.collected) === 0 && "—"]
			}),
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "am-hints-button",
				disabled: !t,
				onClick: () => M(!0),
				children: [
					g("games.amanite.hintsTitle"),
					" · ",
					(t?.hints.length ?? 0) + (t?.colorHints.length ?? 0)
				]
			})
		]
	});
	return /* @__PURE__ */ d("div", {
		className: "am-screen",
		children: /* @__PURE__ */ d(l, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ f("div", {
				className: "am-header",
				children: [/* @__PURE__ */ d(ee, {
					tone: re,
					text: B,
					chip: g("games.amanite.roundShort", { n: e.round }),
					accent: "#24215f"
				}), /* @__PURE__ */ d("div", {
					className: "am-seats",
					children: /* @__PURE__ */ d(te, {
						variant: "medal",
						members: p,
						myRid: m,
						action: (t) => e.actor === t ? "pending" : null,
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							if (!n) return null;
							let r = _.reduce((e, t) => e + (n.collected[t] ?? 0), 0);
							return /* @__PURE__ */ f("span", {
								className: "am-seat-status",
								children: [
									"🍄",
									r,
									" ▣",
									n.hintCount
								]
							});
						}
					})
				})]
			}),
			actionsHeight: "am-action-slot",
			actions: /* @__PURE__ */ f("div", {
				className: "am-actions",
				children: [
					J,
					/* @__PURE__ */ d("div", {
						className: "am-actions-label",
						children: N ? g("games.amanite.splitPrompt") : B
					}),
					/* @__PURE__ */ d("div", {
						className: "am-actions-buttons",
						children: N ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
							type: "button",
							className: "am-secondary",
							onClick: () => O(null),
							children: g("games.amanite.cancel")
						}), /* @__PURE__ */ f("button", {
							type: "button",
							className: "am-primary",
							disabled: !G,
							onClick: () => {
								G && V(N.tile) && (h({
									type: "placeMeeple",
									tile: N.tile,
									split: H
								}), O(null));
							},
							children: [
								g("games.amanite.splitConfirm"),
								" · ",
								U,
								"/",
								W
							]
						})] }) : L ? /* @__PURE__ */ f("button", {
							type: "button",
							className: "am-primary",
							disabled: P.length !== e.pendingCount,
							onClick: () => {
								P.length === e.pendingCount && (h({
									type: "takeTwo",
									tokens: P
								}), A(null));
							},
							children: [
								g("games.amanite.confirm"),
								" · ",
								P.length,
								"/",
								e.pendingCount
							]
						}) : I ? /* @__PURE__ */ f("button", {
							type: "button",
							className: "am-primary",
							disabled: P.length !== e.pendingCount,
							onClick: () => {
								P.length === e.pendingCount && (h({
									type: "discardPigs",
									tokens: P
								}), A(null));
							},
							children: [
								g("games.amanite.confirm"),
								" · ",
								P.length,
								"/",
								e.pendingCount
							]
						}) : /* @__PURE__ */ d("div", {
							className: "am-action-idle",
							children: e.phase === "place" && S ? g("games.amanite.meeplesLeft", { n: C }) : e.phase === "notebook" && S ? g("games.amanite.notebooksLeft", { n: S.notebooksLeft }) : null
						})
					})
				]
			}),
			overlay: I || j || e.phase === "side" && t && t.myCard.chosen == null ? /* @__PURE__ */ f("div", {
				className: "am-overlay",
				children: [
					I && S && /* @__PURE__ */ f("div", {
						className: "am-sheet",
						role: "group",
						"aria-label": g("games.amanite.pigPrompt", { n: e.pendingCount }),
						children: [/* @__PURE__ */ d("div", {
							className: "am-sheet-heading",
							children: g("games.amanite.pigPrompt", { n: e.pendingCount })
						}), /* @__PURE__ */ d("div", {
							className: "am-discard-grid",
							children: _.map((t) => {
								let n = S.collected[t] ?? 0, r = P.filter((e) => e === t).length;
								return /* @__PURE__ */ f("div", {
									className: "am-discard-cell",
									children: [
										/* @__PURE__ */ f("div", {
											className: "am-discard-head",
											children: [/* @__PURE__ */ d(Y, { type: t }), g(X[t])]
										}),
										/* @__PURE__ */ f("div", {
											className: "am-discard-count",
											children: [
												r,
												"/",
												n
											]
										}),
										/* @__PURE__ */ f("div", {
											className: "am-discard-controls",
											children: [/* @__PURE__ */ d("button", {
												type: "button",
												disabled: r === 0,
												onClick: () => q(t, -1),
												"aria-label": `${g(X[t])} −`,
												children: "−"
											}), /* @__PURE__ */ d("button", {
												type: "button",
												disabled: r >= n || P.length >= e.pendingCount,
												onClick: () => q(t, 1),
												"aria-label": `${g(X[t])} +`,
												children: "+"
											})]
										})
									]
								}, t);
							})
						})]
					}),
					e.phase === "side" && t && t.myCard.chosen == null && /* @__PURE__ */ f("div", {
						className: "am-sheet",
						children: [/* @__PURE__ */ d("div", {
							className: "am-sheet-heading",
							children: g("games.amanite.sidePrompt")
						}), /* @__PURE__ */ d("div", {
							className: "am-start-choices",
							children: t.myCard.options.map((e, t) => /* @__PURE__ */ f("button", {
								type: "button",
								className: "am-start-choice",
								onClick: () => h({
									type: "chooseSide",
									side: t
								}),
								"aria-label": `${g("games.amanite.chooseSideAria")} ${t + 1}`,
								children: [/* @__PURE__ */ d("span", { children: g(t === 0 ? "games.amanite.sideFront" : "games.amanite.sideBack") }), /* @__PURE__ */ d("span", {
									className: "am-start-triple",
									children: e.map((e, t) => /* @__PURE__ */ d(Y, { type: e }, `${e}-${t}`))
								})]
							}, t))
						})]
					}),
					j && t && /* @__PURE__ */ f("div", {
						className: "am-sheet",
						children: [
							/* @__PURE__ */ f("div", {
								className: "am-sheet-heading",
								children: [/* @__PURE__ */ d("span", { children: g("games.amanite.hintsTitle") }), /* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => M(!1),
									"aria-label": g("games.amanite.close"),
									children: "×"
								})]
							}),
							t.myCard.chosen != null && /* @__PURE__ */ d("div", {
								className: "am-hint-group",
								children: t.myCard.options[t.myCard.chosen].map((e, t) => /* @__PURE__ */ f("span", {
									className: "am-hint-card",
									children: [/* @__PURE__ */ d(Y, { type: e }), g(X[e])]
								}, `${e}-${t}`))
							}),
							/* @__PURE__ */ d("div", {
								className: "am-sheet-subtitle",
								children: g("games.amanite.startHintsLabel")
							}),
							/* @__PURE__ */ d("div", {
								className: "am-hint-group",
								children: t.hints.map((e, t) => /* @__PURE__ */ d("span", {
									className: "am-hint-card",
									children: g(he[e])
								}, t))
							}),
							/* @__PURE__ */ d("div", {
								className: "am-sheet-subtitle",
								children: g("games.amanite.knownHintsLabel")
							}),
							/* @__PURE__ */ d("div", {
								className: "am-hint-group",
								children: t.colorHints.map((e, t) => /* @__PURE__ */ f("span", {
									className: "am-hint-card",
									children: [/* @__PURE__ */ d(Y, { type: e.color }), g(he[e.attr])]
								}, t))
							})
						]
					})
				]
			}) : void 0,
			children: /* @__PURE__ */ f("div", {
				className: "am-table",
				children: [/* @__PURE__ */ d(c, {
					kind: "sheen",
					base: "#126f56",
					className: "am-texture"
				}), /* @__PURE__ */ f("div", {
					className: "am-table-content",
					children: [/* @__PURE__ */ f("section", {
						className: "am-cards-section",
						"aria-label": g("games.amanite.cardsLabel"),
						children: [/* @__PURE__ */ f("div", {
							className: "am-section-heading",
							children: [/* @__PURE__ */ d("strong", { children: g("games.amanite.cardsLabel") }), /* @__PURE__ */ d("span", { children: e.phase === "notebook" && S ? g("games.amanite.notebooksLeft", { n: S.notebooksLeft }) : "" })]
						}), /* @__PURE__ */ d("div", {
							className: "am-card-grid",
							children: _.map((t) => {
								let n = e.phase === "notebook" && x && (S?.notebooksLeft ?? 0) > 0 && e.spacesUsed[t] < e.spacesTotal && e.decks[t] > 0;
								return /* @__PURE__ */ f("button", {
									type: "button",
									className: `am-card ${n ? "is-actionable" : ""} ${e.phase === "notebook" && x && !n ? "is-blocked" : ""}`,
									disabled: !n,
									onClick: () => h({
										type: "placeNotebook",
										color: t
									}),
									"aria-label": `${g(X[t])}, ${g("games.amanite.deckLeft", { n: e.decks[t] })}, ${g("games.amanite.spacesLabel", {
										used: e.spacesUsed[t],
										total: e.spacesTotal
									})}`,
									children: [
										/* @__PURE__ */ d(pe, { color: t }),
										n && /* @__PURE__ */ d("span", {
											className: "am-card-badge",
											children: "+"
										}),
										/* @__PURE__ */ f("span", {
											className: "am-card-info",
											children: [
												/* @__PURE__ */ d("span", {
													className: "am-color-mark",
													style: { backgroundColor: ue[t] }
												}),
												/* @__PURE__ */ d("span", {
													className: "am-card-name",
													children: g(X[t])
												}),
												/* @__PURE__ */ d("span", {
													className: "am-deck-count",
													children: e.decks[t]
												}),
												/* @__PURE__ */ d("span", {
													className: "am-notebook-slots",
													children: Array.from({ length: e.spacesTotal }, (n, r) => /* @__PURE__ */ d("span", { className: `am-notebook-slot ${r < e.spacesUsed[t] ? "is-used" : ""}` }, r))
												})
											]
										}),
										e.result && /* @__PURE__ */ d("span", {
											className: "am-card-result",
											children: g(he[e.result.attrs[t]])
										})
									]
								}, t);
							})
						})]
					}), /* @__PURE__ */ f("section", {
						className: "am-forest-section",
						"aria-label": g("games.amanite.forestLabel"),
						children: [/* @__PURE__ */ f("div", {
							className: "am-forest-heading",
							children: [/* @__PURE__ */ f("div", {
								className: "am-section-heading",
								children: [/* @__PURE__ */ d("strong", { children: g("games.amanite.forestLabel") }), /* @__PURE__ */ d("span", { children: e.phase === "gather" ? `${e.gatherTile + 1}/${e.tiles.length}` : "" })]
							}), /* @__PURE__ */ d("div", {
								className: "am-forest-nav",
								children: e.tiles.map((t, n) => /* @__PURE__ */ d("button", {
									type: "button",
									className: `am-nav-dot ${e.gatherTile === n && e.phase === "gather" ? "is-current" : ""} ${t.meeples.length ? "is-occupied" : ""}`,
									onClick: () => z(n),
									"aria-label": g("games.amanite.tileLabel", { n: n + 1 }),
									children: n + 1
								}, n))
							})]
						}), /* @__PURE__ */ d("div", {
							className: "am-rail",
							ref: y,
							children: e.tiles.map((t, n) => {
								let r = V(n), i = e.phase === "gather" && e.gatherTile === n, o = N?.tile === n, s = e.phase === "gather" && n < e.gatherTile, c = Z(t.tokens);
								return /* @__PURE__ */ f("div", {
									ref: (e) => {
										b.current[n] = e;
									},
									className: `am-forest-tile ${i ? "is-current" : ""} ${o ? "is-split" : ""} ${s ? "is-spent" : ""} ${r ? "is-placeable" : ""}`,
									children: [
										/* @__PURE__ */ d(me, { index: n }),
										/* @__PURE__ */ d("span", {
											className: "am-tile-title",
											children: g("games.amanite.tileLabel", { n: n + 1 })
										}),
										/* @__PURE__ */ d("div", {
											className: "am-slots",
											children: [0, 1].map((e) => {
												let n = t.meeples[e], r = n ? ne(n) : void 0;
												return /* @__PURE__ */ f("span", {
													className: "am-slot",
													title: n ? w(n) : void 0,
													children: [/* @__PURE__ */ d("span", {
														className: `am-slot-disc ${n ? "has-avatar" : ""}`,
														style: n ? { backgroundColor: T(n) } : void 0,
														children: r ? /* @__PURE__ */ d("img", {
															src: r,
															alt: "",
															draggable: !1,
															className: "am-slot-avatar"
														}) : n ? /* @__PURE__ */ d("img", {
															src: a[0],
															alt: "",
															draggable: !1,
															className: "am-slot-avatar"
														}) : e === 0 ? "◆" : "✂"
													}), /* @__PURE__ */ d("span", {
														className: "am-slot-name",
														children: n ? w(n) : g(e === 0 ? "games.amanite.stakeSlot" : "games.amanite.scissorsSlot")
													})]
												}, e);
											})
										}),
										t.piles && !o ? /* @__PURE__ */ d("div", {
											className: "am-piles",
											children: t.piles.map((e, t) => /* @__PURE__ */ f("button", {
												type: "button",
												className: `am-pile ${R && i ? "is-actionable" : ""}`,
												disabled: !(R && i),
												onClick: () => h({
													type: "choosePile",
													pile: t
												}),
												children: [/* @__PURE__ */ d("span", {
													className: "am-pile-label",
													children: g(t === 0 ? "games.amanite.pileTop" : "games.amanite.pileBottom")
												}), /* @__PURE__ */ d("span", {
													className: "am-pile-tokens",
													children: Z(e).map((e, t) => /* @__PURE__ */ d(Y, { type: e }, t))
												})]
											}, t))
										}) : /* @__PURE__ */ f(u, { children: [o && /* @__PURE__ */ f("div", {
											className: "am-split-totals",
											children: [/* @__PURE__ */ f("span", { children: [
												g("games.amanite.pileTop"),
												" ",
												U
											] }), /* @__PURE__ */ f("span", { children: [
												g("games.amanite.pileBottom"),
												" ",
												W - U
											] })]
										}), /* @__PURE__ */ d("div", {
											className: "am-token-grid",
											children: c.map((e, t) => {
												let n = c.slice(0, t).filter((t) => t === e).length, r = o ? N.indices.includes(t) : L && i && F.includes(t), a = o || L && i;
												return /* @__PURE__ */ f("button", {
													type: "button",
													className: `am-token-hit ${r ? "is-selected" : ""} ${o ? r ? "is-top" : "is-bottom" : ""}`,
													disabled: !a,
													onClick: () => o ? ae(t) : K(e, t),
													"aria-label": `${g(X[e])} ${n + 1}`,
													"aria-pressed": a ? r : void 0,
													children: [/* @__PURE__ */ d(Y, { type: e }), r && /* @__PURE__ */ d("span", {
														className: "am-token-choice",
														children: "✓"
													})]
												}, t);
											})
										})] }),
										r && !o && /* @__PURE__ */ d("button", {
											type: "button",
											className: "am-tile-hit",
											onClick: () => ie(n),
											"aria-label": g("games.amanite.hintPlace", { n: n + 1 }),
											children: t.meeples.length ? g("games.amanite.tapToSplit") : g("games.amanite.tapToPlace")
										}),
										s && /* @__PURE__ */ d("span", {
											className: "am-tile-spent",
											children: "✓"
										})
									]
								}, n);
							})
						})]
					})]
				})]
			})
		})
	});
}
//#endregion
//#region src/games/amanite/bot.ts
var ye = (e) => Object.values(e).reduce((e, t) => e + (t ?? 0), 0), be = (e) => _.reduce((t, n) => t + (e[n] ?? 0), 0);
function Q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function xe(e) {
	let t = {};
	for (let n of e) t[n] = 1 / e.length;
	return t;
}
function Se(e) {
	let t = e.public, n = e.private, r = new Map((n?.colorHints ?? []).map((e) => [e.color, e.attr])), i = new Set(r.values()), a = n && n.myCard.chosen !== null ? n.myCard.options[n.myCard.chosen] : [], o = (n?.hints ?? []).filter((e) => !i.has(e)), s = t.attrs.filter((e) => !i.has(e)), c = {};
	for (let e of _) {
		let t = r.get(e);
		c[e] = t ? { [t]: 1 } : a.includes(e) && o.length > 0 ? xe(o) : xe(s);
	}
	return c;
}
function Ce(e, t) {
	let n = Object.fromEntries(y.map((e) => [e, 0]));
	for (let r of _) {
		let i = t[r] ?? 0;
		if (i) for (let [t, a] of Object.entries(e[r])) n[t] += (a ?? 0) * i;
	}
	return n;
}
function we(e, t, n, r, i, a) {
	switch (e) {
		case "neg1": return -1;
		case "v1": return 1;
		case "v2": return 2;
		case "v3": return 3;
		case "v8": return t.v8 < .5 ? 3 : t.v8 < 1.5 ? 5 : 0;
		case "v12": return t.v12 < .5 ? 5 : t.v12 < 1.5 ? 3 : t.v12 < 2.5 ? 9 : -50;
		case "poison": return t.poison + 1 <= t.antidote + t.elixir ? 5 : -50;
		case "antidote": return (t.antidote + t.elixir < t.poison ? 5 : 0) + (t.antidote < t.elixir ? -3 : 0) || 1;
		case "elixir": return (t.antidote + t.elixir < t.poison ? 5 : 0) + (t.elixir < t.antidote ? -3 : 0) || 1;
		case "v10": {
			let e = _.find((e) => (r[e].v10 ?? 0) === 1);
			if (!e) return 3;
			let t = (n.players.find((e) => e.rid === i).collected[e] ?? 0) + +(a === e), o = Math.max(0, ...n.players.filter((e) => e.rid !== i).map((t) => t.collected[e] ?? 0));
			return t > o ? 6 : t === o ? 4 : 1;
		}
	}
}
function Te(e, t) {
	let n = Infinity;
	for (let r of _) (e[r] ?? 0) > 0 && (n = Math.min(n, t(r)));
	return n === Infinity ? 3 : 3 - n;
}
function $(e, t) {
	let n = e.public, r = n.players.find((e) => e.rid === t), i = Se(e), a = Ce(i, r.collected), o = (e) => {
		let r = 0;
		for (let [o, s] of Object.entries(i[e])) r += (s ?? 0) * we(o, a, n, i, t, e);
		return r;
	}, s = (e) => e === "pig" ? Te(r.collected, o) : o(e);
	return {
		token: s,
		pile: (e) => Object.entries(e).reduce((e, [t, n]) => e + (n ?? 0) * s(t), 0)
	};
}
function Ee(e, t) {
	let n = [];
	for (let [r, i] of Object.entries(e)) for (let e = 0; e < (i ?? 0); e += 1) n.push({
		t: r,
		v: t.token(r)
	});
	n.sort((e, t) => t.v - e.v);
	let r = {}, i = {}, a = 0, o = 0;
	for (let [e, t] of n.entries()) e === 0 || e > 1 && a <= o ? (r[t.t] = (r[t.t] ?? 0) + 1, a += t.v) : (i[t.t] = (i[t.t] ?? 0) + 1, o += t.v);
	return {
		split: r,
		v: Math.min(a, o)
	};
}
function De(e, t) {
	let n = e.public.players.find((e) => e.rid === t.rid);
	return !n || n.ready ? null : {
		type: "chooseSide",
		side: Q([0, 1])
	};
}
function Oe(e, t) {
	let n = e.public.tiles.map((e, t) => ({
		t: e,
		i: t
	})).filter(({ t: e }) => !e.meeples.includes(t.rid) && e.meeples.length < 2 && (e.meeples.length === 0 || ye(e.tokens) >= 2));
	if (t.difficulty === "weak") {
		let { t: e, i: t } = Q(n);
		if (e.meeples.length === 0) return {
			type: "placeMeeple",
			tile: t
		};
		let r = [];
		for (let [t, n] of Object.entries(e.tokens)) for (let e = 0; e < (n ?? 0); e += 1) r.push(t);
		return {
			type: "placeMeeple",
			tile: t,
			split: { [Q(r)]: 1 }
		};
	}
	let r = $(e, t.rid), i = {
		type: "placeMeeple",
		tile: n[0].i
	}, a = -Infinity;
	for (let { t: e, i: t } of n) {
		let n, o;
		if (e.meeples.length === 0) {
			let t = Object.entries(e.tokens).flatMap(([e, t]) => Array.from({ length: t ?? 0 }, () => r.token(e))).sort((e, t) => t - e), i = (t[0] ?? 0) + (t[1] ?? 0);
			n = Math.max(i, .55 * r.pile(e.tokens));
		} else {
			let t = Ee(e.tokens, r);
			n = t.v, o = t.split;
		}
		n > a && (a = n, i = {
			type: "placeMeeple",
			tile: t,
			split: o
		});
	}
	return i;
}
function ke(e, t) {
	let n = e.public, r = n.tiles[n.gatherTile], i = t.difficulty === "weak";
	if (n.pendingKind === "pile") {
		if (i || !r.piles) return {
			type: "choosePile",
			pile: Q([0, 1])
		};
		let n = $(e, t.rid);
		return {
			type: "choosePile",
			pile: n.pile(r.piles[0]) >= n.pile(r.piles[1]) ? 0 : 1
		};
	}
	if (n.pendingKind === "take") {
		let n = Math.min(2, ye(r.tokens)), a = [];
		for (let [e, t] of Object.entries(r.tokens)) for (let n = 0; n < (t ?? 0); n += 1) a.push(e);
		if (i) {
			let e = [];
			for (let t = 0; t < n; t += 1) e.push(a.splice(Math.floor(crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % a.length), 1)[0]);
			return {
				type: "takeTwo",
				tokens: e
			};
		}
		let o = $(e, t.rid);
		return {
			type: "takeTwo",
			tokens: a.map((e) => ({
				t: e,
				v: o.token(e)
			})).sort((e, t) => t.v - e.v).slice(0, n).map((e) => e.t)
		};
	}
	let a = n.players.find((e) => e.rid === t.rid), o = Math.min(n.pendingCount, be(a.collected)), s = [];
	for (let e of _) for (let t = 0; t < (a.collected[e] ?? 0); t += 1) s.push(e);
	if (i) {
		let e = [];
		for (let t = 0; t < o; t += 1) e.push(s.splice(Math.floor(crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % s.length), 1)[0]);
		return {
			type: "discardPigs",
			tokens: e
		};
	}
	let c = $(e, t.rid);
	return {
		type: "discardPigs",
		tokens: s.map((e) => ({
			c: e,
			v: c.token(e)
		})).sort((e, t) => e.v - t.v).slice(0, o).map((e) => e.c)
	};
}
function Ae(e, t) {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (r.notebooksLeft <= 0) return null;
	let i = _.filter((e) => n.spacesUsed[e] < n.spacesTotal && n.decks[e] > 0);
	if (i.length === 0) return null;
	if (t.difficulty === "weak") return {
		type: "placeNotebook",
		color: Q(i)
	};
	let a = Se(e), o = (e) => n.tiles.reduce((t, n) => t + (n.tokens[e] ?? 0), 0), s = i[0], c = -Infinity;
	for (let e of i) {
		let t = Object.keys(a[e]).length === 1 && (Object.values(a[e])[0] ?? 0) === 1 ? -1 : 2 * (r.collected[e] ?? 0) + o(e);
		t > c && (c = t, s = e);
	}
	return {
		type: "placeNotebook",
		color: s
	};
}
var je = (e, t) => {
	let n = e.public;
	if (n.phase === "done") return null;
	if (n.phase === "side") {
		let n = De(e, t);
		return n ? { action: n } : null;
	}
	if (n.actor !== t.rid) return null;
	if (n.phase === "place") return { action: Oe(e, t) };
	if (n.phase === "gather") return { action: ke(e, t) };
	let r = Ae(e, t);
	return r ? { action: r } : null;
}, Me = {
	green: "games.amanite.colorGreen",
	blue: "games.amanite.colorBlue",
	pink: "games.amanite.colorPink",
	white: "games.amanite.colorWhite",
	red: "games.amanite.colorRed",
	yellow: "games.amanite.colorYellow"
}, Ne = (e, t, n) => {
	let r = (e) => n(Me[e]), i = (e) => e === "pig" ? n("games.amanite.colorPig") : r(e);
	switch (e.type) {
		case "chooseSide": {
			let i = t.private?.myCard.options[e.side];
			return n("games.amanite.hintSide", { colors: i ? i.map(r).join("·") : "" });
		}
		case "placeMeeple": return n("games.amanite.hintPlace", { n: e.tile + 1 });
		case "choosePile": return n("games.amanite.hintPile", { pile: n(e.pile === 0 ? "games.amanite.pileTop" : "games.amanite.pileBottom") });
		case "takeTwo": return n("games.amanite.hintTake", { tokens: e.tokens.map(i).join("·") });
		case "discardPigs": return n("games.amanite.hintDiscard", { tokens: e.tokens.map(r).join("·") });
		case "placeNotebook": return n("games.amanite.hintNotebook", { color: r(e.color) });
		default: return "";
	}
}, Pe = {
	neg1: "games.amanite.attrNeg1",
	v1: "games.amanite.attrV1",
	v2: "games.amanite.attrV2",
	v3: "games.amanite.attrV3",
	v8: "games.amanite.attrV8",
	elixir: "games.amanite.attrElixir",
	v10: "games.amanite.attrV10",
	v12: "games.amanite.attrV12",
	antidote: "games.amanite.attrAntidote",
	poison: "games.amanite.attrPoison",
	pair: "games.amanite.attrPair",
	clash: "games.amanite.attrClash",
	pig: "games.amanite.colorPig"
};
function Fe({ public: e, rid: t }) {
	let n = o(), r = e.result;
	if (!r) return null;
	let i = r.breakdown[t] ?? [], a = r.eliminated.includes(t);
	return /* @__PURE__ */ f("div", {
		className: "am-result-breakdown mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] font-bold",
		children: [a && /* @__PURE__ */ d("span", {
			className: "text-rose-600",
			children: n("games.amanite.eliminatedLabel")
		}), i.map((e, t) => /* @__PURE__ */ f("span", {
			className: "am-result-item flex items-center gap-0.5",
			children: [
				/* @__PURE__ */ d("span", {
					className: "am-result-icon inline-flex size-5 items-center justify-center [&_.am-token-art]:size-5 [&_.am-token-art]:[filter:none]",
					children: e.kind === "pig" ? /* @__PURE__ */ d(Y, { type: "pig" }) : (() => {
						let t = _.find((t) => r.attrs[t] === e.kind);
						return t ? /* @__PURE__ */ d(Y, { type: t }) : /* @__PURE__ */ f("svg", {
							viewBox: "0 0 24 24",
							className: "size-5",
							"aria-hidden": !0,
							children: [/* @__PURE__ */ d("circle", {
								cx: "12",
								cy: "12",
								r: "11",
								fill: "#f6d763",
								stroke: "#24215f",
								strokeWidth: "2"
							}), e.kind === "pair" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
								cx: "8",
								cy: "12",
								r: "3",
								fill: "#24215f"
							}), /* @__PURE__ */ d("circle", {
								cx: "16",
								cy: "12",
								r: "3",
								fill: "#24215f"
							})] }) : e.kind === "clash" ? /* @__PURE__ */ d("path", {
								d: "M7 7L17 17M17 7L7 17",
								stroke: "#24215f",
								strokeWidth: "3",
								strokeLinecap: "round"
							}) : /* @__PURE__ */ d("path", {
								d: "M6 16L10 10L13 13L18 6",
								fill: "none",
								stroke: "#24215f",
								strokeWidth: "2.5",
								strokeLinecap: "round",
								strokeLinejoin: "round"
							})]
						});
					})()
				}),
				/* @__PURE__ */ d("span", {
					className: "text-ink/50",
					children: n(Pe[e.kind] ?? "games.amanite.attrPair")
				}),
				/* @__PURE__ */ d("span", {
					className: `font-mono tabular-nums ${e.n < 0 ? "text-rose-600" : ""}`,
					children: e.n > 0 ? `+${e.n}` : e.n
				})
			]
		}, t))]
	});
}
//#endregion
//#region src/games/amanite/game-over.tsx
function Ie({ hintCount: e, result: t, public: n, members: r, myRid: i, onPlayAgain: a, onBackToLobby: o }) {
	return /* @__PURE__ */ d("div", {
		className: "am-over",
		children: /* @__PURE__ */ d(p, {
			hintCount: e,
			result: t,
			members: r,
			myRid: i,
			accent: g.accent,
			onPlayAgain: a,
			onBackToLobby: o,
			renderRowExtra: (e) => /* @__PURE__ */ d(Fe, {
				public: n,
				rid: e,
				myRid: i
			})
		})
	});
}
//#endregion
//#region src/games/amanite/options.tsx
var Le = {
	recommended: "games.amanite.optAttrsRec",
	random: "games.amanite.optAttrsRandom"
};
function Re({ value: e, onChange: t }) {
	let n = o(), r = w.safeParse(e), i = r.success ? r.data : w.parse(void 0);
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ d(h, {
			title: n("games.amanite.optAttrs"),
			columns: 2,
			children: ["recommended", "random"].map((e) => /* @__PURE__ */ d(m, {
				name: "amanite-attrs",
				value: e,
				checked: i.attrs === e,
				label: n(Le[e]),
				accent: g.accent,
				onChange: () => t({
					...i,
					attrs: e
				})
			}, e))
		}), /* @__PURE__ */ d("p", {
			className: "text-xs text-ink/60",
			children: n("games.amanite.optAttrsHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/amanite/entry.tsx
var ze = {
	definition: le,
	View: _e,
	bot: je,
	describe: Ne,
	OverView: Ie,
	RowView: Fe,
	Options: Re,
	locales: {
		zh: {
			name: "鹅膏菌",
			desc: "推断六种蘑菇的秘密属性,采对蘑菇、避开毒菇",
			rules: "目标:三轮结束后,凭收集的圆片获得最多胜利分;毒菇太多会被淘汰。\n准备:\n· 六种颜色的蘑菇各秘密对应一个属性,开局无人知道对应关系。\n· 每人从起始牌三种颜色对应的牌叠各抽一张线索牌,洗混后查看。\n· 本局使用六个属性,毒菇与解药必定入选。\n· 森林板块数量比玩家人数多一块。\n流程:\n· 每轮开始:每块森林板块放圆片,第一至三轮分别放 4、5、6 个。\n· 进入森林：从先手开始轮流放置米宝,共两轮;在空板块上须放在左侧位置；板块已有一名玩家时，须放在右侧位置。\n· 放到右格时,立即把该板块的圆片分成两堆,两堆各至少一个。\n· 同一玩家的两个米宝不能放在同一块板块。\n· 采集：从最左侧的森林板块开始，逐块结算。板块上有两名玩家时，左侧位置的玩家先选择一堆圆片，右侧位置的玩家获得另一堆。\n· 只有一人时,该玩家自选两个圆片拿走,其余圆片放回袋中；没有玩家的板块上的圆片全部放回袋中。\n· 领取线索：第一、二轮结束后,从回合顺序中的末位玩家开始，每名玩家依次把笔记标记放到一张蘑菇卡上,抽一张线索牌。\n· 两人局每张蘑菇卡只有一个笔记格。\n· 第三轮结束后直接结算,不再领取线索。\n猪:每收集一个猪圆片,立即从自己已收集的圆片中弃掉一个蘑菇圆片。\n结算:\n· 毒菇数量多于解药加灵药之和,或梯度菇达到四个,立即淘汰。\n· 毒菇与解药或灵药配对,每对获得5分;解药与灵药自动成对,每对扣除3分。\n其余属性按卡面计分：\n· 对子菇：恰好有两个时，获得8分。\n· 多数菇：数量最多的玩家获得10分，数量次多的玩家获得4分。\n· 每个猪圆片获得3分;平分时蘑菇圆片总数最少者获胜,若仍然相同，则共享胜利。",
			round: "第 {{n}} 轮",
			roundShort: "{{n}}/3",
			sidePrompt: "选择起始牌的一面",
			sideWaiting: "等待其他人选择起始牌…",
			chooseSideAria: "选择这一面",
			placePrompt: "放置米宝:点选一块森林板块",
			placeSecondPrompt: "放置第二个米宝:点选一块森林板块",
			placeWaiting: "等待 {{name}} 放置米宝…",
			splitPrompt: "把该板块的圆片分成两堆,两堆各至少一个",
			splitInvalid: "两堆都需要至少一个圆片",
			splitConfirm: "确认分堆",
			pileTop: "上堆",
			pileBottom: "下堆",
			choosePilePrompt: "选择一堆圆片拿走",
			choosePileWaiting: "等待 {{name}} 挑选圆片堆…",
			takePrompt: "从板块上拿走 {{n}} 个圆片",
			takeWaiting: "等待 {{name}} 采集圆片…",
			pigPrompt: "猪吃掉了蘑菇:弃掉 {{n}} 个蘑菇圆片",
			pigWaiting: "等待 {{name}} 弃置蘑菇…",
			notebookPrompt: "把笔记标记放到一张蘑菇卡上,抽取该色线索",
			notebookWaiting: "等待 {{name}} 领取线索…",
			resolving: "结算中…",
			hintsTitle: "我的线索",
			startHintsLabel: "开局线索(顺序已打乱)",
			knownHintsLabel: "已确认颜色",
			collectedLabel: "收获",
			deckLeft: "剩 {{n}} 张",
			spacesLabel: "笔记 {{used}}/{{total}}",
			confirm: "确认",
			cancel: "取消",
			close: "关闭",
			cardsLabel: "蘑菇卡",
			forestLabel: "森林",
			tileLabel: "林地 {{n}}",
			stakeSlot: "钉位",
			scissorsSlot: "剪刀位",
			tapToPlace: "放置米宝",
			tapToSplit: "分堆进林",
			meeplesLeft: "本轮剩余米宝: {{n}}",
			notebooksLeft: "剩余笔记标记: {{n}}",
			sideFront: "正面",
			sideBack: "背面",
			eliminatedLabel: "淘汰",
			breakdownTotal: "总计",
			optAttrs: "属性组合",
			optAttrsRec: "首局推荐",
			optAttrsRandom: "随机",
			optAttrsHint: "六个属性必含毒菇与解药;随机模式再从其余八种中抽四种",
			colorGreen: "绿菇",
			colorBlue: "蓝菇",
			colorPink: "粉菇",
			colorWhite: "白菇",
			colorRed: "红菇",
			colorYellow: "黄菇",
			colorPig: "猪",
			attrNeg1: "扣分菇",
			attrV1: "一分菇",
			attrV2: "两分菇",
			attrV3: "三分菇",
			attrV8: "对子菇",
			attrElixir: "灵药",
			attrV10: "多数菇",
			attrV12: "梯度菇",
			attrAntidote: "解药",
			attrPoison: "毒菇",
			attrPair: "毒菇配对",
			attrClash: "解药灵药相冲",
			attrNeg1Desc: "每个扣 1 分",
			attrV1Desc: "每个 1 分",
			attrV2Desc: "每个 2 分",
			attrV3Desc: "每个 3 分",
			attrV8Desc: "恰好两个时获得 8 分",
			attrElixirDesc: "与毒菇配对得分,与解药成对扣分",
			attrV10Desc: "最多者 10 分,其次 4 分",
			attrV12Desc: "0/1/2/3 个得 -5/0/3/12 分,四个淘汰",
			attrAntidoteDesc: "与毒菇配对得分,与灵药成对扣分",
			attrPoisonDesc: "多于解药加灵药之和则淘汰",
			errNotYourTurn: "现在轮不到你",
			errBadTile: "这块板块不能放",
			errBadSplit: "分堆不合法:两堆各至少一个",
			errBadTokens: "圆片选择不合法",
			errNoNotebook: "没有可用的笔记标记",
			errNoSpace: "这张蘑菇卡没有空笔记格",
			hintSide: "选择这一面:{{colors}}",
			hintPlace: "把米宝放到第 {{n}} 块板块",
			hintPile: "拿走{{pile}}",
			hintTake: "拿走 {{tokens}}",
			hintDiscard: "弃掉 {{tokens}}",
			hintNotebook: "把笔记标记放到{{color}}卡上"
		},
		en: {
			name: "Amanite",
			desc: "Deduce the secret attribute of each mushroom color and gather the right ones",
			rules: "Goal: after three rounds, score the most victory points from collected tokens; too many Poison mushrooms means elimination.\nSetup:\n· Each of the six mushroom colors secretly matches one attribute; nobody knows the mapping.\n· Each player draws one hint card from each deck of the three colors on their Start card, shuffles them, then looks.\n· Six attributes are used; Poison and Antidote are always included.\n· There is one more Forest tile than players.\nPlay:\n· At the start of each round, place tokens on every Forest tile: 4, 5, then 6 in rounds 1-3.\n· Venture: take turns placing meeples for two passes; an empty tile takes the left space, an occupied tile the right.\n· Placing on the right space immediately splits that tile's tokens into two piles of at least one.\n· Your two meeples can never share the same tile.\n· Gathering: resolve Forest tiles from left to right. With two meeples on a tile, the player on the left chooses one pile, and the player on the right takes the other.\n· With one meeple, that player takes exactly two tokens of their choice and the rest return to the bag.\n· Hints: after rounds one and two, from last in turn order each player places a Notebook token on a Mushroom card and draws a hint.\n· With two players, each Mushroom card has only one Notebook space.\n· No hints are collected after round three; the game ends instead.\nPigs: for each Pig token collected, immediately discard one Mushroom token from your collection.\nScoring:\n· More Poison than Antidote plus Elixir, or four of the gradient mushroom, means elimination.\n· Each Poison paired with an Antidote or Elixir scores 5; each Antidote-Elixir pair costs 3.\nScore remaining attributes as printed:\n· The pair mushroom scores 8 points if you have exactly two.\n· For the majority mushroom, the player with the most scores 10 points, and the player with the second-most scores 4 points.\n· Each Pig token scores 3; ties go to the fewest Mushroom tokens, further ties share the win.",
			round: "Round {{n}}",
			roundShort: "{{n}}/3",
			sidePrompt: "Choose a side of your Start card",
			sideWaiting: "Waiting for others to choose a side…",
			chooseSideAria: "Choose this side",
			placePrompt: "Place a meeple: tap a Forest tile",
			placeSecondPrompt: "Place your second meeple: tap a Forest tile",
			placeWaiting: "Waiting for {{name}} to place a meeple…",
			splitPrompt: "Split the tokens on this tile into two piles of at least one",
			splitInvalid: "Both piles need at least one token",
			splitConfirm: "Confirm split",
			pileTop: "Top pile",
			pileBottom: "Bottom pile",
			choosePilePrompt: "Pick one pile to take",
			choosePileWaiting: "Waiting for {{name}} to pick a pile…",
			takePrompt: "Take {{n}} tokens from this tile",
			takeWaiting: "Waiting for {{name}} to gather…",
			pigPrompt: "The pigs ate a mushroom: discard {{n}} Mushroom tokens",
			pigWaiting: "Waiting for {{name}} to discard mushrooms…",
			notebookPrompt: "Place a Notebook token on a Mushroom card to draw its hint",
			notebookWaiting: "Waiting for {{name}} to collect a hint…",
			resolving: "Resolving…",
			hintsTitle: "My hints",
			startHintsLabel: "Opening hints (order shuffled)",
			knownHintsLabel: "Confirmed colors",
			collectedLabel: "Collection",
			deckLeft: "{{n}} left",
			spacesLabel: "Notebooks {{used}}/{{total}}",
			confirm: "Confirm",
			cancel: "Cancel",
			close: "Close",
			cardsLabel: "Mushroom cards",
			forestLabel: "Forest",
			tileLabel: "Tile {{n}}",
			stakeSlot: "Stake",
			scissorsSlot: "Scissors",
			tapToPlace: "Place meeple",
			tapToSplit: "Split and enter",
			meeplesLeft: "Meeples left this round: {{n}}",
			notebooksLeft: "Notebook tokens left: {{n}}",
			sideFront: "Front",
			sideBack: "Back",
			eliminatedLabel: "Eliminated",
			breakdownTotal: "Total",
			optAttrs: "Attribute set",
			optAttrsRec: "First game",
			optAttrsRandom: "Random",
			optAttrsHint: "Poison and Antidote are always included; Random draws four more from the other eight",
			colorGreen: "Green",
			colorBlue: "Blue",
			colorPink: "Pink",
			colorWhite: "White",
			colorRed: "Red",
			colorYellow: "Yellow",
			colorPig: "Pig",
			attrNeg1: "-1 mushroom",
			attrV1: "1-point mushroom",
			attrV2: "2-point mushroom",
			attrV3: "3-point mushroom",
			attrV8: "Pair mushroom",
			attrElixir: "Elixir",
			attrV10: "Majority mushroom",
			attrV12: "Gradient mushroom",
			attrAntidote: "Antidote",
			attrPoison: "Poison",
			attrPair: "Poison pairs",
			attrClash: "Antidote-Elixir clash",
			attrNeg1Desc: "Scores -1 each",
			attrV1Desc: "Scores 1 each",
			attrV2Desc: "Scores 2 each",
			attrV3Desc: "Scores 3 each",
			attrV8Desc: "Scores 8 for exactly two",
			attrElixirDesc: "Pairs with Poison to score; pairs with Antidote to lose points",
			attrV10Desc: "10 for the most, 4 for the second most",
			attrV12Desc: "Scores -5/0/3/12 for 0/1/2/3; four means elimination",
			attrAntidoteDesc: "Pairs with Poison to score; pairs with Elixir to lose points",
			attrPoisonDesc: "More than Antidote plus Elixir means elimination",
			errNotYourTurn: "Not your move right now",
			errBadTile: "Cannot place on that tile",
			errBadSplit: "Invalid split: both piles need at least one token",
			errBadTokens: "Invalid token selection",
			errNoNotebook: "No Notebook tokens left",
			errNoSpace: "No free Notebook space on that Mushroom card",
			hintSide: "Choose this side: {{colors}}",
			hintPlace: "Place your meeple on tile {{n}}",
			hintPile: "Take the {{pile}}",
			hintTake: "Take {{tokens}}",
			hintDiscard: "Discard {{tokens}}",
			hintNotebook: "Place your Notebook on the {{color}} card"
		}
	}
};
//#endregion
export { ze as default };
