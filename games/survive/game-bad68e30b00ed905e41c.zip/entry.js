import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o, useFxAnchorsMaybe as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconClose as u, IconRecenter as d } from "@bgparty/sdk/icons";
import { useWakeLock as f } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { SheetFxProbe as v, SheetView as y } from "@bgparty/sdk/sheet-view";
import { FlySprite as b, PulseBox as te } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/survive/meta.ts
var C = {
	id: "survive",
	tier: "alpha",
	mechanics: [
		"grid-movement",
		"action-points",
		"race",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.survive.name",
	descKey: "games.survive.desc",
	rulesKey: "games.survive.rules",
	icon: "🌋",
	iconImg: "games/survive.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/14884808387312904706/3336DE41459F02FEF7BF93FA898DE530ACA3B792/" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#1676ad",
	releasedAt: "2026-11-04T01:12:10+08:00",
	search: {
		py: "tao li jue ming dao",
		init: "tljmd"
	},
	hotseat: "cover"
}, ne = t.enum([
	"serpent",
	"shark",
	"kaiju",
	"kraken",
	"pterodactyl",
	"whale"
]), w = t.enum([
	"paddle",
	"dolphin",
	"dive",
	"die",
	"repellent",
	"piranha"
]), re = t.enum([
	"green",
	"blue",
	"raft",
	"whirlpool",
	"volcano",
	"egg",
	"piranha",
	"paddle",
	"dolphin",
	"dive",
	"die",
	"repellent"
]), T = t.object({
	red: t.enum([
		"serpent",
		"kraken",
		"both"
	]).default("serpent"),
	green: t.enum([
		"shark",
		"pterodactyl",
		"both"
	]).default("shark"),
	blue: t.enum([
		"kaiju",
		"whale",
		"both"
	]).default("kaiju"),
	piranha: t.boolean().default(!1),
	eggs: t.boolean().default(!1),
	bff: t.boolean().default(!1)
}).default({
	red: "serpent",
	green: "shark",
	blue: "kaiju",
	piranha: !1,
	eggs: !1,
	bff: !1
}), E = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().min(1).max(220)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), ie = t.enum([
	"place",
	"raftPlace",
	"move",
	"raftMove",
	"sink",
	"roll",
	"creature",
	"step",
	"stop",
	"spawn",
	"egg",
	"board",
	"attack",
	"repel",
	"pass",
	"pushPerson",
	"pushCreature",
	"pushTo",
	"kraken",
	"abilityPaddle",
	"abilityDolphin",
	"abilityDive",
	"abilityDie",
	"abilityPiranha",
	"end"
]), ae = t.object({
	id: t.string(),
	kind: ie,
	entity: t.string().optional(),
	cell: t.string().optional(),
	card: t.string().optional(),
	target: t.string().optional()
}), oe = t.object({
	id: t.string(),
	owner: t.string(),
	team: t.int().min(0).max(4),
	heart: t.boolean(),
	cell: t.string().nullable(),
	raft: t.string().nullable(),
	status: t.enum([
		"reserve",
		"alive",
		"rescued",
		"dead"
	])
}), se = t.object({
	id: t.string(),
	kind: ne,
	cell: t.string().nullable()
}), ce = t.object({
	id: t.string(),
	cell: t.string().nullable()
}), le = t.enum([
	"sea",
	"beach",
	"forest",
	"mountain",
	"volcano",
	"piranha"
]), D = t.object({
	id: t.string(),
	terrain: le
}), ue = t.object({
	rid: t.string(),
	treasure: t.int(),
	bff: t.int(),
	total: t.int(),
	rescued: t.int(),
	lost: t.int(),
	values: t.array(t.object({
		id: t.string(),
		value: t.int(),
		team: t.int(),
		heart: t.boolean()
	}))
}), de = t.object({
	players: t.array(t.object({
		rid: t.string(),
		teams: t.array(t.int()),
		cards: t.int()
	})).min(2).max(5),
	active: t.string(),
	actor: t.string(),
	phase: t.enum([
		"setup",
		"rafts",
		"action",
		"sinking",
		"roll",
		"creatures",
		"done"
	]),
	turn: t.int(),
	moves: t.int(),
	tiles: t.int(),
	volcanoes: t.int(),
	die: t.enum([
		"red",
		"green",
		"blue"
	]).nullable(),
	cells: t.array(D),
	people: t.array(oe),
	rafts: t.array(ce),
	creatures: t.array(se),
	eggs: t.array(t.object({
		id: t.string(),
		owner: t.string(),
		cell: t.string(),
		turn: t.int()
	})),
	config: T,
	busy: t.boolean(),
	prompt: t.string(),
	promptCell: t.string().nullable(),
	promptEntity: t.string().nullable(),
	swum: t.array(t.string()),
	last: t.object({
		cell: t.string(),
		back: re.nullable(),
		serial: t.int()
	}).nullable(),
	scores: t.array(ue),
	setupRafts: t.record(t.string(), t.int())
}), O = t.object({
	id: t.string(),
	kind: w
}), fe = t.object({
	abilities: t.array(O),
	values: t.array(t.object({
		id: t.string(),
		value: t.int()
	})),
	choices: t.array(ae)
}), k = [
	[1, 0],
	[0, 1],
	[-1, 1],
	[-1, 0],
	[0, -1],
	[1, -1]
], A = (e, t) => `${e},${t}`, j = Array.from({ length: 13 }, (e, t) => {
	let n = t - 6, r = Math.abs(n) === 6 ? 6 : Math.abs(n) % 2 == 1 ? 9 : 10;
	return Array.from({ length: r + 1 }, (e, t) => {
		let i = -r + 2 * t, a = (i - n) / 2;
		return {
			id: A(a, n),
			q: a,
			r: n,
			x: 650 + i * 51,
			y: 700 + n * 88.3346
		};
	});
}).flat(), M = Object.fromEntries(j.map((e) => [e.id, e])), N = [
	{
		id: "nw",
		x: 110,
		y: 130,
		links: [A(-2, -5), A(-3, -4)]
	},
	{
		id: "ne",
		x: 1190,
		y: 130,
		links: [A(7, -5), A(7, -4)]
	},
	{
		id: "sw",
		x: 110,
		y: 1270,
		links: [A(-7, 5), A(-7, 4)]
	},
	{
		id: "se",
		x: 1190,
		y: 1270,
		links: [A(2, 5), A(3, 4)]
	}
], pe = j.filter((e) => {
	let t = e.q * 2 + e.r, n = Math.abs(e.r);
	return n === 3 ? Math.abs(t) <= 3 : n === 2 ? Math.abs(t) <= 4 : n === 1 ? Math.abs(t) <= 7 : n === 0 && t !== 0 && Math.abs(t) <= 6;
}).map((e) => e.id), P = [
	A(-2, -5),
	A(0, 0),
	A(7, -4),
	A(-7, 4),
	A(2, 5)
], F = [
	A(-1, -5),
	A(6, -5),
	A(-6, 5),
	A(1, 5)
];
function I(e, t = !1) {
	let n = M[e];
	if (!n) return N.find((t) => t.id === e)?.links ?? [];
	let r = k.map(([e, t]) => A(n.q + e, n.r + t)).filter((e) => !!M[e]);
	return t ? [...r, ...N.filter((t) => t.links.includes(e)).map((e) => e.id)] : r;
}
var L = (e) => N.some((t) => t.id === e), R = (e, t) => e.cells.find((e) => e.id === t)?.terrain, z = (e, t) => ["sea", "piranha"].includes(R(e, t) ?? ""), B = (e, t) => e.people.filter((e) => e.status === "alive" && e.cell === t), V = (e, t, n) => e.creatures.some((e) => e.kind === "kaiju" && e.cell === t && e.id !== n), H = (e, t) => e.rafts.find((e) => e.cell === t), U = (e, t) => e.people.filter((e) => e.status === "alive" && e.raft === t);
function me(e, t, n) {
	let r = e.players.map((t) => U(e, n).filter((e) => e.owner === t.rid).length);
	return r[e.players.findIndex((e) => e.rid === t)] >= Math.max(...r);
}
function W(e, t) {
	return L(t) || !!R(e, t) && R(e, t) !== "volcano" && !V(e, t);
}
function he(e, t) {
	return t.status === "alive" && !!t.cell && z(e, t.cell) && !t.raft;
}
function ge(e, t, n) {
	let r = H(e, n), i = !!r && U(e, r.id).length < 3;
	return he(e, t) || z(e, n) && !i;
}
var _e = (e) => e === "serpent" || e === "kraken" ? "red" : e === "shark" || e === "pterodactyl" ? "green" : "blue", ve = (e) => e === "serpent" || e === "kraken" ? 1 : e === "whale" ? 3 : 2;
function ye(e, t, n, r) {
	let i = M[n];
	if (!i) return [];
	if (t === "pterodactyl") {
		let t = [];
		for (let [n, r] of k) for (let a = 1; a < 15; a++) {
			let o = A(i.q + n * a, i.r + r * a);
			if (!M[o]) break;
			R(e, o) !== "volcano" && !V(e, o) && B(e, o).length <= 1 && t.push(o);
		}
		return t;
	}
	return I(n).filter((n) => t === "kaiju" ? R(e, n) !== "volcano" : z(e, n) && !V(e, n, r));
}
function be(e, t) {
	let n = M[e], r = M[t];
	return !n || !r ? 0 : (Math.abs(n.q - r.q) + Math.abs(n.r - r.r) + Math.abs(n.q + n.r - r.q - r.r)) / 2;
}
function G(e, t) {
	let n = e.people.find((e) => e.id === t), r = e.rafts.find((e) => e.id === t), i = e.creatures.find((e) => e.id === t), a = e.eggs.find((e) => e.id === t), o = n?.cell ?? r?.cell ?? i?.cell ?? a?.cell;
	if (!o) return null;
	let s = M[o] ?? N.find((e) => e.id === o);
	if (!s) return null;
	if (n) {
		let t = e.people.filter((e) => (e.status === "alive" || e.status === "rescued") && e.cell === o).indexOf(n);
		return {
			cell: o,
			x: s.x - 15 + (t % 3 - 1) * 23,
			y: s.y - 39 + Math.floor(t / 3) * 25 - xe(e, o),
			w: 30,
			h: 39
		};
	}
	if (r) return {
		cell: o,
		x: s.x - 42,
		y: s.y - 16,
		w: 84,
		h: 62
	};
	if (a) return {
		cell: o,
		x: s.x - 16,
		y: s.y - 25,
		w: 32,
		h: 39
	};
	let c = e.creatures.filter((e) => e.cell === o).findIndex((e) => e.id === t);
	return {
		cell: o,
		x: s.x - 42 + c % 2 * 23,
		y: s.y - 42 + Math.floor(c / 2) * 20,
		w: 84,
		h: 84
	};
}
var xe = (e, t) => R(e, t) === "mountain" ? 21 : R(e, t) === "forest" ? 13 : R(e, t) === "beach" ? 6 : 0, K = {
	move: 480,
	reveal: 720,
	attack: 640,
	die: 650,
	card: 520,
	turn: 260
}, Se = () => ({ code: "games.survive.errorAction" }), Ce = [
	"paddle",
	"dolphin",
	"dive",
	"die",
	"repellent",
	"piranha"
], q = (e, t, n, r, i) => ({
	id: [
		e,
		t ?? "",
		n ?? "",
		r ?? "",
		i ?? ""
	].join(":"),
	kind: e,
	...t === void 0 ? {} : { entity: t },
	...n === void 0 ? {} : { cell: n },
	...r === void 0 ? {} : { card: r },
	...i === void 0 ? {} : { target: i }
}), we = (e) => e.tasks[0]?.kind === "respond" ? e.tasks[0].responders[0] : e.public.active;
function Te(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Ee(e) {
	let t = e.public, n = e.tasks[0];
	t.busy = e.beat > 0, t.actor = we(e) ?? t.active, t.prompt = n?.kind ?? t.phase, t.promptCell = n && "cell" in n ? n.cell : null, t.promptEntity = n && "entity" in n ? n.entity : null;
	for (let n of t.players) n.cards = e.hands[n.rid].length;
}
function J(e, t, n, r, i = K.move, a = e.public.active) {
	t.push({
		kind: n,
		rid: a,
		data: r,
		...t.length ? { with: !0 } : {}
	}), e.beat = Math.max(e.beat, i);
}
function De(e, t, n) {
	let r = e.public.people.find((e) => e.id === n);
	r.status === "alive" && (J(e, t, "lost", {
		id: n,
		cell: r.cell,
		team: r.team,
		piece: "person",
		heart: r.heart,
		source: G(e.public, n)
	}, K.attack), r.status = "dead", r.cell = null, r.raft = null);
}
function Oe(e, t, n) {
	let r = e.public.creatures.find((e) => e.id === n);
	r.cell && J(e, t, "lost", {
		id: n,
		cell: r.cell,
		piece: r.kind,
		source: G(e.public, n)
	}, K.attack), r.cell = null;
}
function ke(e, t, n) {
	let r = e.public.rafts.find((e) => e.id === n);
	r.cell && J(e, t, "lost", {
		id: n,
		cell: r.cell,
		piece: "raft",
		source: G(e.public, n)
	}, K.attack);
	for (let t of U(e.public, n)) t.raft = null;
	r.cell = null;
}
function Ae(e, t, n) {
	for (let r of B(e.public, n)) De(e, t, r.id);
	for (let r of e.public.creatures.filter((e) => e.cell === n)) Oe(e, t, r.id);
	for (let r of e.public.rafts.filter((e) => e.cell === n)) ke(e, t, r.id);
	for (let r of e.public.eggs.filter((e) => e.cell === n)) J(e, t, "lost", {
		id: r.id,
		cell: n,
		piece: "egg",
		source: G(e.public, r.id)
	}, K.attack);
	e.public.eggs = e.public.eggs.filter((e) => e.cell !== n);
}
function je(e) {
	let t = e.public;
	t.scores = t.players.map((n) => {
		let r = t.people.filter((e) => e.owner === n.rid && e.status === "rescued"), i = r.filter((e) => !e.heart).reduce((t, n) => t + e.values[n.id], 0), a = n.teams.reduce((e, t) => e + (r.filter((e) => e.team === t && e.heart).length === 2 ? 12 : 0), 0);
		return {
			rid: n.rid,
			treasure: i,
			bff: a,
			total: i + a,
			rescued: r.length,
			lost: t.people.filter((e) => e.owner === n.rid && e.status !== "rescued").length,
			values: r.map((t) => ({
				id: t.id,
				team: t.team,
				heart: t.heart,
				value: t.heart ? 0 : e.values[t.id]
			}))
		};
	});
}
function Me(e) {
	return e.beat || e.public.phase === "setup" || e.public.phase === "rafts" || e.public.volcanoes < 3 && e.public.people.some((e) => e.status === "alive") ? !1 : (e.public.phase = "done", e.tasks = [], e.beat = 0, je(e), Ee(e), !0);
}
function Ne(e, t, n, r) {
	let i = e.public.people.find((e) => e.id === n), a = i.cell, o = G(e.public, n);
	i.cell = r, i.raft = null, L(r) && (i.status = "rescued"), J(e, t, L(r) ? "rescue" : "move", {
		id: n,
		from: a,
		to: r,
		piece: "person",
		team: i.team,
		heart: i.heart,
		source: o
	});
}
function Pe(e) {
	let t = e.public;
	t.phase = "action", t.moves = 3, t.swum = [], t.die = null, t.tiles = t.people.some((e) => e.owner === t.active && e.status === "alive") ? 1 : 2, e.tasks.push(...t.eggs.filter((e) => e.owner === t.active && e.turn < t.turn).map((e) => ({
		kind: "hatch",
		id: e.id
	})));
}
function Fe(e) {
	let t = e.public;
	t.active = t.players[(t.players.findIndex((e) => e.rid === t.active) + 1) % t.players.length].rid, t.turn++, Pe(e);
}
function Ie(e, t, n) {
	let r = e.public, i = r.creatures.find((e) => e.id === t);
	if (!i || i.cell !== n) return !1;
	let a = B(r, n), o = r.rafts.some((e) => e.cell === n);
	return i.kind === "shark" ? a.some((e) => !e.raft) : i.kind === "whale" ? o : i.kind === "kaiju" ? a.length > 0 || o || r.creatures.some((e) => e.cell === n && e.id !== t) : i.kind === "kraken" ? a.some((e) => !e.raft) : a.length > 0 || i.kind === "serpent" && o;
}
function Le(e, t, n) {
	let r = e.public, i = r.creatures.find((e) => e.id === t), a = r.players.map((e, t) => r.players[(r.players.findIndex((e) => e.rid === r.active) + t) % r.players.length].rid), o = i.kind === "shark" || i.kind === "kaiju" ? a.filter((e) => B(r, n).some((t) => t.owner === e)) : [];
	e.tasks.unshift({
		kind: "respond",
		entity: t,
		cell: n,
		responders: o
	});
}
function Re(e, t, n) {
	let r = e.public.creatures.filter((e) => _e(e.kind) === t), i = r.filter((e) => e.cell === null);
	return (i.length ? i.filter((e, t) => i.findIndex((t) => t.kind === e.kind) === t) : r).filter((t) => !V(e.public, n, t.id) || t.kind === "kaiju");
}
function ze(e, t) {
	let n = e.public, r = [];
	if (t.mode === "creature") {
		let e = n.creatures.find((e) => e.id === t.entity);
		e?.cell && (r = ye(n, e.kind, e.cell, e.id));
	} else if (t.mode === "raft") {
		let e = n.rafts.find((e) => e.id === t.entity);
		e?.cell && (r = I(e.cell).filter((e) => z(n, e) && !H(n, e) && !V(n, e)));
	} else {
		let e = n.people.find((e) => e.id === t.entity);
		e?.cell && e.status === "alive" && he(n, e) && (r = I(e.cell, !0).filter((e) => W(n, e)));
	}
	return [...r.map((e) => q("step", t.entity, e)), ...t.started ? [q("stop", t.entity)] : []];
}
function Be(e, t) {
	let n = e.public, r = e.tasks[0];
	if (e.beat || n.phase === "done" || we(e) !== t) return [];
	if (r) {
		if (r.kind === "travel") return ze(e, r);
		if (r.kind === "creature") return n.creatures.filter((e) => e.cell && _e(e.kind) === r.color && ye(n, e.kind, e.cell, e.id).length > 0).map((e) => q("creature", e.id));
		if (r.kind === "spawn") return Re(e, r.color, r.cell).map((e) => q("spawn", e.id, r.cell));
		if (r.kind === "raft") {
			let e = n.rafts.find((e) => e.cell === null);
			return (e ? [e] : n.rafts.filter((e) => !U(n, e.id).length)).map((e) => q("raftPlace", e.id, r.cell));
		}
		return r.kind === "egg" ? n.cells.filter((e) => z(n, e.id)).map((e) => q("egg", void 0, e.id)) : r.kind === "board" ? B(n, r.cell).filter((e) => !e.raft).map((e) => q("board", e.id, r.cell)) : r.kind === "interact" ? r.ids.filter((t) => Ie(e, t, r.cell)).map((e) => q("attack", e, r.cell)) : r.kind === "respond" ? [q("pass"), ...e.hands[t].filter((e) => e.kind === "repellent").map((e) => q("repel", r.entity, r.cell, e.id))] : r.kind === "kraken" ? n.creatures.some((e) => e.id === r.entity && e.kind === "kraken" && e.cell === r.cell) ? n.people.filter((e) => e.status === "alive" && e.cell && [r.cell, ...I(r.cell, !0)].includes(e.cell)).map((e) => q("kraken", e.id, e.cell)) : [] : r.kind === "push" ? [...B(n, r.cell).map((e) => q("pushPerson", e.id, r.cell)), ...n.creatures.filter((e) => e.cell === r.cell && e.id !== r.entity && ye(n, e.kind, r.cell, e.id).length > 0).map((e) => q("pushCreature", e.id, r.cell))] : r.kind === "pushTo" ? I(r.cell, !0).filter((e) => W(n, e)).map((e) => q("pushTo", r.entity, e)) : [];
	}
	if (n.phase === "setup") {
		let e = n.people.filter((e) => e.owner === t && e.status === "reserve"), r = n.cells.filter((e) => pe.includes(e.id)).map((e) => ({
			cell: e.id,
			n: B(n, e.id).length
		})), i = Math.min(...r.map((e) => e.n));
		return e.flatMap((e) => r.filter((e) => e.n === i).map((t) => q("place", e.id, t.cell)));
	}
	if (n.phase === "rafts") return n.cells.filter((e) => z(n, e.id) && !H(n, e.id) && !n.creatures.some((t) => t.cell === e.id) && I(e.id).some((e) => pe.includes(e))).map((e) => q("raftPlace", void 0, e.id));
	if (n.phase === "sinking") {
		let e = [
			"beach",
			"forest",
			"mountain"
		].find((e) => n.cells.some((t) => t.terrain === e));
		return n.cells.filter((t) => t.terrain === e).map((e) => q("sink", void 0, e.id));
	}
	if (n.phase === "roll") return [q("roll")];
	if (n.phase !== "action") return [];
	let i = [q("end")], a = n.people.filter((e) => e.owner === t && e.status === "alive"), o = n.rafts.filter((e) => e.cell && me(n, t, e.id));
	if (a.length && n.moves > 0) {
		for (let e of a) for (let t of I(e.cell, !0)) W(n, t) && !(ge(n, e, t) && n.swum.includes(e.id)) && i.push(q("move", e.id, t));
		for (let e of o) for (let t of I(e.cell)) z(n, t) && !H(n, t) && !V(n, t) && i.push(q("raftMove", e.id, t));
	}
	for (let r of e.hands[t]) {
		if (r.kind === "paddle") for (let t of o) ze(e, {
			kind: "travel",
			entity: t.id,
			mode: "raft",
			left: 2,
			started: !1
		}).length && i.push(q("abilityPaddle", t.id, void 0, r.id));
		if (r.kind === "dolphin") for (let e of a.filter((e) => he(n, e))) I(e.cell, !0).some((e) => W(n, e)) && i.push(q("abilityDolphin", e.id, void 0, r.id));
		if (r.kind === "dive") for (let e of n.creatures.filter((e) => e.cell)) for (let t of n.cells.filter((e) => z(n, e.id) && !B(n, e.id).length && !H(n, e.id) && !n.creatures.some((t) => t.cell === e.id) && !n.eggs.some((t) => t.cell === e.id))) i.push(q("abilityDive", e.id, t.id, r.id));
		if (r.kind === "die" && i.push(q("abilityDie", void 0, void 0, r.id)), r.kind === "piranha") for (let e of n.cells.filter((e) => e.terrain === "sea" && I(e.id).some((e) => R(n, e) === "piranha"))) i.push(q("abilityPiranha", void 0, e.id, r.id));
		if (r.kind === "repellent") for (let e of n.creatures.filter((e) => (e.kind === "shark" || e.kind === "kaiju") && e.cell && B(n, e.cell).some((e) => e.owner === t))) i.push(q("repel", e.id, e.cell, r.id));
	}
	return i;
}
function Ve(e, t) {
	let n = Be(e, t), r = e.public;
	if (e.beat || r.phase === "done" || e.tasks[0]?.kind === "respond") return n;
	for (let i of e.hands[t] ?? []) if (i.kind === "repellent") {
		for (let e of r.creatures) if ((e.kind === "shark" || e.kind === "kaiju") && e.cell && B(r, e.cell).some((e) => e.owner === t)) {
			let t = q("repel", e.id, e.cell, i.id);
			n.some((e) => e.id === t.id) || n.push(t);
		}
	}
	return n;
}
function He(t, n) {
	let r = [
		"red",
		"green",
		"blue"
	][e(t.seed, t.cursor++, 3)];
	return t.public.die = r, J(t, n, "die", { color: r }, K.die), r;
}
function Ue(e, t, n, r) {
	let i = e.public.rafts.find((e) => e.id === n), a = i.cell, o = G(e.public, n);
	i.cell = r;
	let s = U(e.public, n).map((t) => ({
		id: t.id,
		team: t.team,
		heart: t.heart,
		source: G(e.public, t.id)
	}));
	for (let t of U(e.public, n)) t.cell = r;
	J(e, t, "move", {
		id: n,
		piece: "raft",
		from: a,
		to: r,
		riders: s,
		source: o
	});
}
function We(e, t) {
	let n = 0;
	for (; !e.beat && e.tasks.length && !Me(e);) {
		if (++n > 160) throw Error("survive: resolution did not converge");
		let r = e.public, i = e.tasks[0];
		if (i.kind === "cell") {
			if (e.tasks.shift(), R(r, i.cell) === "piranha") {
				Ae(e, t, i.cell);
				continue;
			}
			let n = r.creatures.filter((e) => e.cell === i.cell).map((e) => e.id), a = r.creatures.find((e) => e.id === i.entrant), o = a?.kind === "kaiju" ? [a.id] : n;
			e.tasks.unshift({
				kind: "board",
				cell: i.cell
			}, {
				kind: "interact",
				cell: i.cell,
				ids: o
			});
			continue;
		}
		if (i.kind === "board") {
			let n = H(r, i.cell), a = B(r, i.cell).filter((e) => !e.raft), o = n ? 3 - U(r, n.id).length : 0;
			if (!n || o < 1 || !a.length) {
				e.tasks.shift();
				continue;
			}
			if (a.length <= o) {
				e.tasks.shift();
				for (let r of a) r.raft = n.id, J(e, t, "board", {
					id: r.id,
					cell: i.cell,
					raft: n.id,
					team: r.team,
					heart: r.heart
				});
				continue;
			}
			break;
		}
		if (i.kind === "interact") {
			if (i.ids = i.ids.filter((t) => Ie(e, t, i.cell)), !i.ids.length) {
				e.tasks.shift();
				continue;
			}
			if (i.ids.length === 1) {
				Le(e, i.ids.pop(), i.cell);
				continue;
			}
			break;
		}
		if (i.kind === "respond") {
			let t = r.creatures.find((e) => e.id === i.entity);
			if (i.responders = i.responders.filter((e) => B(r, i.cell).some((t) => t.owner === e)), !t?.cell) {
				e.tasks.shift();
				continue;
			}
			if (i.responders.length) break;
			e.tasks.shift(), e.tasks.unshift({
				kind: "hit",
				entity: i.entity,
				cell: i.cell
			});
			continue;
		}
		if (i.kind === "hit") {
			e.tasks.shift();
			let n = r.creatures.find((e) => e.id === i.entity);
			if (!n || n.cell !== i.cell) continue;
			if (J(e, t, "attack", {
				id: n.id,
				cell: i.cell,
				piece: n.kind,
				source: G(e.public, n.id)
			}, K.attack), [
				"serpent",
				"kaiju",
				"whale"
			].includes(n.kind)) for (let n of r.rafts.filter((e) => e.cell === i.cell)) ke(e, t, n.id);
			if (n.kind === "kaiju") e.tasks.unshift({
				kind: "push",
				entity: n.id,
				cell: i.cell
			});
			else if (n.kind === "whale") e.tasks.unshift({
				kind: "interact",
				cell: i.cell,
				ids: r.creatures.filter((e) => e.cell === i.cell && e.id !== n.id).map((e) => e.id)
			});
			else for (let a of B(r, i.cell)) (n.kind === "serpent" || n.kind === "pterodactyl" || !a.raft) && De(e, t, a.id);
			continue;
		}
		if (i.kind === "pushTo" && !r.creatures.some((e) => e.id === i.source && e.cell === i.cell)) {
			e.tasks.shift();
			continue;
		}
		if (i.kind === "push") {
			if (!r.creatures.some((e) => e.id === i.entity && e.cell === i.cell)) {
				e.tasks.shift();
				continue;
			}
			if (!B(r, i.cell).length && !r.creatures.some((e) => e.cell === i.cell && e.id !== i.entity && ye(r, e.kind, i.cell, e.id).length > 0)) {
				e.tasks.shift();
				continue;
			}
			break;
		}
		if (i.kind === "hatch") {
			e.tasks.shift();
			let n = r.eggs.find((e) => e.id === i.id);
			if (!n) continue;
			let a = He(e, t);
			r.eggs = r.eggs.filter((e) => e.id !== n.id), J(e, t, "hatch", {
				id: n.id,
				cell: n.cell,
				color: a
			}, K.die), e.tasks.unshift({
				kind: "spawn",
				color: a,
				cell: n.cell
			});
			continue;
		}
		if (i.kind === "nextTurn") {
			e.tasks.shift(), Fe(e), J(e, t, "turn", {}, K.turn);
			continue;
		}
		if (i.kind === "travel" && (i.left === 0 || !ze(e, i).some((e) => e.kind === "step"))) {
			e.tasks.shift();
			continue;
		}
		if (i.kind === "spawn" && !Re(e, i.color, i.cell).length) {
			e.tasks.shift();
			continue;
		}
		if (i.kind === "raft" && (H(r, i.cell) || V(r, i.cell) || !r.rafts.some((e) => e.cell === null || !U(r, e.id).length))) {
			e.tasks.shift();
			continue;
		}
		if (i.kind === "creature" && !r.creatures.some((e) => e.cell && _e(e.kind) === i.color && ye(r, e.kind, e.cell, e.id).length)) {
			e.tasks.shift();
			continue;
		}
		if (i.kind === "kraken" && (!r.creatures.some((e) => e.id === i.entity && e.kind === "kraken" && e.cell === i.cell) || !r.people.some((e) => e.status === "alive" && e.cell && [i.cell, ...I(i.cell, !0)].includes(e.cell)))) {
			e.tasks.shift();
			continue;
		}
		break;
	}
	!e.tasks.length && e.public.phase === "sinking" && !e.public.tiles && (e.public.phase = "roll"), Me(e), Ee(e);
}
function Ge(e, t, n) {
	let r = {
		seed: n,
		cursor: 0
	}, i = Te(r, t), a = i.flatMap((e, n) => (t.length === 2 ? [n * 2, n * 2 + 1] : [n]).map((t) => ({
		rid: e,
		team: t
	}))), o = a.flatMap(({ rid: t, team: n }) => Array.from({ length: 10 }, (r, i) => ({
		id: `a${n}-${i}`,
		owner: t,
		team: n,
		heart: e.bff && i < 2,
		cell: null,
		raft: null,
		status: "reserve"
	}))), s = {};
	for (let { team: t } of a) {
		let n = o.filter((e) => e.team === t), i = Te(r, e.bff ? [
			0,
			0,
			2,
			2,
			3,
			3,
			4,
			4,
			5,
			5
		] : [
			1,
			1,
			2,
			2,
			3,
			3,
			4,
			4,
			5,
			5
		]);
		if (e.bff) {
			let e = i.filter((e) => e !== 0);
			n.forEach((t) => {
				s[t.id] = t.heart ? 0 : e.pop();
			});
		} else n.forEach((e, t) => {
			s[e.id] = i[t];
		});
	}
	let c = [
		"green",
		"green",
		"green",
		"blue",
		"blue",
		"blue",
		"raft",
		"paddle",
		"paddle",
		"dolphin",
		"dolphin",
		"dolphin",
		"die",
		"die",
		"repellent",
		"repellent"
	], l = [
		"green",
		"green",
		"green",
		"blue",
		"blue",
		"raft",
		"raft",
		"raft",
		"whirlpool",
		"whirlpool",
		"dolphin",
		"dive",
		"dive",
		"die",
		"die",
		"repellent"
	];
	e.piranha && (c[c.indexOf("die")] = "piranha"), e.eggs && (c[c.indexOf("green")] = "egg", c[c.indexOf("blue")] = "egg");
	let u = Te(r, [
		...c.map((e) => ({
			terrain: "beach",
			back: e
		})),
		...l.map((e) => ({
			terrain: "forest",
			back: e
		})),
		...Array.from({ length: 8 }, (e, t) => ({
			terrain: "mountain",
			back: t < 4 ? "whirlpool" : "volcano"
		}))
	]), d = Object.fromEntries(pe.map((e, t) => [e, u[t].back])), f = [];
	for (let [t, n, r, i, a] of [
		[
			"red",
			"serpent",
			"kraken",
			5,
			4
		],
		[
			"green",
			"shark",
			"pterodactyl",
			6,
			3
		],
		[
			"blue",
			"kaiju",
			"whale",
			2,
			5
		]
	]) {
		let o = e[t];
		for (let e of [n, r]) {
			if (o !== e && o !== "both") continue;
			let r = o === "both" ? e === "serpent" || e === "shark" || e === "whale" ? 3 : 2 : e === n ? i : a;
			for (let n = 0; n < r; n++) f.push({
				id: `${e}${n}`,
				kind: e,
				cell: t === "red" ? o === "both" ? e === "serpent" ? [
					P[1],
					F[0],
					F[3]
				][n] : [F[1], F[2]][n] : (e === "serpent" ? P : F)[n] : null
			});
		}
	}
	return { state: {
		public: {
			players: i.map((e) => ({
				rid: e,
				teams: a.filter((t) => t.rid === e).map((e) => e.team),
				cards: 0
			})),
			active: i[0],
			actor: i[0],
			phase: "setup",
			turn: 1,
			moves: 3,
			tiles: 1,
			volcanoes: 0,
			die: null,
			cells: j.map((e) => ({
				id: e.id,
				terrain: u[pe.indexOf(e.id)]?.terrain ?? "sea"
			})),
			people: o,
			rafts: Array.from({ length: 12 }, (e, t) => ({
				id: `raft${t}`,
				cell: null
			})),
			creatures: f,
			eggs: [],
			config: e,
			busy: !1,
			prompt: "setup",
			promptCell: null,
			promptEntity: null,
			swum: [],
			last: null,
			scores: [],
			setupRafts: Object.fromEntries(i.map((e) => [e, t.length === 2 ? 4 : 2]))
		},
		hands: Object.fromEntries(t.map((e) => [e, []])),
		values: s,
		backs: d,
		seed: n,
		cursor: r.cursor,
		tasks: [],
		beat: 0
	} };
}
function Ke(e, t, n) {
	e.hands[t] = e.hands[t].filter((e) => e.id !== n);
}
function qe(e, t, n, r) {
	let i = e.public, a = e.tasks[0], o = t.cell, s = t.entity, c = s ? G(e.public, s) : null;
	if (t.kind === "place") {
		let t = i.people.find((e) => e.id === s);
		if (t.status = "alive", t.cell = o, J(e, r, "deploy", {
			id: s,
			to: o,
			piece: "person",
			team: t.team,
			heart: t.heart
		}), !i.people.some((e) => e.status === "reserve")) i.phase = "rafts", i.active = i.players[0].rid;
		else do
			i.active = i.players[(i.players.findIndex((e) => e.rid === i.active) + 1) % i.players.length].rid;
		while (!i.people.some((e) => e.owner === i.active && e.status === "reserve"));
	} else if (t.kind === "raftPlace") {
		a?.kind === "raft" && e.tasks.shift();
		let t = s ? i.rafts.find((e) => e.id === s) : i.rafts.find((e) => !e.cell), l = t.cell;
		if (t.cell = o, J(e, r, l ? "move" : "deploy", {
			id: t.id,
			from: l,
			to: o,
			piece: "raft",
			source: c
		}), i.phase === "rafts") {
			if (i.setupRafts[n]--, Object.values(i.setupRafts).every((e) => e === 0)) i.active = i.players[0].rid, Pe(e);
			else do
				i.active = i.players[(i.players.findIndex((e) => e.rid === i.active) + 1) % i.players.length].rid;
			while (!i.setupRafts[i.active]);
		} else e.tasks.unshift({
			kind: "cell",
			cell: o
		});
	} else if (t.kind === "move" || t.kind === "pushTo") {
		let n = i.people.find((e) => e.id === s);
		t.kind === "move" ? (ge(i, n, o) && i.swum.push(n.id), i.moves--) : e.tasks.shift(), Ne(e, r, s, o), L(o) || e.tasks.unshift({
			kind: "cell",
			cell: o
		});
	} else if (t.kind === "raftMove") i.moves--, Ue(e, r, s, o), e.tasks.unshift({
		kind: "cell",
		cell: o
	});
	else if (t.kind === "end") i.phase = "sinking", J(e, r, "turn", {}, K.turn);
	else if (t.kind === "sink") {
		let t = e.backs[o], a = i.cells.find((e) => e.id === o), s = a.terrain;
		a.terrain = t === "volcano" ? "volcano" : t === "piranha" ? "piranha" : "sea", i.tiles--;
		let c = Ce.includes(t) && t !== "piranha";
		if (i.last = {
			cell: o,
			back: c ? null : t,
			serial: (i.last?.serial ?? 0) + 1
		}, J(e, r, "sink", {
			cell: o,
			terrain: s,
			back: c ? null : t
		}, K.reveal), c) e.hands[n].push({
			id: `tile-${o}`,
			kind: t
		}), r.push({
			kind: "gain",
			rid: n,
			data: {
				cell: o,
				card: `tile-${o}`
			},
			for: [n],
			secret: { ability: t },
			with: !0
		}), e.tasks.unshift({
			kind: "cell",
			cell: o
		});
		else if (t === "green" || t === "blue") e.tasks.unshift({
			kind: "spawn",
			color: t,
			cell: o
		});
		else if (t === "raft") e.tasks.unshift({
			kind: "raft",
			cell: o
		});
		else if (t === "egg") e.tasks.unshift({ kind: "egg" }, {
			kind: "cell",
			cell: o
		});
		else if (t === "volcano") i.volcanoes++, Ae(e, r, o);
		else if (t === "whirlpool") for (let t of [o, ...I(o).filter((e) => z(i, e))]) Ae(e, r, t);
		else if (t === "piranha") {
			Ae(e, r, o);
			let t = i.players.findIndex((e) => e.rid === n);
			for (let n = 0; n < 5; n++) e.hands[i.players[(t + n) % i.players.length].rid].push({
				id: `piranha-${n}`,
				kind: "piranha"
			});
		}
	} else if (t.kind === "roll") i.phase = "creatures", e.tasks.push({
		kind: "creature",
		color: He(e, r)
	}, { kind: "nextTurn" });
	else if (t.kind === "creature" || t.kind === "pushCreature") {
		t.kind === "creature" && e.tasks.shift();
		let n = i.creatures.find((e) => e.id === s);
		e.tasks.unshift({
			kind: "travel",
			entity: s,
			mode: "creature",
			left: n.kind === "pterodactyl" ? 1 : ve(n.kind),
			started: !1
		});
	} else if (t.kind === "step" && a?.kind === "travel") {
		if (a.left--, a.started = !0, a.mode === "creature") {
			let t = i.creatures.find((e) => e.id === s), n = t.cell;
			t.cell = o, J(e, r, "move", {
				id: s,
				piece: t.kind,
				from: n,
				to: o,
				source: c
			}), (R(i, o) === "piranha" || Ie(e, s, o) || !a.left) && e.tasks.shift(), e.tasks.unshift({
				kind: "cell",
				cell: o,
				entrant: s
			}, ...t.kind === "kraken" ? [{
				kind: "kraken",
				entity: s,
				cell: o
			}] : []);
		} else a.mode === "raft" ? Ue(e, r, s, o) : Ne(e, r, s, o), (R(i, o) === "piranha" || i.creatures.some((t) => t.cell === o && Ie(e, t.id, o)) || !a.left || a.mode === "dolphin" && (!z(i, o) || H(i, o))) && e.tasks.shift(), L(o) || e.tasks.unshift({
			kind: "cell",
			cell: o
		});
	} else if (t.kind === "stop") e.tasks.shift();
	else if (t.kind === "spawn") {
		e.tasks.shift();
		let t = i.creatures.find((e) => e.id === s), n = t.cell;
		t.cell = o, J(e, r, n ? "move" : "deploy", {
			id: s,
			piece: t.kind,
			from: n,
			to: o,
			source: c
		}), e.tasks.unshift({
			kind: "cell",
			cell: o,
			entrant: s
		}, ...t.kind === "kraken" && n ? [{
			kind: "kraken",
			entity: s,
			cell: o
		}] : []);
	} else if (t.kind === "egg") {
		e.tasks.shift();
		let t = `egg-${i.last.serial}`;
		i.eggs.push({
			id: t,
			owner: n,
			cell: o,
			turn: i.turn
		}), J(e, r, "deploy", {
			id: t,
			piece: "egg",
			to: o
		}), R(i, o) === "piranha" && e.tasks.unshift({
			kind: "cell",
			cell: o
		});
	} else if (t.kind === "board") {
		let t = i.people.find((e) => e.id === s), n = H(i, o);
		t.raft = n.id, J(e, r, "board", {
			id: s,
			cell: o,
			raft: n.id,
			team: t.team,
			heart: t.heart
		});
	} else if (t.kind === "attack" && a?.kind === "interact") a.ids = a.ids.filter((e) => e !== s), Le(e, s, o);
	else if (t.kind === "repel") Ke(e, n, t.card), Oe(e, r, s), J(e, r, "ability", {
		ability: "repellent",
		cell: o
	}, K.card, n), a?.kind === "respond" && e.tasks.shift();
	else if (t.kind === "pass" && a?.kind === "respond") a.responders.shift();
	else if (t.kind === "kraken") e.tasks.shift(), De(e, r, s);
	else if (t.kind === "pushPerson" && a?.kind === "push") e.tasks.unshift({
		kind: "pushTo",
		source: a.entity,
		entity: s,
		cell: a.cell
	});
	else if (t.kind.startsWith("ability")) {
		let a = e.hands[n].find((e) => e.id === t.card);
		if (Ke(e, n, a.id), J(e, r, "ability", {
			ability: a.kind,
			cell: o ?? null,
			entity: s ?? null
		}, K.card), (t.kind === "abilityPaddle" || t.kind === "abilityDolphin") && e.tasks.unshift({
			kind: "travel",
			entity: s,
			mode: t.kind === "abilityPaddle" ? "raft" : "dolphin",
			left: 2,
			started: !1
		}), t.kind === "abilityDive") {
			let t = i.creatures.find((e) => e.id === s), n = t.cell;
			t.cell = o, J(e, r, "move", {
				id: s,
				from: n,
				to: o,
				piece: t.kind,
				source: c
			}), e.tasks.unshift({
				kind: "cell",
				cell: o,
				entrant: s
			}, ...t.kind === "kraken" ? [{
				kind: "kraken",
				entity: s,
				cell: o
			}] : []);
		}
		t.kind === "abilityDie" && e.tasks.unshift({
			kind: "creature",
			color: He(e, r)
		}), t.kind === "abilityPiranha" && (i.cells.find((e) => e.id === o).terrain = "piranha", e.tasks.unshift({
			kind: "cell",
			cell: o
		}));
	}
}
var Je = {
	meta: C,
	saveCompatibility: { version: "1" },
	schemas: {
		action: E,
		config: T,
		publicView: de,
		privateView: fe
	},
	setup: Ge,
	reduce(e, t, n) {
		let r = structuredClone(e), i = [];
		if (t.type === "tick") return n.by === "$engine" ? r.beat ? (r.beat = 0, We(r, i), {
			state: r,
			fx: i
		}) : { state: e } : Se();
		let a = Ve(e, n.by).find((e) => e.id === t.id);
		return a ? (qe(r, a, n.by, i), We(r, i), {
			state: r,
			fx: i
		}) : Se();
	},
	viewFor(e, t) {
		return {
			public: structuredClone(e.public),
			private: {
				abilities: structuredClone(e.hands[t] ?? []),
				values: e.public.phase === "setup" || e.public.phase === "rafts" ? e.public.people.filter((e) => e.owner === t).map((t) => ({
					id: t.id,
					value: e.values[t.id]
				})) : [],
				choices: Ve(e, t)
			}
		};
	},
	status(e) {
		if (e.public.phase !== "done") return { phase: e.public.phase };
		let t = e.public.scores, n = Math.max(...t.map((e) => e.total));
		return {
			phase: "done",
			winner: t.filter((e) => e.total === n).map((e) => e.rid),
			ranking: [...t].sort((e, t) => t.total - e.total).map((e) => e.rid),
			scores: Object.fromEntries(t.map((e) => [e.rid, e.total]))
		};
	},
	nextTickIn(e) {
		return e.beat || null;
	}
}, Ye = [
	"#f28c62",
	"#d44757",
	"#9365b1",
	"#2dafe0",
	"#f3ca48"
], Y = {
	serpent: "games/survive/serpent.svg",
	shark: "games/survive/shark.svg",
	kaiju: "games/survive/kaiju.svg",
	kraken: "games/survive/kraken.svg",
	pterodactyl: "games/survive/pterodactyl.svg",
	whale: "games/survive/whale.svg",
	paddle: "games/survive/tile-paddle.svg",
	dolphin: "games/survive/tile-dolphin.svg",
	dive: "games/survive/tile-dive.svg",
	die: "games/survive/tile-die.svg",
	repellent: "games/survive/tile-repellent.svg",
	piranha: "games/survive/tile-piranha.svg",
	egg: "games/survive/tile-egg.svg",
	raft: "games/survive/tile-raft.svg",
	volcano: "games/survive/tile-volcano.svg",
	whirlpool: "games/survive/tile-whirlpool.svg",
	green: "games/survive/tile-green.svg",
	blue: "games/survive/tile-blue.svg"
}, X = "M0,-58.8L50.9,-29.4V29.4L0,58.8L-50.9,29.4V-29.4Z", Xe = (e) => e === "mountain" ? 21 : e === "forest" ? 13 : e === "beach" ? 6 : 0;
function Ze({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ _("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ g("path", {
				d: "M0 23Q7 9 2-9",
				stroke: "#a67845",
				strokeWidth: "5",
				fill: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: "M2-9Q-12-29-26-10Q-13-16 0-5Q-21-9-23 6Q-10-3 3-5Q6-28 21-23Q12-18 7-5Q23-20 33-3Q20-10 6-3Q20-4 23 12Q9 3 3-4Z",
				fill: "#30714f"
			}),
			/* @__PURE__ */ g("path", {
				d: "M3-10Q-4-27-18-14Q-6-14 3-7Q14-22 24-17Q14-14 7-5Z",
				fill: "#70a46b"
			})
		]
	});
}
function Qe({ terrain: e, variant: t = 0 }) {
	if (e === "sea") return /* @__PURE__ */ g("path", {
		d: "M-22 2Q-12-5 0 2T23 2M-10 19Q0 12 12 19",
		stroke: "#79d1df",
		strokeOpacity: ".25",
		strokeWidth: "2",
		fill: "none"
	});
	if (e === "piranha" || e === "volcano") return /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("path", {
		d: X,
		fill: e === "piranha" ? "#126680" : "#4c3447"
	}), /* @__PURE__ */ g("image", {
		href: e === "piranha" ? "games/survive/tile-piranha-effect.svg" : Y.volcano,
		x: "-53",
		y: "-48",
		width: "106",
		height: "96"
	})] });
	let n = Xe(e), r = e === "beach" ? "#f3d18b" : e === "forest" ? "#42845b" : "#81738b";
	return /* @__PURE__ */ _(h, { children: [
		/* @__PURE__ */ g("path", {
			d: X,
			fill: e === "beach" ? "#b78b53" : e === "forest" ? "#234e3d" : "#4d455d",
			stroke: "#153e51",
			strokeWidth: "2",
			transform: `translate(0 ${n})`
		}),
		/* @__PURE__ */ g("path", {
			d: X,
			fill: r,
			stroke: e === "beach" ? "#ffe5ac" : "#b2b995",
			strokeWidth: "1.5"
		}),
		e === "beach" ? /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ g("path", {
				d: "M-34-19Q-13-35 7-20T36-15M-31 26Q-14 12 15 27",
				fill: "none",
				stroke: "#e4b573",
				strokeWidth: "8",
				strokeLinecap: "round",
				opacity: ".4"
			}),
			/* @__PURE__ */ g(Ze, {
				x: t % 2 ? -24 : 20,
				y: -8,
				scale: .48
			}),
			/* @__PURE__ */ g("path", {
				d: "M-23 28l5-5 5 5-5 3Z",
				fill: "#fff0c2"
			})
		] }) : e === "forest" ? /* @__PURE__ */ g("g", { children: [
			-25,
			0,
			24
		].map((e, t) => /* @__PURE__ */ _("g", {
			transform: `translate(${e} ${t % 2 ? 12 : -9})`,
			children: [
				/* @__PURE__ */ g("path", {
					d: "M-16 12Q-22-3-11-9Q-11-26 3-21Q18-22 17-9Q28 0 17 13Q4 23-16 12Z",
					fill: t % 2 ? "#2b6549" : "#35734e"
				}),
				/* @__PURE__ */ g("path", {
					d: "M-13 1Q-15-16-3-13Q6-26 12-9Q23-1 11 5Z",
					fill: "#78a46c"
				}),
				/* @__PURE__ */ g("path", {
					d: "M-9 11Q0 5 11 11",
					stroke: "#548c57",
					fill: "none",
					strokeWidth: "3"
				})
			]
		}, e)) }) : /* @__PURE__ */ _("g", { children: [
			/* @__PURE__ */ g("path", {
				d: "M-40 19L-28-17-11-13 1-37 23-27 31-1 43 21 16 31-2 24-22 33Z",
				fill: "#625b73"
			}),
			/* @__PURE__ */ g("path", {
				d: "M-28-17L-11-13-4 5-27 15-40 19ZM1-37L23-27 10-4-4 5ZM31-1L43 21 16 31 10-4Z",
				fill: "#a695ad"
			}),
			/* @__PURE__ */ g("path", {
				d: "M-4 5L10-4 16 31-2 24ZM-27 15L-4 5-2 24-22 33Z",
				fill: "#777087"
			}),
			/* @__PURE__ */ g("path", {
				d: "M-22-13L-10-8M5-31L18-25",
				stroke: "#c4b1c7",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ g(Ze, {
				x: -32,
				y: 23,
				scale: .35
			})
		] })
	] });
}
var $e = "M85,0L83,161L82,162L6,162L6,210L99,210L100,211L100,235L102,247L107,264L118,287L135,310L149,324L168,339L180,346L181,348L143,368L104,395L84,412L68,428L48,452L27,485L12,519L2,558L0,574L0,596L499,596L500,595L499,565L495,543L490,525L483,506L473,485L455,456L433,429L400,398L362,371L319,347L335,337L349,326L367,308L381,289L390,272L397,252L400,236L400,211L401,210L494,210L494,162L418,162L417,161L415,0Z";
function Z({ team: e = 0, heart: t = !1 }) {
	return /* @__PURE__ */ _("svg", {
		viewBox: "-25 -25 551 660",
		className: "survive-person-art",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ g("path", {
				d: $e,
				fill: "#172c41",
				transform: "translate(0 25)"
			}),
			/* @__PURE__ */ g("path", {
				d: $e,
				fill: Ye[e],
				stroke: "#fce8bc",
				strokeWidth: "9"
			}),
			/* @__PURE__ */ g("path", {
				d: "M103 37H397M105 172H395",
				stroke: "#fff0cc",
				strokeOpacity: ".45",
				strokeWidth: "15",
				strokeLinecap: "round"
			}),
			t && /* @__PURE__ */ g("path", {
				d: "M250 459C143 394 182 341 225 374L250 397 275 374C320 340 357 394 250 459Z",
				fill: "#fff3d4"
			})
		]
	});
}
function et({ children: e }) {
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 110 82",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _("g", {
			transform: "rotate(-9 55 41)",
			children: [
				/* @__PURE__ */ g("path", {
					d: "M14 15Q9 37 13 66L94 69Q100 45 94 15Z",
					fill: "#684c3c",
					stroke: "#dbc09a",
					strokeWidth: "2"
				}),
				[
					18,
					34,
					50,
					66,
					82
				].map((e) => /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("path", {
					d: `M${e} 12Q${e - 4} 39 ${e} 67L${e + 11} 69Q${e + 15} 41 ${e + 11} 14Z`,
					fill: "#b98a57",
					stroke: "#78573d",
					strokeWidth: "2"
				}), /* @__PURE__ */ g("path", {
					d: `M${e + 4} 19Q${e + 2} 34 ${e + 5} 52`,
					stroke: "#dfb57a",
					strokeWidth: "2",
					fill: "none"
				})] }, e)),
				/* @__PURE__ */ g("path", {
					d: "M13 26L96 27M12 54L97 57",
					stroke: "#dfc99d",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ g("path", {
					d: "M13 28L96 29M12 56L97 59",
					stroke: "#69583e",
					strokeWidth: "1.5"
				})
			]
		}), e]
	});
}
function tt({ kind: e }) {
	return /* @__PURE__ */ g("img", {
		src: Y[e],
		alt: "",
		draggable: !1,
		className: "survive-creature-art"
	});
}
function nt() {
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 80 90",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ g("path", {
				d: "M40 6C21 6 10 44 11 61C13 91 68 91 69 61C70 44 59 6 40 6Z",
				fill: "#60569a",
				stroke: "#c9b8ec",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: "M41 12L32 36 43 48 24 68M61 40L47 52 58 76",
				fill: "none",
				stroke: "#5bd9dc",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("ellipse", {
				cx: "26",
				cy: "32",
				rx: "6",
				ry: "10",
				fill: "#c0b8e6",
				opacity: ".6"
			})
		]
	});
}
function rt({ flip: e = !1, bottom: t = !1 }) {
	return /* @__PURE__ */ _("g", {
		transform: e ? "scale(-1 1)" : void 0,
		children: [
			/* @__PURE__ */ g("path", {
				d: "M-108-100Q-9-128 73-80Q110-27 81 34Q72 83 8 106L-100 111Z",
				fill: "#5bc9b6"
			}),
			/* @__PURE__ */ g("path", {
				d: "M-108-105Q-7-120 63-78Q92-23 64 26Q58 66-5 91L-108 101Z",
				fill: "#edcb85",
				stroke: "#ffe9b3",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ g("path", {
				d: "M-104-100Q-32-121 23-83Q46-58 25-29Q53 9 11 42L-101 68Z",
				fill: "#39774f"
			}),
			/* @__PURE__ */ g(Ze, {
				x: -13,
				y: -48,
				scale: 1.15
			}),
			/* @__PURE__ */ g(Ze, {
				x: -75,
				y: 9,
				scale: .85
			}),
			/* @__PURE__ */ g("path", {
				d: t ? "M35-24L100-40 95-58 32-43Z" : "M35 24L100 40 95 58 32 43Z",
				fill: "#ae8459",
				stroke: "#5a503c",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ g("path", {
				d: t ? "M47-29L44-47M64-33L61-51M81-37L78-55" : "M47 29L44 47M64 33L61 51M81 37L78 55",
				stroke: "#e2bd85",
				strokeWidth: "3"
			})
		]
	});
}
//#endregion
//#region src/games/survive/labels.ts
var it = {
	serpent: "games.survive.serpent",
	shark: "games.survive.shark",
	kaiju: "games.survive.kaiju",
	kraken: "games.survive.kraken",
	pterodactyl: "games.survive.pterodactyl",
	whale: "games.survive.whale"
}, at = {
	paddle: "games.survive.paddle",
	dolphin: "games.survive.dolphin",
	dive: "games.survive.dive",
	die: "games.survive.die",
	repellent: "games.survive.repellent",
	piranha: "games.survive.piranha"
}, ot = {
	paddle: "games.survive.abilityDetailPaddle",
	dolphin: "games.survive.abilityDetailDolphin",
	dive: "games.survive.abilityDetailDive",
	die: "games.survive.abilityDetailDie",
	repellent: "games.survive.abilityDetailRepellent",
	piranha: "games.survive.abilityDetailPiranha"
};
({ ...at });
var st = [
	"games.survive.teamOrange",
	"games.survive.teamRed",
	"games.survive.teamPurple",
	"games.survive.teamBlue",
	"games.survive.teamYellow"
], ct = {
	setup: "games.survive.setup",
	rafts: "games.survive.rafts",
	action: "games.survive.action",
	sinking: "games.survive.sinking",
	roll: "games.survive.roll",
	creatures: "games.survive.creatures",
	done: "games.survive.done"
}, lt = {
	setup: "games.survive.choosePerson",
	rafts: "games.survive.rafts",
	action: "games.survive.choosePerson",
	sinking: "games.survive.chooseTile",
	roll: "games.survive.roll",
	creature: "games.survive.chooseCreature",
	spawn: "games.survive.chooseSpawn",
	raft: "games.survive.chooseRaft",
	egg: "games.survive.chooseEgg",
	board: "games.survive.chooseBoard",
	interact: "games.survive.chooseAttack",
	respond: "games.survive.chooseRepel",
	push: "games.survive.choosePush",
	pushTo: "games.survive.choosePushTo",
	kraken: "games.survive.chooseKraken",
	travel: "games.survive.chooseTarget"
};
//#endregion
//#region src/games/survive/map.tsx
function ut({ name: e, r: t }) {
	let r = s(), i = n((t) => {
		r?.registerProbe(e, t ? () => {
			let e = t.getBoundingClientRect();
			return {
				x: e.left,
				y: e.top,
				w: e.width,
				h: e.height
			};
		} : null);
	}, [r, e]);
	return /* @__PURE__ */ g("rect", {
		ref: i,
		x: t.x,
		y: t.y,
		width: t.w,
		height: t.h,
		fill: "none",
		pointerEvents: "none"
	});
}
function dt({ pub: e, id: t, selected: n }) {
	let r = o(`piece:${t}`).hidden, i = G(e, t);
	if (!i) return null;
	let a = e.people.find((e) => e.id === t), s = e.creatures.find((e) => e.id === t), c = e.rafts.find((e) => e.id === t);
	return /* @__PURE__ */ _("g", {
		opacity: +!r,
		pointerEvents: "none",
		children: [
			n && /* @__PURE__ */ g("ellipse", {
				cx: i.x + i.w / 2,
				cy: i.y + i.h * .8,
				rx: i.w * .68,
				ry: i.h * .28,
				fill: "#ffe9a2",
				stroke: "#fff9d7",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ _("g", {
				className: "survive-map-piece",
				transform: `translate(${i.x} ${i.y})`,
				children: [/* @__PURE__ */ g("ellipse", {
					cx: i.w / 2,
					cy: i.h * .91,
					rx: i.w * .4,
					ry: i.h * .1,
					fill: "#09263c",
					opacity: ".45"
				}), a ? /* @__PURE__ */ g("svg", {
					width: i.w,
					height: i.h,
					children: /* @__PURE__ */ g(Z, {
						team: a.team,
						heart: a.heart
					})
				}) : s ? /* @__PURE__ */ g("image", {
					href: Y[s.kind],
					width: i.w,
					height: i.h
				}) : c ? /* @__PURE__ */ g("svg", {
					width: i.w,
					height: i.h,
					children: /* @__PURE__ */ g(et, {})
				}) : /* @__PURE__ */ g("svg", {
					width: i.w,
					height: i.h,
					children: /* @__PURE__ */ g(nt, {})
				})]
			}),
			/* @__PURE__ */ g(ut, {
				name: `piece:${t}`,
				r: i
			})
		]
	});
}
function ft({ pub: e, targets: t = [], sources: n = [], selected: r, fitKey: i = "", onCell: a }) {
	let o = l(), s = [...j, ...N], c = a ? s.map((e) => ({
		key: e.id,
		rect: {
			x: e.x - 24,
			y: e.y - 24,
			w: 48,
			h: 48
		}
	})) : [], u = e.people.filter((e) => e.status === "alive" || e.status === "rescued");
	return /* @__PURE__ */ _(y, {
		clampToSheet: !0,
		sheetW: 1300,
		sheetH: 1400,
		eligible: c,
		onTapEligible: a,
		readOnly: !a,
		fitKey: i,
		highlight: "off",
		children: [
			/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ _("radialGradient", {
				id: "survive-water",
				children: [/* @__PURE__ */ g("stop", { stopColor: "#267fb0" }), /* @__PURE__ */ g("stop", {
					offset: "1",
					stopColor: "#163f7d"
				})]
			}) }),
			/* @__PURE__ */ g("rect", {
				width: "1300",
				height: "1400",
				fill: "url(#survive-water)",
				rx: "40"
			}),
			j.map((t) => {
				let n = e.cells.find((e) => e.id === t.id).terrain;
				return /* @__PURE__ */ _("g", {
					transform: `translate(${t.x} ${t.y})`,
					children: [/* @__PURE__ */ g("path", {
						d: X,
						fill: "none",
						stroke: "#82a8cf",
						strokeOpacity: ".24",
						strokeWidth: "1.5"
					}), /* @__PURE__ */ g(Qe, {
						terrain: n,
						variant: t.q
					})]
				}, t.id);
			}),
			N.map((e) => /* @__PURE__ */ g("g", {
				transform: `translate(${e.x} ${e.y})`,
				children: /* @__PURE__ */ g(rt, {
					flip: e.x > 650,
					bottom: e.y > 700
				})
			}, e.id)),
			N.flatMap((e) => e.links.map((t) => {
				let n = M[t];
				return /* @__PURE__ */ g("path", {
					d: `M${e.x + (e.x < 650 ? 88 : -88)},${e.y + (e.y < 700 ? 50 : -50)}L${n.x},${n.y}`,
					stroke: "#c7dfd4",
					strokeWidth: "3",
					strokeDasharray: "7 9",
					opacity: ".55",
					fill: "none",
					pointerEvents: "none"
				}, `${e.id}:${t}`);
			})),
			s.map((e) => /* @__PURE__ */ g(v, {
				name: `cell:${e.id}`,
				r: {
					x: e.x - 50,
					y: e.y - 50,
					w: 100,
					h: 100
				}
			}, e.id)),
			e.rafts.filter((e) => e.cell).map((t) => /* @__PURE__ */ g(dt, {
				pub: e,
				id: t.id,
				selected: t.id === r
			}, t.id)),
			u.filter((e) => u.filter((t) => t.cell === e.cell).indexOf(e) < 6).map((t) => /* @__PURE__ */ g(dt, {
				pub: e,
				id: t.id,
				selected: t.id === r
			}, t.id)),
			e.eggs.map((t) => /* @__PURE__ */ g(dt, {
				pub: e,
				id: t.id,
				selected: !1
			}, t.id)),
			e.creatures.filter((e) => e.cell).map((t) => /* @__PURE__ */ g(dt, {
				pub: e,
				id: t.id,
				selected: t.id === r
			}, t.id)),
			s.map((e) => {
				let t = u.filter((t) => t.cell === e.id).length;
				return t > 6 ? /* @__PURE__ */ _("g", { children: [/* @__PURE__ */ g("circle", {
					cx: e.x + 30,
					cy: e.y + 23,
					r: "15",
					fill: "#f5e2ac"
				}), /* @__PURE__ */ _("text", {
					x: e.x + 30,
					y: e.y + 29,
					textAnchor: "middle",
					fontSize: "18",
					fill: "#183a53",
					children: ["+", t - 6]
				})] }, e.id) : null;
			}),
			[...new Set(n)].map((e) => {
				let t = M[e] ?? N.find((t) => t.id === e);
				return t ? /* @__PURE__ */ g("path", {
					d: X,
					transform: `translate(${t.x} ${t.y})`,
					fill: "none",
					stroke: "#b8e5de",
					strokeWidth: "3",
					strokeDasharray: "3 6",
					pointerEvents: "none"
				}, e) : null;
			}),
			[...new Set(t)].map((e) => {
				let t = M[e] ?? N.find((t) => t.id === e);
				return t ? /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					transform: `translate(${t.x} ${t.y})`,
					children: [/* @__PURE__ */ g("path", {
						d: X,
						fill: "#ffefb6",
						fillOpacity: ".12",
						stroke: "#fff0ae",
						strokeWidth: "5"
					}), /* @__PURE__ */ g("path", {
						d: X,
						fill: "none",
						stroke: "#164861",
						strokeWidth: "2.8",
						strokeDasharray: "10 7",
						children: /* @__PURE__ */ g("animate", {
							attributeName: "stroke-dashoffset",
							from: "0",
							to: "-34",
							dur: ".8s",
							repeatCount: "indefinite"
						})
					})]
				}, e) : null;
			}),
			a && /* @__PURE__ */ g("g", {
				className: "survive-map-keyboard",
				children: s.map((e) => /* @__PURE__ */ g("g", {
					role: "button",
					tabIndex: 0,
					"aria-label": o("games.survive.cell", { cell: e.id }),
					onKeyDown: (t) => {
						(t.key === "Enter" || t.key === " ") && (t.preventDefault(), a(e.id));
					},
					children: /* @__PURE__ */ g("path", {
						d: "M0,-58.8L50.9,-29.4V29.4L0,58.8L-50.9,29.4V-29.4Z",
						transform: `translate(${e.x} ${e.y})`,
						fill: "transparent",
						pointerEvents: "none"
					})
				}, e.id))
			})
		]
	});
}
//#endregion
//#region src/games/survive/view-player.tsx
function pt({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = o(e);
	return /* @__PURE__ */ g("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function mt({ id: e, kind: t }) {
	let { ref: n, hidden: r } = o(`card:${e}`);
	return /* @__PURE__ */ g("img", {
		ref: n,
		src: Y[t],
		alt: "",
		draggable: !1,
		style: { visibility: r ? "hidden" : void 0 }
	});
}
var ht = {
	abilities: [],
	values: [],
	choices: []
}, gt = /* @__PURE__ */ new Set([
	"creature",
	"spawn",
	"board",
	"attack",
	"pushPerson",
	"pushCreature",
	"kraken",
	"abilityPaddle",
	"abilityDolphin",
	"repel",
	"raftPlace"
]);
function _t({ public: e, private: t, members: n, myRid: r, send: i }) {
	let v = e, y = t ?? ht, b = l(), te = c((e) => e.locale), x = s();
	f();
	let S = [
		r,
		v.active,
		v.turn,
		v.phase,
		v.prompt
	].join("/"), [C, ne] = a(null), w = C?.key === S && !v.busy && y.choices.length > 0 ? C : null, [re, T] = a(null), E = re?.key === S && !v.busy ? re : null, [ie, ae] = a(0), { ref: oe } = o("maparea"), { ref: se } = o("reserve"), { ref: ce, hidden: le } = o("dice"), D = y.choices, ue = D.length > 0, de = y.abilities.find((e) => e.id === w?.card), O = D.filter((e) => w?.card ? e.card === w.card : !e.card), fe = v.prompt === "travel" || v.prompt === "pushTo" ? v.promptEntity : null, k = w?.entity ?? fe, A = k ? O.filter((e) => e.entity === k || !e.entity) : O, j = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ee(t, te) : e;
	}, M = (e) => {
		let t = v.people.find((t) => t.id === e);
		return b("games.survive.pawn", {
			name: j(t.owner),
			team: b(st[t.team]),
			n: Number(e.split("-")[1]) + 1
		});
	}, N = (e) => v.people.some((t) => t.id === e) ? M(e) : v.creatures.some((t) => t.id === e) ? b(it[v.creatures.find((t) => t.id === e).kind]) : b("games.survive.raft"), pe = (e) => v.people.find((t) => t.id === e)?.cell ?? v.creatures.find((t) => t.id === e)?.cell ?? v.rafts.find((t) => t.id === e)?.cell, P = (e) => {
		ne(null), T(null), i({
			type: "choose",
			id: e.id
		});
	}, F = (e) => {
		let t = O.filter((t) => t.entity === e);
		t.length && (t.length === 1 && gt.has(t[0].kind) || t[0].kind === "abilityPaddle" || t[0].kind === "abilityDolphin" ? P(t[0]) : (ne({
			key: S,
			card: w?.card ?? null,
			entity: e
		}), T(null)));
	}, I = (e) => {
		let t = A.filter((t) => t.cell === e && (k && t.entity === k || !t.entity));
		if (t.length === 1) {
			P(t[0]);
			return;
		}
		let n = [
			...v.people.filter((t) => (t.status === "alive" || t.status === "rescued") && t.cell === e).map((e) => e.id),
			...v.rafts.filter((t) => t.cell === e).map((e) => e.id),
			...v.creatures.filter((t) => t.cell === e).map((e) => e.id)
		], r = [...new Set(O.filter((e) => e.entity && n.includes(e.entity)).map((e) => e.entity))];
		if (r.length === 1 && !n.some((e) => e !== r[0])) {
			F(r[0]);
			return;
		}
		if (!n.length) {
			T(null);
			return;
		}
		let i = x?.measure(`cell:${e}`), a = x?.measure("maparea");
		T({
			key: S,
			cell: e,
			x: i && a ? Math.max(8, Math.min(a.w - 230, i.x + i.w / 2 - a.x - 105)) : 8,
			y: i && a ? Math.max(8, Math.min(a.h - 235, i.y + i.h / 2 - a.y + 12)) : 8
		});
	}, L = A.filter((e) => e.cell && (k && e.entity === k || !e.entity)).map((e) => e.cell), R = k ? [] : [...new Set(O.flatMap((e) => e.entity && pe(e.entity) ? [pe(e.entity)] : []))], z = (e) => {
		let t = D.filter((t) => t.card === e);
		if (t.length) {
			if (t.length === 1 && ["abilityDie", "repel"].includes(t[0].kind)) {
				P(t[0]);
				return;
			}
			ne({
				key: S,
				card: e === w?.card ? null : e,
				entity: null
			}), T(null);
		}
	}, B = D.filter((e) => [
		"end",
		"stop",
		"pass",
		"roll"
	].includes(e.kind)), V = v.busy ? b("games.survive.busy") : ue && v.actor !== r ? b("games.survive.chooseRepel") : !ue && v.phase !== "done" ? b("games.survive.waiting", { name: j(v.actor) }) : b(k || de ? "games.survive.chooseTarget" : lt[v.prompt] ?? ct[v.phase]), H = [...new Set(v.creatures.map((e) => e.kind))], U = v.phase === "setup" || v.phase === "rafts", me = v.people.filter((e) => e.owner === r && e.status === "reserve"), W = ["spawn", "raft"].includes(v.prompt) ? [...new Set(D.map((e) => e.entity).filter((e) => !!e))] : [], he = /* @__PURE__ */ g(pt, {
		name: `hand:${r}`,
		className: "survive-hand",
		children: v.phase === "setup" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("div", {
			className: "survive-tray-title",
			children: b("games.survive.myCrew")
		}), /* @__PURE__ */ g("div", {
			className: "survive-crew-tray",
			children: me.map((e) => /* @__PURE__ */ _("button", {
				type: "button",
				className: "survive-pawn-choice",
				disabled: !D.some((t) => t.entity === e.id),
				"aria-label": M(e.id),
				"aria-pressed": k === e.id,
				onClick: () => F(e.id),
				children: [
					/* @__PURE__ */ g(Z, {
						team: e.team,
						heart: e.heart
					}),
					/* @__PURE__ */ g("b", { children: e.heart ? b("games.survive.heart") : b("games.survive.value", { n: y.values.find((t) => t.id === e.id)?.value ?? 0 }) }),
					/* @__PURE__ */ _("small", { children: [
						b(st[e.team]),
						" · ",
						b("games.survive.number", { n: Number(e.id.split("-")[1]) + 1 })
					] })
				]
			}, e.id))
		})] }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
			className: "survive-tray-title",
			children: [
				b("games.survive.cards"),
				" ",
				/* @__PURE__ */ g("span", { children: y.abilities.length })
			]
		}), /* @__PURE__ */ g("div", {
			className: "survive-ability-tray",
			children: y.abilities.map((e) => /* @__PURE__ */ _("button", {
				type: "button",
				className: "survive-ability-choice",
				disabled: !D.some((t) => t.card === e.id),
				"aria-label": `${b(at[e.kind])}: ${b(ot[e.kind])}`,
				"aria-pressed": w?.card === e.id,
				title: b(ot[e.kind]),
				onClick: () => z(e.id),
				children: [/* @__PURE__ */ g(mt, {
					id: e.id,
					kind: e.kind
				}), /* @__PURE__ */ g("b", { children: b(at[e.kind]) })]
			}, e.id))
		})] })
	});
	return /* @__PURE__ */ g(p, {
		adaptive: !0,
		className: "survive-screen",
		scroll: !1,
		banner: /* @__PURE__ */ _("header", {
			className: "survive-header",
			children: [
				/* @__PURE__ */ g("div", {
					className: "survive-title",
					children: /* @__PURE__ */ g("h1", { children: b("games.survive.name") })
				}),
				/* @__PURE__ */ g("span", {
					className: "survive-round",
					children: b("games.survive.turn", { n: v.turn })
				}),
				/* @__PURE__ */ g("div", {
					className: "survive-volcanoes",
					"aria-label": `${b("games.survive.volcano")} ${v.volcanoes}/3`,
					children: [
						0,
						1,
						2
					].map((e) => /* @__PURE__ */ g("span", {
						"data-erupted": e < v.volcanoes,
						children: /* @__PURE__ */ g("img", {
							src: Y.volcano,
							alt: ""
						})
					}, e))
				})
			]
		}),
		actionsHeight: "survive-actions-height",
		actions: /* @__PURE__ */ _("div", {
			className: "survive-actions",
			children: [/* @__PURE__ */ g("div", {
				className: "survive-phase",
				children: /* @__PURE__ */ g(m, {
					tone: ue ? "accent" : v.phase === "done" ? "done" : "info",
					accent: "#164768",
					text: V,
					chip: /* @__PURE__ */ g("span", { children: v.phase === "action" ? b("games.survive.moves", { n: v.moves }) : b(ct[v.phase]) })
				})
			}), /* @__PURE__ */ _("div", {
				className: "survive-controls",
				children: [w && /* @__PURE__ */ g("button", {
					type: "button",
					className: "survive-quiet",
					onClick: () => ne(null),
					children: b("games.survive.cancel")
				}), B.map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					className: e.kind === "end" || e.kind === "roll" ? "survive-primary" : "survive-quiet",
					onClick: () => P(e),
					children: b(e.kind === "end" ? "games.survive.end" : e.kind === "stop" ? "games.survive.stop" : e.kind === "pass" ? "games.survive.pass" : "games.survive.roll")
				}, e.id))]
			})]
		}),
		children: /* @__PURE__ */ _("div", {
			className: "survive-workspace",
			children: [
				/* @__PURE__ */ g("aside", {
					className: "survive-crews",
					children: v.players.map((e) => /* @__PURE__ */ g(pt, {
						name: `seat:${e.rid}`,
						className: "survive-crew",
						children: /* @__PURE__ */ _("div", {
							className: "survive-crew-inner",
							"data-active": e.rid === v.active,
							style: { "--survive-team": Ye[e.teams[0]] },
							children: [/* @__PURE__ */ g("div", {
								className: "survive-team-pawns",
								children: e.teams.map((e) => /* @__PURE__ */ g("span", {
									title: b(st[e]),
									children: /* @__PURE__ */ g(Z, { team: e })
								}, e))
							}), /* @__PURE__ */ _("div", {
								className: "survive-crew-data",
								children: [
									/* @__PURE__ */ g("b", { children: j(e.rid) }),
									/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ _("span", { children: [
										b("games.survive.alive"),
										" ",
										/* @__PURE__ */ g("strong", { children: v.people.filter((t) => t.owner === e.rid && t.status === "alive").length })
									] }), /* @__PURE__ */ _("span", { children: [
										b("games.survive.rescued"),
										" ",
										/* @__PURE__ */ g("strong", { children: v.people.filter((t) => t.owner === e.rid && t.status === "rescued").length })
									] })] }),
									/* @__PURE__ */ _("small", { children: [
										b("games.survive.cards"),
										" ",
										e.cards
									] })
								]
							})]
						})
					}, e.rid))
				}),
				/* @__PURE__ */ _("section", {
					className: "survive-chart",
					ref: oe,
					children: [
						/* @__PURE__ */ g(ft, {
							pub: v,
							targets: L,
							sources: R,
							selected: k,
							fitKey: String(ie),
							onCell: I
						}),
						/* @__PURE__ */ g("button", {
							type: "button",
							className: "survive-fit",
							"aria-label": b("games.survive.fit"),
							title: b("games.survive.fit"),
							onClick: () => {
								ae((e) => e + 1), T(null);
							},
							children: /* @__PURE__ */ g(d, { size: 20 })
						}),
						U && /* @__PURE__ */ g("p", {
							className: "survive-memory-note",
							children: b("games.survive.remember")
						}),
						E && /* @__PURE__ */ _("div", {
							className: "survive-local-picker",
							style: {
								left: E.x,
								top: E.y
							},
							children: [/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("span", { children: b("games.survive.cell", { cell: E.cell }) }), /* @__PURE__ */ g("button", {
								type: "button",
								"aria-label": b("games.survive.cancel"),
								onClick: () => T(null),
								children: /* @__PURE__ */ g(u, { size: 17 })
							})] }), /* @__PURE__ */ g("div", {
								className: "survive-local-pieces",
								children: [
									...v.people.filter((e) => (e.status === "alive" || e.status === "rescued") && e.cell === E.cell).map((e) => ({
										id: e.id,
										art: /* @__PURE__ */ g(Z, {
											team: e.team,
											heart: e.heart
										}),
										value: y.values.find((t) => t.id === e.id)?.value
									})),
									...v.rafts.filter((e) => e.cell === E.cell).map((e) => ({
										id: e.id,
										art: /* @__PURE__ */ g(et, {}),
										value: void 0
									})),
									...v.creatures.filter((e) => e.cell === E.cell).map((e) => ({
										id: e.id,
										art: /* @__PURE__ */ g(tt, { kind: e.kind }),
										value: void 0
									}))
								].map((e) => /* @__PURE__ */ _("button", {
									type: "button",
									className: "survive-local-piece",
									disabled: !O.some((t) => t.entity === e.id),
									"aria-label": N(e.id),
									onClick: () => F(e.id),
									children: [
										e.art,
										/* @__PURE__ */ g("span", { children: N(e.id) }),
										e.value !== void 0 && /* @__PURE__ */ g("b", { children: b("games.survive.value", { n: e.value }) })
									]
								}, e.id))
							})]
						}),
						W.length > 0 && /* @__PURE__ */ g("div", {
							className: "survive-spawn-picker",
							children: W.map((e) => /* @__PURE__ */ _("button", {
								type: "button",
								"aria-label": b("games.survive.select", { name: N(e) }),
								onClick: () => P(D.find((t) => t.entity === e)),
								children: [v.creatures.some((t) => t.id === e) ? /* @__PURE__ */ g(tt, { kind: v.creatures.find((t) => t.id === e).kind }) : /* @__PURE__ */ g(et, {}), /* @__PURE__ */ g("span", { children: N(e) })]
							}, e))
						})
					]
				}),
				/* @__PURE__ */ _("aside", {
					className: "survive-logbook",
					children: [
						he,
						/* @__PURE__ */ g("div", {
							className: "survive-selected-card",
							"aria-live": "polite",
							children: de ? b(ot[de.kind]) : v.phase === "sinking" ? b("games.survive.waters", { n: v.tiles }) : ""
						}),
						/* @__PURE__ */ _("div", {
							className: "survive-reserve",
							ref: se,
							children: [/* @__PURE__ */ g("h2", { children: b("games.survive.reserve") }), /* @__PURE__ */ _("div", {
								className: "survive-reserve-pieces",
								children: [
									H.map((e) => /* @__PURE__ */ _("div", { children: [
										/* @__PURE__ */ g(tt, { kind: e }),
										/* @__PURE__ */ g("span", { children: b(it[e]) }),
										/* @__PURE__ */ g("b", { children: v.creatures.filter((t) => t.kind === e && !t.cell).length })
									] }, e)),
									/* @__PURE__ */ _("div", { children: [
										/* @__PURE__ */ g(et, {}),
										/* @__PURE__ */ g("span", { children: b("games.survive.raft") }),
										/* @__PURE__ */ g("b", { children: v.rafts.filter((e) => !e.cell).length })
									] }),
									v.config.eggs && /* @__PURE__ */ _("div", { children: [
										/* @__PURE__ */ g(nt, {}),
										/* @__PURE__ */ g("span", { children: b("games.survive.egg") }),
										/* @__PURE__ */ g("b", { children: 2 - v.eggs.length })
									] })
								]
							})]
						}),
						/* @__PURE__ */ g("div", {
							className: "survive-dice",
							ref: ce,
							style: { visibility: le ? "hidden" : void 0 },
							"data-color": v.die ?? "none",
							children: v.die && /* @__PURE__ */ g("img", {
								src: Y[v.die === "red" ? "serpent" : v.die === "green" ? "shark" : "kaiju"],
								alt: b(v.die === "red" ? "games.survive.redGroup" : v.die === "green" ? "games.survive.greenGroup" : "games.survive.blueGroup")
							})
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/games/survive/bot.ts
var vt = {
	danger: 1,
	aggression: 1,
	rescue: 1,
	conserve: 1
};
function yt(e, t) {
	let n = {}, r = [];
	if (t) for (let e of N) for (let t of e.links) n[t] = 1, r.push(t);
	else for (let e of N) n[e.id] = 0, r.push(e.id);
	for (; r.length;) {
		let i = r.shift(), a = n[i];
		for (let o of I(i, !t)) {
			if (t ? !z(e, o) || V(e, o) : !W(e, o)) continue;
			let i = t ? 1 : z(e, o) && !H(e, o) ? 2.7 : 1;
			(n[o] === void 0 || n[o] > a + i) && (n[o] = a + i, r.push(o));
		}
	}
	return n;
}
function Q(e, t, n) {
	return e.values[t] ?? (n ? 6 : 3);
}
function $(e, t, n) {
	if (L(t)) return 0;
	if (R(e, t) === "piranha") return 30;
	let r = 0;
	for (let i of e.creatures.filter((e) => e.cell)) {
		let a = be(i.cell, t);
		a > ve(i.kind) + 1 && i.kind !== "pterodactyl" || i.kind === "shark" && n || i.kind === "whale" && !n || i.kind === "pterodactyl" && B(e, t).length > 1 || (a === 0 ? r += i.kind === "kaiju" ? 10 : i.kind === "whale" ? 1.8 : 8 : a <= ve(i.kind) && (r += 1.2 / a));
	}
	return r;
}
function bt(e, t, n, r, i = !1) {
	return B(e, n).filter((e) => !i || !e.raft).reduce((e, n) => e + (n.owner === t ? -Q(r, n.id, n.heart) * 1.45 : 3), 0);
}
function xt(e, t, n, r, i, a, o) {
	let s = e.people.find((e) => e.id === n.entity), c = e.rafts.find((e) => e.id === n.entity), l = e.creatures.find((e) => e.id === n.entity), u = n.cell, d = s?.cell ?? c?.cell ?? l?.cell, f = (n, o) => {
		let s = e.people.find((e) => e.id === n), c = Q(i, n, s.heart), l = s.owner === t, u = (a[s.cell] ?? 30) - (a[o] ?? 30), d = $(e, o, !!H(e, o) && U(e, H(e, o).id).length < 3) - $(e, s.cell, !!s.raft), f = i.trail[n]?.includes(o) ? 3 : 0, p = L(o) ? 15 + c * r.rescue : u * (1 + c * .12) - d * r.danger - f;
		return l ? p : -p * r.aggression;
	}, p = (n, a) => {
		let s = e.rafts.find((e) => e.id === n), c = U(e, n).filter((e) => e.owner === t), l = c.reduce((e, t) => e + Q(i, t.id, t.heart), 0), u = (o[s.cell] ?? 25) - (o[a] ?? 25), d = B(e, a).filter((e) => e.owner === t && !e.raft).length;
		return u * (c.length * 1.5 + l * .2) + d * 2 - ($(e, a, !0) - $(e, s.cell, !0)) * r.danger * Math.max(1, c.length) - (i.trail[n]?.includes(a) ? 4 : 0);
	}, m = (n, a) => {
		let o = e.creatures.find((e) => e.id === n);
		if (R(e, a) === "piranha") return -.3;
		let s = bt(e, t, a, i, o.kind === "shark" || o.kind === "kraken");
		if (o.kind === "whale" && (s = U(e, H(e, a)?.id ?? "").reduce((e, n) => e + (n.owner === t ? -2 : 1.5), 0)), o.kind === "kaiju" && (s *= .5), o.kind === "kraken") {
			let n = e.people.filter((e) => e.status === "alive" && e.cell && [a, ...I(a)].includes(e.cell));
			n.length && (s += Math.max(...n.map((e) => e.owner === t ? -Q(i, e.id, e.heart) * 1.5 : 3)));
		}
		let c = e.people.filter((e) => e.status === "alive" && e.owner !== t && e.cell), l = c.length ? Math.min(...c.map((e) => be(a, e.cell))) : 0;
		return s * r.aggression - l * .16 - (i.trail[n]?.includes(a) ? .7 : 0);
	};
	if (n.kind === "place") return -(a[u] ?? 30) * (1 + Q(i, s.id, s.heart) * .12) - $(e, u, !1) * r.danger + +(R(e, u) === "mountain");
	if (n.kind === "raftPlace" && !n.entity) return I(u).flatMap((t) => B(e, t)).reduce((e, n) => e + (n.owner === t ? Q(i, n.id, n.heart) : -.5), 0) - (o[u] ?? 25) * .4 - $(e, u, !0) * r.danger;
	if (n.kind === "move" || n.kind === "pushTo") return f(n.entity, u);
	if (n.kind === "raftMove") return p(n.entity, u);
	if (n.kind === "step") return s ? f(s.id, u) : c ? p(c.id, u) : m(l.id, u);
	if (n.kind === "sink") {
		let n = B(e, u).filter((e) => e.owner === t), a = B(e, u).filter((e) => e.owner !== t);
		return a.length * 2 * r.aggression - n.reduce((e, t) => e + Q(i, t.id, t.heart), 0) * r.danger + $(e, u, !1) * (a.length - n.length) * .3;
	}
	return n.kind === "creature" || n.kind === "pushCreature" ? Math.max(...ye(e, l.kind, l.cell, l.id).map((e) => m(l.id, e)), -100) : n.kind === "spawn" ? m(l.id, u) : n.kind === "kraken" ? s.owner === t ? -Q(i, s.id, s.heart) : 3 : n.kind === "board" ? s.owner === t ? Q(i, s.id, s.heart) + 4 : -3 : n.kind === "repel" ? 20 : n.kind === "pass" ? -50 : n.kind === "attack" ? m(l.id, u) : n.kind === "pushPerson" ? s.owner === t ? -2 : 2 : n.kind === "egg" ? bt(e, t, u, i) + (e.people.some((e) => e.owner === t && e.status === "alive" && e.cell === u) ? -10 : 0) : n.kind === "abilityPiranha" ? bt(e, t, u, i) * r.aggression - 1.5 * r.conserve : n.kind === "abilityDive" ? m(l.id, u) - m(l.id, l.cell) - r.conserve * 2 : n.kind === "abilityPaddle" ? Math.max(...I(c.cell).filter((t) => z(e, t) && !H(e, t) && !V(e, t)).map((e) => p(c.id, e)), -100) - r.conserve : n.kind === "abilityDolphin" ? Math.max(...I(s.cell, !0).filter((t) => W(e, t)).map((e) => f(s.id, e)), -100) + 1 - r.conserve : n.kind === "abilityDie" ? -.5 : n.kind === "stop" ? 0 : n.kind === "end" ? -.1 : n.kind === "raftPlace" ? 1 : d ? 0 : .1;
}
function St(e = vt) {
	return (t, n) => {
		let r = t.public, i = t.private;
		if (!i?.choices.length) return null;
		let a = n.memory, o = {
			values: {
				...a?.values,
				...Object.fromEntries(i.values.map((e) => [e.id, e.value]))
			},
			turn: r.turn,
			trail: a?.turn === r.turn ? structuredClone(a.trail) : {}
		}, s = n.difficulty === "weak" ? {
			...e,
			danger: 0,
			aggression: .15,
			rescue: .4
		} : e, c = yt(r, !1), l = yt(r, !0), u = i.choices.map((e) => ({
			c: e,
			score: xt(r, n.rid, e, s, o, c, l)
		}));
		u.sort((e, t) => t.score - e.score || e.c.id.localeCompare(t.c.id));
		let d = u[0].c;
		if (d.cell && d.entity && [
			"move",
			"raftMove",
			"step",
			"pushTo"
		].includes(d.kind)) {
			let e = r.people.find((e) => e.id === d.entity)?.cell ?? r.rafts.find((e) => e.id === d.entity)?.cell ?? r.creatures.find((e) => e.id === d.entity)?.cell;
			e && (o.trail[d.entity] ??= []).push(e);
		}
		return {
			action: {
				type: "choose",
				id: d.id
			},
			memory: o
		};
	};
}
var Ct = St(), wt = (e, t, n) => {
	let r = e.type === "choose" ? t.private?.choices.find((t) => t.id === e.id) : null;
	return r?.cell ? n("games.survive.hintCell", { cell: r.cell }) : n("games.survive.hintAction");
};
//#endregion
//#region src/games/survive/fx.tsx
function Tt({ d: e }) {
	return e.piece === "person" ? /* @__PURE__ */ g(Z, {
		team: e.team,
		heart: e.heart
	}) : e.piece === "raft" ? /* @__PURE__ */ g(et, {}) : e.piece === "egg" ? /* @__PURE__ */ g(nt, {}) : /* @__PURE__ */ g(tt, { kind: e.piece });
}
function Et(e, t, n) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
function Dt(e, t) {
	if (!t.source) return null;
	let n = e.anchor(`cell:${t.source.cell}`), r = M[t.source.cell] ?? N.find((e) => e.id === t.source.cell);
	if (!n || !r) return null;
	let i = n.w / 100;
	return {
		x: n.x + (t.source.x - r.x + 50) * i,
		y: n.y + (t.source.y - r.y + 50) * i,
		w: t.source.w * i,
		h: t.source.h * i
	};
}
function Ot({ at: e, ms: t, frames: n, children: a }) {
	let o = i(null);
	return r(() => {
		let e = o.current?.animate(n, {
			duration: t,
			easing: "ease-in-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [n, t]), /* @__PURE__ */ g("div", {
		ref: o,
		className: "survive-fx-object",
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: a
	});
}
var kt = (e, t) => {
	let n = e.data, r = t.anchor(`piece:${n.id}`);
	if (!r) return null;
	let i = t.anchor(e.rid === t.myRid && n.piece === "person" ? `hand:${e.rid}` : "reserve"), a = Dt(t, n) ?? (i && i.w > 0 ? i : t.anchor(`seat:${e.rid}`));
	if (!a) return null;
	let o = n.source ? a : Et(a, r.w, r.h);
	return {
		ms: K.move,
		hide: t.queued ? [] : [`piece:${n.id}`, ...(n.riders ?? []).map((e) => `piece:${e.id}`)],
		node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(b, {
			from: o,
			to: r,
			ms: K.move,
			children: /* @__PURE__ */ g("div", {
				className: "survive-fx-object",
				style: {
					width: o.w,
					height: o.h
				},
				children: /* @__PURE__ */ g(Tt, { d: n })
			})
		}), n.riders?.map((e) => {
			let n = Dt(t, {
				...e,
				piece: "person"
			}), r = t.anchor(`piece:${e.id}`);
			return n && r ? /* @__PURE__ */ g(b, {
				from: n,
				to: r,
				ms: K.move,
				children: /* @__PURE__ */ g("div", {
					className: "survive-fx-object",
					style: {
						width: n.w,
						height: n.h
					},
					children: /* @__PURE__ */ g(Z, {
						team: e.team,
						heart: e.heart
					})
				})
			}, e.id) : null;
		})] })
	};
}, At = {
	move: kt,
	deploy: kt,
	rescue: kt,
	board(e, t) {
		let n = e.data, r = t.anchor(`piece:${n.id}`);
		return r ? {
			ms: K.move,
			hide: t.queued ? [] : [`piece:${n.id}`],
			node: /* @__PURE__ */ g(Ot, {
				at: r,
				ms: K.move,
				frames: [
					{ transform: "translateY(6px) scale(.8)" },
					{
						transform: "translateY(-5px) scale(1.12)",
						offset: .5
					},
					{ transform: "none" }
				],
				children: /* @__PURE__ */ g(Z, {
					team: n.team,
					heart: n.heart
				})
			})
		} : null;
	},
	lost(e, t) {
		let n = e.data, r = Dt(t, n);
		return r ? {
			ms: K.attack,
			node: /* @__PURE__ */ g(Ot, {
				at: r,
				ms: K.attack,
				frames: [
					{
						transform: "none",
						opacity: 1
					},
					{
						transform: "translateY(5px) rotate(12deg) scale(.92)",
						opacity: 1,
						offset: .3
					},
					{
						transform: "translateY(20px) rotate(-15deg) scale(.35)",
						opacity: 0
					}
				],
				children: /* @__PURE__ */ g(Tt, { d: n })
			})
		} : null;
	},
	sink(e, t) {
		let n = e.data, r = t.anchor(`cell:${n.cell}`);
		return r ? {
			ms: K.reveal,
			node: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Ot, {
				at: r,
				ms: K.reveal,
				frames: [
					{
						transform: "perspective(350px) rotateX(0deg)",
						opacity: 1
					},
					{
						transform: "perspective(350px) rotateX(80deg) translateY(12px)",
						opacity: .9,
						offset: .5
					},
					{
						transform: "perspective(350px) rotateX(100deg) translateY(22px)",
						opacity: 0
					}
				],
				children: /* @__PURE__ */ g("svg", {
					viewBox: "-60 -60 120 120",
					children: /* @__PURE__ */ g(Qe, { terrain: n.terrain })
				})
			}), n.back && /* @__PURE__ */ g(Ot, {
				at: r,
				ms: K.reveal,
				frames: [
					{
						transform: "scale(.6)",
						opacity: 0
					},
					{
						transform: "scale(1.25)",
						opacity: 1,
						offset: .65
					},
					{
						transform: "scale(.9)",
						opacity: 0
					}
				],
				children: /* @__PURE__ */ g("img", {
					src: Y[n.back],
					alt: ""
				})
			})] })
		} : null;
	},
	gain(e, t) {
		let n = e.data, r = e.secret, i = t.anchor(`cell:${n.cell}`), a = e.rid === t.myRid ? t.anchor(`card:${n.card}`) ?? t.anchor(`hand:${e.rid}`) : t.anchor(`seat:${e.rid}`);
		if (!i || !a) return null;
		let o = Et(a, Math.min(75, a.w), Math.min(65, a.h));
		return {
			ms: K.reveal,
			hide: t.queued || e.rid !== t.myRid ? [] : [`card:${n.card}`],
			node: /* @__PURE__ */ g(b, {
				from: i,
				to: o,
				ms: K.reveal,
				children: /* @__PURE__ */ g("div", {
					className: "survive-fx-card",
					style: {
						width: i.w,
						height: i.h
					},
					children: r?.ability ? /* @__PURE__ */ g("img", {
						src: Y[r.ability],
						alt: ""
					}) : /* @__PURE__ */ g("svg", {
						viewBox: "-60 -60 120 120",
						children: /* @__PURE__ */ g(Qe, { terrain: "forest" })
					})
				})
			})
		};
	},
	ability(e, t) {
		let n = e.data, r = e.rid === t.myRid ? t.anchor(`hand:${e.rid}`) : t.anchor(`seat:${e.rid}`), i = n.cell ? t.anchor(`cell:${n.cell}`) : n.entity ? t.anchor(`piece:${n.entity}`) : t.anchor("maparea");
		if (!r || !i || !n.ability) return null;
		let a = Et(r, 70, 62), o = Et(i, 88, 78);
		return {
			ms: K.card,
			node: /* @__PURE__ */ g(b, {
				from: a,
				to: o,
				ms: K.card,
				children: /* @__PURE__ */ g("div", {
					className: "survive-fx-card",
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ g("img", {
						src: Y[n.ability],
						alt: ""
					})
				})
			})
		};
	},
	die(e, t) {
		let n = e.data, r = t.anchor("dice"), i = t.anchor("maparea"), a = r && r.w > 0 ? r : i ? Et(i, 72, 72) : null;
		return a ? {
			ms: K.die,
			hide: ["dice"],
			node: /* @__PURE__ */ g(Ot, {
				at: a,
				ms: K.die,
				frames: [
					{ transform: "rotate(-120deg) scale(.6)" },
					{
						transform: "rotate(80deg) scale(1.15)",
						offset: .45
					},
					{
						transform: "rotate(-12deg)",
						offset: .8
					},
					{ transform: "none" }
				],
				children: /* @__PURE__ */ g("div", {
					className: "survive-fx-die",
					"data-color": n.color,
					children: /* @__PURE__ */ g("img", {
						src: Y[n.color === "red" ? "serpent" : n.color === "green" ? "shark" : "kaiju"],
						alt: ""
					})
				})
			})
		} : null;
	},
	attack(e, t) {
		let n = e.data, r = t.anchor(`piece:${n.id}`);
		return r ? {
			ms: K.attack,
			hide: t.queued ? [] : [`piece:${n.id}`],
			node: /* @__PURE__ */ g(Ot, {
				at: r,
				ms: K.attack,
				frames: [
					{ transform: "none" },
					{
						transform: "translateY(-10px) rotate(-8deg) scale(1.22)",
						offset: .35
					},
					{
						transform: "translateY(3px) rotate(5deg)",
						offset: .6
					},
					{ transform: "none" }
				],
				children: /* @__PURE__ */ g(Tt, { d: n })
			})
		} : null;
	},
	hatch(e, t) {
		let n = e.data, r = t.anchor(`cell:${n.cell}`);
		return r ? {
			ms: K.die,
			node: /* @__PURE__ */ g(Ot, {
				at: Et(r, r.w * .5, r.h * .6),
				ms: K.die,
				frames: [
					{
						transform: "rotate(-12deg)",
						opacity: 1
					},
					{
						transform: "rotate(16deg) scale(1.15)",
						offset: .4
					},
					{
						transform: "rotate(-18deg) scale(1.4)",
						opacity: 0
					}
				],
				children: /* @__PURE__ */ g(nt, {})
			})
		} : null;
	},
	turn(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: K.turn,
			node: /* @__PURE__ */ g(te, {
				at: n,
				ms: K.turn
			})
		} : null;
	}
};
//#endregion
//#region src/games/survive/game-over.tsx
function jt({ public: e, result: t, members: n, myRid: r, hintCount: i, onPlayAgain: o, onBackToLobby: s }) {
	let u = e, d = l(), f = c((e) => e.locale), [m, v] = a(!1), [y, b] = a(null), [te, x] = a(null), S = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ee(t, f) : e;
	}, C = t.winner.map(S).join(f === "zh" ? "、" : ", ");
	return /* @__PURE__ */ _(p, {
		adaptive: !0,
		className: "survive-screen survive-over",
		scroll: !1,
		banner: /* @__PURE__ */ _("header", {
			className: "survive-header",
			children: [/* @__PURE__ */ g("div", {
				className: "survive-title",
				children: /* @__PURE__ */ g("h1", { children: d("games.survive.final") })
			}), /* @__PURE__ */ g("button", {
				className: "survive-quiet",
				onClick: () => v(!m),
				children: d(m ? "games.survive.showResult" : "games.survive.review")
			})]
		}),
		actionsHeight: "survive-result-actions-height",
		actions: /* @__PURE__ */ g("div", {
			className: "survive-result-actions",
			children: o || s ? /* @__PURE__ */ _(h, { children: [o && /* @__PURE__ */ g("button", {
				className: "survive-primary",
				onClick: () => x("again"),
				children: d("session.result.playAgain")
			}), s && /* @__PURE__ */ g("button", {
				className: "survive-quiet",
				onClick: () => x("leave"),
				children: d("session.result.backToLobby")
			})] }) : /* @__PURE__ */ g("span", { children: d("session.result.waitHost") })
		}),
		children: [/* @__PURE__ */ _("div", {
			className: "survive-result-body",
			children: [/* @__PURE__ */ g("div", {
				className: "survive-final-map",
				children: /* @__PURE__ */ g(ft, { pub: u })
			}), /* @__PURE__ */ _("section", {
				className: "survive-manifest",
				hidden: m,
				children: [
					/* @__PURE__ */ g("h2", { children: d(t.winner.length > 1 ? "games.survive.tie" : "games.survive.winners", { name: C }) }),
					i !== void 0 && /* @__PURE__ */ g("p", { children: d("session.hint.usedCount", { n: i }) }),
					/* @__PURE__ */ g("div", {
						className: "survive-result-list",
						children: t.ranking.map((e) => {
							let n = u.scores.find((t) => t.rid === e);
							return /* @__PURE__ */ _("article", {
								className: "survive-result-row",
								"data-winner": t.winner.includes(e),
								children: [
									/* @__PURE__ */ _("button", {
										className: "survive-result-player",
										"aria-expanded": y === e,
										onClick: () => b(y === e ? null : e),
										children: [/* @__PURE__ */ _("span", { children: [
											t.winner.includes(e) && /* @__PURE__ */ g("span", {
												"aria-hidden": !0,
												children: "★ "
											}),
											S(e),
											e === r && /* @__PURE__ */ _("small", { children: [" ", d("lobby.you")] })
										] }), /* @__PURE__ */ g("b", { children: n.total })]
									}),
									/* @__PURE__ */ _("dl", { children: [
										/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: d("games.survive.treasure") }), /* @__PURE__ */ g("dd", { children: n.treasure })] }),
										/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: d("games.survive.bffScore") }), /* @__PURE__ */ g("dd", { children: n.bff })] }),
										/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: d("games.survive.rescued") }), /* @__PURE__ */ g("dd", { children: n.rescued })] }),
										/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("dt", { children: d("games.survive.lost") }), /* @__PURE__ */ g("dd", { children: n.lost })] })
									] }),
									!!t.autopilot?.[e] && /* @__PURE__ */ g("p", { children: d("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) }) }),
									y === e && /* @__PURE__ */ g("div", {
										className: "survive-value-list",
										"aria-label": d("games.survive.rescuedValues"),
										children: n.values.map((e) => /* @__PURE__ */ _("div", { children: [
											/* @__PURE__ */ g(Z, {
												team: e.team,
												heart: e.heart
											}),
											/* @__PURE__ */ g("span", { children: d("games.survive.number", { n: Number(e.id.split("-")[1]) + 1 }) }),
											/* @__PURE__ */ g("b", { children: e.heart ? d("games.survive.heart") : d("games.survive.value", { n: e.value }) })
										] }, e.id))
									})
								]
							}, e);
						})
					})
				]
			})]
		}), te && /* @__PURE__ */ g("div", {
			className: "survive-confirm-backdrop",
			children: /* @__PURE__ */ _("div", {
				role: "alertdialog",
				"aria-modal": "true",
				"aria-labelledby": "survive-confirm-title",
				className: "survive-confirm",
				children: [
					/* @__PURE__ */ g("h2", {
						id: "survive-confirm-title",
						children: d(te === "again" ? "games.survive.confirmAgain" : "games.survive.confirmLeave")
					}),
					/* @__PURE__ */ g("button", {
						className: "survive-quiet",
						autoFocus: !0,
						onClick: () => x(null),
						children: d("games.survive.cancelDecision")
					}),
					/* @__PURE__ */ g("button", {
						className: "survive-primary",
						onClick: () => {
							x(null), (te === "again" ? o : s)?.();
						},
						children: d("games.survive.confirmDecision")
					})
				]
			})
		})]
	});
}
//#endregion
//#region src/games/survive/options.tsx
function Mt({ value: e, onChange: t }) {
	let n = l(), r = T.safeParse(e), i = r.success ? r.data : T.parse(void 0);
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ g(S, {
				title: n("games.survive.redGroup"),
				columns: 3,
				children: [
					"serpent",
					"kraken",
					"both"
				].map((e) => /* @__PURE__ */ g(x, {
					name: "survive-red",
					value: e,
					checked: i.red === e,
					label: n(e === "serpent" ? "games.survive.serpent" : e === "kraken" ? "games.survive.kraken" : "games.survive.both"),
					accent: C.accent,
					onChange: () => t({
						...i,
						red: e
					})
				}, e))
			}),
			/* @__PURE__ */ g(S, {
				title: n("games.survive.greenGroup"),
				columns: 3,
				children: [
					"shark",
					"pterodactyl",
					"both"
				].map((e) => /* @__PURE__ */ g(x, {
					name: "survive-green",
					value: e,
					checked: i.green === e,
					label: n(e === "shark" ? "games.survive.shark" : e === "pterodactyl" ? "games.survive.pterodactyl" : "games.survive.both"),
					accent: C.accent,
					onChange: () => t({
						...i,
						green: e
					})
				}, e))
			}),
			/* @__PURE__ */ g(S, {
				title: n("games.survive.blueGroup"),
				columns: 3,
				children: [
					"kaiju",
					"whale",
					"both"
				].map((e) => /* @__PURE__ */ g(x, {
					name: "survive-blue",
					value: e,
					checked: i.blue === e,
					label: n(e === "kaiju" ? "games.survive.kaiju" : e === "whale" ? "games.survive.whale" : "games.survive.both"),
					accent: C.accent,
					onChange: () => t({
						...i,
						blue: e
					})
				}, e))
			}),
			[
				"piranha",
				"eggs",
				"bff"
			].map((e) => /* @__PURE__ */ g(S, {
				title: n(e === "piranha" ? "games.survive.piranha" : e === "eggs" ? "games.survive.egg" : "games.survive.bff"),
				columns: 2,
				children: [!1, !0].map((r) => /* @__PURE__ */ g(x, {
					name: `survive-${e}`,
					value: String(r),
					checked: i[e] === r,
					label: n(r ? "games.survive.on" : "games.survive.off"),
					accent: C.accent,
					onChange: () => t({
						...i,
						[e]: r
					})
				}, String(r)))
			}, e))
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/survive/entry.tsx
var Nt = {
	definition: Je,
	View: _t,
	bot: Ct,
	describe: wt,
	fx: At,
	OverView: jt,
	Options: Mt,
	locales: {
		zh: {
			cancelDecision: "取消",
			confirmDecision: "确认",
			name: "逃离绝命岛",
			desc: "带着宝藏逃离沉没的海岛，驾筏避开远古生物。",
			rules: "目标：\n将自己的冒险者送到四角救援岛，得救者携带的宝藏分值计入总分，最高者获胜。每队有10名冒险者，1至5分各两名。准备时查看并记住自己棋件的分值，正式回合开始后，任何人都不能再查看分值。\n\n准备：\n将16块沙滩、16块森林和8块山地随机铺成中央岛屿，不查看背面。基础版5条海蛇按地图标记入场，6条鲨鱼与2只巨兽放在库存。玩家轮流将一名自己的冒险者放到空岛块。5人局填满40格后，剩余冒险者放到只有一人的岛块。每人再轮流放置两只木筏，位置须为空、邻接岛块的海格。双人局每人控制两队，共20名冒险者与4只木筏，两队按同一玩家计算筏的控制权。\n\n回合：\n依次进行行动、水位上涨和生物三个阶段。行动阶段可分配至多3步移动，每步移动自己一名冒险者或一只自己能控制的木筏到相邻格。仍有冒险者待救时才能使用这3步。自己在筏上的人数不低于任何单个对手，即控制该筏；空筏人人可移动。木筏只能移到没有其他筏的海格，容量为3人。\n起点与终点都在陆地、筏或救援岛上为步行；任一端在海中为游泳。每名冒险者每回合最多游泳一次，但能力移动不受此限制。进入有空位木筏的格时立即登筏；空位不足时由当前回合玩家选择谁登筏。进入救援岛后得救，不能再返回海图。\n水位上涨时移除当前最低剩余种类的任意岛块，先沙滩、再森林、最后山地，不要求邻海。原格上的物件落入新海格。回合开始时自己已没有待救冒险者，则改为移除两块。红色效果立即处理；绿色能力暗置保留，在以后的行动阶段使用。最后掷生物骰，必须移动场上对应颜色的一只生物；没有可移动者则结束回合。\n\n生物：\n· 海蛇移动1个海格，消灭同格的木筏和全部冒险者。\n· 鲨鱼移动1至2个海格，只消灭同格泳者。\n· 巨兽移动1至2个海格或岛块，毁掉木筏，把冒险者推到任选相邻合法格，把其他生物按各自移动规则移开。当前回合玩家选择处理顺序及每个目标。其他物件不能进入巨兽所在格，另一只巨兽可以进入并推开原来一只。\n· 生物进入会发生互动的格时立即停止移动。生物之间通常可以同格。消灭的木筏与生物回到库存，冒险者死亡后不再回来，也不公开其分值。\n\n岛块效果：\n· 生物效果：绿色生物在原格放置一只绿色生物，蓝色生物放置蓝色生物；同色库存都用完时，从场上选一只移来。\n· 木筏效果从库存放一只到原格；库存用完时可移动场上一只空筏，没有空筏则不生效。\n· 漩涡：清除原格及所有相邻海格上的冒险者、生物、筏与蛋，不清除食人鱼板块。\n· 火山：清除原格物件并永久封闭该格。\n\n能力：\n· 划桨：将空筏或自己控制的筏移动1至2个海格。\n· 海豚：将自己一名泳者移动1至2格，可以在陆地或筏上结束；不能从陆地或筏上开始。\n· 潜水：把场上一只生物移到任意空海格。\n· 生物骰：额外掷骰并移动对应颜色生物，不替代回合末的正常生物阶段。\n· 驱除：自己冒险者与鲨鱼或巨兽同格时，可移除其中一只。受到攻击时先给相关玩家响应机会；一块能力只驱除一只，被驱除者本次不再攻击，该格其他冒险者和筏也获免。\n能力用后弃置；行动阶段可穿插使用多块能力，不消耗3步移动。\n\nMonster Pack：\n扩展选项默认关闭。红、绿、蓝三组中，每组至少选择一种生物，可以只使用基础生物、只使用扩展生物，或同时使用两者。各生物单独使用时的数量，以及与同色另一种生物混合使用时的数量如下：\n· 海蛇：单独使用时 5 条，混合使用时 3 条。\n· Kraken：单独使用时 4 只，混合使用时 2 只。\n· 鲨鱼：单独使用时 6 条，混合使用时 3 条。\n· 翼龙：单独使用时 3 只，混合使用时 2 只。\n· 巨兽：单独和混合使用时均为 2 只。\n· 鲸鱼：单独使用时 5 条，混合使用时 3 条。\n同色的两种生物同时在场时，召唤和掷骰所作用的生物类型均由当前玩家选择。\n· 鲸鱼：移动1至3个海格，只毁筏，原乘员落水后可能受到其他同格生物攻击。\n· 翼龙：沿六方向之一飞行任意距离，可飞越任何物件，只能落在没有火山、巨兽且至多一名冒险者的海格或岛块，消灭落点全部冒险者。\n· Kraken：移动1个海格并先消灭同格泳者，然后必须消灭本格或相邻格一名尚未得救的冒险者，包括陆地和筏上的人；只有自己的可选时也必须选择。冒险者进入Kraken邻格、或木筏进入其格，不会触发这次额外攻击。\n\n食人鱼与蛋：\n可独立开启。食人鱼用一块红效果替换一块沙滩生物骰能力。揭示后清除原格物件，留下永久食人鱼海格；5块绿色食人鱼能力从揭示者起顺时针轮发。使用时放到邻接现有食人鱼的海格，任何进入或放置其上的冒险者、生物、筏或蛋都被消灭。\n蛋用两块蛋板块替换一块绿色、一块蓝色沙滩生物效果。揭示后将蛋放在任选海格。自己下一行动阶段开始时掷骰孵化，蛋替换成该色库存生物；该色库存用完时移来一只场上生物。被清除的蛋不再孵化。\n\nBFF：\n开启后每队两名1分冒险者换成心形BFF。同色两名都得救，合计12分；只得救一名或没有得救则为0分。双人局分别判断两队的配对，其他冒险者正常计分。\n\n结束：\n第三座火山揭示，或所有冒险者均已得救或死亡时结束。未得救者不计分。最高总分者获胜，平分共享胜利。",
			errorAction: "当前不能执行此操作。",
			serpent: "海蛇",
			shark: "鲨鱼",
			kaiju: "巨兽",
			kraken: "Kraken",
			pterodactyl: "翼龙",
			whale: "鲸鱼",
			person: "冒险者",
			raft: "木筏",
			egg: "蛋",
			beach: "沙滩",
			forest: "森林",
			mountain: "山地",
			sea: "海域",
			volcano: "火山",
			whirlpool: "漩涡",
			paddle: "划桨",
			dolphin: "海豚",
			dive: "潜水",
			die: "生物骰",
			repellent: "驱除",
			piranha: "食人鱼",
			green: "绿色生物",
			blue: "蓝色生物",
			redGroup: "红色生物",
			greenGroup: "绿色生物",
			blueGroup: "蓝色生物",
			both: "两种共存",
			bff: "BFF心形冒险者",
			off: "关闭",
			on: "开启",
			setup: "放置冒险者",
			rafts: "放置木筏",
			action: "行动",
			sinking: "水位上涨",
			roll: "掷生物骰",
			creatures: "移动生物",
			done: "远征结束",
			choosePerson: "选择冒险者",
			chooseTarget: "选择落点",
			chooseTile: "移除一块最低地形",
			chooseCreature: "选择要移动的生物",
			chooseSpawn: "选择要入场的生物",
			chooseRaft: "选择一只空筏",
			chooseEgg: "放置蛋",
			chooseBoard: "选择登筏的冒险者",
			chooseAttack: "选择先行动的生物",
			chooseRepel: "使用驱除，或放弃响应",
			choosePush: "选择要推开的物件",
			choosePushTo: "选择推移落点",
			chooseKraken: "选择一名冒险者",
			waiting: "等待{{name}}",
			turn: "第{{n}}回合",
			moves: "剩余{{n}}步",
			waters: "本回合移除{{n}}块",
			rescued: "得救",
			alive: "待救",
			lost: "未得救",
			cards: "能力",
			reserve: "库存",
			myCrew: "我的船员",
			end: "结束行动",
			stop: "停止移动",
			pass: "放弃驱除",
			cancel: "取消选择",
			fit: "查看全图",
			cell: "海图格 {{cell}}",
			pawn: "{{name}}的{{team}}冒险者{{n}}",
			select: "选择{{name}}",
			number: "{{n}}号",
			value: "{{n}}分",
			heart: "心形BFF",
			abilityDetailPaddle: "将可控制的木筏移动1至2格。",
			abilityDetailDolphin: "将自己一名泳者移动1至2格，可在陆地或筏上结束。",
			abilityDetailDive: "将场上一只生物移至空海格。",
			abilityDetailDie: "额外掷骰并移动对应颜色生物。",
			abilityDetailRepellent: "移除与自己冒险者同格的一只鲨鱼或巨兽。",
			abilityDetailPiranha: "在现有食人鱼旁的海格放置食人鱼。",
			remember: "记住分值；正式回合开始后将不再显示。",
			selected: "已选择{{name}}",
			busy: "正在结算",
			final: "救援清点",
			winners: "{{name}}获胜",
			tie: "{{name}}共享胜利",
			treasure: "宝藏分值",
			bffScore: "BFF配对",
			total: "总分",
			rescuedValues: "得救冒险者",
			review: "回看海图",
			showResult: "展开救援清点",
			confirmAgain: "确定重新开始？",
			confirmLeave: "确定返回大厅？",
			hintCell: "选择海图格{{cell}}。",
			hintAction: "执行当前可用行动。",
			teamOrange: "橙队",
			teamRed: "红队",
			teamPurple: "紫队",
			teamBlue: "蓝队",
			teamYellow: "黄队"
		},
		en: {
			cancelDecision: "Cancel",
			confirmDecision: "Confirm",
			name: "Survive The Island",
			desc: "Escape a sinking island with your treasure, dodging ancient creatures.",
			rules: "Goal:\nLead your Adventurers to the four Rescue Islands. Rescued treasure scores; the highest total wins. Each team has ten Adventurers, two each worth 1 to 5. Check and remember your own values during setup. Once regular turns begin, nobody may inspect these values again.\n\nSetup:\nRandomly arrange 16 Beach, 16 Forest and 8 Mountain tiles in the central island without inspecting their backs. Place five Sea Serpents on their marked spaces; keep six Sharks and two Kaijus in reserve. In turn, place one Adventurer on an empty island tile. In five-player games, after all forty tiles are occupied, place the remaining Adventurers on tiles with just one Adventurer. Then take turns placing two Rafts each on empty Water spaces adjacent to the island. With two players, each controls two teams, twenty Adventurers and four Rafts. Both teams count as one player for Raft control.\n\nTurns:\nComplete Actions, Rising Waters and Creatures in order. During Actions, divide up to three one-space moves among your Adventurers and Rafts you control. You can use these three moves only while you have Adventurers left to rescue. You control a Raft if your passengers are at least as numerous as those of any individual opponent. Anyone may move an empty Raft. Rafts move only onto adjacent Water spaces without another Raft and hold three Adventurers.\nMoving between land, Rafts and Rescue Islands is walking. If either endpoint is open Water, it is swimming. Each Adventurer may swim only once per turn; Ability movement is exempt. Immediately board a Raft with a free seat. If there are more swimmers than seats, the active player chooses who boards. Reaching a Rescue Island rescues an Adventurer permanently.\nDuring Rising Waters, remove any tile of the lowest remaining type: Beaches, then Forests, then Mountains. It need not border Water. Objects on it remain on the revealed Water space. If you had no Adventurers left to rescue at the start of your turn, remove two tiles instead of one. Resolve red Effects immediately; keep green Abilities face down for a subsequent Action phase. Finally roll the Creature die and move one matching creature on the board if any can move.\n\nCreatures:\n· Sea Serpent: move one Water space; eliminate Rafts and all Adventurers on its space.\n· Shark: move one or two Water spaces; eliminate swimmers only.\n· Kaiju: move one or two Water and/or Land spaces; destroy Rafts, push Adventurers to chosen adjacent legal spaces, and displace other creatures using their movement rules. The active player chooses the order and destinations. Nothing may enter a Kaiju space except another Kaiju, which displaces the resident one.\n· A creature stops immediately on entering a space containing something it interacts with. Creatures may otherwise share spaces. Removed creatures and Rafts return to reserve. Eliminated Adventurers never return and their values remain hidden.\n\nTile Effects:\nGreen and Blue Creature tiles place a matching creature on the revealed space. If all creatures of that color are on the board, move one there instead. A Raft tile places a reserve Raft there; if none remain, move an empty Raft already on the board. With no empty Raft, nothing happens. A Whirlpool clears its own space and every adjacent Water space of Adventurers, creatures, Rafts and Eggs, but leaves Piranha tiles. A Volcano clears its space and permanently blocks it.\n\nAbilities:\n· Paddles: move an empty Raft or one you control one or two Water spaces.\n· Dolphin: move one of your swimmers one or two spaces, optionally ending on land or a Raft. It cannot start from land or a Raft.\n· Dive: move any creature on the board to any empty Water space.\n· Creature die: roll and move a matching creature, in addition to the normal Creature phase.\n· Repellent: when one of your Adventurers shares a space with a Shark or Kaiju, remove one such creature. Relevant players receive a response opportunity before an attack. Each Repellent removes just one creature; everyone and every Raft on its space is spared that attack.\nDiscard used Abilities. You may use multiple Abilities between moves during Actions without spending movement points.\n\nMonster Pack:\nExpansion options are off by default. Choose at least one creature of each color: base, expansion or both. Use the following quantities when a type is included alone or together with the other type of its color:\n· Sea Serpents: 5 alone, or 3 together.\n· Krakens: 4 alone, or 2 together.\n· Sharks: 6 alone, or 3 together.\n· Pterodactyls: 3 alone, or 2 together.\n· Kaijus: 2 in either case.\n· Whales: 5 alone, or 3 together.\nWhen both types of a color are included, the active player chooses the type for spawning and movement.\n· Whales move one to three Water spaces and destroy Rafts, leaving their passengers swimming and vulnerable to other creatures.\n· Pterodactyls fly any distance in one of six straight directions, over any objects. They may land only on Water or Land without a Volcano or Kaiju and with at most one Adventurer; they eliminate all Adventurers there.\n· A Kraken moves one Water space, eliminates swimmers there, then must eliminate one unrescued Adventurer on its space or any adjacent space, including on land or a Raft. It must choose your own Adventurer if no opponents are available. Moving Adventurers adjacent to a Kraken, or a Raft onto its space, does not trigger that extra attack.\n\nPiranhas and Eggs:\nThese modules can be enabled independently. Piranhas replace one Beach Creature Die Ability with a red Piranha Effect. Reveal it to clear its space and leave permanent Piranha Water. Deal the five green Piranha Abilities clockwise, starting with the revealing player. Play one on a Water space adjacent to existing Piranhas. Adventurers, creatures, Rafts and Eggs entering or placed there are eliminated.\nEggs replace one Green and one Blue Beach Creature Effect with two Egg tiles. Reveal an Egg tile to place an Egg on any Water space. At the beginning of your next Action phase, roll the die and replace it with a reserve creature of that color; if none remain, move an existing creature there. Removed Eggs do not hatch.\n\nBFF:\nReplace each team's two 1-point Adventurers with heart-shaped BFFs. Rescue both of the same color to score twelve points together; rescue only one or neither to score zero. With two players, check each team's pair independently. All other Adventurers score normally.\n\nEnd:\nThe third revealed Volcano, or all Adventurers being rescued or eliminated, ends the game. Unrescued Adventurers score nothing. The highest total wins; tied leaders share victory.",
			errorAction: "That action is not available now.",
			serpent: "Sea Serpent",
			shark: "Shark",
			kaiju: "Kaiju",
			kraken: "Kraken",
			pterodactyl: "Pterodactyl",
			whale: "Whale",
			person: "Adventurer",
			raft: "Raft",
			egg: "Egg",
			beach: "Beach",
			forest: "Forest",
			mountain: "Mountain",
			sea: "Water",
			volcano: "Volcano",
			whirlpool: "Whirlpool",
			paddle: "Paddles",
			dolphin: "Dolphin",
			dive: "Dive",
			die: "Creature die",
			repellent: "Repellent",
			piranha: "Piranhas",
			green: "Green creature",
			blue: "Blue creature",
			redGroup: "Red creatures",
			greenGroup: "Green creatures",
			blueGroup: "Blue creatures",
			both: "Both types",
			bff: "Heart-shaped BFFs",
			off: "Off",
			on: "On",
			setup: "Place Adventurers",
			rafts: "Place Rafts",
			action: "Actions",
			sinking: "Rising Waters",
			roll: "Roll the Creature die",
			creatures: "Move a creature",
			done: "Expedition ended",
			choosePerson: "Choose an Adventurer",
			chooseTarget: "Choose a destination",
			chooseTile: "Remove a lowest-level tile",
			chooseCreature: "Choose a creature to move",
			chooseSpawn: "Choose a creature to place",
			chooseRaft: "Choose an empty Raft",
			chooseEgg: "Place an Egg",
			chooseBoard: "Choose who boards",
			chooseAttack: "Choose which creature acts first",
			chooseRepel: "Use Repellent or pass",
			choosePush: "Choose an object to push",
			choosePushTo: "Choose where to push it",
			chooseKraken: "Choose an Adventurer",
			waiting: "Waiting for {{name}}",
			turn: "Turn {{n}}",
			moves: "{{n}} moves left",
			waters: "Remove {{n}} tiles this turn",
			rescued: "Rescued",
			alive: "To rescue",
			lost: "Unrescued",
			cards: "Abilities",
			reserve: "Reserve",
			myCrew: "My crew",
			end: "End Actions",
			stop: "Stop moving",
			pass: "Pass",
			cancel: "Cancel",
			fit: "Fit map",
			cell: "Map space {{cell}}",
			pawn: "{{name}}: {{team}} Adventurer {{n}}",
			select: "Select {{name}}",
			number: "No. {{n}}",
			value: "{{n}} points",
			heart: "Heart-shaped BFF",
			abilityDetailPaddle: "Move a Raft you control one or two spaces.",
			abilityDetailDolphin: "Move one of your swimmers one or two spaces, optionally ending on land or a Raft.",
			abilityDetailDive: "Move a creature on the board to empty Water.",
			abilityDetailDie: "Roll an extra die and move a matching creature.",
			abilityDetailRepellent: "Remove a Shark or Kaiju sharing a space with your Adventurer.",
			abilityDetailPiranha: "Place Piranhas on Water next to existing Piranhas.",
			remember: "Remember the values; they disappear when regular turns begin.",
			selected: "{{name}} selected",
			busy: "Resolving",
			final: "Rescue manifest",
			winners: "{{name}} wins",
			tie: "{{name}} share victory",
			treasure: "Treasure",
			bffScore: "BFF pairs",
			total: "Total",
			rescuedValues: "Rescued Adventurers",
			review: "Review map",
			showResult: "Show rescue manifest",
			confirmAgain: "Start a new expedition?",
			confirmLeave: "Return to the lobby?",
			hintCell: "Choose map space {{cell}}.",
			hintAction: "Take the available action.",
			teamOrange: "Orange",
			teamRed: "Red",
			teamPurple: "Purple",
			teamBlue: "Blue",
			teamYellow: "Yellow"
		}
	}
};
//#endregion
export { Nt as default };
