import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u, seatName as d } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { IconBack as g, IconBot as ee, IconExpand as _, IconLog as v } from "@bgparty/sdk/icons";
import { Confetti as y } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as b, OptionSection as te } from "@bgparty/sdk/ui/game-options";
//#region src/games/tend/data.ts
var x = {
	dot: [[0, 0]],
	i2: [[0, 0], [1, 0]],
	i3: [
		[0, 0],
		[1, 0],
		[2, 0]
	],
	l3: [
		[0, 0],
		[0, 1],
		[1, 1]
	],
	t4: [
		[0, 0],
		[1, 0],
		[2, 0],
		[1, 1]
	],
	o4: [
		[0, 0],
		[1, 0],
		[0, 1],
		[1, 1]
	],
	u5: [
		[0, 0],
		[2, 0],
		[0, 1],
		[1, 1],
		[2, 1]
	]
}, S = {
	pineapple: {
		cat: "farm",
		sell: 2,
		shape: "dot"
	},
	wildFruit: {
		cat: "farm",
		sell: 3,
		shape: "i3"
	},
	pumpkin: {
		cat: "farm",
		sell: 4,
		shape: "u5"
	},
	berries: {
		cat: "farm",
		sell: 2,
		shape: "l3"
	},
	egg: {
		cat: "farm",
		sell: 1,
		shape: "dot"
	},
	wool: {
		cat: "farm",
		sell: 2,
		shape: "l3"
	},
	milk: {
		cat: "farm",
		sell: 4,
		shape: "u5"
	},
	mamble: {
		cat: "fish",
		sell: 1,
		shape: "dot"
	},
	sunpop: {
		cat: "fish",
		sell: 2,
		shape: "i2"
	},
	blobber: {
		cat: "fish",
		sell: 3,
		shape: "i3"
	},
	geojell: {
		cat: "fish",
		sell: 1,
		shape: "dot"
	},
	pebblepuff: {
		cat: "fish",
		sell: 2,
		shape: "i2"
	},
	crankle: {
		cat: "fish",
		sell: 3,
		shape: "i3"
	},
	nessel: {
		cat: "fish",
		sell: 2,
		shape: "i2"
	},
	lillybloom: {
		cat: "fish",
		sell: 3,
		shape: "i3"
	},
	orbble: {
		cat: "fish",
		sell: 4,
		shape: "o4"
	},
	plumfish: {
		cat: "fish",
		sell: 2,
		shape: "i2"
	},
	shimmerpuff: {
		cat: "fish",
		sell: 3,
		shape: "i3"
	},
	gribble: {
		cat: "fish",
		sell: 4,
		shape: "o4"
	},
	stone: {
		cat: "mining",
		sell: 1,
		shape: "dot"
	},
	copper: {
		cat: "mining",
		sell: 1,
		shape: "dot"
	},
	iron: {
		cat: "mining",
		sell: 1,
		shape: "dot"
	},
	artifact: {
		cat: "mining",
		sell: 2,
		shape: "i2"
	},
	bone: {
		cat: "mining",
		sell: 2,
		shape: "i3"
	},
	ruby: {
		cat: "mining",
		sell: 2,
		shape: "i3"
	},
	crystal: {
		cat: "mining",
		sell: 3,
		shape: "t4"
	},
	rainbowRock: {
		cat: "mining",
		sell: 4,
		shape: "o4"
	},
	treeSap: {
		cat: "mining",
		sell: 4,
		shape: "o4"
	},
	redBp: {
		cat: "social",
		sell: 1,
		shape: "dot"
	},
	purpleBp: {
		cat: "social",
		sell: 2,
		shape: "i2"
	},
	heart: {
		cat: "social",
		sell: 0,
		shape: "o4"
	},
	medalCopper: {
		cat: "badge",
		sell: 3,
		shape: "i2"
	},
	medalSilver: {
		cat: "badge",
		sell: 3,
		shape: "i3"
	},
	medalGold: {
		cat: "badge",
		sell: 5,
		shape: "t4"
	},
	medalPlatinum: {
		cat: "badge",
		sell: 6,
		shape: "u5"
	}
}, C = {
	wood: 1,
	exoWood: 2
}, ne = [
	{
		cat: "mining",
		pts: 0
	},
	{
		cat: "mining",
		pts: 2
	},
	{
		cat: "farm",
		pts: 0
	}
], re = [
	"tend",
	"fish",
	"chop",
	"mine",
	"tend",
	"fish",
	"chop",
	"mine"
], ie = [
	"coin",
	"coin",
	"stone",
	"stone",
	"ruby",
	"ruby",
	"iron",
	"iron",
	"geode",
	"geode"
], w = [
	"coin",
	"coin",
	"wood",
	"wood",
	"wood",
	"wood",
	"exoWood",
	"exoWood",
	"bone",
	"treeSap"
], T = [
	"wood",
	"purpleBp",
	"exoWood",
	"artifact",
	"bone",
	"redBp",
	"heart",
	"treeSap"
], E = [
	"stone",
	"redBp",
	"copper",
	"iron",
	"geode",
	"purpleBp",
	"heart",
	"rainbowRock"
], D = {
	pineapple: {
		good: "pineapple",
		size: 2,
		trellis: !1,
		faces: [
			1,
			"w2",
			3,
			"wx"
		]
	},
	berries: {
		good: "berries",
		size: 2,
		trellis: !0,
		faces: [
			1,
			"w2",
			3,
			"wx"
		]
	},
	wildFruit: {
		good: "wildFruit",
		size: 3,
		trellis: !1,
		faces: [
			1,
			2,
			"wx"
		]
	},
	pumpkin: {
		good: "pumpkin",
		size: 4,
		trellis: !1,
		faces: [
			1,
			2,
			"wx"
		]
	}
}, O = {
	chicken: {
		good: "egg",
		size: 2,
		rowCount: 4,
		rowCost: 2,
		faces: [
			1,
			"w2",
			3,
			"wr"
		]
	},
	sheep: {
		good: "wool",
		size: 3,
		rowCount: 3,
		rowCost: 3,
		faces: [
			1,
			2,
			"wr"
		]
	},
	cow: {
		good: "milk",
		size: 4,
		rowCount: 1,
		rowCost: 4,
		faces: [
			1,
			2,
			"wr"
		]
	}
}, ae = [
	"wood",
	"wood",
	"coin"
], k = [[
	"copper",
	"redBp",
	"coin",
	"coin"
], [
	"iron",
	"purpleBp",
	"coin",
	"coin"
]], A = [[
	"wood",
	"coin",
	"stone"
], [
	"wood",
	"coin",
	"copper"
]], j = [["wood", "coin"], ["coin", "coin"]], M = [["exoWood", "coin"], ["exoWood", "coin"]], oe = [[
	"treeSap",
	"coin",
	"coin",
	"coin"
], [
	"rainbowRock",
	"coin",
	"coin",
	"coin"
]], se = [
	{
		cost: ["coin"],
		till: 1,
		fence: 1
	},
	{
		cost: ["stone"],
		till: 0,
		fence: 3
	},
	{
		cost: ["copper"],
		till: 0,
		fence: 4
	},
	{
		cost: ["exoWood"],
		till: 0,
		fence: 5
	}
], ce = {
	1: "wood",
	3: "iron"
}, le = [
	"exoWood",
	"artifact",
	"bone",
	"treeSap"
], ue = [
	{
		good: "wood",
		cost: 1
	},
	{
		good: "copper",
		cost: 1
	},
	{
		good: "exoWood",
		cost: 3
	},
	{
		good: "iron",
		cost: 3
	},
	{
		good: "redBp",
		cost: 3
	},
	{
		good: "purpleBp",
		cost: 4
	}
], N = [
	{
		id: "basicWoods",
		vp: 5,
		rows: [
			{
				cost: [
					"wood",
					"wood",
					"wood"
				],
				medal: "medalCopper"
			},
			{
				cost: [
					"wood",
					"wood",
					"artifact"
				],
				medal: "medalSilver"
			},
			{
				cost: [
					"wood",
					"wood",
					"artifact"
				],
				medal: "medalSilver"
			}
		]
	},
	{
		id: "basicMines",
		vp: 5,
		rows: [
			{
				cost: [
					"stone",
					"stone",
					"stone"
				],
				medal: "medalCopper"
			},
			{
				cost: [
					"stone",
					"copper",
					"copper"
				],
				medal: "medalCopper"
			},
			{
				cost: [
					"stone",
					"copper",
					"copper"
				],
				medal: "medalCopper"
			}
		]
	},
	{
		id: "basicFishing",
		vp: 5,
		rows: [
			{
				cost: [
					"mamble",
					"mamble",
					"sunpop"
				],
				medal: "medalCopper"
			},
			{
				cost: [
					"mamble",
					"mamble",
					"blobber"
				],
				medal: "medalSilver"
			},
			{
				cost: [
					"geojell",
					"geojell",
					"pebblepuff"
				],
				medal: "medalSilver"
			}
		]
	},
	{
		id: "advWoods",
		vp: 10,
		rows: [
			{
				cost: [
					"exoWood",
					"exoWood",
					"exoWood"
				],
				medal: "medalSilver"
			},
			{
				cost: [
					"exoWood",
					"exoWood",
					"bone"
				],
				medal: "medalGold"
			},
			{
				cost: [
					"exoWood",
					"exoWood",
					"treeSap"
				],
				medal: "medalPlatinum"
			}
		]
	},
	{
		id: "advMines",
		vp: 10,
		rows: [
			{
				cost: [
					"iron",
					"iron",
					"iron"
				],
				medal: "medalSilver"
			},
			{
				cost: [
					"iron",
					"iron",
					"ruby"
				],
				medal: "medalGold"
			},
			{
				cost: [
					"iron",
					"iron",
					"crystal"
				],
				medal: "medalPlatinum"
			}
		]
	},
	{
		id: "advFishing",
		vp: 10,
		rows: [
			{
				cost: [
					"pebblepuff",
					"pebblepuff",
					"crankle"
				],
				medal: "medalGold"
			},
			{
				cost: [
					"lillybloom",
					"lillybloom",
					"orbble"
				],
				medal: "medalPlatinum"
			},
			{
				cost: [
					"shimmerpuff",
					"shimmerpuff",
					"gribble"
				],
				medal: "medalPlatinum"
			}
		]
	},
	{
		id: "plants",
		vp: 15,
		rows: [
			{
				cost: [
					"pineapple",
					"pineapple",
					"wildFruit"
				],
				medal: "medalSilver"
			},
			{
				cost: [
					"berries",
					"berries",
					"berries"
				],
				medal: "medalGold"
			},
			{
				cost: [
					"berries",
					"wildFruit",
					"pumpkin"
				],
				medal: "medalPlatinum"
			}
		]
	},
	{
		id: "animals",
		vp: 15,
		rows: [
			{
				cost: [
					"egg",
					"egg",
					"egg"
				],
				medal: "medalCopper"
			},
			{
				cost: [
					"wool",
					"wool",
					"wool"
				],
				medal: "medalGold"
			},
			{
				cost: [
					"egg",
					"wool",
					"milk"
				],
				medal: "medalPlatinum"
			}
		]
	},
	{
		id: "generalist",
		vp: 20,
		rows: [
			{
				cost: [
					"wool",
					"wildFruit",
					"berries"
				],
				medal: "medalGold"
			},
			{
				cost: [
					"artifact",
					"rainbowRock",
					"bone"
				],
				medal: "medalGold"
			},
			{
				cost: [
					"geojell",
					"plumfish",
					"nessel"
				],
				medal: "medalGold"
			}
		]
	}
], de = {
	M: "mamble",
	U: "sunpop",
	B: "blobber",
	W: "wood",
	G: "geojell",
	P: "pebblepuff",
	C: "crankle",
	X: "exoWood",
	A: "artifact",
	N: "nessel",
	L: "lillybloom",
	O: "orbble",
	E: "bone",
	F: "plumfish",
	H: "shimmerpuff",
	I: "gribble",
	D: "geode",
	R: "ruby",
	Y: "crystal",
	Q: "rainbowRock"
}, P = Object.fromEntries([
	{
		id: "pond",
		grid: [
			"MMWBM",
			"MB..M",
			"M..MM",
			".UMMU",
			"UM.U."
		]
	},
	{
		id: "river",
		grid: [
			"GXPGC",
			"GG.G.",
			"PG.GP",
			"G.GAG",
			"C.P.C"
		]
	},
	{
		id: "lake",
		grid: [
			"L.EOL",
			"NNN.N",
			"L.LN.",
			".NNNN",
			"OEN.O"
		]
	},
	{
		id: "grotto",
		grid: [
			"DI.FD",
			"FFF.I",
			".F.FH",
			"FHFFF",
			"H.HI."
		]
	},
	{
		id: "geode",
		grid: [
			"RERYR",
			"RERYR",
			"EQQQY",
			"EAAAY",
			"AEAYA"
		]
	}
].map((e) => [e.id, e.grid.flatMap((e) => [...e].map((e) => e === "." ? null : de[e]))])), fe = [
	"tend",
	"tend",
	"chop",
	"chop",
	"mine",
	"mine",
	"fish",
	"fish",
	"zenithOrders"
], pe = [
	[0, 8],
	[0, 8],
	[0, 9],
	[0, 9],
	[0, 9],
	[0, 9],
	[0, 10],
	[0, 10],
	[0, 10],
	[2, 8],
	[4, 8],
	[4, 8]
], me = [
	[10, 4],
	[10, 5],
	[10, 6],
	[11, 4],
	[11, 5],
	[11, 6]
], he = [
	"h:0:1",
	"h:0:2",
	"h:0:3",
	"h:0:4",
	"v:1:0",
	"v:2:0",
	"v:3:0"
], F = [
	{
		goods: ["egg"],
		bonus: 1
	},
	{
		goods: ["egg"],
		bonus: 1
	},
	{
		goods: ["egg"],
		bonus: 1
	},
	{
		goods: ["egg"],
		bonus: 1
	},
	{
		goods: ["egg"],
		bonus: 1
	},
	{
		goods: ["egg"],
		bonus: 1
	},
	{
		goods: ["pineapple"],
		bonus: 1
	},
	{
		goods: ["pineapple"],
		bonus: 1
	},
	{
		goods: ["pineapple"],
		bonus: 1
	},
	{
		goods: ["pineapple"],
		bonus: 1
	},
	{
		goods: ["pineapple"],
		bonus: 1
	},
	{
		goods: ["pineapple"],
		bonus: 1
	},
	{
		goods: ["geojell", "sunpop"],
		bonus: 1
	},
	{
		goods: ["geojell", "sunpop"],
		bonus: 1
	},
	{
		goods: ["geojell", "sunpop"],
		bonus: 1
	},
	{
		goods: ["geojell", "sunpop"],
		bonus: 1
	},
	{
		goods: ["geojell", "sunpop"],
		bonus: 1
	},
	{
		goods: ["geojell", "sunpop"],
		bonus: 1
	},
	{
		goods: ["mamble", "sunpop"],
		bonus: 1
	},
	{
		goods: ["mamble", "sunpop"],
		bonus: 1
	},
	{
		goods: ["mamble", "sunpop"],
		bonus: 1
	},
	{
		goods: ["mamble", "sunpop"],
		bonus: 1
	},
	{
		goods: ["mamble", "sunpop"],
		bonus: 1
	},
	{
		goods: ["mamble", "sunpop"],
		bonus: 1
	},
	{
		goods: ["berries", "wool"],
		bonus: 2
	},
	{
		goods: ["berries", "wool"],
		bonus: 2
	},
	{
		goods: ["exoWood"],
		bonus: 2
	},
	{
		goods: ["exoWood"],
		bonus: 2
	},
	{
		goods: ["copper", "artifact"],
		bonus: 2
	},
	{
		goods: ["copper", "artifact"],
		bonus: 2
	},
	{
		goods: ["blobber", "pebblepuff"],
		bonus: 2
	},
	{
		goods: ["blobber", "pebblepuff"],
		bonus: 2
	},
	{
		goods: ["blobber", "pebblepuff"],
		bonus: 2
	},
	{
		goods: ["blobber", "pebblepuff"],
		bonus: 2
	},
	{
		goods: ["wildFruit", "wool"],
		bonus: 2
	},
	{
		goods: ["wildFruit", "wool"],
		bonus: 2
	}
], ge = [
	6,
	10,
	12
], _e = [
	{
		upgrades: 3,
		resources: { wood: 6 }
	},
	{
		upgrades: 2,
		resources: { wood: 5 }
	},
	{
		upgrades: 3,
		resources: {
			wood: 2,
			artifact: 2,
			exoWood: 2
		}
	},
	{
		upgrades: 3,
		resources: {
			wood: 1,
			artifact: 2,
			exoWood: 2
		}
	},
	{
		upgrades: 3,
		resources: {
			exoWood: 4,
			bone: 2
		}
	},
	{
		upgrades: 4,
		resources: {
			exoWood: 4,
			bone: 2
		}
	},
	{
		upgrades: 3,
		resources: {
			exoWood: 3,
			geode: 1,
			treeSap: 2
		}
	},
	{
		upgrades: 4,
		resources: {
			exoWood: 2,
			geode: 2,
			treeSap: 2
		}
	}
], ve = [
	{
		upgrades: 2,
		resources: {
			stone: 5,
			copper: 1
		}
	},
	{
		upgrades: 3,
		resources: {
			stone: 4,
			copper: 1
		}
	},
	{
		upgrades: 3,
		resources: {
			copper: 4,
			stone: 2
		}
	},
	{
		upgrades: 3,
		resources: {
			copper: 2,
			iron: 3
		}
	},
	{
		upgrades: 3,
		resources: {
			ruby: 2,
			iron: 2,
			geode: 1,
			artifact: 1
		}
	},
	{
		upgrades: 4,
		resources: {
			ruby: 2,
			iron: 2,
			geode: 1,
			artifact: 1
		}
	},
	{
		upgrades: 3,
		resources: {
			bone: 1,
			geode: 2,
			crystal: 2,
			rainbowRock: 1
		}
	},
	{
		upgrades: 4,
		resources: {
			crystal: 2,
			bone: 1,
			geode: 2,
			rainbowRock: 1
		}
	}
], ye = [
	{
		row: 0,
		col: 4,
		content: "chop"
	},
	{
		row: 1,
		col: 4,
		content: "wood"
	},
	{
		row: 1,
		col: 3,
		content: "chop"
	},
	{
		row: 2,
		col: 3,
		content: "wood"
	},
	{
		row: 3,
		col: 3,
		content: "chopGold"
	},
	{
		row: 3,
		col: 2,
		content: "wood"
	},
	{
		row: 4,
		col: 2,
		content: "chopUpgraded"
	},
	{
		row: 5,
		col: 2,
		content: "exoWood"
	},
	{
		row: 6,
		col: 2,
		content: "chopUpgraded"
	},
	{
		row: 7,
		col: 2,
		content: "exoWood"
	}
], be = [
	{
		row: 0,
		col: 4,
		content: "mine"
	},
	{
		row: 1,
		col: 4,
		content: "stone"
	},
	{
		row: 1,
		col: 3,
		content: "mine"
	},
	{
		row: 2,
		col: 3,
		content: "copper"
	},
	{
		row: 3,
		col: 3,
		content: "mineGold"
	},
	{
		row: 3,
		col: 2,
		content: "copper"
	},
	{
		row: 4,
		col: 2,
		content: "mineUpgraded"
	},
	{
		row: 5,
		col: 2,
		content: "iron"
	},
	{
		row: 6,
		col: 2,
		content: "mineUpgraded"
	},
	{
		row: 7,
		col: 2,
		content: "geode"
	}
];
function xe(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; t--) {
		let a = e(n, r, t + 1);
		r += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return {
		out: i,
		cursor: r
	};
}
function Se(e, t, n) {
	let r = e === "woods" ? _e : ve, i = new Map((e === "woods" ? ye : be).map((e) => [e.row * 7 + e.col, e.content])), a = Array(56);
	for (let e = 0; e < 8; e += 2) {
		let o = [], s = 0;
		for (let t = e; t < e + 2; t++) {
			let e = r[t];
			s += e.upgrades;
			for (let [t, n] of Object.entries(e.resources)) for (let e = 0; e < n; e++) o.push(t);
		}
		let c = Array.from({ length: o.length }, (e, t) => t < s), l = xe(o, t, n);
		n = l.cursor;
		let u = xe(c, t, n);
		n = u.cursor;
		let d = 0;
		for (let t = e; t < e + 2; t++) for (let e = 0; e < 7; e++) {
			let n = t * 7 + e, r = i.get(n);
			r === void 0 ? (a[n] = {
				content: l.out[d],
				upgrade: u.out[d],
				fixed: !1
			}, d += 1) : a[n] = {
				content: r,
				upgrade: !1,
				fixed: !0
			};
		}
	}
	return {
		cells: a,
		nextCursor: n
	};
}
//#endregion
//#region src/games/tend/tasks.ts
var I = (e) => ({
	kind: "tasks",
	tasks: e
}), L = (...e) => ({
	kind: "goods",
	goods: e
}), R = (...e) => ({
	kind: "pick",
	options: e
}), Ce = (e) => ({
	kind: "coins",
	n: e
}), z = (...e) => ({
	kind: "freeTask",
	tasks: e
}), B = (...e) => ({
	kind: "choice",
	options: e
}), we = (...e) => ({
	kind: "bundle",
	parts: e
}), Te = [
	"basicFishing",
	"advFishing",
	"plants",
	"animals"
], Ee = [
	"basicWoods",
	"basicMines",
	"basicFishing",
	"advWoods",
	"advMines",
	"advFishing",
	"plants",
	"animals",
	"generalist"
], De = [
	{
		id: "s1-01",
		season: 1,
		adv: !0,
		top: I(["mine", "chop"]),
		cond: {
			kind: "mineLevel",
			n: 3
		},
		bottom: L("wood", "wood")
	},
	{
		id: "s1-02",
		season: 1,
		adv: !1,
		top: I(["mine", "fish"]),
		cond: {
			kind: "mineLevel",
			n: 2
		},
		bottom: L("pebblepuff")
	},
	{
		id: "s1-03",
		season: 1,
		adv: !0,
		top: {
			kind: "coins",
			n: 2
		},
		cond: {
			kind: "energyBars",
			n: 1
		},
		bottom: { kind: "anyTask" }
	},
	{
		id: "s1-04",
		season: 1,
		adv: !1,
		top: I(["tend", "chop"]),
		cond: {
			kind: "animals",
			n: 1
		},
		bottom: L("wood", "wood")
	},
	{
		id: "s1-05",
		season: 1,
		adv: !0,
		top: I(["tend", "fish"]),
		cond: {
			kind: "trellis",
			n: 1
		},
		bottom: L("sunpop")
	},
	{
		id: "s1-06",
		season: 1,
		adv: !1,
		top: I(["tend", "mine"]),
		cond: {
			kind: "tilled",
			n: 12
		},
		bottom: L("artifact")
	},
	{
		id: "s1-07",
		season: 1,
		adv: !0,
		top: I(["mine", "chop"]),
		cond: {
			kind: "cargoCols",
			n: 1
		},
		bottom: Ce(3)
	},
	{
		id: "s1-08",
		season: 1,
		adv: !0,
		top: I(["tend", "fish"]),
		cond: {
			kind: "cargoCols",
			n: 1
		},
		bottom: Ce(3)
	},
	{
		id: "s1-09",
		season: 1,
		adv: !0,
		top: I(["tend", "chop"]),
		cond: {
			kind: "and",
			all: [{
				kind: "animals",
				n: 1
			}, {
				kind: "chopLevel",
				n: 2
			}]
		},
		bottom: L("mamble", "copper")
	},
	{
		id: "s1-10",
		season: 1,
		adv: !0,
		top: I([
			"tend",
			"mine",
			"fish"
		]),
		cond: {
			kind: "cargoFilled",
			n: 8
		},
		bottom: L("wood", "wood")
	},
	{
		id: "s1-11",
		season: 1,
		adv: !1,
		top: I(["chop", "fish"]),
		cond: {
			kind: "unlock",
			what: "rod"
		},
		bottom: L("iron")
	},
	{
		id: "s1-12",
		season: 1,
		adv: !1,
		top: I(["tend", "chop"]),
		cond: {
			kind: "chopLevel",
			n: 2
		},
		bottom: L("wool")
	},
	{
		id: "s1-13",
		season: 1,
		adv: !1,
		top: I(["tend", "mine"]),
		cond: {
			kind: "mineLevel",
			n: 2
		},
		bottom: R("pineapple", "egg")
	},
	{
		id: "s1-14",
		season: 1,
		adv: !1,
		top: I(["chop", "fish"]),
		cond: {
			kind: "chopLevel",
			n: 2
		},
		bottom: L("artifact")
	},
	{
		id: "s1-15",
		season: 1,
		adv: !1,
		top: I(["mine", "fish"]),
		cond: {
			kind: "unlock",
			what: "river"
		},
		bottom: L("sunpop")
	},
	{
		id: "s1-16",
		season: 1,
		adv: !0,
		top: I(["mine", "fish"]),
		cond: {
			kind: "and",
			all: [{
				kind: "mineLevel",
				n: 2
			}, {
				kind: "unlock",
				what: "river"
			}]
		},
		bottom: L("egg", "wood")
	},
	{
		id: "s1-17",
		season: 1,
		adv: !0,
		top: I([
			"tend",
			"mine",
			"chop"
		]),
		cond: {
			kind: "equipUpgrades",
			n: 1
		},
		bottom: L("purpleBp")
	},
	{
		id: "s1-18",
		season: 1,
		adv: !0,
		top: I(["chop", "fish"]),
		cond: {
			kind: "unlock",
			what: "rod"
		},
		bottom: Ce(2)
	},
	{
		id: "s1-19",
		season: 1,
		adv: !0,
		top: I([
			"tend",
			"chop",
			"fish"
		]),
		cond: {
			kind: "neighborBonus",
			n: 2
		},
		bottom: L("redBp")
	},
	{
		id: "s1-20",
		season: 1,
		adv: !0,
		top: I(["mine", "chop"]),
		cond: {
			kind: "chopLevel",
			n: 3
		},
		bottom: L("stone", "copper")
	},
	{
		id: "s2-01",
		season: 2,
		adv: !1,
		top: I(["tend"]),
		cond: {
			kind: "cargoCat",
			cat: "farm",
			n: 9
		},
		bottom: z("mine", "chop")
	},
	{
		id: "s2-02",
		season: 2,
		adv: !0,
		top: I(["tend", "fish"]),
		cond: {
			kind: "cargoFilled",
			n: 12
		},
		bottom: Ce(2)
	},
	{
		id: "s2-03",
		season: 2,
		adv: !1,
		top: I(["tend", "mine"]),
		cond: {
			kind: "mineLevel",
			n: 5
		},
		bottom: R("wool", "wildFruit")
	},
	{
		id: "s2-04",
		season: 2,
		adv: !0,
		top: I(["tend", "fish"]),
		cond: {
			kind: "energyBars",
			n: 2
		},
		bottom: z("mine", "chop")
	},
	{
		id: "s2-05",
		season: 2,
		adv: !1,
		top: I(["mine"]),
		cond: {
			kind: "cargoCat",
			cat: "mining",
			n: 9
		},
		bottom: we(z("tend"), L("wood"))
	},
	{
		id: "s2-06",
		season: 2,
		adv: !1,
		top: I(["fish"]),
		cond: {
			kind: "cargoCat",
			cat: "fish",
			n: 9
		},
		bottom: z("mine", "chop")
	},
	{
		id: "s2-07",
		season: 2,
		adv: !0,
		top: I([
			"tend",
			"chop",
			"fish"
		]),
		cond: {
			kind: "neighborBonus",
			n: 5
		},
		bottom: R("purpleBp", "redBp")
	},
	{
		id: "s2-08",
		season: 2,
		adv: !0,
		top: I([
			"tend",
			"mine",
			"chop"
		]),
		cond: {
			kind: "tilled",
			n: 20
		},
		bottom: L("crystal")
	},
	{
		id: "s2-09",
		season: 2,
		adv: !1,
		top: I(["tend", "chop"]),
		cond: {
			kind: "animals",
			n: 2
		},
		bottom: L("wood")
	},
	{
		id: "s2-10",
		season: 2,
		adv: !0,
		top: I(["mine", "chop"]),
		cond: {
			kind: "badgeUnlocked",
			projects: ["basicWoods", "basicMines"]
		},
		bottom: R("crystal", "wood")
	},
	{
		id: "s2-11",
		season: 2,
		adv: !0,
		top: { kind: "anyTask" },
		cond: {
			kind: "projectMedals",
			projects: ["generalist"],
			n: 1
		},
		bottom: {
			kind: "crossGood",
			projects: ["generalist"]
		}
	},
	{
		id: "s2-12",
		season: 2,
		adv: !0,
		top: I([
			"tend",
			"mine",
			"fish"
		]),
		cond: {
			kind: "cargoCols",
			n: 2
		},
		bottom: R("blobber", "ruby", "wildFruit")
	},
	{
		id: "s2-13",
		season: 2,
		adv: !1,
		top: I(["chop", "fish"]),
		cond: {
			kind: "unlock",
			what: "lake"
		},
		bottom: L("iron", "copper")
	},
	{
		id: "s2-14",
		season: 2,
		adv: !0,
		top: I([
			"mine",
			"chop",
			"fish"
		]),
		cond: {
			kind: "unlock",
			what: "lure"
		},
		bottom: L("wildFruit", "pebblepuff")
	},
	{
		id: "s2-15",
		season: 2,
		adv: !0,
		top: I(["tend", "fish"]),
		cond: {
			kind: "projectMedals",
			projects: Te,
			n: 1
		},
		bottom: {
			kind: "crossGood",
			projects: Ee
		}
	},
	{
		id: "s2-16",
		season: 2,
		adv: !0,
		top: I([
			"tend",
			"chop",
			"fish"
		]),
		cond: {
			kind: "cargoCols",
			n: 2
		},
		bottom: we(Ce(2), L("wood", "copper"))
	},
	{
		id: "s2-17",
		season: 2,
		adv: !0,
		top: I(["mine", "chop"]),
		cond: {
			kind: "projectsDone",
			n: 4
		},
		bottom: R("iron", "wood")
	},
	{
		id: "s2-18",
		season: 2,
		adv: !0,
		top: I(["mine", "chop"]),
		cond: {
			kind: "equipUpgrades",
			n: 2
		},
		bottom: B(z("tend"), L("blobber"))
	},
	{
		id: "s2-19",
		season: 2,
		adv: !1,
		top: I(["mine", "fish"]),
		cond: {
			kind: "unlock",
			what: "grotto"
		},
		bottom: L("wood", "wood")
	},
	{
		id: "s2-20",
		season: 2,
		adv: !1,
		top: I(["chop"]),
		cond: {
			kind: "chopLevel",
			n: 5
		},
		bottom: L("iron", "copper")
	},
	{
		id: "s3-01",
		season: 3,
		adv: !0,
		top: I(["chop", "fish"]),
		cond: {
			kind: "neighborBonus",
			n: 8
		},
		bottom: L("heart")
	},
	{
		id: "s3-02",
		season: 3,
		adv: !0,
		top: I(["tend", "chop"]),
		cond: {
			kind: "cargoFilled",
			n: 25
		},
		bottom: L("wood", "wood")
	},
	{
		id: "s3-03",
		season: 3,
		adv: !0,
		top: I([
			"tend",
			"mine",
			"fish"
		]),
		cond: {
			kind: "and",
			all: [{
				kind: "mineLevel",
				n: 5
			}, {
				kind: "tilled",
				n: 20
			}]
		},
		bottom: R("pebblepuff", "wool")
	},
	{
		id: "s3-04",
		season: 3,
		adv: !1,
		top: I(["tend", "mine"]),
		cond: {
			kind: "mineLevel",
			n: 8
		},
		bottom: B(z("tend"), L("blobber"))
	},
	{
		id: "s3-05",
		season: 3,
		adv: !0,
		top: I(["chop"]),
		cond: {
			kind: "energyBars",
			n: 3
		},
		bottom: R("wildFruit", "geode", "blobber")
	},
	{
		id: "s3-06",
		season: 3,
		adv: !0,
		top: I(["fish"]),
		cond: {
			kind: "and",
			all: [{
				kind: "unlock",
				what: "lake"
			}, {
				kind: "unlock",
				what: "grotto"
			}]
		},
		bottom: L("heart")
	},
	{
		id: "s3-07",
		season: 3,
		adv: !1,
		top: I(["tend"]),
		cond: {
			kind: "cargoCat",
			cat: "farm",
			n: 15
		},
		bottom: z("tend")
	},
	{
		id: "s3-08",
		season: 3,
		adv: !1,
		top: I(["mine"]),
		cond: {
			kind: "cargoCat",
			cat: "mining",
			n: 15
		},
		bottom: z("mine")
	},
	{
		id: "s3-09",
		season: 3,
		adv: !1,
		top: I(["mine", "fish"]),
		cond: {
			kind: "unlock",
			what: "grotto"
		},
		bottom: L("geode")
	},
	{
		id: "s3-10",
		season: 3,
		adv: !1,
		top: I(["fish"]),
		cond: {
			kind: "cargoCat",
			cat: "fish",
			n: 15
		},
		bottom: R("shimmerpuff", "lillybloom")
	},
	{
		id: "s3-11",
		season: 3,
		adv: !1,
		top: I(["chop", "fish"]),
		cond: {
			kind: "unlock",
			what: "lake"
		},
		bottom: L("bone")
	},
	{
		id: "s3-12",
		season: 3,
		adv: !0,
		top: I([
			"tend",
			"mine",
			"chop"
		]),
		cond: {
			kind: "cargoCols",
			n: 3
		},
		bottom: {
			kind: "crossGood",
			projects: Ee
		}
	},
	{
		id: "s3-13",
		season: 3,
		adv: !0,
		top: I(["mine", "fish"]),
		cond: {
			kind: "cargoCols",
			n: 3
		},
		bottom: B(z("tend"), z("chop"))
	},
	{
		id: "s3-14",
		season: 3,
		adv: !0,
		top: I(["tend", "fish"]),
		cond: {
			kind: "cargoRows",
			n: 1
		},
		bottom: B(z("mine"), z("chop"))
	},
	{
		id: "s3-15",
		season: 3,
		adv: !0,
		top: I(["tend", "mine"]),
		cond: {
			kind: "cargoRows",
			n: 1
		},
		bottom: B(z("chop"), L("blobber"))
	},
	{
		id: "s3-16",
		season: 3,
		adv: !0,
		top: I(["mine", "chop"]),
		cond: {
			kind: "badgeUnlocked",
			projects: ["advWoods", "advMines"]
		},
		bottom: R("pebblepuff", "berries")
	},
	{
		id: "s3-17",
		season: 3,
		adv: !1,
		top: I(["tend", "chop"]),
		cond: {
			kind: "or",
			any: [{
				kind: "tilled",
				n: 25
			}, {
				kind: "animals",
				n: 3
			}]
		},
		bottom: z("tend")
	},
	{
		id: "s3-18",
		season: 3,
		adv: !0,
		top: I(["tend", "fish"]),
		cond: {
			kind: "badgeUnlocked",
			projects: Te
		},
		bottom: {
			kind: "crossGood",
			projects: Te
		}
	},
	{
		id: "s3-19",
		season: 3,
		adv: !0,
		top: I(["mine", "chop"]),
		cond: {
			kind: "badges",
			n: 2
		},
		bottom: L("heart")
	},
	{
		id: "s3-20",
		season: 3,
		adv: !1,
		top: I(["chop"]),
		cond: {
			kind: "chopLevel",
			n: 8
		},
		bottom: B(z("tend"), z("fish"))
	}
], Oe = Object.fromEntries(De.map((e) => [e.id, e])), ke = [
	{
		id: "clearer",
		season: 1,
		score: {
			type: "perScratch",
			pts: 2
		}
	},
	{
		id: "cruncher",
		season: 1,
		score: {
			type: "perEnergyBar",
			pts: 4
		}
	},
	{
		id: "edges",
		season: 1,
		score: {
			type: "perEdgeCovered",
			pts: 2
		}
	},
	{
		id: "leftSampler",
		season: 1,
		score: {
			type: "perStallVariety",
			stall: 1,
			pts: 6
		}
	},
	{
		id: "loner",
		season: 1,
		score: {
			type: "perGoodSize",
			size: 1,
			pts: 3
		}
	},
	{
		id: "medalBonus",
		season: 1,
		score: {
			type: "perMedal",
			pts: 5
		}
	},
	{
		id: "socialite",
		season: 1,
		score: {
			type: "perGiftGiven",
			pts: 3
		}
	},
	{
		id: "spacer",
		season: 1,
		score: {
			type: "perEmptyRegion",
			size: 1,
			pts: 4
		}
	},
	{
		id: "wideSpacer",
		season: 1,
		score: {
			type: "perEmptyRegion",
			size: 2,
			pts: 5
		}
	},
	{
		id: "animalHandler",
		season: 2,
		score: {
			type: "perAnimalTypeAndSpot",
			pts: 5
		}
	},
	{
		id: "borders",
		season: 2,
		score: {
			type: "bordersFull",
			pts: 15
		}
	},
	{
		id: "centerSampler",
		season: 2,
		score: {
			type: "perStallVariety",
			stall: 2,
			pts: 3
		}
	},
	{
		id: "crossOver",
		season: 2,
		score: {
			type: "perCrossStall",
			pts: 4
		}
	},
	{
		id: "meritEarner",
		season: 2,
		score: {
			type: "perBadge",
			pts: 5
		}
	},
	{
		id: "minimalist",
		season: 2,
		score: {
			type: "perEmptyRegion",
			size: 3,
			pts: 6
		}
	},
	{
		id: "moderate",
		season: 2,
		score: {
			type: "perGoodSize",
			size: 3,
			pts: 4
		}
	},
	{
		id: "organizer",
		season: 2,
		score: {
			type: "perCargoCol",
			pts: 8
		}
	},
	{
		id: "shrimp",
		season: 2,
		score: {
			type: "perGoodSize",
			size: 2,
			pts: 4
		}
	},
	{
		id: "biggen",
		season: 3,
		score: {
			type: "perGoodSize",
			size: 4,
			pts: 4
		}
	},
	{
		id: "cargoMaster",
		season: 3,
		score: {
			type: "perCargoRow",
			pts: 8
		}
	},
	{
		id: "centrist",
		season: 3,
		score: {
			type: "stallFull",
			stall: 2,
			pts: 20
		}
	},
	{
		id: "lefty",
		season: 3,
		score: {
			type: "stallFull",
			stall: 1,
			pts: 20
		}
	},
	{
		id: "packed",
		season: 3,
		score: {
			type: "edgesFull",
			pts: 20
		}
	},
	{
		id: "righty",
		season: 3,
		score: {
			type: "stallFull",
			stall: 3,
			pts: 20
		}
	},
	{
		id: "seasonedWorker",
		season: 3,
		score: {
			type: "perTrackLevel",
			pts: 1
		}
	},
	{
		id: "trueFriend",
		season: 3,
		score: {
			type: "perFullNeighborTrack",
			pts: 10
		}
	},
	{
		id: "varietyPack",
		season: 3,
		score: {
			type: "perFullVarietyStall",
			pts: 12
		}
	}
], Ae = Object.fromEntries(ke.map((e) => [e.id, e])), V = {
	id: "tend",
	tier: "alpha",
	mechanics: ["roll-and-write", "dice-rolling"],
	interactionTags: [],
	nameKey: "games.tend.name",
	descKey: "games.tend.desc",
	rulesKey: "games.tend.rules",
	icon: "👽",
	iconImg: "games/tend.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/tend/en.pdf" },
	minPlayers: 1,
	maxPlayers: 6,
	bestPlayers: [1, 3],
	accent: "#7c3aed",
	releasedAt: "2026-09-21",
	search: {
		py: "yi xing wu yu",
		init: "yxwy"
	},
	hotseat: "cover"
}, je = t.enum([
	"tend",
	"fish",
	"chop",
	"mine"
]), Me = t.enum(["left", "right"]), Ne = t.enum([
	"pond",
	"river",
	"lake",
	"grotto"
]), Pe = t.enum([
	"pineapple",
	"berries",
	"wildFruit",
	"pumpkin"
]), Fe = t.enum([
	"chicken",
	"sheep",
	"cow"
]), Ie = t.enum([
	"trellis",
	"bridge",
	"rod1",
	"rod2",
	"lureGreen",
	"lureRed",
	"equipTools",
	"equipHatchet",
	"equipPickaxe",
	"energy",
	"animal",
	"badge",
	"purchase",
	"explorer",
	"intern"
]), Le = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pickNeighborCards"),
		left: t.number().int().min(0).max(3),
		right: t.number().int().min(0).max(3)
	}),
	t.object({
		type: t.literal("resolveGift"),
		idx: t.number().int().min(0),
		use: t.boolean(),
		good: t.string().optional()
	}),
	t.object({
		type: t.literal("redrawNeighbor"),
		side: Me,
		keep: t.union([t.literal(0), t.literal(1)])
	}),
	t.object({
		type: t.literal("cycleNeighbor"),
		side: Me
	}),
	t.object({ type: t.literal("neighborDone") }),
	t.object({
		type: t.literal("pickTasks"),
		cards: t.tuple([t.number().int().min(0).max(4), t.number().int().min(0).max(4)])
	}),
	t.object({
		type: t.literal("chooseTask"),
		task: je
	}),
	t.object({ type: t.literal("useEnergy") }),
	t.object({
		type: t.literal("tendPlant"),
		crop: Pe,
		anchor: t.number().int().min(0).max(131)
	}),
	t.object({
		type: t.literal("tendWater"),
		idx: t.number().int().min(0)
	}),
	t.object({
		type: t.literal("tendTill"),
		cells: t.array(t.number().int().min(0).max(131)).length(6)
	}),
	t.object({
		type: t.literal("scratch"),
		card: t.enum(["woods", "mines"]),
		cell: t.number().int().min(0).max(55)
	}),
	t.object({
		type: t.literal("fishSpot"),
		spot: Ne
	}),
	t.object({
		type: t.literal("fishPick"),
		cell: t.number().int().min(-1).max(24)
	}),
	t.object({
		type: t.literal("fishLure"),
		use: t.boolean()
	}),
	t.object({
		type: t.literal("geodePick"),
		cell: t.number().int().min(0).max(24)
	}),
	t.object({ type: t.literal("disposeSell") }),
	t.object({
		type: t.literal("disposeCargo"),
		anchor: t.number().int().min(0).max(95),
		rot: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		type: t.literal("disposeCost"),
		area: Ie,
		row: t.number().int().min(0),
		slot: t.number().int().min(0),
		id: t.string().optional()
	}),
	t.object({
		type: t.literal("disposeGift"),
		side: Me
	}),
	t.object({
		type: t.literal("disposeGrounds"),
		till: t.array(t.number().int().min(0).max(131)).optional(),
		fences: t.array(t.string()).optional()
	}),
	t.object({
		type: t.literal("groundsCoin"),
		till: t.array(t.number().int().min(0).max(131)).optional(),
		fences: t.array(t.string()).optional()
	}),
	t.object({
		type: t.literal("pay"),
		area: Ie,
		row: t.number().int().min(0).optional(),
		slot: t.number().int().min(0).optional(),
		id: t.string().optional()
	}),
	t.object({
		type: t.literal("placeAnimal"),
		animal: Fe,
		anchor: t.number().int().min(0).max(131)
	}),
	t.object({
		type: t.literal("placeTrellis"),
		anchor: t.number().int().min(0).max(131)
	}),
	t.object({
		type: t.literal("useExplorer"),
		badge: t.string()
	}),
	t.object({
		type: t.literal("useBuyback"),
		badge: t.string(),
		row: t.number().int().min(0).max(2),
		slot: t.number().int().min(0).max(2)
	}),
	t.object({
		type: t.literal("pickReward"),
		idx: t.number().int().min(0)
	}),
	t.object({
		type: t.literal("crossGood"),
		badge: t.string(),
		row: t.number().int().min(0).max(2),
		slot: t.number().int().min(0).max(2)
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("finishActions") }),
	t.object({ type: t.literal("taskDone") })
]), Re = t.record(t.string(), t.unknown()), ze = t.record(t.string(), t.unknown()), Be = t.object({ noAdv: t.boolean().default(!1) }).default({ noAdv: !1 }), Ve = {
	action: Le,
	publicView: Re,
	privateView: ze,
	config: Be
}, He = (e, t) => e * 11 + t, H = (e) => Math.floor(e / 11), U = (e) => e % 11;
function W(e, t) {
	if (e < 0 || e >= pe.length) return !1;
	let [n, r] = pe[e];
	return t >= n && t <= r;
}
function G(e, t) {
	let n = H(e), r = U(e), i = [];
	for (let e = 0; e < t; e++) for (let a = 0; a < t; a++) {
		if (!W(n + e, r + a)) return null;
		i.push(He(n + e, r + a));
	}
	return i;
}
function Ue(e, t) {
	let n = H(e), r = U(e);
	return t === "up" ? `h:${n}:${r}` : t === "down" ? `h:${n + 1}:${r}` : t === "left" ? `v:${n}:${r}` : `v:${n}:${r + 1}`;
}
function We(e, t) {
	let n = new Set(t), r = new Set(e), i = [...e];
	for (; i.length;) {
		let e = i.pop(), t = H(e), a = U(e), o = [
			[
				t - 1,
				a,
				"up"
			],
			[
				t + 1,
				a,
				"down"
			],
			[
				t,
				a - 1,
				"left"
			],
			[
				t,
				a + 1,
				"right"
			]
		];
		for (let [t, a, s] of o) {
			if (n.has(Ue(e, s))) continue;
			if (!W(t, a)) return !1;
			let o = He(t, a);
			r.has(o) || (r.add(o), i.push(o));
		}
	}
	return !0;
}
function Ge(e, t) {
	let n = new Set(t);
	for (let t of e) {
		let e = H(t), r = U(t);
		for (let [t, i] of [
			[e - 1, r],
			[e + 1, r],
			[e, r - 1],
			[e, r + 1]
		]) if (n.has(He(t, i))) return !0;
	}
	return !1;
}
function Ke(e, t) {
	let n = t + 1, r = e[n];
	return r === void 0 ? {
		face: t,
		harvest: !1,
		out: !1
	} : r === "wx" ? {
		face: n,
		harvest: !0,
		out: !0
	} : r === "wr" ? {
		face: 0,
		harvest: !0,
		out: !1
	} : r === "w2" ? {
		face: n,
		harvest: !0,
		out: !1
	} : {
		face: n,
		harvest: !1,
		out: !1
	};
}
function qe(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; t--) {
		let a = e(n, r.cursor, t + 1);
		r.cursor += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return i;
}
function Je() {
	return {
		coins: 0,
		tilled: me.map(([e, t]) => He(e, t)),
		fences: [...he],
		crops: [],
		animals: [],
		animalPaid: {
			chicken: 0,
			sheep: 0,
			cow: 0
		},
		animalUnlocked: {
			chicken: 0,
			sheep: 0,
			cow: 0
		},
		trellis: Array.from({ length: 4 }, () => ae.map(() => !1)),
		trellises: [],
		equip: {
			tools: k.map((e) => e.map(() => !1)),
			hatchet: k.map((e) => e.map(() => !1)),
			pickaxe: k.map((e) => e.map(() => !1))
		},
		bridge: A.map((e) => e.map(() => !1)),
		rod1: j.map((e) => e.map(() => !1)),
		rod2: M.map((e) => e.map(() => !1)),
		lures: oe.map((e) => e.map(() => !1)),
		lureChoice: null,
		explorerPaid: [
			!1,
			!1,
			!1,
			!1
		],
		energyPaid: Array.from({ length: 3 }, () => 0),
		energyCharges: Array.from({ length: 3 }, () => 0),
		chopLv: 0,
		mineLv: 0,
		cargo: Array.from({ length: 96 }, () => null),
		cargoPieces: [],
		cargoRowsDone: Array.from({ length: 8 }, () => !1),
		cargoColsDone: Array.from({ length: 12 }, () => !1),
		badges: Object.fromEntries(N.map((e) => [e.id, e.rows.map((e) => e.cost.map(() => !1))])),
		badgeDoubled: null,
		internUsed: !1,
		explorerUsed: !1,
		buybackUsed: !1,
		purchaseUsed: ue.map(() => !1),
		nbHand: {
			left: null,
			right: null
		},
		nbTrack: {
			left: 0,
			right: 0
		},
		nbIncoming: [],
		nbIncomingDir: [],
		nbIncomingNext: [],
		nbIncomingDirNext: [],
		nbGifted: 0,
		nbDraws: {},
		nbCycled: {
			left: !1,
			right: !1
		},
		disposeQueue: [],
		rewardPick: null,
		fish: null,
		geode: null,
		execStack: [],
		picked: [],
		phaseDone: !1
	};
}
function Ye(e, t, n) {
	let r = { cursor: 0 }, i = (e, t) => e.splice(0, t), a = (t) => qe(De.filter((n) => n.season === t && (!e.noAdv || !n.adv)).map((e) => e.id), n, r), o = (() => {
		let e = a(1), t = a(2), n = a(3), r = () => [
			...i(n, 3),
			...i(t, 4),
			...i(e, 4)
		];
		return [r(), r()];
	})(), s = qe(fe.map((e, t) => `st:${e}:${t}`), n, r), c = s.splice(s.length - 5), l = [
		1,
		2,
		3
	].map((e) => qe(ke.filter((t) => t.season === e).map((e) => e.id), n, r)[0]), u = qe(F.map((e, t) => t), n, r), d = {};
	return t.forEach((e) => {
		let t = Je(), i = Se("woods", n, r.cursor);
		r.cursor = i.nextCursor;
		let a = Se("mines", n, r.cursor);
		r.cursor = a.nextCursor, d[e] = {
			...t,
			woods: {
				cells: i.cells,
				scratched: i.cells.map(() => !1)
			},
			mines: {
				cells: a.cells,
				scratched: a.cells.map(() => !1)
			},
			setupHand: u.splice(0, 4)
		};
	}), { state: {
		seed: n,
		cursor: r.cursor,
		players: t,
		ps: d,
		phase: "setupCards",
		round: 1,
		seasonDecks: o,
		taskDeck: s,
		taskDiscard: [],
		taskRow: c,
		objectives: l,
		seasonScores: [
			null,
			null,
			null
		],
		nbDeck: u,
		nbDiscard: [],
		finalScores: null
	} };
}
//#endregion
//#region src/games/tend/rules.ts
var K = {
	phase: "games.tend.err.phase",
	pending: "games.tend.err.pending",
	queue: "games.tend.err.queue",
	coins: "games.tend.err.coins",
	cost: "games.tend.err.cost",
	occupied: "games.tend.err.occupied",
	fence: "games.tend.err.fence",
	scratch: "games.tend.err.scratch",
	fish: "games.tend.err.fish",
	cargo: "games.tend.err.cargo",
	card: "games.tend.err.card"
}, q = (e) => ({ code: e }), Xe = (e) => structuredClone(e), Ze = (e) => ({ state: e });
function Qe(t) {
	for (let n of t.players) {
		let r = t.ps[n];
		for (r.disposeQueue[0] === "geode" && !r.geode && (r.geode = [e(t.seed, t.cursor++, 6) + 1, e(t.seed, t.cursor++, 6) + 1]); ht(r)?.options === null;) mt(r);
	}
}
function $e(e) {
	return e !== "geode" && e !== "wood" && e !== "exoWood";
}
function et(e) {
	return e.disposeQueue[0] ?? null;
}
var tt = (e) => e.bridge.every((e) => e.every(Boolean)), nt = (e) => e.rod2.every((e) => e.every(Boolean)) ? 2 : +!!e.rod1.every((e) => e.every(Boolean)), rt = (e) => e.lureChoice !== null && e.lures[e.lureChoice].every(Boolean), it = (e, t) => e.equip[t].every((e) => e.every(Boolean)), at = (e) => e.woods.scratched.some((e, t) => e && t >= 49), ot = (e) => e.mines.scratched.some((e, t) => e && t >= 49);
function st(e, t) {
	return t === "pond" ? !0 : t === "river" ? tt(e) : t === "lake" ? at(e) : ot(e);
}
function ct(e, t) {
	return e.badges[t].filter((e) => e.every(Boolean)).length;
}
function lt(e, t) {
	return ct(e, t) >= 2;
}
function ut(e) {
	return N.filter((t) => lt(e, t.id)).length;
}
function dt(e, t) {
	return N.filter((e) => !t || t.includes(e.id)).reduce((t, n) => t + ct(e, n.id), 0);
}
function ft(e, t) {
	switch (e.kind) {
		case "mineLevel": return t.mineLv >= e.n;
		case "chopLevel": return t.chopLv >= e.n;
		case "energyBars": return t.energyPaid.filter((e) => e >= 3).length >= e.n;
		case "animals": return Object.values(t.animalUnlocked).reduce((e, t) => e + t, 0) >= e.n;
		case "trellis": return t.trellis.filter((e) => e.every(Boolean)).length >= e.n;
		case "tilled": return t.tilled.length >= e.n;
		case "cargoFilled": return t.cargo.filter(Boolean).length >= e.n;
		case "cargoCols": return t.cargoColsDone.filter(Boolean).length >= e.n;
		case "cargoRows": return t.cargoRowsDone.filter(Boolean).length >= e.n;
		case "neighborBonus": return t.nbGifted >= e.n;
		case "projectsDone": return ut(t) >= e.n;
		case "badges": return ut(t) >= e.n;
		case "equipUpgrades": return [
			"tools",
			"hatchet",
			"pickaxe"
		].filter((e) => it(t, e)).length >= e.n;
		case "cargoCat": return t.cargo.filter((t) => t && S[t].cat === e.cat).length >= e.n;
		case "unlock": return e.what === "river" ? tt(t) : e.what === "lake" ? at(t) : e.what === "grotto" ? ot(t) : e.what === "rod" ? nt(t) > 0 : rt(t);
		case "badgeUnlocked": return e.projects.some((e) => lt(t, e));
		case "projectMedals": return dt(t, e.projects) >= e.n;
		case "and": return e.all.every((e) => ft(e, t));
		case "or": return e.any.some((e) => ft(e, t));
	}
}
function pt(e, t) {
	switch (t.kind) {
		case "goods":
			e.disposeQueue.push(...t.goods);
			break;
		case "pick":
			e.rewardPick = {
				kind: "pick",
				options: [...t.options]
			};
			break;
		case "coins":
			e.coins += t.n;
			break;
		case "freeTask":
			e.execStack.push({
				source: "free",
				options: [...t.tasks],
				task: null,
				actions: 0,
				energyUsed: !1,
				cond: null,
				reward: null
			});
			break;
		case "anyTask":
			e.execStack.push({
				source: "any",
				options: [],
				task: null,
				actions: 0,
				energyUsed: !1,
				cond: null,
				reward: null
			});
			break;
		case "crossGood":
			e.rewardPick = {
				kind: "crossGood",
				projects: [...t.projects]
			};
			break;
		case "bundle":
			t.parts.forEach((t) => pt(e, t));
			break;
		case "choice": e.rewardPick = {
			kind: "choice",
			options: [...t.options]
		};
	}
}
function mt(e) {
	let t = e.execStack.pop();
	t && t.reward && (!t.cond || ft(t.cond, e)) && pt(e, t.reward);
}
var ht = (e) => e.execStack[e.execStack.length - 1] ?? null, gt = (e) => Math.floor(e / 4);
function _t(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.cargo.length; r++) {
		if (e.cargo[r] || t.has(r)) continue;
		let i = 0, a = [r];
		for (t.add(r); a.length;) {
			let n = a.pop();
			i++;
			let r = Math.floor(n / 12), o = n % 12;
			for (let [n, i] of [
				[r - 1, o],
				[r + 1, o],
				[r, o - 1],
				[r, o + 1]
			]) {
				if (n < 0 || n >= 8 || i < 0 || i >= 12) continue;
				let r = n * 12 + i;
				!e.cargo[r] && !t.has(r) && (t.add(r), a.push(r));
			}
		}
		n.push(i);
	}
	return n;
}
function vt(e, t) {
	let n = Ae[t];
	if (!n) return 0;
	let r = n.score, i = (t) => e.cargo.filter((e, n) => e && gt(n % 12) === t - 1);
	switch (r.type) {
		case "perScratch": return r.pts * (e.woods.scratched.filter(Boolean).length + e.mines.scratched.filter(Boolean).length);
		case "perEnergyBar": return r.pts * e.energyPaid.filter((e) => e >= 3).length;
		case "perEdgeCovered": return r.pts * e.cargo.filter((e, t) => {
			if (!e) return !1;
			let n = Math.floor(t / 12), r = t % 12;
			return n === 0 || n === 7 || r === 0 || r === 11;
		}).length;
		case "perStallVariety": return r.pts * new Set(i(r.stall)).size;
		case "perGoodSize": return r.pts * e.cargoPieces.filter((e) => r.size >= 4 ? e.cells.length >= 4 : e.cells.length === r.size).length;
		case "perMedal": return r.pts * dt(e);
		case "perGiftGiven": return r.pts * e.nbGifted;
		case "perEmptyRegion": return r.pts * _t(e).filter((e) => e === r.size).length;
		case "perAnimalTypeAndSpot": {
			let t = Object.keys(e.animalUnlocked).filter((t) => e.animalUnlocked[t] > 0).length, n = 1 + [
				"river",
				"lake",
				"grotto"
			].filter((t) => st(e, t)).length;
			return r.pts * (t + n);
		}
		case "bordersFull": {
			let t = (t) => Array.from({ length: 8 }, (n, r) => e.cargo[r * 12 + t]).every(Boolean);
			return t(0) && t(11) ? r.pts : 0;
		}
		case "perCrossStall": return r.pts * e.cargoPieces.filter((e) => new Set(e.cells.map((e) => gt(e % 12))).size >= 2).length;
		case "perBadge": return r.pts * ut(e);
		case "perCargoCol": return r.pts * e.cargoColsDone.filter(Boolean).length;
		case "perCargoRow": return r.pts * e.cargoRowsDone.filter(Boolean).length;
		case "stallFull": return Array.from({ length: 8 }, (t, n) => Array.from({ length: 4 }, (t, i) => e.cargo[n * 12 + (r.stall - 1) * 4 + i])).flat().every(Boolean) ? r.pts : 0;
		case "edgesFull": return e.cargo.every((e, t) => {
			let n = Math.floor(t / 12), r = t % 12;
			return n !== 0 && n !== 7 && r !== 0 && r !== 11 || e !== null;
		}) ? r.pts : 0;
		case "perTrackLevel": return r.pts * (e.chopLv + e.mineLv);
		case "perFullNeighborTrack": return r.pts * +(e.nbTrack.left >= 8) + r.pts * +(e.nbTrack.right >= 8);
		case "perFullVarietyStall": {
			let e = [
				"farm",
				"fish",
				"mining",
				"social",
				"badge"
			];
			return r.pts * [
				1,
				2,
				3
			].filter((t) => e.every((e) => i(t).some((t) => t && S[t].cat === e))).length;
		}
	}
}
function yt(e) {
	let t = 0;
	return e.cargo.forEach((e, n) => {
		if (!e) return;
		let r = ne[gt(n % 12)];
		t += S[e].cat === r.cat ? r.pts : 1;
	}), t;
}
function bt(e, t) {
	let n = e.ps[t], r = yt(n);
	r += e.seasonScores.reduce((e, n) => e + (n?.[t] ?? 0), 0);
	for (let e of N) lt(n, e.id) && (r += e.vp * (n.badgeDoubled === e.id ? 2 : 1));
	let i = e.players.indexOf(t), a = e.players.length;
	if (a === 1) r += 3 * (n.nbTrack.left + n.nbTrack.right);
	else {
		let t = e.ps[e.players[(i - 1 + a) % a]], o = e.ps[e.players[(i + 1) % a]];
		r += 3 * Math.max(0, n.nbTrack.left - t.nbTrack.right), r += 3 * Math.max(0, n.nbTrack.right - o.nbTrack.left);
	}
	return r;
}
function xt(e, t, n) {
	switch (t) {
		case "trellis": return {
			rows: Array.from({ length: e.trellis.length }, () => ae),
			paid: e.trellis
		};
		case "bridge": return {
			rows: A,
			paid: e.bridge
		};
		case "rod1": return {
			rows: j,
			paid: e.rod1
		};
		case "rod2": return {
			rows: M,
			paid: e.rod2
		};
		case "lureGreen": return {
			rows: [oe[0]],
			paid: [e.lures[0]]
		};
		case "lureRed": return {
			rows: [oe[1]],
			paid: [e.lures[1]]
		};
		case "equipTools": return {
			rows: k,
			paid: e.equip.tools
		};
		case "equipHatchet": return {
			rows: k,
			paid: e.equip.hatchet
		};
		case "equipPickaxe": return {
			rows: k,
			paid: e.equip.pickaxe
		};
		case "explorer": return {
			rows: [le],
			paid: [e.explorerPaid]
		};
		case "badge": {
			let t = N.find((e) => e.id === n);
			return t && e.badges[t.id] ? {
				rows: t.rows.map((e) => e.cost),
				paid: e.badges[t.id]
			} : null;
		}
		default: return null;
	}
}
function St(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.crops) G(n.anchor, D[n.crop].size)?.forEach((e) => t.add(e));
	for (let n of e.animals) G(n.anchor, O[n.animal].size)?.forEach((e) => t.add(e));
	for (let n of e.trellises) G(n, 2)?.forEach((e) => t.add(e));
	return t;
}
function Ct(e) {
	let t = [];
	for (let n of e.crops) {
		let r = Ke(D[n.crop].faces, n.face);
		n.face = r.face, r.harvest && e.disposeQueue.push(D[n.crop].good), r.out || t.push(n);
	}
	e.crops = t;
	for (let t of e.animals) {
		let n = Ke(O[t.animal].faces, t.face);
		t.face = n.face, n.harvest && e.disposeQueue.push(O[t.animal].good);
	}
}
function wt(e, t) {
	let n = [];
	for (; n.length < t;) {
		if (e.taskDeck.length === 0) {
			if (e.taskDiscard.length === 0) break;
			e.taskDeck = e.taskDiscard, e.taskDiscard = [];
		}
		n.push(e.taskDeck.pop());
	}
	return n;
}
function Tt(e, t) {
	let n = () => (e.nbDeck.length === 0 && (e.nbDeck = e.nbDiscard, e.nbDiscard = []), e.nbDeck.pop());
	t.nbDraws = {}, t.nbHand.left === null && e.players.length > 1 && (t.nbDraws.left = [n(), n()]), t.nbHand.right === null && e.players.length > 1 && (t.nbDraws.right = [n(), n()]);
}
function Et(e) {
	if (e.players.every((t) => e.ps[t].phaseDone)) {
		if (e.phase === "setupCards") {
			e.phase = "task", e.players.forEach((t) => {
				e.ps[t].phaseDone = !1;
			});
			return;
		}
		if (e.phase === "task") {
			if (e.round >= 12) {
				e.phase = "finalGifts", e.players.forEach((t) => {
					let n = e.ps[t];
					n.phaseDone = !1, n.nbIncoming = n.nbIncomingNext, n.nbIncomingNext = [];
				});
				return;
			}
			e.round += 1, e.phase = "neighbor", e.players.forEach((t) => {
				let n = e.ps[t];
				n.phaseDone = !1, n.nbIncoming = n.nbIncomingNext, n.nbIncomingNext = [], n.nbCycled = {
					left: !1,
					right: !1
				}, Tt(e, n);
			});
			return;
		}
		if (e.phase === "neighbor") {
			let t = ge.indexOf(e.round);
			if (t >= 0) {
				let n = {};
				e.players.forEach((r) => {
					n[r] = vt(e.ps[r], e.objectives[t]);
				}), e.seasonScores[t] = n;
			}
			e.taskDiscard.push(...e.taskRow);
			let n = [e.seasonDecks[0].pop(), e.seasonDecks[1].pop()].filter((e) => !!e);
			e.taskRow = [...wt(e, 5 - n.length), ...n], e.players.forEach((t) => {
				let n = e.ps[t];
				Ct(n), n.phaseDone = !1, n.picked = [], n.execStack = [];
			}), e.phase = "task";
			return;
		}
		e.phase === "finalGifts" && (e.finalScores = {}, e.players.forEach((t) => {
			e.finalScores[t] = bt(e, t);
		}), e.phase = "done");
	}
}
function Dt(t, n, r) {
	let i = Xe(t), a = r.by, o = i.ps[a];
	if (!o) return q(K.phase);
	let s = () => (Qe(i), Et(i), Ze(i)), c = () => o.geode !== null || o.fish !== null || o.rewardPick !== null;
	switch (n.type) {
		case "pickNeighborCards": {
			if (i.phase !== "setupCards" || !o.setupHand) return q(K.phase);
			if (n.left === n.right) return q(K.card);
			let e = o.setupHand;
			return o.nbHand.left = e[n.left], o.nbHand.right = e[n.right], e.forEach((e, t) => {
				t !== n.left && t !== n.right && i.nbDiscard.push(e);
			}), o.setupHand = null, o.phaseDone = !0, s();
		}
		case "resolveGift": {
			if (i.phase !== "neighbor" && i.phase !== "finalGifts") return q(K.phase);
			let e = o.nbIncoming[n.idx];
			if (e === void 0) return q(K.card);
			let t = F[e];
			if (n.use) {
				let r = n.good ?? (t.goods.length === 1 ? t.goods[0] : void 0);
				if (!r || !t.goods.includes(r)) return q(K.card);
				o.disposeQueue.push(r), i.nbDiscard.push(e);
			} else {
				if (i.players.length === 1) return q(K.card);
				let t = i.players.indexOf(a), r = o.nbIncomingDir[n.idx], s = r === "left" ? i.players[(t + 1) % i.players.length] : i.players[(t - 1 + i.players.length) % i.players.length];
				i.ps[s].nbIncomingNext.push(e), i.ps[s].nbIncomingDirNext.push(r === "left" ? "left" : "right");
			}
			return o.nbIncoming.splice(n.idx, 1), o.nbIncomingDir.splice(n.idx, 1), s();
		}
		case "redrawNeighbor": {
			if (i.phase !== "neighbor") return q(K.phase);
			let e = o.nbDraws[n.side];
			return e ? (o.nbHand[n.side] = e[n.keep], i.nbDiscard.push(e[1 - n.keep]), delete o.nbDraws[n.side], s()) : q(K.card);
		}
		case "cycleNeighbor": {
			if (i.phase !== "neighbor") return q(K.phase);
			let e = o.nbHand[n.side];
			return e === null || o.nbCycled[n.side] ? q(K.card) : (i.nbDiscard.push(e), i.nbDeck.length === 0 && (i.nbDeck = i.nbDiscard.filter((t) => t !== e), i.nbDiscard = [e]), o.nbHand[n.side] = i.nbDeck.pop(), o.nbCycled[n.side] = !0, s());
		}
		case "neighborDone": return i.phase !== "neighbor" && i.phase !== "finalGifts" ? q(K.phase) : o.nbIncoming.length > 0 || i.phase === "neighbor" && (o.nbDraws.left || o.nbDraws.right) || o.disposeQueue.length > 0 || c() ? q(K.pending) : (o.phaseDone = !0, s());
		case "pickTasks": {
			if (i.phase !== "task" || o.phaseDone) return q(K.phase);
			if (o.picked.length > 0) return q(K.pending);
			let e = (e) => {
				if (e.startsWith("st:")) {
					let t = e.split(":")[1];
					return t === "zenithOrders" ? (o.coins += 2, null) : {
						source: e,
						options: [t],
						task: null,
						actions: 0,
						energyUsed: !1,
						cond: null,
						reward: null
					};
				}
				let t = Oe[e];
				return t ? t.top.kind === "coins" ? (o.coins += t.top.n, {
					source: e,
					options: null,
					task: null,
					actions: 0,
					energyUsed: !1,
					cond: t.cond,
					reward: t.bottom
				}) : {
					source: e,
					options: t.top.kind === "anyTask" ? [] : [...t.top.tasks],
					task: null,
					actions: 0,
					energyUsed: !1,
					cond: t.cond,
					reward: t.bottom
				} : null;
			}, t = e(i.taskRow[n.cards[1]]), r = e(i.taskRow[n.cards[0]]);
			for (t && o.execStack.push(t), r && o.execStack.push(r), o.picked = [...n.cards]; ht(o)?.options === null;) mt(o);
			return s();
		}
		case "chooseTask": {
			let e = ht(o);
			if (!e || e.options === null || e.task !== null || c()) return q(K.pending);
			if (e.options.length > 0 && !e.options.includes(n.task)) return q(K.card);
			e.task = n.task, e.actions = 1;
			let t = {
				tend: "tools",
				chop: "hatchet",
				mine: "pickaxe",
				fish: null
			}[n.task];
			return t && it(o, t) && (e.actions += 1), s();
		}
		case "useEnergy": {
			let e = ht(o);
			if (!e || !e.task || e.energyUsed || c()) return q(K.pending);
			let t = o.energyCharges.findIndex((e) => e > 0);
			return t < 0 ? q(K.coins) : (--o.energyCharges[t], e.energyUsed = !0, e.task !== "fish" && (e.actions += 1), s());
		}
		case "finishActions": return !ht(o) || c() || o.disposeQueue.length > 0 ? q(K.pending) : (mt(o), s());
		case "tendPlant":
		case "tendWater":
		case "tendTill": {
			let e = ht(o);
			if (!e || e.task !== "tend" || e.actions < 1 || c()) return q(K.pending);
			if (n.type === "tendPlant") {
				let e = D[n.crop], t = G(n.anchor, e.size);
				if (!t) return q(K.occupied);
				let r = St(o);
				if (t.some((e) => r.has(e) || !o.tilled.includes(e)) || e.trellis && !o.trellises.includes(n.anchor)) return q(K.occupied);
				o.crops.push({
					crop: n.crop,
					anchor: n.anchor,
					face: 0
				});
			} else if (n.type === "tendWater") {
				let e = o.crops[n.idx];
				if (!e) return q(K.card);
				let t = G(e.anchor, D[e.crop].size), r = o.crops.filter((n) => n === e || Ge(t, G(n.anchor, D[n.crop].size))), i = [];
				for (let e of o.crops) {
					if (!r.includes(e)) {
						i.push(e);
						continue;
					}
					let t = Ke(D[e.crop].faces, e.face);
					e.face = t.face, t.harvest && o.disposeQueue.push(D[e.crop].good), t.out || i.push(e);
				}
				o.crops = i;
			} else {
				let e = St(o), t = n.cells;
				if (new Set(t).size !== 6 || t.some((t) => !W(H(t), U(t)) || o.tilled.includes(t) || e.has(t))) return q(K.occupied);
				o.tilled.push(...t);
			}
			return --e.actions, s();
		}
		case "scratch": {
			let e = ht(o), t = n.card === "woods" ? o.woods : o.mines, r = n.card === "woods" ? "chop" : "mine";
			if (!e || e.task !== r || c()) return q(K.pending);
			let i = Math.floor(n.cell / 7), a = n.cell % 7, l = i < 4 ? 1 : 2;
			if (e.actions < l || t.scratched[n.cell]) return q(K.scratch);
			let u = t.scratched.some(Boolean), d = [
				[-1, 0],
				[1, 0],
				[0, -1],
				[0, 1]
			].some(([e, n]) => {
				let r = i + e, o = a + n;
				return r >= 0 && r < 8 && o >= 0 && o < 7 && t.scratched[r * 7 + o];
			});
			if (u && !d && i !== 0 || !u && i !== 0) return q(K.scratch);
			e.actions -= l, t.scratched[n.cell] = !0;
			let f = t.cells[n.cell], p = f.content;
			if (p === "chop" || p === "mine" ? e.actions += 1 : p === "chopGold" || p === "mineGold" ? (e.actions += 1, o.coins += 1) : p === "chopUpgraded" || p === "mineUpgraded" ? e.actions += 2 : o.disposeQueue.push(p), f.upgrade) {
				if (n.card === "woods" && o.chopLv < 10) {
					o.chopLv += 1;
					let e = w[o.chopLv - 1];
					e === "coin" ? o.coins += 1 : o.disposeQueue.push(e);
				} else if (n.card === "mines" && o.mineLv < 10) {
					o.mineLv += 1;
					let e = ie[o.mineLv - 1];
					e === "coin" ? o.coins += 1 : o.disposeQueue.push(e);
				}
			}
			return s();
		}
		case "fishSpot": {
			let t = ht(o);
			if (!t || t.task !== "fish" || t.actions < 1 || c()) return q(K.pending);
			if (!st(o, n.spot)) return q(K.fish);
			--t.actions;
			let r = [e(i.seed, i.cursor++, 6) + 1, e(i.seed, i.cursor++, 6) + 1], a = 1 + +!!rt(o) + +!!t.energyUsed;
			return o.fish = {
				spot: n.spot,
				dice: r,
				maxPicks: a,
				picks: []
			}, s();
		}
		case "fishPick": {
			let e = o.fish;
			if (!e) return q(K.fish);
			let t = P[e.spot];
			if (n.cell >= 0) {
				let r = nt(o);
				if (!Array.from({ length: 25 }, (e, t) => t).some((t) => {
					let i = Math.floor(t / 5), a = t % 5;
					if (e.dice[0] !== 1 && i !== e.dice[0] - 1 || e.dice[1] !== 1 && a !== e.dice[1] - 1) return !1;
					let o = Math.floor(n.cell / 5), s = n.cell % 5;
					return r === 2 ? Math.abs(o - i) <= 1 && Math.abs(s - a) <= 1 : r === 1 ? Math.abs(o - i) + Math.abs(s - a) <= 1 : o === i && s === a;
				}) || e.picks.includes(n.cell)) return q(K.fish);
				e.picks.push(n.cell);
				let i = t[n.cell];
				i && o.disposeQueue.push(i);
			} else e.picks.push(-1);
			return e.picks.length >= e.maxPicks && (o.fish = null, mt(o)), s();
		}
		case "fishLure": return o.fish ? (n.use || (o.fish = null, mt(o)), s()) : q(K.fish);
		case "geodePick": {
			if (!o.geode || o.disposeQueue[0] !== "geode") return q(K.pending);
			let [e, t] = o.geode, r = Math.floor(n.cell / 5), i = n.cell % 5;
			if (e !== 1 && r !== e - 1 || t !== 1 && i !== t - 1) return q(K.fish);
			let a = P.geode[n.cell];
			return o.geode = null, o.disposeQueue[0] = a ?? "stone", s();
		}
		case "disposeSell": {
			let e = et(o);
			if (!e || e === "geode" || o.fish || o.rewardPick) return q(K.queue);
			let t = $e(e) ? S[e].sell : C[e];
			return t <= 0 ? q(K.queue) : (o.coins += t, o.disposeQueue.shift(), s());
		}
		case "disposeCargo": {
			let e = et(o);
			if (!e || e === "geode" || !$e(e) || o.fish || o.rewardPick) return q(K.queue);
			let t = x[S[e].shape].map(([e, t]) => [e, t]);
			for (let e = 0; e < n.rot; e++) t = t.map(([e, t]) => [t, -e]);
			let r = Math.min(...t.map(([e]) => e)), i = Math.min(...t.map(([, e]) => e));
			t = t.map(([e, t]) => [e - r, t - i]);
			let a = Math.floor(n.anchor / 12), c = n.anchor % 12, l = t.map(([e, t]) => (a + e) * 12 + (c + t));
			if (l.some((e) => {
				let t = Math.floor(e / 12), n = e % 12;
				return t >= 8 || n >= 12 || n < c || o.cargo[e] !== null;
			})) return q(K.cargo);
			let u = S[e].cat, d = new Set(l);
			for (let e of l) {
				let t = Math.floor(e / 12), n = e % 12;
				for (let [e, r] of [
					[t - 1, n],
					[t + 1, n],
					[t, n - 1],
					[t, n + 1]
				]) {
					if (e < 0 || e >= 8 || r < 0 || r >= 12) continue;
					let t = e * 12 + r;
					if (d.has(t)) continue;
					let n = o.cargo[t];
					if (n && S[n].cat === u) return q(K.cargo);
				}
			}
			l.forEach((t) => {
				o.cargo[t] = e;
			}), o.cargoPieces.push({
				good: e,
				cells: l
			}), o.disposeQueue.shift();
			for (let e = 0; e < 8; e++) !o.cargoRowsDone[e] && Array.from({ length: 12 }, (t, n) => o.cargo[e * 12 + n]).every(Boolean) && (o.cargoRowsDone[e] = !0, o.execStack.push({
				source: `cargoRow:${e}`,
				options: [re[e]],
				task: null,
				actions: 0,
				energyUsed: !1,
				cond: null,
				reward: null
			}));
			for (let e = 0; e < 12; e++) !o.cargoColsDone[e] && Array.from({ length: 8 }, (t, n) => o.cargo[n * 12 + e]).every(Boolean) && (o.cargoColsDone[e] = !0);
			return s();
		}
		case "disposeCost": {
			let e = et(o);
			if (!e || e === "geode" || o.fish || o.rewardPick) return q(K.queue);
			if (n.area === "lureGreen" && o.lureChoice === 1 || n.area === "lureRed" && o.lureChoice === 0) return q(K.cost);
			let t = xt(o, n.area, n.id);
			if (!t) return q(K.cost);
			let r = t.rows[n.row], i = t.paid[n.row];
			if (!r || !i || r[n.slot] !== e || i[n.slot]) return q(K.cost);
			if (n.area === "lureGreen" && (o.lureChoice = 0), n.area === "lureRed" && (o.lureChoice = 1), i[n.slot] = !0, o.disposeQueue.shift(), n.area === "badge" && i.every(Boolean)) {
				let e = N.find((e) => e.id === n.id);
				o.disposeQueue.push(e.rows[n.row].medal);
			}
			return s();
		}
		case "disposeGift": {
			let e = et(o);
			if (!e || e === "geode" || o.fish || o.rewardPick) return q(K.queue);
			let t = o.nbHand[n.side];
			if (t === null) return q(K.card);
			let r = F[t];
			if (!r.goods.includes(e)) return q(K.card);
			let c = o.nbTrack[n.side], l = Math.min(8, c + r.bonus);
			if (o.nbTrack[n.side] = l, l > c) {
				let e = (n.side === "left" ? T : E)[l - 1];
				o.disposeQueue.push(e);
			}
			if (o.nbGifted += 1, o.nbHand[n.side] = null, o.disposeQueue.shift(), i.players.length > 1) {
				let e = i.players.indexOf(a), r = n.side === "left" ? i.players[(e - 1 + i.players.length) % i.players.length] : i.players[(e + 1) % i.players.length];
				i.ps[r].nbIncomingNext.push(t), i.ps[r].nbIncomingDirNext.push(n.side === "left" ? "right" : "left");
			} else i.nbDiscard.push(t);
			return s();
		}
		case "disposeGrounds": {
			let e = et(o);
			if (!e || e === "geode" || o.fish || o.rewardPick) return q(K.queue);
			let t = se.findIndex((t, n) => n > 0 && (t.cost[0] === e || ce[n] === e));
			if (t < 0) return q(K.cost);
			let r = se[t];
			return Ot(o, r.till, r.fence, n.till, n.fences) || (o.disposeQueue.shift(), s());
		}
		case "groundsCoin": return o.coins < 1 || o.fish || o.rewardPick || o.geode ? q(K.coins) : Ot(o, 1, 1, n.till, n.fences) || (--o.coins, s());
		case "pay":
			if (c()) return q(K.pending);
			switch (n.area) {
				case "energy": {
					let e = n.slot ?? o.energyPaid.findIndex((e) => e < 3);
					return e < 0 || e > 2 || o.energyPaid[e] >= 3 || o.coins < 1 ? q(K.coins) : (--o.coins, o.energyPaid[e] += 1, o.energyPaid[e] === 3 && (o.energyCharges[e] = 2), s());
				}
				case "animal": {
					let e = n.id;
					return !e || !O[e] || o.coins < 1 ? q(K.coins) : (--o.coins, o.animalPaid[e] += 1, o.animalPaid[e] % O[e].rowCost === 0 && (o.animalUnlocked[e] += 1), s());
				}
				case "purchase": {
					let e = Number(n.id), t = ue[e];
					return !t || o.purchaseUsed[e] || o.coins < t.cost ? q(K.coins) : (o.coins -= t.cost, o.purchaseUsed[e] = !0, o.disposeQueue.push(t.good), s());
				}
				case "intern": return o.internUsed || o.coins < 3 ? q(K.coins) : (o.coins -= 3, o.internUsed = !0, o.execStack.push({
					source: "intern",
					options: [],
					task: null,
					actions: 0,
					energyUsed: !1,
					cond: null,
					reward: null
				}), s());
				case "badge":
				case "explorer": return q(K.cost);
				default: {
					let e = xt(o, n.area, n.id);
					if (!e) return q(K.cost);
					let t = n.row ?? 0, r = e.rows[t], i = e.paid[t];
					if (!r || !i) return q(K.cost);
					let a = n.slot ?? r.findIndex((e, t) => e === "coin" && !i[t]);
					return a < 0 || r[a] !== "coin" || i[a] || o.coins < 1 ? q(K.coins) : n.area === "lureGreen" && o.lureChoice === 1 || n.area === "lureRed" && o.lureChoice === 0 ? q(K.cost) : (n.area === "lureGreen" && (o.lureChoice = 0), n.area === "lureRed" && (o.lureChoice = 1), --o.coins, i[a] = !0, s());
				}
			}
		case "useExplorer": return o.explorerUsed || !o.explorerPaid.every(Boolean) || !N.some((e) => e.id === n.badge) || o.badgeDoubled ? q(K.cost) : (o.explorerUsed = !0, o.badgeDoubled = n.badge, s());
		case "useBuyback": {
			if (o.buybackUsed || o.coins < 3) return q(K.coins);
			let e = N.find((e) => e.id === n.badge);
			if (!e) return q(K.cost);
			let t = o.badges[e.id][n.row];
			return !t || t[n.slot] === void 0 || t[n.slot] ? q(K.cost) : (o.coins -= 3, o.buybackUsed = !0, t[n.slot] = !0, t.every(Boolean) && o.disposeQueue.push(e.rows[n.row].medal), s());
		}
		case "pickReward": {
			let e = o.rewardPick;
			if (!e) return q(K.pending);
			if (e.kind === "pick") {
				let t = e.options[n.idx];
				if (t === void 0) return q(K.card);
				o.rewardPick = null, o.disposeQueue.push(t);
			} else if (e.kind === "choice") {
				let t = e.options[n.idx];
				if (!t) return q(K.card);
				for (o.rewardPick = null, pt(o, t); ht(o)?.options === null;) mt(o);
			} else return q(K.card);
			return s();
		}
		case "crossGood": {
			let e = o.rewardPick;
			if (!e || e.kind !== "crossGood" || !e.projects.includes(n.badge)) return q(K.card);
			let t = N.find((e) => e.id === n.badge);
			if (!t) return q(K.card);
			let r = o.badges[t.id][n.row];
			return !r || r[n.slot] === void 0 || r[n.slot] ? q(K.cost) : (o.rewardPick = null, r[n.slot] = !0, r.every(Boolean) && o.disposeQueue.push(t.rows[n.row].medal), s());
		}
		case "skip":
			if (o.rewardPick) o.rewardPick = null;
			else return q(K.pending);
			return s();
		case "placeAnimal": {
			let e = O[n.animal], t = o.animals.filter((e) => e.animal === n.animal).length;
			if (o.animalUnlocked[n.animal] <= t) return q(K.card);
			let r = G(n.anchor, e.size);
			if (!r) return q(K.fence);
			let i = St(o);
			return r.some((e) => i.has(e)) ? q(K.occupied) : We(r, o.fences) ? (o.animals.push({
				animal: n.animal,
				anchor: n.anchor,
				face: 0
			}), s()) : q(K.fence);
		}
		case "placeTrellis": {
			let e = o.trellis.filter((e) => e.every(Boolean)).length;
			if (o.trellises.length >= e) return q(K.card);
			let t = G(n.anchor, 2);
			if (!t) return q(K.occupied);
			let r = St(o);
			return t.some((e) => r.has(e)) ? q(K.occupied) : (o.trellises.push(n.anchor), s());
		}
		case "taskDone": return i.phase !== "task" || o.phaseDone ? q(K.phase) : o.execStack.length > 0 || o.disposeQueue.length > 0 || c() || o.picked.length < 2 ? q(K.pending) : (o.phaseDone = !0, s());
		default: return q(K.phase);
	}
}
function Ot(e, t, n, r, i) {
	if (t > 0) {
		if (!r || r.length !== t || i) return q(K.cost);
		let n = St(e);
		return new Set(r).size !== r.length || r.some((t) => !W(H(t), U(t)) || e.tilled.includes(t) || n.has(t)) ? q(K.occupied) : (e.tilled.push(...r), null);
	}
	if (!i || i.length !== n || r) return q(K.cost);
	if (new Set(i).size !== i.length) return q(K.fence);
	for (let t of i) {
		let [n, r, i] = t.split(":"), a = Number(r), o = Number(i);
		if (!(n === "h" ? W(a, o) || W(a - 1, o) : n === "v" && (W(a, o) || W(a, o - 1))) || e.fences.includes(t)) return q(K.fence);
	}
	return e.fences.push(...i), null;
}
function kt(e) {
	let t = (e) => ({
		scratched: e.scratched,
		cells: e.cells.map((t, n) => e.scratched[n] ? t : null)
	}), { setupHand: n, nbDraws: r, ...i } = e;
	return {
		...i,
		woods: t(e.woods),
		mines: t(e.mines),
		setupHandCount: n ? n.length : 0,
		nbDrawsCount: {
			left: r.left ? 2 : 0,
			right: r.right ? 2 : 0
		}
	};
}
function At(e, t) {
	let n = {
		phase: e.phase,
		round: e.round,
		totalRounds: 12,
		taskRow: e.taskRow,
		seasonTops: e.seasonDecks.map((e) => e[e.length - 1] ?? null),
		taskDeckCount: e.taskDeck.length,
		taskDiscardCount: e.taskDiscard.length,
		nbDeckCount: e.nbDeck.length,
		objectives: e.objectives,
		seasonScores: e.seasonScores,
		finalScores: e.finalScores,
		players: Object.fromEntries(e.players.map((t) => [t, kt(e.ps[t])])),
		order: e.players
	}, r = e.ps[t];
	return {
		public: n,
		private: r ? {
			setupHand: r.setupHand,
			nbDraws: r.nbDraws
		} : {}
	};
}
function jt(e) {
	if (e.phase !== "done" || !e.finalScores) return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.finalScores[n] - e.finalScores[t]), n = e.finalScores[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.finalScores[t] === n),
		ranking: t,
		scores: e.finalScores
	};
}
var Mt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: V,
	schemas: Ve,
	setup: (e, t, n) => Ye(e, t, n),
	reduce: Dt,
	viewFor: At,
	status: jt
}, J = "games/tend/", Nt = {
	farm: `${J}farm-scene.webp`,
	cargo: `${J}cargo-bay.webp`,
	woods: `${J}woods-scene.webp`,
	mines: `${J}mines-scene.webp`,
	pond: `${J}pond-scene.webp`,
	river: `${J}river-scene.webp`,
	lake: `${J}lake-scene.webp`,
	grotto: `${J}grotto-scene.webp`,
	geode: `${J}geode-scene.webp`
}, Pt = {
	pineapple: "pineapple-crop",
	berries: "berries-crop",
	wildFruit: "wildfruit-crop",
	pumpkin: "pumpkin-crop",
	egg: "egg-product",
	wool: "wool-product",
	milk: "milk-product",
	mamble: "mamble-fish",
	sunpop: "sunpop-fish",
	blobber: "blobber-fish",
	geojell: "geojell-fish",
	pebblepuff: "pebblepuff-fish",
	crankle: "crankle-fish",
	nessel: "nessel-fish",
	lillybloom: "lillybloom-fish",
	orbble: "orbble-fish",
	plumfish: "plumfish-fish",
	shimmerpuff: "shimmerpuff-fish",
	gribble: "gribble-fish",
	stone: "stone-rock",
	copper: "copper-rock",
	iron: "iron-rock",
	artifact: "artifact-relic",
	bone: "bone-relic",
	ruby: "ruby-gem",
	crystal: "crystal-gem",
	rainbowRock: "rainbow-rock",
	treeSap: "tree-sap",
	wood: "wood-log",
	exoWood: "exowood-log"
}, Ft = (e) => {
	if (e === "geode") return null;
	let t = Pt[e];
	return t ? `${J}${t}.webp` : null;
}, It = (e) => `${J}${Pt[e]}.webp`, Lt = (e) => `${J}${{
	chicken: "chicken-animal",
	sheep: "sheep-animal",
	cow: "cow-animal"
}[e]}.webp`, Rt = (e) => Nt[e], zt = (e) => `${J}${e}-tool.webp`, Bt = {
	pineapple: "games.tend.good.pineapple",
	wildFruit: "games.tend.good.wildFruit",
	pumpkin: "games.tend.good.pumpkin",
	berries: "games.tend.good.berries",
	egg: "games.tend.good.egg",
	wool: "games.tend.good.wool",
	milk: "games.tend.good.milk",
	mamble: "games.tend.good.mamble",
	sunpop: "games.tend.good.sunpop",
	blobber: "games.tend.good.blobber",
	geojell: "games.tend.good.geojell",
	pebblepuff: "games.tend.good.pebblepuff",
	crankle: "games.tend.good.crankle",
	nessel: "games.tend.good.nessel",
	lillybloom: "games.tend.good.lillybloom",
	orbble: "games.tend.good.orbble",
	plumfish: "games.tend.good.plumfish",
	shimmerpuff: "games.tend.good.shimmerpuff",
	gribble: "games.tend.good.gribble",
	stone: "games.tend.good.stone",
	copper: "games.tend.good.copper",
	iron: "games.tend.good.iron",
	artifact: "games.tend.good.artifact",
	bone: "games.tend.good.bone",
	ruby: "games.tend.good.ruby",
	crystal: "games.tend.good.crystal",
	rainbowRock: "games.tend.good.rainbowRock",
	treeSap: "games.tend.good.treeSap",
	redBp: "games.tend.good.redBp",
	purpleBp: "games.tend.good.purpleBp",
	heart: "games.tend.good.heart",
	medalCopper: "games.tend.good.medalCopper",
	medalSilver: "games.tend.good.medalSilver",
	medalGold: "games.tend.good.medalGold",
	medalPlatinum: "games.tend.good.medalPlatinum",
	wood: "games.tend.good.wood",
	exoWood: "games.tend.good.exoWood",
	geode: "games.tend.good.geode"
}, Vt = {
	basicWoods: "games.tend.badge.basicWoods",
	basicMines: "games.tend.badge.basicMines",
	basicFishing: "games.tend.badge.basicFishing",
	advWoods: "games.tend.badge.advWoods",
	advMines: "games.tend.badge.advMines",
	advFishing: "games.tend.badge.advFishing",
	plants: "games.tend.badge.plants",
	animals: "games.tend.badge.animals",
	generalist: "games.tend.badge.generalist"
}, Ht = {
	farm: "bg-emerald-500",
	fish: "bg-sky-500",
	mining: "bg-amber-600",
	social: "bg-rose-400",
	badge: "bg-violet-500"
}, Ut = {
	wood: "bg-amber-800",
	exoWood: "bg-fuchsia-700",
	geode: "bg-indigo-500"
}, Wt = (e) => e === "geode" || e === "wood" || e === "exoWood" ? null : S[e].cat, Gt = (e) => {
	let t = Ut[e];
	if (t) return t;
	let n = Wt(e);
	return n ? Ht[n] : "bg-slate-400";
}, Kt = (e) => e === "geode" ? 0 : e === "wood" || e === "exoWood" ? C[e] : S[e].sell;
function qt({ good: e, size: t = 20 }) {
	let n = c()(Bt[e]), r = Ft(e), i = e === "heart" ? "♥" : e.startsWith("medal") ? "✦" : e === "geode" ? "◇" : "●";
	return r ? /* @__PURE__ */ m("img", {
		src: r,
		alt: n,
		title: n,
		width: t,
		height: t,
		className: "inline-block shrink-0 object-contain",
		draggable: !1
	}) : /* @__PURE__ */ m("span", {
		title: n,
		"aria-label": n,
		className: "inline-flex shrink-0 items-center justify-center font-black text-violet-700",
		style: {
			width: t,
			height: t
		},
		children: i
	});
}
function Y({ good: e, size: t = "sm" }) {
	let n = c()(Bt[e]), r = e === "geode" ? null : Ft(e), i = e === "heart" ? "♥" : e.startsWith("medal") ? "✦" : e === "geode" ? "◇" : "●";
	return /* @__PURE__ */ h("span", {
		className: "tend-token",
		"data-size": t,
		title: n,
		children: [
			/* @__PURE__ */ m("span", {
				className: `h-4 w-1 shrink-0 rounded-full ${Gt(e)}`,
				"aria-hidden": "true"
			}),
			r ? /* @__PURE__ */ m("img", {
				src: r,
				alt: "",
				draggable: !1
			}) : /* @__PURE__ */ m("span", {
				className: "text-sm leading-none",
				"aria-hidden": "true",
				children: i
			}),
			/* @__PURE__ */ m("span", {
				className: "whitespace-nowrap",
				children: t === "xs" ? n.slice(0, 2) : n
			})
		]
	});
}
//#endregion
//#region src/games/tend/farm-view.tsx
var X = 30, Jt = 11 * X, Yt = pe.length * X, Xt = {
	chicken: "🐔",
	sheep: "🦙",
	cow: "🐄"
}, Zt = {
	w2: "⚪2",
	wx: "⚪✕",
	wr: "⚪↺"
};
function Qt() {
	let e = [];
	for (let t = 0; t <= pe.length; t++) for (let n = 0; n < 11; n++) (W(t, n) || W(t - 1, n)) && e.push(`h:${t}:${n}`);
	for (let t = 0; t < pe.length; t++) for (let n = 0; n <= 11; n++) (W(t, n) || W(t, n - 1)) && e.push(`v:${t}:${n}`);
	return e;
}
var $t = Qt();
function en(e) {
	let [t, n, r] = e.split(":"), i = Number(n), a = Number(r);
	return t === "h" ? {
		x: a * X,
		y: i * X,
		w: X,
		h: 0
	} : {
		x: a * X,
		y: i * X,
		w: 0,
		h: X
	};
}
function Z({ rows: e, paid: t, mode: n, good: r, onTap: i, rowLabel: a }) {
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-1",
		children: e.map((e, o) => /* @__PURE__ */ h("div", {
			className: "flex items-center gap-1",
			children: [a && /* @__PURE__ */ m("span", {
				className: "w-4 text-[9px] font-bold opacity-60",
				children: a(o)
			}), e.map((e, a) => {
				let s = t[o]?.[a] ?? !1, c = !s && (n === "pay" ? e === "coin" : n === "dispose" ? e === r : n === "any");
				return /* @__PURE__ */ m("button", {
					type: "button",
					disabled: !c,
					onClick: () => i?.(o, a),
					className: `flex min-h-11 min-w-11 items-center justify-center rounded-md border-2 text-sm font-black ${s ? "border-ink/20 bg-slate-300 text-white line-through" : c ? "border-ink bg-amber-300" : "border-ink/30 bg-surface"}`,
					children: e === "coin" ? "🪙" : /* @__PURE__ */ m(Y, {
						good: e,
						size: "xs"
					})
				}, a);
			})]
		}, o))
	});
}
function Q({ k: e, done: t }) {
	let n = c();
	return /* @__PURE__ */ h("p", {
		className: `text-[10px] font-black ${t ? "text-emerald-700" : "opacity-70"}`,
		children: [n(e), t ? " ✓" : ""]
	});
}
function tn(e) {
	let t = c(), { p: n, accent: r } = e, i = e.placeSize, a = /* @__PURE__ */ new Set(), o = [];
	for (let e of n.crops) {
		let t = D[e.crop].size, n = H(e.anchor), r = U(e.anchor);
		for (let e = 0; e < t; e++) for (let i = 0; i < t; i++) a.add((n + e) * 11 + r + i);
		let i = D[e.crop].faces[e.face];
		o.push({
			idx: e.anchor,
			art: It(e.crop),
			symbol: "",
			face: Zt[i] ?? String(i),
			size: t
		});
	}
	for (let e of n.animals) {
		let t = O[e.animal].size, n = H(e.anchor), r = U(e.anchor);
		for (let e = 0; e < t; e++) for (let i = 0; i < t; i++) a.add((n + e) * 11 + r + i);
		let i = O[e.animal].faces[e.face];
		o.push({
			idx: e.anchor,
			art: Lt(e.animal),
			symbol: "",
			face: Zt[i] ?? String(i),
			size: t
		});
	}
	for (let e of n.trellises) {
		let t = H(e), n = U(e);
		for (let e = 0; e < 2; e++) for (let r = 0; r < 2; r++) a.add((t + e) * 11 + n + r);
		o.push({
			idx: e,
			art: null,
			symbol: "⌗",
			face: "",
			size: 2
		});
	}
	let s = new Set(n.tilled), l = new Set(n.fences), u = (e, n, r) => /* @__PURE__ */ h("div", {
		className: "flex items-center gap-1",
		children: [/* @__PURE__ */ m("span", {
			className: "w-8 text-[10px] font-black opacity-70",
			children: t(r)
		}), e.map((e, t) => /* @__PURE__ */ m("span", {
			className: `flex size-6 items-center justify-center rounded ${t < n ? "bg-slate-300 opacity-50 line-through" : t === n ? "border-2 border-ink bg-amber-300" : "bg-surface border border-ink/20"}`,
			children: e === "coin" ? /* @__PURE__ */ m("span", {
				className: "text-[10px]",
				children: "🪙"
			}) : /* @__PURE__ */ m(qt, {
				good: e,
				size: 20
			})
		}, t))]
	});
	return /* @__PURE__ */ h("div", {
		className: "tend-farm-page flex h-full min-h-0 flex-col gap-2 overflow-y-auto p-2",
		children: [
			/* @__PURE__ */ h("div", {
				className: "tend-scene",
				children: [/* @__PURE__ */ m("img", {
					src: Nt.farm,
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ h("div", {
					className: "tend-scene-title",
					children: [t("games.tend.tabFarm"), /* @__PURE__ */ m("span", {
						className: "tend-scene-subtitle",
						children: t("games.tend.journalLabel")
					})]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "tend-sheet-section tend-grid-scroll shrink-0",
				children: /* @__PURE__ */ h("svg", {
					viewBox: `-2 -2 ${Jt + 4} ${Yt + 4}`,
					className: "tend-farm-grid",
					"data-active": !!(e.hiCells?.size || e.hiEdges?.size),
					role: "group",
					"aria-label": t("games.tend.tabFarm"),
					children: [
						/* @__PURE__ */ m("image", {
							href: Nt.farm,
							x: "0",
							y: "0",
							width: Jt,
							height: Yt,
							preserveAspectRatio: "xMidYMid slice",
							opacity: "0.58"
						}),
						pe.map(([t, n], i) => Array.from({ length: n - t + 1 }, (e, n) => t + n).map((t) => {
							let n = i * 11 + t, o = t * X, c = i * X, l = s.has(n), u = a.has(n), d = e.hiCells?.has(n) ?? !1, f = e.selCells?.has(n) ?? !1;
							return /* @__PURE__ */ h("g", {
								onClick: d || e.onCellTap ? () => e.onCellTap?.(n) : void 0,
								className: d ? "cursor-pointer" : void 0,
								children: [/* @__PURE__ */ m("rect", {
									x: o + .5,
									y: c + .5,
									width: 29,
									height: 29,
									fill: f ? "var(--color-amber-300)" : d ? "var(--color-emerald-100)" : l ? "var(--color-amber-100)" : "var(--color-paper)",
									fillOpacity: f || d ? .78 : l ? .7 : .48,
									stroke: d ? r : "var(--color-ink)",
									strokeOpacity: d ? 1 : .38,
									strokeWidth: d ? 2.5 : .8
								}), u && /* @__PURE__ */ m("circle", {
									cx: o + X / 2,
									cy: c + X / 2,
									r: "2",
									fill: "var(--color-ink)",
									opacity: ".22"
								})]
							}, n);
						})),
						i && [...e.hiCells ?? []].map((e) => {
							let t = U(e) * X, n = H(e) * X;
							return /* @__PURE__ */ m("rect", {
								x: t + 2,
								y: n + 2,
								width: i * X - 4,
								height: i * X - 4,
								rx: "5",
								fill: "var(--color-emerald-100)",
								fillOpacity: ".18",
								stroke: r,
								strokeWidth: "2.5",
								strokeDasharray: "6 3",
								pointerEvents: "none"
							}, `place-${e}`);
						}),
						o.map((t) => {
							let n = U(t.idx) * X, i = H(t.idx) * X, a = t.size * X, o = e.hiCells?.has(t.idx) ?? !1;
							return /* @__PURE__ */ h("g", {
								pointerEvents: "none",
								children: [
									/* @__PURE__ */ m("rect", {
										x: n + 2,
										y: i + 2,
										width: a - 4,
										height: a - 4,
										rx: "7",
										fill: "var(--color-surface)",
										fillOpacity: ".68",
										stroke: o ? r : "var(--color-ink)",
										strokeWidth: o ? 3 : 1.4
									}),
									t.art ? /* @__PURE__ */ m("image", {
										href: t.art,
										x: n + 4,
										y: i + 4,
										width: a - 8,
										height: a - 8,
										preserveAspectRatio: "xMidYMid meet"
									}) : /* @__PURE__ */ m("text", {
										x: n + a / 2,
										y: i + a / 2 + 12,
										textAnchor: "middle",
										fontSize: "38",
										fontWeight: "900",
										fill: "var(--color-emerald-700)",
										children: t.symbol
									}),
									t.face && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("rect", {
										x: n + a - 24,
										y: i + a - 22,
										width: "21",
										height: "19",
										rx: "5",
										fill: "var(--color-surface)",
										stroke: "var(--color-ink)",
										strokeWidth: "1.4"
									}), /* @__PURE__ */ m("text", {
										x: n + a - 13.5,
										y: i + a - 8,
										textAnchor: "middle",
										fontSize: "9",
										fontWeight: "900",
										fill: "var(--color-ink)",
										children: t.face
									})] })
								]
							}, t.idx);
						}),
						$t.map((t) => {
							let n = l.has(t), i = e.hiEdges?.has(t) ?? !1, a = e.selEdges?.has(t) ?? !1;
							if (!n && !i) return null;
							let { x: o, y: s, w: c, h: u } = en(t), d = c > 0;
							return /* @__PURE__ */ h("g", {
								onClick: i ? () => e.onEdgeTap?.(t) : void 0,
								className: i ? "cursor-pointer" : void 0,
								children: [i && /* @__PURE__ */ m("rect", {
									x: d ? o : o - 14,
									y: d ? s - 14 : s,
									width: d ? c : 28,
									height: d ? 28 : u,
									fill: "transparent"
								}), /* @__PURE__ */ m("line", {
									x1: o,
									y1: s,
									x2: o + c,
									y2: s + u,
									stroke: a ? "#eab308" : n ? "#7c5a3a" : r,
									strokeWidth: n ? 4 : 3,
									strokeDasharray: n ? void 0 : "4 3",
									strokeLinecap: "round"
								})]
							}, t);
						})
					]
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "tend-farm-costs",
				children: [
					/* @__PURE__ */ h("div", {
						className: "flex shrink-0 flex-col gap-1",
						children: [
							u(w, n.chopLv, "games.tend.chopTrack"),
							u(ie, n.mineLv, "games.tend.mineTrack"),
							/* @__PURE__ */ h("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ m("span", {
									className: "w-8 text-[10px] font-black opacity-70",
									children: t("games.tend.energyBar")
								}), n.energyPaid.map((t, r) => /* @__PURE__ */ h("button", {
									type: "button",
									disabled: e.costMode !== "pay" || t >= 3,
									onClick: () => e.onCostTap?.({
										area: "energy",
										row: 0,
										slot: r
									}),
									className: `flex min-h-9 items-center gap-0.5 rounded-md border-2 px-1 ${t >= 3 ? "border-emerald-600 bg-emerald-100" : e.costMode === "pay" ? "border-ink bg-amber-300" : "border-ink/30 bg-surface"}`,
									children: [Array.from({ length: 3 }, (e, n) => /* @__PURE__ */ m("span", {
										className: `text-[10px] ${n < t ? "" : "opacity-30"}`,
										children: "🪙"
									}, n)), /* @__PURE__ */ h("span", {
										className: "ml-0.5 text-[10px] font-black text-sky-700",
										children: ["⚡", n.energyCharges[r]]
									})]
								}, r))]
							})
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "grid shrink-0 grid-cols-2 gap-x-2 gap-y-2",
						children: [
							/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m(Q, {
								k: "games.tend.trellisArea",
								done: n.trellis.every((e) => e.every(Boolean))
							}), /* @__PURE__ */ m(Z, {
								rows: n.trellis.map(() => ae),
								paid: n.trellis,
								mode: e.costMode,
								good: e.disposeGood,
								onTap: (t, n) => e.onCostTap?.({
									area: "trellis",
									row: t,
									slot: n
								})
							})] }),
							/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m(Q, {
								k: "games.tend.bridge",
								done: n.bridge.every((e) => e.every(Boolean))
							}), /* @__PURE__ */ m(Z, {
								rows: A,
								paid: n.bridge,
								mode: e.costMode,
								good: e.disposeGood,
								onTap: (t, n) => e.onCostTap?.({
									area: "bridge",
									row: t,
									slot: n
								})
							})] }),
							/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m(Q, {
								k: "games.tend.equipTools",
								done: n.equip.tools.every((e) => e.every(Boolean))
							}), /* @__PURE__ */ m(Z, {
								rows: k,
								paid: n.equip.tools,
								mode: e.costMode,
								good: e.disposeGood,
								onTap: (t, n) => e.onCostTap?.({
									area: "equipTools",
									row: t,
									slot: n
								})
							})] }),
							/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m(Q, {
								k: "games.tend.equipHatchet",
								done: n.equip.hatchet.every((e) => e.every(Boolean))
							}), /* @__PURE__ */ m(Z, {
								rows: k,
								paid: n.equip.hatchet,
								mode: e.costMode,
								good: e.disposeGood,
								onTap: (t, n) => e.onCostTap?.({
									area: "equipHatchet",
									row: t,
									slot: n
								})
							})] }),
							/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m(Q, {
								k: "games.tend.equipPickaxe",
								done: n.equip.pickaxe.every((e) => e.every(Boolean))
							}), /* @__PURE__ */ m(Z, {
								rows: k,
								paid: n.equip.pickaxe,
								mode: e.costMode,
								good: e.disposeGood,
								onTap: (t, n) => e.onCostTap?.({
									area: "equipPickaxe",
									row: t,
									slot: n
								})
							})] }),
							/* @__PURE__ */ h("div", { children: [
								/* @__PURE__ */ m(Q, {
									k: "games.tend.rod1",
									done: n.rod1.every((e) => e.every(Boolean))
								}),
								/* @__PURE__ */ m(Z, {
									rows: j,
									paid: n.rod1,
									mode: e.costMode,
									good: e.disposeGood,
									onTap: (t, n) => e.onCostTap?.({
										area: "rod1",
										row: t,
										slot: n
									})
								}),
								/* @__PURE__ */ m(Q, {
									k: "games.tend.rod2",
									done: n.rod2.every((e) => e.every(Boolean))
								}),
								/* @__PURE__ */ m(Z, {
									rows: M,
									paid: n.rod2,
									mode: e.costMode,
									good: e.disposeGood,
									onTap: (t, n) => e.onCostTap?.({
										area: "rod2",
										row: t,
										slot: n
									})
								})
							] }),
							/* @__PURE__ */ h("div", { children: [
								/* @__PURE__ */ m(Q, {
									k: "games.tend.lureGreen",
									done: n.lureChoice === 0 && n.lures[0].every(Boolean)
								}),
								/* @__PURE__ */ m(Z, {
									rows: [oe[0]],
									paid: [n.lures[0]],
									mode: e.costMode,
									good: e.disposeGood,
									onTap: (t, n) => e.onCostTap?.({
										area: "lureGreen",
										row: 0,
										slot: n
									})
								}),
								/* @__PURE__ */ m(Q, {
									k: "games.tend.lureRed",
									done: n.lureChoice === 1 && n.lures[1].every(Boolean)
								}),
								/* @__PURE__ */ m(Z, {
									rows: [oe[1]],
									paid: [n.lures[1]],
									mode: e.costMode,
									good: e.disposeGood,
									onTap: (t, n) => e.onCostTap?.({
										area: "lureRed",
										row: 0,
										slot: n
									})
								})
							] }),
							/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m(Q, { k: "games.tend.animalPen" }), Object.keys(O).map((t) => {
								let i = O[t], a = i.rowCount * i.rowCost, o = n.animalPaid[t], s = n.animalUnlocked[t] - n.animals.filter((e) => e.animal === t).length;
								return /* @__PURE__ */ h("div", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ m("span", {
											className: "text-sm",
											children: Xt[t]
										}),
										/* @__PURE__ */ m("button", {
											type: "button",
											disabled: e.costMode !== "pay" || o >= a,
											onClick: () => e.onAnimalPay?.(t),
											className: `flex min-h-9 flex-1 items-center gap-0.5 rounded-md border-2 px-1 ${o >= a ? "border-emerald-600 bg-emerald-100" : e.costMode === "pay" ? "border-ink bg-amber-300" : "border-ink/30 bg-surface"}`,
											children: Array.from({ length: a }, (e, t) => /* @__PURE__ */ m("span", {
												className: `text-[9px] ${t < o ? "" : "opacity-30"}`,
												children: "🪙"
											}, t))
										}),
										s > 0 && /* @__PURE__ */ h("button", {
											type: "button",
											onClick: () => e.onPlaceAnimal?.(t),
											className: `min-h-9 rounded-md border-2 px-1.5 text-[10px] font-black ${e.animalMode === t ? "border-ink text-white" : "border-ink/40 bg-surface"}`,
											style: e.animalMode === t ? { background: r } : void 0,
											children: [
												Xt[t],
												"×",
												s
											]
										})
									]
								}, t);
							})] })
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "shrink-0",
						children: [/* @__PURE__ */ m(Q, { k: "games.tend.groundsTitle" }), /* @__PURE__ */ h("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ m("button", {
								type: "button",
								disabled: e.costMode !== "pay" || n.coins < 1,
								onClick: e.onGroundsCoin,
								className: `min-h-9 rounded-md border-2 px-2 text-left text-[10px] font-black ${e.groundsActive ? "border-ink text-white" : "border-ink/30 bg-surface disabled:opacity-40"}`,
								style: e.groundsActive ? { background: r } : void 0,
								children: t("games.tend.groundsCoin")
							}), se.slice(1).map((e, t) => {
								let n = ce[t + 1];
								return /* @__PURE__ */ h("div", {
									className: "flex min-h-9 items-center gap-1 rounded-md border border-ink/20 bg-surface px-2 text-[10px] font-bold",
									children: [
										/* @__PURE__ */ m(Y, {
											good: e.cost[0],
											size: "xs"
										}),
										n && /* @__PURE__ */ m("span", {
											className: "opacity-60",
											children: "/"
										}),
										n && /* @__PURE__ */ m(Y, {
											good: n,
											size: "xs"
										}),
										/* @__PURE__ */ h("span", {
											className: "opacity-70",
											children: ["→ ", e.fence > 0 ? `🚧×${e.fence}` : `~×${e.till}`]
										})
									]
								}, t);
							})]
						})]
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/tend/task-row.tsx
var nn = (e) => ({
	tend: "🌱",
	fish: "🎣",
	chop: "🪓",
	mine: "⛏️"
})[e], rn = {
	tend: "games.tend.mainTask.tend",
	fish: "games.tend.mainTask.fish",
	chop: "games.tend.mainTask.chop",
	mine: "games.tend.mainTask.mine"
};
function an({ task: e, size: t = 20, alt: n }) {
	let r = c();
	return /* @__PURE__ */ m("img", {
		src: zt(e),
		alt: n ?? r(rn[e]),
		width: t,
		height: t,
		className: "inline-block shrink-0 object-contain",
		draggable: !1
	});
}
var on = {
	farm: "🌱",
	fish: "🐟",
	mining: "⛏️",
	social: "💌",
	badge: "🏅"
}, sn = {
	river: "games.tend.unlockRiver",
	lake: "games.tend.unlockLake",
	grotto: "games.tend.unlockGrotto",
	rod: "games.tend.unlockRod",
	lure: "games.tend.unlockLure"
}, cn = {
	"s1-01": "games.tend.task.s1-01",
	"s1-02": "games.tend.task.s1-02",
	"s1-03": "games.tend.task.s1-03",
	"s1-04": "games.tend.task.s1-04",
	"s1-05": "games.tend.task.s1-05",
	"s1-06": "games.tend.task.s1-06",
	"s1-07": "games.tend.task.s1-07",
	"s1-08": "games.tend.task.s1-08",
	"s1-09": "games.tend.task.s1-09",
	"s1-10": "games.tend.task.s1-10",
	"s1-11": "games.tend.task.s1-11",
	"s1-12": "games.tend.task.s1-12",
	"s1-13": "games.tend.task.s1-13",
	"s1-14": "games.tend.task.s1-14",
	"s1-15": "games.tend.task.s1-15",
	"s1-16": "games.tend.task.s1-16",
	"s1-17": "games.tend.task.s1-17",
	"s1-18": "games.tend.task.s1-18",
	"s1-19": "games.tend.task.s1-19",
	"s1-20": "games.tend.task.s1-20",
	"s2-01": "games.tend.task.s2-01",
	"s2-02": "games.tend.task.s2-02",
	"s2-03": "games.tend.task.s2-03",
	"s2-04": "games.tend.task.s2-04",
	"s2-05": "games.tend.task.s2-05",
	"s2-06": "games.tend.task.s2-06",
	"s2-07": "games.tend.task.s2-07",
	"s2-08": "games.tend.task.s2-08",
	"s2-09": "games.tend.task.s2-09",
	"s2-10": "games.tend.task.s2-10",
	"s2-11": "games.tend.task.s2-11",
	"s2-12": "games.tend.task.s2-12",
	"s2-13": "games.tend.task.s2-13",
	"s2-14": "games.tend.task.s2-14",
	"s2-15": "games.tend.task.s2-15",
	"s2-16": "games.tend.task.s2-16",
	"s2-17": "games.tend.task.s2-17",
	"s2-18": "games.tend.task.s2-18",
	"s2-19": "games.tend.task.s2-19",
	"s2-20": "games.tend.task.s2-20",
	"s3-01": "games.tend.task.s3-01",
	"s3-02": "games.tend.task.s3-02",
	"s3-03": "games.tend.task.s3-03",
	"s3-04": "games.tend.task.s3-04",
	"s3-05": "games.tend.task.s3-05",
	"s3-06": "games.tend.task.s3-06",
	"s3-07": "games.tend.task.s3-07",
	"s3-08": "games.tend.task.s3-08",
	"s3-09": "games.tend.task.s3-09",
	"s3-10": "games.tend.task.s3-10",
	"s3-11": "games.tend.task.s3-11",
	"s3-12": "games.tend.task.s3-12",
	"s3-13": "games.tend.task.s3-13",
	"s3-14": "games.tend.task.s3-14",
	"s3-15": "games.tend.task.s3-15",
	"s3-16": "games.tend.task.s3-16",
	"s3-17": "games.tend.task.s3-17",
	"s3-18": "games.tend.task.s3-18",
	"s3-19": "games.tend.task.s3-19",
	"s3-20": "games.tend.task.s3-20"
}, ln = {
	clearer: "games.tend.obj.clearer",
	cruncher: "games.tend.obj.cruncher",
	edges: "games.tend.obj.edges",
	leftSampler: "games.tend.obj.leftSampler",
	loner: "games.tend.obj.loner",
	medalBonus: "games.tend.obj.medalBonus",
	socialite: "games.tend.obj.socialite",
	spacer: "games.tend.obj.spacer",
	wideSpacer: "games.tend.obj.wideSpacer",
	animalHandler: "games.tend.obj.animalHandler",
	borders: "games.tend.obj.borders",
	centerSampler: "games.tend.obj.centerSampler",
	crossOver: "games.tend.obj.crossOver",
	meritEarner: "games.tend.obj.meritEarner",
	minimalist: "games.tend.obj.minimalist",
	moderate: "games.tend.obj.moderate",
	organizer: "games.tend.obj.organizer",
	shrimp: "games.tend.obj.shrimp",
	biggen: "games.tend.obj.biggen",
	cargoMaster: "games.tend.obj.cargoMaster",
	centrist: "games.tend.obj.centrist",
	lefty: "games.tend.obj.lefty",
	packed: "games.tend.obj.packed",
	righty: "games.tend.obj.righty",
	seasonedWorker: "games.tend.obj.seasonedWorker",
	trueFriend: "games.tend.obj.trueFriend",
	varietyPack: "games.tend.obj.varietyPack"
}, un = {
	clearer: "games.tend.objDesc.clearer",
	cruncher: "games.tend.objDesc.cruncher",
	edges: "games.tend.objDesc.edges",
	leftSampler: "games.tend.objDesc.leftSampler",
	loner: "games.tend.objDesc.loner",
	medalBonus: "games.tend.objDesc.medalBonus",
	socialite: "games.tend.objDesc.socialite",
	spacer: "games.tend.objDesc.spacer",
	wideSpacer: "games.tend.objDesc.wideSpacer",
	animalHandler: "games.tend.objDesc.animalHandler",
	borders: "games.tend.objDesc.borders",
	centerSampler: "games.tend.objDesc.centerSampler",
	crossOver: "games.tend.objDesc.crossOver",
	meritEarner: "games.tend.objDesc.meritEarner",
	minimalist: "games.tend.objDesc.minimalist",
	moderate: "games.tend.objDesc.moderate",
	organizer: "games.tend.objDesc.organizer",
	shrimp: "games.tend.objDesc.shrimp",
	biggen: "games.tend.objDesc.biggen",
	cargoMaster: "games.tend.objDesc.cargoMaster",
	centrist: "games.tend.objDesc.centrist",
	lefty: "games.tend.objDesc.lefty",
	packed: "games.tend.objDesc.packed",
	righty: "games.tend.objDesc.righty",
	seasonedWorker: "games.tend.objDesc.seasonedWorker",
	trueFriend: "games.tend.objDesc.trueFriend",
	varietyPack: "games.tend.objDesc.varietyPack"
};
function dn(e, t) {
	switch (t.kind) {
		case "mineLevel": return `⛏️Lv${t.n}+`;
		case "chopLevel": return `🪓Lv${t.n}+`;
		case "energyBars": return `⚡×${t.n}`;
		case "animals": return `🐔×${t.n}`;
		case "trellis": return `🪜×${t.n}`;
		case "tilled": return `~×${t.n}`;
		case "cargoFilled": return `📦×${t.n}`;
		case "cargoCols": return `▯×${t.n}`;
		case "cargoRows": return `▬×${t.n}`;
		case "neighborBonus": return `💌×${t.n}`;
		case "projectsDone": return `🏅×${t.n}`;
		case "badges": return `🏅×${t.n}`;
		case "equipUpgrades": return `🔧×${t.n}`;
		case "cargoCat": return `${on[t.cat]}×${t.n}`;
		case "unlock": return e(sn[t.what]);
		case "badgeUnlocked": return t.projects.map((t) => e(Vt[t])).join("/") + "🏅";
		case "projectMedals": return t.projects.map((t) => e(Vt[t])).join("/") + ` ${e("games.tend.medalShort")}×${t.n}`;
		case "and": return t.all.map((t) => dn(e, t)).join(" & ");
		case "or": return t.any.map((t) => dn(e, t)).join(" | ");
	}
}
function fn(e) {
	return /* @__PURE__ */ m("span", {
		className: "inline-flex flex-wrap items-center gap-0.5",
		children: e.map((e, t) => /* @__PURE__ */ m(Y, {
			good: e === "geode" ? "geode" : e,
			size: "xs"
		}, t))
	});
}
function pn({ r: e }) {
	let t = c();
	switch (e.kind) {
		case "goods": return fn(e.goods);
		case "pick": return /* @__PURE__ */ m("span", {
			className: "inline-flex flex-wrap items-center gap-0.5",
			children: e.options.map((e, t) => /* @__PURE__ */ h("span", {
				className: "inline-flex items-center gap-0.5",
				children: [t > 0 && /* @__PURE__ */ m("span", {
					className: "text-[9px] opacity-60",
					children: "|"
				}), /* @__PURE__ */ m(Y, {
					good: e === "geode" ? "geode" : e,
					size: "xs"
				})]
			}, t))
		});
		case "coins": return /* @__PURE__ */ h("span", {
			className: "text-[10px] font-black",
			children: ["🪙×", e.n]
		});
		case "freeTask": return /* @__PURE__ */ h("span", {
			className: "text-[10px] font-black",
			children: [
				t("games.tend.rewardFree"),
				" ",
				e.tasks.map(nn).join("/")
			]
		});
		case "anyTask": return /* @__PURE__ */ m("span", {
			className: "text-[10px] font-black",
			children: t("games.tend.rewardAny")
		});
		case "crossGood": return /* @__PURE__ */ h("span", {
			className: "text-[10px] font-black",
			children: ["✕ ", t("games.tend.rewardCross")]
		});
		case "bundle": return /* @__PURE__ */ m("span", {
			className: "inline-flex flex-wrap items-center gap-1",
			children: e.parts.map((e, t) => /* @__PURE__ */ m(pn, { r: e }, t))
		});
		case "choice": return /* @__PURE__ */ m("span", {
			className: "inline-flex flex-wrap items-center gap-1",
			children: e.options.map((e, t) => /* @__PURE__ */ h("span", {
				className: "inline-flex items-center gap-1",
				children: [t > 0 && /* @__PURE__ */ m("span", {
					className: "text-[9px] opacity-60",
					children: "|"
				}), /* @__PURE__ */ m(pn, { r: e })]
			}, t))
		});
	}
}
function mn({ cardId: e, selected: t, disabled: n, onPick: r, small: i }) {
	let a = c();
	if (e.startsWith("st:")) {
		let o = e.split(":")[1];
		return /* @__PURE__ */ h("button", {
			type: "button",
			disabled: n,
			onClick: r,
			className: "tend-task-card",
			"data-small": !!i,
			"data-selected": !!t,
			children: [/* @__PURE__ */ m("span", {
				className: "tend-task-card-head bg-violet-100",
				children: a(o === "zenithOrders" ? "games.tend.starter.zenithOrders" : rn[o])
			}), /* @__PURE__ */ h("span", {
				className: "flex flex-1 flex-col items-center justify-center gap-1 p-2",
				children: [/* @__PURE__ */ m("span", {
					className: "text-3xl",
					children: o === "zenithOrders" ? "🪙" : /* @__PURE__ */ m(an, {
						task: o,
						size: 46,
						alt: ""
					})
				}), o === "zenithOrders" && /* @__PURE__ */ m("span", {
					className: "font-mono text-sm font-black tabular-nums",
					children: "×2"
				})]
			})]
		});
	}
	let o = Oe[e];
	if (!o) return null;
	let s = o.season === 1 ? "bg-emerald-200" : o.season === 2 ? "bg-amber-200" : "bg-violet-200";
	return /* @__PURE__ */ h("button", {
		type: "button",
		disabled: n,
		onClick: r,
		className: "tend-task-card",
		"data-small": !!i,
		"data-selected": !!t,
		children: [/* @__PURE__ */ h("div", {
			className: `tend-task-card-head ${s}`,
			children: [/* @__PURE__ */ h("span", { children: [a(cn[o.id]), o.adv ? " ✦" : ""] }), /* @__PURE__ */ h("span", {
				className: "font-mono text-[10px] tabular-nums",
				children: ["S", o.season]
			})]
		}), /* @__PURE__ */ h("div", {
			className: "tend-task-card-body",
			children: [
				/* @__PURE__ */ h("div", {
					className: "flex flex-wrap gap-1 text-xs font-black",
					children: [
						o.top.kind === "tasks" && o.top.tasks.map((e) => /* @__PURE__ */ h("span", {
							className: "inline-flex items-center gap-0.5 rounded border border-ink/25 bg-emerald-50 px-1 py-0.5",
							children: [
								/* @__PURE__ */ m(an, {
									task: e,
									size: 17,
									alt: ""
								}),
								" ",
								a(rn[e])
							]
						}, e)),
						o.top.kind === "anyTask" && a("games.tend.rewardAny"),
						o.top.kind === "coins" && `🪙×${o.top.n}`
					]
				}),
				o.cond && /* @__PURE__ */ m("div", {
					className: "tend-task-condition",
					children: dn(a, o.cond)
				}),
				o.bottom && /* @__PURE__ */ m("div", {
					className: "tend-task-reward",
					children: /* @__PURE__ */ m(pn, { r: o.bottom })
				})
			]
		})]
	});
}
function hn({ id: e, season: t }) {
	let n = c();
	return Ae[e] ? /* @__PURE__ */ h("div", {
		className: "tend-sheet-section flex items-center gap-2",
		children: [/* @__PURE__ */ h("span", {
			className: "shrink-0 rounded border border-ink/40 bg-amber-200 px-1.5 py-1 font-mono text-xs font-black tabular-nums",
			children: ["S", t]
		}), /* @__PURE__ */ h("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ m("p", {
				className: "text-xs font-black",
				children: n(ln[e])
			}), /* @__PURE__ */ m("p", {
				className: "text-[11px] font-bold opacity-70",
				children: n(un[e])
			})]
		})]
	}) : null;
}
//#endregion
//#region src/games/tend/cargo-view.tsx
var gn = {
	farm: "games.tend.cat.farm",
	fish: "games.tend.cat.fish",
	mining: "games.tend.cat.mining",
	social: "games.tend.cat.social",
	badge: "games.tend.cat.badge"
}, $ = 26;
function _n(e, t, n) {
	let r = x[S[e].shape].map(([e, t]) => [e, t]);
	for (let e = 0; e < n; e++) r = r.map(([e, t]) => [t, -e]);
	let i = Math.min(...r.map(([e]) => e)), a = Math.min(...r.map(([, e]) => e));
	r = r.map(([e, t]) => [e - i, t - a]);
	let o = Math.floor(t / 12), s = t % 12;
	return r.map(([e, t]) => (o + e) * 12 + (s + t));
}
function vn(e, t, n, r) {
	let i = _n(t, n, r), a = n % 12;
	if (i.some((t) => {
		let n = Math.floor(t / 12), r = t % 12;
		return n >= 8 || r >= 12 || r < a || e.cargo[t] !== null;
	})) return !1;
	let o = S[t].cat, s = new Set(i);
	for (let t of i) {
		let n = Math.floor(t / 12), r = t % 12;
		for (let [t, i] of [
			[n - 1, r],
			[n + 1, r],
			[n, r - 1],
			[n, r + 1]
		]) {
			if (t < 0 || t >= 8 || i < 0 || i >= 12) continue;
			let n = t * 12 + i;
			if (s.has(n)) continue;
			let r = e.cargo[n];
			if (r && S[r].cat === o) return !1;
		}
	}
	return !0;
}
var yn = [
	"var(--color-amber-500)",
	"var(--color-sky-500)",
	"var(--color-emerald-500)"
];
function bn({ p: e, cargoGood: t, cargoRot: n, onCargoTap: r, onRotate: i, costMode: a, disposeGood: o, onCostTap: s, onPurchase: l, onIntern: u, onExplorer: d, onBuyback: f, buybackMode: p, crossPick: g, accent: ee }) {
	let _ = c(), v = /* @__PURE__ */ new Set();
	if (t != null && n != null) for (let r = 0; r < 96; r++) vn(e, t, r, n) && v.add(r);
	let y = e.cargoPieces, b = e.cargo.filter(Boolean).length;
	return /* @__PURE__ */ h("div", {
		className: "tend-cargo-page flex h-full min-h-0 flex-col gap-2 overflow-y-auto p-2",
		children: [
			/* @__PURE__ */ h("div", {
				className: "tend-scene",
				children: [/* @__PURE__ */ m("img", {
					src: Nt.cargo,
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ h("div", {
					className: "tend-scene-title",
					children: [_("games.tend.cargoTitle"), /* @__PURE__ */ m("span", {
						className: "tend-scene-subtitle",
						children: _("games.tend.cargoLabel")
					})]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "tend-sheet-section",
				children: [
					/* @__PURE__ */ h("div", {
						className: "flex min-h-11 items-center gap-2",
						children: [
							/* @__PURE__ */ h("p", {
								className: "font-mono text-xs font-black tabular-nums",
								children: [
									b,
									" / ",
									96
								]
							}),
							t != null && /* @__PURE__ */ m("svg", {
								width: "44",
								height: "44",
								viewBox: "0 0 44 44",
								role: "img",
								"aria-label": _(Bt[t]),
								children: _n(t, 0, n ?? 0).map((e) => /* @__PURE__ */ m("rect", {
									x: 4 + e % 12 * 12,
									y: 4 + Math.floor(e / 12) * 12,
									width: "11",
									height: "11",
									rx: "2",
									fill: "var(--color-emerald-200)",
									stroke: "var(--color-ink)"
								}, e))
							}),
							t != null && i && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: i,
								className: "btn-quiet ml-auto min-h-11 px-2 text-xs font-black",
								children: ["⟳ ", _("games.tend.rotateCargo")]
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "tend-grid-scroll",
						children: /* @__PURE__ */ h("svg", {
							viewBox: `-14 -2 ${12 * $ + 16} ${8 * $ + 16}`,
							className: "tend-cargo-grid",
							"data-active": v.size > 0,
							role: "group",
							"aria-label": _("games.tend.cargoTitle"),
							children: [
								[4, 8].map((e, t) => /* @__PURE__ */ m("line", {
									x1: e * $,
									y1: 0,
									x2: e * $,
									y2: 8 * $,
									stroke: yn[t],
									strokeWidth: 2.5
								}, e)),
								e.cargo.map((e, t) => {
									let n = Math.floor(t / 12), i = t % 12 * $, a = n * $, o = v.has(t);
									return /* @__PURE__ */ h("g", {
										onClick: o ? () => r?.(t) : void 0,
										className: o ? "cursor-pointer" : void 0,
										children: [/* @__PURE__ */ m("rect", {
											x: i + .5,
											y: a + .5,
											width: 25,
											height: 25,
											fill: o ? "var(--color-emerald-100)" : e ? "var(--color-sky-100)" : "var(--color-surface)",
											stroke: "var(--color-ink)",
											strokeOpacity: o ? .55 : .3,
											strokeWidth: o ? 1 : .7
										}), o && /* @__PURE__ */ m("circle", {
											cx: i + $ / 2,
											cy: a + $ / 2,
											r: "2",
											fill: ee
										})]
									}, t);
								}),
								y.map(({ good: e, cells: t }, n) => {
									let r = t.map((e) => Math.floor(e / 12)), i = t.map((e) => e % 12), a = Math.min(...i) * $, o = Math.min(...r) * $, s = (Math.max(...i) - Math.min(...i) + 1) * $, c = (Math.max(...r) - Math.min(...r) + 1) * $, l = Ft(e);
									return /* @__PURE__ */ h("g", {
										pointerEvents: "none",
										children: [/* @__PURE__ */ m("clipPath", {
											id: `tend-cargo-piece-${n}`,
											children: t.map((e) => /* @__PURE__ */ m("rect", {
												x: e % 12 * $ + 2,
												y: Math.floor(e / 12) * $ + 2,
												width: 22,
												height: 22,
												rx: "3"
											}, e))
										}), l ? /* @__PURE__ */ m("image", {
											href: l,
											x: a + 2,
											y: o + 2,
											width: s - 4,
											height: c - 4,
											preserveAspectRatio: "xMidYMid meet",
											clipPath: `url(#tend-cargo-piece-${n})`
										}) : /* @__PURE__ */ m("text", {
											x: a + s / 2,
											y: o + c / 2 + 4,
											textAnchor: "middle",
											fontSize: "12",
											fontWeight: "900",
											fill: "var(--color-violet-700)",
											children: "✦"
										})]
									}, n);
								}),
								e.cargoRowsDone.map((e, t) => /* @__PURE__ */ m("text", {
									x: -8,
									y: t * $ + $ / 2 + 3,
									textAnchor: "middle",
									fontSize: 9,
									fill: e ? "#059669" : "#cbd5e1",
									children: nn(re[t])
								}, t)),
								e.cargoColsDone.map((e, t) => /* @__PURE__ */ m("text", {
									x: t * $ + $ / 2,
									y: 8 * $ + 10,
									textAnchor: "middle",
									fontSize: 8,
									fill: e ? "#059669" : "#e2e8f0",
									children: "✓"
								}, t))
							]
						})
					}),
					/* @__PURE__ */ m("div", {
						className: "grid grid-cols-3 gap-0.5 text-center text-[10px] font-black",
						children: ne.map((e, t) => /* @__PURE__ */ h("div", {
							className: "rounded-b border border-ink/30 bg-sky-100 px-1 py-1",
							style: { borderTop: `3px solid ${yn[t]}` },
							children: [
								_("games.tend.stallN", { n: t + 1 }),
								" · ",
								_(gn[e.cat]),
								" ",
								e.pts === 0 ? "0" : e.pts === 2 ? "+2" : "+1"
							]
						}, t))
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "tend-cargo-projects",
				children: [
					/* @__PURE__ */ h("div", {
						className: "flex flex-col gap-1",
						children: [
							/* @__PURE__ */ m("button", {
								type: "button",
								disabled: e.internUsed || a === null || e.coins < 3,
								onClick: u,
								className: `min-h-9 rounded-md border-2 px-2 text-left text-[10px] font-black ${e.internUsed ? "border-ink/20 bg-slate-300 line-through" : "border-ink/30 bg-surface disabled:opacity-40"}`,
								children: _("games.tend.internTitle")
							}),
							/* @__PURE__ */ h("div", {
								className: "rounded-md border border-ink/20 bg-surface p-1",
								children: [/* @__PURE__ */ m("p", {
									className: "text-[9px] font-black opacity-70",
									children: _("games.tend.explorerTitle")
								}), /* @__PURE__ */ h("div", {
									className: "flex items-center gap-1",
									children: [
										le.map((t, n) => /* @__PURE__ */ m("span", {
											className: e.explorerPaid[n] ? "opacity-40 line-through" : "",
											children: /* @__PURE__ */ m(Y, {
												good: t,
												size: "xs"
											})
										}, n)),
										e.explorerPaid.every(Boolean) && !e.explorerUsed && /* @__PURE__ */ m("span", {
											className: "text-[9px] font-black text-amber-700",
											children: _("games.tend.explorerReady")
										}),
										e.explorerUsed && /* @__PURE__ */ h("span", {
											className: "text-[9px] font-black text-emerald-700",
											children: [
												"✓",
												e.badgeDoubled ? _(Vt[e.badgeDoubled]) : "",
												_("games.tend.doubled")
											]
										})
									]
								})]
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								disabled: e.buybackUsed || a === null || e.coins < 3,
								onClick: () => f?.("", -1, -1),
								className: `min-h-9 rounded-md border-2 px-2 text-left text-[10px] font-black ${e.buybackUsed ? "border-ink/20 bg-slate-300 line-through" : p ? "border-ink text-white" : "border-ink/30 bg-surface disabled:opacity-40"}`,
								style: p ? { background: ee } : void 0,
								children: _("games.tend.buybackTitle")
							})
						]
					}),
					/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("p", {
						className: "text-[10px] font-black opacity-70",
						children: _("games.tend.purchaseTitle")
					}), /* @__PURE__ */ m("div", {
						className: "grid grid-cols-3 gap-1",
						children: ue.map((t, n) => /* @__PURE__ */ h("button", {
							type: "button",
							disabled: e.purchaseUsed[n] || a === null || e.coins < t.cost,
							onClick: () => l?.(n),
							className: `flex min-h-9 items-center justify-center gap-1 rounded-md border-2 text-[10px] font-black ${e.purchaseUsed[n] ? "border-ink/20 bg-slate-300 line-through" : "border-ink/30 bg-surface disabled:opacity-40"}`,
							children: [/* @__PURE__ */ m(Y, {
								good: t.good,
								size: "xs"
							}), /* @__PURE__ */ h("span", { children: ["🪙", t.cost] })]
						}, n))
					})] }),
					/* @__PURE__ */ m("div", {
						className: "flex flex-col gap-1.5",
						children: N.map((t) => {
							let n = e.badges[t.id].filter((e) => e.every(Boolean)).length >= 2, r = e.badgeDoubled === t.id, i = e.explorerPaid.every(Boolean) && !e.explorerUsed && !e.badgeDoubled && n;
							return /* @__PURE__ */ h("div", {
								className: `rounded-md border-2 p-1 ${n ? "border-violet-500 bg-violet-50" : "border-ink/20 bg-surface"}`,
								children: [/* @__PURE__ */ h("div", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ m("span", {
											className: "text-[10px] font-black",
											children: _(Vt[t.id])
										}),
										/* @__PURE__ */ m("span", {
											className: "text-[9px] font-bold text-violet-700",
											children: _("games.tend.badgeVp", { n: r ? t.vp * 2 : t.vp })
										}),
										i && /* @__PURE__ */ h("button", {
											type: "button",
											onClick: () => d?.(t.id),
											className: "min-h-9 rounded-md border-2 border-amber-500 bg-amber-200 px-1.5 text-[9px] font-black",
											children: ["✦", _("games.tend.doubled")]
										})
									]
								}), /* @__PURE__ */ m(Z, {
									rows: t.rows.map((e) => e.cost),
									paid: e.badges[t.id],
									mode: g && g.projects.includes(t.id) || p ? "any" : a,
									good: o,
									onTap: (n, r) => {
										if (g && g.projects.includes(t.id) && !e.badges[t.id][n][r]) {
											g.onPick(t.id, n, r);
											return;
										}
										if (p) {
											f?.(t.id, n, r);
											return;
										}
										s?.({
											area: "badge",
											row: n,
											slot: r,
											id: t.id
										});
									}
								})]
							}, t.id);
						})
					}),
					/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("p", {
						className: "text-[10px] font-black opacity-70",
						children: _("games.tend.sellTable")
					}), /* @__PURE__ */ m("div", {
						className: "flex flex-wrap gap-1",
						children: Object.keys(S).filter((e) => Kt(e) > 0).map((e) => /* @__PURE__ */ h("span", {
							className: "flex items-center gap-0.5 rounded bg-surface px-1 text-[9px] font-bold",
							children: [
								/* @__PURE__ */ m(Y, {
									good: e,
									size: "xs"
								}),
								"🪙",
								Kt(e)
							]
						}, e))
					})] })
				]
			})
		]
	});
}
//#endregion
//#region src/games/tend/scratch-view.tsx
var xn = Bt, Sn = {
	chop: "🪓",
	chopGold: "🪙",
	chopUpgraded: "🪓",
	mine: "⛏️",
	mineGold: "🪙",
	mineUpgraded: "⛏️"
}, Cn = {
	chop: "+1",
	chopGold: "+1🪙",
	chopUpgraded: "+2",
	mine: "+1",
	mineGold: "+1🪙",
	mineUpgraded: "+2"
}, wn = 44, Tn = 40;
function En(e, t) {
	let n = /* @__PURE__ */ new Set(), r = e.scratched.some(Boolean);
	for (let i = 0; i < e.scratched.length; i++) {
		if (e.scratched[i]) continue;
		let a = Math.floor(i / 7);
		if (a >= 4 && t < 2) continue;
		if (!r) {
			a === 0 && n.add(i);
			continue;
		}
		if (a === 0) {
			n.add(i);
			continue;
		}
		let o = a, s = i % 7;
		[
			[-1, 0],
			[1, 0],
			[0, -1],
			[0, 1]
		].some(([t, n]) => {
			let r = o + t, i = s + n;
			return r >= 0 && r < 8 && i >= 0 && i < 7 && e.scratched[r * 7 + i];
		}) && n.add(i);
	}
	return n;
}
function Dn({ kind: e, card: t, eligible: n, onPick: r, accent: i }) {
	let a = 7 * wn, o = 8 * Tn;
	return /* @__PURE__ */ h("svg", {
		viewBox: `0 0 ${a} ${o}`,
		className: "h-auto w-full",
		role: "group",
		children: [
			/* @__PURE__ */ m("defs", { children: /* @__PURE__ */ m("pattern", {
				id: `tend-foil-${e}`,
				width: "8",
				height: "8",
				patternUnits: "userSpaceOnUse",
				children: /* @__PURE__ */ m("path", {
					d: "M0 8L8 0",
					stroke: "var(--color-slate-500)",
					strokeOpacity: ".55",
					strokeWidth: "1"
				})
			}) }),
			/* @__PURE__ */ m("image", {
				href: Nt[e],
				x: "0",
				y: "0",
				width: a,
				height: o,
				preserveAspectRatio: "xMidYMid slice",
				opacity: ".58"
			}),
			t.cells.map((a, o) => {
				let s = Math.floor(o / 7), c = o % 7 * wn, l = s * Tn, u = t.scratched[o], d = n?.has(o) ?? !1, f = a && [
					"chop",
					"chopGold",
					"chopUpgraded",
					"mine",
					"mineGold",
					"mineUpgraded"
				].includes(a.content);
				return /* @__PURE__ */ h("g", {
					onClick: d ? () => r?.(o) : void 0,
					className: d ? "cursor-pointer" : void 0,
					children: [
						/* @__PURE__ */ m("rect", {
							x: c + 1,
							y: l + 1,
							width: 42,
							height: 38,
							rx: 4,
							fill: u ? f ? "var(--color-amber-100)" : "var(--color-paper)" : "var(--color-slate-300)",
							fillOpacity: u ? .92 : .72,
							stroke: d ? i : "var(--color-slate-600)",
							strokeWidth: d ? 3 : 1
						}),
						!u && /* @__PURE__ */ m("rect", {
							x: c + 3,
							y: l + 3,
							width: 38,
							height: 34,
							rx: "3",
							fill: `url(#tend-foil-${e})`
						}),
						s === 4 && /* @__PURE__ */ m("rect", {
							x: c,
							y: l - 2,
							width: wn,
							height: 2,
							fill: "#64748b"
						}),
						!u && /* @__PURE__ */ m("text", {
							x: c + wn / 2,
							y: l + Tn / 2 + 4,
							textAnchor: "middle",
							fontSize: 14,
							fill: "var(--color-slate-600)",
							children: "·"
						}),
						u && a && (f ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("text", {
							x: c + wn / 2,
							y: l + Tn / 2 - 2,
							textAnchor: "middle",
							fontSize: 13,
							children: Sn[a.content]
						}), /* @__PURE__ */ m("text", {
							x: c + wn / 2,
							y: l + Tn / 2 + 12,
							textAnchor: "middle",
							fontSize: 10,
							fontWeight: 900,
							fill: "#78350f",
							children: Cn[a.content]
						})] }) : Ft(a.content) ? /* @__PURE__ */ m("image", {
							href: Ft(a.content),
							x: c + 6,
							y: l + 3,
							width: 32,
							height: 34,
							preserveAspectRatio: "xMidYMid meet"
						}) : /* @__PURE__ */ m("text", {
							x: c + wn / 2,
							y: l + Tn / 2 + 5,
							textAnchor: "middle",
							fontSize: "17",
							fill: "var(--color-violet-700)",
							children: "✦"
						})),
						u && a?.upgrade && /* @__PURE__ */ m("text", {
							x: c + wn - 8,
							y: l + 12,
							fontSize: 11,
							fill: "#dc2626",
							children: "▲"
						})
					]
				}, o);
			})
		]
	});
}
function On(e, t) {
	let n = /* @__PURE__ */ new Set();
	if (e.picks.length >= e.maxPicks) return n;
	for (let r = 0; r < 25; r++) {
		let i = Math.floor(r / 5), a = r % 5;
		if ((e.dice[0] === 1 || i === e.dice[0] - 1) && (e.dice[1] === 1 || a === e.dice[1] - 1)) for (let r = 0; r < 25; r++) {
			if (e.picks.includes(r)) continue;
			let o = Math.floor(r / 5), s = r % 5;
			(t === 2 ? Math.abs(o - i) <= 1 && Math.abs(s - a) <= 1 : t === 1 ? Math.abs(o - i) + Math.abs(s - a) <= 1 : o === i && s === a) && n.add(r);
		}
	}
	return n;
}
function kn(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n = 0; n < 25; n++) {
		let r = Math.floor(n / 5), i = n % 5;
		(e[0] === 1 || r === e[0] - 1) && (e[1] === 1 || i === e[1] - 1) && t.add(n);
	}
	return t;
}
var An = 52;
function jn({ spot: e, fish: t, geodeDice: n, eligible: r, onPick: i, onSkipPick: a, accent: o }) {
	let s = c(), l = P[e], u = 5 * An, d = 5 * An, f = t?.dice ?? n;
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col items-center gap-1",
		children: [
			f && /* @__PURE__ */ h("div", {
				className: "flex w-full items-center justify-around rounded-lg border border-ink/40 bg-sky-100 px-1 py-1 font-mono text-xs font-black tabular-nums",
				"aria-label": s(t ? "games.tend.fishDice" : "games.tend.geodeRoll", {
					a: f[0],
					b: f[1]
				}),
				children: [
					/* @__PURE__ */ h("span", {
						className: "flex items-center gap-1",
						children: [
							s("games.tend.whiteDie"),
							" ",
							/* @__PURE__ */ m("b", {
								className: "flex size-8 items-center justify-center rounded border-2 border-ink bg-surface text-lg",
								children: f[0]
							})
						]
					}),
					/* @__PURE__ */ h("span", {
						className: "flex items-center gap-1",
						children: [
							s("games.tend.blackDie"),
							" ",
							/* @__PURE__ */ m("b", {
								className: "flex size-8 items-center justify-center rounded border-2 border-ink bg-slate-700 text-lg text-white",
								children: f[1]
							})
						]
					}),
					t && /* @__PURE__ */ h("span", { children: [
						t.picks.length,
						"/",
						t.maxPicks
					] })
				]
			}),
			/* @__PURE__ */ h("svg", {
				viewBox: `0 0 ${u} ${d}`,
				className: "h-auto w-full max-w-72",
				role: "group",
				children: [/* @__PURE__ */ m("image", {
					href: Rt(e),
					x: "0",
					y: "0",
					width: u,
					height: d,
					preserveAspectRatio: "xMidYMid slice"
				}), l.map((e, n) => {
					let a = Math.floor(n / 5), c = n % 5 * An, l = a * An, u = r?.has(n) ?? !1, d = t?.picks.includes(n) ?? !1;
					return /* @__PURE__ */ h("g", {
						onClick: u ? () => i?.(n) : void 0,
						className: u ? "cursor-pointer" : void 0,
						children: [
							/* @__PURE__ */ m("rect", {
								x: c + 1.5,
								y: l + 1.5,
								width: 49,
								height: 49,
								rx: 6,
								fill: d ? "var(--color-slate-200)" : u ? "var(--color-emerald-100)" : "var(--color-surface)",
								fillOpacity: d || u ? .8 : .48,
								stroke: u ? o : "var(--color-ink)",
								strokeOpacity: u ? 1 : .5,
								strokeWidth: u ? 3.5 : 1
							}),
							e && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("title", { children: s(xn[e]) }), Ft(e) ? /* @__PURE__ */ m("image", {
								href: Ft(e),
								x: c + 5,
								y: l + 5,
								width: 42,
								height: 42,
								preserveAspectRatio: "xMidYMid meet",
								opacity: d ? .35 : 1
							}) : /* @__PURE__ */ m("text", {
								x: c + An / 2,
								y: l + An / 2 + 6,
								textAnchor: "middle",
								fontSize: "19",
								fill: "var(--color-violet-700)",
								children: "✦"
							})] }),
							d && /* @__PURE__ */ m("text", {
								x: c + An / 2,
								y: l + An / 2 + 5,
								textAnchor: "middle",
								fontSize: 16,
								fill: "#64748b",
								children: "✕"
							})
						]
					}, n);
				})]
			}),
			t && a && t.picks.length < t.maxPicks && /* @__PURE__ */ m("button", {
				type: "button",
				onClick: a,
				className: "btn-quiet min-h-9 px-3 text-xs font-bold",
				children: s("games.tend.skip")
			})
		]
	});
}
//#endregion
//#region src/games/tend/neighbor-view.tsx
function Mn({ rewards: e, pos: t }) {
	return /* @__PURE__ */ m("div", {
		className: "flex gap-0.5",
		children: e.map((e, n) => /* @__PURE__ */ m("span", {
			className: `flex size-7 items-center justify-center rounded ${n < t ? "bg-slate-300 opacity-60" : "border border-ink/30 bg-surface"}`,
			children: /* @__PURE__ */ m(qt, {
				good: e,
				size: 21
			})
		}, n))
	});
}
function Nn({ idx: e, small: t, onClick: n, selected: r, label: i }) {
	let a = c(), o = F[e];
	return /* @__PURE__ */ h("button", {
		type: "button",
		onClick: n,
		disabled: !n,
		className: "tend-neighbor-card",
		"data-small": !!t,
		"data-selected": !!r,
		children: [
			/* @__PURE__ */ m("span", {
				className: `min-h-7 border-b border-ink/30 px-1 py-1 text-[10px] font-black ${o.bonus === 2 ? "bg-amber-200" : "bg-sky-200"}`,
				children: i ?? "✦"
			}),
			/* @__PURE__ */ m("span", {
				className: "flex flex-1 flex-wrap items-center justify-center gap-1 px-1",
				children: o.goods.map((e, t) => /* @__PURE__ */ h("span", {
					className: "flex flex-col items-center gap-0.5",
					children: [/* @__PURE__ */ m(qt, {
						good: e,
						size: o.goods.length > 1 ? 35 : 51
					}), /* @__PURE__ */ m("span", {
						className: "text-[10px] font-black leading-none",
						children: a(Bt[e])
					})]
				}, t))
			}),
			/* @__PURE__ */ h("span", {
				className: "mx-1 mb-1 rounded border border-ink/30 bg-emerald-100 py-1 font-mono text-xs font-black tabular-nums",
				children: ["+", o.bonus]
			})
		]
	});
}
function Pn({ p: e, order: t, myRid: n, members: r, phase: i, setupHand: a, nbDraws: s, giftSide: l, onGiftSide: u, disposeGood: d, onPickSetup: f, onResolveGift: p, onRedraw: g, onCycle: ee, onDone: _, doneDisabled: v }) {
	let y = c(), [b, te] = o({
		left: null,
		right: null
	}), x = t.indexOf(n), S = t.length > 1 ? r.find((e) => e.rid === t[(x - 1 + t.length) % t.length])?.name ?? "" : "", C = t.length > 1 ? r.find((e) => e.rid === t[(x + 1) % t.length])?.name ?? "" : "";
	if (i === "setupCards" && a) {
		let e = b.left !== null && b.right !== null;
		return /* @__PURE__ */ h("div", {
			className: "tend-neighbor-page flex h-full min-h-0 flex-col gap-2 overflow-y-auto p-2",
			children: [
				/* @__PURE__ */ m("p", {
					className: "text-sm font-black",
					children: y("games.tend.setupPrompt")
				}),
				/* @__PURE__ */ m("div", {
					className: "flex flex-wrap gap-2",
					children: a.map((e, t) => {
						let n = b.left === t, r = b.right === t;
						return /* @__PURE__ */ m(Nn, {
							idx: e,
							selected: n || r,
							label: n ? y("games.tend.setupLeft") : r ? y("games.tend.setupRight") : void 0,
							onClick: () => {
								n ? te({
									...b,
									left: null
								}) : r ? te({
									...b,
									right: null
								}) : b.left === null ? te({
									...b,
									left: t
								}) : b.right === null && te({
									...b,
									right: t
								});
							}
						}, t);
					})
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					disabled: !e,
					onClick: () => f?.(b.left, b.right),
					className: "btn-base min-h-12 border-3 border-ink text-base font-black text-white disabled:opacity-40",
					style: { background: "#7c3aed" },
					children: y("games.tend.confirm")
				})
			]
		});
	}
	return /* @__PURE__ */ h("div", {
		className: "tend-neighbor-page flex h-full min-h-0 flex-col gap-2 overflow-y-auto p-2",
		children: [
			e.nbIncoming.length > 0 && /* @__PURE__ */ h("div", {
				className: "tend-sheet-section bg-violet-50",
				children: [/* @__PURE__ */ h("p", {
					className: "text-[10px] font-black text-rose-700",
					children: ["🎁×", e.nbIncoming.length]
				}), /* @__PURE__ */ m("div", {
					className: "flex flex-col gap-1.5",
					children: e.nbIncoming.map((e, n) => {
						let r = F[e];
						return /* @__PURE__ */ h("div", {
							className: "flex items-center gap-1.5 rounded-md bg-surface p-1",
							children: [/* @__PURE__ */ m(Nn, {
								idx: e,
								small: !0
							}), /* @__PURE__ */ h("div", {
								className: "flex min-w-0 flex-1 flex-wrap gap-1",
								children: [r.goods.map((e) => /* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => p?.(n, !0, e),
									className: "btn-base min-h-11 border-2 border-ink px-1.5 text-[10px] font-black text-white",
									style: { background: "var(--tend-accent)" },
									children: /* @__PURE__ */ m(Y, {
										good: e,
										size: "xs"
									})
								}, e)), t.length > 1 && /* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => p?.(n, !1),
									className: "btn-quiet min-h-11 px-1.5 text-[10px] font-bold",
									children: y("games.tend.giftPass")
								})]
							})]
						}, n);
					})
				})]
			}),
			["left", "right"].map((t) => {
				let n = e.nbHand[t], r = s?.[t], a = t === "left" ? S : C;
				return /* @__PURE__ */ h("div", {
					className: "tend-sheet-section",
					children: [/* @__PURE__ */ h("p", {
						className: "mb-1 text-xs font-black",
						children: [y(t === "left" ? "games.tend.setupLeft" : "games.tend.setupRight"), a ? ` → ${a}` : ""]
					}), r ? /* @__PURE__ */ h("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ m("span", {
							className: "text-[9px] font-bold opacity-70",
							children: y("games.tend.redrawPrompt", { side: y(t === "left" ? "games.tend.nbTrackLeft" : "games.tend.nbTrackRight") })
						}), r.map((e, n) => /* @__PURE__ */ m(Nn, {
							idx: e,
							small: !0,
							onClick: () => g?.(t, n)
						}, n))]
					}) : n === null ? /* @__PURE__ */ m("p", {
						className: "text-[10px] opacity-50",
						children: "—"
					}) : /* @__PURE__ */ h("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ m(Nn, {
							idx: n,
							small: !0,
							selected: l === t,
							onClick: l !== void 0 && d && F[n].goods.includes(d) ? () => u?.(t) : void 0
						}), i === "neighbor" && !e.nbCycled[t] && /* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => ee?.(t),
							className: "btn-quiet min-h-11 px-2 text-[10px] font-bold",
							children: y("games.tend.cycleCard")
						})]
					})]
				}, t);
			}),
			/* @__PURE__ */ h("div", {
				className: "flex flex-col gap-1.5",
				children: [/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ h("p", {
					className: "text-[10px] font-black opacity-70",
					children: [
						y("games.tend.nbTrackLeft"),
						" ",
						e.nbTrack.left,
						"/",
						8
					]
				}), /* @__PURE__ */ m(Mn, {
					rewards: T,
					pos: e.nbTrack.left
				})] }), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ h("p", {
					className: "text-[10px] font-black opacity-70",
					children: [
						y("games.tend.nbTrackRight"),
						" ",
						e.nbTrack.right,
						"/",
						8
					]
				}), /* @__PURE__ */ m(Mn, {
					rewards: E,
					pos: e.nbTrack.right
				})] })]
			}),
			(i === "neighbor" || i === "finalGifts") && _ && /* @__PURE__ */ m("button", {
				type: "button",
				disabled: v,
				onClick: _,
				className: "btn-base min-h-12 border-3 border-ink text-base font-black text-white disabled:opacity-40",
				style: { background: "#7c3aed" },
				children: y("games.tend.neighborDone")
			})
		]
	});
}
//#endregion
//#region src/games/tend/view-player.tsx
var Fn = {
	tasks: "games.tend.tabTasks",
	farm: "games.tend.tabFarm",
	cargo: "games.tend.tabCargo",
	fish: "games.tend.tabExplore",
	neighbor: "games.tend.tabNeighbor"
}, In = (e) => e.execStack[e.execStack.length - 1] ?? null, Ln = (e) => e.geode !== null || e.fish !== null || e.rewardPick !== null, Rn = (e) => se.findIndex((t, n) => n > 0 && (t.cost[0] === e || ce[n] === e)), zn = (e) => e.rod2.every((e) => e.every(Boolean)) ? 2 : +!!e.rod1.every((e) => e.every(Boolean));
function Bn(e) {
	let t = e.public, n = e.private ?? {};
	return /* @__PURE__ */ m(Vn, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Vn({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let s = c(), [d, g] = o("farm"), [ee, _] = o(r), [v, y] = o(null), [b, te] = o(0), [x, S] = o(null), [C, ne] = o(!1), [re, ie] = o([]), w = e.players[r], T = e.players[ee] ?? w, E = ee === r && e.phase !== "done", ae = (e) => n.find((t) => t.rid === e)?.name ?? e, k = In(w), A = w.disposeQueue[0], j = A && A !== "geode" ? A : null, M = Ln(w), oe = `${e.phase}|${w.execStack.length}|${w.disposeQueue.length}|${w.rewardPick?.kind ?? ""}|${+!!w.geode}|${+!!w.fish}|${w.picked.length}|${w.phaseDone}`, [ce, le] = o("");
	ce !== oe && (le(oe), y(null), S(null), ne(!1), te(0), e.phase === "setupCards" || e.phase === "neighbor" || e.phase === "finalGifts" ? (g("neighbor"), _(r)) : w.geode || w.fish ? (g("fish"), _(r)) : k && !k.task ? g("tasks") : k?.task === "chop" || k?.task === "mine" ? (g("fish"), _(r)) : k?.task === "tend" || k?.task === "fish" ? (g(k.task === "tend" ? "farm" : "fish"), _(r)) : e.phase === "task" && w.picked.length < 2 && !w.phaseDone && (g("tasks"), _(r)));
	let ue = w.picked.length, [N, de] = o(-1);
	N !== ue && (de(ue), ie([]));
	let P = (e) => a(e), fe = (e) => {
		if (ne(!1), e === "cargo") S("cargo"), g("cargo");
		else if (e === "cost") S("cost"), y({ kind: "disposeCost" });
		else if (e === "gift") S("gift"), g("neighbor");
		else {
			S(null);
			let e = Rn(j ?? ""), t = e > 0 ? se[e] : null;
			y({
				kind: "disposeGrounds",
				sub: t && t.till > 0 ? "till" : "fence",
				till: [],
				fences: [],
				tillN: t?.till ?? 0,
				fenceN: t?.fence ?? 0
			}), g("farm");
		}
	}, { hiCells: pe, hiEdges: me } = i(() => {
		let e = /* @__PURE__ */ new Set(), t = /* @__PURE__ */ new Set();
		if (!E) return {
			hiCells: e,
			hiEdges: t
		};
		let n = /* @__PURE__ */ new Set();
		for (let e of w.crops) G(e.anchor, D[e.crop].size)?.forEach((e) => n.add(e));
		for (let e of w.animals) G(e.anchor, O[e.animal].size)?.forEach((e) => n.add(e));
		for (let e of w.trellises) G(e, 2)?.forEach((e) => n.add(e));
		if (v?.kind === "till" || v?.kind === "grounds" && v.sub === "till" || v?.kind === "disposeGrounds" && v.sub === "till") for (let t = 0; t < 132; t++) W(H(t), U(t)) && !w.tilled.includes(t) && !n.has(t) && e.add(t);
		if (v?.kind === "plant") {
			let t = D[v.crop];
			for (let r = 0; r < 132; r++) {
				let i = G(r, t.size);
				i && (!t.trellis || w.trellises.includes(r)) && i.every((e) => w.tilled.includes(e) && !n.has(e)) && e.add(r);
			}
		}
		if (v?.kind === "water" && w.crops.forEach((t) => e.add(t.anchor)), v?.kind === "animal") {
			let t = O[v.animal];
			for (let r = 0; r < 132; r++) {
				let i = G(r, t.size);
				i && !i.some((e) => n.has(e)) && We(i, w.fences) && e.add(r);
			}
		}
		if (v?.kind === "trellis") for (let t = 0; t < 132; t++) {
			let r = G(t, 2);
			r && r.every((e) => !n.has(e)) && e.add(t);
		}
		if ((v?.kind === "grounds" || v?.kind === "disposeGrounds") && v.sub === "fence") for (let e of $t) w.fences.includes(e) || t.add(e);
		return {
			hiCells: e,
			hiEdges: t
		};
	}, [
		E,
		w,
		v
	]), he = (e) => {
		if (E) {
			if (v?.kind === "till") {
				let t = v.cells.includes(e) ? v.cells.filter((t) => t !== e) : v.cells.length < 6 ? [...v.cells, e] : v.cells;
				y({
					...v,
					cells: t
				});
				return;
			}
			if (v?.kind === "grounds" && v.sub === "till") {
				let t = v.till.includes(e) ? v.till.filter((t) => t !== e) : [...v.till, e];
				y({
					...v,
					till: t
				});
				return;
			}
			if (v?.kind === "disposeGrounds" && v.sub === "till") {
				let t = v.till.includes(e) ? v.till.filter((t) => t !== e) : [...v.till, e];
				y({
					...v,
					till: t
				});
				return;
			}
			if (v?.kind === "plant") {
				P({
					type: "tendPlant",
					crop: v.crop,
					anchor: e
				}), y(null);
				return;
			}
			if (v?.kind === "water") {
				let t = w.crops.findIndex((t) => G(t.anchor, D[t.crop].size)?.includes(e));
				t >= 0 && P({
					type: "tendWater",
					idx: t
				});
				return;
			}
			if (v?.kind === "animal") {
				P({
					type: "placeAnimal",
					animal: v.animal,
					anchor: e
				}), y(null);
				return;
			}
			if (v?.kind === "trellis") {
				P({
					type: "placeTrellis",
					anchor: e
				}), y(null);
				return;
			}
		}
	}, F = (e) => {
		if (!E || !v || v.kind !== "grounds" && v.kind !== "disposeGrounds" || v.sub !== "fence") return;
		let t = v.fences.includes(e) ? v.fences.filter((t) => t !== e) : [...v.fences, e];
		y({
			...v,
			fences: t
		});
	}, ge = (e) => {
		if (E) {
			if (v?.kind === "disposeCost") {
				P({
					type: "disposeCost",
					area: e.area,
					row: e.row,
					slot: e.slot,
					...e.id ? { id: e.id } : {}
				}), y(null), S(null);
				return;
			}
			if (e.area === "energy") {
				P({
					type: "pay",
					area: "energy",
					slot: e.slot
				});
				return;
			}
			P({
				type: "pay",
				area: e.area,
				row: e.row,
				slot: e.slot,
				...e.id ? { id: e.id } : {}
			});
		}
	}, _e = (e) => P({
		type: "chooseTask",
		task: e
	}), ve = (e) => {
		g("farm"), _(r), y(e === "till" ? {
			kind: "till",
			cells: []
		} : e === "water" ? { kind: "water" } : {
			kind: "plant",
			crop: "pineapple"
		});
	}, ye = e.phase === "setupCards" ? w.phaseDone || !t.setupHand ? {
		tone: "info",
		text: s("games.tend.waitingNeighbor", { name: "…" })
	} : {
		tone: "accent",
		text: s("games.tend.setupPrompt")
	} : e.phase === "neighbor" || e.phase === "finalGifts" ? w.phaseDone ? {
		tone: "info",
		text: s("games.tend.waitingNeighbor", { name: "…" })
	} : {
		tone: "accent",
		text: s("games.tend.phaseNeighbor")
	} : e.phase === "task" ? w.phaseDone ? {
		tone: "info",
		text: s("games.tend.waitingTask", { name: "…" })
	} : w.rewardPick ? {
		tone: "warn",
		text: s("games.tend.pickOne")
	} : w.geode ? {
		tone: "warn",
		text: s("games.tend.geodePickCell")
	} : w.fish ? {
		tone: "warn",
		text: s("games.tend.fishPickCell")
	} : w.disposeQueue.length > 0 ? {
		tone: "warn",
		text: s("games.tend.queueLeft", { n: w.disposeQueue.length })
	} : k ? {
		tone: "accent",
		text: k.task ? `${nn(k.task)} ×${k.actions}` : s("games.tend.freeTaskPick")
	} : {
		tone: "accent",
		text: s("games.tend.pickTasks")
	} : {
		tone: "done",
		text: s("games.tend.phaseDone")
	}, be = `${s("games.tend.roundChip", { n: e.round })}/${e.totalRounds}`, xe = (e) => e === "woods" ? w.woods : w.mines, Se = (e) => !E || !k || k.task !== (e === "woods" ? "chop" : "mine") || M ? /* @__PURE__ */ new Set() : En(xe(e), k.actions), I = [
		"pond",
		"river",
		"lake",
		"grotto"
	], L = w.fish?.spot ?? null, R = zn(w), Ce = w.fish ? On(w.fish, R) : /* @__PURE__ */ new Set(), z = w.geode ? kn(w.geode) : /* @__PURE__ */ new Set(), B = w.rewardPick, we = /* @__PURE__ */ h("div", {
		className: "tend-actions",
		children: [
			E && B && /* @__PURE__ */ h(p, { children: [
				B.kind === "pick" && B.options.map((e, t) => /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => P({
						type: "pickReward",
						idx: t
					}),
					className: "btn-base min-h-11 shrink-0 border-2 border-ink px-2 text-white",
					style: { background: V.accent },
					children: /* @__PURE__ */ m(Y, {
						good: e === "geode" ? "geode" : e,
						size: "xs"
					})
				}, t)),
				B.kind === "choice" && B.options.map((e, t) => /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => P({
						type: "pickReward",
						idx: t
					}),
					className: "btn-base min-h-11 shrink-0 border-2 border-ink px-2 text-[10px] font-black text-white",
					style: { background: V.accent },
					children: /* @__PURE__ */ m(pn, { r: e })
				}, t)),
				B.kind === "crossGood" && /* @__PURE__ */ m("p", {
					className: "text-xs font-bold",
					children: s("games.tend.crossGoodPick")
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => P({ type: "skip" }),
					className: "btn-quiet min-h-11 shrink-0 px-2 text-xs font-bold",
					children: s("games.tend.skip")
				})
			] }),
			E && !B && A !== void 0 && !w.geode && !w.fish && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("span", {
					className: "shrink-0",
					children: /* @__PURE__ */ m(Y, { good: j ?? "geode" })
				}),
				j && Kt(j) > 0 && /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => P({ type: "disposeSell" }),
					className: "btn-base min-h-11 shrink-0 border-2 border-ink px-2 text-[10px] font-black text-white",
					style: { background: V.accent },
					children: s("games.tend.disposeSell", { n: Kt(j) })
				}),
				j && j !== "wood" && j !== "exoWood" && /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => fe("cargo"),
					className: `min-h-11 shrink-0 rounded-lg border-2 px-2 text-[10px] font-black ${x === "cargo" ? "border-ink text-white" : "border-ink/40 bg-surface"}`,
					style: x === "cargo" ? { background: V.accent } : void 0,
					children: s("games.tend.disposeCargo")
				}),
				j && /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => fe("cost"),
					className: `min-h-11 shrink-0 rounded-lg border-2 px-2 text-[10px] font-black ${x === "cost" ? "border-ink text-white" : "border-ink/40 bg-surface"}`,
					style: x === "cost" ? { background: V.accent } : void 0,
					children: s("games.tend.disposeCost")
				}),
				j && e.order.length > 0 && /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => fe("gift"),
					className: `min-h-11 shrink-0 rounded-lg border-2 px-2 text-[10px] font-black ${x === "gift" ? "border-ink text-white" : "border-ink/40 bg-surface"}`,
					style: x === "gift" ? { background: V.accent } : void 0,
					children: s("games.tend.disposeGift")
				}),
				j && Rn(j) > 0 && /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => fe("grounds"),
					className: "min-h-11 shrink-0 rounded-lg border-2 border-ink/40 bg-surface px-2 text-[10px] font-black",
					children: s("games.tend.disposeGrounds")
				})
			] }),
			E && !B && A === void 0 && k && !k.task && k.options !== null && !M && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", {
				className: "shrink-0 text-[10px] font-bold opacity-70",
				children: s("games.tend.freeTaskPick")
			}), (k.options.length > 0 ? k.options : [
				"tend",
				"fish",
				"chop",
				"mine"
			]).map((e) => /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => _e(e),
				className: "btn-base min-h-11 shrink-0 border-2 border-ink px-2.5 text-sm text-white",
				style: { background: V.accent },
				children: /* @__PURE__ */ m(an, {
					task: e,
					size: 28
				})
			}, e))] }),
			E && !B && A === void 0 && k?.task === "tend" && !M && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => ve("plant"),
					className: `min-h-11 shrink-0 rounded-lg border-2 px-2 text-[10px] font-black ${v?.kind === "plant" ? "border-ink text-white" : "border-ink/40 bg-surface"}`,
					style: v?.kind === "plant" ? { background: V.accent } : void 0,
					children: s("games.tend.tendPlant")
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => ve("water"),
					className: `min-h-11 shrink-0 rounded-lg border-2 px-2 text-[10px] font-black ${v?.kind === "water" ? "border-ink text-white" : "border-ink/40 bg-surface"}`,
					style: v?.kind === "water" ? { background: V.accent } : void 0,
					children: s("games.tend.tendWater")
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => ve("till"),
					className: `min-h-11 shrink-0 rounded-lg border-2 px-2 text-[10px] font-black ${v?.kind === "till" ? "border-ink text-white" : "border-ink/40 bg-surface"}`,
					style: v?.kind === "till" ? { background: V.accent } : void 0,
					children: s("games.tend.tendTill")
				}),
				v?.kind === "plant" && /* @__PURE__ */ m("div", {
					className: "flex shrink-0 gap-1",
					children: Object.keys(D).map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						onClick: () => y({
							kind: "plant",
							crop: e
						}),
						"aria-label": s(Bt[e]),
						className: `flex min-h-11 min-w-11 items-center justify-center rounded-lg border-2 px-1 text-xs ${v.crop === e ? "border-ink bg-amber-300" : "border-ink/30 bg-surface"}`,
						children: /* @__PURE__ */ m("img", {
							src: It(e),
							alt: "",
							width: "32",
							height: "32",
							className: "size-8 object-contain",
							draggable: !1
						})
					}, e))
				})
			] }),
			E && !B && A === void 0 && k?.task && !M && /* @__PURE__ */ h(p, { children: [!k.energyUsed && w.energyCharges.some((e) => e > 0) && /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => P({ type: "useEnergy" }),
				className: "btn-quiet min-h-11 shrink-0 px-2 text-[10px] font-black text-sky-700",
				children: ["⚡", s("games.tend.useEnergy")]
			}), k.actions >= 0 && /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => P({ type: "finishActions" }),
				className: "btn-quiet min-h-11 shrink-0 px-2 text-[10px] font-bold",
				children: s("games.tend.finishActions")
			})] }),
			E && (v?.kind === "till" || v?.kind === "grounds" || v?.kind === "disposeGrounds") && /* @__PURE__ */ h(p, { children: [
				(v.kind === "grounds" || v.kind === "disposeGrounds") && v.tillN > 0 && v.fenceN > 0 && /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => y({
						...v,
						sub: v.sub === "till" ? "fence" : "till"
					}),
					className: "btn-quiet min-h-11 shrink-0 px-2 text-[10px] font-black",
					children: v.sub === "till" ? "~" : "🚧"
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					disabled: v.kind === "till" ? v.cells.length !== 6 : v.sub === "till" ? v.till.length !== v.tillN : v.fences.length !== v.fenceN,
					onClick: () => {
						v.kind === "till" ? P({
							type: "tendTill",
							cells: v.cells
						}) : v.kind === "grounds" ? P({
							type: "groundsCoin",
							...v.sub === "till" ? { till: v.till } : { fences: v.fences }
						}) : P({
							type: "disposeGrounds",
							...v.sub === "till" ? { till: v.till } : { fences: v.fences }
						}), y(null);
					},
					className: "btn-base min-h-11 shrink-0 border-2 border-ink px-3 text-xs font-black text-white disabled:opacity-40",
					style: { background: V.accent },
					children: s("games.tend.confirm")
				}),
				/* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => y(null),
					className: "btn-quiet min-h-11 shrink-0 px-2 text-xs font-bold",
					children: s("games.tend.cancel")
				})
			] }),
			E && e.phase === "task" && !w.phaseDone && w.picked.length >= 2 && !k && A === void 0 && !M && /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => P({ type: "taskDone" }),
				className: "btn-base min-h-12 flex-1 border-3 border-ink text-sm font-black text-white",
				style: { background: V.accent },
				children: s("games.tend.taskDone")
			})
		]
	});
	return /* @__PURE__ */ m("div", {
		className: "tend-screen h-full min-h-0",
		children: /* @__PURE__ */ m(f, {
			adaptive: !0,
			className: "tend-adaptive",
			banner: /* @__PURE__ */ h("div", {
				className: "tend-header",
				children: [
					/* @__PURE__ */ m(l, {
						tone: ye.tone,
						text: ye.text,
						chip: be,
						accent: V.accent
					}),
					/* @__PURE__ */ m(u, {
						members: n.filter((t) => e.order.includes(t.rid)),
						myRid: r,
						variant: "plate",
						status: (t) => {
							let n = e.players[t];
							return n ? /* @__PURE__ */ h("span", {
								className: "flex items-center gap-1.5 font-mono tabular-nums",
								children: [/* @__PURE__ */ h("span", {
									className: "text-[10px] font-bold opacity-70",
									children: ["🪙", n.coins]
								}), e.finalScores && /* @__PURE__ */ m("span", {
									className: "text-base font-black",
									children: e.finalScores[t]
								})]
							}) : null;
						},
						action: (t) => e.players[t]?.phaseDone ? "done" : "pending",
						onPick: (e) => _(e),
						picked: (e) => e === ee
					}),
					/* @__PURE__ */ m("div", {
						className: "tend-tabs",
						role: "tablist",
						children: Object.keys(Fn).map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							role: "tab",
							"aria-selected": d === e,
							onClick: () => g(e),
							className: "tend-tab",
							children: s(Fn[e])
						}, e))
					})
				]
			}),
			actions: we,
			actionsHeight: "tend-actions-height h-16",
			scroll: !1,
			children: /* @__PURE__ */ h("div", {
				className: "tend-paper min-h-0 h-full overflow-hidden",
				children: [
					d === "tasks" && /* @__PURE__ */ h("div", {
						className: "tend-task-page flex h-full min-h-0 flex-col gap-2 overflow-y-auto p-2",
						children: [
							/* @__PURE__ */ m("div", {
								className: "flex flex-col gap-1",
								children: e.objectives.map((e, t) => /* @__PURE__ */ m(hn, {
									id: e,
									season: t + 1
								}, e))
							}),
							e.phase !== "done" && /* @__PURE__ */ m("p", {
								className: "text-[10px] font-black opacity-70",
								children: s("games.tend.pickTasks")
							}),
							e.phase !== "done" && /* @__PURE__ */ m("div", {
								className: "tend-task-row flex gap-1.5 overflow-x-auto pb-1",
								children: e.taskRow.map((t, n) => /* @__PURE__ */ m(mn, {
									cardId: t,
									selected: re.includes(n),
									disabled: !E || e.phase !== "task" || w.picked.length > 0 || w.phaseDone,
									onPick: () => {
										if (re.includes(n)) ie(re.filter((e) => e !== n));
										else if (re.length < 2) {
											let e = [...re, n];
											ie(e), e.length === 2 && P({
												type: "pickTasks",
												cards: [e[0], e[1]]
											});
										}
									}
								}, `${t}:${n}`))
							}),
							w.execStack.length > 0 && /* @__PURE__ */ h("div", {
								className: "flex flex-col gap-1",
								children: [/* @__PURE__ */ m("p", {
									className: "text-[10px] font-black opacity-70",
									children: "▶"
								}), w.execStack.map((e, t) => /* @__PURE__ */ m("div", {
									className: `rounded-md border-2 px-1.5 py-0.5 text-[10px] font-bold ${t === w.execStack.length - 1 ? "border-ink bg-amber-100" : "border-ink/20 bg-surface opacity-60"}`,
									children: e.source.startsWith("st:") || Un(e.source) ? /* @__PURE__ */ m(mn, {
										cardId: e.source,
										small: !0
									}) : e.source
								}, t))]
							}),
							e.seasonScores.some(Boolean) && /* @__PURE__ */ m("div", {
								className: "tend-sheet-section flex flex-col gap-1.5",
								children: e.seasonScores.map((t, n) => t && /* @__PURE__ */ h("div", {
									className: "plate flex min-h-11 items-center gap-2 px-2 py-1.5",
									title: s("games.tend.scoreSeason", { n: n + 1 }),
									children: [/* @__PURE__ */ h("span", {
										className: "rounded border border-ink bg-violet-100 px-1.5 font-display text-sm font-black",
										children: ["S", n + 1]
									}), /* @__PURE__ */ m("div", {
										className: "ml-auto flex flex-wrap items-center justify-end gap-x-2 gap-y-0.5",
										children: e.order.map((e) => /* @__PURE__ */ h("span", {
											className: "whitespace-nowrap text-[10px] font-bold",
											children: [
												ae(e),
												" ",
												/* @__PURE__ */ m("b", {
													className: "font-mono text-xs font-black tabular-nums",
													children: t[e]
												})
											]
										}, e))
									})]
								}, n))
							})
						]
					}),
					d === "farm" && /* @__PURE__ */ m(tn, {
						p: T,
						accent: V.accent,
						hiCells: pe,
						hiEdges: me,
						placeSize: v?.kind === "plant" ? D[v.crop].size : void 0,
						selCells: new Set(v?.kind === "till" ? v.cells : v?.kind === "grounds" || v?.kind === "disposeGrounds" ? v.till : []),
						selEdges: new Set(v?.kind === "grounds" || v?.kind === "disposeGrounds" ? v.fences : []),
						onCellTap: he,
						onEdgeTap: F,
						costMode: E ? v?.kind === "disposeCost" ? "dispose" : !M && A === void 0 ? "pay" : null : null,
						disposeGood: j ?? null,
						onCostTap: ge,
						onAnimalPay: (e) => P({
							type: "pay",
							area: "animal",
							id: e
						}),
						onPlaceAnimal: (e) => y({
							kind: "animal",
							animal: e
						}),
						animalMode: v?.kind === "animal" ? v.animal : null,
						onGroundsCoin: () => y({
							kind: "grounds",
							sub: "till",
							till: [],
							fences: [],
							tillN: 1,
							fenceN: 1
						}),
						groundsActive: v?.kind === "grounds"
					}),
					d === "cargo" && /* @__PURE__ */ m(bn, {
						p: T,
						accent: V.accent,
						cargoGood: E && x === "cargo" && j && j !== "wood" && j !== "exoWood" ? j : null,
						cargoRot: b,
						onRotate: () => te((b + 1) % 4),
						onCargoTap: (e) => {
							x === "cargo" && (P({
								type: "disposeCargo",
								anchor: e,
								rot: b
							}), S(null));
						},
						costMode: E ? v?.kind === "disposeCost" ? "dispose" : !M && A === void 0 ? "pay" : null : null,
						disposeGood: j,
						onCostTap: ge,
						onPurchase: (e) => P({
							type: "pay",
							area: "purchase",
							id: String(e)
						}),
						onIntern: () => P({
							type: "pay",
							area: "intern"
						}),
						onExplorer: (e) => P({
							type: "useExplorer",
							badge: e
						}),
						buybackMode: C,
						onBuyback: (e, t, n) => {
							if (!C) {
								ne(!0);
								return;
							}
							e && (P({
								type: "useBuyback",
								badge: e,
								row: t,
								slot: n
							}), ne(!1));
						},
						crossPick: E && B?.kind === "crossGood" ? {
							projects: B.projects,
							onPick: (e, t, n) => P({
								type: "crossGood",
								badge: e,
								row: t,
								slot: n
							})
						} : null
					}),
					d === "fish" && /* @__PURE__ */ h("div", {
						className: "tend-explore-page flex h-full min-h-0 flex-col gap-2 overflow-y-auto p-2",
						children: [
							["woods", "mines"].map((e) => /* @__PURE__ */ h("div", {
								className: `tend-sheet-section flex flex-col gap-2 ${k?.task === (e === "woods" ? "chop" : "mine") ? "-order-1" : ""}`,
								children: [/* @__PURE__ */ h("div", {
									className: "tend-scene",
									children: [/* @__PURE__ */ m("img", {
										src: Nt[e],
										alt: "",
										draggable: !1
									}), /* @__PURE__ */ h("div", {
										className: "tend-scene-title",
										children: [s(e === "woods" ? "games.tend.woodsLabel" : "games.tend.minesLabel"), /* @__PURE__ */ h("span", {
											className: "tend-scene-subtitle font-mono tabular-nums",
											children: [
												T[e].scratched.filter(Boolean).length,
												" / ",
												T[e].scratched.length
											]
										})]
									})]
								}), /* @__PURE__ */ m(Dn, {
									kind: e,
									card: E ? xe(e) : {
										cells: T[e].cells.map(() => null),
										scratched: T[e].scratched
									},
									eligible: Se(e),
									onPick: (t) => P({
										type: "scratch",
										card: e,
										cell: t
									}),
									accent: V.accent
								})]
							}, e)),
							w.geode && E && /* @__PURE__ */ m("div", {
								className: "tend-sheet-section -order-1",
								children: /* @__PURE__ */ m(jn, {
									spot: "geode",
									geodeDice: w.geode,
									eligible: z,
									onPick: (e) => P({
										type: "geodePick",
										cell: e
									}),
									accent: V.accent
								})
							}),
							I.map((e) => {
								let t = st(E ? w : T, e), n = L === e;
								return /* @__PURE__ */ h("div", {
									className: `tend-sheet-section flex flex-col gap-2 ${n ? "-order-1" : ""} ${t ? "" : "opacity-40"}`,
									children: [/* @__PURE__ */ h("div", {
										className: "tend-scene",
										children: [
											/* @__PURE__ */ m("img", {
												src: Nt[e],
												alt: "",
												draggable: !1
											}),
											/* @__PURE__ */ h("div", {
												className: "tend-scene-title",
												children: [s(Hn[e]), /* @__PURE__ */ m("span", {
													className: "tend-scene-subtitle",
													children: s("games.tend.fishingLabel")
												})]
											}),
											E && k?.task === "fish" && k.actions >= 1 && !M && t && /* @__PURE__ */ m("button", {
												type: "button",
												onClick: () => P({
													type: "fishSpot",
													spot: e
												}),
												className: "btn-base absolute bottom-2 right-2 z-10 min-h-11 border-2 border-ink px-3 text-sm font-black text-white",
												style: { background: V.accent },
												children: "🎣"
											})
										]
									}), /* @__PURE__ */ m(jn, {
										spot: e,
										fish: n ? w.fish : null,
										eligible: n ? Ce : void 0,
										onPick: n ? (e) => P({
											type: "fishPick",
											cell: e
										}) : void 0,
										onSkipPick: n ? () => P({
											type: "fishPick",
											cell: -1
										}) : void 0,
										accent: V.accent
									})]
								}, e);
							})
						]
					}),
					d === "neighbor" && /* @__PURE__ */ m(Pn, {
						p: T,
						order: e.order,
						myRid: r,
						members: n,
						phase: e.phase,
						setupHand: E ? t.setupHand : null,
						nbDraws: E ? t.nbDraws : void 0,
						disposeGood: x === "gift" ? j : null,
						onGiftSide: (e) => {
							P({
								type: "disposeGift",
								side: e
							}), S(null);
						},
						onPickSetup: (e, t) => P({
							type: "pickNeighborCards",
							left: e,
							right: t
						}),
						onResolveGift: (e, t, n) => P({
							type: "resolveGift",
							idx: e,
							use: t,
							...n ? { good: n } : {}
						}),
						onRedraw: (e, t) => P({
							type: "redrawNeighbor",
							side: e,
							keep: t
						}),
						onCycle: (e) => P({
							type: "cycleNeighbor",
							side: e
						}),
						onDone: E && (e.phase === "neighbor" || e.phase === "finalGifts") ? () => P({ type: "neighborDone" }) : void 0,
						doneDisabled: w.nbIncoming.length > 0 || w.disposeQueue.length > 0 || M || !!(t.nbDraws?.left || t.nbDraws?.right)
					})
				]
			})
		})
	});
}
var Hn = {
	pond: "games.tend.spot.pond",
	river: "games.tend.spot.river",
	lake: "games.tend.spot.lake",
	grotto: "games.tend.spot.grotto"
}, Un = (e) => e.startsWith("s1-") || e.startsWith("s2-") || e.startsWith("s3-"), Wn = (e) => e, Gn = () => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, Kn = (e) => e[Math.floor(Gn() * e.length)], qn = (e) => e !== "geode" && e !== "wood" && e !== "exoWood", Jn = [
	"pond",
	"river",
	"lake",
	"grotto"
], Yn = [
	"tend",
	"fish",
	"chop",
	"mine"
], Xn = (e, t) => e.badges[t].filter((e) => e.every(Boolean)).length;
function Zn(e, t) {
	let n = null, r = (r, i, a, o, s) => {
		i.forEach((i, c) => {
			let l = a[c];
			l && i.forEach((a, u) => {
				if (a !== t || l[u]) return;
				let d = i.every((e, t) => t === u || l[t]), f = o + (d ? 6 : 0);
				if (r === "badge" && s) {
					let t = N.find((e) => e.id === s);
					f += t.vp / 10 + (d && Xn(e, s) === 1 ? t.vp / 2 : 0);
				}
				(!n || f > n.score) && (n = {
					area: r,
					row: c,
					slot: u,
					id: s,
					score: f
				});
			});
		});
	};
	r("bridge", A, e.bridge, 7), r("rod2", M, e.rod2, 6.5), r("rod1", j, e.rod1, 6), e.lureChoice !== 1 && r("lureGreen", [oe[0]], [e.lures[0]], 5), e.lureChoice !== 0 && r("lureRed", [oe[1]], [e.lures[1]], 5), r("equipTools", k, e.equip.tools, 6), r("equipHatchet", k, e.equip.hatchet, 6), r("equipPickaxe", k, e.equip.pickaxe, 6), r("explorer", [le], [e.explorerPaid], 5), r("trellis", e.trellis.map(() => ae), e.trellis, 4);
	for (let t of N) r("badge", t.rows.map((e) => e.cost), e.badges[t.id], 6, t.id);
	return n;
}
function Qn(e, t) {
	return e === "geode" ? 2.5 : (qn(e) ? S[e].sell : C[e]) + (Zn(t, e) ? 1.5 : 0);
}
function $n(e, t) {
	let n = e.map(([e, t]) => [e, t]);
	for (let e = 0; e < t; e++) n = n.map(([e, t]) => [t, -e]);
	let r = Math.min(...n.map(([e]) => e)), i = Math.min(...n.map(([, e]) => e));
	return n.map(([e, t]) => [e - r, t - i]);
}
function er(e, t) {
	let n = S[t], r = null;
	for (let t = 0; t < 4; t++) {
		let i = $n(x[n.shape], t), a = Math.max(...i.map(([e]) => e)) + 1, o = Math.max(...i.map(([, e]) => e)) + 1;
		for (let s = 0; s + a <= 8; s++) for (let a = 0; a + o <= 12; a++) {
			let o = i.map(([e, t]) => (s + e) * 12 + (a + t)), c = new Set(o), l = !0, u = 0;
			for (let t of o) {
				if (e.cargo[t] !== null) {
					l = !1;
					break;
				}
				let r = Math.floor(t / 12), i = t % 12, a = ne[Math.floor(i / 4)];
				u += a.cat === n.cat ? a.pts : 1, (r === 0 || r === 7 || i === 0 || i === 11) && (u += .3);
				for (let [t, a] of [
					[r - 1, i],
					[r + 1, i],
					[r, i - 1],
					[r, i + 1]
				]) {
					if (t < 0 || t >= 8 || a < 0 || a >= 12) continue;
					let r = t * 12 + a;
					if (c.has(r)) continue;
					let i = e.cargo[r];
					if (i && S[i].cat === n.cat) {
						l = !1;
						break;
					}
				}
				if (!l) break;
			}
			if (!l) continue;
			let d = new Set(o.map((e) => Math.floor(e / 12)));
			for (let t of d) {
				if (e.cargoRowsDone[t]) continue;
				let n = !0;
				for (let r = 0; r < 12; r++) e.cargo[t * 12 + r] === null && !c.has(t * 12 + r) && (n = !1);
				n && (u += 12);
			}
			let f = new Set(o.map((e) => e % 12));
			for (let t of f) {
				if (e.cargoColsDone[t]) continue;
				let n = !0;
				for (let r = 0; r < 8; r++) e.cargo[r * 12 + t] === null && !c.has(r * 12 + t) && (n = !1);
				n && (u += 4);
			}
			(!r || u > r.score) && (r = {
				anchor: s * 12 + a,
				rot: t,
				score: u
			});
		}
	}
	return r;
}
function tr(e, t) {
	let n = null;
	for (let r of ["left", "right"]) {
		let i = e.nbHand[r];
		if (i === null) continue;
		let a = F[i];
		a.goods.includes(t) && (!n || a.bonus > n.bonus) && (n = {
			side: r,
			bonus: a.bonus
		});
	}
	return n ? n.side : null;
}
function nr(e, t) {
	let n = e.disposeQueue[0], r = Zn(e, n), i = tr(e, n), a = qn(n) ? er(e, n) : null, o = qn(n) ? S[n].sell : C[n], s = r ? {
		type: "disposeCost",
		area: r.area,
		row: r.row,
		slot: r.slot,
		id: r.id
	} : null, c = a ? {
		type: "disposeCargo",
		anchor: a.anchor,
		rot: a.rot
	} : null;
	if (t) {
		let e = [];
		return s && e.push(s), i && e.push({
			type: "disposeGift",
			side: i
		}), c && e.push(c), o > 0 && e.push({ type: "disposeSell" }), e.length ? Kn(e) : { type: "disposeSell" };
	}
	return s || (i ? {
		type: "disposeGift",
		side: i
	} : c || { type: "disposeSell" });
}
function rr(e, t) {
	let [n, r] = e.geode, i = [];
	for (let e = 0; e < 25; e++) {
		let t = Math.floor(e / 5), a = e % 5;
		(n === 1 || t === n - 1) && (r === 1 || a === r - 1) && i.push(e);
	}
	if (t) return {
		type: "geodePick",
		cell: Kn(i)
	};
	let a = P.geode, o = i[0], s = -1;
	for (let t of i) {
		let n = a[t], r = n && n !== "geode" ? Qn(n, e) : 0;
		r > s && (s = r, o = t);
	}
	return {
		type: "geodePick",
		cell: o
	};
}
var ir = (e) => e.rod2.every((e) => e.every(Boolean)) ? 2 : +!!e.rod1.every((e) => e.every(Boolean));
function ar(e) {
	let t = e.fish, n = ir(e), r = /* @__PURE__ */ new Set();
	for (let e = 0; e < 25; e++) {
		let i = Math.floor(e / 5), a = e % 5;
		if ((t.dice[0] === 1 || i === t.dice[0] - 1) && (t.dice[1] === 1 || a === t.dice[1] - 1)) for (let e = 0; e < 25; e++) {
			if (t.picks.includes(e)) continue;
			let o = Math.floor(e / 5), s = e % 5;
			(n === 2 ? Math.abs(o - i) <= 1 && Math.abs(s - a) <= 1 : n === 1 ? Math.abs(o - i) + Math.abs(s - a) <= 1 : o === i && s === a) && r.add(e);
		}
	}
	return r;
}
function or(e, t) {
	let n = [...ar(e)];
	if (t) return {
		type: "fishPick",
		cell: Kn([...n, -1])
	};
	let r = P[e.fish.spot], i = null;
	for (let t of n) {
		let n = r[t];
		if (!n) continue;
		let a = n === "geode" ? 2.5 : Qn(n, e);
		(!i || a > i.v) && (i = {
			cell: t,
			v: a
		});
	}
	return {
		type: "fishPick",
		cell: i ? i.cell : -1
	};
}
function sr(e, t) {
	switch (e.kind) {
		case "goods": return e.goods.reduce((e, n) => e + Qn(n, t) + 1, 0);
		case "pick": return Math.max(...e.options.map((e) => Qn(e, t))) + 1;
		case "coins": return e.n;
		case "freeTask": return 3.5;
		case "anyTask": return 4;
		case "crossGood": return 3;
		case "bundle": return e.parts.reduce((e, n) => e + sr(n, t), 0);
		case "choice": return Math.max(...e.options.map((e) => sr(e, t)));
	}
}
function cr(e, t, n) {
	if (e.kind === "crossGood") {
		let n = null;
		for (let r of e.projects) {
			let e = N.find((e) => e.id === r), i = t.badges[r];
			if (!e || !i) continue;
			let a = i.filter((e) => e.every(Boolean)).length;
			for (let t = 0; t < i.length; t++) for (let o = 0; o < i[t].length; o++) {
				if (i[t][o]) continue;
				let s = i[t].filter((e) => !e).length, c = a * 3 + (s === 1 ? 8 : 0) + e.vp / 10;
				(!n || c > n.s) && (n = {
					badge: r,
					row: t,
					slot: o,
					s: c
				});
			}
		}
		return n ? {
			type: "crossGood",
			badge: n.badge,
			row: n.row,
			slot: n.slot
		} : { type: "skip" };
	}
	if (n) return {
		type: "pickReward",
		idx: Math.floor(Gn() * e.options.length)
	};
	let r = 0, i = -1;
	return e.options.forEach((n, a) => {
		let o = e.kind === "pick" ? Qn(n, t) : sr(n, t);
		o > i && (i = o, r = a);
	}), {
		type: "pickReward",
		idx: r
	};
}
function lr(e, t) {
	let n = St(Wn(e)), r = new Set(e.tilled), i = [];
	for (let e = 0; e < 132; e++) {
		let t = H(e), a = U(e);
		if (!W(t, a) || r.has(e) || n.has(e)) continue;
		let o = 0;
		for (let [e, n] of [
			[t - 1, a],
			[t + 1, a],
			[t, a - 1],
			[t, a + 1]
		]) W(e, n) && r.has(He(e, n)) && (o += 1);
		i.push({
			i: e,
			s: o
		});
	}
	return i.sort((e, t) => t.s - e.s), i.length >= t ? i.slice(0, t).map((e) => e.i) : null;
}
function ur(e) {
	let t = St(Wn(e)), n = new Set(e.tilled), r = (r, i) => {
		let a = G(i, D[r].size);
		return !(!a || a.some((e) => !n.has(e) || t.has(e)) || D[r].trellis && !e.trellises.includes(i));
	};
	for (let e of [
		"pumpkin",
		"wildFruit",
		"berries",
		"pineapple"
	]) for (let t = 0; t < 132; t++) if (r(e, t)) return {
		crop: e,
		anchor: t
	};
	return null;
}
function dr(e, t) {
	if (t) {
		let t = e.crops.map((e, t) => ({
			type: "tendWater",
			idx: t
		})), n = ur(e);
		n && t.push({
			type: "tendPlant",
			crop: n.crop,
			anchor: n.anchor
		});
		let r = lr(e, 6);
		return r && t.push({
			type: "tendTill",
			cells: r
		}), t.length ? Kn(t) : null;
	}
	let n = e.crops.findIndex((e) => Ke(D[e.crop].faces, e.face).harvest);
	if (n >= 0) return {
		type: "tendWater",
		idx: n
	};
	let r = ur(e);
	if (r) return {
		type: "tendPlant",
		crop: r.crop,
		anchor: r.anchor
	};
	if (e.crops.length > 0) {
		let t = 0;
		return e.crops.forEach((n, r) => {
			n.face > e.crops[t].face && (t = r);
		}), {
			type: "tendWater",
			idx: t
		};
	}
	let i = lr(e, 6);
	return i ? {
		type: "tendTill",
		cells: i
	} : null;
}
var fr = {
	woods: new Map(ye.map((e) => [e.row * 7 + e.col, e.content])),
	mines: new Map(be.map((e) => [e.row * 7 + e.col, e.content]))
}, pr = /* @__PURE__ */ new Set([
	"chop",
	"chopGold",
	"chopUpgraded",
	"mine",
	"mineGold",
	"mineUpgraded"
]);
function mr(e, t) {
	let n = e.scratched.some(Boolean), r = [];
	for (let i = 0; i < e.scratched.length; i++) {
		if (e.scratched[i]) continue;
		let a = Math.floor(i / 7), o = i % 7;
		if (!((a < 4 ? 1 : 2) > t)) {
			if (!n) {
				if (a !== 0) continue;
			} else if (a !== 0 && ![
				[-1, 0],
				[1, 0],
				[0, -1],
				[0, 1]
			].some(([t, n]) => {
				let r = a + t, i = o + n;
				return r >= 0 && r < 8 && i >= 0 && i < 7 && e.scratched[r * 7 + i];
			})) continue;
			r.push(i);
		}
	}
	return r;
}
function hr(e, t, n, r) {
	let i = mr(e, n);
	if (!i.length) return null;
	if (r) return Kn(i);
	let a = fr[t], o = i[0], s = -1;
	for (let e of i) {
		let t = Math.floor(e / 7), n = a.get(e), r = t * 2 + (n === void 0 ? 0 : pr.has(n) ? 3 : 1);
		r > s && (s = r, o = e);
	}
	return o;
}
function gr(e, t) {
	switch (t) {
		case "tend": {
			let t = 0;
			return e.crops.some((e) => Ke(D[e.crop].faces, e.face).harvest) && (t += 3), ur(e) && (t += 2), e.crops.length > 0 ? t += .5 : lr(e, 6) && (t += 1), t;
		}
		case "chop": return mr(e.woods, 3).length > 0 ? 2.5 : 0;
		case "mine": return mr(e.mines, 3).length > 0 ? 2.5 : 0;
		case "fish": {
			let t = Wn(e);
			return 1 + Jn.filter((e) => st(t, e)).length;
		}
	}
}
function _r(e, t) {
	if (e.startsWith("st:")) {
		let n = e.split(":")[1];
		return n === "zenithOrders" ? 2 : 1 + gr(t, n);
	}
	let n = Oe[e];
	if (!n) return 0;
	let r = n.top.kind === "coins" ? n.top.n : n.top.kind === "anyTask" ? 3 : 1 + Math.max(...n.top.tasks.map((e) => gr(t, e))), i = n.bottom ? sr(n.bottom, t) : 0, a = n.cond ? ft(n.cond, Wn(t)) : !1;
	return r + (n.cond ? a ? i : i * .15 : i * .5);
}
function vr(e, t, n) {
	let r = e.length;
	if (n) return [Math.floor(Gn() * r), Math.floor(Gn() * r)];
	let i = e.map((e, n) => ({
		i: n,
		s: _r(e, t)
	}));
	return i.sort((e, t) => t.s - e.s), [i[0].i, i[1].i];
}
function yr(e, t, n) {
	let r = t.options && t.options.length > 0 ? t.options : Yn;
	if (n) return Kn(r);
	let i = r[0], a = -1;
	for (let t of r) {
		let n = gr(e, t);
		n > a && (a = n, i = t);
	}
	return i;
}
function br(e, t) {
	if (!t.task) return !1;
	if (t.task === "fish") return !0;
	if (t.task === "tend") return gr(e, "tend") > 0;
	let n = t.task === "chop" ? "woods" : "mines";
	return hr(e[n], n, t.actions + 1, !1) !== null;
}
function xr(e, t, n) {
	switch (t.task) {
		case "tend": return dr(e, n);
		case "chop":
		case "mine": {
			let r = t.task === "chop" ? "woods" : "mines", i = hr(e[r], r, t.actions, n);
			return i === null ? null : {
				type: "scratch",
				card: r,
				cell: i
			};
		}
		case "fish": {
			let t = Wn(e), r = Jn.filter((e) => st(t, e));
			return r.length ? {
				type: "fishSpot",
				spot: n ? Kn(r) : r[r.length - 1]
			} : null;
		}
		default: return null;
	}
}
function Sr(e) {
	let t = [
		{
			area: "bridge",
			rows: A,
			paid: e.bridge,
			pri: 4
		},
		{
			area: "rod1",
			rows: j,
			paid: e.rod1,
			pri: 3
		},
		{
			area: "rod2",
			rows: M,
			paid: e.rod2,
			pri: 3
		},
		{
			area: "equipTools",
			rows: k,
			paid: e.equip.tools,
			pri: 2
		},
		{
			area: "equipHatchet",
			rows: k,
			paid: e.equip.hatchet,
			pri: 2
		},
		{
			area: "equipPickaxe",
			rows: k,
			paid: e.equip.pickaxe,
			pri: 2
		},
		{
			area: "trellis",
			rows: e.trellis.map(() => ae),
			paid: e.trellis,
			pri: 1
		}
	], n = null;
	for (let e of t) for (let t = 0; t < e.rows.length; t++) {
		let r = e.rows[t], i = e.paid[t];
		if (!i) continue;
		let a = r.findIndex((e, t) => e === "coin" && !i[t]);
		a < 0 || r.every((e, t) => e === "coin" || i[t]) && (!n || e.pri > n.pri) && (n = {
			area: e.area,
			row: t,
			slot: a,
			pri: e.pri
		});
	}
	return n;
}
function Cr(e, t, n) {
	if (n) return null;
	let r = Wn(e);
	if (t === "task") {
		if (!e.explorerUsed && e.explorerPaid.every(Boolean)) {
			let t = N.filter((t) => Xn(e, t.id) >= 2);
			if (t.length) return {
				type: "useExplorer",
				badge: t.reduce((e, t) => t.vp > e.vp ? t : e).id
			};
		}
		let t = e.trellis.filter((e) => e.every(Boolean)).length;
		if (e.trellises.length < t) {
			let t = St(r), n = new Set(e.tilled), i = -1;
			for (let e = 0; e < 132; e++) {
				let r = G(e, 2);
				if (r && !r.some((e) => t.has(e))) {
					if (r.every((e) => n.has(e))) return {
						type: "placeTrellis",
						anchor: e
					};
					i < 0 && (i = e);
				}
			}
			if (i >= 0) return {
				type: "placeTrellis",
				anchor: i
			};
		}
	}
	if (!e.buybackUsed && e.coins >= 4) {
		let t = null;
		for (let n of N) {
			let r = e.badges[n.id], i = r.filter((e) => e.every(Boolean)).length;
			for (let e = 0; e < r.length; e++) {
				let a = [];
				if (r[e].forEach((e, t) => {
					e || a.push(t);
				}), a.length !== 1) continue;
				let o = n.vp / 10 + i * 3;
				(!t || o > t.s) && (t = {
					id: n.id,
					row: e,
					slot: a[0],
					s: o
				});
			}
		}
		if (t && t.s >= 3) return {
			type: "useBuyback",
			badge: t.id,
			row: t.row,
			slot: t.slot
		};
	}
	if (t === "task") {
		let t = e.energyPaid.findIndex((e) => e < 3);
		if (t >= 0 && e.coins >= 5) return {
			type: "pay",
			area: "energy",
			slot: t
		};
		let n = Sr(e);
		if (n && e.coins >= 4) return {
			type: "pay",
			area: n.area,
			row: n.row,
			slot: n.slot
		};
	}
	let i = ue.findIndex((t, n) => t.good === "copper" && !e.purchaseUsed[n]);
	if (i >= 0 && e.coins >= (t === "finalGifts" ? 1 : 6) && er(e, "copper")) return {
		type: "pay",
		area: "purchase",
		id: String(i)
	};
	if (t === "task" && e.coins >= 4 && e.crops.length < 2) {
		let t = lr(e, 1);
		if (t) return {
			type: "groundsCoin",
			till: t
		};
	}
	return null;
}
function wr(e, t, n) {
	if (n) {
		let e = [
			0,
			1,
			2,
			3
		].sort(() => Gn() - .5);
		return {
			left: e[0],
			right: e[1]
		};
	}
	let r = e.map((e, n) => ({
		i: n,
		s: F[e].bonus * 3 + Math.max(...F[e].goods.map((e) => Qn(e, t)))
	}));
	return r.sort((e, t) => t.s - e.s), {
		left: r[0].i,
		right: r[1].i
	};
}
function Tr(e, t, n) {
	let r = F[e.nbIncoming[0]];
	if (n) return {
		type: "resolveGift",
		idx: 0,
		use: !0,
		good: Kn(r.goods)
	};
	let i = r.goods[0], a = -1;
	for (let t of r.goods) {
		let n = Qn(t, e);
		n > a && (a = n, i = t);
	}
	return {
		type: "resolveGift",
		idx: 0,
		use: r.goods.some((e) => e !== "heart") || t,
		good: i
	};
}
function Er(e, t, n) {
	if (n) return Gn() < .5 ? 0 : 1;
	let r = (n) => {
		let r = F[e[n]];
		return r.bonus * 3 + Math.max(...r.goods.map((e) => Qn(e, t)));
	};
	return +(r(1) > r(0));
}
function Dr(e, t, n, r, i) {
	if (n.rewardPick) return cr(n.rewardPick, n, i);
	if (n.geode) return rr(n, i);
	if (n.fish) return or(n, i);
	if (n.disposeQueue.length > 0) return nr(n, i);
	switch (e.phase) {
		case "setupCards": {
			let e = t.setupHand;
			return e ? {
				type: "pickNeighborCards",
				...wr(e, n, i)
			} : null;
		}
		case "neighbor":
		case "finalGifts":
			if (n.nbIncoming.length > 0) return Tr(n, r, i);
			if (e.phase === "neighbor") {
				if (t.nbDraws?.left) return {
					type: "redrawNeighbor",
					side: "left",
					keep: Er(t.nbDraws.left, n, i)
				};
				if (t.nbDraws?.right) return {
					type: "redrawNeighbor",
					side: "right",
					keep: Er(t.nbDraws.right, n, i)
				};
			}
			if (e.phase === "finalGifts") {
				let e = Cr(n, "finalGifts", i);
				if (e) return e;
			}
			return { type: "neighborDone" };
		case "task": {
			let t = n.execStack[n.execStack.length - 1];
			if (t) {
				if (t.task === null) return {
					type: "chooseTask",
					task: yr(n, t, i)
				};
				if (!t.energyUsed && !i && n.energyCharges.some((e) => e > 0) && br(n, t)) return { type: "useEnergy" };
				if (t.actions > 0) {
					let e = xr(n, t, i);
					if (e) return e;
				}
				return { type: "finishActions" };
			}
			return n.picked.length < 2 ? {
				type: "pickTasks",
				cards: vr(e.taskRow, n, i)
			} : Cr(n, "task", i) ?? { type: "taskDone" };
		}
		default: return null;
	}
}
var Or = (e, t) => {
	let n = e.public, r = n.players?.[t.rid];
	if (!r || n.finalScores || r.phaseDone) return null;
	let i = Dr(n, e.private ?? {}, r, n.order.length === 1, t.difficulty === "weak");
	return i ? { action: i } : null;
};
//#endregion
//#region src/games/tend/endgame-review.tsx
function kr({ board: e, renderResult: t, ...n }) {
	let s = c(), [l, u] = o(!0), [d, f] = o(null), p = a(null), ee = a(null), y = a(null);
	r(() => {
		if (!d) return;
		y.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let b = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? p : ee).current?.focus({ preventScroll: !0 }));
	}, te = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), x = {
		...n,
		...te
	};
	return /* @__PURE__ */ h("div", {
		className: "tend-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ m("div", {
				className: "tend-endgame-board",
				inert: l,
				children: e
			}),
			/* @__PURE__ */ m("div", {
				className: "tend-endgame-overlay",
				hidden: !l,
				children: /* @__PURE__ */ h("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), b(!1));
					},
					className: "tend-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ h("header", {
							className: "tend-endgame-heading",
							children: [/* @__PURE__ */ h("div", {
								className: "tend-endgame-brand",
								children: [/* @__PURE__ */ m("span", {
									"aria-hidden": "true",
									children: V.icon
								}), s(V.nameKey)]
							}), /* @__PURE__ */ m("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.tend.reviewHide"),
								title: s("games.tend.reviewHide"),
								onClick: () => b(!1),
								children: /* @__PURE__ */ m(_, { size: 19 })
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "tend-endgame-result",
							inert: d !== null,
							children: t(x)
						}),
						d && /* @__PURE__ */ h("div", {
							className: "tend-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ m("button", {
								type: "button",
								ref: y,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.tend.reviewConfirmAgain" : "games.tend.reviewConfirmLobby")
							}), /* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.tend.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "tend-endgame-toolbar",
				hidden: l,
				children: /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base",
					ref: ee,
					onClick: () => b(!0),
					children: [
						/* @__PURE__ */ m(v, { size: 18 }),
						s("games.tend.reviewShow"),
						/* @__PURE__ */ m(g, { size: 18 })
					]
				})
			})
		]
	});
}
function Ar({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: u, renderRowExtra: f, summary: g, navigation: v, content: b, afterRanking: te, scoreUnit: x, rankOf: S }) {
	let C = c(), ne = s((e) => e.locale), [re, ie] = o({}), w = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? d(n, ne) : e;
	}, T = (t, n) => S?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), E = e.ranking.some((t) => e.scores?.[t] !== void 0), D = (t, n) => /* @__PURE__ */ h("div", {
		className: "tend-score-identity",
		children: [
			/* @__PURE__ */ h("span", {
				className: "tend-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ m("span", {
					"aria-label": C("games.tend.reviewWinner"),
					children: "♛ "
				}), E && T(t, n)]
			}),
			/* @__PURE__ */ h("span", {
				className: "tend-score-name",
				children: [w(t), t === r && /* @__PURE__ */ m("small", { children: C("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ h("small", {
				className: "tend-score-autopilot",
				children: [
					/* @__PURE__ */ m(ee, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), O = (t) => e.ranking.map((n) => /* @__PURE__ */ m("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ h("div", {
		className: "tend-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ m(y, {}),
			v,
			/* @__PURE__ */ h("div", {
				className: "tend-score-body",
				children: [
					g && /* @__PURE__ */ m("div", {
						className: "tend-score-summary",
						children: g
					}),
					i !== void 0 && /* @__PURE__ */ m("p", {
						className: "tend-score-hints",
						children: C("session.hint.usedCount", { n: i })
					}),
					b ?? (u?.length ? /* @__PURE__ */ m("div", {
						className: "tend-score-table-scroll",
						children: /* @__PURE__ */ h("table", {
							className: "tend-score-table",
							"aria-label": C(V.nameKey),
							children: [
								/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { scope: "col" }), /* @__PURE__ */ m(p, { children: e.ranking.map((t, n) => /* @__PURE__ */ m("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: D(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ m("tbody", { children: u.map((e, t) => /* @__PURE__ */ h(n, { children: [/* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ h("button", {
										type: "button",
										"aria-expanded": !!re[t],
										onClick: () => ie((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ m(_, { size: 15 }), e.label]
									}) : e.label
								}), O(e)] }), re[t] && e.details?.map((e, t) => /* @__PURE__ */ h("tr", {
									className: "tend-score-sub",
									children: [/* @__PURE__ */ m("th", {
										scope: "row",
										children: e.label
									}), O(e)]
								}, t))] }, t)) }),
								E && /* @__PURE__ */ m("tfoot", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: C("games.tend.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ m("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ m("ol", {
						className: "tend-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ h("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ h("div", {
								className: "tend-score-rankline",
								children: [D(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ h("strong", {
									className: "tend-score-points",
									children: [e.scores[t], x && /* @__PURE__ */ m("small", { children: x })]
								})]
							}), f?.(t)]
						}, t))
					})),
					te,
					!!u?.length && f && /* @__PURE__ */ m("div", {
						className: "tend-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ h("details", { children: [/* @__PURE__ */ m("summary", { children: w(e) }), f(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ h("footer", {
				className: "tend-score-actions",
				children: [
					l && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: C("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: C("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ m("p", { children: C("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/tend/game-over.tsx
function jr(e) {
	return /* @__PURE__ */ m(Ar, {
		...e,
		accent: V.accent
	});
}
function Mr(e) {
	return /* @__PURE__ */ m(kr, {
		...e,
		board: /* @__PURE__ */ m(Bn, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ m(jr, { ...e })
	});
}
//#endregion
//#region src/games/tend/options.tsx
function Nr({ value: e, onChange: t }) {
	let n = c(), r = Be.safeParse(e), i = r.success ? r.data : Be.parse(void 0);
	return /* @__PURE__ */ h(te, {
		title: n("games.tend.optNoAdv"),
		children: [/* @__PURE__ */ m(b, {
			name: "tend-no-adv",
			value: "false",
			checked: !i.noAdv,
			label: n("games.tend.optNoAdvOff"),
			hint: n("games.tend.optNoAdvOffHint"),
			accent: V.accent,
			onChange: () => t({
				...i,
				noAdv: !1
			})
		}), /* @__PURE__ */ m(b, {
			name: "tend-no-adv",
			value: "true",
			checked: i.noAdv,
			label: n("games.tend.optNoAdvOn"),
			hint: n("games.tend.optNoAdvOnHint"),
			accent: V.accent,
			onChange: () => t({
				...i,
				noAdv: !0
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tend/entry.tsx
var Pr = {
	definition: Mt,
	View: Bn,
	bot: Or,
	OverView: Mr,
	Options: Nr,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "异星物语",
			desc: "外星农场骰写:照料作物、钓鱼挖矿、装满货运舱",
			rules: "目标：进行 12 轮外星农场经营。将目标、货运舱、徽章和邻居轨道获得的分数相加，总分最高的玩家获胜。\n流程(每轮):\n· 邻居阶段:处理收到的礼物(收下卡面所示的 1 份资源,或沿来路转赠给下一家),赠出过礼物的槽位会补充新卡。\n· 任务阶段:从任务行选 2 张卡执行。\n· 每张卡的上半部分选 1 个主行动执行(务农/钓鱼/砍木/挖矿),条件满足时再获得下半部分的奖励。\n· 成长:你的作物与动物骰自动前进 1 面,停在白色面时收获。\n主行动：\n· 务农：选择种植作物、浇水或耕作 6 格土地。\n· 砍木：在对应刮刮卡上刮开 1 至 2 格。\n· 挖矿：在对应刮刮卡上刮开 1 至 2 格。\n· 钓鱼：投掷 2 颗骰子，并在钓点网格中选择鱼。\n资源不保留在库存中。每次获得资源时，立即选择以下一种处理方式：\n· 将资源卖给企业站。\n· 将资源装入货运舱。\n· 将资源填入费用格。\n· 将资源赠送给邻居。\n计分：\n· 在第6、10、12轮，分别按当季目标卡计算得分。\n· 游戏结束时，加入货运舱和徽章的得分。\n· 邻居轨道按领先格数计分，每领先1格获得3分。\n解锁条件：项目的费用格须全部填满，才能启用对应项目。填满断桥的费用格后，解锁河流（RIVER）；在树林的最下行刮开一个格子后，解锁湖泊（LAKE）；在矿洞的最下行刮开一个格子后，解锁洞穴（GROTTO）。\n货运舱中一行或一列填满时，获得免费行动。奖章既可以出售，也计入徽章进度。",
			err: {
				phase: "当前阶段不能这么做",
				pending: "先处理完当前待办",
				queue: "先处置队首的资源",
				coins: "Z 币不够",
				cost: "这格费用不能用这份资源填",
				occupied: "这里有东西了",
				fence: "围栏不合规",
				scratch: "这格刮不了",
				fish: "钓鱼操作无效",
				cargo: "货舱放不下",
				card: "这张卡不可用"
			},
			good: {
				pineapple: "菠萝",
				wildFruit: "野果",
				pumpkin: "南瓜",
				berries: "浆果",
				egg: "蛋",
				wool: "驼绒",
				milk: "牛奶",
				mamble: "曼波鱼",
				sunpop: "日泡鱼",
				blobber: "团团鱼",
				geojell: "岩冻鱼",
				pebblepuff: "卵石豚",
				crankle: "曲壳鱼",
				nessel: "刺鳍鱼",
				lillybloom: "莲灯鱼",
				orbble: "圆珠鱼",
				plumfish: "梅鱼",
				shimmerpuff: "微光豚",
				gribble: "砾齿鱼",
				stone: "石料",
				copper: "铜矿",
				iron: "铁矿",
				artifact: "遗物",
				bone: "兽骨",
				ruby: "红晶",
				crystal: "水晶",
				rainbowRock: "虹彩岩",
				treeSap: "树液",
				redBp: "红蓝图",
				purpleBp: "紫蓝图",
				heart: "红心",
				medalCopper: "铜奖章",
				medalSilver: "银奖章",
				medalGold: "金奖章",
				medalPlatinum: "铂金奖章",
				wood: "木料",
				exoWood: "外星木料",
				geode: "晶球"
			},
			cat: {
				farm: "农牧",
				fish: "鱼类",
				mining: "矿产",
				social: "社交",
				badge: "奖章"
			},
			mainTask: {
				tend: "务农",
				fish: "钓鱼",
				chop: "砍木",
				mine: "挖矿"
			},
			starter: {
				tend: "务农",
				fish: "钓鱼",
				chop: "砍木",
				mine: "挖矿",
				zenithOrders: "天顶订单"
			},
			task: {
				"s1-01": "斧矿工",
				"s1-02": "洞穴渔夫",
				"s1-03": "能量爱好者",
				"s1-04": "农场清道夫",
				"s1-05": "农场渔夫",
				"s1-06": "农场矿工",
				"s1-07": "采集者",
				"s1-08": "种植者",
				"s1-09": "自然收藏家",
				"s1-10": "新手收藏家",
				"s1-11": "新手渔夫",
				"s1-12": "新手觅食者",
				"s1-13": "新手矿工",
				"s1-14": "河道疏浚工",
				"s1-15": "河钓手",
				"s1-16": "闪亮收藏家",
				"s1-17": "熟练学徒",
				"s1-18": "熟练渔夫",
				"s1-19": "社交蝴蝶",
				"s1-20": "木料收集工",
				"s2-01": "业余农夫",
				"s2-02": "收藏家",
				"s2-03": "洞穴种植者",
				"s2-04": "充能者",
				"s2-05": "挖掘工",
				"s2-06": "专家渔夫",
				"s2-07": "外向者",
				"s2-08": "农场挖掘工",
				"s2-09": "农场林务员",
				"s2-10": "装备商",
				"s2-11": "通才奖章得主",
				"s2-12": "万事通",
				"s2-13": "伐木渔夫",
				"s2-14": "鱼饵大师",
				"s2-15": "奖章得主",
				"s2-16": "实用主义者",
				"s2-17": "项目爱好者",
				"s2-18": "重装上阵",
				"s2-19": "秘矿渔夫",
				"s2-20": "林地清理工",
				"s3-01": "反反社交",
				"s3-02": "全能建造者",
				"s3-03": "完满主义者",
				"s3-04": "深入者",
				"s3-05": "能量怪",
				"s3-06": "猎鱼手",
				"s3-07": "新晋农夫",
				"s3-08": "地质学家",
				"s3-09": "岩洞渔夫",
				"s3-10": "翠鸟渔夫",
				"s3-11": "湖钓手",
				"s3-12": "市场耕耘者",
				"s3-13": "市场挖掘者",
				"s3-14": "市场大师",
				"s3-15": "市场奇才",
				"s3-16": "建筑大师",
				"s3-17": "农场大师",
				"s3-18": "研究徽章大师",
				"s3-19": "密林探险家",
				"s3-20": "伐木人"
			},
			obj: {
				clearer: "清理工",
				cruncher: "电力狂人",
				edges: "边缘",
				leftSampler: "左档尝鲜",
				loner: "独行侠",
				medalBonus: "奖章加成",
				socialite: "社交名流",
				spacer: "留白者",
				wideSpacer: "宽留白",
				animalHandler: "驯兽师",
				borders: "边界",
				centerSampler: "中档尝鲜",
				crossOver: "跨界",
				meritEarner: "功勋得主",
				minimalist: "极简主义",
				moderate: "适中",
				organizer: "整理师",
				shrimp: "小虾",
				biggen: "大块头",
				cargoMaster: "货运大师",
				centrist: "中档大师",
				lefty: "左档大师",
				packed: "满满当当",
				righty: "右档大师",
				seasonedWorker: "老练工人",
				trueFriend: "真朋友",
				varietyPack: "全家福"
			},
			objDesc: {
				clearer: "树林+矿洞每刮开 1 格 = 2 分",
				cruncher: "每条已解锁能量条 = 4 分",
				edges: "货舱边缘格每被覆盖 1 格 = 2 分",
				leftSampler: "档位 1 内每不同种货物 = 6 分",
				loner: "每个 1 格货物 = 3 分",
				medalBonus: "每个奖章 = 5 分",
				socialite: "每次完成邻居请求 = 3 分",
				spacer: "每个 1 格空白区域 = 4 分",
				wideSpacer: "每个 2 格空白区域 = 5 分",
				animalHandler: "每种动物 + 每个已解锁钓点 = 5 分",
				borders: "货舱左右两列填满 = 15 分",
				centerSampler: "档位 2 内每不同种货物 = 3 分",
				crossOver: "每个横跨 2 档位的货物 = 4 分",
				meritEarner: "每个已解锁徽章 = 5 分",
				minimalist: "每个 3 格空白区域 = 6 分",
				moderate: "每个 3 格货物 = 4 分",
				organizer: "每完成 1 列 = 8 分",
				shrimp: "每个 2 格货物 = 4 分",
				biggen: "每个 4 格及以上货物 = 4 分",
				cargoMaster: "每完成 1 行 = 8 分",
				centrist: "档位 2 全满 = 20 分",
				lefty: "档位 1 全满 = 20 分",
				packed: "货舱全部边缘格填满 = 20 分",
				righty: "档位 3 全满 = 20 分",
				seasonedWorker: "采矿+砍木每级 = 1 分",
				trueFriend: "每条完成的邻居轨 = 10 分",
				varietyPack: "每个集齐 5 类货物的档位 = 12 分"
			},
			badge: {
				basicWoods: "基础林地",
				basicMines: "基础矿洞",
				basicFishing: "基础垂钓",
				advWoods: "进阶林地",
				advMines: "进阶矿洞",
				advFishing: "进阶垂钓",
				plants: "作物",
				animals: "动物",
				generalist: "通才"
			},
			spot: {
				pond: "池塘",
				river: "河流",
				lake: "湖泊",
				grotto: "岩洞",
				geodeCard: "晶球"
			},
			animal: {
				chicken: "鸡",
				sheep: "驼",
				cow: "牛"
			},
			phaseSetup: "开局选卡",
			phaseNeighbor: "邻居阶段",
			phaseTask: "任务阶段",
			phaseGifts: "终局赠礼",
			phaseDone: "已结束",
			roundChip: "第 {{n}} 轮",
			seasonChip: "季节 {{n}}",
			scoringNow: "季节计分!",
			tabTasks: "任务",
			tabFarm: "农场",
			tabCargo: "货运",
			tabExplore: "探索",
			tabNeighbor: "邻居",
			journalLabel: "田野手账",
			cargoLabel: "天顶货运清单",
			rotateCargo: "旋转形状",
			woodsLabel: "树林刮刮纸",
			minesLabel: "矿洞刮刮纸",
			fishingLabel: "钓鱼生态卡",
			whiteDie: "白骰",
			blackDie: "黑骰",
			setupPrompt: "抽 4 张邻居卡:左右槽各留 1 张",
			setupLeft: "左邻居槽",
			setupRight: "右邻居槽",
			giftUse: "收下(选 1 资源)",
			giftPass: "转赠给下一家",
			giftPickGood: "选 1 份资源收下",
			redrawPrompt: "摸 2 张卡,选 1 张补回{{side}}槽",
			cycleCard: "换卡",
			neighborDone: "完成邻居阶段",
			waitingNeighbor: "等 {{name}} 处理邻居阶段…",
			nbTrackLeft: "左轨",
			nbTrackRight: "右轨",
			pickTasks: "从任务行选 2 张卡",
			waitingTask: "等 {{name}} 执行任务…",
			taskDone: "完成任务",
			finishActions: "提前结束本卡",
			useEnergy: "充能 +1 行动",
			energyEmpty: "没有可用充能",
			freeTaskPick: "选择要执行的自由行动",
			tendPlant: "种植",
			tendWater: "浇水",
			tendTill: "耕地(选 6 格)",
			tendPickCrop: "选择作物",
			tendPickSpot: "点农场放置",
			scratchPick: "点刮刮卡格子刮开",
			fishPickSpot: "选择钓点",
			fishDice: "骰点 {{a}} / {{b}}",
			fishPickCell: "点选区内 1 格钓鱼",
			fishLureAsk: "用鱼饵再钓 1 条?",
			geodeRoll: "晶球掷出 {{a}} / {{b}}",
			geodePickCell: "在晶球卡上选 1 格",
			placeAnimal: "放置{{name}}(需围栏闭合)",
			placeTrellis: "放置格架(空 2×2)",
			disposePrompt: "处置 {{name}}",
			disposeSell: "卖给企业站,获得 {{n}} 币",
			disposeCargo: "装入货舱",
			disposeCost: "填费用格",
			disposeGift: "赠给邻居",
			disposeGrounds: "换耕地/围栏",
			disposeSkip: "丢弃",
			queueLeft: "待处置 {{n}} 项",
			unlockRiver: "河流解锁",
			unlockLake: "湖泊解锁",
			unlockGrotto: "岩洞解锁",
			unlockRod: "钓竿升级",
			unlockLure: "鱼饵解锁",
			rewardFree: "自由行动",
			rewardAny: "任意主行动",
			rewardCross: "划 1 货物格",
			rewardCoins: "币",
			badgeShort: "徽章",
			medalShort: "奖章",
			pickOne: "选 1 项",
			rewardPickGood: "选 1 份资源",
			crossGoodPick: "点 1 个货物格免费划掉",
			groundsTitle: "场地维护(免费)",
			groundsCoin: "1 币可换 1 耕地或 1 围栏",
			bridge: "断桥",
			rod1: "钓竿 I",
			rod2: "钓竿 II",
			lureGreen: "绿树液饵",
			lureRed: "虹彩饵",
			equipTools: "园艺工具",
			equipHatchet: "斧升级",
			equipPickaxe: "镐升级",
			energyBar: "能量条",
			chopTrack: "砍木轨",
			mineTrack: "采矿轨",
			trellisArea: "格架",
			animalPen: "动物栏",
			cargoTitle: "货运舱",
			purchaseTitle: "单次购买",
			internTitle: "实习生(3 币换 1 次任意主行动)",
			explorerTitle: "资深探险家(徽章 VP 翻倍)",
			buybackTitle: "回购计划(3 币换 1 个徽章万能格)",
			stallN: "档位 {{n}}",
			badgeVp: "徽章 {{n}} 分",
			doubled: "×2",
			explorerReady: "可激活:任选一个已解锁徽章 VP 翻倍",
			sellTable: "企业站售价",
			scoreSeason: "季节 {{n}} 计分",
			scoreCargo: "货运舱",
			scoreBadge: "徽章",
			scoreNeighbor: "邻居轨",
			scoreTotal: "总分",
			neighborCompare: "对{{side}}邻居 +{{n}}",
			done: "完成",
			skip: "跳过",
			cancel: "取消",
			confirm: "确认",
			payCoins: "付 {{n}} 币",
			coins: "Z 币",
			optNoAdv: "移除进阶卡",
			optNoAdvOff: "关闭",
			optNoAdvOffHint: "完整 60 张任务卡",
			optNoAdvOn: "开启",
			optNoAdvOnHint: "移除 ADV 任务卡,首局推荐"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Tend",
			desc: "Alien-farm flip-and-write: tend crops, fish and mine, fill the cargo hold",
			rules: "Goal: run your alien farm for 12 rounds. Objectives, cargo hold, badges and neighbor tracks all score; highest total wins.\nEach round:\n· Neighbor phase: resolve gifts you received (take the 1 good shown on the card, or pass it along to the next neighbor); slots that gave a gift are refilled with a new card.\n· Task phase: pick 2 cards from the task row and resolve them.\n· On each card, choose 1 main action from the top half (tend/fish/chop/mine); if the condition is met, also gain the bottom-half reward.\n· Growth: your crop and animal dice advance 1 face; landing on a white face harvests.\nMain actions:\n· Tend: Plant crops, water crops, or till 6 plots.\n· Chop: Scratch 1–2 cells on the corresponding scratch card.\n· Mine: Scratch 1–2 cells on the corresponding scratch card.\n· Fish: Roll 2 dice and select a cell in the fishing grid.\nResources are not stored in an inventory. Whenever you gain a good, immediately choose one of the following:\n· Sell it.\n· Stow it in your cargo hold.\n· Spend it on a cost track.\n· Give it to a neighbor.\nScoring:\n· Score the current season’s objective in rounds 6, 10 and 12.\n· At the end of the game, add the points from your cargo hold and badges.\n· Compare neighbor tracks and gain 3 points for each space by which you lead.\nUnlocking areas:\nFill every cost space of a project to unlock that project. Completing the bridge unlocks the River. Scratching at least one space in the bottom row of the Woods unlocks the Lake; doing so in the Mines unlocks the Grotto.\nFull cargo rows or columns grant free actions; medals can be sold and also count toward badge progress.",
			err: {
				phase: "Not allowed in this phase",
				pending: "Resolve the current prompt first",
				queue: "Dispose of the first good in queue first",
				coins: "Not enough Z coins",
				cost: "This good cannot fill that cost slot",
				occupied: "Something is already there",
				fence: "Invalid fence placement",
				scratch: "Cannot scratch that cell",
				fish: "Invalid fishing move",
				cargo: "Does not fit in the cargo hold",
				card: "That card is not available"
			},
			good: {
				pineapple: "Pineapple",
				wildFruit: "Wild Fruit",
				pumpkin: "Pumpkin",
				berries: "Berries",
				egg: "Egg",
				wool: "Wool",
				milk: "Milk",
				mamble: "Mamble",
				sunpop: "Sunpop",
				blobber: "Blobber",
				geojell: "Geojell",
				pebblepuff: "Pebblepuff",
				crankle: "Crankle",
				nessel: "Nessel",
				lillybloom: "Lillybloom",
				orbble: "Orbble",
				plumfish: "Plumfish",
				shimmerpuff: "Shimmerpuff",
				gribble: "Gribble",
				stone: "Stone",
				copper: "Copper",
				iron: "Iron",
				artifact: "Artifact",
				bone: "Bone",
				ruby: "Ruby",
				crystal: "Crystal",
				rainbowRock: "Rainbow Rock",
				treeSap: "Tree Sap",
				redBp: "Red Blueprint",
				purpleBp: "Purple Blueprint",
				heart: "Heart",
				medalCopper: "Copper Medal",
				medalSilver: "Silver Medal",
				medalGold: "Gold Medal",
				medalPlatinum: "Platinum Medal",
				wood: "Wood",
				exoWood: "Exo Wood",
				geode: "Geode"
			},
			cat: {
				farm: "Farm",
				fish: "Fish",
				mining: "Mining",
				social: "Social",
				badge: "Badge"
			},
			mainTask: {
				tend: "Tend",
				fish: "Fish",
				chop: "Chop",
				mine: "Mine"
			},
			starter: {
				tend: "Tending",
				fish: "Fishing",
				chop: "Chopping",
				mine: "Mining",
				zenithOrders: "Zenith Orders"
			},
			task: {
				"s1-01": "Axe Miner",
				"s1-02": "Cave Fisher",
				"s1-03": "Energy Enthusiast",
				"s1-04": "Farm Clearer",
				"s1-05": "Farm Fisher",
				"s1-06": "Farm Miner",
				"s1-07": "Gatherer",
				"s1-08": "Grower",
				"s1-09": "Nature Collector",
				"s1-10": "Novice Collector",
				"s1-11": "Novice Fisher",
				"s1-12": "Novice Forager",
				"s1-13": "Novice Miner",
				"s1-14": "River Dredger",
				"s1-15": "River Fisher",
				"s1-16": "Shiny Collector",
				"s1-17": "Skilled Apprentice",
				"s1-18": "Skilled Fisher",
				"s1-19": "Social Butterfly",
				"s1-20": "Wood Scrapper",
				"s2-01": "Amateur Farmer",
				"s2-02": "Collector",
				"s2-03": "Cavern Grower",
				"s2-04": "Energizer",
				"s2-05": "Excavator",
				"s2-06": "Expert Fisher",
				"s2-07": "Extrovert",
				"s2-08": "Farm Excavator",
				"s2-09": "Farm Forester",
				"s2-10": "Furnisher",
				"s2-11": "Generalist Medal Earner",
				"s2-12": "Jack of All Trades",
				"s2-13": "Lumberjack Fisher",
				"s2-14": "Lure Master",
				"s2-15": "Medal Earner",
				"s2-16": "Pragmatist",
				"s2-17": "Project Dabbler",
				"s2-18": "Re-Tooler",
				"s2-19": "Secret Mine Fisher",
				"s2-20": "Woods Clearer",
				"s3-01": "Anti-Anti-Social",
				"s3-02": "Complete Builder",
				"s3-03": "Completist",
				"s3-04": "Delver",
				"s3-05": "Energy Monster",
				"s3-06": "Fish Hunter",
				"s3-07": "Fresh Farmer",
				"s3-08": "Geologist",
				"s3-09": "Grotto Fisher",
				"s3-10": "Kingfisher",
				"s3-11": "Lake Fisher",
				"s3-12": "Market Cultivator",
				"s3-13": "Market Delver",
				"s3-14": "Market Master",
				"s3-15": "Market Wizard",
				"s3-16": "Master Builder",
				"s3-17": "Master Farmer",
				"s3-18": "Research Badge Master",
				"s3-19": "Woods Explorer",
				"s3-20": "Woodsman"
			},
			obj: {
				clearer: "Clearer",
				cruncher: "Cruncher",
				edges: "Edges",
				leftSampler: "Left Sampler",
				loner: "Loner",
				medalBonus: "Medal Bonus",
				socialite: "Socialite",
				spacer: "Spacer",
				wideSpacer: "Wide Spacer",
				animalHandler: "Animal Handler",
				borders: "Borders",
				centerSampler: "Center Sampler",
				crossOver: "Cross Over",
				meritEarner: "Merit Earner",
				minimalist: "Minimalist",
				moderate: "Moderate",
				organizer: "Organizer",
				shrimp: "Shrimp",
				biggen: "Biggen",
				cargoMaster: "Cargo Master",
				centrist: "Centrist",
				lefty: "Lefty",
				packed: "Packed",
				righty: "Righty",
				seasonedWorker: "Seasoned Worker",
				trueFriend: "True Friend",
				varietyPack: "Variety Pack"
			},
			objDesc: {
				clearer: "2 pts per scratched cell in Woods + Mines",
				cruncher: "4 pts per unlocked energy bar",
				edges: "2 pts per covered edge cell of the cargo hold",
				leftSampler: "6 pts per distinct good in stall 1",
				loner: "3 pts per size-1 good",
				medalBonus: "5 pts per medal",
				socialite: "3 pts per neighbor request completed",
				spacer: "4 pts per size-1 empty region",
				wideSpacer: "5 pts per size-2 empty region",
				animalHandler: "5 pts per animal type + per unlocked fishing spot",
				borders: "15 pts if both side columns of the hold are full",
				centerSampler: "3 pts per distinct good in stall 2",
				crossOver: "4 pts per good spanning 2 stalls",
				meritEarner: "5 pts per unlocked badge",
				minimalist: "6 pts per size-3 empty region",
				moderate: "4 pts per size-3 good",
				organizer: "8 pts per completed column",
				shrimp: "4 pts per size-2 good",
				biggen: "4 pts per good of size 4 or more",
				cargoMaster: "8 pts per completed row",
				centrist: "20 pts if stall 2 is full",
				lefty: "20 pts if stall 1 is full",
				packed: "20 pts if every edge cell is covered",
				righty: "20 pts if stall 3 is full",
				seasonedWorker: "1 pt per mining + chopping level",
				trueFriend: "10 pts per completed neighbor track",
				varietyPack: "12 pts per stall with all 5 categories"
			},
			badge: {
				basicWoods: "Basic Woods",
				basicMines: "Basic Mines",
				basicFishing: "Basic Fishing",
				advWoods: "Adv. Woods",
				advMines: "Adv. Mines",
				advFishing: "Adv. Fishing",
				plants: "Plants",
				animals: "Animals",
				generalist: "Generalist"
			},
			spot: {
				pond: "Pond",
				river: "River",
				lake: "Lake",
				grotto: "Grotto",
				geodeCard: "Geode"
			},
			animal: {
				chicken: "Chicken",
				sheep: "Sheep",
				cow: "Cow"
			},
			phaseSetup: "Opening picks",
			phaseNeighbor: "Neighbor phase",
			phaseTask: "Task phase",
			phaseGifts: "Final gifts",
			phaseDone: "Game over",
			roundChip: "Round {{n}}",
			seasonChip: "Season {{n}}",
			scoringNow: "Season scoring!",
			tabTasks: "Tasks",
			tabFarm: "Farm",
			tabCargo: "Cargo",
			tabExplore: "Explore",
			tabNeighbor: "Neighbors",
			journalLabel: "Field Journal",
			cargoLabel: "Zenith Cargo Manifest",
			rotateCargo: "Rotate piece",
			woodsLabel: "Woods Scratch Card",
			minesLabel: "Mines Scratch Card",
			fishingLabel: "Fishing Habitat Card",
			whiteDie: "White die",
			blackDie: "Black die",
			setupPrompt: "Draw 4 neighbor cards: keep 1 for each side",
			setupLeft: "Left slot",
			setupRight: "Right slot",
			giftUse: "Keep (take 1 good)",
			giftPass: "Pass it along",
			giftPickGood: "Pick 1 good to keep",
			redrawPrompt: "Draw 2 cards, keep 1 for the {{side}} slot",
			cycleCard: "Swap",
			neighborDone: "Finish neighbor phase",
			waitingNeighbor: "Waiting for {{name}} (neighbors)…",
			nbTrackLeft: "Left track",
			nbTrackRight: "Right track",
			pickTasks: "Pick 2 cards from the task row",
			waitingTask: "Waiting for {{name}} (tasks)…",
			taskDone: "Finish tasks",
			finishActions: "End this card early",
			useEnergy: "Charge +1 action",
			energyEmpty: "No charges left",
			freeTaskPick: "Choose your free action",
			tendPlant: "Plant",
			tendWater: "Water",
			tendTill: "Till (pick 6 plots)",
			tendPickCrop: "Choose a crop",
			tendPickSpot: "Tap the farm to place",
			scratchPick: "Tap a cell to scratch",
			fishPickSpot: "Choose a fishing spot",
			fishDice: "Rolled {{a}} / {{b}}",
			fishPickCell: "Tap 1 cell in the area",
			fishLureAsk: "Use the lure for 1 more?",
			geodeRoll: "Geode rolled {{a}} / {{b}}",
			geodePickCell: "Pick 1 cell on the geode card",
			placeAnimal: "Place {{name}} (needs a closed pen)",
			placeTrellis: "Place trellis (empty 2×2)",
			disposePrompt: "Dispose of {{name}}",
			disposeSell: "Sell to the station for {{n}} coins",
			disposeCargo: "Stow in hold",
			disposeCost: "Fill a cost slot",
			disposeGift: "Gift to neighbor",
			disposeGrounds: "Till / fence",
			disposeSkip: "Discard",
			queueLeft: "{{n}} left to dispose",
			unlockRiver: "RIVER unlocked",
			unlockLake: "LAKE unlocked",
			unlockGrotto: "GROTTO unlocked",
			unlockRod: "Rod upgrade",
			unlockLure: "Lure unlocked",
			rewardFree: "Free",
			rewardAny: "Any main action",
			rewardCross: "Cross off 1 good",
			rewardCoins: "coins",
			badgeShort: "Badge",
			medalShort: "Medal",
			pickOne: "Pick 1",
			rewardPickGood: "Pick 1 good",
			crossGoodPick: "Tap 1 good slot to cross off for free",
			groundsTitle: "Groundskeeping (free)",
			groundsCoin: "1 coin buys 1 tilled plot or 1 fence",
			bridge: "Broken Bridge",
			rod1: "Rod I",
			rod2: "Rod II",
			lureGreen: "Tree Sap Lure",
			lureRed: "Rainbow Lure",
			equipTools: "Gardening Tools",
			equipHatchet: "Hatchet Upgrade",
			equipPickaxe: "Pickaxe Upgrade",
			energyBar: "Energy Bar",
			chopTrack: "Chop Track",
			mineTrack: "Mine Track",
			trellisArea: "Trellises",
			animalPen: "Animal Pens",
			cargoTitle: "Cargo Hold",
			purchaseTitle: "One-time Purchases",
			internTitle: "Intern (3 coins for any main action)",
			explorerTitle: "Seasoned Explorer (double a badge VP)",
			explorerReady: "Ready: double any one unlocked badge's VP",
			buybackTitle: "Buyback Program (3 coins for a wild badge slot)",
			stallN: "Stall {{n}}",
			badgeVp: "Badge {{n}} VP",
			doubled: "×2",
			sellTable: "Zenith station prices",
			scoreSeason: "Season {{n}} scoring",
			scoreCargo: "Cargo",
			scoreBadge: "Badges",
			scoreNeighbor: "Neighbor tracks",
			scoreTotal: "Total",
			neighborCompare: "vs {{side}} neighbor +{{n}}",
			done: "Done",
			skip: "Skip",
			cancel: "Cancel",
			confirm: "Confirm",
			payCoins: "Pay {{n}}",
			coins: "Z coins",
			optNoAdv: "Remove ADV cards",
			optNoAdvOff: "Off",
			optNoAdvOffHint: "Full 60-card task deck",
			optNoAdvOn: "On",
			optNoAdvOnHint: "Remove ADV task cards; recommended first game"
		}
	}
};
//#endregion
export { Pr as default };
