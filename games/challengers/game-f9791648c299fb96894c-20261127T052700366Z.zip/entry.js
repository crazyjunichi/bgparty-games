import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { AVATARS as r } from "@bgparty/sdk/avatars";
import { botAvatarOf as i } from "@bgparty/sdk/lobby";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as o, useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { IconClose as d } from "@bgparty/sdk/icons";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { botPersonality as h } from "@bgparty/sdk/bot-personality";
import { Floater as g, FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { PLAYER_COLORS as y } from "@bgparty/sdk/player-colors";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region src/game/cards.ts
var x = (e) => e, S = (e, t) => e.bench.some((e) => {
	let n = E.get(e.card);
	return !!n && t(n);
}), C = (e, t) => e.bench.reduce((e, n) => {
	let r = E.get(n.card);
	return r && t(r) ? e + n.count : e;
}, 0), w = (e) => E.get(e)?.power ?? 0, T = (e) => E.get(e)?.set, ee = [
	"start_newcomer",
	"start_newcomer",
	"start_newcomer",
	"start_talent",
	"start_dog",
	"start_champion"
], te = [
	x({
		id: "start_newcomer",
		set: "city",
		level: "S",
		power: 1,
		copies: 0,
		emoji: "🧍",
		nameKey: "games.challengers.cards.newcomer.name",
		textKey: null
	}),
	x({
		id: "start_talent",
		set: "city",
		level: "S",
		power: 2,
		copies: 0,
		emoji: "🎤",
		nameKey: "games.challengers.cards.talent.name",
		textKey: null
	}),
	x({
		id: "start_dog",
		set: "city",
		level: "S",
		power: 3,
		copies: 0,
		emoji: "🐕",
		nameKey: "games.challengers.cards.dog.name",
		textKey: null
	}),
	x({
		id: "start_champion",
		set: "city",
		level: "S",
		power: 4,
		copies: 0,
		emoji: "🏅",
		nameKey: "games.challengers.cards.champion.name",
		textKey: null
	}),
	x({
		id: "city_reporter",
		set: "city",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "🎙️",
		nameKey: "games.challengers.cards.reporter.name",
		textKey: "games.challengers.cards.reporter.text",
		onReveal: (e) => e.ask({
			kind: "sink",
			min: 1,
			max: 1
		})
	}),
	x({
		id: "city_talent",
		set: "city",
		level: "A",
		power: 2,
		copies: 3,
		emoji: "🎤",
		nameKey: "games.challengers.cards.talent.name",
		textKey: null
	}),
	x({
		id: "city_mascot",
		set: "city",
		level: "B",
		power: 2,
		copies: 4,
		emoji: "📣",
		nameKey: "games.challengers.cards.mascot.name",
		textKey: "games.challengers.cards.mascot.text",
		bonusSelf: (e) => new Set(e.bench.map((e) => E.get(e.card)?.set)).size
	}),
	x({
		id: "city_dog",
		set: "city",
		level: "B",
		power: 3,
		copies: 3,
		emoji: "🐕",
		nameKey: "games.challengers.cards.dog.name",
		textKey: null
	}),
	x({
		id: "city_fanbus",
		set: "city",
		level: "C",
		power: 6,
		copies: 4,
		emoji: "🚌",
		nameKey: "games.challengers.cards.fanbus.name",
		textKey: "games.challengers.cards.fanbus.text",
		onReveal: (e, t) => {
			t.trophies <= 3 && e.gainFans(2);
		}
	}),
	x({
		id: "city_champion",
		set: "city",
		level: "C",
		power: 4,
		copies: 2,
		emoji: "🏅",
		nameKey: "games.challengers.cards.champion.name",
		textKey: null
	}),
	x({
		id: "castle_jester",
		set: "castle",
		level: "A",
		power: 1,
		copies: 4,
		emoji: "🃏",
		nameKey: "games.challengers.cards.jester.name",
		textKey: "games.challengers.cards.jester.text",
		bonusSelf: (e) => S(e, (e) => e.power === 1) ? 3 : 0
	}),
	x({
		id: "castle_stableboy",
		set: "castle",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "🧹",
		nameKey: "games.challengers.cards.stableboy.name",
		textKey: "games.challengers.cards.stableboy.text",
		bonusSelf: (e) => C(e, (e) => e.power === 3)
	}),
	x({
		id: "castle_hermit",
		set: "castle",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "🛖",
		nameKey: "games.challengers.cards.hermit.name",
		textKey: "games.challengers.cards.hermit.text",
		bonusSelf: (e) => S(e, (e) => e.set === "castle") ? 0 : 2
	}),
	x({
		id: "castle_pig",
		set: "castle",
		level: "A",
		power: 3,
		copies: 3,
		emoji: "🐷",
		nameKey: "games.challengers.cards.pig.name",
		textKey: null
	}),
	x({
		id: "castle_blacksmith",
		set: "castle",
		level: "B",
		power: 3,
		copies: 4,
		emoji: "⚒️",
		nameKey: "games.challengers.cards.blacksmith.name",
		textKey: "games.challengers.cards.blacksmith.text",
		benchPower: (e, t) => +(T(t) === "castle")
	}),
	x({
		id: "castle_knight",
		set: "castle",
		level: "B",
		power: 3,
		copies: 4,
		emoji: "🛡️",
		nameKey: "games.challengers.cards.knight.name",
		textKey: "games.challengers.cards.knight.text",
		attackPower: (e) => e.oppTrophies
	}),
	x({
		id: "castle_sorcerer",
		set: "castle",
		level: "B",
		power: 4,
		copies: 4,
		emoji: "🪄",
		nameKey: "games.challengers.cards.sorcerer.name",
		textKey: "games.challengers.cards.sorcerer.text",
		onReveal: (e) => e.ask({
			kind: "benchExhaust",
			min: 0,
			max: 1,
			maxPower: 3
		})
	}),
	x({
		id: "castle_horse",
		set: "castle",
		level: "B",
		power: 5,
		copies: 3,
		emoji: "🐴",
		nameKey: "games.challengers.cards.horse.name",
		textKey: null
	}),
	x({
		id: "castle_bard",
		set: "castle",
		level: "C",
		power: 4,
		copies: 4,
		emoji: "🎻",
		nameKey: "games.challengers.cards.bard.name",
		textKey: "games.challengers.cards.bard.text",
		benchPower: (e, t, n) => +(n === "attack")
	}),
	x({
		id: "castle_prince",
		set: "castle",
		level: "C",
		power: 5,
		copies: 4,
		emoji: "🤴",
		nameKey: "games.challengers.cards.prince.name",
		textKey: "games.challengers.cards.prince.text",
		flagLossDest: "exhaust"
	}),
	x({
		id: "castle_dragon",
		set: "castle",
		level: "C",
		power: 7,
		copies: 2,
		emoji: "🐉",
		nameKey: "games.challengers.cards.dragon.name",
		textKey: null
	}),
	x({
		id: "film_makeup",
		set: "film",
		level: "A",
		power: 1,
		copies: 4,
		emoji: "💄",
		nameKey: "games.challengers.cards.makeup.name",
		textKey: "games.challengers.cards.makeup.text",
		benchPower: (e, t, n) => n === "attack" && w(t) === 1 ? 2 : 0
	}),
	x({
		id: "film_moviestar",
		set: "film",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "⭐",
		nameKey: "games.challengers.cards.moviestar.name",
		textKey: "games.challengers.cards.moviestar.text",
		onReveal: (e) => e.ask({
			kind: "benchTop",
			min: 0,
			max: 2,
			sameNameAs: "start_newcomer"
		})
	}),
	x({
		id: "film_gangster",
		set: "film",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "🕴️",
		nameKey: "games.challengers.cards.gangster.name",
		textKey: "games.challengers.cards.gangster.text",
		attackPower: () => 2
	}),
	x({
		id: "film_cat",
		set: "film",
		level: "A",
		power: 3,
		copies: 3,
		emoji: "🐈",
		nameKey: "games.challengers.cards.cat.name",
		textKey: null
	}),
	x({
		id: "film_cowboy",
		set: "film",
		level: "B",
		power: 3,
		copies: 4,
		emoji: "🤠",
		nameKey: "games.challengers.cards.cowboy.name",
		textKey: "games.challengers.cards.cowboy.text",
		onFlagGain: (e) => {
			let t = e.oppDeck.pop();
			t && !e.benchCard(e.oppBench, t) && e.oppExhausted.push(t);
		}
	}),
	x({
		id: "film_director",
		set: "film",
		level: "B",
		power: 4,
		copies: 4,
		emoji: "🎬",
		nameKey: "games.challengers.cards.director.name",
		textKey: "games.challengers.cards.director.text",
		benchPower: (e, t, n) => +(n === "attack" && T(t) === "film")
	}),
	x({
		id: "film_comic",
		set: "film",
		level: "B",
		power: 4,
		copies: 4,
		emoji: "💥",
		nameKey: "games.challengers.cards.comic.name",
		textKey: "games.challengers.cards.comic.text",
		onFlagLoss: (e) => e.addPendingBonus(2)
	}),
	x({
		id: "film_lion",
		set: "film",
		level: "B",
		power: 5,
		copies: 3,
		emoji: "🦁",
		nameKey: "games.challengers.cards.lion.name",
		textKey: null
	}),
	x({
		id: "film_heroine",
		set: "film",
		level: "C",
		power: 5,
		copies: 4,
		emoji: "🦸",
		nameKey: "games.challengers.cards.heroine.name",
		textKey: "games.challengers.cards.heroine.text",
		onFlagGain: (e) => e.gainFans(3)
	}),
	x({
		id: "film_villain",
		set: "film",
		level: "C",
		power: 10,
		copies: 4,
		emoji: "🦹",
		nameKey: "games.challengers.cards.villain.name",
		textKey: "games.challengers.cards.villain.text",
		onReveal: (e) => {
			let t = e.drawPile("A");
			t && e.selfDeck.push(t);
		}
	}),
	x({
		id: "film_trex",
		set: "film",
		level: "C",
		power: 7,
		copies: 2,
		emoji: "🦖",
		nameKey: "games.challengers.cards.trex.name",
		textKey: null
	}),
	x({
		id: "funfair_clown",
		set: "funfair",
		level: "A",
		power: 1,
		copies: 4,
		emoji: "🤡",
		nameKey: "games.challengers.cards.clown.name",
		textKey: "games.challengers.cards.clown.text",
		onFlagGain: (e) => e.gainFans(2)
	}),
	x({
		id: "funfair_juggler",
		set: "funfair",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "🤹",
		nameKey: "games.challengers.cards.juggler.name",
		textKey: "games.challengers.cards.juggler.text",
		onReveal: (e) => e.ask({
			kind: "order",
			min: 3,
			max: 3
		})
	}),
	x({
		id: "funfair_vendor",
		set: "funfair",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "🍿",
		nameKey: "games.challengers.cards.vendor.name",
		textKey: "games.challengers.cards.vendor.text",
		benchPower: (e, t) => +(T(t) === "funfair")
	}),
	x({
		id: "funfair_pony",
		set: "funfair",
		level: "A",
		power: 3,
		copies: 3,
		emoji: "🎠",
		nameKey: "games.challengers.cards.pony.name",
		textKey: null
	}),
	x({
		id: "funfair_pyro",
		set: "funfair",
		level: "A",
		power: 4,
		copies: 4,
		emoji: "🎆",
		nameKey: "games.challengers.cards.pyro.name",
		textKey: "games.challengers.cards.pyro.text",
		onReveal: (e, t) => {
			t.deckCount <= 1 && e.gainFans(2);
		}
	}),
	x({
		id: "funfair_mime",
		set: "funfair",
		level: "B",
		power: 1,
		copies: 4,
		emoji: "🎭",
		nameKey: "games.challengers.cards.mime.name",
		textKey: "games.challengers.cards.mime.text",
		bonusSelf: (e) => e.emptySeats
	}),
	x({
		id: "funfair_clairvoyant",
		set: "funfair",
		level: "B",
		power: 4,
		copies: 4,
		emoji: "🔮",
		nameKey: "games.challengers.cards.clairvoyant.name",
		textKey: "games.challengers.cards.clairvoyant.text",
		onFlagLoss: (e) => e.ask({
			kind: "deckTop",
			min: 1,
			max: 1
		})
	}),
	x({
		id: "funfair_duck",
		set: "funfair",
		level: "B",
		power: 5,
		copies: 3,
		emoji: "🦆",
		nameKey: "games.challengers.cards.duck.name",
		textKey: null
	}),
	x({
		id: "funfair_illusionist",
		set: "funfair",
		level: "C",
		power: 5,
		copies: 4,
		emoji: "🎩",
		nameKey: "games.challengers.cards.illusionist.name",
		textKey: "games.challengers.cards.illusionist.text",
		flagPower: (e) => e.emptySeats
	}),
	x({
		id: "funfair_bumper",
		set: "funfair",
		level: "C",
		power: 6,
		copies: 4,
		emoji: "🚗",
		nameKey: "games.challengers.cards.bumper.name",
		textKey: "games.challengers.cards.bumper.text",
		onReveal: (e) => e.ask({
			kind: "order",
			min: 3,
			max: 3
		})
	}),
	x({
		id: "funfair_teddy",
		set: "funfair",
		level: "C",
		power: 7,
		copies: 2,
		emoji: "🧸",
		nameKey: "games.challengers.cards.teddy.name",
		textKey: null
	}),
	x({
		id: "haunted_butler",
		set: "haunted",
		level: "A",
		power: 1,
		copies: 4,
		emoji: "🤵",
		nameKey: "games.challengers.cards.butler.name",
		textKey: "games.challengers.cards.butler.text",
		onReveal: (e) => e.ask({
			kind: "benchExhaust",
			min: 0,
			max: 2
		})
	}),
	x({
		id: "haunted_skeleton",
		set: "haunted",
		level: "A",
		power: 2,
		copies: 8,
		emoji: "💀",
		nameKey: "games.challengers.cards.skeleton.name",
		textKey: "games.challengers.cards.skeleton.text",
		flagPower: () => 1
	}),
	x({
		id: "haunted_spider",
		set: "haunted",
		level: "A",
		power: 3,
		copies: 3,
		emoji: "🕷️",
		nameKey: "games.challengers.cards.spider.name",
		textKey: null
	}),
	x({
		id: "haunted_ghost",
		set: "haunted",
		level: "B",
		power: 1,
		copies: 4,
		emoji: "👻",
		nameKey: "games.challengers.cards.ghost.name",
		textKey: "games.challengers.cards.ghost.text",
		onReveal: (e) => {
			let t = e.oppDeck.pop();
			t && e.oppExhausted.push(t);
		}
	}),
	x({
		id: "haunted_teenager",
		set: "haunted",
		level: "B",
		power: 2,
		copies: 4,
		emoji: "🛹",
		nameKey: "games.challengers.cards.teenager.name",
		textKey: "games.challengers.cards.teenager.text",
		bonusSelf: (e) => C(e, (e) => e.set === "haunted")
	}),
	x({
		id: "haunted_necromancer",
		set: "haunted",
		level: "B",
		power: 3,
		copies: 4,
		emoji: "⚰️",
		nameKey: "games.challengers.cards.necromancer.name",
		textKey: "games.challengers.cards.necromancer.text",
		onReveal: (e) => e.ask({
			kind: "benchTop",
			min: 1,
			max: 1,
			power: 2
		})
	}),
	x({
		id: "haunted_bat",
		set: "haunted",
		level: "B",
		power: 5,
		copies: 3,
		emoji: "🦇",
		nameKey: "games.challengers.cards.bat.name",
		textKey: null
	}),
	x({
		id: "haunted_vampire",
		set: "haunted",
		level: "C",
		power: 4,
		copies: 4,
		emoji: "🧛",
		nameKey: "games.challengers.cards.vampire.name",
		textKey: "games.challengers.cards.vampire.text",
		onReveal: (e) => e.ask({
			kind: "benchTop",
			min: 1,
			max: 1,
			level: "B"
		})
	}),
	x({
		id: "haunted_vacuum",
		set: "haunted",
		level: "C",
		power: 5,
		copies: 4,
		emoji: "🌀",
		nameKey: "games.challengers.cards.vacuum.name",
		textKey: "games.challengers.cards.vacuum.text",
		onReveal: (e) => e.ask({
			kind: "benchExhaust",
			min: 0,
			max: 2
		})
	}),
	x({
		id: "haunted_werewolf",
		set: "haunted",
		level: "C",
		power: 7,
		copies: 2,
		emoji: "🐺",
		nameKey: "games.challengers.cards.werewolf.name",
		textKey: null
	}),
	x({
		id: "space_rescuepod",
		set: "space",
		level: "A",
		power: 1,
		copies: 4,
		emoji: "🚀",
		nameKey: "games.challengers.cards.rescuepod.name",
		textKey: "games.challengers.cards.rescuepod.text",
		flagLossDest: "exhaust",
		onFlagLoss: (e) => {
			let t = e.drawPile("B");
			t && e.selfExhausted.push(t);
		}
	}),
	x({
		id: "space_shapeshifter",
		set: "space",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "🫥",
		nameKey: "games.challengers.cards.shapeshifter.name",
		textKey: "games.challengers.cards.shapeshifter.text",
		onPick: "offerAny1"
	}),
	x({
		id: "space_ai",
		set: "space",
		level: "A",
		power: 2,
		copies: 3,
		emoji: "🤖",
		nameKey: "games.challengers.cards.ai.name",
		textKey: "games.challengers.cards.ai.text",
		benchPower: (e, t) => +(w(t) === 2)
	}),
	x({
		id: "space_cow",
		set: "space",
		level: "A",
		power: 3,
		copies: 3,
		emoji: "🐄",
		nameKey: "games.challengers.cards.cow.name",
		textKey: null
	}),
	x({
		id: "space_band",
		set: "space",
		level: "B",
		power: 3,
		copies: 4,
		emoji: "🥁",
		nameKey: "games.challengers.cards.band.name",
		textKey: "games.challengers.cards.band.text",
		benchPower: (e, t) => +(T(t) === "space")
	}),
	x({
		id: "space_ufo",
		set: "space",
		level: "B",
		power: 3,
		copies: 4,
		emoji: "🛸",
		nameKey: "games.challengers.cards.ufo.name",
		textKey: "games.challengers.cards.ufo.text",
		onReveal: (e) => {
			let t = e.drawPile("A");
			t && e.selfDeck.unshift(t);
			let n = e.drawPile("A");
			n && e.selfDeck.splice(1, 0, n);
		}
	}),
	x({
		id: "space_clones",
		set: "space",
		level: "B",
		power: 4,
		copies: 5,
		emoji: "👯",
		nameKey: "games.challengers.cards.clones.name",
		textKey: "games.challengers.cards.clones.text",
		onPick: "fans1"
	}),
	x({
		id: "space_alien",
		set: "space",
		level: "B",
		power: 5,
		copies: 3,
		emoji: "👽",
		nameKey: "games.challengers.cards.alien.name",
		textKey: null
	}),
	x({
		id: "space_hologram",
		set: "space",
		level: "C",
		power: 4,
		copies: 4,
		emoji: "🔷",
		nameKey: "games.challengers.cards.hologram.name",
		textKey: "games.challengers.cards.hologram.text",
		onReveal: (e) => {
			let t = e.drawPile("B");
			t && e.oppDeck.push(t);
		}
	}),
	x({
		id: "space_scifigeek",
		set: "space",
		level: "C",
		power: 6,
		copies: 4,
		emoji: "🤓",
		nameKey: "games.challengers.cards.scifigeek.name",
		textKey: "games.challengers.cards.scifigeek.text",
		onPick: "offerSpace2"
	}),
	x({
		id: "space_slime",
		set: "space",
		level: "C",
		power: 7,
		copies: 2,
		emoji: "🫧",
		nameKey: "games.challengers.cards.slime.name",
		textKey: null
	}),
	x({
		id: "ship_merman",
		set: "shipwreck",
		level: "A",
		power: 1,
		copies: 4,
		emoji: "🧜",
		nameKey: "games.challengers.cards.merman.name",
		textKey: "games.challengers.cards.merman.text",
		bonusSelf: (e) => S(e, (e) => e.set === "shipwreck") ? 3 : 0
	}),
	x({
		id: "ship_treasure",
		set: "shipwreck",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "💰",
		nameKey: "games.challengers.cards.treasure.name",
		textKey: "games.challengers.cards.treasure.text",
		flagPower: () => 2
	}),
	x({
		id: "ship_sailor",
		set: "shipwreck",
		level: "A",
		power: 2,
		copies: 4,
		emoji: "⛵",
		nameKey: "games.challengers.cards.sailor.name",
		textKey: "games.challengers.cards.sailor.text",
		onReveal: (e) => e.ask({
			kind: "deckBottom",
			min: 1,
			max: 1
		})
	}),
	x({
		id: "ship_parrot",
		set: "shipwreck",
		level: "A",
		power: 3,
		copies: 3,
		emoji: "🦜",
		nameKey: "games.challengers.cards.parrot.name",
		textKey: null
	}),
	x({
		id: "ship_cook",
		set: "shipwreck",
		level: "B",
		power: 2,
		copies: 4,
		emoji: "🍳",
		nameKey: "games.challengers.cards.cook.name",
		textKey: "games.challengers.cards.cook.text",
		benchPower: (e, t, n) => +(n === "flag")
	}),
	x({
		id: "ship_lifeguard",
		set: "shipwreck",
		level: "B",
		power: 4,
		copies: 4,
		emoji: "🛟",
		nameKey: "games.challengers.cards.lifeguard.name",
		textKey: "games.challengers.cards.lifeguard.text",
		bonusSelf: (e) => e.deckCount <= 1 ? 2 : 0
	}),
	x({
		id: "ship_navigator",
		set: "shipwreck",
		level: "B",
		power: 4,
		copies: 4,
		emoji: "🧭",
		nameKey: "games.challengers.cards.navigator.name",
		textKey: "games.challengers.cards.navigator.text",
		onFlagLoss: (e) => e.ask({
			kind: "sink",
			min: 1,
			max: 1
		})
	}),
	x({
		id: "ship_shark",
		set: "shipwreck",
		level: "B",
		power: 5,
		copies: 3,
		emoji: "🦈",
		nameKey: "games.challengers.cards.shark.name",
		textKey: null
	}),
	x({
		id: "ship_siren",
		set: "shipwreck",
		level: "C",
		power: 6,
		copies: 4,
		emoji: "🎶",
		nameKey: "games.challengers.cards.siren.name",
		textKey: "games.challengers.cards.siren.text",
		onReveal: (e) => e.ask({
			kind: "oppBenchExhaust",
			min: 0,
			max: 1
		})
	}),
	x({
		id: "ship_kraken",
		set: "shipwreck",
		level: "C",
		power: 7,
		copies: 2,
		emoji: "🐙",
		nameKey: "games.challengers.cards.kraken.name",
		textKey: null
	}),
	x({
		id: "ship_submarine",
		set: "shipwreck",
		level: "C",
		power: 9,
		copies: 4,
		emoji: "🌊",
		nameKey: "games.challengers.cards.submarine.name",
		textKey: "games.challengers.cards.submarine.text",
		onReveal: (e) => {
			let t = e.selfDeck.shift();
			t && e.selfExhausted.push(t);
		}
	})
], E = new Map(te.map((e) => [e.id, e])), D = [
	{
		id: "city",
		emoji: "🏙️",
		nameKey: "games.challengers.sets.city"
	},
	{
		id: "castle",
		emoji: "🏰",
		nameKey: "games.challengers.sets.castle"
	},
	{
		id: "film",
		emoji: "🎬",
		nameKey: "games.challengers.sets.film"
	},
	{
		id: "funfair",
		emoji: "🎡",
		nameKey: "games.challengers.sets.funfair"
	},
	{
		id: "haunted",
		emoji: "👻",
		nameKey: "games.challengers.sets.haunted"
	},
	{
		id: "space",
		emoji: "🚀",
		nameKey: "games.challengers.sets.space"
	},
	{
		id: "shipwreck",
		emoji: "⚓",
		nameKey: "games.challengers.sets.shipwreck"
	}
], O = (e) => e === "a" ? "b" : "a";
function k(e, t) {
	return {
		rid: e,
		deck: t,
		bench: [],
		flagStack: [],
		attackPile: [],
		exhausted: [],
		pendingBonus: 0
	};
}
function A(e, t, n) {
	return {
		bench: e.bench,
		flagStack: e.flagStack.map((e) => e.card),
		attackPile: e.attackPile.map((e) => e.card),
		oppBench: t.bench,
		oppFlag: t.flagStack.length ? t.flagStack[t.flagStack.length - 1].card : null,
		deckCount: e.deck.length,
		emptySeats: 6 - e.bench.length,
		round: n.round,
		trophies: n.trophies[e.rid] ?? 0,
		oppTrophies: n.trophies[t.rid] ?? 0,
		fans: n.fans,
		selfRid: e.rid,
		oppRid: t.rid
	};
}
var ne = (e, t) => E.get(e)?.nameKey === E.get(t)?.nameKey;
function re(e, t) {
	return e.find((e) => ne(e.card, t));
}
function ie(e, t) {
	let n = re(e, t);
	return n ? (n.count += 1, !0) : e.length >= 6 ? !1 : (e.push({
		card: t,
		count: 1
	}), !0);
}
function j(e, t) {
	let n = e.findIndex((e) => e.card === t);
	return n < 0 ? !1 : (--e[n].count, e[n].count <= 0 && e.splice(n, 1), !0);
}
function ae(e, t, n) {
	let r = 0;
	for (let i of e.bench) {
		let a = E.get(i.card);
		a?.benchPower && (r += a.benchPower(e, t, n) * i.count);
	}
	return r;
}
function oe(e, t, n) {
	let r = e[t], i = r.flagStack[r.flagStack.length - 1];
	if (!i) return 0;
	let a = E.get(i.card);
	if (!a) return i.bonus;
	let o = A(r, e[O(t)], n);
	return a.power + i.bonus + (a.flagPower?.(o) ?? 0) + ae(o, i.card, "flag");
}
function se(e, t, n) {
	let r = e[t], i = A(r, e[O(t)], n), a = 0;
	for (let e of r.attackPile) {
		let t = E.get(e.card);
		t && (a += t.power + e.bonus + (t.attackPower?.(i) ?? 0) + ae(i, e.card, "attack"));
	}
	return a;
}
var M = class {
	m;
	sideKey;
	env;
	events;
	constructor(e, t, n, r) {
		this.m = e, this.sideKey = t, this.env = n, this.events = r;
	}
	get selfDeck() {
		return this.m[this.sideKey].deck;
	}
	get oppDeck() {
		return this.m[O(this.sideKey)].deck;
	}
	get selfBench() {
		return this.m[this.sideKey].bench;
	}
	get oppBench() {
		return this.m[O(this.sideKey)].bench;
	}
	get selfExhausted() {
		return this.m[this.sideKey].exhausted;
	}
	get oppExhausted() {
		return this.m[O(this.sideKey)].exhausted;
	}
	gainFans(e) {
		let t = this.m[this.sideKey].rid;
		this.events.fans[t] = (this.events.fans[t] ?? 0) + e;
	}
	drawPile(e) {
		return this.env.drawPile(e);
	}
	addPendingBonus(e) {
		this.m[this.sideKey].pendingBonus += e;
	}
	benchCard(e, t) {
		return ie(e, t);
	}
	ask(e) {
		let t = ce(this.m, this.sideKey, e);
		t && (this.m.pending = t);
	}
};
function ce(e, t, n) {
	let r = e[t], i = e[O(t)], a = (e) => {
		let t = E.get(e);
		return !(!t || n.power !== void 0 && t.power !== n.power || n.maxPower !== void 0 && t.power > n.maxPower || n.level !== void 0 && t.level !== n.level || n.sameNameAs !== void 0 && t.nameKey !== E.get(n.sameNameAs)?.nameKey);
	}, o = (e) => e.flatMap((e) => Array.from({ length: e.count }, () => e.card)).filter(a), s;
	if (n.kind === "order") {
		let e = Math.min(n.max, r.deck.length);
		return e <= 1 ? null : (s = r.deck.slice(-e).reverse(), {
			side: t,
			kind: n.kind,
			cards: s,
			min: e,
			max: e
		});
	}
	if (n.kind === "sink") {
		if (r.deck.length < 2) return null;
		s = r.deck.slice(-2).reverse();
	} else s = n.kind === "deckBottom" || n.kind === "deckTop" ? [...r.deck] : n.kind === "benchExhaust" || n.kind === "benchTop" ? o(r.bench) : o(i.bench);
	return s.length < n.min ? null : {
		side: t,
		kind: n.kind,
		cards: s,
		min: n.min,
		max: Math.min(n.max, s.length)
	};
}
function le(e, t, n) {
	let r = e.pending;
	if (!r || e[r.side].rid !== t || e.done) return !1;
	if (r.kind === "order") {
		if (n.length !== r.cards.length) return !1;
	} else if (n.length < r.min || n.length > r.max) return !1;
	let i = /* @__PURE__ */ new Map();
	for (let e of r.cards) i.set(e, (i.get(e) ?? 0) + 1);
	for (let e of n) {
		let t = i.get(e) ?? 0;
		if (t <= 0) return !1;
		i.set(e, t - 1);
	}
	let a = e[r.side], o = e[O(r.side)];
	if (r.kind === "order") e[r.side].deck.splice(a.deck.length - n.length, n.length, ...[...n].reverse());
	else if (r.kind === "sink") {
		let e = a.deck.splice(-2);
		e.splice(e.indexOf(n[0]), 1), a.deck.unshift(n[0]), a.deck.push(e[0]);
	} else if (r.kind === "deckBottom") a.deck.splice(a.deck.indexOf(n[0]), 1), a.deck.unshift(n[0]);
	else if (r.kind === "deckTop") a.deck.splice(a.deck.indexOf(n[0]), 1), a.deck.push(n[0]);
	else if (r.kind === "benchExhaust") for (let e of n) j(a.bench, e) && a.exhausted.push(e);
	else if (r.kind === "benchTop") for (let e of n) j(a.bench, e) && a.deck.push(e);
	else for (let e of n) j(o.bench, e) && o.exhausted.push(e);
	return e.pending = null, !0;
}
function ue(e, t, n, r, i, a, o) {
	let s = r[n], c = E.get(t), l = A(s, r[O(n)], i), u = c?.bonusSelf?.(l) ?? 0;
	return o && s.pendingBonus > 0 && (u += s.pendingBonus, s.pendingBonus = 0), e.push({
		card: t,
		bonus: u
	}), c?.onReveal && c.onReveal(new M(r, n, i, a), A(s, r[O(n)], i)), c;
}
function de(e, t) {
	let n = 0;
	for (let r of new Set(t)) re(e, r) || (n += 1);
	return e.length + n <= 6;
}
var N = () => ({ fans: {} });
function P(e, t, n, r, i) {
	return e.done = !0, e.winner = t, e.loseReason = n, i.push({
		kind: "matchEnd",
		data: {
			winner: e[t].rid,
			loser: e[O(t)].rid,
			reason: n
		}
	}), {
		fx: i,
		events: r
	};
}
function fe(e, t, n, r, i) {
	let a = e[t], o = e[O(t)], s = o.flagStack, c = s[s.length - 1], l = E.get(c.card);
	l?.onFlagLoss && l.onFlagLoss(new M(e, O(t), n, r), A(o, a, n));
	let u = l?.flagLossDest === "exhaust" ? s.slice(0, -1) : s;
	if (l?.flagLossDest === "exhaust" && o.exhausted.push(c.card), !de(o.bench, u.map((e) => e.card))) return P(e, t, "benchFull", r, i);
	for (let { card: e } of u) ie(o.bench, e);
	o.flagStack = [], a.flagStack = a.attackPile, a.attackPile = [], e.flag = t;
	let d = a.flagStack[a.flagStack.length - 1];
	i.push({
		kind: "flagChange",
		data: {
			rid: a.rid,
			side: t,
			loserSide: O(t),
			card: d.card,
			lost: u.map((e) => e.card)
		}
	});
	let f = E.get(d.card);
	return f?.onFlagGain && f.onFlagGain(new M(e, t, n, r), A(a, o, n)), {
		fx: i,
		events: r
	};
}
function pe(e, t) {
	let n = N();
	if (e.pending || e.flag === null) return {
		fx: [],
		events: n
	};
	let r = O(e.flag), i = e.flag, a = e[r], o = [], s = () => a.attackPile.length > 0 && se(e, r, t) >= oe(e, i, t);
	if (s()) return fe(e, r, t, n, o);
	let c = a.deck.pop();
	if (c === void 0) return P(e, i, "deckOut", n, o);
	let l = ue(a.attackPile, c, r, e, t, n, !0);
	return o.push({
		kind: "reveal",
		data: {
			rid: a.rid,
			side: r,
			card: c,
			effect: !!l?.onReveal,
			lethal: s()
		}
	}), e.pending ? {
		fx: o,
		events: n
	} : a.deck.length === 0 && !s() ? P(e, i, "deckOut", n, o) : {
		fx: o,
		events: n
	};
}
function me(e, t, n) {
	let r = e[t], i = N(), a = r.deck.pop();
	if (a === void 0) return P(e, O(t), "deckOut", i, []);
	let o = ue(r.flagStack, a, t, e, n, i, !1);
	return e.flag = t, o?.onFlagGain && o.onFlagGain(new M(e, t, n, i), A(r, e[O(t)], n)), {
		fx: [{
			kind: "flagStart",
			data: {
				rid: r.rid,
				side: t,
				card: a,
				effect: !!o?.onReveal
			}
		}],
		events: i
	};
}
//#endregion
//#region src/game/meta.ts
var F = {
	id: "challengers",
	uuid: "7f8211be-d0f7-4d76-93db-bbc8b41defa4",
	tier: "beta",
	mechanics: ["deck-bag-building"],
	interactionTags: [],
	nameKey: "games.challengers.name",
	descKey: "games.challengers.desc",
	rulesKey: "games.challengers.rules",
	icon: "🚩",
	iconImg: "games/challengers.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/challengers/en.pdf" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [
		4,
		6,
		8
	],
	accent: "#ea580c",
	releasedAt: "2026-09-12",
	search: {
		py: "guan jun tiao zhan zhe",
		init: "gjzzz"
	},
	hotseat: "cover"
}, he = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choosePile"),
		pile: t.enum([
			"A",
			"B",
			"C"
		])
	}),
	t.object({
		type: t.literal("pick"),
		indices: t.array(t.int().nonnegative()).max(5)
	}),
	t.object({ type: t.literal("redraw") }),
	t.object({
		type: t.literal("remove"),
		index: t.int().nonnegative()
	}),
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("choose"),
		picks: t.array(t.string()).max(40)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), I = t.string(), ge = t.enum([
	"A",
	"B",
	"C"
]), _e = t.object({
	card: t.string(),
	count: t.int().positive()
}), ve = t.object({
	card: t.string(),
	bonus: t.int()
}), ye = t.object({
	rid: I,
	deckCount: t.int().nonnegative(),
	power: t.number(),
	bench: t.array(_e),
	flagStack: t.array(ve),
	attackPile: t.array(ve),
	exhaustedCount: t.int().nonnegative()
}), be = t.object({
	a: ye,
	b: ye,
	flag: t.enum(["a", "b"]).nullable(),
	pending: t.object({
		side: t.enum(["a", "b"]),
		kind: t.string()
	}).nullable(),
	done: t.boolean(),
	winner: t.enum(["a", "b"]).nullable(),
	loseReason: t.enum(["deckOut", "benchFull"]).nullable()
}), xe = t.object({
	phase: t.enum([
		"deck",
		"match",
		"roundEnd",
		"finalTrim",
		"finalMatch",
		"done"
	]),
	round: t.int().min(1).max(7),
	sets: t.array(t.string()),
	draftOptions: t.array(t.object({
		pile: ge,
		picks: t.int().min(1).max(2)
	})),
	players: t.array(t.object({
		rid: I,
		fans: t.int().nonnegative(),
		trophyRounds: t.array(t.int()),
		deckCount: t.int().nonnegative(),
		ready: t.boolean(),
		bye: t.boolean()
	})),
	matches: t.array(be).nullable(),
	finalists: t.tuple([I, I]).nullable(),
	champion: I.nullable(),
	reveal: t.array(t.object({
		rid: I,
		fans: t.int().nonnegative(),
		trophyFans: t.array(t.int()),
		total: t.int().nonnegative()
	})).nullable()
}), Se = t.object({
	deck: t.array(t.string()),
	display: t.array(t.string()).nullable(),
	pile: ge.nullable(),
	picksLeft: t.int().nonnegative(),
	redrawUsed: t.boolean(),
	extraOffer: t.object({
		space: t.boolean(),
		got: t.int().nonnegative(),
		need: t.int().positive()
	}).nullable(),
	choice: t.object({
		kind: t.string(),
		cards: t.array(t.string()),
		min: t.int().nonnegative(),
		max: t.int().positive()
	}).nullable(),
	trophyFans: t.array(t.int())
}), L = 9e4, R = 1100, Ce = 4e3, z = [
	[{
		pile: "A",
		picks: 2
	}],
	[{
		pile: "A",
		picks: 2
	}],
	[{
		pile: "A",
		picks: 2
	}, {
		pile: "B",
		picks: 1
	}],
	[{
		pile: "A",
		picks: 2
	}, {
		pile: "B",
		picks: 1
	}],
	[{
		pile: "B",
		picks: 2
	}, {
		pile: "C",
		picks: 1
	}],
	[{
		pile: "B",
		picks: 2
	}, {
		pile: "C",
		picks: 1
	}],
	[{
		pile: "B",
		picks: 2
	}, {
		pile: "C",
		picks: 1
	}]
], B = [
	[],
	[
		2,
		2,
		2,
		3
	],
	[
		2,
		2,
		3,
		3
	],
	[
		3,
		3,
		4,
		4
	],
	[
		5,
		5,
		6,
		6
	],
	[
		6,
		6,
		6,
		7
	],
	[
		7,
		7,
		7,
		8
	],
	[
		9,
		9,
		10,
		10
	]
];
function we(t, n) {
	let r = e(t.seed, t.rngCursor, n);
	return t.rngCursor += 1, r;
}
function V(e, t) {
	for (let n = t.length - 1; n > 0; --n) {
		let r = we(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
}
function H(e, t, n) {
	let r = [];
	for (; r.length < n;) {
		if (e.piles[t].length === 0) {
			if (e.discards[t].length === 0) break;
			e.piles[t] = e.discards[t], e.discards[t] = [], V(e, e.piles[t]);
		}
		r.push(e.piles[t].pop());
	}
	return r;
}
function Te(e, t) {
	let n = [...e];
	n.length % 2 == 1 && n.push("$bye");
	let r = n.length, i = (t - 1) % (r - 1), a = n.slice(1), o = [n[0], ...a.map((e, t) => a[(t + i) % a.length])], s = [], c = null;
	for (let e = 0; e < r / 2; e += 1) {
		let t = o[e], n = o[r - 1 - e];
		t === "$bye" ? c = n : n === "$bye" ? c = t : s.push([t, n]);
	}
	return {
		pairs: s,
		bye: c
	};
}
function U(e, t) {
	return e.fans[t] + e.trophies[t].reduce((e, t) => e + t.fans, 0);
}
function W(e, t) {
	return [...t].sort((t, n) => U(e, n) - U(e, t) || e.trophies[n].length - e.trophies[t].length || Math.max(0, ...e.trophies[n].map((e) => e.round)) - Math.max(0, ...e.trophies[t].map((e) => e.round)));
}
function Ee(e, t, n) {
	let r = Math.max(0, ...e.trophies[t].map((e) => e.round)), i = Math.max(0, ...e.trophies[n].map((e) => e.round));
	return r === i ? we(e, 2) === 0 ? "a" : "b" : r > i ? "a" : "b";
}
function De(e) {
	let { pairs: t, bye: n } = Te(e.players, e.round);
	e.bye = n, e.matches = t.map(([t, n]) => ({
		a: k(t, [...e.decks[t]]),
		b: k(n, [...e.decks[n]]),
		flag: null,
		pending: null,
		done: !1,
		winner: null,
		loseReason: null
	}));
	for (let t of e.matches) V(e, t.a.deck), V(e, t.b.deck);
	return e.phase = "match", e.beatMs = R, e.matches.map((t, n) => ({
		kind: "matchStart",
		data: {
			round: e.round,
			matchId: n
		},
		for: [e.matches[n].a.rid, e.matches[n].b.rid]
	}));
}
function Oe(e) {
	let t = z[e.round - 1];
	e.deckPhase = {};
	for (let n of e.players) {
		let r = {
			pile: null,
			display: null,
			picksLeft: 0,
			redrawUsed: !1,
			extraOffer: null,
			ready: !1
		};
		t.length === 1 && (r.pile = t[0].pile, r.picksLeft = t[0].picks, r.display = H(e, t[0].pile, 5)), e.deckPhase[n] = r;
	}
	return e.phase = "deck", e.beatMs = L, [{
		kind: "deckStart",
		data: { round: e.round }
	}];
}
function ke(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		players: t,
		sets: [],
		piles: {
			A: [],
			B: [],
			C: []
		},
		discards: {
			A: [],
			B: [],
			C: []
		},
		round: 1,
		phase: "deck",
		decks: {},
		fans: {},
		trophies: {},
		deckPhase: null,
		matches: null,
		bye: null,
		finalists: null,
		champion: null,
		beatMs: L
	}, i = [
		"castle",
		"film",
		"funfair",
		"haunted",
		"space",
		"shipwreck"
	];
	V(r, i), r.sets = i.slice(0, 5);
	let a = /* @__PURE__ */ new Set(["city", ...r.sets]);
	for (let e of te) if (!(!a.has(e.set) || e.level === "S" || e.copies <= 0)) for (let t = 0; t < e.copies; t += 1) r.piles[e.level].push(e.id);
	V(r, r.piles.A), V(r, r.piles.B), V(r, r.piles.C);
	for (let e of t) r.decks[e] = [...ee], r.fans[e] = 0, r.trophies[e] = [];
	return {
		state: r,
		fx: Oe(r)
	};
}
function Ae(e, t, n, r) {
	e.decks[n].push(r);
	let i = E.get(r);
	return i?.onPick === "fans1" ? (e.fans[n] += 1, [{
		kind: "fans",
		rid: n,
		data: { n: 1 }
	}]) : (i?.onPick === "offerAny1" && (t.extraOffer = {
		space: !1,
		got: 0,
		need: 1
	}), i?.onPick === "offerSpace2" && (t.extraOffer = {
		space: !0,
		got: 0,
		need: 2
	}), []);
}
function je(e) {
	let t = e.deckPhase;
	if (!t || !e.players.every((e) => t[e]?.ready)) return null;
	for (let n of e.players) {
		let r = t[n];
		r.display && r.pile && e.discards[r.pile].push(...r.display);
	}
	return e.deckPhase = null, De(e);
}
function Me(e, t, n) {
	let r = e.deckPhase?.[n];
	if (!r) return { code: "games.challengers.errNotInDeckPhase" };
	let i = z[e.round - 1], a = [];
	if (t.type === "choosePile") {
		if (r.pile !== null || r.ready) return { code: "games.challengers.errPileChosen" };
		let a = i.find((e) => e.pile === t.pile);
		return a ? (r.pile = a.pile, r.picksLeft = a.picks, r.display = H(e, a.pile, 5), {
			state: e,
			fx: [{
				kind: "deal",
				rid: n,
				data: { n: 5 },
				for: [n]
			}]
		}) : { code: "games.challengers.errBadPile" };
	}
	if (t.type === "pick") {
		if (!r.display || r.picksLeft === 0 || r.ready) return { code: "games.challengers.errNoPick" };
		let i = t.indices;
		if (i.length > r.picksLeft || new Set(i).size !== i.length || i.some((e) => e >= (r.display?.length ?? 0))) return { code: "games.challengers.errNoPick" };
		let o = i.map((e) => r.display[e]);
		for (let t of o) a.push(...Ae(e, r, n, t));
		return r.picksLeft = 0, e.discards[r.pile].push(...r.display.filter((e, t) => !i.includes(t))), r.display = [], {
			state: e,
			fx: a
		};
	}
	if (t.type === "redraw") return !r.display || r.display.length === 0 || r.redrawUsed || r.ready ? { code: "games.challengers.errNoRedraw" } : (r.redrawUsed = !0, r.pile && e.discards[r.pile].push(...r.display), r.display = H(e, r.pile, r.display.length), {
		state: e,
		fx: [{
			kind: "deal",
			rid: n,
			data: { n: r.display.length },
			for: [n]
		}]
	});
	if (t.type === "remove") {
		if (r.ready || r.picksLeft > 0 && !r.extraOffer) return { code: "games.challengers.errNoRemove" };
		let i = e.decks[n][t.index];
		return i === void 0 ? { code: "games.challengers.errNoRemove" } : r.extraOffer?.space && E.get(i)?.set !== "space" ? { code: "games.challengers.errBadChoice" } : (e.decks[n].splice(t.index, 1), r.extraOffer && (r.extraOffer.got += 1, r.extraOffer.got >= r.extraOffer.need && (r.extraOffer = null, r.picksLeft += 1, (!r.display || r.display.length === 0) && r.pile && (r.display = H(e, r.pile, 4)))), {
			state: e,
			fx: []
		});
	}
	return r.ready || r.picksLeft > 0 ? { code: "games.challengers.errNotReady" } : (r.ready = !0, {
		state: e,
		fx: je(e) ?? []
	});
}
function Ne(e) {
	e.deckPhase = null;
	let [t, n] = e.finalists, r = {
		a: k(t, [...e.decks[t]]),
		b: k(n, [...e.decks[n]]),
		flag: null,
		pending: null,
		done: !1,
		winner: null,
		loseReason: null
	};
	return V(e, r.a.deck), V(e, r.b.deck), e.matches = [r], e.phase = "finalMatch", e.beatMs = R, [{
		kind: "finalStart",
		data: {
			a: t,
			b: n
		}
	}];
}
function Pe(e, t, n) {
	if (!e.finalists?.includes(n)) return { code: "games.challengers.errNotFinalist" };
	let r = e.deckPhase?.[n];
	return !r || r.ready ? { code: "games.challengers.errNotInDeckPhase" } : t.type === "remove" ? t.index >= e.decks[n].length ? { code: "games.challengers.errNoRemove" } : (e.decks[n].splice(t.index, 1), {
		state: e,
		fx: []
	}) : t.type === "ready" ? (r.ready = !0, e.finalists.every((t) => e.deckPhase?.[t]?.ready) ? {
		state: e,
		fx: Ne(e)
	} : {
		state: e,
		fx: []
	}) : { code: "games.challengers.errNotReady" };
}
function Fe(e, t, n, r, i) {
	let a = i ? void 0 : [t.a.rid, t.b.rid], o = (e) => e.map((e) => ({
		kind: e.kind,
		data: {
			...e.data,
			matchId: n
		},
		...a ? { for: a } : {}
	})), s = t.flag === null ? me(t, Ee(e, t.a.rid, t.b.rid), r) : pe(t, r);
	for (let [t, n] of Object.entries(s.events.fans)) e.fans[t] = (e.fans[t] ?? 0) + n;
	return o(s.fx);
}
function Ie(e) {
	let t = [...B[e.round]];
	V(e, t);
	let n = [];
	for (let r of e.matches ?? []) {
		if (!r.winner) continue;
		let i = r[r.winner].rid, a = t.pop() ?? B[e.round][0];
		e.trophies[i].push({
			round: e.round,
			fans: a
		}), n.push({
			kind: "trophy",
			rid: i,
			data: { round: e.round }
		});
	}
	return e.phase = "roundEnd", e.beatMs = Ce, n;
}
function Le(e) {
	if (e.phase === "deck") {
		for (let t of e.players) {
			let n = e.deckPhase?.[t];
			n && !n.ready && (n.display && n.pile && e.discards[n.pile].push(...n.display), n.display = null, n.picksLeft = 0, n.ready = !0);
		}
		return je(e) ?? [];
	}
	if (e.phase === "finalTrim") {
		for (let t of e.finalists ?? []) {
			let n = e.deckPhase?.[t];
			n && !n.ready && (n.ready = !0);
		}
		return e.finalists?.every((t) => e.deckPhase?.[t]?.ready) ? Ne(e) : [];
	}
	if (e.phase === "match" || e.phase === "finalMatch") {
		let t = {
			round: e.round,
			fans: e.fans,
			trophies: Object.fromEntries(e.players.map((t) => [t, e.trophies[t]?.length ?? 0])),
			drawPile: (t) => H(e, t, 1)[0]
		}, n = e.phase === "finalMatch", r = [];
		if ((e.matches ?? []).forEach((i, a) => {
			i.done || (r = r.concat(Fe(e, i, a, t, n)));
		}), (e.matches ?? []).every((e) => e.done)) {
			if (e.phase === "finalMatch") {
				let t = e.matches?.[0];
				return e.champion = t?.winner ? t[t.winner].rid : null, e.phase = "done", [...r, {
					kind: "champion",
					...e.champion ? { rid: e.champion } : {}
				}];
			}
			return [...r, ...Ie(e)];
		}
		return r;
	}
	if (e.phase === "roundEnd") {
		if (e.round >= 7) {
			let t = W(e, e.players);
			e.finalists = [t[0], t[1]], e.deckPhase = {};
			for (let t of e.finalists) e.deckPhase[t] = {
				pile: null,
				display: null,
				picksLeft: 0,
				redrawUsed: !0,
				extraOffer: null,
				ready: !1
			};
			return e.phase = "finalTrim", e.beatMs = L, [{
				kind: "finalists",
				data: {
					a: t[0],
					b: t[1]
				}
			}];
		}
		return e.round += 1, Oe(e);
	}
	return [];
}
function Re(e, t, n) {
	if (e.phase === "done") return { code: "games.challengers.errDone" };
	let r = structuredClone(e);
	if (t.type === "tick") return {
		state: r,
		fx: Le(r)
	};
	if (t.type === "choose") {
		if (r.phase !== "match" && r.phase !== "finalMatch") return { code: "games.challengers.errBadChoice" };
		let e = r.matches?.find((e) => !e.done && e.pending && e[e.pending.side].rid === n.by);
		return !e || !le(e, n.by, t.picks) ? { code: "games.challengers.errBadChoice" } : {
			state: r,
			fx: []
		};
	}
	return r.phase === "deck" ? Me(r, t, n.by) : r.phase === "finalTrim" ? Pe(r, t, n.by) : { code: "games.challengers.errNotInDeckPhase" };
}
function ze(e, t) {
	let n = {
		round: t.round,
		fans: t.fans,
		trophies: Object.fromEntries(t.players.map((e) => [e, t.trophies[e].length])),
		drawPile: () => void 0
	}, r = (t, r) => ({
		rid: t.rid,
		deckCount: t.deck.length,
		power: e.flag === r ? oe(e, r, n) : se(e, r, n),
		bench: t.bench,
		flagStack: t.flagStack,
		attackPile: t.attackPile,
		exhaustedCount: t.exhausted.length
	});
	return {
		a: r(e.a, "a"),
		b: r(e.b, "b"),
		flag: e.flag,
		pending: e.pending ? {
			side: e.pending.side,
			kind: e.pending.kind
		} : null,
		done: e.done,
		winner: e.winner,
		loseReason: e.loseReason
	};
}
function Be(e, t) {
	let n = e.phase === "deck" || e.phase === "finalTrim", r = e.deckPhase?.[t] ?? null, i = (t) => n ? e.deckPhase?.[t]?.ready ?? !0 : !0, a = e.matches?.find((e) => !e.done && e.pending && e[e.pending.side].rid === t)?.pending ?? null;
	return {
		public: {
			phase: e.phase,
			round: e.round,
			sets: e.sets,
			draftOptions: e.phase === "deck" ? z[e.round - 1] : [],
			players: e.players.map((t) => ({
				rid: t,
				fans: e.fans[t],
				trophyRounds: e.trophies[t].map((e) => e.round),
				deckCount: e.decks[t].length,
				ready: i(t),
				bye: (e.phase === "match" || e.phase === "roundEnd") && e.bye === t
			})),
			matches: e.matches ? e.matches.map((t) => ze(t, e)) : null,
			finalists: e.finalists,
			champion: e.champion,
			reveal: e.phase === "done" ? e.players.map((t) => ({
				rid: t,
				fans: e.fans[t],
				trophyFans: e.trophies[t].map((e) => e.fans),
				total: U(e, t)
			})) : null
		},
		private: {
			deck: n ? e.decks[t] : [],
			display: e.phase === "deck" ? r?.display ?? null : null,
			pile: e.phase === "deck" ? r?.pile ?? null : null,
			picksLeft: e.phase === "deck" ? r?.picksLeft ?? 0 : 0,
			redrawUsed: r?.redrawUsed ?? !1,
			extraOffer: e.phase === "deck" ? r?.extraOffer ?? null : null,
			choice: a ? {
				kind: a.kind,
				cards: a.cards,
				min: a.min,
				max: a.max
			} : null,
			trophyFans: e.trophies[t]?.map((e) => e.fans) ?? []
		}
	};
}
function Ve(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = W(e, e.players), n = e.finalists?.find((t) => t !== e.champion) ?? null, r = t.filter((t) => t !== e.champion && t !== n), i = e.champion ? [
		e.champion,
		...n ? [n] : [],
		...r
	] : t;
	return {
		phase: "done",
		winner: e.champion ? [e.champion] : [t[0]],
		ranking: i,
		scores: Object.fromEntries(e.players.map((t) => [t, U(e, t)]))
	};
}
function He(e) {
	return e.phase === "done" ? null : e.beatMs;
}
var Ue = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: F,
	schemas: {
		action: he,
		publicView: xe,
		privateView: Se
	},
	setup: ke,
	reduce: Re,
	viewFor: Be,
	status: Ve,
	nextTickIn: He
}, G = {
	city: "#64748b",
	castle: "#b45309",
	film: "#db2777",
	funfair: "#dc2626",
	haunted: "#7c3aed",
	space: "#0369a1",
	shipwreck: "#0d9488"
}, We = {
	start_newcomer: "/games/challengers/art/newcomer.webp",
	start_champion: "/games/challengers/art/champion.webp",
	start_talent: "/games/challengers/art/talent.webp",
	city_talent: "/games/challengers/art/talent.webp",
	city_reporter: "/games/challengers/art/reporter.webp",
	castle_jester: "/games/challengers/art/jester.webp",
	castle_stableboy: "/games/challengers/art/stableboy.webp",
	castle_pig: "/games/challengers/art/pig.webp",
	castle_dragon: "/games/challengers/art/dragon.webp"
};
function K({ cardId: e, bonus: t, size: n, selected: r, onPick: i }) {
	let a = c(), o = E.get(e);
	if (!o) return null;
	let s = a(o.nameKey), l = D.find((e) => e.id === o.set), u = We[e], d = `ch-card ch-card--${n}${r ? " ch-card--selected" : ""}${i ? " ch-card--button" : ""}`, h = /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p("span", {
			className: "ch-card-art",
			style: { background: G[o.set] },
			"aria-hidden": !0,
			children: u ? /* @__PURE__ */ p("img", {
				src: u,
				alt: "",
				draggable: !1
			}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("svg", {
				className: "ch-card-landscape",
				viewBox: "0 0 84 75",
				preserveAspectRatio: "none",
				"aria-hidden": !0,
				children: [
					/* @__PURE__ */ p("circle", {
						cx: "66",
						cy: "17",
						r: "15",
						fill: "var(--color-ch-gold)",
						opacity: ".85"
					}),
					/* @__PURE__ */ p("path", {
						d: "M0 54C16 36 24 49 36 43S60 31 84 48V75H0Z",
						fill: "var(--color-ch-field)"
					}),
					/* @__PURE__ */ p("path", {
						d: "M0 63C21 45 30 59 46 52S65 49 84 56V75H0Z",
						fill: "var(--color-ch-field-deep)"
					}),
					/* @__PURE__ */ p("path", {
						d: "M6 9l5 3-5 3M20 18l5 3-5 3",
						fill: "none",
						stroke: "var(--color-surface)",
						strokeWidth: "2",
						opacity: ".8"
					})
				]
			}), /* @__PURE__ */ p("span", {
				className: "ch-card-character",
				children: o.emoji
			})] })
		}),
		/* @__PURE__ */ m("span", {
			className: "ch-card-power",
			children: [o.power, t ? /* @__PURE__ */ m("small", { children: ["+", t] }) : null]
		}),
		n === "deck" && /* @__PURE__ */ p("span", {
			className: "ch-card-set",
			"aria-hidden": !0,
			children: l?.emoji
		}),
		/* @__PURE__ */ p("span", {
			className: "ch-card-level",
			"aria-label": `${l ? a(l.nameKey) : ""} ${o.level}`,
			children: o.level
		}),
		/* @__PURE__ */ p("span", {
			className: "ch-card-name",
			children: s
		}),
		(n === "full" || n === "deck") && /* @__PURE__ */ p("span", {
			className: `ch-card-effect${o.textKey ? "" : " ch-card-effect--empty"}`,
			children: o.textKey ? a(o.textKey) : n === "deck" ? a("games.challengers.cardNoEffect") : "\xA0"
		})
	] }), g = n === "deck" && i ? a("games.challengers.cardInspectAria", {
		name: s,
		set: l ? a(l.nameKey) : "",
		level: o.level,
		power: o.power
	}) : a("games.challengers.cardAria", {
		name: s,
		power: o.power
	});
	return i ? /* @__PURE__ */ p("button", {
		type: "button",
		className: d,
		"aria-label": g,
		"aria-pressed": r === void 0 ? void 0 : r,
		onClick: i,
		children: h
	}) : /* @__PURE__ */ p("span", {
		className: d,
		"aria-label": g,
		children: h
	});
}
function Ge({ cardId: e, onClose: t, onRemove: n }) {
	let r = c(), i = E.get(e);
	if (!i) return null;
	let a = D.find((e) => e.id === i.set);
	return /* @__PURE__ */ p("div", {
		className: "ch-detail-shade",
		onClick: t,
		children: /* @__PURE__ */ m("section", {
			className: "ch-card-detail",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": r(i.nameKey),
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ m("header", { children: [
					/* @__PURE__ */ p("span", {
						className: "ch-detail-set",
						style: { background: G[i.set] },
						"aria-hidden": !0,
						children: a?.emoji
					}),
					/* @__PURE__ */ p("b", { children: r(i.nameKey) }),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "ch-detail-x",
						onClick: t,
						"aria-label": r("games.challengers.closeDetail"),
						children: /* @__PURE__ */ p(d, { size: 20 })
					})
				] }),
				/* @__PURE__ */ m("div", {
					className: "ch-detail-body",
					children: [/* @__PURE__ */ p(K, {
						cardId: e,
						size: "deck"
					}), /* @__PURE__ */ m("div", {
						className: "ch-detail-info",
						children: [/* @__PURE__ */ m("div", {
							className: "ch-detail-chips",
							children: [
								/* @__PURE__ */ m("span", {
									className: "ch-chip",
									children: [
										a?.emoji,
										" ",
										a ? r(a.nameKey) : ""
									]
								}),
								/* @__PURE__ */ p("span", {
									className: "ch-chip",
									children: r("games.challengers.cardLevelChip", { level: i.level })
								}),
								/* @__PURE__ */ p("span", {
									className: "ch-chip ch-chip--power",
									children: r("games.challengers.cardPowerChip", { power: i.power })
								})
							]
						}), /* @__PURE__ */ p("p", { children: i.textKey ? r(i.textKey) : r("games.challengers.cardNoEffect") })]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: "ch-detail-actions",
					children: [n && /* @__PURE__ */ p("button", {
						type: "button",
						className: "ch-detail-remove",
						onClick: n,
						children: r("games.challengers.removeThisCard")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: "ch-detail-close",
						onClick: t,
						children: r("games.challengers.closeDetail")
					})]
				})
			]
		})
	});
}
function Ke({ mini: e }) {
	return /* @__PURE__ */ p("span", {
		"aria-hidden": !0,
		className: `ch-card-back${e ? " ch-card-back--mini" : ""}`,
		children: /* @__PURE__ */ m("svg", {
			viewBox: "0 0 64 88",
			preserveAspectRatio: "none",
			children: [
				/* @__PURE__ */ p("path", {
					d: "M10 8H54V80H10Z",
					fill: "none",
					stroke: "var(--color-ch-cream)",
					strokeWidth: "2",
					opacity: ".85"
				}),
				/* @__PURE__ */ p("path", {
					d: "M31 62V26M33 28c9-5 13 1 22-3l-3 22c-8 2-13-3-19 1",
					fill: "none",
					stroke: "var(--color-ch-cream)",
					strokeWidth: "4",
					strokeLinejoin: "round"
				}),
				/* @__PURE__ */ p("path", {
					d: "M16 68H48",
					stroke: "var(--color-ch-gold)",
					strokeWidth: "4"
				})
			]
		})
	});
}
//#endregion
//#region src/game/view-player.tsx
function qe(e) {
	return /* @__PURE__ */ p(Xe, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Je(e, t, n) {
	let r = e.find((e) => e.rid === n);
	return r ? i(r.rid) === null ? r.name : o(t, r.avatar) : n;
}
function Ye(e, t, n, r, i, a) {
	let o = e.players.find((e) => e.rid === n), s = e.matches?.find((e) => e.a.rid === n || e.b.rid === n);
	return e.phase === "deck" ? !t || t.pile === null ? a("games.challengers.choosePile") : t.picksLeft > 0 ? a("games.challengers.pickCards", { n: t.picksLeft }) : o?.ready ? a("games.challengers.waitingOthers") : a("games.challengers.trimOrReady") : e.phase === "finalTrim" ? e.finalists?.includes(n) ? o?.ready ? a("games.challengers.waitingOthers") : a("games.challengers.finalTrim") : a("games.challengers.finalWatch", { names: (e.finalists ?? []).map(r).join(i === "zh" ? "、" : ", ") }) : e.phase === "roundEnd" ? a("games.challengers.roundEnd", { n: e.round }) : e.phase === "finalMatch" ? a("games.challengers.finalLive") : s ? s.done && s.winner ? a(s[s.winner].rid === n ? "games.challengers.matchWon" : "games.challengers.matchLost") : a("games.challengers.matchVs", { name: r(s.a.rid === n ? s.b.rid : s.a.rid) }) : a("games.challengers.byeRound");
}
function Xe({ pub: e, priv: t, members: r, myRid: i, send: a }) {
	let o = c(), d = s((e) => e.locale), f = (e) => Je(r, d, e), h = e.players.find((e) => e.rid === i), g = e.matches ?? [], _ = g.find((e) => e.a.rid === i || e.b.rid === i), v = e.phase === "match" && !_, y = e.phase === "match" || e.phase === "finalMatch", b = e.phase === "deck" || e.phase === "finalTrim", [x, S] = n(null), C = x ? g.findIndex((e) => e.a.rid === x || e.b.rid === x) : -1, w = v && g.length ? C >= 0 ? C : 0 : null, T = Ye(e, t, i, f, d, o), ee = e.phase === "deck" && t && !h?.ready ? /* @__PURE__ */ p("button", {
		className: "ch-action-button",
		type: "button",
		disabled: t.pile === null || t.picksLeft > 0,
		onClick: () => a({ type: "ready" }),
		children: o("games.challengers.ready")
	}) : e.phase === "finalTrim" && e.finalists?.includes(i) && !h?.ready ? /* @__PURE__ */ p("button", {
		className: "ch-action-button",
		type: "button",
		onClick: () => a({ type: "ready" }),
		children: o("games.challengers.readyFinal")
	}) : /* @__PURE__ */ m("span", {
		className: "ch-action-note",
		children: [/* @__PURE__ */ p("span", { className: "ch-live-dot" }), y ? o("games.challengers.watchHint") : T]
	});
	return /* @__PURE__ */ p("main", {
		className: "ch-game-root",
		children: /* @__PURE__ */ m(l, {
			adaptive: !0,
			className: "ch-screen",
			scroll: !1,
			actionsHeight: "ch-actions-height",
			actions: /* @__PURE__ */ p("div", {
				className: "ch-action-slot",
				children: ee
			}),
			overlay: t?.choice && y ? /* @__PURE__ */ p(rt, {
				choice: t.choice,
				send: a
			}, `${i}:${t.choice.kind}:${t.choice.cards.join(",")}`) : null,
			banner: /* @__PURE__ */ m("div", {
				className: "ch-game-banner",
				children: [
					/* @__PURE__ */ m("div", {
						className: "ch-game-heading",
						children: [
							/* @__PURE__ */ m("b", { children: ["CHALLENGERS", /* @__PURE__ */ p("span", { children: "!" })] }),
							/* @__PURE__ */ p("strong", { children: e.phase === "finalTrim" || e.phase === "finalMatch" ? o("games.challengers.finalChip") : o("games.challengers.roundShort", {
								n: e.round,
								total: 7
							}) }),
							/* @__PURE__ */ p("span", { className: "ch-menu-space" })
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "ch-round-progress",
						"aria-hidden": !0,
						children: Array.from({ length: 7 }, (t, n) => /* @__PURE__ */ p("span", { className: n < e.round ? "is-done" : "" }, n))
					}),
					/* @__PURE__ */ p("p", {
						className: "ch-game-status",
						children: T
					}),
					/* @__PURE__ */ p("div", {
						className: "ch-score-roster",
						children: e.players.map((t) => /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p("b", { children: f(t.rid) }), /* @__PURE__ */ p(Ze, {
							pub: e,
							rid: t.rid
						})] }, t.rid))
					}),
					/* @__PURE__ */ p("div", {
						className: "ch-mini-seats",
						children: /* @__PURE__ */ p(u, {
							adaptive: !0,
							members: r,
							myRid: i,
							variant: "mini",
							scroll: !0,
							status: (t) => /* @__PURE__ */ p(Ze, {
								pub: e,
								rid: t
							}),
							anchorOf: (e) => `seat:${e}`,
							action: (t) => {
								if (!b) return null;
								let n = e.players.find((e) => e.rid === t);
								return !n || e.phase === "finalTrim" && !e.finalists?.includes(t) ? null : n.ready ? "done" : "pending";
							},
							dimmed: (t) => e.players.find((e) => e.rid === t)?.bye ?? !1,
							onPick: v ? S : void 0,
							picked: v ? (e) => {
								let t = w === null ? null : g[w];
								return !!t && (t.a.rid === e || t.b.rid === e);
							} : void 0
						})
					})
				]
			}),
			children: [
				e.phase === "deck" && t && /* @__PURE__ */ p(et, {
					pub: e,
					priv: t,
					ready: !!h?.ready,
					send: a
				}, i),
				e.phase === "finalTrim" && t && e.finalists?.includes(i) && /* @__PURE__ */ p(tt, {
					priv: t,
					ready: !!h?.ready,
					send: a
				}, i),
				e.phase === "finalTrim" && !e.finalists?.includes(i) && /* @__PURE__ */ m("div", {
					className: "ch-field ch-field--waiting",
					children: [/* @__PURE__ */ p("span", { children: "⚑" }), /* @__PURE__ */ p("b", { children: o("games.challengers.finalTrimWait") })]
				}),
				y && /* @__PURE__ */ p(it, {
					pub: e,
					members: r,
					locale: d,
					myRid: i,
					watchIdx: w
				}),
				e.phase === "roundEnd" && /* @__PURE__ */ p(ut, {
					pub: e,
					nameOf: f
				})
			]
		})
	});
}
function Ze({ pub: e, rid: t }) {
	let n = c(), r = e.players.find((e) => e.rid === t);
	return r ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("span", {
		"aria-label": n("games.challengers.stripFans", { n: r.fans }),
		className: "ch-strip-stat",
		children: ["⭐", r.fans]
	}), r.trophyRounds.length > 0 && /* @__PURE__ */ m("span", {
		"aria-label": n("games.challengers.stripTrophies", { n: r.trophyRounds.length }),
		className: "ch-strip-stat",
		children: ["🏆", r.trophyRounds.length]
	})] }) : null;
}
function Qe({ priv: e, canRemove: t, onInspect: n }) {
	let r = c();
	return /* @__PURE__ */ m("section", {
		className: "ch-deck-tray",
		children: [/* @__PURE__ */ m("div", {
			className: "ch-section-heading",
			children: [/* @__PURE__ */ p("b", { children: r("games.challengers.deckLabel", { n: e.deck.length }) }), /* @__PURE__ */ p("small", { children: r(t ? "games.challengers.trimHint" : "games.challengers.deckViewHint") })]
		}), /* @__PURE__ */ p("ul", {
			className: "ch-deck-cards",
			children: e.deck.map((e, t) => /* @__PURE__ */ p("li", {
				className: "ch-deck-card-wrap",
				children: /* @__PURE__ */ p(K, {
					cardId: e,
					size: "deck",
					onPick: () => n(t)
				})
			}, `${e}:${t}`))
		})]
	});
}
function $e({ priv: e, send: t }) {
	let r = c(), [i, a] = n([]), [o, s] = n(null), l = (t) => {
		s(t), a((n) => n.includes(t) ? n.filter((e) => e !== t) : n.length < e.picksLeft ? [...n, t] : n);
	}, u = o === null ? null : E.get(e.display?.[o] ?? ""), d = u ? D.find((e) => e.id === u.set) : void 0;
	return /* @__PURE__ */ m("section", {
		className: "ch-draft-display",
		children: [
			/* @__PURE__ */ m("div", {
				className: "ch-section-heading",
				children: [
					/* @__PURE__ */ p("b", { children: r("games.challengers.displayLabel") }),
					/* @__PURE__ */ m("span", {
						className: "ch-pick-count",
						children: [
							i.length,
							"/",
							e.picksLeft
						]
					}),
					!e.redrawUsed && /* @__PURE__ */ p("button", {
						className: "ch-redraw",
						type: "button",
						onClick: () => t({ type: "redraw" }),
						children: r("games.challengers.redraw")
					})
				]
			}),
			/* @__PURE__ */ p("ul", {
				className: "ch-display-cards",
				children: e.display?.map((e, t) => /* @__PURE__ */ p("li", { children: /* @__PURE__ */ p(K, {
					cardId: e,
					size: "deck",
					selected: i.includes(t),
					onPick: () => l(t)
				}) }, `${e}:${t}`))
			}),
			/* @__PURE__ */ p("p", {
				className: "ch-card-inspect",
				children: u ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("span", {
					className: "ch-inspect-head",
					children: [
						/* @__PURE__ */ p("b", { children: r(u.nameKey) }),
						/* @__PURE__ */ m("span", {
							className: "ch-chip",
							children: [
								d?.emoji,
								" ",
								d ? r(d.nameKey) : ""
							]
						}),
						/* @__PURE__ */ p("span", {
							className: "ch-chip",
							children: r("games.challengers.cardLevelChip", { level: u.level })
						}),
						/* @__PURE__ */ p("span", {
							className: "ch-chip ch-chip--power",
							children: r("games.challengers.cardPowerChip", { power: u.power })
						})
					]
				}), /* @__PURE__ */ p("span", {
					className: "ch-inspect-text",
					children: u.textKey ? r(u.textKey) : r("games.challengers.cardNoEffect")
				})] }) : r("games.challengers.pickCards", { n: e.picksLeft })
			}),
			/* @__PURE__ */ p("button", {
				className: "ch-action-button ch-pick-submit",
				type: "button",
				onClick: () => t({
					type: "pick",
					indices: i
				}),
				children: i.length === 0 ? r("games.challengers.pickNone") : r("games.challengers.confirmPick", {
					n: i.length,
					max: e.picksLeft
				})
			})
		]
	});
}
function et({ pub: e, priv: t, ready: r, send: i }) {
	let o = c(), { ref: s } = a("deckarea"), [l, u] = n(null), d = !r && (t.picksLeft === 0 || !!t.extraOffer), f = l === null ? void 0 : t.deck[l];
	return /* @__PURE__ */ m("div", {
		ref: s,
		className: "ch-field ch-draft-field",
		children: [/* @__PURE__ */ m("div", {
			className: "ch-draft-scroll",
			children: [/* @__PURE__ */ m("div", {
				className: "ch-draft-selection",
				children: [
					/* @__PURE__ */ m("section", {
						className: "ch-pile-area",
						children: [/* @__PURE__ */ p("div", {
							className: "ch-section-heading",
							children: /* @__PURE__ */ p("b", { children: o("games.challengers.choosePile") })
						}), /* @__PURE__ */ p("div", {
							className: "ch-pile-options",
							children: e.draftOptions.map((e) => /* @__PURE__ */ m("button", {
								type: "button",
								className: `ch-pile${t.pile === e.pile ? " is-picked" : ""}`,
								disabled: t.pile !== null,
								onClick: () => i({
									type: "choosePile",
									pile: e.pile
								}),
								children: [
									/* @__PURE__ */ p(Ke, {}),
									/* @__PURE__ */ p("span", {
										className: "ch-pile-letter",
										children: e.pile
									}),
									/* @__PURE__ */ m("span", {
										className: "ch-pile-caption",
										children: [o("games.challengers.pileLevel", { level: e.pile }), /* @__PURE__ */ p("small", { children: o("games.challengers.pilePicks", { n: e.picks }) })]
									})
								]
							}, e.pile))
						})]
					}),
					!r && t.display && t.display.length > 0 && /* @__PURE__ */ p($e, {
						priv: t,
						send: i
					}, `${t.pile}:${t.redrawUsed}:${t.display.join(",")}`),
					t.extraOffer && /* @__PURE__ */ p("p", {
						className: "ch-extra-offer",
						children: o(t.extraOffer.space ? "games.challengers.extraOfferSpace" : "games.challengers.extraOfferAny", {
							got: t.extraOffer.got,
							need: t.extraOffer.need
						})
					})
				]
			}), /* @__PURE__ */ p(Qe, {
				priv: t,
				canRemove: d,
				onInspect: u
			})]
		}), f && /* @__PURE__ */ p(Ge, {
			cardId: f,
			onClose: () => u(null),
			onRemove: d ? () => {
				i({
					type: "remove",
					index: l
				}), u(null);
			} : void 0
		})]
	});
}
function tt({ priv: e, ready: t, send: r }) {
	let i = c(), { ref: o } = a("deckarea"), [s, l] = n(null), u = !t, d = s === null ? void 0 : e.deck[s];
	return /* @__PURE__ */ m("div", {
		ref: o,
		className: "ch-field ch-draft-field ch-final-trim",
		children: [/* @__PURE__ */ m("div", {
			className: "ch-draft-scroll",
			children: [/* @__PURE__ */ m("div", {
				className: "ch-final-banner",
				children: [/* @__PURE__ */ p("span", { children: "🏆" }), /* @__PURE__ */ p("b", { children: i("games.challengers.finalTrim") })]
			}), /* @__PURE__ */ p(Qe, {
				priv: e,
				canRemove: u,
				onInspect: l
			})]
		}), d && /* @__PURE__ */ p(Ge, {
			cardId: d,
			onClose: () => l(null),
			onRemove: u ? () => {
				r({
					type: "remove",
					index: s
				}), l(null);
			} : void 0
		})]
	});
}
var nt = {
	order: "games.challengers.choiceOrder",
	sink: "games.challengers.choiceSink",
	deckBottom: "games.challengers.choiceDeckBottom",
	deckTop: "games.challengers.choiceDeckTop",
	benchExhaust: "games.challengers.choiceBenchExhaust",
	benchTop: "games.challengers.choiceBenchTop",
	oppBenchExhaust: "games.challengers.choiceOppBench"
};
function rt({ choice: e, send: t }) {
	let r = c(), [i, a] = n([]), o = e.kind === "order", s = (t) => a((n) => n.includes(t) ? n.filter((e) => e !== t) : o || n.length < e.max ? [...n, t] : n), l = o ? i.length === e.cards.length : i.length >= e.min && i.length <= e.max;
	return /* @__PURE__ */ m("div", {
		className: "ch-choice-sheet pointer-events-auto",
		role: "dialog",
		"aria-label": r(nt[e.kind] ?? "games.challengers.choiceOrder", { n: e.max }),
		children: [
			/* @__PURE__ */ m("p", { children: ["⚡ ", r(nt[e.kind] ?? "games.challengers.choiceOrder", { n: e.max })] }),
			/* @__PURE__ */ p("ul", { children: e.cards.map((e, t) => /* @__PURE__ */ m("li", { children: [/* @__PURE__ */ p(K, {
				cardId: e,
				size: "hand",
				selected: i.includes(t),
				onPick: () => s(t)
			}), o && i.includes(t) && /* @__PURE__ */ p("b", { children: i.indexOf(t) + 1 })] }, `${e}:${t}`)) }),
			/* @__PURE__ */ m("div", { children: [e.min === 0 && /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => t({
					type: "choose",
					picks: []
				}),
				children: r("games.challengers.choiceSkip")
			}), /* @__PURE__ */ p("button", {
				className: "ch-action-button",
				type: "button",
				disabled: !l,
				onClick: () => t({
					type: "choose",
					picks: i.map((t) => e.cards[t])
				}),
				children: r("games.challengers.choiceConfirm")
			})] })
		]
	});
}
function it({ pub: e, members: t, locale: n, myRid: r, watchIdx: i }) {
	let a = c(), o = e.matches ?? [], s = e.phase === "finalMatch", l = o.findIndex((e) => e.a.rid === r || e.b.rid === r), u = s ? 0 : l >= 0 ? l : i ?? -1, d = u >= 0 ? o[u] : null, f = (e) => Je(t, n, e);
	return /* @__PURE__ */ m("div", {
		className: "ch-field ch-match-field",
		children: [d ? /* @__PURE__ */ p(ot, {
			m: d,
			matchIdx: u,
			myRid: r,
			members: t,
			nameOf: f
		}) : /* @__PURE__ */ m("div", {
			className: "ch-field--waiting",
			children: [/* @__PURE__ */ p("span", { children: "⚑" }), /* @__PURE__ */ p("b", { children: a("games.challengers.byeWatch") })]
		}), !s && o.length > 1 && /* @__PURE__ */ p("div", {
			className: "ch-other-matches",
			children: o.map((e, t) => t === u ? null : /* @__PURE__ */ m("span", { children: [
				f(e.a.rid),
				" vs ",
				f(e.b.rid),
				e.done && e.winner ? ` · 🏆 ${f(e[e.winner].rid)}` : ""
			] }, t))
		})]
	});
}
function at({ mine: e }) {
	return /* @__PURE__ */ m("svg", {
		className: "ch-match-flag",
		viewBox: "0 0 84 88",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ p("path", {
				d: "M32 76V8",
				stroke: "var(--color-ink)",
				strokeWidth: "6",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M36 10C49 5 59 13 72 9L67 41C54 43 47 35 36 40Z",
				fill: e ? "var(--color-ch-orange)" : "var(--color-ch-blue)",
				stroke: "var(--color-ink)",
				strokeWidth: "4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "32",
				cy: "7",
				r: "5",
				fill: "var(--color-ch-gold)",
				stroke: "var(--color-ink)",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ p("path", {
				d: "M13 79H52L59 85H7Z",
				fill: "var(--color-ch-gold)",
				stroke: "var(--color-ink)",
				strokeWidth: "4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "M43 20l6 4-3 7 8-5",
				fill: "none",
				stroke: "var(--color-surface)",
				strokeWidth: "4",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			})
		]
	});
}
function ot({ m: e, matchIdx: t, myRid: n, members: r, nameOf: i }) {
	let o = c(), { ref: s } = a(`flag:${t}`), l = e.b.rid === n ? "a" : "b", u = l === "a" ? "b" : "a";
	return /* @__PURE__ */ m("div", {
		className: "ch-match-layout",
		children: [
			/* @__PURE__ */ p(lt, {
				side: e[l],
				sideKey: l,
				matchIdx: t,
				flag: e.flag,
				mine: !1,
				member: r.find((t) => t.rid === e[l].rid),
				name: i(e[l].rid)
			}),
			/* @__PURE__ */ m("div", {
				ref: s,
				className: "ch-match-midline",
				children: [
					/* @__PURE__ */ m("div", {
						className: "ch-power-readout",
						children: [/* @__PURE__ */ p("span", { children: e.flag === l ? o("games.challengers.flag") : "⚡" }), /* @__PURE__ */ p("b", { children: e.flag === null ? "—" : e[l].power })]
					}),
					/* @__PURE__ */ m("div", {
						className: "ch-flag-base",
						children: [
							/* @__PURE__ */ p("span", { className: "ch-flag-rays" }),
							/* @__PURE__ */ p(at, { mine: e.flag === u }),
							/* @__PURE__ */ p("small", { children: e.done && e.winner ? `🏆 ${i(e[e.winner].rid)}` : e.pending ? o("games.challengers.choiceWaiting", { name: i(e[e.pending.side].rid) }) : e.flag === null ? o("games.challengers.watchHint") : o("games.challengers.flag") })
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "ch-power-readout ch-power-readout--mine",
						children: [/* @__PURE__ */ p("span", { children: e.flag === u ? o("games.challengers.flag") : "⚡" }), /* @__PURE__ */ p("b", { children: e.flag === null ? "—" : e[u].power })]
					})
				]
			}),
			/* @__PURE__ */ p(lt, {
				side: e[u],
				sideKey: u,
				matchIdx: t,
				flag: e.flag,
				mine: !0,
				member: r.find((t) => t.rid === e[u].rid),
				name: i(e[u].rid)
			})
		]
	});
}
function st({ card: e, anchorName: t }) {
	let { ref: n, hidden: r } = a(t);
	return /* @__PURE__ */ p("li", {
		ref: n,
		style: { visibility: r ? "hidden" : void 0 },
		children: /* @__PURE__ */ p(K, {
			cardId: e.card,
			bonus: e.bonus,
			size: "mini"
		})
	});
}
function ct({ anchorName: e, label: t, slot: n, index: r }) {
	let { ref: i } = a(e);
	return /* @__PURE__ */ p("li", {
		ref: i,
		"aria-label": `${t} ${r + 1}`,
		children: n ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(K, {
			cardId: n.card,
			size: "mini"
		}), n.count > 1 && /* @__PURE__ */ m("b", { children: ["×", n.count] })] }) : /* @__PURE__ */ p("small", { children: r + 1 })
	});
}
function lt({ side: e, sideKey: t, matchIdx: n, flag: i, mine: o, member: s, name: l }) {
	let u = c(), { ref: d } = a(`deck:${n}:${t}`), { ref: h, hidden: g } = a(`flagtop:${n}:${t}`), { ref: _ } = a(`attack:${n}:${t}`), { ref: v, hidden: y } = a(`bench:${n}:${t}`), b = e.flagStack[e.flagStack.length - 1];
	return /* @__PURE__ */ m("section", {
		className: `ch-match-side${o ? " ch-match-side--mine" : ""}${i === t ? " is-holder" : ""}`,
		children: [
			/* @__PURE__ */ m("header", {
				className: "ch-side-header",
				children: [
					s && /* @__PURE__ */ p("img", {
						src: r[s.avatar % r.length],
						alt: "",
						draggable: !1
					}),
					/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("b", { children: l }), /* @__PURE__ */ p("small", { children: i === t ? `🚩 ${u("games.challengers.flag")}` : e.attackPile.length ? "⚡" : "" })] }),
					/* @__PURE__ */ m("span", {
						ref: d,
						className: "ch-side-deck",
						children: [/* @__PURE__ */ p(Ke, { mini: !0 }), /* @__PURE__ */ m("b", { children: ["×", e.deckCount] })]
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "ch-side-lane",
				children: [
					/* @__PURE__ */ p("div", {
						ref: h,
						className: "ch-flag-card",
						style: { visibility: g ? "hidden" : void 0 },
						children: b && /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ p("span", { children: u("games.challengers.flag") }),
							/* @__PURE__ */ p(K, {
								cardId: b.card,
								bonus: b.bonus,
								size: "full"
							}),
							e.flagStack.length > 1 && /* @__PURE__ */ m("b", { children: ["+", e.flagStack.length - 1] })
						] })
					}),
					/* @__PURE__ */ p("ul", {
						ref: _,
						className: "ch-attack-cards",
						children: e.attackPile.map((r, i) => /* @__PURE__ */ p(st, {
							card: r,
							anchorName: i === e.attackPile.length - 1 ? `attacktop:${n}:${t}` : null
						}, i))
					}),
					!b && !e.attackPile.length && /* @__PURE__ */ p("span", {
						className: "ch-lane-empty",
						children: "⚑"
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "ch-bench",
				children: [/* @__PURE__ */ m("span", {
					className: "ch-bench-title",
					children: [
						u("games.challengers.benchAria"),
						" ",
						/* @__PURE__ */ m("b", { children: [e.bench.length, "/6"] })
					]
				}), /* @__PURE__ */ p("ul", {
					ref: v,
					style: { visibility: y ? "hidden" : void 0 },
					children: Array.from({ length: 6 }, (r, i) => /* @__PURE__ */ p(ct, {
						anchorName: `benchslot:${n}:${t}:${i}`,
						label: u("games.challengers.benchAria"),
						slot: e.bench[i],
						index: i
					}, i))
				})]
			})
		]
	});
}
function ut({ pub: e, nameOf: t }) {
	let n = c(), r = e.players.filter((t) => t.trophyRounds.includes(e.round));
	return /* @__PURE__ */ m("div", {
		className: "ch-field ch-round-end",
		children: [
			/* @__PURE__ */ p("span", { children: "🏆" }),
			/* @__PURE__ */ p("b", { children: n("games.challengers.roundEnd", { n: e.round }) }),
			/* @__PURE__ */ p("ul", { children: r.map((e) => /* @__PURE__ */ p("li", { children: t(e.rid) }, e.rid)) }),
			/* @__PURE__ */ p("div", { children: e.sets.map((e) => {
				let t = D.find((t) => t.id === e);
				return t && /* @__PURE__ */ m("span", {
					style: { borderColor: G[e] },
					children: [
						t.emoji,
						" ",
						n(t.nameKey)
					]
				}, e);
			}) })
		]
	});
}
//#endregion
//#region src/game/bot.ts
function q() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
var J = (e) => E.get(e)?.power ?? 0, dt = (e) => !!E.get(e)?.benchPower, ft = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let a = h(i(t.rid)), o = t.difficulty === "weak", s = (e) => {
		let t = E.get(e);
		if (!t) return 0;
		let n = r.deck.filter((e) => E.get(e)?.nameKey === t.nameKey).length;
		return t.power + n * 1.5;
	};
	if (r.choice) {
		let e = r.choice, i = (e) => [...e].sort(() => q() - .5), a = (e, t) => (o ? i(e) : [...e].sort((e, t) => J(t) - J(e))).slice(0, t), s = (e, t) => (o ? i(e) : [...e].sort((e, t) => J(e) - J(t))).slice(0, t), c;
		if (e.kind === "order") c = o ? i(e.cards) : a(e.cards, e.cards.length);
		else if (e.kind === "sink" || e.kind === "deckBottom") c = s(e.cards, 1);
		else if (e.kind === "deckTop") c = a(e.cards, 1);
		else if (e.kind === "benchExhaust") c = s(o ? e.cards : e.cards.filter((e) => !dt(e)), e.max);
		else if (e.kind === "benchTop") {
			if (e.min === 0) {
				let r = n.matches?.find((e) => e.a.rid === t.rid || e.b.rid === t.rid);
				c = (r ? (r.a.rid === t.rid ? r.a : r.b).bench.length : 0) >= 5 && !o ? a(e.cards, e.max) : [];
			} else c = a(e.cards, e.min);
		} else c = a(e.cards, e.min || 1);
		return { action: {
			type: "choose",
			picks: c
		} };
	}
	if (n.phase === "deck") {
		let e = n.players.find((e) => e.rid === t.rid);
		if (!e || e.ready) return null;
		if (r.pile === null) {
			let e = n.draftOptions;
			if (e.length === 0) return null;
			let t = e[0];
			if (e.length > 1 && !o) {
				let n = e[1];
				t = q() < .35 + .5 * a.greed ? n : e[0];
			} else e.length > 1 && (t = e[q() < .5 ? 0 : 1]);
			return { action: {
				type: "choosePile",
				pile: t.pile
			} };
		}
		if (r.extraOffer && r.deck.length > 6 && !o) {
			let e = r.extraOffer, t = r.deck.map((e, t) => ({
				c: e,
				i: t
			})).filter(({ c: t }) => !e.space || E.get(t)?.set === "space");
			if (t.length > 0) return { action: {
				type: "remove",
				index: t.reduce((e, t) => s(t.c) < s(e.c) ? t : e).i
			} };
		}
		if (r.display && r.picksLeft > 0) {
			let e = Math.max(0, ...r.display.map(s));
			if (!r.redrawUsed && !o && e < 2 && q() < .8 || o && !r.redrawUsed && q() < .15) return { action: { type: "redraw" } };
			if (o) return { action: {
				type: "pick",
				indices: r.display.map((e, t) => t).filter(() => q() < .4).slice(0, r.picksLeft)
			} };
			let t = r.display.map((e, t) => ({
				c: e,
				i: t
			})).sort((e, t) => s(t.c) - s(e.c)), n = t.filter(({ c: e }) => s(e) >= 2).slice(0, r.picksLeft).map(({ i: e }) => e);
			return n.length === 0 && r.deck.length < 10 && n.push(t[0].i), { action: {
				type: "pick",
				indices: n
			} };
		}
		if (r.picksLeft === 0 && n.round >= 3 && r.deck.length > 8) {
			let e = r.deck.reduce((e, t, n) => s(t) < s(r.deck[e]) ? n : e, 0), t = E.get(r.deck[e]);
			if (t && t.level === "S" && !o) return { action: {
				type: "remove",
				index: e
			} };
		}
		return { action: { type: "ready" } };
	}
	if (n.phase === "finalTrim") {
		if (!n.finalists?.includes(t.rid)) return null;
		let e = n.players.find((e) => e.rid === t.rid);
		if (!e || e.ready) return null;
		if (r.deck.length > 10 && !o) {
			let e = r.deck.reduce((e, t, n) => s(t) < s(r.deck[e]) ? n : e, 0), t = E.get(r.deck[e]);
			if (t && t.level === "S") return { action: {
				type: "remove",
				index: e
			} };
		}
		return { action: { type: "ready" } };
	}
	return null;
};
function pt(e, t) {
	return e.map((e) => {
		let n = E.get(e);
		return n ? `${n.emoji}${t(n.nameKey)}` : e;
	}).join(" ");
}
var mt = (e, t, n) => {
	let r = t.private;
	switch (e.type) {
		case "choosePile": return n("games.challengers.hintChoosePile", { pile: n("games.challengers.pileLevel", { level: e.pile }) });
		case "pick": {
			let t = r?.display ?? [], i = e.indices.map((e) => t[e]).filter((e) => !!e);
			return i.length ? n("games.challengers.hintPick", { names: pt(i, n) }) : n("games.challengers.pickNone");
		}
		case "redraw": return n("games.challengers.redraw");
		case "remove": {
			let t = r?.deck[e.index], i = t ? E.get(t) : void 0;
			return i ? n("games.challengers.hintRemove", { name: `${i.emoji}${n(i.nameKey)}` }) : n("games.challengers.removeCard");
		}
		case "ready": return n(t.public.phase === "finalTrim" ? "games.challengers.readyFinal" : "games.challengers.ready");
		case "choose": {
			if (e.picks.length === 0) return n("games.challengers.choiceSkip");
			let t = pt(e.picks, n), i = r?.choice?.kind;
			return n(i === "order" ? "games.challengers.hintChooseOrder" : i === "sink" || i === "deckBottom" ? "games.challengers.hintChooseSink" : i === "deckTop" ? "games.challengers.hintChooseTop" : i === "benchTop" ? "games.challengers.hintChooseBenchTop" : i === "benchExhaust" ? "games.challengers.hintChooseExhaust" : i === "oppBenchExhaust" ? "games.challengers.hintChooseOpp" : "games.challengers.hintChoose", { names: t });
		}
		default: return "";
	}
}, ht = {
	name: "冠军挑战者!",
	desc: "组建梦幻战队打七轮夺旗巡回赛,攒粉丝进决赛,捧起冠军杯",
	rules: "目标:7 轮巡回赛后,粉丝总数前两名进入决赛,决赛胜者夺冠。\n流程(每轮两段):\n· 组牌:从指定牌堆抽 5 张展示,留下至多 1~2 张(可以一张不留),可整手重抽一次。\n· 选牌结束后，可以从自己的卡组中移除卡牌。\n· 比赛:与本轮对手夺旗。双方轮流翻牌比力量,攻方总力量达到持旗方即夺旗。\n· 失旗的卡进替补席(6 格,同名叠放);牌堆翻空或替补席无法容纳新卡牌的一方输掉本场比赛。\n· 胜者捧走本轮奖杯,奖杯的粉丝值保密。\n· 需要抉择的卡效果会暂停比赛,等当事人操作完再继续。\n牌堆配置:\n· 第1至2轮：从A级牌堆选择至多2张牌。\n· 第3至4轮：从A级牌堆选择至多2张牌，或从B级牌堆选择至多1张牌。\n· 第5至7轮：从B级牌堆选择至多2张牌，或从C级牌堆选择至多1张牌。\n决赛:\n· 7 轮后粉丝前两名进决赛,赛前只能撤卡整备;决赛胜者捧起冠军杯。",
	roundShort: "第 {{n}}/{{total}} 轮",
	finalChip: "决赛",
	choosePile: "选一堆抽卡",
	pickCards: "选至多 {{n}} 张加入卡组(可以一张不选)",
	confirmPick: "就要这 {{n}}/{{max}} 张",
	pickNone: "都不要",
	trimOrReady: "点卡查看效果或撤掉弱卡,也可直接就绪",
	trimHint: "点卡查看效果并撤掉弱卡;卡组越薄,越容易翻到强卡",
	deckViewHint: "点卡查看效果",
	waitingOthers: "已就绪,等其他选手…",
	matchVs: "对阵 {{name}}",
	matchWon: "你赢下了这场比赛!",
	matchLost: "这场比赛输了……",
	byeRound: "本轮你轮空",
	byeHint: "人数为奇,休息一下;点头像可观战",
	byeWatch: "看看别人的比赛吧",
	roundEnd: "第 {{n}} 轮结束",
	finalTrim: "决赛前最后整备:只能撤卡",
	finalWatch: "决赛对阵:{{names}}",
	finalTrimWait: "决赛选手正在整备卡组…",
	finalLive: "决赛进行中!",
	ready: "就绪",
	readyFinal: "整备完毕,开打!",
	watchHint: "比赛自动进行,可在此观看",
	stripFans: "粉丝 {{n}}",
	stripTrophies: "奖杯 {{n}} 座",
	pileLevel: "{{level}} 级堆",
	pilePicks: "选 {{n}} 张",
	displayLabel: "本轮展示",
	redraw: "重抽一手",
	deckLabel: "我的卡组({{n}} 张)",
	flag: "持旗",
	benchAria: "替补席",
	cardAria: "{{name}},力量 {{power}}",
	cardLevelChip: "{{level}} 级",
	cardPowerChip: "力量 {{power}}",
	cardNoEffect: "无特殊效果",
	cardInspectAria: "{{name}},{{set}} {{level}} 级,力量 {{power}},查看卡牌效果",
	closeDetail: "关闭",
	removeThisCard: "撤掉这张卡",
	endTitle: "巡回赛落幕!",
	endChampion: "{{name}} 捧起冠军杯!",
	endTrophyAria: "奖杯粉丝 {{n}}",
	removeCard: "撤掉",
	extraOfferAny: "变形者:从卡组撤 1 张卡,可多选 1 张({{got}}/{{need}})",
	extraOfferSpace: "科幻迷:撤 2 张🚀太空卡,可多选 1 张({{got}}/{{need}})",
	choiceOrder: "牌堆顶 {{n}} 张:按点击顺序排出新顺序(先点 = 最上面)",
	choiceSink: "选一张沉入牌堆底,另一张回到顶",
	choiceDeckBottom: "浏览牌堆:选一张放到牌堆底",
	choiceDeckTop: "浏览牌堆:选一张放到牌堆顶",
	choiceBenchExhaust: "从替补席选至多 {{n}} 张移入耗尽堆",
	choiceBenchTop: "从替补席选卡放回牌堆顶(至多 {{n}} 张)",
	choiceOppBench: "可将对手一张替补卡移出游戏",
	choiceConfirm: "确定",
	choiceSkip: "跳过",
	choiceWaiting: "{{name}} 正在抉择…",
	sets: {
		city: "城市",
		castle: "城堡",
		film: "片场",
		funfair: "游乐园",
		haunted: "鬼屋",
		space: "太空",
		shipwreck: "沉船"
	},
	cards: {
		newcomer: { name: "新人" },
		talent: { name: "达人" },
		dog: { name: "忠犬" },
		champion: { name: "冠军" },
		reporter: {
			name: "记者",
			text: "查看牌堆顶 2 张:一张沉入牌堆底,一张放回牌堆顶"
		},
		mascot: {
			name: "吉祥物",
			text: "替补席每种不同套装使力量 +1"
		},
		fanbus: {
			name: "应援巴士",
			text: "若你的奖杯 ≤3 座,获得 2 粉丝"
		},
		jester: {
			name: "弄臣",
			text: "若替补席有力量 1 的卡,力量 +3"
		},
		stableboy: {
			name: "马倌",
			text: "替补席每张力量 3 的卡使力量 +1"
		},
		hermit: {
			name: "隐士",
			text: "若替补席没有🏰城堡卡,力量 +2"
		},
		pig: { name: "猪" },
		blacksmith: {
			name: "铁匠",
			text: "在替补席时:你的🏰城堡卡力量 +1"
		},
		knight: {
			name: "骑士",
			text: "进攻时:对手每座奖杯使力量 +1"
		},
		sorcerer: {
			name: "巫师",
			text: "可将替补席一张力量 ≤3 的卡移入耗尽堆"
		},
		horse: { name: "骏马" },
		bard: {
			name: "吟游诗人",
			text: "在替补席时:你的卡进攻时力量 +1"
		},
		prince: {
			name: "王子",
			text: "失旗:本卡移入耗尽堆"
		},
		dragon: { name: "巨龙" },
		makeup: {
			name: "化妆师",
			text: "在替补席时:你力量 1 的卡进攻时力量 +2"
		},
		moviestar: {
			name: "影星",
			text: "将至多 2 张新人从替补席放回牌堆顶"
		},
		gangster: {
			name: "黑帮",
			text: "进攻时力量 +2"
		},
		cat: { name: "猫" },
		cowboy: {
			name: "牛仔",
			text: "得旗:对手牌堆顶的卡放进其替补席"
		},
		director: {
			name: "导演",
			text: "在替补席时:你的片场卡进攻时力量 +1"
		},
		comic: {
			name: "漫画角色",
			text: "失旗:你的下一张卡进攻时力量 +2"
		},
		lion: { name: "狮子" },
		heroine: {
			name: "女英雄",
			text: "得旗:获得 3 粉丝"
		},
		villain: {
			name: "反派",
			text: "将 A 堆顶的卡放到你的牌堆顶(不查看)"
		},
		trex: { name: "霸王龙" },
		clown: {
			name: "小丑",
			text: "得旗:获得 2 粉丝"
		},
		juggler: {
			name: "杂耍人",
			text: "查看牌堆顶 3 张,按任意顺序放回"
		},
		vendor: {
			name: "小贩",
			text: "在替补席时:你的🎡游乐园卡力量 +1"
		},
		pony: { name: "小马" },
		pyro: {
			name: "烟花师",
			text: "若你的牌堆 ≤1 张,获得 2 粉丝"
		},
		mime: {
			name: "默剧演员",
			text: "替补席每个空位使力量 +1"
		},
		clairvoyant: {
			name: "占卜师",
			text: "失旗:浏览牌堆,任选一张放到牌堆顶"
		},
		duck: { name: "橡皮鸭" },
		illusionist: {
			name: "魔术师",
			text: "持旗时:替补席每个空位使力量 +1"
		},
		bumper: {
			name: "碰碰车",
			text: "查看牌堆顶 3 张,按任意顺序放回"
		},
		teddy: { name: "泰迪熊" },
		butler: {
			name: "管家",
			text: "将至多 2 张替补席卡移入耗尽堆"
		},
		skeleton: {
			name: "骷髅",
			text: "持旗时力量 +1"
		},
		spider: { name: "蜘蛛" },
		ghost: {
			name: "幽灵",
			text: "对手牌堆顶的卡进入其耗尽堆"
		},
		teenager: {
			name: "少年",
			text: "替补席每张鬼屋卡使力量 +1"
		},
		necromancer: {
			name: "死灵法师",
			text: "将替补席一张力量 2 的卡放回牌堆顶"
		},
		bat: { name: "蝙蝠" },
		vampire: {
			name: "吸血鬼",
			text: "将替补席一张 B 级卡放回牌堆顶"
		},
		vacuum: {
			name: "吸尘器",
			text: "将至多 2 张替补席卡移入耗尽堆"
		},
		werewolf: { name: "狼人" },
		rescuepod: {
			name: "救生舱",
			text: "失旗:将本卡移出游戏,B 堆顶的卡进入你的耗尽堆"
		},
		shapeshifter: {
			name: "变形者",
			text: "选中时:可将卡组 1 张卡移出游戏,以多选 1 张"
		},
		ai: {
			name: "人工智能",
			text: "在替补席时:你力量 2 的卡力量 +1"
		},
		cow: { name: "奶牛" },
		band: {
			name: "乐队",
			text: "在替补席时:你的🚀太空卡力量 +1"
		},
		ufo: {
			name: "飞碟",
			text: "将 A 堆顶 2 张放到你的牌堆底(不查看)"
		},
		clones: {
			name: "克隆人",
			text: "选中时:获得 1 粉丝"
		},
		alien: { name: "外星人" },
		hologram: {
			name: "全息影像",
			text: "对手将 B 堆顶的卡放到其牌堆顶(不查看)"
		},
		scifigeek: {
			name: "科幻迷",
			text: "选中时:可将 2 张🚀太空卡移出游戏,以多选 1 张"
		},
		slime: { name: "史莱姆" },
		merman: {
			name: "人鱼",
			text: "若替补席有⚓沉船卡,力量 +3"
		},
		treasure: {
			name: "宝箱",
			text: "持旗时力量 +2"
		},
		sailor: {
			name: "水手",
			text: "浏览牌堆,任选一张沉入牌堆底"
		},
		parrot: { name: "鹦鹉" },
		cook: {
			name: "厨师",
			text: "在替补席时:你的持旗卡力量 +1"
		},
		lifeguard: {
			name: "救生员",
			text: "若你的牌堆 ≤1 张,力量 +2"
		},
		navigator: {
			name: "领航员",
			text: "失旗:查看牌堆顶 2 张,一张沉入牌堆底,一张放回牌堆顶"
		},
		shark: { name: "鲨鱼" },
		siren: {
			name: "塞壬",
			text: "可将对手一张替补卡移入其耗尽堆"
		},
		kraken: { name: "海怪" },
		submarine: {
			name: "潜水艇",
			text: "你牌堆最底部的卡进入耗尽堆"
		}
	},
	errNotInDeckPhase: "现在不在组牌阶段",
	errPileChosen: "已经选过牌堆了",
	errBadPile: "本轮不能从这堆抽",
	errNoPick: "现在不能选牌",
	errNoRedraw: "重抽已经用过了",
	errNoRemove: "现在不能撤卡",
	errNotReady: "还没完成选牌",
	errNotFinalist: "只有决赛选手能整备",
	errBadChoice: "这个选择无效",
	errDone: "比赛已结束",
	hintChoosePile: "抽 {{pile}}",
	hintPick: "留下 {{names}}",
	hintRemove: "撤掉 {{name}}",
	hintChooseOrder: "牌堆顶按此顺序排:{{names}}",
	hintChooseSink: "把 {{names}} 沉到牌堆底",
	hintChooseTop: "把 {{names}} 放到牌堆顶",
	hintChooseBenchTop: "把 {{names}} 从替补席放回牌堆顶",
	hintChooseExhaust: "把 {{names}} 移入耗尽堆",
	hintChooseOpp: "拆掉对手替补席的 {{names}}",
	hintChoose: "选定 {{names}}"
}, gt = ht.cards, Y = (e) => {
	let t = E.get(e);
	if (!t) return e;
	let n = gt[e.slice(e.indexOf("_") + 1)];
	return `${e}(${n?.name ?? e},${t.level}级,力量${t.power}${n?.text ? `,${n.text}` : ""})`;
}, _t = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "deck" || n.phase === "finalTrim" ? n.players.find((e) => e.rid === t.rid)?.ready === !1 : n.phase === "match" || n.phase === "finalMatch" ? e.private?.choice != null : !1;
	},
	describeView(e, t) {
		let n = e.public, r = e.private, i = ["规则速览:7 轮巡回赛,每轮先组牌(抽 5 张展示,留至多指定张数,可整手重抽一次,之后可撤掉卡组弱卡——卡组越薄强卡越常翻到)再与对手夺旗比赛(自动进行,只有卡效抉择需要你操作)。胜者捧奖杯(粉丝值保密),7 轮后粉丝前两名进决赛。"];
		if (i.push(`各选手: ${n.players.map((e) => `${e.rid === t.rid ? "你" : e.rid}: 粉丝${e.fans},奖杯${e.trophyRounds.length}座,卡组${e.deckCount}张${e.bye ? ",本轮轮空" : ""}`).join("; ")}`), r && r.trophyFans.length && i.push(`你的奖杯粉丝值(保密): ${r.trophyFans.join(", ")}`), (n.phase === "deck" || n.phase === "finalTrim") && r && (i.push(`你的卡组(${r.deck.length} 张): ${r.deck.map((e, t) => `${t}:${Y(e)}`).join(" ")}`), n.phase === "finalTrim" ? i.push("决赛前整备:只能撤卡(remove=卡组下标)或就绪(ready)。") : r.pile === null && n.draftOptions.length > 1 ? i.push(`本轮可选牌堆: ${n.draftOptions.map((e) => `${e.pile} 级留 ${e.picks} 张`).join(" 或 ")}。先输出 choosePile。`) : r.display ? i.push(`展示中的卡(留至多 ${r.picksLeft} 张,可以一张不留): ${r.display.map((e, t) => `${t}:${Y(e)}`).join(" ")}。输出 pick(indices) 选定;${r.redrawUsed ? "重抽已用过。" : "也可以 redraw 整手重抽一次。"}选完后可 remove 撤卡或 ready 就绪。`) : i.push("展示已取完。可 remove(index) 撤掉卡组弱卡,或 ready 就绪。")), (n.phase === "match" || n.phase === "finalMatch") && r?.choice) {
			let e = r.choice;
			i.push(`比赛中,你的卡效果需要抉择(${e.kind}):候选 ${e.cards.map(Y).join(" | ")}。输出 choose(picks):${e.kind === "order" ? "给出全排列,顶在最先" : `选 ${e.min}-${e.max} 张`}。`);
		}
		return i.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: {
				type: { const: "choosePile" },
				pile: { enum: [
					"A",
					"B",
					"C"
				] }
			},
			required: ["type", "pile"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "pick" },
				indices: {
					type: "array",
					items: {
						type: "integer",
						minimum: 0
					},
					maxItems: 5,
					description: "展示卡下标,可空数组"
				}
			},
			required: ["type", "indices"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "redraw" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "remove" },
				index: {
					type: "integer",
					minimum: 0
				}
			},
			required: ["type", "index"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "ready" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "choose" },
				picks: {
					type: "array",
					items: { type: "string" },
					maxItems: 40
				}
			},
			required: ["type", "picks"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = he.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public, o = t.private, s = a.players.find((e) => e.rid === n.rid);
		if (!s) return null;
		if (i.type === "choose") {
			let e = o?.choice;
			return a.phase !== "match" && a.phase !== "finalMatch" || !e || !i.picks.every((t) => e.cards.includes(t)) ? null : e.kind === "order" ? i.picks.length === e.cards.length && [...i.picks].sort().join(",") === [...e.cards].sort().join(",") ? i : null : new Set(i.picks).size === i.picks.length && i.picks.length >= e.min && i.picks.length <= e.max ? i : null;
		}
		if (a.phase !== "deck" && a.phase !== "finalTrim" || s.ready) return null;
		let c = o?.deck ?? [];
		switch (i.type) {
			case "choosePile": return a.phase === "deck" && o?.pile == null && a.draftOptions.some((e) => e.pile === i.pile) ? i : null;
			case "pick": {
				let e = o?.display;
				return a.phase !== "deck" || !e || new Set(i.indices).size !== i.indices.length || i.indices.some((t) => t >= e.length) ? null : i.indices.length <= (o?.picksLeft ?? 0) ? i : null;
			}
			case "redraw": return a.phase === "deck" && o?.display != null && !o.redrawUsed ? i : null;
			case "remove": return i.index < c.length ? i : null;
			case "ready": return i;
		}
	}
};
//#endregion
//#region src/game/fx.tsx
function X(e) {
	let t = e.data?.matchId;
	return typeof t == "number" ? t : 0;
}
function Z(e) {
	return e === "a" || e === "b" ? e : null;
}
function Q(e) {
	return e !== null && Number.isFinite(e.w) && e.w > 0 && Number.isFinite(e.h) && e.h > 0;
}
function $({ cardId: e, from: t, at: n }) {
	let r = Number.isFinite(t.w) && t.w > 0 ? t.w : 40, i = n.h / n.w, a = Number.isFinite(i) && i > 0 ? i : 56 / 40;
	return /* @__PURE__ */ p("span", {
		className: "ch-fx-card",
		style: {
			width: r,
			height: r * a
		},
		children: /* @__PURE__ */ p("span", {
			style: {
				display: "block",
				width: 40,
				height: 40 * a,
				transform: `scale(${r / 40})`,
				transformOrigin: "top left"
			},
			children: /* @__PURE__ */ p(K, {
				cardId: e,
				size: "mini"
			})
		})
	});
}
function vt(e, t, n) {
	let r = e.data, i = Z(r?.side), a = typeof r?.card == "string" ? r.card : null;
	if (!i || !a) return null;
	let o = X(e), s = t.anchor(`deck:${o}:${i}`), c = t.anchor(`${n}:${o}:${i}`);
	if (!Q(s) || !Q(c)) return null;
	let l = r?.effect === !0, u = r?.lethal === !0;
	u && navigator.vibrate?.(80);
	let d = t.anchor(`flagtop:${o}:${i === "a" ? "b" : "a"}`);
	return {
		ms: u ? 1100 : l ? 1080 : 660,
		hide: [`${n}:${o}:${i}`],
		node: /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p(_, {
				from: s,
				to: c,
				ms: 580,
				children: /* @__PURE__ */ p($, {
					cardId: a,
					from: s,
					at: c
				})
			}),
			l && /* @__PURE__ */ p(g, {
				at: c,
				ms: 540,
				delay: 500,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					children: "⚡"
				})
			}),
			u && Q(d) && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(v, {
				at: d,
				ms: 560,
				delay: 500
			}), /* @__PURE__ */ p(g, {
				at: d,
				ms: 580,
				delay: 500,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "text-lg",
					children: "💥"
				})
			})] })
		] })
	};
}
var yt = {
	deckStart(e, t) {
		let n = t.anchor("deckarea");
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ p(v, {
				at: n,
				ms: 700
			})
		} : null;
	},
	deal(e, t) {
		let n = t.anchor("deckarea");
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ p(v, {
				at: n,
				ms: 600
			})
		} : null;
	},
	matchStart(e, t) {
		let n = t.anchor(`flag:${X(e)}`);
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ p(v, {
				at: n,
				ms: 700
			})
		} : null;
	},
	reveal(e, t) {
		return vt(e, t, "attacktop");
	},
	flagStart(e, t) {
		return vt(e, t, "flagtop");
	},
	flagChange(e, t) {
		let n = e.data, r = Z(n?.side), i = Z(n?.loserSide), a = X(e), o = r ? t.anchor(`flagtop:${a}:${r}`) : null, s = i ? t.anchor(`flagtop:${a}:${i}`) : null, c = i ? t.anchor(`bench:${a}:${i}`) : null, l = r ? t.anchor(`attack:${a}:${r}`) : null, u = Array.isArray(n?.lost) ? n.lost.filter((e) => typeof e == "string") : [], d = [], m = [];
		Q(s) && Q(c) && (u.forEach((e, n) => {
			let r = t.anchor(`benchslot:${a}:${i}:${Math.min(n, 5)}`) ?? c;
			Q(r) && d.push(/* @__PURE__ */ p(_, {
				from: s,
				to: r,
				ms: 520,
				delay: n * 80,
				children: /* @__PURE__ */ p($, {
					cardId: e,
					from: s,
					at: r
				})
			}, `lost:${n}`));
		}), d.length && m.push(`bench:${a}:${i}`));
		let h = u.length * 80 + 60;
		return Q(l) && Q(o) && typeof n?.card == "string" && (d.push(/* @__PURE__ */ p(_, {
			from: l,
			to: o,
			ms: 520,
			delay: h,
			children: /* @__PURE__ */ p($, {
				cardId: n.card,
				from: l,
				at: o
			})
		}, "crown"), /* @__PURE__ */ p(g, {
			at: o,
			ms: 800,
			delay: h + 470,
			children: /* @__PURE__ */ p("span", {
				"aria-hidden": !0,
				children: "🚩"
			})
		}, "flag")), m.push(`flagtop:${a}:${r}`)), d.length ? {
			ms: h + 700,
			hide: m,
			node: /* @__PURE__ */ p(f, { children: d })
		} : null;
	},
	matchEnd(e, t) {
		let n = e.data, r = typeof n?.winner == "string" ? t.anchor(`seat:${n.winner}`) : null;
		return r ? {
			ms: 1100,
			node: /* @__PURE__ */ p(g, {
				at: r,
				ms: 1e3,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					children: "🏆"
				})
			})
		} : null;
	},
	trophy(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 1e3,
			node: /* @__PURE__ */ p(g, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					children: "🏆"
				})
			})
		} : null;
	},
	fans(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null, r = e.data, i = typeof r?.n == "number" ? r.n : 1;
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ p(g, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ m("span", {
					className: "text-warn-ink",
					children: [
						"+",
						i,
						"⭐"
					]
				})
			})
		} : null;
	},
	champion(e, t) {
		navigator.vibrate?.(150);
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 1400,
			node: /* @__PURE__ */ p(g, {
				at: n,
				ms: 1300,
				children: /* @__PURE__ */ p("span", {
					className: "text-2xl",
					"aria-hidden": !0,
					children: "👑"
				})
			})
		} : null;
	}
};
//#endregion
//#region src/game/game-over.tsx
function bt({ result: e, public: t, members: n, onPlayAgain: i, onBackToLobby: a }) {
	let o = c(), s = t, l = e.winner[0], u = n.find((e) => e.rid === l), d = i ?? a, f = (e) => s.reveal?.find((t) => t.rid === e) ?? null;
	return /* @__PURE__ */ m("div", {
		className: "ch-game-over relative h-full min-h-0",
		children: [/* @__PURE__ */ p(b, {}), /* @__PURE__ */ m("div", {
			className: "ch-end-layout",
			children: [
				/* @__PURE__ */ m("div", {
					className: "ch-end-hero",
					children: [/* @__PURE__ */ p("span", {
						"aria-hidden": !0,
						children: "🏆"
					}), /* @__PURE__ */ p("h1", { children: u ? o("games.challengers.endChampion", { name: u.name }) : o("games.challengers.endTitle") })]
				}),
				/* @__PURE__ */ p("ol", {
					className: "ch-end-ranking",
					children: e.ranking.map((e, t) => {
						let i = n.find((t) => t.rid === e), a = f(e), s = i ? y[i.colorIndex % y.length] : null;
						return /* @__PURE__ */ m("li", {
							className: `ch-end-seat${t === 0 ? " ch-end-winner" : ""}`,
							style: t === 0 ? { borderColor: F.accent } : void 0,
							children: [
								/* @__PURE__ */ p("span", {
									className: "ch-end-place font-display font-extrabold tabular-nums",
									children: t + 1
								}),
								i && /* @__PURE__ */ p("img", {
									src: r[i.avatar % r.length],
									alt: "",
									draggable: !1,
									className: "ch-end-avatar rounded-full border-2 border-ink object-contain",
									style: { backgroundColor: s?.hex }
								}),
								/* @__PURE__ */ p("span", {
									className: "ch-end-name font-extrabold",
									children: i?.name ?? e
								}),
								a && /* @__PURE__ */ m("span", {
									className: "ch-end-totals font-bold",
									children: [a.trophyFans.map((e, t) => /* @__PURE__ */ m("span", {
										"aria-label": o("games.challengers.endTrophyAria", { n: e }),
										className: "rounded-md border border-ink bg-warn-soft px-1 font-mono tabular-nums",
										children: ["🏆", e]
									}, t)), /* @__PURE__ */ m("span", {
										className: "ch-end-total font-mono font-extrabold tabular-nums",
										children: ["⭐", a.total]
									})]
								})
							]
						}, e);
					})
				}),
				d ? /* @__PURE__ */ m("div", {
					className: "ch-end-actions safe-b",
					children: [i && /* @__PURE__ */ p("button", {
						className: "ch-action-button",
						onClick: i,
						children: o("session.result.playAgain")
					}), a && /* @__PURE__ */ p("button", {
						className: "btn-quiet w-full cursor-pointer",
						onClick: a,
						children: o("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ p("p", {
					className: "ch-end-actions ch-end-wait safe-b font-bold opacity-70",
					children: o("session.result.waitHost")
				})
			]
		})]
	});
}
//#endregion
//#region src/index.tsx
var xt = {
	definition: Ue,
	View: qe,
	bot: ft,
	describe: mt,
	llm: _t,
	fx: yt,
	OverView: bt,
	locales: {
		zh: ht,
		en: {
			name: "Challengers!",
			desc: "Draft your dream team, fight seven capture-the-flag rounds, and lift the cup in the final",
			rules: "Goal: after 7 tournament rounds, the two players with the most fans meet in the final, and the finalist who wins it lifts the cup.\nEach round has two parts:\n· Deck phase: draw 5 cards from this round’s pile and keep up to 1–2 (you may keep none); one full redraw is allowed.\n· Afterwards you may trim weak cards from your deck — a thinner deck cycles your best cards more often.\n· Match phase: a flag duel against this round’s opponent. Take turns flipping cards and comparing power; the attacker captures the flag by matching the holder’s total power.\n· Beaten cards go to a 6-slot bench (same names stack); running out of deck cards or bench space loses the match.\n· The winner takes the round’s trophy, whose fan value stays secret.\n· Card effects that need a decision pause the match until that player answers.\nPile schedule:\n· In rounds 1–2, keep up to 2 cards from pile A.\n· In rounds 3–4, keep up to 2 cards from pile A or 1 card from pile B.\n· In rounds 5–7, keep up to 2 cards from pile B or 1 card from pile C.\nThe final:\n· After 7 rounds the top two in fans advance; only trimming is allowed before the final. The winner of the final is the champion.",
			roundShort: "Round {{n}}/{{total}}",
			finalChip: "Final",
			choosePile: "Choose a pile to draw from",
			pickCards: "Pick up to {{n}} for your deck (or none)",
			confirmPick: "Take {{n}}/{{max}}",
			pickNone: "Take none",
			trimOrReady: "Tap a card to read it or cut it, or hit ready",
			trimHint: "Tap a card to read it and cut weak cards; a thin deck cycles your best cards faster",
			deckViewHint: "Tap a card to read its effect",
			waitingOthers: "Ready — waiting for the others…",
			matchVs: "Facing {{name}}",
			matchWon: "You won this match!",
			matchLost: "Match lost…",
			byeRound: "Bye this round",
			byeHint: "Odd headcount — rest a round; tap a player to watch",
			byeWatch: "Watch the other matches",
			roundEnd: "Round {{n}} over",
			finalTrim: "Final prep: cutting cards only",
			finalWatch: "Final: {{names}}",
			finalTrimWait: "The finalists are trimming their decks…",
			finalLive: "The final is on!",
			ready: "Ready",
			readyFinal: "Ready — fight!",
			watchHint: "Matches play out automatically; watch them here",
			stripFans: "{{n}} fans",
			stripTrophies: "{{n}} trophies",
			pileLevel: "Pile {{level}}",
			pilePicks: "Pick {{n}}",
			displayLabel: "On offer",
			redraw: "Redraw",
			deckLabel: "My deck ({{n}})",
			flag: "flag",
			benchAria: "Bench",
			cardAria: "{{name}}, power {{power}}",
			cardLevelChip: "Level {{level}}",
			cardPowerChip: "Power {{power}}",
			cardNoEffect: "No special effect",
			cardInspectAria: "{{name}}, {{set}}, level {{level}}, power {{power}}. View card effect",
			closeDetail: "Close",
			removeThisCard: "Cut this card",
			endTitle: "Tournament over!",
			endChampion: "{{name}} lifts the cup!",
			endTrophyAria: "Trophy fans {{n}}",
			removeCard: "Cut",
			extraOfferAny: "Shapeshifter: cut 1 card from your deck to pick an extra card ({{got}}/{{need}})",
			extraOfferSpace: "Sci-Fi Geek: cut 2 🚀space cards to pick an extra card ({{got}}/{{need}})",
			choiceOrder: "Top {{n}} cards of your deck: tap in the new order (first tap = top)",
			choiceSink: "Choose one to sink under your deck; the other stays on top",
			choiceDeckBottom: "Choose a card to put under your deck",
			choiceDeckTop: "Choose a card to put on top of your deck",
			choiceBenchExhaust: "Move up to {{n}} bench cards to your exhaust pile",
			choiceBenchTop: "Return up to {{n}} bench cards to the top of your deck",
			choiceOppBench: "You may remove one of the opponent's bench cards from the game",
			choiceConfirm: "OK",
			choiceSkip: "Skip",
			choiceWaiting: "{{name}} is deciding…",
			sets: {
				city: "City",
				castle: "Castle",
				film: "Film Studio",
				funfair: "Funfair",
				haunted: "Haunted House",
				space: "Outer Space",
				shipwreck: "Shipwreck"
			},
			cards: {
				newcomer: { name: "Newcomer" },
				talent: { name: "Talent" },
				dog: { name: "Dog" },
				champion: { name: "Champion" },
				reporter: {
					name: "Reporter",
					text: "Look at the top 2 cards of your deck: one under, one back on top"
				},
				mascot: {
					name: "Mascot",
					text: "+1 power per different set icon on your bench"
				},
				fanbus: {
					name: "Fan-Bus",
					text: "If you have 3 or fewer trophies, gain 2 fans"
				},
				jester: {
					name: "Jester",
					text: "+3 power if your bench has a power-1 card"
				},
				stableboy: {
					name: "Stable Boy",
					text: "+1 power per power-3 card on your bench"
				},
				hermit: {
					name: "Hermit",
					text: "+2 power if your bench has no 🏰castle card"
				},
				pig: { name: "Pig" },
				blacksmith: {
					name: "Blacksmith",
					text: "Bench: your 🏰castle cards have +1 power"
				},
				knight: {
					name: "Knight",
					text: "During the attack: +1 power per opponent trophy"
				},
				sorcerer: {
					name: "Sorcerer",
					text: "You may exhaust a power-≤3 card from your bench"
				},
				horse: { name: "Horse" },
				bard: {
					name: "Bard",
					text: "Bench: your cards have +1 power during the attack"
				},
				prince: {
					name: "Prince",
					text: "Flag loss: exhaust this card"
				},
				dragon: { name: "Dragon" },
				makeup: {
					name: "Make-Up Artist",
					text: "Bench: your power-1 cards have +2 power during the attack"
				},
				moviestar: {
					name: "Movie Star",
					text: "Put up to two Newcomers from your bench on top of your deck"
				},
				gangster: {
					name: "Gangster",
					text: "+2 power during the attack"
				},
				cat: { name: "Cat" },
				cowboy: {
					name: "Cowboy",
					text: "If this gets the flag: top card of the opponent's deck goes to their bench"
				},
				director: {
					name: "Director",
					text: "Bench: your film cards have +1 power during the attack"
				},
				comic: {
					name: "Comic Character",
					text: "Flag loss: your next card has +2 power during the attack"
				},
				lion: { name: "Lion" },
				heroine: {
					name: "Heroine",
					text: "If this gets the flag: gain 3 fans"
				},
				villain: {
					name: "Villain",
					text: "Put the top card of the Level-A pile on top of your deck (no peeking)"
				},
				trex: { name: "T-Rex" },
				clown: {
					name: "Clown",
					text: "If this gets the flag: gain 2 fans"
				},
				juggler: {
					name: "Juggler",
					text: "Look at the top 3 cards of your deck, return in any order"
				},
				vendor: {
					name: "Vendor",
					text: "Bench: your 🎡funfair cards have +1 power"
				},
				pony: { name: "Pony" },
				pyro: {
					name: "Pyrotechnician",
					text: "If you have 1 or 0 cards left in your deck, gain 2 fans"
				},
				mime: {
					name: "Mime",
					text: "+1 power per empty bench seat"
				},
				clairvoyant: {
					name: "Clairvoyant",
					text: "Flag loss: choose any card from your deck and put it on top"
				},
				duck: { name: "Rubber Duck" },
				illusionist: {
					name: "Illusionist",
					text: "In flag possession: +1 power per empty bench seat"
				},
				bumper: {
					name: "Bumper Car",
					text: "Look at the top 3 cards of your deck, return in any order"
				},
				teddy: { name: "Teddy Bear" },
				butler: {
					name: "Butler",
					text: "Put up to two cards from your bench on your exhaust pile"
				},
				skeleton: {
					name: "Skeleton",
					text: "+1 power in flag possession"
				},
				spider: { name: "Spider" },
				ghost: {
					name: "Ghost",
					text: "Top card of the opponent's deck goes to their exhaust pile"
				},
				teenager: {
					name: "Teenager",
					text: "+1 power per haunted house card on your bench"
				},
				necromancer: {
					name: "Necromancer",
					text: "Put a power-2 card from your bench on top of your deck"
				},
				bat: { name: "Bat" },
				vampire: {
					name: "Vampire",
					text: "Put a Level-B card from your bench on top of your deck"
				},
				vacuum: {
					name: "Vacuum Cleaner",
					text: "Put up to two cards from your bench on your exhaust pile"
				},
				werewolf: { name: "Werewolf" },
				rescuepod: {
					name: "Rescue Pod",
					text: "Flag loss: remove this card from the game; top card of the Level-B pile goes to your exhaust pile"
				},
				shapeshifter: {
					name: "Shapeshifter",
					text: "When picked: you may cut a card from your deck to pick an extra card"
				},
				ai: {
					name: "A.I.",
					text: "Bench: your power-2 cards have +1 power"
				},
				cow: { name: "Cow" },
				band: {
					name: "Band",
					text: "Bench: your 🚀space cards have +1 power"
				},
				ufo: {
					name: "UFO",
					text: "Put the top 2 cards of the Level-A pile under your deck (no peeking)"
				},
				clones: {
					name: "Clones",
					text: "When picked: gain 1 fan"
				},
				alien: { name: "Alien" },
				hologram: {
					name: "Hologram",
					text: "Opponent puts the top card of the Level-B pile on their deck (no peeking)"
				},
				scifigeek: {
					name: "Sci-Fi Geek",
					text: "When picked: you may cut 2 🚀space cards to pick an extra card"
				},
				slime: { name: "Slime" },
				merman: {
					name: "Merman",
					text: "+3 power if your bench has a ⚓shipwreck card"
				},
				treasure: {
					name: "Treasure",
					text: "+2 power in flag possession"
				},
				sailor: {
					name: "Sailor",
					text: "Choose any card from your deck and put it under your deck"
				},
				parrot: { name: "Parrot" },
				cook: {
					name: "Cook",
					text: "Bench: your card in flag possession has +1 power"
				},
				lifeguard: {
					name: "Lifeguard",
					text: "+2 power if you have 1 or 0 cards left in your deck"
				},
				navigator: {
					name: "Navigator",
					text: "Flag loss: look at the top 2 cards of your deck: one under, one back on top"
				},
				shark: { name: "Shark" },
				siren: {
					name: "Siren",
					text: "You may exhaust a card from the opponent's bench"
				},
				kraken: { name: "Kraken" },
				submarine: {
					name: "Submarine",
					text: "Put the bottom card of your deck on your exhaust pile"
				}
			},
			errNotInDeckPhase: "Not in the deck phase",
			errPileChosen: "Pile already chosen",
			errBadPile: "That pile is not available this round",
			errNoPick: "Nothing to pick right now",
			errNoRedraw: "Redraw already used",
			errNoRemove: "Cannot cut cards right now",
			errNotReady: "Finish picking first",
			errNotFinalist: "Only finalists can trim",
			errBadChoice: "Invalid choice",
			errDone: "The tournament is over",
			hintChoosePile: "Draw from {{pile}}",
			hintPick: "Keep {{names}}",
			hintRemove: "Remove {{name}}",
			hintChooseOrder: "Order the deck top: {{names}}",
			hintChooseSink: "Sink {{names}} to the deck bottom",
			hintChooseTop: "Put {{names}} on the deck top",
			hintChooseBenchTop: "Return {{names}} from the bench to the deck top",
			hintChooseExhaust: "Move {{names}} to the exhausted pile",
			hintChooseOpp: "Remove {{names}} from the opponent's bench",
			hintChoose: "Choose {{names}}"
		}
	}
};
//#endregion
export { xt as default };
