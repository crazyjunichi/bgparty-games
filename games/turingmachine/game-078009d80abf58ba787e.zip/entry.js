import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { ConfirmButton as s } from "@bgparty/sdk/confirm-button";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconCheck as u, IconClose as d, IconEdit as ee, IconInfo as te, IconLog as f } from "@bgparty/sdk/icons";
import { useWakeLock as p } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { createPortal as ne } from "react-dom";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { OptionRadio as v, OptionSection as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/turingmachine/cards.ts
var b = Array.from({ length: 125 }, (e, t) => [
	Math.floor(t / 25) + 1,
	Math.floor(t / 5) % 5 + 1,
	t % 5 + 1
]), x = (1n << 125n) - 1n, S = (e) => (e[0] - 1) * 25 + (e[1] - 1) * 5 + e[2] - 1, C = (e) => e.join(""), w = [];
function T(e, t, n) {
	w.push({
		id: e,
		titleKey: t,
		criteria: n.map(([t, n], r) => {
			let i = b.map(([e, t, r]) => n(e, t, r));
			return {
				id: e * 16 + r,
				card: e,
				label: t.startsWith("games.") ? "" : t,
				labelKey: t.startsWith("games.") ? t : void 0,
				hits: i,
				mask: i.reduce((e, t, n) => t ? e | 1n << BigInt(n) : e, 0n)
			};
		})
	});
}
var E = [
	"▲",
	"■",
	"●"
], D = (e, t) => e.filter((e) => e === t).length, O = (e, t, n) => [
	e,
	t,
	n
].filter((e) => e % 2 == 0).length, k = (e, t, n, r) => [
	[`${e} < ${t}`, (e, t, i) => n(e, t, i) < r(e, t, i)],
	[`${e} = ${t}`, (e, t, i) => n(e, t, i) === r(e, t, i)],
	[`${e} > ${t}`, (e, t, i) => n(e, t, i) > r(e, t, i)]
], A = (e) => (t, n, r) => [
	t,
	n,
	r
][e], j = (e) => () => e;
T(1, "games.turingmachine.cards.c1", [["▲ = 1", (e) => e === 1], ["▲ > 1", (e) => e > 1]]), T(2, "games.turingmachine.cards.c2", k("▲", "3", A(0), j(3))), T(3, "games.turingmachine.cards.c3", k("■", "3", A(1), j(3))), T(4, "games.turingmachine.cards.c4", k("■", "4", A(1), j(4))), T(5, "games.turingmachine.cards.c5", [["▲ ∈ {2, 4}", (e) => e % 2 == 0], ["▲ ∈ {1, 3, 5}", (e) => e % 2 == 1]]), T(6, "games.turingmachine.cards.c6", [["■ ∈ {2, 4}", (e, t) => t % 2 == 0], ["■ ∈ {1, 3, 5}", (e, t) => t % 2 == 1]]), T(7, "games.turingmachine.cards.c7", [["● ∈ {2, 4}", (e, t, n) => n % 2 == 0], ["● ∈ {1, 3, 5}", (e, t, n) => n % 2 == 1]]), T(8, "games.turingmachine.cards.c8", [
	0,
	1,
	2,
	3
].map((e) => [`#1 = ${e}`, (t, n, r) => D([
	t,
	n,
	r
], 1) === e])), T(9, "games.turingmachine.cards.c9", [
	0,
	1,
	2,
	3
].map((e) => [`#3 = ${e}`, (t, n, r) => D([
	t,
	n,
	r
], 3) === e])), T(10, "games.turingmachine.cards.c10", [
	0,
	1,
	2,
	3
].map((e) => [`#4 = ${e}`, (t, n, r) => D([
	t,
	n,
	r
], 4) === e])), T(11, "games.turingmachine.cards.c11", k("▲", "■", A(0), A(1))), T(12, "games.turingmachine.cards.c12", k("▲", "●", A(0), A(2))), T(13, "games.turingmachine.cards.c13", k("■", "●", A(1), A(2))), T(14, "games.turingmachine.cards.c14", [
	0,
	1,
	2
].map((e) => [`${E[e]} < ${E.filter((t, n) => n !== e).join(", ")}`, (t, n, r) => [
	t,
	n,
	r
].every((t, n, r) => n === e || r[e] < t)])), T(15, "games.turingmachine.cards.c15", [
	0,
	1,
	2
].map((e) => [`${E[e]} > ${E.filter((t, n) => n !== e).join(", ")}`, (t, n, r) => [
	t,
	n,
	r
].every((t, n, r) => n === e || r[e] > t)])), T(16, "games.turingmachine.cards.c16", [["games.turingmachine.criteria.moreEven", (e, t, n) => O(e, t, n) >= 2], ["games.turingmachine.criteria.moreOdd", (e, t, n) => O(e, t, n) <= 1]]), T(17, "games.turingmachine.cards.c17", [
	0,
	1,
	2,
	3
].map((e) => [`${e} × {2, 4}`, (t, n, r) => O(t, n, r) === e])), T(18, "games.turingmachine.cards.c18", [["games.turingmachine.criteria.evenSum", (e, t, n) => (e + t + n) % 2 == 0], ["games.turingmachine.criteria.oddSum", (e, t, n) => (e + t + n) % 2 == 1]]), T(19, "games.turingmachine.cards.c19", k("▲ + ■", "6", (e, t) => e + t, j(6))), T(20, "games.turingmachine.cards.c20", [
	["games.turingmachine.criteria.triple", (e, t, n) => e === t && t === n],
	["games.turingmachine.criteria.pair", (e, t, n) => (/* @__PURE__ */ new Set([
		e,
		t,
		n
	])).size === 2],
	["games.turingmachine.criteria.distinct", (e, t, n) => (/* @__PURE__ */ new Set([
		e,
		t,
		n
	])).size === 3]
]), T(21, "games.turingmachine.cards.c21", [["games.turingmachine.criteria.noPair", (e, t, n) => (/* @__PURE__ */ new Set([
	e,
	t,
	n
])).size !== 2], ["games.turingmachine.criteria.pair", (e, t, n) => (/* @__PURE__ */ new Set([
	e,
	t,
	n
])).size === 2]]), T(22, "games.turingmachine.cards.c22", [
	["▲ < ■ < ●", (e, t, n) => e < t && t < n],
	["▲ > ■ > ●", (e, t, n) => e > t && t > n],
	["games.turingmachine.criteria.unordered", (e, t, n) => !(e < t && t < n) && !(e > t && t > n)]
]), T(23, "games.turingmachine.cards.c23", k("▲ + ■ + ●", "6", (e, t, n) => e + t + n, j(6))), T(24, "games.turingmachine.cards.c24", [
	["games.turingmachine.criteria.increasingThree", (e, t, n) => t === e + 1 && n === t + 1],
	["games.turingmachine.criteria.increasingTwo", (e, t, n) => Number(t === e + 1) + Number(n === t + 1) === 1],
	["games.turingmachine.criteria.increasingNone", (e, t, n) => t !== e + 1 && n !== t + 1]
]);
var M = (e, t, n) => t - e === n - t && Math.abs(t - e) === 1, re = (e, t, n) => Math.abs(t - e) === 1 || Math.abs(n - t) === 1;
T(25, "games.turingmachine.cards.c25", [
	["games.turingmachine.criteria.sequenceNone", (e, t, n) => !re(e, t, n)],
	["games.turingmachine.criteria.sequenceTwo", (e, t, n) => re(e, t, n) && !M(e, t, n)],
	["games.turingmachine.criteria.sequenceThree", M]
]), T(26, "games.turingmachine.cards.c26", [
	0,
	1,
	2
].map((e) => [`${E[e]} < 3`, (...t) => t[e] < 3])), T(27, "games.turingmachine.cards.c27", [
	0,
	1,
	2
].map((e) => [`${E[e]} < 4`, (...t) => t[e] < 4])), T(28, "games.turingmachine.cards.c28", [
	0,
	1,
	2
].map((e) => [`${E[e]} = 1`, (...t) => t[e] === 1])), T(29, "games.turingmachine.cards.c29", [
	0,
	1,
	2
].map((e) => [`${E[e]} = 3`, (...t) => t[e] === 3])), T(30, "games.turingmachine.cards.c30", [
	0,
	1,
	2
].map((e) => [`${E[e]} = 4`, (...t) => t[e] === 4])), T(31, "games.turingmachine.cards.c31", [
	0,
	1,
	2
].map((e) => [`${E[e]} > 1`, (...t) => t[e] > 1])), T(32, "games.turingmachine.cards.c32", [
	0,
	1,
	2
].map((e) => [`${E[e]} > 3`, (...t) => t[e] > 3])), T(33, "games.turingmachine.cards.c33", [
	0,
	1,
	2
].flatMap((e) => [0, 1].map((t) => [`${E[e]} ∈ ${t === 0 ? "{2, 4}" : "{1, 3, 5}"}`, (...n) => n[e] % 2 === t]))), T(34, "games.turingmachine.cards.c34", [
	0,
	1,
	2
].map((e) => [`${E[e]} ≤ ${E.filter((t, n) => n !== e).join(", ")}`, (t, n, r) => [
	t,
	n,
	r
].every((t, n, r) => n === e || r[e] <= t)])), T(35, "games.turingmachine.cards.c35", [
	0,
	1,
	2
].map((e) => [`${E[e]} ≥ ${E.filter((t, n) => n !== e).join(", ")}`, (t, n, r) => [
	t,
	n,
	r
].every((t, n, r) => n === e || r[e] >= t)])), T(36, "games.turingmachine.cards.c36", [
	3,
	4,
	5
].map((e) => [`▲ + ■ + ● = ${e}k`, (t, n, r) => (t + n + r) % e === 0])), T(37, "games.turingmachine.cards.c37", [
	[0, 1],
	[0, 2],
	[1, 2]
].map(([e, t]) => [`${E[e]} + ${E[t]} = 4`, (...n) => n[e] + n[t] === 4])), T(38, "games.turingmachine.cards.c38", [
	[0, 1],
	[0, 2],
	[1, 2]
].map(([e, t]) => [`${E[e]} + ${E[t]} = 6`, (...n) => n[e] + n[t] === 6])), T(39, "games.turingmachine.cards.c39", [
	0,
	1,
	2
].flatMap((e) => [[`${E[e]} = 1`, (...t) => t[e] === 1], [`${E[e]} > 1`, (...t) => t[e] > 1]])), T(40, "games.turingmachine.cards.c40", [
	0,
	1,
	2
].flatMap((e) => k(E[e], "3", A(e), j(3)))), T(41, "games.turingmachine.cards.c41", [
	0,
	1,
	2
].flatMap((e) => k(E[e], "4", A(e), j(4)))), T(42, "games.turingmachine.cards.c42", [
	0,
	1,
	2
].flatMap((e) => [[`${E[e]} < ${E.filter((t, n) => n !== e).join(", ")}`, (t, n, r) => [
	t,
	n,
	r
].every((t, n, r) => n === e || r[e] < t)], [`${E[e]} > ${E.filter((t, n) => n !== e).join(", ")}`, (t, n, r) => [
	t,
	n,
	r
].every((t, n, r) => n === e || r[e] > t)]])), T(43, "games.turingmachine.cards.c43", [1, 2].flatMap((e) => k("▲", E[e], A(0), A(e)))), T(44, "games.turingmachine.cards.c44", [0, 2].flatMap((e) => k("■", E[e], A(1), A(e)))), T(45, "games.turingmachine.cards.c45", [1, 3].flatMap((e) => [
	0,
	1,
	2
].map((t) => [`#${e} = ${t}`, (n, r, i) => D([
	n,
	r,
	i
], e) === t]))), T(46, "games.turingmachine.cards.c46", [3, 4].flatMap((e) => [
	0,
	1,
	2
].map((t) => [`#${e} = ${t}`, (n, r, i) => D([
	n,
	r,
	i
], e) === t]))), T(47, "games.turingmachine.cards.c47", [1, 4].flatMap((e) => [
	0,
	1,
	2
].map((t) => [`#${e} = ${t}`, (n, r, i) => D([
	n,
	r,
	i
], e) === t]))), T(48, "games.turingmachine.cards.c48", [
	[0, 1],
	[0, 2],
	[1, 2]
].flatMap(([e, t]) => k(E[e], E[t], A(e), A(t))));
var N = w, P = w.flatMap((e) => e.criteria), F = new Map(P.map((e) => [e.id, e])), I = (e) => N[e - 1], L = (e) => F.get(e);
function R(e) {
	let t = 0;
	for (; e;) e &= e - 1n, t++;
	return t;
}
//#endregion
//#region src/games/turingmachine/solver.ts
function z(e) {
	return Array.from({ length: e.verifiers }, (t, n) => (e.mode === "nightmare" ? e.cards : e.groups[n]).flatMap((e) => I(e).criteria));
}
function B(e, t) {
	let n = z(e);
	for (let e of t) {
		let t = S(e.code);
		for (let r of e.answers) n[r.verifier] = n[r.verifier].filter((e) => e.hits[t] === r.passed);
	}
	return n;
}
function ie(e, t = 0, n = 0) {
	if (t === e.length) return !0;
	for (let r of e[t]) {
		let i = 1 << r;
		if (!(n & i) && ie(e, t + 1, n | i)) return !0;
	}
	return !1;
}
function V(e, t, n) {
	let r = e.reduce((e, t) => e & t.reduce((e, t) => e | t.mask, 0n), x), i = [];
	for (let a = 0; a < b.length; a++) r & 1n << BigInt(a) && (t !== "nightmare" || ie(e.map((e) => [...new Set(e.filter((e) => e.hits[a]).map((e) => n.indexOf(e.card)))]).sort((e, t) => e.length - t.length))) && i.push(a);
	return i;
}
function H(e, t) {
	if (!e.length) return 0;
	let n = e.reduce((e, n) => e + Number(n.hits[t]), 0);
	return n * (e.length - n) / (e.length * e.length);
}
function ae(e, t, n) {
	let r = null, i = 0;
	for (let a = 0; a < e.length; a++) {
		if (n.includes(a)) continue;
		let o = H(e[a], t);
		o > i && (i = o, r = a);
	}
	return r;
}
function U(e, t) {
	let n = t[0] ?? 0, r = -1;
	for (let i = 0; i < b.length; i++) {
		let a = e.map((e) => H(e, i)).sort((e, t) => t - e).slice(0, 3).reduce((e, t) => e + t, 0);
		(a > r + 1e-9 || Math.abs(a - r) < 1e-9 && t.includes(i) && !t.includes(n)) && (n = i, r = a);
	}
	return n;
}
function oe(e, t) {
	let n = z(e), r = 0;
	for (let i = 1; i <= 48; i++) {
		let a = V(n, e.mode, e.cards);
		if (a.length === 1) return {
			rounds: i,
			questions: r
		};
		if (!a.length) return null;
		let o = U(n, a), s = [];
		for (let c = 0; c < 3; c++) {
			let c = ae(n, o, s);
			if (c === null) break;
			let l = L(t[c]).hits[o];
			if (n = n.map((e, t) => t === c ? e.filter((e) => e.hits[o] === l) : e), r++, s.push(c), a = V(n, e.mode, e.cards), a.length === 1) return {
				rounds: i,
				questions: r
			};
		}
		if (s.length === 0) return null;
	}
	return null;
}
//#endregion
//#region src/games/turingmachine/generator.ts
function se(t) {
	let n = 0;
	return (r) => e(t, n++, r);
}
function W(e, t) {
	let n = [...e];
	for (let e = n.length - 1; e > 0; e--) {
		let r = t(e + 1);
		[n[e], n[r]] = [n[r], n[e]];
	}
	return n;
}
function ce(e) {
	return e.every((t, n) => (e.reduce((e, t, r) => r === n ? e : e & t.mask, x) & ~t.mask) !== 0n);
}
function le(e, t) {
	let n = se(e);
	for (let e = 0; e < 12e3; e++) {
		let e = n(125), r = P.filter((t) => t.hits[e]), i = [], a = x;
		for (let e = 0; e < t.verifiers; e++) {
			let o = e === t.verifiers - 1, s = r.filter((e) => {
				if (i.some((t) => t.card === e.card)) return !1;
				let t = a & e.mask;
				return t === a || R(t) === 1 !== o ? !1 : ce([...i, e]);
			});
			if (!s.length) break;
			let c = s[n(s.length)];
			i.push(c), a &= c.mask;
		}
		if (i.length !== t.verifiers) continue;
		let o = W(i.map((e) => e.id), n), s = o.map((e) => L(e).card), c = s.map((e) => [e]);
		if (t.mode === "extreme") {
			let e = W(Array.from({ length: 48 }, (e, t) => t + 1).filter((e) => !s.includes(e)), n);
			c = c.map((t, r) => W([...t, e[r]], n));
		}
		let l = c.flat().sort((e, t) => e - t);
		t.mode === "nightmare" && (c = c.map(() => []));
		let u = {
			mode: t.mode,
			verifiers: t.verifiers,
			groups: c,
			cards: l
		}, d = oe(u, o);
		if (d) return {
			...u,
			hidden: o,
			solution: e,
			reference: d
		};
	}
	throw Error("Unable to construct an irredundant puzzle");
}
var ue = (e) => e.rounds * 1e3 + e.questions, de = {
	classic: {
		4: [
			3006,
			3008,
			27,
			6,
			24
		],
		5: [
			3008,
			4010,
			98,
			16,
			14
		],
		6: [
			4010,
			4012,
			13,
			2,
			236
		]
	},
	extreme: {
		4: [
			4011,
			5012,
			159,
			19,
			9
		],
		5: [
			5013,
			6014,
			77,
			2,
			6
		],
		6: [
			6015,
			6017,
			227,
			2,
			9
		]
	},
	nightmare: {
		4: [
			4012,
			5014,
			159,
			77,
			33
		],
		5: [
			6017,
			7019,
			90,
			36,
			7
		],
		6: [
			7020,
			8024,
			26,
			1,
			73
		]
	}
};
function fe(e, t) {
	let [n, r] = de[t.mode][t.verifiers], i = ue(e);
	return i <= n ? "easy" : i <= r ? "standard" : "hard";
}
function pe(e, t) {
	for (let n = 0; n < 24; n++) {
		let r = le(e + Math.imul(n, 2654435769) >>> 0, t);
		if (fe(r.reference, t) === t.difficulty) return r;
	}
	let n = de[t.mode][t.verifiers];
	return le(n[t.difficulty === "easy" ? 2 : t.difficulty === "standard" ? 3 : 4], t);
}
//#endregion
//#region src/games/turingmachine/meta.ts
var G = {
	id: "turingmachine",
	tier: "beta",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.turingmachine.name",
	descKey: "games.turingmachine.desc",
	rulesKey: "games.turingmachine.rules",
	icon: "🧮",
	iconImg: "games/turingmachine.webp",
	rulesUrl: { en: "https://www.scorpionmasque.com/sites/scorpionmasque.com/files/tm_rules_en_11nov2022.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#39745c",
	releasedAt: "2026-10-17T15:29:38+08:00",
	search: {
		py: "tu ling ji turing machine",
		init: "tlj"
	},
	hotseat: "cover"
}, me = t.enum([
	"classic",
	"extreme",
	"nightmare"
]), he = t.enum([
	"easy",
	"standard",
	"hard"
]), K = t.object({
	mode: me.default("classic"),
	difficulty: he.default("easy"),
	verifiers: t.union([
		t.literal(4),
		t.literal(5),
		t.literal(6)
	]).default(4)
}).default({
	mode: "classic",
	difficulty: "easy",
	verifiers: 4
}), q = t.tuple([
	t.int().min(1).max(5),
	t.int().min(1).max(5),
	t.int().min(1).max(5)
]), ge = t.int().min(0).max(5), _e = t.int().min(16).max(783), ve = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("compose"),
		code: q
	}),
	t.object({
		type: t.literal("query"),
		verifier: ge
	}),
	t.object({ type: t.literal("finishQuestions") }),
	t.object({ type: t.literal("nextRound") }),
	t.object({
		type: t.literal("answer"),
		code: q
	}),
	t.object({ type: t.literal("concede") }),
	t.object({
		type: t.literal("noteCriterion"),
		verifier: ge,
		criterion: _e,
		excluded: t.boolean()
	}),
	t.object({
		type: t.literal("noteDigit"),
		position: t.int().min(0).max(2),
		digit: t.int().min(1).max(5)
	}),
	t.object({
		type: t.literal("noteText"),
		text: t.string().max(2e3)
	})
]), ye = t.object({
	round: t.int().min(1),
	code: q,
	answers: t.array(t.object({
		verifier: ge,
		passed: t.boolean()
	})).max(3)
}), be = t.object({
	rounds: t.int().min(1),
	questions: t.int().nonnegative()
}), xe = t.object({
	excludedCriteria: t.array(t.string()),
	excludedDigits: t.array(t.int().min(0).max(14)),
	text: t.string().max(2e3)
}), Se = t.object({
	mode: me,
	difficulty: he,
	verifiers: t.int().min(4).max(6),
	cards: t.array(t.int().min(1).max(48)).min(4).max(12),
	groups: t.array(t.array(t.int().min(1).max(48)).max(2)).min(4).max(6),
	phase: t.enum([
		"compose",
		"question",
		"deduce",
		"done"
	]),
	round: t.int().min(1),
	history: t.array(ye),
	questions: t.int().nonnegative(),
	notes: xe,
	final: t.object({
		outcome: t.enum([
			"solved",
			"incorrect",
			"conceded"
		]),
		solution: q,
		submitted: q.nullable(),
		criteria: t.array(_e).min(4).max(6),
		reference: be
	}).nullable()
}), Ce = t.object({}), J = () => ({ code: "games.turingmachine.errorAction" }), we = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: G,
	schemas: {
		action: ve,
		publicView: Se,
		privateView: Ce,
		config: K
	},
	setup(e, t, n) {
		return { state: {
			owner: t[0],
			config: e,
			puzzle: pe(n, e),
			phase: "compose",
			round: 1,
			history: [],
			notes: {
				excludedCriteria: [],
				excludedDigits: [],
				text: ""
			},
			outcome: null,
			submitted: null
		} };
	},
	reduce(e, t, n) {
		if (n.by !== e.owner || e.phase === "done") return J();
		let r = structuredClone(e);
		switch (t.type) {
			case "compose":
				if (r.phase !== "compose") return { code: "games.turingmachine.errorLocked" };
				r.history.push({
					round: r.round,
					code: [...t.code],
					answers: []
				}), r.phase = "question";
				break;
			case "query": {
				let e = r.history.at(-1);
				if (r.phase !== "question" || !e || t.verifier >= r.config.verifiers || e.answers.length >= 3 || e.answers.some((e) => e.verifier === t.verifier)) return { code: "games.turingmachine.errorQuery" };
				e.answers.push({
					verifier: t.verifier,
					passed: L(r.puzzle.hidden[t.verifier]).hits[S(e.code)]
				}), e.answers.length === 3 && (r.phase = "deduce");
				break;
			}
			case "finishQuestions":
				if (r.phase !== "question") return J();
				r.phase = "deduce";
				break;
			case "nextRound":
				if (r.phase !== "deduce") return J();
				r.round++, r.phase = "compose";
				break;
			case "answer":
				if (r.phase !== "deduce") return J();
				r.submitted = [...t.code], r.outcome = S(t.code) === r.puzzle.solution ? "solved" : "incorrect", r.phase = "done";
				break;
			case "concede":
				r.phase = "done", r.outcome = "conceded";
				break;
			case "noteCriterion": {
				let e = F.get(t.criterion), n = r.config.mode === "nightmare" ? r.puzzle.cards : r.puzzle.groups[t.verifier];
				if (t.verifier >= r.config.verifiers || !e || !n?.includes(e.card)) return { code: "games.turingmachine.errorNote" };
				let i = `${t.verifier}:${t.criterion}`, a = new Set(r.notes.excludedCriteria);
				t.excluded ? a.add(i) : a.delete(i), r.notes.excludedCriteria = [...a];
				break;
			}
			case "noteDigit": {
				let e = t.position * 5 + t.digit - 1;
				r.notes.excludedDigits = r.notes.excludedDigits.includes(e) ? r.notes.excludedDigits.filter((t) => t !== e) : [...r.notes.excludedDigits, e];
				break;
			}
			case "noteText": r.notes.text = t.text;
		}
		return { state: r };
	},
	viewFor(e) {
		return {
			public: structuredClone({
				mode: e.config.mode,
				difficulty: e.config.difficulty,
				verifiers: e.config.verifiers,
				cards: e.puzzle.cards,
				groups: e.puzzle.groups,
				phase: e.phase,
				round: e.round,
				history: e.history,
				questions: e.history.reduce((e, t) => e + t.answers.length, 0),
				notes: e.notes,
				final: e.outcome ? {
					outcome: e.outcome,
					solution: b[e.puzzle.solution],
					submitted: e.submitted,
					criteria: e.puzzle.hidden,
					reference: e.puzzle.reference
				} : null
			}),
			private: {}
		};
	},
	status(e) {
		return e.outcome ? {
			phase: "done",
			winner: e.outcome === "solved" ? [e.owner] : [],
			ranking: [e.owner]
		} : { phase: e.phase };
	}
}, Y = [
	"▲",
	"■",
	"●"
];
function X({ text: e }) {
	return /* @__PURE__ */ g(h, { children: e.split(/([▲■●])/).map((e, t) => Y.includes(e) ? /* @__PURE__ */ g("span", {
		"data-colour": Y.indexOf(e),
		children: e
	}, t) : /* @__PURE__ */ g("span", { children: e }, t)) });
}
function Te({ left: e, right: t }) {
	return /* @__PURE__ */ _("span", {
		className: "turingmachine-balance",
		children: [
			/* @__PURE__ */ g("span", { children: /* @__PURE__ */ g(X, { text: e }) }),
			/* @__PURE__ */ g("span", { children: /* @__PURE__ */ g(X, { text: t }) }),
			/* @__PURE__ */ g("i", {})
		]
	});
}
var Ee = {
	1: ["▲", "1"],
	2: ["▲", "3"],
	3: ["■", "3"],
	4: ["■", "4"],
	11: ["▲", "■"],
	12: ["▲", "●"],
	13: ["■", "●"],
	19: ["▲ + ■", "6"],
	23: ["▲ + ■ + ●", "6"]
};
function De({ id: e }) {
	let t;
	if (Ee[e]) {
		let [n, r] = Ee[e];
		t = /* @__PURE__ */ g(Te, {
			left: n,
			right: r
		});
	} else t = /* @__PURE__ */ g(X, { text: {
		5: "▲ ∈ ?",
		6: "■ ∈ ?",
		7: "● ∈ ?",
		8: "? × 1",
		9: "? × 3",
		10: "? × 4",
		14: "▲ ■ ● ↓",
		15: "▲ ■ ● ↑",
		16: "{2,4} ⇄ {1,3,5}",
		17: "? × {2,4}",
		18: "Σ ∈ ?",
		20: "? × X",
		21: "XX ?",
		22: "▲ ↔ ■ ↔ ●",
		24: "▲ → ■ → ●",
		25: "▲ ↔ ■ ↔ ●",
		26: "? < 3",
		27: "? < 4",
		28: "? = 1",
		29: "? = 3",
		30: "? = 4",
		31: "? > 1",
		32: "? > 3",
		33: "▲ ■ ● ∈ ?",
		34: "▲ ■ ● ≤",
		35: "▲ ■ ● ≥",
		36: "Σ = ? × k",
		37: "? + ? = 4",
		38: "? + ? = 6",
		39: "▲ ■ ● ? 1",
		40: "▲ ■ ● ? 3",
		41: "▲ ■ ● ? 4",
		42: "▲ ■ ● ↕",
		43: "▲ ? ■ ●",
		44: "■ ? ▲ ●",
		45: "? × {1,3}",
		46: "? × {3,4}",
		47: "? × {1,4}",
		48: "▲ ? ■ ? ●"
	}[e] });
	return /* @__PURE__ */ g("span", {
		className: "turingmachine-formula",
		"aria-hidden": !0,
		children: t
	});
}
function Oe({ index: e }) {
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 58 28",
		className: "turingmachine-repetition",
		"aria-hidden": !0,
		children: [
			e === 0 && /* @__PURE__ */ g("rect", {
				x: "2",
				y: "5",
				width: "54",
				height: "18",
				rx: "9"
			}),
			e === 1 && /* @__PURE__ */ g("rect", {
				x: "2",
				y: "5",
				width: "33",
				height: "18",
				rx: "9"
			}),
			[
				0,
				1,
				2
			].map((t) => e === 2 && t === 1 ? /* @__PURE__ */ g("rect", {
				x: 6 + t * 18,
				y: "9",
				width: "10",
				height: "10"
			}, t) : e === 2 && t === 2 || e === 1 && t === 2 ? /* @__PURE__ */ g("path", { d: `M${11 + t * 18} 6 l7 8 -7 8 -7 -8Z` }, t) : /* @__PURE__ */ g("circle", {
				cx: 11 + t * 18,
				cy: "14",
				r: "3.2",
				fill: e === 2 ? "none" : "currentColor"
			}, t))
		]
	});
}
function ke({ descending: e = !1, unordered: t = !1 }) {
	return /* @__PURE__ */ g("svg", {
		className: "turingmachine-order",
		viewBox: "0 0 48 40",
		"aria-hidden": !0,
		children: (t ? [
			18,
			9,
			15
		] : e ? [
			27,
			18,
			8
		] : [
			8,
			18,
			27
		]).map((e, t) => /* @__PURE__ */ _("g", {
			className: "turingmachine-order-shape",
			"data-colour": t,
			children: [/* @__PURE__ */ g("path", {
				d: `M${8 + t * 16} 34V${34 - e}`,
				stroke: "currentColor",
				strokeWidth: "2"
			}), t === 0 ? /* @__PURE__ */ g("path", {
				d: `M${8 + t * 16} ${28 - e}l-6 10h12Z`,
				fill: "currentColor"
			}) : t === 1 ? /* @__PURE__ */ g("rect", {
				x: 3 + t * 16,
				y: 29 - e,
				width: "10",
				height: "10",
				fill: "currentColor"
			}) : /* @__PURE__ */ g("circle", {
				cx: 8 + t * 16,
				cy: 34 - e,
				r: "5",
				fill: "currentColor"
			})]
		}, t))
	});
}
function Ae({ id: e, excluded: t }) {
	let n = l(), r = I(e), i = (e, r) => /* @__PURE__ */ g("span", {
		className: "turingmachine-choice",
		"data-excluded": t(e),
		"data-criterion": e.id,
		"aria-label": e.labelKey ? n(e.labelKey) : e.label,
		title: e.labelKey ? n(e.labelKey) : e.label,
		children: r
	}, e.id), a = (e, t, n) => /* @__PURE__ */ _("span", {
		className: "turingmachine-option-matrix",
		"data-columns": e.length,
		style: {
			gridTemplateColumns: `repeat(${e.length}, minmax(0, 1fr))`,
			gridTemplateRows: `var(--turingmachine-matrix-head, 14px) repeat(${t}, minmax(0, 1fr))`
		},
		children: [e.map((e, t) => /* @__PURE__ */ g("span", {
			className: "turingmachine-pair",
			children: /* @__PURE__ */ g(X, { text: e })
		}, t)), Array.from({ length: t }, (a, o) => e.map((e, a) => i(r.criteria[a * t + o], n(a, o))))]
	});
	if ([
		33,
		39,
		40,
		41,
		42,
		43,
		44,
		45,
		46,
		47,
		48
	].includes(e)) {
		let t = [
			33,
			39,
			42
		].includes(e) ? 2 : 3;
		return a(e === 43 ? ["▲ ? ■", "▲ ? ●"] : e === 44 ? ["■ ? ▲", "■ ? ●"] : e === 48 ? [
			"▲ ? ■",
			"▲ ? ●",
			"■ ? ●"
		] : e >= 45 ? {
			45: ["#1", "#3"],
			46: ["#3", "#4"],
			47: ["#1", "#4"]
		}[e] : Y, t, (t, n) => e === 33 ? /* @__PURE__ */ g("small", { children: n === 0 ? "{2,4}" : "{1,3,5}" }) : e === 39 ? ["=", ">"][n] : e === 42 ? ["↓", "↑"][n] : e >= 45 && e <= 47 ? n : [
			"<",
			"=",
			">"
		][n]);
	}
	let o = e === 20 || e === 21, s = o ? "turingmachine-options-repeat" : r.criteria.length === 4 ? "turingmachine-options-count" : "";
	return /* @__PURE__ */ g("span", {
		className: `turingmachine-options ${s}`,
		children: r.criteria.map((t, r) => {
			let a = /* @__PURE__ */ g(X, { text: t.label });
			if (Ee[e]) a = e === 1 ? ["=", ">"][r] : [
				"<",
				"=",
				">"
			][r];
			else if (e >= 5 && e <= 7) a = /* @__PURE__ */ g("small", { children: r === 0 ? "{2,4}" : "{1,3,5}" });
			else if (e === 18) a = /* @__PURE__ */ g("small", { children: n(r === 0 ? "games.turingmachine.evenShort" : "games.turingmachine.oddShort") });
			else if (e >= 8 && e <= 10 || e === 17) a = /* @__PURE__ */ _(h, { children: [r, /* @__PURE__ */ g("small", { children: n("games.turingmachine.countUnit") })] });
			else if ([
				14,
				15,
				26,
				27,
				28,
				29,
				30,
				31,
				32,
				34,
				35
			].includes(e)) a = /* @__PURE__ */ g(X, { text: Y[r] });
			else if (e === 16) a = /* @__PURE__ */ _("small", { children: [
				n("games.turingmachine.evenShort"),
				" ",
				r === 0 ? ">" : "<",
				" ",
				n("games.turingmachine.oddShort")
			] });
			else if (o) {
				let t = e === 21 ? r === 0 ? 2 : 1 : r, i = e === 21 && r === 0 ? n("games.turingmachine.noPairShort") : [
					n("games.turingmachine.tripleShort"),
					n("games.turingmachine.pairShort"),
					n("games.turingmachine.distinctShort")
				][t];
				a = /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Oe, { index: t }), /* @__PURE__ */ g("small", { children: i })] });
			} else e === 22 ? a = /* @__PURE__ */ _("span", {
				className: "turingmachine-order-option",
				children: [/* @__PURE__ */ g(ke, {
					descending: r === 1,
					unordered: r === 2
				}), /* @__PURE__ */ g("small", { children: r === 0 ? "↗" : r === 1 ? "↘" : n("games.turingmachine.otherOrder") })]
			}) : e === 24 || e === 25 ? a = /* @__PURE__ */ g("small", { children: e === 24 ? [
				"3 ↗",
				"2 ↗",
				"∅"
			][r] : [
				"∅",
				"2 ↔",
				"3 ↗↘"
			][r] }) : e === 36 ? a = /* @__PURE__ */ _("small", { children: [r + 3, "k"] }) : (e === 37 || e === 38) && (a = /* @__PURE__ */ g("small", { children: /* @__PURE__ */ g(X, { text: [
				"▲ + ■",
				"▲ + ●",
				"■ + ●"
			][r] }) }));
			return i(t, a);
		})
	});
}
//#endregion
//#region src/games/turingmachine/components.tsx
var Z = "ABCDEF", je = [
	"games.turingmachine.blue",
	"games.turingmachine.yellow",
	"games.turingmachine.purple"
], Me = [
	"▲",
	"■",
	"●"
];
function Ne(e, t) {
	return e.labelKey ? t(e.labelKey) : e.label;
}
function Pe({ code: e }) {
	return /* @__PURE__ */ g("span", {
		className: "turingmachine-code",
		children: e.map((e, t) => /* @__PURE__ */ _("span", {
			"data-colour": t,
			children: [/* @__PURE__ */ g("span", {
				"aria-hidden": !0,
				children: Me[t]
			}), /* @__PURE__ */ g("strong", { children: e })]
		}, t))
	});
}
function Fe({ code: e, onChange: t, disabled: o = !1, verifier: s, passed: c }) {
	let d = l(), te = r(), f = i(null), p = i(null), m = i([]), [v, y] = a(null), b = o ? null : v, x = (e = !1) => {
		y(null), e && v && m.current[v.position]?.focus();
	}, S = (e) => {
		if (b?.position === e) {
			x();
			return;
		}
		let t = f.current.getBoundingClientRect(), n = m.current[e].getBoundingClientRect(), r = Math.min(292, window.innerWidth - 24), i = Math.max(12, Math.min(n.left + n.width / 2 - r / 2, window.innerWidth - r - 12));
		y({
			position: e,
			left: i,
			top: Math.min(t.top, n.top) - 10,
			width: r,
			pointer: n.left + n.width / 2 - i
		});
	};
	return n(() => {
		if (!b) return;
		p.current?.querySelector("[aria-selected=\"true\"]")?.focus({ preventScroll: !0 });
		let e = () => y(null), t = (t) => {
			let n = t.target;
			!f.current?.contains(n) && !p.current?.contains(n) && e();
		}, n = (t) => {
			let n = t.target;
			!f.current?.contains(n) && !p.current?.contains(n) && e();
		};
		return document.addEventListener("click", t), document.addEventListener("focusin", n), window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			document.removeEventListener("click", t), document.removeEventListener("focusin", n), window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0);
		};
	}, [b]), /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
		ref: f,
		className: "turingmachine-picker",
		role: "group",
		"aria-label": d("games.turingmachine.proposal"),
		"data-locked": o,
		children: [
			/* @__PURE__ */ g("span", {
				className: "turingmachine-reader-lock",
				"aria-label": d(o ? "games.turingmachine.codeLocked" : "games.turingmachine.composePrompt"),
				children: g(o ? u : ee, { size: 13 })
			}),
			/* @__PURE__ */ g("span", {
				className: "turingmachine-reader-side",
				"aria-hidden": !0,
				children: s ?? "?"
			}),
			/* @__PURE__ */ g("div", {
				className: "turingmachine-feed-stack",
				children: e.map((t, n) => /* @__PURE__ */ _("div", {
					className: "turingmachine-punch-card",
					"data-colour": n,
					children: [/* @__PURE__ */ _("button", {
						type: "button",
						ref: (e) => {
							m.current[n] = e;
						},
						className: "turingmachine-number-tab",
						"aria-label": `${d("games.turingmachine.chooseDigit", { color: d(je[n]) })} · ${t}`,
						"aria-haspopup": "listbox",
						"aria-expanded": b?.position === n,
						"aria-controls": b?.position === n ? te : void 0,
						disabled: o,
						onClick: () => S(n),
						onKeyDown: (e) => {
							(e.key === "ArrowUp" || e.key === "ArrowDown") && (e.preventDefault(), S(n));
						},
						children: [/* @__PURE__ */ g("span", {
							"aria-hidden": !0,
							children: Me[n]
						}), /* @__PURE__ */ g("strong", { children: t })]
					}), n === 2 && /* @__PURE__ */ _(h, { children: [["left", "right"].map((t) => /* @__PURE__ */ g("span", {
						className: `turingmachine-punches turingmachine-punches-${t}`,
						"aria-hidden": !0,
						children: Array.from({ length: 15 }, (t, n) => /* @__PURE__ */ g("i", { "data-open": (e[Math.floor(n / 5)] + n) % 5 < 2 }, n))
					}, t)), /* @__PURE__ */ g("span", {
						className: "turingmachine-read-hole",
						"aria-live": "polite",
						children: /* @__PURE__ */ g(Q, { passed: c })
					})] })]
				}, n))
			})
		]
	}), b && ne(/* @__PURE__ */ _("div", {
		ref: p,
		id: te,
		className: "turingmachine-root turingmachine-digit-menu",
		"data-colour": b.position,
		role: "listbox",
		"aria-label": d("games.turingmachine.chooseDigit", { color: d(je[b.position]) }),
		"aria-orientation": "horizontal",
		style: {
			left: b.left,
			top: b.top,
			width: b.width,
			"--turingmachine-pointer": `${b.pointer}px`
		},
		onKeyDown: (e) => {
			if (e.key === "Escape" || e.key === "Tab") {
				e.key === "Escape" && (e.preventDefault(), e.stopPropagation()), x(!0);
				return;
			}
			let t = [...e.currentTarget.querySelectorAll("[role=\"option\"]")], n = t.indexOf(document.activeElement), r = e.key === "Home" ? 0 : e.key === "End" ? 4 : e.key === "ArrowRight" || e.key === "ArrowDown" ? (n + 1) % 5 : e.key === "ArrowLeft" || e.key === "ArrowUp" ? (n + 4) % 5 : null;
			r !== null && (e.preventDefault(), t[r].focus());
		},
		children: [/* @__PURE__ */ g("span", {
			className: "turingmachine-digit-shape",
			"aria-hidden": !0,
			children: Me[b.position]
		}), [
			1,
			2,
			3,
			4,
			5
		].map((n) => /* @__PURE__ */ g("button", {
			type: "button",
			role: "option",
			"aria-selected": e[b.position] === n,
			tabIndex: e[b.position] === n ? 0 : -1,
			onClick: () => {
				let r = [...e];
				r[b.position] = n, t(r), x(!0);
			},
			children: n
		}, n))]
	}), document.body)] });
}
function Q({ passed: e }) {
	let t = l();
	return /* @__PURE__ */ g("span", {
		className: "turingmachine-test-result",
		"data-result": e === void 0 ? "empty" : e ? "pass" : "fail",
		"aria-label": t(e === void 0 ? "games.turingmachine.notAsked" : e ? "games.turingmachine.passed" : "games.turingmachine.failed"),
		children: e === void 0 ? /* @__PURE__ */ g("span", {
			"aria-hidden": !0,
			children: "·"
		}) : g(e ? u : d, {
			size: 20,
			"aria-hidden": !0
		})
	});
}
function Ie({ id: e, letter: t = "?", selected: n = !1, passed: r, excluded: i = () => !1, onClick: a }) {
	let o = l(), s = I(e);
	return /* @__PURE__ */ _("button", {
		className: "turingmachine-card",
		onClick: a,
		"data-selected": n,
		"data-card": e,
		"aria-pressed": n,
		"aria-label": `${t === "?" ? o("games.turingmachine.inspectCard", { n: e }) : o("games.turingmachine.selectVerifier", { letter: t })} · ${o(s.titleKey)}`,
		children: [
			/* @__PURE__ */ _("span", {
				className: "turingmachine-card-head",
				children: [
					/* @__PURE__ */ g("strong", { children: t }),
					r !== void 0 && /* @__PURE__ */ g(Q, { passed: r }),
					/* @__PURE__ */ g("span", {
						className: "turingmachine-card-number",
						children: String(e).padStart(2, "0")
					})
				]
			}),
			/* @__PURE__ */ g(De, { id: e }),
			/* @__PURE__ */ g(Ae, {
				id: e,
				excluded: i
			})
		]
	});
}
function Le({ view: e }) {
	let t = l();
	return e.history.length ? /* @__PURE__ */ g("div", {
		className: "turingmachine-records",
		children: /* @__PURE__ */ _("table", { children: [/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [
			/* @__PURE__ */ g("th", {
				"aria-label": t("games.turingmachine.round", { n: e.round }),
				children: "#"
			}),
			/* @__PURE__ */ g("th", { children: t("games.turingmachine.proposal") }),
			Array.from({ length: e.verifiers }, (e, t) => /* @__PURE__ */ g("th", { children: Z[t] }, t))
		] }) }), /* @__PURE__ */ g("tbody", { children: e.history.map((t) => /* @__PURE__ */ _("tr", { children: [
			/* @__PURE__ */ g("th", { children: t.round }),
			/* @__PURE__ */ g("td", { children: /* @__PURE__ */ g(Pe, { code: t.code }) }),
			Array.from({ length: e.verifiers }, (e, n) => /* @__PURE__ */ g("td", { children: /* @__PURE__ */ g(Q, { passed: t.answers.find((e) => e.verifier === n)?.passed }) }, n))
		] }, t.round)) })] })
	}) : /* @__PURE__ */ g("p", {
		className: "turingmachine-empty",
		children: t("games.turingmachine.noRecords")
	});
}
//#endregion
//#region src/games/turingmachine/options.tsx
var $ = {
	classic: "games.turingmachine.classic",
	extreme: "games.turingmachine.extreme",
	nightmare: "games.turingmachine.nightmare"
}, Re = {
	easy: "games.turingmachine.easy",
	standard: "games.turingmachine.standard",
	hard: "games.turingmachine.hard"
}, ze = {
	classic: "games.turingmachine.classicHint",
	extreme: "games.turingmachine.extremeHint",
	nightmare: "games.turingmachine.nightmareHint"
};
function Be({ value: e, onChange: t }) {
	let n = l(), r = K.safeParse(e), i = r.success ? r.data : K.parse(void 0), a = (e) => t({
		...i,
		...e
	});
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ g(y, {
				title: n("games.turingmachine.mode"),
				columns: 3,
				children: [
					"classic",
					"extreme",
					"nightmare"
				].map((e) => /* @__PURE__ */ g(v, {
					name: "turingmachine-mode",
					value: e,
					checked: i.mode === e,
					label: n($[e]),
					hint: n(ze[e]),
					accent: G.accent,
					onChange: () => a({ mode: e })
				}, e))
			}),
			/* @__PURE__ */ g(y, {
				title: n("games.turingmachine.difficulty"),
				columns: 3,
				children: [
					"easy",
					"standard",
					"hard"
				].map((e) => /* @__PURE__ */ g(v, {
					name: "turingmachine-difficulty",
					value: e,
					checked: i.difficulty === e,
					label: n(Re[e]),
					accent: G.accent,
					onChange: () => a({ difficulty: e })
				}, e))
			}),
			/* @__PURE__ */ g("p", {
				className: "text-sm text-ink/65",
				children: n("games.turingmachine.difficultyHint")
			}),
			/* @__PURE__ */ g(y, {
				title: n("games.turingmachine.verifierCount"),
				columns: 3,
				children: [
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ g(v, {
					name: "turingmachine-verifiers",
					value: String(e),
					checked: i.verifiers === e,
					label: n("games.turingmachine.verifierCountValue", { n: e }),
					accent: G.accent,
					onChange: () => a({ verifiers: e })
				}, e))
			})
		]
	});
}
//#endregion
//#region src/games/turingmachine/view-player.tsx
var Ve = {
	compose: "games.turingmachine.composePrompt",
	question: "games.turingmachine.questionPrompt",
	deduce: "games.turingmachine.deducePrompt",
	done: "games.turingmachine.solved"
};
function He({ public: e, send: t }) {
	let n = e, r = l(), i = c((e) => e.locale);
	p();
	let [ne, v] = a(!1), [y, b] = a(0), [x, S] = a(null), [C, w] = a([
		1,
		1,
		1
	]), [T, E] = a([
		1,
		1,
		1
	]), [D, O] = a(!1), [k, A] = a(null), [j, M] = a(0), [re, N] = a(!1), [P, F] = a(n.notes.text), L = n.history.find((e) => e.round === n.round), R = L?.answers ?? [], z = n.phase === "compose" ? C : L?.code ?? C, B = (e, t) => {
		A(e), M(t);
	}, ie = () => {
		F(n.notes.text), N(!0);
	}, V = k === null ? null : I(k), H = R.find((e) => e.verifier === y), ae = n.phase === "question" && !H && R.length < 3, U = (e, t) => {
		S(e), b(t);
	};
	return /* @__PURE__ */ _("div", {
		className: "turingmachine-root",
		lang: i,
		children: [
			/* @__PURE__ */ g(m, {
				adaptive: !0,
				className: "turingmachine-layout",
				scroll: !1,
				actionsHeight: "turingmachine-actions-slot h-[156px] wide:h-[96px] short:h-[96px]",
				banner: /* @__PURE__ */ _("div", {
					className: "turingmachine-banner",
					children: [
						/* @__PURE__ */ _("div", {
							className: "turingmachine-meta",
							children: [
								/* @__PURE__ */ _("span", {
									className: "turingmachine-brand",
									"aria-hidden": !0,
									children: [
										/* @__PURE__ */ g("i", {
											"data-colour": "0",
											children: "▲"
										}),
										/* @__PURE__ */ g("i", {
											"data-colour": "1",
											children: "■"
										}),
										/* @__PURE__ */ g("i", {
											"data-colour": "2",
											children: "●"
										})
									]
								}),
								/* @__PURE__ */ g("strong", { children: r("games.turingmachine.name") }),
								/* @__PURE__ */ _("span", { children: [
									r($[n.mode]),
									" · ",
									r(Re[n.difficulty])
								] })
							]
						}),
						/* @__PURE__ */ _("div", {
							className: "turingmachine-status",
							children: [/* @__PURE__ */ g("strong", { children: r("games.turingmachine.round", { n: n.round }) }), /* @__PURE__ */ _("div", {
								className: "turingmachine-quota",
								children: [/* @__PURE__ */ g("span", { children: r("games.turingmachine.questionQuota", { n: R.length }) }), /* @__PURE__ */ g("span", {
									"aria-hidden": !0,
									children: [
										0,
										1,
										2
									].map((e) => /* @__PURE__ */ g("i", { "data-used": e < R.length }, e))
								})]
							})]
						}),
						/* @__PURE__ */ g("span", {
							className: "sr-only",
							"aria-live": "polite",
							children: r(Ve[n.phase])
						})
					]
				}),
				actions: /* @__PURE__ */ _("div", {
					className: "turingmachine-controls",
					children: [/* @__PURE__ */ _("section", {
						className: "turingmachine-sidebar-records",
						children: [/* @__PURE__ */ g("h2", { children: r("games.turingmachine.records") }), /* @__PURE__ */ g(Le, { view: n })]
					}), /* @__PURE__ */ _("div", {
						className: "turingmachine-reader-actions",
						children: [/* @__PURE__ */ g(Fe, {
							code: z,
							disabled: n.phase !== "compose",
							onChange: w,
							verifier: Z[y],
							passed: H?.passed
						}), /* @__PURE__ */ g("div", {
							className: "turingmachine-actions",
							children: /* @__PURE__ */ _("div", {
								className: "turingmachine-action-buttons",
								children: [
									n.phase === "compose" && /* @__PURE__ */ g("button", {
										className: "btn-base turingmachine-primary",
										onClick: () => t({
											type: "compose",
											code: C
										}),
										children: r("games.turingmachine.begin")
									}),
									n.phase === "question" && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("button", {
										className: "btn-base turingmachine-secondary",
										onClick: () => t({ type: "finishQuestions" }),
										children: r("games.turingmachine.finishQuestions")
									}), /* @__PURE__ */ g("button", {
										className: "btn-base turingmachine-primary",
										disabled: !ae,
										onClick: () => t({
											type: "query",
											verifier: y
										}),
										children: r("games.turingmachine.askVerifier", { letter: "ABCDEF"[y] })
									})] }),
									n.phase === "deduce" && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("button", {
										className: "btn-base turingmachine-secondary",
										onClick: () => t({ type: "nextRound" }),
										children: r("games.turingmachine.nextRound")
									}), /* @__PURE__ */ g("button", {
										className: "btn-base turingmachine-primary",
										onClick: () => {
											E([...z]), O(!0);
										},
										children: r("games.turingmachine.submit")
									})] })
								]
							})
						})]
					})]
				}),
				children: /* @__PURE__ */ _("div", {
					className: "turingmachine-table",
					children: [
						/* @__PURE__ */ _("div", {
							className: "turingmachine-rackbar",
							"aria-hidden": !0,
							children: [/* @__PURE__ */ g("i", {}), /* @__PURE__ */ g("i", {})]
						}),
						n.mode === "nightmare" && /* @__PURE__ */ g("div", {
							className: "turingmachine-sockets",
							role: "group",
							"aria-label": r("games.turingmachine.verifiers"),
							children: Array.from({ length: n.verifiers }, (e, t) => {
								let n = R.find((e) => e.verifier === t);
								return /* @__PURE__ */ _("button", {
									className: "turingmachine-socket",
									"aria-pressed": y === t,
									onClick: () => b(t),
									"aria-label": r("games.turingmachine.selectVerifier", { letter: "ABCDEF"[t] }),
									children: [/* @__PURE__ */ g("strong", { children: "ABCDEF"[t] }), /* @__PURE__ */ g(Q, { passed: n?.passed })]
								}, t);
							})
						}),
						/* @__PURE__ */ g("div", {
							className: "turingmachine-central",
							children: /* @__PURE__ */ g("div", {
								className: `turingmachine-deck ${n.mode === "extreme" ? "turingmachine-deck-extreme" : ""}`,
								"data-rows": Math.ceil(n.verifiers / 2),
								children: n.mode === "nightmare" ? n.cards.map((e) => /* @__PURE__ */ g(Ie, {
									id: e,
									excluded: (e) => n.notes.excludedCriteria.includes(`${y}:${e.id}`),
									onClick: () => {
										S(e), B(e, y);
									}
								}, e)) : n.mode === "classic" ? n.groups.map(([e], t) => /* @__PURE__ */ g(Ie, {
									id: e,
									letter: Z[t],
									selected: y === t,
									passed: R.find((e) => e.verifier === t)?.passed,
									excluded: (e) => n.notes.excludedCriteria.includes(`${t}:${e.id}`),
									onClick: () => U(e, t)
								}, e)) : n.groups.map((e, t) => /* @__PURE__ */ g("div", {
									className: "turingmachine-card-group",
									"data-selected": y === t,
									children: e.map((r) => /* @__PURE__ */ g(Ie, {
										id: r,
										letter: Z[t],
										selected: y === t && (x === r || x === null && t === 0 && r === e[0]),
										passed: R.find((e) => e.verifier === t)?.passed,
										excluded: (e) => n.notes.excludedCriteria.includes(`${t}:${e.id}`),
										onClick: () => U(r, t)
									}, r))
								}, t))
							})
						}),
						/* @__PURE__ */ _("nav", {
							className: "turingmachine-utility",
							"aria-label": r("games.turingmachine.name"),
							children: [
								/* @__PURE__ */ _("button", {
									onClick: () => v(!0),
									children: [
										/* @__PURE__ */ g(f, { size: 17 }),
										r("games.turingmachine.recordsShort"),
										/* @__PURE__ */ g("b", { children: n.questions })
									]
								}),
								/* @__PURE__ */ g("span", { "aria-hidden": !0 }),
								/* @__PURE__ */ g("button", {
									"aria-label": r("games.turingmachine.conditionDetails"),
									onClick: () => B(x ?? (n.mode === "nightmare" ? n.cards[0] : n.groups[y][0]), y),
									children: /* @__PURE__ */ g(te, { size: 18 })
								}),
								/* @__PURE__ */ _("button", {
									onClick: ie,
									children: [/* @__PURE__ */ g(ee, { size: 17 }), r("games.turingmachine.notesShort")]
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ g(o, {
				open: ne,
				onClose: () => v(!1),
				label: r("games.turingmachine.records"),
				title: r("games.turingmachine.records"),
				children: /* @__PURE__ */ g("div", {
					className: "turingmachine-root turingmachine-detail",
					children: /* @__PURE__ */ g(Le, { view: n })
				})
			}),
			/* @__PURE__ */ g(o, {
				open: V !== null,
				onClose: () => A(null),
				label: r("games.turingmachine.cardsLabel"),
				title: V ? `${String(V.id).padStart(2, "0")} · ${r(V.titleKey)}` : void 0,
				children: V && /* @__PURE__ */ _("div", {
					className: "turingmachine-root turingmachine-detail",
					children: [
						n.mode === "nightmare" && /* @__PURE__ */ g("div", {
							className: "turingmachine-note-verifiers",
							children: Array.from({ length: n.verifiers }, (e, t) => /* @__PURE__ */ g("button", {
								"aria-pressed": j === t,
								onClick: () => M(t),
								children: "ABCDEF"[t]
							}, t))
						}),
						/* @__PURE__ */ _("h3", { children: [
							r("games.turingmachine.verifier", { letter: "ABCDEF"[j] }),
							" · ",
							r("games.turingmachine.conditionNotes")
						] }),
						V.criteria.map((e) => {
							let i = n.notes.excludedCriteria.includes(`${j}:${e.id}`), a = Ne(e, r);
							return /* @__PURE__ */ _("button", {
								className: "turingmachine-criterion",
								"data-excluded": i,
								"aria-pressed": i,
								"aria-label": r(i ? "games.turingmachine.restoreCondition" : "games.turingmachine.excludeCondition", { condition: a }),
								onClick: () => t({
									type: "noteCriterion",
									verifier: j,
									criterion: e.id,
									excluded: !i
								}),
								children: [/* @__PURE__ */ g("span", {
									className: "turingmachine-note-box",
									children: i && /* @__PURE__ */ g(d, { size: 18 })
								}), /* @__PURE__ */ g("span", { children: a })]
							}, e.id);
						})
					]
				})
			}),
			/* @__PURE__ */ g(o, {
				open: re,
				onClose: () => {
					t({
						type: "noteText",
						text: P
					}), N(!1);
				},
				label: r("games.turingmachine.notes"),
				title: r("games.turingmachine.notes"),
				children: /* @__PURE__ */ _("div", {
					className: "turingmachine-root turingmachine-detail",
					children: [
						/* @__PURE__ */ g("h3", { children: r("games.turingmachine.numberNotes") }),
						/* @__PURE__ */ g("div", {
							className: "turingmachine-number-notes",
							children: je.map((e, i) => /* @__PURE__ */ _("div", {
								"data-colour": i,
								children: [/* @__PURE__ */ g("span", {
									"aria-label": r(e),
									children: [
										"▲",
										"■",
										"●"
									][i]
								}), [
									1,
									2,
									3,
									4,
									5
								].map((a) => {
									let o = n.notes.excludedDigits.includes(i * 5 + a - 1);
									return /* @__PURE__ */ g("button", {
										"aria-pressed": o,
										"data-excluded": o,
										"aria-label": r(o ? "games.turingmachine.restoreDigit" : "games.turingmachine.excludeDigit", {
											color: r(e),
											n: a
										}),
										onClick: () => t({
											type: "noteDigit",
											position: i,
											digit: a
										}),
										children: a
									}, a);
								})]
							}, e))
						}),
						/* @__PURE__ */ g("textarea", {
							"aria-label": r("games.turingmachine.notes"),
							placeholder: r("games.turingmachine.notesPlaceholder"),
							maxLength: 2e3,
							rows: 5,
							value: P,
							onChange: (e) => F(e.target.value)
						}),
						/* @__PURE__ */ g("button", {
							className: "btn-base turingmachine-primary",
							onClick: () => {
								t({
									type: "noteText",
									text: P
								}), N(!1);
							},
							children: r("games.turingmachine.saveNotes")
						}),
						/* @__PURE__ */ g(s, {
							label: r("games.turingmachine.giveUp"),
							confirmLabel: r("games.turingmachine.confirmGiveUp"),
							onConfirm: () => t({ type: "concede" })
						})
					]
				})
			}),
			/* @__PURE__ */ g(o, {
				open: D,
				onClose: () => O(!1),
				label: r("games.turingmachine.submitTitle"),
				title: r("games.turingmachine.submitTitle"),
				children: /* @__PURE__ */ _("div", {
					className: "turingmachine-root turingmachine-detail",
					children: [
						/* @__PURE__ */ g(Fe, {
							code: T,
							onChange: E
						}),
						/* @__PURE__ */ g("p", {
							className: "text-sm text-warn-ink",
							children: r("games.turingmachine.submitWarning")
						}),
						/* @__PURE__ */ _("button", {
							className: "btn-base turingmachine-primary",
							onClick: () => {
								O(!1), t({
									type: "answer",
									code: T
								});
							},
							children: [/* @__PURE__ */ g(u, { size: 20 }), r("games.turingmachine.confirmSubmit")]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/turingmachine/bot.ts
var Ue = ({ public: e }) => {
	if (e.phase === "done") return null;
	let t = B(e, e.history), n = V(t, e.mode, e.cards);
	if (!n.length) return null;
	if (e.phase === "compose") return { action: {
		type: "compose",
		code: b[U(t, n)]
	} };
	if (e.phase === "deduce") return { action: n.length === 1 ? {
		type: "answer",
		code: b[n[0]]
	} : { type: "nextRound" } };
	let r = e.history.at(-1), i = ae(t, S(r.code), r.answers.map((e) => e.verifier));
	return { action: n.length === 1 || i === null ? { type: "finishQuestions" } : {
		type: "query",
		verifier: i
	} };
}, We = (e, t, n) => {
	switch (e.type) {
		case "compose": return n("games.turingmachine.hintCompose", { code: C(e.code) });
		case "query": return n("games.turingmachine.hintQuery", { letter: "ABCDEF"[e.verifier] });
		case "answer": return n("games.turingmachine.hintAnswer", { code: C(e.code) });
		case "nextRound": return n("games.turingmachine.hintNext");
		default: return n("games.turingmachine.hintFinish");
	}
};
//#endregion
//#region src/games/turingmachine/game-over.tsx
function Ge({ public: e, onPlayAgain: t, onPlayAgainWithConfig: n, onBackToLobby: r }) {
	let i = e, a = l(), o = i.final;
	if (!o) return null;
	let s = o.outcome === "solved", c = i.round - o.reference.rounds || i.questions - o.reference.questions;
	return /* @__PURE__ */ _("div", {
		className: "turingmachine-root turingmachine-over",
		children: [/* @__PURE__ */ _("div", {
			className: "turingmachine-over-scroll",
			children: [
				/* @__PURE__ */ _("header", {
					className: "turingmachine-over-title",
					"data-solved": s,
					children: [
						/* @__PURE__ */ _("p", { children: [
							a($[i.mode]),
							" · ",
							a(Re[i.difficulty])
						] }),
						/* @__PURE__ */ g("h1", { children: a(s ? "games.turingmachine.solved" : o.outcome === "incorrect" ? "games.turingmachine.incorrect" : "games.turingmachine.conceded") }),
						/* @__PURE__ */ g("span", { children: a("games.turingmachine.solution") }),
						/* @__PURE__ */ g(Pe, { code: o.solution }),
						o.submitted && !s && /* @__PURE__ */ _("div", {
							className: "turingmachine-submitted",
							children: [a("games.turingmachine.yourAnswer"), /* @__PURE__ */ g(Pe, { code: o.submitted })]
						})
					]
				}),
				/* @__PURE__ */ _("div", {
					className: "turingmachine-score",
					children: [/* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("span", { children: a("games.turingmachine.roundsUsed") }), /* @__PURE__ */ g("strong", { children: i.round })] }), /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ g("span", { children: a("games.turingmachine.questionsUsed") }), /* @__PURE__ */ g("strong", { children: i.questions })] })]
				}),
				/* @__PURE__ */ _("section", {
					className: "turingmachine-reference",
					children: [
						/* @__PURE__ */ g("h2", { children: a("games.turingmachine.reference") }),
						/* @__PURE__ */ g("p", { children: a("games.turingmachine.referenceValue", o.reference) }),
						s && /* @__PURE__ */ g("p", { children: a(c < 0 ? "games.turingmachine.better" : c === 0 ? "games.turingmachine.equal" : "games.turingmachine.slower") })
					]
				}),
				/* @__PURE__ */ _("section", {
					className: "turingmachine-reveal",
					children: [/* @__PURE__ */ g("h2", { children: a("games.turingmachine.explanation") }), o.criteria.map((e, t) => {
						let n = L(e);
						return /* @__PURE__ */ _("div", { children: [
							/* @__PURE__ */ g("strong", { children: Z[t] }),
							/* @__PURE__ */ g("span", {
								className: "turingmachine-reveal-number",
								children: String(n.card).padStart(2, "0")
							}),
							/* @__PURE__ */ g("span", { children: Ne(n, a) })
						] }, t);
					})]
				}),
				/* @__PURE__ */ _("section", {
					className: "turingmachine-over-records",
					children: [/* @__PURE__ */ g("h2", { children: a("games.turingmachine.records") }), /* @__PURE__ */ g(Le, { view: i })]
				})
			]
		}), /* @__PURE__ */ _("div", {
			className: "turingmachine-over-actions",
			children: [(n || t) && /* @__PURE__ */ g("button", {
				className: "btn-base turingmachine-primary",
				onClick: () => n ? n({
					mode: i.mode,
					difficulty: i.difficulty,
					verifiers: i.verifiers
				}) : t?.(),
				children: a("session.result.playAgain")
			}), r && /* @__PURE__ */ g("button", {
				className: "btn-quiet",
				onClick: r,
				children: a("session.result.backToLobby")
			})]
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/turingmachine/entry.tsx
var Ke = {
	definition: we,
	View: He,
	bot: Ue,
	describe: We,
	OverView: Ge,
	Options: Be,
	locales: {
		zh: {
			name: "图灵机",
			desc: "向验证器提问，从条件与线索中推导唯一密码",
			rules: "目标：\n· 找出由蓝色三角、黄色方块、紫色圆形组成的密码。\n· 三个数字分别为 1 至 5，允许重复。\n准备：\n· 选择经典、极限或噩梦模式，以及难度和验证器数量。\n· 每个验证器秘密采用一个条件；全体条件恰好确定一个密码。\n· 每个验证器都不可缺少，可将此作为推理依据。\n模式：\n· 经典：每个验证器对应一张条件卡。\n· 极限：每个验证器对应两张卡，合计只有一个条件生效。\n· 噩梦：条件卡全部公开，卡片与验证器的对应关系隐藏。\n· 噩梦中每张条件卡恰好对应一个验证器。\n流程：\n· 每轮选择一组试探密码，开始验证后本轮不能更换。\n· 每轮最多询问三个不同的验证器，也可提前结束提问。\n· 勾号表示通过该验证器的条件，叉号表示未通过。\n· 回答只说明该验证器的条件，不能直接否定其他数字。\n· 记录自动保存；可在条件详情中手动排除条件。\n· 笔记中的数字和条件可再次点击恢复，不会改变验证结果。\n· 提问结束后，可以进入下一轮或提交最终答案。\n条件图例：\n· 井号后的数字表示统计对象，例如井号 1 表示数字 1 的个数。\n· 偶数为 2、4，奇数为 1、3、5；小于、大于均不包括相等。\n· 成对指恰有两个数字相同，三个相同不属于成对。\n· 升序和降序要求三个数字严格递增或严格递减。\n· 连续数列要求相邻位置相差 1，三个连续数字方向须相同。\n结束：\n· 最终答案正确则解谜成功，错误或放弃则挑战结束。\n· 结算展示正确条件、使用轮数、提问次数与本地参考成绩。\n· 三档难度与参考成绩由本地求解器评估。\n· 参考成绩不是官方机器成绩，也不保证为最少提问次数。",
			mode: "规则模式",
			classic: "经典",
			extreme: "极限",
			nightmare: "噩梦",
			classicHint: "每个验证器对应一张卡",
			extremeHint: "每个验证器对应两张卡",
			nightmareHint: "条件卡的对应关系隐藏",
			difficulty: "难度",
			easy: "简单",
			standard: "标准",
			hard: "困难",
			difficultyHint: "根据本地求解器的轮数与提问次数分级。",
			verifierCount: "验证器数量",
			verifierCountValue: "{{n}} 个",
			round: "第 {{n}} 轮",
			totalQuestions: "已提问 {{n}} 次",
			questionQuota: "本轮 {{n}} / 3 次",
			composePrompt: "选择本轮的试探密码",
			questionPrompt: "选择要询问的验证器",
			deducePrompt: "整理线索，继续推理或提交答案",
			begin: "开始验证",
			finishQuestions: "结束提问",
			nextRound: "下一轮",
			submit: "提交答案",
			submitTitle: "最终答案",
			submitWarning: "答案错误将结束本次挑战。",
			confirmSubmit: "确认提交",
			blue: "蓝色三角",
			yellow: "黄色方块",
			purple: "紫色圆形",
			chooseDigit: "选择{{color}}的数字",
			selectVerifier: "选择验证器 {{letter}}",
			codeLocked: "本轮密码已锁定",
			recordsShort: "记录",
			notesShort: "笔记",
			conditionDetails: "条件详情",
			countUnit: "个",
			tripleShort: "三个相同",
			pairShort: "恰好一对",
			distinctShort: "各不相同",
			noPairShort: "没有一对",
			otherOrder: "其他",
			evenShort: "偶数",
			oddShort: "奇数",
			verifiers: "验证器",
			cardsLabel: "条件卡",
			records: "验证记录",
			notes: "推理笔记",
			verifier: "验证器 {{letter}}",
			inspectCard: "查看 {{n}} 号条件卡",
			askVerifier: "询问验证器 {{letter}}",
			passed: "通过",
			failed: "未通过",
			notAsked: "尚未询问",
			hiddenPairing: "对应关系未知",
			noRecords: "开始验证后，提问结果将记录在这里。",
			proposal: "试探密码",
			numberNotes: "数字排除",
			conditionNotes: "条件排除",
			notesPlaceholder: "记录你的推理……",
			saveNotes: "保存笔记",
			excludeCondition: "排除条件：{{condition}}",
			restoreCondition: "恢复条件：{{condition}}",
			excludeDigit: "排除{{color}}的数字 {{n}}",
			restoreDigit: "恢复{{color}}的数字 {{n}}",
			conceded: "本次挑战已结束",
			solved: "解谜成功",
			incorrect: "答案不正确",
			solution: "正确密码",
			yourAnswer: "你的答案",
			roundsUsed: "使用轮数",
			questionsUsed: "提问次数",
			reference: "本地参考成绩",
			referenceValue: "{{rounds}} 轮 · {{questions}} 次提问",
			better: "你的成绩优于参考成绩",
			equal: "你的成绩与参考成绩相同",
			slower: "你已找到密码，可以再次挑战更少的提问",
			explanation: "验证器采用的条件",
			giveUp: "放弃挑战",
			confirmGiveUp: "确认放弃",
			errorAction: "当前不能执行此操作",
			errorLocked: "本轮的试探密码已经确定",
			errorQuery: "请选择本轮尚未询问的验证器，每轮最多提问三次",
			errorNote: "请选择本题可见的条件",
			hintCompose: "建议用 {{code}} 开始本轮验证",
			hintQuery: "建议询问验证器 {{letter}}",
			hintFinish: "可以结束本轮提问",
			hintNext: "可以开始下一轮",
			hintAnswer: "根据已有线索，建议提交 {{code}}",
			cards: {
				c1: "蓝色数字与 1 比较",
				c2: "蓝色数字与 3 比较",
				c3: "黄色数字与 3 比较",
				c4: "黄色数字与 4 比较",
				c5: "蓝色数字的奇偶",
				c6: "黄色数字的奇偶",
				c7: "紫色数字的奇偶",
				c8: "数字 1 的个数",
				c9: "数字 3 的个数",
				c10: "数字 4 的个数",
				c11: "蓝色与黄色比较",
				c12: "蓝色与紫色比较",
				c13: "黄色与紫色比较",
				c14: "严格最小的颜色",
				c15: "严格最大的颜色",
				c16: "奇数与偶数的数量比较",
				c17: "偶数的个数",
				c18: "总和的奇偶",
				c19: "蓝色与黄色之和与 6 比较",
				c20: "数字的重复情况",
				c21: "是否恰有一对相同数字",
				c22: "数字的升降顺序",
				c23: "三个数字之和与 6 比较",
				c24: "连续递增数列",
				c25: "连续递增或递减数列",
				c26: "某种颜色小于 3",
				c27: "某种颜色小于 4",
				c28: "某种颜色等于 1",
				c29: "某种颜色等于 3",
				c30: "某种颜色等于 4",
				c31: "某种颜色大于 1",
				c32: "某种颜色大于 3",
				c33: "某种颜色的奇偶",
				c34: "允许并列的最小颜色",
				c35: "允许并列的最大颜色",
				c36: "总和为 3、4 或 5 的倍数",
				c37: "某两种颜色之和等于 4",
				c38: "某两种颜色之和等于 6",
				c39: "某种颜色与 1 比较",
				c40: "某种颜色与 3 比较",
				c41: "某种颜色与 4 比较",
				c42: "某种颜色严格最小或最大",
				c43: "蓝色与另一种颜色比较",
				c44: "黄色与另一种颜色比较",
				c45: "数字 1 或数字 3 的个数",
				c46: "数字 3 或数字 4 的个数",
				c47: "数字 1 或数字 4 的个数",
				c48: "某两种颜色的大小关系"
			},
			criteria: {
				moreEven: "偶数多于奇数",
				moreOdd: "奇数多于偶数",
				evenSum: "三个数字之和为偶数",
				oddSum: "三个数字之和为奇数",
				triple: "三个数字相同",
				pair: "恰有两个数字相同",
				distinct: "三个数字各不相同",
				noPair: "没有恰好一对相同数字",
				unordered: "既非严格升序，也非严格降序",
				increasingThree: "三个数字连续递增",
				increasingTwo: "恰有一组相邻数字连续递增",
				increasingNone: "没有相邻数字连续递增",
				sequenceThree: "三个数字同向连续递增或递减",
				sequenceTwo: "有两个连续数字，但三个不构成同向连续数列",
				sequenceNone: "没有相邻的连续数字"
			}
		},
		en: {
			name: "Turing Machine",
			desc: "Question the Verifiers and deduce the unique secret code",
			rules: "Goal:\n· Find the code formed by a blue triangle, yellow square, and purple circle.\n· Each digit is from 1 to 5; repeated digits are allowed.\nSetup:\n· Choose Classic, Extreme, or Nightmare, a difficulty, and a Verifier count.\n· Each Verifier secretly uses one criterion; together they identify exactly one code.\n· Every Verifier is essential; you may use this fact in your deductions.\nModes:\n· Classic: each Verifier has one Criteria card.\n· Extreme: each Verifier has two cards, with only one active criterion in total.\n· Nightmare: all cards are visible, but their Verifier assignments are hidden.\n· In Nightmare, each card belongs to exactly one Verifier.\nPlay:\n· Choose one proposal per round; it cannot change once questioning begins.\n· Question up to three different Verifiers per round, or stop earlier.\n· A check means the proposal passes that criterion; a cross means it fails.\n· An answer only concerns that criterion; it does not rule out unrelated digits.\n· Answers are recorded automatically; cross off criteria in Criterion details.\n· Tap crossed-off digits or criteria again to restore them; answers do not change.\n· After questioning, start another round or submit your final answer.\nCriteria guide:\n· A number after a hash is what you count: hash 1 means the number of ones.\n· Even digits are 2 and 4; odd digits are 1, 3, and 5. Strict comparisons exclude equality.\n· A pair means exactly two equal digits; three equal digits are not a pair.\n· Ascending and descending mean all three digits increase or decrease strictly.\n· Consecutive digits differ by 1 in adjacent positions; a three-digit run has one direction.\nEnd:\n· A correct final answer solves the puzzle; a wrong answer or giving up ends the attempt.\n· Results show the actual criteria, your rounds and questions, and a local reference score.\n· Difficulty levels and reference scores are evaluated by the local solver.\n· The reference is not the official Machine score or a guaranteed minimum.",
			mode: "Mode",
			classic: "Classic",
			extreme: "Extreme",
			nightmare: "Nightmare",
			classicHint: "One card per Verifier",
			extremeHint: "Two cards per Verifier",
			nightmareHint: "Card assignments are hidden",
			difficulty: "Difficulty",
			easy: "Easy",
			standard: "Standard",
			hard: "Hard",
			difficultyHint: "Rated by local solver rounds and questions.",
			verifierCount: "Verifiers",
			verifierCountValue: "{{n}}",
			round: "Round {{n}}",
			totalQuestions: "{{n}} questions",
			questionQuota: "{{n}} / 3 this round",
			composePrompt: "Choose this round’s proposal",
			questionPrompt: "Choose a Verifier to question",
			deducePrompt: "Deduce, continue, or submit your answer",
			begin: "Begin testing",
			finishQuestions: "End questioning",
			nextRound: "Next round",
			submit: "Submit answer",
			submitTitle: "Final answer",
			submitWarning: "A wrong answer ends this attempt.",
			confirmSubmit: "Confirm answer",
			blue: "blue triangle",
			yellow: "yellow square",
			purple: "purple circle",
			chooseDigit: "Choose the {{color}} digit",
			selectVerifier: "Select Verifier {{letter}}",
			codeLocked: "Proposal locked for this round",
			recordsShort: "Records",
			notesShort: "Notes",
			conditionDetails: "Criterion details",
			countUnit: "",
			tripleShort: "All equal",
			pairShort: "One pair",
			distinctShort: "All different",
			noPairShort: "No pair",
			otherOrder: "Other",
			evenShort: "Even",
			oddShort: "Odd",
			verifiers: "Verifiers",
			cardsLabel: "Criteria cards",
			records: "Test records",
			notes: "Notes",
			verifier: "Verifier {{letter}}",
			inspectCard: "Inspect Criteria card {{n}}",
			askVerifier: "Question Verifier {{letter}}",
			passed: "Pass",
			failed: "Fail",
			notAsked: "Not questioned",
			hiddenPairing: "Unknown assignment",
			noRecords: "Your questions and answers will appear here.",
			proposal: "Proposal",
			numberNotes: "Eliminate digits",
			conditionNotes: "Eliminate criteria",
			notesPlaceholder: "Write your deductions…",
			saveNotes: "Save notes",
			excludeCondition: "Cross off: {{condition}}",
			restoreCondition: "Restore: {{condition}}",
			excludeDigit: "Cross off {{color}} digit {{n}}",
			restoreDigit: "Restore {{color}} digit {{n}}",
			conceded: "Attempt ended",
			solved: "Code solved",
			incorrect: "Incorrect answer",
			solution: "Correct code",
			yourAnswer: "Your answer",
			roundsUsed: "Rounds",
			questionsUsed: "Questions",
			reference: "Local reference score",
			referenceValue: "{{rounds}} rounds · {{questions}} questions",
			better: "You beat the reference score",
			equal: "You matched the reference score",
			slower: "Code found — try again with fewer questions",
			explanation: "Actual Verifier criteria",
			giveUp: "Give up",
			confirmGiveUp: "Confirm give up",
			errorAction: "You cannot do that now",
			errorLocked: "This round’s proposal is already locked",
			errorQuery: "Choose an unasked Verifier; at most three questions per round",
			errorNote: "Choose a visible criterion in this puzzle",
			hintCompose: "Try {{code}} as this round’s proposal",
			hintQuery: "Try questioning Verifier {{letter}}",
			hintFinish: "You can end questioning",
			hintNext: "You can start the next round",
			hintAnswer: "The recorded clues suggest submitting {{code}}",
			cards: {
				c1: "Blue compared to 1",
				c2: "Blue compared to 3",
				c3: "Yellow compared to 3",
				c4: "Yellow compared to 4",
				c5: "Blue parity",
				c6: "Yellow parity",
				c7: "Purple parity",
				c8: "Number of ones",
				c9: "Number of threes",
				c10: "Number of fours",
				c11: "Blue versus yellow",
				c12: "Blue versus purple",
				c13: "Yellow versus purple",
				c14: "Strictly smallest colour",
				c15: "Strictly largest colour",
				c16: "More even or odd digits",
				c17: "Number of even digits",
				c18: "Parity of the sum",
				c19: "Blue plus yellow versus 6",
				c20: "Repeated digits",
				c21: "Exactly one pair?",
				c22: "Ascending or descending",
				c23: "Total sum versus 6",
				c24: "Consecutive increasing digits",
				c25: "Consecutive increasing or decreasing digits",
				c26: "A colour below 3",
				c27: "A colour below 4",
				c28: "A colour equal to 1",
				c29: "A colour equal to 3",
				c30: "A colour equal to 4",
				c31: "A colour above 1",
				c32: "A colour above 3",
				c33: "Parity of a colour",
				c34: "Smallest, ties allowed",
				c35: "Largest, ties allowed",
				c36: "Sum is a multiple of 3, 4, or 5",
				c37: "Two colours sum to 4",
				c38: "Two colours sum to 6",
				c39: "A colour versus 1",
				c40: "A colour versus 3",
				c41: "A colour versus 4",
				c42: "A colour is strictly smallest or largest",
				c43: "Blue versus another colour",
				c44: "Yellow versus another colour",
				c45: "Number of ones or threes",
				c46: "Number of threes or fours",
				c47: "Number of ones or fours",
				c48: "Compare two colours"
			},
			criteria: {
				moreEven: "More even than odd digits",
				moreOdd: "More odd than even digits",
				evenSum: "The total sum is even",
				oddSum: "The total sum is odd",
				triple: "All three digits are equal",
				pair: "Exactly two digits are equal",
				distinct: "All three digits differ",
				noPair: "No exact pair of equal digits",
				unordered: "Neither strictly ascending nor descending",
				increasingThree: "Three consecutive increasing digits",
				increasingTwo: "Exactly one consecutive increasing pair",
				increasingNone: "No consecutive increasing pair",
				sequenceThree: "Three consecutive digits in one direction",
				sequenceTwo: "A consecutive pair, but no three-digit run",
				sequenceNone: "No consecutive adjacent digits"
			}
		}
	}
};
//#endregion
export { Ke as default };
