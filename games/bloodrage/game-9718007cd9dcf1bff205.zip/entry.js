import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { IconClose as c, IconExpand as l } from "@bgparty/sdk/icons";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { SheetView as h } from "@bgparty/sdk/sheet-view";
//#region src/games/bloodrage/data.ts
var g = [
	{
		id: "a1-0",
		age: 1,
		effect: "chosen1",
		minPlayers: 2,
		expansion: "mystics",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_chosen1",
		textKey: "games.bloodrage.text_chosen1"
	},
	{
		id: "a1-1",
		age: 1,
		effect: "thorGlory",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 2,
		nameKey: "games.bloodrage.card_thorGlory",
		textKey: "games.bloodrage.text_thorGlory"
	},
	{
		id: "a1-2",
		age: 1,
		effect: "brothers",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "warrior",
		strength: 1,
		nameKey: "games.bloodrage.card_brothers",
		textKey: "games.bloodrage.text_brothers"
	},
	{
		id: "a1-3",
		age: 1,
		effect: "sight",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_sight",
		textKey: "games.bloodrage.text_sight"
	},
	{
		id: "a1-4",
		age: 1,
		effect: "chosen1",
		minPlayers: 4,
		expansion: "mystics",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_chosen1",
		textKey: "games.bloodrage.text_chosen1"
	},
	{
		id: "a1-5",
		age: 1,
		effect: "dwarf",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 2,
		nameKey: "games.bloodrage.card_dwarf",
		textKey: "games.bloodrage.text_dwarf"
	},
	{
		id: "a1-6",
		age: 1,
		effect: "ship1",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "ship",
		strength: 2,
		nameKey: "games.bloodrage.card_ship1",
		textKey: "games.bloodrage.text_ship1"
	},
	{
		id: "a1-7",
		age: 1,
		effect: "leader1",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "leader",
		strength: 3,
		nameKey: "games.bloodrage.card_leader1",
		textKey: "games.bloodrage.text_leader1"
	},
	{
		id: "a1-8",
		age: 1,
		effect: "smash",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_smash",
		textKey: "games.bloodrage.text_smash"
	},
	{
		id: "a1-9",
		age: 1,
		effect: "hammer",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_hammer",
		textKey: "games.bloodrage.text_hammer"
	},
	{
		id: "a1-10",
		age: 1,
		effect: "troll",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 2,
		nameKey: "games.bloodrage.card_troll",
		textKey: "games.bloodrage.text_troll"
	},
	{
		id: "a1-11",
		age: 1,
		effect: "charm",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_charm",
		textKey: "games.bloodrage.text_charm"
	},
	{
		id: "a1-12",
		age: 1,
		effect: "smite",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 5,
		nameKey: "games.bloodrage.card_smite",
		textKey: "games.bloodrage.text_smite"
	},
	{
		id: "a1-13",
		age: 1,
		effect: "blessing",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 1,
		nameKey: "games.bloodrage.card_blessing",
		textKey: "games.bloodrage.text_blessing"
	},
	{
		id: "a1-14",
		age: 1,
		effect: "succor",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 2,
		nameKey: "games.bloodrage.card_succor",
		textKey: "games.bloodrage.text_succor"
	},
	{
		id: "a1-15",
		age: 1,
		effect: "smite",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 5,
		nameKey: "games.bloodrage.card_smite",
		textKey: "games.bloodrage.text_smite"
	},
	{
		id: "a1-16",
		age: 1,
		effect: "trickery",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_trickery",
		textKey: "games.bloodrage.text_trickery"
	},
	{
		id: "a1-17",
		age: 1,
		effect: "manheim",
		minPlayers: 4,
		expansion: "base",
		glory: 5,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_manheim",
		textKey: "games.bloodrage.text_manheim"
	},
	{
		id: "a1-18",
		age: 1,
		effect: "alfheim",
		minPlayers: 4,
		expansion: "base",
		glory: 5,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_alfheim",
		textKey: "games.bloodrage.text_alfheim"
	},
	{
		id: "a1-19",
		age: 1,
		effect: "widespread",
		minPlayers: 5,
		expansion: "base",
		glory: 7,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_widespread",
		textKey: "games.bloodrage.text_widespread"
	},
	{
		id: "a1-20",
		age: 1,
		effect: "brothers",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "warrior",
		strength: 1,
		nameKey: "games.bloodrage.card_brothers",
		textKey: "games.bloodrage.text_brothers"
	},
	{
		id: "a1-21",
		age: 1,
		effect: "yggdrasil",
		minPlayers: 3,
		expansion: "base",
		glory: 6,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_yggdrasil",
		textKey: "games.bloodrage.text_yggdrasil"
	},
	{
		id: "a1-22",
		age: 1,
		effect: "serpent",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 3,
		nameKey: "games.bloodrage.card_serpent",
		textKey: "games.bloodrage.text_serpent"
	},
	{
		id: "a1-23",
		age: 1,
		effect: "grace",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_grace",
		textKey: "games.bloodrage.text_grace"
	},
	{
		id: "a1-24",
		age: 1,
		effect: "smash",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_smash",
		textKey: "games.bloodrage.text_smash"
	},
	{
		id: "a1-25",
		age: 1,
		effect: "crush",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 4,
		nameKey: "games.bloodrage.card_crush",
		textKey: "games.bloodrage.text_crush"
	},
	{
		id: "a1-26",
		age: 1,
		effect: "hammer",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_hammer",
		textKey: "games.bloodrage.text_hammer"
	},
	{
		id: "a1-27",
		age: 1,
		effect: "jotunheim",
		minPlayers: 4,
		expansion: "base",
		glory: 5,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_jotunheim",
		textKey: "games.bloodrage.text_jotunheim"
	},
	{
		id: "a1-28",
		age: 1,
		effect: "death",
		minPlayers: 4,
		expansion: "base",
		glory: 6,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a1-29",
		age: 1,
		effect: "grace",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_grace",
		textKey: "games.bloodrage.text_grace"
	},
	{
		id: "a1-30",
		age: 1,
		effect: "death",
		minPlayers: 5,
		expansion: "base",
		glory: 6,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a1-31",
		age: 1,
		effect: "smash",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_smash",
		textKey: "games.bloodrage.text_smash"
	},
	{
		id: "a1-32",
		age: 1,
		effect: "leader1",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "leader",
		strength: 3,
		nameKey: "games.bloodrage.card_leader1",
		textKey: "games.bloodrage.text_leader1"
	},
	{
		id: "a1-33",
		age: 1,
		effect: "jotunheim",
		minPlayers: 2,
		expansion: "base",
		glory: 5,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_jotunheim",
		textKey: "games.bloodrage.text_jotunheim"
	},
	{
		id: "a1-34",
		age: 1,
		effect: "bash",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_bash",
		textKey: "games.bloodrage.text_bash"
	},
	{
		id: "a1-35",
		age: 1,
		effect: "alfheim",
		minPlayers: 2,
		expansion: "base",
		glory: 5,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_alfheim",
		textKey: "games.bloodrage.text_alfheim"
	},
	{
		id: "a1-36",
		age: 1,
		effect: "death",
		minPlayers: 2,
		expansion: "base",
		glory: 6,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a1-37",
		age: 1,
		effect: "odinSmite",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_odinSmite",
		textKey: "games.bloodrage.text_odinSmite"
	},
	{
		id: "a1-38",
		age: 1,
		effect: "manheim",
		minPlayers: 2,
		expansion: "base",
		glory: 5,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_manheim",
		textKey: "games.bloodrage.text_manheim"
	},
	{
		id: "a1-39",
		age: 1,
		effect: "tyrDomain",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_tyrDomain",
		textKey: "games.bloodrage.text_tyrDomain"
	},
	{
		id: "a1-40",
		age: 1,
		effect: "odinSmite",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_odinSmite",
		textKey: "games.bloodrage.text_odinSmite"
	},
	{
		id: "a1-41",
		age: 1,
		effect: "loki1",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 1,
		nameKey: "games.bloodrage.card_loki1",
		textKey: "games.bloodrage.text_loki1"
	},
	{
		id: "a1-42",
		age: 1,
		effect: "ship1",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "ship",
		strength: 2,
		nameKey: "games.bloodrage.card_ship1",
		textKey: "games.bloodrage.text_ship1"
	},
	{
		id: "a1-43",
		age: 1,
		effect: "trickery",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_trickery",
		textKey: "games.bloodrage.text_trickery"
	},
	{
		id: "a1-fifth",
		age: 1,
		effect: "dwarf",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 2,
		nameKey: "games.bloodrage.card_dwarf",
		textKey: "games.bloodrage.text_dwarf"
	},
	{
		id: "a2-0",
		age: 2,
		effect: "smash",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_smash",
		textKey: "games.bloodrage.text_smash"
	},
	{
		id: "a2-1",
		age: 2,
		effect: "smite",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 5,
		nameKey: "games.bloodrage.card_smite",
		textKey: "games.bloodrage.text_smite"
	},
	{
		id: "a2-2",
		age: 2,
		effect: "rage",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 6,
		nameKey: "games.bloodrage.card_rage",
		textKey: "games.bloodrage.text_rage"
	},
	{
		id: "a2-3",
		age: 2,
		effect: "thorDomain",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 1,
		nameKey: "games.bloodrage.card_thorDomain",
		textKey: "games.bloodrage.text_thorDomain"
	},
	{
		id: "a2-4",
		age: 2,
		effect: "backstab",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_backstab",
		textKey: "games.bloodrage.text_backstab"
	},
	{
		id: "a2-5",
		age: 2,
		effect: "crush",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 4,
		nameKey: "games.bloodrage.card_crush",
		textKey: "games.bloodrage.text_crush"
	},
	{
		id: "a2-6",
		age: 2,
		effect: "elf",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 1,
		nameKey: "games.bloodrage.card_elf",
		textKey: "games.bloodrage.text_elf"
	},
	{
		id: "a2-7",
		age: 2,
		effect: "valkyrie",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 2,
		nameKey: "games.bloodrage.card_valkyrie",
		textKey: "games.bloodrage.text_valkyrie"
	},
	{
		id: "a2-8",
		age: 2,
		effect: "eye",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_eye",
		textKey: "games.bloodrage.text_eye"
	},
	{
		id: "a2-9",
		age: 2,
		effect: "yggdrasil",
		minPlayers: 3,
		expansion: "base",
		glory: 8,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_yggdrasil",
		textKey: "games.bloodrage.text_yggdrasil"
	},
	{
		id: "a2-10",
		age: 2,
		effect: "chosen2",
		minPlayers: 2,
		expansion: "mystics",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_chosen2",
		textKey: "games.bloodrage.text_chosen2"
	},
	{
		id: "a2-11",
		age: 2,
		effect: "fire",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 4,
		nameKey: "games.bloodrage.card_fire",
		textKey: "games.bloodrage.text_fire"
	},
	{
		id: "a2-12",
		age: 2,
		effect: "widespread",
		minPlayers: 5,
		expansion: "base",
		glory: 10,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_widespread",
		textKey: "games.bloodrage.text_widespread"
	},
	{
		id: "a2-13",
		age: 2,
		effect: "leader2",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "leader",
		strength: 3,
		nameKey: "games.bloodrage.card_leader2",
		textKey: "games.bloodrage.text_leader2"
	},
	{
		id: "a2-14",
		age: 2,
		effect: "loki2",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 2,
		nameKey: "games.bloodrage.card_loki2",
		textKey: "games.bloodrage.text_loki2"
	},
	{
		id: "a2-15",
		age: 2,
		effect: "protection",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_protection",
		textKey: "games.bloodrage.text_protection"
	},
	{
		id: "a2-16",
		age: 2,
		effect: "death",
		minPlayers: 4,
		expansion: "base",
		glory: 8,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a2-17",
		age: 2,
		effect: "backstab",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_backstab",
		textKey: "games.bloodrage.text_backstab"
	},
	{
		id: "a2-18",
		age: 2,
		effect: "jotunheim",
		minPlayers: 4,
		expansion: "base",
		glory: 7,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_jotunheim",
		textKey: "games.bloodrage.text_jotunheim"
	},
	{
		id: "a2-19",
		age: 2,
		effect: "eye",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_eye",
		textKey: "games.bloodrage.text_eye"
	},
	{
		id: "a2-20",
		age: 2,
		effect: "tide",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_tide",
		textKey: "games.bloodrage.text_tide"
	},
	{
		id: "a2-21",
		age: 2,
		effect: "jotunheim",
		minPlayers: 2,
		expansion: "base",
		glory: 7,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_jotunheim",
		textKey: "games.bloodrage.text_jotunheim"
	},
	{
		id: "a2-22",
		age: 2,
		effect: "watch",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_watch",
		textKey: "games.bloodrage.text_watch"
	},
	{
		id: "a2-23",
		age: 2,
		effect: "experts",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "warrior",
		strength: 2,
		nameKey: "games.bloodrage.card_experts",
		textKey: "games.bloodrage.text_experts"
	},
	{
		id: "a2-24",
		age: 2,
		effect: "smash",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_smash",
		textKey: "games.bloodrage.text_smash"
	},
	{
		id: "a2-25",
		age: 2,
		effect: "death",
		minPlayers: 5,
		expansion: "base",
		glory: 8,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a2-26",
		age: 2,
		effect: "death",
		minPlayers: 2,
		expansion: "base",
		glory: 8,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a2-27",
		age: 2,
		effect: "chosen2",
		minPlayers: 4,
		expansion: "mystics",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_chosen2",
		textKey: "games.bloodrage.text_chosen2"
	},
	{
		id: "a2-28",
		age: 2,
		effect: "tide",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_tide",
		textKey: "games.bloodrage.text_tide"
	},
	{
		id: "a2-29",
		age: 2,
		effect: "manheim",
		minPlayers: 4,
		expansion: "base",
		glory: 7,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_manheim",
		textKey: "games.bloodrage.text_manheim"
	},
	{
		id: "a2-30",
		age: 2,
		effect: "manheim",
		minPlayers: 2,
		expansion: "base",
		glory: 7,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_manheim",
		textKey: "games.bloodrage.text_manheim"
	},
	{
		id: "a2-31",
		age: 2,
		effect: "experts",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "warrior",
		strength: 2,
		nameKey: "games.bloodrage.card_experts",
		textKey: "games.bloodrage.text_experts"
	},
	{
		id: "a2-32",
		age: 2,
		effect: "oath",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_oath",
		textKey: "games.bloodrage.text_oath"
	},
	{
		id: "a2-33",
		age: 2,
		effect: "leader2",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "leader",
		strength: 3,
		nameKey: "games.bloodrage.card_leader2",
		textKey: "games.bloodrage.text_leader2"
	},
	{
		id: "a2-34",
		age: 2,
		effect: "inspiration",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 2,
		nameKey: "games.bloodrage.card_inspiration",
		textKey: "games.bloodrage.text_inspiration"
	},
	{
		id: "a2-35",
		age: 2,
		effect: "eye",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_eye",
		textKey: "games.bloodrage.text_eye"
	},
	{
		id: "a2-36",
		age: 2,
		effect: "ship2",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "ship",
		strength: 2,
		nameKey: "games.bloodrage.card_ship2",
		textKey: "games.bloodrage.text_ship2"
	},
	{
		id: "a2-37",
		age: 2,
		effect: "prowess",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 2,
		nameKey: "games.bloodrage.card_prowess",
		textKey: "games.bloodrage.text_prowess"
	},
	{
		id: "a2-38",
		age: 2,
		effect: "oath",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_oath",
		textKey: "games.bloodrage.text_oath"
	},
	{
		id: "a2-39",
		age: 2,
		effect: "alfheim",
		minPlayers: 2,
		expansion: "base",
		glory: 7,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_alfheim",
		textKey: "games.bloodrage.text_alfheim"
	},
	{
		id: "a2-40",
		age: 2,
		effect: "challenge",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_challenge",
		textKey: "games.bloodrage.text_challenge"
	},
	{
		id: "a2-41",
		age: 2,
		effect: "eye",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_eye",
		textKey: "games.bloodrage.text_eye"
	},
	{
		id: "a2-42",
		age: 2,
		effect: "alfheim",
		minPlayers: 4,
		expansion: "base",
		glory: 7,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_alfheim",
		textKey: "games.bloodrage.text_alfheim"
	},
	{
		id: "a2-43",
		age: 2,
		effect: "ship2",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "ship",
		strength: 2,
		nameKey: "games.bloodrage.card_ship2",
		textKey: "games.bloodrage.text_ship2"
	},
	{
		id: "a2-fifth",
		age: 2,
		effect: "elf",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 1,
		nameKey: "games.bloodrage.card_elf",
		textKey: "games.bloodrage.text_elf"
	},
	{
		id: "a3-0",
		age: 3,
		effect: "leader3",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "leader",
		strength: 3,
		nameKey: "games.bloodrage.card_leader3",
		textKey: "games.bloodrage.text_leader3"
	},
	{
		id: "a3-1",
		age: 3,
		effect: "conquest",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 3,
		nameKey: "games.bloodrage.card_conquest",
		textKey: "games.bloodrage.text_conquest"
	},
	{
		id: "a3-2",
		age: 3,
		effect: "chosen3",
		minPlayers: 2,
		expansion: "mystics",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_chosen3",
		textKey: "games.bloodrage.text_chosen3"
	},
	{
		id: "a3-3",
		age: 3,
		effect: "watch",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_watch",
		textKey: "games.bloodrage.text_watch"
	},
	{
		id: "a3-4",
		age: 3,
		effect: "alfheim",
		minPlayers: 4,
		expansion: "base",
		glory: 9,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_alfheim",
		textKey: "games.bloodrage.text_alfheim"
	},
	{
		id: "a3-5",
		age: 3,
		effect: "hel",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 3,
		nameKey: "games.bloodrage.card_hel",
		textKey: "games.bloodrage.text_hel"
	},
	{
		id: "a3-6",
		age: 3,
		effect: "leader3",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "leader",
		strength: 3,
		nameKey: "games.bloodrage.card_leader3",
		textKey: "games.bloodrage.text_leader3"
	},
	{
		id: "a3-7",
		age: 3,
		effect: "gaze",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_gaze",
		textKey: "games.bloodrage.text_gaze"
	},
	{
		id: "a3-8",
		age: 3,
		effect: "primacy",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_primacy",
		textKey: "games.bloodrage.text_primacy"
	},
	{
		id: "a3-9",
		age: 3,
		effect: "manheim",
		minPlayers: 2,
		expansion: "base",
		glory: 9,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_manheim",
		textKey: "games.bloodrage.text_manheim"
	},
	{
		id: "a3-10",
		age: 3,
		effect: "tyrWrath",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 1,
		nameKey: "games.bloodrage.card_tyrWrath",
		textKey: "games.bloodrage.text_tyrWrath"
	},
	{
		id: "a3-11",
		age: 3,
		effect: "gaze",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_gaze",
		textKey: "games.bloodrage.text_gaze"
	},
	{
		id: "a3-12",
		age: 3,
		effect: "crush",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 4,
		nameKey: "games.bloodrage.card_crush",
		textKey: "games.bloodrage.text_crush"
	},
	{
		id: "a3-13",
		age: 3,
		effect: "witch",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 3,
		nameKey: "games.bloodrage.card_witch",
		textKey: "games.bloodrage.text_witch"
	},
	{
		id: "a3-14",
		age: 3,
		effect: "poison",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_poison",
		textKey: "games.bloodrage.text_poison"
	},
	{
		id: "a3-15",
		age: 3,
		effect: "loki3",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 3,
		nameKey: "games.bloodrage.card_loki3",
		textKey: "games.bloodrage.text_loki3"
	},
	{
		id: "a3-16",
		age: 3,
		effect: "jotunheim",
		minPlayers: 4,
		expansion: "base",
		glory: 9,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_jotunheim",
		textKey: "games.bloodrage.text_jotunheim"
	},
	{
		id: "a3-17",
		age: 3,
		effect: "masters",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "warrior",
		strength: 2,
		nameKey: "games.bloodrage.card_masters",
		textKey: "games.bloodrage.text_masters"
	},
	{
		id: "a3-18",
		age: 3,
		effect: "poison",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 0,
		nameKey: "games.bloodrage.card_poison",
		textKey: "games.bloodrage.text_poison"
	},
	{
		id: "a3-19",
		age: 3,
		effect: "manheim",
		minPlayers: 4,
		expansion: "base",
		glory: 9,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_manheim",
		textKey: "games.bloodrage.text_manheim"
	},
	{
		id: "a3-20",
		age: 3,
		effect: "death",
		minPlayers: 5,
		expansion: "base",
		glory: 11,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a3-21",
		age: 3,
		effect: "odinJudgement",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_odinJudgement",
		textKey: "games.bloodrage.text_odinJudgement"
	},
	{
		id: "a3-22",
		age: 3,
		effect: "widespread",
		minPlayers: 5,
		expansion: "base",
		glory: 15,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_widespread",
		textKey: "games.bloodrage.text_widespread"
	},
	{
		id: "a3-23",
		age: 3,
		effect: "crush",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 4,
		nameKey: "games.bloodrage.card_crush",
		textKey: "games.bloodrage.text_crush"
	},
	{
		id: "a3-24",
		age: 3,
		effect: "chosen3",
		minPlayers: 4,
		expansion: "mystics",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_chosen3",
		textKey: "games.bloodrage.text_chosen3"
	},
	{
		id: "a3-25",
		age: 3,
		effect: "ascension",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_ascension",
		textKey: "games.bloodrage.text_ascension"
	},
	{
		id: "a3-26",
		age: 3,
		effect: "smite",
		minPlayers: 4,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 5,
		nameKey: "games.bloodrage.card_smite",
		textKey: "games.bloodrage.text_smite"
	},
	{
		id: "a3-27",
		age: 3,
		effect: "masters",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "warrior",
		strength: 2,
		nameKey: "games.bloodrage.card_masters",
		textKey: "games.bloodrage.text_masters"
	},
	{
		id: "a3-28",
		age: 3,
		effect: "ship3",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "ship",
		strength: 2,
		nameKey: "games.bloodrage.card_ship3",
		textKey: "games.bloodrage.text_ship3"
	},
	{
		id: "a3-29",
		age: 3,
		effect: "death",
		minPlayers: 4,
		expansion: "base",
		glory: 11,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a3-30",
		age: 3,
		effect: "frost",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 4,
		nameKey: "games.bloodrage.card_frost",
		textKey: "games.bloodrage.text_frost"
	},
	{
		id: "a3-31",
		age: 3,
		effect: "primacy",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 3,
		nameKey: "games.bloodrage.card_primacy",
		textKey: "games.bloodrage.text_primacy"
	},
	{
		id: "a3-32",
		age: 3,
		effect: "alfheim",
		minPlayers: 2,
		expansion: "base",
		glory: 9,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_alfheim",
		textKey: "games.bloodrage.text_alfheim"
	},
	{
		id: "a3-33",
		age: 3,
		effect: "death",
		minPlayers: 2,
		expansion: "base",
		glory: 11,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_death",
		textKey: "games.bloodrage.text_death"
	},
	{
		id: "a3-34",
		age: 3,
		effect: "ascension",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 1,
		nameKey: "games.bloodrage.card_ascension",
		textKey: "games.bloodrage.text_ascension"
	},
	{
		id: "a3-35",
		age: 3,
		effect: "odinJudgement",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 2,
		nameKey: "games.bloodrage.card_odinJudgement",
		textKey: "games.bloodrage.text_odinJudgement"
	},
	{
		id: "a3-36",
		age: 3,
		effect: "yggdrasil",
		minPlayers: 3,
		expansion: "base",
		glory: 10,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_yggdrasil",
		textKey: "games.bloodrage.text_yggdrasil"
	},
	{
		id: "a3-37",
		age: 3,
		effect: "jotunheim",
		minPlayers: 2,
		expansion: "base",
		glory: 9,
		kind: "quest",
		strength: 0,
		nameKey: "games.bloodrage.card_jotunheim",
		textKey: "games.bloodrage.text_jotunheim"
	},
	{
		id: "a3-38",
		age: 3,
		effect: "throne",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 2,
		nameKey: "games.bloodrage.card_throne",
		textKey: "games.bloodrage.text_throne"
	},
	{
		id: "a3-39",
		age: 3,
		effect: "ship3",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "ship",
		strength: 2,
		nameKey: "games.bloodrage.card_ship3",
		textKey: "games.bloodrage.text_ship3"
	},
	{
		id: "a3-40",
		age: 3,
		effect: "rage",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 6,
		nameKey: "games.bloodrage.card_rage",
		textKey: "games.bloodrage.text_rage"
	},
	{
		id: "a3-41",
		age: 3,
		effect: "sacrifice",
		minPlayers: 3,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 1,
		nameKey: "games.bloodrage.card_sacrifice",
		textKey: "games.bloodrage.text_sacrifice"
	},
	{
		id: "a3-42",
		age: 3,
		effect: "friggaDomain",
		minPlayers: 2,
		expansion: "base",
		glory: 0,
		kind: "clan",
		strength: 0,
		nameKey: "games.bloodrage.card_friggaDomain",
		textKey: "games.bloodrage.text_friggaDomain"
	},
	{
		id: "a3-43",
		age: 3,
		effect: "judgement",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "battle",
		strength: 6,
		nameKey: "games.bloodrage.card_judgement",
		textKey: "games.bloodrage.text_judgement"
	},
	{
		id: "a3-fifth",
		age: 3,
		effect: "hel",
		minPlayers: 5,
		expansion: "base",
		glory: 0,
		kind: "monster",
		strength: 3,
		nameKey: "games.bloodrage.card_hel",
		textKey: "games.bloodrage.text_hel"
	},
	{
		id: "a1-fenrir",
		age: 1,
		effect: "fenrir",
		minPlayers: 2,
		expansion: "monsters",
		glory: 0,
		kind: "monster",
		strength: 2,
		nameKey: "games.bloodrage.card_fenrir",
		textKey: "games.bloodrage.text_fenrir"
	},
	{
		id: "a1-mountain",
		age: 1,
		effect: "mountain",
		minPlayers: 2,
		expansion: "monsters",
		glory: 0,
		kind: "monster",
		strength: 3,
		nameKey: "games.bloodrage.card_mountain",
		textKey: "games.bloodrage.text_mountain"
	},
	{
		id: "a1-hildi",
		age: 1,
		effect: "hildi",
		minPlayers: 2,
		expansion: "monsters",
		glory: 0,
		kind: "monster",
		strength: 1,
		nameKey: "games.bloodrage.card_hildi",
		textKey: "games.bloodrage.text_hildi"
	},
	{
		id: "a2-wolfman",
		age: 2,
		effect: "wolfman",
		minPlayers: 2,
		expansion: "monsters",
		glory: 0,
		kind: "monster",
		strength: 3,
		nameKey: "games.bloodrage.card_wolfman",
		textKey: "games.bloodrage.text_wolfman"
	},
	{
		id: "a2-nidhogg",
		age: 2,
		effect: "nidhogg",
		minPlayers: 2,
		expansion: "monsters",
		glory: 0,
		kind: "monster",
		strength: 2,
		nameKey: "games.bloodrage.card_nidhogg",
		textKey: "games.bloodrage.text_nidhogg"
	},
	{
		id: "a3-mysticTroll",
		age: 3,
		effect: "mysticTroll",
		minPlayers: 2,
		expansion: "monsters",
		glory: 0,
		kind: "monster",
		strength: 2,
		nameKey: "games.bloodrage.card_mysticTroll",
		textKey: "games.bloodrage.text_mysticTroll"
	},
	{
		id: "a3-ymir",
		age: 3,
		effect: "ymir",
		minPlayers: 2,
		expansion: "monsters",
		glory: 0,
		kind: "monster",
		strength: 0,
		nameKey: "games.bloodrage.card_ymir",
		textKey: "games.bloodrage.text_ymir"
	}
], _ = Object.fromEntries(g.map((e) => [e.id, e])), v = [
	[
		6,
		7,
		8,
		9,
		12,
		12
	],
	[
		3,
		4,
		5,
		6,
		8,
		8
	],
	[
		4,
		5,
		6,
		7,
		10,
		10
	]
], y = [
	{
		id: "p0",
		key: "games.bloodrage.p0",
		region: "manheim",
		capacity: 3,
		fjord: 0,
		adjacent: ["p1", "p8"]
	},
	{
		id: "p1",
		key: "games.bloodrage.p1",
		region: "manheim",
		capacity: 4,
		fjord: 1,
		adjacent: ["p0", "p8"]
	},
	{
		id: "p2",
		key: "games.bloodrage.p2",
		region: "manheim",
		capacity: 5,
		fjord: 1,
		adjacent: ["p3", "p8"]
	},
	{
		id: "p3",
		key: "games.bloodrage.p3",
		region: "jotunheim",
		capacity: 5,
		fjord: 2,
		adjacent: ["p2", "p8"]
	},
	{
		id: "p4",
		key: "games.bloodrage.p4",
		region: "jotunheim",
		capacity: 4,
		fjord: 2,
		adjacent: ["p5", "p8"]
	},
	{
		id: "p5",
		key: "games.bloodrage.p5",
		region: "jotunheim",
		capacity: 3,
		fjord: 3,
		adjacent: ["p4", "p8"]
	},
	{
		id: "p6",
		key: "games.bloodrage.p6",
		region: "alfheim",
		capacity: 3,
		fjord: 3,
		adjacent: ["p7", "p8"]
	},
	{
		id: "p7",
		key: "games.bloodrage.p7",
		region: "alfheim",
		capacity: 5,
		fjord: 0,
		adjacent: ["p6", "p8"]
	},
	{
		id: "p8",
		key: "games.bloodrage.p8",
		region: "yggdrasil",
		capacity: 100,
		fjord: -1,
		adjacent: [
			"p0",
			"p1",
			"p2",
			"p3",
			"p4",
			"p5",
			"p6",
			"p7"
		]
	}
], ee = [
	"thor",
	"frigga",
	"tyr",
	"odin",
	"loki",
	"heimdall"
], b = {
	id: "bloodrage",
	tier: "alpha",
	nameKey: "games.bloodrage.name",
	descKey: "games.bloodrage.desc",
	rulesKey: "games.bloodrage.rules",
	icon: "🪓",
	iconImg: "games/bloodrage.webp",
	rulesUrl: { en: "https://cdn.1j1ju.com/medias/88/21/c2-blood-rage-rulebook.pdf" },
	mechanics: [
		"drafting",
		"area-control",
		"hand-management",
		"action-points"
	],
	interactionTags: [],
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4],
	playerRange: (e) => ({
		min: 2,
		max: e?.fifthPlayer ? 5 : 4
	}),
	accent: "#a92526",
	releasedAt: "2026-11-05T00:25:00+08:00",
	search: {
		py: "xue se kuang nu blood rage",
		init: "xskn"
	},
	hotseat: "cover",
	botDelayMs: 550
}, x = t.object({
	fifthPlayer: t.boolean().default(!1),
	mystics: t.boolean().default(!1),
	gods: t.boolean().default(!1),
	monsters: t.boolean().default(!1)
}).default({
	fifthPlayer: !1,
	mystics: !1,
	gods: !1,
	monsters: !1
}), S = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draft"),
		cards: t.array(t.string()).min(1).max(2)
	}),
	t.object({
		type: t.literal("invade"),
		unit: t.string(),
		to: t.string(),
		fromValhalla: t.boolean().optional(),
		replace: t.string().optional(),
		pushTo: t.string().optional()
	}),
	t.object({
		type: t.literal("march"),
		units: t.array(t.string()).min(1).max(14),
		to: t.string()
	}),
	t.object({
		type: t.literal("upgrade"),
		card: t.string(),
		slot: t.string()
	}),
	t.object({
		type: t.literal("quest"),
		card: t.string()
	}),
	t.object({
		type: t.literal("pillage"),
		province: t.string()
	}),
	t.object({
		type: t.literal("sacrifice"),
		units: t.array(t.string()).length(2)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("choose"),
		id: t.string()
	}),
	t.object({
		type: t.literal("reinforce"),
		unit: t.string().nullable()
	}),
	t.object({
		type: t.literal("battle"),
		card: t.string().nullable()
	}),
	t.object({
		type: t.literal("extra"),
		card: t.string().nullable()
	}),
	t.object({
		type: t.literal("discard"),
		keep: t.string().nullable()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), C = t.object({
	id: t.string(),
	owner: t.string(),
	kind: t.enum([
		"warrior",
		"leader",
		"ship",
		"mystic",
		"monster"
	]),
	location: t.string(),
	card: t.string().nullable()
}), te = t.object({
	rid: t.string(),
	rage: t.number(),
	stats: t.array(t.number()).length(3),
	glory: t.number(),
	upgrades: t.record(t.string(), t.string()),
	handCount: t.number(),
	questCount: t.number(),
	mystics: t.number(),
	ready: t.boolean(),
	finalStats: t.number(),
	finalConquest: t.number()
}), w = t.object({
	id: t.string(),
	card: t.string().optional(),
	unit: t.string().optional(),
	to: t.string().optional(),
	stat: t.number().optional(),
	n: t.number().optional(),
	skip: t.boolean().optional(),
	label: t.string().optional()
}), ne = t.enum([
	"draft",
	"action",
	"reinforce",
	"battle",
	"extra",
	"decision",
	"settle",
	"discard",
	"quests",
	"ragnarok",
	"release",
	"done"
]), re = t.object({
	phase: ne,
	age: t.number(),
	turn: t.string(),
	players: t.array(te),
	figures: t.array(C),
	config: x,
	destroyed: t.array(t.string()),
	pillaged: t.array(t.string()),
	rewards: t.array(t.string()),
	doom: t.array(t.string()),
	gods: t.array(t.object({
		kind: t.string(),
		province: t.string()
	})),
	battle: t.object({
		province: t.string(),
		pillager: t.string(),
		participants: t.array(t.string()),
		cards: t.record(t.string(), t.array(t.string())),
		strengths: t.record(t.string(), t.number()),
		winner: t.string().nullable(),
		revealed: t.boolean(),
		picked: t.array(t.string()),
		questBoost: t.record(t.string(), t.number())
	}).nullable(),
	prompt: t.object({
		rid: t.string(),
		kind: t.string()
	}).nullable(),
	event: t.object({
		seq: t.number(),
		kind: t.string(),
		rid: t.string(),
		units: t.array(t.string()),
		card: t.string().nullable(),
		from: t.string(),
		to: t.string(),
		amount: t.number()
	}),
	questResults: t.array(t.object({
		rid: t.string(),
		card: t.string(),
		success: t.boolean(),
		glory: t.number()
	})),
	log: t.array(t.object({
		kind: t.string(),
		rid: t.string(),
		card: t.string().nullable(),
		location: t.string(),
		amount: t.number()
	}))
}), ie = t.object({
	hand: t.array(t.string()),
	draft: t.array(t.string()),
	quests: t.array(t.string()),
	selected: t.array(t.string()),
	actions: t.array(S),
	choices: t.array(w)
}), T = { code: "games.bloodrage.errAction" }, E = {
	id: "skip",
	skip: !0,
	tasks: []
}, D = (e) => y.find((t) => t.id === e), O = (e) => e.location.startsWith("p") || e.location.startsWith("f"), k = (e, t) => e.figures.find((e) => e.id === t), A = (e, t, n) => Object.values(e.clans[t].upgrades).filter((e) => _[e].effect === n).length, j = (e, t, n) => v[n][e.clans[t].stats[n]], M = (e) => e.kind === "ship" || e.card !== null && _[e.card].effect === "serpent", N = (e) => e.kind === "leader" || e.card !== null && _[e.card].effect === "mountain", P = (e, t, n) => e.gods.some((e) => e.kind === t && e.province === n), F = (e, t, n) => t.location === n || D(n) && D(n).fjord >= 0 && t.location === `f${D(n).fjord}`, I = (e, t, n) => e.figures.filter((r) => F(e, r, t) && (!n || r.owner === n)), L = (e, t) => t.startsWith("f") ? 100 : (D(t)?.capacity ?? 0) - e.figures.filter((e) => e.location === t).length, ae = (e, t) => [...e.players.slice(e.players.indexOf(t)), ...e.players.slice(0, e.players.indexOf(t))], R = (t, n) => {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rngCursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
};
function z(e, t, n, r, i, a = !1, o = !1) {
	if (!n.length || !e.frameFx) return;
	let s = {
		from: r,
		to: i,
		count: n.length,
		faceDown: o
	};
	e.frameFx.push(a ? {
		kind: "brCards",
		rid: t,
		data: s,
		for: [t],
		secret: { cards: n }
	} : {
		kind: "brCards",
		rid: t,
		data: {
			...s,
			cards: n
		}
	});
}
function B(e) {
	let t = (e.frameFx ?? []).map((e, t) => t ? {
		...e,
		with: !0
	} : e);
	return delete e.frameFx, {
		state: e,
		fx: t
	};
}
function V(e, t, n = "", r = [], i = "", a = "", o = 0, s = null) {
	r.length && e.frameFx && e.frameFx.push({
		kind: "brUnits",
		rid: n,
		data: {
			from: i,
			to: a,
			units: r.map((t) => ({ ...k(e, t) }))
		}
	}), [
		"ragnarok",
		"pillage",
		"battle",
		"questSuccess",
		"questFail"
	].includes(t) && e.frameFx?.push({
		kind: "brPulse",
		rid: n,
		data: {
			location: a || i,
			kind: t
		}
	}), e.event = {
		seq: e.event.seq + 1,
		kind: t,
		rid: n,
		units: r,
		from: i,
		to: a,
		amount: o,
		card: s
	}, [
		"invade",
		"march",
		"pillage",
		"battle",
		"destroy",
		"ragnarok",
		"questSuccess",
		"questFail",
		"age",
		"upgrade",
		"release",
		"final"
	].includes(t) && e.log.push({
		kind: t,
		rid: n,
		card: s,
		location: a || i,
		amount: o
	});
}
function H(e, t, n = !1) {
	e.tasks = n ? [...t, ...e.tasks] : [...e.tasks, ...t], e.phase = "settle";
}
function U(e, t, n, r) {
	r.length !== 0 && (e.decision = {
		rid: t,
		kind: n,
		choices: r
	}, e.phase = "decision", e.turn = t);
}
function W(e, t, n, r = 1) {
	e.clans[t].stats[n] = Math.min(5, e.clans[t].stats[n] + r);
}
function oe(e, t, n = []) {
	U(e, t, "stat", [
		0,
		1,
		2
	].filter((e) => !n.includes(e)).map((e) => ({
		id: `stat${e}`,
		stat: e,
		tasks: [{
			kind: "raise",
			rid: t,
			stat: e
		}]
	})));
}
function G(e, t, n = t.location) {
	if (t.kind === "warrior") return A(e, t.owner, "experts") ? 2 : 1;
	if (t.kind === "leader") return 3;
	if (t.kind === "ship" || t.kind === "mystic") return 2;
	if (!t.card) return 0;
	let r = _[t.card];
	return r.effect === "ymir" ? e.figures.filter((e) => e.owner === t.owner && e.location === "valhalla").length * 2 : r.effect === "elf" && n === "p8" ? 3 : r.strength;
}
function se(e, t, n, r = !1) {
	let i = I(e, n, t);
	if (r && P(e, "tyr", n)) return 0;
	let a = r && I(e, n).some((e) => e.card && _[e.card].effect === "wolfman") ? i.filter((e) => e.kind === "monster") : i, o = a.reduce((t, r) => t + G(e, r, n), 0), s = a.filter((e) => e.kind === "warrior").length, c = e.clans[t].upgrades.warrior;
	return c && ["brothers", "masters"].includes(_[c].effect) && (o += Math.floor(s / 2) * (_[c].effect === "masters" ? 4 : 1)), o;
}
function ce(e, t, n, r = !1) {
	return r ? 1 : N(t) || t.kind === "mystic" || t.card && [
		"dwarf",
		"hel",
		"ymir"
	].includes(_[t.card].effect) || e.figures.some((e) => e.owner === t.owner && e.location === n && e.card && _[e.card].effect === "mysticTroll") ? 0 : G(e, t, n);
}
function le(e, t, n, r = !1, i = !1, a = !1) {
	if (e.figures.filter((e) => e.owner === t && O(e)).length >= j(e, t, 2) || n.location !== (a ? "valhalla" : "reserve")) return [];
	let o = M(n) ? [
		"f0",
		"f1",
		"f2",
		"f3"
	] : y.filter((e) => e.id !== "p8" || i || n.card && _[n.card].effect === "elf").map((e) => e.id), s = [];
	for (let i of o) if (!(e.destroyed.includes(i) || !r && e.clans[t].rage < ce(e, n, i, a))) {
		if (L(e, i) > 0 && s.push({
			type: "invade",
			unit: n.id,
			to: i,
			...a ? { fromValhalla: !0 } : {}
		}), n.card && _[n.card].effect === "hildi") for (let t of e.figures.filter((e) => e.location === i && !M(e))) for (let r of D(i)?.adjacent ?? []) !e.destroyed.includes(r) && L(e, r) > 0 && s.push({
			type: "invade",
			unit: n.id,
			to: i,
			replace: t.id,
			pushTo: r,
			...a ? { fromValhalla: !0 } : {}
		});
		if (n.kind === "mystic" && A(e, t, "chosen2")) for (let t of e.figures.filter((e) => e.location === i && ["warrior", "mystic"].includes(e.kind))) s.push({
			type: "invade",
			unit: n.id,
			to: i,
			replace: t.id,
			...a ? { fromValhalla: !0 } : {}
		});
	}
	return s;
}
function ue(e, t, n, r, i = !1, a) {
	U(e, t, r, [...n.flatMap((n) => le(e, t, n, !0, i)).filter((e) => e.type === "invade" && (!a || e.to === a)).map((e, n) => ({
		id: `invade${n}`,
		unit: e.type === "invade" ? e.unit : "",
		to: e.type === "invade" ? e.to : "",
		tasks: [{
			kind: "invasion",
			rid: t,
			action: e,
			amount: 0
		}]
	})), E]);
}
function de(e, t, n) {
	let r = t.location;
	if (!O(t)) return;
	t.location = "valhalla", e.battle && n === "battle" && e.battle.dead.push(t.id);
	let i = e.clans[t.owner].upgrades.ship;
	M(t) && i && (e.clans[t.owner].glory += {
		ship1: 4,
		ship2: 8,
		ship3: 12
	}[_[i].effect] ?? 0), n === "ragnarok" && (e.clans[t.owner].glory += (e.age + 1) * 2 ** A(e, t.owner, "inspiration")), V(e, "destroy", t.owner, [t.id], r, "valhalla");
}
function fe(e, t, n) {
	let r = k(e, t);
	if (!r || !O(r) || n === "battle" && e.battle && P(e, "frigga", e.battle.province)) return;
	let i = [{
		id: "destroy",
		unit: t,
		label: "destroy",
		tasks: [{
			kind: "killNow",
			unit: t,
			reason: n
		}]
	}];
	if (n !== "sacrifice") {
		A(e, r.owner, "protection") && e.clans[r.owner].rage >= 1 && i.push({
			id: "protect",
			unit: t,
			label: "protect",
			tasks: [{
				kind: "pay",
				rid: r.owner,
				amount: 1
			}]
		});
		let n = [];
		r.kind === "mystic" && A(e, r.owner, "chosen1") && (n = [...D(r.location)?.adjacent ?? []].filter((e) => e !== "p8")), r.card && _[r.card].effect === "witch" && r.location !== "p8" && (n = ["p8"]);
		for (let r of n.filter((t) => !e.destroyed.includes(t) && L(e, t) > 0)) i.push({
			id: `retreat${r}`,
			unit: t,
			to: r,
			label: "retreat",
			tasks: [{
				kind: "move",
				unit: t,
				to: r
			}]
		});
	}
	i.length > 1 ? U(e, r.owner, "death", i) : de(e, r, n);
}
function pe(e, t, n, r) {
	let i = k(e, n.unit);
	if (e.clans[t].rage -= r, n.replace) {
		let r = k(e, n.replace);
		if (n.pushTo) {
			let t = r.location;
			r.location = n.pushTo, V(e, "march", r.owner, [r.id], t, n.pushTo);
		} else {
			H(e, [{
				kind: "kill",
				unit: r.id,
				reason: "invasion"
			}, {
				kind: "occupy",
				rid: t,
				action: {
					...n,
					replace: void 0
				},
				amount: 0
			}], !0);
			return;
		}
	}
	let a = i.location;
	i.location = n.to, a === "valhalla" && (e.clans[t].glory += A(e, t, "loki1") + 2 * A(e, t, "loki2") + 3 * A(e, t, "loki3")), V(e, "invade", t, [i.id], a, n.to);
	let o = i.card ? _[i.card].effect : "", s = e.figures.filter((e) => e.owner !== t && e.location === n.to && (o === "troll" ? e.kind === "warrior" : o === "fire" && e.kind !== "monster")).map((e) => ({
		kind: "kill",
		unit: e.id,
		reason: "invasion"
	}));
	A(e, t, "succor") && s.push({
		kind: "succor",
		rid: t,
		to: n.to,
		amount: A(e, t, "succor")
	}), A(e, t, "thorDomain") && !M(i) && s.push({
		kind: "domainPillage",
		rid: t,
		to: n.to
	}), H(e, s, !0);
}
function me(e) {
	let t = R(e, g.filter((t) => t.age === e.age && t.minPlayers <= e.players.length && (t.expansion === "base" || (t.expansion === "mystics" ? e.config.mystics : e.config.monsters))).map((e) => e.id));
	e.draft = Object.fromEntries(e.players.map((e, n) => [e, t.slice(n * 8, n * 8 + 8)])), e.draftPicked = {}, e.draftCount = 0, e.ready = [], e.phase = "draft", e.turn = e.players[e.first];
	for (let t of e.players) z(e, t, e.draft[t], "deck", "draft", !0);
	V(e, "age", "", [], "", "", e.age);
}
function he(e) {
	let t = R(e, y.filter((t) => t.id !== "p8" && !e.destroyed.includes(t.id) && !e.doom.slice(e.age - 1).includes(t.id)).map((e) => e.id));
	e.gods.forEach((e, n) => {
		e.province = t[n];
	});
}
function ge(e, t, n) {
	let r = {
		players: t,
		config: x.parse(e),
		seed: n,
		rngCursor: 0,
		clans: {},
		figures: [],
		phase: "draft",
		age: 1,
		turn: t[0],
		actionPlayer: t[0],
		first: 0,
		destroyed: [],
		pillaged: [],
		rewards: [],
		doom: [],
		gods: [],
		draft: {},
		draftPicked: {},
		draftCount: 0,
		discarded: [],
		ready: [],
		battle: null,
		tasks: [],
		decision: null,
		event: {
			seq: 0,
			kind: "setup",
			rid: "",
			units: [],
			card: null,
			from: "",
			to: "",
			amount: 0
		},
		questResults: [],
		log: []
	};
	for (let e of t) {
		r.clans[e] = {
			rage: 6,
			stats: [
				0,
				0,
				0
			],
			glory: 0,
			upgrades: {},
			hand: [],
			quests: [],
			mystics: 0,
			finalStats: 0,
			finalConquest: 0
		};
		for (let t = 0; t < 8; t++) r.figures.push({
			id: `${e}:w${t}`,
			owner: e,
			kind: "warrior",
			location: "reserve",
			card: null
		});
		for (let t of ["leader", "ship"]) r.figures.push({
			id: `${e}:${t}`,
			owner: e,
			kind: t,
			location: "reserve",
			card: null
		});
	}
	let i = R(r, y.slice(0, 8).map((e) => e.id));
	return r.doom = i.slice(0, 3), r.destroyed = i.slice(3, 8 - t.length), r.rewards = [...R(r, [
		"rage",
		"rage",
		"rage",
		"axes",
		"axes",
		"horns",
		"horns",
		"glory"
	]), "all"], r.config.gods && (r.gods = R(r, ee).slice(0, 2).map((e) => ({
		kind: e,
		province: ""
	})), he(r)), me(r), { state: r };
}
function _e(e) {
	if (e.phase = "discard", e.battle = null, e.ready = e.players.filter((t) => e.age === 3 || e.clans[t].hand.length <= 1), e.age === 3) for (let t of e.players) z(e, t, e.clans[t].hand, "hand", "deck", !0), e.discarded.push(...e.clans[t].hand), e.clans[t].hand = [];
	e.ready.length === e.players.length && je(e);
}
function ve(e) {
	if (e.battle = null, e.players.every((t) => e.clans[t].rage === 0) || y.every((t) => e.destroyed.includes(t.id) || e.pillaged.includes(t.id))) {
		_e(e);
		return;
	}
	let t = e.players.indexOf(e.actionPlayer);
	for (let n = 1; n <= e.players.length; n++) {
		let r = e.players[(t + n) % e.players.length];
		if (e.clans[r].rage > 0) {
			e.turn = r, e.actionPlayer = r, e.phase = "action";
			return;
		}
	}
}
function ye(e, t, n) {
	e.battle = {
		province: n,
		pillager: t,
		participants: [],
		cards: {},
		selected: {},
		strengths: {},
		winner: null,
		revealed: !1,
		cursor: (e.players.indexOf(t) + 1) % e.players.length,
		passes: 0,
		initial: [],
		dead: [],
		canceled: [],
		questBoost: {}
	}, e.phase = "reinforce", e.turn = e.players[e.battle.cursor], L(e, n) <= 0 && H(e, [{ kind: "startCards" }], !0);
}
function be(e) {
	let t = e.battle;
	if (t.participants = ae(e, t.pillager).filter((n) => I(e, t.province, n).length > 0), t.initial = I(e, t.province).map((e) => e.id), t.participants.length <= 1) {
		t.winner = t.pillager, H(e, [
			{
				kind: "reward",
				rid: t.pillager
			},
			{ kind: "moveGod" },
			{ kind: "closeBattle" }
		], !0);
		return;
	}
	t.selected = Object.fromEntries(t.participants.filter((t) => e.clans[t].hand.length === 0).map((e) => [e, null])), t.cards = {}, t.revealed = !1, e.phase = "battle", xe(e), Object.keys(t.selected).length === t.participants.length && H(e, [{ kind: "reveal" }], !0);
}
function xe(e) {
	let t = e.battle;
	e.turn = [...t.participants.filter((e) => e !== t.pillager), t.pillager].find((e) => !(e in t.selected)) ?? t.pillager;
}
function Se(e, t) {
	return e.battle.canceled.includes(t);
}
function K(e, t) {
	return (e.battle.cards[t] ?? []).map((e) => _[e]);
}
function Ce(e, t, n) {
	let r = _[n];
	return r.kind === "battle" ? r.strength : r.kind === "quest" ? e.battle.questBoost[t] ?? 0 : 0;
}
function we(e, t) {
	let n = e.battle;
	return (n.cards[t] ?? []).reduce((r, i) => _[i].effect !== "sight" || Se(e, t) ? r + Ce(e, t, i) : r + Math.max(0, ...n.participants.filter((e) => e !== t).flatMap((t) => (n.cards[t] ?? []).map((n) => Ce(e, t, n)))), 0);
}
function Te(e, t, n) {
	return !(_[n].effect === "backstab" && A(e, t, "chosen1") && e.battle.initial.some((n) => {
		let r = k(e, n);
		return r.owner === t && r.kind === "mystic";
	}));
}
function Ee(e) {
	let t = e.battle;
	for (let n of t.participants) {
		let r = t.selected[n];
		t.cards[n] = r ? [r] : [], r && (e.clans[n].hand = e.clans[n].hand.filter((e) => e !== r));
	}
	if (!P(e, "heimdall", t.province)) for (let n of t.participants) e.frameFx?.push({
		kind: "brReveal",
		rid: n,
		data: { cards: t.cards[n] }
	});
	t.revealed = !0;
	let n = t.participants.filter((t) => K(e, t).some((e) => e.effect === "primacy"));
	t.canceled = t.participants.filter((e) => n.some((t) => t !== e)), V(e, "reveal", t.pillager, [], "", t.province), H(e, [...t.participants.map((e) => ({
		kind: "questBattle",
		rid: e
	})), { kind: "watch" }], !0);
}
function De(e) {
	let t = e.battle;
	t.cursor = 0, t.passes = 0, e.phase = "extra", e.turn = t.participants[0];
}
function Oe(e) {
	let t = e.battle, n = [];
	for (let r of t.participants) if (!Se(e, r)) for (let i of K(e, r)) {
		if (i.effect === "odinSmite") for (let e of t.participants.filter((e) => e !== r)) n.push({
			kind: "smite",
			rid: e
		});
		if (i.effect === "tide") for (let e of t.participants) n.push({
			kind: "tide",
			rid: e
		});
	}
	H(e, [...n, { kind: "winner" }], !0);
}
function ke(e, t) {
	let n = e.battle, r = n.province, i = e.rewards[Number(r.slice(1))];
	e.pillaged.includes(r) || e.pillaged.push(r);
	let a = (1 + I(e, r, t).filter((e) => e.card && _[e.card].effect === "frost").length) * (P(e, "odin", r) ? 2 : 1);
	for (let n = 0; n < a; n++) if (i === "all") for (let n = 0; n < 3; n++) W(e, t, n);
	else i === "glory" ? e.clans[t].glory += 5 : W(e, t, [
		"rage",
		"axes",
		"horns"
	].indexOf(i));
	let o = [];
	if (I(e, r, t).some(N)) {
		let n = e.clans[t].upgrades.leader;
		if (n) {
			let i = _[n].effect;
			if (i === "leader1") for (let n of I(e, r, t).filter(N)) o.push({
				kind: "leaderMove",
				rid: t,
				unit: n.id
			});
			if (i === "leader2" && o.push({
				kind: "stat",
				rid: t
			}), i === "leader3") for (let n = 0; n < 3; n++) W(e, t, n);
		}
	}
	if (n.participants.length > 1 && !Se(e, t)) for (let n of K(e, t)) n.effect === "grace" && o.push({
		kind: "stat",
		rid: t,
		excluded: [
			"rage",
			"axes",
			"horns"
		].includes(i) ? [[
			"rage",
			"axes",
			"horns"
		].indexOf(i)] : []
	});
	V(e, "pillage", t, [], "", r, a), H(e, o, !0);
}
function Ae(e, t, n) {
	let r = _[n].effect;
	if (r === "death") return e.figures.filter((e) => e.owner === t && e.location === "valhalla").length >= 4;
	let i = y.filter((n) => !e.destroyed.includes(n.id) && se(e, t, n.id) > Math.max(0, ...e.players.filter((e) => e !== t).map((t) => se(e, t, n.id))));
	return r === "widespread" ? i.length >= 2 : i.some((e) => e.region === r);
}
function je(e) {
	H(e, [...e.players.flatMap((t) => e.clans[t].quests.map((e) => ({
		kind: "quest",
		rid: t,
		card: e
	}))), { kind: "ragnarok" }]), e.phase = "settle";
}
function Me(e, t) {
	let n = t.rid ?? "", r = t.unit ? k(e, t.unit) : void 0, i = e.battle;
	switch (t.kind) {
		case "finishTurn":
			ve(e);
			break;
		case "raise":
			W(e, n, t.stat), V(e, "stat", n, [], "", "", t.stat);
			break;
		case "stat":
			oe(e, n, t.excluded);
			break;
		case "pay":
			e.clans[n].rage -= t.amount;
			break;
		case "move":
			if (r) {
				let n = r.location;
				r.location = t.to, V(e, "march", r.owner, [r.id], n, t.to);
			}
			break;
		case "kill":
			fe(e, t.unit, t.reason);
			break;
		case "killNow":
			r && de(e, r, t.reason);
			break;
		case "invasion":
			t.action?.type === "invade" && pe(e, n, t.action, t.amount ?? 0);
			break;
		case "occupy":
			t.action?.type === "invade" && L(e, t.action.to) > 0 && pe(e, n, t.action, 0);
			break;
		case "freeUpgrade":
			ue(e, n, e.figures.filter((e) => e.owner === n && (t.card ? e.card === t.card : t.reason === "leader" ? N(e) : t.reason === "ship" ? M(e) : e.kind === t.reason)), "freeInvade");
			break;
		case "succor": {
			(t.amount ?? 0) > 1 && H(e, [{
				...t,
				amount: t.amount - 1
			}], !0);
			let r = e.figures.filter((e) => e.owner === n && e.kind === "warrior" && e.location === "reserve").slice(0, 1), i = t.to.startsWith("f") ? y.filter((e) => `f${e.fjord}` === t.to).map((e) => e.id) : [t.to];
			U(e, n, "succor", [...r.flatMap((t) => le(e, n, t, !0, !0)).filter((e) => e.type === "invade" && i.includes(e.to)).map((e, t) => ({
				id: `succor${t}`,
				unit: e.type === "invade" ? e.unit : "",
				to: e.type === "invade" ? e.to : "",
				tasks: [{
					kind: "succorMove",
					rid: n,
					action: e
				}]
			})), E]);
			break;
		}
		case "succorMove":
			if (t.action?.type === "invade") {
				let r = k(e, t.action.unit);
				r.location = t.action.to, V(e, "invade", n, [r.id], "reserve", t.action.to);
			}
			break;
		case "domainPillage":
			e.clans[n].rage >= 2 && !e.pillaged.includes(t.to) && !e.destroyed.includes(t.to) && U(e, n, "domainPillage", [{
				id: "pillage",
				to: t.to,
				n: 2,
				tasks: [{
					kind: "pay",
					rid: n,
					amount: 2
				}, {
					kind: "startPillage",
					rid: n,
					to: t.to
				}]
			}, E]);
			break;
		case "startPillage":
			ye(e, n, t.to);
			break;
		case "startCards":
			be(e);
			break;
		case "reveal":
			Ee(e);
			break;
		case "questBattle": {
			let t = A(e, n, "tyrWrath") ? 5 : A(e, n, "tyrDomain") ? 3 : 0;
			t && K(e, n).some((e) => e.kind === "quest") && U(e, n, "questBattle", [{
				id: "boost",
				label: "boost",
				n: t,
				tasks: [{
					kind: "boostQuest",
					rid: n,
					amount: t
				}]
			}, E]);
			break;
		}
		case "boostQuest":
			i.questBoost[n] = t.amount;
			break;
		case "watch": {
			let t = i.participants.find((t) => !Se(e, t) && K(e, t).some((e) => e.effect === "watch"));
			if (t) {
				let n = i.participants.reduce((t, n) => t + we(e, n), 0);
				e.clans[t].glory += n;
				for (let t of i.participants) z(e, t, i.cards[t], "battle", "deck");
				e.discarded.push(...Object.values(i.cards).flat()), i.cards = {}, i.selected = {}, i.revealed = !1, i.canceled = [], i.questBoost = {};
				for (let t of i.participants) e.clans[t].hand.length === 0 && (i.selected[t] = null);
				e.phase = "battle", xe(e), V(e, "watch", t, [], "", i.province, n), Object.keys(i.selected).length === i.participants.length && H(e, [{ kind: "reveal" }], !0);
			} else De(e);
			break;
		}
		case "prepareBattle":
			Oe(e);
			break;
		case "smite": {
			let t = e.figures.filter((e) => e.owner === n && e.location === i.province && e.kind === "warrior");
			t.length && H(e, [{
				kind: "kill",
				unit: t[0].id,
				reason: "battle"
			}], !0);
			break;
		}
		case "tide": {
			let t = I(e, i.province, n);
			t.length > 1 && U(e, n, "survivor", t.map((e) => ({
				id: e.id,
				unit: e.id,
				tasks: t.filter((t) => t.id !== e.id).map((e) => ({
					kind: "kill",
					unit: e.id,
					reason: "battle"
				}))
			})));
			break;
		}
		case "winner": {
			i.strengths = Object.fromEntries(i.participants.map((t) => [t, se(e, t, i.province, !0) + we(e, t)]));
			let t = Math.max(...Object.values(i.strengths)), n = i.participants.filter((e) => i.strengths[e] === t);
			i.winner = n.length === 1 ? n[0] : null;
			let r = I(e, i.province).filter((e) => e.owner !== i.winner).map((e) => ({
				kind: "kill",
				unit: e.id,
				reason: "battle"
			}));
			i.winner === i.pillager && r.push({
				kind: "reward",
				rid: i.pillager
			}), r.push({ kind: "battleGlory" }, { kind: "battleEffects" }, { kind: "cardsBack" }, { kind: "moveGod" }, { kind: "closeBattle" }), H(e, r, !0), V(e, "battle", i.winner ?? "", [], "", i.province, t);
			break;
		}
		case "reward":
			ke(e, n);
			break;
		case "leaderMove":
			r && O(r) && U(e, n, "leaderMove", [...(D(r.location)?.adjacent ?? []).filter((t) => !e.destroyed.includes(t) && L(e, t) > 0).map((e) => ({
				id: e,
				unit: r.id,
				to: e,
				tasks: [{
					kind: "move",
					unit: r.id,
					to: e
				}]
			})), E]);
			break;
		case "battleGlory":
			for (let t of i.participants) (P(e, "loki", i.province) ? t !== i.winner : t === i.winner) && (e.clans[t].glory += j(e, t, 1));
			break;
		case "battleEffects": {
			let t = [];
			for (let n of i.participants) {
				let r = i.dead.map((t) => k(e, t)).filter((e) => e.owner !== n).length;
				r >= 2 && (e.clans[n].glory += 2 * A(e, n, "thorGlory"));
				let a = i.initial.map((t) => k(e, t)).filter((e) => e.owner === n), o = a.filter((e) => e.card && _[e.card].effect === "valkyrie").length;
				if (e.clans[n].glory += 2 * r * o, n === i.winner && (P(e, "thor", i.province) && (e.clans[n].glory += 2 * r), A(e, n, "chosen3") && (e.clans[n].glory += 3 * a.filter((e) => e.kind === "mystic").length), a.some((e) => e.card && _[e.card].effect === "nidhogg") && (e.clans[n].glory += e.figures.filter((e) => e.location === "valhalla" && i.participants.includes(e.owner) && e.owner !== n).length)), !Se(e, n)) {
					for (let r of K(e, n)) if (r.effect === "odinJudgement" && (e.clans[n].glory += i.dead.length * 2), n === i.winner) r.effect === "hammer" && (e.clans[n].glory += 3), r.effect === "oath" && t.push({
						kind: "stat",
						rid: n
					}), r.effect === "ascension" && (e.clans[n].rage = Math.min(12, e.clans[n].rage + 3), e.clans[n].glory += 3);
					else if (i.winner) {
						if (r.effect === "trickery") {
							let t = Math.min(1, e.clans[i.winner].rage);
							e.clans[i.winner].rage -= t, e.clans[n].rage = Math.min(12, e.clans[n].rage + t);
						}
						if (r.effect === "backstab") {
							let t = Math.min(2, e.clans[i.winner].glory);
							e.clans[i.winner].glory -= t, e.clans[n].glory += t;
						}
						r.effect === "poison" && t.push({
							kind: "poison",
							rid: n
						});
					}
				}
				n !== i.winner && A(e, n, "blessing") && t.push({
					kind: "blessing",
					rid: n,
					to: i.province,
					amount: A(e, n, "blessing")
				});
			}
			H(e, t, !0);
			break;
		}
		case "poison":
			i.winner && (z(e, n, i.cards[i.winner], `battle:${i.winner}`, "hand"), e.clans[n].hand.push(...i.cards[i.winner]), i.cards[i.winner] = []);
			break;
		case "blessing":
			(t.amount ?? 0) > 1 && H(e, [{
				...t,
				amount: t.amount - 1
			}], !0), ue(e, n, e.figures.filter((e) => e.owner === n && e.kind === "warrior" && e.location === "reserve").slice(0, 1), "blessing", !0, t.to);
			break;
		case "cardsBack": {
			let t = [];
			for (let n of i.participants) for (let r of i.cards[n]) n === i.winner ? A(e, n, "prowess") ? t.push({
				kind: "keepCard",
				rid: n,
				card: r
			}) : t.push({
				kind: "discardCard",
				rid: n,
				card: r
			}) : t.push({
				kind: "returnCard",
				rid: n,
				card: r
			});
			H(e, t, !0);
			break;
		}
		case "keepCard":
			e.clans[n].rage >= 1 ? U(e, n, "keepCard", [{
				id: "keep",
				card: t.card,
				n: 1,
				label: "keep",
				tasks: [{
					kind: "pay",
					rid: n,
					amount: 1
				}, {
					kind: "returnCard",
					rid: n,
					card: t.card
				}]
			}, {
				id: "discard",
				card: t.card,
				label: "discard",
				tasks: [{
					kind: "discardCard",
					rid: n,
					card: t.card
				}]
			}]) : H(e, [{
				kind: "discardCard",
				rid: n,
				card: t.card
			}], !0);
			break;
		case "returnCard":
			z(e, n, [t.card], "battle", "hand"), i && (i.cards[n] = i.cards[n].filter((e) => e !== t.card)), e.clans[n].hand.push(t.card), V(e, "cardReturn", n, [], "", "", 0, t.card);
			break;
		case "discardCard":
			z(e, n, [t.card], "battle", "deck"), i && (i.cards[n] = i.cards[n].filter((e) => e !== t.card)), e.discarded.push(t.card), V(e, "cardDiscard", n, [], "", "", 0, t.card);
			break;
		case "moveGod": {
			let t = e.gods.find((e) => e.province === i.province);
			if (t) {
				let n = y.filter((t) => t.id !== i.province && !e.destroyed.includes(t.id) && !e.pillaged.includes(t.id) && !e.gods.some((e) => e.province === t.id)).map((e) => ({
					id: e.id,
					to: e.id,
					tasks: [{
						kind: "godMove",
						from: t.kind,
						to: e.id
					}]
				}));
				n.length && U(e, i.pillager, "godMove", n);
			}
			break;
		}
		case "godMove":
			e.gods.find((e) => e.kind === t.from).province = t.to, V(e, "godMove", "", [], "", t.to);
			break;
		case "closeBattle":
			e.turn = i.pillager, e.battle = null;
			break;
		case "quest": {
			let r = Ae(e, n, t.card), i = r ? _[t.card].glory * 2 ** A(e, n, "throne") : 0;
			z(e, n, [t.card], "quests", "reveal"), e.questResults.push({
				rid: n,
				card: t.card,
				success: r,
				glory: i
			}), e.clans[n].glory += i, e.clans[n].quests = e.clans[n].quests.filter((e) => e !== t.card), e.discarded.push(t.card), V(e, r ? "questSuccess" : "questFail", n, [], "", "", i, t.card), r && H(e, [{
				kind: "stat",
				rid: n
			}], !0);
			break;
		}
		case "ragnarok": {
			let t = e.figures.find((e) => e.card && _[e.card].effect === "fenrir" && e.location.startsWith("p") && e.location !== "p8")?.location ?? e.doom[e.age - 1];
			e.destroyed.includes(t) || e.destroyed.push(t);
			for (let n = e.age; n < 3; n++) e.doom[n] === t && (e.doom[n] = R(e, y.slice(0, 8).map((e) => e.id).filter((t) => !e.destroyed.includes(t) && !e.doom.slice(e.age).filter((t, r) => r + e.age !== n).includes(t)))[0]);
			H(e, [...I(e, t).map((e) => ({
				kind: "kill",
				unit: e.id,
				reason: "ragnarok"
			})), { kind: "releaseStart" }], !0), V(e, "ragnarok", "", [], "", t);
			break;
		}
		case "releaseStart":
			H(e, [...e.figures.filter((e) => e.location === "valhalla").map((e) => ({
				kind: "release",
				unit: e.id
			})), { kind: "nextAge" }], !0);
			break;
		case "release":
			if (r?.location === "valhalla") {
				r.location = "reserve";
				let t = A(e, r.owner, "loki1") + 2 * A(e, r.owner, "loki2") + 3 * A(e, r.owner, "loki3");
				e.clans[r.owner].glory += t, V(e, "release", r.owner, [r.id], "valhalla", "reserve", t);
			}
			break;
		case "nextAge": if (e.age === 3) {
			for (let t of e.players) {
				let n = e.clans[t];
				n.finalStats = n.stats.reduce((e, t) => e + (t === 5 ? 20 : t >= 3 ? 10 : 0), 0), n.finalConquest = A(e, t, "conquest") * 3 * e.figures.filter((e) => e.owner === t && O(e)).length, n.glory += n.finalStats + n.finalConquest;
			}
			e.phase = "done", V(e, "final");
		} else e.age++, e.first = (e.first + 1) % e.players.length, e.pillaged = [], he(e), me(e);
	}
}
function Ne(e, t) {
	let n = (e) => JSON.stringify(Object.fromEntries(Object.entries(e).filter(([, e]) => e !== void 0).sort(([e], [t]) => e.localeCompare(t)).map(([e, t]) => [e, Array.isArray(t) ? [...t].sort() : t])));
	return n(e) === n(t);
}
function Pe(e, t, n) {
	return !e.destroyed.includes(n) && I(e, n, t).length > 0 && (!e.pillaged.includes(n) || A(e, t, "challenge") > 0 && e.clans[t].rage >= 2);
}
function Fe(e, t) {
	let n = e.clans[t];
	if (!n) return [];
	if (e.phase === "draft") {
		if (e.draftPicked[t]) return [];
		let n = e.draft[t];
		return e.players.length === 2 ? n.flatMap((e, t) => n.slice(t + 1).map((t) => ({
			type: "draft",
			cards: [e, t]
		}))) : n.map((e) => ({
			type: "draft",
			cards: [e]
		}));
	}
	if (e.phase === "discard") return e.ready.includes(t) ? [] : n.hand.map((e) => ({
		type: "discard",
		keep: e
	}));
	if (e.phase === "decision") return e.decision?.rid === t ? e.decision.choices.map((e) => ({
		type: "choose",
		id: e.id
	})) : [];
	if (e.phase === "battle") {
		let r = e.battle;
		if (!r.participants.includes(t) || t in r.selected || P(e, "heimdall", r.province) && e.turn !== t) return [];
		let i = n.hand.filter((n) => Te(e, t, n));
		return i.length ? i.map((e) => ({
			type: "battle",
			card: e
		})) : [{
			type: "battle",
			card: null
		}];
	}
	if (e.phase === "extra") return e.turn === t ? [{
		type: "extra",
		card: null
	}, ...n.hand.filter((e) => [
		"sight",
		"eye",
		"gaze"
	].includes(_[e].effect)).map((e) => ({
		type: "extra",
		card: e
	}))] : [];
	if (e.phase === "reinforce") {
		if (e.turn !== t) return [];
		let n = e.battle;
		return [{
			type: "reinforce",
			unit: null
		}, ...L(e, n.province) > 0 ? e.figures.filter((e) => e.owner === t && !M(e) && (D(n.province)?.adjacent).includes(e.location)).map((e) => ({
			type: "reinforce",
			unit: e.id
		})) : []];
	}
	if (e.phase !== "action" || e.turn !== t || n.rage <= 0) return [];
	let r = [{ type: "pass" }];
	for (let n of y) Pe(e, t, n.id) && r.push({
		type: "pillage",
		province: n.id
	});
	for (let n of e.figures.filter((e) => e.owner === t)) n.location === "reserve" && r.push(...le(e, t, n)), n.location === "valhalla" && A(e, t, "friggaDomain") && r.push(...le(e, t, n, !1, !1, !0));
	for (let i of n.hand) {
		let a = _[i];
		if (a.kind === "quest" && r.push({
			type: "quest",
			card: i
		}), a.kind === "battle" || a.kind === "quest" || ([
			"dwarf",
			"hel",
			"ymir"
		].includes(a.effect) ? 0 : Math.max(0, a.strength - A(e, t, "charm"))) > n.rage) continue;
		let o = a.kind === "clan" ? [
			"clan0",
			"clan1",
			"clan2"
		] : a.kind === "monster" ? ["monster0", "monster1"] : [a.kind];
		for (let e of o) r.push({
			type: "upgrade",
			card: i,
			slot: e
		});
	}
	if (n.rage >= 1) for (let n of y) {
		let i = e.figures.filter((e) => e.owner === t && e.location === n.id && !M(e));
		for (let t of y.filter((t) => t.id !== n.id && !e.destroyed.includes(t.id) && L(e, t.id) > 0)) {
			for (let e of i) r.push({
				type: "march",
				units: [e.id],
				to: t.id
			});
			let n = i.slice(0, L(e, t.id));
			n.length > 1 && r.push({
				type: "march",
				units: n.map((e) => e.id),
				to: t.id
			});
		}
	}
	if (A(e, t, "sacrifice")) {
		let n = e.figures.filter((e) => e.owner === t && O(e));
		for (let e = 0; e < n.length; e++) for (let t = e + 1; t < n.length; t++) r.push({
			type: "sacrifice",
			units: [n[e].id, n[t].id]
		});
	}
	return r;
}
function Ie(e, t, { by: n }) {
	if (t.type === "tick") {
		if (e.phase !== "settle" || !e.tasks.length) return { state: e };
		let t = structuredClone(e);
		return t.frameFx = [], Me(t, t.tasks.shift()), B(t);
	}
	if (!e.clans[n]) return T;
	if (t.type === "march" && e.phase === "action" && e.turn === n && e.clans[n].rage > 0) {
		let r = t.units.map((t) => k(e, t)), i = r[0]?.location;
		if (new Set(t.units).size !== t.units.length || !i?.startsWith("p") || r.some((e) => !e || e.owner !== n || e.location !== i || M(e)) || t.to === i || !D(t.to) || e.destroyed.includes(t.to) || L(e, t.to) < r.length) return T;
	} else if (!Fe(e, n).some((e) => Ne(e, t))) return T;
	let r = structuredClone(e);
	r.frameFx = [];
	let i = r.clans[n];
	switch (t.type) {
		case "draft":
			if (r.draftPicked[n] = t.cards, Object.keys(r.draftPicked).length === r.players.length) {
				let e = {};
				for (let t = 0; t < r.players.length; t++) {
					let n = r.players[t], i = r.draftPicked[n];
					z(r, n, i, "draft", "hand", !0), r.clans[n].hand.push(...i), e[r.players[(t + 1) % r.players.length]] = r.draft[n].filter((e) => !i.includes(e));
				}
				if (r.draftCount += r.players.length === 2 ? 2 : 1, r.draftPicked = {}, r.draft = e, r.draftCount === 6) {
					r.discarded.push(...Object.values(r.draft).flat()), r.draft = {}, r.phase = "action", r.turn = r.players[r.first], r.actionPlayer = r.turn;
					for (let e of r.players) r.clans[e].rage = j(r, e, 0);
				}
				for (let e of r.players) r.draft[e] && z(r, e, r.draft[e], "seat", "draft", !0);
				V(r, "draft");
			}
			break;
		case "choose": {
			let e = r.decision.choices.find((e) => e.id === t.id);
			if (r.decision = null, H(r, e.tasks, !0), !r.tasks.length) return T;
			break;
		}
		case "invade":
			H(r, [{ kind: "finishTurn" }]), pe(r, n, t, ce(r, k(r, t.unit), t.to, t.fromValhalla));
			break;
		case "march": {
			let e = k(r, t.units[0]).location;
			i.rage--;
			for (let e of t.units) k(r, e).location = t.to;
			V(r, "march", n, t.units, e, t.to), H(r, [{ kind: "finishTurn" }]);
			break;
		}
		case "upgrade": {
			let e = _[t.card], a = i.upgrades[t.slot], o = [
				"dwarf",
				"hel",
				"ymir"
			].includes(e.effect) ? 0 : Math.max(0, e.strength - A(r, n, "charm"));
			if (i.rage -= o, i.hand = i.hand.filter((e) => e !== t.card), a && (z(r, n, [a], "upgrade", "deck"), r.discarded.push(a), t.slot.startsWith("monster"))) for (let e of r.figures.filter((e) => e.card === a)) {
				let t = e.location;
				e.location = "box", V(r, "remove", n, [e.id], t, "box");
			}
			if (z(r, n, [t.card], "hand", "upgrade"), i.upgrades[t.slot] = t.card, e.effect.startsWith("chosen") && i.mystics < 2) {
				let e = `${n}:mystic${i.mystics++}`;
				r.figures.push({
					id: e,
					owner: n,
					kind: "mystic",
					card: null,
					location: "reserve"
				});
			}
			e.kind === "monster" && r.figures.push({
				id: `${n}:${t.card}`,
				owner: n,
				kind: "monster",
				card: t.card,
				location: "reserve"
			});
			let s = [];
			e.kind !== "clan" && s.push({
				kind: "freeUpgrade",
				rid: n,
				...e.kind === "monster" ? { card: t.card } : { reason: e.kind }
			}), s.push({ kind: "finishTurn" }), H(r, s), V(r, "upgrade", n, [], "", "", o, t.card);
			break;
		}
		case "quest":
			z(r, n, [t.card], "hand", "quests", !0, !0), i.hand = i.hand.filter((e) => e !== t.card), i.quests.push(t.card), H(r, [{ kind: "finishTurn" }]), V(r, "questCommit", n);
			break;
		case "pillage":
			r.pillaged.includes(t.province) && (i.rage -= 2), H(r, [{ kind: "finishTurn" }]), ye(r, n, t.province);
			break;
		case "sacrifice":
			H(r, [
				...t.units.map((e) => ({
					kind: "kill",
					unit: e,
					reason: "sacrifice"
				})),
				{
					kind: "stat",
					rid: n
				},
				{ kind: "finishTurn" }
			]);
			break;
		case "pass":
			i.rage = 0, H(r, [{ kind: "finishTurn" }]);
			break;
		case "reinforce": {
			let e = r.battle;
			if (t.unit) {
				let i = k(r, t.unit), a = i.location;
				i.location = e.province, e.passes = 0, V(r, "march", n, [i.id], a, e.province);
			} else e.passes++;
			e.cursor = (e.cursor + 1) % r.players.length, r.turn = r.players[e.cursor], (e.passes === r.players.length || L(r, e.province) <= 0) && H(r, [{ kind: "startCards" }], !0);
			break;
		}
		case "battle": {
			let e = r.battle;
			e.selected[n] = t.card, t.card && (z(r, n, [t.card], "hand", "battle", !P(r, "heimdall", e.province), !P(r, "heimdall", e.province)), i.hand = i.hand.filter((e) => e !== t.card)), xe(r), Object.keys(e.selected).length === e.participants.length && H(r, [{ kind: "reveal" }], !0);
			break;
		}
		case "extra": {
			let e = r.battle;
			t.card ? (z(r, n, [t.card], "hand", "battle"), e.cards[n].push(t.card), i.hand = i.hand.filter((e) => e !== t.card), e.passes = 0, V(r, "extra", n, [], "", e.province, 0, t.card)) : e.passes++, e.cursor = (e.cursor + 1) % e.participants.length, r.turn = e.participants[e.cursor], e.passes === e.participants.length && H(r, [{ kind: "prepareBattle" }], !0);
			break;
		}
		case "discard": z(r, n, i.hand.filter((e) => e !== t.keep), "hand", "deck", !0), r.discarded.push(...i.hand.filter((e) => e !== t.keep)), i.hand = t.keep ? [t.keep] : [], r.ready.push(n), r.ready.length === r.players.length && je(r);
	}
	return B(r);
}
function Le(e, t) {
	let n = e.clans[t], r = e.battle;
	return {
		public: {
			phase: e.phase,
			age: e.age,
			turn: e.turn,
			config: e.config,
			players: e.players.map((t) => ({
				rid: t,
				rage: e.clans[t].rage,
				stats: e.clans[t].stats,
				glory: e.clans[t].glory,
				upgrades: e.clans[t].upgrades,
				handCount: e.clans[t].hand.length,
				questCount: e.clans[t].quests.length,
				mystics: e.clans[t].mystics,
				ready: e.phase === "draft" ? t in e.draftPicked : e.ready.includes(t),
				finalStats: e.clans[t].finalStats,
				finalConquest: e.clans[t].finalConquest
			})),
			figures: e.figures,
			destroyed: e.destroyed,
			pillaged: e.pillaged,
			rewards: e.rewards,
			doom: e.doom,
			gods: e.gods,
			battle: r ? {
				province: r.province,
				pillager: r.pillager,
				participants: r.participants,
				cards: r.revealed ? r.cards : P(e, "heimdall", r.province) ? Object.fromEntries(Object.entries(r.selected).map(([e, t]) => [e, t ? [t] : []])) : {},
				strengths: r.strengths,
				winner: r.winner,
				revealed: r.revealed,
				picked: Object.keys(r.selected),
				questBoost: r.questBoost
			} : null,
			prompt: e.decision ? {
				rid: e.decision.rid,
				kind: e.decision.kind
			} : null,
			event: e.event,
			questResults: e.questResults,
			log: e.log
		},
		private: {
			hand: n?.hand ?? [],
			quests: n?.quests ?? [],
			draft: e.draft[t] ?? [],
			selected: e.draftPicked[t] ?? (r?.selected[t] ? [r.selected[t]] : []),
			actions: Fe(e, t),
			choices: e.decision?.rid === t ? e.decision.choices.map((e) => {
				let { tasks: t, ...n } = e;
				return n;
			}) : []
		}
	};
}
var Re = {
	meta: b,
	saveCompatibility: { version: "1" },
	schemas: {
		action: S,
		publicView: re,
		privateView: ie,
		config: x
	},
	setup: ge,
	reduce: Ie,
	viewFor: Le,
	nextTickIn: (e) => e.phase === "settle" && e.tasks.length ? [
		"destroy",
		"ragnarok",
		"battle",
		"reveal",
		"questSuccess",
		"questFail"
	].includes(e.event.kind) ? 900 : 450 : null,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => e.clans[n].glory - e.clans[t].glory);
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((n) => e.clans[n].glory === e.clans[t[0]].glory),
			scores: Object.fromEntries(e.players.map((t) => [t, e.clans[t].glory]))
		};
	}
}, q = (e) => `games/bloodrage/${e}.svg`, J = {
	...Object.fromEntries(y.map((e) => [e.id, e.key])),
	f0: "games.bloodrage.f0",
	f1: "games.bloodrage.f1",
	f2: "games.bloodrage.f2",
	f3: "games.bloodrage.f3",
	reserve: "games.bloodrage.reserve",
	valhalla: "games.bloodrage.valhalla"
}, Y = {
	warrior: "games.bloodrage.warrior",
	leader: "games.bloodrage.leader",
	ship: "games.bloodrage.ship",
	mystic: "games.bloodrage.mystic",
	monster: "games.bloodrage.monster",
	clan: "games.bloodrage.clan",
	battle: "games.bloodrage.battleCard",
	quest: "games.bloodrage.questCard"
}, ze = [
	"games.bloodrage.rage",
	"games.bloodrage.axes",
	"games.bloodrage.horns"
], Be = {
	rage: ze[0],
	axes: ze[1],
	horns: ze[2],
	glory: "games.bloodrage.glory",
	all: "games.bloodrage.all"
}, Ve = {
	thor: "games.bloodrage.thor",
	frigga: "games.bloodrage.frigga",
	tyr: "games.bloodrage.tyr",
	odin: "games.bloodrage.odin",
	loki: "games.bloodrage.loki",
	heimdall: "games.bloodrage.heimdall"
}, He = {
	thor: "games.bloodrage.god_thor",
	frigga: "games.bloodrage.god_frigga",
	tyr: "games.bloodrage.god_tyr",
	odin: "games.bloodrage.god_odin",
	loki: "games.bloodrage.god_loki",
	heimdall: "games.bloodrage.god_heimdall"
}, Ue = {
	stat: "games.bloodrage.statPrompt",
	death: "games.bloodrage.death",
	survivor: "games.bloodrage.survivor",
	freeInvade: "games.bloodrage.freeInvade",
	succor: "games.bloodrage.succor",
	blessing: "games.bloodrage.blessing",
	domainPillage: "games.bloodrage.domainPillage",
	questBattle: "games.bloodrage.questBattle",
	keepCard: "games.bloodrage.choosePrompt",
	godMove: "games.bloodrage.godMove",
	leaderMove: "games.bloodrage.leaderMove"
}, We = {
	boost: "games.bloodrage.boostQuest",
	destroy: "games.bloodrage.destroy",
	protect: "games.bloodrage.protect",
	retreat: "games.bloodrage.retreat",
	keep: "games.bloodrage.keep",
	discard: "games.bloodrage.discard"
}, Ge = {
	invade: "games.bloodrage.log_invade",
	march: "games.bloodrage.log_march",
	pillage: "games.bloodrage.log_pillage",
	battle: "games.bloodrage.log_battle",
	destroy: "games.bloodrage.log_destroy",
	ragnarok: "games.bloodrage.log_ragnarok",
	questSuccess: "games.bloodrage.log_questSuccess",
	questFail: "games.bloodrage.log_questFail",
	age: "games.bloodrage.log_age",
	upgrade: "games.bloodrage.log_upgrade",
	release: "games.bloodrage.log_release",
	final: "games.bloodrage.log_final"
}, Ke = /* @__PURE__ */ new Set([
	"dwarf",
	"troll",
	"serpent",
	"elf",
	"valkyrie",
	"fire",
	"hel",
	"witch",
	"frost",
	"fenrir",
	"mountain",
	"wolfman",
	"mysticTroll",
	"hildi",
	"nidhogg",
	"ymir"
]);
function qe(e) {
	let t = _[e].effect;
	return Ke.has(t) ? t : [
		"chosen1",
		"protection",
		"charm",
		"succor",
		"grace",
		"sacrifice",
		"friggaDomain"
	].includes(t) ? "chosen1" : t.startsWith("loki") || [
		"trickery",
		"backstab",
		"poison",
		"blessing"
	].includes(t) ? "trickery" : [
		"sight",
		"eye",
		"gaze",
		"watch"
	].includes(t) ? "sight" : t.startsWith("odin") || [
		"chosen2",
		"inspiration",
		"throne",
		"tide"
	].includes(t) ? "chosen2" : t.startsWith("tyr") || [
		"smash",
		"smite",
		"crush",
		"bash",
		"rage",
		"judgement",
		"prowess",
		"challenge"
	].includes(t) ? "tyrDomain" : "thorGlory";
}
function Je(e, t, n = t.location) {
	let r = e.players.find((e) => e.rid === t.owner), i = (e) => Object.values(r.upgrades).some((t) => _[t].effect === e);
	if (t.kind === "warrior") return i("experts") ? 2 : 1;
	if (t.kind === "leader") return 3;
	if (t.kind === "ship" || t.kind === "mystic") return 2;
	let a = _[t.card];
	return a.effect === "ymir" ? 2 * e.figures.filter((e) => e.owner === t.owner && e.location === "valhalla").length : a.effect === "elf" && n === "p8" ? 3 : a.strength;
}
function X(e, t, n, r = !1) {
	if (r && e.gods.some((e) => e.kind === "tyr" && e.province === n)) return 0;
	let i = y.find((e) => e.id === n), a = e.figures.filter((e) => e.location === n || i && i.fjord >= 0 && e.location === `f${i.fjord}`), o = r && a.some((e) => e.card && _[e.card].effect === "wolfman"), s = a.filter((e) => e.owner === t && (!o || e.kind === "monster")), c = e.players.find((e) => e.rid === t).upgrades.warrior, l = c ? {
		brothers: 1,
		masters: 4
	}[_[c].effect] ?? 0 : 0;
	return s.reduce((t, r) => t + Je(e, r, n), 0) + Math.floor(s.filter((e) => e.kind === "warrior").length / 2) * l;
}
//#endregion
//#region src/games/bloodrage/piece.tsx
function Ye({ figure: e, color: t, seat: n }) {
	let r = e.kind === "leader" ? "♛" : e.kind === "ship" ? "≈" : e.kind === "mystic" ? "ᛉ" : e.kind === "warrior" ? "ᛏ" : "";
	return /* @__PURE__ */ m("g", { children: [
		/* @__PURE__ */ p("circle", {
			r: "17",
			fill: t,
			stroke: "#f0e6cb",
			strokeWidth: "2"
		}),
		e.card ? /* @__PURE__ */ p("image", {
			href: q(qe(e.card)),
			x: "-13",
			y: "-13",
			width: "26",
			height: "26",
			preserveAspectRatio: "xMidYMin slice"
		}) : /* @__PURE__ */ p("text", {
			y: "6",
			textAnchor: "middle",
			fontSize: "22",
			fontWeight: "900",
			fill: "#10202b",
			children: r
		}),
		/* @__PURE__ */ p("circle", {
			cx: "13",
			cy: "13",
			r: "8",
			fill: "#15212a",
			stroke: "#dac795"
		}),
		/* @__PURE__ */ p("text", {
			x: "13",
			y: "17",
			textAnchor: "middle",
			fontSize: "11",
			fontWeight: "800",
			fill: "#fff0cf",
			children: n
		})
	] });
}
//#endregion
//#region src/games/bloodrage/board.tsx
var Xe = [
	{
		id: "p0",
		x: 337,
		y: 312,
		d: "M202 221L258 190 333 233 380 335 442 337 392 405 248 398 175 340Z"
	},
	{
		id: "p1",
		x: 467,
		y: 223,
		d: "M262 185L350 71 455 67 521 92 553 163 535 300 548 350 458 365 409 337 374 236Z"
	},
	{
		id: "p2",
		x: 674,
		y: 260,
		d: "M550 181L632 153 704 139 765 210 789 296 746 387 690 422 613 430 575 365 540 345Z"
	},
	{
		id: "p3",
		x: 755,
		y: 541,
		d: "M649 431L723 407 817 438 864 526 914 637 839 669 748 663 678 632 623 578Z"
	},
	{
		id: "p4",
		x: 635,
		y: 742,
		d: "M619 598L681 632 747 664 781 755 760 835 681 837 616 879 534 906 510 824 535 748Z"
	},
	{
		id: "p5",
		x: 424,
		y: 808,
		d: "M375 681L437 679 493 699 529 751 509 832 476 896 392 902 319 869 304 801 323 740Z"
	},
	{
		id: "p6",
		x: 268,
		y: 686,
		d: "M256 600L336 577 361 634 386 682 328 747 302 797 263 845 228 806 156 743 122 654Z"
	},
	{
		id: "p7",
		x: 242,
		y: 483,
		d: "M74 427L175 395 259 405 341 380 373 420 359 485 335 575 262 609 143 625 95 569 59 493Z"
	},
	{
		id: "p8",
		x: 500,
		y: 468,
		d: "M409 351L458 365 549 356 609 417 646 435 626 574 613 606 538 685 492 701 437 680 387 682 362 626 335 575 360 483 376 420Z"
	},
	{
		id: "f0",
		x: 122,
		y: 307,
		d: "M64 260H183V356H64Z"
	},
	{
		id: "f1",
		x: 663,
		y: 99,
		d: "M597 58H730V151H597Z"
	},
	{
		id: "f2",
		x: 862,
		y: 765,
		d: "M809 715H935V815H809Z"
	},
	{
		id: "f3",
		x: 271,
		y: 908,
		d: "M200 862H332V954H200Z"
	}
];
function Ze({ pub: e, selected: t, targets: n, onSelect: r, color: i, nameOf: o, onFigureSelect: s }) {
	let c = a();
	return /* @__PURE__ */ m("div", {
		className: "bloodrage-map",
		children: [/* @__PURE__ */ p(h, {
			image: q("board"),
			sheetW: 1e3,
			sheetH: 1e3,
			clampToSheet: !0,
			fitKey: "bloodrage",
			highlight: "off",
			eligible: [...Xe.map((e) => ({
				key: e.id,
				rect: {
					x: e.x - 78,
					y: e.y - 33,
					w: 156,
					h: 66
				}
			})), ...e.figures.flatMap((t) => {
				let n = Xe.find((e) => e.id === t.location);
				if (!n) return [];
				let r = e.figures.filter((e) => e.location === n.id).findIndex((e) => e.id === t.id);
				return [{
					key: `unit:${t.id}`,
					rect: {
						x: n.x - 78 + r % 5 * 35,
						y: n.y + 35 + Math.floor(r / 5) * 40,
						w: 35,
						h: 40
					}
				}];
			})],
			onTapEligible: (t) => {
				if (t.startsWith("unit:")) {
					let n = e.figures.find((e) => `unit:${e.id}` === t);
					n && (r(n.location), s?.(n));
				} else r(t);
			},
			children: Xe.map((r) => {
				let a = y.find((e) => e.id === r.id), s = e.destroyed.includes(r.id), l = e.figures.filter((e) => e.location === r.id), u = a ? e.rewards[Number(r.id.slice(1))] : void 0, d = e.doom.indexOf(r.id), f = e.gods.find((e) => e.province === r.id);
				return /* @__PURE__ */ m("g", {
					className: "bloodrage-province",
					"data-destroyed": s,
					children: [
						/* @__PURE__ */ p("path", {
							d: r.d,
							fill: s ? "#101518d9" : t === r.id ? "#ffe3a619" : "transparent",
							stroke: t === r.id ? "#f1cd7d" : s ? "#8a4a3e" : "transparent",
							strokeWidth: 4
						}),
						n.includes(r.id) && /* @__PURE__ */ p("path", {
							d: r.d,
							fill: "#ffffff18",
							stroke: "#f6eed4",
							strokeWidth: "5",
							strokeDasharray: "12 8",
							children: /* @__PURE__ */ p("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: "-40",
								dur: "1s",
								repeatCount: "indefinite"
							})
						}),
						/* @__PURE__ */ m("g", {
							"data-br-zone": r.id,
							children: [/* @__PURE__ */ p("rect", {
								x: r.x - 77,
								y: r.y - 26,
								width: "154",
								height: "37",
								rx: "3",
								fill: "#16222aef",
								stroke: t === r.id ? "#f2d584" : "#aa9665",
								strokeWidth: "2"
							}), /* @__PURE__ */ p("text", {
								x: r.x,
								y: r.y,
								textAnchor: "middle",
								fill: "#f5ebd5",
								fontSize: "20",
								fontWeight: "700",
								children: c(J[r.id])
							})]
						}),
						a && /* @__PURE__ */ p("text", {
							x: r.x,
							y: r.y + 31,
							textAnchor: "middle",
							fill: s ? "#e8a895" : "#ead6a8",
							fontSize: "17",
							paintOrder: "stroke",
							stroke: "#1c272d",
							strokeWidth: "4",
							children: s ? c("games.bloodrage.destroyed") : e.pillaged.includes(r.id) ? c("games.bloodrage.pillaged") : u ? c(Be[u]) : ""
						}),
						!s && d >= e.age - 1 && /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("path", {
							d: `M${r.x + 60} ${r.y - 52}l17 29h-34Z`,
							fill: "#a4302b",
							stroke: "#f3b396",
							strokeWidth: "2"
						}), /* @__PURE__ */ p("text", {
							x: r.x + 60,
							y: r.y - 31,
							fill: "#fff0d1",
							fontSize: "18",
							textAnchor: "middle",
							children: [
								"I",
								"II",
								"III"
							][d]
						})] }),
						f && /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("circle", {
							cx: r.x - 76,
							cy: r.y - 27,
							r: "12",
							fill: "#d3b772",
							stroke: "#f7e7bc",
							strokeWidth: "3"
						}), /* @__PURE__ */ p("text", {
							x: r.x - 50,
							y: r.y - 35,
							fontSize: "18",
							fill: "#fff0be",
							paintOrder: "stroke",
							stroke: "#17242c",
							strokeWidth: "4",
							children: c(Ve[f.kind])
						})] }),
						l.map((t, n) => /* @__PURE__ */ m("g", {
							"data-br-motion": `unit:${t.id}`,
							"data-br-place": t.location,
							transform: `translate(${r.x - 58 + n % 5 * 35},${r.y + 55 + Math.floor(n / 5) * 40})`,
							children: [/* @__PURE__ */ m("title", { children: [
								o(t.owner),
								" · ",
								c(Y[t.kind])
							] }), /* @__PURE__ */ p(Ye, {
								figure: t,
								color: i(t.owner),
								seat: e.players.findIndex((e) => e.rid === t.owner) + 1
							})]
						}, t.id))
					]
				}, r.id);
			})
		}), /* @__PURE__ */ m("div", {
			className: "bloodrage-map-tray",
			children: [/* @__PURE__ */ p("span", {
				"data-br-zone": "deck",
				children: c("games.bloodrage.age", { n: e.age })
			}), /* @__PURE__ */ m("span", {
				"data-br-zone": "valhalla",
				children: [
					c("games.bloodrage.valhalla"),
					" ",
					e.figures.filter((e) => e.location === "valhalla").length
				]
			})]
		})]
	});
}
//#endregion
//#region src/games/bloodrage/card.tsx
function Qe({ id: e, compact: t = !1, selected: n = !1 }) {
	let r = a(), i = _[e], o = [
		"dwarf",
		"hel",
		"ymir"
	].includes(i.effect), s = ["sight", "ymir"].includes(i.effect), c = o || [
		"brothers",
		"masters",
		"elf"
	].includes(i.effect), l = s ? "*" : `${i.strength}${c ? "*" : ""}`, u = i.kind === "battle" ? r("games.bloodrage.strength") : i.kind === "clan" ? r("games.bloodrage.baseCost") : r("games.bloodrage.figureCardValue", {
		strength: s ? "*" : i.strength,
		cost: o ? 0 : i.strength
	});
	return /* @__PURE__ */ m("div", {
		className: "bloodrage-card",
		"data-kind": i.kind,
		"data-selected": n,
		"data-compact": t,
		children: [
			/* @__PURE__ */ p("div", {
				className: "bloodrage-card-title",
				children: r(i.nameKey)
			}),
			/* @__PURE__ */ m("div", {
				className: "bloodrage-card-picture",
				children: [
					/* @__PURE__ */ p("img", {
						src: q(qe(e)),
						alt: ""
					}),
					i.kind !== "quest" && /* @__PURE__ */ p("span", {
						className: "bloodrage-card-strength",
						title: u,
						children: l
					}),
					/* @__PURE__ */ m("span", {
						className: "bloodrage-card-age",
						children: [[
							"I",
							"II",
							"III"
						][i.age - 1], /* @__PURE__ */ m("small", { children: [i.minPlayers, "+"] })]
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "bloodrage-card-type",
				children: [r(Y[i.kind]), i.glory > 0 && /* @__PURE__ */ m("strong", { children: [
					i.glory,
					" ",
					r("games.bloodrage.glory")
				] })]
			}),
			!t && /* @__PURE__ */ p("p", { children: r(i.textKey) })
		]
	});
}
//#endregion
//#region src/games/bloodrage/motion.tsx
function $e(e, t, n) {
	if (getComputedStyle(e).visibility !== "visible") return null;
	let r = t.getBoundingClientRect(), i = Math.max(n.left, r.left), a = Math.min(n.right, r.right), o = Math.max(n.top, r.top), s = Math.min(n.bottom, r.bottom);
	for (let n = e.parentElement; n && n !== t; n = n.parentElement) {
		let e = getComputedStyle(n), t = n.getBoundingClientRect();
		/^(auto|scroll|hidden|clip)$/.test(e.overflowX) && (i = Math.max(i, t.left), a = Math.min(a, t.right)), /^(auto|scroll|hidden|clip)$/.test(e.overflowY) && (o = Math.max(o, t.top), s = Math.min(s, t.bottom));
	}
	return a > i && s > o ? new DOMRect(i, o, a - i, s - o) : null;
}
function et(e, t) {
	let n = e.getBoundingClientRect(), r = e.cloneNode(!0), i = [e, ...e.querySelectorAll("*")], a = [r, ...r.querySelectorAll("*")];
	for (let e = 0; e < i.length; e++) {
		if (!(i[e] instanceof HTMLElement)) continue;
		let t = getComputedStyle(i[e]), n = a[e];
		for (let e of t) n.style.setProperty(e, t.getPropertyValue(e));
		n.style.animation = "none", n.style.transition = "none";
	}
	if (r instanceof HTMLElement && (r.style.opacity = "1"), e instanceof SVGGraphicsElement && !(e instanceof SVGSVGElement)) {
		let t = e.getBBox(), n = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		n.setAttribute("viewBox", `${t.x} ${t.y} ${t.width} ${t.height}`), r.removeAttribute("transform"), n.append(r), r = n;
	}
	return r.setAttribute("data-br-native-width", String(n.width)), r.setAttribute("data-br-native-height", String(n.height)), {
		rect: n,
		clip: $e(e, t, n),
		clone: r,
		node: e
	};
}
function tt() {
	let e = document.createElement("div");
	return e.className = "bloodrage-card-back", e.setAttribute("aria-hidden", "true"), e;
}
var nt = null;
function rt(e, t) {
	let i = r({
		viewer: t,
		items: /* @__PURE__ */ new Map()
	});
	n(() => {
		let n = e.current;
		if (!n) return;
		let r = [...n.querySelectorAll("[data-br-motion],[data-br-zone]")].map((e) => ({
			key: e.getAttribute("data-br-motion") ?? `zone:${e.getAttribute("data-br-zone")}`,
			item: et(e, n)
		})), a = /* @__PURE__ */ new Map(), o = () => {
			a.clear();
			for (let { key: e, item: t } of r) t.node.isConnected && (t.rect = t.node.getBoundingClientRect(), t.clip = $e(t.node, n, t.rect), t.rect.width && t.rect.height && (!a.has(e) || !a.get(e)?.clip && t.clip) && a.set(e, t));
		};
		return o(), nt = {
			container: n,
			before: i.current.viewer === t ? i.current.items : /* @__PURE__ */ new Map(),
			items: a,
			viewer: t
		}, i.current = {
			viewer: t,
			items: a
		}, n.addEventListener("scroll", o, !0), window.addEventListener("resize", o), () => {
			n.removeEventListener("scroll", o, !0), window.removeEventListener("resize", o), nt?.container === n && (nt = null);
		};
	});
}
function it({ entries: e }) {
	return n(() => {
		let t = nt;
		if (!t) return;
		let { container: n, items: r } = t, i = { items: t.before }, a = n.getBoundingClientRect(), o = [], s = [], c = (e) => e?.clip ? {
			...e,
			rect: e.clip
		} : void 0, l = (e, t, n = !1) => {
			let a = n ? i.items : r;
			return c(a.get(`zone:${e}:${t}`)) ?? c(a.get(`zone:${e}`)) ?? c(a.get(`zone:seat:${t}`));
		}, u = (e, t, r, i = 420, c, l = !1) => {
			if (!e || !t) return;
			let u = e.rect, d = t.rect, f = Number(r.getAttribute("data-br-native-width")) || 64, p = Number(r.getAttribute("data-br-native-height")) || 92, m = [];
			if (l) {
				let e = document.createElement("div"), t = tt(), n = r;
				Object.assign(e.style, { perspective: "700px" });
				for (let e of [t, n]) Object.assign(e.style, {
					position: "absolute",
					inset: "0",
					width: "100%",
					height: "100%",
					backfaceVisibility: "hidden"
				});
				n.style.opacity = "1", e.append(t, n), r = e, m = [t, n];
			}
			let h = r, g = u.left + (u.width - f) / 2, _ = u.top + (u.height - p) / 2, v = d.left + (d.width - f) / 2, y = d.top + (d.height - p) / 2;
			Object.assign(h.style, {
				position: "absolute",
				left: `${g - a.left}px`,
				top: `${_ - a.top}px`,
				width: `${f}px`,
				height: `${p}px`,
				pointerEvents: "none",
				zIndex: "35",
				margin: "0",
				transformOrigin: "center",
				overflow: l ? "visible" : "hidden"
			}), h.setAttribute("data-br-flight", "true"), h.removeAttribute("data-br-motion"), h.removeAttribute("data-br-zone"), n.append(h), s.push(h);
			let ee = Math.min(u.width / f, u.height / p), b = Math.min(d.width / f, d.height / p), x = v - g, S = y - _, C = h.animate([
				{
					transform: `translate(0,0) scale(${ee})`,
					opacity: 1
				},
				{
					transform: `translate(${x * .55}px,${S * .55 - 16}px) scale(${(ee + b) / 2})`,
					offset: .5,
					opacity: 1
				},
				{
					transform: `translate(${x}px,${S}px) scale(${b})`,
					opacity: 1
				}
			], {
				duration: i,
				easing: "cubic-bezier(.22,.68,.22,1)",
				fill: "forwards"
			});
			o.push(C), m.length && (o.push(m[0].animate([
				{
					transform: "rotateY(0deg)",
					opacity: 1
				},
				{
					transform: "rotateY(90deg)",
					opacity: 1,
					offset: .5
				},
				{
					transform: "rotateY(90deg)",
					opacity: 0,
					offset: .501
				},
				{
					transform: "rotateY(90deg)",
					opacity: 0
				}
			], {
				duration: i,
				fill: "forwards"
			})), o.push(m[1].animate([
				{
					transform: "rotateY(-90deg)",
					opacity: 0
				},
				{
					transform: "rotateY(-90deg)",
					opacity: 0,
					offset: .499
				},
				{
					transform: "rotateY(-90deg)",
					opacity: 1,
					offset: .5
				},
				{
					transform: "rotateY(0deg)",
					opacity: 1
				}
			], {
				duration: i,
				fill: "forwards"
			}))), c && o.push(c.animate([
				{
					opacity: 0,
					offset: 0
				},
				{
					opacity: 0,
					offset: .96
				},
				{ opacity: 1 }
			], { duration: i })), C.finished.then(() => h.remove()).catch(() => {});
		};
		if (!matchMedia("(prefers-reduced-motion: reduce)").matches) for (let t of e) {
			if (!t.kind.startsWith("br")) continue;
			let e = {
				...t.data ?? {},
				...t.secret ?? {}
			}, n = t.rid ?? "";
			if (t.kind === "brUnits") for (let t of e.units ?? []) {
				let n = `unit:${t.id}`, a = i.items.get(n), o = r.get(n), s = c(a), d = c(o), f = d?.clone ?? s?.clone ?? a?.clone ?? o?.clone;
				f && u(s ?? l(e.from ?? "", t.owner, !0), d ?? l(e.to ?? "", t.owner), f, 420, d?.node);
			}
			if (t.kind === "brCards") for (let t = 0; t < (e.count ?? e.cards?.length ?? 0); t++) {
				let a = e.cards?.[t], o = `card:${a}`, s = a ? c(i.items.get(o)) : void 0, d = a ? c(r.get(o)) : void 0, f = e.from ?? "hand", p = e.to ?? "hand", m = s ?? l(f, n, !0), h = d ?? l(p, n);
				if (!s && m && h) {
					let e = m.rect, t = Math.min(96, h.rect.width), n = Math.min(138, h.rect.height);
					m = {
						...m,
						rect: new DOMRect(e.x + (e.width - t) / 2, e.y + (e.height - n) / 2, t, n)
					};
				}
				let g = e.faceDown || !a ? tt() : s?.clone ?? d?.clone ?? tt();
				u(m, h, g, 420, d?.node);
			}
			if (t.kind === "brReveal") for (let t of e.cards ?? []) {
				let e = c(r.get(`card:${t}`)) ?? l("battle", n);
				e && u(e, e, e.clone, 650, e.node, !0);
			}
			if (t.kind === "brPulse") {
				let t = l(e.location || "seat", n);
				t && o.push(t.node.animate([
					{ filter: "brightness(1)" },
					{
						filter: `brightness(${e.kind === "ragnarok" ? 2 : 1.65})`,
						offset: .3
					},
					{ filter: "brightness(1)" }
				], { duration: 650 }));
			}
		}
		return () => {
			o.forEach((e) => e.cancel()), s.forEach((e) => e.remove());
		};
	}, [e]), null;
}
//#endregion
//#region src/games/bloodrage/view-player.tsx
function at(e) {
	return /* @__PURE__ */ p(ot, { ...e }, e.myRid);
}
function ot(e) {
	let t = e.public, n = e.private, l = a(), h = r(null);
	rt(h, e.myRid);
	let [g, y] = i(null), [ee, b] = i(e.myRid), [x, S] = i({
		seq: -1,
		units: []
	}), [C, te] = i({
		ids: [],
		source: ""
	}), [w, ne] = i("hand"), [re, ie] = i(!1), [T, E] = i(!1), [D, O] = i(!1), k = n?.actions ?? [], A = x.seq === t.event.seq ? x : {
		seq: t.event.seq,
		units: []
	}, j = A.card, M = A.units.map((e) => t.figures.find((t) => t.id === e)).filter((e) => !!e), N = t.players.find((e) => e.rid === ee) ?? t.players[0], P = t.players.find((t) => t.rid === e.myRid), F = (t) => e.members.find((e) => e.rid === t)?.name ?? t, I = (n) => o[(e.members.find((e) => e.rid === n)?.colorIndex ?? t.players.findIndex((e) => e.rid === n)) % o.length].hex, L = (t) => {
		e.send(t), S({
			seq: -1,
			units: []
		}), E(!1);
	}, ae = n?.draft.join(",") ?? "", R = C.source === ae ? C.ids : [], z = t.players.length === 2 ? 2 : 1, B = t.prompt?.rid === e.myRid, V = t.phase === "done" ? l("games.bloodrage.done") : k.length === 0 ? l("games.bloodrage.waiting") : t.phase === "draft" ? l("games.bloodrage.draftPrompt", { n: z }) : t.phase === "battle" ? l("games.bloodrage.battlePrompt") : t.phase === "extra" ? l("games.bloodrage.extraPrompt") : t.phase === "reinforce" ? l("games.bloodrage.reinforcePrompt") : t.phase === "discard" ? l("games.bloodrage.discardPrompt") : B ? l(Ue[t.prompt.kind] ?? "games.bloodrage.choosePrompt") : t.phase === "action" ? l("games.bloodrage.actionPrompt") : l("games.bloodrage.settling"), H = M.length === 1 ? k.filter((e) => e.type === "invade" && e.unit === M[0].id) : [], U = M.length && M.every((t) => t.owner === e.myRid && t.location === M[0].location) ? k.filter((e) => e.type === "march" && e.units.includes(M[0].id)) : [], W = [.../* @__PURE__ */ new Set([...H.map((e) => e.to), ...U.map((e) => e.to)])], oe = (n) => {
		O(!1);
		let r = k.find((e) => e.type === "reinforce" && e.unit === n.id);
		if (r) {
			L(r);
			return;
		}
		if (n.owner !== e.myRid) return;
		let i = M.length && M[0].location === n.location && n.location.startsWith("p") ? A.units.includes(n.id) ? A.units.filter((e) => e !== n.id) : [...A.units, n.id] : [n.id];
		S({
			seq: t.event.seq,
			units: i
		});
	}, G = ({ f: e }) => /* @__PURE__ */ m("button", {
		className: "bloodrage-unit",
		"data-selected": A.units.includes(e.id),
		style: { "--bloodrage-player": I(e.owner) },
		onClick: () => oe(e),
		title: `${F(e.owner)} · ${e.card ? l(_[e.card].nameKey) : l(Y[e.kind])}`,
		children: [
			/* @__PURE__ */ p("svg", {
				"data-br-motion": e.location === "reserve" || e.location === "valhalla" ? `unit:${e.id}` : void 0,
				"data-br-place": e.location,
				viewBox: "-25 -25 50 50",
				"aria-hidden": "true",
				children: /* @__PURE__ */ p(Ye, {
					figure: e,
					color: I(e.owner),
					seat: t.players.findIndex((t) => t.rid === e.owner) + 1
				})
			}),
			/* @__PURE__ */ p("span", { children: e.card ? l(_[e.card].nameKey) : l(Y[e.kind]) }),
			/* @__PURE__ */ p("b", { children: Je(t, e) })
		]
	}), se = j ? k.filter((e) => "card" in e && e.card === j) : [], ce = t.phase === "draft" ? n?.draft ?? [] : w === "quests" ? n?.quests ?? [] : w === "upgrades" ? Object.values(N.upgrades) : n?.hand ?? [], le = (e) => {
		S({
			seq: t.event.seq,
			card: e,
			units: []
		}), t.phase === "draft" && k.length && te({
			source: ae,
			ids: R.includes(e) ? R.filter((t) => t !== e) : R.length < z ? [...R, e] : [...R.slice(1), e]
		});
	}, ue = t.figures.filter((e) => e.location === g), de = B && /* @__PURE__ */ m("section", {
		className: "bloodrage-choices",
		children: [/* @__PURE__ */ p("h3", { children: V }), n.choices.map((e) => /* @__PURE__ */ m("button", {
			className: "bloodrage-choice",
			onClick: () => L({
				type: "choose",
				id: e.id
			}),
			children: [
				e.skip ? l("games.bloodrage.skip") : e.label ? l(We[e.label], { n: e.n ?? 0 }) : e.stat === void 0 ? e.card ? l(_[e.card].nameKey) : e.unit ? (() => {
					let n = t.figures.find((t) => t.id === e.unit);
					return n.card ? l(_[n.card].nameKey) : l(Y[n.kind]);
				})() : e.to ? l(J[e.to]) : l("games.bloodrage.confirm") : l(ze[e.stat]),
				e.to && /* @__PURE__ */ p("small", { children: l(J[e.to]) }),
				e.card && /* @__PURE__ */ p("small", { children: l(_[e.card].nameKey) })
			]
		}, e.id))]
	}), fe = /* @__PURE__ */ m(f, { children: [
		de,
		t.questResults.length > 0 && ["settle", "decision"].includes(t.phase) && (() => {
			let e = t.questResults[t.questResults.length - 1];
			return _[e.card].age === t.age ? /* @__PURE__ */ m("section", {
				"data-br-zone": "reveal",
				className: "bloodrage-quest-result",
				children: [
					/* @__PURE__ */ m("strong", { children: [
						F(e.rid),
						" · ",
						l(e.success ? "games.bloodrage.questComplete" : "games.bloodrage.questFailed")
					] }),
					/* @__PURE__ */ p(Qe, {
						id: e.card,
						compact: !0
					}),
					/* @__PURE__ */ m("p", { children: [
						e.glory,
						" ",
						l("games.bloodrage.glory")
					] })
				]
			}) : null;
		})(),
		j && /* @__PURE__ */ m("section", {
			className: "bloodrage-card-detail",
			children: [/* @__PURE__ */ p(Qe, { id: j }), /* @__PURE__ */ m("div", {
				className: "bloodrage-buttons",
				children: [se.map((e, t) => e.type === "upgrade" ? /* @__PURE__ */ m("button", {
					onClick: () => L(e),
					children: [
						l("games.bloodrage.upgrade"),
						" · ",
						e.slot.startsWith("clan") ? l("games.bloodrage.clanSlot", { n: Number(e.slot.slice(-1)) + 1 }) : e.slot.startsWith("monster") ? l("games.bloodrage.monsterSlot", { n: Number(e.slot.slice(-1)) + 1 }) : l(Y[e.slot]),
						P?.upgrades[e.slot] && /* @__PURE__ */ p("small", { children: l(_[P?.upgrades[e.slot]].nameKey) })
					]
				}, t) : e.type === "quest" ? /* @__PURE__ */ p("button", {
					onClick: () => L(e),
					children: l("games.bloodrage.quest")
				}, t) : e.type === "battle" || e.type === "extra" ? /* @__PURE__ */ p("button", {
					onClick: () => L(e),
					children: l("games.bloodrage.battleSubmit")
				}, t) : null), t.phase === "discard" && k.some((e) => e.type === "discard" && e.keep === j) && /* @__PURE__ */ p("button", {
					onClick: () => L({
						type: "discard",
						keep: j
					}),
					children: l("games.bloodrage.confirm")
				})]
			})]
		}),
		M.length > 0 && /* @__PURE__ */ m("section", {
			className: "bloodrage-move",
			children: [
				/* @__PURE__ */ p("h3", { children: l(M[0].location === "reserve" || M[0].location === "valhalla" ? "games.bloodrage.invade" : "games.bloodrage.march") }),
				/* @__PURE__ */ p("p", { children: l("games.bloodrage.chooseDestination") }),
				/* @__PURE__ */ p("div", {
					className: "bloodrage-buttons",
					children: W.map((e) => /* @__PURE__ */ p("button", {
						"data-selected": g === e,
						onClick: () => y(e),
						children: l(J[e])
					}, e))
				}),
				g && H.filter((e) => e.to === g).map((e, n) => /* @__PURE__ */ m("button", {
					className: "bloodrage-primary",
					onClick: () => L(e),
					children: [
						l("games.bloodrage.invade"),
						" · ",
						l(J[e.to]),
						e.replace && /* @__PURE__ */ m("small", { children: [l("games.bloodrage.replace", { name: (() => {
							let n = t.figures.find((t) => t.id === e.replace);
							return `${F(n.owner)} ${n.card ? l(_[n.card].nameKey) : l(Y[n.kind])}`;
						})() }), e.pushTo && ` · ${l("games.bloodrage.push", { name: l(J[e.pushTo]) })}`] })
					]
				}, n)),
				g && U.some((e) => e.to === g) && /* @__PURE__ */ m("button", {
					className: "bloodrage-primary",
					disabled: M.length > (g === "p8" ? 100 : {
						p0: 3,
						p1: 4,
						p2: 5,
						p3: 5,
						p4: 4,
						p5: 3,
						p6: 3,
						p7: 5
					}[g] - ue.length),
					onClick: () => L({
						type: "march",
						units: A.units,
						to: g
					}),
					children: [
						l("games.bloodrage.moveCount", { n: A.units.length }),
						" · ",
						l(J[g])
					]
				}),
				/* @__PURE__ */ p("button", {
					onClick: () => S({
						seq: -1,
						units: []
					}),
					children: l("games.bloodrage.cancel")
				})
			]
		}),
		g && /* @__PURE__ */ m("section", {
			className: "bloodrage-location-detail",
			children: [
				/* @__PURE__ */ p("h3", { children: l(J[g]) }),
				t.destroyed.includes(g) ? /* @__PURE__ */ p("p", { children: l("games.bloodrage.destroyed") }) : /* @__PURE__ */ p("div", {
					className: "bloodrage-strengths",
					children: t.players.map((e) => /* @__PURE__ */ m("span", {
						style: { borderColor: I(e.rid) },
						children: [
							F(e.rid),
							" ",
							/* @__PURE__ */ p("b", { children: X(t, e.rid, g, !0) })
						]
					}, e.rid))
				}),
				t.gods.filter((e) => e.province === g).map((e) => /* @__PURE__ */ m("p", { children: [
					/* @__PURE__ */ p("strong", { children: l(Ve[e.kind]) }),
					" · ",
					l(He[e.kind])
				] }, e.kind)),
				g.startsWith("p") && /* @__PURE__ */ p("p", { children: l(t.pillaged.includes(g) ? "games.bloodrage.pillaged" : Be[t.rewards[Number(g.slice(1))]]) }),
				/* @__PURE__ */ p("div", {
					className: "bloodrage-units",
					children: ue.map((e) => /* @__PURE__ */ p(G, { f: e }, e.id))
				}),
				k.filter((e) => e.type === "pillage" && e.province === g).map((e, t) => /* @__PURE__ */ p("button", {
					className: "bloodrage-primary",
					onClick: () => L(e),
					children: l("games.bloodrage.pillage")
				}, t))
			]
		}),
		!j && !M.length && !g && !B && /* @__PURE__ */ p("p", {
			className: "bloodrage-instruction",
			children: V
		}),
		t.battle && /* @__PURE__ */ m("section", {
			className: "bloodrage-battle",
			children: [/* @__PURE__ */ p("h3", { children: l("games.bloodrage.battleAt", { name: l(J[t.battle.province]) }) }), t.battle.participants.map((r) => /* @__PURE__ */ m("div", {
				className: "bloodrage-combatant",
				"data-br-zone": `battle:${r}`,
				children: [/* @__PURE__ */ m("strong", {
					style: { borderColor: I(r) },
					children: [
						F(r),
						" ",
						t.battle.strengths[r] ?? X(t, r, t.battle.province, !0)
					]
				}), /* @__PURE__ */ m("div", { children: [
					(t.battle.questBoost[r] ?? 0) > 0 && /* @__PURE__ */ p("span", { children: l("games.bloodrage.boostQuest", { n: t.battle.questBoost[r] }) }),
					(t.battle.cards[r] ?? (r === e.myRid ? n?.selected : []) ?? []).map((e) => /* @__PURE__ */ p("div", {
						"data-br-motion": `card:${e}`,
						"data-br-place": "battle",
						children: /* @__PURE__ */ p(Qe, {
							id: e,
							compact: !0
						})
					}, e)),
					!t.battle.cards[r]?.length && !(r === e.myRid && n?.selected.length) && t.battle.picked.includes(r) && /* @__PURE__ */ p("span", {
						className: "bloodrage-card-back",
						children: l("games.bloodrage.pending")
					})
				] })]
			}, r))]
		}),
		k.some((e) => e.type === "reinforce" && e.unit === null) && /* @__PURE__ */ p("button", {
			onClick: () => L({
				type: "reinforce",
				unit: null
			}),
			children: l("games.bloodrage.reinforcePass")
		}),
		k.some((e) => e.type === "extra" && e.card === null) && /* @__PURE__ */ p("button", {
			onClick: () => L({
				type: "extra",
				card: null
			}),
			children: l("games.bloodrage.extraPass")
		}),
		k.some((e) => e.type === "battle" && e.card === null) && /* @__PURE__ */ p("button", {
			onClick: () => L({
				type: "battle",
				card: null
			}),
			children: l("games.bloodrage.noCard")
		}),
		k.some((e) => e.type === "pass") && (T ? /* @__PURE__ */ m("div", {
			className: "bloodrage-pass",
			children: [
				/* @__PURE__ */ p("p", { children: l("games.bloodrage.confirmPass") }),
				/* @__PURE__ */ p("button", {
					onClick: () => L({ type: "pass" }),
					children: l("games.bloodrage.confirm")
				}),
				/* @__PURE__ */ p("button", {
					onClick: () => E(!1),
					children: l("games.bloodrage.cancel")
				})
			]
		}) : /* @__PURE__ */ p("button", {
			className: "bloodrage-pass",
			onClick: () => E(!0),
			children: l("games.bloodrage.pass")
		})),
		k.filter((e) => e.type === "sacrifice").length > 0 && /* @__PURE__ */ m("details", {
			className: "bloodrage-sacrifice",
			children: [/* @__PURE__ */ p("summary", { children: l("games.bloodrage.sacrifice") }), /* @__PURE__ */ p("div", {
				className: "bloodrage-buttons",
				children: k.filter((e) => e.type === "sacrifice").map((e, n) => /* @__PURE__ */ p("button", {
					onClick: () => L(e),
					children: e.units.map((e) => {
						let n = t.figures.find((t) => t.id === e);
						return `${n.card ? l(_[n.card].nameKey) : l(Y[n.kind])} · ${l(J[n.location])}`;
					}).join(" / ")
				}, n))
			})]
		})
	] });
	return /* @__PURE__ */ m("div", {
		ref: h,
		className: "bloodrage-screen",
		children: [
			/* @__PURE__ */ p(u, {
				adaptive: !0,
				scroll: !1,
				className: "bloodrage-shell",
				banner: /* @__PURE__ */ m("div", {
					className: "bloodrage-header",
					children: [/* @__PURE__ */ p("div", {
						className: "bloodrage-phase",
						children: /* @__PURE__ */ p(d, {
							tone: k.length ? "accent" : "info",
							text: V,
							chip: l("games.bloodrage.age", { n: t.age }),
							accent: "#a92526"
						})
					}), /* @__PURE__ */ p("div", {
						className: "bloodrage-players",
						children: t.players.map((e, t) => /* @__PURE__ */ m("button", {
							"data-selected": N.rid === e.rid,
							onClick: () => {
								b(e.rid), O(!0);
							},
							className: "bloodrage-player",
							"data-br-zone": `seat:${e.rid}`,
							style: { "--bloodrage-player": I(e.rid) },
							children: [/* @__PURE__ */ m("strong", { children: [
								t + 1,
								" · ",
								F(e.rid)
							] }), /* @__PURE__ */ m("span", { children: [
								l("games.bloodrage.glory"),
								" ",
								/* @__PURE__ */ p(s, { value: e.glory }),
								" ",
								/* @__PURE__ */ p("img", {
									src: q("rage"),
									alt: l("games.bloodrage.rage")
								}),
								/* @__PURE__ */ p(s, { value: e.rage }),
								e.ready && /* @__PURE__ */ p("small", { children: l("games.bloodrage.pending") })
							] })]
						}, e.rid))
					})]
				}),
				actionsHeight: "bloodrage-hand-slot",
				actions: /* @__PURE__ */ m("div", {
					className: "bloodrage-hand",
					children: [/* @__PURE__ */ m("div", {
						className: "bloodrage-hand-tabs",
						children: [
							/* @__PURE__ */ m("button", {
								"data-br-zone": `hand:${e.myRid}`,
								onClick: () => ne("hand"),
								"data-selected": w === "hand",
								children: [
									l("games.bloodrage.hand"),
									" ",
									n?.hand.length ?? 0
								]
							}),
							/* @__PURE__ */ m("button", {
								onClick: () => ne("quests"),
								"data-selected": w === "quests",
								"data-br-zone": `quests:${e.myRid}`,
								children: [
									l("games.bloodrage.quests"),
									" ",
									n?.quests.length ?? 0
								]
							}),
							/* @__PURE__ */ p("button", {
								onClick: () => ne("upgrades"),
								"data-selected": w === "upgrades",
								children: l("games.bloodrage.upgrades")
							}),
							t.phase === "draft" && k.length > 0 && /* @__PURE__ */ m("button", {
								className: "bloodrage-primary",
								disabled: R.length !== z,
								onClick: () => L({
									type: "draft",
									cards: R
								}),
								children: [
									l("games.bloodrage.draftConfirm"),
									" ",
									R.length,
									"/",
									z
								]
							})
						]
					}), /* @__PURE__ */ p("div", {
						className: "bloodrage-hand-scroll",
						"data-br-zone": t.phase === "draft" ? `draft:${e.myRid}` : void 0,
						children: ce.map((e) => /* @__PURE__ */ p("button", {
							className: "bloodrage-card-button",
							"data-br-motion": `card:${e}`,
							"data-br-place": t.phase === "draft" ? "draft" : w,
							onClick: () => le(e),
							"aria-pressed": t.phase === "draft" ? R.includes(e) : j === e,
							children: /* @__PURE__ */ p(Qe, {
								id: e,
								compact: !0,
								selected: t.phase === "draft" ? R.includes(e) : j === e
							})
						}, e))
					})]
				}),
				children: /* @__PURE__ */ m("div", {
					className: "bloodrage-main",
					children: [
						/* @__PURE__ */ m("aside", {
							className: "bloodrage-clan-panel",
							"data-open": D,
							children: [
								/* @__PURE__ */ p("button", {
									className: "bloodrage-mobile-clan",
									onClick: () => O(!1),
									children: l("games.bloodrage.close")
								}),
								/* @__PURE__ */ p("h2", { children: F(N.rid) }),
								/* @__PURE__ */ p("div", {
									className: "bloodrage-stat-track",
									children: ze.map((e, t) => /* @__PURE__ */ m("div", { children: [
										/* @__PURE__ */ p("img", {
											src: q([
												"rage",
												"axes",
												"horns"
											][t]),
											alt: ""
										}),
										/* @__PURE__ */ p("span", { children: l(e) }),
										/* @__PURE__ */ p("strong", { children: v[t][N.stats[t]] }),
										/* @__PURE__ */ p("small", { children: l("games.bloodrage.statLevel", { n: N.stats[t] + 1 }) })
									] }, e))
								}),
								/* @__PURE__ */ p("p", { children: l("games.bloodrage.cardsCount", {
									n: N.handCount,
									quests: N.questCount
								}) }),
								/* @__PURE__ */ p("h3", { children: l("games.bloodrage.reserve") }),
								/* @__PURE__ */ p("div", {
									className: "bloodrage-units",
									"data-br-zone": `reserve:${N.rid}`,
									children: t.figures.filter((e) => e.owner === N.rid && e.location === "reserve").map((e) => /* @__PURE__ */ p(G, { f: e }, e.id))
								}),
								/* @__PURE__ */ p("p", { children: l("games.bloodrage.figures", {
									n: t.figures.filter((e) => e.owner === N.rid && (e.location.startsWith("p") || e.location.startsWith("f"))).length,
									total: v[2][N.stats[2]]
								}) }),
								/* @__PURE__ */ p("h3", { children: l("games.bloodrage.upgrades") }),
								/* @__PURE__ */ p("div", {
									className: "bloodrage-upgrade-list",
									"data-br-zone": `upgrade:${N.rid}`,
									children: Object.entries(N.upgrades).map(([e, n]) => /* @__PURE__ */ m("button", {
										"data-br-motion": `card:${n}`,
										"data-br-place": "upgrade",
										onClick: () => S({
											seq: t.event.seq,
											card: n,
											units: []
										}),
										children: [/* @__PURE__ */ p("span", { children: l(_[n].nameKey) }), /* @__PURE__ */ p("small", { children: l(Y[_[n].kind]) })]
									}, e))
								}),
								/* @__PURE__ */ p("h3", { children: l("games.bloodrage.valhalla") }),
								/* @__PURE__ */ p("div", {
									className: "bloodrage-units",
									"data-br-zone": "valhalla",
									children: t.figures.filter((e) => e.location === "valhalla").map((e) => /* @__PURE__ */ p(G, { f: e }, e.id))
								}),
								/* @__PURE__ */ p("button", {
									onClick: () => ie(!0),
									children: l("games.bloodrage.log")
								})
							]
						}),
						/* @__PURE__ */ p(Ze, {
							pub: t,
							selected: g,
							targets: W,
							onSelect: y,
							color: I,
							nameOf: F,
							onFigureSelect: oe
						}),
						/* @__PURE__ */ m("aside", {
							className: "bloodrage-detail",
							children: [/* @__PURE__ */ m("div", {
								className: "bloodrage-detail-nav",
								children: [/* @__PURE__ */ p("button", {
									className: "bloodrage-mobile-clan",
									onClick: () => {
										b(e.myRid), O(!0);
									},
									children: l("games.bloodrage.reserve")
								}), /* @__PURE__ */ m("select", {
									"aria-label": l("games.bloodrage.chooseDestination"),
									value: g ?? "",
									onChange: (e) => y(e.target.value || null),
									children: [/* @__PURE__ */ p("option", {
										value: "",
										children: l("games.bloodrage.chooseDestination")
									}), Object.entries(J).filter(([e]) => e.startsWith("p") || e.startsWith("f")).map(([e, t]) => /* @__PURE__ */ p("option", {
										value: e,
										children: l(t)
									}, e))]
								})]
							}), fe]
						})
					]
				})
			}),
			re && /* @__PURE__ */ p("div", {
				className: "bloodrage-modal",
				children: /* @__PURE__ */ m("div", {
					className: "bloodrage-modal-panel",
					children: [/* @__PURE__ */ m("div", {
						className: "bloodrage-modal-title",
						children: [/* @__PURE__ */ p("h2", { children: l("games.bloodrage.log") }), /* @__PURE__ */ p("button", {
							"aria-label": l("games.bloodrage.close"),
							onClick: () => ie(!1),
							children: /* @__PURE__ */ p(c, { size: 24 })
						})]
					}), /* @__PURE__ */ p("ol", { children: t.log.map((e, t) => /* @__PURE__ */ m("li", { children: [l(Ge[e.kind], {
						name: F(e.rid),
						place: J[e.location] ? l(J[e.location]) : "",
						n: e.amount
					}), e.card && ` · ${l(_[e.card].nameKey)}`] }, t)) })]
				})
			}),
			P && /* @__PURE__ */ p("span", {
				className: "bloodrage-deck-anchor",
				"data-br-motion": "deck",
				"aria-hidden": !0
			})
		]
	});
}
//#endregion
//#region src/games/bloodrage/bot.ts
var st = {
	quest: 1,
	upgrade: 1,
	control: 1,
	rage: 1,
	battle: 1,
	doom: 1
}, Z = (e, t, n) => Object.values(e.players.find((e) => e.rid === t).upgrades).filter((e) => _[e].effect === n).length;
function ct(e, t, n) {
	let r = e.players.find((e) => e.rid === t).stats[n];
	return r >= 5 ? 0 : (r === 2 || r === 4 ? 10 : r === 3 ? 0 : 2) + [
		3,
		2.3,
		1.6
	][n] * (4 - e.age);
}
function Q(e, t, n, r) {
	let i = _[r], a = e.players.find((e) => e.rid === n), o = i.effect;
	return i.kind === "quest" ? 2 + i.glory * .5 + (lt(e, n, r) ? i.glory * .5 + 3 : 0) : i.kind === "battle" ? 1 + i.strength * .7 + ({
		poison: 2,
		backstab: 1,
		trickery: 2,
		sight: 3,
		hammer: 2,
		ascension: 4,
		watch: 2,
		primacy: 2,
		odinJudgement: 3,
		tide: 1
	}[o] ?? 0) : i.kind === "monster" ? 3 + i.strength + ([
		"dwarf",
		"hel",
		"ymir",
		"elf",
		"frost"
	].includes(o) ? 4 : 0) : i.kind === "warrior" ? 3 + (o === "masters" ? 7 : o === "experts" ? 6 : 3) : i.kind === "leader" ? 5 + (o === "leader3" ? 7 : o === "leader2" ? 4 : 0) : i.kind === "ship" ? 4 + Number(o.slice(-1)) * 3 + (Z(e, n, "loki3") + Z(e, n, "loki2") + Z(e, n, "loki1")) : ({
		loki1: 8,
		loki2: 11,
		loki3: 13,
		succor: 9,
		charm: 7,
		blessing: 6,
		protection: 5,
		friggaDomain: 7,
		conquest: 3 * e.figures.filter((e) => e.owner === n && (e.location.startsWith("p") || e.location.startsWith("f"))).length,
		chosen1: 5,
		chosen2: 6,
		chosen3: 8,
		thorGlory: 5,
		throne: t.quests.length * 5 + 3,
		inspiration: 3,
		tyrDomain: 4,
		tyrWrath: 5,
		thorDomain: 5,
		prowess: 5,
		challenge: 5,
		sacrifice: 5
	}[o] ?? 4) * (i.age === e.age ? 1 : .95) + (a.rage === 0 ? 0 : 1);
}
function lt(e, t, n) {
	let r = _[n].effect;
	if (r === "death") return e.figures.filter((e) => e.owner === t && e.location === "valhalla").length >= 4;
	let i = y.filter((n) => !e.destroyed.includes(n.id) && X(e, t, n.id) > Math.max(0, ...e.players.filter((e) => e.rid !== t).map((t) => X(e, t.rid, n.id))));
	return r === "widespread" ? i.length >= 2 : i.some((e) => e.region === r);
}
function $(e, t, n, r, i = X(e, n, r)) {
	if (e.destroyed.includes(r)) return -3;
	let a = i - Math.max(0, ...e.players.filter((e) => e.rid !== n).map((t) => X(e, t.rid, r))), o = i === 0 ? 0 : a > 0 ? 1 : a === 0 ? .2 : .05, s = Number(r.slice(1)), c = e.rewards[s], l = c === "all" ? [
		0,
		1,
		2
	].reduce((t, r) => t + ct(e, n, r), 0) : c === "glory" ? 5 : ct(e, n, [
		"rage",
		"axes",
		"horns"
	].indexOf(c));
	return o * (t.quests.filter((e) => {
		let t = _[e].effect;
		return t === "widespread" || y.find((e) => e.id === r)?.region === t;
	}).reduce((e, t) => e + _[t].glory * .6 + 2, 0) + (e.pillaged.includes(r) ? 1 : l * .6 + 3)) + Math.min(3, i) * .2;
}
function ut(e, t, n, r, i) {
	let a = X(e, n, r, !0) + i, o = /* @__PURE__ */ new Set([
		...t.hand,
		...t.quests,
		...Object.values(e.players.find((e) => e.rid === n).upgrades)
	]), s = g.filter((t) => t.age <= e.age && t.minPlayers <= e.players.length && !o.has(t.id)), c = 1, l = y.find((e) => e.id === r);
	for (let t of e.players.filter((t) => t.rid !== n && e.figures.some((e) => e.owner === t.rid && (e.location === r || l.fjord >= 0 && e.location === `f${l.fjord}`)))) {
		let n = X(e, t.rid, r, !0), i = e.battle?.cards[t.rid];
		if (i?.length) {
			c *= +(a > n + i.reduce((e, t) => e + _[t].strength, 0));
			continue;
		}
		if (t.handCount === 0) {
			c *= +(a > n);
			continue;
		}
		let o = s.map((n) => n.kind === "battle" ? n.strength : n.kind === "quest" ? Z(e, t.rid, "tyrWrath") ? 5 : Z(e, t.rid, "tyrDomain") ? 3 : 0 : 0);
		c *= o.filter((e) => a > n + e).length / Math.max(1, o.length);
	}
	return c;
}
function dt(e, t, n, r = st) {
	let i = e.public, a = e.private, o = i.players.find((e) => e.rid === t), s = i.figures.filter((e) => e.owner === t && (e.location.startsWith("p") || e.location.startsWith("f"))), c = (e) => s.filter((t) => t.location === e).length * (Z(i, t, "loki1") + 2 * Z(i, t, "loki2") + 3 * Z(i, t, "loki3"));
	if (n.type === "draft") return n.cards.reduce((e, n) => e + Q(i, a, t, n), 0);
	if (n.type === "discard") return n.keep ? Q(i, a, t, n.keep) : 0;
	if (n.type === "battle" || n.type === "extra") {
		if (!n.card) return n.type === "extra" ? 0 : -1;
		let e = _[n.card], l = i.battle.province, u = ut(i, a, t, l, (e.effect === "sight" ? 5 : e.kind === "battle" ? e.strength : e.kind === "quest" ? Z(i, t, "tyrWrath") ? 5 : Z(i, t, "tyrDomain") ? 3 : 0 : 0) + (n.type === "extra" ? (i.battle.cards[t] ?? []).reduce((e, t) => e + _[t].strength, 0) : 0)), d = v[1][o.stats[1]] + (i.battle.pillager === t ? $(i, a, t, l) * 1.5 : 0) + s.filter((e) => e.location === l).length * 1.2, f = {
			hammer: 3,
			ascension: 6,
			oath: 6
		}[e.effect] ?? 0, p = {
			trickery: 2,
			backstab: 2,
			poison: 4
		}[e.effect] ?? 0, m = u * (d + f) + (1 - u) * (p + c(l));
		return r.battle * m - Q(i, a, t, n.card) * u * .35 - (n.type === "extra");
	}
	if (n.type === "quest") return r.quest * (lt(i, t, n.card) ? _[n.card].glory + 5 : 1.2);
	if (n.type === "upgrade") {
		let e = _[n.card], s = [
			"dwarf",
			"hel",
			"ymir"
		].includes(e.effect) ? 0 : Math.max(0, e.strength - Z(i, t, "charm")), c = o.upgrades[n.slot], l = c && _[c].effect === e.effect;
		return r.upgrade * (Q(i, a, t, n.card) - (c ? Q(i, a, t, c) * .7 : 0)) * (l ? .3 : 1) - s * r.rage + (e.kind === "clan" ? 0 : 2);
	}
	if (n.type === "pillage") {
		let e = Math.max(0, ...a.hand.map((e) => {
			let n = _[e];
			return n.effect === "sight" ? 4 : n.kind === "battle" ? n.strength : n.kind === "quest" ? Z(i, t, "tyrWrath") ? 5 : Z(i, t, "tyrDomain") ? 3 : 0 : 0;
		})), r = ut(i, a, t, n.province, e), l = y.find((e) => e.id === n.province), u = s.filter((e) => e.location === n.province || l.fjord >= 0 && e.location === `f${l.fjord}`).length, d = i.gods.some((e) => e.kind === "frigga" && e.province === n.province);
		return r * ($(i, a, t, n.province) * 1.6 + v[1][o.stats[1]]) - (1 - r) * (1 + (d ? 0 : u)) + (d ? 0 : (1 - r) * c(n.province)) - (i.pillaged.includes(n.province) ? 2 : 0);
	}
	if (n.type === "invade") {
		let e = i.figures.find((e) => e.id === n.unit), o = e.card ? _[e.card] : null, s = e.kind === "leader" ? 3 : e.kind === "warrior" ? Z(i, t, "experts") ? 2 : 1 : o?.strength ?? 2, l = n.fromValhalla ? 1 : e.kind === "leader" || e.kind === "mystic" || o && [
			"dwarf",
			"hel",
			"ymir",
			"mountain"
		].includes(o.effect) ? 0 : s, u = (n.to.startsWith("f") ? y.filter((e) => `f${e.fjord}` === n.to).map((e) => e.id) : [n.to]).reduce((e, n) => e + $(i, a, t, n, X(i, t, n) + s) - $(i, a, t, n), 0), d = i.doom[i.age - 1] === n.to ? Math.max(0, 2 - (i.age + 1 + c(n.to)) * .15) : 0;
		return r.control * u + 1.4 - l * r.rage * .7 - d * r.doom + +!!n.replace + +!!n.fromValhalla;
	}
	if (n.type === "march") {
		let e = i.figures.find((e) => e.id === n.units[0]).location, o = i.figures.filter((e) => n.units.includes(e.id)).reduce((e, t) => e + (t.kind === "leader" ? 3 : t.kind === "warrior" ? 1 : t.card ? _[t.card].strength : 2), 0), s = $(i, a, t, e) + $(i, a, t, n.to);
		return ($(i, a, t, e, Math.max(0, X(i, t, e) - o)) + $(i, a, t, n.to, X(i, t, n.to) + o) - s) * r.control - r.rage * .8 + (i.doom[i.age - 1] === e ? .6 : 0);
	}
	if (n.type === "reinforce") {
		if (!n.unit) return 0;
		let e = i.figures.find((e) => e.id === n.unit), r = i.battle.province, o = e.kind === "leader" ? 3 : e.kind === "warrior" ? 1 : e.card ? _[e.card].strength : 2;
		return $(i, a, t, r, X(i, t, r) + o) - $(i, a, t, e.location) + ut(i, a, t, r, o + 2) * 4 - 1;
	}
	if (n.type === "choose") {
		let e = a.choices.find((e) => e.id === n.id);
		if (e.stat !== void 0) return ct(i, t, e.stat);
		if (e.skip) return 0;
		if (e.label === "boost") return e.n ?? 0;
		if (e.label === "protect") return i.phase === "decision" && o.rage > 1 ? 2 : -1;
		if (e.label === "destroy") return -1;
		if (e.label === "retreat") return 3;
		if (e.label === "keep") return Q(i, a, t, e.card) * .4 - 1;
		if (e.label === "discard") return 0;
		if (e.to) return e.to.startsWith("p") ? $(i, a, t, e.to, X(i, t, e.to) + 2) + 1 : 2;
		if (e.unit) {
			let t = i.figures.find((t) => t.id === e.unit);
			return t.kind === "leader" ? 3 : t.card ? _[t.card].strength : 1;
		}
		return 0;
	}
	return n.type === "sacrifice" ? Math.max(...[
		0,
		1,
		2
	].map((e) => ct(i, t, e))) - 4 + (Z(i, t, "loki3") * 3 + Z(i, t, "loki2") * 2 + Z(i, t, "loki1")) * 2 : n.type === "pass" ? -.2 : 0;
}
function ft(e) {
	let t = Math.floor(2 ** 32 / e.length) * e.length, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return e[n[0] % e.length];
}
function pt(e = st) {
	return (t, n) => {
		let r = t.private?.actions ?? [];
		if (!r.length) return null;
		let i = t.public, a = JSON.stringify([
			i.age,
			i.figures,
			i.players.map((e) => [
				e.rid,
				e.rage,
				e.stats,
				e.upgrades,
				e.handCount
			]),
			t.private.hand,
			i.pillaged,
			i.gods
		]), o = n.memory, s = r.map((r) => ({
			action: r,
			value: r.type === "pillage" && o?.pillage === r.province && o.signature === a ? -1e3 : dt(t, n.rid, r, e)
		})).sort((e, t) => t.value - e.value), c = n.difficulty === "weak" ? ft(s.slice(0, Math.max(1, Math.ceil(s.length * .6)))).action : s[0].action;
		return {
			action: c,
			memory: c.type === "pillage" ? {
				pillage: c.province,
				signature: a
			} : o
		};
	};
}
var mt = pt(), ht = (e, t, n) => e.type === "draft" ? `${n("games.bloodrage.draftConfirm")}: ${e.cards.map((e) => n(_[e].nameKey)).join(" / ")}` : e.type === "pillage" ? `${n("games.bloodrage.pillage")} · ${n(J[e.province])}` : e.type === "invade" || e.type === "march" ? `${n(e.type === "invade" ? "games.bloodrage.invade" : "games.bloodrage.march")} · ${n(J[e.to])}` : "card" in e && e.card ? n(_[e.card].nameKey) : e.type === "pass" ? n("games.bloodrage.pass") : e.type === "reinforce" ? n(e.unit ? "games.bloodrage.reinforcePrompt" : "games.bloodrage.reinforcePass") : e.type === "extra" ? n("games.bloodrage.extraPass") : e.type === "discard" ? e.keep ? n(_[e.keep].nameKey) : n("games.bloodrage.discard") : e.type === "sacrifice" ? n("games.bloodrage.sacrifice") : n("games.bloodrage.choosePrompt"), gt = Object.fromEntries([
	"brUnits",
	"brCards",
	"brReveal",
	"brPulse"
].map((e) => [e, (t) => ({
	ms: e === "brReveal" || e === "brPulse" ? 650 : 420,
	node: /* @__PURE__ */ p(it, { entries: [t] })
})]));
//#endregion
//#region src/games/bloodrage/game-over.tsx
function _t(e) {
	let t = a(), n = e.public, [r, o] = i(!0), [s, u] = i(null), d = (t) => e.members.find((e) => e.rid === t)?.name ?? t;
	return /* @__PURE__ */ m("div", {
		className: "bloodrage-ending",
		children: [
			/* @__PURE__ */ p("div", {
				className: "bloodrage-ending-board",
				inert: r,
				children: /* @__PURE__ */ p(at, {
					public: e.public,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "bloodrage-ending-overlay",
				hidden: !r,
				children: /* @__PURE__ */ m("section", {
					className: "bloodrage-ending-panel",
					role: "dialog",
					"aria-label": t("games.bloodrage.score"),
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), o(!1));
					},
					children: [
						/* @__PURE__ */ m("header", {
							className: "bloodrage-ending-header",
							children: [/* @__PURE__ */ m("h1", { children: [
								t("games.bloodrage.name"),
								" · ",
								t("games.bloodrage.score")
							] }), /* @__PURE__ */ p("button", {
								"aria-label": t("games.bloodrage.reviewBoard"),
								onClick: () => o(!1),
								children: /* @__PURE__ */ p(c, { size: 22 })
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "bloodrage-ending-body",
							children: [
								/* @__PURE__ */ m("div", {
									className: "bloodrage-ending-winner",
									children: [
										t(e.result.winner.length > 1 ? "games.bloodrage.tie" : "games.bloodrage.winner"),
										/* @__PURE__ */ p("br", {}),
										e.result.winner.map(d).join(" · ")
									]
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ p("p", {
									className: "bloodrage-ending-hints",
									children: t("session.hint.usedCount", { n: e.hintCount })
								}),
								/* @__PURE__ */ p("div", {
									className: "bloodrage-score-scroll",
									children: /* @__PURE__ */ m("table", {
										className: "bloodrage-score-table",
										children: [
											/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
												scope: "col",
												children: t("games.bloodrage.glory")
											}), e.result.ranking.map((n) => /* @__PURE__ */ m("th", {
												scope: "col",
												"data-winner": e.result.winner.includes(n),
												children: [
													d(n),
													n === e.myRid && /* @__PURE__ */ m("small", { children: [" · ", t("lobby.you")] }),
													!!e.result.autopilot?.[n] && /* @__PURE__ */ p("p", { children: t("session.autopilot.share", { n: Math.round(e.result.autopilot[n] * 100) }) })
												]
											}, n))] }) }),
											/* @__PURE__ */ p("tbody", { children: [
												{
													key: "games.bloodrage.duringGame",
													value: (e) => {
														let t = n.players.find((t) => t.rid === e);
														return t.glory - t.finalStats - t.finalConquest;
													}
												},
												{
													key: "games.bloodrage.finalStats",
													value: (e) => n.players.find((t) => t.rid === e).finalStats
												},
												{
													key: "games.bloodrage.finalConquest",
													value: (e) => n.players.find((t) => t.rid === e).finalConquest
												}
											].map((n) => /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
												scope: "row",
												children: t(n.key)
											}), e.result.ranking.map((t) => /* @__PURE__ */ p("td", {
												"data-winner": e.result.winner.includes(t),
												children: n.value(t)
											}, t))] }, n.key)) }),
											/* @__PURE__ */ p("tfoot", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", {
												scope: "row",
												children: t("games.bloodrage.total")
											}), e.result.ranking.map((t) => /* @__PURE__ */ p("td", {
												"data-winner": e.result.winner.includes(t),
												children: e.result.scores?.[t] ?? n.players.find((e) => e.rid === t).glory
											}, t))] }) })
										]
									})
								})
							]
						}),
						/* @__PURE__ */ m("footer", {
							className: "bloodrage-ending-actions",
							children: [s ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("button", {
								className: "bloodrage-primary",
								onClick: () => {
									let t = s;
									u(null), t === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.();
								},
								children: [
									t("games.bloodrage.confirm"),
									" · ",
									t(s === "again" ? "session.result.playAgain" : "session.result.backToLobby")
								]
							}), /* @__PURE__ */ p("button", {
								onClick: () => u(null),
								children: t("games.bloodrage.cancel")
							})] }) : /* @__PURE__ */ m(f, { children: [
								e.onPlayAgain && /* @__PURE__ */ p("button", {
									className: "bloodrage-primary",
									onClick: () => u("again"),
									children: t("session.result.playAgain")
								}),
								e.onBackToLobby && /* @__PURE__ */ p("button", {
									onClick: () => u("lobby"),
									children: t("session.result.backToLobby")
								}),
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ p("p", { children: t("session.result.waitHost") })
							] }), /* @__PURE__ */ m("button", {
								onClick: () => o(!1),
								children: [/* @__PURE__ */ p(l, { size: 18 }), t("games.bloodrage.reviewBoard")]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "bloodrage-ending-toolbar",
				hidden: r,
				children: /* @__PURE__ */ p("button", {
					onClick: () => o(!0),
					children: t("games.bloodrage.showResults")
				})
			})
		]
	});
}
//#endregion
//#region src/games/bloodrage/options.tsx
var vt = [
	["fifthPlayer", "games.bloodrage.fifthPlayer"],
	["mystics", "games.bloodrage.mystics"],
	["gods", "games.bloodrage.gods"],
	["monsters", "games.bloodrage.monsters"]
];
function yt({ value: e, onChange: t }) {
	let n = a(), r = x.safeParse(e), i = r.success ? r.data : x.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-3",
		children: [vt.map(([e, r]) => /* @__PURE__ */ m("label", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ p("input", {
				type: "checkbox",
				checked: i[e],
				onChange: (n) => t({
					...i,
					[e]: n.target.checked
				})
			}), n(r)]
		}, e)), /* @__PURE__ */ p("p", {
			className: "text-sm",
			children: n("games.bloodrage.expansionNote")
		})]
	});
}
//#endregion
//#region src/games/bloodrage/guide.tsx
function bt() {
	return /* @__PURE__ */ p("article", {
		className: "bloodrage-guide",
		children: /* @__PURE__ */ p("img", {
			src: q("board"),
			alt: ""
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/bloodrage/entry.tsx
var xt = {
	definition: Re,
	View: at,
	bot: mt,
	describe: ht,
	fx: gt,
	OverView: _t,
	Options: yt,
	Guide: bt,
	locales: {
		zh: {
			name: "血色狂怒",
			desc: "在诸神黄昏前率领维京氏族，轮抽神赐、争夺九省，赢取荣耀。",
			errAction: "此行动当前无法执行。请重新选择。",
			p0: "米尔库洛尔",
			p1: "埃尔瓦加尔",
			p2: "安格尔博达",
			p3: "穆斯贝尔海姆",
			p4: "霍尔格",
			p5: "乌特加尔德",
			p6: "安德朗",
			p7: "吉姆雷",
			p8: "世界树",
			f0: "西北峡湾",
			f1: "东北峡湾",
			f2: "东南峡湾",
			f3: "西南峡湾",
			rage: "怒气",
			axes: "战斧",
			horns: "号角",
			glory: "荣耀",
			strength: "战力",
			cost: "怒气费用",
			baseCost: "基础升级费用",
			figureCardValue: "战力{{strength}}；基础升级费用{{cost}}怒气",
			age: "第{{n}}时代",
			all: "全部属性",
			warrior: "战士",
			leader: "领袖",
			ship: "龙船",
			mystic: "秘术师",
			monster: "怪物",
			clan: "氏族升级",
			battleCard: "战斗牌",
			questCard: "任务牌",
			draftPrompt: "选择{{n}}张牌",
			actionPrompt: "选择棋子、手牌或要掠夺的省份",
			reinforcePrompt: "选择相邻省份中的棋子增援，或放弃本次增援",
			battlePrompt: "选择一张手牌参战",
			extraPrompt: "追加海姆达尔牌，或结束追加",
			discardPrompt: "选择一张手牌保留至下一时代",
			waiting: "等待其他氏族",
			settling: "结算中",
			choosePrompt: "选择效果",
			done: "诸神黄昏已至",
			draftConfirm: "收下所选牌",
			invade: "入侵",
			march: "行军",
			upgrade: "升级",
			quest: "秘密承诺任务",
			pillage: "掠夺",
			pass: "结束本时代行动",
			confirmPass: "结束行动后，剩余怒气归零。",
			cancel: "取消",
			confirm: "确认",
			skip: "跳过",
			reinforcePass: "放弃本次增援",
			extraPass: "结束追加",
			battleSubmit: "打出此牌",
			noCard: "无牌参战",
			hand: "手牌",
			reserve: "预备区",
			valhalla: "英灵殿",
			upgrades: "已装备升级",
			quests: "秘密任务",
			destroyed: "已毁灭",
			pillaged: "已掠夺",
			doom: "第{{n}}时代毁灭",
			villages: "村庄 {{n}}/{{total}}",
			figures: "版图单位 {{n}}/{{total}}",
			empty: "空置",
			selected: "已选",
			back: "返回",
			details: "详情",
			log: "战报",
			close: "关闭",
			chooseDestination: "选择目标省份",
			chooseFigure: "选择棋子",
			chooseSlot: "选择替换的升级槽",
			clanSlot: "氏族槽{{n}}",
			monsterSlot: "怪物槽{{n}}",
			sacrifice: "献祭两个己方单位",
			destroy: "摧毁此单位",
			protect: "支付1怒气保护",
			retreat: "撤退",
			keep: "支付1怒气收回",
			discard: "弃牌",
			survivor: "选择保留的单位",
			freeInvade: "选择免费入侵的单位与省份",
			succor: "额外入侵一名战士",
			blessing: "向战场免费入侵一名战士",
			domainPillage: "支付2怒气立即掠夺",
			statPrompt: "提升一项氏族属性",
			godMove: "移动神祇",
			leaderMove: "移动领袖",
			death: "选择如何处置将被摧毁的单位",
			thor: "索尔",
			frigga: "弗丽嘉",
			tyr: "提尔",
			odin: "奥丁",
			loki: "洛基",
			heimdall: "海姆达尔",
			god_thor: "赢得战斗时，每个在该战斗中被摧毁的敌方单位额外带来2荣耀。",
			god_frigga: "该省份及支援峡湾中的单位，在战斗期间不会被摧毁。",
			god_tyr: "战斗中所有单位的战力为0，只计算卡牌战力。",
			god_odin: "该省份的掠夺奖励翻倍。",
			god_loki: "战斗荣耀改由所有输家获得；卡牌额外奖励仍归赢家。",
			god_heimdall: "依次明牌，掠夺者最后出牌。",
			fifthPlayer: "第五人扩展",
			mystics: "米德加尔特秘术师",
			gods: "阿斯加德诸神",
			monsters: "官方追加怪物",
			expansionNote: "扩展默认关闭。开启第五人扩展后最多5人。",
			score: "荣耀榜",
			winner: "获胜氏族",
			tie: "并列获胜",
			duringGame: "时代中获得",
			finalStats: "氏族属性奖励",
			finalConquest: "索尔的征服",
			total: "总荣耀",
			reviewBoard: "回看版图",
			showResults: "查看结算",
			ageGlory: "诸神黄昏：每个单位{{n}}荣耀",
			cardsCount: "手牌{{n}}张 · 任务{{quests}}张",
			noActions: "本阶段没有需要你执行的行动。",
			battleAt: "{{name}}之战",
			pending: "已提交",
			replace: "替换 {{name}}",
			push: "推至 {{name}}",
			moveCount: "行军{{n}}个单位",
			statLevel: "第{{n}}格",
			resultSuccess: "任务完成",
			resultFail: "任务未完成",
			log_invade: "{{name}}入侵{{place}}",
			log_march: "{{name}}行军至{{place}}",
			log_pillage: "{{name}}成功掠夺{{place}}",
			log_battle: "{{place}}战斗结束，最高战力{{n}}",
			log_destroy: "{{name}}的单位进入英灵殿",
			log_ragnarok: "诸神黄昏摧毁{{place}}",
			log_questSuccess: "{{name}}完成任务，获得{{n}}荣耀",
			log_questFail: "{{name}}的任务未完成",
			log_age: "第{{n}}时代开始",
			log_upgrade: "{{name}}装备升级",
			log_release: "{{name}}的单位从英灵殿归来",
			log_final: "第三时代结束，结算最终荣耀",
			rules: "【目标与准备】：\n经过三个时代，总荣耀最高的氏族获胜，同分共同获胜。每族初始有8名战士、1名领袖和1艘龙船；怒气、战斧和号角的初始属性值分别为6、3和4。开局随机毁灭的外省数量根据人数决定：\n· 两人对局毁灭3个外省。\n· 三人对局毁灭2个外省。\n· 四人对局毁灭1个外省。\n· 五人对局不预先毁灭外省。\n版图标出三个时代的诸神黄昏目标。外省随机分配3枚怒气、2枚战斧、2枚号角和1枚提供5点荣耀的掠夺奖励标记；世界树奖励提升全部属性。\n【轮抽】：\n每时代发8张牌。3至5人每轮选1张，其余传给左邻，选满6张后弃掉余牌。2人每轮选2张，共选三次。上一时代保留的牌不参与轮抽。\n【行动】：\n从起始氏族依次行动，每次选择一项：入侵、行军、升级、承诺任务或掠夺。结束行动会将剩余怒气归零。怒气为0时不能主动行动，仍能增援、参战或发动允许的效果；恢复怒气后可以再次行动。所有人怒气为0，或全部未毁省份都已被掠夺，立即结束时代。\n【入侵与行军】：\n入侵需要支付与单位战力相等的怒气；领袖可以免费入侵，战士通常需要支付1点怒气，船需要支付2点怒气。不能超过号角的版图单位上限，非船单位必须占据空村庄，通常不能直接入侵世界树。船只能入侵峡湾，并支援两侧省份。行军需要支付1点怒气，将同一省份任意数量的己方非船单位移至任意另一未毁省份，不要求相邻，目的地必须容纳所有单位。\n【升级与任务】：\n升级需要支付牌面所示的怒气，将升级牌放入对应槽位，并替换原有卡牌。氏族升级共有3个槽位，怪物共有2个槽位，战士、领袖和船各有1个槽位。打出单位升级后，可立即让一个对应单位免费入侵。任务不消耗怒气，秘密放置，直到时代末才检查；同名任务可分别完成。牌面详细效果优先于通则。\n【掠夺与增援】：\n选择有己方单位或己方支援船、未被掠夺的省份，掠夺本身不消耗怒气。从掠夺者左邻起，各氏族轮流可将一个相邻陆地单位移入战场，或放弃。直到村庄已满，或所有氏族连续放弃；之前放弃的氏族仍可在后来再次增援。只有一个氏族参战时直接获得掠夺奖励。\n【战斗】：\n各参战氏族同时暗选一张手牌，无手牌时不出牌；非战斗牌通常提供0点战力。揭牌后可以轮流追加海姆达尔之视、之眼、凝视，直到所有人连续放弃。先处理索尔的威权，再处理海姆达尔的守望，再处理其他牌。单位与卡牌战力之和最高且唯一的氏族获胜；最高同分则全部失败。输家单位被摧毁，卡牌收回；赢家弃掉揭示牌并获得当前战斧数的荣耀。只有掠夺者获胜才获得掠夺奖励，先提升奖励属性，再计算战斗荣耀。被卡牌提前消灭全部单位的氏族仍使用卡牌战力参战。船和海蛇计入支援省份战力，世界树没有支援峡湾。\n【时代末】：\n前两时代弃至最多1张手牌，第三时代弃掉全部。逐张检查秘密任务：完成则获得牌面荣耀并任选一项氏族属性提升1格。控制要求在相应省份独占最高战力，平局不算控制；光荣赴死要求英灵殿中至少4个己方单位。随后诸神黄昏摧毁目标省份及支援峡湾中的单位，每个死亡单位在第一、第二和第三时代分别带来2、3和4点荣耀。英灵殿所有单位回到预备区，版图幸存单位留下；起始标记传左，重置掠夺标记，并开始下一时代。\n【终局】：\n第三时代结算后，三项氏族属性各按最终位置奖励荣耀：第4或第5格获得10点荣耀，第6格获得20点荣耀，每项只奖励一次。加上适用卡牌终局奖励后比较总荣耀。\n【可选扩展】：\n第五人扩展增加各时代9张牌并允许5人。秘术师升级增加1名具有2点战力且可以免费入侵的秘术师，最多拥有2名，且仍计入号角规定的单位上限；同名选民能力不重复生效。诸神扩展开局随机两位神，每时代重新放置；影响所在省份及支援峡湾，掠夺后由掠夺者移动至不同、未毁、未掠夺且无神的省份。\n· 索尔增加杀敌荣耀。\n· 弗丽嘉禁止战中死亡。\n· 提尔令单位战力为0。\n· 奥丁令掠夺奖励翻倍。\n· 洛基令输家获得战斗荣耀。\n· 海姆达尔要求依次明牌、掠夺者最后。\n追加怪物可独立开启，效果见牌面。弗丽嘉的选民秘术师参战时禁止打出洛基的背刺。",
			questComplete: "任务完成",
			questFailed: "任务未完成",
			questBattle: "是否将任务牌作为战斗牌？",
			boostQuest: "战力增加{{n}}",
			card_chosen1: "弗丽嘉的选民",
			text_chosen1: "获得1名秘术师。你的秘术师被摧毁时，可以改为撤退到相邻的外省。",
			card_chosen2: "奥丁的选民",
			text_chosen2: "获得1名秘术师。你的秘术师可以入侵已有战士或秘术师的村庄，并摧毁原单位。",
			card_chosen3: "索尔的选民",
			text_chosen3: "获得1名秘术师。你赢得战斗时，每名参战的己方秘术师使你获得3荣耀。",
			card_thorGlory: "索尔的荣耀",
			text_thorGlory: "你参与的战斗中，若至少2个敌方单位被摧毁，获得2荣耀。",
			card_brothers: "并肩兄弟",
			text_brothers: "同一省份中，你的每对战士合计拥有3战力。",
			card_experts: "精锐战士",
			text_experts: "你的战士拥有2战力。",
			card_masters: "战斗大师",
			text_masters: "同一省份中，你的每对战士合计拥有6战力。",
			card_sight: "海姆达尔之视",
			text_sight: "本牌战力等于敌方揭示牌的最高单张战力。可以在所有人揭牌后追加。",
			card_dwarf: "矮人酋长",
			text_dwarf: "升级和入侵均不消耗怒气。",
			card_ship1: "洛基的龙船",
			text_ship1: "你的船被摧毁时，获得4荣耀。",
			card_ship2: "火焰龙船",
			text_ship2: "你的船被摧毁时，获得8荣耀。",
			card_ship3: "永恒龙船",
			text_ship3: "你的船被摧毁时，获得12荣耀。",
			card_leader1: "战锤领主",
			text_leader1: "领袖成功掠夺后，你可以将他移到相邻省份。",
			card_leader2: "战斧领主",
			text_leader2: "领袖成功掠夺后，任选一项氏族属性提升1格。",
			card_leader3: "长矛领主",
			text_leader3: "领袖成功掠夺后，所有氏族属性各提升1格。",
			card_smash: "提尔的重击",
			text_smash: "增加所示战力。",
			card_smite: "提尔的猛击",
			text_smite: "增加所示战力。",
			card_crush: "提尔的碾压",
			text_crush: "增加所示战力。",
			card_bash: "提尔的撞击",
			text_bash: "增加所示战力。",
			card_rage: "提尔的狂怒",
			text_rage: "增加所示战力。",
			card_judgement: "提尔的审判",
			text_judgement: "增加所示战力。",
			card_hammer: "索尔之锤",
			text_hammer: "若赢得这场战斗，获得3荣耀。",
			card_troll: "巨魔",
			text_troll: "入侵省份时，摧毁其中所有敌方战士。",
			card_charm: "弗丽嘉的魅惑",
			text_charm: "你打出的升级牌少消耗1怒气。",
			card_blessing: "洛基的祝福",
			text_blessing: "输掉战斗后，你可以向该省份免费入侵1名战士。",
			card_succor: "弗丽嘉的援助",
			text_succor: "你入侵时，可以向该省份免费额外入侵1名战士。船入侵时，选择其支援的省份。",
			card_trickery: "洛基的诡计",
			text_trickery: "若输掉战斗，从赢家处偷取1怒气。",
			card_manheim: "曼海姆！",
			text_manheim: "在至少一个黄色省份中独占最高战力。完成后获得牌面荣耀，并任选一项氏族属性提升1格。",
			card_alfheim: "亚尔夫海姆！",
			text_alfheim: "在至少一个灰色省份中独占最高战力。完成后获得牌面荣耀，并任选一项氏族属性提升1格。",
			card_jotunheim: "约顿海姆！",
			text_jotunheim: "在至少一个蓝色省份中独占最高战力。完成后获得牌面荣耀，并任选一项氏族属性提升1格。",
			card_widespread: "遍地征服！",
			text_widespread: "在至少两个不同省份中独占最高战力。完成后获得牌面荣耀，并任选一项氏族属性提升1格。",
			card_yggdrasil: "世界树！",
			text_yggdrasil: "在世界树中独占最高战力。完成后获得牌面荣耀，并任选一项氏族属性提升1格。",
			card_death: "光荣赴死！",
			text_death: "诸神黄昏前，至少4个己方单位位于英灵殿。完成后获得牌面荣耀，并任选一项氏族属性提升1格。",
			card_serpent: "海蛇",
			text_serpent: "本怪物视为船。",
			card_grace: "弗丽嘉的恩典",
			text_grace: "若成功掠夺，额外提升一项与掠夺奖励不同的氏族属性1格。奖励为荣耀或全属性时，可以任选。",
			card_odinSmite: "奥丁的惩击",
			text_odinSmite: "比较战力前，摧毁每个敌方氏族在该省份中的1名战士。",
			card_tyrDomain: "提尔的领域",
			text_tyrDomain: "战斗中揭示任务牌后，你可以将它视为增加3战力的战斗牌。",
			card_loki1: "洛基的领域",
			text_loki1: "每个己方单位离开英灵殿时，获得1荣耀。",
			card_loki2: "洛基的权势",
			text_loki2: "每个己方单位离开英灵殿时，获得2荣耀。",
			card_loki3: "洛基之怒",
			text_loki3: "每个己方单位离开英灵殿时，获得3荣耀。",
			card_thorDomain: "索尔的领域",
			text_thorDomain: "入侵省份后，你可以支付2怒气，立刻尝试掠夺该省份。",
			card_backstab: "洛基的背刺",
			text_backstab: "若输掉战斗，从赢家处偷取2荣耀。拥有弗丽嘉的选民且有秘术师参战时，不能打出本牌。",
			card_elf: "黑暗精灵",
			text_elf: "可以直接入侵世界树。在世界树中拥有3战力。",
			card_valkyrie: "女武神",
			text_valkyrie: "本怪物参战时，每个在本场战斗中被摧毁的敌方单位使你获得2荣耀。",
			card_eye: "海姆达尔之眼",
			text_eye: "可以在所有玩家揭示战斗牌后追加本牌战力。",
			card_fire: "火焰巨人",
			text_fire: "入侵省份时，摧毁其中所有敌方非怪物单位。",
			card_protection: "弗丽嘉的庇护",
			text_protection: "每当你的一个单位将被摧毁时，可以支付1怒气防止它被摧毁。",
			card_tide: "奥丁的洪流",
			text_tide: "比较战力前，每名参战者选择一个己方参战单位，其余己方参战单位全部摧毁。",
			card_watch: "海姆达尔的守望",
			text_watch: "弃掉所有揭示牌，获得等于这些牌合计战力的荣耀。然后各方重新出牌。",
			card_oath: "索尔的誓言",
			text_oath: "若赢得战斗，任选一项氏族属性提升1格。",
			card_inspiration: "奥丁的启示",
			text_inspiration: "己方单位死于诸神黄昏时，获得的荣耀翻倍。",
			card_prowess: "提尔的武勇",
			text_prowess: "赢得战斗后，可以为每张应弃掉的己方揭示牌支付1怒气，将其收回手中。",
			card_challenge: "提尔的挑战",
			text_challenge: "你可以花费一次行动并支付2怒气，再次掠夺已经被掠夺的省份。",
			card_conquest: "索尔的征服",
			text_conquest: "游戏结束时，每个仍在版图上的己方单位使你获得3荣耀。",
			card_hel: "海拉的士兵",
			text_hel: "升级和入侵均不消耗怒气。",
			card_gaze: "海姆达尔的凝视",
			text_gaze: "可以在所有玩家揭示战斗牌后追加本牌战力。",
			card_primacy: "索尔的威权",
			text_primacy: "在敌方揭示牌生效前，取消它们的文字效果。",
			card_tyrWrath: "提尔之怒",
			text_tyrWrath: "战斗中揭示任务牌后，你可以将它视为增加5战力的战斗牌。",
			card_witch: "女巫沃尔娃",
			text_witch: "在外省被摧毁时，可以改为撤退到世界树。",
			card_poison: "洛基的毒计",
			text_poison: "若输掉战斗，将赢家揭示的牌取到你的手中。",
			card_odinJudgement: "奥丁的审判",
			text_odinJudgement: "本场战斗中每有一个单位被摧毁，包括己方，获得2荣耀。",
			card_ascension: "索尔的飞升",
			text_ascension: "若赢得战斗，获得3怒气和3荣耀。",
			card_frost: "冰霜巨人",
			text_frost: "使用本怪物成功掠夺时，再获得一次掠夺奖励。",
			card_throne: "奥丁的王座",
			text_throne: "你完成的任务所奖励的荣耀翻倍。",
			card_sacrifice: "弗丽嘉的献祭",
			text_sacrifice: "你可以花费一次行动，摧毁自己的两个版图单位，任选一项氏族属性提升1格。",
			card_friggaDomain: "弗丽嘉的领域",
			text_friggaDomain: "支付1怒气，可以让英灵殿中的一个己方单位入侵。",
			card_fenrir: "芬里尔",
			text_fenrir: "诸神黄昏改为摧毁本怪物所在的外省，而非原定目标。",
			card_mountain: "山岳巨人",
			text_mountain: "本怪物视为领袖，并受领袖升级影响。",
			card_wolfman: "狼人",
			text_wolfman: "本怪物参战时，仅怪物单位计算版图战力；战斗牌仍有效。",
			card_mysticTroll: "秘术巨魔",
			text_mysticTroll: "你的单位入侵本怪物所在省份时，不消耗怒气。",
			card_hildi: "希尔迪斯维尼",
			text_hildi: "本怪物入侵省份时，可以替换一个单位，将原单位移到你选择的相邻省份。",
			card_nidhogg: "尼德霍格",
			text_nidhogg: "使用本怪物赢得战斗后，输家在英灵殿中每有一个单位，你获得1荣耀。",
			card_ymir: "尤弥尔",
			text_ymir: "升级和入侵均不消耗怒气。战力等于你在英灵殿中的单位数乘以2。"
		},
		en: {
			name: "Blood Rage",
			desc: "Draft the gifts of the gods, invade the nine provinces, and earn glory before Ragnarök.",
			errAction: "This action is unavailable. Please choose again.",
			p0: "Myrkulor",
			p1: "Elvagar",
			p2: "Angerboda",
			p3: "Muspelheim",
			p4: "Horgr",
			p5: "Utgard",
			p6: "Andlang",
			p7: "Gimle",
			p8: "Yggdrasil",
			f0: "Northwest fjord",
			f1: "Northeast fjord",
			f2: "Southeast fjord",
			f3: "Southwest fjord",
			rage: "Rage",
			axes: "Axes",
			horns: "Horns",
			glory: "Glory",
			strength: "Strength",
			cost: "Rage cost",
			baseCost: "Base upgrade cost",
			figureCardValue: "Strength {{strength}}; base upgrade cost {{cost}} Rage",
			age: "Age {{n}}",
			all: "All stats",
			warrior: "Warrior",
			leader: "Leader",
			ship: "Ship",
			mystic: "Mystic",
			monster: "Monster",
			clan: "Clan upgrade",
			battleCard: "Battle",
			questCard: "Quest",
			draftPrompt: "Choose {{n}} cards",
			actionPrompt: "Choose a figure, card, or province to pillage",
			reinforcePrompt: "Reinforce with an adjacent figure, or pass",
			battlePrompt: "Choose one hand card for battle",
			extraPrompt: "Play a Heimdall card, or pass",
			discardPrompt: "Keep one card for the next age",
			waiting: "Waiting for the other clans",
			settling: "Resolving",
			choosePrompt: "Choose an effect",
			done: "Ragnarök has come",
			draftConfirm: "Keep selected cards",
			invade: "Invade",
			march: "March",
			upgrade: "Upgrade",
			quest: "Commit quest",
			pillage: "Pillage",
			pass: "End actions this age",
			confirmPass: "Ending your actions reduces your remaining Rage to zero.",
			cancel: "Cancel",
			confirm: "Confirm",
			skip: "Skip",
			reinforcePass: "Pass reinforcement",
			extraPass: "Pass",
			battleSubmit: "Play this card",
			noCard: "Fight without a card",
			hand: "Hand",
			reserve: "Reserve",
			valhalla: "Valhalla",
			upgrades: "Equipped upgrades",
			quests: "Secret quests",
			destroyed: "Destroyed",
			pillaged: "Pillaged",
			doom: "Doomed in Age {{n}}",
			villages: "Villages {{n}}/{{total}}",
			figures: "Figures {{n}}/{{total}}",
			empty: "Empty",
			selected: "Selected",
			back: "Back",
			details: "Details",
			log: "Chronicle",
			close: "Close",
			chooseDestination: "Choose a destination",
			chooseFigure: "Choose a figure",
			chooseSlot: "Choose an upgrade slot",
			clanSlot: "Clan slot {{n}}",
			monsterSlot: "Monster slot {{n}}",
			sacrifice: "Sacrifice two of your figures",
			destroy: "Destroy this figure",
			protect: "Pay 1 Rage to protect",
			retreat: "Retreat",
			keep: "Pay 1 Rage to keep",
			discard: "Discard",
			survivor: "Choose one figure to keep",
			freeInvade: "Choose a free invasion",
			succor: "Invade with an additional warrior",
			blessing: "Invade the battlefield with a free warrior",
			domainPillage: "Pay 2 Rage to pillage now",
			statPrompt: "Raise one clan stat",
			godMove: "Move the god",
			leaderMove: "Move your leader",
			death: "Choose the fate of this figure",
			thor: "Thor",
			frigga: "Frigga",
			tyr: "Tyr",
			odin: "Odin",
			loki: "Loki",
			heimdall: "Heimdall",
			god_thor: "The battle winner gains 2 extra Glory per enemy figure destroyed in this battle.",
			god_frigga: "Figures in this province and its supporting fjord cannot be destroyed during battle.",
			god_tyr: "All figures have 0 Strength in battle. Only cards count.",
			god_odin: "Double the pillage reward in this province.",
			god_loki: "All losers gain battle Glory instead of the winner. Card rewards still go to the winner.",
			god_heimdall: "Play cards face up in turn, with the pillaging player last.",
			fifthPlayer: "5th Player",
			mystics: "Mystics of Midgard",
			gods: "Gods of Asgard",
			monsters: "Official bonus monsters",
			expansionNote: "Expansions are off by default. The 5th Player expansion allows up to 5 players.",
			score: "Glory standings",
			winner: "Victorious clan",
			tie: "Shared victory",
			duringGame: "Earned during the ages",
			finalStats: "Clan stat bonus",
			finalConquest: "Thor’s Conquest",
			total: "Total Glory",
			reviewBoard: "View the board",
			showResults: "Show results",
			ageGlory: "Ragnarök: {{n}} Glory per figure",
			cardsCount: "{{n}} hand cards · {{quests}} quests",
			noActions: "You have no action to take in this phase.",
			battleAt: "Battle of {{name}}",
			pending: "Submitted",
			replace: "Replace {{name}}",
			push: "Push to {{name}}",
			moveCount: "March {{n}} figures",
			statLevel: "Level {{n}}",
			resultSuccess: "Quest fulfilled",
			resultFail: "Quest unfulfilled",
			log_invade: "{{name}} invades {{place}}",
			log_march: "{{name}} marches to {{place}}",
			log_pillage: "{{name}} successfully pillages {{place}}",
			log_battle: "Battle in {{place}} ends; highest Strength {{n}}",
			log_destroy: "A figure of {{name}} enters Valhalla",
			log_ragnarok: "Ragnarök destroys {{place}}",
			log_questSuccess: "{{name}} fulfills a quest for {{n}} Glory",
			log_questFail: "A quest of {{name}} remains unfulfilled",
			log_age: "Age {{n}} begins",
			log_upgrade: "{{name}} equips an upgrade",
			log_release: "A figure of {{name}} returns from Valhalla",
			log_final: "Age 3 ends; final Glory is scored",
			rules: "【Goal and setup】：\nThe clan with the most Glory after three ages wins. Ties share victory. Each clan has 8 Warriors, 1 Leader, and 1 Ship, with initial Rage of 6, Axes of 3, and Horns of 4. Randomly destroy outer provinces at setup according to the player count:\n· With two players, destroy 3 outer provinces.\n· With three players, destroy 2 outer provinces.\n· With four players, destroy 1 outer province.\n· With five players, destroy no outer provinces.\nThree future Ragnarök targets are shown. Randomly assign the outer pillage rewards: 3 Rage, 2 Axes, 2 Horns, and one 5-Glory token. Yggdrasil raises all stats.\n【Draft】：\nDeal 8 cards per age. With 3–5 players, keep 1 and pass left each round until you have kept 6; discard the rest. With 2 players, keep 2 each round, three times. A card kept from the previous age is not drafted.\n【Actions】：\nIn turn, invade, march, upgrade, commit a quest, or pillage. Passing reduces remaining Rage to zero. At zero Rage you cannot take regular actions, but may reinforce, fight, or use eligible effects. Gaining Rage lets you act again. The age ends immediately when everyone has zero Rage, or every surviving province has been pillaged.\n【Invade and march】：\nInvasion costs a figure’s Strength; Leaders are free, Warriors normally cost 1, Ships 2. Horns limits your figures on the board. Land figures require empty villages and normally cannot invade Yggdrasil directly. Ships invade fjords and support both adjacent provinces. Pay 1 Rage to march any number of your land figures from one province to any other surviving province with enough room. Marching does not require adjacency.\n【Upgrades and quests】：\nPay an upgrade’s Rage cost and equip its matching slot, replacing the old card. You have 3 Clan slots, 2 Monster slots, and one each for Warriors, Leader, and Ship. A figure upgrade allows one corresponding figure to invade immediately for free. Committing a quest costs no Rage and keeps it secret until the end of the age. Identical quests may each score. Card text overrides general rules.\n【Pillage and reinforcement】：\nPillage an unpillaged province containing your figure or supported by your Ship, at no Rage cost. Beginning left of the pillager, each clan may move one adjacent land figure into the battlefield or pass. Continue until all villages are full or every clan passes consecutively. A previous pass does not prevent later reinforcement. If only one clan participates, it receives the reward without battle.\n【Battle】：\nEach participant secretly chooses one hand card, or none if empty-handed. Non-Battle cards normally add zero Strength. Reveal together, then take turns adding Heimdall’s Sight, Eye, or Gaze until everyone passes consecutively. Resolve Thor’s Primacy before Heimdall’s Watch, then other effects. The unique highest total of figure and card Strength wins; a tie makes everyone lose. Losing figures are destroyed and losing cards return to hand. The winner discards revealed cards and gains Glory equal to current Axes. Only a winning pillager receives the pillage reward; raise reward stats before awarding battle Glory. A clan whose figures were all destroyed by cards still fights with card Strength. Ships and the Sea Serpent support adjacent provinces. Yggdrasil has no supporting fjord.\n【End of an age】：\nIn Ages 1–2, discard down to at most one hand card. In Age 3, discard all. Check secret quests individually: each success earns printed Glory and raises one clan stat. Control requires unique highest figure Strength; ties do not control. Glorious Death needs at least 4 of your figures in Valhalla. Then Ragnarök destroys the doomed province and figures in its supporting fjord, awarding 2/3/4 Glory per figure in Ages 1/2/3. All Valhalla figures return to reserve; surviving board figures remain. Pass first player left, reset pillage markers, and begin the next age.\n【Final scoring】：\nAfter Age 3, each clan stat at its fourth or fifth position grants 10 Glory, or 20 at its sixth position. Each stat scores once. Add applicable endgame card rewards and compare total Glory.\n【Optional expansions】：\n5th Player adds 9 cards per age and allows 5 players. Mystic upgrades add one free-to-invade, Strength-2 Mystic, up to two; they count against Horns. Identical Chosen abilities do not stack. Gods of Asgard uses two random gods, repositioned each age. They affect their province and supporting fjord. After a pillage, the pillager moves its god to a different surviving, unpillaged, god-free province.\n· Thor adds Glory for destroyed enemies.\n· Frigga prevents battle deaths.\n· Tyr makes figure Strength zero.\n· Odin doubles pillage rewards.\n· Loki awards battle Glory to losers.\n· Heimdall requires sequential face-up cards, with the pillager last.\nBonus monsters can be enabled separately; see their cards. A clan fighting with a Frigga’s Chosen Mystic cannot play Loki’s Backstab.",
			questComplete: "Quest completed",
			questFailed: "Quest not completed",
			questBattle: "Treat this quest as a battle card?",
			boostQuest: "Add {{n}} Strength",
			card_chosen1: "Frigga’s Chosen",
			text_chosen1: "Add 1 mystic. Your mystics may retreat to an adjacent outer province instead of being destroyed.",
			card_chosen2: "Odin’s Chosen",
			text_chosen2: "Add 1 mystic. Your mystics may invade a village occupied by a warrior or mystic, destroying that figure.",
			card_chosen3: "Thor’s Chosen",
			text_chosen3: "Add 1 mystic. Each time you win a battle, gain 3 glory for each participating mystic of yours.",
			card_thorGlory: "Thor’s Glory",
			text_thorGlory: "Gain 2 glory whenever at least 2 enemy figures are destroyed in a battle you participate in.",
			card_brothers: "Brothers in Arms",
			text_brothers: "Each pair of your warriors in a province has 3 total STR.",
			card_experts: "Experts in Arms",
			text_experts: "Your warriors have 2 STR.",
			card_masters: "Masters in Arms",
			text_masters: "Each pair of your warriors in a province has 6 total STR.",
			card_sight: "Heimdall’s Sight",
			text_sight: "This card has the same STR as the highest revealed enemy card. You may play it after all players reveal their cards.",
			card_dwarf: "Dwarf Chieftain",
			text_dwarf: "Costs no rage to upgrade or invade.",
			card_ship1: "Loki’s Dragons",
			text_ship1: "Gain 4 glory when a ship of yours is destroyed.",
			card_ship2: "Fire Dragons",
			text_ship2: "Gain 8 glory when a ship of yours is destroyed.",
			card_ship3: "Eternal Dragons",
			text_ship3: "Gain 12 glory when a ship of yours is destroyed.",
			card_leader1: "Lord of Hammers",
			text_leader1: "After successfully pillaging with your leader, you may move him to an adjacent province.",
			card_leader2: "Lord of Axes",
			text_leader2: "If you successfully pillage with your leader, raise one clan stat by 1.",
			card_leader3: "Lord of Spears",
			text_leader3: "If you successfully pillage with your leader, raise all clan stats by 1.",
			card_smash: "Tyr’s Smash",
			text_smash: "Add the indicated STR.",
			card_smite: "Tyr’s Smite",
			text_smite: "Add the indicated STR.",
			card_crush: "Tyr’s Crush",
			text_crush: "Add the indicated STR.",
			card_bash: "Tyr’s Bash",
			text_bash: "Add the indicated STR.",
			card_rage: "Tyr’s Rage",
			text_rage: "Add the indicated STR.",
			card_judgement: "Tyr’s Judgment",
			text_judgement: "Add the indicated STR.",
			card_hammer: "Thor’s Hammer",
			text_hammer: "Gain 3 glory if you win this battle.",
			card_troll: "Troll",
			text_troll: "When this monster invades a province, destroy all enemy warriors there.",
			card_charm: "Frigga’s Charm",
			text_charm: "Upgrade cards cost you 1 less rage to play.",
			card_blessing: "Loki’s Blessing",
			text_blessing: "If you lose a battle, you may invade that province with a warrior for free.",
			card_succor: "Frigga’s Succor",
			text_succor: "When you invade, you may invade with an additional warrior in that province for free. For a ship, choose a supported province.",
			card_trickery: "Loki’s Trickery",
			text_trickery: "If you lose, steal 1 rage from the winning player.",
			card_manheim: "Manheim!",
			text_manheim: "Have the most STR in at least one yellow province. Gain the indicated glory and raise one clan stat by 1.",
			card_alfheim: "Alfheim!",
			text_alfheim: "Have the most STR in at least one gray province. Gain the indicated glory and raise one clan stat by 1.",
			card_jotunheim: "Jotunheim!",
			text_jotunheim: "Have the most STR in at least one blue province. Gain the indicated glory and raise one clan stat by 1.",
			card_widespread: "Widespread!",
			text_widespread: "Have the most STR in at least 2 different provinces. Gain the indicated glory and raise one clan stat by 1.",
			card_yggdrasil: "Yggdrasil!",
			text_yggdrasil: "Have the most STR in Yggdrasil. Gain the indicated glory and raise one clan stat by 1.",
			card_death: "Glorious Death!",
			text_death: "Have at least 4 figures in Valhalla before Ragnarök. Gain the indicated glory and raise one clan stat by 1.",
			card_serpent: "Sea Serpent",
			text_serpent: "This monster counts as a ship.",
			card_grace: "Frigga’s Grace",
			text_grace: "If you successfully pillage, raise another clan stat by 1. With a glory or all-stats reward, choose any stat.",
			card_odinSmite: "Odin’s Smite",
			text_odinSmite: "Destroy one warrior from each opponent in this province before comparing STR.",
			card_tyrDomain: "Tyr’s Domain",
			text_tyrDomain: "After revealing a quest in battle, you may treat it as a +3 battle card.",
			card_loki1: "Loki’s Domain",
			text_loki1: "Gain 1 glory for each figure you release from Valhalla.",
			card_loki2: "Loki’s Eminence",
			text_loki2: "Gain 2 glory for each figure you release from Valhalla.",
			card_loki3: "Loki’s Wrath",
			text_loki3: "Gain 3 glory for each figure you release from Valhalla.",
			card_thorDomain: "Thor’s Domain",
			text_thorDomain: "After invading a province, you may pay 2 rage to immediately try to pillage it.",
			card_backstab: "Loki’s Backstab",
			text_backstab: "If you lose, steal 2 glory from the winner. You cannot play this with a participating mystic and Frigga’s Chosen.",
			card_elf: "Dark Elf",
			text_elf: "May invade Yggdrasil. Has 3 STR in Yggdrasil.",
			card_valkyrie: "Valkyrie",
			text_valkyrie: "Gain 2 glory per enemy figure destroyed in a battle with this monster.",
			card_eye: "Heimdall’s Eye",
			text_eye: "You may play this card and add its STR after all players reveal their battle cards.",
			card_fire: "Fire Giant",
			text_fire: "When this monster invades a province, destroy all enemy non-monster figures there.",
			card_protection: "Frigga’s Protection",
			text_protection: "You may pay 1 rage to prevent a figure of yours from being destroyed.",
			card_tide: "Odin’s Tide",
			text_tide: "Before comparing STR, each player chooses one figure and destroys all their other figures in this battle.",
			card_watch: "Heimdall’s Watch",
			text_watch: "Discard all revealed cards. Gain glory equal to their total revealed STR. Then play new cards.",
			card_oath: "Thor’s Oath",
			text_oath: "If you win, raise one clan stat by 1.",
			card_inspiration: "Odin’s Inspiration",
			text_inspiration: "Double your glory award for dying during Ragnarök.",
			card_prowess: "Tyr’s Prowess",
			text_prowess: "If you win a battle, you may keep any of your revealed cards by paying 1 rage each.",
			card_challenge: "Tyr’s Challenge",
			text_challenge: "As your action, pay 2 rage to repillage an already pillaged province.",
			card_conquest: "Thor’s Conquest",
			text_conquest: "Gain 3 glory for each figure you have on the board at the end of the game.",
			card_hel: "Soldier of Hel",
			text_hel: "Costs no rage to upgrade or invade.",
			card_gaze: "Heimdall’s Gaze",
			text_gaze: "You may play this card and add its STR after all players reveal their battle cards.",
			card_primacy: "Thor’s Primacy",
			text_primacy: "Cancel the text of each opponent’s revealed cards before it takes effect.",
			card_tyrWrath: "Tyr’s Wrath",
			text_tyrWrath: "After revealing a quest in battle, you may treat it as a +5 battle card.",
			card_witch: "Völur Witch",
			text_witch: "May retreat from an outer province to Yggdrasil instead of being destroyed.",
			card_poison: "Loki’s Poison",
			text_poison: "If you lose, take the winning player’s revealed cards into your hand.",
			card_odinJudgement: "Odin’s Judgement",
			text_odinJudgement: "Gain 2 glory for each figure destroyed in this battle, including yours.",
			card_ascension: "Thor’s Ascension",
			text_ascension: "If you win, gain 3 rage and 3 glory.",
			card_frost: "Frost Giant",
			text_frost: "If you successfully pillage with this monster, gain the pillage reward again.",
			card_throne: "Odin’s Throne",
			text_throne: "Double the glory award for quests you complete.",
			card_sacrifice: "Frigga’s Sacrifice",
			text_sacrifice: "As your action, destroy 2 of your figures on the board to raise one clan stat by 1.",
			card_friggaDomain: "Frigga’s Domain",
			text_friggaDomain: "You may pay 1 rage to invade with any one of your figures in Valhalla.",
			card_fenrir: "Fenrir",
			text_fenrir: "Ragnarök destroys this monster’s outer province instead of the doomed one.",
			card_mountain: "Mountain Giant",
			text_mountain: "This monster counts as a leader and benefits from leader upgrades.",
			card_wolfman: "Wolfman",
			text_wolfman: "Only monsters count their figure STR in a battle with this monster. Battle cards still count.",
			card_mysticTroll: "Mystic Troll",
			text_mysticTroll: "Your figures invade this monster’s province for free.",
			card_hildi: "Hildisvíni",
			text_hildi: "When this monster invades a province, it may replace a figure there, moving it to an adjacent province of your choice.",
			card_nidhogg: "Nídhöggr",
			text_nidhogg: "After winning a battle with this monster, gain 1 glory for each figure the losers have in Valhalla.",
			card_ymir: "Ymir",
			text_ymir: "Costs no rage to upgrade or invade. STR equals twice the number of your figures in Valhalla."
		}
	}
};
//#endregion
export { xt as default };
