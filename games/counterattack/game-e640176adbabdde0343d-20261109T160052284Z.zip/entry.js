import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { PLAYER_COLORS as n } from "@bgparty/sdk/player-colors";
import { useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconZoomIn as l, IconZoomOut as u } from "@bgparty/sdk/icons";
import { playTurn as d, useSoundEdge as f } from "@bgparty/sdk/sfx";
import { LogTicker as p } from "@bgparty/sdk/ui/log-sheet";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { GameOverScreen as v } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as y, OptionSection as ee } from "@bgparty/sdk/ui/game-options";
//#region src/games/counterattack/data.ts
var te = [
	{
		name: "RUIZ",
		nation: "ARG",
		st: [
			6,
			5,
			2,
			5,
			3,
			4,
			1
		]
	},
	{
		name: "LANGDON",
		nation: "AUS",
		st: [
			5,
			4,
			3,
			5,
			4,
			4,
			2
		]
	},
	{
		name: "ANDRE NORUEGA",
		nation: "BRA",
		st: [
			4,
			6,
			3,
			5,
			5,
			5,
			1
		]
	},
	{
		name: "BARISIC",
		nation: "CRO",
		st: [
			4,
			5,
			3,
			4,
			6,
			5,
			2
		]
	},
	{
		name: "FRUIN",
		nation: "ENG",
		st: [
			4,
			3,
			6,
			4,
			6,
			5,
			1
		]
	},
	{
		name: "KUCKLICK",
		nation: "GER",
		st: [
			5,
			5,
			3,
			5,
			5,
			3,
			2
		]
	},
	{
		name: "MCNULTY",
		nation: "IRL",
		st: [
			5,
			4,
			4,
			5,
			1,
			5,
			1
		]
	},
	{
		name: "VAN DE KERKHOF",
		nation: "NED",
		st: [
			5,
			5,
			2,
			6,
			4,
			4,
			1
		]
	},
	{
		name: "SESAY",
		nation: "NGA",
		st: [
			6,
			2,
			2,
			4,
			3,
			5,
			1
		]
	},
	{
		name: "MITCHELL",
		nation: "NIR",
		st: [
			4,
			3,
			3,
			5,
			4,
			4,
			2
		]
	},
	{
		name: "RUSU",
		nation: "ROU",
		st: [
			4,
			4,
			4,
			4,
			5,
			6,
			1
		]
	},
	{
		name: "PAVLOVIC",
		nation: "SRB",
		st: [
			4,
			2,
			6,
			4,
			5,
			5,
			1
		]
	},
	{
		name: "WILLEMS",
		nation: "BEL",
		st: [
			5,
			3,
			5,
			5,
			5,
			3,
			4
		]
	},
	{
		name: "YUGAR",
		nation: "BOL",
		st: [
			4,
			1,
			3,
			6,
			5,
			2,
			1
		]
	},
	{
		name: "LESSA",
		nation: "BRA",
		st: [
			5,
			2,
			4,
			5,
			6,
			2,
			5
		]
	},
	{
		name: "TAYLOR",
		nation: "CAN",
		st: [
			5,
			2,
			4,
			6,
			3,
			2,
			5
		]
	},
	{
		name: "VRABEC",
		nation: "CZE",
		st: [
			5,
			1,
			6,
			4,
			6,
			2,
			5
		]
	},
	{
		name: "KALLA",
		nation: "GER",
		st: [
			5,
			3,
			3,
			6,
			5,
			1,
			4
		]
	},
	{
		name: "O'CONNOR",
		nation: "IRL",
		st: [
			5,
			1,
			3,
			4,
			4,
			2,
			2
		]
	},
	{
		name: "LONGO",
		nation: "ITA",
		st: [
			4,
			2,
			6,
			3,
			6,
			2,
			6
		]
	},
	{
		name: "ABRAHAM",
		nation: "CIV",
		st: [
			5,
			1,
			4,
			6,
			4,
			1,
			3
		]
	},
	{
		name: "TOOTHNAIL",
		nation: "MNG",
		st: [
			5,
			2,
			4,
			5,
			6,
			2,
			4
		]
	},
	{
		name: "MARELL",
		nation: "NED",
		st: [
			4,
			1,
			6,
			4,
			6,
			2,
			5
		]
	},
	{
		name: "WERDEKKER",
		nation: "NED",
		st: [
			4,
			3,
			3,
			6,
			4,
			4,
			5
		]
	},
	{
		name: "DELGADO",
		nation: "ESP",
		st: [
			5,
			4,
			4,
			5,
			5,
			2,
			3
		]
	},
	{
		name: "K.OZCAN",
		nation: "TUR",
		st: [
			4,
			1,
			6,
			5,
			2,
			2,
			3
		]
	},
	{
		name: "DIONTE",
		nation: "USA",
		st: [
			4,
			2,
			6,
			4,
			6,
			3,
			3
		]
	},
	{
		name: "NAZEF",
		nation: "ALG",
		st: [
			5,
			2,
			4,
			6,
			5,
			3,
			4
		]
	},
	{
		name: "GILBERT",
		nation: "ENG",
		st: [
			4,
			4,
			3,
			6,
			4,
			4,
			3
		]
	},
	{
		name: "LITTLEWOOD",
		nation: "ENG",
		st: [
			4,
			4,
			4,
			6,
			5,
			4,
			4
		]
	},
	{
		name: "GOALEY",
		nation: "ENG",
		st: [
			4,
			4,
			3,
			6,
			5,
			4,
			3
		]
	},
	{
		name: "IWU",
		nation: "FRA",
		st: [
			5,
			3,
			4,
			4,
			6,
			4,
			3
		]
	},
	{
		name: "ATTAH",
		nation: "GHA",
		st: [
			5,
			2,
			4,
			3,
			5,
			3,
			5
		]
	},
	{
		name: "PATRAS",
		nation: "MDA",
		st: [
			5,
			1,
			3,
			4,
			3,
			3,
			2
		]
	},
	{
		name: "ANDERSEN",
		nation: "NOR",
		st: [
			5,
			1,
			5,
			4,
			5,
			2,
			3
		]
	},
	{
		name: "RIBEIRO",
		nation: "POR",
		st: [
			3,
			3,
			1,
			5,
			4,
			2,
			3
		]
	},
	{
		name: "KERR",
		nation: "SCO",
		st: [
			5,
			2,
			3,
			4,
			4,
			3,
			1
		]
	},
	{
		name: "ROBBIE",
		nation: "SCO",
		st: [
			6,
			4,
			1,
			5,
			4,
			4,
			3
		]
	},
	{
		name: "STEWART",
		nation: "SCO",
		st: [
			5,
			4,
			3,
			5,
			5,
			4,
			3
		]
	},
	{
		name: "NILSSON",
		nation: "SWE",
		st: [
			4,
			3,
			3,
			5,
			5,
			4,
			2
		]
	},
	{
		name: "EKSTROM",
		nation: "SWE",
		st: [
			5,
			2,
			4,
			5,
			6,
			3,
			5
		]
	},
	{
		name: "WALTON",
		nation: "USA",
		st: [
			6,
			3,
			3,
			6,
			3,
			4,
			3
		]
	}
], ne = [
	{
		name: "FIRRELL",
		nation: "AUS",
		st: [
			6,
			1,
			5,
			6,
			3,
			4,
			5
		]
	},
	{
		name: "EUBSINHO",
		nation: "BRA",
		st: [
			6,
			3,
			5,
			6,
			4,
			4,
			6
		]
	},
	{
		name: "WALKER",
		nation: "ENG",
		st: [
			5,
			1,
			6,
			6,
			5,
			2,
			4
		]
	},
	{
		name: "NKOSI",
		nation: "RSA",
		st: [
			5,
			2,
			6,
			6,
			4,
			4,
			4
		]
	}
], b = [
	{
		name: "WEBSTER",
		leniency: 2
	},
	{
		name: "CASTOLO",
		leniency: 3
	},
	{
		name: "BAKKER",
		leniency: 4
	},
	{
		name: "READ",
		leniency: 5
	}
], re = (e) => e >= 100;
function ie(e, t = 0) {
	let n = (e) => Math.max(0, e - t);
	if (re(e)) {
		let [t, r, i, a, o, s, c] = ne[e - 100].st;
		return {
			pace: n(i),
			dribbling: n(r),
			heading: 0,
			highPass: n(c),
			resilience: n(a),
			shooting: 0,
			tackling: 0,
			aerial: n(t),
			saving: n(o),
			handling: n(s)
		};
	}
	let [r, i, a, o, s, c, l] = te[e].st;
	return {
		pace: n(r),
		dribbling: n(i),
		heading: n(a),
		highPass: n(o),
		resilience: n(s),
		shooting: n(c),
		tackling: n(l),
		aerial: 0,
		saving: 0,
		handling: 0
	};
}
var x = [[
	100,
	29,
	2,
	3,
	16,
	19,
	30,
	31,
	10,
	21,
	28,
	41,
	11,
	15,
	37,
	0
], [
	101,
	12,
	40,
	4,
	14,
	23,
	27,
	38,
	5,
	22,
	24,
	1,
	7,
	17,
	32,
	39
]], ae = te.map((e, t) => t), S = {
	header: 6,
	firstTime: 6,
	standard: 11,
	highPass: 15,
	shot: 11,
	gkDive: 3
}, oe = {
	id: "counterattack",
	tier: "beta",
	mechanics: ["dice-rolling", "grid-movement"],
	interactionTags: [],
	nameKey: "games.counterattack.name",
	descKey: "games.counterattack.desc",
	rulesKey: "games.counterattack.rules",
	icon: "⚽",
	iconImg: "games/counterattack.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/counterattack/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#16a34a",
	releasedAt: "2026-09-25",
	search: {
		py: "lv yin fan ji",
		init: "lyfj"
	},
	hotseat: "cover"
}, se = (e, t) => `${e},${t}`, C = (e, t) => se(e, t), w = (e) => {
	let [t, n] = e.split(",").map(Number);
	return {
		c: t,
		r: n
	};
}, T = (e, t) => e >= 0 && e < 37 && t >= 0 && t < 25, ce = (e) => [e.r - (e.c - (e.c & 1) >> 1), e.c], le = (e, t) => ({
	c: t,
	r: e + (t - (t & 1) >> 1)
}), E = (e, t) => {
	let [n, r] = ce(e), [i, a] = ce(t);
	return (Math.abs(n - i) + Math.abs(r - a) + Math.abs(n + r - i - a)) / 2;
}, ue = [
	[0, 1],
	[0, -1],
	[1, 0],
	[1, -1],
	[-1, 0],
	[-1, -1]
], de = [
	[0, 1],
	[0, -1],
	[1, 0],
	[1, 1],
	[-1, 0],
	[-1, 1]
], D = (e) => {
	let t = e.c & 1 ? de : ue, n = [];
	for (let [r, i] of t) {
		let t = e.c + r, a = e.r + i;
		T(t, a) && n.push({
			c: t,
			r: a
		});
	}
	return n;
}, fe = [
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1],
	[0, 1]
], pe = (e, t) => {
	let [n, r] = ce(e), [i, a] = fe[(t - 1 + 6) % 6];
	return le(n + i, r + a);
}, O = (e, t) => {
	let [n, r] = ce(e), [i, a] = ce(t), o = E(e, t);
	if (o === 0) return [];
	let s = [];
	for (let e = 1; e <= o; e += 1) {
		let t = e / o, c = n + (i - n) * t, l = r + (a - r) * t, u = -c - l, d = Math.round(c), f = Math.round(u), p = Math.round(l), m = Math.abs(d - c), h = Math.abs(f - u), g = Math.abs(p - l);
		m > h && m > g ? d = -f - p : h <= g && (p = -d - f), s.push(le(d, p));
	}
	return s;
}, k = [
	9,
	10,
	11,
	12,
	13,
	14,
	15
], me = (e) => e === 0 ? 1 : -1, A = (e, t) => (t === 0 ? e.c <= 6 : e.c >= 30) && e.r >= 5 && e.r <= 19, he = (e, t) => (t === 0 ? e.c <= 2 : e.c >= 34) && e.r >= 7 && e.r <= 17, ge = (e) => ({
	c: e === 0 ? 4 : 32,
	r: 12
}), _e = (e, t) => t === 0 ? e.c <= 18 : e.c >= 18, ve = (e, t) => t === 0 ? e.c >= 26 : e.c <= 10, ye = {
	c: 18,
	r: 12
}, be = (e) => e >= k[0] && e <= k[6], xe = (e, t) => {
	let n = t === 0 ? 36 - e.c : e.c;
	return Math.abs(e.r - 12) > 1.5 * n;
}, Se = (e, t) => D(e).filter((n) => n.c === e.c - me(t)), j = (e) => 1 - e, M = (e) => Number(e[0]), Ce = (e, t) => `${e}:${t}`, we = 60;
function N(e, t) {
	e.log.push(t), e.log.length > we && (e.log = e.log.slice(-60));
}
function P(t) {
	let n = e(t.seed, t.cursor, 6) + 1;
	return t.cursor += 1, n;
}
function F(e, t) {
	let n = M(t), r = e.squads[n][Number(t.slice(2))];
	return ie(r, e.injuries[t] ?? 0);
}
var I = (e, t) => re(e.squads[M(t)][Number(t.slice(2))]), L = (e, t) => w(e.pos[t]), Te = (e, t) => {
	for (let n of [0, 1]) for (let r of e.onPitch[n]) if (e.pos[r] === t) return r;
	return null;
}, R = (e, t) => e.onPitch[t].find((t) => I(e, t)) ?? null;
function z(e, t) {
	if (A(e, j(t))) return !0;
	let n = t === 0 ? 36 : 0;
	for (let t of k) if (E(e, {
		c: n,
		r: t
	}) <= S.shot) return !0;
	return !1;
}
function B(e, t) {
	if (e.phase === "play" && e.actions >= e.config.halfLength) {
		De(e);
		return;
	}
	e.mode = t;
}
var V = (e) => B(e, { k: "action" });
function Ee(e) {
	e.actions += 1;
}
function De(e) {
	e.half === 1 ? (e.half = 2, e.actions = 0, N(e, {
		k: "half",
		n: 1
	}), Oe(e, j(e.kickoffSide))) : (e.phase = "over", N(e, {
		k: "half",
		n: 2
	}));
}
function Oe(e, t) {
	for (let t of [0, 1]) for (let n of e.onPitch[t]) {
		let r = e.home[`${t}:${e.num[n]}`];
		r && (e.pos[n] = r);
	}
	let n = e.onPitch[t].find((t) => !I(e, t)) ?? e.onPitch[t][0];
	e.pos[n] = C(ye.c, ye.r), e.ball = C(ye.c, ye.r), e.holder = n, e.gkHands = !1, e.poss = t, e.lastTouch = t, e.canFT = !1, e.canSnap = !1, e.mode = { k: "action" };
}
function ke(e, t) {
	e.scores[t] += 1, N(e, {
		k: "goal",
		side: t
	}), Oe(e, j(t)), B(e, { k: "action" });
}
function Ae(e, t, n) {
	if (n.c < 0 || n.c >= 37) {
		let r = n.c < 0 ? 0 : 1;
		if (be(n.r)) {
			let n = R(e, r);
			if (n && E(L(e, n), t) <= 1) {
				let t = P(e);
				if (t >= 5 || F(e, n).saving + t >= 10) {
					U(e, n);
					return;
				}
			}
			ke(e, j(r));
			return;
		}
		e.lastTouch === r ? Pe(e, j(r), t) : Me(e, r);
		return;
	}
	Ne(e, j(e.lastTouch), {
		c: t.c,
		r: n.r < 0 ? 0 : 24
	});
}
function je(e, t, n, r) {
	let i = M(t);
	if (I(e, t) && A(L(e, t), i)) {
		U(e, t);
		return;
	}
	e.holder = t, e.gkHands = !1, e.ball = e.pos[t], i === e.poss ? (e.canFT = !1, e.canSnap = z(L(e, t), i)) : (e.poss = i, e.canFT = !0, e.canSnap = !1), n === "header" ? We(e, w(e.ball), r, !1) : V(e);
}
function H(e, t, n, r = "move", i) {
	let a = i ?? P(e), o = P(e), s = t;
	for (let t = 0; t < o; t += 1) {
		let t = pe(s, a);
		if (!T(t.c, t.r)) {
			e.ball = C(s.c, s.r), Ae(e, s, t);
			return;
		}
		let i = Te(e, C(t.c, t.r));
		if (i && !n.includes(i)) {
			je(e, i, r, n);
			return;
		}
		s = t;
	}
	e.ball = C(s.c, s.r), e.holder = null, e.gkHands = !1;
	for (let t of [0, 1]) {
		if (!A(s, t)) continue;
		let n = R(e, t);
		if (n && E(L(e, n), s) <= 1) {
			U(e, n);
			return;
		}
	}
	let c = j(e.poss), l = null;
	for (let t of e.onPitch[c]) n.includes(t) || I(e, t) || E(L(e, t), s) > 1 || (!l || F(e, t).tackling > F(e, l).tackling) && (l = t);
	if (l) {
		let t = P(e);
		if (t === 6 || F(e, l).tackling + t >= 10) {
			e.holder = l, e.ball = e.pos[l], e.poss = c, e.canFT = !0, e.canSnap = !1, N(e, {
				k: "steal",
				side: c,
				pid: l
			}), V(e);
			return;
		}
	}
	r === "header" ? We(e, s, n, !1) : Xe(e, "action");
}
function Me(e, t) {
	let n = R(e, t) ?? e.onPitch[t][0], r = t === 0 ? {
		c: 1,
		r: 12
	} : {
		c: 35,
		r: 12
	};
	if (Te(e, C(r.c, r.r))) {
		let n = D(r).find((n) => he(n, t) && !Te(e, C(n.c, n.r)));
		n && Object.assign(r, n);
	}
	e.pos[n] = C(r.c, r.r), e.ball = e.pos[n], e.holder = n, e.gkHands = !1, e.poss = t, e.canFT = !1, e.canSnap = !1, N(e, {
		k: "goalkick",
		side: t
	}), B(e, {
		k: "gk",
		kick: !0
	});
}
function Ne(e, t, n) {
	e.poss = t, e.holder = null, e.gkHands = !1, e.ball = C(n.c, n.r), e.canFT = !1, e.canSnap = !1, e.throwCtx = {
		spot: e.ball,
		thrower: null,
		movesLeft: 2
	}, N(e, {
		k: "throwin",
		side: t
	}), B(e, {
		k: "throw",
		spot: e.ball,
		thrower: null,
		movesLeft: 2
	});
}
function Pe(e, t, n) {
	let r = {
		c: t === 0 ? 36 : 0,
		r: n.r < 12 ? 0 : 24
	};
	e.poss = t, e.holder = null, e.gkHands = !1, e.ball = C(r.c, r.r), e.canFT = !1, e.canSnap = !1, N(e, {
		k: "corner",
		side: t
	}), B(e, {
		k: "sp",
		kind: "corner",
		spot: e.ball,
		steps: [
			"a2",
			"d2",
			"a2",
			"d2",
			"a2",
			"d2"
		]
	});
}
function Fe(e, t, n) {
	e.poss = t, e.holder = null, e.gkHands = !1, e.ball = n, e.canFT = !1, e.canSnap = !1;
	let r = w(n);
	for (let n of e.onPitch[j(t)]) E(L(e, n), r) >= 2 || (e.pos[n] = C(...Re(e, L(e, n), (e) => E(e, r) >= 2)));
	let i = Le(e, t, r, !1);
	E(L(e, i), r) > 1 && (e.pos[i] = C(...Re(e, L(e, i), (e) => E(e, r) === 1))), B(e, {
		k: "sp",
		kind: "fk",
		spot: n,
		steps: [
			"a2",
			"d2",
			"a2",
			"d2",
			"a3",
			"d2"
		]
	});
}
function Ie(e, t, n) {
	let r = j(t), i = n && e.onPitch[t].includes(n) ? n : Le(e, t, w(e.ball), !1), a = R(e, r), o = ge(r);
	for (let t of [...e.onPitch[0], ...e.onPitch[1]]) {
		if (t === i || t === a) continue;
		let n = L(e, t);
		A(n, r) && (e.pos[t] = C(...Re(e, n, (e) => !A(e, r))));
	}
	a && (e.pos[a] = C(r === 0 ? 0 : 36, 12)), e.pos[i] = C(o.c, o.r), e.ball = e.pos[i], e.holder = i, e.gkHands = !1, e.poss = t, e.canFT = !1, e.canSnap = !1, N(e, {
		k: "pen",
		side: t
	}), B(e, {
		k: "pen",
		taker: i
	});
}
function Le(e, t, n, r) {
	let i = null;
	for (let a of e.onPitch[t]) (r || !I(e, a)) && (!i || E(L(e, a), n) < E(L(e, i), n)) && (i = a);
	return i ?? e.onPitch[t][0];
}
function Re(e, t, n) {
	let r = null;
	for (let i = 0; i < 37; i += 1) for (let a = 0; a < 25; a += 1) {
		let o = {
			c: i,
			r: a
		};
		n(o) && !Te(e, C(i, a)) && (!r || E(o, t) < E(r, t)) && (r = o);
	}
	let i = r ?? t;
	return [i.c, i.r];
}
function U(e, t) {
	let n = M(t);
	e.holder = t, e.gkHands = !0, e.ball = e.pos[t], e.poss = n, e.lastTouch = n, e.canFT = !1, e.canSnap = !1, N(e, {
		k: "save",
		side: n
	}), B(e, {
		k: "gk",
		kick: !1
	});
}
function ze(e, t, n, r) {
	let i = R(e, t);
	if (i && e.holder !== i) for (let t = 0; t < r; t += 1) {
		let t = L(e, i), r = null;
		for (let i of D(t)) Te(e, C(i.c, i.r)) || E(i, n) >= E(t, n) || (!r || E(i, n) < E(r, n) || E(i, n) === E(r, n) && Math.abs(i.r - 12) < Math.abs(r.r - 12)) && (r = i);
		if (!r) return;
		e.pos[i] = C(r.c, r.r);
	}
}
function Be(e, t, n, r, i) {
	let a = M(t), o = M(n);
	P(e) >= F(e, n).resilience && (e.injuries[n] = (e.injuries[n] ?? 0) + 1, N(e, {
		k: "inj",
		side: o,
		pid: n
	}));
	let s = (e.injuries[n] ?? 0) >= 2 && e.bench[o].length > 0, c = b[e.referee].leniency, l = P(e), u = !i.byGk && Ve(e, t, w(r)), d = i.harsh || u, f = "none";
	i.byGk ? l >= c && (f = "yellow") : d ? f = l >= c ? "red" : "yellow" : l >= c && (f = "yellow"), f === "yellow" && (e.yellow[t] = (e.yellow[t] ?? 0) + 1, e.yellow[t] >= 2 && (f = "red")), f !== "none" && (N(e, {
		k: "card",
		side: a,
		pid: t,
		n: f === "red" ? 2 : 1
	}), f === "red" && He(e, t));
	let p = A(w(r), a);
	if (N(e, {
		k: "foul",
		side: a,
		pid: t
	}), f === "red" || s) {
		p ? Ie(e, o, n) : Fe(e, o, r);
		return;
	}
	B(e, {
		k: "foul",
		victim: n,
		culprit: t,
		spot: r,
		sentOff: !1,
		inBox: p,
		move: i.resumeMove
	});
}
function Ve(e, t, n) {
	let r = M(t), i = r === 0 ? n.c : 36 - n.c;
	for (let n of e.onPitch[r]) {
		if (n === t || I(e, n)) continue;
		let a = L(e, n);
		if ((r === 0 ? a.c : 36 - a.c) <= i) return !1;
	}
	return !0;
}
function He(e, t) {
	let n = M(t);
	e.off.push(t), e.onPitch[n] = e.onPitch[n].filter((e) => e !== t), delete e.pos[t], e.holder === t && (e.holder = null);
}
function Ue(e, t, n, r) {
	let i = M(t), a = j(i), o = w(e.ball);
	e.lastTouch = i;
	let s = 0;
	A(o, a) || --s, r.snap && --s, xe(o, i) && --s, s = Math.max(s, -2);
	let c;
	if (r.headerScore !== void 0) c = r.headerScore + s;
	else {
		let n = P(e);
		if (n === 1) {
			N(e, {
				k: "miss",
				side: i,
				pid: t
			}), Me(e, a);
			return;
		}
		c = F(e, t).shooting + n + s;
	}
	let l = O(o, {
		c: i === 0 ? 36 : 0,
		r: n.r
	}), u = R(e, a);
	if (!(r.fk && c >= 9) && r.headerScore === void 0) {
		let t = l.map((e) => C(e.c, e.r));
		for (let n of t) {
			let t = Te(e, n);
			if (!t || M(t) !== a || t === u) continue;
			let r = P(e);
			if (r >= 5 || F(e, t).tackling + r >= 10) {
				H(e, L(e, t), []);
				return;
			}
		}
		let n = null;
		for (let r of e.onPitch[a]) {
			if (r === u || t.includes(e.pos[r])) continue;
			let i = L(e, r);
			l.some((e) => E(e, i) <= 1) && (!n || F(e, r).tackling > F(e, n).tackling) && (n = r);
		}
		if (n) {
			let t = P(e);
			if (t === 6 || F(e, n).tackling + t >= 10) {
				H(e, L(e, n), []);
				return;
			}
		}
	}
	if (!u) {
		ke(e, i);
		return;
	}
	let d = L(e, u), f = Math.abs(d.r - n.r);
	if (f > S.gkDive) {
		ke(e, i);
		return;
	}
	let p = P(e), m = F(e, u).saving + p + (f === S.gkDive ? -1 : 0) + (r.gkPen ?? 0);
	if (c > m) {
		ke(e, i);
		return;
	}
	if (c === m) {
		H(e, o, []);
		return;
	}
	if (P(e) < F(e, u).handling) {
		U(e, u);
		return;
	}
	let h = P(e);
	(a === 0 ? [1, 2] : [4, 5]).includes(h) ? H(e, d, [], "move", h) : Pe(e, i, d);
}
function We(e, t, n, r) {
	if (e.ball = C(t.c, t.r), e.holder = null, e.gkHands = !1, ![...e.onPitch[0], ...e.onPitch[1]].some((r) => !n.includes(r) && E(L(e, r), t) <= 2)) {
		Xe(e, "action");
		return;
	}
	B(e, {
		k: "header",
		stage: e.onPitch[e.poss].some((r) => !n.includes(r) && E(L(e, r), t) <= 2) ? "atk" : "def",
		landing: e.ball,
		ban: n,
		corner: r
	});
}
function Ge(e, t, n, r) {
	return e.onPitch[t].filter((t) => !r.includes(t) && E(L(e, t), n) <= 2);
}
function Ke(e, t, n) {
	e.ball = C(t.c, t.r);
	let r = Te(e, e.ball);
	if (r) {
		let t = M(r);
		e.holder = r, e.gkHands = !1, t !== e.poss && (e.poss = t), e.canFT = !0, e.canSnap = !1, V(e);
		return;
	}
	e.holder = null, qe(e, t, n);
}
function qe(e, t, n) {
	let r = j(e.poss), i = null;
	for (let a of e.onPitch[r]) n.includes(a) || I(e, a) || E(L(e, a), t) > 1 || (!i || F(e, a).tackling > F(e, i).tackling) && (i = a);
	if (i) {
		let t = P(e);
		if (t === 6 || F(e, i).tackling + t >= 10) {
			e.holder = i, e.ball = e.pos[i], e.poss = r, e.canFT = !0, e.canSnap = !1, V(e);
			return;
		}
	}
	Xe(e, "action");
}
function Je(e, t, n, r) {
	e.poss = t;
	let i = t === 0 ? 1 : 4, a = n;
	for (let e = 0; e < S.header; e += 1) {
		let e = pe(a, i);
		if (!T(e.c, e.r)) break;
		a = e;
	}
	e.ball = C(a.c, a.r), e.holder = null, qe(e, a, r);
}
function Ye(e, t) {
	let n = [...e.noMoveNext];
	return e.noMoveNext = [], {
		k: "move",
		step: "a1",
		left: 4,
		moved: n,
		stealUsed: [],
		trails: {},
		from: t
	};
}
function Xe(e, t) {
	B(e, Ye(e, t));
}
function Ze(e, t, n) {
	let r = M(t);
	return Se(L(e, t), r).some((e) => e.c === n.c && e.r === n.r);
}
//#endregion
//#region src/games/counterattack/play.ts
var W = {
	turn: "games.counterattack.errTurn",
	phase: "games.counterattack.errPhase",
	pid: "games.counterattack.errPid",
	cell: "games.counterattack.errCell",
	range: "games.counterattack.errRange",
	path: "games.counterattack.errPath"
}, Qe = (e, t, n) => M(n) === t && e.onPitch[t].includes(n);
function $e(e, t) {
	t.step === "a1" ? (t.step = "d", t.left = 5) : t.step === "d" ? (t.step = "a2", t.left = 2) : et(e, t);
}
function et(e, t) {
	if (e.holder === null) {
		let t = w(e.ball);
		for (let n of [0, 1]) {
			let r = R(e, n);
			if (r && A(t, n) && A(L(e, r), n) && E(L(e, r), t) <= 1 && e.lastTouch !== n) {
				U(e, r);
				return;
			}
		}
	}
	if (t.from === "throw" && e.throwCtx) {
		--e.throwCtx.movesLeft;
		let t = e.throwCtx;
		B(e, {
			k: "throw",
			spot: t.spot,
			thrower: t.thrower,
			movesLeft: t.movesLeft
		});
		return;
	}
	Ee(e), V(e);
}
function tt(e, t) {
	et(e, t);
}
function nt(e, t) {
	e.holder = t, e.ball = e.pos[t], e.gkHands = !1;
	let n = M(t);
	n !== e.poss && (e.poss = n, e.canFT = !0, e.canSnap = !1);
}
function rt(e, t, n, r) {
	let i = e.poss, a = j(i), o = e.holder === n, s = L(e, n);
	for (let c = 0; c < r.length; c += 1) {
		let l = w(r[c]), u = G(e, r[c]);
		if (u) {
			let r = P(e);
			if (r === 1) {
				t.moved.push(n), --t.left, Be(e, u, n, C(s.c, s.r), {
					harsh: !1,
					byGk: !1,
					resumeMove: { ...t }
				});
				return;
			}
			let i = P(e), c = F(e, u).tackling + 1 + r, d = F(e, n).dribbling + i;
			if (t.stealUsed.push(u), d > c) e.noMoveNext.push(u), s = l;
			else if (c > d) {
				e.pos[n] = C(s.c, s.r), o && (e.ball = e.pos[n]), e.noMoveNext.push(n), e.holder = u, e.poss = a, e.gkHands = !1, e.canFT = !0, e.canSnap = !1, N(e, {
					k: "steal",
					side: a,
					pid: u
				}), tt(e, t);
				return;
			} else {
				e.pos[n] = C(s.c, s.r), o && (e.ball = e.pos[n]), H(e, L(e, u), [n, u]);
				return;
			}
		} else if (e.pos[n] = r[c], o && (e.ball = r[c]), !o && e.holder === null && r[c] === e.ball && (nt(e, n), I(e, n) && A(l, i))) {
			U(e, n);
			return;
		}
		if (o) {
			for (let i of e.onPitch[a]) if (!t.stealUsed.includes(i) && e.pos[i] && E(L(e, i), l) === 1) {
				if (t.stealUsed.push(i), I(e, i) && A(L(e, i), a)) {
					let a = P(e);
					if (a === 1) {
						t.moved.push(n), --t.left, Be(e, i, n, r[c], {
							harsh: !1,
							byGk: !0,
							resumeMove: { ...t }
						});
						return;
					}
					let o = P(e);
					if (F(e, i).saving + a > F(e, n).dribbling + o) {
						U(e, i);
						return;
					}
					if (F(e, i).saving + a === F(e, n).dribbling + o) {
						H(e, l, [n, i]);
						return;
					}
				} else {
					let o = P(e);
					if (o === 1) {
						t.moved.push(n), --t.left, Be(e, i, n, r[c], {
							harsh: !1,
							byGk: !1,
							resumeMove: { ...t }
						});
						return;
					}
					if (o === 6 || F(e, i).tackling + o >= 10) {
						e.holder = i, e.poss = a, e.gkHands = !1, e.ball = e.pos[i], e.canFT = !0, e.canSnap = !1, N(e, {
							k: "steal",
							side: a,
							pid: i
						}), tt(e, t);
						return;
					}
				}
			}
			A(l, a) && !A(s, a) && ze(e, a, l, 1);
		}
		s = l;
	}
	t.moved.push(n), --t.left, t.left === 0 && $e(e, t);
}
function G(e, t) {
	for (let n of [0, 1]) for (let r of e.onPitch[n]) if (e.pos[r] === t) return r;
	return null;
}
function it(e, t, n, r, i) {
	let a = j(e.poss);
	for (let i of r) if (e.pos[n] = i, e.holder === null && i === e.ball) {
		nt(e, n), I(e, n) && A(w(i), a) ? U(e, n) : tt(e, t);
		return;
	}
	t.moved.push(n), --t.left;
	let o = L(e, n);
	if (e.holder === null && !i && E(o, w(e.ball)) === 1) {
		if (I(e, n) && A(o, a)) {
			U(e, n);
			return;
		}
		let r = P(e);
		if (r === 6 || F(e, n).tackling + r >= 10) {
			nt(e, n), N(e, {
				k: "steal",
				side: a,
				pid: n
			}), tt(e, t);
			return;
		}
	}
	if (i === "reckless") {
		let r = w(e.ball), i = e.onPitch[e.poss].filter((t) => E(L(e, t), r) <= 3).sort((t, n) => E(L(e, t), o) - E(L(e, n), o))[0];
		if (!i) return W.cell;
		if (P(e) <= 2) e.yellow[n] = (e.yellow[n] ?? 0) + 1, N(e, {
			k: "card",
			side: a,
			pid: n,
			n: 1
		}), e.yellow[n] >= 2 && (N(e, {
			k: "card",
			side: a,
			pid: n,
			n: 2
		}), He(e, n));
		else {
			Be(e, n, i, e.pos[i], {
				harsh: !0,
				byGk: !1,
				resumeMove: { ...t }
			});
			return;
		}
	} else if (i === "std" && e.holder && M(e.holder) === e.poss && E(o, L(e, e.holder)) === 1) {
		let r = e.holder, i = L(e, r), s = I(e, n) && A(o, a), c = !s && Ze(e, r, o), l = P(e);
		if (l === 1 || c && l === 2) {
			Be(e, n, r, C(i.c, i.r), {
				harsh: c,
				byGk: s,
				resumeMove: { ...t }
			});
			return;
		}
		let u = P(e), d = (s ? F(e, n).saving : F(e, n).tackling) + l, f = F(e, r).dribbling + u;
		if (d > f) {
			if (s) {
				U(e, n);
				return;
			}
			e.holder = n, e.poss = a, e.gkHands = !1, e.ball = e.pos[n], e.canFT = !0, e.canSnap = !1, N(e, {
				k: "steal",
				side: a,
				pid: n
			}), tt(e, t);
			return;
		}
		if (f > d) {
			let t = D(o).filter((t) => !G(e, C(t.c, t.r))).sort((t, n) => at(e.poss, t) - at(e.poss, n))[0];
			t && (e.pos[r] = C(t.c, t.r), e.ball = e.pos[r], A(t, a) && !A(i, a) && ze(e, a, t, 1));
		} else {
			H(e, i, [r, n]);
			return;
		}
	}
	t.left === 0 && $e(e, t);
}
function at(e, t) {
	return (e === 0 ? 36 - t.c : t.c) * 2 + Math.abs(t.r - 12);
}
function ot(e, t, n, r) {
	let i = e.poss;
	if (!e.holder) return W.phase;
	let a = w(e.ball), o = w(t);
	if (!T(o.c, o.r)) return W.cell;
	if (E(a, o) > n || t === e.ball) return W.range;
	let s = O(a, o);
	for (let t of s) {
		let n = G(e, C(t.c, t.r));
		if (n && M(n) !== i) return W.path;
	}
	if (Ee(e), e.lastTouch = i, r) {
		let t = s.filter((t) => {
			let n = G(e, C(t.c, t.r));
			return !(n && M(n) === i);
		}), n = null, r = -1;
		for (let a of e.onPitch[j(i)]) {
			let i = L(e, a);
			if (!t.some((e) => E(e, i) <= 1)) continue;
			let o = I(e, a) ? F(e, a).saving : F(e, a).tackling;
			o > r && (n = a, r = o);
		}
		if (n) {
			let t = P(e), r = I(e, n), a = r ? F(e, n).saving : F(e, n).tackling;
			if (r ? t >= 5 || a + t >= 10 : t === 6 || a + t >= 10) {
				if (r && A(L(e, n), j(i))) {
					U(e, n);
					return;
				}
				e.holder = n, e.poss = j(i), e.gkHands = !1, e.ball = e.pos[n], e.canFT = !0, e.canSnap = !1, N(e, {
					k: "intercept",
					side: j(i),
					pid: n
				}), V(e);
				return;
			}
		}
	}
	st(e, t, o);
}
function st(e, t, n) {
	e.ball = t;
	let r = G(e, t);
	if (r && M(r) === e.poss) {
		e.holder = r, e.gkHands = !1, e.canFT = !0, e.canSnap = z(n, e.poss);
		let t = j(e.poss);
		A(n, t) && ze(e, t, n, 1);
	} else e.holder = null, e.canFT = !1, e.canSnap = !1;
	V(e);
}
function ct(e, t, n) {
	let r = e.poss, i = e.holder;
	if (!i) return W.phase;
	let a = w(e.ball), o = w(t);
	if (!T(o.c, o.r)) return W.cell;
	let s = E(a, o);
	if (!n && (s < 3 || s > S.highPass)) return W.range;
	let c = G(e, t);
	if (!c || M(c) !== r || c === i || n && ve(o, r)) return W.cell;
	let l = O(a, o)[0];
	if (l) {
		let t = G(e, C(l.c, l.r));
		if (t && M(t) !== r) return W.path;
	}
	Ee(e), e.lastTouch = r, B(e, {
		k: "hp",
		who: "atk",
		to: t,
		gkKick: n
	});
}
function lt(e, t) {
	let n = e.holder, r = P(e);
	F(e, n).highPass + r >= 8 ? We(e, w(t), [n], !1) : H(e, w(t), [], "header");
}
function ut(e, t) {
	let n = e.poss, r = e.holder;
	if (!r) return W.phase;
	let i = w(e.ball), a = w(t);
	if (!T(a.c, a.r)) return W.cell;
	if (ve(i, n) && ve(a, n)) return W.range;
	for (let t of e.onPitch[n]) if (E(L(e, t), a) < 5) return W.cell;
	for (let t of e.onPitch[j(n)]) if (E(L(e, t), a) <= 1) return W.cell;
	let o = O(i, a)[0];
	if (o) {
		let t = G(e, C(o.c, o.r));
		if (t && M(t) !== n) return W.path;
	}
	Ee(e), e.lastTouch = n;
	let s = P(e);
	if (F(e, r).highPass + s >= 9) {
		e.ball = t, e.holder = null;
		let r = a, i = R(e, j(n));
		i && ze(e, j(n), r, F(e, i).pace + +!!A(r, j(n))), Xe(e, "action");
	} else H(e, a, [], "move");
}
function dt(e, t, n, r) {
	let i = e.poss, a = j(i), o = w(t.landing), s = r ? R(e, a) : null, c = [
		...t.atkContest ?? [],
		...n,
		...s ? [s] : []
	];
	e.noMoveNext.push(...c);
	let l = (t) => {
		let n = P(e), r = +(E(L(e, t), o) === 2);
		return {
			pid: t,
			total: (I(e, t) ? F(e, t).aerial : F(e, t).heading) + n - r,
			nat: n
		};
	}, u = (t.atkContest ?? []).map(l), d = [...n.map(l), ...s ? [l(s)] : []], f = u.length ? u.reduce((e, t) => t.total > e.total ? t : e) : null, p = d.length ? d.reduce((e, t) => t.total > e.total ? t : e) : null;
	if (!p) {
		if (t.intent === "control") {
			let n = (t.atkContest ?? [])[0];
			if (!n) {
				qe(e, o, c);
				return;
			}
			let r = P(e), i = +(E(L(e, n), o) === 2);
			F(e, n).dribbling + r - i >= 9 ? (e.holder = n, e.gkHands = !1, e.ball = e.pos[n], e.canFT = !0, e.canSnap = !1, V(e)) : H(e, L(e, n), c);
			return;
		}
		if (!f) {
			qe(e, o, c);
			return;
		}
		t.intent === "shot" ? ft(e, i, f, o, c) : Ke(e, w(t.target), c);
		return;
	}
	if (!f || p.total > f.total) {
		s && p.pid === s ? U(e, s) : Je(e, a, o, c);
		return;
	}
	if (f.total > p.total) {
		if (t.intent === "shot") {
			if (f.nat === 1) {
				N(e, {
					k: "miss",
					side: i
				}), Me(e, a);
				return;
			}
			if (s) {
				ke(e, i);
				return;
			}
			ft(e, i, f, o, c);
			return;
		}
		Ke(e, w(t.target), c);
		return;
	}
	H(e, o, c);
}
function ft(e, t, n, r, i) {
	let a = j(t);
	if (n.nat === 1) {
		N(e, {
			k: "miss",
			side: t
		}), Me(e, a);
		return;
	}
	let o = R(e, a);
	if (!o) {
		ke(e, t);
		return;
	}
	let s = L(e, o), c = Math.abs(s.r - r.r);
	if (c > S.gkDive) {
		ke(e, t);
		return;
	}
	let l = P(e), u = F(e, o).saving + l + (c === S.gkDive ? -1 : 0);
	if (n.total > u) {
		ke(e, t);
		return;
	}
	if (n.total === u) {
		H(e, r, i);
		return;
	}
	if (P(e) < F(e, o).handling) {
		U(e, o);
		return;
	}
	let d = P(e);
	(a === 0 ? [1, 2] : [4, 5]).includes(d) ? H(e, s, [], "move", d) : Pe(e, t, s);
}
function pt(e, t, n) {
	let r = e.mode;
	switch (t.type) {
		case "startMove":
			if (n !== e.poss) return W.turn;
			if (r.k === "action") {
				e.mode = Ye(e, "action");
				return;
			}
			if (r.k === "throw" && r.thrower && r.movesLeft > 0) {
				e.mode = Ye(e, "throw");
				return;
			}
			return W.phase;
		case "mv": {
			if (r.k !== "move" || r.step !== "a1" && r.step !== "a2" || n !== e.poss) return W.turn;
			if (!Qe(e, n, t.pid) || r.moved.includes(t.pid)) return W.pid;
			let i = r.step === "a2" ? 2 : F(e, t.pid).pace, a = t.path.filter((t) => {
				let r = G(e, t);
				return r !== null && M(r) !== n;
			}).length;
			if (t.path.length + a > i) return W.range;
			let o = gt(e, n, t.pid, t.path, e.holder === t.pid);
			if (o) return o;
			let s = e.pos[t.pid], c = rt(e, r, t.pid, t.path), l = t.path.lastIndexOf(e.pos[t.pid]);
			return r.trails[t.pid] = [s, ...t.path.slice(0, l + 1)], c;
		}
		case "mvd": {
			if (r.k !== "move" || r.step !== "d" || n !== j(e.poss)) return W.turn;
			if (!Qe(e, n, t.pid) || r.moved.includes(t.pid)) return W.pid;
			if (t.path.length > F(e, t.pid).pace) return W.range;
			for (let n of t.path) {
				let t = w(n);
				if (!T(t.c, t.r)) return W.cell;
				if (G(e, n)) return W.path;
			}
			let i = L(e, t.pid);
			for (let e of t.path) {
				let t = w(e);
				if (E(i, t) !== 1) return W.path;
				i = t;
			}
			let a = e.pos[t.pid], o = it(e, r, t.pid, t.path, t.tackle), s = t.path.lastIndexOf(e.pos[t.pid]);
			return r.trails[t.pid] = [a, ...t.path.slice(0, s + 1)], o;
		}
		case "mvStep":
			if (r.k !== "move") return W.phase;
			if (n !== (r.step === "d" ? j(e.poss) : e.poss)) return W.turn;
			$e(e, r);
			return;
		case "pass":
			if (r.k !== "action" || n !== e.poss) return W.turn;
			if (!e.holder || M(e.holder) !== n) return W.phase;
			if (t.kind === "std") return ot(e, t.to, S.standard, !0);
			if (t.kind === "ft") {
				if (!e.canFT) return W.phase;
				let r = w(t.to);
				if (!T(r.c, r.r)) return W.cell;
				if (E(w(e.ball), r) > S.firstTime || t.to === e.ball) return W.range;
				Ee(e), e.lastTouch = n, B(e, {
					k: "ft",
					who: "atk",
					to: t.to
				});
				return;
			}
			return t.kind === "high" ? ct(e, t.to, !1) : ut(e, t.to);
		case "shoot": {
			if (r.k !== "action" || n !== e.poss || !e.holder || M(e.holder) !== n) return W.turn;
			let i = ht(e, n, t.to);
			if (mt(i)) return i;
			Ee(e), Ue(e, e.holder, i, {});
			return;
		}
		case "snapshot": {
			let i = e.holder;
			if (!i || M(i) !== n || n !== e.poss) return W.turn;
			if (!(r.k === "action" && e.canSnap || r.k === "move" && r.step !== "d")) return W.phase;
			if (!z(w(e.ball), n)) return W.range;
			let a = ht(e, n, t.to);
			if (mt(a)) return a;
			B(e, {
				k: "snap",
				shooter: i,
				to: t.to
			});
			return;
		}
		case "snapMove":
		case "snapSkip": {
			if (r.k !== "snap" || n !== j(e.poss)) return W.turn;
			let i;
			if (t.type === "snapMove") {
				if (!Qe(e, n, t.pid)) return W.pid;
				let r = w(t.to);
				if (!T(r.c, r.r) || G(e, t.to)) return W.cell;
				let a = E(L(e, t.pid), r);
				if (a < 1 || a > 2) return W.range;
				e.pos[t.pid] = t.to, I(e, t.pid) && a === 2 && (i = -1);
			}
			Ee(e);
			let a = r.shooter;
			Ue(e, a, w(r.to), {
				snap: !0,
				gkPen: i
			});
			return;
		}
		case "hpMove":
		case "hpSkip":
			if (r.k !== "hp") return W.phase;
			if (n !== (r.who === "atk" ? e.poss : j(e.poss))) return W.turn;
			if (t.type === "hpMove") {
				if (!Qe(e, n, t.pid)) return W.pid;
				let r = w(t.to);
				if (!T(r.c, r.r) || G(e, t.to)) return W.cell;
				if (E(L(e, t.pid), r) < 1 || E(L(e, t.pid), r) > 3) return W.range;
				e.pos[t.pid] = t.to;
			}
			if (r.who === "atk") {
				r.who = "def";
				return;
			}
			lt(e, r.to);
			return;
		case "ftMove":
		case "ftSkip":
			if (r.k !== "ft") return W.phase;
			if (n !== (r.who === "atk" ? e.poss : j(e.poss))) return W.turn;
			if (t.type === "ftMove") {
				if (!Qe(e, n, t.pid)) return W.pid;
				let i = w(t.to);
				if (!T(i.c, i.r) || G(e, t.to)) return W.cell;
				if (E(L(e, t.pid), i) !== 1) return W.range;
				e.pos[t.pid] = t.to, r.moved = t.pid;
			}
			if (r.who === "atk") {
				r.who = "def";
				return;
			}
			_t(e, r);
			return;
		case "headAtk": {
			if (r.k !== "header" || r.stage !== "atk" || n !== e.poss) return W.turn;
			let i = w(r.landing), a = Ge(e, n, i, r.ban), o = Ge(e, j(n), i, r.ban);
			for (let e of t.contesters) if (!a.includes(e)) return W.pid;
			if (t.intent === "control" && (o.length > 0 || r.corner)) return W.phase;
			if (t.intent === "shot" && !(A(i, j(n)) || E(i, {
				c: n === 0 ? 36 : 0,
				r: Math.max(k[0], Math.min(k[6], i.r))
			}) <= S.header)) return W.range;
			if (t.intent === "pass") {
				if (!t.target) return W.cell;
				let e = w(t.target);
				if (!T(e.c, e.r) || E(i, e) > S.header) return W.range;
			}
			if (t.intent !== "control" && t.contesters.length === 0) return W.pid;
			r.intent = t.intent, r.target = t.target, r.atkContest = t.contesters, r.stage = "def";
			return;
		}
		case "headDef": {
			if (r.k !== "header" || r.stage !== "def" || n !== j(e.poss)) return W.turn;
			let i = w(r.landing), a = Ge(e, n, i, r.ban).filter((t) => !I(e, t));
			for (let e of t.contesters) if (!a.includes(e)) return W.pid;
			if (t.gk) {
				let t = R(e, n);
				if (!t || !Ge(e, n, i, r.ban).includes(t)) return W.pid;
			}
			dt(e, r, t.contesters, t.gk);
			return;
		}
		case "foulChoice":
			if (r.k !== "foul" || n !== e.poss) return W.turn;
			if (t.take) {
				r.inBox ? Ie(e, n, r.victim) : Fe(e, n, r.spot);
				return;
			}
			if (r.move) {
				let t = r.move;
				e.mode = t, t.left === 0 && $e(e, t);
				return;
			}
			V(e);
			return;
		case "spPlace": {
			if (r.k !== "sp" || r.steps.length === 0) return W.phase;
			let i = r.steps[0];
			if (n !== (i[0] === "a" ? e.poss : j(e.poss))) return W.turn;
			let a = Number(i[1]);
			if (t.moves.length + +!!t.sub > a) return W.range;
			let o = /* @__PURE__ */ new Set();
			for (let i of t.moves) {
				if (!Qe(e, n, i.pid)) return W.pid;
				let t = w(i.to);
				if (!T(t.c, t.r) || G(e, i.to) || o.has(i.to) || r.kind === "fk" && n !== e.poss && E(t, w(e.ball)) < 2 || r.kind === "corner" && n !== e.poss && E(t, w(r.spot)) < 2) return W.cell;
				o.add(i.to);
			}
			for (let n of t.moves) e.pos[n.pid] = n.to;
			if (t.sub) {
				let { out: r, in: i } = t.sub, a = e.onPitch[n].indexOf(r), o = e.bench[n].indexOf(i);
				if (a < 0 || o < 0) return W.pid;
				e.onPitch[n][a] = i, e.bench[n][o] = r, e.pos[i] = e.pos[r], delete e.pos[r];
				let s = e.home[`${n}:${e.num[r]}`];
				s && (e.home[`${n}:${e.num[i]}`] = s), e.injuries[r] !== void 0 && (e.injuries[i] = 0, delete e.injuries[r]), N(e, {
					k: "sub",
					side: n,
					pid: i
				});
			}
			r.steps.shift();
			return;
		}
		case "fkTake":
			if (r.k !== "sp" || r.kind !== "fk" || r.steps.length > 0 || n !== e.poss) return W.turn;
			if (!Qe(e, n, t.by) || E(L(e, t.by), w(e.ball)) > 1) return W.pid;
			for (let t of e.onPitch[j(n)]) if (E(L(e, t), w(e.ball)) < 2) return W.path;
			if (e.holder = t.by, t.kind === "shot") {
				let r = ht(e, n, t.to);
				if (mt(r)) return r;
				if (!z(w(e.ball), n)) return W.range;
				Ee(e), e.lastTouch = n, Ue(e, t.by, r, { fk: !0 });
				return;
			}
			return t.kind === "std" ? ot(e, t.to, S.standard, !0) : t.kind === "high" ? ct(e, t.to, !1) : ut(e, t.to);
		case "cornerTake": {
			if (r.k !== "sp" || r.kind !== "corner" || r.steps.length > 0 || n !== e.poss) return W.turn;
			let i = j(n), a = w(t.to);
			if (t.kind === "high") {
				if (!A(a, i)) return W.cell;
				Ee(e), e.lastTouch = n, We(e, a, [], !0);
				return;
			}
			e.holder = Le(e, n, w(e.ball), !1), e.lastTouch = n;
			let o = ot(e, t.to, S.firstTime, !0);
			return o || (e.canFT = !1), o;
		}
		case "penTake": {
			if (r.k !== "pen" || n !== e.poss) return W.turn;
			let i = ht(e, n, t.to);
			if (mt(i)) return i;
			Ee(e), e.lastTouch = n;
			let a = j(n), o = P(e);
			if (o === 1) {
				N(e, {
					k: "miss",
					side: n,
					pid: r.taker
				}), Me(e, a);
				return;
			}
			let s = F(e, r.taker).shooting + o, c = R(e, a);
			if (!c) {
				ke(e, n);
				return;
			}
			let l = P(e), u = F(e, c).saving + l - 2;
			if (s > u) ke(e, n);
			else if (s === u) H(e, w(e.ball), [r.taker]);
			else if (P(e) < F(e, c).handling) U(e, c);
			else {
				let t = P(e);
				(a === 0 ? [1, 2] : [4, 5]).includes(t) ? H(e, L(e, c), [], "move", t) : Pe(e, n, L(e, c));
			}
			return;
		}
		case "throwPick":
			if (r.k !== "throw" || n !== e.poss || r.thrower) return W.turn;
			if (!Qe(e, n, t.pid)) return W.pid;
			e.pos[t.pid] = r.spot, e.holder = t.pid, e.gkHands = !1, r.thrower = t.pid, e.throwCtx && (e.throwCtx.thrower = t.pid);
			return;
		case "throwTake": {
			if (r.k !== "throw" || n !== e.poss || !r.thrower) return W.turn;
			let i = w(t.to);
			if (!T(i.c, i.r) || E(w(r.spot), i) > S.firstTime) return W.range;
			if (t.kind === "head") {
				let a = G(e, t.to);
				if (!a || M(a) !== n || a === r.thrower) return W.cell;
				e.throwCtx = null, Ee(e), e.lastTouch = n, We(e, i, [r.thrower], !1);
				return;
			}
			let a = ot(e, t.to, S.firstTime, !0);
			return a || (e.throwCtx = null), a;
		}
		case "gkThrow": return r.k !== "gk" || r.kick || n !== e.poss || !e.gkHands ? W.turn : ot(e, t.to, S.standard, !1);
		case "gkKick": return r.k !== "gk" || r.kick || n !== e.poss || !e.gkHands ? W.turn : ct(e, t.to, !0);
		case "gkDrop":
			if (r.k !== "gk" || r.kick || n !== e.poss) return W.turn;
			e.gkHands = !1, V(e);
			return;
		case "gkTake": return r.k !== "gk" || !r.kick || n !== e.poss ? W.turn : t.kind === "std" ? ot(e, t.to, S.standard, !0) : ct(e, t.to, !0);
		default: return W.phase;
	}
}
function mt(e) {
	return typeof e == "string";
}
function ht(e, t, n) {
	let r = w(n), i = t === 0 ? 37 : -1;
	return r.c !== i || !be(r.r) ? W.cell : z(w(e.ball), t) ? r : W.range;
}
function gt(e, t, n, r, i) {
	let a = L(e, n);
	for (let n = 0; n < r.length; n += 1) {
		let o = w(r[n]);
		if (!T(o.c, o.r)) return W.cell;
		if (E(a, o) !== 1) return W.path;
		let s = G(e, r[n]);
		if (s && (M(s) === t || !i || n === r.length - 1)) return W.path;
		a = o;
	}
}
function _t(e, t) {
	let n = e.poss, r = e.holder, i = w(e.ball), a = w(t.to), o = O(i, a);
	if (t.moved && M(t.moved) !== n && E(L(e, t.moved), i) === 1) {
		let a = P(e);
		if (a === 1) {
			Be(e, t.moved, r, C(i.c, i.r), {
				harsh: !1,
				byGk: !1,
				resumeMove: null
			});
			return;
		}
		if (a === 6 || F(e, t.moved).tackling + a >= 10) {
			e.holder = t.moved, e.poss = j(n), e.gkHands = !1, e.ball = e.pos[t.moved], e.canFT = !0, e.canSnap = !1, N(e, {
				k: "intercept",
				side: j(n),
				pid: t.moved
			}), V(e);
			return;
		}
	}
	let s = o.filter((t) => {
		let r = G(e, C(t.c, t.r));
		return !(r && M(r) === n);
	}), c = null, l = -1;
	for (let t of e.onPitch[j(n)]) {
		let n = L(e, t);
		if (!s.some((e) => E(e, n) <= 1)) continue;
		let r = I(e, t) ? F(e, t).saving : F(e, t).tackling;
		r > l && (c = t, l = r);
	}
	if (c) {
		let r = P(e), i = I(e, c), a = i ? F(e, c).saving : F(e, c).tackling, o = c === t.moved;
		if (i || o ? r >= 5 || a + r >= 10 : r === 6 || a + r >= 10) {
			if (i && A(L(e, c), j(n))) {
				U(e, c);
				return;
			}
			e.holder = c, e.poss = j(n), e.gkHands = !1, e.ball = e.pos[c], e.canFT = !0, e.canSnap = !1, N(e, {
				k: "intercept",
				side: j(n),
				pid: c
			}), V(e);
			return;
		}
	}
	st(e, t.to, a);
}
//#endregion
//#region src/games/counterattack/schema.ts
var K = t.string().regex(/^-?\d+,\d+$/), q = t.string().regex(/^[01]:\d+$/), vt = t.union([t.literal(0), t.literal(1)]), yt = t.object({
	squadMode: t.enum(["preset", "draft"]).catch("preset"),
	halfLength: t.union([
		t.literal(12),
		t.literal(20),
		t.literal(30)
	]).catch(20)
}).default({
	squadMode: "preset",
	halfLength: 20
}), bt = t.int().min(0).max(103), xt = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draftPick"),
		ref: bt
	}),
	t.object({
		type: t.literal("lineupMove"),
		pid: q,
		to: K
	}),
	t.object({
		type: t.literal("lineupSwap"),
		out: q,
		in: q
	}),
	t.object({ type: t.literal("lineupConfirm") }),
	t.object({ type: t.literal("startMove") }),
	t.object({
		type: t.literal("pass"),
		kind: t.enum([
			"std",
			"high",
			"long",
			"ft"
		]),
		to: K
	}),
	t.object({
		type: t.literal("shoot"),
		to: K
	}),
	t.object({
		type: t.literal("snapshot"),
		to: K
	}),
	t.object({
		type: t.literal("mv"),
		pid: q,
		path: t.array(K).min(1).max(8)
	}),
	t.object({ type: t.literal("mvStep") }),
	t.object({
		type: t.literal("mvd"),
		pid: q,
		path: t.array(K).min(1).max(8),
		tackle: t.enum(["std", "reckless"]).optional()
	}),
	t.object({
		type: t.literal("hpMove"),
		pid: q,
		to: K
	}),
	t.object({ type: t.literal("hpSkip") }),
	t.object({
		type: t.literal("ftMove"),
		pid: q,
		to: K
	}),
	t.object({ type: t.literal("ftSkip") }),
	t.object({
		type: t.literal("headAtk"),
		intent: t.enum([
			"pass",
			"shot",
			"control"
		]),
		contesters: t.array(q).max(2),
		target: K.optional()
	}),
	t.object({
		type: t.literal("headDef"),
		contesters: t.array(q).max(2),
		gk: t.boolean()
	}),
	t.object({
		type: t.literal("snapMove"),
		pid: q,
		to: K
	}),
	t.object({ type: t.literal("snapSkip") }),
	t.object({
		type: t.literal("foulChoice"),
		take: t.boolean()
	}),
	t.object({
		type: t.literal("spPlace"),
		moves: t.array(t.object({
			pid: q,
			to: K
		})).max(3),
		sub: t.object({
			out: q,
			in: q
		}).optional()
	}),
	t.object({
		type: t.literal("fkTake"),
		kind: t.enum([
			"std",
			"high",
			"long",
			"shot"
		]),
		by: q,
		to: K
	}),
	t.object({
		type: t.literal("cornerTake"),
		kind: t.enum(["high", "low"]),
		to: K
	}),
	t.object({
		type: t.literal("penTake"),
		to: K
	}),
	t.object({
		type: t.literal("throwPick"),
		pid: q
	}),
	t.object({
		type: t.literal("throwTake"),
		kind: t.enum(["feet", "head"]),
		to: K
	}),
	t.object({
		type: t.literal("gkThrow"),
		to: K
	}),
	t.object({
		type: t.literal("gkKick"),
		to: K
	}),
	t.object({ type: t.literal("gkDrop") }),
	t.object({
		type: t.literal("gkTake"),
		kind: t.enum(["std", "kick"]),
		to: K
	})
]), St = t.object({
	k: t.literal("move"),
	step: t.enum([
		"a1",
		"d",
		"a2"
	]),
	left: t.int().nonnegative(),
	moved: t.array(q),
	stealUsed: t.array(q),
	trails: t.record(t.string(), t.array(K)),
	from: t.enum(["action", "throw"])
}), Ct = t.discriminatedUnion("k", [
	t.object({ k: t.literal("action") }),
	St,
	t.object({
		k: t.literal("ft"),
		who: t.enum(["atk", "def"]),
		to: K,
		moved: q.optional()
	}),
	t.object({
		k: t.literal("hp"),
		who: t.enum(["atk", "def"]),
		to: K,
		gkKick: t.boolean()
	}),
	t.object({
		k: t.literal("header"),
		stage: t.enum(["atk", "def"]),
		landing: K,
		ban: t.array(q),
		corner: t.boolean(),
		intent: t.enum([
			"pass",
			"shot",
			"control"
		]).optional(),
		target: K.optional(),
		atkContest: t.array(q).optional()
	}),
	t.object({
		k: t.literal("foul"),
		victim: q,
		culprit: q,
		spot: K,
		sentOff: t.boolean(),
		inBox: t.boolean(),
		move: St.nullable()
	}),
	t.object({
		k: t.literal("snap"),
		shooter: q,
		to: K,
		gkPen: t.int().max(0).optional()
	}),
	t.object({
		k: t.literal("sp"),
		kind: t.enum(["fk", "corner"]),
		spot: K,
		steps: t.array(t.enum([
			"a2",
			"d2",
			"a3"
		]))
	}),
	t.object({
		k: t.literal("pen"),
		taker: q
	}),
	t.object({
		k: t.literal("throw"),
		spot: K,
		thrower: q.nullable(),
		movesLeft: t.int().nonnegative()
	}),
	t.object({
		k: t.literal("gk"),
		kick: t.boolean()
	})
]), wt = t.object({
	k: t.enum([
		"kickoff",
		"half",
		"goal",
		"save",
		"miss",
		"loose",
		"foul",
		"card",
		"inj",
		"sub",
		"steal",
		"intercept",
		"pen",
		"corner",
		"throwin",
		"goalkick"
	]),
	side: vt.optional(),
	pid: q.optional(),
	n: t.int().optional()
}), Tt = t.object({
	phase: t.enum([
		"draft",
		"lineup",
		"play",
		"over"
	]),
	seats: t.tuple([t.string(), t.string()]),
	config: yt,
	referee: t.int().min(0).max(3),
	squads: t.tuple([t.array(bt), t.array(bt)]),
	onPitch: t.tuple([t.array(q), t.array(q)]),
	bench: t.tuple([t.array(q), t.array(q)]),
	pos: t.record(t.string(), K),
	num: t.record(t.string(), t.int()),
	injuries: t.record(t.string(), t.int().nonnegative()),
	yellow: t.record(t.string(), t.int().nonnegative()),
	off: t.array(q),
	draft: t.object({
		revealed: t.array(bt),
		turn: vt,
		round: t.int().min(1),
		counts: t.tuple([t.int().nonnegative(), t.int().nonnegative()])
	}).nullable(),
	lineupReady: t.tuple([t.boolean(), t.boolean()]),
	half: t.union([t.literal(1), t.literal(2)]),
	actionsLeft: t.int().nonnegative(),
	scores: t.tuple([t.int().nonnegative(), t.int().nonnegative()]),
	ball: K,
	holder: q.nullable(),
	poss: vt,
	canFT: t.boolean(),
	canSnap: t.boolean(),
	mode: Ct,
	log: t.array(wt)
}), Et = t.object({ mySide: vt.nullable() }), Dt = {
	turn: "games.counterattack.errTurn",
	phase: "games.counterattack.errPhase",
	pid: "games.counterattack.errPid",
	cell: "games.counterattack.errCell"
}, Ot = (e) => ({ code: e });
function kt(e) {
	let t = (t) => e === 0 ? t : 36 - t;
	return [
		{
			c: t(1),
			r: 12
		},
		{
			c: t(7),
			r: 4
		},
		{
			c: t(7),
			r: 9
		},
		{
			c: t(7),
			r: 15
		},
		{
			c: t(7),
			r: 20
		},
		{
			c: t(12),
			r: 4
		},
		{
			c: t(12),
			r: 9
		},
		{
			c: t(12),
			r: 15
		},
		{
			c: t(12),
			r: 20
		},
		{
			c: t(16),
			r: 10
		},
		{
			c: t(16),
			r: 14
		}
	];
}
function At(e) {
	e.phase = "lineup", e.lineupReady = [!1, !1];
	for (let t of [0, 1]) {
		let n = kt(t);
		for (let r = 0; r < e.squads[t].length; r += 1) {
			let i = Ce(t, r), a = r + 1;
			e.num[i] = a, r < 11 ? (e.onPitch[t].push(i), e.pos[i] = `${n[r].c},${n[r].r}`, e.home[`${t}:${a}`] = e.pos[i]) : e.bench[t].push(i);
		}
	}
}
function jt(t, n, r) {
	let i = 0, a = (t) => e(r, i++, t), o = a(b.length), s = a(2), c = {
		players: [n[0], n[1]],
		config: t,
		phase: "draft",
		seed: r,
		cursor: i,
		referee: o,
		squads: [[], []],
		draft: null,
		lineupReady: [!1, !1],
		onPitch: [[], []],
		bench: [[], []],
		pos: {},
		home: {},
		num: {},
		injuries: {},
		yellow: {},
		off: [],
		half: 1,
		actions: 0,
		scores: [0, 0],
		ball: "10,9",
		holder: null,
		gkHands: !1,
		poss: s,
		lastTouch: s,
		kickoffSide: s,
		canFT: !1,
		canSnap: !1,
		noMoveNext: [],
		throwCtx: null,
		mode: { k: "action" },
		log: []
	};
	if (t.squadMode === "draft") {
		let e = [
			0,
			1,
			2,
			3
		], t = e.splice(a(4), 1)[0], n = e.splice(a(3), 1)[0];
		c.squads = [[100 + t], [100 + n]];
		let r = [...ae];
		for (let e = r.length - 1; e > 0; --e) {
			let t = a(e + 1);
			[r[e], r[t]] = [r[t], r[e]];
		}
		c.draft = {
			pool: r,
			revealed: r.splice(0, 4),
			turn: 0,
			round: 1,
			pick: 0
		};
	} else c.squads = [x[0].slice(), x[1].slice()], At(c);
	return {
		state: c,
		fx: []
	};
}
var Mt = (e) => e % 2 == 1 ? 0 : 1;
function Nt(e, t, n) {
	let r = e.draft;
	if (!r) return Dt.phase;
	if (n !== r.turn) return Dt.turn;
	if (!r.revealed.includes(t)) return Dt.pid;
	r.revealed = r.revealed.filter((e) => e !== t), e.squads[n].push(t);
	let i = r.round < 8 ? 4 : 2;
	if (r.pick += 1, r.pick < i) {
		r.turn = j(r.turn);
		return;
	}
	if (r.round >= 8) {
		e.draft = null, At(e);
		return;
	}
	r.round += 1, r.pick = 0, r.turn = Mt(r.round), r.revealed = r.pool.splice(0, 4);
}
function Pt(e, t) {
	return [0, 1].some((n) => e.onPitch[n].some((n) => e.pos[n] === t));
}
function Ft(e, t, n) {
	if (e.lineupReady[n]) return Dt.phase;
	if (t.type === "lineupMove") {
		if (M(t.pid) !== n || !e.onPitch[n].includes(t.pid)) return Dt.pid;
		let r = w(t.to);
		if (!T(r.c, r.r) || !_e(r, n) || Pt(e, t.to)) return Dt.cell;
		e.pos[t.pid] = t.to;
		return;
	}
	if (t.type === "lineupSwap") {
		if (M(t.out) !== n || M(t.in) !== n) return Dt.pid;
		let r = e.onPitch[n].indexOf(t.out), i = e.bench[n].indexOf(t.in);
		if (r < 0 || i < 0) return Dt.pid;
		e.onPitch[n][r] = t.in, e.bench[n][i] = t.out, e.pos[t.in] = e.pos[t.out], delete e.pos[t.out];
		return;
	}
	for (let t of e.onPitch[n]) e.home[`${n}:${e.num[t]}`] = e.pos[t];
	e.lineupReady[n] = !0, e.lineupReady[0] && e.lineupReady[1] && (e.phase = "play", Oe(e, e.kickoffSide), N(e, {
		k: "kickoff",
		side: e.kickoffSide
	}));
}
function It(e, t, n) {
	let r = e.players.indexOf(n.by);
	if (r !== 0 && r !== 1) return Ot(Dt.turn);
	if (e.phase === "over") return Ot(Dt.phase);
	let i = structuredClone(e), a;
	return a = i.phase === "draft" ? t.type === "draftPick" ? Nt(i, t.ref, r) : Dt.phase : i.phase === "lineup" ? t.type === "lineupMove" || t.type === "lineupSwap" || t.type === "lineupConfirm" ? Ft(i, t, r) : Dt.phase : pt(i, t, r), a ? Ot(a) : { state: i };
}
function Lt(e, t) {
	let n = e.players.indexOf(t);
	return {
		public: {
			phase: e.phase,
			seats: e.players,
			config: e.config,
			referee: e.referee,
			squads: e.squads,
			onPitch: e.onPitch,
			bench: e.bench,
			pos: e.pos,
			num: e.num,
			injuries: e.injuries,
			yellow: e.yellow,
			off: e.off,
			draft: e.draft ? {
				revealed: e.draft.revealed,
				turn: e.draft.turn,
				round: e.draft.round,
				counts: [e.squads[0].length - 1, e.squads[1].length - 1]
			} : null,
			lineupReady: e.lineupReady,
			half: e.half,
			actionsLeft: Math.max(0, e.config.halfLength - e.actions),
			scores: e.scores,
			ball: e.ball,
			holder: e.holder,
			poss: e.poss,
			canFT: e.canFT,
			canSnap: e.canSnap,
			mode: e.mode,
			log: e.log
		},
		private: { mySide: n === 0 || n === 1 ? n : null }
	};
}
function Rt(e) {
	if (e.phase !== "over") return { phase: e.phase };
	let [t, n] = e.scores, r = t >= n ? [...e.players] : [e.players[1], e.players[0]];
	return {
		phase: "over",
		winner: t === n ? [...e.players] : [r[0]],
		ranking: r,
		scores: {
			[e.players[0]]: t,
			[e.players[1]]: n
		}
	};
}
var zt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: oe,
	schemas: {
		action: xt,
		publicView: Tt,
		privateView: Et,
		config: yt
	},
	setup: jt,
	reduce: It,
	viewFor: Lt,
	status: Rt
}, Bt = {
	name: "Counter Attack",
	desc: "A two-player football duel: build a squad, set your formation, and score with passing, dribbling, headers and shots",
	rules: "Goal: score more goals than your opponent over two halves; a draw stands, no extra time.\nSetup:\n· Build a 16-player squad (1 goalkeeper, 15 outfield players), or use the preset squads.\n· Draft mode: 8 rounds, 4 players revealed each round, taking turns to pick.\n· Both sides arrange their starting 11 on their own half, then confirm to kick off at the center.\nPlay (on each action the team in possession chooses one):\n· Movement phase: the attacking team first moves 4 players, the defending team then moves 5, and the attacking team finally moves 2 more. Each player may move up to their Pace in hexes.\n· Pass: standard pass up to 11 hexes; first-time pass up to 6 hexes (must have just received the ball).\n· High ball: within 15 onto a teammate; long ball: unlimited range.\n· High and long balls require an accuracy check. Add the player's High Pass attribute to the die roll. A high ball requires a total of at least 8, and a long ball requires at least 9. On failure, the ball becomes loose at its landing spot.\n· Defenders along a pass or shot path automatically attempt to intercept.\n· Shoot: the player must be within 11 hexes of goal or inside the penalty area. Add their Shooting attribute to the die roll and compare it with the goalkeeper's Saving attribute plus the goalkeeper's die roll. A roll of 1 sends the shot off target.\n· Shots from outside the box, snapshots and difficult angles each cost 1 point, capped at 2.\nDuels:\n· When the ball carrier enters a hex adjacent to a defender, that defender automatically attempts a steal. A die roll of 6, or a total of at least 10 from Tackling plus the die roll, wins the ball.\n· The carrier may dribble through an opponent's hex (nutmeg): costs 2 Pace and gives the defender a 1-point bonus.\n· During the defense movement step, a defender may tackle. Add Tackling to their die roll and compare it with the ball carrier's Dribbling plus their die roll. A tackle from behind is a foul on a roll of 1 or 2.\n· A foul may cause an injury, reducing all the injured player's attributes by 1. If the die roll is at least the referee's Leniency, the offending player receives a yellow card. Two yellow cards result in a red card and dismissal.\n· A foul inside the box is a penalty; the attack may instead waive the set piece and play on.\nSet pieces (free kick / corner):\n· Both sides take turns placing players. For a free kick, the attack places 2, defense 2, attack 2, defense 2, attack 3, and defense 2, in that order.\n· Corners: 2 players each, alternating, 6 turns in total.\n· Each placement turn can be skipped; a substitution may be made while placing and costs one placement slot.\n· After a free kick the player by the ball plays a short pass, high ball, long ball or direct shot; a corner is crossed (always contested) or played low.\n· Penalties are set up automatically with non-takers moved out of the box; the keeper saves at a 2-point penalty.\nOther restarts:\n· Up to 2 players per side within 2 hexes of a high ball's landing spot contest the header (Heading + die); the attack may head-pass, head at goal or control.\n· Throw-ins: the attack picks a thrower for up to 6 hexes — to the feet is receivable, to the head is contested; the attack may first move up to 2 players.\n· Goal kicks: the keeper plays from the six-yard box — a standard pass or a high/long kick (not into the opposing final third).\n· With the ball the keeper chooses one of three: throw out, kick long, or drop to feet and play on.\n· After a goal both sides return to their confirmed formations; the conceding side kicks off at the center.\nEnd: each half has an action budget (20 by default, or 12/30); when it runs out the half ends, and goals decide the match.",
	errTurn: "Not your turn",
	errPhase: "Not allowed right now",
	errPid: "Cannot select that player",
	errCell: "Invalid target cell",
	errRange: "Out of range",
	errPath: "Illegal path",
	optSquadMode: "Squad building",
	optSquadPreset: "Preset squads",
	optSquadDraft: "Draft",
	optHalfLength: "Actions per half",
	halfN: "{{n}} actions",
	draftTitle: "Draft",
	draftRound: "Round {{n}}/8",
	draftYourTurn: "Your pick",
	draftWait: "Waiting for opponent…",
	draftPicked: "{{n}} picked",
	lineupTitle: "Set your formation",
	lineupHint: "Tap a player then a cell to move; tap a substitute then a starter to swap",
	lineupSubHint: "Sub selected: tap a starter to complete the swap",
	lineupConfirm: "Confirm formation",
	lineupReady: "Confirmed, waiting…",
	bench: "Bench",
	gkShort: "GK",
	referee: "Referee",
	refereeLeniency: "Leniency {{n}}",
	half: "Half {{n}}",
	actionsLeft: "Actions {{n}}",
	ballLoose: "Loose ball",
	turnMine: "Your turn",
	turnWait: "Waiting",
	turnWatch: "Spectating",
	waitPhase: "Phase",
	waitPossession: "Possession",
	waitBall: "Carrier",
	phaseAction: "Choose a play",
	phaseSetPiece: "Set piece setup",
	zoomNear: "Zoom in",
	zoomFull: "Full pitch",
	actMove: "Move",
	actPassStd: "Pass",
	actPassFT: "First-time",
	actPassHigh: "High ball",
	actPassLong: "Long ball",
	actShoot: "Shoot",
	actSnapshot: "Snapshot",
	actCancel: "Cancel",
	pickTarget: "Pick a target cell",
	moveAtk1: "Attack moves ({{n}} left)",
	moveDef: "Defense moves ({{n}} left)",
	moveAtk2: "Attack again ({{n}} left)",
	moveEnd: "End step",
	moveEndN: "End step ({{n}})",
	tackleStd: "Tackle",
	tackleReckless: "Reckless",
	guideWait: "Waiting for opponent…",
	guideAction: "Your action: move, pass or shoot",
	guidePath: "Tap cells to draw routes; \"End step\" moves all",
	guideAdjust: "Tap a player, then a cell",
	guideSnap: "Snapshot: defense may adjust 1 player by up to 2",
	guideFoul: "Foul: take the set piece, or play on?",
	guideSp: "Tap a player, then an empty cell; tap a sub then a starter to swap",
	guideFk: "Free kick: pick a type, then a target cell",
	guideCorner: "Corner: pick a type, then a target cell",
	guidePen: "Penalty: tap a goal cell",
	guideThrow: "Throw-in: pick a type, then a target cell",
	guideGk: "Keeper ball: pick a type, then a target cell",
	guideGkKick: "Goal kick: pick a type, then a target cell",
	guideAnts: "Tap a highlighted cell",
	spDone: "Done",
	spLeft: "{{n}} left",
	spSubOptional: "Sub (optional)",
	headPrompt: "Pick challengers (up to 2)",
	headPass: "Head pass",
	headShot: "Head at goal",
	headControl: "Control",
	headNone: "No challenge",
	headGk: "Keeper comes",
	ftPrompt: "First-time pass: adjust 1 player by 1",
	hpPrompt: "High ball: adjust 1 player by up to 3",
	adjSkip: "Skip",
	foulTitle: "Foul committed",
	foulTakeFk: "Take free kick",
	foulTakePen: "Take penalty",
	foulPlayOn: "Play on",
	spPlace: "Set pieces (move {{n}})",
	spSub: "Substitute",
	fkStd: "Short pass",
	fkShot: "Direct shot",
	cornerHigh: "Cross",
	cornerLow: "Low ball",
	penTake: "Take penalty",
	throwPick: "Pick the thrower",
	throwFeet: "Throw to feet",
	throwHead: "Throw to head",
	gkThrow: "Throw out",
	gkKick: "Kick long",
	gkDrop: "Drop to feet",
	gkGoalStd: "Short pass",
	gkGoalLong: "Kick long",
	logKickoff: "Kick-off",
	logHalf: "Half time",
	logGoal: "Goal!",
	logSave: "Saved",
	logMiss: "Off target",
	logFoul: "Foul",
	logCardYellow: "Yellow card",
	logCardRed: "Sent off",
	logInj: "Injured",
	logSub: "Substitution",
	logSteal: "Tackled",
	logIntercept: "Intercepted",
	logPen: "Penalty",
	logCorner: "Corner",
	logThrowin: "Throw-in",
	logGoalkick: "Goal kick",
	attrPace: "PAC",
	attrDribbling: "DRI",
	attrHeading: "HEA",
	attrHighPass: "PAS",
	attrResilience: "RES",
	attrShooting: "SHO",
	attrTackling: "TAC",
	attrAerial: "AER",
	attrSaving: "SAV",
	attrHandling: "HAN",
	cardInj: "Injured: all attributes -{{n}}",
	nations: {
		ARG: "Argentina",
		AUS: "Australia",
		BRA: "Brazil",
		CRO: "Croatia",
		ENG: "England",
		GER: "Germany",
		IRL: "Ireland",
		NED: "Netherlands",
		NGA: "Nigeria",
		NIR: "N.Ireland",
		ROU: "Romania",
		SRB: "Serbia",
		BEL: "Belgium",
		BOL: "Bolivia",
		CAN: "Canada",
		CZE: "Czechia",
		ITA: "Italy",
		CIV: "Ivory Coast",
		MNG: "Mongolia",
		USA: "USA",
		ALG: "Algeria",
		FRA: "France",
		GHA: "Ghana",
		MDA: "Moldova",
		NOR: "Norway",
		POR: "Portugal",
		SCO: "Scotland",
		SWE: "Sweden",
		TUR: "Türkiye",
		RSA: "South Africa",
		ESP: "Spain"
	},
	players: /* @__PURE__ */ "RUIZ.LANGDON.NORUEGA.BARISIC.FRUIN.KUCKLICK.MCNULTY.VAN DE KERKHOF.SESAY.MITCHELL.RUSU.PAVLOVIC.WILLEMS.YUGAR.LESSA.TAYLOR.VRABEC.KALLA.O'CONNOR.LONGO.ABRAHAM.TOOTHNAIL.MARELL.WERDEKKER.DELGADO.OZCAN.DIONTE.NAZEF.GILBERT.LITTLEWOOD.GOALEY.IWU.ATTAH.PATRAS.ANDERSEN.RIBEIRO.KERR.ROBBIE.STEWART.NILSSON.EKSTROM.WALTON".split("."),
	gks: [
		"FIRRELL",
		"EUBSINHO",
		"WALKER",
		"NKOSI"
	],
	refs: [
		"WEBSTER",
		"CASTOLO",
		"BAKKER",
		"READ"
	]
}, Vt = {
	name: "绿茵反击",
	desc: "二人足球对决:组建球队、排兵布阵,用传球、过人、头球与射门攻破对方球门",
	rules: "目标:上下两个半场进球多者获胜;平局即平局,无加时。\n准备:\n· 组建 16 人球队(1 名门将、15 名外场球员):可直接用预设两队。\n· 或轮流选秀:共 8 轮,每轮亮出 4 名球员,双方轮流挑选。\n· 双方各自在己方半场布置首发 11 人,确认后中圈开球。\n流程(持球方每次行动四选一):\n· 移动阶段：进攻方先移动4名球员，防守方随后移动5名球员，进攻方最后再移动2名球员。每名球员的移动格数不得超过其速度属性值。\n· 传球:标准传球至多 11 格;一脚传球至多 6 格(须刚接到球)。\n· 高球 15 格内瞄准队友头顶;长传不限距离。\n· 高球与长传需要进行精度判定：将球员的长传属性值与骰子点数相加。高球的合计值至少为8，长传至少为9；判定失败时，球在落点成为松球。\n· 传球与射门路线上的防守者会自动尝试拦截。\n· 射门：球员必须位于距离球门11格以内或禁区内。将射门属性值与骰子点数相加，与门将扑救属性值加上骰子点数的结果比较；骰出1点时，射门直接偏出。\n· 禁区外射门、抢点射门、刁钻角度各减 1 点,合计至多减 2 点。\n对抗:\n· 带球者进入防守球员的相邻格时，防守球员自动尝试抢断。骰出6点，或抢断属性值与骰子点数之和至少为10时，带球者失去控球权。\n· 带球可穿过对方球员脚下(穿裆):耗 2 格速度,对方抢断判定加 1。\n· 在防守方的移动阶段，可以尝试铲球：将抢断属性值与骰子点数相加，与对方的盘带属性值加上骰子点数的结果比较。从背后铲球时，骰出1或2点即构成犯规。\n· 犯规可能造成受伤，使球员的全部属性各降低1点。骰子点数大于或等于裁判宽容度时，犯规球员被出示黄牌；累计两张黄牌后，领到红牌并被罚下。\n· 禁区内犯规判点球;攻方也可放弃定位球,选择继续比赛。\n定位球(任意球/角球):\n· 双方交替摆放球员。任意球依次由进攻方摆放2名、防守方2名、进攻方2名、防守方2名、进攻方3名、防守方2名。\n· 角球攻守交替,每次各摆 2 人,共 6 次。\n· 每次摆放均可跳过;摆放时也可进行换人,一次换人占一个摆放名额。\n· 任意球摆完由球旁球员短传、高球、长传或直接射门;角球可高球传中(落点必争顶)或低平球。\n· 点球自动摆位,非主罚球员退出禁区;门将扑救减 2。\n其他死球:\n· 高球落点 2 格内,双方各派至多2名球员争顶，将各自的头球属性值与骰子点数相加进行比较;攻方可顶传、顶射或停球。\n· 界外球由攻方选一人掷出 ≤6 格:掷向脚下可直接接球,掷向头顶按高球争顶;掷出前攻方可先移动至多 2 人。\n· 球门球由门将在小禁区开出:标准传球或高球长传(不得直入对方进攻三区)。\n· 门将得球后三选一:手抛、大脚开出,或放在脚下继续比赛。\n· 进球后双方自动回到各自确认的阵型,失球方中圈开球。\n结束:每半场有行动数预算(默认 20 次,可选 12/30),用尽即半场结束;全场结束比进球数。",
	errTurn: "现在不是你的回合",
	errPhase: "当前阶段不能这么做",
	errPid: "不能选择这名球员",
	errCell: "目标位置不可用",
	errRange: "超出距离",
	errPath: "路径不合法",
	optSquadMode: "组队方式",
	optSquadPreset: "预设两队",
	optSquadDraft: "轮流选秀",
	optHalfLength: "半场行动数",
	halfN: "{{n}} 行动",
	draftTitle: "选秀",
	draftRound: "第 {{n}}/8 轮",
	draftYourTurn: "轮到你选人",
	draftWait: "等待对方选人…",
	draftPicked: "已选 {{n}} 人",
	lineupTitle: "排兵布阵",
	lineupHint: "点选球员再点目标格移动;点替补再点首发可换人",
	lineupSubHint: "已选替补:再点一名首发球员完成替换",
	lineupConfirm: "确认阵型",
	lineupReady: "已确认,等待对方…",
	bench: "替补席",
	gkShort: "门将",
	referee: "裁判",
	refereeLeniency: "宽容度 {{n}}",
	half: "第 {{n}} 半场",
	actionsLeft: "行动 {{n}}",
	ballLoose: "松球",
	turnMine: "你的回合",
	turnWait: "等待对方",
	turnWatch: "观战中",
	waitPhase: "当前阶段",
	waitPossession: "球权",
	waitBall: "持球球员",
	phaseAction: "选择战术",
	phaseSetPiece: "定位球摆放",
	zoomNear: "近景",
	zoomFull: "全景",
	actMove: "移动",
	actPassStd: "传球",
	actPassFT: "一脚传球",
	actPassHigh: "高球",
	actPassLong: "长传",
	actShoot: "射门",
	actSnapshot: "抢点射门",
	actCancel: "取消",
	pickTarget: "选择目标格",
	moveAtk1: "进攻方移动(剩 {{n}} 人)",
	moveDef: "防守方移动(剩 {{n}} 人)",
	moveAtk2: "进攻方再移动(剩 {{n}} 人)",
	moveEnd: "结束本步",
	moveEndN: "结束本步({{n}})",
	tackleStd: "铲球",
	tackleReckless: "鲁莽铲球",
	guideWait: "等待对方操作…",
	guideAction: "轮到你:移动、传球或射门",
	guidePath: "点目标格画路线,「结束本步」一起移动",
	guideAdjust: "点选球员,再点目标格",
	guideSnap: "抢点射门:防守方可调整 1 人至多 2 格",
	guideFoul: "对方犯规:要定位球,还是继续比赛?",
	guideSp: "点选球员,再点空格摆放;点替补再点首发可换人",
	guideFk: "任意球:选择主罚方式,再点目标格",
	guideCorner: "角球:选择主罚方式,再点目标格",
	guidePen: "主罚点球:点选球门格",
	guideThrow: "界外球:选择掷法,再点目标格",
	guideGk: "门将发球:选择方式,再点目标格",
	guideGkKick: "球门球:选择方式,再点目标格",
	guideAnts: "点蚂蚁线标记的格子",
	spDone: "完成摆放",
	spLeft: "还可摆 {{n}} 人",
	spSubOptional: "换人(可选)",
	headPrompt: "选择争顶球员(至多 2 人)",
	headPass: "头球摆渡",
	headShot: "头球攻门",
	headControl: "停球",
	headNone: "不争顶",
	headGk: "门将出击",
	ftPrompt: "一脚传球:可调整 1 人 1 格",
	hpPrompt: "高球:可调整 1 人至多 3 格",
	adjSkip: "不调整",
	foulTitle: "对方犯规",
	foulTakeFk: "罚任意球",
	foulTakePen: "罚点球",
	foulPlayOn: "有利继续",
	spPlace: "布置定位球(可移动 {{n}} 人)",
	spSub: "换人",
	fkStd: "短传",
	fkShot: "直接射门",
	cornerHigh: "高球传中",
	cornerLow: "低平球",
	penTake: "主罚点球",
	throwPick: "选择掷球者",
	throwFeet: "掷向脚下",
	throwHead: "掷向头顶",
	gkThrow: "手抛球",
	gkKick: "大脚开出",
	gkDrop: "放脚下",
	gkGoalStd: "短传开出",
	gkGoalLong: "大脚开出",
	logKickoff: "开球",
	logHalf: "半场结束",
	logGoal: "进球!",
	logSave: "门将扑救",
	logMiss: "射偏了",
	logFoul: "犯规",
	logCardYellow: "黄牌",
	logCardRed: "红牌罚下",
	logInj: "受伤",
	logSub: "换人",
	logSteal: "断球",
	logIntercept: "拦截",
	logPen: "点球",
	logCorner: "角球",
	logThrowin: "界外球",
	logGoalkick: "球门球",
	attrPace: "速度",
	attrDribbling: "盘带",
	attrHeading: "头球",
	attrHighPass: "长传",
	attrResilience: "体格",
	attrShooting: "射门",
	attrTackling: "抢断",
	attrAerial: "制空",
	attrSaving: "扑救",
	attrHandling: "接球",
	cardInj: "伤病:全属性 -{{n}}",
	nations: {
		ARG: "阿根廷",
		AUS: "澳大利亚",
		BRA: "巴西",
		CRO: "克罗地亚",
		ENG: "英格兰",
		GER: "德国",
		IRL: "爱尔兰",
		NED: "荷兰",
		NGA: "尼日利亚",
		NIR: "北爱尔兰",
		ROU: "罗马尼亚",
		SRB: "塞尔维亚",
		BEL: "比利时",
		BOL: "玻利维亚",
		CAN: "加拿大",
		CZE: "捷克",
		ITA: "意大利",
		CIV: "科特迪瓦",
		MNG: "蒙古",
		USA: "美国",
		ALG: "阿尔及利亚",
		FRA: "法国",
		GHA: "加纳",
		MDA: "摩尔多瓦",
		NOR: "挪威",
		POR: "葡萄牙",
		SCO: "苏格兰",
		SWE: "瑞典",
		TUR: "土耳其",
		RSA: "南非",
		ESP: "西班牙"
	},
	players: /* @__PURE__ */ "鲁伊斯.兰登.诺鲁埃加.巴里西奇.弗鲁因.库克利克.麦克纳尔蒂.范德克霍夫.塞赛.米切尔.鲁苏.帕夫洛维奇.威廉斯.尤加尔.莱萨.泰勒.弗拉贝茨.卡拉.奥康纳.隆戈.亚伯拉罕.图思耐尔.马雷尔.韦德克尔.德尔加多.厄兹詹.迪翁特.纳泽夫.吉尔伯特.利特尔伍德.戈利.伊乌.阿塔.帕特拉斯.安德森.里贝罗.克尔.罗比.斯图尔特.尼尔松.埃克斯特伦.沃尔顿".split("."),
	gks: [
		"法雷尔",
		"尤布西尼奥",
		"沃克",
		"恩科西"
	],
	refs: [
		"韦伯斯特",
		"卡斯托洛",
		"巴克",
		"里德"
	]
}, J = 15, Ht = Math.sqrt(3), Ut = Ht * J * 25.5, Wt = J * 1.5 * 39 + 30, Gt = {
	0: "#0ea5e9",
	1: "#f97316"
}, Kt = "#41b56a", qt = "#258754", Jt = "#104d32", Yt = (() => {
	let e = [];
	for (let t = 0; t < 6; t += 1) {
		let n = Math.PI / 180 * (60 * t + 30);
		e.push(`${(J * Math.cos(n)).toFixed(2)},${(J * Math.sin(n)).toFixed(2)}`);
	}
	return e.join(" ");
})(), Xt = (() => {
	let e = [];
	for (let t = 0; t < 5; t += 1) {
		let n = Math.PI / 180 * (72 * t - 90);
		e.push(`${(J * .27 * Math.cos(n)).toFixed(2)},${(J * .27 * Math.sin(n)).toFixed(2)}`);
	}
	return e.join(" ");
})(), Y = (e, t, n) => {
	let r = Ht * J * (t + .5 * (e & 1)) + Ht * J / 2, i = J * 1.5 * e + J * 2.5;
	return {
		x: r,
		y: n ? Wt - i : i
	};
};
function Zt({ viewMode: e, anchor: t, registerWasDrag: n, children: i }) {
	let s = a(null), c = a(0);
	r(() => {
		n(() => Date.now() - c.current < 250);
	}, [n]);
	let [l, u] = o({
		w: 0,
		h: 0
	}), [d, f] = o({
		x: 20,
		y: 20,
		k: 1
	}), p = a(null);
	r(() => {
		let e = s.current;
		if (!e) return;
		let t = new ResizeObserver(() => u({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let m = `${e}:${l.w}:${l.h}:${e === "near" ? `${Math.round(t.x)}:${Math.round(t.y)}` : ""}`, [h, _] = o("");
	if (h !== m && l.w > 0) {
		_(m);
		let n = Math.min(l.w / Ut, l.h / Wt) * .98;
		if (e === "full") f({
			x: (l.w - Ut * n) / 2,
			y: (l.h - Wt * n) / 2,
			k: n
		});
		else {
			let e = Math.min(3, Math.max(n, Math.min(l.w, l.h) / (Ht * J * 10.5))), r = (t, n, r) => n * e <= r ? (r - n * e) / 2 : Math.min(0, Math.max(r - n * e, r / 2 - t * e));
			f({
				x: r(t.x, Ut, l.w),
				y: r(t.y, Wt, l.h),
				k: e
			});
		}
	}
	let v = (e) => {
		p.current ||= {
			pointers: /* @__PURE__ */ new Map(),
			startD: 0,
			startK: d.k,
			dragging: !1
		}, p.current.pointers.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY,
			startX: e.clientX,
			startY: e.clientY
		}), p.current.pointers.size === 2 && (p.current.startD = 0, p.current.startK = d.k);
	}, y = (e) => {
		if (l.w <= 0) return e;
		let t = (t, n, r) => n * e.k <= r ? (r - n * e.k) / 2 : Math.min(0, Math.max(r - n * e.k, t));
		return {
			...e,
			x: t(e.x, Ut, l.w),
			y: t(e.y, Wt, l.h)
		};
	}, ee = (e) => {
		let t = p.current;
		if (!t || !t.pointers.has(e.pointerId)) return;
		let n = t.pointers.get(e.pointerId);
		if (!n || t.pointers.size === 1 && !t.dragging && Math.hypot(e.clientX - n.startX, e.clientY - n.startY) < 4) return;
		e.currentTarget.hasPointerCapture(e.pointerId) || e.currentTarget.setPointerCapture(e.pointerId);
		let r = e.clientX - (t.dragging ? n.x : n.startX), i = e.clientY - (t.dragging ? n.y : n.startY);
		if (t.dragging = !0, t.pointers.set(e.pointerId, {
			...n,
			x: e.clientX,
			y: e.clientY
		}), t.pointers.size === 1 && n) c.current = Date.now(), f((e) => y({
			...e,
			x: e.x + r,
			y: e.y + i
		}));
		else if (t.pointers.size === 2) {
			c.current = Date.now();
			let [e, n] = [...t.pointers.values()], r = Math.hypot(e.x - n.x, e.y - n.y);
			if (!t.startD) {
				t.startD = r, t.startK = d.k;
				return;
			}
			let i = Math.min(3, Math.max(.4, t.startK * (r / t.startD)));
			f((e) => y({
				...e,
				k: i
			}));
		}
	}, te = (e) => {
		p.current?.pointers.delete(e.pointerId), p.current?.pointers.size === 0 && (p.current = null);
	};
	return /* @__PURE__ */ g("div", {
		className: "ca-viewport",
		ref: s,
		onPointerDown: v,
		onPointerMove: ee,
		onPointerUp: te,
		onPointerCancel: te,
		children: /* @__PURE__ */ g("div", {
			style: {
				transform: `translate(${d.x}px, ${d.y}px) scale(${d.k})`,
				transformOrigin: "0 0"
			},
			children: i
		})
	});
}
function Qt(e, t) {
	let n = e.mode;
	if (n.k !== "move" || !e.pos[t] || n.moved.includes(t)) return null;
	let r = Number(t[0]);
	if (r !== (n.step === "d" ? 1 - e.poss : e.poss)) return null;
	let i = n.step === "a2" ? 2 : ie(e.squads[r][Number(t.slice(2))], e.injuries[t] ?? 0).pace, a = e.holder === t, o = /* @__PURE__ */ new Map();
	for (let t of [0, 1]) for (let n of e.onPitch[t]) e.pos[n] && o.set(e.pos[n], t);
	let s = e.pos[t], c = /* @__PURE__ */ new Map([[s, {
		cost: 0,
		prev: null
	}]]), l = /* @__PURE__ */ new Set();
	for (;;) {
		let e = null, t = Infinity;
		for (let [n, r] of c) !l.has(n) && r.cost < t && (t = r.cost, e = n);
		if (e === null) break;
		l.add(e);
		for (let s of D(w(e))) {
			let l = C(s.c, s.r), u = o.get(l), d = 1;
			if (u !== void 0) {
				if (u === r || n.step === "d" || !a) continue;
				d = 2;
			}
			let f = t + d;
			if (f > i) continue;
			let p = c.get(l);
			(!p || f < p.cost) && c.set(l, {
				cost: f,
				prev: e
			});
		}
	}
	for (let e of [...c.keys()]) {
		let t = o.get(e);
		e !== s && t !== void 0 && t !== r && c.delete(e);
	}
	return c;
}
function $t(e, t, n, r, i) {
	if (t === null) return null;
	let a = /* @__PURE__ */ new Map();
	for (let t of [0, 1]) for (let n of e.onPitch[t]) e.pos[n] && a.set(e.pos[n], n);
	let o = (e) => {
		let t = a.get(e);
		return t ? Number(t[0]) : null;
	}, s = w(e.ball), c = [], l = (e) => {
		for (let t = 0; t < 25; t += 1) for (let n = 0; n < 37; n += 1) e({
			c: n,
			r: t
		}) && c.push(C(n, t));
	}, u = (e, n) => O(e, n).every((e) => {
		let n = o(C(e.c, e.r));
		return n === null || n === t;
	}), d = (e) => {
		let n = O(s, e)[0];
		if (!n) return !0;
		let r = o(C(n.c, n.r));
		return r === null || r === t;
	}, f = (t) => l((n) => C(n.c, n.r) !== e.ball && E(s, n) <= t && u(s, n));
	if (e.phase === "lineup") return !n || e.lineupReady[t] ? null : (l((e) => _e(e, t) && !a.has(C(e.c, e.r))), c);
	if (e.phase !== "play") return null;
	let p = e.mode;
	if (p.k === "ft" || p.k === "hp" || p.k === "snap") {
		let r = p.k === "snap" ? 1 - e.poss : p.who === "atk" ? e.poss : 1 - e.poss;
		if (!n || t !== r || Number(n[0]) !== t || !e.pos[n]) return null;
		let i = p.k === "ft" ? 1 : p.k === "snap" ? 2 : 3, o = w(e.pos[n]);
		return l((e) => {
			let t = E(o, e);
			return t >= 1 && t <= i && !a.has(C(e.c, e.r));
		}), c;
	}
	if (p.k === "sp" && p.steps.length > 0) {
		let r = p.steps[0][0] === "a" ? e.poss : 1 - e.poss;
		if (!n || r !== t || Number(n[0]) !== t) return null;
		let o = p.kind === "fk" ? s : w(p.spot);
		return l((n) => {
			let r = C(n.c, n.r);
			return a.has(r) || i.some((e) => e.to === r) ? !1 : t === e.poss || E(n, o) >= 2;
		}), c;
	}
	if (!r) return null;
	let m = (n) => l((r) => {
		let i = C(r.c, r.r);
		if (o(i) !== t || i === e.ball) return !1;
		let a = E(s, r);
		return !n && (a < 3 || a > S.highPass) || n && ve(r, t) ? !1 : d(r);
	}), h = () => l((n) => {
		if (ve(s, t) && ve(n, t)) return !1;
		for (let r of e.onPitch[t]) if (E(w(e.pos[r]), n) < 5) return !1;
		for (let r of e.onPitch[1 - t]) if (E(w(e.pos[r]), n) <= 1) return !1;
		return d(n);
	}), g = () => {
		if (z(s, t)) for (let e of k) c.push(C(t === 0 ? 37 : -1, e));
	};
	switch (r) {
		case "std":
		case "fkStd":
		case "gkThrow":
		case "gkGoalStd":
			f(S.standard);
			break;
		case "cornerLow":
		case "throwFeet":
			f(S.firstTime);
			break;
		case "ft":
			l((t) => C(t.c, t.r) !== e.ball && E(s, t) <= S.firstTime);
			break;
		case "high":
		case "fkHigh":
			m(!1);
			break;
		case "gkKick":
		case "gkGoalLong":
			m(!0);
			break;
		case "long":
		case "fkLong":
			h();
			break;
		case "shoot":
		case "fkShot":
		case "snapshot":
		case "pen":
			g();
			break;
		case "cornerHigh":
			l((e) => A(e, 1 - t));
			break;
		case "throwHead": {
			if (p.k !== "throw") return null;
			let e = w(p.spot);
			l((n) => {
				let r = C(n.c, n.r);
				return o(r) === t && a.get(r) !== p.thrower && E(e, n) <= S.firstTime;
			});
			break;
		}
		case "headPass": {
			if (p.k !== "header") return null;
			let e = w(p.landing);
			l((t) => E(e, t) <= S.header);
			break;
		}
		default: return null;
	}
	return c;
}
function X({ label: e, onClick: t, active: n, disabled: r, symbol: i }) {
	return /* @__PURE__ */ _("button", {
		type: "button",
		onClick: t,
		disabled: r,
		"aria-pressed": n ?? void 0,
		className: `ca-action ${n ? "ca-action-active" : ""}`,
		children: [i && /* @__PURE__ */ g("span", {
			className: "ca-action-symbol",
			"aria-hidden": !0,
			children: i
		}), /* @__PURE__ */ g("span", { children: e })]
	});
}
var en = (e) => [
	["games.counterattack.attrPace", e.pace],
	["games.counterattack.attrDribbling", e.dribbling],
	["games.counterattack.attrShooting", e.shooting],
	["games.counterattack.attrHeading", e.heading],
	["games.counterattack.attrHighPass", e.highPass],
	["games.counterattack.attrTackling", e.tackling],
	["games.counterattack.attrResilience", e.resilience]
], tn = (e) => [
	["games.counterattack.attrSaving", e.saving],
	["games.counterattack.attrHandling", e.handling],
	["games.counterattack.attrAerial", e.aerial],
	["games.counterattack.attrHighPass", e.highPass],
	["games.counterattack.attrPace", e.pace],
	["games.counterattack.attrDribbling", e.dribbling],
	["games.counterattack.attrResilience", e.resilience]
], nn = {
	0: "#9ca3af",
	1: "#b91c1c",
	2: "#ef4444",
	3: "#f59e0b",
	4: "#84cc16",
	5: "#22c55e",
	6: "#16a34a"
}, rn = {
	ARG: "🇦🇷",
	AUS: "🇦🇺",
	BRA: "🇧🇷",
	CRO: "🇭🇷",
	ENG: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
	GER: "🇩🇪",
	IRL: "🇮🇪",
	NED: "🇳🇱",
	NGA: "🇳🇬",
	ROU: "🇷🇴",
	SRB: "🇷🇸",
	BEL: "🇧🇪",
	BOL: "🇧🇴",
	CAN: "🇨🇦",
	CZE: "🇨🇿",
	ITA: "🇮🇹",
	CIV: "🇨🇮",
	MNG: "🇲🇳",
	USA: "🇺🇸",
	ALG: "🇩🇿",
	FRA: "🇫🇷",
	GHA: "🇬🇭",
	MDA: "🇲🇩",
	NOR: "🇳🇴",
	POR: "🇵🇹",
	SCO: "🏴󠁧󠁢󠁳󠁣󠁴󠁿",
	SWE: "🇸🇪",
	TUR: "🇹🇷",
	RSA: "🇿🇦",
	ESP: "🇪🇸"
};
function an({ rows: e, t }) {
	return /* @__PURE__ */ g("div", {
		className: "grid grid-cols-2 gap-x-2",
		children: e.map(([e, n]) => /* @__PURE__ */ _("p", {
			className: "ca-card-attr flex items-center justify-between font-bold",
			children: [/* @__PURE__ */ g("span", {
				className: "opacity-60",
				children: t(e)
			}), /* @__PURE__ */ g("span", {
				className: "ca-card-badge grid place-items-center rounded-full font-mono tabular-nums text-white",
				style: { backgroundColor: nn[n] },
				children: n
			})]
		}, e))
	});
}
function on({ nation: e, nations: t }) {
	return /* @__PURE__ */ _("p", {
		className: "ca-card-nation mt-0.5 flex items-center gap-1 font-bold opacity-70",
		children: [/* @__PURE__ */ g("span", {
			"aria-hidden": !0,
			children: rn[e] ?? "🏳️"
		}), t[e] ?? e]
	});
}
function sn({ pub: e, pid: t, pname: n, nations: r, t: i }) {
	let a = Number(t[0]), o = e.squads[a][Number(t.slice(2))], s = e.injuries[t] ?? 0, c = re(o), l = ie(o, s), u = c ? tn(l) : en(l);
	return /* @__PURE__ */ _("div", {
		className: "ca-player-card",
		children: [
			/* @__PURE__ */ _("p", {
				className: "ca-card-name flex items-center gap-1 font-black",
				children: [
					/* @__PURE__ */ g("span", {
						className: "inline-block size-3 flex-none rounded-full",
						style: { backgroundColor: Gt[a] }
					}),
					/* @__PURE__ */ _("span", {
						className: "font-mono tabular-nums opacity-60",
						children: ["#", e.num[t]]
					}),
					/* @__PURE__ */ g("span", {
						className: "truncate",
						children: n(o)
					}),
					(e.yellow[t] ?? 0) > 0 && /* @__PURE__ */ g("span", {
						"aria-hidden": !0,
						children: "🟨"
					})
				]
			}),
			/* @__PURE__ */ g(on, {
				nation: (c ? ne[o - 100] : te[o]).nation,
				nations: r
			}),
			/* @__PURE__ */ g("div", {
				className: "mt-1",
				children: /* @__PURE__ */ g(an, {
					rows: u,
					t: i
				})
			}),
			s > 0 && /* @__PURE__ */ g("p", {
				className: "mt-1 text-[10px] font-bold text-amber-600",
				children: i("games.counterattack.cardInj", { n: s })
			})
		]
	});
}
function cn(e) {
	let t = e.public, h = e.private?.mySide ?? null, v = c(), y = s((e) => e.locale) === "zh" ? Vt : Bt, ee = y.nations, ne = (e) => re(e) ? y.gks[e - 100] : y.players[e], b = (t) => e.send(t), [x, ae] = o(null), [S, se] = o({}), [C, T] = o(null), [ce, le] = o("none"), [ue, de] = o([]), [D, fe] = o(!1), [pe, O] = o([]), [k, me] = o(null), [A, he] = o(null), [ge, ve] = o(null), [ye, be] = o(null), xe = t.scores[0], Se = t.scores[1], j = a([xe, Se]);
	r(() => {
		let e = [xe, Se], t = [0, 1].find((t) => e[t] > j.current[t]);
		if (j.current = e, t === void 0) return;
		be(t);
		let n = window.setTimeout(() => be(null), 1600);
		return () => window.clearTimeout(n);
	}, [xe, Se]);
	let M = `${t.phase}:${JSON.stringify(t.mode)}`, [Ce, we] = o(M);
	Ce !== M && (we(M), ae(null), se({}), T(null), le("none"), de([]), fe(!1), O([]), me(null), he(null), ve(null));
	let N = a(() => !1), P = (e) => {
		N.current = e;
	}, F = () => N.current(), [I, L] = o("near"), Te = i(() => {
		let e = /* @__PURE__ */ new Map();
		for (let n of [0, 1]) for (let r of t.onPitch[n]) t.pos[r] && e.set(t.pos[r], r);
		return e;
	}, [t]), R = i(() => x ? Qt(t, x) : null, [t, x]), z = R && x ? [...R.keys()].filter((e) => e !== t.pos[x]) : null, B = i(() => $t(t, h, x, C, pe), [
		t,
		h,
		x,
		C,
		pe
	]), V = i(() => dn(t, h, C, v), [
		t,
		h,
		C,
		v
	]);
	f(V.mine, d);
	let Ee = i(() => {
		if (h === null) return null;
		let e = t.onPitch[h].filter((e) => t.pos[e]);
		if (t.phase === "lineup") return t.lineupReady[h] ? null : e;
		if (t.phase !== "play") return null;
		let n = t.mode;
		if (n.k === "move") return (n.step === "d" ? 1 - t.poss : t.poss) === h ? e.filter((e) => !n.moved.includes(e)) : null;
		if (n.k === "ft" || n.k === "hp") return (n.who === "atk" ? t.poss : 1 - t.poss) === h ? e : null;
		if (n.k === "snap") return t.poss === h ? null : e;
		if (n.k === "header") {
			if ((n.stage === "atk" ? t.poss : 1 - t.poss) !== h) return null;
			let r = w(n.landing);
			return e.filter((e) => !n.ban.includes(e) && !!t.pos[e] && E(w(t.pos[e]), r) <= 2);
		}
		return n.k === "sp" ? n.steps.length === 0 ? null : (n.steps[0][0] === "a" ? t.poss : 1 - t.poss) === h ? e : null : n.k === "throw" && !n.thrower && t.poss === h ? e : null;
	}, [t, h]), De = h === 0, Oe = x && t.pos[x] ? w(t.pos[x]) : t.phase === "lineup" && h !== null ? {
		c: h === 0 ? 6 : 30,
		r: 12
	} : w(t.ball), ke = Y(Oe.c, Oe.r, De), Ae = (r) => e.members.find((e) => e.rid === t.seats[r])?.name ?? v(n[0].nameKey), je = (e) => ne(t.squads[Number(e[0])][Number(e.slice(2))]), H = (e) => h !== null && Number(e[0]) === h, Me = x ?? k ?? ge, Ne = (e) => ve((t) => t === e ? null : e), Pe = (e) => {
		if (F()) return;
		if (t.phase === "lineup" && h !== null) {
			if (t.lineupReady[h]) return;
			if (!H(e)) {
				Ne(e);
				return;
			}
			if (k) {
				t.onPitch[h].includes(e) && b({
					type: "lineupSwap",
					out: e,
					in: k
				}), me(null);
				return;
			}
			ae(x === e ? null : e);
			return;
		}
		if (t.phase !== "play" || h === null) return;
		let n = t.mode;
		if (n.k === "header") {
			if (!((n.stage === "atk" ? t.poss : 1 - t.poss) === h && H(e) && t.pos[e] && !n.ban.includes(e) && E(w(t.pos[e]), w(n.landing)) <= 2)) {
				Ne(e);
				return;
			}
			de((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < 2 ? [...t, e] : t);
			return;
		}
		if (n.k === "throw" && !n.thrower && t.poss === h && H(e)) {
			b({
				type: "throwPick",
				pid: e
			});
			return;
		}
		if (C) {
			Fe(t.pos[e]);
			return;
		}
		if ((n.k === "ft" || n.k === "hp" || n.k === "snap") && H(e)) {
			ae(x === e ? null : e);
			return;
		}
		if (n.k === "sp" && n.steps.length > 0) {
			if ((n.steps[0][0] === "a" ? t.poss : 1 - t.poss) !== h || !H(e)) {
				Ne(e);
				return;
			}
			if (k) {
				if (!A && pe.length >= Number(n.steps[0][1])) return;
				he(e);
				return;
			}
			ae(x === e ? null : e);
			return;
		}
		if (n.k === "move") {
			if ((n.step === "d" ? 1 - t.poss : t.poss) !== h) {
				Ne(e);
				return;
			}
			if (!H(e)) {
				Fe(t.pos[e]);
				return;
			}
			if (n.moved.includes(e)) {
				Ne(e);
				return;
			}
			if (x === e) {
				if (S[e]) {
					let t = { ...S };
					delete t[e], se(t);
				} else ae(null);
				return;
			}
			ae(e);
			return;
		}
		Ne(e);
	}, Fe = (e) => {
		if (h === null || F()) return;
		let n = w(e);
		if (t.phase === "lineup") {
			x && t.lineupReady[h] === !1 && _e(n, h) && !Te.has(e) && b({
				type: "lineupMove",
				pid: x,
				to: e
			});
			return;
		}
		if (t.phase !== "play") return;
		let r = t.mode;
		if (C) {
			if (!B?.includes(e)) return;
			let t = Le(C, e);
			if (!t) return;
			b(t), T(null);
			return;
		}
		if (r.k === "move" && x && R) {
			let n = R.get(e);
			if (!n || n.cost === 0 || !S[x] && Object.keys(S).length >= r.left) return;
			let i = [], a = e;
			for (; a !== null && a !== t.pos[x];) i.unshift(a), a = R.get(a)?.prev ?? null;
			se({
				...S,
				[x]: i
			});
			return;
		}
		if ((r.k === "ft" || r.k === "hp" || r.k === "snap") && x) {
			let i = r.k === "ft" ? 1 : r.k === "snap" ? 2 : 3;
			if (Te.has(e) || E(w(t.pos[x]), n) > i) return;
			b(r.k === "ft" ? {
				type: "ftMove",
				pid: x,
				to: e
			} : r.k === "hp" ? {
				type: "hpMove",
				pid: x,
				to: e
			} : {
				type: "snapMove",
				pid: x,
				to: e
			}), ae(null);
			return;
		}
		if (r.k === "sp" && r.steps.length > 0 && x && H(x)) {
			if (Te.has(e) || pe.some((t) => t.to === e) || !pe.some((e) => e.pid === x) && pe.length + (k && A ? 1 : 0) >= Number(r.steps[0][1])) return;
			O([...pe.filter((e) => e.pid !== x), {
				pid: x,
				to: e
			}]), ae(null);
			return;
		}
	}, Ie = () => {
		if (h === null) return null;
		let e = w(t.ball), n = null, r = 2;
		for (let i of t.onPitch[h]) {
			let a = t.pos[i];
			if (!a) continue;
			let o = E(w(a), e);
			o < r && (n = i, r = o);
		}
		return n;
	}, Le = (e, t) => {
		switch (e) {
			case "std": return {
				type: "pass",
				kind: "std",
				to: t
			};
			case "ft": return {
				type: "pass",
				kind: "ft",
				to: t
			};
			case "high": return {
				type: "pass",
				kind: "high",
				to: t
			};
			case "long": return {
				type: "pass",
				kind: "long",
				to: t
			};
			case "shoot": return {
				type: "shoot",
				to: t
			};
			case "snapshot": return {
				type: "snapshot",
				to: t
			};
			case "fkStd":
			case "fkHigh":
			case "fkLong":
			case "fkShot": {
				let n = Ie();
				return n ? {
					type: "fkTake",
					kind: {
						fkStd: "std",
						fkHigh: "high",
						fkLong: "long",
						fkShot: "shot"
					}[e],
					by: n,
					to: t
				} : null;
			}
			case "cornerHigh": return {
				type: "cornerTake",
				kind: "high",
				to: t
			};
			case "cornerLow": return {
				type: "cornerTake",
				kind: "low",
				to: t
			};
			case "gkThrow": return {
				type: "gkThrow",
				to: t
			};
			case "gkKick": return {
				type: "gkKick",
				to: t
			};
			case "gkGoalStd": return {
				type: "gkTake",
				kind: "std",
				to: t
			};
			case "gkGoalLong": return {
				type: "gkTake",
				kind: "kick",
				to: t
			};
			case "pen": return {
				type: "penTake",
				to: t
			};
			case "throwFeet": return {
				type: "throwTake",
				kind: "feet",
				to: t
			};
			case "throwHead": return {
				type: "throwTake",
				kind: "head",
				to: t
			};
			case "headPass": return {
				type: "headAtk",
				intent: "pass",
				contesters: ue,
				target: t
			};
		}
	};
	if (t.phase === "draft") {
		let e = t.draft?.turn === h;
		return /* @__PURE__ */ g(m, {
			adaptive: !0,
			scroll: !1,
			className: "ca-adaptive",
			children: /* @__PURE__ */ _("div", {
				className: "ca-screen ca-draft",
				children: [
					/* @__PURE__ */ _("div", {
						className: "ca-phase-head",
						children: [/* @__PURE__ */ g("span", {
							className: "text-base font-black",
							children: v("games.counterattack.draftTitle")
						}), /* @__PURE__ */ g("span", {
							className: "font-mono text-sm font-bold tabular-nums",
							children: v("games.counterattack.draftRound", { n: t.draft?.round ?? 1 })
						})]
					}),
					/* @__PURE__ */ g("p", {
						className: "ca-draft-turn text-center text-sm font-bold",
						children: v(e ? "games.counterattack.draftYourTurn" : "games.counterattack.draftWait")
					}),
					/* @__PURE__ */ g("div", {
						className: "ca-draft-choices grid flex-none grid-cols-2 gap-2",
						children: t.draft?.revealed.map((t) => /* @__PURE__ */ _("button", {
							type: "button",
							disabled: !e,
							onClick: () => b({
								type: "draftPick",
								ref: t
							}),
							className: "ca-draft-card card min-h-11 p-2 text-left disabled:opacity-60",
							style: e ? { borderColor: oe.accent } : void 0,
							children: [/* @__PURE__ */ _("div", {
								className: "ca-draft-card-head",
								children: [/* @__PURE__ */ g("span", {
									className: "ca-jersey",
									"aria-hidden": !0,
									children: "★"
								}), /* @__PURE__ */ _("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ g("p", {
										className: "truncate text-sm font-black",
										children: ne(t)
									}), /* @__PURE__ */ g(on, {
										nation: te[t].nation,
										nations: ee
									})]
								})]
							}), /* @__PURE__ */ g("div", {
								className: "mt-0.5",
								children: /* @__PURE__ */ g(an, {
									rows: en(ie(t)),
									t: v
								})
							})]
						}, t))
					}),
					/* @__PURE__ */ g("div", {
						className: "ca-draft-rosters grid min-h-0 flex-1 grid-cols-2 gap-2 overflow-hidden",
						children: [0, 1].map((e) => /* @__PURE__ */ _("div", {
							className: "ca-draft-roster frame min-h-0 overflow-y-auto p-2",
							children: [/* @__PURE__ */ _("p", {
								className: "text-xs font-black",
								style: { color: Gt[e] },
								children: [
									Ae(e),
									" · ",
									v("games.counterattack.draftPicked", { n: t.squads[e].length - 1 })
								]
							}), t.squads[e].map((e) => /* @__PURE__ */ _("p", {
								className: "text-xs opacity-80",
								children: [ne(e), re(e) ? ` (${v("games.counterattack.gkShort")})` : ""]
							}, e))]
						}, e))
					})
				]
			})
		});
	}
	if (t.phase === "lineup") {
		let e = h !== null && t.lineupReady[h], n = h === null ? [] : t.bench[h];
		return /* @__PURE__ */ g(m, {
			adaptive: !0,
			scroll: !1,
			className: "ca-adaptive",
			children: /* @__PURE__ */ _("div", {
				className: "ca-screen ca-lineup",
				children: [
					/* @__PURE__ */ _("div", {
						className: "ca-phase-head",
						children: [/* @__PURE__ */ g("span", {
							className: "text-base font-black",
							children: v("games.counterattack.lineupTitle")
						}), /* @__PURE__ */ _("span", {
							className: "text-xs opacity-80",
							children: [
								v("games.counterattack.referee"),
								": ",
								y.refs[t.referee]
							]
						})]
					}),
					/* @__PURE__ */ _("div", {
						className: "ca-stage",
						children: [
							/* @__PURE__ */ g(Zt, {
								viewMode: I,
								anchor: ke,
								registerWasDrag: P,
								children: /* @__PURE__ */ g(pn, {
									pub: t,
									mySide: h,
									sel: x,
									paths: {},
									reach: B,
									hot: Ee,
									ghosts: null,
									trails: null,
									onTapCell: Fe,
									onTapToken: Pe,
									t: v
								})
							}),
							Me && /* @__PURE__ */ g(sn, {
								pub: t,
								pid: Me,
								pname: ne,
								nations: ee,
								t: v
							}),
							/* @__PURE__ */ _("button", {
								type: "button",
								"aria-label": v(I === "full" ? "games.counterattack.zoomNear" : "games.counterattack.zoomFull"),
								onClick: () => L((e) => e === "full" ? "near" : "full"),
								className: "ca-zoom",
								children: [g(I === "full" ? l : u, {
									size: 18,
									"aria-hidden": !0
								}), /* @__PURE__ */ g("span", { children: v(I === "full" ? "games.counterattack.zoomNear" : "games.counterattack.zoomFull") })]
							})
						]
					}),
					/* @__PURE__ */ _("div", {
						className: "ca-lineup-dock",
						children: [
							/* @__PURE__ */ g("p", {
								className: "flex-none truncate text-center",
								style: k ? { color: "#d7f365" } : void 0,
								children: v(k ? "games.counterattack.lineupSubHint" : "games.counterattack.lineupHint")
							}),
							/* @__PURE__ */ g("div", {
								className: "ca-lineup-bench flex min-h-0 flex-1 flex-nowrap items-center gap-1 overflow-x-auto",
								children: n.map((n) => /* @__PURE__ */ _("button", {
									type: "button",
									disabled: e,
									onClick: () => {
										if (x && h !== null && t.onPitch[h].includes(x)) {
											b({
												type: "lineupSwap",
												out: x,
												in: n
											}), ae(null);
											return;
										}
										me(k === n ? null : n);
									},
									className: "ca-bench-card flex min-h-9 flex-none items-center gap-1 rounded-lg border-2 border-ink/40 bg-surface px-2 font-bold",
									style: k === n ? {
										borderColor: oe.accent,
										backgroundColor: oe.accent,
										color: "#fff"
									} : void 0,
									children: [/* @__PURE__ */ _("span", {
										className: "ca-bench-number font-mono tabular-nums",
										children: ["#", t.num[n]]
									}), ne(t.squads[h ?? 0][Number(n.slice(2))])]
								}, n))
							}),
							/* @__PURE__ */ g("button", {
								type: "button",
								disabled: e,
								onClick: () => b({ type: "lineupConfirm" }),
								className: "flex min-h-11 w-full flex-none items-center justify-center rounded-xl border-2 border-ink text-sm font-black text-white shadow-[2px_2px_0_var(--color-ink)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-none",
								style: { backgroundColor: oe.accent },
								children: v(e ? "games.counterattack.lineupReady" : "games.counterattack.lineupConfirm")
							})
						]
					})
				]
			})
		});
	}
	let Re = t.mode, U = h !== null && t.poss === h, ze = Re.k === "move" ? Re.step === "d" ? 1 - t.poss : t.poss : null, Be = ze !== null && ze === h, Ve = Re.k === "header" ? Re.stage === "atk" ? t.poss : 1 - t.poss : null, He = Re.k === "sp" && Re.steps.length > 0 ? [...pe, ...k && A && t.pos[A] ? [{
		pid: k,
		to: t.pos[A]
	}] : []] : null;
	return /* @__PURE__ */ g(m, {
		adaptive: !0,
		scroll: !1,
		className: "ca-adaptive",
		children: /* @__PURE__ */ _("div", {
			className: "ca-screen ca-play",
			children: [
				/* @__PURE__ */ _("header", {
					className: "ca-score",
					"aria-label": `${Ae(0)} ${t.scores[0]} : ${t.scores[1]} ${Ae(1)}`,
					children: [
						/* @__PURE__ */ _("div", {
							className: `ca-team ca-team-blue ${ye === 0 ? "ca-team-scored" : ""}`,
							children: [/* @__PURE__ */ g("span", {
								className: "ca-team-mark",
								"aria-hidden": !0,
								children: "A"
							}), /* @__PURE__ */ _("div", {
								className: "ca-team-copy",
								children: [/* @__PURE__ */ g("span", {
									className: "ca-team-name",
									children: Ae(0)
								}), /* @__PURE__ */ g("span", {
									className: "ca-team-score",
									children: t.scores[0]
								})]
							})]
						}),
						/* @__PURE__ */ _("div", {
							className: "ca-center-score",
							children: [/* @__PURE__ */ g("strong", { children: v("games.counterattack.half", { n: t.half }) }), /* @__PURE__ */ g("span", { children: v("games.counterattack.actionsLeft", { n: t.actionsLeft }) })]
						}),
						/* @__PURE__ */ _("div", {
							className: `ca-team ca-team-right ca-team-orange ${ye === 1 ? "ca-team-scored" : ""}`,
							children: [/* @__PURE__ */ _("div", {
								className: "ca-team-copy",
								children: [/* @__PURE__ */ g("span", {
									className: "ca-team-name",
									children: Ae(1)
								}), /* @__PURE__ */ g("span", {
									className: "ca-team-score",
									children: t.scores[1]
								})]
							}), /* @__PURE__ */ g("span", {
								className: "ca-team-mark",
								"aria-hidden": !0,
								children: "B"
							})]
						})
					]
				}),
				/* @__PURE__ */ _("div", {
					className: "ca-stage",
					children: [
						/* @__PURE__ */ g(Zt, {
							viewMode: I,
							anchor: ke,
							registerWasDrag: P,
							children: /* @__PURE__ */ g(pn, {
								pub: t,
								mySide: h,
								sel: x,
								paths: S,
								pending: C,
								reach: t.mode.k === "move" ? z : B,
								hot: Ee,
								contest: ue,
								ghosts: He,
								trails: t.mode.k === "move" ? t.mode.trails : null,
								goalSide: ye,
								onTapCell: Fe,
								onTapToken: Pe,
								t: v
							})
						}),
						/* @__PURE__ */ _("div", {
							className: "ca-chip",
							children: [/* @__PURE__ */ g("span", {
								className: "ca-chip-ball",
								"aria-hidden": !0
							}), t.holder ? `${Ae(t.poss)} · #${t.num[t.holder]} ${je(t.holder)}` : v("games.counterattack.ballLoose")]
						}),
						Me && /* @__PURE__ */ g(sn, {
							pub: t,
							pid: Me,
							pname: ne,
							nations: ee,
							t: v
						}),
						ye !== null && /* @__PURE__ */ g("div", {
							className: "ca-goal-splash",
							role: "status",
							children: v("games.counterattack.logGoal")
						}),
						/* @__PURE__ */ _("button", {
							type: "button",
							"aria-label": v(I === "full" ? "games.counterattack.zoomNear" : "games.counterattack.zoomFull"),
							onClick: () => L((e) => e === "full" ? "near" : "full"),
							className: "ca-zoom",
							children: [g(I === "full" ? l : u, {
								size: 18,
								"aria-hidden": !0
							}), /* @__PURE__ */ g("span", { children: v(I === "full" ? "games.counterattack.zoomNear" : "games.counterattack.zoomFull") })]
						})
					]
				}),
				/* @__PURE__ */ _("div", {
					className: "ca-dock",
					children: [
						/* @__PURE__ */ _("div", {
							className: "ca-dock-top",
							children: [/* @__PURE__ */ g("span", {
								className: `ca-turn-tag ${V.mine ? "" : "ca-turn-tag-wait"}`,
								children: h === null ? v("games.counterattack.turnWatch") : V.mine ? v("games.counterattack.turnMine") : v("games.counterattack.turnWait")
							}), /* @__PURE__ */ g(p, {
								log: t.log,
								line: (e) => fn(e, v, {
									num: (e) => t.num[e],
									pname: je
								})
							})]
						}),
						/* @__PURE__ */ g("p", {
							className: `ca-guide ${V.mine ? "" : "ca-guide-wait"}`,
							children: V.text || (t.phase === "over" ? v("session.result.title") : v("games.counterattack.turnWatch"))
						}),
						/* @__PURE__ */ g("div", {
							className: "ca-control-area",
							children: V.mine ? /* @__PURE__ */ g(ln, {
								pub: t,
								mySide: h,
								myPoss: U,
								myMoveStep: Be,
								headerStageSide: Ve,
								paths: S,
								pending: C,
								tackle: ce,
								contest: ue,
								gkIn: D,
								spMoves: pe,
								subSel: k,
								subOut: A,
								pname: ne,
								setPending: T,
								setTackle: le,
								setGkIn: fe,
								setSubSel: me,
								send: b,
								t: v
							}) : /* @__PURE__ */ g(un, {
								pub: t,
								nameOf: Ae,
								t: v
							})
						})
					]
				})
			]
		})
	});
}
function ln(e) {
	let { pub: t, mySide: n, t: r, send: i } = e;
	if (n === null) return /* @__PURE__ */ g("p", {
		className: "flex flex-1 items-center justify-center text-xs opacity-50",
		children: "—"
	});
	let a = t.mode;
	if (a.k === "action") {
		if (!e.myPoss) return /* @__PURE__ */ g("div", { className: "flex-1" });
		let a = t.holder !== null && Number(t.holder[0]) === n;
		return /* @__PURE__ */ _("div", {
			className: "ca-actions",
			children: [
				/* @__PURE__ */ g(X, {
					symbol: "↗",
					label: r("games.counterattack.actMove"),
					onClick: () => i({ type: "startMove" })
				}),
				/* @__PURE__ */ g(X, {
					symbol: "⚽",
					label: r("games.counterattack.actPassStd"),
					disabled: !a,
					active: e.pending === "std",
					onClick: () => e.setPending("std")
				}),
				/* @__PURE__ */ g(X, {
					symbol: "⇢",
					label: r("games.counterattack.actPassFT"),
					disabled: !a || !t.canFT,
					active: e.pending === "ft",
					onClick: () => e.setPending("ft")
				}),
				/* @__PURE__ */ g(X, {
					symbol: "↗",
					label: r("games.counterattack.actPassHigh"),
					disabled: !a,
					active: e.pending === "high",
					onClick: () => e.setPending("high")
				}),
				/* @__PURE__ */ g(X, {
					symbol: "➤",
					label: r("games.counterattack.actPassLong"),
					disabled: !a,
					active: e.pending === "long",
					onClick: () => e.setPending("long")
				}),
				/* @__PURE__ */ g(X, {
					symbol: "◉",
					label: r("games.counterattack.actShoot"),
					disabled: !a || !z(w(t.ball), n),
					active: e.pending === "shoot",
					onClick: () => e.setPending("shoot")
				}),
				/* @__PURE__ */ g(X, {
					symbol: "✦",
					label: r("games.counterattack.actSnapshot"),
					disabled: !a || !t.canSnap,
					active: e.pending === "snapshot",
					onClick: () => e.setPending("snapshot")
				}),
				/* @__PURE__ */ g(X, {
					symbol: "×",
					label: r("games.counterattack.actCancel"),
					disabled: !e.pending,
					onClick: () => e.setPending(null)
				})
			]
		});
	}
	if (a.k === "move") {
		if (!e.myMoveStep) return /* @__PURE__ */ g("div", { className: "flex-1" });
		let t = Object.keys(e.paths).length;
		return /* @__PURE__ */ _("div", {
			className: "flex flex-1 items-center gap-1.5",
			children: [a.step === "d" && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(X, {
				label: r("games.counterattack.tackleStd"),
				active: e.tackle === "std",
				onClick: () => e.setTackle(e.tackle === "std" ? "none" : "std")
			}), /* @__PURE__ */ g(X, {
				label: r("games.counterattack.tackleReckless"),
				active: e.tackle === "reckless",
				onClick: () => e.setTackle(e.tackle === "reckless" ? "none" : "reckless")
			})] }), /* @__PURE__ */ g(X, {
				label: t > 0 ? r("games.counterattack.moveEndN", { n: t }) : r("games.counterattack.moveEnd"),
				active: t > 0,
				onClick: () => {
					let t = Object.entries(e.paths);
					for (let [n, r] of t) i(a.step === "d" ? {
						type: "mvd",
						pid: n,
						path: r,
						...e.tackle === "none" ? {} : { tackle: e.tackle }
					} : {
						type: "mv",
						pid: n,
						path: r
					});
					t.length < a.left && i({ type: "mvStep" });
				}
			})]
		});
	}
	if (a.k === "header") return e.headerStageSide === n ? a.stage === "atk" ? /* @__PURE__ */ _("div", {
		className: "flex flex-1 items-center gap-1.5",
		children: [
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.headPass"),
				onClick: () => e.setPending("headPass"),
				disabled: e.contest.length === 0
			}),
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.headShot"),
				onClick: () => i({
					type: "headAtk",
					intent: "shot",
					contesters: e.contest
				}),
				disabled: e.contest.length === 0
			}),
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.headControl"),
				onClick: () => i({
					type: "headAtk",
					intent: "control",
					contesters: e.contest
				})
			})
		]
	}) : /* @__PURE__ */ _("div", {
		className: "flex flex-1 items-center gap-1.5",
		children: [
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.headGk"),
				active: e.gkIn,
				onClick: () => e.setGkIn(!e.gkIn)
			}),
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.headNone"),
				onClick: () => i({
					type: "headDef",
					contesters: [],
					gk: !1
				})
			}),
			/* @__PURE__ */ g(X, {
				label: "✓",
				disabled: e.contest.length === 0 && !e.gkIn,
				onClick: () => i({
					type: "headDef",
					contesters: e.contest,
					gk: e.gkIn
				})
			})
		]
	}) : /* @__PURE__ */ g("div", { className: "flex-1" });
	if (a.k === "ft" || a.k === "hp") return (a.who === "atk" ? t.poss : 1 - t.poss) === n ? /* @__PURE__ */ g("div", {
		className: "flex flex-1 items-center",
		children: /* @__PURE__ */ g(X, {
			label: r("games.counterattack.adjSkip"),
			onClick: () => i({ type: a.k === "ft" ? "ftSkip" : "hpSkip" })
		})
	}) : /* @__PURE__ */ g("div", { className: "flex-1" });
	if (a.k === "snap") return t.poss === n ? /* @__PURE__ */ g("div", { className: "flex-1" }) : /* @__PURE__ */ g("div", {
		className: "flex flex-1 items-center",
		children: /* @__PURE__ */ g(X, {
			label: r("games.counterattack.adjSkip"),
			onClick: () => i({ type: "snapSkip" })
		})
	});
	if (a.k === "foul") return t.poss === n ? /* @__PURE__ */ _("div", {
		className: "flex flex-1 items-center gap-1.5",
		children: [/* @__PURE__ */ g(X, {
			label: a.inBox ? r("games.counterattack.foulTakePen") : r("games.counterattack.foulTakeFk"),
			onClick: () => i({
				type: "foulChoice",
				take: !0
			})
		}), /* @__PURE__ */ g(X, {
			label: r("games.counterattack.foulPlayOn"),
			onClick: () => i({
				type: "foulChoice",
				take: !1
			})
		})]
	}) : /* @__PURE__ */ g("div", { className: "flex-1" });
	if (a.k === "sp") {
		if (a.steps.length > 0) {
			let o = Number(a.steps[0][1]);
			if ((a.steps[0][0] === "a" ? t.poss : 1 - t.poss) !== n) return /* @__PURE__ */ g("div", { className: "flex-1" });
			let s = e.spMoves.length + (e.subSel && e.subOut ? 1 : 0), c = t.bench[n];
			return /* @__PURE__ */ _("div", {
				className: "ca-setpiece flex flex-1 flex-col justify-center gap-1.5",
				children: [/* @__PURE__ */ _("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ g("span", {
						className: "plate flex h-9 flex-none items-center px-2.5 font-mono text-[11px] font-black tabular-nums",
						children: r("games.counterattack.spLeft", { n: Math.max(0, o - s) })
					}), /* @__PURE__ */ g(X, {
						label: r("games.counterattack.spDone"),
						active: s > 0,
						onClick: () => {
							let t = e.subSel && e.subOut ? {
								out: e.subOut,
								in: e.subSel
							} : void 0;
							i({
								type: "spPlace",
								moves: e.spMoves,
								...t ? { sub: t } : {}
							});
						}
					})]
				}), /* @__PURE__ */ _("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ g("span", {
						className: "section-label flex-none",
						children: r("games.counterattack.spSubOptional")
					}), /* @__PURE__ */ g("div", {
						className: "ca-setpiece-bench flex min-h-9 min-w-0 flex-1 flex-nowrap items-center gap-1 overflow-x-auto",
						children: c.map((r) => /* @__PURE__ */ _("button", {
							type: "button",
							disabled: e.subSel === null && e.spMoves.length >= o,
							onClick: () => e.setSubSel(e.subSel === r ? null : r),
							className: "flex min-h-9 flex-none items-center gap-1 rounded-lg border-2 border-ink/40 bg-surface px-2 text-[11px] font-bold disabled:opacity-40",
							style: e.subSel === r ? {
								borderColor: oe.accent,
								backgroundColor: oe.accent,
								color: "#fff"
							} : void 0,
							children: [/* @__PURE__ */ _("span", {
								className: "font-mono text-[10px] tabular-nums opacity-60",
								children: ["#", t.num[r]]
							}), e.pname(t.squads[n][Number(r.slice(2))])]
						}, r))
					})]
				})]
			});
		}
		return t.poss === n ? a.kind === "fk" ? /* @__PURE__ */ _("div", {
			className: "grid flex-1 grid-cols-4 content-center gap-1.5",
			children: [
				/* @__PURE__ */ g(X, {
					label: r("games.counterattack.fkStd"),
					active: e.pending === "fkStd",
					onClick: () => e.setPending("fkStd")
				}),
				/* @__PURE__ */ g(X, {
					label: r("games.counterattack.actPassHigh"),
					active: e.pending === "fkHigh",
					onClick: () => e.setPending("fkHigh")
				}),
				/* @__PURE__ */ g(X, {
					label: r("games.counterattack.actPassLong"),
					active: e.pending === "fkLong",
					onClick: () => e.setPending("fkLong")
				}),
				/* @__PURE__ */ g(X, {
					label: r("games.counterattack.fkShot"),
					disabled: !z(w(t.ball), n),
					active: e.pending === "fkShot",
					onClick: () => e.setPending("fkShot")
				})
			]
		}) : /* @__PURE__ */ _("div", {
			className: "flex flex-1 items-center gap-1.5",
			children: [/* @__PURE__ */ g(X, {
				label: r("games.counterattack.cornerHigh"),
				active: e.pending === "cornerHigh",
				onClick: () => e.setPending("cornerHigh")
			}), /* @__PURE__ */ g(X, {
				label: r("games.counterattack.cornerLow"),
				active: e.pending === "cornerLow",
				onClick: () => e.setPending("cornerLow")
			})]
		}) : /* @__PURE__ */ g("div", { className: "flex-1" });
	}
	return a.k === "pen" ? t.poss === n ? /* @__PURE__ */ g("div", {
		className: "flex flex-1 items-center",
		children: /* @__PURE__ */ g(X, {
			label: r("games.counterattack.penTake"),
			active: e.pending === "pen",
			onClick: () => e.setPending("pen")
		})
	}) : /* @__PURE__ */ g("div", { className: "flex-1" }) : a.k === "throw" ? t.poss !== n || !a.thrower ? /* @__PURE__ */ g("div", { className: "flex-1" }) : /* @__PURE__ */ _("div", {
		className: "flex flex-1 items-center gap-1.5",
		children: [
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.throwFeet"),
				active: e.pending === "throwFeet",
				onClick: () => e.setPending("throwFeet")
			}),
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.throwHead"),
				active: e.pending === "throwHead",
				onClick: () => e.setPending("throwHead")
			}),
			a.movesLeft > 0 && /* @__PURE__ */ g(X, {
				label: r("games.counterattack.actMove"),
				onClick: () => i({ type: "startMove" })
			})
		]
	}) : a.k === "gk" ? t.poss === n ? a.kick ? /* @__PURE__ */ _("div", {
		className: "flex flex-1 items-center gap-1.5",
		children: [/* @__PURE__ */ g(X, {
			label: r("games.counterattack.gkGoalStd"),
			active: e.pending === "gkGoalStd",
			onClick: () => e.setPending("gkGoalStd")
		}), /* @__PURE__ */ g(X, {
			label: r("games.counterattack.gkGoalLong"),
			active: e.pending === "gkGoalLong",
			onClick: () => e.setPending("gkGoalLong")
		})]
	}) : /* @__PURE__ */ _("div", {
		className: "flex flex-1 items-center gap-1.5",
		children: [
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.gkThrow"),
				active: e.pending === "gkThrow",
				onClick: () => e.setPending("gkThrow")
			}),
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.gkKick"),
				active: e.pending === "gkKick",
				onClick: () => e.setPending("gkKick")
			}),
			/* @__PURE__ */ g(X, {
				label: r("games.counterattack.gkDrop"),
				onClick: () => i({ type: "gkDrop" })
			})
		]
	}) : /* @__PURE__ */ g("div", { className: "flex-1" }) : null;
}
function un({ pub: e, nameOf: t, t: n }) {
	let r = e.mode.k, i = e.phase === "over" ? n("session.result.title") : n(r === "move" ? "games.counterattack.actMove" : r === "header" ? "games.counterattack.headPrompt" : r === "foul" ? "games.counterattack.foulTitle" : r === "sp" ? "games.counterattack.phaseSetPiece" : r === "pen" ? "games.counterattack.logPen" : r === "throw" ? "games.counterattack.logThrowin" : r === "gk" ? "games.counterattack.gkShort" : "games.counterattack.phaseAction");
	return /* @__PURE__ */ _("div", {
		className: "ca-wait-panel",
		children: [
			/* @__PURE__ */ _("div", {
				className: "ca-wait-metric",
				children: [/* @__PURE__ */ g("small", { children: n("games.counterattack.waitPhase") }), /* @__PURE__ */ g("strong", { children: i })]
			}),
			/* @__PURE__ */ _("div", {
				className: "ca-wait-metric",
				children: [/* @__PURE__ */ g("small", { children: n("games.counterattack.waitPossession") }), /* @__PURE__ */ g("strong", { children: t(e.poss) })]
			}),
			/* @__PURE__ */ _("div", {
				className: "ca-wait-metric",
				children: [/* @__PURE__ */ g("small", { children: n("games.counterattack.waitBall") }), /* @__PURE__ */ g("strong", { children: e.holder ? `#${e.num[e.holder]}` : n("games.counterattack.ballLoose") })]
			})
		]
	});
}
function dn(e, t, n, r) {
	if (t === null || e.phase !== "play") return {
		text: "",
		mine: !1
	};
	let i = e.mode, a = (e) => ({
		text: e,
		mine: !1
	}), o = (e) => ({
		text: e,
		mine: !0
	});
	if (n) return o(`${r("games.counterattack.pickTarget")} · ${r("games.counterattack.guideAnts")}`);
	switch (i.k) {
		case "action": return e.poss === t ? o(r("games.counterattack.guideAction")) : a(r("games.counterattack.guideWait"));
		case "move": {
			let n = i.step === "d" ? 1 - e.poss : e.poss, s = r(i.step === "d" ? "games.counterattack.moveDef" : i.step === "a1" ? "games.counterattack.moveAtk1" : "games.counterattack.moveAtk2", { n: i.left });
			return n === t ? o(`${s} · ${r("games.counterattack.guidePath")}`) : a(s);
		}
		case "header": {
			let n = i.stage === "atk" ? e.poss : 1 - e.poss, s = r("games.counterattack.headPrompt");
			return n === t ? o(`${s} · ${r("games.counterattack.guideAdjust")}`) : a(s);
		}
		case "ft":
		case "hp": {
			let n = i.who === "atk" ? e.poss : 1 - e.poss, s = r(i.k === "ft" ? "games.counterattack.ftPrompt" : "games.counterattack.hpPrompt");
			return n === t ? o(`${s} · ${r("games.counterattack.guideAdjust")}`) : a(s);
		}
		case "snap": {
			let n = r("games.counterattack.guideSnap");
			return e.poss === t ? a(n) : o(`${n} · ${r("games.counterattack.guideAdjust")}`);
		}
		case "foul": return e.poss === t ? o(r("games.counterattack.guideFoul")) : a(r("games.counterattack.logFoul"));
		case "sp": {
			if (i.steps.length > 0) {
				let n = i.steps[0][0] === "a" ? e.poss : 1 - e.poss, s = r("games.counterattack.spPlace", { n: Number(i.steps[0][1]) });
				return n === t ? o(`${s} · ${r("games.counterattack.guideSp")}`) : a(s);
			}
			let n = i.kind === "fk" ? "games.counterattack.guideFk" : "games.counterattack.guideCorner";
			return e.poss === t ? o(r(n)) : a(r(n));
		}
		case "pen": return e.poss === t ? o(r("games.counterattack.guidePen")) : a(r("games.counterattack.logPen"));
		case "throw": return e.poss === t ? o(i.thrower ? r("games.counterattack.guideThrow") : r("games.counterattack.throwPick")) : a(r("games.counterattack.logThrowin"));
		case "gk": {
			let n = i.kick ? "games.counterattack.guideGkKick" : "games.counterattack.guideGk";
			return e.poss === t ? o(r(n)) : a(r(n));
		}
	}
}
function fn(e, t, n) {
	let r = {
		kickoff: "games.counterattack.logKickoff",
		half: "games.counterattack.logHalf",
		goal: "games.counterattack.logGoal",
		save: "games.counterattack.logSave",
		miss: "games.counterattack.logMiss",
		foul: "games.counterattack.logFoul",
		inj: "games.counterattack.logInj",
		sub: "games.counterattack.logSub",
		steal: "games.counterattack.logSteal",
		intercept: "games.counterattack.logIntercept",
		pen: "games.counterattack.logPen",
		corner: "games.counterattack.logCorner",
		throwin: "games.counterattack.logThrowin",
		goalkick: "games.counterattack.logGoalkick",
		loose: "games.counterattack.ballLoose"
	}, i = e.k === "card" ? t(e.n === 2 ? "games.counterattack.logCardRed" : "games.counterattack.logCardYellow") : r[e.k] ? t(r[e.k]) : e.k, a = e.pid ? Number(e.pid[0]) : null;
	return /* @__PURE__ */ _("span", {
		className: "inline-flex items-center gap-1",
		children: [
			e.side !== void 0 && a === null && /* @__PURE__ */ g("span", {
				className: "size-2.5 flex-none rounded-full",
				style: { backgroundColor: Gt[e.side] }
			}),
			/* @__PURE__ */ g("span", {
				className: "min-w-0",
				children: i
			}),
			e.pid && a !== null && /* @__PURE__ */ _("span", {
				className: "flex-none rounded-md px-1 py-px text-[10px] font-bold whitespace-nowrap text-white",
				style: { backgroundColor: Gt[a] },
				children: [
					/* @__PURE__ */ _("span", {
						className: "font-mono tabular-nums opacity-70",
						children: ["#", n.num(e.pid)]
					}),
					" ",
					n.pname(e.pid)
				]
			})
		]
	});
}
function pn(e) {
	let { pub: t } = e, n = e.mySide === 0, r = e.goalSide === null || e.goalSide === void 0 ? null : e.goalSide === 0 ? n : !n, i = e.pending === "shoot" || e.pending === "snapshot" || e.pending === "fkShot" || e.pending === "pen", a = Array.from({ length: 25 }, (t, r) => Array.from({ length: 37 }, (t, i) => {
		let { x: a, y: o } = Y(i, r, n), s = ((r - (i - (i & 1) >> 1) - i) % 3 + 3) % 3 == 0;
		return /* @__PURE__ */ g("polygon", {
			points: Yt,
			transform: `translate(${a},${o})`,
			fill: s ? qt : i % 8 < 4 ? Kt : "#3aaa65",
			stroke: "rgba(0,40,15,0.24)",
			strokeWidth: .8,
			onClick: () => e.onTapCell(C(i, r))
		}, `${i},${r}`);
	})), o = [];
	for (let t of k) for (let r of [-1, 37]) {
		let { x: i, y: a } = Y(r, t, n);
		o.push(/* @__PURE__ */ g("polygon", {
			points: Yt,
			transform: `translate(${i},${a})`,
			fill: "rgba(0,0,0,0)",
			stroke: "none",
			onClick: () => e.onTapCell(C(r, t))
		}, `goal${r},${t}`));
	}
	let s = (e) => J * (1.5 * e + 1.75), c = (e) => Ht * J * e, l = s(0), u = s(37), d = s(37 / 2), f = Y(ye.c, ye.r, !1), p = Y(ge(0).c, ge(0).r, !1), m = Y(ge(1).c, ge(1).r, !1), v = c(k[0]), y = c(k[6] + 1), ee = J * .35, te = l - ee, ne = Math.sqrt(8100 - (s(6.5) - p.y) ** 2), b = J * .9, ie = /* @__PURE__ */ _("g", {
		transform: n ? `translate(0 ${Wt}) scale(1 -1)` : void 0,
		style: { pointerEvents: "none" },
		fill: "none",
		stroke: "#f7fff1",
		opacity: .95,
		children: [
			/* @__PURE__ */ g("rect", {
				x: 0,
				y: l,
				width: Ut,
				height: u - l,
				strokeWidth: 2.2
			}),
			/* @__PURE__ */ g("line", {
				x1: 0,
				y1: d,
				x2: Ut,
				y2: d,
				strokeWidth: 1.8
			}),
			/* @__PURE__ */ g("circle", {
				cx: f.x,
				cy: f.y,
				r: 75,
				strokeWidth: 1.8
			}),
			/* @__PURE__ */ g("circle", {
				cx: f.x,
				cy: f.y,
				r: 1.4,
				fill: "#fff",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${c(5)} ${l} V ${s(6.5)} H ${c(20)} V ${l}`,
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${c(7.5)} ${l} V ${s(2.5)} H ${c(17.5)} V ${l}`,
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${c(5)} ${u} V ${s(30.5)} H ${c(20)} V ${u}`,
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${c(7.5)} ${u} V ${s(34.5)} H ${c(17.5)} V ${u}`,
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ g("circle", {
				cx: p.x,
				cy: p.y,
				r: 1.2,
				fill: "#fff",
				stroke: "none"
			}),
			/* @__PURE__ */ g("circle", {
				cx: m.x,
				cy: m.y,
				r: 1.2,
				fill: "#fff",
				stroke: "none"
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${p.x - ne} ${s(6.5)} A 90 90 0 0 0 ${p.x + ne} ${s(6.5)}`,
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${m.x - ne} ${s(30.5)} A 90 90 0 0 1 ${m.x + ne} ${s(30.5)}`,
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${b} ${l} A ${b} ${b} 0 0 1 0 ${l + b}`,
				strokeWidth: 1
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${Ut - b} ${l} A ${b} ${b} 0 0 0 ${Ut} ${l + b}`,
				strokeWidth: 1
			}),
			/* @__PURE__ */ g("path", {
				d: `M 0 ${u - b} A ${b} ${b} 0 0 1 ${b} ${u}`,
				strokeWidth: 1
			}),
			/* @__PURE__ */ g("path", {
				d: `M ${Ut} ${u - b} A ${b} ${b} 0 0 0 ${Ut - b} ${u}`,
				strokeWidth: 1
			}),
			[[l, s(11)], [s(26), u]].map(([e, t]) => /* @__PURE__ */ _("g", {
				fill: "#e5ef69",
				stroke: "none",
				opacity: .85,
				children: [/* @__PURE__ */ g("rect", {
					x: 0,
					y: e,
					width: J * .35,
					height: t - e
				}), /* @__PURE__ */ g("rect", {
					x: Ut - J * .35,
					y: e,
					width: J * .35,
					height: t - e
				})]
			}, `ft-${e}`)),
			[0, 1].map((e) => {
				let t = e === 0 ? ee : u;
				return /* @__PURE__ */ _("g", { children: [
					/* @__PURE__ */ g("rect", {
						x: v,
						y: t,
						width: y - v,
						height: te,
						fill: r === (e === 0) ? "#eaff8b88" : "rgba(255,255,255,0.12)",
						strokeWidth: 2.2
					}),
					[
						.25,
						.5,
						.75
					].map((e) => /* @__PURE__ */ g("line", {
						x1: v + (y - v) * e,
						y1: t,
						x2: v + (y - v) * e,
						y2: t + te,
						strokeWidth: .6,
						opacity: .6
					}, e)),
					/* @__PURE__ */ g("line", {
						x1: v,
						y1: t + te / 2,
						x2: y,
						y2: t + te / 2,
						strokeWidth: .6,
						opacity: .6
					}),
					/* @__PURE__ */ g("line", {
						x1: v,
						y1: e === 0 ? l : u,
						x2: y,
						y2: e === 0 ? l : u,
						strokeWidth: 2.4
					})
				] }, `goalframe-${e}`);
			})
		]
	}), x = [];
	for (let [r, i] of Object.entries(e.paths)) {
		let e = t.pos[r];
		if (!e || i.length === 0) continue;
		let a = [e, ...i].map((e) => {
			let t = w(e);
			return Y(t.c, t.r, n);
		}), o = a[a.length - 1], s = a[a.length - 2], c = Math.atan2(o.y - s.y, o.x - s.x);
		x.push(/* @__PURE__ */ _("g", {
			style: { pointerEvents: "none" },
			children: [
				/* @__PURE__ */ g("polyline", {
					points: a.map((e) => `${e.x},${e.y}`).join(" "),
					fill: "none",
					stroke: "#fff",
					strokeWidth: 2.2,
					strokeLinecap: "round",
					strokeLinejoin: "round",
					opacity: .9
				}),
				a.slice(1).map((e, t) => /* @__PURE__ */ g("circle", {
					cx: e.x,
					cy: e.y,
					r: 1.8,
					fill: "#fff",
					opacity: .9
				}, t)),
				/* @__PURE__ */ g("polygon", {
					points: "0,-3.5 7,0 0,3.5",
					transform: `translate(${o.x - Math.cos(c) * 8},${o.y - Math.sin(c) * 8}) rotate(${c * 180 / Math.PI})`,
					fill: "#fff",
					opacity: .95
				})
			]
		}, `mk-${r}`));
	}
	let ae = [];
	for (let r of [0, 1]) for (let i of t.onPitch[r]) {
		let a = t.pos[i];
		if (!a) continue;
		let o = w(a), { x: s, y: c } = Y(o.c, o.r, n), l = re(t.squads[r][Number(i.slice(2))]), u = t.injuries[i] ?? 0, d = t.yellow[i] ?? 0;
		ae.push(/* @__PURE__ */ _("g", {
			className: "ca-token",
			filter: "url(#ca-token-shadow)",
			style: {
				transform: `translate(${s}px, ${c}px)`,
				cursor: "pointer"
			},
			onClick: (t) => {
				t.stopPropagation(), e.onTapToken(i);
			},
			children: [
				e.hot?.includes(i) && e.sel !== i && /* @__PURE__ */ g("circle", {
					r: J * 1.14,
					fill: "none",
					stroke: "#e8ff81",
					strokeWidth: 1.8,
					strokeDasharray: "4 3",
					style: { pointerEvents: "none" }
				}),
				e.sel === i && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("circle", {
					r: J * 1.11,
					fill: "#e8ff81",
					stroke: "#fff",
					strokeWidth: 2.5,
					style: { pointerEvents: "none" }
				}), /* @__PURE__ */ g("circle", {
					r: J * 1.3,
					fill: "none",
					stroke: "#e8ff81",
					strokeWidth: 1.6,
					strokeDasharray: "5 4",
					style: { pointerEvents: "none" }
				})] }),
				e.contest?.includes(i) && /* @__PURE__ */ g("circle", {
					r: J * 1.12,
					fill: "none",
					stroke: "#e8ff81",
					strokeWidth: 2.6,
					style: { pointerEvents: "none" }
				}),
				l ? /* @__PURE__ */ g("rect", {
					x: -11.25,
					y: -11.25,
					width: J * 1.5,
					height: J * 1.5,
					rx: 5,
					fill: Gt[r],
					stroke: "#fff",
					strokeWidth: 2.4
				}) : /* @__PURE__ */ g("circle", {
					r: J * .87,
					fill: Gt[r],
					stroke: "#fff",
					strokeWidth: 2.5
				}),
				/* @__PURE__ */ g("circle", {
					r: J * .59,
					fill: "none",
					stroke: "#11271e",
					strokeOpacity: .5,
					strokeWidth: 1,
					style: { pointerEvents: "none" }
				}),
				/* @__PURE__ */ g("text", {
					textAnchor: "middle",
					dy: "0.35em",
					fontFamily: "ui-monospace,monospace",
					fontSize: J * .78,
					fontWeight: 900,
					fill: "#fff",
					style: { pointerEvents: "none" },
					children: t.num[i]
				}),
				d > 0 && /* @__PURE__ */ g("circle", {
					cx: J * .72,
					cy: -15 * .72,
					r: J * .23,
					fill: "#facc15",
					stroke: "#0f172a",
					strokeWidth: .8
				}),
				u > 0 && /* @__PURE__ */ g("text", {
					x: -8.25,
					y: -4.5,
					fontSize: J * .5,
					style: { pointerEvents: "none" },
					children: "✚"
				})
			]
		}, i));
	}
	let S = w(t.ball), oe = Y(S.c, S.r, n), se = [0, 1].some((e) => t.onPitch[e].some((e) => t.pos[e] === t.ball)), T = /* @__PURE__ */ _("g", {
		className: "ca-ball",
		filter: "url(#ca-token-shadow)",
		style: {
			transform: `translate(${oe.x + (se ? J * .53 : 0)}px, ${oe.y + (se ? J * .53 : 0)}px)`,
			pointerEvents: "none"
		},
		children: [
			/* @__PURE__ */ g("circle", {
				r: J * .53,
				fill: "#fff",
				stroke: "#20382d",
				strokeWidth: 1.7
			}),
			/* @__PURE__ */ g("polygon", {
				points: Xt,
				fill: "#0f172a"
			}),
			/* @__PURE__ */ g("path", {
				d: "M0 -8 V-5 M7 -3 L4 -1 M5 6 L2 4 M-5 6 L-2 4 M-7 -3 L-4 -1",
				stroke: "#20382d",
				strokeWidth: 1.1
			})
		]
	});
	return /* @__PURE__ */ _("svg", {
		width: Ut,
		height: Wt,
		viewBox: `0 0 ${Ut} ${Wt}`,
		style: {
			display: "block",
			background: Jt
		},
		children: [
			/* @__PURE__ */ g("defs", { children: /* @__PURE__ */ g("filter", {
				id: "ca-token-shadow",
				x: "-50%",
				y: "-50%",
				width: "200%",
				height: "200%",
				children: /* @__PURE__ */ g("feDropShadow", {
					dx: "2",
					dy: "3",
					stdDeviation: "1.3",
					floodColor: "#042719",
					floodOpacity: "0.8"
				})
			}) }),
			a,
			ie,
			o,
			e.trails && Object.entries(e.trails).map(([e, t]) => t.length > 1 ? /* @__PURE__ */ g("polyline", {
				points: t.map((e) => {
					let t = w(e), { x: r, y: i } = Y(t.c, t.r, n);
					return `${r},${i}`;
				}).join(" "),
				fill: "none",
				stroke: "#fff",
				strokeWidth: 1.6,
				strokeDasharray: "2 3",
				strokeLinecap: "round",
				strokeLinejoin: "round",
				opacity: .45,
				style: { pointerEvents: "none" }
			}, `tr-${e}`) : null),
			e.ghosts?.map((e) => {
				let r = w(e.to), { x: i, y: a } = Y(r.c, r.r, n);
				return /* @__PURE__ */ _("g", {
					transform: `translate(${i},${a})`,
					style: { pointerEvents: "none" },
					children: [/* @__PURE__ */ g("circle", {
						r: J * .62,
						fill: Gt[Number(e.pid[0])],
						opacity: .4,
						stroke: "#fff",
						strokeWidth: 1,
						strokeDasharray: "3 2"
					}), /* @__PURE__ */ g("text", {
						textAnchor: "middle",
						dy: "0.35em",
						fontSize: J * .62,
						fontWeight: 900,
						fill: "#fff",
						opacity: .8,
						children: t.num[e.pid]
					})]
				}, `gh-${e.pid}`);
			}),
			e.reach?.map((e) => {
				let t = w(e), { x: r, y: a } = Y(t.c, t.r, n);
				return /* @__PURE__ */ g("polygon", {
					points: Yt,
					transform: `translate(${r},${a})`,
					fill: i ? "#ffb68555" : "#eaff8b22",
					stroke: i ? "#ffb685" : "#edff91",
					strokeWidth: i ? 2.4 : 1.2,
					opacity: i ? 1 : .8,
					style: { pointerEvents: "none" }
				}, `rh-${e}`);
			}),
			x,
			t.holder && T,
			ae,
			!t.holder && T,
			t.holder && t.pos[t.holder] && /* @__PURE__ */ g("circle", {
				cx: Y(w(t.pos[t.holder]).c, w(t.pos[t.holder]).r, n).x,
				cy: Y(w(t.pos[t.holder]).c, w(t.pos[t.holder]).r, n).y,
				r: J * .85,
				fill: "none",
				stroke: "#fde047",
				strokeWidth: 2,
				style: {
					pointerEvents: "none",
					transition: "cx 0.35s ease, cy 0.35s ease"
				}
			})
		]
	});
}
//#endregion
//#region src/games/counterattack/bot.ts
var Z = (e) => 1 - e, mn = (e) => Number(e[0]), hn = (e, t) => t === 0 ? e.c : 36 - e.c, gn = (e) => e === 0 ? 36 : 0, _n = (e, t) => `${e === 0 ? 37 : -1},${t}`;
function Q(e, t) {
	return ie(e.squads[mn(t)][Number(t.slice(2))], e.injuries[t] ?? 0);
}
var $ = (e, t) => e.squads[mn(t)][Number(t.slice(2))] >= 100, vn = (e, t) => e.onPitch[t].find((t) => $(e, t)) ?? null;
function yn(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of [0, 1]) for (let r of e.onPitch[n]) e.pos[r] && t.set(e.pos[r], r);
	return t;
}
function bn(e, t) {
	let n = 0, r = 0;
	for (let i = 1; i <= 6; i += 1) for (let a = 1; a <= 6; a += 1) e + i > t + a ? n += 1 : e + i === t + a && (r += 1);
	return [n / 36, r / 36];
}
var xn = (e) => Math.max(2 / 6, (e - 3) / 6), Sn = (e) => Math.max(1 / 6, (e - 3) / 6);
function Cn(e, t, n, r, i) {
	let a = Z(t), o = vn(e, a), s = Math.max((A(n, a) ? 0 : -1) + (i.snap ? -1 : 0) + (xe(n, t) ? -1 : 0), -2), c = gn(t), l = {
		exp: -1,
		row: 12
	};
	for (let t of k) {
		let u = O(n, {
			c,
			r: t
		}), d = [], f = -1;
		for (let t of e.onPitch[a]) {
			if (t === o) continue;
			let n = w(e.pos[t]), r = Q(e, t).tackling;
			u.some((e) => e.c === n.c && e.r === n.r) ? d.push(r) : u.some((e) => E(e, n) <= 1) && (f = Math.max(f, r));
		}
		let p = o ? Math.abs(w(e.pos[o]).r - t) : 99, m = 0;
		for (let t = 1; t <= 6; t += 1) {
			if (t === 1) continue;
			let n = r + t + s, a = 1;
			if (!(i.fk && n >= 9)) {
				for (let e of d) a *= 1 - xn(e);
				a *= 1 - Sn(f < 0 ? 0 : f) * (f < 0 ? 0 : 1);
			}
			let c;
			if (!o || p > S.gkDive) c = 1;
			else {
				let [t, r] = bn(n, Q(e, o).saving + (p === S.gkDive ? -1 : 0));
				c = t + r * .25;
			}
			m += 1 / 6 * a * c;
		}
		m > l.exp && (l = {
			exp: m,
			row: t
		});
	}
	return l;
}
function wn(e, t) {
	let n = Z(e);
	if (A(t, n)) return .5 - E(t, ge(n)) * .02;
	let r = gn(e), i = Infinity;
	for (let e of k) i = Math.min(i, E(t, {
		c: r,
		r: e
	}));
	return i <= S.shot ? .28 - i * .012 - (xe(t, e) ? .04 : 0) : hn(t, e) * .006;
}
function Tn(e, t, n) {
	let r = 0;
	for (let i of e.onPitch[Z(t)]) E(w(e.pos[i]), n) <= 1 && (r += 1);
	return r;
}
function En(e, t, n, r, i) {
	let a = O(r, i).filter((e) => {
		let r = t.get(C(e.c, e.r));
		return !(r && mn(r) === n);
	}), o = -1, s = !1;
	for (let t of e.onPitch[Z(n)]) {
		let n = w(e.pos[t]);
		if (!a.some((e) => E(e, n) <= 1)) continue;
		let r = $(e, t), i = r ? Q(e, t).saving : Q(e, t).tackling;
		i > o && (o = i, s = r);
	}
	return o < 0 ? 0 : s ? xn(o) : Sn(o);
}
var Dn = (e, t, n, r) => O(t, n).every((t) => {
	let n = e.get(C(t.c, t.r));
	return !n || mn(n) === r;
});
function On(e, t, n) {
	let r = Q(e, t).dribbling, i = Q(e, n).tackling + 1, a = 0, o = 0;
	for (let e = 2; e <= 6; e += 1) for (let t = 1; t <= 6; t += 1) i + e > r + t ? a += 1 : i + e === r + t && (o += 1);
	return (a + .5 * o) / 30 - .03;
}
function kn(e, t, n) {
	let r = 0;
	for (let i of e.onPitch[Z(t)]) E(w(e.pos[i]), n) === 1 && (r += Sn(Q(e, i).tackling) - 1 / 6 / 3);
	return r;
}
function An(e, t, n, r, i, a) {
	let o = w(e.pos[r]), s = /* @__PURE__ */ new Map([[C(o.c, o.r), {
		cost: 0,
		risk: 0,
		path: []
	}]]), c = [C(o.c, o.r)];
	for (; c.length > 0;) {
		c.sort((e, t) => s.get(e).cost - s.get(t).cost);
		let o = c.shift(), l = s.get(o), u = w(o);
		for (let o of D(u)) {
			let u = C(o.c, o.r), d = n.get(u), f = 1, p = 0;
			if (d) {
				if (mn(d) === t || !a) continue;
				f = 2, p = On(e, r, d);
			} else a && (p = kn(e, t, o));
			let m = l.cost + f;
			if (m > i) continue;
			let h = s.get(u);
			h && (h.cost < m || h.cost === m && h.risk <= l.risk + p) || (s.set(u, {
				cost: m,
				risk: l.risk + p,
				path: [...l.path, u]
			}), c.push(u));
		}
	}
	return s;
}
function jn(e, t, n, r, i, a) {
	let o = w(e.pos[a]), s = Q(e, a), c = z(o, n) ? Cn(e, n, o, s.shooting, {}).exp : 0, l = hn(o, n) - hn(r, n);
	return (c - i) * 1.2 + l * .015 - En(e, t, n, r, o) * .5 - Tn(e, n, o) * .03;
}
function Mn(e, t, n) {
	if (!e.draft || e.draft.turn !== t) return null;
	if (n) return {
		type: "draftPick",
		ref: e.draft.revealed[0]
	};
	let r = e.draft.revealed[0], i = (e) => te[e].st.reduce((e, t) => e + t, 0) + te[e].st[0] * .3;
	for (let t of e.draft.revealed) i(t) > i(r) && (r = t);
	return {
		type: "draftPick",
		ref: r
	};
}
function Nn(e, t, n, r) {
	let i = Z(t), a = w(r.landing), o = (t) => e.onPitch[t].filter((t) => !r.ban.includes(t) && E(w(e.pos[t]), a) <= 2), s = (t) => [...t].sort((t, n) => Q(e, n).heading - Q(e, t).heading);
	if (r.stage === "atk") {
		if (e.poss !== t) return null;
		let c = o(t), l = s(c).slice(0, 2);
		if (l.length === 0) return {
			type: "headAtk",
			intent: "pass",
			contesters: [],
			target: r.landing
		};
		let u = Q(e, l[0]).heading, d = Math.max(0, ...o(i).map((t) => Q(e, t).heading)), f = vn(e, i), p = f && A(a, i) ? Q(e, f).aerial : 0;
		if ((A(a, i) || E(a, {
			c: gn(t),
			r: Math.max(k[0], Math.min(k[6], a.r))
		}) <= S.header) && u >= d + +(p > u) && (!n || A(a, i))) return {
			type: "headAtk",
			intent: "shot",
			contesters: l
		};
		let m, h = 0;
		for (let n of e.onPitch[t]) {
			if (l.includes(n)) continue;
			let r = w(e.pos[n]);
			if (E(a, r) > S.header) continue;
			let i = wn(t, r) - Tn(e, t, r) * .05 + hn(r, t) * .005;
			i > h && (h = i, m = e.pos[n]);
		}
		return m ? {
			type: "headAtk",
			intent: "pass",
			contesters: l,
			target: m
		} : !(o(i).length > 0) && !r.corner ? {
			type: "headAtk",
			intent: "control",
			contesters: [[...c].sort((t, n) => Q(e, n).dribbling - Q(e, t).dribbling)[0]]
		} : {
			type: "headAtk",
			intent: "pass",
			contesters: l,
			target: r.landing
		};
	}
	if (e.poss === t) return null;
	let c = o(t).filter((t) => !$(e, t)), l = vn(e, t), u = l && o(t).includes(l) && A(a, t), d = Math.max(0, ...(r.atkContest ?? []).map((t) => Q(e, t).heading)), f = !!u && Q(e, l).aerial >= d + 2;
	return {
		type: "headDef",
		contesters: s(c).slice(0, 2),
		gk: f
	};
}
function Pn(e, t, n, r) {
	let i = r.steps[0];
	if ((i[0] === "a" ? e.poss : Z(e.poss)) !== t) return null;
	let a = Number(i[1]), o = t === e.poss, s = /* @__PURE__ */ new Set(), c = [], l = (e) => {
		let t = C(e.c, e.r);
		return T(e.c, e.r) && !n.has(t) && !s.has(t);
	}, u = (e, t) => {
		s.add(C(t.c, t.r)), c.push({
			pid: e,
			to: C(t.c, t.r)
		});
	}, d = (e, t) => {
		let n = [];
		for (let r = -t; r <= t; r += 1) for (let i = -t; i <= t; i += 1) {
			let a = {
				c: e.c + r,
				r: e.r + i
			};
			E(a, e) <= t && l(a) && n.push(a);
		}
		return n.sort((t, n) => E(t, e) - E(n, e) || Math.abs(t.r - 12) - Math.abs(n.r - 12));
	}, f = w(e.ball);
	if (r.kind === "corner") {
		let n = ge(o ? Z(t) : t), r = d(n, 2), i = e.onPitch[t].filter((t) => !$(e, t) && E(w(e.pos[t]), n) > 2).sort((t, n) => Q(e, n).heading - Q(e, t).heading);
		for (let e of i) {
			if (c.length >= a || r.length === 0) break;
			u(e, r.shift());
		}
		return {
			type: "spPlace",
			moves: c
		};
	}
	if (o) {
		let n = (t) => E(w(e.pos[t]), f) <= 1, r = z(f, t) ? ge(Z(t)) : {
			c: gn(t) === 36 ? 29 : 7,
			r: 12
		}, i = d(r, 2), o = e.onPitch[t].filter((t) => !$(e, t) && !n(t) && E(w(e.pos[t]), r) > 2).sort((t, n) => Q(e, n).shooting + Q(e, n).heading - (Q(e, t).shooting + Q(e, t).heading));
		for (let e of o) {
			if (c.length >= a || i.length === 0) break;
			u(e, i.shift());
		}
		return {
			type: "spPlace",
			moves: c
		};
	}
	let p = O(f, {
		c: gn(t),
		r: 12
	}).filter((e) => E(e, f) >= 2 && l(e));
	p.sort((e, t) => E(t, f) - E(e, f));
	let m = e.onPitch[t].filter((t) => !$(e, t)).sort((t, n) => Q(e, n).tackling - Q(e, t).tackling);
	for (let e of m) {
		if (c.length >= a || p.length === 0) break;
		u(e, p.shift());
	}
	return {
		type: "spPlace",
		moves: c
	};
}
function Fn(e, t, n, r) {
	let i = w(e.ball), a = e.onPitch[t].filter((t) => E(w(e.pos[t]), i) <= 1);
	if (a.length === 0) return null;
	let o = a.sort((t, n) => Q(e, n).shooting - Q(e, t).shooting)[0];
	if (z(i, t)) {
		let n = Cn(e, t, i, Q(e, o).shooting, { fk: !0 });
		if (n.exp >= (r ? .45 : .25)) return {
			type: "fkTake",
			kind: "shot",
			by: o,
			to: _n(t, n.row)
		};
	}
	let s = null, c = .03;
	for (let r of e.onPitch[t]) {
		if (r === o) continue;
		let a = w(e.pos[r]);
		if (E(i, a) > S.standard || !Dn(n, i, a, t)) continue;
		let l = jn(e, n, t, i, 0, r);
		l > c && (c = l, s = r);
	}
	if (s) return {
		type: "fkTake",
		kind: "std",
		by: o,
		to: e.pos[s]
	};
	let l = null, u = 0;
	for (let n of e.onPitch[t]) {
		if (n === o) continue;
		let r = w(e.pos[n]), a = E(i, r);
		if (a < 3 || a > S.highPass || !A(r, Z(t))) continue;
		let s = Q(e, n).heading;
		s > u && (u = s, l = n);
	}
	if (l && Q(e, o).highPass >= 4) return {
		type: "fkTake",
		kind: "high",
		by: o,
		to: e.pos[l]
	};
	let d = D(i).find((e) => T(e.c, e.r) && !n.has(C(e.c, e.r)));
	return d ? {
		type: "fkTake",
		kind: "std",
		by: o,
		to: C(d.c, d.r)
	} : null;
}
function In(e, t, n, r, i) {
	let a = Z(t), o = w(e.ball), s = new Set(i.moved), c = e.holder, l = c && mn(c) === t ? c : null;
	if (i.step !== "d") {
		if (l && z(o, t)) {
			let n = Cn(e, t, o, Q(e, l).shooting, { snap: !0 }), i = r ? A(o, a) ? .45 : 99 : e.actionsLeft <= 2 ? .15 : .3;
			if (n.exp >= i) return {
				type: "snapshot",
				to: _n(t, n.row)
			};
		}
		let u = i.step === "a2" ? 2 : Infinity;
		if (l && !s.has(l)) {
			let r = An(e, t, n, l, Math.min(u, Q(e, l).pace), !0), i = z(o, t) ? Cn(e, t, o, Q(e, l).shooting, { snap: !0 }).exp : 0, a = null, s = i + .02;
			for (let [i, o] of r) {
				if (n.has(i) || o.path.length === 0) continue;
				let r = w(i), c = z(r, t) ? Cn(e, t, r, Q(e, l).shooting, { snap: !0 }).exp : hn(r, t) * .01;
				c += hn(r, t) * .004 - o.risk * .6, c > s && (s = c, a = i);
			}
			if (a) return {
				type: "mv",
				pid: l,
				path: r.get(a).path
			};
		}
		if (!c) {
			let r = e.onPitch[t].filter((e) => !s.has(e)).sort((t, n) => E(w(e.pos[t]), o) - E(w(e.pos[n]), o))[0];
			if (r) {
				let i = An(e, t, n, r, Math.min(u, Q(e, r).pace), !1), a = null, s = E(w(e.pos[r]), o);
				for (let [e, t] of i) {
					if (n.has(e) || t.path.length === 0) continue;
					let r = E(w(e), o);
					r < s && (s = r, a = e);
				}
				if (a) return {
					type: "mv",
					pid: r,
					path: i.get(a).path
				};
			}
			return { type: "mvStep" };
		}
		let d = null, f = [], p = .03;
		for (let r of e.onPitch[t]) {
			if (s.has(r) || r === l || $(e, r)) continue;
			let i = wn(t, w(e.pos[r])), a = An(e, t, n, r, Math.min(u, Q(e, r).pace), !1);
			for (let [o, s] of a) {
				if (n.has(o) || s.path.length === 0) continue;
				let a = w(o), c = wn(t, a) - i - Tn(e, t, a) * .02 - s.cost * .002;
				c > p && (p = c, d = r, f = s.path);
			}
		}
		return d ? {
			type: "mv",
			pid: d,
			path: f
		} : { type: "mvStep" };
	}
	let u = e.onPitch[t].filter((t) => !s.has(t) && !$(e, t));
	if (u.length === 0) return { type: "mvStep" };
	let d = (r, i) => {
		let a = An(e, t, n, r, Q(e, r).pace, !1), o = null, s = E(w(e.pos[r]), i);
		for (let [e, t] of a) {
			if (n.has(e) || t.path.length === 0) continue;
			let r = E(w(e), i);
			r < s && (s = r, o = e);
		}
		return o ? {
			type: "mvd",
			pid: r,
			path: a.get(o).path
		} : null;
	};
	if (!c) {
		let t = u.sort((t, n) => E(w(e.pos[t]), o) - E(w(e.pos[n]), o))[0];
		return d(t, o) ?? { type: "mvStep" };
	}
	if (mn(c) === t) return { type: "mvStep" };
	let f = e.onPitch[t].filter((t) => E(w(e.pos[t]), o) <= 2).length, p = u.sort((t, n) => E(w(e.pos[t]), o) - E(w(e.pos[n]), o))[0], m = (n, r) => {
		let i = $(e, n) && A(r, t) ? Q(e, n).saving : Q(e, n).tackling, a = Q(e, c).dribbling, [o] = bn(i, a);
		return o - 1 / 6 * (A(w(e.pos[c]), t) ? 1.2 : .35);
	};
	if (f < 2) {
		let i = w(e.pos[p]);
		if (E(i, o) === 1) {
			if (!r && m(p, i) > .25) {
				let e = D(i).find((e) => T(e.c, e.r) && !n.has(C(e.c, e.r)) && E(e, o) === 1);
				if (e) return {
					type: "mvd",
					pid: p,
					path: [C(e.c, e.r)],
					tackle: "std"
				};
			}
		} else {
			let a = An(e, t, n, p, Q(e, p).pace, !1), s = null, c = E(i, o);
			for (let [e, t] of a) {
				if (n.has(e) || t.path.length === 0) continue;
				let r = E(w(e), o);
				(r < c || r === c && r === 1 && s === null) && (c = r, s = e);
			}
			if (s) {
				let e = w(s), t = !r && E(e, o) === 1 && m(p, e) > .25 ? "std" : void 0;
				return {
					type: "mvd",
					pid: p,
					path: a.get(s).path,
					tackle: t
				};
			}
		}
	}
	let h = Q(e, c).shooting, g = z(o, a) ? Cn(e, a, o, h, {}) : null, _ = u.filter((e) => e !== p);
	if (_.length === 0) return { type: "mvStep" };
	if (g && g.exp > .12) {
		let r = O(o, {
			c: gn(a),
			r: g.row
		});
		for (let i of [...r].sort((e, t) => E(t, o) - E(e, o))) {
			let r = C(i.c, i.r);
			if (n.has(r)) continue;
			let a = _.map((t) => ({
				pid: t,
				d: E(w(e.pos[t]), i)
			})).filter((t) => t.d <= Q(e, t.pid).pace).sort((e, t) => e.d - t.d)[0];
			if (!a) continue;
			let o = Ln(e, t, n, a.pid, i);
			if (o && o.length > 0) return {
				type: "mvd",
				pid: a.pid,
				path: o
			};
		}
	}
	let v = null, y = .15;
	for (let t of e.onPitch[a]) {
		if (t === c || $(e, t)) continue;
		let n = wn(a, w(e.pos[t]));
		n > y && (y = n, v = t);
	}
	if (v) {
		let r = D(w(e.pos[v])).filter((e) => T(e.c, e.r) && !n.has(C(e.c, e.r))).sort((e, n) => hn(e, t) - hn(n, t))[0];
		if (r) {
			let i = _.sort((t, n) => E(w(e.pos[t]), r) - E(w(e.pos[n]), r))[0], a = Ln(e, t, n, i, r);
			if (a) return {
				type: "mvd",
				pid: i,
				path: a
			};
		}
	}
	return { type: "mvStep" };
}
function Ln(e, t, n, r, i) {
	let a = An(e, t, n, r, Q(e, r).pace, !1), o = C(i.c, i.r);
	if (a.has(o) && a.get(o).path.length > 0) return a.get(o).path;
	let s = null, c = E(w(e.pos[r]), i);
	for (let [e, t] of a) {
		if (n.has(e) || t.path.length === 0) continue;
		let r = E(w(e), i);
		r < c && (c = r, s = e);
	}
	return s ? a.get(s).path : null;
}
function Rn(e, t, n, r) {
	let i = w(e.ball), a = e.holder && mn(e.holder) === t ? e.holder : null;
	if (!a) return { type: "startMove" };
	let o = Z(t), s = Q(e, a).shooting, c = z(i, t) ? Cn(e, t, i, s, {}) : null, l = r ? A(i, o) ? .45 : 99 : e.actionsLeft <= 2 ? .15 : .33;
	if (c && c.exp >= l) return {
		type: "shoot",
		to: _n(t, c.row)
	};
	let u = c?.exp ?? 0, d = null;
	for (let r of e.onPitch[t]) {
		if (r === a) continue;
		let o = w(e.pos[r]);
		if (!Dn(n, i, o, t)) continue;
		let s = E(i, o);
		if (s <= S.standard) {
			let a = jn(e, n, t, i, u, r);
			(!d || a > d.v) && (d = {
				pid: r,
				kind: "std",
				v: a
			});
		}
		if (e.canFT && s <= S.firstTime) {
			let a = jn(e, n, t, i, u, r) + .02;
			(!d || a > d.v) && (d = {
				pid: r,
				kind: "ft",
				v: a
			});
		}
	}
	let f = r ? .08 : .04;
	if (d && d.v > f) return {
		type: "pass",
		kind: d.kind,
		to: e.pos[d.pid]
	};
	if (!r) {
		let r = Q(e, a), o = null, s = 0;
		for (let r of e.onPitch[t]) {
			if (r === a) continue;
			let c = w(e.pos[r]), l = E(i, c);
			if (l < 3 || l > S.highPass || hn(c, t) < hn(i, t) + 3) continue;
			let u = O(i, c)[0];
			if (u) {
				let e = n.get(C(u.c, u.r));
				if (e && mn(e) !== t) continue;
			}
			let d = Q(e, r).heading + wn(t, c) * 4;
			d > s && (s = d, o = r);
		}
		if (o && r.highPass >= 4 && s >= 5) return {
			type: "pass",
			kind: "high",
			to: e.pos[o]
		};
	}
	return { type: "startMove" };
}
var zn = (e, t) => {
	let n = e.public, r = e.private?.mySide ?? null;
	if (r === null || n.phase === "over") return null;
	let i = t.difficulty === "weak", a = Z(r), o = yn(n), s = w(n.ball), c = n.mode;
	if (n.phase === "draft") {
		let e = Mn(n, r, i);
		return e ? { action: e } : null;
	}
	if (n.phase === "lineup") return n.lineupReady[r] ? null : { action: { type: "lineupConfirm" } };
	if (c.k === "header") {
		let e = Nn(n, r, i, c);
		return e ? { action: e } : null;
	}
	if (c.k === "ft") {
		if ((c.who === "atk" ? n.poss : Z(n.poss)) !== r) return null;
		if (c.who === "def") {
			let e = O(s, w(c.to));
			for (let t of n.onPitch[r]) {
				if ($(n, t)) continue;
				let r = w(n.pos[t]);
				if (e.some((e) => E(e, r) <= 1)) continue;
				let i = D(r).find((t) => T(t.c, t.r) && !o.has(C(t.c, t.r)) && e.some((e) => E(e, t) <= 1));
				if (i) return { action: {
					type: "ftMove",
					pid: t,
					to: C(i.c, i.r)
				} };
			}
		}
		return { action: { type: "ftSkip" } };
	}
	if (c.k === "hp") {
		if ((c.who === "atk" ? n.poss : Z(n.poss)) !== r) return null;
		let e = w(c.to);
		if (!n.onPitch[r].some((t) => E(w(n.pos[t]), e) <= 2)) {
			let t = n.onPitch[r].filter((t) => E(w(n.pos[t]), e) <= 5).sort((e, t) => Q(n, t).heading + Q(n, t).aerial - (Q(n, e).heading + Q(n, e).aerial))[0];
			if (t) {
				let r = w(n.pos[t]), i = D(r).filter((t) => T(t.c, t.r) && !o.has(C(t.c, t.r)) && E(t, e) < E(r, e)).sort((t, n) => E(t, e) - E(n, e))[0];
				if (i) return { action: {
					type: "hpMove",
					pid: t,
					to: C(i.c, i.r)
				} };
			}
		}
		return { action: { type: "hpSkip" } };
	}
	if (c.k === "snap") {
		if (n.poss === r) return null;
		let e = vn(n, r);
		if (e) {
			let t = w(n.pos[e]), i = w(c.to), a = Math.max(k[0], Math.min(k[6], i.r));
			if (t.r !== a) {
				let n = D(t).filter((e) => T(e.c, e.r) && !o.has(C(e.c, e.r)) && Math.abs(e.r - a) < Math.abs(t.r - a)).sort((e, t) => Math.abs(e.r - a) - Math.abs(t.r - a) || E(e, {
					c: gn(r),
					r: a
				}) - E(t, {
					c: gn(r),
					r: a
				}))[0];
				if (n && E(t, n) === 1) return { action: {
					type: "snapMove",
					pid: e,
					to: C(n.c, n.r)
				} };
			}
		}
		return { action: { type: "snapSkip" } };
	}
	if (c.k === "foul") {
		if (n.poss !== r) return null;
		let e = n.holder && mn(n.holder) === r;
		if (!c.inBox && e && z(s, r)) {
			let e = Cn(n, r, s, Q(n, n.holder).shooting, {}), t = Cn(n, r, w(c.spot), Q(n, n.holder).shooting, { fk: !0 });
			if (e.exp > t.exp + .05) return { action: {
				type: "foulChoice",
				take: !1
			} };
		}
		return { action: {
			type: "foulChoice",
			take: !0
		} };
	}
	if (c.k === "sp") {
		if (c.steps.length > 0) {
			let e = Pn(n, r, o, c);
			return e ? { action: e } : null;
		}
		if (n.poss !== r) return null;
		if (c.kind === "fk") {
			let e = Fn(n, r, o, i);
			return e ? { action: e } : null;
		}
		let e = ge(a);
		return { action: {
			type: "cornerTake",
			kind: "high",
			to: C(e.c, e.r)
		} };
	}
	if (c.k === "pen") return n.poss === r ? { action: {
		type: "penTake",
		to: _n(r, 9)
	} } : null;
	if (c.k === "throw") {
		if (n.poss !== r) return null;
		let e = w(c.spot);
		if (!c.thrower) {
			let t = n.onPitch[r].filter((e) => !$(n, e)).sort((t, r) => E(w(n.pos[t]), e) - E(w(n.pos[r]), e))[0];
			return t ? { action: {
				type: "throwPick",
				pid: t
			} } : null;
		}
		let t = null, i = 0;
		for (let a of n.onPitch[r]) {
			if (a === c.thrower) continue;
			let s = w(n.pos[a]);
			if (E(e, s) > S.firstTime || !Dn(o, e, s, r)) continue;
			let l = jn(n, o, r, e, 0, a);
			l > i && (i = l, t = a);
		}
		if (t && i > .02) return { action: {
			type: "throwTake",
			kind: "feet",
			to: n.pos[t]
		} };
		if (ve(e, r) && c.movesLeft > 0) return { action: { type: "startMove" } };
		if (t) return { action: {
			type: "throwTake",
			kind: "feet",
			to: n.pos[t]
		} };
		let a = D(e).find((e) => T(e.c, e.r) && !o.has(C(e.c, e.r)));
		return a ? { action: {
			type: "throwTake",
			kind: "feet",
			to: C(a.c, a.r)
		} } : null;
	}
	if (c.k === "gk") {
		if (n.poss !== r) return null;
		if (!c.kick) {
			let e = null, t = 0;
			for (let i of n.onPitch[r]) {
				if ($(n, i)) continue;
				let a = w(n.pos[i]);
				if (E(s, a) > S.standard || !Dn(o, s, a, r)) continue;
				let c = hn(a, r) * .02 + wn(r, a) - Tn(n, r, a) * .05;
				c > t && (t = c, e = i);
			}
			return e ? { action: {
				type: "gkThrow",
				to: n.pos[e]
			} } : { action: { type: "gkDrop" } };
		}
		let e = null, t = .1;
		for (let i of n.onPitch[r]) {
			if ($(n, i)) continue;
			let a = w(n.pos[i]);
			if (E(s, a) > S.standard || !Dn(o, s, a, r)) continue;
			let c = jn(n, o, r, s, 0, i);
			c > t && (t = c, e = i);
		}
		if (e) return { action: {
			type: "gkTake",
			kind: "std",
			to: n.pos[e]
		} };
		let i = n.onPitch[r].filter((e) => {
			if ($(n, e)) return !1;
			let t = w(n.pos[e]);
			if (ve(t, r) || n.pos[e] === n.ball) return !1;
			let i = O(s, t)[0];
			if (i) {
				let e = o.get(C(i.c, i.r));
				if (e && mn(e) !== r) return !1;
			}
			return !0;
		});
		if (i.length > 0) {
			let e = i.sort((e, t) => hn(w(n.pos[t]), r) + Q(n, t).heading * .5 - (hn(w(n.pos[e]), r) + Q(n, e).heading * .5))[0];
			return { action: {
				type: "gkTake",
				kind: "kick",
				to: n.pos[e]
			} };
		}
		for (let e of n.onPitch[r]) {
			if ($(n, e)) continue;
			let t = w(n.pos[e]);
			if (E(s, t) <= S.standard && Dn(o, s, t, r)) return { action: {
				type: "gkTake",
				kind: "std",
				to: n.pos[e]
			} };
		}
		return null;
	}
	if (c.k === "move") {
		if ((c.step === "d" ? Z(n.poss) : n.poss) !== r) return null;
		let e = In(n, r, o, i, c);
		return e ? { action: e } : null;
	}
	return c.k === "action" && n.poss === r ? { action: Rn(n, r, o, i) } : null;
}, Bn = (e, t, n) => {
	switch (e.type) {
		case "draftPick": return n("games.counterattack.draftYourTurn");
		case "lineupConfirm": return n("games.counterattack.lineupConfirm");
		case "startMove": return n("games.counterattack.actMove");
		case "pass": return n(e.kind === "std" ? "games.counterattack.actPassStd" : e.kind === "ft" ? "games.counterattack.actPassFT" : e.kind === "high" ? "games.counterattack.actPassHigh" : "games.counterattack.actPassLong");
		case "shoot": return n("games.counterattack.actShoot");
		case "snapshot": return n("games.counterattack.actSnapshot");
		case "mv":
		case "mvStep": return n("games.counterattack.actMove");
		case "mvd": return e.tackle === "reckless" ? n("games.counterattack.tackleReckless") : e.tackle === "std" ? n("games.counterattack.tackleStd") : n("games.counterattack.actMove");
		case "headAtk": return e.intent === "shot" ? n("games.counterattack.headShot") : e.intent === "control" ? n("games.counterattack.headControl") : n("games.counterattack.headPass");
		case "headDef": return n("games.counterattack.headPrompt");
		case "foulChoice": return e.take ? n("games.counterattack.foulTakeFk") : n("games.counterattack.foulPlayOn");
		case "fkTake": return e.kind === "shot" ? n("games.counterattack.fkShot") : n("games.counterattack.fkStd");
		case "cornerTake": return e.kind === "high" ? n("games.counterattack.cornerHigh") : n("games.counterattack.cornerLow");
		case "penTake": return n("games.counterattack.penTake");
		case "throwTake": return e.kind === "head" ? n("games.counterattack.throwHead") : n("games.counterattack.throwFeet");
		case "gkThrow": return n("games.counterattack.gkThrow");
		case "gkKick":
		case "gkTake": return n("games.counterattack.gkKick");
		case "gkDrop": return n("games.counterattack.gkDrop");
		default: return "";
	}
};
//#endregion
//#region src/games/counterattack/game-over.tsx
function Vn({ result: e, hintCount: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ g("div", {
		className: "ca-over",
		children: /* @__PURE__ */ g(v, {
			result: e,
			hintCount: t,
			members: n,
			myRid: r,
			accent: oe.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/counterattack/options.tsx
var Hn = [
	12,
	20,
	30
];
function Un({ value: e, onChange: t }) {
	let n = c(), r = yt.safeParse(e), i = r.success ? r.data : yt.parse(void 0);
	return /* @__PURE__ */ _("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ g(ee, {
			title: n("games.counterattack.optSquadMode"),
			children: ["preset", "draft"].map((e) => /* @__PURE__ */ g(y, {
				name: "counterattack-squad-mode",
				value: e,
				checked: i.squadMode === e,
				label: n(e === "preset" ? "games.counterattack.optSquadPreset" : "games.counterattack.optSquadDraft"),
				accent: oe.accent,
				onChange: () => t({
					...i,
					squadMode: e
				})
			}, e))
		}), /* @__PURE__ */ g(ee, {
			title: n("games.counterattack.optHalfLength"),
			columns: 3,
			children: Hn.map((e) => /* @__PURE__ */ g(y, {
				name: "counterattack-half-length",
				value: String(e),
				checked: i.halfLength === e,
				label: n("games.counterattack.halfN", { n: e }),
				accent: oe.accent,
				onChange: () => t({
					...i,
					halfLength: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/counterattack/entry.tsx
var Wn = {
	definition: zt,
	View: cn,
	bot: zn,
	describe: Bn,
	OverView: Vn,
	Options: Un,
	locales: {
		zh: Vt,
		en: Bt
	}
};
//#endregion
export { Wn as default };
