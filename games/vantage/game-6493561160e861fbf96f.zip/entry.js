import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { useEffect as n, useRef as r, useState as i, useSyncExternalStore as a } from "react";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { loadGameAssetUrl as s } from "@bgparty/sdk/assets";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { ConfirmButton as h } from "@bgparty/sdk/confirm-button";
import { IconExpand as g, IconLog as _ } from "@bgparty/sdk/icons";
import { seatName as v } from "@bgparty/sdk/ui/player-strip";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region \0bgparty-json:D:/Other/BG/BGParty/src/games/vantage/cards.json.mjs
var x = await fetch("games/vantage/data/cards.json").then((e) => e.json()), S = await fetch("games/vantage/data/stories.json").then((e) => e.json()), C = [
	"move",
	"look",
	"engage",
	"help",
	"take",
	"overpower"
], w = [
	"time",
	"morale",
	"health"
], T = [
	"time",
	"morale",
	"health",
	"setback",
	"blank",
	"blank"
], E = x, D = S;
function O(e, t) {
	return Object.values(D).filter((n) => n.card === e && (!t || n.book === t));
}
function ee(e) {
	return e.book === "depart" ? "move" : C.includes(e.book) ? e.book : "look";
}
var te = [
	[
		761,
		691,
		770,
		683,
		694,
		780,
		787,
		387,
		385,
		709,
		301,
		676,
		667,
		664,
		680,
		705,
		316,
		351,
		773,
		668,
		305
	],
	[
		126,
		308,
		357,
		725,
		374,
		405,
		115,
		471,
		140,
		354,
		146,
		722,
		112,
		148,
		411,
		137,
		359,
		314,
		408,
		136,
		106
	],
	[
		426,
		476,
		134,
		631,
		479,
		734,
		144,
		433,
		362,
		456,
		449,
		751,
		452,
		364,
		366,
		368,
		119,
		428,
		737,
		755,
		739
	],
	[
		601,
		221,
		346,
		622,
		194,
		777,
		228,
		249,
		192,
		349,
		400,
		397,
		237,
		225,
		180,
		183,
		205,
		402,
		177,
		784,
		245
	],
	[
		613,
		223,
		610,
		501,
		267,
		258,
		203,
		417,
		423,
		153,
		123,
		212,
		270,
		482,
		414,
		629,
		419,
		150,
		172,
		496,
		163
	],
	[
		298,
		297,
		269,
		747,
		759,
		278,
		508,
		338,
		469,
		464,
		460,
		506,
		437,
		444,
		275,
		286,
		336,
		334,
		288,
		441,
		447
	]
], ne = [
	1590,
	1596,
	1578,
	1581,
	1589,
	1577,
	1583,
	1584,
	1585,
	1586,
	1587,
	1588,
	1582,
	1595,
	1591,
	1592,
	1593,
	1594,
	1580,
	1579,
	1597
];
function re(e, t) {
	if (e === t) return e;
	let n = [e, t].sort((e, t) => e - t).join(":");
	return 6 + [
		"0:1",
		"1:2",
		"2:3",
		"3:4",
		"4:5",
		"2:5",
		"0:3",
		"1:4",
		"3:5",
		"1:3",
		"0:4",
		"1:5",
		"0:5",
		"0:2",
		"2:4"
	].indexOf(n);
}
//#endregion
//#region src/games/vantage/action-coins.ts
function ie(e, t, n, r = !1) {
	let i = e?.actionCoin ?? (e?.coinDiscount ? {
		cost: 1,
		discount: "one",
		once: !1
	} : void 0);
	return i && t >= 0 && (!i.once || !n && !r) && (i.discount === "none" || t > 0) ? i : null;
}
//#endregion
//#region src/games/vantage/effects.ts
function k(e, t) {
	if (e.puzzle) return {
		effects: [{
			kind: "puzzle",
			amount: e.puzzle,
			value: ""
		}],
		blocked: !1,
		continuation: "no"
	};
	if (e.flight || e.returnSky) return {
		effects: [{
			kind: e.flight ? "flight" : "returnSky",
			amount: +!!e.ignoreFlightHypoxia,
			value: ""
		}],
		blocked: !1,
		continuation: "no"
	};
	if (e.dragonEscape) return {
		effects: [{
			kind: "dragonEscape",
			amount: 1,
			value: ""
		}],
		blocked: !1,
		continuation: "no"
	};
	if (e.rewind) return {
		effects: [{
			kind: "rewind",
			amount: 1,
			value: ""
		}],
		blocked: !1,
		continuation: "no"
	};
	if (e.questProgress) return {
		effects: [{
			kind: "questProgress",
			amount: 1,
			value: e.questProgress
		}],
		blocked: !1,
		continuation: "no"
	};
	if (e.elemental) return {
		effects: [{
			kind: "elemental",
			amount: e.elementalSpell ?? 1,
			value: e.elemental
		}],
		blocked: !1,
		continuation: e.elemental === "retreat" ? "no" : "must"
	};
	if (e.sentientTrial) return {
		effects: [{
			kind: "sentientTrial",
			amount: e.sentientTrial.dice,
			value: e.sentientTrial.bond ? "bond" : "boost"
		}],
		blocked: !1,
		continuation: "no"
	};
	if (e.conquest) return {
		effects: [{
			kind: "conquest",
			amount: 1,
			value: ""
		}],
		blocked: !1,
		continuation: "no"
	};
	let n = e.beforeTest ? k({
		text: e.beforeTest,
		choices: []
	}) : null, r = [...n?.effects ?? []];
	if (e.nextBonus && r.push({
		kind: "printedAbility",
		amount: 0,
		value: "nextBonus"
	}), e.miniGame && r.push({
		kind: "miniGame",
		amount: e.miniVariant ?? 0,
		value: e.miniGame
	}), e.miniSkills && r.push({
		kind: "miniSkills",
		amount: 1,
		value: e.miniSkills
	}), e.miniCoins && r.push({
		kind: "miniCoins",
		amount: 1,
		value: ""
	}), e.crewLocations && r.push({
		kind: "crewLocations",
		amount: 1,
		value: ""
	}), e.barter && r.push({
		kind: "barter",
		amount: e.barter.max,
		value: JSON.stringify(e.barter)
	}), e.coinCount && r.push({
		kind: "coinCount",
		amount: 0,
		value: e.coinCount
	}), e.paymentRewards) for (let e of [
		"time",
		"morale",
		"health"
	]) r.push({
		kind: "partyStat",
		amount: 1,
		value: "contributors:" + e
	});
	for (let t of e.partyStats ?? []) r.push({
		kind: "partyStat",
		amount: t.amount,
		value: (t.others ? "others:" : "all:") + t.stat
	});
	e.challengeCheck && r.push({
		kind: "challengeCheck",
		amount: 1,
		value: ""
	}), e.loseRememberedSkirm && r.push({
		kind: "loseRememberedSkirm",
		amount: 1,
		value: ""
	}), e.copyAction && r.push({
		kind: "copyAction",
		amount: 0,
		value: ""
	}), e.printedAbility && r.push({
		kind: "printedAbility",
		amount: 0,
		value: e.printedAbility
	}), e.actionLock && r.push({
		kind: "printedAbility",
		amount: 0,
		value: "actionLock"
	}), e.commonPreparation && r.push({
		kind: "preparation",
		amount: 1,
		value: "prepare"
	}), e.selectedBoost && r.push({
		kind: "selectedBoost",
		amount: e.selectedBoost.max,
		value: e.selectedBoost.trait,
		minimum: e.selectedBoost.min
	}), e.masterReward && r.push({
		kind: "masterReward",
		amount: 1,
		value: ""
	}), e.animalAir && r.push({
		kind: "animalAir",
		amount: 1,
		value: e.animalAir
	}), e.gardenTuck && r.push({
		kind: "gardenTuck",
		amount: 1,
		value: String(e.gardenTuck)
	}), e.gardenPluck && r.push({
		kind: "gardenPluck",
		amount: 1,
		value: ""
	}), e.lostSkill && r.push({
		kind: "loseSkill",
		amount: 1,
		value: ""
	});
	for (let t = 0; t < (e.chosenSkills ?? 0); t++) r.push({
		kind: "skillChoice",
		amount: 1,
		value: ""
	});
	e.replaceCard && r.push({
		kind: "replaceCard",
		amount: 1,
		value: String(e.replaceCard)
	}), e.trap && r.push({
		kind: "trap",
		amount: 3,
		value: e.trap
	}), e.boostMatching && r.push({
		kind: "boostMatching",
		amount: 1,
		value: e.boostMatching
	}), e.challengeReward && r.push({
		kind: "challengeReward",
		amount: 1,
		value: ""
	}), e.structureTrade && r.push({
		kind: "structureTrade",
		amount: typeof e.structureTrade.amount == "number" ? e.structureTrade.amount : e.structureTrade.amount === "X" ? -1 : e.structureTrade.amount === "source" ? -2 : -3,
		value: e.structureTrade.kind + ":" + (e.structureTrade.trait ?? "")
	}), e.nextActionDiscount && r.push({
		kind: "nextActionDiscount",
		amount: 0,
		value: ""
	}), e.makeShelter && r.push({
		kind: "makeShelter",
		amount: 1,
		value: ""
	}), e.keepTestAll && r.push({
		kind: "keepTestAll",
		amount: 0,
		value: ""
	}), e.reserveVehicles && r.push({
		kind: "reserveVehicles",
		amount: 0,
		value: ""
	}), e.diveTo && r.push({
		kind: "dive",
		amount: e.ignoreArrivalDamage === "cold" ? 2 : e.ignoreArrivalDamage === "heat" ? 3 : 1,
		value: String(e.diveTo)
	}), e.gridRefresh && r.push({
		kind: "gridRefresh",
		amount: e.gridRefresh,
		value: e.exactGridRefresh ? "exact" : ""
	}), e.runeFocus && r.push({
		kind: "runeBoost",
		amount: 1,
		value: ""
	}, {
		kind: "runeRoll",
		amount: e.runeDice ?? -1,
		value: ""
	}, {
		kind: "runeQuest",
		amount: 1,
		value: ""
	}), e.runeSkills && r.push({
		kind: "runeSkill",
		amount: e.runeSkills,
		value: ""
	}), e.crewShare && r.push({
		kind: "crewShare",
		amount: 1,
		value: ""
	}), e.crewLearn && r.push({
		kind: "crewLearn",
		amount: 1,
		value: ""
	}), e.stowCards && r.push({
		kind: "stowCards",
		amount: 0,
		value: ""
	}), e.upgradeVehicle && r.push({
		kind: "upgradeVehicle",
		amount: 1,
		value: String(e.upgradeVehicle)
	}), e.signal && r.push({
		kind: "signal",
		amount: 1,
		value: ""
	}), e.missionPivot && r.push({
		kind: "missionPivot",
		amount: 1,
		value: String(e.missionPivot)
	}), e.missionSkillChoice && r.push({
		kind: "skillChoice",
		amount: 1,
		value: ""
	}), e.cardBoost && r.push({
		kind: "cardWithBoost",
		amount: e.cardBoost.boost,
		value: String(e.cardBoost.card)
	}), e.cardIfMissing && r.push({
		kind: "cardIfMissing",
		amount: 1,
		value: String(e.cardIfMissing)
	}), e.forbidLocation && r.push({
		kind: "forbidLocation",
		amount: 1,
		value: String(e.forbidLocation)
	}), e.characterUpgrade && r.push({
		kind: "powerArmor",
		amount: +!!e.characterUpgrade.optional,
		value: String(e.characterUpgrade.duplicateBoost)
	});
	for (let t of e.partySkills ?? []) r.push({
		kind: "partySkill",
		amount: t.amount,
		value: (t.others ? "others:" : "all:") + t.skill
	});
	e.cardInitialBoost && r.push({
		kind: "cardInitialBoost",
		amount: e.cardInitialBoost.boost,
		value: String(e.cardInitialBoost.card)
	}), e.rest && r.push({
		kind: "rest",
		amount: 0,
		value: ""
	}), e.skillTest && r.push({
		kind: "skillTest",
		amount: typeof e.skillTest.count == "number" ? e.skillTest.count : -1,
		value: ""
	}), e.keepTestSkill && r.push({
		kind: "keepTestSkill",
		amount: 0,
		value: e.keepTestSkill
	});
	for (let t of e.keepTestSkills ?? []) r.push({
		kind: "keepTestSkill",
		amount: 0,
		value: t
	});
	e.pickTestCount && r.push({
		kind: "testPickMany",
		amount: e.pickTestCount,
		value: String(e.pickTestCount)
	}), e.testPickOne && r.push({
		kind: "testPickOne",
		amount: 1,
		value: ""
	}), e.matchingTestReward && r.push({
		kind: "matchingTestReward",
		amount: 1,
		value: ""
	});
	for (let t of [...e.testRewards ?? [], ...e.testReward ? [e.testReward] : []]) r.push({
		kind: t.stat === "boost" ? "testBoost" : "testStat",
		amount: t.amount,
		value: t.stat + ":" + t.skill
	});
	e.testDamage && r.push({
		kind: "damage",
		amount: (t ?? []).filter((t) => e.testDamage.skills.includes(t)).length,
		value: e.testDamage.kind
	});
	let i = n?.blocked ?? !1, a = e.continuation ?? (e.rest ? "no" : /you may continue/i.test(e.text) ? "may" : /\bcontinue\b/i.test(e.text) && !/proceed with|continue your adventure/i.test(e.text) ? "must" : "no"), o = (e.instructions ?? e.text).replace(/(\bLose (?:item|card|quest|objective|sentient|flora|animal|vehicle|spell|curse) \d{3,4}) \(if you (?:still )?have (?:it|them)\)/gi, "$1").split(/(?<=[.!?;])\s+|(?<=[.!?;][”"’'])\s+/).flatMap((e) => /\b(if|unless|per|each|for every|instead|may|either|or|chosen|choose)\b/i.test(e) || /^\s*Roll \d+ skill dice (?:and (?:gain|keep) all|; gain all)/i.test(e) ? [e] : e.split(/(?:[,;]\s*(?:and\s+)?|\band\s+|\bthen\s+)(?=(?:gain|lose|go to|suffer|refresh)\b)/i));
	for (let t of o) {
		let n = /^CLEANSE (\d+) (optional|required)[.!;]?$/i.exec(t.trim());
		if (n) {
			r.push({
				kind: "removeCurses",
				amount: Number(n[1]),
				value: n[2].toLowerCase()
			});
			continue;
		}
		if (/^Gain X boost on this card[.]?$/i.test(t.trim())) {
			r.push({
				kind: "boostX",
				amount: 0,
				value: ""
			});
			continue;
		}
		if (/^Gain \$X[.]?$/i.test(t.trim())) {
			r.push({
				kind: "coinX",
				amount: 0,
				value: ""
			});
			continue;
		}
		if (/^Gain \$X \(X is the number of boost on this structure\)[.]?$/i.test(t.trim())) {
			r.push({
				kind: "sourceCoin",
				amount: 0,
				value: ""
			});
			continue;
		}
		if (/^If this action[’']s cost was not reduced to 1, also gain 1 morale[.]?$/i.test(t.trim())) {
			r.push({
				kind: "obstacleMorale",
				amount: 1,
				value: ""
			});
			continue;
		}
		if (/^Return to the cave location from which you originally entered the dungeon[.]?$/i.test(t.trim())) {
			r.push({
				kind: "returnDungeon",
				amount: 1,
				value: ""
			});
			continue;
		}
		if (e.choices.length === 6 && e.choices.every((e) => e.roll) && /\broll (?:a|1) skill die\b/i.test(t) && !/\bif|unless|pay|gain|lose\b/i.test(t)) {
			r.push({
				kind: "skillResult",
				amount: e.gainSkillResult ? 2 : 1,
				value: ""
			});
			continue;
		}
		if (/^Variant: Quick Skirm/i.test(t.trim())) continue;
		if (/^Place card 798 on the table.*follow its instructions(?:, using card 15\d\d as the opponent[’']s card)?[.]?$/i.test(t.trim())) {
			r.push({
				kind: "skirm",
				amount: 1,
				value: t.match(/using card (\d+)/i)?.[1] ?? ""
			});
			continue;
		}
		if (/^Roll (\d+) skill dice (?:and (?:gain|keep) all|; gain all) (move|look|engage|help|take|overpower) results[.]?$/i.test(t.trim())) {
			let e = t.match(/Roll (\d+).* (move|look|engage|help|take|overpower) results/i);
			r.push({
				kind: "rollSkill",
				amount: Number(e[1]),
				value: e[2].toLowerCase()
			});
			continue;
		}
		if (/^Suffer (\d+) (?:heat|cold|hypoxia) damage[.]?$/i.test(t.trim())) {
			r.push({
				kind: "damage",
				amount: Number(t.match(/\d+/)[0]),
				value: t.match(/heat|cold|hypoxia/i)[0].toLowerCase()
			});
			continue;
		}
		if (/^Gain 1 random card from the Skirm spoiler pack/i.test(t.trim()) && !/\bif|unless\b/i.test(t)) {
			r.push({
				kind: "skirmCard",
				amount: 1,
				value: ""
			});
			continue;
		}
		if (/^The game ends, and you achieve an epic victory if you also completed the mission[.]?$/i.test(t.trim()) || /\b(?:The game ends|End the game)\b/.test(t) && !/\bif|unless|may|whether\b/i.test(t)) {
			r.push({
				kind: "end",
				amount: 1,
				value: /achieve an epic victory if you also completed the mission/i.test(t) ? "destiny" : ""
			});
			continue;
		}
		if (!(/^\s*(?:(?:then|and)\s+)?(?:gain|lose|pay|go|return to|replace|refresh|roll|place|read|choose|discard|transfer|set|end the game|perform|reduce|increase|remove|add|suffer|view|look at|consult|refer to|reveal|draw|shuffle|flip|spend|move|advance|proceed|climb|exit|rotate)\b/i.test(t) || /\b(?:Gain|Lose|Pay|Go|Return to|Replace|Refresh|Roll|Place|Read|Choose|Discard|Transfer|Set|End the game|Perform|Reduce|Increase|Remove|Add|Suffer|View|Look at|Consult|Refer to|Reveal|Draw|Shuffle|Flip|Spend|Move|Advance|Proceed|Climb|Exit|Rotate)\b/.test(t) || /\b(?:gain|lose|pay|go to|move to|advance to|proceed to|climb to|exit to|read|roll|view|look at|refer to|suffer|rotate)\s+(?:\d|\$|item|animal|quest|ability|spell|flora|destiny|mission|sentient|curse|card|location|entry|page|this|the)/i.test(t)) && !/\bchoose (?:one|an?|your|the)\b/i.test(t) || e.choices.length && /\bchoose(?: one| how| based| a direction| your destiny)?\b/i.test(t) && !/\b(?:gain|lose|pay|roll|go to|read)\s+(?:\d|\$)/i.test(t) || /^(?:choose one:?|you may continue[.!]?|continue[.!]?)$/i.test(t.trim())) continue;
		let a = e.choices.length ? t.replace(/\bchoose(?: one| how to proceed| based on previous actions| a direction for your leap)?\s*:?\s*$/i, "") : t;
		if (/\b(if|unless|per|each|for every|instead|may|either|or|random card|matching|chosen|choose)\b/i.test(a) || /continue with/i.test(a)) {
			i = !0;
			continue;
		}
		let o = a, s = [], c = (e, t) => {
			let n = [...o.matchAll(e)];
			for (let e of n) s.push({
				index: e.index,
				effect: t(e)
			});
			o = o.replace(e, (e) => " ".repeat(e.length));
		}, l = /\blose\b/i.test(a) && !/\bgain\b/i.test(a) ? -1 : 1;
		c(/\b(\d+) boost(?: on your character| on this (?:card|structure))?\b/gi, (e) => ({
			kind: "boost",
			amount: l * Number(e[1]),
			value: /on your character/i.test(e[0]) ? "character" : ""
		})), c(/\$(\d+)/g, (e) => ({
			kind: "coin",
			amount: l * Number(e[1]),
			value: ""
		})), c(/\b(\d+) (move|look|engage|help|take|overpower)\b/gi, (e) => ({
			kind: "skill",
			amount: l * Number(e[1]),
			value: e[2].toLowerCase()
		})), c(/\b(\d+) (time|morale|health)\b/gi, (e) => ({
			kind: "stat",
			amount: l * Number(e[1]),
			value: e[2].toLowerCase()
		})), c(/\b(\d+) random skill(?: tokens?)?s?\b/gi, (e) => ({
			kind: "randomSkill",
			amount: Number(e[1]),
			value: ""
		})), c(/\b(?:go|move|advance|proceed|climb|exit)\s+(?:(?:to|north|east|south|west|deeper|into|planet|location|interior|city|cave|dungeon|tower|vantage|landmark|forest|ruin|temple|building|village|settlement|the|a|an)\s+)*(\d{1,3})\b/gi, (e) => ({
			kind: /\bdungeon\b/i.test(e[0]) ? "dungeon" : "location",
			amount: 1,
			value: e[1]
		})), c(/\bRotate (?:(?:this|the) (?:quest|card|objective)|(?:quest|objective)(?: card)?\s+(\d{4})) and add it to your grid(?:,\s*replacing (?:objective|quest|card) (\d{4}))?/gi, (e) => ({
			kind: "completeCard",
			amount: Number(e[2] ?? 0),
			value: e[1] ?? "self"
		})), c(/\bRotate and add (?:quest|objective)(?: card)? (\d{4}) to your grid(?:,\s*replacing (?:objective|quest|card) (\d{4}))?/gi, (e) => ({
			kind: "completeCard",
			amount: Number(e[2] ?? 0),
			value: e[1]
		})), c(/\b(?:item|animal|loyal animal|sentient|elemental|ability|experience(?: card)?|spell|curse|blueprint|structure|vehicle|flora|lesson|destiny|mission|food|potion|emblem|artifact|card|puzzle|quest|objective)\s+(\d{3,4})\b/gi, (e) => ({
			kind: l < 0 ? "loseCard" : "card",
			amount: 1,
			value: e[1]
		})), c(/\bGain [^.()]+\((\d{3,4})\)/gi, (e) => ({
			kind: "card",
			amount: 1,
			value: e[1]
		})), c(/\bread (?:entry|the entry) (\d+) in (?:the )?Book of Secrets\b/gi, (e) => ({
			kind: "secret",
			amount: 1,
			value: e[1]
		})), c(/\brefresh all challenge dice\b/gi, () => ({
			kind: "refresh",
			amount: 1,
			value: ""
		})), c(/\b(?:view|look at|read|refer to) page (\d+) (?:in|of) (?:the )?Book of Vantages\b/gi, (e) => ({
			kind: "vantage",
			amount: 1,
			value: e[1]
		})), o = o.replace(/\b(?:gain|lose|and|then|you|on your character|on this card|on this structure|place it in the center|add it horizontally to your supply|keep this location for reference|continue)\b/gi, ""), (!s.length || /\b(?:pay|go|return|replace|refresh|roll|place|read|choose|discard|transfer|set|perform|reduce|increase|remove|add|suffer|view|look at|refer to|consult|reveal|draw|shuffle|flip|spend|move|advance|proceed|climb|exit|rotate|matching|adjacent|row|column|another|all|from|sell|buy|exchange)\b/i.test(o) || s.some((e) => e.effect.kind === "boost") && /\b(?:on|onto)\b/i.test(o)) && (i = !0), r.push(...s.sort((e, t) => e.index - t.index).map((e) => e.effect));
	}
	return e.testCoins && r.push({
		kind: "testCoins",
		amount: 1,
		value: ""
	}), e.sellCards && r.push({
		kind: "sellCards",
		amount: e.sellCards.max,
		value: [
			e.sellCards.min,
			e.sellCards.bonus,
			e.sellCards.itemsOnly ? "items" : "all"
		].join(":")
	}), e.sentientBoost && r.push({
		kind: "sentientBoost",
		amount: e.sentientBoost,
		value: ""
	}), e.regionalVantage && r.push({
		kind: "vantage",
		amount: 1,
		value: "region"
	}), e.departureLimit && r.push({
		kind: "departureLimit",
		amount: 0,
		value: ""
	}), {
		effects: i ? [] : r,
		blocked: i,
		continuation: a
	};
}
//#endregion
//#region src/games/vantage/story-payment.ts
function ae(e, t) {
	if (e === t || !/\bpay\b/i.test(e) || /\b(?:don[’']t|do not|cannot|can[’']t) pay\b/i.test(e)) return null;
	let n = /^(?:If you |You may )?Pay\s+(\$(\d+)|(\d+)\s+(boost|move|look|engage|help|take|overpower|time|morale|health))\b/i.exec(e);
	return !n || /\bor\b|\band\s+(?:\d|\$)/i.test(e) ? "unsupported" : {
		amount: Number(n[2] ?? n[3]),
		kind: n[2] ? "coin" : n[4].toLowerCase()
	};
}
function oe(e) {
	if (e.payment) return e.payment;
	let t = ae(e.label, e.node.text);
	return t === "unsupported" ? t : t ? [t] : [];
}
function se(e, t) {
	return t === "coin" ? e.coins : t === "boost" ? e.grid.find((t) => t?.card === e.character)?.boost ?? 0 : t in e.stats ? e.stats[t] : e.skills[t];
}
function ce(e, t, n = !1, r = 0, i = {}) {
	let a = oe(t);
	return a !== "unsupported" && a.every((t) => t.kind === "coin" && n || se(e, t.kind) + (C.includes(t.kind) ? i[t.kind] ?? 0 : 0) >= Math.max(0, t.amount - (t.kind === "coin" ? r : 0)));
}
//#endregion
//#region src/games/vantage/stored-skills.ts
function le(e) {
	return e ? [...e.faces, ...e.bonusFaces ?? []] : void 0;
}
function ue(e) {
	let t = e.skillRolls[0];
	if (t?.kind === "mini" && e.miniGame && [
		"hunt",
		"arena",
		"race",
		"tournament"
	].includes(e.miniGame.kind)) return {
		rid: t.rid,
		key: `${t.rid}:${t.group}:mini`,
		kind: "mini",
		match: void 0
	};
	if (t && [
		"gain",
		"match",
		"rune",
		"trial",
		"pearl",
		"skirm"
	].includes(t.kind)) return {
		rid: t.rid,
		key: `${t.rid}:${t.group}:${t.kind}`,
		kind: t.kind,
		match: t.match
	};
	if (t && t.kind !== "test") return null;
	let n = e.storyTest;
	if (!n || !n.rounds || e.phase !== "story" || !e.passage) return null;
	let r = k(e.passage.node).effects.findIndex((e) => e.kind === "skillTest");
	return r < 0 || e.passage.applied.some((e) => e > r) ? null : {
		rid: n.rid,
		key: `test:${n.rid}:${e.passage.entry}:${n.rounds}`,
		kind: "test",
		match: void 0
	};
}
function A(e, t, n) {
	let r = ue(e), i = t.grid.find((e) => e?.card === 997);
	if (n.card !== 997 || n.op !== "useStoredSkill" || !n.skill || !r || n.target && n.target !== r.rid || !i || i.boost < 1 || e.skillDiceChoice) return null;
	let a = r.kind === "test" ? e.storyTest.storedSkills : e.storedSkillUse?.key === r.key ? e.storedSkillUse.skills : void 0;
	if ((i.skills?.[n.skill] ?? 0) <= (a?.[n.skill] ?? 0)) return null;
	let o = e.players.find((e) => e.rid === r.rid), s = n.skill;
	return (t) => {
		if (t.spendBoost(e, i, 1), r.kind === "test") {
			let n = e.storyTest, r = n.storedSkills ??= {};
			r[s] = (r[s] ?? 0) + 1, (n.bonusFaces ??= []).push(s), !n.remaining && n.spec.repeatSkill && s === n.spec.repeatSkill && (t.gainSkill(o, s, 1), n.done = !1);
		} else {
			e.storedSkillUse?.key !== r.key && (e.storedSkillUse = {
				key: r.key,
				skills: {}
			});
			let n = e.storedSkillUse.skills;
			n[s] = (n[s] ?? 0) + 1, (r.kind === "gain" || ["match", "rune"].includes(r.kind) && r.match === s) && t.gainSkill(o, s, 1), r.kind === "rune" && (e.runeFaces ??= []).push(s), r.kind === "trial" && e.sentientTrial && (e.sentientTrial.faces.push(s), e.sentientTrial.success ||= s === "engage"), r.kind === "pearl" && e.pearlDefense && !e.pearlDefense.remaining.includes(s) && e.pearlDefense.remaining.push(s), r.kind === "skirm" && e.skirm && e.skirm.extras[0].push(s), r.kind === "mini" && e.miniGame && (e.miniGame.bonusSkills ??= []).push(s);
		}
	};
}
function j(e, t) {
	return C.map((e) => ({
		type: "printedPower",
		card: 997,
		op: "useStoredSkill",
		skill: e
	})).filter((n) => A(e, t, n) !== null);
}
//#endregion
//#region src/games/vantage/characters.ts
var de = [
	["look", "overpower"],
	["move", "engage"],
	["look", "help"],
	["engage", "take"],
	["help", "overpower"],
	["take", "move"]
];
function fe(e) {
	return (e - 1435) % 6;
}
function M(e) {
	return fe(e.character === 1453 ? e.previousCharacter ?? 1435 : e.character);
}
function pe(e) {
	return C[fe(e)];
}
function me(e) {
	return e >= 1435 && e <= 1440 ? "starting" : e >= 1441 && e <= 1446 ? "survivor" : e >= 1447 && e <= 1452 ? "armor" : "other";
}
function N(e, t) {
	return me(e) === "armor" ? t === "hypoxia" : me(e) === "survivor" && t === ([
		0,
		3,
		4
	].includes(fe(e)) ? "heat" : "cold");
}
//#endregion
//#region src/games/vantage/composition.ts
var he = {
	14: ["sinew"],
	16: ["metal"],
	17: ["sinew"],
	28: ["stone"],
	30: ["stone"],
	31: ["stone"],
	34: ["stone"],
	43: ["sand"],
	44: ["sand"],
	45: ["sand"],
	53: ["leaf"],
	55: ["gold"],
	56: ["water"],
	57: ["water"],
	63: ["water"],
	78: ["fire"],
	80: ["metal"],
	94: ["metal"],
	96: ["wind"],
	100: ["leaf"],
	101: ["wood"],
	103: ["leaf"],
	104: ["leaf"],
	105: ["wind"],
	109: ["leaf"],
	110: ["leaf"],
	112: ["leaf"],
	118: ["wind"],
	119: ["leaf"],
	124: ["metal"],
	125: ["fire"],
	128: ["water"],
	144: ["leaf"],
	145: ["energy"],
	146: ["energy"],
	150: ["fire"],
	158: ["sand"],
	159: ["fire"],
	160: ["fire"],
	161: ["fire"],
	162: ["fire"],
	163: ["fire"],
	167: ["fire"],
	168: ["fire"],
	172: ["leaf"],
	174: ["fire"],
	175: ["wind"],
	176: ["wind"],
	177: ["wind"],
	178: ["wind"],
	179: ["wind"],
	180: ["wind"],
	182: ["wind"],
	183: ["wind"],
	184: ["wind"],
	186: ["wind"],
	187: ["wind"],
	188: ["wind"],
	192: ["wind"],
	194: ["wind"],
	197: ["wind"],
	199: ["metal"],
	201: ["metal"],
	202: ["metal"],
	203: ["metal"],
	206: ["metal"],
	207: ["metal"],
	209: ["metal"],
	211: ["metal"],
	212: ["metal"],
	219: ["metal"],
	221: ["circuit"],
	222: ["sinew"],
	228: ["energy"],
	231: ["energy"],
	232: ["energy"],
	233: ["energy"],
	234: ["energy"],
	237: ["energy"],
	242: ["energy"],
	244: ["energy"],
	247: ["energy"],
	252: ["sinew"],
	255: ["sinew"],
	257: ["leaf"],
	258: ["sinew"],
	259: ["sinew"],
	261: ["sinew"],
	262: ["sinew"],
	265: ["sinew"],
	266: ["sinew"],
	267: ["wind"],
	268: ["sinew"],
	277: ["sand"],
	279: ["sand"],
	280: ["sand"],
	286: ["sand"],
	288: ["sand"],
	295: ["sand"],
	300: ["leaf"],
	301: ["energy"],
	308: ["water"],
	313: ["fire"],
	316: ["leaf"],
	317: ["leaf"],
	319: ["gold"],
	321: ["leaf"],
	322: ["wood"],
	323: ["leaf"],
	324: ["energy"],
	325: ["gold"],
	326: ["gold"],
	328: ["gold"],
	329: ["circuit"],
	332: ["gold"],
	333: ["gold"],
	334: ["gold"],
	336: ["gold"],
	337: ["gold"],
	338: ["gold"],
	339: ["gold"],
	341: ["gold"],
	342: ["gold"],
	345: ["wind"],
	352: ["wood"],
	357: ["fire"],
	358: ["fire"],
	359: ["fire"],
	369: ["wood"],
	373: ["leaf"],
	374: ["stone"],
	378: ["fire"],
	380: ["fire"],
	381: ["water"],
	383: ["wood"],
	393: ["metal"],
	406: ["sand"],
	417: ["fire"],
	420: ["sinew"],
	421: ["sinew"],
	426: ["leaf"],
	427: ["water"],
	431: ["leaf"],
	437: ["stone"],
	439: ["sand"],
	440: ["fire"],
	443: ["gold"],
	444: ["gold"],
	446: ["gold"],
	449: ["wood"],
	451: ["water"],
	461: ["energy"],
	462: ["circuit"],
	463: ["wind"],
	470: ["energy"],
	473: ["leaf"],
	475: ["metal"],
	479: ["water"],
	480: ["water"],
	483: ["metal"],
	489: ["sinew"],
	498: ["sinew"],
	505: ["gold"],
	510: ["leaf"],
	511: ["leaf"],
	517: ["fire"],
	522: ["metal"],
	568: ["gold"],
	596: ["wind"],
	603: ["circuit"],
	604: ["circuit"],
	605: ["sinew"],
	606: ["circuit"],
	607: ["circuit"],
	614: ["circuit"],
	616: ["circuit"],
	618: ["circuit"],
	619: ["circuit"],
	620: ["energy"],
	621: ["circuit"],
	622: ["circuit"],
	627: ["circuit"],
	629: ["circuit"],
	633: ["wind"],
	636: ["stone"],
	641: ["water"],
	642: ["water"],
	643: ["water"],
	645: ["water"],
	646: ["water"],
	647: ["water"],
	650: ["water"],
	651: ["water"],
	652: ["water"],
	657: ["water"],
	660: ["water"],
	667: ["wood"],
	668: ["wood"],
	673: ["wood"],
	676: ["leaf"],
	678: ["wood"],
	679: ["leaf"],
	680: ["wood"],
	683: ["leaf"],
	689: ["sinew"],
	692: ["leaf"],
	693: ["wood"],
	703: ["stone"],
	705: ["stone"],
	706: ["wind"],
	708: ["stone"],
	711: ["stone"],
	714: ["stone"],
	715: ["stone"],
	718: ["stone"],
	721: ["stone"],
	724: ["stone"],
	726: ["stone"],
	727: ["stone"],
	728: ["stone"],
	729: ["stone"],
	735: ["sand"],
	737: ["wood"],
	740: ["wood"],
	742: ["sand"],
	743: ["water"],
	744: ["wood"],
	747: ["sand"],
	748: ["sand"],
	750: ["water"],
	751: ["wood"],
	752: ["sand"],
	753: ["sand"],
	755: ["wood"],
	758: ["sand"],
	759: ["sand"],
	762: ["energy"],
	768: ["wood"],
	769: ["sinew"],
	772: ["water"],
	774: ["fire"],
	775: ["sinew"],
	777: ["metal"],
	782: ["leaf"],
	783: ["gold"],
	787: ["metal"],
	788: ["metal"],
	789: ["metal"],
	803: ["wind"],
	804: ["wind"],
	805: ["wind"],
	806: ["wind"],
	807: ["wind"],
	808: ["circuit"],
	809: ["circuit"],
	810: ["sinew"],
	811: ["sinew"],
	812: ["circuit"],
	813: ["fire"],
	814: ["fire"],
	815: ["fire"],
	816: ["fire"],
	817: ["gold"],
	818: ["gold"],
	819: ["gold"],
	820: ["circuit"],
	821: ["energy"],
	822: ["energy"],
	823: ["energy"],
	824: ["sinew"],
	825: ["sinew"],
	826: ["sinew"],
	827: ["sinew"],
	828: ["metal"],
	829: ["metal"],
	830: ["metal"],
	831: ["metal"],
	832: ["sand"],
	833: ["sand"],
	834: ["sand"],
	835: ["sand"],
	836: ["sand"],
	837: ["stone"],
	838: ["stone"],
	839: ["stone"],
	840: ["wind"],
	841: ["leaf"],
	842: ["leaf"],
	843: ["leaf"],
	844: ["leaf"],
	845: ["leaf"],
	846: ["wood"],
	847: ["water"],
	848: ["water"],
	849: ["water"],
	850: ["water"],
	851: ["leaf"],
	852: ["leaf"],
	853: ["wood"],
	854: ["wood"],
	855: ["leaf"],
	977: ["wind"],
	978: ["fire"],
	979: ["stone"],
	997: ["wood"],
	998: ["fire"],
	999: ["gold"],
	1e3: ["stone"],
	1002: ["circuit"],
	1003: ["wind"],
	1004: ["sand"],
	1005: ["water"],
	1006: ["metal"],
	1007: ["sinew"],
	1008: ["leaf"],
	1013: ["water"],
	1046: ["leaf"],
	1047: ["leaf"],
	1048: ["leaf"],
	1049: ["leaf"],
	1050: ["leaf"],
	1051: ["leaf"],
	1052: ["leaf"],
	1053: ["leaf"],
	1054: ["leaf"],
	1055: ["leaf"],
	1056: ["leaf"],
	1057: ["leaf"],
	1058: ["leaf"],
	1059: ["leaf"],
	1060: ["leaf"],
	1061: ["leaf"],
	1062: ["leaf"],
	1063: ["leaf"],
	1064: ["leaf"],
	1065: ["leaf"],
	1066: ["leaf"],
	1067: ["leaf"],
	1068: ["leaf"],
	1069: ["leaf"],
	1070: ["leaf"],
	1071: ["leaf"],
	1072: ["leaf"],
	1073: ["leaf"],
	1074: ["leaf"],
	1075: ["leaf"],
	1076: ["leaf"],
	1077: ["leaf"],
	1078: ["leaf"],
	1079: ["leaf"],
	1080: ["leaf"],
	1081: ["leaf"],
	1082: ["leaf"],
	1107: ["leaf"],
	1108: ["wind"],
	1109: ["wind"],
	1110: ["wind"],
	1111: ["circuit"],
	1112: ["fire"],
	1113: ["fire"],
	1114: ["gold"],
	1115: ["circuit"],
	1116: ["energy"],
	1117: ["energy"],
	1118: ["energy"],
	1119: ["sinew"],
	1120: ["sinew"],
	1121: ["sinew"],
	1122: ["sinew"],
	1123: ["metal"],
	1124: ["metal"],
	1125: ["sand"],
	1126: ["stone"],
	1127: ["wind"],
	1129: ["wood"],
	1130: ["water"],
	1131: ["water"],
	1132: ["wood"],
	1133: ["wood"],
	1134: ["leaf"],
	1136: ["leaf"],
	1141: ["circuit"],
	1155: ["sinew"],
	1159: ["leaf"],
	1213: ["wind"],
	1218: ["sinew"],
	1219: ["sinew"],
	1220: ["sinew"],
	1221: ["leaf"],
	1222: ["leaf"],
	1239: ["wind"],
	1240: ["circuit"],
	1241: ["fire"],
	1242: ["gold"],
	1243: ["energy"],
	1244: ["sinew"],
	1245: ["metal"],
	1246: ["sand"],
	1247: ["stone"],
	1248: ["leaf"],
	1249: ["water"],
	1250: ["wood"],
	1305: ["wind"],
	1306: ["wind"],
	1307: ["wind"],
	1308: ["wind"],
	1309: ["wind"],
	1310: ["circuit"],
	1311: ["circuit"],
	1312: ["circuit"],
	1313: ["circuit"],
	1314: ["circuit"],
	1315: ["fire"],
	1316: ["fire"],
	1317: ["fire"],
	1318: ["fire"],
	1319: ["fire"],
	1320: ["gold"],
	1321: ["gold"],
	1322: ["gold"],
	1323: ["gold"],
	1324: ["gold"],
	1325: ["energy"],
	1326: ["energy"],
	1327: ["energy"],
	1328: ["energy"],
	1329: ["energy"],
	1330: ["sinew"],
	1331: ["sinew"],
	1332: ["sinew"],
	1333: ["sinew"],
	1334: ["sinew"],
	1335: ["metal"],
	1336: ["metal"],
	1337: ["metal"],
	1338: ["metal"],
	1339: ["metal"],
	1340: ["sand"],
	1341: ["sand"],
	1342: ["sand"],
	1343: ["sand"],
	1344: ["sand"],
	1345: ["stone"],
	1346: ["stone"],
	1347: ["stone"],
	1348: ["stone"],
	1349: ["stone"],
	1350: ["leaf"],
	1351: ["leaf"],
	1352: ["leaf"],
	1353: ["leaf"],
	1354: ["leaf"],
	1355: ["water"],
	1356: ["water"],
	1357: ["water"],
	1358: ["water"],
	1359: ["water"],
	1360: ["wood"],
	1361: ["wood"],
	1362: ["wood"],
	1363: ["wood"],
	1364: ["wood"],
	1397: ["wind"],
	1398: ["leaf"],
	1399: ["circuit"],
	1400: ["fire"],
	1401: ["gold"],
	1402: ["energy"],
	1403: ["sinew"],
	1404: ["sand"],
	1405: ["stone"],
	1406: ["water"],
	1407: ["wood"],
	1408: ["metal"],
	1453: ["sand"],
	1529: ["wind"],
	1530: ["wind"],
	1531: ["wind"],
	1532: ["wind"],
	1533: ["leaf"],
	1534: ["leaf"],
	1535: ["leaf"],
	1536: ["leaf"],
	1537: ["circuit"],
	1538: ["circuit"],
	1539: ["circuit"],
	1540: ["circuit"],
	1541: ["fire"],
	1542: ["fire"],
	1543: ["fire"],
	1544: ["fire"],
	1545: ["gold"],
	1546: ["gold"],
	1547: ["gold"],
	1548: ["gold"],
	1549: ["energy"],
	1550: ["energy"],
	1551: ["energy"],
	1552: ["energy"],
	1553: ["sinew"],
	1554: ["sinew"],
	1555: ["sinew"],
	1556: ["sinew"],
	1557: ["sand"],
	1558: ["sand"],
	1559: ["sand"],
	1560: ["sand"],
	1561: ["stone"],
	1562: ["stone"],
	1563: ["stone"],
	1564: ["stone"],
	1565: ["water"],
	1566: ["water"],
	1567: ["water"],
	1568: ["water"],
	1569: ["wood"],
	1570: ["wood"],
	1571: ["wood"],
	1572: ["wood"],
	1573: ["metal"],
	1574: ["metal"],
	1575: ["metal"],
	1576: ["metal"]
}, ge = [
	"water",
	"wood",
	"wind",
	"leaf",
	"stone",
	"sand",
	"metal",
	"sinew",
	"gold",
	"fire",
	"energy",
	"circuit"
];
function _e(e, t) {
	let n = he[String(e)] ?? [], r = t?.grid.find((t) => t?.card === e), i = t?.grid.find((e) => e?.card === 1707);
	if (!r) return n;
	let a = [...r.affinities ?? [], ...i?.affinities ?? (i?.affinity ? [i.affinity] : [])];
	return n.map((t, n) => a.find((t) => t.card === e && t.index === n)?.element ?? t);
}
var ve = /* @__PURE__ */ new Set(/* @__PURE__ */ "d45:0.d109:0.d159:0.d194:0.d252:1.d257:1.d258:0.d265:0.d268:0.d277:0.d286:0.d295:0.d301:0.d328:0.d357:1.d374:1.d426:1.d449:0.d451:0.d505:0.d605:0.d622:0.d646:0.d650:0.d651:0.d652:0.d703:0.d708:1.d714:0.d726:0.d728:0.d742:0.d750:1.d753:0.d753:1.d775:0.d783:0.d783:1.d43:1.d44:0.d80:0.d96:0.d101:0.d128:1.d168:0.d175:0.d178:0.d179:0.d180:0.d182:0.d197:0.d199:0.d199:1.d202:1.d209:1.d211:0.d212:0.d219:2.d221:0.d242:0.d247:0.d247:1.d267:0.d300:0.d313:0.d319:0.d323:1.d339:0.d358:0.d369:0.d373:0.d393:1.d417:0.d427:1.d427:2.d431:0.d440:0.d443:0.d446:0.d463:0.d498:0.d616:0.d619:0.d621:1.d627:2.d629:0.d633:0.d642:0.d645:0.d657:1.d667:0.d679:0.d692:0.d729:0.d751:1.d752:0.d758:0.d759:1.d774:0.d777:0.d782:0.d789:1".split("."));
function ye(e) {
	let t = D[e];
	if (!t) return !1;
	let n = E[t.card]?.group;
	return n !== "location" && !["animal", "sentient"].includes(n) && !(t.card >= 1529 && t.card <= 1576) ? !1 : t.book !== "depart" || ve.has(e);
}
var be = [
	{
		element: "water",
		instruction: {
			kind: "stat",
			value: "boost"
		}
	},
	{
		element: "wood",
		instruction: {
			kind: "skill",
			value: ""
		}
	},
	{
		element: "wind",
		instruction: {
			kind: "damage",
			value: "hypoxia"
		}
	},
	{
		element: "leaf",
		instruction: {
			kind: "rollCenter",
			value: ""
		}
	},
	{
		element: "stone",
		instruction: {
			kind: "rollPool",
			value: ""
		}
	},
	{
		element: "sand",
		instruction: {
			kind: "stat",
			value: "time"
		}
	},
	{
		element: "metal",
		instruction: {
			kind: "reserve",
			value: ""
		}
	},
	{
		element: "sinew",
		instruction: {
			kind: "stat",
			value: "health"
		}
	},
	{
		element: "gold",
		instruction: {
			kind: "stat",
			value: "coin"
		}
	},
	{
		element: "fire",
		instruction: {
			kind: "damage",
			value: "heat"
		}
	},
	{
		element: "energy",
		instruction: {
			kind: "stat",
			value: "morale"
		}
	},
	{
		element: "circuit",
		instruction: {
			kind: "damage",
			value: "cold"
		}
	}
];
function xe(e) {
	return be[e - 1385]?.element;
}
function Se(e, t, n, r) {
	if (!n) return [];
	let i = _e(e, r);
	return be.flatMap((e, n) => t.includes(1385 + n) && i.includes(e.element) ? [{
		card: 1385 + n,
		instruction: e.instruction
	}] : []);
}
//#endregion
//#region src/games/vantage/card-triggers.ts
var Ce = {
	803: 1108,
	804: 805,
	806: 1109,
	807: 1110,
	808: 809,
	810: 811,
	812: 1111,
	813: 1112,
	814: 815,
	816: 1113,
	817: 818,
	819: 1114,
	820: 1115,
	821: 1116,
	822: 1117,
	823: 1118,
	824: 1119,
	825: 1120,
	826: 1121,
	827: 1122,
	828: 1123,
	829: 830,
	831: 1124,
	832: 833,
	834: 835,
	836: 1125,
	837: 1126,
	838: 839,
	840: 1127,
	841: 842,
	843: 844,
	845: 1107,
	846: 1129,
	847: 1130,
	848: 849,
	850: 1131,
	851: 852,
	853: 1132,
	854: 1133,
	855: 1134,
	1221: 1222
}, we = new Set(Object.values(Ce));
function Te(e, t) {
	return !t || (t.grid ? e.grid : [
		...e.grid,
		...e.reserve,
		...e.supply
	]).some((e) => e && e.boost >= (t.boost ?? 0) && t.any.some((t) => P(e.card, t))) === t.present;
}
function Ee(e) {
	return [
		e - 3,
		e + 3,
		e % 3 > 0 ? e - 1 : -1,
		e % 3 < 2 ? e + 1 : 9
	].filter((e) => e >= 0 && e < 9);
}
var De = [
	1037,
	1154,
	1251,
	1252,
	1254,
	1255,
	1256,
	1257,
	1258,
	1259,
	1260,
	1261,
	1262,
	1263,
	1264
], Oe = [
	1043,
	1044,
	1045,
	1191,
	1192,
	1193,
	1214,
	1215,
	1223
], ke = {
	977: 807,
	978: {
		move: 813,
		look: 813,
		engage: 814,
		help: 814,
		take: 816,
		overpower: 816
	},
	979: {
		move: 837,
		look: 837,
		engage: 837,
		help: 838,
		take: 838,
		overpower: 838
	},
	1155: {
		move: 810,
		look: 810,
		engage: 824,
		help: 824,
		take: 825,
		overpower: 825
	},
	1213: {
		move: 803,
		look: 816,
		engage: 820,
		help: 820,
		take: 826,
		overpower: 826
	}
}, Ae = {
	997: "wood",
	998: "fire",
	999: "gold",
	1e3: "circuit",
	1001: "energy",
	1003: "wind",
	1004: "sand",
	1005: "water",
	1006: "metal",
	1007: "sinew",
	1008: "leaf",
	1141: "stone"
}, je = {
	1239: "wind",
	1240: "circuit",
	1241: "fire",
	1242: "gold",
	1243: "energy",
	1244: "sinew",
	1245: "metal",
	1246: "sand",
	1247: "stone",
	1248: "leaf",
	1249: "water",
	1250: "wood"
}, Me = {
	1397: {
		stat: "morale",
		skill: "move"
	},
	1398: {
		stat: "health",
		skill: "help"
	},
	1399: {
		stat: "time",
		skill: "help"
	},
	1400: {
		stat: "health",
		skill: "take"
	},
	1401: {
		stat: "morale",
		skill: "engage"
	},
	1402: {
		stat: "morale",
		skill: "look"
	},
	1403: {
		stat: "morale",
		skill: "overpower"
	},
	1404: {
		stat: "time",
		skill: "move"
	},
	1405: {
		stat: "health",
		skill: "engage"
	},
	1406: {
		stat: "health",
		skill: "overpower"
	},
	1407: {
		stat: "time",
		skill: "look"
	},
	1408: {
		stat: "time",
		skill: "take"
	}
}, Ne = /* @__PURE__ */ new Set([
	856,
	859,
	861,
	862,
	863,
	864,
	865,
	866,
	868,
	869,
	1013,
	1136,
	1158,
	1178,
	1207,
	1208,
	1217,
	1224,
	1226
]);
function Pe(e) {
	return Ne.has(e) || e >= 1305 && e <= 1364 || !!Me[e];
}
function Fe(e) {
	return e >= 1236 && e <= 1238 || e >= 1365 && e <= 1384;
}
function P(e, t) {
	let n = E[e];
	return t.startsWith("composition:") ? _e(e).includes(t.slice(12)) : t === "sinew" ? _e(e).includes("sinew") : t === "valuableItem" ? n?.group === "item" && (n.value ?? 0) >= 10 : t === "experience" ? e >= 1454 && e <= 1459 : t === "wildAnimal" ? Ce[e] !== void 0 : t === "loyalAnimal" ? we.has(e) : t === "egg" ? [
		977,
		978,
		979,
		1155,
		1213
	].includes(e) : t === "torch" ? e >= 1084 && e <= 1087 : t === "ability" ? e >= 1460 && e <= 1516 : t === "map" ? De.includes(e) : n?.traits?.includes(t) || n?.group === t;
}
//#endregion
//#region src/games/vantage/coin-powers.ts
function Ie(e, t, n) {
	let r = t === e.players.find((t) => t.rid === (e.arrivalSecret ? e.arrivalReader : e.players[e.turn].rid));
	if (e.phase === "skirm" && e.skirm?.stage === "scored" && !e.skirm.rewarded && n === "gain") return t.rid === e.skirm.controllers[e.skirm.winner ?? 0] && (e.skirm.winner === 0 || !e.skirm.solo);
	if (n === "gain" && ![
		"launch",
		"landing",
		"experience",
		"done"
	].includes(e.phase) && ((t.grid[4]?.boost ?? 0) >= 2 && me(t.character) !== "armor" || e.phase === "story" && e.players.some((n) => n !== t && n.coins > 0 && e.personal[n.rid].location === e.personal[t.rid].location) || r && e.challenge && (e.phase === "cost" && M(t) === 5 && me(t.character) === "armor" && (t.grid[4]?.boost ?? 0) > 0 && e.challenge.cost >= 0 || [
		"cost",
		"dice",
		"story"
	].includes(e.phase) && e.challenge.interaction?.sentients.length && t.grid.some((e) => e?.card === 936 && e.boost >= 1) || e.phase === "cost" && !e.setFaces.length && t.grid.some((e) => e?.card === 1410 && e.boost >= 1) && t.grid.some((t) => t && P(t.card, "bow") && (e.challenge.skill === "overpower" || t.card === 960 && e.challenge.skill === "take"))))) return !0;
	if (!r) return !1;
	if (n === "pay" && e.phase === "story" && e.personal[t.rid].location === 570 && [
		...t.grid,
		...t.reserve,
		...t.supply
	].some((e) => e?.card === 1682) || n === "pay" && e.phase === "cost" && e.challenge && ie(D[e.challenge.id], e.challenge.cost, e.challenge.coinsPaid ?? 0, e.challenge.coinOfferUsed)) return !0;
	if (e.phase !== "story" || !e.passage) return !1;
	let i = k(e.passage.node, le(e.storyTest)).effects.find((t, n) => !e.passage.applied.includes(n));
	return n === "pay" ? !e.challenge?.waiveCoins && (!i && e.passage.node.choices.some((e) => {
		let t = oe(e);
		return t !== "unsupported" && t.some((e) => e.kind === "coin" && e.amount > 0);
	}) || i?.kind === "printedAbility" && i.value === "invest") : i ? i.kind === "coin" ? i.amount > 0 : i.kind === "miniCoins" ? !!e.miniGame?.done && e.miniGame.coins > 0 : i.kind === "coinX" ? (e.challenge?.chosenX ?? 0) > 0 : i.kind === "sourceCoin" ? e.players.some((t) => [
		...t.grid,
		...t.reserve,
		...t.supply
	].some((t) => t && t.card === e.challenge?.source && t.boost > 0)) : i.kind === "testCoins" ? !!e.storyTest?.done && le(e.storyTest).length > 0 : [
		"coinCount",
		"sellCards",
		"structureTrade"
	].includes(i.kind) ? !0 : i.kind === "barter" ? !!e.passage.node.barter?.sale : i.kind === "printedAbility" ? [
		"collectInvestment",
		"deliverBarrel",
		"deliverSoulstone",
		"feedVillagers"
	].includes(i.value) || i.value === "assembly" && !!e.copied?.assemblyEarned || i.value === "double" && !!e.copied?.benefits.some((e) => e.kind === "coin") : !1 : !1;
}
function Le(e, t, n) {
	return Ie(e, t, n) ? JSON.stringify([
		e.phase,
		e.challenge?.id,
		e.skirm?.winner,
		e.passage?.entry,
		e.passage?.node.text,
		e.passage?.applied
	]) : null;
}
function Re(e, t, n) {
	return Math.max(0, n - (e.coinPowers?.[t.rid]?.pay ?? 0));
}
function ze(e, t, n) {
	let r = Re(e, t, n);
	return e.coinPowers?.[t.rid] && delete e.coinPowers[t.rid].pay, t.coins -= r, r;
}
function Be(e, t, n) {
	n <= 0 || (t.coins += n + (e.coinPowers?.[t.rid]?.gain ?? 0), e.coinPowers?.[t.rid] && delete e.coinPowers[t.rid].gain);
}
//#endregion
//#region src/games/vantage/departure-destinations.ts
function Ve(e, t) {
	return D[e]?.book === "depart" ? He(e, t) : [];
}
function He(e, t) {
	let n = /* @__PURE__ */ new Set();
	function r(e) {
		for (let r of k(e).effects) {
			let e = r.kind === "returnDungeon" ? t : [
				"location",
				"dungeon",
				"dive"
			].includes(r.kind) ? Number(r.value) : null;
			e !== null && E[e]?.group === "location" && n.add(e);
		}
		e.choices.forEach((e) => r(e.node)), e.after && r(e.after);
	}
	return D[e] && r(D[e].node), [...n];
}
//#endregion
//#region src/games/vantage/skill-tokens.ts
function Ue(e, t) {
	let n = /* @__PURE__ */ new Set();
	function r(e) {
		return !e || n.has(e.card) ? 0 : (n.add(e.card), (e.skills?.[t] ?? 0) + (e.tucked ?? []).reduce((e, t) => e + r(t), 0));
	}
	let i = e.players.reduce((e, n) => e + n.skills[t] + [
		...n.grid,
		...n.reserve,
		...n.supply
	].reduce((e, t) => e + r(t), 0), 0);
	i += e.center.reduce((e, t) => e + r(t), 0);
	for (let t of Object.values(e.personal)) for (let e of t.storedBelongings ?? []) for (let { held: t } of e.cards) i += r(t);
	for (let t of Object.values(e.deliveries)) for (let e of t) i += r(e);
	for (let t of Object.values(e.pendingInstances)) i += r(t);
	return Math.max(0, 10 - i);
}
function F(e, t, n, r) {
	let i = t.skills[n];
	return t.skills[n] = Math.max(0, t.skills[n] + (r > 0 ? Math.min(r, Ue(e, n)) : r)), t.skills[n] - i;
}
function We(e, t, n) {
	let r = {};
	for (let i of n) r[i] = (r[i] ?? 0) + F(e, t, i, 1);
	return r;
}
function Ge(e, t) {
	for (let [n, r] of Object.entries(t ?? {})) e.skills[n] -= r;
}
//#endregion
//#region src/games/vantage/skill-dice-powers.ts
var Ke = /* @__PURE__ */ new Set([
	"repeatSkillGroup",
	"extraSkillGroup",
	"keepSkillGroup",
	"replaceSkillGroup",
	"dropExtraSkill",
	"useStoredSkill"
]);
function qe(e) {
	return Ke.has(e);
}
function Je(e) {
	return `${e.rid}:${e.group ?? -1}:${e.kind}`;
}
function Ye(e) {
	let t = e.skillRolls[0];
	if (!t) return [];
	let n = Je(t), r = e.skillRolls.findIndex((e) => Je(e) !== n);
	return e.skillRolls.slice(0, r < 0 ? void 0 : r);
}
function Xe(e, t, n) {
	if (n.op === "useStoredSkill") return A(e, t, n);
	let r = Ye(e), i = e.skillDiceChoice;
	if (!r.length || e.replenishments.length) return null;
	if (i) return i.rid === t.rid ? i.kind === "repeat" ? n.card !== 1381 || !["keepSkillGroup", "replaceSkillGroup"].includes(n.op) ? null : () => {
		n.op === "replaceSkillGroup" && r.forEach((e, t) => {
			e.face = i.faces[t];
		}), delete e.skillDiceChoice;
	} : n.card !== 1384 || n.op !== "dropExtraSkill" || n.die === void 0 || n.die >= i.faces.length ? null : () => {
		i.faces.splice(n.die, 1), --i.remaining === 0 && (r.forEach((e, t) => {
			e.face = i.faces[t];
		}), delete e.skillDiceChoice);
	} : null;
	if (e.skillGroupCommitted === Je(r[0])) return null;
	let a = n.op === "repeatSkillGroup" ? 1381 : n.op === "extraSkillGroup" ? 1384 : 0, o = t.grid.find((e) => e?.card === a);
	return n.card !== a || !o || o.boost < 2 ? null : (t) => {
		t.spendBoost(e, o, 2);
		let i = Array.from({ length: n.op === "repeatSkillGroup" ? r.length : 2 }, () => C[t.roll(e, 6)]);
		e.skillDiceChoice = {
			rid: r[0].rid,
			kind: n.op === "repeatSkillGroup" ? "repeat" : "extra",
			faces: n.op === "repeatSkillGroup" ? i : [...r.map((e) => e.face), ...i],
			remaining: 2
		};
	};
}
function Ze(e, t) {
	let n = e.skillDiceChoice, r = j(e, t);
	return n ? n.kind === "repeat" ? r.push({
		type: "printedPower",
		card: 1381,
		op: "keepSkillGroup",
		skillFaces: Ye(e).map((e) => e.face)
	}, {
		type: "printedPower",
		card: 1381,
		op: "replaceSkillGroup",
		skillFaces: n.faces
	}) : n.faces.forEach((e, t) => r.push({
		type: "printedPower",
		card: 1384,
		op: "dropExtraSkill",
		die: t,
		skill: e
	})) : r.push({
		type: "printedPower",
		card: 1381,
		op: "repeatSkillGroup"
	}, {
		type: "printedPower",
		card: 1384,
		op: "extraSkillGroup"
	}), r.filter((n) => Xe(e, t, n) !== null);
}
//#endregion
//#region src/games/vantage/trade-puzzle.ts
var Qe = "overpower", I = "take", $e = "help", et = "engage", tt = "move", nt = "look", rt = (e, t, n = !1) => ({
	give: e,
	take: t,
	emblem: n
}), it = [
	[
		[rt([Qe], [I, $e]), rt([et, I], [$e])],
		[rt([Qe], [
			I,
			I,
			et
		]), rt([
			I,
			I,
			I
		], [$e, Qe])],
		[rt([Qe], [
			I,
			I,
			I
		]), rt([Qe, et], [tt])],
		[rt([$e], [
			I,
			I,
			et
		]), rt([I, I], [tt])]
	],
	[
		[rt([et], [Qe, Qe]), rt([tt, $e], [I, I])],
		[rt([tt, Qe], [I, I]), rt([tt], [
			Qe,
			Qe,
			et
		])],
		[rt([Qe], [tt]), rt([I, I], [nt])],
		[rt([$e, et], [I, Qe]), rt([$e], [et, I])]
	],
	[
		[rt([Qe, nt], [I, I]), rt([et, nt], [
			tt,
			I,
			I
		])],
		[rt([
			nt,
			tt,
			tt
		], [], !0), rt([Qe], [nt])],
		[rt([I, nt], [tt, tt]), rt([
			$e,
			et,
			Qe
		], [tt, nt])],
		[rt([
			I,
			I,
			Qe
		], [$e, et]), rt([I, $e], [nt, Qe])],
		[rt([Qe], [et]), rt([I], [et, Qe])]
	]
];
function at(e, t) {
	return C.every((n, r) => e[r] >= t.give.filter((e) => e === n).length);
}
function ot(e, t) {
	return C.map((n, r) => e[r] - t.give.filter((e) => e === n).length + t.take.filter((e) => e === n).length);
}
//#endregion
//#region src/games/vantage/race-track.ts
var st = [
	4,
	4,
	4,
	2,
	2,
	1,
	1,
	2,
	2,
	1,
	2
], ct = [
	[210, 438],
	[310, 441],
	[423, 439],
	[548, 436],
	[253, 385],
	[330, 380],
	[407, 374],
	[499, 370],
	[258, 343],
	[320, 337],
	[369, 322],
	[430, 320],
	[228, 297],
	[293, 278],
	[185, 223],
	[246, 217],
	[178, 132],
	[265, 109],
	[371, 155],
	[374, 186],
	[461, 176],
	[469, 208],
	[565, 185],
	[642, 112],
	[679, 110]
], lt = [
	7,
	2,
	4,
	6,
	5,
	1
];
function ut(e) {
	let t = 0;
	for (let n = 0; n < st.length; n++) {
		let r = st[n];
		if (e < t + r) {
			if (n === st.length - 1) return [25];
			let i = e - t, a = st[n + 1], o = t + r;
			return r === 4 && a === 2 ? (i === 0 ? [0] : i === 3 ? [1] : [0, 1]).map((e) => o + e) : Array.from({ length: a }, (e, t) => t).filter((e) => r === 1 || a === 1 || Math.abs(e - i) <= 1).map((e) => o + e);
		}
		t += r;
	}
	return [];
}
function dt(e, t) {
	return ut(e[t]).filter((t) => t === 25 || !e.includes(t));
}
//#endregion
//#region src/games/vantage/advanced-mini-games.ts
var ft = (e, t) => Array.from({ length: e }, () => C[t(6)]), pt = (e, t) => {
	e.done = !0, e.success = t, e.stage = "done";
}, mt = (e, t) => e.filter((e) => e === t).length, ht = [
	3,
	8,
	2,
	7,
	5,
	6,
	4,
	1
], gt = [
	12,
	2,
	14,
	4,
	8,
	6,
	10,
	16
];
function _t(e) {
	return !e.carry.length && e.pots.every((t) => t.every((n) => e.dice[n] === e.dice[t[0]])) && C.every((t) => e.pots.filter((n) => n.some((n) => e.dice[n] === t)).length <= 1);
}
function vt(e, t, n) {
	return e.kind === "race" ? (e.racers = [...lt], e.dice = ft(6, n), e.stage = "round") : e.kind === "trade" ? e.tokens[5] = 1 : e.kind === "mancala" ? (e.dice = ft(12, n), e.pots = Array.from({ length: 6 }, (e, t) => [t * 2, t * 2 + 1]), e.remaining = 6 + e.variant) : e.kind === "tournament" ? (e.fighters = [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7
	], e.variant = t, e.stage = t ? "choose" : "bet", e.bets = Array(8).fill(0)) : e.kind === "arena" ? e.dice = ft(6, n) : e.kind === "pinch" ? (e.stage = "round", e.remaining = 6) : (e.stage = "bet", e.bets = [
		,
		,
		,
		,
		,
		,
	].fill(0)), {
		game: e,
		rolls: e.dice.map((e, t) => ({
			field: "dice",
			index: t
		}))
	};
}
function yt(e, t, n, r) {
	let i = [], a = (t) => {
		for (let r of t) e.dice[r] = C[n(6)], i.push({
			field: "dice",
			index: r
		});
	}, o = (t) => {
		e.dice = ft(t, n), i.push(...e.dice.map((e, t) => ({
			field: "dice",
			index: t
		})));
	};
	if (new Set(t.indices).size !== t.indices.length || t.indices.some((t) => t >= e.dice.length)) return null;
	if (e.kind === "race") {
		if (t.op === "keep" && e.stage === "round") e.tokens = C.map((t) => mt([...e.dice, ...e.bonusSkills ?? []], t)), e.stage = "choose", e.used = [], e.activeRacer = null;
		else if (t.op === "advance" && e.stage === "choose" && e.tokens.every((e) => e === 0)) e.round++, o(6), e.stage = "round";
		else if (t.op === "place" || t.op === "skip") {
			let n = t.racer;
			if (e.stage !== "choose" || n === void 0 || !e.tokens[n] || e.used.includes(n) || e.activeRacer !== null && e.activeRacer !== n && e.tokens[e.activeRacer] > 0 && dt(e.racers, e.activeRacer).length > 0) return null;
			let r = dt(e.racers, n);
			if (t.op === "skip") {
				if (r.length) return null;
				e.tokens[n] = 0, e.used.push(n), e.activeRacer = null;
			} else {
				if (t.cell === void 0 || !r.includes(t.cell)) return null;
				e.activeRacer !== null && e.activeRacer !== n && (e.tokens[e.activeRacer] = 0, e.used.push(e.activeRacer)), e.activeRacer = n, e.racers[n] = t.cell, e.tokens[n]--, t.cell === 25 ? pt(e, n === e.variant) : e.tokens[n] || (e.used.push(n), e.activeRacer = null);
			}
		} else return null;
	} else if (e.kind === "trade") {
		if (t.op === "trade") {
			let n = it[e.merchant][t.section ?? -1]?.[t.option ?? -1];
			if (!n || e.used.includes(t.section) || !at(e.tokens, n)) return null;
			e.tokens = ot(e.tokens, n), e.used.push(t.section), n.emblem && pt(e, !0);
		} else if (t.op === "advance") e.merchant === 2 ? pt(e, !1) : (e.merchant++, e.used = []);
		else if (t.op === "stop") pt(e, !1);
		else return null;
	} else if (e.kind === "mancala") {
		if (t.op === "pick") {
			if (e.carry.length || e.remaining < 1 || t.section === void 0 || !e.pots[t.section]?.length) return null;
			e.remaining--, e.carry = e.pots[t.section], e.pots[t.section] = [], e.pot = (t.section + 1) % 6;
		} else if (t.op === "skip") {
			let t = e.pots[e.pot];
			if (!e.carry.length || !t.length || !t.every((n) => e.dice[n] === e.dice[t[0]])) return null;
			e.pot = (e.pot + 1) % 6;
		} else if (t.op === "drop") {
			if (t.die === void 0 || !e.carry.includes(t.die)) return null;
			e.pots[e.pot].push(t.die), e.carry = e.carry.filter((e) => e !== t.die), e.pot = (e.pot + 1) % 6, !e.carry.length && (_t(e) || !e.remaining) && pt(e, _t(e));
		} else if (t.op === "keep" && _t(e)) pt(e, !0);
		else return null;
	} else if (e.kind === "tournament") {
		if (t.op === "bet") {
			if (e.stage !== "bet" || !t.bets || t.bets.length !== 8 || t.bets.some((e) => e > 3) || t.bets.reduce((e, t) => e + t, 0) > r) return null;
			e.bets = t.bets, e.stage = "choose";
		} else if (t.op === "advance" && e.stage === "choose") {
			let t = e.fighters[e.match * 2], r = e.fighters[e.match * 2 + 1], a = (t) => t === 7 && e.variant ? e.variant : ht[t], o = ft(a(t), n), s = ft(a(r), n);
			e.dice = e.variant && r === 7 ? s : o, e.enemy = e.variant && r === 7 ? o : s, e.stage = "round", e.variant && (t === 7 || r === 7) && i.push(...e.dice.map((e, t) => ({
				field: "dice",
				index: t
			})));
		} else if (t.op === "keep" && e.stage === "round") {
			let t = e.fighters[e.match * 2], n = e.fighters[e.match * 2 + 1], r = (t) => t === 7 && e.variant ? e.variant : ht[t], a = e.variant && n === 7 ? e.enemy : e.dice, o = e.variant && n === 7 ? e.dice : e.enemy, s = mt(e.bonusSkills ?? [], "overpower"), c = mt(a, "overpower") + (e.variant && t === 7 ? s : 0), l = mt(o, "overpower") + (e.variant && n === 7 ? s : 0);
			if (c === l && r(t) === r(n)) return e.stage = "choose", { rolls: i };
			let u = c > l || c === l && r(t) < r(n) ? t : n;
			if (e.results.push({
				a: t,
				b: n,
				winner: u,
				left: [...a],
				right: [...o]
			}), e.nextFighters.push(u), e.variant && u === 7 && e.wins++, !e.variant && e.round === 1) {
				e.coins += e.bets[u];
				let r = u === t ? n : t;
				e.coins -= e.bets[r], e.bets[r] = 0;
			}
			if (e.variant && (t === 7 || n === 7) && u !== 7) pt(e, !1);
			else if (e.nextFighters.length === e.fighters.length / 2) {
				if (e.fighters = e.nextFighters, e.nextFighters = [], e.match = 0, e.fighters.length === 1) {
					let t = e.fighters[0];
					e.variant || (e.coins += e.bets[t] * gt[t], e.bets.forEach((n, r) => {
						r !== t && (e.coins -= n);
					})), pt(e, t === 7);
				} else e.round++, e.stage = "choose";
			} else e.match++, e.stage = "choose";
		} else return null;
	} else if (e.kind === "arena") {
		if (t.op === "reroll") {
			if (t.indices.length < 1 || t.indices.length > 2 || !t.indices.some((t) => e.dice[t] === "move" && !e.used.includes(t))) return null;
			e.used.push(...t.indices.filter((t) => e.dice[t] === "move")), a(t.indices);
		} else if (t.op === "advance" && e.stage === "choose") {
			let t = [...e.dice, ...e.bonusSkills ?? []], n = Math.max(0, mt(t, "take") - mt(t, "engage") - mt(t, "help"));
			e.damage += n, mt(t, "look") && mt(t, "overpower") ? (e.wins++, e.round === 3 ? pt(e, !0) : e.stage = "round") : pt(e, !1);
		} else if (t.op === "keep" && e.stage === "round") e.round++, e.used = [], e.stage = "choose", o(6);
		else return null;
	} else if (e.kind === "perfecto" || e.kind === "press") {
		if (e.stage === "bet") {
			if (t.op !== "bet" || t.amount === void 0 || t.amount < 1 || t.amount > (e.kind === "perfecto" ? 6 : 5) || t.amount > r) return null;
			e.wager = t.amount, e.stage = "choose", e.remaining = e.kind === "perfecto" ? e.variant ? 6 : 5 : 0, o(e.kind === "perfecto" ? 6 : 1);
		} else if (e.kind === "perfecto") {
			if (t.op === "reroll" && e.remaining > 0 && t.indices.length) e.remaining--, a(t.indices);
			else if (t.op === "keep") {
				let t = new Set(e.dice).size === 1;
				e.coins = t ? e.wager * 2 : -e.wager, pt(e, t);
			} else return null;
		} else if (t.op === "advance" && e.stage === "choose") {
			let t = C[n(6)], r = e.dice.includes(t);
			e.dice.push(t), i.push({
				field: "dice",
				index: e.dice.length - 1
			}), r && (e.stage = "round");
		} else if (t.op === "keep") {
			let t = e.dice.length - +(e.stage === "round"), r = [];
			for (let e = 0; e < 7; e++) {
				let e = C[n(6)];
				if (r.includes(e)) break;
				r.push(e);
			}
			e.enemy = r, e.finalCounts = [t, r.length], e.coins = t >= r.length ? e.wager * 2 : -e.wager, pt(e, t >= r.length);
		} else return null;
	} else if (e.kind === "pinch") {
		if (t.op === "advance" && e.remaining > 0) {
			if (e.stage !== "round" && !e.dice.includes("engage")) return null;
			o(e.remaining), e.remaining--, e.stage = "choose";
		} else if (t.op === "keep" && e.stage === "choose") e.dice.includes("engage") ? (e.coins += 2, e.remaining ? e.stage = "round" : pt(e, !0)) : (e.coins = Math.max(0, e.coins - 2), pt(e, !1));
		else if (t.op === "stop" && e.stage === "round" && e.remaining < 6) pt(e, !0);
		else return null;
	} else if (e.kind === "punch") {
		if (t.op === "bet" && e.stage === "bet") {
			let n = t.bets?.reduce((e, t) => e + t, 0) ?? 0;
			if (!t.bets || t.bets.length !== 6 || t.bets.some((e) => e > 3) || n < 1 || n > r) return null;
			e.bets = t.bets, o(2), e.stage = "choose";
		} else if (t.op === "keep" && e.stage === "choose") e.coins = e.dice.reduce((t, n) => t + 2 * e.bets[C.indexOf(n)], 0) - e.bets.reduce((e, t) => e + t, 0), pt(e, e.coins >= 0);
		else return null;
	} else return null;
	return { rolls: i };
}
//#endregion
//#region src/games/vantage/mini-games.ts
var bt = e.enum(C), xt = e.object({
	kind: e.enum([
		"poker",
		"hunt",
		"slide",
		"dance",
		"trade",
		"mancala",
		"tournament",
		"arena",
		"perfecto",
		"pinch",
		"press",
		"punch",
		"race"
	]),
	stage: e.enum([
		"bet",
		"choose",
		"round",
		"done"
	]),
	dice: e.array(bt).max(30),
	enemy: e.array(bt).max(30),
	shared: e.array(bt).max(3),
	bonusSkills: e.array(bt).optional(),
	board: e.array(e.object({
		x: e.int().min(-12).max(12),
		y: e.int().min(-12).max(12),
		face: bt
	})).max(12),
	round: e.int().nonnegative(),
	remaining: e.int().nonnegative(),
	rerolled: e.boolean(),
	done: e.boolean(),
	success: e.boolean(),
	coins: e.int(),
	finalCounts: e.tuple([e.int().nonnegative(), e.int().nonnegative()]),
	tokens: e.array(e.int().nonnegative()).length(6).default([
		0,
		0,
		0,
		0,
		0,
		0
	]),
	merchant: e.int().min(0).max(2).default(0),
	used: e.array(e.int().nonnegative()).default([]),
	pots: e.array(e.array(e.int().min(0).max(29))).max(6).default([]),
	carry: e.array(e.int().min(0).max(29)).max(30).default([]),
	pot: e.int().min(0).max(5).default(0),
	bets: e.array(e.int().min(0).max(6)).max(8).default([]),
	wager: e.int().min(0).max(6).default(0),
	variant: e.int().nonnegative().default(0),
	wins: e.int().nonnegative().default(0),
	fighters: e.array(e.int().min(0).max(7)).max(8).default([]),
	results: e.array(e.object({
		a: e.int(),
		b: e.int(),
		winner: e.int(),
		left: e.array(bt),
		right: e.array(bt)
	})).max(7).default([]),
	nextFighters: e.array(e.int().min(0).max(7)).max(4).default([]),
	match: e.int().min(0).max(3).default(0),
	damage: e.int().nonnegative().default(0),
	paidDamage: e.int().nonnegative().default(0),
	racers: e.array(e.int().min(0).max(25)).max(6).default([]),
	activeRacer: e.int().min(0).max(5).nullable().default(null)
}), St = e.object({
	type: e.literal("miniGame"),
	op: e.enum([
		"keep",
		"reroll",
		"advance",
		"push",
		"place",
		"stop",
		"trade",
		"pick",
		"drop",
		"skip",
		"bet"
	]),
	indices: e.array(e.int().min(0).max(29)).max(30).default([]),
	line: e.int().min(0).max(2).optional(),
	direction: e.enum([
		"N",
		"E",
		"S",
		"W"
	]).optional(),
	die: e.int().min(0).max(29).optional(),
	x: e.int().min(-12).max(12).optional(),
	y: e.int().min(-12).max(12).optional(),
	amount: e.int().min(0).max(6).optional(),
	bets: e.array(e.int().min(0).max(6)).max(8).optional(),
	section: e.int().min(0).max(5).optional(),
	option: e.int().min(0).max(1).optional(),
	racer: e.int().min(0).max(5).optional(),
	cell: e.int().min(0).max(25).optional()
});
function Ct(e, t) {
	return Array.from({ length: e }, () => C[t(6)]);
}
function wt(e) {
	let t = C.map((t) => e.filter((e) => e === t).length).sort((e, t) => t - e);
	return t[0] === 5 ? 6 : t[0] === 4 ? 5 : t[0] === 3 && t[1] === 2 ? 4 : t[0] === 3 ? 3 : t[0] === 2 && t[1] === 2 ? 2 : +(t[0] === 2);
}
function Tt(e) {
	return e.length === 10 && ([
		0,
		1,
		2
	].every((t) => e[t * 3] === e[t * 3 + 1] && e[t * 3] === e[t * 3 + 2]) || [
		0,
		1,
		2
	].every((t) => e[t] === e[t + 3] && e[t] === e[t + 6]));
}
function Et(e) {
	let t = e.board.at(-1);
	return (t ? [
		{
			x: t.x + 1,
			y: t.y
		},
		{
			x: t.x - 1,
			y: t.y
		},
		{
			x: t.x,
			y: t.y + 1
		},
		{
			x: t.x,
			y: t.y - 1
		}
	] : [{
		x: 0,
		y: 0
	}]).flatMap((t) => e.dice.flatMap((n, r) => e.board.some((e) => e.x === t.x && e.y === t.y || e.face === n && (e.x === t.x || e.y === t.y)) ? [] : [{
		...t,
		die: r
	}]));
}
function Dt(e, t, n, r = 0) {
	let i = xt.parse({
		kind: e,
		stage: "choose",
		dice: [],
		enemy: [],
		shared: [],
		board: [],
		round: 1,
		remaining: e === "slide" ? 6 : 0,
		rerolled: !1,
		done: !1,
		success: !1,
		coins: 0,
		finalCounts: [0, 0],
		variant: r
	}), a = [];
	return [
		"poker",
		"hunt",
		"slide",
		"dance"
	].includes(e) ? (e === "poker" ? (i.dice = Ct(2, n), i.shared = Ct(1, n), a.push({
		field: "shared",
		index: 0
	})) : e === "hunt" ? (i.dice = Ct(t + 1, n), i.enemy = Ct(6, n)) : e === "slide" ? (i.dice = Ct(10, n), i.rerolled = !0) : i.dice = Ct(2, n), a.push(...i.dice.map((e, t) => ({
		field: "dice",
		index: t
	}))), {
		game: i,
		rolls: a
	}) : vt(i, t, n);
}
function Ot(e, t) {
	e.done = !0, e.success = t, e.stage = "done";
}
function kt(e, t, n, r = 0) {
	if (e.done) return null;
	if (![
		"poker",
		"hunt",
		"slide",
		"dance"
	].includes(e.kind)) return yt(e, t, n, r);
	let i = [], a = (t) => {
		for (let r of t) e.dice[r] = C[n(6)], i.push({
			field: "dice",
			index: r
		});
	};
	if (new Set(t.indices).size !== t.indices.length || t.indices.some((t) => t >= e.dice.length)) return null;
	if (e.kind === "poker") {
		if (t.op === "reroll") {
			if (e.rerolled || !t.indices.length) return null;
			a(t.indices), e.rerolled = !0;
		} else if (t.op === "advance") e.round === 3 ? (e.enemy = Ct(4, n), Ot(e, wt([...e.dice, ...e.shared]) >= Math.max(wt([...e.enemy.slice(0, 2), ...e.shared]), wt([...e.enemy.slice(2), ...e.shared])))) : (e.shared.push(C[n(6)]), i.push({
			field: "shared",
			index: e.shared.length - 1
		}), e.round++, e.rerolled = !1);
		else return null;
	} else if (e.kind === "hunt") {
		if (t.op === "reroll") {
			if (e.rerolled || !t.indices.length) return null;
			a(t.indices), e.rerolled = !0;
		} else if (t.op === "advance") {
			let t = [...e.dice, ...e.bonusSkills ?? []], r = (e, t, n = t) => C.reduce((r, i) => r + (e.filter((e) => e === i).length > t.filter((e) => e === i).length ? n.filter((e) => e === i).length : 0), 0), a = r(t, e.enemy), o = r(e.enemy, t, e.dice), s = e.dice.length + a - o, c = e.enemy.length + o - a;
			e.round === 3 ? (e.finalCounts = [s, c], Ot(e, s > c)) : (e.round++, e.rerolled = !1, e.dice = Ct(s, n), e.enemy = Ct(c, n), i.push(...e.dice.map((e, t) => ({
				field: "dice",
				index: t
			}))));
		} else return null;
	} else if (e.kind === "slide") {
		if (t.op === "push") {
			if (t.line === void 0 || !t.direction) return null;
			let n = t.direction === "E" || t.direction === "W", r = [
				0,
				1,
				2
			].map((e) => n ? t.line * 3 + e : e * 3 + t.line);
			(t.direction === "N" || t.direction === "W") && r.reverse();
			let i = e.dice[r[2]], a = e.dice[9];
			e.dice[r[2]] = e.dice[r[1]], e.dice[r[1]] = e.dice[r[0]], e.dice[r[0]] = a, e.dice[9] = i, e.rerolled = !1;
		} else if (t.op === "reroll") {
			if (e.remaining < 1 || e.rerolled) return null;
			e.remaining--, e.rerolled = !0, a([9]);
		} else if (t.op === "stop") {
			if (e.remaining > 0) return null;
			Ot(e, Tt(e.dice));
		} else if (t.op === "keep") {
			if (!Tt(e.dice)) return null;
			Ot(e, !0);
		} else return null;
	} else if (t.op === "reroll") {
		if (e.dice[0] !== e.dice[1] || !t.indices.length) return null;
		a(t.indices);
	} else if (t.op === "place") {
		if (!Et(e).some((e) => e.x === t.x && e.y === t.y && e.die === t.die)) return null;
		e.board.push({
			x: t.x,
			y: t.y,
			face: e.dice[t.die]
		}), e.coins++;
		let r = e.board[0], a = e.board.at(-1);
		e.board.length >= 6 && new Set(e.board.map((e) => e.face)).size === 6 && Math.abs(r.x - a.x) + Math.abs(r.y - a.y) === 1 ? Ot(e, !0) : e.board.length === 12 ? Ot(e, !1) : (e.dice = Ct(2, n), i.push(...e.dice.map((e, t) => ({
			field: "dice",
			index: t
		}))));
	} else if (t.op === "stop") {
		if (Et(e).length || e.dice[0] === e.dice[1]) return null;
		Ot(e, !1);
	} else return null;
	return { rolls: i };
}
//#endregion
//#region src/games/vantage/puzzles.ts
var At = e.object({
	type: e.literal("puzzleMove"),
	op: e.enum([
		"ready",
		"submit",
		"move",
		"point",
		"remove",
		"knot",
		"clear",
		"tunnel",
		"entrance"
	]),
	answer: e.string().max(2e3).optional(),
	direction: e.enum([
		"N",
		"E",
		"S",
		"W"
	]).optional(),
	point: e.tuple([e.number().min(0).max(1e3), e.number().min(0).max(1e3)]).optional(),
	knot: e.int().min(0).max(35).optional(),
	index: e.int().min(0).max(5).optional(),
	row: e.int().min(0).max(3).optional(),
	column: e.int().min(0).max(2).optional(),
	target: e.int().min(0).max(2).optional(),
	entrance: e.int().min(1).max(3).optional()
}), jt = e.object({
	id: e.int(),
	cards: e.array(e.int()),
	stage: e.enum([
		"study",
		"answer",
		"done"
	]),
	path: e.array(e.int()),
	point: e.tuple([e.number(), e.number()]).nullable(),
	points: e.array(e.tuple([e.number(), e.number()])).max(6).default([]),
	tunnels: e.array(e.array(e.int().min(0).max(2)).length(3)).length(4).default(() => [
		[
			0,
			1,
			2
		],
		[
			0,
			1,
			2
		],
		[
			0,
			1,
			2
		],
		[
			0,
			1,
			2
		]
	]),
	entrance: e.int().min(1).max(3).nullable().default(null),
	you: e.tuple([e.int(), e.int()]),
	knight: e.tuple([e.int(), e.int()]),
	knightResult: e.enum([
		"playing",
		"won",
		"lost"
	]),
	success: e.boolean().nullable()
}), Mt = {
	110: [1135],
	125: [532],
	128: [533],
	174: [1708],
	187: [1140],
	207: [538, 539],
	231: [
		1137,
		1138,
		1139
	],
	233: [
		1147,
		1148,
		1149
	],
	511: [511],
	537: [
		537,
		1142,
		1143,
		1144,
		1145
	],
	543: [800],
	586: [535],
	621: [1146],
	693: [536],
	721: [534],
	1002: [
		537,
		1142,
		1143,
		1144,
		1145
	]
};
function Nt(e) {
	return Mt[e] ? {
		id: e,
		cards: Mt[e],
		stage: "study",
		path: [],
		point: null,
		points: [],
		tunnels: [
			[
				0,
				1,
				2
			],
			[
				0,
				1,
				2
			],
			[
				0,
				1,
				2
			],
			[
				0,
				1,
				2
			]
		],
		entrance: null,
		you: [6, 4],
		knight: [0, 4],
		knightResult: "playing",
		success: null
	} : null;
}
var Pt = (e) => e.normalize("NFKC").toUpperCase().replace(/[\s,，、/;；\-→。.[\]()（）:：]+/g, ""), Ft = {
	110: ["124"],
	125: [
		"2",
		"TUNNEL2",
		"隧道2"
	],
	174: ["3425"],
	187: ["ADCG"],
	207: ["A1B1C2C3D4E4F3G2"],
	231: ["458"],
	233: [
		"12SPARKS1FIRE",
		"12火花1火焰",
		"十二火花一火焰",
		"十二个火花一团火焰",
		"12个火花1团火焰"
	],
	537: ["DBCA"],
	543: [
		"A",
		"BONEA",
		"骨头A",
		"骨A"
	],
	586: [
		"HOOK",
		"钩子",
		"钩",
		"鈎子"
	],
	621: ["NEWSNWSWNESENEWN", "东北西南西北西南北东东南东北西北"],
	1002: ["1DBCA6"]
}, It = /* @__PURE__ */ new Set([
	"2,0",
	"2,4",
	"2,6",
	"3,4",
	"4,2",
	"4,6",
	"4,8"
]), Lt = /* @__PURE__ */ new Set([
	"1,2",
	"1,6",
	"5,2",
	"5,6"
]), Rt = {
	N: [-1, 0],
	E: [0, 1],
	S: [1, 0],
	W: [0, -1]
}, zt = ([e, t]) => e >= 0 && e < 7 && t >= 0 && t < 9, Bt = [
	[243, 54],
	[317, 57],
	[375, 50],
	[445, 48],
	[513, 54],
	[565, 58],
	[224, 127],
	[292, 130],
	[368, 133],
	[445, 137],
	[513, 143],
	[572, 143],
	[201, 196],
	[277, 194],
	[359, 200],
	[450, 216],
	[521, 218],
	[582, 222],
	[172, 262],
	[258, 271],
	[359, 276],
	[453, 286],
	[524, 298],
	[598, 300],
	[146, 337],
	[249, 342],
	[358, 348],
	[460, 359],
	[550, 359],
	[625, 368],
	[105, 422],
	[219, 435],
	[359, 433],
	[461, 448],
	[555, 438],
	[636, 435]
], Vt = [
	[
		3,
		2,
		null,
		null,
		null
	],
	[
		3,
		null,
		3,
		1,
		1
	],
	[
		null,
		0,
		1,
		1,
		1
	],
	[
		2,
		null,
		null,
		null,
		null
	],
	[
		0,
		2,
		3,
		null,
		1
	]
], Ht = (e, t) => [e, t].sort((e, t) => e - t).join(":");
function Ut(e) {
	if (e.length < 5 || e[0] !== 32 || e.at(-1) !== 32) return !1;
	let t = /* @__PURE__ */ new Set();
	for (let n = 1; n < e.length; n++) {
		let r = e[n - 1], i = e[n];
		if (Math.abs(Math.floor(r / 6) - Math.floor(i / 6)) + Math.abs(r % 6 - i % 6) !== 1 || t.has(Ht(r, i))) return !1;
		t.add(Ht(r, i));
	}
	return new Set(e.slice(0, -1)).size === e.length - 1 && Vt.every((e, n) => e.every((e, r) => e === null || [
		[n * 6 + r, n * 6 + r + 1],
		[(n + 1) * 6 + r, (n + 1) * 6 + r + 1],
		[n * 6 + r, (n + 1) * 6 + r],
		[n * 6 + r + 1, (n + 1) * 6 + r + 1]
	].filter(([e, n]) => t.has(Ht(e, n))).length === e));
}
function Wt(e, t, n = 0) {
	let [r, i] = e, a = !1;
	for (let e = 0, o = t.length - 1; e < t.length; o = e++) {
		let [s, c] = t[o], [l, u] = t[e], d = l - s, f = u - c, p = Math.max(0, Math.min(1, ((r - s) * d + (i - c) * f) / (d * d + f * f)));
		if (Math.hypot(r - s - p * d, i - c - p * f) <= n) return !0;
		c > i != u > i && r < (l - s) * (i - c) / (u - c) + s && (a = !a);
	}
	return a;
}
var Gt = [
	[277, 282],
	[315, 273],
	[347, 295],
	[343, 329],
	[301, 340],
	[270, 317]
];
function Kt(e) {
	return Wt([e[0] * .75, e[1] * .5], Gt, 2);
}
var qt = [
	[
		[344, 367],
		[419, 368],
		[447, 418],
		[398, 431],
		[340, 403]
	],
	[
		[448, 384],
		[524, 384],
		[548, 431],
		[500, 451],
		[449, 434]
	],
	[
		[522, 215],
		[590, 212],
		[598, 265],
		[541, 269]
	],
	[
		[454, 5],
		[555, 5],
		[583, 67],
		[517, 56],
		[475, 37]
	],
	[
		[247, 316],
		[331, 302],
		[356, 326],
		[317, 356],
		[257, 349]
	],
	[
		[202, 266],
		[280, 259],
		[286, 302],
		[218, 310]
	]
];
function Jt(e) {
	return qt.filter((t) => e.some((e) => Wt([e[0] * .75, e[1] * .5], t))).length;
}
var Yt = [
	[
		["N0-W0"],
		[
			"N0-W0",
			"W1-S1",
			"S0-E0"
		],
		["N0-E1", "S0-E0"]
	],
	[
		[
			"N0-W1",
			"W0-E0",
			"N1-S1"
		],
		["N0-E0", "S1-E1"],
		["W0-S0"]
	],
	[
		["S0-E0", "N1-E1"],
		["N0-W0", "W1-S0"],
		["N1-S0"]
	],
	[
		[
			"N0-S0",
			"W0-E0",
			"W1-E1"
		],
		["N0-E0", "S1-E1"],
		["N0-W1", "W0-S1"]
	],
	[
		["N1-E0", "S0-E1"],
		["S1-W0", "N0-W1"],
		["S0-N1"]
	]
];
function Xt(e, t) {
	if (e.length !== 4 || e.some((e) => e.length !== 3 || [...e].sort().join("") !== "012") || t < 1 || t > 3) return !1;
	let n = 4, r = t - 1, i = t === 2 ? "S1" : "S0", a = /* @__PURE__ */ new Set();
	for (; n >= 0 && n < 5 && r >= 0 && r < 3;) {
		let t = [
			n,
			r,
			i
		].join(":");
		if (a.has(t)) return !1;
		a.add(t);
		let o = Yt[n][n === 4 ? r : e[n][r]].map((e) => e.split("-")).find((e) => e.includes(i));
		if (!o) return !1;
		let s = o.find((e) => e !== i), c = s[1];
		if (s[0] === "N") {
			if (n === 0) return r === 0;
			n--, i = "S" + c;
		} else s[0] === "S" ? (n++, i = "N" + c) : s[0] === "E" ? (r++, i = "W" + c) : (r--, i = "E" + c);
	}
	return !1;
}
function Zt(e) {
	return e.id !== 128 || e.stage !== "answer" || e.knightResult !== "playing" ? [] : [
		"N",
		"E",
		"S",
		"W"
	].filter((t) => {
		let [n, r] = Rt[t], i = [e.you[0] + n, e.you[1] + r];
		return zt(i) && !It.has(i.join(",")) && !Lt.has(i.join(","));
	});
}
function Qt(e, t) {
	if (e.id !== 693 || e.stage !== "answer") return !1;
	let n = e.path.at(-1);
	return e.path.length > 1 && t === e.path.at(-2) ? !0 : n === void 0 ? t === 32 : n !== t && Math.abs(Math.floor(n / 6) - Math.floor(t / 6)) + Math.abs(n % 6 - t % 6) === 1 && !(e.path.length > 1 && n === 32) && (!e.path.includes(t) || t === 32);
}
function $t(e, t) {
	if (e.stage === "done") return null;
	let n = structuredClone(e);
	if (t.op === "ready") return n.stage === "study" ? (n.stage = "answer", n) : null;
	if (t.op === "clear") return n.stage !== "answer" || ![
		511,
		693,
		721,
		125
	].includes(n.id) ? null : (n.path = [], n.point = null, n.points = [], n.tunnels = [
		[
			0,
			1,
			2
		],
		[
			0,
			1,
			2
		],
		[
			0,
			1,
			2
		],
		[
			0,
			1,
			2
		]
	], n.entrance = null, n);
	if (t.op === "tunnel") {
		if (n.id !== 125 || n.stage !== "answer" || t.row === void 0 || t.column === void 0 || t.target === void 0 || t.column === t.target) return null;
		let e = n.tunnels[t.row];
		return [e[t.column], e[t.target]] = [e[t.target], e[t.column]], n;
	}
	if (t.op === "entrance") return n.id !== 125 || n.stage !== "answer" || t.entrance === void 0 ? null : (n.entrance = t.entrance, n);
	if (t.op === "move") {
		if (n.id !== 128 || n.stage !== "answer" || n.knightResult !== "playing" || !t.direction) return null;
		let [e, r] = Rt[t.direction], i = [n.you[0] + e, n.you[1] + r];
		if (!zt(i) || It.has(i.join(",")) || Lt.has(i.join(","))) return null;
		if (n.you = i, i.join(",") === n.knight.join(",")) return n.knightResult = "lost", n;
		let a = [n.knight[0] - e, n.knight[1] - r];
		return zt(a) && !It.has(a.join(",")) && (n.knight = a), Lt.has(n.knight.join(",")) ? n.knightResult = "won" : n.you.join(",") === n.knight.join(",") && (n.knightResult = "lost"), n;
	}
	if (t.op === "point") {
		if (![511, 721].includes(n.id) || n.stage !== "answer" || !t.point) return null;
		if (n.id === 721) n.point = t.point;
		else {
			if (n.points.length >= 6) return null;
			n.points.push(t.point);
		}
		return n;
	}
	if (t.op === "remove") return n.id !== 511 || n.stage !== "answer" || t.index === void 0 || t.index >= n.points.length ? null : (n.points.splice(t.index, 1), n);
	if (t.op === "knot") return t.knot === void 0 || !Qt(n, t.knot) ? null : n.path.length > 1 && t.knot === n.path.at(-2) ? (n.path.pop(), n) : (n.path.push(t.knot), n);
	if (t.op !== "submit" || n.stage !== "answer") return null;
	if (n.id === 128) {
		if (n.knightResult === "playing") return null;
		n.success = n.knightResult === "won";
	} else if (n.id === 693) n.success = Ut(n.path);
	else if (n.id === 721) {
		if (!n.point) return null;
		n.success = Kt(n.point);
	} else if (n.id === 511) {
		if (n.points.length < 5) return null;
		n.success = Jt(n.points) >= 5;
	} else if (n.id === 125 && n.entrance !== null) n.success = n.entrance === 2 || Xt(n.tunnels, n.entrance);
	else {
		if (!t.answer?.trim()) return null;
		n.success = (Ft[n.id] ?? []).includes(Pt(t.answer));
	}
	return n.stage = "done", n;
}
function en(e) {
	let t = (e, t, n = e) => ({
		text: e,
		zh: t,
		instructions: n,
		choices: []
	}), n = {
		110: 1248,
		125: 998,
		174: 1241,
		187: 1003,
		207: 1245,
		231: 1001,
		233: 1243,
		537: 1141,
		543: 1007,
		586: 997,
		621: 1240,
		693: 1250,
		721: 1247,
		1002: 1141
	}, r = {
		110: 1388,
		174: 1394,
		207: 1391,
		233: 1395,
		621: 1396,
		693: 1386,
		721: 1389,
		1002: 1396
	}, i = t(e.success ? "Your answer is correct." : "Your answer is incorrect.", e.success ? "答案正确。" : "答案不正确。", "");
	return e.id === 128 ? (i.zh = e.success ? "骑士落入深坑，你赢得了试炼。" : "你与骑士位于同一格，失去1点生命。", i.text = e.success ? "The knight fell into a pit. You won the trial." : "You and the knight share a square. Lose 1 health.", e.success ? i.choices = [{
		label: "Gain the loyal knight",
		labelZh: "让骑士加入同行",
		node: t("Gain sentient 1357.", "获得智慧生物1357。")
	}, {
		label: "Take the blade",
		labelZh: "领取刀刃",
		node: t("Gain item 1005.", "获得物品1005。")
	}] : i.instructions = "Lose 1 health.") : i.instructions = e.success ? `Gain item ${n[e.id] ?? 1006}.` : e.id === 537 ? "Lose 1 boost on your character." : "Gain 2 random skills.", e.success && r[e.id] && (i.instructions += ` Lose curse ${r[e.id]}.`), (e.success && [
		125,
		187,
		231,
		511
	].includes(e.id) || e.id === 128) && (i.forbidLocation = e.id), e.id === 1002 && (i.instructions += " Lose item 1002."), e.id === 543 && (i.after = t("Go to 269.", "前往地点269。")), i;
}
//#endregion
//#region src/games/vantage/action-bonus.ts
var tn = e.object({
	ignore: e.array(e.enum([
		"time",
		"morale",
		"health",
		"setback",
		"blank"
	])).default([]),
	ignoreOne: e.boolean().default(!1),
	changeOne: e.boolean().default(!1),
	reroll: e.boolean().default(!1),
	half: e.boolean().default(!1),
	helpDiscount: e.boolean().default(!1),
	chooseIgnore: e.boolean().default(!1),
	initial: e.boolean().default(!1),
	immunity: e.enum(["heat", "cold"]).nullable().default(null)
});
function nn(e, t, n = 0) {
	return Math.max(0, (t?.half ? Math.ceil(e / 2) : e) - (t?.helpDiscount ? Math.min(2, n) : 0));
}
function rn(e, t, n, r) {
	return !!e?.ignore?.includes(t) || !!e?.initial && t === "time" && r.includes(n);
}
//#endregion
//#region src/games/vantage/story-barter.ts
function an(e, t) {
	return [
		...e.grid,
		...e.reserve,
		...t.supply ? e.supply : []
	].flatMap((n) => !n || n.hiddenAt !== void 0 || n.card === e.character || t.minValue !== void 0 && (E[n.card].value ?? -1) < t.minValue || t.traits?.length && !t.traits.some((e) => P(n.card, e)) || t.exclude?.includes(n.card) || t.token && n.boost < 1 || t.sale && E[n.card].value === void 0 ? [] : [n.card]);
}
//#endregion
//#region src/games/vantage/story-tests.ts
function on(e, t, n) {
	return e.rerollEach ? t.flatMap((e, t) => n.includes(t) ? [] : [t]) : !e.rerollWith || t.filter((t) => t === e.rerollWith).length <= n.length ? [] : t.flatMap((t, n) => e.rerollTargets?.includes(t) ? [n] : []);
}
//#endregion
//#region src/games/vantage/rune-rules.ts
function sn(e) {
	return e.players.find((e) => e.supply.some((e) => e.card === 1706 && !e.rotated));
}
function cn(e) {
	return Array.from({ length: 18 }, (t, n) => e.runeQuest?.entries.some((e) => e.row === Math.floor(n / 6) && C.indexOf(e.skill) === n % 6) ?? !1);
}
function ln(e, t, n, r, i) {
	let a = sn(e)?.supply.find((e) => e.card === 1706 && !e.rotated), o = e.runeQuest?.entries, s = e.personal[t.rid].location;
	if (!a || !o || s <= 1 || o.some((e) => e.location === s || e.skill === n && e.row === r)) return !1;
	if (o.push({
		location: s,
		skill: n,
		row: r
	}), a.tokens = o.length, o.filter((e) => e.row === r).length === 6) for (let t of e.players) i(t, w[r]);
	if (o.filter((e) => e.skill === n).length === 3) for (let t of e.players) t.skills[n]++;
	return !0;
}
//#endregion
//#region src/games/vantage/location-rules.ts
var un = /* @__PURE__ */ new Set([
	14,
	15,
	16,
	17,
	18,
	19,
	593,
	594,
	595,
	596,
	598,
	599
]), dn = /* @__PURE__ */ new Set([
	...un,
	...Array.from({ length: 21 }, (e, t) => 20 + t),
	...Array.from({ length: 8 }, (e, t) => 43 + t),
	...Array.from({ length: 21 }, (e, t) => 79 + t)
]);
function fn(e) {
	return dn.has(e);
}
function pn(e) {
	return e === 41 || e >= 518 && e <= 531;
}
function mn(e) {
	return pn(e) || e === 439 || e === 791 || un.has(e);
}
//#endregion
//#region src/games/vantage/launch.ts
function hn() {
	return {
		dragonEscape: !1,
		founderTemple: !1,
		elementalSlain: !1,
		elementalAction: !1,
		hackedTowers: [],
		acquiredCards: [],
		objectives: [],
		origin: !1,
		signalCut: !1,
		diplomacy: !1,
		sentients: [],
		sentientOrigins: {},
		travelerLocations: [],
		travelerRescue: !1,
		vantages: [],
		quests: [],
		towers: [],
		conquests: {}
	};
}
function gn(e, t, n) {
	if (t) {
		e.turn = 0, e.round = 1, e.phase = "launch", e.penaltyDice = 0, e.center = [], e.missionDone = !1, e.missionPivot = !1, e.pivotUsed = !1, e.destinyDone = !1, e.ending = "none", e.endingRequestedBy = null, e.challenge = null, e.passage = null, e.pendingCards = [], e.continuation = "no", e.locationContinuation = !1, e.lastChanceUsed = !1, e.skirm = null, e.duelsWon = 0, e.lastSkirmWon = null, e.skillResult = null, e.rescue = null, e.milestones = hn(), e.spentExperience = [], e.blankSetbacks = !1, e.slotPermission = [], e.impactPermission = [], e.followConsent = [], e.deliveries = {}, e.pendingInstances = {}, e.replacementCells = {}, e.freeReading = !1, e.cardClaims = [], e.placementChoices = [], e.replenishments = [], e.replenishResume = null, e.eggHatches = [], e.protection = [], e.temporaryImpact = [], e.blankRewards = {}, e.stopForced = [], e.setFaces = [], e.gamblePlayer = null, e.skillRolls = [], e.crewSharing = null, e.runeFaces = [], e.runeSurvey = null, e.runeSkill = null, e.runeQuest = null, e.storyTest = null, e.sentientTrial = null, e.elemental = null, e.restrictedActions = [], e.restrictedSkill = null, e.summoning = null, e.arrivals = [], e.arrivalResume = null, e.arrivalSecret = !1, e.arrivalStack = [], e.arrivalEndsTurn = !1, e.arrivalReader = null, e.crisisResume = null, e.pool = 8 + 2 * e.players.length - e.players.reduce((e, t) => e + [...t.grid, ...t.reserve].reduce((e, t) => e + (t ? Object.keys(t.dice).length : 0), 0), 0);
		let t = new Set(e.players.flatMap((e) => e.skirm)), r = Array.from({ length: 144 }, (e, t) => t + 1).filter((e) => !t.has(e));
		e.pack = [];
		for (let t = 0; t < 15 && r.length; t++) e.pack.push(r.splice(n(r.length), 1)[0]);
		let i = [
			0,
			1,
			2,
			3,
			4,
			5
		];
		for (let t of e.players) {
			t.coins = 0, t.supply = [], t.landingReady = !1;
			let r = e.startingStat ?? 4;
			t.stats = {
				time: r,
				morale: r,
				health: r
			};
			let a = e.personal[t.rid], o = i.splice(n(i.length), 1)[0], s = [n(6), n(6)];
			e.personal[t.rid] = {
				escape: o,
				landing: s,
				location: 0,
				visited: [],
				usedLocations: [],
				usedActions: [],
				forbiddenLocations: [],
				notes: a.notes,
				bookPages: [],
				dungeonOrigin: null,
				scouted: [],
				revealedCosts: [],
				questLocations: {},
				questFlags: [],
				expiredQuests: []
			};
		}
		e.missionDice = [n(6), n(6)], e.mission = ne[re(...e.missionDice)], e.center = [{
			card: e.mission,
			boost: 0,
			dice: {}
		}], e.missionSkills = We(e, e.players[0], e.missionDice.map((e) => C[e]));
	} else for (let t of e.players) {
		let n = e.personal[t.rid];
		Ge(t, n.escapeSkills), Ge(t, n.landingSkills), n.escapeSkills = {}, n.landingSkills = {}, n.location = 0;
	}
	e.launch = {
		stage: "000",
		ready: [],
		selected: [],
		rewind: t,
		stats: Object.fromEntries(e.players.map((t) => [t.rid, e.startingStat ?? 4])),
		locked: []
	}, e.phase = "launch";
}
function _n(e, t, n) {
	if (e.phase !== "launch" || e.launch?.stage !== "000" || e.launch.ready.includes(t) || n !== e.launch.stats[t]) return !1;
	if (e.launch.ready.push(t), e.launch.ready.length === e.players.length) {
		e.launch.stage = "001";
		for (let t of Object.values(e.personal)) t.location = 1;
	}
	return !0;
}
function vn(e) {
	return e.phase !== "launch" || e.launch?.stage !== "001" ? [] : C.filter((t, n) => !e.launch.selected.some((t) => e.personal[t].escape === n));
}
function yn(e, t, n) {
	if (!e.launch || e.launch.selected.includes(t) || !vn(e).includes(n)) return !1;
	let r = e.launch.joined?.[t] ?? t, i = e.personal[r].landing;
	for (let r of xn(e, t)) {
		let t = e.players.find((e) => e.rid === r), a = e.personal[r];
		a.escape = C.indexOf(n), a.landing = [...i], a.escapeSkills = We(e, t, [n]), a.landingSkills = We(e, t, a.landing.map((e) => C[e])), e.launch.selected.push(r);
	}
	return bn(e), !0;
}
function bn(e) {
	if (e.launch?.stage === "001" && e.launch.selected.length === e.players.length) {
		e.launch.stage = "landing", e.phase = "landing", e.turn = 0;
		for (let t of e.players) {
			let n = e.personal[t.rid];
			n.location = te[n.escape][re(...n.landing)];
		}
	}
}
function xn(e, t) {
	let n = e.launch?.joined?.[t] ?? t;
	return e.players.filter((t) => (e.launch?.joined?.[t.rid] ?? t.rid) === n).map((e) => e.rid);
}
function Sn(e, t) {
	let n = e.personal[t];
	return n.landing[0] === n.landing[1] && xn(e, t).every((t) => !e.players.find((e) => e.rid === t).landingReady);
}
function Cn(e, t, n) {
	let r = e.launch;
	if (r?.stage !== "001" || !e.players.some((e) => e.rid === n)) return !1;
	let i = xn(e, t), a = r.joined?.[n] ?? n;
	if (i.includes(n) || i.some((e) => r.selected.includes(e))) return !1;
	for (let t of i) if ((r.joined ??= {})[t] = a, r.selected.includes(a)) {
		let n = e.players.find((e) => e.rid === t), i = e.personal[t], o = e.personal[a];
		i.escape = o.escape, i.landing = [...o.landing], i.escapeSkills = We(e, n, [C[i.escape]]), i.landingSkills = We(e, n, i.landing.map((e) => C[e])), r.selected.push(t);
	}
	return !0;
}
//#endregion
//#region src/games/vantage/flight.ts
var wn = {
	8: "M",
	9: "N",
	10: "O",
	11: "P",
	12: "P",
	13: "J",
	14: "F",
	15: "B",
	16: "L",
	17: "M",
	18: "N",
	19: "D",
	20: "J",
	21: "B",
	22: "F",
	23: "L",
	24: "J",
	25: "H",
	26: "O",
	27: "C",
	28: "M",
	29: "M",
	30: "I",
	31: "L",
	32: "P",
	33: "K",
	34: "F",
	35: "K",
	36: "E",
	37: "N",
	38: "I",
	39: "G",
	40: "–",
	41: "F",
	42: "F",
	43: "F",
	44: "M",
	45: "N",
	46: "D",
	47: "K",
	48: "G",
	49: "O",
	50: "J",
	51: "–",
	52: "–",
	53: "–",
	54: "–",
	55: "–",
	56: "–",
	57: "–",
	58: "–",
	59: "–",
	60: "–",
	61: "–",
	62: "–",
	63: "–",
	64: "A",
	65: "B",
	66: "C",
	67: "D",
	68: "E",
	69: "F",
	70: "G",
	71: "H",
	72: "I",
	73: "J",
	74: "K",
	75: "L",
	76: "E",
	77: "E",
	78: "E",
	79: "J",
	80: "J",
	81: "B",
	82: "F",
	83: "L",
	84: "J",
	85: "H",
	86: "N",
	87: "C",
	88: "M",
	89: "M",
	90: "I",
	91: "L",
	92: "O",
	93: "K",
	94: "F",
	95: "K",
	96: "E",
	97: "M",
	98: "I",
	99: "G",
	100: "K",
	101: "K",
	102: "K",
	103: "K",
	104: "K",
	105: "K",
	106: "K",
	107: "K",
	108: "K",
	109: "K",
	110: "K",
	111: "K",
	112: "K",
	113: "K",
	114: "K",
	115: "K",
	116: "K",
	117: "K",
	118: "K",
	119: "K",
	120: "K",
	121: "K",
	122: "K",
	123: "K",
	124: "K",
	125: "O",
	126: "O",
	127: "O",
	128: "O",
	129: "O",
	130: "O",
	131: "O",
	132: "O",
	133: "O",
	134: "O",
	135: "O",
	136: "O",
	137: "O",
	138: "O",
	139: "O",
	140: "O",
	141: "O",
	142: "O",
	143: "O",
	144: "O",
	145: "K",
	146: "K",
	147: "K",
	148: "K",
	149: "K",
	150: "G",
	151: "G",
	152: "G",
	153: "G",
	154: "G",
	155: "G",
	156: "G",
	157: "G",
	158: "G",
	159: "G",
	160: "G",
	161: "G",
	162: "G",
	163: "G",
	164: "G",
	165: "G",
	166: "G",
	167: "G",
	168: "G",
	169: "G",
	170: "G",
	171: "G",
	172: "G",
	173: "G",
	174: "G",
	175: "E",
	176: "E",
	177: "E",
	178: "E",
	179: "E",
	180: "E",
	181: "E",
	182: "E",
	183: "E",
	184: "E",
	185: "E",
	186: "E",
	187: "E",
	188: "E",
	189: "E",
	190: "E",
	191: "E",
	192: "E",
	193: "E",
	194: "E",
	195: "A",
	196: "A",
	197: "A",
	198: "A",
	199: "A",
	200: "F",
	201: "F",
	202: "F",
	203: "F",
	204: "F",
	205: "F",
	206: "F",
	207: "F",
	208: "F",
	209: "F",
	210: "F",
	211: "F",
	212: "F",
	213: "F",
	214: "F",
	215: "F",
	216: "F",
	217: "F",
	218: "F",
	219: "F",
	220: "F",
	221: "F",
	222: "F",
	223: "F",
	224: "F",
	225: "A",
	226: "A",
	227: "A",
	228: "A",
	229: "A",
	230: "A",
	231: "A",
	232: "A",
	233: "A",
	234: "A",
	235: "A",
	236: "A",
	237: "A",
	238: "A",
	239: "A",
	240: "A",
	241: "A",
	242: "A",
	243: "A",
	244: "A",
	245: "A",
	246: "A",
	247: "A",
	248: "A",
	249: "A",
	250: "C",
	251: "C",
	252: "C",
	253: "C",
	254: "C",
	255: "C",
	256: "C",
	257: "C",
	258: "C",
	259: "C",
	260: "C",
	261: "C",
	262: "C",
	263: "C",
	264: "C",
	265: "C",
	266: "C",
	267: "C",
	268: "C",
	269: "C",
	270: "C",
	271: "C",
	272: "C",
	273: "C",
	274: "C",
	275: "H",
	276: "H",
	277: "H",
	278: "H",
	279: "H",
	280: "H",
	281: "H",
	282: "H",
	283: "H",
	284: "H",
	285: "H",
	286: "H",
	287: "H",
	288: "H",
	289: "H",
	290: "H",
	291: "H",
	292: "H",
	293: "H",
	294: "H",
	295: "D",
	296: "D",
	297: "D",
	298: "D",
	299: "D",
	300: "N",
	301: "N",
	302: "N",
	303: "N",
	304: "N",
	305: "N",
	306: "N",
	307: "N",
	308: "N",
	309: "N",
	310: "N",
	311: "N",
	312: "N",
	313: "N",
	314: "N",
	315: "N",
	316: "N",
	317: "N",
	318: "N",
	319: "N",
	320: "J",
	321: "J",
	322: "J",
	323: "J",
	324: "J",
	325: "D",
	326: "D",
	327: "D",
	328: "D",
	329: "D",
	330: "D",
	331: "D",
	332: "D",
	333: "D",
	334: "D",
	335: "D",
	336: "D",
	337: "D",
	338: "D",
	339: "D",
	340: "D",
	341: "D",
	342: "D",
	343: "D",
	344: "D",
	345: "E",
	346: "E",
	347: "E",
	348: "E",
	349: "E",
	350: "M",
	351: "N",
	352: "N",
	353: "N",
	354: "N",
	355: "N",
	356: "N",
	357: "O",
	358: "O",
	359: "O",
	360: "O",
	361: "O",
	362: "O",
	363: "P",
	364: "P",
	365: "P",
	366: "P",
	367: "P",
	368: "P",
	369: "M",
	370: "N",
	371: "N",
	372: "N",
	373: "N",
	374: "N",
	375: "N",
	376: "O",
	377: "O",
	378: "O",
	379: "O",
	380: "O",
	381: "O",
	382: "M",
	383: "M",
	384: "M",
	385: "M",
	386: "I",
	387: "I",
	388: "I",
	389: "I",
	390: "I",
	391: "I",
	392: "I",
	393: "E",
	394: "E",
	395: "E",
	396: "E",
	397: "E",
	398: "E",
	399: "A",
	400: "A",
	401: "A",
	402: "A",
	403: "A",
	404: "N",
	405: "N",
	406: "N",
	407: "N",
	408: "J",
	409: "J",
	410: "J",
	411: "J",
	412: "J",
	413: "J",
	414: "J",
	415: "F",
	416: "F",
	417: "F",
	418: "F",
	419: "F",
	420: "F",
	421: "B",
	422: "B",
	423: "B",
	424: "B",
	425: "B",
	426: "O",
	427: "O",
	428: "O",
	429: "O",
	430: "K",
	431: "K",
	432: "K",
	433: "K",
	434: "K",
	435: "K",
	436: "K",
	437: "G",
	438: "G",
	439: "G",
	440: "G",
	441: "G",
	442: "G",
	443: "C",
	444: "C",
	445: "C",
	446: "C",
	447: "C",
	448: "P",
	449: "P",
	450: "P",
	451: "P",
	452: "P",
	453: "L",
	454: "L",
	455: "L",
	456: "L",
	457: "L",
	458: "L",
	459: "L",
	460: "H",
	461: "H",
	462: "H",
	463: "H",
	464: "H",
	465: "H",
	466: "D",
	467: "D",
	468: "D",
	469: "D",
	470: "D",
	471: "K",
	472: "K",
	473: "K",
	474: "K",
	475: "K",
	476: "L",
	477: "L",
	478: "L",
	479: "L",
	480: "L",
	481: "G",
	482: "G",
	483: "G",
	484: "G",
	485: "G",
	486: "H",
	487: "H",
	488: "H",
	489: "H",
	490: "H",
	491: "A",
	492: "B",
	493: "B",
	494: "B",
	495: "B",
	496: "B",
	497: "B",
	498: "C",
	499: "C",
	500: "C",
	501: "C",
	502: "C",
	503: "C",
	504: "D",
	505: "D",
	506: "D",
	507: "D",
	508: "D",
	509: "D",
	510: "L",
	511: "K",
	512: "P",
	513: "F",
	514: "P",
	515: "–",
	516: "–",
	517: "–",
	518: "E",
	519: "M",
	520: "A",
	521: "B",
	522: "F",
	523: "J",
	524: "C",
	525: "G",
	526: "K",
	527: "L",
	528: "P",
	529: "D",
	530: "D",
	531: "H",
	541: "O",
	542: "E",
	543: "C",
	544: "M",
	545: "N",
	546: "I",
	547: "J",
	548: "E",
	549: "K",
	550: "O",
	551: "A",
	552: "H",
	553: "K",
	554: "G",
	555: "O",
	556: "F",
	557: "F",
	558: "C",
	559: "J",
	560: "M",
	561: "H",
	562: "G",
	563: "F",
	564: "F",
	565: "A",
	566: "N",
	567: "J",
	568: "D",
	569: "D",
	570: "D",
	571: "O",
	572: "E",
	573: "J",
	574: "L",
	575: "L",
	576: "L",
	577: "H",
	578: "B",
	579: "C",
	580: "B",
	581: "B",
	582: "P",
	583: "E",
	584: "M",
	585: "M",
	586: "M",
	587: "L",
	588: "L",
	589: "I",
	590: "I",
	591: "I",
	592: "H",
	593: "E",
	594: "L",
	595: "F",
	596: "K",
	597: "N",
	598: "J",
	599: "G",
	600: "J",
	601: "F",
	602: "F",
	603: "F",
	604: "F",
	605: "F",
	606: "B",
	607: "B",
	608: "B",
	609: "B",
	610: "B",
	611: "B",
	612: "B",
	613: "B",
	614: "B",
	615: "B",
	616: "B",
	617: "B",
	618: "B",
	619: "B",
	620: "B",
	621: "B",
	622: "B",
	623: "B",
	624: "B",
	625: "B",
	626: "B",
	627: "B",
	628: "B",
	629: "B",
	630: "B",
	631: "P",
	632: "P",
	633: "P",
	634: "P",
	635: "P",
	636: "L",
	637: "P",
	638: "P",
	639: "P",
	640: "P",
	641: "P",
	642: "L",
	643: "P",
	644: "P",
	645: "P",
	646: "P",
	647: "P",
	648: "L",
	649: "P",
	650: "P",
	651: "P",
	652: "P",
	653: "P",
	654: "L",
	655: "P",
	656: "P",
	657: "P",
	658: "P",
	659: "P",
	660: "L",
	661: "M",
	662: "M",
	663: "M",
	664: "M",
	665: "M",
	666: "M",
	667: "M",
	668: "M",
	669: "M",
	670: "M",
	671: "M",
	672: "M",
	673: "M",
	674: "M",
	675: "M",
	676: "M",
	677: "M",
	678: "M",
	679: "M",
	680: "M",
	681: "M",
	682: "M",
	683: "M",
	684: "M",
	685: "M",
	686: "M",
	687: "M",
	688: "M",
	689: "M",
	690: "M",
	691: "I",
	692: "I",
	693: "I",
	694: "I",
	695: "I",
	696: "I",
	697: "I",
	698: "I",
	699: "I",
	700: "I",
	701: "J",
	702: "J",
	703: "J",
	704: "J",
	705: "J",
	706: "J",
	707: "J",
	708: "J",
	709: "J",
	710: "J",
	711: "J",
	712: "J",
	713: "J",
	714: "J",
	715: "J",
	716: "J",
	717: "J",
	718: "J",
	719: "J",
	720: "J",
	721: "J",
	722: "J",
	723: "J",
	724: "J",
	725: "J",
	726: "J",
	727: "J",
	728: "J",
	729: "J",
	730: "J",
	731: "L",
	732: "L",
	733: "L",
	734: "L",
	735: "L",
	736: "H",
	737: "L",
	738: "L",
	739: "L",
	740: "L",
	741: "L",
	742: "H",
	743: "L",
	744: "L",
	745: "L",
	746: "L",
	747: "L",
	748: "H",
	749: "L",
	750: "L",
	751: "L",
	752: "L",
	753: "L",
	754: "H",
	755: "L",
	756: "L",
	757: "L",
	758: "L",
	759: "L",
	760: "H",
	761: "I",
	762: "I",
	763: "I",
	764: "I",
	765: "I",
	766: "E",
	767: "I",
	768: "I",
	769: "I",
	770: "I",
	771: "I",
	772: "E",
	773: "I",
	774: "I",
	775: "I",
	776: "I",
	777: "I",
	778: "E",
	779: "I",
	780: "I",
	781: "I",
	782: "I",
	783: "I",
	784: "E",
	785: "I",
	786: "I",
	787: "I",
	788: "I",
	789: "I",
	790: "E",
	791: "L",
	795: "H",
	799: "E",
	801: "N"
}, Tn = Object.fromEntries([...Array.from({ length: 12 }, (e, t) => [String.fromCharCode(65 + t), 64 + t]), ...Array.from({ length: 4 }, (e, t) => [String.fromCharCode(77 + t), 8 + t])]), En = /* @__PURE__ */ new Set([
	510,
	513,
	...Array.from({ length: 52 }, (e, t) => 541 + t),
	597,
	600,
	791,
	795,
	799
]);
function Dn(e) {
	return e >= 8 && e <= 11 || e >= 64 && e <= 75;
}
function On(e) {
	return (e === 78 || e >= 100 && e <= 514 || e >= 518 && e <= 531 || e >= 601 && e <= 630 || e >= 661 && e <= 801) && !En.has(e) ? Tn[wn[e]] ?? null : null;
}
function kn(e) {
	let t = wn[e];
	return t ? 31 + t.charCodeAt(0) - 65 : null;
}
function An(e) {
	let t = kn(e);
	return t === null ? null : [
		96,
		81,
		87,
		85,
		90,
		82,
		99,
		83,
		98,
		84,
		95,
		91,
		88,
		89,
		86,
		92
	][t - 31] ?? null;
}
function jn(e) {
	let t = kn(e);
	return t === null ? null : [
		236,
		622,
		267,
		332,
		178,
		212,
		162,
		279,
		775,
		721,
		117,
		745,
		678,
		305,
		133,
		651
	][t - 31] ?? null;
}
function Mn(e, t) {
	let n = e.players.find((e) => e.rid === t).grid;
	return !n.some((e) => e?.card === 1010) || n.some((e) => e && [
		957,
		985,
		1017,
		1023,
		1033,
		1110,
		1253,
		1434
	].includes(e.card));
}
//#endregion
//#region src/games/vantage/meta.ts
var Nn = {
	id: "vantage",
	tier: "alpha",
	sdkApi: 4,
	assetLoading: "deferred-images",
	mechanics: [
		"dice-rolling",
		"grid-movement",
		"action-points"
	],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.vantage.name",
	descKey: "games.vantage.desc",
	rulesKey: "games.vantage.rules",
	icon: "🌌",
	iconImg: "games/vantage.webp",
	rulesUrl: { en: "https://rulepop.com/vantage/" },
	minPlayers: 1,
	maxPlayers: 6,
	bestPlayers: [
		1,
		2,
		3,
		4
	],
	accent: "#497c91",
	releasedAt: "2026-11-04T22:00:00+08:00",
	search: {
		py: "wan jing qi lv",
		init: "wjql"
	},
	hotseat: "cover"
};
//#endregion
//#region src/games/vantage/structure-trade.ts
function Pn(e, t, n, r) {
	let i = [
		...e.grid.flatMap((e) => e ? [e] : []),
		...e.reserve,
		...e.supply
	];
	return [...i, ...i.flatMap((e) => e.tucked ?? [])].filter((i) => i.hiddenAt !== void 0 || i.card === e.character ? !1 : n === "crafted" ? i.craftedAt === r && i.craftedBy === e.rid && E[i.card].value !== void 0 : P(i.card, n) && (t === "token" ? i.boost > 0 : E[i.card].value !== void 0)).map((e) => e.card);
}
//#endregion
//#region src/games/vantage/goals.ts
var Fn = [
	1265,
	1283,
	1289,
	1290,
	1687,
	1688,
	1689,
	1690,
	1691,
	1692,
	1701
], In = [
	956,
	959,
	960,
	1038,
	1089,
	1090,
	1152,
	1153,
	1231,
	1233
], Ln = {
	1577: 1603,
	1578: 1608,
	1579: 1598,
	1580: 1607,
	1581: 1604,
	1582: 1605,
	1583: 1601,
	1584: 1602,
	1585: 1598,
	1586: 1603,
	1587: 1600,
	1588: 1599,
	1589: 1606,
	1590: 1600,
	1591: 1601,
	1592: 1602,
	1593: 1605,
	1594: 1607,
	1595: 1606,
	1596: 1605,
	1597: 1604
}, Rn = [
	1577,
	1578,
	1581,
	1589,
	1590,
	1596
];
function zn(e) {
	return e.milestones.sentients.reduce((e, t) => e + (["location:286", "card:1342"].includes(t) ? 3 : 1), 0);
}
function Bn(e, t) {
	return !!e.players.find((e) => e.rid === t)?.grid.some((e) => e?.card === 1110) && e.center.some((e) => e.card === 1602) && e.players.every((n) => e.personal[n.rid].location === e.personal[t].location);
}
function Vn(e, t) {
	let n = e.players.flatMap((e) => [...e.grid.filter((e) => e !== null), ...e.reserve]), r = (e) => n.some((t) => t.card === e), i = (t) => e.players.some((e) => e.supply.some((e) => e.card === t));
	switch (t) {
		case 1578: return e.milestones.origin || e.missionPivot && e.milestones.founderTemple;
		case 1577: return e.milestones.elementalSlain || e.missionPivot && e.milestones.elementalAction;
		case 1579: return e.players.some((t) => t.character >= 1441 && t.character <= 1452 && (e.missionPivot || t.grid[4].boost === E[t.character].boostCapacity));
		case 1580: return n.filter((e) => E[e.card].group === "flora").length >= (e.missionPivot ? 1 : 1 + e.players.length);
		case 1581: return r(865) || e.missionPivot && n.some((e) => P(e.card, "medicine"));
		case 1582: return n.filter((e) => E[e.card].group === "sentient").length >= (e.missionPivot ? 1 : 1 + e.players.length);
		case 1583: return e.players.some((t) => [...t.grid, ...t.reserve].reduce((e, t) => e + (t ? E[t.card].value ?? 0 : 0), 0) >= (e.missionPivot ? 20 : 30));
		case 1584: return n.filter((t) => E[t.card].group === "animal" && (e.missionPivot || P(t.card, "loyalAnimal"))).length >= (e.missionPivot ? 2 : 1 + e.players.length);
		case 1585: return e.milestones.vantages.length >= (e.missionPivot ? 1 : 2);
		case 1586: return e.milestones.quests.length > 0 || e.missionPivot && e.milestones.acquiredCards.some((e) => e >= 1627 && e <= 1704);
		case 1587: return e.players.reduce((e, t) => e + t.coins, 0) >= (e.missionPivot ? 10 : 10 + 5 * e.players.length);
		case 1588: return n.some((e) => e.rotated && e.card >= 1621 && e.card <= 1626) || e.missionPivot && e.milestones.objectives.length > 0;
		case 1589: return r(1232) || e.missionPivot && e.milestones.acquiredCards.some((e) => E[e].slots.some((e) => e.ability === "捕鱼"));
		case 1590: return e.milestones.signalCut || e.missionPivot && e.milestones.hackedTowers.length > 0;
		case 1591: return Fn.some(i) || e.players.some((t) => t.supply.some((t) => t.shelter || e.missionPivot && E[t.card].group === "structure"));
		case 1600: return Fn.some(i) || e.players.some((e) => e.supply.some((e) => e.shelter));
		case 1592: return Object.values(e.milestones.conquests).some((t) => t >= (e.missionPivot ? 1 : 3));
		case 1593: return e.milestones.diplomacy || n.some((e) => e.card >= 1239 && e.card <= 1250) || e.missionPivot && zn(e) >= 2;
		case 1596: return e.missionPivot && e.milestones.travelerLocations.length >= 2;
		case 1594: return new Set(n.filter((e) => e.card >= 1160 && e.card <= 1177).map((e) => (e.card - 1160) % 6).concat(n.filter((e) => e.card >= 990 && e.card <= 995).map((e) => [
			4,
			0,
			5,
			2,
			3,
			1
		][e.card - 990]))).size >= (e.missionPivot ? 1 : 2);
		case 1595: return n.filter((e) => E[e.card].slots.some((e) => e.skill === "overpower") || In.includes(e.card)).length >= (e.missionPivot ? 3 : 3 + e.players.length);
		case 1597: return n.some((t) => E[t.card].group === "item" && (E[t.card].value ?? 0) >= (e.missionPivot ? 10 : 15));
		case 1598: return e.milestones.towers.length >= 3;
		case 1599: return e.players.every((t) => [...t.grid, ...t.reserve].some((e) => e?.card === 1122) || e.players.some((n) => n.rid !== t.rid && e.personal[n.rid].location === e.personal[t.rid].location));
		case 1601: return e.players.some((e) => e.supply.some((e) => [
			"commerce",
			"agriculture",
			"service"
		].some((t) => P(e.card, t))));
		case 1602: return !!e.milestones.dragonEscape;
		case 1603: return e.duelsWon >= 1 + e.players.length;
		case 1604: return r(1369);
		case 1605: return n.some((t) => t.card === 1033 && (!(e.mission === 1596 && e.milestones.travelerRescue) || t.rescueShip));
		case 1606: return n.some((e) => e.card === 1033 && e.upgradedShip);
		case 1607: return n.some((e) => e.card === 1033 && e.builtShip);
		case 1608: return r(1381);
		default: return !1;
	}
}
//#endregion
//#region src/games/vantage/skirm-cards.json
var Hn = /*#__PURE__*/ JSON.parse("[{\"id\":\"S001\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S002\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S003\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S004\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S005\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S006\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S007\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S008\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S009\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S010\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S011\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S012\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"mask\",\"ability_text\":\"Set 2 dice to match 1 or 2 opposing dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S013\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S014\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S015\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S016\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S017\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S018\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S019\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S020\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S021\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S022\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S023\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S024\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"horn\",\"ability_text\":\"Reroll each unmatching die until it matches a skill type you have.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S025\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S026\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S027\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S028\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S029\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S030\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S031\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S032\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S033\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S034\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S035\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S036\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"gauntlet\",\"ability_text\":\"Steal 1 opposing die that does not match any of your dice.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S037\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S038\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S039\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S040\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S041\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S042\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S043\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S044\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S045\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S046\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S047\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S048\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"scepter\",\"ability_text\":\"Reroll 1 die, then set 1 die to match its skill type.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S049\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S050\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S051\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S052\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S053\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S054\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S055\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S056\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S057\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S058\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S059\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S060\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"helm\",\"ability_text\":\"Exchange 1 die for 1 opposing die. You may reroll the die you gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S061\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S062\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S063\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S064\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S065\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S066\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S067\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S068\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S069\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S070\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S071\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S072\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"harness\",\"ability_text\":\"Reroll up to 6 dice (all at once).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S073\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S074\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S075\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S076\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S077\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S078\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S079\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S080\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S081\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S082\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S083\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S084\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"cloak\",\"ability_text\":\"Reroll up to 2 dice, concealing them until final scoring.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S085\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S086\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S087\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S088\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S089\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S090\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S091\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S092\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S093\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S094\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S095\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S096\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"tome\",\"ability_text\":\"You may reroll each die once; choose the new or old result.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S097\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S098\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S099\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S100\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S101\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S102\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S103\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S104\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S105\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S106\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S107\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S108\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"dodecahedron\",\"ability_text\":\"Reroll 1 of each player's dice. Choose 1 fore each player to gain.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S109\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S110\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S111\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S112\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S113\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S114\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S115\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S116\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S117\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S118\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S119\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S120\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"mantle\",\"ability_text\":\"Give 1 die to opponent, then set X dice (X is opponent's best skill type).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S121\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S122\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S123\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S124\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S125\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S126\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S127\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S128\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S129\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S130\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S131\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S132\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"blade\",\"ability_text\":\"Cut the opposing dice into 2 groups; they choose 1 group to reroll.\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S133\",\"speed\":5,\"skills\":[\"take\",\"help\"],\"element\":\"circuit\",\"scoring_text\":\"Gain 1 point per tied skill type\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S134\",\"speed\":11,\"skills\":[\"engage\",\"move\"],\"element\":\"wind\",\"scoring_text\":\"Gain 1 point per [Move] skill\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S135\",\"speed\":10,\"skills\":[\"move\",\"look\"],\"element\":\"energy\",\"scoring_text\":\"Gain 1 point per skill of opponent's best type\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S136\",\"speed\":6,\"skills\":[\"overpower\",\"take\"],\"element\":\"fire\",\"scoring_text\":\"Gain 1 point per skill type you don't have\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S137\",\"speed\":1,\"skills\":[\"help\",\"engage\"],\"element\":\"gold\",\"scoring_text\":\"Gain 1 point per dice pair\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S138\",\"speed\":2,\"skills\":[\"take\",\"overpower\"],\"element\":\"sinew\",\"scoring_text\":\"Gain 1 point per skill of your best skill type\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S139\",\"speed\":8,\"skills\":[\"look\",\"take\"],\"element\":\"metal\",\"scoring_text\":\"Gain 1 point per unique opponent skill type\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S140\",\"speed\":12,\"skills\":[\"help\",\"move\"],\"element\":\"sand\",\"scoring_text\":\"Gain 1 point per skill type that doesn't match this\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S141\",\"speed\":3,\"skills\":[\"overpower\",\"engage\"],\"element\":\"stone\",\"scoring_text\":\"Gain 3 points if you have all 6 skill types\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S142\",\"speed\":7,\"skills\":[\"look\",\"help\"],\"element\":\"leaf\",\"scoring_text\":\"Gain 1 point per skill type you lose\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S143\",\"speed\":4,\"skills\":[\"engage\",\"overpower\"],\"element\":\"water\",\"scoring_text\":\"Gain +1 point per skill type you win\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"},{\"id\":\"S144\",\"speed\":9,\"skills\":[\"move\",\"look\"],\"element\":\"wood\",\"scoring_text\":\"Gain 1 point per different skill quantity (1+)\",\"artifact\":\"tools\",\"ability_text\":\"Set up to 3 dice to different faces (each unique).\",\"evidence_level\":\"community_list_partly_deduced_crosschecked\",\"source_article\":\"46448579\"}]"), Un = [
	"circuit",
	"wind",
	"energy",
	"fire",
	"gold",
	"sinew",
	"metal",
	"sand",
	"stone",
	"leaf",
	"water",
	"wood"
], Wn = [
	"mask",
	"horn",
	"gauntlet",
	"scepter",
	"helm",
	"harness",
	"cloak",
	"tome",
	"dodecahedron",
	"mantle",
	"blade",
	"tools"
], Gn = [
	["help", "take"],
	["move", "engage"],
	["look", "move"],
	["take", "overpower"],
	["engage", "help"],
	["overpower", "take"],
	["take", "look"],
	["move", "help"],
	["engage", "overpower"],
	["help", "look"],
	["overpower", "engage"],
	["look", "move"]
];
function Kn(e) {
	let t = e >= 1517 ? e - 1517 : (e - 1) % 12, n = e >= 1517 ? t : Math.floor((e - 1) / 12), r = Hn[n * 12 + t];
	return {
		id: e,
		element: Un[t],
		artifact: Wn[n],
		speed: r.speed,
		skills: Gn[t],
		scoring: r.scoring_text,
		ability: r.ability_text
	};
}
function qn(e, t, n, r, i) {
	let a = i ?? 1517 + r(12), o = Array.from({ length: 12 }, (e, t) => 1517 + t).filter((e) => e !== a);
	return {
		rolled: Array.from({ length: 6 }, (e, t) => ({
			side: 0,
			index: t
		})),
		controllers: [e, t ?? e],
		solo: !t,
		cards: [null, a],
		options: n.length ? [...n] : [o[r(o.length)]],
		dice: [Array.from({ length: 6 }, () => C[r(6)]), Array.from({ length: 6 }, () => C[r(6)])],
		extras: [[], []],
		removedPrinted: [[], []],
		hidden: [[], []],
		first: 0,
		turn: 0,
		stage: "choose",
		acted: [],
		processed: [],
		pending: null,
		bonus: [0, 0],
		scores: [0, 0],
		winner: null,
		rewarded: !1
	};
}
function Jn(e, t) {
	let n = e.cards[t], r = [
		...e.dice[t].filter((n, r) => !e.hidden[t].includes(r)),
		...e.extras[t],
		...n === null ? [] : Kn(n).skills.filter((n) => !e.removedPrinted[t].includes(n))
	];
	return C.map((e) => r.filter((t) => t === e).length);
}
function Yn(e, t, n, r) {
	switch (e) {
		case "circuit": return t.filter((e, t) => e === n[t]).length;
		case "wind": return t[0];
		case "energy": return Math.max(...n);
		case "fire": return t.filter((e) => e === 0).length;
		case "gold": return C.filter((e) => r.filter((t) => t === e).length >= 2).length;
		case "sinew": return Math.max(...t);
		case "metal": return n.filter((e) => e > 0).length;
		case "sand": return t.filter((e, t) => e > 0 && t !== 0 && t !== 3).length;
		case "stone": return t.every((e) => e > 0) ? 3 : 0;
		case "leaf": return t.filter((e, t) => e < n[t]).length;
		case "water": return t.filter((e, t) => e > n[t]).length;
		case "wood": return new Set(t.filter((e) => e > 0)).size;
		default: return 0;
	}
}
function Xn(e) {
	e.hidden = [[], []];
	let t = Jn(e, 0), n = Jn(e, 1);
	e.scores = [t.filter((e, t) => e > n[t]).length + e.bonus[0] + Yn(Kn(e.cards[0]).element, t, n, e.dice[0]), n.filter((e, n) => e > t[n]).length + e.bonus[1]];
	let r = Kn(e.cards[1]).element;
	e.scores[1] += e.solo ? r === "energy" ? Math.max(...n) : r === "metal" ? n.filter((e) => e > 0).length : Yn(r, t, n, e.dice[0]) : Yn(r, n, t, e.dice[1]), e.winner = e.scores[0] === e.scores[1] ? e.first : e.scores[0] > e.scores[1] ? 0 : 1, e.hidden = [[], []], e.stage = "scored";
}
function Zn(e, t, n, r) {
	return (e.rolled ??= []).push({
		side: t,
		index: n
	}), C[r(6)];
}
function Qn(e, t) {
	if (e.first === 1) {
		e.extras[1].push(C[t(6)]);
		return;
	}
	e.bonus[1]++;
	let n = T[t(6)], r = Jn(e, 0), i = Jn(e, 1);
	if (n === "morale") e.dice[1] = e.dice[1].map((n, a) => r[C.indexOf(n)] > i[C.indexOf(n)] ? Zn(e, 1, a, t) : n);
	else if (n === "setback") {
		let n = Kn(e.cards[1]).skills;
		e.dice[1] = e.dice[1].map((r, i) => n.includes(r) ? Zn(e, 1, i, t) : r), e.bonus[1]++;
	} else if (n === "time") {
		let t = C.find((t, n) => r[n] - i[n] >= 1 && r[n] - i[n] <= 2 && e.dice[0].includes(t));
		t && e.dice[1].push(e.dice[0].splice(e.dice[0].indexOf(t), 1)[0]);
	} else if (n === "health") {
		let t = Kn(e.cards[0]).skills[0];
		e.extras[1].push(t), e.removedPrinted[0].push(t);
	} else e.extras[1].push(C[t(6)]);
}
function $n(e, t) {
	if (e.pauseRolls && e.rolled?.some((e) => e.side === 0)) {
		e.resume = "finish";
		return;
	}
	if (e.acted.push(e.turn), e.processed = [], e.pending = null, e.acted.length === 2) {
		Xn(e);
		return;
	}
	e.turn = 1 - e.turn, e.stage = "ability", e.solo && e.turn === 1 && (Qn(e, t), $n(e, t));
}
function er(e, t) {
	let n = e.dice[e.turn];
	for (let r = e.hornIndex ?? 0; r < n.length; r++) {
		let i = [
			...n.filter((e, t) => t !== r),
			...Kn(e.cards[e.turn]).skills.filter((t) => !e.removedPrinted[e.turn].includes(t)),
			...e.extras[e.turn]
		];
		for (; !i.includes(n[r]);) if (n[r] = Zn(e, e.turn, r, t), e.pauseRolls && e.turn === 0) {
			e.hornIndex = r, e.resume = "horn";
			return;
		}
	}
	delete e.hornIndex, $n(e, t);
}
function tr(e, t) {
	let n = e.resume;
	delete e.resume, e.rolled = [], n === "horn" ? er(e, t) : n === "finish" && $n(e, t);
}
var nr = (e, t) => new Set(e).size === e.length && e.every((e) => Number.isInteger(e) && e >= 0 && e < t.length);
function rr(e, t, n, r, i = !1) {
	if (e.stage === "scored" || e.resume) return !1;
	if (e.pauseRolls = i, e.rolled = [], e.stage === "choose") {
		if (n !== e.controllers[0] || t.op !== "choose" || t.card === void 0 || !e.options.includes(t.card)) return !1;
		e.cards[0] = t.card;
		let i = Kn(t.card), a = Kn(e.cards[1]);
		return e.first = i.speed === a.speed ? i.id > a.id ? 0 : 1 : i.speed > a.speed ? 0 : 1, e.turn = e.first, e.stage = "ability", e.solo && e.turn === 1 && (Qn(e, r), $n(e, r)), !0;
	}
	let a = e.turn;
	if (e.stage === "blade" && (a = 1 - a), n !== e.controllers[a]) return !1;
	let o = e.dice[e.turn], s = e.dice[1 - e.turn];
	if (!nr(t.indices, o) || !nr(t.other, s) || !t.faces.every((e) => C.includes(e)) || t.other.some((t) => e.hidden[1 - e.turn].includes(t))) return !1;
	let c = Kn(e.cards[e.turn]).artifact, l = t.indices[0], u = t.other[0];
	if (e.stage === "scepter") return t.op !== "set" || t.indices.length !== 1 || l === e.pending?.index || !e.pending ? !1 : (o[l] = o[e.pending.index], $n(e, r), !0);
	if (e.stage === "helm") return !["reroll", "skip"].includes(t.op) || !e.pending ? !1 : (t.op === "reroll" && (o[e.pending.index] = Zn(e, e.turn, e.pending.index, r)), $n(e, r), !0);
	if (e.stage === "dodecahedron") return t.op !== "keep" || !e.pending || ![0, 1].includes(t.choice ?? -1) ? !1 : (t.choice === 1 && ([o[e.pending.index], s[e.pending.other]] = [s[e.pending.other], o[e.pending.index]]), $n(e, r), !0);
	if (e.stage === "tome") return !e.pending || t.op !== "keep" || ![0, 1].includes(t.choice ?? -1) ? !1 : (o[e.pending.index] = t.choice === 0 ? e.pending.old : e.pending.rolled, e.processed.push(e.pending.index), e.pending = null, e.stage = "ability", !0);
	if (e.stage === "mantle") {
		let n = Math.min(Math.max(...Jn(e, 1 - e.turn)), o.length);
		return t.op !== "set" || t.indices.length !== n || t.faces.length !== n ? !1 : (t.indices.forEach((e, n) => {
			o[e] = t.faces[n];
		}), $n(e, r), !0);
	}
	if (e.stage === "blade") {
		if (t.op !== "group" || !e.pending || ![0, 1].includes(t.choice ?? -1)) return !1;
		let n = t.choice === 0 ? e.pending.group : s.map((e, t) => t).filter((t) => !e.pending.group.includes(t));
		for (let t of n) s[t] = Zn(e, 1 - e.turn, t, r);
		return $n(e, r), !0;
	}
	if (t.op === "skip") return [
		"harness",
		"cloak",
		"tome",
		"tools"
	].includes(c) || c === "gauntlet" && s.every((t, n) => e.hidden[1 - e.turn].includes(n) || o.includes(t)) ? ($n(e, r), !0) : !1;
	if (c === "mask") {
		if (t.op !== "set" || t.indices.length !== 2 || t.faces.length !== 2 || !t.faces.every((t) => s.some((n, r) => n === t && !e.hidden[1 - e.turn].includes(r)))) return !1;
		t.indices.forEach((e, n) => {
			o[e] = t.faces[n];
		});
	} else if (c === "horn") return t.op === "activate" && (er(e, r), !0);
	else if (c === "gauntlet") {
		if (t.op !== "activate" || t.other.length !== 1 || o.includes(s[u])) return !1;
		o.push(s.splice(u, 1)[0]);
		let n = e.hidden[1 - e.turn];
		e.hidden[1 - e.turn] = n.filter((e) => e !== u).map((e) => e > u ? e - 1 : e);
	} else if (c === "scepter") return t.op !== "reroll" || t.indices.length !== 1 ? !1 : (o[l] = Zn(e, e.turn, l, r), e.pending = {
		index: l,
		other: 0,
		old: o[l],
		rolled: o[l],
		group: []
	}, e.stage = "scepter", !0);
	else if (c === "helm") return t.op !== "swap" || t.indices.length !== 1 || t.other.length !== 1 ? !1 : ([o[l], s[u]] = [s[u], o[l]], e.pending = {
		index: l,
		other: u,
		old: o[l],
		rolled: o[l],
		group: []
	}, e.stage = "helm", !0);
	else if (c === "harness" || c === "cloak") {
		if (t.op !== "reroll" || t.indices.length > (c === "cloak" ? 2 : 6)) return !1;
		for (let n of t.indices) o[n] = Zn(e, e.turn, n, r);
		c === "cloak" && (e.hidden[e.turn] = [...t.indices]);
	} else if (c === "tome") {
		if (t.op !== "reroll" || t.indices.length !== 1 || e.processed.includes(l)) return !1;
		let n = o[l], i = Zn(e, e.turn, l, r);
		return o[l] = i, e.pending = {
			index: l,
			other: 0,
			old: n,
			rolled: i,
			group: []
		}, e.stage = "tome", !0;
	} else if (c === "dodecahedron") return t.op !== "reroll" || t.indices.length !== 1 || t.other.length !== 1 ? !1 : (o[l] = Zn(e, e.turn, l, r), s[u] = Zn(e, 1 - e.turn, u, r), e.pending = {
		index: l,
		other: u,
		old: o[l],
		rolled: s[u],
		group: []
	}, e.stage = "dodecahedron", !0);
	else if (c === "mantle") return t.op !== "activate" || t.indices.length !== 1 ? !1 : (s.push(o.splice(l, 1)[0]), e.stage = "mantle", !0);
	else if (c === "blade") {
		if (t.op !== "activate" || t.other.length === 0 || t.other.length >= s.length) return !1;
		if (e.pending = {
			index: 0,
			other: 0,
			old: "move",
			rolled: "move",
			group: [...t.other]
		}, e.stage = "blade", e.solo) {
			let n = T[r(6)], i = [
				"time",
				"morale",
				"health"
			].includes(n) ? t.other : s.map((e, t) => t).filter((e) => !t.other.includes(e));
			for (let t of i) s[t] = Zn(e, 1 - e.turn, t, r);
			$n(e, r);
		}
		return !0;
	} else if (c === "tools") {
		if (t.op !== "set" || t.indices.length > 3 || t.indices.length !== t.faces.length || new Set(t.faces).size !== t.faces.length) return !1;
		t.indices.forEach((e, n) => {
			o[e] = t.faces[n];
		});
	} else return !1;
	return $n(e, r), !0;
}
//#endregion
//#region src/games/vantage/personal.ts
var ir = /* @__PURE__ */ new Set([
	...Array.from({ length: 18 }, (e, t) => 1609 + t),
	1627,
	1628,
	1629,
	1630,
	1631,
	1632,
	1633,
	1634,
	1635,
	1636,
	1637,
	1638,
	1639,
	1640,
	1641,
	1643,
	1644,
	1645,
	1647,
	1648,
	1649,
	1650,
	1651,
	1652,
	1653,
	1654,
	1656,
	1658,
	1661,
	1663,
	1664,
	1665,
	1666,
	1667,
	1668,
	1669,
	1670,
	1671,
	1672,
	1673,
	1677,
	1678,
	1680,
	1682,
	1683,
	1684,
	1685,
	1686,
	1693,
	1695,
	1697,
	1699,
	1700,
	1702,
	1703,
	1704
]);
function ar(e) {
	let t = E[e], n = D["s" + e + ":0"];
	return ir.has(e) && !!n && !!t && !k(n.node).blocked;
}
//#endregion
//#region src/games/vantage/sentient-powers.ts
function or(e, t) {
	return [...e.grid.flatMap((e) => e ? [e] : []), ...e.supply.filter((e) => e.asylumAt === t)].filter((e) => cr(e.card) !== null);
}
var sr = [
	"wind",
	"circuit",
	"fire",
	"gold",
	"energy",
	"sinew",
	"metal",
	"sand",
	"stone",
	"leaf",
	"water",
	"wood"
];
function cr(e) {
	return e >= 1305 && e <= 1364 ? sr[Math.floor((e - 1305) / 5)] : null;
}
var lr = {
	1305: 1469,
	1306: 1019,
	1308: 1669,
	1309: 867,
	1315: 895,
	1316: 1294,
	1318: 1101,
	1319: 1086,
	1343: 1429,
	1353: 1665,
	1355: 1474,
	1358: 1681,
	1360: 884,
	1363: 993,
	1364: 1014
}, ur = {
	1307: 20,
	1340: 18,
	1350: 30,
	1351: 26,
	1352: 14,
	1357: 19
}, dr = {
	1308: 180,
	1353: 390,
	1358: 738
};
//#endregion
//#region src/games/vantage/quests.ts
function fr(e, t, n) {
	let r = e.personal[t.rid].personalFacts ??= [];
	r.includes(n) || r.push(n);
}
var pr = /* @__PURE__ */ new Set([
	12,
	13,
	42,
	76,
	77,
	78,
	510,
	513,
	...Array.from({ length: 52 }, (e, t) => 541 + t),
	597,
	600,
	791,
	795,
	799
]);
function mr(e) {
	return pr.has(e);
}
function hr(e, t, n) {
	let r = n?.allPlayers ? e.players : [t];
	return !n || r.some((t) => (n.anyOf ?? [n.id]).some((n) => [...e.personal[t.rid].completedActions ?? [], ...e.personal[t.rid].usedActions].includes(n))) === n.present;
}
function gr(e, t, n) {
	let r = e.personal[t.rid];
	return br(t, 1640) && r.location === 682 && !r.personalFacts?.includes(1640) && !r.questLocations[1640]?.includes(682) && [
		"m682:0",
		"e682:0",
		"h682:0",
		"o682:0",
		"t682:0"
	].includes(n);
}
function _r(e, t) {
	let n = e === "h682:0" ? 1 : ["m682:0", "e682:0"].includes(e) ? 0 : null;
	return n === null ? t : {
		...t,
		instructions: "",
		choices: [t.choices[n]]
	};
}
var vr = [
	465,
	190,
	191,
	464,
	185,
	186
], yr = {
	1631: 0,
	1634: 0,
	1635: 8,
	1638: 4,
	1642: 0,
	1643: 5,
	1659: 0,
	1669: 0,
	1673: 0,
	1680: 0,
	1695: 0,
	1702: 0
};
function br(e, t) {
	return e.supply.some((e) => e.card === t && !e.rotated);
}
function xr(e, t, n) {
	yr[n.card] !== void 0 && (n.tokens = yr[n.card], n.card === 1673 && (e.personal[t.rid].pathStations = []), e.personal[t.rid].questLocations[n.card] = n.card === 1643 ? [e.personal[t.rid].location] : [], e.personal[t.rid].questFlags = e.personal[t.rid].questFlags.filter((e) => e !== n.card));
}
function Sr(e, t, n) {
	let r = t.supply.find((e) => e.card === 1634 && !e.rotated);
	r && n === 448 && !e.personal[t.rid].questFlags.includes(1634) && !e.players.some((t) => (e.personal[t.rid].completedActions ?? []).some((e) => [
		"e448:0",
		"o448:0",
		"t448:0",
		"t448:0:afterCraft"
	].includes(e))) && (r.tokens = 1);
	let i = t.supply.find((e) => e.card === 1643 && !e.rotated);
	if (!i) return;
	let a = e.personal[t.rid].questLocations[1643] ??= [];
	a.includes(n) || (a.push(n), i.tokens = Math.max(0, (i.tokens ?? 5) - 1));
}
function Cr(e, t, n) {
	let r = e.personal[t.rid], i = t.supply.find((e) => e.card === n), a = (e) => [...t.grid, ...t.reserve].some((t) => t?.card === e), o = [...t.grid.flatMap((e) => e ? [e] : []), ...t.reserve], s = [.../* @__PURE__ */ new Set([...r.acquiredCards ?? [], ...o.map((e) => e.card)])], c = r.personalFacts ?? [], l = [...r.completedActions ?? [], ...r.usedActions];
	switch (n) {
		case 1609: return [r.location, ...r.visited].some(fn);
		case 1610: return c.includes(1610);
		case 1611: return c.includes(1611);
		case 1612: return s.some((e) => E[e].group === "flora");
		case 1613: return c.includes(1613) || [r.location, ...r.visited].some(mr);
		case 1614: return c.includes(1614) || s.some((e) => E[e].group === "animal" && !P(e, "wildAnimal"));
		case 1615: return c.includes(1615) || !!r.towerTop;
		case 1616: return c.includes(1616);
		case 1617: return s.some((e) => e >= 1460 && e <= 1516);
		case 1618: return c.includes(1618);
		case 1619: return c.includes(1619);
		case 1620: return c.includes(1620);
		case 1621: return o.some((e) => E[e.card].group === "vehicle");
		case 1622: return c.includes(1622) || pn(r.location) || r.visited.some(pn);
		case 1623: return c.includes(1623);
		case 1624: return o.some((e) => Fe(e.card));
		case 1625: return c.includes(1625);
		case 1626: return t.character >= 1447 && t.character <= 1452;
		case 1627: return r.location === 146 && (a(834) || a(835));
		case 1628: return c.includes(1628);
		case 1629: return r.location === 563;
		case 1630: return l.includes("m287:0");
		case 1632: return l.includes("h289:0");
		case 1633: return l.includes("h498:0");
		case 1634: return r.location === 672 && i?.tokens === 1;
		case 1636: return r.location === 519 && c.includes(1636);
		case 1639: return l.includes("h652:0");
		case 1640: return c.includes(1640);
		case 1644: return c.includes(1644);
		case 1647: return l.includes("o622:0");
		case 1649: return l.some((e) => /^HUNT\b/.test(D[e]?.label ?? ""));
		case 1648: return r.location === 789 && a(953);
		case 1650: return a(804) || a(805);
		case 1651: return r.location === 297;
		case 1653: return l.includes("o176:0");
		case 1656: return t.character >= 1447 && t.character <= 1452;
		case 1658: return o.some((e) => e.card === 1012 && e.acquiredAt !== void 0 && e.acquiredAt !== r.location);
		case 1661: return r.location === 330 && o.some((e) => cr(e.card) === "gold");
		case 1663: return a(1009) && a(1011);
		case 1665: return r.location === 710 && a(1353);
		case 1666: return r.location === 78;
		case 1667: return e.players.some((t) => [...e.personal[t.rid].completedActions ?? [], ...e.personal[t.rid].usedActions].some((e) => [
			"h465:0",
			"o465:0",
			"o97:0"
		].includes(e)));
		case 1668: return a(827) || a(1122);
		case 1670: return r.location === 96 || r.visited.includes(96) || s.some((e) => e === 807 || e === 1110);
		case 1671: return l.includes("h87:0");
		case 1672: return l.includes("l701:0");
		case 1673: return r.location === 411;
		case 1677: return l.includes("m129:0");
		case 1678: return r.location === 229;
		case 1683: return a(1371);
		case 1686: return a(1035);
		case 1693: return c.includes(1693);
		case 1699: return r.location === 516 && !r.questFlags.includes(1699);
		case 1700: return r.location === 218;
		case 1703: return r.location === 310;
		case 1704: return a(991);
		case 1631: return (i?.tokens ?? 0) >= 4 && r.questLocations[n]?.at(-1) === r.location;
		case 1635: return (i?.tokens ?? 0) > 0 && r.questFlags.includes(n);
		case 1637: return o.some((e) => e.card === 977 && e.acquiredAt === 589) && On(r.location) !== null;
		case 1641: return r.location === 175 && a(1158);
		case 1645: return r.location === 588 && r.usedActions.includes("l1645:0") && r.usedActions.includes("e1645:0");
		case 1652: return a(1349);
		case 1654: return On(r.location) !== null && o.some((e) => e.card === 1160 && e.acquiredAt === 563);
		case 1664: return r.location === 499 && o.some((e) => P(e.card, "food"));
		case 1669: return (i?.tokens ?? 0) >= 3;
		case 1697: return r.location === 592 && t.character !== 1453;
		case 1638: return (i?.tokens ?? 0) > 0 && r.location === 771;
		case 1643: return i?.tokens === 0 && r.location === 751;
		case 1642: return (i?.tokens ?? 0) >= 3;
		case 1659: return (i?.tokens ?? 0) >= 9 && r.location === 760;
		case 1702: return (i?.tokens ?? 0) >= 4 && r.location === 695;
		case 1680: return (i?.tokens ?? 0) >= 2 && r.location === 785;
		case 1682: return r.location === 570 && t.coins >= Re(e, t, 20);
		case 1684: return r.location === 578 && C.every((e) => t.skills[e] >= 1);
		case 1685: return a(989);
		case 1695: return (i?.tokens ?? 0) >= 3;
		default: return !0;
	}
}
function wr(e, t) {
	return t.supply.flatMap((n) => {
		if (n.tokens === void 0 || n.rotated || yr[n.card] === void 0) return [];
		let r = n.card === 1631 ? "underwater" : n.card === 1643 ? "journey" : [1635, 1638].includes(n.card) ? "timer" : "counter";
		return [{
			card: n.card,
			tokens: n.tokens,
			kind: r,
			canRecord: n.card === 1631 && n.tokens < 4 && !(e.personal[t.rid].questLocations[1631] ?? []).includes(e.personal[t.rid].location)
		}];
	});
}
function Tr(e, t, n) {
	let r = e.personal[t.rid].location;
	return n === "m1702:0" ? r === 387 && br(t, 1702) : n === "o1642:0" ? br(t, 1642) && !e.personal[t.rid].usedLocations.includes(r) && !(e.personal[t.rid].questLocations[1642] ?? []).includes(r) : /^[elo]1680:/.test(n) ? r === 785 : n === "d515:0" ? [...t.grid, ...t.reserve].some((e) => e?.card === 1695 && e.rotated) : n === "d515:2" ? br(t, 1699) : n === "m1646:0" ? r === 518 && [...t.grid, ...t.reserve].filter((e) => e && e.card >= 1305 && e.card <= 1364).length >= 2 : n === "h1655:0" ? r === 650 : n === "e1657:0" ? r === 690 && [...t.grid, ...t.reserve].some((e) => e?.card === 1369) : n === "m1657:0" ? r === 690 : n === "h1662:0" ? r === 605 && [...t.grid, ...t.reserve].some((e) => e && E[e.card].group === "flora") : n === "o1659:0" || n === "o1694:0" ? r === 760 : n === "o1674:0" ? r === 128 : n === "m1675:0" ? r === 438 : n === "m1676:0" ? r === 274 : n === "l1645:0" || n === "e1645:0" ? r === 588 : n !== "h1669:0" || br(t, 1669) && vr.includes(r) && !(e.personal[t.rid].questLocations[1669] ?? []).includes(r);
}
//#endregion
//#region src/games/vantage/card-rules.ts
function Er(e) {
	return E[e]?.group === "structure" || E[e]?.group === "tree";
}
function Dr(e) {
	return e >= 1385 && e <= 1396;
}
function Or(e) {
	return e.grid.some((e) => e && [942, 1117].includes(e.card));
}
function kr(e, t, n = !1) {
	return N(e.character, t) || e.character === 1453 && ["heat", "cold"].includes(t) ? !0 : e.grid.some((e) => e && (e.card === 984 || n && e.card === 1033 || t === "cold" && [
		922,
		928,
		929,
		962,
		971,
		1040,
		1110,
		1112
	].includes(e.card) || t === "heat" && [
		965,
		966,
		967
	].includes(e.card) || t === "hypoxia" && [
		964,
		1013,
		1110
	].includes(e.card)));
}
function Ar(e) {
	return e.grid.some((e) => e && [
		930,
		939,
		983,
		1018,
		1033
	].includes(e.card));
}
function jr(e) {
	return e.grid.reduce((e, t) => e + (t ? E[t.card].reserveCapacity ?? 0 : 0), 0);
}
//#endregion
//#region src/games/vantage/arrivals.ts
var Mr = {};
function L(e, t) {
	for (let n of e) (Mr[n] ??= []).push(t);
}
L([
	16,
	86,
	125,
	126,
	161,
	164,
	256,
	257,
	258,
	261,
	263,
	266,
	267,
	268,
	271,
	273,
	281,
	347,
	348,
	357,
	361,
	379,
	440,
	487,
	488,
	489,
	515,
	562,
	571,
	579,
	736,
	742,
	747,
	748,
	754,
	759,
	760,
	774
], {
	kind: "damage",
	value: "heat"
}), L([
	82,
	206,
	211,
	214,
	217,
	220,
	221,
	224,
	290,
	291,
	292,
	293,
	296,
	297,
	298,
	299,
	595,
	601,
	602,
	603,
	604,
	605,
	606,
	607,
	608,
	609,
	611,
	613,
	614,
	617,
	618,
	621,
	622,
	623,
	627,
	628
], {
	kind: "damage",
	value: "cold"
}), L([
	8,
	9,
	10,
	11,
	15,
	...Array.from({ length: 12 }, (e, t) => 64 + t),
	92,
	97,
	176,
	194,
	582,
	...Array.from({ length: 30 }, (e, t) => 631 + t)
], {
	kind: "damage",
	value: "hypoxia"
}), L([
	17,
	57,
	300,
	426,
	465,
	599
], {
	kind: "stat",
	value: "health"
}), L([49], {
	kind: "stat",
	value: "morale"
}), L([
	44,
	79,
	84,
	87
], {
	kind: "payment",
	value: "health",
	skills: ["move"]
}), L([85], {
	kind: "payment",
	value: "health",
	skills: ["overpower"]
}), L([94], {
	kind: "payment",
	value: "time",
	skills: ["engage", "look"]
}), L([96], {
	kind: "payment",
	value: "health",
	skills: ["move"],
	first: !0
}), L([128], {
	kind: "payment",
	value: "health",
	skills: ["help"]
}), L([799], {
	kind: "payment",
	value: "health",
	skills: ["overpower"]
}), L([312], {
	kind: "payment",
	value: "health",
	skills: ["move"],
	gainCard: 1460
}), L([325], {
	kind: "secret",
	value: "325",
	requiredCards: [817, 818]
}), L([610], {
	kind: "secret",
	value: "610",
	requiredCards: [810]
}), L([708], {
	kind: "secret",
	value: "708",
	requiredCards: [1346]
}), L([168], {
	kind: "damage",
	value: "heat",
	first: !0,
	destinations: [167, 169]
}), L([182], {
	kind: "stat",
	value: "morale",
	first: !0
}), L([242], {
	kind: "stat",
	value: "morale",
	first: !0,
	destinations: [
		237,
		241,
		243
	]
}), L([369], {
	kind: "skill",
	value: "",
	first: !0,
	destinations: [
		350,
		370,
		670
	]
}), L([393], {
	kind: "reserve",
	value: "",
	first: !0,
	destinations: [392]
}), L([431], {
	kind: "rollCenter",
	value: "",
	first: !0,
	destinations: [476]
}), L([439], {
	kind: "stat",
	value: "time",
	ignoresTime: !0
}), L([446], {
	kind: "stat",
	value: "coin",
	first: !0,
	destinations: [269, 335]
}), L([463], {
	kind: "damage",
	value: "hypoxia",
	first: !0,
	destinations: [180, 284]
}), L([498], {
	kind: "stat",
	value: "health",
	first: !0,
	destinations: [
		270,
		497,
		499
	]
}), L([616], {
	kind: "damage",
	value: "cold",
	first: !0,
	destinations: [401, 617]
}), L([657], {
	kind: "stat",
	value: "boost",
	first: !0,
	destinations: [651, 656]
}), L([729], {
	kind: "rollPool",
	value: "",
	first: !0,
	destinations: [
		413,
		723,
		728
	]
}), L([752], {
	kind: "stat",
	value: "time",
	first: !0,
	destinations: [746, 758]
});
function Nr(e, t) {
	return (Mr[e] ?? []).filter((e) => t || !e.first);
}
function Pr(e) {
	return !!Mr[e]?.some((e) => e.ignoresTime);
}
function Fr(e) {
	return [
		"time",
		"morale",
		"health"
	].includes(e);
}
//#endregion
//#region src/games/vantage/slot-rules.ts
var Ir = {
	援助: "AID",
	打碎: "SMASH",
	说服: "PERSUADE",
	建立: "BUILD",
	窃取: "PILFER",
	强行: "FORCE",
	开凿: "TUNNEL",
	探访: "ACCESS",
	躲闪: "DODGE",
	攀登: "SCALE",
	协助: "ASSIST",
	"挤/压": "SQUEEZE",
	隐藏: "HIDE",
	询问: "ASK",
	"挑/撬": "PICK",
	跋涉: "TREK",
	扫视: "SCAN",
	偷取: "STEAL",
	修复: "REPAIR",
	劈砍: "CLEAVE",
	组装: "ASSEMBLE",
	威吓: "INTIMIDATE",
	粉碎: "SHATTER",
	倾听: "LISTEN",
	翻译: "TRANSLATE",
	拆卸: "DISMANTLE",
	升级: "UPGRADE",
	制作: "CRAFT",
	攀爬: "CLIMB",
	下降: "DESCEND",
	吹嘘: "BOAST",
	娱乐: "ENTERTAIN",
	击杀: "SLAY",
	攻击: "ATTACK",
	战斗: "FIGHT",
	狩猎: "HUNT",
	解脱: "RELIEVE",
	破解: "HACK",
	挖掘: "DIG",
	诱哄: "COAX",
	模仿: "MIMIC",
	喂养: "FEED",
	救助: "RESCUE",
	激活: "ACTIVATE",
	制服: "SUBDUE",
	瞄准: "TARGET",
	捕获: "CATCH",
	捕鱼: "FISH",
	进入: "ENTER",
	开辟: "TRAILBLAZE",
	劫持: "HIJACK",
	"切/砍": "CUT",
	"追/赶": "CHASE",
	设陷: "TRAP",
	玩: "PLAY",
	对决: "DUEL",
	检视: "INSPECT",
	解决: "SOLVE",
	徒步: "HIKE",
	艰行: "TRUDGE",
	滑: "SLIDE",
	学习: "LEARN",
	扒窃: "PICKPOCKET",
	威胁: "COERCE",
	寻找: "FORAGE",
	采摘: "PLUCK",
	冲: "DASH",
	避开: "EVADE",
	潜行: "SNEAK",
	引诱: "LURE",
	放松: "RELAX",
	调情: "FLIRT",
	治愈: "HEAL",
	"跳/跃": "LEAP",
	驾驶: "STEER",
	乘坐: "RIDE",
	探索: "EXPLORE",
	导航: "NAVIGATE",
	下潜: "DIVE",
	游: "SWIM",
	涉水: "WADE",
	极速: "SPEED",
	击晕: "STUN",
	解除: "DISARM",
	搜寻: "SCAVENGE",
	让步: "YIELD",
	致敬: "HONOR",
	跟随: "FOLLOW",
	取出: "EXTRACT",
	保卫: "DEFEND",
	引导: "GUIDE",
	燃烧: "BURN",
	收集: "GATHER",
	分心: "DISTRACT",
	交谈: "TALK",
	交易: "TRADE",
	检查: "EXAMINE",
	净化: "PURIFY",
	监视: "SPY",
	酿制: "BREW",
	低语: "WHISPER",
	提供: "OFFER",
	称赞: "PRAISE",
	呼叫: "HAIL",
	抽取: "SIPHON",
	研究: "STUDY",
	观察: "OBSERVE",
	搜刮: "LOOT",
	创造: "CREATE",
	发送: "TRANSMIT",
	沟通: "COMMUNE",
	照料: "NURTURE",
	练习: "PRACTICE",
	劫掠: "RAID",
	招募: "ENLIST",
	提炼: "REFINE",
	跳舞: "DANCE",
	抢劫: "ROB",
	平衡: "BALANCE",
	"推/按": "PUSH",
	搜索: "SEARCH",
	征服: "CONQUER",
	打破: "BREAK"
};
function Lr(e) {
	return e.split("|").flatMap((e) => Ir[e.trim()] ? [Ir[e.trim()]] : []);
}
function Rr(e, t) {
	return t === "zh" ? e : Lr(e).join(" / ");
}
var zr = {
	935: "metal",
	997: "wood",
	1006: "metal",
	1092: "sinew",
	1093: "metal",
	1094: "wood",
	1095: "stone",
	1096: "leaf",
	1097: "energy",
	1098: "circuit",
	1099: "gold",
	1100: "water",
	1101: "fire",
	1102: "wind",
	1141: "circuit",
	1179: "stone",
	1184: "metal",
	1368: "stone",
	1372: "gold",
	1374: "wood",
	1375: "metal",
	1378: "sinew",
	1380: "water",
	1381: "sand",
	1382: "leaf",
	1384: "energy",
	1707: "stone"
}, Br = [
	"wind",
	"circuit",
	"fire",
	"gold",
	"energy",
	"sinew",
	"metal",
	"sand",
	"stone",
	"leaf",
	"water",
	"wood"
];
function Vr(e, t) {
	if (t.kind === "element_specific") return e >= 1305 && e <= 1364 ? Br[Math.floor((e - 1305) / 5)] : zr[e];
}
function Hr(e, t, n, r, i, a, o) {
	if (e === 987 && a?.grid.some((e) => e?.card === 987 && e.rotated) || n.untyped && (t.skill || t.kind === "ability" || t.kind === "element_specific") || t.face && t.face !== r || t.skill && t.skill !== n.skill && !(e === 983 && t.index === 0 && a ? [
		...a.grid,
		...a.reserve,
		...a.supply
	].filter((e) => e && E[e.card]?.traits?.includes("crystal")) : []).some((e) => e && E[e.card].slots.some((e) => e.skill === n.skill))) return !1;
	if (t.kind === "any") return !0;
	if (t.kind === "specific_result") return !!t.face;
	if (t.kind === "skill_type") return t.skill === n.skill;
	if (t.kind === "ability") {
		let e = D[n.id];
		if (!e || ee(e) !== n.skill) return !1;
		let r = e.label.match(/\b[A-Z][A-Z-]+\b/g) ?? [];
		return Lr(t.ability).some((e) => r.includes(e));
	}
	if (t.kind === "element_specific") {
		let r = Vr(e, t);
		return !!r && ye(n.id) && _e(n.source, o).includes(r);
	}
	return t.kind === "terrain_specific" && i;
}
//#endregion
//#region src/games/vantage/item-powers.ts
function Ur(e) {
	return e.grid.some((e) => e?.card === 1232 && e.boost > 0);
}
function Wr(e, t, n, r = !1) {
	return (Ur(e) || r) && E[n]?.group === "location" && ye(t);
}
function Gr(e, t, n) {
	return e !== 1232 || t !== 1 || n === 0;
}
//#endregion
//#region src/games/vantage/animal-powers.ts
var Kr = Object.fromEntries(Object.entries({
	scout: {
		cards: [
			805,
			1113,
			1115,
			1118,
			1121,
			1125
		],
		cost: 1,
		zh: "侦察：查看一个相邻的列出地点，或者查看所有相邻未列出地点的移动费用。",
		en: "Scout: view one adjacent listed location, or the move costs of all adjacent unlisted locations."
	},
	land: {
		cards: [809, 1111],
		cost: 2,
		zh: "乘坐：移动到一个相邻的陆地地点。",
		en: "Ride: move to an adjacent land location."
	},
	tunnel: {
		cards: [833],
		cost: 2,
		zh: "乘坐：移动到一个相邻地点，或者地下移动至043、044、045、046、047或048。",
		en: "Ride: move to an adjacent location, or travel underground to 043, 044, 045, 046, 047, or 048."
	},
	waterRide: {
		cards: [1134],
		cost: 2,
		zh: "乘坐：移动到一个相邻的陆地、海洋或水下地点。",
		en: "Ride: move to an adjacent land, ocean, or underwater location."
	},
	fly: {
		cards: [
			1108,
			1110,
			1127
		],
		cost: 2,
		zh: "乘坐：将当前地区与《万境之书》第48页配对，然后前往对应的天空地点。",
		en: "Ride: match your current region to its sky location on page 48 of the Book of Vantages, then go there."
	},
	health: {
		cards: [
			811,
			842,
			1114,
			1116,
			1123,
			1126,
			1131,
			1222
		],
		cost: 2,
		zh: "保护：忽略所有未放置骰子上的生命结果，将这些骰子放在中央区。",
		en: "Protect: ignore health results on all unplaced dice, placing those dice in the center."
	},
	morale: {
		cards: [
			818,
			1119,
			1129,
			1130,
			1133
		],
		cost: 2,
		zh: "安慰：忽略所有未放置骰子上的士气结果，将这些骰子放在中央区。",
		en: "Comfort: ignore morale results on all unplaced dice, placing those dice in the center."
	},
	charm: {
		cards: [
			830,
			839,
			844,
			849,
			852,
			1112,
			1117,
			1122
		],
		cost: 1,
		zh: "魅惑：与智慧生物或动物互动时，重掷至多2枚挑战骰。",
		en: "Charm: when interacting with a sentient or animal, reroll up to 2 challenge dice."
	},
	fetch: {
		cards: [
			835,
			1107,
			1124,
			1132
		],
		cost: 1,
		zh: "取物：将内部地点上的一个获取行动费用减少至0点。",
		en: "Fetch: reduce the cost of one take action at an interior location to 0."
	},
	plunder: {
		cards: [1120],
		cost: 1,
		zh: "掠夺：位于有宝箱的地点，获得宝箱中的1件物品，参阅《获取》故事书中的选项。",
		en: "Plunder: at a location with a treasure chest, gain one item from it, referring to the options in the Take storybook."
	},
	cold: {
		cards: [815],
		cost: 1,
		zh: "温暖：本回合忽略所有寒冷伤害。",
		en: "Warmth: ignore all cold damage this turn."
	},
	hypoxia: {
		cards: [1109],
		cost: 1,
		zh: "供氧：本回合忽略所有缺氧伤害。",
		en: "Oxygen: ignore all hypoxia damage this turn."
	},
	revive: {
		cards: [
			1218,
			1219,
			1220
		],
		cost: 2,
		zh: "复活：在承受所掷挑战骰的结果之前，将至多3枚已掷出的骰子与中央区的骰子交换。",
		en: "Revive: before suffering a rolled challenge die result, swap up to 3 rolled dice with dice in the center."
	}
}).flatMap(([e, t]) => t.cards.map((n) => [n, {
	kind: e,
	cost: t.cost
}])));
function qr(e) {
	return [...new Set(Object.values(E[e].exits).flatMap((e) => e.destination === null ? [] : [e.destination]))];
}
function Jr(e) {
	return Yr(e).map((e) => e.id);
}
function Yr(e) {
	return O(e, "depart").filter((e) => e.hasCost && !e.sequenceOnly);
}
function Xr(e, t) {
	return [.../* @__PURE__ */ new Set([...qr(t), ...Kr[e]?.kind === "tunnel" ? [
		43,
		44,
		45,
		46,
		47,
		48
	] : []])].filter((e) => e !== t);
}
function Zr(e) {
	return [...Qr[e] ?? []];
}
var Qr = {
	91: [1020, 1036],
	102: [1169, 1207],
	126: [1164, 895],
	181: [1021],
	253: [886, 1160],
	270: [924, 1165],
	358: [1036],
	367: [924, 1164],
	384: [1214, 1165],
	416: [1193, 1162],
	432: [1043, 1162],
	448: [977, 908],
	457: [942, 1165],
	471: [857],
	485: [1089, 1162],
	488: [983, 1162],
	494: [1083, 1165],
	502: [1036, 1164],
	602: [1090, 1165],
	653: [1161, 885],
	675: [973],
	756: [1189, 1162]
};
//#endregion
//#region src/games/vantage/center-dice.ts
function $r(e) {
	return Array.from({ length: e.penaltyDice }, (t, n) => e.penaltyFaces?.[n] ?? null);
}
function ei(e, ...t) {
	e.penaltyFaces = [...$r(e), ...t], e.penaltyDice += t.length;
}
function ti(e, t) {
	e.penaltyFaces = $r(e).slice(t), e.penaltyDice -= t;
}
//#endregion
//#region src/games/vantage/power-travel.ts
var ni = {
	freeOverpower: void 0,
	jumpAfterDeparture: void 0,
	turn: 0,
	phase: "action",
	challenge: null,
	passage: null,
	continuation: "no",
	locationContinuation: !1,
	skillResult: null,
	lastSkirmWon: null,
	storyTest: null,
	sentientTrial: null,
	skirm: null,
	miniGame: null,
	puzzle: null,
	copied: void 0,
	trapTest: null,
	storySkirmGain: void 0,
	storyInvestment: void 0,
	storyInvestmentReturn: void 0,
	freeReading: !1,
	restrictedActions: [],
	restrictedBooks: [],
	restrictedDirections: [],
	restrictedVerbs: [],
	restrictedSkill: null,
	restrictedExclude: void 0,
	restrictedExcludes: [],
	restrictedWater: !1,
	nextActionMaxCost: void 0,
	nextActionDiscount: 0,
	previewedOutcome: null,
	abilityDice: [],
	setFaces: [],
	stopForced: [],
	pearlDefense: void 0,
	nextBonus: void 0,
	foresight: [],
	foresightFromPool: void 0,
	challengeRewardFace: null,
	runeSkill: null,
	runeFaces: [],
	arrivals: [],
	arrivalResume: null,
	arrivalStack: [],
	arrivalSecret: !1,
	arrivalReader: null,
	arrivalEndsTurn: !1,
	crisisResume: null
};
function ri(e) {
	return (e.powerDiceChoice?.faces.length ?? 0) + [e, ...e.powerTravel ?? []].reduce((e, t) => e + (t.foresight?.length ?? 0) + (t.challenge?.foresight?.length ?? 0) + (t.challenge?.dice.filter((e) => e !== null).length ?? 0), 0);
}
function ii(e, t) {
	let n = Object.fromEntries(Object.keys(ni).map((t) => [t, e[t]]));
	(e.arrivalSecret ? e.arrivalReader : e.players[e.turn].rid) !== t && (n.permissions = {
		slotPermission: e.slotPermission,
		impactPermission: e.impactPermission,
		followConsent: e.followConsent
	}, e.slotPermission = [], e.impactPermission = [], e.followConsent = []), (e.powerTravel ??= []).push(n), Object.assign(e, structuredClone(ni)), e.turn = e.players.findIndex((e) => e.rid === t);
}
function ai(e) {
	let t = e.powerTravel?.pop();
	if (!t) return !1;
	let { permissions: n, ...r } = t;
	return Object.assign(e, r, n), !0;
}
var oi = {
	starts: {
		168: {
			first: 1541,
			curse: 1394
		},
		242: {
			first: 1549,
			curse: 1395
		},
		369: {
			first: 1569,
			curse: 1386
		},
		393: {
			first: 1573,
			curse: 1391
		},
		431: {
			first: 1533,
			curse: 1388
		},
		446: {
			first: 1545,
			curse: 1393
		},
		463: {
			first: 1529,
			curse: 1387
		},
		498: {
			first: 1553,
			curse: 1392
		},
		616: {
			first: 1537,
			curse: 1396
		},
		657: {
			first: 1565,
			curse: 1385
		},
		729: {
			first: 1561,
			curse: 1389
		},
		752: {
			first: 1557,
			curse: 1390
		}
	},
	parts: {
		1529: {
			weapon: 1195,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1387,
			next: "none"
		},
		1530: {
			weapon: 1195,
			refresh: "all",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1531: {
			weapon: 1195,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "discount"
		},
		1532: {
			weapon: 1195,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "reroll"
		},
		1533: {
			weapon: 1196,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 1,
			curse: 0,
			next: "none"
		},
		1534: {
			weapon: 1196,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "reroll"
		},
		1535: {
			weapon: 1196,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1388,
			next: "none"
		},
		1536: {
			weapon: 1196,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "discount"
		},
		1537: {
			weapon: 1197,
			refresh: "all",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1538: {
			weapon: 1197,
			refresh: "center",
			afterOnly: !1,
			boost: 2,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1539: {
			weapon: 1197,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "ignoreHealth"
		},
		1540: {
			weapon: 1197,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1396,
			next: "none"
		},
		1541: {
			weapon: 1198,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "reroll"
		},
		1542: {
			weapon: 1198,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 1,
			curse: 0,
			next: "none"
		},
		1543: {
			weapon: 1198,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1394,
			next: "none"
		},
		1544: {
			weapon: 1198,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "ignoreHealth"
		},
		1545: {
			weapon: 1199,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "reroll"
		},
		1546: {
			weapon: 1199,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 1,
			curse: 0,
			next: "none"
		},
		1547: {
			weapon: 1199,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1393,
			next: "none"
		},
		1548: {
			weapon: 1199,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "ignoreHealth"
		},
		1549: {
			weapon: 1200,
			refresh: "all",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1550: {
			weapon: 1200,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "discount"
		},
		1551: {
			weapon: 1200,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1395,
			next: "none"
		},
		1552: {
			weapon: 1200,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "reroll"
		},
		1553: {
			weapon: 1201,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "ignoreHealth"
		},
		1554: {
			weapon: 1201,
			refresh: "all",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1555: {
			weapon: 1201,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "discount"
		},
		1556: {
			weapon: 1201,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1392,
			next: "none"
		},
		1557: {
			weapon: 1202,
			refresh: "center",
			afterOnly: !1,
			boost: 2,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1558: {
			weapon: 1202,
			refresh: "none",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "ignoreHealth"
		},
		1559: {
			weapon: 1202,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1390,
			next: "none"
		},
		1560: {
			weapon: 1202,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 1,
			curse: 0,
			next: "none"
		},
		1561: {
			weapon: 1203,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "discount"
		},
		1562: {
			weapon: 1203,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1389,
			next: "none"
		},
		1563: {
			weapon: 1203,
			refresh: "center",
			afterOnly: !1,
			boost: 2,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1564: {
			weapon: 1203,
			refresh: "all",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1565: {
			weapon: 1204,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "reroll"
		},
		1566: {
			weapon: 1204,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1385,
			next: "none"
		},
		1567: {
			weapon: 1204,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "discount"
		},
		1568: {
			weapon: 1204,
			refresh: "all",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1569: {
			weapon: 1205,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 1,
			curse: 0,
			next: "none"
		},
		1570: {
			weapon: 1205,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "reroll"
		},
		1571: {
			weapon: 1205,
			refresh: "center",
			afterOnly: !1,
			boost: 2,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1572: {
			weapon: 1205,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1386,
			next: "none"
		},
		1573: {
			weapon: 1206,
			refresh: "all",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1574: {
			weapon: 1206,
			refresh: "center",
			afterOnly: !1,
			boost: 2,
			morale: 0,
			curse: 0,
			next: "none"
		},
		1575: {
			weapon: 1206,
			refresh: "center",
			afterOnly: !0,
			boost: 0,
			morale: 0,
			curse: 0,
			next: "ignoreHealth"
		},
		1576: {
			weapon: 1206,
			refresh: "center",
			afterOnly: !1,
			boost: 0,
			morale: 0,
			curse: 1391,
			next: "none"
		}
	}
}, si = oi.starts, ci = oi.parts, li = /* @__PURE__ */ new Set([
	"ropeSkill",
	"peekInterior",
	"peekCost",
	"regionView",
	"lessonBenefit",
	"signalView",
	"spiralSpell",
	"referencePage",
	"sandboat",
	"abilitySkill"
]);
function ui(e) {
	return li.has(e);
}
var di = {
	1037: 7,
	1154: 8,
	1251: 9,
	1252: 10,
	1254: 11,
	1255: 12,
	1256: 13,
	1257: 14,
	1258: 15,
	1259: 16,
	1260: 17,
	1261: 18,
	1262: 19,
	1263: 20,
	1264: 21,
	1043: 22,
	1044: 23,
	1045: 24,
	1191: 25,
	1192: 26,
	1193: 27,
	1214: 28,
	1215: 29,
	1223: 30
}, fi = Object.fromEntries([
	...Array.from({ length: 57 }, (e, t) => [1460 + t, {
		cost: 2,
		ops: ["abilitySkill"]
	}]),
	...[
		901,
		902,
		903,
		905
	].map((e) => [e, {
		cost: 1,
		ops: ["ropeSkill"]
	}]),
	[935, {
		cost: 1,
		ops: ["peekInterior", "peekCost"]
	}],
	[940, {
		cost: 1,
		ops: ["regionView"]
	}],
	[941, {
		cost: 1,
		ops: ["regionView"]
	}],
	[953, {
		cost: 2,
		ops: ["lessonBenefit"]
	}],
	[961, {
		cost: 1,
		ops: ["signalView"]
	}],
	[981, {
		cost: 1,
		ops: ["spiralSpell"]
	}],
	[1022, {
		cost: 3,
		ops: ["sandboat"]
	}],
	...Object.keys(di).map((e) => [Number(e), {
		cost: 1,
		ops: ["referencePage"]
	}])
]);
function pi(e, t) {
	return no(e, t.rid, !0).flatMap((n) => D[n.id] && /^(ENTER|ACCESS)\b/.test(D[n.id].label) ? He(n.id, e.personal[t.rid].dungeonOrigin).filter(mr).map((e) => ({
		action: n.id,
		targetCard: e
	})) : []);
}
function mi(e, t) {
	let n = e.personal[t.rid];
	return [.../* @__PURE__ */ new Set([...Object.values(E[n.location]?.exits ?? {}).flatMap((e) => e.destination === null ? [] : [e.destination]), ...Yr(n.location).flatMap((e) => Ve(e.id, n.dungeonOrigin))])].filter((e) => e !== n.location);
}
function hi(e, t) {
	return t === 1022 && e.grid.some((e) => e && E[e.card].group === "animal") ? 1 : fi[t]?.cost ?? 0;
}
function gi(e, t, n) {
	let r = fi[n.card], i = t.grid.find((e) => e?.card === n.card), a = hi(t, n.card), o = e.personal[t.rid];
	if (!i || !ui(n.op) || !r?.ops.includes(n.op) || i.boost < a || [
		"launch",
		"landing",
		"experience",
		"done"
	].includes(e.phase)) return null;
	let s = (t) => (n) => {
		n.spendBoost(e, i, a), t(n);
	};
	if (n.op === "abilitySkill") {
		let e = E[n.card].slots[0]?.skill;
		return e ? s((n) => n.gainSkill(t, e, 1)) : null;
	}
	if (n.op === "ropeSkill") return n.skill && ["move", "take"].includes(n.skill) ? s((e) => e.gainSkill(t, n.skill, 1)) : null;
	if (n.op === "peekCost") return !mr(o.location) || !n.action || o.revealedCosts.includes(n.action) || !no(e, t.rid, !0).some((e) => e.id === n.action) ? null : s(() => {
		o.revealedCosts.push(n.action);
	});
	if (n.op === "peekInterior") return mr(o.location) || !pi(e, t).some((e) => e.action === n.action && e.targetCard === n.targetCard) ? null : s(() => {
		o.scouted.includes(n.targetCard) || o.scouted.push(n.targetCard);
	});
	if (n.op === "regionView" || n.op === "signalView") {
		let r = n.card === 941 ? An(o.location) : kn(o.location);
		return r === null || n.op === "signalView" && (mr(o.location) || !n.condition) ? null : s((i) => {
			for (let a of n.op === "signalView" ? e.players : [t]) {
				let t = e.personal[a.rid], o = n.card === 941 ? t.scouted : t.bookPages;
				o.includes(r) || o.push(r), i.addBoost(a.grid[4], 1);
			}
			n.card !== 941 && !e.milestones.vantages.includes(r) && e.milestones.vantages.push(r);
		});
	}
	if (n.op === "lessonBenefit") return n.targetCard !== 1424 && n.face !== "morale" ? null : s((r) => {
		n.targetCard === 1424 ? r.pending(e, 1424, t) : r.gainStat(e, t, "morale", 1);
	});
	if (n.op === "spiralSpell") {
		let r = t.grid.find((e) => e?.card === n.sourceCard), a = t.grid.indexOf(i), o = r ? t.grid.indexOf(r) : -1;
		if (!r || r === i || r.boost < 1) return null;
		let c = Math.floor(a / 3) === Math.floor(o / 3) ? 1380 : a % 3 == o % 3 ? 1383 : 1367;
		return s((n) => {
			n.spendBoost(e, r, 1), n.pending(e, c, t);
		});
	}
	if (n.op === "referencePage") {
		let e = di[i.card];
		return e ? s(() => {
			o.bookPages.includes(e) || (o.bookPages.push(e), (o.temporaryBookPages ??= []).push(e));
		}) : null;
	}
	if (n.op === "sandboat") {
		let r = n.targetCard;
		return r === void 0 || !mi(e, t).includes(r) ? null : s((n) => n.travel(e, t, r));
	}
	return null;
}
function _i(e, t) {
	let n = [];
	for (let r of t.grid) if (r) for (let i of fi[r.card]?.ops ?? []) {
		let a = {
			type: "printedPower",
			card: r.card,
			op: i,
			boostCost: hi(t, r.card)
		};
		if (i === "ropeSkill") for (let e of ["move", "take"]) n.push({
			...a,
			skill: e
		});
		else if (i === "peekInterior") for (let r of pi(e, t)) n.push({
			...a,
			...r
		});
		else if (i === "peekCost") for (let r of no(e, t.rid, !0)) n.push({
			...a,
			action: r.id
		});
		else if (i === "lessonBenefit") n.push({
			...a,
			targetCard: 1424
		}, {
			...a,
			face: "morale"
		});
		else if (i === "spiralSpell") for (let e of t.grid) e && n.push({
			...a,
			sourceCard: e.card
		});
		else if (i === "sandboat") for (let r of mi(e, t)) n.push({
			...a,
			targetCard: r
		});
		else n.push({
			...a,
			...i === "signalView" ? { condition: !0 } : {}
		});
	}
	return n.filter((n) => gi(e, t, n) !== null);
}
//#endregion
//#region src/games/vantage/printed-powers.ts
var vi = {
	...fi,
	...Object.fromEntries(Array.from({ length: 18 }, (e, t) => [1160 + t, {
		cost: 1,
		ops: ["refineDiscount"]
	}])),
	...Object.fromEntries(Array.from({ length: 6 }, (e, t) => [1299 + t, {
		cost: 2,
		ops: ["startingSkill", "firstObjective"]
	}])),
	...Object.fromEntries([
		874,
		922,
		928,
		929,
		942,
		946,
		965,
		966,
		967,
		973,
		974,
		975,
		976
	].map((e) => [e, {
		cost: 2,
		ops: ["refreshDie"]
	}])),
	857: {
		cost: 1,
		ops: ["heatGuard"]
	},
	858: {
		cost: 1,
		ops: ["heatGuard"]
	},
	861: {
		cost: 1,
		ops: ["coldGuard"]
	},
	865: {
		cost: 1,
		ops: ["refreshHealth"]
	},
	1182: {
		cost: 1,
		ops: ["coldGuard"]
	},
	1183: {
		cost: 1,
		ops: ["heatGuard"]
	},
	1212: {
		cost: 1,
		ops: ["hypoxiaGuard"]
	},
	983: {
		cost: 3,
		ops: ["moraleBoost"]
	},
	1141: {
		cost: 1,
		impact: !0,
		ops: ["replaySentient"]
	},
	1225: {
		cost: 2,
		ops: ["awakenTree"]
	},
	952: {
		cost: 1,
		ops: ["transport"]
	},
	1083: {
		cost: 1,
		ops: ["transport"]
	},
	1366: {
		cost: 1,
		impact: !0,
		ops: ["transferBoost", "transferDie"]
	},
	889: {
		cost: 2,
		ops: ["refreshSelf"]
	},
	950: {
		cost: 2,
		ops: ["refreshSelf"]
	},
	986: {
		cost: 2,
		ops: ["secondGroup"]
	},
	917: {
		cost: 1,
		ops: ["portal"]
	},
	988: {
		cost: 1,
		ops: ["portal"]
	},
	987: {
		cost: 1,
		ops: ["hourglassUndo"]
	},
	994: {
		cost: 2,
		impact: !0,
		ops: ["transformCard"]
	},
	1365: {
		cost: 2,
		impact: !0,
		ops: ["transformCard"]
	},
	1367: {
		cost: 1,
		impact: !0,
		ops: ["preserveReplacement"]
	},
	1006: {
		cost: 1,
		impact: !0,
		ops: ["ignoreExit"]
	},
	1206: {
		cost: 1,
		ops: ["cannon"]
	},
	1199: {
		cost: 1,
		ops: ["payLess", "gainMore"]
	},
	1200: {
		cost: 1,
		ops: ["powerHealthGuard"]
	},
	1707: {
		cost: 1,
		ops: ["attuneComposition"]
	},
	1368: {
		cost: 1,
		impact: !0,
		ops: ["surface"]
	},
	1374: {
		cost: 2,
		impact: !0,
		ops: ["regionalVision"]
	},
	996: {
		cost: 1,
		ops: ["freeResult"]
	},
	1370: {
		cost: 2,
		impact: !0,
		ops: ["freeResult"]
	},
	1378: {
		cost: 2,
		impact: !0,
		ops: ["freeResult"]
	},
	1380: {
		cost: 1,
		impact: !0,
		ops: ["freeResult"]
	},
	1382: {
		cost: 1,
		impact: !0,
		ops: ["freeResult"]
	},
	1372: {
		cost: 1,
		impact: !0,
		ops: ["luckyRoll"]
	},
	1381: {
		cost: 2,
		impact: !0,
		ops: ["secondGroup"]
	},
	1384: {
		cost: 2,
		impact: !0,
		ops: ["extraChoice"]
	},
	1019: {
		cost: 0,
		ops: ["seedSite"]
	},
	1020: {
		cost: 0,
		ops: ["seedSite"]
	},
	1021: {
		cost: 0,
		ops: ["seedSite"]
	},
	...Object.fromEntries([
		956,
		959,
		960,
		1089,
		1090,
		1152,
		1153,
		1231,
		1233,
		1234,
		1235,
		1409,
		1410,
		1411,
		1412,
		1413,
		1414,
		1415,
		1416,
		1417,
		1418
	].map((e) => [e, {
		cost: 1,
		ops: ["beforeDiscount"]
	}])),
	871: {
		cost: 2,
		impact: !0,
		ops: ["rerollAll"]
	},
	886: {
		cost: 2,
		ops: ["randomOverpower"]
	},
	887: {
		cost: 2,
		ops: ["moraleDice"]
	},
	893: {
		cost: 2,
		ops: ["gainTake"]
	},
	934: {
		cost: 1,
		impact: !0,
		ops: ["relocateCard"]
	},
	936: {
		cost: 1,
		ops: ["sentientCoins"]
	},
	937: {
		cost: 1,
		ops: ["tame"]
	},
	939: {
		cost: 2,
		ops: ["refreshSelf"]
	},
	944: {
		cost: 1,
		ops: ["tame"]
	},
	949: {
		cost: 1,
		ops: ["animalDiscount"]
	},
	958: {
		cost: 1,
		ops: ["saddle"]
	},
	980: {
		cost: 1,
		ops: ["rerollFace"]
	},
	990: {
		cost: 2,
		impact: !0,
		ops: ["takeFree"]
	},
	991: {
		cost: 2,
		impact: !0,
		ops: ["moveAdjacent"]
	},
	992: {
		cost: 2,
		ops: ["destroyDie"]
	},
	993: {
		cost: 2,
		impact: !0,
		ops: ["actionEngage"]
	},
	995: {
		cost: 2,
		impact: !0,
		ops: ["shareLocations"]
	},
	997: {
		cost: 1,
		impact: !0,
		ops: ["storeSkill", "useStoredSkill"]
	},
	998: {
		cost: 2,
		impact: !0,
		ops: ["coldGuard", "exploreFree"]
	},
	999: {
		cost: 1,
		impact: !0,
		ops: ["gamble"]
	},
	1e3: {
		cost: 1,
		impact: !0,
		ops: ["page"]
	},
	1003: {
		cost: 1,
		ops: ["destiny"]
	},
	1001: {
		cost: 2,
		impact: !0,
		ops: ["healthMorale"]
	},
	1004: {
		cost: 1,
		impact: !0,
		ops: ["distinctTime"]
	},
	1005: {
		cost: 1,
		impact: !0,
		ops: ["weaponSkills"]
	},
	1007: {
		cost: 2,
		impact: !0,
		ops: ["ignoreFace"]
	},
	1008: {
		cost: 1,
		impact: !0,
		ops: ["cleanse", "newSkill"]
	},
	1009: {
		cost: 1,
		ops: ["remoteReceive"]
	},
	1011: {
		cost: 1,
		ops: ["remotePlace"]
	},
	1024: {
		cost: 2,
		ops: ["convertWeapon"]
	},
	1025: {
		cost: 1,
		ops: ["heatGuard", "stopForced"]
	},
	928: {
		cost: 2,
		ops: ["refreshDie", "ignoreCurse"]
	},
	1038: {
		cost: 1,
		ops: ["rerollFace", "pulseBefore"]
	},
	1039: {
		cost: 1,
		ops: ["ignoreCurse"]
	},
	1151: {
		cost: 1,
		ops: ["hookCost", "hookDiscount"]
	},
	1153: {
		cost: 1,
		ops: ["beforeDiscount", "scope"]
	},
	1157: {
		cost: 1,
		impact: !0,
		ops: ["rerollAll", "startSwitch"]
	},
	1195: {
		cost: 1,
		ops: ["pairBefore"]
	},
	1196: {
		cost: 1,
		ops: ["pairBefore"]
	},
	1198: {
		cost: 1,
		ops: ["pairBefore"]
	},
	1201: {
		cost: 1,
		ops: ["pairBefore"]
	},
	1203: {
		cost: 1,
		ops: ["pairBefore"]
	},
	1205: {
		cost: 1,
		ops: ["pairBefore"]
	},
	1216: {
		cost: 1,
		ops: ["revealCard"]
	},
	1228: {
		cost: 1,
		ops: ["jump"]
	},
	1369: {
		cost: 2,
		impact: !0,
		ops: ["teleport"]
	},
	1202: {
		cost: 1,
		ops: ["cycleDice"]
	},
	1204: {
		cost: 1,
		ops: ["flourish"]
	},
	1236: {
		cost: 2,
		ops: ["rerollFace"]
	},
	1237: {
		cost: 2,
		ops: ["rerollFace"]
	},
	1238: {
		cost: 2,
		ops: ["rerollFace"]
	},
	1371: {
		cost: 2,
		impact: !0,
		ops: ["missingFace"]
	},
	1375: {
		cost: 2,
		ops: ["metalDraw", "metalPush"]
	},
	1373: {
		cost: 2,
		impact: !0,
		ops: ["healAfter"]
	},
	1376: {
		cost: 2,
		impact: !0,
		ops: [
			"cleanse",
			"learnSkill",
			"sentientBoost"
		]
	},
	1377: {
		cost: 2,
		impact: !0,
		ops: [
			"heatGuard",
			"coldGuard",
			"hypoxiaGuard"
		]
	},
	1379: {
		cost: 2,
		impact: !0,
		ops: ["hypoxiaGuard", "rerollFace"]
	},
	1383: {
		cost: 1,
		impact: !0,
		ops: [
			"coldGuard",
			"overpowerDiscount",
			"lampBoost"
		]
	}
}, yi = {
	956: ["overpower"],
	959: ["take"],
	960: ["overpower", "take"],
	1089: ["overpower"],
	1090: ["overpower"],
	1152: ["overpower"],
	1153: ["overpower"],
	1231: ["overpower"],
	1233: ["overpower"]
}, bi = /* @__PURE__ */ new Set([
	1234,
	1235,
	1409,
	1410,
	1411,
	1412,
	1413,
	1414,
	1415,
	1416,
	1417,
	1418
]);
function xi(e, t) {
	return e.powerMove?.kind === "teleport" ? Object.keys(E).map(Number).filter((e) => e >= 12 && e <= 63 || e >= 76 && e <= 531 || e >= 541 && e <= 791 || [
		795,
		799,
		801
	].includes(e)) : [...new Set(Object.values(E[e.personal[t.rid].location]?.exits ?? {}).flatMap((e) => e.destination === null ? [] : [e.destination]))];
}
function Si(e, t) {
	return t === "pulseBefore" || [
		"keepSkillGroup",
		"replaceSkillGroup",
		"dropExtraSkill"
	].includes(t ?? "") || [
		"powerIgnore",
		"powerChange",
		"powerReroll",
		"finishMove",
		"cancelMove",
		"recallDie",
		"convertSkill",
		"keepConversion",
		"flourishSkill",
		"keepDice",
		"replaceDice",
		"dropExtraDie",
		"finishSwitch",
		"cancelSwitch",
		"finishReplacement"
	].includes(t ?? "") ? 0 : t === "ignoreCurse" && e === 928 ? 1 : vi[e]?.cost ?? 0;
}
function Ci(e, t, n, r = !1) {
	let i = /* @__PURE__ */ new Set(), a = (e) => {
		for (let t of k(e).effects) [
			"card",
			"replaceCard",
			"upgradeVehicle"
		].includes(t.kind) && E[Number(t.value)] && [
			"item",
			"vehicle",
			"structure",
			"animal",
			"flora",
			"other"
		].includes(E[Number(t.value)].group) && i.add(Number(t.value));
		for (let t of e.choices) (t.sourceBoost === void 0 || n?.boost === t.sourceBoost) && (t.sourceBoostMin !== void 0 && (n?.boost ?? 0) < t.sourceBoostMin || (!/\bif\b/i.test(t.label) || r) && a(t.node));
		e.after && a(e.after);
	};
	for (let n of O(e)) (t === 994 ? /^(CRAFT|UPGRADE|REFINE)\b/ : /^(BREW|CRAFT|UPGRADE|REFINE)\b/).test(n.label) && a(n.node);
	return i.delete(e), [...i];
}
function wi(e) {
	return e.players.find((t) => t.rid === (e.arrivalSecret ? e.arrivalReader : e.players[e.turn].rid));
}
function Ti(e) {
	let t = e.challenge;
	return !!t && (E[t.source]?.group === "animal" || /\banimals?\b/i.test(D[t.id]?.label ?? ""));
}
function Ei(e) {
	return !!e.challenge && (E[e.challenge.source]?.group === "sentient" || !!e.challenge.interaction?.sentients.length);
}
function Di(e, t) {
	let n = T[t.roll(e, 6)];
	return n === "setback" && e.blankSetbacks ? "blank" : n;
}
function Oi(e, t) {
	return !!(e.pendingCards.length && t !== "ignoreCurse" || e.skillRolls.length || e.replenishments.length || e.placementChoices.length || e.gamblePlayer || e.cardClaims.length || Object.values(e.deliveries).some((e) => e.length) || e.runeSurvey?.length || e.crewSharing || e.summoning?.waiting.length || e.phase === "story" && e.miniGame && !e.miniGame.done || e.storyTest && !e.storyTest.done && t !== "useStoredSkill");
}
function ki(e, t, n) {
	if (e.portalReturnDecision) {
		let r = e.portalReturnDecision;
		return r.rid !== t.rid || n.card !== r.source || !["returnPortal", "stayPortal"].includes(n.op) ? null : (r) => r.finishPortal(e, t, n.op === "returnPortal");
	}
	if (e.hourglassTurnEnd && n.op === "finishHourglassTurn") return e.hourglassTurnEnd === t.rid && n.card === 987 ? (t) => t.finishHourglassTurn(e) : null;
	if (e.hourglassTurnEnd && n.op !== "hourglassUndo") return null;
	if (qe(n.op)) return Xe(e, t, n);
	if (e.powerReplacement) {
		let r = e.powerReplacement;
		if (n.op === "finishReplacement") return n.card !== 1367 || r.rid !== t.rid || r.preserved && (n.cell === void 0 || n.cell === 4 || t.grid[n.cell]) ? null : (t) => t.finishReplacement(e, r.preserved ? n.cell : void 0);
		let i = t.grid.find((e) => e?.card === 1367), a = e.players.find((e) => e.rid === r.rid);
		return n.op !== "preserveReplacement" || n.card !== 1367 || r.preserved || !i || i.boost < 1 || !a?.grid.some((e, t) => t !== 4 && !e) || !["item", "vehicle"].includes(E[r.source]?.group) ? null : (t) => {
			t.spendBoost(e, i, 1), r.preserved = !0;
		};
	}
	if (Oi(e, n.op)) return null;
	if (e.powerSwitch) {
		if (e.powerSwitch.rid !== t.rid || n.card !== 1157) return null;
		if (n.op === "cancelSwitch") return () => {
			delete e.powerSwitch;
		};
		if (n.op !== "finishSwitch" || !n.action || n.action === e.challenge?.id || !no(e, t.rid, !0).some((e) => e.id === n.action)) return null;
		let r = D[n.action];
		return r && (r.condition || r.requiresWater) && !n.condition || e.restrictedWater && !n.condition || Wr(t, n.action, r?.card ?? e.personal[t.rid].location, e.mission === 1593 && !e.missionDone) && n.sentientInteraction === void 0 ? null : (r) => {
			delete e.powerSwitch, r.switchAction(e, t, n.action, n.condition ?? !1, n.sentientInteraction);
		};
	}
	if (e.powerReward) return e.powerReward.rid !== t.rid || n.card !== 1204 || n.op !== "flourishSkill" || !n.skill ? null : (r) => {
		r.gainSkill(t, n.skill, 1), delete e.powerReward, r.cancelMove(e);
	};
	if (e.powerDiceChoice) {
		let r = e.powerDiceChoice;
		return r.rid !== t.rid || n.card !== (r.source ?? 1381) || !["keepDice", "replaceDice"].includes(n.op) || !e.challenge ? null : () => {
			n.op === "replaceDice" && (e.challenge.dice = r.faces, e.challenge.initialTime = r.initialTime), e.pool += r.faces.length, delete e.powerDiceChoice;
		};
	}
	if (e.powerDiscardDice) {
		let r = e.powerDiscardDice, i = n.die;
		return r.rid !== t.rid || n.card !== 1384 || n.op !== "dropExtraDie" || i === void 0 || e.challenge?.dice[i] == null ? null : () => {
			e.challenge.dice.splice(i, 1), e.challenge.initialTime = e.challenge.initialTime?.filter((e) => e !== i).map((e) => e > i ? e - 1 : e), e.pool++, --r.remaining === 0 && delete e.powerDiscardDice;
		};
	}
	if (e.powerMove) {
		if (e.powerMove.rid !== t.rid || n.card !== e.powerMove.source) return null;
		if (n.op === "cancelMove") return (t) => {
			delete e.powerMove, t.cancelMove(e);
		};
		if (n.op !== "finishMove") return null;
		if (n.action) return e.powerMove.kind === "teleport" || !Yr(e.personal[t.rid].location).some((e) => e.id === n.action) || n.targetCard === void 0 || !Ve(n.action, e.personal[t.rid].dungeonOrigin).includes(n.targetCard) ? null : (r) => r.moveAction(e, t, n.action, n.targetCard);
		if (!n.targetCard || !xi(e, t).includes(n.targetCard)) return null;
		let r = e.powerMove.kind === "jump";
		return r && e.pool < 1 && 8 + 2 * e.players.length - ri(e) - (e.boxedDice ?? 0) < 1 ? null : (i) => i.finishMove(e, t, n.targetCard, r);
	}
	if (e.powerConversion && !["convertSkill", "keepConversion"].includes(n.op)) return null;
	if ([
		"powerIgnore",
		"powerChange",
		"powerReroll"
	].includes(n.op)) {
		let r = e.challenge, i = n.die, a = n.op === "powerIgnore" ? "ignore" : n.op === "powerChange" ? "change" : "reroll", o = i === void 0 ? null : r?.dice[i], s = r?.printedEffects?.find((e) => e.source === n.card && e.kind === a && e.remaining > 0 && (e.face === void 0 || e.face === o));
		return wi(e) !== t || e.phase !== "dice" || !r || i === void 0 || o == null || !s || a === "change" && (!n.face || s.nonblank && n.face === "blank") ? null : (t) => {
			s.remaining--, r.initialTime = r.initialTime?.filter((e) => e !== i), a === "ignore" ? (o === "setback" ? e.pool++ : t.putInCenter(e, o), r.dice[i] = null) : a === "change" ? r.dice[i] = n.face : r.dice[i] = Di(e, t);
		};
	}
	if (n.op === "recallDie") return n.card === 992 && (e.boxedDice ?? 0) > 0 ? () => {
		e.boxedDice--, e.pool++;
	} : null;
	if (n.op === "convertSkill" || n.op === "keepConversion") {
		let r = e.powerConversion;
		return n.card !== 1024 || !r?.waiting.includes(t.rid) ? null : (i) => {
			n.op === "convertSkill" && (i.gainSkill(t, "overpower", t.skills[r.skill]), t.skills[r.skill] = 0), r.waiting = r.waiting.filter((e) => e !== t.rid), r.waiting.length || (e.powerConversion = void 0);
		};
	}
	if (e.powerConversion || e.printedRoll) return null;
	if (n.op === "hourglassUndo") {
		if (n.card !== 987) return null;
		let r = co(e, t);
		return r ? () => {
			for (let t of Object.keys(e)) Object.hasOwn(r, t) || delete e[t];
			Object.assign(e, r);
		} : null;
	}
	if (ui(n.op)) return gi(e, t, n);
	let r = vi[n.card], i = t.grid.find((e) => e?.card === n.card), a = wi(e), o = e.challenge, s = n.op === "pulseBefore" ? 0 : n.op === "ignoreCurse" && n.card === 928 ? 1 : r?.cost ?? 0, c = n.op === "cannon" ? t.grid.find((e) => !!e && e.card === n.sourceCard && E[e.card].group === "item") : i;
	if (!r || !i || !c || c.boost < s || !r.ops.includes(n.op) || [
		"launch",
		"landing",
		"experience",
		"done"
	].includes(e.phase) || !r.impact && n.target && n.target !== t.rid && ![
		"remotePlace",
		"transport",
		"portal"
	].includes(n.op)) return null;
	let l = r.impact ? e.players.find((e) => e.rid === (n.target ?? a.rid)) : t;
	if (!l) return null;
	let u = a.rid === t.rid, d = l === a, f = (t) => (n) => {
		n.spendBoost(e, c, s), t(n);
	}, p = (t, r) => f((i) => {
		e.printedRoll = {
			rid: l.rid,
			card: n.card,
			kind: t,
			count: r,
			faces: []
		};
		for (let t = 0; t < r; t++) i.skillRoll(e, l, "printed");
	});
	if (n.op === "portal") {
		let r = n.target ? e.players.find((e) => e.rid === n.target && e !== t) : void 0;
		if (n.target && (!r || n.card !== 988 || n.targetCard !== void 0)) return null;
		let i = r ? e.personal[r.rid].location : n.targetCard, a = e.personal[t.rid].location;
		return i === void 0 || i === a || !r && ![
			157,
			664,
			83,
			106,
			690
		].includes(i) ? null : f((r) => {
			(e.portalReturns ??= []).push({
				rid: t.rid,
				source: n.card,
				origin: a
			}), r.travel(e, t, i);
		});
	}
	if (n.op === "attuneComposition") {
		let e = t.grid.find((e) => e?.card === n.targetCard);
		return !n.composition || n.compositionIndex === void 0 || !e || !_e(e.card).at(n.compositionIndex) || _e(e.card, t)[n.compositionIndex] === n.composition ? null : f(() => {
			let t = e.affinities ??= [], r = t.findIndex((t) => t.card === e.card && t.index === n.compositionIndex);
			r >= 0 && t.splice(r, 1), t.push({
				card: e.card,
				index: n.compositionIndex,
				element: n.composition
			});
		});
	}
	if (n.op === "refineDiscount") return !u || e.phase !== "cost" || !o || o.source !== i.card || !D[o.id]?.boostDiscount || o.cost < 1 || e.setFaces.length ? null : f(() => {
		o.cost--, o.discount = (o.discount ?? 0) + 1;
	});
	if (n.op === "startingSkill") return f((e) => e.gainSkill(t, C[i.card - 1299], 1));
	if (n.op === "firstObjective") {
		let n = 1609 + i.card - 1299;
		return e.personal[t.rid].acquiredCards?.includes(n) || [
			...t.grid,
			...t.reserve,
			...t.supply
		].some((e) => e?.card === n) || e.pendingCards.includes(n) || e.cardClaims.some((e) => e.card === n) ? null : f((r) => r.pending(e, n, t));
	}
	if (n.op === "cannon") return !u || ![
		"action",
		"cost",
		"dice",
		"story"
	].includes(e.phase) || !no(e, t.rid, !0).some((e) => e.book === "overpower") ? null : f((n) => n.cannon(e, t));
	if (n.op === "payLess" || n.op === "gainMore") return Ie(e, t, n.op === "payLess" ? "pay" : "gain") ? f(() => {
		let r = (e.coinPowers ??= {})[t.rid] ??= {}, i = n.op === "payLess" ? "pay" : "gain";
		r[i] = (r[i] ?? 0) + 2;
	}) : null;
	if (n.op === "powerHealthGuard") return e.energySwords?.[t.rid] ? null : f(() => {
		(e.energySwords ??= {})[t.rid] = !0;
	});
	if (n.op === "seedSite") return i.growthAt !== void 0 || n.targetCard !== e.personal[t.rid].location || E[n.targetCard]?.group !== "location" ? null : () => {
		i.growthAt = n.targetCard;
	};
	if (n.op === "transport") {
		let r = e.players.find((e) => e.rid === n.target && e !== t), a = [
			...t.grid,
			...t.reserve,
			...t.supply
		].find((e) => e?.card === n.targetCard);
		return !r || !a || a === i || E[a.card].group !== "item" || a.hiddenAt !== void 0 || a.asylumAt !== void 0 ? null : f((i) => i.transport(e, t, r, a, n.card));
	}
	if (n.op === "transformCard") {
		let t = l.grid.find((e) => e?.card === n.sourceCard);
		return !t || t.card === l.character || n.targetCard === void 0 || !Ci(t.card, n.card, t, n.condition).includes(n.targetCard) ? null : f((r) => r.replace(e, l, t.card, n.targetCard));
	}
	if (n.op === "ignoreExit") {
		if (!d || e.phase !== "story" || !o || !e.passage || !mr(e.personal[l.rid].location) || !/\b(?:exit|leave|outside)\b/i.test(e.passage.node.text)) return null;
		let t = k(e.passage.node, e.storyTest?.faces).effects, n = t.findIndex((t, n) => !e.passage.applied.includes(n));
		return ["location", "returnDungeon"].includes(t[n]?.kind) ? f(() => {
			e.passage.applied.push(n), o.cloakContinue = !0, e.continuation = "must", e.locationContinuation = !0;
		}) : null;
	}
	if (n.op === "transferBoost" || n.op === "transferDie") {
		let r = e.players.find((e) => e.rid === n.sourceOwner), a = r?.grid.find((e) => e?.card === n.sourceCard), o = l.grid.find((e) => e?.card === n.targetCard);
		return !r || !a || !o || a === o || n.op === "transferBoost" && (a.boost - (a === i ? s : 0) < 1 || o.boost - (o === i ? s : 0) >= E[o.card].boostCapacity) || n.op === "transferDie" && (n.sourceSlot === void 0 || n.slot === void 0 || a.dice[String(n.sourceSlot)] === void 0 || !E[o.card].slots[n.slot] || o.dice[String(n.slot)] !== void 0) ? null : () => {
			e.powerTransfer = {
				payer: t.rid,
				from: r.rid,
				to: l.rid,
				source: a.card,
				destination: o.card,
				kind: n.op === "transferBoost" ? "boost" : "die",
				sourceSlot: n.sourceSlot,
				slot: n.slot,
				waiting: [.../* @__PURE__ */ new Set([r.rid, l.rid])].filter((e) => e !== t.rid)
			};
		};
	}
	if (n.op === "flourish") return !u || ![
		"action",
		"cost",
		"dice",
		"story",
		"skirm",
		"arrival"
	].includes(e.phase) || e.pool < 1 && 8 + 2 * e.players.length - ri(e) - (e.boxedDice ?? 0) < 1 ? null : f((n) => n.flourish(e, t));
	if (n.op === "startSwitch") return !d || !o || e.phase !== "cost" || o.cost < 0 || !no(e, l.rid, !0).some((e) => e.id !== o.id) ? null : f(() => {
		e.powerSwitch = { rid: l.rid };
	});
	if (n.op === "hookCost" || n.op === "hookDiscount") {
		let r = n.op === "hookDiscount" ? o?.id : n.action, i = r ? D[r] : void 0, a = i?.card, s = E[a ?? 0]?.group;
		return !u || !i || ![
			"animal",
			"sentient",
			"location"
		].includes(s ?? "") || _e(a, t).includes("energy") || s === "location" && !n.condition ? null : n.op === "hookCost" ? !no(e, t.rid, !0).some((e) => e.id === r) || e.personal[t.rid].revealedCosts.includes(r) ? null : f(() => {
			e.personal[t.rid].revealedCosts.push(r);
		}) : e.phase !== "cost" || !o || o.cost <= 0 || e.setFaces.length ? null : f(() => {
			o.cost--, o.discount = (o.discount ?? 0) + 1;
		});
	}
	if (n.op === "luckyRoll" || n.op === "extraChoice") return !d || !o || e.phase !== "cost" || (n.op === "luckyRoll" ? o.luck : o.extraChoice) ? null : f(() => {
		n.op === "luckyRoll" ? o.luck = !0 : o.extraChoice = !0;
	});
	if (n.op === "secondGroup") return !d || !o || e.phase !== "dice" || o.placed || !o.dice.length || o.dice.some((e) => e === null) || n.card === 986 && o.dice.length > 5 || e.pool < o.dice.length && n.card !== 986 || n.card === 986 && 8 + 2 * e.players.length - ri(e) - (e.boxedDice ?? 0) < o.dice.length ? null : f((t) => {
		if (n.card === 986) {
			let n = o.dice.length;
			if (o.dice = [], t.refresh(e), o.dice = Array.from({ length: n }, () => Di(e, t)), e.pool -= n, o.initialTime = o.bonus?.initial ? o.dice.flatMap((e, t) => e === "time" ? [t] : []) : [], o.bonus?.initial) for (let n = 0; n < o.dice.length; n++) o.dice[n] === "morale" && (o.dice[n] = Di(e, t));
		}
		let r = o.dice.map(() => Di(e, t)), i = o.bonus?.initial ? r.flatMap((e, t) => e === "time" ? [t] : []) : [];
		if (o.bonus?.initial) for (let n = 0; n < r.length; n++) r[n] === "morale" && (r[n] = Di(e, t));
		e.pool -= r.length, e.powerDiceChoice = {
			rid: l.rid,
			source: n.card,
			faces: r,
			initialTime: i
		};
	});
	if (n.op === "replaySentient") {
		let t = l.grid.find((e) => e?.card === n.targetCard), r = n.cell;
		return !t || E[t.card].group !== "sentient" || r === void 0 || r === 4 || l.grid[r] && l.grid[r] !== t ? null : f((n) => {
			let i = {
				card: t.card,
				boost: 0,
				dice: {},
				placed: !0
			};
			n.removeCard(e, l, t.card), l.grid[r] = i, n.whenPlaced(e, l, i, r);
		});
	}
	if (n.op === "awakenTree") return !n.condition || !n.targetCard || n.targetCard < 1360 || n.targetCard > 1364 ? null : f((r) => r.pending(e, n.targetCard, t));
	if (n.op === "regionalVision") {
		let t = kn(e.personal[l.rid].location);
		return t === null ? null : f((n) => {
			e.personal[l.rid].bookPages.includes(t) || e.personal[l.rid].bookPages.push(t), e.milestones.vantages.includes(t) || e.milestones.vantages.push(t), n.addBoost(l.grid[4], 1);
		});
	}
	if (n.op === "surface") {
		let t = e.personal[l.rid].location, n = jn(t);
		return !fn(t) || n === null || ![
			"action",
			"cost",
			"dice",
			"story",
			"skirm",
			"arrival"
		].includes(e.phase) ? null : f((t) => t.travel(e, l, n));
	}
	if (n.op === "freeResult") {
		if (!d || !o || e.phase !== "cost" || o.cost < 0 || !D[o.id]) return null;
		let t = D[o.id]?.label ?? "", r = E[o.source]?.group;
		return n.card === 996 && !/^(?:ENTER|PICK|ACCESS|HIJACK)\b/.test(t) || n.card === 1380 && !/^(?:SWIM|WADE|DIVE|ASCEND)\b/.test(t) || n.card === 1370 && !Ei(e) && !(r === "location" && n.condition) || n.card === 1378 && !Ti(e) && !(r === "location" && n.condition) || n.card === 1382 && r !== "flora" && !(r === "location" && n.condition) ? null : f((t) => {
			o.waiveCoins = n.card !== 1380, t.result(e);
		});
	}
	if (n.op === "healthBoost" || n.op === "moraleBoost" || n.op === "timeBoost") return f((t) => t.gainStat(e, l, n.op === "healthBoost" ? "health" : n.op === "moraleBoost" ? "morale" : "time", 1));
	if (n.op === "refreshDie") {
		let r = t.grid.find((e) => e?.card === n.targetCard), i = n.die, a = n.slot;
		return r && a !== void 0 && r.dice[String(a)] !== void 0 ? f(() => {
			delete r.dice[String(a)], e.pool++;
		}) : !n.targetCard && u && o && e.phase === "dice" && i !== void 0 && o.dice[i] != null ? f(() => {
			o.dice[i] = null, e.pool++;
		}) : null;
	}
	if (n.op === "refreshHealth") {
		let n = t.grid.filter((e) => !!e && Object.values(e.dice).includes("health"));
		return n.length ? f(() => {
			for (let t of n) for (let [n, r] of Object.entries(t.dice)) r === "health" && (delete t.dice[n], e.pool++);
		}) : null;
	}
	if (n.op === "moveAdjacent" || n.op === "teleport" || n.op === "jump") return [
		"action",
		"cost",
		"dice",
		"story",
		"skirm",
		"arrival"
	].includes(e.phase) ? f((t) => t.beginMove(e, l, n.card, n.op === "teleport" ? "teleport" : n.op === "jump" ? "jump" : "adjacent")) : null;
	if (n.op === "beforeDiscount") {
		let r = bi.has(n.card) ? t.grid.flatMap((e) => e && P(e.card, "bow") ? yi[e.card] ?? [] : []) : yi[n.card];
		if (!u || !o || e.phase !== "cost" || !r?.includes(o.skill) || e.setFaces.length) return null;
		let a = n.card === 1409 ? t.grid.find((e) => e?.card === n.targetCard) : null, s = n.card === 1418 ? t.grid.find((e) => e?.card === n.targetCard) : null;
		return n.card === 1409 && (!a || n.slot === void 0 || a.dice[String(n.slot)] === void 0) || n.card === 1418 && (!s || s === i || s.boost >= E[s.card].boostCapacity) ? null : f((r) => {
			o.discount = (o.discount ?? 0) + 1, o.cost >= 0 && (o.cost = Math.max(0, o.cost - 1));
			let i = (e, t, r) => (o.printedEffects ??= []).push({
				source: n.card,
				kind: e,
				face: t,
				nonblank: r,
				remaining: 1
			});
			n.card === 1234 && r.skillRoll(e, t, "gain"), n.card === 1235 && i("ignore", "setback"), a && (delete a.dice[String(n.slot)], e.pool++), n.card === 1410 && Be(e, t, 1), n.card === 1411 && i("ignore", "health"), n.card === 1412 && i("change", void 0, !0), n.card === 1413 && i("ignore", "time"), (n.card === 1414 && /^FORCE\b/.test(D[o.id]?.label ?? "") || n.card === 1416 && /^FISH\b/.test(D[o.id]?.label ?? "")) && (o.testExtraDice = (o.testExtraDice ?? 0) + 1), n.card === 1415 && (Ti(e) || Ei(e)) && i("ignore"), n.card === 1417 && i("reroll"), s && r.addBoost(s, 1);
		});
	}
	if (n.op === "missingFace") return !d || e.phase !== "dice" || !o || o.placed || o.dice.some((e) => e === null) || !n.face || o.dice.includes(n.face) ? null : f(() => {
		o.initialTime = [], o.dice = o.dice.map(() => n.face);
	});
	if (n.op === "lampBoost") {
		let e = l.grid.find((e) => e?.card === n.targetCard);
		return !e || !ke[e.card] || e.boost >= E[e.card].boostCapacity ? null : f((t) => t.addBoost(e, 1));
	}
	if (n.op === "scope") {
		let r = n.targetCard;
		return !r || !Object.values(E[e.personal[t.rid].location]?.exits ?? {}).some((e) => e.destination === r) || e.personal[t.rid].scouted.includes(r) ? null : f(() => e.personal[t.rid].scouted.push(r));
	}
	if (n.op === "metalDraw" || n.op === "metalPush") {
		let r = t.grid.indexOf(i), a = t.grid.flatMap((e, t) => e && (Math.abs(t - r) === 3 || Math.floor(t / 3) === Math.floor(r / 3) && Math.abs(t - r) === 1) ? [e] : []).find((e) => e.card === n.targetCard);
		if (!a) return null;
		let o = n.op === "metalDraw" ? a : i, c = n.op === "metalDraw" ? i : a, l = o.boost - (o === i ? s : 0), u = E[c.card].boostCapacity - c.boost + (c === i ? s : 0), d = Math.min(l, u);
		return d < 1 ? null : f((t) => {
			t.spendBoost(e, o, d), t.addBoost(c, d);
		});
	}
	if (n.op === "cycleDice") {
		let n = t.grid.reduce((e, t) => e + (t ? Object.keys(t.dice).length : 0), 0);
		return !u || !o || e.phase !== "cost" || !n ? null : f(() => {
			for (let e of t.grid) e && (e.dice = {});
			e.pool += n, o.extraChallengeDice = (o.extraChallengeDice ?? 0) + n;
		});
	}
	if (n.op === "rerollAll") return e.phase !== "dice" || !o || o.placed || !o.dice.length || o.dice.some((e) => e === null) || !d ? null : f((t) => {
		o.initialTime = [], o.dice = o.dice.map(() => Di(e, t)), n.card === 871 && t.addBoost(l.grid[4], 1);
	});
	if (n.op === "randomOverpower") return p("randomOverpower", 1);
	if (n.op === "distinctTime") return p("distinctTime", 3);
	if (n.op === "convertWeapon") return p("convertWeapon", 1);
	if (n.op === "moraleDice") return e.pool < 2 && 8 + 2 * e.players.length - ri(e) - (e.boxedDice ?? 0) < 2 ? null : f((n) => {
		e.pool < 2 && n.refresh(e), e.pool -= 2;
		for (let r = 0; r < 2; r++) {
			let r = Di(e, n);
			r === "morale" && n.gainStat(e, t, "morale", 1), n.putInCenter(e, r);
		}
	});
	if (n.op === "pairBefore") return !u || !o || e.phase !== "cost" || o.skill !== {
		1195: "move",
		1196: "help",
		1198: "take",
		1201: "overpower",
		1203: "engage",
		1205: "look"
	}[n.card] || o.pairAttempted ? null : p("pairBefore", 2);
	if (n.op === "pulseBefore") return !u || !o || e.phase !== "cost" || o.skill !== "overpower" || t.skills.look < 1 ? null : (e) => {
		t.skills.look--, e.gainSkill(t, "overpower", 2);
	};
	if (n.op === "relocateCard") {
		let r = t.grid.find((e) => e?.card === n.targetCard) ?? t.reserve.find((e) => e.card === n.targetCard), a = n.cell;
		return !r || r === i || r.card === t.character || a === void 0 || a === 4 || l.grid[a] || Dr(r.card) ? null : f((n) => {
			n.removeCard(e, t, r.card), r.dice = {}, l.grid[a] = r, n.whenPlaced(e, l, r, a);
		});
	}
	if (n.op === "destroyDie") {
		let t = n.face;
		return !t || !(e.penaltyFaces ?? []).includes(t) ? null : f(() => {
			let n = e.penaltyFaces.indexOf(t);
			e.penaltyFaces.splice(n, 1), e.penaltyDice--, e.boxedDice = (e.boxedDice ?? 0) + 1;
		});
	}
	if (n.op === "actionEngage") return !d || !o || ![
		"cost",
		"dice",
		"story"
	].includes(e.phase) || o.temporaryEngage ? null : f(() => {
		o.temporaryEngage = 10;
	});
	if (n.op === "shareLocations") return f((t) => {
		e.sharedLocations = Object.fromEntries(e.players.map((t) => [t.rid, e.personal[t.rid].location]));
		for (let n of e.players) t.addBoost(n.grid[4], 1);
	});
	if (n.op === "healthMorale") return d ? f(() => {
		(e.healthMorale ??= {})[l.rid] = !0;
	}) : null;
	if (n.op === "storeSkill") return !n.skill || Ue(e, n.skill) < 1 ? null : f(() => {
		(i.skills ??= {})[n.skill] = (i.skills?.[n.skill] ?? 0) + 1;
	});
	if (n.op === "stopForced") return !u || e.phase !== "story" || e.continuation !== "must" || e.stopForced.includes(t.rid) ? null : f(() => e.stopForced.push(t.rid));
	if (n.op === "ignoreCurse") {
		let t = e.pendingCards.find(Dr);
		return !u || !t ? null : f(() => {
			e.pendingCards = e.pendingCards.filter((e) => e !== t), delete e.pendingInstances[t];
		});
	}
	if (n.op === "heatGuard" || n.op === "hypoxiaGuard") return f(() => e.protection.push({
		rid: l.rid,
		kind: n.op === "heatGuard" ? "heat" : "hypoxia",
		amount: 1
	}));
	if (n.op === "overpowerDiscount") return d ? f(() => {
		(e.nextOverpowerDiscount ??= {})[l.rid] = (e.nextOverpowerDiscount?.[l.rid] ?? 0) + 1;
	}) : null;
	if (n.op === "revealCard") return n.targetCard === void 0 || n.targetCard > 1708 || !E[n.targetCard] ? null : f(() => {
		e.personal[t.rid].revealedCard = n.targetCard;
	});
	if (n.op === "learnSkill") return n.skill ? f((e) => e.gainSkill(l, n.skill, 1)) : null;
	if (n.op === "sentientBoost") {
		let e = l.grid.find((e) => e?.card === n.targetCard);
		return !e || E[e.card].group !== "sentient" ? null : f((t) => t.addBoost(e, 1));
	}
	if (n.op === "healAfter") {
		let t = e.recentHealthLoss;
		return !t || t.rid !== l.rid || t.serial !== e.eventSeq || t.used ? null : f((n) => {
			t.used = !0, n.gainStat(e, l, "health", 1);
		});
	}
	if (n.op === "remoteReceive" || n.op === "remotePlace") {
		let s = n.die, c = n.op === "remoteReceive" ? t : e.players.find((e) => e.rid === n.target), l = n.slot, d = c?.grid.find((e) => e?.card === n.targetCard), p = E[n.targetCard ?? 0]?.slots[l ?? -1], m = o?.dice[s ?? -1];
		if (!o || e.phase !== "dice" || s === void 0 || l === void 0 || !c || !d || !p || m == null || d.dice[String(l)] !== void 0 || !Gr(d.card, l, d.boost) || !Hr(d.card, p, o, m, !1, c, a) || n.op === "remoteReceive" && (u || a.rid === t.rid) || n.op === "remotePlace" && (!u || c === t || !e.slotPermission.includes(c.rid))) return null;
		let h = d.bonded ? 0 : p.cost;
		return d.boost - (d === i ? r.cost : 0) < h ? null : f((t) => {
			t.spendBoost(e, d, h), d.dice[String(l)] = m, t.slotReward(e, c, d, l, m), o.dice[s] = null, o.placed = !0, (o.placedSlots ??= []).push({
				rid: c.rid,
				card: d.card,
				slot: l
			});
		});
	}
	if (n.op === "gainTake") return f((e) => {
		e.addBoost(t.grid[4], 1), e.gainSkill(t, "take", 1);
	});
	if (n.op === "sentientCoins") return !u || ![
		"cost",
		"dice",
		"story"
	].includes(e.phase) || !Ei(e) ? null : f(() => {
		Be(e, t, 2);
	});
	if (n.op === "tame") {
		let r = t.grid.find((e) => e?.card === n.targetCard), i = Ce[n.targetCard ?? 0];
		if (!r || !i) return null;
		let a = t.grid.indexOf(r);
		return f((o) => {
			o.removeCard(e, t, n.card), o.removeCard(e, t, r.card), o.pending(e, i, t), e.replacementCells[i] = a;
		});
	}
	if (n.op === "refreshSelf") return !Object.keys(i.dice).length || [889, 950].includes(n.card) && Object.keys(i.dice).length !== 2 ? null : f(() => {
		e.pool += Object.keys(i.dice).length, i.dice = {};
	});
	if (n.op === "animalDiscount" || n.op === "exploreFree" || n.op === "takeFree") return !o || e.phase !== "cost" || o.cost <= 0 || e.setFaces.length || !d || n.op === "animalDiscount" && (!u || !Ti(e)) || n.op === "takeFree" && o.skill !== "take" || n.op === "exploreFree" && !/^EXPLORE\b/.test(D[o.id]?.label ?? "") ? null : f(() => {
		n.op === "animalDiscount" ? (o.cost--, o.discount = (o.discount ?? 0) + 1) : (o.cost = 0, o.maxCost = 0);
	});
	if (n.op === "saddle") {
		let t = n.die;
		return !u || !o || e.phase !== "dice" || !Ti(e) || t === void 0 || !["health", "time"].includes(o.dice[t] ?? "") ? null : f((n) => {
			n.putInCenter(e, o.dice[t]), o.dice[t] = null;
		});
	}
	if (n.op === "rerollFace") return !d || !o || e.phase !== "dice" || !n.face || !o.dice.includes(n.face) || n.card === 1038 && !Ti(e) && !Ei(e) && !e.elemental || n.card >= 1236 && n.card <= 1238 && n.face !== {
		1236: "health",
		1237: "morale",
		1238: "time"
	}[n.card] ? null : f((t) => {
		let r = o.dice.flatMap((e, t) => e === n.face ? [t] : []);
		for (let n of r) o.dice[n] = Di(e, t);
		o.initialTime = o.initialTime?.filter((e) => !r.includes(e));
	});
	if (n.op === "gamble") return !o || !d || e.phase !== "dice" || o.placed || !o.dice.length || o.dice.some((e) => e === null) || e.pool < 1 ? null : f((t) => {
		e.pool--, o.cost++, o.initialTime = [], o.dice = Array.from({ length: o.dice.length + 1 }, () => Di(e, t));
	});
	if (n.op === "page") return n.page === void 0 || n.page < 7 || n.page > 30 ? null : f(() => {
		let t = e.personal[l.rid];
		t.bookPages.includes(n.page) || t.bookPages.push(n.page), e.milestones.vantages.includes(n.page) || e.milestones.vantages.push(n.page);
	});
	if (n.op === "destiny") {
		let t = n.targetCard;
		return !t || t < 1598 || t > 1608 || e.center.some((e) => e.card === t) ? null : f(() => {
			e.center.push({
				card: t,
				boost: 0,
				dice: {},
				placed: !0
			});
		});
	}
	if (n.op === "weaponSkills") {
		let e = l.grid.filter((e) => e && (P(e.card, "weapon") || Ae[e.card])).length;
		return e ? f((t) => t.gainSkill(l, "overpower", e)) : null;
	}
	return n.op === "ignoreFace" ? !o || !d || e.phase !== "dice" || !n.face || ![
		"time",
		"health",
		"morale"
	].includes(n.face) || !o.dice.includes(n.face) ? null : f((t) => {
		o.dice = o.dice.map((r) => r === n.face ? (t.putInCenter(e, r), null) : r);
	}) : n.op === "coldGuard" ? f(() => e.protection.push({
		rid: l.rid,
		kind: "cold",
		amount: 1
	})) : n.op === "cleanse" ? !n.targetCard || !Dr(n.targetCard) || !l.grid.some((e) => e?.card === n.targetCard) ? null : f((t) => {
		t.removeCard(e, l, n.targetCard);
	}) : n.op === "newSkill" ? !n.skill || e.players.some((e) => e.skills[n.skill] > 0) ? null : f((e) => e.gainSkill(l, n.skill, 1)) : null;
}
function Ai(e, t) {
	if (e.portalReturnDecision) return e.portalReturnDecision.rid === t.rid ? ["returnPortal", "stayPortal"].map((t) => ({
		type: "printedPower",
		card: e.portalReturnDecision.source,
		op: t,
		boostCost: 0
	})) : [];
	if (e.hourglassTurnEnd) return e.hourglassTurnEnd === t.rid ? [{
		type: "printedPower",
		card: 987,
		op: "finishHourglassTurn",
		boostCost: 0
	}, ...ki(e, t, {
		type: "printedPower",
		card: 987,
		op: "hourglassUndo"
	}) ? [{
		type: "printedPower",
		card: 987,
		op: "hourglassUndo"
	}] : []] : [];
	if (e.powerTransfer) return [];
	if (e.skillRolls.length) return Ze(e, t);
	if (e.powerReplacement) {
		let n = e.powerReplacement, r = [];
		if (n.rid === t.rid) {
			if (n.preserved) for (let e = 0; e < 9; e++) r.push({
				type: "printedPower",
				card: 1367,
				op: "finishReplacement",
				cell: e
			});
			else r.push({
				type: "printedPower",
				card: 1367,
				op: "finishReplacement"
			});
		}
		return r.push({
			type: "printedPower",
			card: 1367,
			op: "preserveReplacement"
		}), r.filter((n) => ki(e, t, n) !== null);
	}
	if (e.skillRolls.length || e.replenishments.length || e.placementChoices.length || e.gamblePlayer || Object.values(e.deliveries).some((e) => e.length) || e.printedRoll) return [];
	if (e.powerSwitch) {
		if (e.powerSwitch.rid !== t.rid) return [];
		let n = [{
			type: "printedPower",
			card: 1157,
			op: "cancelSwitch"
		}];
		for (let r of no(e, t.rid, !0)) {
			let i = {
				type: "printedPower",
				card: 1157,
				op: "finishSwitch",
				action: r.id,
				...r.condition || r.water || e.restrictedWater ? { condition: !0 } : {}
			};
			Wr(t, r.id, r.source, e.mission === 1593 && !e.missionDone) ? n.push({
				...i,
				sentientInteraction: !0
			}, {
				...i,
				sentientInteraction: !1
			}) : n.push(i);
		}
		return n.filter((n) => ki(e, t, n) !== null);
	}
	if (e.powerReward) return e.powerReward.rid === t.rid ? C.map((e) => ({
		type: "printedPower",
		card: 1204,
		op: "flourishSkill",
		skill: e
	})) : [];
	if (e.powerDiceChoice) return e.powerDiceChoice.rid === t.rid ? [{
		type: "printedPower",
		card: e.powerDiceChoice.source ?? 1381,
		op: "keepDice",
		faces: e.challenge.dice
	}, {
		type: "printedPower",
		card: e.powerDiceChoice.source ?? 1381,
		op: "replaceDice",
		faces: e.powerDiceChoice.faces
	}] : [];
	if (e.powerDiscardDice) return e.powerDiscardDice.rid === t.rid ? e.challenge.dice.flatMap((e, t) => e === null ? [] : [{
		type: "printedPower",
		card: 1384,
		op: "dropExtraDie",
		die: t
	}]) : [];
	if (e.powerConversion) return e.powerConversion.waiting.includes(t.rid) ? [{
		type: "printedPower",
		card: 1024,
		op: "convertSkill"
	}, {
		type: "printedPower",
		card: 1024,
		op: "keepConversion"
	}] : [];
	if (e.powerMove) {
		if (e.powerMove.rid !== t.rid) return [];
		let n = {
			type: "printedPower",
			card: e.powerMove.source,
			op: "finishMove"
		};
		return [
			...xi(e, t).map((e) => ({
				...n,
				targetCard: e
			})),
			...e.powerMove.kind === "teleport" ? [] : Yr(e.personal[t.rid].location).flatMap((r) => Ve(r.id, e.personal[t.rid].dungeonOrigin).map((e) => ({
				...n,
				action: r.id,
				targetCard: e
			}))),
			{
				...n,
				op: "cancelMove"
			}
		].filter((n) => ki(e, t, n) !== null);
	}
	let n = _i(e, t);
	if (wi(e) === t && e.phase === "dice") for (let t of e.challenge?.printedEffects ?? []) t.remaining > 0 && e.challenge.dice.forEach((e, r) => {
		let i = {
			type: "printedPower",
			card: t.source,
			op: t.kind === "ignore" ? "powerIgnore" : t.kind === "change" ? "powerChange" : "powerReroll",
			die: r
		};
		if (t.kind === "change") for (let e of [
			"time",
			"morale",
			"health",
			"setback",
			"blank"
		]) n.push({
			...i,
			face: e
		});
		else n.push(i);
	});
	(e.boxedDice ?? 0) > 0 && n.push({
		type: "printedPower",
		card: 992,
		op: "recallDie"
	});
	for (let r of t.grid) {
		let i = r && vi[r.card];
		if (r && i) for (let a of i.ops) {
			if (ui(a)) continue;
			let i = {
				type: "printedPower",
				card: r.card,
				op: a
			};
			if (a === "portal") {
				for (let e of [
					157,
					664,
					83,
					106,
					690
				]) n.push({
					...i,
					targetCard: e
				});
				if (r.card === 988) for (let r of e.players) r !== t && n.push({
					...i,
					target: r.rid
				});
				continue;
			}
			if (!(e.pendingCards.length && a !== "ignoreCurse")) {
				if (a === "attuneComposition") {
					for (let e of t.grid) e && _e(e.card).forEach((t, r) => {
						for (let t of ge) n.push({
							...i,
							targetCard: e.card,
							compositionIndex: r,
							composition: t
						});
					});
					continue;
				}
				if (a === "transformCard") {
					for (let t of e.players) for (let e of t.grid) if (e) {
						let a = Ci(e.card, r.card, e);
						for (let o of Ci(e.card, r.card, e, !0)) n.push({
							...i,
							target: t.rid,
							sourceCard: e.card,
							targetCard: o,
							...a.includes(o) ? {} : { condition: !0 }
						});
					}
					continue;
				}
				if ([
					"page",
					"weaponSkills",
					"coldGuard",
					"heatGuard",
					"hypoxiaGuard",
					"cleanse",
					"newSkill",
					"learnSkill",
					"storeSkill",
					"useStoredSkill",
					"relocateCard",
					"replaySentient",
					"sentientBoost",
					"healAfter",
					"lampBoost",
					"moveAdjacent",
					"teleport",
					"surface",
					"regionalVision",
					"freeResult",
					"luckyRoll",
					"secondGroup",
					"extraChoice",
					"startSwitch",
					"ignoreExit"
				].includes(a)) for (let o of e.players) if (a === "page") for (let e = 7; e <= 30; e++) n.push({
					...i,
					target: o.rid,
					page: e
				});
				else if (a === "cleanse") for (let e of o.grid) e && Dr(e.card) && n.push({
					...i,
					target: o.rid,
					targetCard: e.card
				});
				else if ([
					"newSkill",
					"learnSkill",
					"storeSkill",
					"useStoredSkill"
				].includes(a)) for (let e of C) n.push({
					...i,
					target: o.rid,
					skill: e
				});
				else if (a === "relocateCard") {
					for (let e of [...t.grid, ...t.reserve]) if (e) for (let t = 0; t < 9; t++) n.push({
						...i,
						target: o.rid,
						targetCard: e.card,
						cell: t
					});
				} else if (a === "replaySentient") {
					for (let e of o.grid) if (e && E[e.card].group === "sentient") for (let t = 0; t < 9; t++) n.push({
						...i,
						target: o.rid,
						targetCard: e.card,
						cell: t
					});
				} else if (a === "sentientBoost" || a === "lampBoost") for (let e of o.grid) e && n.push({
					...i,
					target: o.rid,
					targetCard: e.card
				});
				else a === "freeResult" ? n.push({
					...i,
					target: o.rid,
					...[
						1370,
						1378,
						1382
					].includes(r.card) && E[e.challenge?.source ?? 0]?.group === "location" ? { condition: !0 } : {}
				}) : n.push({
					...i,
					target: o.rid
				});
				else if (a === "tame") for (let e of t.grid) e && Ce[e.card] && n.push({
					...i,
					targetCard: e.card
				});
				else if (a === "awakenTree") for (let e = 1360; e <= 1364; e++) n.push({
					...i,
					targetCard: e,
					condition: !0
				});
				else if (a === "transport") {
					for (let r of e.players) if (r !== t) for (let e of [
						...t.grid,
						...t.reserve,
						...t.supply
					]) e && n.push({
						...i,
						target: r.rid,
						targetCard: e.card
					});
				} else if (a === "cannon") for (let e of t.grid) e && n.push({
					...i,
					sourceCard: e.card
				});
				else if (a === "transferBoost" || a === "transferDie") {
					for (let t of e.players) for (let r of t.grid) if (r) {
						for (let o of e.players) for (let e of o.grid) if (e && e !== r) {
							let s = {
								...i,
								sourceOwner: t.rid,
								sourceCard: r.card,
								target: o.rid,
								targetCard: e.card
							};
							if (a === "transferBoost") n.push(s);
							else for (let t of Object.keys(r.dice)) for (let r of E[e.card].slots) e.dice[String(r.index)] === void 0 && n.push({
								...s,
								sourceSlot: Number(t),
								slot: r.index
							});
						}
					}
				} else if (a === "hookCost") for (let r of no(e, t.rid, !0)) n.push({
					...i,
					action: r.id,
					...E[r.source]?.group === "location" ? { condition: !0 } : {}
				});
				else if (a === "hookDiscount") n.push({
					...i,
					...E[e.challenge?.source ?? 0]?.group === "location" ? { condition: !0 } : {}
				});
				else if (a === "destiny") for (let e = 1598; e <= 1608; e++) n.push({
					...i,
					targetCard: e
				});
				else if (a === "saddle") e.challenge?.dice.forEach((e, t) => n.push({
					...i,
					die: t
				}));
				else if (a === "refreshDie") {
					for (let e of t.grid) if (e) for (let t of Object.keys(e.dice)) n.push({
						...i,
						targetCard: e.card,
						slot: Number(t)
					});
					e.challenge?.dice.forEach((e, t) => n.push({
						...i,
						die: t
					}));
				} else if (a === "ignoreFace" || a === "rerollFace" || a === "destroyDie" || a === "missingFace") for (let e of [
					"time",
					"morale",
					"health",
					"setback",
					"blank"
				]) n.push({
					...i,
					face: e
				});
				else if (a === "scope") for (let r of Object.values(E[e.personal[t.rid].location]?.exits ?? {})) r.destination && n.push({
					...i,
					targetCard: r.destination
				});
				else if (a === "metalDraw" || a === "metalPush" || a === "beforeDiscount" && r.card === 1418) for (let e of t.grid) e && n.push({
					...i,
					targetCard: e.card
				});
				else if (a === "beforeDiscount" && r.card === 1409) {
					for (let e of t.grid) if (e) for (let t of Object.keys(e.dice)) n.push({
						...i,
						targetCard: e.card,
						slot: Number(t)
					});
				} else if (a === "revealCard" || a === "seedSite") n.push({
					...i,
					targetCard: e.personal[t.rid].location
				});
				else if (a === "remotePlace" || a === "remoteReceive") {
					for (let r of a === "remoteReceive" ? [t] : e.players) for (let t of r.grid) if (t) for (let a of E[t.card].slots) e.challenge?.dice.forEach((e, o) => n.push({
						...i,
						target: r.rid,
						targetCard: t.card,
						slot: a.index,
						die: o
					}));
				} else n.push(i);
			}
		}
	}
	return n.filter((n) => ki(e, t, n) !== null);
}
function ji(e, t, n, r) {
	let i = e.printedRoll;
	i && i.rid === t.rid && (i.faces.push(n), !(i.faces.length < i.count) && (e.printedRoll = void 0, i.kind === "randomOverpower" && (r.gainSkill(t, n, 1), n === "overpower" && r.gainSkill(t, n, 1)), i.kind === "distinctTime" && new Set(i.faces).size === 3 && r.gainStat(e, t, "time", 1), i.kind === "pairBefore" && e.challenge && (e.challenge.pairAttempted = !0, i.faces[0] === i.faces[1] && (e.challenge.skipChallenge = !0)), i.kind === "convertWeapon" && (r.gainSkill(t, n, 1), n !== "overpower" && (e.powerConversion = {
		skill: n,
		waiting: e.players.map((e) => e.rid)
	})), i.kind === "luck" && e.challenge && n === e.challenge.skill && (r.putInCenter(e, ...e.challenge.dice.filter((e) => e !== null)), e.challenge.dice = [], e.challenge.initialTime = [], delete e.powerDiscardDice)));
}
//#endregion
//#region src/games/vantage/schema.ts
var R = e.int().min(0).max(1714), Mi = e.enum([
	"time",
	"morale",
	"health"
]), z = e.enum([
	"move",
	"look",
	"engage",
	"help",
	"take",
	"overpower"
]), Ni = e.enum([
	"water",
	"wood",
	"wind",
	"leaf",
	"stone",
	"sand",
	"metal",
	"sinew",
	"gold",
	"fire",
	"energy",
	"circuit"
]), Pi = e.enum([
	"time",
	"morale",
	"health",
	"setback",
	"blank"
]), Fi = e.object({
	card: R,
	index: e.int().min(0).max(11),
	element: Ni
}), Ii = e.object({
	affinities: e.array(Fi).max(108).optional(),
	affinity: Fi.optional(),
	growthAt: R.optional(),
	skills: e.partialRecord(z, e.int().nonnegative()).optional(),
	acquiredAt: R.optional(),
	asylumAt: R.optional(),
	hiddenAt: R.optional(),
	tucked: e.array(e.object({
		card: R,
		boost: e.int().nonnegative(),
		dice: e.record(e.string(), Pi)
	})).optional(),
	card: R,
	boost: e.int().nonnegative(),
	dice: e.record(e.string(), Pi),
	craftedAt: R.optional(),
	craftedBy: e.string().optional(),
	shelter: e.boolean().optional(),
	rotated: e.boolean().optional(),
	placed: e.boolean().optional(),
	bonded: e.boolean().optional(),
	tokens: e.int().nonnegative().optional(),
	origin: R.optional(),
	rescueShip: e.boolean().optional(),
	upgradedShip: e.boolean().optional(),
	builtShip: e.boolean().optional(),
	initialBoost: e.int().nonnegative().optional()
}), Li = e.object({
	startingStat: e.int().min(3).max(6).default(4),
	opening: e.boolean().optional()
}).prefault({ opening: !0 }), Ri = e.object({
	type: e.literal("printedPower"),
	card: R,
	boostCost: e.int().nonnegative().optional(),
	op: e.enum(/* @__PURE__ */ "rerollAll.gainTake.sentientCoins.tame.refreshSelf.animalDiscount.saddle.rerollFace.takeFree.gamble.page.destiny.weaponSkills.ignoreFace.cleanse.newSkill.coldGuard.exploreFree.randomOverpower.moraleDice.relocateCard.destroyDie.recallDie.actionEngage.shareLocations.healthMorale.distinctTime.stopForced.heatGuard.ignoreCurse.pairBefore.convertWeapon.convertSkill.keepConversion.storeSkill.useStoredSkill.pulseBefore.remoteReceive.remotePlace.learnSkill.healAfter.hypoxiaGuard.overpowerDiscount.revealCard.sentientBoost.beforeDiscount.powerIgnore.powerChange.powerReroll.missingFace.lampBoost.metalDraw.metalPush.cycleDice.flourish.scope.moveAdjacent.teleport.jump.finishMove.cancelMove.refreshDie.refreshHealth.healthBoost.moraleBoost.timeBoost.seedSite.replaySentient.awakenTree.surface.regionalVision.freeResult.flourishSkill.luckyRoll.secondGroup.keepDice.replaceDice.extraChoice.dropExtraDie.startSwitch.finishSwitch.cancelSwitch.hookCost.hookDiscount.transport.transferBoost.transferDie.refineDiscount.startingSkill.firstObjective.transformCard.preserveReplacement.finishReplacement.ignoreExit.repeatSkillGroup.extraSkillGroup.keepSkillGroup.replaceSkillGroup.dropExtraSkill.cannon.payLess.gainMore.powerHealthGuard.attuneComposition.ropeSkill.peekInterior.peekCost.regionView.lessonBenefit.signalView.spiralSpell.referencePage.sandboat.abilitySkill.portal.returnPortal.stayPortal.hourglassUndo.finishHourglassTurn".split(".")),
	composition: Ni.optional(),
	compositionIndex: e.int().min(0).max(11).optional(),
	sourceSlot: e.int().min(0).max(20).optional(),
	skillFaces: e.array(z).max(30).optional(),
	sourceOwner: e.string().optional(),
	sourceCard: R.optional(),
	sentientInteraction: e.boolean().optional(),
	faces: e.array(Pi).max(30).optional(),
	condition: e.boolean().optional(),
	target: e.string().optional(),
	targetCard: R.optional(),
	action: e.string().max(50).optional(),
	die: e.int().min(0).max(30).optional(),
	face: Pi.optional(),
	skill: z.optional(),
	page: e.int().min(1).max(50).optional(),
	cell: e.int().min(0).max(8).optional(),
	slot: e.int().min(0).max(20).optional()
}), zi = e.discriminatedUnion("type", [
	Ri,
	e.object({
		type: e.literal("answerPowerTransfer"),
		accept: e.boolean()
	}),
	e.object({
		type: e.literal("actionBonus"),
		op: e.enum([
			"ignore",
			"change",
			"reroll",
			"chooseIgnore",
			"foresight"
		]),
		die: e.int().nonnegative().optional(),
		face: Pi.optional(),
		indices: e.array(e.int().nonnegative()).max(30).default([])
	}),
	St,
	At,
	e.object({
		type: e.literal("confirmRune"),
		present: e.boolean()
	}),
	e.object({
		type: e.literal("recordRune"),
		skill: z,
		row: e.int().min(0).max(2),
		condition: e.boolean()
	}),
	e.object({
		type: e.literal("completeRuneQuest"),
		target: e.string()
	}),
	e.object({
		type: e.literal("shareVantage"),
		accept: e.boolean()
	}),
	e.object({
		type: e.literal("stowCard"),
		card: R,
		cell: e.int().min(0).max(8).optional()
	}),
	e.object({
		type: e.literal("setLaunchStat"),
		stat: e.int().min(3).max(6)
	}),
	e.object({
		type: e.literal("prepareLaunch"),
		stat: e.int().min(3).max(6)
	}),
	e.object({
		type: e.literal("chooseCapsule"),
		skill: z
	}),
	e.object({ type: e.literal("confirmLanding") }),
	e.object({ type: e.literal("rerollLanding") }),
	e.object({ type: e.literal("rerollMission") }),
	e.object({
		type: e.literal("chooseAction"),
		id: e.string().max(50),
		sentientInteraction: e.boolean().optional(),
		condition: e.boolean().optional()
	}),
	e.object({
		type: e.literal("chooseCost"),
		cost: e.int().min(1).max(6)
	}),
	e.object({
		type: e.literal("clearObstacle"),
		condition: e.boolean()
	}),
	e.object({ type: e.literal("contribute") }),
	e.object({
		type: e.literal("requestStoryPayment"),
		index: e.int().min(0).max(100)
	}),
	e.object({
		type: e.literal("pledgeStoryPayment"),
		skill: z,
		amount: e.int().min(0).max(10)
	}),
	e.object({ type: e.literal("cancelStoryPayment") }),
	e.object({ type: e.literal("contributeCoin") }),
	e.object({ type: e.literal("roll") }),
	e.object({
		type: e.literal("placeDie"),
		die: e.int().min(0).max(30),
		owner: e.string(),
		card: R,
		slot: e.int().min(0).max(20),
		condition: e.boolean().default(!1)
	}),
	e.object({ type: e.literal("rerollElemental") }),
	e.object({
		type: e.literal("rerollDie"),
		die: e.int().min(0).max(30)
	}),
	e.object({ type: e.literal("penalties") }),
	e.object({
		type: e.literal("applyEffect"),
		index: e.int().nonnegative().max(100),
		destination: R.optional(),
		diceFromPool: e.int().min(0).max(4).optional(),
		skillPayment: e.array(z).min(1).max(3).optional(),
		investment: e.int().min(1).max(10).optional(),
		transfers: e.array(e.object({
			card: R,
			amount: e.int().min(1).max(9)
		})).max(20).optional(),
		target: e.string().optional(),
		diceIndices: e.array(e.int().min(0).max(40)).max(2).optional(),
		amount: e.int().min(1).max(2).optional(),
		cards: e.array(R).max(20).optional(),
		condition: e.boolean().optional(),
		reward: e.int().nonnegative().max(100).optional(),
		action: e.string().max(50).optional(),
		actions: e.array(e.string().max(50)).max(2).optional(),
		damage: e.enum(["health", "timeMorale"]).optional(),
		refreshDice: e.array(e.object({
			card: R,
			slot: e.int().min(0).max(20)
		})).max(6).optional(),
		replaceCharacter: e.boolean().optional(),
		preparation: e.enum([
			"skills",
			"row",
			"column"
		]).optional(),
		skill: z.optional(),
		line: e.int().min(0).max(2).optional()
	}),
	e.object({
		type: e.literal("answerSummon"),
		accept: e.boolean(),
		card: R.optional()
	}),
	e.object({
		type: e.literal("chooseBranch"),
		index: e.int().nonnegative().max(100),
		condition: e.boolean().default(!1)
	}),
	e.object({
		type: e.literal("placeCard"),
		card: R,
		zone: e.enum([
			"grid",
			"reserve",
			"supply",
			"center",
			"tuck"
		]),
		cell: e.int().min(0).max(8).optional()
	}),
	e.object({
		type: e.literal("placementBoost"),
		card: R
	}),
	e.object({
		type: e.literal("replenish"),
		accept: e.boolean()
	}),
	e.object({
		type: e.literal("itemPower"),
		card: R,
		power: e.enum([
			"refresh",
			"neighbors",
			"ride",
			"ice",
			"help",
			"fly",
			"skillFace"
		]),
		skill: z.optional(),
		targetCard: R.optional(),
		slot: e.int().min(0).max(20).optional(),
		die: e.int().min(0).max(30).optional(),
		condition: e.boolean().default(!1)
	}),
	e.object({
		type: e.literal("sentientPower"),
		card: R,
		power: e.enum([
			"refresh",
			"protect",
			"skill",
			"gain",
			"page",
			"travel",
			"unique",
			"gamble",
			"impact",
			"boost",
			"stop",
			"siphon",
			"ignore",
			"blank",
			"scout",
			"cost",
			"reroll",
			"skillFace"
		]),
		targetCard: R.optional(),
		skill: z.optional(),
		slot: e.int().min(0).max(20).optional(),
		die: e.int().min(0).max(30).optional(),
		indices: e.array(e.int().min(0).max(30)).max(30).default([]),
		faces: e.array(Pi).max(5).default([]),
		action: e.string().max(50).optional()
	}),
	e.object({
		type: e.literal("chooseGamble"),
		face: Pi
	}),
	e.object({ type: e.literal("keepSkillRoll") }),
	e.object({
		type: e.literal("storyTest"),
		op: e.enum([
			"roll",
			"keep",
			"bait",
			"boost",
			"reroll",
			"partial",
			"skill"
		]),
		skill: z.optional(),
		indices: e.array(e.int().min(0).max(40)).max(40).optional(),
		card: R.optional(),
		die: e.int().min(0).max(40).optional()
	}),
	e.object({
		type: e.literal("discard"),
		card: R
	}),
	e.object({
		type: e.literal("boost"),
		power: e.enum([
			"coin",
			"move",
			"reserve"
		]),
		card: R.optional(),
		cell: e.int().min(0).max(8).optional()
	}),
	e.object({
		type: e.literal("finishStory"),
		continue: e.boolean().default(!1)
	}),
	e.object({ type: e.literal("lastChance") }),
	e.object({ type: e.literal("endCrisis") }),
	e.object({ type: e.literal("endAdventure") }),
	e.object({ type: e.literal("confirmEnd") }),
	e.object({ type: e.literal("cancelEnd") }),
	e.object({
		type: e.literal("setNotes"),
		text: e.string().max(3e3)
	}),
	e.object({
		type: e.literal("skirm"),
		op: e.enum([
			"choose",
			"activate",
			"set",
			"reroll",
			"keep",
			"swap",
			"skip",
			"group"
		]),
		card: e.int().min(1).max(1528).optional(),
		indices: e.array(e.int().min(0).max(12)).max(12).default([]),
		other: e.array(e.int().min(0).max(12)).max(12).default([]),
		faces: e.array(z).max(12).default([]),
		choice: e.int().min(0).max(1).optional()
	}),
	e.object({ type: e.literal("finishSkirm") }),
	e.object({ type: e.literal("discardSkirmCollection") }),
	e.object({
		type: e.literal("assignRescue"),
		target: e.string(),
		stat: Mi
	}),
	e.object({
		type: e.literal("readGoal"),
		card: R,
		condition: e.boolean()
	}),
	e.object({
		type: e.literal("readPersonal"),
		card: R,
		condition: e.boolean()
	}),
	e.object({
		type: e.literal("recordQuestLocation"),
		card: R,
		condition: e.boolean()
	}),
	e.object({
		type: e.literal("recordPathStation"),
		symbol: e.int().min(0).max(8),
		condition: e.boolean()
	}),
	e.object({
		type: e.literal("tameAnimal"),
		card: R
	}),
	e.object({
		type: e.literal("animalPower"),
		card: R,
		power: e.enum([
			"scout",
			"costs",
			"ride",
			"fly",
			"ignore",
			"charm",
			"fetch",
			"plunder",
			"climate",
			"revive"
		]),
		action: e.string().max(50).optional(),
		targetCard: R.optional(),
		condition: e.boolean().default(!1),
		indices: e.array(e.int().min(0).max(30)).max(3).default([]),
		centerIndices: e.array(e.int().min(0).max(30)).max(3).default([])
	}),
	e.object({ type: e.literal("startPearlDefense") }),
	e.object({
		type: e.literal("abandonQuest"),
		card: R
	}),
	e.object({
		type: e.literal("completeMission"),
		end: e.boolean(),
		destiny: e.int().min(1598).max(1608).optional()
	}),
	e.object({
		type: e.literal("reserveCard"),
		card: R
	}),
	e.object({
		type: e.literal("releaseCard"),
		card: R
	}),
	e.object({
		type: e.literal("resolveExperience"),
		card: R,
		replace: e.boolean()
	}),
	e.object({
		type: e.literal("allowSlots"),
		allowed: e.boolean()
	}),
	e.object({
		type: e.literal("allowImpact"),
		allowed: e.boolean()
	}),
	e.object({
		type: e.literal("follow"),
		allowed: e.boolean()
	}),
	e.object({
		type: e.literal("giveCoins"),
		target: e.string(),
		amount: e.int().positive().max(1e5)
	}),
	e.object({
		type: e.literal("giveCard"),
		target: e.string(),
		card: R
	}),
	e.object({
		type: e.literal("resolveCardClaim"),
		card: R,
		transfer: e.boolean()
	}),
	e.object({
		type: e.literal("payArrival"),
		skill: z
	}),
	e.object({ type: e.literal("shieldArrival") }),
	e.object({
		type: e.literal("resolveArrival"),
		damage: e.enum(["health", "timeMorale"]).optional(),
		skill: z.optional(),
		reserveCard: R.optional(),
		destination: R.optional()
	}),
	e.object({
		type: e.literal("characterPower"),
		power: e.enum([
			"boost",
			"skill",
			"switch",
			"refreshPlaced",
			"blankSetbacks",
			"ignore",
			"increase",
			"undo"
		]),
		card: R.optional(),
		slot: e.int().min(0).max(20).optional(),
		die: e.int().min(0).max(30).optional(),
		action: e.string().max(50).optional(),
		sentientInteraction: e.boolean().optional()
	})
]), Bi = e.object({
	rid: e.string(),
	character: R,
	previousCharacter: R.optional(),
	stats: e.record(Mi, e.int().min(0).max(6)),
	coins: e.int().nonnegative(),
	skills: e.record(z, e.int().nonnegative()),
	grid: e.array(Ii.nullable()).length(9),
	reserve: e.array(Ii),
	supply: e.array(Ii),
	skirm: e.array(e.int().min(1).max(144)),
	landingReady: e.boolean()
}), Vi = e.object({
	storyPayment: e.object({
		costs: e.array(e.object({
			skill: z,
			amount: e.int().positive()
		})),
		pledges: e.record(e.string(), e.partialRecord(z, e.int().nonnegative()))
	}).nullable(),
	runeSurvey: e.array(e.string()).nullable(),
	runeQuest: e.object({ cells: e.array(e.boolean()).length(18) }).nullable(),
	crewSharing: e.object({ waiting: e.array(e.string()) }).nullable(),
	players: e.array(Bi),
	active: e.string(),
	phase: e.enum([
		"launch",
		"landing",
		"action",
		"cost",
		"dice",
		"story",
		"skirm",
		"crisis",
		"experience",
		"arrival",
		"done"
	]),
	launch: e.object({
		stage: e.enum([
			"000",
			"001",
			"landing"
		]),
		ready: e.array(e.string()),
		selected: e.array(e.string()),
		rewind: e.boolean(),
		stats: e.record(e.string(), e.int().min(3).max(6)),
		locked: e.array(e.string()),
		joined: e.record(e.string(), e.string()).optional()
	}).nullable(),
	round: e.int().positive(),
	pool: e.int().nonnegative(),
	penaltyDice: e.int().nonnegative(),
	penaltyFaces: e.array(Pi.nullable()),
	center: e.array(Ii),
	mission: R,
	missionDone: e.boolean(),
	missionPivot: e.boolean(),
	destinyDone: e.boolean(),
	missionReady: e.boolean(),
	readyDestinies: e.array(R),
	challenge: e.object({
		skill: z,
		untyped: e.boolean().optional(),
		rollCount: e.int().nonnegative().optional(),
		cost: e.int().nonnegative(),
		dice: e.array(Pi.nullable())
	}).nullable(),
	endingRequestedBy: e.string().nullable(),
	ending: e.enum([
		"none",
		"retired",
		"failure",
		"mission",
		"destiny",
		"epic"
	]),
	event: e.enum([
		"setup",
		"landing",
		"action",
		"roll",
		"place",
		"penalty",
		"story",
		"gain",
		"turn",
		"end"
	]),
	eventSeq: e.int().nonnegative(),
	rescue: e.record(Mi, e.int().nonnegative()).nullable(),
	slotPermission: e.array(e.string()),
	impactPermission: e.array(e.string()),
	followConsent: e.array(e.string()),
	deliveryRecipients: e.array(e.string()),
	cardClaims: e.array(e.object({
		card: R,
		owner: e.string(),
		requester: e.string()
	})),
	placementPlayer: e.string().nullable(),
	replenishment: e.object({
		rid: e.string(),
		owner: e.string(),
		card: R
	}).nullable(),
	summoning: e.object({
		caller: e.string(),
		waiting: e.array(e.string()),
		summoned: e.array(e.string()),
		solo: Ii.nullable()
	}).nullable(),
	powerTransfer: e.object({
		payer: e.string(),
		from: e.string(),
		to: e.string(),
		source: R,
		destination: R,
		kind: e.enum(["boost", "die"]),
		waiting: e.array(e.string())
	}).nullable(),
	temporaryImpact: e.array(R),
	gamblePlayer: e.string().nullable(),
	skillRollPlayer: e.string().nullable(),
	cardsPending: e.boolean(),
	presetFaces: e.array(Pi),
	arrivalPlayer: e.string().nullable(),
	arrivalSkills: e.array(z),
	skirm: e.object({
		controllers: e.tuple([e.string(), e.string()]),
		cards: e.tuple([e.number().nullable(), e.number().nullable()]),
		dice: e.tuple([e.array(z.nullable()), e.array(z.nullable())]),
		stage: e.string(),
		turn: e.int(),
		first: e.int(),
		scores: e.tuple([e.int(), e.int()]),
		winner: e.int().nullable(),
		processed: e.array(e.int()),
		groups: e.array(e.int()),
		counts: e.tuple([e.array(e.int().nonnegative()), e.array(e.int().nonnegative())]),
		extras: e.tuple([e.array(z), e.array(z)]),
		removedPrinted: e.tuple([e.array(z), e.array(z)]),
		bonus: e.tuple([e.int(), e.int()])
	}).nullable()
}), Hi = e.object({
	kind: e.string(),
	amount: e.int(),
	value: e.string(),
	minimum: e.int().positive().optional(),
	applied: e.boolean()
}), Ui = e.object({
	printedPowerOptions: e.array(Ri),
	sharedLocations: e.array(e.object({
		rid: e.string(),
		location: R
	})),
	revealedCard: R.nullable(),
	actionEngage: e.int().nonnegative(),
	powerTravel: e.boolean(),
	landingRerollAllowed: e.boolean(),
	puzzle: jt.nullable(),
	canUndoAction: e.boolean(),
	actionBonus: tn.nullable(),
	bonusDice: e.array(Pi),
	bonusSelection: e.array(e.int().nonnegative()).nullable(),
	bonusChoiceNeeded: e.boolean(),
	foresightSources: e.object({
		pool: e.int().nonnegative(),
		center: e.int().nonnegative()
	}),
	miniGame: xt.nullable(),
	abilityChoices: e.array(e.object({
		id: e.string(),
		label: e.string(),
		labelZh: e.string(),
		source: R
	})),
	copiedBenefits: e.array(e.object({
		kind: e.string(),
		amount: e.int(),
		value: e.string()
	})),
	previewedOutcome: e.object({
		text: e.string(),
		zh: e.string().optional()
	}).nullable(),
	asylumPending: e.array(R),
	abilityDice: e.array(Pi),
	knownHouseFace: Pi.nullable(),
	investmentReturn: e.int().nonnegative().nullable(),
	storedBelongings: e.array(e.object({
		location: R,
		returnOnLeave: e.boolean(),
		cards: e.array(R)
	})),
	requiredGrid: e.array(R),
	tuckTargets: e.record(e.string(), R),
	tuckedPlants: e.array(R),
	trapTest: e.object({
		target: Pi,
		faces: e.array(Pi).min(1).max(3)
	}).nullable(),
	nextActionDiscount: e.int().nonnegative(),
	challengeRewardFace: Pi.nullable(),
	runeFaces: e.array(z),
	runeRecordable: e.boolean(),
	slotPartners: e.array(e.string()),
	summonCharacters: e.array(R),
	elemental: e.object({
		location: R,
		cards: e.array(R),
		next: e.enum([
			"none",
			"discount",
			"ignoreHealth",
			"reroll"
		])
	}).nullable(),
	elementalReroll: e.boolean(),
	scouted: e.array(R),
	revealedCosts: e.array(e.object({
		id: e.string(),
		label: e.string(),
		labelZh: e.string(),
		cost: e.union([e.number(), e.string()])
	})),
	gamble: e.boolean(),
	skillRoll: e.object({
		face: z,
		kind: e.enum([
			"gain",
			"result",
			"resultGain",
			"match",
			"trial",
			"test",
			"crew",
			"rune",
			"mini",
			"hatch",
			"pearl",
			"printed",
			"skirm"
		]),
		match: z.optional()
	}).nullable(),
	restDice: e.array(e.object({
		card: R,
		slot: e.int().min(0).max(20)
	})),
	gridDice: e.array(e.object({
		card: R,
		slot: e.int().min(0).max(20)
	})),
	storyTest: e.object({
		paySkills: e.array(z),
		repeatSkill: z.nullable(),
		count: e.int().positive(),
		rounds: e.int().nonnegative(),
		maxRolls: e.int().positive(),
		faces: e.array(z),
		remaining: e.int().nonnegative(),
		done: e.boolean(),
		bait: e.boolean(),
		sourceBoost: e.boolean(),
		baitUsed: e.boolean(),
		source: R,
		partialRounds: e.int().nonnegative(),
		rerollable: e.array(e.int().nonnegative())
	}).nullable(),
	sentientTrial: e.object({
		card: R,
		faces: e.array(z),
		remaining: e.int().nonnegative(),
		success: e.boolean(),
		bond: e.boolean()
	}).nullable(),
	protection: e.array(e.object({
		kind: e.string(),
		amount: e.int().positive()
	})),
	animalProtection: e.array(e.enum([
		"health",
		"morale",
		"cold",
		"hypoxia"
	])),
	placement: e.object({
		source: R,
		kind: e.enum(["gain", "drain"]),
		remaining: e.int().positive(),
		options: e.array(R)
	}).nullable(),
	arrival: e.object({
		curse: R.nullable(),
		kind: e.string(),
		value: e.string(),
		skills: e.array(z),
		destinations: e.array(R),
		paid: e.boolean(),
		ignored: e.boolean()
	}).nullable(),
	location: e.int().min(0).max(1714),
	capsules: e.array(z),
	landingDice: e.tuple([z, z]).nullable(),
	missionDice: e.tuple([z, z]).optional(),
	options: e.array(e.object({
		id: e.string(),
		label: e.string(),
		labelZh: e.string(),
		book: e.string(),
		source: R,
		water: e.boolean().optional(),
		condition: e.object({
			en: e.string(),
			zh: e.string()
		}).optional()
	})),
	current: e.object({
		id: e.string(),
		label: e.string(),
		labelZh: e.string(),
		cost: e.union([e.number(), e.string()]),
		source: R,
		canClearObstacle: e.boolean(),
		canPayCoin: e.boolean(),
		coinPrice: e.int().nonnegative(),
		coinDiscount: e.enum([
			"one",
			"zero",
			"none"
		])
	}).nullable(),
	experience: e.array(R),
	powerOptions: e.array(e.object({
		id: e.string(),
		label: e.string(),
		labelZh: e.string()
	})),
	coLocated: e.array(e.string()),
	pathQuest: e.boolean(),
	pathStations: e.array(e.object({
		symbol: e.int().min(0).max(8),
		location: R
	})),
	canStartPearlDefense: e.boolean(),
	pearlDefense: e.object({
		remaining: e.array(z),
		active: e.boolean()
	}).nullable(),
	personalGoals: e.array(R),
	questProgress: e.array(e.object({
		card: R,
		tokens: e.int().nonnegative(),
		kind: e.enum([
			"timer",
			"journey",
			"underwater",
			"counter"
		]),
		canRecord: e.boolean()
	})),
	expiredQuests: e.array(R),
	abandonableQuests: e.array(R),
	rotatedPending: e.array(R),
	replacementCells: e.record(e.string(), e.int().min(-1).max(8)),
	passage: e.object({
		text: e.string(),
		zh: e.string().optional(),
		choices: e.array(e.string()),
		choicesZh: e.array(e.string()).optional(),
		effects: e.array(Hi),
		blocked: e.boolean(),
		hasFollowing: e.boolean(),
		returnsToAction: e.boolean(),
		allowedChoices: e.array(e.int().nonnegative()),
		payableChoices: e.array(e.int().nonnegative()),
		skillPaymentChoices: e.array(e.int().nonnegative())
	}).nullable(),
	pendingCards: e.array(R),
	notes: e.string(),
	visitedCount: e.int().nonnegative(),
	canContinue: e.enum([
		"no",
		"may",
		"must"
	]),
	lastChanceUsed: e.boolean(),
	skirmOptions: e.array(e.int()),
	skirmDice: e.array(z),
	skirmSide: e.int().nullable(),
	skirmPrevious: z.nullable(),
	skirmRolled: z.nullable(),
	crisisText: e.string(),
	missionConclusion: e.string(),
	missionConclusionZh: e.string(),
	bookPages: e.array(e.int().min(1).max(50)),
	skillResult: z.nullable(),
	needsReserveRoom: e.boolean()
});
//#endregion
//#region src/games/vantage/rules.ts
function B(e, n) {
	return t(e.seed, e.cursor++, n);
}
function Wi(e) {
	return [B(e, 6), B(e, 6)];
}
function V(e) {
	return {
		card: e,
		boost: 0,
		dice: {}
	};
}
function H(e, t) {
	e.event = t, e.eventSeq++;
}
function U(e) {
	return e.arrivalSecret ? e.players.find((t) => t.rid === e.arrivalReader) : e.players[e.turn];
}
function W(e) {
	return e.grid[4];
}
function Gi(e, t, n) {
	let r = W(t);
	n === 1453 ? t.previousCharacter = t.character : delete t.previousCharacter, e.pool += Object.keys(r.dice).length, t.grid[4] = {
		card: n,
		boost: r.boost,
		dice: {}
	}, t.character = n;
}
function Ki(e) {
	return e.character === 1453 ? [] : e.grid.filter((e) => !!e && e.card >= 1454 && e.card <= 1459 && e.boost >= 3);
}
function G(e) {
	return [
		...e.grid.filter((e) => e !== null),
		...e.reserve,
		...e.supply
	];
}
function qi(e) {
	let t = G(e);
	return [...t, ...t.flatMap((e) => e.tucked ?? [])];
}
function Ji(e, t) {
	return e.players.flatMap(qi).find((e) => e.card === t) ?? e.center.find((e) => e.card === t);
}
function Yi(e, t, n, r, i) {
	let a = [];
	for (let n of [...G(t)]) if (i(n)) {
		let r = t.grid.includes(n) ? "grid" : t.reserve.includes(n) ? "reserve" : "supply";
		Y(e, t, n.card), n.dice = {};
		for (let e of n.tucked ?? []) e.dice = {};
		a.push({
			held: n,
			zone: r
		});
	}
	a.length && (e.personal[t.rid].storedBelongings ??= []).push({
		location: n,
		returnOnLeave: r,
		cards: a
	});
}
function Xi(e, t, n, r) {
	let i = e.personal[t.rid], a = (i.storedBelongings ?? []).filter((e) => e.returnOnLeave ? e.location === n && n !== r : e.location === r);
	i.storedBelongings = i.storedBelongings?.filter((e) => !a.includes(e));
	for (let n of a) for (let { held: r, zone: i } of n.cards) i === "supply" ? t.supply.push(r) : t.rid === U(e).rid ? (e.pendingCards.push(r.card), e.pendingInstances[r.card] = r) : (e.deliveries[t.rid] ??= []).push(r);
}
function Zi(e, t, n = "gain", r, i) {
	let a = C[B(e, 6)];
	ea(e, t) ? e.skillRolls.push({
		rid: t.rid,
		face: a,
		kind: n,
		match: r,
		testIndex: i,
		group: e.eventSeq
	}) : Qi(e, t, {
		face: a,
		kind: n,
		match: r,
		testIndex: i
	});
}
function Qi(e, t, n) {
	if (n.kind === "printed") ji(e, t, n.face, {
		gainSkill: (t, n, r) => F(e, t, n, r),
		gainStat: K,
		putInCenter: ei
	});
	else if (n.kind === "pearl") {
		let r = e.pearlDefense;
		r && r.rid === t.rid && (r.remaining.includes(n.face) || r.remaining.push(n.face), r.rolling--);
	} else if (n.kind === "hatch") {
		let r = e.eggHatches?.find((e) => e.rid === t.rid && e.egg === n.testIndex), i = ke[n.testIndex ?? 0];
		r && typeof i == "object" && (r.animal = i[n.face]);
	} else if (n.kind === "skirm") e.skirm && n.testIndex !== void 0 && (e.skirm.dice[0][n.testIndex] = n.face, e.skirm.stage === "tome" && e.skirm.turn === 0 && e.skirm.pending?.index === n.testIndex && (e.skirm.pending.rolled = n.face));
	else if (n.kind === "mini") e.miniGame && n.miniField !== void 0 && n.testIndex !== void 0 && (e.miniGame[n.miniField][n.testIndex] = n.face);
	else if (n.kind === "rune") (e.runeFaces ??= []).push(n.face), n.face === n.match && F(e, t, n.face, 1);
	else if (n.kind === "crew") F(e, t, n.face, 1), e.crewSharing.faces[t.rid] = n.face, na(e);
	else if (n.kind === "test") {
		let r = e.storyTest;
		if (n.testIndex === void 0 ? r.faces.push(n.face) : r.faces[n.testIndex] = n.face, r.remaining--, !r.remaining && r.spec.repeatSkill) {
			let n = le(r).filter((e) => e === r.spec.repeatSkill).length;
			F(e, t, r.spec.repeatSkill, n), r.done = n === 0;
		}
	} else if (n.kind === "trial") {
		let r = e.sentientTrial;
		if (r.faces.push(n.face), r.remaining--, r.success ||= n.face === "engage", !r.remaining && r.success) {
			fr(e, t, 1623);
			let n = t.grid.find((e) => e?.card === r.card);
			n && (r.bond ? n.bonded = !0 : q(n, 1));
		}
	} else n.kind === "result" || n.kind === "resultGain" ? (e.skillResult = n.face, n.kind === "resultGain" && F(e, t, n.face, 1)) : (n.kind === "gain" || n.face === n.match) && F(e, t, n.face, 1);
}
function $i(e, t, n) {
	if (e.miniGame && n.length && delete e.miniGame.bonusSkills, e.miniGame && ea(e, t)) for (let r of n) e.skillRolls.push({
		rid: t.rid,
		kind: "mini",
		face: e.miniGame[r.field][r.index],
		testIndex: r.index,
		miniField: r.field,
		group: e.eventSeq
	});
}
function ea(e, t) {
	return t.grid.some((e) => e && [924, 1354].includes(e.card) && e.boost > 0) || e.players.some((e) => e.grid.some((e) => e && e.boost > 0 && ([1381, 1384].includes(e.card) || e.card === 997 && Object.values(e.skills ?? {}).some((e) => e > 0))));
}
function ta(e) {
	let t = e.skirm, n = e.players.find((e) => e.rid === t?.controllers[0]);
	if (t && n && ea(e, n)) for (let r of new Set(t.rolled?.filter((e) => e.side === 0).map((e) => e.index))) e.skillRolls.push({
		rid: n.rid,
		kind: "skirm",
		face: t.dice[0][r],
		testIndex: r,
		group: e.eventSeq
	});
}
function na(e) {
	let t = e.crewSharing;
	if (!t || Object.keys(t.decisions).length !== e.players.length) return;
	let n = e.players.filter((e) => t.decisions[e.rid]);
	if (!n.some((e) => !t.faces[e.rid])) {
		e.crewSharing = null;
		for (let r of n) n.some((e) => e.rid !== r.rid && t.faces[e.rid] === t.faces[r.rid]) ? K(e, r, "morale", 1) : !t.tides && !e.center.some((e) => e.card === 1599) && e.center.push(V(1599));
		if (t.tides) for (let r of n) la(e, r, {
			move: 51,
			look: 57,
			engage: 478,
			help: 450,
			take: 364,
			overpower: 429
		}[t.faces[r.rid]], void 0, !1);
	}
}
function ra(e) {
	if (e.phase !== "story" || !e.passage) return !1;
	let t = k(e.passage.node, le(e.storyTest));
	return !t.blocked && t.effects.find((t, n) => !e.passage.applied.includes(n))?.kind === "stowCards";
}
function ia(e, t, n) {
	n < 1 || !e.energySwords?.[t.rid] || (e.placementChoices.push({
		rid: t.rid,
		source: 1200,
		kind: "gain",
		remaining: n,
		once: !1,
		used: [],
		exclude: [1200]
	}), ba(e));
}
function aa(e, t, n) {
	return e.protection.filter((e) => e.rid === t.rid && e.kind === n).reduce((e, t) => e + t.amount, 0);
}
function oa(e, t, n, r, i = !1) {
	let a = r;
	if (n === "heat" && r > 0) for (let e of t.grid) e && ke[e.card] && q(e, 1);
	if (kr(t, n, i) || e.personal[t.rid].animalProtection?.includes(n) || t.rid === U(e).rid && e.challenge?.bonus?.immunity === n || n === "heat" && e.personal[t.rid].heatImmuneHere === e.personal[t.rid].location) return ia(e, t, r), 0;
	for (let i of e.protection.filter((e) => e.rid === t.rid && e.kind === n)) {
		let e = Math.min(r, i.amount);
		i.amount -= e, r -= e;
	}
	return e.protection = e.protection.filter((e) => e.amount > 0), ia(e, t, a - r), r;
}
function sa(e, t, n) {
	let r = e.arrivals.filter((e) => e.rid === t.rid && !e.curse && n(e));
	e.arrivals = e.arrivals.filter((e) => !r.includes(e)), ia(e, t, r.filter((e) => e.instruction.kind === "damage" || ["stat", "payment"].includes(e.instruction.kind) && e.instruction.value === "health").length);
}
function K(e, t, n, r) {
	if (!(r < 0 && n === "time" && Pr(e.personal[t.rid].location))) {
		r < 0 && (n === "time" || n === "health") && e.challenge && t.rid === U(e).rid && (e.challenge.lostTimeOrHealth = !0), r < 0 && n === "health" && t.stats.health > 0 && (e.personal[t.rid].healthLostThisTurn = !0, e.recentHealthLoss = {
			rid: t.rid,
			serial: e.eventSeq + 1
		}, e.healthMorale?.[t.rid] && K(e, t, "morale", Math.min(t.stats.health, -r)));
		for (let i = 0; i < Math.max(0, t.stats[n] + r - 6); i++) Zi(e, t);
		t.stats[n] = Math.max(0, Math.min(6, t.stats[n] + r));
	}
}
function ca(e) {
	for (let t of e.players) for (let e of G(t)) e.dice = {};
	e.summoning?.solo && (e.summoning.solo.dice = {}), e.pool = 8 + 2 * e.players.length - ri(e) - (e.boxedDice ?? 0), e.penaltyDice = 0, e.penaltyFaces = [];
}
function la(e, t, n, r, i = !0) {
	n === 589 && (e.milestones.founderTemple = !0);
	let a = e.personal[t.rid].location, o = (Object.values(E[a]?.exits ?? {}).some((e) => e.destination === n) || e.challenge?.source === a && D[e.challenge.id]?.book === "depart" && Ve(e.challenge.id, e.personal[t.rid].dungeonOrigin).includes(n)) && e.players.some((e) => e.supply.some((e) => e.card === 1290 && e.origin === a)), s = [t, ...e.players.filter((n) => i && t.rid === U(e).rid && n.rid !== t.rid && e.followConsent.includes(n.rid) && e.personal[n.rid].location === a)];
	for (let t of s) {
		let i = e.personal[t.rid];
		i.skyOrigin = null, i.towerTop = !1, i.location = n, mr(n) && fr(e, t, 1613), pn(n) && fr(e, t, 1622), Xi(e, t, a, n), a !== n && (i.actionBlocks = i.actionBlocks?.filter((e) => !e.untilLeave || e.location !== a)), i.heatImmuneHere !== n && delete i.heatImmuneHere, i.departureLimit?.location !== n && delete i.departureLimit, t.rid === U(e).rid && a === 682 && n === 586 && e.challenge?.questEntryRetry && (i.questLocations[1640] ??= []).push(682), Sr(e, t, n), r === "enterDungeon" && (i.dungeonOrigin = a), r === "leaveDungeon" && (i.dungeonOrigin = null), da(e, t, n, !i.visited.includes(n)), o && sa(e, t, (e) => e.location === n && e.instruction.kind === "damage" && e.instruction.value === "hypoxia"), i.ignoreNextHypoxia &&= (sa(e, t, (e) => e.location === n && e.instruction.value === "hypoxia"), !1), i.visited.includes(n) || i.visited.push(n);
	}
	e.followConsent = [], e.slotPermission = [];
}
function ua(e, t, n = !1) {
	let r = e.personal[t.rid].location, i = On(r);
	if (i === null) return !1;
	let a = e.players.filter((n) => n.rid === t.rid || t.rid === U(e).rid && e.followConsent.includes(n.rid) && e.personal[n.rid].location === r).map((e) => e.rid);
	la(e, t, i);
	for (let t of a) e.personal[t].skyOrigin = r;
	return n && sa(e, t, (e) => e.location === i && e.instruction.value === "hypoxia"), !0;
}
function da(e, t, n, r) {
	for (let i of Nr(n, r)) (!i.requiredCards || G(t).some((e) => i.requiredCards.includes(e.card))) && e.arrivals.push({
		rid: t.rid,
		location: n,
		instruction: i,
		paid: !1
	});
	for (let r of [
		1627,
		1629,
		1630,
		1638,
		1641,
		1643,
		1648,
		1651,
		1658,
		1661,
		1665,
		1666,
		1678,
		1697,
		1700,
		1702,
		1703
	]) br(t, r) && Cr(e, t, r) && e.arrivals.push({
		rid: t.rid,
		location: n,
		instruction: {
			kind: "secret",
			value: String(r)
		},
		paid: !1
	});
}
function fa(e, t) {
	return e.arrivals.length ? (e.arrivalResume = t, e.phase = "arrival", !0) : !1;
}
function pa(e) {
	if (e.arrivals.length || e.pendingCards.length || ma(e) || e.players.some(_a)) {
		e.phase = "arrival";
		return;
	}
	let t = e.arrivalEndsTurn && !e.arrivalSecret ? "nextTurn" : e.arrivalResume;
	e.arrivalResume = null, e.arrivalSecret || (e.arrivalEndsTurn = !1), t === "nextTurn" ? Ya(e) : t === "result" ? Xa(e) ? e.crisisResume = "result" : Aa(e) : (e.phase = t ?? "action", e.phase === "story" && e.passage && (e.continuation = k(e.passage.node, le(e.storyTest)).continuation, e.locationContinuation = !!e.challenge && E[e.challenge.source]?.group === "location" && D[e.challenge.id]?.book !== "depart"));
}
function ma(e) {
	return e.phase === "story" && !!e.miniGame && !e.miniGame.done || !!e.runeSurvey?.length || !!e.crewSharing || !(!e.storyTest || e.storyTest.done) || !!e.summoning?.waiting.length || e.replenishments.length > 0 || e.placementChoices.length > 0 || e.cardClaims.length > 0 || Object.values(e.deliveries).some((e) => e.length > 0);
}
function ha(e) {
	e.summoning?.solo && (e.pool += Object.keys(e.summoning.solo.dice).length), e.summoning = null;
}
function ga(e, t, n) {
	return e.players.find((e) => e.rid === n)?.grid.some((e) => e?.card === 1011 && e.boost > 0) === !0 || e.personal[t].location === e.personal[n].location || e.summoning?.caller === n && e.summoning.summoned.includes(t);
}
function _a(e) {
	return e.reserve.length + +!!e.skirm.length > jr(e);
}
function q(e, t) {
	[
		1019,
		1020,
		1021
	].includes(e.card) && e.growthAt === void 0 || (e.boost = Math.min(E[e.card].boostCapacity, e.boost + t));
}
function J(e, t, n) {
	let r = t.boost > 0 && n >= t.boost;
	if (t.boost = Math.max(0, t.boost - n), !r || t.card === 1197) return;
	let i = e.players.find((e) => e.grid.includes(t)), a = e.players.find((e) => e.grid.some((e) => e?.card === 1197 && e.boost > 0));
	i && a && e.replenishments.push({
		rid: a.rid,
		owner: i.rid,
		card: t.card
	});
}
function va(e) {
	e.replenishments = e.replenishments.filter((t) => e.players.some((e) => e.rid === t.rid && e.grid.some((e) => e?.card === 1197 && e.boost > 0)) && e.players.some((e) => e.rid === t.owner && e.grid.some((e) => e?.card === t.card && e.boost < E[e.card].boostCapacity)));
}
function ya(e, t) {
	let n = e.players.find((e) => e.rid === t.rid);
	if (t.kind === "gain") return n.grid.filter((e) => !!e && !t.exclude?.includes(e.card) && e.boost < E[e.card].boostCapacity);
	let r = n.grid.findIndex((e) => e?.card === t.source);
	return r < 0 || n.grid[r].boost >= E[t.source].boostCapacity ? [] : Ee(r).flatMap((e) => {
		let r = n.grid[e];
		return r && r.boost > 0 && (!t.once || !t.used.includes(r.card)) ? [r] : [];
	});
}
function ba(e) {
	e.placementChoices = e.placementChoices.filter((t) => t.remaining > 0 && ya(e, t).length > 0);
}
function xa(e, t, n, r) {
	let i = n.card;
	i === 987 && (n.rotated = !1), q(n, n.initialBoost ?? E[i].placedBoost);
	let a = Ee(r).flatMap((e) => t.grid[e] ? [t.grid[e]] : []), o = t.grid.filter((e) => !!e);
	if (i === 867 && (q(W(t), 1), K(e, t, "health", 1)), i === 1103) {
		for (let [e, n] of t.grid.entries()) n && Math.floor(e / 3) === Math.floor(r / 3) && q(n, 1);
		q(W(t), 1);
	}
	if (i === 1104) {
		for (let [e, n] of t.grid.entries()) n && e % 3 == r % 3 && q(n, 1);
		K(e, t, "time", -1);
	}
	i === 1122 && K(e, t, "morale", 2), De.includes(i) && q(n, a.length);
	let s = Ae[i];
	s && q(n, o.filter((e) => _e(e.card, t).includes(s)).length), i === 1024 && q(n, o.filter((e) => P(e.card, "weapon")).length);
	let c = i === 897 ? "animal" : i === 968 ? "map" : i === 1039 ? "sentient" : null;
	if (c) for (let e of o) P(e.card, c) && q(e, 1);
	if (i === 874) for (let e of o) _e(e.card, t).includes("circuit") && q(e, 1);
	if ([
		1041,
		1084,
		1085,
		1086,
		1087
	].includes(i)) for (let e of a) q(e, 1);
	if (Fe(i)) for (let [e, n] of t.grid.entries()) n && e % 3 == r % 3 && q(n, 1);
	let l = je[i];
	if (l) for (let t of e.players) for (let e of t.grid) e && _e(e.card, t).includes(l) && q(e, 1);
	if (i === 1105 || i === 1106) {
		for (let e of i === 1105 ? [n, ...a] : o.filter((e) => e !== n)) q(e, 1);
		K(e, t, "time", -1), K(e, t, "morale", -1), i === 1106 && K(e, t, "health", -1);
	}
	if (i === 1117) for (let n of [...o]) Dr(n.card) && Y(e, t, n.card);
	if (Oe.includes(i)) for (let t of e.players) e.placementChoices.push({
		rid: t.rid,
		source: i,
		kind: "gain",
		remaining: 1,
		once: !1,
		used: []
	});
	(i === 948 || Me[i]) && e.placementChoices.push({
		rid: t.rid,
		source: i,
		kind: "drain",
		remaining: Math.min(3, a.reduce((e, t) => e + (i === 948 ? Number(t.boost > 0) : t.boost), 0)),
		once: i === 948,
		used: []
	}), ba(e);
}
function Sa(e, t = !1) {
	t && e.replenishments.length && !e.replenishResume && (e.replenishResume = "endAction");
	for (let n of e.players) for (let r of [...n.grid, ...n.supply.filter((e) => e.asylumAt !== void 0)]) {
		if (!r || r.boost > 0 || !Pe(r.card) || e.placementChoices.some((e) => e.source === r.card) || e.replenishments.some((e) => e.card === r.card) || cr(r.card) && !t) continue;
		let i = Me[r.card];
		Y(e, n, r.card), i && (K(e, n, i.stat, 1), F(e, n, i.skill, 1));
	}
}
function Ca(e) {
	if (!(e.pendingCards.length || e.arrivals.length || e.skillRolls.length || ma(e))) {
		for (let t of e.players) for (let n of t.grid) if (n && [
			1019,
			1020,
			1021
		].includes(n.card) && n.growthAt === e.personal[t.rid].location && n.boost === E[n.card].boostCapacity) {
			let r = t.grid.indexOf(n), i = {
				1019: 1696,
				1020: 1150,
				1021: 1698
			}[n.card];
			Y(e, t, n.card), X(e, i, t), E[i].portrait && (e.pendingCards.includes(i) || e.deliveries[t.rid]?.some((e) => e.card === i)) && (e.replacementCells[i] = r);
			return;
		}
	}
}
function wa(e) {
	if (e.phase === "done" || e.phase === "crisis" || e.phase === "landing" || e.phase === "launch" || e.phase === "experience") return;
	for (let t of e.players) for (let [n, r] of t.grid.entries()) r && ke[r.card] && r.boost >= E[r.card].boostCapacity && !e.eggHatches?.some((e) => e.egg === r.card) && (e.eggHatches ??= []).push({
		rid: t.rid,
		egg: r.card,
		cell: n,
		animal: typeof ke[r.card] == "number" ? ke[r.card] : void 0
	});
	if (e.pendingCards.length || e.skillRolls.length || e.arrivals.length || e.arrivalSecret || ma(e)) return;
	let t = e.eggHatches?.[0];
	if (!t) return;
	let n = e.players.find((e) => e.rid === t.rid);
	if (!(t.cell < 0 ? n.reserve.some((e) => e.card === t.egg) : n.grid[t.cell]?.card === t.egg)) {
		e.eggHatches.shift();
		return;
	}
	if (t.egg === 977 && br(n, 1679)) {
		t.questRead || (t.questRead = !0, e.arrivals.push({
			rid: n.rid,
			location: e.personal[n.rid].location,
			instruction: {
				kind: "secret",
				value: "1679"
			},
			paid: !1
		}), fa(e, e.phase === "arrival" ? e.arrivalResume ?? "action" : e.phase));
		return;
	}
	t.animal === void 0 && !t.rolled && (t.rolled = !0, Zi(e, n, "hatch", void 0, t.egg)), t.animal !== void 0 && (Y(e, n, t.egg), e.eggHatches.shift(), X(e, t.animal, n), (e.pendingCards.includes(t.animal) || e.deliveries[n.rid]?.some((e) => e.card === t.animal) || e.cardClaims.some((e) => e.card === t.animal && e.requester === n.rid)) && (e.replacementCells[t.animal] = t.cell), H(e, "gain"));
}
function Ta(e, t) {
	let n = e.elemental;
	if (!n) return;
	let r = e.personal[t.rid];
	r.forbiddenLocations.includes(n.location) || r.forbiddenLocations.push(n.location), r.usedActions = r.usedActions.filter((e) => e !== "o" + n.location + ":0"), e.elemental = null;
}
function Ea(e, t, n) {
	let r = e.milestones.sentientOrigins[t] ?? n, i = /* @__PURE__ */ new Set([n, "card:" + t]);
	e.milestones.sentientOrigins[t] = r, e.challenge && (e.milestones.sentientOrigins[e.challenge.source] = r);
	for (let t of Object.keys(e.milestones.sentientOrigins)) i.has(e.milestones.sentientOrigins[Number(t)]) && (e.milestones.sentientOrigins[Number(t)] = r);
	e.milestones.sentients = [...new Set(e.milestones.sentients.map((e) => i.has(e) ? r : e))], e.challenge?.interaction && (e.challenge.interaction.sentients = e.challenge.interaction.sentients.map((e) => i.has(e) ? r : e));
}
function Da(e, t, n, r, i) {
	let a = E[n.card], o = a.portrait || n.rotated;
	if (r === "center") {
		if (!a.goalType) return !1;
		e.center.push(n);
	} else if (n.asylumAt !== void 0 && r === "supply") n.placed || q(n, n.initialBoost ?? a.placedBoost), n.placed = !0, t.supply.push(n);
	else if (!o && r === "supply") Er(n.card) && (n.origin ??= e.personal[t.rid].location, n.placed || q(n, a.placedBoost), n.placed = !0), t.supply.push(n), xr(e, t, n);
	else if (o && r === "reserve" && !Dr(n.card) && ![
		1103,
		1104,
		1105,
		1106
	].includes(n.card) && !_a(t)) e.pool += Object.keys(n.dice).length, n.dice = {}, t.reserve.push(n), n.placed = !0;
	else if (o && r === "grid" && i !== void 0 && t.grid[i] === null) t.grid[i] = n, n.placed || xa(e, t, n, i), n.placed = !0;
	else return !1;
	e.milestones.acquiredCards.includes(n.card) || e.milestones.acquiredCards.push(n.card);
	let s = e.personal[t.rid].acquiredCards ??= [];
	s.includes(n.card) || s.push(n.card);
	let c = e.challenge?.interaction;
	return Dr(n.card) && c && (c.curse = !0), a.group === "sentient" && c?.sentients.length === 1 && c.sentients[0] !== "traveler" && Ea(e, n.card, c.sentients[0]), n.rotated && n.card >= 1611 && n.card <= 1626 && !e.milestones.objectives.includes(n.card) && e.milestones.objectives.push(n.card), n.rotated && n.card === 1706 && !e.milestones.quests.includes(1706) && e.milestones.quests.push(1706), t.grid.every(Boolean) && !e.center.some((e) => e.card === 1705) && e.center.push(V(1705)), !0;
}
function Y(e, t, n, r = !0) {
	if (n === t.character) return !1;
	let i = qi(t).find((e) => e.card === n);
	if (!i) return !1;
	r && (e.pool += Object.keys(i.dice).length);
	for (let e of G(t)) e.tucked &&= e.tucked.filter((e) => e.card !== n);
	return r && (e.pool += (i.tucked ?? []).reduce((e, t) => e + Object.keys(t.dice).length, 0)), t.grid = t.grid.map((e) => e?.card === n ? null : e), t.reserve = t.reserve.filter((e) => e.card !== n), t.supply = t.supply.filter((e) => e.card !== n), !0;
}
function X(e, t, n = U(e)) {
	if (Dr(t) && Or(n) || !E[t] || e.spentExperience.includes(t) || e.pendingCards.includes(t) || e.cardClaims.some((e) => e.card === t) || Object.values(e.personal).some((e) => e.storedBelongings?.some((e) => e.cards.some(({ held: e }) => e.card === t || e.tucked?.some((e) => e.card === t))))) return;
	let r = e.players.find((e) => qi(e).some((e) => e.card === t));
	if (r && r.rid !== n.rid) {
		e.cardClaims.push({
			card: t,
			owner: r.rid,
			requester: n.rid
		});
		return;
	}
	if (r) {
		let i = e.challenge?.interaction;
		Dr(t) && i && (i.curse = !0), E[t].group === "sentient" && i?.sentients.length === 1 && i.sentients[0] !== "traveler" && Ea(e, t, i.sentients[0]);
		let a = r.grid.find((e) => e?.card === t);
		if (a) a.boost = Math.min(E[t].boostCapacity, a.boost + 1);
		else if (r.reserve.some((e) => e.card === t) || G(r).some((e) => e.tucked?.some((e) => e.card === t))) {
			if (r.reserve.some((e) => e.card === t && e.hiddenAt !== void 0)) return;
			Y(e, r, t), n.rid === U(e).rid ? e.pendingCards.push(t) : (e.deliveries[n.rid] ??= []).push(V(t));
		}
		return;
	}
	e.center.some((e) => e.card === t) || (n.rid === U(e).rid ? (e.pendingCards.push(t), [
		977,
		1012,
		1160,
		1654
	].includes(t) && (e.pendingInstances[t] = {
		...V(t),
		acquiredAt: e.personal[n.rid].location
	})) : (e.deliveries[n.rid] ??= []).push({
		...V(t),
		...[
			977,
			1012,
			1160,
			1654
		].includes(t) ? { acquiredAt: e.personal[n.rid].location } : {}
	}));
}
function Oa(e, t, n = "", r = [], i = []) {
	e.passage = {
		node: t,
		applied: i,
		entry: n,
		following: t.after ? [{
			node: t.after,
			entry: n,
			applied: []
		}, ...r] : r
	}, e.phase = "story", e.continuation = k(t).continuation, H(e, "story"), t.closeBranch && !e.personal[U(e).rid].chosenBranches?.includes(t.closeBranch) && (e.personal[U(e).rid].chosenBranches ??= []).push(t.closeBranch);
	for (let n of t.personalFacts ?? []) fr(e, U(e), n);
	if (t.personalFacts?.includes(1619) && E[D[n]?.card]?.id === 448) for (let t of e.players) {
		let n = t.supply.find((e) => e.card === 1634 && !e.rotated);
		n && (n.tokens = 0, e.personal[t.rid].questFlags.includes(1634) || e.personal[t.rid].questFlags.push(1634));
	}
	if (t.trialWelcome) {
		let n = e.personal[U(e).rid].welcomedTrials ??= [];
		n.includes(t.trialWelcome) || n.push(t.trialWelcome);
	}
	e.locationContinuation = !!e.challenge && E[e.challenge.source]?.group === "location" && D[e.challenge.id]?.book !== "depart", t.rescueMission && e.mission === 1596 && (e.milestones.travelerRescue = !0), t.diplomacy && (e.milestones.diplomacy = !0), t.traveler && e.challenge?.interaction && (e.challenge.interaction.traveler = !0, e.challenge.interaction.sentients = ["traveler"]), /\borigin of life\b/i.test(t.text) && (e.milestones.origin = !0), (n === "o732:0" || n === "o791:0") && /cut off the signal/i.test(t.text) && (e.milestones.signalCut = !0);
}
function ka(e) {
	let t = e.pearlDefense;
	t?.active && (t.remaining = t.remaining.filter((e) => e !== t.active), delete t.active, delete t.awaitingArrival, e.challenge = null, e.passage = null, e.storyTest = null, e.continuation = "must", e.freeReading = !1, e.restrictedActions = [], e.restrictedBooks = [], e.restrictedDirections = [], e.restrictedVerbs = [], e.restrictedSkill = null, e.restrictedExclude = void 0, e.restrictedExcludes = [], e.restrictedWater = !1, t.remaining.length ? (e.phase = "action", H(e, "story")) : (e.pearlDefense = void 0, e.freeReading = !0, Oa(e, D["s1681:0"].node, "s1681:0")));
}
function Aa(e, t = []) {
	let n = e.challenge;
	if (n.flourish) {
		e.powerReward = { rid: U(e).rid }, e.phase = "story";
		return;
	}
	if (e.restrictedVerbs = [], e.restrictedActions = [], n.direct !== null) {
		if (n.alreadyMoved || la(e, U(e), n.direct), e.pearlDefense?.active) {
			e.pearlDefense.awaitingArrival = !0, fa(e, "action") || ka(e);
			return;
		}
		e.challenge = null, fa(e, "nextTurn") || Ya(e);
		return;
	}
	let r = D[n.id];
	n.id === "h676:0" && !e.encounterMemory?.includes("console676") && (e.encounterMemory ??= []).push("console676"), si[n.source] && r.book !== "depart" && (e.milestones.elementalAction = !0), n.source === e.mission && /^PIVOT\b/.test(r.label) && (e.pivotUsed = !0);
	let i = e.personal[U(e).rid], a = i.completedActions ??= [];
	a.includes(n.id) || a.push(n.id), r.trial && (i.attemptedTrials ??= []).push(r.trial), (n.id === "l1645:0" || n.id === "e1645:0") && !i.usedActions.includes(n.id) && i.usedActions.push(n.id), n.id === "o703:0" && br(U(e), 1635) && !i.questFlags.includes(1635) && i.questFlags.push(1635), r.book === "help" && n.source >= 1435 && n.source <= 1452 && i.usedActions.push("h" + (1435 + fe(n.source)) + ":0"), (r.once || E[n.source]?.group === "location" && r.book !== "depart" && !/always available/i.test(r.label)) && i.usedActions.push(n.id), E[n.source]?.group === "location" && r.book !== "depart" && !i.usedLocations.includes(n.source) && i.usedLocations.push(n.source);
	let o = n.id === "o703:0" && br(U(e), 1635) && Cr(e, U(e), 1635) ? D["s1635:0"] : null;
	Oa(e, n.questEntryRetry ? _r(n.id, r.node) : r.node, n.id, o ? [{
		node: o.node,
		entry: o.id,
		applied: []
	}, ...t] : t);
}
function ja(e) {
	return Number(e.passage?.entry.match(/^[a-z](\d+):/)?.[1]);
}
function Ma(e, t) {
	return Object.fromEntries(C.map((n) => [n, e.players.reduce((e, r) => e + (r.rid === t.rid ? 0 : r.skills[n]), 0)]));
}
function Na(e, t) {
	return Object.fromEntries(C.map((n) => [n, e.players.reduce((r, i) => r + (i.rid === U(e).rid ? 0 : Math.min(i.skills[n], t[i.rid]?.[n] ?? 0)), 0)]));
}
function Pa(e) {
	let t = e.passage?.node.choices[e.passage.payment?.index ?? -1], n = t ? oe(t) : [];
	return n === "unsupported" ? [] : n.flatMap((e) => C.includes(e.kind) ? [{
		skill: e.kind,
		amount: e.amount
	}] : []);
}
function Fa(e, t, n, r = !1, i = 0) {
	let a = oe(n), o = a === "unsupported" ? null : a.find((e) => e.kind === "coin");
	return (r && o || !n.coins || e.coins + (o ? i : 0) >= (n.coins.min ?? 0) && e.coins <= (n.coins.max ?? Infinity)) && (!n.actionCoins || t >= (n.actionCoins.min ?? 0) && t <= (n.actionCoins.max ?? Infinity)) && (!n.barterAvailable || an(e, n.barterAvailable).length >= n.barterAvailable.min && an(e, n.barterAvailable).reduce((e, t) => e + (E[t].value ?? 0), 0) >= (n.barterAvailable.minTotal ?? 0));
}
function Ia(e, t) {
	if (!t) return !0;
	let n = e.storyTest;
	if (!n?.done) return !1;
	let r = le(n), i = (t.anyOf ? r.filter((e) => t.anyOf.includes(e)).length : t.skill ? r.filter((e) => e === t.skill).length : Math.max(...C.map((e) => r.filter((t) => t === e).length))) - (t.difference ? r.filter((e) => e === t.difference).length : 0);
	return i >= t.min && (t.max === void 0 || i <= t.max);
}
function La(e) {
	return e.grid.flatMap((e) => e ? Object.keys(e.dice).map((t) => ({
		card: e.card,
		slot: Number(t)
	})) : []);
}
function Ra(e, t) {
	return La(t).filter((n) => (![
		954,
		971,
		1040
	].includes(e.challenge?.source ?? 0) || n.card !== e.challenge?.source) && !e.challenge?.placedSlots?.some((e) => e.rid === t.rid && e.card === n.card && e.slot === n.slot));
}
function za(e, t) {
	return !!e.passage?.node.boostChoices && !t.grid.some((t) => t?.card === ja(e) && t.boost > 0);
}
function Ba(e, t) {
	let n = Object.entries(E[e.personal[t.rid].location]?.exits ?? {}).flatMap(([t, n]) => (!e.passage?.node.adjacentDirections || e.passage.node.adjacentDirections.includes(t)) && n.availability === "direct_adjacent" && n.destination !== null ? [{
		id: "exit:" + t,
		label: t,
		labelZh: "",
		source: n.destination
	}] : []);
	for (let t of e.passage?.node.scoutLocations ?? []) n.some((e) => e.source === t) || n.push({
		id: "scout:" + t,
		label: String(t),
		labelZh: String(t),
		source: t
	});
	return n;
}
function Va(e) {
	let t = e.supply.find((e) => e.card === 1654 && !e.rotated);
	return t && [704, 718].includes(t.acquiredAt ?? 0) ? t.acquiredAt : void 0;
}
function Ha(e, t) {
	let n = e.passage?.node.copyAction;
	if (!n) return [];
	let r = D[e.passage?.node.copySpecific ?? ""];
	return r ? [{
		id: r.id,
		label: r.label,
		labelZh: r.labelZh || r.printedZh,
		book: r.book,
		source: r.card
	}] : no(e, t.rid, !0, !0).filter((r) => {
		let i = D[r.id];
		return i && i.card !== e.challenge?.ability && i.id !== e.challenge?.id && !e.copied?.trail.includes(i.id) && (!n.ownedOnly || G(t).some((e) => e.card === r.source)) && (!n.locationOnly || i.card === e.personal[t.rid].location) && (!n.books.length || n.books.includes(i.book)) && (!n.verbs.length || n.verbs.includes(i.label.match(/^[A-Z][A-Z-]+/)?.[0] ?? ""));
	}).map((e) => ({
		...e,
		label: D[e.id].label,
		labelZh: D[e.id].labelZh || e.labelZh
	}));
}
function Ua(e, t) {
	if (e.passage?.node.copyAction) return Ha(e, t);
	let n = e.passage?.node.printedAbility;
	if (n === "intimidateSword") return t.grid.flatMap((e) => e && cr(e.card) ? [{
		id: String(e.card),
		source: e.card,
		label: E[e.card].name,
		labelZh: E[e.card].nameZh
	}] : []);
	if (n === "placeFromReserve") return [{
		id: "skip",
		source: 1106,
		label: "Keep all reserved cards",
		labelZh: "保留全部储备牌"
	}, ...t.reserve.filter((e) => e.hiddenAt === void 0).map((e) => ({
		id: String(e.card),
		source: e.card,
		label: E[e.card].name,
		labelZh: E[e.card].nameZh
	}))];
	if (n === "soulstoneTravel") return [200, ...Va(t) ? [Va(t)] : []].map((e) => ({
		id: "soulstone:" + e,
		label: "Go to location " + e,
		labelZh: "前往地点" + e,
		source: e
	}));
	if (n === "escapePlan") {
		let n = new Set(e.players.flatMap((e) => qi(e).map((e) => e.card)));
		return [...e.players.flatMap((n, r) => xn(e, t.rid).includes(n.rid) ? [] : [{
			id: "join:" + n.rid,
			label: "Share an escape pod with player " + (r + 1),
			labelZh: "与" + (r + 1) + "号玩家同乘逃生舱",
			source: e.launch?.selected.includes(n.rid) ? e.personal[n.rid].escape + 2 : 2
		}]), ...Array.from({ length: 6 }, (e, t) => 1435 + t).filter((e) => !n.has(e)).map((e) => ({
			id: "character:" + e,
			label: "Reserve " + E[e].name,
			labelZh: "将" + E[e].nameZh + "放入储备",
			source: e
		}))];
	}
	return [
		"adjacent",
		"adjacentOptional",
		"scout"
	].includes(n ?? "") ? Ba(e, t) : n === "costs" || n === "outcome" ? no(e, t.rid, !0).filter((t) => D[t.id] && t.source !== e.challenge?.source) : [];
}
function Wa(e, t, n) {
	return no({
		...e,
		phase: "action",
		continuation: "must",
		restrictedActions: n.followActions ?? [],
		restrictedBooks: n.followBooks ?? [],
		restrictedDirections: n.followDirections ?? [],
		restrictedVerbs: n.followVerbs ?? [],
		restrictedSkill: n.continueSkill ?? null,
		restrictedExclude: n.followDifferent ? e.challenge?.id : void 0,
		restrictedExcludes: n.followExclude ?? [],
		restrictedWater: n.followWater ?? !1
	}, t.rid).length > 0;
}
function Ga(e, t) {
	return {
		coins: t.coins,
		stats: { ...t.stats },
		skills: { ...t.skills },
		boosts: Object.fromEntries(G(t).map((e) => [e.card, e.boost])),
		pending: [...e.pendingCards]
	};
}
function Ka(e, t, n) {
	let r = e.copied, i = ja(e);
	if (!r || i === r.ability) return;
	let a = [];
	t.coins > n.coins && a.push({
		kind: "coin",
		amount: t.coins - n.coins,
		value: ""
	});
	for (let e of w) t.stats[e] > n.stats[e] && a.push({
		kind: "stat",
		amount: t.stats[e] - n.stats[e],
		value: e
	});
	for (let e of C) t.skills[e] > n.skills[e] && a.push({
		kind: "skill",
		amount: t.skills[e] - n.skills[e],
		value: e
	});
	for (let e of G(t)) n.boosts[e.card] !== void 0 && e.boost > n.boosts[e.card] && a.push({
		kind: "boost",
		amount: e.boost - n.boosts[e.card],
		value: String(e.card)
	});
	for (let t of e.pendingCards) n.pending.includes(t) || a.push({
		kind: "card",
		amount: 1,
		value: String(t)
	});
	r.benefits.push(...a), r.assemblyEarned ||= a.some((e) => e.kind === "coin" || e.kind === "card" && E[Number(e.value)].group === "item");
}
function qa(e) {
	let t = e.passage?.node.printedAbility === "houseOccupancy" ? 1 : e.passage?.node.printedAbility === "floraForesightGroups" ? 4 : 2;
	return e.pool + e.penaltyDice >= t ? {
		pool: e.pool,
		center: e.penaltyDice
	} : {
		pool: 8 + 2 * e.players.length - ri(e),
		center: 0
	};
}
function Ja(e, t, n, r) {
	if (r === "escapePlan") {
		if (e.mission !== 1590 || e.launch?.stage !== "001" || e.launch.selected.includes(t.rid)) return !1;
		let r = Ua(e, t).find((e) => e.id === n.action);
		return r ? r.id.startsWith("join:") ? Cn(e, t.rid, r.id.slice(5)) : Da(e, t, V(r.source), "reserve") : !1;
	}
	if (r === "soulstoneTravel") {
		let r = Ua(e, t).find((e) => e.id === n.action);
		return r ? (la(e, t, r.source), !0) : !1;
	}
	if (r === "pathReward") {
		let n = t.supply.find((e) => e.card === 1673 && !e.rotated);
		if (!n || e.personal[t.rid].location !== 411) return !1;
		for (let r = 0; r < Math.min(9, n.tokens ?? 0); r++) Zi(e, t);
		return !0;
	}
	if (r === "scavengeStarter") {
		let n = [
			1299,
			1300,
			1301,
			1302,
			1303,
			1304
		].filter((t) => !e.players.some((e) => [...e.grid, ...e.reserve].some((e) => e?.card === t)));
		return n.length ? X(e, n[B(e, n.length)], t) : K(e, t, "health", 1), !0;
	}
	if (r === "hatchEgg") {
		let r = n.cards?.length === 1 ? [...t.grid, ...t.reserve].find((e) => e?.card === n.cards[0] && ke[e.card]) : void 0;
		return !r || e.eggHatches?.some((e) => e.egg === r.card) ? !1 : ((e.eggHatches ??= []).push({
			rid: t.rid,
			egg: r.card,
			cell: t.grid.indexOf(r),
			animal: typeof ke[r.card] == "number" ? ke[r.card] : void 0
		}), !0);
	}
	let i = e.personal[t.rid], a = e.challenge;
	if (r === "intimidateSword") {
		let r = t.grid.find((e) => e?.card === 888), i = t.grid.find((e) => e?.card === Number(n.action) && cr(e.card));
		if (!r || !i) return !1;
		Be(e, t, r.boost), J(e, i, Math.min(1, i.boost));
	} else if (r === "placeFromReserve") {
		if (n.action === "skip") return !0;
		let r = t.reserve.find((e) => e.card === Number(n.action) && e.hiddenAt === void 0);
		if (!r || !t.grid.some((e, t) => !e && t !== 4)) return !1;
		t.reserve = t.reserve.filter((e) => e !== r), e.pendingCards.push(r.card), e.pendingInstances[r.card] = r, (e.requiredGrid ??= []).push(r.card);
	} else if (r === "refillPrintedSource") {
		let n = t.grid.find((t) => t?.card === ja(e));
		if (!n) return !1;
		q(n, E[n.card].boostCapacity);
	} else if (r === "reservePrintedSource") {
		let n = t.grid.findIndex((t) => t?.card === ja(e));
		if (n < 0 || n === 4) return !1;
		let r = t.grid[n];
		e.pool += Object.keys(r.dice).length, r.dice = {}, t.grid[n] = null, t.reserve.push(r);
	} else if (r === "retainBrew") {
		let n = t.grid.find((t) => t?.card === ja(e));
		if (!n || E[n.card].group !== "flora" || n.boost < 1) return !1;
		J(e, n, 1);
	} else if (r === "adjacent" || r === "adjacentOptional") {
		if (r === "adjacentOptional" && n.action === "skip") return !0;
		let i = Ba(e, t).find((e) => e.id === n.action);
		if (!i) return !1;
		la(e, t, i.source), e.passage?.node.ignoreArrivalClimate && sa(e, t, (e) => e.instruction.kind === "damage");
	} else if (r === "scout") {
		let r = Ba(e, t).find((e) => e.id === n.action);
		if (!r) return !1;
		i.scouted.includes(r.source) || i.scouted.push(r.source);
	} else if (r === "nextBonus") e.nextBonus = tn.parse(e.passage.node.nextBonus);
	else if (r === "floraForesight" || r === "floraForesightGroups") {
		if (e.foresight?.length) return !1;
		let t = r === "floraForesightGroups" ? 4 : 2;
		e.pool + e.penaltyDice < t && ca(e);
		let i = n.diceFromPool ?? Math.min(t, e.pool);
		if (i > t || i > e.pool || t - i > e.penaltyDice) return !1;
		e.pool -= i, ti(e, t - i), e.foresight = Array.from({ length: t }, () => T[B(e, 6)]), e.foresightFromPool = i;
	} else if (r === "floraChooseForesight") {
		if (e.foresight?.length !== 4 || n.line === void 0 || n.line > 1 || e.foresightFromPool === void 0) return !1;
		let t = [n.line * 2, n.line * 2 + 1], r = e.foresight;
		for (let n = 0; n < 4; n++) t.includes(n) || (n < e.foresightFromPool ? e.pool++ : ei(e, r[n]));
		e.foresight = t.map((e) => r[e]), e.foresightFromPool = void 0;
	} else if (r === "floraDiscard") ei(e, ...e.foresight ?? []), e.foresight = [];
	else if (r === "floraRefreshCharacter" || r === "floraRefreshAdjacent") {
		let n = t.grid.findIndex((t) => t?.card === ja(e));
		if (n < 0) return !1;
		let i = r === "floraRefreshCharacter" ? [W(t)] : Ee(n).flatMap((e) => t.grid[e] ? [t.grid[e]] : []);
		for (let t of i) e.pool += Object.keys(t.dice).length, t.dice = {};
	} else if (r === "floraScoutAll") for (let n of Ba(e, t)) i.scouted.includes(n.source) || i.scouted.push(n.source);
	else if (r === "floraDonate") {
		let r = t.grid.find((t) => t?.card === ja(e)) ?? (E[ja(e)]?.group === "location" ? W(t) : void 0);
		if (!r || !n.cards || n.cards.length > 1) return !1;
		if (!n.cards.length) q(r, 1);
		else {
			let r = t.grid.find((e) => e?.card === n.cards[0] && E[e.card].group === "sentient" && e.boost > 0);
			if (!r) return !1;
			J(e, r, 1), K(e, t, "health", 1), F(e, t, "overpower", 1);
		}
	} else if (r === "floraTransfer") {
		let r = t.grid.find((t) => t?.card === ja(e)), i = n.transfers;
		if (!r || !i || new Set(i.map((e) => e.card)).size !== i.length || i.reduce((e, t) => e + t.amount, 0) > r.boost) return !1;
		let a = i.map((e) => G(t).find((t) => t.card === e.card));
		if (a.some((e, t) => !e || e === r || e.boost + i[t].amount > E[e.card].boostCapacity)) return !1;
		for (let [t, n] of i.entries()) J(e, r, n.amount), q(a[t], n.amount);
	} else if (r === "recruitInformation") {
		let r = n.skillPayment;
		if (!r?.length || r.length > 3 || C.some((e) => r.filter((t) => t === e).length > t.skills[e])) return !1;
		for (let e of r) t.skills[e]--;
		X(e, 1361, t), (e.pendingCards.includes(1361) || e.cardClaims.some((e) => e.card === 1361 && e.requester === t.rid)) && (e.pendingInstances[1361] = {
			...V(1361),
			initialBoost: r.length
		});
	} else if (r === "houseOccupancy") {
		let t = e.passage.node.house;
		if (!t) return !1;
		let r = e.houseOccupancy?.[t];
		if (r !== void 0) e.abilityDice = [r];
		else {
			e.pool + e.penaltyDice < 1 && ca(e);
			let r = n.diceFromPool ?? +(e.pool > 0);
			if (r > 1 || r > e.pool || 1 - r > e.penaltyDice) return !1;
			let i = T[B(e, 6)];
			(e.houseOccupancy ??= {})[t] = i, e.abilityDice = [i];
		}
	} else if (r === "actionLock") {
		let t = e.passage.node.actionLock;
		if (!t) return !1;
		for (let e of t.ids) (i.actionBlocks ??= []).push({
			id: e,
			location: t.location,
			...t.until === "nextTurn" ? { untilTurn: (i.turnsTaken ?? 0) + 2 } : t.until === "leave" ? { untilLeave: !0 } : {}
		});
	} else if (r === "portalDestination") {
		let r = n.destination;
		if (r === void 0 || !(r >= 12 && r <= 63 || r >= 76 && r <= 531 || r >= 541 && r <= 791 || [
			795,
			799,
			801
		].includes(r))) return !1;
		la(e, t, r);
	} else if (r === "councilWeapons") Yi(e, t, 583, !0, (e) => P(e.card, "weapon")), la(e, t, 583);
	else if (r === "hideGatewayItem") {
		if (!n.cards || n.cards.length > 1 || n.cards.length > 0 && t.reserve.some((e) => e.hiddenAt === 741)) return !1;
		if (n.cards.length) {
			let r = [...t.grid, ...t.reserve].find((e) => e?.card === n.cards[0] && E[e.card].group === "item");
			if (!r) return !1;
			Y(e, t, r.card), r.dice = {}, r.hiddenAt = 741, r.placed = !0, t.reserve.push(r);
		}
	} else if (r === "recoverGatewayItem") {
		let n = t.reserve.find((e) => e.hiddenAt === 741);
		n ? (t.reserve = t.reserve.filter((e) => e !== n), delete n.hiddenAt, n.boost = E[n.card].boostCapacity, e.pendingCards.push(n.card), e.pendingInstances[n.card] = n, (e.requiredGrid ??= []).push(n.card)) : q(W(t), 1);
	} else if (r === "boxBelongings" || r === "boxBelongingsWithVehicles") {
		let n = [
			"sentient",
			"animal",
			"flora",
			"item",
			...r === "boxBelongingsWithVehicles" ? ["vehicle"] : []
		];
		Yi(e, t, 701, !1, (e) => n.includes(E[e.card].group)), la(e, t, 369), e.arrivals = e.arrivals.filter((e) => e.rid !== t.rid || e.location !== 369 || e.curse);
	} else if (r === "replaceMission") {
		if (e.missionDone || e.mission === 1596) return !1;
		e.center = e.center.filter((t) => t.card !== e.mission), e.mission = 1596, e.center.push(V(1596)), e.pivotUsed = !1, e.missionPivot = !1;
	} else if (r === "militaryTraining") {
		let n = Ji(e, ja(e));
		if (!n || n.card !== 1292) return !1;
		let r = n.boost;
		F(e, t, "overpower", r), q(n, 1), r === 3 && (i.actionBlocks ??= []).push({
			id: "h1292:0",
			location: 0
		});
	} else if (r === "reviveAnimal") {
		let n = [
			1218,
			1219,
			1220
		].filter((t) => !e.players.some((e) => [...e.grid, ...e.reserve].some((e) => e?.card === t)));
		n.length && X(e, n[B(e, n.length)], t);
	} else if (r === "crewTides") e.crewSharing = {
		decisions: {},
		faces: {},
		tides: !0
	};
	else if (r === "asylumRoll") e.skillResult = null, Zi(e, t, "result");
	else if (r === "grantAsylum") {
		if (!e.skillResult) return !1;
		for (let t of e.players) for (let n of [...t.supply]) n.asylumAt === i.location && Y(e, t, n.card);
		let n = {
			move: 1309,
			look: 1327,
			engage: 1323,
			help: 1312,
			take: 1339,
			overpower: 1330
		}[e.skillResult], r = G(t).find((e) => e.card === n);
		r ? (Y(e, t, n), r.dice = {}, q(r, 1), e.pendingCards.push(n), e.pendingInstances[n] = {
			...r,
			asylumAt: i.location
		}) : (X(e, n, t), (e.pendingCards.includes(n) || e.cardClaims.some((e) => e.card === n && e.requester === t.rid)) && (e.pendingInstances[n] = {
			...V(n),
			asylumAt: i.location
		}));
	} else if (r === "chase668") e.milestones.acquiredCards.includes(853) || K(e, t, "morale", 1);
	else if (r === "passCrying676") e.encounterMemory?.includes("console676") || K(e, t, "morale", -1);
	else if (r === "lizard711") e.milestones.acquiredCards.includes(837) || K(e, t, "health", -1);
	else if (r === "uninjuredFlora") i.healthLostThisTurn || X(e, 1078, t);
	else if (r === "invest") {
		if (!n.investment || n.investment > 10 || Re(e, t, n.investment) > t.coins) return !1;
		ze(e, t, n.investment), e.storyInvestment = n.investment, e.storyInvestmentReturn = void 0, e.skillResult = null, Zi(e, t, "result");
	} else if (r === "investmentReturn") {
		if (e.storyInvestment === void 0 || !e.skillResult) return !1;
		e.storyInvestmentReturn = e.storyInvestment * (e.skillResult === "engage" ? 3 : e.skillResult === "take" ? 0 : 2), Be(e, t, e.storyInvestmentReturn), e.storyInvestment = void 0;
	} else if (r === "paySpiderFood") {
		let r = n.cards?.length === 1 ? t.grid.find((e) => e?.card === n.cards[0]) : null;
		if (!r || r.boost < 1 || ![
			"food",
			"animal",
			"sinew"
		].some((e) => P(r.card, e))) return !1;
		J(e, r, 1);
	} else if (r === "foundryLoot") {
		if (!n.cards?.length || n.cards.length > 2 || new Set(n.cards).size !== n.cards.length || n.cards.some((e) => ![
			874,
			938,
			976
		].includes(e))) return !1;
		for (let r of n.cards) X(e, r, t);
		n.cards.length === 2 && X(e, 1394, t);
	} else if (r === "questEggBoost") {
		let n = G(t).find((e) => e.card === 977);
		if (!n || !Cr(e, t, 1637)) return !1;
		q(n, 1);
	} else if (r === "deliverBarrel") {
		let n = G(t).find((e) => e.card === 1158);
		if (!n || !Cr(e, t, 1641)) return !1;
		Be(e, t, 5 * n.boost), Y(e, t, 1158);
	} else if (r === "murderReward") {
		if (!Cr(e, t, 1645)) return !1;
		let r = G(t).filter((e) => [1359, 1364].includes(e.card));
		if (r.length) for (let e of r) e.boost = E[e.card].boostCapacity;
		else {
			if (n.cards?.length !== 1 || ![1359, 1364].includes(n.cards[0])) return !1;
			X(e, n.cards[0], t);
		}
	} else if (r === "hostageBoost") {
		let n = G(t).find((e) => e.card === 1349);
		if (!n || !Cr(e, t, 1652)) return !1;
		q(n, 1);
	} else if (r === "deliverSoulstone") {
		if (!Cr(e, t, 1654)) return !1;
		Y(e, t, 1160), Be(e, t, 2), X(e, 1345, t);
	} else if (r === "feedVillagers") {
		let r = n.transfers;
		if (!Cr(e, t, 1664) || !r || new Set(r.map((e) => e.card)).size !== r.length) return !1;
		let i = r.map((e) => [...t.grid, ...t.reserve].find((t) => t?.card === e.card));
		if (i.some((e, t) => !e || !P(e.card, "food") || e.boost < r[t].amount)) return !1;
		let a = r.reduce((e, t) => e + t.amount, 0);
		for (let [t, n] of r.entries()) J(e, i[t], n.amount);
		Be(e, t, a), K(e, t, "morale", a), a >= 4 && X(e, 993, t);
	} else if (r === "becomeReborn") {
		if (!Cr(e, t, 1697)) return !1;
		Gi(e, t, 1453);
	} else if (r === "restoreBody") {
		if (t.character !== 1453 || !t.previousCharacter || t.previousCharacter < 1435 || t.previousCharacter > 1452) return !1;
		Gi(e, t, t.previousCharacter), K(e, t, "morale", 1);
	} else if (r === "heatGuardHere") i.heatImmuneHere = i.location;
	else if (r === "personalItemBoost") {
		let e = G(t).find((e) => e.card === 1299 + M(t));
		if (!e || n.reward === void 0 || n.reward > 2) return !1;
		q(e, n.reward);
	} else if (r === "loyalAnimal") {
		let r = n.cards?.length === 1 ? t.grid.find((e) => e?.card === n.cards[0]) : void 0, i = r ? Ce[r.card] : void 0;
		if (!r || !i) return !1;
		let a = t.grid.indexOf(r);
		Y(e, t, r.card), X(e, i, t), (e.pendingCards.includes(i) || e.cardClaims.some((e) => e.card === i && e.requester === t.rid)) && (e.replacementCells[i] = a);
	} else if (r === "refreshRow") {
		if (n.line === void 0) return !1;
		for (let [r, i] of t.grid.entries()) i && Math.floor(r / 3) === n.line && (e.pool += Object.keys(i.dice).length, i.dice = {});
	} else if (r === "costs") {
		if (!n.actions || n.actions.length > 2 || new Set(n.actions).size !== n.actions.length || n.actions.some((n) => !Ua(e, t).some((e) => e.id === n))) return !1;
		i.revealedCosts = [.../* @__PURE__ */ new Set([...i.revealedCosts, ...n.actions])];
	} else if (r === "outcome") {
		let r = Ua(e, t).find((e) => e.id === n.action);
		if (!r) return !1;
		let i = (e, t = !1) => [
			t ? e.zh ?? e.text : e.text,
			...e.choices.map((e) => (t ? e.labelZh ?? e.label : e.label) + "\n" + i(e.node, t)),
			...e.after ? [i(e.after, t)] : []
		].join("\n\n");
		e.previewedOutcome = {
			text: i(D[r.id].node),
			zh: i(D[r.id].node, !0)
		};
	} else if (r === "create") {
		let e = n.cards?.map((e) => G(t).find((t) => t.card === e));
		if (!e || e.length > 3 || e.some((e) => !e || ![
			"item",
			"structure",
			"vehicle"
		].includes(E[e.card].group)) || new Set(e.map((e) => E[e.card].group)).size !== e.length) return !1;
		for (let t of e) q(t, 1);
	} else if (r === "repair" || r === "balance") {
		let i = n.cards?.map((e) => G(t).find((t) => t.card === e));
		if (i?.length !== 2 || !i[0] || !i[1] || i[0] === i[1]) return !1;
		let [a, o] = i;
		if (r === "repair") {
			if (!n.amount || n.amount > 2 || a.boost < n.amount || o.boost + n.amount > E[o.card].boostCapacity || i.some((e) => ![
				"item",
				"structure",
				"vehicle"
			].includes(E[e.card].group))) return !1;
			J(e, a, n.amount), q(o, n.amount);
		} else {
			if (o.boost > E[a.card].boostCapacity) return !1;
			a.boost > o.boost ? J(e, a, a.boost - o.boost) : q(a, o.boost - a.boost);
		}
	} else if (r === "dance" || r === "animalBoost") {
		let i = n.cards?.length === 1 ? t.grid.find((e) => e?.card === n.cards[0]) : void 0;
		if (!i || E[i.card].group !== (r === "dance" ? "sentient" : "animal")) return !1;
		if (r === "dance") K(e, t, "morale", 1), a?.statsBefore && !a.lostTimeOrHealth && t.stats.time >= a.statsBefore.time && t.stats.health >= a.statsBefore.health && q(i, 1);
		else {
			if (!n.condition) return !1;
			q(i, 1);
		}
	} else if (r === "blueprint") X(e, 1294 + B(e, 5), t);
	else if (r === "underground") {
		let n = kn(i.location), r = [
			96,
			81,
			87,
			85,
			90,
			82,
			99,
			83,
			98,
			84,
			95,
			91,
			88,
			89,
			86,
			92
		];
		if (n === null || n < 31 || n > 46) return !1;
		la(e, t, r[n - 31]);
	} else if (r === "double") {
		let r = e.copied?.benefits ?? [];
		if (!r.length) return !0;
		let i = n.reward === void 0 ? void 0 : r[n.reward];
		if (!i) return !1;
		if (i.kind === "coin") Be(e, t, i.amount);
		else if (i.kind === "skill") F(e, t, i.value, i.amount);
		else if (i.kind === "stat") K(e, t, i.value, i.amount);
		else if (i.kind === "boost") {
			let e = G(t).find((e) => e.card === Number(i.value));
			if (!e) return !1;
			q(e, i.amount);
		} else i.kind === "card" && X(e, Number(i.value), t);
	} else if (r === "assembly") e.copied?.assemblyEarned && Be(e, t, 2);
	else if (r === "challengePair") e.abilityDice = [T[B(e, 6)], T[B(e, 6)]], e.passage.following.unshift({
		node: {
			text: "Choose one die as the benefit; suffer the other as the penalty.",
			zh: "选择一枚骰子作为收益，承受另一枚骰子的惩罚。",
			instructions: "",
			choices: [],
			printedAbility: "challengePairChoose"
		},
		entry: e.passage.entry,
		applied: []
	});
	else if (r === "challengePairChoose") {
		if (n.line === void 0 || n.line > 1 || e.abilityDice?.length !== 2) return !1;
		let r = e.abilityDice[n.line], o = e.abilityDice[1 - n.line];
		if (w.includes(r) && K(e, t, r, 1), w.includes(o)) K(e, t, o, -1);
		else if (o === "setback") for (let n of e.players.flatMap((e) => e.grid.flatMap((e) => e && Dr(e.card) ? [e.card] : []))) for (let r of Se(a?.source ?? 0, [n], !0)) e.arrivals.push({
			rid: t.rid,
			location: i.location,
			instruction: r.instruction,
			paid: !1,
			curse: n
		});
	} else return !1;
	return !0;
}
function Ya(e) {
	if (e.replenishments.length) {
		e.replenishResume = "nextTurn";
		return;
	}
	if (Sa(e, !0), yo(e)) return;
	if (ai(e)) {
		H(e, "story");
		return;
	}
	if (e.portalReturns?.length) {
		e.portalReturnDecision = e.portalReturns.pop();
		return;
	}
	if (e.hourglassTurnEnd) return;
	if (co(e, U(e))) {
		e.hourglassTurnEnd = U(e).rid;
		return;
	}
	if (Ki(U(e)).length) {
		e.phase = "experience", H(e, "gain");
		return;
	}
	e.coinPowers = void 0, e.energySwords = void 0;
	for (let t of e.players) for (let e of G(t)) delete e.affinity, delete e.affinities;
	let t = e.personal[U(e).rid];
	t.turnsTaken = (t.turnsTaken ?? 0) + 1, t.actionBlocks = t.actionBlocks?.filter((e) => e.untilTurn === void 0 || e.untilTurn > t.turnsTaken), e.restrictedExclude = void 0, e.restrictedExcludes = [], e.restrictedWater = !1, e.nextBonus = void 0, e.foresight?.length && (ei(e, ...e.foresight), e.foresight = []), e.puzzle = null, e.rebornUndo = void 0, e.hourglassUndo = void 0, e.hourglassExcludedChoice = void 0, e.miniGame = null, e.storyTest = null, e.nextActionDiscount = 0, e.nextActionMaxCost = void 0, e.restrictedBooks = [], e.restrictedDirections = [], e.copied = void 0, e.previewedOutcome = null, e.abilityDice = [], e.challenge = null, e.passage = null, e.continuation = "no", e.locationContinuation = !1, e.phase = "action", e.blankSetbacks = !1, e.freeReading = !1, e.protection = [], e.temporaryImpact = [], e.blankRewards = {}, e.stopForced = [], e.setFaces = [], e.gamblePlayer = null, e.sentientTrial = null, e.healthMorale = {}, e.nextOverpowerDiscount = {}, e.recentHealthLoss = void 0, e.restrictedVerbs = [], e.restrictedActions = [], e.restrictedSkill = null;
	for (let t of Object.values(e.personal)) t.scouted = [], t.revealedCosts = [], t.bookPages = t.bookPages.filter((e) => !t.temporaryBookPages?.includes(e)), t.temporaryBookPages = [], t.hypoxiaSuffered = !1, t.healthLostThisTurn = !1, t.animalProtection = [];
	e.slotPermission = [], e.impactPermission = [], e.followConsent = [], e.turn = (e.turn + 1) % e.players.length, e.turn === 0 && e.round++;
	let n = U(e);
	e.personal[n.rid].expiredQuests = [];
	for (let t of [...n.supply]) [1635, 1638].includes(t.card) && !t.rotated && (t.tokens = Math.max(0, (t.tokens ?? (t.card === 1635 ? 8 : 4)) - 1), t.tokens || (Y(e, n, t.card), e.personal[n.rid].expiredQuests.push(t.card)));
	H(e, "turn");
}
function Xa(e) {
	return e.players.some((e) => w.some((t) => e.stats[t] === 0)) ? (e.lastChanceUsed && !e.rescue ? Qa(e, e.missionDone ? "mission" : "failure") : (e.crisisResume = e.phase === "arrival" || e.arrivals.length ? "arrival" : e.phase === "dice" ? "result" : "story", e.phase = "crisis"), !0) : !1;
}
function Za(e) {
	let t = e.crisisResume;
	e.crisisResume = null, t === "arrival" ? pa(e) : t === "result" ? Aa(e) : e.phase = "story";
}
function Qa(e, t) {
	e.ending = t, e.phase = "done", e.endingRequestedBy = null, H(e, "end");
}
function $a(e, t) {
	return e.stage === "choose" ? C.map((n) => e.dice[t].filter((r, i) => r === n && !e.hidden[t].includes(i)).length) : Jn(e, t);
}
function eo(e, t) {
	return t.rid !== U(e).rid || t.skirm.length || t.reserve.length < jr(t) || !e.pack.length ? !1 : e.phase === "skirm" && e.skirm?.stage === "scored" || e.phase === "story" && !!e.passage && k(e.passage.node, le(e.storyTest)).effects.find((t, n) => !e.passage.applied.includes(n))?.kind === "skirmCard";
}
function to(e, t) {
	let n = D[t]?.trial;
	return !n || !!e.welcomedTrials?.includes(n) && !e.attemptedTrials?.includes(n) && !e.usedActions.includes(t);
}
function no(e, t, n = !1, r = !1) {
	if (e.portalReturnDecision || e.hourglassTurnEnd) return [];
	if (e.launch && e.launch.stage !== "landing" && ["launch", "action"].includes(e.phase)) {
		if (e.pivotUsed || e.missionDone || ![
			1577,
			1578,
			1581,
			1589,
			1590,
			1596
		].includes(e.mission) || e.launch.ready.includes(t) && e.launch.stage === "000" || e.launch.selected.includes(t) || e.launch.stage === "001" && ![1577, 1590].includes(e.mission) || e.launch.stage === "000" && e.mission === 1590) return [];
		let n = D["m" + e.mission + ":0"];
		return [{
			id: n.id,
			label: n.label,
			labelZh: n.labelZh,
			book: n.book,
			source: n.card
		}];
	}
	if (!n && e.phase !== "action" || U(e).rid !== t) return [];
	let i = U(e), a = e.personal[t], o = e.restrictedActions.filter((e) => E[D[e]?.card]?.group !== "location" || D[e].card === a.location);
	if (o.length) return o.filter((e) => to(a, e)).map((e) => {
		let t = D[e];
		return {
			id: e,
			label: t.label,
			labelZh: t.printedZh,
			book: t.book,
			source: t.card
		};
	});
	if (e.elemental?.rid === t && e.elemental.location === a.location) return e.elemental.cards.flatMap((e) => O(e).filter((e) => e.hasCost).map((t) => ({
		id: t.id,
		label: t.label,
		labelZh: t.printedZh,
		book: t.book,
		source: e
	})));
	let s = e.players.flatMap((e) => e.supply.filter((e) => Er(e.card) && e.origin === a.location).map((e) => e.card)), c = [.../* @__PURE__ */ new Set([
		a.location,
		...i.grid.filter((e) => e !== null).map((e) => e.card),
		...i.supply.filter((e) => !Er(e.card) && (e.asylumAt === void 0 || e.asylumAt === a.location)).map((e) => e.card),
		...s,
		...e.center.map((e) => e.card)
	])], l = [];
	for (let t of c) {
		if (t === e.mission && (e.missionDone || t === 1596 && e.milestones.travelerRescue)) continue;
		let n = i.grid.some((e) => e?.card === t && e.rotated) && t >= 1627 && t <= 1704;
		for (let o of O(t)) {
			let s = t === a.location && a.forbiddenLocations.includes(t) && o.node.elemental === "start", c = gr(e, i, o.id);
			(t !== a.location || (!a.forbiddenLocations.includes(t) || s) && a.departureLimit?.location !== t) && (a.actionBlocks?.some((e) => e.id === o.id && (e.location === 0 || e.location === a.location)) || (!n || t === 1657 && o.book === "move" && a.location === 690) && o.book !== "depart" && o.book !== "secrets" && o.hasCost && !o.sequenceOnly && (r || c || o.repeatable || !a.usedActions.includes(o.id)) && (o.completedKey && a.chosenBranches?.includes(o.completedKey) || (!o.node.gardenPluck || Ji(e, t)?.tucked?.length) && (o.repeatOnWin && a.failedDuels?.includes(o.id) || t === e.mission && /^PIVOT\b/.test(o.label) && e.pivotUsed || (!o.boostCost || i.grid.some((e) => e?.card === t && e.boost >= o.boostCost)) && (o.node.flight && On(a.location) === null || (t !== 957 || o.book !== "move" || a.towerTop || a.location === 78) && Tr(e, i, o.id) && to(a, o.id) && (o.book === "help" && t >= 1435 && t <= 1452 && a.usedActions.includes("h" + (1435 + fe(t)) + ":0") || (o.id !== "o1592:0" || pn(a.location)) && (r || c || t !== a.location || !a.usedLocations.includes(t) || s || mn(t) || o.repeatable || e.continuation !== "no" && e.locationContinuation) && l.push({
				id: o.id,
				label: o.option || o.label.match(/^[A-Z][A-Z /-]*/)?.[0].trim() || o.book,
				labelZh: o.printedZh,
				book: o.book,
				source: t,
				water: o.requiresWater,
				condition: o.condition
			}))))));
		}
	}
	for (let [n, r] of Object.entries(E[a.location]?.exits ?? {})) if (!Dn(a.location) || Mn(e, t)) {
		if (r.availability === "direct_adjacent" && r.destination !== null) l.push({
			id: "exit:" + n,
			label: n,
			labelZh: "",
			book: "depart",
			source: a.location
		});
		else if (r.availability === "storybook") for (let t of O(a.location, "depart").filter((t) => t.direction === n[0].toUpperCase() && Tr(e, i, t.id))) l.push({
			id: t.id,
			label: n,
			labelZh: "",
			book: "depart",
			source: a.location
		});
	}
	for (let t of O(a.location, "depart")) t.direction && !/^[NSEW]$/.test(t.direction) && Tr(e, i, t.id) && l.push({
		id: t.id,
		label: t.direction === "north (or northwest)" ? "northOrNorthwest" : t.direction,
		labelZh: "",
		book: "depart",
		source: a.location
	});
	return l.flatMap((e) => D[e.id]?.variants?.map((e) => {
		let t = D[e];
		return {
			id: e,
			label: t.label,
			labelZh: t.labelZh,
			book: t.book,
			source: t.card
		};
	}) ?? [e]).filter((t) => {
		let n = D[t.id]?.direction || (t.id.startsWith("exit:") ? t.id.slice(5)[0].toUpperCase() : ""), r = a.departureLimit?.location === a.location ? a.departureLimit : null, i = e.pearlDefense;
		return i && !i.active && (i.rolling > 0 || !i.remaining.includes(t.book === "depart" ? "move" : t.book)) ? !1 : t.id !== e.restrictedExclude && !e.restrictedExcludes?.includes(t.id) && (!e.restrictedDirections?.length || e.restrictedDirections.includes(n)) && (!r || t.source !== a.location || t.book === "depart" && r.directions.includes(n)) && (!e.restrictedBooks?.length || e.restrictedBooks.includes(t.book)) && (!e.restrictedSkill || (t.book === "depart" ? "move" : t.book) === e.restrictedSkill) && (!e.restrictedVerbs?.length || e.restrictedVerbs.some((e) => D[t.id]?.label.match(/\b[A-Z][A-Z-]+\b/g)?.includes(e)));
	}).map((t) => e.restrictedWater ? {
		...t,
		condition: {
			en: [t.condition?.en, "Confirm that this move action crosses water."].filter(Boolean).join(" "),
			zh: [t.condition?.zh, "确认此移动行动会穿越水域。"].filter(Boolean).join(" ")
		}
	} : t);
}
function ro(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		players: [],
		personal: {},
		turn: 0,
		round: 1,
		phase: "landing",
		pool: 8 + t.length * 2,
		penaltyDice: 0,
		center: [],
		mission: 1590,
		missionDice: [0, 0],
		challenge: null,
		passage: null,
		pendingCards: [],
		continuation: "no",
		locationContinuation: !1,
		lastChanceUsed: !1,
		missionDone: !1,
		missionPivot: !1,
		pivotUsed: !1,
		destinyDone: !1,
		ending: "none",
		endingRequestedBy: null,
		event: "setup",
		eventSeq: 0,
		skirm: null,
		pack: [],
		duelsWon: 0,
		lastSkirmWon: null,
		skillResult: null,
		rescue: null,
		spentExperience: [],
		blankSetbacks: !1,
		slotPermission: [],
		impactPermission: [],
		followConsent: [],
		deliveries: {},
		cardClaims: [],
		placementChoices: [],
		replenishments: [],
		replenishResume: null,
		protection: [],
		temporaryImpact: [],
		blankRewards: {},
		stopForced: [],
		setFaces: [],
		gamblePlayer: null,
		skillRolls: [],
		sentientTrial: null,
		elemental: null,
		restrictedActions: [],
		summoning: null,
		arrivals: [],
		arrivalResume: null,
		arrivalSecret: !1,
		arrivalReader: null,
		arrivalStack: [],
		arrivalEndsTurn: !1,
		crisisResume: null,
		pendingInstances: {},
		replacementCells: {},
		freeReading: !1,
		milestones: hn(),
		startingStat: e.startingStat
	}, i = Array.from({ length: 144 }, (e, t) => t + 1);
	for (let e = 0; e < 15; e++) r.pack.push(i.splice(B(r, i.length), 1)[0]);
	let a = [
		0,
		1,
		2,
		3,
		4,
		5
	], o = [
		0,
		1,
		2,
		3,
		4,
		5
	];
	for (let n of t) {
		let t = a.splice(B(r, a.length), 1)[0], i = o.splice(B(r, o.length), 1)[0], s = Wi(r), c = Array.from({ length: 9 }, () => null);
		c[4] = {
			...V(1435 + t),
			boost: 2,
			placed: !0
		};
		let l = {
			rid: n,
			character: 1435 + t,
			stats: {
				time: e.startingStat,
				morale: e.startingStat,
				health: e.startingStat
			},
			coins: 0,
			skills: {
				move: 0,
				look: 0,
				engage: 0,
				help: 0,
				take: 0,
				overpower: 0
			},
			grid: c,
			reserve: [],
			supply: [],
			skirm: [],
			landingReady: !1
		};
		r.players.push(l), r.personal[n] = {
			escape: i,
			landing: s,
			location: te[i][re(...s)],
			visited: [],
			usedLocations: [],
			usedActions: [],
			forbiddenLocations: [],
			notes: "",
			bookPages: [],
			dungeonOrigin: null,
			scouted: [],
			revealedCosts: [],
			questLocations: {},
			questFlags: [],
			expiredQuests: []
		}, F(r, l, C[t], 1), e.opening || (r.personal[n].escapeSkills = We(r, l, [C[i]]), r.personal[n].landingSkills = We(r, l, s.map((e) => C[e])));
	}
	return r.missionDice = Wi(r), r.mission = ne[re(...r.missionDice)], r.center.push(V(r.mission)), r.missionSkills = We(r, r.players[0], r.missionDice.map((e) => C[e])), e.opening && gn(r, !1, (e) => B(r, e)), { state: r };
}
var Z = () => ({ code: "games.vantage.errInvalid" }), io = () => ({ code: "games.vantage.errTurn" });
function ao(e, t, n, r) {
	ii(e, t.rid), e.powerMove = {
		rid: t.rid,
		source: n,
		kind: r
	};
}
function oo(e, t, n) {
	ii(e, t.rid), la(e, t, n), fa(e, "nextTurn") || Ya(e);
}
function so(e, t, n) {
	let r = e.portalReturnDecision;
	delete e.portalReturnDecision, !(n && (la(e, t, r.origin), fa(e, "nextTurn"))) && Ya(e);
}
function co(e, t) {
	let n = e.hourglassUndo, r = t.grid.find((e) => e?.card === 987);
	if (!n || n.rid !== t.rid || !r?.rotated || r.boost < 1 || U(e) !== t || e.phase === "done") return null;
	let i = structuredClone(n.state), a = i.players.find((e) => e.rid === t.rid).grid.find((e) => e?.card === 987);
	if (!a) return null;
	a.rotated = !1, a.boost = Math.max(0, a.boost - 1), i.cursor = e.cursor, i.eventSeq = e.eventSeq, i.hourglassUndo = void 0, i.hourglassTurnEnd = void 0;
	for (let t of Object.keys(i.personal)) i.personal[t].notes = e.personal[t].notes;
	if (i.endingRequestedBy = e.endingRequestedBy, n.action.type === "chooseAction") {
		if (i.restrictedExcludes = [.../* @__PURE__ */ new Set([...i.restrictedExcludes ?? [], n.action.id])], !no(i, t.rid).length) return null;
	} else if (!i.passage || (i.hourglassExcludedChoice = {
		entry: i.passage.entry,
		node: JSON.stringify(i.passage.node),
		index: n.action.index
	}, !wo.viewFor(i, t.rid).private?.passage?.allowedChoices.length)) return null;
	return i;
}
function lo(e, t) {
	let n = e.hourglassExcludedChoice;
	return !n || n.index !== t || n.entry !== e.passage?.entry || n.node !== JSON.stringify(e.passage.node);
}
function uo(e, t) {
	ii(e, t.rid), e.pool < 1 && ca(e), e.pool--;
	let n = T[B(e, 6)];
	e.challenge = {
		id: "power:1204",
		source: 1204,
		skill: "overpower",
		untyped: !0,
		flourish: !0,
		cost: 1,
		dice: [n === "setback" && e.blankSetbacks ? "blank" : n],
		direct: null,
		obstacleCleared: !1
	}, e.phase = "dice";
}
function fo(e, t, n, r, i) {
	e.phase = "action";
	let a = So(e, {
		type: "chooseAction",
		id: n,
		condition: r,
		sentientInteraction: i
	}, { by: t.rid });
	if ("code" in a) throw Error("Printed switch failed its action validation");
	Object.assign(e, a.state);
}
function po(e, t, n, r, i) {
	let a = {
		...r,
		boost: 0,
		dice: { ...r.dice },
		placed: !0
	};
	Y(e, t, r.card, !1), (e.deliveries[n.rid] ??= []).push(a), (e.transportDeliveries ??= []).push({
		card: r.card,
		from: t.rid,
		to: n.rid,
		source: i,
		reservedAnother: !1
	});
}
function mo(e, t, n, r, i) {
	let a = E[n.card].slots[r];
	q(n, a.reward), n.card === 987 && (n.rotated = !0), a.rewardCard && X(e, a.rewardCard, t), e.blankRewards[t.rid] && (i === "blank" && q(n, e.blankRewards[t.rid]), delete e.blankRewards[t.rid]), n.card >= 1454 && n.card <= 1459 && a.kind === "specific_result" && K(e, t, "health", 1);
}
function ho(e) {
	let t = e.powerTransfer;
	if (!t || t.waiting.length) return;
	let n = e.players.find((e) => e.rid === t.from)?.grid.find((e) => e?.card === t.source), r = e.players.find((e) => e.rid === t.to)?.grid.find((e) => e?.card === t.destination);
	delete e.powerTransfer;
	let i = e.players.find((e) => e.rid === t.payer)?.grid.find((e) => e?.card === 1366);
	!n || !r || !i || i.boost < 1 || (J(e, i, 1), t.kind === "boost" ? (J(e, n, 1), q(r, 1)) : (r.dice[String(t.slot)] = n.dice[String(t.sourceSlot)], delete n.dice[String(t.sourceSlot)]));
}
function go(e, t, n, r, i, a) {
	let o = t.grid.findIndex((e) => e?.card === n);
	o < 0 || (e.powerReplacement = {
		rid: t.rid,
		source: n,
		result: r,
		cell: o,
		resultInstance: i,
		bonus: a
	}, ["item", "vehicle"].includes(E[n].group) && t.grid.some((e, t) => t !== 4 && !e) && e.players.some((e) => e.grid.some((e) => e?.card === 1367 && e.boost > 0)) || _o(e));
}
function _o(e, t) {
	let n = e.powerReplacement, r = e.players.find((e) => e.rid === n.rid), i = r.grid[n.cell];
	if (delete e.powerReplacement, fr(e, r, 1618), E[n.result]?.group === "item" && (E[n.result].value ?? 0) >= 6 && br(r, 1644) && !Ji(e, n.result) && fr(e, r, 1644), Y(e, r, n.source), X(e, n.result, r), e.pendingCards.includes(n.result) || e.cardClaims.some((e) => e.card === n.result && e.requester === r.rid) || e.deliveries[r.rid]?.some((e) => e.card === n.result)) {
		let t = n.resultInstance ?? V(n.result);
		if (r.rid === U(e).rid || e.cardClaims.some((e) => e.card === t.card && e.requester === r.rid)) e.pendingInstances[t.card] = t;
		else {
			let n = e.deliveries[r.rid]?.find((e) => e.card === t.card);
			n && Object.assign(n, t);
		}
		E[t.card].portrait && (e.replacementCells[t.card] = n.cell);
		let i = n.bonus;
		i && [...r.grid.flatMap((e) => e ? [e.card] : []), t.card].some((e) => _e(e, r).some((e) => e === i.composition)) && q(t, i.boost);
	}
	if (t !== void 0) {
		let n = {
			...V(i.card),
			placed: !0
		};
		r.grid[t] = n, xa(e, r, n, t);
	}
}
function vo(e, t) {
	ii(e, t.rid), e.restrictedBooks = ["overpower"], e.continuation = "must", e.freeOverpower = !0, K(e, t, "morale", 1);
}
function yo(e) {
	let t = e.jumpAfterDeparture;
	if (!t) return !1;
	delete e.jumpAfterDeparture;
	let n = e.players.find((e) => e.rid === t.rid);
	if (e.personal[n.rid].location === t.origin || (e.pool < 1 && ca(e), e.pool < 1)) return !1;
	e.pool--;
	let r = T[B(e, 6)];
	return e.challenge = {
		id: "power:1228",
		source: 1228,
		skill: "move",
		untyped: !0,
		cost: 1,
		dice: [r === "setback" && e.blankSetbacks ? "blank" : r],
		direct: e.personal[n.rid].location,
		alreadyMoved: !0,
		obstacleCleared: !1
	}, e.phase = "dice", !0;
}
function bo(e, t, n, r) {
	let i = e.personal[t.rid].location;
	if (delete e.powerMove, la(e, t, n), r) {
		e.pool < 1 && ca(e), e.pool--;
		let t = T[B(e, 6)];
		e.challenge = {
			id: "exit:power",
			source: i,
			skill: "move",
			untyped: !0,
			cost: 1,
			dice: [e.blankSetbacks && t === "setback" ? "blank" : t],
			direct: n,
			obstacleCleared: !1,
			alreadyMoved: !0
		}, e.phase = "dice", fa(e, "dice");
	} else fa(e, "nextTurn") || Ya(e);
}
function xo(e, t, n, r) {
	bo(e, t, r, e.powerMove?.kind === "jump");
}
function So(e, t, { by: n }) {
	let r = e.players.findIndex((e) => e.rid === n);
	if (r < 0 || e.phase === "done") return Z();
	let i = structuredClone(e), a = i.players[r], o = i.personal[n], s = U(i).rid === n;
	if (t.type === "setNotes") return o.notes = t.text, { state: i };
	if (t.type === "endAdventure") return i.endingRequestedBy = n, { state: i };
	if (t.type === "cancelEnd") return i.endingRequestedBy === n ? (i.endingRequestedBy = null, { state: i }) : Z();
	if (t.type === "confirmEnd") return i.endingRequestedBy === n ? (Qa(i, "retired"), { state: i }) : Z();
	if (t.type === "replenish") {
		let e = i.replenishments[0];
		if (!e || e.rid !== n) return Z();
		let r = a.grid.find((e) => e?.card === 1197), o = i.players.find((t) => t.rid === e.owner)?.grid.find((t) => t?.card === e.card);
		return !r || r.boost < 1 || !o ? Z() : (t.accept && (J(i, r, 1), q(o, 1)), i.replenishments.shift(), H(i, "gain"), { state: i });
	}
	if (i.replenishments.length) return Z();
	if (t.type === "answerPowerTransfer") return i.powerTransfer?.waiting.includes(n) ? (t.accept ? (i.powerTransfer.waiting = i.powerTransfer.waiting.filter((e) => e !== n), ho(i)) : delete i.powerTransfer, H(i, "place"), { state: i }) : Z();
	if (i.powerTransfer) return Z();
	if (t.type === "keepSkillRoll" || t.type === "sentientPower" && t.power === "skillFace" || t.type === "itemPower" && t.power === "skillFace") {
		let e = i.skillRolls[0];
		if (!e || e.rid !== n || i.skillDiceChoice) return Z();
		if (t.type !== "keepSkillRoll") {
			let n = t.type === "sentientPower" ? 1354 : 924, r = a.grid.find((e) => e?.card === n);
			if (t.card !== n || !r || r.boost < 1 || !t.skill || n === 1354 && a.skills[t.skill] < 1) return Z();
			J(i, r, 1), e.face = t.skill;
		}
		if (i.skillGroupCommitted = Je(e), Qi(i, a, e), i.skillRolls.shift(), !i.skillRolls.length && (i.skirm?.resume && (i.skirm.pauseRolls = ea(i, U(i)), tr(i.skirm, (e) => B(i, e)), ta(i)), i.miniGame?.kind === "press" && !i.miniGame.done)) {
			let e = i.miniGame.dice;
			i.miniGame.stage = e.slice(0, -1).includes(e.at(-1)) ? "round" : "choose";
		}
		return H(i, "gain"), { state: i };
	}
	if (i.skillRolls.length && !(t.type === "printedPower" && qe(t.op))) return Z();
	if (t.type === "printedPower") {
		let e = ki(i, a, t);
		return e ? (e({
			spendBoost: J,
			addBoost: q,
			slotReward: mo,
			gainSkill: (e, t, n) => F(i, e, t, n),
			gainStat: K,
			roll: B,
			refresh: ca,
			putInCenter: ei,
			pending: X,
			removeCard: Y,
			skillRoll: Zi,
			whenPlaced: xa,
			beginMove: ao,
			finishMove: bo,
			moveAction: xo,
			cancelMove: ai,
			travel: oo,
			finishPortal: so,
			finishHourglassTurn: (e) => {
				delete e.hourglassTurnEnd, e.hourglassUndo = void 0, Ya(e);
			},
			flourish: uo,
			switchAction: fo,
			transport: po,
			cannon: vo,
			replace: go,
			finishReplacement: _o,
			result: (e) => {
				ei(e, ...e.challenge?.foresight ?? []), e.challenge && (e.challenge.foresight = []), e.setFaces = [], Aa(e);
			}
		}), H(i, "gain"), { state: i }) : Z();
	}
	if (i.portalReturnDecision || i.hourglassTurnEnd || i.powerReplacement || i.powerSwitch || i.powerConversion || i.printedRoll || i.powerReward || i.powerDiceChoice || i.powerDiscardDice || i.powerMove && t.type !== "follow") return Z();
	if (t.type === "shareVantage") {
		let e = i.crewSharing;
		if (i.phase !== "story" || !e || Object.hasOwn(e.decisions, n)) return Z();
		if (e.decisions[n] = t.accept, Object.keys(e.decisions).length === i.players.length) {
			let t = i.players.filter((t) => e.decisions[t.rid]);
			for (let e of t) Zi(i, e, "crew");
			na(i);
		}
		return H(i, "gain"), { state: i };
	}
	if (i.crewSharing) return Z();
	if (t.type === "confirmRune") return i.phase !== "story" || !i.runeSurvey?.includes(n) ? Z() : (t.present && q(W(a), 1), i.runeSurvey = i.runeSurvey.filter((e) => e !== n), H(i, "gain"), { state: i });
	if (i.runeSurvey?.length) return Z();
	if (t.type === "miniGame") {
		if (!s || i.phase !== "story" || !i.miniGame || i.pendingCards.length) return Z();
		let e = kt(i.miniGame, t, (e) => B(i, e), a.coins);
		return e ? ($i(i, a, e.rolls), i.miniGame.damage > i.miniGame.paidDamage && (K(i, a, "health", i.miniGame.paidDamage - i.miniGame.damage), i.miniGame.paidDamage = i.miniGame.damage, Xa(i) && (i.crisisResume = "story")), i.miniGame.kind === "mancala" && i.miniGame.done && !i.miniGame.success && (o.mancalaAttempts = (o.mancalaAttempts ?? 0) + 1), i.miniGame.kind === "race" && i.miniGame.done && i.miniGame.success && G(a).some((e) => e.card === 1340) && fr(i, a, 1628), H(i, "roll"), { state: i }) : Z();
	}
	if (i.miniGame && !i.miniGame.done && i.phase === "story") return Z();
	if (t.type === "storyTest") {
		let e = i.storyTest, r = i.passage?.node.skillTest;
		if (!s || i.phase !== "story" || !e || !r || e.rid !== n || e.done || e.remaining || i.pendingCards.length) return Z();
		if (t.op === "skill") {
			if (e.rounds || !t.skill || !r.paySkills?.includes(t.skill) || a.skills[t.skill] < 1) return Z();
			a.skills[t.skill]--, e.count++;
		} else if (t.op === "bait" || t.op === "boost") {
			if (e.rounds) return Z();
			let n = a.grid.find((e) => e?.card === t.card);
			if (!n || n.boost < 1) return Z();
			if (t.op === "bait") {
				if (!r.bait || e.baitUsed || !["food", "flora"].some((e) => P(n.card, e))) return Z();
				e.baitUsed = !0;
			} else if (!r.sourceBoost || n.card !== i.challenge?.source) return Z();
			J(i, n, 1), e.count++;
		} else if (t.op === "reroll") {
			if (!e.rounds || t.die === void 0 || !on(r, e.faces, e.rerolled).includes(t.die)) return Z();
			e.rerolled.push(t.die), e.remaining = 1, Zi(i, a, "test", void 0, t.die);
		} else if (t.op === "partial") {
			let n = t.indices;
			if (!r.partialRounds || !e.rounds || (e.partialRounds ?? 0) >= r.partialRounds || !n?.length || new Set(n).size !== n.length || n.some((t) => t < 0 || t >= e.faces.length)) return Z();
			e.partialRounds = (e.partialRounds ?? 0) + 1, e.remaining = n.length;
			for (let e of n) Zi(i, a, "test", void 0, e);
		} else if (t.op === "roll") {
			if (!r.repeatSkill && e.rounds >= r.rolls) return Z();
			e.rounds++, e.faces = [], e.bonusFaces = [], e.storedSkills = {}, e.remaining = e.count;
			for (let t = 0; t < e.count; t++) Zi(i, a, "test");
		} else {
			if (!e.rounds || r.repeatSkill) return Z();
			e.done = !0;
		}
		return H(i, t.op === "roll" ? "roll" : "gain"), { state: i };
	}
	if (t.type === "answerSummon") {
		let e = i.summoning;
		if (i.phase !== "story" || !e?.waiting.includes(n)) return Z();
		if (t.accept) {
			if (i.players.length === 1) {
				if (!t.card || t.card < 1435 || t.card > 1440 || i.players.some((e) => M(e) === fe(t.card))) return Z();
				e.solo = {
					...V(t.card),
					placed: !0
				};
			} else {
				if (W(a).boost < 2) return Z();
				J(i, W(a), 2), e.summoned.push(n);
			}
		}
		return e.waiting = e.waiting.filter((e) => e !== n), H(i, "gain"), { state: i };
	}
	if (t.type === "chooseGamble") {
		let e = i.challenge;
		return i.gamblePlayer !== n || i.phase !== "dice" || !e || !e.dice.includes(t.face) ? Z() : (e.dice = e.dice.map((e) => e === t.face ? (i.pool++, null) : e), i.gamblePlayer = null, H(i, "place"), { state: i });
	}
	if (i.gamblePlayer) return Z();
	if (t.type === "placementBoost") {
		let e = i.placementChoices[0], r = e && ya(i, e).find((e) => e.card === t.card);
		if (!e || e.rid !== n || !r) return Z();
		if (e.kind === "gain") q(r, 1);
		else {
			let t = a.grid.find((t) => t?.card === e.source);
			J(i, r, 1), q(t, 1), e.used.push(r.card);
		}
		return e.remaining--, ba(i), i.phase === "arrival" && pa(i), H(i, "gain"), { state: i };
	}
	if (i.placementChoices.length && ![
		"endAdventure",
		"cancelEnd",
		"confirmEnd"
	].includes(t.type)) return Z();
	if (t.type === "resolveCardClaim") {
		let e = i.cardClaims.find((e) => e.card === t.card && e.owner === n);
		if (!e) return Z();
		let r = i.players.find((t) => t.rid === e.requester);
		if (t.transfer) {
			if (!Y(i, a, t.card)) return Z();
			e.requester === U(i).rid ? i.pendingCards.push(t.card) : ((i.deliveries[e.requester] ??= []).push(i.pendingInstances[t.card] ?? V(t.card)), delete i.pendingInstances[t.card]);
		} else {
			let e = W(r);
			e.boost = Math.min(E[e.card].boostCapacity, e.boost + 1), delete i.pendingInstances[t.card], delete i.replacementCells[t.card], delete i.pendingTucks?.[t.card];
		}
		return i.cardClaims = i.cardClaims.filter((t) => t !== e), i.phase === "arrival" && pa(i), H(i, "gain"), { state: i };
	}
	if (t.type === "allowSlots" || t.type === "allowImpact" || t.type === "follow") {
		if (s || t.type === "allowSlots" && !ga(i, n, U(i).rid) || t.type === "follow" && i.personal[U(i).rid].location !== o.location) return Z();
		if (t.type === "allowSlots" || t.type === "allowImpact") {
			if (i.phase !== "dice") return Z();
			let e = t.type === "allowImpact" ? "impactPermission" : "slotPermission";
			i[e] = i[e].filter((e) => e !== n), t.allowed && i[e].push(n);
		} else {
			if (![
				"action",
				"cost",
				"dice",
				"story"
			].includes(i.phase)) return Z();
			i.followConsent = i.followConsent.filter((e) => e !== n), t.allowed && i.followConsent.push(n);
		}
		return { state: i };
	}
	if (t.type === "placeCard" && i.deliveries[n]?.some((e) => e.card === t.card)) {
		let e = i.deliveries[n].find((e) => e.card === t.card), r = i.replacementCells[t.card];
		return r !== void 0 && (r < 0 ? t.zone !== "reserve" : t.zone !== "grid" || t.cell !== r) || t.zone === "tuck" || !Da(i, a, e, t.zone, t.cell) ? Z() : (i.deliveries[n] = i.deliveries[n].filter((e) => e.card !== t.card), delete i.replacementCells[t.card], i.phase === "arrival" && pa(i), H(i, "place"), { state: i });
	}
	if ((i.pendingCards.length || ma(i)) && ![
		"placeCard",
		"reserveCard",
		"releaseCard",
		"discard",
		"discardSkirmCollection"
	].includes(t.type)) return Z();
	if (i.players.some(_a) && ![
		"releaseCard",
		"discard",
		"discardSkirmCollection",
		"stowCard"
	].includes(t.type)) return { code: "games.vantage.errReserveFull" };
	if (t.type === "payArrival") {
		let e = i.arrivals[0];
		return i.phase !== "arrival" || !e || e.paid || !e.instruction.skills?.includes(t.skill) || a.skills[t.skill] < 1 ? Z() : (a.skills[t.skill]--, e.paid = !0, e.instruction.value === "health" && ia(i, a, 1), H(i, "gain"), { state: i });
	}
	if (t.type === "shieldArrival") {
		let e = i.arrivals[0], t = a.grid.find((e) => e?.card === 982);
		return i.phase !== "arrival" || !e || e.rid !== n || e.paid || !t || t.boost < 1 || e.curse || e.instruction.value !== "health" || !["stat", "payment"].includes(e.instruction.kind) ? Z() : (J(i, t, 1), e.paid = !0, ia(i, a, 1), H(i, "gain"), { state: i });
	}
	if (t.type === "resolveArrival") {
		let e = i.arrivals[0];
		if (i.phase !== "arrival" || !e || e.rid !== n) return Z();
		let r = e.instruction;
		if (r.destinations && (!t.destination || !r.destinations.includes(t.destination))) return Z();
		if (r.kind === "damage") {
			let n = oa(i, a, r.value, 1, !e.curse);
			if (n && !t.damage) return Z();
			n && r.value === "hypoxia" && (o.hypoxiaSuffered = !0), n && t.damage === "health" ? K(i, a, "health", -n) : n && (K(i, a, "time", -n), K(i, a, "morale", -n));
		} else if (["stat", "payment"].includes(r.kind) && !e.paid) r.value === "health" && !e.curse && Ar(a) && ia(i, a, 1), Fr(r.value) && (r.value !== "health" || e.curse || !Ar(a)) ? e.curse || r.value === "health" ? K(i, a, r.value, -1) : a.stats[r.value] = Math.max(0, a.stats[r.value] - 1) : r.value === "coin" ? a.coins = Math.max(0, a.coins - 1) : r.value === "boost" && J(i, W(a), 1);
		else if (r.kind === "skill") {
			if (C.some((e) => a.skills[e] > 0)) {
				if (!t.skill || a.skills[t.skill] < 1) return Z();
				a.skills[t.skill]--;
			}
		} else if (r.kind === "reserve") {
			let e = a.grid.filter((e) => e && e.card !== a.character && !Dr(e.card) && ![
				1103,
				1104,
				1105,
				1106
			].includes(e.card));
			if (e.length) {
				if (!t.reserveCard || !e.some((e) => e?.card === t.reserveCard)) return Z();
				let n = a.grid.findIndex((e) => e?.card === t.reserveCard), r = a.grid[n];
				i.pool += Object.keys(r.dice).length, r.dice = {}, a.grid[n] = null, a.reserve.push(r);
			}
		} else if ((r.kind === "rollPool" || r.kind === "rollCenter") && (r.kind === "rollPool" ? i.pool : i.penaltyDice) > 0) {
			let e = T[B(i, 6)];
			r.kind === "rollPool" ? (i.pool--, ei(i, e)) : (ti(i, 1), i.pool++), Fr(e) && K(i, a, e, -1);
		}
		if (i.arrivals.shift(), r.gainCard && X(i, r.gainCard, a), t.destination && r.destinations && la(i, a, t.destination), H(i, "penalty"), r.kind === "secret") {
			let e = D["s" + r.value + ":0"];
			return e ? (i.arrivalStack.push({
				passage: i.passage,
				skillResult: i.skillResult,
				skirmWon: i.lastSkirmWon,
				locationContinuation: i.locationContinuation,
				reader: i.arrivalReader,
				resume: i.arrivalResume
			}), i.arrivalSecret = !0, i.arrivalReader = n, i.skillResult = null, i.lastSkirmWon = null, Oa(i, e.node, e.id), { state: i }) : Z();
		}
		return (i.arrivalResume === "result" || !Xa(i)) && pa(i), { state: i };
	}
	if (t.type === "setLaunchStat") return i.phase !== "launch" || i.launch?.stage !== "000" || i.launch.ready.includes(n) || i.launch.locked.includes(n) ? Z() : (a.stats = {
		time: t.stat,
		morale: t.stat,
		health: t.stat
	}, i.launch.stats[n] = t.stat, { state: i });
	if (t.type === "prepareLaunch") return i.pendingCards.length || ma(i) || !_n(i, n, t.stat) ? Z() : (H(i, "setup"), { state: i });
	if (t.type === "chooseCapsule") return i.pendingCards.length || ma(i) || !yn(i, n, t.skill) ? Z() : (H(i, "landing"), { state: i });
	if (t.type === "chooseAction" && i.phase === "launch") return no(i, n).some((e) => e.id === t.id) ? (i.launch.locked.push(n), i.turn = r, i.phase = "action", So(i, t, { by: n })) : Z();
	if (t.type === "rerollMission") return !(i.phase === "launch" && i.launch?.stage === "000" && !i.launch.ready.length && !i.pivotUsed || i.phase === "landing" && !i.launch) || r !== 0 || i.players.some((e) => e.landingReady) || i.missionDice[0] !== i.missionDice[1] ? Z() : (Ge(a, i.missionSkills), i.missionDice = Wi(i), i.mission = ne[re(...i.missionDice)], i.center = [V(i.mission)], i.missionSkills = We(i, a, i.missionDice.map((e) => C[e])), { state: i });
	if (t.type === "rerollLanding" || t.type === "confirmLanding") {
		if (i.phase !== "landing" || a.landingReady) return Z();
		if (t.type === "rerollLanding") {
			if (!Sn(i, n)) return Z();
			let e = Wi(i), t = xn(i, n);
			for (let e of t) Ge(i.players.find((t) => t.rid === e), i.personal[e].landingSkills);
			for (let n of t) {
				let t = i.players.find((e) => e.rid === n), r = i.personal[n];
				r.landing = [...e], r.location = te[r.escape][re(...e)], r.landingSkills = We(i, t, r.landing.map((e) => C[e]));
			}
		} else a.landingReady = !0, da(i, a, o.location, !0), o.visited.push(o.location), i.players.every((e) => e.landingReady) && (i.launch = null, fa(i, "action") || (i.phase = "action"));
		return H(i, "landing"), { state: i };
	}
	if (i.phase === "launch") return Z();
	if (t.type === "boost") {
		let e = W(a);
		if (t.power === "coin" || t.power === "move") {
			if (e.boost < 2 || t.power === "coin" && me(a.character) === "armor") return Z();
			J(i, e, 2), t.power === "coin" ? Be(i, a, 1) : F(i, a, "move", 1);
		} else {
			let n = a.reserve.find((e) => e.card === t.card);
			if (!n || n.hiddenAt !== void 0 || e.boost < 1 || t.cell === void 0 || t.cell === 4) return Z();
			let r = a.grid[t.cell];
			if (r && (Dr(r.card) || [
				1103,
				1104,
				1105,
				1106
			].includes(r.card))) return Z();
			r && (i.pool += Object.keys(r.dice).length, r.dice = {}), a.grid[t.cell] = n, a.reserve = a.reserve.filter((e) => e !== n), r && a.reserve.push(r), J(i, e, 1);
		}
		return H(i, "gain"), { state: i };
	}
	if (t.type === "contribute") {
		let e = i.challenge;
		return i.phase !== "cost" || !e || e.cost < 1 || a.skills[e.skill] < 1 && !(s && e.skill === "engage" && (e.temporaryEngage ?? 0) > 0) || i.setFaces.length ? Z() : (s && e.skill === "engage" && (e.temporaryEngage ?? 0) > 0 ? e.temporaryEngage-- : a.skills[e.skill]--, e.cost--, { state: i });
	}
	if (t.type === "requestStoryPayment") {
		let e = wo.viewFor(i, n).private?.passage;
		return !s || i.phase !== "story" || !i.passage || !e?.allowedChoices.includes(t.index) || !e.skillPaymentChoices.includes(t.index) || e.blocked || e.effects.some((e) => !e.applied) ? Z() : (i.passage.payment = {
			index: t.index,
			pledges: {}
		}, { state: i });
	}
	if (t.type === "pledgeStoryPayment") {
		let e = i.passage?.payment, r = Pa(i).find((e) => e.skill === t.skill);
		return s || i.phase !== "story" || !e || !r || t.amount > r.amount || a.skills[t.skill] < t.amount ? Z() : ((e.pledges[n] ??= {})[t.skill] = t.amount, { state: i });
	}
	if (t.type === "cancelStoryPayment") return !s || !i.passage?.payment ? Z() : (delete i.passage.payment, { state: i });
	if (t.type === "actionBonus") {
		let e = i.challenge, n = e?.bonus;
		if (!s || !e) return Z();
		if (t.op === "foresight") {
			let n = e.foresight ?? [], r = e.cost + (e.extraChallengeDice ?? 0) + (e.extraChoice ? 2 : 0), a = Math.min(r, n.length);
			return i.phase !== "cost" || e.cost < 0 || r >= n.length || t.indices.length !== a || new Set(t.indices).size !== t.indices.length || t.indices.some((e) => e >= n.length) ? Z() : (e.foresightSelection = t.indices, { state: i });
		}
		if (!n) return Z();
		if (t.op === "chooseIgnore") {
			if (i.phase !== "cost" || !n.chooseIgnore || !t.face) return Z();
			n.ignore = [t.face], n.chooseIgnore = !1;
		} else {
			if (i.phase !== "dice") return Z();
			if (t.op === "reroll") {
				if (!n.reroll || !t.indices.length || new Set(t.indices).size !== t.indices.length || t.indices.some((t) => e.dice[t] == null)) return Z();
				n.reroll = !1;
				for (let n of t.indices) {
					let t = T[B(i, 6)];
					e.dice[n] = t === "setback" && i.blankSetbacks ? "blank" : t;
				}
				e.initialTime = e.initialTime?.filter((e) => !t.indices.includes(e));
			} else {
				if (t.die === void 0 || e.dice[t.die] == null) return Z();
				if (t.op === "ignore") {
					if (!n.ignoreOne) return Z();
					n.ignoreOne = !1, e.dice[t.die] === "setback" ? i.pool++ : ei(i, e.dice[t.die]), e.dice[t.die] = null;
				} else {
					if (!n.changeOne || !t.face) return Z();
					n.changeOne = !1, e.dice[t.die] = t.face, e.initialTime = e.initialTime?.filter((e) => e !== t.die);
				}
			}
		}
		return H(i, "roll"), { state: i };
	}
	if (t.type === "contributeCoin") {
		let e = i.challenge, t = e ? ie(D[e.id], e.cost, e.coinsPaid ?? 0, e.coinOfferUsed) : null;
		return !s || i.phase !== "cost" || !e || !t || a.coins < Re(i, a, t.cost) || i.setFaces.length ? Z() : (e.coinsPaid = (e.coinsPaid ?? 0) + ze(i, a, t.cost), e.coinOfferUsed = !0, t.discount === "one" ? e.cost = Math.max(0, e.cost - 1) : t.discount === "zero" && (e.cost = Math.max(0, (e.surcharge ?? 0) - (e.discount ?? 0))), { state: i });
	}
	if (t.type === "stowCard") {
		if (!s || !ra(i) || E[t.card].value === void 0 || t.card === a.character || Dr(t.card) || [
			1103,
			1104,
			1105,
			1106
		].includes(t.card)) return Z();
		let e = a.grid.findIndex((e) => e?.card === t.card);
		if (t.cell === void 0) {
			if (e < 0) return Z();
			let t = a.grid[e];
			i.pool += Object.keys(t.dice).length, t.dice = {}, a.grid[e] = null, a.reserve.push(t);
		} else {
			let e = a.reserve.find((e) => e.card === t.card), n = a.grid[t.cell];
			if (!e || e.hiddenAt !== void 0 || t.cell === 4 || n && (E[n.card].value === void 0 || Dr(n.card) || [
				1103,
				1104,
				1105,
				1106
			].includes(n.card))) return Z();
			n && (i.pool += Object.keys(n.dice).length, n.dice = {}), a.reserve = a.reserve.filter((t) => t !== e), a.grid[t.cell] = e, n && a.reserve.push(n);
		}
		return H(i, "place"), { state: i };
	}
	if (t.type === "recordRune") return ![
		"action",
		"story",
		"cost",
		"dice"
	].includes(i.phase) || !t.condition || !ln(i, a, t.skill, t.row, (e, t) => K(i, e, t, 1)) ? Z() : (H(i, "gain"), { state: i });
	if (t.type === "completeRuneQuest") {
		let e = i.players.find((e) => e.rid === t.target), n = a.supply.find((e) => e.card === 1706 && !e.rotated);
		if (![
			"action",
			"story",
			"cost",
			"dice"
		].includes(i.phase) || !e || !n || !cn(i).every(Boolean)) return Z();
		Y(i, a, 1706);
		let r = {
			...n,
			rotated: !0,
			tokens: 0,
			placed: !1
		};
		return e.rid === U(i).rid ? (i.pendingCards.push(1706), i.pendingInstances[1706] = r) : (i.deliveries[e.rid] ??= []).push(r), H(i, "gain"), { state: i };
	}
	if (t.type === "reserveCard") {
		let e = a.grid.findIndex((e) => e?.card === t.card);
		if (!(s && i.pendingCards.length) && !i.deliveries[n]?.length || e < 0 || e === 4 || Dr(t.card) || [
			1103,
			1104,
			1105,
			1106
		].includes(t.card)) return Z();
		let r = a.grid[e];
		return i.pool += Object.keys(r.dice).length, r.dice = {}, a.grid[e] = null, a.reserve.push(r), { state: i };
	}
	if (t.type === "releaseCard") return !(s && i.pendingCards.length) && !i.deliveries[n]?.length && !eo(i, a) && !_a(a) || !a.reserve.some((e) => e.card === t.card) || !Y(i, a, t.card) ? Z() : (i.phase === "arrival" && pa(i), { state: i });
	if (t.type === "discardSkirmCollection") return !i.pendingCards.length && !(s && i.phase === "skirm" && i.skirm?.stage === "scored") && !_a(a) || !a.skirm.length ? Z() : (a.skirm = [], i.phase === "arrival" && pa(i), { state: i });
	if (t.type === "skirm") return i.phase !== "skirm" || !i.skirm || !rr(i.skirm, t, n, (e) => B(i, e), ea(i, U(i))) ? Z() : (ta(i), H(i, "roll"), { state: i });
	if (t.type === "tameAnimal") {
		let e = a.grid.find((e) => e?.card === t.card), r = Ce[t.card];
		if (!e || e.boost < 2 || !r || [
			"launch",
			"landing",
			"experience"
		].includes(i.phase)) return Z();
		let o = a.grid.indexOf(e);
		return Y(i, a, e.card), X(i, r, a), (i.pendingCards.includes(r) || i.deliveries[n]?.some((e) => e.card === r) || i.cardClaims.some((e) => e.card === r && e.requester === n)) && (i.replacementCells[r] = o), H(i, "gain"), { state: i };
	}
	if (t.type === "animalPower") {
		let e = a.grid.find((e) => e?.card === t.card), r = Kr[t.card], c = i.challenge;
		if (!e || !r || e.boost < r.cost || [
			"launch",
			"landing",
			"experience"
		].includes(i.phase)) return Z();
		let l = r.kind;
		if (l === "scout" && t.power === "scout") {
			if (!t.targetCard || !qr(o.location).includes(t.targetCard) || o.scouted.includes(t.targetCard)) return Z();
			o.scouted.push(t.targetCard);
		} else if (l === "scout" && t.power === "costs") {
			let e = Jr(o.location);
			if (!e.some((e) => !o.revealedCosts.includes(e))) return Z();
			o.revealedCosts = [.../* @__PURE__ */ new Set([...o.revealedCosts, ...e])];
		} else if ([
			"land",
			"tunnel",
			"waterRide"
		].includes(l) && t.power === "ride") {
			if (![
				"action",
				"cost",
				"dice",
				"story",
				"skirm",
				"arrival"
			].includes(i.phase) || s && D[c?.id ?? ""]?.book === "depart" || l !== "tunnel" && !t.condition) return Z();
			if (t.action) {
				let e = D[t.action];
				if (t.targetCard || !Jr(o.location).includes(t.action)) return Z();
				ii(i, n), i.challenge = {
					id: e.id,
					source: o.location,
					skill: "move",
					cost: typeof e.cost == "string" ? -1 : 0,
					dice: [],
					direct: null,
					obstacleCleared: !1
				}, i.challenge.cost < 0 ? (i.phase = "cost", H(i, "action")) : Aa(i);
			} else {
				if (!t.targetCard || !Xr(t.card, o.location).includes(t.targetCard)) return Z();
				let e = i.phase;
				la(i, a, t.targetCard), e !== "arrival" && fa(i, e);
			}
		} else if (l === "fly" && t.power === "fly") {
			if (![
				"action",
				"cost",
				"dice",
				"story",
				"skirm",
				"arrival"
			].includes(i.phase) || s && D[c?.id ?? ""]?.book === "depart") return Z();
			let e = i.phase;
			if (!ua(i, a)) return Z();
			e !== "arrival" && fa(i, e);
		} else if (["cold", "hypoxia"].includes(l) && t.power === "climate" || ["health", "morale"].includes(l) && t.power === "ignore") {
			let e = l;
			if (o.animalProtection?.includes(e)) return Z();
			if ((o.animalProtection ??= []).push(e), s && i.phase === "dice" && c) for (let [t, n] of c.dice.entries()) n === e && (ei(i, n), c.dice[t] = null);
		} else if (l === "charm" && t.power === "charm") {
			if (!s || i.phase !== "dice" || !c || !t.condition || !t.indices.length || t.indices.length > 2 || new Set(t.indices).size !== t.indices.length || t.indices.some((e) => c.dice[e] == null)) return Z();
			for (let e of t.indices) {
				let t = T[B(i, 6)];
				c.dice[e] = t === "setback" && i.blankSetbacks ? "blank" : t;
			}
			c.initialTime = c.initialTime?.filter((e) => !t.indices.includes(e));
		} else if (l === "fetch" && t.power === "fetch") {
			if (!s || i.phase !== "cost" || !c || c.skill !== "take" || c.source !== o.location || !mr(o.location) || c.maxCost === 0 || i.setFaces.length) return Z();
			c.maxCost = 0, c.cost >= 0 && (c.cost = 0);
		} else if (l === "plunder" && t.power === "plunder") {
			if (!t.targetCard || !Zr(o.location).includes(t.targetCard)) return Z();
			X(i, t.targetCard, a);
		} else if (l === "revive" && t.power === "revive") {
			let e = $r(i);
			if (!s || i.phase !== "dice" || !c || !t.indices.length || t.indices.length !== t.centerIndices.length || new Set(t.indices).size !== t.indices.length || new Set(t.centerIndices).size !== t.centerIndices.length || t.indices.some((e) => c.dice[e] == null) || t.centerIndices.some((t) => e[t] == null)) return Z();
			for (let n = 0; n < t.indices.length; n++) {
				let r = t.indices[n], i = t.centerIndices[n];
				[c.dice[r], e[i]] = [e[i], c.dice[r]];
			}
			i.penaltyFaces = e, c.initialTime = c.initialTime?.filter((e) => !t.indices.includes(e));
		} else return Z();
		return J(i, e, r.cost), H(i, t.power === "charm" ? "roll" : "gain"), { state: i };
	}
	if (t.type === "itemPower") {
		let e = a.grid.find((e) => e?.card === t.card);
		if (!e || ["landing", "experience"].includes(i.phase)) return Z();
		let n = t.power === "refresh" ? 2 : t.power === "neighbors" ? 3 : t.power === "help" || t.power === "fly" ? 2 : 1;
		if (e.boost < n) return Z();
		if (t.card === 948 && t.power === "refresh") {
			if (t.die !== void 0) {
				if (!s || i.phase !== "dice" || !i.challenge || i.challenge.dice[t.die] == null) return Z();
				i.challenge.dice[t.die] = null, i.pool++;
			} else {
				let e = a.grid.find((e) => e?.card === t.targetCard);
				if (!e || t.slot === void 0 || e.dice[String(t.slot)] === void 0) return Z();
				delete e.dice[String(t.slot)], i.pool++;
			}
		} else if (t.card === 948 && t.power === "neighbors") for (let t of Ee(a.grid.indexOf(e))) a.grid[t] && q(a.grid[t], 1);
		else if (t.card === 1110 && t.power === "fly") {
			if (![
				"action",
				"cost",
				"dice",
				"story",
				"skirm",
				"arrival"
			].includes(i.phase) || s && D[i.challenge?.id ?? ""]?.book === "depart") return Z();
			let e = i.phase;
			if (!ua(i, a)) return Z();
			e !== "arrival" && fa(i, e);
		} else if (t.card === 1013 && t.power === "ride") {
			if (![
				"action",
				"cost",
				"dice",
				"story",
				"skirm",
				"arrival"
			].includes(i.phase) || s && D[i.challenge?.id ?? ""]?.book === "depart" || !t.targetCard || !Object.values(E[o.location].exits).some((e) => e.destination === t.targetCard)) return Z();
			let e = i.phase;
			la(i, a, t.targetCard), e !== "arrival" && fa(i, e);
		} else if (t.card === 1088 && t.power === "help") F(i, a, "help", 1);
		else return Z();
		return J(i, e, n), H(i, "gain"), { state: i };
	}
	if (t.type === "sentientPower") {
		let e = or(a, o.location).find((e) => e.card === t.card), r = cr(t.card), c = i.challenge, l = r === "metal" ? 2 : 1;
		if (!e || !r || e.boost < l || ["landing", "experience"].includes(i.phase)) return Z();
		J(i, e, l);
		let u = a.grid.find((e) => e?.card === t.targetCard);
		if (t.power === "protect") {
			let e = r === "wind" ? "hypoxia" : r === "fire" ? "cold" : r === "water" ? "heat" : null;
			if (!e) return Z();
			i.protection.push({
				rid: n,
				kind: e,
				amount: 1
			});
		} else if (t.power === "refresh") {
			if (r !== "wind" || !u || t.slot === void 0 || u.dice[String(t.slot)] === void 0) return Z();
			delete u.dice[String(t.slot)], i.pool++;
		} else if (t.power === "skill") {
			if (r !== "fire") return Z();
			Zi(i, a);
		} else if (t.power === "gain") {
			let e = lr[t.card];
			if (!e) return Z();
			X(i, e, a);
		} else if (t.power === "page") {
			let e = ur[t.card];
			if (!e) return Z();
			o.bookPages.includes(e) || (o.bookPages.push(e), t.card === 1307 && (o.temporaryBookPages ??= []).push(e)), i.milestones.vantages.includes(e) || i.milestones.vantages.push(e);
		} else if (t.power === "travel") {
			let e = dr[t.card];
			if (!e || ![
				"action",
				"cost",
				"dice",
				"story",
				"skirm",
				"arrival"
			].includes(i.phase)) return Z();
			let n = i.phase;
			la(i, a, e), n !== "arrival" && fa(i, n);
		} else if (t.power === "unique") {
			let e = t.faces;
			if (r !== "circuit" || !s || i.phase !== "cost" || !c || c.cost < 3 || i.setFaces.length || e.length !== Math.min(c.cost, 5) || new Set(e).size !== e.length) return Z();
			i.setFaces = [...e];
		} else if (t.power === "gamble") {
			if (r !== "gold" || !s || i.phase !== "dice" || !c || !c.dice.length || c.dice.length !== c.cost || c.dice.some((e) => e === null) || c.dice.length >= 8 + 2 * i.players.length || (i.pool || ca(i), i.pool < 1)) return Z();
			i.pool--, c.cost++, c.initialTime = [], c.dice = Array.from({ length: c.dice.length + 1 }, () => {
				let e = T[B(i, 6)];
				return e === "setback" && i.blankSetbacks ? "blank" : e;
			}), i.gamblePlayer = n;
		} else if (t.power === "impact") {
			if (r !== "energy" || i.temporaryImpact.includes(t.card)) return Z();
			i.temporaryImpact.push(t.card);
		} else if (t.power === "boost") {
			if (!u || u.boost >= E[u.card].boostCapacity) return Z();
			if (r === "energy") {
				if (u === e || u.card !== a.character && !cr(u.card)) return Z();
			} else if (r === "leaf") {
				if (!Ee(a.grid.indexOf(e)).includes(a.grid.indexOf(u))) return Z();
			} else return Z();
			q(u, 1);
		} else if (t.power === "stop") {
			if (r !== "sinew" || !s || i.stopForced.includes(n)) return Z();
			i.stopForced.push(n);
		} else if (t.power === "siphon") {
			let n = t.slot === void 0 ? void 0 : u?.dice[String(t.slot)];
			if (r !== "metal" || !u || u === e || u.boost < 1 || n === void 0) return Z();
			J(i, u, 1), q(e, 1), w.includes(n) && K(i, a, n, 1);
		} else if (t.power === "ignore") {
			if (r !== "sand" || !s || i.phase !== "dice" || !c || !t.indices.length || new Set(t.indices).size !== t.indices.length || t.indices.some((e) => c.dice[e] == null) || a.skills[c.skill] < t.indices.length) return Z();
			a.skills[c.skill] -= t.indices.length;
			for (let e of t.indices) c.dice[e] === "setback" ? i.pool++ : ei(i, c.dice[e]), c.dice[e] = null;
		} else if (t.power === "blank") {
			if (r !== "stone") return Z();
			i.blankRewards[n] = (i.blankRewards[n] ?? 0) + 1;
		} else if (t.power === "reroll") {
			if (r !== "water" || !s || i.phase !== "dice" || !c || t.die === void 0 || c.dice[t.die] == null) return Z();
			let e = T[B(i, 6)];
			c.dice[t.die] = e === "setback" && i.blankSetbacks ? "blank" : e, c.initialTime = c.initialTime?.filter((e) => e !== t.die);
		} else if (t.power === "scout") {
			if (r !== "wood" || !t.targetCard || !Object.values(E[o.location].exits).some((e) => e.destination === t.targetCard)) return Z();
			o.scouted.includes(t.targetCard) || o.scouted.push(t.targetCard);
		} else if (t.power === "cost") {
			if (r !== "wood" || !t.action || !O(o.location).some((e) => e.id === t.action && e.hasCost && !["depart", "secrets"].includes(e.book))) return Z();
			o.revealedCosts.includes(t.action) || o.revealedCosts.push(t.action);
		} else return Z();
		return r === "wood" && q(W(a), 1), H(i, t.power === "gamble" || t.power === "reroll" ? "roll" : "gain"), { state: i };
	}
	if (!s) return io();
	if (t.type === "puzzleMove") {
		if (i.phase !== "story" || !i.passage || !i.puzzle || i.pendingCards.length || ma(i) || i.skillRolls.length) return Z();
		let e = $t(i.puzzle, t);
		return e ? (i.puzzle = e, e.stage === "done" ? (e.id === 586 && e.success && br(a, 1640) && fr(i, a, 1640), Oa(i, en(e), "s" + e.id + ":0", i.passage.following)) : H(i, "place"), { state: i }) : Z();
	}
	if (t.type === "giveCoins" || t.type === "giveCard") {
		let e = i.players.find((e) => e.rid === t.target && e.rid !== n);
		if (i.phase !== "story" || !e || i.personal[e.rid].location !== o.location) return Z();
		if (t.type === "giveCoins") {
			if (a.coins < t.amount) return Z();
			a.coins -= t.amount, Be(i, e, t.amount);
		} else {
			let n = [...a.grid, ...a.reserve].find((e) => e?.card === t.card);
			if (!n || n.hiddenAt !== void 0 || ![
				"item",
				"flora",
				"vehicle"
			].includes(E[t.card].group) || i.pendingCards.length || ma(i)) return Z();
			let r = {
				...n,
				boost: 0,
				dice: { ...n.dice },
				placed: !0
			};
			if (!Y(i, a, t.card, !1)) return Z();
			(i.deliveries[e.rid] ??= []).push(r);
		}
		return H(i, "gain"), { state: i };
	}
	if (t.type === "resolveExperience") {
		if (i.phase !== "experience" || !Ki(a).some((e) => e.card === t.card) || !Y(i, a, t.card)) return Z();
		i.spentExperience.push(t.card);
		for (let e of de[t.card - 1454]) F(i, a, e, 1);
		return t.replace && Gi(i, a, 1441 + t.card - 1454), Ya(i), { state: i };
	}
	if (t.type === "characterPower" && t.power === "undo") {
		let e = i.challenge, t = i.rebornUndo;
		if (a.character !== 1453 || W(a).boost < 3 || i.phase !== "dice" || !e || !t || ma(i)) return Z();
		let r = structuredClone(t), o = r.players.find((e) => e.rid === n);
		if (o.character !== 1453 || !o.grid[4] || o.grid[4].boost < 3) return Z();
		J(r, o.grid[4], 3), r.cursor = i.cursor, r.eventSeq = i.eventSeq, r.rebornUndo = void 0;
		for (let e of Object.keys(r.personal)) r.personal[e].notes = i.personal[e].notes;
		return r.endingRequestedBy = i.endingRequestedBy, r.slotPermission = [...i.slotPermission], r.impactPermission = [...i.impactPermission], r.followConsent = [...i.followConsent], r.restrictedExcludes = [.../* @__PURE__ */ new Set([...r.restrictedExcludes ?? [], e.id])], no(r, n).length ? (H(r, "action"), { state: r }) : Z();
	}
	if (t.type === "characterPower") {
		let e = W(a), r = me(a.character), o = M(a), s = i.challenge;
		if (r !== "survivor" && r !== "armor" || e.boost < 1 || i.phase === "landing" || i.phase === "experience") return Z();
		if (t.power === "boost") {
			let n = a.grid.find((e) => e?.card === t.card);
			if (o !== 0 || !n || n.boost >= E[n.card].boostCapacity) return Z();
			J(i, e, 1), n.boost++;
		} else if (t.power === "skill") {
			if (o !== 1) return Z();
			J(i, e, 1), Zi(i, a);
		} else if (t.power === "switch") return o !== 2 || i.phase !== "cost" || !s || s.cost < 0 || t.action === s.id || !no(i, n, !0).some((e) => e.id === t.action) ? Z() : (J(i, e, 1), i.phase = "action", Co(i, {
			type: "chooseAction",
			id: t.action,
			sentientInteraction: t.sentientInteraction
		}, { by: n }));
		else if (t.power === "refreshPlaced") {
			let n = a.grid.find((e) => e?.card === t.card);
			if (o !== 3 || !n || n === e || t.slot === void 0 || n.dice[String(t.slot)] === void 0) return Z();
			J(i, e, 1), delete n.dice[String(t.slot)], i.pool++;
		} else if (t.power === "blankSetbacks") {
			if (o !== 4 || i.blankSetbacks) return Z();
			J(i, e, 1), i.blankSetbacks = !0, s && (s.dice = s.dice.map((e) => e === "setback" ? "blank" : e));
		} else if (t.power === "ignore") {
			if (o !== 5 || r !== "survivor" || i.phase !== "dice" || !s || t.die === void 0 || s.dice[t.die] == null) return Z();
			J(i, e, 1), s.dice[t.die] === "setback" ? i.pool++ : ei(i, s.dice[t.die]), s.dice[t.die] = null;
		} else if (t.power === "increase") {
			if (o !== 5 || r !== "armor" || i.phase !== "cost" || !s || s.cost < 0 || s.cost >= 8 + 2 * i.players.length) return Z();
			J(i, e, 1), s.cost++, Be(i, a, 1);
		} else return Z();
		return H(i, "gain"), { state: i };
	}
	if (t.type === "readGoal") return i.phase !== "action" || !i.center.some((e) => e.card === t.card) || !t.condition || t.card < 1598 || t.card > 1608 || !Vn(i, t.card) ? Z() : (i.destinyDone = !0, i.mission === 1596 && i.milestones.travelerRescue && (t.card === 1605 || t.card === 1608) && (i.missionDone = !0), Oa(i, D["s" + t.card + ":0"].node, "s" + t.card + ":0"), { state: i });
	if (t.type === "startPearlDefense") {
		if (i.phase !== "action" || i.pearlDefense || !br(a, 1681) || o.location !== 733 || o.forbiddenLocations.includes(733) || i.restrictedActions.length || i.restrictedBooks?.length || i.restrictedSkill) return Z();
		i.challenge = null, i.passage = null, i.storyTest = null, i.freeReading = !1, i.pearlDefense = {
			rid: n,
			remaining: [],
			rolling: 3
		};
		for (let e = 0; e < 3; e++) Zi(i, a, "pearl");
		return H(i, "roll"), { state: i };
	}
	if (t.type === "readPersonal") {
		let e = a.supply.find((e) => e.card === t.card), n = D["s" + t.card + ":0"];
		if (i.phase !== "action" || !t.condition || !e || e.rotated || !n || !ar(t.card) || !Cr(i, a, t.card)) return Z();
		if (t.card === 1682 && ze(i, a, 20), t.card === 1684) for (let e of C) a.skills[e]--;
		return t.card === 1685 && !Y(i, a, 989) ? Z() : (t.card === 1699 && o.questFlags.push(1699), i.challenge = null, i.freeReading = !0, Oa(i, n.node, n.id), { state: i });
	}
	if (t.type === "recordPathStation") {
		let e = a.supply.find((e) => e.card === 1673 && !e.rotated), n = o.pathStations ??= [];
		return i.phase !== "action" || !t.condition || !e || E[o.location]?.group !== "location" || n.some((e) => e.symbol === t.symbol) ? Z() : (n.push({
			symbol: t.symbol,
			location: o.location
		}), e.tokens = n.length, H(i, "gain"), { state: i });
	}
	if (t.type === "recordQuestLocation") {
		let e = a.supply.find((e) => e.card === 1631);
		if (i.phase !== "action" || t.card !== 1631 || !t.condition || !e || (e.tokens ?? 0) >= 4) return Z();
		let n = o.questLocations[1631] ??= [];
		return n.includes(o.location) ? Z() : (n.push(o.location), e.tokens = (e.tokens ?? 0) + 1, e.tokens === 4 ? (i.freeReading = !0, i.challenge = null, Oa(i, D["s1631:0"].node, "s1631:0")) : H(i, "gain"), { state: i });
	}
	if (t.type === "abandonQuest") return i.phase !== "action" || t.card !== 1685 || !br(a, 1685) || !Cr(i, a, 1685) ? Z() : (Y(i, a, 1685), H(i, "gain"), { state: i });
	if (t.type === "completeMission") {
		if (i.phase !== "action" || i.missionDone || !Vn(i, i.mission)) return Z();
		if (i.missionDone = !0, t.end) Qa(i, "mission");
		else {
			let e = t.destiny ?? Ln[i.mission];
			if (!e || Rn.includes(i.mission) && e !== Ln[i.mission]) return Z();
			if (i.center.some((t) => t.card === e) || i.center.push(V(e)), !Rn.includes(i.mission)) for (let e of i.players) Zi(i, e);
			H(i, "gain");
		}
		return { state: i };
	}
	if (t.type === "endCrisis") return i.phase === "crisis" ? (Qa(i, i.missionDone ? "mission" : "failure"), { state: i }) : Z();
	if (t.type === "chooseAction") {
		let e = no(i, n).find((e) => e.id === t.id);
		if (!e) return Z();
		let r = gr(i, a, t.id) && (o.usedLocations.includes(o.location) || o.usedActions.includes(t.id));
		if (i.rebornUndo = a.character === 1453 ? structuredClone({
			...i,
			rebornUndo: void 0
		}) : void 0, i.restrictedWater && !t.condition || (i.restrictedExclude = void 0, i.restrictedWater = !1, i.restrictedSkill = null, i.restrictedVerbs = [], i.restrictedBooks = [], i.restrictedDirections = [], i.copied = void 0, i.previewedOutcome = null, i.abilityDice = [], i.storySkirmGain = null, i.miniGame = null, Dn(o.location) && t.id !== "m" + o.location + ":0" && (o.skyOrigin = null), (t.id === "h1695:0" || t.id === "o1642:0") && !t.condition)) return Z();
		let s = t.id.startsWith("exit:") ? E[o.location].exits[t.id.slice(5)].destination : null, c = D[t.id], l = !!i.pearlDefense && !i.pearlDefense.active, u = l ? 3 : c ? typeof c.cost == "number" ? c.cost : -1 : 1;
		if (l && (i.pearlDefense.active = e.book === "depart" ? "move" : e.book), (c?.requiresWater || c?.condition) && !t.condition) return Z();
		if (c?.boostCost) {
			let t = a.grid.find((t) => t?.card === e.source);
			if (!t || t.boost < c.boostCost) return Z();
			J(i, t, c.boostCost);
		}
		if (i.summoning?.caller === n && !(c?.book === "overpower" && /^SLAY\b/.test(c.label)) && ha(i), i.elemental && !ci[e.source] && Ta(i, a), Wr(a, t.id, e.source, i.mission === 1593 && !i.missionDone) && t.sentientInteraction === void 0) return Z();
		let d = Ur(a) && (cr(e.source) !== null || Wr(a, t.id, e.source, i.mission === 1593 && !i.missionDone) && t.sentientInteraction) ? 1 : 0, f = i.nextBonus;
		i.nextBonus = void 0;
		let p = (i.nextActionDiscount ?? 0) + (e.book === "overpower" ? i.nextOverpowerDiscount?.[n] ?? 0 : 0);
		if (i.nextActionDiscount = 0, e.book === "overpower" && i.nextOverpowerDiscount && delete i.nextOverpowerDiscount[n], i.puzzle = null, i.lastSkirmWon = null, i.skillResult = null, i.runeSkill = null, i.runeFaces = [], i.storyTest = null, i.challengeRewardFace = null, i.trapTest = null, i.freeReading = !1, i.setFaces = [], i.sentientTrial = null, i.challenge = {
			questEntryRetry: r,
			id: t.id,
			source: e.source,
			skill: c ? ee(c) : "move",
			cost: u < 0 ? -1 : Math.max(0, u + d - p),
			...l && typeof c?.cost == "string" ? { chosenX: 3 } : {},
			dice: [],
			direct: s,
			obstacleCleared: !1,
			surcharge: d,
			discount: p,
			interaction: {
				location: o.location,
				sentients: cr(e.source) !== null || Wr(a, t.id, e.source, !0) && t.sentientInteraction === !0 ? [i.milestones.sentientOrigins[e.source] ?? (E[e.source]?.group === "sentient" ? "card:" : "location:") + e.source] : [],
				traveler: !1,
				curse: !1
			}
		}, i.elemental && ci[e.source]) {
			let e = i.elemental.next;
			e === "discount" && (i.challenge.discount = (i.challenge.discount ?? 0) + 2, i.challenge.cost >= 0 && (i.challenge.cost = Math.max(0, i.challenge.cost - 2))), i.challenge.ignoreHealth = e === "ignoreHealth", i.challenge.rerollAll = e === "reroll", i.elemental.next = "none";
		}
		return i.nextActionMaxCost !== void 0 && (i.challenge.cost = i.challenge.cost < 0 ? -1 : Math.max(0, Math.min(u, i.nextActionMaxCost) + d - p), i.challenge.maxCost = i.nextActionMaxCost, i.nextActionMaxCost = void 0), i.challenge.bonus = f, f && i.challenge.cost >= 0 && (i.challenge.cost = Math.max(0, nn(Math.min(u, i.challenge.maxCost ?? Infinity), f, i.players.reduce((e, t) => e + t.skills.help, 0)) + (i.challenge.surcharge ?? 0) - (i.challenge.discount ?? 0))), i.challenge.foresight = i.foresight, i.foresight = [], i.challenge.statsBefore = { ...a.stats }, i.challenge.ability = e.source >= 1460 && e.source <= 1516 ? e.source : void 0, i.freeOverpower && (i.challenge.skipChallenge = !0, delete i.freeOverpower), i.phase = "cost", i.passage = null, H(i, "action"), { state: i };
	}
	if (t.type === "chooseCost") return i.phase !== "cost" || !i.challenge || i.challenge.cost !== -1 ? Z() : (i.challenge.chosenX = t.cost, i.powerTravel?.length && D[i.challenge.id]?.book === "depart" ? (i.challenge.cost = 0, Aa(i), { state: i }) : (i.challenge.cost = Math.max(0, nn(Math.min(t.cost, i.challenge.maxCost ?? t.cost), i.challenge.bonus, i.players.reduce((e, t) => e + t.skills.help, 0)) + (i.challenge.surcharge ?? 0) - (i.challenge.discount ?? 0)), { state: i }));
	if (t.type === "clearObstacle") {
		let e = i.challenge;
		return i.phase !== "cost" || !e || e.cost < 1 || i.setFaces.length || e.obstacleCleared || !t.condition || !/reduce this cost to 1/i.test(D[e.id]?.label ?? "") ? Z() : (e.cost = Math.max(0, 1 + (e.surcharge ?? 0) - (e.discount ?? 0)), e.obstacleCleared = !0, { state: i });
	}
	if (t.type === "roll") {
		let e = i.challenge;
		if (i.phase !== "cost" || !e || e.cost < 0 || e.bonus?.chooseIgnore) return Z();
		if (e.skipChallenge) return ei(i, ...e.foresight ?? []), e.foresight = [], e.dice = [], i.phase = "dice", H(i, "roll"), { state: i };
		let t = e.cost + (e.extraChallengeDice ?? 0) + (e.extraChoice ? 2 : 0), r = e.foresight ?? [], o = Math.min(t, r.length), s = t - o, c = t < r.length ? e.foresightSelection : Array.from({ length: o }, (e, t) => t);
		if (!c || c.length !== o) return Z();
		let l = c.map((e) => r[e]);
		return i.pool < s && ca(i), i.pool < s ? Z() : (i.pool -= s, ei(i, ...r.filter((e, t) => !c.includes(t))), e.foresight = [], e.dice = Array.from({ length: t }, (e, t) => {
			let n = t < o ? l[t] : i.setFaces[t] ?? T[B(i, 6)];
			return n === "setback" && i.blankSetbacks ? "blank" : n;
		}), i.setFaces = [], e.initialTime = e.bonus?.initial ? e.dice.flatMap((e, t) => e === "time" ? [t] : []) : [], e.bonus?.initial && (e.dice = e.dice.map((e) => {
			let t = e === "morale" ? T[B(i, 6)] : e;
			return t === "setback" && i.blankSetbacks ? "blank" : t;
		})), i.phase = "dice", e.extraChoice && (i.powerDiscardDice = {
			rid: n,
			remaining: 2
		}), e.luck && (e.luck = !1, i.printedRoll = {
			rid: n,
			card: 1372,
			kind: "luck",
			count: 1,
			faces: []
		}, Zi(i, a, "printed")), H(i, "roll"), { state: i });
	}
	if (t.type === "rerollDie") {
		let e = i.challenge, n = W(a);
		if (i.phase !== "dice" || !e || e.dice[t.die] == null || n.boost < 1) return Z();
		let r = me(a.character), o = e.dice[t.die];
		if (r === "armor") return e.dice[t.die] = null, i.pool++, J(i, n, 1), H(i, "place"), { state: i };
		if (r !== "starting" && r !== "survivor") return Z();
		let s;
		do {
			let e = T[B(i, 6)];
			s = e === "setback" && i.blankSetbacks ? "blank" : e;
		} while (r === "survivor" && s === o);
		return e.initialTime = e.initialTime?.filter((e) => e !== t.die), e.dice[t.die] = s, J(i, n, 1), r === "starting" && o === s && F(i, a, pe(a.character), 1), H(i, "roll"), { state: i };
	}
	if (t.type === "rerollElemental") {
		let e = i.challenge;
		return i.phase !== "dice" || !e?.rerollAll || e.placed || !e.dice.length || e.dice.some((e) => e === null) ? Z() : (e.rerollAll = !1, e.initialTime = [], e.dice = e.dice.map(() => {
			let e = T[B(i, 6)];
			return e === "setback" && i.blankSetbacks ? "blank" : e;
		}), H(i, "roll"), { state: i });
	}
	if (t.type === "placeDie") {
		let e = i.challenge, r = i.players.find((e) => e.rid === t.owner), s = r?.grid.find((e) => e?.card === t.card) ?? (t.owner === n && i.summoning?.caller === n && i.summoning.solo?.card === t.card ? i.summoning.solo : void 0), c = E[t.card]?.slots[t.slot];
		if (s && !Gr(t.card, t.slot, s.boost)) return Z();
		let l = c && s?.bonded && cr(t.card) ? 0 : c?.cost ?? 0, u = e?.dice[t.die];
		return i.phase !== "dice" || !e || !r || !s || !c || u == null || s.dice[String(t.slot)] !== void 0 || s.boost < l || r.rid !== n && !(c.impact || i.temporaryImpact.includes(t.card) ? i.impactPermission.includes(r.rid) : i.slotPermission.includes(r.rid) && (i.personal[r.rid].location === o.location || i.summoning?.caller === n && i.summoning.summoned.includes(r.rid))) || !Hr(t.card, c, e, u, t.condition, r, a) || t.card === 987 && s.rotated ? Z() : (e.placed = !0, (e.placedSlots ??= []).push({
			rid: r.rid,
			card: t.card,
			slot: t.slot
		}), s.dice[String(t.slot)] = u, e.dice[t.die] = null, J(i, s, l), mo(i, r, s, t.slot, u), H(i, "place"), { state: i });
	}
	if (t.type === "penalties") {
		let e = i.challenge;
		if (i.phase !== "dice" || !e) return Z();
		e.unplaced = e.dice.filter((e) => e !== null).length;
		let t = {
			time: 0,
			morale: 0,
			health: 0
		}, r = e.dice.filter((t, n) => t === "setback" && !rn(e.bonus, t, n, e.initialTime ?? [])).length;
		for (let [n, r] of e.dice.entries()) if (r !== null) {
			if (rn(e.bonus, r, n, e.initialTime ?? [])) {
				r === "setback" ? i.pool++ : ei(i, r);
				continue;
			}
			r === "setback" ? i.pool++ : (ei(i, r), r !== "blank" && !(r === "health" && e.ignoreHealth) && !(r !== "time" && o.animalProtection?.includes(r)) && t[r]++);
		}
		let s = i.players.flatMap((e) => e.grid.flatMap((e) => e && Dr(e.card) ? [e.card] : []));
		for (let t = 0; t < r; t++) for (let t of Se(e.source, s, e.direct === null && ye(e.id), a)) i.arrivals.push({
			rid: n,
			location: o.location,
			instruction: t.instruction,
			paid: !1,
			curse: t.card
		});
		for (let e of w) K(i, a, e, -t[e]);
		return e.dice = [], H(i, "penalty"), !fa(i, "result") && !Xa(i) && Aa(i), { state: i };
	}
	if (t.type === "applyEffect") {
		if (i.phase !== "story" || !i.passage) return Z();
		let e = k(i.passage.node, le(i.storyTest)), r = e.effects[t.index];
		if (!r || e.blocked || i.pendingCards.length || ma(i) || i.passage.applied.includes(t.index) || e.effects.some((e, n) => n < t.index && !i.passage.applied.includes(n))) return Z();
		if (r.kind === "puzzle") {
			if (i.puzzle && i.puzzle.stage !== "done" || (i.puzzle = Nt(r.amount), !i.puzzle)) return Z();
		} else if (r.kind === "miniGame") {
			if (i.miniGame && !i.miniGame.done) return Z();
			let e = Dt(r.value, r.value === "tournament" && i.challenge?.skill !== "overpower" ? 0 : i.challenge?.chosenX ?? 0, (e) => B(i, e), r.value === "mancala" ? o.mancalaAttempts ?? 0 : r.value === "race" ? M(a) : r.amount);
			i.miniGame = e.game, $i(i, a, e.rolls);
		} else if (r.kind === "miniCoins") {
			if (!i.miniGame?.done) return Z();
			i.miniGame.coins > 0 ? Be(i, a, i.miniGame.coins) : a.coins = Math.max(0, a.coins + i.miniGame.coins);
		} else if (r.kind === "miniSkills") {
			if (!i.miniGame?.done) return Z();
			F(i, a, r.value, i.miniGame.wins);
		} else if (r.kind === "copyAction") {
			let e = Ha(i, a).find((e) => e.id === t.action), n = i.passage.node, r = i.challenge;
			if (!e || !r || D[e.id]?.requiresWater && !t.condition || D[e.id]?.condition && !t.condition) return Z();
			let o = i.passage, s = {
				id: r.id,
				source: r.source
			};
			return i.copied = {
				ability: r.ability ?? r.source,
				source: e.source,
				trail: [
					...i.copied?.trail ?? [],
					r.id,
					e.id
				],
				retainFlora: n.retainFlora ?? i.copied?.retainFlora,
				retainBlueprint: n.retainBlueprint ?? i.copied?.retainBlueprint,
				doubleBenefit: n.doubleBenefit ?? i.copied?.doubleBenefit,
				assemblyBonus: n.assemblyBonus ?? i.copied?.assemblyBonus,
				assemblyEarned: i.copied?.assemblyEarned,
				discount: n.copyFollowDiscount ?? i.copied?.discount,
				benefits: i.copied?.benefits ?? []
			}, r.id = e.id, r.source = e.source, i.storyTest = null, i.skillResult = null, i.lastSkirmWon = null, Aa(i, o.following.map((e, t) => t === 0 && n.after ? {
				...e,
				inheritContinuation: !/\bcontinue\b/i.test(e.node.text),
				restoreSource: s
			} : e)), { state: i };
		} else if (r.kind === "testPickMany") {
			let e = t.diceIndices;
			if (!i.storyTest?.done || !e || e.length !== r.amount || new Set(e).size !== e.length || e.some((e) => e >= le(i.storyTest).length)) return Z();
			for (let t of e) F(i, a, le(i.storyTest)[t], 1);
		} else if (r.kind === "crewLocations") for (let e of i.players) e.rid !== n && !o.scouted.includes(i.personal[e.rid].location) && o.scouted.push(i.personal[e.rid].location);
		else if (r.kind === "testPickOne") {
			if (!i.storyTest?.done || !t.skill || !le(i.storyTest).includes(t.skill)) return Z();
			F(i, a, t.skill, 1);
		} else if (r.kind === "matchingTestReward") {
			if (!i.storyTest?.done) return Z();
			let e = C.filter((e) => le(i.storyTest).filter((t) => t === e).length >= 2);
			e.length || K(i, a, "time", -1);
			for (let t of e) F(i, a, t, le(i.storyTest).filter((e) => e === t).length);
		} else if (r.kind === "printedAbility") {
			if (!Ja(i, a, t, r.value)) return Z();
		} else if (r.kind === "selectedBoost") {
			let e = r.value === "experience" ? G(a) : a.grid, n = t.cards?.length === 1 ? e.find((e) => e?.card === t.cards[0]) : void 0;
			if (!n || !P(n.card, r.value) || !t.amount || t.amount > r.amount || t.amount < (i.passage.node.selectedBoost?.min ?? 1)) return Z();
			q(n, t.amount);
		} else if (r.kind === "masterReward") {
			let e = i.players.find((e) => e.rid === t.target);
			if (!e) return Z();
			let n = M(e);
			X(i, 1454 + n, e);
			for (let t of de[n]) F(i, e, t, 1);
		} else if (r.kind === "animalAir") r.value === "next" ? o.ignoreNextHypoxia = !0 : o.hypoxiaSuffered && K(i, a, "health", 1);
		else if (r.kind === "testCoins") {
			if (!i.storyTest?.done) return Z();
			Be(i, a, new Set(le(i.storyTest)).size);
		} else if (r.kind === "gardenTuck") {
			let e = ja(i), t = Ji(i, e), n = Number(r.value);
			if (!t || ![1288, 1291].includes(e) || E[n]?.group !== "flora") return Z();
			X(i, n, a), (i.pendingCards.includes(n) || i.cardClaims.some((e) => e.card === n)) && ((i.pendingTucks ??= {})[n] = e);
		} else if (r.kind === "gardenPluck") {
			let e = Ji(i, ja(i)), n = t.cards?.[0];
			if (t.cards?.length !== 1 || !e?.tucked?.some((e) => e.card === n)) return Z();
			let r = e.tucked.find((e) => e.card === n);
			e.tucked = e.tucked.filter((e) => e.card !== n), i.pendingCards.push(r.card), i.pendingInstances[r.card] = r, (i.requiredGrid ??= []).push(r.card);
		} else if (r.kind === "trap") i.trapTest = {
			target: r.value,
			faces: Array.from({ length: 3 }, () => T[B(i, 6)])
		};
		else if (r.kind === "challengeCheck") {
			let e = i.passage.node.challengeCheck;
			e.from === "center" ? i.penaltyDice > 0 && (ti(i, 1), i.pool++) : i.pool === 0 && (i.penaltyDice > 0 ? (ti(i, 1), i.pool++) : ca(i));
			let t = T[B(i, 6)];
			i.trapTest = {
				target: e.match ?? e.penalty ?? "time",
				faces: [t]
			}, e.penalty && t === e.penalty && (K(i, a, e.penalty, -1), i.pool--, ei(i, t));
		} else if (r.kind === "departureLimit") o.departureLimit = i.passage.node.departureLimit;
		else if (r.kind === "loseRememberedSkirm") {
			let e = i.storySkirmGain;
			e != null && a.skirm.includes(e) && (a.skirm = a.skirm.filter((t) => t !== e), i.pack.push(e)), i.storySkirmGain = null;
		} else if (r.kind === "boostMatching") for (let e of a.grid) e && (r.value === "animal" ? E[e.card].group === "animal" : _e(e.card, a).some((e) => e === r.value)) && q(e, r.amount);
		else if (r.kind === "challengeReward") {
			let e = T[B(i, 6)];
			i.challengeRewardFace = e, w.includes(e) && K(i, a, e, 1);
		} else if (r.kind === "structureTrade") {
			let e = i.challenge?.source, n = e ? Ji(i, e) : void 0;
			if (!e || !n || E[e].group !== "structure") return Z();
			let [o, s] = r.value.split(":"), c = r.amount >= 0 ? r.amount : r.amount === -1 ? i.challenge?.chosenX : n.boost + (r.amount === -3 ? G(a).filter((e) => P(e.card, "ability")).length : 0);
			if (c === void 0) return Z();
			if (o === "boost") {
				if (n.boost < 1) return Z();
				J(i, n, 1), Be(i, a, c);
			} else if (o === "income") Be(i, a, c);
			else if (o === "sell") {
				let t = i.players.find((e) => G(e).includes(n)), r = E[e].value;
				if (!t || n.boost < 3 || r === void 0) return Z();
				J(i, n, 3), Y(i, t, e), Be(i, a, r);
			} else if (o === "card" || o === "token") {
				if (t.cards?.length !== 1 || !Pn(a, o, s, e).includes(t.cards[0])) return Z();
				let n = qi(a).find((e) => e.card === t.cards[0]);
				o === "token" ? (J(i, n, 1), Be(i, a, c)) : (Be(i, a, E[n.card].value + c), Y(i, a, n.card));
			} else return Z();
		} else if (r.kind === "nextActionDiscount") {
			if (i.challenge?.chosenX === void 0) return Z();
			i.nextActionDiscount = i.challenge.chosenX;
		} else if (r.kind === "runeBoost") q(W(a), 1), i.runeSurvey = i.players.filter((e) => e.rid !== n).map((e) => e.rid);
		else if (r.kind === "runeRoll" || r.kind === "runeSkill") {
			if (!t.skill || !t.condition) return Z();
			if (i.runeSkill = t.skill, r.kind === "runeSkill") F(i, a, t.skill, r.amount);
			else {
				let e = r.amount > 0 ? r.amount : i.challenge?.chosenX;
				if (e === void 0) return Z();
				i.runeFaces = [];
				for (let n = 0; n < e; n++) Zi(i, a, "rune", t.skill);
			}
		} else if (r.kind === "runeQuest") {
			if (!Ji(i, 1706)) {
				if (!i.runeSkill || t.line === void 0) return Z();
				X(i, 1706), i.pendingInstances[1706] = {
					...V(1706),
					tokens: 1
				}, i.runeQuest = { entries: [{
					location: o.location,
					skill: i.runeSkill,
					row: t.line
				}] };
			}
		} else if (r.kind === "barter") {
			let e = i.passage.node.barter, n = t.cards, r = an(a, e);
			if (!n || new Set(n).size !== n.length || n.length < e.min || n.length > e.max || n.some((e) => !r.includes(e))) return Z();
			let o = n.reduce((e, t) => e + (E[t].value ?? 0), 0);
			if (o < (e.minTotal ?? 0)) return Z();
			for (let t of n) e.token ? J(i, G(a).find((e) => e.card === t), 1) : Y(i, a, t);
			e.sale && n.length && Be(i, a, o + (e.bonus === "X" ? i.challenge?.chosenX ?? 0 : e.bonus ?? 0));
		} else if (r.kind === "coinCount") Be(i, a, W(a).boost + G(a).filter((e) => P(e.card, "map")).length);
		else if (r.kind === "partyStat") {
			let [e, t] = r.value.split(":");
			for (let a of i.players) (e === "all" || e === "contributors" && i.paymentContributors?.includes(a.rid) || e === "others" && a.rid !== n) && K(i, a, t, r.amount);
		} else if (r.kind === "crewShare") i.crewSharing = {
			decisions: {},
			faces: {}
		};
		else if (r.kind === "crewLearn") {
			if (i.players.length === 1) {
				if (!t.skill) return Z();
				F(i, a, t.skill, 1);
			} else for (let e of i.players) e.rid !== n && F(i, a, C[M(e)], 1);
		} else if (r.kind === "stowCards") {
			if (_a(a)) return { code: "games.vantage.errReserveFull" };
		} else if (r.kind === "removeCurses" || r.kind === "sellCards") {
			let e = t.cards;
			if (!e || new Set(e).size !== e.length || e.length > r.amount) return Z();
			let [n, o, s] = r.value.split(":"), c = qi(a).filter((e) => r.kind === "removeCurses" ? Dr(e.card) : e.card !== a.character && E[e.card].value !== void 0 && (s !== "items" || E[e.card].group === "item")), l = r.kind === "removeCurses" ? r.value === "required" ? Math.min(r.amount, c.length) : 0 : Number(n);
			if (e.length < l || e.some((e) => !c.some((t) => t.card === e))) return Z();
			let u = r.kind === "sellCards" ? e.reduce((e, t) => e + E[t].value + Number(o), 0) : 0;
			for (let t of e) Y(i, a, t);
			Be(i, a, u);
		} else if (r.kind === "sentientBoost") for (let e of a.grid) e && E[e.card].group === "sentient" && q(e, r.amount);
		else if (r.kind === "makeShelter") {
			let e = Ji(i, i.challenge?.source ?? 0);
			if (!e || E[e.card].group !== "structure") return Z();
			e.shelter = !0;
		} else if (r.kind === "reserveVehicles") for (let e = 0; e < a.grid.length; e++) {
			let t = a.grid[e];
			t && E[t.card].group === "vehicle" && (i.pool += Object.keys(t.dice).length, t.dice = {}, a.grid[e] = null, a.reserve.push(t));
		}
		else if (r.kind === "dive") {
			let e = Number(r.value);
			la(i, a, e), sa(i, a, (t) => t.location === e && t.instruction.value === ({
				1: "hypoxia",
				2: "cold",
				3: "heat"
			}[r.amount] ?? "hypoxia"));
		} else if (r.kind === "gridRefresh") {
			let e = La(a), n = t.refreshDice;
			if (!n || n.length > r.amount || r.value === "exact" && n.length !== Math.min(r.amount, e.length) || new Set(n.map((e) => e.card + ":" + e.slot)).size !== n.length || n.some((t) => !e.some((e) => e.card === t.card && e.slot === t.slot))) return Z();
			for (let e of n) delete a.grid.find((t) => t?.card === e.card).dice[String(e.slot)], i.pool++;
		} else if (r.kind === "rest") {
			let e = Ra(i, a), n = t.refreshDice, r = i.challenge?.chosenX;
			if (r === void 0 || !n || n.length !== Math.min(r, e.length) || new Set(n.map((e) => e.card + ":" + e.slot)).size !== n.length || n.some((t) => !e.some((e) => e.card === t.card && e.slot === t.slot))) return Z();
			for (let e of n) delete a.grid.find((t) => t?.card === e.card).dice[String(e.slot)], i.pool++;
			let o = a.grid.every((e) => !e || !Object.keys(e.dice).length);
			o && K(i, a, "health", 1), i.continuation = o && /you may continue/i.test(i.passage.node.text) ? "may" : "no";
		} else if (r.kind === "skillTest") {
			let e = i.passage.node.skillTest, t = e.count === "X" ? i.challenge?.chosenX : e.count, r = e.fishing ? a.grid.reduce((e, t) => e + (t ? {
				897: 2,
				898: 1,
				899: 1,
				910: 1,
				911: 1,
				912: 2,
				913: 1,
				921: 2,
				932: 2
			}[t.card] ?? 0 : 0), 0) : 0, o = t === void 0 ? void 0 : t + r;
			if (!o || i.storyTest && !i.storyTest.done) return Z();
			i.storyTest = {
				rid: n,
				spec: e,
				count: o + (i.challenge?.testExtraDice ?? 0),
				rounds: 0,
				faces: [],
				remaining: 0,
				done: !1,
				baitUsed: !1,
				rerolled: []
			}, i.challenge && (i.challenge.testExtraDice = 0);
		} else if (r.kind === "cardInitialBoost") {
			let e = Number(r.value);
			X(i, e, a), (i.pendingCards.includes(e) || i.cardClaims.some((t) => t.card === e && t.requester === n)) && (i.pendingInstances[e] = {
				...V(e),
				initialBoost: r.amount
			});
		} else if (r.kind === "keepTestAll") {
			if (!i.storyTest?.done) return Z();
			for (let e of le(i.storyTest)) F(i, a, e, 1);
		} else if (r.kind === "keepTestSkill") {
			if (!i.storyTest?.done) return Z();
			F(i, a, r.value, le(i.storyTest).filter((e) => e === r.value).length);
		} else if (r.kind === "testStat" || r.kind === "testBoost") {
			if (!i.storyTest?.done) return Z();
			let [e, t] = r.value.split(":"), n = le(i.storyTest).filter((e) => e === t).length * r.amount;
			r.kind === "testStat" ? K(i, a, e, n) : n < 0 ? J(i, W(a), -n) : q(W(a), n);
		} else if (r.kind === "coinX" || r.kind === "boostX" || r.kind === "sourceCoin") {
			let e = i.challenge?.source, t = e ? Ji(i, e) : void 0, n = r.kind === "sourceCoin" ? t?.boost : i.challenge?.chosenX;
			if (n === void 0) return Z();
			if (r.kind === "boostX") {
				if (!t) return Z();
				q(t, n);
			} else Be(i, a, n);
		} else if (r.kind === "rewind") return gn(i, !0, (e) => B(i, e)), H(i, "setup"), { state: i };
		else if (r.kind === "flight") {
			if (!ua(i, a, !!r.amount)) return Z();
		} else if (r.kind === "returnSky") {
			if (!Dn(o.location) || o.skyOrigin == null) return Z();
			la(i, a, o.skyOrigin), q(W(a), 1);
		} else if (r.kind === "dragonEscape") return i.challenge?.id !== "m1110:0" || !Bn(i, n) ? Z() : (i.milestones.dragonEscape = !0, i.destinyDone = !0, Oa(i, D["s1602:0"].node, "s1602:0"), { state: i });
		else if (r.kind === "partySkill") {
			let [e, t] = r.value.split(":");
			for (let a of i.players.filter((t) => e === "all" || t.rid !== n)) if (t === "random") for (let e = 0; e < r.amount; e++) Zi(i, a);
			else F(i, a, t, r.amount);
		} else if (r.kind === "missionPivot") {
			if (Number(r.value) !== i.mission || i.missionDone || i.missionPivot) return Z();
			i.missionPivot = !0, i.mission === 1577 && (i.milestones.elementalAction = !1), i.mission === 1578 && (i.milestones.founderTemple = !1), i.mission === 1596 && (i.milestones.travelerLocations = []), (i.mission === 1593 || i.mission === 1596) && (i.center.find((e) => e.card === i.mission).tokens = i.mission === 1593 ? Math.min(2, zn(i)) : 0), i.mission === 1592 && (i.center.find((e) => e.card === 1592).tokens = Math.min(3, Math.max(0, ...Object.values(i.milestones.conquests)) + 2));
		} else if (r.kind === "loseSkill") {
			if (C.some((e) => a.skills[e] > 0)) {
				if (!t.skill || a.skills[t.skill] < 1) return Z();
				a.skills[t.skill]--;
			}
		} else if (r.kind === "skillChoice") {
			if (!t.skill) return Z();
			F(i, a, t.skill, r.amount);
		} else if (r.kind === "signal") {
			let e = ja(i);
			i.milestones.towers.includes(e) || i.milestones.towers.push(e);
			let t = i.center.find((e) => e.card === 1598);
			t || (t = V(1598), i.center.push(t)), t.tokens = i.milestones.towers.length;
		} else if (r.kind === "conquest") {
			if (i.mission !== 1592 || i.missionDone || !(o.location === 41 || o.location >= 518 && o.location <= 531)) return Z();
			i.milestones.conquests[o.location] = (i.milestones.conquests[o.location] ?? 0) + 1, i.center.find((e) => e.card === 1592).tokens = Math.min(3, Math.max(...Object.values(i.milestones.conquests)) + (i.missionPivot ? 2 : 0));
		} else if (r.kind === "questProgress") {
			let e = r.value === "teach" ? 1695 : r.value === "herd" ? 1702 : r.value === "siege" ? 1659 : r.value === "waterConquest" ? 1642 : r.value === "flags" ? 1669 : 1680, n = a.supply.find((t) => t.card === e && !t.rotated);
			if (!n || e === 1680 && o.location !== 785 || e === 1702 && (o.location !== 387 || !i.storyTest?.done) || e === 1659 && (o.location !== 760 || i.challenge?.chosenX === void 0 || i.challenge.unplaced === void 0)) return Z();
			if (e === 1702) n.tokens = Math.min(4, (n.tokens ?? 0) + le(i.storyTest).filter((e) => e === "move").length);
			else if (e === 1659) n.tokens = Math.max(0, (n.tokens ?? 0) + i.challenge.chosenX - i.challenge.unplaced);
			else {
				if (e === 1669) {
					let e = o.questLocations[1669] ??= [];
					if (!vr.includes(o.location) || e.includes(o.location)) return Z();
					e.push(o.location), o.questLocations[1669] = e;
				}
				if (e === 1642) {
					let e = o.questLocations[1642] ??= [];
					if (o.usedLocations.includes(o.location) || e.includes(o.location)) return Z();
					e.push(o.location), o.questLocations[1642] = e, o.forbiddenLocations.push(o.location);
				}
				n.tokens = (n.tokens ?? 0) + 1;
			}
			if (e === 1695 && F(i, a, "help", n.tokens), e === 1642 && F(i, a, "overpower", n.tokens), e !== 1702 && n.tokens >= (e === 1659 ? 9 : [
				1695,
				1642,
				1669
			].includes(e) ? 3 : 2)) {
				e === 1695 && (n.tokens = 0);
				let r = i.passage, a = D["s" + e + ":0"], o = {
					node: {
						...r.node,
						after: void 0
					},
					entry: r.entry,
					applied: [...r.applied, t.index]
				};
				return e === 1642 && (n.tokens = 0), Oa(i, a.node, a.id, [o, ...r.following]), { state: i };
			}
		} else if (r.kind === "cardWithBoost") {
			let e = Number(r.value);
			X(i, e, a), (i.pendingCards.includes(e) || i.cardClaims.some((t) => t.card === e && t.requester === n)) && (i.pendingInstances[e] = {
				...V(e),
				boost: Math.min(E[e].boostCapacity, r.amount)
			});
		} else if (r.kind === "cardIfMissing") G(a).some((e) => e.card === Number(r.value)) || X(i, Number(r.value), a);
		else if (r.kind === "elemental" || r.kind === "preparation") {
			let e = ja(i);
			if (r.value === "prepare") {
				if (r.kind === "elemental" && !si[e] || !t.preparation) return Z();
				if (t.preparation === "skills") {
					if (!t.skill) return Z();
					Zi(i, a), F(i, a, t.skill, 1);
				} else {
					if (t.line === void 0) return Z();
					for (let [e, n] of a.grid.entries()) n && (t.preparation === "row" && Math.floor(e / 3) === t.line && (i.pool += Object.keys(n.dice).length, n.dice = {}), t.preparation === "column" && e % 3 === t.line && q(n, 1));
				}
			} else if (r.value === "siphon") {
				if (!si[e] || r.amount < 1365 || r.amount > 1384) return Z();
				X(i, r.amount, a);
			} else if (r.value === "summon") {
				let t = _e(e, a)[0];
				if (!si[e] || !t) return Z();
				ha(i);
				let r = i.players.filter((e) => e.rid !== n && [...e.grid, ...e.reserve].some((n) => n && _e(n.card, e).includes(t))).map((e) => e.rid);
				i.summoning = {
					caller: n,
					element: t,
					waiting: i.players.length === 1 ? [n] : i.players.filter((e) => e.rid !== n && !r.includes(e.rid) && W(e).boost >= 2).map((e) => e.rid),
					summoned: r,
					solo: null
				};
			} else if (r.value === "start") {
				let t = si[e];
				if (!t || i.elemental || o.location !== e) return Z();
				i.elemental = {
					rid: n,
					location: e,
					cards: Array.from({ length: 4 }, (e, n) => t.first + n),
					next: "none"
				}, X(i, t.curse, a), i.continuation = "must";
			} else {
				let t = i.elemental, o = ci[e];
				if (!t || t.rid !== n || !t.cards.includes(e) || !o) return Z();
				if (r.value === "retreat") Ta(i, a), q(W(a), 1), i.continuation = "no";
				else if (r.value === "strike") t.cards = t.cards.filter((t) => t !== e), (!o.afterOnly || t.cards.length) && (o.refresh === "all" ? ca(i) : o.refresh === "center" && (i.pool += i.penaltyDice, ti(i, i.penaltyDice))), o.boost && q(W(a), o.boost), o.morale && K(i, a, "morale", o.morale), o.curse && Y(i, a, o.curse), t.cards.length ? (t.next = o.next, i.continuation = "must") : (i.milestones.elementalSlain = !0, t.location === 369 && fr(i, a, 1693), X(i, o.weapon, a), i.elemental = null, i.continuation = "no");
				else return Z();
			}
		} else if (r.kind === "boost") {
			let e = i.challenge?.source, t = r.value !== "character" && e && E[e]?.group !== "location" ? Ji(i, e) : W(a);
			if (!t) return Z();
			r.amount < 0 ? J(i, t, -r.amount) : q(t, r.amount);
		} else if (r.kind === "forbidLocation") o.forbiddenLocations.includes(Number(r.value)) || o.forbiddenLocations.push(Number(r.value));
		else if (r.kind === "coin") r.amount > 0 ? Be(i, a, r.amount) : a.coins = Math.max(0, a.coins + r.amount);
		else if (r.kind === "obstacleMorale") i.challenge?.obstacleCleared || K(i, a, "morale", 1);
		else if (r.kind === "sentientTrial") {
			let e = ja(i);
			if (!a.grid.find((t) => t?.card === e) || !cr(e)) return Z();
			i.sentientTrial = {
				rid: n,
				card: e,
				faces: [],
				remaining: r.amount,
				success: !1,
				bond: r.value === "bond"
			};
			for (let e = 0; e < r.amount; e++) Zi(i, a, "trial");
		} else if (r.kind === "skillResult") Zi(i, a, r.amount === 2 ? "resultGain" : "result");
		else if (r.kind === "stat") K(i, a, r.value, r.amount);
		else if (r.kind === "skill") F(i, a, r.value, r.amount);
		else if (r.kind === "randomSkill") for (let e = 0; e < r.amount; e++) Zi(i, a);
		else if (r.kind === "rollSkill") for (let e = 0; e < r.amount; e++) Zi(i, a, "match", r.value);
		else if (r.kind === "skirmCard") {
			if (eo(i, a)) return { code: "games.vantage.errReserveFull" };
			if (i.pack.length) {
				let e = i.pack.splice(B(i, i.pack.length), 1)[0];
				a.skirm.push(e), i.passage.node.rememberSkirmGain && (i.storySkirmGain = e);
			}
		} else if (r.kind === "powerArmor") {
			if (me(a.character) === "other") return Z();
			if (me(a.character) === "armor") W(a).boost = Math.min(E[a.character].boostCapacity, W(a).boost + Number(r.value));
			else {
				if (r.amount === 1 && t.replaceCharacter === void 0) return Z();
				(r.amount === 0 || t.replaceCharacter) && Gi(i, a, 1447 + M(a));
			}
		} else if (r.kind === "damage") {
			let e = oa(i, a, r.value, r.amount);
			if (e) {
				if (!t.damage) return Z();
				r.value === "hypoxia" && (o.hypoxiaSuffered = !0), t.damage === "health" ? K(i, a, "health", -e) : (K(i, a, "time", -e), K(i, a, "morale", -e));
			}
		} else if (r.kind === "vantage") {
			let e = r.value === "region" ? kn(o.location) : Number(r.value);
			if (e === null || e < 1 || e > 50) return Z();
			o.temporaryBookPages = o.temporaryBookPages?.filter((t) => t !== e), o.bookPages.includes(e) || o.bookPages.push(e), i.milestones.vantages.includes(e) || i.milestones.vantages.push(e);
		} else if (r.kind === "end") return r.value === "destiny" && (i.destinyDone = !0), Qa(i, i.missionDone && i.destinyDone ? "epic" : i.destinyDone ? "destiny" : i.missionDone ? "mission" : "retired"), { state: i };
		else if (r.kind === "card") {
			let e = Number(r.value), t = !qi(a).some((t) => t.card === e);
			X(i, e), E[e]?.group === "item" && /^(?:CRAFT|BREW)\b/.test(D[i.challenge?.id ?? ""]?.label ?? "") && fr(i, a, 1618), t && E[e]?.group === "item" && (E[e].value ?? 0) >= 6 && /^CRAFT\b/.test(D[i.challenge?.id ?? ""]?.label ?? "") && br(a, 1644) && fr(i, a, 1644), i.challenge?.source === 1273 && (i.pendingCards.includes(e) || i.cardClaims.some((t) => t.card === e && t.requester === n)) && (i.pendingInstances[e] = {
				...V(e),
				craftedAt: 1273,
				craftedBy: n
			}), e === 1033 && i.passage.node.builtShip && i.milestones.quests.includes(1695) && (i.pendingCards.includes(e) || i.cardClaims.some((t) => t.card === e && t.requester === n)) && (i.pendingInstances[e] = {
				...V(e),
				builtShip: !0
			}), e === 1434 && i.passage.node.rescueShip && (i.pendingCards.includes(e) || i.cardClaims.some((t) => t.card === e && t.requester === n)) && (i.pendingInstances[e] = {
				...V(e),
				rescueShip: !0
			});
		} else if (r.kind === "replaceCard" || r.kind === "upgradeVehicle") {
			let e = i.challenge?.source, t = a.grid.find((t) => t?.card === e);
			if (!t || !e) return Z();
			let n = Number(r.value), o = r.kind === "upgradeVehicle";
			(o || /^(?:CRAFT|BREW|UPGRADE|REFINE)\b/.test(D[i.challenge?.id ?? ""]?.label ?? "")) && fr(i, a, 1618), i.copied?.retainFlora && i.copied.source === e && E[e].group === "flora" ? X(i, n, a) : go(i, a, e, n, {
				...V(n),
				...o && t.rescueShip ? { rescueShip: !0 } : {},
				...o && n === 1033 ? { upgradedShip: !0 } : {}
			}, i.passage.node.upgradeBonus);
		} else if (r.kind === "completeCard") {
			let e = r.value === "self" ? Number(i.passage.entry.match(/^[a-z](\d+):/)?.[1]) : Number(r.value), t = a.supply.find((t) => t.card === e);
			if (!t || e < 1611 || e > 1704 || E[e].portrait) return Z();
			let n = r.amount ? a.grid.findIndex((e) => e?.card === r.amount) : -1;
			if (n === 4) return Z();
			r.amount && Y(i, a, r.amount), a.supply = a.supply.filter((e) => e !== t), i.pendingCards.push(e), i.pendingInstances[e] = {
				...t,
				rotated: !0
			}, n >= 0 && (i.replacementCells[e] = n);
		} else if (r.kind === "loseCard") {
			if (Number(r.value) === a.character) return Z();
			let e = Number(r.value), t = i.copied;
			!(t?.retainFlora && e === t.source && a.grid.some((t) => t?.card === e) && E[e].group === "flora") && !(t?.retainBlueprint && P(e, "blueprint")) && Y(i, a, e);
		} else if (r.kind === "returnDungeon") {
			if (o.dungeonOrigin === null) return Z();
			la(i, a, o.dungeonOrigin, "leaveDungeon");
		} else if (r.kind === "location" || r.kind === "dungeon") {
			let e = Number(r.value);
			if (E[e]?.group !== "location") return Z();
			la(i, a, e, r.kind === "dungeon" ? "enterDungeon" : void 0), i.passage.node.ignoreArrivalHealth && sa(i, a, (e) => ["stat", "payment"].includes(e.instruction.kind) && e.instruction.value === "health");
		} else if (r.kind === "refresh") ca(i);
		else if (r.kind === "skirm") {
			let e = i.players[(i.turn + 1) % i.players.length];
			return i.lastSkirmWon = null, i.skirm = qn(n, i.players.length > 1 ? e.rid : void 0, a.skirm, (e) => B(i, e), r.value ? Number(r.value) : void 0), ta(i), i.center.some((e) => e.card === 1603) || i.center.push(V(1603)), i.passage.applied.push(t.index), i.phase = "skirm", H(i, "roll"), { state: i };
		} else if (r.kind === "secret") {
			let e = D["s" + Number(r.value) + ":0"];
			if (!e) return Z();
			let n = i.passage, a = {
				node: {
					...n.node,
					after: void 0
				},
				entry: n.entry,
				applied: [...n.applied, t.index],
				skillResult: i.skillResult,
				skirmWon: i.lastSkirmWon
			};
			return Oa(i, e.node, e.id, [a, ...n.following]), { state: i };
		}
		return i.passage.applied.push(t.index), H(i, "gain"), i.arrivals.length && (i.arrivalResume = "story"), !Xa(i) && i.arrivals.length && fa(i, "story"), { state: i };
	}
	if (t.type === "chooseBranch") {
		if (i.phase !== "story" || !i.passage || i.pendingCards.length || ma(i)) return Z();
		let e = k(i.passage.node, le(i.storyTest)), r = i.passage.node.choices[t.index];
		if (!lo(i, t.index) || !r || e.blocked || i.passage.node.skillTest && !i.storyTest?.done || e.effects.some((e, t) => !i.passage.applied.includes(t)) || r.onceKey && o.chosenBranches?.includes(r.onceKey) || r.occupied !== void 0 && (i.houseOccupancy?.[i.passage.node.house ?? 0] === void 0 || i.houseOccupancy[i.passage.node.house ?? 0] !== "blank" !== r.occupied) || r.miniSuccess !== void 0 && (!i.miniGame?.done || i.miniGame.success !== r.miniSuccess) || r.miniWins !== void 0 && (!i.miniGame?.done || i.miniGame.wins !== r.miniWins) || !Fa(a, i.challenge?.coinsPaid ?? 0, r, !!i.challenge?.waiveCoins, i.coinPowers?.[a.rid]?.pay ?? 0) || !hr(i, a, r.completedAction) || r.mission !== void 0 && r.mission !== i.mission || r.exceptMission === i.mission || r.locations && !r.locations.includes(o.location) || r.exceptLocations?.includes(o.location) || r.requiresSkyOrigin && (!Dn(o.location) || o.skyOrigin == null) || r.dragonReady !== void 0 && r.dragonReady !== Bn(i, n) || r.exceptCharacterRole === M(a) || r.roll && r.roll !== i.skillResult || !Ia(i, r.test) || r.minX !== void 0 && (i.challenge?.chosenX ?? 0) < r.minX || r.maxX !== void 0 && (i.challenge?.chosenX ?? 0) > r.maxX || r.requiresNext && !Wa(i, a, r.node) || !Te(a, r.inventory) || r.coldArrival !== void 0 && Nr(o.location, !0).some((e) => e.kind === "damage" && e.value === "cold") !== r.coldArrival || r.forbiddenAction && o.usedActions.includes(r.forbiddenAction) || r.requiredRole !== void 0 && M(a) !== r.requiredRole || r.absentCard && G(a).some((e) => e.card === r.absentCard) || r.requiredCard && !G(a).some((e) => e.card === r.requiredCard) || r.availableCard && Ji(i, r.availableCard) || r.sourceBoostMin !== void 0 && (Ji(i, ja(i))?.boost ?? 0) < r.sourceBoostMin || r.trapMatch !== void 0 && (!i.trapTest || i.trapTest.faces.includes(i.trapTest.target) !== r.trapMatch) || r.tradeAvailable && !Pn(a, r.tradeAvailable.kind, r.tradeAvailable.trait, ja(i)).length || r.sourceBoost !== void 0 && Ji(i, ja(i))?.boost !== r.sourceBoost || r.requiredBoost !== void 0 && !a.grid.some((e) => e?.card === ja(i) && e.boost === r.requiredBoost) || /\b(if|unless)\b/i.test(r.label) && !t.condition || /\bif you (?:win|won)\b/i.test(r.label) && i.lastSkirmWon !== !0 || /\bif you (?:lose|lost)\b/i.test(r.label) && i.lastSkirmWon !== !1) return Z();
		let s = r.label.match(/\bif you (have|do not have|don't have) (?:the |an? )?(?:item|card|animal|flora|sentient|spell|curse|ability) (\d+)\b/i);
		if (s && G(a).some((e) => e.card === Number(s[2])) !== (s[1].toLowerCase() === "have")) return Z();
		let c = oe(r);
		if (c === "unsupported") return { code: "games.vantage.errUnadapted" };
		let l = i.passage.payment?.index === t.index ? i.passage.payment.pledges : {}, u = Na(i, l);
		if (!ce(a, r, !!i.challenge?.waiveCoins, i.coinPowers?.[a.rid]?.pay ?? 0, u)) return Z();
		let d = /* @__PURE__ */ new Set();
		for (let e of c) if (e.kind === "coin") ze(i, a, i.challenge?.waiveCoins ? 0 : e.amount);
		else if (e.kind === "boost") J(i, W(a), e.amount);
		else if (w.includes(e.kind)) a.stats[e.kind] -= e.amount, e.kind === "health" && (o.healthLostThisTurn = !0);
		else {
			let t = e.kind, n = e.amount;
			for (let e of i.players) {
				if (e.rid === a.rid) continue;
				let r = Math.min(n, l[e.rid]?.[t] ?? 0, e.skills[t]);
				e.skills[t] -= r, n -= r, r && d.add(e.rid);
			}
			a.skills[t] -= n, n && d.add(a.rid);
		}
		return i.paymentContributors = [...d], r.onceKey && (o.chosenBranches ??= []).push(r.onceKey), Oa(i, r.node, i.passage.entry, i.passage.following), c.some((e) => w.includes(e.kind)) && Xa(i), { state: i };
	}
	if (t.type === "placeCard") {
		if (!i.pendingCards.includes(t.card) || i.pendingInstances[t.card]?.asylumAt !== void 0 && t.zone !== "supply" || i.requiredGrid?.includes(t.card) && t.zone !== "grid") return Z();
		let e = i.replacementCells[t.card];
		if (e !== void 0 && (e < 0 ? t.zone !== "reserve" : t.zone !== "grid" || t.cell !== e)) return Z();
		let n = i.pendingInstances[t.card] ?? V(t.card), r = i.pendingTucks?.[t.card];
		if (r !== void 0) {
			let e = Ji(i, r);
			if (t.zone !== "tuck" || !e) return Z();
			(e.tucked ??= []).push(n);
		} else if (t.zone === "tuck" || !Da(i, a, n, t.zone, t.cell)) return Z();
		return n.rotated && t.card >= 1627 && t.card <= 1704 && !i.milestones.quests.includes(t.card) && i.milestones.quests.push(t.card), i.requiredGrid = i.requiredGrid?.filter((e) => e !== t.card), i.pendingCards = i.pendingCards.filter((e) => e !== t.card), delete i.pendingInstances[t.card], delete i.replacementCells[t.card], delete i.pendingTucks?.[t.card], i.phase === "arrival" && pa(i), H(i, "gain"), { state: i };
	}
	if (t.type === "discard") return !(s && i.pendingCards.length) && !i.deliveries[n]?.length && !_a(a) || !a.reserve.some((e) => e.card === t.card) || !Y(i, a, t.card) ? Z() : (i.phase === "arrival" && pa(i), { state: i });
	if (t.type === "finishStory") {
		if (i.challenge?.cloakContinue && (i.continuation = "must", i.locationContinuation = !0), i.puzzle && i.puzzle.stage !== "done" || i.phase !== "story" || !i.passage || i.pendingCards.length || ma(i) || i.passage.node.choices.length && !za(i, a) || i.passage.node.skillTest && !i.storyTest?.done) return Z();
		let e = k(i.passage.node, le(i.storyTest));
		if (!e.blocked && e.effects.every((e, t) => i.passage.applied.includes(t)) && i.passage.following.length) {
			let [e, ...t] = i.passage.following;
			e.skillResult !== void 0 && (i.skillResult = e.skillResult), e.skirmWon !== void 0 && (i.lastSkirmWon = e.skirmWon);
			let n = e.inheritContinuation ? {
				...e.node,
				continuation: i.continuation
			} : e.node;
			return e.restoreSource && i.challenge && Object.assign(i.challenge, e.restoreSource), Oa(i, n, e.entry, t, e.applied), { state: i };
		}
		if (e.blocked || e.effects.some((e, t) => !i.passage.applied.includes(t)) || t.continue && i.continuation === "no" || !t.continue && i.continuation === "must" && !i.stopForced.includes(n)) return Z();
		if (i.arrivalSecret) {
			i.passage.node.endTurn && n === i.players[i.turn].rid && (i.arrivalEndsTurn = !0);
			let e = i.arrivalStack.pop();
			return i.arrivalReader = e.reader, i.arrivalSecret = i.arrivalStack.length > 0, i.passage = e.passage, i.skillResult = e.skillResult, i.lastSkirmWon = e.skirmWon, i.locationContinuation = e.locationContinuation, i.arrivalResume = e.resume, pa(i), { state: i };
		}
		let r = i.challenge?.interaction;
		if (r) {
			if (!r.curse) for (let e of r.sentients) i.milestones.sentients.includes(e) || i.milestones.sentients.push(e);
			i.mission === 1596 && i.missionPivot && r.traveler && !i.milestones.travelerLocations.includes(r.location) && i.milestones.travelerLocations.push(r.location);
		}
		if (i.missionPivot && (i.mission === 1593 || i.mission === 1596) && (i.center.find((e) => e.card === i.mission).tokens = Math.min(2, i.mission === 1593 ? zn(i) : i.milestones.travelerLocations.length)), i.challenge && /^(?:HACK|CLEAVE).*\btower/i.test(D[i.challenge.id]?.label ?? "") && !i.milestones.hackedTowers.includes(i.challenge.source) && i.milestones.hackedTowers.push(i.challenge.source), i.passage.node.towerTop && (o.towerTop = !0), (i.passage.node.towerTop || /^UPGRADE\b/.test(D[i.challenge?.id ?? ""]?.label ?? "")) && fr(i, a, i.passage.node.towerTop ? 1615 : 1618), br(a, 1636) && !o.personalFacts?.includes(1636) && i.challenge?.interaction?.location === 677 && E[i.challenge.source]?.group !== "location") return fr(i, a, 1636), Oa(i, {
			text: "The Gatherer returns with the harvest. Gain item 1224 and go to city 519.",
			zh: "森林采集者带着收获归来。获得物品1224，然后前往城市519。",
			instructions: "Gain item 1224. Go to 519.",
			choices: []
		}, "q1636:delivery"), { state: i };
		let s = i.continuation === "must" && (i.passage.node.followActions?.length || i.passage.node.followBooks?.length || i.passage.node.followDirections?.length || i.passage.node.followVerbs?.length || i.passage.node.continueSkill || i.passage.node.followWater || i.passage.node.followDifferent);
		return i.pearlDefense?.active && !s ? (Sa(i, !0), ka(i), { state: i }) : i.powerTravel?.length && !s && yo(i) ? { state: i } : i.powerTravel?.length && !s ? (Sa(i, !0), ai(i), H(i, "story"), { state: i }) : i.launch && i.launch.stage !== "landing" ? (Sa(i, !0), i.passage = null, i.challenge = null, i.phase = "launch", i.turn = 0, i.continuation = "no", i.locationContinuation = !1, bn(i), { state: i }) : i.passage.node.endTurn ? (Ya(i), { state: i }) : (t.continue || i.freeReading ? (i.storyTest = null, Sa(i, !0), i.restrictedBooks = i.passage.node.followBooks ?? [], i.restrictedDirections = i.passage.node.followDirections ?? [], i.nextActionMaxCost = i.passage.node.followMaxCost, i.nextActionDiscount = i.passage.node.followDiscount ?? i.copied?.discount ?? i.nextActionDiscount, i.restrictedActions = i.passage.node.followActions ?? [], i.restrictedVerbs = i.passage.node.followVerbs ?? [], i.restrictedSkill = i.passage.node.continueSkill ?? null, i.restrictedExclude = i.passage.node.followDifferent ? i.challenge?.id : void 0, i.restrictedExcludes = i.passage.node.followExclude ?? [], i.restrictedWater = i.passage.node.followWater ?? !1, i.passage = null, i.challenge = null, i.phase = "action", i.freeReading = !1) : Ya(i), { state: i });
	}
	if (t.type === "lastChance") {
		if (i.phase !== "crisis" || i.lastChanceUsed) return Z();
		i.lastChanceUsed = !0, ca(i);
		let e = {
			time: 0,
			morale: 0,
			health: 0
		};
		for (let t = 0; t < i.pool; t++) {
			let t = T[B(i, 6)];
			t !== "blank" && t !== "setback" && e[t]++;
		}
		return i.rescue = e, w.every((t) => e[t] === 0) && Qa(i, "failure"), { state: i };
	}
	if (t.type === "assignRescue") {
		let e = i.players.find((e) => e.rid === t.target);
		return i.phase !== "crisis" || !i.rescue || i.rescue[t.stat] < 1 || !e ? Z() : (i.rescue[t.stat]--, K(i, e, t.stat, 1), w.every((e) => i.rescue[e] === 0) && (i.rescue = null, i.players.some((e) => w.some((t) => e.stats[t] === 0)) ? Qa(i, "failure") : Za(i)), { state: i });
	}
	return t.type === "finishSkirm" ? i.phase !== "skirm" || !i.skirm || i.skirm.stage !== "scored" || i.skirm.rewarded ? Z() : i.pack.length && !a.skirm.length && a.reserve.length >= jr(a) ? { code: "games.vantage.errReserveFull" } : (i.skirm.rewarded = !0, i.lastSkirmWon = i.skirm.winner === 0, i.challenge && D[i.challenge.id]?.repeatOnWin && !i.lastSkirmWon && (o.failedDuels ??= []).push(i.challenge.id), i.skirm.winner === 0 ? (Be(i, a, 2), i.duelsWon++, fr(i, a, 1625)) : i.skirm.solo || Be(i, i.players.find((e) => e.rid === i.skirm.controllers[1]), 1), i.pack.length && a.skirm.push(i.pack.splice(B(i, i.pack.length), 1)[0]), i.skirm = null, i.phase = "story", H(i, "gain"), { state: i }) : Z();
}
function Co(e, t, n) {
	let r = e.copied ? U(e) : null, i = r && ja(e) !== e.copied.ability ? Ga(e, r) : null, a = So(e, t, n);
	if ("code" in a) return a;
	let o = a.state;
	if ((t.type === "chooseAction" || t.type === "chooseBranch" && (wo.viewFor(e, n.by).private?.passage?.allowedChoices.length ?? 0) > 1) && e.players.find((e) => e.rid === n.by)?.grid.some((e) => e?.card === 987)) {
		let r = structuredClone({
			...e,
			hourglassUndo: void 0,
			rebornUndo: void 0
		});
		o.hourglassUndo = {
			rid: n.by,
			action: t,
			state: r
		};
	}
	for (let t of e.players) for (let n of ["pay", "gain"]) e.coinPowers?.[t.rid]?.[n] && o.coinPowers?.[t.rid] && Le(e, t, n) !== Le(o, o.players.find((e) => e.rid === t.rid), n) && delete o.coinPowers[t.rid][n];
	ho(o);
	let s = e.players.find((t) => t.rid === (e.arrivalSecret ? e.arrivalReader : e.players[e.turn].rid));
	if (s && e.phase === "dice" && e.challenge) {
		let n = e.challenge, r = o.players.find((e) => e.rid === s.rid);
		t.type === "penalties" ? ia(o, r, n.dice.filter((t, i) => t === "health" && (n.ignoreHealth || rn(n.bonus, t, i, n.initialTime ?? []) || e.personal[r.rid].animalProtection?.includes("health"))).length) : o.challenge?.id === n.id && ia(o, r, Math.max(0, n.dice.filter((e) => e === "health").length - o.challenge.dice.filter((e) => e === "health").length));
	}
	if (t.type === "reserveCard") for (let e of o.transportDeliveries ?? []) e.to === n.by && (e.reservedAnother = !0);
	for (let t of o.transportDeliveries ?? []) {
		let n = e.players.find((e) => e.rid === t.to), r = o.players.find((e) => e.rid === t.to);
		qi(n).some((e) => e.card !== t.card && !qi(r).some((t) => t.card === e.card)) && (t.lostAnother = !0);
	}
	if (t.type === "placeCard") {
		let e = o.transportDeliveries?.find((e) => e.card === t.card && e.to === n.by);
		e && (t.zone === "grid" && !(e.source === 1083 ? e.lostAnother : e.reservedAnother) && K(o, o.players.find((t) => t.rid === e.from), "morale", 1), o.transportDeliveries = o.transportDeliveries.filter((t) => t !== e));
	}
	if (o.recentHealthLoss && o.recentHealthLoss.serial !== e.recentHealthLoss?.serial && (o.recentHealthLoss.serial = o.eventSeq), i && r && o.copied && o.copied.ability === e.copied?.ability && Ka(o, o.players.find((e) => e.rid === r.rid), i), va(o), !o.replenishments.length && o.replenishResume) {
		let e = o.replenishResume;
		o.replenishResume = null, e === "nextTurn" ? Ya(o) : Sa(o, !0);
	}
	return t.type === "replenish" && !o.replenishments.length && o.phase === "arrival" && pa(o), Sa(a.state), ["placeCard", "placementBoost"].includes(t.type) && !a.state.placementChoices.length && ["story", "arrival"].includes(a.state.phase) && (a.state.phase !== "arrival" || a.state.arrivalResume !== "result") && Xa(a.state), wa(a.state), Ca(a.state), o.phase === "crisis" && !o.rescue && !o.pendingCards.length && !o.skillRolls.length && !ma(o) && o.players.every((e) => w.every((t) => e.stats[t] > 0)) && Za(o), o.pearlDefense?.awaitingArrival && o.phase === "action" && !o.arrivals.length && !o.pendingCards.length && !ma(o) && ka(o), a;
}
var wo = {
	meta: Nn,
	saveCompatibility: { version: "dev-1" },
	schemas: {
		action: zi,
		publicView: Vi,
		privateView: Ui,
		config: Li
	},
	setup: ro,
	reduce: Co,
	viewFor(e, t) {
		let n = e.players.find((e) => e.rid === t), r = {
			storyPayment: e.phase === "story" && e.passage?.payment ? {
				costs: Pa(e),
				pledges: e.passage.payment.pledges
			} : null,
			powerTransfer: e.powerTransfer ?? null,
			runeSurvey: e.runeSurvey ?? null,
			runeQuest: e.runeQuest ? { cells: cn(e) } : null,
			crewSharing: e.crewSharing ? { waiting: e.players.filter((t) => !Object.hasOwn(e.crewSharing.decisions, t.rid)).map((e) => e.rid) } : null,
			players: structuredClone(e.players),
			active: U(e).rid,
			round: e.round,
			phase: e.phase,
			launch: e.launch ?? null,
			pool: e.pool,
			penaltyDice: e.penaltyDice,
			penaltyFaces: $r(e),
			center: e.center,
			mission: e.mission,
			missionDone: e.missionDone,
			missionPivot: e.missionPivot,
			destinyDone: e.destinyDone,
			missionReady: !e.missionDone && Vn(e, e.mission),
			readyDestinies: e.center.filter((t) => t.card >= 1598 && t.card <= 1608 && Vn(e, t.card)).map((e) => e.card),
			challenge: e.challenge ? {
				skill: e.challenge.skill,
				untyped: e.challenge.untyped,
				cost: Math.max(0, e.challenge.cost),
				rollCount: Math.max(0, e.challenge.cost) + (e.challenge.extraChallengeDice ?? 0) + (e.challenge.extraChoice ? 2 : 0),
				dice: e.challenge.dice
			} : null,
			ending: e.ending,
			endingRequestedBy: e.endingRequestedBy,
			event: e.event,
			eventSeq: e.eventSeq,
			rescue: e.rescue,
			arrivalPlayer: e.phase === "arrival" ? e.arrivals[0]?.rid ?? e.cardClaims[0]?.owner ?? Object.keys(e.deliveries).find((t) => e.deliveries[t].length > 0) ?? U(e).rid : null,
			arrivalSkills: e.phase === "arrival" && !e.arrivals[0]?.paid ? e.arrivals[0]?.instruction.skills ?? [] : [],
			cardClaims: e.cardClaims,
			placementPlayer: e.placementChoices[0]?.rid ?? null,
			replenishment: e.replenishments[0] ?? null,
			summoning: e.summoning ? {
				caller: e.summoning.caller,
				waiting: e.summoning.waiting,
				summoned: e.summoning.summoned,
				solo: e.summoning.solo
			} : null,
			temporaryImpact: e.temporaryImpact,
			gamblePlayer: e.gamblePlayer,
			skillRollPlayer: e.skillRolls[0]?.rid ?? null,
			cardsPending: !!e.portalReturnDecision || !!e.hourglassTurnEnd || !!e.pendingCards.length || ma(e) || !!e.powerConversion || !!e.printedRoll || !!e.powerMove || !!e.powerReward || !!e.powerDiceChoice || !!e.powerDiscardDice || !!e.powerSwitch || !!e.powerReplacement || !!e.powerTransfer,
			presetFaces: e.setFaces,
			slotPermission: e.slotPermission,
			impactPermission: e.impactPermission,
			followConsent: e.followConsent,
			deliveryRecipients: Object.keys(e.deliveries).filter((t) => e.deliveries[t].length > 0),
			skirm: e.skirm ? {
				controllers: e.skirm.controllers,
				cards: e.skirm.stage === "choose" ? [null, null] : e.skirm.cards,
				dice: e.skirm.dice.map((t, n) => t.map((t, r) => e.skirm.hidden[n].includes(r) ? null : t)),
				stage: e.skirm.stage,
				turn: e.skirm.turn,
				first: e.skirm.first,
				scores: e.skirm.scores,
				winner: e.skirm.winner,
				processed: e.skirm.processed,
				counts: [$a(e.skirm, 0), $a(e.skirm, 1)],
				extras: e.skirm.extras,
				removedPrinted: e.skirm.removedPrinted,
				bonus: e.skirm.bonus,
				groups: e.skirm.stage === "blade" ? e.skirm.pending?.group ?? [] : []
			} : null
		};
		if (!n) return { public: r };
		let i = e.personal[t], a = U(e).rid === t, o = a && e.challenge ? D[e.challenge.id] : null, s = e.passage ? k(e.passage.node, le(e.storyTest)) : null, c = e.skirm?.controllers[0] === t ? 0 : e.skirm?.controllers[1] === t ? 1 : null, l = e.phase === "arrival" && e.arrivals[0]?.rid === t ? e.arrivals[0] : null, u = e.placementChoices[0];
		return {
			public: r,
			private: {
				printedPowerOptions: Ai(e, n),
				sharedLocations: Object.entries(e.sharedLocations ?? {}).map(([e, t]) => ({
					rid: e,
					location: t
				})),
				revealedCard: i.revealedCard ?? null,
				actionEngage: a ? e.challenge?.temporaryEngage ?? 0 : 0,
				powerTravel: !!e.powerTravel?.length,
				puzzle: a && e.phase === "story" ? e.puzzle ?? null : null,
				canUndoAction: a && n.character === 1453 && e.phase === "dice" && !!e.rebornUndo && (e.rebornUndo.players.find((e) => e.rid === t)?.grid[4]?.boost ?? 0) >= 3 && !ma(e),
				foresightSources: qa(e),
				knownHouseFace: e.passage?.node.house === void 0 ? null : e.houseOccupancy?.[e.passage.node.house] ?? null,
				investmentReturn: e.storyInvestmentReturn ?? null,
				storedBelongings: (i.storedBelongings ?? []).map((e) => ({
					location: e.location,
					returnOnLeave: e.returnOnLeave,
					cards: e.cards.map(({ held: e }) => e.card)
				})),
				asylumPending: e.pendingCards.filter((t) => e.pendingInstances[t]?.asylumAt !== void 0),
				actionBonus: a ? e.challenge?.bonus ?? e.nextBonus ?? null : null,
				bonusDice: a ? e.challenge?.foresight?.length ? e.challenge.foresight : e.foresight ?? [] : [],
				bonusSelection: a ? e.challenge?.foresightSelection ?? null : null,
				bonusChoiceNeeded: a && e.phase === "cost" && !!e.challenge && e.challenge.cost >= 0 && e.challenge.cost + (e.challenge.extraChallengeDice ?? 0) + (e.challenge.extraChoice ? 2 : 0) < (e.challenge.foresight?.length ?? 0) && e.challenge.foresightSelection?.length !== e.challenge.cost + (e.challenge.extraChallengeDice ?? 0) + (e.challenge.extraChoice ? 2 : 0),
				miniGame: a && e.phase === "story" ? e.miniGame ?? null : null,
				abilityChoices: a && e.phase === "story" ? Ua(e, n) : [],
				copiedBenefits: a ? e.copied?.benefits ?? [] : [],
				previewedOutcome: a ? e.previewedOutcome ?? null : null,
				abilityDice: a ? e.abilityDice ?? [] : [],
				runeFaces: a && e.phase === "story" && e.passage?.node.runeFocus ? e.runeFaces ?? [] : [],
				runeRecordable: !!sn(e) && !!e.runeQuest && i.location > 1 && !e.runeQuest.entries.some((e) => e.location === i.location) && e.runeQuest.entries.length < 18,
				slotPartners: e.players.filter((n) => n.rid !== t && ga(e, n.rid, t)).map((e) => e.rid),
				summonCharacters: e.players.length === 1 && e.summoning?.waiting.includes(t) ? Array.from({ length: 6 }, (e, t) => 1435 + t).filter((t) => !e.players.some((e) => M(e) === fe(t))) : [],
				restDice: a ? Ra(e, n) : [],
				gridDice: a ? La(n) : [],
				storyTest: a && e.phase === "story" && e.storyTest && e.challenge ? {
					paySkills: e.storyTest.spec.paySkills ?? [],
					repeatSkill: e.storyTest.spec.repeatSkill ?? null,
					count: e.storyTest.count,
					rounds: e.storyTest.rounds,
					maxRolls: e.storyTest.spec.rolls,
					faces: le(e.storyTest),
					remaining: e.storyTest.remaining,
					done: e.storyTest.done,
					bait: !!e.storyTest.spec.bait,
					sourceBoost: !!e.storyTest.spec.sourceBoost,
					baitUsed: e.storyTest.baitUsed,
					source: e.challenge.source,
					partialRounds: Math.max(0, (e.storyTest.spec.partialRounds ?? 0) - (e.storyTest.partialRounds ?? 0)),
					rerollable: e.storyTest.done ? [] : on(e.storyTest.spec, e.storyTest.faces, e.storyTest.rerolled)
				} : null,
				elemental: e.elemental?.rid === t ? e.elemental : null,
				elementalReroll: a && e.phase === "dice" && !!e.challenge?.rerollAll && !e.challenge.placed,
				scouted: i.scouted,
				revealedCosts: i.revealedCosts.map((e) => ({
					id: e,
					label: D[e].label,
					labelZh: D[e].labelZh || D[e].printedZh,
					cost: D[e].cost
				})),
				gamble: e.gamblePlayer === t,
				skillRoll: !e.skillDiceChoice && e.skillRolls[0]?.rid === t ? e.skillRolls[0] : null,
				sentientTrial: e.sentientTrial?.rid === t ? e.sentientTrial : null,
				protection: e.protection.filter((e) => e.rid === t).map(({ kind: e, amount: t }) => ({
					kind: e,
					amount: t
				})),
				animalProtection: i.animalProtection ?? [],
				placement: u?.rid === t ? {
					source: u.source,
					kind: u.kind,
					remaining: u.remaining,
					options: ya(e, u).map((e) => e.card)
				} : null,
				arrival: l ? {
					curse: l.curse ?? null,
					kind: l.instruction.kind,
					value: l.instruction.value,
					skills: l.instruction.skills ?? [],
					destinations: l.instruction.destinations ?? [],
					paid: l.paid,
					ignored: l.instruction.kind === "damage" ? kr(n, l.instruction.value, !l.curse) || i.animalProtection?.includes(l.instruction.value) === !0 || aa(e, n, l.instruction.value) > 0 : !l.curse && l.instruction.value === "health" && Ar(n)
				} : null,
				pearlDefense: e.pearlDefense?.rid === t ? {
					remaining: e.pearlDefense.remaining,
					active: !!e.pearlDefense.active
				} : null,
				canStartPearlDefense: a && e.phase === "action" && !e.pearlDefense && br(n, 1681) && i.location === 733 && !i.forbiddenLocations.includes(733) && !e.restrictedActions.length && !e.restrictedBooks?.length && !e.restrictedSkill,
				pathStations: i.pathStations ?? [],
				pathQuest: br(n, 1673),
				personalGoals: n.supply.filter((t) => ar(t.card) && Cr(e, n, t.card)).map((e) => e.card),
				questProgress: wr(e, n),
				expiredQuests: i.expiredQuests,
				abandonableQuests: br(n, 1685) && Cr(e, n, 1685) ? [1685] : [],
				requiredGrid: a ? e.requiredGrid ?? [] : [],
				tuckTargets: a ? e.pendingTucks ?? {} : {},
				tuckedPlants: a ? Ji(e, ja(e))?.tucked?.map((e) => e.card) ?? [] : [],
				rotatedPending: [...a ? Object.values(e.pendingInstances) : [], ...e.deliveries[t] ?? []].filter((e) => e.rotated).map((e) => e.card),
				replacementCells: Object.fromEntries(Object.entries(e.replacementCells).filter(([n]) => a || (e.deliveries[t] ?? []).some((e) => e.card === Number(n)))),
				coLocated: e.players.filter((n) => n.rid !== t && e.personal[n.rid].location === i.location).map((e) => e.rid),
				experience: a && e.phase === "experience" ? Ki(n).map((e) => e.card) : [],
				powerOptions: a && e.phase === "cost" && M(n) === 2 && me(n.character) !== "starting" ? no(e, t, !0).filter((t) => t.id !== e.challenge?.id) : [],
				location: i.location,
				capsules: e.launch?.selected.includes(t) ? [] : vn(e),
				landingDice: e.phase === "landing" ? i.landing.map((e) => C[e]) : null,
				landingRerollAllowed: e.phase === "landing" && Sn(e, t),
				...(e.phase === "landing" && !e.launch || e.phase === "launch" && e.launch?.stage === "000") && e.players[0].rid === t ? { missionDice: e.missionDice.map((e) => C[e]) } : {},
				options: no(e, t),
				current: a && e.challenge ? {
					id: e.challenge.id,
					label: o?.label ?? "",
					labelZh: o?.labelZh ?? "",
					cost: e.challenge.cost,
					source: e.challenge.source,
					canPayCoin: !!ie(o, e.challenge.cost, e.challenge.coinsPaid ?? 0, e.challenge.coinOfferUsed),
					coinPrice: Re(e, n, ie(o, e.challenge.cost, e.challenge.coinsPaid ?? 0, e.challenge.coinOfferUsed)?.cost ?? 1),
					coinDiscount: ie(o, e.challenge.cost, e.challenge.coinsPaid ?? 0, e.challenge.coinOfferUsed)?.discount ?? "one",
					canClearObstacle: !e.challenge.obstacleCleared && /reduce this cost to 1/i.test(o?.label ?? "")
				} : null,
				challengeRewardFace: a && e.phase === "story" ? e.challengeRewardFace ?? null : null,
				trapTest: a && e.phase === "story" ? e.trapTest ?? null : null,
				nextActionDiscount: a ? e.nextActionDiscount ?? 0 : 0,
				passage: a && e.passage && s ? {
					text: e.passage.node.text,
					zh: e.passage.node.zh,
					choices: za(e, n) ? [] : e.passage.node.choices.map((e) => e.label),
					choicesZh: za(e, n) ? [] : e.passage.node.choices.map((e) => e.labelZh ?? e.label),
					effects: s.effects.map((t, r) => ({
						...t,
						value: t.kind === "barter" ? JSON.stringify({
							...JSON.parse(t.value),
							bonus: e.passage.node.barter?.bonus === "X" ? e.challenge?.chosenX ?? 0 : e.passage.node.barter?.bonus ?? 0
						}) : t.value,
						amount: t.kind === "structureTrade" && t.amount < 0 ? t.amount === -1 ? e.challenge?.chosenX ?? 0 : (Ji(e, e.challenge?.source ?? 0)?.boost ?? 0) + (t.amount === -3 ? G(n).filter((e) => P(e.card, "ability")).length : 0) : t.kind === "runeQuest" ? +!Ji(e, 1706) : t.kind === "runeRoll" ? t.amount > 0 ? t.amount : e.challenge?.chosenX ?? 0 : t.kind === "nextActionDiscount" || t.kind === "coinX" || t.kind === "boostX" || t.kind === "rest" ? e.challenge?.chosenX ?? 0 : t.kind === "sourceCoin" ? Ji(e, e.challenge?.source ?? 0)?.boost ?? 0 : t.amount,
						applied: e.passage.applied.includes(r)
					})),
					blocked: s.blocked,
					hasFollowing: e.passage.following.length > 0,
					returnsToAction: e.freeReading || !!e.powerTravel?.length,
					payableChoices: e.passage.node.choices.flatMap((t, r) => ce(n, t, !!e.challenge?.waiveCoins, e.coinPowers?.[n.rid]?.pay ?? 0, e.passage?.payment?.index === r ? Na(e, e.passage.payment.pledges) : {}) ? [r] : []),
					skillPaymentChoices: e.passage.node.choices.flatMap((e, t) => {
						let n = oe(e);
						return n !== "unsupported" && n.some((e) => C.includes(e.kind)) ? [t] : [];
					}),
					allowedChoices: e.passage.node.choices.flatMap((t, r) => lo(e, r) && (!t.onceKey || !i.chosenBranches?.includes(t.onceKey)) && (t.occupied === void 0 || e.houseOccupancy?.[e.passage.node.house ?? 0] !== void 0 && e.houseOccupancy[e.passage.node.house ?? 0] !== "blank" === t.occupied) && (t.miniWins === void 0 || e.miniGame?.done && e.miniGame.wins === t.miniWins) && (t.miniSuccess === void 0 || e.miniGame?.done && e.miniGame.success === t.miniSuccess) && Fa(n, e.challenge?.coinsPaid ?? 0, t, !!e.challenge?.waiveCoins, e.coinPowers?.[n.rid]?.pay ?? 0) && hr(e, n, t.completedAction) && ce(n, t, !!e.challenge?.waiveCoins, e.coinPowers?.[n.rid]?.pay ?? 0, Ma(e, n)) && (!t.requiresSkyOrigin || Dn(i.location) && i.skyOrigin != null) && (t.dragonReady === void 0 || t.dragonReady === Bn(e, n.rid)) && (t.mission === void 0 || t.mission === e.mission) && t.exceptMission !== e.mission && (!t.locations || t.locations.includes(i.location)) && !t.exceptLocations?.includes(i.location) && t.exceptCharacterRole !== M(n) && (t.trapMatch === void 0 || e.trapTest && e.trapTest.faces.includes(e.trapTest.target) === t.trapMatch) && (!t.roll || t.roll === e.skillResult) && (t.minX === void 0 || (e.challenge?.chosenX ?? 0) >= t.minX) && (t.maxX === void 0 || (e.challenge?.chosenX ?? 0) <= t.maxX) && (!t.requiresNext || Wa(e, n, t.node)) && (t.coldArrival === void 0 || Nr(i.location, !0).some((e) => e.kind === "damage" && e.value === "cold") === t.coldArrival) && Te(n, t.inventory) && (!t.forbiddenAction || !i.usedActions.includes(t.forbiddenAction)) && (t.requiredRole === void 0 || M(n) === t.requiredRole) && (!t.absentCard || !G(n).some((e) => e.card === t.absentCard)) && Ia(e, t.test) && (!t.requiredCard || G(n).some((e) => e.card === t.requiredCard)) && (!t.availableCard || !Ji(e, t.availableCard)) && (t.requiredBoost === void 0 || n.grid.some((n) => n?.card === ja(e) && n.boost === t.requiredBoost)) && (t.sourceBoost === void 0 || Ji(e, ja(e))?.boost === t.sourceBoost) && (t.sourceBoostMin === void 0 || (Ji(e, ja(e))?.boost ?? 0) >= t.sourceBoostMin) && (!t.tradeAvailable || Pn(n, t.tradeAvailable.kind, t.tradeAvailable.trait, ja(e)).length > 0) ? [r] : [])
				} : null,
				pendingCards: [...a ? e.pendingCards : [], ...(e.deliveries[t] ?? []).map((e) => e.card)],
				notes: i.notes,
				visitedCount: i.visited.length,
				canContinue: a ? e.continuation === "must" && e.stopForced.includes(t) ? "may" : e.continuation : "no",
				lastChanceUsed: e.lastChanceUsed,
				skirmOptions: a && e.skirm?.stage === "choose" ? e.skirm.options : [],
				skirmDice: c !== null && e.skirm ? e.skirm.dice[c] : [],
				skirmSide: c,
				bookPages: i.bookPages,
				skillResult: a ? e.skillResult : null,
				needsReserveRoom: eo(e, n) || _a(n),
				crisisText: e.phase === "crisis" && a ? D["t" + e.mission + ":0"]?.label ?? "" : "",
				missionConclusion: a && Vn(e, e.mission) && !Rn.includes(e.mission) ? D["s" + e.mission + ":0"]?.node.text ?? "" : "",
				missionConclusionZh: a && Vn(e, e.mission) && !Rn.includes(e.mission) ? D["s" + e.mission + ":0"]?.node.zh ?? "" : "",
				skirmPrevious: e.skirm && c === e.skirm.turn ? e.skirm.pending?.old ?? null : null,
				skirmRolled: e.skirm && c === e.skirm.turn ? e.skirm.pending?.rolled ?? null : null
			}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.ending === "failure" || e.ending === "retired" ? [] : e.players.map((e) => e.rid),
			ranking: e.players.map((e) => e.rid)
		} : { phase: e.phase };
	}
}, To = /* @__PURE__ */ new Map(), Eo = /* @__PURE__ */ new Set(), Do = 0, Oo = (e) => (Eo.add(e), () => {
	Eo.delete(e);
}), ko = () => Do;
function Ao() {
	Do++;
	for (let e of Eo) e();
}
function jo(e) {
	To.has(e) || (To.set(e, {}), (async () => {
		try {
			let t = await s(e), n = new Image();
			n.src = t, await n.decode(), To.set(e, { url: t });
		} catch {
			To.set(e, { failed: !0 });
		}
		Ao();
	})());
}
function Mo(e) {
	let t = JSON.stringify(e);
	a(Oo, ko, ko), n(() => {
		for (let e of JSON.parse(t)) jo(e);
	}, [t]);
	let r = e.map((e) => To.get(e)), i = r.every((e) => !!e?.url);
	return {
		urls: i ? r.map((e) => e.url) : void 0,
		ready: i,
		failed: r.some((e) => e?.failed),
		retry: () => {
			for (let t of e) To.get(t)?.failed && To.delete(t), jo(t);
			Ao();
		}
	};
}
function No(e) {
	let t = Mo(e ? [e] : []);
	return {
		url: t.urls?.[0],
		failed: t.failed,
		retry: t.retry
	};
}
function Po({ failed: e, retry: t }) {
	let n = l();
	return /* @__PURE__ */ f("span", {
		className: "vantage-artwork-status",
		role: "status",
		children: [n(e ? "games.vantage.imageFailed" : "games.vantage.imageLoading"), e && /* @__PURE__ */ d("button", {
			type: "button",
			onClick: (e) => {
				e.stopPropagation(), t();
			},
			children: n("games.vantage.retryImage")
		})]
	});
}
function Fo({ src: e, ...t }) {
	let n = No(e), r = l();
	return n.url ? /* @__PURE__ */ d("img", {
		...t,
		src: n.url
	}) : /* @__PURE__ */ f("span", {
		className: "vantage-artwork-placeholder",
		role: "img",
		"aria-label": t.alt,
		title: n.failed ? r("games.vantage.imageFailed") : r("games.vantage.imageLoading"),
		children: [/* @__PURE__ */ d("span", {
			"aria-hidden": !0,
			children: "◇"
		}), n.failed && /* @__PURE__ */ d("span", { children: r("games.vantage.imageFailed") })]
	});
}
//#endregion
//#region src/games/vantage/labels.ts
var Q = {
	boost: "games.vantage.boost",
	coins: "games.vantage.coins",
	heat: "games.vantage.heat",
	cold: "games.vantage.cold",
	hypoxia: "games.vantage.hypoxia",
	move: "games.vantage.move",
	look: "games.vantage.look",
	engage: "games.vantage.engage",
	help: "games.vantage.help",
	take: "games.vantage.take",
	overpower: "games.vantage.overpower",
	time: "games.vantage.time",
	morale: "games.vantage.morale",
	health: "games.vantage.health",
	setback: "games.vantage.setback",
	blank: "games.vantage.blank",
	north: "games.vantage.north",
	east: "games.vantage.east",
	south: "games.vantage.south",
	west: "games.vantage.west",
	northeast: "games.vantage.northeast",
	southeast: "games.vantage.southeast",
	southwest: "games.vantage.southwest",
	northwest: "games.vantage.northwest",
	northOrNorthwest: "games.vantage.northOrNorthwest"
}, Io = {
	move: "#4497c1",
	look: "#9966ae",
	engage: "#dc923d",
	help: "#729a46",
	take: "#b49e3c",
	overpower: "#bc4f48",
	time: "#b99d64",
	morale: "#cdb45d",
	health: "#bd6461",
	setback: "#777c83",
	blank: "#828c91"
};
function $({ kind: e, size: t = 22 }) {
	return /* @__PURE__ */ f("svg", {
		className: "vantage-symbol",
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0,
		style: { color: Io[e] ?? "#7b8990" },
		children: [
			e === "move" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", { d: "m8 27 8-13 8 13M16 3v5M5 9l5 4M27 9l-5 4M9 3l3 6M23 3l-3 6" }), /* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "26",
				r: "1.5",
				fill: "currentColor"
			})] }),
			e === "look" && /* @__PURE__ */ d("path", { d: "M25 10a11 11 0 1 0 0 12H14m0-6h15" }),
			e === "engage" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "16",
				r: "12"
			}), /* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "16",
				r: "8"
			})] }),
			e === "help" && /* @__PURE__ */ d("path", { d: "M7 8c-7 10 1 23 13 18S30 5 20 4C10 3 10 17 18 18s8-9 1-9c-3 0-5 3-3 5" }),
			e === "take" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", { d: "m4 12 12 14 12-14M4 7l12 14L28 7" }), /* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "7",
				r: "2",
				fill: "currentColor"
			})] }),
			e === "overpower" && /* @__PURE__ */ d("path", { d: "M15 3v23c0 7 8 1 11-5M10 8h11M10 14h11M10 20h9" }),
			e === "time" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", { d: "M7 4h18M7 28h18M10 4v6l12 12v6M22 4v6L10 22v6" }), /* @__PURE__ */ d("path", { d: "m10 8 6 6 6-6M10 25l6-6 6 6" })] }),
			e === "morale" && /* @__PURE__ */ d("path", {
				d: "m16 3 4 9 10 1-8 7 3 10-9-6-9 6 3-10-8-7 10-1Z",
				fill: "currentColor",
				stroke: "none"
			}),
			e === "health" && /* @__PURE__ */ d("path", {
				d: "M16 28 4 16C-5 5 9-2 16 8c7-10 21-3 12 8Z",
				fill: "currentColor",
				stroke: "none"
			}),
			e === "setback" && /* @__PURE__ */ d("path", { d: "M25 25H12a7 7 0 0 1 0-14h9M17 5l7 6-7 6" }),
			e === "blank" && /* @__PURE__ */ d("path", { d: "M6 16h20" })
		]
	});
}
//#endregion
//#region src/games/vantage/launch-panel.tsx
function Lo({ pub: e, priv: t, me: n, send: r }) {
	let i = l(), a = e.launch;
	if (e.phase !== "launch" || !a) return null;
	let o = a.ready.includes(n.rid), s = a.selected.includes(n.rid), c = a.joined?.[n.rid] ?? n.rid, p = e.players.flatMap((e, t) => (a.joined?.[e.rid] ?? e.rid) === c ? [t + 1] : []);
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			/* @__PURE__ */ d("h2", { children: i(a.stage === "000" ? "games.vantage.launchCockpit" : "games.vantage.launchEscape") }),
			a.stage === "001" && p.length > 1 ? /* @__PURE__ */ d("p", {
				role: "status",
				children: i("games.vantage.sharedCapsuleCrew", { seats: p.join(", ") })
			}) : /* @__PURE__ */ d("p", { children: i(a.stage === "000" ? a.rewind ? "games.vantage.launchRewindText" : "games.vantage.launchCockpitText" : "games.vantage.launchEscapeText") }),
			a.stage === "000" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ f("fieldset", {
					disabled: o || a.locked.includes(n.rid),
					children: [/* @__PURE__ */ d("legend", { children: i("games.vantage.startingStat") }), /* @__PURE__ */ d("div", {
						className: "vantage-cost-options",
						children: [
							3,
							4,
							5,
							6
						].map((e) => /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
							type: "radio",
							name: "launch-stat",
							value: e,
							checked: a.stats[n.rid] === e,
							onChange: () => r({
								type: "setLaunchStat",
								stat: e
							})
						}), e] }, e))
					})]
				}),
				t.missionDice && /* @__PURE__ */ f(u, { children: [
					/* @__PURE__ */ d("h3", { children: i("games.vantage.missionDice") }),
					/* @__PURE__ */ d("div", {
						className: "vantage-skill-row",
						children: t.missionDice.map((e, t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: e }), i(Q[e])] }, t))
					}),
					t.missionDice[0] === t.missionDice[1] && !a.ready.length && !e.players.some((e) => a.locked.includes(e.rid)) && /* @__PURE__ */ d("button", {
						onClick: () => r({ type: "rerollMission" }),
						children: i("games.vantage.rerollMission")
					})
				] }),
				!o && /* @__PURE__ */ d("button", {
					className: "vantage-primary",
					onClick: () => r({
						type: "prepareLaunch",
						stat: a.stats[n.rid]
					}),
					children: i("games.vantage.leaveCockpit")
				})
			] }),
			a.stage === "001" && !s && /* @__PURE__ */ d("div", {
				className: "vantage-cost-options",
				children: C.map((e, n) => /* @__PURE__ */ f("button", {
					disabled: !t.capsules.includes(e),
					onClick: () => r({
						type: "chooseCapsule",
						skill: e
					}),
					children: [
						/* @__PURE__ */ d($, { kind: e }),
						i("games.vantage.escapeCapsule", { n: n + 2 }),
						" · ",
						i(Q[e])
					]
				}, e))
			}),
			(a.stage === "000" && o || s) && /* @__PURE__ */ d("p", {
				role: "status",
				children: i("games.vantage.waitingLaunch")
			}),
			t.options.map((e) => /* @__PURE__ */ f("button", {
				onClick: () => r({
					type: "chooseAction",
					id: e.id
				}),
				children: [/* @__PURE__ */ d($, { kind: "move" }), i("games.vantage.openingMissionAction")]
			}, e.id))
		]
	});
}
//#endregion
//#region src/games/vantage/ability-labels.ts
var Ro = {
	escapePlan: "games.vantage.chooseEscapePlan",
	soulstoneTravel: "games.vantage.chooseSoulstoneRoute",
	hatchEgg: "games.vantage.hatchEgg",
	pathReward: "games.vantage.claimPathReward",
	scavengeStarter: "games.vantage.scavengeStarter",
	murderReward: "games.vantage.claimMurderReward",
	feedVillagers: "games.vantage.confirmFoodDonation",
	investmentReturn: "games.vantage.claimInvestment",
	actionLock: "games.vantage.acknowledgeRestriction",
	councilWeapons: "games.vantage.enterCouncil",
	boxBelongings: "games.vantage.enterBox",
	boxBelongingsWithVehicles: "games.vantage.enterBox",
	militaryTraining: "games.vantage.practiceMilitary",
	reviveAnimal: "games.vantage.reviveAnimal",
	crewTides: "games.vantage.beginTideSharing",
	chase668: "games.vantage.resolveAnimalObstacle",
	passCrying676: "games.vantage.passSentient",
	lizard711: "games.vantage.passAnimal",
	uninjuredFlora: "games.vantage.checkUninjuredReward",
	recoverGatewayItem: "games.vantage.retrieveHiddenItem",
	heatGuardHere: "games.vantage.ignoreLocalHeat",
	replaceMission: "games.vantage.adoptTravelerMission",
	asylumRoll: "games.vantage.rollAsylumVisitor",
	grantAsylum: "games.vantage.grantAsylum",
	paySpiderFood: "games.vantage.paySpiderBoost",
	foundryLoot: "games.vantage.claimFoundryLoot",
	questEggBoost: "games.vantage.boostQuestEgg",
	deliverBarrel: "games.vantage.deliverBarrel",
	hostageBoost: "games.vantage.boostHostage",
	deliverSoulstone: "games.vantage.deliverSoulstone",
	becomeReborn: "games.vantage.becomeReborn",
	restoreBody: "games.vantage.restoreBody"
};
//#endregion
//#region src/games/vantage/elemental-panel.tsx
function zo({ battle: e, preview: t }) {
	let n = l(), r = si[e.location].first, [a, o] = i([
		r + 2,
		r + 3,
		r + 1,
		r
	]), [s, c] = i(null);
	function u(e) {
		if (s === null) {
			c(e);
			return;
		}
		let t = [...a];
		[t[s], t[e]] = [t[e], t[s]], o(t), c(null);
	}
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			/* @__PURE__ */ d("h2", { children: n("games.vantage.elementalCombat", { n: e.cards.length }) }),
			/* @__PURE__ */ d("div", {
				className: "vantage-elemental-image",
				children: a.map((t, r) => /* @__PURE__ */ d("button", {
					"data-selected": s === r,
					"data-slain": !e.cards.includes(t),
					"aria-label": n("games.vantage.arrangeElementalPart", { n: t }),
					onClick: () => u(r),
					children: /* @__PURE__ */ d(Fo, {
						src: `games/vantage/live/cards/${t}.webp`,
						alt: n("games.vantage.elementalPart", { n: t })
					})
				}, t))
			}),
			/* @__PURE__ */ d("p", { children: n("games.vantage.arrangeElemental") }),
			/* @__PURE__ */ d("div", {
				className: "vantage-elemental-parts",
				children: e.cards.map((e) => /* @__PURE__ */ d("button", {
					onClick: () => t(e),
					children: n("games.vantage.elementalPart", { n: e })
				}, e))
			}),
			e.next !== "none" && /* @__PURE__ */ d("p", { children: n(e.next === "discount" ? "games.vantage.elementalDiscount" : e.next === "ignoreHealth" ? "games.vantage.elementalIgnoreHealth" : "games.vantage.elementalReroll") })
		]
	});
}
function Bo({ pub: e, priv: t, me: n, nameOf: r, send: i }) {
	let a = l(), o = c((e) => e.locale), s = e.summoning;
	if (!s) return null;
	let u = s.waiting.includes(n.rid);
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			/* @__PURE__ */ d("h2", { children: a("games.vantage.summonedCrew") }),
			s.summoned.length > 0 && /* @__PURE__ */ d("p", { children: a("games.vantage.summonedPlayers", { names: s.summoned.map(r).join("、") }) }),
			u && (t.summonCharacters.length ? /* @__PURE__ */ d("div", {
				className: "vantage-power-options",
				children: t.summonCharacters.map((e) => /* @__PURE__ */ d("button", {
					onClick: () => i({
						type: "answerSummon",
						accept: !0,
						card: e
					}),
					children: a("games.vantage.summonCharacter", { name: o === "zh" ? E[e].nameZh : E[e].name })
				}, e))
			}) : /* @__PURE__ */ d("button", {
				disabled: (n.grid[4]?.boost ?? 0) < 2,
				onClick: () => i({
					type: "answerSummon",
					accept: !0
				}),
				children: a("games.vantage.paySummon")
			})),
			u && /* @__PURE__ */ d("button", {
				onClick: () => i({
					type: "answerSummon",
					accept: !1
				}),
				children: a("games.vantage.declineSummon")
			}),
			s.waiting.length > 0 && !u && /* @__PURE__ */ d("p", {
				role: "status",
				children: a("games.vantage.waitingSummon", { names: s.waiting.map(r).join("、") })
			}),
			/* @__PURE__ */ d("p", { children: a("games.vantage.summonDuration") })
		]
	});
}
//#endregion
//#region src/games/vantage/skirm-labels.ts
var Vo = Object.fromEntries([
	"mask",
	"horn",
	"gauntlet",
	"scepter",
	"helm",
	"harness",
	"cloak",
	"tome",
	"dodecahedron",
	"mantle",
	"blade",
	"tools"
].map((e) => [e, `games.vantage.artifacts.${e}`])), Ho = Object.fromEntries([
	"circuit",
	"wind",
	"energy",
	"fire",
	"gold",
	"sinew",
	"metal",
	"sand",
	"stone",
	"leaf",
	"water",
	"wood"
].map((e) => [e, `games.vantage.elements.${e}`]));
//#endregion
//#region src/games/vantage/skirm-view.tsx
function Uo({ pub: e, priv: t, myRid: n, send: r }) {
	let a = l(), [o, s] = i([]), [c, p] = i([]), [m, h] = i({}), g = e.skirm;
	if (!g) return null;
	let _ = g.turn, v = 1 - _, y = (g.stage === "blade" ? g.controllers[v] : g.controllers[_]) === n && g.stage !== "scored" && !e.skillRollPlayer, b = t.needsReserveRoom, x = g.cards[_] === null ? null : Kn(g.cards[_]), S = g.dice[_], w = g.dice[v], T = (e) => a(e === 0 ? "games.vantage.skirmSelf" : "games.vantage.skirmOpponent"), E = (e) => /* @__PURE__ */ f("div", {
		className: "vantage-skirm-counts",
		children: [C.map((n, r) => {
			let i = t.skirmSide === e ? g.dice[e].filter((e, r) => e === null && t.skirmDice[r] === n).length : 0;
			return /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, {
				kind: n,
				size: 18
			}), /* @__PURE__ */ d("b", { children: g.counts[e][r] + i })] }, n);
		}), g.bonus[e] !== 0 && /* @__PURE__ */ d("span", { children: a("games.vantage.skirmBonus", { n: g.bonus[e] }) })]
	}), D = (e, t) => {
		(t ? p : s)((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
	}, O = (e, t = {}) => {
		r({
			type: "skirm",
			op: e,
			indices: o,
			other: c,
			faces: o.map((e) => m[e] ?? "move"),
			...t
		}), s([]), p([]), h({});
	}, ee = (e, n) => /* @__PURE__ */ d("div", {
		className: "vantage-rolled",
		children: e.map((e, r) => {
			let i = n ? v : _, s = e ?? (t.skirmSide === i ? t.skirmDice[r] : null);
			return /* @__PURE__ */ f("button", {
				className: "vantage-die",
				"data-selected": (n ? c : o).includes(r),
				"data-hidden": e === null,
				"data-group": g.stage === "blade" && n ? g.groups.includes(r) ? 1 : 2 : void 0,
				disabled: !y || e === null || g.stage === "blade",
				onClick: () => D(r, n),
				"aria-label": a(s ? Q[s] : "games.vantage.skirmHidden"),
				children: [
					/* @__PURE__ */ d($, {
						kind: s ?? "blank",
						size: 30
					}),
					/* @__PURE__ */ d("small", { children: s ? a(Q[s]) : "?" }),
					g.stage === "blade" && n && /* @__PURE__ */ d("b", { children: a("games.vantage.skirmGroupN", { n: g.groups.includes(r) ? 1 : 2 }) })
				]
			}, r);
		})
	});
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper vantage-skirm",
		children: [/* @__PURE__ */ d("h2", { children: a("games.vantage.skirm") }), g.stage === "choose" ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("p", { children: a("games.vantage.skirmChoose") }),
			ee(t.skirmDice, !1),
			/* @__PURE__ */ d("div", {
				className: "vantage-skirm-cards",
				children: t.skirmOptions.map((e) => {
					let t = Kn(e);
					return /* @__PURE__ */ f("button", {
						className: "vantage-skirm-card",
						onClick: () => r({
							type: "skirm",
							op: "choose",
							card: e,
							indices: [],
							other: [],
							faces: []
						}),
						children: [
							/* @__PURE__ */ d("strong", { children: e >= 1517 ? e : "S" + String(e).padStart(3, "0") }),
							/* @__PURE__ */ d("span", { children: a("games.vantage.skirmSpeed", { n: t.speed }) }),
							/* @__PURE__ */ d("span", { children: t.skills.map((e, t) => /* @__PURE__ */ d($, { kind: e }, t)) }),
							/* @__PURE__ */ d("p", { children: a(Vo[t.artifact]) }),
							/* @__PURE__ */ d("small", { children: a(Ho[t.element]) })
						]
					}, e);
				})
			})
		] }) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("div", {
			className: "vantage-skirm-cards",
			children: g.cards.map((e, t) => e !== null && /* @__PURE__ */ f("article", {
				className: "vantage-skirm-card",
				children: [
					/* @__PURE__ */ f("h3", { children: [
						a(t === 0 ? "games.vantage.skirmSelf" : "games.vantage.skirmOpponent"),
						" · ",
						e < 1517 ? "S" + String(e).padStart(3, "0") : e
					] }),
					/* @__PURE__ */ d("strong", { children: a("games.vantage.skirmSpeed", { n: Kn(e).speed }) }),
					/* @__PURE__ */ f("div", { children: [Kn(e).skills.map((e, n) => g.removedPrinted[t].includes(e) ? /* @__PURE__ */ d("s", { children: /* @__PURE__ */ d($, { kind: e }) }, n) : /* @__PURE__ */ d($, { kind: e }, n)), g.extras[t].map((e, t) => /* @__PURE__ */ d($, { kind: e }, "extra" + t))] }),
					/* @__PURE__ */ d("p", { children: a(Vo[Kn(e).artifact]) }),
					/* @__PURE__ */ d("small", { children: a(Ho[Kn(e).element]) })
				]
			}, t))
		}), g.stage === "scored" ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("h2", { children: a(g.winner === 0 ? "games.vantage.skirmWin" : "games.vantage.skirmLose") }),
			/* @__PURE__ */ f("p", { children: [
				a("games.vantage.skirmPoints", { n: g.scores[0] }),
				" / ",
				a("games.vantage.skirmPoints", { n: g.scores[1] })
			] }),
			/* @__PURE__ */ d("h3", { children: T(_) }),
			E(_),
			ee(S, !1),
			/* @__PURE__ */ d("h3", { children: T(v) }),
			E(v),
			ee(w, !0),
			e.active === n && /* @__PURE__ */ f(u, { children: [b && /* @__PURE__ */ d("p", {
				role: "status",
				children: a("games.vantage.errReserveFull")
			}), /* @__PURE__ */ d("button", {
				className: "vantage-primary",
				disabled: b,
				onClick: () => r({ type: "finishSkirm" }),
				children: a("games.vantage.skirmFinish")
			})] })
		] }) : /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("p", { children: a(g.stage === "blade" ? "games.vantage.skirmGroupTurn" : "games.vantage.skirmTurn", { side: T(g.stage === "blade" ? v : _) }) }),
			/* @__PURE__ */ d("h3", { children: T(_) }),
			E(_),
			ee(S, !1),
			/* @__PURE__ */ d("h3", { children: T(v) }),
			E(v),
			ee(w, !0),
			y && x && /* @__PURE__ */ f("div", {
				className: "vantage-skirm-controls",
				children: [
					/* @__PURE__ */ d("p", { children: a(Vo[x.artifact]) }),
					(x.artifact === "mask" || x.artifact === "tools" || g.stage === "mantle") && /* @__PURE__ */ f("fieldset", { children: [/* @__PURE__ */ d("legend", { children: a("games.vantage.skirmSelectFaces") }), o.map((e) => /* @__PURE__ */ f("label", { children: [e + 1, /* @__PURE__ */ d("select", {
						value: m[e] ?? "move",
						onChange: (t) => h({
							...m,
							[e]: t.target.value
						}),
						children: C.map((e) => /* @__PURE__ */ d("option", {
							value: e,
							children: a(Q[e])
						}, e))
					})] }, e))] }),
					g.stage === "tome" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("button", {
						onClick: () => O("keep", { choice: 0 }),
						children: [
							a("games.vantage.skirmOld"),
							" ",
							/* @__PURE__ */ d($, { kind: t.skirmPrevious ?? "blank" })
						]
					}), /* @__PURE__ */ f("button", {
						onClick: () => O("keep", { choice: 1 }),
						children: [
							a("games.vantage.skirmNew"),
							" ",
							/* @__PURE__ */ d($, { kind: t.skirmRolled ?? "blank" })
						]
					})] }) : g.stage === "dodecahedron" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
						onClick: () => O("keep", { choice: 0 }),
						children: a("games.vantage.skirmKeepMine")
					}), /* @__PURE__ */ d("button", {
						onClick: () => O("keep", { choice: 1 }),
						children: a("games.vantage.skirmKeepOther")
					})] }) : g.stage === "blade" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
						onClick: () => O("group", { choice: 0 }),
						children: a("games.vantage.skirmGroup1")
					}), /* @__PURE__ */ d("button", {
						onClick: () => O("group", { choice: 1 }),
						children: a("games.vantage.skirmGroup2")
					})] }) : g.stage === "helm" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
						onClick: () => O("reroll"),
						children: a("games.vantage.skirmReroll")
					}), /* @__PURE__ */ d("button", {
						onClick: () => O("skip"),
						children: a("games.vantage.skirmSkip")
					})] }) : g.stage === "scepter" || g.stage === "mantle" || ["mask", "tools"].includes(x.artifact) ? /* @__PURE__ */ d("button", {
						onClick: () => O("set"),
						children: a("games.vantage.skirmSet")
					}) : x.artifact === "helm" ? /* @__PURE__ */ d("button", {
						onClick: () => O("swap"),
						children: a("games.vantage.skirmSwap")
					}) : [
						"scepter",
						"harness",
						"cloak",
						"tome",
						"dodecahedron"
					].includes(x.artifact) ? /* @__PURE__ */ d("button", {
						onClick: () => O("reroll"),
						children: a("games.vantage.skirmReroll")
					}) : /* @__PURE__ */ d("button", {
						onClick: () => O("activate"),
						children: a("games.vantage.skirmActivate")
					}),
					g.stage === "ability" && [
						"harness",
						"cloak",
						"tome",
						"tools",
						"gauntlet"
					].includes(x.artifact) && /* @__PURE__ */ d("button", {
						onClick: () => O("skip"),
						children: a("games.vantage.skirmSkip")
					})
				]
			})
		] })] })]
	});
}
//#endregion
//#region src/games/vantage/composition-icons.tsx
var Wo = {
	water: "games.vantage.composition.water",
	wood: "games.vantage.composition.wood",
	wind: "games.vantage.composition.wind",
	leaf: "games.vantage.composition.leaf",
	stone: "games.vantage.composition.stone",
	sand: "games.vantage.composition.sand",
	metal: "games.vantage.composition.metal",
	sinew: "games.vantage.composition.sinew",
	gold: "games.vantage.composition.gold",
	fire: "games.vantage.composition.fire",
	energy: "games.vantage.composition.energy",
	circuit: "games.vantage.composition.circuit"
};
function Go({ element: e }) {
	let t = l();
	return /* @__PURE__ */ d("span", {
		className: "vantage-compositions",
		title: t(Wo[e]),
		children: /* @__PURE__ */ d(Fo, {
			src: `games/vantage/live/compositions/${e}.webp`,
			alt: t(Wo[e])
		})
	});
}
function Ko({ card: e, owner: t }) {
	let n = l(), r = xe(e), i = r ? [r] : _e(e, t);
	return i.length ? /* @__PURE__ */ d("span", {
		className: "vantage-compositions",
		children: i.map((e) => /* @__PURE__ */ d("span", {
			title: n(Wo[e]),
			children: /* @__PURE__ */ d(Fo, {
				src: `games/vantage/live/compositions/${e}.webp`,
				alt: n(Wo[e])
			})
		}, e))
	}) : null;
}
//#endregion
//#region src/games/vantage/card-description.tsx
var qo = {
	water: "games.vantage.curseInstructions.water",
	wood: "games.vantage.curseInstructions.wood",
	wind: "games.vantage.curseInstructions.wind",
	leaf: "games.vantage.curseInstructions.leaf",
	stone: "games.vantage.curseInstructions.stone",
	sand: "games.vantage.curseInstructions.sand",
	metal: "games.vantage.curseInstructions.metal",
	sinew: "games.vantage.curseInstructions.sinew",
	gold: "games.vantage.curseInstructions.gold",
	fire: "games.vantage.curseInstructions.fire",
	energy: "games.vantage.curseInstructions.energy",
	circuit: "games.vantage.curseInstructions.circuit"
};
function Jo({ card: e }) {
	let t = l(), n = c((e) => e.locale), r = xe(e), i = E[e];
	if (e >= 1517 && e <= 1528) {
		let n = Kn(e);
		return /* @__PURE__ */ f("div", {
			className: "vantage-card-description",
			children: [
				/* @__PURE__ */ d("p", { children: t("games.vantage.skirmSpeed", { n: n.speed }) }),
				/* @__PURE__ */ d("p", { children: n.skills.map((e, t) => /* @__PURE__ */ d($, { kind: e }, t)) }),
				/* @__PURE__ */ d("p", { children: t(Vo[n.artifact]) }),
				/* @__PURE__ */ d("p", { children: t(Ho[n.element]) })
			]
		});
	}
	let a = n === "en" ? i?.printedActionsEn : i?.printedActionsZh, o = r ? t("games.vantage.curseDescription", {
		element: t(Wo[r]),
		penalty: t(qo[r])
	}) : n === "en" && i?.textEn ? i.textEn : i?.textZh;
	return /* @__PURE__ */ f(u, { children: [a && /* @__PURE__ */ d("p", {
		className: "vantage-card-description",
		children: a
	}), o && /* @__PURE__ */ d("p", {
		className: "vantage-card-description",
		children: o
	})] });
}
function Yo({ card: e }) {
	let t = l(), n = E[e]?.value;
	return n === void 0 ? null : /* @__PURE__ */ d("span", {
		className: "vantage-card-value",
		children: t("games.vantage.printedValue", { n })
	});
}
//#endregion
//#region src/games/vantage/mission-panel.tsx
function Xo({ pub: e, priv: t, mine: n, send: r, preview: a }) {
	let o = l(), s = c((e) => e.locale), [u, p] = i(null), m = D["m" + e.mission + ":0"]?.node, h = m?.missionPivot ? m : m?.choices.find((e) => e.node.missionPivot)?.node;
	return /* @__PURE__ */ f("section", {
		className: "vantage-mission",
		children: [/* @__PURE__ */ d("h2", { children: o("games.vantage.mission", { n: e.mission }) }), e.center.map((i) => /* @__PURE__ */ f("div", { children: [
			/* @__PURE__ */ d("button", {
				onClick: () => a(i.card),
				children: o("games.vantage.card", { n: i.card })
			}),
			/* @__PURE__ */ d(Jo, { card: i.card }),
			i.tokens !== void 0 && /* @__PURE__ */ d("p", { children: o("games.vantage.goalTokens", { n: i.tokens }) }),
			i.card === e.mission && e.missionPivot && h?.missionGoal && /* @__PURE__ */ f("p", { children: [
				/* @__PURE__ */ d("strong", { children: o("games.vantage.alternativeMission") }),
				" · ",
				s === "zh" ? h.missionGoal.zh : h.missionGoal.en
			] }),
			i.card === e.mission && e.missionDone && /* @__PURE__ */ d("strong", { children: o("games.vantage.missionCompleted") }),
			i.card === e.mission && e.missionReady && n && e.phase === "action" && /* @__PURE__ */ f("div", {
				className: "vantage-goal-choice",
				children: [
					/* @__PURE__ */ d("p", { children: s === "zh" && t?.missionConclusionZh ? t.missionConclusionZh : t?.missionConclusion }),
					/* @__PURE__ */ d("button", {
						onClick: () => r({
							type: "completeMission",
							end: !0
						}),
						children: o("games.vantage.endMissionVictory")
					}),
					!Rn.includes(e.mission) && /* @__PURE__ */ f("label", { children: [o("games.vantage.chooseDestiny"), /* @__PURE__ */ d("select", {
						value: u ?? Ln[e.mission],
						onChange: (e) => p(Number(e.target.value)),
						children: Array.from({ length: 11 }, (e, t) => 1598 + t).map((e) => /* @__PURE__ */ d("option", {
							value: e,
							children: o("games.vantage.destinyN", { n: e })
						}, e))
					})] }),
					/* @__PURE__ */ d("button", {
						onClick: () => r({
							type: "completeMission",
							end: !1,
							...u === null ? {} : { destiny: u }
						}),
						children: o("games.vantage.pursueDestiny")
					})
				]
			}),
			e.readyDestinies.includes(i.card) && n && e.phase === "action" && /* @__PURE__ */ d("button", {
				onClick: () => r({
					type: "readGoal",
					card: i.card,
					condition: !0
				}),
				children: o("games.vantage.completeDestiny")
			})
		] }, i.card))]
	});
}
//#endregion
//#region src/games/vantage/ability-effects.tsx
function Zo({ priv: e, player: t, index: n, kind: r, value: a, disabled: o, send: s }) {
	let u = l(), p = c((e) => e.locale), [m, h] = i({}), [g, _] = i(null), [v, y] = i([]), [b, x] = i(1), [S, w] = i([]), [T, D] = i(""), [O, ee] = i(""), [te, ne] = i(1), [re, ie] = i(!1), k = (e = {}) => s({
		type: "applyEffect",
		index: n,
		...e
	}), ae = (e) => `${e} ${p === "zh" ? E[e]?.nameZh : E[e]?.name}`, oe = [
		...t.grid.flatMap((e) => e ? [e] : []),
		...t.reserve,
		...t.supply
	], se = u(r === "copyAction" ? "games.vantage.chooseCopiedAction" : r === "testPickOne" ? "games.vantage.chooseTestSkill" : r === "matchingTestReward" ? "games.vantage.gainMatchingTest" : "games.vantage.abilityInstructions");
	if ([
		"soulstoneTravel",
		"escapePlan",
		"intimidateSword",
		"placeFromReserve"
	].includes(a)) return /* @__PURE__ */ d("div", {
		className: "vantage-power-options",
		children: e.abilityChoices.map((e) => /* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k({ action: e.id }),
			children: p === "zh" ? e.labelZh : e.label
		}, e.id))
	});
	if (a === "hatchEgg") return /* @__PURE__ */ f("div", {
		className: "vantage-power-options",
		children: [/* @__PURE__ */ d("p", { children: u("games.vantage.hatchEgg") }), [...t.grid, ...t.reserve].flatMap((e) => e && ke[e.card] ? [e] : []).map((e) => /* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k({ cards: [e.card] }),
			children: ae(e.card)
		}, e.card))]
	});
	if (a === "feedVillagers") {
		let e = [...t.grid.flatMap((e) => e ? [e] : []), ...t.reserve].filter((e) => P(e.card, "food")), n = Object.values(m).reduce((e, t) => e + t, 0);
		return /* @__PURE__ */ f("div", {
			className: "vantage-power-options",
			children: [
				/* @__PURE__ */ d("p", { children: u("games.vantage.foodDonation") }),
				e.map((e) => /* @__PURE__ */ f("label", { children: [ae(e.card), /* @__PURE__ */ d("select", {
					value: m[e.card] ?? 0,
					disabled: o,
					onChange: (t) => h({
						...m,
						[e.card]: Number(t.target.value)
					}),
					children: Array.from({ length: e.boost + 1 }, (e, t) => /* @__PURE__ */ d("option", {
						value: t,
						children: t
					}, t))
				})] }, e.card)),
				/* @__PURE__ */ d("button", {
					disabled: o,
					onClick: () => k({ transfers: Object.entries(m).filter(([, e]) => e > 0).map(([e, t]) => ({
						card: Number(e),
						amount: t
					})) }),
					children: u("games.vantage.confirmFoodDonation", { n })
				})
			]
		});
	}
	if (a === "murderReward") {
		let e = oe.some((e) => [1359, 1364].includes(e.card));
		return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: u(e ? "games.vantage.fillInnocentSentients" : "games.vantage.chooseInnocentSentient") }), e ? /* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k(),
			children: u("games.vantage.fillSentientBoost")
		}) : [1359, 1364].map((e) => /* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k({ cards: [e] }),
			children: ae(e)
		}, e))] });
	}
	if (a === "paySpiderFood") return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: u("games.vantage.paySpiderFood") }), t.grid.flatMap((e) => e && e.boost > 0 && [
		"food",
		"animal",
		"sinew"
	].some((t) => P(e.card, t)) ? [e] : []).map((e) => /* @__PURE__ */ d("button", {
		disabled: o,
		onClick: () => k({ cards: [e.card] }),
		children: u("games.vantage.payBoostFrom", { card: ae(e.card) })
	}, e.card))] });
	if (a === "foundryLoot") return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d("p", { children: u("games.vantage.foundryLoot") }),
		[
			874,
			938,
			976
		].map((e) => /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
			type: "checkbox",
			checked: S.includes(String(e)),
			disabled: o || !S.includes(String(e)) && S.length >= 2,
			onChange: (t) => w(t.target.checked ? [...S, String(e)] : S.filter((t) => t !== String(e)))
		}), ae(e)] }, e)),
		/* @__PURE__ */ d("button", {
			disabled: o || !S.length,
			onClick: () => k({ cards: S.map(Number) }),
			children: u("games.vantage.confirmFoundryLoot", { n: S.length })
		})
	] });
	if (a === "hideGatewayItem") return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d("p", { children: u("games.vantage.hideGatewayItem") }),
		[...t.grid, ...t.reserve].flatMap((e) => e && E[e.card].group === "item" && e.hiddenAt === void 0 ? [e] : []).map((e) => /* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k({ cards: [e.card] }),
			children: ae(e.card)
		}, e.card)),
		/* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k({ cards: [] }),
			children: u("games.vantage.hideNoItem")
		})
	] });
	if (a === "portalDestination") return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ f("label", { children: [u("games.vantage.portalDestination"), /* @__PURE__ */ d("input", {
			inputMode: "numeric",
			type: "number",
			min: 12,
			max: 801,
			value: T,
			disabled: o,
			onChange: (e) => D(e.target.value)
		})] }),
		/* @__PURE__ */ d("p", { children: u("games.vantage.portalDestinations") }),
		/* @__PURE__ */ d("button", {
			disabled: o || !Number(T) || !(Number(T) >= 12 && Number(T) <= 63 || Number(T) >= 76 && Number(T) <= 531 || Number(T) >= 541 && Number(T) <= 791 || [
				795,
				799,
				801
			].includes(Number(T))),
			onClick: () => k({ destination: Number(T) }),
			children: u("games.vantage.enterPortal")
		})
	] });
	if (a === "recruitInformation") return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d("p", { children: u("games.vantage.recruitWithSkills") }),
		C.map((e) => /* @__PURE__ */ f("label", { children: [u(Q[e]), /* @__PURE__ */ d("select", {
			disabled: o,
			value: v.filter((t) => t === e).length,
			onChange: (t) => y([...v.filter((t) => t !== e), ...Array.from({ length: Number(t.target.value) }, () => e)]),
			children: Array.from({ length: Math.min(3, t.skills[e]) + 1 }, (e, t) => /* @__PURE__ */ d("option", {
				value: t,
				children: t
			}, t))
		})] }, e)),
		/* @__PURE__ */ d("button", {
			disabled: o || v.length < 1 || v.length > 3,
			onClick: () => k({ skillPayment: v }),
			children: u("games.vantage.confirmRecruitSkills", { n: v.length })
		})
	] });
	if (a === "invest") return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [u("games.vantage.investmentAmount"), /* @__PURE__ */ d("select", {
		value: b,
		disabled: o,
		onChange: (e) => x(Number(e.target.value)),
		children: Array.from({ length: Math.min(10, t.coins) }, (e, t) => /* @__PURE__ */ d("option", {
			value: t + 1,
			children: t + 1
		}, t))
	})] }), /* @__PURE__ */ d("button", {
		disabled: o || t.coins < b,
		onClick: () => k({ investment: b }),
		children: u("games.vantage.investAndRoll")
	})] });
	if (a === "loyalAnimal") return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: u("games.vantage.chooseWildAnimal") }), t.grid.flatMap((e) => e && P(e.card, "wildAnimal") ? [e] : []).map((e) => /* @__PURE__ */ d("button", {
		disabled: o,
		onClick: () => k({ cards: [e.card] }),
		children: ae(e.card)
	}, e.card))] });
	if (a === "personalItemBoost") {
		let e = oe.find((e) => e.card === 1299 + M(t)), n = e ? Math.min(2, E[e.card].boostCapacity - e.boost) : 0, r = Math.min(te, n);
		return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [u("games.vantage.personalItemBoostAmount"), /* @__PURE__ */ d("select", {
			value: r,
			disabled: o,
			onChange: (e) => ne(Number(e.target.value)),
			children: Array.from({ length: n + 1 }, (e, t) => /* @__PURE__ */ d("option", {
				value: t,
				children: t
			}, t))
		})] }), /* @__PURE__ */ d("button", {
			disabled: o || !e,
			onClick: () => k({ reward: r }),
			children: u("games.vantage.apply")
		})] });
	}
	if (a === "houseOccupancy" && e.knownHouseFace !== null) return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: u(e.knownHouseFace === "blank" ? "games.vantage.houseKnownEmpty" : "games.vantage.houseKnownOccupied") }), /* @__PURE__ */ d("button", {
		disabled: o,
		onClick: () => k(),
		children: u("games.vantage.useKnownHouseStatus")
	})] });
	if (a === "floraForesight" || a === "floraForesightGroups" || a === "houseOccupancy") {
		let t = a === "houseOccupancy" ? 1 : a === "floraForesightGroups" ? 4 : 2, { pool: n, center: r } = e.foresightSources, i = Array.from({ length: t + 1 }, (e, t) => t).filter((e) => e <= n && t - e <= r), s = i.includes(g ?? -1) ? g : i.at(-1);
		return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [u(a === "houseOccupancy" ? "games.vantage.chooseHouseDieSource" : "games.vantage.chooseForesightSources"), /* @__PURE__ */ d("select", {
			value: s ?? "",
			disabled: o,
			onChange: (e) => _(Number(e.target.value)),
			children: i.map((e) => /* @__PURE__ */ d("option", {
				value: e,
				children: u("games.vantage.foresightSources", {
					pool: e,
					center: t - e
				})
			}, e))
		})] }), /* @__PURE__ */ d("button", {
			disabled: o || s === void 0,
			onClick: () => k({ diceFromPool: s }),
			children: u(a === "houseOccupancy" ? "games.vantage.checkHouse" : "games.vantage.rollForesight", { n: t })
		})] });
	}
	if (a === "floraChooseForesight") return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: u("games.vantage.chooseForesightGroup") }), [0, 1].map((t) => /* @__PURE__ */ d("button", {
		disabled: o || e.bonusDice.length !== 4,
		onClick: () => k({ line: t }),
		children: u("games.vantage.foresightGroup", {
			n: t + 1,
			faces: e.bonusDice.slice(t * 2, t * 2 + 2).map((e) => u(Q[e])).join(" · ")
		})
	}, t))] });
	if (a === "floraDonate") return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d("p", { children: u("games.vantage.floraDonate") }),
		t.grid.flatMap((e) => e && E[e.card].group === "sentient" && e.boost > 0 ? [e] : []).map((e) => /* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k({ cards: [e.card] }),
			children: ae(e.card)
		}, e.card)),
		/* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k({ cards: [] }),
			children: u(E[e.current?.source ?? 0]?.group === "location" ? "games.vantage.characterBoostInstead" : "games.vantage.floraBoostInstead")
		})
	] });
	if (a === "floraTransfer") {
		let t = oe.find((t) => t.card === e.current?.source), n = Object.values(m).reduce((e, t) => e + t, 0);
		return /* @__PURE__ */ f("div", { children: [
			/* @__PURE__ */ d("p", { children: u("games.vantage.floraTransfer", { n: t?.boost ?? 0 }) }),
			oe.filter((e) => e !== t && e.boost < E[e.card].boostCapacity).map((e) => /* @__PURE__ */ f("label", { children: [ae(e.card), /* @__PURE__ */ d("select", {
				disabled: o,
				value: m[e.card] ?? 0,
				onChange: (t) => h({
					...m,
					[e.card]: Number(t.target.value)
				}),
				children: Array.from({ length: Math.min(t?.boost ?? 0, E[e.card].boostCapacity - e.boost) + 1 }, (e, t) => /* @__PURE__ */ d("option", {
					value: t,
					children: t
				}, t))
			})] }, e.card)),
			/* @__PURE__ */ d("button", {
				disabled: o || n > (t?.boost ?? 0),
				onClick: () => k({ transfers: Object.entries(m).filter(([, e]) => e > 0).map(([e, t]) => ({
					card: Number(e),
					amount: t
				})) }),
				children: u("games.vantage.confirmFloraTransfer")
			})
		] });
	}
	if (r === "matchingTestReward") return /* @__PURE__ */ d("button", {
		disabled: o || !e.storyTest?.done,
		onClick: () => k(),
		children: se
	});
	if (r === "testPickMany") return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d("p", { children: u("games.vantage.chooseTestSkills", { n: Number(a) }) }),
		(e.storyTest?.faces ?? []).map((e, t) => /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
			type: "checkbox",
			checked: S.includes(String(t)),
			disabled: o || !S.includes(String(t)) && S.length >= Number(a),
			onChange: (e) => w(e.target.checked ? [...S, String(t)] : S.filter((e) => e !== String(t)))
		}), u(Q[e])] }, t)),
		/* @__PURE__ */ d("button", {
			disabled: o || !e.storyTest?.done || S.length !== Number(a),
			onClick: () => k({ diceIndices: S.map(Number) }),
			children: u("games.vantage.apply")
		})
	] });
	if (r === "testPickOne") return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: se }), [...new Set(e.storyTest?.faces ?? [])].map((t) => /* @__PURE__ */ d("button", {
		disabled: o || !e.storyTest?.done,
		onClick: () => k({ skill: t }),
		children: u(Q[t])
	}, t))] });
	if (a === "refreshRow") return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: u("games.vantage.elementalPrepareRow") }), [
		0,
		1,
		2
	].map((e) => /* @__PURE__ */ d("button", {
		disabled: o,
		onClick: () => k({ line: e }),
		children: u("games.vantage.gridRow", { n: e + 1 })
	}, e))] });
	if (r === "copyAction" || [
		"adjacent",
		"adjacentOptional",
		"scout",
		"outcome",
		"costs"
	].includes(a)) return /* @__PURE__ */ f("div", {
		className: "vantage-power-options",
		children: [
			/* @__PURE__ */ d("p", { children: se }),
			r === "copyAction" && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: re,
				onChange: (e) => ie(e.target.checked)
			}), u("games.vantage.confirmMatchingAction")] }),
			e.abilityChoices.map((e) => a === "costs" ? /* @__PURE__ */ f("label", { children: [
				/* @__PURE__ */ d("input", {
					type: "checkbox",
					checked: S.includes(e.id),
					disabled: o || !S.includes(e.id) && S.length >= 2,
					onChange: (t) => w(t.target.checked ? [...S, e.id] : S.filter((t) => t !== e.id))
				}),
				p === "zh" && e.labelZh ? e.labelZh : e.label,
				" (",
				e.source,
				")"
			] }, e.id) : /* @__PURE__ */ f("button", {
				disabled: o || r === "copyAction" && !re,
				onClick: () => k({
					action: e.id,
					condition: re
				}),
				children: [
					p === "zh" && e.labelZh ? e.labelZh : Q[e.label] ? u(Q[e.label]) : e.label,
					" (",
					e.source,
					")"
				]
			}, e.id)),
			a === "costs" && /* @__PURE__ */ d("button", {
				disabled: o,
				onClick: () => k({ actions: S }),
				children: u("games.vantage.viewSelectedCosts")
			}),
			a === "adjacentOptional" && /* @__PURE__ */ d("button", {
				disabled: o,
				onClick: () => k({ action: "skip" }),
				children: u("games.vantage.stopHere")
			}),
			!e.abilityChoices.length && a !== "costs" && a !== "adjacentOptional" && /* @__PURE__ */ d("p", { children: u("games.vantage.noMatchingAction") })
		]
	});
	if (a === "double") return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d("p", { children: u("games.vantage.doubleBenefit") }),
		e.copiedBenefits.map((e, t) => /* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k({ reward: t }),
			children: u("games.vantage.benefitAmount", {
				n: e.amount,
				kind: Q[e.value] ? u(Q[e.value]) : u(e.kind === "coin" ? "games.vantage.coins" : e.kind === "boost" ? "games.vantage.boost" : "games.vantage.card"),
				card: e.value
			})
		}, t)),
		!e.copiedBenefits.length && /* @__PURE__ */ d("button", {
			disabled: o,
			onClick: () => k(),
			children: u("games.vantage.noBenefitToDouble")
		})
	] });
	if (a === "challengePairChoose") return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: u("games.vantage.chooseChallengeBenefit") }), e.abilityDice.map((t, n) => /* @__PURE__ */ d("button", {
		disabled: o,
		onClick: () => k({ line: n }),
		children: u("games.vantage.challengeBenefitPair", {
			benefit: u(Q[t]),
			penalty: u(Q[e.abilityDice[1 - n]])
		})
	}, n))] });
	if (a === "create") {
		let e = oe.filter((e) => [
			"item",
			"structure",
			"vehicle"
		].includes(E[e.card].group));
		return /* @__PURE__ */ f("div", { children: [
			/* @__PURE__ */ d("p", { children: u("games.vantage.createBoost") }),
			e.map((e) => {
				let t = String(e.card), n = E[e.card].group;
				return /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
					type: "checkbox",
					checked: S.includes(t),
					disabled: o || !S.includes(t) && S.some((e) => E[Number(e)].group === n),
					onChange: (e) => w(e.target.checked ? [...S, t] : S.filter((e) => e !== t))
				}), ae(e.card)] }, t);
			}),
			/* @__PURE__ */ d("button", {
				disabled: o,
				onClick: () => k({ cards: S.map(Number) }),
				children: u("games.vantage.apply")
			})
		] });
	}
	if ([
		"repair",
		"balance",
		"dance",
		"animalBoost"
	].includes(a)) {
		let e = a === "repair" ? oe.filter((e) => [
			"item",
			"structure",
			"vehicle"
		].includes(E[e.card].group)) : a === "dance" || a === "animalBoost" ? t.grid.flatMap((e) => e && E[e.card].group === (a === "dance" ? "sentient" : "animal") ? [e] : []) : oe, n = a === "repair" || a === "balance", r = (t, n) => /* @__PURE__ */ f("select", {
			value: t,
			onChange: (e) => n(e.target.value),
			children: [/* @__PURE__ */ d("option", {
				value: "",
				children: u("games.vantage.chooseCard")
			}), e.map((e) => /* @__PURE__ */ f("option", {
				value: e.card,
				children: [
					ae(e.card),
					" · ",
					u("games.vantage.supplyBoost", { n: e.boost })
				]
			}, e.card))]
		});
		return /* @__PURE__ */ f("div", { children: [
			/* @__PURE__ */ d("p", { children: u(a === "repair" ? "games.vantage.transferBoost" : a === "balance" ? "games.vantage.matchBoost" : a === "dance" ? "games.vantage.chooseDanceSentient" : "games.vantage.chooseInteractedAnimal") }),
			/* @__PURE__ */ f("label", { children: [u("games.vantage.chooseCard"), r(T, D)] }),
			n && /* @__PURE__ */ f("label", { children: [u("games.vantage.chooseSecondCard"), r(O, ee)] }),
			a === "repair" && /* @__PURE__ */ f("label", { children: [u("games.vantage.boostAmount"), /* @__PURE__ */ f("select", {
				value: te,
				onChange: (e) => ne(Number(e.target.value)),
				children: [/* @__PURE__ */ d("option", {
					value: 1,
					children: "1"
				}), /* @__PURE__ */ d("option", {
					value: 2,
					children: "2"
				})]
			})] }),
			a === "animalBoost" && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: re,
				onChange: (e) => ie(e.target.checked)
			}), u("games.vantage.confirmInteractedAnimal")] }),
			/* @__PURE__ */ d("button", {
				disabled: o || !T || n && (!O || O === T) || a === "animalBoost" && !re,
				onClick: () => k({
					cards: [Number(T), ...n ? [Number(O)] : []],
					amount: te,
					condition: re
				}),
				children: u("games.vantage.apply")
			})
		] });
	}
	return /* @__PURE__ */ d("button", {
		disabled: o,
		onClick: () => k(),
		children: u(Ro[a] ?? (a === "blueprint" ? "games.vantage.randomBlueprint" : a === "underground" ? "games.vantage.goUnderground" : a === "challengePair" ? "games.vantage.rollChallengePair" : a === "assembly" ? "games.vantage.assemblyBonus" : "games.vantage.apply"))
	});
}
function Qo({ option: e, disabled: t, choose: n }) {
	let r = l(), a = c((e) => e.locale), [o, s] = i(!1);
	return /* @__PURE__ */ f("div", { children: [e.condition && /* @__PURE__ */ f("label", {
		className: "vantage-condition",
		children: [/* @__PURE__ */ d("input", {
			type: "checkbox",
			checked: o,
			onChange: (e) => s(e.target.checked)
		}), a === "zh" ? e.condition.zh : e.condition.en]
	}), /* @__PURE__ */ f("button", {
		className: "vantage-action",
		"data-skill": e.book,
		disabled: t || !!e.condition && !o,
		onClick: n,
		children: [
			/* @__PURE__ */ d($, { kind: e.book === "depart" ? "move" : e.book }),
			/* @__PURE__ */ d("span", { children: e.book === "depart" && Q[e.label] ? r(Q[e.label]) : a === "zh" && e.labelZh ? e.labelZh : e.label }),
			/* @__PURE__ */ d("small", { children: e.source })
		]
	})] });
}
//#endregion
//#region src/games/vantage/branch-choice.tsx
function $o({ label: e, conditionLabel: t = e, disabled: n, choose: r }) {
	let a = l(), [o, s] = i(!1), c = /\bif|unless\b/i.test(t);
	return /* @__PURE__ */ f("div", {
		className: "vantage-branch-choice",
		children: [c && /* @__PURE__ */ f("label", {
			className: "vantage-condition",
			children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: o,
				onChange: (e) => s(e.target.checked)
			}), a("games.vantage.confirmBranchCondition")]
		}), /* @__PURE__ */ d("button", {
			className: "vantage-choice",
			disabled: n || c && !o,
			onClick: () => r(o),
			children: e
		})]
	});
}
//#endregion
//#region src/games/vantage/story-payment-panel.tsx
function es({ pub: e, me: t, waiting: n, send: r }) {
	let i = l(), a = e.storyPayment;
	if (!a) return null;
	let o = e.active === t.rid;
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ d("h3", { children: i("games.vantage.storyPaymentRequest") }),
			/* @__PURE__ */ d("p", { children: i("games.vantage.storyPaymentConsent") }),
			a.costs.map((s) => {
				let c = Object.entries(a.pledges).reduce((t, [n, r]) => t + Math.min(r[s.skill] ?? 0, e.players.find((e) => e.rid === n)?.skills[s.skill] ?? 0), 0);
				return /* @__PURE__ */ f("div", {
					className: "vantage-skill-row",
					children: [
						/* @__PURE__ */ d($, { kind: s.skill }),
						/* @__PURE__ */ d("span", { children: i("games.vantage.storyPaymentProgress", {
							skill: i(Q[s.skill]),
							n: s.amount,
							offered: c
						}) }),
						!o && Array.from({ length: Math.min(s.amount, t.skills[s.skill]) + 1 }, (e, o) => /* @__PURE__ */ d("button", {
							"aria-pressed": (a.pledges[t.rid]?.[s.skill] ?? 0) === o,
							disabled: n,
							onClick: () => r({
								type: "pledgeStoryPayment",
								skill: s.skill,
								amount: o
							}),
							children: i("games.vantage.storyPaymentPledge", { n: o })
						}, o))
					]
				}, s.skill);
			}),
			o && /* @__PURE__ */ d("button", {
				disabled: n,
				onClick: () => r({ type: "cancelStoryPayment" }),
				children: i("games.vantage.storyPaymentCancel")
			})
		]
	});
}
//#endregion
//#region src/games/vantage/printed-power-controls.tsx
var ts = [
	"hourglassUndo",
	"returnPortal",
	"stayPortal",
	"finishHourglassTurn",
	"convertSkill",
	"keepConversion",
	"recallDie",
	"finishMove",
	"cancelMove",
	"flourishSkill",
	"keepDice",
	"replaceDice",
	"dropExtraDie",
	"finishSwitch",
	"cancelSwitch",
	"finishReplacement",
	"preserveReplacement",
	"keepSkillGroup",
	"replaceSkillGroup",
	"dropExtraSkill",
	"repeatSkillGroup",
	"extraSkillGroup"
];
function ns({ card: e, ...t }) {
	let n = t.priv.printedPowerOptions.filter((t) => t.card === e && !ts.includes(t.op));
	return /* @__PURE__ */ d(u, { children: [...new Set(n.map((e) => e.op))].map((e) => /* @__PURE__ */ d(rs, {
		...t,
		options: n.filter((t) => t.op === e)
	}, e)) });
}
function rs({ options: e, nameOf: t, send: n }) {
	let r = l(), a = c((e) => e.locale), [o, s] = i(""), [u, p] = i(() => e[0]?.targetCard ?? 0), [m, h] = i(!1), g = e.find((e) => JSON.stringify(e) === o) ?? e[0];
	if (!g) return null;
	let _ = (e) => e.startsWith("exit:") ? r(Q[e.slice(5)]) : a === "zh" ? D[e]?.labelZh || D[e]?.printedZh : D[e]?.label, v = (e) => [
		e.composition && e.targetCard && e.compositionIndex !== void 0 ? r("games.vantage.compositionChange", {
			from: r(Wo[_e(e.targetCard)[e.compositionIndex]]),
			to: r(Wo[e.composition])
		}) : null,
		e.sourceOwner && e.sourceCard ? r("games.vantage.powerTransferSource", {
			name: t(e.sourceOwner),
			n: e.sourceCard
		}) : null,
		e.sourceCard && !e.sourceOwner ? String(e.sourceCard) : null,
		e.target ? t(e.target) : null,
		e.targetCard ? `${e.targetCard} · ${a === "zh" ? E[e.targetCard]?.nameZh : E[e.targetCard]?.name}` : null,
		e.action ? _(e.action) : null,
		e.page === void 0 ? null : r("games.vantage.powerPage", { n: e.page }),
		e.skill ? r(Q[e.skill]) : null,
		e.face ? r(Q[e.face]) : null,
		e.faces ? e.faces.map((e) => r(Q[e])).join(" · ") : null,
		e.skillFaces ? e.skillFaces.map((e) => r(Q[e])).join(" · ") : null,
		e.sentientInteraction === void 0 ? null : r(e.sentientInteraction ? "games.vantage.switchSentientYes" : "games.vantage.switchSentientNo"),
		e.sourceSlot === void 0 ? null : r("games.vantage.sourceSlot", { n: e.sourceSlot + 1 }),
		e.cell === void 0 ? null : r("games.vantage.powerCell", { n: e.cell + 1 }),
		e.die === void 0 ? null : r("games.vantage.selectedDie", { n: e.die + 1 }),
		e.slot === void 0 ? null : r("games.vantage.slot", { n: e.slot + 1 })
	].filter(Boolean).join(" · ");
	return /* @__PURE__ */ f("details", {
		className: "vantage-printed-power",
		children: [
			/* @__PURE__ */ f("summary", { children: [
				r(`games.vantage.printed_${g.op}`),
				" · ",
				r("games.vantage.powerBoostPrice", { n: g.boostCost ?? Si(g.card, g.op) })
			] }),
			g.op === "revealCard" ? /* @__PURE__ */ f("label", { children: [r("games.vantage.powerCardNumber"), /* @__PURE__ */ d("input", {
				type: "number",
				min: 0,
				max: 1708,
				value: u,
				onChange: (e) => p(Number(e.target.value))
			})] }) : e.length > 1 ? /* @__PURE__ */ f("label", { children: [r("games.vantage.powerChoice"), /* @__PURE__ */ d("select", {
				value: JSON.stringify(g),
				onChange: (e) => s(e.target.value),
				children: e.map((e) => /* @__PURE__ */ d("option", {
					value: JSON.stringify(e),
					children: v(e)
				}, JSON.stringify(e)))
			})] }) : v(g) ? /* @__PURE__ */ d("p", { children: v(g) }) : null,
			g.condition && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: m,
				onChange: (e) => h(e.target.checked)
			}), r(g.op === "signalView" ? "games.vantage.confirmOutdoors" : g.op === "awakenTree" ? "games.vantage.confirmTrees" : g.op === "transformCard" ? "games.vantage.confirmTransformationCondition" : g.op === "finishSwitch" ? "games.vantage.confirmSelectedActionCondition" : g.op === "hookCost" || g.op === "hookDiscount" ? "games.vantage.confirmHookInteraction" : g.card === 1370 ? "games.vantage.confirmPowerSentient" : g.card === 1378 ? "games.vantage.confirmPowerAnimal" : "games.vantage.confirmFloraInteraction")] }),
			/* @__PURE__ */ d("button", {
				disabled: !!g.condition && !m || g.op === "revealCard" && (!Number.isInteger(u) || u < 0 || u > 1708),
				onClick: () => n(g.op === "revealCard" ? {
					...g,
					targetCard: u
				} : g.condition ? {
					...g,
					condition: m
				} : g),
				children: r("games.vantage.activatePrintedPower")
			})
		]
	});
}
function is({ priv: e, nameOf: t, send: n, preview: r }) {
	let i = l(), a = e.printedPowerOptions.filter((e) => ts.includes(e.op));
	return !a.length && !e.sharedLocations.length && e.revealedCard === null ? null : /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			[...new Set(a.map((e) => e.op))].map((e) => /* @__PURE__ */ d(rs, {
				options: a.filter((t) => t.op === e),
				nameOf: t,
				send: n
			}, e)),
			e.sharedLocations.map(({ rid: e, location: n }) => /* @__PURE__ */ d("p", { children: i("games.vantage.knownSharedLocation", {
				name: t(e),
				n
			}) }, e)),
			e.revealedCard !== null && /* @__PURE__ */ d("button", {
				onClick: () => r(e.revealedCard),
				children: i("games.vantage.viewRevealedCard", { n: e.revealedCard })
			})
		]
	});
}
//#endregion
//#region src/games/vantage/item-controls.tsx
function as({ value: e, change: t }) {
	let n = l();
	return /* @__PURE__ */ f("label", {
		className: "vantage-condition",
		children: [n("games.vantage.sentientInteractionQuestion"), /* @__PURE__ */ f("select", {
			value: e,
			onChange: (e) => t(e.target.value),
			children: [
				/* @__PURE__ */ d("option", {
					value: "",
					disabled: !0,
					children: n("games.vantage.chooseInteraction")
				}),
				/* @__PURE__ */ d("option", {
					value: "yes",
					children: n("games.vantage.sentientInteractionYes")
				}),
				/* @__PURE__ */ d("option", {
					value: "no",
					children: n("games.vantage.sentientInteractionNo")
				})
			]
		})]
	});
}
function os({ pub: e, priv: t, me: n, send: r }) {
	let i = l();
	if ([
		"landing",
		"experience",
		"done"
	].includes(e.phase)) return null;
	let a = e.cardsPending || !!e.skillRollPlayer || !!e.gamblePlayer, o = [
		"action",
		"cost",
		"dice",
		"story",
		"skirm",
		"arrival"
	].includes(e.phase) && !(e.active === n.rid && t.current?.id.startsWith("d")), s = n.grid.find((e) => e?.card === 948), c = n.grid.find((e) => e?.card === 1013), u = n.grid.find((e) => e?.card === 1088), p = n.grid.flatMap((e) => e && Ce[e.card] ? [e] : []);
	if (!s && !c && !u && !p.length) return null;
	let m = [...new Set(Object.values(E[t.location].exits).flatMap((e) => e.destination ? [e.destination] : []))];
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			/* @__PURE__ */ d("h2", { children: i("games.vantage.itemPowers") }),
			p.map((e) => /* @__PURE__ */ d("button", {
				disabled: a || e.boost < 2,
				onClick: () => r({
					type: "tameAnimal",
					card: e.card
				}),
				children: i("games.vantage.tameAnimal", { n: e.card })
			}, e.card)),
			s && /* @__PURE__ */ f("details", { children: [/* @__PURE__ */ d("summary", { children: i("games.vantage.transducer") }), /* @__PURE__ */ f("div", {
				className: "vantage-power-options",
				children: [
					e.active === n.rid && e.phase === "dice" && e.challenge?.dice.map((e, t) => e !== null && /* @__PURE__ */ d("button", {
						disabled: a || s.boost < 2,
						onClick: () => r({
							type: "itemPower",
							card: 948,
							power: "refresh",
							die: t,
							condition: !1
						}),
						children: i("games.vantage.transducerRefreshUnplaced", { n: t + 1 })
					}, "die" + t)),
					n.grid.flatMap((e) => e ? Object.keys(e.dice).map((t) => /* @__PURE__ */ d("button", {
						disabled: a || s.boost < 2,
						onClick: () => r({
							type: "itemPower",
							card: 948,
							power: "refresh",
							targetCard: e.card,
							slot: Number(t),
							condition: !1
						}),
						children: i("games.vantage.transducerRefreshPlaced", {
							n: e.card,
							slot: Number(t) + 1
						})
					}, e.card + ":" + t)) : []),
					/* @__PURE__ */ d("button", {
						disabled: a || s.boost < 3,
						onClick: () => r({
							type: "itemPower",
							card: 948,
							power: "neighbors",
							condition: !1
						}),
						children: i("games.vantage.transducerNeighbors")
					})
				]
			})] }),
			c && /* @__PURE__ */ f("details", { children: [/* @__PURE__ */ d("summary", { children: i("games.vantage.turtaxi") }), /* @__PURE__ */ d("div", {
				className: "vantage-power-options",
				children: m.map((e) => /* @__PURE__ */ d("button", {
					disabled: a || c.boost < 1 || !o,
					onClick: () => r({
						type: "itemPower",
						card: 1013,
						power: "ride",
						targetCard: e,
						condition: !1
					}),
					children: i("games.vantage.turtaxiRide", { n: e })
				}, e))
			})] }),
			u && /* @__PURE__ */ f("details", { children: [/* @__PURE__ */ d("summary", { children: i("games.vantage.sawAxe") }), /* @__PURE__ */ d("div", {
				className: "vantage-power-options",
				children: /* @__PURE__ */ d("button", {
					disabled: a || u.boost < 2,
					onClick: () => r({
						type: "itemPower",
						card: 1088,
						power: "help",
						condition: !1
					}),
					children: i("games.vantage.axeHelp")
				})
			})] })
		]
	});
}
//#endregion
//#region src/games/vantage/animal-controls.tsx
function ss(e) {
	let t = l(), n = e.me.grid.flatMap((e) => e && Kr[e.card] ? [e] : []);
	return !n.length || [
		"launch",
		"landing",
		"experience",
		"done"
	].includes(e.pub.phase) ? null : /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [/* @__PURE__ */ d("h2", { children: t("games.vantage.animalPowers") }), n.map((t) => /* @__PURE__ */ d(cs, {
			...e,
			card: t.card
		}, t.card))]
	});
}
function cs({ pub: e, priv: t, me: n, send: r, card: a }) {
	let o = l(), s = c((e) => e.locale), [p, m] = i(!1), [h, g] = i([]), [_, v] = i({}), { kind: y, cost: b } = Kr[a], x = n.grid.find((e) => e?.card === a), S = e.active === n.rid, C = S && e.phase === "dice" ? e.challenge?.dice ?? [] : [], w = x.boost < b || e.cardsPending || !!e.skillRollPlayer || !!e.gamblePlayer || !!e.replenishment, T = s === "zh" ? E[a].nameZh : E[a].name, D = [
		"action",
		"cost",
		"dice",
		"story",
		"skirm",
		"arrival"
	].includes(e.phase) && !(S && t.current?.id.startsWith("d")), O = (e, t, n = {}, i = !1, o) => /* @__PURE__ */ d("button", {
		disabled: w || i,
		onClick: () => {
			r({
				type: "animalPower",
				card: a,
				power: e,
				condition: p,
				indices: [],
				centerIndices: [],
				...n
			}), m(!1), g([]), v({});
		},
		children: t
	}, o ?? e), ee = (e) => /* @__PURE__ */ f("label", {
		className: "vantage-condition",
		children: [/* @__PURE__ */ d("input", {
			type: "checkbox",
			checked: p,
			onChange: (e) => m(e.target.checked)
		}), e]
	}), te = (e) => o(Q[{
		N: "north",
		E: "east",
		S: "south",
		W: "west",
		"north (or northwest)": "northOrNorthwest"
	}[e] ?? e]);
	return /* @__PURE__ */ f("details", { children: [
		/* @__PURE__ */ f("summary", { children: [
			a,
			" · ",
			T,
			" · ",
			o("games.vantage.powerBoostPrice", { n: b })
		] }),
		/* @__PURE__ */ f("div", {
			className: "vantage-power-options",
			children: [
				y === "scout" && /* @__PURE__ */ f(u, { children: [qr(t.location).map((e) => O("scout", o("games.vantage.sentientScout", { n: e }), { targetCard: e }, t.scouted.includes(e), e)), O("costs", o("games.vantage.animalScoutCosts"), {}, !Jr(t.location).some((e) => !t.revealedCosts.some((t) => t.id === e)))] }),
				[
					"land",
					"tunnel",
					"waterRide"
				].includes(y) && /* @__PURE__ */ f(u, { children: [
					y !== "tunnel" && ee(o(y === "land" ? "games.vantage.confirmAnimalLand" : "games.vantage.confirmAnimalRideTerrain")),
					Xr(a, t.location).map((e) => O("ride", o("games.vantage.animalRide", { n: e }), { targetCard: e }, !D || y !== "tunnel" && !p, e)),
					Yr(t.location).map((e) => O("ride", o("games.vantage.animalRideUnlisted", { direction: te(e.direction) }), { action: e.id }, !D || y !== "tunnel" && !p, e.id))
				] }),
				y === "fly" && O("fly", o("games.vantage.dragonFlightPower"), {}, !D || On(t.location) === null),
				(y === "health" || y === "morale") && O("ignore", o("games.vantage.animalIgnore", { face: o(Q[y]) }), {}, t.animalProtection.includes(y)),
				(y === "cold" || y === "hypoxia") && O("climate", o("games.vantage.animalClimate", { kind: o(Q[y]) }), {}, t.animalProtection.includes(y)),
				y === "fetch" && O("fetch", o("games.vantage.animalFetch"), {}, !S || e.phase !== "cost" || e.challenge?.skill !== "take" || t.current?.source !== t.location || !mr(t.location) || e.challenge.cost === 0),
				y === "plunder" && Zr(t.location).map((e) => O("plunder", o("games.vantage.animalPlunder", { n: e }), { targetCard: e }, !1, e)),
				y === "charm" && C.some((e) => e !== null) && /* @__PURE__ */ f(u, { children: [
					ee(o("games.vantage.confirmAnimalInteraction")),
					/* @__PURE__ */ d("div", {
						className: "vantage-skill-row",
						children: C.map((e, t) => e !== null && /* @__PURE__ */ f("label", { children: [
							/* @__PURE__ */ d("input", {
								type: "checkbox",
								checked: h.includes(t),
								onChange: (e) => g(e.target.checked ? [...h, t] : h.filter((e) => e !== t))
							}),
							t + 1,
							" · ",
							/* @__PURE__ */ d($, { kind: e }),
							o(Q[e])
						] }, t))
					}),
					O("charm", o("games.vantage.animalCharm", { n: h.length }), { indices: h }, !p || !h.length || h.length > 2 || h.some((e) => C[e] == null))
				] }),
				y === "revive" && C.some((e) => e !== null) && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("div", {
					className: "vantage-power-options",
					children: C.map((t, n) => t !== null && /* @__PURE__ */ f("label", { children: [
						n + 1,
						" · ",
						/* @__PURE__ */ d($, { kind: t }),
						o(Q[t]),
						/* @__PURE__ */ f("select", {
							value: _[n] ?? -1,
							onChange: (e) => {
								let t = { ..._ };
								e.target.value === "-1" ? delete t[n] : t[n] = Number(e.target.value), v(t);
							},
							children: [/* @__PURE__ */ d("option", {
								value: -1,
								children: o("games.vantage.keepDie")
							}), e.penaltyFaces.map((e, t) => e !== null && /* @__PURE__ */ d("option", {
								value: t,
								children: o("games.vantage.centerDieFace", {
									n: t + 1,
									face: o(Q[e])
								})
							}, t))]
						})
					] }, n))
				}), O("revive", o("games.vantage.animalRevive", { n: Object.keys(_).length }), {
					indices: Object.keys(_).map(Number),
					centerIndices: Object.values(_)
				}, !Object.keys(_).length || Object.keys(_).length > 3 || new Set(Object.values(_)).size !== Object.keys(_).length || Object.keys(_).some((e) => C[Number(e)] == null))] })
			]
		}),
		/* @__PURE__ */ d(Jo, { card: a })
	] });
}
//#endregion
//#region src/games/vantage/character-powers.tsx
function ls({ pub: e, priv: t, me: n, selectedDie: r, send: a }) {
	let o = l(), s = c((e) => e.locale), [u, p] = i(""), m = me(n.character), h = M(n);
	if (n.character === 1453 && e.active === n.rid && e.phase === "dice") return /* @__PURE__ */ d("div", {
		className: "vantage-character-powers",
		children: /* @__PURE__ */ d("button", {
			disabled: !t.canUndoAction || e.cardsPending || !!e.skillRollPlayer || (n.grid[4]?.boost ?? 0) < 3,
			onClick: () => a({
				type: "characterPower",
				power: "undo"
			}),
			children: o("games.vantage.rebornUndo")
		})
	});
	if (m === "starting" || m === "other" || e.active !== n.rid || e.phase === "landing" || e.phase === "experience") return null;
	let g = e.cardsPending || !!e.skillRollPlayer || !!e.gamblePlayer || (n.grid[4]?.boost ?? 0) < 1;
	return /* @__PURE__ */ f("div", {
		className: "vantage-character-powers",
		children: [
			h === 0 && n.grid.filter((e) => e && e.boost < E[e.card].boostCapacity).map((e) => e && /* @__PURE__ */ d("button", {
				disabled: g,
				onClick: () => a({
					type: "characterPower",
					power: "boost",
					card: e.card
				}),
				children: o("games.vantage.characterBoost", { n: e.card })
			}, e.card)),
			h === 1 && /* @__PURE__ */ d("button", {
				disabled: g,
				onClick: () => a({
					type: "characterPower",
					power: "skill"
				}),
				children: o("games.vantage.characterSkill")
			}),
			h === 2 && t.powerOptions.length > 0 && /* @__PURE__ */ f("details", { children: [
				/* @__PURE__ */ d("summary", { children: o("games.vantage.switchAction") }),
				t.powerOptions.some((t) => Wr(n, t.id, D[t.id]?.card ?? 0, e.mission === 1593 && !e.missionDone)) && /* @__PURE__ */ d(as, {
					value: u,
					change: p
				}),
				t.powerOptions.map((r) => /* @__PURE__ */ d("button", {
					disabled: g || Number(t.current?.cost) < 0 || Wr(n, r.id, D[r.id]?.card ?? 0, e.mission === 1593 && !e.missionDone) && !u,
					onClick: () => {
						a({
							type: "characterPower",
							power: "switch",
							action: r.id,
							sentientInteraction: u ? u === "yes" : void 0
						}), p("");
					},
					children: s === "zh" && r.labelZh ? r.labelZh : r.label
				}, r.id))
			] }),
			h === 3 && n.grid.filter((e) => e && e.card !== n.character).flatMap((e) => e ? Object.keys(e.dice).map((t) => /* @__PURE__ */ d("button", {
				disabled: g,
				onClick: () => a({
					type: "characterPower",
					power: "refreshPlaced",
					card: e.card,
					slot: Number(t)
				}),
				children: o("games.vantage.characterRefreshPlaced", {
					n: e.card,
					slot: Number(t) + 1
				})
			}, e.card + ":" + t)) : []),
			h === 4 && /* @__PURE__ */ d("button", {
				disabled: g,
				onClick: () => a({
					type: "characterPower",
					power: "blankSetbacks"
				}),
				children: o("games.vantage.characterBlank")
			}),
			h === 5 && m === "survivor" && e.phase === "dice" && r !== null && e.challenge?.dice[r] != null && /* @__PURE__ */ d("button", {
				disabled: g,
				onClick: () => a({
					type: "characterPower",
					power: "ignore",
					die: r
				}),
				children: o("games.vantage.characterIgnore")
			}),
			h === 5 && m === "armor" && e.phase === "cost" && /* @__PURE__ */ d("button", {
				disabled: g || Number(t.current?.cost) < 0,
				onClick: () => a({
					type: "characterPower",
					power: "increase"
				}),
				children: o("games.vantage.characterIncrease")
			})
		]
	});
}
//#endregion
//#region src/games/vantage/story-test.tsx
function us({ priv: e, me: t, rolling: n, send: r }) {
	let a = l(), o = e.storyTest, [s, c] = i([]);
	if (!o) return null;
	let p = t.grid.find((e) => e?.card === o.source);
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		role: "status",
		children: [
			/* @__PURE__ */ d("h2", { children: a("games.vantage.storySkillTest") }),
			/* @__PURE__ */ d("p", { children: o.repeatSkill ? a("games.vantage.repeatSkillTest", {
				n: Math.max(1, o.rounds),
				count: o.count,
				skill: a(Q[o.repeatSkill])
			}) : a("games.vantage.storyTestRound", {
				n: o.rounds,
				max: o.maxRolls,
				count: o.count
			}) }),
			/* @__PURE__ */ d("div", {
				className: "vantage-skill-row",
				children: o.faces.map((e, t) => /* @__PURE__ */ f("span", { children: [
					!o.done && o.partialRounds > 0 && /* @__PURE__ */ d("input", {
						type: "checkbox",
						"aria-label": a("games.vantage.selectTestDie", { n: t + 1 }),
						checked: s.includes(t),
						disabled: n || o.remaining > 0,
						onChange: (e) => c(e.target.checked ? [...s, t] : s.filter((e) => e !== t))
					}),
					/* @__PURE__ */ d($, { kind: e }),
					a(Q[e]),
					o.rerollable.includes(t) && /* @__PURE__ */ d("button", {
						disabled: n || o.remaining > 0,
						onClick: () => r({
							type: "storyTest",
							op: "reroll",
							die: t
						}),
						children: a("games.vantage.storyTestRerollOne")
					})
				] }, t))
			}),
			!o.done && /* @__PURE__ */ f(u, { children: [
				!o.rounds && o.paySkills.map((e) => /* @__PURE__ */ d("button", {
					disabled: n || t.skills[e] < 1,
					onClick: () => r({
						type: "storyTest",
						op: "skill",
						skill: e
					}),
					children: a("games.vantage.storyTestPaySkill", { skill: a(Q[e]) })
				}, e)),
				!o.rounds && o.bait && !o.baitUsed && t.grid.filter((e) => e && e.boost > 0 && (P(e.card, "food") || P(e.card, "flora"))).map((e) => e && /* @__PURE__ */ d("button", {
					disabled: n,
					onClick: () => r({
						type: "storyTest",
						op: "bait",
						card: e.card
					}),
					children: a("games.vantage.storyTestBait", { n: e.card })
				}, e.card)),
				!o.rounds && o.sourceBoost && p && p.boost > 0 && /* @__PURE__ */ d("button", {
					disabled: n,
					onClick: () => r({
						type: "storyTest",
						op: "boost",
						card: p.card
					}),
					children: a("games.vantage.storyTestExtra", { n: p.card })
				}),
				/* @__PURE__ */ d("button", {
					disabled: n || o.remaining > 0 || !o.repeatSkill && o.rounds >= o.maxRolls,
					onClick: () => r({
						type: "storyTest",
						op: "roll"
					}),
					children: a(o.repeatSkill && o.rounds ? "games.vantage.repeatSkillNext" : o.rounds ? "games.vantage.storyTestReroll" : "games.vantage.storyTestRoll", { n: o.count })
				}),
				o.rounds > 0 && o.partialRounds > 0 && /* @__PURE__ */ d("button", {
					disabled: n || o.remaining > 0 || !s.length,
					onClick: () => {
						r({
							type: "storyTest",
							op: "partial",
							indices: s
						}), c([]);
					},
					children: a("games.vantage.rerollSelectedTestDice", { n: o.partialRounds })
				}),
				o.rounds > 0 && !o.repeatSkill && /* @__PURE__ */ d("button", {
					disabled: n || o.remaining > 0,
					onClick: () => r({
						type: "storyTest",
						op: "keep"
					}),
					children: a("games.vantage.storyTestKeep")
				})
			] }),
			o.done && /* @__PURE__ */ d("p", { children: o.repeatSkill ? a("games.vantage.repeatSkillComplete", { skill: a(Q[o.repeatSkill]) }) : a("games.vantage.storyTestFinal") })
		]
	});
}
//#endregion
//#region src/games/vantage/race-panel.tsx
var ds = [
	"#3a7cbe",
	"#a362aa",
	"#dc8c44",
	"#719d54",
	"#d6b23d",
	"#bc554c"
];
function fs({ game: e, waiting: t, send: n }) {
	let r = l(), [a, o] = i(null), s = e.activeRacer !== null && dt(e.racers, e.activeRacer).length > 0 ? e.activeRacer : a ?? e.activeRacer, c = No("games/vantage/live/cards/540.webp"), p = (t) => e.tokens[t] > 0 && !e.used.includes(t) && (e.activeRacer === null || t === e.activeRacer || !dt(e.racers, e.activeRacer).length), m = s !== null && p(s) ? dt(e.racers, s) : [];
	return /* @__PURE__ */ f(u, { children: [
		/* @__PURE__ */ d("p", { children: r("games.vantage.raceInstructions") }),
		/* @__PURE__ */ d("p", { children: r("games.vantage.raceYourToken", { skill: r(Q[C[e.variant]]) }) }),
		!c.url && /* @__PURE__ */ d(Po, {
			failed: c.failed,
			retry: c.retry
		}),
		/* @__PURE__ */ f("svg", {
			className: "vantage-race-map",
			viewBox: "0 0 750 500",
			role: "img",
			"aria-label": r("games.vantage.raceBoard"),
			children: [
				/* @__PURE__ */ d("image", {
					href: c.url,
					width: 750,
					height: 500
				}),
				ct.map(([e, t], n) => /* @__PURE__ */ f("g", { children: [/* @__PURE__ */ d("circle", {
					cx: e,
					cy: t,
					r: m.includes(n) ? 14 : 10,
					fill: m.includes(n) ? "#fff4b2" : "#fff8",
					stroke: "#183946",
					strokeWidth: m.includes(n) ? 3 : 1
				}), /* @__PURE__ */ d("text", {
					x: e,
					y: t + 4,
					textAnchor: "middle",
					fontSize: 10,
					fill: "#163846",
					children: n + 1
				})] }, n)),
				e.racers.map((t, n) => {
					let [r, i] = ct[t] ?? [665, 65];
					return /* @__PURE__ */ f("g", { children: [/* @__PURE__ */ d("circle", {
						cx: r,
						cy: i,
						r: 13,
						fill: ds[n],
						stroke: n === e.variant ? "#fff" : "#142d38",
						strokeWidth: n === e.variant ? 4 : 2
					}), /* @__PURE__ */ d("text", {
						x: r,
						y: i + 4,
						textAnchor: "middle",
						fill: "#fff",
						fontSize: 11,
						children: n + 1
					})] }, n);
				})
			]
		}),
		/* @__PURE__ */ d("div", {
			className: "vantage-skill-row",
			children: e.dice.map((e, t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: e }), r(Q[e])] }, t))
		}),
		!e.done && /* @__PURE__ */ d("div", {
			className: "vantage-trial-actions",
			children: e.stage === "round" ? /* @__PURE__ */ d("button", {
				disabled: !c.url || t,
				onClick: () => {
					o(null), n({
						type: "miniGame",
						op: "keep",
						indices: []
					});
				},
				children: r("games.vantage.confirmRoll")
			}) : /* @__PURE__ */ f(u, { children: [
				C.map((n, i) => /* @__PURE__ */ f("button", {
					disabled: !c.url || t || !p(i),
					"data-selected": s === i,
					onClick: () => o(i),
					children: [/* @__PURE__ */ d($, { kind: n }), r("games.vantage.racerMoves", {
						skill: r(Q[n]),
						n: e.tokens[i]
					})]
				}, n)),
				m.map((e) => /* @__PURE__ */ d("button", {
					disabled: !c.url || t,
					onClick: () => n({
						type: "miniGame",
						op: "place",
						indices: [],
						racer: s,
						cell: e
					}),
					children: r(e === 25 ? "games.vantage.crossFinish" : "games.vantage.moveToRaceCell", { n: e + 1 })
				}, e)),
				s !== null && p(s) && !m.length && /* @__PURE__ */ d("button", {
					disabled: !c.url || t,
					onClick: () => {
						n({
							type: "miniGame",
							op: "skip",
							indices: [],
							racer: s
						}), o(null);
					},
					children: r("games.vantage.racerBlocked")
				}),
				e.tokens.every((e) => e === 0) && /* @__PURE__ */ d("button", {
					disabled: !c.url || t,
					onClick: () => {
						o(null), n({
							type: "miniGame",
							op: "advance",
							indices: []
						});
					},
					children: r("games.vantage.nextRaceRound")
				})
			] })
		})
	] });
}
//#endregion
//#region src/games/vantage/stored-skill-bonus.tsx
function ps({ skills: e }) {
	let t = l();
	return e?.length ? /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("h3", { children: t("games.vantage.countedStoredSkills") }), /* @__PURE__ */ d("div", {
		className: "vantage-skill-row",
		children: e.map((e, n) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: e }), t(Q[e])] }, n))
	})] }) : null;
}
//#endregion
//#region src/games/vantage/advanced-mini-panel.tsx
var ms = {
	race: "games.vantage.trialRace",
	trade: "games.vantage.trialTrade",
	mancala: "games.vantage.trialMancala",
	tournament: "games.vantage.trialTournament",
	arena: "games.vantage.trialArena",
	perfecto: "games.vantage.perfecto",
	pinch: "games.vantage.pinch",
	press: "games.vantage.press",
	punch: "games.vantage.punch"
}, hs = {
	race: "games.vantage.raceInstructions",
	trade: "games.vantage.tradeInstructions",
	mancala: "games.vantage.mancalaInstructions",
	tournament: "games.vantage.tournamentInstructions",
	arena: "games.vantage.arenaInstructions",
	perfecto: "games.vantage.perfectoInstructions",
	pinch: "games.vantage.pinchInstructions",
	press: "games.vantage.pressInstructions",
	punch: "games.vantage.punchInstructions"
}, gs = [
	"games.vantage.tokenBlue",
	"games.vantage.tokenPurple",
	"games.vantage.tokenOrange",
	"games.vantage.tokenGreen",
	"games.vantage.tokenYellow",
	"games.vantage.tokenRed"
];
function _s({ game: e, coins: t, waiting: n, send: r }) {
	let a = l(), [o, s] = i([]), [c, p] = i(1), [m, h] = i({}), g = (e, t = {}) => {
		r({
			type: "miniGame",
			op: e,
			indices: [],
			...t
		}), s([]);
	}, _ = (e, t) => /* @__PURE__ */ d("span", {
		className: `vantage-trade-token vantage-trade-${e}`,
		children: a(gs[C.indexOf(e)])
	}, t), v = (e, t = !1) => /* @__PURE__ */ d("div", {
		className: "vantage-skill-row",
		children: e.map((e, r) => /* @__PURE__ */ f("label", { children: [
			t && /* @__PURE__ */ d("input", {
				type: "checkbox",
				"aria-label": a("games.vantage.selectTestDie", { n: r + 1 }),
				checked: o.includes(r),
				disabled: n,
				onChange: (e) => s(e.target.checked ? [...o, r] : o.filter((e) => e !== r))
			}),
			/* @__PURE__ */ d($, { kind: e }),
			a(Q[e])
		] }, r))
	}), y = e.kind, b = e.kind === "tournament" ? 8 : 6, x = Array.from({ length: b }, (e, t) => m[t] ?? 0), S = x.reduce((e, t) => e + t, 0);
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper vantage-trial",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ d("h2", { children: a(ms[y]) }),
			/* @__PURE__ */ d(ps, { skills: e.bonusSkills }),
			e.kind === "race" ? /* @__PURE__ */ d(fs, {
				game: e,
				waiting: n,
				send: r
			}) : /* @__PURE__ */ d("p", { children: a(hs[y]) }),
			e.done && /* @__PURE__ */ d("p", { children: a(e.kind === "tournament" && !e.variant ? "games.vantage.tournamentComplete" : e.success ? "games.vantage.trialSucceeded" : "games.vantage.trialFailed") }),
			(e.kind === "perfecto" || e.kind === "pinch" || e.kind === "press" || e.kind === "punch" || e.kind === "tournament" && !e.variant) && /* @__PURE__ */ d("p", { children: a(e.done ? "games.vantage.finalMiniCoins" : "games.vantage.pendingMiniCoins", { n: e.coins }) }),
			e.kind === "trade" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("h3", { children: a("games.vantage.merchantName", { name: a([
					"games.vantage.merchantMinic",
					"games.vantage.merchantBastia",
					"games.vantage.merchantLak"
				][e.merchant]) }) }),
				/* @__PURE__ */ d("div", {
					className: "vantage-token-stock",
					children: C.map((t, n) => /* @__PURE__ */ f("span", { children: [_(t, n), /* @__PURE__ */ d("b", { children: e.tokens[n] })] }, t))
				}),
				!e.done && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("div", {
					className: "vantage-trade-sections",
					children: it[e.merchant].map((t, r) => /* @__PURE__ */ f("fieldset", { children: [/* @__PURE__ */ d("legend", { children: a("games.vantage.tradeSection", { n: r + 1 }) }), t.map((t, i) => /* @__PURE__ */ f("button", {
						disabled: n || e.used.includes(r) || !at(e.tokens, t),
						onClick: () => g("trade", {
							section: r,
							option: i
						}),
						children: [
							/* @__PURE__ */ d("span", { children: t.give.map(_) }),
							/* @__PURE__ */ d("b", {
								"aria-label": a("games.vantage.exchangeFor"),
								children: "→"
							}),
							/* @__PURE__ */ d("span", { children: t.emblem ? a("games.vantage.goldEmblem") : t.take.map(_) })
						]
					}, i))] }, r))
				}), /* @__PURE__ */ f("div", {
					className: "vantage-trial-actions",
					children: [/* @__PURE__ */ d("button", {
						disabled: n,
						onClick: () => g("advance"),
						children: a(e.merchant === 2 ? "games.vantage.finishTrial" : "games.vantage.nextMerchant")
					}), /* @__PURE__ */ d("button", {
						disabled: n,
						onClick: () => g("stop"),
						children: a("games.vantage.endTrial")
					})]
				})] })
			] }),
			e.kind === "mancala" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("p", { children: a("games.vantage.timeCubes", { n: e.remaining }) }),
				/* @__PURE__ */ d("div", {
					className: "vantage-mancala",
					children: e.pots.map((t, r) => /* @__PURE__ */ f("div", {
						className: "vantage-mancala-pot",
						"data-current": e.carry.length > 0 && e.pot === r,
						style: {
							gridColumn: [
								2,
								3,
								4,
								3,
								2,
								1
							][r],
							gridRow: [
								1,
								1,
								2,
								3,
								3,
								2
							][r]
						},
						children: [
							/* @__PURE__ */ d("b", { children: r + 1 }),
							v(t.map((t) => e.dice[t])),
							/* @__PURE__ */ d("button", {
								disabled: n || e.done || e.carry.length > 0 || !t.length || !e.remaining,
								onClick: () => g("pick", { section: r }),
								children: a("games.vantage.pickCircle", { n: r + 1 })
							})
						]
					}, r))
				}),
				!e.done && /* @__PURE__ */ d("div", {
					className: "vantage-trial-actions",
					children: e.carry.length > 0 ? /* @__PURE__ */ f(u, { children: [
						/* @__PURE__ */ d("p", { children: a("games.vantage.dropCircle", { n: e.pot + 1 }) }),
						e.carry.filter((t, n, r) => r.findIndex((n) => e.dice[n] === e.dice[t]) === n).map((t) => /* @__PURE__ */ f("button", {
							disabled: n,
							onClick: () => g("drop", { die: t }),
							children: [/* @__PURE__ */ d($, { kind: e.dice[t] }), a("games.vantage.dropSkillDie", { skill: a(Q[e.dice[t]]) })]
						}, t)),
						/* @__PURE__ */ d("button", {
							disabled: n || !e.pots[e.pot].length || !e.pots[e.pot].every((t) => e.dice[t] === e.dice[e.pots[e.pot][0]]),
							onClick: () => g("skip"),
							children: a("games.vantage.skipPureCircle")
						})
					] }) : /* @__PURE__ */ d("button", {
						disabled: n || !_t(e),
						onClick: () => g("keep"),
						children: a("games.vantage.completeArrangement")
					})
				})
			] }),
			e.stage === "bet" && (e.kind === "perfecto" || e.kind === "press") && /* @__PURE__ */ f("div", {
				className: "vantage-trial-actions",
				children: [/* @__PURE__ */ f("label", { children: [a("games.vantage.betCoins"), /* @__PURE__ */ d("input", {
					type: "number",
					min: 1,
					max: Math.min(t, e.kind === "perfecto" ? 6 : 5),
					value: c,
					onChange: (e) => p(Number(e.target.value))
				})] }), /* @__PURE__ */ d("button", {
					disabled: n || !Number.isInteger(c) || c < 1 || c > t || c > (e.kind === "perfecto" ? 6 : 5),
					onClick: () => g("bet", { amount: c }),
					children: a("games.vantage.confirmBet")
				})]
			}),
			e.stage === "bet" && (e.kind === "punch" || e.kind === "tournament") && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("div", {
					className: "vantage-bet-grid",
					children: x.map((t, n) => /* @__PURE__ */ f("label", { children: [e.kind === "punch" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d($, { kind: C[n] }), a(Q[C[n]])] }) : a("games.vantage.fighterOdds", {
						n: n + 1,
						strength: ht[n],
						multiplier: gt[n]
					}), /* @__PURE__ */ d("input", {
						type: "number",
						min: 0,
						max: 3,
						value: t,
						onChange: (e) => h({
							...m,
							[n]: Number(e.target.value)
						})
					})] }, n))
				}),
				/* @__PURE__ */ d("p", { children: a("games.vantage.totalBet", {
					n: S,
					coins: t
				}) }),
				/* @__PURE__ */ d("button", {
					disabled: n || x.some((e) => !Number.isInteger(e) || e < 0 || e > 3) || S > t || e.kind === "punch" && S < 1,
					onClick: () => g("bet", { bets: x }),
					children: a("games.vantage.confirmBet")
				})
			] }),
			e.kind === "tournament" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("p", { children: a("games.vantage.trialRound", { n: e.round }) }),
				e.stage === "round" && /* @__PURE__ */ f(u, { children: [
					/* @__PURE__ */ d("h3", { children: a("games.vantage.currentBout", {
						a: e.fighters[e.match * 2] + 1,
						b: e.fighters[e.match * 2 + 1] + 1
					}) }),
					v(e.dice),
					v(e.enemy)
				] }),
				/* @__PURE__ */ d("ol", {
					className: "vantage-bout-results",
					children: e.results.map((e, t) => /* @__PURE__ */ d("li", { children: a("games.vantage.boutResult", {
						a: e.a + 1,
						b: e.b + 1,
						winner: e.winner + 1
					}) }, t))
				}),
				!e.done && e.stage !== "bet" && /* @__PURE__ */ d("button", {
					disabled: n,
					onClick: () => g(e.stage === "round" ? "keep" : "advance"),
					children: a(e.stage === "round" ? "games.vantage.confirmBout" : "games.vantage.rollBout")
				})
			] }),
			[
				"perfecto",
				"press",
				"punch",
				"pinch",
				"arena"
			].includes(e.kind) && e.stage !== "bet" && /* @__PURE__ */ f(u, { children: [
				v(e.dice, !e.done && e.stage === "choose" && (e.kind === "perfecto" || e.kind === "arena")),
				e.kind === "arena" && /* @__PURE__ */ d("p", { children: a("games.vantage.arenaProgress", {
					wins: e.wins,
					damage: e.damage
				}) }),
				e.kind === "perfecto" && /* @__PURE__ */ d("p", { children: a("games.vantage.rerollsRemaining", { n: e.remaining }) }),
				e.kind === "press" && e.done && /* @__PURE__ */ f(u, { children: [
					/* @__PURE__ */ d("h3", { children: a("games.vantage.opponentDice") }),
					v(e.enemy),
					/* @__PURE__ */ d("p", { children: a("games.vantage.pressFinal", {
						mine: e.finalCounts[0],
						enemy: e.finalCounts[1]
					}) })
				] }),
				!e.done && /* @__PURE__ */ f("div", {
					className: "vantage-trial-actions",
					children: [
						e.kind === "perfecto" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
							disabled: n || !e.remaining || !o.length,
							onClick: () => g("reroll", { indices: o }),
							children: a("games.vantage.rerollTrialDice")
						}), /* @__PURE__ */ d("button", {
							disabled: n,
							onClick: () => g("keep"),
							children: a("games.vantage.finishTrial")
						})] }),
						e.kind === "press" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
							disabled: n || e.stage !== "choose",
							onClick: () => g("advance"),
							children: a("games.vantage.rollAnotherDie")
						}), /* @__PURE__ */ d("button", {
							disabled: n,
							onClick: () => g("keep"),
							children: a("games.vantage.compareOpponent")
						})] }),
						e.kind === "punch" && /* @__PURE__ */ d("button", {
							disabled: n,
							onClick: () => g("keep"),
							children: a("games.vantage.finishTrial")
						}),
						e.kind === "pinch" && /* @__PURE__ */ d(u, { children: e.stage === "round" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
							disabled: n,
							onClick: () => g("advance"),
							children: a("games.vantage.rollPinchDice", { n: e.remaining })
						}), /* @__PURE__ */ d("button", {
							disabled: n || e.remaining === 6,
							onClick: () => g("stop"),
							children: a("games.vantage.keepWinnings")
						})] }) : /* @__PURE__ */ d("button", {
							disabled: n,
							onClick: () => g("keep"),
							children: a("games.vantage.confirmRoll")
						}) }),
						e.kind === "arena" && /* @__PURE__ */ d(u, { children: e.stage === "choose" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
							disabled: n || o.length < 1 || o.length > 2 || !o.some((t) => e.dice[t] === "move" && !e.used.includes(t)),
							onClick: () => g("reroll", { indices: o }),
							children: a("games.vantage.rerollTrialDice")
						}), /* @__PURE__ */ d("button", {
							disabled: n,
							onClick: () => g("advance"),
							children: a("games.vantage.confirmBout")
						})] }) : /* @__PURE__ */ d("button", {
							disabled: n,
							onClick: () => g("keep"),
							children: a("games.vantage.nextBout")
						}) })
					]
				})
			] })
		]
	});
}
//#endregion
//#region src/games/vantage/mini-game-panel.tsx
function vs({ game: e, coins: t, waiting: n, send: r }) {
	let a = l(), [o, s] = i([]), c = (e, t = []) => {
		r({
			type: "miniGame",
			op: e,
			indices: t
		}), s([]);
	}, p = {
		poker: "games.vantage.trialPoker",
		hunt: "games.vantage.trialHunt",
		slide: "games.vantage.trialSlide",
		dance: "games.vantage.trialDance"
	}, m = Et(e).filter((t, n, r) => r.findIndex((n) => n.x === t.x && n.y === t.y && e.dice[n.die] === e.dice[t.die]) === n), h = (t, r = !1) => /* @__PURE__ */ d("div", {
		className: "vantage-skill-row",
		children: t.map((t, i) => /* @__PURE__ */ f("label", { children: [
			r && /* @__PURE__ */ d("input", {
				type: "checkbox",
				disabled: n || e.done || e.rerolled && e.kind !== "dance",
				"aria-label": a("games.vantage.selectTestDie", { n: i + 1 }),
				checked: o.includes(i),
				onChange: (e) => s(e.target.checked ? [...o, i] : o.filter((e) => e !== i))
			}),
			/* @__PURE__ */ d($, { kind: t }),
			a(Q[t])
		] }, i))
	});
	return [
		"poker",
		"hunt",
		"slide",
		"dance"
	].includes(e.kind) ? /* @__PURE__ */ f("section", {
		className: "vantage-paper vantage-trial",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ d("h2", { children: a(p[e.kind]) }),
			/* @__PURE__ */ d(ps, { skills: e.bonusSkills }),
			e.done ? /* @__PURE__ */ d("p", { children: a(e.success ? "games.vantage.trialSucceeded" : "games.vantage.trialFailed") }) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("p", { children: a(e.kind === "poker" ? "games.vantage.pokerInstructions" : e.kind === "hunt" ? "games.vantage.huntInstructions" : e.kind === "slide" ? "games.vantage.slideInstructions" : "games.vantage.danceInstructions") }), (e.kind === "poker" || e.kind === "hunt") && /* @__PURE__ */ d("p", { children: a("games.vantage.trialRound", { n: e.round }) })] }),
			e.kind === "poker" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("h3", { children: a("games.vantage.sharedDice") }),
				h(e.shared),
				/* @__PURE__ */ d("h3", { children: a("games.vantage.yourDice") })
			] }),
			e.kind === "slide" ? /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("div", {
					className: "vantage-trial-slide",
					children: e.dice.slice(0, 9).map((e, t) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d($, { kind: e }), /* @__PURE__ */ d("span", { children: a(Q[e]) })] }, t))
				}),
				/* @__PURE__ */ d("p", { children: a("games.vantage.extraDie") }),
				h(e.dice.slice(9)),
				/* @__PURE__ */ d("p", { children: a("games.vantage.waterRemaining", { n: e.remaining }) })
			] }) : h(e.dice, !e.done && (["poker", "hunt"].includes(e.kind) || e.kind === "dance" && e.dice[0] === e.dice[1])),
			e.kind === "hunt" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("h3", { children: a("games.vantage.opponentDice") }),
				h(e.enemy),
				e.done && /* @__PURE__ */ d("p", { children: a("games.vantage.huntFinal", {
					mine: e.finalCounts[0],
					enemy: e.finalCounts[1]
				}) })
			] }),
			e.kind === "poker" && e.done && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("p", { children: a("games.vantage.pokerRank", { n: wt([...e.dice, ...e.shared]) + 1 }) }),
				/* @__PURE__ */ d("h3", { children: a("games.vantage.opponentDice") }),
				h(e.enemy.slice(0, 2)),
				h(e.enemy.slice(2))
			] }),
			e.kind === "dance" && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("div", {
				className: "vantage-dance-board",
				style: { gridTemplateColumns: `repeat(${Math.max(1, ...e.board.map((e) => e.x)) - Math.min(-1, ...e.board.map((e) => e.x)) + 1},minmax(32px,1fr))` },
				children: e.board.map((t, n) => /* @__PURE__ */ f("div", {
					style: {
						gridColumn: t.x - Math.min(-1, ...e.board.map((e) => e.x)) + 1,
						gridRow: t.y - Math.min(-1, ...e.board.map((e) => e.y)) + 1
					},
					children: [/* @__PURE__ */ d("b", { children: n + 1 }), /* @__PURE__ */ d($, { kind: t.face })]
				}, n))
			}), /* @__PURE__ */ d("p", { children: a("games.vantage.danceCount", { n: e.board.length }) })] }),
			!e.done && /* @__PURE__ */ f("div", {
				className: "vantage-trial-actions",
				children: [
					(e.kind === "poker" || e.kind === "hunt" || e.kind === "dance" && e.dice[0] === e.dice[1]) && /* @__PURE__ */ d("button", {
						disabled: n || !o.length || e.rerolled && e.kind !== "dance",
						onClick: () => c("reroll", o),
						children: a("games.vantage.rerollTrialDice")
					}),
					(e.kind === "poker" || e.kind === "hunt") && /* @__PURE__ */ d("button", {
						disabled: n,
						onClick: () => c("advance"),
						children: a(e.round === 3 ? "games.vantage.finishTrial" : "games.vantage.nextTrialRound")
					}),
					e.kind === "slide" && /* @__PURE__ */ f(u, { children: [
						/* @__PURE__ */ d("button", {
							disabled: n || !e.remaining || e.rerolled,
							onClick: () => c("reroll"),
							children: a("games.vantage.rerollExtraDie")
						}),
						[
							0,
							1,
							2
						].map((e) => /* @__PURE__ */ d("div", { children: [
							"E",
							"W",
							"S",
							"N"
						].map((t) => /* @__PURE__ */ d("button", {
							disabled: n,
							onClick: () => r({
								type: "miniGame",
								op: "push",
								indices: [],
								line: e,
								direction: t
							}),
							children: a(t === "E" || t === "W" ? "games.vantage.pushRow" : "games.vantage.pushColumn", {
								n: e + 1,
								direction: a({
									E: "games.vantage.trialEast",
									W: "games.vantage.trialWest",
									N: "games.vantage.trialNorth",
									S: "games.vantage.trialSouth"
								}[t])
							})
						}, t)) }, e)),
						/* @__PURE__ */ d("button", {
							disabled: n || !Tt(e.dice),
							onClick: () => c("keep"),
							children: a("games.vantage.completeArrangement")
						}),
						/* @__PURE__ */ d("button", {
							disabled: n || e.remaining > 0,
							onClick: () => c("stop"),
							children: a("games.vantage.endUnsolvedTrial")
						})
					] }),
					e.kind === "dance" && /* @__PURE__ */ f(u, { children: [m.map(({ x: t, y: i, die: o }) => /* @__PURE__ */ d("button", {
						disabled: n,
						onClick: () => {
							r({
								type: "miniGame",
								op: "place",
								indices: [],
								x: t,
								y: i,
								die: o
							}), s([]);
						},
						children: a("games.vantage.placeDanceDie", {
							skill: a(Q[e.dice[o]]),
							x: t,
							y: i
						})
					}, `${t},${i},${o}`)), /* @__PURE__ */ d("button", {
						disabled: n || Et(e).length > 0 || e.dice[0] === e.dice[1],
						onClick: () => c("stop"),
						children: a("games.vantage.noDancePlacement")
					})] })
				]
			})
		]
	}) : /* @__PURE__ */ d(_s, {
		game: e,
		coins: t,
		waiting: n,
		send: r
	});
}
//#endregion
//#region src/games/vantage/artwork-preview.tsx
function ys({ src: e, label: t, close: n, children: a }) {
	let o = l(), [s, c] = i(0), [u, p] = i(null), m = r(null), h = No(e);
	function g(e) {
		let t = m.current;
		if (!t || !s) return;
		let n = u ?? t.clientWidth / s;
		p(Math.max(.1, Math.min(3, n * e)));
	}
	return /* @__PURE__ */ d("div", {
		className: "vantage-modal",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": t,
		onKeyDown: (e) => {
			e.key === "Escape" && (e.stopPropagation(), n());
		},
		children: /* @__PURE__ */ f("section", {
			className: "vantage-preview",
			children: [
				/* @__PURE__ */ f("div", {
					className: "vantage-preview-toolbar",
					children: [
						/* @__PURE__ */ d("strong", { children: t }),
						/* @__PURE__ */ d("button", {
							disabled: u === null,
							onClick: () => p(null),
							children: o("games.vantage.fitImage")
						}),
						/* @__PURE__ */ d("button", {
							disabled: !s || u === 1,
							onClick: () => p(1),
							children: o("games.vantage.originalImageSize")
						}),
						/* @__PURE__ */ d("button", {
							disabled: !s || u !== null && u <= .1,
							"aria-label": o("games.vantage.zoomImageOut"),
							onClick: () => g(.8),
							children: "−"
						}),
						/* @__PURE__ */ d("output", {
							"aria-live": "polite",
							children: u === null ? "" : o("games.vantage.imageZoomLevel", { n: Math.round(u * 100) })
						}),
						/* @__PURE__ */ d("button", {
							disabled: !s || u !== null && u >= 3,
							"aria-label": o("games.vantage.zoomImageIn"),
							onClick: () => g(1.25),
							children: "+"
						}),
						/* @__PURE__ */ d("button", {
							autoFocus: !0,
							className: "vantage-close",
							onClick: n,
							children: o("games.vantage.closeImage")
						})
					]
				}),
				/* @__PURE__ */ d("div", {
					className: "vantage-preview-viewport",
					tabIndex: 0,
					"aria-label": t,
					children: h.url ? /* @__PURE__ */ d("img", {
						ref: m,
						src: h.url,
						alt: t,
						draggable: !1,
						onLoad: (e) => c(e.currentTarget.naturalWidth),
						style: u === null ? void 0 : {
							width: s * u,
							maxWidth: "none",
							maxHeight: "none"
						}
					}) : /* @__PURE__ */ d(Po, {
						failed: h.failed,
						retry: h.retry
					})
				}),
				a && /* @__PURE__ */ d("div", {
					className: "vantage-preview-description",
					children: a
				})
			]
		})
	});
}
//#endregion
//#region src/games/vantage/puzzle-panel.tsx
function bs({ puzzle: e, waiting: t, send: n }) {
	let r = l(), [a, o] = i(""), [s, c] = i(null), [p, m] = i(e.point ?? [500, 500]), [h, g] = i(null), _ = (e) => `games/vantage/live/cards/${e}.webp`, v = No([
		128,
		511,
		693,
		721
	].includes(e.id) ? _(e.cards[0]) : e.id === 125 ? _(532) : null), y = Mo(e.stage === "study" ? e.cards.map(_) : []);
	if (e.stage === "done") return null;
	let b = [
		128,
		511,
		693,
		721
	].includes(e.id), x = e.id === 621 && e.stage === "answer", S = e.id === 125, C = (e) => {
		m(e), n({
			type: "puzzleMove",
			op: "point",
			point: e
		});
	};
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper vantage-puzzle",
		children: [
			/* @__PURE__ */ d("h2", { children: r("games.vantage.puzzleTitle", { n: e.id }) }),
			!y.ready && /* @__PURE__ */ d(Po, {
				failed: y.failed,
				retry: y.retry
			}),
			x ? /* @__PURE__ */ d("p", { children: r("games.vantage.puzzleMemoryHidden") }) : /* @__PURE__ */ f(u, { children: [!b && /* @__PURE__ */ d("div", {
				className: "vantage-puzzle-references",
				children: e.cards.map((e) => /* @__PURE__ */ f("article", { children: [/* @__PURE__ */ d("button", {
					onClick: () => c(e),
					"aria-label": r("games.vantage.enlargePuzzleCard", { n: e }),
					children: /* @__PURE__ */ d(Fo, {
						src: _(e),
						alt: r("games.vantage.puzzleCard", { n: e })
					})
				}), /* @__PURE__ */ d(Jo, { card: e })] }, e))
			}), b && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("button", {
					onClick: () => c(e.cards[0]),
					children: r("games.vantage.enlargePuzzleCard", { n: e.cards[0] })
				}),
				/* @__PURE__ */ d("p", { children: r(e.id === 693 ? "games.vantage.puzzleTreeControls" : e.id === 721 ? "games.vantage.puzzleHexControls" : e.id === 511 ? "games.vantage.puzzleDifferencesControls" : "games.vantage.puzzleKnightControls") }),
				!v.url && /* @__PURE__ */ d(Po, {
					failed: v.failed,
					retry: v.retry
				}),
				/* @__PURE__ */ d("div", {
					className: "vantage-puzzle-scroll",
					children: /* @__PURE__ */ f("div", {
						className: "vantage-puzzle-board",
						"aria-busy": !v.url,
						children: [
							/* @__PURE__ */ d(Fo, {
								src: _(e.cards[0]),
								alt: r("games.vantage.puzzleCard", { n: e.cards[0] })
							}),
							e.id === 128 && /* @__PURE__ */ d(u, { children: [e.you, e.knight].map(([e, t], n) => /* @__PURE__ */ d("span", {
								className: "vantage-puzzle-token",
								"data-side": n,
								style: {
									left: (136 + 64.5 * t - 6.5 * e) / 750 * 100 + "%",
									top: (70 + 58 * e + 1.5 * t) / 500 * 100 + "%"
								},
								children: r(n ? "games.vantage.puzzleKnight" : "games.vantage.puzzleYou")
							}, n)) }),
							e.id === 693 && /* @__PURE__ */ f(u, { children: [e.path.slice(1).map((t, n) => {
								let [r, i] = Bt[e.path[n]], [a, o] = Bt[t];
								return /* @__PURE__ */ d("span", {
									className: "vantage-puzzle-line",
									style: {
										left: r / 750 * 100 + "%",
										top: i / 500 * 100 + "%",
										width: Math.hypot(a - r, o - i) / 750 * 100 + "%",
										transform: `rotate(${Math.atan2(o - i, a - r)}rad)`
									}
								}, n);
							}), Bt.map(([i, a], o) => /* @__PURE__ */ d("button", {
								className: "vantage-puzzle-knot",
								"data-selected": e.path.includes(o),
								style: {
									left: i / 750 * 100 + "%",
									top: a / 500 * 100 + "%"
								},
								disabled: !v.url && b || t || !Qt(e, o),
								onClick: () => n({
									type: "puzzleMove",
									op: "knot",
									knot: o
								}),
								"aria-label": r("games.vantage.puzzleKnot", {
									row: String.fromCharCode(65 + Math.floor(o / 6)),
									n: o % 6 + 1
								})
							}, o))] }),
							[511, 721].includes(e.id) && /* @__PURE__ */ f(u, { children: [
								/* @__PURE__ */ d("button", {
									className: "vantage-puzzle-pick",
									"aria-label": r(e.id === 721 ? "games.vantage.puzzleHexPick" : "games.vantage.puzzleDifferencePick"),
									disabled: !v.url && b || t || e.stage !== "answer" || e.id === 511 && e.points.length >= 6,
									onClick: (e) => {
										let t = e.currentTarget.getBoundingClientRect();
										C([(e.clientX - t.left) / t.width * 1e3, (e.clientY - t.top) / t.height * 1e3]);
									},
									onKeyDown: (e) => {
										let t = e.shiftKey ? 5 : 25, n = null;
										e.key === "ArrowLeft" && (n = [Math.max(0, p[0] - t), p[1]]), e.key === "ArrowRight" && (n = [Math.min(1e3, p[0] + t), p[1]]), e.key === "ArrowUp" && (n = [p[0], Math.max(0, p[1] - t)]), e.key === "ArrowDown" && (n = [p[0], Math.min(1e3, p[1] + t)]), n && (e.preventDefault(), m(n)), (e.key === "Enter" || e.key === " ") && (e.preventDefault(), C(p));
									}
								}),
								e.stage === "answer" && /* @__PURE__ */ d("span", {
									className: "vantage-puzzle-crosshair",
									style: {
										left: p[0] / 10 + "%",
										top: p[1] / 10 + "%"
									},
									children: "⊕"
								}),
								e.id === 721 && e.point && /* @__PURE__ */ d("span", {
									className: "vantage-puzzle-mark",
									style: {
										left: e.point[0] / 10 + "%",
										top: e.point[1] / 10 + "%"
									},
									children: "✓"
								}),
								e.id === 511 && e.points.map(([e, i], a) => /* @__PURE__ */ d("button", {
									className: "vantage-puzzle-mark",
									style: {
										left: e / 10 + "%",
										top: i / 10 + "%"
									},
									disabled: !v.url && (b || S) || t,
									onClick: () => n({
										type: "puzzleMove",
										op: "remove",
										index: a
									}),
									"aria-label": r("games.vantage.removePuzzlePoint", { n: a + 1 }),
									children: a + 1
								}, a))
							] })
						]
					})
				})
			] })] }),
			e.stage === "study" ? /* @__PURE__ */ d("button", {
				disabled: !y.ready || t,
				onClick: () => {
					c(null), n({
						type: "puzzleMove",
						op: "ready"
					});
				},
				children: r(e.id === 621 ? "games.vantage.puzzleHideMemory" : "games.vantage.puzzleReady")
			}) : /* @__PURE__ */ f(u, { children: [
				S && /* @__PURE__ */ f(u, { children: [
					/* @__PURE__ */ d("p", { children: r("games.vantage.puzzleTunnelControls") }),
					!v.url && /* @__PURE__ */ d(Po, {
						failed: v.failed,
						retry: v.retry
					}),
					/* @__PURE__ */ d("div", {
						className: "vantage-puzzle-scroll",
						children: /* @__PURE__ */ f("div", {
							className: "vantage-puzzle-tunnels",
							"aria-busy": !v.url,
							children: [e.tunnels.map((e, i) => /* @__PURE__ */ d("div", { children: e.map((e, a) => /* @__PURE__ */ d("button", {
								className: "vantage-puzzle-tile",
								"data-selected": h?.[0] === i && h[1] === a,
								disabled: !v.url && (b || S) || t,
								"aria-label": r("games.vantage.puzzleTunnelTile", {
									row: i + 1,
									n: a + 1
								}),
								style: {
									backgroundImage: v.url ? `url("${v.url}")` : void 0,
									backgroundPosition: `${-[
										35,
										185,
										330
									][e]}px ${-[
										213,
										311,
										412,
										514
									][i]}px`
								},
								onClick: () => {
									h?.[0] === i && h[1] !== a ? (n({
										type: "puzzleMove",
										op: "tunnel",
										row: i,
										column: h[1],
										target: a
									}), g(null)) : g([i, a]);
								}
							}, a)) }, i)), /* @__PURE__ */ d("div", { children: [
								1,
								2,
								3
							].map((i) => /* @__PURE__ */ d("button", {
								className: "vantage-puzzle-entrance",
								"aria-pressed": e.entrance === i,
								disabled: !v.url && (b || S) || t,
								onClick: () => n({
									type: "puzzleMove",
									op: "entrance",
									entrance: i
								}),
								style: {
									backgroundImage: v.url ? `url("${v.url}")` : void 0,
									backgroundPosition: `${-[
										35,
										187,
										332
									][i - 1]}px -613px`
								},
								children: /* @__PURE__ */ d("span", { children: r("games.vantage.puzzleTunnelEntrance", { n: i }) })
							}, i)) })]
						})
					})
				] }),
				!b && !S && /* @__PURE__ */ f("label", { children: [r(e.id === 586 ? "games.vantage.puzzleTool" : e.id === 543 ? "games.vantage.puzzleBone" : e.id === 233 ? "games.vantage.puzzleTranslation" : "games.vantage.puzzleAnswer"), /* @__PURE__ */ d("textarea", {
					rows: 2,
					value: a,
					disabled: !v.url && (b || S) || t,
					onChange: (e) => o(e.target.value)
				})] }),
				e.id === 128 && /* @__PURE__ */ d("div", {
					className: "vantage-puzzle-directions",
					children: [
						"N",
						"E",
						"S",
						"W"
					].map((i) => /* @__PURE__ */ d("button", {
						disabled: !v.url && b || t || !Zt(e).includes(i),
						onClick: () => n({
							type: "puzzleMove",
							op: "move",
							direction: i
						}),
						children: r(i === "N" ? "games.vantage.puzzleNorth" : i === "E" ? "games.vantage.puzzleEast" : i === "S" ? "games.vantage.puzzleSouth" : "games.vantage.puzzleWest")
					}, i))
				}),
				e.id === 128 && e.knightResult !== "playing" && /* @__PURE__ */ d("p", {
					role: "status",
					children: r(e.knightResult === "won" ? "games.vantage.puzzleKnightWon" : "games.vantage.puzzleKnightLost")
				}),
				e.id === 511 && /* @__PURE__ */ d("p", {
					role: "status",
					children: r("games.vantage.puzzlePointsSelected", { n: e.points.length })
				}),
				/* @__PURE__ */ d("button", {
					disabled: !v.url && b || t || e.id === 128 && e.knightResult === "playing" || e.id === 721 && !e.point || e.id === 511 && e.points.length < 5 || e.id === 693 && e.path.length < 2 || S && e.entrance === null || !b && !S && !a.trim(),
					onClick: () => n({
						type: "puzzleMove",
						op: "submit",
						answer: a
					}),
					children: r("games.vantage.submitPuzzleAnswer")
				}),
				[
					511,
					693,
					721,
					125
				].includes(e.id) && /* @__PURE__ */ d("button", {
					disabled: !v.url && (b || S) || t,
					onClick: () => {
						g(null), n({
							type: "puzzleMove",
							op: "clear"
						});
					},
					children: r(e.id === 693 ? "games.vantage.clearPuzzlePath" : "games.vantage.clearPuzzleSelection")
				})
			] }),
			s !== null && !x && /* @__PURE__ */ d(ys, {
				src: _(s),
				label: r("games.vantage.puzzleCard", { n: s }),
				close: () => c(null),
				children: /* @__PURE__ */ d(Jo, { card: s })
			})
		]
	});
}
//#endregion
//#region src/games/vantage/action-bonus-panel.tsx
var xs = [...new Set(T)];
function Ss({ bonus: e, phase: t, dice: n, selected: r, waiting: a, send: o }) {
	let s = l(), [c, p] = i("blank"), [m, h] = i([]), g = /* @__PURE__ */ f("label", { children: [s("games.vantage.chooseResultType"), /* @__PURE__ */ d("select", {
		value: c,
		onChange: (e) => p(e.target.value),
		children: xs.map((e) => /* @__PURE__ */ d("option", {
			value: e,
			children: s(Q[e])
		}, e))
	})] });
	return /* @__PURE__ */ f("div", {
		className: "vantage-bonus-controls",
		children: [
			!!e.ignore.length && /* @__PURE__ */ d("p", { children: s("games.vantage.ignoreResultTypes", { faces: e.ignore.map((e) => s(Q[e])).join(" / ") }) }),
			e.initial && /* @__PURE__ */ d("p", { children: s("games.vantage.initialFloraRoll") }),
			e.immunity && /* @__PURE__ */ d("p", { children: s("games.vantage.bonusClimate", { kind: s(e.immunity === "heat" ? "games.vantage.heat" : "games.vantage.cold") }) }),
			t === "cost" && e.chooseIgnore && /* @__PURE__ */ f(u, { children: [g, /* @__PURE__ */ d("button", {
				disabled: a,
				onClick: () => o({
					type: "actionBonus",
					op: "chooseIgnore",
					face: c,
					indices: []
				}),
				children: s("games.vantage.confirmIgnoredType")
			})] }),
			t === "dice" && /* @__PURE__ */ f(u, { children: [
				e.ignoreOne && /* @__PURE__ */ d("button", {
					disabled: a || r === null || n[r] == null,
					onClick: () => o({
						type: "actionBonus",
						op: "ignore",
						die: r,
						indices: []
					}),
					children: s("games.vantage.ignoreSelectedBonusDie")
				}),
				e.changeOne && /* @__PURE__ */ f(u, { children: [g, /* @__PURE__ */ d("button", {
					disabled: a || r === null || n[r] == null,
					onClick: () => o({
						type: "actionBonus",
						op: "change",
						die: r,
						face: c,
						indices: []
					}),
					children: s("games.vantage.changeSelectedBonusDie")
				})] }),
				e.reroll && /* @__PURE__ */ f(u, { children: [
					/* @__PURE__ */ d("p", { children: s("games.vantage.bonusSubsetReroll") }),
					n.map((e, t) => e !== null && /* @__PURE__ */ f("label", { children: [
						/* @__PURE__ */ d("input", {
							type: "checkbox",
							checked: m.includes(t),
							disabled: a,
							onChange: (e) => h(e.target.checked ? [...m, t] : m.filter((e) => e !== t))
						}),
						t + 1,
						" · ",
						s(Q[e])
					] }, t)),
					/* @__PURE__ */ d("button", {
						disabled: a || !m.length || m.some((e) => n[e] == null),
						onClick: () => {
							o({
								type: "actionBonus",
								op: "reroll",
								indices: m
							}), h([]);
						},
						children: s("games.vantage.rerollTrialDice")
					})
				] })
			] })
		]
	});
}
function Cs({ dice: e, cost: t, chosen: n, waiting: r, send: a }) {
	let o = l(), [s, c] = i([]), p = t === null ? null : Math.min(t, e.length), m = p !== null && p >= 0 && p < e.length;
	return /* @__PURE__ */ f("div", {
		className: "vantage-bonus-controls",
		children: [
			/* @__PURE__ */ d("p", { children: o("games.vantage.floraForesightResults") }),
			e.map((e, t) => /* @__PURE__ */ f("label", { children: [
				m && /* @__PURE__ */ d("input", {
					type: "checkbox",
					checked: s.includes(t),
					disabled: r || !s.includes(t) && s.length >= p,
					onChange: (e) => c(e.target.checked ? [...s, t] : s.filter((e) => e !== t))
				}),
				" ",
				t + 1,
				" · ",
				o(Q[e])
			] }, t)),
			m && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("p", { children: o("games.vantage.chooseForesightDice", { n: p }) }),
				/* @__PURE__ */ d("button", {
					disabled: r || s.length !== p,
					onClick: () => a({
						type: "actionBonus",
						op: "foresight",
						indices: s
					}),
					children: o("games.vantage.confirmForesightDice")
				}),
				n?.length === p && /* @__PURE__ */ d("p", { children: o("games.vantage.foresightDiceConfirmed", { dice: n.map((e) => e + 1).join(" · ") || "0" }) })
			] })
		]
	});
}
//#endregion
//#region src/games/vantage/runes.tsx
function ws({ pub: e, rid: t, send: n }) {
	let r = l();
	return e.runeSurvey?.includes(t) ? /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [/* @__PURE__ */ d("p", { children: r("games.vantage.runeSurvey") }), /* @__PURE__ */ f("div", {
			className: "vantage-card-row",
			children: [/* @__PURE__ */ d("button", {
				onClick: () => n({
					type: "confirmRune",
					present: !0
				}),
				children: r("games.vantage.runePresent")
			}), /* @__PURE__ */ d("button", {
				onClick: () => n({
					type: "confirmRune",
					present: !1
				}),
				children: r("games.vantage.runeAbsent")
			})]
		})]
	}) : null;
}
function Ts({ disabled: e, index: t, label: n, send: r }) {
	let a = l(), [o, s] = i("move"), [c, u] = i(!1);
	return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d("p", { children: n }),
		/* @__PURE__ */ f("label", { children: [a("games.vantage.runeShape"), /* @__PURE__ */ d("select", {
			value: o,
			disabled: e,
			onChange: (e) => {
				s(e.target.value), u(!1);
			},
			children: C.map((e) => /* @__PURE__ */ d("option", {
				value: e,
				children: a(Q[e])
			}, e))
		})] }),
		/* @__PURE__ */ d($, { kind: o }),
		/* @__PURE__ */ f("label", {
			className: "vantage-condition",
			children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: c,
				disabled: e,
				onChange: (e) => u(e.target.checked)
			}), a("games.vantage.confirmRuneShape")]
		}),
		/* @__PURE__ */ d("button", {
			disabled: e || !c,
			onClick: () => r({
				type: "applyEffect",
				index: t,
				skill: o,
				condition: !0
			}),
			children: a("games.vantage.resolveRuneSkills")
		})
	] });
}
function Es({ disabled: e, index: t, send: n }) {
	let r = l(), [a, o] = i(0);
	return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [r("games.vantage.runeTokenRow"), /* @__PURE__ */ d("select", {
		disabled: e,
		value: a,
		onChange: (e) => o(Number(e.target.value)),
		children: w.map((e, t) => /* @__PURE__ */ d("option", {
			value: t,
			children: r(Q[e])
		}, e))
	})] }), /* @__PURE__ */ d("button", {
		disabled: e,
		onClick: () => n({
			type: "applyEffect",
			index: t,
			line: a
		}),
		children: r("games.vantage.gainRuneQuest")
	})] });
}
function Ds({ pub: e, priv: t, me: n, waiting: r, nameOf: a, send: o }) {
	let s = l(), [c, u] = i("move"), [p, m] = i(0), [h, g] = i(!1), [_, v] = i(n.rid);
	if (!e.runeQuest) return null;
	let y = e.players.find((e) => e.supply.some((e) => e.card === 1706 && !e.rotated));
	if (!y) return null;
	let b = e.runeQuest.cells, x = [
		0,
		1,
		2
	].filter((e) => !b[e * 6 + C.indexOf(c)]), S = x.includes(p) ? p : x[0], T = !r && [
		"action",
		"cost",
		"dice",
		"story"
	].includes(e.phase);
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			/* @__PURE__ */ d("h2", { children: s("games.vantage.runeQuestTitle") }),
			/* @__PURE__ */ f("div", {
				className: "vantage-rune-table",
				role: "table",
				"aria-label": s("games.vantage.runeQuestTitle"),
				children: [/* @__PURE__ */ f("div", {
					role: "row",
					children: [C.map((e) => /* @__PURE__ */ d("span", {
						role: "columnheader",
						"aria-label": s(Q[e]),
						children: /* @__PURE__ */ d($, { kind: e })
					}, e)), /* @__PURE__ */ d("span", {})]
				}), w.map((e, t) => /* @__PURE__ */ f("div", {
					role: "row",
					children: [C.map((n, r) => /* @__PURE__ */ d("span", {
						role: "cell",
						"aria-label": s(b[t * 6 + r] ? "games.vantage.runeFilledCell" : "games.vantage.runeEmptyCell", {
							skill: s(Q[n]),
							stat: s(Q[e])
						}),
						children: b[t * 6 + r] ? s("games.vantage.runeMarked") : ""
					}, n)), /* @__PURE__ */ d("span", {
						role: "rowheader",
						"aria-label": s(Q[e]),
						children: /* @__PURE__ */ d($, { kind: e })
					})]
				}, e))]
			}),
			t.runeRecordable && /* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d("p", { children: s("games.vantage.recordRunePrompt") }),
				/* @__PURE__ */ f("label", { children: [s("games.vantage.runeShape"), /* @__PURE__ */ d("select", {
					value: c,
					onChange: (e) => {
						u(e.target.value), g(!1);
					},
					children: C.map((e) => /* @__PURE__ */ d("option", {
						value: e,
						children: s(Q[e])
					}, e))
				})] }),
				/* @__PURE__ */ d($, { kind: c }),
				/* @__PURE__ */ f("label", { children: [s("games.vantage.runeTokenRow"), /* @__PURE__ */ d("select", {
					value: S ?? "",
					onChange: (e) => m(Number(e.target.value)),
					children: x.map((e) => /* @__PURE__ */ d("option", {
						value: e,
						children: s(Q[w[e]])
					}, e))
				})] }),
				/* @__PURE__ */ f("label", {
					className: "vantage-condition",
					children: [/* @__PURE__ */ d("input", {
						type: "checkbox",
						checked: h,
						onChange: (e) => g(e.target.checked)
					}), s("games.vantage.confirmRuneShape")]
				}),
				/* @__PURE__ */ d("button", {
					disabled: !T || !h || S === void 0,
					onClick: () => {
						o({
							type: "recordRune",
							skill: c,
							row: S,
							condition: !0
						}), g(!1);
					},
					children: s("games.vantage.recordRune")
				})
			] }),
			b.every(Boolean) && y.rid === n.rid && /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [s("games.vantage.runeQuestRecipient"), /* @__PURE__ */ d("select", {
				value: _,
				onChange: (e) => v(e.target.value),
				children: e.players.map((e) => /* @__PURE__ */ d("option", {
					value: e.rid,
					children: a(e.rid)
				}, e.rid))
			})] }), /* @__PURE__ */ d("button", {
				disabled: !T,
				onClick: () => o({
					type: "completeRuneQuest",
					target: _
				}),
				children: s("games.vantage.completeRuneQuest")
			})] })
		]
	});
}
//#endregion
//#region src/games/vantage/crew-stories.tsx
function Os({ pub: e, rid: t, send: n }) {
	let r = l(), i = e.crewSharing;
	if (!i) return null;
	let a = i.waiting.includes(t);
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		"aria-live": "polite",
		children: [/* @__PURE__ */ d("p", { children: r("games.vantage.crewSharing") }), a ? /* @__PURE__ */ f("div", {
			className: "vantage-card-row",
			children: [/* @__PURE__ */ d("button", {
				onClick: () => n({
					type: "shareVantage",
					accept: !0
				}),
				children: r("games.vantage.acceptShareSkill")
			}), /* @__PURE__ */ d("button", {
				onClick: () => n({
					type: "shareVantage",
					accept: !1
				}),
				children: r("games.vantage.declineShareSkill")
			})]
		}) : /* @__PURE__ */ d("p", { children: r("games.vantage.waitCrewSharing") })]
	});
}
function ks({ player: e, disabled: t, overCapacity: n, confirm: r, send: a }) {
	let o = l(), [s, c] = i(0), p = e.grid.flatMap((e, t) => e && t !== 4 && E[e.card].value !== void 0 && !Dr(e.card) && ![
		1103,
		1104,
		1105,
		1106
	].includes(e.card) ? [{
		held: e,
		cell: t
	}] : []), m = e.grid.flatMap((e, t) => t !== 4 && (!e || p.some((e) => e.cell === t)) ? [t] : []), h = m.includes(s) ? s : m[0];
	return /* @__PURE__ */ f("div", {
		className: "vantage-stow",
		children: [
			/* @__PURE__ */ d("p", { children: o("games.vantage.stowValuedCards") }),
			/* @__PURE__ */ d("div", {
				className: "vantage-card-row",
				children: p.map(({ held: e }) => /* @__PURE__ */ d("button", {
					disabled: t,
					onClick: () => a({
						type: "stowCard",
						card: e.card
					}),
					children: o("games.vantage.stowToReserve", { n: e.card })
				}, e.card))
			}),
			e.reserve.some((e) => E[e.card].value !== void 0) && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("label", { children: [o("games.vantage.gridDestination"), /* @__PURE__ */ d("select", {
				value: h ?? "",
				disabled: t || !m.length,
				onChange: (e) => c(Number(e.target.value)),
				children: m.map((e) => /* @__PURE__ */ d("option", {
					value: e,
					children: o("games.vantage.stowGridCell", { n: e + 1 })
				}, e))
			})] }), /* @__PURE__ */ d("div", {
				className: "vantage-card-row",
				children: e.reserve.filter((e) => E[e.card].value !== void 0).map((e) => /* @__PURE__ */ d("button", {
					disabled: t || h === void 0,
					onClick: () => a({
						type: "stowCard",
						card: e.card,
						cell: h
					}),
					children: o("games.vantage.stowToGrid", { n: e.card })
				}, e.card))
			})] }),
			/* @__PURE__ */ d("button", {
				disabled: t || n,
				onClick: r,
				children: o("games.vantage.finishStowing")
			})
		]
	});
}
//#endregion
//#region src/games/vantage/story-card-selection.tsx
function As({ cards: e, minimum: t, maximum: n, selling: r, bonus: a, disabled: o, label: s, choose: c, minimumValue: u = 0, totalBonus: p = 0 }) {
	let m = l(), [h, g] = i([]), _ = h.filter((t) => e.includes(t)), v = _.reduce((e, t) => e + (E[t].value ?? 0) + a, 0);
	return /* @__PURE__ */ f("div", {
		className: "vantage-story-card-selection",
		children: [
			/* @__PURE__ */ d("p", { children: s }),
			/* @__PURE__ */ d("div", {
				className: "vantage-card-row",
				children: e.map((e) => /* @__PURE__ */ f("button", {
					className: _.includes(e) ? "vantage-selected" : "",
					"aria-pressed": _.includes(e),
					disabled: o || !_.includes(e) && _.length >= n,
					onClick: () => g(_.includes(e) ? _.filter((t) => t !== e) : [..._, e]),
					children: [m("games.vantage.storyCardNumber", { n: e }), r && /* @__PURE__ */ d("span", { children: m("games.vantage.printedValue", { n: E[e].value }) })]
				}, e))
			}),
			r && /* @__PURE__ */ d("p", { children: m("games.vantage.saleProceeds", { n: v + (_.length ? p : 0) }) }),
			/* @__PURE__ */ d("button", {
				disabled: o || _.length < t || _.length > n || _.reduce((e, t) => e + (E[t].value ?? 0), 0) < u,
				onClick: () => c(_),
				children: m(_.length ? "games.vantage.confirmStoryCards" : "games.vantage.skipStoryCards")
			})
		]
	});
}
//#endregion
//#region src/games/vantage/story-effects.tsx
function js({ priv: e, player: t, players: n, nameOf: r, playerCount: i, waiting: a, character: o, send: s, label: c, showBook: u }) {
	let p = l(), m = e.passage;
	return m.effects.map((l, h) => {
		let g = l.applied || a || e.pendingCards.length > 0 || m.effects.slice(0, h).some((e) => !e.applied), _ = g || e.needsReserveRoom || l.kind === "testCoins" && !e.storyTest?.done;
		if (l.kind === "barter" && !l.applied) {
			let e = JSON.parse(l.value);
			return /* @__PURE__ */ d(As, {
				cards: an(t, e),
				minimum: e.min,
				maximum: e.max,
				minimumValue: e.minTotal,
				totalBonus: typeof e.bonus == "number" ? e.bonus : 0,
				selling: !!e.sale,
				bonus: 0,
				disabled: _,
				label: c(l),
				choose: (e) => s({
					type: "applyEffect",
					index: h,
					cards: e
				})
			}, h);
		}
		if ([
			"copyAction",
			"printedAbility",
			"testPickOne",
			"testPickMany",
			"matchingTestReward"
		].includes(l.kind) && !l.applied) return /* @__PURE__ */ d(Zo, {
			priv: e,
			player: t,
			index: h,
			kind: l.kind,
			value: l.value,
			disabled: _,
			send: s
		}, h);
		if (l.kind === "printedAbility" && l.value === "houseOccupancy" && l.applied && e.knownHouseFace !== null) return /* @__PURE__ */ d("p", { children: p("games.vantage.houseCheckResult", {
			face: p(Q[e.knownHouseFace]),
			status: p(e.knownHouseFace === "blank" ? "games.vantage.houseEmpty" : "games.vantage.houseOccupied")
		}) }, h);
		if (l.kind === "printedAbility" && l.value === "invest" && l.applied && e.skillResult) return /* @__PURE__ */ d("p", { children: p("games.vantage.investmentRolled", { face: p(Q[e.skillResult]) }) }, h);
		if (l.kind === "printedAbility" && l.value === "investmentReturn" && l.applied) return /* @__PURE__ */ d("p", { children: p("games.vantage.investmentClaimed", { n: e.investmentReturn ?? 0 }) }, h);
		if (l.kind === "printedAbility" && l.value === "asylumRoll" && l.applied && e.skillResult) return /* @__PURE__ */ d("p", { children: p("games.vantage.skillResult", { skill: p(Q[e.skillResult]) }) }, h);
		if (l.kind === "selectedBoost" && !l.applied) return /* @__PURE__ */ d(Fs, {
			cards: (l.value === "experience" ? [
				...t.grid,
				...t.reserve,
				...t.supply
			] : t.grid).flatMap((e) => e && P(e.card, l.value) ? [e.card] : []),
			maximum: l.amount,
			minimum: l.minimum ?? 1,
			disabled: _,
			choose: (e, t) => s({
				type: "applyEffect",
				index: h,
				cards: e,
				amount: t
			})
		}, h);
		if (l.kind === "masterReward" && !l.applied) return /* @__PURE__ */ d(Is, {
			players: n,
			nameOf: r,
			disabled: _,
			choose: (e) => s({
				type: "applyEffect",
				index: h,
				target: e
			})
		}, h);
		if (l.kind === "gardenPluck" && !l.applied) return /* @__PURE__ */ d(As, {
			cards: e.tuckedPlants,
			minimum: 1,
			maximum: 1,
			selling: !1,
			bonus: 0,
			disabled: _,
			label: c(l),
			choose: (e) => s({
				type: "applyEffect",
				index: h,
				cards: e
			})
		}, h);
		if ((l.kind === "trap" || l.kind === "challengeCheck") && l.applied && e.trapTest) return /* @__PURE__ */ d("p", { children: p("games.vantage.trapResults", {
			target: p(Q[e.trapTest.target]),
			faces: e.trapTest.faces.map((e) => p(Q[e])).join(" · ")
		}) }, h);
		if (l.kind === "structureTrade" && !l.applied && /^(card|token):/.test(l.value)) {
			let [n, r] = l.value.split(":");
			return /* @__PURE__ */ d(As, {
				cards: Pn(t, n, r, e.current?.source ?? 0),
				minimum: 1,
				maximum: 1,
				selling: n === "card",
				bonus: l.amount,
				disabled: _,
				label: c(l),
				choose: (e) => s({
					type: "applyEffect",
					index: h,
					cards: e
				})
			}, h);
		}
		if (l.kind === "challengeReward" && l.applied && e.challengeRewardFace) return /* @__PURE__ */ d("p", { children: p("games.vantage.challengeRewardResult", { face: p(Q[e.challengeRewardFace]) }) }, h);
		if ((l.kind === "removeCurses" || l.kind === "sellCards") && !l.applied) {
			let [e, n, r] = l.value.split(":"), i = [
				...t.grid.flatMap((e) => e ? [e.card] : []),
				...t.reserve.map((e) => e.card),
				...t.supply.map((e) => e.card),
				...t.supply.flatMap((e) => (e.tucked ?? []).map((e) => e.card))
			].filter((e) => l.kind === "removeCurses" ? Dr(e) : e !== t.character && E[e].value !== void 0 && (r !== "items" || E[e].group === "item")), a = l.kind === "removeCurses" ? l.value === "required" ? Math.min(l.amount, i.length) : 0 : Number(e);
			return /* @__PURE__ */ d(As, {
				cards: i,
				minimum: a,
				maximum: l.amount,
				selling: l.kind === "sellCards",
				bonus: Number(n) || 0,
				disabled: _,
				label: c(l),
				choose: (e) => s({
					type: "applyEffect",
					index: h,
					cards: e
				})
			}, h);
		}
		if ((l.kind === "runeRoll" || l.kind === "runeSkill") && !l.applied) return /* @__PURE__ */ d(Ts, {
			disabled: _,
			index: h,
			label: c(l),
			send: s
		}, h);
		if (l.kind === "runeQuest" && l.amount && !l.applied) return /* @__PURE__ */ d(Es, {
			disabled: _,
			index: h,
			send: s
		}, h);
		if (l.kind === "stowCards" && !l.applied) return /* @__PURE__ */ d(ks, {
			player: t,
			disabled: g,
			overCapacity: e.needsReserveRoom,
			confirm: () => s({
				type: "applyEffect",
				index: h
			}),
			send: s
		}, h);
		if (l.kind === "crewLearn" && !l.applied && i === 1) return /* @__PURE__ */ d(Ns, {
			disabled: _,
			index: h,
			send: s
		}, h);
		if (l.kind === "rest" && !l.applied) return /* @__PURE__ */ d(Ps, {
			priv: e,
			disabled: _,
			amount: l.amount,
			index: h,
			send: s
		}, h);
		if (l.kind === "gridRefresh" && !l.applied) return /* @__PURE__ */ d(Ps, {
			priv: e,
			disabled: _,
			amount: l.amount,
			index: h,
			send: s,
			grid: !0,
			optional: l.value !== "exact"
		}, h);
		if (l.kind === "loseSkill" && !l.applied) return /* @__PURE__ */ d(Ns, {
			disabled: _,
			index: h,
			send: s,
			losing: t
		}, h);
		if (l.kind === "skillChoice" && !l.applied) return /* @__PURE__ */ d(Ns, {
			disabled: _,
			index: h,
			send: s
		}, h);
		if ((l.kind === "preparation" || l.kind === "elemental" && l.value === "prepare") && !l.applied) return /* @__PURE__ */ d(Ms, {
			disabled: _,
			index: h,
			send: s
		}, h);
		if (l.kind === "damage" && !l.applied && !N(o, l.value)) return /* @__PURE__ */ f("div", { children: [
			/* @__PURE__ */ d("p", { children: c(l) }),
			/* @__PURE__ */ d("button", {
				disabled: _,
				onClick: () => s({
					type: "applyEffect",
					index: h,
					damage: "health"
				}),
				children: p("games.vantage.damageHealth", { n: l.amount })
			}),
			/* @__PURE__ */ d("button", {
				disabled: _,
				onClick: () => s({
					type: "applyEffect",
					index: h,
					damage: "timeMorale"
				}),
				children: p("games.vantage.damageTimeMorale", { n: l.amount })
			})
		] }, h);
		if (l.kind === "powerArmor" && !l.applied && l.amount === 1 && me(o) !== "armor") return /* @__PURE__ */ f("div", { children: [
			/* @__PURE__ */ d("p", { children: p("games.vantage.powerArmorChoice") }),
			/* @__PURE__ */ d("button", {
				disabled: _,
				onClick: () => s({
					type: "applyEffect",
					index: h,
					replaceCharacter: !0
				}),
				children: p("games.vantage.equipPowerArmor")
			}),
			/* @__PURE__ */ d("button", {
				disabled: _,
				onClick: () => s({
					type: "applyEffect",
					index: h,
					replaceCharacter: !1
				}),
				children: p("games.vantage.keepCharacter")
			})
		] }, h);
		let v = l.kind === "powerArmor" ? p(l.applied ? "games.vantage.powerArmorResolved" : me(o) === "armor" ? "games.vantage.armorBoost" : "games.vantage.equipPowerArmor", { n: l.value }) : l.kind === "damage" && N(o, l.value) ? p("games.vantage.environmentImmune") : c(l);
		return /* @__PURE__ */ f("button", {
			className: "vantage-effect",
			disabled: _,
			onClick: () => {
				s({
					type: "applyEffect",
					index: h
				}), l.kind === "vantage" && u(Number(l.value));
			},
			children: [/* @__PURE__ */ d("span", { children: v }), /* @__PURE__ */ d("b", { children: p(l.applied ? "games.vantage.applied" : "games.vantage.apply") })]
		}, h);
	});
}
function Ms({ disabled: e, index: t, send: n }) {
	let r = l(), [a, o] = i("move"), [s, c] = i(0), [u, p] = i(0);
	return /* @__PURE__ */ f("div", {
		className: "vantage-power-options",
		children: [
			/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [r("games.vantage.chooseSkill"), /* @__PURE__ */ d("select", {
				value: a,
				onChange: (e) => o(e.target.value),
				children: C.map((e) => /* @__PURE__ */ d("option", {
					value: e,
					children: r(Q[e])
				}, e))
			})] }), /* @__PURE__ */ d("button", {
				disabled: e,
				onClick: () => n({
					type: "applyEffect",
					index: t,
					preparation: "skills",
					skill: a
				}),
				children: r("games.vantage.elementalPrepareSkills")
			})] }),
			/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [r("games.vantage.chooseGridRow"), /* @__PURE__ */ d("select", {
				value: s,
				onChange: (e) => c(Number(e.target.value)),
				children: [
					0,
					1,
					2
				].map((e) => /* @__PURE__ */ d("option", {
					value: e,
					children: r("games.vantage.gridRow", { n: e + 1 })
				}, e))
			})] }), /* @__PURE__ */ d("button", {
				disabled: e,
				onClick: () => n({
					type: "applyEffect",
					index: t,
					preparation: "row",
					line: s
				}),
				children: r("games.vantage.elementalPrepareRow")
			})] }),
			/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [r("games.vantage.chooseGridColumn"), /* @__PURE__ */ d("select", {
				value: u,
				onChange: (e) => p(Number(e.target.value)),
				children: [
					0,
					1,
					2
				].map((e) => /* @__PURE__ */ d("option", {
					value: e,
					children: r("games.vantage.gridColumn", { n: e + 1 })
				}, e))
			})] }), /* @__PURE__ */ d("button", {
				disabled: e,
				onClick: () => n({
					type: "applyEffect",
					index: t,
					preparation: "column",
					line: u
				}),
				children: r("games.vantage.elementalPrepareColumn")
			})] })
		]
	});
}
function Ns({ disabled: e, index: t, send: n, losing: r }) {
	let a = l(), [o, s] = i("move"), c = r ? C.filter((e) => r.skills[e] > 0) : [...C], u = c.includes(o) ? o : c[0];
	return /* @__PURE__ */ f("div", { children: [c.length > 0 && /* @__PURE__ */ f("label", { children: [a("games.vantage.chooseSkill"), /* @__PURE__ */ d("select", {
		value: u,
		onChange: (e) => s(e.target.value),
		children: c.map((e) => /* @__PURE__ */ d("option", {
			value: e,
			children: a(Q[e])
		}, e))
	})] }), /* @__PURE__ */ d("button", {
		disabled: e,
		onClick: () => n({
			type: "applyEffect",
			index: t,
			skill: u
		}),
		children: a(r ? c.length ? "games.vantage.loseChosenSkill" : "games.vantage.noSkillToLose" : "games.vantage.gainChosenSkill")
	})] });
}
function Ps({ priv: e, disabled: t, amount: n, index: r, send: a, optional: o = !1, grid: s = !1 }) {
	let c = l(), [u, p] = i([]), m = s ? e.gridDice : e.restDice, h = Math.min(n, m.length);
	return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ d("p", { children: c(s ? o ? "games.vantage.gridRefreshLimit" : "games.vantage.gridRefreshExact" : "games.vantage.restRefresh", { n: h }) }),
		m.map((e) => {
			let n = e.card + ":" + e.slot;
			return /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				disabled: t || !u.includes(n) && u.length >= h,
				checked: u.includes(n),
				onChange: (e) => p(e.target.checked ? [...u, n] : u.filter((e) => e !== n))
			}), c("games.vantage.restDie", {
				card: e.card,
				n: e.slot + 1
			})] }, n);
		}),
		/* @__PURE__ */ d("button", {
			disabled: t || (o ? u.length > h : u.length !== h),
			onClick: () => a({
				type: "applyEffect",
				index: r,
				refreshDice: m.filter((e) => u.includes(e.card + ":" + e.slot))
			}),
			children: c("games.vantage.restRefreshConfirm")
		})
	] });
}
function Fs({ cards: e, maximum: t, minimum: n = 1, disabled: r, choose: a }) {
	let o = l(), [s, c] = i(n);
	return /* @__PURE__ */ f("div", { children: [t > 1 && /* @__PURE__ */ f("label", { children: [o("games.vantage.boostAmount"), /* @__PURE__ */ d("select", {
		value: s,
		onChange: (e) => c(Number(e.target.value)),
		children: Array.from({ length: t - n + 1 }, (e, t) => /* @__PURE__ */ d("option", {
			value: t + n,
			children: t + n
		}, t))
	})] }), /* @__PURE__ */ d(As, {
		cards: e,
		minimum: 1,
		maximum: 1,
		selling: !1,
		bonus: 0,
		disabled: r,
		label: o("games.vantage.boostSelectedCard"),
		choose: (e) => a(e, s)
	})] });
}
function Is({ players: e, nameOf: t, disabled: n, choose: r }) {
	let a = l(), [o, s] = i(e[0].rid);
	return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [a("games.vantage.chooseRewardPlayer"), /* @__PURE__ */ d("select", {
		value: o,
		onChange: (e) => s(e.target.value),
		children: e.map((e) => /* @__PURE__ */ d("option", {
			value: e.rid,
			children: t(e.rid)
		}, e.rid))
	})] }), /* @__PURE__ */ d("button", {
		disabled: n,
		onClick: () => r(o),
		children: a("games.vantage.grantMasterReward")
	})] });
}
//#endregion
//#region src/games/vantage/cooperation.tsx
function Ls({ pub: e, priv: t, me: n, nameOf: r, send: a }) {
	let o = l(), [s, c] = i(""), [p, m] = i(1), h = t.coLocated.includes(s) ? s : t.coLocated[0], g = e.active === n.rid, _ = t.coLocated.includes(e.active), v = e.summoning?.caller === e.active && e.summoning.summoned.includes(n.rid), y = !g && e.phase === "dice" && !!e.players.find((t) => t.rid === e.active)?.grid.some((e) => e?.card === 1011 && e.boost > 0), b = !g && e.phase === "dice" && n.grid.some((t) => t && (e.temporaryImpact.includes(t.card) || E[t.card].slots.some((e) => e.impact))), x = [...n.grid, ...n.reserve].filter((e) => e && [
		"item",
		"flora",
		"vehicle"
	].includes(E[e.card].group));
	return !e.powerTransfer && !h && !e.deliveryRecipients.length && !e.cardClaims.length && !b && !v && !y ? null : /* @__PURE__ */ f("section", {
		className: "vantage-paper vantage-cooperation",
		children: [
			/* @__PURE__ */ d("h2", { children: o(e.cardClaims.length ? "games.vantage.cardOwnership" : t.coLocated.length ? "games.vantage.companionsHere" : b ? "games.vantage.slotCooperation" : "games.vantage.cardDelivery") }),
			e.powerTransfer && /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: o("games.vantage.powerTransferConsent", {
				from: r(e.powerTransfer.from),
				to: r(e.powerTransfer.to),
				source: e.powerTransfer.source,
				destination: e.powerTransfer.destination
			}) }), e.powerTransfer.waiting.includes(n.rid) && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
				onClick: () => a({
					type: "answerPowerTransfer",
					accept: !0
				}),
				children: o("games.vantage.acceptPowerTransfer")
			}), /* @__PURE__ */ d("button", {
				onClick: () => a({
					type: "answerPowerTransfer",
					accept: !1
				}),
				children: o("games.vantage.declinePowerTransfer")
			})] })] }),
			t.coLocated.length > 0 && /* @__PURE__ */ d("p", { children: t.coLocated.map(r).join("、") }),
			!g && _ && [
				"action",
				"cost",
				"dice",
				"story"
			].includes(e.phase) && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: e.followConsent.includes(n.rid),
				onChange: (e) => a({
					type: "follow",
					allowed: e.target.checked
				})
			}), o("games.vantage.consentFollow", { name: r(e.active) })] }),
			!g && (_ || v || y) && e.phase === "dice" && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: e.slotPermission.includes(n.rid),
				onChange: (e) => a({
					type: "allowSlots",
					allowed: e.target.checked
				})
			}), o("games.vantage.consentSlots", { name: r(e.active) })] }),
			b && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: e.impactPermission.includes(n.rid),
				onChange: (e) => a({
					type: "allowImpact",
					allowed: e.target.checked
				})
			}), o("games.vantage.consentImpact", { name: r(e.active) })] }),
			g && h && e.phase === "story" && /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ f("label", { children: [o("games.vantage.giveTo"), /* @__PURE__ */ d("select", {
					value: h,
					onChange: (e) => c(e.target.value),
					children: t.coLocated.map((e) => /* @__PURE__ */ d("option", {
						value: e,
						children: r(e)
					}, e))
				})] }),
				n.coins > 0 && /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ f("label", { children: [o("games.vantage.coinQuantity"), /* @__PURE__ */ d("input", {
					type: "number",
					min: 1,
					max: n.coins,
					value: p,
					onChange: (e) => m(Number(e.target.value))
				})] }), /* @__PURE__ */ d("button", {
					disabled: !Number.isSafeInteger(p) || p < 1 || p > n.coins,
					onClick: () => a({
						type: "giveCoins",
						target: h,
						amount: p
					}),
					children: o("games.vantage.giveCoins")
				})] }),
				x.map((n) => n && /* @__PURE__ */ d("button", {
					disabled: t.pendingCards.length > 0 || e.deliveryRecipients.length > 0 || e.cardClaims.length > 0,
					onClick: () => a({
						type: "giveCard",
						target: h,
						card: n.card
					}),
					children: o("games.vantage.giveCard", { n: n.card })
				}, n.card))
			] }),
			e.deliveryRecipients.length > 0 && /* @__PURE__ */ d("p", {
				role: "status",
				children: o("games.vantage.waitingGiftPlacement", { names: e.deliveryRecipients.map(r).join("、") })
			}),
			e.cardClaims.map((e) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", {
				role: "status",
				children: o("games.vantage.cardClaim", {
					n: e.card,
					owner: r(e.owner),
					requester: r(e.requester)
				})
			}), e.owner === n.rid && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
				onClick: () => a({
					type: "resolveCardClaim",
					card: e.card,
					transfer: !1
				}),
				children: o("games.vantage.keepClaimedCard")
			}), /* @__PURE__ */ d("button", {
				onClick: () => a({
					type: "resolveCardClaim",
					card: e.card,
					transfer: !0
				}),
				children: o("games.vantage.transferClaimedCard", { name: r(e.requester) })
			})] })] }, e.card))
		]
	});
}
//#endregion
//#region src/games/vantage/card-placement.tsx
function Rs({ id: e, me: t, priv: n, name: r, preview: i, send: a }) {
	let o = l(), s = E[e], c = s.portrait || n.rotatedPending.includes(e), p = n.replacementCells[e];
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			/* @__PURE__ */ d("h2", { children: o("games.vantage.pendingCard") }),
			/* @__PURE__ */ f("button", {
				onClick: i,
				children: [
					e,
					" · ",
					r
				]
			}),
			/* @__PURE__ */ d(Ko, { card: e }),
			/* @__PURE__ */ d(Yo, { card: e }),
			/* @__PURE__ */ d(Jo, { card: e }),
			/* @__PURE__ */ d("div", {
				className: "vantage-placement",
				children: n.asylumPending.includes(e) ? /* @__PURE__ */ d("button", {
					onClick: () => a({
						type: "placeCard",
						card: e,
						zone: "supply"
					}),
					children: o("games.vantage.shelterInEmbassy")
				}) : n.tuckTargets[e] === void 0 ? c ? /* @__PURE__ */ f(u, { children: [t.grid.map((t, n) => t === null && (p === void 0 || p === n) && /* @__PURE__ */ d("button", {
					onClick: () => a({
						type: "placeCard",
						card: e,
						zone: "grid",
						cell: n
					}),
					children: o("games.vantage.placeGrid", { n: n + 1 })
				}, n)), (p === void 0 || p < 0) && !n.requiredGrid.includes(e) && !Dr(e) && ![
					1103,
					1104,
					1105,
					1106
				].includes(e) && /* @__PURE__ */ d("button", {
					onClick: () => a({
						type: "placeCard",
						card: e,
						zone: "reserve"
					}),
					children: o("games.vantage.placeReserve")
				})] }) : /* @__PURE__ */ d(u, { children: s.goalType ? /* @__PURE__ */ d("button", {
					onClick: () => a({
						type: "placeCard",
						card: e,
						zone: "center"
					}),
					children: o("games.vantage.placeCenter")
				}) : /* @__PURE__ */ d("button", {
					onClick: () => a({
						type: "placeCard",
						card: e,
						zone: "supply"
					}),
					children: o("games.vantage.placeSupply")
				}) }) : /* @__PURE__ */ d("button", {
					onClick: () => a({
						type: "placeCard",
						card: e,
						zone: "tuck"
					}),
					children: o("games.vantage.tuckUnderStructure", { n: n.tuckTargets[e] })
				})
			})
		]
	});
}
//#endregion
//#region src/games/vantage/placement-triggers.tsx
function zs({ pub: e, priv: t, myRid: n, nameOf: r, send: i }) {
	let a = l(), o = t.placement;
	return e.replenishment ? /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		role: "status",
		children: [
			/* @__PURE__ */ d("h2", { children: a("games.vantage.replenishTitle") }),
			/* @__PURE__ */ d("p", { children: a("games.vantage.replenishPrompt", {
				name: r(e.replenishment.owner),
				n: e.replenishment.card
			}) }),
			e.replenishment.rid === n ? /* @__PURE__ */ f("div", {
				className: "vantage-placement",
				children: [/* @__PURE__ */ d("button", {
					onClick: () => i({
						type: "replenish",
						accept: !0
					}),
					children: a("games.vantage.replenishAccept")
				}), /* @__PURE__ */ d("button", {
					onClick: () => i({
						type: "replenish",
						accept: !1
					}),
					children: a("games.vantage.replenishDecline")
				})]
			}) : /* @__PURE__ */ d("p", { children: a("games.vantage.waitingReplenish", { name: r(e.replenishment.rid) }) })
		]
	}) : e.placementPlayer ? /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		role: "status",
		children: [/* @__PURE__ */ d("h2", { children: a("games.vantage.resolvePlacement") }), o ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("p", { children: a(o.kind === "drain" ? "games.vantage.placementDrain" : "games.vantage.placementGain", {
			n: o.source,
			remaining: o.remaining
		}) }), /* @__PURE__ */ d("div", {
			className: "vantage-placement",
			children: o.options.map((e) => /* @__PURE__ */ d("button", {
				onClick: () => i({
					type: "placementBoost",
					card: e
				}),
				children: a(o.kind === "drain" ? "games.vantage.drainFromCard" : "games.vantage.boostOnCard", { n: e })
			}, e))
		})] }) : /* @__PURE__ */ d("p", { children: a("games.vantage.waitingPlacement", { name: r(e.placementPlayer) }) })]
	}) : null;
}
//#endregion
//#region src/games/vantage/sentient-controls.tsx
var Bs = [
	"time",
	"morale",
	"health",
	"setback",
	"blank"
];
function Vs({ pub: e, priv: t, me: n, send: r }) {
	let i = l();
	return e.replenishment ? null : e.skillRollPlayer ? /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		role: "status",
		children: [/* @__PURE__ */ d("h2", { children: i("games.vantage.skillRollDecision") }), t.skillRoll ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ f("p", { children: [/* @__PURE__ */ d($, { kind: t.skillRoll.face }), i("games.vantage.skillResult", { skill: i(Q[t.skillRoll.face]) })] }),
			t.skillRoll.kind === "match" && /* @__PURE__ */ d("p", { children: i("games.vantage.skillMatchOnly", { skill: i(Q[t.skillRoll.match]) }) }),
			/* @__PURE__ */ d("button", {
				onClick: () => r({ type: "keepSkillRoll" }),
				children: i("games.vantage.keepSkillRoll")
			}),
			(n.grid.find((e) => e?.card === 924)?.boost ?? 0) > 0 && C.filter((e) => e !== t.skillRoll?.face).map((e) => /* @__PURE__ */ d("button", {
				onClick: () => r({
					type: "itemPower",
					card: 924,
					power: "skillFace",
					skill: e,
					condition: !1
				}),
				children: i("games.vantage.weightedSkillRoll", { skill: i(Q[e]) })
			}, "924:" + e)),
			(n.grid.find((e) => e?.card === 1354)?.boost ?? 0) > 0 && C.filter((e) => n.skills[e] > 0 && e !== t.skillRoll?.face).map((e) => /* @__PURE__ */ d("button", {
				onClick: () => r({
					type: "sentientPower",
					card: 1354,
					power: "skillFace",
					skill: e,
					indices: [],
					faces: []
				}),
				children: i("games.vantage.changeSkillRoll", { skill: i(Q[e]) })
			}, e))
		] }) : /* @__PURE__ */ d("p", { children: i("games.vantage.waitingSkillRoll") })]
	}) : e.gamblePlayer ? /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		role: "status",
		children: [/* @__PURE__ */ d("h2", { children: i("games.vantage.gambleChoice") }), t.gamble ? /* @__PURE__ */ d("div", {
			className: "vantage-skill-row",
			children: Bs.filter((t) => e.challenge?.dice.includes(t)).map((e) => /* @__PURE__ */ f("button", {
				onClick: () => r({
					type: "chooseGamble",
					face: e
				}),
				children: [/* @__PURE__ */ d($, { kind: e }), i("games.vantage.refreshGambleFace", { face: i(Q[e]) })]
			}, e))
		}) : /* @__PURE__ */ d("p", { children: i("games.vantage.waitingGamble") })]
	}) : null;
}
function Hs(e) {
	let t = l(), n = or(e.me, e.priv.location);
	return !n.length || [
		"landing",
		"experience",
		"done"
	].includes(e.pub.phase) ? null : /* @__PURE__ */ f("section", {
		className: "vantage-paper vantage-sentients",
		children: [/* @__PURE__ */ d("h2", { children: t("games.vantage.sentientPowers") }), n.map((t) => t && /* @__PURE__ */ d(Us, {
			...e,
			card: t.card
		}, t.card))]
	});
}
function Us({ pub: e, priv: t, me: n, send: r, card: a }) {
	let o = l(), s = c((e) => e.locale), [p, m] = i([]), [h, g] = i([]), _ = cr(a), v = or(n, t.location).find((e) => e.card === a), y = e.active === n.rid, b = e.challenge, x = _ === "metal" ? 2 : 1, S = v.boost < x || !!e.skillRollPlayer || !!e.gamblePlayer || e.cardsPending, C = y && e.phase === "dice" ? b?.dice ?? [] : [], w = n.grid.filter((e) => e !== null), T = (e, t, n = {}, i = !1, o) => /* @__PURE__ */ d("button", {
		disabled: S || i,
		onClick: () => r({
			type: "sentientPower",
			card: a,
			power: e,
			indices: [],
			faces: [],
			...n
		}),
		children: t
	}, o ?? e), D = s === "zh" ? E[a].nameZh : E[a].name;
	return /* @__PURE__ */ f("details", { children: [/* @__PURE__ */ f("summary", { children: [
		a,
		" · ",
		D || o("games.vantage.card", { n: a }),
		" · ",
		o("games.vantage.powerBoostPrice", { n: x })
	] }), /* @__PURE__ */ f("div", {
		className: "vantage-power-options",
		children: [
			[
				"wind",
				"fire",
				"water"
			].includes(_) && T("protect", o("games.vantage.sentientProtect", { kind: o(Q[_ === "wind" ? "hypoxia" : _ === "fire" ? "cold" : "heat"]) })),
			_ === "wind" && w.flatMap((e) => Object.keys(e.dice).map((t) => T("refresh", o("games.vantage.sentientRefresh", {
				n: e.card,
				slot: Number(t) + 1
			}), {
				targetCard: e.card,
				slot: Number(t)
			}, !1, e.card + ":" + t))),
			_ === "fire" && T("skill", o("games.vantage.sentientRandomSkill")),
			lr[a] && T("gain", o("games.vantage.sentientGain", { n: lr[a] })),
			ur[a] && T("page", o("games.vantage.sentientPage", { n: ur[a] })),
			dr[a] && T("travel", o("games.vantage.sentientTravel", { n: dr[a] }), {}, ![
				"action",
				"cost",
				"dice",
				"story",
				"skirm",
				"arrival"
			].includes(e.phase)),
			_ === "circuit" && y && e.phase === "cost" && b && b.cost >= 3 && /* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d("p", { children: o("games.vantage.sentientUnique", { n: Math.min(b.cost, 5) }) }),
				/* @__PURE__ */ d("div", {
					className: "vantage-skill-row",
					children: Bs.map((e) => /* @__PURE__ */ f("label", { children: [
						/* @__PURE__ */ d("input", {
							type: "checkbox",
							checked: p.includes(e),
							onChange: (t) => m(t.target.checked ? [...p, e] : p.filter((t) => t !== e))
						}),
						/* @__PURE__ */ d($, { kind: e }),
						o(Q[e])
					] }, e))
				}),
				T("unique", o("games.vantage.confirmPreset"), { faces: p }, p.length !== Math.min(b.cost, 5) || e.presetFaces.length > 0)
			] }),
			_ === "gold" && y && e.phase === "dice" && T("gamble", o("games.vantage.sentientGamble"), {}, !b?.dice.length || b.dice.length !== b.cost || b.dice.some((e) => e === null) || b.dice.length >= 8 + 2 * e.players.length),
			_ === "energy" && /* @__PURE__ */ f(u, { children: [T("impact", o("games.vantage.sentientImpact"), {}, e.temporaryImpact.includes(a)), w.filter((e) => e.card !== a && (e.card === n.character || cr(e.card))).map((e) => T("boost", o("games.vantage.sentientBoost", { n: e.card }), { targetCard: e.card }, e.boost >= E[e.card].boostCapacity, e.card))] }),
			_ === "sinew" && y && T("stop", o("games.vantage.sentientStop")),
			_ === "metal" && w.filter((e) => e.card !== a && e.boost > 0).flatMap((e) => Object.entries(e.dice).map(([t, n]) => T("siphon", o("games.vantage.sentientSiphon", {
				n: e.card,
				slot: Number(t) + 1,
				face: o(Q[n])
			}), {
				targetCard: e.card,
				slot: Number(t)
			}, !1, e.card + ":" + t))),
			_ === "sand" && C.some((e) => e !== null) && /* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d("p", { children: o("games.vantage.sentientSand") }),
				/* @__PURE__ */ d("div", {
					className: "vantage-skill-row",
					children: C.map((e, t) => e !== null && /* @__PURE__ */ f("label", { children: [
						/* @__PURE__ */ d("input", {
							type: "checkbox",
							checked: h.includes(t),
							onChange: (e) => g(e.target.checked ? [...h, t] : h.filter((e) => e !== t))
						}),
						t + 1,
						" · ",
						/* @__PURE__ */ d($, { kind: e }),
						o(Q[e])
					] }, t))
				}),
				T("ignore", o("games.vantage.ignoreDice", { n: h.length }), { indices: h }, !h.length || h.some((e) => C[e] == null) || n.skills[b.skill] < h.length)
			] }),
			_ === "stone" && T("blank", o("games.vantage.sentientBlank")),
			_ === "leaf" && Ee(n.grid.indexOf(v)).flatMap((e) => {
				let t = n.grid[e];
				return t ? [T("boost", o("games.vantage.sentientBoost", { n: t.card }), { targetCard: t.card }, t.boost >= E[t.card].boostCapacity, t.card)] : [];
			}),
			_ === "water" && C.map((e, t) => e !== null && T("reroll", o("games.vantage.sentientReroll", { n: t + 1 }), { die: t }, !1, t)),
			_ === "wood" && /* @__PURE__ */ f(u, { children: [
				Object.values(E[t.location].exits).flatMap((e) => e.destination ? [T("scout", o("games.vantage.sentientScout", { n: e.destination }), { targetCard: e.destination }, !1, e.destination)] : []),
				O(t.location).filter((e) => e.hasCost && !["depart", "secrets"].includes(e.book)).map((e) => T("cost", o("games.vantage.sentientCost", { action: s === "zh" && e.printedZh ? e.printedZh : e.option || e.book }), { action: e.id }, !1, e.id)),
				/* @__PURE__ */ d("p", { children: o("games.vantage.sentientWoodReward") })
			] })
		]
	})] });
}
//#endregion
//#region src/games/vantage/path-stations.tsx
function Ws({ index: e }) {
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 40 40",
		width: "32",
		height: "32",
		"aria-hidden": "true",
		fill: "currentColor",
		stroke: "currentColor",
		strokeWidth: "4",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: e === 0 ? /* @__PURE__ */ d("circle", {
			cx: "20",
			cy: "21",
			r: "2"
		}) : e < 3 ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", { d: "M8 27H32" }), e === 2 && /* @__PURE__ */ d("circle", {
			cx: "20",
			cy: "12",
			r: "2"
		})] }) : e < 5 ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", { d: e === 3 ? "M8 21H32M20 9V33" : "M9 17L31 33M9 33L31 17" }), e === 4 && /* @__PURE__ */ d("circle", {
			cx: "20",
			cy: "7",
			r: "2"
		})] }) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", {
			fill: "none",
			d: e < 7 ? "M20 5L35 33H5Z" : "M7 7H33V33H7Z"
		}), e % 2 == 0 && /* @__PURE__ */ d("circle", {
			cx: "20",
			cy: "23",
			r: "2"
		})] })
	});
}
function Gs({ priv: e, canAct: t, send: n }) {
	let r = l(), [a, o] = i(!1);
	return e.pathQuest ? /* @__PURE__ */ f("div", {
		className: "vantage-path-stations",
		children: [
			/* @__PURE__ */ d("p", { children: r("games.vantage.pathStationInstructions") }),
			/* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
				type: "checkbox",
				checked: a,
				onChange: (e) => o(e.target.checked)
			}), r("games.vantage.confirmPathStation")] }),
			/* @__PURE__ */ d("div", {
				className: "vantage-power-options",
				children: Array.from({ length: 9 }, (i, s) => {
					let c = e.pathStations.some((e) => e.symbol === s);
					return /* @__PURE__ */ f("button", {
						"aria-label": r(c ? "games.vantage.pathStationRecorded" : "games.vantage.recordPathStation", { n: s + 1 }),
						disabled: !t || !a || c,
						onClick: () => {
							o(!1), n({
								type: "recordPathStation",
								symbol: s,
								condition: !0
							});
						},
						children: [/* @__PURE__ */ d(Ws, { index: s }), c ? "✓" : ""]
					}, s);
				})
			})
		]
	}) : null;
}
//#endregion
//#region src/games/vantage/personal-goals.tsx
function Ks({ priv: e, canAct: t, send: n, preview: r }) {
	let a = l(), [o, s] = i({}), [c, p] = i(!1), m = e.personalGoals;
	return !m.length && !e.canStartPearlDefense && !e.pearlDefense && !e.questProgress.length && !e.expiredQuests.length && !e.abandonableQuests.length && !e.storedBelongings.length ? null : /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			/* @__PURE__ */ d("h2", { children: a("games.vantage.personalGoals") }),
			/* @__PURE__ */ d(Gs, {
				priv: e,
				canAct: t,
				send: n
			}),
			e.canStartPearlDefense && /* @__PURE__ */ d("button", {
				disabled: !t,
				onClick: () => n({ type: "startPearlDefense" }),
				children: a("games.vantage.startPearlDefense")
			}),
			e.pearlDefense && /* @__PURE__ */ d("p", { children: a("games.vantage.pearlDefenseInstructions", { skills: e.pearlDefense.remaining.map((e) => a(Q[e])).join("、") }) }),
			e.storedBelongings.map((e, t) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("p", { children: a(e.returnOnLeave ? "games.vantage.weaponsStored" : "games.vantage.belongingsStored", { n: e.location }) }), e.cards.map((e) => /* @__PURE__ */ d("button", {
				onClick: () => r(e),
				children: a("games.vantage.card", { n: e })
			}, e))] }, "stored" + t)),
			e.expiredQuests.map((e) => /* @__PURE__ */ d("p", {
				role: "status",
				children: a("games.vantage.questExpired", { n: e })
			}, "expired" + e)),
			e.questProgress.map((e) => /* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d("button", {
					onClick: () => r(e.card),
					children: a("games.vantage.card", { n: e.card })
				}),
				/* @__PURE__ */ d("p", { children: a(e.kind === "timer" ? "games.vantage.questTimer" : e.kind === "journey" ? "games.vantage.questJourney" : e.kind === "underwater" ? "games.vantage.questUnderwater" : "games.vantage.questTokens", { n: e.tokens }) }),
				e.canRecord && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
					type: "checkbox",
					checked: c,
					onChange: (e) => p(e.target.checked)
				}), a("games.vantage.confirmUnderwater")] }), /* @__PURE__ */ d("button", {
					disabled: !t || !c,
					onClick: () => {
						p(!1), n({
							type: "recordQuestLocation",
							card: e.card,
							condition: !0
						});
					},
					children: a("games.vantage.recordUnderwater")
				})] })
			] }, "progress" + e.card)),
			m.map((e) => /* @__PURE__ */ f("div", { children: [
				/* @__PURE__ */ d("button", {
					onClick: () => r(e),
					children: a("games.vantage.card", { n: e })
				}),
				/* @__PURE__ */ d(Jo, { card: e }),
				/* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
					type: "checkbox",
					checked: o[e] ?? !1,
					onChange: (t) => s({
						...o,
						[e]: t.target.checked
					})
				}), a("games.vantage.confirmPersonalGoal")] }),
				/* @__PURE__ */ d("button", {
					disabled: !t || !o[e],
					onClick: () => {
						s({
							...o,
							[e]: !1
						}), n({
							type: "readPersonal",
							card: e,
							condition: !0
						});
					},
					children: a(e === 1682 ? "games.vantage.questPayCoins" : e === 1684 ? "games.vantage.questPaySkills" : e === 1685 ? "games.vantage.questGiveShoes" : "games.vantage.readPersonalGoal", { n: e })
				})
			] }, e)),
			e.abandonableQuests.map((e) => /* @__PURE__ */ d("button", {
				disabled: !t,
				onClick: () => n({
					type: "abandonQuest",
					card: e
				}),
				children: a("games.vantage.questAbandonShoes")
			}, "abandon" + e))
		]
	});
}
//#endregion
//#region src/games/vantage/arrival-panel.tsx
function qs({ pub: e, priv: t, me: n, send: r }) {
	let a = l(), o = t.arrival, [s, c] = i(""), [p, m] = i(""), [h, g] = i("");
	if (e.phase !== "arrival" || e.replenishment) return null;
	let _ = C.filter((e) => n.skills[e] > 0), v = n.grid.filter((e) => e && e.card !== n.character && !Dr(e.card)), y = _.find((e) => e === s) ?? _[0], b = v.find((e) => String(e?.card) === p) ?? v[0], x = o?.destinations.length === 1 ? o.destinations[0] : Number(h) || void 0, S = (e) => r({
		type: "resolveArrival",
		damage: e,
		skill: y,
		reserveCard: b?.card,
		destination: x
	});
	return /* @__PURE__ */ f("section", {
		className: "vantage-paper",
		children: [
			/* @__PURE__ */ d("h2", { children: o?.curse ? a("games.vantage.cursePenalty", { n: o.curse }) : a("games.vantage.arrivalPhase") }),
			e.arrivalSkills.map((e) => /* @__PURE__ */ f("button", {
				disabled: n.skills[e] < 1,
				onClick: () => r({
					type: "payArrival",
					skill: e
				}),
				children: [/* @__PURE__ */ d($, { kind: e }), a("games.vantage.payArrivalSkill", { skill: a(Q[e]) })]
			}, e)),
			o && /* @__PURE__ */ f(u, { children: [
				o.ignored ? /* @__PURE__ */ d("p", { children: a("games.vantage.arrivalIgnored") }) : o.kind === "damage" ? /* @__PURE__ */ d("p", { children: a("games.vantage.arrivalDamage", { kind: a(o.value === "heat" ? "games.vantage.heat" : o.value === "cold" ? "games.vantage.cold" : "games.vantage.hypoxia") }) }) : o.kind === "secret" ? /* @__PURE__ */ d("p", { children: a("games.vantage.effectSecret", { n: o.value }) }) : o.kind === "rollPool" || o.kind === "rollCenter" ? /* @__PURE__ */ d("p", { children: a(o.kind === "rollPool" ? "games.vantage.arrivalRollPool" : "games.vantage.arrivalRollCenter") }) : o.kind === "skill" ? /* @__PURE__ */ d("p", { children: a("games.vantage.arrivalLoseSkill") }) : o.kind === "reserve" ? /* @__PURE__ */ d("p", { children: a("games.vantage.arrivalReserve") }) : /* @__PURE__ */ d("p", { children: a(o.paid ? "games.vantage.arrivalPaid" : o.curse ? "games.vantage.curseLose" : "games.vantage.arrivalLose", { resource: a(Q[o.value === "coin" ? "coins" : o.value]) }) }),
				o.kind === "skill" && _.length > 0 && /* @__PURE__ */ f("label", { children: [a("games.vantage.chooseSkill"), /* @__PURE__ */ d("select", {
					value: y,
					onChange: (e) => c(e.target.value),
					children: _.map((e) => /* @__PURE__ */ d("option", {
						value: e,
						children: a(Q[e])
					}, e))
				})] }),
				o.kind === "reserve" && v.length > 0 && /* @__PURE__ */ f("label", { children: [a("games.vantage.chooseReserveCard"), /* @__PURE__ */ d("select", {
					value: b?.card,
					onChange: (e) => m(e.target.value),
					children: v.map((e) => e && /* @__PURE__ */ d("option", {
						value: e.card,
						children: a("games.vantage.card", { n: e.card })
					}, e.card))
				})] }),
				!o.curse && !o.ignored && !o.paid && o.value === "health" && ["stat", "payment"].includes(o.kind) && n.grid.some((e) => e?.card === 982 && e.boost > 0) && /* @__PURE__ */ d("button", {
					onClick: () => r({ type: "shieldArrival" }),
					children: a("games.vantage.shieldArrival")
				}),
				o.destinations.length > 0 && /* @__PURE__ */ f("label", { children: [a("games.vantage.arrivalForcedMove"), /* @__PURE__ */ f("select", {
					value: x ?? "",
					onChange: (e) => g(e.target.value),
					children: [/* @__PURE__ */ d("option", {
						value: "",
						disabled: !0,
						children: a("games.vantage.chooseDestination")
					}), o.destinations.map((e) => /* @__PURE__ */ d("option", {
						value: e,
						children: a("games.vantage.location", { n: e })
					}, e))]
				})] }),
				o.kind === "damage" && !o.ignored ? /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("button", {
					disabled: o.destinations.length > 0 && !x,
					onClick: () => S("health"),
					children: a("games.vantage.damageHealth", { n: 1 })
				}), /* @__PURE__ */ d("button", {
					disabled: o.destinations.length > 0 && !x,
					onClick: () => S("timeMorale"),
					children: a("games.vantage.damageTimeMorale", { n: 1 })
				})] }) : /* @__PURE__ */ d("button", {
					disabled: o.destinations.length > 0 && !x,
					onClick: () => S(),
					children: a(o.curse ? "games.vantage.resolveCurse" : "games.vantage.resolveArrival")
				})
			] })
		]
	});
}
//#endregion
//#region src/games/vantage/view-player.tsx
function Js() {
	return /* @__PURE__ */ d("svg", {
		className: "vantage-selection-outline",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ d("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "7",
			vectorEffect: "non-scaling-stroke"
		})
	});
}
function Ys(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ d(Xs, {
		...e,
		pub: t,
		priv: n
	});
}
function Xs({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let s = l(), h = c((e) => e.locale), [g, _] = i(r), [v, y] = i(null), [b, x] = i(null), [S, T] = i(null), [D, O] = i(""), [ee, te] = i(!1), [ne, re] = i(!1), [ie, k] = i(!1), [ae, oe] = i(null), [se, ce] = i(!1), [le, ue] = i(!1), A = e.players.find((e) => e.rid === r), j = e.players.find((e) => e.rid === g) ?? A, de = e.active === r, fe = (e) => n.find((t) => t.rid === e)?.name ?? e, M = (e) => a(e), pe = e.replenishment ? s("games.vantage.waitingReplenish", { name: fe(e.replenishment.rid) }) : e.cardClaims.some((e) => e.owner === r) ? s("games.vantage.decideCardOwnership") : e.phase === "launch" ? s("games.vantage.launchPhase") : e.phase === "landing" ? s("games.vantage.landing") : e.phase === "arrival" ? e.arrivalPlayer === r ? s(t?.arrival?.curse ? "games.vantage.cursePhase" : "games.vantage.arrivalPhase") : s("games.vantage.waitingArrival", { name: fe(e.arrivalPlayer ?? e.active) }) : de ? e.phase === "cost" ? s("games.vantage.cost") : e.phase === "dice" ? s("games.vantage.dice") : e.phase === "story" ? s("games.vantage.story") : e.phase === "experience" ? s("games.vantage.experiencePhase") : e.phase === "crisis" ? s("games.vantage.crisis") : s("games.vantage.chooseAction") : s("games.vantage.waiting", { name: fe(e.active) }), N = e.cardsPending || !!e.skillRollPlayer || !!e.gamblePlayer, he = v !== null && !N ? e.challenge?.dice[v] : null, ge = (e) => {
		if (e.kind === "puzzle") return s("games.vantage.beginPuzzle");
		if (e.kind === "miniSkills") return s("games.vantage.claimTournamentSkills");
		if (e.kind === "miniGame") return s("games.vantage.startTrial");
		if (e.kind === "miniCoins") return s("games.vantage.claimMiniCoins");
		if (e.kind === "challengeCheck") return s("games.vantage.rollStoryChallenge");
		if (e.kind === "departureLimit") return s("games.vantage.departureLimit");
		if (e.kind === "loseRememberedSkirm") return s("games.vantage.loseRecentSkirm");
		if (e.kind === "copyAction") return s("games.vantage.chooseCopiedAction");
		if (e.kind === "printedAbility") return s(Ro[e.value] ?? "games.vantage.abilityInstructions");
		if (e.kind === "testPickMany") return s("games.vantage.chooseTestSkills", { n: e.amount });
		if (e.kind === "crewLocations") return s("games.vantage.viewCrewLocations");
		if (e.kind === "testPickOne") return s("games.vantage.chooseTestSkill");
		if (e.kind === "matchingTestReward") return s("games.vantage.gainMatchingTest");
		if (e.kind === "preparation") return s("games.vantage.choosePreparation");
		if (e.kind === "selectedBoost") return s("games.vantage.boostSelectedCard");
		if (e.kind === "masterReward") return s("games.vantage.grantMasterReward");
		if (e.kind === "testCoins") return s("games.vantage.distinctTestCoins");
		if (e.kind === "animalAir") return s(e.value === "next" ? "games.vantage.animalAirNext" : "games.vantage.animalAirRecovery");
		if (e.kind === "trap") return s("games.vantage.rollTrapDice");
		if (e.kind === "replaceCard") return s("games.vantage.replaceWithCard", { n: e.value });
		if (e.kind === "boostMatching") return s("games.vantage.boostMatchingCards");
		if (e.kind === "structureTrade") return s(e.value.startsWith("sell:") ? "games.vantage.sellStructure" : e.value.startsWith("boost:") ? "games.vantage.structureBoostSale" : e.value.startsWith("token:") ? "games.vantage.structureTokenSale" : e.value.startsWith("card:") ? "games.vantage.structureCardSale" : "games.vantage.effectCoin", { n: e.amount });
		if (e.kind === "challengeReward") return s("games.vantage.rollChallengeReward");
		if (e.kind === "nextActionDiscount") return s("games.vantage.nextActionDiscount", { n: e.amount });
		if (e.kind === "makeShelter") return s("games.vantage.structureShelter");
		if (e.kind === "keepTestAll") return s("games.vantage.keepAllTestSkills");
		if (e.kind === "reserveVehicles") return s("games.vantage.reserveAllVehicles");
		if (e.kind === "dive") return s("games.vantage.protectedArrival", {
			n: e.value,
			kind: s("games.vantage." + ({
				1: "hypoxia",
				2: "cold",
				3: "heat"
			}[e.amount] ?? "hypoxia"))
		});
		if (e.kind === "gridRefresh") return s("games.vantage.gridRefreshLimit", { n: e.amount });
		if (e.kind === "runeBoost") return s("games.vantage.runeBoost");
		if (e.kind === "runeRoll") return s("games.vantage.rollRuneSkills", { n: e.amount });
		if (e.kind === "runeSkill") return s("games.vantage.gainRuneSkills", { n: e.amount });
		if (e.kind === "runeQuest") return s(e.amount ? "games.vantage.gainRuneQuest" : "games.vantage.runeQuestAlreadyHeld");
		if (e.kind === "barter") return s("games.vantage.chooseStoryTradeCards");
		if (e.kind === "coinCount") return s("games.vantage.gainCharacterMapCoins");
		if (e.kind === "partyStat") {
			let [t, n] = e.value.split(":");
			return s(t === "contributors" ? "games.vantage.contributingCrewStat" : t === "others" ? "games.vantage.otherCrewStat" : "games.vantage.allCrewStat", {
				n: e.amount,
				stat: s(Q[n])
			});
		}
		if (e.kind === "crewShare") return s("games.vantage.beginCrewSharing");
		if (e.kind === "crewLearn") return s("games.vantage.learnCrewSlots");
		if (e.kind === "stowCards") return s("games.vantage.stowValuedCards");
		if (e.kind === "keepTestSkill") return s("games.vantage.storyTestGainType", { skill: s(Q[e.value]) });
		if (e.kind === "removeCurses") return s("games.vantage.removeCurseLimit", { n: e.amount });
		if (e.kind === "sellCards") return s("games.vantage.sellCardLimit", { n: e.amount });
		if (e.kind === "sentientBoost") return s("games.vantage.boostAllSentients", { n: e.amount });
		if (e.kind === "cardInitialBoost") return s("games.vantage.gainCardWithBoost", {
			n: e.value,
			boost: e.amount
		});
		if (e.kind === "rest") return s("games.vantage.restRefresh", { n: e.amount });
		if (e.kind === "skillTest") return s("games.vantage.beginStoryTest");
		if (e.kind === "testStat" || e.kind === "testBoost") {
			let [t, n] = e.value.split(":");
			return s(e.amount < 0 ? "games.vantage.storyTestLoseStat" : "games.vantage.storyTestStat", {
				n: Math.abs(e.amount),
				stat: s(Q[t]),
				skill: s(Q[n])
			});
		}
		if (e.kind === "boostX") return s("games.vantage.effectBoost", { n: e.amount });
		if (e.kind === "coinX" || e.kind === "sourceCoin") return s("games.vantage.effectCoin", { n: e.amount });
		if (e.kind === "flight") return s("games.vantage.flyToRegionalSky");
		if (e.kind === "returnSky") return s("games.vantage.returnToTakeoff");
		if (e.kind === "dragonEscape") return s("games.vantage.escapeWithDragon");
		if (e.kind === "partySkill") {
			let [t, n] = e.value.split(":");
			return s(t === "others" ? "games.vantage.otherCrewSkill" : "games.vantage.allCrewSkill", {
				n: e.amount,
				skill: s(n === "random" ? "games.vantage.randomSkillName" : Q[n])
			});
		}
		return e.kind === "rewind" ? s("games.vantage.rewindAdventure") : e.kind === "upgradeVehicle" ? s("games.vantage.upgradeVehicle", { n: e.value }) : e.kind === "signal" ? s("games.vantage.transmitSignal") : e.kind === "missionPivot" ? s("games.vantage.adoptAlternativeGoal") : e.kind === "gardenTuck" ? s("games.vantage.tuckFlora", { n: e.value }) : e.kind === "gardenPluck" ? s("games.vantage.pluckFlora") : e.kind === "loseSkill" ? s("games.vantage.loseChosenSkill") : e.kind === "skillChoice" ? s("games.vantage.gainChosenSkill") : e.kind === "conquest" ? s("games.vantage.conquerCityPart") : e.kind === "questProgress" ? s(e.value === "flags" ? "games.vantage.questFlagProgress" : e.value === "teach" ? "games.vantage.questTeachProgress" : e.value === "herd" ? "games.vantage.questHerdProgress" : e.value === "siege" ? "games.vantage.questSiegeProgress" : e.value === "waterConquest" ? "games.vantage.questWaterConquestProgress" : "games.vantage.questPatrolProgress") : e.kind === "cardWithBoost" ? s("games.vantage.gainCardWithBoost", {
			n: e.value,
			boost: e.amount
		}) : e.kind === "cardIfMissing" ? s("games.vantage.gainCardIfMissing", { n: e.value }) : e.kind === "elemental" ? s(e.value === "prepare" ? "games.vantage.prepareElemental" : e.value === "siphon" ? "games.vantage.siphonElemental" : e.value === "summon" ? "games.vantage.summonElemental" : e.value === "start" ? "games.vantage.beginElemental" : e.value === "retreat" ? "games.vantage.retreatElemental" : "games.vantage.strikeElemental", { n: e.amount }) : e.kind === "boost" ? s(e.amount < 0 ? "games.vantage.effectLoseBoost" : "games.vantage.effectBoost", { n: Math.abs(e.amount) }) : e.kind === "coin" ? s(e.amount < 0 ? "games.vantage.effectLoseCoin" : "games.vantage.effectCoin", { n: Math.abs(e.amount) }) : e.kind === "skill" ? s(e.amount < 0 ? "games.vantage.effectLoseSkill" : "games.vantage.effectSkill", {
			n: Math.abs(e.amount),
			skill: s(Q[e.value])
		}) : e.kind === "stat" ? s("games.vantage.effectStat", {
			n: e.amount,
			stat: s(Q[e.value])
		}) : e.kind === "card" ? s("games.vantage.effectCard", { n: e.value }) : e.kind === "forbidLocation" ? s("games.vantage.forbidLocation", { n: e.value }) : e.kind === "completeCard" ? s("games.vantage.completePersonalCard") : e.kind === "loseCard" ? s("games.vantage.effectLoseCard", { n: e.value }) : e.kind === "location" || e.kind === "dungeon" ? s("games.vantage.effectLocation", { n: e.value }) : e.kind === "returnDungeon" ? s("games.vantage.returnDungeon") : e.kind === "obstacleMorale" ? s("games.vantage.obstacleMorale") : e.kind === "randomSkill" ? s("games.vantage.effectRandom", { n: e.amount }) : e.kind === "secret" ? s("games.vantage.effectSecret", { n: e.value }) : e.kind === "skirm" ? s("games.vantage.effectSkirm") : e.kind === "damage" ? s("games.vantage.effectDamage", { n: e.amount }) : e.kind === "rollSkill" ? s("games.vantage.effectRollSkill", {
			n: e.amount,
			skill: s(Q[e.value])
		}) : e.kind === "skillResult" ? s("games.vantage.rollSkillResult") : e.kind === "sentientTrial" ? s("games.vantage.rollSentientTrial", { n: e.amount }) : e.kind === "skirmCard" ? s("games.vantage.effectSkirmCard") : e.kind === "vantage" ? e.value === "region" ? s("games.vantage.effectRegionalVantage") : s("games.vantage.effectVantage", { n: e.value }) : e.kind === "end" ? s("games.vantage.effectEnd") : s("games.vantage.effectRefresh");
	}, _e = (e) => {
		let t = xe(e);
		return t ? s("games.vantage.curseName", {
			n: e,
			element: s(Wo[t])
		}) : (h === "zh" ? E[e]?.nameZh : E[e]?.name) || s("games.vantage.card", { n: e });
	}, ve = (n, i) => {
		let a = n.grid[i];
		if (!a) return /* @__PURE__ */ d("div", {
			className: "vantage-grid-empty",
			"aria-label": s("games.vantage.empty")
		}, i);
		let c = E[a.card];
		return /* @__PURE__ */ f("div", {
			className: "vantage-grid-card",
			"data-character": a.card === n.character,
			children: [
				/* @__PURE__ */ f("button", {
					className: "vantage-card-title",
					onClick: () => x(a.card),
					children: [/* @__PURE__ */ d("small", { children: a.card }), /* @__PURE__ */ d("strong", { children: _e(a.card) })]
				}),
				/* @__PURE__ */ d(Ko, {
					card: a.card,
					owner: n
				}),
				/* @__PURE__ */ d(Yo, { card: a.card }),
				a.card === 987 && /* @__PURE__ */ d("small", { children: s(a.rotated ? "games.vantage.hourglassInverted" : "games.vantage.hourglassUpright") }),
				Object.entries(a.skills ?? {}).map(([e, t]) => /* @__PURE__ */ d("small", { children: s("games.vantage.storedPowerSkill", {
					skill: s(Q[e]),
					n: t
				}) }, e)),
				a.growthAt !== void 0 && /* @__PURE__ */ d("small", { children: s("games.vantage.seedGrowthSite", { n: a.growthAt }) }),
				a.bonded && /* @__PURE__ */ d("span", {
					className: "vantage-bond",
					children: s("games.vantage.sentientBond")
				}),
				Dr(a.card) && /* @__PURE__ */ d(Jo, { card: a.card }),
				/* @__PURE__ */ f("div", {
					className: "vantage-card-boost",
					children: [
						/* @__PURE__ */ d("span", { children: s("games.vantage.boost") }),
						/* @__PURE__ */ d("b", { children: /* @__PURE__ */ d(o, { value: a.boost }) }),
						/* @__PURE__ */ f("span", { children: ["/", c.boostCapacity] })
					]
				}),
				n.rid === r && t && /* @__PURE__ */ d(ns, {
					card: a.card,
					priv: t,
					nameOf: fe,
					send: M
				}),
				/* @__PURE__ */ d("div", {
					className: "vantage-slots",
					children: c.slots.map((i) => {
						let o = a.dice[String(i.index)], l = Vr(c.id, i), u = i.impact || e.temporaryImpact.includes(c.id), p = a.bonded ? 0 : i.cost, m = !(c.id === 987 && a.rotated) && Gr(c.id, i.index, a.boost) && !N && e.phase === "dice" && de && he != null && a.boost >= p && (n.rid === r || (u ? e.impactPermission.includes(n.rid) : e.slotPermission.includes(n.rid) && (t?.coLocated.includes(n.rid) || e.summoning?.caller === r && e.summoning.summoned.includes(n.rid)))) && o === void 0 && !!e.challenge && !!t?.current && Hr(c.id, i, {
							id: t.current.id,
							source: t.current.source,
							skill: e.challenge.skill,
							untyped: e.challenge.untyped
						}, he, se, n, A);
						return /* @__PURE__ */ f("button", {
							className: "vantage-slot",
							"data-filled": o !== void 0,
							disabled: !m,
							"aria-label": s("games.vantage.slot", { n: i.index + 1 }),
							onClick: () => {
								v !== null && M({
									type: "placeDie",
									die: v,
									owner: n.rid,
									card: c.id,
									slot: i.index,
									condition: se
								});
							},
							children: [
								o === void 0 ? l ? /* @__PURE__ */ d(Go, { element: l }) : /* @__PURE__ */ d($, { kind: i.face || i.skill }) : /* @__PURE__ */ d("span", {
									className: "vantage-placed-die",
									children: /* @__PURE__ */ d($, { kind: o })
								}, o),
								m && /* @__PURE__ */ d(Js, {}),
								u && /* @__PURE__ */ d("span", {
									className: "vantage-impact",
									children: s("games.vantage.impact")
								}),
								i.ability && /* @__PURE__ */ d("small", { children: Rr(i.ability, h) }),
								i.reward > 0 && /* @__PURE__ */ d("span", {
									className: "vantage-slot-reward",
									children: i.reward
								}),
								i.rewardCard && /* @__PURE__ */ d("small", { children: s("games.vantage.effectCard", { n: i.rewardCard }) }),
								p > 0 && /* @__PURE__ */ d("small", { children: s("games.vantage.slotBoostCost", { n: p }) })
							]
						}, i.index);
					})
				}),
				n.rid === r && (t?.pendingCards.length ?? 0) > 0 && i !== 4 && !Dr(a.card) && ![
					1103,
					1104,
					1105,
					1106
				].includes(a.card) && /* @__PURE__ */ d("button", {
					className: "vantage-card-manage",
					onClick: () => M({
						type: "reserveCard",
						card: a.card
					}),
					children: s("games.vantage.reserveFromGrid")
				})
			]
		}, `${i}:${a.card}`);
	};
	return /* @__PURE__ */ f("div", {
		className: "vantage-screen",
		children: [
			/* @__PURE__ */ d(p, {
				adaptive: !0,
				scroll: !1,
				banner: /* @__PURE__ */ f("div", {
					className: "vantage-header",
					children: [/* @__PURE__ */ d(m, {
						tone: de || e.phase === "landing" ? "accent" : "info",
						text: pe,
						chip: s("games.vantage.round", { n: e.round }),
						accent: "#355e70"
					}), /* @__PURE__ */ f("div", {
						className: "vantage-crew",
						children: [e.players.map((t) => /* @__PURE__ */ f("button", {
							className: "vantage-crew-member",
							"data-active": e.active === t.rid,
							"data-selected": j?.rid === t.rid,
							onClick: () => _(t.rid),
							children: [/* @__PURE__ */ d("strong", { children: fe(t.rid) }), /* @__PURE__ */ d("span", { children: w.map((e) => /* @__PURE__ */ f("span", {
								className: "vantage-stat",
								children: [/* @__PURE__ */ d($, {
									kind: e,
									size: 15
								}), /* @__PURE__ */ d("b", { children: /* @__PURE__ */ d(o, { value: t.stats[e] }, t.rid) })]
							}, e)) })]
						}, t.rid)), /* @__PURE__ */ f("div", {
							className: "vantage-dice-pool",
							children: [/* @__PURE__ */ d("span", { children: s("games.vantage.pool", { n: e.pool }) }), /* @__PURE__ */ d("small", { children: s("games.vantage.penaltyPool", { n: e.penaltyDice }) })]
						})]
					})]
				}),
				actionsHeight: "h-16",
				actions: /* @__PURE__ */ f("div", {
					className: "vantage-footer",
					children: [t && A && e.phase === "landing" && !A.landingReady ? /* @__PURE__ */ d("button", {
						className: "vantage-primary",
						onClick: () => M({ type: "confirmLanding" }),
						children: s("games.vantage.confirmLanding")
					}) : de && e.phase === "cost" ? /* @__PURE__ */ d("button", {
						className: "vantage-primary",
						disabled: N || !t?.current || Number(t.current.cost) < 0 || t.actionBonus?.chooseIgnore || t.bonusChoiceNeeded,
						onClick: () => M({ type: "roll" }),
						children: s("games.vantage.roll")
					}) : de && e.phase === "dice" ? /* @__PURE__ */ d("button", {
						className: "vantage-primary",
						disabled: N,
						onClick: () => {
							M({ type: "penalties" }), y(null);
						},
						children: s("games.vantage.resolveDice")
					}) : de && e.phase === "story" && t?.passage && !t.passage.choices.length ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("button", {
						className: "vantage-primary",
						disabled: N || !!t.puzzle && t.puzzle.stage !== "done" || !!t.storyTest && !t.storyTest.done || t.needsReserveRoom || t.passage.blocked || e.deliveryRecipients.length > 0 || e.cardClaims.length > 0 || t.pendingCards.length > 0 || t.passage.effects.some((e) => !e.applied) || !t.passage.hasFollowing && t.canContinue === "must",
						onClick: () => M({
							type: "finishStory",
							continue: !1
						}),
						children: s(t.passage.hasFollowing ? "games.vantage.continueReading" : t.pearlDefense?.active ? "games.vantage.continuePearlDefense" : t.passage.returnsToAction || e.launch ? "games.vantage.returnToAction" : "games.vantage.finishStory")
					}), !t.passage.hasFollowing && t.canContinue !== "no" && /* @__PURE__ */ d("button", {
						className: "vantage-primary",
						disabled: N || !!t.puzzle && t.puzzle.stage !== "done" || !!t.storyTest && !t.storyTest.done || t.needsReserveRoom || t.passage.blocked || e.deliveryRecipients.length > 0 || e.cardClaims.length > 0 || t.pendingCards.length > 0 || t.passage.effects.some((e) => !e.applied),
						onClick: () => M({
							type: "finishStory",
							continue: !0
						}),
						children: s("games.vantage.continue")
					})] }) : /* @__PURE__ */ d("span", { children: pe }), /* @__PURE__ */ d("button", {
						className: "vantage-end",
						onClick: () => M({ type: "endAdventure" }),
						children: s("games.vantage.endAdventure")
					})]
				}),
				children: /* @__PURE__ */ f("div", {
					className: "vantage-layout",
					children: [/* @__PURE__ */ d("main", {
						className: "vantage-vantage",
						children: !t || !A ? /* @__PURE__ */ d("p", { children: s("games.vantage.noPrivate") }) : /* @__PURE__ */ f(u, { children: [
							/* @__PURE__ */ d(Lo, {
								pub: e,
								priv: t,
								me: A,
								send: M
							}),
							t.location >= 2 && /* @__PURE__ */ f("section", {
								className: "vantage-location",
								children: [
									/* @__PURE__ */ f("div", {
										className: "vantage-section-heading",
										children: [
											/* @__PURE__ */ d("span", { children: s("games.vantage.privateLocation") }),
											/* @__PURE__ */ d(Ko, { card: t.location }),
											/* @__PURE__ */ d("strong", { children: s("games.vantage.location", { n: t.location }) })
										]
									}),
									/* @__PURE__ */ d("button", {
										className: "vantage-location-image",
										onClick: () => x(t.location),
										"aria-label": s("games.vantage.location", { n: t.location }),
										children: /* @__PURE__ */ d(Fo, {
											src: `games/vantage/live/cards/${t.location}.webp`,
											alt: s("games.vantage.location", { n: t.location }),
											draggable: !1
										})
									}),
									/* @__PURE__ */ d("div", {
										className: "vantage-location-caption",
										children: /* @__PURE__ */ d(Jo, { card: t.location })
									})
								]
							}, `location-${t.location}`),
							e.phase === "landing" && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								children: [
									/* @__PURE__ */ d("h2", { children: s("games.vantage.landingDice") }),
									/* @__PURE__ */ d("div", {
										className: "vantage-skill-row",
										children: t.landingDice?.map((e, t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: e }), s(Q[e])] }, t))
									}),
									t.landingRerollAllowed && !A.landingReady && /* @__PURE__ */ d("button", {
										onClick: () => M({ type: "rerollLanding" }),
										children: s("games.vantage.rerollLanding")
									}),
									t.missionDice && /* @__PURE__ */ f(u, { children: [
										/* @__PURE__ */ d("h2", { children: s("games.vantage.missionDice") }),
										/* @__PURE__ */ d("div", {
											className: "vantage-skill-row",
											children: t.missionDice.map((e, t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: e }), s(Q[e])] }, t))
										}),
										t.missionDice[0] === t.missionDice[1] && !e.players.some((e) => e.landingReady) && /* @__PURE__ */ d("button", {
											onClick: () => M({ type: "rerollMission" }),
											children: s("games.vantage.rerollMission")
										})
									] })
								]
							}),
							t.elemental && /* @__PURE__ */ d(zo, {
								battle: t.elemental,
								preview: x
							}, `elemental-${t.elemental.location}`),
							de && e.phase === "action" && /* @__PURE__ */ f("section", {
								className: "vantage-actions-list",
								children: [
									t.nextActionDiscount > 0 && /* @__PURE__ */ d("p", { children: s("games.vantage.nextActionDiscount", { n: t.nextActionDiscount }) }),
									t.options.some((t) => Wr(A, t.id, t.source, e.mission === 1593 && !e.missionDone)) && /* @__PURE__ */ d(as, {
										value: D,
										change: O
									}),
									t.options.some((e) => e.water) && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
										type: "checkbox",
										checked: ee,
										onChange: (e) => te(e.target.checked)
									}), s("games.vantage.confirmFishingWater")] }),
									t.options.some((e) => e.id === "h1695:0") && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
										type: "checkbox",
										checked: ne,
										onChange: (e) => re(e.target.checked)
									}), s("games.vantage.confirmFireSentient")] }),
									t.options.some((e) => e.id === "o1642:0") && /* @__PURE__ */ f("label", { children: [/* @__PURE__ */ d("input", {
										type: "checkbox",
										checked: ie,
										onChange: (e) => k(e.target.checked)
									}), s("games.vantage.confirmLandLocation")] }),
									t.options.length === 0 && /* @__PURE__ */ d("p", { children: s("games.vantage.noActions") }),
									t.options.map((t) => /* @__PURE__ */ d(Qo, {
										option: t,
										disabled: N || Wr(A, t.id, t.source, e.mission === 1593 && !e.missionDone) && !D || t.id === "h1695:0" && !ne || t.id === "o1642:0" && !ie || t.water && !ee,
										choose: () => {
											ue(!1), M({
												type: "chooseAction",
												id: t.id,
												sentientInteraction: D ? D === "yes" : void 0,
												condition: t.condition ? !0 : t.water ? ee : t.id === "h1695:0" ? ne : t.id === "o1642:0" ? ie : void 0
											}), O(""), re(!1), te(!1), k(!1);
										}
									}, t.id))
								]
							}),
							de && e.phase === "cost" && t.current && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								children: [
									/* @__PURE__ */ d("h2", { children: h === "zh" && t.current.labelZh ? t.current.labelZh : t.current.label }),
									t.powerTravel && /* @__PURE__ */ d("p", { children: s("games.vantage.rideChooseX") }),
									Number(t.current.cost) < 0 ? /* @__PURE__ */ d("div", {
										className: "vantage-cost-options",
										children: [
											1,
											2,
											3,
											4,
											5,
											6
										].map((e) => /* @__PURE__ */ d("button", {
											onClick: () => M({
												type: "chooseCost",
												cost: e
											}),
											children: e
										}, e))
									}) : /* @__PURE__ */ d("strong", {
										className: "vantage-cost",
										children: s("games.vantage.costN", { n: t.current.cost })
									}),
									e.challenge && !e.challenge.untyped && /* @__PURE__ */ f("div", {
										className: "vantage-skill-row",
										children: [/* @__PURE__ */ d($, { kind: e.challenge.skill }), /* @__PURE__ */ d("span", { children: s(Q[e.challenge.skill]) })]
									}),
									t.actionBonus && /* @__PURE__ */ d(Ss, {
										bonus: t.actionBonus,
										phase: e.phase,
										dice: e.challenge?.dice ?? [],
										selected: v,
										waiting: N,
										send: M
									}),
									!!t.bonusDice.length && /* @__PURE__ */ d(Cs, {
										dice: t.bonusDice,
										cost: Number(t.current.cost) < 0 ? -1 : e.challenge?.rollCount ?? Number(t.current.cost),
										chosen: t.bonusSelection,
										waiting: N,
										send: M
									}, String(e.challenge?.rollCount)),
									t.current.canClearObstacle && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("label", {
										className: "vantage-condition",
										children: [/* @__PURE__ */ d("input", {
											type: "checkbox",
											checked: le,
											onChange: (e) => ue(e.target.checked)
										}), s("games.vantage.confirmObstacleCleared")]
									}), /* @__PURE__ */ d("button", {
										disabled: !le || Number(t.current.cost) < 1,
										onClick: () => M({
											type: "clearObstacle",
											condition: !0
										}),
										children: s("games.vantage.clearObstacle")
									})] }),
									t.current.canPayCoin && /* @__PURE__ */ d("button", {
										disabled: N || e.presetFaces.length > 0 || A.coins < t.current.coinPrice,
										onClick: () => M({ type: "contributeCoin" }),
										children: s(t.current.coinDiscount === "one" ? "games.vantage.contributeCoin" : t.current.coinDiscount === "zero" ? "games.vantage.payZeroAction" : "games.vantage.payGateHealth", { n: t.current.coinPrice })
									})
								]
							}),
							e.phase === "cost" && e.challenge && /* @__PURE__ */ d("button", {
								className: "vantage-contribute",
								disabled: N || e.presetFaces.length > 0 || e.challenge.cost < 1 || A.skills[e.challenge.skill] < 1 && t.actionEngage < 1,
								onClick: () => M({ type: "contribute" }),
								children: s("games.vantage.contribute")
							}),
							e.phase === "dice" && e.challenge && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								children: [
									de && t.actionBonus && /* @__PURE__ */ d(Ss, {
										bonus: t.actionBonus,
										phase: e.phase,
										dice: e.challenge.dice,
										selected: v,
										waiting: N,
										send: M
									}),
									t.elementalReroll && /* @__PURE__ */ d("button", {
										disabled: N,
										onClick: () => M({ type: "rerollElemental" }),
										children: s("games.vantage.elementalReroll")
									}),
									/* @__PURE__ */ d("div", {
										className: "vantage-rolled",
										children: e.challenge.dice.map((e, t) => e === null ? /* @__PURE__ */ d("span", { className: "vantage-die-used" }, t) : /* @__PURE__ */ f("button", {
											className: "vantage-die",
											"data-selected": v === t,
											"aria-pressed": v === t,
											disabled: !de || N,
											onClick: () => y(t),
											"aria-label": s(Q[e]),
											children: [
												/* @__PURE__ */ d($, {
													kind: e,
													size: 32
												}),
												/* @__PURE__ */ d("small", { children: s(Q[e]) }),
												v === t && /* @__PURE__ */ d(Js, {})
											]
										}, t))
									}, e.eventSeq),
									de && he != null && v !== null && /* @__PURE__ */ f(u, { children: [
										/* @__PURE__ */ d("p", { children: s("games.vantage.selectedDie", { n: v + 1 }) }),
										/* @__PURE__ */ d("button", {
											disabled: (A.grid[4]?.boost ?? 0) < 1,
											onClick: () => M({
												type: "rerollDie",
												die: v
											}),
											children: s(me(A.character) === "armor" ? "games.vantage.refreshUnplaced" : me(A.character) === "survivor" ? "games.vantage.rerollDifferent" : "games.vantage.rerollDie")
										}),
										/* @__PURE__ */ f("label", {
											className: "vantage-condition",
											children: [/* @__PURE__ */ d("input", {
												type: "checkbox",
												checked: se,
												onChange: (e) => ce(e.target.checked)
											}), s("games.vantage.conditionalSlot")]
										})
									] })
								]
							}),
							/* @__PURE__ */ d(es, {
								pub: e,
								me: A,
								waiting: N,
								send: M
							}),
							de && e.phase === "story" && t.passage && /* @__PURE__ */ f("section", {
								className: "vantage-paper vantage-story",
								children: [
									/* @__PURE__ */ d("p", {
										className: "vantage-prose",
										children: h === "zh" && t.passage.zh ? t.passage.zh : t.passage.text
									}),
									!!t.bonusDice.length && /* @__PURE__ */ d(Cs, {
										dice: t.bonusDice,
										cost: null,
										chosen: null,
										waiting: N,
										send: M
									}),
									t.passage.blocked && /* @__PURE__ */ d("p", {
										className: "vantage-unadapted",
										role: "status",
										children: s("games.vantage.unadapted")
									}),
									t.needsReserveRoom && /* @__PURE__ */ d("p", {
										role: "status",
										children: s("games.vantage.errReserveFull")
									}),
									/* @__PURE__ */ d(js, {
										priv: t,
										player: A,
										players: e.players,
										nameOf: fe,
										playerCount: e.players.length,
										waiting: N,
										character: A.character,
										send: M,
										label: ge,
										showBook: T
									}, t.passage.text),
									t.skillResult && t.passage.choices.length > 0 && /* @__PURE__ */ f("p", {
										role: "status",
										children: [/* @__PURE__ */ d($, { kind: t.skillResult }), s("games.vantage.skillResult", { skill: s(Q[t.skillResult]) })]
									}),
									t.previewedOutcome && /* @__PURE__ */ f("details", { children: [/* @__PURE__ */ d("summary", { children: s("games.vantage.previewedOutcome") }), /* @__PURE__ */ d("p", { children: h === "zh" ? t.previewedOutcome.zh ?? t.previewedOutcome.text : t.previewedOutcome.text })] }),
									t.passage.choices.map((n, r) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d($o, {
										conditionLabel: n,
										label: h === "zh" ? t.passage.choicesZh?.[r] ?? n : n,
										disabled: N || !!t.puzzle && t.puzzle.stage !== "done" || !!t.storyTest && !t.storyTest.done || t.needsReserveRoom || t.passage.blocked || e.deliveryRecipients.length > 0 || e.cardClaims.length > 0 || t.pendingCards.length > 0 || !t.passage.allowedChoices.includes(r) || !t.passage.payableChoices.includes(r) || t.passage.effects.some((e) => !e.applied),
										choose: (e) => M({
											type: "chooseBranch",
											index: r,
											condition: e
										})
									}), e.players.length > 1 && t.passage.skillPaymentChoices.includes(r) && /* @__PURE__ */ d("button", {
										disabled: N || !t.passage.allowedChoices.includes(r) || t.passage.effects.some((e) => !e.applied),
										onClick: () => M({
											type: "requestStoryPayment",
											index: r
										}),
										children: s("games.vantage.storyPaymentAsk")
									})] }, t.passage.text + n))
								]
							}, t.passage.text),
							t.needsReserveRoom && /* @__PURE__ */ d("p", {
								role: "status",
								children: s("games.vantage.errReserveFull")
							}),
							t.runeFaces.length > 0 && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								"aria-live": "polite",
								children: [/* @__PURE__ */ d("h3", { children: s("games.vantage.runeFinalDice") }), /* @__PURE__ */ d("div", {
									className: "vantage-skill-row",
									children: t.runeFaces.map((e, t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: e }), s(Q[e])] }, t))
								})]
							}),
							de && t.miniGame && /* @__PURE__ */ d(vs, {
								game: t.miniGame,
								coins: A?.coins ?? 0,
								waiting: !!e.skillRollPlayer,
								send: M
							}),
							de && t.puzzle && /* @__PURE__ */ d(bs, {
								puzzle: t.puzzle,
								waiting: N,
								send: M
							}, `puzzle-${t.puzzle.id}`),
							de && e.phase === "story" && /* @__PURE__ */ d(us, {
								priv: t,
								me: A,
								rolling: !!e.skillRollPlayer,
								send: M
							}),
							/* @__PURE__ */ d(ws, {
								pub: e,
								rid: r,
								send: M
							}),
							/* @__PURE__ */ d(Ds, {
								pub: e,
								priv: t,
								me: A,
								waiting: N,
								nameOf: fe,
								send: M
							}),
							/* @__PURE__ */ d(Os, {
								pub: e,
								rid: r,
								send: M
							}),
							/* @__PURE__ */ d(Vs, {
								pub: e,
								priv: t,
								me: A,
								send: M
							}),
							t.sentientTrial && !t.sentientTrial.remaining && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								role: "status",
								children: [
									/* @__PURE__ */ d("h2", { children: s("games.vantage.sentientTrialResult") }),
									/* @__PURE__ */ d("div", {
										className: "vantage-skill-row",
										children: t.sentientTrial.faces.map((e, t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: e }), s(Q[e])] }, t))
									}),
									/* @__PURE__ */ d("p", { children: s(t.sentientTrial.success ? t.sentientTrial.bond ? "games.vantage.sentientBond" : "games.vantage.sentientTrialBoost" : "games.vantage.sentientTrialFailed") })
								]
							}),
							/* @__PURE__ */ d(zs, {
								pub: e,
								priv: t,
								myRid: r,
								nameOf: fe,
								send: M
							}),
							/* @__PURE__ */ d(Bo, {
								pub: e,
								priv: t,
								me: A,
								nameOf: fe,
								send: M
							}),
							/* @__PURE__ */ d(Ls, {
								pub: e,
								priv: t,
								me: A,
								nameOf: fe,
								send: M
							}),
							de && ["action", "story"].includes(e.phase) && /* @__PURE__ */ d(Ks, {
								priv: t,
								canAct: e.phase === "action" && !N,
								send: M,
								preview: x
							}),
							t.experience.map((e) => /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								children: [
									/* @__PURE__ */ d("h2", { children: s("games.vantage.experienceFull", { n: e }) }),
									/* @__PURE__ */ d("p", { children: s("games.vantage.experienceResolution") }),
									/* @__PURE__ */ d("button", {
										onClick: () => M({
											type: "resolveExperience",
											card: e,
											replace: !0
										}),
										children: s("games.vantage.becomeSurvivor")
									}),
									/* @__PURE__ */ d("button", {
										onClick: () => M({
											type: "resolveExperience",
											card: e,
											replace: !1
										}),
										children: s("games.vantage.keepCharacter")
									})
								]
							}, e)),
							t.pendingCards.map((e) => /* @__PURE__ */ d(Rs, {
								id: e,
								me: A,
								priv: t,
								name: _e(e),
								preview: () => x(e),
								send: M
							}, e)),
							e.phase === "skirm" && /* @__PURE__ */ d(Uo, {
								pub: e,
								priv: t,
								myRid: r,
								send: M
							}),
							/* @__PURE__ */ d(qs, {
								pub: e,
								priv: t,
								me: A,
								send: M
							}, t.location + ":" + t.arrival?.kind + ":" + t.arrival?.value),
							e.phase === "crisis" && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								children: [
									/* @__PURE__ */ d("h2", { children: s("games.vantage.crisis") }),
									/* @__PURE__ */ d("p", { children: t.crisisText }),
									de && !e.rescue && /* @__PURE__ */ d("button", {
										onClick: () => M({ type: "endCrisis" }),
										children: s(e.missionDone ? "games.vantage.endMissionVictory" : "games.vantage.acceptJourneyEnd")
									}),
									de && !t.lastChanceUsed && /* @__PURE__ */ d("button", {
										onClick: () => M({ type: "lastChance" }),
										children: s("games.vantage.lastChance")
									}),
									e.rescue && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h3", { children: s("games.vantage.rescueRemaining") }), w.map((t) => /* @__PURE__ */ f("div", { children: [
										/* @__PURE__ */ d($, { kind: t }),
										/* @__PURE__ */ d("b", { children: e.rescue[t] }),
										de && e.rescue[t] > 0 && e.players.map((e) => /* @__PURE__ */ d("button", {
											onClick: () => M({
												type: "assignRescue",
												stat: t,
												target: e.rid
											}),
											children: s("games.vantage.assignRescue", {
												stat: s(Q[t]),
												name: fe(e.rid)
											})
										}, e.rid))
									] }, t))] })
								]
							}),
							t.bookPages.length > 0 && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								children: [/* @__PURE__ */ d("h2", { children: s("games.vantage.bookOfVantages") }), t.bookPages.map((e) => /* @__PURE__ */ d("button", {
									onClick: () => T(e),
									children: s("games.vantage.bookPage", { n: e })
								}, e))]
							}),
							(t.scouted.length > 0 || t.revealedCosts.length > 0) && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								children: [
									/* @__PURE__ */ d("h2", { children: s("games.vantage.scoutedInformation") }),
									t.scouted.map((e) => /* @__PURE__ */ d("button", {
										onClick: () => x(e),
										children: s("games.vantage.viewScouted", { n: e })
									}, e)),
									t.revealedCosts.map((e) => /* @__PURE__ */ f("p", { children: [
										h === "zh" && e.labelZh ? e.labelZh : e.label,
										" · ",
										s("games.vantage.costN", { n: e.cost })
									] }, e.id))
								]
							}),
							t.protection.length > 0 && /* @__PURE__ */ d("section", {
								className: "vantage-paper",
								role: "status",
								children: t.protection.map((e, t) => /* @__PURE__ */ d("p", { children: s("games.vantage.protectionRemaining", {
									kind: s(Q[e.kind]),
									n: e.amount
								}) }, t))
							}),
							/* @__PURE__ */ f("details", {
								className: "vantage-paper",
								children: [
									/* @__PURE__ */ d("summary", { children: s("games.vantage.notes") }),
									/* @__PURE__ */ d("textarea", {
										value: ae ?? t.notes,
										onChange: (e) => oe(e.target.value),
										maxLength: 3e3,
										placeholder: s("games.vantage.notesPlaceholder")
									}),
									/* @__PURE__ */ d("button", {
										onClick: () => {
											M({
												type: "setNotes",
												text: ae ?? t.notes
											}), oe(null);
										},
										children: s("games.vantage.saveNotes")
									})
								]
							})
						] })
					}), /* @__PURE__ */ f("aside", {
						className: "vantage-board",
						children: [
							A && e.summoning?.caller === r && e.summoning.solo && /* @__PURE__ */ f("section", {
								className: "vantage-paper",
								children: [/* @__PURE__ */ d("h2", { children: s("games.vantage.summonedCharacter") }), ve({
									...A,
									character: e.summoning.solo.card,
									grid: Array.from({ length: 9 }, (t, n) => n === 4 ? e.summoning.solo : null)
								}, 4)]
							}),
							t && /* @__PURE__ */ d(is, {
								priv: t,
								nameOf: fe,
								send: M,
								preview: x
							}),
							j && /* @__PURE__ */ f(u, { children: [
								/* @__PURE__ */ f("h2", { children: [
									fe(j.rid),
									" · ",
									s("games.vantage.grid")
								] }),
								/* @__PURE__ */ d("div", {
									className: "vantage-grid",
									children: j.grid.map((e, t) => ve(j, t))
								}),
								/* @__PURE__ */ f("div", {
									className: "vantage-resources",
									children: [/* @__PURE__ */ f("span", { children: [
										s("games.vantage.coins"),
										" ",
										/* @__PURE__ */ d("b", { children: /* @__PURE__ */ d(o, { value: j.coins }, j.rid) })
									] }), C.map((e) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, {
										kind: e,
										size: 18
									}), /* @__PURE__ */ d("b", { children: /* @__PURE__ */ d(o, { value: j.skills[e] }, j.rid) })] }, e))]
								}),
								j.rid === r && e.phase !== "launch" && /* @__PURE__ */ f("div", {
									className: "vantage-boost-powers",
									children: [me(j.character) !== "armor" && /* @__PURE__ */ d("button", {
										disabled: N || (A?.grid[4]?.boost ?? 0) < 2,
										onClick: () => M({
											type: "boost",
											power: "coin"
										}),
										children: s("games.vantage.boostCoin")
									}), /* @__PURE__ */ d("button", {
										disabled: N || (A?.grid[4]?.boost ?? 0) < 2,
										onClick: () => M({
											type: "boost",
											power: "move"
										}),
										children: s("games.vantage.boostMove")
									})]
								}),
								j.rid === r && t && A && /* @__PURE__ */ d(ls, {
									pub: e,
									priv: t,
									me: A,
									selectedDie: v,
									send: M
								}),
								j.rid === r && t && A && /* @__PURE__ */ d(os, {
									pub: e,
									priv: t,
									me: A,
									send: M
								}),
								j.rid === r && t && A && /* @__PURE__ */ d(ss, {
									pub: e,
									priv: t,
									me: A,
									send: M
								}),
								j.rid === r && t && A && /* @__PURE__ */ d(Hs, {
									pub: e,
									priv: t,
									me: A,
									send: M
								}),
								/* @__PURE__ */ f("div", {
									className: "vantage-card-row",
									children: [/* @__PURE__ */ d("h3", { children: s("games.vantage.reserveCount", {
										n: j.reserve.length + +!!j.skirm.length,
										max: jr(j)
									}) }), j.reserve.map((e) => /* @__PURE__ */ f("div", { children: [
										/* @__PURE__ */ f("button", {
											onClick: () => x(e.card),
											children: [
												e.card,
												" · ",
												_e(e.card),
												" ",
												/* @__PURE__ */ d(Yo, { card: e.card }),
												e.hiddenAt !== void 0 && /* @__PURE__ */ d("small", { children: s("games.vantage.hiddenGatewayItem") })
											]
										}),
										j.rid === r && ((t?.pendingCards.length ?? 0) > 0 || t?.needsReserveRoom) && /* @__PURE__ */ d("button", {
											onClick: () => M({
												type: "releaseCard",
												card: e.card
											}),
											children: s("games.vantage.discard")
										}),
										j.rid === r && e.hiddenAt === void 0 && !t?.passage?.effects.some((e) => e.kind === "stowCards" && !e.applied) && A?.grid.map((t, n) => n !== 4 && /* @__PURE__ */ d("button", {
											disabled: N || (A.grid[4]?.boost ?? 0) < 1 || Dr(A.grid[n]?.card ?? 0) || [
												1103,
												1104,
												1105,
												1106
											].includes(A.grid[n]?.card ?? 0),
											onClick: () => M({
												type: "boost",
												power: "reserve",
												card: e.card,
												cell: n
											}),
											children: s("games.vantage.transferReserve", { n: n + 1 })
										}, n))
									] }, e.card))]
								}),
								j.skirm.length > 0 && /* @__PURE__ */ f("div", {
									className: "vantage-card-row",
									children: [
										/* @__PURE__ */ d("h3", { children: s("games.vantage.skirmCollection", { n: j.skirm.length }) }),
										j.skirm.map((e) => /* @__PURE__ */ f("span", { children: [
											"S",
											String(e).padStart(3, "0"),
											" "
										] }, e)),
										j.rid === r && ((t?.pendingCards.length ?? 0) > 0 || t?.needsReserveRoom) && /* @__PURE__ */ d("button", {
											onClick: () => M({ type: "discardSkirmCollection" }),
											children: s("games.vantage.discardSkirmCollection")
										})
									]
								}),
								j.supply.length > 0 && /* @__PURE__ */ f("div", {
									className: "vantage-card-row",
									children: [/* @__PURE__ */ d("h3", { children: s("games.vantage.supply") }), j.supply.map((e) => /* @__PURE__ */ f("button", {
										onClick: () => x(e.card),
										children: [
											e.card,
											" · ",
											_e(e.card),
											" ",
											/* @__PURE__ */ d(Yo, { card: e.card }),
											/* @__PURE__ */ f("span", {
												className: "vantage-supply-details",
												children: [
													E[e.card].boostCapacity > 0 && /* @__PURE__ */ d("small", { children: s("games.vantage.supplyBoost", { n: e.boost }) }),
													!!e.tucked?.length && /* @__PURE__ */ d("small", { children: s("games.vantage.tuckedFlora", { cards: e.tucked.map((e) => e.card).join(" · ") }) }),
													e.asylumAt !== void 0 && /* @__PURE__ */ d("small", { children: s("games.vantage.asylumLocation", { n: e.asylumAt }) }),
													e.shelter && /* @__PURE__ */ d("small", { children: s("games.vantage.shelter") }),
													e.origin !== void 0 && /* @__PURE__ */ d("small", { children: s("games.vantage.siteLocation", { n: e.origin }) })
												]
											})
										]
									}, e.card))]
								})
							] }),
							/* @__PURE__ */ d(Xo, {
								pub: e,
								priv: t,
								mine: de,
								send: M,
								preview: x
							})
						]
					})]
				})
			}),
			e.endingRequestedBy === r && /* @__PURE__ */ d("div", {
				className: "vantage-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": s("games.vantage.endAdventure"),
				children: /* @__PURE__ */ f("section", {
					className: "vantage-paper",
					children: [
						/* @__PURE__ */ d("p", { children: s("games.vantage.confirmEndText") }),
						/* @__PURE__ */ d("button", {
							className: "vantage-primary",
							onClick: () => M({ type: "confirmEnd" }),
							children: s("games.vantage.confirmEnd")
						}),
						/* @__PURE__ */ d("button", {
							onClick: () => M({ type: "cancelEnd" }),
							children: s("games.vantage.cancel")
						})
					]
				})
			}),
			S !== null && t?.bookPages.includes(S) && /* @__PURE__ */ d(ys, {
				src: `games/vantage/live/vantages/${S}.webp`,
				label: s("games.vantage.bookPage", { n: S }),
				close: () => T(null)
			}, `book-${S}`),
			b !== null && /* @__PURE__ */ f(ys, {
				src: `games/vantage/live/cards/${b}.webp`,
				label: E[b]?.nameZh || E[b]?.name ? `${b} · ${_e(b)}` : s("games.vantage.card", { n: b }),
				close: () => x(null),
				children: [
					/* @__PURE__ */ d(Ko, { card: b }),
					/* @__PURE__ */ d(Yo, { card: b }),
					/* @__PURE__ */ d(Jo, { card: b })
				]
			}, `card-${b}`)
		]
	});
}
//#endregion
//#region src/games/vantage/game-over.tsx
function Zs({ public: e, private: t, members: a, myRid: o, result: s, hintCount: p, onPlayAgain: m, onBackToLobby: y }) {
	let b = l(), x = c((e) => e.locale), S = e, T = t, [D, O] = i(!0), [ee, te] = i(o), [ne, re] = i(null), ie = r(null), k = r(null);
	n(() => {
		ie.current?.focus({ preventScroll: !0 });
	}, []);
	let ae = S.ending === "epic" ? "games.vantage.epicVictory" : S.ending === "mission" ? "games.vantage.missionVictory" : S.ending === "destiny" ? "games.vantage.destinyVictory" : S.ending === "failure" ? "games.vantage.failure" : "games.vantage.retired", oe = (e) => {
		let t = a.find((t) => t.rid === e);
		return t ? v(t, x) : e;
	}, se = (e) => (x === "zh" ? E[e]?.nameZh : E[e]?.name) || b("games.vantage.card", { n: e }), ce = S.players.find((e) => e.rid === ee) ?? S.players[0], le = (e) => {
		O(e), requestAnimationFrame(() => (e ? ie : k).current?.focus({ preventScroll: !0 }));
	}, ue = (e) => /* @__PURE__ */ f("button", {
		type: "button",
		className: "vantage-final-card",
		onClick: () => re(e),
		children: [
			/* @__PURE__ */ d("small", { children: e }),
			/* @__PURE__ */ d("strong", { children: se(e) }),
			/* @__PURE__ */ d(Ko, { card: e }),
			/* @__PURE__ */ d(Yo, { card: e })
		]
	});
	return /* @__PURE__ */ f("div", {
		className: "vantage-screen vantage-endgame",
		children: [
			/* @__PURE__ */ f("div", {
				className: "vantage-final-board",
				inert: D,
				children: [
					/* @__PURE__ */ f("header", {
						className: "vantage-final-heading",
						children: [/* @__PURE__ */ d("h2", { children: b("games.vantage.finalJourney") }), /* @__PURE__ */ d("p", { children: b(ae) })]
					}),
					/* @__PURE__ */ d("nav", {
						className: "vantage-crew",
						"aria-label": b("games.vantage.grid"),
						children: S.players.map((e) => /* @__PURE__ */ f("button", {
							type: "button",
							className: "vantage-crew-member",
							"aria-pressed": ce?.rid === e.rid,
							"data-selected": ce?.rid === e.rid,
							onClick: () => te(e.rid),
							children: [/* @__PURE__ */ d("strong", { children: oe(e.rid) }), /* @__PURE__ */ d("span", { children: w.map((t) => /* @__PURE__ */ f("span", {
								className: "vantage-stat",
								children: [/* @__PURE__ */ d($, {
									kind: t,
									size: 15
								}), e.stats[t]]
							}, t)) })]
						}, e.rid))
					}),
					/* @__PURE__ */ f("div", {
						className: "vantage-final-layout",
						children: [/* @__PURE__ */ f("main", {
							className: "vantage-final-location",
							children: [
								T && T.location >= 0 ? /* @__PURE__ */ f("section", {
									className: "vantage-location",
									children: [/* @__PURE__ */ f("div", {
										className: "vantage-section-heading",
										children: [/* @__PURE__ */ d("span", { children: b("games.vantage.privateLocation") }), /* @__PURE__ */ d("strong", { children: b("games.vantage.location", { n: T.location }) })]
									}), /* @__PURE__ */ d("button", {
										type: "button",
										className: "vantage-location-image",
										onClick: () => re(T.location),
										"aria-label": b("games.vantage.location", { n: T.location }),
										children: /* @__PURE__ */ d(Fo, {
											src: `games/vantage/live/cards/${T.location}.webp`,
											alt: b("games.vantage.location", { n: T.location })
										})
									})]
								}) : /* @__PURE__ */ d("p", { children: b("games.vantage.noPrivate") }),
								T?.notes && /* @__PURE__ */ f("details", {
									className: "vantage-paper",
									children: [/* @__PURE__ */ d("summary", { children: b("games.vantage.notes") }), /* @__PURE__ */ d("p", {
										className: "vantage-prose",
										children: T.notes
									})]
								}),
								!!T?.bookPages.length && /* @__PURE__ */ f("section", {
									className: "vantage-paper",
									children: [/* @__PURE__ */ d("h3", { children: b("games.vantage.bookOfVantages") }), /* @__PURE__ */ d("div", {
										className: "vantage-final-pages",
										children: T.bookPages.map((e) => /* @__PURE__ */ d("button", {
											type: "button",
											onClick: () => re(-e),
											children: b("games.vantage.bookPage", { n: e })
										}, e))
									})]
								})
							]
						}), /* @__PURE__ */ d("aside", {
							className: "vantage-final-inventory",
							children: ce && /* @__PURE__ */ f(u, { children: [
								/* @__PURE__ */ f("h3", { children: [
									oe(ce.rid),
									" · ",
									b("games.vantage.grid")
								] }),
								/* @__PURE__ */ d("div", {
									className: "vantage-grid",
									children: ce.grid.map((e, t) => e ? /* @__PURE__ */ f("article", {
										className: "vantage-grid-card",
										"data-character": e.card === ce.character,
										children: [
											ue(e.card),
											/* @__PURE__ */ f("p", {
												className: "vantage-card-boost",
												children: [
													b("games.vantage.boost"),
													" ",
													e.boost,
													"/",
													E[e.card].boostCapacity
												]
											}),
											/* @__PURE__ */ d("div", {
												className: "vantage-slots",
												children: E[e.card].slots.map((t) => /* @__PURE__ */ f("span", {
													className: "vantage-slot",
													"data-filled": e.dice[t.index] !== void 0,
													children: [/* @__PURE__ */ d($, { kind: e.dice[t.index] ?? (t.face || t.skill) }), t.impact && /* @__PURE__ */ d("small", { children: b("games.vantage.impact") })]
												}, t.index))
											})
										]
									}, t) : /* @__PURE__ */ d("div", {
										className: "vantage-grid-empty",
										"aria-label": b("games.vantage.empty")
									}, t))
								}),
								/* @__PURE__ */ f("div", {
									className: "vantage-resources",
									children: [/* @__PURE__ */ f("span", { children: [
										b("games.vantage.coins"),
										" ",
										ce.coins
									] }), C.map((e) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: e }), ce.skills[e]] }, e))]
								}),
								!!ce.reserve.length && /* @__PURE__ */ f("section", {
									className: "vantage-card-row",
									children: [/* @__PURE__ */ d("h3", { children: b("games.vantage.reserve") }), ce.reserve.map((e) => /* @__PURE__ */ d("div", { children: ue(e.card) }, e.card))]
								}),
								!!ce.supply.length && /* @__PURE__ */ f("section", {
									className: "vantage-card-row",
									children: [/* @__PURE__ */ d("h3", { children: b("games.vantage.supply") }), ce.supply.map((e) => /* @__PURE__ */ d("div", { children: ue(e.card) }, e.card))]
								}),
								!!ce.skirm.length && /* @__PURE__ */ f("section", {
									className: "vantage-card-row",
									children: [/* @__PURE__ */ d("h3", { children: b("games.vantage.skirmCollection", { n: ce.skirm.length }) }), /* @__PURE__ */ d("p", { children: ce.skirm.map((e) => "S" + String(e).padStart(3, "0")).join(" · ") })]
								})
							] })
						})]
					})
				]
			}),
			/* @__PURE__ */ d("div", {
				className: "vantage-result-overlay",
				hidden: !D,
				children: /* @__PURE__ */ f("section", {
					className: "vantage-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": b(ae),
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), le(!1)), e.key !== "Tab") return;
						let t = [...e.currentTarget.querySelectorAll("button:not(:disabled)")], n = t[0], r = t.at(-1);
						e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
					},
					children: [
						/* @__PURE__ */ f("header", {
							className: "vantage-result-heading",
							children: [/* @__PURE__ */ d("strong", { children: b("games.vantage.name") }), /* @__PURE__ */ d("button", {
								type: "button",
								ref: ie,
								className: "vantage-end",
								"aria-label": b("games.vantage.reviewJourney"),
								title: b("games.vantage.reviewJourney"),
								onClick: () => le(!1),
								children: /* @__PURE__ */ d(g, { size: 20 })
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "vantage-result-content",
							children: [
								/* @__PURE__ */ d("h1", { children: b(ae) }),
								/* @__PURE__ */ d("p", { children: b("games.vantage.adventureRound", { n: S.round }) }),
								/* @__PURE__ */ f("section", {
									className: "vantage-result-summary",
									children: [
										/* @__PURE__ */ d("h2", { children: b("games.vantage.mission", { n: S.mission }) }),
										/* @__PURE__ */ d(Jo, { card: S.mission }),
										/* @__PURE__ */ d("strong", { children: b(S.missionDone ? "games.vantage.missionCompleted" : "games.vantage.missionIncomplete") }),
										T && /* @__PURE__ */ d("p", { children: b("games.vantage.visited", { n: T.visitedCount }) }),
										S.destinyDone && /* @__PURE__ */ d("p", { children: b("games.vantage.destinyCompleted") })
									]
								}),
								/* @__PURE__ */ d("div", {
									className: "vantage-result-crew",
									children: S.players.map((e) => /* @__PURE__ */ f("article", { children: [
										/* @__PURE__ */ d("strong", { children: oe(e.rid) }),
										/* @__PURE__ */ d("div", {
											className: "vantage-resources",
											children: w.map((t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, { kind: t }), /* @__PURE__ */ f("span", { children: [
												b(Q[t]),
												" ",
												e.stats[t]
											] })] }, t))
										}),
										!!s.autopilot?.[e.rid] && /* @__PURE__ */ d("small", { children: b("games.vantage.autopilotShare", { n: Math.round(s.autopilot[e.rid] * 100) }) })
									] }, e.rid))
								}),
								p !== void 0 && /* @__PURE__ */ d("p", { children: b("session.hint.usedCount", { n: p }) })
							]
						}),
						/* @__PURE__ */ f("footer", {
							className: "vantage-result-actions",
							children: [
								m && /* @__PURE__ */ d(h, {
									label: b("games.vantage.playAgain"),
									confirmLabel: b("games.vantage.confirmPlayAgain"),
									onConfirm: m,
									className: "vantage-primary"
								}),
								y && /* @__PURE__ */ d(h, {
									label: b("games.vantage.backLobby"),
									confirmLabel: b("games.vantage.confirmBackLobby"),
									onConfirm: y,
									className: "vantage-primary"
								}),
								!m && !y && /* @__PURE__ */ d("p", { children: b("games.vantage.waitingHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ d("footer", {
				className: "vantage-review-toolbar",
				hidden: D,
				children: /* @__PURE__ */ f("button", {
					type: "button",
					ref: k,
					className: "vantage-primary",
					onClick: () => le(!0),
					children: [/* @__PURE__ */ d(_, { size: 18 }), b("games.vantage.showJourneyResult")]
				})
			}),
			ne !== null && /* @__PURE__ */ d(ys, {
				src: ne < 0 ? `games/vantage/live/vantages/${-ne}.webp` : `games/vantage/live/cards/${ne}.webp`,
				label: ne < 0 ? b("games.vantage.bookPage", { n: -ne }) : `${ne} · ${se(ne)}`,
				close: () => re(null),
				children: ne >= 0 && /* @__PURE__ */ f(u, { children: [
					/* @__PURE__ */ d(Ko, { card: ne }),
					/* @__PURE__ */ d(Yo, { card: ne }),
					/* @__PURE__ */ d(Jo, { card: ne })
				] })
			}, ne)
		]
	});
}
//#endregion
//#region src/games/vantage/options.tsx
function Qs({ value: e, onChange: t }) {
	let n = l(), r = Li.safeParse(e), i = r.success ? r.data : Li.parse(void 0);
	return /* @__PURE__ */ d(b, {
		title: n("games.vantage.startingStat"),
		columns: 2,
		children: [
			3,
			4,
			5,
			6
		].map((e) => /* @__PURE__ */ d(y, {
			name: "vantage-difficulty",
			value: String(e),
			checked: i.startingStat === e,
			label: n(e === 3 ? "games.vantage.difficulty3" : e === 4 ? "games.vantage.difficulty4" : e === 5 ? "games.vantage.difficulty5" : "games.vantage.difficulty6"),
			accent: Nn.accent,
			onChange: () => t({
				...i,
				startingStat: e,
				opening: !0
			})
		}, e))
	});
}
//#endregion
//#region src/games/vantage/guide.tsx
function $s() {
	let e = l();
	return /* @__PURE__ */ f("section", {
		className: "vantage-guide",
		children: [/* @__PURE__ */ d("div", {
			className: "vantage-guide-symbols",
			children: C.map((t) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, {
				kind: t,
				size: 28
			}), e(Q[t])] }, t))
		}), /* @__PURE__ */ d("div", {
			className: "vantage-guide-symbols",
			children: T.map((t, n) => /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, {
				kind: t,
				size: 28
			}), e(Q[t])] }, n))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/vantage/entry.tsx
var ec = {
	definition: wo,
	View: Ys,
	OverView: Zs,
	Options: Qs,
	Guide: $s,
	locales: {
		zh: {
			imageLoading: "正在载入图片…",
			imageFailed: "图片载入失败",
			retryImage: "重试",
			contributingCrewStat: "各位支付了技能的玩家获得{{n}}点{{stat}}",
			storyPaymentRequest: "故事行动的技能协助",
			storyPaymentConsent: "各玩家自愿选择贡献数量。确认选项时才会扣除；确认前可以更改或撤回。",
			storyPaymentProgress: "需要{{n}}点{{skill}}，同伴已同意贡献{{offered}}点",
			storyPaymentPledge: "贡献{{n}}点",
			storyPaymentCancel: "取消协助请求",
			storyPaymentAsk: "请求同伴协助付款",
			finalJourney: "本次旅途",
			reviewJourney: "收起结算，回看旅途",
			showJourneyResult: "查看探索结算",
			missionIncomplete: "使命尚未完成",
			destinyCompleted: "命运已完成",
			confirmPlayAgain: "确认再次探索",
			confirmBackLobby: "确认返回大堂",
			autopilotShare: "托管占比 {{n}}%",
			countedStoredSkills: "计入结果的储存技能",
			weightedSkillRoll: "支付加重骰子的1点强化，将结果改为{{skill}}",
			printed_ropeSkill: "获得1点移动或获取技能",
			printed_peekInterior: "查看建筑内部",
			printed_peekCost: "查看一个行动的费用",
			printed_regionView: "获得本地区的视野和1点角色强化",
			printed_lessonBenefit: "获得课程1424或1点士气",
			printed_signalView: "发射信号弹，共享本地区的视野",
			printed_spiralSpell: "同时支付另一张牌上的1点强化，获得对应法术",
			printed_referencePage: "查阅对应的万境之书页面",
			printed_sandboat: "移动至相邻地点（拥有动物时支付1点强化）",
			confirmOutdoors: "确认：当前位置在户外",
			printed_attuneComposition: "将自己网格卡牌的1个构成图标视为指定构成",
			compositionChange: "将{{from}}视为{{to}}",
			printed_transferDie: "将一颗已放置的挑战骰转移到另一张卡牌的空槽，不获得槽位奖励",
			sourceSlot: "来源槽位 {{n}}",
			powerTransferConsent: "{{from}}的卡牌{{source}}向{{to}}的卡牌{{destination}}转移强化或挑战骰，等待相关玩家同意。",
			acceptPowerTransfer: "同意转移",
			declinePowerTransfer: "拒绝转移",
			printed_refineDiscount: "支付此牌1个强化，提炼费用减少1点",
			printed_startingSkill: "获得此物品对应的1点技能",
			printed_firstObjective: "获得此物品对应的第一项个人目标",
			printed_transformCard: "将网格卡牌直接替换为制作、升级或提炼结果",
			printed_preserveReplacement: "保留即将被替换的卡牌",
			printed_finishReplacement: "完成替换并放置保留的卡牌",
			printed_ignoreExit: "忽略退出内部地点的指示并继续行动",
			printed_repeatSkillGroup: "重掷同数量技能骰，再选择一组结果",
			printed_extraSkillGroup: "额外掷2颗技能骰，再忽略2个结果",
			printed_keepSkillGroup: "保留原来的技能骰结果",
			printed_replaceSkillGroup: "采用新的一组技能骰结果",
			printed_dropExtraSkill: "选择一个技能骰结果忽略",
			printed_cannon: "支付所选物品的1个强化，继续压制行动并获得1点士气",
			printed_payLess: "即将支付的钱币减少2枚",
			printed_gainMore: "即将获得的钱币增加2枚",
			printed_powerHealthGuard: "本回合每防止损失1点生命，在另一张牌上获得1个强化",
			printed_seedSite: "选择此种子将要生长的地点",
			seedGrowthSite: "生长地点：{{n}}",
			printed_replaySentient: "重新放置一名智慧生物并获得放置收益",
			printed_awakenTree: "在树木旁唤醒一名智慧生物",
			printed_surface: "从洞穴前往本地区的地面地点",
			printed_regionalVision: "查看本地区的视野并在角色上获得1个强化",
			confirmTrees: "确认当前地点的画面上有树木",
			confirmTransformationCondition: "确认当前地点的画面满足所选制作结果的自然特征条件",
			printed_freeResult: "直接获得此行动结果",
			printed_transport: "将另一件物品交给其他玩家",
			hourglassInverted: "倒置：可支付强化撤销最近一次选择",
			hourglassUpright: "正置：可在交涉行动中放置时间骰",
			printed_abilitySkill: "获得此牌对应的1点技能",
			printed_portal: "开启临时传送门",
			printed_returnPortal: "返回传送前的地点",
			printed_stayPortal: "留在当前地点",
			printed_hourglassUndo: "倒置沙漏，撤销最近一次行动或收益选择并改选",
			printed_finishHourglassTurn: "结束回合",
			printed_transferBoost: "在两张卡牌之间转移1个强化",
			powerTransferSource: "从{{name}}的卡牌{{n}}转出",
			printed_startSwitch: "让行动中的玩家选择不同的行动",
			printed_finishSwitch: "改选此行动",
			printed_cancelSwitch: "保留原行动",
			printed_hookCost: "查看一项互动行动的费用",
			printed_hookDiscount: "将此互动行动的费用减少1点",
			confirmHookInteraction: "确认此行动与非能量的动物或智慧生物互动",
			confirmSelectedActionCondition: "确认满足所选行动列明的条件",
			switchSentientYes: "此行动与智慧生物互动",
			switchSentientNo: "此行动不与智慧生物互动",
			printed_flourishSkill: "选择获得的技能",
			printed_luckyRoll: "同时掷1颗技能骰，匹配时忽略全部挑战骰",
			printed_secondGroup: "再掷一组挑战骰并选择一组",
			printed_keepDice: "保留原来的骰子结果",
			printed_replaceDice: "采用新的一组骰子结果",
			printed_extraChoice: "额外掷2颗挑战骰，再选择2颗刷新",
			printed_dropExtraDie: "选择一颗骰子刷新",
			confirmPowerSentient: "确认此行动与智慧生物互动",
			confirmPowerAnimal: "确认此行动与动物互动",
			confirmFloraInteraction: "确认此行动与蘑菇或植物互动",
			printed_refreshDie: "刷新自己的一颗骰子",
			printed_refreshHealth: "刷新自己网格上的全部生命骰",
			printed_healthBoost: "获得1点生命",
			printed_moraleBoost: "获得1点士气",
			printed_timeBoost: "获得1点时间",
			printed_moveAdjacent: "让一位玩家移动到相邻地点",
			printed_teleport: "传送一位玩家",
			printed_jump: "移动到相邻地点并掷1颗挑战骰",
			printed_finishMove: "选择目的地",
			printed_cancelMove: "放弃此次移动",
			printed_beforeDiscount: "行动之前：费用减少1点",
			printed_powerIgnore: "忽略1颗挑战骰",
			printed_powerChange: "改变1颗挑战骰结果",
			printed_powerReroll: "重掷1颗挑战骰",
			printed_missingFace: "将全部骰子改为未出现的结果",
			printed_lampBoost: "在蛋上添加1点强化",
			printed_metalDraw: "从相邻卡牌转入尽可能多的强化",
			printed_metalPush: "向相邻卡牌转出尽可能多的强化",
			printed_cycleDice: "刷新自己卡牌上的骰子并添加到此行动",
			printed_flourish: "掷1颗挑战骰，然后获得1技能",
			printed_scope: "查看一个相邻的列出地点",
			printed_rerollAll: "重掷全部未放置骰",
			printed_gainTake: "角色获得1点强化，获得1点获取",
			printed_sentientCoins: "与智慧生物互动：获得2钱币",
			printed_tame: "使野生动物变得忠诚",
			printed_refreshSelf: "刷新此牌上的全部骰子",
			printed_animalDiscount: "动物互动费用减少1点",
			printed_saddle: "忽略1颗生命或时间骰",
			printed_rerollFace: "重掷所有匹配结果的未放置骰",
			printed_takeFree: "获取行动费用减少至0点",
			printed_gamble: "添加1颗可用骰并重掷全部",
			printed_page: "查看《万境》中的一页",
			printed_destiny: "选择命运放入中央区",
			printed_weaponSkills: "按神器和武器数量获得压制",
			printed_ignoreFace: "忽略所有同种未放置结果",
			printed_cleanse: "移除1个诅咒",
			printed_newSkill: "获得无人拥有的一种技能",
			printed_coldGuard: "忽略1点寒冷伤害",
			printed_exploreFree: "探索行动费用减少至0点",
			printed_randomOverpower: "获得1随机技能；压制则额外获得1点",
			printed_moraleDice: "掷2颗挑战骰；每个士气结果获得1士气",
			printed_relocateCard: "将另一张牌移至任意网格空位",
			printed_destroyDie: "从中央区移除1颗骰子",
			printed_recallDie: "取回1颗移除的骰子",
			printed_actionEngage: "获得仅用于此行动的10点接触",
			printed_shareLocations: "互相查看地点；所有角色获得1强化",
			printed_healthMorale: "本回合每失去1生命便获得1士气",
			printed_distinctTime: "掷3技能骰；各不相同则获得1时间",
			printed_stopForced: "允许停止强制继续",
			printed_heatGuard: "忽略1点高温伤害",
			printed_hypoxiaGuard: "忽略1点缺氧伤害",
			printed_ignoreCurse: "忽略即将获得的诅咒",
			printed_pairBefore: "掷2技能骰；成对则免掷挑战骰",
			printed_convertWeapon: "获得随机技能；各自选择是否改为压制",
			printed_convertSkill: "将此技能的全部标记改为压制",
			printed_keepConversion: "保留原有技能标记",
			printed_storeSkill: "获得1技能并存于此牌",
			printed_useStoredSkill: "将储存技能计入本次技能骰结果",
			printed_pulseBefore: "压制之前：支付1观察获得2压制",
			printed_remoteReceive: "将其他玩家的骰子放在自己的合法槽位",
			printed_remotePlace: "经允许，将骰子放在另一玩家的合法槽位",
			printed_learnSkill: "获得1点技能",
			printed_sentientBoost: "智慧生物获得1点强化",
			printed_healAfter: "刚失去生命：恢复1生命",
			printed_overpowerDiscount: "下一个压制行动费用减少1点",
			printed_revealCard: "私下查看一张卡牌",
			powerChoice: "选择目标与效果",
			activatePrintedPower: "发动异能",
			powerCell: "第{{n}}格",
			powerPage: "第{{n}}页",
			powerCardNumber: "卡牌编号",
			knownSharedLocation: "{{name}}共享的地点：{{n}}",
			viewRevealedCard: "查看已揭示卡牌{{n}}",
			storedPowerSkill: "储存技能：{{skill}} {{n}}",
			chooseEscapePlan: "选择同舱船员或储备角色",
			chooseSoulstoneRoute: "选择灵魂石任务的目的地",
			sharedCapsuleCrew: "同舱船员：{{seats}}。你们共享逃生舱与落点，分别获得对应技能。",
			animalPowers: "动物能力",
			animalScoutCosts: "查看所有相邻未列出地点的移动费用",
			confirmAnimalLand: "确认目的地是相邻的陆地地点",
			confirmAnimalRideTerrain: "确认目的地是相邻的陆地、海洋或水下地点",
			animalRide: "乘坐前往地点 {{n}}",
			animalIgnore: "本回合忽略所有未放置的{{face}}结果",
			animalClimate: "本回合忽略所有{{kind}}伤害",
			animalFetch: "将本次获取行动的费用降至0点",
			animalPlunder: "掠夺宝箱中的卡牌 {{n}}",
			confirmAnimalInteraction: "确认本次行动正在与智慧生物或动物互动",
			animalCharm: "重掷所选的 {{n}} 枚挑战骰",
			keepDie: "保留此骰",
			centerDieFace: "中央骰 {{n}} · {{face}}",
			animalRevive: "交换所选的 {{n}} 枚挑战骰",
			hatchEgg: "选择一颗蛋进行孵化",
			scavengeStarter: "随机获得一件尚未被持有的初始物品；没有可用物品时获得1点生命",
			puzzleTitle: "谜题 {{n}}",
			puzzleCard: "谜题原图 {{n}}",
			enlargePuzzleCard: "放大查看原图 {{n}}",
			puzzleMemoryHidden: "迷宫原图已隐藏。请凭记忆提交完整路线。",
			puzzleTreeControls: "先准备好，再从标出的起点点击相邻结点。可横向滚动查看完整原图。点击上一个结点撤回一步。",
			puzzleHexControls: "先准备好，再点击你选择的六边形格。也可聚焦图片，用方向键移动光标、Shift微调，按回车确认选点。可横向滚动查看完整原图。",
			puzzleKnightControls: "先准备好，再用方向按钮移动。可横向滚动查看完整原图。",
			puzzleKnight: "骑士",
			puzzleYou: "你",
			puzzleKnot: "结点 {{row}}{{n}}",
			puzzleHexPick: "选择站立的六边形格",
			puzzleHideMemory: "隐藏迷宫原图，开始回忆",
			puzzleReady: "准备好，开始作答",
			puzzleDifferences: "描述至少5处不同之处",
			puzzleDifferencesControls: "凭记忆在图上标出5至6处不同之处。点击编号可撤销该选点；可以用方向键移动光标、Shift微调，按回车选点。不能再次查看地点104。",
			puzzleDifferencePick: "在原图上标记不同之处",
			removePuzzlePoint: "撤销第{{n}}个选点",
			puzzlePointsSelected: "已标记{{n}}处（需5至6处）",
			clearPuzzleSelection: "清空选择",
			puzzleTunnelControls: "选择一个入口；也可先点击同一行的两块方块交换位置，找出通向左上方神器的完整路线。交叉隧道互不连通，入口行固定。",
			puzzleTunnelTile: "第{{row}}行第{{n}}列方块",
			puzzleTunnelEntrance: "隧道{{n}}",
			puzzleTool: "第四步使用的工具",
			puzzleBone: "符合规律的骨头字母",
			puzzleTranslation: "卷轴译文",
			puzzleAnswer: "按顺序填写答案，用空格或逗号分隔",
			puzzleNorth: "向北移动",
			puzzleEast: "向东移动",
			puzzleSouth: "向南移动",
			puzzleWest: "向西移动",
			puzzleKnightWon: "骑士落入深坑，可以领取试炼结果。",
			puzzleKnightLost: "你与骑士位于同一格，试炼失败。",
			submitPuzzleAnswer: "提交答案并查看结果",
			clearPuzzlePath: "清空路线",
			beginPuzzle: "查看谜题并作答",
			paySpiderBoost: "支付喂养所需的强化",
			claimFoundryLoot: "领取铸造厂战利品",
			storyTestPaySkill: "支付1点{{skill}}，增加1枚检定骰",
			paySpiderFood: "选择网格中的一张食物、动物或筋腱牌，支付其上的1点强化。",
			payBoostFrom: "支付{{card}}上的1点强化",
			foundryLoot: "选择一件战利品；也可以选择两件，同时获得诅咒1394。",
			confirmFoundryLoot: "领取{{n}}件战利品",
			rollAsylumVisitor: "投掷技能骰，确定来访者",
			grantAsylum: "收留请求庇护的智慧生物",
			shelterInEmbassy: "收留于使馆的供应区",
			asylumLocation: "在地点{{n}}的使馆避难；只有身处该地点时可使用其行动与强化能力，不能在其骰槽放骰。",
			investmentRolled: "技能骰结果：{{face}}。按此结果结算投资。",
			investmentClaimed: "已领取投资收益：{{n}}枚钱币。",
			claimInvestment: "领取投资收益",
			acknowledgeRestriction: "记录行动限制",
			enterCouncil: "暂存武器并进入议会",
			enterBox: "存放随身物品并进入箱子",
			practiceMilitary: "进行军事训练",
			reviveAnimal: "随机复活动物",
			beginTideSharing: "分享所见并随潮漂流",
			resolveAnimalObstacle: "查看动物是否仍在阻挡",
			passSentient: "从智慧生物身边经过",
			passAnimal: "经过动物所在之处",
			checkUninjuredReward: "结算本回合未受伤的奖励",
			retrieveHiddenItem: "寻找藏在传送门旁的物品",
			ignoreLocalHeat: "获得此处的高温保护",
			adoptTravelerMission: "改为救助旅行者使命",
			hideGatewayItem: "可以选择一件物品藏在门旁；它仍占用储备位置，在515取回前不能使用或交易。",
			hideNoItem: "不藏物品",
			hiddenGatewayItem: "藏在传送门旁，前往515取回",
			weaponsStored: "武器暂存在地点{{n}}，离开时自动取回。",
			belongingsStored: "物品留在地点{{n}}，返回时自动取回。",
			portalDestination: "传送目的地编号",
			portalDestinations: "可前往012至063、076至531、541至791、795、799或801。",
			enterPortal: "进入传送门",
			houseKnownEmpty: "已知屋内无人，沿用该结果。",
			houseKnownOccupied: "已知屋内有人，沿用该结果。",
			useKnownHouseStatus: "沿用已知屋内情况",
			chooseHouseDieSource: "选择临时挑战骰的来源",
			checkHouse: "投掷挑战骰查看屋内情况",
			houseCheckResult: "挑战骰：{{face}}。{{status}}；骰子已按来源归还。",
			houseEmpty: "屋内无人",
			houseOccupied: "屋内有人",
			recruitWithSkills: "选择支付1至3点任意技能，同行者获得等量强化。",
			confirmRecruitSkills: "支付{{n}}点技能并招募同行者",
			investmentAmount: "投资的钱币数",
			investAndRoll: "支付钱币并投掷技能骰",
			chooseWildAnimal: "选择网格中的一只野生动物，将其替换为忠诚版本。",
			personalItemBoostAmount: "个人物品增加的强化",
			chooseForesightSources: "选择预投骰的来源",
			foresightSources: "骰池{{pool}}枚，中央区{{center}}枚",
			rollForesight: "投掷{{n}}枚挑战骰",
			chooseForesightGroup: "选择一组用于下一行动；另一组按来源归还。",
			foresightGroup: "第{{n}}组：{{faces}}",
			characterBoostInstead: "改为让角色获得1点强化",
			repeatSkillNext: "再投掷一组{{n}}枚技能骰",
			repeatSkillComplete: "本组没有{{skill}}结果，前面各组的匹配技能已全部获得，可以继续。",
			floraForesightResults: "预投挑战骰结果",
			chooseForesightDice: "选择其中{{n}}枚用于本次行动，其余放入中央区并忽略结果。",
			confirmForesightDice: "确定使用的预投骰",
			foresightDiceConfirmed: "已选择骰子：{{dice}}",
			floraDonate: "可以移除网格中一名智慧生物的1点强化，获得1点生命和1点压制。",
			floraBoostInstead: "改为在此植物上获得1点强化",
			floraTransfer: "可以将此植物上的强化移到自己的其他卡牌，共有{{n}}点可分配。",
			confirmFloraTransfer: "确定强化分配",
			repeatSkillTest: "第{{n}}组，每组投掷{{count}}枚。获得全部{{skill}}结果；本组有匹配结果时继续投掷，直到没有匹配。",
			fitImage: "适应窗口",
			originalImageSize: "原尺寸",
			zoomImageOut: "缩小图像",
			zoomImageIn: "放大图像",
			imageZoomLevel: "{{n}}%",
			closeImage: "关闭",
			chooseResultType: "选择挑战结果类型",
			ignoreResultTypes: "本次行动忽略：{{faces}}",
			initialFloraRoll: "首次投掷的时间结果可忽略，士气结果自动重投一次。",
			bonusClimate: "本次行动忽略{{kind}}伤害。",
			confirmIgnoredType: "确定忽略类型",
			ignoreSelectedBonusDie: "忽略所选骰子的结果",
			changeSelectedBonusDie: "更改所选骰子的结果",
			bonusSubsetReroll: "可以将任意一组尚未放置的挑战骰重投一次。",
			tournamentComplete: "锦标赛结束，请结算钱币。",
			merchantMinic: "明尼克",
			merchantBastia: "巴斯提耀",
			merchantLak: "琅克",
			chooseStoryTradeCards: "选择本次交易使用的卡牌",
			gainCharacterMapCoins: "按角色强化与持有地图数量获得钱币",
			otherCrewStat: "其他每位玩家获得{{n}}点{{stat}}",
			allCrewStat: "每位玩家获得{{n}}点{{stat}}",
			chooseTestSkills: "从最终骰子中选择{{n}}枚，获得对应技能",
			viewCrewLocations: "查看其他玩家当前所在的地点",
			payZeroAction: "支付{{n}}枚钱币，将行动费用降至0",
			payGateHealth: "支付{{n}}枚钱币，取得门道的恢复效果",
			rollStoryChallenge: "投掷1枚挑战骰并结算结果",
			loseRecentSkirm: "失去本次偷取的交锋牌",
			protectedArrival: "前往{{n}}，忽略本次抵达的{{kind}}伤害",
			departureLimit: "此地点仅可向东、南或西离开",
			chooseCard: "选择卡牌",
			chooseCopiedAction: "选择符合条件的行动并获得其结果",
			chooseTestSkill: "选择获得一个最终骰面对应的技能",
			gainMatchingTest: "获得所有匹配的最终结果；无匹配则失去1点时间",
			abilityInstructions: "执行能力牌说明",
			confirmMatchingAction: "确认该行动符合能力要求及当前场景条件",
			viewSelectedCosts: "查看所选行动费用",
			stopHere: "停留在此地点",
			noMatchingAction: "当前没有符合条件的行动",
			doubleBenefit: "选择该结果的一项收益翻倍",
			benefitAmount: "再次获得{{n}} {{kind}} {{card}}",
			noBenefitToDouble: "没有可翻倍的收益，继续",
			chooseChallengeBenefit: "选择收益骰，承受另一枚骰子的惩罚",
			challengeBenefitPair: "获得{{benefit}}；承受{{penalty}}",
			createBoost: "选择物品、构筑物和载具，各至多一件，每件获得1点强化",
			transferBoost: "从第一张卡牌向第二张卡牌转移强化",
			matchBoost: "使第一张卡牌的强化数量与第二张相同",
			chooseDanceSentient: "选择与你跳舞的网格智慧生物",
			chooseInteractedAnimal: "选择本次互动的动物",
			chooseSecondCard: "第二张卡牌",
			confirmInteractedAnimal: "确认这正是本次互动的动物",
			randomBlueprint: "随机获得一张1294至1298的蓝图",
			goUnderground: "前往当前地区对应的地下地点",
			rollChallengePair: "掷两枚挑战骰",
			assemblyBonus: "结算组装的额外钱币",
			previewedOutcome: "已查看的行动结果",
			selectTestDie: "选择第{{n}}枚技能骰",
			rerollSelectedTestDice: "重投所选技能骰（剩余{{n}}轮）",
			replaceWithCard: "替换为卡牌{{n}}",
			rollTrapDice: "为所选陷阱投掷3枚挑战骰",
			trapResults: "目标：{{target}}。投掷结果：{{faces}}。",
			boostMatchingCards: "符合条件的网格牌各获得1点强化",
			runeFinalDice: "符文技能骰的最终结果",
			runeSurvey: "查看你当前的地点画面，其中是否有六种技能符号之一？符文可能隐藏或镜像，颜色不影响判断。",
			runePresent: "看到了符文，获得1点强化",
			runeAbsent: "没有看到符文",
			runeShape: "符文对应的技能",
			confirmRuneShape: "确认在当前地点画面中看到了此形状的符文",
			resolveRuneSkills: "结算符文技能",
			runeTokenRow: "放置标记的行",
			gainRuneQuest: "获得任务1706并放置第一个标记",
			runeQuestTitle: "找到隐藏的符文 · 1706",
			recordRunePrompt: "在当前地点发现符文时，可以为该地点放置一个标记。每个地点只能记录一次。",
			recordRune: "记录当前地点的符文",
			runeQuestRecipient: "领取完成任务的玩家",
			completeRuneQuest: "完成任务并交给所选玩家安置",
			runeFilledCell: "{{skill}}列、{{stat}}行，已有标记",
			runeEmptyCell: "{{skill}}列、{{stat}}行，空位",
			runeMarked: "●",
			runeBoost: "有符文地点的每名玩家获得1点强化",
			rollRuneSkills: "投掷{{n}}枚技能骰，获得与符文匹配的技能",
			gainRuneSkills: "获得{{n}}点与符文匹配的技能",
			runeQuestAlreadyHeld: "已有玩家持有任务1706，继续",
			crewSharing: "每位队员选择是否获得本次分享的随机技能。",
			acceptShareSkill: "获得1点随机技能",
			declineShareSkill: "本次不获得技能",
			waitCrewSharing: "等待队员完成选择或技能骰结算。",
			beginCrewSharing: "与队员分享信息",
			learnCrewSlots: "按其他角色最左侧骰槽获得技能",
			stowValuedCards: "在网格与储备区之间调动有钱币价值的卡牌",
			stowToReserve: "将卡牌{{n}}移入储备区",
			stowToGrid: "将卡牌{{n}}移入所选网格位置",
			gridDestination: "网格目标位置",
			stowGridCell: "位置{{n}}",
			finishStowing: "完成卡牌调动",
			storyTestLoseStat: "每个{{skill}}结果失去{{n}}点{{stat}}",
			contributeCoin: "支付1枚钱币，将费用减少1",
			confirmFishingWater: "确认当前地点有可供捕鱼的水域",
			restRefresh: "刷新网格中的{{n}}枚挑战骰",
			restDie: "卡牌{{card}}的第{{n}}个骰槽",
			restRefreshConfirm: "刷新所选骰子",
			storyTestRerollOne: "重投此骰",
			storyTestGainType: "获得结果中的全部{{skill}}技能",
			storySkillTest: "技能投骰",
			storyTestRound: "已投掷{{n}}次，最多{{max}}次；每次{{count}}枚骰子。",
			storyTestBait: "支付卡牌{{n}}上的1点强化作为诱饵，增加1枚骰子",
			storyTestExtra: "支付卡牌{{n}}上的1点强化，增加1枚骰子",
			storyTestRoll: "投掷{{n}}枚技能骰",
			storyTestReroll: "重新投掷全部{{n}}枚技能骰",
			storyTestKeep: "保留这组结果",
			storyTestFinal: "结果已确定，请结算对应奖励。",
			beginStoryTest: "准备投掷技能骰",
			storyTestStat: "每个{{skill}}结果获得{{n}}点{{stat}}",
			launchPhase: "飞船出发准备",
			launchCockpit: "000 · 飞船驾驶舱",
			launchEscape: "001 · 紧急逃生",
			launchCockpitText: "选择自己的初始时间、士气与生命，然后前往逃生区。各项初始值相同；其他船员准备就绪后一起离开。",
			launchRewindText: "你们带着网格、储备和技能回到了出发前。重新选择初始时间、士气与生命，然后再度启程。",
			launchEscapeText: "飞船发生故障！每位船员选择一个不同的逃生舱，获得对应的1点技能，然后投掷两枚技能骰确定落点并获得骰面技能。",
			leaveCockpit: "准备就绪，前往001",
			waitingLaunch: "等待其他船员准备就绪。",
			escapeCapsule: "逃生舱00{{n}}",
			openingMissionAction: "执行使命的转变行动",
			rewindAdventure: "保留网格、储备和技能，从地点000重新开始",
			printedValue: "价值 {{n}}",
			transmitSignal: "发送求救信号",
			goalTokens: "进度标记 {{n}}",
			returnToAction: "返回行动",
			adoptAlternativeGoal: "采用使命的替代目标",
			loseChosenSkill: "失去所选技能",
			noSkillToLose: "没有技能，继续结算",
			tuckUnderStructure: "夹藏在建筑 {{n}} 下",
			tuckFlora: "培育植物 {{n}}",
			pluckFlora: "取出一张夹藏植物",
			tuckedFlora: "夹藏植物：{{cards}}",
			gainChosenSkill: "获得 1 点自选技能",
			conquerCityPart: "征服此城市的一部分",
			alternativeMission: "替代目标",
			questExpired: "任务 {{n}} 已超过期限，已失去。",
			questTimer: "期限标记剩余 {{n}}",
			questJourney: "还需探索 {{n}} 处不同的新地点，然后返回 751。",
			questUnderwater: "已记录 {{n}} / 4 处不同的水下地点",
			questTokens: "进度标记 {{n}}",
			confirmUnderwater: "按当前地点的场景确认：这里是水下地点",
			recordUnderwater: "记录当前水下地点",
			questPayCoins: "支付 20 钱币，完成任务 1682",
			questPaySkills: "每种技能各支付 1，完成任务 1684",
			questGiveShoes: "失去悬浮鞋，完成任务 1685",
			questAbandonShoes: "放弃任务 1685，保留悬浮鞋",
			questPatrolProgress: "在桥上添加 1 进度标记",
			questTeachProgress: "添加 1 进度标记，按当前标记数获得帮助技能",
			confirmFireSentient: "确认当前位置有火智慧生物在场",
			gainCardWithBoost: "获得卡牌 {{n}}，其上放置 {{boost}} 强化",
			gainCardIfMissing: "若尚未拥有，获得卡牌 {{n}}",
			prepareElemental: "准备下一次元素体行动",
			siphonElemental: "获得法术 {{n}}，然后继续击杀",
			summonElemental: "召唤船员支援",
			elementalPrepareSkills: "获得 1 随机技能和 1 个所选技能",
			elementalPrepareRow: "刷新所选行的全部挑战骰",
			elementalPrepareColumn: "所选列的每张牌各获得 1 强化",
			chooseGridRow: "选择网格行",
			chooseGridColumn: "选择网格列",
			gridRow: "第 {{n}} 行",
			gridColumn: "第 {{n}} 列",
			summonedCrew: "召唤支援",
			summonedCharacter: "召唤的角色",
			summonedPlayers: "已召唤：{{names}}",
			summonCharacter: "召唤 {{name}}",
			paySummon: "支付角色的 2 强化，响应召唤",
			declineSummon: "不加入此次召唤",
			waitingSummon: "等待 {{names}} 回应召唤",
			summonDuration: "支援者可提供网格骰槽；只有行动者承受元素体惩罚。执行压制—击杀以外的行动时，支援结束。",
			arrangeElementalPart: "选择部位 {{n}}，与另一张交换位置",
			arrangeElemental: "选择两张部位牌可以交换位置，拼成完整的元素体。",
			beginElemental: "获得对应诅咒，展开元素体的四张部位牌",
			retreatElemental: "撤离战斗，角色获得 1 强化",
			strikeElemental: "击杀此部位，结算奖励与后续效果",
			elementalCombat: "元素体战斗 · 剩余 {{n}} 个部位",
			elementalPart: "查看部位 {{n}}",
			elementalDiscount: "下一次部位行动的费用减少 2。",
			elementalIgnoreHealth: "下一次部位行动忽略挑战骰的生命损失。",
			elementalReroll: "放置前可重掷本次全部挑战骰一次",
			itemPowers: "卡牌强化能力",
			transducer: "948 · 换能器",
			transducerRefreshUnplaced: "支付 2 强化，刷新第 {{n}} 颗未放置骰子",
			transducerRefreshPlaced: "支付 2 强化，刷新卡牌 {{n}} 第 {{slot}} 槽的骰子",
			transducerNeighbors: "支付 3 强化，在每张正交相邻牌上各加 1 强化",
			turtaxi: "1013 · 海龟出租车",
			turtaxiRide: "支付 1 强化，前往相邻地点 {{n}}",
			sawAxe: "1088 · 锯齿斧",
			confirmNearbyIce: "当前地点附近有冰或雪",
			axeIce: "支付 1 强化，获得冰资源 1183",
			axeHelp: "支付 2 强化，获得 1 帮助",
			sentientInteractionQuestion: "本次地点行动是否与智慧生物互动？请按场景与元素图标判断。",
			chooseInteraction: "选择互动对象",
			sentientInteractionYes: "与智慧生物互动",
			sentientInteractionNo: "未与智慧生物互动",
			replenishTitle: "电路法杖 · 补充",
			replenishPrompt: "{{name}} 的卡牌 {{n}} 刚移除了最后 1 强化。",
			replenishAccept: "支付法杖的 1 强化，在该牌上加回 1 强化",
			replenishDecline: "放弃补充",
			waitingReplenish: "等待 {{name}} 决定是否补充强化",
			rollSentientTrial: "投掷 {{n}} 颗技能骰，检查是否有接触结果",
			sentientTrialResult: "智慧生物的回应",
			sentientTrialFailed: "没有掷出接触结果，未获得奖励。",
			sentientTrialBoost: "此智慧生物获得 1 强化。",
			sentientBond: "此智慧生物的骰槽不再需要支付强化",
			sentientPowers: "智慧生物的强化能力",
			powerBoostPrice: "支付 {{n}} 强化",
			sentientProtect: "忽略本回合接下来的 1 点{{kind}}伤害",
			sentientRefresh: "刷新卡牌 {{n}} 第 {{slot}} 槽的骰子",
			sentientRandomSkill: "获得 1 个随机技能",
			sentientGain: "获得卡牌 {{n}}",
			sentientPage: "查看《万境之书》第 {{n}} 页",
			sentientTravel: "前往地点 {{n}}",
			sentientUnique: "设置 {{n}} 颗互不相同的骰面，然后投掷其余骰子。设置后不能再降低本次费用。",
			confirmPreset: "确认骰面",
			sentientGamble: "增加 1 颗骰子，重掷本次全部骰子",
			gambleChoice: "选择一种结果，忽略并刷新该面的全部骰子",
			refreshGambleFace: "忽略并刷新所有{{face}}骰",
			waitingGamble: "等待行动者选择刷新结果",
			sentientImpact: "此牌所有骰槽本回合获得影响",
			sentientBoost: "在卡牌 {{n}} 上获得 1 强化",
			sentientStop: "本回合可以结束强制继续的行动",
			sentientSiphon: "从卡牌 {{n}} 拿取 1 强化，获得其第 {{slot}} 槽的{{face}}结果",
			sentientSand: "每选择 1 颗骰子，另支付 1 个与当前行动匹配的技能。",
			ignoreDice: "忽略所选的 {{n}} 颗骰子",
			sentientBlank: "下一颗放入自己网格的骰子若为空白，在该牌获得 1 强化",
			sentientReroll: "重掷第 {{n}} 颗骰子",
			sentientScout: "查看相邻地点 {{n}}",
			sentientCost: "查看费用：{{action}}",
			sentientWoodReward: "完成此能力后，角色获得 1 强化。",
			scoutedInformation: "本回合获知的信息",
			viewScouted: "查看地点 {{n}}",
			protectionRemaining: "本回合还可忽略 {{n}} 点{{kind}}伤害",
			skillRollDecision: "结算新掷的技能骰",
			skillMatchOnly: "本次只获得{{skill}}结果。",
			keepSkillRoll: "保留此技能结果",
			changeSkillRoll: "支付 1354 上的 1 强化，改为{{skill}}",
			waitingSkillRoll: "等待牌主结算新掷的技能骰",
			resolvePlacement: "结算放置奖励",
			placementDrain: "从相邻卡牌向卡牌 {{n}} 转移强化，还需转移 {{remaining}} 个。",
			placementGain: "卡牌 {{n}} 的放置奖励：在你的一张网格牌上获得 1 强化。",
			drainFromCard: "从卡牌 {{n}} 转移 1 强化",
			boostOnCard: "在卡牌 {{n}} 上获得 1 强化",
			waitingPlacement: "等待 {{name}} 结算放置奖励",
			slotCooperation: "骰槽协作",
			consentImpact: "允许 {{name}} 本回合使用我的影响槽位",
			cursePhase: "结算诅咒惩罚",
			resolveCurse: "结算诅咒指令",
			curseName: "诅咒 {{n}} · {{element}}",
			curseDescription: "全队：任何玩家与{{element}}元素互动时，每颗未放置的挫折骰都触发以下惩罚：{{penalty}}此牌必须放入网格，不能储备。",
			curseInstructions: {
				water: "角色失去1强化。",
				wood: "失去1个自选技能。",
				wind: "受到1点缺氧伤害。",
				leaf: "如果可能，掷1颗中央区的挑战骰，承受其属性惩罚后刷新。",
				stone: "如果可能，掷1颗骰池中的挑战骰，承受其属性惩罚后放入中央区。",
				sand: "失去1时间。",
				metal: "如果可能，储备1张非角色、非诅咒的网格牌。",
				sinew: "失去1生命。",
				gold: "失去1钱币。",
				fire: "受到1点高温伤害。",
				energy: "失去1士气。",
				circuit: "受到1点寒冷伤害。"
			},
			composition: {
				water: "水",
				wood: "木",
				wind: "风",
				leaf: "叶",
				stone: "石",
				sand: "沙",
				metal: "金属",
				sinew: "肌腱",
				gold: "黄金",
				fire: "火",
				energy: "能量",
				circuit: "电路"
			},
			cursePenalty: "结算诅咒 {{n}} 的惩罚",
			curseLose: "失去1{{resource}}",
			cardOwnership: "商定卡牌归属",
			decideCardOwnership: "请决定卡牌归属",
			cardDelivery: "安置获得的卡牌",
			forbidLocation: "此后不能在地点 {{n}} 执行地点行动",
			arrivalPhase: "结算抵达效果",
			waitingArrival: "等待{{name}}完成结算",
			arrivalIgnored: "忽略本次抵达损失",
			shieldArrival: "支付力场盾上的1强化，忽略本次生命损失",
			heat: "高温",
			cold: "寒冷",
			hypoxia: "缺氧",
			payArrivalSkill: "支付1个{{skill}}技能以避免抵达损失",
			arrivalDamage: "受到1点{{kind}}伤害",
			arrivalImmune: "免疫本次{{kind}}伤害",
			arrivalLose: "失去1{{resource}}",
			arrivalPaid: "已支付技能，免除本次损失",
			arrivalLoseSkill: "失去1个自选技能；没有技能时忽略此损失。",
			arrivalReserve: "储备网格中的1张非角色、非诅咒牌；没有符合条件的牌时忽略此损失。",
			arrivalRollPool: "如果骰池中有骰子，掷1颗，承受其属性损失，并将骰子放到中央惩罚区。",
			arrivalRollCenter: "如果中央惩罚区有骰子，掷1颗，承受其属性损失，并将骰子刷新回骰池。",
			chooseSkill: "选择技能",
			chooseReserveCard: "选择储备的卡牌",
			arrivalForcedMove: "必须离开此地",
			chooseDestination: "选择目的地",
			resolveArrival: "结算抵达指令",
			cardClaim: "{{requester}}将获得{{owner}}持有的卡牌{{n}}。请商定归属；原持有人保留时，获得者改为在角色上获得1强化。",
			keepClaimedCard: "保留此牌，让获得者的角色获得1强化",
			transferClaimedCard: "让{{name}}获得此牌",
			effectLoseBoost: "失去 {{n}} 强化",
			effectLoseCoin: "失去 {{n}} 钱币",
			effectLoseSkill: "失去 {{n}} 个{{skill}}技能",
			personalGoals: "个人目标与任务",
			confirmPersonalGoal: "确认已满足此牌所述的完成条件",
			readPersonalGoal: "阅读秘密条目 {{n}}",
			completePersonalCard: "将完成的目标或任务竖放至网格",
			slotBoostCost: "支付 {{n}} 强化",
			companionsHere: "同地点的同伴",
			consentFollow: "同意跟随 {{name}} 的下一次移动",
			consentSlots: "允许 {{name}} 使用我的非影响槽位",
			giveTo: "赠予对象",
			coinQuantity: "钱币数量",
			giveCoins: "赠送钱币",
			giveCard: "赠送卡牌 {{n}}",
			waitingGiftPlacement: "等待 {{names}} 安置收到的卡牌",
			powerArmorResolved: "已处理动力装甲",
			experiencePhase: "结算已满的经验牌",
			experienceFull: "经验牌 {{n}} 已满",
			experienceResolution: "失去此经验牌，获得其列出的两枚技能，然后决定是否替换角色。此经验牌之后无法再次获得。",
			becomeSurvivor: "替换为对应生存者",
			keepCharacter: "保留当前角色",
			powerArmorChoice: "是否穿上对应的动力装甲？角色上的强化会全部转移。",
			equipPowerArmor: "替换为动力装甲",
			armorBoost: "在角色上获得 {{n}} 强化",
			environmentImmune: "角色免疫此次环境伤害",
			refreshUnplaced: "支付 1 强化刷新这枚未放置骰",
			rerollDifferent: "支付 1 强化重掷至结果改变",
			characterBoost: "支付 1 强化，在卡牌 {{n}} 上获得 1 强化",
			characterSkill: "支付 1 强化获得 1 随机技能",
			switchAction: "支付 1 强化改选其他行动",
			characterRefreshPlaced: "支付 1 强化，刷新卡牌 {{n}} 的第 {{slot}} 槽骰子",
			characterBlank: "支付 1 强化，本回合所有返回骰视为空白",
			characterIgnore: "支付 1 强化，忽略所选骰子的惩罚",
			characterIncrease: "支付 1 强化，将本次费用加 1 并获得 1 钱币",
			continueReading: "继续阅读结果",
			rollSkillResult: "投掷 1 枚技能骰决定结果",
			skillResult: "本次投掷结果：{{skill}}",
			returnDungeon: "返回进入地牢前的洞穴",
			obstacleMorale: "若未因障碍消除而降低费用，获得 1 士气",
			confirmObstacleCleared: "确认说明中的障碍已经消除",
			clearObstacle: "将基础费用降至 1",
			chooseDestiny: "选择继续追求的命运",
			destinyN: "命运 {{n}}",
			name: "万境奇旅",
			desc: "在未知星球上探索、求生，决定你们的命运",
			rules: "目标：在未知星球上完成共同使命，或找到属于你们的命运。\n每位玩家独自查看当前地点，只能向同伴口述景物，不能展示地点牌。个人网格、补给、储备和资源公开。\n开局：每人获得一名角色和一个不同的逃生舱，获得相应技能；投掷两枚技能骰决定落点；两枚骰子的结果相同时，可以重新投掷。第一位玩家额外投掷两枚技能骰决定使命。\n回合：选择一个地点行动、卡牌行动，或沿允许的方向离开。承诺后再查看费用和说明；任何玩家都可以支付匹配技能，每枚降低 1 点费用。投掷与剩余费用相同数量的挑战骰。骰池不足时才刷新全部挑战骰。\n将骰子逐一放入自己的合法槽位，或同伴带有影响标记的槽位。每个槽位只放一枚骰子。技能槽按当前行动类型匹配，与骰面无关；指定骰面槽按骰面匹配。能力、地形和元素槽还需要符合牌上条件。随后同时结算未放置的时间、士气和生命损失。空白骰进入中央；返回骰回到骰池，基础规则不会额外扣除生存资源。\n完成挑战后才阅读故事结果。选择前只阅读选项，选择后再揭示对应结果。地点每人每局通常只能执行一次地点行动；明确要求继续或标为始终可用的行动例外。\n获得竖牌时放入三行三列的个人网格，角色始终位于中心，不能随意重排。横牌进入补给，使命和命运进入中央。储备牌不能提供槽位与能力。\n角色可以支付 2 点强化，获得 1 枚钱币或 1 点移动技能；也可以支付 1 点强化，重掷自己行动中的一枚挑战骰。如果重掷后的结果与原结果相同，则获得角色对应的技能。\n任何生存资源降至零时，先查看使命的获取故事，按其中说明处理最后机会。达成使命可以结束，也可继续追求命运；两者均完成时为史诗胜利。\n故事结果中的技能费用也可由同伴自愿分担。请求协助后，各玩家选择贡献数量；确认选项时统一扣除。钱币、强化和生存资源按选项说明由对应玩家或卡牌支付。",
			sellStructure: "支付此构筑物3点强化并出售，获得印刷价值所示的钱币",
			structureBoostSale: "支付此构筑物1点强化，获得{{n}}枚钱币",
			structureTokenSale: "支付所选卡牌1点强化，获得{{n}}枚钱币",
			structureCardSale: "出售一张符合条件的卡牌，获得其印刷价值及额外{{n}}枚钱币",
			rollChallengeReward: "投掷1枚挑战骰，获得对应的生存资源",
			challengeRewardResult: "本次挑战骰结果：{{face}}",
			nextActionDiscount: "本回合下一个行动的费用减少{{n}}。",
			chooseAction: "选择一项行动",
			waiting: "等待 {{name}} 行动",
			landing: "确认你的逃生落点",
			cost: "支付技能或投掷挑战骰",
			dice: "放置挑战骰，再结算损失",
			story: "阅读行动结果",
			crisis: "有玩家的生存资源降至零",
			round: "第 {{n}} 轮",
			location: "地点 {{n}}",
			privateLocation: "你的视角",
			pool: "骰池 {{n}}",
			penaltyPool: "中央 {{n}}",
			move: "移动",
			look: "查看",
			engage: "接触",
			help: "帮助",
			take: "获取",
			overpower: "压制",
			time: "时间",
			morale: "士气",
			health: "生命",
			setback: "返回",
			blank: "空白",
			boost: "强化",
			coins: "钱币",
			north: "向北离开",
			east: "向东离开",
			south: "向南离开",
			west: "向西离开",
			northeast: "向东北离开",
			southeast: "向东南离开",
			southwest: "向西南离开",
			northwest: "向西北离开",
			northOrNorthwest: "向北或西北离开",
			confirmLanding: "确认落点",
			rerollLanding: "重新投掷落点",
			rerollMission: "重新投掷使命",
			mission: "共同使命 {{n}}",
			missionDice: "决定使命的技能",
			landingDice: "坠落时获得的技能",
			costN: "费用 {{n}}",
			chooseCost: "选择费用",
			contribute: "支付 1 个匹配技能",
			roll: "投掷挑战骰",
			resolveDice: "结算剩余骰子",
			rerollDie: "支付 1 强化重掷",
			selectDie: "选择一枚骰子",
			selectedDie: "已选择第 {{n}} 枚骰子",
			placeDie: "放置骰子",
			slot: "槽位 {{n}}",
			impact: "影响",
			conditionalSlot: "确认符合牌上的条件",
			escapeWithDragon: "全体船员骑乘上古巨龙逃离",
			allCrewSkill: "每位玩家获得{{n}}点{{skill}}",
			otherCrewSkill: "其他每位玩家获得{{n}}点{{skill}}",
			randomSkillName: "随机技能",
			flyToRegionalSky: "飞往本地区的天空",
			returnToTakeoff: "返回起飞地点，并获得1点强化",
			dragonFlightPower: "支付上古巨龙2点强化，飞往本地区的天空",
			upgradeVehicle: "替换为卡牌 {{n}}",
			effectRegionalVantage: "查看本地区的瞭望图",
			siteLocation: "原始地点 {{n}}",
			grid: "个人网格",
			reserve: "储备",
			supply: "补给",
			center: "中央",
			ownBoard: "我的牌区",
			card: "卡牌 {{n}}",
			empty: "空位",
			boostCoin: "支付 2 强化获得 1 钱币",
			boostMove: "支付 2 强化获得 1 移动技能",
			placeGrid: "放入第 {{n}} 格",
			placeReserve: "放入储备",
			placeSupply: "放入补给",
			placeCenter: "放入中央",
			pendingCard: "安置新获得的卡牌",
			discard: "失去这张牌",
			apply: "执行",
			applied: "已执行",
			finishStory: "结束回合",
			continue: "继续行动",
			noActions: "此地点的普通行动已用过，请选择离开或卡牌行动。",
			unadapted: "此段的复杂效果尚未编排，开发版暂不能继续结算。",
			officialText: "官方原文",
			effectBoost: "获得 {{n}} 强化",
			effectCoin: "获得 {{n}} 钱币",
			effectSkill: "获得 {{n}} 个{{skill}}技能",
			effectStat: "{{stat}}变化 {{n}}",
			effectCard: "获得卡牌 {{n}}",
			effectLoseCard: "失去卡牌 {{n}}",
			effectLocation: "前往地点 {{n}}",
			effectRandom: "获得 {{n}} 个随机技能",
			effectSecret: "阅读秘密条目 {{n}}",
			effectRefresh: "刷新全部挑战骰",
			endAdventure: "结束冒险",
			confirmEndText: "结束这次冒险？当前进度将作为本次探索的结局保留。",
			confirmEnd: "确认结束冒险",
			cancel: "返回冒险",
			retired: "冒险告一段落",
			failure: "旅途暂时止步",
			missionVictory: "使命胜利",
			destinyVictory: "命运胜利",
			epicVictory: "史诗胜利",
			visited: "探索了 {{n}} 个地点",
			adventureRound: "共同经历 {{n}} 轮",
			playAgain: "再次探索",
			backLobby: "返回大堂",
			waitingHost: "等待主机开启下一次探索",
			notes: "探索笔记",
			saveNotes: "保存笔记",
			notesPlaceholder: "记录线索与共同约定",
			noPrivate: "请以入座玩家身份查看自己的地点。",
			startingStat: "初始生存资源",
			difficulty3: "嚣张 · 3",
			difficulty4: "无畏 · 4",
			difficulty5: "务实 · 5",
			difficulty6: "谨慎 · 6",
			errInvalid: "当前不能执行这项操作",
			errTurn: "现在轮不到你",
			errUnadapted: "此效果尚未完成编排",
			skirm: "交锋",
			skirmChoose: "选择本次交锋使用的卡牌",
			skirmAbility: "执行交锋能力",
			skirmOpponent: "对手",
			skirmSelf: "冒险者",
			skirmHidden: "隐藏骰面",
			skirmScore: "交锋结果",
			skirmWin: "冒险者赢得了交锋",
			skirmLose: "对手赢得了交锋",
			skirmFinish: "领取交锋奖励",
			skirmSpeed: "速度 {{n}}",
			skirmPoints: "{{n}} 分",
			skirmActivate: "执行能力",
			skirmReroll: "重掷所选骰子",
			skirmSet: "设置所选骰面",
			skirmSwap: "交换所选骰子",
			skirmSkip: "结束能力",
			skirmOld: "保留原骰面",
			skirmNew: "保留新骰面",
			skirmKeepMine: "保留自己的骰子",
			skirmKeepOther: "拿走对方的骰子",
			skirmGroup1: "重掷第一组",
			skirmGroup2: "重掷第二组",
			skirmSelectFaces: "为所选骰子设置新骰面",
			skirmOwnDice: "自己的骰子",
			skirmEnemyDice: "对方的骰子",
			skirmFollow: "完成能力的后续步骤",
			effectSkirm: "进行一场交锋",
			lastChance: "尝试最后一次机会",
			assignRescue: "将 1 点{{stat}}分配给 {{name}}",
			rescueRemaining: "待分配的生存资源",
			removeCurseLimit: "移除至多 {{n}} 张诅咒",
			sellCardLimit: "出售至多 {{n}} 张有价值的卡牌",
			boostAllSentients: "网格中的每名智慧生物获得 {{n}} 点强化",
			confirmStoryCards: "确认所选卡牌",
			skipStoryCards: "不选择卡牌，继续",
			saleProceeds: "获得 {{n}} 枚钱币",
			storyCardNumber: "卡牌 {{n}}",
			artifacts: {
				mask: "面具：将自己的 2 枚骰子设置为与对方的 1 或 2 枚骰子匹配的骰面。",
				horn: "号角：逐颗重掷不与自身其他技能匹配的骰子，直到匹配为止；计入牌上技能。",
				gauntlet: "护手：偷取对方 1 枚骰子，其骰面不能与自己的任何骰子相同。",
				scepter: "权杖：重掷自己的 1 枚骰子，再将另一枚骰子设置为相同骰面。",
				helm: "头盔：与对方交换各 1 枚骰子，可以重掷换来的骰子。",
				harness: "挽具：同时重掷自己的至多 6 枚骰子。",
				cloak: "斗篷：重掷自己的 1 或 2 枚骰子，将它们隐藏至计分。",
				tome: "典籍：自己的每枚骰子至多重掷一次，逐枚决定保留新旧结果。",
				dodecahedron: "十二面体：双方各重掷 1 枚骰子，选择拿走其中一枚，另一枚交给对方。",
				mantle: "披风：给予对方 1 枚骰子，再按对方最多技能的数量设置自己的骰子。",
				blade: "利刃：将对方骰子分为两组，对方选择其中一组重掷。",
				tools: "工具：设置自己的至多 3 枚骰子，新骰面必须互不相同。"
			},
			effectDamage: "承受 {{n}} 点环境伤害",
			damageHealth: "失去 {{n}} 生命",
			damageTimeMorale: "各失去 {{n}} 时间与士气",
			effectRollSkill: "投掷 {{n}} 枚技能骰，获得其中的{{skill}}结果",
			effectSkirmCard: "获得 1 张随机交锋牌",
			effectEnd: "阅读本次冒险的结局",
			reserveFromGrid: "将此牌移入储备",
			transferReserve: "支付 1 强化放入第 {{n}} 格",
			completeDestiny: "完成此命运",
			missionCompleted: "使命已完成",
			endMissionVictory: "以使命胜利结束冒险",
			pursueDestiny: "继续追求命运",
			acceptJourneyEnd: "接受本次冒险的结局",
			confirmBranchCondition: "确认符合此选项的条件",
			skirmGroupN: "第 {{n}} 组",
			effectVantage: "查看《万境之书》第 {{n}} 页",
			bookOfVantages: "已看过的万境",
			bookPage: "第 {{n}} 页",
			skirmCollection: "交锋收藏 · {{n}} 张",
			discardSkirmCollection: "失去整套交锋收藏",
			errReserveFull: "储备区容量不足，请先失去一张储备牌或整组交锋牌",
			skirmBonus: "额外 {{n}} 分",
			skirmTurn: "由{{side}}执行能力",
			skirmGroupTurn: "由{{side}}选择重掷的一组",
			elements: {
				circuit: "电路：每种数量相同的技能获得 1 分。",
				wind: "风：每个移动技能获得 1 分。",
				energy: "能量：对方数量最多的技能每个获得 1 分。",
				fire: "火：每种自己没有的技能获得 1 分。",
				gold: "黄金：每种至少出现两枚的骰面获得 1 分。",
				sinew: "肌腱：自己数量最多的技能每个获得 1 分。",
				metal: "金属：对方每种拥有的技能获得 1 分。",
				sand: "沙：每种拥有的查看、接触、获取和压制技能获得 1 分。",
				stone: "石：拥有全部六种技能时获得 3 分。",
				leaf: "叶：每种数量少于对方的技能获得 1 分。",
				water: "水：每种数量多于对方的技能额外获得 1 分。",
				wood: "木：自己拥有的技能中，每种不同的正数数量获得 1 分。"
			},
			keepAllTestSkills: "获得最终骰面的全部技能",
			reserveAllVehicles: "将网格中的全部载具移入储备区",
			diveArrival: "潜入{{n}}，忽略本次抵达的缺氧伤害",
			gridRefreshLimit: "刷新网格中至多{{n}}枚挑战骰",
			structureShelter: "将此构筑物改作居住空间，同时视为庇护所",
			gridRefreshExact: "刷新网格中的{{n}}枚挑战骰",
			choosePreparation: "选择准备方式",
			boostSelectedCard: "为选中的卡牌添加强化",
			boostAmount: "强化数量",
			chooseRewardPlayer: "选择一名玩家",
			grantMasterReward: "使该玩家获得自己角色的掌握行动结果",
			distinctTestCoins: "每种不同的最终技能图标获得1枚钱币",
			animalAirNext: "忽略抵达下一个地点时的缺氧伤害",
			animalAirRecovery: "若本回合承受过缺氧伤害，获得1点生命",
			trialEast: "东",
			trialWest: "西",
			trialNorth: "北",
			trialSouth: "南",
			claimMiniCoins: "结算本次游戏的钱币",
			claimTournamentSkills: "每赢一场获得1点压制",
			trialRace: "速度试炼",
			raceInstructions: "每枚技能骰让对应颜色的选手向前直行或斜行1格，同格不能容纳两名选手。完成一名选手的全部移动后才能移动另一名选手；无路可走的移动作废。用完后重新投掷六枚骰子，首位越过终点者获胜。",
			raceYourToken: "你的选手：{{skill}}",
			raceBoard: "标有格号的赛跑版图",
			racerMoves: "{{skill}} · 剩余{{n}}步",
			crossFinish: "越过终点",
			moveToRaceCell: "移动至第{{n}}格",
			racerBlocked: "前方无空位，结束此选手的移动",
			nextRaceRound: "投掷下一组六枚骰子",
			trialTrade: "交涉试炼",
			trialMancala: "时间循环播棋",
			trialTournament: "八人锦标赛",
			trialArena: "格斗试炼",
			perfecto: "完美",
			pinch: "拿捏",
			press: "施压",
			punch: "出拳",
			tradeInstructions: "依次与明尼克、巴斯提耀、琅克交易。每个分区只能选择其中一个交换选项，使用一次。离开商人后不能返回。通过交换彩色标记获得黄金徽章。",
			mancalaInstructions: "花费1枚时间方块，拿起一个圆圈内的全部骰子。自行决定顺序，顺时针依次向后续圆圈各放1枚。可以跳过仅有同种技能骰的非空圆圈。让每种技能的全部骰子各自集中在一个圆圈内。",
			tournamentInstructions: "逐场比较压制结果数量。平局时强度较低者获胜；强度与结果均相同时重赛。亲自参赛时替代第8名选手。所有投注须在首场比赛前确定。",
			arenaInstructions: "每场至少获得1个查看和1个压制才获胜。每枚移动骰可以单独重投，或与另一枚骰一起重投。每个获取结果失去1点生命，可以各用1个接触或帮助抵消。",
			perfectoInstructions: "投注1至6枚钱币，尝试让六枚骰子显示同种技能。每次可以重投任意骰子。最终全部相同则获得投注额两倍的钱币，否则失去投注的钱币。",
			pinchInstructions: "支付入场费后投掷六枚骰子。出现接触则获得2枚钱币，可以保留收益或减少一枚骰子继续。没有接触则失去上一轮获得的2枚钱币，并结束游戏。",
			pressInstructions: "逐枚投骰，可以随时停止。出现重复技能则爆掉，不能继续投骰。对手会一直投到爆掉。比较不重复骰的数量：平局或更多则获得投注额两倍的钱币，否则失去投注的钱币。",
			punchInstructions: "在任意技能上各投注最多3枚钱币，然后投掷两枚骰子。每枚命中的骰子获得该技能投注额两倍的钱币，最后失去全部投注的钱币。",
			tokenBlue: "蓝色",
			tokenPurple: "紫色",
			tokenOrange: "橙色",
			tokenGreen: "绿色",
			tokenYellow: "黄色",
			tokenRed: "红色",
			merchantName: "商人：{{name}}",
			tradeSection: "第{{n}}分区",
			exchangeFor: "交换为",
			goldEmblem: "黄金徽章",
			nextMerchant: "离开并前往下一位商人",
			endTrial: "结束试炼",
			timeCubes: "剩余时间方块：{{n}}",
			pickCircle: "拿起第{{n}}圈的骰子",
			dropCircle: "将下一枚骰子放入第{{n}}圈",
			dropSkillDie: "放置1枚{{skill}}骰",
			skipPureCircle: "跳过此纯色圆圈",
			betCoins: "投注钱币数量",
			confirmBet: "确认投注并开始",
			totalBet: "共投注{{n}}枚，可用{{coins}}枚",
			fighterOdds: "选手{{n}} · 强度{{strength}} · {{multiplier}}倍",
			pendingMiniCoins: "待结算钱币变化：{{n}}",
			finalMiniCoins: "最终钱币变化：{{n}}",
			currentBout: "选手{{a}}对阵选手{{b}}",
			boutResult: "{{a}}对阵{{b}}：选手{{winner}}获胜",
			confirmBout: "确定本场结果",
			rollBout: "投掷本场骰子",
			arenaProgress: "已赢{{wins}}场，已失去{{damage}}点生命",
			rerollsRemaining: "剩余重投次数：{{n}}",
			pressFinal: "不重复骰数量：你{{mine}}枚，对手{{enemy}}枚",
			rollAnotherDie: "再投1枚骰子",
			compareOpponent: "停止并与对手比较",
			rollPinchDice: "投掷{{n}}枚骰子",
			keepWinnings: "停止并保留收益",
			confirmRoll: "确定本次骰子结果",
			nextBout: "开始下一场",
			startTrial: "开始试炼",
			claimDanceCoins: "领取舞步对应的钱币",
			trialPoker: "骰子扑克",
			trialHunt: "狩猎试炼",
			trialSlide: "推骰谜题",
			trialDance: "舞蹈试炼",
			trialSucceeded: "试炼成功，请结算奖励。",
			trialFailed: "试炼失败，请结算结果。",
			trialRound: "第{{n}}轮，共3轮",
			pokerInstructions: "每枚公共骰揭示后，可以同时重投任意手牌骰一次。三枚公共骰揭示后，与两名对手比较五枚骰的组合。平局也算获胜。",
			huntInstructions: "每轮可以同时重投自己的任意骰子一次。确定结果后，每种技能数量较多的一方捕获另一方该种技能的骰子。三轮后，拥有更多骰子的一方获胜。",
			slideInstructions: "用额外骰从任一边推入一行或一列，另一端的骰子成为新的额外骰。每次推出后，可以花费1枚水方块重投额外骰一次。使每行或每列各自为同一种技能。",
			danceInstructions: "选择一枚骰放在上一舞步的正交相邻空位。同一行或列不能重复技能图标。掷出对子时可以重投任意骰。集齐六种图标并让末步邻接首步即成功，最多12步。",
			sharedDice: "公共骰",
			yourDice: "你的骰子",
			opponentDice: "对手的骰子",
			extraDie: "额外骰",
			waterRemaining: "剩余水方块：{{n}}",
			huntFinal: "最终骰子数量：你{{mine}}枚，对手{{enemy}}枚",
			pokerRank: "你的组合等级：{{n}}（1最低，7最高）",
			danceCount: "已放置{{n}}枚舞步骰",
			rerollTrialDice: "重投所选骰子",
			nextTrialRound: "确定本轮，进入下一轮",
			finishTrial: "确定最终结果",
			rerollExtraDie: "支付1枚水方块重投额外骰",
			pushRow: "第{{n}}行向{{direction}}推入",
			pushColumn: "第{{n}}列向{{direction}}推入",
			completeArrangement: "确认完成排列",
			endUnsolvedTrial: "水方块耗尽，结束试炼",
			placeDanceDie: "放置{{skill}}至（{{x}}，{{y}}）",
			noDancePlacement: "没有合法舞步，结束试炼",
			rebornUndo: "支付3点强化撤销本次行动，改选其他行动",
			foodDonation: "选择从食物牌移除的强化数量；每点获得1枚钱币和1点士气。至少4点时额外获得戒指993。",
			confirmFoodDonation: "捐出{{n}}点食物强化",
			chooseInnocentSentient: "选择一名无辜的智慧生物加入同行。",
			fillInnocentSentients: "为已拥有的无辜智慧生物填满强化。",
			fillSentientBoost: "填满强化",
			boostQuestEgg: "为蛋增加1点强化",
			deliverBarrel: "交付果汁桶并领取钱币",
			boostHostage: "为1349增加1点强化",
			deliverSoulstone: "交付蓝色水晶并领取奖励",
			becomeReborn: "交换身体，成为重生者",
			restoreBody: "恢复原角色并获得1点士气",
			supplyBoost: "强化 {{n}}",
			shelter: "庇护所",
			questFlagProgress: "在当前地点安放1面旗帜",
			claimMurderReward: "领取调查奖励",
			questHerdProgress: "按最终移动结果添加巨兽标记，最多4个",
			questSiegeProgress: "添加原始X值的标记，再移除未放置骰子数量的标记",
			questWaterConquestProgress: "记录此处征服，按累计标记数获得压制技能",
			confirmLandLocation: "按当前地点场景确认：这里是陆地地点",
			pathStationInstructions: "对照原牌辨认当前地点中的九站符号，选择对应符号放置标记。重复看到同一符号不重复计数；到达最后符号所在地点后结算任务。",
			confirmPathStation: "确认已在当前地点图中辨认出所选符号",
			recordPathStation: "记录第{{n}}个符号",
			pathStationRecorded: "第{{n}}个符号已记录",
			claimPathReward: "领取每个标记对应的1点随机技能",
			tameAnimal: "支付2点强化，使动物{{n}}变得忠诚",
			animalRideUnlisted: "{{direction}}：乘坐前往未列出地点",
			rideChooseX: "选择后续效果使用的X值。此次乘坐不支付行动费用，也不投掷挑战骰。",
			startPearlDefense: "保护岛屿珍珠：投掷3枚技能骰",
			pearlDefenseInstructions: "尚待完成的技能行动：{{skills}}。每种不同结果执行一次匹配行动，基础费用为3点，然后继续。",
			continuePearlDefense: "继续保卫珍珠",
			reserveCount: "储备 {{n}} / {{max}}"
		},
		en: {
			imageLoading: "Loading image…",
			imageFailed: "Image could not be loaded",
			retryImage: "Retry",
			contributingCrewStat: "Each player who paid skills gains {{n}} {{stat}}",
			storyPaymentRequest: "Help pay for the story action",
			storyPaymentConsent: "Choose how many skills to contribute. Skills are spent when the option is confirmed; you may change or withdraw your offer first.",
			storyPaymentProgress: "{{n}} {{skill}} needed; {{offered}} offered by companions",
			storyPaymentPledge: "Offer {{n}}",
			storyPaymentCancel: "Cancel request",
			storyPaymentAsk: "Ask companions to help pay",
			finalJourney: "This journey",
			reviewJourney: "Hide results and review the journey",
			showJourneyResult: "Show journey results",
			missionIncomplete: "Mission incomplete",
			destinyCompleted: "Destiny completed",
			confirmPlayAgain: "Confirm new adventure",
			confirmBackLobby: "Confirm return to lobby",
			autopilotShare: "Autopilot {{n}}%",
			countedStoredSkills: "Stored skills counted in the result",
			weightedSkillRoll: "Pay 1 boost from Weighted Dice to change the result to {{skill}}",
			printed_ropeSkill: "Gain 1 move or take skill",
			printed_peekInterior: "View the building interior",
			printed_peekCost: "View an action cost",
			printed_regionView: "Gain your regional view and 1 character boost",
			printed_lessonBenefit: "Gain lesson 1424 or 1 morale",
			printed_signalView: "Share a regional view with a signal flare",
			printed_spiralSpell: "Also pay 1 boost from another card to gain its matching spell",
			printed_referencePage: "Read the matching Book of Vantages page",
			printed_sandboat: "Travel to an adjacent location (pay 1 boost with an animal)",
			confirmOutdoors: "Confirm: this location is outdoors",
			printed_attuneComposition: "Treat one composition icon on a card in your grid as the chosen composition",
			compositionChange: "Treat {{from}} as {{to}}",
			printed_transferDie: "Transfer a placed challenge die to an empty slot on another card without gaining its reward",
			sourceSlot: "Source slot {{n}}",
			powerTransferConsent: "Transfer boost or a challenge die from {{from}}’s card {{source}} to {{to}}’s card {{destination}}. Waiting for the involved players.",
			acceptPowerTransfer: "Accept transfer",
			declinePowerTransfer: "Decline transfer",
			printed_refineDiscount: "Pay 1 boost from this card to reduce its REFINE cost by 1",
			printed_startingSkill: "Gain 1 skill matching this item",
			printed_firstObjective: "Gain the first personal objective matching this item",
			printed_transformCard: "Replace a grid card with its crafting, upgrading or refining result",
			printed_preserveReplacement: "Keep the card being replaced",
			printed_finishReplacement: "Complete the replacement and place the retained card",
			printed_ignoreExit: "Ignore the instruction to exit this interior and continue",
			printed_repeatSkillGroup: "Roll an equal skill-dice group and choose one group",
			printed_extraSkillGroup: "Roll 2 extra skill dice, then ignore 2 results",
			printed_keepSkillGroup: "Keep the original skill-dice group",
			printed_replaceSkillGroup: "Use the new skill-dice group",
			printed_dropExtraSkill: "Ignore one skill-die result",
			printed_cannon: "Pay 1 boost from the selected item, continue with overpower and gain 1 morale",
			printed_payLess: "Pay 2 fewer coins",
			printed_gainMore: "Gain 2 additional coins",
			printed_powerHealthGuard: "This turn, gain 1 boost on another card per health loss you prevent",
			printed_seedSite: "Choose the location where this seed will grow",
			seedGrowthSite: "Growth location: {{n}}",
			printed_replaySentient: "Place a sentient again and gain its placement benefits",
			printed_awakenTree: "Awaken a sentient beside trees",
			printed_surface: "Leave a cave for this region's ground location",
			printed_regionalVision: "View this region's vista and gain 1 boost on your character",
			confirmTrees: "Confirm that trees are shown at your current location",
			confirmTransformationCondition: "Confirm that the current location shows the natural feature required for this crafting result",
			printed_freeResult: "Gain this action's result directly",
			printed_transport: "Give another item to a different player",
			hourglassInverted: "Inverted: spend boost to undo the most recent choice",
			hourglassUpright: "Upright: accepts a time die during an engage action",
			printed_abilitySkill: "Gain 1 matching skill from this card",
			printed_portal: "Open a temporary portal",
			printed_returnPortal: "Return to the location before teleporting",
			printed_stayPortal: "Stay at the current location",
			printed_hourglassUndo: "Flip the hourglass, undo the most recent action or benefit choice, and choose differently",
			printed_finishHourglassTurn: "End turn",
			printed_transferBoost: "Transfer 1 boost between two cards",
			powerTransferSource: "From {{name}}'s card {{n}}",
			printed_startSwitch: "Let the acting player choose a different action",
			printed_finishSwitch: "Switch to this action",
			printed_cancelSwitch: "Keep the original action",
			printed_hookCost: "View an interaction action's cost",
			printed_hookDiscount: "Reduce this interaction action's cost by 1",
			confirmHookInteraction: "Confirm interaction with a non-energy animal or sentient",
			confirmSelectedActionCondition: "Confirm the conditions listed for the selected action",
			switchSentientYes: "This action interacts with a sentient",
			switchSentientNo: "This action does not interact with a sentient",
			printed_flourishSkill: "Choose a skill to gain",
			printed_luckyRoll: "Roll a skill die too; ignore all challenge dice on a match",
			printed_secondGroup: "Roll another group of challenge dice and choose a group",
			printed_keepDice: "Keep the original dice results",
			printed_replaceDice: "Use the new group of dice results",
			printed_extraChoice: "Roll 2 extra challenge dice, then refresh 2 of your choice",
			printed_dropExtraDie: "Choose a die to refresh",
			confirmPowerSentient: "Confirm that this action interacts with a sentient",
			confirmPowerAnimal: "Confirm that this action interacts with an animal",
			confirmFloraInteraction: "Confirm that this action interacts with mushrooms or plants",
			printed_refreshDie: "Refresh 1 of your dice",
			printed_refreshHealth: "Refresh all Health dice on your grid",
			printed_healthBoost: "Gain 1 Health",
			printed_moraleBoost: "Gain 1 Morale",
			printed_timeBoost: "Gain 1 Time",
			printed_moveAdjacent: "Move a player to an adjacent location",
			printed_teleport: "Teleport a player",
			printed_jump: "Move to an adjacent location and roll 1 challenge die",
			printed_finishMove: "Choose the destination",
			printed_cancelMove: "Decline this move",
			printed_beforeDiscount: "Before the action: reduce cost by 1",
			printed_powerIgnore: "Ignore 1 challenge die",
			printed_powerChange: "Change 1 challenge die result",
			printed_powerReroll: "Reroll 1 challenge die",
			printed_missingFace: "Change all dice to a result not rolled",
			printed_lampBoost: "Add 1 boost to an egg",
			printed_metalDraw: "Transfer as much boost as possible from an adjacent card",
			printed_metalPush: "Transfer as much boost as possible to an adjacent card",
			printed_cycleDice: "Refresh dice on your cards and add them to this action",
			printed_flourish: "Roll 1 challenge die, then gain 1 skill",
			printed_scope: "View an adjacent listed location",
			printed_rerollAll: "Reroll all unplaced dice",
			printed_gainTake: "Gain 1 character boost and 1 Take",
			printed_sentientCoins: "Sentient interaction: gain 2 coins",
			printed_tame: "Make a wild animal loyal",
			printed_refreshSelf: "Refresh all dice on this card",
			printed_animalDiscount: "Reduce animal interaction cost by 1",
			printed_saddle: "Ignore 1 Health or Time die",
			printed_rerollFace: "Reroll all unplaced dice of one result",
			printed_takeFree: "Reduce a Take action cost to 0",
			printed_gamble: "Add 1 available die and reroll all",
			printed_page: "View a page of the Book of Vantages",
			printed_destiny: "Choose a destiny for the center",
			printed_weaponSkills: "Gain Overpower for artifacts and weapons",
			printed_ignoreFace: "Ignore all unplaced dice of one result",
			printed_cleanse: "Remove 1 curse",
			printed_newSkill: "Gain a skill nobody possesses",
			printed_coldGuard: "Ignore 1 Cold damage",
			printed_exploreFree: "Reduce an Explore action cost to 0",
			printed_randomOverpower: "Gain 1 random skill, plus 1 if Overpower",
			printed_moraleDice: "Roll 2 challenge dice; gain 1 Morale per Morale result",
			printed_relocateCard: "Move another card to an empty grid space",
			printed_destroyDie: "Box 1 die from the center",
			printed_recallDie: "Recall 1 boxed die",
			printed_actionEngage: "Gain 10 Engage for this action only",
			printed_shareLocations: "Share locations; every character gains 1 boost",
			printed_healthMorale: "Gain 1 Morale per Health lost this turn",
			printed_distinctTime: "Roll 3 skill dice; gain 1 Time if all differ",
			printed_stopForced: "Allow stopping a forced continuation",
			printed_heatGuard: "Ignore 1 Heat damage",
			printed_hypoxiaGuard: "Ignore 1 Hypoxia damage",
			printed_ignoreCurse: "Ignore the curse being gained",
			printed_pairBefore: "Roll 2 skill dice; a pair skips challenge dice",
			printed_convertWeapon: "Gain a random skill; each player may convert to Overpower",
			printed_convertSkill: "Convert all matching tokens to Overpower",
			printed_keepConversion: "Keep the original skill tokens",
			printed_storeSkill: "Gain 1 skill stored on this card",
			printed_useStoredSkill: "Count a stored skill in this skill test",
			printed_pulseBefore: "Before Overpower: pay 1 Look to gain 2 Overpower",
			printed_remoteReceive: "Place another player’s die in your legal slot",
			printed_remotePlace: "With consent, place a die in another player’s legal slot",
			printed_learnSkill: "Gain 1 skill",
			printed_sentientBoost: "Give a sentient 1 boost",
			printed_healAfter: "Immediately after losing Health: gain 1 Health",
			printed_overpowerDiscount: "Reduce the next Overpower action cost by 1",
			printed_revealCard: "Privately view a card",
			powerChoice: "Choose a target and effect",
			activatePrintedPower: "Use power",
			powerCell: "Space {{n}}",
			powerPage: "Page {{n}}",
			powerCardNumber: "Card number",
			knownSharedLocation: "Location shared by {{name}}: {{n}}",
			viewRevealedCard: "View revealed card {{n}}",
			storedPowerSkill: "Stored skill: {{skill}} {{n}}",
			chooseEscapePlan: "Choose a pod companion or a reserve character",
			chooseSoulstoneRoute: "Choose a destination for the soulstone quest",
			sharedCapsuleCrew: "Pod companions: {{seats}}. You share the pod and landing site, and each gain the corresponding skills.",
			animalPowers: "Animal powers",
			animalScoutCosts: "View all adjacent unlisted move costs",
			confirmAnimalLand: "Confirm the destination is an adjacent land location",
			confirmAnimalRideTerrain: "Confirm the destination is adjacent land, ocean, or underwater",
			animalRide: "Ride to location {{n}}",
			animalIgnore: "Ignore all unplaced {{face}} results this turn",
			animalClimate: "Ignore all {{kind}} damage this turn",
			animalFetch: "Reduce this take action to 0 cost",
			animalPlunder: "Plunder card {{n}} from the chest",
			confirmAnimalInteraction: "Confirm this action interacts with a sentient or animal",
			animalCharm: "Reroll {{n}} selected challenge dice",
			keepDie: "Keep this die",
			centerDieFace: "Center die {{n}} · {{face}}",
			animalRevive: "Swap {{n}} selected challenge dice",
			hatchEgg: "Choose an egg to hatch",
			scavengeStarter: "Gain a random unowned starting item, or 1 health if none are available",
			puzzleTitle: "Puzzle {{n}}",
			puzzleCard: "Original puzzle card {{n}}",
			enlargePuzzleCard: "Enlarge original card {{n}}",
			puzzleMemoryHidden: "The maze is hidden. Submit the full route from memory.",
			puzzleTreeControls: "When ready, click adjacent knots from the marked start. Scroll horizontally to see the full original. Click the previous knot to undo one step.",
			puzzleHexControls: "When ready, click your chosen hex. You can also focus the image, move the cursor with arrow keys (Shift for fine adjustment), and press Enter to select. Scroll horizontally to see the full original.",
			puzzleKnightControls: "When ready, move with the direction buttons. Scroll horizontally to see the full original.",
			puzzleKnight: "Knight",
			puzzleYou: "You",
			puzzleKnot: "Knot {{row}}{{n}}",
			puzzleHexPick: "Choose the hex to stand on",
			puzzleHideMemory: "Hide the maze and recall the route",
			puzzleReady: "Ready to answer",
			puzzleDifferences: "Describe at least 5 differences",
			puzzleDifferencesControls: "From memory, mark 5–6 differences on this image. Click a numbered mark to remove it. You can move the cursor with arrow keys (Shift for fine adjustment) and press Enter to mark. Do not look at location 104 again.",
			puzzleDifferencePick: "Mark a difference on the original image",
			removePuzzlePoint: "Remove mark {{n}}",
			puzzlePointsSelected: "{{n}} places marked (choose 5–6)",
			clearPuzzleSelection: "Clear selection",
			puzzleTunnelControls: "Choose an entrance. You may first swap two tiles within the same row to trace a complete route to the artifact at the top left. Crossing tunnels do not join; the entrance row is fixed.",
			puzzleTunnelTile: "Tile in row {{row}}, column {{n}}",
			puzzleTunnelEntrance: "Tunnel {{n}}",
			puzzleTool: "Tool used fourth",
			puzzleBone: "Letter of the valid bone",
			puzzleTranslation: "Scroll translation",
			puzzleAnswer: "Enter the answer in order, separated by spaces or commas",
			puzzleNorth: "Move north",
			puzzleEast: "Move east",
			puzzleSouth: "Move south",
			puzzleWest: "Move west",
			puzzleKnightWon: "The knight fell into a pit. Claim the trial result.",
			puzzleKnightLost: "You and the knight share a square. The trial failed.",
			submitPuzzleAnswer: "Submit answer and reveal result",
			clearPuzzlePath: "Clear route",
			beginPuzzle: "View and solve the puzzle",
			paySpiderBoost: "Pay boost to feed the spider",
			claimFoundryLoot: "Claim the foundry loot",
			storyTestPaySkill: "Pay 1 {{skill}} to add 1 test die",
			paySpiderFood: "Pay 1 boost from a food, animal, or sinew card in your grid.",
			payBoostFrom: "Pay 1 boost from {{card}}",
			foundryLoot: "Choose one item, or choose two and gain curse 1394.",
			confirmFoundryLoot: "Claim {{n}} items",
			rollAsylumVisitor: "Roll a skill die to identify the visitor",
			grantAsylum: "Grant asylum to the sentient",
			shelterInEmbassy: "Keep in the embassy supply",
			asylumLocation: "Granted asylum at {{n}}. Actions and boost abilities are available only there. Its dice slots cannot be used.",
			investmentRolled: "Skill die: {{face}}. Settle the investment using this result.",
			investmentClaimed: "Investment return claimed: {{n}} coins.",
			claimInvestment: "Claim the investment return",
			acknowledgeRestriction: "Record the action restriction",
			enterCouncil: "Set weapons aside and enter the council",
			enterBox: "Set belongings aside and enter the box",
			practiceMilitary: "Practice military training",
			reviveAnimal: "Revive a random animal",
			beginTideSharing: "Share the view and follow the tides",
			resolveAnimalObstacle: "Check whether the animal still blocks the way",
			passSentient: "Walk past the sentient",
			passAnimal: "Pass the animal",
			checkUninjuredReward: "Resolve the reward for avoiding injury this turn",
			retrieveHiddenItem: "Look for the hidden gateway item",
			ignoreLocalHeat: "Gain protection from local heat",
			adoptTravelerMission: "Adopt the Traveler rescue mission",
			hideGatewayItem: "You may hide an item near the gateway. It still occupies reserve space and cannot be used or traded until recovered at 515.",
			hideNoItem: "Do not hide an item",
			hiddenGatewayItem: "Hidden near the gateway; recover at 515",
			weaponsStored: "Weapons are set aside at {{n}}. Reclaim them when you leave.",
			belongingsStored: "Belongings remain at {{n}}. Reclaim them when you return.",
			portalDestination: "Portal destination number",
			portalDestinations: "Choose 012–063, 076–531, 541–791, 795, 799, or 801.",
			enterPortal: "Enter the portal",
			houseKnownEmpty: "No one is home. Use the known result.",
			houseKnownOccupied: "Someone is home. Use the known result.",
			useKnownHouseStatus: "Use the known occupancy",
			chooseHouseDieSource: "Choose the temporary challenge die’s source",
			checkHouse: "Roll to check occupancy",
			houseCheckResult: "Challenge die: {{face}}. {{status}}. The die has been returned to its source.",
			houseEmpty: "No one is home",
			houseOccupied: "Someone is home",
			recruitWithSkills: "Pay 1–3 skills of any types. The sentient gains that much boost.",
			confirmRecruitSkills: "Pay {{n}} skills and gain the sentient",
			investmentAmount: "Coins to invest",
			investAndRoll: "Pay coins and roll a skill die",
			chooseWildAnimal: "Choose a wild animal in your grid to replace with its loyal version.",
			personalItemBoostAmount: "Boost to add to your personal item",
			chooseForesightSources: "Choose where to take the dice",
			foresightSources: "{{pool}} from the pool, {{center}} from the center",
			rollForesight: "Roll {{n}} challenge dice",
			chooseForesightGroup: "Choose a pair for your next action. Return the other pair to its sources.",
			foresightGroup: "Pair {{n}}: {{faces}}",
			characterBoostInstead: "Gain 1 boost on your character instead",
			repeatSkillNext: "Roll another batch of {{n}} skill dice",
			repeatSkillComplete: "No {{skill}} results in this batch. All previous matching skills have been gained. You may continue.",
			floraForesightResults: "Pre-rolled challenge dice",
			chooseForesightDice: "Choose {{n}} dice for this action. Put the rest in the center, ignoring their results.",
			confirmForesightDice: "Confirm pre-rolled dice",
			foresightDiceConfirmed: "Selected dice: {{dice}}",
			floraDonate: "You may remove 1 boost from a sentient in your grid to gain 1 health and 1 overpower.",
			floraBoostInstead: "Gain 1 boost on this flora instead",
			floraTransfer: "You may move boost from this flora to your other cards. Available: {{n}}.",
			confirmFloraTransfer: "Confirm boost distribution",
			repeatSkillTest: "Batch {{n}}: roll {{count}} dice. Gain all {{skill}} results. Repeat while a batch has a matching result. Stop when none match.",
			fitImage: "Fit to window",
			originalImageSize: "Original size",
			zoomImageOut: "Zoom image out",
			zoomImageIn: "Zoom image in",
			imageZoomLevel: "{{n}}%",
			closeImage: "Close",
			chooseResultType: "Choose a challenge result",
			ignoreResultTypes: "Ignore during this action: {{faces}}",
			initialFloraRoll: "Ignore time on the initial roll; automatically reroll initial morale once.",
			bonusClimate: "Ignore {{kind}} damage during this action.",
			confirmIgnoredType: "Confirm ignored result",
			ignoreSelectedBonusDie: "Ignore the selected die",
			changeSelectedBonusDie: "Change the selected die",
			bonusSubsetReroll: "You may reroll any subset of unplaced challenge dice once.",
			tournamentComplete: "The tournament is over. Settle your winnings.",
			merchantMinic: "Minic",
			merchantBastia: "Bastia",
			merchantLak: "Lak",
			chooseStoryTradeCards: "Choose cards for this trade",
			gainCharacterMapCoins: "Gain coins for character boost and maps held",
			otherCrewStat: "Each other player gains {{n}} {{stat}}",
			allCrewStat: "Each player gains {{n}} {{stat}}",
			chooseTestSkills: "Choose {{n}} final dice and gain their skills",
			viewCrewLocations: "Look at each other player’s current location",
			payZeroAction: "Pay {{n}} coin to reduce the action cost to 0",
			payGateHealth: "Pay {{n}} coins for the gateway’s healing effect",
			rollStoryChallenge: "Roll 1 challenge die and resolve the result",
			loseRecentSkirm: "Lose the Skirm card stolen during this action",
			protectedArrival: "Go to {{n}} and ignore {{kind}} damage on this arrival",
			departureLimit: "At this location, depart only east, south, or west",
			chooseCard: "Choose a card",
			chooseCopiedAction: "Choose a matching action and gain its result",
			chooseTestSkill: "Choose one final skill result to gain",
			gainMatchingTest: "Gain all matching final results; lose 1 time if none match",
			abilityInstructions: "Resolve the ability card",
			confirmMatchingAction: "Confirm this action meets the ability requirements and current scene conditions",
			viewSelectedCosts: "View the selected action costs",
			stopHere: "Stop at this location",
			noMatchingAction: "No matching action is currently available",
			doubleBenefit: "Choose one benefit from this result to double",
			benefitAmount: "Gain another {{n}} {{kind}} {{card}}",
			noBenefitToDouble: "No benefit to double; continue",
			chooseChallengeBenefit: "Choose the benefit die and suffer the other die as a penalty",
			challengeBenefitPair: "Gain {{benefit}}; suffer {{penalty}}",
			createBoost: "Choose at most one item, structure, and vehicle; each gains 1 boost",
			transferBoost: "Transfer boost from the first card to the second card",
			matchBoost: "Match the first card’s boost to the second card",
			chooseDanceSentient: "Choose the sentient in your grid to dance with",
			chooseInteractedAnimal: "Choose the animal from this interaction",
			chooseSecondCard: "Second card",
			confirmInteractedAnimal: "Confirm this is the animal from this interaction",
			randomBlueprint: "Gain a random blueprint from 1294–1298",
			goUnderground: "Go to the underground location matching your current region",
			rollChallengePair: "Roll 2 challenge dice",
			assemblyBonus: "Resolve the extra assembly money",
			previewedOutcome: "Viewed action result",
			selectTestDie: "Select skill die {{n}}",
			rerollSelectedTestDice: "Reroll selected skill dice ({{n}} rounds left)",
			replaceWithCard: "Replace with card {{n}}",
			rollTrapDice: "Roll 3 challenge dice for the selected trap",
			trapResults: "Target: {{target}}. Results: {{faces}}.",
			boostMatchingCards: "Gain 1 boost on each matching card in your grid",
			runeFinalDice: "Final rune skill dice",
			runeSurvey: "Does your current vantage contain one of the six skill symbols? Runes may be hidden or mirrored; their color does not matter.",
			runePresent: "I see a rune: gain 1 boost",
			runeAbsent: "I do not see a rune",
			runeShape: "Skill matching the rune",
			confirmRuneShape: "I can see this rune shape in my current vantage",
			resolveRuneSkills: "Resolve rune skills",
			runeTokenRow: "Row for the token",
			gainRuneQuest: "Gain quest 1706 and place the first token",
			runeQuestTitle: "Find hidden runes · 1706",
			recordRunePrompt: "When you discover a rune on your current location, record it here. Each location can be recorded once.",
			recordRune: "Record the rune on my location",
			runeQuestRecipient: "Player to receive the completed quest",
			completeRuneQuest: "Complete the quest for the selected player to place",
			runeFilledCell: "{{skill}} column, {{stat}} row: marked",
			runeEmptyCell: "{{skill}} column, {{stat}} row: empty",
			runeMarked: "●",
			runeBoost: "Each player on a location with a rune gains 1 boost",
			rollRuneSkills: "Roll {{n}} skill dice and gain results matching the rune",
			gainRuneSkills: "Gain {{n}} skills matching the rune",
			runeQuestAlreadyHeld: "A player already has quest 1706: continue",
			crewSharing: "Each crewmate chooses whether to gain a random skill from this sharing.",
			acceptShareSkill: "Gain 1 random skill",
			declineShareSkill: "Do not gain a skill",
			waitCrewSharing: "Waiting for crew choices or skill dice.",
			beginCrewSharing: "Share information with your crewmates",
			learnCrewSlots: "Gain skills matching other characters’ leftmost slots",
			stowValuedCards: "Transfer cards with coin values between your grid and reserve",
			stowToReserve: "Move card {{n}} to reserve",
			stowToGrid: "Move card {{n}} to the selected grid cell",
			gridDestination: "Destination grid cell",
			stowGridCell: "Cell {{n}}",
			finishStowing: "Finish transferring cards",
			storyTestLoseStat: "Lose {{n}} {{stat}} per {{skill}} result",
			contributeCoin: "Pay 1 coin to reduce the cost by 1",
			confirmFishingWater: "Confirm this location has water for fishing",
			restRefresh: "Refresh {{n}} challenge dice in your grid",
			restDie: "Card {{card}}, slot {{n}}",
			restRefreshConfirm: "Refresh selected dice",
			storyTestRerollOne: "Reroll this die",
			storyTestGainType: "Gain all {{skill}} results",
			storySkillTest: "Skill dice",
			storyTestRound: "Roll {{n}} of {{max}}; {{count}} dice per roll.",
			storyTestBait: "Pay 1 boost from card {{n}} as bait to add 1 die",
			storyTestExtra: "Pay 1 boost from card {{n}} to add 1 die",
			storyTestRoll: "Roll {{n}} skill dice",
			storyTestReroll: "Reroll all {{n}} skill dice",
			storyTestKeep: "Keep these results",
			storyTestFinal: "Results are final. Resolve the matching reward.",
			beginStoryTest: "Prepare to roll skill dice",
			storyTestStat: "Gain {{n}} {{stat}} per {{skill}} result",
			launchPhase: "Preparing to depart",
			launchCockpit: "000 · Spaceship cockpit",
			launchEscape: "001 · Emergency evacuation",
			launchCockpitText: "Choose your starting time, morale, and health, all at the same value. Proceed to the escape area when everyone is ready.",
			launchRewindText: "You return to the start with your grids, reserves, and skills. Choose your starting time, morale, and health again before departing.",
			launchEscapeText: "The ship malfunctions! Each crewmate chooses a different escape capsule, gains its matching skill, and rolls two skill dice to gain their skills and determine a landing location.",
			leaveCockpit: "Ready — proceed to 001",
			waitingLaunch: "Waiting for the other crewmates to prepare.",
			escapeCapsule: "Escape capsule 00{{n}}",
			openingMissionAction: "Perform the mission’s PIVOT action",
			rewindAdventure: "Keep grids, reserves, and skills; restart at location 000",
			printedValue: "Value {{n}}",
			transmitSignal: "Transmit a rescue signal",
			goalTokens: "Progress tokens: {{n}}",
			returnToAction: "Return to actions",
			adoptAlternativeGoal: "Adopt the alternative mission goal",
			loseChosenSkill: "Lose the chosen skill",
			noSkillToLose: "No skills to lose; continue",
			tuckUnderStructure: "Tuck under structure {{n}}",
			tuckFlora: "Grow flora {{n}}",
			pluckFlora: "Pluck one tucked flora",
			tuckedFlora: "Tucked flora: {{cards}}",
			gainChosenSkill: "Gain 1 selected skill",
			conquerCityPart: "Conquer part of this city",
			alternativeMission: "Alternative goal",
			questExpired: "Quest {{n}} expired and was lost.",
			questTimer: "Deadline tokens remaining: {{n}}",
			questJourney: "Visit {{n}} more distinct new locations, then return to 751.",
			questUnderwater: "Distinct underwater locations recorded: {{n}} / 4",
			questTokens: "Progress tokens: {{n}}",
			confirmUnderwater: "Confirm from the scene: this is an underwater location",
			recordUnderwater: "Record this underwater location",
			questPayCoins: "Pay 20 coins to complete quest 1682",
			questPaySkills: "Pay 1 of each skill to complete quest 1684",
			questGiveShoes: "Lose the hovershoes to complete quest 1685",
			questAbandonShoes: "Abandon quest 1685 and keep the hovershoes",
			questPatrolProgress: "Add 1 progress token to the bridge",
			questTeachProgress: "Add 1 progress token and gain help skills equal to the token count",
			confirmFireSentient: "Confirm a fire sentient is present at this location",
			gainCardWithBoost: "Gain card {{n}} with {{boost}} boost on it",
			gainCardIfMissing: "Gain card {{n}} if you do not already have it",
			prepareElemental: "Prepare for the next elemental action",
			siphonElemental: "Gain spell {{n}}, then continue with SLAY",
			summonElemental: "Summon support from your crew",
			elementalPrepareSkills: "Gain 1 random skill and 1 selected skill",
			elementalPrepareRow: "Refresh all challenge dice in the selected row",
			elementalPrepareColumn: "Gain 1 boost on each card in the selected column",
			chooseGridRow: "Choose a grid row",
			chooseGridColumn: "Choose a grid column",
			gridRow: "Row {{n}}",
			gridColumn: "Column {{n}}",
			summonedCrew: "Summoned support",
			summonedCharacter: "Summoned character",
			summonedPlayers: "Summoned: {{names}}",
			summonCharacter: "Summon {{name}}",
			paySummon: "Pay 2 boost on your character to join the summon",
			declineSummon: "Decline this summon",
			waitingSummon: "Waiting for {{names}} to answer the summon",
			summonDuration: "Supporters can offer their grid slots; only the acting player suffers elemental penalties. Support ends when an action other than overpower-SLAY is performed.",
			arrangeElementalPart: "Select part {{n}} to exchange positions with another",
			arrangeElemental: "Select two part cards to exchange positions and assemble the elemental.",
			beginElemental: "Gain the matching curse and assemble the four elemental parts",
			retreatElemental: "Retreat and gain 1 boost on your character",
			strikeElemental: "Slay this part and resolve its benefits and next-action effect",
			elementalCombat: "Elemental combat · {{n}} parts remain",
			elementalPart: "View part {{n}}",
			elementalDiscount: "The next part action costs 2 less.",
			elementalIgnoreHealth: "Ignore health penalties on challenge dice during the next part action.",
			elementalReroll: "Reroll all challenge dice once before placing any",
			itemPowers: "Card boost powers",
			transducer: "948 · Transducer",
			transducerRefreshUnplaced: "Pay 2 boost to refresh unplaced die {{n}}",
			transducerRefreshPlaced: "Pay 2 boost to refresh card {{n}}, slot {{slot}}",
			transducerNeighbors: "Pay 3 boost to add 1 boost to each orthogonally adjacent card",
			turtaxi: "1013 · Turtaxi",
			turtaxiRide: "Pay 1 boost to travel to adjacent location {{n}}",
			sawAxe: "1088 · Sawtooth axe",
			confirmNearbyIce: "There is ice or snow near the current location",
			axeIce: "Pay 1 boost to gain ice resource 1183",
			axeHelp: "Pay 2 boost to gain 1 help",
			sentientInteractionQuestion: "Does this location action interact with a sentient? Check the scene and composition icon.",
			chooseInteraction: "Choose the interaction",
			sentientInteractionYes: "Interacting with a sentient",
			sentientInteractionNo: "Not interacting with a sentient",
			replenishTitle: "Circuit staff · Replenish",
			replenishPrompt: "The last boost was just removed from {{name}}’s card {{n}}.",
			replenishAccept: "Pay 1 boost on the staff to add 1 boost to that card",
			replenishDecline: "Decline replenishment",
			waitingReplenish: "Waiting for {{name}} to decide on replenishment",
			rollSentientTrial: "Roll {{n}} skill dice and check for an engage result",
			sentientTrialResult: "The sentient responds",
			sentientTrialFailed: "No engage result was rolled; no benefit is gained.",
			sentientTrialBoost: "Gain 1 boost on this sentient.",
			sentientBond: "This sentient’s slots no longer cost boost",
			sentientPowers: "Sentient boost powers",
			powerBoostPrice: "Pay {{n}} boost",
			sentientProtect: "Ignore the next 1 {{kind}} damage this turn",
			sentientRefresh: "Refresh the die in card {{n}}, slot {{slot}}",
			sentientRandomSkill: "Gain 1 random skill",
			sentientGain: "Gain card {{n}}",
			sentientPage: "View Book of Vantages page {{n}}",
			sentientTravel: "Go to location {{n}}",
			sentientUnique: "Set {{n}} dice to different faces, then roll the rest. The cost cannot be reduced after setting the faces.",
			confirmPreset: "Confirm faces",
			sentientGamble: "Add 1 die and reroll all dice for this action",
			gambleChoice: "Choose a result: ignore and refresh every die showing it",
			refreshGambleFace: "Ignore and refresh all {{face}} dice",
			waitingGamble: "Waiting for the active player to choose a result",
			sentientImpact: "All slots on this card gain impact this turn",
			sentientBoost: "Gain 1 boost on card {{n}}",
			sentientStop: "You may stop instead of continuing this turn",
			sentientSiphon: "Take 1 boost from card {{n}} and gain its slot {{slot}} {{face}} result",
			sentientSand: "For each selected die, also pay 1 skill matching this action.",
			ignoreDice: "Ignore the {{n}} selected dice",
			sentientBlank: "If the next die placed on your grid is blank, gain 1 boost on that card",
			sentientReroll: "Reroll die {{n}}",
			sentientScout: "View adjacent location {{n}}",
			sentientCost: "View cost: {{action}}",
			sentientWoodReward: "After this power, gain 1 boost on your character.",
			scoutedInformation: "Information learned this turn",
			viewScouted: "View location {{n}}",
			protectionRemaining: "Ignore up to {{n}} more {{kind}} damage this turn",
			skillRollDecision: "Resolve the newly rolled skill die",
			skillMatchOnly: "Only {{skill}} results are gained.",
			keepSkillRoll: "Keep this skill result",
			changeSkillRoll: "Pay 1 boost on 1354 to change to {{skill}}",
			waitingSkillRoll: "Waiting for the owner to resolve a newly rolled skill die",
			resolvePlacement: "Resolve placement benefits",
			placementDrain: "Transfer boost from adjacent cards to card {{n}}. {{remaining}} remaining.",
			placementGain: "Card {{n}} grants 1 boost on a card in your grid.",
			drainFromCard: "Transfer 1 boost from card {{n}}",
			boostOnCard: "Gain 1 boost on card {{n}}",
			waitingPlacement: "Waiting for {{name}} to resolve placement benefits",
			slotCooperation: "Share impact slots",
			consentImpact: "Allow {{name}} to use my impact slots this turn",
			cursePhase: "Resolve curse penalties",
			resolveCurse: "Resolve curse instruction",
			curseName: "Curse {{n}} · {{element}}",
			curseDescription: "All players: When anyone interacts with {{element}}, each unplaced setback die causes this penalty: {{penalty}} Place this card in the grid; it cannot be reserved.",
			curseInstructions: {
				water: "Lose 1 boost on your character.",
				wood: "Lose 1 skill of your choice.",
				wind: "Suffer 1 hypoxia damage.",
				leaf: "If possible, roll 1 challenge die from the center, suffer its stat penalty, then refresh it.",
				stone: "If possible, roll 1 challenge die from the pool, suffer its stat penalty, then place it in the center.",
				sand: "Lose 1 time.",
				metal: "If possible, reserve 1 non-character, non-curse grid card.",
				sinew: "Lose 1 health.",
				gold: "Lose 1 coin.",
				fire: "Suffer 1 heat damage.",
				energy: "Lose 1 morale.",
				circuit: "Suffer 1 cold damage."
			},
			composition: {
				water: "Water",
				wood: "Wood",
				wind: "Wind",
				leaf: "Leaf",
				stone: "Stone",
				sand: "Sand",
				metal: "Metal",
				sinew: "Sinew",
				gold: "Gold",
				fire: "Fire",
				energy: "Energy",
				circuit: "Circuit"
			},
			cursePenalty: "Resolve curse {{n}}",
			curseLose: "Lose 1 {{resource}}",
			cardOwnership: "Agree on card ownership",
			decideCardOwnership: "Decide who keeps the card",
			cardDelivery: "Place the card you gained",
			forbidLocation: "No further location actions at {{n}}",
			arrivalPhase: "Resolve arrival",
			waitingArrival: "Waiting for {{name}} to finish resolving effects",
			arrivalIgnored: "Ignore this arrival loss",
			shieldArrival: "Pay 1 boost on the forcefield to ignore this health loss",
			heat: "heat",
			cold: "cold",
			hypoxia: "hypoxia",
			payArrivalSkill: "Pay 1 {{skill}} skill to avoid the arrival loss",
			arrivalDamage: "Suffer 1 {{kind}} damage",
			arrivalImmune: "Immune to this {{kind}} damage",
			arrivalLose: "Lose 1 {{resource}}",
			arrivalPaid: "A skill was paid; ignore this loss",
			arrivalLoseSkill: "Lose 1 skill of your choice. Ignore the loss if you have none.",
			arrivalReserve: "Reserve 1 non-character, non-curse grid card. Ignore the loss if you have none.",
			arrivalRollPool: "If possible, roll 1 die from the pool, suffer its stat penalty, then place it in the center.",
			arrivalRollCenter: "If possible, roll 1 die from the center, suffer its stat penalty, then refresh it to the pool.",
			chooseSkill: "Choose a skill",
			chooseReserveCard: "Choose a card to reserve",
			arrivalForcedMove: "You must leave this location",
			chooseDestination: "Choose a destination",
			resolveArrival: "Resolve arrival instruction",
			cardClaim: "{{requester}} would gain card {{n}}, held by {{owner}}. Agree who keeps it. If the owner keeps it, the requester gains 1 character boost.",
			keepClaimedCard: "Keep the card and give the requester 1 character boost",
			transferClaimedCard: "Let {{name}} gain this card",
			effectLoseBoost: "Lose {{n}} boost",
			effectLoseCoin: "Lose {{n}} coins",
			effectLoseSkill: "Lose {{n}} {{skill}} skills",
			personalGoals: "Objectives and quests",
			confirmPersonalGoal: "I have met the completion condition printed on this card",
			readPersonalGoal: "Read secret entry {{n}}",
			completePersonalCard: "Rotate the completed objective or quest into your grid",
			slotBoostCost: "Pay {{n}} boost",
			companionsHere: "Companions at your location",
			consentFollow: "Follow {{name}} on their next move",
			consentSlots: "Allow {{name}} to use my non-impact slots",
			giveTo: "Give to",
			coinQuantity: "Number of coins",
			giveCoins: "Give coins",
			giveCard: "Give card {{n}}",
			waitingGiftPlacement: "Waiting for {{names}} to place the card they received",
			powerArmorResolved: "Power armor resolved",
			experiencePhase: "Resolve full experience",
			experienceFull: "Experience card {{n}} is full",
			experienceResolution: "Lose this experience, gain its two printed skills, then choose whether to replace your character. This experience cannot be gained again.",
			becomeSurvivor: "Become the corresponding survivor",
			keepCharacter: "Keep your current character",
			powerArmorChoice: "Equip your corresponding power armor? Transfer all boost from your current character.",
			equipPowerArmor: "Equip power armor",
			armorBoost: "Gain {{n}} boost on your character",
			environmentImmune: "Your character ignores this environmental damage",
			refreshUnplaced: "Pay 1 boost to refresh this unplaced die",
			rerollDifferent: "Pay 1 boost to reroll until the result changes",
			characterBoost: "Pay 1 boost to gain 1 boost on card {{n}}",
			characterSkill: "Pay 1 boost to gain 1 random skill",
			switchAction: "Pay 1 boost to choose a different action",
			characterRefreshPlaced: "Pay 1 boost to refresh slot {{slot}} on card {{n}}",
			characterBlank: "Pay 1 boost to treat all your setbacks as blanks this turn",
			characterIgnore: "Pay 1 boost to ignore the selected die’s penalty",
			characterIncrease: "Pay 1 boost to increase this cost by 1 and gain 1 coin",
			continueReading: "Continue reading the result",
			rollSkillResult: "Roll 1 skill die to determine the result",
			skillResult: "Rolled result: {{skill}}",
			returnDungeon: "Return to the cave where you entered the dungeon",
			obstacleMorale: "Gain 1 morale unless clearing the obstacle reduced the cost",
			confirmObstacleCleared: "Confirm the obstacle described in this action is no longer present",
			clearObstacle: "Reduce the base cost to 1",
			chooseDestiny: "Choose a destiny to pursue",
			destinyN: "Destiny {{n}}",
			name: "Vantage",
			desc: "Explore an unfamiliar planet, survive together, and choose your destiny",
			rules: "Goal: Complete your shared mission or discover a destiny on an unfamiliar planet.\nOnly you may see your location. Describe it to companions without showing the card. Grids, supplies, reserves, and resources are public.\nSetup: Receive a character and a distinct escape capsule with their skills. Roll two skill dice for your landing site; doubles may be rerolled. The first player rolls two additional skill dice to determine the mission.\nTurn: Commit to a location action, an action on a card, or departing in an available direction. Read its cost only after committing. Any player may pay matching skill tokens, reducing the cost by one each. Roll challenge dice equal to the remaining cost. Refresh all challenge dice only when the pool is insufficient.\nPlace dice in legal slots on your grid or impact slots on companions’ grids, one per slot. Skill slots match the action, regardless of the die face; specific-result slots match the face. Ability, terrain, and composition slots require their printed conditions. Apply losses from unplaced time, morale, and health dice simultaneously. Blank dice go to the center. Setbacks return to the pool without an inherent stat loss.\nRead the result only after resolving the challenge. Read choices before selecting and reveal only the chosen result. Each player normally performs just one location action per location per game; explicit continuation and always-available actions are exceptions.\nPlace vertical cards in your 3×3 grid, keeping your character in the center. Cards cannot be freely rearranged. Horizontal cards enter your supply; missions and destinies go to the center. Reserved cards do not provide slots or powers.\nYour character can pay two boost for a coin or a move skill. Pay one boost to reroll one of your challenge dice; if unchanged, gain your character skill.\nIf any stat reaches zero, consult the mission’s take entry before resolving your final chance. You may end after completing the mission or pursue a destiny. Completing both earns an epic victory.\nCompanions may also voluntarily help pay skill costs in story results. Request help, let each player offer skills, then confirm the option to spend them. Pay coins, boost, and survival resources from the player or card specified by the option.",
			sellStructure: "Pay 3 boost from this structure and sell it for its printed value",
			structureBoostSale: "Pay 1 boost from this structure to gain {{n}} coins",
			structureTokenSale: "Pay 1 boost from the selected card to gain {{n}} coins",
			structureCardSale: "Sell one eligible card for its printed value plus {{n}} coins",
			rollChallengeReward: "Roll 1 challenge die to gain the matching survival stat",
			challengeRewardResult: "Challenge die result: {{face}}",
			nextActionDiscount: "Reduce the cost of your next action this turn by {{n}}.",
			chooseAction: "Choose an action",
			waiting: "Waiting for {{name}}",
			landing: "Confirm your landing site",
			cost: "Pay skills or roll challenge dice",
			dice: "Place challenge dice, then resolve losses",
			story: "Read the action result",
			crisis: "A survival stat has reached zero",
			round: "Round {{n}}",
			location: "Location {{n}}",
			privateLocation: "Your vantage",
			pool: "Pool {{n}}",
			penaltyPool: "Center {{n}}",
			move: "Move",
			look: "Look",
			engage: "Engage",
			help: "Help",
			take: "Take",
			overpower: "Overpower",
			time: "Time",
			morale: "Morale",
			health: "Health",
			setback: "Setback",
			blank: "Blank",
			boost: "Boost",
			coins: "Coins",
			north: "Depart north",
			east: "Depart east",
			south: "Depart south",
			west: "Depart west",
			confirmLanding: "Confirm landing",
			rerollLanding: "Reroll landing",
			rerollMission: "Reroll mission",
			mission: "Shared mission {{n}}",
			missionDice: "Mission skills",
			landingDice: "Landing skills",
			costN: "Cost {{n}}",
			chooseCost: "Choose cost",
			contribute: "Pay 1 matching skill",
			roll: "Roll challenge dice",
			northeast: "Depart northeast",
			southeast: "Depart southeast",
			southwest: "Depart southwest",
			northwest: "Depart northwest",
			northOrNorthwest: "Depart north or northwest",
			resolveDice: "Resolve remaining dice",
			rerollDie: "Pay 1 boost to reroll",
			selectDie: "Select a die",
			selectedDie: "Die {{n}} selected",
			placeDie: "Place die",
			slot: "Slot {{n}}",
			impact: "Impact",
			conditionalSlot: "Confirm the printed condition applies",
			escapeWithDragon: "Escape together on the elder dragon",
			allCrewSkill: "Each player gains {{n}} {{skill}}",
			otherCrewSkill: "Each other player gains {{n}} {{skill}}",
			randomSkillName: "random skill",
			flyToRegionalSky: "Fly to the sky above this region",
			returnToTakeoff: "Return to your takeoff location and gain 1 boost",
			dragonFlightPower: "Pay 2 boost from the elder dragon to fly above this region",
			upgradeVehicle: "Replace with card {{n}}",
			effectRegionalVantage: "View the vista for this region",
			siteLocation: "Original location {{n}}",
			grid: "Grid",
			reserve: "Reserve",
			supply: "Supply",
			center: "Center",
			ownBoard: "My cards",
			card: "Card {{n}}",
			empty: "Empty",
			boostCoin: "Pay 2 boost for 1 coin",
			boostMove: "Pay 2 boost for 1 move skill",
			placeGrid: "Place in cell {{n}}",
			placeReserve: "Place in reserve",
			placeSupply: "Place in supply",
			placeCenter: "Place in center",
			pendingCard: "Place the card you gained",
			discard: "Lose this card",
			apply: "Apply",
			applied: "Applied",
			finishStory: "End turn",
			continue: "Continue",
			noActions: "Your ordinary action here has been used. Depart or use a card action.",
			unadapted: "This complex effect has not been adapted. Resolution is unavailable in this development version.",
			officialText: "Official text",
			effectBoost: "Gain {{n}} boost",
			effectCoin: "Gain {{n}} coins",
			effectSkill: "Gain {{n}} {{skill}} skills",
			effectStat: "{{stat}} changes by {{n}}",
			effectCard: "Gain card {{n}}",
			effectLoseCard: "Lose card {{n}}",
			effectLocation: "Go to location {{n}}",
			effectRandom: "Gain {{n}} random skills",
			effectSecret: "Read secret entry {{n}}",
			effectRefresh: "Refresh all challenge dice",
			endAdventure: "End adventure",
			confirmEndText: "End this adventure? Your current progress will remain as this journey’s outcome.",
			confirmEnd: "Confirm end of adventure",
			cancel: "Return to adventure",
			retired: "A chapter of your journey",
			failure: "Your journey pauses here",
			missionVictory: "Mission victory",
			destinyVictory: "Destiny victory",
			epicVictory: "Epic victory",
			visited: "Locations explored: {{n}}",
			adventureRound: "Rounds together: {{n}}",
			playAgain: "Explore again",
			backLobby: "Back to lobby",
			waitingHost: "Waiting for the host to begin another journey",
			notes: "Field notes",
			saveNotes: "Save notes",
			notesPlaceholder: "Record clues and shared decisions",
			noPrivate: "Take a seat to view your own location.",
			startingStat: "Starting survival stats",
			difficulty3: "Brash · 3",
			difficulty4: "Daring · 4",
			difficulty5: "Pragmatic · 5",
			difficulty6: "Cautious · 6",
			errInvalid: "That action is unavailable now",
			errTurn: "It is not your turn",
			errUnadapted: "This effect has not yet been adapted",
			skirm: "Skirm",
			skirmChoose: "Choose your card for this duel",
			skirmAbility: "Activate the Skirm ability",
			skirmOpponent: "Opponent",
			skirmSelf: "Adventurer",
			skirmHidden: "Concealed die",
			skirmScore: "Duel result",
			skirmWin: "The adventurer won the duel",
			skirmLose: "Your opponent won the duel",
			skirmFinish: "Collect duel rewards",
			skirmSpeed: "Speed {{n}}",
			skirmPoints: "{{n}} points",
			skirmActivate: "Activate ability",
			skirmReroll: "Reroll selected dice",
			skirmSet: "Set selected dice",
			skirmSwap: "Exchange selected dice",
			skirmSkip: "Finish ability",
			skirmOld: "Keep old face",
			skirmNew: "Keep new face",
			skirmKeepMine: "Keep your die",
			skirmKeepOther: "Take the opposing die",
			skirmGroup1: "Reroll group 1",
			skirmGroup2: "Reroll group 2",
			skirmSelectFaces: "Set new faces for selected dice",
			skirmOwnDice: "Your dice",
			skirmEnemyDice: "Opposing dice",
			skirmFollow: "Complete the next ability step",
			effectSkirm: "Play a Skirm duel",
			lastChance: "Take one final chance",
			assignRescue: "Give 1 {{stat}} to {{name}}",
			rescueRemaining: "Survival benefits to distribute",
			removeCurseLimit: "Remove up to {{n}} curses",
			sellCardLimit: "Sell up to {{n}} cards with printed values",
			boostAllSentients: "Gain {{n}} boost on each sentient in your grid",
			confirmStoryCards: "Confirm selected cards",
			skipStoryCards: "Select no cards and continue",
			saleProceeds: "Gain {{n}} coins",
			storyCardNumber: "Card {{n}}",
			artifacts: {
				mask: "MASK: Set 2 dice to match 1 or 2 opposing dice.",
				horn: "HORN: Reroll each unmatching die until it matches a skill type you have, including printed skills.",
				gauntlet: "GAUNTLET: Steal 1 opposing die that does not match any of your dice.",
				scepter: "SCEPTER: Reroll 1 die, then set another die to match its skill type.",
				helm: "HELM: Exchange 1 die with your opponent. You may reroll the die you gain.",
				harness: "HARNESS: Reroll up to 6 dice simultaneously.",
				cloak: "CLOAK: Reroll 1 or 2 dice, concealing them until scoring.",
				tome: "TOME: You may reroll each die once. Choose the new or old face after each roll.",
				dodecahedron: "DODECAHEDRON: Reroll 1 of your dice and 1 opposing die. Choose which to keep, giving the other to your opponent.",
				mantle: "MANTLE: Give 1 die to your opponent, then set X dice, where X is their best skill quantity.",
				blade: "BLADE: Divide opposing dice into 2 groups. Your opponent chooses a group to reroll.",
				tools: "TOOLS: Set up to 3 dice to different faces. Each new face must be unique."
			},
			effectDamage: "Suffer {{n}} environmental damage",
			damageHealth: "Lose {{n}} health",
			damageTimeMorale: "Lose {{n}} time and {{n}} morale",
			effectRollSkill: "Roll {{n}} skill dice and gain all {{skill}} results",
			effectSkirmCard: "Gain 1 random Skirm card",
			effectEnd: "Read the outcome of this adventure",
			reserveFromGrid: "Move this card to reserve",
			transferReserve: "Pay 1 boost to place in cell {{n}}",
			completeDestiny: "Complete this destiny",
			missionCompleted: "Mission completed",
			endMissionVictory: "End with a mission victory",
			pursueDestiny: "Continue toward a destiny",
			acceptJourneyEnd: "Accept this journey’s end",
			confirmBranchCondition: "Confirm this choice’s condition is met",
			skirmGroupN: "Group {{n}}",
			effectVantage: "View page {{n}} in the Book of Vantages",
			bookOfVantages: "Vantages you have viewed",
			bookPage: "Page {{n}}",
			skirmCollection: "Skirm collection · {{n}} cards",
			discardSkirmCollection: "Lose the entire Skirm collection",
			errReserveFull: "Your reserve is full. Lose a reserved card or the entire Skirm collection first.",
			skirmBonus: "{{n}} bonus points",
			skirmTurn: "{{side}} activates their ability",
			skirmGroupTurn: "{{side}} chooses a group to reroll",
			elements: {
				circuit: "CIRCUIT: Gain 1 point per tied skill type.",
				wind: "WIND: Gain 1 point per move skill.",
				energy: "ENERGY: Gain 1 point per skill of the opponent’s best type.",
				fire: "FIRE: Gain 1 point per skill type you do not have.",
				gold: "GOLD: Gain 1 point per dice pair; higher quantities count as one pair.",
				sinew: "SINEW: Gain 1 point per skill of your best type.",
				metal: "METAL: Gain 1 point per unique opposing skill type.",
				sand: "SAND: Gain 1 point for each look, engage, take or overpower type you have.",
				stone: "STONE: Gain 3 points if you have all six skill types.",
				leaf: "LEAF: Gain 1 point per skill type you lose.",
				water: "WATER: Gain 1 extra point per skill type you win.",
				wood: "WOOD: Gain 1 point per different positive skill quantity you have."
			},
			keepAllTestSkills: "Gain all skills shown on the final dice",
			reserveAllVehicles: "Move all vehicles from your grid to reserve",
			diveArrival: "Dive to {{n}} and ignore hypoxia on this arrival",
			gridRefreshLimit: "Refresh up to {{n}} challenge dice from your grid",
			structureShelter: "Create a living space; this structure also counts as a shelter",
			gridRefreshExact: "Refresh {{n}} challenge dice from your grid",
			choosePreparation: "Choose how to prepare",
			boostSelectedCard: "Add boost to the selected card",
			boostAmount: "Amount of boost",
			chooseRewardPlayer: "Choose a player",
			grantMasterReward: "Grant this player their character’s MASTER result",
			distinctTestCoins: "Gain 1 coin per different final skill icon",
			animalAirNext: "Ignore hypoxia damage upon arriving at your next location",
			animalAirRecovery: "Gain 1 health if you suffered hypoxia damage this turn",
			trialEast: "east",
			trialWest: "west",
			trialNorth: "north",
			trialSouth: "south",
			claimMiniCoins: "Settle coins from this game",
			claimTournamentSkills: "Gain 1 overpower per bout won",
			trialRace: "Trial of speed",
			raceInstructions: "Move the racer matching each skill die one space forward, straight or diagonally, without sharing a space. Use all movement for one racer before moving another. Blocked movement is lost. Roll six dice again after all movement is used. The first racer across the finish wins.",
			raceYourToken: "Your racer: {{skill}}",
			raceBoard: "Race track with numbered spaces",
			racerMoves: "{{skill}} · {{n}} moves",
			crossFinish: "Cross the finish line",
			moveToRaceCell: "Move to space {{n}}",
			racerBlocked: "No forward space: end this racer’s movement",
			nextRaceRound: "Roll the next six dice",
			trialTrade: "Trial of negotiation",
			trialMancala: "Time-loop mancala",
			trialTournament: "Eight-fighter tournament",
			trialArena: "Trial of combat",
			perfecto: "Perfecto",
			pinch: "Pinch",
			press: "Press",
			punch: "Punch",
			tradeInstructions: "Trade with Minic, Bastia, then Lak. Choose at most one offer in each section, once. After leaving a merchant you cannot return. Trade colored tokens to obtain the Gold Emblem.",
			mancalaInstructions: "Spend one time cube to pick up every die in one circle. Place them one at a time clockwise, choosing their order. You may skip a nonempty circle containing only one skill. Finish with each skill in its own circle.",
			tournamentInstructions: "Resolve each bout by counting overpower results. Lower strength wins a tie. If both strength and results tie, replay the bout. Your fighter replaces number 8 when participating. Bets are fixed before the first bout.",
			arenaInstructions: "Win each bout with at least one look and one overpower. Each move die may be rerolled alone or with one other die. Each take loses one health unless blocked by an engage or help.",
			perfectoInstructions: "Bet 1–6 coins, then try to make all six dice identical. Each reroll can include any dice. Win twice your bet if all final faces match; otherwise lose your bet.",
			pinchInstructions: "After paying the entry fee, roll six dice. An engage earns two coins. Keep your winnings or continue with one fewer die. If a roll has no engage, lose the previous roll’s two coins and stop.",
			pressInstructions: "Roll one die at a time and stop when you choose. A repeated skill busts and ends your rolling. The opponent rolls until they bust. Compare the number of different dice: ties win twice your bet; otherwise lose the bet.",
			punchInstructions: "Bet up to three coins on each skill. Roll two dice. Each matching die pays twice that skill’s bet, then all bets are lost.",
			tokenBlue: "Blue",
			tokenPurple: "Purple",
			tokenOrange: "Orange",
			tokenGreen: "Green",
			tokenYellow: "Yellow",
			tokenRed: "Red",
			merchantName: "Merchant: {{name}}",
			tradeSection: "Section {{n}}",
			exchangeFor: "Trade for",
			goldEmblem: "Gold Emblem",
			nextMerchant: "Leave and visit the next merchant",
			endTrial: "End the trial",
			timeCubes: "Time cubes remaining: {{n}}",
			pickCircle: "Pick up circle {{n}}",
			dropCircle: "Place the next die in circle {{n}}",
			dropSkillDie: "Place one {{skill}} die",
			skipPureCircle: "Skip this single-skill circle",
			betCoins: "Coins to bet",
			confirmBet: "Confirm bets and begin",
			totalBet: "Total bet: {{n}} · Available coins: {{coins}}",
			fighterOdds: "Fighter {{n}} · strength {{strength}} · ×{{multiplier}}",
			pendingMiniCoins: "Unsettled coin change: {{n}}",
			finalMiniCoins: "Final coin change: {{n}}",
			currentBout: "Fighter {{a}} versus fighter {{b}}",
			boutResult: "{{a}} versus {{b}}: fighter {{winner}} wins",
			confirmBout: "Confirm this bout",
			rollBout: "Roll this bout",
			arenaProgress: "Bouts won: {{wins}} · Health lost: {{damage}}",
			rerollsRemaining: "Rerolls remaining: {{n}}",
			pressFinal: "Different dice: you {{mine}}, opponent {{enemy}}",
			rollAnotherDie: "Roll another die",
			compareOpponent: "Stop and compare with the opponent",
			rollPinchDice: "Roll {{n}} dice",
			keepWinnings: "Stop and keep winnings",
			confirmRoll: "Confirm these dice",
			nextBout: "Begin the next bout",
			startTrial: "Begin the trial",
			claimDanceCoins: "Claim coins for placed dance dice",
			trialPoker: "Dice poker",
			trialHunt: "Trial of hunting",
			trialSlide: "Sliding dice puzzle",
			trialDance: "Trial of dance",
			trialSucceeded: "Trial succeeded. Resolve the reward.",
			trialFailed: "Trial failed. Resolve the outcome.",
			trialRound: "Round {{n}} of 3",
			pokerInstructions: "After each shared die is revealed, reroll either or both of your dice once. After three shared dice, compare your five-die hand with both opponents. Ties win.",
			huntInstructions: "Reroll any of your dice once each round. For each skill, the hunter with more results captures the other hunter’s dice of that skill. After three rounds, win with more dice.",
			slideInstructions: "Push the extra die into any row or column; the die leaving the other end becomes the extra die. After each push, spend one water cube to reroll it once. Make every row or every column contain identical skills.",
			danceInstructions: "Place one die orthogonally beside the previous step. Never repeat a skill in the same row or column. Doubles allow either or both dice to be rerolled. Use all six skills and return beside the first step, within twelve steps.",
			sharedDice: "Shared dice",
			yourDice: "Your dice",
			opponentDice: "Opponent dice",
			extraDie: "Extra die",
			waterRemaining: "Water cubes remaining: {{n}}",
			huntFinal: "Final dice: you {{mine}}, opponent {{enemy}}",
			pokerRank: "Your hand rank: {{n}} (1 lowest, 7 highest)",
			danceCount: "{{n}} dance dice placed",
			rerollTrialDice: "Reroll selected dice",
			nextTrialRound: "Keep and begin next round",
			finishTrial: "Confirm final results",
			rerollExtraDie: "Spend 1 water cube to reroll the extra die",
			pushRow: "Push row {{n}} toward {{direction}}",
			pushColumn: "Push column {{n}} toward {{direction}}",
			completeArrangement: "Confirm the completed arrangement",
			endUnsolvedTrial: "Out of water: end the trial",
			placeDanceDie: "Place {{skill}} at ({{x}}, {{y}})",
			noDancePlacement: "No legal placement: end the trial",
			rebornUndo: "Pay 3 boost to undo this action and choose another",
			foodDonation: "Choose boost to remove from food cards. Gain 1 coin and 1 morale for each boost. Donate at least 4 to also gain ring 993.",
			confirmFoodDonation: "Donate {{n}} food boost",
			chooseInnocentSentient: "Choose an innocent sentient to join you.",
			fillInnocentSentients: "Fill the innocent sentients you already own with boost.",
			fillSentientBoost: "Fill with boost",
			boostQuestEgg: "Add 1 boost to the egg",
			deliverBarrel: "Deliver the barrel and claim coins",
			boostHostage: "Add 1 boost to sentient 1349",
			deliverSoulstone: "Deliver the blue crystal and claim rewards",
			becomeReborn: "Exchange bodies and become Reborn",
			restoreBody: "Restore your original character and gain 1 morale",
			supplyBoost: "Boost {{n}}",
			shelter: "Shelter",
			questFlagProgress: "Place 1 flag at this location",
			claimMurderReward: "Claim the investigation reward",
			questHerdProgress: "Add hulk tokens for final move results, up to 4",
			questSiegeProgress: "Add the declared X tokens, then remove one per unplaced die",
			questWaterConquestProgress: "Record this conquest and gain overpower skills equal to the token count",
			confirmLandLocation: "Confirm from the scene: this is a land location",
			pathStationInstructions: "Compare the quest card with the current location and mark a symbol you recognize. Each symbol counts once. Resolve the quest at the final symbol’s location.",
			confirmPathStation: "Confirm that the selected symbol is visible at the current location",
			recordPathStation: "Record symbol {{n}}",
			pathStationRecorded: "Symbol {{n}} already recorded",
			claimPathReward: "Gain 1 random skill per marked symbol",
			tameAnimal: "Pay 2 boost to make animal {{n}} loyal",
			animalRideUnlisted: "{{direction}}: ride to an unlisted location",
			rideChooseX: "Choose X for the following effects. This ride has no action cost and rolls no challenge dice.",
			startPearlDefense: "Protect the Pearl: roll 3 skill dice",
			pearlDefenseInstructions: "Remaining action skills: {{skills}}. Perform one matching action per distinct result with a base cost of 3, then continue.",
			continuePearlDefense: "Continue defending the Pearl",
			reserveCount: "Reserve {{n}} / {{max}}"
		}
	}
};
//#endregion
export { ec as default };
