import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useState as r } from "react";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { Texture as s } from "@bgparty/sdk/texture";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as u, seatName as d } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { GameOverScreen as h } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/rss/meta.ts
var g = {
	id: "rss",
	tier: "alpha",
	mechanics: ["auction", "stock-holding"],
	interactionTags: [],
	nameKey: "games.rss.name",
	descKey: "games.rss.desc",
	rulesKey: "games.rss.rules",
	icon: "🚂",
	iconImg: "games/rss.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/rss/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [4],
	accent: "#0369a1",
	releasedAt: "2026-09-17",
	search: {
		py: "jiao yun zhi xing",
		init: "jyzx"
	},
	hotseat: "cover"
}, _ = t.discriminatedUnion("type", [
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("startAuction"),
		company: t.string(),
		bid: t.number().int().min(0)
	}),
	t.object({
		type: t.literal("raiseBid"),
		amount: t.number().int().min(1)
	}),
	t.object({ type: t.literal("leaveAuction") }),
	t.object({
		type: t.literal("buyShare"),
		corp: t.string()
	}),
	t.object({
		type: t.literal("sellShare"),
		corp: t.string()
	}),
	t.object({
		type: t.literal("proposeDeal"),
		buyer: t.string(),
		company: t.string(),
		price: t.number().int().min(0)
	}),
	t.object({
		type: t.literal("respondDeal"),
		accept: t.boolean()
	}),
	t.object({
		type: t.literal("intervene"),
		accept: t.boolean()
	}),
	t.object({ type: t.literal("doneAcquire") }),
	t.object({
		type: t.literal("closeCompany"),
		company: t.string()
	}),
	t.object({ type: t.literal("doneClosing") }),
	t.object({
		type: t.literal("setDividend"),
		amount: t.number().int().min(0)
	}),
	t.object({
		type: t.literal("setIssue"),
		issue: t.boolean()
	}),
	t.object({
		type: t.literal("ipo"),
		company: t.string(),
		corp: t.string(),
		priceIdx: t.number().int().min(0)
	}),
	t.object({
		type: t.literal("ipoPass"),
		company: t.string()
	})
]), v = t.object({
	id: t.string(),
	cash: t.number(),
	companies: t.array(t.string()),
	shares: t.record(t.string(), t.number()),
	bankShares: t.number(),
	unissued: t.number(),
	president: t.string().nullable(),
	priceIdx: t.number().nullable()
}), y = t.object({
	buyer: t.string(),
	company: t.string(),
	price: t.number(),
	sellerKind: t.enum([
		"fi",
		"player",
		"corp"
	]),
	sellerId: t.string(),
	suitors: t.array(t.string()),
	auto: t.boolean()
}), b = t.object({
	turn: t.number(),
	phase: t.enum([
		"invest",
		"acquire",
		"close",
		"dividend",
		"issue",
		"ipo",
		"done"
	]),
	endFlipped: t.boolean(),
	deckTop: t.enum([
		"red",
		"orange",
		"yellow",
		"green",
		"blue",
		"end",
		"flipped"
	]),
	deckCount: t.number(),
	players: t.array(t.object({
		rid: t.string(),
		cash: t.number(),
		companies: t.array(t.string())
	})),
	fi: t.object({
		cash: t.number(),
		companies: t.array(t.string())
	}),
	offering: t.array(t.object({
		id: t.string(),
		vertical: t.boolean()
	})),
	corps: t.array(v),
	charters: t.array(t.string()),
	priceRow: t.array(t.string().nullable()),
	invest: t.object({
		actor: t.string(),
		passed: t.array(t.string()),
		auction: t.object({
			company: t.string(),
			highBid: t.number(),
			highBidder: t.string(),
			bidders: t.array(t.string()),
			turn: t.string(),
			starter: t.string()
		}).nullable()
	}).nullable(),
	acquire: t.object({
		done: t.array(t.string()),
		used: t.array(t.string()),
		deal: y.nullable()
	}).nullable(),
	closeDone: t.array(t.string()).nullable(),
	dividendQueue: t.array(t.string()).nullable(),
	issueQueue: t.array(t.string()).nullable(),
	ipoQueue: t.array(t.string()).nullable(),
	result: t.object({
		scores: t.record(t.string(), t.number()),
		ranking: t.array(t.string())
	}).nullable()
}), x = t.object({}), S = (e, t, n, r, i, a) => ({
	id: e,
	name: t,
	tier: n,
	face: r,
	income: i,
	synergies: a
}), C = Object.fromEntries([
	S("BME", "Bergisch-Märkische Eisenbahn-Gesellschaft", "red", 1, 1, [
		"KME",
		"BD",
		"HE",
		"PR"
	]),
	S("BSE", "Berlin-Stettiner Eisenbahn-Gesellschaft", "red", 2, 1, [
		"BPM",
		"SX",
		"MS",
		"PR"
	]),
	S("KME", "Köln-Mindener Eisenbahn-Gesellschaft", "red", 5, 2, [
		"BME",
		"MHE",
		"HE",
		"OL",
		"PR"
	]),
	S("AKE", "Altona-Kieler Eisenbahn-Gesellschaft", "red", 6, 2, [
		"BPM",
		"MHE",
		"OL",
		"MS",
		"PR"
	]),
	S("BPM", "Berlin-Potsdam-Magdeburger Eisenbahn", "red", 7, 2, [
		"BSE",
		"AKE",
		"MHE",
		"SX",
		"MS",
		"PR"
	]),
	S("MHE", "Magdeburg-Halberstädter Eisenbahngesellschaft", "red", 8, 2, [
		"KME",
		"AKE",
		"BPM",
		"OL",
		"SX",
		"MS",
		"PR"
	]),
	S("WT", "Königlich Württembergische Staats-Eisenbahnen", "orange", 11, 3, [
		"BY",
		"BD",
		"SBB",
		"DR"
	]),
	S("BY", "Königlich Bayerische Staatseisenbahnen", "orange", 12, 3, [
		"WT",
		"HE",
		"SX",
		"KK",
		"DR"
	]),
	S("BD", "Großherzoglich Badische Staatseisenbahnen", "orange", 13, 3, [
		"BME",
		"WT",
		"HE",
		"SBB",
		"SNCF",
		"DR"
	]),
	S("HE", "Großherzoglich Hessische Staatseisenbahnen", "orange", 14, 3, [
		"BME",
		"KME",
		"BY",
		"BD",
		"PR",
		"DR"
	]),
	S("OL", "Großherzoglich Oldenburgische Staatseisenbahnen", "orange", 15, 3, [
		"KME",
		"AKE",
		"MHE",
		"MS",
		"PR",
		"DSB",
		"NS",
		"DR"
	]),
	S("SX", "Königlich Sächsische Staatseisenbahnen", "orange", 16, 3, [
		"BSE",
		"BPM",
		"MHE",
		"BY",
		"MS",
		"PR",
		"KK",
		"PKP",
		"DR"
	]),
	S("MS", "Großherzoglich Mecklenburgische Friedrich-Franz-Eisenbahn", "orange", 17, 3, [
		"BSE",
		"AKE",
		"BPM",
		"MHE",
		"OL",
		"SX",
		"PR",
		"DSB",
		"PKP",
		"DR"
	]),
	S("PR", "Preußische Staatseisenbahnen", "orange", 19, 3, [
		"BME",
		"BSE",
		"KME",
		"AKE",
		"BPM",
		"MHE",
		"HE",
		"OL",
		"SX",
		"MS",
		"DSB",
		"NS",
		"B",
		"PKP",
		"DR"
	]),
	S("DSB", "Danske Statsbaner", "yellow", 20, 5, [
		"OL",
		"MS",
		"PR",
		"DR",
		"BSR",
		"HH"
	]),
	S("KK", "k.k. Österreichische Staatsbahnen", "yellow", 21, 5, [
		"BY",
		"SX",
		"SBB",
		"PKP",
		"DR",
		"FS",
		"FRA"
	]),
	S("NS", "Nederlandse Spoorwegen", "yellow", 22, 5, [
		"OL",
		"PR",
		"B",
		"DR",
		"E",
		"HA",
		"HR"
	]),
	S("SBB", "Schweizerische Bundesbahnen", "yellow", 23, 5, [
		"WT",
		"BD",
		"KK",
		"SNCF",
		"DR",
		"FS",
		"FRA",
		"CDG"
	]),
	S("B", "Nationale Maatschappij der Belgische Spoorwegen", "yellow", 24, 5, [
		"PR",
		"NS",
		"SNCF",
		"DR",
		"E",
		"HA",
		"HR"
	]),
	S("PKP", "Polskie Koleje Państwowe", "yellow", 25, 5, [
		"SX",
		"MS",
		"PR",
		"KK",
		"DR",
		"SZD",
		"BSR",
		"HH",
		"FRA"
	]),
	S("SNCF", "Société nationale des chemins de fer français", "yellow", 26, 5, [
		"BD",
		"SBB",
		"B",
		"DR",
		"FS",
		"RENFE",
		"E",
		"HA",
		"CDG"
	]),
	S("DR", "Deutsche Reichsbahn", "yellow", 29, 5, [
		"WT",
		"BY",
		"BD",
		"HE",
		"OL",
		"SX",
		"MS",
		"PR",
		"DSB",
		"KK",
		"NS",
		"SBB",
		"B",
		"PKP",
		"SNCF",
		"BSR",
		"HH",
		"HR",
		"FRA"
	]),
	S("SZD", "Sovetskie železnye dorogi", "green", 30, 7, ["PKP"]),
	S("SJ", "Statens Järnvägar", "green", 31, 7, ["BSR"]),
	S("FS", "Ferrovie dello Stato", "green", 32, 7, [
		"KK",
		"SBB",
		"SNCF"
	]),
	S("RENFE", "Red Nacional de los Ferrocarriles Españoles", "green", 33, 7, ["SNCF", "MAD"]),
	S("BR", "British Rail", "green", 34, 7, ["E", "LHR"]),
	S("BSR", "Baltic Sea Rail", "green", 36, 7, [
		"DSB",
		"PKP",
		"DR",
		"SJ",
		"HH"
	]),
	S("E", "Eurotunnel", "green", 43, 7, [
		"NS",
		"B",
		"SNCF",
		"BR",
		"HA",
		"HR",
		"LHR",
		"CDG"
	]),
	S("HH", "Hamburger Hafen", "blue", 45, 10, [
		"DSB",
		"PKP",
		"DR",
		"BSR"
	]),
	S("HA", "Haven van Antwerpen", "blue", 46, 10, [
		"NS",
		"B",
		"SNCF",
		"E"
	]),
	S("HR", "Haven van Rotterdam", "blue", 47, 10, [
		"NS",
		"B",
		"DR",
		"E"
	]),
	S("MAD", "Madrid-Barajas Airport", "blue", 50, 10, ["RENFE", "CDG"]),
	S("FRA", "Flughafen Frankfurt", "blue", 56, 10, [
		"KK",
		"SBB",
		"PKP",
		"DR",
		"LHR",
		"CDG"
	]),
	S("LHR", "London Heathrow Airport", "blue", 58, 10, [
		"BR",
		"E",
		"FRA",
		"CDG"
	]),
	S("CDG", "Aéroport Paris-Charles-de-Gaulle", "blue", 60, 10, [
		"SBB",
		"SNCF",
		"E",
		"MAD",
		"FRA",
		"LHR"
	])
].map((e) => [e.id, e])), w = [
	"red",
	"orange",
	"yellow",
	"green",
	"blue"
], T = [
	0,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	12,
	13,
	14,
	16,
	18,
	20,
	22,
	24,
	27,
	30,
	33,
	37,
	41,
	45,
	50,
	55,
	61,
	68,
	75
], E = {
	red: [6, 10],
	orange: [6, 13],
	yellow: [11, 16],
	green: [14, 19],
	blue: [17, 19]
}, D = {
	jupiter: {
		id: "jupiter",
		name: "Prussian Railway",
		shares: 5
	},
	saturn: {
		id: "saturn",
		name: "Doppler AG",
		shares: 5
	},
	horse: {
		id: "horse",
		name: "Synergistic",
		shares: 7
	},
	bear: {
		id: "bear",
		name: "Vintage Machinery",
		shares: 4
	},
	eagle: {
		id: "eagle",
		name: "Stock Masters",
		shares: 6
	},
	orion: {
		id: "orion",
		name: "Overseas Trading",
		shares: 6
	},
	ship: {
		id: "ship",
		name: "Junkyard Scrappers",
		shares: 7
	},
	star: {
		id: "star",
		name: "Stars Inc.",
		shares: 4
	}
};
Object.keys(D);
var O = {
	red: "MHE",
	orange: "PR",
	yellow: "DR",
	green: "E",
	blue: "CDG"
};
function k(e) {
	return Math.ceil(e.face / 2);
}
function A(e) {
	return e.id === "BME" ? 2 : e.id === "BSE" ? 3 : e.id === "KME" ? 7 : Math.floor(e.face * 4 / 3);
}
function j(e, t) {
	return e === "red" || t === "red" ? 1 : e === "orange" || t === "orange" ? 2 : e === "yellow" && t === "yellow" || e === "yellow" || t === "yellow" ? 4 : e === "green" && t === "green" || e === "green" || t === "green" ? 8 : 16;
}
var M = {
	red: 1,
	orange: 2,
	yellow: 3,
	green: 4,
	blue: 5
};
function N(e, t) {
	return Math.round(e * t / 10);
}
function P(e) {
	return Math.floor(e / 3);
}
function F(e, t) {
	switch (t) {
		case "green": return e === "red" ? 2 : 0;
		case "blue": return e === "red" || e === "orange" ? 4 : 0;
		case "end": return e === "red" || e === "orange" || e === "yellow" ? 7 : 0;
		case "flipped": return e === "blue" ? 0 : 10;
		default: return 0;
	}
}
function I(e) {
	let t = new Set(e), n = 0;
	for (let r of e) {
		let e = C[r];
		for (let r of e.synergies) {
			let i = C[r];
			t.has(r) && i.face < e.face && (n += j(e.tier, i.tier));
		}
	}
	return n;
}
function L(e) {
	let t = new Set(e), n = 0;
	for (let r of e) for (let e of C[r].synergies) t.has(e) && (n += 1);
	return n / 2;
}
var ee = Object.values(C);
function R(e, t) {
	let n = ee.filter((t) => t.tier === e).length;
	return t >= 6 ? n - 1 : e === "orange" && t === 4 ? 4 : e === "orange" && t === 5 ? 6 : t - 1;
}
//#endregion
//#region src/games/rss/rules.ts
var z = (e, t) => ({
	code: e,
	params: t
});
function B(e) {
	return e.priceIdx ?? T.length - 1;
}
function V(e) {
	return T[B(e)];
}
function H(e) {
	return D[e.id].shares - e.unissued;
}
function U(e, t) {
	return e.corps.find((e) => e.id === t);
}
function W(e, t) {
	return e.players.find((e) => e.rid === t);
}
function G(e) {
	return e.deck.length > 0 ? C[e.deck[0]].tier : e.endFlipped ? "flipped" : "end";
}
function K(e) {
	return new Set(e.corps.filter((e) => e.priceIdx !== null).map((e) => e.priceIdx));
}
function q(e, t, n) {
	let r = K(e);
	for (let e = t; e >= 0 && e < T.length; e += n) if (!r.has(e)) return e;
	return null;
}
function te(e) {
	return [...e.corps].sort((e, t) => B(t) - B(e) || e.formed - t.formed);
}
function ne(e, t) {
	if (e.fi.companies.includes(t)) return {
		kind: "fi",
		id: "fi"
	};
	for (let n of e.players) if (n.companies.includes(t)) return {
		kind: "player",
		id: n.rid
	};
	for (let n of e.corps) if (n.companies.includes(t)) return {
		kind: "corp",
		id: n.id
	};
	return null;
}
function J(e, t) {
	e.corps = e.corps.filter((e) => e !== t), e.charters.push(t.id);
}
function re(e) {
	let t = new Map(e.players.map((e, t) => [e.rid, t]));
	for (e.players.sort((e, n) => n.cash - e.cash || (t.get(e.rid) ?? 0) - (t.get(n.rid) ?? 0));;) {
		let t = e.offering.filter((t) => !t.vertical && C[t.id].face <= e.fi.cash).sort((e, t) => C[e.id].face - C[t.id].face);
		if (!t.length) break;
		let n = t[0];
		e.fi.cash -= C[n.id].face, e.fi.companies.push(n.id), e.offering = e.offering.filter((e) => e !== n), e.deck.length > 0 && e.offering.push({
			id: e.deck.shift(),
			vertical: !0
		});
	}
	for (let t of e.offering) t.vertical = !1;
}
function ie(e) {
	let t = G(e);
	for (let n of e.players) n.cash += n.companies.reduce((e, n) => e + C[n].income - F(C[n].tier, t), 0);
	e.fi.cash += 5 + e.fi.companies.reduce((e, n) => e + C[n].income - F(C[n].tier, t), 0);
	for (let n of [...e.corps]) {
		let r = n.companies.map((e) => C[e]), i = r.reduce((e, t) => e + t.income, 0), a = r.reduce((e, n) => e + F(n.tier, t), 0);
		n.id === "bear" && (a = Math.max(0, a - 10)), i += I(n.companies), n.id === "jupiter" && (i += r.length), n.id === "saturn" && r.length > 0 && (i += Math.max(...r.map((e) => e.income))), n.id === "horse" && (i += Math.floor(L(n.companies) / 2)), n.cash += i - a, n.cash < 0 && J(e, n);
	}
}
function ae(e, t, n, r) {
	if (t.id === "orion") return [];
	let i = [], a = e.corps.find((e) => e.id === "orion");
	a && a !== t && a.president !== null && a.president !== t.president && a.cash >= r && i.push(a);
	let o = e.corps.filter((e) => e !== t && e.id !== "orion" && e.president !== null && e.president !== t.president && B(e) > B(t) && e.cash >= n).sort((e, t) => B(t) - B(e) || e.formed - t.formed);
	return [...i, ...o].map((e) => e.id);
}
function oe(e) {
	let t = e.acquire;
	if (t) {
		for (; !t.deal && t.recvQueue.length > 0;) {
			let n = U(e, t.recvQueue[0]);
			if (!n || n.president !== null) {
				t.recvQueue.shift();
				continue;
			}
			let r = e.fi.companies.map((e) => C[e]).filter((e) => n.cash >= (n.id === "orion" ? e.face : A(e))).sort((e, t) => t.face - e.face);
			if (!r.length) {
				t.recvQueue.shift();
				continue;
			}
			let i = r[0], a = n.id === "orion" ? i.face : A(i);
			t.deal = {
				buyer: n.id,
				company: i.id,
				price: a,
				sellerKind: "fi",
				sellerId: "fi",
				suitors: ae(e, n, a, i.face),
				auto: !0
			};
		}
		t.deal && t.deal.sellerKind === "fi" && t.deal.suitors.length === 0 && Y(e);
	}
}
function Y(e) {
	let t = e.acquire;
	if (!t || !t.deal) return;
	let n = t.deal, r = U(e, n.buyer);
	if (t.deal = null, r) {
		if (r.cash -= n.price, n.sellerKind === "fi") e.fi.cash += n.price, e.fi.companies = e.fi.companies.filter((e) => e !== n.company);
		else if (n.sellerKind === "player") {
			let t = W(e, n.sellerId);
			t && (t.cash += n.price, t.companies = t.companies.filter((e) => e !== n.company));
		} else {
			let t = U(e, n.sellerId);
			t && (t.cash += n.price, t.companies = t.companies.filter((e) => e !== n.company));
		}
		r.companies.push(n.company), t.used.push(n.company), t.done = [], oe(e);
	}
}
function se(e) {
	if (e.corps.length === 0) {
		le(e);
		return;
	}
	e.phase = "acquire", e.acquire = {
		done: [],
		used: [],
		deal: null,
		recvQueue: e.corps.filter((e) => e.president === null).sort((e, t) => e.id === "orion" ? -1 : t.id === "orion" ? 1 : B(t) - B(e) || e.formed - t.formed).map((e) => e.id)
	}, oe(e);
}
function ce(e, t) {
	e.companies = e.companies.filter((e) => e !== t), e.id === "ship" && (e.cash += C[t].income * 2);
}
function le(e) {
	e.phase = "close", e.closeDone = [];
	let t = G(e);
	e.fi.companies = e.fi.companies.filter((e) => F(C[e].tier, t) <= C[e].income);
	for (let n of e.corps.filter((e) => e.president === null)) {
		let e = n.companies.filter((e) => {
			let n = C[e], r = F(n.tier, t);
			return n.tier === "red" && r >= 4 || n.tier === "orange" && r >= 7;
		}).sort((e, t) => C[e].face - C[t].face);
		for (let t of e) {
			if (n.companies.length <= 1) break;
			ce(n, t);
		}
	}
}
function ue(e, t) {
	let n = V(t), r = t.companies.reduce((e, t) => e + M[C[t].tier], 0) + Math.floor(t.cash / 10);
	t.id === "star" && (r += 2);
	let i = r - N(H(t), n), a = i >= 2 ? 2 : i === 1 ? 1 : i === -1 ? -1 : i <= -2 ? -2 : 0;
	a !== 0 && de(e, t, a);
}
function de(e, t, n) {
	let r = B(t);
	if (n > 0) t.priceIdx = q(e, Math.min(r + n, T.length - 1), 1);
	else {
		let i = q(e, r + n, -1);
		if (i === null) return;
		t.priceIdx = i, i === 0 && J(e, t);
	}
}
function fe(e, t, n) {
	t.cash -= n * H(t);
	for (let [r, i] of Object.entries(t.shares)) {
		let t = W(e, r);
		t && (t.cash += n * i);
	}
	ue(e, t);
}
function pe(e) {
	let t = e.dividendQueue;
	if (t) {
		for (; t.length > 0;) {
			let n = U(e, t[0]);
			if (!n) {
				t.shift();
				continue;
			}
			if (n.president !== null) return;
			t.shift(), fe(e, n, 0);
		}
		he(e);
	}
}
function me(e) {
	let t = {};
	for (let n of e.players) {
		let r = n.cash + n.companies.reduce((e, t) => e + C[t].face, 0);
		for (let t of e.corps) r += (t.shares[n.rid] ?? 0) * V(t);
		t[n.rid] = r;
	}
	let n = new Map(e.players.map((e, t) => [e.rid, t]));
	e.result = {
		scores: t,
		ranking: e.players.map((e) => e.rid).sort((e, r) => t[r] - t[e] || (n.get(e) ?? 0) - (n.get(r) ?? 0))
	}, e.phase = "done";
}
function he(e) {
	if (e.dividendQueue = null, e.corps.some((e) => B(e) === T.length - 1)) {
		me(e);
		return;
	}
	if (e.endFlipped) {
		me(e);
		return;
	}
	e.offering.length === 0 && e.deck.length === 0 && (e.endFlipped = !0), ve(e);
}
function ge(e, t) {
	if (!(t.unissued <= 0)) {
		if (t.id === "eagle") t.cash += V(t);
		else {
			let n = q(e, B(t) - 1, -1);
			if (n === null) return;
			t.priceIdx = n, t.cash += T[n];
		}
		--t.unissued, t.bankShares += 1, t.priceIdx === 0 && J(e, t);
	}
}
function _e(e) {
	let t = e.issueQueue;
	if (t) {
		for (; t.length > 0;) {
			let n = U(e, t[0]);
			if (!n) {
				t.shift();
				continue;
			}
			if (n.president !== null) return;
			t.shift(), ge(e, n);
		}
		ye(e);
	}
}
function ve(e) {
	e.phase = "issue", e.issueQueue = te(e).map((e) => e.id), _e(e);
}
function ye(e) {
	e.issueQueue = null, e.phase = "ipo", e.ipoQueue = e.players.flatMap((e) => e.companies).sort((e, t) => C[t].face - C[e].face), e.ipoQueue.length === 0 && be(e);
}
function be(e) {
	e.ipoQueue = null, e.turn += 1, e.phase = "invest", e.invest = {
		actor: 0,
		passed: [],
		auction: null
	};
}
function xe(t, n, r) {
	let i = n.length, a = 0, o = (t) => {
		for (let n = t.length - 1; n > 0; n--) {
			let i = e(r, a++, n + 1);
			[t[n], t[i]] = [t[i], t[n]];
		}
		return t;
	}, s = [];
	for (let e of w) {
		let t = o(Object.values(C).filter((t) => t.tier === e).filter((t) => t.id !== O[e]).map((e) => e.id)), n = [O[e], ...t.slice(0, R(e, i))];
		s.push(...o(n));
	}
	let c = s.splice(0, i).map((e) => ({
		id: e,
		vertical: !1
	}));
	return { state: {
		rngSeed: r,
		rngCursor: a,
		turn: 1,
		phase: "invest",
		endFlipped: !1,
		deck: s,
		players: n.map((e) => ({
			rid: e,
			cash: i === 6 ? 25 : 30,
			companies: []
		})),
		fi: {
			cash: 4,
			companies: []
		},
		offering: c,
		corps: [],
		charters: Object.keys(D),
		formedSeq: 0,
		invest: {
			actor: 0,
			passed: [],
			auction: null
		},
		acquire: null,
		closeDone: null,
		dividendQueue: null,
		issueQueue: null,
		ipoQueue: null,
		result: null
	} };
}
function Se(e, t, n) {
	let r = structuredClone(e), i = W(r, n.by);
	if (!i || r.phase === "done") return z("games.rss.errBadPhase");
	switch (t.type) {
		case "pass": return r.phase !== "invest" || !r.invest || r.invest.auction ? z("games.rss.errBadPhase") : r.players[r.invest.actor].rid === n.by ? (r.invest.passed.includes(n.by) || r.invest.passed.push(n.by), r.invest.passed.length === r.players.length ? (r.invest = null, re(r), se(r)) : r.invest.actor = (r.invest.actor + 1) % r.players.length, { state: r }) : z("games.rss.errNotYourTurn");
		case "startAuction": {
			if (r.phase !== "invest" || !r.invest || r.invest.auction) return z("games.rss.errBadPhase");
			if (r.players[r.invest.actor].rid !== n.by) return z("games.rss.errNotYourTurn");
			let e = r.offering.find((e) => e.id === t.company), a = C[t.company];
			if (!e || !a) return z("games.rss.errNoSuchCompany");
			if (e.vertical) return z("games.rss.errNotAvailable");
			if (t.bid < a.face) return z("games.rss.errBidTooLow");
			if (t.bid > i.cash) return z("games.rss.errNotEnoughCash");
			let o = r.players.map((e) => e.rid);
			return r.invest.passed = r.invest.passed.filter((e) => e !== n.by), r.invest.auction = {
				company: t.company,
				highBid: t.bid,
				highBidder: n.by,
				bidders: o,
				turn: o[(r.invest.actor + 1) % o.length],
				starter: n.by
			}, { state: r };
		}
		case "raiseBid": {
			let e = r.invest?.auction;
			return r.phase !== "invest" || !e ? z("games.rss.errBadPhase") : e.turn === n.by ? t.amount <= e.highBid ? z("games.rss.errMustRaise") : t.amount > i.cash ? z("games.rss.errNotEnoughCash") : (e.highBid = t.amount, e.highBidder = n.by, e.turn = Ce(e, n.by), { state: r }) : z("games.rss.errNotYourTurn");
		}
		case "leaveAuction": {
			let e = r.invest?.auction;
			if (r.phase !== "invest" || !e) return z("games.rss.errBadPhase");
			if (e.turn !== n.by) return z("games.rss.errNotYourTurn");
			if (e.highBidder === n.by) return z("games.rss.errBadPhase");
			let t = e.bidders.indexOf(n.by);
			return e.bidders.splice(t, 1), e.bidders.length === 1 ? we(r, e) : e.turn = e.bidders[t % e.bidders.length], { state: r };
		}
		case "buyShare": {
			if (r.phase !== "invest" || !r.invest || r.invest.auction) return z("games.rss.errBadPhase");
			if (r.players[r.invest.actor].rid !== n.by) return z("games.rss.errNotYourTurn");
			let e = U(r, t.corp);
			if (!e || e.bankShares <= 0) return z("games.rss.errNoShares");
			if (e.priceIdx === null) return z("games.rss.errNoHigherCard");
			let a = q(r, e.priceIdx + 1, 1);
			if (a === null) return z("games.rss.errNoHigherCard");
			let o = T[a];
			return i.cash < o ? z("games.rss.errNotEnoughCash") : (e.priceIdx = a, i.cash -= o, --e.bankShares, e.shares[n.by] = (e.shares[n.by] ?? 0) + 1, (e.president === null || n.by !== e.president && e.shares[n.by] > (e.shares[e.president] ?? 0)) && (e.president = n.by), r.invest.passed = r.invest.passed.filter((e) => e !== n.by), r.invest.actor = (r.invest.actor + 1) % r.players.length, a === T.length - 1 && me(r), { state: r });
		}
		case "sellShare": {
			if (r.phase !== "invest" || !r.invest || r.invest.auction) return z("games.rss.errBadPhase");
			if (r.players[r.invest.actor].rid !== n.by) return z("games.rss.errNotYourTurn");
			let e = U(r, t.corp);
			if (!e || (e.shares[n.by] ?? 0) <= 0) return z("games.rss.errNotSellable");
			let a = q(r, B(e) - 1, -1);
			if (a === null) return z("games.rss.errNotSellable");
			if (e.priceIdx = a, i.cash += T[a], --e.shares[n.by], e.shares[n.by] === 0 && delete e.shares[n.by], e.bankShares += 1, e.president === n.by) {
				if (e.bankShares === H(e)) e.president = null;
				else {
					let t = e.shares[n.by] ?? 0, i = Math.max(0, ...Object.values(e.shares));
					if (i > t) {
						let t = r.players.map((e) => e.rid), a = t.indexOf(n.by), o = null;
						for (let n = 1; n <= t.length; n++) {
							let r = t[(a + n) % t.length];
							if ((e.shares[r] ?? 0) === i) {
								o = r;
								break;
							}
						}
						e.president = o;
					}
				}
			}
			return r.invest.passed = r.invest.passed.filter((e) => e !== n.by), r.invest.actor = (r.invest.actor + 1) % r.players.length, e.priceIdx === 0 && J(r, e), { state: r };
		}
		case "proposeDeal": {
			let e = r.acquire;
			if (r.phase !== "acquire" || !e) return z("games.rss.errBadPhase");
			if (e.deal) return z("games.rss.errDealPending");
			let i = U(r, t.buyer), a = C[t.company];
			if (!i || !a) return z("games.rss.errNoSuchCompany");
			if (i.president !== n.by) return z("games.rss.errNotPresident");
			if (e.used.includes(t.company)) return z("games.rss.errNotAvailable");
			let o = ne(r, t.company);
			if (!o) return z("games.rss.errNotAvailable");
			if (o.kind === "corp" && o.id === i.id) return z("games.rss.errBadPrice");
			if (o.kind === "corp") {
				let e = U(r, o.id);
				if (!e || e.president === null) return z("games.rss.errReceivership");
				if (e.companies.length <= 1) return z("games.rss.errCorpNeedCompany");
			}
			if (o.kind === "fi") {
				let e = i.id === "orion" ? a.face : A(a);
				if (t.price !== e) return z("games.rss.errBadPrice");
			} else if (t.price < k(a) || t.price > A(a)) return z("games.rss.errBadPrice");
			if (i.cash < t.price) return z("games.rss.errNotEnoughCash");
			e.done = [];
			let s = o.kind === "fi" ? ae(r, i, t.price, a.face) : [];
			return e.deal = {
				buyer: i.id,
				company: t.company,
				price: t.price,
				sellerKind: o.kind,
				sellerId: o.id,
				suitors: s,
				auto: !1
			}, (o.kind === "fi" && s.length === 0 || o.kind === "player" && o.id === n.by || o.kind === "corp" && U(r, o.id)?.president === n.by) && Y(r), { state: r };
		}
		case "respondDeal": {
			let e = r.acquire;
			if (r.phase !== "acquire" || !e?.deal) return z("games.rss.errBadPhase");
			let i = e.deal;
			if (i.suitors.length > 0) return z("games.rss.errNotSuitor");
			let a = i.sellerKind === "player" ? i.sellerId : i.sellerKind === "corp" ? U(r, i.sellerId)?.president : null;
			return !a || a !== n.by ? z("games.rss.errNotSeller") : (t.accept ? Y(r) : (e.deal = null, e.done = [], oe(r)), { state: r });
		}
		case "intervene": {
			let e = r.acquire;
			if (r.phase !== "acquire" || !e?.deal) return z("games.rss.errBadPhase");
			let i = e.deal, a = i.suitors[0], o = a ? U(r, a) : void 0;
			if (!o || o.president !== n.by) return z("games.rss.errNotSuitor");
			if (!t.accept) return i.suitors.shift(), i.suitors.length === 0 && i.sellerKind === "fi" && Y(r), { state: r };
			let s = C[i.company], c = o.id === "orion" ? s.face : A(s);
			return o.cash < c ? z("games.rss.errNotEnoughCash") : (e.deal = {
				...i,
				buyer: o.id,
				price: c,
				suitors: []
			}, Y(r), { state: r });
		}
		case "doneAcquire": {
			let e = r.acquire;
			return r.phase !== "acquire" || !e ? z("games.rss.errBadPhase") : e.deal ? z("games.rss.errDealPending") : (e.done.includes(n.by) || e.done.push(n.by), e.done.length === r.players.length && e.recvQueue.length === 0 && (r.acquire = null, le(r)), { state: r });
		}
		case "closeCompany": {
			if (r.phase !== "close" || !r.closeDone) return z("games.rss.errBadPhase");
			let e = ne(r, t.company);
			if (!e || e.kind === "fi") return z("games.rss.errNoSuchCompany");
			if (e.kind === "player") {
				if (e.id !== n.by) return z("games.rss.errNotOwner");
				i.companies = i.companies.filter((e) => e !== t.company);
			} else {
				let i = U(r, e.id);
				if (!i || i.president !== n.by) return z("games.rss.errNotPresident");
				if (i.companies.length <= 1) return z("games.rss.errCorpNeedCompany");
				ce(i, t.company);
			}
			return r.closeDone = [], { state: r };
		}
		case "doneClosing": {
			if (r.phase !== "close" || !r.closeDone) return z("games.rss.errBadPhase");
			let e = G(r), t = i.companies.reduce((t, n) => t + C[n].income - F(C[n].tier, e), 0);
			return t < 0 && i.cash + t < 0 ? z("games.rss.errMustClose") : (r.closeDone.includes(n.by) || r.closeDone.push(n.by), r.closeDone.length === r.players.length && (r.closeDone = null, ie(r), r.phase = "dividend", r.dividendQueue = te(r).map((e) => e.id), pe(r)), { state: r });
		}
		case "setDividend": {
			let e = r.dividendQueue;
			if (r.phase !== "dividend" || !e || e.length === 0) return z("games.rss.errBadPhase");
			let i = U(r, e[0]);
			if (!i) return z("games.rss.errBadPhase");
			if (i.president !== n.by) return z("games.rss.errNotPresident");
			let a = Math.min(P(V(i)), Math.floor(i.cash / H(i)));
			return t.amount < 0 || t.amount > a ? z("games.rss.errBadDividend") : (e.shift(), fe(r, i, t.amount), pe(r), { state: r });
		}
		case "setIssue": {
			let e = r.issueQueue;
			if (r.phase !== "issue" || !e || e.length === 0) return z("games.rss.errBadPhase");
			let i = U(r, e[0]);
			return i ? i.president === n.by ? (e.shift(), t.issue && ge(r, i), _e(r), { state: r }) : z("games.rss.errNotPresident") : z("games.rss.errBadPhase");
		}
		case "ipo": {
			let e = r.ipoQueue;
			if (r.phase !== "ipo" || !e || e.length === 0) return z("games.rss.errBadPhase");
			if (e[0] !== t.company || !i.companies.includes(t.company)) return z("games.rss.errNotOwner");
			let a = t.corp;
			if (!r.charters.includes(a)) return z("games.rss.errNotCharter");
			let o = C[t.company], [s, c] = E[o.tier];
			if (t.priceIdx < s || t.priceIdx > c || K(r).has(t.priceIdx)) return z("games.rss.errBadIpoPrice");
			let l = T[t.priceIdx], u = l < o.face ? 2 : 1, d = u * l - o.face;
			return i.cash < d ? z("games.rss.errNotEnoughCash") : (i.cash -= d, i.companies = i.companies.filter((e) => e !== t.company), r.charters = r.charters.filter((e) => e !== a), r.corps.push({
				id: a,
				cash: u * l + d,
				companies: [t.company],
				shares: { [n.by]: u },
				bankShares: u,
				unissued: D[a].shares - u * 2,
				president: n.by,
				priceIdx: t.priceIdx,
				formed: r.formedSeq++
			}), e.shift(), e.length === 0 && be(r), { state: r });
		}
		case "ipoPass": {
			let e = r.ipoQueue;
			return r.phase !== "ipo" || !e || e.length === 0 ? z("games.rss.errBadPhase") : e[0] !== t.company || !i.companies.includes(t.company) ? z("games.rss.errNotOwner") : (e.shift(), e.length === 0 && be(r), { state: r });
		}
		default: return z("games.rss.errBadPhase");
	}
}
function Ce(e, t) {
	let n = e.bidders.indexOf(t);
	for (let t = 1; t <= e.bidders.length; t++) {
		let r = e.bidders[(n + t) % e.bidders.length];
		if (r !== e.highBidder) return r;
	}
	return e.highBidder;
}
function we(e, t) {
	let n = W(e, t.highBidder);
	if (n && (n.cash -= t.highBid, n.companies.push(t.company)), e.offering = e.offering.filter((e) => e.id !== t.company), e.deck.length > 0 && e.offering.push({
		id: e.deck.shift(),
		vertical: !0
	}), e.invest) {
		let n = e.players.findIndex((e) => e.rid === t.starter);
		e.invest.actor = (n + 1) % e.players.length, e.invest.auction = null;
	}
}
function Te(e) {
	let t = Array.from({ length: T.length }, () => null);
	for (let n of e.corps) n.priceIdx !== null && (t[n.priceIdx] = n.id);
	return {
		public: {
			turn: e.turn,
			phase: e.phase,
			endFlipped: e.endFlipped,
			deckTop: G(e),
			deckCount: e.deck.length,
			players: e.players.map((e) => ({
				rid: e.rid,
				cash: e.cash,
				companies: [...e.companies]
			})),
			fi: {
				cash: e.fi.cash,
				companies: [...e.fi.companies]
			},
			offering: e.offering.map((e) => ({ ...e })),
			corps: e.corps.map((e) => ({
				id: e.id,
				cash: e.cash,
				companies: [...e.companies],
				shares: { ...e.shares },
				bankShares: e.bankShares,
				unissued: e.unissued,
				president: e.president,
				priceIdx: e.priceIdx
			})),
			charters: [...e.charters],
			priceRow: t,
			invest: e.invest ? {
				actor: e.players[e.invest.actor].rid,
				passed: [...e.invest.passed],
				auction: e.invest.auction ? {
					...e.invest.auction,
					bidders: [...e.invest.auction.bidders]
				} : null
			} : null,
			acquire: e.acquire ? {
				done: [...e.acquire.done],
				used: [...e.acquire.used],
				deal: e.acquire.deal ? {
					...e.acquire.deal,
					suitors: [...e.acquire.deal.suitors]
				} : null
			} : null,
			closeDone: e.closeDone ? [...e.closeDone] : null,
			dividendQueue: e.dividendQueue ? [...e.dividendQueue] : null,
			issueQueue: e.issueQueue ? [...e.issueQueue] : null,
			ipoQueue: e.ipoQueue ? [...e.ipoQueue] : null,
			result: e.result ? {
				scores: { ...e.result.scores },
				ranking: [...e.result.ranking]
			} : null
		},
		private: {}
	};
}
function Ee(e) {
	return e.phase !== "done" || !e.result ? { phase: e.phase } : {
		phase: "done",
		winner: [e.result.ranking[0]],
		ranking: e.result.ranking,
		scores: e.result.scores
	};
}
var De = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: g,
	schemas: {
		action: _,
		publicView: b,
		privateView: x
	},
	setup: xe,
	reduce: Se,
	viewFor: Te,
	status: Ee
};
//#endregion
//#region src/games/rss/pieces.tsx
function X({ className: e = "" }) {
	return /* @__PURE__ */ p("svg", {
		className: e,
		viewBox: "0 0 62 18",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		"aria-hidden": !0,
		children: /* @__PURE__ */ p("path", { d: "M1 3h60M1 15h60M8 3v12M20 3v12M32 3v12M44 3v12M56 3v12" })
	});
}
function Oe({ id: e, deckTop: t, size: n = "small", selected: r = !1, locked: i = !1, used: o = !1, onClick: s, title: c }) {
	let l = a(), u = C[e];
	if (!u) return null;
	let d = u.income - F(u.tier, t), h = `${u.id} · ${u.name} · ${l("games.rss.face")} ${u.face} · ${l("games.rss.netIncome")} ${d} · ★ ${M[u.tier]} · ${l("games.rss.synergy")} ${u.synergies.join(", ")}${i ? ` · ${l("games.rss.nextRound")}` : ""}${o ? ` · ${l("games.rss.usedThisPhase")}` : ""}`, g = /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ m("span", {
			className: "rss-certificate__band",
			children: [/* @__PURE__ */ p(X, {}), /* @__PURE__ */ p("span", { children: "★".repeat(M[u.tier]) })]
		}),
		/* @__PURE__ */ p("span", {
			className: "rss-certificate__name",
			children: u.id
		}),
		n === "market" && /* @__PURE__ */ p("span", {
			className: "rss-certificate__full",
			title: u.name,
			children: u.name
		}),
		/* @__PURE__ */ m("span", {
			className: "rss-certificate__values",
			children: [/* @__PURE__ */ m("span", { children: [
				l("games.rss.face"),
				" ",
				/* @__PURE__ */ m("b", {
					className: "font-mono tabular-nums",
					children: ["$", u.face]
				})
			] }), /* @__PURE__ */ m("span", { children: [
				l("games.rss.netIncome"),
				" ",
				/* @__PURE__ */ m("b", {
					className: "font-mono tabular-nums",
					children: [d >= 0 ? "+" : "", d]
				})
			] })]
		}),
		n === "market" && /* @__PURE__ */ m("span", {
			className: "rss-certificate__synergy",
			children: [
				l("games.rss.synergy"),
				" ",
				u.synergies.slice(0, 4).join(" · "),
				u.synergies.length > 4 ? "…" : ""
			]
		}),
		i && /* @__PURE__ */ p("span", {
			className: "rss-certificate__stamp",
			children: l("games.rss.nextRound")
		}),
		o && /* @__PURE__ */ p("span", {
			className: "rss-certificate__stamp",
			children: l("games.rss.usedThisPhase")
		})
	] }), _ = `rss-certificate rss-certificate--${n} rss-certificate--${u.tier}${r ? " is-selected" : ""}${i || o ? " is-locked" : ""}${s ? " is-actionable" : ""}`;
	return s ? /* @__PURE__ */ p("button", {
		type: "button",
		className: _,
		onClick: s,
		"aria-label": h,
		"aria-pressed": r,
		title: c ?? u.name,
		children: g
	}) : /* @__PURE__ */ p("span", {
		className: _,
		"aria-label": h,
		title: c ?? u.name,
		children: g
	});
}
function ke({ top: e, count: t, endFlipped: n }) {
	let r = a(), i = r(`games.rss.dt${e[0].toUpperCase()}${e.slice(1)}`);
	return /* @__PURE__ */ m("div", {
		className: `rss-deck rss-deck--${e}`,
		"aria-label": `${r("games.rss.deckTop")} ${t} · ${i}`,
		children: [/* @__PURE__ */ m("div", {
			className: "rss-deck__back",
			children: [
				/* @__PURE__ */ p(X, {}),
				/* @__PURE__ */ p("strong", { children: "RSS" }),
				/* @__PURE__ */ m("small", { children: [
					r("games.rss.deckTop"),
					" ×",
					t
				] })
			]
		}), /* @__PURE__ */ m("span", {
			className: "rss-deck__cost",
			children: [n ? "⌛ " : "", i]
		})]
	});
}
function Ae({ price: e, stars: t, need: n, payout: r, className: i = "" }) {
	let o = a();
	return /* @__PURE__ */ m("span", {
		className: `rss-price-card ${i}`,
		"aria-label": `${o("games.rss.price")} ${e} · ${o("games.rss.stars", {
			have: t,
			need: n
		})} · ${o("games.rss.maxPayout", { n: r })}`,
		children: [
			/* @__PURE__ */ p("small", { children: "SHARE PRICE" }),
			/* @__PURE__ */ m("strong", {
				className: "font-mono tabular-nums",
				children: ["$", e]
			}),
			/* @__PURE__ */ p("span", { children: o("games.rss.maxPayout", { n: r }) })
		]
	});
}
function je({ name: e, count: t, color: n, bank: r = !1 }) {
	return /* @__PURE__ */ m("span", {
		className: `rss-stock-token${r ? " rss-stock-token--bank" : ""}`,
		style: n ? { "--rss-token-color": n } : void 0,
		title: `${e} ×${t}`,
		children: [/* @__PURE__ */ p("b", { children: e }), /* @__PURE__ */ p("span", {
			className: "font-mono tabular-nums",
			children: t
		})]
	});
}
//#endregion
//#region src/games/rss/view-player.tsx
function Me(e, t, n) {
	let r = e.corps.find((e) => e.id === t)?.priceIdx, i = new Set(e.priceRow.map((e, t) => e ? t : -1)), a = (r ?? T.length - 1) + n;
	for (; a >= 0 && a < T.length;) {
		if (!i.has(a)) return T[a];
		a += n;
	}
	return null;
}
function Z({ id: e, top: t, selected: n, dimmed: r, locked: i, size: a, onClick: o, title: s }) {
	return /* @__PURE__ */ p(Oe, {
		id: e,
		deckTop: t,
		size: a,
		selected: n,
		used: r,
		locked: i,
		onClick: o,
		title: s
	});
}
function Q({ min: e, max: t, value: n, onChange: r }) {
	return /* @__PURE__ */ m("div", {
		className: "rss-stepper",
		children: [
			/* @__PURE__ */ p("button", {
				type: "button",
				disabled: n <= e,
				onClick: () => r(Math.max(e, n - 1)),
				"aria-label": "-1",
				children: "−"
			}),
			/* @__PURE__ */ p("output", {
				className: "font-mono tabular-nums",
				children: n
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				disabled: n >= t,
				onClick: () => r(Math.min(t, n + 1)),
				"aria-label": "+1",
				children: "+"
			})
		]
	});
}
function Ne(e) {
	let t = e.public;
	return /* @__PURE__ */ p(Pe, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Pe({ pub: e, members: t, myRid: n, send: o }) {
	let h = a(), _ = i((e) => e.locale), [v, y] = r(null), [b, x] = r(null), [S, w] = r(null), T = (e) => t.find((t) => t.rid === e)?.name ?? e, E = (e) => D[e]?.name ?? e, O = e.players.some((e) => e.rid === n), k = e.players.find((e) => e.rid === n), A = e.invest?.auction ?? null, j = e.phase === "invest" && !A && e.invest?.actor === n, M = A?.turn === n, N = e.acquire?.deal ?? null, P = N && (N.sellerKind === "player" && N.sellerId === n || N.sellerKind === "corp" && e.corps.find((e) => e.id === N.sellerId)?.president === n), F = N && N.suitors.length > 0 ? e.corps.find((e) => e.id === N.suitors[0]) : null, I = F?.president === n, L = e.phase === "dividend" && e.dividendQueue?.length ? e.corps.find((t) => t.id === e.dividendQueue[0]) : null, ee = L?.president === n, R = e.phase === "issue" && e.issueQueue?.length ? e.corps.find((t) => t.id === e.issueQueue[0]) : null, z = R?.president === n, B = e.phase === "ipo" && e.ipoQueue?.length ? e.ipoQueue[0] : null, V = B !== null && (k?.companies.includes(B) ?? !1), H = j && e.offering.some((e) => e.id === v && !e.vertical) ? v : null, U = /* @__PURE__ */ new Set([...k?.companies ?? [], ...e.corps.filter((e) => e.president === n && e.companies.length > 1).flatMap((e) => e.companies)]), W = e.phase === "close" && !e.closeDone?.includes(n) && b && U.has(b) ? b : null, G, K;
	e.phase === "invest" ? A ? (G = M ? "accent" : "info", K = M ? h("games.rss.raisePrompt", { n: A.highBid }) : h("games.rss.raiseWait", { name: T(A.turn) })) : (G = j ? "accent" : "info", K = j ? h("games.rss.investPrompt") : h("games.rss.investWait", { name: T(e.invest?.actor ?? "") })) : e.phase === "acquire" ? (G = P || I ? "accent" : "info", K = N ? h("games.rss.dealPending", {
		corp: E(N.buyer),
		company: N.company,
		price: N.price
	}) : h("games.rss.phaseAcquire")) : e.phase === "close" ? (G = e.closeDone?.includes(n) ? "done" : "accent", K = h("games.rss.closePrompt")) : e.phase === "dividend" ? (G = ee ? "accent" : "info", K = L ? h("games.rss.dividendPrompt", {
		corp: E(L.id),
		max: Fe(L)
	}) : "") : e.phase === "issue" ? (G = z ? "accent" : "info", K = R ? h("games.rss.issuePrompt", { corp: E(R.id) }) : "") : e.phase === "ipo" ? (G = V ? "accent" : "info", K = B ? h("games.rss.ipoPrompt", { company: B }) : "") : (G = "done", K = h("games.rss.phaseDone"));
	let q = (t) => e.players.some((e) => e.rid === t) ? e.phase === "invest" && e.invest ? A ? A.turn === t ? "pending" : A.bidders.includes(t) ? null : "done" : e.invest.actor === t ? "pending" : e.invest.passed.includes(t) ? "done" : null : e.phase === "acquire" && e.acquire ? N && (I && t === n || F && F.president === t || N.suitors.length === 0 && (N.sellerKind === "player" && N.sellerId === t || N.sellerKind === "corp" && e.corps.find((e) => e.id === N.sellerId)?.president === t)) ? "pending" : e.acquire.done.includes(t) ? "done" : null : e.phase === "close" && e.closeDone ? e.closeDone.includes(t) ? "done" : "pending" : e.phase === "dividend" && L ? L.president === t ? "pending" : null : e.phase === "issue" && R ? R.president === t ? "pending" : null : e.phase === "ipo" && B && e.players.find((e) => e.companies.includes(B))?.rid === t ? "pending" : null : null, te = /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("div", {
		className: "pr-11",
		children: /* @__PURE__ */ p(l, {
			tone: G,
			text: K,
			chip: h("games.rss.turn", { n: e.turn }),
			accent: g.accent
		})
	}), /* @__PURE__ */ p("div", {
		className: "rss-player-ledger",
		"aria-label": h("games.rss.players"),
		children: t.map((t) => {
			let r = t.rid, i = e.players.find((e) => e.rid === r);
			if (!i) return null;
			let a = e.corps.reduce((e, t) => e + (t.shares[r] ?? 0), 0);
			return /* @__PURE__ */ m("div", {
				className: "rss-player-ledger__item",
				children: [/* @__PURE__ */ p(u, {
					m: t,
					myRid: n,
					action: q(r),
					anchorName: null,
					box: "size-9",
					img: "size-7"
				}), /* @__PURE__ */ m("span", {
					className: "rss-player-ledger__copy",
					children: [/* @__PURE__ */ p("strong", {
						title: d(t, _),
						children: d(t, _)
					}), /* @__PURE__ */ m("small", {
						className: "font-mono tabular-nums",
						children: [
							"$",
							i.cash,
							" · ",
							i.companies.length,
							h("games.rss.companyShort"),
							" · ",
							a,
							h("games.rss.shareShort")
						]
					})]
				})]
			}, r);
		})
	})] }), ne = O && e.phase === "acquire" && e.acquire ? /* @__PURE__ */ p("div", {
		className: "rss-overlay",
		children: /* @__PURE__ */ p(Be, {
			pub: e,
			myRid: n,
			corpName: E,
			nameOf: T,
			send: o
		})
	}) : O && e.phase === "ipo" && V && B ? /* @__PURE__ */ p("div", {
		className: "rss-overlay",
		children: /* @__PURE__ */ p(We, {
			pub: e,
			company: B,
			meCash: k?.cash ?? 0,
			corpName: E,
			send: o
		})
	}) : S && C[S] ? /* @__PURE__ */ p("div", {
		className: "rss-overlay rss-overlay--inspect",
		children: /* @__PURE__ */ p(Ie, {
			id: S,
			top: e.deckTop,
			onClose: () => w(null)
		})
	}) : null, J = /* @__PURE__ */ m("div", {
		className: "rss-action-ticket",
		children: [/* @__PURE__ */ p("span", {
			className: "rss-action-ticket__title",
			children: h("games.rss.waiting")
		}), /* @__PURE__ */ p("span", {
			className: "text-xs font-bold",
			children: K
		})]
	});
	return O && e.phase === "invest" && !A && j ? J = /* @__PURE__ */ p(ze, {
		selected: H,
		cash: k?.cash ?? 0,
		send: o,
		onClear: () => {
			y(null), w(null);
		}
	}, H ?? "empty") : O && e.phase === "invest" && A && M ? J = /* @__PURE__ */ p(Re, {
		pub: e,
		auction: A,
		myRid: n,
		send: o
	}) : O && e.phase === "close" ? J = /* @__PURE__ */ p(He, {
		pub: e,
		myRid: n,
		selected: W,
		onClear: () => {
			x(null), w(null);
		},
		send: o
	}, W ?? "empty") : O && e.phase === "dividend" && ee && L ? J = /* @__PURE__ */ p(Ue, {
		corp: L,
		send: o
	}, L.id) : O && e.phase === "issue" && z && R && (J = /* @__PURE__ */ m("div", {
		className: "rss-action-ticket",
		children: [/* @__PURE__ */ p("span", {
			className: "rss-action-ticket__title",
			children: K
		}), /* @__PURE__ */ m("div", {
			className: "rss-action-ticket__body",
			children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-base bg-info text-white disabled:opacity-40",
				disabled: R.unissued <= 0,
				onClick: () => o({
					type: "setIssue",
					issue: !0
				}),
				children: h("games.rss.issueYes")
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-quiet",
				onClick: () => o({
					type: "setIssue",
					issue: !1
				}),
				children: h("games.rss.issueNo")
			})]
		})]
	})), /* @__PURE__ */ p("div", {
		className: "rss-view h-full min-h-0",
		style: { "--rss-accent": g.accent },
		children: /* @__PURE__ */ p(c, {
			adaptive: !0,
			banner: te,
			actions: J,
			actionsHeight: "h-28 wide:short:h-16",
			overlay: ne,
			scroll: !1,
			children: /* @__PURE__ */ m("div", {
				className: "rss-board",
				children: [/* @__PURE__ */ p(s, {
					kind: "sheen",
					base: "color-mix(in srgb, var(--rss-accent) 7%, var(--color-paper))",
					className: "pointer-events-none absolute inset-0 rounded-[inherit]"
				}), /* @__PURE__ */ m("div", {
					className: "rss-board__scroll",
					children: [/* @__PURE__ */ m("div", {
						className: "rss-left-column",
						children: [/* @__PURE__ */ m("section", {
							className: "rss-zone rss-zone--market",
							"aria-label": h("games.rss.offering"),
							children: [/* @__PURE__ */ m("div", {
								className: "rss-zone__heading",
								children: [/* @__PURE__ */ m("span", { children: ["01 · ", h("games.rss.offering")] }), /* @__PURE__ */ m("small", { children: [
									h("games.rss.deckTop"),
									" ×",
									e.deckCount
								] })]
							}), /* @__PURE__ */ m("div", {
								className: "rss-market",
								children: [
									/* @__PURE__ */ p(ke, {
										top: e.deckTop,
										count: e.deckCount,
										endFlipped: e.endFlipped
									}),
									e.offering.map((t) => /* @__PURE__ */ p(Z, {
										id: t.id,
										top: e.deckTop,
										size: "market",
										locked: t.vertical,
										selected: H === t.id || A?.company === t.id,
										onClick: () => {
											j && !t.vertical && y(H === t.id ? null : t.id), w(S === t.id ? null : t.id);
										}
									}, t.id)),
									e.offering.length === 0 && /* @__PURE__ */ p("span", {
										className: "rss-market__empty",
										children: h("games.rss.noOffering")
									})
								]
							})]
						}), /* @__PURE__ */ m("section", {
							className: "rss-zone rss-zone--assets",
							"aria-label": h("games.rss.myCompanies"),
							children: [/* @__PURE__ */ p("div", {
								className: "rss-zone__heading",
								children: /* @__PURE__ */ m("span", { children: ["03 · ", h("games.rss.holdings")] })
							}), /* @__PURE__ */ m("div", {
								className: "rss-assets",
								children: [/* @__PURE__ */ m("div", {
									className: "rss-assets__tray",
									children: [/* @__PURE__ */ m("div", {
										className: "rss-zone__heading",
										children: [/* @__PURE__ */ p("span", { children: h("games.rss.myCompanies") }), /* @__PURE__ */ m("small", { children: ["$", k?.cash ?? 0] })]
									}), /* @__PURE__ */ m("div", {
										className: "rss-assets__cards",
										children: [k?.companies.map((t) => /* @__PURE__ */ p(Z, {
											id: t,
											top: e.deckTop,
											selected: W === t,
											onClick: () => {
												e.phase === "close" && U.has(t) && !e.closeDone?.includes(n) && x(W === t ? null : t), w(S === t ? null : t);
											}
										}, t)), !k?.companies.length && /* @__PURE__ */ p("span", {
											className: "rss-assets__empty",
											children: h("games.rss.noPrivateCompanies")
										})]
									})]
								}), /* @__PURE__ */ m("div", {
									className: "rss-assets__tray",
									children: [/* @__PURE__ */ m("div", {
										className: "rss-zone__heading",
										children: [/* @__PURE__ */ p("span", { children: h("games.rss.fi") }), /* @__PURE__ */ m("small", { children: ["$", e.fi.cash] })]
									}), /* @__PURE__ */ m("div", {
										className: "rss-assets__cards",
										children: [e.fi.companies.map((t) => /* @__PURE__ */ p(Z, {
											id: t,
											top: e.deckTop,
											onClick: () => w(S === t ? null : t)
										}, t)), e.fi.companies.length === 0 && /* @__PURE__ */ p("span", {
											className: "rss-assets__empty",
											children: h("games.rss.noPrivateCompanies")
										})]
									})]
								})]
							})]
						})]
					}), /* @__PURE__ */ m("section", {
						className: "rss-zone rss-zone--corps",
						"aria-label": h("games.rss.corps"),
						children: [/* @__PURE__ */ m("div", {
							className: "rss-zone__heading",
							children: [/* @__PURE__ */ m("span", { children: ["02 · ", h("games.rss.corps")] }), /* @__PURE__ */ p("small", { children: e.corps.length })]
						}), /* @__PURE__ */ m("div", {
							className: "rss-corp-list",
							children: [e.corps.map((r) => /* @__PURE__ */ p(Le, {
								pub: e,
								corp: r,
								myRid: n,
								members: t,
								nameOf: T,
								corpName: E,
								myInvestTurn: j,
								meCash: k?.cash ?? 0,
								selectedClose: W,
								onClosePick: (e) => x(W === e ? null : e),
								onInspect: (e) => w(S === e ? null : e),
								send: o,
								t: h
							}, r.id)), e.corps.length === 0 && /* @__PURE__ */ p("span", {
								className: "rss-assets__empty",
								children: h("games.rss.noCorps")
							})]
						})]
					})]
				})]
			})
		})
	});
}
function Fe(e) {
	let t = T[e.priceIdx ?? T.length - 1], n = Object.values(e.shares).reduce((e, t) => e + t, 0) + e.bankShares;
	return Math.min(P(t), Math.floor(e.cash / Math.max(1, n)));
}
function Ie({ id: e, top: t, onClose: n }) {
	let r = a(), i = C[e], o = F(i.tier, t);
	return /* @__PURE__ */ m("div", {
		className: "rss-inspect",
		children: [
			/* @__PURE__ */ m("div", {
				className: "rss-inspect__head",
				children: [
					/* @__PURE__ */ p(X, {}),
					/* @__PURE__ */ p("strong", { children: r("games.rss.cardDetails", { company: e }) }),
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: n,
						"aria-label": r("games.rss.closeDetails"),
						children: "×"
					})
				]
			}),
			/* @__PURE__ */ p("p", {
				className: "rss-inspect__name",
				children: i.name
			}),
			/* @__PURE__ */ m("div", {
				className: "rss-inspect__facts font-mono tabular-nums",
				children: [
					/* @__PURE__ */ m("span", { children: [
						r("games.rss.face"),
						" $",
						i.face
					] }),
					/* @__PURE__ */ m("span", { children: [
						r("games.rss.income"),
						" +",
						i.income
					] }),
					/* @__PURE__ */ m("span", { children: [
						r("games.rss.cost"),
						" −",
						o
					] }),
					/* @__PURE__ */ m("strong", { children: [
						r("games.rss.netIncome"),
						" ",
						i.income - o >= 0 ? "+" : "",
						i.income - o
					] })
				]
			}),
			/* @__PURE__ */ m("p", {
				className: "rss-inspect__synergy",
				children: [
					r("games.rss.synergy"),
					" · ",
					i.synergies.join(" · ")
				]
			})
		]
	});
}
function Le({ pub: e, corp: t, myRid: n, members: r, nameOf: i, corpName: a, myInvestTurn: s, meCash: c, selectedClose: l, onClosePick: u, onInspect: d, send: f, t: h }) {
	let g = T[t.priceIdx ?? T.length - 1], _ = Object.values(t.shares).reduce((e, t) => e + t, 0) + t.bankShares, v = t.companies.reduce((e, t) => e + M[C[t].tier], 0) + Math.floor(t.cash / 10) + (t.id === "star" ? 2 : 0), y = Me(e, t.id, 1), b = Me(e, t.id, -1), x = Object.entries(t.shares).filter(([, e]) => e > 0), S = e.phase === "close" && !e.closeDone?.includes(n) && t.president === n && t.companies.length > 1, w = `games.rss.ability${t.id[0].toUpperCase()}${t.id.slice(1)}`;
	return /* @__PURE__ */ m("div", {
		className: `rss-corp${t.president === null ? " is-receivership" : ""}`,
		children: [
			/* @__PURE__ */ m("div", {
				className: "rss-corp__top",
				children: [/* @__PURE__ */ m("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ m("div", {
							className: "rss-corp__title",
							children: [/* @__PURE__ */ p(X, {}), /* @__PURE__ */ p("span", { children: a(t.id) })]
						}),
						/* @__PURE__ */ m("div", {
							className: "rss-corp__meta",
							children: [
								t.president ? `${h("games.rss.president")} ${i(t.president)}` : h("games.rss.receivership"),
								" · ",
								h("games.rss.treasury"),
								" ",
								/* @__PURE__ */ m("b", {
									className: "font-mono tabular-nums",
									children: ["$", t.cash]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "rss-corp__stars",
							children: [/* @__PURE__ */ p("span", {
								className: "font-mono tabular-nums",
								children: h("games.rss.stars", {
									have: v,
									need: N(_, g)
								})
							}), /* @__PURE__ */ p("span", { children: h("games.rss.starRequirement") })]
						}),
						/* @__PURE__ */ p("div", {
							className: "rss-corp__ability",
							children: h(w)
						})
					]
				}), /* @__PURE__ */ p(Ae, {
					price: g,
					stars: v,
					need: N(_, g),
					payout: P(g)
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "rss-corp__stocks",
				children: [
					/* @__PURE__ */ p("span", {
						className: "rss-corp__label",
						children: h("games.rss.shareholders")
					}),
					x.map(([e, t]) => /* @__PURE__ */ p(je, {
						name: i(e),
						count: t,
						color: o[(r.find((t) => t.rid === e)?.colorIndex ?? 0) % o.length].hex
					}, e)),
					t.bankShares > 0 && /* @__PURE__ */ p(je, {
						name: h("games.rss.bankShort"),
						count: t.bankShares,
						bank: !0
					})
				]
			}),
			s && /* @__PURE__ */ m("div", {
				className: "rss-corp__trades",
				children: [/* @__PURE__ */ m("button", {
					type: "button",
					disabled: t.bankShares <= 0 || y === null || y > c,
					onClick: () => f({
						type: "buyShare",
						corp: t.id
					}),
					"aria-label": `${h("games.rss.buyShare")} ${a(t.id)} ${y ?? ""}`,
					children: [/* @__PURE__ */ p("span", { children: h("games.rss.buyShare") }), /* @__PURE__ */ m("b", {
						className: "font-mono tabular-nums",
						children: ["$", y ?? "—"]
					})]
				}), /* @__PURE__ */ m("button", {
					type: "button",
					disabled: (t.shares[n] ?? 0) <= 0 || b === null,
					onClick: () => f({
						type: "sellShare",
						corp: t.id
					}),
					"aria-label": `${h("games.rss.sellShare")} ${a(t.id)} ${b ?? ""}`,
					children: [/* @__PURE__ */ p("span", { children: h("games.rss.sellShare") }), /* @__PURE__ */ m("b", {
						className: "font-mono tabular-nums",
						children: ["$", b ?? "—"]
					})]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: "rss-corp__subs",
				children: [
					/* @__PURE__ */ p("span", {
						className: "rss-corp__label",
						children: h("games.rss.subsidiaries")
					}),
					t.companies.map((t) => /* @__PURE__ */ p(Z, {
						id: t,
						top: e.deckTop,
						dimmed: e.acquire?.used.includes(t),
						selected: l === t,
						onClick: () => {
							S && u(t), d(t);
						}
					}, t)),
					t.companies.length === 0 && /* @__PURE__ */ p("span", {
						className: "rss-corp__empty",
						children: h("games.rss.noPrivateCompanies")
					})
				]
			})
		]
	});
}
function Re({ pub: e, auction: t, myRid: n, send: i }) {
	let o = a(), s = e.players.find((e) => e.rid === n), [c, l] = r(t.highBid + 1);
	if (!s) return null;
	let u = t.highBid + 1, d = Math.min(Math.max(c, u), s.cash);
	return /* @__PURE__ */ m("div", {
		className: "rss-action-ticket",
		children: [/* @__PURE__ */ p("span", {
			className: "rss-action-ticket__title",
			children: o("games.rss.auctionLive", {
				company: t.company,
				n: t.highBid
			})
		}), /* @__PURE__ */ m("div", {
			className: "rss-action-ticket__body",
			children: [
				s.cash >= u ? /* @__PURE__ */ p(Q, {
					min: u,
					max: s.cash,
					value: d,
					onChange: l
				}) : /* @__PURE__ */ p("span", {
					className: "text-xs font-bold",
					children: o("games.rss.errNotEnoughCash")
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base bg-info text-white disabled:opacity-40",
					disabled: s.cash < u,
					onClick: () => i({
						type: "raiseBid",
						amount: d
					}),
					children: o("games.rss.raise")
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-quiet",
					onClick: () => i({ type: "leaveAuction" }),
					children: o("games.rss.leaveAuction")
				})
			]
		})]
	});
}
function ze({ selected: e, cash: t, send: n, onClear: i }) {
	let o = a(), s = e ? C[e] : null, [c, l] = r(s?.face ?? 0), u = s !== null && t >= s.face;
	return /* @__PURE__ */ m("div", {
		className: "rss-action-ticket",
		children: [/* @__PURE__ */ p("span", {
			className: "rss-action-ticket__title",
			children: s ? o("games.rss.bidTicket", {
				company: s.id,
				face: s.face,
				cash: t
			}) : o("games.rss.selectOfferHint")
		}), /* @__PURE__ */ p("div", {
			className: "rss-action-ticket__body",
			children: s ? /* @__PURE__ */ m(f, { children: [
				u ? /* @__PURE__ */ p(Q, {
					min: s.face,
					max: t,
					value: c,
					onChange: l
				}) : /* @__PURE__ */ p("span", {
					className: "text-xs font-bold",
					children: o("games.rss.errNotEnoughCash")
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base bg-info text-white disabled:opacity-40",
					disabled: !u,
					onClick: () => {
						n({
							type: "startAuction",
							company: s.id,
							bid: c
						}), i();
					},
					children: o("games.rss.startAuction")
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-quiet rss-pass",
					onClick: i,
					children: o("games.rss.cancel")
				})
			] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", {
				className: "flex-1 text-xs font-bold",
				children: o("games.rss.tradeHint")
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-quiet rss-pass",
				onClick: () => n({ type: "pass" }),
				children: o("games.rss.pass")
			})] })
		})]
	});
}
function Be({ pub: e, myRid: t, corpName: n, nameOf: r, send: i }) {
	let o = a(), s = e.acquire, c = s?.deal ?? null;
	if (!s) return null;
	if (c) {
		let a = c.suitors.length > 0 ? e.corps.find((e) => e.id === c.suitors[0]) : null, s = a?.president === t, l = c.sellerKind === "player" && c.sellerId === t || c.sellerKind === "corp" && e.corps.find((e) => e.id === c.sellerId)?.president === t, u = c.sellerKind === "fi" ? o("games.rss.dealFromFi") : c.sellerKind === "player" ? o("games.rss.dealFromPlayer", { name: r(c.sellerId) }) : o("games.rss.dealFromCorp", { corp: n(c.sellerId) });
		return /* @__PURE__ */ m("div", {
			className: "rss-deal",
			children: [
				/* @__PURE__ */ p("p", {
					className: "rss-overlay__heading",
					children: o("games.rss.dealPending", {
						corp: n(c.buyer),
						company: c.company,
						price: c.price
					})
				}),
				/* @__PURE__ */ p("p", {
					className: "rss-deal__seller",
					children: u
				}),
				/* @__PURE__ */ m("div", {
					className: "rss-deal__preview",
					children: [
						/* @__PURE__ */ p(Z, {
							id: c.company,
							top: e.deckTop
						}),
						/* @__PURE__ */ p("span", { children: "→" }),
						/* @__PURE__ */ m("span", {
							className: "rss-charter-choice",
							children: [/* @__PURE__ */ p(X, {}), /* @__PURE__ */ p("strong", { children: n(c.buyer) })]
						})
					]
				}),
				a ? s ? /* @__PURE__ */ m("div", {
					className: "rss-ipo__footer",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base bg-info text-white",
						onClick: () => i({
							type: "intervene",
							accept: !0
						}),
						children: o("games.rss.intervene")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet",
						onClick: () => i({
							type: "intervene",
							accept: !1
						}),
						children: o("games.rss.passIntervene")
					})]
				}) : /* @__PURE__ */ p("p", {
					className: "rss-deal__seller",
					children: o("games.rss.dealWaitSuitor", { corp: n(a.id) })
				}) : l ? /* @__PURE__ */ m("div", {
					className: "rss-ipo__footer",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-base bg-info text-white",
						onClick: () => i({
							type: "respondDeal",
							accept: !0
						}),
						children: o("games.rss.accept")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						className: "btn-quiet",
						onClick: () => i({
							type: "respondDeal",
							accept: !1
						}),
						children: o("games.rss.reject")
					})]
				}) : /* @__PURE__ */ p("p", {
					className: "rss-deal__seller",
					children: o("games.rss.dealWaitSeller")
				})
			]
		});
	}
	return /* @__PURE__ */ p(Ve, {
		pub: e,
		myRid: t,
		corpName: n,
		nameOf: r,
		send: i
	});
}
function Ve({ pub: e, myRid: t, corpName: n, nameOf: i, send: o }) {
	let s = a(), c = e.acquire, [l, u] = r(null), [d, h] = r(null), [g, _] = r(0), v = e.corps.filter((e) => e.president === t), y = c?.done.includes(t) ?? !1, b = new Set(c?.used ?? []), x = [];
	for (let t of e.fi.companies) b.has(t) || x.push({
		id: t,
		owner: s("games.rss.fi")
	});
	for (let t of e.players) for (let e of t.companies) b.has(e) || x.push({
		id: e,
		owner: i(t.rid)
	});
	for (let t of e.corps) if (t.id !== l && t.president !== null) for (let e of t.companies) !b.has(e) && t.companies.length > 1 && x.push({
		id: e,
		owner: n(t.id)
	});
	let S = d ? C[d] : null, w = e.fi.companies.includes(d ?? ""), T = e.corps.find((e) => e.id === l), E = S ? w ? l === "orion" ? S.face : A(S) : k(S) : 0, D = S ? w && l === "orion" ? S.face : A(S) : 0, O = S ? Math.min(Math.max(g || E, E), D) : 0, j = T ? O <= T.cash : !1;
	return /* @__PURE__ */ m("div", {
		className: "rss-deal",
		children: [
			/* @__PURE__ */ p("p", {
				className: "rss-overlay__heading",
				children: s("games.rss.phaseAcquire")
			}),
			v.length > 0 && /* @__PURE__ */ m("div", { children: [
				/* @__PURE__ */ p("p", {
					className: "section-label",
					children: s("games.rss.dealPickBuyer")
				}),
				/* @__PURE__ */ p("div", {
					className: "rss-choice-row",
					children: v.map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						className: `rss-charter-choice${l === e.id ? " is-selected" : ""}`,
						"aria-pressed": l === e.id,
						onClick: () => {
							u(l === e.id ? null : e.id), h(null);
						},
						children: [
							/* @__PURE__ */ p(X, {}),
							/* @__PURE__ */ p("strong", { children: n(e.id) }),
							/* @__PURE__ */ m("small", { children: [
								s("games.rss.treasury"),
								" $",
								e.cash
							] })
						]
					}, e.id))
				}),
				l && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("p", {
					className: "section-label",
					children: s("games.rss.dealPickCompany")
				}), /* @__PURE__ */ p("div", {
					className: "rss-choice-row",
					children: x.map((t) => /* @__PURE__ */ m("span", {
						className: "rss-deal__target",
						children: [/* @__PURE__ */ p(Z, {
							id: t.id,
							top: e.deckTop,
							selected: d === t.id,
							onClick: () => {
								h(d === t.id ? null : t.id), _(0);
							}
						}), /* @__PURE__ */ p("small", { children: t.owner || s("games.rss.privateOwner") })]
					}, `${t.owner}:${t.id}`))
				})] }),
				l && S && /* @__PURE__ */ m(f, { children: [
					/* @__PURE__ */ m("p", {
						className: "rss-deal__seller",
						children: [
							S.name,
							" · ",
							s("games.rss.synergy"),
							" ",
							S.synergies.join(" · ")
						]
					}),
					/* @__PURE__ */ p("p", {
						className: "section-label",
						children: s("games.rss.dealPickPrice", {
							min: E,
							max: D
						})
					}),
					/* @__PURE__ */ m("div", {
						className: "rss-deal__price",
						children: [E === D ? /* @__PURE__ */ m("span", {
							className: "font-mono text-lg font-extrabold tabular-nums",
							children: ["$", E]
						}) : /* @__PURE__ */ p(Q, {
							min: E,
							max: D,
							value: O,
							onChange: _
						}), /* @__PURE__ */ p("button", {
							type: "button",
							className: "btn-base bg-info px-3 text-sm font-extrabold text-white disabled:opacity-40",
							disabled: !j,
							onClick: () => {
								o({
									type: "proposeDeal",
									buyer: l,
									company: d,
									price: O
								}), h(null);
							},
							children: s("games.rss.dealPropose")
						})]
					})
				] })
			] }),
			/* @__PURE__ */ m("button", {
				type: "button",
				disabled: y,
				className: "btn-quiet mt-2 w-full text-sm font-extrabold disabled:opacity-50",
				onClick: () => o({ type: "doneAcquire" }),
				children: [s("games.rss.doneAcquire"), y ? " ✓" : ""]
			})
		]
	});
}
function He({ pub: e, myRid: t, selected: i, onClear: o, send: s }) {
	let c = a(), [l, u] = r(!1), d = e.closeDone?.includes(t) ?? !1;
	return n(() => {
		if (!l) return;
		let e = window.setTimeout(() => u(!1), 3e3);
		return () => window.clearTimeout(e);
	}, [l]), /* @__PURE__ */ m("div", {
		className: "rss-action-ticket",
		children: [/* @__PURE__ */ p("span", {
			className: "rss-action-ticket__title",
			children: d ? c("games.rss.waiting") : i ? c("games.rss.hintClose", { company: i }) : c("games.rss.closePrompt")
		}), /* @__PURE__ */ p("div", {
			className: "rss-action-ticket__body",
			children: i && !d ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: `btn-base bg-danger text-white${l ? " rss-close-armed" : ""}`,
				onBlur: () => u(!1),
				onClick: () => {
					if (!l) {
						u(!0);
						return;
					}
					s({
						type: "closeCompany",
						company: i
					}), o();
				},
				children: c(l ? "games.rss.confirmClose" : "games.rss.hintClose", { company: i })
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-quiet rss-pass",
				onClick: o,
				children: c("games.rss.cancel")
			})] }) : /* @__PURE__ */ m("button", {
				type: "button",
				disabled: d,
				className: "btn-quiet w-full disabled:opacity-50",
				onClick: () => s({ type: "doneClosing" }),
				children: [c("games.rss.doneClosing"), d ? " ✓" : ""]
			})
		})]
	});
}
function Ue({ corp: e, send: t }) {
	let n = a(), i = Fe(e), [o, s] = r(i);
	return /* @__PURE__ */ m("div", {
		className: "rss-action-ticket",
		children: [/* @__PURE__ */ p("span", {
			className: "rss-action-ticket__title",
			children: n("games.rss.dividendPrompt", {
				corp: D[e.id]?.name ?? e.id,
				max: i
			})
		}), /* @__PURE__ */ m("div", {
			className: "rss-action-ticket__body",
			children: [/* @__PURE__ */ p(Q, {
				min: 0,
				max: i,
				value: Math.min(o, i),
				onChange: s
			}), /* @__PURE__ */ p("button", {
				type: "button",
				className: "btn-base bg-info text-white",
				onClick: () => t({
					type: "setDividend",
					amount: Math.min(o, i)
				}),
				children: n("games.rss.dividendPay")
			})]
		})]
	});
}
function We({ pub: e, company: t, meCash: n, corpName: i, send: o }) {
	let s = a(), c = C[t], [l, u] = r(null), [d, f] = r(null), [h, g] = E[c.tier], _ = Array.from({ length: g - h + 1 }, (e, t) => t + h), v = d !== null && !e.priceRow[d] ? T[d] : null, y = v !== null && v < c.face ? 2 : 1, b = v === null ? 0 : y * v - c.face, x = l !== null && d !== null && v !== null && b <= n;
	return /* @__PURE__ */ m("div", {
		className: "rss-ipo",
		children: [
			/* @__PURE__ */ p("p", {
				className: "rss-overlay__heading",
				children: s("games.rss.ipoPrompt", { company: t })
			}),
			/* @__PURE__ */ p("p", {
				className: "section-label",
				children: s("games.rss.ipoPickCharter")
			}),
			/* @__PURE__ */ p("div", {
				className: "rss-choice-row",
				children: e.charters.map((e) => /* @__PURE__ */ m("button", {
					type: "button",
					className: `rss-charter-choice${l === e ? " is-selected" : ""}`,
					"aria-pressed": l === e,
					onClick: () => u(l === e ? null : e),
					children: [/* @__PURE__ */ p(X, {}), /* @__PURE__ */ p("strong", { children: i(e) })]
				}, e))
			}),
			l && /* @__PURE__ */ p("p", {
				className: "rss-ipo__ability",
				children: s(`games.rss.ability${l[0].toUpperCase()}${l.slice(1)}`)
			}),
			/* @__PURE__ */ p("p", {
				className: "section-label",
				children: s("games.rss.ipoPickPrice")
			}),
			/* @__PURE__ */ p("div", {
				className: "rss-choice-row",
				children: _.map((t) => /* @__PURE__ */ m("button", {
					type: "button",
					className: `rss-ipo-price${d === t ? " is-selected" : ""}${e.priceRow[t] ? " is-occupied" : ""}`,
					disabled: !!e.priceRow[t],
					"aria-pressed": d === t,
					"aria-label": `${s("games.rss.price")} ${T[t]}${e.priceRow[t] ? ` · ${s("games.rss.priceOccupied", { corp: i(e.priceRow[t]) })}` : ""}`,
					onClick: () => f(d === t ? null : t),
					children: [/* @__PURE__ */ m("strong", {
						className: "font-mono tabular-nums",
						children: ["$", T[t]]
					}), e.priceRow[t] && /* @__PURE__ */ p("small", { children: i(e.priceRow[t]) })]
				}, t))
			}),
			v !== null && /* @__PURE__ */ p("p", {
				className: "rss-ipo__ability",
				children: s("games.rss.ipoPreview", {
					shares: y,
					payment: b
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "rss-ipo__footer",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base bg-info text-white disabled:opacity-40",
					disabled: !x,
					onClick: () => l !== null && d !== null && o({
						type: "ipo",
						company: t,
						corp: l,
						priceIdx: d
					}),
					children: s("games.rss.ipoConfirm")
				}), /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-quiet",
					onClick: () => o({
						type: "ipoPass",
						company: t
					}),
					children: s("games.rss.ipoPass")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/rss/bot.ts
function Ge() {
	let e = /* @__PURE__ */ new Uint32Array(1);
	return crypto.getRandomValues(e), e[0] / 4294967296;
}
function $(e, t) {
	let n = C[e];
	return n.income - F(n.tier, t);
}
function Ke(e, t) {
	return C[e].face + Math.max(0, $(e, t)) * 2;
}
function qe(e) {
	return Object.values(e.shares).reduce((e, t) => e + t, 0) + e.bankShares;
}
function Je(e) {
	return T[e.priceIdx ?? T.length - 1];
}
function Ye(e, t, n) {
	let r = e.corps.find((e) => e.id === t)?.priceIdx, i = new Set(e.priceRow.map((e, t) => e ? t : -1)), a = (r ?? T.length - 1) + n;
	for (; a >= 0 && a < T.length;) {
		if (!i.has(a)) return T[a];
		a += n;
	}
	return null;
}
var Xe = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = t.difficulty === "weak", a = (e) => i ? e * (.7 + Ge() * .6) : e;
	if (n.phase === "invest" && n.invest) {
		let e = n.invest.auction;
		if (e) {
			if (e.turn !== t.rid) return null;
			let i = a(Ke(e.company, n.deckTop));
			return e.highBid + 1 <= r.cash && e.highBid + 1 <= i ? { action: {
				type: "raiseBid",
				amount: e.highBid + 1
			} } : { action: { type: "leaveAuction" } };
		}
		if (n.invest.actor !== t.rid) return null;
		let o = n.corps.filter((e) => e.bankShares > 0 && e.president !== null).map((e) => ({
			id: e.id,
			price: Ye(n, e.id, 1)
		})).filter((e) => e.price !== null && e.price <= r.cash).sort((e, t) => e.price - t.price);
		if (o.length > 0 && Ge() < (i ? .4 : .7)) return { action: {
			type: "buyShare",
			corp: o[0].id
		} };
		let s = n.offering.filter((e) => !e.vertical && C[e.id].face <= r.cash);
		if (s.length > 0) {
			let e = s.sort((e, t) => Ke(t.id, n.deckTop) - Ke(e.id, n.deckTop))[0];
			return { action: {
				type: "startAuction",
				company: e.id,
				bid: C[e.id].face
			} };
		}
		return { action: { type: "pass" } };
	}
	if (n.phase === "acquire" && n.acquire) {
		let e = n.acquire, r = e.deal;
		if (r) {
			let e = r.suitors[0];
			if ((e ? n.corps.find((t) => t.id === e) : null)?.president === t.rid) return { action: {
				type: "intervene",
				accept: !1
			} };
			if (r.suitors.length === 0 && (r.sellerKind === "player" && r.sellerId === t.rid || r.sellerKind === "corp" && n.corps.find((e) => e.id === r.sellerId)?.president === t.rid)) {
				let e = C[r.company], t = k(e) + (A(e) - k(e)) * (i ? .5 : .7);
				return { action: {
					type: "respondDeal",
					accept: r.price >= t
				} };
			}
			return null;
		}
		if (e.done.includes(t.rid)) return null;
		let a = new Set(e.used);
		for (let e of n.corps.filter((e) => e.president === t.rid)) for (let t of n.fi.companies) {
			if (a.has(t)) continue;
			let r = e.id === "orion" ? C[t].face : A(C[t]);
			if (e.cash >= r && Ke(t, n.deckTop) >= r) return { action: {
				type: "proposeDeal",
				buyer: e.id,
				company: t,
				price: r
			} };
		}
		return { action: { type: "doneAcquire" } };
	}
	if (n.phase === "close") {
		if (n.closeDone?.includes(t.rid)) return null;
		let e = n.corps.filter((e) => e.president === t.rid), i = r.companies.reduce((e, t) => e + $(t, n.deckTop), 0);
		if (i < 0 && r.cash + i < 0 && r.companies.length > 0) return { action: {
			type: "closeCompany",
			company: [...r.companies].sort((e, t) => $(e, n.deckTop) - $(t, n.deckTop))[0]
		} };
		for (let t of e) {
			if (t.companies.length <= 1) continue;
			let e = t.companies.reduce((e, t) => e + F(C[t].tier, n.deckTop), 0), r = I(t.companies) + t.companies.reduce((e, t) => e + C[t].income, 0);
			if (r - e < 0 && t.cash + (r - e) < 0) return { action: {
				type: "closeCompany",
				company: [...t.companies].sort((e, t) => $(e, n.deckTop) - $(t, n.deckTop))[0]
			} };
		}
		return { action: { type: "doneClosing" } };
	}
	if (n.phase === "dividend" && n.dividendQueue?.length) {
		let e = n.corps.find((e) => e.id === n.dividendQueue[0]);
		return !e || e.president !== t.rid ? null : { action: {
			type: "setDividend",
			amount: Math.min(P(Je(e)), Math.floor(e.cash / Math.max(1, qe(e))))
		} };
	}
	if (n.phase === "issue" && n.issueQueue?.length) {
		let e = n.corps.find((e) => e.id === n.issueQueue[0]);
		return !e || e.president !== t.rid ? null : { action: {
			type: "setIssue",
			issue: e.unissued > 0 && e.cash < 5
		} };
	}
	if (n.phase === "ipo" && n.ipoQueue?.length) {
		let e = n.ipoQueue[0];
		if (!r.companies.includes(e)) return null;
		if (i && Ge() < .3) return { action: {
			type: "ipoPass",
			company: e
		} };
		let t = C[e], [a, o] = E[t.tier], s = null;
		for (let e = o; e >= a; e--) if (!n.priceRow[e]) {
			s = e;
			break;
		}
		let c = n.charters[0];
		if (s === null || !c) return { action: {
			type: "ipoPass",
			company: e
		} };
		let l = T[s];
		return (l < t.face ? 2 : 1) * l - t.face > r.cash ? { action: {
			type: "ipoPass",
			company: e
		} } : { action: {
			type: "ipo",
			company: e,
			corp: c,
			priceIdx: s
		} };
	}
	return null;
}, Ze = (e) => D[e]?.name ?? e, Qe = (e, t, n) => {
	switch (e.type) {
		case "pass": return n("games.rss.hintPass");
		case "startAuction": return n("games.rss.hintAuction", {
			company: e.company,
			n: e.bid
		});
		case "raiseBid": return n("games.rss.hintRaise", { n: e.amount });
		case "leaveAuction": return n("games.rss.hintLeave");
		case "buyShare": return n("games.rss.hintBuy", { corp: Ze(e.corp) });
		case "sellShare": return n("games.rss.hintSell", { corp: Ze(e.corp) });
		case "proposeDeal": return n("games.rss.hintDeal", {
			company: e.company,
			price: e.price
		});
		case "respondDeal": return n(e.accept ? "games.rss.hintAccept" : "games.rss.hintReject");
		case "intervene": return n(e.accept ? "games.rss.hintIntervene" : "games.rss.hintPassIntervene");
		case "doneAcquire":
		case "doneClosing": return n("games.rss.hintDone");
		case "closeCompany": return n("games.rss.hintClose", { company: e.company });
		case "setDividend": return n("games.rss.hintDividend", { n: e.amount });
		case "setIssue": return n(e.issue ? "games.rss.hintIssue" : "games.rss.hintNoIssue");
		case "ipo": return n("games.rss.hintIpo", {
			corp: Ze(e.corp),
			price: T[e.priceIdx]
		});
		case "ipoPass": return n("games.rss.hintIpoPass");
	}
};
//#endregion
//#region src/games/rss/game-over-row.tsx
function $e({ public: e, rid: t }) {
	let n = a(), r = e, i = r.players.find((e) => e.rid === t);
	if (!i) return null;
	let o = i.cash, s = i.companies.reduce((e, t) => e + (C[t]?.face ?? 0), 0), c = r.corps.reduce((e, n) => e + (n.shares[t] ?? 0) * T[n.priceIdx ?? T.length - 1], 0);
	return /* @__PURE__ */ m("div", {
		className: "rss-result mt-1.5",
		children: [
			/* @__PURE__ */ p(X, {}),
			/* @__PURE__ */ p("span", { children: n("games.rss.scoreCash", { n: o }) }),
			/* @__PURE__ */ p("span", { children: n("games.rss.scoreCompanies", { n: s }) }),
			/* @__PURE__ */ p("span", { children: n("games.rss.scoreShares", { n: c }) }),
			/* @__PURE__ */ p("strong", {
				className: "font-mono tabular-nums",
				children: n("games.rss.scoreTotal", { n: o + s + c })
			})
		]
	});
}
//#endregion
//#region src/games/rss/game-over.tsx
function et(e) {
	return /* @__PURE__ */ p("div", {
		className: "rss-over",
		children: /* @__PURE__ */ p(h, {
			...e,
			accent: g.accent,
			renderRowExtra: (t) => /* @__PURE__ */ p($e, {
				...e,
				rid: t
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/rss/entry.tsx
var tt = {
	definition: De,
	View: Ne,
	bot: Xe,
	describe: Qe,
	OverView: et,
	RowView: $e,
	locales: {
		zh: {
			name: "交运之星",
			desc: "竞拍铁路公司、组建集团、炒股分红,18XX 血统的纯金融卡牌游戏",
			rules: "目标:游戏结束时总资产(现金 + 私有公司面值 + 持股×股价)最高者胜。\n准备:每人 30 元(6 人局 25 元);按人数组公司牌堆(红在顶、蓝垫底、终局卡压底),翻开等于人数的公司作为待拍区。\n每回合 9 个阶段:\n· 1 投资:轮流行动——发起拍卖(公开竞价,起拍价不低于面值)、买入或卖出股票,或过;全员连续过则结束。\n· 买入付下一张更高可用股价卡的价格,卖出收下一张更低可用卡的价格。\n· 持股严格超过总裁即夺权;银行持有全部已发行股时,该集团进入托管。\n· 2 收尾:按现金重排玩家顺序;外商(每回合收入加 5)按面值升序买入买得起的最便宜公司。\n· 3 收购:集团可用金库现金收购玩家、外商或其他集团的公司,价格须在卡面区间内。\n· 外商只按最高价出售;股价更高的集团可干预抢买(外商贸易集团恒最优先、付面值)。\n· 4 关闭:可关闭亏损公司;若下阶段总收入为负且现金不够付,必须关到够付为止。\n· 5 收入:玩家与集团结算(公司收入减去持有成本;集团另加协同与能力加成)。\n· 6 分红:按股价降序,总裁定每股分红(上限为股价除以 3 向下取整)。\n· 再按星数(公司星 + 现金除以 10 向下取整)对比股价卡要求调整股价。\n· 星数多 2 跳两格、多 1 升一格、少 1 降一格、少 2 降两格,降到 0 破产。\n· 7 终局检查:有集团持 75 股价卡,或终局卡已翻面,游戏结束;否则无公司可买时翻开终局卡。\n· 8 增发:按股价降序,各集团可增发一股给银行换取现金(股价下移一格)。\n· 9 IPO:按面值降序,私有公司可组建集团——选一张可用执照和该颜色区间内的初始股价。\n· 股价低于面值获得 2 股,否则获得 1 股并补差价,银行配等量股并把股款付入金库。\n集团能力:\n· 普鲁士铁路每公司收入加 1;多普勒最佳公司收入翻倍;协同每 2 个协同标记收入加 1。\n· 老爷车总持有成本减 10;股票大师增发不变价;外商贸易买外商付面值且最优先。\n· 废品回收关闭公司收入翻倍;星星公司星数加 2。",
			turn: "第 {{n}} 轮",
			players: "玩家资产",
			companyShort: "企",
			shareShort: "股",
			phaseInvest: "投资",
			phaseAcquire: "收购",
			phaseClose: "关闭公司",
			phaseDividend: "分红",
			phaseIssue: "增发",
			phaseIpo: "IPO",
			phaseDone: "结束",
			investPrompt: "轮到你：竞拍、买卖股票或过",
			investWait: "等待 {{name}} 行动",
			auctionLive: "拍卖中:{{company}} 最高 {{n}}",
			raisePrompt: "加价(须高于 {{n}})或退出",
			raiseWait: "等待 {{name}} 表态",
			offering: "待拍公司",
			noOffering: "待翻开新公司",
			nextRound: "下轮可拍",
			usedThisPhase: "本阶段已交易",
			selectOfferHint: "点击桌面上的公司证书，选择起拍公司",
			tradeHint: "也可在集团执照上买卖股票",
			bidTicket: "拍卖委托 · {{company}} · 面值 ${{face}} · 现金 ${{cash}}",
			cancel: "取消",
			deckTop: "牌堆",
			fi: "外商",
			corps: "集团公司",
			noCorps: "尚未有集团成立；持有私有公司后可在 IPO 阶段组建。",
			holdings: "档案夹与外商货架",
			noPrivateCompanies: "暂无公司牌",
			myCompanies: "我的公司",
			charters: "可用执照",
			price: "股价",
			cash: "现金",
			treasury: "金库",
			income: "收入",
			netIncome: "净收入",
			cardDetails: "{{company}} · 公司证书",
			closeDetails: "关闭公司详情",
			cost: "成本",
			synergy: "协同",
			president: "总裁",
			receivership: "托管中",
			bankStock: "银行 {{n}} 股",
			bankShort: "银行",
			shareholders: "股权",
			subsidiaries: "旗下公司",
			starRequirement: "当前／要求",
			maxPayout: "每股分红上限 {{n}}",
			stars: "★ {{have}}/{{need}}",
			face: "面值",
			pass: "过",
			bid: "出价",
			raise: "加价",
			leaveAuction: "退出拍卖",
			startAuction: "发起拍卖",
			buyShare: "买入股票",
			sellShare: "卖出股票",
			dealPropose: "发起收购",
			dealPickBuyer: "选择收购方(你任总裁的集团)",
			dealPickCompany: "选择目标公司",
			privateOwner: "玩家私有",
			dealPickPrice: "价格({{min}}–{{max}})",
			dealPending: "{{corp}} 拟以 {{price}} 收购 {{company}}",
			dealFromFi: "卖方:外商",
			dealFromPlayer: "卖方:{{name}}",
			dealFromCorp: "卖方:{{corp}}",
			dealWaitSeller: "等待卖方确认",
			dealWaitSuitor: "等待 {{corp}} 总裁决定是否干预",
			accept: "接受",
			reject: "拒绝",
			intervene: "干预买下",
			passIntervene: "不干预",
			doneAcquire: "结束收购",
			closePrompt: "点击自己的公司卡将其关闭(移除出游戏)",
			confirmClose: "确认关闭 {{company}}",
			doneClosing: "完成关闭",
			dividendPrompt: "{{corp}}:定每股分红(0–{{max}})",
			dividendPay: "分红",
			issuePrompt: "{{corp}}:是否增发一股?(股价下移一格换现金)",
			issueYes: "增发",
			issueNo: "不增发",
			ipoPrompt: "{{company}}:组建集团还是保持私有?",
			ipoPass: "保持私有",
			ipoConfirm: "组建集团",
			ipoPickCharter: "选择执照",
			ipoPickPrice: "选择初始股价",
			priceOccupied: "已被 {{corp}} 占用",
			ipoPreview: "获得 {{shares}} 股 · 需补差价 {{payment}}",
			waiting: "等待其他玩家…",
			tierRed: "红",
			tierOrange: "橙",
			tierYellow: "黄",
			tierGreen: "绿",
			tierBlue: "蓝",
			dtRed: "无持有成本",
			dtOrange: "无持有成本",
			dtYellow: "无持有成本",
			dtGreen: "持有成本:红 −2",
			dtBlue: "持有成本:红/橙 −4",
			dtEnd: "持有成本:红/橙/黄 −7",
			dtFlipped: "持有成本:红/橙/黄/绿 −10",
			abilityJupiter: "每家公司 +1 收入",
			abilitySaturn: "最佳公司收入翻倍",
			abilityHorse: "每 2 个协同标记 +1 收入",
			abilityBear: "总持有成本 −10(最低 0)",
			abilityEagle: "增发股票不改变股价",
			abilityOrion: "买外商公司付面值且最优先",
			abilityShip: "关闭公司时获得两倍印刷收入",
			abilityStar: "星数 +2",
			scoreCash: "现金 {{n}}",
			scoreCompanies: "公司面值 {{n}}",
			scoreShares: "股票 {{n}}",
			scoreTotal: "总资产 {{n}}",
			errBadPhase: "当前阶段不能这么做",
			errNotYourTurn: "还没轮到你",
			errNoSuchCompany: "没有这张公司卡",
			errNotAvailable: "该公司当前不可用",
			errBidTooLow: "出价不能低于面值",
			errNotEnoughCash: "现金不足",
			errMustRaise: "加价必须高于当前最高价",
			errNoShares: "该集团没有可买的股票",
			errNotSellable: "没有可卖的股票",
			errNoHigherCard: "没有更高的可用股价卡",
			errNotPresident: "只有总裁能这么做",
			errBadPrice: "价格不在允许区间",
			errCorpNeedCompany: "集团必须至少保留一家公司",
			errReceivership: "托管中的集团不能交易",
			errDealPending: "有交易正在等待处理",
			errNotSeller: "只有卖方能确认",
			errNotSuitor: "还没轮到你表态干预",
			errMustClose: "下阶段收入为负且现金不够付,必须先关闭亏损公司",
			errBadDividend: "分红超出允许范围",
			errNotCharter: "该执照不可用",
			errBadIpoPrice: "该股价卡不可用于这家公司",
			errNotOwner: "只有持有者能这么做",
			hintPass: "过",
			hintAuction: "以 {{n}} 起拍 {{company}}",
			hintRaise: "加价到 {{n}}",
			hintLeave: "退出拍卖",
			hintBuy: "买入 {{corp}} 一股",
			hintSell: "卖出 {{corp}} 一股",
			hintDeal: "以 {{price}} 收购 {{company}}",
			hintAccept: "接受这笔交易",
			hintReject: "拒绝这笔交易",
			hintIntervene: "干预抢买",
			hintPassIntervene: "不干预",
			hintDone: "结束当前阶段",
			hintClose: "关闭 {{company}}",
			hintDividend: "每股分红 {{n}}",
			hintIssue: "增发一股",
			hintNoIssue: "不增发",
			hintIpo: "以股价 {{price}} 组建 {{corp}}",
			hintIpoPass: "保持私有"
		},
		en: {
			name: "Rolling Stock Stars",
			desc: "Auction railroads, form corporations, trade shares and pay dividends — a pure financial card game in the 18XX family",
			rules: "Goal: when the game ends, the richest player wins — cash + face value of private companies + shares × share price.\nSetup: each player gets 30 (25 in a 6-player game); the company deck is built by player count (red on top, blue at the bottom, end card at the very bottom); reveal as many companies as players as the offering.\nEach turn has 9 phases:\n· 1 Investment: take turns starting auctions (open bidding, opening bid at least face value), buying or selling shares, or passing; the phase ends when everyone passes in a row.\n· Buying pays the next higher available price card; selling receives the next lower one.\n· Owning strictly more shares than the president takes over the presidency; if the bank holds all issued shares, the corporation goes into receivership.\n· 2 Wrap-up: player order is re-sorted by cash; the foreign investor (+5 income per turn) buys the cheapest companies it can afford, in ascending face value.\n· 3 Acquisition: corporations may spend treasury cash to buy companies from players, the foreign investor, or other corporations, at a price within the printed span.\n· The foreign investor only sells at the maximum price; corporations with a higher share price may intervene (Overseas Trading always has priority and pays face value).\n· 4 Closing: companies may be closed; if your next income would be negative beyond your cash, you must close until you can pay.\n· 5 Income: players and corporations collect (company income minus cost of ownership; corporations add synergy and ability bonuses).\n· 6 Dividends: in descending share price order, the president sets a dividend per share (up to one third of the price, rounded down).\n· Then the share price adjusts by stars (company stars plus cash divided by 10, rounded down) against the card requirement.\n· 2 stars over jumps two cards, 1 over rises one, 1 under drops one, 2 under drops two; reaching 0 means bankruptcy.\n· 7 End check: if a corporation holds the 75 card, or the end card is already flipped, the game ends; otherwise flip the end card once no companies are left to buy.\n· 8 Issue shares: in share price order, each corporation may issue one share to the bank for cash (price moves down one card).\n· 9 IPO: in descending face value order, private companies may form corporations — pick an unused charter and a starting price in the company color range.\n· Below face value you take 2 shares, otherwise 1 share and pay the difference; the bank takes the same number of shares and pays into the treasury.\nCorporation abilities:\n· Prussian Railway +1 income per company; Doppler AG doubles its best company; Synergistic +1 per 2 synergy markers.\n· Vintage Machinery −10 total cost of ownership; Stock Masters issues at unchanged price; Overseas Trading pays face value to the foreign investor with top priority.\n· Junkyard Scrappers doubles income when closing a company; Stars Inc. +2 stars.",
			turn: "Turn {{n}}",
			players: "Player assets",
			companyShort: "Co",
			shareShort: "Sh",
			phaseInvest: "Investment",
			phaseAcquire: "Acquisition",
			phaseClose: "Closing",
			phaseDividend: "Dividends",
			phaseIssue: "Issue Shares",
			phaseIpo: "IPO",
			phaseDone: "Game Over",
			investPrompt: "Your move: auction, trade, or pass",
			investWait: "Waiting for {{name}}",
			auctionLive: "Auction: {{company}} at {{n}}",
			raisePrompt: "Raise above {{n}} or leave",
			raiseWait: "Waiting for {{name}}",
			offering: "Offering",
			noOffering: "Awaiting new companies",
			nextRound: "Next Turn",
			usedThisPhase: "Traded This Phase",
			selectOfferHint: "Tap a company certificate on the table to start an auction",
			tradeHint: "You can also trade shares on a corporation charter",
			bidTicket: "Auction ticket · {{company}} · Face ${{face}} · Cash ${{cash}}",
			cancel: "Cancel",
			deckTop: "Deck",
			fi: "Foreign Investor",
			corps: "Corporations",
			noCorps: "No corporation yet. Your private company can form one during IPO.",
			holdings: "Portfolio and Foreign Investor",
			noPrivateCompanies: "No company cards yet",
			myCompanies: "My Companies",
			charters: "Available Charters",
			price: "Price",
			cash: "Cash",
			treasury: "Treasury",
			income: "Income",
			netIncome: "Net Income",
			cardDetails: "{{company}} · Certificate",
			closeDetails: "Close company details",
			cost: "Cost",
			synergy: "Synergy",
			president: "President",
			receivership: "Receivership",
			bankStock: "Bank: {{n}}",
			bankShort: "Bank",
			shareholders: "Shares",
			subsidiaries: "Subsidiaries",
			starRequirement: "Current / Required",
			maxPayout: "Max dividend/share {{n}}",
			stars: "★ {{have}}/{{need}}",
			face: "Face",
			pass: "Pass",
			bid: "Bid",
			raise: "Raise",
			leaveAuction: "Leave",
			startAuction: "Start Auction",
			buyShare: "Buy Share",
			sellShare: "Sell Share",
			dealPropose: "Propose Deal",
			dealPickBuyer: "Pick buyer (a corporation you preside)",
			dealPickCompany: "Pick target company",
			privateOwner: "Player-owned",
			dealPickPrice: "Price ({{min}}–{{max}})",
			dealPending: "{{corp}} offers {{price}} for {{company}}",
			dealFromFi: "Seller: Foreign Investor",
			dealFromPlayer: "Seller: {{name}}",
			dealFromCorp: "Seller: {{corp}}",
			dealWaitSeller: "Waiting for the seller",
			dealWaitSuitor: "Waiting for {{corp}} president to intervene or pass",
			accept: "Accept",
			reject: "Reject",
			intervene: "Intervene",
			passIntervene: "No Intervention",
			doneAcquire: "Done Acquiring",
			closePrompt: "Tap your own company card to close it (removed from the game)",
			confirmClose: "Confirm closing {{company}}",
			doneClosing: "Done Closing",
			dividendPrompt: "{{corp}}: set dividend per share (0–{{max}})",
			dividendPay: "Pay",
			issuePrompt: "{{corp}}: issue one share? (price drops one card for cash)",
			issueYes: "Issue",
			issueNo: "Skip",
			ipoPrompt: "{{company}}: form a corporation or stay private?",
			ipoPass: "Stay Private",
			ipoConfirm: "Form Corporation",
			ipoPickCharter: "Pick a charter",
			ipoPickPrice: "Pick starting price",
			priceOccupied: "Occupied by {{corp}}",
			ipoPreview: "Receive {{shares}} shares · balance due {{payment}}",
			waiting: "Waiting for other players…",
			tierRed: "Red",
			tierOrange: "Orange",
			tierYellow: "Yellow",
			tierGreen: "Green",
			tierBlue: "Blue",
			dtRed: "No cost of ownership",
			dtOrange: "No cost of ownership",
			dtYellow: "No cost of ownership",
			dtGreen: "Cost of ownership: red −2",
			dtBlue: "Cost of ownership: red/orange −4",
			dtEnd: "Cost of ownership: red/orange/yellow −7",
			dtFlipped: "Cost of ownership: red/orange/yellow/green −10",
			abilityJupiter: "+1 income per company",
			abilitySaturn: "Best company income doubled",
			abilityHorse: "+1 income per 2 synergy markers",
			abilityBear: "Total cost of ownership −10 (min 0)",
			abilityEagle: "Issuing shares keeps the price",
			abilityOrion: "Pays face value to the foreign investor, top priority",
			abilityShip: "Closing a company pays 2× printed income",
			abilityStar: "+2 stars",
			scoreCash: "Cash {{n}}",
			scoreCompanies: "Companies {{n}}",
			scoreShares: "Shares {{n}}",
			scoreTotal: "Total {{n}}",
			errBadPhase: "Not allowed in this phase",
			errNotYourTurn: "Not your turn",
			errNoSuchCompany: "No such company",
			errNotAvailable: "That company is not available",
			errBidTooLow: "Bid must be at least face value",
			errNotEnoughCash: "Not enough cash",
			errMustRaise: "Raise must beat the current high bid",
			errNoShares: "No shares available to buy",
			errNotSellable: "No share to sell",
			errNoHigherCard: "No higher price card available",
			errNotPresident: "Only the president can do this",
			errBadPrice: "Price out of the allowed span",
			errCorpNeedCompany: "A corporation must keep at least one company",
			errReceivership: "Corporations in receivership cannot trade",
			errDealPending: "A deal is already pending",
			errNotSeller: "Only the seller can confirm",
			errNotSuitor: "Not your call to intervene",
			errMustClose: "Negative income beyond your cash — close losing companies first",
			errBadDividend: "Dividend out of range",
			errNotCharter: "Charter not available",
			errBadIpoPrice: "Price card not eligible for this company",
			errNotOwner: "Only the owner can do this",
			hintPass: "Pass",
			hintAuction: "Open {{company}} at {{n}}",
			hintRaise: "Raise to {{n}}",
			hintLeave: "Leave the auction",
			hintBuy: "Buy one share of {{corp}}",
			hintSell: "Sell one share of {{corp}}",
			hintDeal: "Buy {{company}} for {{price}}",
			hintAccept: "Accept the deal",
			hintReject: "Reject the deal",
			hintIntervene: "Intervene and buy",
			hintPassIntervene: "No intervention",
			hintDone: "Finish the phase",
			hintClose: "Close {{company}}",
			hintDividend: "Dividend {{n}} per share",
			hintIssue: "Issue one share",
			hintNoIssue: "Do not issue",
			hintIpo: "Form {{corp}} at {{price}}",
			hintIpoPass: "Stay private"
		}
	}
};
//#endregion
export { tt as default };
