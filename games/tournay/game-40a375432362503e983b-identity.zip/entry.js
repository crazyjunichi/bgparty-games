import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s, useFxAnchorsMaybe as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as u } from "@bgparty/sdk/i18n";
import { Texture as d } from "@bgparty/sdk/texture";
import { useWakeLock as f } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as m } from "@bgparty/sdk/ui/phase-banner";
import { seatName as h } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as ee, FlySprite as y, PulseBox as te } from "@bgparty/sdk/fx/primitives";
import { Confetti as ne } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as re, OptionSection as ie, OptionSwitch as ae } from "@bgparty/sdk/ui/game-options";
//#region src/games/tournay/data.ts
var b = [
	"yellow",
	"white",
	"red"
], x = {}, S = (e, t, n, r, i, a, o = {}) => {
	x[e] = {
		id: e,
		color: t,
		level: n,
		kind: r,
		points: i,
		effect: a,
		cost: n === 1 ? 1 : 3,
		...o
	};
};
for (let e of [1, 2]) {
	let t = e;
	S(`y${t}-architect`, "yellow", t, "character", 1, "architect", { amount: t }), S(`y${t}-quarry`, "yellow", t, "building", t, "money", {
		amount: t + 3,
		marked: !0
	}), S(`y${t}-journeyman`, "yellow", t, "character", +(t === 1), "journeyman", { amount: t }), S(`y${t}-councillor`, "yellow", t, "character", t, "councillor", {
		amount: t * 2,
		marked: !0
	}), S(`y${t}-${t === 1 ? "farm" : "toll"}`, "yellow", t, "building", 0, t === 1 ? "empty" : "occupied", { marked: !0 }), S(`y${t}-barn`, "yellow", t, "building", 1, "draw", {
		target: "yellow",
		drawLevel: t + 1
	}), S(`y${t}-residence`, "yellow", t, "building", t, "recruit", {
		target: "yellow",
		amount: t === 1 ? 3 : 2
	}), S(`y${t}-market`, "yellow", t, "building", t - 1, "money", { amount: t + 4 }), S(`y${t}-port`, "yellow", t, "building", 1, "copy", {
		target: "yellow",
		amount: t
	}), S(`y${t}-brewery`, "yellow", t, "building", 0, "brewery", {
		expansion: !0,
		amount: t
	}), S(`y${t}-senator`, "yellow", t, "character", t, "senator", {
		expansion: !0,
		amount: t + 1
	}), S(`y${t}-${t === 1 ? "inn" : "bakery"}`, "yellow", t, "building", t, t === 1 ? "inn" : "bakery", { expansion: !0 }), S(`w${t}-prior`, "white", t, "character", 0, "prior", {
		amount: t + 1,
		marked: !0
	}), S(`w${t}-library-draw`, "white", t, "building", +(t === 1), "draw", { drawLevel: t + 1 }), S(`w${t}-library-two`, "white", t, "building", 0, "takeTwo", {
		drawLevel: t,
		marked: t === 1
	}), S(`w${t}-bishopric`, "white", t, "building", t - 1, t === 1 ? "takeTwo" : "draw", {
		target: "white",
		drawLevel: t + 1
	}), t === 1 ? (S("w1-bishop", "white", 1, "character", 1, "bishop", { marked: !0 }), S("w1-hospital", "white", 1, "building", 1, "money", { amount: 4 })) : (S("w2-augustinian", "white", 2, "character", 2, "augustinian", {
		marked: !0,
		amount: 2
	}), S("w2-monastery-white", "white", 2, "building", 2, "recruit", {
		target: "white",
		amount: 2,
		marked: !0
	})), S(`w${t}-monastery`, "white", t, "building", 0, "recruit", { amount: t === 1 ? 3 : 2 }), S(`w${t}-bridge`, "white", t, "building", 0, "copy", { amount: t }), S(`w${t}-priest`, "white", t, "character", 1, "priest"), S(`w${t}-abbey`, "white", t, "building", 0, "abbey", { expansion: !0 }), S(`w${t}-monk`, "white", t, "character", 0, "monk", {
		expansion: !0,
		cost: t === 1 ? 5 : 3,
		target: "yellow"
	}), S(`w${t}-templar`, "white", t, "character", 0, "templar", {
		expansion: !0,
		cost: t === 1 ? 5 : 3,
		target: "red"
	}), S(`r${t}-arsenal`, "red", t, "building", 1, "draw", {
		target: "red",
		drawLevel: t + 1
	}), S(`r${t}-lawyer`, "red", t, "character", t, "lawyer", {
		amount: t + 1,
		marked: !0
	}), S(`r${t}-ballista`, "red", t, "building", t, "ballista", { amount: t + 1 }), t === 1 ? S("r1-knight", "red", 1, "character", 1, "knight") : S("r2-bastion", "red", 2, "building", 1, "fight", { amount: 0 }), S(`r${t}-barracks`, "red", t, "building", t, "recruit", {
		target: "red",
		amount: t === 1 ? 3 : 2
	}), S(`r${t}-fort`, "red", t, "building", 1, "fight", { amount: t }), S(`r${t}-fort-marked`, "red", t, "building", 1, "fight", {
		amount: t,
		marked: !0
	}), S(`r${t}-tax`, "red", t, "character", t, "tax", {
		amount: t,
		marked: !0
	}), S(`r${t}-road`, "red", t, "building", 1, "copy", {
		target: "red",
		amount: t
	}), S(`r${t}-pair-knight`, "red", t, "character", t, "pairKnight", {
		expansion: !0,
		amount: t
	});
}
S("r1-seigniory", "red", 1, "building", 1, "seigniory", { expansion: !0 }), S("r1-catapult", "red", 1, "building", 1, "catapult", { expansion: !0 }), S("r2-mercenary", "red", 2, "character", 2, "mercenary", { expansion: !0 }), S("r2-court", "red", 2, "building", 2, "court", { expansion: !0 });
var C = (e, t, n, r = 2, i = 1, a) => {
	x[e] = {
		id: e,
		color: t,
		level: 3,
		kind: "prestige",
		cost: a === "card" ? 2 : a ? 0 : 5,
		points: 0,
		metric: n,
		owner: r,
		guest: i,
		sacrifice: a
	};
};
C("y3-belfry", "yellow", "setsCards", 4, 2), C("y3-cloth", "yellow", "yellowCards", 2, 1, "yellow"), C("y3-mint", "yellow", "money"), C("y3-hall", "yellow", "yellowWorkers", 2, 1, "card"), C("y3-six", "yellow", "characters"), C("w3-cathedral", "white", "cathedral", 0, 0), x["w3-cathedral"].cost = 20, x["w3-cathedral"].points = 8, C("w3-madeleine", "white", "prestige", 2, 1, "card"), C("w3-brice", "white", "setsCards", 4, 2), C("w3-jacques", "white", "whiteCards", 2, 1, "white"), C("w3-nicolas", "white", "setsWorkers", 3, 1), C("w3-quentin", "white", "whiteWorkers", 2, 1, "card"), C("r3-trous", "red", "setsWorkers", 3, 1), C("r3-vigne", "red", "redWorkers", 2, 1, "card"), C("r3-georges", "red", "redCards", 2, 1, "red"), C("r3-arras", "red", "civilBuildings"), C("r3-henry", "red", "walls");
var w = {
	yellow: [
		"y3-hall",
		"y3-hall",
		"y3-six",
		"y3-six",
		"y3-cloth",
		"y3-cloth",
		"y3-mint",
		"y3-mint",
		"y3-belfry"
	],
	white: [
		"w3-cathedral",
		"w3-madeleine",
		"w3-madeleine",
		"w3-brice",
		"w3-jacques",
		"w3-jacques",
		"w3-nicolas",
		"w3-quentin",
		"w3-quentin"
	],
	red: [
		"r3-vigne",
		"r3-vigne",
		"r3-georges",
		"r3-georges",
		"r3-arras",
		"r3-arras",
		"r3-trous",
		"r3-henry",
		"r3-henry"
	]
}, T = (e) => x[e.split("~")[0]], E = (e, t) => `${e}:${t}`, D = [
	{
		color: "white",
		effect: "damage",
		cap: 2
	},
	{
		color: "red",
		effect: "rest",
		target: "red",
		cap: 2
	},
	{
		color: "red",
		effect: "loss",
		cap: 3
	},
	{
		color: "yellow",
		effect: "damage",
		target: "yellow",
		cap: 3
	},
	{
		color: "yellow",
		effect: "loss",
		cap: 3
	},
	{
		color: "red",
		effect: "rest",
		cap: 2
	},
	{
		color: "white",
		effect: "rest",
		target: "white",
		cap: 3
	},
	{
		color: "yellow",
		effect: "positive",
		target: "yellow",
		cap: 2
	},
	{
		color: "yellow",
		effect: "rest",
		target: "yellow",
		cap: 3
	},
	{
		color: "red",
		effect: "damage",
		target: "red",
		cap: 2
	},
	{
		color: "white",
		effect: "damage",
		target: "white",
		cap: 3
	},
	{
		color: "white",
		effect: "loss",
		cap: 3
	},
	{
		color: "white",
		effect: "positive",
		target: "white",
		cap: 2
	},
	{
		color: "yellow",
		effect: "loss",
		cap: 2
	},
	{
		color: "red",
		effect: "positive",
		target: "red",
		cap: 2
	}
], O = (e) => e.startsWith("event:"), oe = (e) => Number(e.slice(6)), se = {
	id: "tournay",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"engine-building",
		"tile-placement",
		"hand-management"
	],
	interactionTags: [],
	nameKey: "games.tournay.name",
	descKey: "games.tournay.desc",
	rulesKey: "games.tournay.rules",
	icon: "🏰",
	iconImg: "games/tournay.webp",
	rulesUrl: { fr: "https://pearlgames.be/wp-content/uploads/2017/10/TOURNAY_RULES_FR_06_02_12_LD.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#86582d",
	releasedAt: "2026-10-31T14:17:20+08:00",
	search: {
		py: "tu er nai",
		init: "ten"
	},
	hotseat: "cover"
}, k = (e, t, n) => `tn:pool:${e}:${t}:${n}`, A = (e, t, n, r) => `${k(e, t, n)}:${r}`, ce = (e, t, n, r) => `tn:worker:${e}:${t},${n}:${r}`, j = (e, t, n) => `tn:cell:${e}:${t},${n}`;
function M(e, t, n, r) {
	e && e.push({
		kind: "move",
		rid: t,
		data: n,
		with: e.length > 0,
		...r ? {
			for: [t],
			secret: { card: r }
		} : {}
	});
}
//#endregion
//#region src/games/tournay/schema.ts
var N = t.enum([
	"yellow",
	"white",
	"red"
]), P = t.object({
	advanced: t.boolean().default(!1),
	expansion: t.enum([
		"off",
		"replace",
		"mix"
	]).default("off")
}).default({
	advanced: !1,
	expansion: "off"
}), le = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().min(1).max(180)
}), t.object({
	type: t.literal("tick"),
	now: t.number().finite()
})]), ue = t.object({
	x: t.int(),
	y: t.int(),
	stack: t.array(t.string()),
	workers: t.array(t.enum([
		"yellow",
		"white",
		"red",
		"gray"
	])),
	damage: t.boolean()
}), F = t.object({
	yellow: t.int().nonnegative(),
	white: t.int().nonnegative(),
	red: t.int().nonnegative()
}), de = t.object({
	id: t.string(),
	label: t.string(),
	kind: t.enum([
		"action",
		"card",
		"cell",
		"worker",
		"deck",
		"event",
		"color"
	]),
	card: t.string().optional(),
	owner: t.string().optional(),
	x: t.int().optional(),
	y: t.int().optional(),
	color: N.optional(),
	level: t.int().optional(),
	amount: t.int().optional(),
	extra: t.string().optional()
}), fe = t.object({
	phase: t.enum([
		"play",
		"final",
		"settle",
		"done"
	]),
	turn: t.string(),
	decision: t.string().nullable(),
	prompt: t.string(),
	round: t.int(),
	crierCount: t.int(),
	lastRound: t.boolean(),
	config: P,
	players: t.array(t.object({
		rid: t.string(),
		money: t.int().nonnegative(),
		ready: F,
		resting: F,
		total: F,
		city: t.array(ue),
		handCount: t.int().nonnegative(),
		walls: t.int().nonnegative(),
		locked: t.boolean()
	})),
	decks: t.array(t.object({
		key: t.string(),
		color: N,
		level: t.int(),
		count: t.int().nonnegative(),
		face: t.string().nullable(),
		crier: t.boolean()
	})),
	events: t.array(t.object({
		card: t.int(),
		coins: t.int().nonnegative()
	}).nullable()),
	supply: F,
	eventCount: t.int().nonnegative(),
	revealed: t.array(t.string()),
	event: t.int().nullable(),
	last: t.object({
		kind: t.string(),
		rid: t.string(),
		card: t.string().nullable(),
		amount: t.int(),
		serial: t.int()
	}).nullable(),
	scores: t.record(t.string(), t.object({
		printed: t.int(),
		walls: t.int(),
		prestige: t.array(t.object({
			card: t.string(),
			amount: t.int(),
			owner: t.boolean()
		})),
		total: t.int()
	}))
}), pe = t.object({
	hand: t.array(t.string()),
	choices: t.array(de),
	prompt: t.string(),
	selected: t.string().nullable()
}), I = (e = 0) => ({
	yellow: e,
	white: e,
	red: e
}), me = (e) => {
	let t = I();
	for (let n of b) t[n] = e.ready[n] + e.resting[n] + e.city.reduce((e, t) => e + t.workers.filter((e) => e === n).length, 0);
	return t;
}, L = (e) => e.stack[e.stack.length - 1], R = (e, t, n) => e.city.find((e) => e.x === t && e.y === n), z = (e, t) => e !== t && (e.x === t.x || e.y === t.y), B = (e) => e.city.filter((e) => !e.damage && T(L(e)).kind === "character");
function he(e, t) {
	let n = T(L(t));
	return B(e).some((e) => z(e, t) && T(L(e)).effect === "priest" && (T(L(e)).level === 2 || n.color === "white")) ? 2 : 1;
}
var ge = (e, t) => !t.damage && T(L(t)).kind === "building" && t.workers.length < he(e, t), V = (e) => Object.values(e.people).reduce((e, t) => e + t.city.reduce((e, t) => e + Number(t.damage) + t.workers.filter((e) => e === "gray").length, 0), 0) < 20, H = (e, t) => e.phase === "final" ? e.finalTasks[t] : e.tasks[0], _e = (e, t, n) => {
	e.phase === "final" ? n[0] ? e.finalTasks[t] = n[0] : delete e.finalTasks[t] : e.tasks.splice(0, 1, ...n);
}, U = (e, ...t) => e.tasks.unshift(...t), W = (e, t, n, r = null, i = 0) => {
	e.last = {
		kind: t,
		rid: n,
		card: r,
		amount: i,
		serial: e.serial + 1
	};
};
function ve(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rngCursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ye(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		serial: 0,
		players: [...t],
		people: {},
		decks: {},
		events: [],
		eventDeck: [],
		supply: I(e.advanced ? t.length + 3 : 3),
		config: e,
		turnIdx: 0,
		round: 1,
		crierCount: 0,
		lastRound: !1,
		phase: "play",
		tasks: [{
			type: "build",
			rid: t[0]
		}, {
			type: "action",
			rid: t[0]
		}],
		finalTasks: {},
		finalPlans: {},
		catapultUsed: [],
		scores: {},
		last: null
	};
	for (let n of t) r.people[n] = {
		rid: n,
		money: e.advanced ? 9 : 6,
		ready: I(e.advanced ? 1 : 2),
		resting: I(),
		city: [],
		hand: [],
		walls: []
	};
	for (let t of b) for (let n of [
		1,
		2,
		3
	]) {
		let i = E(t, n), a = n === 3 ? w[t] : Object.values(x).filter((e) => e.color === t && e.level === n && !e.expansion).map((e) => e.id);
		if (n !== 3 && e.expansion !== "off") {
			let i = a.filter((e) => !x[e].marked), o = Object.values(x).filter((e) => e.color === t && e.level === n && e.expansion).map((e) => e.id), s = e.expansion === "mix" ? a.filter((e) => x[e].marked).concat(o) : o;
			a = i.concat(ve(r, s).slice(0, 3));
		}
		r.decks[i] = {
			color: t,
			level: n,
			cards: ve(r, a.map((e, t) => `${e}~${t}`).concat(`crier:${i}`)),
			face: !1,
			crier: !1
		};
	}
	return r.eventDeck = ve(r, D.map((e, t) => t)), r.events = [
		0,
		1,
		2
	].map(() => ({
		card: r.eventDeck.shift(),
		coins: 0
	})), { state: r };
}
function be(e, t, n, r) {
	if (O(t)) e.eventDeck.push(oe(t));
	else {
		let n = T(t);
		e.decks[E(n.color, n.level)].cards.push(t);
	}
	r && M(n, r.rid, {
		piece: "card",
		from: r.from,
		to: O(t) ? "tn:event-deck" : `tn:deck:${E(T(t).color, T(t).level)}`,
		...r.open ? { card: t } : {}
	}, r.open ? void 0 : t);
}
function G(e, t, n, r, i, a) {
	if (!r) return;
	let o = e[n][t];
	e[n][t] += r;
	let s = n === "ready" ? Array.from({ length: Math.max(0, Math.min(r, 6 - o)) }, (r, i) => A(e.rid, t, n, o + i)) : o === 0 ? [A(e.rid, t, n, 0)] : [];
	M(a, e.rid, {
		piece: "citizen",
		color: t,
		count: r,
		from: i,
		to: k(e.rid, t, n),
		hide: s
	});
}
function xe(e, t, n, r) {
	e.ready[t] -= n, G(e, t, "resting", n, k(e.rid, t, "ready"), r);
}
function Se(e, t, n) {
	let r = j(e.rid, t.x, t.y);
	for (let i of t.workers) i === "gray" ? M(n, e.rid, {
		piece: "citizen",
		color: i,
		from: r,
		to: "tn:supply"
	}) : G(e, i, "resting", 1, r, n);
	t.damage && M(n, e.rid, {
		piece: "damage",
		from: r,
		to: "tn:supply"
	}), t.workers = [], t.damage = !1;
}
function Ce(e, t, n, r) {
	if (!n) return;
	let i = e.people[t];
	if (n.startsWith("hand|")) {
		let a = n.slice(5);
		i.hand.splice(i.hand.indexOf(a), 1), be(e, a, r, {
			rid: t,
			from: `tn:hand:${t}`,
			open: !1
		});
	} else if (n.startsWith("city|")) {
		let [, a, o, s] = n.split("|"), c = R(i, Number(a), Number(o));
		L(c) === s && Se(i, c, r), c.stack.splice(c.stack.indexOf(s), 1), be(e, s, r, {
			rid: t,
			from: j(t, c.x, c.y),
			open: !0
		}), c.stack.length || i.city.splice(i.city.indexOf(c), 1);
	} else {
		let [, a, o, s, c] = n.split("|"), l = a;
		if (o === "ready") i.ready[l]--;
		else if (o === "resting") i.resting[l]--;
		else {
			let e = R(i, Number(s), Number(c));
			e.workers.splice(e.workers.indexOf(l), 1);
		}
		e.supply[l]++, M(r, t, {
			piece: "citizen",
			color: l,
			from: o === "city" ? j(t, Number(s), Number(c)) : k(t, l, o),
			to: "tn:supply"
		});
	}
}
function we(e, t, n) {
	if (!t.sacrifice) return [];
	if (t.sacrifice === "card") return [...e.hand.filter((e) => e !== n && !O(e)).map((e) => ({
		token: `hand|${e}`,
		view: {
			card: e,
			kind: "card"
		}
	})), ...e.city.flatMap((t) => t.stack.map((n) => ({
		token: `city|${t.x}|${t.y}|${n}`,
		view: {
			card: n,
			kind: "cell",
			x: t.x,
			y: t.y,
			owner: e.rid
		}
	})))];
	let r = t.sacrifice;
	return [
		...e.ready[r] ? [{
			token: `worker|${r}|ready`,
			view: {
				color: r,
				amount: e.ready[r],
				kind: "worker",
				owner: e.rid,
				extra: "ready"
			}
		}] : [],
		...e.resting[r] ? [{
			token: `worker|${r}|resting`,
			view: {
				color: r,
				amount: e.resting[r],
				kind: "worker",
				owner: e.rid,
				extra: "resting"
			}
		}] : [],
		...e.city.filter((e) => e.workers.includes(r)).map((t) => ({
			token: `worker|${r}|city|${t.x}|${t.y}`,
			view: {
				color: r,
				kind: "cell",
				x: t.x,
				y: t.y,
				owner: e.rid
			}
		}))
	];
}
function Te(e) {
	if (!e.length) return [{
		x: 0,
		y: 0
	}];
	let t = /* @__PURE__ */ new Map();
	for (let n of e) for (let [r, i] of [
		[0, 0],
		[-1, 0],
		[1, 0],
		[0, -1],
		[0, 1]
	]) {
		let a = n.x + r, o = n.y + i, s = e.map((e) => e.x).concat(a), c = e.map((e) => e.y).concat(o);
		Math.max(...s) - Math.min(...s) < 3 && Math.max(...c) - Math.min(...c) < 3 && t.set(`${a},${o}`, {
			x: a,
			y: o
		});
	}
	return [...t.values()].sort((e, t) => e.y - t.y || e.x - t.x);
}
function Ee(e, t, n, r) {
	let i = structuredClone(e);
	Ce(i, t, r);
	let a = i.people[t], o = T(n);
	return o.kind === "prestige" && a.city.some((e) => e.stack.some((e) => T(e).id === o.id)) ? [] : Te(a.city);
}
function De(e, t, n, r) {
	let i = e.people[t], a = T(n.card);
	Ce(e, t, n.sacrifice, r), i.money -= a.cost, i.hand.splice(i.hand.indexOf(n.card), 1);
	let o = R(i, n.x, n.y);
	if (o) {
		if (Se(i, o, r), T(L(o)).color !== a.color) {
			for (let n of o.stack) be(e, n, r, {
				rid: t,
				from: j(t, o.x, o.y),
				open: !0
			});
			o.stack = [];
		}
	} else o = {
		x: n.x,
		y: n.y,
		stack: [],
		workers: [],
		damage: !1
	}, i.city.push(o);
	o.stack.push(n.card), W(e, "build", t, n.card);
	let s = [];
	for (let e of B(i).filter((e) => e !== o && z(e, o))) {
		let n = T(L(e));
		(n.effect === "architect" && a.kind !== "character" || n.effect === "councillor" && a.kind === "character" || n.effect === "lawyer" && a.kind === "building" && a.color !== "red" || n.effect === "augustinian" && a.color === "white" && a.kind !== "prestige") && s.push({
			type: "gain",
			rid: t,
			n: n.amount ?? 0,
			card: L(e)
		}), n.effect === "knight" && a.kind === "prestige" && s.push({
			type: "fightEffect",
			rid: t,
			n: 2,
			card: L(e)
		});
	}
	U(e, ...s);
}
function Oe(e, t, n) {
	e.finalPlans[t] = n, delete e.finalTasks[t], Object.keys(e.finalPlans).length === e.players.length && (e.phase = "settle", e.tasks = [
		{
			type: "revealFinal",
			rid: e.players[0]
		},
		{
			type: "finalWalls",
			rid: e.players[0]
		},
		{
			type: "score",
			rid: e.players[0]
		}
	]);
}
function ke(e, t, n) {
	let r = e.people[t.rid], i = t.color, a = t.owners ?? [];
	r.money -= t.price ?? 0;
	for (let o of a) {
		let a = e.people[o];
		a.ready[i]--, o !== t.rid && (r.money -= 2, a.money += 2), (t.intent !== "activate" || o !== t.rid) && G(a, i, "resting", 1, k(o, i, "ready"), n);
	}
	if (t.intent === "draw" && U(e, {
		type: "draw",
		rid: t.rid,
		color: i,
		level: t.level
	}), t.intent === "fight" && Ae(e, t.rid, t.slot, !1, n), t.intent === "recruit" && (G(r, i, "ready", 1, "tn:supply", n), e.supply[i]--, W(e, "recruit", t.rid, null, 1)), t.intent === "activate") {
		let o = R(r, t.x, t.y), s = a[0] === t.rid ? i : "gray";
		o.workers.push(s), M(n, t.rid, {
			piece: "citizen",
			color: s,
			from: s === "gray" ? "tn:supply" : k(t.rid, i, "ready"),
			to: j(t.rid, o.x, o.y),
			hide: [ce(t.rid, o.x, o.y, o.workers.length - 1)]
		});
		let c = B(r).filter((e) => z(e, o) && T(L(e)).effect === "pairKnight" && (s === "red" || s === "gray") && r.city.filter((t) => z(e, t)).flatMap((e) => e.workers).filter((e) => e === "red" || e === "gray").length % 2 == 0).map((e) => ({
			type: "fightEffect",
			rid: t.rid,
			n: T(L(e)).amount,
			card: L(e)
		}));
		U(e, {
			type: "effectChoice",
			rid: t.rid,
			card: L(o),
			x: o.x,
			y: o.y,
			visited: [`${t.rid}:${o.x},${o.y}`]
		}, {
			type: "hooks",
			rid: t.rid,
			color: T(L(o)).color,
			x: o.x,
			y: o.y
		}, ...c), W(e, "activate", t.rid, L(o));
	}
}
function Ae(e, t, n, r, i) {
	let a = e.events[n];
	e.people[t].hand.push(`event:${a.card}`), r && (e.people[t].money += a.coins), e.events[n] = e.eventDeck.length ? {
		card: e.eventDeck.shift(),
		coins: 0
	} : null, M(i, t, {
		piece: "card",
		card: `event:${a.card}`,
		from: `tn:event:${n}`,
		to: `tn:hand:${t}`,
		hide: [`tn:hand:event:${a.card}`]
	});
	let o = e.events[n];
	o && M(i, t, {
		piece: "event",
		card: `event:${o.card}`,
		from: "tn:event-deck",
		to: `tn:event:${n}`,
		hide: [`tn:event-art:${o.card}`]
	}), W(e, "fight", t, `event:${a.card}`, r ? a.coins : 0);
}
function je(e, t, n, r) {
	let i = e.events[n];
	if (i.coins >= D[i.card].cap) return;
	let a = i.coins++;
	M(r, t, {
		piece: "coin",
		from: "tn:supply",
		to: `tn:event-coin:${i.card}:${a}`,
		hide: [`tn:event-coin:${i.card}:${a}`]
	});
}
function Me(e, t, n) {
	M(n, e.rid, {
		piece: "card",
		card: t,
		from: `tn:hand:${e.rid}`,
		to: `tn:walls:${e.rid}`,
		hide: e.walls.length ? [] : [`tn:wall-art:${e.rid}`]
	}), e.walls.push(t);
}
function Ne(e, t) {
	return Array.from({ length: t }, () => ({
		type: "crier",
		rid: e
	}));
}
function Pe(e, t, n) {
	let r = E(t.color, t.level), i = e.decks[r];
	i.face && i.cards.length > 2 && i.cards.push(i.cards.shift()), i.face = !1;
	let a = [], o = 0;
	for (; a.length < 2 && i.cards.length;) {
		let e = i.cards.shift();
		e.startsWith("crier:") ? (i.crier = !0, o++) : (a.push({
			deck: r,
			card: e
		}), n?.push({
			kind: "move",
			rid: t.rid,
			data: {
				piece: "card",
				from: `tn:deck:${r}`,
				to: `tn:seat:${t.rid}`
			},
			for: [t.rid],
			secret: {
				card: e,
				to: `tn:offer:${e}`,
				hide: [`tn:offer:${e}`]
			},
			with: n.length > 0
		}));
	}
	a.length ? _e(e, t.rid, [{
		...t,
		type: "drawPick",
		items: a,
		cries: o
	}]) : _e(e, t.rid, Ne(t.rid, o));
}
function Fe(e, t, n, r) {
	let i = e.people[t];
	for (let e of b) G(i, e, "ready", i.resting[e], k(t, e, "resting"), r), i.resting[e] = 0;
	if (n) {
		for (let e of i.city) {
			let n = j(t, e.x, e.y);
			for (let a of e.workers) a === "gray" ? M(r, t, {
				piece: "citizen",
				color: a,
				from: n,
				to: "tn:supply"
			}) : G(i, a, "ready", 1, n, r);
			e.damage && M(r, t, {
				piece: "damage",
				from: n,
				to: "tn:supply"
			}), e.workers = [], e.damage = !1;
		}
		U(e, ...B(i).filter((e) => T(L(e)).effect === "senator").map((e) => ({
			type: "gain",
			rid: t,
			card: L(e),
			n: T(L(e)).amount
		})));
	}
	W(e, "gather", t);
}
function K(e, t, n, r, i = 0) {
	let a = e.people[t];
	if (a.money < i) return !1;
	let o = e.players.filter((e) => e !== t).reduce((t, r) => t + e.people[r].ready[n], 0);
	return a.ready[n] + Math.min(o, Math.floor((a.money - i) / 2)) >= r;
}
var Ie = /* @__PURE__ */ new Set([
	"effect",
	"gain",
	"hooks",
	"readyResting",
	"crier",
	"event",
	"applyEvent",
	"take",
	"abbeyReveal",
	"advance",
	"revealFinal",
	"finalWalls",
	"score"
]);
function Le(e, t, n) {
	let r = H(e, t);
	if (!r || r.rid !== t || Ie.has(r.type) || e.phase === "done") return [];
	let i = e.people[t], a = [], o = (t, n, r, i = {}) => a.push({
		view: {
			id: `${e.serial}:${a.length}`,
			label: t,
			kind: n,
			...i
		},
		run: r
	}), s = (...n) => _e(e, t, n), c = () => o("skip", "action", () => s());
	if (r.type === "build") {
		o(e.phase === "final" ? "lockNone" : "skipBuild", "action", () => {
			e.phase === "final" ? Oe(e, t, null) : s();
		});
		for (let n of i.hand.filter((e) => !O(e))) {
			let r = T(n);
			i.money < r.cost || (r.sacrifice ? we(i, r, n) : [{ token: void 0 }]).some((r) => Ee(e, t, n, r.token).length) && o("build", "card", () => s({
				type: r.sacrifice ? "payment" : "place",
				rid: t,
				card: n
			}), {
				card: n,
				amount: r.cost
			});
		}
	} else if (r.type === "payment") {
		for (let n of we(i, T(r.card), r.card)) Ee(e, t, r.card, n.token).length && o("sacrifice", n.view.kind ?? "card", () => s({
			...r,
			type: "place",
			sacrifice: n.token
		}), n.view);
		o("cancel", "action", () => s({
			type: "build",
			rid: t
		}));
	} else if (r.type === "place") {
		for (let i of Ee(e, t, r.card, r.sacrifice)) o("place", "cell", () => {
			let a = {
				card: r.card,
				x: i.x,
				y: i.y,
				sacrifice: r.sacrifice
			};
			e.phase === "final" ? Oe(e, t, a) : (s(), De(e, t, a, n));
		}, {
			...i,
			owner: t,
			card: r.card
		});
		o("cancel", "action", () => s({
			type: "build",
			rid: t
		}));
	} else if (r.type === "action") {
		for (let n of Object.values(e.decks)) n.cards.length && K(e, t, n.color, n.level) && o("draw", "deck", () => s({
			type: "workers",
			rid: t,
			intent: "draw",
			color: n.color,
			level: n.level,
			n: n.level,
			owners: [],
			price: 0
		}, {
			type: "end",
			rid: t
		}), {
			color: n.color,
			level: n.level
		});
		for (let n of i.city.filter((n) => ge(i, n) && K(e, t, T(L(n)).color, 1) && (i.ready[T(L(n)).color] > 0 || V(e)))) o("activate", "cell", () => s({
			type: "workers",
			rid: t,
			intent: "activate",
			color: T(L(n)).color,
			n: 1,
			x: n.x,
			y: n.y,
			owners: [],
			price: 0
		}, {
			type: "end",
			rid: t
		}), {
			x: n.x,
			y: n.y,
			card: L(n),
			owner: t
		});
		e.events.forEach((n, r) => {
			if (!n?.coins) return;
			let i = D[n.card], a = i.effect === "loss" ? 2 : 1, c = i.effect === "loss" ? 0 : n.coins + 1;
			K(e, t, i.color, a, c) && o("fight", "event", () => s({
				type: "workers",
				rid: t,
				intent: "fight",
				color: i.color,
				slot: r,
				n: a,
				price: c,
				owners: []
			}, {
				type: "end",
				rid: t
			}), {
				card: `event:${n.card}`,
				amount: c,
				color: i.color,
				level: a
			});
		});
		for (let r of b) for (let a = 1; a <= i.ready[r]; a++) o("earn", "worker", () => {
			xe(i, r, a, n);
			let o = r === "red" && B(i).some((e) => T(L(e)).effect === "mercenary") ? 3 : 2;
			i.money += a * o, W(e, "earn", t, null, a * o), s({
				type: "end",
				rid: t
			});
		}, {
			color: r,
			owner: t,
			amount: a
		});
		if (o("gather", "action", () => {
			s({
				type: "end",
				rid: t
			}), Fe(e, t, !0, n);
		}), e.config.advanced) for (let n of b) e.supply[n] > 0 && K(e, t, n, 1, 5) && o("recruit", "color", () => s({
			type: "workers",
			rid: t,
			intent: "recruit",
			color: n,
			n: 1,
			price: 5,
			owners: []
		}, {
			type: "end",
			rid: t
		}), {
			color: n,
			amount: 5
		});
	} else if (r.type === "workers") {
		let a = r.owners ?? [], c = (r.n ?? 1) - a.length;
		for (let l of e.players) {
			let u = e.people[l].ready[r.color] - a.filter((e) => e === l).length, d = a.filter((e) => e !== t).length + Number(l !== t);
			u < 1 || i.money < (r.price ?? 0) + d * 2 || (r.intent !== "activate" || l === t || V(e)) && o("useWorker", "worker", () => {
				c > 1 ? s({
					...r,
					owners: a.concat(l)
				}) : (s(), ke(e, {
					...r,
					owners: a.concat(l)
				}, n));
			}, {
				owner: l,
				color: r.color,
				amount: u,
				extra: l === t ? "own" : "rent"
			});
		}
		o("cancel", "action", () => {
			r.back ? s(r.back) : e.tasks.splice(0, 2, {
				type: "action",
				rid: t
			});
		});
	} else if (r.type === "effectChoice") o("useEffect", "cell", () => s({
		...r,
		type: "effect"
	}), {
		owner: t,
		card: r.card,
		x: r.x,
		y: r.y
	}), c();
	else if (r.type === "draw") {
		let a = e.decks[E(r.color, r.level)];
		a.face && a.cards.length > 2 && o("takeVisible", "card", () => {
			let n = a.cards.shift();
			a.face = !1, i.hand.push(n), W(e, "draw", t), s();
		}, { card: a.cards[0] }), o("drawTwo", "deck", () => Pe(e, r, n), {
			color: r.color,
			level: r.level
		});
	} else if (r.type === "drawPick") for (let a of r.items ?? []) o("keep", "card", () => {
		i.hand.push(a.card);
		let o = r.items.filter((e) => e !== a), c = e.decks[a.deck];
		o.length && (c.cards.unshift(o[0].card), c.face = !0, M(n, t, {
			piece: "card",
			card: o[0].card,
			from: `tn:offer:${o[0].card}`,
			to: `tn:deck:${a.deck}`,
			hide: [`tn:deck-face:${o[0].card}`]
		})), W(e, "draw", t), s(...Ne(t, r.cries ?? 0));
	}, { card: a.card });
	else if (r.type === "end") {
		for (let r of i.hand.filter((e) => O(e) || i.hand.length > 4)) o(O(r) ? "wall" : "discard", "card", () => {
			i.hand.splice(i.hand.indexOf(r), 1), O(r) ? (Me(i, r, n), W(e, "wall", t)) : be(e, r, n, {
				rid: t,
				from: `tn:hand:${t}`,
				open: !1
			});
		}, { card: r });
		i.hand.length <= 4 && o("endTurn", "action", () => s({
			type: "advance",
			rid: t
		}));
	} else if (r.type === "recruitEffect") {
		for (let a of b) (!r.color || a === r.color) && e.supply[a] && i.money >= (r.n ?? 0) && o("recruit", "color", () => {
			i.money -= r.n ?? 0, G(i, a, "ready", 1, "tn:supply", n), e.supply[a]--, W(e, "recruit", t, null, 1), s();
		}, {
			color: a,
			amount: r.n
		});
		c();
	} else if (r.type === "chooseDeck") {
		for (let t of b) e.decks[E(t, r.level)].cards.length && o("draw", "deck", () => s({
			...r,
			type: r.intent === "draw" ? "draw" : "take",
			color: t,
			n: 2
		}), {
			color: t,
			level: r.level
		});
		c();
	} else if (r.type === "fightEffect") e.events.forEach((i, a) => {
		i && (r.n === 0 && !i.coins || r.n !== 0 && i.coins > 0) && o("fight", "event", () => {
			Ae(e, t, a, r.n === 2, n), s();
		}, {
			card: `event:${i.card}`,
			amount: i.coins
		});
	}), c();
	else if (r.type === "copy") {
		for (let n of e.players.filter((e) => e !== t)) for (let i of e.people[n].city) {
			let e = T(L(i)), a = `${n}:${i.x},${i.y}`;
			e.kind !== "building" || i.damage || r.color && e.color !== r.color || r.n === 1 && i.workers.length || r.visited?.includes(a) || o("copy", "cell", () => s({
				type: "effect",
				rid: t,
				card: L(i),
				x: r.x,
				y: r.y,
				visited: (r.visited ?? []).concat(a)
			}), {
				card: L(i),
				x: i.x,
				y: i.y,
				owner: n
			});
		}
		c();
	} else if (r.type === "ballista") {
		let i = e.events.flatMap((e, t) => e ? [t] : []);
		for (let a = 1; a < 1 << i.length; a++) {
			let c = i.filter((e, t) => a & 1 << t);
			c.length > (r.n ?? 1) || o("fire", "action", () => {
				let r = c.map((r) => {
					let i = e.events[r];
					return je(e, t, r, n), {
						type: "event",
						rid: t,
						event: i.card,
						n: i.coins,
						targets: D[i.card].effect === "positive" ? [...e.players] : e.players.filter((e) => e !== t)
					};
				});
				s(...r);
			}, { extra: c.map((t) => String(e.events[t].card)).join(",") });
		}
		c();
	} else if (r.type === "seigniory") {
		for (let n of b) o("collectTax", "color", () => {
			let r = 0;
			for (let i of e.players.filter((e) => e !== t)) {
				let t = e.people[i], a = Math.min(t.money, t.city.filter((e) => {
					let t = T(L(e));
					return t.kind === "building" && t.color === n;
				}).length);
				t.money -= a, r += a;
			}
			i.money += r, W(e, "earn", t, null, r), s();
		}, { color: n });
		c();
	} else if (r.type === "bakery") {
		for (let n of ["red", "white"]) o("earn", "color", () => {
			i.money += 2 * i.ready[n], W(e, "earn", t, null, 2 * i.ready[n]), s();
		}, {
			color: n,
			amount: 2 * i.ready[n]
		});
		c();
	} else if (r.type === "follow") {
		for (let n of i.city.filter((n) => ge(i, n) && K(e, t, "white", 1) && (i.ready.white > 0 || V(e)) && T(L(n)).color === r.color && (n.x === r.x || n.y === r.y))) o("activate", "cell", () => s({
			type: "workers",
			rid: t,
			intent: "activate",
			color: "white",
			n: 1,
			x: n.x,
			y: n.y,
			owners: [],
			price: 0,
			back: r
		}), {
			x: n.x,
			y: n.y,
			card: L(n),
			owner: t
		});
		c();
	} else if (r.type === "defend") {
		for (let r of i.hand.filter(O)) o("protect", "card", () => {
			i.hand.splice(i.hand.indexOf(r), 1), Me(i, r, n), W(e, "wall", t), s();
		}, { card: r });
		if (r.catapult && !e.catapultUsed.includes(t)) {
			let n = i.city.find((e) => T(L(e)).effect === "catapult" && e.workers.length > 0 && !e.damage);
			n && o("catapultProtect", "cell", () => {
				e.catapultUsed.push(t), s();
			}, {
				owner: t,
				card: L(n),
				x: n.x,
				y: n.y
			});
		}
		o("accept", "action", () => s({
			...r,
			type: "applyEvent"
		}));
	} else if (r.type === "damage") {
		let i = e.people[r.targets?.[0] ?? t];
		for (let t of i.city.filter((e) => !e.damage && !e.workers.length && T(L(e)).level < 3 && (!r.color || T(L(e)).color === r.color))) V(e) && o("damage", "cell", () => {
			t.damage = !0, M(n, i.rid, {
				piece: "damage",
				from: "tn:supply",
				to: j(i.rid, t.x, t.y),
				hide: [`tn:damage:${i.rid}:${t.x},${t.y}`]
			}), W(e, "damage", i.rid, L(t)), s(...(r.n ?? 1) > 1 ? [{
				...r,
				n: r.n - 1
			}] : []);
		}, {
			owner: i.rid,
			x: t.x,
			y: t.y,
			card: L(t)
		});
		a.length || o("continue", "action", () => s());
	} else if (r.type === "rest") {
		for (let a of b) i.ready[a] && (!r.color || r.color === a) && o("rest", "worker", () => {
			xe(i, a, 1, n), W(e, "rest", t, null, 1), s(...(r.n ?? 1) > 1 ? [{
				...r,
				n: r.n - 1
			}] : []);
		}, {
			color: a,
			owner: t,
			amount: i.ready[a]
		});
		a.length || o("continue", "action", () => s());
	} else if (r.type === "abbeyPick") {
		for (let a of r.items ?? []) o("keep", "card", () => {
			i.hand.push(a.card), W(e, "draw", t), M(n, t, {
				piece: "card",
				card: a.card,
				from: `tn:offer:${a.card}`,
				to: `tn:hand:${t}`,
				hide: [`tn:hand:${a.card}`]
			});
			let o = r.items.filter((e) => e !== a);
			if ((r.n ?? 1) > 1 && o.length) s({
				...r,
				items: o,
				n: r.n - 1
			});
			else {
				for (let r of o) {
					let i = e.decks[r.deck];
					i.cards.unshift(r.card), i.face = !0, M(n, t, {
						piece: "card",
						card: r.card,
						from: `tn:offer:${r.card}`,
						to: `tn:deck:${r.deck}`,
						hide: [`tn:deck-face:${r.card}`]
					});
				}
				s();
			}
		}, { card: a.card });
		a.length || o("continue", "action", () => s());
	}
	return a;
}
function Re(e, t) {
	let n = e.tasks.shift(), r = e.people[n.rid];
	if (n.type === "gain") r.money += n.n ?? 0, W(e, "earn", n.rid, n.card ?? null, n.n ?? 0);
	else if (n.type === "effect") {
		let t = T(n.card), i = t.amount ?? 0;
		if (t.effect === "money") r.money += i, W(e, "earn", n.rid, n.card, i);
		else if (t.effect === "empty" || t.effect === "occupied") {
			let i = t.effect === "empty" ? 9 - r.city.length : r.city.length;
			r.money += i, W(e, "earn", n.rid, n.card, i);
		} else if (t.effect === "draw" || t.effect === "takeTwo") U(e, {
			type: t.target ? t.effect === "draw" ? "draw" : "take" : "chooseDeck",
			rid: n.rid,
			color: t.target,
			level: t.drawLevel,
			n: 2,
			intent: t.effect === "draw" ? "draw" : void 0
		});
		else if (t.effect === "recruit") U(e, {
			type: "recruitEffect",
			rid: n.rid,
			color: t.target,
			n: i
		});
		else if (t.effect === "copy") U(e, {
			...n,
			type: "copy",
			color: t.target,
			n: i
		});
		else if (t.effect === "fight") U(e, {
			type: "fightEffect",
			rid: n.rid,
			n: i
		});
		else if (t.effect === "ballista") U(e, {
			type: "ballista",
			rid: n.rid,
			n: i
		});
		else if (t.effect === "brewery") {
			let i = b.reduce((e, n) => e + (t.level === 1 ? r.ready[n] : r.resting[n]) * t.level, 0);
			r.money += i, W(e, "earn", n.rid, n.card, i);
		} else if (t.effect === "inn") {
			let t = 4 * Math.min(r.ready.yellow, r.ready.red);
			r.money += t, W(e, "earn", n.rid, n.card, t);
		} else if (t.effect === "bakery" || t.effect === "seigniory") U(e, {
			type: t.effect,
			rid: n.rid
		});
		else if (t.effect === "court") {
			let t = Math.max(...e.players.map((t) => e.people[t].money)), i = 0;
			for (let r of e.players.filter((r) => r !== n.rid && e.people[r].money === t)) {
				let t = Math.min(3, e.people[r].money);
				e.people[r].money -= t, i += t;
			}
			r.money += i, W(e, "earn", n.rid, n.card, i);
		} else t.effect === "catapult" ? U(e, ...e.players.map((e) => ({
			type: "damage",
			rid: n.rid,
			targets: [e],
			n: 1
		}))) : t.effect === "abbey" && U(e, {
			type: "abbeyReveal",
			rid: n.rid,
			level: t.level,
			n: 0,
			items: []
		});
	} else if (n.type === "hooks") {
		let t = R(r, n.x, n.y);
		if (!t) return;
		let i = [];
		for (let e of B(r).filter((e) => e !== t && z(e, t))) {
			let t = T(L(e));
			(t.effect === "journeyman" || t.effect === "prior" && n.color === "white" || t.effect === "tax" && n.color === "yellow") && i.push({
				type: "gain",
				rid: n.rid,
				n: t.amount,
				card: L(e)
			}), t.effect === "bishop" && n.color === "white" && i.push({
				type: "readyResting",
				rid: n.rid,
				card: L(e)
			}), (t.effect === "monk" || t.effect === "templar") && n.color === "white" && i.push({
				type: "follow",
				rid: n.rid,
				color: t.target,
				x: e.x,
				y: e.y,
				card: L(e)
			});
		}
		U(e, ...i);
	} else if (n.type === "readyResting") Fe(e, n.rid, !1, t);
	else if (n.type === "crier") {
		e.crierCount++, e.catapultUsed = [];
		let r = [];
		e.events.forEach((i, a) => {
			i && (je(e, n.rid, a, t), r.push({
				type: "event",
				rid: n.rid,
				event: i.card,
				n: i.coins,
				targets: [...e.players],
				catapult: !0
			}));
		}), U(e, ...r), W(e, "crier", n.rid);
	} else if (n.type === "event") {
		let t = D[n.event];
		if (t.effect === "positive") {
			let r = (n) => me(e.people[n])[t.target] + e.people[n].city.filter((e) => T(L(e)).color === t.target).length, i = Math.max(...e.players.map(r));
			for (let t of n.targets ?? e.players) r(t) === i && (e.people[t].money += 2 * (n.n ?? 0));
			W(e, "event", n.rid, `event:${n.event}`, 2 * (n.n ?? 0));
		} else U(e, ...(n.targets ?? e.players).map((e) => ({
			...n,
			type: "defend",
			rid: e
		})));
	} else if (n.type === "applyEvent") {
		let t = D[n.event];
		if (t.effect === "loss") {
			let t = Math.min(r.money, n.n ?? 0);
			r.money -= t, W(e, "loss", n.rid, `event:${n.event}`, t);
		} else (t.effect === "damage" || t.effect === "rest") && U(e, {
			type: t.effect,
			rid: n.rid,
			color: t.target,
			n: n.n,
			event: n.event
		});
	} else if (n.type === "take") {
		let t = e.decks[E(n.color, n.level)];
		if (!t.cards.length || !n.n) return;
		let i = t.cards.shift();
		t.face = !1, i.startsWith("crier:") ? (t.crier = !0, U(e, {
			type: "crier",
			rid: n.rid
		}, n)) : (r.hand.push(i), W(e, "draw", n.rid), n.n > 1 && U(e, {
			...n,
			n: n.n - 1
		}));
	} else if (n.type === "abbeyReveal") {
		if ((n.n ?? 0) >= 3) {
			U(e, {
				...n,
				type: "abbeyPick",
				n: Math.min(2, n.items?.length ?? 0)
			});
			return;
		}
		let r = E(b[n.n ?? 0], n.level), i = e.decks[r];
		if (!i.cards.length) {
			U(e, {
				...n,
				n: (n.n ?? 0) + 1
			});
			return;
		}
		let a = i.cards.shift();
		i.face = !1, a.startsWith("crier:") ? (i.crier = !0, U(e, {
			type: "crier",
			rid: n.rid
		}, n)) : (U(e, {
			...n,
			n: (n.n ?? 0) + 1,
			items: (n.items ?? []).concat({
				deck: r,
				card: a
			})
		}), M(t, n.rid, {
			piece: "card",
			card: a,
			from: `tn:deck:${r}`,
			to: `tn:offer:${a}`,
			hide: [`tn:offer:${a}`]
		}));
	} else if (n.type === "advance") {
		if (e.turnIdx = (e.turnIdx + 1) % e.players.length, e.turnIdx === 0) {
			if (e.lastRound) {
				e.phase = "final", e.tasks = [];
				for (let t of e.players) e.finalTasks[t] = {
					type: "build",
					rid: t
				};
				return;
			}
			e.round++;
			let t = e.players.filter((t) => {
				let n = e.people[t];
				return n.city.length === 9 && n.city.filter((e) => T(L(e)).kind === "prestige").length >= 2;
			}).length;
			(t >= 2 || t >= 1 && e.crierCount >= e.players.length + 1) && (e.lastRound = !0);
		}
		let t = e.players[e.turnIdx];
		U(e, {
			type: "build",
			rid: t
		}, {
			type: "action",
			rid: t
		});
	} else if (n.type === "revealFinal") {
		let r = e.tasks.splice(0), i = [];
		for (let n of e.players) {
			let r = e.finalPlans[n];
			r && (De(e, n, r, t), i.push(...e.tasks.splice(0)));
		}
		e.tasks = i.concat(r), W(e, "reveal", n.rid);
	} else if (n.type === "finalWalls") for (let n of e.players) {
		let r = e.people[n];
		for (let e of r.hand.filter(O)) Me(r, e, t);
		r.hand = r.hand.filter((e) => !O(e));
	}
	else n.type === "score" && (e.scores = ze(e), e.phase = "done", e.tasks = [], W(e, "score", n.rid));
}
function ze(e) {
	let t = [...new Set(e.players.flatMap((t) => e.people[t].city.filter((e) => T(L(e)).kind === "prestige").map((e) => T(L(e)).id)))], n = {};
	for (let r of e.players) {
		let i = e.people[r], a = i.city.map((e) => T(L(e))), o = me(i), s = (e) => a.filter((t) => t.color === e && t.level < 3).length, c = t.map((e) => {
			let t = x[e], n = a.some((t) => t.id === e), r = 0;
			return t.metric === "setsCards" ? r = Math.min(...b.map(s)) : t.metric === "yellowCards" ? r = s("yellow") : t.metric === "whiteCards" ? r = s("white") : t.metric === "redCards" ? r = s("red") : t.metric === "money" ? r = Math.floor(i.money / 4) : t.metric === "yellowWorkers" ? r = o.yellow : t.metric === "whiteWorkers" ? r = o.white : t.metric === "redWorkers" ? r = o.red : t.metric === "characters" ? r = a.filter((e) => e.kind === "character").length : t.metric === "prestige" ? r = a.filter((e) => e.kind === "prestige").length : t.metric === "setsWorkers" ? r = Math.min(...b.map((e) => o[e])) : t.metric === "civilBuildings" ? r = a.filter((e) => e.kind === "building" && e.color !== "red").length : t.metric === "walls" && (r = i.walls.length), {
				card: e,
				owner: n,
				amount: Math.min(12, r * (n ? t.owner ?? 0 : t.guest ?? 0))
			};
		}), l = i.city.flatMap((e) => e.stack).reduce((e, t) => e + T(t).points, 0), u = i.walls.length;
		n[r] = {
			printed: l,
			walls: u,
			prestige: c,
			total: l + u + c.reduce((e, t) => e + t.amount, 0)
		};
	}
	return n;
}
function Be(e, t, n) {
	let r = { code: "games.tournay.invalid" };
	if (e.phase === "done") return r;
	let i = structuredClone(e), a = [];
	if (t.type === "tick") {
		if (n.by !== "$engine" || i.phase === "final" || !i.tasks[0] || !Ie.has(i.tasks[0].type)) return r;
		Re(i, a);
	} else {
		if (!i.players.includes(n.by)) return r;
		let e = Le(i, n.by, a).find((e) => e.view.id === t.id);
		if (!e) return r;
		e.run();
	}
	i.serial++;
	let o = i.last;
	if (o?.serial === i.serial) {
		let t = i.people[o.rid], n = o.card ? t.city.find((e) => L(e) === o.card) : void 0;
		if (o.kind === "build" && n) a.push({
			kind: "build",
			rid: t.rid,
			data: {
				card: o.card,
				x: n.x,
				y: n.y
			},
			with: a.length > 0
		});
		else if (o.kind === "draw" && !a.some((e) => e.kind === "move" && e.data?.to === `tn:hand:${t.rid}`)) {
			let n = t.hand[t.hand.length - 1], r = T(n), i = H(e, t.rid)?.type === "drawPick" ? `tn:offer:${n}` : `tn:deck:${E(r.color, r.level)}`;
			a.push({
				kind: "draw",
				rid: t.rid,
				data: { deck: E(r.color, r.level) },
				for: [t.rid],
				secret: {
					card: n,
					from: i
				},
				with: a.length > 0
			});
		} else if (o.kind === "reveal") for (let e of i.players) {
			let t = i.finalPlans[e];
			t && a.push({
				kind: "build",
				rid: e,
				data: {
					card: t.card,
					x: t.x,
					y: t.y
				},
				with: a.length > 0
			});
		}
		else [
			"earn",
			"loss",
			"event",
			"crier",
			"score"
		].includes(o.kind) && a.push({
			kind: "change",
			rid: o.rid,
			data: { ...o },
			with: a.length > 0
		});
	}
	return {
		state: i,
		fx: a
	};
}
function Ve(e, t) {
	let n = H(e, t), r = e.phase === "final" ? null : e.tasks[0]?.rid ?? null, i = e.tasks[0];
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			decision: r,
			prompt: e.phase === "final" ? "final" : i?.type ?? "done",
			round: e.round,
			crierCount: e.crierCount,
			lastRound: e.lastRound,
			config: e.config,
			players: e.players.map((t) => {
				let n = e.people[t];
				return {
					rid: t,
					money: n.money,
					ready: n.ready,
					resting: n.resting,
					total: me(n),
					city: n.city,
					handCount: n.hand.length,
					walls: n.walls.length,
					locked: Object.hasOwn(e.finalPlans, t)
				};
			}),
			decks: Object.entries(e.decks).map(([e, t]) => ({
				key: e,
				color: t.color,
				level: t.level,
				count: t.cards.length,
				face: t.face ? t.cards[0] ?? null : null,
				crier: t.crier
			})),
			events: e.events,
			eventCount: e.eventDeck.length,
			supply: e.supply,
			last: e.last,
			scores: e.scores,
			revealed: (e.tasks.find((e) => e.type === "abbeyReveal" || e.type === "abbeyPick")?.items ?? []).map((e) => e.card),
			event: i && [
				"defend",
				"applyEvent",
				"damage",
				"rest"
			].includes(i.type) ? i.event ?? null : null
		},
		private: {
			hand: e.people[t]?.hand ?? [],
			choices: Le(e, t).map((e) => e.view),
			prompt: n?.rid === t ? n.type : "",
			selected: n?.rid === t && ["payment", "place"].includes(n.type) ? n.card ?? null : null
		}
	};
}
var He = {
	meta: se,
	saveCompatibility: { version: "1" },
	schemas: {
		action: le,
		config: P,
		publicView: fe,
		privateView: pe
	},
	setup: ye,
	reduce: Be,
	viewFor: Ve,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => e.scores[n].total - e.scores[t].total), n = e.scores[t[0]].total;
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((t) => e.scores[t].total === n),
			scores: Object.fromEntries(e.players.map((t) => [t, e.scores[t].total]))
		};
	},
	nextTickIn: (e) => e.phase !== "final" && e.tasks[0] && Ie.has(e.tasks[0].type) ? 420 : null
}, Ue = {
	"y1-architect": ["建筑师", "Architect"],
	"y1-quarry": ["采石场", "Quarry"],
	"y1-journeyman": ["工匠", "Journeyman"],
	"y1-councillor": ["参事", "Councillor"],
	"y1-farm": ["农庄", "Farmhouse"],
	"y1-barn": ["粮仓", "Barn"],
	"y1-residence": ["住宅", "Residence"],
	"y1-market": ["市场", "Market"],
	"y1-port": ["港口", "Port"],
	"y1-brewery": ["酿酒坊", "Brewery"],
	"y1-senator": ["议员", "Senator"],
	"y1-inn": ["旅店", "Inn"],
	"w1-prior": ["修道院长", "Prior"],
	"w1-library-draw": ["图书馆", "Library"],
	"w1-library-two": ["图书馆", "Library"],
	"w1-bishopric": ["主教府", "Bishopric"],
	"w1-bishop": ["主教", "Bishop"],
	"w1-hospital": ["医院", "Hospital"],
	"w1-monastery": ["修道院", "Monastery"],
	"w1-bridge": ["桥梁", "Bridge"],
	"w1-priest": ["神父", "Priest"],
	"w1-abbey": ["大修道院", "Abbey"],
	"w1-monk": ["修士", "Monk"],
	"w1-templar": ["圣殿骑士", "Templar"],
	"r1-arsenal": ["军械库", "Arsenal"],
	"r1-lawyer": ["司法官", "Lawyer"],
	"r1-ballista": ["弩炮", "Ballista"],
	"r1-knight": ["骑士", "Knight"],
	"r1-barracks": ["兵营", "Barracks"],
	"r1-fort": ["要塞", "Fort"],
	"r1-fort-marked": ["要塞", "Fort"],
	"r1-tax": ["税吏", "Tax Collector"],
	"r1-road": ["道路", "Road"],
	"r1-pair-knight": ["骑士", "Knight"],
	"y2-architect": ["建筑师", "Architect"],
	"y2-quarry": ["采石场", "Quarry"],
	"y2-journeyman": ["工匠", "Journeyman"],
	"y2-councillor": ["参事", "Councillor"],
	"y2-toll": ["收费站", "Tollbooth"],
	"y2-barn": ["粮仓", "Barn"],
	"y2-residence": ["住宅", "Residence"],
	"y2-market": ["市场", "Market"],
	"y2-port": ["港口", "Port"],
	"y2-brewery": ["酿酒坊", "Brewery"],
	"y2-senator": ["议员", "Senator"],
	"y2-bakery": ["面包坊", "Bakery"],
	"w2-prior": ["修道院长", "Prior"],
	"w2-library-draw": ["图书馆", "Library"],
	"w2-library-two": ["图书馆", "Library"],
	"w2-bishopric": ["主教府", "Bishopric"],
	"w2-augustinian": ["奥古斯丁会士", "Augustinian"],
	"w2-monastery-white": ["修道院", "Monastery"],
	"w2-monastery": ["修道院", "Monastery"],
	"w2-bridge": ["桥梁", "Bridge"],
	"w2-priest": ["神父", "Priest"],
	"w2-abbey": ["大修道院", "Abbey"],
	"w2-monk": ["修士", "Monk"],
	"w2-templar": ["圣殿骑士", "Templar"],
	"r2-arsenal": ["军械库", "Arsenal"],
	"r2-lawyer": ["司法官", "Lawyer"],
	"r2-ballista": ["弩炮", "Ballista"],
	"r2-bastion": ["堡垒", "Bastion"],
	"r2-barracks": ["兵营", "Barracks"],
	"r2-fort": ["要塞", "Fort"],
	"r2-fort-marked": ["要塞", "Fort"],
	"r2-tax": ["税吏", "Tax Collector"],
	"r2-road": ["道路", "Road"],
	"r2-pair-knight": ["骑士", "Knight"],
	"r1-seigniory": ["领主庄园", "Seigniory"],
	"r1-catapult": ["投石机", "Catapult"],
	"r2-mercenary": ["雇佣兵", "Mercenary"],
	"r2-court": ["法庭", "Courthouse"],
	"y3-belfry": ["钟楼", "Belfry"],
	"y3-cloth": ["布业会馆", "Cloth Hall"],
	"y3-mint": ["铸币厂", "Mint"],
	"y3-hall": ["市政厅", "City Hall"],
	"y3-six": ["六塔楼", "Tour des Six"],
	"w3-cathedral": ["大教堂", "Cathedral"],
	"w3-madeleine": ["玛德莱娜教堂", "La Madeleine"],
	"w3-brice": ["圣布里斯教堂", "Saint-Brice"],
	"w3-jacques": ["圣雅克教堂", "Saint-Jacques"],
	"w3-nicolas": ["圣尼古拉教堂", "Saint-Nicolas"],
	"w3-quentin": ["圣康坦教堂", "Saint-Quentin"],
	"r3-trous": ["三孔桥", "Pont des Trous"],
	"r3-vigne": ["葡萄园城门", "Porte de la Vigne"],
	"r3-georges": ["圣乔治塔", "Tour Saint-Georges"],
	"r3-arras": ["阿拉斯塔", "Tour d’Arras"],
	"r3-henry": ["亨利八世塔", "Tour Henry VIII"]
}, We = [
	["诺曼人入侵", "Normans Attack"],
	["布汶战役", "Battle of Bouvines"],
	["卡塞尔战役", "Battle of Cassel"],
	["库特赖战役", "Battle of Courtrai"],
	["强盗", "Brigands"],
	["十字军东征", "Crusade"],
	["绝罚", "Excommunication"],
	["盛大集会", "Great Gathering"],
	["大瘟疫", "Great Plague"],
	["征服者威廉", "William the Conqueror"],
	["异端", "Heresy"],
	["劫掠", "Marauding"],
	["游行", "Procession"],
	["干旱", "Drought"],
	["国王来访", "King’s Visit"]
], Ge = {
	name: "图尔奈",
	desc: "重建中世纪城市，安排三类市民，经营行列相连的建筑与人物。",
	rules: "目标：\n经营不超过 3 行、3 列的城市，在结束时获得最多威望。黄色代表市民，白色代表教士，红色代表军人。\n准备：\n每人获得 6 枚钱币及每色 2 名可用市民；公共供给每色 3 名。按颜色和等级组成 9 堆牌，每堆包含 9 张活动牌及 1 张传令官。随机翻开 3 张事件，最初没有硬币。\n高级招募规则改为每人 9 枚钱币、每色 1 人，公共供给每色为玩家人数加 3；增加花费 5 枚钱币并使用 1 名同色市民招募该色市民的行动。扩展默认关闭，可用 18 张盒内扩展替换指定牌，或将每堆的 3 张指定牌与 3 张扩展混合，随机保留 3 张。\n回合流程：\n回合开始可以支付费用建造一张手牌，然后必须完成一个市民行动。新位置须与已有牌正交相邻，城市的宽、高均不超过 3 格。同色叠牌保留底牌，底牌只计印刷分；异色替换会把整叠旧牌放回各自牌堆底。被覆盖或替换位置上的本人市民变为休息，灰色市民和伤害标记移除。不能在城市中保留两张同名威望建筑。\n· 抽牌：使用同色 1、2、3 名市民，分别抽对应颜色的 I、II、III 级牌。可以拿取牌堆顶部的明牌；也可以将该明牌移到牌堆底部，再查看顶部两张背面朝上的牌，选择一张保留，另一张正面朝上放回牌堆顶部。只剩两张时必须从这两张选择；只剩一张时直接拿取。传令官不进入手牌，额外补抽。\n· 激活建筑：使用 1 名同色市民，放到本人未受损、尚有容量的建筑上，执行牌面效果，再执行同一行或列的人物效果。人物不需要放市民。神父使符合条件的建筑可分两次行动各激活一次。\n· 对抗事件：只可选择有硬币的事件。使玩家失去钱的事件须使用 2 名指定颜色市民；其他事件须使用 1 名指定颜色市民，并支付事件硬币数加 1 枚钱币。获得事件作为手中城墙，事件上的钱回到供给，补入新事件且没有硬币。\n· 赚钱：只使用本人同色的 1 名或更多可用市民，每使用一名市民，获得2枚钱币；拥有雇佣兵时，每使用一名红色市民，改为获得3枚钱币。\n· 集合：使本人的全部市民恢复可用，移除本人城市的伤害与灰色市民。即使还有可用市民也能集合。\n除赚钱外，可以使用其他玩家的可用市民，每使用一名市民，须向其主人支付2枚钱币。租用的市民仍归原主人所有，并在原主人处休息；激活建筑时另放灰色市民标记。多个来源可以混合。\n回合结束最多保留 4 张手牌，城墙牌也计入。超额的活动牌放回各自牌堆底；手中城墙可以建成城墙，每张终局计 1 分。\n事件与人物：\n每堆传令官只触发一次。翻到传令官后，每张事件增加 1 枚钱币，上限为牌上的圆圈数；从左到右执行，每有 1 枚钱币执行一次该事件。可以从手中建造一张城墙，抵御一整张事件的全部强度。已建城墙不能再次防御。占有市民的投石机可在每次传令官出现时免费抵御一张事件。\n正面事件比较对应颜色的市民总数与城市可见牌数之和，领先者每次获得 2 枚钱币，并列均获益。损失钱不会使钱变为负数；缺少对应可用市民或无可损坏牌时，无法执行的部分不产生效果。\n人物仅影响同一行或列，除非牌面说明是常驻能力。受损人物暂停效果。复制对手建筑只复制建筑效果，不使用对手的人物；本人原激活位置的人物仍生效。建筑和人物的具体效果可点击牌面查看。\n结束与计分：\n在起始玩家回合开始时，若至少两人拥有 9 个占用位置且有至少 2 张可见威望建筑，或至少一人满足此条件且传令官数达到玩家人数加 1，进入最后一轮，每人再进行一整回合。\n随后每人秘密选择最后建造的一张牌及位置，也可以放弃。全员锁定后同时揭示，支付费用并执行相关人物效果，最后建造所有剩余城墙。\n每种可见威望建筑只触发一次全员计分：拥有该名称可见建筑的玩家采用拥有者倍率，其他玩家采用访客倍率；每种每人最多 12 分。再加入城市全部牌（包括被覆盖牌）的印刷分及已建城墙分。总分最高者获胜，同分并列。大教堂费用 20 枚钱币，自带 8 分；以牺牲市民建造的威望建筑须交回对应颜色的本人市民，可来自任何位置。牺牲卡牌费用可从本人手牌或城市任一层支付，允许留下空洞。",
	invalid: "当前无法这样行动，请按新的可用选项操作。",
	ready: "可用",
	resting: "休息",
	money: "钱",
	walls: "城墙",
	hand: "手牌",
	supply: "公共供给",
	city: "城市",
	cards: "牌",
	round: "轮",
	crier: "传令官",
	finalRound: "最后一轮",
	yellow: "市民",
	white: "教士",
	red: "军人",
	gray: "租用市民",
	building: "建筑",
	character: "人物",
	prestige: "威望建筑",
	event: "事件",
	owner: "拥有者",
	guest: "访客",
	printed: "印刷威望",
	prestigeScore: "威望建筑",
	total: "总分",
	scoreTitle: "城市的荣光",
	review: "回看城市",
	showScores: "查看计分",
	again: "再来一局",
	lobby: "返回大厅",
	waitHost: "等待主机决定",
	close: "关闭",
	details: "卡牌详情",
	covered: "被覆盖牌",
	occupied: "已占用",
	damaged: "受损",
	emptyCity: "建造你的第一座建筑",
	noHand: "手中暂无卡牌",
	locked: "已锁定",
	wait: "等待其他玩家",
	advanced: "高级招募",
	advancedHint: "以较少市民和较多钱开始，可花费 5 钱招募。",
	expansion: "盒内扩展",
	off: "基础牌",
	replace: "替换指定牌",
	mix: "随机混合",
	prompts: {
		effectChoice: "可以执行本次激活建筑的效果",
		build: "可以建造一张手牌",
		payment: "选择要交回的卡牌或市民",
		place: "选择城市中的建造位置",
		action: "选择一个市民行动",
		workers: "选择要使用的可用市民",
		draw: "选择如何抽牌",
		drawPick: "选择要保留的牌",
		end: "整理手牌并结束回合",
		recruitEffect: "选择要招募的市民",
		chooseDeck: "选择抽牌的颜色",
		fightEffect: "选择要对抗的事件",
		copy: "选择要复制的对手建筑",
		ballista: "选择要触发的事件",
		seigniory: "选择收税的建筑颜色",
		bakery: "选择产生收入的市民颜色",
		follow: "可以使用教士追加激活建筑",
		defend: "选择是否使用城墙抵御事件",
		damage: "选择一张未占用的活动牌承受伤害",
		rest: "选择一名可用市民休息",
		abbeyPick: "保留其中两张牌",
		final: "秘密选择最后建造的牌",
		settle: "正在结算",
		done: "对局结束"
	},
	actions: {
		useEffect: "执行建筑效果",
		skip: "放弃效果",
		lockNone: "不再建造并锁定",
		skipBuild: "跳过建造",
		build: "建造",
		sacrifice: "交回供给",
		place: "在此建造",
		cancel: "取消",
		draw: "抽牌",
		activate: "激活",
		fight: "对抗",
		earn: "赚钱",
		gather: "集合市民",
		recruit: "招募",
		useWorker: "使用",
		takeVisible: "拿取明牌",
		drawTwo: "查看暗牌",
		keep: "保留",
		wall: "建造城墙",
		discard: "放回牌堆",
		endTurn: "结束回合",
		copy: "复制",
		fire: "触发所选事件",
		collectTax: "向该色建筑收税",
		protect: "建造城墙并抵御",
		catapultProtect: "用投石机抵御",
		accept: "承受事件",
		damage: "放置伤害标记",
		continue: "继续",
		rest: "使其休息"
	},
	own: "免费",
	rent: "向主人支付 2 钱",
	select: "选择",
	cost: "建造费用",
	points: "印刷分",
	take: "保留",
	inspect: "查看详情"
}, Ke = {
	name: "Tournay",
	desc: "Rebuild a medieval city with three classes of citizens and a network of buildings and characters.",
	rules: "Goal:\nEarn the most prestige in a district no wider or taller than three spaces. Yellow represents civilians, white clergy, and red soldiers.\nSetup:\nEach player starts with 6 deniers and two ready citizens of each colour. The reserve has three of each colour. Make nine decks by colour and level, each containing nine activity cards and one town crier. Reveal three events with no coins.\nWith advanced recruitment, start with 9 deniers and one citizen of each colour; the reserve has the player count plus three of each colour. An extra action uses one citizen and 5 deniers to recruit a citizen of that colour. The 18-card expansion is optional: replace the three marked cards in each relevant deck, or shuffle those three with the three expansion cards and retain three at random.\nYour turn:\nYou may first build one card from your hand, paying its cost. Then perform one citizen action. A new space must share an edge with an existing card. The district may never exceed three rows or three columns. Stacking the same colour preserves covered cards for their printed points; replacing with a different colour returns the entire old stack to the appropriate deck bottoms. Citizens on that space rest, and damage and grey markers are removed. You cannot keep two prestige buildings of the same name in your district.\n· Draw: use one, two, or three citizens of the same colour to draw from level I, II, or III in that colour. Take the visible top card, or put it underneath the deck and inspect two hidden cards, keeping one and leaving the other face up. With two cards left, inspect both; with one left, take it. Replace any town crier drawn with another card.\n· Activate: place one matching-colour citizen on one of your undamaged buildings with available capacity. Resolve its effect before the characters in the same row or column. Characters do not receive citizens. A qualifying Priest lets a building be activated twice, in separate actions.\n· Fight: choose an event with at least one coin. Money-loss events require two citizens of the printed colour. Other events require one matching citizen and coins equal to the event’s coins plus one. Keep the event as a rampart in hand, return its coins to the reserve, and replace it with a new event with no coins.\n· Earn: use one or more of your own ready citizens of a single colour for 2 deniers each. A Mercenary makes red citizens earn 3 each.\n· Gather: ready all your citizens and remove your district’s damage and grey markers. This is allowed even if you still have ready citizens.\nExcept when earning money, you may hire opponents’ ready citizens for 2 deniers each, paid to their owners. They rest at their owners’ plazas; a hired citizen activating your building is represented by a grey marker. You may combine sources.\nAt turn end, keep at most four cards, including ramparts. Return excess activity cards to their deck bottoms. You may build ramparts from your hand for one final point each.\nEvents and characters:\nEach deck’s town crier triggers only once. Add one coin to each event, up to its printed circles, then resolve events left to right. Each coin repeats that event’s effect once. Build one rampart from hand to resist the entire strength of one event. A built rampart cannot defend again. An occupied Catapult can resist one event for free per town crier.\nPositive events compare all owned citizens plus visible district cards of the relevant colour; the leader gains 2 deniers per application, including tied leaders. Money cannot fall below zero. Effects that have no eligible citizen or card do nothing.\nCharacters affect their row and column unless their card grants a permanent ability. Damaged characters have no effect. Copying an opponent’s building copies its effect without their characters; your own characters still apply at the original activation location. Inspect a card for its specific effect.\nEnding and scoring:\nAt the start of the first player’s turn, trigger the final round if at least two players have nine occupied spaces and at least two visible prestige buildings, or if at least one player meets that condition and the crier count is at least the player count plus one. Each player takes one complete final turn.\nThen each secretly chooses one last card and placement, or passes. Once everyone locks in, reveal all cards together, pay their costs, and resolve placement characters. Finally build all remaining ramparts.\nEach distinct visible prestige building scores once for everyone. Players with that visible building use its owner multiplier; others use its visitor multiplier. Each type is capped at 12 points per player. Add the printed points of every district card, including covered cards, and one point per built rampart. Highest total wins; ties remain tied. The Cathedral costs 20 deniers and has 8 printed points. Prestige costs that sacrifice a citizen require your own matching-colour citizen from any location. A sacrificed activity card may come from your hand or any layer of your district, possibly leaving a hole.",
	invalid: "That action is unavailable. Please use the current choices.",
	ready: "Ready",
	resting: "Resting",
	money: "Deniers",
	walls: "Ramparts",
	hand: "Hand",
	supply: "Reserve",
	city: "District",
	cards: "Cards",
	round: "Round",
	crier: "Town criers",
	finalRound: "Final round",
	yellow: "Civilians",
	white: "Clergy",
	red: "Soldiers",
	gray: "Hired citizen",
	building: "Building",
	character: "Character",
	prestige: "Prestige building",
	event: "Event",
	owner: "Owner",
	guest: "Visitor",
	printed: "Printed prestige",
	prestigeScore: "Prestige buildings",
	total: "Total",
	scoreTitle: "Glory of the city",
	review: "Review districts",
	showScores: "Show scoring",
	again: "Play again",
	lobby: "Back to lobby",
	waitHost: "Waiting for the host",
	close: "Close",
	details: "Card details",
	covered: "Covered cards",
	occupied: "Occupied",
	damaged: "Damaged",
	emptyCity: "Build your first building",
	noHand: "No cards in hand",
	locked: "Locked in",
	wait: "Waiting for other players",
	advanced: "Advanced recruitment",
	advancedHint: "Start with fewer citizens and more money; recruit for 5 deniers.",
	expansion: "Box expansion",
	off: "Base cards",
	replace: "Replace marked cards",
	mix: "Random mix",
	prompts: {
		effectChoice: "You may resolve this building’s effect",
		build: "You may build one card from hand",
		payment: "Choose a card or citizen to return",
		place: "Choose where to build in your district",
		action: "Choose one citizen action",
		workers: "Choose ready citizens to use",
		draw: "Choose how to draw",
		drawPick: "Choose a card to keep",
		end: "Manage your hand and end your turn",
		recruitEffect: "Choose a citizen to recruit",
		chooseDeck: "Choose a deck colour",
		fightEffect: "Choose an event to fight",
		copy: "Choose an opponent’s building to copy",
		ballista: "Choose events to trigger",
		seigniory: "Choose the building colour to tax",
		bakery: "Choose the citizen colour for income",
		follow: "You may use clergy to activate another building",
		defend: "Choose whether to defend with a rampart",
		damage: "Choose a free activity card to damage",
		rest: "Choose a ready citizen to rest",
		abbeyPick: "Keep two of these cards",
		final: "Secretly choose your last building",
		settle: "Resolving",
		done: "Game over"
	},
	actions: {
		useEffect: "Resolve building effect",
		skip: "Skip effect",
		lockNone: "Build nothing and lock in",
		skipBuild: "Skip building",
		build: "Build",
		sacrifice: "Return to reserve",
		place: "Build here",
		cancel: "Cancel",
		draw: "Draw",
		activate: "Activate",
		fight: "Fight",
		earn: "Earn",
		gather: "Gather citizens",
		recruit: "Recruit",
		useWorker: "Use",
		takeVisible: "Take visible card",
		drawTwo: "Inspect hidden cards",
		keep: "Keep",
		wall: "Build rampart",
		discard: "Return to deck",
		endTurn: "End turn",
		copy: "Copy",
		fire: "Trigger chosen events",
		collectTax: "Tax this building colour",
		protect: "Build rampart to resist",
		catapultProtect: "Resist with Catapult",
		accept: "Suffer event",
		damage: "Place damage marker",
		continue: "Continue",
		rest: "Rest citizen"
	},
	own: "Free",
	rent: "Pay owner 2 deniers",
	select: "Choose",
	cost: "Build cost",
	points: "Printed points",
	take: "Keep",
	inspect: "Inspect"
}, q = (e) => e === "en" ? Ke : Ge, J = (e, t) => O(e) ? We[oe(e)][+(t === "en")] : Ue[T(e).id][+(t === "en")];
function qe(e, t) {
	let n = q(t), r = e.amount ?? 0, i = e.target ? n[e.target] : t === "en" ? "any colour" : "任意颜色", a = [
		"",
		"I",
		"II",
		"III"
	][e.drawLevel ?? 0], o = t === "en";
	if (e.kind === "prestige") {
		let t = {
			setsCards: o ? "set of visible yellow, white and red level I–II cards" : "组可见的黄、白、红 I–II 级牌",
			yellowCards: o ? "visible yellow level I–II card" : "张可见黄色 I–II 级牌",
			whiteCards: o ? "visible white level I–II card" : "张可见白色 I–II 级牌",
			redCards: o ? "visible red level I–II card" : "张可见红色 I–II 级牌",
			money: o ? "4 deniers" : "组 4 钱",
			yellowWorkers: o ? "owned civilian" : "名本人市民",
			whiteWorkers: o ? "owned clergy" : "名本人教士",
			redWorkers: o ? "owned soldier" : "名本人军人",
			characters: o ? "visible character" : "张可见人物",
			prestige: o ? "visible prestige building" : "张可见威望建筑",
			setsWorkers: o ? "set of owned yellow, white and red citizens" : "组本人黄、白、红市民",
			civilBuildings: o ? "visible yellow or white level I–II building" : "张可见黄色或白色 I–II 级建筑",
			walls: o ? "built rampart" : "张已建城墙",
			cathedral: ""
		};
		return e.metric === "cathedral" ? o ? "8 printed prestige points." : "自带 8 点印刷威望。" : o ? `Per ${t[e.metric]}: owner ${e.owner}, visitor ${e.guest}. Maximum 12 per player.` : `每${t[e.metric]}：拥有者 ${e.owner} 分，访客 ${e.guest} 分；每人最多 12 分。`;
	}
	return (o ? {
		money: `Gain ${r} deniers.`,
		empty: "Gain 1 denier per empty district space.",
		occupied: "Gain 1 denier per occupied district space.",
		draw: `Draw from ${i}, level ${a}, using the normal draw rule.`,
		takeTwo: `Take both top cards from ${i}, level ${a}. Take any visible card first.`,
		recruit: `Pay ${r} deniers to recruit one ready ${i} citizen from the reserve.`,
		copy: `Copy an opponent’s ${i} building${r === 1 ? " that has no citizens" : ", occupied or free"}. Damaged buildings cannot be copied.`,
		ballista: `Add a coin to ${r === 2 ? "one or two" : "one to three"} different events and trigger them against opponents. Positive events also include you.`,
		fight: `Take an event with ${r === 0 ? "no coins" : "at least one coin"} as a rampart.${r === 2 ? " Also gain its coins." : ""} No extra citizens or money required.`,
		brewery: e.level === 1 ? "Gain 1 denier per ready citizen at your plaza." : "Gain 2 deniers per citizen resting beside your plaza.",
		inn: "Gain 4 deniers per pair of ready civilian and soldier at your plaza.",
		bakery: "Gain 2 deniers per ready soldier, or per ready clergy, at your plaza.",
		abbey: `Reveal the top card of each colour at level ${e.level === 1 ? "I" : "II"}; keep two. Resolve any town crier before replacing it.`,
		seigniory: "Choose a colour. Each other player pays you 1 denier per building of that colour in their district, as far as able.",
		catapult: "Damage one free level I–II card of your choice in each district, including yours. While occupied, resist one event per town crier for free.",
		court: "Compare every player’s wealth, including yours. Each other player tied for richest pays you up to 3 deniers.",
		architect: `Gain ${r} denier(s) when placing a building or prestige building in this row or column.`,
		councillor: `Gain ${r} deniers when placing a character in this row or column.`,
		journeyman: `Gain ${r} denier(s) when activating a building in this row or column.`,
		prior: `Gain ${r} deniers when activating a white building in this row or column.`,
		bishop: "After activating a white building in this row or column, ready citizens resting beside your plaza. Citizens on buildings stay there.",
		priest: `Buildings ${e.level === 1 ? "of white colour " : ""}in this row or column may hold two citizens, activated in separate actions.`,
		lawyer: `Gain ${r} deniers when placing a yellow or white building in this row or column.`,
		knight: "After placing a prestige building in this row or column, take a funded event and its coins, without paying.",
		tax: `Gain ${r} denier(s) when activating a yellow building in this row or column.`,
		augustinian: "Gain 2 deniers when placing a white building or character in this row or column.",
		senator: `Gain ${r} deniers whenever you take the Gather action.`,
		monk: "After activating a white building in this row or column, use a second white citizen to activate a yellow building in this row or column.",
		templar: "After activating a white building in this row or column, use a second white citizen to activate a red building in this row or column.",
		mercenary: "Your soldiers earn 3 deniers each with the Earn action.",
		pairKnight: `Whenever a 2nd, 4th or 6th red or grey citizen is placed in this row or column, take a funded event${e.level === 2 ? " and its coins" : ""}, without paying.`
	} : {
		money: `获得 ${r} 钱。`,
		empty: "本人城市每个空位获得 1 钱。",
		occupied: "本人城市每个占用位置获得 1 钱。",
		draw: `按通常抽牌规则，抽取${i}的 ${a} 级牌。`,
		takeTwo: `拿取${i} ${a} 级牌堆的顶层两张牌，须先拿明牌。`,
		recruit: `支付 ${r} 钱，从公共供给招募一名可用的${i}。`,
		copy: `复制其他玩家的一座${i}建筑${r === 1 ? "，该建筑必须未被市民占用" : "，可以选择已占用建筑"}；不能复制受损建筑。`,
		ballista: `给 ${r === 2 ? "1 至 2" : "1 至 3"} 张不同事件各加 1 钱并触发，使对手承受其全部强度。正面事件也包括本人。`,
		fight: `无须另付市民或钱，将一张${r === 0 ? "没有硬币" : "至少有 1 钱"}的事件收入手中作为城墙。${r === 2 ? "同时获得其全部硬币。" : ""}`,
		brewery: e.level === 1 ? "本人广场上每名可用市民获得 1 钱。" : "本人广场旁每名休息市民获得 2 钱。",
		inn: "本人广场上每对可用的黄色市民与红色军人获得 4 钱。",
		bakery: "选择本人广场上每名可用军人或每名可用教士获得 2 钱。",
		abbey: `翻开三色 ${e.level === 1 ? "I" : "II"} 级牌堆的顶层牌，保留其中两张。遇到传令官须先结算，再补翻。`,
		seigniory: "选择一种颜色，其他玩家为其城市中每座该色建筑向你支付 1 钱，不足时全部支付。",
		catapult: "为包括自己在内的每位玩家选择一张未占用的 I–II 级活动牌，放上伤害标记。被市民占用时，每次传令官出现可免费抵御一张事件。",
		court: "比较包括自己在内的所有玩家财富。处于最富有位置的其他玩家各向你支付至多 3 钱，并列者均支付。",
		architect: `在同一行或列建造建筑或威望建筑时，获得 ${r} 钱。`,
		councillor: `在同一行或列放置人物时，获得 ${r} 钱。`,
		journeyman: `激活同一行或列的建筑时，获得 ${r} 钱。`,
		prior: `激活同一行或列的白色建筑时，获得 ${r} 钱。`,
		bishop: "激活同一行或列的白色建筑后，广场旁的休息市民恢复可用；建筑上的市民保持原位。",
		priest: `同一行或列的${e.level === 1 ? "白色" : ""}建筑可以容纳两名市民，须分两次行动激活。`,
		lawyer: `在同一行或列建造黄色或白色建筑时，获得 ${r} 钱。`,
		knight: "在同一行或列建造威望建筑后，无须另付费用，将一张有硬币的事件收入手中，并获得其硬币。",
		tax: `激活同一行或列的黄色建筑时，获得 ${r} 钱。`,
		augustinian: "在同一行或列放置白色建筑或人物时，获得 2 钱。",
		senator: `进行集合行动时，获得 ${r} 钱。`,
		monk: "激活同一行或列的白色建筑后，可以再使用一名教士，激活本人物同一行或列的黄色建筑。",
		templar: "激活同一行或列的白色建筑后，可以再使用一名教士，激活本人物同一行或列的红色建筑。",
		mercenary: "进行赚钱行动时，每名军人获得 3 钱。",
		pairKnight: `在同一行或列放置第 2、4、6 名红色或灰色市民时，无须另付费用，将一张有硬币的事件收入手中${e.level === 2 ? "，并获得其硬币" : ""}。`
	})[e.effect ?? ""] ?? "";
}
function Je(e, t) {
	let n = D[e], r = q(t), i = n.target ? r[n.target] : t === "en" ? "any colour" : "任意颜色", a = t === "en";
	return n.effect === "loss" ? a ? "Each player loses 1 denier per coin." : "每有 1 钱，每位玩家失去 1 钱。" : n.effect === "damage" ? a ? `Per coin, damage one free level I–II ${i} card in each district.` : `每有 1 钱，每位玩家选择一张未占用的${i} I–II 级活动牌承受伤害。` : n.effect === "rest" ? a ? `Per coin, each player rests one ready ${i} citizen.` : `每有 1 钱，每位玩家使一名可用的${i}休息。` : a ? `Most ${r[n.target]} plus visible cards of that colour: gain 2 deniers per coin. Ties all benefit.` : `${r[n.target]}总数与该色可见牌之和最多的玩家，每有 1 钱获得 2 钱；并列均获益。`;
}
//#endregion
//#region src/games/tournay/card.tsx
function Y({ color: e, resting: t = !1 }) {
	return /* @__PURE__ */ _("img", {
		className: `tn-citizen${t ? " tn-resting" : ""}`,
		src: `games/tournay/citizen-${e}.svg`,
		alt: ""
	});
}
function X() {
	return /* @__PURE__ */ _("svg", {
		className: "tn-target-outline",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ _("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "6",
			pathLength: "100",
			fill: "none",
			stroke: "var(--color-info-ink)",
			strokeWidth: "2",
			strokeDasharray: "4 3",
			children: /* @__PURE__ */ _("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-14",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
function Z({ id: e, locale: t, compact: n = !1, selected: r = !1, anchorName: i }) {
	let { ref: a, hidden: o } = s(i ?? null), c = q(t);
	if (O(e)) {
		let i = D[oe(e)];
		return /* @__PURE__ */ v("div", {
			ref: a,
			style: { visibility: o ? "hidden" : void 0 },
			className: `tn-card tn-wall-card${n ? " tn-compact" : ""}${r ? " tn-selected" : ""}`,
			children: [
				/* @__PURE__ */ _("div", {
					className: "tn-card-title",
					children: J(e, t)
				}),
				/* @__PURE__ */ _("img", {
					className: "tn-wall-art",
					src: "games/tournay/rampart.svg",
					alt: ""
				}),
				/* @__PURE__ */ v("div", {
					className: "tn-card-bottom",
					children: [/* @__PURE__ */ _("span", { children: c.walls }), /* @__PURE__ */ _("b", { children: "1 PP" })]
				}),
				/* @__PURE__ */ _("span", {
					className: "tn-card-detail",
					children: Je(oe(e), t)
				}),
				/* @__PURE__ */ _("span", { className: `tn-class-mark tn-${i.color}` })
			]
		});
	}
	let l = T(e);
	return /* @__PURE__ */ v("div", {
		ref: a,
		style: { visibility: o ? "hidden" : void 0 },
		className: `tn-card tn-${l.color}${n ? " tn-compact" : ""}${r ? " tn-selected" : ""}`,
		children: [
			/* @__PURE__ */ v("div", {
				className: "tn-card-title",
				children: [
					/* @__PURE__ */ _("span", {
						className: "tn-cost",
						children: l.sacrifice === "card" ? `${l.cost} + ${c.cards}` : l.sacrifice ? /* @__PURE__ */ _(Y, { color: l.sacrifice }) : l.cost
					}),
					/* @__PURE__ */ _("strong", { children: J(e, t) }),
					/* @__PURE__ */ _("span", {
						className: "tn-level",
						children: [
							"",
							"I",
							"II",
							"III"
						][l.level]
					})
				]
			}),
			/* @__PURE__ */ _("img", {
				className: "tn-card-art",
				src: `games/tournay/${l.id}.svg`,
				alt: "",
				loading: "lazy"
			}),
			/* @__PURE__ */ v("div", {
				className: "tn-card-bottom",
				children: [/* @__PURE__ */ _("span", { children: c[l.kind] }), /* @__PURE__ */ _("b", { children: l.points ? `${l.points} PP` : l.kind === "prestige" && l.metric !== "cathedral" ? `${l.owner} / ${l.guest}` : "—" })]
			}),
			/* @__PURE__ */ _("span", {
				className: "tn-card-detail",
				children: qe(l, t)
			})
		]
	});
}
//#endregion
//#region src/games/tournay/motion-anchor.ts
function Ye(e) {
	let { ref: t, hidden: a } = s(e), o = c(), l = i(null), u = i(null), d = n(() => {
		let e = l.current?.getBoundingClientRect();
		e?.width && e.height && (u.current = {
			x: e.left,
			y: e.top,
			w: e.width,
			h: e.height
		});
	}, []);
	return r(() => {
		d();
	}), {
		ref: n((n) => {
			n || d(), l.current = n, t(n), o?.registerProbe(e, n ? null : () => u.current);
		}, [
			o,
			e,
			t,
			d
		]),
		hidden: a
	};
}
//#endregion
//#region src/games/tournay/view-player.tsx
function Xe({ color: e, name: t, resting: n = !1 }) {
	let { ref: r, hidden: i } = s(t);
	return /* @__PURE__ */ _("span", {
		ref: r,
		className: "tn-citizen-anchor",
		style: { visibility: i ? "hidden" : void 0 },
		children: /* @__PURE__ */ _(Y, {
			color: e,
			resting: n
		})
	});
}
function Ze({ cell: e, owner: t }) {
	return /* @__PURE__ */ _("div", {
		className: "tn-placed-workers",
		children: e.workers.map((n, r) => /* @__PURE__ */ _(Xe, {
			color: n,
			name: ce(t, e.x, e.y, r)
		}, r))
	});
}
function Qe({ cell: e, owner: t, label: n }) {
	let { ref: r, hidden: i } = s(`tn:damage:${t}:${e.x},${e.y}`);
	return /* @__PURE__ */ _("img", {
		ref: r,
		className: "tn-damage-marker",
		src: "games/tournay/damage-marker.svg",
		alt: n,
		style: { visibility: i ? "hidden" : void 0 }
	});
}
function $e({ player: e, label: t }) {
	let { ref: n } = s(`tn:walls:${e.rid}`), { ref: r, hidden: i } = s(`tn:wall-art:${e.rid}`);
	return /* @__PURE__ */ v("div", {
		ref: n,
		className: "tn-wall-pile",
		children: [/* @__PURE__ */ _("img", {
			ref: r,
			src: "games/tournay/rampart.svg",
			alt: "",
			style: { visibility: i || !e.walls ? "hidden" : void 0 }
		}), /* @__PURE__ */ v("span", { children: [
			t,
			" ",
			/* @__PURE__ */ _("b", { children: e.walls })
		] })]
	});
}
function et({ slot: e, children: t }) {
	let { ref: n } = s(`tn:event:${e}`);
	return /* @__PURE__ */ _("div", {
		ref: n,
		className: "tn-event-slot",
		children: t
	});
}
function tt({ card: e, children: t }) {
	let { ref: n, hidden: r } = s(`tn:event-art:${e}`);
	return /* @__PURE__ */ _("div", {
		ref: n,
		style: { visibility: r ? "hidden" : void 0 },
		children: t
	});
}
function nt({ card: e, index: t, filled: n }) {
	let { ref: r, hidden: i } = s(`tn:event-coin:${e}:${t}`);
	return /* @__PURE__ */ _("i", {
		ref: r,
		className: n ? "tn-filled" : "",
		children: n && /* @__PURE__ */ _("img", {
			src: "games/tournay/coin.svg",
			alt: "",
			style: { visibility: i ? "hidden" : void 0 }
		})
	});
}
function rt({ id: e, children: t }) {
	let { ref: n, hidden: r } = Ye(`tn:offer:${e}`);
	return /* @__PURE__ */ _("div", {
		ref: n,
		className: "tn-offer",
		style: { visibility: r ? "hidden" : void 0 },
		children: t
	});
}
function it({ p: e, name: t, selected: n, onClick: r, locale: i }) {
	let { ref: a } = s(`tn:seat:${e.rid}`), o = q(i);
	return /* @__PURE__ */ v("button", {
		type: "button",
		ref: a,
		className: `tn-player-tab${n ? " tn-current" : ""}`,
		onClick: r,
		children: [
			/* @__PURE__ */ _("strong", { children: t }),
			/* @__PURE__ */ v("span", {
				className: "tn-player-money",
				children: [
					/* @__PURE__ */ _(l, { value: e.money }),
					" ",
					o.money
				]
			}),
			/* @__PURE__ */ v("span", { children: [b.map((t) => /* @__PURE__ */ v("span", { children: [/* @__PURE__ */ _(Y, { color: t }), e.total[t]] }, t)), /* @__PURE__ */ v("span", { children: [
				o.walls,
				" ",
				e.walls
			] })] }),
			e.locked && /* @__PURE__ */ v("small", { children: ["✓ ", o.locked] })
		]
	});
}
function at({ c: e, x: t, y: n, owner: r, candidates: i, locale: a, onChoose: o, onInspect: s }) {
	let { ref: c } = Ye(`tn:cell:${r}:${t},${n}`), l = q(a), u = i.length === 1 ? i[0] : void 0, d = e?.stack[e.stack.length - 1], f = !d && u?.label === "place" ? u.card : null;
	return /* @__PURE__ */ v("div", {
		ref: c,
		className: `tn-space${e?.damage ? " tn-damaged" : ""}${i.length ? " tn-legal" : ""}`,
		children: [
			d ? /* @__PURE__ */ _(Z, {
				id: d,
				locale: a,
				compact: !0,
				anchorName: `tn:card:${d}`
			}) : f ? /* @__PURE__ */ _("div", {
				className: "tn-ghost",
				children: /* @__PURE__ */ _(Z, {
					id: f,
					locale: a,
					compact: !0
				})
			}) : /* @__PURE__ */ _("span", {
				className: "tn-street",
				"aria-hidden": !0,
				children: "✦"
			}),
			i.length > 0 && /* @__PURE__ */ _("button", {
				className: "tn-space-hit",
				"aria-label": `${l.actions[i[0].label] ?? l.select} ${d ? J(d, a) : `${t + 1}, ${n + 1}`}`,
				onClick: () => u ? o(u) : s(e?.stack ?? [], i),
				children: /* @__PURE__ */ _(X, {})
			}),
			d && /* @__PURE__ */ _("button", {
				className: "tn-inspect",
				"aria-label": `${l.inspect}: ${J(d, a)}`,
				onClick: () => s(e.stack, i),
				children: "i"
			}),
			e?.workers.length ? /* @__PURE__ */ _(Ze, {
				cell: e,
				owner: r
			}) : null,
			e?.damage && /* @__PURE__ */ _(Qe, {
				cell: e,
				owner: r,
				label: l.damaged
			}),
			e && e.stack.length > 1 && /* @__PURE__ */ _("span", {
				className: "tn-stack-count",
				title: l.covered,
				children: e.stack.length
			})
		]
	});
}
function ot({ player: e, options: t, locale: n, onChoose: r, onInspect: i }) {
	let { ref: a } = s(`tn:district:${e.rid}`), o = t.filter((t) => t.kind === "cell" && t.owner === e.rid && t.x !== void 0 && t.y !== void 0), c = e.city.concat(o.map((e) => ({
		x: e.x,
		y: e.y,
		stack: [],
		workers: [],
		damage: !1
	}))), l = c.map((e) => e.x), u = c.map((e) => e.y), d = Math.min(0, ...l), f = Math.max(2, ...l), p = Math.min(0, ...u), m = Math.max(2, ...u), h = c.length ? {
		x0: Math.min(...l),
		x1: Math.max(...l),
		y0: Math.min(...u),
		y1: Math.max(...u)
	} : {
		x0: d,
		x1: f,
		y0: p,
		y1: m
	}, g = Math.max(3, h.x1 - h.x0 + 1), v = Math.max(3, h.y1 - h.y0 + 1);
	return /* @__PURE__ */ _("div", {
		ref: a,
		className: "tn-district",
		style: {
			"--tn-columns": g,
			"--tn-rows": v
		},
		children: Array.from({ length: v * g }, (t, a) => {
			let s = h.x0 + a % g, c = h.y0 + Math.floor(a / g), l = e.city.find((e) => e.x === s && e.y === c);
			return /* @__PURE__ */ _(at, {
				c: l,
				x: s,
				y: c,
				owner: e.rid,
				candidates: o.filter((e) => e.x === s && e.y === c),
				locale: n,
				onChoose: r,
				onInspect: i
			}, `${s},${c}`);
		})
	});
}
function st({ player: e, color: t, choices: n, locale: r, onChoose: i, onGroup: a }) {
	let o = q(r), { ref: c } = s(k(e.rid, t, "ready")), { ref: l } = s(k(e.rid, t, "resting")), u = n.filter((n) => n.kind === "worker" && n.color === t && n.owner === e.rid && n.extra !== "resting"), d = n.filter((n) => n.kind === "worker" && n.color === t && n.owner === e.rid && n.extra === "resting"), f = u.length === 1 ? u[0] : null;
	return /* @__PURE__ */ v("div", {
		className: "tn-citizen-row",
		children: [
			/* @__PURE__ */ _("span", { children: o[t] }),
			/* @__PURE__ */ v("button", {
				ref: c,
				type: "button",
				className: `tn-citizen-group${u.length ? " tn-worker-legal" : ""}`,
				disabled: !u.length,
				onClick: () => f ? i(f) : a(u),
				"aria-label": `${o[t]} ${e.ready[t]} ${o.ready}`,
				children: [
					Array.from({ length: Math.min(e.ready[t], 6) }, (n, r) => /* @__PURE__ */ _(Xe, {
						color: t,
						name: A(e.rid, t, "ready", r)
					}, r)),
					e.ready[t] === 0 && /* @__PURE__ */ _("span", { children: "—" }),
					e.ready[t] > 6 && /* @__PURE__ */ _("b", { children: e.ready[t] }),
					u.length > 0 && /* @__PURE__ */ _(X, {})
				]
			}),
			/* @__PURE__ */ v("button", {
				ref: l,
				type: "button",
				className: `tn-rest-count${d.length ? " tn-worker-legal" : ""}`,
				disabled: !d.length,
				onClick: () => d[0] && i(d[0]),
				"aria-label": `${o[t]} ${o.resting} ${e.resting[t]}`,
				children: [
					/* @__PURE__ */ _(Xe, {
						color: t,
						resting: !0,
						name: A(e.rid, t, "resting", 0)
					}),
					e.resting[t],
					d.length > 0 && /* @__PURE__ */ _(X, {})
				]
			})
		]
	});
}
function ct({ player: e, choices: t, name: n, locale: r, onChoose: i, onGroup: a }) {
	let { ref: o } = s(`tn:plaza:${e.rid}`), c = q(r);
	return /* @__PURE__ */ v("div", {
		ref: o,
		className: "tn-plaza",
		children: [
			/* @__PURE__ */ _("h3", { children: n }),
			b.map((n) => /* @__PURE__ */ _(st, {
				player: e,
				color: n,
				choices: t,
				locale: r,
				onChoose: i,
				onGroup: a
			}, n)),
			/* @__PURE__ */ v("div", {
				className: "tn-plaza-legend",
				children: [/* @__PURE__ */ _("span", { children: c.ready }), /* @__PURE__ */ _("span", { children: c.resting })]
			}),
			/* @__PURE__ */ _($e, {
				player: e,
				label: c.walls
			})
		]
	});
}
function lt({ deck: e, options: t, locale: n, onChoose: r, onInspect: i }) {
	let { ref: a } = s(`tn:deck:${e.key}`), o = q(n), c = t.find((t) => t.kind === "deck" && t.color === e.color && t.level === e.level), l = t.find((t) => t.label === "takeVisible" && t.card === e.face);
	return /* @__PURE__ */ v("div", {
		className: `tn-deck-wrap tn-${e.color}`,
		ref: a,
		children: [
			/* @__PURE__ */ v("button", {
				type: "button",
				className: "tn-deck",
				disabled: !c && !l,
				onClick: () => (l ?? c) && r(l ?? c),
				"aria-label": `${o.actions.draw} ${o[e.color]} ${[
					"",
					"I",
					"II",
					"III"
				][e.level]}`,
				children: [e.face ? /* @__PURE__ */ _(Z, {
					id: e.face,
					locale: n,
					compact: !0,
					anchorName: `tn:deck-face:${e.face}`
				}) : /* @__PURE__ */ v(g, { children: [
					/* @__PURE__ */ _("span", {
						className: "tn-deck-herald",
						children: [
							"",
							"I",
							"II",
							"III"
						][e.level]
					}),
					/* @__PURE__ */ _("span", { children: o[e.color] }),
					/* @__PURE__ */ _("span", { children: e.count })
				] }), (c || l) && /* @__PURE__ */ _(X, {})]
			}),
			e.crier && /* @__PURE__ */ _("small", {
				className: "tn-crier-used",
				children: "✓"
			}),
			e.face && /* @__PURE__ */ _("button", {
				className: "tn-deck-inspect",
				onClick: () => i([e.face]),
				"aria-label": o.inspect,
				children: "i"
			}),
			l && c && /* @__PURE__ */ _("button", {
				className: "tn-deck-alternative",
				onClick: () => r(c),
				children: o.actions.drawTwo
			})
		]
	});
}
function ut(e) {
	let t = e.public, n = e.private, r = u((e) => e.locale), i = q(r);
	f();
	let c = n?.choices ?? [], l = n?.prompt || t.prompt, ee = `${t.phase}:${l}`, [y, te] = a(ee), [ne, re] = a(e.myRid), [ie, ae] = a(null), [x, S] = a(!1), [C, w] = a(!1), [E, k] = a([]), [A, ce] = a([]);
	if (y !== ee) {
		te(ee), w(!1), S(!1), ce([]);
		let e = c.find((e) => e.kind === "cell" && e.owner);
		e && re(e.owner);
	}
	let j = t.players.find((e) => e.rid === ne) ?? t.players[0], M = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? h(n, r) : t;
	}, N = (t) => {
		e.send({
			type: "choose",
			id: t.id
		}), w(!1), S(!1);
	}, P = (e, t = []) => {
		ae({
			cards: [...e].reverse(),
			candidates: t
		}), S(!0);
	}, le = (e) => {
		k(e), w(!0);
	}, { ref: ue } = s(`tn:hand:${e.myRid}`), { ref: F } = s("tn:supply"), { ref: de } = s("tn:event-deck"), { ref: fe } = s("tn:viewport"), { ref: pe } = s("tn:players-viewport"), { ref: I } = s("tn:table-viewport"), { ref: me } = s("tn:market-viewport"), { ref: L } = s("tn:city-viewport"), { ref: R } = s("tn:citizens-viewport"), z = (i.prompts[l] ?? i.prompts.settle) + (t.event === null ? "" : " · " + J(`event:${t.event}`, r)), B = c.length > 0, he = c.filter((e) => e.kind === "card" && e.card && !(n?.hand ?? []).includes(e.card) && e.label !== "takeVisible"), ge = c.filter((e) => e.kind === "action" && e.label !== "fire"), V = n?.prompt === "ballista" && c.some((e) => e.label === "fire"), H = V ? c.find((e) => e.label === "fire" && e.extra === A.join(",")) : void 0, _e = c.filter((e) => e.kind === "color"), U = t.decision ? M(t.decision) : M(t.turn);
	return /* @__PURE__ */ v("div", {
		ref: fe,
		className: "tn-root",
		children: [
			/* @__PURE__ */ _(d, {
				kind: "sheen",
				base: "var(--tn-paper)",
				className: "absolute inset-0"
			}),
			/* @__PURE__ */ _(p, {
				adaptive: !0,
				scroll: !1,
				className: "tn-game",
				banner: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(m, {
					tone: t.phase === "done" ? "done" : B ? "accent" : "info",
					accent: se.accent,
					text: B ? z : t.phase === "final" ? i.wait : `${U} · ${z}`,
					chip: t.lastRound ? i.finalRound : `${i.round} ${t.round}`
				}), /* @__PURE__ */ _("div", {
					ref: pe,
					className: "tn-player-strip",
					children: t.players.map((e) => /* @__PURE__ */ _(it, {
						p: e,
						name: M(e.rid),
						selected: e.rid === j.rid,
						locale: r,
						onClick: () => re(e.rid)
					}, e.rid))
				})] }),
				actionsHeight: "tn-actions-height",
				actions: /* @__PURE__ */ v("div", {
					className: "tn-bottom",
					children: [/* @__PURE__ */ _("div", {
						className: "tn-hand",
						ref: ue,
						"aria-label": i.hand,
						children: n?.hand.length ? n.hand.map((e) => {
							let t = c.find((t) => t.kind === "card" && t.card === e);
							return /* @__PURE__ */ v("div", {
								className: "tn-hand-slot",
								children: [/* @__PURE__ */ v("button", {
									type: "button",
									disabled: !t,
									onClick: () => t && N(t),
									"aria-label": t ? `${i.actions[t.label] ?? i.select} ${J(e, r)}` : J(e, r),
									children: [/* @__PURE__ */ _(Z, {
										id: e,
										locale: r,
										compact: !0,
										selected: n.selected === e,
										anchorName: `tn:hand:${e}`
									}), t && /* @__PURE__ */ _(X, {})]
								}), /* @__PURE__ */ _("button", {
									className: "tn-hand-inspect",
									onClick: () => P([e]),
									"aria-label": i.inspect,
									children: "i"
								})]
							}, e);
						}) : /* @__PURE__ */ _("p", {
							className: "tn-no-hand",
							children: i.noHand
						})
					}), /* @__PURE__ */ v("div", {
						className: "tn-controls",
						children: [
							ge.map((e) => /* @__PURE__ */ _("button", {
								type: "button",
								className: e.label === "endTurn" || e.label === "gather" || e.label === "accept" ? "btn-base bg-pop" : "btn-quiet bg-surface",
								onClick: () => N(e),
								children: i.actions[e.label] ?? i.select
							}, e.id)),
							V && /* @__PURE__ */ _("button", {
								type: "button",
								className: "btn-base bg-pop",
								disabled: !H,
								onClick: () => H && N(H),
								children: i.actions.fire
							}),
							!B && /* @__PURE__ */ _("p", { children: t.phase === "done" ? i.prompts.done : i.wait })
						]
					})]
				}),
				children: /* @__PURE__ */ v("div", {
					ref: I,
					className: "tn-table-layout",
					children: [
						/* @__PURE__ */ v("aside", {
							ref: me,
							className: "tn-market",
							children: [
								/* @__PURE__ */ _("div", {
									className: "tn-events",
									children: t.events.map((e, n) => {
										if (!e) return /* @__PURE__ */ _(et, {
											slot: n,
											children: /* @__PURE__ */ _("div", { className: "tn-empty-event" })
										}, n);
										let a = `event:${e.card}`, o = c.find((e) => e.kind === "event" && e.card === a), s = V && A.includes(e.card), l = D[e.card], u = !!o || V;
										return /* @__PURE__ */ _(et, {
											slot: n,
											children: /* @__PURE__ */ _(tt, {
												card: e.card,
												children: /* @__PURE__ */ v("div", {
													className: `tn-event tn-${l.color}${s ? " tn-selected-event" : ""}`,
													children: [/* @__PURE__ */ v("button", {
														type: "button",
														className: "tn-event-main",
														disabled: !u,
														onClick: () => {
															V ? ce(s ? A.filter((t) => t !== e.card) : t.events.filter((t) => t && (t.card === e.card || A.includes(t.card))).map((e) => e.card)) : o && N(o);
														},
														children: [
															/* @__PURE__ */ _("strong", { children: J(a, r) }),
															/* @__PURE__ */ _("span", {
																className: "tn-event-effect",
																children: /* @__PURE__ */ _("img", {
																	src: `games/tournay/event-${e.card}.svg`,
																	alt: Je(e.card, r)
																})
															}),
															/* @__PURE__ */ _("span", {
																className: "tn-event-coins",
																children: Array.from({ length: l.cap }, (t, n) => /* @__PURE__ */ _(nt, {
																	card: e.card,
																	index: n,
																	filled: n < e.coins
																}, n))
															}),
															u && /* @__PURE__ */ _(X, {})
														]
													}), /* @__PURE__ */ _("button", {
														className: "tn-event-info",
														onClick: () => P([a]),
														"aria-label": i.inspect,
														children: "i"
													})]
												})
											})
										}, n);
									})
								}),
								/* @__PURE__ */ _("div", {
									className: "tn-decks",
									children: [
										3,
										2,
										1
									].flatMap((e) => b.map((n) => {
										let i = t.decks.find((t) => t.color === n && t.level === e);
										return /* @__PURE__ */ _(lt, {
											deck: i,
											options: c,
											locale: r,
											onChoose: N,
											onInspect: P
										}, i.key);
									}))
								}),
								/* @__PURE__ */ v("div", {
									className: "tn-market-counts",
									children: [/* @__PURE__ */ v("p", {
										className: "tn-crier-count",
										children: [
											i.crier,
											" ",
											t.crierCount,
											" / 9"
										]
									}), /* @__PURE__ */ v("div", {
										ref: de,
										className: "tn-event-deck",
										"aria-label": r === "en" ? "Event deck" : "事件牌堆",
										children: [/* @__PURE__ */ _("span", {
											"aria-hidden": !0,
											children: "▤"
										}), t.eventCount]
									})]
								})
							]
						}),
						/* @__PURE__ */ v("main", {
							ref: L,
							className: "tn-city-column",
							children: [
								/* @__PURE__ */ v("div", {
									className: "tn-city-caption",
									children: [/* @__PURE__ */ v("h2", { children: [
										M(j.rid),
										" · ",
										i.city
									] }), /* @__PURE__ */ v("span", { children: [j.city.length, " / 9"] })]
								}),
								he.length ? /* @__PURE__ */ _("div", {
									className: "tn-offers",
									children: he.map((e) => /* @__PURE__ */ _(rt, {
										id: e.card,
										children: /* @__PURE__ */ v("button", {
											type: "button",
											onClick: () => N(e),
											"aria-label": `${i.actions[e.label] ?? i.select} ${J(e.card, r)}`,
											children: [/* @__PURE__ */ _(Z, {
												id: e.card,
												locale: r
											}), /* @__PURE__ */ _(X, {})]
										})
									}, e.id))
								}) : null,
								t.revealed.length > 0 && !he.length && /* @__PURE__ */ _("div", {
									className: "tn-revealed",
									children: t.revealed.map((e) => /* @__PURE__ */ _(rt, {
										id: e,
										children: /* @__PURE__ */ _("button", {
											type: "button",
											onClick: () => P([e]),
											children: /* @__PURE__ */ _(Z, {
												id: e,
												locale: r,
												compact: !0
											})
										})
									}, e))
								}),
								/* @__PURE__ */ _(ot, {
									player: j,
									options: c,
									locale: r,
									onChoose: N,
									onInspect: P
								})
							]
						}),
						/* @__PURE__ */ v("aside", {
							ref: R,
							className: "tn-citizens-column",
							children: [
								t.players.map((e) => /* @__PURE__ */ _(ct, {
									player: e,
									name: M(e.rid),
									choices: c,
									locale: r,
									onChoose: N,
									onGroup: le
								}, e.rid)),
								_e.length > 0 && /* @__PURE__ */ _("div", {
									className: "tn-color-choices",
									children: _e.map((e) => /* @__PURE__ */ v("button", {
										className: `tn-color-choice tn-${e.color}`,
										onClick: () => N(e),
										children: [
											/* @__PURE__ */ _(Y, { color: e.color }),
											/* @__PURE__ */ _("span", { children: i.actions[e.label] ?? i.select }),
											e.amount !== void 0 && /* @__PURE__ */ v("b", { children: [
												e.amount,
												" ",
												i.money
											] }),
											/* @__PURE__ */ _(X, {})
										]
									}, e.id))
								}),
								/* @__PURE__ */ v("div", {
									className: "tn-supply",
									ref: F,
									children: [/* @__PURE__ */ _("span", { children: i.supply }), b.map((e) => /* @__PURE__ */ v("span", { children: [/* @__PURE__ */ _(Y, { color: e }), t.supply[e]] }, e))]
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ _(o, {
				open: x,
				onClose: () => S(!1),
				label: i.details,
				title: i.details,
				children: ie && /* @__PURE__ */ _("div", {
					className: "tn-detail-list",
					children: ie.cards.map((e) => /* @__PURE__ */ v("article", { children: [/* @__PURE__ */ _(Z, {
						id: e,
						locale: r
					}), /* @__PURE__ */ v("div", { children: [
						/* @__PURE__ */ _("h3", { children: J(e, r) }),
						/* @__PURE__ */ _("p", { children: O(e) ? Je(oe(e), r) : qe(T(e), r) }),
						!O(e) && /* @__PURE__ */ v("p", { children: [
							i.cost,
							": ",
							T(e).cost,
							" ",
							i.money,
							T(e).sacrifice && ` · ${i.actions.sacrifice}: ${T(e).sacrifice === "card" ? i.cards : i[T(e).sacrifice]}`
						] }),
						ie.candidates.filter((t) => t.card === e || !t.card).map((e) => /* @__PURE__ */ _("button", {
							className: "btn-base bg-pop",
							onClick: () => N(e),
							children: i.actions[e.label] ?? i.select
						}, e.id))
					] })] }, e))
				})
			}),
			/* @__PURE__ */ _(o, {
				open: C,
				onClose: () => w(!1),
				label: i.select,
				title: i.select,
				children: /* @__PURE__ */ _("div", {
					className: "tn-group-choices",
					children: E.map((e) => /* @__PURE__ */ v("button", {
						className: "btn-base bg-pop",
						onClick: () => N(e),
						children: [
							/* @__PURE__ */ _(Y, { color: e.color }),
							e.amount,
							" · ",
							i.actions[e.label] ?? i.select,
							e.extra === "rent" && /* @__PURE__ */ _("small", { children: i.rent })
						]
					}, e.id))
				})
			})
		]
	});
}
//#endregion
//#region src/games/tournay/bot.ts
var dt = {
	prestige: 1,
	income: 1,
	recruitment: 1
};
function ft(e = dt) {
	return ({ public: t, private: n }, r) => {
		let i = n?.choices ?? [], a = t.players.find((e) => e.rid === r.rid);
		if (!i.length || !a) return null;
		let o = a.city.map((e) => T(e.stack[e.stack.length - 1])), s = (n?.hand ?? []).filter((e) => !O(e)), c = o.filter((e) => e.kind === "prestige").length, l = a.city.length, u = b.reduce((e, t) => e + a.ready[t], 0), d = Math.max(0, 10 - a.money);
		function f(t) {
			if (t.kind === "prestige") {
				let n = (e) => o.filter((t) => t.color === e && t.level < 3).length, r = {
					setsCards: Math.min(...b.map(n)),
					yellowCards: n("yellow"),
					whiteCards: n("white"),
					redCards: n("red"),
					money: Math.floor(Math.max(0, a.money - t.cost) / 4),
					yellowWorkers: a.total.yellow,
					whiteWorkers: a.total.white,
					redWorkers: a.total.red,
					characters: o.filter((e) => e.kind === "character").length,
					prestige: c + 1,
					setsWorkers: Math.min(...b.map((e) => a.total[e])),
					civilBuildings: o.filter((e) => e.kind === "building" && e.color !== "red").length,
					walls: a.walls,
					cathedral: 0
				};
				return o.some((e) => e.id === t.id) ? -30 : 2 + t.points + Math.min(12, (r[t.metric] ?? 0) * (t.owner ?? 0)) * e.prestige + (c < 2 && l >= 6 ? 6 : 0) - t.cost * .25 - (t.sacrifice ? 1.5 : 0) - (t.sacrifice && t.sacrifice !== "card" && a.total[t.sacrifice] <= 1 ? 12 : 0);
			}
			let n = {
				money: (t.amount ?? 0) * .8 * e.income,
				empty: Math.max(1, 9 - l) * .65,
				occupied: l * .65,
				draw: 3.4,
				takeTwo: 4.2,
				recruit: Math.max(0, 4 - Math.min(...b.map((e) => a.total[e]))) * e.recruitment,
				copy: 3.3,
				ballista: 1.5,
				fight: 2.2,
				brewery: 3,
				inn: 3.2,
				bakery: 3.1,
				abbey: 4.5,
				seigniory: 2.5,
				catapult: 1.8,
				court: 2.3,
				priest: 3.2,
				bishop: 4,
				senator: 4.2,
				mercenary: 3.2,
				monk: 3.5,
				templar: 2.6
			};
			return 1 + t.points + (n[t.effect] ?? 2.5) + (l < 9 ? 3 : 0) - t.cost * .18;
		}
		function p(t) {
			if (!t.card || O(t.card)) return 0;
			let n = T(t.card);
			return n.effect === "money" ? (n.amount ?? 0) * (.55 + d * .16) * e.income : n.effect === "empty" ? (9 - l) * (.5 + d * .1) : n.effect === "occupied" ? l * (.5 + d * .1) : n.effect === "recruit" ? a.money >= (n.amount ?? 0) ? Math.max(0, 4 - (n.target ? a.total[n.target] : Math.min(...b.map((e) => a.total[e])))) * 2 * e.recruitment : .1 : n.effect === "draw" || n.effect === "takeTwo" || n.effect === "abbey" ? (s.length < 3 ? 6 : .4) + (n.drawLevel === 3 && l >= 6 && c < 2 ? 4 : 0) : s.length < 3 ? 2.6 : 1.6;
		}
		function m(i) {
			if (i.label === "cancel" || i.label === "skip" || i.label === "skipBuild" || i.label === "lockNone") return -20;
			if (n.prompt === "build") return i.card && !O(i.card) ? f(T(i.card)) : -20;
			if (n.prompt === "payment") return i.card ? -f(T(i.card)) + (i.kind === "card" ? 1 : -1) : (i.extra === "resting" ? 3 : i.extra === "ready" ? 1 : 2) + (i.color ? a.total[i.color] : 0);
			if (n.prompt === "place") {
				let e = a.city.find((e) => e.x === i.x && e.y === i.y), t = i.card ? T(i.card) : null, n = e ? t?.color === T(e.stack[e.stack.length - 1]).color ? 0 : -4 : 12;
				if (e) {
					let t = T(e.stack[e.stack.length - 1]);
					n -= f(t) * .3, t.kind === "prestige" && (n -= c <= 2 ? 80 : 25);
				}
				for (let r of a.city.filter((t) => t !== e && (t.x === i.x || t.y === i.y) && !t.damage)) {
					let e = T(r.stack[r.stack.length - 1]);
					t?.kind === "character" && e.kind === "building" && (n += 1.2), t?.kind === "building" && e.kind === "character" && (n += 1.2);
				}
				return n;
			}
			if (n.prompt === "action") {
				if (i.label === "activate") return p(i) + .8;
				if (i.label === "draw") {
					let e = s.length, t = l >= 6 && c < 2;
					return e >= 3 ? -5 : i.level === 3 ? t ? 11 : l >= 5 ? 6 : -2 : (e < 1 ? 8 : 5) + +(i.level === 2 && l >= 3);
				}
				if (i.label === "earn") return (i.amount ?? 1) * (1 + d * .18) * e.income - (a.money >= 16 ? 9 : 0);
				if (i.label === "gather") return u === 0 ? 15 : 3 + (b.reduce((e, t) => e + a.total[t], 0) - u) * .35 - u * 1.3;
				if (i.label === "recruit") return Math.max(0, 4 - a.total[i.color]) * 2 * e.recruitment - (a.money < 9 ? 3 : 0);
				if (i.label === "fight") return a.money > 8 && n.hand.length < 4 ? 2.8 : -.5;
			}
			if (n.prompt === "workers") return i.owner === r.rid ? 10 : 2 - (t.players.find((e) => e.rid === i.owner)?.money ?? 0) * .01;
			if (n.prompt === "end") return i.label === "wall" ? 10 : i.label === "endTurn" ? 5 : i.card ? -f(T(i.card)) : 0;
			if (n.prompt === "defend") {
				let e = t.event === null ? null : D[t.event];
				return i.label === "catapultProtect" ? 10 : i.label === "protect" ? 3 + (e?.effect === "damage" ? 2 : 0) : 0;
			}
			return n.prompt === "damage" ? i.owner === r.rid ? i.card ? -f(T(i.card)) : 0 : i.card ? f(T(i.card)) : 1 : n.prompt === "rest" ? i.color ? -a.ready[i.color] * .1 : 0 : i.label === "keep" || i.label === "copy" ? i.card && !O(i.card) ? f(T(i.card)) : 1 : i.label === "recruit" ? i.color ? 6 - a.total[i.color] : 0 : i.label === "fight" ? i.amount ?? 1 : i.label === "earn" ? i.amount ?? 0 : i.label === "activate" ? p(i) : i.label === "draw" ? s.length < 3 ? 5 : 1 : i.label === "fire" || i.label === "useEffect" ? 2 : 0;
		}
		let h = i.map((e) => ({
			c: e,
			n: m(e)
		})).sort((e, t) => t.n - e.n);
		return { action: {
			type: "choose",
			id: (r.difficulty === "weak" && h.length > 1 && [
				"drawPick",
				"abbeyPick",
				"copy"
			].includes(n.prompt) ? h[1].c : h[0].c).id
		} };
	};
}
var pt = ft();
//#endregion
//#region src/games/tournay/fx.tsx
function mt({ id: e, width: t, height: n }) {
	let r = u((e) => e.locale);
	return /* @__PURE__ */ _("div", {
		className: "tn-root tn-flying-card",
		style: {
			width: t,
			height: n
		},
		children: e ? /* @__PURE__ */ _(Z, {
			id: e,
			locale: r,
			compact: !0
		}) : /* @__PURE__ */ _("div", {
			className: "tn-card-back",
			children: q(r).name
		})
	});
}
function ht({ data: e, ms: t }) {
	let n = i(null), a = e.from.includes(":resting") ? 90 : 0, o = e.to.includes(":resting") ? 90 : 0;
	return r(() => {
		let e = n.current?.animate([{ transform: `rotate(${a}deg)` }, { transform: `rotate(${o}deg)` }], {
			duration: t,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, [
		a,
		o,
		t
	]), /* @__PURE__ */ v("div", {
		className: "tn-root tn-flying-citizen",
		children: [/* @__PURE__ */ _("div", {
			ref: n,
			children: /* @__PURE__ */ _(Y, { color: e.color })
		}), (e.count ?? 1) > 1 && /* @__PURE__ */ _("b", { children: e.count })]
	});
}
function gt({ id: e, width: t, height: n }) {
	let r = u((e) => e.locale);
	return /* @__PURE__ */ v("div", {
		className: "tn-root tn-moving-event",
		style: {
			width: t,
			height: n
		},
		children: [/* @__PURE__ */ _("strong", { children: J(e, r) }), /* @__PURE__ */ _("img", {
			src: `games/tournay/event-${e.slice(6)}.svg`,
			alt: ""
		})]
	});
}
function Q(e, t) {
	let n = t.anchor(e);
	if (!n || !n.w || !n.h) return null;
	let r = /^tn:(?:pool|plaza|walls|wall-art|supply)(:|$)/.test(e) ? "citizens" : /^tn:(?:cell|worker|damage|district|offer|card):/.test(e) ? "city" : /^tn:(?:deck|deck-face|event|event-art|event-coin|event-deck)(:|$)/.test(e) ? "market" : e.startsWith("tn:seat:") ? "players" : null;
	return [
		t.anchor("tn:viewport"),
		r && r !== "players" ? t.anchor("tn:table-viewport") : null,
		r ? t.anchor(`tn:${r}-viewport`) : e.startsWith("tn:hand:") ? t.anchor(`tn:hand:${t.myRid}`) : null
	].every((e) => !e || n.x >= e.x - .5 && n.y >= e.y - .5 && n.x + n.w <= e.x + e.w + .5 && n.y + n.h <= e.y + e.h + .5) ? n : null;
}
function $(e, t, n) {
	let r = Q(e, t);
	if (r) return r;
	let i = /^tn:(?:cell|worker|damage|district|pool|plaza|walls|wall-art):([^:]+)/.exec(e)?.[1];
	return i || /^tn:(?:hand|offer|card):/.test(e) ? Q(`tn:seat:${i ?? n}`, t) : /^tn:(?:deck|deck-face|event|event-art|event-coin|event-deck)(:|$)/.test(e) ? Q("tn:market-viewport", t) : e === "tn:supply" ? Q("tn:citizens-viewport", t) : null;
}
var _t = {
	move(e, t) {
		let n = {
			...e.data,
			...e.secret
		}, r = n.card, i = n.to === `tn:hand:${t.myRid}`, a = n.to === `tn:hand:${e.rid}` && !i ? `tn:seat:${e.rid}` : n.to, o = $(n.from === `tn:hand:${e.rid}` && e.rid !== t.myRid ? `tn:seat:${e.rid}` : n.from, t, e.rid), s = $(a, t, e.rid);
		if (!o || !s) return null;
		let c = t.queued ? 160 : 390, l = t.queued ? [] : (n.hide ?? []).filter((e) => !!Q(e, t)), u = n.to.startsWith("tn:walls:") ? Q(`tn:wall-art:${e.rid}`, t) : l.length === 1 ? Q(l[0], t) : null, d = u ?? s, f = n.piece === "card" ? u ? d.w : Math.min(94, d.w) : n.piece === "event" ? d.w : n.piece === "damage" ? 34 : n.piece === "coin" ? 17 : 28, p = n.piece === "card" ? u ? d.h : f / .76 : n.piece === "event" ? d.h : n.piece === "damage" ? 34 : n.piece === "coin" ? 17 : 38, m = {
			x: d.x + (d.w - f) / 2,
			y: d.y + (d.h - p) / 2,
			w: f,
			h: p
		};
		return {
			ms: c,
			hide: l,
			node: /* @__PURE__ */ _(y, {
				from: o,
				to: m,
				ms: c,
				children: n.piece === "card" ? /* @__PURE__ */ _(mt, {
					id: r,
					width: f,
					height: p
				}) : n.piece === "event" ? /* @__PURE__ */ _(gt, {
					id: r,
					width: f,
					height: p
				}) : n.piece === "coin" || n.piece === "damage" ? /* @__PURE__ */ _("img", {
					src: `games/tournay/${n.piece === "coin" ? "coin" : "damage-marker"}.svg`,
					alt: "",
					style: {
						width: f,
						height: p
					}
				}) : /* @__PURE__ */ _(ht, {
					data: n,
					ms: c
				})
			})
		};
	},
	build(e, t) {
		let n = e.data, r = $(`tn:hand:${e.rid}`, t, e.rid), i = $(`tn:card:${n.card}`, t, e.rid);
		if (!r || !i) return null;
		let a = t.queued ? 170 : 390, o = Q(`tn:card:${n.card}`, t), s = o ? i.w : Math.min(94, i.w), c = s / .76, l = o ?? {
			x: i.x + (i.w - s) / 2,
			y: i.y + (i.h - c) / 2,
			w: s,
			h: c
		};
		return {
			ms: a,
			hide: t.queued || !o ? [] : [`tn:card:${n.card}`],
			node: /* @__PURE__ */ _(y, {
				from: r,
				to: l,
				ms: a,
				children: /* @__PURE__ */ _(mt, {
					id: n.card,
					width: s,
					height: c
				})
			})
		};
	},
	draw(e, t) {
		let n = e.data, r = e.secret, i = r?.card, a = $(r?.from ?? `tn:deck:${n.deck}`, t, e.rid), o = e.rid === t.myRid && i ? `tn:hand:${i}` : `tn:seat:${e.rid}`, s = $(o, t, e.rid);
		if (!a || !s) return null;
		let c = t.queued ? 160 : 390, l = Math.min(a.w, 160), u = o.startsWith("tn:hand:") ? Q(o, t) : null, d = Math.min(94, s.w), f = d / .76, p = u ?? {
			x: s.x + (s.w - d) / 2,
			y: s.y + (s.h - f) / 2,
			w: d,
			h: f
		};
		return {
			ms: c,
			hide: t.queued || !i || !u ? [] : [o],
			node: /* @__PURE__ */ _(y, {
				from: a,
				to: p,
				ms: c,
				children: /* @__PURE__ */ _(mt, {
					id: i,
					width: l,
					height: u ? l * u.h / u.w : l / .76
				})
			})
		};
	},
	change(e, t) {
		let n = e.data, r = t.anchor(`tn:seat:${e.rid}`), i = n.card ? t.anchor(`tn:card:${n.card}`) : null;
		if (!r) return null;
		if (n.kind === "earn" || n.kind === "loss") {
			if (!n.amount) return null;
			let e = i ?? {
				...r,
				y: r.y + 40,
				w: 22,
				h: 22
			}, t = {
				...r,
				w: 22,
				h: 22
			};
			return {
				ms: 390,
				node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(y, {
					from: n.kind === "loss" ? t : e,
					to: n.kind === "loss" ? e : t,
					ms: 390,
					children: /* @__PURE__ */ _("img", {
						className: "tn-flying-coin",
						src: "games/tournay/coin.svg",
						alt: ""
					})
				}), /* @__PURE__ */ v(ee, {
					at: r,
					ms: 390,
					children: [n.kind === "loss" ? "−" : "+", n.amount]
				})] })
			};
		}
		return {
			ms: 390,
			node: /* @__PURE__ */ _(te, {
				at: i ?? r,
				ms: 390
			})
		};
	}
};
//#endregion
//#region src/games/tournay/game-over.tsx
function vt(e) {
	let t = e.public, n = u((e) => e.locale), r = q(n), [i, s] = a(!0), [c, l] = a(null), [d, f] = a(!1), p = (t) => {
		let r = e.members.find((e) => e.rid === t);
		return r ? h(r, n) : t;
	}, m = e.result.ranking, g = t.scores[m[0]].prestige.map((e) => e.card);
	return /* @__PURE__ */ v("div", {
		className: "tn-root tn-over",
		children: [
			/* @__PURE__ */ _("div", {
				className: "tn-over-board",
				inert: i,
				"aria-hidden": i,
				children: /* @__PURE__ */ _(ut, {
					public: t,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => void 0
				})
			}),
			/* @__PURE__ */ _("button", {
				className: "tn-show-score btn-base bg-pop",
				disabled: i,
				tabIndex: i ? -1 : 0,
				onClick: () => s(!0),
				children: r.showScores
			}),
			/* @__PURE__ */ v("div", {
				className: `tn-score-overlay${i ? " tn-score-open" : ""}`,
				"aria-hidden": !i,
				inert: !i,
				children: [/* @__PURE__ */ _(ne, {}), /* @__PURE__ */ v("section", {
					className: "tn-score-sheet",
					"aria-label": r.scoreTitle,
					children: [
						/* @__PURE__ */ v("header", { children: [/* @__PURE__ */ _("h1", { children: r.scoreTitle }), /* @__PURE__ */ _("button", {
							className: "btn-quiet",
							onClick: () => s(!1),
							children: r.review
						})] }),
						/* @__PURE__ */ _("div", {
							className: "tn-score-scroll",
							children: /* @__PURE__ */ v("table", {
								className: "tn-score-table",
								children: [
									/* @__PURE__ */ _("thead", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
										scope: "col",
										children: r.city
									}), m.map((t, n) => /* @__PURE__ */ v("th", {
										scope: "col",
										className: e.result.winner.includes(t) ? "tn-winner" : "",
										children: [/* @__PURE__ */ _("small", { children: e.result.winner.includes(t) ? 1 : n + 1 }), /* @__PURE__ */ _("span", { children: p(t) })]
									}, t))] }) }),
									/* @__PURE__ */ v("tbody", { children: [
										/* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
											scope: "row",
											children: r.printed
										}), m.map((e) => /* @__PURE__ */ _("td", { children: t.scores[e].printed }, e))] }),
										/* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
											scope: "row",
											children: r.walls
										}), m.map((e) => /* @__PURE__ */ _("td", { children: t.scores[e].walls }, e))] }),
										g.map((e) => /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
											scope: "row",
											children: /* @__PURE__ */ _("button", {
												onClick: () => {
													l(e), f(!0);
												},
												children: J(e, n)
											})
										}), m.map((n) => {
											let i = t.scores[n].prestige.find((t) => t.card === e);
											return /* @__PURE__ */ v("td", { children: [/* @__PURE__ */ _("b", { children: i.amount }), /* @__PURE__ */ _("small", { children: i.owner ? r.owner : r.guest })] }, n);
										})] }, e))
									] }),
									/* @__PURE__ */ _("tfoot", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
										scope: "row",
										children: r.total
									}), m.map((n) => /* @__PURE__ */ _("td", {
										className: e.result.winner.includes(n) ? "tn-winner" : "",
										children: t.scores[n].total
									}, n))] }) })
								]
							})
						}),
						/* @__PURE__ */ v("footer", { children: [
							e.onPlayAgain && /* @__PURE__ */ _("button", {
								className: "btn-base bg-pop",
								onClick: e.onPlayAgain,
								children: r.again
							}),
							e.onBackToLobby && /* @__PURE__ */ _("button", {
								className: "btn-quiet",
								onClick: e.onBackToLobby,
								children: r.lobby
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ _("p", { children: r.waitHost })
						] })
					]
				})]
			}),
			/* @__PURE__ */ _(o, {
				open: d,
				onClose: () => f(!1),
				label: r.details,
				title: r.details,
				children: c && /* @__PURE__ */ _("div", {
					className: "tn-score-card",
					children: /* @__PURE__ */ _(Z, {
						id: c,
						locale: n
					})
				})
			})
		]
	});
}
//#endregion
//#region src/games/tournay/options.tsx
function yt({ value: e, onChange: t }) {
	let n = P.safeParse(e), r = n.success ? n.data : P.parse(void 0), i = q(u((e) => e.locale));
	return /* @__PURE__ */ v("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ _(ae, {
			checked: r.advanced,
			label: i.advanced,
			hint: i.advancedHint,
			onChange: () => t({
				...r,
				advanced: !r.advanced
			})
		}), /* @__PURE__ */ _(ie, {
			title: i.expansion,
			columns: 3,
			children: [
				"off",
				"replace",
				"mix"
			].map((e) => /* @__PURE__ */ _(re, {
				name: "tournay-expansion",
				value: e,
				checked: r.expansion === e,
				label: i[e],
				onChange: () => t({
					...r,
					expansion: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tournay/entry.tsx
var bt = {
	definition: He,
	View: ut,
	bot: pt,
	fx: _t,
	OverView: vt,
	Options: yt,
	locales: {
		zh: Ge,
		en: Ke
	}
};
//#endregion
export { bt as default };
