import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useT as s } from "@bgparty/sdk/i18n";
import { Texture as c } from "@bgparty/sdk/texture";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { SheetFxProbe as u } from "@bgparty/sdk/sheet-view";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { FlySprite as m } from "@bgparty/sdk/fx/primitives";
import { Confetti as h } from "@bgparty/sdk/ui/confetti";
//#region src/games/downforce/data.ts
var g = [
	"K",
	"B",
	"G",
	"O",
	"R",
	"Y"
], _ = [
	"aggressive",
	"cunning",
	"determined",
	"strategic",
	"tricky",
	"unpredictable",
	"ambitious",
	"experienced",
	"reckless",
	"tough",
	"bold",
	"defensive",
	"civilized",
	"lucky"
], v = [
	"river",
	"marina",
	"crosstown",
	"switchback",
	"aloha",
	"savanna"
], y = (/* @__PURE__ */ "O6 Y5 B4 R3 G2 K1.G6 R4 W2 K1.W3 W2.G8.R8.O6 Y4 W2 B1.O6 G4 B2 Y1.W5 G2.R6 K4 W2 G1.G6 Y4 O2.Y5.K6 O5 Y4 B3 R2 G1.K5.K6 G4 W2 R1.Y6 B5 R4 G3 K2 O1.B6 O4 G2 R1.B5.G6 K5 O4 Y3 B2 R1.B6 O4 Y2.O5.G5.B8.R6 K4 G2.K6 B4 R2.G6 B4 O2 K1.W5.O6 G4 B2.Y6 B4 W2 O1.R6 G5 K4 O3 Y2 B1.O8.K6 R4 Y2 O1.W5 O2.W3 W2.B6 O4 W2 Y1.W5 K2.W5 B2.R5.W5 Y2.W5.R6 Y4 K2 B1.W3 W2.Y6 K4 R2 G1.W5 R2.W5.B6 R5 G4 K3 O2 Y1.Y6 R4 K2.K8.Y8".split(".")).map((e, t) => {
	let n = e.split(" ").map((e) => ({
		color: e[0],
		value: Number(e.slice(1))
	}));
	return {
		id: t,
		rows: n,
		speed8: n.length === 1 && n[0].value === 8
	};
}), b = y.filter((e) => !e.speed8).map((e) => e.id), x = y.filter((e) => e.speed8).map((e) => e.id), S = [
	12,
	9,
	6,
	4,
	2,
	0
], C = [
	[
		9,
		6,
		3
	],
	[
		6,
		4,
		2
	],
	[
		3,
		2,
		1
	]
], w = {
	K: {
		color: "#353c47",
		number: 1,
		stripe: "#f7e8ca"
	},
	B: {
		color: "#2678b9",
		number: 2,
		stripe: "#d8f3ff"
	},
	G: {
		color: "#3e924d",
		number: 3,
		stripe: "#f6f3cc"
	},
	O: {
		color: "#ed8a2b",
		number: 4,
		stripe: "#453832"
	},
	R: {
		color: "#d94a42",
		number: 5,
		stripe: "#fff1d6"
	},
	Y: {
		color: "#e6bd35",
		number: 6,
		stripe: "#353c47"
	}
};
//#endregion
//#region src/games/downforce/auction.ts
function T(e, t, n = !1) {
	let r = e.some((e) => y[e].rows.some((e) => e.color === t)), i = e.some((e) => y[e].rows.some((e) => e.color === "W")), a = e.flatMap((e) => {
		let a = y[e].rows, o = Math.min(...a.map((e) => e.value)), s = a.flatMap((n, a) => (r ? n.color === t : i ? n.color === "W" : n.value === o) ? [{
			card: e,
			row: a,
			value: n.value
		}] : []), c = !a.some((e) => e.color === t) && (!i || r || !a.some((e) => e.color === "W"));
		return [...s, ...!n && c ? [{
			card: e,
			row: -1,
			value: 0
		}] : []];
	});
	if (!n || !a.length) return a;
	let o = Math.min(...a.map((e) => e.value));
	return a.filter((e) => e.value === o);
}
function E(e, t) {
	let n = y[e.card], r = y[t.card];
	return t.value - e.value || r.rows.length - n.rows.length || Number(n.rows.some((e) => e.color === "W")) - Number(r.rows.some((e) => e.color === "W"));
}
function D(e, t) {
	let n = t.filter((t) => e[t] != null);
	return n.sort((t, n) => E(e[t], e[n])), n[0] ?? null;
}
//#endregion
//#region src/games/downforce/meta.ts
var O = {
	id: "downforce",
	tier: "alpha",
	mechanics: [
		"auction",
		"hand-management",
		"grid-movement",
		"betting",
		"race"
	],
	interactionTags: [],
	nameKey: "games.downforce.name",
	descKey: "games.downforce.desc",
	rulesKey: "games.downforce.rules",
	icon: "🏎️",
	iconImg: "games/downforce.webp",
	rulesUrl: { en: "https://restorationgames.com/wp-content/uploads/2019/02/Downforce_Rulebook_2e-1.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [
		4,
		5,
		6
	],
	accent: "#cb452f",
	releasedAt: "2026-10-31T13:32:00+08:00",
	search: {
		py: "wan ming sai dao",
		init: "wmsd"
	},
	hotseat: "cover",
	botDelayMs: 550
}, k = {
	river: {
		width: 1641,
		height: 1080,
		length: 5689.1,
		closed: !0,
		starts: [
			"135",
			"151",
			"152",
			"162",
			"163",
			"174"
		],
		firstStart: "151",
		bets: [
			1202,
			2340.3,
			3526
		],
		nodes: {
			4: {
				x: 565.5,
				y: 85.5,
				angle: 0,
				front: 1752.3,
				poly: [
					[517, 60],
					[614, 60],
					[614, 111],
					[517, 111]
				],
				physical: "4",
				next: ["5", "16"],
				direct: ["5"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 16: ["15", "5"] }
			},
			5: {
				x: 662.5,
				y: 85.5,
				angle: 0,
				front: 1849.3,
				poly: [
					[614, 60],
					[711, 60],
					[711, 111],
					[614, 111]
				],
				physical: "5",
				next: ["6", "17"],
				direct: ["6"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 17: ["16", "6"] }
			},
			6: {
				x: 760.5,
				y: 85.5,
				angle: 0,
				front: 1948.3,
				poly: [
					[711, 60],
					[810, 60],
					[810, 111],
					[711, 111]
				],
				physical: "6",
				next: ["7", "18"],
				direct: ["7"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 18: ["17", "7"] }
			},
			7: {
				x: 858,
				y: 85.5,
				angle: 0,
				front: 2044.3,
				poly: [
					[810, 60],
					[906, 60],
					[906, 111],
					[810, 111]
				],
				physical: "7",
				next: ["8", "19"],
				direct: ["8"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 19: ["18", "8"] }
			},
			8: {
				x: 954,
				y: 85.5,
				angle: 0,
				front: 2140.3,
				poly: [
					[906, 60],
					[1002, 60],
					[1002, 111],
					[906, 111]
				],
				physical: "8",
				next: ["9", "20"],
				direct: ["9"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 20: ["19", "9"] }
			},
			9: {
				x: 1051,
				y: 85.5,
				angle: 0,
				front: 2238.3,
				poly: [
					[1002, 60],
					[1100, 60],
					[1100, 111],
					[1002, 111]
				],
				physical: "9",
				next: ["10", "21"],
				direct: ["10"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 21: ["20", "10"] }
			},
			10: {
				x: 1146.5,
				y: 85.5,
				angle: 0,
				front: 2333,
				poly: [
					[1100, 60],
					[1193, 60],
					[1193, 111],
					[1100, 111]
				],
				physical: "10",
				next: ["11", "35"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			11: {
				x: 1247.8,
				y: 89.4,
				angle: -.021,
				front: 2440,
				poly: [
					[1212.3, 59.5],
					[1284.1, 59.5],
					[1286.1, 111.8],
					[1214.3, 126.2]
				],
				physical: "11",
				next: ["22"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			12: {
				x: 280.6,
				y: 135.9,
				angle: -.2861,
				front: 1468,
				poly: [
					[226.7, 137.4],
					[269.7, 109.7],
					[326.1, 110.8],
					[325.1, 143.6],
					[261.5, 170.3]
				],
				physical: "12",
				next: ["13", "26"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					13: ["25", "26"],
					26: ["25", "13"]
				}
			},
			13: {
				x: 377.5,
				y: 120,
				angle: 0,
				front: 1567.3,
				poly: [
					[330, 95],
					[425, 95],
					[425, 145],
					[330, 145]
				],
				physical: "13",
				next: ["14", "27"],
				direct: ["14"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 27: ["26", "14"] }
			},
			14: {
				x: 474.5,
				y: 111.9,
				angle: -.0867,
				front: 1655.3,
				poly: [
					[425, 95],
					[517, 65],
					[517, 145],
					[425, 145]
				],
				physical: "14",
				next: [
					"4",
					"15",
					"28"
				],
				direct: ["4"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 28: ["27", "15"] }
			},
			15: {
				x: 565.5,
				y: 137,
				angle: 0,
				front: 1752.3,
				poly: [
					[517, 111],
					[614, 111],
					[614, 163],
					[517, 163]
				],
				physical: "15",
				next: [
					"5",
					"16",
					"29"
				],
				direct: ["16"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					5: ["4", "16"],
					29: ["28", "16"]
				}
			},
			16: {
				x: 662.5,
				y: 137,
				angle: 0,
				front: 1849.3,
				poly: [
					[614, 111],
					[711, 111],
					[711, 163],
					[614, 163]
				],
				physical: "16",
				next: [
					"6",
					"17",
					"30"
				],
				direct: ["17"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					6: ["5", "17"],
					30: ["29", "17"]
				}
			},
			17: {
				x: 760.5,
				y: 137,
				angle: 0,
				front: 1948.3,
				poly: [
					[711, 111],
					[810, 111],
					[810, 163],
					[711, 163]
				],
				physical: "17",
				next: [
					"7",
					"18",
					"31"
				],
				direct: ["18"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					7: ["6", "18"],
					31: ["30", "18"]
				}
			},
			18: {
				x: 858,
				y: 137,
				angle: 0,
				front: 2044.3,
				poly: [
					[810, 111],
					[906, 111],
					[906, 163],
					[810, 163]
				],
				physical: "18",
				next: [
					"8",
					"19",
					"32"
				],
				direct: ["19"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					8: ["7", "19"],
					32: ["31", "19"]
				}
			},
			19: {
				x: 954,
				y: 137,
				angle: 0,
				front: 2140.3,
				poly: [
					[906, 111],
					[1002, 111],
					[1002, 163],
					[906, 163]
				],
				physical: "19",
				next: [
					"9",
					"20",
					"33"
				],
				direct: ["20"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					9: ["8", "20"],
					33: ["32", "20"]
				}
			},
			20: {
				x: 1051,
				y: 137,
				angle: 0,
				front: 2238.3,
				poly: [
					[1002, 111],
					[1100, 111],
					[1100, 163],
					[1002, 163]
				],
				physical: "20",
				next: [
					"10",
					"21",
					"34"
				],
				direct: ["21"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					10: ["9", "21"],
					34: ["33", "21"]
				}
			},
			21: {
				x: 1146.5,
				y: 137,
				angle: 0,
				front: 2331.9,
				poly: [
					[1100, 111],
					[1193, 111],
					[1193, 163],
					[1100, 163]
				],
				physical: "21",
				next: ["11", "35"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			22: {
				x: 1328.7,
				y: 104.5,
				angle: -.2328,
				front: 2526,
				poly: [
					[1288.2, 62.6],
					[1382.5, 70.8],
					[1376.4, 120],
					[1289.2, 163.1]
				],
				physical: "22",
				next: ["23"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			23: {
				x: 1426,
				y: 129.2,
				angle: .8235,
				front: 2618.7,
				poly: [
					[1388.7, 72.8],
					[1422.5, 83.1],
					[1455.4, 115.9],
					[1464.6, 132.3],
					[1472.8, 176.4],
					[1425.6, 177.4],
					[1382.5, 120]
				],
				physical: "23",
				next: ["38"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			25: {
				x: 283.1,
				y: 198.3,
				angle: -.2861,
				front: 1468,
				poly: [
					[325.1, 146.7],
					[327.2, 193.8],
					[281, 243.1],
					[234.9, 244.1],
					[240, 208.2],
					[256.4, 180.5],
					[293.3, 152.8]
				],
				physical: "25",
				next: ["13", "26"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					13: ["12", "26"],
					26: ["12", "13"]
				}
			},
			26: {
				x: 377.5,
				y: 170,
				angle: 0,
				front: 1563,
				poly: [
					[330, 145],
					[425, 145],
					[425, 195],
					[330, 195]
				],
				physical: "26",
				next: [
					"13",
					"14",
					"27"
				],
				direct: ["13", "27"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 14: ["13", "27"] }
			},
			27: {
				x: 473.6,
				y: 175.3,
				angle: -.0867,
				front: 1654.6,
				poly: [
					[425, 145],
					[517, 145],
					[517, 215],
					[425, 195]
				],
				physical: "27",
				next: [
					"4",
					"15",
					"28"
				],
				direct: ["28"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 4: ["14", "15"] }
			},
			28: {
				x: 565.5,
				y: 189,
				angle: 0,
				front: 1752.3,
				poly: [
					[517, 163],
					[614, 163],
					[614, 215],
					[517, 215]
				],
				physical: "28",
				next: ["16", "29"],
				direct: ["29"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 16: ["15", "29"] }
			},
			29: {
				x: 662.5,
				y: 189,
				angle: 0,
				front: 1849.3,
				poly: [
					[614, 163],
					[711, 163],
					[711, 215],
					[614, 215]
				],
				physical: "29",
				next: ["17", "30"],
				direct: ["30"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 17: ["16", "30"] }
			},
			30: {
				x: 760.5,
				y: 189,
				angle: 0,
				front: 1948.3,
				poly: [
					[711, 163],
					[810, 163],
					[810, 215],
					[711, 215]
				],
				physical: "30",
				next: ["18", "31"],
				direct: ["31"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 18: ["17", "31"] }
			},
			31: {
				x: 858,
				y: 189,
				angle: 0,
				front: 2044.3,
				poly: [
					[810, 163],
					[906, 163],
					[906, 215],
					[810, 215]
				],
				physical: "31",
				next: ["19", "32"],
				direct: ["32"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 19: ["18", "32"] }
			},
			32: {
				x: 954,
				y: 189,
				angle: 0,
				front: 2140.3,
				poly: [
					[906, 163],
					[1002, 163],
					[1002, 215],
					[906, 215]
				],
				physical: "32",
				next: ["20", "33"],
				direct: ["33"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 20: ["19", "33"] }
			},
			33: {
				x: 1051,
				y: 189,
				angle: 0,
				front: 2238.3,
				poly: [
					[1002, 163],
					[1100, 163],
					[1100, 215],
					[1002, 215]
				],
				physical: "33",
				next: ["21", "34"],
				direct: ["34"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 21: ["20", "34"] }
			},
			34: {
				x: 1146.5,
				y: 189,
				angle: 0,
				front: 2331.3,
				poly: [
					[1100, 163],
					[1193, 163],
					[1193, 215],
					[1100, 215]
				],
				physical: "34",
				next: ["35"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			35: {
				x: 1246.8,
				y: 154.9,
				angle: -.021,
				front: 2440,
				poly: [
					[1285.1, 116.9],
					[1285.1, 166.2],
					[1212.3, 202],
					[1213.3, 131.3]
				],
				physical: "35",
				next: ["22"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			36: {
				x: 214.1,
				y: 201.6,
				angle: -1.3507,
				front: 1379.4,
				poly: [
					[224.6, 144.6],
					[242, 161],
					[230.8, 243.1],
					[185.6, 245.1],
					[183.6, 221.5],
					[194.9, 182.6]
				],
				physical: "36",
				next: ["12", "25"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			38: {
				x: 1448.9,
				y: 231.7,
				angle: 1.5708,
				front: 2731,
				poly: [
					[1426.6, 181.5],
					[1473.8, 182.6],
					[1469.7, 283.1],
					[1425.6, 282]
				],
				physical: "38",
				next: ["50"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			39: {
				x: 205,
				y: 294,
				angle: -1.6802,
				front: 1303,
				poly: [
					[183, 246],
					[235, 246],
					[238, 337],
					[165, 337]
				],
				physical: "39",
				next: [
					"25",
					"36",
					"40"
				],
				direct: ["40"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			40: {
				x: 268.3,
				y: 294.5,
				angle: -1.6802,
				front: 1313.9,
				poly: [
					[235, 246],
					[285, 246],
					[313, 337],
					[238, 337]
				],
				physical: "40",
				next: ["25", "36"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			43: {
				x: 644,
				y: 339,
				angle: 3.1416,
				front: 3616,
				poly: [
					[605, 313],
					[683, 313],
					[683, 365],
					[605, 365]
				],
				physical: "43",
				next: ["56"],
				direct: ["56"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			44: {
				x: 753.5,
				y: 339,
				angle: 3.1416,
				front: 3516,
				poly: [
					[705, 313],
					[802, 313],
					[802, 365],
					[705, 365]
				],
				physical: "44",
				next: ["43", "57"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			45: {
				x: 850.5,
				y: 339,
				angle: 3.1416,
				front: 3419,
				poly: [
					[802, 313],
					[899, 313],
					[899, 365],
					[802, 365]
				],
				physical: "45",
				next: ["44", "58"],
				direct: ["44"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 58: ["59", "44"] }
			},
			46: {
				x: 947,
				y: 339,
				angle: 3.1416,
				front: 3322,
				poly: [
					[899, 313],
					[995, 313],
					[995, 365],
					[899, 365]
				],
				physical: "46",
				next: ["45", "59"],
				direct: ["45"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 59: ["60", "45"] }
			},
			47: {
				x: 1041,
				y: 339,
				angle: 3.1416,
				front: 3226,
				poly: [
					[995, 313],
					[1087, 313],
					[1087, 365],
					[995, 365]
				],
				physical: "47",
				next: ["46", "60"],
				direct: ["46"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 60: ["61", "46"] }
			},
			48: {
				x: 1135,
				y: 339,
				angle: 3.1416,
				front: 3134,
				poly: [
					[1087, 313],
					[1183, 313],
					[1183, 365],
					[1087, 365]
				],
				physical: "48",
				next: ["47", "61"],
				direct: ["47"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 61: ["62", "47"] }
			},
			49: {
				x: 1229,
				y: 339,
				angle: 3.1416,
				front: 3038,
				poly: [
					[1183, 313],
					[1275, 313],
					[1275, 365],
					[1183, 365]
				],
				physical: "49",
				next: ["48", "62"],
				direct: ["48"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 62: ["63", "48"] }
			},
			50: {
				x: 1441,
				y: 322.7,
				angle: 2.0344,
				front: 2796.5,
				poly: [
					[1470.7, 285.1],
					[1470.7, 316.9],
					[1460.5, 341.5],
					[1441, 368.2],
					[1431.8, 369.2],
					[1408.2, 335.4],
					[1424.6, 288.2]
				],
				physical: "50",
				next: ["64"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			52: {
				x: 190,
				y: 398.5,
				angle: -1.5708,
				front: 1192,
				poly: [
					[165, 355],
					[215, 355],
					[215, 442],
					[165, 442]
				],
				physical: "52",
				next: ["39", "40"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			53: {
				x: 240,
				y: 398.5,
				angle: -1.5708,
				front: 1192,
				poly: [
					[215, 355],
					[265, 355],
					[265, 442],
					[215, 442]
				],
				physical: "53",
				next: ["39", "40"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			54: {
				x: 290,
				y: 398.5,
				angle: -1.5708,
				front: 1192,
				poly: [
					[265, 355],
					[315, 355],
					[315, 442],
					[265, 442]
				],
				physical: "54",
				next: ["39", "40"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			55: {
				x: 455.6,
				y: 386.1,
				angle: 2.6779,
				front: 3830.6,
				poly: [
					[493.3, 328.2],
					[499.5, 383.6],
					[455.4, 433.8],
					[408.2, 432.8],
					[413.3, 394.9],
					[429.7, 365.1],
					[455.4, 343.6]
				],
				physical: "55",
				next: ["68"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			56: {
				x: 557.5,
				y: 359.2,
				angle: 3.1416,
				front: 3728.6,
				poly: [
					[500, 326],
					[605, 313],
					[605, 414],
					[500, 382]
				],
				physical: "56",
				next: ["55"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			57: {
				x: 644,
				y: 389.5,
				angle: 3.1416,
				front: 3616,
				poly: [
					[605, 365],
					[683, 365],
					[683, 414],
					[605, 414]
				],
				physical: "57",
				next: ["56"],
				direct: ["56"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			58: {
				x: 753.5,
				y: 389.5,
				angle: 3.1416,
				front: 3516,
				poly: [
					[705, 365],
					[802, 365],
					[802, 414],
					[705, 414]
				],
				physical: "58",
				next: ["43", "57"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			59: {
				x: 850.5,
				y: 389.5,
				angle: 3.1416,
				front: 3419,
				poly: [
					[802, 365],
					[899, 365],
					[899, 414],
					[802, 414]
				],
				physical: "59",
				next: ["44", "58"],
				direct: ["58"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 44: ["45", "58"] }
			},
			60: {
				x: 947,
				y: 389.5,
				angle: 3.1416,
				front: 3322,
				poly: [
					[899, 365],
					[995, 365],
					[995, 414],
					[899, 414]
				],
				physical: "60",
				next: ["45", "59"],
				direct: ["59"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 45: ["46", "59"] }
			},
			61: {
				x: 1041,
				y: 389.5,
				angle: 3.1416,
				front: 3226,
				poly: [
					[995, 365],
					[1087, 365],
					[1087, 414],
					[995, 414]
				],
				physical: "61",
				next: ["46", "60"],
				direct: ["60"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 46: ["47", "60"] }
			},
			62: {
				x: 1135,
				y: 389.5,
				angle: 3.1416,
				front: 3134,
				poly: [
					[1087, 365],
					[1183, 365],
					[1183, 414],
					[1087, 414]
				],
				physical: "62",
				next: ["47", "61"],
				direct: ["61"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 47: ["48", "61"] }
			},
			63: {
				x: 1229,
				y: 389.5,
				angle: 3.1416,
				front: 3038,
				poly: [
					[1183, 365],
					[1275, 365],
					[1275, 414],
					[1183, 414]
				],
				physical: "63",
				next: ["48", "62"],
				direct: ["62"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 48: ["49", "62"] }
			},
			64: {
				x: 1324.3,
				y: 365.8,
				angle: -3.0509,
				front: 2946,
				poly: [
					[1277.9, 311.8],
					[1376.4, 341.5],
					[1384.6, 393.8],
					[1336.4, 406.1],
					[1277.9, 409.2]
				],
				physical: "64",
				next: ["49", "63"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			65: {
				x: 190,
				y: 490,
				angle: -1.5708,
				front: 1105,
				poly: [
					[165, 442],
					[215, 442],
					[215, 538],
					[165, 538]
				],
				physical: "65",
				next: ["52", "53"],
				direct: ["52"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 53: ["66", "52"] }
			},
			66: {
				x: 240,
				y: 490,
				angle: -1.5708,
				front: 1105,
				poly: [
					[215, 442],
					[265, 442],
					[265, 538],
					[215, 538]
				],
				physical: "66",
				next: [
					"52",
					"53",
					"54"
				],
				direct: ["53"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					52: ["65", "53"],
					54: ["67", "53"]
				}
			},
			67: {
				x: 290,
				y: 490,
				angle: -1.5708,
				front: 1105,
				poly: [
					[265, 442],
					[315, 442],
					[315, 538],
					[265, 538]
				],
				physical: "67",
				next: ["53", "54"],
				direct: ["54"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 53: ["66", "54"] }
			},
			68: {
				x: 433,
				y: 487.5,
				angle: 1.5708,
				front: 3942.4,
				poly: [
					[408, 437],
					[458, 437],
					[458, 538],
					[408, 538]
				],
				physical: "68",
				next: ["82"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			71: {
				x: 754,
				y: 515.5,
				angle: 0,
				front: 4349.1,
				poly: [
					[706, 490],
					[802, 490],
					[802, 541],
					[706, 541]
				],
				physical: "71",
				next: ["72", "87"],
				direct: ["72"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 87: ["86", "72"] }
			},
			72: {
				x: 850.5,
				y: 515.5,
				angle: 0,
				front: 4446.1,
				poly: [
					[802, 490],
					[899, 490],
					[899, 541],
					[802, 541]
				],
				physical: "72",
				next: ["73", "88"],
				direct: ["73"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 88: ["87", "73"] }
			},
			73: {
				x: 947,
				y: 515.5,
				angle: 0,
				front: 4542.1,
				poly: [
					[899, 490],
					[995, 490],
					[995, 541],
					[899, 541]
				],
				physical: "73",
				next: ["74", "89"],
				direct: ["74"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 89: ["88", "74"] }
			},
			74: {
				x: 1041,
				y: 515.5,
				angle: 0,
				front: 4634.1,
				poly: [
					[995, 490],
					[1087, 490],
					[1087, 541],
					[995, 541]
				],
				physical: "74",
				next: ["75", "90"],
				direct: ["75"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 90: ["89", "75"] }
			},
			75: {
				x: 1135,
				y: 515.5,
				angle: 0,
				front: 4730.1,
				poly: [
					[1087, 490],
					[1183, 490],
					[1183, 541],
					[1087, 541]
				],
				physical: "75",
				next: ["76", "91"],
				direct: ["76"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 91: ["90", "76"] }
			},
			76: {
				x: 1231,
				y: 515.5,
				angle: 0,
				front: 4826.1,
				poly: [
					[1183, 490],
					[1279, 490],
					[1279, 541],
					[1183, 541]
				],
				physical: "76",
				next: [
					"77",
					"91",
					"92"
				],
				direct: ["77", "91"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 92: ["91", "77"] }
			},
			77: {
				x: 1321.4,
				y: 520.3,
				angle: .4466,
				front: 4914.3,
				poly: [
					[1279, 490.2],
					[1338.4, 496.4],
					[1372.3, 514.9],
					[1351.8, 552.8],
					[1280, 537.4]
				],
				physical: "77",
				next: ["94"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			79: {
				x: 190,
				y: 585,
				angle: -1.5708,
				front: 1009,
				poly: [
					[165, 538],
					[215, 538],
					[215, 632],
					[165, 632]
				],
				physical: "79",
				next: ["65", "66"],
				direct: ["65"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 66: ["80", "65"] }
			},
			80: {
				x: 240,
				y: 585,
				angle: -1.5708,
				front: 1009,
				poly: [
					[215, 538],
					[265, 538],
					[265, 632],
					[215, 632]
				],
				physical: "80",
				next: [
					"65",
					"66",
					"67"
				],
				direct: ["66"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					65: ["79", "66"],
					67: ["81", "66"]
				}
			},
			81: {
				x: 290,
				y: 585,
				angle: -1.5708,
				front: 1009,
				poly: [
					[265, 538],
					[315, 538],
					[315, 632],
					[265, 632]
				],
				physical: "81",
				next: ["66", "67"],
				direct: ["67"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 66: ["80", "67"] }
			},
			82: {
				x: 455.7,
				y: 587.4,
				angle: 1.1284,
				front: 4039.9,
				poly: [
					[409.2, 540.5],
					[453.3, 539.5],
					[501.5, 594.9],
					[493.3, 642],
					[454.4, 629.7],
					[430.8, 608.2],
					[413.3, 576.4]
				],
				physical: "82",
				next: ["96"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			85: {
				x: 657.5,
				y: 547.7,
				angle: -.1338,
				front: 4253.1,
				poly: [
					[602, 543],
					[706, 490],
					[706, 568],
					[602, 595]
				],
				physical: "85",
				next: [
					"71",
					"86",
					"98"
				],
				direct: ["71"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 98: ["97", "86"] }
			},
			86: {
				x: 754,
				y: 566,
				angle: 0,
				front: 4349.1,
				poly: [
					[706, 541],
					[802, 541],
					[802, 591],
					[706, 591]
				],
				physical: "86",
				next: [
					"72",
					"87",
					"99"
				],
				direct: ["87"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					72: ["71", "87"],
					99: ["98", "87"]
				}
			},
			87: {
				x: 850.5,
				y: 566,
				angle: 0,
				front: 4446.1,
				poly: [
					[802, 541],
					[899, 541],
					[899, 591],
					[802, 591]
				],
				physical: "87",
				next: [
					"73",
					"88",
					"100"
				],
				direct: ["88"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					73: ["72", "88"],
					100: ["99", "88"]
				}
			},
			88: {
				x: 947,
				y: 566,
				angle: 0,
				front: 4542.1,
				poly: [
					[899, 541],
					[995, 541],
					[995, 591],
					[899, 591]
				],
				physical: "88",
				next: [
					"74",
					"89",
					"101"
				],
				direct: ["89"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					74: ["73", "89"],
					101: ["100", "89"]
				}
			},
			89: {
				x: 1041,
				y: 566,
				angle: 0,
				front: 4634.1,
				poly: [
					[995, 541],
					[1087, 541],
					[1087, 591],
					[995, 591]
				],
				physical: "89",
				next: [
					"75",
					"90",
					"102"
				],
				direct: ["90"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					75: ["74", "90"],
					102: ["101", "90"]
				}
			},
			90: {
				x: 1135,
				y: 566,
				angle: 0,
				front: 4730.1,
				poly: [
					[1087, 541],
					[1183, 541],
					[1183, 591],
					[1087, 591]
				],
				physical: "90",
				next: [
					"76",
					"91",
					"103"
				],
				direct: ["91"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 76: ["75", "91"] }
			},
			91: {
				x: 1231,
				y: 566,
				angle: 0,
				front: 4836.8,
				poly: [
					[1183, 541],
					[1279, 541],
					[1279, 591],
					[1183, 591]
				],
				physical: "91",
				next: [
					"77",
					"92",
					"103",
					"104"
				],
				direct: ["103"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					77: ["76", "92"],
					92: ["76", "77"]
				}
			},
			92: {
				x: 1323.8,
				y: 575.9,
				angle: .4466,
				front: 4914.3,
				poly: [
					[1280, 542.6],
					[1333.3, 549.7],
					[1379.5, 580.5],
					[1349.7, 611.3],
					[1281, 587.7]
				],
				physical: "92",
				next: [
					"94",
					"104",
					"106"
				],
				direct: ["104"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			94: {
				x: 1399.2,
				y: 562.5,
				angle: .7393,
				front: 4990.5,
				poly: [
					[1375.4, 515.9],
					[1407.2, 533.3],
					[1448.2, 583.6],
					[1408.2, 606.1],
					[1355.9, 555.9]
				],
				physical: "94",
				next: ["106", "107"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			96: {
				x: 556.6,
				y: 603.4,
				angle: -.3393,
				front: 4153,
				poly: [
					[500, 592],
					[602, 543],
					[602, 642],
					[500, 642]
				],
				physical: "96",
				next: ["85", "97"],
				direct: ["85", "97"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			97: {
				x: 657.9,
				y: 611.2,
				angle: -.1338,
				front: 4252.8,
				poly: [
					[602, 595],
					[706, 568],
					[706, 642],
					[602, 642]
				],
				physical: "97",
				next: [
					"71",
					"86",
					"98"
				],
				direct: ["98"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 71: ["85", "86"] }
			},
			98: {
				x: 754,
				y: 616.5,
				angle: 0,
				front: 4349.1,
				poly: [
					[706, 591],
					[802, 591],
					[802, 642],
					[706, 642]
				],
				physical: "98",
				next: ["87", "99"],
				direct: ["99"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 87: ["86", "99"] }
			},
			99: {
				x: 850.5,
				y: 616.5,
				angle: 0,
				front: 4446.1,
				poly: [
					[802, 591],
					[899, 591],
					[899, 642],
					[802, 642]
				],
				physical: "99",
				next: ["88", "100"],
				direct: ["100"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 88: ["87", "100"] }
			},
			100: {
				x: 947,
				y: 616.5,
				angle: 0,
				front: 4542.1,
				poly: [
					[899, 591],
					[995, 591],
					[995, 642],
					[899, 642]
				],
				physical: "100",
				next: ["89", "101"],
				direct: ["101"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 89: ["88", "101"] }
			},
			101: {
				x: 1041,
				y: 616.5,
				angle: 0,
				front: 4634.1,
				poly: [
					[995, 591],
					[1087, 591],
					[1087, 642],
					[995, 642]
				],
				physical: "101",
				next: ["90", "102"],
				direct: ["102"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 90: ["89", "102"] }
			},
			102: {
				x: 1135,
				y: 616.5,
				angle: 0,
				front: 4730.1,
				poly: [
					[1087, 591],
					[1183, 591],
					[1183, 642],
					[1087, 642]
				],
				physical: "102",
				next: ["91", "103"],
				direct: ["103"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			103: {
				x: 1231,
				y: 616.5,
				angle: 0,
				front: 4858.9,
				poly: [
					[1183, 591],
					[1279, 591],
					[1279, 642],
					[1183, 642]
				],
				physical: "103",
				next: ["92", "104"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			104: {
				x: 1325.6,
				y: 640.3,
				angle: 1.0321,
				front: 4990.5,
				poly: [
					[1280, 591.8],
					[1313.8, 595.9],
					[1347.7, 616.4],
					[1370.2, 649.2],
					[1376.4, 684.1],
					[1330.2, 685.1],
					[1280, 636.9]
				],
				physical: "104",
				next: [
					"106",
					"120",
					"121"
				],
				direct: ["106"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			106: {
				x: 1389.7,
				y: 640,
				angle: 1.0321,
				front: 5006.1,
				poly: [
					[1382.5, 582.6],
					[1418.4, 634.9],
					[1425.6, 684.1],
					[1379.5, 684.1],
					[1351.8, 614.3]
				],
				physical: "106",
				next: [
					"120",
					"121",
					"122"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					121: ["107", "122"],
					122: ["107", "121"]
				}
			},
			107: {
				x: 1446.6,
				y: 641.5,
				angle: 1.0321,
				front: 5006.1,
				poly: [
					[1449.2, 586.7],
					[1471.8, 633.8],
					[1476.9, 684.1],
					[1429.7, 683.1],
					[1415.4, 612.3]
				],
				physical: "107",
				next: ["121", "122"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					121: ["106", "122"],
					122: ["106", "121"]
				}
			},
			108: {
				x: 190,
				y: 679,
				angle: -1.5708,
				front: 915,
				poly: [
					[165, 632],
					[215, 632],
					[215, 726],
					[165, 726]
				],
				physical: "108",
				next: ["79", "80"],
				direct: ["79"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 80: ["110", "79"] }
			},
			110: {
				x: 240,
				y: 679,
				angle: -1.5708,
				front: 915,
				poly: [
					[215, 632],
					[265, 632],
					[265, 726],
					[215, 726]
				],
				physical: "110",
				next: [
					"79",
					"80",
					"81"
				],
				direct: ["80"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					79: ["108", "80"],
					81: ["113", "80"]
				}
			},
			113: {
				x: 290,
				y: 679,
				angle: -1.5708,
				front: 915,
				poly: [
					[265, 632],
					[315, 632],
					[315, 726],
					[265, 726]
				],
				physical: "113",
				next: ["80", "81"],
				direct: ["81"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 80: ["110", "81"] }
			},
			120: {
				x: 1353,
				y: 734,
				angle: 1.5708,
				front: 5122.3,
				poly: [
					[1328, 687],
					[1378, 687],
					[1378, 781],
					[1328, 781]
				],
				physical: "120",
				next: ["138", "139"],
				direct: ["138"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			121: {
				x: 1403,
				y: 734,
				angle: 1.5708,
				front: 5107.3,
				poly: [
					[1378, 687],
					[1428, 687],
					[1428, 781],
					[1378, 781]
				],
				physical: "121",
				next: [
					"120",
					"138",
					"139",
					"140"
				],
				direct: ["120"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					139: ["122", "140"],
					140: ["122", "139"]
				}
			},
			122: {
				x: 1453,
				y: 734,
				angle: 1.5708,
				front: 5100.1,
				poly: [
					[1428, 687],
					[1478, 687],
					[1478, 781],
					[1428, 781]
				],
				physical: "122",
				next: [
					"121",
					"139",
					"140"
				],
				direct: ["121"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {
					139: ["121", "140"],
					140: ["121", "139"]
				}
			},
			125: {
				x: 205.7,
				y: 772.9,
				angle: -1.5708,
				front: 821,
				poly: [
					[165, 726],
					[239, 726],
					[234, 827],
					[186, 827]
				],
				physical: "125",
				next: [
					"108",
					"110",
					"113"
				],
				direct: ["108"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 113: ["126", "110"] }
			},
			126: {
				x: 267.8,
				y: 773.1,
				angle: -1.5708,
				front: 821,
				poly: [
					[239, 726],
					[313, 726],
					[283, 827],
					[234, 827]
				],
				physical: "126",
				next: [
					"108",
					"110",
					"113"
				],
				direct: ["113"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 108: ["125", "110"] }
			},
			129: {
				x: 472.5,
				y: 824.5,
				angle: 3.1416,
				front: 475,
				poly: [
					[425, 800],
					[520, 800],
					[520, 849],
					[425, 849]
				],
				physical: "129",
				next: ["145"],
				direct: ["145"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			130: {
				x: 567.5,
				y: 824.5,
				angle: 3.1416,
				front: 380,
				poly: [
					[520, 800],
					[615, 800],
					[615, 849],
					[520, 849]
				],
				physical: "130",
				next: ["129", "146"],
				direct: ["129"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 146: ["147", "129"] }
			},
			131: {
				x: 663,
				y: 824.5,
				angle: 3.1416,
				front: 285,
				poly: [
					[615, 800],
					[711, 800],
					[711, 849],
					[615, 849]
				],
				physical: "131",
				next: ["130", "147"],
				direct: ["130"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 147: ["148", "130"] }
			},
			132: {
				x: 759,
				y: 824.5,
				angle: 3.1416,
				front: 189,
				poly: [
					[711, 800],
					[807, 800],
					[807, 849],
					[711, 849]
				],
				physical: "132",
				next: ["131", "148"],
				direct: ["131"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 148: ["149", "131"] }
			},
			133: {
				x: 853.5,
				y: 824.5,
				angle: 3.1416,
				front: 93,
				poly: [
					[807, 800],
					[900, 800],
					[900, 849],
					[807, 849]
				],
				physical: "133",
				next: ["132", "149"],
				direct: ["132"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 149: ["150", "132"] }
			},
			134: {
				x: 949,
				y: 824.5,
				angle: 3.1416,
				front: 0,
				poly: [
					[900, 800],
					[998, 800],
					[998, 849],
					[900, 849]
				],
				physical: "134",
				next: ["133", "150"],
				direct: ["133"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 150: ["151", "133"] }
			},
			135: {
				x: 1043,
				y: 824.5,
				angle: 3.1416,
				front: 5591.1,
				poly: [
					[998, 800],
					[1088, 800],
					[1088, 849],
					[998, 849]
				],
				physical: "135",
				next: ["134", "151"],
				direct: ["134"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 151: ["152", "134"] }
			},
			136: {
				x: 1135.5,
				y: 824.5,
				angle: 3.1416,
				front: 5501.1,
				poly: [
					[1088, 800],
					[1183, 800],
					[1183, 849],
					[1088, 849]
				],
				physical: "136",
				next: ["135", "152"],
				direct: ["135"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 152: ["153", "135"] }
			},
			137: {
				x: 1228,
				y: 845.3,
				angle: 3.1416,
				front: 5406.1,
				poly: [
					[1183, 800],
					[1279, 833],
					[1279, 881],
					[1183, 870]
				],
				physical: "137",
				next: [
					"136",
					"153",
					"164",
					"165"
				],
				direct: ["136"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			138: {
				x: 1324.5,
				y: 826,
				angle: 2.2554,
				front: 5282.5,
				poly: [
					[1328, 781],
					[1378, 781],
					[1352, 849],
					[1279, 881],
					[1279, 833]
				],
				physical: "138",
				next: [
					"137",
					"154",
					"165"
				],
				direct: ["137"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			139: {
				x: 1390.5,
				y: 825.9,
				angle: 1.8753,
				front: 5282.5,
				poly: [
					[1425.6, 782.6],
					[1420.5, 824.6],
					[1394.8, 871.8],
					[1372.3, 871.8],
					[1352.8, 851.3],
					[1379.5, 784.6]
				],
				physical: "139",
				next: ["154", "166"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			140: {
				x: 1446.5,
				y: 824.6,
				angle: 1.8753,
				front: 5282.5,
				poly: [
					[1430.7, 782.6],
					[1476.9, 783.6],
					[1473.8, 822.6],
					[1453.3, 875.9],
					[1414.3, 856.4]
				],
				physical: "140",
				next: ["166"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			142: {
				x: 217.2,
				y: 866.8,
				angle: -1.9839,
				front: 720,
				poly: [
					[186.7, 827.7],
					[228.7, 828.7],
					[253.3, 901.5],
					[218.5, 907.7],
					[199, 890.2],
					[188.7, 863.6]
				],
				physical: "142",
				next: ["125", "126"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					125: ["143", "126"],
					126: ["143", "125"]
				}
			},
			143: {
				x: 284.7,
				y: 873.3,
				angle: -1.9839,
				front: 720,
				poly: [
					[235.9, 827.7],
					[283.1, 828.7],
					[329.2, 877.9],
					[328.2, 925.1],
					[293.3, 917.9],
					[256.4, 890.2],
					[237.9, 854.3]
				],
				physical: "143",
				next: ["125", "126"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					125: ["142", "126"],
					126: ["142", "125"]
				}
			},
			145: {
				x: 383.1,
				y: 876.3,
				angle: 2.855,
				front: 595.2,
				poly: [
					[330, 878],
					[380, 850],
					[425, 800],
					[425, 899],
					[330, 928]
				],
				physical: "145",
				next: [
					"143",
					"156",
					"167"
				],
				direct: ["167"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			146: {
				x: 472.5,
				y: 874.5,
				angle: 3.1416,
				front: 475,
				poly: [
					[425, 849],
					[520, 849],
					[520, 900],
					[425, 900]
				],
				physical: "146",
				next: ["145", "167"],
				direct: ["145"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			147: {
				x: 567.5,
				y: 874.5,
				angle: 3.1416,
				front: 380,
				poly: [
					[520, 849],
					[615, 849],
					[615, 900],
					[520, 900]
				],
				physical: "147",
				next: [
					"129",
					"146",
					"157"
				],
				direct: ["146"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					129: ["130", "146"],
					157: ["158", "146"]
				}
			},
			148: {
				x: 663,
				y: 874.5,
				angle: 3.1416,
				front: 285,
				poly: [
					[615, 849],
					[711, 849],
					[711, 900],
					[615, 900]
				],
				physical: "148",
				next: [
					"130",
					"147",
					"158"
				],
				direct: ["147"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					130: ["131", "147"],
					158: ["159", "147"]
				}
			},
			149: {
				x: 759,
				y: 874.5,
				angle: 3.1416,
				front: 189,
				poly: [
					[711, 849],
					[807, 849],
					[807, 900],
					[711, 900]
				],
				physical: "149",
				next: [
					"131",
					"148",
					"159"
				],
				direct: ["148"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					131: ["132", "148"],
					159: ["160", "148"]
				}
			},
			150: {
				x: 853.5,
				y: 874.5,
				angle: 3.1416,
				front: 93,
				poly: [
					[807, 849],
					[900, 849],
					[900, 900],
					[807, 900]
				],
				physical: "150",
				next: [
					"132",
					"149",
					"160"
				],
				direct: ["149"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					132: ["133", "149"],
					160: ["161", "149"]
				}
			},
			151: {
				x: 949,
				y: 874.5,
				angle: 3.1416,
				front: 0,
				poly: [
					[900, 849],
					[998, 849],
					[998, 900],
					[900, 900]
				],
				physical: "151",
				next: [
					"133",
					"150",
					"161"
				],
				direct: ["150"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					133: ["134", "150"],
					161: ["162", "150"]
				}
			},
			152: {
				x: 1043,
				y: 874.5,
				angle: 3.1416,
				front: 5591.1,
				poly: [
					[998, 849],
					[1088, 849],
					[1088, 900],
					[998, 900]
				],
				physical: "152",
				next: [
					"134",
					"151",
					"162"
				],
				direct: ["151"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					134: ["135", "151"],
					162: ["163", "151"]
				}
			},
			153: {
				x: 1135.5,
				y: 874.5,
				angle: 3.1416,
				front: 5501.1,
				poly: [
					[1088, 849],
					[1183, 849],
					[1183, 900],
					[1088, 900]
				],
				physical: "153",
				next: [
					"135",
					"152",
					"163"
				],
				direct: ["152"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					135: ["136", "152"],
					163: ["164", "152"]
				}
			},
			154: {
				x: 1324.9,
				y: 892.5,
				angle: 2.6714,
				front: 5300,
				poly: [
					[1380.5, 885.1],
					[1335.4, 917.9],
					[1281, 927.2],
					[1282, 882],
					[1351.8, 856.4]
				],
				physical: "154",
				next: [
					"137",
					"165",
					"176",
					"177"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			156: {
				x: 286.2,
				y: 940.2,
				angle: -2.705,
				front: 644,
				poly: [
					[229.7, 930.2],
					[259.5, 900.5],
					[328.2, 928.2],
					[329.2, 982.5],
					[270.8, 964.1]
				],
				physical: "156",
				next: ["142", "143"],
				direct: ["143"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			157: {
				x: 472.5,
				y: 925,
				angle: 3.1416,
				front: 475,
				poly: [
					[425, 900],
					[520, 900],
					[520, 950],
					[425, 950]
				],
				physical: "157",
				next: ["145", "167"],
				direct: ["167"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			158: {
				x: 567.5,
				y: 925,
				angle: 3.1416,
				front: 380,
				poly: [
					[520, 900],
					[615, 900],
					[615, 950],
					[520, 950]
				],
				physical: "158",
				next: [
					"146",
					"157",
					"168"
				],
				direct: ["157"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					146: ["147", "157"],
					168: ["169", "157"]
				}
			},
			159: {
				x: 663,
				y: 925,
				angle: 3.1416,
				front: 285,
				poly: [
					[615, 900],
					[711, 900],
					[711, 950],
					[615, 950]
				],
				physical: "159",
				next: [
					"147",
					"158",
					"169"
				],
				direct: ["158"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					147: ["148", "158"],
					169: ["170", "158"]
				}
			},
			160: {
				x: 759,
				y: 925,
				angle: 3.1416,
				front: 189,
				poly: [
					[711, 900],
					[807, 900],
					[807, 950],
					[711, 950]
				],
				physical: "160",
				next: [
					"148",
					"159",
					"170"
				],
				direct: ["159"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					148: ["149", "159"],
					170: ["171", "159"]
				}
			},
			161: {
				x: 853.5,
				y: 925,
				angle: 3.1416,
				front: 93,
				poly: [
					[807, 900],
					[900, 900],
					[900, 950],
					[807, 950]
				],
				physical: "161",
				next: [
					"149",
					"160",
					"171"
				],
				direct: ["160"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					149: ["150", "160"],
					171: ["172", "160"]
				}
			},
			162: {
				x: 949,
				y: 925,
				angle: 3.1416,
				front: 0,
				poly: [
					[900, 900],
					[998, 900],
					[998, 950],
					[900, 950]
				],
				physical: "162",
				next: [
					"150",
					"161",
					"172"
				],
				direct: ["161"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					150: ["151", "161"],
					172: ["173", "161"]
				}
			},
			163: {
				x: 1043,
				y: 925,
				angle: 3.1416,
				front: 5591.1,
				poly: [
					[998, 900],
					[1088, 900],
					[1088, 950],
					[998, 950]
				],
				physical: "163",
				next: [
					"151",
					"162",
					"173"
				],
				direct: ["162"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					151: ["152", "162"],
					173: ["174", "162"]
				}
			},
			164: {
				x: 1135.5,
				y: 925,
				angle: 3.1416,
				front: 5501.1,
				poly: [
					[1088, 900],
					[1183, 900],
					[1183, 950],
					[1088, 950]
				],
				physical: "164",
				next: [
					"152",
					"163",
					"174"
				],
				direct: ["163"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					152: ["153", "163"],
					174: ["175", "163"]
				}
			},
			165: {
				x: 1231,
				y: 906.5,
				angle: 3.1416,
				front: 5450,
				poly: [
					[1183, 881],
					[1279, 881],
					[1279, 932],
					[1183, 932]
				],
				physical: "165",
				next: [
					"136",
					"153",
					"164",
					"175"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 175: ["176", "164"] }
			},
			166: {
				x: 1401.1,
				y: 902.5,
				angle: 2.2554,
				front: 5300,
				poly: [
					[1448.2, 880],
					[1430.7, 910.8],
					[1380.5, 950.8],
					[1356.9, 910.8],
					[1408.2, 859.5]
				],
				physical: "166",
				next: ["177"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			167: {
				x: 381.6,
				y: 952.9,
				angle: 2.855,
				front: 644,
				poly: [
					[330, 928],
					[425, 899],
					[425, 999],
					[330, 987]
				],
				physical: "167",
				next: ["143"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			168: {
				x: 472.5,
				y: 974.5,
				angle: 3.1416,
				front: 475,
				poly: [
					[425, 950],
					[520, 950],
					[520, 999],
					[425, 999]
				],
				physical: "168",
				next: ["167"],
				direct: ["167"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			169: {
				x: 567.5,
				y: 974.5,
				angle: 3.1416,
				front: 380,
				poly: [
					[520, 950],
					[615, 950],
					[615, 999],
					[520, 999]
				],
				physical: "169",
				next: ["157", "168"],
				direct: ["168"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 157: ["158", "168"] }
			},
			170: {
				x: 663,
				y: 974.5,
				angle: 3.1416,
				front: 285,
				poly: [
					[615, 950],
					[711, 950],
					[711, 999],
					[615, 999]
				],
				physical: "170",
				next: ["158", "169"],
				direct: ["169"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 158: ["159", "169"] }
			},
			171: {
				x: 759,
				y: 974.5,
				angle: 3.1416,
				front: 189,
				poly: [
					[711, 950],
					[807, 950],
					[807, 999],
					[711, 999]
				],
				physical: "171",
				next: ["159", "170"],
				direct: ["170"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 159: ["160", "170"] }
			},
			172: {
				x: 853.5,
				y: 974.5,
				angle: 3.1416,
				front: 93,
				poly: [
					[807, 950],
					[900, 950],
					[900, 999],
					[807, 999]
				],
				physical: "172",
				next: ["160", "171"],
				direct: ["171"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 160: ["161", "171"] }
			},
			173: {
				x: 949,
				y: 974.5,
				angle: 3.1416,
				front: 0,
				poly: [
					[900, 950],
					[998, 950],
					[998, 999],
					[900, 999]
				],
				physical: "173",
				next: ["161", "172"],
				direct: ["172"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 161: ["162", "172"] }
			},
			174: {
				x: 1043,
				y: 974.5,
				angle: 3.1416,
				front: 5591.1,
				poly: [
					[998, 950],
					[1088, 950],
					[1088, 999],
					[998, 999]
				],
				physical: "174",
				next: ["162", "173"],
				direct: ["173"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 162: ["163", "173"] }
			},
			175: {
				x: 1135.5,
				y: 974.5,
				angle: 3.1416,
				front: 5501.1,
				poly: [
					[1088, 950],
					[1183, 950],
					[1183, 999],
					[1088, 999]
				],
				physical: "175",
				next: ["163", "174"],
				direct: ["174"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 163: ["164", "174"] }
			},
			176: {
				x: 1229.1,
				y: 962.1,
				angle: 3.1416,
				front: 5450,
				poly: [
					[1183, 932],
					[1279, 932],
					[1279, 985],
					[1183, 999]
				],
				physical: "176",
				next: [
					"153",
					"164",
					"175"
				],
				direct: ["175"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 153: ["165", "164"] }
			},
			177: {
				x: 1323.1,
				y: 949.1,
				angle: 2.6714,
				front: 5360,
				poly: [
					[1353.8, 913.8],
					[1375.4, 953.8],
					[1333.3, 973.3],
					[1283.1, 985.6],
					[1281, 933.3]
				],
				physical: "177",
				next: ["165", "176"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			}
		},
		jumps: [],
		animals: []
	},
	marina: {
		width: 1590,
		height: 1080,
		length: 5437.2,
		closed: !0,
		starts: [
			"87",
			"90",
			"103",
			"104",
			"105",
			"106"
		],
		firstStart: "90",
		bets: [
			1176.3,
			2507.9,
			3683
		],
		nodes: {
			2: {
				x: 425.7,
				y: 96.3,
				angle: .0484,
				front: 728.7,
				poly: [
					[382.6, 67.6],
					[474, 66.6],
					[475, 113.3],
					[382.6, 136.1]
				],
				physical: "2",
				next: ["3"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			3: {
				x: 520,
				y: 90,
				angle: .0484,
				front: 816.7,
				poly: [
					[477, 65],
					[563, 65],
					[563, 115],
					[477, 115]
				],
				physical: "3",
				next: ["4", "11"],
				direct: ["4"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			4: {
				x: 606.5,
				y: 90,
				angle: .0484,
				front: 903.6,
				poly: [
					[563, 65],
					[650, 65],
					[650, 115],
					[563, 115]
				],
				physical: "4",
				next: ["5", "12"],
				direct: ["5"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 12: ["11", "5"] }
			},
			5: {
				x: 694,
				y: 90,
				angle: .0484,
				front: 991.5,
				poly: [
					[650, 65],
					[738, 65],
					[738, 115],
					[650, 115]
				],
				physical: "5",
				next: ["6", "13"],
				direct: ["6"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 13: ["12", "6"] }
			},
			6: {
				x: 782,
				y: 90,
				angle: .0484,
				front: 1079.4,
				poly: [
					[738, 65],
					[826, 65],
					[826, 115],
					[738, 115]
				],
				physical: "6",
				next: ["7", "14"],
				direct: ["7"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 14: ["13", "7"] }
			},
			7: {
				x: 869.5,
				y: 90,
				angle: .0484,
				front: 1166.3,
				poly: [
					[826, 65],
					[913, 65],
					[913, 115],
					[826, 115]
				],
				physical: "7",
				next: ["8", "15"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			8: {
				x: 966.5,
				y: 88.5,
				angle: .0484,
				front: 1254.1,
				poly: [
					[932, 64],
					[1001, 64],
					[1001, 113],
					[932, 113]
				],
				physical: "8",
				next: ["10", "16"],
				direct: ["10"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 16: ["15", "10"] }
			},
			10: {
				x: 1046,
				y: 88.5,
				angle: .0706,
				front: 1343.3,
				poly: [
					[1001, 64],
					[1091, 64],
					[1091, 113],
					[1001, 113]
				],
				physical: "10",
				next: ["17"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			11: {
				x: 606.5,
				y: 140,
				angle: .0484,
				front: 906,
				poly: [
					[563, 115],
					[650, 115],
					[650, 165],
					[563, 165]
				],
				physical: "11",
				next: [
					"5",
					"12",
					"21"
				],
				direct: ["12"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 5: ["4", "12"] }
			},
			12: {
				x: 694,
				y: 140,
				angle: .0484,
				front: 993.9,
				poly: [
					[650, 115],
					[738, 115],
					[738, 165],
					[650, 165]
				],
				physical: "12",
				next: [
					"6",
					"13",
					"22"
				],
				direct: ["13"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					6: ["5", "13"],
					22: ["21", "13"]
				}
			},
			13: {
				x: 782,
				y: 140,
				angle: .0484,
				front: 1081.8,
				poly: [
					[738, 115],
					[826, 115],
					[826, 165],
					[738, 165]
				],
				physical: "13",
				next: [
					"7",
					"14",
					"23"
				],
				direct: ["14"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					7: ["6", "14"],
					23: ["22", "14"]
				}
			},
			14: {
				x: 869.5,
				y: 140,
				angle: .0484,
				front: 1168.7,
				poly: [
					[826, 115],
					[913, 115],
					[913, 165],
					[826, 165]
				],
				physical: "14",
				next: [
					"8",
					"15",
					"24"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			15: {
				x: 966.5,
				y: 137,
				angle: .0484,
				front: 1256.4,
				poly: [
					[932, 113],
					[1001, 113],
					[1001, 161],
					[932, 161]
				],
				physical: "15",
				next: [
					"10",
					"16",
					"25"
				],
				direct: ["16"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					10: ["8", "16"],
					25: ["24", "16"]
				}
			},
			16: {
				x: 1046,
				y: 137,
				angle: .0706,
				front: 1346.7,
				poly: [
					[1001, 113],
					[1091, 113],
					[1091, 161],
					[1001, 161]
				],
				physical: "16",
				next: ["17", "26"],
				direct: ["17"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 26: ["25", "17"] }
			},
			17: {
				x: 1139,
				y: 135,
				angle: .0706,
				front: 1442.4,
				poly: [
					[1091, 109],
					[1187, 109],
					[1187, 161],
					[1091, 161]
				],
				physical: "17",
				next: ["18", "27"],
				direct: ["18"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 27: ["26", "18"] }
			},
			18: {
				x: 1235,
				y: 135,
				angle: .0706,
				front: 1538.2,
				poly: [
					[1187, 109],
					[1283, 109],
					[1283, 161],
					[1187, 161]
				],
				physical: "18",
				next: ["28"],
				direct: ["28"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			19: {
				x: 326.8,
				y: 151.8,
				angle: -.7086,
				front: 652.4,
				poly: [
					[273, 198],
					[278, 166],
					[293, 137],
					[319, 115],
					[348, 103],
					[381, 99],
					[381, 133],
					[358, 147],
					[347, 170],
					[347, 198]
				],
				physical: "19",
				next: ["2"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			21: {
				x: 694,
				y: 188.5,
				angle: .0484,
				front: 996.2,
				poly: [
					[650, 165],
					[738, 165],
					[738, 212],
					[650, 212]
				],
				physical: "21",
				next: ["13", "22"],
				direct: ["22"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 13: ["12", "22"] }
			},
			22: {
				x: 782,
				y: 188.5,
				angle: .0484,
				front: 1084.1,
				poly: [
					[738, 165],
					[826, 165],
					[826, 212],
					[738, 212]
				],
				physical: "22",
				next: ["14", "23"],
				direct: ["23"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 14: ["13", "23"] }
			},
			23: {
				x: 869.5,
				y: 188.5,
				angle: .0484,
				front: 1171,
				poly: [
					[826, 165],
					[913, 165],
					[913, 212],
					[826, 212]
				],
				physical: "23",
				next: ["15", "24"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			24: {
				x: 966.5,
				y: 186.5,
				angle: .0484,
				front: 1258.9,
				poly: [
					[932, 161],
					[1001, 161],
					[1001, 212],
					[932, 212]
				],
				physical: "24",
				next: ["16", "25"],
				direct: ["25"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 16: ["15", "25"] }
			},
			25: {
				x: 1046,
				y: 186.5,
				angle: .0706,
				front: 1350.3,
				poly: [
					[1001, 161],
					[1091, 161],
					[1091, 212],
					[1001, 212]
				],
				physical: "25",
				next: ["17", "26"],
				direct: ["26"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 17: ["16", "26"] }
			},
			26: {
				x: 1139,
				y: 186,
				angle: .0706,
				front: 1445.9,
				poly: [
					[1091, 161],
					[1187, 161],
					[1187, 211],
					[1091, 211]
				],
				physical: "26",
				next: ["18", "27"],
				direct: ["27"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 18: ["17", "27"] }
			},
			27: {
				x: 1235,
				y: 186,
				angle: .0706,
				front: 1541.7,
				poly: [
					[1187, 161],
					[1283, 161],
					[1283, 211],
					[1187, 211]
				],
				physical: "27",
				next: ["28"],
				direct: ["28"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			28: {
				x: 1327.6,
				y: 184.7,
				angle: .555,
				front: 1668,
				poly: [
					[1284.9, 105.3],
					[1303.8, 109.3],
					[1344.5, 137.1],
					[1372.4, 185.8],
					[1382.3, 245.5],
					[1337.6, 252.4],
					[1283.9, 207.7]
				],
				physical: "28",
				next: ["41"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			29: {
				x: 222,
				y: 245.5,
				angle: -1.561,
				front: 473.8,
				poly: [
					[197, 198],
					[247, 198],
					[247, 293],
					[197, 293]
				],
				physical: "29",
				next: ["19", "nw-outer"],
				direct: ["nw-outer"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 19: ["30", "nw-outer"] }
			},
			30: {
				x: 272,
				y: 245.5,
				angle: -1.561,
				front: 474.3,
				poly: [
					[247, 198],
					[297, 198],
					[297, 293],
					[247, 293]
				],
				physical: "30",
				next: ["19", "nw-outer"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			31: {
				x: 322,
				y: 245.5,
				angle: -1.561,
				front: 474.7,
				poly: [
					[297, 198],
					[347, 198],
					[347, 293],
					[297, 293]
				],
				physical: "31",
				next: ["19", "nw-outer"],
				direct: ["19"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { "nw-outer": ["30", "19"] }
			},
			35: {
				x: 222,
				y: 341,
				angle: -1.5708,
				front: 379,
				poly: [
					[197, 293],
					[247, 293],
					[247, 389],
					[197, 389]
				],
				physical: "35",
				next: ["29", "30"],
				direct: ["29"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 30: ["42", "29"] }
			},
			36: {
				x: 322,
				y: 341,
				angle: -1.5708,
				front: 379,
				poly: [
					[297, 293],
					[347, 293],
					[347, 389],
					[297, 389]
				],
				physical: "36",
				next: ["30", "31"],
				direct: ["31"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 30: ["42", "31"] }
			},
			38: {
				x: 829.2,
				y: 350,
				angle: 2.7456,
				front: 2500.4,
				poly: [
					[860.6, 313],
					[875.5, 355.8],
					[797, 386.6],
					[783.1, 344.8]
				],
				physical: "38",
				next: ["43", "52"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			39: {
				x: 904.4,
				y: 324.5,
				angle: 2.9229,
				front: 2420,
				poly: [
					[937.1, 296.1],
					[935.1, 344.8],
					[878.5, 351.8],
					[865.6, 309.1]
				],
				physical: "39",
				next: ["38", "44"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					38: ["45", "44"],
					44: ["45", "38"]
				}
			},
			40: {
				x: 972.5,
				y: 330.3,
				angle: -2.7945,
				front: 2370,
				poly: [
					[941.1, 297.1],
					[985.8, 306.1],
					[1016.6, 337.9],
					[982.8, 363.7],
					[941.1, 345.8]
				],
				physical: "40",
				next: ["39", "45"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			41: {
				x: 1355.7,
				y: 314.8,
				angle: 1.7561,
				front: 1797.5,
				poly: [
					[1383.3, 248.4],
					[1387.3, 283.2],
					[1380.3, 338.9],
					[1359.4, 388.6],
					[1321.7, 365.7],
					[1337.6, 256.4]
				],
				physical: "41",
				next: ["53"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			42: {
				x: 272,
				y: 341,
				angle: -1.5708,
				front: 379,
				poly: [
					[247, 293],
					[297, 293],
					[297, 389],
					[247, 389]
				],
				physical: "42",
				next: [
					"29",
					"30",
					"31"
				],
				direct: ["30"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					29: ["35", "30"],
					31: ["36", "30"]
				}
			},
			43: {
				x: 740.2,
				y: 386.4,
				angle: 2.7456,
				front: 2585.8,
				poly: [
					[763.2, 352.8],
					[778.1, 395.5],
					[717.5, 419.4],
					[701.6, 378.6]
				],
				physical: "43",
				next: ["51", "57"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					51: ["52", "57"],
					57: ["52", "51"]
				}
			},
			44: {
				x: 846.2,
				y: 396.6,
				angle: 2.7456,
				front: 2500.4,
				poly: [
					[877.5, 359.7],
					[892.4, 402.5],
					[815.9, 433.3],
					[799, 391.5]
				],
				physical: "44",
				next: ["43", "52"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			45: {
				x: 937.8,
				y: 382.4,
				angle: -2.7945,
				front: 2420,
				poly: [
					[881.5, 357.8],
					[921.2, 347.8],
					[965.9, 355.8],
					[986.8, 384.6],
					[986.8, 421.4],
					[896.4, 401.5]
				],
				physical: "45",
				next: ["38", "44"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					38: ["39", "44"],
					44: ["39", "38"]
				}
			},
			46: {
				x: 1009.1,
				y: 390.8,
				angle: -1.7206,
				front: 2310,
				poly: [
					[1016.6, 342.8],
					[1032.5, 377.6],
					[1028.5, 433.3],
					[988.8, 423.3],
					[983.8, 367.7]
				],
				physical: "46",
				next: ["40", "45"],
				direct: ["45"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			48: {
				x: 222,
				y: 437,
				angle: -1.5708,
				front: 283,
				poly: [
					[197, 389],
					[247, 389],
					[247, 485],
					[197, 485]
				],
				physical: "48",
				next: ["35", "42"],
				direct: ["35"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 42: ["49", "35"] }
			},
			49: {
				x: 272,
				y: 437,
				angle: -1.5708,
				front: 283,
				poly: [
					[247, 389],
					[297, 389],
					[297, 485],
					[247, 485]
				],
				physical: "49",
				next: [
					"35",
					"36",
					"42"
				],
				direct: ["42"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					35: ["48", "42"],
					36: ["50", "42"]
				}
			},
			50: {
				x: 322,
				y: 437,
				angle: -1.5708,
				front: 283,
				poly: [
					[297, 389],
					[347, 389],
					[347, 485],
					[297, 485]
				],
				physical: "50",
				next: ["36", "42"],
				direct: ["36"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 42: ["49", "36"] }
			},
			51: {
				x: 666.4,
				y: 417.5,
				angle: 2.7456,
				front: 2675.7,
				poly: [
					[697.6, 380.6],
					[713.5, 421.4],
					[635, 455.1],
					[620.1, 412.4]
				],
				physical: "51",
				next: ["56", "66"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			52: {
				x: 757.1,
				y: 433.1,
				angle: 2.7456,
				front: 2588.6,
				poly: [
					[780.1, 399.5],
					[796, 441.2],
					[734.4, 467.1],
					[718.5, 424.3]
				],
				physical: "52",
				next: ["51", "57"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					51: ["43", "57"],
					57: ["43", "51"]
				}
			},
			53: {
				x: 1298.4,
				y: 432.9,
				angle: 2.4181,
				front: 1921.4,
				poly: [
					[1322.7, 369.7],
					[1359.4, 396.5],
					[1318.7, 459.1],
					[1271, 502.8],
					[1241.2, 442.2]
				],
				physical: "53",
				next: ["61"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			56: {
				x: 583,
				y: 457.7,
				angle: 2.7456,
				front: 2775.1,
				poly: [
					[617.1, 414.4],
					[632, 457.1],
					[556.5, 501.8],
					[532.6, 468.1],
					[537.6, 458.1],
					[575.4, 432.3]
				],
				physical: "56",
				next: ["65", "66"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			57: {
				x: 684.1,
				y: 464.2,
				angle: 2.7456,
				front: 2678.5,
				poly: [
					[715.5, 426.3],
					[730.4, 469],
					[651.9, 502.8],
					[639, 458.1]
				],
				physical: "57",
				next: ["56", "66"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			58: {
				x: 977.1,
				y: 486.6,
				angle: -2.0556,
				front: 2269.1,
				poly: [
					[940, 418],
					[991, 428],
					[987, 462],
					[991, 485],
					[1005, 504],
					[1031, 515],
					[1014, 556],
					[981, 541],
					[952, 509],
					[939, 466]
				],
				physical: "58",
				next: ["45", "46"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			59: {
				x: 1015.2,
				y: 467.4,
				angle: -1.6199,
				front: 2269.1,
				poly: [
					[987.8, 429.3],
					[1027.5, 436.3],
					[1048.4, 471],
					[1031.5, 509.8],
					[1009.6, 501.8],
					[992.8, 483],
					[985.8, 462.1]
				],
				physical: "59",
				next: ["45", "46"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			60: {
				x: 1095.2,
				y: 494.4,
				angle: 3.1416,
				front: 2157.7,
				poly: [
					[1143.8, 473],
					[1145.8, 512.8],
					[1104.1, 517.7],
					[1040.5, 512.8],
					[1051.4, 472]
				],
				physical: "60",
				next: ["58", "59"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					58: ["67", "59"],
					59: ["67", "58"]
				}
			},
			61: {
				x: 1201.2,
				y: 497.8,
				angle: 2.7174,
				front: 2035.1,
				poly: [
					[1237.2, 444.2],
					[1268, 506.8],
					[1214.4, 536.6],
					[1155.7, 554.5],
					[1145.8, 471]
				],
				physical: "61",
				next: ["60", "67"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			62: {
				x: 222,
				y: 530,
				angle: -1.5708,
				front: 187,
				poly: [
					[197, 485],
					[247, 485],
					[247, 575],
					[197, 575]
				],
				physical: "62",
				next: ["48", "49"],
				direct: ["48"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 49: ["63", "48"] }
			},
			63: {
				x: 272,
				y: 530,
				angle: -1.5708,
				front: 187,
				poly: [
					[247, 485],
					[297, 485],
					[297, 575],
					[247, 575]
				],
				physical: "63",
				next: [
					"48",
					"49",
					"50"
				],
				direct: ["49"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					48: ["62", "49"],
					50: ["64", "49"]
				}
			},
			64: {
				x: 322,
				y: 530,
				angle: -1.5708,
				front: 187,
				poly: [
					[297, 485],
					[347, 485],
					[347, 575],
					[297, 575]
				],
				physical: "64",
				next: ["49", "50"],
				direct: ["50"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 49: ["63", "50"] }
			},
			65: {
				x: 512.6,
				y: 526.7,
				angle: 2.0517,
				front: 2869,
				poly: [
					[530.7, 471],
					[553.5, 506.8],
					[520.7, 570.4],
					[471, 565.4],
					[474, 540.6],
					[496.9, 500.8]
				],
				physical: "65",
				next: ["72", "76"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			66: {
				x: 595.4,
				y: 511.9,
				angle: 2.7456,
				front: 2869,
				poly: [
					[635, 464.1],
					[645.9, 506.8],
					[572.4, 556.5],
					[537.6, 534.6],
					[572.4, 494.9]
				],
				physical: "66",
				next: ["72"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			67: {
				x: 1085.3,
				y: 538.8,
				angle: 3.1416,
				front: 2157.7,
				poly: [
					[1015.6, 552.5],
					[1033.5, 515.8],
					[1148.8, 517.7],
					[1149.8, 557.5],
					[1037.5, 562.5]
				],
				physical: "67",
				next: ["58", "59"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					58: ["60", "59"],
					59: ["60", "58"]
				}
			},
			72: {
				x: 544.2,
				y: 596.4,
				angle: 1.5841,
				front: 2965.7,
				poly: [
					[537.6, 536.6],
					[570.4, 563.5],
					[565.4, 630],
					[529.7, 653.9],
					[521.7, 632],
					[519.7, 590.3]
				],
				physical: "72",
				next: ["83", "91"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			73: {
				x: 212.9,
				y: 620.3,
				angle: -1.5708,
				front: 97,
				poly: [
					[192, 575],
					[247, 575],
					[245, 661],
					[169, 661]
				],
				physical: "73",
				next: ["62", "63"],
				direct: ["62"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 63: ["74", "62"] }
			},
			74: {
				x: 271,
				y: 618,
				angle: -1.5708,
				front: 97,
				poly: [
					[247, 575],
					[297, 575],
					[295, 661],
					[245, 661]
				],
				physical: "74",
				next: [
					"62",
					"63",
					"64"
				],
				direct: ["63"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					62: ["73", "63"],
					64: ["75", "63"]
				}
			},
			75: {
				x: 327.6,
				y: 620.9,
				angle: -1.5708,
				front: 97,
				poly: [
					[297, 575],
					[347, 575],
					[370, 661],
					[295, 661]
				],
				physical: "75",
				next: ["63", "64"],
				direct: ["64"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 63: ["74", "64"] }
			},
			76: {
				x: 495,
				y: 621.1,
				angle: 1.5841,
				front: 2965.7,
				poly: [
					[470, 568.4],
					[518.7, 576.4],
					[526.7, 656.9],
					[487.9, 680.7],
					[475, 660.8],
					[464.1, 609.2]
				],
				physical: "76",
				next: ["83", "91"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			77: {
				x: 904.2,
				y: 644.3,
				angle: -.2623,
				front: 3421.8,
				poly: [
					[959, 593.3],
					[933.1, 686.7],
					[856.6, 681.7],
					[845.7, 637],
					[934.1, 595.3]
				],
				physical: "77",
				next: ["78", "85"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			78: {
				x: 996.6,
				y: 628.6,
				angle: .2555,
				front: 3488.3,
				poly: [
					[961, 595.3],
					[1041.4, 617.1],
					[1033.5, 661.8],
					[951, 640]
				],
				physical: "78",
				next: ["79", "95"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					79: ["85", "95"],
					95: ["85", "79"]
				}
			},
			79: {
				x: 1080.9,
				y: 647.9,
				angle: .2555,
				front: 3579,
				poly: [
					[1046.4, 619.1],
					[1130.9, 641],
					[1125.9, 666.8],
					[1037.5, 666.8]
				],
				physical: "79",
				next: ["86", "96"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 96: ["95", "86"] }
			},
			83: {
				x: 570.1,
				y: 675.9,
				angle: .6276,
				front: 3033.5,
				poly: [
					[564.4, 635],
					[602.2, 681.7],
					[592.3, 717.5],
					[560.5, 699.6],
					[532.6, 660.8]
				],
				physical: "83",
				next: ["91", "93"],
				direct: ["91"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			84: {
				x: 807.4,
				y: 676.8,
				angle: -.2623,
				front: 3296.3,
				poly: [
					[840.7, 640],
					[853.6, 684.7],
					[774.1, 713.5],
					[761.2, 668.8]
				],
				physical: "84",
				next: ["77"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			85: {
				x: 983.9,
				y: 677.5,
				angle: .2555,
				front: 3488.3,
				poly: [
					[948, 644],
					[1029.5, 666.8],
					[1020.6, 710.5],
					[938.1, 688.7]
				],
				physical: "85",
				next: ["79", "95"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					79: ["78", "95"],
					95: ["78", "79"]
				}
			},
			86: {
				x: 1173.9,
				y: 677.9,
				angle: .2555,
				front: 3674.7,
				poly: [
					[1134.9, 644.9],
					[1223.3, 666.8],
					[1213.4, 710.5],
					[1124.9, 689.7]
				],
				physical: "86",
				next: ["97", "101"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			87: {
				x: 194,
				y: 725.5,
				angle: -1.3173,
				front: 5432,
				poly: [
					[169, 682],
					[219, 682],
					[219, 769],
					[169, 769]
				],
				physical: "87",
				next: ["73"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			88: {
				x: 244,
				y: 725.5,
				angle: -1.3173,
				front: 5432,
				poly: [
					[219, 682],
					[269, 682],
					[269, 769],
					[219, 769]
				],
				physical: "88",
				next: ["73", "74"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			89: {
				x: 294,
				y: 725.5,
				angle: -1.3173,
				front: 5432,
				poly: [
					[269, 682],
					[319, 682],
					[319, 769],
					[269, 769]
				],
				physical: "89",
				next: ["74", "75"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			90: {
				x: 344.5,
				y: 725.5,
				angle: -1.3173,
				front: 5432.2,
				poly: [
					[319, 682],
					[370, 682],
					[370, 769],
					[319, 769]
				],
				physical: "90",
				next: ["75"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			91: {
				x: 541.5,
				y: 710.1,
				angle: .6276,
				front: 3047.9,
				poly: [
					[488.9, 684.7],
					[528.7, 660.8],
					[590.3, 722.5],
					[581.3, 757.2],
					[541.6, 746.3],
					[500.8, 708.5]
				],
				physical: "91",
				next: ["93"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			93: {
				x: 633.8,
				y: 727.4,
				angle: 0,
				front: 3126.9,
				poly: [
					[584.3, 759.2],
					[605.2, 684.7],
					[675.8, 703.6],
					[685.7, 748.3],
					[631, 761.2]
				],
				physical: "93",
				next: ["94"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			94: {
				x: 724.4,
				y: 707.6,
				angle: -.2623,
				front: 3209,
				poly: [
					[757.2, 669.8],
					[771.2, 714.5],
					[691.6, 745.3],
					[677.7, 700.6]
				],
				physical: "94",
				next: ["84"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			95: {
				x: 1069.8,
				y: 702.6,
				angle: .2555,
				front: 3579,
				poly: [
					[1033.5, 670.8],
					[1116, 689.7],
					[1106, 734.4],
					[1023.6, 715.5]
				],
				physical: "95",
				next: ["86", "96"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			96: {
				x: 1159.7,
				y: 725.9,
				angle: .2555,
				front: 3674.7,
				poly: [
					[1120, 693.6],
					[1209.4, 714.5],
					[1199.5, 758.2],
					[1110, 737.4]
				],
				physical: "96",
				next: ["97", "101"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			97: {
				x: 1276.3,
				y: 705,
				angle: .2555,
				front: 3771.1,
				poly: [
					[1247.2, 673.8],
					[1317.7, 692.6],
					[1304.8, 736.4],
					[1235.2, 717.5]
				],
				physical: "97",
				next: ["102"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			101: {
				x: 1262.6,
				y: 753,
				angle: .2555,
				front: 3771.1,
				poly: [
					[1234.2, 721.5],
					[1303.8, 740.3],
					[1291.9, 784.1],
					[1221.3, 766.2]
				],
				physical: "101",
				next: ["102"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			102: {
				x: 1350.3,
				y: 756.5,
				angle: 1.0685,
				front: 3885,
				poly: [
					[1321.7, 694.6],
					[1363.4, 713.5],
					[1393.2, 745.3],
					[1411.1, 792],
					[1368.4, 802],
					[1295.8, 785.1]
				],
				physical: "102",
				next: ["124"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			103: {
				x: 194,
				y: 817,
				angle: -1.3173,
				front: 5330.5,
				poly: [
					[169, 769],
					[219, 769],
					[219, 865],
					[169, 865]
				],
				physical: "103",
				next: [
					"87",
					"88",
					"104"
				],
				direct: ["87", "104"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			104: {
				x: 244,
				y: 817,
				angle: -1.3173,
				front: 5344.9,
				poly: [
					[219, 769],
					[269, 769],
					[269, 865],
					[219, 865]
				],
				physical: "104",
				next: [
					"87",
					"88",
					"89"
				],
				direct: ["88"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 89: ["105", "88"] }
			},
			105: {
				x: 294,
				y: 817,
				angle: -1.3173,
				front: 5344.9,
				poly: [
					[269, 769],
					[319, 769],
					[319, 865],
					[269, 865]
				],
				physical: "105",
				next: [
					"88",
					"89",
					"90"
				],
				direct: ["89"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					88: ["104", "89"],
					90: ["106", "89"]
				}
			},
			106: {
				x: 344.5,
				y: 817,
				angle: -1.3173,
				front: 5345,
				poly: [
					[319, 769],
					[370, 769],
					[370, 865],
					[319, 865]
				],
				physical: "106",
				next: ["89", "90"],
				direct: ["90"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 89: ["105", "90"] }
			},
			109: {
				x: 686.5,
				y: 830.3,
				angle: 2.802,
				front: 4717.7,
				poly: [
					[717.5, 792],
					[733.4, 835.7],
					[654.9, 868.5],
					[640, 824.8]
				],
				physical: "109",
				next: ["117", "128"],
				direct: ["117"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 128: ["118", "117"] }
			},
			110: {
				x: 771.6,
				y: 801.1,
				angle: 2.9367,
				front: 4633.5,
				poly: [
					[815.9, 772.1],
					[811.9, 819.8],
					[735.4, 832.8],
					[723.4, 788],
					[774.1, 774.1]
				],
				physical: "110",
				next: ["109", "118"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					109: ["119", "118"],
					118: ["119", "109"]
				}
			},
			111: {
				x: 859.8,
				y: 801.8,
				angle: -2.8845,
				front: 4560.2,
				poly: [
					[818.8, 772.1],
					[905.3, 786.1],
					[897.4, 830.8],
					[818.8, 819.8]
				],
				physical: "111",
				next: ["110", "119"],
				direct: ["119"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			112: {
				x: 945.6,
				y: 823.1,
				angle: -2.8845,
				front: 4468,
				poly: [
					[910.3, 790],
					[990.8, 811.9],
					[981.8, 855.6],
					[900.3, 834.8]
				],
				physical: "112",
				next: ["111", "119"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			113: {
				x: 1016.8,
				y: 844.5,
				angle: -2.8845,
				front: 4379.3,
				poly: [
					[995.7, 813.9],
					[1044.4, 827.8],
					[1043.4, 875.5],
					[983.8, 857.6]
				],
				physical: "113",
				next: ["112", "120"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					112: ["121", "120"],
					120: ["121", "112"]
				}
			},
			115: {
				x: 331.3,
				y: 898.8,
				angle: -2.9066,
				front: 5240.9,
				poly: [
					[270.3, 867.5],
					[367.7, 866.6],
					[378.6, 895.4],
					[365.7, 946],
					[331.9, 937.1],
					[300.1, 917.2],
					[279.2, 893.4]
				],
				physical: "115",
				next: [
					"104",
					"105",
					"106"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					104: ["125", "105"],
					105: ["125", "104"]
				}
			},
			116: {
				x: 521.6,
				y: 899.5,
				angle: 2.802,
				front: 4897.1,
				poly: [
					[555.5, 862.6],
					[570.4, 905.3],
					[488.9, 937.1],
					[473, 892.4]
				],
				physical: "116",
				next: ["126", "138"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			117: {
				x: 599.9,
				y: 855.8,
				angle: 2.802,
				front: 4818.1,
				poly: [
					[539, 842],
					[635, 807],
					[655, 870],
					[575, 906]
				],
				physical: "117",
				next: ["116", "127"],
				direct: ["116"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 127: ["128", "116"] }
			},
			118: {
				x: 702.4,
				y: 877.6,
				angle: 2.802,
				front: 4718.4,
				poly: [
					[734.4, 839.7],
					[748.3, 882.4],
					[670.8, 915.2],
					[655.9, 873.5]
				],
				physical: "118",
				next: [
					"117",
					"128",
					"140"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					117: ["109", "128"],
					128: ["109", "117"],
					140: ["130", "128"]
				}
			},
			119: {
				x: 817.6,
				y: 853.8,
				angle: 2.9367,
				front: 4633.5,
				poly: [
					[738.4, 837.7],
					[795, 822.8],
					[846.7, 824.8],
					[895.4, 836.7],
					[883.4, 881.5],
					[753.3, 881.5]
				],
				physical: "119",
				next: [
					"109",
					"118",
					"130"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					109: ["110", "118"],
					118: ["110", "109"]
				}
			},
			120: {
				x: 933.9,
				y: 871.7,
				angle: -2.8845,
				front: 4468,
				poly: [
					[897.4, 839.7],
					[978.8, 860.6],
					[968.9, 904.3],
					[889.4, 882.4]
				],
				physical: "120",
				next: ["111", "119"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			121: {
				x: 1017.3,
				y: 895.1,
				angle: -2.8845,
				front: 4379.3,
				poly: [
					[981.8, 863.6],
					[1061.3, 882.4],
					[1051.4, 927.2],
					[973.9, 907.3]
				],
				physical: "121",
				next: [
					"112",
					"120",
					"131"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					112: ["113", "120"],
					120: ["113", "112"],
					131: ["132", "120"]
				}
			},
			122: {
				x: 1118.6,
				y: 870.7,
				angle: -2.8845,
				front: 4292.7,
				poly: [
					[1079.2, 837.7],
					[1168.6, 859.6],
					[1157.7, 903.3],
					[1069.3, 882.4]
				],
				physical: "122",
				next: ["113", "121"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			123: {
				x: 1211.1,
				y: 895.1,
				angle: -2.8845,
				front: 4196.3,
				poly: [
					[1171.6, 863.6],
					[1258.1, 883.4],
					[1252.1, 926.2],
					[1163.7, 907.3]
				],
				physical: "123",
				next: ["122", "133"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					122: ["134", "133"],
					133: ["134", "122"]
				}
			},
			124: {
				x: 1383.2,
				y: 869.7,
				angle: 1.757,
				front: 4009.3,
				poly: [
					[1417.1, 812.9],
					[1413.1, 874.5],
					[1396.2, 914.2],
					[1378.3, 933.1],
					[1344.5, 897.4],
					[1366.4, 824.8]
				],
				physical: "124",
				next: ["135"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			125: {
				x: 234.3,
				y: 912.6,
				angle: -1.6649,
				front: 5240.9,
				poly: [
					[169.9, 866.6],
					[267.3, 867.5],
					[291.2, 913.3],
					[269.3, 971.9],
					[239.5, 971.9],
					[203.7, 942.1],
					[178.9, 908.3]
				],
				physical: "125",
				next: [
					"103",
					"104",
					"105"
				],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					104: ["115", "105"],
					105: ["115", "104"]
				}
			},
			126: {
				x: 425.9,
				y: 922.6,
				angle: 2.802,
				front: 5123.3,
				poly: [
					[485, 935.1],
					[483, 940.1],
					[435.3, 952],
					[368.7, 948],
					[382.6, 894.4],
					[468.1, 893.4]
				],
				physical: "126",
				next: ["115"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			127: {
				x: 538.8,
				y: 947.3,
				angle: 2.802,
				front: 4896.5,
				poly: [
					[571.4, 909.3],
					[586.3, 953],
					[507.8, 985.8],
					[490.9, 941.1]
				],
				physical: "127",
				next: ["126", "138"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			128: {
				x: 621,
				y: 912.6,
				angle: 2.802,
				front: 4806.7,
				poly: [
					[652.9, 875.5],
					[666.8, 917.2],
					[589.3, 950],
					[575.4, 907.3]
				],
				physical: "128",
				next: [
					"116",
					"117",
					"127"
				],
				direct: ["117"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					116: ["117", "127"],
					127: ["117", "116"]
				}
			},
			130: {
				x: 718.9,
				y: 924.5,
				angle: 2.802,
				front: 4719.5,
				poly: [
					[751.3, 885.4],
					[766.2, 929.2],
					[686.7, 963.9],
					[671.8, 919.2]
				],
				physical: "130",
				next: ["128", "140"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					128: ["118", "140"],
					140: ["118", "128"]
				}
			},
			131: {
				x: 920.1,
				y: 919.8,
				angle: -2.8845,
				front: 4468,
				poly: [
					[884.4, 885.4],
					[964.9, 907.3],
					[957, 954],
					[874.5, 932.1]
				],
				physical: "131",
				next: ["119"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			132: {
				x: 1000.9,
				y: 943.2,
				angle: -2.8845,
				front: 4379.3,
				poly: [
					[969.9, 911.3],
					[1035.5, 928.2],
					[1042.4, 964.9],
					[1006.7, 969.9],
					[962, 958]
				],
				physical: "132",
				next: ["120", "131"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					120: ["121", "131"],
					131: ["121", "120"]
				}
			},
			133: {
				x: 1105.5,
				y: 919,
				angle: -2.8845,
				front: 4292.7,
				poly: [
					[1065.3, 886.4],
					[1154.7, 907.3],
					[1144.8, 952],
					[1056.4, 930.2]
				],
				physical: "133",
				next: [
					"113",
					"121",
					"132"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 132: ["142", "121"] }
			},
			134: {
				x: 1198.3,
				y: 943.3,
				angle: -2.8845,
				front: 4196.3,
				poly: [
					[1158.7, 910.3],
					[1247.2, 931.1],
					[1238.2, 975.9],
					[1149.8, 956]
				],
				physical: "134",
				next: [
					"122",
					"133",
					"142"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					122: ["123", "133"],
					133: ["123", "122"]
				}
			},
			135: {
				x: 1302.8,
				y: 936.8,
				angle: 3.0883,
				front: 4112.7,
				poly: [
					[1241.2, 977.8],
					[1266, 886.4],
					[1341.6, 899.3],
					[1375.4, 935.1],
					[1353.5, 960],
					[1334.6, 969.9],
					[1277, 983.8]
				],
				physical: "135",
				next: ["123", "134"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			137: {
				x: 333.1,
				y: 974.1,
				angle: -2.9066,
				front: 5123.3,
				poly: [
					[264, 986],
					[306, 927],
					[346, 944],
					[390, 956],
					[390, 1008],
					[345, 1009],
					[305, 1003]
				],
				physical: "137",
				next: ["115", "125"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			138: {
				x: 440.2,
				y: 966.7,
				angle: 2.802,
				front: 5012.9,
				poly: [
					[391, 956],
					[480, 927],
					[497, 975],
					[406, 1002],
					[390, 1005]
				],
				physical: "138",
				next: [
					"115",
					"126",
					"137"
				],
				direct: ["126", "137"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			140: {
				x: 637.3,
				y: 959.8,
				angle: 2.802,
				front: 4807.6,
				poly: [
					[668.8, 921.2],
					[683.7, 965.9],
					[605.2, 997.7],
					[590.3, 955]
				],
				physical: "140",
				next: ["127"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			142: {
				x: 1095.1,
				y: 963.2,
				angle: -2.8845,
				front: 4292.7,
				poly: [
					[1057, 925],
					[1147, 949],
					[1134, 1001],
					[1043, 978]
				],
				physical: "142",
				next: ["121", "132"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			"nw-outer": {
				x: 277.5,
				y: 128.6,
				angle: -.7086,
				front: 652.4,
				poly: [
					[198, 198],
					[201, 169],
					[213, 139],
					[236, 111],
					[265, 88],
					[298, 75],
					[340, 67],
					[381, 65],
					[381, 99],
					[348, 103],
					[319, 115],
					[295, 135],
					[281, 159],
					[273, 183],
					[273, 198]
				],
				physical: "nw-outer",
				next: ["2"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			}
		},
		jumps: [],
		animals: []
	},
	crosstown: {
		width: 1612,
		height: 1080,
		length: 5819.8,
		closed: !0,
		starts: [
			"73",
			"74",
			"89",
			"90",
			"91",
			"92"
		],
		firstStart: "74",
		bets: [
			1548.6,
			3036.4,
			4299.1
		],
		nodes: {
			1: {
				x: 317.5,
				y: 141.9,
				angle: -.9957,
				front: 379.3,
				poly: [
					[374.8, 81.6],
					[374.8, 125.9],
					[314.3, 195.5],
					[248.9, 194.4],
					[263, 157.2],
					[308.3, 101.8],
					[346.6, 83.6]
				],
				physical: "1",
				next: ["2", "12"],
				direct: ["12"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			2: {
				x: 423.3,
				y: 103.1,
				angle: -.1651,
				front: 463.1,
				poly: [
					[376.8, 80.6],
					[467.5, 78.6],
					[470.5, 125.9],
					[377.8, 126.9]
				],
				physical: "2",
				next: ["3", "13"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			3: {
				x: 531.8,
				y: 114.1,
				angle: .2954,
				front: 529.7,
				poly: [
					[472.5, 81.6],
					[551.1, 85.6],
					[582.3, 100.8],
					[599.5, 120.9],
					[565.2, 153.1],
					[473.5, 126.9]
				],
				physical: "3",
				next: ["14-in", "23-in"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"14-in": ["13", "23"],
					"23-in": ["13", "14"]
				}
			},
			4: {
				x: 737.7,
				y: 107.3,
				angle: -.3258,
				front: 1656.7,
				poly: [
					[778.8, 125.9],
					[718.3, 138],
					[683.1, 98.7],
					[722.4, 83.6],
					[777.8, 80.6]
				],
				physical: "4",
				next: ["5", "15"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			5: {
				x: 828.6,
				y: 103.8,
				angle: 0,
				front: 1751.7,
				poly: [
					[781.8, 81.6],
					[874.5, 80.6],
					[875.5, 125.9],
					[782.8, 126.9]
				],
				physical: "5",
				next: ["6", "16"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			6: {
				x: 927.7,
				y: 115.4,
				angle: .4636,
				front: 1807.6,
				poly: [
					[877.5, 81.6],
					[911.8, 81.6],
					[948.1, 90.7],
					[991.4, 120.9],
					[951.1, 155.2],
					[878.5, 126.9]
				],
				physical: "6",
				next: ["17-in", "25-in"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					"17-in": ["16", "25"],
					"25-in": ["16", "17"]
				}
			},
			7: {
				x: 1125.9,
				y: 111.7,
				angle: -.3021,
				front: 3147.9,
				poly: [
					[1184.8, 81.6],
					[1183.8, 126.9],
					[1093.1, 147.1],
					[1056.9, 113.8],
					[1075, 96.7],
					[1103.2, 85.6]
				],
				physical: "7",
				next: ["9", "18"],
				direct: ["18"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			9: {
				x: 1238.2,
				y: 106.9,
				angle: 0,
				front: 3257.7,
				poly: [
					[1187.8, 81.6],
					[1293.6, 93.7],
					[1294.6, 125.9],
					[1188.8, 126.9]
				],
				physical: "9",
				next: ["10", "19"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			10: {
				x: 1357.2,
				y: 108.7,
				angle: .2522,
				front: 3360.3,
				poly: [
					[1297, 80],
					[1374, 80],
					[1432, 109],
					[1401, 141],
					[1297, 127]
				],
				physical: "10",
				next: ["21", "27"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			12: {
				x: 380.9,
				y: 163.2,
				angle: -.1651,
				front: 444.3,
				poly: [
					[437.3, 132],
					[435.2, 177.3],
					[382.8, 195.5],
					[318.4, 194.4],
					[326.4, 163.2],
					[351.6, 137],
					[369.8, 130]
				],
				physical: "12",
				next: ["2", "13"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			13: {
				x: 493.9,
				y: 161,
				angle: .2954,
				front: 529.7,
				poly: [
					[439.3, 131],
					[512.8, 133],
					[537, 142.1],
					[558.2, 160.2],
					[518.9, 199.5],
					[440.3, 175.3]
				],
				physical: "13",
				next: ["14-in", "23-in"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"14-in": ["3", "23"],
					"23-in": ["3", "14"]
				}
			},
			15: {
				x: 773.4,
				y: 157.7,
				angle: -.3258,
				front: 1703.9,
				poly: [
					[708.3, 149.1],
					[752.6, 131],
					[825.1, 130],
					[826.2, 176.3],
					[743.5, 191.4]
				],
				physical: "15",
				next: ["5", "16"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			16: {
				x: 885.4,
				y: 161.1,
				angle: .4636,
				front: 1807.6,
				poly: [
					[829.2, 134],
					[905.7, 133],
					[931.9, 144.1],
					[950.1, 160.2],
					[909.8, 198.5],
					[830.2, 174.3]
				],
				physical: "16",
				next: ["17-in", "25-in"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"17-in": ["6", "25"],
					"25-in": ["6", "17"]
				}
			},
			18: {
				x: 1179.2,
				y: 157.5,
				angle: -.3021,
				front: 3211.4,
				poly: [
					[1098.2, 150.1],
					[1144.5, 131],
					[1247.3, 130],
					[1248.3, 176.3],
					[1133.4, 190.4]
				],
				physical: "18",
				next: ["9", "19"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			19: {
				x: 1319.2,
				y: 156.7,
				angle: .2522,
				front: 3360.3,
				poly: [
					[1250.3, 175.3],
					[1251.3, 130],
					[1358.1, 131],
					[1398.4, 147.1],
					[1365.2, 189.4]
				],
				physical: "19",
				next: ["21", "27"],
				direct: ["27"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			21: {
				x: 1477.7,
				y: 194.9,
				angle: .9773,
				front: 3517.5,
				poly: [
					[1436.7, 109.8],
					[1475, 137],
					[1530.4, 198.5],
					[1560.6, 257.9],
					[1464.9, 256.9],
					[1406.5, 147.1]
				],
				physical: "21",
				next: ["46", "47"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			22: {
				x: 318.7,
				y: 245.6,
				angle: -1.5708,
				front: 293.9,
				poly: [
					[296.2, 198.5],
					[342.6, 202.5],
					[341.5, 291.2],
					[295.2, 290.2]
				],
				physical: "22",
				next: [
					"1",
					"12",
					"30"
				],
				direct: ["30"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			27: {
				x: 1407.2,
				y: 223.3,
				angle: .9773,
				front: 3503.2,
				poly: [
					[1368, 191],
					[1394, 151],
					[1418, 164],
					[1436, 199],
					[1441, 287],
					[1394, 287]
				],
				physical: "27",
				next: [
					"21",
					"45",
					"46"
				],
				direct: ["21"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			29: {
				x: 260.5,
				y: 248,
				angle: -1.5708,
				front: 284,
				poly: [
					[246.8, 198.5],
					[292.2, 199.5],
					[291.2, 291.2],
					[220.6, 290.2],
					[225.7, 248.9]
				],
				physical: "29",
				next: [
					"1",
					"12",
					"22"
				],
				direct: ["22"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			30: {
				x: 374.7,
				y: 250.5,
				angle: -1.5708,
				front: 316.4,
				poly: [
					[345.6, 199.5],
					[383.9, 202.5],
					[413.1, 270],
					[416.1, 291.2],
					[345.6, 290.2]
				],
				physical: "30",
				next: ["1", "12"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			34: {
				x: 244.5,
				y: 341,
				angle: -1.5708,
				front: 189,
				poly: [
					[220, 294],
					[269, 294],
					[269, 388],
					[220, 388]
				],
				physical: "34",
				next: ["22", "29"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 22: ["36", "29"] }
			},
			36: {
				x: 294,
				y: 341,
				angle: -1.5708,
				front: 189,
				poly: [
					[269, 294],
					[319, 294],
					[319, 388],
					[269, 388]
				],
				physical: "36",
				next: [
					"22",
					"29",
					"30"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			37: {
				x: 344,
				y: 341,
				angle: -1.5708,
				front: 189,
				poly: [
					[319, 294],
					[369, 294],
					[369, 388],
					[319, 388]
				],
				physical: "37",
				next: [
					"22",
					"29",
					"30"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 29: ["36", "22"] }
			},
			38: {
				x: 394,
				y: 341,
				angle: -1.5708,
				front: 189,
				poly: [
					[369, 294],
					[419, 294],
					[419, 388],
					[369, 388]
				],
				physical: "38",
				next: ["22", "30"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			39: {
				x: 512.8,
				y: 311.6,
				angle: -1.1818,
				front: 1362.7,
				poly: [
					[518.9, 247.8],
					[559.2, 292.2],
					[518.9, 362.7],
					[474.5, 365.7],
					[480.6, 306.3],
					[494.7, 276.1]
				],
				physical: "39",
				next: ["23-out", "31-out"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					"23-out": ["49", "31"],
					"31-out": ["49", "23"]
				}
			},
			40: {
				x: 742.7,
				y: 311.8,
				angle: 1.1494,
				front: 824.9,
				poly: [
					[735.5, 249.9],
					[754.6, 269],
					[773.8, 303.3],
					[781.8, 362.7],
					[736.5, 362.7],
					[697.2, 292.2]
				],
				physical: "40",
				next: ["50", "58"],
				direct: ["50"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			41: {
				x: 898.1,
				y: 306.5,
				angle: -.858,
				front: 2820.4,
				poly: [
					[911.8, 250.9],
					[950.1, 292.2],
					[883.6, 360.7],
					[847.3, 330.5],
					[881.6, 281.1]
				],
				physical: "41",
				next: ["25-out", "32-out"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"25-out": ["42", "32"],
					"32-out": ["42", "25"]
				}
			},
			42: {
				x: 941.2,
				y: 344.3,
				angle: -.858,
				front: 2820.4,
				poly: [
					[955.1, 295.2],
					[994.4, 334.5],
					[921.9, 390.9],
					[888.6, 361.7]
				],
				physical: "42",
				next: ["25-out", "32-out"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"25-out": ["41", "32"],
					"32-out": ["41", "25"]
				}
			},
			43: {
				x: 1097.1,
				y: 344.2,
				angle: .7337,
				front: 2114.2,
				poly: [
					[1084.1, 295.2],
					[1149.6, 361.7],
					[1116.3, 390.9],
					[1043.8, 334.5]
				],
				physical: "43",
				next: [
					"44",
					"52",
					"60"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			44: {
				x: 1140.1,
				y: 306.3,
				angle: .7337,
				front: 2124,
				poly: [
					[1123.4, 253.9],
					[1133.4, 254.9],
					[1190.9, 330.5],
					[1156.6, 359.7],
					[1089.1, 293.2]
				],
				physical: "44",
				next: ["52", "60"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			45: {
				x: 1417.5,
				y: 336,
				angle: 1.5708,
				front: 3609.5,
				poly: [
					[1393, 289],
					[1442, 289],
					[1442, 383],
					[1393, 383]
				],
				physical: "45",
				next: ["61", "62"],
				direct: ["61"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			46: {
				x: 1489.5,
				y: 307.5,
				angle: 1.5708,
				front: 3582.5,
				poly: [
					[1464, 259],
					[1515, 259],
					[1515, 356],
					[1464, 356]
				],
				physical: "46",
				next: [
					"45",
					"62",
					"63"
				],
				direct: ["62"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 63: ["47", "62"] }
			},
			47: {
				x: 1539.5,
				y: 307.5,
				angle: 1.5708,
				front: 3582.5,
				poly: [
					[1515, 259],
					[1564, 259],
					[1564, 356],
					[1515, 356]
				],
				physical: "47",
				next: ["62", "63"],
				direct: ["63"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 62: ["46", "63"] }
			},
			49: {
				x: 558.6,
				y: 354.8,
				angle: -1.1818,
				front: 1362.7,
				poly: [
					[563.2, 294.2],
					[600.5, 331.5],
					[569.2, 404],
					[525.9, 405],
					[525.9, 343.6]
				],
				physical: "49",
				next: ["23-out", "31-out"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"23-out": ["39", "31"],
					"31-out": ["39", "23"]
				}
			},
			50: {
				x: 697.3,
				y: 354.4,
				angle: 1.1494,
				front: 865.9,
				poly: [
					[692.2, 295.2],
					[713.3, 315.3],
					[729.4, 342.6],
					[729.4, 405],
					[684.1, 403],
					[655.9, 331.5]
				],
				physical: "50",
				next: ["58", "66"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			51: {
				x: 845.2,
				y: 395.4,
				angle: -1.3976,
				front: 2754.9,
				poly: [
					[847.3, 336.5],
					[881.6, 363.7],
					[856.4, 441.3],
					[811, 443.3],
					[818.1, 391.9]
				],
				physical: "51",
				next: ["41", "42"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					41: ["59", "42"],
					42: ["59", "41"]
				}
			},
			52: {
				x: 1193.9,
				y: 394.4,
				angle: 1.2956,
				front: 2217.2,
				poly: [
					[1190.9, 336.5],
					[1219.1, 387.9],
					[1227.1, 443.3],
					[1187.8, 441.3],
					[1156.6, 365.7]
				],
				physical: "52",
				next: ["60", "69"],
				direct: ["60"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			53: {
				x: 244.5,
				y: 430,
				angle: -1.5708,
				front: 95,
				poly: [
					[220, 388],
					[269, 388],
					[269, 472],
					[220, 472]
				],
				physical: "53",
				next: ["34", "36"],
				direct: ["34"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 36: ["54", "34"] }
			},
			54: {
				x: 294,
				y: 430,
				angle: -1.5708,
				front: 95,
				poly: [
					[269, 388],
					[319, 388],
					[319, 472],
					[269, 472]
				],
				physical: "54",
				next: [
					"34",
					"36",
					"37"
				],
				direct: ["36"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					34: ["53", "36"],
					37: ["55", "36"]
				}
			},
			55: {
				x: 344,
				y: 430,
				angle: -1.5708,
				front: 95,
				poly: [
					[319, 388],
					[369, 388],
					[369, 472],
					[319, 472]
				],
				physical: "55",
				next: [
					"36",
					"37",
					"38"
				],
				direct: ["37"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					36: ["54", "37"],
					38: ["56", "37"]
				}
			},
			56: {
				x: 394,
				y: 430,
				angle: -1.5708,
				front: 95,
				poly: [
					[369, 388],
					[419, 388],
					[419, 472],
					[369, 472]
				],
				physical: "56",
				next: ["37", "38"],
				direct: ["38"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 37: ["55", "38"] }
			},
			57: {
				x: 498.7,
				y: 409.6,
				angle: -1.5708,
				front: 1296.8,
				poly: [
					[518.9, 365.7],
					[524.9, 440.3],
					[480.6, 461.4],
					[473.5, 369.8]
				],
				physical: "57",
				next: ["39", "49"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			58: {
				x: 756.6,
				y: 400.7,
				angle: 1.5708,
				front: 899.2,
				poly: [
					[736.5, 365.7],
					[782.8, 369.8],
					[774.8, 438.3],
					[731.4, 430.2]
				],
				physical: "58",
				next: ["66", "67"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			59: {
				x: 888.6,
				y: 427.3,
				angle: -1.3976,
				front: 2753.7,
				poly: [
					[885.6, 368.7],
					[918.8, 392.9],
					[911.8, 466.5],
					[873.5, 482.6],
					[861.4, 459.4],
					[859.4, 424.2],
					[865.4, 400]
				],
				physical: "59",
				next: ["41", "42"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					41: ["51", "42"],
					42: ["51", "41"]
				}
			},
			60: {
				x: 1149.9,
				y: 427.5,
				angle: 1.2956,
				front: 2262.9,
				poly: [
					[1151.6, 367.7],
					[1170.7, 394.9],
					[1178.8, 424.2],
					[1177.8, 454.4],
					[1167.7, 484.6],
					[1127.4, 467.5],
					[1119.3, 392.9]
				],
				physical: "60",
				next: ["69", "80"],
				direct: ["69"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			61: {
				x: 1417.5,
				y: 431,
				angle: 1.5708,
				front: 3705.5,
				poly: [
					[1393, 383],
					[1442, 383],
					[1442, 479],
					[1393, 479]
				],
				physical: "61",
				next: ["70", "81"],
				direct: ["81"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			62: {
				x: 1489.5,
				y: 404,
				angle: 1.5708,
				front: 3678.5,
				poly: [
					[1464, 356],
					[1515, 356],
					[1515, 452],
					[1464, 452]
				],
				physical: "62",
				next: [
					"61",
					"70",
					"71"
				],
				direct: ["70"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 71: ["63", "70"] }
			},
			63: {
				x: 1539.5,
				y: 404,
				angle: 1.5708,
				front: 3678.5,
				poly: [
					[1515, 356],
					[1564, 356],
					[1564, 452],
					[1515, 452]
				],
				physical: "63",
				next: ["70", "71"],
				direct: ["71"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 70: ["62", "71"] }
			},
			65: {
				x: 557.2,
				y: 457.6,
				angle: -2.0236,
				front: 1256.8,
				poly: [
					[526.9, 408],
					[573.3, 407],
					[589.4, 482.6],
					[566.2, 519.9],
					[545.1, 502.7],
					[533, 481.6]
				],
				physical: "65",
				next: ["49", "57"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			66: {
				x: 698.8,
				y: 458,
				angle: 2.0032,
				front: 996.2,
				poly: [
					[729.4, 408],
					[723.4, 480.6],
					[709.3, 504.8],
					[686.1, 519.9],
					[667, 482.6],
					[683.1, 407]
				],
				physical: "66",
				next: ["77", "83"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					77: ["78", "83"],
					83: ["78", "77"]
				}
			},
			67: {
				x: 750.2,
				y: 483.9,
				angle: 2.0032,
				front: 959.1,
				poly: [
					[731.4, 461.4],
					[776.8, 465.5],
					[760.7, 516.8],
					[723.4, 488.6]
				],
				physical: "67",
				next: ["66", "78"],
				direct: ["78"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			68: {
				x: 848.1,
				y: 491.2,
				angle: -2.2465,
				front: 2661.2,
				poly: [
					[811, 445.3],
					[857.4, 447.3],
					[887.6, 515.8],
					[859.4, 547.1],
					[839.2, 528.9],
					[818.1, 492.7]
				],
				physical: "68",
				next: ["51", "59"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			69: {
				x: 1190.2,
				y: 490.3,
				angle: 1.9586,
				front: 2306.4,
				poly: [
					[1227.1, 446.3],
					[1226.1, 471.5],
					[1215, 502.7],
					[1178.8, 547.1],
					[1150.6, 515.8],
					[1180.8, 447.3]
				],
				physical: "69",
				next: ["80", "86"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			70: {
				x: 1489.5,
				y: 500,
				angle: 1.5708,
				front: 3774.5,
				poly: [
					[1464, 452],
					[1515, 452],
					[1515, 548],
					[1464, 548]
				],
				physical: "70",
				next: [
					"81",
					"87",
					"88"
				],
				direct: ["87"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 88: ["71", "87"] }
			},
			71: {
				x: 1539.5,
				y: 500,
				angle: 1.5708,
				front: 3774.5,
				poly: [
					[1515, 452],
					[1564, 452],
					[1564, 548],
					[1515, 548]
				],
				physical: "71",
				next: ["87", "88"],
				direct: ["88"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 87: ["70", "88"] }
			},
			72: {
				x: 244.5,
				y: 536,
				angle: -1.5708,
				front: 5808.8,
				poly: [
					[220, 494],
					[269, 494],
					[269, 578],
					[220, 578]
				],
				physical: "72",
				next: ["53", "54"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			73: {
				x: 294,
				y: 536,
				angle: -1.5708,
				front: 5808.8,
				poly: [
					[269, 494],
					[319, 494],
					[319, 578],
					[269, 578]
				],
				physical: "73",
				next: [
					"53",
					"54",
					"55"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			74: {
				x: 344,
				y: 536,
				angle: -1.5708,
				front: 5808.8,
				poly: [
					[319, 494],
					[369, 494],
					[369, 578],
					[319, 578]
				],
				physical: "74",
				next: [
					"54",
					"55",
					"56"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			75: {
				x: 394,
				y: 536,
				angle: -1.5708,
				front: 5808.8,
				poly: [
					[369, 494],
					[419, 494],
					[419, 578],
					[369, 578]
				],
				physical: "75",
				next: ["55", "56"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			76: {
				x: 523,
				y: 508.7,
				angle: -2.0236,
				front: 1218.8,
				poly: [
					[480.6, 464.5],
					[525.9, 462.4],
					[566.2, 525.9],
					[546.1, 566.2],
					[524.9, 553.1],
					[496.7, 520.9],
					[483.6, 490.7]
				],
				physical: "76",
				next: ["57", "65"],
				direct: ["65"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			77: {
				x: 627.2,
				y: 511.9,
				angle: -2.7299,
				front: 1126.5,
				poly: [
					[603, 488],
					[650, 488],
					[688, 528],
					[661, 530],
					[600, 530],
					[567, 528]
				],
				physical: "77",
				next: ["65", "76"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			78: {
				x: 724.2,
				y: 525.1,
				angle: 2.3159,
				front: 998.7,
				poly: [
					[748.6, 497.7],
					[758.6, 520.9],
					[736.5, 548.1],
					[709.3, 566.2],
					[691.1, 524.9],
					[722.4, 489.6]
				],
				physical: "78",
				next: ["77", "83"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					77: ["66", "83"],
					83: ["66", "77"]
				}
			},
			79: {
				x: 925,
				y: 508.4,
				angle: -2.6079,
				front: 2607.5,
				poly: [
					[875.5, 486.6],
					[911.8, 471.5],
					[975.3, 516.8],
					[975.3, 529.9],
					[929.9, 543],
					[885.6, 508.8]
				],
				physical: "79",
				next: ["59", "68"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			80: {
				x: 1111,
				y: 510.1,
				angle: 2.7029,
				front: 2408.5,
				poly: [
					[1152.6, 482.6],
					[1150.6, 510.8],
					[1106.2, 543],
					[1063.9, 534],
					[1061.9, 520.9],
					[1123.4, 473.5]
				],
				physical: "80",
				next: ["85"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			81: {
				x: 1417.5,
				y: 527.5,
				angle: 1.5708,
				front: 3802.5,
				poly: [
					[1393, 479],
					[1442, 479],
					[1442, 576],
					[1393, 576]
				],
				physical: "81",
				next: ["87", "93"],
				direct: ["93"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			83: {
				x: 628.8,
				y: 556.4,
				angle: 3.0909,
				front: 1125.5,
				poly: [
					[706.3, 567.2],
					[690.1, 577.3],
					[652.9, 586.4],
					[603.5, 586.4],
					[550.1, 569.2],
					[569.2, 528.9],
					[686.1, 527.9]
				],
				physical: "83",
				next: ["65", "76"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			84: {
				x: 917.9,
				y: 557.8,
				angle: -2.7238,
				front: 2587.4,
				poly: [
					[861.4, 550.1],
					[892.6, 520.9],
					[968.2, 559.2],
					[962.2, 591.4],
					[906.8, 579.3]
				],
				physical: "84",
				next: ["68", "79"],
				direct: ["79"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			85: {
				x: 1019.6,
				y: 558.9,
				angle: -3.0488,
				front: 2495.1,
				poly: [
					[1058.9, 519.9],
					[1072, 594.4],
					[967.2, 594.4],
					[980.3, 519.9]
				],
				physical: "85",
				next: ["79", "84"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			86: {
				x: 1120.2,
				y: 557.8,
				angle: 2.7029,
				front: 2396.9,
				poly: [
					[1176.8, 550.1],
					[1131.4, 579.3],
					[1076, 591.4],
					[1070, 559.2],
					[1145.5, 520.9]
				],
				physical: "86",
				next: ["80", "85"],
				direct: ["80"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			87: {
				x: 1489.5,
				y: 596,
				angle: 1.5708,
				front: 3870.5,
				poly: [
					[1464, 548],
					[1515, 548],
					[1515, 644],
					[1464, 644]
				],
				physical: "87",
				next: [
					"93",
					"94",
					"95"
				],
				direct: ["94"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 95: ["88", "94"] }
			},
			88: {
				x: 1539.5,
				y: 596,
				angle: 1.5708,
				front: 3870.5,
				poly: [
					[1515, 548],
					[1564, 548],
					[1564, 644],
					[1515, 644]
				],
				physical: "88",
				next: ["94", "95"],
				direct: ["95"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 94: ["87", "95"] }
			},
			89: {
				x: 244.5,
				y: 624,
				angle: -1.5708,
				front: 5724.8,
				poly: [
					[220, 578],
					[269, 578],
					[269, 670],
					[220, 670]
				],
				physical: "89",
				next: ["72", "73"],
				direct: ["72"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 73: ["90", "72"] }
			},
			90: {
				x: 294,
				y: 624,
				angle: -1.5708,
				front: 5724.8,
				poly: [
					[269, 578],
					[319, 578],
					[319, 670],
					[269, 670]
				],
				physical: "90",
				next: [
					"72",
					"73",
					"74"
				],
				direct: ["73"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					72: ["89", "73"],
					74: ["91", "73"]
				}
			},
			91: {
				x: 344,
				y: 624,
				angle: -1.5708,
				front: 5724.8,
				poly: [
					[319, 578],
					[369, 578],
					[369, 670],
					[319, 670]
				],
				physical: "91",
				next: [
					"73",
					"74",
					"75"
				],
				direct: ["74"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					73: ["90", "74"],
					75: ["92", "74"]
				}
			},
			92: {
				x: 394,
				y: 624,
				angle: -1.5708,
				front: 5724.8,
				poly: [
					[369, 578],
					[419, 578],
					[419, 670],
					[369, 670]
				],
				physical: "92",
				next: ["74", "75"],
				direct: ["75"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 74: ["91", "75"] }
			},
			93: {
				x: 1417.5,
				y: 624,
				angle: 1.5708,
				front: 3898.5,
				poly: [
					[1393, 576],
					[1442, 576],
					[1442, 672],
					[1393, 672]
				],
				physical: "93",
				next: ["94", "99"],
				direct: ["99"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			94: {
				x: 1489.5,
				y: 692,
				angle: 1.5708,
				front: 3966.5,
				poly: [
					[1464, 644],
					[1515, 644],
					[1515, 740],
					[1464, 740]
				],
				physical: "94",
				next: [
					"99",
					"102",
					"103"
				],
				direct: ["102"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 103: ["95", "102"] }
			},
			95: {
				x: 1539.5,
				y: 692,
				angle: 1.5708,
				front: 3966.5,
				poly: [
					[1515, 644],
					[1564, 644],
					[1564, 740],
					[1515, 740]
				],
				physical: "95",
				next: ["102", "103"],
				direct: ["103"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 102: ["94", "103"] }
			},
			96: {
				x: 262,
				y: 718.2,
				angle: -1.5708,
				front: 5628.8,
				poly: [
					[221.6, 674],
					[292.2, 678],
					[291.2, 767.7],
					[244.8, 765.7]
				],
				physical: "96",
				next: [
					"89",
					"90",
					"91"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 91: ["97", "90"] }
			},
			97: {
				x: 319.6,
				y: 720.6,
				angle: -1.5708,
				front: 5628.8,
				poly: [
					[297.2, 674],
					[342.6, 676],
					[340.5, 767.7],
					[298.2, 766.7]
				],
				physical: "97",
				next: [
					"89",
					"90",
					"91",
					"92"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					89: ["96", "90"],
					92: ["98", "91"]
				}
			},
			98: {
				x: 375,
				y: 718.1,
				angle: -1.5708,
				front: 5628.8,
				poly: [
					[346.6, 674],
					[416.1, 678],
					[390.9, 767.7],
					[344.6, 764.7]
				],
				physical: "98",
				next: [
					"90",
					"91",
					"92"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 90: ["97", "91"] }
			},
			99: {
				x: 1417.5,
				y: 720.5,
				angle: 1.5708,
				front: 3995.5,
				poly: [
					[1393, 672],
					[1442, 672],
					[1442, 769],
					[1393, 769]
				],
				physical: "99",
				next: ["102", "114"],
				direct: ["114"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			100: {
				x: 1137.8,
				y: 766.2,
				angle: 2.3884,
				front: 4585.4,
				poly: [
					[1185.8, 707.3],
					[1186.8, 768.7],
					[1146.5, 831.2],
					[1068, 782.8],
					[1112.3, 730.4],
					[1157.6, 710.3]
				],
				physical: "100",
				next: ["112", "115"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			101: {
				x: 1249.3,
				y: 758.6,
				angle: -2.4387,
				front: 4488.8,
				poly: [
					[1188.8, 709.3],
					[1235.2, 713.3],
					[1312.8, 737.5],
					[1333.9, 769.7],
					[1226.1, 816.1],
					[1189.9, 768.7]
				],
				physical: "101",
				next: ["100"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			102: {
				x: 1489.5,
				y: 788.5,
				angle: 1.5708,
				front: 4067.3,
				poly: [
					[1464, 740],
					[1515, 740],
					[1515, 837],
					[1464, 837]
				],
				physical: "102",
				next: ["114", "118"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			103: {
				x: 1539.5,
				y: 788.5,
				angle: 1.5708,
				front: 4063.5,
				poly: [
					[1515, 740],
					[1564, 740],
					[1564, 837],
					[1515, 837]
				],
				physical: "103",
				next: ["118"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			104: {
				x: 272.3,
				y: 815.1,
				angle: -1.5708,
				front: 5533.1,
				poly: [
					[246.8, 769.7],
					[292.2, 771.7],
					[302.2, 853.4],
					[256.9, 863.4],
					[245.8, 822.1]
				],
				physical: "104",
				next: ["96", "97"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					96: ["105", "97"],
					97: ["105", "96"]
				}
			},
			105: {
				x: 324,
				y: 816.3,
				angle: -1.5708,
				front: 5532.1,
				poly: [
					[296.2, 770.7],
					[342.6, 771.7],
					[353.6, 854.4],
					[312.3, 868.5],
					[299.2, 824.1]
				],
				physical: "105",
				next: [
					"96",
					"97",
					"98"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					96: ["104", "97"],
					97: ["104", "96"],
					98: ["106", "97"]
				}
			},
			106: {
				x: 385.2,
				y: 814.4,
				angle: -1.5708,
				front: 5533.1,
				poly: [
					[346.6, 769.7],
					[391.9, 770.7],
					[421.1, 822.1],
					[420.1, 865.4],
					[394.9, 861.4],
					[365.7, 839.2],
					[348.6, 805]
				],
				physical: "106",
				next: ["97", "98"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					97: ["105", "98"],
					98: ["105", "97"]
				}
			},
			107: {
				x: 480,
				y: 843,
				angle: 3.1416,
				front: 5352.1,
				poly: [
					[423, 820],
					[537, 820],
					[537, 866],
					[423, 866]
				],
				physical: "107",
				next: ["106"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			108: {
				x: 594,
				y: 843,
				angle: 3.1416,
				front: 5216.3,
				poly: [
					[537, 820],
					[651, 820],
					[651, 866],
					[537, 866]
				],
				physical: "108",
				next: ["107"],
				direct: ["107"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			109: {
				x: 708,
				y: 843,
				angle: 3.1416,
				front: 5102.3,
				poly: [
					[651, 820],
					[765, 820],
					[765, 866],
					[651, 866]
				],
				physical: "109",
				next: ["108"],
				direct: ["108"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			110: {
				x: 822,
				y: 843,
				angle: 3.1416,
				front: 4988.3,
				poly: [
					[765, 820],
					[879, 820],
					[879, 866],
					[765, 866]
				],
				physical: "110",
				next: ["109"],
				direct: ["109"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			111: {
				x: 938,
				y: 843,
				angle: 3.1416,
				front: 4874.3,
				poly: [
					[879, 820],
					[997, 820],
					[997, 866],
					[879, 866]
				],
				physical: "111",
				next: ["110"],
				direct: ["110"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			112: {
				x: 1044.4,
				y: 826.2,
				angle: 2.339,
				front: 4753.9,
				poly: [
					[1105.2, 811],
					[1056.9, 849.3],
					[1027.6, 861.4],
					[999.4, 864.4],
					[1000.4, 818.1],
					[1068, 787.9]
				],
				physical: "112",
				next: ["111"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			113: {
				x: 1312.1,
				y: 830.8,
				angle: -1.9122,
				front: 4388.1,
				poly: [
					[1314.8, 781.8],
					[1350, 862.4],
					[1308.7, 879.5],
					[1274.5, 798.9]
				],
				physical: "113",
				next: ["101", "116"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			114: {
				x: 1417.5,
				y: 817,
				angle: 1.5708,
				front: 4154,
				poly: [
					[1393, 769],
					[1442, 769],
					[1442, 865],
					[1393, 865]
				],
				physical: "114",
				next: ["117"],
				direct: ["117"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			115: {
				x: 1104.5,
				y: 871.7,
				angle: 2.339,
				front: 4682.1,
				poly: [
					[1112.3, 815.1],
					[1145.5, 840.3],
					[1126.4, 898.7],
					[1104.2, 932.9],
					[1056.9, 879.5]
				],
				physical: "115",
				next: ["112", "126"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			116: {
				x: 1266.4,
				y: 851.3,
				angle: -1.9122,
				front: 4397.5,
				poly: [
					[1270.5, 803],
					[1304.7, 882.6],
					[1262.4, 899.7],
					[1228.1, 820.1]
				],
				physical: "116",
				next: ["101"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			117: {
				x: 1381.6,
				y: 894.7,
				angle: 2.985,
				front: 4278.7,
				poly: [
					[1439.7, 866.4],
					[1427.6, 904.7],
					[1393.4, 925.9],
					[1344, 921.9],
					[1314.8, 894.7],
					[1355.1, 874.5],
					[1394.4, 865.4]
				],
				physical: "117",
				next: [
					"113",
					"116",
					"127"
				],
				direct: ["127"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					113: ["127", "116"],
					116: ["127", "113"]
				}
			},
			118: {
				x: 1503,
				y: 885.9,
				angle: 2.0019,
				front: 4125.7,
				poly: [
					[1553.6, 839.2],
					[1547.5, 902.7],
					[1511.2, 942],
					[1494.1, 950.1],
					[1451.8, 902.7],
					[1464.9, 840.3]
				],
				physical: "118",
				next: [
					"114",
					"117",
					"128"
				],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			119: {
				x: 302.9,
				y: 902.1,
				angle: -2.2545,
				front: 5461.8,
				poly: [
					[259.9, 869.5],
					[305.3, 857.4],
					[344.6, 919.8],
					[315.3, 956.1],
					[271, 902.7]
				],
				physical: "119",
				next: ["104", "105"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			120: {
				x: 377.7,
				y: 908.1,
				angle: -2.8966,
				front: 5433.8,
				poly: [
					[329.5, 868.5],
					[420.1, 898.7],
					[421.1, 944],
					[392.9, 942],
					[350.6, 920.9],
					[332.5, 902.7]
				],
				physical: "120",
				next: [
					"105",
					"106",
					"119"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			121: {
				x: 480,
				y: 923,
				angle: 3.1416,
				front: 5333,
				poly: [
					[423, 899],
					[537, 899],
					[537, 947],
					[423, 947]
				],
				physical: "121",
				next: ["120", "129"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			122: {
				x: 594,
				y: 923,
				angle: 3.1416,
				front: 5216.3,
				poly: [
					[537, 899],
					[651, 899],
					[651, 947],
					[537, 947]
				],
				physical: "122",
				next: ["121", "130"],
				direct: ["121"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 130: ["131", "121"] }
			},
			123: {
				x: 708,
				y: 923,
				angle: 3.1416,
				front: 5102.3,
				poly: [
					[651, 899],
					[765, 899],
					[765, 947],
					[651, 947]
				],
				physical: "123",
				next: ["122", "131"],
				direct: ["122"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 131: ["132", "122"] }
			},
			124: {
				x: 822,
				y: 923,
				angle: 3.1416,
				front: 4988.3,
				poly: [
					[765, 899],
					[879, 899],
					[879, 947],
					[765, 947]
				],
				physical: "124",
				next: ["123", "132"],
				direct: ["123"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 132: ["133", "123"] }
			},
			125: {
				x: 938,
				y: 923,
				angle: 3.1416,
				front: 4874.3,
				poly: [
					[879, 899],
					[997, 899],
					[997, 947],
					[879, 947]
				],
				physical: "125",
				next: ["124", "133"],
				direct: ["124"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 133: ["134", "124"] }
			},
			126: {
				x: 1040.2,
				y: 938.4,
				angle: 3.1416,
				front: 4753.9,
				poly: [
					[1052.8, 883.6],
					[1102.2, 939],
					[1052.8, 982.3],
					[1000.4, 995.4],
					[999.4, 899.7]
				],
				physical: "126",
				next: ["125", "134"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			127: {
				x: 1327.1,
				y: 936.7,
				angle: -2.5478,
				front: 4285.5,
				poly: [
					[1269.4, 912.8],
					[1311.8, 895.7],
					[1372.2, 929.9],
					[1373.2, 976.3],
					[1345, 975.3],
					[1309.8, 961.2],
					[1285.6, 940]
				],
				physical: "127",
				next: ["113", "116"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					113: ["117", "116"],
					116: ["117", "113"]
				}
			},
			128: {
				x: 1426.9,
				y: 944.4,
				angle: 2.5582,
				front: 4210.3,
				poly: [
					[1491.1, 952.1],
					[1432.7, 974.3],
					[1376.2, 973.2],
					[1377.3, 929.9],
					[1447.8, 905.7]
				],
				physical: "128",
				next: ["117", "127"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			129: {
				x: 375.8,
				y: 960.8,
				angle: -2.8966,
				front: 5392.1,
				poly: [
					[318.4, 958.1],
					[347.6, 923.9],
					[420.1, 948.1],
					[421.1, 994.4],
					[372.8, 990.4]
				],
				physical: "129",
				next: ["119", "120"],
				direct: ["120"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			130: {
				x: 480,
				y: 972,
				angle: 3.1416,
				front: 5330.3,
				poly: [
					[423, 947],
					[537, 947],
					[537, 997],
					[423, 997]
				],
				physical: "130",
				next: ["120", "129"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			131: {
				x: 594,
				y: 972,
				angle: 3.1416,
				front: 5216.3,
				poly: [
					[537, 947],
					[651, 947],
					[651, 997],
					[537, 997]
				],
				physical: "131",
				next: ["121", "130"],
				direct: ["130"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 121: ["122", "130"] }
			},
			132: {
				x: 708,
				y: 972,
				angle: 3.1416,
				front: 5102.3,
				poly: [
					[651, 947],
					[765, 947],
					[765, 997],
					[651, 997]
				],
				physical: "132",
				next: ["122", "131"],
				direct: ["131"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 122: ["123", "131"] }
			},
			133: {
				x: 822,
				y: 972,
				angle: 3.1416,
				front: 4988.3,
				poly: [
					[765, 947],
					[879, 947],
					[879, 997],
					[765, 997]
				],
				physical: "133",
				next: ["123", "132"],
				direct: ["132"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 123: ["124", "132"] }
			},
			134: {
				x: 938,
				y: 972,
				angle: 3.1416,
				front: 4874.3,
				poly: [
					[879, 947],
					[997, 947],
					[997, 997],
					[879, 997]
				],
				physical: "134",
				next: ["124", "133"],
				direct: ["133"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 124: ["125", "133"] }
			},
			"14-in": {
				x: 628.5,
				y: 162.7,
				angle: .6796,
				front: 647,
				poly: [
					[603.5, 121.9],
					[654.9, 121.9],
					[691.1, 157.2],
					[629.7, 220.6],
					[565.2, 160.2]
				],
				physical: "14",
				next: ["24-in", "31-in"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"24-in": ["23", "31"],
					"31-in": ["23", "24"]
				}
			},
			"14-out": {
				x: 628.5,
				y: 162.7,
				angle: .6796,
				front: 1567.8,
				poly: [
					[603.5, 121.9],
					[654.9, 121.9],
					[691.1, 157.2],
					[629.7, 220.6],
					[565.2, 160.2]
				],
				physical: "14",
				next: [
					"4",
					"15",
					"24-out"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			"23-in": {
				x: 565.8,
				y: 224.7,
				angle: .4876,
				front: 647.7,
				poly: [
					[561.2, 162.2],
					[624.6, 223.7],
					[563.2, 287.1],
					[521.9, 245.8],
					[522.9, 203.5]
				],
				physical: "23",
				next: ["24-in", "31-in"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"24-in": ["14", "31"],
					"31-in": ["14", "24"]
				}
			},
			"23-out": {
				x: 565.8,
				y: 224.7,
				angle: .4876,
				front: 1474.4,
				poly: [
					[561.2, 162.2],
					[624.6, 223.7],
					[563.2, 287.1],
					[521.9, 245.8],
					[522.9, 203.5]
				],
				physical: "23",
				next: ["14-out", "24-out"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"14-out": ["31", "24"],
					"24-out": ["31", "14"]
				}
			},
			"24-in": {
				x: 690.4,
				y: 224.7,
				angle: -.6992,
				front: 741,
				poly: [
					[693.2, 162.2],
					[732.5, 199.5],
					[733.5, 244.8],
					[695.2, 288.1],
					[631.7, 225.7]
				],
				physical: "24",
				next: ["40", "50"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			"24-out": {
				x: 690.4,
				y: 224.7,
				angle: -.6992,
				front: 1572.3,
				poly: [
					[693.2, 162.2],
					[732.5, 199.5],
					[733.5, 244.8],
					[695.2, 288.1],
					[631.7, 225.7]
				],
				physical: "24",
				next: ["4", "15"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			"31-in": {
				x: 627.6,
				y: 286.6,
				angle: -.793,
				front: 739.5,
				poly: [
					[626.7, 228.7],
					[690.1, 289.2],
					[652.9, 327.4],
					[602.5, 327.4],
					[565.2, 292.2]
				],
				physical: "31",
				next: ["40", "50"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			"31-out": {
				x: 627.6,
				y: 286.6,
				angle: -.793,
				front: 1473.7,
				poly: [
					[626.7, 228.7],
					[690.1, 289.2],
					[652.9, 327.4],
					[602.5, 327.4],
					[565.2, 292.2]
				],
				physical: "31",
				next: ["14-out", "24-out"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"14-out": ["23", "24"],
					"24-out": ["23", "14"]
				}
			},
			"17-in": {
				x: 1022.3,
				y: 164.1,
				angle: .7779,
				front: 1925.2,
				poly: [
					[1045.8, 121.9],
					[1083.1, 159.2],
					[1018.6, 221.6],
					[965.2, 166.2],
					[995.4, 123.9]
				],
				physical: "17",
				next: ["26-in", "32-in"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"26-in": ["25", "32"],
					"32-in": ["25", "26"]
				}
			},
			"17-out": {
				x: 1022.3,
				y: 164.1,
				angle: .7779,
				front: 3044.5,
				poly: [
					[1045.8, 121.9],
					[1083.1, 159.2],
					[1018.6, 221.6],
					[965.2, 166.2],
					[995.4, 123.9]
				],
				physical: "17",
				next: [
					"7",
					"18",
					"26-out"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			"25-in": {
				x: 957.2,
				y: 224.4,
				angle: .5109,
				front: 1923.7,
				poly: [
					[952.1, 162.2],
					[1015.6, 223.7],
					[956.1, 286.1],
					[913.8, 247.8],
					[916.8, 198.5]
				],
				physical: "25",
				next: ["26-in", "32-in"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"26-in": ["17", "32"],
					"32-in": ["17", "26"]
				}
			},
			"25-out": {
				x: 957.2,
				y: 224.4,
				angle: .5109,
				front: 2952.1,
				poly: [
					[952.1, 162.2],
					[1015.6, 223.7],
					[956.1, 286.1],
					[913.8, 247.8],
					[916.8, 198.5]
				],
				physical: "25",
				next: ["17-out", "26-out"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"17-out": ["32", "26"],
					"26-out": ["32", "17"]
				}
			},
			"26-in": {
				x: 1082,
				y: 224.7,
				angle: -.7779,
				front: 2018.4,
				poly: [
					[1085.1, 162.2],
					[1123.4, 199.5],
					[1124.4, 245.8],
					[1087.1, 287.1],
					[1023.6, 226.7]
				],
				physical: "26",
				next: ["43", "44"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					43: ["32", "44"],
					44: ["32", "43"]
				}
			},
			"26-out": {
				x: 1082,
				y: 224.7,
				angle: -.7779,
				front: 3050.8,
				poly: [
					[1085.1, 162.2],
					[1123.4, 199.5],
					[1124.4, 245.8],
					[1087.1, 287.1],
					[1023.6, 226.7]
				],
				physical: "26",
				next: ["7", "18"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			"32-in": {
				x: 1019.5,
				y: 287.2,
				angle: -.7768,
				front: 2017.4,
				poly: [
					[1020.6, 228.7],
					[1082.1, 292.2],
					[1045.8, 326.4],
					[998.4, 331.5],
					[957.1, 290.2]
				],
				physical: "32",
				next: ["43", "44"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					43: ["26", "44"],
					44: ["26", "43"]
				}
			},
			"32-out": {
				x: 1019.5,
				y: 287.2,
				angle: -.7768,
				front: 2952.1,
				poly: [
					[1020.6, 228.7],
					[1082.1, 292.2],
					[1045.8, 326.4],
					[998.4, 331.5],
					[957.1, 290.2]
				],
				physical: "32",
				next: ["17-out", "26-out"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					"17-out": ["25", "26"],
					"26-out": ["25", "17"]
				}
			}
		},
		jumps: [],
		animals: []
	},
	switchback: {
		width: 1920,
		height: 1272,
		length: 5921,
		closed: !0,
		starts: [
			"40",
			"43",
			"54",
			"55",
			"56",
			"57"
		],
		firstStart: "43",
		bets: [
			1373.4,
			2566.2,
			3953.9
		],
		nodes: {
			0: {
				x: 591.3,
				y: 241.8,
				angle: .4706,
				front: 461.4,
				poly: [
					[537.6, 192],
					[571.2, 192],
					[615.6, 214.8],
					[638.4, 236.4],
					[657.6, 272.4],
					[606, 295.2],
					[537.6, 244.8]
				],
				physical: "0",
				next: ["15", "d0"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			1: {
				x: 983.4,
				y: 211.1,
				angle: -.6172,
				front: 1832.4,
				poly: [
					[1063.2, 159.6],
					[1064.4, 174],
					[994.8, 270],
					[891.6, 231.6],
					[918, 202.8],
					[967.2, 176.4],
					[1016.4, 162]
				],
				physical: "1",
				next: ["2", "d7"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { d7: ["d6", "2"] }
			},
			2: {
				x: 1132.6,
				y: 207.4,
				angle: .4167,
				front: 1946,
				poly: [
					[1066.8, 171.6],
					[1105.2, 163.2],
					[1136.4, 171.6],
					[1184.4, 202.8],
					[1210.8, 238.8],
					[1164, 252],
					[1071.6, 214.8]
				],
				physical: "2",
				next: ["9", "10"],
				direct: ["10"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 9: ["d7", "10"] }
			},
			3: {
				x: 1520.4,
				y: 223,
				angle: -.0377,
				front: 3493.9,
				poly: [
					[1597.2, 202.8],
					[1580.4, 231.6],
					[1490.4, 264],
					[1442.4, 240],
					[1473.6, 207.6],
					[1519.2, 189.6],
					[1568.4, 189.6]
				],
				physical: "3",
				next: ["6", "crest4"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			4: {
				x: 527.3,
				y: 289.8,
				angle: -.3604,
				front: 391.9,
				poly: [
					[601.2, 295.2],
					[558, 319.2],
					[502.8, 322.8],
					[450, 297.6],
					[487.2, 265.2],
					[534, 253.2],
					[571.2, 262.8]
				],
				physical: "4",
				next: [
					"0",
					"15",
					"d0"
				],
				direct: ["0"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			5: {
				x: 895.6,
				y: 294.6,
				angle: -1.1475,
				front: 1700.5,
				poly: [
					[888, 236.4],
					[938.4, 254.4],
					[902.4, 352.8],
					[853.2, 336]
				],
				physical: "5",
				next: ["1"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			6: {
				x: 1620.2,
				y: 268.1,
				angle: 1.1479,
				front: 3618.1,
				poly: [
					[1600.8, 207.6],
					[1640.4, 247.2],
					[1663.2, 321.6],
					[1642.8, 327.6],
					[1574.4, 252]
				],
				physical: "6",
				next: ["18", "crest7"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			7: {
				x: 949.8,
				y: 314.4,
				angle: -1.1475,
				front: 1700.5,
				poly: [
					[943.2, 255.6],
					[992.4, 273.6],
					[956.4, 373.2],
					[907.2, 355.2]
				],
				physical: "7",
				next: ["1", "d6"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					1: ["8", "d6"],
					d6: ["8", "1"]
				}
			},
			8: {
				x: 1004.4,
				y: 334.2,
				angle: -1.1475,
				front: 1700.5,
				poly: [
					[997.2, 276],
					[1047.6, 294],
					[1011.6, 392.4],
					[961.2, 374.4]
				],
				physical: "8",
				next: ["1", "d6"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					1: ["7", "d6"],
					d6: ["7", "1"]
				}
			},
			9: {
				x: 1148.7,
				y: 311.8,
				angle: 1.7792,
				front: 2024.1,
				poly: [
					[1152, 259.2],
					[1165.2, 261.6],
					[1174.8, 296.4],
					[1164, 376.8],
					[1140, 370.8],
					[1116, 270]
				],
				physical: "9",
				next: ["21", "22"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			10: {
				x: 1197.6,
				y: 315.7,
				angle: 1.7792,
				front: 2024.1,
				poly: [
					[1167, 245],
					[1209, 242],
					[1224, 282],
					[1232, 320],
					[1231, 386],
					[1167, 374]
				],
				physical: "10",
				next: ["22"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			11: {
				x: 1452.8,
				y: 311,
				angle: -1.5708,
				front: 3318.7,
				poly: [
					[1438.8, 244.8],
					[1485.6, 267.6],
					[1474.8, 368.4],
					[1425.6, 367.2],
					[1423.2, 297.6]
				],
				physical: "11",
				next: ["3", "crest1"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			12: {
				x: 378.8,
				y: 355.4,
				angle: -1.3016,
				front: 250.8,
				poly: [
					[310, 420],
					[343, 335],
					[390, 276],
					[445, 301],
					[419, 357],
					[396, 420]
				],
				physical: "12",
				next: ["4", "nw-outer"],
				direct: ["nw-outer"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			14: {
				x: 450.6,
				y: 370,
				angle: -1.3016,
				front: 241.3,
				poly: [
					[396, 420],
					[418, 357],
					[445, 301],
					[494, 327],
					[482, 420]
				],
				physical: "14",
				next: [
					"4",
					"12",
					"nw-outer"
				],
				direct: ["12"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			15: {
				x: 586.6,
				y: 373.1,
				angle: 1.5922,
				front: 559.7,
				poly: [
					[557, 332],
					[579, 321],
					[614, 304],
					[615, 424],
					[557, 433]
				],
				physical: "15",
				next: ["29", "d2"],
				direct: ["29"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			16: {
				x: 857.8,
				y: 398.2,
				angle: -1.2417,
				front: 1585.3,
				poly: [
					[850.8, 339.6],
					[901.2, 357.6],
					[864, 457.2],
					[814.8, 439.2]
				],
				physical: "16",
				next: ["5", "7"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			18: {
				x: 1640.5,
				y: 392.5,
				angle: 1.3972,
				front: 3741,
				poly: [
					[1616.4, 339.6],
					[1645.2, 331.2],
					[1669.2, 381.6],
					[1665.6, 444],
					[1616.4, 442.8]
				],
				physical: "18",
				next: ["37", "39"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 39: ["crest8", "37"] }
			},
			19: {
				x: 915.1,
				y: 420.9,
				angle: -1.2417,
				front: 1585.3,
				poly: [
					[926.4, 366],
					[955.2, 380.4],
					[915.6, 476.4],
					[872.4, 456],
					[915.6, 372]
				],
				physical: "19",
				next: [
					"5",
					"7",
					"8"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					5: ["16", "7"],
					7: ["20", "8"],
					8: ["20", "7"]
				}
			},
			20: {
				x: 966.2,
				y: 437.9,
				angle: -1.2417,
				front: 1585.3,
				poly: [
					[960, 379.2],
					[1009.2, 397.2],
					[973.2, 496.8],
					[922.8, 477.6]
				],
				physical: "20",
				next: ["7", "8"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					7: ["19", "8"],
					8: ["19", "7"]
				}
			},
			21: {
				x: 1111.6,
				y: 427.1,
				angle: 1.7792,
				front: 2139.6,
				poly: [
					[1112.4, 368.4],
					[1135.2, 375.6],
					[1118.4, 480],
					[1083.6, 470.4]
				],
				physical: "21",
				next: ["33", "34"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			22: {
				x: 1179.4,
				y: 442,
				angle: 1.7792,
				front: 2139.6,
				poly: [
					[1167.6, 384],
					[1219.2, 398.4],
					[1190.4, 500.4],
					[1140, 486]
				],
				physical: "22",
				next: ["33", "34"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			23: {
				x: 1390.8,
				y: 424.3,
				angle: -1.5708,
				front: 3186.7,
				poly: [
					[1365.6, 370.8],
					[1419.6, 373.2],
					[1413.6, 478.8],
					[1364.4, 477.6]
				],
				physical: "23",
				next: ["11", "crest9"],
				direct: ["crest9"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			24: {
				x: 1449.6,
				y: 424.8,
				angle: -1.5708,
				front: 3186.7,
				poly: [
					[1424.4, 370.8],
					[1477.2, 373.2],
					[1474.8, 478.8],
					[1422, 476.4]
				],
				physical: "24",
				next: ["11", "crest9"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			26: {
				x: 327,
				y: 471,
				angle: -1.5708,
				front: 114,
				poly: [
					[287, 421],
					[367, 421],
					[367, 521],
					[287, 521]
				],
				physical: "26",
				next: ["12", "14"],
				direct: ["12"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 14: ["27", "12"] }
			},
			27: {
				x: 396,
				y: 471,
				angle: -1.5708,
				front: 114,
				poly: [
					[367, 421],
					[425, 421],
					[425, 521],
					[367, 521]
				],
				physical: "27",
				next: ["12", "14"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			28: {
				x: 454,
				y: 471,
				angle: -1.5708,
				front: 114,
				poly: [
					[425, 421],
					[483, 421],
					[483, 521],
					[425, 521]
				],
				physical: "28",
				next: ["12", "14"],
				direct: ["14"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 12: ["27", "14"] }
			},
			29: {
				x: 592.4,
				y: 483.9,
				angle: 1.4106,
				front: 672.8,
				poly: [
					[557, 433],
					[615, 424],
					[617, 473],
					[632, 526],
					[581, 550],
					[563, 496]
				],
				physical: "29",
				next: ["44", "45"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			30: {
				x: 820.6,
				y: 499,
				angle: -1.2417,
				front: 1475.2,
				poly: [
					[812.4, 442.8],
					[862.8, 460.8],
					[828, 555.6],
					[778.8, 537.6]
				],
				physical: "30",
				next: ["16", "19"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					16: ["31", "19"],
					19: ["31", "16"]
				}
			},
			31: {
				x: 875.3,
				y: 519.7,
				angle: -1.2417,
				front: 1475.2,
				poly: [
					[870, 464.4],
					[916.8, 481.2],
					[882, 574.8],
					[832.8, 556.8]
				],
				physical: "31",
				next: [
					"16",
					"19",
					"20"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					16: ["30", "19"],
					19: ["30", "16"],
					20: ["32", "19"]
				}
			},
			32: {
				x: 928.8,
				y: 538.8,
				angle: -1.2417,
				front: 1475.2,
				poly: [
					[921.6, 482.4],
					[970.8, 500.4],
					[936, 595.2],
					[886.8, 577.2]
				],
				physical: "32",
				next: ["19", "20"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					19: ["31", "20"],
					20: ["31", "19"]
				}
			},
			33: {
				x: 1086,
				y: 528.1,
				angle: 1.8336,
				front: 2246.8,
				poly: [
					[1113.6, 482.4],
					[1117.2, 489.6],
					[1086, 582],
					[1056, 578.4],
					[1081.2, 476.4]
				],
				physical: "33",
				next: ["49", "58"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			34: {
				x: 1150.2,
				y: 548.4,
				angle: 1.8336,
				front: 2246.8,
				poly: [
					[1138.8, 490.8],
					[1190.4, 505.2],
					[1161.6, 606],
					[1110, 591.6]
				],
				physical: "34",
				next: ["49", "58"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			35: {
				x: 1391.2,
				y: 534.7,
				angle: -1.5471,
				front: 3076.4,
				poly: [
					[1365.6, 481.2],
					[1418.4, 482.4],
					[1416, 589.2],
					[1364.4, 586.8]
				],
				physical: "35",
				next: ["23", "24"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					23: ["36", "24"],
					24: ["36", "23"]
				}
			},
			36: {
				x: 1451.1,
				y: 533.7,
				angle: -1.5471,
				front: 3076.4,
				poly: [
					[1424.4, 481.2],
					[1477.2, 483.6],
					[1473.6, 589.2],
					[1429.2, 586.8]
				],
				physical: "36",
				next: ["23", "24"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					23: ["35", "24"],
					24: ["35", "23"]
				}
			},
			37: {
				x: 1647.2,
				y: 504.8,
				angle: 1.4515,
				front: 3847.7,
				poly: [
					[1614, 448],
					[1685, 448],
					[1686, 559],
					[1604, 559]
				],
				physical: "37",
				next: ["50", "51"],
				direct: ["50"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			39: {
				x: 1727.5,
				y: 503.9,
				angle: 1.4515,
				front: 3847.7,
				poly: [
					[1687.2, 447.6],
					[1759.2, 448.8],
					[1772.4, 558],
					[1690.8, 556.8]
				],
				physical: "39",
				next: [
					"50",
					"51",
					"52"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 50: ["37", "51"] }
			},
			40: {
				x: 315.5,
				y: 594.5,
				angle: -1.0813,
				front: 5916.2,
				poly: [
					[287, 548],
					[344, 548],
					[344, 641],
					[287, 641]
				],
				physical: "40",
				next: ["26"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			41: {
				x: 372.5,
				y: 594.5,
				angle: -1.0813,
				front: 5916.2,
				poly: [
					[344, 548],
					[401, 548],
					[401, 641],
					[344, 641]
				],
				physical: "41",
				next: ["26", "27"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			42: {
				x: 430,
				y: 594.5,
				angle: -1.0813,
				front: 5916.2,
				poly: [
					[401, 548],
					[459, 548],
					[459, 641],
					[401, 641]
				],
				physical: "42",
				next: ["27", "28"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			43: {
				x: 488,
				y: 594.5,
				angle: -1.0813,
				front: 5916.2,
				poly: [
					[459, 548],
					[517, 548],
					[517, 641],
					[459, 641]
				],
				physical: "43",
				next: ["28"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			44: {
				x: 630.3,
				y: 594,
				angle: 1.2667,
				front: 791.1,
				poly: [
					[597.6, 552],
					[632.4, 544.8],
					[654, 609.6],
					[660, 654],
					[645.6, 654],
					[597.6, 571.2]
				],
				physical: "44",
				next: [
					"45",
					"61",
					"62"
				],
				direct: ["45"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			45: {
				x: 678.3,
				y: 592.3,
				angle: 1.2667,
				front: 807.2,
				poly: [
					[636, 537.6],
					[684, 525.6],
					[711.6, 595.2],
					[717.6, 652.8],
					[663.6, 651.6]
				],
				physical: "45",
				next: ["61", "62"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			47: {
				x: 801.8,
				y: 619.1,
				angle: -1.5534,
				front: 1382.5,
				poly: [
					[772.8, 554.4],
					[847.2, 580.8],
					[824.4, 684],
					[762, 663.6]
				],
				physical: "47",
				next: ["30", "31"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			48: {
				x: 876.2,
				y: 644.9,
				angle: -1.5534,
				front: 1355.1,
				poly: [
					[852, 583.2],
					[930, 610.8],
					[891.6, 706.8],
					[829.2, 686.4]
				],
				physical: "48",
				next: [
					"31",
					"32",
					"47"
				],
				direct: ["47"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			49: {
				x: 1076.4,
				y: 645.9,
				angle: 1.8336,
				front: 2357.1,
				poly: [
					[1087.2, 589.2],
					[1105.2, 598.8],
					[1072.8, 697.2],
					[1045.2, 686.4]
				],
				physical: "49",
				next: ["68", "69"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					68: ["58", "69"],
					69: ["58", "68"]
				}
			},
			50: {
				x: 1632.5,
				y: 614,
				angle: 1.4515,
				front: 3957.2,
				poly: [
					[1604, 560],
					[1661, 560],
					[1661, 668],
					[1604, 668]
				],
				physical: "50",
				next: ["64", "65"],
				direct: ["64"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 65: ["51", "64"] }
			},
			51: {
				x: 1689.5,
				y: 614,
				angle: 1.4515,
				front: 3957.2,
				poly: [
					[1661, 560],
					[1718, 560],
					[1718, 668],
					[1661, 668]
				],
				physical: "51",
				next: [
					"64",
					"65",
					"66"
				],
				direct: ["65"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					64: ["50", "65"],
					66: ["52", "65"]
				}
			},
			52: {
				x: 1746.5,
				y: 614,
				angle: 1.4515,
				front: 3957.2,
				poly: [
					[1718, 560],
					[1775, 560],
					[1775, 668],
					[1718, 668]
				],
				physical: "52",
				next: ["65", "66"],
				direct: ["66"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 65: ["51", "66"] }
			},
			54: {
				x: 315.5,
				y: 696,
				angle: -1.5708,
				front: 5800.8,
				poly: [
					[287, 641],
					[344, 641],
					[344, 751],
					[287, 751]
				],
				physical: "54",
				next: ["40", "41"],
				direct: ["40"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 41: ["55", "40"] }
			},
			55: {
				x: 372.5,
				y: 696,
				angle: -1.5708,
				front: 5800.8,
				poly: [
					[344, 641],
					[401, 641],
					[401, 751],
					[344, 751]
				],
				physical: "55",
				next: [
					"40",
					"41",
					"42"
				],
				direct: ["41"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					40: ["54", "41"],
					42: ["56", "41"]
				}
			},
			56: {
				x: 430,
				y: 696,
				angle: -1.5708,
				front: 5800.8,
				poly: [
					[401, 641],
					[459, 641],
					[459, 751],
					[401, 751]
				],
				physical: "56",
				next: [
					"41",
					"42",
					"43"
				],
				direct: ["42"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					41: ["55", "42"],
					43: ["57", "42"]
				}
			},
			57: {
				x: 488,
				y: 696,
				angle: -1.5708,
				front: 5800.8,
				poly: [
					[459, 641],
					[517, 641],
					[517, 751],
					[459, 751]
				],
				physical: "57",
				next: ["42", "43"],
				direct: ["43"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 42: ["56", "43"] }
			},
			58: {
				x: 1120.8,
				y: 654.6,
				angle: 1.8336,
				front: 2357.1,
				poly: [
					[1110, 596.4],
					[1160.4, 610.8],
					[1131.6, 712.8],
					[1081.2, 698.4]
				],
				physical: "58",
				next: ["68", "69"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					68: ["49", "69"],
					69: ["49", "68"]
				}
			},
			59: {
				x: 1384.8,
				y: 650.9,
				angle: -1.2005,
				front: 2960.2,
				poly: [
					[1365.6, 591.6],
					[1419.6, 594],
					[1413.6, 667.2],
					[1393.2, 721.2],
					[1347.6, 694.8]
				],
				physical: "59",
				next: [
					"35",
					"36",
					"bypass0"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					35: ["bypass0", "36"],
					36: ["bypass0", "35"]
				}
			},
			61: {
				x: 636.5,
				y: 713,
				angle: 1.4353,
				front: 903,
				poly: [
					[607, 658],
					[666, 658],
					[666, 768],
					[607, 768]
				],
				physical: "61",
				next: [
					"62",
					"76",
					"d4"
				],
				direct: ["62", "76"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			62: {
				x: 693,
				y: 713,
				angle: 1.4353,
				front: 910.3,
				poly: [
					[666, 658],
					[720, 658],
					[720, 768],
					[666, 768]
				],
				physical: "62",
				next: [
					"76",
					"d4",
					"d5"
				],
				direct: ["d4"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			63: {
				x: 787.4,
				y: 729.1,
				angle: -1.2775,
				front: 1243.4,
				poly: [
					[766.8, 669.6],
					[824.4, 690],
					[799.2, 794.4],
					[756, 770.4]
				],
				physical: "63",
				next: ["47", "48"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			64: {
				x: 1632.5,
				y: 725,
				angle: 1.6016,
				front: 4063.4,
				poly: [
					[1604, 668],
					[1661, 668],
					[1661, 782],
					[1604, 782]
				],
				physical: "64",
				next: ["79", "80"],
				direct: ["79"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 80: ["65", "79"] }
			},
			65: {
				x: 1689.5,
				y: 725,
				angle: 1.6016,
				front: 4063.4,
				poly: [
					[1661, 668],
					[1718, 668],
					[1718, 782],
					[1661, 782]
				],
				physical: "65",
				next: [
					"79",
					"80",
					"81"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					79: ["64", "80"],
					80: ["64", "79"]
				}
			},
			66: {
				x: 1746.5,
				y: 725,
				angle: 1.6016,
				front: 4063.4,
				poly: [
					[1718, 668],
					[1775, 668],
					[1775, 782],
					[1718, 782]
				],
				physical: "66",
				next: ["80", "81"],
				direct: ["81"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 80: ["65", "81"] }
			},
			67: {
				x: 844.6,
				y: 755.6,
				angle: -1.2775,
				front: 1240.8,
				poly: [
					[829.2, 691.2],
					[889.2, 711.6],
					[854.4, 825.6],
					[802.8, 796.8]
				],
				physical: "67",
				next: ["47", "48"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			68: {
				x: 1054.1,
				y: 753.7,
				angle: 1.6214,
				front: 2482.4,
				poly: [
					[1044, 692.4],
					[1075.2, 700.8],
					[1071.6, 807.6],
					[1052.4, 823.2],
					[1030.8, 776.4],
					[1034.4, 716.4]
				],
				physical: "68",
				next: ["84"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			69: {
				x: 1111.2,
				y: 754.9,
				angle: 1.6214,
				front: 2482.4,
				poly: [
					[1080, 702],
					[1131.6, 717.6],
					[1153.2, 813.6],
					[1136.4, 811.2],
					[1078.8, 769.2],
					[1071.6, 735.6]
				],
				physical: "69",
				next: ["77", "84"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			70: {
				x: 1328,
				y: 765,
				angle: -.7776,
				front: 2814.9,
				poly: [
					[1383.6, 735.6],
					[1342.8, 776.4],
					[1280.4, 801.6],
					[1280.4, 777.6],
					[1363.2, 729.6]
				],
				physical: "70",
				next: [
					"59",
					"bypass2",
					"bypass3"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			73: {
				x: 326.1,
				y: 807.5,
				angle: -1.913,
				front: 5705.8,
				poly: [
					[295.2, 752.4],
					[357.6, 753.6],
					[346.8, 878.4],
					[322.8, 883.2],
					[289.2, 786]
				],
				physical: "73",
				next: ["54", "55"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			74: {
				x: 379,
				y: 815.4,
				angle: -1.913,
				front: 5681.5,
				poly: [
					[398.4, 752.4],
					[416.4, 856.8],
					[350.4, 876],
					[346.8, 841.2],
					[357.6, 756]
				],
				physical: "74",
				next: [
					"54",
					"55",
					"56",
					"73"
				],
				direct: ["73"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			75: {
				x: 460.7,
				y: 807.2,
				angle: -1.9787,
				front: 5664.7,
				poly: [
					[403.2, 753.6],
					[511.2, 752.4],
					[516, 850.8],
					[428.4, 876],
					[409.2, 816]
				],
				physical: "75",
				next: [
					"55",
					"56",
					"57",
					"74"
				],
				direct: ["57", "74"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			76: {
				x: 657,
				y: 823,
				angle: 1.0612,
				front: 1021.4,
				poly: [
					[612, 769.2],
					[664.8, 769.2],
					[705.6, 880.8],
					[686.4, 888],
					[642, 854.4],
					[620.4, 818.4]
				],
				physical: "76",
				next: ["83", "d5"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			77: {
				x: 1210,
				y: 799.8,
				angle: -.267,
				front: 2683.1,
				poly: [
					[1261.2, 786],
					[1257.6, 810],
					[1176, 830.4],
					[1164, 781.2],
					[1224, 776.4]
				],
				physical: "77",
				next: ["70", "bypass4"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			78: {
				x: 1234.9,
				y: 847.3,
				angle: -.267,
				front: 2683.1,
				poly: [
					[1279.2, 808.8],
					[1291.2, 860.4],
					[1189.2, 885.6],
					[1179.6, 834]
				],
				physical: "78",
				next: ["70", "bypass4"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			79: {
				x: 1623.3,
				y: 837.2,
				angle: 1.9974,
				front: 4199.6,
				poly: [
					[1605.6, 781.2],
					[1658.4, 783.6],
					[1651.2, 853.2],
					[1636.8, 896.4],
					[1585.2, 885.6]
				],
				physical: "79",
				next: ["87"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			80: {
				x: 1677.2,
				y: 846.6,
				angle: 1.9974,
				front: 4199.6,
				poly: [
					[1663.2, 781.2],
					[1682.4, 782.4],
					[1713.6, 823.2],
					[1692, 906],
					[1641.6, 896.4]
				],
				physical: "80",
				next: ["87", "96"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			81: {
				x: 1737,
				y: 846.2,
				angle: 1.9974,
				front: 4199.6,
				poly: [
					[1771.2, 781.2],
					[1770, 848.4],
					[1744.8, 914.4],
					[1698, 907.2],
					[1719.6, 783.6]
				],
				physical: "81",
				next: ["96"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			83: {
				x: 778.4,
				y: 852.3,
				angle: -.5834,
				front: 1137.7,
				poly: [
					[850.8, 830.4],
					[828, 861.6],
					[784.8, 889.2],
					[727.2, 897.6],
					[715.2, 888],
					[723.6, 843.6],
					[800.4, 802.8]
				],
				physical: "83",
				next: ["63", "67"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			84: {
				x: 1117.4,
				y: 854.9,
				angle: .3972,
				front: 2584.5,
				poly: [
					[1052.4, 828],
					[1075.2, 811.2],
					[1160.4, 840],
					[1173.6, 890.4],
					[1138.8, 896.4],
					[1105.2, 886.8]
				],
				physical: "84",
				next: ["77", "78"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			85: {
				x: 399.3,
				y: 921.7,
				angle: -2.2719,
				front: 5579.5,
				poly: [
					[417.6, 861.6],
					[458.4, 944.4],
					[397.2, 988.8],
					[349.2, 928.8],
					[349.2, 880.8]
				],
				physical: "85",
				next: [
					"73",
					"74",
					"75"
				],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			86: {
				x: 491.9,
				y: 915.7,
				angle: -2.2719,
				front: 5526.9,
				poly: [
					[516, 855.6],
					[541.2, 946.8],
					[501.6, 987.6],
					[454.8, 931.2],
					[430.8, 880.8]
				],
				physical: "86",
				next: [
					"74",
					"75",
					"85"
				],
				direct: ["85"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			87: {
				x: 1582.5,
				y: 943.3,
				angle: 2.583,
				front: 4339.3,
				poly: [
					[1656, 903.6],
					[1638, 937.2],
					[1602, 976.8],
					[1537.2, 1004.4],
					[1516.8, 961.2],
					[1581.6, 890.4]
				],
				physical: "87",
				next: [
					"95",
					"106",
					"107"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			95: {
				x: 1477.8,
				y: 993.5,
				angle: 2.8312,
				front: 4461.1,
				poly: [
					[1537.2, 1016.4],
					[1407.6, 1003.2],
					[1406.4, 990],
					[1513.2, 966]
				],
				physical: "95",
				next: [
					"105",
					"106",
					"112"
				],
				direct: ["106"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			96: {
				x: 1672.5,
				y: 959,
				angle: 2.3047,
				front: 4278.3,
				poly: [
					[1740, 918],
					[1728, 948],
					[1651.2, 1026],
					[1609.2, 981.6],
					[1669.2, 906]
				],
				physical: "96",
				next: ["87", "107"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			97: {
				x: 469.1,
				y: 1007.5,
				angle: -2.6442,
				front: 5476.9,
				poly: [
					[459.6, 948],
					[526.8, 1012.8],
					[501.6, 1068],
					[440.4, 1032],
					[403.2, 994.8]
				],
				physical: "97",
				next: ["85", "86"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			98: {
				x: 576.1,
				y: 997.9,
				angle: -2.879,
				front: 5383.7,
				poly: [
					[507.6, 990],
					[546, 950.4],
					[631.2, 990],
					[631.2, 1041.6],
					[561.6, 1028.4]
				],
				physical: "98",
				next: ["86", "97"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			99: {
				x: 688,
				y: 1016,
				angle: 3.1416,
				front: 5248.3,
				poly: [
					[633, 987],
					[743, 987],
					[743, 1045],
					[633, 1045]
				],
				physical: "99",
				next: ["98", "109"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			100: {
				x: 798,
				y: 1016,
				angle: 3.1416,
				front: 5138.3,
				poly: [
					[743, 987],
					[853, 987],
					[853, 1045],
					[743, 1045]
				],
				physical: "100",
				next: ["99", "110"],
				direct: ["99"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 110: ["111", "99"] }
			},
			101: {
				x: 908,
				y: 1016,
				angle: 3.1416,
				front: 5028.3,
				poly: [
					[853, 987],
					[963, 987],
					[963, 1045],
					[853, 1045]
				],
				physical: "101",
				next: ["100", "111"],
				direct: ["100"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 111: ["bridge0", "100"] }
			},
			102: {
				x: 1018,
				y: 1016,
				angle: 3.1416,
				front: 4918.3,
				poly: [
					[963, 987],
					[1073, 987],
					[1073, 1045],
					[963, 1045]
				],
				physical: "102",
				next: ["101", "bridge1"],
				direct: ["101"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			103: {
				x: 1128,
				y: 1016,
				angle: 3.1416,
				front: 4808.3,
				poly: [
					[1073, 987],
					[1183, 987],
					[1183, 1045],
					[1073, 1045]
				],
				physical: "103",
				next: ["102", "bridge3"],
				direct: ["102"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			104: {
				x: 1238,
				y: 1016,
				angle: 3.1416,
				front: 4698.3,
				poly: [
					[1183, 987],
					[1293, 987],
					[1293, 1045],
					[1183, 1045]
				],
				physical: "104",
				next: ["103", "bridge5"],
				direct: ["103"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			105: {
				x: 1349,
				y: 1016,
				angle: 3.1416,
				front: 4588.3,
				poly: [
					[1293, 987],
					[1405, 987],
					[1405, 1045],
					[1293, 1045]
				],
				physical: "105",
				next: ["104", "bridge7"],
				direct: ["104"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			106: {
				x: 1451.7,
				y: 1022.9,
				angle: 2.8312,
				front: 4474,
				poly: [
					[1406.4, 1041.6],
					[1407.6, 1003.2],
					[1530, 1017.6],
					[1468.8, 1038]
				],
				physical: "106",
				next: [
					"105",
					"112",
					"bridge9"
				],
				direct: ["112"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			107: {
				x: 1576.2,
				y: 1033.6,
				angle: 2.583,
				front: 4383.3,
				poly: [
					[1604.4, 981.6],
					[1641.6, 1032],
					[1588.8, 1064.4],
					[1534.8, 1083.6],
					[1516.8, 1029.6]
				],
				physical: "107",
				next: [
					"95",
					"106",
					"112"
				],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			109: {
				x: 568.7,
				y: 1053.2,
				angle: -2.879,
				front: 5364.7,
				poly: [
					[507.6, 1063.2],
					[530.4, 1016.4],
					[631.2, 1047.6],
					[630, 1080],
					[514.8, 1071.6]
				],
				physical: "109",
				next: ["97", "98"],
				direct: ["98"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			110: {
				x: 688,
				y: 1074.5,
				angle: 3.1416,
				front: 5248.3,
				poly: [
					[633, 1045],
					[743, 1045],
					[743, 1104],
					[633, 1104]
				],
				physical: "110",
				next: ["98", "109"],
				direct: [],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			111: {
				x: 798,
				y: 1074.5,
				angle: 3.1416,
				front: 5138.3,
				poly: [
					[743, 1045],
					[853, 1045],
					[853, 1104],
					[743, 1104]
				],
				physical: "111",
				next: ["99", "110"],
				direct: ["110"],
				rectangle: !0,
				rumble: !0,
				danger: !1,
				gates: { 99: ["100", "110"] }
			},
			112: {
				x: 1464.1,
				y: 1068.2,
				angle: 2.8312,
				front: 4491.6,
				poly: [
					[1514.4, 1033.2],
					[1527.6, 1086],
					[1446, 1100.4],
					[1406.4, 1099.2],
					[1407.6, 1046.4]
				],
				physical: "112",
				next: ["105", "bridge9"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			"nw-outer": {
				x: 472.1,
				y: 244.6,
				angle: -.3604,
				front: 368.2,
				poly: [
					[390, 276],
					[421, 243],
					[455, 217],
					[493, 199],
					[537, 192],
					[537, 253],
					[486, 261],
					[445, 301]
				],
				physical: "nw-outer",
				next: ["0", "4"],
				direct: ["0", "4"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			d0: {
				x: 641,
				y: 327.5,
				angle: 1.5922,
				front: 495.4,
				poly: [
					[614, 304],
					[665, 283],
					[666, 355],
					[618, 370]
				],
				physical: "d0",
				next: ["15", "d1"],
				direct: ["15", "d1"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			d1: {
				x: 642.2,
				y: 393,
				angle: 1.5922,
				front: 555.4,
				poly: [
					[618, 370],
					[666, 355],
					[664, 419],
					[620, 430]
				],
				physical: "d1",
				next: [
					"15",
					"29",
					"d2"
				],
				direct: ["d2"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			d2: {
				x: 645.3,
				y: 451.4,
				angle: 1.4106,
				front: 616.6,
				poly: [
					[620, 430],
					[664, 419],
					[667, 475],
					[631, 485]
				],
				physical: "d2",
				next: ["29", "d3"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			d3: {
				x: 658.5,
				y: 505.3,
				angle: 1.4106,
				front: 669.8,
				poly: [
					[631, 485],
					[667, 475],
					[687, 524],
					[649, 536]
				],
				physical: "d3",
				next: ["44", "45"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			d4: {
				x: 701.7,
				y: 789.8,
				angle: 1.0612,
				front: 971.2,
				poly: [
					[666, 768],
					[720, 768],
					[736, 791],
					[706, 823],
					[683, 806]
				],
				physical: "d4",
				next: [
					"63",
					"76",
					"83",
					"d5"
				],
				direct: ["d5"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			d5: {
				x: 752.3,
				y: 808.7,
				angle: .4115,
				front: 1057.3,
				poly: [
					[706, 823],
					[736, 791],
					[756, 789],
					[775, 777],
					[800, 802],
					[758, 828],
					[726, 838]
				],
				physical: "d5",
				next: [
					"63",
					"67",
					"83"
				],
				direct: ["83"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			d6: {
				x: 1042,
				y: 254.7,
				angle: -.1448,
				front: 1832.4,
				poly: [
					[994, 273],
					[1022, 236],
					[1068, 220],
					[1078, 269],
					[1047, 281]
				],
				physical: "d6",
				next: ["2", "d7"],
				direct: ["d7"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			d7: {
				x: 1112.6,
				y: 249,
				angle: .4167,
				front: 1946,
				poly: [
					[1078, 269],
					[1068, 220],
					[1123, 229],
					[1167, 253],
					[1167, 266],
					[1118, 271]
				],
				physical: "d7",
				next: ["9", "10"],
				direct: ["9"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: { 10: ["2", "9"] }
			},
			crest0: {
				x: 1401.9,
				y: 269.1,
				angle: -1.249,
				front: 3318.7,
				poly: [
					[1369, 303],
					[1369.3, 292.8],
					[1370.2, 282.5],
					[1371.7, 272.4],
					[1373.8, 262.4],
					[1376.5, 252.5],
					[1379.8, 242.8],
					[1383.6, 233.3],
					[1388, 224],
					[1440.5, 250.8],
					[1437.6, 256.9],
					[1435.1, 263.2],
					[1433, 269.6],
					[1431.2, 276.2],
					[1429.8, 282.8],
					[1428.8, 289.5],
					[1428.2, 296.2],
					[1428, 303]
				],
				physical: "crest0",
				next: ["3", "crest1"],
				direct: ["crest1"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest1: {
				x: 1432.7,
				y: 208.8,
				angle: -.5978,
				front: 3365,
				poly: [
					[1388, 224],
					[1392.9, 215],
					[1398.3, 206.3],
					[1404.3, 198],
					[1410.7, 190],
					[1417.6, 182.4],
					[1424.9, 175.2],
					[1432.6, 168.5],
					[1440.7, 162.2],
					[1475.4, 210],
					[1470, 214.1],
					[1464.9, 218.6],
					[1460.1, 223.3],
					[1455.6, 228.3],
					[1451.3, 233.6],
					[1447.4, 239.1],
					[1443.8, 244.8],
					[1440.5, 250.8]
				],
				physical: "crest1",
				next: ["3", "crest2"],
				direct: ["3", "crest2"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest2: {
				x: 1498.5,
				y: 166,
				angle: -.0377,
				front: 3434.7,
				poly: [
					[1440.7, 162.2],
					[1452.1, 154.6],
					[1464, 148],
					[1476.4, 142.2],
					[1489.2, 137.5],
					[1502.4, 133.8],
					[1515.8, 131.1],
					[1529.3, 129.5],
					[1543, 129],
					[1543, 188],
					[1534, 188.4],
					[1525, 189.4],
					[1516.2, 191.2],
					[1507.5, 193.6],
					[1499, 196.8],
					[1490.8, 200.5],
					[1482.9, 204.9],
					[1475.4, 210]
				],
				physical: "crest2",
				next: ["3", "crest3"],
				direct: ["3", "crest3"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest3: {
				x: 1581.2,
				y: 163.4,
				angle: .3914,
				front: 3493.9,
				poly: [
					[1543, 129],
					[1554.6, 129.4],
					[1566.2, 130.5],
					[1577.6, 132.5],
					[1588.9, 135.2],
					[1600, 138.6],
					[1610.8, 142.8],
					[1621.4, 147.7],
					[1631.6, 153.2],
					[1601.5, 204],
					[1594.8, 200.3],
					[1587.8, 197.1],
					[1580.7, 194.3],
					[1573.3, 192.1],
					[1565.9, 190.3],
					[1558.3, 189],
					[1550.7, 188.3],
					[1543, 188]
				],
				physical: "crest3",
				next: ["6", "crest4"],
				direct: ["crest4"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest4: {
				x: 1644,
				y: 198.8,
				angle: .7697,
				front: 3540.6,
				poly: [
					[1631.6, 153.2],
					[1640.2, 158.7],
					[1648.6, 164.7],
					[1656.5, 171.1],
					[1664.1, 178],
					[1671.2, 185.4],
					[1677.9, 193.1],
					[1684.2, 201.3],
					[1689.9, 209.8],
					[1640.1, 241.4],
					[1636.3, 235.8],
					[1632.2, 230.4],
					[1627.8, 225.3],
					[1623, 220.4],
					[1618, 215.8],
					[1612.8, 211.6],
					[1607.3, 207.6],
					[1601.5, 204]
				],
				physical: "crest4",
				next: ["6", "crest5"],
				direct: ["crest5"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest5: {
				x: 1679.7,
				y: 253.8,
				angle: 1.1479,
				front: 3590.7,
				poly: [
					[1689.9, 209.8],
					[1694.8, 218],
					[1699.3, 226.5],
					[1703.2, 235.2],
					[1706.7, 244.1],
					[1709.7, 253.1],
					[1712.2, 262.4],
					[1714.2, 271.7],
					[1715.6, 281.2],
					[1657.1, 288.6],
					[1656.1, 282.3],
					[1654.8, 276.2],
					[1653.2, 270],
					[1651.2, 264],
					[1648.9, 258.2],
					[1646.3, 252.4],
					[1643.3, 246.8],
					[1640.1, 241.4]
				],
				physical: "crest5",
				next: ["6", "crest6"],
				direct: ["crest6"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest6: {
				x: 1693.6,
				y: 303.7,
				angle: 1.3972,
				front: 3618.1,
				poly: [
					[1658, 281],
					[1716, 275],
					[1730, 321],
					[1674, 337]
				],
				physical: "crest6",
				next: ["18", "crest7"],
				direct: ["crest7"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest7: {
				x: 1709.2,
				y: 359.1,
				angle: 1.3972,
				front: 3678.5,
				poly: [
					[1674, 337],
					[1730, 321],
					[1744, 386],
					[1686, 393]
				],
				physical: "crest7",
				next: ["18", "crest8"],
				direct: ["crest8"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest8: {
				x: 1719.3,
				y: 419.2,
				angle: 1.3972,
				front: 3741,
				poly: [
					[1686, 393],
					[1744, 386],
					[1758, 447],
					[1686, 447]
				],
				physical: "crest8",
				next: ["37", "39"],
				direct: ["39"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			crest9: {
				x: 1392,
				y: 336.2,
				angle: -1.5708,
				front: 3259.5,
				poly: [
					[1363, 298],
					[1422, 305],
					[1422, 371],
					[1363, 371]
				],
				physical: "crest9",
				next: ["11", "crest0"],
				direct: ["11", "crest0"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bypass0: {
				x: 1449.8,
				y: 621,
				angle: -1.5471,
				front: 2969.9,
				poly: [
					[1422, 589],
					[1479, 589],
					[1477, 655],
					[1420, 651]
				],
				physical: "bypass0",
				next: ["35", "36"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {
					35: ["59", "36"],
					36: ["59", "35"]
				}
			},
			bypass1: {
				x: 1443.7,
				y: 681.4,
				angle: -1.2005,
				front: 2924.1,
				poly: [
					[1420, 651],
					[1477, 655],
					[1463, 719],
					[1410, 700]
				],
				physical: "bypass1",
				next: ["59", "bypass0"],
				direct: ["bypass0"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bypass2: {
				x: 1424,
				y: 733.2,
				angle: -1.2005,
				front: 2859.4,
				poly: [
					[1410, 700],
					[1463, 719],
					[1429, 773],
					[1388, 738]
				],
				physical: "bypass2",
				next: ["59", "bypass1"],
				direct: ["bypass1"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bypass3: {
				x: 1387.9,
				y: 775.7,
				angle: -.7776,
				front: 2821,
				poly: [
					[1388, 738],
					[1429, 773],
					[1384, 816],
					[1349, 773]
				],
				physical: "bypass3",
				next: ["59", "bypass2"],
				direct: ["bypass2"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bypass4: {
				x: 1329.3,
				y: 810.8,
				angle: -.5223,
				front: 2769.9,
				poly: [
					[1349, 773],
					[1384, 816],
					[1298, 848],
					[1281, 805]
				],
				physical: "bypass4",
				next: ["70", "bypass3"],
				direct: ["70", "bypass3"],
				rectangle: !1,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge0: {
				x: 880.6,
				y: 1074.5,
				angle: 3.1416,
				front: 5028.3,
				poly: [
					[853, 1045],
					[908.2, 1045],
					[908.2, 1104],
					[853, 1104]
				],
				physical: "bridge0",
				next: ["100", "111"],
				direct: ["111"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: { 100: ["101", "111"] }
			},
			bridge1: {
				x: 935.8,
				y: 1074.5,
				angle: 3.1416,
				front: 4973.1,
				poly: [
					[908.2, 1045],
					[963.4, 1045],
					[963.4, 1104],
					[908.2, 1104]
				],
				physical: "bridge1",
				next: ["101", "bridge0"],
				direct: ["101", "bridge0"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge2: {
				x: 991,
				y: 1074.5,
				angle: 3.1416,
				front: 4917.9,
				poly: [
					[963.4, 1045],
					[1018.6, 1045],
					[1018.6, 1104],
					[963.4, 1104]
				],
				physical: "bridge2",
				next: ["101", "bridge1"],
				direct: ["bridge1"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge3: {
				x: 1046.2,
				y: 1074.5,
				angle: 3.1416,
				front: 4862.7,
				poly: [
					[1018.6, 1045],
					[1073.8, 1045],
					[1073.8, 1104],
					[1018.6, 1104]
				],
				physical: "bridge3",
				next: ["102", "bridge2"],
				direct: ["102", "bridge2"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge4: {
				x: 1101.4,
				y: 1074.5,
				angle: 3.1416,
				front: 4807.5,
				poly: [
					[1073.8, 1045],
					[1129, 1045],
					[1129, 1104],
					[1073.8, 1104]
				],
				physical: "bridge4",
				next: ["102", "bridge3"],
				direct: ["bridge3"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge5: {
				x: 1156.6,
				y: 1074.5,
				angle: 3.1416,
				front: 4752.3,
				poly: [
					[1129, 1045],
					[1184.2, 1045],
					[1184.2, 1104],
					[1129, 1104]
				],
				physical: "bridge5",
				next: ["103", "bridge4"],
				direct: ["103", "bridge4"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge6: {
				x: 1211.8,
				y: 1074.5,
				angle: 3.1416,
				front: 4697.1,
				poly: [
					[1184.2, 1045],
					[1239.4, 1045],
					[1239.4, 1104],
					[1184.2, 1104]
				],
				physical: "bridge6",
				next: ["103", "bridge5"],
				direct: ["bridge5"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge7: {
				x: 1267,
				y: 1074.5,
				angle: 3.1416,
				front: 4641.9,
				poly: [
					[1239.4, 1045],
					[1294.6, 1045],
					[1294.6, 1104],
					[1239.4, 1104]
				],
				physical: "bridge7",
				next: ["104", "bridge6"],
				direct: ["104", "bridge6"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge8: {
				x: 1322.2,
				y: 1074.5,
				angle: 3.1416,
				front: 4586.7,
				poly: [
					[1294.6, 1045],
					[1349.8, 1045],
					[1349.8, 1104],
					[1294.6, 1104]
				],
				physical: "bridge8",
				next: ["104", "bridge7"],
				direct: ["bridge7"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			},
			bridge9: {
				x: 1377.4,
				y: 1074.5,
				angle: 3.1416,
				front: 4531.5,
				poly: [
					[1349.8, 1045],
					[1405, 1045],
					[1405, 1104],
					[1349.8, 1104]
				],
				physical: "bridge9",
				next: ["105", "bridge8"],
				direct: ["105", "bridge8"],
				rectangle: !0,
				rumble: !1,
				danger: !0,
				gates: {}
			}
		},
		jumps: [],
		animals: []
	},
	aloha: {
		width: 2836,
		height: 1466,
		length: 8630.7,
		closed: !0,
		starts: [
			"82",
			"115",
			"89",
			"start-front",
			"112",
			"six-landing"
		],
		firstStart: "start-front",
		bets: [
			1893.1,
			4245,
			6152.8
		],
		nodes: {
			3: {
				x: 447.8,
				y: 174.3,
				angle: -.0615,
				front: 1887.7,
				poly: [
					[540.6, 131.2],
					[540.6, 189.7],
					[388.2, 223.3],
					[336.8, 179],
					[413, 140]
				],
				physical: "3",
				next: ["4", "13"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			4: {
				x: 646.5,
				y: 161,
				angle: 0,
				front: 2074.1,
				poly: [
					[562, 128],
					[731, 128],
					[731, 194],
					[562, 194]
				],
				physical: "4",
				next: ["14"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			5: {
				x: 1225,
				y: 161,
				angle: 0,
				front: 2646.1,
				poly: [
					[1147, 128],
					[1303, 128],
					[1303, 194],
					[1147, 194]
				],
				physical: "5",
				next: ["6"],
				direct: ["6"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			6: {
				x: 1391.5,
				y: 161,
				angle: 0,
				front: 2823.1,
				poly: [
					[1303, 128],
					[1480, 128],
					[1480, 194],
					[1303, 194]
				],
				physical: "6",
				next: ["7"],
				direct: ["7"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			7: {
				x: 1569.5,
				y: 161,
				angle: 0,
				front: 3002.1,
				poly: [
					[1480, 128],
					[1659, 128],
					[1659, 194],
					[1480, 194]
				],
				physical: "7",
				next: ["8"],
				direct: ["8"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			8: {
				x: 1751.5,
				y: 161,
				angle: 0,
				front: 3187.1,
				poly: [
					[1659, 128],
					[1844, 128],
					[1844, 194],
					[1659, 194]
				],
				physical: "8",
				next: ["9", "17"],
				direct: ["9"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			9: {
				x: 1940.7,
				y: 169.3,
				angle: .265,
				front: 3378.9,
				poly: [
					[1839.9, 189.7],
					[1841.6, 131.2],
					[1958.6, 134.7],
					[2052.6, 157.8],
					[2024.2, 212.7]
				],
				physical: "9",
				next: ["18", "20"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			12: {
				x: 462.7,
				y: 242.2,
				angle: -.0615,
				front: 1887.7,
				poly: [
					[542.4, 196.7],
					[540.6, 255.2],
					[430.7, 290.7],
					[359.8, 265.9],
					[421.9, 214.5],
					[480.3, 198.5]
				],
				physical: "12",
				next: ["4", "13"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			13: {
				x: 646.5,
				y: 226.5,
				angle: 0,
				front: 2074.1,
				poly: [
					[562, 194],
					[731, 194],
					[731, 259],
					[562, 259]
				],
				physical: "13",
				next: ["14"],
				direct: ["14"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			14: {
				x: 812,
				y: 226.5,
				angle: 0,
				front: 2236.1,
				poly: [
					[731, 194],
					[893, 194],
					[893, 259],
					[731, 259]
				],
				physical: "14",
				next: ["15"],
				direct: ["15"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			15: {
				x: 974,
				y: 226.5,
				angle: 0,
				front: 2398.1,
				poly: [
					[893, 194],
					[1055, 194],
					[1055, 259],
					[893, 259]
				],
				physical: "15",
				next: ["16"],
				direct: ["16"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			16: {
				x: 1136.5,
				y: 226.5,
				angle: 0,
				front: 2561.1,
				poly: [
					[1055, 194],
					[1218, 194],
					[1218, 259],
					[1055, 259]
				],
				physical: "16",
				next: ["5"],
				direct: ["5"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			18: {
				x: 2130.4,
				y: 217.8,
				angle: .265,
				front: 3555.3,
				poly: [
					[2056.1, 164.8],
					[2220.9, 210.9],
					[2203.2, 267.6],
					[2176.6, 267.6],
					[2036.6, 218]
				],
				physical: "18",
				next: ["21"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			19: {
				x: 314.5,
				y: 259.1,
				angle: -1.4492,
				front: 1718.9,
				poly: [
					[382.9, 226.9],
					[329.7, 320.8],
					[249.9, 317.3],
					[264.1, 251.7],
					[326.1, 180.8]
				],
				physical: "19",
				next: ["3", "12"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			20: {
				x: 2082.9,
				y: 272.7,
				angle: .265,
				front: 3513.7,
				poly: [
					[2024.2, 225.1],
					[2162.4, 267.6],
					[2143, 319],
					[2004.7, 280.1]
				],
				physical: "20",
				next: ["18", "21"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			21: {
				x: 2233.4,
				y: 322.3,
				angle: .343,
				front: 3676.5,
				poly: [
					[2148.3, 326.1],
					[2176.6, 273],
					[2318.4, 317.3],
					[2288.3, 372.2]
				],
				physical: "21",
				next: ["24"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			22: {
				x: 378.1,
				y: 352.4,
				angle: -1.4492,
				front: 1709.8,
				poly: [
					[354.5, 271.2],
					[425.4, 297.8],
					[414.8, 423.6],
					[335, 420.1],
					[336.8, 313.7]
				],
				physical: "22",
				next: ["12", "19"],
				direct: ["19"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			24: {
				x: 2382.2,
				y: 371.3,
				angle: .343,
				front: 3831.1,
				poly: [
					[2323.7, 322.6],
					[2465.5, 365.1],
					[2440.7, 420.1],
					[2298.9, 377.5]
				],
				physical: "24",
				next: ["26", "29"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			26: {
				x: 2570.8,
				y: 406.5,
				angle: .8224,
				front: 3948.7,
				poly: [
					[2499.2, 365.1],
					[2582.5, 351],
					[2621.5, 398.8],
					[2630.4, 457.3],
					[2552.4, 459.1]
				],
				physical: "26",
				next: ["29", "31"],
				direct: ["29"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			27: {
				x: 377.5,
				y: 488.3,
				angle: -1.5708,
				front: 1500.8,
				poly: [
					[338.5, 427.2],
					[418.3, 430.7],
					[416.5, 549.5],
					[336.8, 545.9]
				],
				physical: "27",
				next: ["22"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			29: {
				x: 2493,
				y: 458.1,
				angle: .8224,
				front: 4081.1,
				poly: [
					[2476.2, 370.5],
					[2524, 400.6],
					[2545.3, 450.2],
					[2532.9, 506.9],
					[2490.4, 547.7],
					[2451.4, 503.4],
					[2447.8, 418.3]
				],
				physical: "29",
				next: ["30", "46"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					30: ["31", "46"],
					46: ["31", "30"]
				}
			},
			30: {
				x: 2392.2,
				y: 546.5,
				angle: 2.9124,
				front: 4239,
				poly: [
					[2478, 549.5],
					[2403.5, 579.6],
					[2320.2, 584.9],
					[2325.5, 526.4],
					[2444.3, 505.2]
				],
				physical: "30",
				next: [],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			31: {
				x: 2563.2,
				y: 525.9,
				angle: 2.1193,
				front: 4081.1,
				poly: [
					[2632.2, 464.4],
					[2628.6, 503.4],
					[2594.9, 560.1],
					[2525.8, 604.4],
					[2492.1, 554.8],
					[2550.6, 466.2]
				],
				physical: "31",
				next: ["30", "46"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {
					30: ["29", "46"],
					46: ["29", "30"]
				}
			},
			32: {
				x: 1336.4,
				y: 570.3,
				angle: 2.9294,
				front: 5264.1,
				poly: [
					[1405.6, 530],
					[1403.8, 590.2],
					[1286.8, 613.3],
					[1251.4, 567.2],
					[1322.3, 537.1]
				],
				physical: "32",
				next: ["42"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			33: {
				x: 1488.5,
				y: 560,
				angle: 3.1416,
				front: 5141.9,
				poly: [
					[1407, 527],
					[1570, 527],
					[1570, 593],
					[1407, 593]
				],
				physical: "33",
				next: ["32"],
				direct: ["32"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			34: {
				x: 1651.5,
				y: 560,
				angle: 3.1416,
				front: 4979,
				poly: [
					[1570, 527],
					[1733, 527],
					[1733, 593],
					[1570, 593]
				],
				physical: "34",
				next: ["33", "43"],
				direct: ["33", "43"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			35: {
				x: 1814,
				y: 560,
				angle: 3.1416,
				front: 4816,
				poly: [
					[1733, 527],
					[1895, 527],
					[1895, 593],
					[1733, 593]
				],
				physical: "35",
				next: ["34", "44"],
				direct: ["34", "44"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			36: {
				x: 1974.5,
				y: 560,
				angle: 3.1416,
				front: 4654,
				poly: [
					[1895, 527],
					[2054, 527],
					[2054, 593],
					[1895, 593]
				],
				physical: "36",
				next: ["35", "45"],
				direct: ["35", "45"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			37: {
				x: 290,
				y: 613.5,
				angle: -1.5708,
				front: 1378,
				poly: [
					[246, 550],
					[334, 550],
					[334, 677],
					[246, 677]
				],
				physical: "37",
				next: ["27"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			38: {
				x: 378.5,
				y: 613.5,
				angle: -1.5708,
				front: 1378,
				poly: [
					[334, 550],
					[423, 550],
					[423, 677],
					[334, 677]
				],
				physical: "38",
				next: ["27"],
				direct: ["27"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			42: {
				x: 1201.4,
				y: 637.6,
				angle: 2.5432,
				front: 5409.3,
				poly: [
					[1278, 611.5],
					[1191.1, 701.9],
					[1120.2, 678.9],
					[1169.8, 611.5],
					[1237.2, 567.2]
				],
				physical: "42",
				next: ["50"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			43: {
				x: 1585,
				y: 625.5,
				angle: 3.1416,
				front: 5054,
				poly: [
					[1495, 593],
					[1675, 593],
					[1675, 658],
					[1495, 658]
				],
				physical: "43",
				next: ["33"],
				direct: ["33"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			44: {
				x: 1755,
				y: 625.5,
				angle: 3.1416,
				front: 4874,
				poly: [
					[1675, 593],
					[1835, 593],
					[1835, 658],
					[1675, 658]
				],
				physical: "44",
				next: ["34", "43"],
				direct: ["34", "43"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			45: {
				x: 1914.5,
				y: 625.5,
				angle: 3.1416,
				front: 4714,
				poly: [
					[1835, 593],
					[1994, 593],
					[1994, 658],
					[1835, 658]
				],
				physical: "45",
				next: ["35", "44"],
				direct: ["35", "44"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			46: {
				x: 2415.5,
				y: 608.8,
				angle: 2.9124,
				front: 4239,
				poly: [
					[2517, 602.6],
					[2506.3, 622.1],
					[2460.2, 638.1],
					[2322, 654.1],
					[2323.7, 592],
					[2485, 560.1]
				],
				physical: "46",
				next: [],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			48: {
				x: 290,
				y: 741,
				angle: -1.5708,
				front: 1251,
				poly: [
					[246, 677],
					[334, 677],
					[334, 805],
					[246, 805]
				],
				physical: "48",
				next: ["37", "38"],
				direct: ["37"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 38: ["inner-vertical", "37"] }
			},
			50: {
				x: 1144.4,
				y: 756.2,
				angle: 2.0647,
				front: 5531.1,
				poly: [
					[1114.9, 689.5],
					[1189.3, 707.2],
					[1180.5, 811.8],
					[1113.1, 822.4],
					[1100.7, 748]
				],
				physical: "50",
				next: ["53", "59"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			53: {
				x: 1243,
				y: 805.2,
				angle: .5337,
				front: 5672.2,
				poly: [
					[1191.1, 751.5],
					[1265.6, 758.6],
					[1299.2, 829.5],
					[1254.9, 873.8],
					[1196.4, 810]
				],
				physical: "53",
				next: ["60"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			56: {
				x: 290,
				y: 868.5,
				angle: -1.5708,
				front: 1123,
				poly: [
					[246, 805],
					[334, 805],
					[334, 932],
					[246, 932]
				],
				physical: "56",
				next: ["48", "inner-vertical"],
				direct: ["48"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { "inner-vertical": ["57", "48"] }
			},
			57: {
				x: 378.5,
				y: 868.5,
				angle: -1.5708,
				front: 1123,
				poly: [
					[334, 805],
					[423, 805],
					[423, 932],
					[334, 932]
				],
				physical: "57",
				next: ["48", "inner-vertical"],
				direct: ["inner-vertical"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 48: ["56", "inner-vertical"] }
			},
			59: {
				x: 1203.9,
				y: 878.7,
				angle: .5337,
				front: 5672.2,
				poly: [
					[1120.2, 831.3],
					[1191.1, 813.6],
					[1281.5, 904],
					[1242.5, 951.8],
					[1178.7, 911.1]
				],
				physical: "59",
				next: ["60", "70"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			60: {
				x: 1351.4,
				y: 879.3,
				angle: .2315,
				front: 5818.8,
				poly: [
					[1260.2, 877.4],
					[1304.6, 833.1],
					[1421.5, 861.4],
					[1426.9, 921.7],
					[1331.1, 912.8]
				],
				physical: "60",
				next: ["61", "71"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					61: ["70", "71"],
					71: ["70", "61"]
				}
			},
			61: {
				x: 1510,
				y: 894.5,
				angle: 0,
				front: 5978.8,
				poly: [
					[1430, 861],
					[1590, 861],
					[1590, 928],
					[1430, 928]
				],
				physical: "61",
				next: ["62", "72"],
				direct: ["62"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 72: ["71", "62"] }
			},
			62: {
				x: 1668.5,
				y: 894.5,
				angle: 0,
				front: 6135.8,
				poly: [
					[1590, 861],
					[1747, 861],
					[1747, 928],
					[1590, 928]
				],
				physical: "62",
				next: ["63", "73"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					63: ["72", "73"],
					73: ["72", "63"]
				}
			},
			63: {
				x: 1843,
				y: 894.5,
				angle: 0,
				front: 6310.8,
				poly: [
					[1764, 861],
					[1922, 861],
					[1922, 928],
					[1764, 928]
				],
				physical: "63",
				next: ["64"],
				direct: ["64"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			64: {
				x: 2002,
				y: 894.5,
				angle: 0,
				front: 6470.8,
				poly: [
					[1922, 861],
					[2082, 861],
					[2082, 928],
					[1922, 928]
				],
				physical: "64",
				next: ["65"],
				direct: ["65"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			65: {
				x: 2163.5,
				y: 894.5,
				angle: 0,
				front: 6633.8,
				poly: [
					[2082, 861],
					[2245, 861],
					[2245, 928],
					[2082, 928]
				],
				physical: "65",
				next: ["66"],
				direct: ["66"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			66: {
				x: 2326,
				y: 894.5,
				angle: 0,
				front: 6795.8,
				poly: [
					[2245, 861],
					[2407, 861],
					[2407, 928],
					[2245, 928]
				],
				physical: "66",
				next: ["67", "east-landing"],
				direct: ["east-landing"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			67: {
				x: 2495.9,
				y: 908.5,
				angle: .3239,
				front: 6946.4,
				poly: [
					[2410.6, 863.2],
					[2517, 872.1],
					[2600.3, 914.6],
					[2548.9, 958.9],
					[2412.4, 923.5]
				],
				physical: "67",
				next: ["74", "79"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			68: {
				x: 290,
				y: 996,
				angle: -1.5708,
				front: 996,
				poly: [
					[246, 932],
					[334, 932],
					[334, 1060],
					[246, 1060]
				],
				physical: "68",
				next: ["56", "57"],
				direct: ["56"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 57: ["69", "56"] }
			},
			69: {
				x: 378.5,
				y: 996,
				angle: -1.5708,
				front: 996,
				poly: [
					[334, 932],
					[423, 932],
					[423, 1060],
					[334, 1060]
				],
				physical: "69",
				next: ["56", "57"],
				direct: ["57"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 56: ["68", "57"] }
			},
			70: {
				x: 1347.7,
				y: 948.3,
				angle: .2315,
				front: 5818.8,
				poly: [
					[1253.2, 951.8],
					[1288.6, 904],
					[1425.1, 928.8],
					[1426.9, 989.1],
					[1329.4, 982]
				],
				physical: "70",
				next: ["61", "71"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					61: ["60", "71"],
					71: ["60", "61"]
				}
			},
			71: {
				x: 1510,
				y: 961.5,
				angle: 0,
				front: 5978.8,
				poly: [
					[1430, 928],
					[1590, 928],
					[1590, 995],
					[1430, 995]
				],
				physical: "71",
				next: ["62", "72"],
				direct: ["72"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 62: ["61", "72"] }
			},
			72: {
				x: 1668.5,
				y: 961.5,
				angle: 0,
				front: 6135.8,
				poly: [
					[1590, 928],
					[1747, 928],
					[1747, 995],
					[1590, 995]
				],
				physical: "72",
				next: ["63", "73"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					63: ["62", "73"],
					73: ["62", "63"]
				}
			},
			73: {
				x: 1843,
				y: 961.5,
				angle: 0,
				front: 6310.8,
				poly: [
					[1764, 928],
					[1922, 928],
					[1922, 995],
					[1764, 995]
				],
				physical: "73",
				next: ["64"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			74: {
				x: 2622.4,
				y: 999.6,
				angle: .9358,
				front: 7064.5,
				poly: [
					[2605.6, 918.2],
					[2633.9, 937.7],
					[2671.2, 990.8],
					[2681.8, 1067],
					[2603.8, 1065.3],
					[2557.7, 960.7]
				],
				physical: "74",
				next: [
					"79",
					"83",
					"95"
				],
				direct: ["79"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			79: {
				x: 2542.9,
				y: 1031.3,
				angle: .9358,
				front: 7124.6,
				poly: [
					[2520.5, 951.8],
					[2580.8, 1003.2],
					[2598.5, 1052.9],
					[2594.9, 1095.4],
					[2515.2, 1084.8],
					[2485, 1001.5]
				],
				physical: "79",
				next: ["83", "95"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			80: {
				x: 311.9,
				y: 1123.8,
				angle: -2.1143,
				front: 876.5,
				poly: [
					[253.5, 1065.3],
					[333.2, 1061.7],
					[375.8, 1161],
					[312, 1200],
					[264.1, 1134.4]
				],
				physical: "80",
				next: ["68", "69"],
				direct: ["68"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: { 69: ["81", "68"] }
			},
			81: {
				x: 410.4,
				y: 1120.8,
				angle: -2.583,
				front: 876.5,
				poly: [
					[342.1, 1063.5],
					[421.9, 1065.3],
					[478.6, 1141.5],
					[441.4, 1191.1],
					[405.9, 1175.2],
					[365.1, 1136.2]
				],
				physical: "81",
				next: ["68", "69"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					68: ["80", "69"],
					69: ["80", "68"]
				}
			},
			82: {
				x: 1233,
				y: 1134,
				angle: 3.1416,
				front: 8596.7,
				poly: [
					[1164, 1101],
					[1302, 1101],
					[1302, 1167],
					[1164, 1167]
				],
				physical: "82",
				next: ["87"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			83: {
				x: 2633.2,
				y: 1140.2,
				angle: 2.0344,
				front: 7183.1,
				poly: [
					[2607.3, 1072.4],
					[2685.3, 1075.9],
					[2685.3, 1139.7],
					[2651.7, 1219.5],
					[2568.4, 1182.3]
				],
				physical: "83",
				next: ["95", "114"],
				direct: ["95"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			84: {
				x: 552.6,
				y: 1187.5,
				angle: -2.881,
				front: 683.3,
				poly: [
					[446.7, 1192.9],
					[485.7, 1145],
					[641.6, 1168.1],
					[643.4, 1223],
					[538.8, 1223]
				],
				physical: "84",
				next: ["81", "97"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			85: {
				x: 740.2,
				y: 1191.2,
				angle: 3.1416,
				front: 481,
				poly: [
					[649, 1167],
					[820, 1134],
					[820, 1233],
					[649, 1233]
				],
				physical: "85",
				next: ["84", "107"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			86: {
				x: 900,
				y: 1167,
				angle: 3.1416,
				front: 310,
				poly: [
					[820, 1134],
					[980, 1134],
					[980, 1200],
					[820, 1200]
				],
				physical: "86",
				next: ["85", "108"],
				direct: ["85"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 108: ["98", "85"] }
			},
			87: {
				x: 1055,
				y: 1167,
				angle: 3.1416,
				front: 150,
				poly: [
					[980, 1134],
					[1130, 1134],
					[1130, 1200],
					[980, 1200]
				],
				physical: "87",
				next: ["86", "98"],
				direct: ["86"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 98: ["99", "86"] }
			},
			88: {
				x: 1233,
				y: 1200,
				angle: 3.1416,
				front: 8596.7,
				poly: [
					[1164, 1167],
					[1302, 1167],
					[1302, 1233],
					[1164, 1233]
				],
				physical: "88",
				next: ["87", "99"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			89: {
				x: 1385,
				y: 1167,
				angle: 3.1416,
				front: 8458.7,
				poly: [
					[1302, 1134],
					[1468, 1134],
					[1468, 1200],
					[1302, 1200]
				],
				physical: "89",
				next: [
					"82",
					"88",
					"111"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 111: ["100", "88"] }
			},
			90: {
				x: 1710.5,
				y: 1167,
				angle: 3.1416,
				front: 8130.7,
				poly: [
					[1630, 1134],
					[1791, 1134],
					[1791, 1200],
					[1630, 1200]
				],
				physical: "90",
				next: ["101", "start-front"],
				direct: ["start-front"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 101: ["102", "start-front"] }
			},
			91: {
				x: 1872.5,
				y: 1167,
				angle: 3.1416,
				front: 7969.7,
				poly: [
					[1791, 1134],
					[1954, 1134],
					[1954, 1200],
					[1791, 1200]
				],
				physical: "91",
				next: ["90", "102"],
				direct: ["90"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 102: ["103", "90"] }
			},
			92: {
				x: 2034.5,
				y: 1167,
				angle: 3.1416,
				front: 7806.7,
				poly: [
					[1954, 1134],
					[2115, 1134],
					[2115, 1200],
					[1954, 1200]
				],
				physical: "92",
				next: ["91", "103"],
				direct: ["91"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 103: ["104", "91"] }
			},
			93: {
				x: 2196.5,
				y: 1167,
				angle: 3.1416,
				front: 7645.7,
				poly: [
					[2115, 1134],
					[2278, 1134],
					[2278, 1200],
					[2115, 1200]
				],
				physical: "93",
				next: ["92", "104"],
				direct: ["92"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 104: ["105", "92"] }
			},
			94: {
				x: 2359.5,
				y: 1167,
				angle: 3.1416,
				front: 7482.7,
				poly: [
					[2278, 1134],
					[2441, 1134],
					[2441, 1200],
					[2278, 1200]
				],
				physical: "94",
				next: ["93", "105"],
				direct: ["93"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 105: ["106", "93"] }
			},
			95: {
				x: 2509.2,
				y: 1156,
				angle: 2.6903,
				front: 7320.7,
				poly: [
					[2596.7, 1100.7],
					[2579, 1153.9],
					[2541.8, 1196.4],
					[2481.5, 1226.6],
					[2440.7, 1228.3],
					[2442.5, 1136.2],
					[2513.4, 1091.9]
				],
				physical: "95",
				next: [
					"94",
					"106",
					"113"
				],
				direct: ["94"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 113: ["114", "106"] }
			},
			97: {
				x: 414.2,
				y: 1220.9,
				angle: -2.583,
				front: 809.2,
				poly: [
					[320.8, 1203.5],
					[386.4, 1166.3],
					[489.2, 1215.9],
					[492.8, 1226.6],
					[473.3, 1274.4],
					[452, 1276.2],
					[338.5, 1223]
				],
				physical: "97",
				next: ["80", "81"],
				direct: ["81"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			98: {
				x: 900,
				y: 1233.5,
				angle: 3.1416,
				front: 310,
				poly: [
					[820, 1200],
					[980, 1200],
					[980, 1267],
					[820, 1267]
				],
				physical: "98",
				next: ["85", "108"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			99: {
				x: 1055,
				y: 1233.5,
				angle: 3.1416,
				front: 150,
				poly: [
					[980, 1200],
					[1130, 1200],
					[1130, 1267],
					[980, 1267]
				],
				physical: "99",
				next: [
					"86",
					"98",
					"109"
				],
				direct: ["98"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					86: ["87", "98"],
					109: ["110", "98"]
				}
			},
			100: {
				x: 1385,
				y: 1233.5,
				angle: 3.1416,
				front: 8458.7,
				poly: [
					[1302, 1200],
					[1468, 1200],
					[1468, 1267],
					[1302, 1267]
				],
				physical: "100",
				next: [
					"82",
					"88",
					"111",
					"115"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					82: ["89", "88"],
					115: ["112", "111"]
				}
			},
			101: {
				x: 1549,
				y: 1233.5,
				angle: 3.1416,
				front: 8292.7,
				poly: [
					[1468, 1200],
					[1630, 1200],
					[1630, 1267],
					[1468, 1267]
				],
				physical: "101",
				next: [
					"89",
					"100",
					"112"
				],
				direct: ["100"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					89: ["start-front", "100"],
					112: ["six-landing", "100"]
				}
			},
			102: {
				x: 1710.5,
				y: 1233.5,
				angle: 3.1416,
				front: 8130.7,
				poly: [
					[1630, 1200],
					[1791, 1200],
					[1791, 1267],
					[1630, 1267]
				],
				physical: "102",
				next: [
					"101",
					"start-front",
					"six-landing"
				],
				direct: ["101"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { "start-front": ["90", "101"] }
			},
			103: {
				x: 1872.5,
				y: 1233.5,
				angle: 3.1416,
				front: 7969.7,
				poly: [
					[1791, 1200],
					[1954, 1200],
					[1954, 1267],
					[1791, 1267]
				],
				physical: "103",
				next: ["90", "102"],
				direct: ["102"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 90: ["91", "102"] }
			},
			104: {
				x: 2034.5,
				y: 1233.5,
				angle: 3.1416,
				front: 7806.7,
				poly: [
					[1954, 1200],
					[2115, 1200],
					[2115, 1267],
					[1954, 1267]
				],
				physical: "104",
				next: ["91", "103"],
				direct: ["103"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 91: ["92", "103"] }
			},
			105: {
				x: 2196.5,
				y: 1233.5,
				angle: 3.1416,
				front: 7645.7,
				poly: [
					[2115, 1200],
					[2278, 1200],
					[2278, 1267],
					[2115, 1267]
				],
				physical: "105",
				next: ["92", "104"],
				direct: ["104"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 92: ["93", "104"] }
			},
			106: {
				x: 2359.5,
				y: 1233.5,
				angle: 3.1416,
				front: 7482.7,
				poly: [
					[2278, 1200],
					[2441, 1200],
					[2441, 1267],
					[2278, 1267]
				],
				physical: "106",
				next: ["93", "105"],
				direct: ["105"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 93: ["94", "105"] }
			},
			107: {
				x: 565.6,
				y: 1260.3,
				angle: -2.881,
				front: 651.4,
				poly: [
					[478.6, 1274.4],
					[501.6, 1221.3],
					[643.4, 1235.4],
					[641.6, 1295.7],
					[530, 1292.2]
				],
				physical: "107",
				next: ["84", "97"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			108: {
				x: 740.3,
				y: 1275.1,
				angle: 3.1416,
				front: 481,
				poly: [
					[649, 1233],
					[820, 1233],
					[820, 1333],
					[649, 1299]
				],
				physical: "108",
				next: ["84", "107"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			109: {
				x: 900,
				y: 1300,
				angle: 3.1416,
				front: 310,
				poly: [
					[820, 1267],
					[980, 1267],
					[980, 1333],
					[820, 1333]
				],
				physical: "109",
				next: ["85", "108"],
				direct: ["108"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 85: ["98", "108"] }
			},
			110: {
				x: 1055,
				y: 1300,
				angle: 3.1416,
				front: 150,
				poly: [
					[980, 1267],
					[1130, 1267],
					[1130, 1333],
					[980, 1333]
				],
				physical: "110",
				next: ["98", "109"],
				direct: ["109"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 98: ["99", "109"] }
			},
			111: {
				x: 1233,
				y: 1266,
				angle: 3.1416,
				front: 8596.7,
				poly: [
					[1164, 1233],
					[1302, 1233],
					[1302, 1299],
					[1164, 1299]
				],
				physical: "111",
				next: ["99", "110"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			112: {
				x: 1385,
				y: 1300,
				angle: 3.1416,
				front: 8458.7,
				poly: [
					[1302, 1267],
					[1468, 1267],
					[1468, 1333],
					[1302, 1333]
				],
				physical: "112",
				next: [
					"88",
					"111",
					"115"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 88: ["100", "111"] }
			},
			113: {
				x: 2359.5,
				y: 1300,
				angle: 3.1416,
				front: 7482.7,
				poly: [
					[2278, 1267],
					[2441, 1267],
					[2441, 1333],
					[2278, 1333]
				],
				physical: "113",
				next: ["105"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			114: {
				x: 2527.9,
				y: 1259.5,
				angle: 2.6903,
				front: 7320.7,
				poly: [
					[2646.3, 1224.8],
					[2570.1, 1302.8],
					[2499.2, 1327.6],
					[2440.7, 1331.1],
					[2442.5, 1235.4],
					[2561.3, 1187.6]
				],
				physical: "114",
				next: [
					"94",
					"106",
					"113"
				],
				direct: ["113"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: { 94: ["95", "106"] }
			},
			115: {
				x: 1233,
				y: 1332,
				angle: 3.1416,
				front: 8596.7,
				poly: [
					[1164, 1299],
					[1302, 1299],
					[1302, 1365],
					[1164, 1365]
				],
				physical: "115",
				next: ["110"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			17: {
				x: 1925,
				y: 236.2,
				angle: .265,
				front: 3361.3,
				poly: [
					[1844, 194],
					[2018, 218],
					[1994, 278],
					[1844, 258]
				],
				physical: "17",
				next: [
					"9",
					"18",
					"20"
				],
				direct: ["9"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			"inner-vertical": {
				x: 378.5,
				y: 741,
				angle: -1.5708,
				front: 1251,
				poly: [
					[334, 677],
					[423, 677],
					[423, 805],
					[334, 805]
				],
				physical: "inner-vertical",
				next: ["37", "38"],
				direct: ["38"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 37: ["48", "38"] }
			},
			"start-front": {
				x: 1549,
				y: 1167,
				angle: 3.1416,
				front: 8292.7,
				poly: [
					[1468, 1134],
					[1630, 1134],
					[1630, 1200],
					[1468, 1200]
				],
				physical: "start-front",
				next: ["89", "100"],
				direct: ["89"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 100: ["101", "89"] }
			},
			"six-landing": {
				x: 1549,
				y: 1300,
				angle: 3.1416,
				front: 8292.7,
				poly: [
					[1468, 1267],
					[1630, 1267],
					[1630, 1333],
					[1468, 1333]
				],
				physical: "six-landing",
				next: ["100", "112"],
				direct: ["112"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 100: ["101", "112"] }
			},
			"east-landing": {
				x: 2424.8,
				y: 964.1,
				angle: .3239,
				front: 6946.4,
				poly: [
					[2334, 930],
					[2417, 930],
					[2546, 951],
					[2484, 1002],
					[2400, 993],
					[2334, 993]
				],
				physical: "east-landing",
				next: ["74", "79"],
				direct: ["79"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			}
		},
		jumps: [
			{
				from: "37",
				to: "19",
				speed: 3,
				ramp: "west-3"
			},
			{
				from: "4",
				to: "5",
				speed: 5,
				ramp: "north-5"
			},
			{
				from: "16",
				to: "17",
				speed: 4,
				ramp: "north-inner-4"
			},
			{
				from: "18",
				to: "26",
				speed: 4,
				ramp: "northeast-4"
			},
			{
				from: "30",
				to: "36",
				speed: 3,
				ramp: "east-double-3"
			},
			{
				from: "46",
				to: "45",
				speed: 3,
				ramp: "east-double-3"
			},
			{
				from: "43",
				to: "53",
				speed: 4,
				ramp: "west-inner-4"
			},
			{
				from: "73",
				to: "east-landing",
				speed: 4,
				ramp: "southeast-inner-4"
			},
			{
				from: "113",
				to: "six-landing",
				speed: 6,
				ramp: "south-6"
			}
		],
		animals: []
	},
	savanna: {
		width: 2778,
		height: 1344,
		length: 10189.6,
		closed: !1,
		starts: [
			"first-start",
			"0",
			"1",
			"23",
			"24",
			"25"
		],
		firstStart: "first-start",
		bets: [
			3154.5,
			5130.4,
			7237.6
		],
		nodes: {
			0: {
				x: 346,
				y: 110.5,
				angle: -.0166,
				front: 327.5,
				poly: [
					[266, 80],
					[426, 80],
					[426, 141],
					[266, 141]
				],
				physical: "0",
				next: ["1", "13"],
				direct: ["1"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 13: ["12", "1"] }
			},
			1: {
				x: 497.5,
				y: 110.5,
				angle: -.0166,
				front: 470.5,
				poly: [
					[426, 80],
					[569, 80],
					[569, 141],
					[426, 141]
				],
				physical: "1",
				next: ["2", "14"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			2: {
				x: 680,
				y: 111,
				angle: -.0166,
				front: 651.5,
				poly: [
					[610, 80],
					[750, 80],
					[750, 142],
					[610, 142]
				],
				physical: "2",
				next: ["15", "a1"],
				direct: ["a1"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			5: {
				x: 1156,
				y: 111,
				angle: -.0166,
				front: 1131.4,
				poly: [
					[1082, 80],
					[1230, 80],
					[1230, 142],
					[1082, 142]
				],
				physical: "5",
				next: ["e1", "pre-e1"],
				direct: ["pre-e1"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { e1: ["17", "pre-e1"] }
			},
			6: {
				x: 1476.5,
				y: 110.5,
				angle: -.0166,
				front: 1454.3,
				poly: [
					[1400, 80],
					[1553, 80],
					[1553, 141],
					[1400, 141]
				],
				physical: "6",
				next: ["7", "19"],
				direct: ["7"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 19: ["18", "7"] }
			},
			7: {
				x: 1630.5,
				y: 110.5,
				angle: -.0166,
				front: 1609.3,
				poly: [
					[1553, 80],
					[1708, 80],
					[1708, 141],
					[1553, 141]
				],
				physical: "7",
				next: ["8", "20"],
				direct: ["8"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 20: ["19", "8"] }
			},
			8: {
				x: 1788,
				y: 110.5,
				angle: -.0166,
				front: 1769.3,
				poly: [
					[1708, 80],
					[1868, 80],
					[1868, 141],
					[1708, 141]
				],
				physical: "8",
				next: ["9", "21"],
				direct: ["9"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 21: ["20", "9"] }
			},
			9: {
				x: 1948,
				y: 110.5,
				angle: -.0166,
				front: 1929.3,
				poly: [
					[1868, 80],
					[2028, 80],
					[2028, 141],
					[1868, 141]
				],
				physical: "9",
				next: ["10"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			10: {
				x: 2096.9,
				y: 118.1,
				angle: .2347,
				front: 2062.1,
				poly: [
					[2029.7, 74.7],
					[2074.8, 74.7],
					[2161.6, 102.4],
					[2158.2, 171.9],
					[2031.4, 132]
				],
				physical: "10",
				next: ["31", "p1"],
				direct: ["p1"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			11: {
				x: 183,
				y: 171.5,
				angle: -.0166,
				front: 166.5,
				poly: [
					[100, 141],
					[266, 141],
					[266, 202],
					[100, 202]
				],
				physical: "11",
				next: [
					"0",
					"12",
					"24"
				],
				direct: ["12"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					0: ["first-start", "12"],
					24: ["23", "12"]
				}
			},
			12: {
				x: 346,
				y: 171.5,
				angle: -.0166,
				front: 326.5,
				poly: [
					[266, 141],
					[426, 141],
					[426, 202],
					[266, 202]
				],
				physical: "12",
				next: [
					"1",
					"13",
					"25"
				],
				direct: ["13"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					1: ["0", "13"],
					25: ["24", "13"]
				}
			},
			13: {
				x: 497.5,
				y: 171.5,
				angle: -.0166,
				front: 469.5,
				poly: [
					[426, 141],
					[569, 141],
					[569, 202],
					[426, 202]
				],
				physical: "13",
				next: [
					"2",
					"14",
					"26"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			14: {
				x: 680,
				y: 172,
				angle: -.0166,
				front: 650.4,
				poly: [
					[610, 142],
					[750, 142],
					[750, 202],
					[610, 202]
				],
				physical: "14",
				next: [
					"15",
					"27",
					"a1"
				],
				direct: ["15"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 27: ["26", "15"] }
			},
			15: {
				x: 829.5,
				y: 172,
				angle: -.0166,
				front: 809.4,
				poly: [
					[750, 142],
					[909, 142],
					[909, 202],
					[750, 202]
				],
				physical: "15",
				next: [
					"16",
					"28",
					"a1"
				],
				direct: ["16", "a1"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 28: ["27", "16"] }
			},
			16: {
				x: 988,
				y: 172,
				angle: -.0166,
				front: 967.4,
				poly: [
					[909, 142],
					[1067, 142],
					[1067, 202],
					[909, 202]
				],
				physical: "16",
				next: [
					"5",
					"17",
					"29"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					5: ["a1", "17"],
					17: ["28", "29"],
					29: ["28", "17"]
				}
			},
			17: {
				x: 1156,
				y: 172,
				angle: -.0166,
				front: 1130.4,
				poly: [
					[1082, 142],
					[1230, 142],
					[1230, 202],
					[1082, 202]
				],
				physical: "17",
				next: ["e1", "pre-e1"],
				direct: ["e1"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { "pre-e1": ["5", "e1"] }
			},
			18: {
				x: 1476.5,
				y: 169.5,
				angle: -.0166,
				front: 1453.3,
				poly: [
					[1400, 141],
					[1553, 141],
					[1553, 198],
					[1400, 198]
				],
				physical: "18",
				next: ["7", "19"],
				direct: ["19"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 7: ["6", "19"] }
			},
			19: {
				x: 1630.5,
				y: 169.5,
				angle: -.0166,
				front: 1608.3,
				poly: [
					[1553, 141],
					[1708, 141],
					[1708, 198],
					[1553, 198]
				],
				physical: "19",
				next: ["8", "20"],
				direct: ["20"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 8: ["7", "20"] }
			},
			20: {
				x: 1788,
				y: 169.5,
				angle: -.0166,
				front: 1768.3,
				poly: [
					[1708, 141],
					[1868, 141],
					[1868, 198],
					[1708, 198]
				],
				physical: "20",
				next: ["9", "21"],
				direct: ["21"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 9: ["8", "21"] }
			},
			21: {
				x: 1948,
				y: 169.5,
				angle: -.0166,
				front: 1928.3,
				poly: [
					[1868, 141],
					[2028, 141],
					[2028, 198],
					[1868, 198]
				],
				physical: "21",
				next: ["10"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			23: {
				x: 183,
				y: 232.5,
				angle: -.0166,
				front: 165.5,
				poly: [
					[100, 202],
					[266, 202],
					[266, 263],
					[100, 263]
				],
				physical: "23",
				next: ["12", "24"],
				direct: ["24"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 12: ["11", "24"] }
			},
			24: {
				x: 346,
				y: 232.5,
				angle: -.0166,
				front: 325.5,
				poly: [
					[266, 202],
					[426, 202],
					[426, 263],
					[266, 263]
				],
				physical: "24",
				next: ["13", "25"],
				direct: ["25"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 13: ["12", "25"] }
			},
			25: {
				x: 497.5,
				y: 232.5,
				angle: -.0166,
				front: 468.5,
				poly: [
					[426, 202],
					[569, 202],
					[569, 263],
					[426, 263]
				],
				physical: "25",
				next: ["14", "26"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			26: {
				x: 680,
				y: 232.5,
				angle: -.0166,
				front: 649.4,
				poly: [
					[610, 202],
					[750, 202],
					[750, 263],
					[610, 263]
				],
				physical: "26",
				next: ["15", "27"],
				direct: ["27"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 15: ["14", "27"] }
			},
			27: {
				x: 829.5,
				y: 232.5,
				angle: -.0166,
				front: 808.4,
				poly: [
					[750, 202],
					[909, 202],
					[909, 263],
					[750, 263]
				],
				physical: "27",
				next: ["16", "28"],
				direct: ["28"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 16: ["15", "28"] }
			},
			28: {
				x: 988,
				y: 232.5,
				angle: -.0166,
				front: 966.4,
				poly: [
					[909, 202],
					[1067, 202],
					[1067, 263],
					[909, 263]
				],
				physical: "28",
				next: ["17", "29"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					17: ["16", "29"],
					29: ["16", "17"]
				}
			},
			29: {
				x: 1156,
				y: 232.5,
				angle: -.0166,
				front: 1129.4,
				poly: [
					[1082, 202],
					[1230, 202],
					[1230, 263],
					[1082, 263]
				],
				physical: "29",
				next: ["e1"],
				direct: ["e1"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			31: {
				x: 2207.5,
				y: 238.7,
				angle: 1.4027,
				front: 2212.3,
				poly: [
					[2229.3, 158],
					[2248.4, 189.3],
					[2257.1, 257],
					[2218.9, 317.7],
					[2159.9, 291.7],
					[2165.1, 191]
				],
				physical: "31",
				next: ["47", "p1"],
				direct: ["p1"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			32: {
				x: 1311.6,
				y: 327.2,
				angle: 2.9669,
				front: 3153.1,
				poly: [
					[1375.1, 284.7],
					[1373.4, 350.7],
					[1241.4, 364.6],
					[1248.4, 309.1]
				],
				physical: "32",
				next: ["42", "52"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			33: {
				x: 1476.5,
				y: 320,
				angle: 3.1416,
				front: 2981.9,
				poly: [
					[1400, 290],
					[1553, 290],
					[1553, 350],
					[1400, 350]
				],
				physical: "33",
				next: ["32", "43"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			34: {
				x: 1630.5,
				y: 320,
				angle: 3.1416,
				front: 2828.9,
				poly: [
					[1553, 290],
					[1708, 290],
					[1708, 350],
					[1553, 350]
				],
				physical: "34",
				next: ["33", "a2"],
				direct: ["33", "a2"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			35: {
				x: 1788,
				y: 320,
				angle: 3.1416,
				front: 2673.9,
				poly: [
					[1708, 290],
					[1868, 290],
					[1868, 350],
					[1708, 350]
				],
				physical: "35",
				next: ["34", "a2"],
				direct: ["34"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			36: {
				x: 1941,
				y: 320,
				angle: 3.1416,
				front: 2513.9,
				poly: [
					[1868, 290],
					[2014, 290],
					[2014, 350],
					[1868, 350]
				],
				physical: "36",
				next: ["35", "45"],
				direct: ["35"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 45: ["46", "35"] }
			},
			37: {
				x: 339.2,
				y: 384,
				angle: 2.7611,
				front: 4142.9,
				poly: [
					[425.4, 333.4],
					[425.4, 388.9],
					[302.1, 437.5],
					[236.1, 411.5],
					[263.9, 378.5],
					[324.7, 345.5]
				],
				physical: "37",
				next: ["53", "p2"],
				direct: ["p2"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			38: {
				x: 511.5,
				y: 361.5,
				angle: 3.1416,
				front: 3953.9,
				poly: [
					[431, 332],
					[592, 332],
					[592, 391],
					[431, 391]
				],
				physical: "38",
				next: ["37", "p2"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			39: {
				x: 671.5,
				y: 361.5,
				angle: 3.1416,
				front: 3792.9,
				poly: [
					[592, 332],
					[751, 332],
					[751, 391],
					[592, 391]
				],
				physical: "39",
				next: ["38", "48"],
				direct: ["38"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 48: ["49", "38"] }
			},
			40: {
				x: 831,
				y: 361.5,
				angle: 3.1416,
				front: 3633.9,
				poly: [
					[751, 332],
					[911, 332],
					[911, 391],
					[751, 391]
				],
				physical: "40",
				next: ["39", "49"],
				direct: ["39"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 49: ["50", "39"] }
			},
			41: {
				x: 992,
				y: 361.5,
				angle: 3.1416,
				front: 3473.9,
				poly: [
					[911, 332],
					[1073, 332],
					[1073, 391],
					[911, 391]
				],
				physical: "41",
				next: ["40", "50"],
				direct: ["40"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 50: ["51", "40"] }
			},
			42: {
				x: 1145.4,
				y: 352.8,
				angle: 3.0716,
				front: 3315.7,
				poly: [
					[1217.1, 319.5],
					[1215.4, 375],
					[1073, 385.4],
					[1074.7, 331.6]
				],
				physical: "42",
				next: ["41", "51"],
				direct: ["41"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 51: ["52", "41"] }
			},
			43: {
				x: 1304.1,
				y: 389.2,
				angle: 2.9669,
				front: 3153.1,
				poly: [
					[1375.1, 357.7],
					[1373.4, 395.9],
					[1239.7, 427.1],
					[1243.2, 373.3]
				],
				physical: "43",
				next: ["42", "52"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			45: {
				x: 1788,
				y: 380.5,
				angle: 3.1416,
				front: 2673.9,
				poly: [
					[1708, 350],
					[1868, 350],
					[1868, 411],
					[1708, 411]
				],
				physical: "45",
				next: ["34", "a2"],
				direct: ["a2"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			46: {
				x: 1941,
				y: 380.5,
				angle: 3.1416,
				front: 2513.9,
				poly: [
					[1868, 350],
					[2014, 350],
					[2014, 411],
					[1868, 411]
				],
				physical: "46",
				next: ["35", "45"],
				direct: ["45"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 35: ["36", "45"] }
			},
			47: {
				x: 2121.7,
				y: 352,
				angle: 2.9326,
				front: 2353.3,
				poly: [
					[2220.7, 324.7],
					[2185.9, 361.1],
					[2121.7, 394.1],
					[2040.1, 404.5],
					[2041.8, 349],
					[2154.7, 296.9]
				],
				physical: "47",
				next: ["36", "46"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			48: {
				x: 511.5,
				y: 421.5,
				angle: 3.1416,
				front: 3953.9,
				poly: [
					[431, 391],
					[592, 391],
					[592, 452],
					[431, 452]
				],
				physical: "48",
				next: ["37", "p2"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			49: {
				x: 671.5,
				y: 421.5,
				angle: 3.1416,
				front: 3792.9,
				poly: [
					[592, 391],
					[751, 391],
					[751, 452],
					[592, 452]
				],
				physical: "49",
				next: ["38", "48"],
				direct: ["48"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 38: ["39", "48"] }
			},
			50: {
				x: 831,
				y: 421.5,
				angle: 3.1416,
				front: 3633.9,
				poly: [
					[751, 391],
					[911, 391],
					[911, 452],
					[751, 452]
				],
				physical: "50",
				next: ["39", "49"],
				direct: ["49"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 39: ["40", "49"] }
			},
			51: {
				x: 992,
				y: 421.5,
				angle: 3.1416,
				front: 3473.9,
				poly: [
					[911, 391],
					[1073, 391],
					[1073, 452],
					[911, 452]
				],
				physical: "51",
				next: ["40", "50"],
				direct: ["50"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 40: ["41", "50"] }
			},
			52: {
				x: 1145.8,
				y: 413.6,
				angle: 3.0716,
				front: 3315.7,
				poly: [
					[1218.8, 380.2],
					[1215.4, 435.8],
					[1073, 446.2],
					[1074.7, 392.4]
				],
				physical: "52",
				next: ["41", "51"],
				direct: ["51"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 41: ["42", "51"] }
			},
			53: {
				x: 248.8,
				y: 496.9,
				angle: 1.5772,
				front: 4222.1,
				poly: [
					[229.2, 418.4],
					[295.2, 444.5],
					[296.9, 548.7],
					[234.4, 576.4],
					[208.4, 545.2],
					[197.9, 491.4],
					[204.9, 451.4]
				],
				physical: "53",
				next: ["65", "p2"],
				direct: ["p2"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			54: {
				x: 1321.5,
				y: 515.9,
				angle: -.0912,
				front: 5296.3,
				poly: [
					[1385.5, 484.4],
					[1385.5, 538.2],
					[1241.4, 536.5],
					[1248.4, 505.2]
				],
				physical: "54",
				next: ["e2"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			56: {
				x: 1712,
				y: 510,
				angle: 0,
				front: 5792.4,
				poly: [
					[1570, 480],
					[1854, 480],
					[1854, 540],
					[1570, 540]
				],
				physical: "56",
				next: ["57"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			57: {
				x: 1948,
				y: 510,
				angle: 0,
				front: 5966.4,
				poly: [
					[1868, 480],
					[2028, 480],
					[2028, 540],
					[1868, 540]
				],
				physical: "57",
				next: ["64"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			58: {
				x: 520.5,
				y: 574.5,
				angle: 0,
				front: 4496.1,
				poly: [
					[446, 544],
					[595, 544],
					[595, 605],
					[446, 605]
				],
				physical: "58",
				next: ["67", "a3"],
				direct: ["a3"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			61: {
				x: 999.5,
				y: 574.5,
				angle: 0,
				front: 4974.1,
				poly: [
					[926, 544],
					[1073, 544],
					[1073, 605],
					[926, 605]
				],
				physical: "61",
				next: ["62", "70"],
				direct: ["62"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 70: ["69", "62"] }
			},
			62: {
				x: 1151.5,
				y: 563.7,
				angle: -.0912,
				front: 5130.4,
				poly: [
					[1073, 544],
					[1073, 540],
					[1220, 507],
					[1220, 605],
					[1073, 605]
				],
				physical: "62",
				next: [
					"54",
					"63",
					"71"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					63: ["70", "71"],
					71: ["70", "63"]
				}
			},
			63: {
				x: 1310,
				y: 574.5,
				angle: -.0912,
				front: 5295.3,
				poly: [
					[1230, 544],
					[1390, 544],
					[1390, 605],
					[1230, 605]
				],
				physical: "63",
				next: ["72", "e2"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			64: {
				x: 2113.8,
				y: 561.4,
				angle: .3191,
				front: 6176.1,
				poly: [
					[2029.7, 486.2],
					[2071.3, 479.2],
					[2118.2, 494.8],
					[2185.9, 540],
					[2227.6, 604.2],
					[2146, 638.9],
					[2031.4, 595.5]
				],
				physical: "64",
				next: ["77", "p3"],
				direct: ["p3"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			65: {
				x: 334.4,
				y: 610.6,
				angle: .3612,
				front: 4342.2,
				poly: [
					[241.3, 579.9],
					[305.6, 555.6],
					[418.4, 623.3],
					[420.2, 663.2],
					[316, 642.4],
					[277.8, 621.6]
				],
				physical: "65",
				next: ["58", "66"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			66: {
				x: 520.5,
				y: 635.5,
				angle: 0,
				front: 4496.1,
				poly: [
					[446, 605],
					[595, 605],
					[595, 666],
					[446, 666]
				],
				physical: "66",
				next: ["67", "a3"],
				direct: ["67"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			67: {
				x: 673,
				y: 635.5,
				angle: 0,
				front: 4652.1,
				poly: [
					[595, 605],
					[751, 605],
					[751, 666],
					[595, 666]
				],
				physical: "67",
				next: ["68", "a3"],
				direct: ["68", "a3"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			68: {
				x: 830,
				y: 635.5,
				angle: 0,
				front: 4810.1,
				poly: [
					[751, 605],
					[909, 605],
					[909, 666],
					[751, 666]
				],
				physical: "68",
				next: ["61", "69"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					61: ["a3", "69"],
					69: ["a3", "61"]
				}
			},
			69: {
				x: 999.5,
				y: 635.5,
				angle: 0,
				front: 4974.1,
				poly: [
					[926, 605],
					[1073, 605],
					[1073, 666],
					[926, 666]
				],
				physical: "69",
				next: ["62", "70"],
				direct: ["70"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 62: ["61", "70"] }
			},
			70: {
				x: 1151.5,
				y: 635.5,
				angle: -.0912,
				front: 5130.4,
				poly: [
					[1073, 605],
					[1230, 605],
					[1230, 666],
					[1073, 666]
				],
				physical: "70",
				next: ["63", "71"],
				direct: ["71"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 63: ["62", "71"] }
			},
			71: {
				x: 1310,
				y: 635.5,
				angle: -.0912,
				front: 5295.3,
				poly: [
					[1230, 605],
					[1390, 605],
					[1390, 666],
					[1230, 666]
				],
				physical: "71",
				next: ["72", "e2"],
				direct: ["72"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			72: {
				x: 1472,
				y: 635.5,
				angle: 0,
				front: 5456.4,
				poly: [
					[1390, 605],
					[1554, 605],
					[1554, 666],
					[1390, 666]
				],
				physical: "72",
				next: ["73"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			73: {
				x: 1639,
				y: 630.5,
				angle: 0,
				front: 5646.4,
				poly: [
					[1570, 600],
					[1708, 600],
					[1708, 661],
					[1570, 661]
				],
				physical: "73",
				next: ["74"],
				direct: ["74"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			74: {
				x: 1788,
				y: 630.5,
				angle: 0,
				front: 5806.4,
				poly: [
					[1708, 600],
					[1868, 600],
					[1868, 661],
					[1708, 661]
				],
				physical: "74",
				next: ["75"],
				direct: ["75"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			75: {
				x: 1948,
				y: 630.5,
				angle: 0,
				front: 5966.4,
				poly: [
					[1868, 600],
					[2028, 600],
					[2028, 661],
					[1868, 661]
				],
				physical: "75",
				next: ["64"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			77: {
				x: 2206.3,
				y: 689,
				angle: 1.1325,
				front: 6293.9,
				poly: [
					[2236.3, 611.2],
					[2251.9, 647.6],
					[2253.7, 713.6],
					[2227.6, 767.4],
					[2165.1, 746.6],
					[2153, 644.1]
				],
				physical: "77",
				next: ["100", "p3"],
				direct: ["p3"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			78: {
				x: 1779,
				y: 721.5,
				angle: 3.1416,
				front: 6759.6,
				poly: [
					[1708, 692],
					[1850, 692],
					[1850, 751],
					[1708, 751]
				],
				physical: "78",
				next: ["e3"],
				direct: ["e3"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			79: {
				x: 507.4,
				y: 769.1,
				angle: 2.9628,
				front: 8048.3,
				poly: [
					[592.1, 734.4],
					[590.3, 788.3],
					[446.2, 809.1],
					[406.3, 764],
					[493.1, 736.2]
				],
				physical: "79",
				next: ["89", "90"],
				direct: ["90"],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			80: {
				x: 673,
				y: 760.5,
				angle: 3.1416,
				front: 7872.8,
				poly: [
					[595, 730],
					[751, 730],
					[751, 791],
					[595, 791]
				],
				physical: "80",
				next: ["79", "90"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			81: {
				x: 823.9,
				y: 770.5,
				angle: 3.0916,
				front: 7713.4,
				poly: [
					[757, 732.7],
					[889, 753.5],
					[892.4, 807.4],
					[758.7, 788.3]
				],
				physical: "81",
				next: ["80", "91"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					80: ["92", "91"],
					91: ["92", "80"]
				}
			},
			82: {
				x: 999.5,
				y: 782,
				angle: 3.1416,
				front: 7541.6,
				poly: [
					[926, 751],
					[1073, 751],
					[1073, 813],
					[926, 813]
				],
				physical: "82",
				next: [
					"81",
					"92",
					"a4"
				],
				direct: ["a4"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			83: {
				x: 1151.5,
				y: 782,
				angle: 3.1416,
				front: 7394.6,
				poly: [
					[1073, 751],
					[1230, 751],
					[1230, 813],
					[1073, 813]
				],
				physical: "83",
				next: ["82", "a4"],
				direct: ["82", "a4"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			84: {
				x: 1310,
				y: 782,
				angle: 3.1416,
				front: 7237.6,
				poly: [
					[1230, 751],
					[1390, 751],
					[1390, 813],
					[1230, 813]
				],
				physical: "84",
				next: ["83", "a4"],
				direct: ["83"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			85: {
				x: 1465,
				y: 782,
				angle: 3.1416,
				front: 7077.6,
				poly: [
					[1390, 751],
					[1540, 751],
					[1540, 813],
					[1390, 813]
				],
				physical: "85",
				next: ["84", "95"],
				direct: ["84"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			87: {
				x: 1779,
				y: 782,
				angle: 3.1416,
				front: 6759.6,
				poly: [
					[1708, 751],
					[1850, 751],
					[1850, 813],
					[1708, 813]
				],
				physical: "87",
				next: ["97", "e3"],
				direct: ["e3"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 97: ["98", "e3"] }
			},
			88: {
				x: 1941,
				y: 782,
				angle: 3.1416,
				front: 6599.6,
				poly: [
					[1868, 751],
					[2014, 751],
					[2014, 813],
					[1868, 813]
				],
				physical: "88",
				next: [
					"78",
					"87",
					"98"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			89: {
				x: 356.9,
				y: 822.7,
				angle: 2.6122,
				front: 8175.4,
				poly: [
					[437.5, 809.1],
					[340.3, 876.8],
					[272.6, 849],
					[303.8, 814.3],
					[394.1, 764]
				],
				physical: "89",
				next: ["104", "105"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			90: {
				x: 499.7,
				y: 837.5,
				angle: 2.9628,
				front: 8082.2,
				poly: [
					[592.1, 795.2],
					[590.3, 847.3],
					[442.7, 883.8],
					[387.2, 849],
					[475.7, 805.6]
				],
				physical: "90",
				next: ["89", "105"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			91: {
				x: 673,
				y: 821,
				angle: 3.1416,
				front: 7872.8,
				poly: [
					[595, 791],
					[751, 791],
					[751, 851],
					[595, 851]
				],
				physical: "91",
				next: [
					"79",
					"90",
					"102"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			92: {
				x: 817.3,
				y: 847.4,
				angle: 3.0916,
				front: 7713.4,
				poly: [
					[757, 793.5],
					[890.7, 814.3],
					[892.4, 871.6],
					[758.7, 908.1]
				],
				physical: "92",
				next: [
					"80",
					"91",
					"103"
				],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					80: ["81", "91"],
					91: ["81", "80"]
				}
			},
			95: {
				x: 1317,
				y: 843.5,
				angle: 3.1416,
				front: 7223.6,
				poly: [
					[1244, 813],
					[1390, 813],
					[1390, 874],
					[1244, 874]
				],
				physical: "95",
				next: [
					"83",
					"84",
					"a4"
				],
				direct: ["84"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			96: {
				x: 1465,
				y: 843.5,
				angle: 3.1416,
				front: 7077.6,
				poly: [
					[1390, 813],
					[1540, 813],
					[1540, 874],
					[1390, 874]
				],
				physical: "96",
				next: ["84", "95"],
				direct: ["95"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			97: {
				x: 1624,
				y: 843.5,
				angle: 3.1416,
				front: 6927.6,
				poly: [
					[1540, 813],
					[1708, 813],
					[1708, 874],
					[1540, 874]
				],
				physical: "97",
				next: ["85", "96"],
				direct: ["96"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 85: ["e3", "96"] }
			},
			98: {
				x: 1788,
				y: 843.5,
				angle: 3.1416,
				front: 6759.6,
				poly: [
					[1708, 813],
					[1868, 813],
					[1868, 874],
					[1708, 874]
				],
				physical: "98",
				next: ["97", "e3"],
				direct: ["97"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { e3: ["87", "97"] }
			},
			99: {
				x: 1941,
				y: 843.5,
				angle: 3.1416,
				front: 6599.6,
				poly: [
					[1868, 813],
					[2014, 813],
					[2014, 874],
					[1868, 874]
				],
				physical: "99",
				next: ["87", "98"],
				direct: ["98"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			100: {
				x: 2126.2,
				y: 810.4,
				angle: 2.8716,
				front: 6443.3,
				poly: [
					[2224.1, 772.6],
					[2199.8, 814.3],
					[2128.6, 856],
					[2038.4, 864.7],
					[2041.8, 810.8],
					[2159.9, 751.8]
				],
				physical: "100",
				next: ["88", "99"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			102: {
				x: 517.3,
				y: 895.9,
				angle: 2.9628,
				front: 8059.2,
				poly: [
					[592.1, 854.2],
					[588.6, 908.1],
					[487.9, 937.6],
					[421.9, 911.5],
					[480.9, 869.9]
				],
				physical: "102",
				next: ["90", "105"],
				direct: ["90"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			103: {
				x: 673,
				y: 881,
				angle: 3.1416,
				front: 7872.8,
				poly: [
					[595, 851],
					[751, 851],
					[751, 911],
					[595, 911]
				],
				physical: "103",
				next: ["90", "102"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			104: {
				x: 274.5,
				y: 923.7,
				angle: 1.9601,
				front: 8261.5,
				poly: [
					[333.4, 882],
					[298.6, 981],
					[220.5, 979.2],
					[230.9, 908.1],
					[269.1, 856]
				],
				physical: "104",
				next: ["106", "107"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			105: {
				x: 367.2,
				y: 924,
				angle: 2.6122,
				front: 8212.7,
				poly: [
					[432.3, 887.2],
					[383.7, 981],
					[305.6, 979.2],
					[322.9, 911.5],
					[373.3, 854.2]
				],
				physical: "105",
				next: [
					"104",
					"106",
					"107",
					"p4"
				],
				direct: ["104", "p4"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			106: {
				x: 271.8,
				y: 1042.8,
				angle: 1.2063,
				front: 8339.6,
				poly: [
					[217, 986.2],
					[298.6, 986.2],
					[326.4, 1086.9],
					[263.9, 1111.2],
					[237.9, 1074.7]
				],
				physical: "106",
				next: ["107", "124"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			107: {
				x: 366.4,
				y: 1041.6,
				angle: .635,
				front: 8406.2,
				poly: [
					[305.6, 986.2],
					[383.7, 984.5],
					[430.6, 1078.2],
					[371.6, 1111.2],
					[324.7, 1059.1]
				],
				physical: "107",
				next: [
					"124",
					"125",
					"p4"
				],
				direct: ["p4"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			109: {
				x: 1787,
				y: 1022.5,
				angle: 0,
				front: 9863.6,
				poly: [
					[1724, 991],
					[1850, 991],
					[1850, 1054],
					[1724, 1054]
				],
				physical: "109",
				next: ["111", "121"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			111: {
				x: 1948,
				y: 1022.5,
				angle: 0,
				front: 10041.6,
				poly: [
					[1868, 991],
					[2028, 991],
					[2028, 1054],
					[1868, 1054]
				],
				physical: "111",
				next: ["112", "122"],
				direct: ["112"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 122: ["121", "112"] }
			},
			112: {
				x: 2102,
				y: 1022.5,
				angle: 0,
				front: 10189.6,
				poly: [
					[2028, 991],
					[2176, 991],
					[2176, 1054],
					[2028, 1054]
				],
				physical: "112",
				next: ["finish"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			113: {
				x: 679.5,
				y: 1084.5,
				angle: -.064,
				front: 8765,
				poly: [
					[608, 1054],
					[751, 1054],
					[751, 1115],
					[608, 1115]
				],
				physical: "113",
				next: ["114", "136"],
				direct: ["114"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 136: ["135", "114"] }
			},
			114: {
				x: 831,
				y: 1084.5,
				angle: -.155,
				front: 8930.9,
				poly: [
					[751, 1054],
					[911, 1054],
					[911, 1115],
					[751, 1115]
				],
				physical: "114",
				next: ["126", "a5"],
				direct: ["a5"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			117: {
				x: 1317,
				y: 1084.5,
				angle: 0,
				front: 9400.5,
				poly: [
					[1244, 1054],
					[1390, 1054],
					[1390, 1115],
					[1244, 1115]
				],
				physical: "117",
				next: ["118", "129"],
				direct: ["118"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 129: ["128", "118"] }
			},
			118: {
				x: 1475.4,
				y: 1066.9,
				angle: -.2038,
				front: 9572.4,
				poly: [
					[1390, 1054],
					[1440, 1046],
					[1480, 1010],
					[1540, 991],
					[1540, 1115],
					[1390, 1115]
				],
				physical: "118",
				next: ["130", "e4"],
				direct: ["e4"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: { 130: ["129", "e4"] }
			},
			120: {
				x: 1787,
				y: 1084.5,
				angle: 0,
				front: 9863.6,
				poly: [
					[1724, 1054],
					[1850, 1054],
					[1850, 1115],
					[1724, 1115]
				],
				physical: "120",
				next: [
					"111",
					"121",
					"132"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			121: {
				x: 1948,
				y: 1084.5,
				angle: 0,
				front: 10041.6,
				poly: [
					[1868, 1054],
					[2028, 1054],
					[2028, 1115],
					[1868, 1115]
				],
				physical: "121",
				next: [
					"112",
					"122",
					"133"
				],
				direct: ["122"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					112: ["111", "122"],
					133: ["132", "122"]
				}
			},
			122: {
				x: 2102,
				y: 1084.5,
				angle: 0,
				front: 10189.6,
				poly: [
					[2028, 1054],
					[2176, 1054],
					[2176, 1115],
					[2028, 1115]
				],
				physical: "122",
				next: ["finish"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			124: {
				x: 356,
				y: 1142.7,
				angle: .635,
				front: 8456.7,
				poly: [
					[274.3, 1114.7],
					[338.6, 1088.6],
					[435.8, 1156.3],
					[392.4, 1199.7],
					[316, 1161.6]
				],
				physical: "124",
				next: ["125", "134"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			125: {
				x: 500.1,
				y: 1127.4,
				angle: .1185,
				front: 8605.6,
				poly: [
					[385.4, 1116.4],
					[437.5, 1081.7],
					[595, 1116.4],
					[595, 1170.2],
					[461.8, 1156.3]
				],
				physical: "125",
				next: ["113", "135"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					113: ["p4", "135"],
					135: ["p4", "113"]
				}
			},
			126: {
				x: 999.5,
				y: 1144.5,
				angle: 0,
				front: 9083.5,
				poly: [
					[926, 1115],
					[1073, 1115],
					[1073, 1174],
					[926, 1174]
				],
				physical: "126",
				next: ["127", "a5"],
				direct: ["127", "a5"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			127: {
				x: 1151.5,
				y: 1144.5,
				angle: 0,
				front: 9240.5,
				poly: [
					[1073, 1115],
					[1230, 1115],
					[1230, 1174],
					[1073, 1174]
				],
				physical: "127",
				next: ["117", "128"],
				direct: ["128"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 117: ["a5", "128"] }
			},
			128: {
				x: 1310,
				y: 1144.5,
				angle: 0,
				front: 9400.5,
				poly: [
					[1230, 1115],
					[1390, 1115],
					[1390, 1174],
					[1230, 1174]
				],
				physical: "128",
				next: ["118", "129"],
				direct: ["129"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 118: ["117", "129"] }
			},
			129: {
				x: 1465,
				y: 1144.5,
				angle: -.2038,
				front: 9572.4,
				poly: [
					[1390, 1115],
					[1540, 1115],
					[1540, 1174],
					[1390, 1174]
				],
				physical: "129",
				next: ["130", "e4"],
				direct: ["130"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { e4: ["118", "130"] }
			},
			130: {
				x: 1624,
				y: 1144.5,
				angle: 0,
				front: 9721.6,
				poly: [
					[1540, 1115],
					[1708, 1115],
					[1708, 1174],
					[1540, 1174]
				],
				physical: "130",
				next: ["120", "131"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					120: ["e4", "131"],
					131: ["e4", "120"]
				}
			},
			131: {
				x: 1787,
				y: 1144.5,
				angle: 0,
				front: 9863.6,
				poly: [
					[1724, 1115],
					[1850, 1115],
					[1850, 1174],
					[1724, 1174]
				],
				physical: "131",
				next: ["121", "132"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			132: {
				x: 1948,
				y: 1144.5,
				angle: 0,
				front: 10041.6,
				poly: [
					[1868, 1115],
					[2028, 1115],
					[2028, 1174],
					[1868, 1174]
				],
				physical: "132",
				next: ["122", "133"],
				direct: ["133"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 122: ["121", "133"] }
			},
			133: {
				x: 2102,
				y: 1144.5,
				angle: 0,
				front: 10189.6,
				poly: [
					[2028, 1115],
					[2176, 1115],
					[2176, 1174],
					[2028, 1174]
				],
				physical: "133",
				next: ["finish"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			134: {
				x: 506.3,
				y: 1196.6,
				angle: .1185,
				front: 8605.6,
				poly: [
					[397.6, 1201.5],
					[444.5, 1156.3],
					[595, 1177.2],
					[595, 1234.5],
					[463.6, 1224.1]
				],
				physical: "134",
				next: ["135"],
				direct: [],
				rectangle: !1,
				rumble: !0,
				danger: !1,
				gates: {}
			},
			135: {
				x: 675.6,
				y: 1168,
				angle: -.064,
				front: 8758.3,
				poly: [
					[607.7, 1118.1],
					[748.3, 1116.4],
					[750.1, 1203.2],
					[609.4, 1232.7]
				],
				physical: "135",
				next: [
					"113",
					"114",
					"136"
				],
				direct: ["113"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					114: ["113", "136"],
					136: ["113", "114"]
				}
			},
			136: {
				x: 828.3,
				y: 1151.3,
				angle: -.155,
				front: 8920.1,
				poly: [
					[909.8, 1116.4],
					[906.3, 1172],
					[760.5, 1199.7],
					[757, 1116.4]
				],
				physical: "136",
				next: [
					"114",
					"126",
					"a5"
				],
				direct: ["114"],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			a1: {
				x: 908.5,
				y: 110.5,
				angle: -.0166,
				front: 968.4,
				poly: [
					[750, 80],
					[1067, 80],
					[1067, 141],
					[750, 141]
				],
				physical: "a1",
				next: ["5", "17"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					5: ["16", "17"],
					17: ["16", "5"]
				}
			},
			a2: {
				x: 1554,
				y: 380.5,
				angle: 3.1416,
				front: 2981.9,
				poly: [
					[1400, 350],
					[1708, 350],
					[1708, 411],
					[1400, 411]
				],
				physical: "a2",
				next: ["32", "43"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			a3: {
				x: 752,
				y: 574.5,
				angle: 0,
				front: 4810.1,
				poly: [
					[595, 544],
					[909, 544],
					[909, 605],
					[595, 605]
				],
				physical: "a3",
				next: ["61", "69"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					61: ["68", "69"],
					69: ["68", "61"]
				}
			},
			a4: {
				x: 1070.5,
				y: 843.5,
				angle: 3.1416,
				front: 7556.6,
				poly: [
					[911, 813],
					[1230, 813],
					[1230, 874],
					[911, 874]
				],
				physical: "a4",
				next: ["81", "92"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			a5: {
				x: 1071.5,
				y: 1084.5,
				angle: 0,
				front: 9240.5,
				poly: [
					[913, 1054],
					[1230, 1054],
					[1230, 1115],
					[913, 1115]
				],
				physical: "a5",
				next: ["117", "128"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					117: ["127", "128"],
					128: ["127", "117"]
				}
			},
			e1: {
				x: 1310,
				y: 202.5,
				angle: -.0166,
				front: 1290.3,
				poly: [
					[1230, 142],
					[1390, 142],
					[1390, 263],
					[1230, 263]
				],
				physical: "e1",
				next: ["6", "18"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					6: ["pre-e1", "18"],
					18: ["pre-e1", "6"]
				}
			},
			e2: {
				x: 1472,
				y: 514,
				angle: 0,
				front: 5456.4,
				poly: [
					[1390, 460],
					[1554, 460],
					[1554, 568],
					[1390, 568]
				],
				physical: "e2",
				next: ["56", "73"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			e3: {
				x: 1624,
				y: 752.5,
				angle: 3.1416,
				front: 6927.6,
				poly: [
					[1540, 692],
					[1708, 692],
					[1708, 813],
					[1540, 813]
				],
				physical: "e3",
				next: ["85", "96"],
				direct: ["85"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 96: ["97", "85"] }
			},
			e4: {
				x: 1624,
				y: 1053,
				angle: 0,
				front: 9721.6,
				poly: [
					[1540, 991],
					[1708, 991],
					[1708, 1115],
					[1540, 1115]
				],
				physical: "e4",
				next: [
					"109",
					"120",
					"131"
				],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					120: ["130", "131"],
					131: ["130", "120"]
				}
			},
			"first-start": {
				x: 183,
				y: 110.5,
				angle: -.0166,
				front: 167.5,
				poly: [
					[100, 80],
					[266, 80],
					[266, 141],
					[100, 141]
				],
				physical: "first-start",
				next: ["0", "12"],
				direct: ["0"],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: { 12: ["11", "0"] }
			},
			"pre-e1": {
				x: 1310,
				y: 111,
				angle: -.0166,
				front: 1291.4,
				poly: [
					[1230, 80],
					[1390, 80],
					[1390, 142],
					[1230, 142]
				],
				physical: "pre-e1",
				next: ["6", "18"],
				direct: [],
				rectangle: !0,
				rumble: !1,
				danger: !1,
				gates: {
					6: ["e1", "18"],
					18: ["e1", "6"]
				}
			},
			p1: {
				x: 2095.6,
				y: 243,
				angle: .8176,
				front: 2353.3,
				poly: [
					[2028, 135],
					[2060.3, 137.7],
					[2090.9, 145.7],
					[2118.4, 158.6],
					[2141.4, 175.7],
					[2158.6, 196.1],
					[2169.4, 219],
					[2173, 243],
					[2169.4, 267],
					[2158.6, 289.9],
					[2141.4, 310.3],
					[2118.4, 327.4],
					[2090.9, 340.3],
					[2060.3, 348.3],
					[2028, 351],
					[2028, 288],
					[2038, 286.9],
					[2047.5, 283.5],
					[2056.1, 278.2],
					[2063.2, 271.1],
					[2068.5, 262.5],
					[2071.9, 253],
					[2073, 243],
					[2071.9, 233],
					[2068.5, 223.5],
					[2063.2, 214.9],
					[2056.1, 207.8],
					[2047.5, 202.5],
					[2038, 199.1],
					[2028, 198]
				],
				physical: "p1",
				next: ["36", "46"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			p2: {
				x: 356.2,
				y: 498,
				angle: 2.1653,
				front: 4342.2,
				poly: [
					[425, 606],
					[392.7, 603.3],
					[362.1, 595.3],
					[334.6, 582.4],
					[311.6, 565.3],
					[294.4, 544.9],
					[283.6, 522],
					[280, 498],
					[283.6, 474],
					[294.4, 451.1],
					[311.6, 430.7],
					[334.6, 413.6],
					[362.1, 400.7],
					[392.7, 392.7],
					[425, 390],
					[425, 453],
					[411.6, 454.1],
					[399, 457.5],
					[387.6, 462.8],
					[378.1, 469.9],
					[370.9, 478.5],
					[366.5, 488],
					[365, 498],
					[366.5, 508],
					[370.9, 517.5],
					[378.1, 526.1],
					[387.6, 533.2],
					[399, 538.5],
					[411.6, 541.9],
					[425, 543]
				],
				physical: "p2",
				next: ["58", "66"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			p3: {
				x: 2095.6,
				y: 705,
				angle: 2.2327,
				front: 6443.3,
				poly: [
					[2028, 597],
					[2060.3, 599.7],
					[2090.9, 607.7],
					[2118.4, 620.6],
					[2141.4, 637.7],
					[2158.6, 658.1],
					[2169.4, 681],
					[2173, 705],
					[2169.4, 729],
					[2158.6, 751.9],
					[2141.4, 772.3],
					[2118.4, 789.4],
					[2090.9, 802.3],
					[2060.3, 810.3],
					[2028, 813],
					[2028, 750],
					[2038, 748.9],
					[2047.5, 745.5],
					[2056.1, 740.2],
					[2063.2, 733.1],
					[2068.5, 724.5],
					[2071.9, 715],
					[2073, 705],
					[2071.9, 695],
					[2068.5, 685.5],
					[2063.2, 676.9],
					[2056.1, 669.8],
					[2047.5, 664.5],
					[2038, 661.1],
					[2028, 660]
				],
				physical: "p3",
				next: ["88", "99"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {}
			},
			p4: {
				x: 474,
				y: 1024.7,
				angle: .1185,
				front: 8605.6,
				poly: [
					[425.1, 906.4],
					[407.9, 924.1],
					[395.3, 943.2],
					[387.6, 963.4],
					[385, 984],
					[387.6, 1004.6],
					[395.3, 1024.8],
					[407.9, 1043.9],
					[425.1, 1061.6],
					[446.5, 1077.3],
					[471.6, 1090.8],
					[499.7, 1101.6],
					[530.1, 1109.5],
					[562.1, 1114.4],
					[595, 1116],
					[595, 1056],
					[575.4, 1055.1],
					[556.4, 1052.5],
					[538.3, 1048.2],
					[521.5, 1042.2],
					[506.6, 1034.9],
					[493.9, 1026.3],
					[483.6, 1016.7],
					[476.1, 1006.2],
					[471.5, 995.3],
					[470, 984],
					[471.5, 972.7],
					[476.1, 961.8],
					[483.6, 951.3],
					[493.9, 941.7]
				],
				physical: "p4",
				next: ["113", "135"],
				direct: [],
				rectangle: !1,
				rumble: !1,
				danger: !1,
				gates: {
					113: ["125", "135"],
					135: ["125", "113"]
				}
			}
		},
		jumps: [],
		animals: [
			{
				id: "antelope",
				spaces: [
					"a1",
					"a2",
					"a3",
					"a4",
					"a5"
				],
				lines: [
					966.9,
					2991.7,
					4810.1,
					7558.6,
					9240.5
				]
			},
			{
				id: "elephant",
				spaces: [
					"e1",
					"e2",
					"e3",
					"e4"
				],
				lines: [
					1289.8,
					5508.4,
					6927.6,
					9721.6
				]
			},
			{
				id: "python",
				spaces: [
					"p1",
					"p2",
					"p3",
					"p4"
				],
				lines: [
					2353.9,
					4326.1,
					6439.6,
					8603.2
				]
			}
		]
	}
};
//#endregion
//#region src/games/downforce/movement.ts
function A(e) {
	return {
		track: e.track,
		cars: e.cars,
		animals: e.animals,
		powers: Object.fromEntries(e.players.map((e) => [e.rid, e.power])),
		activePlayer: e.activePlayer
	};
}
var j = (e, t) => {
	let n = e.cars.find((e) => e.color === t)?.owner;
	return n ? e.powers[n] : null;
};
function M(e, t, n) {
	let r = k[e.track], i = r.nodes[t].physical;
	return e.cars.some((e) => e.color !== n && e.node !== null && r.nodes[e.node].physical === i) ? !0 : e.animals.some((e) => e.index >= 0 && r.animals.find((t) => t.id === e.id)?.spaces[e.index] === t);
}
function N(e, t, n, r) {
	let i = k[e];
	if (n === "finish") return i.length + 1;
	let a = i.nodes[n].front - i.nodes[t].front;
	return i.closed && a <= 0 && (a += i.length), r + a;
}
function P(e, t, n, r) {
	if (r <= 0) return [];
	let i = k[e.track];
	if (t.forcedTarget) return !M(e, t.forcedTarget, t.color) && i.nodes[n].direct.includes(t.forcedTarget) ? [t.forcedTarget] : [];
	let a = i.jumps.filter((e) => e.from === n && t.rampSpeed >= e.speed).map((e) => e.to), o = [.../* @__PURE__ */ new Set([...i.nodes[n].next, ...a])].filter((n) => n === "finish" || !M(e, n, t.color)), s = o.filter((e) => e === "finish" || !i.nodes[e].danger);
	return s.length ? s : o;
}
function F(e, t, n) {
	return k[e.track].bets.flatMap((e, r) => t < e && n >= e ? [r] : []);
}
function I(e, t, n) {
	let r = k[e.track], i = r.nodes[t].gates[n];
	return !!i && i.every((t) => e.cars.some((e) => e.node !== null && r.nodes[e.node].physical === t));
}
function L(e, t, n, r) {
	let i = j(e, t.color);
	if (i === "ambitious") return n.length * 2;
	let a = e.cars.find((e) => e.color === t.color)?.owner;
	return i === "reckless" && a === e.activePlayer && r ? 2 : 0;
}
function R(e, t, n, r, i, a, o, s) {
	if (s > 32) return !1;
	let c = k[e.track];
	if (i === 0) {
		if (!c.nodes[n].danger) return !0;
		let i = L(e, t, a, o);
		return i > 0 && R(e, {
			...t,
			source: j(e, t.color) === "ambitious" ? "ambitious" : "reckless"
		}, n, r, i, [], !1, s + 1);
	}
	let l = P(e, t, n, i);
	return l.length ? l.some((l) => {
		if (l === "finish") return !0;
		let u = N(e.track, n, l, r);
		return c.closed && u >= c.length ? !0 : R(e, t, l, u, i - 1, [.../* @__PURE__ */ new Set([...a, ...F(e, r, u)])], o || I(e, n, l), s + 1);
	}) : !c.nodes[n].danger;
}
function z(e, t, n) {
	let r = k[e.track], i = e.cars.find((e) => e.color === t.color), a = i.node, o = i.distance, s = !0, c = !1, l = !1, u = [], d = (n) => !a || l ? [] : P(e, t, a, n).filter((i) => {
		if (i === "finish" || !r.nodes[i].danger) return !0;
		let s = N(e.track, a, i, o);
		return R(e, t, i, s, n - 1, [.../* @__PURE__ */ new Set([...u, ...F(e, o, s)])], c || I(e, a, i), 0);
	});
	for (let i = 0; i < n.length; i += 1) {
		let f = n[i];
		if (!a || l || !d(t.speed - i).includes(f)) return {
			valid: !1,
			complete: !1,
			node: a,
			distance: o,
			moved: i > 0,
			finished: l,
			rectangles: s,
			crossed: u,
			reckless: c,
			next: []
		};
		let p = N(e.track, a, f, o);
		u = [.../* @__PURE__ */ new Set([...u, ...F(e, o, p)])], c ||= I(e, a, f), o = p, f === "finish" || r.closed && o >= r.length ? (l = !0, a = null) : (a = f, s &&= r.nodes[f].rectangle);
	}
	let f = d(t.speed - n.length), p = n.length <= t.speed && (l || n.length === t.speed || !f.length), m = !a || !r.nodes[a].danger || L(e, t, u, c) > 0;
	return {
		valid: m || !p,
		complete: p && m,
		node: a,
		distance: o,
		moved: n.length > 0,
		finished: l,
		rectangles: s,
		crossed: u,
		reckless: c,
		next: f
	};
}
function ee(e, t) {
	let n = e.cars.find((e) => e.color === t);
	return n.node ? Object.entries(e.powers).flatMap(([t, r]) => {
		if (r !== "experienced") return [];
		let i = g.filter((r) => {
			let i = e.cars.find((e) => e.color === r);
			return i.owner === t && i.node !== null && k[e.track].nodes[i.node].direct.includes(n.node);
		});
		return i.length ? [{
			actor: t,
			colors: i,
			target: n.node
		}] : [];
	}) : [];
}
//#endregion
//#region src/games/downforce/schema.ts
var B = t.enum(g), V = t.enum(_), te = t.object({
	track: t.enum(v).default("river"),
	dangerPowers: t.boolean().default(!1),
	promoPowers: t.boolean().default(!1),
	pairedPowers: t.boolean().default(!1)
}).prefault({}), ne = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("bid"),
		card: t.int().min(0).max(47),
		row: t.int().min(-1).max(5)
	}),
	t.object({
		type: t.literal("power"),
		power: V
	}),
	t.object({
		type: t.literal("play"),
		card: t.int().min(0).max(47),
		reverse: t.boolean().default(!1),
		aggressive: t.boolean().default(!0),
		skip: B.nullable().default(null),
		civilizedRow: t.int().min(0).max(5).nullable().default(null),
		civilizedColor: B.nullable().default(null)
	}),
	t.object({
		type: t.literal("wild"),
		color: B,
		lucky: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("move"),
		path: t.array(t.string().max(40)).max(32)
	}),
	t.object({
		type: t.literal("bonus"),
		accept: t.boolean()
	}),
	t.object({
		type: t.literal("chooseCar"),
		color: B.nullable()
	}),
	t.object({
		type: t.literal("bet"),
		color: B
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), re = t.object({
	color: B,
	owner: t.string().nullable(),
	node: t.string().nullable(),
	distance: t.number(),
	place: t.int().min(1).max(6).nullable()
}), ie = t.enum([
	"card",
	"civilized",
	"determined",
	"ambitious",
	"reckless",
	"tough",
	"experienced",
	"defensive"
]), ae = t.object({
	kind: t.literal("move"),
	actor: t.string(),
	color: B,
	speed: t.int().min(1).max(12),
	rampSpeed: t.int().min(0).max(12),
	source: ie,
	forcedTarget: t.string().nullable()
}), oe = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("card"),
		actor: t.string()
	}),
	t.object({
		kind: t.literal("wild"),
		actor: t.string(),
		row: t.int(),
		speed: t.int(),
		choices: t.array(B)
	}),
	ae,
	t.object({
		kind: t.literal("bonus"),
		actor: t.string(),
		color: B,
		speed: t.int(),
		rampSpeed: t.int(),
		source: ie,
		forced: t.boolean()
	}),
	t.object({
		kind: t.literal("follow"),
		actor: t.string(),
		colors: t.array(B),
		target: t.string()
	}),
	t.object({
		kind: t.literal("defensive"),
		actor: t.string(),
		colors: t.array(B)
	})
]), se = t.object({
	card: t.int(),
	row: t.int(),
	value: t.int()
}), ce = t.object({
	color: B,
	powers: t.array(V),
	winner: t.string().nullable(),
	price: t.int(),
	bids: t.record(t.string(), se.nullable())
}), le = t.object({
	kind: t.enum([
		"auction",
		"play",
		"move",
		"finish",
		"bet",
		"animal",
		"die"
	]),
	rid: t.string().nullable(),
	color: B.nullable(),
	n: t.number(),
	source: ie.nullable(),
	card: t.int().nullable()
}), ue = t.object({
	track: t.enum(v),
	phase: t.enum([
		"auction",
		"powers",
		"race",
		"bet",
		"settle",
		"done"
	]),
	turn: t.string(),
	decision: oe.nullable(),
	cars: t.array(re),
	auction: t.object({
		color: B,
		powers: t.array(V),
		round: t.int(),
		eligible: t.array(t.string()),
		results: t.array(ce)
	}).nullable(),
	players: t.array(t.object({
		rid: t.string(),
		handCount: t.int(),
		reserve: t.array(t.int()),
		cost: t.int(),
		power: V.nullable(),
		powers: t.array(V),
		decided: t.boolean()
	})),
	activeCard: t.int().nullable(),
	activePlayer: t.string().nullable(),
	activeRow: t.int().nullable(),
	usedWilds: t.array(B),
	betRound: t.int().min(0).max(3),
	crossedBets: t.array(t.boolean()),
	animals: t.array(t.object({
		id: t.string(),
		index: t.int(),
		triggered: t.boolean()
	})),
	log: t.array(le),
	lastDie: t.object({
		rid: t.string(),
		color: B,
		value: t.int()
	}).nullable(),
	finalBets: t.record(t.string(), t.array(B)).nullable(),
	scores: t.record(t.string(), t.object({
		race: t.int(),
		bets: t.int(),
		cost: t.int(),
		total: t.int()
	})).nullable()
}), de = t.object({
	hand: t.array(t.int().min(0).max(47)),
	bidOptions: t.array(se),
	needsDecision: t.boolean(),
	bets: t.array(B),
	chosenBid: se.nullable()
}), H = () => ({ code: "games.downforce.errInvalid" }), U = () => ({ code: "games.downforce.errTurn" });
function W(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var G = (e, t) => e.cars.find((e) => e.color === t), K = (e, t) => e.cars.filter((e) => e.owner === t), fe = (e, t) => K(e, t).filter((e) => e.node !== null);
function pe(e) {
	return {
		track: e.config.track,
		cars: e.cars,
		animals: e.animals,
		powers: e.chosenPower,
		activePlayer: e.active?.player ?? null
	};
}
function q(e, t, n = null, r = null, i = 0, a = null, o = null) {
	e.log.push({
		kind: t,
		rid: n,
		color: r,
		n: i,
		source: a,
		card: o
	});
}
function J(e) {
	let t = e.players.filter((t) => !K(e, t).length);
	return e.secondAuction || e.auctionOrder.length - e.auctionAt <= t.length ? t : e.players;
}
function me(e, t) {
	let n = J(e), r = e.auctionOrder.length - e.auctionAt === 1 && !K(e, t).length && n.length === 1;
	return T(e.hands[t], e.auctionOrder[e.auctionAt], r);
}
function he(e) {
	return Object.fromEntries(e.players.map((t) => {
		let n = K(e, t).reduce((e, t) => e + (t.place ? S[t.place - 1] : 0), 0), r = e.bets[t].reduce((t, n, r) => {
			let i = G(e, n).place;
			return t + (i && i <= 3 ? C[r][i - 1] : 0);
		}, 0);
		return [t, {
			race: n,
			bets: r,
			cost: e.costs[t],
			total: n + r - e.costs[t]
		}];
	}));
}
function ge(e) {
	e.phase = "done", e.decision = null, e.active = null, e.scores = he(e);
}
function _e(e, t) {
	return (!K(e, t).length || fe(e, t).length > 0) && e.hands[t].length + e.reserve[t].length > 0;
}
function ve(e) {
	for (let t = 1; t <= e.players.length; t += 1) {
		let n = (e.turnIdx + t) % e.players.length;
		if (_e(e, e.players[n])) {
			e.turnIdx = n, e.phase = "race", e.active = null, e.interrupts = [], e.decision = {
				kind: "card",
				actor: e.players[n]
			};
			return;
		}
	}
	ge(e);
}
function ye(e) {
	let t = e.crossedBets.findIndex((t, n) => t && e.players.some((t) => e.bets[t].length <= n));
	if (t >= 0) {
		e.phase = "bet", e.betRound = t + 1, e.decision = null;
		return;
	}
	if (e.cars.every((e) => e.node === null)) {
		ge(e);
		return;
	}
	ve(e);
}
function be(e) {
	let t = e.active;
	t.drawAfter && _e(e, t.player) && e.draws[t.player].length && e.hands[t.player].push(e.draws[t.player].pop());
	for (let t of e.animals) {
		if (!t.triggered || t.index < 0) continue;
		t.triggered = !1;
		let n = k[e.config.track].animals.find((e) => e.id === t.id).spaces, r = t.index + 1;
		for (; r < n.length && e.cars.some((e) => e.node === n[r]);) r += 1;
		t.index = r < n.length ? r : -1, q(e, "animal", null, null, e.animals.indexOf(t));
	}
	ye(e);
}
function xe(e, t, n, r, i) {
	let a = e.active, o = G(e, t), s = o.owner ? e.chosenPower[o.owner] : null, c = n;
	return o.owner === a.player && s === "bold" && c <= 2 && (c = 3), o.owner === a.player && s === "aggressive" && a.aggressive && i === 0 && y[a.card].rows.length > 1 && y[a.card].rows[0].color !== "W" && (c += 1), {
		kind: "move",
		actor: r === "civilized" || s === "cunning" && o.owner ? o.owner : a.player,
		color: t,
		speed: c,
		rampSpeed: c,
		source: r,
		forcedTarget: null
	};
}
function Se(e, t) {
	if (t.kind === "bonus") return G(e, t.color).node ? t : null;
	if (t.kind === "follow") {
		if (M(pe(e), t.target, t.colors[0])) return null;
		let n = t.colors.filter((n) => {
			let r = G(e, n);
			return r.node !== null && k[e.config.track].nodes[r.node].direct.includes(t.target);
		});
		return n.length ? {
			...t,
			colors: n
		} : null;
	}
	if (t.kind === "defensive") {
		let n = t.colors.filter((t) => G(e, t).node !== null);
		return n.length ? {
			...t,
			colors: n
		} : null;
	}
	return t;
}
function Y(e) {
	for (e.phase = "race", e.decision = null; e.interrupts.length;) {
		let t = Se(e, e.interrupts.shift());
		if (t) {
			e.decision = t;
			return;
		}
	}
	let t = e.active;
	for (; t.at < t.rows.length;) {
		let n = t.rows[t.at++], r = y[t.card].rows[n];
		if (t.civilized?.row === n) {
			let i = t.civilized.color;
			if (r.color === "W" && t.usedWilds.push(i), G(e, i).node) {
				e.decision = xe(e, i, r.value, "civilized", n);
				return;
			}
		} else if (r.color === "W") {
			let i = y[t.card].rows.map((e) => e.color), a = g.filter((n) => !t.usedWilds.includes(n) && (e.chosenPower[t.player] === "unpredictable" || !i.includes(n)));
			e.decision = {
				kind: "wild",
				actor: t.player,
				row: n,
				speed: r.value,
				choices: a
			};
			return;
		} else if (G(e, r.color).node) {
			e.decision = xe(e, r.color, r.value, "card", n);
			return;
		}
	}
	if (e.chosenPower[t.player] === "defensive" && !t.moved.some((n) => G(e, n).owner === t.player)) {
		let n = fe(e, t.player).map((e) => e.color);
		if (t.moved.push(...K(e, t.player).map((e) => e.color)), n.length) {
			e.decision = {
				kind: "defensive",
				actor: t.player,
				colors: n
			};
			return;
		}
	}
	be(e);
}
function Ce(e, t) {
	e.phase = "settle", e.decision = null, e.settleTask = t;
}
function we(e, t, n) {
	let r = pe(e), i = z(r, t, n);
	if (!i.valid || !i.complete) return null;
	let a = G(e, t.color), o = a.node, s = a.distance, c = i.moved ? ee(r, t.color) : [];
	if (a.node = i.node, a.distance = i.distance, i.moved) {
		e.active.moved.push(t.color);
		for (let t of i.crossed) e.crossedBets[t] = !0;
		for (let t of e.animals) {
			if (t.index < 0) continue;
			let n = k[e.config.track].animals.find((e) => e.id === t.id).lines[t.index];
			s < n && a.distance >= n && (t.triggered = !0);
		}
		q(e, "move", t.actor, t.color, n.length, t.source);
	}
	i.finished && (a.place = e.cars.filter((e) => e.place !== null).length + 1, q(e, "finish", a.owner, a.color, a.place), a.owner && fe(e, a.owner).length === 0 && (e.hands[a.owner] = [], e.draws[a.owner] = [], e.reserve[a.owner] = []));
	let l = [];
	if (i.moved && a.node && a.owner) {
		let n = e.chosenPower[a.owner], r = null, o = 2;
		n === "ambitious" && i.crossed.length ? (r = "ambitious", o = i.crossed.length * 2) : n === "tough" && k[e.config.track].nodes[a.node].rumble ? r = "tough" : (t.source === "card" || t.source === "civilized") && n === "determined" && i.rectangles ? r = "determined" : n === "reckless" && a.owner === e.active.player && i.reckless && (r = "reckless"), r && l.push({
			kind: "bonus",
			actor: a.owner,
			color: a.color,
			speed: o,
			rampSpeed: t.rampSpeed,
			source: r,
			forced: k[e.config.track].nodes[a.node].danger
		});
	}
	let u = e.players.indexOf(e.active.player);
	return c.sort((t, n) => (e.players.indexOf(t.actor) - u + e.players.length) % e.players.length - (e.players.indexOf(n.actor) - u + e.players.length) % e.players.length), l.push(...c.map((e) => ({
		kind: "follow",
		...e
	}))), e.interrupts.unshift(...l), Ce(e, "advance"), i.moved ? [{
		kind: "drive",
		rid: t.actor,
		data: {
			color: t.color,
			from: o,
			path: n,
			finish: i.finished,
			source: t.source,
			track: e.config.track
		}
	}] : [];
}
function Te(e) {
	if (e.players.length === 2) for (let t of e.players) e.draws[t] = W(e, e.hands[t]), e.hands[t] = e.draws[t].splice(0, 7);
	let t = k[e.config.track].firstStart, n = e.cars.find((e) => e.node === t).owner;
	e.turnIdx = e.players.indexOf(n ?? e.priority[0]), e.phase = "race", e.decision = {
		kind: "card",
		actor: e.players[e.turnIdx]
	}, e.decided = [];
}
function Ee(e) {
	e.phase = "powers", e.decided = [];
	for (let t of e.players) e.powers[t].length <= 1 && (e.chosenPower[t] = e.powers[t][0] ?? null, e.decided.push(t));
	e.decided.length === e.players.length && Te(e);
}
function De(e) {
	if (e.auctionAt += 1, e.bids = {}, e.decided = [], e.priority.push(e.priority.shift()), e.auctionAt >= e.auctionOrder.length) {
		if (!e.secondAuction && e.deferred.length && e.players.some((t) => !K(e, t).length)) e.secondAuction = !0, e.auctionOrder = e.deferred.map((e) => e.color), e.auctionPowers = e.deferred.map((e) => e.powers), e.auctionAt = 0;
		else {
			Ee(e);
			return;
		}
	}
	if (e.secondAuction && !e.players.some((t) => !K(e, t).length)) {
		Ee(e);
		return;
	}
	e.phase = "auction";
}
function Oe(e) {
	let t = e.auctionOrder[e.auctionAt], n = e.auctionPowers[e.auctionAt], r = D(e.bids, e.priority), i = r ? e.bids[r].value : 0;
	if (e.auctionResults.push({
		color: t,
		powers: n,
		winner: r,
		price: i,
		bids: { ...e.bids }
	}), r) {
		G(e, t).owner = r, e.costs[r] += i, e.powers[r].push(...n);
		let a = x.find((e) => y[e].rows[0].color === t);
		(e.players.length === 2 ? e.reserve[r] : e.hands[r]).push(a);
	} else e.secondAuction || e.deferred.push({
		color: t,
		powers: n
	});
	q(e, "auction", r, t, i), Ce(e, "auction");
}
function ke(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		players: [...t],
		config: te.parse(e),
		phase: "auction",
		turnIdx: 0,
		hands: {},
		draws: {},
		reserve: {},
		cars: [],
		costs: {},
		powers: {},
		chosenPower: {},
		auctionOrder: [],
		auctionPowers: [],
		auctionAt: 0,
		secondAuction: !1,
		deferred: [],
		bids: {},
		decided: [],
		priority: [],
		auctionResults: [],
		bets: {},
		crossedBets: [
			!1,
			!1,
			!1
		],
		betRound: 0,
		animals: [],
		active: null,
		decision: null,
		interrupts: [],
		settleTask: null,
		log: [],
		lastDie: null,
		scores: null
	}, i = W(r, b), a = Math.floor(i.length / t.length);
	for (let [e, n] of t.entries()) r.hands[n] = i.slice(e * a, (e + 1) * a), r.draws[n] = [], r.reserve[n] = [], r.costs[n] = 0, r.powers[n] = [], r.chosenPower[n] = null, r.bets[n] = [];
	let o = k[r.config.track], s = W(r, o.starts);
	r.cars = g.map((e, t) => ({
		color: e,
		owner: null,
		node: s[t],
		distance: o.closed ? o.nodes[s[t]].front - o.length : o.nodes[s[t]].front,
		place: null
	})), r.priority = W(r, t), r.auctionOrder = W(r, g);
	let c = W(r, _.filter((e, t) => t < 6 || (t < 12 ? r.config.dangerPowers : r.config.promoPowers))), l = r.config.dangerPowers && r.config.pairedPowers ? 2 : 1;
	return r.auctionPowers = r.auctionOrder.map((e, t) => c.slice(t * l, (t + 1) * l)), r.animals = o.animals.map((e) => ({
		id: e.id,
		index: 0,
		triggered: !1
	})), { state: r };
}
function Ae(e, t, n) {
	let r = e.chosenPower[n], i = y[t.card], a = e.hands[n].includes(t.card), o = e.reserve[n].includes(t.card);
	if (!a && !o || t.reverse && r !== "tricky" || t.skip !== null && (r !== "strategic" || i.rows.length !== 6 || !i.rows.some((e) => e.color === t.skip))) return H();
	let s = null;
	if (t.civilizedRow !== null) {
		let a = i.rows[t.civilizedRow], o = t.civilizedColor ?? (a?.color === "W" ? null : a?.color);
		if (r !== "civilized" || !a || !o || !G(e, o).owner || G(e, o).owner === n || a.color !== "W" && a.color !== o || a.color === "W" && i.rows.some((e) => e.color === o)) return H();
		s = {
			row: t.civilizedRow,
			color: o
		};
	} else if (t.civilizedColor !== null) return H();
	let c = i.rows.map((e, t) => t).filter((e) => i.rows[e].color !== t.skip);
	return t.reverse && c.reverse(), s && (c = [s.row, ...c.filter((e) => e !== s.row)]), a ? e.hands[n] = e.hands[n].filter((e) => e !== t.card) : e.reserve[n] = e.reserve[n].filter((e) => e !== t.card), e.active = {
		card: t.card,
		player: n,
		rows: c,
		at: 0,
		usedWilds: [],
		moved: [],
		civilized: s,
		drawAfter: e.players.length === 2 && a,
		aggressive: t.aggressive
	}, e.lastDie = null, q(e, "play", n, null, 0, null, t.card), Y(e), null;
}
function je(t, n, r) {
	if (n.type === "tick") {
		if (r.by !== "$engine" || t.phase !== "settle") return U();
		let e = structuredClone(t), n = e.settleTask;
		return e.settleTask = null, n === "auction" ? De(e) : Y(e), { state: e };
	}
	if (!t.players.includes(r.by) || t.phase === "done" || t.phase === "settle") return U();
	let i = structuredClone(t), a = r.by;
	if (n.type === "bid") {
		if (i.phase !== "auction" || !J(i).includes(a) || i.decided.includes(a)) return U();
		let e = me(i, a).find((e) => e.card === n.card && e.row === n.row);
		return e ? (i.bids[a] = e.value > 0 ? e : null, i.decided.push(a), J(i).every((e) => i.decided.includes(e)) && Oe(i), { state: i }) : H();
	}
	if (n.type === "power") return i.phase !== "powers" || i.decided.includes(a) ? U() : i.powers[a].includes(n.power) ? (i.chosenPower[a] = n.power, i.decided.push(a), i.decided.length === i.players.length && Te(i), { state: i }) : H();
	if (n.type === "bet") return i.phase !== "bet" || i.bets[a].length >= i.betRound ? U() : (i.bets[a].push(n.color), i.players.every((e) => i.bets[e].length === i.betRound) && (q(i, "bet", null, null, i.betRound), ye(i)), { state: i });
	let o = i.decision;
	if (i.phase !== "race" || !o || o.actor !== a) return U();
	if (n.type === "play") return o.kind === "card" ? Ae(i, n, a) ?? {
		state: i,
		fx: [{
			kind: "play",
			rid: a,
			data: { card: n.card }
		}]
	} : H();
	if (n.type === "wild") {
		if (o.kind !== "wild" || !o.choices.includes(n.color)) return H();
		let t = G(i, n.color);
		if (n.lucky && (i.chosenPower[a] !== "lucky" || t.owner !== a)) return H();
		if (i.active.usedWilds.push(n.color), !t.node) return Y(i), { state: i };
		let r = o.speed;
		return n.lucky && (r = e(i.seed, i.cursor++, 6) + 1, i.lastDie = {
			rid: a,
			color: n.color,
			value: r
		}, q(i, "die", a, n.color, r)), i.decision = xe(i, n.color, r, "card", o.row), { state: i };
	}
	if (n.type === "move") {
		if (o.kind !== "move") return H();
		let e = we(i, o, n.path);
		return e === null ? H() : {
			state: i,
			fx: e
		};
	}
	if (n.type === "bonus") return o.kind !== "bonus" || !n.accept && o.forced ? H() : (n.accept ? i.decision = {
		kind: "move",
		actor: o.actor,
		color: o.color,
		speed: o.speed,
		rampSpeed: o.rampSpeed,
		source: o.source,
		forcedTarget: null
	} : Y(i), { state: i });
	if (n.type === "chooseCar") {
		if (o.kind !== "follow" && o.kind !== "defensive") return H();
		if (n.color === null) return Y(i), { state: i };
		if (!o.colors.includes(n.color)) return H();
		if (o.kind === "follow") {
			let e = we(i, {
				kind: "move",
				actor: a,
				color: n.color,
				speed: 1,
				rampSpeed: 0,
				source: "experienced",
				forcedTarget: o.target
			}, [o.target]);
			return e === null ? H() : {
				state: i,
				fx: e
			};
		}
		return i.decision = {
			kind: "move",
			actor: a,
			color: n.color,
			speed: 3,
			rampSpeed: 0,
			source: "defensive",
			forcedTarget: null
		}, { state: i };
	}
	return H();
}
function Me(e, t, n) {
	let r = je(e, t, n);
	if ("code" in r) return r;
	let i = r.state, a = [...r.fx ?? []];
	if (i.auctionResults.length > e.auctionResults.length) {
		let e = i.auctionResults.at(-1);
		e.winner && a.push({
			kind: "auction",
			rid: e.winner,
			data: {
				color: e.color,
				price: e.price
			}
		});
	}
	for (let t of i.animals) {
		let n = e.animals.find((e) => e.id === t.id);
		n && t.index !== n.index && a.push({
			kind: "animal",
			data: {
				id: t.id,
				from: n.index,
				to: t.index,
				track: i.config.track
			}
		});
	}
	for (let t of i.players) i.draws[t].length < e.draws[t].length && i.hands[t].length > e.hands[t].length && a.push({
		kind: "draw",
		rid: t,
		data: {}
	});
	return {
		...r,
		fx: a
	};
}
function Ne(e, t) {
	let n = e.phase === "auction" || e.phase === "settle" && e.settleTask === "auction", r = {
		track: e.config.track,
		phase: e.phase,
		turn: e.players[e.turnIdx],
		decision: e.decision,
		cars: e.cars,
		auction: n ? {
			color: e.auctionOrder[e.auctionAt],
			powers: e.auctionPowers[e.auctionAt],
			round: e.auctionResults.length + +(e.phase === "auction"),
			eligible: e.phase === "auction" ? J(e) : Object.keys(e.bids),
			results: e.auctionResults
		} : null,
		players: e.players.map((t) => ({
			rid: t,
			handCount: e.hands[t].length + e.draws[t].length,
			reserve: e.reserve[t],
			cost: e.costs[t],
			power: e.chosenPower[t],
			powers: e.powers[t],
			decided: e.phase === "bet" ? e.bets[t].length >= e.betRound : e.decided.includes(t)
		})),
		activeCard: e.active?.card ?? null,
		activePlayer: e.active?.player ?? null,
		activeRow: e.active ? e.active.rows[e.active.at - 1] ?? null : null,
		usedWilds: e.active?.usedWilds ?? [],
		betRound: e.betRound,
		crossedBets: e.crossedBets,
		animals: e.animals,
		log: e.log,
		lastDie: e.lastDie,
		finalBets: e.phase === "done" ? e.bets : null,
		scores: e.scores
	}, i = e.players.includes(t) && (e.phase === "auction" ? J(e).includes(t) && !e.decided.includes(t) : e.phase === "powers" ? !e.decided.includes(t) : e.phase === "bet" ? e.bets[t].length < e.betRound : e.phase === "race" && e.decision?.actor === t);
	return {
		public: r,
		private: e.players.includes(t) ? {
			hand: e.hands[t],
			bidOptions: e.phase === "auction" && i ? me(e, t) : [],
			needsDecision: i,
			bets: e.bets[t],
			chosenBid: e.bids[t] ?? null
		} : void 0
	};
}
function Pe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.scores, n = (t) => Math.min(7, ...K(e, t).map((e) => e.place ?? 7)), r = [...e.players].sort((e, r) => t[r].total - t[e].total || n(e) - n(r)), i = r[0];
	return {
		phase: "done",
		winner: r.filter((e) => t[e].total === t[i].total && n(e) === n(i)),
		ranking: r,
		scores: Object.fromEntries(e.players.map((e) => [e, t[e].total]))
	};
}
var Fe = {
	meta: O,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ne,
		publicView: ue,
		privateView: de,
		config: te
	},
	setup: ke,
	reduce: Me,
	viewFor: Ne,
	status: Pe,
	nextTickIn: (e) => e.phase === "settle" ? 500 : null
};
//#endregion
//#region src/games/downforce/pieces.tsx
function Ie({ id: e }) {
	return /* @__PURE__ */ p("svg", {
		viewBox: "-45 -35 90 70",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ f("ellipse", {
			rx: "41",
			ry: "24",
			fill: "#c5a175",
			stroke: "#453b2b",
			strokeWidth: "3"
		}), e === "elephant" ? /* @__PURE__ */ f("path", {
			d: "M-23 3Q-39-19-19-22L17-19Q35-5 25 15L37 24L29 29L17 14H-21Z",
			fill: "#75776f",
			stroke: "#343c39",
			strokeWidth: "2"
		}) : e === "antelope" ? /* @__PURE__ */ f("path", {
			d: "M-27 4L-16-10H10L21-20L21-32M21-20L31-31M21-20L28-5L16 2L10 19M-13 2L-21 20M8 3L-8 3",
			fill: "none",
			stroke: "#554530",
			strokeWidth: "8",
			strokeLinecap: "round"
		}) : /* @__PURE__ */ f("path", {
			d: "M-25 4C-38-22 31-29 30 0S-27 29-16 6S17-8 17 4",
			fill: "none",
			stroke: "#576345",
			strokeWidth: "10",
			strokeLinecap: "round"
		})]
	});
}
function X({ color: e, className: t }) {
	let n = e === "W" ? {
		color: "#fffef5",
		stripe: "#e5e5df",
		number: ""
	} : w[e];
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 112 64",
		className: t,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ p("g", {
				fill: e === "W" ? n.color : "#171d22",
				stroke: "#080b10",
				strokeWidth: "1.5",
				children: [
					/* @__PURE__ */ f("rect", {
						x: "19",
						y: "2",
						width: "25",
						height: "14",
						rx: "4"
					}),
					/* @__PURE__ */ f("rect", {
						x: "19",
						y: "48",
						width: "25",
						height: "14",
						rx: "4"
					}),
					/* @__PURE__ */ f("rect", {
						x: "76",
						y: "5",
						width: "17",
						height: "12",
						rx: "3"
					}),
					/* @__PURE__ */ f("rect", {
						x: "76",
						y: "47",
						width: "17",
						height: "12",
						rx: "3"
					})
				]
			}),
			/* @__PURE__ */ f("path", {
				d: "M30 12V52M83 14V50",
				stroke: "#68737a",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("path", {
				d: "M7 9H18V55H7Z M96 12H106V52H96Z M19 21L39 15L60 20L76 27L100 28V36L76 37L60 44L39 49L19 43Z",
				fill: n.color,
				stroke: "#111a22",
				strokeWidth: "2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ f("path", {
				d: "M21 26L43 23L75 29L98 30V34L75 35L43 41L21 38Z",
				fill: n.stripe
			}),
			/* @__PURE__ */ f("path", {
				d: "M41 21Q64 20 69 32Q64 44 41 43L35 36V28Z",
				fill: "#18232a",
				stroke: n.color,
				strokeWidth: "3"
			}),
			/* @__PURE__ */ f("ellipse", {
				cx: "50",
				cy: "32",
				rx: "8",
				ry: "7",
				fill: "#d6dce0"
			}),
			/* @__PURE__ */ f("path", {
				d: "M48 26L56 31L49 36",
				stroke: "#334957",
				strokeWidth: "4",
				fill: "none"
			}),
			/* @__PURE__ */ f("path", {
				d: "M20 20L33 17M20 44L33 47M9 12V51M101 16V48",
				stroke: "#fff",
				opacity: ".4",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("text", {
				x: "83",
				y: "37",
				textAnchor: "middle",
				fill: e === "K" ? "white" : "#161d25",
				fontSize: "14",
				fontWeight: "900",
				fontFamily: "sans-serif",
				children: n.number
			})
		]
	});
}
function Z({ id: e, selected: t = !1, activeRow: n, onClick: r, anchor: i = !1, anchorName: a, disabled: c = !1 }) {
	let l = s(), u = y[e], { ref: d, hidden: m } = o(a ?? (i ? `card:${e}` : null));
	return /* @__PURE__ */ p("button", {
		type: "button",
		ref: d,
		className: "df-card",
		"data-selected": t,
		"data-clickable": !!r,
		disabled: c,
		onClick: r,
		"aria-label": u.rows.map((e) => `${l(`games.downforce.${e.color}`)} ${e.value}`).join(", "),
		style: { visibility: m ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ p("span", {
				className: "df-card-brand",
				children: ["DOWNFORCE ", /* @__PURE__ */ f("i", { children: "↗" })]
			}),
			/* @__PURE__ */ f("span", {
				className: "df-card-rows",
				children: u.rows.map((e, t) => /* @__PURE__ */ p("span", {
					className: "df-card-row",
					"data-wild": e.color === "W",
					"data-active": n === t,
					style: { "--df-car": e.color === "W" ? "#e4ded0" : w[e.color].color },
					children: [
						/* @__PURE__ */ f(X, { color: e.color }),
						/* @__PURE__ */ f("b", { children: e.value }),
						/* @__PURE__ */ f("small", { children: e.color === "W" ? "" : w[e.color].number })
					]
				}, t))
			}),
			/* @__PURE__ */ p("span", {
				className: "df-card-foot",
				children: [u.speed8 ? "8 SPEED" : "SPEED CARD", /* @__PURE__ */ f("span", { children: "▰▱▰" })]
			})
		]
	});
}
//#endregion
//#region src/games/downforce/board.tsx
var Le = (e, t, n) => {
	let r = !1;
	for (let i = 0, a = n.length - 1; i < n.length; a = i++) {
		let o = n[i], s = n[a];
		o[1] > t != s[1] > t && e < (s[0] - o[0]) * (t - o[1]) / (s[1] - o[1]) + o[0] && (r = !r);
	}
	return r;
};
function Re({ pub: e, legal: t = [], path: r = [], onSpace: o, carChoices: c = [], onCar: l }) {
	let d = s(), m = k[e.track], h = i(null), [g, _] = a({
		w: 1e3,
		h: 600
	}), [v, y] = a(null), b = i(/* @__PURE__ */ new Map()), x = i(0), S = e.cars.find((t) => t.node && e.decision?.kind === "move" && t.color === e.decision.color) ?? e.cars.find((e) => e.node), C = S?.node ? m.nodes[S.node] : null, w = v ?? (g.w < 650 && C ? {
		x: C.x,
		y: C.y,
		zoom: 2.8
	} : {
		x: m.width / 2,
		y: m.height / 2,
		zoom: 1
	}), T = i(w);
	n(() => {
		T.current = w;
	});
	let E = Math.min(g.w / m.width, g.h / m.height) * w.zoom, D = g.w / E, O = g.h / E;
	n(() => {
		let e = h.current, t = new ResizeObserver(() => _({
			w: e.clientWidth || 1,
			h: e.clientHeight || 1
		}));
		return t.observe(e), () => t.disconnect();
	}, []), n(() => {
		let e = h.current, t = (e) => {
			e.preventDefault(), y((t) => {
				let n = t ?? {
					x: m.width / 2,
					y: m.height / 2,
					zoom: 1
				};
				return {
					...n,
					zoom: Math.min(6, Math.max(1, n.zoom * (e.deltaY < 0 ? 1.2 : 1 / 1.2)))
				};
			});
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [m]);
	let A = (e) => {
		e.currentTarget.setPointerCapture(e.pointerId), b.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), b.current.size === 1 && (x.current = 0);
	}, j = (e) => {
		let t = b.current.get(e.pointerId);
		if (t) {
			if (b.current.size === 2) {
				let n = [...b.current.entries()].find(([t]) => t !== e.pointerId)[1], r = Math.hypot(t.x - n.x, t.y - n.y), i = Math.hypot(e.clientX - n.x, e.clientY - n.y);
				if (r > 0) {
					let a = T.current, o = e.currentTarget.getBoundingClientRect(), s = (t.x + n.x) / 2 - o.left - g.w / 2, c = (t.y + n.y) / 2 - o.top - g.h / 2, l = (e.clientX + n.x) / 2 - o.left - g.w / 2, u = (e.clientY + n.y) / 2 - o.top - g.h / 2, d = Math.max(1, Math.min(6, a.zoom * i / r)), f = E * d / a.zoom;
					y({
						x: a.x + s / E - l / f,
						y: a.y + c / E - u / f,
						zoom: d
					});
				}
				x.current = 99;
			} else {
				let n = e.clientX - t.x, r = e.clientY - t.y;
				x.current += Math.abs(n) + Math.abs(r), y({
					...T.current,
					x: Math.max(0, Math.min(m.width, T.current.x - n / E)),
					y: Math.max(0, Math.min(m.height, T.current.y - r / E))
				});
			}
			b.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
		}
	}, M = (n) => {
		let r = b.current.size === 1 && x.current < 8;
		if (b.current.delete(n.pointerId), !r) return;
		let i = h.current?.getScreenCTM();
		if (!i) return;
		let a = new DOMPoint(n.clientX, n.clientY).matrixTransform(i.inverse()), s = t.find((e) => e !== "finish" && Le(a.x, a.y, m.nodes[e].poly));
		if (s) {
			o?.(s);
			return;
		}
		let u = e.cars.find((e) => e.node && c.includes(e.color) && Le(a.x, a.y, m.nodes[e.node].poly));
		u && l?.(u.color);
	}, N = [...new Map(Object.entries(m.nodes).map(([e, t]) => [t.physical, {
		k: e,
		n: t
	}])).values()], P = e.decision?.kind === "move" ? e.decision.color : null, F = r.filter((e) => e !== "finish").map((e) => m.nodes[e]), I = () => {
		let t = e.cars.find((e) => e.color === P) ?? e.cars.find((e) => e.node);
		if (t?.node) {
			let e = m.nodes[t.node];
			y({
				x: e.x,
				y: e.y,
				zoom: 3
			});
		}
	};
	return /* @__PURE__ */ p("div", {
		className: "df-board-wrap",
		children: [/* @__PURE__ */ p("svg", {
			ref: h,
			viewBox: `${w.x - D / 2} ${w.y - O / 2} ${D} ${O}`,
			className: "df-board",
			onPointerDown: A,
			onPointerMove: j,
			onPointerUp: M,
			onPointerCancel: (e) => b.current.delete(e.pointerId),
			"aria-label": d(`games.downforce.${e.track}`),
			children: [
				/* @__PURE__ */ f("image", {
					href: `games/downforce/${e.track}.svg`,
					width: m.width,
					height: m.height
				}),
				N.map(({ k: e, n: t }) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("polygon", {
					points: t.poly.map((e) => e.join(",")).join(" "),
					fill: t.danger ? "#993d34" : "#5b6564",
					fillOpacity: t.danger ? .7 : .42,
					stroke: "#e9dec0",
					strokeOpacity: ".65",
					strokeWidth: "1.8"
				}), t.danger && /* @__PURE__ */ f("path", {
					d: `M${t.x - 8},${t.y - 9}l16,18m0,-18l-16,18`,
					stroke: "#f7c198",
					strokeWidth: "3"
				})] }, e)),
				m.bets.map((t, n) => {
					let r = Object.values(m.nodes).filter((e) => Math.abs(e.front - t) < 80);
					if (!r.length) return null;
					let i = r.reduce((e, t) => e + t.x, 0) / r.length, a = r.reduce((e, t) => e + t.y, 0) / r.length;
					return /* @__PURE__ */ p("g", {
						transform: `translate(${i},${a})`,
						children: [/* @__PURE__ */ f("circle", {
							r: "18",
							fill: e.crossedBets[n] ? "#c34a2e" : "#e8ca4e",
							stroke: "#fff5db",
							strokeWidth: "3"
						}), /* @__PURE__ */ f("text", {
							textAnchor: "middle",
							y: "7",
							fontSize: "22",
							fontWeight: "900",
							fill: "#222b2e",
							children: n + 1
						})]
					}, n);
				}),
				m.jumps.map((e, t) => {
					let n = m.nodes[e.from], r = m.nodes[e.to];
					return /* @__PURE__ */ p("g", { children: [
						/* @__PURE__ */ f("path", {
							d: `M${n.x},${n.y}L${r.x},${r.y}`,
							stroke: "#f4b946",
							strokeDasharray: "7 6",
							strokeWidth: "3"
						}),
						/* @__PURE__ */ f("rect", {
							x: n.x - 17,
							y: n.y - 15,
							width: "34",
							height: "30",
							rx: "4",
							fill: "#e8b02f",
							stroke: "#3e3326",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ f("text", {
							x: n.x,
							y: n.y + 8,
							textAnchor: "middle",
							fill: "#201c17",
							fontSize: "24",
							fontWeight: "900",
							children: e.speed
						})
					] }, t);
				}),
				m.animals.flatMap((e) => e.spaces.map((t, n) => {
					let r = m.nodes[t];
					return /* @__PURE__ */ f(u, {
						name: `animal-node:${e.id}:${n}`,
						r: {
							x: r.x - 45,
							y: r.y - 35,
							w: 90,
							h: 70
						}
					}, `${e.id}:${n}`);
				})),
				e.animals.map((e) => {
					if (e.index < 0) return null;
					let t = m.nodes[m.animals.find((t) => t.id === e.id).spaces[e.index]];
					return /* @__PURE__ */ p("g", {
						transform: `translate(${t.x},${t.y})`,
						children: [/* @__PURE__ */ f("foreignObject", {
							x: "-45",
							y: "-35",
							width: "90",
							height: "70",
							children: /* @__PURE__ */ f(Be, { id: e.id })
						}), /* @__PURE__ */ f("title", { children: d(`games.downforce.${e.id}`) })]
					}, e.id);
				}),
				t.filter((e) => e !== "finish").map((e) => /* @__PURE__ */ p("g", {
					role: "button",
					tabIndex: 0,
					"aria-label": d("games.downforce.space"),
					onKeyDown: (t) => {
						(t.key === "Enter" || t.key === " ") && (t.preventDefault(), o?.(e));
					},
					children: [/* @__PURE__ */ f("polygon", {
						points: m.nodes[e].poly.map((e) => e.join(",")).join(" "),
						fill: "white",
						fillOpacity: ".4",
						stroke: "white",
						strokeWidth: "8"
					}), /* @__PURE__ */ f("polygon", {
						points: m.nodes[e].poly.map((e) => e.join(",")).join(" "),
						fill: "none",
						stroke: "#20292e",
						strokeWidth: "4",
						strokeDasharray: "12 8",
						children: /* @__PURE__ */ f("animate", {
							attributeName: "stroke-dashoffset",
							from: "0",
							to: "-20",
							dur: ".7s",
							repeatCount: "indefinite"
						})
					})]
				}, e)),
				!!F.length && /* @__PURE__ */ f("polyline", {
					points: [...P && e.cars.find((e) => e.color === P)?.node ? [m.nodes[e.cars.find((e) => e.color === P).node]] : [], ...F].map((e) => `${e.x},${e.y}`).join(" "),
					stroke: "#fff6cf",
					strokeWidth: "8",
					strokeLinecap: "round",
					strokeLinejoin: "round",
					fill: "none",
					opacity: ".85"
				}),
				Object.entries(m.nodes).map(([e, t]) => /* @__PURE__ */ f(u, {
					name: `node:${e}`,
					r: {
						x: t.x - 40,
						y: t.y - 23,
						w: 80,
						h: 46
					}
				}, e)),
				e.cars.filter((e) => e.node).map((e) => {
					let t = m.nodes[e.node], n = c.includes(e.color);
					return /* @__PURE__ */ p("g", {
						transform: `translate(${t.x},${t.y}) rotate(${t.angle * 180 / Math.PI})`,
						className: "df-track-car",
						"data-active": P === e.color,
						children: [n && /* @__PURE__ */ f("ellipse", {
							rx: "50",
							ry: "30",
							fill: "white",
							fillOpacity: ".3",
							stroke: "white",
							strokeWidth: "4",
							strokeDasharray: "8 5",
							children: /* @__PURE__ */ f("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: "-26",
								dur: ".7s",
								repeatCount: "indefinite"
							})
						}), /* @__PURE__ */ f("foreignObject", {
							x: "-45",
							y: "-25",
							width: "90",
							height: "50",
							children: /* @__PURE__ */ f(ze, { color: e.color })
						})]
					}, e.color);
				}),
				F.at(-1) && P && /* @__PURE__ */ f("g", {
					transform: `translate(${F.at(-1).x},${F.at(-1).y}) rotate(${F.at(-1).angle * 180 / Math.PI})`,
					opacity: ".65",
					children: /* @__PURE__ */ f("foreignObject", {
						x: "-45",
						y: "-25",
						width: "90",
						height: "50",
						children: /* @__PURE__ */ f(X, { color: P })
					})
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "df-camera",
			children: [
				/* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => y({
						...w,
						zoom: Math.min(6, w.zoom * 1.5)
					}),
					"aria-label": d("games.downforce.zoomIn"),
					children: "＋"
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => y({
						...w,
						zoom: Math.max(1, w.zoom / 1.5)
					}),
					"aria-label": d("games.downforce.zoomOut"),
					children: "−"
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => y({
						x: m.width / 2,
						y: m.height / 2,
						zoom: 1
					}),
					children: d("games.downforce.fit")
				}),
				/* @__PURE__ */ p("button", {
					type: "button",
					onClick: I,
					children: ["◎", /* @__PURE__ */ f("span", {
						className: "sr-only",
						children: d("games.downforce.focus")
					})]
				})
			]
		})]
	});
}
function ze({ color: e }) {
	let { ref: t, hidden: n } = o(`car:${e}`);
	return /* @__PURE__ */ f("div", {
		ref: t,
		style: {
			visibility: n ? "hidden" : void 0,
			filter: `drop-shadow(0 2px 1px ${w[e].color}55)`
		},
		children: /* @__PURE__ */ f(X, { color: e })
	});
}
function Be({ id: e }) {
	let { ref: t, hidden: n } = o(`animal:${e}`);
	return /* @__PURE__ */ f("div", {
		ref: t,
		style: { visibility: n ? "hidden" : void 0 },
		children: /* @__PURE__ */ f(Ie, { id: e })
	});
}
//#endregion
//#region src/games/downforce/view-player.tsx
function Ve(e) {
	return /* @__PURE__ */ f(He, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function He({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let { ref: u } = o(`hand:${r}`), m = s(), h = e.decision, _ = e.players.find((e) => e.rid === r)?.power, v = (e) => n.find((t) => t.rid === e)?.name ?? e, b = `${e.phase}:${e.log.length}:${h?.kind}:${h?.actor}:${h?.kind === "wild" ? h.row : ""}`, x = {
		key: b,
		card: null,
		path: [],
		reverse: !1,
		aggressive: !0,
		skip: null,
		civilized: null,
		lucky: !1
	}, [S, C] = a(x), [T, E] = a(null), D = S.key === b ? S : x, O = (e) => C({
		...D,
		...e
	}), k = t?.needsDecision && e.phase !== "done", j = h?.kind === "move" ? h : null, M = j ? z(A(e), j, D.path) : null, N = D.card !== null && [...t?.hand ?? [], ...e.players.find((e) => e.rid === r)?.reserve ?? []].includes(D.card) ? D.card : null, P = (e) => i(e), F = (t) => {
		k && (e.phase === "bet" ? P({
			type: "bet",
			color: t
		}) : h?.kind === "wild" ? P({
			type: "wild",
			color: t,
			lucky: D.lucky
		}) : (h?.kind === "follow" || h?.kind === "defensive") && P({
			type: "chooseCar",
			color: t
		}));
	}, I = k ? e.phase === "bet" ? [...g] : h?.kind === "wild" ? h.choices : h?.kind === "follow" || h?.kind === "defensive" ? h.colors : [] : [], L = m("games.downforce.racing");
	e.phase === "auction" ? L = m("games.downforce.auction", { n: e.auction.round }) : e.phase === "done" ? L = m("games.downforce.results") : e.phase === "powers" ? L = m("games.downforce.choosePower") : e.phase === "bet" ? L = m("games.downforce.bet", { n: e.betRound }) : e.phase === "settle" ? L = m("games.downforce.settling") : h?.kind === "card" ? L = m("games.downforce.play") : h?.kind === "wild" ? L = m("games.downforce.wild", { n: h.speed }) : h?.kind === "move" ? L = m("games.downforce.move", {
		car: m(`games.downforce.${h.color}`),
		n: h.speed
	}) : h?.kind === "bonus" ? L = m("games.downforce.bonus", {
		power: m(`games.downforce.${h.source}`),
		n: h.speed
	}) : h?.kind === "follow" ? L = m("games.downforce.follow") : h?.kind === "defensive" && (L = m("games.downforce.defensiveChoice"));
	let R = /* @__PURE__ */ p("div", {
		className: "df-header",
		children: [/* @__PURE__ */ f("div", {
			className: "df-crew-strip",
			children: e.players.map((t) => /* @__PURE__ */ p(We, {
				rid: t.rid,
				active: t.rid === h?.actor,
				me: t.rid === r,
				children: [
					/* @__PURE__ */ p("div", {
						className: "df-crew-name",
						children: [/* @__PURE__ */ f("b", { children: v(t.rid) }), /* @__PURE__ */ p("span", { children: [t.cost, "M"] })]
					}),
					/* @__PURE__ */ p("div", {
						className: "df-crew-cars",
						children: [e.cars.filter((e) => e.owner === t.rid).map((e) => /* @__PURE__ */ p("span", {
							style: { "--df-car": w[e.color].color },
							children: [/* @__PURE__ */ f(X, { color: e.color }), e.place && /* @__PURE__ */ f("b", { children: e.place })]
						}, e.color)), /* @__PURE__ */ f("small", { children: m("games.downforce.handCount", { n: t.handCount + t.reserve.length }) })]
					}),
					t.power && /* @__PURE__ */ f("button", {
						className: "df-power-name",
						type: "button",
						onClick: () => E(t.power),
						children: m(`games.downforce.${t.power}`)
					})
				]
			}, t.rid))
		}), /* @__PURE__ */ p("div", {
			className: "df-phase",
			children: [
				/* @__PURE__ */ f("span", {
					className: "df-track-name",
					children: m(`games.downforce.${e.track}`)
				}),
				/* @__PURE__ */ f("strong", { children: L }),
				/* @__PURE__ */ f("span", {
					className: "df-wait",
					children: !k && e.phase !== "settle" && e.phase !== "done" && (h ? m("games.downforce.waiting", { name: v(h.actor) }) : m("games.downforce.waitingAll"))
				})
			]
		})]
	}), ee = e.phase === "auction" || h?.kind === "card", B = /* @__PURE__ */ p("div", {
		className: "df-actions",
		children: [/* @__PURE__ */ p("div", {
			className: "df-hand",
			ref: u,
			children: [ee && t ? t.hand.map((e) => /* @__PURE__ */ f(Z, {
				id: e,
				selected: N === e,
				anchor: !0,
				onClick: k ? () => O({ card: e }) : void 0
			}, e)) : I.length ? I.map((t) => /* @__PURE__ */ p("button", {
				type: "button",
				className: "df-choice-car",
				onClick: () => F(t),
				"aria-label": e.phase === "bet" ? m("games.downforce.betOn", { car: m(`games.downforce.${t}`) }) : m(`games.downforce.${t}`),
				children: [
					/* @__PURE__ */ f(X, { color: t }),
					/* @__PURE__ */ f("b", { children: w[t].number }),
					/* @__PURE__ */ f("span", { children: e.cars.find((e) => e.color === t)?.place ? m("games.downforce.place", { n: e.cars.find((e) => e.color === t).place }) : m(`games.downforce.${t}`) })
				]
			}, t)) : /* @__PURE__ */ p("div", {
				className: "df-pit-status",
				children: [j && /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f(X, { color: j.color }),
					/* @__PURE__ */ f("b", { children: m("games.downforce.plan", {
						n: D.path.length,
						total: j.speed
					}) }),
					M?.complete && !M.finished && D.path.length < j.speed && /* @__PURE__ */ f("span", { children: m("games.downforce.blocked") })
				] }), !j && e.activeCard !== null && /* @__PURE__ */ f(Z, {
					id: e.activeCard,
					activeRow: e.activeRow
				})]
			}), ee && e.players.find((e) => e.rid === r)?.reserve.map((e) => /* @__PURE__ */ f("div", {
				className: "df-reserve",
				children: /* @__PURE__ */ f(Z, {
					id: e,
					selected: N === e,
					anchor: !0,
					onClick: k ? () => O({ card: e }) : void 0
				})
			}, e))]
		}), /* @__PURE__ */ p("div", {
			className: "df-controls",
			children: [
				k && e.phase === "auction" && N !== null && t?.bidOptions.filter((e) => e.card === N).map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					className: e.value ? "df-main-button" : "df-button",
					onClick: () => P({
						type: "bid",
						card: e.card,
						row: e.row
					}),
					children: e.value ? m("games.downforce.bid", { n: e.value }) : m("games.downforce.pass")
				}, e.row)),
				k && h?.kind === "card" && N !== null && /* @__PURE__ */ p(d, { children: [
					_ === "aggressive" && y[N].rows.length > 1 && e.cars.some((e) => e.owner === r && e.color === y[N].rows[0].color) && /* @__PURE__ */ p("label", { children: [/* @__PURE__ */ f("input", {
						type: "checkbox",
						checked: D.aggressive,
						onChange: (e) => O({ aggressive: e.target.checked })
					}), m("games.downforce.aggressiveExtra")] }),
					_ === "tricky" && /* @__PURE__ */ p("label", { children: [/* @__PURE__ */ f("input", {
						type: "checkbox",
						checked: D.reverse,
						onChange: (e) => O({ reverse: e.target.checked })
					}), m("games.downforce.reverse")] }),
					_ === "strategic" && y[N].rows.length === 6 && /* @__PURE__ */ p("select", {
						"aria-label": m("games.downforce.skip"),
						value: D.skip ?? "",
						onChange: (e) => O({ skip: e.target.value || null }),
						children: [/* @__PURE__ */ f("option", {
							value: "",
							children: m("games.downforce.noSkip")
						}), g.map((e) => /* @__PURE__ */ f("option", {
							value: e,
							children: m(`games.downforce.${e}`)
						}, e))]
					}),
					_ === "civilized" && /* @__PURE__ */ p("select", {
						"aria-label": m("games.downforce.civilizedFirst"),
						value: D.civilized ? `${D.civilized.row}:${D.civilized.color}` : "",
						onChange: (e) => {
							let [t, n] = e.target.value.split(":");
							O({ civilized: n ? {
								row: Number(t),
								color: n
							} : null });
						},
						children: [/* @__PURE__ */ f("option", {
							value: "",
							children: m("games.downforce.noCivilized")
						}), y[N].rows.flatMap((t, n) => (t.color === "W" ? g.filter((e) => !y[N].rows.some((t) => t.color === e)) : [t.color]).filter((t) => {
							let n = e.cars.find((e) => e.color === t)?.owner;
							return n && n !== r;
						}).map((e) => /* @__PURE__ */ p("option", {
							value: `${n}:${e}`,
							children: [
								m(`games.downforce.${e}`),
								" · ",
								t.value
							]
						}, `${n}:${e}`)))]
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "df-main-button",
						onClick: () => P({
							type: "play",
							card: N,
							reverse: D.reverse,
							aggressive: D.aggressive,
							skip: D.skip,
							civilizedRow: D.civilized?.row ?? null,
							civilizedColor: D.civilized?.color ?? null
						}),
						children: m("games.downforce.play")
					})
				] }),
				k && j && /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "df-button",
						disabled: !D.path.length,
						onClick: () => O({ path: D.path.slice(0, -1) }),
						children: m("games.downforce.undo")
					}),
					M?.next.includes("finish") && /* @__PURE__ */ f("button", {
						type: "button",
						className: "df-button",
						onClick: () => O({ path: [...D.path, "finish"] }),
						children: m("games.downforce.finishSpace")
					}),
					/* @__PURE__ */ f("button", {
						type: "button",
						className: "df-main-button",
						disabled: !M?.complete || !M.valid,
						onClick: () => P({
							type: "move",
							path: D.path
						}),
						children: m("games.downforce.finishMove")
					})
				] }),
				k && h?.kind === "bonus" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("button", {
					type: "button",
					className: "df-main-button",
					onClick: () => P({
						type: "bonus",
						accept: !0
					}),
					children: m("games.downforce.accept")
				}), !h.forced && /* @__PURE__ */ f("button", {
					type: "button",
					className: "df-button",
					onClick: () => P({
						type: "bonus",
						accept: !1
					}),
					children: m("games.downforce.decline")
				})] }),
				k && (h?.kind === "follow" || h?.kind === "defensive") && /* @__PURE__ */ f("button", {
					type: "button",
					className: "df-button",
					onClick: () => P({
						type: "chooseCar",
						color: null
					}),
					children: m("games.downforce.decline")
				}),
				k && h?.kind === "wild" && _ === "lucky" && /* @__PURE__ */ p("label", { children: [/* @__PURE__ */ f("input", {
					type: "checkbox",
					checked: D.lucky,
					onChange: (e) => O({ lucky: e.target.checked })
				}), m("games.downforce.luckyRoll")] }),
				!k && t?.bets.length ? /* @__PURE__ */ p("div", {
					className: "df-bets",
					children: [/* @__PURE__ */ f("span", { children: m("games.downforce.bets") }), t.bets.map((e, t) => /* @__PURE__ */ p("span", { children: [
						t + 1,
						".",
						/* @__PURE__ */ f(X, { color: e })
					] }, t))]
				}) : null
			]
		})]
	}), V = e.auction;
	return /* @__PURE__ */ p(l, {
		adaptive: !0,
		scroll: !1,
		className: "df-screen",
		banner: R,
		actions: B,
		actionsHeight: "df-actions-height",
		children: [
			/* @__PURE__ */ f(c, {
				kind: "sheen",
				base: "#263236",
				line: "#c6c5a9"
			}),
			/* @__PURE__ */ p("div", {
				className: "df-center",
				children: [/* @__PURE__ */ f(Re, {
					pub: e,
					legal: k ? M?.next ?? [] : [],
					path: D.path,
					onSpace: (e) => O({ path: [...D.path, e] }),
					carChoices: I,
					onCar: F
				}), /* @__PURE__ */ p("aside", {
					className: "df-race-desk",
					children: [
						/* @__PURE__ */ f(Ue, {
							name: "deck",
							className: "df-desk-card",
							children: V ? /* @__PURE__ */ p("div", {
								className: "df-lot",
								children: [
									/* @__PURE__ */ f(Ue, {
										name: "auction-car",
										className: "df-lot-car",
										children: /* @__PURE__ */ f(X, { color: V.color })
									}),
									/* @__PURE__ */ f("b", { children: m(`games.downforce.${V.color}`) }),
									V.powers.map((e) => /* @__PURE__ */ p("button", {
										type: "button",
										className: "df-power-tile",
										onClick: () => E(e),
										children: [/* @__PURE__ */ f("b", { children: m(`games.downforce.${e}`) }), /* @__PURE__ */ f("small", { children: m(`games.downforce.power_${e}`) })]
									}, e))
								]
							}) : e.activeCard === null ? /* @__PURE__ */ p("div", {
								className: "df-brand",
								children: [
									"DOWN",
									/* @__PURE__ */ f("br", {}),
									"FORCE",
									/* @__PURE__ */ f("span", { children: "↗" })
								]
							}) : /* @__PURE__ */ f(Z, {
								id: e.activeCard,
								activeRow: e.activeRow,
								anchorName: "active-card"
							})
						}),
						/* @__PURE__ */ f("div", {
							className: "df-podium",
							children: e.cars.filter((e) => e.place).sort((e, t) => e.place - t.place).map((e) => /* @__PURE__ */ p(Ue, {
								name: `finish:${e.color}`,
								children: [
									/* @__PURE__ */ f("b", { children: e.place }),
									/* @__PURE__ */ f(X, { color: e.color }),
									/* @__PURE__ */ f("small", { children: e.owner ? v(e.owner) : m("games.downforce.unowned") })
								]
							}, e.color))
						}),
						e.lastDie && /* @__PURE__ */ p("div", {
							className: "df-die",
							children: ["⚄ ", m("games.downforce.die", { n: e.lastDie.value })]
						})
					]
				})]
			}),
			k && e.phase === "powers" && /* @__PURE__ */ f("div", {
				className: "df-choice-overlay",
				children: /* @__PURE__ */ f("div", {
					className: "df-power-grid",
					children: e.players.find((e) => e.rid === r).powers.map((e) => /* @__PURE__ */ p("button", {
						type: "button",
						className: "df-power-tile",
						onClick: () => P({
							type: "power",
							power: e
						}),
						children: [/* @__PURE__ */ f("b", { children: m(`games.downforce.${e}`) }), /* @__PURE__ */ f("small", { children: m(`games.downforce.power_${e}`) })]
					}, e))
				})
			}),
			T && /* @__PURE__ */ f("div", {
				className: "df-choice-overlay",
				onClick: () => E(null),
				children: /* @__PURE__ */ p("div", {
					className: "df-power-detail",
					role: "dialog",
					"aria-label": m(`games.downforce.${T}`),
					onClick: (e) => e.stopPropagation(),
					onKeyDown: (e) => {
						e.key === "Escape" && E(null);
					},
					children: [
						/* @__PURE__ */ f("h2", { children: m(`games.downforce.${T}`) }),
						/* @__PURE__ */ f("p", { children: m(`games.downforce.power_${T}`) }),
						/* @__PURE__ */ f("button", {
							autoFocus: !0,
							type: "button",
							className: "df-button",
							onClick: () => E(null),
							children: m("games.downforce.confirm")
						})
					]
				})
			})
		]
	});
}
function Ue({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = o(e);
	return /* @__PURE__ */ f("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function We({ rid: e, active: t, me: n, children: r }) {
	let { ref: i } = o(`crew:${e}`);
	return /* @__PURE__ */ f("div", {
		ref: i,
		className: "df-crew",
		"data-active": t,
		"data-me": n,
		children: r
	});
}
//#endregion
//#region src/games/downforce/bot.ts
var Ge = (e, t) => [...t].reduce((e, t) => e * 31 + t.charCodeAt(0) >>> 0, e.log.length * 2654435761), Q = (e, t) => e.players.find((e) => e.rid === t)?.power;
function $(e, t, n, r) {
	let i = e.cars.find((e) => e.color === r), a = t.bets.reduce((e, t, n) => e + (t === r ? [
		2.6,
		1.8,
		1
	][n] : 0), 0);
	return (i.owner === n ? 3.4 : i.owner === null ? 0 : -.8) + a;
}
function Ke(e, t, n, r, i) {
	let a = z(e, t, n), o = e.cars.find((e) => e.color === t.color), s = k[e.track], c = r * (a.distance - o.distance + (a.finished ? s.length * .25 : 0));
	if (i === "search" && a.node) {
		let n = s.nodes[a.node].next.filter((n) => n === "finish" || !e.cars.some((e) => e.color !== t.color && e.node !== null && s.nodes[e.node].physical === s.nodes[n].physical)).length;
		c += r * n * 18, s.nodes[a.node].rumble && o.owner && e.powers[o.owner] === "tough" && (c += r * 120), a.rectangles && o.owner && e.powers[o.owner] === "determined" && t.source === "card" && (c += r * 120);
	}
	return c;
}
function qe(e, t, n = 1, r = "search") {
	let i = [[]], a = [], o = r === "search" ? 18 : 4;
	for (let s = 0; s <= t.speed; s += 1) {
		let s = [];
		for (let n of i) {
			let r = z(e, t, n);
			if (r.complete && r.valid) {
				a.push(n);
				continue;
			}
			for (let e of r.next) s.push([...n, e]);
		}
		if (!s.length) break;
		s.sort((i, a) => Ke(e, t, a, n, r) - Ke(e, t, i, n, r)), i = s.slice(0, o);
	}
	return a.sort((i, a) => Ke(e, t, a, n, r) - Ke(e, t, i, n, r)), a[0] ?? [];
}
var Je = {
	aggressive: 5,
	cunning: 7,
	determined: 6,
	strategic: 5,
	tricky: 5,
	unpredictable: 4,
	ambitious: 6,
	experienced: 7,
	reckless: 3,
	tough: 7,
	bold: 7,
	defensive: 5,
	civilized: 3,
	lucky: 4
};
function Ye(e, t) {
	return t === "determined" ? Object.values(k[e.track].nodes).filter((e) => e.rectangle).length / Object.keys(k[e.track].nodes).length * 12 : t === "experienced" ? e.players.length + 3 : Je[t];
}
function Xe(e, t, n, r) {
	let i = Q(e, t), a = e.cars.find((e) => e.color === n).owner === t && i === "bold" && r <= 2 ? 3 : r;
	return {
		kind: "move",
		actor: t,
		color: n,
		speed: a,
		rampSpeed: a,
		source: "card",
		forcedTarget: null
	};
}
function Ze(e, t, n, r, i, a) {
	let o = y[r], s = i ? [...o.rows].reverse() : o.rows, c = [];
	if (a === "baseline") return s.reduce((r, i) => r + (i.color === "W" ? Math.max(...g.filter((e) => !o.rows.some((t) => t.color === e)).map((r) => i.value * $(e, t, n, r))) : i.value * $(e, t, n, i.color)), 0);
	let l = structuredClone(A(e)), u = 0;
	for (let r of s) {
		let i = (r.color === "W" ? g.filter((t) => !c.includes(t) && (Q(e, n) === "unpredictable" || !o.rows.some((e) => e.color === t))) : [r.color]).map((i) => {
			let a = l.cars.find((e) => e.color === i), o = $(e, t, n, i), s = Xe(e, n, i, r.value);
			if (!a.node) return {
				color: i,
				path: [],
				value: 0,
				move: s
			};
			let c = qe(l, s, Math.sign(o) || -1, "baseline"), u = z(l, s, c);
			return {
				color: i,
				path: c,
				value: o * ((u.distance - a.distance) / 130 + (u.finished ? 8 : 0)),
				move: s
			};
		}).sort((e, t) => t.value - e.value)[0];
		if (!i) continue;
		r.color === "W" && c.push(i.color);
		let a = l.cars.find((e) => e.color === i.color);
		if (a.node) {
			let e = z(l, i.move, i.path);
			a.node = e.node, a.distance = e.distance;
		}
		u += i.value;
	}
	return u;
}
function Qe(e, t, n, r = "search", i = !1) {
	if (!t.needsDecision) return null;
	if (e.phase === "auction") {
		let r = t.bidOptions;
		if (!r.length) return null;
		if (i) return {
			type: "bid",
			...r[Ge(e, n) % r.length]
		};
		let a = e.auction.color, o = t.hand.reduce((e, t) => e + y[t].rows.reduce((e, t) => e + (t.color === a ? t.value : t.color === "W" ? t.value * .35 : 0), 0), 0), s = e.cars.filter((e) => e.owner === n).length, c = 4.3 + Math.min(3, o / 18) + Math.max(...e.auction.powers.map((t) => Ye(e, t))) * .16 - s * .35, l = r.filter((e) => e.value <= c), u = [...l.length ? l : r].sort((e, t) => t.value - e.value || y[t.card].rows.length - y[e.card].rows.length)[0];
		return {
			type: "bid",
			card: u.card,
			row: u.row
		};
	}
	if (e.phase === "powers") return {
		type: "power",
		power: [...e.players.find((e) => e.rid === n).powers].sort((t, n) => Ye(e, n) - Ye(e, t))[0]
	};
	if (e.phase === "bet") return {
		type: "bet",
		color: [...e.cars].sort((e, n) => {
			let r = (e) => e.place === 1 ? 1e9 : e.place === null ? e.distance + (i ? 0 : t.hand.reduce((t, n) => t + y[n].rows.reduce((t, n) => t + (n.color === e.color ? n.value * 12 : 0), 0), 0)) : 1e8 - e.place * 1e6;
			return r(n) - r(e);
		})[0].color
	};
	let a = e.decision;
	if (!a || a.actor !== n) return null;
	if (a.kind === "card") {
		let a = [...t.hand, ...e.players.find((e) => e.rid === n).reserve].flatMap((a) => [!1, ...Q(e, n) === "tricky" ? [!0] : []].map((o) => ({
			card: a,
			reverse: o,
			value: Ze(e, t, n, a, o, i ? "baseline" : r)
		}))).sort((e, t) => t.value - e.value), o = i ? a[Ge(e, n) % a.length] : a[0];
		if (!o) return null;
		let s = y[o.card], c = Q(e, n) === "strategic" && s.rows.length === 6 ? s.rows.filter((e) => e.color !== "W").sort((r, i) => $(e, t, n, r.color) * r.value - $(e, t, n, i.color) * i.value)[0]?.color : null;
		return {
			type: "play",
			card: o.card,
			reverse: o.reverse,
			aggressive: !0,
			skip: c ?? null,
			civilizedRow: null,
			civilizedColor: null
		};
	}
	if (a.kind === "wild") {
		let o = A(e), s = a.choices.map((i) => {
			let s = Xe(e, n, i, a.speed), c = e.cars.find((e) => e.color === i), l = $(e, t, n, i);
			if (!c.node) return {
				color: i,
				value: 0
			};
			let u = z(o, s, qe(o, s, Math.sign(l) || -1, r));
			return {
				color: i,
				value: l * (u.distance - c.distance + (u.finished ? 1e3 : 0))
			};
		}).sort((e, t) => t.value - e.value), c = i ? a.choices[Ge(e, n) % a.choices.length] : s[0].color;
		return {
			type: "wild",
			color: c,
			lucky: Q(e, n) === "lucky" && e.cars.find((e) => e.color === c).owner === n && a.speed < 4
		};
	}
	return a.kind === "move" ? {
		type: "move",
		path: qe(A(e), a, Math.sign($(e, t, n, a.color)) || -1, i ? "baseline" : r)
	} : a.kind === "bonus" ? {
		type: "bonus",
		accept: !0
	} : a.kind === "follow" || a.kind === "defensive" ? {
		type: "chooseCar",
		color: [...a.colors].sort((t, n) => e.cars.find((e) => e.color === t).distance - e.cars.find((e) => e.color === n).distance)[0] ?? null
	} : null;
}
var $e = (e, t) => {
	if (!e.private) return null;
	let n = Qe(e.public, e.private, t.rid, "search", t.difficulty === "weak");
	return n ? { action: n } : null;
};
//#endregion
//#region src/games/downforce/fx.tsx
function et({ frames: e, color: t, ms: n }) {
	let a = i(null);
	return r(() => {
		let t = a.current;
		if (!t) return;
		let r = e[0].angle, i = e.map((t, n) => {
			let i = t.angle;
			for (; i - r > 180;) i -= 360;
			for (; i - r < -180;) i += 360;
			return r = i, {
				transform: `translate(${t.box.x + t.box.w / 2 - e[0].box.w / 2}px,${t.box.y + t.box.h / 2 - e[0].box.h / 2}px) rotate(${i}deg)`,
				opacity: n === e.length - 1 && t.box.w === 0 ? 0 : 1
			};
		}), o = t.animate(i, {
			duration: n,
			fill: "both",
			easing: "linear"
		});
		return () => o.cancel();
	}, [e, n]), /* @__PURE__ */ f("div", {
		ref: a,
		style: {
			position: "absolute",
			left: 0,
			top: 0,
			width: e[0].box.w,
			height: e[0].box.h,
			filter: "drop-shadow(0 3px 2px #131b2299)"
		},
		children: /* @__PURE__ */ f(X, { color: t })
	});
}
var tt = {
	drive: (e, t) => {
		let n = e.data;
		if (!g.includes(n.color) || !k[n.track]) return null;
		let r = k[n.track], i = t.queued ? 180 : 455, a = [n.from, ...n.path.filter((e) => e !== "finish")].flatMap((e) => {
			let n = t.anchor(`node:${e}`);
			return n ? [{
				box: n,
				angle: r.nodes[e].angle * 180 / Math.PI
			}] : [];
		});
		if (n.finish) {
			let e = a.at(-1), r = t.anchor(`finish:${n.color}`);
			a.push({
				box: r ?? {
					...e.box,
					x: e.box.x + e.box.w,
					y: e.box.y - e.box.h,
					w: 0,
					h: 0
				},
				angle: 0
			});
		}
		return a.length < 2 ? null : {
			ms: i,
			node: /* @__PURE__ */ f(et, {
				frames: a,
				color: n.color,
				ms: i
			}),
			hide: t.queued ? [] : [n.finish ? `finish:${n.color}` : `car:${n.color}`]
		};
	},
	play: (e, t) => {
		let n = e.data, r = t.myRid === e.rid ? t.anchor(`hand:${e.rid}`) : t.anchor(`crew:${e.rid}`), i = t.anchor("active-card");
		if (!r || !i) return null;
		let a = t.queued ? 130 : 320;
		return {
			ms: a,
			node: /* @__PURE__ */ f(m, {
				from: {
					...r,
					w: i.w,
					h: i.h
				},
				to: i,
				ms: a,
				children: /* @__PURE__ */ f(Z, { id: n.card })
			}),
			hide: t.queued ? [] : ["active-card"]
		};
	},
	auction: (e, t) => {
		let n = e.data, r = t.anchor("auction-car"), i = t.anchor(`crew:${e.rid}`);
		if (!r || !i) return null;
		let a = t.queued ? 140 : 420, o = {
			x: i.x + 10,
			y: i.y + 25,
			w: 65,
			h: 40
		};
		return {
			ms: a,
			node: /* @__PURE__ */ f(m, {
				from: r,
				to: o,
				ms: a,
				children: /* @__PURE__ */ f(X, { color: n.color })
			})
		};
	},
	draw: (e, t) => {
		let n = t.anchor("deck"), r = t.anchor(`hand:${e.rid}`);
		if (!n || !r || t.myRid !== e.rid) return null;
		let i = t.queued ? 130 : 300;
		return {
			ms: i,
			node: /* @__PURE__ */ f(m, {
				from: {
					...n,
					w: 80,
					h: 120
				},
				to: {
					...r,
					w: 80,
					h: 120
				},
				ms: i,
				children: /* @__PURE__ */ f("div", {
					style: {
						width: "100%",
						height: "100%",
						background: "#c94a32",
						border: "5px double #f0e7cf",
						display: "grid",
						placeItems: "center",
						color: "#f0e7cf",
						fontWeight: 900
					},
					children: "↗"
				})
			})
		};
	},
	animal: (e, t) => {
		let n = e.data, r = t.anchor(`animal-node:${n.id}:${n.from}`);
		if (!r) return null;
		let i = (n.to < 0 ? null : t.anchor(`animal-node:${n.id}:${n.to}`)) ?? {
			...r,
			x: r.x + r.w,
			w: 0,
			h: 0
		}, a = t.queued ? 140 : 360;
		return {
			ms: a,
			node: /* @__PURE__ */ f(m, {
				from: r,
				to: i,
				ms: a,
				children: /* @__PURE__ */ f(Ie, { id: n.id })
			}),
			hide: t.queued ? [] : [`animal:${n.id}`]
		};
	}
};
//#endregion
//#region src/games/downforce/game-over.tsx
function nt(e) {
	let t = s(), n = e.public, [r, i] = a(!0), o = (t) => e.members.find((e) => e.rid === t)?.name ?? t, c = e.result.ranking;
	return /* @__PURE__ */ p("div", {
		className: "df-result-root df-screen",
		children: [
			/* @__PURE__ */ f(He, {
				...e,
				pub: n,
				priv: void 0,
				send: () => {}
			}),
			!r && /* @__PURE__ */ f("button", {
				type: "button",
				className: "df-show-results df-main-button",
				onClick: () => i(!0),
				children: t("games.downforce.showResults")
			}),
			/* @__PURE__ */ f("div", {
				className: "df-result-shade",
				hidden: !r,
				children: /* @__PURE__ */ p("section", {
					className: "df-result-sheet",
					"aria-label": t("games.downforce.results"),
					children: [
						/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", {
							className: "df-result-kicker",
							children: "DOWNFORCE / FINISH"
						}), /* @__PURE__ */ f("h1", { children: t("games.downforce.results") })] }), /* @__PURE__ */ f("button", {
							type: "button",
							className: "df-result-close",
							onClick: () => i(!1),
							"aria-label": t("games.downforce.closeResults"),
							children: "⌄"
						})] }),
						/* @__PURE__ */ p("div", {
							className: "df-result-scroll",
							children: [
								/* @__PURE__ */ f("div", {
									className: "df-result-podium",
									children: n.cars.filter((e) => e.place).sort((e, t) => e.place - t.place).map((e) => /* @__PURE__ */ p("div", { children: [
										/* @__PURE__ */ f("span", { children: e.place }),
										/* @__PURE__ */ f(X, { color: e.color }),
										/* @__PURE__ */ f("b", { children: e.owner ? o(e.owner) : t("games.downforce.unowned") })
									] }, e.color))
								}),
								/* @__PURE__ */ f("div", {
									className: "df-score-scroll",
									children: /* @__PURE__ */ p("table", {
										className: "df-score-table",
										children: [/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {}), c.map((t) => /* @__PURE__ */ f("th", {
											"data-winner": e.result.winner.includes(t),
											children: /* @__PURE__ */ p("span", { children: [e.result.winner.includes(t) ? "🏆 " : "", o(t)] })
										}, t))] }) }), /* @__PURE__ */ p("tbody", { children: [[
											"race",
											"bets",
											"cost",
											"total"
										].map((e, r) => /* @__PURE__ */ p("tr", {
											"data-total": e === "total",
											children: [/* @__PURE__ */ f("th", { children: t(`games.downforce.${[
												"racePrize",
												"betPrize",
												"auctionCost",
												"total"
											][r]}`) }), c.map((t) => /* @__PURE__ */ p("td", { children: [e === "cost" ? "−" : "", n.scores?.[t][e] ?? 0] }, t))]
										}, e)), [
											0,
											1,
											2
										].map((e) => /* @__PURE__ */ p("tr", {
											className: "df-score-bet",
											children: [/* @__PURE__ */ f("th", { children: t("games.downforce.bet", { n: e + 1 }) }), c.map((t) => /* @__PURE__ */ f("td", { children: n.finalBets?.[t]?.[e] ? /* @__PURE__ */ f(X, { color: n.finalBets[t][e] }) : /* @__PURE__ */ f("span", { children: "—" }) }, t))]
										}, e))] })]
									})
								}),
								c.some((t) => (e.result.autopilot?.[t] ?? 0) > 0) && /* @__PURE__ */ f("div", {
									className: "df-result-notes",
									children: c.filter((t) => (e.result.autopilot?.[t] ?? 0) > 0).map((n) => /* @__PURE__ */ p("p", { children: [
										o(n),
										" · ",
										t("games.downforce.autopilot", { n: Math.round(e.result.autopilot[n] * 100) })
									] }, n))
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ f("p", {
									className: "df-result-notes",
									children: t("session.hint.usedCount", { n: e.hintCount })
								})
							]
						}),
						/* @__PURE__ */ p("footer", { children: [
							/* @__PURE__ */ f("button", {
								type: "button",
								className: "df-button",
								onClick: () => i(!1),
								children: t("games.downforce.review")
							}),
							e.onPlayAgain && /* @__PURE__ */ f("button", {
								type: "button",
								className: "df-main-button",
								onClick: e.onPlayAgain,
								children: t("session.result.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ f("button", {
								type: "button",
								className: "df-button",
								onClick: e.onBackToLobby,
								children: t("session.result.backToLobby")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ f("span", { children: t("session.result.waitHost") })
						] })
					]
				})
			}),
			e.result.winner.length > 0 && /* @__PURE__ */ f(h, {})
		]
	});
}
//#endregion
//#region src/games/downforce/options.tsx
function rt({ value: e, onChange: t }) {
	let n = s(), r = te.parse(e ?? {});
	return /* @__PURE__ */ p("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ p("label", {
			className: "flex flex-col gap-2 font-bold",
			children: [n("games.downforce.track"), /* @__PURE__ */ f("select", {
				className: "rounded border-2 p-2",
				value: r.track,
				onChange: (e) => t({
					...r,
					track: e.target.value
				}),
				children: v.map((e) => /* @__PURE__ */ f("option", {
					value: e,
					children: n(`games.downforce.${e}`)
				}, e))
			})]
		}), [
			"dangerPowers",
			"promoPowers",
			"pairedPowers"
		].map((e) => /* @__PURE__ */ p("label", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ f("input", {
				type: "checkbox",
				checked: r[e],
				disabled: e === "pairedPowers" && !r.dangerPowers,
				onChange: (n) => t({
					...r,
					[e]: n.target.checked
				})
			}), n(`games.downforce.${e}`)]
		}, e))]
	});
}
//#endregion
//#region src/games/downforce/guide.tsx
function it() {
	let e = s();
	return /* @__PURE__ */ f("div", {
		style: {
			padding: 16,
			lineHeight: 1.7,
			maxWidth: 850,
			margin: "auto"
		},
		children: /* @__PURE__ */ f("dl", { children: _.map((t) => /* @__PURE__ */ p("div", {
			style: {
				padding: "9px 0",
				borderTop: "1px solid #8886"
			},
			children: [/* @__PURE__ */ f("dt", {
				style: { fontWeight: 800 },
				children: e(`games.downforce.${t}`)
			}), /* @__PURE__ */ f("dd", {
				style: { margin: 0 },
				children: e(`games.downforce.power_${t}`)
			})]
		}, t)) })
	});
}
//#endregion
//#region src/games/downforce/locales/zh.ts
var at = {
	name: "玩命赛道",
	desc: "竞拍赛车、掌控车流，在终点兑现你的眼光。",
	rules: "目标：\n赛车奖金与三次下注奖金之和，减去竞拍费用，净收益最高者获胜。平分时，拥有名次最高赛车的玩家获胜。所有金额均以百万计。\n准备：\n42 张普通速度牌平均分发，余牌移出。六辆赛车随机排列。依次竞拍赛车及能力，出价牌不消耗。每人至少拥有一辆赛车；当剩余赛车数等于无车玩家数时，只有无车玩家可以出价。最后一辆赛车只有一名无车玩家时，该玩家必须给出最低有效出价。无人竞拍的赛车向无车玩家再拍一次，仍无人出价则成为无主赛车。\n竞拍：\n整手有目标颜色时，使用该颜色出价；否则使用白色万能行；也没有万能行时，使用所选牌上的最低数字。可用不含有效目标颜色的牌弃权。同价先比较牌上赛车数量，再优先没有万能行的牌；仍相同时，按照本局确定的座位优先顺序判定；该顺序在每次竞拍后轮换。赢家支付出价并获得对应的速度 8 牌与能力。拥有多张能力的玩家选择其中一张，全局使用。\n比赛：\n最前方起跑位的车主先行动。依次打出一张速度牌，从上到下移动每一行对应的赛车。每辆赛车必须走足格数，或走到被阻挡。只能向前或斜前移动，不得横移、后退或穿过赛车。同一格只能停一辆赛车；大格仍算一格。允许主动选择会被阻挡的路线。万能行选择牌上没有的颜色，同一张牌的两条万能行必须选不同颜色。已完赛的颜色仍可选，但不移动。\n下注：\n任一赛车第一次越过一条下注线后，整张速度牌及能力结算完毕，所有玩家秘密选择预期冠军。三轮可押同一颜色。根据所押赛车的最终名次，三轮下注奖金如下，金额均以百万计：\n· 第一轮下注：第一、第二和第三名分别获得9、6、3。\n· 第二轮下注：第一、第二和第三名分别获得6、4、2。\n· 第三轮下注：第一、第二和第三名分别获得3、2、1。\n赛车按第一至第六名，分别获得12、9、6、4、2、0的名次奖金。\n结束：\n赛车越过终点立即收走并记录名次。一名玩家的所有赛车完赛后，该玩家弃去余牌，仍参与下注。所有赛车完赛或没有玩家能够出牌时结算，未完赛车没有赛车奖金。没有赛车的玩家仍正常出牌。\n两人局：\n竞拍后将每人 21 张普通牌洗成个人牌堆，抽 7 张；每次打出普通手牌后补 1 张。竞拍获得的速度 8 牌公开放在旁边，使用后不补牌。\n赛道：\n· 河畔与码头为基础赛道。\n· 十字街区的交叉口按进入方向继续，不能抄近路。\n· 蛇形山路的危险格只能在无普通格可走时进入，且必须依靠本次移动与已满足的能力追加移动离开。\n· 阿罗哈沙滩的跳台要求原速度达到标示数值，落点空置，跳跃消耗 1 格。\n· 塞伦盖蒂的动物阻挡赛车；越过动物线后，整牌末将动物移到下一个空动物格，经过最后一个位置后离场。\n能力：\n在选牌或相应决策时查看能力说明。本游戏包含基础六能力、Danger Circuit 六能力、Civilized 与 Lucky 两张官方赠卡；不含初学者、长途赛与世界巡回可选变体。",
	errInvalid: "这个行动不符合当前规则。",
	errTurn: "现在不能执行这个行动。",
	hintAction: "建议：{{action}}",
	action_bid: "选择竞价牌",
	action_power: "选择能力",
	action_play: "打出速度牌",
	action_wild: "选择万能行颜色",
	action_move: "规划赛车路线",
	action_bonus: "使用追加移动",
	action_chooseCar: "选择赛车",
	action_bet: "选择下注赛车",
	action_tick: "等待赛车落位",
	river: "河畔赛道",
	marina: "码头赛道",
	crosstown: "十字街区",
	switchback: "蛇形山路",
	aloha: "阿罗哈沙滩",
	savanna: "塞伦盖蒂",
	K: "黑色赛车",
	B: "蓝色赛车",
	G: "绿色赛车",
	O: "橙色赛车",
	R: "红色赛车",
	Y: "黄色赛车",
	W: "万能行",
	aggressive: "积极进取",
	cunning: "精明老练",
	determined: "坚定不移",
	strategic: "深谋远虑",
	tricky: "出其不意",
	unpredictable: "变幻莫测",
	ambitious: "雄心勃勃",
	experienced: "经验丰富",
	reckless: "勇往直前",
	tough: "坚韧不拔",
	bold: "大胆果敢",
	defensive: "稳守反击",
	civilized: "礼让有方",
	lucky: "幸运之星",
	power_aggressive: "你的回合，多色牌顶行明确印有你的赛车颜色时，该车可以多移动 1 格。万能行与单色牌不适用。",
	power_cunning: "你的赛车始终由你选择路线，包括其他玩家的回合。",
	power_determined: "任何回合，你的赛车在牌面移动中进入的格子全部为完整矩形时，可以追加移动 2 格。起点与追加移动的格子不限形状。",
	power_strategic: "你的回合，打出包含全部六种颜色的牌时，可以忽略其中一种颜色。",
	power_tricky: "你的回合，可以从下到上依次执行牌面。",
	power_unpredictable: "你的万能行可以选择牌上已有的颜色；两条万能行仍须选择不同颜色。",
	power_ambitious: "任何回合，你的赛车每越过一条下注线，在本次移动后可以追加移动 2 格。",
	power_experienced: "任何回合，原本位于你的赛车正前方的赛车移动后，你的一辆符合条件的赛车可以跟进它的起始格。斜前方不适用。",
	power_reckless: "你的回合，你的赛车从斜向相邻的两辆赛车之间斜穿后，可以追加移动 2 格。",
	power_tough: "任何回合，你的赛车停在接触红白路肩的格子后，可以追加移动 2 格；若再次停在路肩旁，可以再次触发。",
	power_bold: "你的回合，你的赛车由速度牌移动 1 或 2 格时，改为移动 3 格。万能行适用，能力追加移动不适用。",
	power_defensive: "你的回合，整张牌没有移动你的任何赛车时，可以选择一辆自己的赛车移动 3 格。",
	power_civilized: "你的回合，可以选择牌上一辆属于其他玩家的赛车，由车主在其余赛车之前移动。",
	power_lucky: "你的回合，用万能行移动自己的赛车时，可以掷六面骰，用骰点代替原速度。",
	track: "赛道",
	dangerPowers: "加入 Danger Circuit 能力",
	promoPowers: "加入官方赠卡能力",
	pairedPowers: "每辆赛车搭配两张能力",
	auction: "竞拍 · 第 {{n}} 轮",
	chooseBid: "选择竞价牌与数字",
	pass: "弃权",
	bid: "出价 {{n}}",
	cost: "费用 {{n}}",
	million: "{{n}} 百万",
	choosePower: "选择本场能力",
	play: "打出速度牌",
	waiting: "等待 {{name}}",
	waitingAll: "等待其他玩家",
	settling: "赛车落位中",
	wild: "选择万能行颜色 · {{n}} 格",
	move: "{{car}} · 移动 {{n}} 格",
	bonus: "{{power}} · 追加 {{n}} 格",
	follow: "选择一辆赛车跟进",
	defensiveChoice: "选择一辆赛车移动 3 格",
	bet: "第 {{n}} 次秘密下注",
	betOn: "押注 {{car}}",
	confirm: "确认",
	cancel: "取消",
	undo: "撤回一步",
	decline: "放弃追加移动",
	accept: "追加移动",
	finishMove: "完成移动",
	aggressiveExtra: "顶行赛车多移动 1 格",
	reverse: "从下到上",
	skip: "忽略一种颜色",
	noSkip: "全部移动",
	civilizedFirst: "礼让赛车先行",
	noCivilized: "按通常顺序",
	luckyRoll: "掷骰替代速度",
	die: "骰点 {{n}}",
	hand: "速度牌",
	reserve: "公开速度 8",
	selected: "已选择",
	plan: "已规划 {{n}} / {{total}} 格",
	blocked: "前方受阻",
	zoomIn: "放大赛道",
	zoomOut: "缩小赛道",
	fit: "查看全图",
	focus: "跟随当前赛车",
	space: "选择前方格子",
	finishSpace: "驶过终点",
	owned: "{{name}} 的赛车",
	unowned: "无主赛车",
	place: "第 {{n}} 名",
	racing: "比赛进行中",
	auctionResult: "{{car}} · {{name}} · {{n}} 百万",
	none: "无人竞得",
	bets: "我的下注",
	handCount: "{{n}} 张牌",
	results: "最终收益",
	racePrize: "赛车奖金",
	betPrize: "下注奖金",
	auctionCost: "竞拍费用",
	total: "净收益",
	podium: "终点名次",
	review: "回看赛道",
	showResults: "查看收益",
	closeResults: "收起收益表",
	autopilot: "托管 {{n}}%",
	finish: "终点",
	betLine: "下注线 {{n}}",
	antelope: "羚羊",
	elephant: "大象",
	python: "蟒蛇"
}, ot = {
	definition: Fe,
	View: Ve,
	bot: $e,
	fx: tt,
	OverView: nt,
	Options: rt,
	Guide: it,
	locales: {
		zh: at,
		en: {
			...at,
			name: "Downforce",
			desc: "Bid for cars, control the traffic, and cash in at the finish.",
			rules: "Goal: earn the most money from racing and betting, minus auction costs. Ties go to the owner of the highest placed car. All amounts are in millions.\nDeal the 42 regular speed cards evenly, removing leftovers. Randomize the six starting cars. Auction each car with its power and matching speed-8 card. Bid using the car color if present anywhere in your hand; otherwise use a wild; without either, use the lowest value on your chosen card. Pass with a card without an eligible color. Equal bids favor more car rows, then no wild; any remaining tie uses this game’s seat priority order, which rotates after each auction. When the remaining cars equal the players without cars, only those players bid. The last sole eligible player must bid their lowest legal value. Unsold cars are offered once more to players without cars, then remain unowned. Choose one power if you acquired several.\nThe owner of the foremost starting car plays first. Play one speed card and resolve its rows from top to bottom. Each car moves its full speed or until blocked. Move forward or diagonally forward, never sideways or backward, and never through an occupied space. Large spaces still cost one step. You may choose a route that becomes blocked. Wilds name colors absent from the card; two wilds must name different colors. Finished colors remain valid wild choices but do not move.\nAfter the complete card and powers resolve, crossing a new betting line prompts everyone to bet secretly on a winner. Bets may repeat. For a bet on a car finishing first, second, or third, the rewards are:\n· First betting round: 9, 6, or 3 respectively.\n· Second betting round: 6, 4, or 2 respectively.\n· Third betting round: 3, 2, or 1 respectively.\nRacing prizes from first through sixth are 12, 9, 6, 4, 2, and 0. All amounts are in millions.\nRemove a car immediately when it finishes. Players whose cars have all finished discard their remaining cards but still bet. Players with no car continue playing. End when all cars finish or nobody can play; unfinished cars earn no racing prize.\nTwo players: after auctioning, shuffle your 21 regular cards into a personal deck and draw seven. Replace each regular card played. Keep speed-8 cards face up separately; playing one does not draw a replacement.\nTracks:\n· River and Marina are the base circuits.\n· Crosstown intersections preserve the route of entry.\n· Switchback danger spaces can be entered only when no ordinary destination is available, and must be exited within this move plus actually earned power movement.\n· Aloha ramps require the original speed shown on the ramp and an empty landing; a jump costs one step.\n· Serengeti animals block cars. After a card crosses their current line, move them to the next empty animal space at the end of that card; after their last space they leave.\nIncludes all six base powers, six Danger Circuit powers, and Civilized and Lucky promos. Beginner, Long Distance, and World Tour variants are not included. See power cards for their full effects.",
			errInvalid: "That action is not legal now.",
			errTurn: "You cannot act now.",
			hintAction: "Suggestion: {{action}}",
			action_bid: "Choose a bid",
			action_power: "Choose a power",
			action_play: "Play a speed card",
			action_wild: "Choose a wild color",
			action_move: "Plan a route",
			action_bonus: "Take bonus movement",
			action_chooseCar: "Choose a car",
			action_bet: "Place a bet",
			action_tick: "Wait for the car",
			river: "River",
			marina: "Marina",
			crosstown: "Crosstown",
			switchback: "Switchback",
			aloha: "Aloha Sands",
			savanna: "Serengeti",
			K: "Black car",
			B: "Blue car",
			G: "Green car",
			O: "Orange car",
			R: "Red car",
			Y: "Yellow car",
			W: "Wild",
			aggressive: "Aggressive",
			cunning: "Cunning",
			determined: "Determined",
			strategic: "Strategic",
			tricky: "Tricky",
			unpredictable: "Unpredictable",
			ambitious: "Ambitious",
			experienced: "Experienced",
			reckless: "Reckless",
			tough: "Tough",
			bold: "Bold",
			defensive: "Defensive",
			civilized: "Civilized",
			lucky: "Lucky",
			power_aggressive: "On your turn, your explicitly colored car at the top of a multicolor card may move one extra space. Wilds and single-color cards do not qualify.",
			power_cunning: "You always choose routes for your own cars, even on other players’ turns.",
			power_determined: "On any turn, if every space your car enters during its card movement is a perfect rectangle, it may move two extra spaces. The starting and bonus spaces may have any shape.",
			power_strategic: "On your turn, you may ignore one color on a card showing all six colors.",
			power_tricky: "On your turn, you may resolve your speed card from bottom to top.",
			power_unpredictable: "Your wilds may name colors already on the card. Two wilds still need different colors.",
			power_ambitious: "On any turn, each betting line crossed by your car earns two optional extra spaces after its movement.",
			power_experienced: "On any turn, when a car that started directly ahead of your car moves away, one of your eligible cars may follow into its starting space. Diagonal adjacency does not qualify.",
			power_reckless: "On your turn, after your car passes diagonally between two diagonally adjacent cars, it may move two extra spaces.",
			power_tough: "On any turn, when your car ends a move touching a red-and-white rumble strip, it may move two extra spaces. This can trigger again.",
			power_bold: "On your turn, card movement of one or two for your car becomes three. Wilds qualify; power movement does not.",
			power_defensive: "On your turn, if none of your cars moved during the entire card, you may move one of your cars three spaces.",
			power_civilized: "On your turn, choose another player’s car on your card. Its owner moves it before you resolve the remaining rows.",
			power_lucky: "On your turn, when a wild moves your car, you may replace its speed with a six-sided die roll.",
			track: "Track",
			dangerPowers: "Include Danger Circuit powers",
			promoPowers: "Include official promo powers",
			pairedPowers: "Two powers with each car",
			auction: "Auction · {{n}}",
			chooseBid: "Choose a card and bid value",
			pass: "Pass",
			bid: "Bid {{n}}",
			cost: "Cost {{n}}",
			million: "{{n}} million",
			choosePower: "Choose your power",
			play: "Play speed card",
			waiting: "Waiting for {{name}}",
			waitingAll: "Waiting for other players",
			settling: "Car moving",
			wild: "Choose a wild color · {{n}} spaces",
			move: "{{car}} · {{n}} spaces",
			bonus: "{{power}} · {{n}} extra spaces",
			follow: "Choose a car to follow",
			defensiveChoice: "Choose your car to move three spaces",
			bet: "Secret bet {{n}}",
			betOn: "Bet on {{car}}",
			confirm: "Confirm",
			cancel: "Cancel",
			undo: "Undo step",
			decline: "Decline bonus",
			accept: "Take bonus",
			finishMove: "Finish move",
			aggressiveExtra: "Move the top car one extra space",
			reverse: "Bottom to top",
			skip: "Ignore one color",
			noSkip: "Move all colors",
			civilizedFirst: "Let a car go first",
			noCivilized: "Usual order",
			luckyRoll: "Roll for speed",
			die: "Rolled {{n}}",
			hand: "Speed cards",
			reserve: "Public speed 8",
			selected: "Selected",
			plan: "Route {{n}} / {{total}}",
			blocked: "Blocked ahead",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			fit: "Full track",
			focus: "Follow active car",
			space: "Choose a space ahead",
			finishSpace: "Cross the finish",
			owned: "{{name}}’s car",
			unowned: "Unowned car",
			place: "Place {{n}}",
			racing: "Race in progress",
			auctionResult: "{{car}} · {{name}} · {{n}} million",
			none: "Unsold",
			bets: "My bets",
			handCount: "{{n}} cards",
			results: "Final earnings",
			racePrize: "Race prizes",
			betPrize: "Bet prizes",
			auctionCost: "Auction costs",
			total: "Net earnings",
			podium: "Finishing order",
			review: "Review track",
			showResults: "Show earnings",
			closeResults: "Hide earnings",
			autopilot: "Autopilot {{n}}%",
			finish: "Finish",
			betLine: "Betting line {{n}}",
			antelope: "Antelope",
			elephant: "Elephant",
			python: "Python"
		}
	}
};
//#endregion
export { ot as default };
